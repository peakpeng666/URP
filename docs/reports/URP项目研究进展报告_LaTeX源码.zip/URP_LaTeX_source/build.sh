#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p output qa .cache .texmf/web2c
export XDG_CACHE_HOME="$PWD/.cache"
# Some slim TeX Live images ship sources but omit ls-R and prebuilt formats.
if ! kpsewhich article.cls >/dev/null 2>&1; then
  export TEXMF="{$PWD/.texmf,/usr/share/texlive/texmf-dist,/usr/share/texmf,/etc/texmf}"
fi
if ! kpsewhich xelatex.fmt >/dev/null 2>&1; then
  export TEXFORMATS="$PWD/.texmf/web2c//:"
  if [[ ! -f .texmf/web2c/xelatex.fmt ]]; then
    (cd .texmf/web2c && xetex -ini -etex -jobname=xelatex -progname=xelatex -interaction=nonstopmode xelatex.ini > format-build.stdout 2>&1)
  fi
fi
export BIBINPUTS="$PWD:"
xelatex -halt-on-error -interaction=nonstopmode -output-directory=output main.tex > output/pass1.stdout
(cd output && bibtex main > bibtex.stdout)
xelatex -halt-on-error -interaction=nonstopmode -output-directory=output main.tex > output/pass2.stdout
xelatex -halt-on-error -interaction=nonstopmode -output-directory=output main.tex > output/pass3.stdout
cp output/main.pdf 'URP项目研究进展报告.pdf'
pdfinfo 'URP项目研究进展报告.pdf' > output/pdfinfo.txt
if [[ "${1:-}" == "--render" ]]; then
  pdftoppm -r 120 -png 'URP项目研究进展报告.pdf' qa/page >/dev/null 2>&1
fi
printf 'Built: %s/URP项目研究进展报告.pdf\n' "$PWD"
