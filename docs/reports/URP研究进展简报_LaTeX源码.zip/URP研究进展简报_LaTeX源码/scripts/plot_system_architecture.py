"""Redraw only: verified existing architecture.pdf + full/sections/system.tex.
Fixed source identity: 41e6bdc221cbe5e733a583fbadb287afd0534723.
No new execution, algorithm availability, or LLM integration is asserted.
"""
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch
from matplotlib.font_manager import FontProperties
font=FontProperties(fname='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
plt.rcParams['pdf.fonttype']=3
fig,ax=plt.subplots(figsize=(11.8,7.0)); fig.subplots_adjust(left=.01,right=.99,bottom=.01,top=.99)
ax.set_xlim(0,11.6);ax.set_ylim(0,6.9);ax.axis('off')
blue='#eaf2f8';green='#edf5ef';orange='#fff3e7';gray='#f3f4f6';ink='#263c4c'
def txt(x,y,s,size=12.5,weight='normal',color=ink):
 ax.text(x,y,s,ha='center',va='center',fontproperties=font,fontsize=size,weight=weight,color=color,linespacing=1.5)
def box(x,y,w,h,s,fc=blue,size=12.5,dash=False):
 ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.045,rounding_size=0.08',fc=fc,ec='#7890a0',lw=1.1,linestyle='--' if dash else '-'));txt(x+w/2,y+h/2,s,size)
def arrow(x,y,a,b,dash=False):
 ax.add_patch(FancyArrowPatch((x,y),(a,b),arrowstyle='-|>',mutation_scale=12,color='#627786',lw=1.1,linestyle='--' if dash else '-',connectionstyle='arc3'))
txt(5.8,6.67,'农业机器人路径规划与智能推荐系统',18,'bold')
box(3.2,5.76,5.2,.62,'系统前端：二维任务 / ROS三维 / Gazebo场景\n实时遥测 / 实验图表 / 历史回放',size=11.5)
box(.12,5.65,2.56,.85,'后续扩展（尚未闭环）\nLLM解析、推荐与调用验证',orange,11.5,True)
arrow(2.73,6.07,3.16,6.07,True)
box(8.95,5.65,2.53,.85,'历史BPP静态 /data\n只读导出记录',gray,12)
arrow(8.45,6.07,8.90,6.07)
arrow(5.8,5.71,5.8,5.36)
box(3.65,4.80,4.3,.52,'4100 网关  ·  FastAPI / 同源路由',size=13)
# branch labels and columns
arrow(4.5,4.77,3.15,4.27);txt(2.55,4.65,'/lab/api',12)
arrow(7.1,4.77,9.7,4.27);txt(9.45,4.65,'/api → 4180',12)
# left group bounding backdrop
ax.add_patch(FancyBboxPatch((.08,.86),7.55,3.40,boxstyle='round,pad=0.03',fc='#fafcfe',ec='#ccd9e2',lw=1))
txt(3.85,4.01,'在线规划、独立检查与仿真执行',14,'bold')
box(.3,3.05,2.15,.60,'任务调度\n隔离求解子进程',size=12)
box(2.84,3.05,2.15,.60,'算法库适配\n5类问题 / 28配置',size=12)
box(5.38,3.05,2.0,.60,'独立结果检查\n按任务模型验算',size=12)
arrow(2.49,3.35,2.79,3.35);arrow(5.03,3.35,5.33,3.35)
box(.3,2.03,3.2,.60,'Lab SQLite + 原始文件\n输入、输出、日志与决策记录',size=12)
arrow(6.38,3.00,6.38,2.69)
ax.plot([5.7,5.7,1.9],[3.00,2.83,2.83],color='#627786',lw=1.1)
arrow(1.9,2.83,1.9,2.68)
box(5.38,2.03,2,.60,'执行准入 / 重验算\n车型、资产与语义',green,11.5)
box(.3,1.09,3.2,.59,'轨迹、真值与停留检查\n保存执行结果 / 回读与回放',green,12)
box(4.02,1.09,3.36,.59,'ROS 2 / Gazebo\n内置同构差速车 · 串行放行',green,12)
arrow(6.38,1.98,6.38,1.73);arrow(3.97,1.38,3.55,1.38)
# archive independent branch
ax.add_patch(FancyBboxPatch((7.94,.86),3.53,3.40,boxstyle='round,pad=0.03',fc='#fffcf8',ec='#dfd0bf',lw=1))
txt(9.70,4.01,'独立数值任务与研究档案',13.2,'bold')
box(8.14,3.05,3.13,.60,'4180 archive 后端\n冻结历史 / 串行CVRP任务',orange,12)
box(8.14,2.03,3.13,.60,'研究 runner + validator\n截止时间 / 检查点 / 状态',orange,12)
box(8.14,1.09,3.13,.59,'archive SQLite / 文件包\n独立记录与档案视图',orange,12)
arrow(9.70,3,9.70,2.68);arrow(9.70,1.98,9.70,1.73)
txt(5.8,.54,'各分支由共享前端读取；规划、执行和历史记录分别展示，回放不计为新实验。',12)
txt(5.8,.18,'配置按依赖与任务准入条件启用；现有自然语言入口为规则/词汇解析；虚线表示后续工作。',11.5,color='#5b6670')
out=Path(__file__).resolve().parents[1]/'figures'
fig.savefig(out/'architecture.pdf',bbox_inches='tight',pad_inches=.04)
fig.savefig(out/'architecture-preview.png',dpi=170,bbox_inches='tight',pad_inches=.04)
