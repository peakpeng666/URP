#!/usr/bin/env python3
"""Chinese vector re-rendering from immutable copied report tables; no new experiments."""
from pathlib import Path
import csv,json,hashlib,shutil,subprocess,os
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
font_manager.fontManager.addfont('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
FONT=font_manager.FontProperties(fname='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc').get_name()
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'source-index'/'plot-data'
(ROOT/'preview').mkdir(exist_ok=True)
for sub in ['research','agriculture']:
 (ROOT/'figures'/sub).mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'font.family':FONT,'axes.unicode_minus':False,'font.size':10,'pdf.fonttype':3,'axes.spines.top':False,'axes.spines.right':False})
manifest=[]
def read(rel):
 p=SRC/rel; dest=SRC/rel; dest.parent.mkdir(parents=True,exist_ok=True);
 if p.resolve()!=dest.resolve(): shutil.copy2(p,dest)
 manifest.append({'input':rel,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'source':str(p.relative_to(ROOT))})
 return list(csv.DictReader(p.open(encoding='utf-8-sig')))
def save(fig,name):
 sub='research' if name.startswith('core') else 'agriculture'
 target=ROOT/'figures'/sub/f'{name}.pdf'
 fig.savefig(target,bbox_inches='tight')
 fig.savefig(ROOT/'preview'/f'{name}.png',dpi=150,bbox_inches='tight');plt.close(fig)
r=read('core/main_algorithm_summary.csv'); labels=[a['algorithm'] for a in r]; y=np.arange(len(r));valid=np.array([int(a['valid']) for a in r]);total=np.array([int(a['planned']) for a in r]);gap=np.array([float(a['case_equal_gap_pct']) for a in r])
f,(a,b)=plt.subplots(1,2,figsize=(12,7),sharey=True,gridspec_kw={'width_ratios':[1,1.15]})
a.barh(y,valid,color='#277b8b',label='有效解');a.barh(y,total-valid,left=valid,color='#dbb494',label='无有效解');a.set_yticks(y,labels);a.invert_yaxis();a.set_xlim(0,310)
for i,v in enumerate(valid):a.text(268,i,f'{v}/265',va='center',fontsize=8)
a.set_xlabel('计划运行数（包含失败）');a.legend(loc='lower center',bbox_to_anchor=(.5,1.01),ncol=2,frameon=False)
b.barh(y,gap,color='#6d8da3');b.set_xlim(0,145)
for i,v in enumerate(gap):b.text(v+1,i,f'{v:.3f}',va='center',fontsize=8)
b.set_xlabel('问题等权参考差距（%）\n仅含有效子集；历史主机条件不完全相同')
f.tight_layout();save(f,'core01_coverage_quality')
r=read('core/main_verified_cloud0_cpu.csv');m={a['algorithm']:a for a in r};f,a=plt.subplots(figsize=(9,6.6));v=[float(m[k]['mean_cpu_s']) for k in labels];a.barh(y,v,color='#277b8b');a.set_yticks(y,labels);a.invert_yaxis();a.set_xlim(0,5.5);a.set_xlabel('工作进程平均 CPU 时间（s，所有已启动运行）');a.set_title('已核验云端 seed 0 批次：每配置 53 次运行');f.tight_layout();save(f,'core05_verified_cpu_only')
r=read('agriculture/nl124_penalty_counts.csv');f,a=plt.subplots(figsize=(10,4.8));x=np.arange(4);v=[int(z['valid']) for z in r];h=[int(z['hit']) for z in r]
a.bar(x-.18,v,.36,label='独立核验可行',color='#277b8b');a.bar(x+.18,h,.36,label='命中自身目标最优',color='#d6a054');a.set_xticks(x,['E / 默认罚项','E / 输入派生罚项','G / 默认罚项','G / 输入派生罚项']);a.set_ylim(0,420);a.set_ylabel('运行次数（每组计划 372 次）')
for dx,vs in [(-.18,v),(.18,h)]:
 for xx,vv in zip(x,vs):a.text(xx+dx,vv+5,str(vv),ha='center',fontsize=10)
a.legend(loc='upper center',ncol=2,frameon=False);f.tight_layout();save(f,'agri01_nl124_feasibility')
r=read('agriculture/nl124_proxy_deltas.csv');p=sorted([z for z in r if float(z['delta_m'])>1e-8],key=lambda z:-float(z['delta_m']));assert len(p)==13 and len(r)==124
f,a=plt.subplots(figsize=(9,4.8));v=[float(z['delta_m']) for z in p];names=[z['field'].removeprefix('nl_field_') for z in p];a.bar(range(13),v,color=['#b96846']+['#6d8da3']*12);a.set_xticks(range(13),names,rotation=45);a.set_ylabel('距离代理差（m）');a.set_xlabel('地块编号（13块正差；111块零差未绘出）');a.text(.98,.94,f'地块42：{v[0]:.3f} m\n占总差值的 {v[0]/sum(v)*100:.2f}%',transform=a.transAxes,ha='right',va='top');f.tight_layout();save(f,'agri02_nl124_proxy_gap')
(ROOT/'source-index'/'plot_provenance.json').write_text(json.dumps({'description':'Frozen CSV values rendered as new vector charts; no rerun, raster editing or data alteration. Algorithm/API identifiers preserved.','inputs':manifest},ensure_ascii=False,indent=2))
