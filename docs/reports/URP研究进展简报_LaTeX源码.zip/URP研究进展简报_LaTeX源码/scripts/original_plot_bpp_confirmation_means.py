#!/usr/bin/env python3
"""Render all six distinct BPP means from the frozen recomputed CSV, without changing values."""
import csv
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'source-index/data/bpp/confirmation_algorithm_summary.csv'
OUT=ROOT/'figures/historical'
rows={r['algorithm']:r for r in csv.DictReader(SOURCE.open(encoding='utf-8-sig'))}
font=FontProperties(family='Noto Sans CJK SC')
plt.rcParams.update({'font.family':font.get_name(),'axes.unicode_minus':False,'pdf.fonttype':3,'font.size':10})
items=[('BF','全程 BF','#6d8da3'),('BF_then_EoH','BF前500→EoH（训练SBS）','#d4a041'),('published_EoH','全程已发表 EoH','#9a8bb6'),('SELECTOR','前缀选择器','#21877b'),('branch_oracle','同状态分支 oracle','#505050'),('full_run_oracle','全程起点 oracle','#b66b58')]
assert float(rows['SBS']['mean_bins']) == float(rows['BF_then_EoH']['mean_bins'])
fig,ax=plt.subplots(figsize=(9.2,4.9))
for y,(key,label,color) in enumerate(items):
 v=float(rows[key]['mean_bins']);assert int(rows[key]['n'])==108
 ax.scatter(v,y,s=57,color=color,zorder=3)
 ax.annotate(f'{v:.3f}',(v,y),xytext=(7,0),textcoords='offset points',ha='left',va='center',fontsize=10)
ax.set_yticks(range(6),[i[1] for i in items],fontproperties=font)
ax.invert_yaxis();ax.set_ylim(5.5,-.5);ax.set_xlim(2723,2811)
ax.set_xticks(range(2730,2811,10))
ax.set_title('BPP确认集：108条流 / 36个多重集簇',fontproperties=font,pad=10)
ax.set_xlabel('最终平均箱数（越低越好；点图横轴为局部范围）',fontproperties=font)
ax.grid(axis='x',color='#e6e6e6',alpha=.8);ax.set_axisbelow(True)
ax.spines[['top','right']].set_visible(False)
fig.subplots_adjust(left=.26,right=.985,bottom=.145,top=.90)
fig.savefig(OUT/'bpp_confirmation_means.pdf')
fig.savefig(OUT/'bpp_confirmation_means.png',dpi=200)
print('Rendered:',[(i[0],float(rows[i[0]]['mean_bins'])) for i in items])
