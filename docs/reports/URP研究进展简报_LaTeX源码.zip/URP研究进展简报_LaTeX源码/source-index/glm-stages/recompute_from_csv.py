"""Recompute sanitized saved results. No networking or candidate execution."""
import csv,json,statistics
from fractions import Fraction
from pathlib import Path
p=Path(__file__).resolve().parent
L=[2012,1983,1978,1986,1980]
def fitness(b):return sum((Fraction(l,n) for l,n in zip(L,b)),Fraction())/5
bf=fitness([2094,2059,2057,2067,2058])
r=list(csv.DictReader(open(p/'p2_all60_sanitized.csv')))
assert len(r)==60
for x in r:
 if x['fitness_numerator']:
  f=fitness(json.loads(x['bins']));assert f==Fraction(int(x['fitness_numerator']),int(x['fitness_denominator']))
  assert x['relative_to_BF']==('higher' if f>bf else 'equal' if f==bf else 'lower')
s=json.load(open(p/'p2_recomputed_summary.json'))
for a in ['EOH_TC','IID_TC']:
 rr=[x for x in r if x['arm']==a];v=[Fraction(int(x['fitness_numerator']),int(x['fitness_denominator'])) for x in rr if x['fitness_numerator']]
 assert len(rr)==30 and len(v)==s['arms'][a]['complete']
 assert float(sum(v)/len(v))==s['arms'][a]['conditional_mean']
 assert float(statistics.median(v))==s['arms'][a]['conditional_median']
 assert float(max(v))==s['arms'][a]['best_fitness']
print('PASS: all 60 statuses retained; 43 exact fitness values and both arm summaries verified.')
