# URP研究进展简报 LaTeX源码

本工程为六章连续排版的研究简报。保留独立的既有详细报告，不覆盖其文件。

## 编译

依赖：XeLaTeX、BibTeX、Poppler、Noto Serif CJK SC、Noto Sans CJK SC和DejaVu Sans Mono。
运行 `bash build.sh`，输出 `URP研究进展简报.pdf`；`bash build.sh --render` 生成逐页PNG。字体使用系统安装版本，无须分发平台缓存。

## 研究内容与来源

正文以截至2026-10-19的研究记录及同一冻结版本的原始档案组织而成；本轮配套详细报告为110页。固定提交为41e6bdc221cbe5e733a583fbadb287afd0534723。此轮为材料整理、数值复算和排版，不包含新的模型调用、候选执行或求解实验。

- `source-index/text_sources.json`记录既有详细报告章节身份。
- `source-index/glm-stages/`含P1/P2摘要、60槽精简数据、精确分数复算脚本和原始归档来源。后补FF/BF对照与原始P2协议分别标记。
- `source-index/selection-studies/`含时间窗配置互补、64新几何选择及邻域/容量研究的归档来源与精简结果。
- `source-index/selected_figures.csv`列出本简报图资产的来源、SHA-256与在main.tex中的顺序，不复用详细报告的页码作为简报位置。
- `source-index/plot-data/`与`scripts/plot_chinese.py`用于从冻结CSV重绘四张中文统计图。脚本需Python、matplotlib、numpy及Noto Sans CJK字体（输出PDF采用Type3矢量字形，避免合并时的字体子集映射冲突）。原始会话截图和原始结果图未经内容改写。

实验分母、预算、成功子集、独立几何、后补对照与留出集条件均在正文相应结果旁说明。完整逐运行数据仍见原始档案；精简源包不重复收录全量存档。

## 项目书与算法库

`source-index/proposal_requirements.md`记录研究要求和阶段安排，不含行政个人信息。`catalog-summary.json`为固定提交的28配置、5类问题静态目录；与17配置CVRP正式面板存在重叠，不相加。`code_sources.json`记录实现出处。原定图搜索、采样规划、局部避障和任务优化四类及11算法逐项对应，注册、调用、实验验证与执行能力分别说明。

## 本轮介绍结构调整

开篇按算法库、已开展实验和系统功能三条主线组织。软件成果统一称为“农业机器人路径规划与智能推荐系统”；通用候选研究称为LLM辅助算法生成与筛选，具体模型设置保留原名。实验数据、统计口径与原始来源链接保持不变。

系统章节进一步说明任务级规划、检查、执行、可视化与实验记录的联系，区分已实现的运行关联与待验证的研究反馈；`source-index/visualization_sources.json`记录固定源码和既有日志的来源身份。
