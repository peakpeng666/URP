URP saved-work handoff, 2026-10-14

Base commit: f110f039854f7314e36632ce7d3ee977cd0de0fc
Branch: repair/cvrplib-preflight-20261014
This archive contains only existing uncommitted changes and saved evidence. No new experiment was run for packaging.
files/ preserves repository-relative paths; changes.patch includes modified and added files, including binary data.
To review against the base checkout: git apply --check /path/to/changes.patch
To apply after review: git apply /path/to/changes.patch
Do not execute cvrplib_acceptance.py merely to inspect this handoff: its interrupted grid is incomplete.

Verified saved evidence: 20 targeted tests; 93 research regression tests; 53 inputs/references verified; 51 bases; 53 model-only matrix checks; 44/50 invented grid calls saved.
One earlier P-n19-k2 call yielded a deadline-valid cost 212. None are formal batch results.
Final freeze, remaining tests, and review were stopped by parent. Latest additions have no final full regression.
Historical reports/results/freeze archives and src/checks.json were not modified.
Excluded: .git, virtual environments, cached bytecode, unrelated repositories, credentials.
