"""Post-run reference scoring. This module is never imported by the worker."""
from fractions import Fraction
import json
from pathlib import Path

from .audit import independent_input, validator
from .io import contract_for, parse_sol, parse_vrp, sha


def evaluate_saved(repo, manifest_path, result_path):
    repo = Path(repo)
    result = json.loads(Path(result_path).read_text())
    manifest = json.loads(Path(manifest_path).read_text())
    case = next(c for c in manifest['cases'] if c['case_id'] == result['case_id'])
    vrp = repo/case['instance_path']
    sol = repo/case['reference']['path']
    if sha(vrp) != case['instance_sha256'] or sha(sol) != case['reference']['sha256']:
        raise ValueError('input/reference hash mismatch')
    if result['case_manifest_sha256'] != sha(manifest_path):
        raise ValueError('result manifest hash mismatch')
    contract = contract_for(case, parse_vrp(vrp.read_text()), result['contract']['id']=='derived-capped-X')
    if contract != result['contract']:
        raise ValueError('saved fleet contract mismatch')
    p = independent_input.parse_vrp(vrp.read_text(), contract['K'])
    routes, cost = parse_sol(sol.read_text())
    ref = validator.validate_solution(p, routes, cost)
    candidate = validator.validate_solution(p, result.get('routes'), result.get('cost'))
    eligible = (result.get('feasible') and result['status'] in {'OK','TIMEOUT_WITH_FEASIBLE_INCUMBENT'}
                and ref['valid'] and candidate['valid'] and candidate['reported_cost_checked'])
    gap = Fraction(100*(candidate['cost']-cost), cost) if eligible and cost > 0 else None
    return {'result_sha256':sha(result_path), 'contract':contract,
            'candidate_check':candidate,'reference_check':ref,
            'reference_label':case['reference']['label'], 'optimality_proved_here':False,
            'eligible_for_gap':bool(eligible),'gap_percent':float(gap) if gap is not None else None,
            'gap_exact':str(gap) if gap is not None else None,
            'reference_review_required':gap is not None and gap < 0}
