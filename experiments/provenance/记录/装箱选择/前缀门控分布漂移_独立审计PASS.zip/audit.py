"""Read-only independent trace audit. Never imports candidate or packing engine."""
import pathlib,json,hashlib,hmac,time,resource,signal,sys,zipfile,collections
from fractions import Fraction
resource.setrlimit(resource.RLIMIT_CPU,(15,15));signal.alarm(30)
t=time.process_time();w=time.monotonic()
import numpy as np
R=pathlib.Path('/workspace/shared/bpp_prefix_gate_drift_20261008');O=pathlib.Path(__file__).resolve().parent
U=R.parent/'bpp_online_prefix_gate_20261008';A=R.parent/'bpp_online_prefix_gate_audit_20261008'
sha=lambda b:hashlib.sha256(b).hexdigest()
canon=lambda x:json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
read=lambda p:json.loads(p.read_text())
snapshot={str(p.relative_to(R)):sha(p.read_bytes()) for p in R.rglob('*') if p.is_file()}
p=read(R/'policy.json');seal=read(R/'DATA_SEAL.json');freeze=read(R/'SOURCE_FREEZE.json')
for n,h in freeze['files'].items():assert snapshot[n]==h,n
for n in ('engine.py','patch.py'):assert (R/n).read_bytes()==(U/n).read_bytes()
assert p['prefix']==64 and p['threshold']==2880 and p['horizon']==1000 and p['capacity']==100
up=read(R/'UPSTREAM_PASS.json');assert up['status']=='PASS' and up['root_released']
assert sha((A/'AUDIT.json').read_bytes())==up['audit_sha256']
assert sha((A/'PACKAGE_BINDING.json').read_bytes())==up['binding_sha256']
assert read(A/'AUDIT.json')['status']=='PASS_WITH_SCOPE_LIMITS'
assert read(A/'PACKAGE_BINDING.json')['status']=='PASS'
assert sha((R.parent/'bpp_online_prefix_gate_20261008_CLEAN.zip').read_bytes())==up['package_sha256']
assert freeze['frozen_unix']<read(R/'GENERATION_CLAIM.json')['start']<read(R/'RUN_CLAIM.json')['start_unix']
assert up['verified_unix']<read(R/'RUN_CLAIM.json')['start_unix']
assert read(R/'EXIT_RECEIPT.json')['exit_code']==0 and read(R/'EXIT_RECEIPT.json')['reaped']
prior=set(read(R/'exclusions.json')['hashes']);old=set(read(U/'exclusions.json')['hashes'])
old.update(e['items_sha256'] for e in read(U/'DATA_SEAL.json')['instances']);assert prior==old and len(prior)==63
assert len(seal['instances'])==16 and seal['generation_attempts']==1 and seal['candidate_calls_before_seal']==0
assert seal['source_freeze_sha256']==sha((R/'SOURCE_FREEZE.json').read_bytes())
master=(R/'entropy.bin').read_bytes();assert len(master)==32 and sha(master)==seal['entropy_sha256']
# Execute generator definitions only; no main invocation, no writes, no candidate imports.
ns={'__file__':str(R/'generate.py'),'__name__':'generator_readonly_audit'}
exec(compile((R/'generate.py').read_text(),str(R/'generate.py'),'exec'),ns)
class Sentinel:
 def __init__(self):self.calls=[]
 def weibull(self,shape,size):assert shape==3;self.calls.append(('W',size));return np.full(size,13/45)
 def integers(self,low,high,size,dtype):assert (low,high)==(1,101);self.calls.append(('U',size));return np.full(size,79,dtype=dtype)
for d in ('W_to_U','U_to_W'):
 for cp in (64,500):
  a,b=d.split('_to_');r=Sentinel();x=ns['generate'](r,d,cp)
  assert x==[{'W':13,'U':79}[a]]*cp+[{'W':13,'U':79}[b]]*(1000-cp)
  assert r.calls==[(a,cp),(b,1000-cp)]
class Edge:
 def weibull(self,shape,size):return np.array([0,1,1.5,2.5,100,101])/45
assert ns['draw'](Edge(),'W',6)==[1,1,2,2,100,100]
seen=set();verified=[];pairs=[];full=[];groupcounts=collections.Counter()
for e in seal['instances']:
 i=e['sequence'];items=read(R/e['path'])['items'];assert len(items)==1000 and all(type(v)is int and 1<=v<=100 for v in items)
 h=sha(canon(items));assert h==e['items_sha256'] and h not in prior|seen;seen.add(h)
 assert sha((R/e['path']).read_bytes())==e['file_sha256'];assert read(R/e['path'])['capacity']==100
 assert e==dict(p['sequences'][i],path=e['path'],items_sha256=h,file_sha256=e['file_sha256'])
 seed=int.from_bytes(hmac.new(master,b'prefix-drift-v1|'+sha((R/'policy.json').read_bytes()).encode()+b'|'+str(i).encode(),hashlib.sha256).digest()[:16],'big')
 rng=np.random.Generator(np.random.PCG64(seed));cp=e['change_after_item'];direction=e['direction'].split('_to_')
 replay=[]
 for fam,n in zip(direction,(cp,1000-cp)):
  replay.extend(np.round(np.clip(45*rng.weibull(3,size=n),1,100)).astype(np.int64).tolist() if fam=='W' else rng.integers(1,101,size=n,dtype=np.int64).tolist())
 assert replay==items
 prefix=sum(items[:64]);switch=prefix<2880;rr={};groupcounts[e['family']]+=1
 for arm in ('B','P','D','G'):
  r=read(R/f'trajectories/{i:02d}_{arm}.json');rr[arm]=r
  for key in ('sequence','family','within_family','direction','change_after_item','items_sha256'):assert r[key]==e[key]
  assert r['arm']==arm and r['status']=='ok' and r['prefix64_sum']==prefix
  assert len(r['events'])==len(r['assignment'])==1000
  rem=[100]*1000;running=0;rs=[]
  for k,(item,event,j) in enumerate(zip(items,r['events'],r['assignment']),1):
   assert type(j)is int and 0<=j<1000
   method='P' if arm=='P' or k>64 and (arm=='D' or arm=='G' and switch) else 'B'
   counts=collections.Counter(rem);feasible_count=sum(count for v,count in counts.items() if v>=item)
   if method=='B':assert j==rem.index(min(v for v in counts if v>=item))
   before=rem[j];assert before>=item;rem[j]-=item
   assert event==dict(step=k,item=item,bin=j,remaining_before=before,remaining_after=rem[j],method=method,feasible_count=feasible_count)
   running+=item;rs.append(running)
  used=sum(v<100 for v in rem);l1=(sum(items)+99)//100;f=Fraction(l1,used)
  assert rem==r['remaining'] and used==r['used_bins'] and l1==r['L1'] and str(f)==r['F_exact'] and float(f)==r['F']
  assert rs==r['observed_running_sums']
  gate=dict(decision_after_item=64,first_postdecision_item=65,observed_prefix_sum=prefix,threshold=2880,switch=(arm=='D' or switch),rule='unconditional' if arm=='D' else 'strict_less')
  assert r['gate']==(gate if arm in ('D','G') else None)
  clocks=r['boundary_clocks_ns'];assert len(clocks)==1001 and all(clocks[k][c]<=clocks[k+1][c] for k in range(1000) for c in (0,1))
  d=r['segment_diagnostics'];ps=set(r['assignment'][:cp]);ss=set(r['assignment'][cp:])
  for key,val in dict(change_after_item=cp,prefix_used_bins=len(ps),suffix_touched_bins=len(ss),suffix_new_bins=len(ss-ps),cross_boundary_bins=len(ps&ss),total_used_bins=used).items():assert d[key]==val
  assert len(ps)+len(ss-ps)==used
  for c,label in enumerate(('CPU','wall')):
   assert d[f'prefix_{label}_ns']==clocks[cp][c]-clocks[0][c]
   assert d[f'suffix_{label}_ns']==clocks[-1][c]-clocks[cp][c]
  assert r['resources']['prefix64']['used_bins']==len(set(r['assignment'][:64]))
  assert r['resources']['switch_state_copy_count']==0
  verified.append(dict(sequence=i,arm=arm,used_bins=used,F_exact=str(f),legal_steps=1000))
  full.append({k:r[k] for k in ['sequence','family','within_family','arm','used_bins','L1','F_exact','F','status','gate','resources','segment_diagnostics']})
 for arm in ('D','G'):assert rr[arm]['events'][:64]==rr['B']['events'][:64]
 assert rr['G']['events']==rr['D' if switch else 'B']['events']
 pair=dict(sequence=i,family=e['family'],prefix64_sum=prefix,gate_switch=switch)
 for arm in rr:pair[arm+'_bins']=rr[arm]['used_bins'];pair[arm+'_F']=rr[arm]['F_exact']
 for a,b in [('G','B'),('G','P'),('G','D'),('D','P')]:pair[a+'-'+b+'_bins']=rr[a]['used_bins']-rr[b]['used_bins'];pair[a+'-'+b+'_F']=str(Fraction(rr[a]['F_exact'])-Fraction(rr[b]['F_exact']))
 pairs.append(pair)
assert groupcounts==dict.fromkeys(p['families'],4)
assert {(v['sequence'],v['arm']) for v in seal['plan']}=={(i,a) for i in range(16) for a in 'BPDG'} and len(seal['plan'])==64
assert len(list((R/'trajectories').glob('*.json')))==64
assert sorted(full,key=lambda v:(v['sequence'],v['arm']))==sorted(read(R/'RESULTS.json'),key=lambda v:(v['sequence'],v['arm']))
assert pairs==read(R/'PAIRED_RESULTS.json')
contrasts=[]
for fam in p['families']:
 pp=[v for v in pairs if v['family']==fam]
 for a,b in [('G','B'),('G','P'),('G','D'),('D','P')]:
  ds=[v[a+'-'+b+'_bins'] for v in pp];fs=[v[a+'-'+b+'_F'] for v in pp]
  contrasts.append(dict(family=fam,contrast=a+'-'+b,paired_bins=ds,paired_F_exact=fs,complete_pairs=4,missing_pairs=0,mean_delta_bins=sum(ds)/4,mean_delta_F_exact=str(sum(map(Fraction,fs),Fraction())/4),wins_ties_losses=[sum(v<0 for v in ds),sum(v==0 for v in ds),sum(v>0 for v in ds)]))
assert contrasts==read(R/'FAMILY_CONTRASTS.json')
assert snapshot=={str(q.relative_to(R)):sha(q.read_bytes()) for q in R.rglob('*') if q.is_file()},'Source changed during audit'
out=dict(status='PASS_WITH_SCOPE_LIMITS',trajectories=64,placements=64000,prior_hashes_excluded=63,generator_boundaries_and_exact_replay=True,source_byte_identity=True,upstream_audit_admission_verified=True,gate_and_identity_verified=True,candidate_runs=0,solver_runs=0,sequence_results=verified,family_contrasts=contrasts,source_snapshot_sha256=snapshot,limitations=['Recorded patch placements checked for legality, but patch scores deliberately not re-executed.','No assurance beyond supplied 63 historical canonical hashes.','Local timestamps are not externally timestamped preregistration.','Stress sample is not real-world drift frequency or harm prevalence.','No pooled result substitutes for the four direction/change-point groups.','Boundary clocks and separate records support 64 executions; no external attestation of execution provenance.'])
(O/'AUDIT.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
(O/'AUDIT_RECEIPT.json').write_text(json.dumps(dict(status='PASS',CPU_seconds=time.process_time()-t,wall_seconds=time.monotonic()-w,CPU_limit_seconds=15,wall_limit_seconds=30,candidate_runs=0,solver_runs=0,scope='Independent audit process; excludes interactive inspection and subsequent packaging'),indent=2)+'\n')
print(json.dumps({'status':out['status'],'trajectories':64,'placements':64000,'resources':read(O/'AUDIT_RECEIPT.json')}))
