import pathlib,json,hashlib,zipfile,time,csv,resource,signal
resource.setrlimit(resource.RLIMIT_CPU,(15,15));signal.alarm(30)
t=time.process_time();w=time.monotonic()
O=pathlib.Path(__file__).resolve().parent;R=O.parent/'bpp_prefix_gate_drift_20261008';Z=O.parent/'bpp_prefix_gate_drift_20261008_CLEAN.zip'
sha=lambda x:hashlib.sha256(x).hexdigest();read=lambda p:json.loads(p.read_text())
expected='f5d4fe95bc8a033d51adfc83c6aef2cecfe424641bc9ea4fbdd50ef37cd7dea4'
assert sha(Z.read_bytes())==expected
m=read(R/'DELIVERY_MANIFEST.json');assert sha((R/'DELIVERY_MANIFEST.json').read_bytes())=='3c5e9840d28f1e14ec2984d6a3cc925d4bb2bff6b7618fea4623d8cba0be303d'
with zipfile.ZipFile(Z) as z:
 assert z.testzip() is None
 names=z.namelist();assert len(names)==len(set(names))==118
 for n in names:
  assert not n.startswith('/') and '..' not in pathlib.PurePosixPath(n).parts and not n.endswith('.zip')
  assert z.read(n)==(R/n).read_bytes()
 assert set(names)==set(m['files'])|{'DELIVERY_MANIFEST.json'}
 for n,h in m['files'].items():assert sha(z.read(n))==h
snapshot=read(O/'AUDIT.json')['source_snapshot_sha256']
for n,h in snapshot.items():assert sha((R/n).read_bytes())==h,n
plan=read(R/'DATA_SEAL.json')['plan'];prev=None;timings=set()
for a in plan:
 r=read(R/f"trajectories/{a['sequence']:02d}_{a['arm']}.json");cs=r['boundary_clocks_ns'];interval=(tuple(cs[0]),tuple(cs[-1]))
 assert interval not in timings;timings.add(interval)
 if prev is not None:assert all(prev[c]<=cs[0][c] for c in (0,1))
 prev=cs[-1]
# CSV export equivalence (strings versus JSON scalar/list rendering).
for csvname,jsonname in [('paired_results.csv','PAIRED_RESULTS.json'),('sequence_results.csv','SEQUENCE_RESULTS.json'),('family_contrasts.csv','FAMILY_CONTRASTS.json')]:
 with (R/csvname).open() as f:rows=list(csv.DictReader(f))
 expectedrows=read(R/jsonname);assert len(rows)==len(expectedrows)
 for got,expectedrow in zip(rows,expectedrows):assert got=={k:str(v) for k,v in expectedrow.items()}
result=dict(status='PASS',package=str(Z),sha256=expected,members=118,bytes=Z.stat().st_size,all_manifest_members_verified=True,audited_scientific_bytes_match=True,distinct_nonoverlapping_execution_intervals=64,CSV_JSON_identity=True,CPU_seconds=time.process_time()-t,wall_seconds=time.monotonic()-w)
(O/'PACKAGE_BINDING.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
