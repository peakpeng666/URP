import pathlib,json,zipfile,hashlib
R=pathlib.Path('/workspace/shared/bpp_online_prefix_gate_20261008');O=pathlib.Path(__file__).resolve().parent;Z=pathlib.Path(str(R)+'_CLEAN.zip');H=lambda b:hashlib.sha256(b).hexdigest()
expected='e105b8fce756f12ca35bf690baee3edcf91b531943bc74bb18b4eb2a541095aa';assert H(Z.read_bytes())==expected
m=json.loads((R/'DELIVERY_MANIFEST.json').read_text());prior=json.loads((O/'AUDIT.json').read_text())['source_snapshot_sha256']
with zipfile.ZipFile(Z) as z:
 names=z.namelist();base=R.name+'/'
 # Accept exact manifest names, with a single common root if used by the packer.
 prefix=base if all(n.startswith(base) for n in names) else ''
 assert len(names)==96 and len(names)==len(set(names));assert set(names)=={prefix+n for n in m['artifacts']}|{prefix+'DELIVERY_MANIFEST.json'}
 for n,h in m['artifacts'].items():
  assert H(z.read(prefix+n))==h==H((R/n).read_bytes())
  if n in prior:assert h==prior[n]
 assert z.read(prefix+'DELIVERY_MANIFEST.json')==(R/'DELIVERY_MANIFEST.json').read_bytes()
 assert z.testzip() is None
binding=dict(status='PASS',package=str(Z),sha256=expected,bytes=Z.stat().st_size,members=96,manifest_sha256=H((R/'DELIVERY_MANIFEST.json').read_bytes()),all_manifest_members_verified=True,audited_scientific_bytes_match=True,packaging_correction='Earlier COMPLETE draft self-included during packaging. Excluded from this clean manifest-selected package; no scientific file change or solver rerun. Do not archive draft.',scientific_preseal_count_scope='candidate_calls_before_seal=0 means scientific input evaluations only; recorded toy patch calls occurred before seal.')
(O/'PACKAGE_BINDING.json').write_text(json.dumps(binding,indent=2,ensure_ascii=False));print(json.dumps(binding))
