"""Read-only evidence audit. Never imports or executes any candidate or producer code."""
import json,pathlib,hashlib,time,resource,signal,ast
from fractions import Fraction
R=pathlib.Path('/workspace/shared/bpp_online_prefix_gate_20261008'); O=pathlib.Path(__file__).resolve().parent
resource.setrlimit(resource.RLIMIT_CPU,(15,15));signal.alarm(30); c0=time.process_time();t0=time.monotonic()
read=lambda p:json.loads((R/p).read_text()); H=lambda b:hashlib.sha256(b).hexdigest(); canon=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
before={str(p.relative_to(R)):H(p.read_bytes()) for p in R.rglob('*') if p.is_file()}
seal=read('DATA_SEAL.json');freeze=read('SOURCE_FREEZE.json');pol=read('policy.json')
for f,h in freeze['files'].items():assert before[f]==h,('freeze',f)
assert H((R/'SOURCE_FREEZE.json').read_bytes())==seal['source_freeze_sha256']
assert H((R/'entropy.bin').read_bytes())==seal['entropy_sha256']
old=pathlib.Path('/workspace/shared/bpp_nearfit_distribution_20261008')
method=json.loads((old/'methods.json').read_text())['methods']['EOH_nearfit_one']
assert (R/'patch.py').read_bytes()==method['code'].encode();assert before['patch.py']==method['code_sha256']==pol['patch_sha256']
oldmanifest=read('evidence/d1_manifest.json');oldex=read('evidence/d1_exclusions.json');ex=set(read('exclusions.json')['hashes'])
assert ex==set(oldex['prior_1000_prefix_sha256'])|{x['items_sha256'] for x in oldmanifest['instances']}
assert len(ex)==51
for e in oldmanifest['instances']:
 raw=(old/e['relative_file']).read_bytes();assert H(raw)==e['file_sha256'];assert H(canon(json.loads(raw)['items']))==e['items_sha256']
assert freeze['frozen_unix']<read('GENERATION_CLAIM.json')['start']<read('RUN_CLAIM.json')['start_unix']
assert read('RUN_CLAIM.json')['attempt']==read('LAUNCH_CLAIM.json')['attempt']==1
assert seal['generation_attempts']==1 and seal['candidate_calls_before_seal']==0
assert seal['plan']==pol['actions'];assert len(seal['plan'])==48
assert {(a['sequence'],a['arm']) for a in seal['plan']}=={(i,a) for i in range(12) for a in 'BPDG'}
result=read('RESULTS.json');assert [(r['sequence'],r['arm']) for r in result]==[(a['sequence'],a['arm']) for a in seal['plan']]
summary={(r['sequence'],r['arm']):r for r in result};sq={(r['sequence'],r['arm']):r for r in read('SEQUENCE_RESULTS.json')}
assert len(list((R/'trajectories').glob('*.json')))==48
seen=set();metrics={};checks=[];times=[]
for e in seal['instances']:
 i=e['sequence'];raw=(R/e['path']).read_bytes();assert H(raw)==e['file_sha256'];x=json.loads(raw)['items'];h=H(canon(x));assert h==e['items_sha256'] and h not in seen|ex;seen.add(h)
 assert len(x)==1000 and all(type(v) is int and 1<=v<=100 for v in x);assert e['family']==pol['families'][i//4]
 rr={};s=sum(x[:64]);l1=(sum(x)+99)//100
 for a in 'BPDG':
  r=read(f'trajectories/{i:02d}_{a}.json');rr[a]=r;assert len(r['assignment'])==len(r['events'])==1000
  rem=[100]*1000;used=set()
  for k,(v,j,ev) in enumerate(zip(x,r['assignment'],r['events']),1):
   assert type(j) is int and 0<=j<1000 and rem[j]>=v
   m='P' if a=='P' or k>64 and (a=='D' or a=='G' and s<2880) else 'B'
   feas=[z for z in range(1000) if rem[z]>=v]
   if m=='B':assert j==min(feas,key=lambda z:(rem[z],z)),('BF',i,a,k)
   assert ev==dict(step=k,item=v,bin=j,remaining_before=rem[j],remaining_after=rem[j]-v,method=m,feasible_count=len(feas))
   rem[j]-=v;used.add(j)
  b=len(used);f=Fraction(l1,b);assert rem==r['remaining'] and sum(100-y for y in rem)==sum(x)
  assert r['used_bins']==b and r['L1']==l1 and r['F_exact']==str(f) and r['F']==float(f)
  assert r['sequence']==i and r['family']==e['family'] and r['items_sha256']==h and r['status']=='ok'
  gate=None if a in 'BP' else dict(decision_after_item=64,first_postdecision_item=65,observed_prefix_sum=s,threshold=2880,switch=(a=='D' or s<2880),rule='unconditional' if a=='D' else 'strict_less')
  assert r['gate']==gate
  for key,val in summary[i,a].items():assert r[key]==val
  for key,val in sq[i,a].items():assert r[key]==val
  assert r['resources']['switch_state_copy_count']==0 and r['resources']['CPU_ns']>0 and r['resources']['wall_ns']>0
  times.append((r['resources']['CPU_ns'],r['resources']['wall_ns']));metrics[i,a]=(b,f)
  checks.append(dict(sequence=i,arm=a,legal_steps=1000,bins=b,F_exact=str(f),prefix_sum=s))
 assert rr['B']['events'][:64]==rr['D']['events'][:64]==rr['G']['events'][:64]
 assert rr['G']['events']==rr['D' if s<2880 else 'B']['events']
 assert rr['G']['assignment']==rr['D' if s<2880 else 'B']['assignment']
assert len(set(times))==48
pairs=read('PAIRED_RESULTS.json');assert len(pairs)==12
for p in pairs:
 i=p['sequence'];x=read(seal['instances'][i]['path'])['items'];assert p['prefix64_sum']==sum(x[:64]) and p['gate_switch']==(sum(x[:64])<2880)
 for a in 'BPDG':assert p[a+'_bins']==metrics[i,a][0] and p[a+'_F']==str(metrics[i,a][1])
 for ab in pol['contrasts']:
  a,b=ab.split('-');assert p[ab+'_bins']==metrics[i,a][0]-metrics[i,b][0];assert p[ab+'_F']==str(metrics[i,a][1]-metrics[i,b][1])
contrasts=[]
for r in read('FAMILY_CONTRASTS.json'):
 pp=[p for p in pairs if p['family']==r['family']];ab=r['contrast'];ds=[p[ab+'_bins'] for p in pp];fs=[p[ab+'_F'] for p in pp]
 assert r['paired_bins']==ds and r['paired_F_exact']==fs and r['complete_pairs']==4 and r['missing_pairs']==0
 assert r['mean_delta_bins']==sum(ds)/4 and r['mean_delta_F_exact']==str(sum(map(Fraction,fs),Fraction())/4)
 assert r['wins_ties_losses']==[sum(d<0 for d in ds),sum(d==0 for d in ds),sum(d>0 for d in ds)]
 contrasts.append(r)
assert len(contrasts)==12
# Recorded boundary tests only: no solver invocation.
for case in read('TOYS.json')['cases']:
 x=case['input'];r=case['trajectories'];s=sum(x[:64])
 if len(x)>=64:
  assert r['G']['gate']['switch']==(s<2880);assert r['G']['events']==r['D' if s<2880 else 'B']['events']
# AST/manual source review: runner supplies only items/arm, patch only item and feasible residuals.
engine=ast.parse((R/'engine.py').read_text());pack=next(n for n in engine.body if isinstance(n,ast.FunctionDef) and n.name=='pack')
assert [x.arg for x in pack.args.args]==['items','arm']
assert not any(isinstance(n,ast.Name) and n.id in {'family','sequence','source','label'} for n in ast.walk(pack))
assert not any(isinstance(n,ast.Subscript) and isinstance(n.value,ast.Name) and n.value.id=='items' for n in ast.walk(pack))
exit=read('EXIT_RECEIPT.json');assert exit['exit_code']==0 and exit['reaped'] and not exit['retry'] and exit['CPU_total']<180 and exit['wall_seconds']<240
assert (R/'stderr.txt').stat().st_size==0
assert all(H((R/f).read_bytes())==h for f,h in before.items())
report=dict(status='PASS_WITH_SCOPE_LIMITS',scientific_trajectories=48,placements=48000,independent_BF_and_integer_reconstruction=True,candidate_executions_by_auditor=0,old_candidate_replays=0,new_solver_runs=0,source_snapshot_sha256=before,checks=checks,family_contrasts=contrasts,execution_evidence={'unique_timing_pairs':48,'runner_pack_calls':48,'fresh_state_per_pack':True,'original_exit':exit,'scope':'Static call path, complete raw event records, distinct measured durations and clean exit support 48 independent executions; this is not trusted external execution attestation.'},limitations=['No patch score rerun; patch placement legality and source integrity checked, not independently recomputed scores.','No assurance against unavailable historical input arrays; all 51 supplied prior canonical hashes excluded.','Frozen and generation ordering rely on locally recorded timestamps, not externally timestamped preregistration.','Fine-grained CPU timers often return zero; no zero-overhead claim.','Known horizon len(items)=1000 controls empty-bin reservoir; no future item values or family labels used.','12 fresh streams support exploratory paired results only; no calibrated risk guarantee or distribution-general improvement.'])
(O/'AUDIT.json').write_text(json.dumps(report,indent=2,ensure_ascii=False))
(O/'AUDIT_RECEIPT.json').write_text(json.dumps(dict(status='PASS',CPU_seconds=time.process_time()-c0,wall_seconds=time.monotonic()-t0,CPU_limit_seconds=15,wall_limit_seconds=30,original_files_unchanged=True,candidate_calls=0),indent=2))
print(json.dumps({'status':report['status'],'trajectories':48,'CPU':time.process_time()-c0,'wall':time.monotonic()-t0}))
