#!/usr/bin/env python3
"""Read-only audit of frozen artifacts. Does not import experiment code or generate paths."""
import json, math, itertools, hashlib, zipfile, time, resource, datetime
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CPU,(6,6))
START=time.process_time()
ROOT=Path('/workspace/shared/dubins_graph_limits_20261007')
OLD=Path('/workspace/shared/curvature_routes_20261007')
OUT=Path(__file__).resolve().parent
J=lambda p:json.loads(p.read_text())
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
TAU=2*math.pi
checks=[]
def ok(name):checks.append(name)
def near(x,y,tol=2e-8):assert abs(x-y)<=tol,(x,y)
def pose_error(q,p):return math.dist(q[:2],p[:2]),abs(math.remainder(q[2]-p[2],TAU))
def pose_check(q,p):
 a,b=pose_error(q,p);assert a<2e-8 and b<2e-10,(q,p,a,b);return a,b
cfg=J(ROOT/'freeze.json');ids=cfg['instance_ids'];grid=J(ROOT/'input/intermediate_grid.json')
oldcfg=J(OLD/'freeze.json');oldgeoms=J(OLD/'instances.json');geoms=J(ROOT/'input/instances_selected5.json')
assert ids==J(OLD/'failure_index.json')['both_failures_in_candidate_graph']
assert len(ids)==5
oldrows=J(OLD/'raw/results.json')
assert [r['instance_id'] for r in oldrows if not r['dubins_dp_feasible']]==ids
assert all(r['R']==6 for r in oldrows if r['instance_id'] in ids)
assert geoms==[g for g in oldgeoms if g['geometry_id']+'_R6' in ids]
assert cfg['rectangle']==oldcfg['rectangle']==[0.,40.,0.,30.]
assert cfg['R']==6. and cfg['obstacles']==[]
assert all(len(g['poses'])==8 and g['poses'][0]==oldcfg['depot_pose'] for g in geoms)
poses={g['geometry_id']+'_R6':g['poses'] for g in geoms}
ok('Exactly five original failures; all original eight poses, rectangle and R=6 unchanged')
for src,dst in [('freeze.json','old_freeze.json'),('raw/results.json','old_results_all72.json'),('failure_index.json','old_failure_index.json'),('raw/graphs.json','old_graphs_all72.json')]:assert H(OLD/src)==H(ROOT/'input'/dst)
expected=J(ROOT/'evidence/old_inventory_before.json')
actual={str(p.relative_to(OLD)):H(p) for p in sorted(OLD.rglob('*')) if p.is_file()}
assert actual==expected==J(ROOT/'evidence/old_inventory_after.json')
assert len(actual)==54
assert H(OLD/'source/dubins.py')==H(ROOT/'source/dubins.py')
ok('54 original files and copied generator byte hashes unchanged')
for manifest in ('freeze.sha256','source.sha256','postprocessing_source.sha256','SHA256SUMS.txt'):
 for line in (ROOT/manifest).read_text().splitlines():
  h,rel=line.split('  ');assert H(ROOT/rel)==h,(manifest,rel)
rawgrid=[{'grid_id':f'x{ix}_y{iy}_h{ih}','pose':[x,y,ih*math.pi/4]} for ix,x in enumerate([6.,13.,20.,27.,34.]) for iy,y in enumerate([6.,15.,24.]) for ih in range(8)]
excluded=[g for g in rawgrid if g['pose']==[20.,15.,0.]]
assert len(rawgrid)==120 and excluded==cfg['grid']['excluded']==[{'grid_id':'x2_y1_h0','pose':[20.,15.,0.]}]
assert grid==[g for g in rawgrid if g not in excluded] and len(grid)==119
status=J(ROOT/'evidence/run_status.json')
assert status['freeze_sha256']==H(ROOT/'freeze.json')
assert datetime.datetime.fromisoformat(cfg['frozen_utc'])<datetime.datetime.fromisoformat(status['started_utc'])
assert cfg['connections']['max_intermediate_poses_per_original_edge']==1
ok('119-pose deterministic exclusion rule matches freeze; freeze hash checked at run start and timestamp precedes results')
original_bytes=b''.join(l for l in (OLD/'raw/edges.jsonl').read_bytes().splitlines(keepends=True) if json.loads(l)['instance_id'] in ids)
assert original_bytes==(ROOT/'input/original_edges_selected5.jsonl').read_bytes()
orig={}
for line in original_bytes.splitlines():
 r=json.loads(line);key=(r['instance_id'],r['i'],r['j']);assert key not in orig;orig[key]=r
assert len(orig)==280
words={'LSL','LSR','RSL','RSR','LRL','RLR'}
legs={};stats={iid:dict(leg_pairs=0,candidates=0,valid_candidates=0,missing_legs=0,via_pairs_evaluated=0,via_pairs_feasible=0) for iid in ids}
for line in (ROOT/'raw/legs.jsonl').open():
 r=json.loads(line);iid=r['instance_id'];node=r['node'];gi=r['grid_index'];d=r['direction'];key=(iid,node,gi,d)
 assert key not in legs and d in ('in','out') and 0<=node<8 and 0<=gi<119
 assert r['R']==6 and r['grid_id']==grid[gi]['grid_id']
 q0,q1=(poses[iid][node],grid[gi]['pose']) if d=='out' else (grid[gi]['pose'],poses[iid][node])
 assert r['q0']==q0 and r['q1']==q1
 w=[c['word'] for c in r['candidates']]+r['unavailable_words'];assert len(w)==6 and set(w)==words
 valid=[c for c in r['candidates'] if c['feasible']]
 selected=min(valid,key=lambda p:(p['length'],p['word'])) if valid else None
 assert r['cost']==(selected['length'] if selected else None) and r['selected_word']==(selected['word'] if selected else None)
 legs[key]=r
 s=stats[iid];s['leg_pairs']+=1;s['candidates']+=len(r['candidates']);s['valid_candidates']+=len(valid);s['missing_legs']+=selected is None
assert set(legs)==set(itertools.product(ids,range(8),range(119),('out','in')))
ok('All 9520 directed leg records present exactly once; six-word availability and selected-cost records complete')
graphs=J(ROOT/'raw/graphs.json');rows=J(ROOT/'raw/results.json');failures=J(ROOT/'raw/failures.json')
assert [r['instance_id'] for r in rows]==ids and rows==failures
assert [g['instance_id'] for g in graphs]==ids
oldgraphs={g['instance_id']:g for g in J(OLD/'raw/graphs.json')}
geometry_checks=[];summary=[];newedges=[]
# Independent exact integration of constant-curvature segment, not production code.
def at(q,k,s):
 x,y,h=q
 if k==0:return [x+s*math.cos(h),y+s*math.sin(h),h]
 # Midpoint-angle identity integrates heading ODE without production generator.
 amp=2*math.sin(k*s/2)/k
 return [x+amp*math.cos(h+k*s/2),y+amp*math.sin(h+k*s/2),h+k*s]
def check_path(q0,q1,path):
 q=list(q0);extrema=[];total=0.;curv_errors=[]
 assert len(path['word'])==len(path['params'])==3
 for kind,u in zip(path['word'],path['params']):
  assert kind in 'LSR' and math.isfinite(u) and u>=0
  k={'L':1/6,'R':-1/6,'S':0}[kind];length=6*u;times=[0.,length]
  if k:
   lo,hi=sorted((q[2],q[2]+k*length))
   for n in range(math.ceil(lo/(math.pi/2)),math.floor(hi/(math.pi/2))+1):
    s=(n*math.pi/2-q[2])/k
    if 0<=s<=length:times.append(s)
  extrema.extend(at(q,k,s) for s in times)
  if length>1e-8:
   a,b,c=[at(q,k,t*length) for t in (.3,.5,.7)]
   den=math.dist(a[:2],b[:2])*math.dist(b[:2],c[:2])*math.dist(c[:2],a[:2])
   curvature=2*((b[0]-a[0])*(c[1]-b[1])-(b[1]-a[1])*(c[0]-b[0]))/den
   curv_errors.append(abs(curvature-k));assert abs(curvature-k)<2e-7 and abs(curvature)<=1/6+2e-7
  q=at(q,k,length);total+=length
 pe,he=pose_check(q,q1);near(total,path['length'],2e-9)
 bbox=[min(p[0] for p in extrema),max(p[0] for p in extrema),min(p[1] for p in extrema),max(p[1] for p in extrema)]
 for a,b in zip(bbox,path['bbox']):near(a,b)
 margin=min(bbox[0],40-bbox[1],bbox[2],30-bbox[3])
 assert path['feasible']==(margin>=-1e-9)
 near(margin,path['boundary_margin'])
 return q,{'word':path['word'],'length_m':total,'endpoint_position_error_m':pe,'endpoint_heading_error_rad':he,'continuous_bbox':bbox,'minimum_boundary_margin_m':margin,'max_signed_menger_curvature_error':max(curv_errors,default=0.)}
for row,g in zip(rows,graphs):
 iid=row['instance_id'];cost=g['cost'];oc=g['original_cost']
 assert oc==oldgraphs[iid]['cost'];new=[]
 for i in range(8):
  for j in range(8):
   if i==j:assert cost[i][j] is None;continue
   o=orig[iid,i,j];assert oc[i][j]==o['cost'];choices=[]
   if o['cost'] is not None:choices.append((o['cost'],0,-1))
   for gi in range(119):
    a,b=legs[iid,i,gi,'out'],legs[iid,j,gi,'in'];stats[iid]['via_pairs_evaluated']+=1
    if a['cost'] is not None and b['cost'] is not None:
     choices.append((a['cost']+b['cost'],1,gi));stats[iid]['via_pairs_feasible']+=1
   best=min(choices) if choices else None
   assert cost[i][j]==(best[0] if best else None)
   if o['cost'] is not None:assert cost[i][j] is not None and cost[i][j]<=o['cost']
   if best:
    edge=g['selected_edges'][f'{i},{j}'];assert edge['length']==best[0] and edge['original_cost']==o['cost']
    assert edge['type']==('direct' if best[1]==0 else 'via_one_grid_pose')
    assert edge['grid_index']==(None if best[1]==0 else best[2])
   if cost[i][j] is not None and oc[i][j] is None:new.append([i,j]);newedges.append((iid,i,j))
 assert new==row['newly_connected_edges']
 missing_out=[i for i in range(8) if all(c is None for c in cost[i])]
 missing_in=[j for j in range(8) if all(cost[i][j] is None for i in range(8))]
 assert row['outgoing_missing_nodes']==missing_out and row['incoming_missing_nodes']==missing_in
 assert row['original_feasible_edges']==sum(c is not None for r in oc for c in r)
 assert row['expanded_feasible_edges']==sum(c is not None for r in cost for c in r)
 assert row['counts']==stats[iid]
 # Verification only: re-enumerate orders on recorded graphs. No generation or expansion.
 counts=[0,0];orders=0
 for p in itertools.permutations(range(1,8)):
  tour=(0,)+p+(0,);orders+=1
  for k,matrix in enumerate((oc,cost)):
   counts[k]+=all(matrix[a][b] is not None for a,b in zip(tour,tour[1:]))
 assert orders==5040 and counts==[0,0] and row['feasible'] is False and row['tour'] is None and row['length'] is None
 summary.append({'instance_id':iid,'original_edges':row['original_feasible_edges'],'expanded_edges':row['expanded_feasible_edges'],'new_edges':new,'missing_out':missing_out,'missing_in':missing_in,'orders_checked':orders,'original_feasible_orders':counts[0],'expanded_feasible_orders':counts[1]})
assert len(newedges)==10
ok('All 280 original edges preserved; expanded costs reconstructed from recorded legs across 33320 combinations; all five degree failures match')
ok('Independent 5040-order enumeration per case on both original and expanded frozen graphs confirms no full seven-task tour')
for iid,i,j in newedges:
 w=J(ROOT/'edge_witnesses'/f'{iid}_{i}_to_{j}.json');edge=w['edge'];graph=next(g for g in graphs if g['instance_id']==iid)
 assert w['kind']=='partial_node_pair_connection_only' and w['not_a_complete_7_task_tour'] is True
 assert edge==graph['selected_edges'][f'{i},{j}'] and len(edge['components'])==2
 assert w['R']==6 and w['rectangle']==cfg['rectangle']
 gi=edge['grid_index'];a,b=edge['components'];assert a['q0']==poses[iid][i] and b['q1']==poses[iid][j]
 assert a['q1']==b['q0']==grid[gi]['pose']
 for c,key in [(a,(iid,i,gi,'out')),(b,(iid,j,gi,'in'))]:
  raw=legs[key];p=next(p for p in raw['candidates'] if p['word']==raw['selected_word'])
  assert c=={'q0':raw['q0'],'q1':raw['q1'],'path':p}
 end_a,res_a=check_path(a['q0'],a['q1'],a['path'])
 # The second component is integrated from the first actual endpoint, checking direction continuity.
 join_pos,join_h=pose_check(end_a,b['q0'])
 end_b,res_b=check_path(end_a,b['q1'],b['path']);pose_check(end_b,poses[iid][j])
 assert res_a['minimum_boundary_margin_m']>=-1e-9 and res_b['minimum_boundary_margin_m']>=-1e-9
 near(res_a['length_m']+res_b['length_m'],edge['length'],2e-9)
 assert w['original_direct_candidates']==[{k:p[k] for k in ('word','params','length','bbox','boundary_margin','feasible')} for p in orig[iid,i,j]['candidates']]
 direct_margins=[]
 for c in w['original_direct_candidates']:
  _,r=check_path(poses[iid][i],poses[iid][j],c);assert r['minimum_boundary_margin_m']<-1e-9;direct_margins.append(r['minimum_boundary_margin_m'])
 geometry_checks.append({'instance_id':iid,'edge':[i,j],'grid_id':edge['grid_id'],'length_m':edge['length'],'join_position_error_m':join_pos,'join_heading_error_rad':join_h,'legs':[res_a,res_b],'original_direct_candidate_margins_m':direct_margins})
ok('All ten new local connection witnesses independently checked: both full continuous legs, exact extrema, signed curvature, actual-endpoint stitching and headings; all original direct candidates still cross boundary')
assert not list((ROOT/'routes').glob('*.json'))
assert sum(s['leg_pairs'] for s in stats.values())==9520
assert sum(s['candidates'] for s in stats.values())==46742
assert sum(s['via_pairs_evaluated'] for s in stats.values())==33320
assert {k:sum(s[k] for s in stats.values()) for k in stats[ids[0]]}==status['counts']
verification=J(ROOT/'evidence/verification.json')
assert verification['instances_checked']==5 and verification['witnesses_checked']==0
for a,b in zip(summary,verification['all_order_checks']):
 assert a['instance_id']==b['instance_id'] and a['orders_checked']==b['orders_enumerated'] and a['expanded_feasible_orders']==b['expanded_feasible_orders']
delivery=J(ROOT/'DELIVERY.json');zip_path=Path(delivery['zip']);resource_ledger=J(ROOT/'evidence/resource.json')
assert zip_path.stat().st_size==4024822==delivery['zip_bytes']
assert H(zip_path)==delivery['zip_sha256']=='3119f802c0f83bcbd544fd5cb8799729538e87b02a60b16cf74ab3ae666e84a0'
assert H(ROOT/'evidence/resource.json')==delivery['resource_sha256']
near(resource_ledger['total_cpu_seconds'],17.967534,1e-9)
near(resource_ledger['total_cpu_seconds'],delivery['formal_and_postprocessing_cpu_seconds'],1e-9)
with zipfile.ZipFile(zip_path) as z:
 assert z.testzip() is None
 assert ROOT.name+'/evidence/resource.json' not in z.namelist() and ROOT.name+'/DELIVERY.json' not in z.namelist()
 for line in z.read(ROOT.name+'/SHA256SUMS.txt').decode().splitlines():
  h,p=line.split('  ');assert hashlib.sha256(z.read(ROOT.name+'/'+p)).hexdigest()==h
 assert z.read(ROOT.name+'/evidence/resource_pre_archive.json')==(ROOT/'evidence/resource_pre_archive.json').read_bytes()
ok('ZIP size/hash, CRC and every manifest payload hash verified; final 17.967534 CPU-second ledger and DELIVERY are intentionally external')
report={'status':'passed_with_scope_limits','generated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':checks,'cases':summary,'new_connection_geometry_checks':geometry_checks,'freeze_provenance':{'frozen_utc':cfg['frozen_utc'],'formal_run_started_utc':status['started_utc'],'freeze_sha256':H(ROOT/'freeze.json'),'interpretation':'Local artifacts and execution code support pre-run freezing. This is not an independently timestamped preregistration or proof about unrecorded prior activity.'},'claim_limits':['Five cases were selected after original failure; no new population success-rate estimate.','Ten local node-pair witnesses are not complete tours. Zero complete seven-task tours in this frozen finite graph.','Finite-graph failure does not establish continuous-space infeasibility.','No path generator or solver was rerun; full geometry revalidation limited to ten exported connections and their failed original direct candidates; all other leg data checked structurally and algebraically.'],'resource':{'hard_cpu_limit_seconds':6,'audit_cpu_seconds_to_report':time.process_time()-START,'author_final_cpu_seconds':resource_ledger['total_cpu_seconds'],'additional_audit_budget_seconds':10},'zip':{'bytes':zip_path.stat().st_size,'sha256':H(zip_path)}}
(OUT/'audit.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'status':report['status'],'audit_cpu_seconds':time.process_time()-START,'new_connections_independently_geometry_checked':len(geometry_checks),'complete_tours':0,'checks':checks},indent=2,ensure_ascii=False))
