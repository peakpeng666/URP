#!/usr/bin/env python3
"""Independent, bounded audit; reads originals and certificate data, never author code.
No trajectory generation, search, optimization, radius change, or model calls.
"""
from pathlib import Path
from fractions import Fraction as Q
import csv, datetime, hashlib, json, math, resource, time

resource.setrlimit(resource.RLIMIT_CPU, (4, 5))
started = time.process_time()
BASE = Path('/workspace/shared/dubins_boundary_certificates_20261007')
OUT = Path(__file__).resolve().parent

def load(p):
    return json.loads(Path(p).read_text())
def hashfile(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rat(x):
    return Q(x)
def exact_json(x):
    if isinstance(x, Q):
        return str(x)
    raise TypeError(type(x).__name__)
def signed(I, sign):
    return (I[0], I[1]) if sign == 1 else (-I[1], -I[0])
def absolute(I):
    a,b = I
    return (Q(0) if a <= 0 <= b else min(abs(a), abs(b)), max(abs(a), abs(b)))
def trig(x):
    # Independent recurrences. Sine through degree79; cosine through degree80.
    # Lagrange derivative bounds <=1 give rigorous, rational remainders.
    ss = st = x
    cc = ct = Q(1)
    for k in range(1, 40):
        st *= -x*x / ((2*k)*(2*k+1))
        ss += st
    for k in range(1, 41):
        ct *= -x*x / ((2*k-1)*(2*k))
        cc += ct
    es = abs(x)**80 / math.factorial(80)
    ec = abs(x)**81 / math.factorial(81)
    return (max(Q(-1),ss-es),min(Q(1),ss+es)), (max(Q(-1),cc-ec),min(Q(1),cc+ec))
def check_interval(record, key, independent):
    lo,hi = Q(record[key]['lower']),Q(record[key]['upper'])
    assert lo <= independent[0] <= independent[1] <= hi, (record['instance_id'],record['service_pose_index'],record['face'],key)

manifest = load(BASE/'input_manifest.json')
manifest_checks=[]
for entry in manifest:
    paths=[Path(entry['source']), BASE/entry['copy']]
    assert all(hashfile(p)==entry['sha256'] for p in paths), entry
    assert all(p.stat().st_size==entry['bytes'] for p in paths),entry
    manifest_checks.append({'source':entry['source'],'copy':entry['copy'],'sha256':entry['sha256'],'matched':True})
old_inventory=load(BASE/'evidence/original_inventory_before.json')
for entry in old_inventory:
    assert Path(entry['path']).stat().st_size==entry['bytes'],entry
    assert hashfile(entry['path'])==entry['sha256'],entry

cfg=load(BASE/'input/original_freeze.json')
assert cfg['rectangle']==[0.0,40.0,0.0,30.0]
assert cfg['depot_pose']==[20.0,15.0,0.0]
assert cfg['radius_values']==[1.0,3.0,6.0]
assert 'tolerance 1e-9 metres' in cfg['boundary_check']
assert cfg['tasks_per_geometry']==7
idx=load(BASE/'input/original_failure_index.json')
names=idx['both_failures_in_candidate_graph']
assert names==['near_boundary_01_R6','near_boundary_02_R6','near_boundary_03_R6','near_boundary_10_R6','near_boundary_11_R6']
diagnostic=load(BASE/'input/diagnostic_freeze.json')
assert diagnostic['instance_ids']==names
assert diagnostic['R']==6 and diagnostic['rectangle']==cfg['rectangle']
instances=load(BASE/'input/original_instances.json')
selected=[next(g for g in instances if g['geometry_id']==n[:-3]) for n in names]
assert selected==load(BASE/'input/diagnostic_instances_selected5.json')
records=load(BASE/'all_checks.json')
assert len(records)==280
keys=[(r['instance_id'],r['service_pose_index'],r['face'],r['direction']) for r in records]
assert len(set(keys))==280
record_map=dict(zip(keys,records))
faces=[('left',(-1,0),Q(0)),('right',(1,0),Q(40)),('bottom',(0,-1),Q(0)),('top',(0,1),Q(30))]
certs=[]
independent_all=[]
btol=Q(1,10**9); guard=Q(1,10**6); qguard=Q(1,10**12)
for name,inst in zip(names,selected):
    assert len(inst['poses'])==8 and inst['poses'][0]==cfg['depot_pose']
    depot=inst['poses'][0]
    for i,pose in enumerate(inst['poses'][1:],1):
        x,y,theta=map(rat,pose)
        ss,cc=trig(theta)
        for face,(nx,ny),h in faces:
            d=h-nx*x-ny*y
            delta=nx*(Q(depot[0])-x)+ny*(Q(depot[1])-y)
            for direction,sign in [('outgoing_to_depot',1),('incoming_from_depot_reversed',-1)]:
                rec=record_map[(name,i,face,direction)]
                # Dot velocity into unit normal; tangent is the +90 degree rotation.
                q=signed(cc,sign*nx) if nx else signed(ss,sign*ny)
                w=signed(ss,sign*nx) if nx else signed(cc,-sign*ny)
                aw=absolute(w)
                displacement=(6*(1-aw[1]),6*(1-aw[0]))
                raw=(displacement[0]-d,displacement[1]-d)
                margin=(raw[0]-btol-guard,raw[1]-btol-guard)
                eligible=q[0]>qguard and delta < -guard
                assert not (q[0]<=qguard<q[1])
                assert not (margin[0]<=0<margin[1])
                status='certified_model_infeasible' if eligible and margin[0]>0 else 'not_proved_by_this_test'
                assert rec['pose']==pose and rec['depot_pose']==depot
                assert rec['outward_normal']==[nx,ny]
                assert Q(rec['face_h_exact'])==h
                assert rec['R_m']==6 and rec['heading_rad']==pose[2]
                assert Q(rec['clearance_d_m_exact'])==d
                assert rec['clearance_d_m']==float(d)
                assert Q(rec['target_normal_displacement_m_exact'])==delta
                assert rec['target_normal_displacement_m']==float(delta)
                assert rec['target_strictly_inward']==(delta<-guard)
                assert rec['initial_auxiliary_velocity_strictly_outward']==(q[0]>qguard)
                assert Q(rec['boundary_tolerance_m'])==btol
                assert Q(rec['additional_length_guard_m'])==guard
                assert rec['status']==status
                for key,I in [('cos_phi_interval',q),('sin_phi_interval',w),('required_outward_displacement_m_interval',displacement),('raw_deficit_m_interval',raw),('strict_margin_m_interval',margin)]:
                    check_interval(rec,key,I)
                report={'instance_id':name,'service_pose_index':i,'face':face,'direction':direction,'R_m':6,'clearance_d_m':float(d),'independent_displacement_lower_m':float(displacement[0]),'independent_strict_margin_lower_m':float(margin[0]),'initial_outward_projection_lower':float(q[0]),'depot_normal_displacement_m':float(delta),'eligible_outward_and_inward':eligible,'status':status}
                independent_all.append(report)
                if status=='certified_model_infeasible': certs.append(report)

counts={n:sum(c['instance_id']==n for c in certs) for n in names}
assert counts=={'near_boundary_01_R6':1,'near_boundary_02_R6':0,'near_boundary_03_R6':0,'near_boundary_10_R6':2,'near_boundary_11_R6':1}
for n in names:
    case=load(BASE/'certificates'/f'{n}.json')
    expected=[r for r in records if r['instance_id']==n and r['status']=='certified_model_infeasible']
    assert case['certificates']==expected
    assert case['certificate_count']==counts[n]
    assert case['checks']==56 and case['service_poses_checked']==7
    assert case['status']==('certified_model_infeasible' if counts[n] else 'not_proved_by_this_test')
summary=load(BASE/'summary.json')
assert summary['instances_checked']==5 and summary['total_pose_face_direction_checks']==280
assert summary['certificate_count']==4
assert summary['certified_model_infeasible_instances']==[n for n in names if counts[n]]
assert summary['not_proved_instances']==[n for n in names if not counts[n]]
with (BASE/'certificates.csv').open(newline='') as f:
    csvrows=list(csv.DictReader(f))
assert len(csvrows)==4
for row,cert in zip(csvrows,certs):
    assert all(row[k]==str(cert[k]) for k in ['instance_id','face','direction','status'])
    assert int(row['service_pose_index'])==cert['service_pose_index']
    assert float(row['clearance_d_m'])==cert['clearance_d_m']
    assert abs(float(row['strict_margin_m_display'])-cert['independent_strict_margin_lower_m'])<1e-15

snapshot=[]
for p in sorted(BASE.rglob('*')):
    if p.is_file():
        snapshot.append({'path':str(p.relative_to(BASE)),'bytes':p.stat().st_size,'sha256':hashfile(p)})
not_proved_best={n:max((r for r in independent_all if r['instance_id']==n and r['eligible_outward_and_inward']),key=lambda r:r['independent_strict_margin_lower_m']) for n in names if not counts[n]}
report={'status':'PASS','generated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Original fixed forward-only point Dubins ODE model only; not a claim about real robots, reversing vehicles, or vehicles with in-place rotation.','independent_method':'No author code import or execution. Exact Fraction odd/even recurrences (sine degree 79, cosine degree 80) and independent Lagrange remainder bounds. All published 24-decimal intervals independently enclose the tighter recomputation.','author_inputs_compared_with_live_sources':manifest_checks,'original_and_diagnostic_inventory_files_unchanged':len(old_inventory),'all_pose_face_direction_checks_verified':len(records),'certificates':certs,'per_instance_certificate_counts':counts,'not_proved_instances':[n for n in names if not counts[n]],'best_eligible_test_in_each_unproved_case':not_proved_best,'no_graph_infeasibility_used_as_proof':True,'trajectory_searches':0,'new_grids':0,'tour_solves':0,'radius_changes':0,'external_or_paid_model_calls':0,'cpu_limit_seconds':5,'cpu_seconds':time.process_time()-started,'author_artifact_snapshot':snapshot}
(OUT/'independent_checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
(OUT/'independent_all_checks.json').write_text(json.dumps(independent_all,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['author_inputs_compared_with_live_sources','author_artifact_snapshot']},ensure_ascii=False,indent=2))
