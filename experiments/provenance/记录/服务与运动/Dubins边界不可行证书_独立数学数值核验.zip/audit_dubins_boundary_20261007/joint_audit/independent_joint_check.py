#!/usr/bin/env python3
"""Independent appended joint audit only. Does not rerun the single-face audit."""
from pathlib import Path
from fractions import Fraction as Q
import datetime,hashlib,json,math,resource,time
resource.setrlimit(resource.RLIMIT_CPU,(1,2))
t0=time.process_time()
BASE=Path('/workspace/shared/dubins_boundary_certificates_20261007')
JOINT=BASE/'joint'
OUT=Path(__file__).resolve().parent

def load(p): return json.loads(Path(p).read_text())
def digest(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def neg(I,k): return I if k==1 else (-I[1],-I[0])
def trig(x):
    st=ss=x; ct=cc=Q(1)
    for k in range(1,40):
        st *= -x*x/((2*k)*(2*k+1)); ss+=st
    for k in range(1,41):
        ct *= -x*x/((2*k-1)*(2*k)); cc+=ct
    se=abs(x)**80/math.factorial(80); ce=abs(x)**81/math.factorial(81)
    return (max(Q(-1),ss-se),min(Q(1),ss+se)),(max(Q(-1),cc-ce),min(Q(1),cc+ce))
def shift(I,k):
    z=neg(I,k)
    return (6*(1+z[0]),6*(1+z[1]))
def contained(I,published):
    assert Q(published['lower'])<=I[0]<=I[1]<=Q(published['upper'])

deficit_guard=Q(1,10**9)+Q(1,10**6)
projection_guard=Q(1,10**12)
inner_guard=Q(1,10**6)
prior=load(OUT.parent/'independent_checks.json')
# Only source dependencies used by this new checker are compared with the frozen
# previous audit. Historical 125 files and original 280 checks are not rerun.
prior_hashes={r['path']:r['sha256'] for r in prior['author_artifact_snapshot']}
dependencies=['input/diagnostic_instances_selected5.json','input/original_freeze.json','input/original_failure_index.json','input_manifest.json','source/check_boundary.py','summary.json']
for rel in dependencies: assert digest(BASE/rel)==prior_hashes[rel],rel
cfg=load(BASE/'input/original_freeze.json')
instances=load(BASE/'input/diagnostic_instances_selected5.json')
names=load(BASE/'input/original_failure_index.json')['both_failures_in_candidate_graph']
assert cfg['rectangle']==[0.,40.,0.,30.] and cfg['depot_pose']==[20.,15.,0.]
rows=load(JOINT/'all_checks.json')
keys=[(r['instance_id'],r['service_pose_index'],tuple(r['faces']),r['direction']) for r in rows]
assert len(rows)==len(set(keys))==280
lookup=dict(zip(keys,rows))
all_reports=[]; certs=[]
for inst in instances:
    name=inst['geometry_id']+'_R6'
    assert name in names and len(inst['poses'])==8
    assert inst['poses'][0]==cfg['depot_pose']
    for i,pose in enumerate(inst['poses'][1:],1):
        x,y,theta=map(Q,pose)
        ss,cc=trig(theta)
        for fx,sx,hx in [('left',-1,Q(0)),('right',1,Q(40))]:
            for fy,sy,hy in [('bottom',-1,Q(0)),('top',1,Q(30))]:
                dx=hx-sx*x; dy=hy-sy*y
                tx=sx*(20-x); ty=sy*(15-y)
                for direction,sign in [('outgoing_to_depot',1),('incoming_from_depot_reversed',-1)]:
                    a=neg(cc,sx*sign); b=neg(ss,sy*sign)
                    row=lookup[(name,i,(fx,fy),direction)]
                    assert row['pose']==pose and row['depot_pose']==cfg['depot_pose']
                    assert row['R_m']==6 and row['heading_rad']==pose[2]
                    assert row['normals']==[[sx,0],[0,sy]]
                    assert Q(row['clearance_dx_m_exact'])==dx
                    assert Q(row['clearance_dy_m_exact'])==dy
                    assert row['clearance_dx_m_display']==float(dx)
                    assert row['clearance_dy_m_display']==float(dy)
                    assert Q(row['depot_x_displacement_m_exact'])==tx
                    assert Q(row['depot_y_displacement_m_exact'])==ty
                    assert Q(row['boundary_tolerance_m'])==Q(1,10**9)
                    assert Q(row['additional_guard_m'])==inner_guard
                    contained(a,row['a_interval']); contained(b,row['b_interval'])
                    assert not (a[0]<=projection_guard<a[1])
                    assert not (b[0]<=projection_guard<b[1])
                    positive=a[0]>projection_guard and b[0]>projection_guard
                    inward=tx<-inner_guard and ty<-inner_guard
                    assert row['both_initial_components_positive']==positive
                    assert row['depot_strictly_inward_both_faces']==inward
                    branches={}
                    for branch,rx,ry in [('A_first_a_zero',shift(b,-1),shift(a,1)),('B_first_b_zero',shift(b,1),shift(a,-1))]:
                        mx=(rx[0]-dx-deficit_guard,rx[1]-dx-deficit_guard)
                        my=(ry[0]-dy-deficit_guard,ry[1]-dy-deficit_guard)
                        assert not (mx[0]<=0<mx[1])
                        assert not (my[0]<=0<my[1])
                        rr=row['branches'][branch]
                        contained(rx,rr['required_x_displacement_m_interval'])
                        contained(ry,rr['required_y_displacement_m_interval'])
                        contained(mx,rr['x_strict_deficit_m_interval'])
                        contained(my,rr['y_strict_deficit_m_interval'])
                        assert rr['x_strict_deficit_display']==float(mx[0])
                        assert rr['y_strict_deficit_display']==float(my[0])
                        excludes=([fx] if mx[0]>0 else [])+([fy] if my[0]>0 else [])
                        assert rr['excluded_by_faces']==excludes and rr['excluded']==bool(excludes)
                        branches[branch]={'requirement_x_m_approx':float(rx[0]),'requirement_y_m_approx':float(ry[0]),'x_guarded_deficit_m_approx':float(mx[0]),'y_guarded_deficit_m_approx':float(my[0]),'excluded_by_faces':excludes,'excluded':bool(excludes)}
                    certified=positive and inward and all(br['excluded'] for br in branches.values())
                    assert row['status']==('joint_certificate_pending_independent_review' if certified else 'not_proved_by_joint_test')
                    rep={'instance_id':name,'service_pose_index':i,'faces':[fx,fy],'direction':direction,'a_approx':float(a[0]),'b_approx':float(b[0]),'clearance_dx_m_approx':float(dx),'clearance_dy_m_approx':float(dy),'depot_x_displacement_m_approx':float(tx),'depot_y_displacement_m_approx':float(ty),'hypotheses_verified':positive and inward,'branches':branches,'independently_certified':certified}
                    all_reports.append(rep)
                    if certified: certs.append(rep)
counts={n:sum(c['instance_id']==n for c in certs) for n in names}
assert counts=={'near_boundary_01_R6':0,'near_boundary_02_R6':1,'near_boundary_03_R6':2,'near_boundary_10_R6':1,'near_boundary_11_R6':0}
for n in names:
    case=load(JOINT/'certificates'/f'{n}.json')
    assert case['checks']==56 and case['certificate_count']==counts[n]
    assert case['post_hoc'] is True
    assert case['certificates']==[r for r in rows if r['instance_id']==n and r['status']=='joint_certificate_pending_independent_review']
summary=load(JOINT/'summary.json')
assert summary['candidate_certificate_count']==4 and summary['checks']==280
assert summary['post_hoc'] is True
assert summary['joint_candidate_instance_ids']==[n for n in names if counts[n]]
assert summary['newly_covered_beyond_single_face']==['near_boundary_02_R6','near_boundary_03_R6']
assert summary['still_unproved_after_both_tests']==[]
assert summary['shared_exact_arithmetic_source_sha256']==prior_hashes['source/check_boundary.py']
assert summary['input_manifest_sha256']==prior_hashes['input_manifest.json']
result={'status':'PASS','generated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'joint_necessary_condition_mathematically_valid':True,'arithmetic':'Independent exact Fraction sin degree79 and cos degree80 recurrences with Lagrange enclosures; no author code execution/import. Display numbers are approximate only.','scope':'Fixed forward-only point Dubins ODE, absolutely continuous heading, R=6, original fixed service poses and depot, rectangle; no real-robot or reversing/in-place-turning infeasibility claim.','post_hoc':True,'joint_checks_verified':280,'joint_certificate_count':len(certs),'per_instance_joint_counts':counts,'newly_certified_instance_ids':['near_boundary_02_R6','near_boundary_03_R6'],'combined_certified_instance_ids':names,'still_unproved_among_original_five':[],'certificates':certs,'prior_dependency_hashes_unchanged':dependencies,'single_face_checks_rerun':0,'historic_125_inventory_rerun':False,'new_searches':0,'new_grids':0,'new_tour_solves':0,'numeric_cpu_seconds':time.process_time()-t0,'numeric_cpu_hard_limit_seconds':2,'joint_snapshot':[{'path':str(p.relative_to(JOINT)),'sha256':digest(p),'bytes':p.stat().st_size} for p in sorted(JOINT.rglob('*')) if p.is_file()]}
(OUT/'independent_joint_checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
(OUT/'independent_joint_all_checks.json').write_text(json.dumps(all_reports,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='joint_snapshot'},ensure_ascii=False,indent=2))
