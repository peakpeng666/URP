# Research Console 后端

新增、独立的本地科研记录模块，基于本轮上传的 `bpp-research-console-delivery.zip`，来源身份见 [config/sources.json](config/sources.json)。没有替换仓库原有 `src/urp_research/` CLI。这是后端工程交付；本 PR 不包含前端，尚未覆盖浏览器视觉验收。

Python 3.10+ 标准库与 SQLite，无第三方依赖。支持记录导入、不可变版本、状态查询、同口径比较和原字节附件下载，不执行模型请求或求解实验。

## 用户存档百客户与配置组合格式

已显式接入 `vrptw-archived-solomon-v1`（112条）和 `vrptw-solver-portfolio-v1`（224条），读取接口沿用run/vehicle/逐站时间表。新336记录中329合法、7无方案超时；两包共56输入、仅4坐标geometry groups。官方字节身份未证实，固定K距离单目标，不计算官方BKS gap。原336运行/48输入完整字段不回归；四包可并存，共672运行、104逻辑输入。见[输入获取、导入命令与明确语义](docs/PUBLIC_ROUTE_API.md)。不运行solver，也不改变前端。

## 成熟求解器格式与共同问题比较

已增加显式 `vrptw-mature-solver-v1` 适配，新旧档案可保持独立身份并存，共336条运行、48个逻辑输入。66返回方案重新回放核对，30未返回结果保留no_solution；按算法/预算做共同连续问题下的只读描述性比较。见 [成熟格式契约与测试](docs/MATURE_ROUTE_API.md)。仍未修改前端；只接受明确支持的归档格式。

## 新增路线读取扩展

VRPTW 的任务点、run、单车路线和逐站时间表现可从原始档案导入后读取。新接口仅 GET，旧导入/比较接口兼容；未改 UI，也不是求解服务。见 [路线契约、状态与复现](docs/ROUTE_API.md)。完整原始实验仍在私有 Drive，源码只带小型合成 fixture。

```sh
python3 -m unittest discover -s tests -p 'test_*.py' -v
python3 -m backend import-vrptw /path/to/vrptw_archive
```

## 无需数据的验证

以下命令从仓库根目录开始。测试使用临时目录和明确标注的合成 fixture；不会把 fixture 当真实研究结果。

```sh
cd research_console
python3 -m unittest discover -s tests -p test_backend.py -v
```

9 项测试覆盖幂等导入、版本历史、未知值与状态、比较口径、附件不可变性、路径/凭据拒绝及真实 loopback HTTP。无需下载数据、联网或安装依赖。集成测试故意使用不同文件名，不会被上述命令自动运行。

## 真实数据和复现

真实资料及完整实验记录留在原私有 Google Drive；不随 Git 提交。两个固定归档都包含 `bpp-research-console/packages/`，内有 selector、budget、fleet、turns、bpp-history 五包：

- [后端核心包](https://drive.google.com/file/d/1NbcekvX809gAW5fRb_8Y1ymDaaFnwilv/view)：302949 字节，足够执行本后端集成验证。SHA-256：`9fcff5d1dc990fe4242181daba4fcd323ed565d149b2d0772e90d8df1518b96d`
- [完整工程交接包](https://drive.google.com/file/d/1GMJyq8rjLsB6hlKCjruw9EHKvKeZUBgy/view)：26065013 字节，另保留原始 BPP 输入等。SHA-256：`8f606f8886119c40e5018bd1fd017f44c8d3ee0c12235409f08c8b41caeb27d3`

用已有权限下载其中一包，先对照上面 SHA-256 校验，再解压到仓库外的新目录。以下 `PACKAGE_ROOT` 换成解压后实际绝对路径；不要把整个包复制进 Git 仓库。

```sh
# 在 research_console/ 下执行；例如先验证下载文件：
sha256sum /path/to/research-backend-core-20261007.zip
export PACKAGE_ROOT=/path/to/extracted/bpp-research-console/packages
RESEARCH_CONSOLE_PACKAGE_ROOT="$PACKAGE_ROOT" python3 -m unittest discover -s tests -p integration_backend.py -v
python3 -m backend.smoke --package-root "$PACKAGE_ROOT" --db backend_data/smoke.sqlite3 --report artifacts/smoke.json
python3 -m backend bootstrap --package-root "$PACKAGE_ROOT"
python3 -m backend list
python3 -m backend serve --import-root "$PACKAGE_ROOT" --port 4180
```

集成测试缺少任何真实包都会明确失败，不生成替代数据。HTTP smoke 导入五包、校验幂等性、下载并校验全部 28 个原附件，验证同口径差值和跨预算拒绝后停止服务。最后一条命令持续监听本机 `127.0.0.1:4180`，Ctrl-C 退出。`--db` 是 CLI 全局选项，指定时放在子命令之前，例如 `python3 -m backend --db backend_data/custom.sqlite3 list`。

新增记录目录放 `experiment.json` 和其引用的相对路径附件，再执行 `python3 -m backend import /path/to/package`。实际描述格式可看下载包中的 `packages/selector/experiment.json`；独立合成格式示例见 `tests/test_backend.py` 的 `fixture()`。`backend.adapters` 可从完整面板的已有快照重建五包，输出必须在源面板目录之外；这不是运行原实验。

## API 与语义

- GET `/api/health`、`/api/experiments`
- GET `/api/experiments/{id}?revision=1`；省略 revision 为最新
- POST `/api/import`，JSON `{"package":"selector"}`，目录必须在指定 import root 下
- POST `/api/compare`，JSON `{"items":[{"experiment_id":"selector","metric_id":"family_holdout-5-delta_vs_subset_sbs"},{"experiment_id":"selector","metric_id":"family_holdout-40-delta_vs_subset_sbs"}]}`
- GET `/api/experiments/{id}/artifacts/{artifact_id}`；支持 revision，响应头 `X-Content-SHA256` 是附件校验值

POST 只接受 `application/json`。比较要求 metric、unit、direction、cohort、protocol、budget、aggregation、reference 全部一致；未知值或未完成实验不进入完整结果比较。差值是描述性结果，不代表显著性结论。导入者负责正确声明口径，后端不会自动认证科学有效性。

计数保留单位和 scope，fit、decision、trajectory、checkpoint、historical run 不直接相加。未知值为 null，0 代表有来源的真零；导入时间不是运行结束时间。恢复过的阶段性失败保留在 failures，最终完成状态不被误写为从未发生故障。

## 数据边界与迁移

不提交原始 ZIP、真实研究包、数据库、日志、node_modules 或凭据。不增加 workflow、服务部署、身份系统或公开入口。服务仅用于可信本机环境，尚未验证多用户/公网部署；路径和常见凭据拒绝不是通用秘密识别器。

核心 `store.py`、`adapters.py`、`__init__.py` 与固定交接包保持原字节一致；本次仅在 `server.py`、`__main__.py` 增加路线读取/导入分支；`smoke.py` 仅增加外部 package root 参数。原 10 项测试拆为 9 项独立测试及 1 项显式真实包集成测试。原有全项目审计和历史实验没有在本 PR 中重跑。

新环境可从源码及 Drive 包重建数据库。如需迁移后来导入的全部版本历史，先停止服务，再备份 `backend_data/research.sqlite3`。只使用本目录源码入口；尚未验证 PyPI/wheel、Windows、UI 或完整历史实验重放。
