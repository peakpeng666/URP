"""Read-only independent evidence audit. Never imports or runs the solver.

Recomputes route validity/costs, checkpoint extraction, grouping and ledgers.
It does not repeat optimization or the author's toy solver executions.
Run only with supervise_audit.py, which enforces 20 CPU / 40 wall seconds.
"""
import ast
import collections
import csv
import datetime
import difflib
import hashlib
import html
import itertools
import json
import math
import random
import re
import statistics
import sys
import time
import zipfile
from pathlib import Path

ROOT = Path('/workspace/shared/official_cvrp_controls_20261008')
DATA = Path('/workspace/shared/official_cvrp_benchmarks_20261008')
OUT = Path(__file__).resolve().parent
NAMES = ['A-n32-k5', 'B-n31-k5', 'P-n40-k5']
REFS = dict(zip(NAMES, [784, 672, 458]))
failures = []
checks = 0
evidence = {}
t0 = time.process_time()
w0 = time.perf_counter()

def read(p):
    return json.loads(p.read_text())

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def ck(ok, label):
    global checks
    checks += 1
    if not ok:
        failures.append(label)

def close(a, b):
    return math.isclose(a, b, abs_tol=1e-10, rel_tol=1e-12)

def integer_edge(a, b):
    # Integer-only independent expression for floor(sqrt(s) + 0.5).
    # s is integral, so sqrt(s) cannot be a half integer.
    s = sum((x-y)**2 for x, y in zip(a, b))
    return (math.isqrt(4*s) + 1) // 2

def inspect_solution(raw, sol, k=None):
    if not isinstance(sol, dict) or not isinstance(sol.get('routes'), list):
        return {'valid': False, 'errors': ['malformed_output'], 'cost': None}
    errors = []
    routes = sol['routes']
    n = len(raw['demands'])-1
    if len(routes) > (raw['K'] if k is None else k):
        errors.append('vehicle_upper_bound_exceeded')
    seen = []
    loads = []
    route_costs = []
    for route in routes:
        if not isinstance(route, list) or len(route)<3 or any(type(j) is not int or not 0<=j<=n for j in route):
            errors.append('invalid_route_shape_or_id')
            continue
        if route[0] != 0 or route[-1] != 0 or 0 in route[1:-1]:
            errors.append('invalid_depot')
        seen.extend(route[1:-1])
        load = sum(raw['demands'][j] for j in route[1:-1])
        loads.append(load)
        if load > raw['capacity']:
            errors.append('capacity_exceeded')
        route_costs.append(sum(integer_edge(raw['coordinates'][a],raw['coordinates'][b]) for a,b in zip(route,route[1:])))
    counter = collections.Counter(seen)
    if set(range(1,n+1))-set(counter):
        errors.append('missing_customers')
    if any(v!=1 for v in counter.values()):
        errors.append('duplicate_customers')
    cost = sum(route_costs)
    claimed = sol.get('reported_cost',sol.get('cost'))
    if type(claimed) not in (int,float) or not math.isfinite(claimed) or cost != claimed:
        errors.append('reported_cost_mismatch')
    return dict(valid=not errors, errors=errors, cost=cost, route_costs=route_costs, loads=loads)

def parse_vrp(path):
    headers = {}
    sections = collections.defaultdict(list)
    section = None
    for line in path.read_text().splitlines():
        line = line.strip()
        if line in ('NODE_COORD_SECTION','DEMAND_SECTION','DEPOT_SECTION'):
            section = line
        elif not line or line == 'EOF':
            continue
        elif section:
            sections[section].append([int(x) for x in line.split()])
        else:
            a,b = line.split(':',1)
            headers[a.strip()] = b.strip()
    xy = {r[0]:r[1:] for r in sections['NODE_COORD_SECTION']}
    ds = {r[0]:r[1] for r in sections['DEMAND_SECTION']}
    dim = int(headers['DIMENSION'])
    ck(sorted(xy)==list(range(1,dim+1)) and sorted(ds)==list(range(1,dim+1)), 'contiguous original node IDs '+path.name)
    ck(sections['DEPOT_SECTION']==[[1],[-1]], 'original depot ID '+path.name)
    ck(headers['TYPE']=='CVRP' and headers['EDGE_WEIGHT_TYPE']=='EUC_2D', 'VRP type '+path.name)
    return dict(instance_id=headers['NAME'],coordinates=[xy[i] for i in range(1,dim+1)],demands=[ds[i] for i in range(1,dim+1)],capacity=int(headers['CAPACITY']),K=5)

before = {str(p.relative_to(ROOT)):sha(p) for p in ROOT.rglob('*') if p.is_file()}
manifest = read(ROOT/'MANIFEST.json')
for entry in manifest['files']:
    p = ROOT/entry['path']
    ck(sha(p)==entry['sha256'] and p.stat().st_size==entry['bytes'], 'package manifest '+entry['path'])
for line in (ROOT/'SHA256SUMS.txt').read_text().splitlines():
    digest, rel = line.split('  ',1)
    ck(sha(ROOT/rel)==digest, 'SHA256SUMS '+rel)
archive_digest, archive_name = (ROOT/'archive.sha256').read_text().strip().split('  ',1)
ck(sha(ROOT/archive_name)==archive_digest,'ZIP checksum')
with zipfile.ZipFile(ROOT/archive_name) as z:
    ck(z.testzip() is None,'ZIP CRC')
    expected = {e['path'] for e in manifest['files']}|{'MANIFEST.json','SHA256SUMS.txt'}
    ck(set(z.namelist())==expected and len(z.namelist())==len(expected),'ZIP member inventory')
    for name in z.namelist():
        ck(z.read(name)==(ROOT/name).read_bytes(),'ZIP identical '+name)
for entry in read(DATA/'FILE_INVENTORY.json'):
    p = DATA/entry['path']
    ck(sha(p)==entry['sha256'] and p.stat().st_size==entry['size_bytes'],'official package inventory '+entry['path'])
for leaf in ['PRE_TOY_FREEZE.json','PRE_RUN_FREEZE.json']:
    for rel,digest in read(ROOT/'freeze'/leaf)['sha256'].items():
        ck(sha(ROOT/rel)==digest,'pre-freeze '+leaf+' '+rel)
for entry in read(ROOT/'freeze/SOURCE_PROVENANCE.json'):
    ck(sha(ROOT/entry['path'])==sha(Path(entry['origin']))==entry['sha256'],'source origin '+entry['path'])
old = (ROOT/'provenance/capacity_solver.py').read_text()
new = (ROOT/'source/official_solver.py').read_text()
expected = old.replace('from experiment import Budget, StopBudget, matrix_for, cost_of, savings, derived_seed, destroy, output_for', 'from experiment import Budget, StopBudget, cost_of, savings, derived_seed, destroy, output_for\nfrom integer_distance import matrix_for').replace('from audit import check','from integer_audit import check')
ck(new==expected,'only integer matrix and checker imports changed')
diff = ''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='capacity_solver.py',tofile='official_solver.py'))
ck(diff==(ROOT/'provenance/INTEGER_ADAPTER_DIFF.patch').read_text(),'recorded integer diff matches')
oldfixed = (ROOT/'provenance/fixed_solver.py').read_text()
prior_diff = (ROOT/'provenance/DFS_MINIMAL_CORE_DIFF.patch').read_text()
ck(prior_diff==''.join(difflib.unified_diff(oldfixed.splitlines(True),old.splitlines(True),fromfile='fixed_solver.py (unchanged predecessor)',tofile='capacity_solver.py (new algorithm)')),'recorded DFS diff matches')
for name in ['OFFICIAL_DATA_MANIFEST.json','OFFICIAL_DATA_README.zh.md','OFFICIAL_DATA_FILE_INVENTORY.json']:
    target = {'OFFICIAL_DATA_MANIFEST.json':'manifest.json','OFFICIAL_DATA_README.zh.md':'README.zh.md','OFFICIAL_DATA_FILE_INVENTORY.json':'FILE_INVENTORY.json'}[name]
    ck(sha(ROOT/'provenance'/name)==sha(DATA/target),'official metadata unchanged '+name)
for folder,target in [('sources','official_sources'),('audit','official_data_audit')]:
    for p in (DATA/folder).rglob('*'):
        if p.is_file():
            ck(sha(p)==sha(ROOT/'provenance'/target/p.relative_to(DATA/folder)),'official supporting file '+p.name)
evidence['integrity'] = dict(manifest_files=len(manifest['files']),zip_sha256=archive_digest,all_source_freezes_verified=True,source_delta='Exactly two objective dependency changes; no search body change.')

raws = {}
matrices = {}
instance_evidence = []
official_rows = read(DATA/'audit/source_table_rows.json')
for name in NAMES:
    raw = parse_vrp(ROOT/'provenance'/f'{name}.vrp')
    inp = read(ROOT/'input'/f'{name}.json')
    clean = read(DATA/'clean'/f'{name}.instance.json')
    ck(raw==inp and set(inp)=={'instance_id','coordinates','demands','capacity','K'},'five-field ID-preserving input '+name)
    ck(sha(ROOT/'provenance'/f'{name}.vrp')==sha(DATA/'raw'/f'{name}.vrp'),'original .vrp bytes '+name)
    ck(raw['coordinates']==clean['coordinates'] and raw['demands']==clean['demands'],'official clean data '+name)
    n = len(raw['demands'])
    m = [[integer_edge(a,b) for b in raw['coordinates']] for a in raw['coordinates']]
    ck(m==read(ROOT/'input'/f'{name}.matrix.json')==clean['distance_matrix'],'every EUC_2D matrix edge '+name)
    ck(all(m[i][j]==math.floor(math.hypot(raw['coordinates'][i][0]-raw['coordinates'][j][0],raw['coordinates'][i][1]-raw['coordinates'][j][1])+0.5) for i,j in itertools.product(range(n),repeat=2)),'independent floating nint crosscheck '+name)
    dup = [[i,j] for i in range(n) for j in range(i+1,n) if raw['coordinates'][i]==raw['coordinates'][j]]
    zero = [[i,j] for i in range(n) for j in range(i+1,n) if m[i][j]==0]
    neg = sum(m[i][k]+m[k][j]<m[i][j] for i,j,k in itertools.product(range(n),repeat=3))
    ck(neg>0,'nonmetric integer matrix '+name)
    if name=='B-n31-k5':
        ck(dup==[[7,30],[13,17]] and n==31,'B co-located distinct IDs')
    solpath = ROOT/'reference'/f'{name}.sol'
    ck(sha(solpath)==sha(DATA/'raw'/solpath.name),'original .sol bytes '+name)
    routes=[];claimed=None
    for line in solpath.read_text().splitlines():
        if line.startswith('Route #'):
            routes.append([0]+[int(x) for x in line.split(':',1)[1].split()]+[0])
        elif line.startswith('Cost'):
            claimed=int(line.split()[1])
    ref = inspect_solution(raw,dict(routes=routes,reported_cost=claimed))
    refjson = read(ROOT/'reference'/f'{name}.reference_solution.json')
    ck(ref['valid'] and ref['cost']==REFS[name] and claimed==REFS[name],'official reference feasibility and exact cost '+name)
    ck([r[1:-1] for r in routes]==refjson['routes'] and ref['loads']==refjson['route_loads'] and ref['route_costs']==refjson['route_costs'],'reference JSON mapping '+name)
    row = next(r for r in official_rows if r['instance']==name)
    htmlrow=(ROOT/'provenance/official_sources'/f'{name}.official_table_row.html').read_text()
    cells=re.findall(r'<td\b[^>]*>(.*?)</td>',htmlrow,re.S)
    texts=[' '.join(html.unescape(re.sub('<[^>]*>',' ',s)).split()).replace('$','') for s in cells]
    ck(texts[:6]==[name,str(n-1),'5',str(raw['capacity']),f'{REFS[name]:.2f}','yes'],'saved official table HTML '+name)
    ck(row['UB']==REFS[name] and row['Opt']=='yes' and row['reported_K']==5,'official row metadata '+name)
    instance_evidence.append(dict(instance_id=name,customers=n-1,capacity=raw['capacity'],K_local_upper_bound=5,reference_cost=REFS[name],reference_check=ref,duplicate_normalized_customer_ID_pairs=dup,off_diagonal_zero_pairs=zero,ordered_triangle_violations=neg,unordered_endpoint_triangle_violations=neg//2,official_source=row['source_url'],instance_url=row['instance_url'],solution_url=row['solution_url'],optimality='Opt=yes attributed to saved official page, not independently proven.'))
    raws[name]=raw;matrices[name]=m
evidence['instances']=instance_evidence

cfg=read(ROOT/'freeze/PROTOCOL.json')
schedule=read(ROOT/'freeze/SCHEDULE.json')
records=[json.loads(s) for s in (ROOT/'raw/heuristics.jsonl').read_text().splitlines()]
checkpoints=read(ROOT/'reports/CHECKPOINT_RESULTS.json')
summary=read(ROOT/'reports/SUMMARY.json')
expected_schedule=[dict(instance_id=n,method=m,search_seed=s) for n in NAMES for m in ['cheapest','regret2'] for s in cfg['search_seeds']]
random.Random(cfg['schedule_seed']).shuffle(expected_schedule)
ck(schedule==expected_schedule and len(schedule)==24 and len(records)==24,'frozen complete randomized schedule')
ck(cfg['delta_limit']==160000 and cfg['checkpoints']==[40000,160000] and cfg['K_upper_bound']==5,'frozen protocol limits')
ck(len(set(cfg['search_seeds']))==4,'four distinct seeds')
for prior in ['fixed_fleet_cvrp_20261008','capacity_partition_fallback_20261008']:
    ck(not set(cfg['search_seeds']) & set(read(ROOT.parent/prior/'freeze/PROTOCOL.json')['search_seeds']),'limited seed novelty '+prior)
recalculated=[]
trace_count=0;solution_count=0;candidate_count=0
ledger=collections.Counter()
trace_details=[]
for ix,(record,spec) in enumerate(zip(records,schedule)):
    key='/'.join(str(spec[k]) for k in ['instance_id','method','search_seed'])
    ck(all(record[k]==v for k,v in spec.items()) and record['schedule_index']==ix,'schedule identity '+key)
    raw=raws[record['instance_id']];n=len(raw['demands'])-1
    ck(record['input_sha256']==sha(ROOT/'input'/f"{record['instance_id']}.json"),'run input hash '+key)
    ck(record['status']=='LEGAL_COMPLETION' and record['error'] is None and record['stop_reason']=='delta_budget','legal completion '+key)
    ck(record['deltas']==160000 and sum(record['delta_by_kind'].values())==160000,'delta total '+key)
    ck(record['delta_by_kind']['savings']==n*(n-1)//2 and record['delta_by_kind']['removal']==0,'savings/random removal ledger '+key)
    ck(record['matrix_distances']==(n+1)**2,'matrix ledger '+key)
    init=record['initialization']
    ck(init['deltas_after_initialization']==init['deltas_after_savings']==n*(n-1)//2,'initialization delta ledger '+key)
    ck(not init['fallback_triggered'] and not init.get('capacity_partition') and init['savings_route_count']==5,'no official FFD/DFS triggered '+key)
    prev=record['baseline']
    ck(inspect_solution(raw,prev)['valid'],'baseline legality '+key);solution_count+=1
    ck(prev['routes']==[[0]+r+[0] for r in init['savings_routes']],'baseline equals recorded savings output '+key)
    lastdelta=init['deltas_after_initialization']
    objedges=sum(len(r)-1 for r in prev['routes'])
    accepted=completed=failed=0
    for j,e in enumerate(record['trace']):
        trace_count+=1
        ck(e['iteration']==j and lastdelta<=e['deltas']<=160000,'trace index/deltas '+key+f'/{j}')
        lastdelta=e['deltas']
        def derived(kind):
            return int.from_bytes(hashlib.sha256(f"{record['search_seed']}/{kind}/{j}".encode()).digest()[:8],'big')
        expected_q=random.Random(derived('q')).randint(max(2,math.ceil(.1*n)),max(2,math.ceil(.3*n)))
        expected_removed=random.Random(derived('removal')).sample(list(range(1,n+1)),expected_q)
        ck(e['q']==expected_q and e['removed']==expected_removed,'q/removal seed derivation '+key+f'/{j}')
        if e['candidate_status']=='complete':
            candidate_count+=1;completed+=1
            c=inspect_solution(raw,e['candidate']);solution_count+=1
            ck(c['valid'],'candidate legality/integer cost '+key+f'/{j}')
            want=c['cost']<prev['reported_cost']
            ck(e['accepted']==want,'strict-improvement decision '+key+f'/{j}')
            if want:
                prev=e['candidate'];accepted+=1
            objedges+=sum(len(r)-1 for r in e['candidate']['routes'])
        else:
            ck(e['candidate'] is None and not e['accepted'],'atomic failed candidate discard '+key+f'/{j}')
            failed+=e['candidate_status']=='repair_failed'
        ck(e['incumbent']==prev,'incumbent transition '+key+f'/{j}')
        ck(inspect_solution(raw,e['incumbent'])['valid'],'incumbent legality/integer cost '+key+f'/{j}');solution_count+=1
    ck(record['iterations_started']==len(record['trace']) and record['iterations_completed']==completed and record['accepted_improvements']==accepted and record['repair_failures']==failed,'iteration counters '+key)
    ck(record['output']==prev and inspect_solution(raw,record['output'])['valid'],'final output equals committed incumbent '+key);solution_count+=1
    ck(objedges==record['objective_edges'],'independent objective-edge ledger '+key)
    ck(record['trace'][-1]['candidate_status']=='budget_discarded' and record['trace'][-1]['deltas']==160000,'exact final atomic budget exhaustion '+key)
    ck(record['solver_cpu_seconds']<=3.0 and record['solver_wall_seconds']<=10.0,'per-run resources '+key)
    ledger.update(dict(deltas=record['deltas'],savings=record['delta_by_kind']['savings'],removal=record['delta_by_kind']['removal'],insertion=record['delta_by_kind']['insertion'],matrix=record['matrix_distances'],objective=objedges))
    for cut in [40000,160000]:
        out=record['baseline'];last=init['deltas_after_initialization']
        for e in record['trace']:
            if e['deltas']<=cut:
                out=e['incumbent'];last=e['deltas']
        r=next(r for r in checkpoints if all(r[k]==spec[k] for k in spec) and r['checkpoint']==cut)
        val=inspect_solution(raw,out);solution_count+=1
        cost=val['cost'];ref=REFS[record['instance_id']]
        ck(val['valid'] and r['output']==out and r['cost']==cost and r['last_atomic_record_deltas']==last,'checkpoint output '+key+f'/{cut}')
        ck(r['legal'] and r['reached_cut'] and r['official_reference']==ref and close(r['gap_percent'],100*(cost-ref)/ref) and r['official_value_hit']==(cost==ref),'checkpoint scoring '+key+f'/{cut}')
        ck(r['check']['cost']==cost and r['check']['route_costs']==val['route_costs'] and r['check']['loads']==val['loads'],'checkpoint detailed check '+key+f'/{cut}')
        recalculated.append(dict(**spec,checkpoint=cut,cost=cost,gap_percent=100*(cost-ref)/ref,last_atomic_record_deltas=last))
    trace_details.append(dict(**spec,trace_entries=len(record['trace']),complete_candidates=completed,accepted_improvements=accepted,deltas=record['deltas'],objective_edges=objedges))
ck(len(checkpoints)==48,'48 checkpoint full denominator')
grouped=[]
for name,cut,method in itertools.product(NAMES,[40000,160000],['cheapest','regret2']):
    g=[r for r in recalculated if (r['instance_id'],r['checkpoint'],r['method'])==(name,cut,method)]
    costs=[r['cost'] for r in g];gaps=[r['gap_percent'] for r in g]
    row=next(r for r in summary['per_instance_method'] if (r['instance_id'],r['checkpoint'],r['method'])==(name,cut,method))
    ck(len(g)==4 and {r['search_seed'] for r in g}==set(cfg['search_seeds']),'seed-group full denominator '+name+method+str(cut))
    for k,v in dict(planned_seeds=4,observed_rows=4,legal_outputs=4,reached_cut=4,INIT_FAIL=0,CONSTRUCTION_FAIL=0,NOT_RUN=0,other_failure=0,official_reference=REFS[name],cost_mean=statistics.mean(costs),cost_min=min(costs),cost_worst=max(costs),gap_mean_percent=statistics.mean(gaps),gap_min_percent=min(gaps),gap_worst_percent=max(gaps),official_value_hits=0).items():
        ck(close(row[k],v),'group aggregate '+name+'/'+method+'/'+str(cut)+'/'+k)
    ck(row['seed_costs']=={str(r['search_seed']):r['cost'] for r in g},'seed-level costs '+name+method+str(cut))
    grouped.append(dict(instance_id=name,method=method,checkpoint=cut,seed_costs={str(r['search_seed']):r['cost'] for r in g},cost_mean=statistics.mean(costs),cost_min=min(costs),cost_worst=max(costs),gap_mean_percent=statistics.mean(gaps),reference=REFS[name],reference_hits=sum(c==REFS[name] for c in costs)))
csvrows=list(csv.DictReader((ROOT/'reports/PER_INSTANCE_METHOD.csv').open()))
ck(len(csvrows)==12,'12 CSV instance/method/checkpoint groups')
for row in csvrows:
    js=next(r for r in summary['per_instance_method'] if r['instance_id']==row['instance_id'] and r['method']==row['method'] and r['checkpoint']==int(row['checkpoint']))
    ck(all(str(js[k])==v or (type(js[k]) in (int,float) and close(float(v),js[k])) for k,v in row.items()),'CSV equals detailed JSON '+row['instance_id']+row['method']+row['checkpoint'])
for name in NAMES:
    ck(len({json.dumps(r['baseline'],sort_keys=True) for r in records if r['instance_id']==name})==1,'identical paired baseline '+name)
ck(all(r['cost']>REFS[r['instance_id']] for r in recalculated),'zero reference hits/below-reference anomalies')
ck(read(ROOT/'reports/BELOW_REFERENCE_ANOMALIES.json')==[],'empty anomaly report')
for k,v in dict(unique_benchmark_instances=3,planned_trajectories=24,observed_trajectories=24,legal_trajectories=24,planned_checkpoint_rows=48,observed_checkpoint_rows=48,legal_checkpoint_rows=48,checkpoint_rows_reached=48,below_reference_anomaly_count=0).items():
    ck(summary[k]==v,'overall denominator '+k)
resources=read(ROOT/'reports/RESOURCE_ACCOUNTING.json')
ck(dict(ledger)==dict(deltas=3840000,savings=13128,removal=0,insertion=3826872,matrix=28680,objective=214879),'aggregate operation ledger')
ck(resources['counted_deltas']==ledger['deltas'] and resources['matrix_pair_evaluations']==ledger['matrix'] and resources['objective_edge_evaluations']==ledger['objective'],'reported operation ledger')
ck(resources['dfs_entered_nodes_total']==0,'no official DFS nodes')
evidence['trajectories']=dict(count=24,trace_entries=trace_count,complete_candidates=candidate_count,solution_occurrences_independently_checked=solution_count,checkpoints=48,ledger=dict(ledger),details=trace_details)
evidence['groups']=grouped

toys=read(ROOT/'reports/TOY_VALIDATION.json')
ck(toys['passed'] is True and len(toys['tests'])==17 and len(set(toys['tests']))==17,'17 unique toy assertion outcomes recorded')
ck(read(ROOT/'freeze/PRE_RUN_FREEZE.json')['passed_toys']==17,'17 frozen toy outcomes')
fixtures={
    'NONMETRIC_DUPLICATES':dict(coordinates=[[0,0],[1,1],[2,2],[1,1]],demands=[0,1,1,1],capacity=4,K=5),
    'FIVE_VEHICLES':dict(coordinates=[[0,0],[1,0],[2,0],[3,0],[4,0],[5,0]],demands=[0,10,10,10,10,10],capacity=10,K=5),
    'DFS_RESCUE':dict(coordinates=[[0,0]]*10,demands=[0,4,4,4,3,3,3,2,2,2],capacity=9,K=3),
    'TRUE_CAPACITY_IMPOSSIBLE':dict(coordinates=[[0,0]]*5,demands=[0,5,5,5,5],capacity=9,K=3)}
toy_solution_count=0
for i,r in enumerate(toys['records']):
    if r.get('instance_id') in fixtures:
        fixture=fixtures[r['instance_id']]
        outputs=[r.get('baseline'),r.get('output')]
        for e in r['trace']:
            outputs.extend([e.get('candidate'),e.get('incumbent')])
        for o in outputs:
            if o is not None:
                ck(inspect_solution(fixture,o)['valid'],'retained toy output '+str(i));toy_solution_count+=1
        if r['instance_id']=='FIVE_VEHICLES':
            ck(len(r['output']['routes'])==5 and not inspect_solution(fixture,r['output'],4)['valid'],'toy genuine K5')
        if r['instance_id']=='DFS_RESCUE' and r['output'] is not None:
            cp=r['initialization']['capacity_partition']
            groups=cp['groups']
            ck(sorted(j for g in groups for j in g)==list(range(1,10)) and len(groups)<=3 and all(sum(fixture['demands'][j] for j in g)<=9 for g in groups),'toy DFS retained witness')
            ck(cp['nodes']<=256 and cp['outcome']=='FOUND' and cp['route_insertion_deltas']==sum(len(g)*(len(g)+1)//2 for g in groups)==18 and r['deltas']==54,'toy DFS recorded node/independent fixed-group insertion ledger')
        if r['instance_id']=='DFS_RESCUE' and r['output'] is None:
            ck(r['deltas']==40 and r['stop_reason']=='delta_budget','toy atomic initialization truncation evidence')
        if r['instance_id']=='TRUE_CAPACITY_IMPOSSIBLE':
            ck(r['output'] is None and r['status']=='CONSTRUCTION_FAIL','toy infeasible output rejected')
    else:
        ck(r==dict(status='budget_discarded',reason='delta_budget',candidate=None),'toy atomic repair recorded outcome')
f=fixtures['NONMETRIC_DUPLICATES'];m=[[integer_edge(a,b) for b in f['coordinates']] for a in f['coordinates']]
ck(m[0][2]==3 and m[0][1]+m[1][2]==2 and m[1][3]==0 and m[0][1]+m[1][2]-m[0][2]==-1,'independent nonmetric toy arithmetic')
for a,b,c in itertools.product(range(4),repeat=3):
    ck(m[a][c]+m[c][b]-m[a][b]==integer_edge(f['coordinates'][a],f['coordinates'][c])+integer_edge(f['coordinates'][c],f['coordinates'][b])-integer_edge(f['coordinates'][a],f['coordinates'][b]),'toy insertion delta arithmetic')
bad=[(dict(routes=[[0,1,1,2,0]],reported_cost=5),'duplicate_customers'),(dict(routes=[[0,1,2,0]],reported_cost=5),'missing_customers'),(dict(routes=[[0,1,3,2,0]],reported_cost=6),'reported_cost_mismatch'),(dict(routes=[[0,0]],reported_cost=0),'invalid_route_shape_or_id'),(dict(routes=[[0,99,0]],reported_cost=0),'invalid_route_shape_or_id')]
for output,error in bad:
    ck(error in inspect_solution(f,output)['errors'],'independent adversarial toy checker '+error)
evidence['toy_evidence']=dict(recorded_assertions=toys['tests'],retained_records=len(toys['records']),retained_solution_occurrences_independently_checked=toy_solution_count,solver_reruns=0,limitation='17 frozen assertion outcomes and assertion source are present. Complete raw evidence is not retained for every assertion, notably both checkpoint-prefix solver comparisons, the one-node DFS cutoff and caller-mutation snapshot. These were reviewed, not independently re-executed.')

read_audit=read(ROOT/'raw/READ_AUDIT.json')
read_paths=read_audit['opened_read_paths']
ck(not read_audit['denied'] and read_audit['reference_read_count']==0,'recorded no forbidden reads')
ck(not any('/reference/' in p or '/provenance/' in p for p in read_paths),'no reference/provenance paths in Python open audit')
allowed=[str(ROOT/p)+'/' for p in ['source','input','freeze']]
ck(all(not p.startswith('/workspace/shared/') or any(p.startswith(q) for q in allowed) or p==str(ROOT/'reports/TOY_VALIDATION.json') for p in read_paths),'recorded shared-read allowlist')
run=(ROOT/'source/run.py').read_text()
analyze=(ROOT/'source/analyze.py').read_text()
ck(run.index('sys.addaudithook(guard)')<run.index('import official_solver as solver'),'read guard installed before solver import')
ck('os.fsync(handle.fileno())' in run and "handle.open('x'" not in run and ".open('x',encoding='utf-8')" in run,'unique exclusive output and fsync source')
ck('official_solver' not in analyze and 'run_one' not in analyze,'analysis has no solver invocation')
seal=read(ROOT/'raw/HEURISTICS_FINISHED.json')
ck(seal['heuristics_sha256']==sha(ROOT/'raw/heuristics.jsonl') and seal['trajectory_count']==24 and seal['all_rows_flushed_fsynced'],'sealed outputs hash and denominator')
dt=lambda x:datetime.datetime.fromisoformat(x)
ck(dt(read(ROOT/'freeze/PRE_TOY_FREEZE.json')['utc'])<dt(read(ROOT/'freeze/PRE_RUN_FREEZE.json')['utc'])<dt(read(ROOT/'raw/STARTED.json')['utc'])<dt(seal['utc'])<dt(summary['reference_read_started_after_seal'])<dt(summary['utc']),'freeze run seal scoring timestamp order')
ck(all(dt(r['finished_utc'])<=dt(seal['utc']) for r in records),'all trajectories finished before seal')
ck(read(ROOT/'raw/STARTED.json')['freeze_sha256']==sha(ROOT/'freeze/PRE_RUN_FREEZE.json'),'start freeze identity')
core_files=['official_solver.py','integer_distance.py','integer_audit.py','legacy/experiment.py']
core_calls=[]
for rel in core_files:
    tree=ast.parse((ROOT/'source'/rel).read_text())
    for node in ast.walk(tree):
        if isinstance(node,ast.Call):
            name=ast.unparse(node.func)
            if name in ['eval','exec','__import__','requests.get','requests.post','urllib.request.urlopen','subprocess.run','subprocess.Popen']:
                core_calls.append(dict(file=rel,line=node.lineno,call=name))
ck(not core_calls,'no dynamic/network/process calls in active algorithm core')
receipt=read(ROOT/'receipts/main.json')
ck(receipt['exit_code']==0 and receipt['complete'] and not receipt['wall_limit_kill'] and receipt['signal'] is None,'main process successful exit')
ck(receipt['cpu_hard_limit_seconds']==90 and receipt['wall_limit_seconds']==150 and receipt['child_total_cpu_seconds']<=90 and receipt['elapsed_wall_seconds']<=150,'hard limit main receipt')
ck(close(receipt['child_total_cpu_seconds'],receipt['child_user_cpu_seconds']+receipt['child_system_cpu_seconds']),'wait4 CPU sum')
for stage in ['prepare','main','audit','package']:
    rc=read(ROOT/'receipts'/f'{stage}.json')
    ck(rc['exit_code']==0 and rc['complete'],'all author stages successful '+stage)
    ck((ROOT/'receipts'/f'{stage}.stderr.log').stat().st_size==0,'empty stage stderr '+stage)
ck(all(resources[k]==0 for k in ['external_api_calls','scientific_model_calls','dependency_installs','uploads','oracle_calls']),'declared no billed external work')
evidence['leakage_and_resources']=dict(main_cpu_seconds=receipt['child_total_cpu_seconds'],main_wall_seconds=receipt['elapsed_wall_seconds'],main_exit_code=receipt['exit_code'],recorded_reference_read_paths=0,seal_utc=seal['utc'],scoring_reference_read_started=summary['reference_read_started_after_seal'],freeze_seal_timestamp_order_verified=True,cost_scope=resources['cost_scope'],limitations=['Python audit open events are not OS-level isolation and can include attempted nonexistent .pyc paths.','Pre-run preparation read official reference solutions for validation, as disclosed. No reference values or routes occur in the five-field solver input.','No runtime search replay: insertion total is cross-checked against counter arithmetic and source placement of charges, not independently reconstructed for every insertion decision.','No trusted execution attestation; hashes and local receipts establish internal consistency, not an absolute proof that no unrecorded external execution ever occurred.'])

after={str(p.relative_to(ROOT)):sha(p) for p in ROOT.rglob('*') if p.is_file()}
ck(after==before,'all audited package bytes unchanged during audit')
result=dict(status='PASS_WITH_LIMITATIONS' if not failures else 'FAIL',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Independent read-only frozen-package audit; no solver, oracle, model, network or official benchmark rerun.',assertions=checks,failures=failures,source_unchanged=after==before,evidence=evidence,audit_process_cpu_seconds=time.process_time()-t0,audit_process_wall_seconds=time.perf_counter()-w0)
(OUT/'AUDIT_RESULTS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
(OUT/'RECOMPUTED_CHECKPOINTS.json').write_text(json.dumps(recalculated,ensure_ascii=False,indent=2)+'\n')
(OUT/'SOURCE_SNAPSHOT.json').write_text(json.dumps(before,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['status','assertions','failures','source_unchanged','audit_process_cpu_seconds','audit_process_wall_seconds']},ensure_ascii=False))
sys.exit(0 if not failures else 1)
