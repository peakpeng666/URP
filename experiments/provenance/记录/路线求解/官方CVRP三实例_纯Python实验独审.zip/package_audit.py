"""Package audit evidence without touching the audited experiment."""
import datetime,hashlib,json,os,time,zipfile
from pathlib import Path
OUT=Path(__file__).resolve().parent
t=time.process_time();w=time.perf_counter()
result=json.loads((OUT/'AUDIT_RESULTS.json').read_text())
receipt=json.loads((OUT/'receipt.json').read_text())
assert result['status']=='PASS_WITH_LIMITATIONS' and receipt['exit_code']==0
findings={
 'blocking_defects':[],
 'nonblocking_findings':[
  {'id':'EVIDENCE-1','scope':'toy raw evidence','finding':'17 frozen assertion outcomes and assertion source exist, but raw evidence is not separately retained for every toy assertion. Both checkpoint-prefix comparisons, the one-node DFS cutoff and caller-mutation snapshot are examples. No solver was rerun to fill these gaps.','effect':'Limits independent replay claims; does not invalidate the verified official trajectory results.'},
  {'id':'WORDING-1','scope':'reports/TRACE_CHECKS.json','finding':'candidate_and_incumbent_outputs_checked is 5748, but source/analyze.py computes the number of trace entries. The name is ambiguous as a count of solution objects.','effect':'Independent audit checked 5748 trace incumbents and 5724 complete candidates, plus 24 baselines, 24 final outputs and 48 checkpoints: 11568 solution occurrences. Official cost/legality findings unchanged.'}
 ],
 'source_package_modified':False,
 'audit_solver_runs':0
}
(OUT/'REVIEW_FINDINGS.json').write_text(json.dumps(findings,ensure_ascii=False,indent=2)+'\n')
e=result['evidence']
lines=[
 '官方 CVRP 整数目标控制实验独立审计',
 '',
 '结论 PASS WITH LIMITATIONS',
 '35,813 项独立检查零失败；未发现改变已报告成本、解合法性、分母或主要结论的缺陷。原实验包与源码未修改。',
 '',
 '范围与方法',
 '审计对象为 official_cvrp_controls_20261008 冻结包及 official_cvrp_benchmarks_20261008 官方输入快照。独立标准库脚本只读解析原始 VRP、SOL、矩阵、轨迹、冻结文件和报告；未导入或运行任何被审 solver。未追加实验、pilot、补跑、oracle 或参考值调参。',
 '审计计算采用 19/20 CPU 秒软硬限及 40 秒 wall 硬限。完整执行记录见 receipt.json；脚本、原始审计 JSON 与48条重算检查点均随包保留。',
 '',
 '输入 来源与整数语义',
 '原 VRP/SOL 与官方数据包逐字节一致，manifest、SHA256SUMS、ZIP CRC/内容、运行前两次源码及输入冻结均匹配。两处整数目标依赖导入是唯一 solver core 适配，搜索体与此前 capacity solver 相同；来源文件与前代包哈希匹配。',
 'A/B/P 客户数分别为31/30/39，容量为100/100/140。原 depot ID 1规范化为0；客户原 ID c+1对应内部客户ID c。solver输入恰为 instance_id、coordinates、demands、capacity、K 五字段。',
 '所有矩阵边独立按 EUC_2D 逐边最近整数重算，并交叉检查 floor(hypot+0.5)。B的重复坐标客户对为内部ID(7,30)、(13,17)，未去重，每条合法解仍逐一服务。',
 'A/B/P按无序端点计的三角违例分别为33/60/58。整数矩阵确实非metric，审计未使用三角不等式。',
 'K≤5是本地协议。官方表格的reported K=5不在此改写为已证明的官方上界语义。三份参考路线合法，精确整数成本分别为784、672、458；Opt=yes仅归属于保存的官方页面，本审计未独立证明最优。',
 '',
 '轨迹 检查点与完整分母',
 '3实例×2方法×4固定seed=24条轨迹，每条唯一运行至160,000 counted deltas；同一轨迹观察40,000与160,000两个checkpoint，总48行。24/24轨迹和48/48检查点均合法，均达到预算，未删失败项或替换实例。',
 '独立审查5,748条trace，逐项核对seed派生的q与随机删除客户、严格改进接受、候选丢弃后的incumbent保留、单调delta及最终结果。5,724个完整候选与全部保存的incumbent均合法，整数成本准确。共重算11,568次解出现，包括baseline、final和checkpoint。',
 '40k检查点只取预算cut之前已提交的incumbent；跨cut才完成的候选未计入。按实例/方法分别保留4 seed全分母，CSV与详细JSON一致。',
 '',
 '160k主要结果 每行均为4 seed',
]
for g in e['groups']:
 if g['checkpoint']==160000:
  lines.append(f"{g['instance_id']} {g['method']}：mean/min/worst={g['cost_mean']:g}/{g['cost_min']}/{g['cost_worst']}，mean gap={g['gap_mean_percent']:.6f}%，参考值命中{g['reference_hits']}/4。")
lines += [
 '两个checkpoint的全部12组及seed级成本见 AUDIT_RESULTS.json 的 groups 与 RECOMPUTED_CHECKPOINTS.json。所有48检查点均高于给定官方参考值，没有低于参考值异常。',
 '',
 '资源 退出与参考隔离',
 '总delta=3,840,000，其中savings=13,128，random removal=0，insertion=3,826,872。矩阵pair计算=28,680；目标边计算=214,879，后者由baseline与每个完成候选的route边数独立重建。所有官方初始化均在savings获得5车合法解，FFD/DFS未触发，DFS节点总数为0。',
 '插入计数通过逐轨迹账本总和、单调cut、冻结源码中delta调用位置复核；本审计没有重做每一步repair选择，因此不声称独立重演每个插入候选的计数。checker的直接成本复核与算法cost_of边账不同，不能把214,879误作包括checker的所有距离计算。',
 f"主跑wait4：CPU={e['leakage_and_resources']['main_cpu_seconds']:.6f}秒，wall={e['leakage_and_resources']['main_wall_seconds']:.6f}秒，exit=0，无信号或wall杀停。prepare/main/audit/package四阶段均exit 0且stderr为空。",
 f"本次独立审计wait4：CPU={receipt['child_total_cpu_seconds']:.6f}秒，wall={receipt['elapsed_wall_seconds']:.6f}秒，exit=0。solver重跑、API/model调用、安装、购买、上传均为0。平台云端资源未折算货币价格，不将其称作零成本。",
 '输入与reference/SOL分目录隔离；五字段solver输入未包含参考路线或cost。Python open审计在solver导入前安装；保存的shared读取路径均符合allowlist，无reference/provenance读路径或拒绝事件。所有24行先flush/fsync并按整体SHA256封存，之后分析进程才读取reference并评分，冻结→启动→完成→封存→评分时间顺序一致。',
 '这是一项源与日志一致性审计。Python open事件不是操作系统强隔离证明，包含可能未成功的.pyc打开尝试；准备阶段为语义验证读取过reference，已披露。局部receipt不能证明世界上绝无未记录的外部运行或费用。',
 '',
 '玩具证据与非阻断问题',
 '17项预先冻结的toy断言有源码与PASS记录。本审计复核7条保留record中的72次解出现、重复ID、K5、DFS有效分组、18次固定组插入计数、截断无局部路线、构造失败、负插入代价及5类恶意解。',
 '部分toy没有保存逐项完整原始证据，尤其两项checkpoint-prefix solver对照、一节点DFS cutoff与调用者未变异snapshot。它们只能标记为源码及冻结PASS证据已审，不能称为本审计独立执行通过。遵守不重跑solver，未为补证据增实验。',
 '原TRACE_CHECKS.json字段 candidate_and_incumbent_outputs_checked=5748实际来自trace条目计数，字段命名易被误读为解对象总数。本审计采用上述明确的trace/candidate/solution occurrence口径；此命名问题不改变结果。详见 REVIEW_FINDINGS.json。',
 '',
 '科学结论限制',
 '独立benchmark单位只有3个具名小实例。4 seed为同实例重复，两方法使用成对相同seed，两个checkpoint为重复观测。不得称作24或48个独立实例，也不支持显著性、SOTA、普遍优越性或最优性证明。官方实例中未触发FFD/DFS，本轮不提供fallback救援效果新实证。',
 '',
 '官方证据链接',
 '本审计复核2026-10-07下载并保存的网页与原始文件，不宣称重新联网验证实时页面。',
 '官方表格 https://galgos.inf.puc-rio.br/cvrplib/index.php/en/instances',
 'A实例 https://galgos.inf.puc-rio.br/cvrplib/index.php/en/download/instance/4',
 'A参考 https://galgos.inf.puc-rio.br/cvrplib/index.php/en/download/bks/4',
 'B实例 https://galgos.inf.puc-rio.br/cvrplib/index.php/en/download/instance/6',
 'B参考 https://galgos.inf.puc-rio.br/cvrplib/index.php/en/download/bks/6',
 'P实例 https://galgos.inf.puc-rio.br/cvrplib/index.php/en/download/instance/82',
 'P参考 https://galgos.inf.puc-rio.br/cvrplib/index.php/en/download/bks/82',
 '',
 '审计产物索引',
 'audit.py：独立检查器源码；supervise_audit.py：20CPU/40wall上限监督器。',
 'AUDIT_RESULTS.json：完整检查结论、独立账本、instance/seed分组、边界。',
 'RECOMPUTED_CHECKPOINTS.json：48条独立提取并重算的检查点。',
 'REVIEW_FINDINGS.json：非阻断证据及命名问题。',
 'SOURCE_SNAPSHOT.json：审计前后相同的原包逐文件哈希。',
 'receipt.json、stdout.log、stderr.log：独立计算运行记录。',
 'MANIFEST.json、SHA256SUMS.txt与archive.sha256：审计交付校验。',
]
(OUT/'REPORT_ZH.txt').write_text('\n'.join(lines)+'\n')
(OUT/'README_ZH.txt').write_text('先读REPORT_ZH.txt。结论PASS WITH LIMITATIONS，详见AUDIT_RESULTS.json与REVIEW_FINDINGS.json。\n这是独立只读审计，不含solver重跑。原实验包未改。\n完整脚本、JSON、receipt随包保留。若需复算，将audit.py和supervise_audit.py复制到新的空目录，再运行python -B supervise_audit.py；须保留源码中指定的只读输入包路径。当前receipt不可覆盖。\nZIP包含MANIFEST与SHA256SUMS；archive.sha256与packaging_receipt.json置于ZIP外避免自引用。\n')
excludes={'MANIFEST.json','SHA256SUMS.txt','archive.sha256','packaging_receipt.json','audit_official_cvrp_controls_20261008.zip'}
files=sorted(p for p in OUT.iterdir() if p.is_file() and p.name not in excludes)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':result['status'],'files':[dict(path=p.name,bytes=p.stat().st_size,sha256=sha(p)) for p in files]}
(OUT/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
files.append(OUT/'MANIFEST.json')
(OUT/'SHA256SUMS.txt').write_text(''.join(f'{sha(p)}  {p.name}\n' for p in files))
files.append(OUT/'SHA256SUMS.txt')
archive=OUT/'audit_official_cvrp_controls_20261008.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.name)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 assert all(z.read(p.name)==p.read_bytes() for p in files)
(OUT/'archive.sha256').write_text(f'{sha(archive)}  {archive.name}\n')
receipt=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),packaging_process_cpu_seconds=time.process_time()-t,packaging_wall_seconds=time.perf_counter()-w,archive_bytes=archive.stat().st_size,archive_sha256=sha(archive),zip_integrity_verified=True,solver_runs=0)
(OUT/'packaging_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
for p in OUT.iterdir():
 if p.is_file():p.chmod(0o444)
print(json.dumps(receipt))
