"""One bounded independent recomputation; emits wait4 receipt even on failure."""
import datetime,json,os,resource,signal,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
if (ROOT/'receipt.json').exists():
    raise SystemExit('Independent audit already attempted; preserve receipt.')
def preexec():
    os.setsid()
    resource.setrlimit(resource.RLIMIT_CPU,(19,20))
t=time.perf_counter()
with (ROOT/'stdout.log').open('x') as out,(ROOT/'stderr.log').open('x') as err:
    p=subprocess.Popen([sys.executable,'-B',str(ROOT/'audit.py')],stdout=out,stderr=err,preexec_fn=preexec,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
    killed=False
    while True:
        pid,status,usage=os.wait4(p.pid,os.WNOHANG)
        if pid:
            break
        if time.perf_counter()-t>=40:
            killed=True
            os.killpg(p.pid,signal.SIGKILL)
            pid,status,usage=os.wait4(p.pid,0)
            break
        time.sleep(.025)
code=os.waitstatus_to_exitcode(status)
p.returncode=code
receipt=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),cpu_soft_limit_seconds=19,cpu_hard_limit_seconds=20,wall_limit_seconds=40,child_user_cpu_seconds=usage.ru_utime,child_system_cpu_seconds=usage.ru_stime,child_total_cpu_seconds=usage.ru_utime+usage.ru_stime,elapsed_wall_seconds=time.perf_counter()-t,maxrss_kib=usage.ru_maxrss,exit_code=code,signal=-code if code<0 else None,wall_limit_kill=killed,solver_runs=0,external_api_calls=0,model_calls=0,dependency_installs=0,purchases=0,uploads=0,complete=code==0)
(ROOT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
sys.exit(code)
