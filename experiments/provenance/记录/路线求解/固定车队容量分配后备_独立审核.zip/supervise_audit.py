"""Separate OS-measured receipt; bound audit to 20 CPU / 40 wall seconds."""
import datetime,json,os,pathlib,resource,signal,sys,time
OUT=pathlib.Path(__file__).resolve().parent
start=time.monotonic();pid=os.fork()
if pid==0:
    resource.setrlimit(resource.RLIMIT_CPU,(19,20))
    stdout=os.open(OUT/'audit.stdout.log',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    stderr=os.open(OUT/'audit.stderr.log',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    os.dup2(stdout,1);os.dup2(stderr,2)
    os.execv(sys.executable,[sys.executable,'-B',str(OUT/'independent_audit.py')])
killed=False
while True:
    done,status,usage=os.wait4(pid,os.WNOHANG)
    if done:break
    if time.monotonic()-start>40:
        os.kill(pid,signal.SIGKILL);killed=True;done,status,usage=os.wait4(pid,0);break
    time.sleep(.02)
receipt={'status':'PASS' if os.waitstatus_to_exitcode(status)==0 else 'FAIL','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':os.waitstatus_to_exitcode(status),'child_user_cpu_seconds':usage.ru_utime,'child_system_cpu_seconds':usage.ru_stime,'child_total_cpu_seconds':usage.ru_utime+usage.ru_stime,'elapsed_wall_seconds':time.monotonic()-start,'maxrss_kib':usage.ru_maxrss,'cpu_soft_limit_seconds':19,'cpu_hard_limit_seconds':20,'wall_limit_seconds':40,'wall_killed':killed,'heuristic_calls':0,'experiment_oracle_calls':0,'external_api_calls':0,'new_heuristic_candidates':0,'audit_exact_inputs_expected':64,'scope':'This independent audit process only; inspection, code authoring and packaging are separate.'}
(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt));sys.exit(0 if receipt['status']=='PASS' else 1)
