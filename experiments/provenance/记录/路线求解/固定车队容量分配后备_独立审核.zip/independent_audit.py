"""Read-only independent audit. No imports or execution of experiment code.

The only exact enumeration is an audit calculation on frozen inputs. It does not
call either heuristic, generate experimental candidates, or amend the old bundle.
"""
import ast
import collections
import datetime
import difflib
import functools
import hashlib
import itertools
import json
import math
import pathlib
import random
import statistics
import sys
import time
import zipfile

BASE = pathlib.Path('/workspace/shared/capacity_partition_fallback_20261008')
OUT = pathlib.Path(__file__).resolve().parent
EXPECTED_ZIP = 'bf293cfe351ac52abd6644b2160026134d6a7471c88b91fe693760960de2c0b9'
TIMES = {'solver_cpu_seconds','solver_wall_seconds','final_checker_cpu_seconds','final_checker_wall_seconds'}
TAGS = {'run_id','geometry_id','family','pattern_id','pattern_name','input_sha256','version','completed_utc'}
START = time.process_time()
COUNTS = collections.Counter()

def read(rel):
    return json.loads((BASE/rel).read_text())

def sha(path):
    h=hashlib.sha256()
    with pathlib.Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()

def stable(r):
    return json.dumps({k:v for k,v in r.items() if k not in TIMES|TAGS},sort_keys=True,separators=(',',':'),allow_nan=False).encode()

def check(condition, label):
    if not condition:raise AssertionError(label)
    COUNTS[label.split(':')[0]]+=1

def near(a,b):
    return math.isclose(a,b,rel_tol=1e-10,abs_tol=1e-8)

def matches(a,b,label):
    if isinstance(b,dict):
        for k,v in b.items():
            check(k in a,label+':key:'+k)
            matches(a[k],v,label+':'+k)
    elif isinstance(b,list):
        check(isinstance(a,list) and len(a)==len(b),label+':length')
        for i,(x,y) in enumerate(zip(a,b)):matches(x,y,label+':'+str(i))
    elif type(b) is float:check(type(a) in (float,int) and near(a,b),label)
    else:check(a==b,label)

def function_text(source,name):
    tree=ast.parse(source)
    return ast.get_source_segment(source,next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name==name))

def make_checker(raw):
    n=len(raw['demands'])-1
    xy=raw['coordinates']
    # Independently constructed distances, no experiment matrix or checker used.
    d=[[math.sqrt((x[0]-y[0])**2+(x[1]-y[1])**2) for y in xy] for x in xy]
    cache={}
    def verify(output,K=None):
        if output is None:return None
        K=raw['K'] if K is None else K
        check(isinstance(output,dict) and isinstance(output.get('routes'),list),'solution:shape')
        routes=output['routes'];key=(tuple(tuple(x) for x in routes),K)
        if key not in cache:
            check(0<len(routes)<=K,'solution:vehicle_cap')
            seen=[];edges=[]
            for route in routes:
                check(len(route)>=3 and route[0]==route[-1]==0,'solution:depot')
                check(all(type(j) is int and 1<=j<=n for j in route[1:-1]),'solution:IDs')
                seen.extend(route[1:-1])
                check(sum(raw['demands'][j] for j in route[1:-1])<=raw['capacity'],'solution:capacity')
                edges.extend(d[a][b] for a,b in zip(route,route[1:]))
            check(sorted(seen)==list(range(1,n+1)),'solution:coverage_once')
            cache[key]=math.fsum(edges)
        cost=cache[key];claimed=output.get('reported_cost',output.get('cost'))
        check(type(claimed) in (int,float) and math.isfinite(claimed) and near(cost,claimed),'solution:cost')
        return cost
    return verify,d

def audit_exact(raw,d,record):
    """Direct permutation enumeration per capacity subset, then all <=K covers.

    Unlike the submitted oracle's Held-Karp recurrence, route minima below are
    obtained by direct itertools permutations. No route witnesses are returned.
    Capacity-total contradictions are standalone integer infeasibility proofs.
    """
    n=len(raw['demands'])-1;Q=raw['capacity'];K=raw['K'];full=(1<<n)-1
    total=sum(raw['demands']);claimed=record['result']['by_k'][str(K)]
    if total>K*Q:
        check(claimed is None,'exact:capacity_contradiction')
        return {'instance_id':raw['instance_id'],'feasible':False,'proof':'sum_demands > K*Q','total_demand':total,'total_capacity':K*Q,'exact_cost':None,'permutations':0}
    minima={};perms=0
    for mask in range(1,full+1):
        nodes=tuple(j+1 for j in range(n) if mask>>j&1)
        if sum(raw['demands'][j] for j in nodes)>Q:continue
        v=math.inf
        for perm in itertools.permutations(nodes):
            edges=[d[0][perm[0]],d[perm[-1]][0]]
            edges.extend(d[a][b] for a,b in zip(perm,perm[1:]))
            v=min(v,math.fsum(edges));perms+=1
        minima[mask]=v
        check(near(record['result']['tours'][str(mask)]['cost'],v),'exact:subset_minimum')
    check(set(map(int,record['result']['tours']))==set(minima),'exact:all_capacity_subsets')
    @functools.lru_cache(None)
    def cover(mask,left):
        if not mask:return 0.0
        if not left:return math.inf
        anchor=mask&-mask;best=math.inf;sub=mask
        while sub:
            if sub&anchor and sub in minima:
                tail=cover(mask^sub,left-1)
                best=min(best,minima[sub]+tail)
            sub=(sub-1)&mask
        return best
    exact=cover(full,K);feasible=math.isfinite(exact)
    check(feasible==(claimed is not None),'exact:feasibility')
    if feasible:check(near(exact,claimed['cost']),'exact:K3_optimum')
    return {'instance_id':raw['instance_id'],'feasible':feasible,'proof':'all capacity-subset permutations and anchored set covers up to K','total_demand':total,'total_capacity':K*Q,'exact_cost':exact if feasible else None,'permutations':perms,'capacity_subsets':len(minima),'cover_states':cover.cache_info().currsize}

def main():
    archive=BASE/(BASE.name+'.zip')
    check(sha(archive)==EXPECTED_ZIP,'archive:expected_SHA256')
    manifest=read('MANIFEST.json');filehash={}
    for item in manifest['files']:
        p=BASE/item['path'];h=sha(p);filehash[item['path']]=h
        check(h==item['sha256'] and p.stat().st_size==item['bytes'],'manifest:file')
    check(len(filehash)==manifest['file_count']==120,'manifest:count')
    for line in (BASE/'SHA256SUMS.txt').read_text().splitlines():
        h,p=line.split('  ',1);check(sha(BASE/p)==h,'manifest:SHA256SUMS')
    with zipfile.ZipFile(archive) as z:
        check(set(z.namelist())==set(filehash)|{'MANIFEST.json','SHA256SUMS.txt'},'archive:members')
        for name in z.namelist():check(hashlib.sha256(z.read(name)).hexdigest()==sha(BASE/name),'archive:member_bytes')
    for path in ['freeze/PRE_TOY_FREEZE.json','freeze/PRE_GENERATION_FREEZE.json','freeze/PRE_RUN_FREEZE.json']:
        for p,h in read(path)['sha256'].items():check(sha(BASE/p)==h,'freeze:frozen_file')
    inherited=[]
    for item in read('freeze/SOURCE_PROVENANCE.json'):
        check((BASE/item['path']).read_bytes()==pathlib.Path(item['source']).read_bytes(),'source:old_byte_identical')
        check(sha(BASE/item['path'])==item['sha256'],'source:old_digest')
        inherited.append(item['path'])
    toy_old=BASE/'provenance/PREDECESSOR_TOY_VALIDATION.json'
    check(toy_old.read_bytes()==pathlib.Path('/workspace/shared/fixed_fleet_cvrp_20261008/reports/TOY_VALIDATION.json').read_bytes(),'source:old_toy_byte_identical')
    check(len(inherited)==11,'source:11_python_plus_1_toy')

    old=(BASE/'source/fixed_solver.py').read_text();new=(BASE/'source/capacity_solver.py').read_text()
    unchanged=['instance_for','ffd_routes','route_options','repair','evaluate_candidate']
    for name in unchanged:check(function_text(old,name)==function_text(new,name),'source:unchanged_'+name)
    check(function_text(old,'run_one')==function_text(new,'run_one').replace("        if isinstance(exc,ConstructionFailure):status='CONSTRUCTION_FAIL'\n",''),'source:search_only_failure_status_change')
    check(function_text(old,'initialize')==function_text(new,'initialize').replace("            diagnostic['original_ffd_failure']=str(exc)\n            routes=capacity_routes(inst,matrix,budget,diagnostic)","            exc.detail=diagnostic;raise"),'source:only_InitFailure_hook')
    insert_old=function_text(old,'ffd_routes');insert_old=insert_old[insert_old.index('    for group in bins:'):]
    insert_new=function_text(new,'capacity_routes');insert_new=insert_new[insert_new.index('    for group in bins:'):].replace("    report['route_insertion_deltas']=budget.deltas-before\n",'')
    check(insert_old==insert_new,'source:identical_group_insertion_arithmetic_and_charge')
    patch=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='fixed_solver.py (unchanged predecessor)',tofile='capacity_solver.py (new algorithm)'))
    check(patch==(BASE/'provenance/MINIMAL_CORE_DIFF.patch').read_text(),'source:exact_diff')
    tree=ast.parse(new);part=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='bounded_partition')
    check([x.arg for x in part.args.args]==['demands','capacity','K','node_limit'],'source:demand_only_interface')
    names={n.id for n in ast.walk(part) if isinstance(n,ast.Name)}
    check(not names & {'matrix','raw','oracle','coordinates','reference','cost','distance','time','random','open','eval','exec'},'source:partition_no_external_inputs')
    calls={n.func.id for n in ast.walk(part) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name)}
    check(calls=={'sorted','range','len','set','visit'},'source:partition_calls_allowlist')
    check("CAPACITY_NODE_LIMIT = 256" in new and 'node_limit=CAPACITY_NODE_LIMIT' in function_text(new,'bounded_partition'),'source:fixed256')
    check('bounded_partition(inst.demands,inst.capacity,inst.K)' in new,'source:production_default_cap')
    check('if nodes>=node_limit:' in new and 'nodes+=1' in new and "'mathematical_infeasibility_claim':False" in new,'source:bounded_not_infeasibility_claim')
    for rel in ['source/fixed_solver.py','source/capacity_solver.py','source/legacy/experiment.py','source/audit.py']:
        t=ast.parse((BASE/rel).read_text())
        imports=[n.module for n in ast.walk(t) if isinstance(n,ast.ImportFrom)]+[a.name for n in ast.walk(t) if isinstance(n,ast.Import) for a in n.names]
        check(not any(x and (x=='oracle' or x.startswith(('requests','http','urllib','socket'))) for x in imports),'source:no_oracle_or_network_import')
    runner=(BASE/'source/run.py').read_text()
    check(runner.index('from oracle import solve')>runner.index("raw/HEURISTICS_FINISHED.json"),'source:late_oracle_import')
    check("SOLVER_RAW_KEYS=('instance_id','coordinates','demands','capacity','K')" in runner,'source:raw_allowlist')
    check("SOLVER_CFG_KEYS=('delta_limit','iterations','per_trajectory_cpu_seconds','per_trajectory_wall_seconds')" in runner,'source:config_allowlist')
    check("record=solver(r,e['method'],e['search_seed'],scfg)" in runner,'source:filtered_solver_call')

    cfg=read('freeze/PROTOCOL.json');entries=read('freeze/INPUT_MANIFEST.json');geoms=read('freeze/GEOMETRY_MANIFEST.json')
    raws={e['instance_id']:read(e['input_file']) for e in entries}
    check(len(raws)==64 and len(geoms)==16 and cfg['capacity_dfs_node_limit']==256 and cfg['delta_limit']==5000,'design:dimensions')
    oldgeo=read('freeze/OLD_GEOMETRY_HASHES.json');seen=set()
    for g in geoms:
        check(g['coordinates_sha256'] not in oldgeo['ordered_hashes'] and g['unordered_coordinates_sha256'] not in oldgeo['unordered_hashes'],'design:new_geometry_hashes')
        check(g['coordinates_sha256'] not in seen,'design:unique_geometry');seen.add(g['coordinates_sha256'])
        rng=random.Random(g['generation_seed']);xy=[[0.,0.]]
        for j in range(9):
            p=[rng.uniform(-50,50),rng.uniform(-50,50)] if g['family']=='uniform' else [rng.gauss(z,8) for z in ((-30,-20) if j%2==0 else (30,20))]
            xy.append([round(z,6) for z in p])
        for e in [x for x in entries if x['geometry_id']==g['geometry_id']]:
            raw=raws[e['instance_id']];check(raw['coordinates']==xy,'design:geometry_seed_regeneration')
            p=next(x for x in cfg['patterns'] if x['id']==e['pattern_id']);rng=random.Random(e['demand_seed'])
            ds=p['demands'][:] if p['demands'] else [rng.randint(1,5) for _ in range(9)]
            if p['demands']:rng.shuffle(ds)
            check(raw['demands']==[0]+ds and sha(BASE/e['input_file'])==e['input_sha256'],'design:demand_seed_and_hash')
    schedule=read('freeze/SCHEDULE.json')
    expected={(e['instance_id'],m,v,s) for e in entries for m in cfg['methods'] for v in cfg['versions'] for s in cfg['search_seeds']}
    check(len(schedule)==len(expected)==1024 and {(e['instance_id'],e['method'],e['version'],e['search_seed']) for e in schedule}==expected,'design:full_factorial')
    expected_schedule=[dict(e,method=m,version=v,search_seed=s) for e in entries for s in cfg['search_seeds'] for m in cfg['methods'] for v in cfg['versions']]
    random.Random(cfg['schedule_seed']).shuffle(expected_schedule)
    for i,e in enumerate(expected_schedule):e['run_id']=i
    check(schedule==expected_schedule,'design:prespecified_schedule')
    runs=[json.loads(x) for x in (BASE/'raw/heuristics.jsonl').read_text().splitlines()]
    orows=[json.loads(x) for x in (BASE/'raw/oracles.jsonl').read_text().splitlines()];oracles={o['instance_id']:o for o in orows}
    byid={r['run_id']:r for r in runs}
    check(len(runs)==len(byid)==1024 and set(byid)==set(range(1024)),'runs:all_planned_records')
    check(len(orows)==len(oracles)==64 and set(oracles)==set(raws),'runs:all_oracle_inputs')
    seal=read('raw/HEURISTICS_FINISHED.json');start=read('raw/STARTED.json');finished=read('raw/FINISHED.json')
    check(seal['planned']==seal['recorded']==1024 and seal['oracle_main_calls_so_far']==0 and seal['every_record_flushed_and_fsynced'],'seal:counts')
    check(sha(BASE/'raw/heuristics.jsonl')==seal['raw_sha256'],'seal:raw_hash')
    times=[cfg['created_utc'],read('freeze/PRE_TOY_FREEZE.json')['utc'],read('freeze/PRE_GENERATION_FREEZE.json')['utc'],read('freeze/PRE_RUN_FREEZE.json')['utc'],start['utc'],min(r['completed_utc'] for r in runs),max(r['completed_utc'] for r in runs),seal['utc'],min(r['completed_utc'] for r in orows),max(r['completed_utc'] for r in orows),finished['utc']]
    check(times==sorted(times),'seal:freeze_heuristic_oracle_timeline')
    check(start['freeze_sha256']==sha(BASE/'freeze/PRE_RUN_FREEZE.json') and start['main_launch_number']==1,'seal:launch')

    exact=[];checkers={};matrices={}
    for iid,raw in raws.items():
        checker,d=make_checker(raw);checkers[iid]=checker;matrices[iid]=d
        o=oracles[iid]
        check(o['input_sha256']==next(e['input_sha256'] for e in entries if e['instance_id']==iid),'exact:input_hash')
        for k,sol in o['result']['by_k'].items():
            if sol is not None:checker(sol,int(k))
        exact.append(audit_exact(raw,d,o))
    check(sum(x['feasible'] for x in exact)==56,'exact:56_feasible_inputs')
    exact_by={x['instance_id']:x for x in exact}
    trace_counts=collections.Counter();metrics=[];stable_hashes={}
    for e in schedule:
        r=byid[e['run_id']];raw=raws[e['instance_id']];checker=checkers[e['instance_id']]
        for k in ['run_id','instance_id','geometry_id','family','pattern_id','pattern_name','method','version','search_seed','input_sha256']:check(r[k]==e[k],'runs:record_identity')
        check(0<=r['deltas']<=5000 and sum(r['delta_by_kind'].values())==r['deltas'],'budget:delta_bounds_and_sum')
        check(r['delta_by_kind']['savings']==36 and r['delta_by_kind']['removal']==0 and r['matrix_distances']==100,'budget:fixed_charge_categories')
        prior=r['baseline'];bcost=checker(prior);final=checker(r['output']);legal=r['status']=='LEGAL_COMPLETION'
        check(legal==(final is not None),'runs:status_output')
        feasible=exact_by[e['instance_id']]['feasible'];opt=exact_by[e['instance_id']]['exact_cost']
        check(not legal or feasible,'runs:no_false_positive')
        check(r['check']['accepted']==legal and r['baseline_check']['accepted']==(bcost is not None),'runs:stored_check_agrees')
        init=r['initialization'];cp=init.get('capacity_partition',{}) if init else {}
        check(init is not None and init['deltas_after_savings']==36,'budget:init_saved')
        check(init['savings_route_count']==len(init['savings_routes']) and init['fallback_triggered']==(init['savings_route_count']>raw['K']),'runs:fallback_trigger')
        flat=[j for rr in init['savings_routes'] for j in rr]
        check(sorted(flat)==list(range(1,10)) and all(sum(raw['demands'][j] for j in rr)<=raw['capacity'] for rr in init['savings_routes']),'runs:savings_partial_legal_coverage')
        if cp:
            check(e['version']=='capacity_dfs256' and init['fallback_triggered'] and init['original_ffd_failure']=='ffd_capacity_construction_failed','fallback:failure_only')
            check(0<cp['nodes']<=256 and cp['node_limit']==256 and not cp['mathematical_infeasibility_claim'],'fallback:bounded_not_proof')
            check(cp['cpu_seconds']>=0 and cp['wall_seconds']>=0,'fallback:explicit_extra_time')
            if cp['groups'] is not None:
                groups=cp['groups'];flat=[j for g in groups for j in g]
                check(cp['outcome']=='FOUND' and legal and len(groups)<=3 and sorted(flat)==list(range(1,10)),'fallback:found_partition')
                check(all(sum(raw['demands'][j] for j in g)<=9 for g in groups),'fallback:group_capacity')
                expected_delta=sum(len(g)*(len(g)+1)//2 for g in groups)
                check(cp['route_insertion_deltas']==expected_delta and init['deltas_after_initialization']==36+expected_delta,'fallback:all_group_insertions_charged')
                check(sorted(map(sorted,groups))==sorted(sorted(rr[1:-1]) for rr in prior['routes']),'fallback:group_memberships_preserved')
            else:check(not legal and r['status']=='CONSTRUCTION_FAIL' and cp['outcome'] in ('SEARCH_EXHAUSTED','NODE_LIMIT'),'fallback:no_partial_output')
        elif e['version']=='capacity_dfs256':check(legal,'fallback:new_success_without_DFS')
        delta=init.get('deltas_after_initialization',36);tc=collections.Counter()
        for ti,t in enumerate(r['trace']):
            check(t['iteration']==ti and delta<=t['deltas']<=5000,'trace:iteration_and_delta')
            delta=t['deltas'];check(prior is not None,'trace:has_current')
            check(len(t['removed'])==t['q'] and len(set(t['removed']))==t['q'] and 2<=t['q']<=3 and set(t['removed'])<=set(range(1,10)),'trace:destroy_shape')
            status=t['candidate_status'];tc[status]+=1;trace_counts[status]+=1
            if status=='complete':
                cost=checker(t['candidate']);accept=cost<prior['reported_cost']-1e-9
                check(t['accepted']==accept,'trace:strict_improvement')
                if accept:prior=t['candidate'];tc['accepted']+=1;trace_counts['accepted']+=1
            else:
                check(status in ('repair_failed','budget_discarded') and t['candidate'] is None and not t['accepted'],'trace:failed_candidate_discarded')
                if status=='repair_failed':
                    detail=t['detail'];part=detail['partial_routes'];remaining=detail['remaining'];flat=[j for rr in part for j in rr]
                    check(len(part)<=3 and all(sum(raw['demands'][j] for j in rr)<=9 for rr in part),'trace:failed_partial_capacity')
                    check(sorted(flat+remaining)==list(range(1,10)) and set(remaining)<=set(t['removed']) and detail['blocked_node'] in remaining,'trace:failed_partial_coverage')
                    blocked=detail['blocked_node'];check(len(part)==3 and all(sum(raw['demands'][j] for j in rr)+raw['demands'][blocked]>9 for rr in part),'trace:true_no_feasible_insertion')
                else:check(ti==len(r['trace'])-1 and t['reason']=='delta_budget' and t['deltas']==5000,'trace:budget_stop')
            check(prior==t['incumbent'],'trace:current_best_or_rollback')
            checker(t['incumbent'])
        check(prior==r['output'] and r['iterations_completed']==tc['complete'] and r['repair_failures']==tc['repair_failed'] and r['accepted_improvements']==tc['accepted'],'trace:final_counters')
        check(r['iterations_started']==len(r['trace']),'trace:all_started_saved')
        if legal:check(r['deltas']==5000 and r['stop_reason']=='delta_budget','budget:legal_stops_at5000')
        else:check(r['trace']==[] and r['baseline'] is None and r['deltas']==36 and r['stop_reason']=='initialization_failed','runs:failed_init_accounting')
        gap=100*(final-opt)/opt if legal else None
        if legal:check(final>=opt-1e-8,'exact:solution_lower_bound')
        metrics.append({k:e[k] for k in ['run_id','geometry_id','instance_id','family','pattern_id','method','version','search_seed']}|{'legal':legal,'status':r['status'],'feasible':feasible,'gap':gap,'dfs':cp,'cost':final,'baseline_cost':bcost,'deltas':r['deltas'],'solver_cpu_seconds':r['solver_cpu_seconds'],'solver_wall_seconds':r['solver_wall_seconds'],'repair_failures':r['repair_failures']})
        stable_hashes[r['run_id']]=hashlib.sha256(stable(r)).hexdigest()

    def summarize(rows):
        good=[r for r in rows if r['legal']];feas=[r for r in rows if r['feasible']];inf=[r for r in rows if not r['feasible']]
        return {'planned':len(rows),'recorded':len(rows),'status_counts':dict(collections.Counter(r['status'] for r in rows)),
            'oracle_feasible_planned':len(feas),'oracle_infeasible_planned':len(inf),'oracle_unknown_planned':0,
            'legal_count':len(good),'legal_rate_all_planned':len(good)/len(rows),
            'legal_count_oracle_feasible':sum(r['legal'] for r in feas),'legal_rate_oracle_feasible':sum(r['legal'] for r in feas)/len(feas),
            'infeasible_emitted_output_count':sum(r['cost'] is not None for r in inf),'infeasible_legal_false_positive_count':sum(r['legal'] for r in inf),'illegal_output_count':0,
            'valid_only_mean_gap_percent_descriptive':statistics.mean(r['gap'] for r in good) if good else None,
            'exact_count':sum(abs(r['gap'])<1e-8 for r in good),'within1percent_count':sum(r['gap']<=1+1e-8 for r in good),
            'dfs_calls':sum(bool(r['dfs']) for r in rows),'dfs_nodes':sum(r['dfs'].get('nodes',0) for r in rows),'dfs_max_nodes':max([r['dfs'].get('nodes',0) for r in rows],default=0),
            'dfs_cpu_seconds':sum(r['dfs'].get('cpu_seconds',0) for r in rows),'dfs_wall_seconds':sum(r['dfs'].get('wall_seconds',0) for r in rows),
            'dfs_outcomes':dict(collections.Counter(r['dfs']['outcome'] for r in rows if r['dfs'])),
            'solver_cpu_seconds':sum(r['solver_cpu_seconds'] for r in rows),'solver_wall_seconds':sum(r['solver_wall_seconds'] for r in rows),
            'delta_sum':sum(r['deltas'] for r in rows),'repair_failed_candidates':sum(r['repair_failures'] for r in rows)}
    summary=read('reports/SUMMARY.json');versions={v:summarize([r for r in metrics if r['version']==v]) for v in cfg['versions']}
    matches(summary['versions'],versions,'report:versions')
    for v in cfg['versions']:
        for m in cfg['methods']:matches(summary['version_methods'][v][m],summarize([r for r in metrics if r['version']==v and r['method']==m]),'report:version_methods')
    pairs=collections.defaultdict(dict)
    for r in metrics:pairs[(r['instance_id'],r['method'],r['search_seed'])][r['version']]=r
    pairrows=[];bitwise=[]
    for key,d in pairs.items():
        a=d['original'];b=d['capacity_dfs256'];common=a['legal'] and b['legal'];rescue=not a['legal'] and b['legal'];lost=a['legal'] and not b['legal']
        if a['legal']:
            check(stable(byid[a['run_id']])==stable(byid[b['run_id']]),'pairs:bitwise_non_timing_payload')
            bitwise.append({'original_run_id':a['run_id'],'new_run_id':b['run_id'],'payload_sha256':stable_hashes[a['run_id']]})
        if rescue:check(a['cost'] is None and a['baseline_cost'] is None,'pairs:no_fictitious_original_cost')
        pairrows.append({'instance_id':a['instance_id'],'geometry_id':a['geometry_id'],'method':a['method'],'pattern_id':a['pattern_id'],'common':common,'rescue':rescue,'lost':lost,'old_gap':a['gap'] if common else None,'new_gap':b['gap'] if common or rescue else None,'original_run_id':a['run_id'],'new_run_id':b['run_id']})
    paired={'pairs':len(pairrows),'common_success':sum(p['common'] for p in pairrows),'rescued':sum(p['rescue'] for p in pairrows),'lost':sum(p['lost'] for p in pairrows),'bitwise_negative_control_pass':len(bitwise)}
    matches(summary['paired_counts'],paired,'report:pairs');check(paired=={'pairs':512,'common_success':224,'rescued':224,'lost':0,'bitwise_negative_control_pass':224},'pairs:expected_counts')
    pp=read('reports/PAIRED_RESULTS.json');ppid={x['original_run_id']:x for x in pp}
    for p in pairrows:
        q=ppid[p['original_run_id']]
        matches(q,{'new_run_id':p['new_run_id'],'common_success':p['common'],'rescued':p['rescue'],'lost':p['lost'],'original_gap_percent':p['old_gap'],'new_common_gap_percent':p['new_gap'] if p['common'] else None,'new_rescue_gap_percent':p['new_gap'] if p['rescue'] else None},'report:pair_row')
        if p['rescue']:check(q['new_minus_original_cost'] is None,'report:no_rescue_baseline_percent')
    patterns={}
    for p in cfg['patterns']:
        pid=p['id'];pvs={v:summarize([r for r in metrics if r['version']==v and r['pattern_id']==pid]) for v in cfg['versions']}
        patterns[pid]={'versions':pvs,'rescued_pairs':sum(r['rescue'] for r in pairrows if r['pattern_id']==pid),'common_pairs':sum(r['common'] for r in pairrows if r['pattern_id']==pid)}
        matches(summary['patterns'][pid],patterns[pid],'report:pattern')
    geometry_reports=read('reports/GEOMETRY_RESULTS.json');geometry_checks=[];quality={m:[] for m in cfg['methods']}
    for g in geometry_reports:
        gid=g['geometry_id'];values={v:summarize([r for r in metrics if r['version']==v and r['geometry_id']==gid]) for v in cfg['versions']}
        matches(g['versions'],values,'report:geometry_denominators')
        methods={}
        for m in cfg['methods']:
            cells=[]
            for p in cfg['patterns']:
                cell=[x for x in pairrows if x['geometry_id']==gid and x['method']==m and x['pattern_id']==p['id']]
                check(len(cell)==4,'report:four_seed_cells');common=all(x['common'] for x in cell);rescue=all(x['rescue'] for x in cell)
                cells.append({'pattern_id':p['id'],'common_all4':common,'rescued_all4':rescue,
                    'common_original_gap':statistics.mean(x['old_gap'] for x in cell) if common else None,
                    'common_new_gap':statistics.mean(x['new_gap'] for x in cell) if common else None,
                    'rescued_new_gap':statistics.mean(x['new_gap'] for x in cell) if rescue else None})
            common=[x for x in cells if x['common_all4']];rescue=[x for x in cells if x['rescued_all4']]
            value={'cells':cells,'common_cell_count':len(common),'rescue_cell_count':len(rescue),
                'common_original_gap_geometry_mean':statistics.mean(x['common_original_gap'] for x in common) if common else None,
                'common_new_gap_geometry_mean':statistics.mean(x['common_new_gap'] for x in common) if common else None,
                'rescue_new_gap_geometry_mean':statistics.mean(x['rescued_new_gap'] for x in rescue) if rescue else None}
            matches(g['methods'][m],value,'report:geometry_quality');quality[m].append(value);methods[m]=value
        geometry_checks.append({'geometry_id':gid,'versions':values,'methods':methods})
    qsummary={}
    for m,gg in quality.items():
        c=[x for x in gg if x['common_original_gap_geometry_mean'] is not None];r=[x for x in gg if x['rescue_new_gap_geometry_mean'] is not None]
        qsummary[m]={'common_support_geometries':len(c),'common_original_gap_equal_geometry_percent':statistics.mean(x['common_original_gap_geometry_mean'] for x in c),'common_new_gap_equal_geometry_percent':statistics.mean(x['common_new_gap_geometry_mean'] for x in c),'rescue_support_geometries':len(r),'rescue_new_gap_equal_geometry_percent':statistics.mean(x['rescue_new_gap_geometry_mean'] for x in r),'rescue_baseline_cost_reduction_percent':None}
        matches(summary['geometry_unit_quality'][m],qsummary[m],'report:equal_geometry_quality')
    for family in ['uniform','two_cluster']:
        for v in cfg['versions']:matches(summary['family_descriptions'][family][v],summarize([r for r in metrics if r['family']==family and r['version']==v]),'report:family')

    toys=read('reports/TOY_VALIDATION.json');tr=toys['records']
    check(toys['passed'] and toys['oracle_calls']==toys['main_input_calls']==0 and len(toys['tests'])==len(tr)==6,'toys:coverage')
    a=tr[0]['old'];b=tr[0]['new'];check(a['status']=='INIT_FAIL' and a['output'] is None and b['status']=='LEGAL_COMPLETION' and b['deltas']==54 and b['initialization']['capacity_partition']['route_insertion_deltas']==18,'toys:rescue_charged18')
    toyraw={'demands':[0,4,4,4,3,3,3,2,2,2],'coordinates':[[0,0]]*10,'capacity':9,'K':3};make_checker(toyraw)[0](b['output'])
    b=tr[1]['new'];check(b['status']=='CONSTRUCTION_FAIL' and b['output'] is None and b['initialization']['capacity_partition']['outcome']=='SEARCH_EXHAUSTED' and not b['initialization']['capacity_partition']['mathematical_infeasibility_claim'],'toys:four_large_demands_no_false_positive')
    check(4>3 and 5+5>9,'toys:integer_packing_contradiction')
    check(tr[2]['one_node_limit']=={'nodes':1,'node_limit':1,'limit_reached':True,'outcome':'NODE_LIMIT','mathematical_infeasibility_claim':False},'toys:one_node_cap')
    for i,m in [(3,'cheapest'),(4,'regret2')]:
        check(tr[i]['old']['method']==m and stable(tr[i]['old'])==stable(tr[i]['new']) and 'capacity_partition' not in tr[i]['new']['initialization'],'toys:old_success_identical')
    b=tr[5]['new'];check(b['output'] is None and b['baseline'] is None and b['trace']==[] and b['deltas']==40 and b['delta_by_kind']['insertion']==4 and b['stop_reason']=='delta_budget','toys:insertion_cutoff_atomic')
    predecessor=read('provenance/PREDECESSOR_TOY_VALIDATION.json')
    check(predecessor['passed'] and predecessor['repair_failure_example']['candidate'] is None and predecessor['budget_discard_example']['candidate'] is None,'toys:inherited_rollback_evidence')
    ledger=read('failures/FAILURE_LEDGER.json');check(ledger['missing_run_ids']==[] and ledger['malformed_records']==[],'ledger:no_missing_or_malformed')
    check({r['run_id'] for r in ledger['nonlegal_runs']}=={r['run_id'] for r in metrics if not r['legal']},'ledger:all_nonlegal_rows')
    mr=read('receipts/main.json');check(mr['exit_code']==0 and mr['complete'] and mr['child_total_cpu_seconds']<90 and mr['elapsed_wall_seconds']<150,'resources:main_complete')
    check(near(mr['child_total_cpu_seconds'],10.296334) and near(mr['elapsed_wall_seconds'],10.313158743010717),'resources:main_receipt')
    matches(read('reports/RESOURCE_ACCOUNTING.json')['versions'],versions,'resources:totals')
    check(sha(archive)==EXPECTED_ZIP,'archive:unchanged_after_audit')
    result={'status':'PASS','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'audited_bundle':str(BASE),'original_zip_sha256':EXPECTED_ZIP,
        'audit_scope':{'heuristic_calls':0,'experiment_oracle_calls':0,'external_api_calls':0,'new_heuristic_candidates':0,'experiment_imports':0,'source_bundle_writes':0,'independent_exact_audit_inputs':64,'cpu_hard_limit_seconds':20,'wall_limit_seconds':40},
        'independent_checks':dict(COUNTS),'inherited_unchanged':{'python_files':inherited,'python_count':11,'old_toy_count':1,'total':12},
        'source_core_pass':True,'fixed_node_cap':256,'late_oracle_seal_pass':True,'manifest_file_count':120,'planned_and_recorded_runs':1024,'input_exact_evidence':exact,
        'versions':versions,'paired':paired,'bitwise_pairs':bitwise,'patterns':patterns,'trace_status_counts':dict(trace_counts),'geometry_results':geometry_checks,'geometry_unit_quality':qsummary,
        'main_receipt':mr,'toy_saved_evidence_pass':True,'audit_cpu_seconds_checkpoint':time.process_time()-START,
        'limits':['100% means 448/448 feasible calls in this frozen suite only; all-planned completion is 448/512.','There are 16 geometry blocks, not 1024 independent instances. D01 and D02 are deliberately tight fixtures.','DFS nodes are extra bounded work, not paid by the 5000 routing deltas. No equal-CPU or free-oracle claim.','Rescued original calls have no valid original cost, so baseline cost-reduction percentages are undefined.','Sub-millisecond process-time readings are quantized; 0.004010431 seconds is the recorded aggregate, not a precise standalone microbenchmark.','Seal times and hashes are internally consistent local evidence, not externally attested timestamps.','Recorded DFS node counts were checked against source accounting and fixed cap, not reproduced by rerunning the heuristic.','Exact audit uses IEEE doubles and tolerance, not certified interval arithmetic.']}
    (OUT/'INDEPENDENT_AUDIT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    report='''独立复核：PASS

只读复核原包，无 heuristic/原 oracle 重跑、无 API、无新实验候选、未修改原包。
1024/1024 记录齐全，16 geometry × 4需求 × 2搜索 × 2初始化 × 4seed；每版本分母512。
64输入均有独立 exact 或整数容量证据，56可行、8不可行；全部不可行来自预定随机D04。
原合法224/512，新448/512；在本套可行分母448上由224/448升至448/448。救活224，原成功丢失0，224对非计时solver完整载荷序列化字节一致。
D01/D02各救活112；D03低负载、D04随机不变；每版64个不可行calls没有输出或假阳性。
已核全部保存候选、初始解、最终解、current/best与失败回滚；全部实际插入δ在原5000内，失败/未完成输出未被当成低成本解。
原11个Python文件及1份旧toy证据字节一致。源码差异仅原InitFailure后的需求/Q/K容量分配及失败状态，生产节点限固定256，旧成功分支、repair/search/随机与箱内插入算式不变。
64个路由oracle在全部heuristic封存后评分，输入/配置白名单与源代码未发现oracle/reference泄漏。toy覆盖救活、真实packing不可行、node_limit1、两搜索旧成功不变、δ40截断无部分输出。
DFS 288次，9232节点，最大59；记录CPU合计0.004010431秒，时钟存在量化，不能当精确微基准。DFS节点额外列支；新增成功后的搜索成本不能都算成DFS纯开销，也不宣称等CPU/免费oracle。
主实验CPU10.296334秒、wall10.313158743秒；本独立审计另有receipt，限CPU20秒/wall40秒。
每geometry分母及四seed→需求单元→geometry等权质量统计已复算；救活项没有虚构原baseline或降本百分比。
100%只指本套448个可行calls，不能推广一般分布；16geometry才是区组层独立单位。
原ZIP SHA256保持：'''+EXPECTED_ZIP+'\n'
    (OUT/'REPORT_ZH.txt').write_text(report)
    print(json.dumps({'status':'PASS','runs':1024,'exact_inputs':64,'feasible_inputs':56,'old_legal':224,'new_legal':448,'paired':paired,'trace_counts':dict(trace_counts),'cpu_seconds_checkpoint':time.process_time()-START}))

if __name__=='__main__':main()
