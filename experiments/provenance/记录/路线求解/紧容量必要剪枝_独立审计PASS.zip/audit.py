import json,hashlib,math,ast,time,resource,signal,itertools,collections
from pathlib import Path
from functools import lru_cache
resource.setrlimit(resource.RLIMIT_CPU,(15,15));signal.alarm(30)
t0=time.perf_counter();c0=time.process_time()
R=Path('/workspace/shared/tight_capacity_pruning_20261008'); O=Path(__file__).parent
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before={str(p.relative_to(R)):sha(p) for p in R.rglob('*') if p.is_file() and p.suffix!='.zip'}
f=read(R/'freeze/PRE_RUN_FREEZE.json')
for p,h in f['sha256'].items():assert sha(R/p)==h,p
assert sha(R/'reports/TOYS.json')==f['toy_summary_sha256']
assert sha(R/'reports/PROOF_ZH.txt')==f['proof_sha256']
assert sha(R/'source/capacity_solver.py')==sha(Path('/workspace/shared/capacity_fallback_scaling_20261008/source/capacity_solver.py'))
a=(R/'source/capacity_solver.py').read_text();b=(R/'source/pruned_solver.py').read_text()
aa=ast.parse(a);bb=ast.parse(b)
for node in aa.body:
 if isinstance(node,(ast.FunctionDef,ast.ClassDef)) and node.name!='bounded_partition':
  other=next(x for x in bb.body if isinstance(x,type(node)) and x.name==node.name)
  assert ast.get_source_segment(a,node)==ast.get_source_segment(b,other)
assert b.index('nodes+=1')<b.index('blocked, tight, scanned =')
assert 'CAPACITY_NODE_LIMIT = 256' in a and 'CAPACITY_NODE_LIMIT = 256' in b
run=(R/'source/run.py').read_text();assert "Budget(100000,30,60)" in run
assert "path.startswith(('source/','input/','freeze/'))" in run
rows=[json.loads(s) for s in (R/'raw/results.jsonl').read_text().splitlines()]
sched=read(R/'freeze/SCHEDULE.json');assert len(rows)==len(sched)==72
assert [{k:r[k] for k in ['instance_id','arm']} for r in rows]==sched
assert len({(r['instance_id'],r['arm']) for r in rows})==72
assert sha(R/'raw/results.jsonl')==read(R/'raw/FINISHED.json')['results_sha256']
assert f['utc']<read(R/'raw/STARTED.json')['utc']<read(R/'raw/FINISHED.json')['utc']
counts=collections.Counter(); groups=collections.defaultdict(list);valid=0;traces=0
for r in rows:
 raw=read(R/'input'/(r['instance_id']+'.json'));assert sha(R/'input'/(r['instance_id']+'.json'))==r['input_sha256']
 assert r['deltas']<=100000 and r['status'] in ['SUCCESS','INITFAIL']
 counts[r['arm'],r['status']]+=1;groups[r['n'],r['family'],r['arm']].append(r)
 d=r['initialization'].get('capacity_partition');dem=raw['demands'];K=raw['K'];Q=raw['capacity']
 if d:
  assert 0<d['nodes']<=256 and d['node_limit']==256 and not d['mathematical_infeasibility_claim']
  if r['status']=='INITFAIL':assert d['nodes']==256 and d['limit_reached'] and r['output'] is None
  if 'prunes' in d:
   assert d['prunes']==len(d['prune_trace']);assert d['guard_checks']==d['nodes']-1
   last=0
   for tr in d['prune_trace']:
    traces+=1;assert last<tr['entered_node']<=d['nodes'];last=tr['entered_node']
    assert len(tr['residual'])==len(tr['groups'])==K
    flat=[j for g in tr['groups'] for j in g];assert len(flat)==len(set(flat))==tr['depth']
    assert sorted(flat)==sorted(sorted(range(1,len(dem)),key=lambda j:(-dem[j],j))[:tr['depth']])
    assert tr['remaining']==[dem[j] for j in sorted(range(1,len(dem)),key=lambda j:(-dem[j],j))[tr['depth']:]]
    assert tr['residual']==[Q-sum(dem[j] for j in g) for g in tr['groups']]
    assert sum(tr['remaining'])==sum(tr['residual']) and any(0<s<min(tr['remaining']) for s in tr['residual'])
 if r['status']=='SUCCESS':
  out=r['output'];rr=out['routes'];assert len(rr)<=K
  assert all(rt[0]==rt[-1]==0 for rt in rr)
  assert sorted(j for rt in rr for j in rt[1:-1])==list(range(1,len(dem)))
  assert all(sum(dem[j] for j in rt[1:-1])<=Q for rt in rr)
  xy=raw['coordinates'];cost=sum(math.dist(xy[u],xy[v]) for rt in rr for u,v in zip(rt,rt[1:]))
  assert math.isclose(cost,out['reported_cost'],rel_tol=1e-12,abs_tol=1e-8);valid+=1
assert valid==64 and counts['capacity_solver','SUCCESS']==28 and counts['pruned_solver','SUCCESS']==36
# Non-timing comparisons preserve every bypassed result field except arm identity.
def clean(x):
 if isinstance(x,dict):return {k:clean(v) for k,v in x.items() if k!='arm' and not k.endswith('_seconds')}
 if isinstance(x,list):return [clean(v) for v in x]
 return x
pairs={};bypass=0;old_dfs=[]
for ident in sorted({r['instance_id'] for r in rows}):
 p={r['arm']:r for r in rows if r['instance_id']==ident};x=p['capacity_solver'];y=p['pruned_solver']
 if 'capacity_partition' not in x['initialization']:
  assert clean(x)==clean(y);bypass+=1
 elif x['status']=='SUCCESS':
  dx=x['initialization']['capacity_partition'];dy=y['initialization']['capacity_partition']
  assert x['output']==y['output'] and dx['groups']==dy['groups'] and x['deltas']==y['deltas']
  old_dfs.append({'instance_id':ident,'baseline_nodes':dx['nodes'],'pruned_nodes':dy['nodes'],'prunes':dy['prunes'],'groups_routes_cost_equal':True})
assert bypass==25 and len(old_dfs)==3
# Independent, bounded feasibility check of recorded small states; never executes submitted solver.
@lru_cache(None)
def feasible(ds,rs):
 if not ds:return True
 return any(ds[0]<=v and feasible(ds[1:],rs[:i]+(v-ds[0],)+rs[i+1:]) for i,v in enumerate(rs))
toycounts=collections.Counter(); seen=set()
for line in (R/'reports/toy_states.jsonl').read_text().splitlines():
 q,k,ds,rs,truth,flag=json.loads(line);key=(q,k,tuple(ds),tuple(rs));assert key not in seen;seen.add(key)
 assert truth==feasible(tuple(ds),tuple(rs))
 calc=bool(ds) and sum(ds)==sum(rs) and any(0<v<min(ds) for v in rs)
 assert flag==calc and not(flag and truth);toycounts['zero' if q=='zero_edge' else 'positive']+=1
assert dict(toycounts)=={'positive':30203,'zero':2380}
toys=read(R/'reports/TOYS.json');assert toys['initial_problem_comparisons']==2373 and toys['unsafe_prunes']==0
assert sum(math.comb(Q+n-1,n) for Q in range(1,6) for K in range(1,4) for n in range(7))==2373
assert sha(R/'reports/toy_states.jsonl')==toys['state_trace_sha256']
summary=[]
for (n,fam,arm),rr in sorted(groups.items()):
 cp=[r['initialization'].get('capacity_partition',{}) for r in rr]
 summary.append({'n':n,'family':fam,'arm':arm,'calls':len(rr),'success':sum(r['status']=='SUCCESS' for r in rr),'DFS_calls':sum(bool(x) for x in cp),'nodes':[x.get('nodes',0) for x in cp],'prunes':sum(x.get('prunes',0) for x in cp),'deltas_sum':sum(r['deltas'] for r in rr)})
 if fam!='tight':assert not any(cp)
assert all(sha(R/p)==h for p,h in before.items())
result={'passed':True,'scope':'read-only record verification and bounded independent toy states; no initializer or submitted search rerun','calls':72,'successful_outputs_validated':valid,'baseline_success':28,'pruned_success':36,'bypass_full_non_timing_equal':bypass,'old_DFS_success_comparisons':old_dfs,'pruned_states_validated':traces,'toy_states_independent':dict(toycounts),'initial_problem_2373':'author source, summary, cardinality and receipt checked; not independently rerun','groups':summary,'freeze_files_verified':len(f['sha256']),'source_snapshot_sha256':before,'main_receipt':read(R/'receipts/main.json')}
(O/'AUDIT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
receipt={'cpu_seconds':time.process_time()-c0,'wall_seconds':time.perf_counter()-t0,'cpu_limit':15,'wall_limit':30,'source_unchanged':True,'main_initializer_search_runs':0,'passed':True}
(O/'RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));print('PASS: 72 calls, 64 outputs, 32583 independent toy states')
