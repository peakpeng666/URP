from pathlib import Path
import json,hashlib,zipfile,time,resource,signal
resource.setrlimit(resource.RLIMIT_CPU,(15,15));signal.alarm(30)
c=time.process_time();t=time.perf_counter()
R=Path('/workspace/shared/tight_capacity_pruning_20261008');O=Path(__file__).parent
z=R/'tight_capacity_pruning_20261008.zip';h=hashlib.sha256(z.read_bytes()).hexdigest();assert h=='03431dbabd04275dafadd68e793658dc3cfddd766bf00e6f9cb73881d2a42f7e'
with zipfile.ZipFile(z) as f:
 assert f.testzip() is None
 for n in f.namelist():assert f.read(n)==(R/n).read_bytes(),n
 n=len(f.namelist())
a=json.loads((O/'AUDIT.json').read_text())
for p,h0 in a['source_snapshot_sha256'].items():assert hashlib.sha256((R/p).read_bytes()).hexdigest()==h0,p
(O/'SEAL.json').write_text(json.dumps({'author_archive_sha256':h,'archive_entries_verified':n,'author_source_snapshot_unchanged':True,'cpu_seconds':time.process_time()-c,'wall_seconds':time.perf_counter()-t,'passed':True},indent=2)+'\n')
out=O.with_suffix('.zip')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as f:
 for p in sorted(O.iterdir()):
  if p.is_file():f.write(p,p.name)
print(out);print(hashlib.sha256(out.read_bytes()).hexdigest());print((O/'SEAL.json').read_text())
