import json,hashlib,zipfile,pathlib,math,collections,random,ast,time,resource,signal,datetime
T=time.perf_counter(); C=time.process_time()
resource.setrlimit(resource.RLIMIT_CPU,(10,10));signal.alarm(20)
ROOT=pathlib.Path('/workspace/shared/capacity_fallback_scaling_20261008')
OUT=pathlib.Path(__file__).resolve().parent
EXPECTED='251e54a6b8840ea9c23ae60c95d05d77aa933d3ef2cb4a50ecff67df6db550ae'
def h(b):return hashlib.sha256(b).hexdigest()
def digest(x):return h(json.dumps(x,separators=(',',':'),allow_nan=False).encode())
archive=ROOT/'capacity_fallback_scaling_20261008.zip';assert h(archive.read_bytes())==EXPECTED
z=zipfile.ZipFile(archive);assert z.testzip() is None
prefix=ROOT.name+'/'
assert all(n.startswith(prefix) and '..' not in pathlib.PurePosixPath(n).parts for n in z.namelist())
B={n[len(prefix):]:z.read(n) for n in z.namelist() if not n.endswith('/')}
assert len(B)==len(z.namelist())
def j(n):return json.loads(B[n])
for name,b in B.items():assert (ROOT/name).read_bytes()==b,name
manifest={line.split('  ',1)[1]:line.split('  ',1)[0] for line in B['SHA256SUMS.txt'].decode().splitlines()}
assert set(manifest)==set(B)-{'SHA256SUMS.txt'}
for name,sha in manifest.items():assert h(B[name])==sha,name
freeze=j('freeze/PRE_RUN_FREEZE.json')
for name,sha in freeze['sha256'].items():assert h(B[name])==sha,name
for name in B:
 if name.startswith(('source/','input/','witness/','provenance/')):assert name in freeze['sha256'],name
protocol=j('freeze/PRE_GENERATION.json');started=j('raw/STARTED.json');finished=j('raw/FINISHED.json')
assert started['freeze_sha256']==h(B['freeze/PRE_RUN_FREEZE.json'])
assert protocol['utc']<freeze['utc']<started['utc']<finished['utc']
assert finished['results_sha256']==h(B['raw/results.jsonl'])
assert finished['calls']==72 and finished['local_search_calls']==finished['oracle_calls']==0
assert protocol['dfs_nodes']==256 and protocol['delta_limit']==100000
assert protocol['n']==[9,27,54] and protocol['replicates']==4
inputs={pathlib.Path(name).stem:j(name) for name in B if name.startswith('input/')}
assert len(inputs)==36
geometries=j('freeze/GEOMETRY_MANIFEST.json');assert len(geometries)==36
old=j('provenance/OLD_GEOMETRY_HASHES.json'); oo=set(old['ordered_hashes']);ou=set(old.get('unordered_hashes',[]))
for g in j('provenance/GEOMETRY_MANIFEST.json'):oo.add(g['coordinates_sha256']);ou.add(g['unordered_coordinates_sha256'])
for g in geometries:
 raw=inputs[g['instance_id']];n=raw['n'];family=raw['family'];rep=raw['replicate']-1
 seed=protocol['base_seed']+10000*n+100*protocol['families'].index(family)+rep
 rng=random.Random(seed);xy=[[rng.uniform(0,100),rng.uniform(0,100)] for _ in range(n+1)]
 assert raw['coordinates']==xy and g['geometry_seed']==seed
 assert g['coordinates_sha256']==digest(xy) not in oo
 assert g['unordered_coordinates_sha256']==digest(sorted(xy)) not in ou
 assert raw['capacity']==9 and raw['K']==n//3
 if family=='tight':d=[4,4,4,3,3,3,2,2,2]*(n//9)
 elif family=='feasible_random':dr=random.Random(seed+100000000);d=[dr.randint(1,3) for _ in range(n)]
 else:assert family=='loose';d=[1]*n
 perm=list(range(1,n+1));random.Random(seed+200000000).shuffle(perm);dem=[0]*(n+1)
 for a,b in enumerate(perm):dem[b]=d[a]
 assert raw['demands']==dem
assert len({g['coordinates_sha256'] for g in geometries})==36
upstream=pathlib.Path('/workspace/shared/capacity_partition_fallback_20261008')
core=j('provenance/CORE_BYTE_CHECK.json')
for p in core:
 name=p['file'];assert h(B[name])==p['upstream_sha256']==p['copied_sha256'];assert (upstream/name).read_bytes()==B[name]
run=ast.parse(B['source/run.py']);calls=[]
for node in ast.walk(run):
 if isinstance(node,ast.Call):calls.append(ast.unparse(node.func))
assert 'mod.initialize' in calls and 'mod.run_one' not in calls and 'read' in calls
assert not any('oracle' in c or 'destroy' in c or 'repair' in c or 'witness' in c for c in calls)
assert "CAPACITY_NODE_LIMIT = 256" in B['source/capacity_solver.py'].decode()
assert "hashlib.sha256(Path(p).read_bytes())" in B['source/common.py'].decode()
assert "raw=read(ROOT/'input'" in B['source/run.py'].decode()
assert "'witness'" not in B['source/run.py'].decode()
rows=[json.loads(s) for s in B['raw/results.jsonl'].splitlines()];schedule=j('freeze/SCHEDULE.json')
assert len(rows)==len(schedule)==72
assert [(r['instance_id'],r['arm']) for r in rows]==[(r['instance_id'],r['arm']) for r in schedule]
assert len({(r['instance_id'],r['arm']) for r in rows})==72
assert set((i,a) for i in inputs for a in ['fixed_solver','capacity_solver'])==set((r['instance_id'],r['arm']) for r in rows)
checks=[];cell={};dfs=[];failures=collections.Counter();success=collections.Counter()
for r in rows:
 raw=inputs[r['instance_id']];assert r['input_sha256']==h(B['input/'+r['instance_id']+'.json'])
 assert r['n']==raw['n'] and r['family']==raw['family']
 assert r['deltas']==sum(r['delta_by_kind'].values())<=100000
 assert r['delta_by_kind']['removal']==0
 assert r['delta_by_kind']['savings']==raw['n']*(raw['n']-1)//2
 key=(r['n'],r['family'],r['arm']);g=cell.setdefault(key,{'n':key[0],'family':key[1],'arm':key[2],'calls':0,'success':0,'INITFAIL':0,'BUDGET':0,'ERROR':0,'DFS_calls':0,'DFS_nodes':[],'DFS_outcomes':{},'stops':{},'deltas_total':0,'cpu_total':0.,'wall_total':0.})
 g['calls']+=1;g['success' if r['status']=='SUCCESS' else r['status']]+=1;g['deltas_total']+=r['deltas'];g['cpu_total']+=r['cpu_seconds'];g['wall_total']+=r['wall_seconds'];g['stops'][r['stop_reason']]=g['stops'].get(r['stop_reason'],0)+1
 diag=r['initialization'];d=diag.get('capacity_partition')
 if d:
  dfs.append(d);assert r['arm']=='capacity_solver' and d['node_limit']==256 and d['nodes']<=256 and not d['mathematical_infeasibility_claim']
  assert diag['original_ffd_failure']=='ffd_capacity_construction_failed'
  g['DFS_calls']+=1;g['DFS_nodes'].append(d['nodes']);g['DFS_outcomes'][d['outcome']]=g['DFS_outcomes'].get(d['outcome'],0)+1
 if r['status']=='SUCCESS':
  output=r['output'];routes=output['routes'];assert 0<len(routes)<=raw['K'];flat=[];loads=[];cost=0.
  for route in routes:
   assert len(route)>=3 and route[0]==route[-1]==0
   assert all(type(v)==int and 1<=v<=raw['n'] for v in route[1:-1])
   flat.extend(route[1:-1]);load=sum(raw['demands'][v] for v in route[1:-1]);assert load<=raw['capacity'];loads.append(load)
   cost+=sum(math.dist(raw['coordinates'][a],raw['coordinates'][b]) for a,b in zip(route,route[1:]))
  assert sorted(flat)==list(range(1,raw['n']+1))
  assert math.isfinite(output['reported_cost']) and math.isclose(cost,output['reported_cost'],rel_tol=1e-10,abs_tol=1e-8)
  assert r['error_type'] is None and r['stop_reason']=='initialization_complete'
  checks.append({'instance_id':r['instance_id'],'arm':r['arm'],'coverage_capacity_K_cost':True,'recomputed_cost':cost});success[r['arm']]+=1
 else:
  assert r['status']=='INITFAIL' and r['output'] is None
  if r['arm']=='fixed_solver':assert r['error_type']=='InitFailure' and r['stop_reason']=='ffd_capacity_construction_failed'
  else:assert r['error_type']=='ConstructionFailure' and r['stop_reason']=='capacity_partition_construction_failed' and d['outcome']=='NODE_LIMIT'
  failures[r['stop_reason']]+=1
assert len(checks)==53 and success=={'fixed_solver':25,'capacity_solver':28}
assert failures=={'ffd_capacity_construction_failed':11,'capacity_partition_construction_failed':8}
assert collections.Counter((d['nodes'],d['outcome'],d['limit_reached']) for d in dfs)=={(59,'FOUND',False):3,(256,'NODE_LIMIT',True):8}
assert list(cell.values())==j('reports/SUMMARY.json')
for i in range(0,72,2):
 old,new=rows[i:i+2]
 if old['status']=='SUCCESS':assert old['output']==new['output'] and old['deltas']==new['deltas']
for ident,raw in inputs.items():
 groups=j('witness/'+ident+'.json')['groups'];assert 0<len(groups)<=raw['K']
 assert sorted(v for g in groups for v in g)==list(range(1,raw['n']+1))
 assert all(g and sum(raw['demands'][v] for v in g)<=raw['capacity'] for g in groups)
prep=j('receipts/prepare.json');recovery=j('receipts/finish_prepare.json');main=j('receipts/main.json')
assert prep['exit_code']==1 and recovery['exit_code']==main['exit_code']==0
assert prep['utc']<recovery['utc']<started['utc']
assert 'AssertionError' in B['receipts/prepare.stderr.log'].decode()
assert j('receipts/PREPARATION_RECOVERY.json')['regenerated_inputs']==0
assert "dump(ROOT/'input'" not in B['source/finish_prepare.py'].decode()
assert main['complete'] and main['no_retry'] and not main['wall_limit_kill']
assert main['total_cpu_seconds']==0.161972 and main['elapsed_wall_seconds']<.164
assert main['cpu_hard_limit_seconds']==30 and main['wall_limit_seconds']==60
pack=json.loads(pathlib.Path('/workspace/shared/capacity_fallback_scaling_20261008_packaging_receipt.json').read_text())
result={'结论':'通过（附证据边界）','原包SHA256':EXPECTED,'原包字节':archive.stat().st_size,'核验文件数':len(B),'冻结文件数':len(freeze['sha256']),'继承源码字节一致数':len(core),'输入数':36,'调用数':72,'成功输出独立验算数':53,'成功':dict(success),'失败':dict(failures),'DFS':'3次59节点成功；8次256节点截断','全36见证可行':True,'每格统计与报告一致':True,'准备失败与主跑区分':True,'主跑CPU秒':main['total_cpu_seconds'],'主跑wall秒':main['elapsed_wall_seconds'],'见证隔离':'主跑仅读取见证字节做SHA256，不反序列化或提供给候选；FINISHED witness_read=false不是OS层未读','证据边界':['未重跑任何initializer、DFS、search或oracle。重新推导输入只在审计内存中逐项匹配，不写原数据。','唯一主跑/无重抽样由本地源码、独占创建保护、时间戳、收据和封存链支持；非外部可信时间证明。','tight与既知失败机制关联，不是现实农业抽样。n27/54两臂tight均0/4，8次截断不等于数学不可行。','其余六格两臂均4/4，只限本样本；每格4个几何，不外推100%成功率或规模可扩展。'],'每格':list(cell.values())}
(OUT/'AUDIT_ZH.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
(OUT/'OUTPUT_CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n')
(OUT/'packaging_receipt_source.json').write_text(json.dumps(pack,indent=2)+'\n')
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'audit_cpu_seconds':time.process_time()-C,'audit_wall_seconds':time.perf_counter()-T,'cpu_limit_seconds':10,'wall_alarm_seconds':20,'original_files_mutated':False,'initializer_search_calls':0,'status':'PASS'}
(OUT/'AUDIT_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'status':'PASS','calls':72,'success':dict(success),'valid_outputs':len(checks),'receipt':receipt},ensure_ascii=False))
