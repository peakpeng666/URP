# 成熟求解器档案适配：独立审计结论

结论：当前后端代码通过本审计范围内的真实资料与边界验证。初审发现的四项语义/计数缺口已经复核修复，没有剩余阻断项。审计未改实现、旧基线或原始实验档案。

## 真实资料验证

使用全新独立 SQLite 数据库，导入旧五实验包、旧 VRPTW 240 runs、新成熟求解器96 runs。没有复用开发者的 early.sqlite3 作为最终验收数据库。

- 1089 个真实 127.0.0.1 HTTP 请求，336 条路线记录，672 次车辆接口读取
- 独立逐站算术核对1961站，其中新档462站；使用 math.hypot 自行计算各站距离、到达、等待、开始/结束服务、迟到、累计服务需求、回仓距离/时刻
- 与API总距离最大误差 1.4210854715202004e-14
- 新档两预算各48 runs：每档33合法全服务、15未返回候选，共66/30；96个原生run ID及原始行SHA逐项核对，无预算碰撞
- 旧档状态保留137 feasible、53 partial、35 invalid、15 infeasible
- 56个附件HTTP下载逐字节SHA核对，包括旧五包28、旧路线9、新路线19；此数校正此前口头进展中的57
- 跨档比较336行、48份共同输入引用、7个算法/预算组；非全服务结果的full_service_distance及排名差值均为null
- 累计已服务需求与物理车载载荷分开，onboard_load均为null；整数cumul范围保留原值，明确不是观测/连续到达时刻
- 旧同口径指标比较成功；旧跨预算严格比较409。新路线比较是明确分组的描述性比较；单预算子集same_known_budget=true、跨预算false，未改成公平算力/显著性结论
- 新只读端点POST为405；原格式与成熟格式不能复用对方实验ID覆盖；同档重导入幂等
- 旧基线与所读取的原始档案文件在审计前后SHA相同

## 独立边界验证（18项通过）

1. 参考时间窗语义不兼容，即使更新其哈希，仍拒绝
2. enriched/map同时篡改gap仍拒绝
3. 输入身份哈希不匹配拒绝
4. 冻结protocol原字节不匹配拒绝
5. raw/evaluated/map同时篡改已记录到达时间仍被连续回放拒绝
6. 参考oracle的不可行标签与新合法全服务见证冲突拒绝
7. 参考oracle目标与路线算术不符拒绝
8. 对参考可行实例的ROUTING_FAIL保留no_solution，不推断infeasible/invalid
9. 对参考可行实例的timeout同样保留no_solution
10. 对参考可行实例的error保留unknown/failed和错误内容
11. checker拒绝但路线自身合法且部分服务，保留partial
12. checker拒绝且存在约束违反，保留invalid
13. 不同problem spec在实际HTTP比较被409拒绝
14. 数值相同但不同原输入字节哈希在实际HTTP比较被409拒绝
15. 重复resolved实验/版本被400拒绝，避免重复计数
16. 单成熟实验可比较其两预算，共96条48输入
17. 合成单预算子集明确same_known_budget=true
18. 合成跨预算子集明确same_known_budget=false

预算子集及错误场景只在临时目录/内存中构造用于接口测试，不是新增实验结果。未执行来源checker.py、任何求解器或任何模型API。

## 初审发现与关闭

- 未校验参考time_window_semantics：已增加明确合同校验，并用不同语义反例复核。
- 重复experiment/revision重复计数：已按resolved identity拒绝重复；支持单实验多预算查询。
- gap仅照抄enriched证据：已按连续回放距离和参考目标计算并核对。
- oracle标签可与新可行见证矛盾：已验证参考oracle的路线/audit/目标合同，重新回放参考可行见证；新合法全解与参考不可行标签直接拒绝。

另直接运行工程全部离线单元测试：41项通过。该结论对应以下证据中的实现哈希。

## 证据与复现

- real_http_final.json：真实资料审计结构化报告、实现及原始文件SHA、计数
- http_requests_final.jsonl：1089条HTTP响应状态及响应体哈希
- real_http_final.sqlite3：本次新建的独立验收数据库，仅本地审计用，不应提交源码仓库
- adversarial_final.json：18项边界验证结果及实现SHA
- unit_tests_final.log：41项离线单元测试日志
- legacy_fingerprint_final.json：旧基线/新实现对原240条导入fingerprint完全相同
- audit_real_http.py / audit_adversarial.py：独立验收程序

在目标research_console目录运行：

    python3 ../independent_audit/audit_real_http.py --label NEW_UNIQUE_LABEL
    python3 ../independent_audit/audit_adversarial.py adversarial_NEW_LABEL.json
    python3 -m unittest discover -s tests -p 'test_*.py' -v

程序路径是本dot云端的当前任务路径；旧五包路径需要真实资料。真实验收要求数据库路径此前不存在。中间的adversarial_intermediate_harness_error.json是一次审计预期错误码遗漏reference_conflict造成的误报，已修正审计预期并由adversarial_final.json取代，未被算作通过。

## 范围边界

本审计验证归档读取、一致性、HTTP契约、连续路线见证算术和比较边界；不重新运行求解器，不重新穷举最优性或不可行性证明，不作统计显著性或通用优势结论。参考oracle标签仍来自已有档案。没有浏览器视觉测试、UI接线测试、部署、push、上传或账号操作。最后已阅读 docs/MATURE_ROUTE_API.md 并与实现/验收证据对照，未发现实质不符；其语义、预算、来源及非目标边界均明确。原旧路线240条的导入fingerprint也以原基线代码独立导入后确认完全一致，见 legacy_fingerprint_final.json。
