"""Independent mutation and boundary audit. Only copied/in-memory archive data is changed."""
import copy, hashlib, http.client, json, sys, tempfile, threading
from pathlib import Path
ROOT=Path('/workspace/shared/panel_route_mature_backend_20261007/research_console');sys.path.insert(0,str(ROOT))
from backend.store import Store,StoreError
from backend.mature_routes import FILES,normalize_mature,import_mature
from backend.routes import import_vrptw
from backend.server import make_server
OUT=ROOT.parent/'independent_audit';SRC=Path('/workspace/shared/vrptw_mature_solver_20261007');OLD=Path('/workspace/shared/vrp_time_windows_20261007')
BASE={n:(SRC/n).read_bytes() for n in FILES};sha=lambda b:hashlib.sha256(b).hexdigest();observations=[]
def obj(b,n):return json.loads(b[n])
def save(b,n,d):b[n]=json.dumps(d).encode()
def frozen(b,n,reference=False):
    freeze='reference/freeze.json' if reference else 'freeze.json';d=obj(b,freeze);d['sha256'][n.removeprefix('reference/') if reference else n]=sha(b[n]);save(b,freeze,d)
def rows(b,n):return [json.loads(x) for x in b[n].splitlines()]
def saverows(b,n,rs):b[n]=(''.join(json.dumps(r)+'\n' for r in rs)).encode()
def change_result(b,rid,changes):
    rs=rows(b,'results.jsonl');ev=obj(b,'evaluated_results.json');mp=obj(b,'map_backend.json')
    for seq in [rs,ev,*[x['runs'] for x in mp['instances']]]:
        for r in seq:
            if r['run_id']==rid:r.update(copy.deepcopy(changes))
    saverows(b,'results.jsonl',rs);save(b,'evaluated_results.json',ev);save(b,'map_backend.json',mp)
def change_enriched(b,instance,changes):
    ev=obj(b,'evaluated_results.json');mp=obj(b,'map_backend.json')
    for seq in [ev,*[x['runs'] for x in mp['instances']]]:
        for r in seq:
            if r['instance']==instance:r.update(copy.deepcopy(changes))
    save(b,'evaluated_results.json',ev);save(b,'map_backend.json',mp)
def check_rejected(name,mutate,expected):
    b=copy.deepcopy(BASE);mutate(b)
    try:normalize_mature(b)
    except StoreError as e:observations.append({'case':name,'expected':expected,'observed_error':e.code,'status':'PASS' if e.code in expected else 'FAIL'})
    except Exception as e:observations.append({'case':name,'expected':expected,'unexpected_exception':type(e).__name__,'message':str(e),'status':'FAIL'})
    else:observations.append({'case':name,'expected':expected,'observed':'accepted','status':'FAIL'})
def time_semantics(b):
    p=obj(b,'reference/protocol.json');p['input']['time_window_semantics']='ARRIVAL only; waiting disallowed';save(b,'reference/protocol.json',p);frozen(b,'reference/protocol.json',True)
def enriched_gap(b):change_enriched(b,'G01_medium',{'full_gap_original_percent':987654321})
def input_digest(b):
    m=obj(b,'map_backend.json');m['source_input_sha256']='0'*64;save(b,'map_backend.json',m)
def protocol_frozen(b):b['protocol.json']+=b' '
def saved_arrival(b):
    r=next(r for r in rows(b,'results.jsonl') if r['outcome']=='find');a=copy.deepcopy(r['audit']);a['schedules'][0]['stops'][0]['arrival']+=1;change_result(b,r['run_id'],{'audit':a})
def oracle_conflict(b,keep_witness=False):
    rr=rows(b,'reference/routes.jsonl')
    for row in rr:
        if row['instance']=='G01_medium' and row['method']=='oracle_full':
            row.update(status='proven_infeasible',full_oracle_objective=None)
            if not keep_witness:row.update(routes=None,audit=None)
    saverows(b,'reference/routes.jsonl',rr);change_enriched(b,'G01_medium',{'reference_oracle_full_feasible':False,'full_gap_original_percent':None})
    mp=obj(b,'map_backend.json')
    for instance in mp['instances']:
        if instance['input']['id']=='G01_medium':instance['reference_oracle_full_feasible']=False
    save(b,'map_backend.json',mp)
def zero_objective(b):
    rr=rows(b,'reference/routes.jsonl')
    for row in rr:
        if row['instance']=='G01_medium' and row['method']=='oracle_full':row['full_oracle_objective']=0
    saverows(b,'reference/routes.jsonl',rr)
def check_no_candidate(name,outcome,status,name_status,error=None):
    b=copy.deepcopy(BASE);rid='G01_medium__250ms';changes={'routes':None,'audit':None,'assignment_returned':False,'outcome':outcome,'ortools_status':status,'ortools_status_name':name_status,'objective_integer':None,'encoded_cumul_ranges':None}
    if error is not None:changes['error']=error
    change_result(b,rid,changes);ev=obj(b,'evaluated_results.json');mp=obj(b,'map_backend.json')
    for r in ev:
        if r['run_id']==rid:r['full_gap_original_percent']=None
    for item in mp['instances']:
        for r in item['runs']:
            if r['run_id']==rid:r['full_gap_original_percent']=None
    save(b,'evaluated_results.json',ev);save(b,'map_backend.json',mp)
    v=obj(b,'verification.json');v['returned_solutions_independently_replayed']-=1;save(b,'verification.json',v)
    try:
        r=normalize_mature(b)['runs'][rid];wanted='unknown' if outcome=='error' else 'no_solution'
        assert r['solution_status']==wanted;assert r['problem_feasibility']['status']=='feasible';assert r['unserved_task_ids'] is None;assert r['vehicles']==[];assert r['checker']['audit'] is None;assert not r['full_service_success'];assert r['solver_error']==error
        assert r['execution_status']==('failed' if outcome=='error' else 'completed')
        observations.append({'case':name,'status':'PASS','solution_status':r['solution_status'],'problem_feasibility':'feasible','candidate_missing_null':True})
    except Exception as e:observations.append({'case':name,'status':'FAIL','exception':str(e)})

def check_rejected_witness(kind):
    b=copy.deepcopy(BASE);old=[json.loads(x) for x in (OLD/'routes.jsonl').read_bytes().splitlines()]
    target=next(r for r in old if r['audit'] and r['full_oracle_objective'] is not None and not r['audit']['full_service_feasible'] and (r['audit']['route_feasible']==(kind=='partial')))
    rid=target['instance']+'__250ms';change_result(b,rid,{'routes':target['routes'],'audit':target['audit'],'outcome':'find_but_checker_rejected','assignment_returned':True})
    ev=obj(b,'evaluated_results.json');mp=obj(b,'map_backend.json')
    for seq in [ev,*[x['runs'] for x in mp['instances']]]:
        for r in seq:
            if r['run_id']==rid:r['full_gap_original_percent']=None
    save(b,'evaluated_results.json',ev);save(b,'map_backend.json',mp)
    try:
        r=normalize_mature(b)['runs'][rid];assert r['solution_status']==kind;assert not r['full_service_success'];assert r['metrics']['full_gap_original_percent'] is None;assert r['problem_feasibility']['status']=='feasible'
        observations.append({'case':'checker_rejected_'+kind,'status':'PASS','source_witness_instance':target['instance'],'solution_status':r['solution_status'],'problem_feasibility':'feasible'})
    except Exception as e:observations.append({'case':'checker_rejected_'+kind,'status':'FAIL','exception':str(e)})

def changed_spec(b):
    p=obj(b,'reference/protocol.json');p['study_id']+='-INDEPENDENT-AUDIT-DIFFERENT-SPEC';save(b,'reference/protocol.json',p);frozen(b,'reference/protocol.json',True)
def changed_input_bytes(b):
    b['inputs.json']+=b' ';b['reference/inputs.json']=b['inputs.json'];h=sha(b['inputs.json']);frozen(b,'inputs.json');frozen(b,'reference/inputs.json',True)
    for filename,key in [('verification.json','original_input_sha256'),('map_backend.json','source_input_sha256')]:d=obj(b,filename);d[key]=h;save(b,filename,d)
def one_budget_only(b,budget):
    selected=[r for r in rows(b,'results.jsonl') if r['budget_ms']==budget]
    saverows(b,'results.jsonl',selected);save(b,'evaluated_results.json',[r for r in obj(b,'evaluated_results.json') if r['budget_ms']==budget]);save(b,'requests.json',[r for r in obj(b,'requests.json') if r['budget_ms']==budget]);frozen(b,'requests.json')
    m=obj(b,'map_backend.json')
    for item in m['instances']:item['runs']=[r for r in item['runs'] if r['budget_ms']==budget]
    save(b,'map_backend.json',m);v=obj(b,'verification.json');v['records_checked']=len(selected);v['returned_solutions_independently_replayed']=sum(r['routes'] is not None for r in selected);save(b,'verification.json',v)

def boundary_http():
    with tempfile.TemporaryDirectory(prefix='mature-independent-mutations-') as temp:
        root=Path(temp);store=Store(root/'fresh.sqlite3');import_vrptw(store,OLD,'old');import_mature(store,SRC,'mature')
        for name,mutation in [('different-spec',changed_spec),('different-input-bytes',changed_input_bytes),('synthetic-250',lambda b:one_budget_only(b,250)),('synthetic-1000',lambda b:one_budget_only(b,1000))]:
            b=copy.deepcopy(BASE);mutation(b);dest=root/name
            for n,data in b.items():p=dest/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
            import_mature(store,dest,name)
        server=make_server(store,root,0);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        try:
            cases=[('different-spec','/api/route-comparison?experiments=old,different-spec',409,'incomparable_route_problem'),('different-input-bytes','/api/route-comparison?experiments=old,different-input-bytes',409,'incomparable_route_problem'),('duplicate-latest-explicit-revision','/api/route-comparison?experiments=mature,mature&revisions=1,1',400,'duplicate_comparison_selection'),('single-mature-two-budgets','/api/route-comparison?experiments=mature',200,None)]
            for name,url,wanted,error in cases:
                c=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=10);c.request('GET',url);response=c.getresponse();data=json.loads(response.read());code=response.status;c.close();success=code==wanted and (data.get('error')==error if error else data['row_count']==96 and data['unique_input_count']==48 and len(data['groups'])==2 and not data['same_known_budget']);observations.append({'case':name,'transport':'actual loopback HTTP','status':'PASS' if success else 'FAIL','http_status':code,'error':data.get('error')})
            for name,url,same in [('same-known-budget','/api/route-comparison?experiments=synthetic-250',True),('cross-known-budgets','/api/route-comparison?experiments=synthetic-250,synthetic-1000',False)]:
                c=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=10);c.request('GET',url);r=c.getresponse();d=json.loads(r.read());code=r.status;c.close();success=code==200 and d['same_known_budget'] is same and d['unique_input_count']==48 and d['row_count']==(48 if same else 96);observations.append({'case':name,'transport':'actual loopback HTTP; synthetic budget subsets only','status':'PASS' if success else 'FAIL','http_status':code,'same_known_budget':d.get('same_known_budget')})
        finally:server.shutdown();server.server_close();thread.join()

if __name__=='__main__':
    for name,mutation,error in [('time_semantics',time_semantics,['unsupported_route_semantics']),('enriched_gap',enriched_gap,['replay_mismatch']),('input_hash_mismatch',input_digest,['input_hash_mismatch']),('frozen_protocol_mismatch',protocol_frozen,['frozen_hash_mismatch']),('recorded_arrival_tampered',saved_arrival,['replay_mismatch']),('oracle_infeasible_vs_new_full_witness',oracle_conflict,['source_mismatch','invalid_reference','invalid_run_status','reference_conflict']),('oracle_invalid_zero_objective',zero_objective,['invalid_reference','source_mismatch','replay_mismatch','invalid_route_source'])]:check_rejected(name,mutation,error)
    check_no_candidate('FAIL_on_reference_feasible','no_solution_in_budget',3,'ROUTING_FAIL')
    check_no_candidate('timeout_on_reference_feasible','fail_timeout',4,'ROUTING_FAIL_TIMEOUT')
    check_no_candidate('error_on_reference_feasible','error',None,None,'Synthetic test error only')
    check_rejected_witness('partial');check_rejected_witness('invalid');boundary_http()
    report={'status':'PASS' if all(o['status']=='PASS' for o in observations) else 'FAIL','checks':observations,'no_original_source_written':True,'solver_runs':0,'source_checker_executed':False,'model_api_calls':0,'implementation_sha256':{n:sha((ROOT/'backend'/n).read_bytes()) for n in ['mature_routes.py','route_comparison.py','route_replay.py']}}
    path=OUT/(sys.argv[1] if len(sys.argv)>1 else 'adversarial_current.json');path.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n');print(json.dumps(report,ensure_ascii=False))
