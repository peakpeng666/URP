"""Independent all-record HTTP and arithmetic audit. Never executes a solver or source checker."""
import argparse, collections, copy, datetime, hashlib, http.client, json, math, statistics, sys, tempfile, threading
from pathlib import Path
ROOT=Path('/workspace/shared/panel_route_mature_backend_20261007/research_console')
sys.path.insert(0,str(ROOT))
from backend.store import Store, StoreError
from backend.routes import import_vrptw, SOURCE_FILES
from backend.mature_routes import import_mature, FILES
from backend.server import make_server

OLD=Path('/workspace/shared/vrp_time_windows_20261007')
NEW=Path('/workspace/shared/vrptw_mature_solver_20261007')
BASELINE=Path('/workspace/shared/panel_route_backend_20261007/research_console')
PKG=Path('/workspace/shared/research_panel_backend_20261007/bpp-research-console/packages')
OUT=ROOT.parent/'independent_audit'

sha=lambda b:hashlib.sha256(b).hexdigest()
def manifest(root,names):return {n:sha((root/n).read_bytes()) for n in names}
def close(a,b,label):
    if not math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-9):raise AssertionError((label,a,b))
def independent_schedule(instance,routes):
    # Deliberately uses hypot and an independent per-route implementation, never imports replay/checker.
    nodes={n['id']:n for n in instance['nodes']};schedules=[];distance=0.0
    for route in routes:
        last=nodes[0];now=instance['depart_time'];cumulative=0;d=0.0;stops=[]
        for nid in route:
            node=nodes[nid];leg=math.hypot(node['x']-last['x'],node['y']-last['y']);arrival=now+leg
            begin=max(arrival,node['window'][0]);departure=begin+node['service'];before=cumulative;cumulative+=node['demand'];d+=leg
            stops.append({'node':nid,'leg_distance':leg,'arrival':arrival,'wait':begin-arrival,'start':begin,'service_start':begin,'depart':departure,'lateness':max(0.0,begin-node['window'][1]),'load_before':before,'load_after':cumulative})
            now=departure;last=node
        ret=math.hypot(last['x']-nodes[0]['x'],last['y']-nodes[0]['y']);d+=ret
        schedules.append({'distance':d,'load':cumulative,'overload':max(0,cumulative-instance['capacity']),'return_leg_distance':ret,'return_time':now+ret,'depot_lateness':max(0.0,now+ret-instance['return_deadline']),'stops':stops});distance+=d
    return distance,schedules

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--label',default=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ'));a=parser.parse_args()
    report_file=OUT/f'real_http_{a.label}.json';db=OUT/f'real_http_{a.label}.sqlite3';assert not db.exists(), 'Fresh independent database required'
    old_before=manifest(OLD,SOURCE_FILES);new_before=manifest(NEW,FILES)
    baseline_names=[str(p.relative_to(BASELINE)) for p in BASELINE.rglob('*') if p.is_file() and '__pycache__' not in p.parts]
    baseline_before=manifest(BASELINE,baseline_names)
    implementation_before=manifest(ROOT,[f'backend/{f}' for f in ['mature_routes.py','route_replay.py','route_comparison.py','routes.py','server.py','store.py']])
    store=Store(db);legacy_receipts=[store.import_package(PKG/name) for name in ['selector','budget','fleet','turns','bpp-history']]
    r1=import_vrptw(store,OLD);r2=import_mature(store,NEW);assert not r1['reused'] and not r2['reused'];assert import_vrptw(store,OLD)['reused'] and import_mature(store,NEW)['reused']
    assert r1['revision']==r2['revision']==1
    rows_old=[json.loads(x) for x in (OLD/'routes.jsonl').read_text().splitlines()];lines_new=(NEW/'results.jsonl').read_bytes().splitlines();rows_new=[json.loads(x) for x in lines_new]
    server=make_server(store,PKG,0);assert server.server_address[0]=='127.0.0.1';thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();http_log=[]
    def request(path,method='GET',payload=None):
        c=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=20);c.request(method,path,None if payload is None else json.dumps(payload),{'Content-Type':'application/json'});resp=c.getresponse();body=resp.read();status=resp.status;headers=dict(resp.getheaders());c.close();http_log.append({'method':method,'path':path,'status':status,'body_sha256':sha(body),'bytes':len(body)});return status,headers,body
    def get(path):
        status,_,body=request(path);assert status==200,(path,status,body[:300]);return json.loads(body)
    def reject(path,code,method='GET',payload=None):
        status,_,body=request(path,method,payload);assert status==code,(path,status,body[:300]);return json.loads(body)
    states={};budgets=collections.defaultdict(collections.Counter);artifact_count=stop_count=vehicle_responses=0;new_stops=0;max_difference=0.0;gap_by_budget=collections.defaultdict(list)
    try:
        health=get('/api/health');assert health['executes_experiments'] is False
        assert len(get('/api/experiments')['experiments'])==7
        for name in ['selector','budget','fleet','turns','bpp-history']:
            d=get('/api/experiments/'+name)
            for artifact in d['artifacts']:
                status,headers,body=request(f"/api/experiments/{name}/artifacts/{artifact['id']}");assert status==200;assert sha(body)==artifact['sha256']==headers['X-Content-SHA256'];artifact_count+=1
        same=[dict(experiment_id='selector',metric_id=f'family_holdout-{n}-delta_vs_subset_sbs') for n in [5,40]]
        status,_,body=request('/api/compare','POST',{'items':same});assert status==200;close(json.loads(body)['differences_from_first'][1],44.03148148148148,'same-budget-difference')
        other=[dict(experiment_id='budget',metric_id=f'all-{n}-random_regret2-mean_relative_regret_pct') for n in [2500,10000]]
        assert reject('/api/compare',409,'POST',{'items':other})['error']=='incomparable_metrics'
        for exp,raw,new in [('vrptw-20261007',rows_old,False),('vrptw-mature-20261007',rows_new,True)]:
            prefix='/api/experiments/'+exp;desc=get(prefix);instances=get(prefix+'/instances')['instances'];assert len(instances)==48
            listing=get(prefix+'/runs');assert listing['count']==len(raw);states[exp]=collections.Counter(r['solution_status'] for r in listing['runs'])
            assert len({r['run_id'] for r in listing['runs']})==len(raw)
            for artifact in desc['artifacts']:
                status,headers,body=request(f"{prefix}/artifacts/{artifact['id']}");assert status==200;assert sha(body)==artifact['sha256']==headers['X-Content-SHA256'];artifact_count+=1
            for n,row in enumerate(raw):
                rid=row['run_id'] if new else f"{row['instance']}.{row['method']}";run=get(prefix+'/runs/'+rid);assert run['routes']==row['routes'];assert run['input']['id']==row['instance'];assert run['full_service_success']==bool(row['audit'] and row['audit']['full_service_feasible'])
                assert run['source_status']==row['outcome' if new else 'status'];assert run['semantics']['load'].endswith('physical onboard load is unknown')
                assert run['semantics']['time_window']=='inclusive_service_start';assert not run['semantics']['is_road_network'];assert not run['semantics']['is_geographic']
                if new:
                    assert run['provenance']['source_run_id']==rid;assert run['provenance']['run_sha256']==sha(lines_new[n]);assert run['budget']['value']==row['budget_ms'];budgets[row['budget_ms']][run['solution_status']]+=1
                    assert run['encoded_cumul_ranges']==row['encoded_cumul_ranges'];assert 'not observed continuous arrival/service times' in run['encoded_cumul_semantics']
                    assert run['solver_status']['name']==row['ortools_status_name'];assert run['provenance']['problem_spec_sha256']==old_before['protocol.json'];assert run['provenance']['research_protocol_sha256']==new_before['protocol.json']
                if row['routes'] is not None:
                    distance,schedules=independent_schedule(run['input'],row['routes']);reported=run['checker']['audit']['total_distance'];close(distance,reported,'total distance');max_difference=max(max_difference,abs(distance-reported))
                    if new:
                        assert run['checker']['recomputed_at_import'] is True;assert run['problem_feasibility']['status']=='feasible'
                        gap=100*(distance/run['metrics']['full_oracle_objective']-1);close(gap,run['metrics']['full_gap_original_percent'],'full gap');gap_by_budget[row['budget_ms']].append(gap)
                else:
                    assert run['unserved_task_ids'] is None;assert run['checker']['audit'] is None;assert run['vehicles']==[]
                    if new:
                        assert run['solution_status']=='no_solution';assert run['problem_feasibility']['status']=='infeasible';assert run['solver_status']['name']=='ROUTING_FAIL';assert run['checker']['recomputed_at_import'] is False;assert run['metrics']['full_gap_original_percent'] is None;assert run['metrics']['full_oracle_objective'] is None
                for vi in range(run['input']['vehicles']):
                    vresp=get(prefix+'/runs/'+rid+'/vehicles/'+str(vi));vehicle_responses+=1;v=vresp['vehicle'];assert vresp['solution_status']==run['solution_status']
                    if row['routes'] is None:assert v is None;continue
                    expected=schedules[vi];assert v['path_node_ids']==[0,*row['routes'][vi],0]
                    for field in ['distance','load','overload','return_leg_distance','return_time','depot_lateness']:close(v[field],expected[field],field)
                    assert len(v['stops'])==len(expected['stops'])
                    for stop,truth in zip(v['stops'],expected['stops']):
                        assert stop['onboard_load'] is None
                        for field,value in truth.items():close(stop[field],value,field)
                        stop_count+=1;new_stops+=int(new)
            reject(prefix+'/runs',405,'POST',{})
        assert states['vrptw-20261007']=={'feasible':137,'partial':53,'invalid':35,'infeasible':15}
        assert states['vrptw-mature-20261007']=={'feasible':66,'no_solution':30}
        assert dict(budgets)=={250:{'feasible':33,'no_solution':15},1000:{'feasible':33,'no_solution':15}}
        c=get('/api/route-comparison?experiments=vrptw-20261007,vrptw-mature-20261007');assert c['row_count']==336;assert c['unique_input_count']==48;assert len(c['groups'])==7;assert c['same_known_budget'] is False
        assert len(c['input_references'])==48
        for row in c['rows']:
            if not row['full_service_success']:assert row['full_service_distance'] is None and row['distance_minus_best_returned_full'] is None
        i=get('/api/route-comparison?experiments=vrptw-20261007,vrptw-mature-20261007&instance=G12_tight');assert i['unique_input_count']==1 and i['row_count']==7
        reject('/api/route-comparison',405,'POST',{})
        assert get('/api/route-comparison?experiments=vrptw-mature-20261007')['row_count']==96
        reject('/api/route-comparison?experiments=vrptw-mature-20261007,vrptw-mature-20261007',400)
        reject('/api/route-comparison?experiments=vrptw-20261007,vrptw-mature-20261007&revisions=1',400)
        reject('/api/route-comparison?experiments=vrptw-20261007,vrptw-mature-20261007&revisions=0,1',400)
        reject('/api/route-comparison?experiments=vrptw-20261007,vrptw-mature-20261007&instance=missing',404)
        before_count=len(store.list())
        try:import_mature(store,NEW,'vrptw-20261007')
        except StoreError as e:assert e.code=='experiment_identity_mismatch'
        else:raise AssertionError('Old experiment overwritten')
        assert len(store.list())==before_count
    finally:server.shutdown();server.server_close();thread.join()
    assert old_before==manifest(OLD,SOURCE_FILES);assert new_before==manifest(NEW,FILES);assert baseline_before==manifest(BASELINE,baseline_names)
    report={'status':'PASS','scope':'all real route records over actual loopback HTTP; independent arithmetic; no new solver calls', 'database':str(db),'fresh_database':True,'receipts':[r1,r2],'idempotent':True,'http_requests':len(http_log),'route_records_checked':336,'vehicle_responses_checked':vehicle_responses,'timetable_stops_checked':stop_count,'mature_stops_checked':new_stops,'artifacts_sha256_checked':artifact_count,'max_independent_total_distance_difference':max_difference,'states':{k:dict(v) for k,v in states.items()},'mature_budget_counts':{str(k):dict(v) for k,v in budgets.items()},'mature_gap_statistics':{str(k):{'n':len(v),'mean':statistics.mean(v),'median':statistics.median(v),'max':max(v)} for k,v in gap_by_budget.items()},'comparison':{k:c[k] for k in ['row_count','unique_input_count','same_known_budget','groups']},'legacy_same_budget_comparison_pass':True,'legacy_cross_budget_comparison_rejected_409':True,'new_read_only_post_rejected_405':True,'old_experiment_id_overwrite_rejected':True,'protected_baseline_unchanged':True,'raw_archives_unchanged':True,'source_checker_executed':False,'solver_runs':0,'api_calls_to_models':0,'implementation_sha256_start':implementation_before,'source_archives_sha256':{'old':old_before,'new':new_before}}
    report_file.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');(OUT/f'http_requests_{a.label}.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in http_log));print(json.dumps({'report':str(report_file),'status':'PASS','http_requests':len(http_log),'stops':stop_count,'max_independent_total_distance_difference':max_difference},ensure_ascii=False))
if __name__=='__main__':main()
