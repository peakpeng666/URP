公开CVRP迁移16题：PyVRP 0.14.0强基线质量对照

目录标签20261009对应父任务指定的用户当地日期；实际创建日期为2026-10-08 UTC。
本轮不改变既有16题、不调自制算法，只准备成熟开源求解器的独立补充质量对照。

当前阶段：准备中，安装授权待确认。未安装PyVRP、未运行公共题或新基线评分。
冻结候选：PyVRP 0.14.0默认ILS；16题×seed 0/1/2，每次MaxRuntime(1.0s)。
1秒只限制主ILS循环的停止回调，不包含初始化、模型构建和导入；外层另限CPU5秒/墙时10秒。
主比较：各题三次均值相对历史TSR的reference gap差，16题等权。best-of-3只作副表。
无warmstart，无参考解成本目标，不把reference当严格最优性证明，不比较等算力/速度。

文件结构：
- freeze/：协议、48调用顺序、原目录所有文件的SHA快照
- input/：16题原VRP与净化JSON的逐字节副本
- history/：历史TSR输出及旧冻结协议/报告，仅供末评分
- references/：已保存参考路线/成本，仅供末评分
- source/：适配器、单次主管、外层封存器、报告器与合成自测
- independent_review/：独立Decimal80验解、原始VRP矩阵核对和审查
- selftests/：仅虚构fixture证据
- environment/：工具可用性、官方固定版本出处，待补安装依赖锁定
- provenance/：待补各阶段私有Drive实际回下载门控回执与父任务执行批准
- raw/：尚无公共执行记录
- reports/：待RAW远程回读后生成正式描述报告

正式执行门槛：
1. 明确安装授权；固定官方wheel与依赖哈希；合成API/资源fixture通过。
2. 独立最终precheck与全部源码/输入/计划冻结。
3. PREEXEC私有Drive上传、真实回下载逐字节一致，以及父任务针对最终freeze批准。
4. source/execute_and_seal.py唯一执行48调用，失败原样保留、不得重跑。
5. RAW_UNREVIEWED马上远程保全/回读；此后才可运行source/report.py。
6. 独立复核实际保存路线与报告，不重跑求解器；最终私有归档。

原 /workspace/shared/public_route_order_transfer_20261008 只读，禁止改动。
