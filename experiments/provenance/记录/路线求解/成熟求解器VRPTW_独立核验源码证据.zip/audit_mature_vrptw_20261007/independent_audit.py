"""Read-only independent audit. No solver/experiment/checker import; no solve calls."""
import json, math, hashlib, resource, time, subprocess, collections, statistics
from pathlib import Path
from decimal import Decimal as D, localcontext, ROUND_CEILING, ROUND_FLOOR, ROUND_HALF_UP
resource.setrlimit(resource.RLIMIT_CPU,(8,9))
t0=time.process_time()
P=Path('/workspace/shared/vrptw_mature_solver_20261007')
A=Path('/workspace/shared/audit_mature_vrptw_20261007')
BASE=Path('/workspace/shared/vrp_time_windows_20261007')
OLD_AUD=Path('/workspace/shared/audit_vrp_time_windows_20261007')
def load(name):return json.loads((P/name).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
errors=[]
def check(test,message):
 if not test:errors.append(message)
inputs=load('inputs.json'); I={i['id']:i for i in inputs}; E={e['instance']:e for e in load('encoded_inputs.json')}
O=load('reference/oracle_tables.json'); F={k for k,v in O.items() if v['full_feasible']}
R=[json.loads(s) for s in (P/'results.jsonl').read_text().splitlines()]; Q=load('requests.json')
summary=load('summary.json'); evaluated={r['run_id']:r for r in load('evaluated_results.json')}
source_manifest={}; frozen={}
for filename,digest in load('freeze.json')['sha256'].items():
 frozen[filename]=sha(P/filename)==digest;check(frozen[filename],'frozen hash mismatch '+filename)
for source_dir,names in [(BASE,['inputs.json','protocol.json','freeze.json','routes.jsonl','oracle_tables.json','summary.json','report_zh.txt']),(OLD_AUD,['independent_results.json','audit_zh.txt'])]:
 for name in names:
  ok=(P/'reference'/name).read_bytes()==(source_dir/name).read_bytes()
  source_manifest[str(source_dir/name)]={'sha256':sha(source_dir/name),'copy_identical':ok}
  check(ok,'original/reference mismatch '+name)
check((P/'inputs.json').read_bytes()==(BASE/'inputs.json').read_bytes(),'inputs source mismatch')
old_audit=load('reference/independent_results.json')
check(sha(BASE/'routes.jsonl')==old_audit['routes_sha256'],'original routes changed since prior independent audit')
old_frozen=json.loads((BASE/'freeze.json').read_text())
check(all(sha(BASE/n)==h for n,h in old_frozen['sha256'].items()),'original frozen files changed')
check(len(I)==48 and len(R)==len(Q)==96,'48 instance/96 request count')
check(len(set(r['run_id'] for r in R))==96,'duplicate records')
check({(r['instance'],r['budget_ms']) for r in R}=={(k,b) for k in I for b in [250,1000]},'missing or additional instance budget pairs')
check([(r['sequence'],r['run_id']) for r in R]==[(q['sequence'],q['run_id']) for q in Q],'request order mismatch')
check(len(F)==33 and len(O)-len(F)==15,'oracle denominator mismatch')
check(len({i['geometry'] for i in inputs})==16,'geometry count')
S=D(1000000); encoded_matrix_entries=0
with localcontext() as ctx:
 ctx.prec=60
 distances={}
 for iid,inst in I.items():
  n=inst['nodes']; enc=E[iid]; dist={}
  check([x['id'] for x in n]==list(range(8)),iid+' node IDs')
  check(inst['vehicles']==2 and inst['capacity']==6 and inst['depart_time']==0 and inst['return_deadline']==120,iid+' structural constants')
  for x in n:
   for y in n:
    d=((D(str(x['x']))-D(str(y['x'])))**2+(D(str(x['y']))-D(str(y['y'])))**2).sqrt();dist[x['id'],y['id']]=d
    i,j=x['id'],y['id'];ceil=int((d*S).to_integral_value(rounding=ROUND_CEILING));nearest=int((d*S).to_integral_value(rounding=ROUND_HALF_UP))
    check(enc['travel_matrix_ceil'][i][j]==ceil,iid+' ceil encoding mismatch')
    check(enc['cost_matrix_nearest'][i][j]==nearest,iid+' nearest encoding mismatch')
    check(enc['transit_service_from_plus_travel'][i][j]==ceil+int(D(str(x['service']))*S),iid+' service-from transit mismatch')
    encoded_matrix_entries+=1
   w=[int((D(str(x['window'][0]))*S).to_integral_value(rounding=ROUND_CEILING)),int((D(str(x['window'][1]))*S).to_integral_value(rounding=ROUND_FLOOR))]
   check(w==enc['windows_inward'][x['id']],iid+' window encoding mismatch')
  distances[iid]=dist
 def replay(iid,routes,encoded=False):
  inst=I[iid]; nodes={n['id']:n for n in inst['nodes']}; dist=distances[iid]; seen=[j for r in routes for j in r]; violations=[]
  if len(routes)>inst['vehicles']:violations.append('vehicles')
  if collections.Counter(seen)!=collections.Counter(j for j in nodes if j):violations.append('coverage/duplicates/unknown')
  distance=D(0);loads=[];returns=[];minimum_close_slack=None;integer_cost=0;details=[]
  for r in routes:
   now=D(str(inst['depart_time']));last=0;load=0;stops=[]
   for j in r:
    if j not in nodes:continue
    node=nodes[j];d=dist[last,j];distance+=d;integer_cost+=int((d*S).to_integral_value(rounding=ROUND_HALF_UP))
    travel=(d*S).to_integral_value(rounding=ROUND_CEILING)/S if encoded else d
    lower=D(str(node['window'][0]));upper=D(str(node['window'][1]))
    if encoded:lower=(lower*S).to_integral_value(rounding=ROUND_CEILING)/S;upper=(upper*S).to_integral_value(rounding=ROUND_FLOOR)/S
    now=max(now+travel,lower);slack=upper-now
    minimum_close_slack=slack if minimum_close_slack is None else min(minimum_close_slack,slack)
    if slack < -D('1e-9'):violations.append('late service start')
    stops.append({'node':j,'service_start':float(now),'window_close_slack':float(slack)})
    now+=D(str(node['service']));load+=node['demand'];last=j
   distance+=dist[last,0];integer_cost+=int((dist[last,0]*S).to_integral_value(rounding=ROUND_HALF_UP))
   now+=(dist[last,0]*S).to_integral_value(rounding=ROUND_CEILING)/S if encoded else dist[last,0]
   if now > D(str(inst['return_deadline']))+D('1e-9'):violations.append('late depot return')
   if load>inst['capacity']:violations.append('capacity')
   loads.append(load);returns.append(float(now));details.append(stops)
  return {'valid':not violations,'violations':violations,'distance':float(distance),'distance_decimal':str(distance),'integer_cost':integer_cost,'loads':loads,'returns':returns,'minimum_service_close_slack':float(minimum_close_slack or 0),'stops':details}
 all_replays=[];by_budget={};oracle_witnesses=[];max_reported_distance_diff=0.;max_cost_rounding_error=0.;max_gap_diff=0.
 for r in R:
  iid=r['instance'];routes=r.get('routes')
  check((routes is not None)==r['assignment_returned'],r['run_id']+' return marker')
  if routes is None:
   check(iid not in F,r['run_id']+' feasible instance failure')
   check(r['ortools_status_name']=='ROUTING_FAIL' and r['outcome']=='no_solution_in_budget',r['run_id']+' failure status')
   continue
  rr=replay(iid,routes);ee=replay(iid,routes,True)
  check(rr['valid'] and ee['valid'],r['run_id']+' invalid route')
  check(iid in F,r['run_id']+' assignment on reference infeasible')
  check(rr['integer_cost']==r['objective_integer'],r['run_id']+' integer objective mismatch')
  optimum=O[iid]['best_two_vehicle_by_served_mask']['127']['distance']
  delta=rr['distance']-optimum;gap=100*delta/optimum
  check(abs(delta)<1e-9,r['run_id']+' continuous oracle gap')
  max_reported_distance_diff=max(max_reported_distance_diff,abs(rr['distance']-r['audit']['total_distance']))
  max_cost_rounding_error=max(max_cost_rounding_error,abs(rr['distance']-r['objective_integer']/1e6))
  max_gap_diff=max(max_gap_diff,abs(gap-evaluated[r['run_id']]['full_gap_original_percent']))
  all_replays.append({'run_id':r['run_id'],'instance':iid,'budget_ms':r['budget_ms'],'routes':routes,**rr,'reference_continuous_optimum':optimum,'full_gap_percent':gap,'encoded_replay_valid':ee['valid']})
 for iid in sorted(F):
  witness=O[iid]['best_two_vehicle_by_served_mask']['127']; rr=replay(iid,witness['routes']); ee=replay(iid,witness['routes'],True)
  check(rr['valid'] and ee['valid'],iid+' oracle witness invalid continuous or encoding')
  check(abs(rr['distance']-witness['distance'])<1e-9,iid+' oracle witness distance')
  oracle_witnesses.append({'instance':iid,'continuous_valid':rr['valid'],'inward_encoding_valid':ee['valid']})
 for budget in [250,1000]:
  rows=[r for r in R if r['budget_ms']==budget];goods=[r for r in all_replays if r['budget_ms']==budget];fails=[r['instance'] for r in rows if r['routes'] is None]
  check(len(goods)==33 and set(fails)==set(I)-F,str(budget)+' full denominator')
  by_budget[str(budget)]={'records':len(rows),'original_feasible':len(F),'valid_full_service':len(goods),'oracle_infeasible_retained':len(fails),'ROUTING_FAIL_ids':fails,'gap_mean_percent':statistics.mean(r['full_gap_percent'] for r in goods),'gap_max_absolute_percent':max(abs(r['full_gap_percent']) for r in goods)}
 actual=json.loads(subprocess.check_output([str(P/'.venv/bin/python'),'-c','import sys,importlib.metadata,json; print(json.dumps({"python":sys.version,"ortools":importlib.metadata.version("ortools")}))'],text=True))
 check(actual['python']==load('environment.json')['python'] and actual['ortools']=='9.14.6206','actual environment discrepancy')
 baseline=[json.loads(s) for s in (P/'reference/routes.jsonl').read_text().splitlines()]
 g12_baseline={r['method']:{'served':len(set(j for route in r['routes'] for j in route)),'missing':sorted(set(range(1,8))-{j for route in r['routes'] for j in route})} for r in baseline if r['instance']=='G12_tight' and r['method'] in ['distance_first','time_window_first']}
 report={'passed':not errors,'errors':errors,'unique_instances':len(I),'geometry_clusters':16,'paired_budget_calls':len(R),'returned_assignments_replayed':len(all_replays),'independent_instances_warning':'66 successful assignments are two runs on the same 33 original-feasible cases; 96 calls are the same 48 cases, grouped into 16 correlated geometries.','by_budget':by_budget,'encoding':{'scale':1000000,'decimal_precision':60,'matrix_entries_checked':encoded_matrix_entries,'conservative_travel_and_inward_windows_verified':True,'objective_rounding_bound_original_units':4.5e-6,'max_observed_integer_objective_error':max_cost_rounding_error,'original_optimal_witnesses_continuous_and_encoded_valid':len(oracle_witnesses),'boundary_warning':'Conservative encoding can exclude other original boundary-feasible routes. Null assignment is not proof of original infeasibility.'},'max_reported_distance_difference':max_reported_distance_diff,'max_reported_gap_difference_percent':max_gap_diff,'g12_tight':{'old_baselines':g12_baseline,'new_runs':[r for r in all_replays if r['instance']=='G12_tight']},'actual_environment':actual,'all_current_frozen_hashes_match':all(frozen.values()),'original_reference_copies_match':all(x['copy_identical'] for x in source_manifest.values()),'original_routes_unchanged_from_prior_audit':sha(BASE/'routes.jsonl')==old_audit['routes_sha256'],'source_manifest':source_manifest,'raw_results_sha256':sha(P/'results.jsonl'),'scope':'Seven-task, two-vehicle synthetic small cases only. No mature large-scale benchmark, SOTA claim, independent-sample inference, or OR-Tools optimality certificate. Original feasibility/optimality labels remain conditional on the already audited exhaustive oracle; no exhaustive oracle rerun here.','audit_method':'Independent Decimal(60) Euclidean travel, earliest start-of-service replay, return deadline, capacity, exact coverage and objective/gap recomputation. Imports no author experiment/checker/solver. No solve calls, no installations, no model changes; source directory read-only.','cpu_seconds':time.process_time()-t0}
 (A/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 (A/'independent_replays.json').write_text(json.dumps(all_replays,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({k:report[k] for k in ['passed','errors','by_budget','max_reported_distance_difference','max_reported_gap_difference_percent','actual_environment','cpu_seconds']},ensure_ascii=False,indent=2))
