import sys,time,subprocess,resource,os
sys.dont_write_bytecode=True
from common import *
verify_freeze()
assert read(ROOT/'provenance/PREEXEC_ARCHIVE_VERIFIED.json')['verified'] is True
assert not (ROOT/'raw/STARTED.json').exists(),'No repeated execution allowed'
dump(ROOT/'raw/STARTED.json',{'utc':utc(),'no_rerun':True})
c=time.process_time_ns();w=time.perf_counter_ns()
with (ROOT/'raw/STDOUT.txt').open('x') as out,(ROOT/'raw/STDERR.txt').open('x') as err:
 p=subprocess.Popen([sys.executable,'-B',str(ROOT/'source/worker.py')],stdout=out,stderr=err)
 resource.setrlimit(resource.RLIMIT_CPU,(5,5));resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2))
 timeout=False
 try:code=p.wait(timeout=220)
 except subprocess.TimeoutExpired:p.kill();code=p.wait();timeout=True
 usage=resource.getrusage(resource.RUSAGE_CHILDREN)
 dump(ROOT/'raw/FINISHED.json',{'utc':utc(),'returncode':code,'timeout':timeout,'supervisor_cpu_ns':time.process_time_ns()-c,'elapsed_ns':time.perf_counter_ns()-w,'child_cpu_seconds':usage.ru_utime+usage.ru_stime,'child_peakrss_KiB':usage.ru_maxrss,'supervisor_peakrss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss})
print(json.dumps(read(ROOT/'raw/FINISHED.json')))
sys.exit(code if code>=0 else 1)
