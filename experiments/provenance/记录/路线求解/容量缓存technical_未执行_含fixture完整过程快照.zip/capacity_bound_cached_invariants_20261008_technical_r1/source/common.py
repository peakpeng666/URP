from pathlib import Path
import json,hashlib,datetime,sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[1]
SOURCE=Path('/workspace/shared/capacity_cross_structure_reproduction_20261008_r1')
ARMS=['waste_solver','cached_solver']
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def dump(p,v):
 with Path(p).open('x') as f:json.dump(v,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')
def strip_time(v):
 if isinstance(v,dict):return {k:strip_time(x) for k,x in v.items() if not ('cpu' in k or 'wall' in k or 'seconds' in k)}
 if isinstance(v,list):return [strip_time(x) for x in v]
 return v
def functional(v):return v
def signature(r):return digest(functional(strip_time({k:r.get(k) for k in ['status','output','diagnostic','budget','error','groups']})))
def verify_freeze():
 f=read(ROOT/'freeze/PRE_RUN_FREEZE.json')
 for p,h in f['sha256'].items():assert sha(ROOT/p)==h,p
 return f
