import sys,random,ast,difflib
sys.dont_write_bytecode=True
from common import *
assert not (ROOT/'freeze/PRE_RUN_FREEZE.json').exists()
assert not any((ROOT/'raw').iterdir())
ids=sorted(p.stem for p in (ROOT/'input').glob('*.json'));assert len(ids)==48
old={str(p.relative_to(SOURCE)):sha(p) for p in sorted(SOURCE.rglob('*')) if p.is_file()}
dump(ROOT/'provenance/OLD_FILES_BEFORE.json',old)
refs=[json.loads(x) for x in (SOURCE/'raw/results.jsonl').read_text().splitlines()]
for endpoint,name in [('initialize_256','REFERENCE_INITIALIZE.json'),('partition_256','REFERENCE_PARTITION.json')]:
 rr=[r for r in refs if r['endpoint']==endpoint and r['arm']=='waste_solver'];assert len(rr)==48
 dump(ROOT/'provenance'/name,rr)
for p in (ROOT/'source/solvers').rglob('*.py'):
 if p.name=='cached_solver.py':continue
 src=SOURCE/'source'/p.relative_to(ROOT/'source/solvers');assert sha(p)==sha(src)
for p in (ROOT/'input').glob('*.json'):assert sha(p)==sha(SOURCE/'input'/p.name)
orig=(ROOT/'source/solvers/waste_solver.py').read_text();cand=(ROOT/'source/solvers/cached_solver.py').read_text()
ot=ast.parse(orig);ct=ast.parse(cand)
om={n.name:ast.dump(n,include_attributes=False) for n in ot.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
cm={n.name:ast.dump(n,include_attributes=False) for n in ct.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
assert set(cm)-set(om)=={'suffix_statistics','cached_waste_capacity_test'}
assert all(cm[k]==v for k,v in om.items() if k!='bounded_partition')
assert 'smallest - 1' not in cand and 'smallest-1' not in cand
(ROOT/'provenance/CANDIDATE.diff').write_text(''.join(difflib.unified_diff(orig.splitlines(True),cand.splitlines(True),fromfile='waste_solver.py',tofile='cached_solver.py')))
for p in (ROOT/'source').rglob('*.py'):ast.parse(p.read_text(),filename=str(p))
records=[]
for i in ids:
 raw=read(ROOT/'input'/f'{i}.json')
 assert type(raw['K']) is int and raw['K']>0 and type(raw['capacity']) is int and raw['capacity']>0
 assert all(type(x) is int and x>=0 for x in raw['demands']) and raw['demands'][0]==0
 records.append({'instance_id':i,'K':raw['K'],'capacity':raw['capacity'],'min_customer_demand':min(raw['demands'][1:]),'max_customer_demand':max(raw['demands'][1:]),'input_sha256':sha(ROOT/'input'/f'{i}.json')})
dump(ROOT/'provenance/INTEGER_DOMAIN_CHECK.json',records)
seed=202610081305;first=random.Random(seed).randrange(2);schedule=[]
for rnd in range(6):
 order=ids[:];random.Random(seed+rnd).shuffle(order)
 arms=ARMS[:] if (first+rnd)%2==0 else list(reversed(ARMS))
 for pos,a in enumerate(arms):schedule.append({'batch_id':f'R{rnd}-A{pos}-{a}','phase':'warmup' if rnd==0 else'timed','round':rnd,'arm':a,'instance_order_seed':seed+rnd,'instance_order':order,'repetitions':1 if rnd==0 else 8})
dump(ROOT/'freeze/SCHEDULE.json',schedule)
protocol=read(ROOT/'provenance/PROTOCOL_DRAFT.json')
protocol.update({'utc':utc(),'old_results_sha256':sha(SOURCE/'raw/results.jsonl'),'schedule_seed':seed})
dump(ROOT/'freeze/PROTOCOL.json',protocol)
dump(ROOT/'provenance/PREPARATION_CHECKS.json',{'syntax':'AST parse only, no import/solver execution','inputs':48,'old_files':len(old),'only_bounded_partition_and_two_new_helpers_changed':True,'integer_domain':True,'prior_source_hashes_equal':True,'solver_calls':0})
files={str(p.relative_to(ROOT)):sha(p) for p in sorted(ROOT.rglob('*')) if p.is_file()}
dump(ROOT/'freeze/PRE_RUN_FREEZE.json',{'utc':utc(),'status':'FROZEN_PREEXEC','sha256':files})
print(json.dumps({'frozen_files':len(files),'inputs':len(ids),'solver_calls':0,'schedule_batches':len(schedule)}))
