import sys,time,os,resource,signal,importlib,itertools,gc,platform
sys.dont_write_bytecode=True
ENTRY_C=time.process_time_ns();ENTRY_W=time.perf_counter_ns()
resource.setrlimit(resource.RLIMIT_CPU,(95,100));resource.setrlimit(resource.RLIMIT_AS,(768*1024**2,768*1024**2))
from common import *
class StageStop(BaseException):pass
stop_requested=None;active_call=False
def stop(signum,frame):
 global stop_requested
 stop_requested='signal_'+str(signum)
 if active_call:raise StageStop(stop_requested)
signal.signal(signal.SIGXCPU,stop);signal.signal(signal.SIGALRM,stop);signal.setitimer(signal.ITIMER_REAL,215)
f=verify_freeze();protocol=read(ROOT/'freeze/PROTOCOL.json');schedule=read(ROOT/'freeze/SCHEDULE.json')
receipt=read(ROOT/'provenance/PREEXEC_ARCHIVE_VERIFIED.json')
assert receipt['verified'] is True
assert receipt['preexecution_zip_sha256']==sha(ROOT.parent/'capacity_bound_cached_invariants_20261008_technical_r1_PREEXECUTION_SNAPSHOT.zip')
sys.path.insert(0,str(ROOT/'source/solvers'))
mods={a:importlib.import_module(a) for a in ARMS}
from audit import check
inputs={p.stem:read(p) for p in sorted((ROOT/'input').glob('*.json'))}
input_digests={i:digest(v) for i,v in inputs.items()}
refs={r['instance_id']:r for r in read(ROOT/'provenance/REFERENCE_INITIALIZE.json')}
partrefs={r['instance_id']:r for r in read(ROOT/'provenance/REFERENCE_PARTITION.json')}
for m in mods.values():assert m.CAPACITY_NODE_LIMIT==256
for raw in inputs.values():
 assert type(raw['capacity']) is int and raw['capacity']>0 and type(raw['K']) is int and raw['K']>0
 assert all(type(x) is int and x>=0 for x in raw['demands']) and raw['demands'][0]==0
meta={'utc':utc(),'pid':os.getpid(),'cpu_limit':resource.getrlimit(resource.RLIMIT_CPU),'address_space_limit':resource.getrlimit(resource.RLIMIT_AS),'python':sys.version,'platform':platform.platform(),'gc_enabled':gc.isenabled(),'gc_threshold':gc.get_threshold(),'clocks':{k:vars(time.get_clock_info(k)) for k in ['process_time','perf_counter']},'freeze_sha256':sha(ROOT/'freeze/PRE_RUN_FREEZE.json')}
dump(ROOT/'raw/WORKER_STARTED.json',meta)
cal=[]
for _ in range(1000):
 c=time.process_time_ns();w=time.perf_counter_ns();ew=time.perf_counter_ns();ec=time.process_time_ns();cal.append({'cpu_ns':ec-c,'wall_ns':ew-w})
dump(ROOT/'raw/CLOCK_BRACKETS.json',cal)
ticks=[time.process_time_ns() for _ in range(10000)]
dump(ROOT/'raw/CPU_CLOCK_TICKS.json',ticks)

def feasible(remaining,residual):
 ds=sorted((x for x in remaining if x),reverse=True)
 def visit(i,rooms):
  if i==len(ds):return True
  seen=set()
  for j,r in enumerate(rooms):
   if r in seen:continue
   seen.add(r)
   if r>=ds[i]:
    nxt=rooms[:];nxt[j]-=ds[i]
    if visit(i+1,nxt):return True
  return False
 return visit(0,list(residual))

# Frozen 7140 states; compare the entire guard triple and independent feasibility.
state_count=mismatches=false_prunes=metadata_mismatches=transition_mismatches=0
with (ROOT/'raw/toy_states.jsonl').open('x') as h:
 for K in range(1,4):
  for residual in itertools.product(range(4),repeat=K):
   for n in range(4):
    for rem in itertools.product(range(4),repeat=n):
     if stop_requested:raise StageStop(stop_requested)
     sums,mins,neg=mods['cached_solver'].suffix_statistics(rem)
     slack=sum(residual)-sums[0]
     a=mods['waste_solver'].waste_capacity_test(rem,residual)
     b=mods['cached_solver'].cached_waste_capacity_test(n,mins[0],slack,neg[0],residual)
     can=feasible(rem,residual);state_count+=1
     mismatches+=a!=b;false_prunes+=bool(b[0] and can)
     for d in range(n+1):
      positive=[x for x in rem[d:] if x>0]
      metadata_mismatches+=sums[d]!=sum(rem[d:]) or mins[d]!=(min(positive) if positive else None) or neg[d]!=any(x<0 for x in rem[d:])
     transitions=0
     if rem:
      for j,r in enumerate(residual):
       if rem[0]<=r:
        nxt=list(residual);nxt[j]-=rem[0];transitions+=1
        transition_mismatches+=sum(nxt)-sum(rem[1:])!=slack
     h.write(json.dumps({'state_id':state_count,'remaining':rem,'residual':residual,'original':a,'cached':b,'feasible_exhaustive':can,'suffix_sum':sums,'suffix_min_positive':mins,'suffix_has_negative':neg,'slack':slack,'placement_transitions_checked':transitions},allow_nan=False)+'\n')
 h.flush();os.fsync(h.fileno())
# Preserve negative-domain errors and their ordering even for an empty remaining list.
negative_cases=[([],[-1]),([-1],[]),([-1],[0]),([0,-1],[1]),([0],[-1]),([1],[-1])]
negative_results=[]
for rem,residual in negative_cases:
 sums,mins,neg=mods['cached_solver'].suffix_statistics(rem)
 outcomes=[]
 for which in ARMS:
  try:
   if which=='waste_solver':v=mods[which].waste_capacity_test(rem,residual)
   else:v=mods[which].cached_waste_capacity_test(len(rem),mins[0],sum(residual)-sums[0],neg[0],residual)
   outcomes.append({'value':v})
  except Exception as e:outcomes.append({'error_type':type(e).__name__,'message':str(e)})
 negative_results.append({'remaining':rem,'residual':residual,'outcomes':outcomes})
 assert outcomes[0]==outcomes[1] and outcomes[0].get('error_type')=='ValueError'
dump(ROOT/'raw/NEGATIVE_DOMAIN_CHECKS.json',negative_results)
dump(ROOT/'raw/TOY_FINISHED.json',{'states':state_count,'decision_mismatches':mismatches,'false_prunes':false_prunes,'metadata_mismatches':metadata_mismatches,'transition_mismatches':transition_mismatches,'negative_domain_cases':len(negative_cases)})
assert state_count==7140 and not (mismatches or false_prunes or metadata_mismatches or transition_mismatches)

# The only direct partitions: 48 x 2, untimed. Call events include budget-return calls.
def traced_partition(mod,raw):
 filename=mod.bounded_partition.__code__.co_filename
 node_trace=[]
 def trace(frame,event,arg):
  if frame.f_code.co_filename==filename and frame.f_code.co_name=='visit' and event=='call':
   loc=frame.f_locals
   node_trace.append({'entry_index':len(node_trace)+1,'nodes_before':loc['nodes'],'counted_by_algorithm':loc['nodes']<loc['node_limit'],'depth':loc['depth'],'residual':loc['residual'][:],'groups':[b[:] for b in loc['bins']]})
  return trace
 prior=sys.gettrace();sys.settrace(trace)
 try:groups,diag=mod.bounded_partition(raw['demands'],raw['capacity'],raw['K'],256)
 finally:sys.settrace(prior)
 # Every function call is preserved. Budget-return calls are not entered algorithm nodes.
 assert sum(t['counted_by_algorithm'] for t in node_trace)==diag['nodes']
 return groups,diag,node_trace
partition_records=[]
with (ROOT/'raw/partitions.jsonl').open('x') as h:
 for i,raw in inputs.items():
  for a in ARMS:
   if stop_requested:raise StageStop(stop_requested)
   groups,diag,node_trace=traced_partition(mods[a],raw)
   r={'instance_id':i,'arm':a,'groups':groups,'diagnostic':diag,'status':'SUCCESS' if groups is not None else diag['outcome'],'node_trace':node_trace,'entry_calls':len(node_trace),'uncounted_budget_return_calls':sum(not t['counted_by_algorithm'] for t in node_trace)}
   r['node_trace_sha256']=digest(node_trace);r['prune_trace_sha256']=digest(diag['prune_trace']);r['assignment_sha256']=digest(groups)
   r['functional_signature']=signature(r);r['reference_signature']=signature(partrefs[i]);r['input_unchanged']=digest(raw)==input_digests[i]
   r['assignment_valid']=groups is None or (sorted(j for b in groups for j in b)==list(range(1,len(raw['demands']))) and len(groups)<=raw['K'] and all(sum(raw['demands'][j] for j in b)<=raw['capacity'] for b in groups))
   h.write(json.dumps(r,allow_nan=False)+'\n');h.flush();os.fsync(h.fileno())
   partition_records.append(r)
# Functionality must pass before any warmup or timer batch is permitted.
partition_errors=[]
for r in partition_records:
 if r['functional_signature']!=r['reference_signature'] or not r['input_unchanged'] or not r['assignment_valid']:
  partition_errors.append({'instance_id':r['instance_id'],'arm':r['arm'],'error':'reference_or_validity'})
for a,b in zip(partition_records[::2],partition_records[1::2]):
 if a['instance_id']!=b['instance_id'] or a['functional_signature']!=b['functional_signature'] or any(a[k]!=b[k] for k in ['node_trace_sha256','prune_trace_sha256','assignment_sha256']):
  partition_errors.append({'instance_id':a['instance_id'],'error':'pair_or_full_entry_trace_mismatch'})
dump(ROOT/'raw/PRETIMING_FUNCTIONAL_GATE.json',{'passed':len(partition_records)==96 and not partition_errors,'partition_records':len(partition_records),'errors':partition_errors,'timed_calls_before_gate':0,'warmup_calls_before_gate':0})
assert len(partition_records)==96 and not partition_errors

def invoke(raw,mod):
 global active_call
 out=diag=budget=None;error=None;status='ERROR';abort=False
 active_call=True;w=time.perf_counter_ns()
 try:
  inst=mod.instance_for(raw);budget=mod.Budget(100000,1,2)
  matrix=mod.matrix_for(inst,budget)
  routes,cost,diag=mod.initialize(raw,inst,matrix,budget)
  out=mod.output_for(routes,cost);status='SUCCESS'
 except mod.InitFailure as e:diag=getattr(e,'detail',None);status='INITFAIL';error={'type':type(e).__name__,'message':str(e)}
 except mod.StopBudget as e:status='BUDGET';error={'type':type(e).__name__,'message':str(e)}
 except StageStop as e:status='STAGE_BUDGET';error={'type':type(e).__name__,'message':str(e)};abort=True
 except Exception as e:status='ERROR';error={'type':type(e).__name__,'message':str(e)}
 wall=time.perf_counter_ns()-w;active_call=False
 usage=budget.snapshot() if budget is not None else None
 return {'status':status,'output':out,'diagnostic':diag,'budget':usage,'error':error,'stage_abort':abort,'algorithm_wall_ns':wall}

counts={'warmup':0,'timed':0};batches_done=0;reason=None;active=None;buffer=[];batch_saved=True;saved_records=0
with (ROOT/'raw/calls.jsonl').open('x') as h,(ROOT/'raw/batches.jsonl').open('x') as g:
 try:
  for batch in schedule:
   if stop_requested:reason=stop_requested;break
   active=batch;buffer=[];batch_saved=False;saved_records=0
   c=time.process_time_ns();w=time.perf_counter_ns()
   for i in batch['instance_order']:
    for rep in range(batch['repetitions']):
     if stop_requested:break
     r=invoke(inputs[i],mods[batch['arm']]);buffer.append((i,rep,r))
     if r['stage_abort']:break
    if stop_requested:break
   wall=time.perf_counter_ns()-w;cpu=time.process_time_ns()-c
   # Validation, signatures and durable JSON writes all outside the full-panel timer.
   for i,rep,r in buffer:
    raw=inputs[i];r['functional_signature']=signature(r);r['reference_signature']=signature(refs[i]);r['non_time_diagnostic']=strip_time(r.pop('diagnostic'))
    r['input_unchanged']=digest(raw)==input_digests[i]
    r['output_sha256']=digest(r['output'])
    r['prune_trace_sha256']=digest(((r['non_time_diagnostic'] or {}).get('capacity_partition') or {}).get('prune_trace'))
    r['checker']=check(raw,r['output'],raw['K']) if r['output'] is not None else {'accepted':False,'errors':['no_output']}
    r.update({'call_id':batch['batch_id']+'-'+i+f'-P{rep:02d}','phase':batch['phase'],'round':batch['round'],'arm':batch['arm'],'instance_id':i,'repetition':rep,'input_sha256':f['sha256']['input/'+i+'.json']})
    h.write(json.dumps(r,allow_nan=False)+'\n');counts[batch['phase']]+=1;saved_records+=1
   h.flush();os.fsync(h.fileno())
   g.write(json.dumps({'batch_id':batch['batch_id'],'phase':batch['phase'],'round':batch['round'],'arm':batch['arm'],'completed_calls':len(buffer),'expected_calls':48*batch['repetitions'],'wrapper_inclusive_panel_cpu_ns':cpu,'wrapper_inclusive_panel_wall_ns':wall,'algorithm_wall_sum_ns':sum(r['algorithm_wall_ns'] for _,_,r in buffer)},allow_nan=False)+'\n');g.flush();os.fsync(g.fileno())
   batches_done+=1;batch_saved=True
   print(batch['batch_id'],'calls',len(buffer),'CPU_ns',cpu,'wall_ns',wall,flush=True)
   if stop_requested:reason=stop_requested;break
 except BaseException as e:reason=type(e).__name__+':'+str(e);raise
 finally:
  signal.setitimer(signal.ITIMER_REAL,0)
  if not batch_saved:dump(ROOT/'raw/PARTIAL_BATCH.json',{'batch':active,'already_written_records':saved_records,'buffer':buffer,'overlap_note':'Buffer includes already-written rows; do not double count; no retry.'})
  dump(ROOT/'raw/WORKER_FINISHED.json',{'utc':utc(),'complete':reason is None and batches_done==len(schedule),'reason':reason,'batches':batches_done,'calls':counts,'worker_cpu_ns':time.process_time_ns(),'worker_elapsed_ns':time.perf_counter_ns()-ENTRY_W,'peakrss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'reruns':0})
