import sys,zipfile
sys.dont_write_bytecode=True
from common import *
label=sys.argv[1]
assert label in ['PREEXECUTION_SNAPSHOT','RAW_COMPLETE_UNAUDITED','REPORT_AND_EVIDENCE']
if label=='PREEXECUTION_SNAPSHOT':assert not any((ROOT/'raw').iterdir())
if label=='RAW_COMPLETE_UNAUDITED':assert (ROOT/'raw/FINISHED.json').exists()
manifest={str(p.relative_to(ROOT)):sha(p) for p in sorted(ROOT.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
mp=ROOT/(label+'_SHA256.json');dump(mp,manifest)
zip_path=ROOT.parent/(ROOT.name+'_'+label+'.zip')
with zipfile.ZipFile(zip_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(ROOT.rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts:z.write(p,ROOT.name+'/'+str(p.relative_to(ROOT)))
print(json.dumps({'path':str(zip_path),'bytes':zip_path.stat().st_size,'sha256':sha(zip_path),'status':label,'file_count':len(manifest)+1}))
