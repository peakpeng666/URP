"""Bounded independent toy verification. Only extracted helper/partition functions run."""
import ast, json, resource, signal, time, itertools
from pathlib import Path
from functools import lru_cache
resource.setrlimit(resource.RLIMIT_CPU,(5,5));signal.alarm(10)
cpu=time.process_time();wall=time.perf_counter()
ROOT=Path('/workspace/shared/positive_slack_capacity_bound_20261008');OUT=Path('/workspace/shared/positive_slack_capacity_bound_audit_20261008')
@lru_cache(None)
def sums(ds):
 out=[0]*(1<<len(ds))
 for mask in range(1,1<<len(ds)):
  bit=mask&-mask;out[mask]=out[mask^bit]+ds[bit.bit_length()-1]
 return tuple(out)
def exact(ds,rs):
 # Bin-by-bin subset-mask dynamic program. No candidate bound, demand ordering,
 # labeled-item recursion or solver code is used.
 n=len(ds);full=(1<<n)-1;weights=sums(tuple(ds));reach={0}
 for capacity in rs:
  next_reach=set()
  for used in reach:
   rem=full^used;sub=rem
   while True:
    if weights[sub]<=capacity:next_reach.add(used|sub)
    if not sub:break
    sub=(sub-1)&rem
  reach=next_reach
 return full in reach
mods={}
for arm in ['capacity_solver','pruned_solver','waste_solver']:
 tree=ast.parse((ROOT/'source'/f'{arm}.py').read_text())
 keep=[x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name in ['bounded_partition','tight_capacity_test','waste_capacity_test']]
 ns={'CAPACITY_NODE_LIMIT':256};exec(compile(ast.Module(body=keep,type_ignores=[]),arm,'exec'),ns);mods[arm]=ns
f=mods['waste_solver']['waste_capacity_test'];g=mods['pruned_solver']['tight_capacity_test']
raw_states=0;true_feasible=0;pruned=0;full_fill_equiv=0;seen=set()
for line in (ROOT/'raw/toy_states.jsonl').read_text().splitlines():
 ds,rs,truth,flag=json.loads(line);key=(tuple(ds),tuple(rs));assert key not in seen;seen.add(key)
 assert truth==exact(ds,rs),(ds,rs,truth)
 positive=[d for d in ds if d>0];U=sum(rs)-sum(ds);W=sum(r for r in rs if 0<r<min(positive)) if positive else 0
 expected=bool(ds) and (U<0 or bool(positive) and W>U)
 assert expected==flag==f(ds,rs)[0]
 assert not flag or not truth
 if ds and all(d>0 for d in ds) and sum(ds)==sum(rs):assert f(ds,rs)[0]==g(ds,rs)[0];full_fill_equiv+=1
 raw_states+=1;true_feasible+=truth;pruned+=flag
expected_keys={(tuple(ds),tuple(rs)) for K in range(1,4) for rs in itertools.combinations_with_replacement(range(6),K) for n in range(6) for ds in itertools.combinations_with_replacement(range(6),n)}
assert seen==expected_keys
new_checks=0
for Q in range(1,4):
 for K in range(1,4):
  for n in range(5):
   for ds in itertools.combinations_with_replacement(range(4),n):
    truth=exact(ds,(Q,)*K)
    for arm,ns in mods.items():
     groups,report=ns['bounded_partition']([0,*ds],Q,K,100000)
     assert not report['limit_reached'] and (groups is not None)==truth,(arm,ds,Q,K)
     if groups is not None:
      assert sorted(j for z in groups for j in z)==list(range(1,n+1))
      assert all(sum(ds[j-1] for j in z)<=Q for z in groups)
     new_checks+=1
boundaries=[]
for label,ds,rs,reject,feasible in [
 ('positive_slack_prune',[2,2],[1,1,3],True,False),
 ('W_equals_U_feasible',[2],[1,2],False,True),
 ('W_equals_U_infeasible',[3,3,3],[1,4,5],False,False),
 ('aggregate_capacity_negative',[2],[1],True,False),
 ('only_zero_demands',[0,0],[0],False,True),
 ('zero_and_positive',[0,2],[1,2],False,True),
 ('empty_remaining',[],[0,1],False,True),
 ('empty_remaining_empty_bins',[],[],False,True),
 ('zero_demand_no_bins',[0],[],False,False),
 ('positive_no_bins',[1],[],True,False)]:
 assert f(ds,rs)[0]==reject and exact(ds,rs)==feasible,label
 boundaries.append({'label':label,'remaining':ds,'residual':rs,'reject':reject,'feasible':feasible})
negative=[]
for ds,rs in [([-1],[2]),([2],[-1]),([],[-1])]:
 try:f(ds,rs)
 except ValueError:negative.append([ds,rs])
 else:raise AssertionError('negative domain not rejected')
node_limits=[]
for arm,ns in mods.items():
 for limit in [0,1,2]:
  ans,report=ns['bounded_partition']([0,1],1,1,limit)
  assert report['nodes']==min(2,limit) and (ans is not None)==(limit==2) and report['limit_reached']==(limit<2)
  node_limits.append({'arm':arm,'limit':limit,'report':report})
for arm in ['pruned_solver','waste_solver']:
 # Root prune counts as one admitted state even though it expands no child.
 demands=[0,2,2,2];Q=3;K=2
 ans,report=mods[arm]['bounded_partition'](demands,Q,K,100)
 assert ans is None and report['prunes']>0
 assert all(1<=x['entered_node']<=report['nodes'] for x in report['prune_trace'])
 node_limits.append({'arm':arm,'root_or_descendant_pruned_case':True,'report':report})
result={'passed':True,'audit_raw_toy_states':raw_states,'feasible':true_feasible,'pruned':pruned,'full_fill_equivalence_cases':full_fill_equiv,'new_toy_solver_checks':new_checks,'boundary_cases':boundaries,'negative_cases':negative,'node_limit_cases':node_limits,'oracle':'Independent bin-by-bin subset-mask dynamic program; no main input solver calls','limits':{'cpu_seconds':5,'wall_seconds':10},'cpu_seconds':time.process_time()-cpu,'wall_seconds':time.perf_counter()-wall}
with (OUT/'TOY_AUDIT.json').open('x') as out:json.dump(result,out,indent=2);out.write('\n')
print(json.dumps({k:result[k] for k in ['passed','audit_raw_toy_states','feasible','pruned','full_fill_equivalence_cases','new_toy_solver_checks','cpu_seconds','wall_seconds']},indent=2))
