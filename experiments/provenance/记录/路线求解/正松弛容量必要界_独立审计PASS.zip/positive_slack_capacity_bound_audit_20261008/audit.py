"""Independent read-only audit. Does not import or rerun any main solver."""
from pathlib import Path
import json, hashlib, math, ast, random, collections, datetime, difflib
ROOT=Path('/workspace/shared/positive_slack_capacity_bound_20261008')
OUT=Path('/workspace/shared/positive_slack_capacity_bound_audit_20261008')
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,v):
 with (OUT/name).open('x') as f:json.dump(v,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')
checks=[]
def check(label,v,details=None):
 checks.append({'check':label,'passed':bool(v),'details':details})
 return bool(v)
freeze=read(ROOT/'freeze/PRE_RUN_FREEZE.json'); protocol=read(ROOT/'freeze/PRE_GENERATION.json'); schedule=read(ROOT/'freeze/SCHEDULE.json')
started=read(ROOT/'raw/STARTED.json');finished=read(ROOT/'raw/FINISHED.json')
hashes={p:{'expected':h,'actual':sha(ROOT/p),'matched':sha(ROOT/p)==h} for p,h in freeze['sha256'].items()}
check('every_frozen_path_matches',all(v['matched'] for v in hashes.values()),len(hashes))
check('proof_hash_matches',sha(ROOT/'reports/PROOF.txt')==freeze['proof_sha256'])
check('toy_report_hash_matches',sha(ROOT/'reports/TOYS.json')==freeze['toy_sha256'])
check('start_commits_freeze_hash',started['freeze_sha256']==sha(ROOT/'freeze/PRE_RUN_FREEZE.json'))
check('finish_commits_raw_results',finished['results_sha256']==sha(ROOT/'raw/results.jsonl'))
check('timestamp_chain_consistent',protocol['utc']<freeze['utc']<started['utc']<finished['utc'])
check('runner_verified_all_science_input_schedule_paths',set(started['verified_paths'])=={p for p in freeze['sha256'] if p.startswith(('source/','input/','freeze/'))})
write('HASH_AUDIT.json',{'files':hashes,'proof_hash':sha(ROOT/'reports/PROOF.txt'),'toy_report_hash':sha(ROOT/'reports/TOYS.json'),'results_hash':sha(ROOT/'raw/results.jsonl'),'toy_states_hash_at_audit':sha(ROOT/'raw/toy_states.jsonl'),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'note':'Self-authored timestamp chain is consistent; this is not external preregistration or a trusted timestamp service. toy_states.jsonl and OFFICIAL_READ_ONLY.json were not individually pre-run frozen.'})
inputs={p.stem:read(p) for p in sorted((ROOT/'input').glob('*.json'))}
rows=[json.loads(s) for s in (ROOT/'raw/results.jsonl').read_text().splitlines()]
check('exact_24_input_files',len(inputs)==24)
check('exact_72_schedule_and_raw_calls',len(rows)==len(schedule)==72 and finished['calls']==72)
check('raw_order_equals_frozen_schedule',[{'instance_id':r['instance_id'],'arm':r['arm']} for r in rows]==schedule)
check('each_input_three_arms',collections.Counter(r['instance_id'] for r in rows)=={i:3 for i in inputs} and all(len({r['arm'] for r in rows if r['instance_id']==i})==3 for i in inputs))
check('raw_input_hash_matches',all(r['input_sha256']==sha(ROOT/'input'/f"{r['instance_id']}.json") for r in rows))
check('all_outcomes_retained',all(r['status'] in ['INITFAIL','SUCCESS'] for r in rows) and not (ROOT/'raw/ABORTED.json').exists())
# Independently rebuild deterministic data in memory, never call generation or solvers.
triples=[(a,b,90-a-b) for a in range(1,89) for b in range(1,90-a)]
regen=[]
for ident,x in inputs.items():
 n=x['n'];Q=x['capacity'];fi=protocol['families'].index(x['family']);rep=x['replicate']-1
 seed=protocol['base_seed']+100000*n+1000*Q+100*fi+rep
 rng=random.Random(seed);coords=[[rng.uniform(0,100),rng.uniform(0,100)] for _ in range(n+1)]
 if fi==0:
  ds=[40,40,40,30,30,30,20,20,20]*(n//9);gs=[[j+i,j+i+3,j+i+6] for j in range(1,n+1,9) for i in range(3)]
 else:
  rng=random.Random(seed+100000000);ds=[d for _ in range(n//3) for d in rng.choice(triples)];gs=[list(range(j,j+3)) for j in range(1,n+1,3)]
 perm=list(range(1,n+1));random.Random(seed+200000000).shuffle(perm);demand=[0]*(n+1)
 for old,new in enumerate(perm,1):demand[new]=ds[old-1]
 witness=read(ROOT/'witness'/f'{ident}.json')
 ok=x['demands']==demand and x['coordinates']==coords and witness['groups']==[[perm[j-1] for j in g] for g in gs]
 regen.append({'instance_id':ident,'reproduced_from_frozen_seed':ok,'slack':x['K']*Q-sum(demand),'min_positive_demand':min(demand[1:])})
check('all_input_and_witness_generation_reproduces',all(r['reproduced_from_frozen_seed'] for r in regen))
check('all_positive_integer_demands_slack',all(all(type(d)==int and d>0 for d in x['demands'][1:]) and x['K']*x['capacity']>sum(x['demands']) for x in inputs.values()))
write('GENERATION_AUDIT.json',regen)
# Independent route and witness checking; no original audit.py imports.
def route_check(x,routes,claimed=None):
 errors=[];flat=[];loads=[];cost=0.;edges=[]
 if not isinstance(routes,list) or len(routes)>x['K']:return {'accepted':False,'errors':['route_container_or_K']}
 for r in routes:
  if not isinstance(r,list) or len(r)<3 or r[0]!=0 or r[-1]!=0 or any(type(j)!=int or not 1<=j<=x['n'] for j in r[1:-1]):errors.append('route_format');continue
  flat.extend(r[1:-1]);load=sum(x['demands'][j] for j in r[1:-1]);loads.append(load)
  if load>x['capacity']:errors.append('capacity')
  for a,b in zip(r,r[1:]):edges.append(math.dist(x['coordinates'][a],x['coordinates'][b]))
 if sorted(flat)!=list(range(1,x['n']+1)):errors.append('customer_exact_cover')
 cost=math.fsum(edges)
 if claimed is not None and (not isinstance(claimed,(int,float)) or not math.isfinite(claimed) or not math.isclose(cost,claimed,rel_tol=1e-10,abs_tol=1e-8)):errors.append('cost')
 return {'accepted':not errors,'errors':errors,'loads':loads,'cost':cost,'route_count':len(routes),'objective_edges':len(edges),'cost_residual':None if claimed is None else cost-claimed}
outputs=[];witnesses=[]
for ident,x in inputs.items():
 w=read(ROOT/'witness'/f'{ident}.json');c=route_check(x,[[0,*g,0] for g in w['groups']]);c['instance_id']=ident;witnesses.append(c)
for i,r in enumerate(rows):
 if r['status']=='SUCCESS':
  c=route_check(inputs[r['instance_id']],r['output']['routes'],r['output']['reported_cost']);c.update({'row_index':i,'instance_id':r['instance_id'],'arm':r['arm']});outputs.append(c)
 else:check('failed_output_is_null_'+str(i),r['output'] is None)
check('all_24_independent_feasibility_witnesses_legal',len(witnesses)==24 and all(c['accepted'] for c in witnesses))
check('all_36_success_outputs_legal',len(outputs)==36 and all(c['accepted'] for c in outputs))
write('WITNESS_AUDIT.json',witnesses);write('OUTPUT_AUDIT.json',outputs)
# Verify every recorded prune as a sound, reachable partial-state obstruction.
prunes=[]
for ri,r in enumerate(rows):
 x=inputs[r['instance_id']];d=x['demands'];diag=r['initialization'];p=diag.get('capacity_partition')
 check('delta_ledger_'+str(ri),r['deltas']==sum(r['delta_by_kind'].values()) and r['delta_by_kind']['savings']==x['n']*(x['n']-1)//2 and r['delta_by_kind']['removal']==0 and r['deltas']<=protocol['delta_limit'] and r['matrix_distances']==(x['n']+1)**2)
 check('objective_edge_ledger_'+str(ri),r['objective_edges']==(sum(len(z)-1 for z in r['output']['routes']) if r['output'] is not None else 0))
 if not p:continue
 check('partition_budget_semantics_'+str(ri),0<p['nodes']<=256 and p['node_limit']==256 and p['mathematical_infeasibility_claim'] is False and (not p['limit_reached'] or p['nodes']==256))
 if r['status']=='INITFAIL':check('failure_is_truncation_'+str(ri),p['outcome']=='NODE_LIMIT' and p['limit_reached'] and p['groups'] is None)
 else:
  check('successful_partition_legal_'+str(ri),p['outcome']=='FOUND' and not p['limit_reached'] and route_check(x,[[0,*g,0] for g in p['groups']])['accepted'])
  check('partition_insertion_delta_'+str(ri),p['route_insertion_deltas']==sum(len(g)*(len(g)+1)//2 for g in p['groups']))
 if r['arm']!='capacity_solver':
  check('guard_includes_every_nonterminal_admitted_node_'+str(ri),p['guard_checks']==p['nodes']-(r['status']=='SUCCESS'))
  check('prune_trace_count_'+str(ri),p['prunes']==len(p['prune_trace']))
  ids=[t['entered_node'] for t in p['prune_trace']]
  check('prunes_counted_within_node_limit_'+str(ri),ids==sorted(set(ids)) and all(1<=z<=p['nodes'] for z in ids))
 if r['arm']=='pruned_solver':check('tight_guard_inactive_positive_slack_'+str(ri),p['tight_checks']==p['residual_checks']==p['prunes']==0)
 if r['arm']=='waste_solver':check('waste_scan_counter_'+str(ri),p['waste_checks']==p['guard_checks'] and p['residual_checks']==x['K']*p['guard_checks'])
 for t in p.get('prune_trace',[]):
  ids=[j for g in t['groups'] for j in g];expected_order=sorted(range(1,len(d)),key=lambda j:(-d[j],j));depth=t['depth']
  rem=t['remaining'];rs=t['residual'];U=sum(rs)-sum(rem);m=min(z for z in rem if z>0);W=sum(z for z in rs if 0<z<m)
  state_ok=(len(t['groups'])==len(rs)==x['K'] and len(ids)==depth and sorted(ids)==sorted(expected_order[:depth]) and rem==[d[j] for j in expected_order[depth:]] and rs==[x['capacity']-sum(d[j] for j in g) for g in t['groups']] and min(rs)>=0 and U==x['K']*x['capacity']-sum(d))
  prunes.append({'row_index':ri,'instance_id':r['instance_id'],'entered_node':t['entered_node'],'depth':depth,'U':U,'W':W,'m':m,'state_valid':state_ok,'sound_necessary_rejection':U<0 or W>U})
check('all_1131_recorded_prunes_sound_and_state_valid',len(prunes)==1131 and all(t['state_valid'] and t['sound_necessary_rejection'] for t in prunes))
write('PRUNE_AUDIT.json',prunes)
# Whole-module AST invariance outside partition/helper including imports/constants.
source_text={a:(ROOT/'source'/f'{a}.py').read_text() for a in protocol['arms']}
def invariant_tree(s):
 tree=ast.parse(s);tree.body=[n for n in tree.body if not isinstance(n,(ast.FunctionDef,ast.ClassDef)) or n.name not in ['bounded_partition','tight_capacity_test','waste_capacity_test']]
 return ast.dump(tree,include_attributes=False)
check('whole_module_identical_except_partition_and_helper',len(set(invariant_tree(s) for s in source_text.values()))==1)
for arm in protocol['arms'][1:]:
 (OUT/f'capacity_vs_{arm}.diff').write_text(''.join(difflib.unified_diff(source_text['capacity_solver'].splitlines(keepends=True),source_text[arm].splitlines(keepends=True),fromfile='capacity_solver.py',tofile=arm+'.py')))
# Official cases: use recorded paths, independently read exact source inputs.
official=[]
for o in read(ROOT/'reports/OFFICIAL_READ_ONLY.json'):
 x=read(Path(o['input_path']));K=o['K'];ds=x['demands'][1:];m=min(ds);U=K*x['capacity']-sum(ds);upper=K*(m-1)
 official.append({'name':o['name'],'K':K,'m':m,'U':U,'W_upper':upper,'never_triggers':upper<=U,'input_hash_matches':sha(Path(o['input_path']))==o['input_sha256'],'record_matches':(o['min_demand'],o['U'],o['W_upper'],o['never_triggers'])==(m,U,upper,upper<=U),'positive_integer_demands':all(type(d)==int and d>0 for d in ds)})
check('all_nine_official_cases_bound_inactive',len(official)==9 and all(x['never_triggers'] and x['input_hash_matches'] and x['record_matches'] and x['positive_integer_demands'] for x in official))
write('OFFICIAL_AUDIT.json',official)
# Pair and aggregate results, preserving full denominators.
agg=[];pairs=[]
for arm in protocol['arms']:
 ar=[r for r in rows if r['arm']==arm];parts=[r['initialization']['capacity_partition'] for r in ar if 'capacity_partition' in r['initialization']]
 agg.append({'arm':arm,'calls':len(ar),'successes':sum(r['status']=='SUCCESS' for r in ar),'failures':sum(r['status']=='INITFAIL' for r in ar),'fallbacks':len(parts),'entered_nodes':sum(p['nodes'] for p in parts),'prunes':sum(p.get('prunes',0) for p in parts),'deltas':sum(r['deltas'] for r in ar),'measured_cpu_sum':sum(r['measured_cpu_seconds'] for r in ar),'measured_wall_sum':sum(r['measured_wall_seconds'] for r in ar),'solver_cpu_sum':sum(r['solver_cpu_seconds'] for r in ar),'partition_cpu_sum':sum(p['cpu_seconds'] for p in parts),'partition_wall_sum':sum(p['wall_seconds'] for p in parts),'zero_measured_cpu_count':sum(r['measured_cpu_seconds']==0 for r in ar)})
for ident in inputs:
 rr={r['arm']:r for r in rows if r['instance_id']==ident};a=rr['capacity_solver'];b=rr['pruned_solver'];c=rr['waste_solver']
 check('same_savings_state_'+ident,a['initialization']['savings_routes']==b['initialization']['savings_routes']==c['initialization']['savings_routes'])
 check('baseline_tight_same_outputs_'+ident,a['status']==b['status'] and a['output']==b['output'])
 if inputs[ident]['family']=='random_witness':check('random_all_same_outputs_'+ident,a['status']==c['status'] and a['output']==c['output'])
 pairs.append({'instance_id':ident,'baseline':a['status'],'tight':b['status'],'waste':c['status'],'rescued':a['status']!='SUCCESS' and c['status']=='SUCCESS','lost':a['status']=='SUCCESS' and c['status']!='SUCCESS'})
check('exact_three_rescues_zero_losses',sum(r['rescued'] for r in pairs)==3 and not any(r['lost'] for r in pairs))
summary=read(ROOT/'reports/SUMMARY.json')
check('parent_aggregate_matches',all(next(x for x in summary if x['arm']==a['arm'] and 'family' not in x)['success']==a['successes'] and next(x for x in summary if x['arm']==a['arm'] and 'family' not in x)['entered_nodes']==a['entered_nodes'] for a in agg))
write('RESULT_AUDIT.json',{'aggregates':agg,'paired':pairs,'controlled_structural_demand_multisets':len({(x['capacity'],tuple(sorted(x['demands'][1:]))) for x in inputs.values() if x['family']=='controlled'}),'controlled_instances':12,'caveat':'Three rescues are label/geometry replicates of one demand multiset/capacity structure, not three distinct capacity structures.'})
check('frozen_files_still_unchanged_after_audit',all(sha(ROOT/p)==h for p,h in freeze['sha256'].items()))
write('CHECKS.json',{'passed':all(x['passed'] for x in checks),'check_count':len(checks),'failures':[x for x in checks if not x['passed']],'checks':checks})
print(json.dumps({'passed':all(x['passed'] for x in checks),'checks':len(checks),'failed':[x for x in checks if not x['passed']],'outputs':len(outputs),'witnesses':len(witnesses),'prunes':len(prunes)},indent=2))
