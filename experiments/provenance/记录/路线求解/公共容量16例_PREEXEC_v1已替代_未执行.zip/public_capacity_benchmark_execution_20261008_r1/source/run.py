"""Serial exactly-once runner. Requires explicit archival verification gate."""
import os,sys,json,subprocess,resource,signal,time,math,hashlib,datetime
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):
 with p.open('x') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
if '--execute-authorized' not in sys.argv:raise SystemExit('Execution requires authorization and verified private snapshot.')
gate=ROOT/'freeze/PRIVATE_SNAPSHOT_VERIFIED.json'
if not gate.exists() or not json.loads(gate.read_text()).get('download_sha256_matches'):raise SystemExit('Private snapshot verification missing.')
freeze=json.loads((ROOT/'freeze/PRE_RUN_FREEZE.json').read_text())
for x in freeze['files']:
 p=ROOT/x['path']
 if not p.is_file() or p.stat().st_size!=x['bytes'] or sha(p)!=x['sha256']:raise SystemExit('Frozen bytes mismatch: '+x['path'])
resource.setrlimit(resource.RLIMIT_CPU,(120,120));resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3));signal.alarm(240)
schedule=json.loads((ROOT/'freeze/SCHEDULE.json').read_text());assert len(schedule)==96
cpu0=time.process_time();wall0=time.perf_counter();r0=resource.getrusage(resource.RUSAGE_CHILDREN);child0=r0.ru_utime+r0.ru_stime;cpus=[]
dump(ROOT/'raw/STARTED.json',{'utc':utc(),'claim_namespace':'public-capacity-initialization-20261008-r1','calls_scheduled':len(schedule),'freeze_sha256':sha(ROOT/'freeze/PRE_RUN_FREEZE.json'),'snapshot_gate':json.loads(gate.read_text()),'children_cpu_initial':child0,'clock_info':{s:{k:getattr(time.get_clock_info(s),k) for k in ['implementation','monotonic','adjustable','resolution']} for s in ['process_time','perf_counter']},'execution':'serial exactly once, no reference data accessible by child audit allowlist'})
with (ROOT/'raw/results.jsonl').open('x') as f:
 for item in schedule:
  ru=resource.getrusage(resource.RUSAGE_CHILDREN);total=time.process_time()-cpu0+ru.ru_utime+ru.ru_stime-child0
  if total>118 or time.perf_counter()-wall0>237:
   dump(ROOT/'raw/ABORTED.json',{'utc':utc(),'next_call':item,'reason':'global budget','total_cpu':total,'wall':time.perf_counter()-wall0,'no_retry':True});raise SystemExit(2)
  before=resource.getrusage(resource.RUSAGE_CHILDREN);w=time.perf_counter();timeout=False
  p=subprocess.Popen([sys.executable,'-B',str(ROOT/'source/call_once.py'),json.dumps(item)],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,env={'PATH':os.defpath,'PYTHONDONTWRITEBYTECODE':'1','LANG':'C.UTF-8'})
  try:stdout,stderr=p.communicate(timeout=2)
  except subprocess.TimeoutExpired:p.kill();stdout,stderr=p.communicate();timeout=True
  after=resource.getrusage(resource.RUSAGE_CHILDREN)
  op=ROOT/'raw/calls'/f"{item['call_id']}.stdout";ep=ROOT/'raw/calls'/f"{item['call_id']}.stderr"
  with op.open('x') as h:h.write(stdout)
  with ep.open('x') as h:h.write(stderr)
  try:
   record=json.loads(stdout) if p.returncode==0 else None
   if record is None:raise ValueError('nonzero subprocess exit')
  except Exception as e:
   record={**item,'status':'WALL_LIMIT' if timeout or p.returncode==-14 else ('CPU_LIMIT_OR_KILL' if p.returncode in [-9,-24] else 'PROCESS_ERROR'),'groups':None,'output':None,'diagnostic':None,'input_sha256':sha(ROOT/'input'/f"{item['instance_id']}.json"),'error':{'exception':repr(e),'stderr':stderr}}
  c=after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime;cpus.append(c)
  record.update(process_returncode=p.returncode,process_cpu_seconds=c,process_wall_seconds=time.perf_counter()-w,children_maxrss_KiB=after.ru_maxrss,stdout_sha256=sha(op),stderr_sha256=sha(ep))
  f.write(json.dumps(record,allow_nan=False)+'\n');f.flush();os.fsync(f.fileno())
  if len(cpus)%24==0:print(len(cpus),'calls saved',flush=True)
ru=resource.getrusage(resource.RUSAGE_CHILDREN)
dump(ROOT/'raw/FINISHED.json',{'utc':utc(),'calls':len(cpus),'parent_cpu_seconds':time.process_time()-cpu0,'children_cpu_initial':child0,'children_cpu_final_absolute':ru.ru_utime+ru.ru_stime,'children_cpu_seconds':ru.ru_utime+ru.ru_stime-child0,'sum_per_call_child_cpu':math.fsum(cpus),'wall_seconds':time.perf_counter()-wall0,'children_maxrss_KiB':ru.ru_maxrss,'results_sha256':sha(ROOT/'raw/results.jsonl'),'no_reruns':True})
print('96 calls sealed.',flush=True)
