# Independent read-only audit

Start with REPORT_ZH.md, INDEPENDENT_REVIEW.json and EXIT_RESOURCE.json.

To recheck existing evidence without executing a solver: python -B audit.py /path/to/vrp_operator_restart_ablation_20261008

Standard library only. The script imports no experiment code and does not run a solver. Recorded historical source and registry paths are checked when reachable in this workspace; a portable copy without those historical paths will need those evidence roots for complete provenance verification. Both completed audit executions were read-only with respect to the scientific package and used separate resource accounting. No audit finding required changing the experiment.
