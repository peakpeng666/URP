"""Independent read-only evidence audit. Never imports or runs any solver."""
from pathlib import Path
import collections,csv,datetime,hashlib,itertools,json,math,random,resource,statistics,sys,time,zipfile
START=time.perf_counter(); CPU=time.process_time(); resource.setrlimit(resource.RLIMIT_CPU,(15,15))
ROOT=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/workspace/shared/vrp_operator_restart_ablation_20261008')
OUT=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
errors=[];checks=collections.Counter()
def ck(ok,label,detail=None):
    checks[label]+=1
    if not ok:errors.append({'check':label,'detail':detail})
def near(a,b):return math.isclose(a,b,rel_tol=1e-10,abs_tol=1e-9)
def route(inst,out,label):
    seen=[];cost=[];valid=True;loads=[]
    for r in out['routes']:
        valid &= len(r)>=3 and r[0]==r[-1]==0 and all(type(x) is int and 1<=x<=50 for x in r[1:-1])
        seen+=r[1:-1];loads.append(sum(inst['demands'][x] for x in r[1:-1]))
        for a,b in zip(r,r[1:]):
            x,y=inst['coordinates'][a],inst['coordinates'][b];cost.append(math.sqrt((x[0]-y[0])**2+(x[1]-y[1])**2))
    value=math.fsum(cost)
    ck(valid and sorted(seen)==list(range(1,51)) and max(loads)<=30 and near(value,out['reported_cost']),'coordinate_solution',label)
    return value
cfg=read(ROOT/'freeze/PROTOCOL.json'); schedule=read(ROOT/'freeze/SCHEDULE.json'); manifest=read(ROOT/'freeze/INPUT_MANIFEST.json')
rows=[json.loads(x) for x in (ROOT/'raw/TRAJECTORIES.jsonl').read_text().splitlines()]
for fn in ['PRE_GENERATION_FREEZE.json','PRE_RUN_FREEZE.json']:
    freeze=read(ROOT/'freeze'/fn)
    for p,h in freeze['sha256'].items():ck(sha(ROOT/p)==h,'frozen_sha256',p)
for line in (ROOT/'SHA256SUMS.txt').read_text().splitlines():
    h,p=line.split('  ',1);ck(sha(ROOT/p)==h,'package_sha256',p)
for x in read(ROOT/'MANIFEST.json')['files']:ck(sha(ROOT/x['path'])==x['sha256'] and (ROOT/x['path']).stat().st_size==x['bytes'],'manifest',x['path'])
for x in read(ROOT/'freeze/SOURCE_PROVENANCE.json'):
    if x['byte_identical']:ck(sha(Path(x['source']))==sha(ROOT/x['path'])==x['source_sha256'],'legacy_byte_identical',x['path'])
old=read(ROOT/'freeze/OLD_GEOMETRIES.json')
for x in old['sources']:ck(sha(Path(x['path']))==x['sha256'],'old_registry_hash',x['path'])
insts={e['input_file']:read(ROOT/e['input_file']) for e in manifest}; geom=collections.defaultdict(list)
for e in manifest:
    inst=insts[e['input_file']];h=hashlib.sha256(json.dumps(inst['coordinates'],separators=(',',':')).encode()).hexdigest();geom[e['geometry_id']].append(h)
    ck(h==e['coordinate_sha256'] and h not in old['coordinate_hashes'] and e['geometry_seed'] not in old['geometry_seeds'],'fresh_geometry',e['geometry_id'])
    ck(len(inst['coordinates'])==51 and inst['capacity']==30 and inst['demands'][0]==0 and sum(inst['demands'])==250,'input_dimensions',e['input_file'])
    ck(sorted(inst['demands'][1:])==([5]*50 if e['demand_mode']=='constant5' else [1]*25+[9]*25),'demand_pattern',e['input_file'])
ck(len(geom)==16 and len(set(hs[0] for hs in geom.values()))==16 and all(len(hs)==2 and len(set(hs))==1 for hs in geom.values()),'paired_distinct_geometries')
expected=set(itertools.product(geom,cfg['demand_modes'],cfg['search_seeds'],cfg['repairs'],[False,True]))
observed=[(r['geometry_id'],r['demand_mode'],r['search_seed'],r['repair'],r['restart_on']) for r in rows]
ck(len(rows)==len(schedule)==len(set(r['run_id'] for r in rows))==256 and set(observed)==expected,'factorial_completeness')
freeze=read(ROOT/'freeze/PRE_RUN_FREEZE.json');ck(freeze['utc']<read(ROOT/'raw/STARTED.json')['utc']<rows[0]['started_utc'],'freeze_chronology')
costs=collections.defaultdict(list); baseline={}; restart_total=0;completed_restart_total=0;partial_restarts=0;cp_partial_restarts=0;termination=collections.Counter();route_counts=[]
for call,r in zip(schedule,rows):
    rid=r['run_id'];ck(all(r[k]==v for k,v in call.items()),'schedule_identity',rid)
    ck(r['status']=='executed' and r['stop_reason']=='delta_budget' and r['error'] is None and r['missing_budgets']==[],'raw_status',rid);termination[r['stop_reason']]+=1
    inst=insts[r['input_file']];b=route(inst,r['baseline'],[rid,'baseline']);route_counts.append(len(r['baseline']['routes']))
    if r['input_file'] in baseline:ck(baseline[r['input_file']]==r['baseline'],'common_initial_solution',rid)
    else:baseline[r['input_file']]=r['baseline']
    cur=best=b;stagnation=0;prev=1225;iterations=0;restarts=[];accepted=0
    for ev in r['trace']:
        ck(ev['deltas']>prev,'strict_delta_trace',rid)
        if ev['event']=='restart':
            ck(r['restart_on'] and stagnation==8 and ev['restart_id']==len(restarts) and ev['deltas_before']==prev,'restart_trigger',rid)
            improved=ev['current_cost']<best-1e-9;ck(improved==ev['best_improved'],'restart_best_rule',rid)
            cur=ev['current_cost'];best=min(best,cur);stagnation=0;restarts.append(ev);accepted+=int(improved)
        else:
            ck(ev['iteration']==iterations and 5<=ev['q']<=15,'iteration_order',rid);iterations+=1
            ac=ev['candidate_cost']<cur-1e-9;bi=ev['candidate_cost']<best-1e-9
            ck(ac==ev['accepted_current'] and bi==ev['best_improved'],'acceptance_rule',rid)
            cur=ev['candidate_cost'] if ac else cur;best=min(best,ev['candidate_cost']);stagnation=0 if ac else stagnation+1;accepted+=int(bi)
            ck(stagnation==ev['stagnation'],'stagnation_counter',rid)
        ck(near(cur,ev['current_cost']) and near(best,ev['best_cost']),'current_best_trace',rid);prev=ev['deltas']
    unfinished=r['restart_started']-r['restart_completed'];partial_restarts+=unfinished;completed_restart_total+=len(restarts)
    ck(unfinished in (0,1) and len(restarts)==r['restart_completed'] and iterations==r['iterations_completed'] and near(cur,r['current_cost']) and accepted==r['accepted_improvements'],'final_state',rid)
    if unfinished:ck(r['restart_on'] and stagnation==8,'partial_restart_trigger',rid)
    intervals=[(x['deltas_before'],x['deltas']) for x in restarts]+([(prev,160000)] if unfinished else [])
    prior=b
    for cp in r['checkpoints']:
        B=cp['budget'];v=route(inst,cp['output'],[rid,B]);route_counts.append(len(cp['output']['routes']))
        ck(cp['deltas']==B==sum(cp['delta_by_kind'].values()) and cp['delta_by_kind']=={'savings':1225,'removal':0,'insertion':B-1225} and cp['matrix_distances']==2601 and cp['scoreable'],'checkpoint_ledger',rid)
        counted=sum(max(0,min(B,end)-start) for start,end in intervals)
        ck(counted==cp['restart_insertion_deltas'],'restart_exact_delta_intervals',[rid,B,counted,cp['restart_insertion_deltas']])
        cp_partial_restarts+=int(cp['restart_started']>cp['restart_completed'])
        hist=[e['best_cost'] for e in r['trace'] if e['deltas']<=B];ck(v<=prior+1e-8 and near(v,hist[-1] if hist else b),'checkpoint_historical_best',[rid,B]);prior=v
        costs[r['geometry_id'],r['demand_mode'],B,r['algorithm']].append(v)
    ck(r['deltas']==160000 and r['output']==r['checkpoints'][-1]['output'],'final_budget_incumbent',rid)
    ck(r['restart_insertion_deltas']==sum(end-start for start,end in intervals),'final_restart_ledger',rid);restart_total+=r['restart_insertion_deltas']
    if not r['restart_on']:ck(r['restart_started']==r['restart_completed']==r['restart_insertion_deltas']==0,'off_has_no_restart',rid)
smoke=read(ROOT/'raw/SMOKE_EQUIVALENCE.json')
for t in smoke['tests']:ck(t['passed'] and t['ablation_output']==t['legacy_output'] and t['ablation_ledger']==t['legacy_ledger'] and sum(t['ablation_ledger'].values())==t['budget'],'recorded_smoke_equivalence',[t['repair'],t['budget']])
ck(len(smoke['tests'])==4 and smoke['all_passed'],'smoke_completeness')
# Independent paired aggregation and identical prespecified block resampling.
means={k:math.fsum(v)/len(v) for k,v in costs.items()};effects=collections.defaultdict(dict);family={r['geometry_id']:r['family'] for r in rows}
for g in sorted(geom):
    for B in cfg['checkpoints']:
        vals=collections.defaultdict(list)
        for d in cfg['demand_modes']:
            co,ro,cr,rr=[means[g,d,B,a] for a in ['cheapest_off','regret2_off','cheapest_restart','regret2_restart']]
            ds={'operator_without_restart':100*(co-ro)/co,'restart_effect_cheapest':100*(co-cr)/co,'restart_effect_regret2':100*(ro-rr)/ro,'operator_with_restart':100*(cr-rr)/cr,'factorial_interaction':100*((co-ro)-(cr-rr))/co}
            for k,v in ds.items():vals[k].append(v)
        for k,v in vals.items():effects[B,k][g]=math.fsum(v)/2
rng=random.Random(cfg['bootstrap_seed']);blocks=[[g for g in sorted(geom) if family[g]==f] for f in cfg['families']]
samples=[[rng.choice(block) for block in blocks for _ in range(len(block))] for i in range(10000)]
def pct(xs,q):
    a=sorted(xs);p=(len(a)-1)*q;i=int(p);return a[i]+(a[min(i+1,len(a)-1)]-a[i])*(p-i)
reported=read(ROOT/'reports/SUMMARY.json')['contrasts']; recomputed=[]
for rep in reported:
    B,k=rep['budget'],rep['contrast'];v=effects[B,k];boots=[math.fsum(v[g] for g in smp)/16 for smp in samples]
    got={'budget':B,'contrast':k,'geometry_count':16,'mean_percent':math.fsum(v.values())/16,'ci_low':pct(boots,.025),'ci_high':pct(boots,.975),'wins':sum(x>1e-9 for x in v.values()),'ties':sum(abs(x)<=1e-9 for x in v.values()),'losses':sum(x< -1e-9 for x in v.values())}
    ck(all(near(got[n],rep[n]) for n in ['mean_percent','ci_low','ci_high']) and all(got[n]==rep[n] for n in ['geometry_count','wins','ties','losses']),'paired_geometry_statistics',[B,k]);recomputed.append(got)
    effects[B,k]=v
for fn in ['PREPARE_RESOURCE.json','RUN_RESOURCE.json','ANALYZE_RESOURCE.json']:
    r=read(ROOT/'raw'/fn);ck(r['exit_code']==0 and not r['wall_timeout'] and r['wall_seconds']<=r['wall_limit_seconds'] and r['child_total_cpu_seconds']<=r['cpu_hard_limit_seconds'],'exit_resource',fn)
resource_record=read(ROOT/'raw/RUN_RESOURCE.json');fail=read(ROOT/'failures/FAILURES.json');ck(fail['count']==0 and fail['rows']==[] and fail['retries']==0,'failure_receipt')
receipt=read(ROOT.parent/(ROOT.name+'_archive_receipt.json'));ck(sha(Path(receipt['archive']))==receipt['sha256'] and Path(receipt['archive']).stat().st_size==receipt['bytes'],'archive_receipt')
with zipfile.ZipFile(receipt['archive']) as z:
    ck(z.testzip() is None,'zip_crc')
    for name in z.namelist():
        ck(z.read(name)==(ROOT.parent/name).read_bytes(),'archive_current_content',name)
final_zip=ROOT.parent/(ROOT.name+'_final.zip')
if final_zip.exists():
    final_receipt=read(ROOT.parent/(ROOT.name+'_final_archive_receipt.json'))
    ck(sha(final_zip)==final_receipt['sha256'] and final_zip.stat().st_size==final_receipt['bytes'],'final_archive_receipt')
    for item in read(ROOT/'DELIVERY_MANIFEST.json')['files']:
        ck(sha(ROOT/item['path'])==item['sha256'] and (ROOT/item['path']).stat().st_size==item['bytes'],'delivery_manifest',item['path'])
    with zipfile.ZipFile(final_zip) as z:
        ck(z.testzip() is None,'final_zip_crc')
        for p in ROOT.rglob('*'):
            if p.is_file():ck(z.read(str(p.relative_to(ROOT.parent)))==p.read_bytes(),'final_archive_current_content',str(p.relative_to(ROOT)))
result={'audit_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_WITH_LIMITATIONS' if not errors else 'FAIL','source_root':str(ROOT),'solver_executions':0,'source_static_review':{'source/ablation.py:5-14':'Restart uses legacy route_options with same live budget, no new evaluation ledger.','source/ablation.py:23-27':'restart_insertion_deltas increments only after successful inherited delta charge.','source/ablation.py:37-50':'Only completed reconstruction replaces current, historical best retained; stagnation gate is frozen at 8.','source/ablation.py:53-74':'Off arm keeps original q/removal/repair/acceptance stream and tie tolerance; current equals best without restart.','source/legacy/experiment.py:route_options':'Singleton route always offered when demand <= capacity; no fixed-K cap.','source/legacy/experiment.py:matrix_for,cost_of':'Unrounded Euclidean edge distances and math.fsum objective.'},'scientific_output_copied':False,'independent_math':'Direct original coordinates, demands, raw route outputs, trace transitions and interval accounting; no experiment module imported. Statistics recomputed from these audited outputs.','errors':errors,'checks':dict(checks),'checks_total':sum(checks.values()),'formal_trajectories':len(rows),'geometry_units':len(geom),'route_outputs_checked':checks['coordinate_solution'],'route_count_range':[min(route_counts),max(route_counts)],'fleet_model':'Unlimited homogeneous fleet, capacity 30; no fixed-K constraint.','stop_reasons':dict(termination),'total_formal_deltas':sum(r['deltas'] for r in rows),'restart_insertion_deltas':restart_total,'completed_restarts':completed_restart_total,'final_interrupted_restarts':partial_restarts,'checkpoints_in_partial_restart':cp_partial_restarts,'recomputed_contrasts':recomputed,'main_resource':resource_record,'audit_resource':{'cpu_seconds':time.process_time()-CPU,'wall_seconds':time.perf_counter()-START,'cpu_limit_seconds':15,'charged_separately_from_main':True,'new_model_calls':0,'new_paid_calls':0,'purchased_resources':0,'platform_billing_exposed':False},'limitations':['Recorded four n6 no-restart smoke outputs and ledgers were compared, not independently re-executed; small one-route smoke cannot establish general equivalence by testing alone. Static code review supports unchanged off-arm semantics.','Delta accounting is not FLOPs, equal CPU or full-objective evaluations.','Budget-termination traces are verified; CPU/wall/failure branches were not fault-injected. No run actually failed or was globally interrupted.','Freshness is relative to the frozen registered old geometry hashes and seeds, not all possible past data.','Only 16 geometry units from two existing synthetic families; secondary contrasts unadjusted. No fixed-K, SOTA, or general restart claim supported.']}
(OUT/'INDEPENDENT_REVIEW.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
report=['# 独立复核：算子 × 停滞重启消融','',f"结论：{result['status']}。未运行或导入solver；从原始输入与raw独立复算，共{result['checks_total']}项检查，错误{len(errors)}项。",'',f"- 256/256轨迹、512检查点齐全；统计单位是16个几何，按两族各8块重采样。768个基线/检查点解直接复核客户覆盖、容量和未舍入欧氏目标。",f"- 所有轨迹恰160,000 delta，合计{result['total_formal_deltas']:,}；重启插入真实消耗{restart_total:,}次并包含在总预算内。完成重启{completed_restart_total}次，最终中断重启{partial_restarts}次，中间或最终检查点落入重启过程{cp_partial_restarts}次；未提交未完成重构，始终保留历史最优。",'- 连续8次完整候选未改善当前解触发重启；trace状态转移、每次重启区间费用与计数器一致。无重启的旧/新n6 smoke记录4/4逐内容与ledger一致；此次不重跑，较小单路线smoke只提供有限动态覆盖。','- 冻结源码、输入、登记旧数据、包清单及压缩包逐项hash/内容核验通过。主流程退出0，raw无失败、无丢失、无补样。CPU/墙中断分支没有故障注入。',f"- 主运行CPU {resource_record['child_total_cpu_seconds']:.6f}秒，墙时{resource_record['wall_seconds']:.6f}秒。独审脚本CPU {result['audit_resource']['cpu_seconds']:.6f}秒、墙时{result['audit_resource']['wall_seconds']:.6f}秒，独立计费/计时，不侵占主预算；无新模型/API/付费调用，底层平台账单不可见。",'', '## 独立复算160k结果']
for r in recomputed:
    if r['budget']==160000:report.append(f"- {r['contrast']}：{r['mean_percent']:.6f}%；95%区间[{r['ci_low']:.6f}, {r['ci_high']:.6f}]；{r['wins']}胜/{r['ties']}平/{r['losses']}负。")
report+=['','无重启regret2在16几何均优于cheapest；这一条固定重启规则在此预算下总体变差。交互区间跨0，不能声称一般机制因果或重启普遍无效。','', '限制：旧核是无限同质车辆、容量30，并非固定K；等delta不等CPU/FLOP/整解评价。范围仅原有两种合成族的n50、两需求与两搜索seed。新旧几何零重叠限于已登记旧集合。次要比较未校正。']
(OUT/'REPORT_ZH.md').write_text('\n'.join(report)+'\n')
print(json.dumps({'status':result['status'],'errors':errors,'checks':result['checks_total'],'audit_resource':result['audit_resource'],'restart_deltas':restart_total,'completed_restarts':completed_restart_total,'partial_restarts':partial_restarts},ensure_ascii=False))
