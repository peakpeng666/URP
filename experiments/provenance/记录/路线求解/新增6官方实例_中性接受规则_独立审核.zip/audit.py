import json, pathlib, hashlib, math, collections, time, resource, zipfile
P=pathlib.Path('/workspace/shared/official_cvrp_neutral_validation_20261008'); O=pathlib.Path(__file__).parent
resource.setrlimit(resource.RLIMIT_CPU,(30,30)); start=time.monotonic(); cpu=time.process_time(); errors=[]; checks=[]
def ck(ok,detail):
 checks.append({'check':detail,'passed':bool(ok)})
 if not ok: errors.append(detail)
def load(f):return json.loads((P/f).read_text())
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
ck(sha(P/'official_cvrp_neutral_validation_20261008.zip')=='b9fc0290fac259a3ff57b8cad61f19d492db1f00c4a7d0586f00a780d7f887db','Original ZIP SHA256')
for line in (P/'SHA256SUMS.txt').read_text().splitlines():
 h,f=line.split(None,1);ck(sha(P/f.strip())==h,'Package hash '+f)
for name in ['PRE_TOY_FREEZE','PRE_RUN_FREEZE']:
 for f,h in load('freeze/'+name+'.json')['sha256'].items():ck(sha(P/f)==h,'Freeze '+name+' '+f)
a=load('freeze/PRE_TOY_FREEZE.json'); b=load('freeze/PRE_RUN_FREEZE.json'); s=load('raw/STARTED.json')
ck(a['utc']<b['utc']<s['utc'],'Recorded freeze precedes recorded execution');ck(s['freeze_sha256']==sha(P/'freeze/PRE_RUN_FREEZE.json'),'Start links freeze')
prov=load('freeze/SOURCE_PROVENANCE.json')
for f,h in prov['unchanged_modules'].items():
 old=pathlib.Path(prov['old_package'])/'source'/f
 ck(sha(P/'source'/f)==h and old.exists() and sha(old)==h,'Byte-identical old/current '+f)
D={};refs={}
for f in (P/'input').glob('*.json'):
 d=json.loads(f.read_text());n=d['instance_id'];D[n]=d;c=d['coordinates'];d['_dist']=[[int(math.floor(math.hypot(x[0]-y[0],x[1]-y[1])+.5)) for y in c] for x in c]
 raw=(P/'provenance/dataset/raw'/ (n+'.vrp')).read_text(); coords=[];dem=[];section=''
 for line in raw.splitlines():
  line=line.strip()
  if line in ['NODE_COORD_SECTION','DEMAND_SECTION','DEPOT_SECTION']:section=line;continue
  if section=='NODE_COORD_SECTION':coords.append(list(map(int,line.split()[1:])))
  elif section=='DEMAND_SECTION':dem.append(int(line.split()[1]))
 ck(coords==c and dem==d['demands'],'Raw normalized coordinates/demands '+n)
 ck(math.ceil(sum(d['demands'])/d['capacity'])==d['K'],'Capacity lower bound equals K '+n)
 refs[n]=load('reference/'+n+'.reference_solution.json')
def valid(d,o):
 rs=o['routes'];seen=[i for r in rs for i in r[1:-1]]
 return all(r[0]==r[-1]==0 for r in rs) and sorted(seen)==list(range(1,len(d['demands']))) and len([r for r in rs if len(r)>2])<=d['K'] and all(sum(d['demands'][i] for i in r)<=d['capacity'] for r in rs) and sum(d['_dist'][i][j] for r in rs for i,j in zip(r,r[1:]))==o['reported_cost']
def canonical(o):return tuple(sorted(min(tuple(r[1:-1]),tuple(reversed(r[1:-1]))) for r in o['routes']))
for n,r in refs.items():ck(valid(D[n],{'routes':[[0]+x+[0] for x in r['routes']],'reported_cost':r['total_cost']}),'Reference independent cost/legality '+n)
rows=[json.loads(x) for x in (P/'raw/heuristics.jsonl').read_text().splitlines()]; cps=load('reports/CHECKPOINT_RESULTS.json'); keyed={(x['instance_id'],x['method'],x['search_seed'],x['acceptance_mode'],x['checkpoint']):x for x in cps}; stats=collections.defaultdict(list); trace_count=0
ck(len(rows)==96 and len({(r['instance_id'],r['method'],r['search_seed'],r['acceptance_mode']) for r in rows})==96,'96 distinct trajectories');ck(len(cps)==len(keyed)==192,'192 distinct checkpoint rows')
for r in rows:
 n=r['instance_id'];d=D[n];current=r['baseline'];best=current;last=r['initialization']['deltas_after_initialization'];counts=collections.Counter();ok=True
 ok &= valid(d,current);ok &= r['deltas']==sum(r['delta_by_kind'].values())==160000
 for t in r['trace']:
  trace_count+=1;ok &= last<=t['deltas']<=160000;last=t['deltas']; cand=t.get('candidate')
  if t['candidate_status']=='complete':
   ok &= valid(d,cand); diff=cand['reported_cost']-current['reported_cost'];eq=diff==0;distinct=canonical(cand)!=canonical(current)
   accept=diff<0 or (eq and distinct and r['acceptance_mode']=='neutral')
   ok &= accept==t['accepted']
   if eq:counts['equal_cost_candidates']+=1;counts['neutral_proposals' if distinct else 'canonical_noops']+=1
   if diff<0:counts['strict_improvements']+=1
   if eq and accept:counts['neutral_accepted']+=1
   if accept:current=cand
   if cand['reported_cost']<best['reported_cost']:best=cand
  ok &= t['current']==current and t['incumbent']==best
 ok &= r['output']==best and r['current_output']==current and all(counts[k]==v for k,v in r['neutral_counts'].items())
 ck(ok,'Trace decisions/cost/state/accounting '+str((n,r['method'],r['search_seed'],r['acceptance_mode'])))
 for cut in [40000,160000]:
  out=r['baseline']
  for t in r['trace']:
   if t['deltas']<=cut:out=t['incumbent']
  if r['deltas']<=cut:out=r['output']
  cp=keyed[(n,r['method'],r['search_seed'],r['acceptance_mode'],cut)]
  ck(cp['output']==out and cp['cost']==out['reported_cost'] and valid(d,out),'Atomic checkpoint '+str((n,r['method'],r['search_seed'],r['acceptance_mode'],cut)))
  stats[(n,r['method'],r['acceptance_mode'],cut)].append((out['reported_cost']/refs[n]['total_cost']-1)*100)
paired=[]
for n in sorted(D):
 for m in ['regret2','cheapest']:
  for cut in [40000,160000]:
   av={a:sum(stats[n,m,a,cut])/4 for a in ['strict','neutral']};paired.append(dict(instance=n,method=m,checkpoint=cut,strict_gap=av['strict'],neutral_gap=av['neutral'],difference_pp=av['neutral']-av['strict']))
agg={}
for label,ns in [('six_descriptive',list(D)),('five_prespecified',[n for n in D if n!='P-n45-k5'])]:
 z=[x for x in paired if x['instance'] in ns and x['method']=='regret2' and x['checkpoint']==160000];agg[label]={a:sum(x[a] for x in z)/len(z) for a in ['strict_gap','neutral_gap','difference_pp']}
old=pathlib.Path(prov['old_package'])/'input/P-n40-k5.json'
if old.exists():
 oc=json.loads(old.read_text())['coordinates'][1:];nc=D['P-n45-k5']['coordinates'][1:];ck(all(x in nc for x in oc),'Old P40 customer coordinates nested in P45')
result={'passed':not errors,'errors':errors,'checks_count':len(checks),'trace_entries':trace_count,'trajectories':len(rows),'checkpoints':len(cps),'paired_by_instance':paired,'aggregates':agg,'limitations':['Local archival provenance checked, no live official website revalidation.','Recorded freeze ordering and hashes verified; timestamps are not externally attested.','No solver reruns; accounting checked from trace counters and byte-identical previously audited solver, not independent recomputation of every insertion evaluation.','Seeds and checkpoints are repeated measures; six named benchmarks are not six independent geometries. Official optimality is attributed, not independently proved.'],'solver_calls':0,'cpu_seconds':time.process_time()-cpu,'wall_seconds':time.monotonic()-start}
(O/'RAW_CHECKS.json').write_text(json.dumps(checks,indent=2));(O/'AUDIT_RESULT.json').write_text(json.dumps(result,indent=2));print(json.dumps(result));
