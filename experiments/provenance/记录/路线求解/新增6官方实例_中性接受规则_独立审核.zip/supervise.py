import pathlib,subprocess,time,resource,json
p=pathlib.Path(__file__).parent;t=time.monotonic()
with (p/'stdout.json').open('w') as out,(p/'stderr.log').open('w') as err:
 try: exitcode=subprocess.run(['python',str(p/'audit.py')],stdout=out,stderr=err,timeout=60).returncode
 except subprocess.TimeoutExpired:exitcode=124
u=resource.getrusage(resource.RUSAGE_CHILDREN)
r={'exit_code':exitcode,'cpu_seconds':u.ru_utime+u.ru_stime,'wall_seconds':time.monotonic()-t,'hard_cpu_limit_seconds':30,'wall_timeout_seconds':60,'solver_calls':0};(p/'EXIT_RECEIPT.json').write_text(json.dumps(r,indent=2));print(r)
