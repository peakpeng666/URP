"""Read-only independent verification; never imports or runs an experimental solver."""
import json,hashlib,math,time,resource,signal,itertools,collections,copy
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CPU,(29,30));signal.alarm(60)
t0=time.process_time();w0=time.monotonic()
P=Path('/workspace/shared/cvrp_budgeted_terminal_swap_20261008');O=Path('/workspace/shared/official_cvrp_neutral_validation_20261008');A=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda p:json.loads(p.read_text())
hashes=lambda:{str(p.relative_to(P)):sha(p.read_bytes()) for p in P.rglob('*') if p.is_file()}
assert sha(P.with_suffix('.zip').read_bytes())=='ccebabe4cb3b901c2bcd2e016df575cf4d402001aa94ce6a4e5e2f91bd8bab0a'
before=hashes();counts=collections.Counter();evidence=[]
for label in ['PRE_TOY_FREEZE','PRE_RUN_FREEZE']:
 f=read(P/f'freeze/{label}.json')
 for rel,h in f['hashes'].items():assert sha((P/rel).read_bytes())==h,(label,rel)
for rel,h in read(P/'freeze/UNCHANGED_SOURCE.json').items():
 assert sha((P/rel).read_bytes())==h and sha((O/rel).read_bytes())==h,rel
rows=[json.loads(l) for l in (P/'raw/heuristics.jsonl').read_text().splitlines()]
assert sha((P/'raw/heuristics.jsonl').read_bytes())==read(P/'raw/SEALED.json')['sha256']
plan=read(P/'freeze/PLAN.json');sched=read(P/'freeze/SCHEDULE.json')
seeds=[202610085201,202610085203,202610085207,202610085209]
assert plan['seeds']==seeds and len(rows)==len(sched)==48
assert len({(r['instance_id'],r['search_seed'],r['arm']) for r in rows})==48
assert {(r['instance_id'],r['search_seed'],r['arm']) for r in rows}==set(itertools.product(plan['instances'],seeds,['baseline','terminal_swap']))
old={(r['instance_id'],r['search_seed']):r for r in map(json.loads,(O/'raw/heuristics.jsonl').read_text().splitlines()) if r['method']=='regret2' and r['acceptance_mode']=='strict'}
def strip(x):
 if isinstance(x,dict):return {k:strip(v) for k,v in x.items() if not k.endswith('_seconds')}
 if isinstance(x,list):return list(map(strip,x))
 return x
def canon(x):return json.dumps(strip(x),sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
reg=[];pairs=[];checkpoints=read(P/'reports/CHECKPOINTS_40K.json')
for i,r in enumerate(rows):
 assert r['schedule_index']==i and all(r[k]==v for k,v in sched[i].items())
 inst=read(P/f"input/{r['instance_id']}.json");n=len(inst['demands'])-1
 coords=inst['coordinates'];mat=[]
 for a in coords:
  line=[]
  for b in coords:
   q=sum((x-y)**2 for x,y in zip(a,b));z=math.isqrt(q);line.append(z+(4*q>=(2*z+1)**2))
  mat.append(line)
 def cost(routes):return sum(mat[u][v] for route in routes for u,v in zip(route,route[1:]))
 def validate(out):
  if out is None:return
  rs=out['routes'];assert 1<=len(rs)<=inst['K']
  assert all(len(rt)>=3 and rt[0]==rt[-1]==0 for rt in rs)
  flat=[u for rt in rs for u in rt[1:-1]]
  assert all(type(u) is int for u in flat) and sorted(flat)==list(range(1,n+1))
  assert all(sum(inst['demands'][u] for u in rt)<=inst['capacity'] for rt in rs)
  assert cost(rs)==out['reported_cost'];counts['full_outputs']+=1
 assert r['status']=='LEGAL_COMPLETION';rr=r['rr2'];assert rr['method']=='regret2' and rr['acceptance_mode']=='strict'
 for out in [r['output'],rr['output'],rr['baseline'],rr['current_output']]:validate(out)
 for s in rr['trace']:
  for k in ['candidate','current','incumbent']:validate(s.get(k))
 cp=rr['baseline'] if rr['initialization']['deltas_after_initialization']<=40000 else None
 for s in rr['trace']:
  if s['deltas']<=40000:cp=s['incumbent']
 stored=next(x for x in checkpoints if all(x[k]==r[k] for k in ['instance_id','search_seed','arm']))
 assert stored['output']==cp;validate(cp)
 reserve=n*(n-1)//2 if r['arm']=='terminal_swap' else 0
 assert r['reserved_deltas']==reserve and r['rr2_delta_limit']==160000-reserve
 assert rr['deltas']<=160000-reserve and r['total_delta_deltas']<=160000
 assert sum(r['total_delta_by_kind'].values())==r['total_delta_deltas']
 assert r['unused_delta_allowance']==160000-r['total_delta_deltas']
 assert 0<=r['trajectory_cpu_seconds']<=3 and 0<=r['trajectory_wall_seconds']<=10
 if r['arm']=='baseline':
  expected={k:old[(r['instance_id'],r['search_seed'])][k] for k in rr}
  assert canon(expected)==canon(rr);counts['baseline_regressions']+=1
  reg.append(dict(instance=r['instance_id'],seed=r['search_seed'],sha256=sha(canon(rr))))
  assert r['total_delta_deltas']==rr['deltas'] and r['output']==rr['output']
  continue
 rs=rr['output']['routes'];loc={u:(ri,pi) for ri,rt in enumerate(rs) for pi,u in enumerate(rt) if u}
 loads=[sum(inst['demands'][u] for u in rt) for rt in rs];best=None;stats=collections.Counter();trace=r['swap_trace'];assert len(trace)==reserve
 for (u,v),s in zip(itertools.combinations(range(1,n+1),2),trace):
  assert [s['u'],s['v']]==[u,v];stats['all_pairs']+=1
  ri,pi=loc[u];rj,pj=loc[v]
  if ri==rj:assert s['status']=='same_route_skipped';stats['same_route_skipped']+=1;continue
  stats['capacity_pair_checks']+=1;stats['capacity_inequalities']+=2
  nl=[loads[ri]-inst['demands'][u]+inst['demands'][v],loads[rj]-inst['demands'][v]+inst['demands'][u]]
  assert s['new_loads']==nl
  if max(nl)>inst['capacity']:assert s['status']=='capacity_rejected';stats['capacity_rejected']+=1;continue
  assert s['status']=='feasible';candidate=copy.deepcopy(rs);candidate[ri][pi],candidate[rj][pj]=v,u
  delta=cost(candidate)-cost(rs);assert delta==s['delta'];validate({'routes':candidate,'reported_cost':cost(candidate)})
  stats['feasible_pair_deltas']+=1;stats['distance_lookups']+=8;stats['negative_pairs' if delta<0 else 'zero_pairs' if delta==0 else 'positive_pairs']+=1
  if delta<0 and (best is None or (delta,u,v)<best):best=(delta,u,v)
 sw=r['swap'];assert sw['complete'] and sw['stop_reason'] is None
 for k in ['all_pairs','same_route_skipped','capacity_pair_checks','capacity_inequalities','capacity_rejected','feasible_pair_deltas','distance_lookups','negative_pairs','zero_pairs','positive_pairs']:assert sw[k]==stats[k],k
 expected=copy.deepcopy(rr['output'])
 if best:
  d,u,v=best;ri,pi=loc[u];rj,pj=loc[v];expected['routes'][ri][pi],expected['routes'][rj][pj]=v,u;expected['reported_cost']+=d
  assert sw['best_pair']==[u,v] and sw['best_delta']==d and sw['commits']==1
 else:assert sw['best_pair'] is None and sw['best_delta']==0 and sw['commits']==0
 assert r['output']==expected
 assert r['total_delta_deltas']==rr['deltas']+stats['feasible_pair_deltas']
 assert r['total_delta_by_kind']['swap']==stats['feasible_pair_deltas']
 assert r['conservative_reserve_unused']==reserve-stats['feasible_pair_deltas']
 counts.update(stats);counts['swap_commits']+=sw['commits'];counts['swap_scans']+=1
 a=next(x for x in rows if x['instance_id']==r['instance_id'] and x['search_seed']==r['search_seed'] and x['arm']=='baseline')
 pairs.append(dict(instance=r['instance_id'],seed=r['search_seed'],difference=r['output']['reported_cost']-a['output']['reported_cost'],local_change=r['output']['reported_cost']-rr['output']['reported_cost'],reservation_change=rr['output']['reported_cost']-a['output']['reported_cost']))
summary=[]
for name in plan['instances']:
 ps=[p for p in pairs if p['instance']==name];assert len(ps)==4
 summary.append(dict(instance=name,mean_cost_difference=sum(p['difference'] for p in ps)/4,improved=sum(p['difference']<0 for p in ps),same=sum(p['difference']==0 for p in ps),worsened=sum(p['difference']>0 for p in ps)))
reported=read(P/'reports/SUMMARY.json')
for own in summary:
 given=next(x for x in reported['instance_summary'] if x['instance_id']==own['instance'])
 for k in ['mean_cost_difference','improved','same','worsened']:assert own[k]==given[k]
gap=read(P/'reports/GAP_SCORING.json');gapvalues=[]
for own in summary:
 refrow=next(x for x in gap['instance_gap_rows'] if x['instance_id']==own['instance'])
 val=100*own['mean_cost_difference']/refrow['reference_cost'];assert abs(val-refrow['paired_gap_difference_pp'])<1e-10;gapvalues.append(val)
assert abs(sum(gapvalues)/6-gap['primary_equal_instance_mean_gap_difference_pp'])<1e-10
for path,h in gap['post_seal_reference_hashes'].items():assert sha(Path(path).read_bytes())==h
ex=read(P/'receipts/EXIT.json');assert ex['returncode']==0 and not ex['wall_timeout'] and ex['launches']==1 and ex['child_total_cpu']<30 and ex['supervised_wall_seconds']<60
assert read(P/'raw/READ_AUDIT.json')['denied']==[]
assert before==hashes(),'Original package changed during audit'
result=dict(status='PASS',counts=dict(counts),baseline_regression=reg,pairs=pairs,by_instance=summary,original_file_hashes=before,original_unchanged=True,original_exit=ex,primary_gap_difference_pp=sum(gapvalues)/6,original_zip_sha256=sha(P.with_suffix('.zip').read_bytes()),scope='Read-only independent checks; no solver imported or rerun; output/candidate full-cost recomputation and exhaustive logged pair classification; historical package consumed only for regression.',limitations=['Equal delta budgets do not mean equal CPU: feasible swap uses eight distance lookups; rejected/same-route pairs use CPU without delta.', 'Six reused instances and reused seeds are exploratory, not independent held-out evidence.', 'Local swap improvement must not be reported as overall paired gain.', 'Read-audit claims verified as records/source inspection, not an external OS-level attestation.'])
(A/'CHECKS.json').write_text(json.dumps(result,indent=2));(A/'EXIT.json').write_text(json.dumps(dict(returncode=0,process_cpu_seconds=time.process_time()-t0,wall_seconds=time.monotonic()-w0,cpu_limit=30,wall_limit=60,solver_runs=0,original_mutations=0),indent=2))
print(json.dumps(dict(status='PASS',counts=dict(counts),by_instance=summary,resource=read(A/'EXIT.json')),indent=2))
