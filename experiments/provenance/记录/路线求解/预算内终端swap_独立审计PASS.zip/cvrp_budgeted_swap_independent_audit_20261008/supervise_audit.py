import subprocess,time,resource,json,sys
from pathlib import Path
P=Path(__file__).resolve().parent
start=time.monotonic();before=resource.getrusage(resource.RUSAGE_CHILDREN);timeout=False
with (P/'STDOUT.txt').open('x') as out,(P/'STDERR.txt').open('x') as err:
 try:r=subprocess.run([sys.executable,'-B',str(P/'audit.py')],stdout=out,stderr=err,timeout=60);code=r.returncode
 except subprocess.TimeoutExpired:timeout=True;code=-9
end=resource.getrusage(resource.RUSAGE_CHILDREN)
receipt=dict(returncode=code,wall_timeout=timeout,child_user_cpu=end.ru_utime-before.ru_utime,child_system_cpu=end.ru_stime-before.ru_stime,child_total_cpu=end.ru_utime-before.ru_utime+end.ru_stime-before.ru_stime,supervised_wall_seconds=time.monotonic()-start,max_rss_kb=end.ru_maxrss,cpu_limit_seconds=30,wall_limit_seconds=60,solver_runs=0)
(P/'SUPERVISOR_EXIT.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt));sys.exit(code)
