import datetime,json,os,pathlib,resource,signal,subprocess,sys,time
root=pathlib.Path(__file__).resolve().parent
start=time.perf_counter()
def limits():
 os.setsid();resource.setrlimit(resource.RLIMIT_CPU,(14,15))
with (root/'stdout.log').open('x') as out,(root/'stderr.log').open('x') as err:
 p=subprocess.Popen([sys.executable,'-B',str(root/'audit.py')],stdout=out,stderr=err,preexec_fn=limits,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
 killed=False
 while True:
  pid,status,usage=os.wait4(p.pid,os.WNOHANG)
  if pid:break
  if time.perf_counter()-start>=30:
   os.killpg(p.pid,signal.SIGKILL);pid,status,usage=os.wait4(p.pid,0);killed=True;break
  time.sleep(.01)
 p.returncode=os.waitstatus_to_exitcode(status)
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':p.returncode,'cpu_soft_limit_seconds':14,'cpu_hard_limit_seconds':15,'wall_limit_seconds':30,'wall_limit_kill':killed,'child_user_cpu_seconds':usage.ru_utime,'child_system_cpu_seconds':usage.ru_stime,'child_total_cpu_seconds':usage.ru_utime+usage.ru_stime,'elapsed_wall_seconds':time.perf_counter()-start,'maxrss_kib':usage.ru_maxrss,'solver_calls':0,'independent_audit_separate_from_experiment':True}
(root/'RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));sys.exit(p.returncode)
