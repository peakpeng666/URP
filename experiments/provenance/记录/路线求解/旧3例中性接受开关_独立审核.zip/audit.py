"""Independent read-only audit of saved artifacts. Never imports or runs any solver."""
import ast, collections, datetime, difflib, hashlib, itertools, json, math, pathlib, statistics, time, zipfile
ROOT=pathlib.Path('/workspace/shared/official_cvrp_neutral_moves_20261008')
OUT=pathlib.Path(__file__).resolve().parent
PARENT=ROOT.parent/'official_cvrp_controls_20261008'
T=time.perf_counter(); C=time.process_time()
def read(p): return json.loads(p.read_text())
def digest(b): return hashlib.sha256(b).hexdigest()
def sha(p): return digest(p.read_bytes())
def dump(p,v): p.write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def packed(v): return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def require(x,message):
    if not x: raise AssertionError(message)
checks=[]
def ok(name,detail): checks.append({'check':name,'passed':True,'detail':detail})
# Bytes, archive and freezes.
original={str(p.relative_to(ROOT)):sha(p) for p in ROOT.rglob('*') if p.is_file()}
archive=ROOT/'official_cvrp_neutral_moves_20261008.zip'
require(archive.stat().st_size==673964,'archive size')
require(sha(archive)=='19c43a66bbc467619ed6ec2419c2b690d93eeb0f0e156d03d26e839a3e5641df','archive digest')
m=read(ROOT/'MANIFEST.json')
for f in m['files']:
    p=ROOT/f['path']; require(p.stat().st_size==f['bytes'] and sha(p)==f['sha256'], 'manifest '+f['path'])
for line in (ROOT/'SHA256SUMS.txt').read_text().splitlines():
    h,n=line.split('  ',1); require(sha(ROOT/n)==h,'checksum '+n)
with zipfile.ZipFile(archive) as z:
    require(z.testzip() is None,'archive CRC')
    require(len(z.namelist())==len(set(z.namelist())),'duplicate ZIP names')
    require(set(z.namelist())=={x['path'] for x in m['files']}|{'MANIFEST.json','SHA256SUMS.txt'},'ZIP membership')
    for n in z.namelist(): require(z.read(n)==(ROOT/n).read_bytes(),'ZIP bytes '+n)
for name in ['PRE_TOY_FREEZE','PRE_RUN_FREEZE']:
    for n,h in read(ROOT/f'freeze/{name}.json')['sha256'].items(): require(sha(ROOT/n)==h,'freeze '+n)
ok('artifact_integrity',{'zip_bytes':archive.stat().st_size,'zip_sha256':sha(archive),'manifest_files':len(m['files'])})
prov=read(ROOT/'freeze/SOURCE_PROVENANCE.json')
require(sha(PARENT/'MANIFEST.json')==prov['parent_manifest_sha256'],'parent manifest')
require((PARENT/'source/official_solver.py').read_bytes()==(ROOT/'provenance/parent_official_solver.py').read_bytes(),'parent solver copy')
require((PARENT/'raw/heuristics.jsonl').read_bytes()==(ROOT/'regression/parent_heuristics.jsonl').read_bytes(),'parent raw copy')
for n,h in prov['unchanged_auxiliary_hashes'].items(): require(sha(ROOT/'source'/n)==sha(PARENT/'source'/n)==h,'unchanged auxiliary '+n)
old=(ROOT/'provenance/parent_official_solver.py').read_text(); new=(ROOT/'source/official_solver.py').read_text()
patch=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='parent/official_solver.py',tofile='neutral/official_solver.py'))
require(patch==(ROOT/'provenance/NEUTRAL_MINIMAL_DIFF.patch').read_text(),'complete minimal diff')
def funcs(s): return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(s).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
a,b=funcs(old),funcs(new)
require(set(b)-set(a)=={'canonical','acceptance_kind'},'new functions')
require([n for n in a if a[n]!=b[n]]==['run_one'],'other functions unchanged')
ok('minimal_diff_and_parent_provenance','Exact archived diff; only run_one changed and canonical/acceptance_kind added; all auxiliary source and original raw match parent.')
# Entirely independent integer edge recomputation and route validation.
validated_outputs=0; validated_edges=0

def edge(a,b):
    sq=sum((x-y)**2 for x,y in zip(a,b)); floor=math.isqrt(sq)
    return floor+(sq-floor*floor>floor)

def valid(raw,o):
    global validated_outputs,validated_edges
    require(isinstance(o,dict) and isinstance(o.get('routes'),list),'output shape')
    require(0<len(o['routes'])<=raw['K'],'K')
    seen=[]; cost=0; loads=[]; route_costs=[]
    n=len(raw['demands'])
    for route in o['routes']:
        require(len(route)>=3 and route[0]==route[-1]==0,'route endpoints')
        require(all(type(i) is int and 0<i<n for i in route[1:-1]),'customer IDs')
        seen.extend(route[1:-1]); load=sum(raw['demands'][i] for i in route[1:-1]); loads.append(load)
        require(load<=raw['capacity'],'capacity')
        rc=sum(edge(raw['coordinates'][i],raw['coordinates'][j]) for i,j in zip(route,route[1:]))
        cost+=rc;route_costs.append(rc);validated_edges+=len(route)-1
    require(sorted(seen)==list(range(1,n)),'exact once')
    require(type(o['reported_cost']) in (float,int) and math.isfinite(o['reported_cost']) and o['reported_cost']==cost,'exact integer cost')
    validated_outputs+=1
    return cost

def canon(o): return tuple(sorted(min(tuple(r[1:-1]),tuple(reversed(r[1:-1]))) for r in o['routes']))
def checkpoint(r,cut):
    init=r['initialization']['deltas_after_initialization'];last=None;out=None
    if init<=cut: out=r['baseline'];last=init
    for e in r['trace']:
        if e['deltas']<=cut:out=e['incumbent'];last=e['deltas']
    if r['deltas']<=cut:out=r['output']
    return {'requested_deltas':cut,'reached_cut':r['deltas']>=cut,'trajectory_deltas':r['deltas'],'last_atomic_record_deltas':last,'output':out}

def project(new,old):
    if isinstance(old,dict):return {k:project(new[k],v) for k,v in old.items() if not k.endswith('_seconds') and k not in ['finished_utc','schedule_index']}
    if isinstance(old,list):
        require(len(new)==len(old),'regression list length');return [project(a,b) for a,b in zip(new,old)]
    return new
p=read(ROOT/'freeze/PROTOCOL.json');schedule=read(ROOT/'freeze/SCHEDULE.json')
records=[json.loads(x) for x in (ROOT/'raw/heuristics.jsonl').read_text().splitlines()]
old_records=[json.loads(x) for x in (ROOT/'regression/parent_heuristics.jsonl').read_text().splitlines()]
key=lambda r:(r['instance_id'],r['method'],r['search_seed'],r['acceptance_mode'])
require(len(records)==len(schedule)==48 and len(old_records)==24,'trajectory denominators')
require([key(r) for r in records]==[key(r) for r in schedule],'schedule order')
require(set(map(key,records))==set(itertools.product(p['instances'],p['methods'],p['search_seeds'],p['acceptance_modes'])),'Cartesian design')
raws={n:read(ROOT/'input'/f'{n}.json') for n in p['instances']}
for n,raw in raws.items():
    require(set(raw)==set(p['solver_interface']),'five-field input')
    require((ROOT/'input'/f'{n}.json').read_bytes()==(PARENT/'input'/f'{n}.json').read_bytes(),'parent input bytes')
    xy=raw['coordinates']; matrix=read(ROOT/'input'/f'{n}.matrix.json')
    require(matrix==[[edge(a,b) for b in xy] for a in xy],'independent integer matrix')
oldmap={(r['instance_id'],r['method'],r['search_seed']):r for r in old_records}
cpmap={(r['instance_id'],r['method'],r['search_seed'],r['acceptance_mode'],r['checkpoint']):r for r in read(ROOT/'reports/CHECKPOINT_RESULTS.json')}
require(len(cpmap)==96,'checkpoint denominator')
counts_by_arm={a:collections.Counter() for a in p['acceptance_modes']}; regressions=[];trace_entries=0;cp_rows=[];geometric=collections.Counter()
def replay(raw,r):
    global trace_entries
    current=r['baseline'];best=current;valid(raw,current);counts=collections.Counter({k:0 for k in ['equal_cost_candidates','neutral_proposals','neutral_accepted','canonical_noops','strict_improvements']})
    previous=r['initialization']['deltas_after_initialization'];completed=failed=0
    for e in r['trace']:
        trace_entries+=1
        require(previous<=e['deltas']<=r['deltas'],'monotonic bounded delta trace');previous=e['deltas']
        c=e['candidate'];accepted=False
        if c is not None:
            require(e['candidate_status']=='complete','atomic candidate');cost=valid(raw,c);completed+=1
            curcost=current['reported_cost'];kind='strict_improvement' if cost<curcost else ('canonical_noop' if canon(c)==canon(current) else 'neutral_proposal') if cost==curcost else 'worse'
            require(e['acceptance_kind']==kind,'acceptance classification')
            if cost==curcost:counts['equal_cost_candidates']+=1
            if kind=='canonical_noop':counts['canonical_noops']+=1
            if kind=='neutral_proposal':counts['neutral_proposals']+=1
            accepted=kind=='strict_improvement' or (r['acceptance_mode']=='neutral' and kind=='neutral_proposal')
            if accepted:
                if kind=='strict_improvement':counts['strict_improvements']+=1;best=c
                else:counts['neutral_accepted']+=1
                current=c
        else:
            require(e['candidate_status'] in ['repair_failed','budget_discarded'],'null candidate status')
            failed+=e['candidate_status']=='repair_failed'
        require(e['accepted']==accepted and e['current']==current and e['incumbent']==best,'saved current/best/decision')
        valid(raw,e['current']);valid(raw,e['incumbent'])
        require(current['reported_cost']==best['reported_cost'],'current-best equal cost invariant')
    require(r['output']==best and r['current_output']==current,'final output states')
    valid(raw,r['output']);valid(raw,r['current_output'])
    require(r['neutral_counts']==counts and r['accepted_improvements']==counts['strict_improvements'],'mechanism counts')
    require(r['iterations_completed']==completed and r['repair_failures']==failed and r['iterations_started']==len(r['trace']),'iteration ledger')
    require(sum(r['delta_by_kind'].values())==r['deltas'],'delta ledger sum')
    return counts
for r in records:
    raw=raws[r['instance_id']];n=len(raw['demands'])-1
    require(r['status']=='LEGAL_COMPLETION' and r['stop_reason']=='delta_budget' and r['deltas']==160000,'full legal final budget')
    require(r['input_sha256']==sha(ROOT/'input'/f"{r['instance_id']}.json"),'input hash record')
    require(r['matrix_distances']==(n+1)**2,'matrix accounting')
    require(r['delta_by_kind']=={'savings':n*(n-1)//2,'removal':0,'insertion':160000-n*(n-1)//2},'primitive delta accounting')
    objective_edges=sum(len(route)-1 for o in [r['baseline']]+[e['candidate'] for e in r['trace'] if e['candidate'] is not None] for route in o['routes'])
    require(r['objective_edges']==objective_edges,'all objective edge accounting')
    counts_by_arm[r['acceptance_mode']].update(replay(raw,r))
    for cut in p['checkpoints']:
        cp=checkpoint(r,cut); saved=cpmap[key(r)+(cut,)]; cost=valid(raw,cp['output'])
        require(cp['output']==saved['output'] and cp['last_atomic_record_deltas']==saved['last_atomic_record_deltas'] and saved['legal'] and saved['reached_cut'] and saved['cost']==cost,'atomic checkpoint')
        cp_rows.append({**dict(zip(['instance_id','method','search_seed','acceptance_mode'],key(r))),'checkpoint':cut,'cost':cost})
    if r['acceptance_mode']=='strict':
        oldr=oldmap[key(r)[:3]];newb=packed(project(r,oldr));oldb=packed(project(oldr,oldr))
        require(newb==oldb,'all original non-timing fields bitwise')
        require(all(packed(checkpoint(r,c))==packed(checkpoint(oldr,c)) for c in p['checkpoints']),'strict checkpoint bitwise')
        regressions.append({'key':key(r)[:3],'projected_sha256':digest(newb)})
require(len(regressions)==24,'strict regression count')
ok('all_saved_states_replayed',{'official_trace_entries':trace_entries,'official_trajectories':48,'checkpoints':96,'strict_bitwise_matches':24,'counts_by_arm':counts_by_arm})
# Validate archived toy evidence only, with no test solver calls.
toy=read(ROOT/'reports/TOY_VALIDATION.json');toyr={'instance_id':'NEUTRAL_TOY','coordinates':[[0,0]]+[[1,0]]*6,'demands':[0]+[1]*6,'capacity':6,'K':5}
require(toy['passed'] and len(toy['tests'])==10 and len(set(toy['tests']))==10,'ten toy assertions')
require(len(toy['records'])==8 and toy['official_solver_calls']==toy['reference_file_reads']==toy['oracle_calls']==0,'toy evidence shape')
for r in toy['records']:
    if 'trace' in r:replay(toyr,r)
    else:require(r['status']=='budget_discarded' and r['candidate'] is None,'actual repair cutoff toy')
a,b,c=toy['records'][:3]
require(a['acceptance_mode']=='strict' and not a['trace'][0]['accepted'],'toy strict equal rejected')
require(b['trace'][0]['accepted'] and b['trace'][0]['incumbent']==b['baseline'] and b['trace'][0]['current']!=b['baseline'],'toy neutral retains best')
require(not b['trace'][1]['accepted'] and b['trace'][1]['acceptance_kind']=='canonical_noop','toy canonical noop')
require(b['trace'][2]['acceptance_kind']=='strict_improvement' and checkpoint(b,1)['output']==b['baseline'] and checkpoint(b,3)['output']==b['output'],'toy strict update and checkpoints')
require(c['deltas']==1 and c['output']==c['baseline'] and c['current_output']!=c['baseline'],'toy cutoff')
require({(x['method'],x['acceptance_mode']) for x in toy['records'][4:]}==set(itertools.product(p['methods'],p['acceptance_modes'])) and all(x['deltas']==137 for x in toy['records'][4:]),'all toy arms')
# Direct canonical checks on local values, no solver import.
O=lambda x:{'routes':[[0]+r+[0] for r in x]}
require(canon(O([[1,2,3],[4,5,6]]))==canon(O([[6,5,4],[3,2,1]])),'canonical labels and reversal')
require(canon(O([[1,2,3],[4,5,6]]))!=canon(O([[1,3,2],[4,5,6]])),'canonical ID order')
require(canon(O([[1,2,3],[4,5,6]]))!=canon(O([[1,2,4],[3,5,6]])),'canonical ID partition')
ok('ten_archived_toy_evidence_checks','Passed saved-evidence validation; no solver or original toy code rerun. Co-located IDs retained.')
# Scope of temporal isolation: frozen code and Python open audit, not an OS sandbox proof.
seal=read(ROOT/'raw/HEURISTICS_FINISHED.json');start=read(ROOT/'raw/STARTED.json');reads=read(ROOT/'raw/READ_AUDIT.json');summary=read(ROOT/'reports/SUMMARY.json')
require(seal['heuristics_sha256']==sha(ROOT/'raw/heuristics.jsonl') and seal['all_rows_flushed_fsynced'],'raw seal')
require(read(ROOT/'freeze/PRE_TOY_FREEZE.json')['utc']<read(ROOT/'freeze/PRE_RUN_FREEZE.json')['utc']<start['utc']<=seal['utc']<summary['reference_read_started_after_seal'],'chronology')
require(reads['reference_read_count']==0 and reads['denied']==[] and seal['unexpected_denied_reads']==[],'reference read audit')
for n in reads['opened_read_paths']:
    q=pathlib.Path(n)
    require(q.suffix!='.sol','no sol reads')
    if n.startswith('/workspace/'):
        require(any(q.is_relative_to(ROOT/x) for x in ['source','input','freeze']) or q==ROOT/'reports/TOY_VALIDATION.json','read allowlist')
run=(ROOT/'source/run.py').read_text();analyze=(ROOT/'source/analyze.py').read_text()
require(run.index('sys.addaudithook(guard)')<run.index('import official_solver as solver'),'guard before solver import')
require(analyze.index("seal=read(ROOT/'raw/HEURISTICS_FINISHED.json')")<analyze.index('reference_read_started=utc()')<analyze.index('shutil.copyfile'),'reference after seal source order')
ok('reference_isolation_and_raw_seal','Source order, frozen five-field inputs, main Python open-event allowlist and hash/timestamp chain consistent. This is process-instrumentation evidence, not OS-level adversarial isolation proof.')
# Independent per-seed, per-group aggregates and paired outcomes from raw checkpoints.
refs={n:read(ROOT/'reference'/f'{n}.reference_solution.json')['total_cost'] for n in p['instances']}
for n in p['instances']:
    for ext in ['sol','reference_solution.json']:require((ROOT/'reference'/f'{n}.{ext}').read_bytes()==(PARENT/'reference'/f'{n}.{ext}').read_bytes(),'reference provenance')
groups=[];pairs=[]
for cut in p['checkpoints']:
 for n in p['instances']:
  for method in p['methods']:
   modes={}
   for mode in p['acceptance_modes']:
    rows=[r for r in cp_rows if (r['checkpoint'],r['instance_id'],r['method'],r['acceptance_mode'])==(cut,n,method,mode)]
    costs=[r['cost'] for r in rows];require(len(costs)==4,'four seed denominator');modes[mode]={r['search_seed']:r['cost'] for r in rows}
    saved=next(x for x in summary['per_instance_method_arm'] if (x['checkpoint'],x['instance_id'],x['method'],x['acceptance_mode'])==(cut,n,method,mode))
    require(saved['cost_mean']==statistics.mean(costs) and saved['cost_min']==min(costs) and saved['cost_worst']==max(costs) and saved['legal_outputs']==saved['reached_cut']==4,'summary mean/min/worst/denominator')
    require(saved['seed_costs']=={str(k):v for k,v in modes[mode].items()},'seed costs')
    gap=[100*(v-refs[n])/refs[n] for v in costs]
    require(saved['gap_mean_percent']==statistics.mean(gap) and saved['gap_min_percent']==min(gap) and saved['gap_worst_percent']==max(gap),'gap summary')
    require(min(costs)>=refs[n],'below reference anomaly')
   diffs=[modes['neutral'][s]-modes['strict'][s] for s in p['search_seeds']]
   groups.append({'checkpoint':cut,'instance_id':n,'method':method,'strict_mean':statistics.mean(modes['strict'].values()),'neutral_mean':statistics.mean(modes['neutral'].values()),'mean_difference':statistics.mean(diffs),'improved':sum(d<0 for d in diffs),'worsened':sum(d>0 for d in diffs),'same':sum(d==0 for d in diffs),'strict_seed_costs':modes['strict'],'neutral_seed_costs':modes['neutral']})
   for s in p['search_seeds']:
    d=modes['neutral'][s]-modes['strict'][s];pairs.append({'instance_id':n,'checkpoint':cut,'method':method,'search_seed':s,'strict_cost':modes['strict'][s],'neutral_cost':modes['neutral'][s],'neutral_minus_strict':d,'outcome':'improved' if d<0 else 'worsened' if d>0 else 'same'})
savedpairs=read(ROOT/'reports/PAIRED_RESULTS.json');sortpair=lambda r:(r['checkpoint'],r['instance_id'],r['method'],r['search_seed'])
require(sorted(pairs,key=sortpair)==sorted(savedpairs,key=sortpair),'all paired results')
paired_totals={str(c):{k:sum(g[k] for g in groups if g['checkpoint']==c) for k in ['improved','worsened','same']} for c in p['checkpoints']}
resources=read(ROOT/'reports/RESOURCE_ACCOUNTING.json');receipt=read(ROOT/'receipts/main.json')
require(receipt['exit_code']==0 and receipt['complete'] and receipt['child_total_cpu_seconds']<60 and receipt['elapsed_wall_seconds']<90,'main receipt')
for a in resources['by_arm']:
 mode=a['acceptance_mode'];rr=[r for r in records if r['acceptance_mode']==mode]
 require(a['counts']==counts_by_arm[mode] and a['counted_deltas']==sum(r['deltas'] for r in rr)==3840000,'resource arm counts')
 require(a['solver_cpu_seconds_sum']==sum(r['solver_cpu_seconds'] for r in rr),'resource solver CPU sum')
ok('independent_aggregates',{'paired_totals':paired_totals,'instance_method_groups_per_checkpoint':6,'statistical_units':3})
require(original=={str(q.relative_to(ROOT)):sha(q) for q in ROOT.rglob('*') if q.is_file()},'source package unchanged')
ok('source_package_unchanged','All original on-disk file hashes unchanged before and after audit.')
limitations=['This is an independent artifact audit of a posthoc experiment on three already-seen official instances, not new independent benchmark validation. Four seeds and two checkpoints are repeated measurements.', 'Equal counted delta budgets are not equal CPU budgets. Reported CPU values are descriptive one-shot instrumentation.', 'A reference-value hit is not an independent optimality proof.', 'Canonical removes only vehicle labels and full-route reversal; co-located distinct customer IDs, potentially different demands and capacity-relevant partitions are retained.', 'No optimization, toy solver or scientific search rerun. All legality and costs were recomputed for saved states; archived toy evidence and frozen source were inspected.', 'The open-read audit covers Python open events after hook installation, not a separately enforced OS access boundary.']
result={'status':'PASS','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'audit_scope':'read-only independent saved-artifact audit','solver_calls':0,'main_package_sha256':sha(archive),'checks':checks,'validated_saved_outputs':validated_outputs,'validated_edges':validated_edges,'official_trace_entries':sum(len(r['trace']) for r in records),'strict_regressions':regressions,'group_results':groups,'paired_totals':paired_totals,'mechanism_counts':counts_by_arm,'main_receipt':receipt,'limitations':limitations,'process_cpu_seconds_at_result':time.process_time()-C,'wall_seconds_at_result':time.perf_counter()-T}
dump(OUT/'AUDIT_RESULT.json',result)
lines=['PASS：独立只读审计，无solver重跑。',f'主ZIP 673964 bytes，SHA256 {sha(archive)}。',f'48/48合法轨迹与96/96达到预算检查点；{result["official_trace_entries"]}条逐步记录；24/24原strict非计时字段及两个检查点bitwise一致。',f'复核保存输出{validated_outputs}个，整数目标边{validated_edges}条。全部current/best/candidate、成本、接受分类、计数与预算账一致。','10项toy为封存证据审查，未重跑toy solver。初始化、repair和δ原语未改，最小diff与原源码吻合。','raw在reference分析前flush/fsync/hash封存；文件读取证据与源码顺序一致。此证据不等于OS级对抗性隔离。','']
for g in groups:lines.append(f"{g['checkpoint']} | {g['instance_id']} | {g['method']} | strict mean {g['strict_mean']} → neutral mean {g['neutral_mean']} | 改善/恶化/相同 {g['improved']}/{g['worsened']}/{g['same']}")
lines+=['',f'配对总计：{paired_totals}',f'机制：{dict(counts_by_arm)}','',*limitations]
(OUT/'REPORT_ZH.txt').write_text('\n'.join(lines)+'\n')
print(json.dumps({'status':'PASS','paired_totals':paired_totals,'counts':counts_by_arm,'official_trace_entries':result['official_trace_entries'],'validated_outputs':validated_outputs,'cpu':time.process_time()-C,'wall':time.perf_counter()-T},ensure_ascii=False))
