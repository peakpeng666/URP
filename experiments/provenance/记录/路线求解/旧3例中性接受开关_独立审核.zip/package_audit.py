import datetime,hashlib,json,pathlib,time,zipfile
start=time.perf_counter();cpu=time.process_time();p=pathlib.Path(__file__).resolve().parent
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
r=pathlib.Path('/workspace/shared/official_cvrp_neutral_moves_20261008');parent=r.parent/'official_cvrp_controls_20261008'
old=json.loads((parent/'freeze/SCHEDULE.json').read_text());new=json.loads((r/'freeze/SCHEDULE.json').read_text())
expected=[]
for i,spec in enumerate(old):
 for mode in (['strict','neutral'] if i%2==0 else ['neutral','strict']):expected.append({**spec,'acceptance_mode':mode,'parent_schedule_index':i})
assert new==expected
(p/'SCHEDULE_EXTENSION_CHECK.json').write_text(json.dumps({'passed':True,'original_schedule_rows':len(old),'expanded_schedule_rows':len(new),'policy':'Adjacent strict/neutral pairs, original schedule unchanged, order alternates by original row index.'},indent=2)+'\n')
files=sorted(f for f in p.iterdir() if f.is_file() and f.name not in ['MANIFEST.json','SHA256SUMS.txt','archive.sha256','PACKAGE_RECEIPT.json'] and f.suffix!='.zip')
manifest={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'main_package_sha256':'19c43a66bbc467619ed6ec2419c2b690d93eeb0f0e156d03d26e839a3e5641df','files':[{'path':f.name,'bytes':f.stat().st_size,'sha256':sha(f)} for f in files]}
(p/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n');files.append(p/'MANIFEST.json')
(p/'SHA256SUMS.txt').write_text(''.join(f'{sha(f)}  {f.name}\n' for f in files));files.append(p/'SHA256SUMS.txt')
zpath=p/'audit_official_cvrp_neutral_moves_20261008.zip'
with zipfile.ZipFile(zpath,'x',zipfile.ZIP_DEFLATED) as z:
 for f in files:z.write(f,f.name)
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None
 for f in files:assert z.read(f.name)==f.read_bytes()
(p/'archive.sha256').write_text(f'{sha(zpath)}  {zpath.name}\n')
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'zip_bytes':zpath.stat().st_size,'zip_sha256':sha(zpath),'exit_code':0,'archive_readback_passed':True,'schedule_extension_check_passed':True,'packaging_process_cpu_seconds':time.process_time()-cpu,'packaging_wall_seconds':time.perf_counter()-start,'experiment_unchanged':sha(r/'official_cvrp_neutral_moves_20261008.zip')=='19c43a66bbc467619ed6ec2419c2b690d93eeb0f0e156d03d26e839a3e5641df'}
(p/'PACKAGE_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
for f in files+[zpath,p/'archive.sha256',p/'PACKAGE_RECEIPT.json']:f.chmod(0o444)
print(json.dumps(receipt))
