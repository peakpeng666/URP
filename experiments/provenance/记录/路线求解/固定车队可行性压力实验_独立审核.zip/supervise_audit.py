#!/usr/bin/env python3
"""Independent one-shot audit supervisor: wait4 CPU, hard CPU15s, wall30s."""
import datetime,json,os,resource,signal,subprocess,sys,time
from pathlib import Path
OUT=Path(__file__).resolve().parent
receipt=OUT/'AUDIT_RECEIPT.json'
if receipt.exists():raise SystemExit('Audit already attempted; retain attempt evidence.')
def pre():os.setsid();resource.setrlimit(resource.RLIMIT_CPU,(14,15))
start=time.perf_counter()
with (OUT/'audit.stdout.log').open('x') as out,(OUT/'audit.stderr.log').open('x') as err:
    p=subprocess.Popen([sys.executable,'-B',str(OUT/'independent_audit.py')],stdout=out,stderr=err,preexec_fn=pre,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
    killed=False
    while True:
        pid,status,usage=os.wait4(p.pid,os.WNOHANG)
        if pid:break
        if time.perf_counter()-start>=30:
            killed=True;os.killpg(p.pid,signal.SIGKILL);pid,status,usage=os.wait4(p.pid,0);break
        time.sleep(.02)
    code=os.waitstatus_to_exitcode(status);p.returncode=code
r={'stage':'independent_read_only_audit','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':code,'signal':-code if code<0 else None,'cpu_soft_limit_seconds':14,'cpu_hard_limit_seconds':15,'wall_limit_seconds':30,'wall_limit_kill':killed,'child_user_cpu_seconds':usage.ru_utime,'child_system_cpu_seconds':usage.ru_stime,'child_total_cpu_seconds':usage.ru_utime+usage.ru_stime,'elapsed_wall_seconds':time.perf_counter()-start,'maxrss_kib':usage.ru_maxrss,'complete':code==0,'supplied_solver_calls':0,'supplied_oracle_calls':0,'external_api_calls':0,'dependency_installs':0,'financial_scope':'Separate audit cost; excludes platform/assistant tokens and source-authoring/file-packaging overhead. No billable research API or purchases.'}
receipt.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));sys.exit(code)
