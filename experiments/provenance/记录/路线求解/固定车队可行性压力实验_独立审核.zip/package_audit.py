#!/usr/bin/env python3
"""Package completed independent evidence without changing the research target."""
from pathlib import Path
import datetime,hashlib,json,zipfile
OUT=Path(__file__).resolve().parent
SRC=Path('/workspace/shared/fixed_fleet_feasibility_stress_20261008')
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def write(n,v):(OUT/n).write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
keys=['K','Q','delta_limit','iterations','per_trajectory_cpu_seconds','per_trajectory_wall_seconds','methods']
oldp=Path('/workspace/shared/fixed_fleet_cvrp_20261008/freeze/PROTOCOL.json');newp=SRC/'freeze/PROTOCOL.json'
a,b=read(oldp),read(newp)
assert all(a[k]==b[k] for k in keys)
write('PARAMETER_CONTINUITY.json',{'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'predecessor_protocol_sha256':h(oldp),'current_protocol_sha256':h(newp),'same_fields':{k:b[k] for k in keys},'read_only':True,'solver_calls':0})
r=read(OUT/'AUDIT_RECEIPT.json');s=read(OUT/'INDEPENDENT_AUDIT.json');d=read(OUT/'DENOMINATORS_INDEPENDENT.json')
assert r['complete'] and s['verdict']=='PASS_WITH_LIMITATIONS'
report=f'''固定车队压力实验：独立审查 PASS（附适用限制）
审查日期：2026-10-07 UTC。目录标签20261008沿用被审实验名称。

结论
未发现会改变本轮结论的真实缺陷。原512次记录、64个输入、16个独立几何与完整分母吻合；12个旧核心文件逐字节一致。原科研ZIP为778,754字节，SHA256 cb639ab5e5d4de0f12fc29227b7666f5602a8beb1afb82861160a55f2bbd7eb0，审查前后未改。

1. 完整状态与分母
全计划512次：LEGAL_COMPLETION 144、INIT_FAIL 368；ALGORITHM_FAILURE、ILLEGAL_OUTPUT、NOT_RUN均0。
oracle可行输入32个，对应256次：合法144/256=56.25%，初始化失败112/256=43.75%。
oracle不可行输入32个，对应256次：全部无输出，属于预定不可行对照，不能计作算法能力失败；solver的INIT_FAIL本身不构成无解证明。
每法计划256次，其中可行128与不可行128。cheapest：可行合法72、初始化失败56、精确最优及≤1%命中68、合法次优4；regret2：可行合法72、初始化失败56、精确最优及≤1%命中70、合法次优2。≤1%完整可行分母为68/128=53.125%和70/128=54.6875%。两法各128次不可行调用均无输出。
全体合法返回中精确最优138、合法次优6；非法输出0。成功子集不能替代完整可行分母。逐条512状态另存STATUS_LIST_ALL512.json/csv。

2. 独立枚举与容量证据
未导入、执行或重跑原solver或原oracle。另写审查器，穷举226,368条容量合法子集路线排列，再枚举563,824个容量合法无序客户集合分区，逐一复核全部64输入、K=1至9的oracle值及路线见证。
D01：需求总量18，各输入都有两车可行见证。
D02：需求总量27，3组[4,3,2]可行；紧容量最少3车。仅FS04、FS09共同初始化成功，其余14/16几何两法四seed均在搜索前失败，共112次。
D03：总量25≤27，但有4个需求5>9/2，任意两者不能同车，至少4车，K≤3无解。
D04：总需求30>3×9=27，K≤3无解。
所有路线核查客户恰好一次、端点回库、每车载荷≤9、非空路线数≤K，以及未取整欧氏总长度。这里是“最多3车”，不是“恰好3车”。

3. 轨迹与公平性
独立核查23,995个完整候选、113个repair_failed候选、144个budget_discarded候选及44次接受改进。113次修复失败均有当前3车无可行插入位置的保存见证；失败和截断均保留合法incumbent，没有部分方案泄漏。随机移除列表按保存seed独立复核。
144次合法调用各耗5000delta，368次初始化失败各耗36；合计733,248。共同初始化、原子回滚、K/Q约束、参数和完整预算台账一致。5000是delta上限，不能解释为相同CPU或FLOPs。

4. 几何统计与结论边界
独立几何只有16（uniform和two_cluster各8）。每几何4个需求模式、每方法4seed是重复/分组观察，不能膨胀成64、256或512个独立样本。
D01两法4seed全成功的共同支持为16几何，等权几何平均gap为cheapest 0.267306%、regret2 0.061547%；D02共同支持仅2几何，双方数值最优。所有次优差异都在FS07这一个低负载几何，不能据此声称广泛或显著优势。
本轮有意构造FFD边界与不可行需求，不能估计自然/业务需求分布上的失败率。明确发现的是共同初始化瓶颈，repair差异无法救回进入搜索前的缺失。

5. 冻结、oracle隔离与新输入
复核原manifest119个文件、ZIP每个成员、预生成与主跑冻结、12个前代核心、输入及预定schedule的哈希；按声明seed独立再生16几何与64需求排列，匹配冻结输入，且不重复记录的旧几何集合。
K3、Q9、5000delta、10^9迭代上限、单轨CPU2秒/wall10秒、两方法均与前代冻结值相同。
入口仅传实例ID、坐标、需求、容量和K及预算配置。ID带Dxx后缀，但冻结solver只原样回显，不据此分支；没有构造标签、预期可行性或oracle结果输入。
全部512条启发式记录先flush/fsync并封存哈希，随后才导入oracle并完成64输入评分。独占写入、一次主跑标记与receipt一致。它们属于本地代码/哈希/时间证据，不是第三方时间戳，不能排除包外未记录活动。
原包内的“独审pending”字样因不可改原包而保留；本独立附件给出正式审查结论。

6. 独立资源与费用
原主跑：CPU2.724492秒，wall2.763321秒，硬CPU90秒/wall150秒，退出码0。
本次独审：wait4 CPU{r['child_total_cpu_seconds']:.6f}秒，wall{r['elapsed_wall_seconds']:.6f}秒，硬CPU15秒/wall30秒，退出码0；与原主跑分列，不并入原实验。
本审查新增旧solver调用0、旧oracle调用0、外部科研API/模型调用0、安装0、购买0。未产生本任务可识别的付费科研API交易；平台/助手token与云算力金额不可取得，不声称总费用为0。receipt覆盖独审子进程，不覆盖所有阅读、代码撰写和打包开销。

7. 数值与证据边界
独立排列/集合分区枚举与原动态规划路径不同，但同用IEEE双精度距离和明确容差，不是区间算术形式证明。容量不可行结论另有整数证明。
审查完全基于保存轨迹、独立小规模枚举、冻结源码和原始记录，不重跑原启发式，不改写失败，不追加样本或进行参数选择。

主要交付
INDEPENDENT_AUDIT.json：总判定、检查项与限制。
independent_audit.py、supervise_audit.py：独立审查器与15/30秒资源监督器。
INDEPENDENT_ORACLE_CHECKS.json：64输入、K1至9独立值与证明。
STATUS_LIST_ALL512.json/csv：完整逐运行状态。
DENOMINATORS_INDEPENDENT.json、GEOMETRY_RESULTS_INDEPENDENT.json：全分母与16几何复核。
AUDIT_RECEIPT.json、FULL_RESOURCE_RECEIPTS.json：分阶段及独审资源账。
'''
(OUT/'INDEPENDENT_REPORT_ZH.txt').write_text(report)
write('FULL_RESOURCE_RECEIPTS.json',{'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'original_research_stages':{k:read(SRC/f'receipts/{k}.json') for k in ['prepare','main','audit','package']},'original_prepackage_resource_accounting':read(SRC/'reports/RESOURCE_ACCOUNTING.json'),'independent_audit_receipt':r,'scope':'Original frozen experiment receipts and separate independent audit. No main rerun. Source authoring, reading, packaging and assistant/platform costs are not all covered by numerical-process receipts.','external_research_api_calls':0,'scientific_model_calls':0,'dependency_installs':0,'purchases':0,'financial_cost':'No new billable research API transactions. Platform/token/cloud-dollar cost unavailable; do not claim total monetary zero.'})
exclude={'MANIFEST.json','SHA256SUMS.txt','archive.sha256','UPLOAD_WHITELIST.json'}
files=[p for p in sorted(OUT.iterdir()) if p.is_file() and p.name not in exclude and p.suffix!='.zip']
manifest={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'target_archive_sha256':s['target_archive_sha256'],'verdict':s['verdict'],'file_count':len(files),'files':[{'path':p.name,'bytes':p.stat().st_size,'sha256':h(p)} for p in files],'excludes':'Manifest/self checksum and delivery pointers are outside this file list. ZIP includes manifest and SHA256SUMS; outer ZIP checksum stored separately.'}
write('MANIFEST.json',manifest)
(OUT/'SHA256SUMS.txt').write_text(''.join(f'{h(p)}  {p.name}\n' for p in files+[OUT/'MANIFEST.json']))
zpath=OUT/'audit_fixed_fleet_feasibility_stress_20261008.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in files+[OUT/'MANIFEST.json',OUT/'SHA256SUMS.txt']:z.write(p,p.name)
with zipfile.ZipFile(zpath) as z:assert z.testzip() is None
(OUT/'archive.sha256').write_text(h(zpath)+'  '+zpath.name+'\n')
original=SRC/'fixed_fleet_feasibility_stress_20261008.zip';assert h(original)==s['target_archive_sha256']
whitelist=[original,OUT/'INDEPENDENT_REPORT_ZH.txt',zpath,OUT/'FULL_RESOURCE_RECEIPTS.json']
write('UPLOAD_WHITELIST.json',{'destination':'Existing private Google Drive research folder authorized by user; preserve permissions.','files':[{'path':str(p),'bytes':p.stat().st_size,'sha256':h(p)} for p in whitelist],'audit_verdict':'PASS_WITH_LIMITATIONS','original_unchanged':True})
print(json.dumps(read(OUT/'UPLOAD_WHITELIST.json'),ensure_ascii=False,indent=2))
