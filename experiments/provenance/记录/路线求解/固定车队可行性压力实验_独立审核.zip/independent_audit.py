#!/usr/bin/env python3
"""Read-only independent audit; never imports or runs the supplied solver/oracle.
Oracle alternatives: exhaustive permutations of capacity-valid subsets, then
canonical restricted-growth set partitions. All filesystem writes go to OUT.
"""
import ast, csv, datetime, hashlib, itertools, json, math, random, statistics, sys, time, zipfile
from collections import Counter
from pathlib import Path
START_CPU=time.process_time(); START_WALL=time.perf_counter()
SRC=Path('/workspace/shared/fixed_fleet_feasibility_stress_20261008')
OUT=Path('/workspace/shared/audit_fixed_fleet_feasibility_stress_20261008')
EXPECTED_ZIP_SHA='cb639ab5e5d4de0f12fc29227b7666f5602a8beb1afb82861160a55f2bbd7eb0'
checks=[]
def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def read(p): return json.loads((SRC/p).read_text())
def h(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def digest(v): return hashlib.sha256(json.dumps(v,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def write(name,v): (OUT/name).write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def mark(name,details): checks.append({'check':name,'pass':True,'details':details})
def close(a,b): return math.isclose(a,b,rel_tol=1e-10,abs_tol=1e-8)
def mean(v): return statistics.mean(v) if v else None
def same(a,b,path=''):
    if type(a) is float or type(b) is float:
        assert a is not None and b is not None and close(a,b),(path,a,b)
    elif isinstance(a,dict):
        assert set(a)==set(b),(path,set(a)^set(b))
        for k in a: same(a[k],b[k],path+'/'+k)
    elif isinstance(a,list):
        assert len(a)==len(b),(path,len(a),len(b))
        for i,(x,y) in enumerate(zip(a,b)): same(x,y,path+'/'+str(i))
    else: assert a==b,(path,a,b)

def validate(raw,routes,cost=None,k=3,customers=None):
    assert isinstance(routes,list) and len(routes)<=k
    seen=[]; lengths=[]; loads=[]
    for r in routes:
        assert len(r)>=3 and r[0]==r[-1]==0 and all(type(j)==int and 1<=j<=9 for j in r[1:-1])
        seen.extend(r[1:-1]); load=sum(raw['demands'][j] for j in r[1:-1]);assert load<=9
        loads.append(load)
        lengths.extend(math.dist(raw['coordinates'][i],raw['coordinates'][j]) for i,j in zip(r,r[1:]))
    assert sorted(seen)==(list(range(1,10)) if customers is None else sorted(customers)),seen
    c=math.fsum(lengths)
    if cost is not None: assert math.isfinite(cost) and close(c,cost),(c,cost)
    return c,loads

def check_output(raw,output,k=3):
    assert output is not None
    return validate(raw,output['routes'],output['reported_cost'],k)[0]

# Immutable target including its already-completed packaging receipt.
before={str(p.relative_to(SRC)):h(p) for p in SRC.rglob('*') if p.is_file()}
archive=SRC/'fixed_fleet_feasibility_stress_20261008.zip'
assert archive.stat().st_size==778754 and h(archive)==EXPECTED_ZIP_SHA
manifest=read('MANIFEST.json')
assert len(manifest['files'])==manifest['file_count']==119
for e in manifest['files']:
    p=SRC/e['path'];assert p.stat().st_size==e['bytes'] and h(p)==e['sha256'],str(p)
for line in (SRC/'SHA256SUMS.txt').read_text().splitlines():
    sha,path=line.split('  ',1);assert h(SRC/path)==sha,path
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for n in z.namelist():
        if not n.endswith('/'):
            assert (SRC/n).is_file(),n
            assert hashlib.sha256(z.read(n)).hexdigest()==h(SRC/n),n
    zipfiles=sum(not n.endswith('/') for n in z.namelist())
for freeze_name in ['freeze/PRE_GENERATION_FREEZE.json','freeze/PRE_RUN_FREEZE.json']:
    for p,sha in read(freeze_name)['sha256'].items(): assert h(SRC/p)==sha,p
prov=read('freeze/SOURCE_PROVENANCE.json'); assert len(prov)==12
for e in prov: assert h(SRC/e['copy'])==h(e['source'])==e['sha256'] and e['byte_identical'],e
mark('immutable_archive_freezes_and_predecessor_core',{'zip_sha256':EXPECTED_ZIP_SHA,'zip_bytes':778754,'manifest_files':119,'zip_files':zipfiles,'byte_identical_core_files':12})

cfg=read('freeze/PROTOCOL.json'); gm=read('freeze/GEOMETRY_MANIFEST.json'); im=read('freeze/INPUT_MANIFEST.json'); schedule=read('freeze/SCHEDULE.json')
assert (cfg['n'],cfg['Q'],cfg['K'],cfg['geometry_count'],cfg['input_variant_count'],cfg['planned_runs'])==(9,9,3,16,64,512)
assert (cfg['delta_limit'],cfg['iterations'],cfg['per_trajectory_cpu_seconds'],cfg['per_trajectory_wall_seconds'])==(5000,1000000000,2.,10.)
assert cfg['methods']==['cheapest','regret2'] and cfg['search_seeds']==[113011,113027,113041,113057]
assert cfg['geometry_seeds']==list(range(2026100823300,2026100823316))
assert len(gm)==16 and len(im)==64 and len(schedule)==512
inputs={e['instance_id']:read(e['input_file']) for e in im};meta={e['instance_id']:e for e in im}
assert len(inputs)==64 and len(set(g['geometry_id'] for g in gm))==16
old=read('freeze/OLD_GEOMETRY_HASHES.json'); oldo=set(old['ordered_hashes']); oldu=set(old['unordered_hashes'])
for e in old['records']:
    assert h(e['file'])==e['file_sha256'],e['file']
new_o=set();new_u=set()
for gi,g in enumerate(gm):
    assert g['generation_seed']==cfg['geometry_seeds'][gi] and g['family']==cfg['families'][gi]
    rng=random.Random(g['generation_seed']);xy=[[0.,0.]]
    for j in range(9):
        a=[rng.uniform(-50,50),rng.uniform(-50,50)] if g['family']=='uniform' else [rng.gauss(v,8) for v in ((-30,-20) if j%2==0 else (30,20))]
        xy.append([round(v,6) for v in a])
    ho,hu=digest(xy),digest(sorted(xy));assert ho==g['coordinates_sha256'] and hu==g['unordered_coordinates_sha256']
    assert ho not in oldo|new_o and hu not in oldu|new_u
    new_o.add(ho);new_u.add(hu)
    for pi,p in enumerate(cfg['patterns']):
        iid=g['geometry_id']+'-'+p['id'];raw=inputs[iid];e=meta[iid]
        d=p['demands'][:];random.Random(g['generation_seed']+1000000+10000*pi).shuffle(d)
        assert raw=={'instance_id':iid,'coordinates':xy,'demands':[0]+d,'capacity':9,'K':3}
        assert h(SRC/e['input_file'])==e['input_sha256']
        assert sorted(d)==sorted(p['demands']) and sum(d)==p['sum']
expected=[dict(e,method=m,search_seed=s) for e in im for s in cfg['search_seeds'] for m in cfg['methods']]
random.Random(cfg['schedule_seed']).shuffle(expected)
for i,e in enumerate(expected):e['run_id']=i
assert schedule==expected
mark('new_inputs_reproducible_fixed_design_and_schedule',{'independent_geometries':16,'geometry_families':dict(Counter(g['family'] for g in gm)),'inputs':64,'scheduled_calls':512,'old_geometry_source_file_records':len(old['records']),'novelty_scope':old['scope']})

# Static check only. Source is not imported, eval'ed or executed.
runtext=(SRC/'source/run.py').read_text(); tree=ast.parse(runtext)
assign={n.targets[0].id:ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id.startswith('SOLVER_')}
assert assign['SOLVER_RAW_KEYS']==('instance_id','coordinates','demands','capacity','K')
assert assign['SOLVER_CFG_KEYS']==('delta_limit','iterations','per_trajectory_cpu_seconds','per_trajectory_wall_seconds')
assert runtext.index("dump(ROOT/'raw/HEURISTICS_FINISHED.json'") < runtext.index('from oracle import solve') < runtext.index('o=solve(r)')
assert "open('x')" in runtext and 'os.fsync(out.fileno())' in runtext
fixed=(SRC/'source/fixed_solver.py').read_text()
assert fixed.count("raw['instance_id']")==1 and "'instance_id':raw['instance_id']" in fixed
assert 'from oracle' not in fixed and 'import oracle' not in fixed
started=read('raw/STARTED.json');sealed=read('raw/HEURISTICS_FINISHED.json');finished=read('raw/FINISHED.json')
runs=[json.loads(l) for l in (SRC/'raw/heuristics.jsonl').read_text().splitlines()]
oracles=[json.loads(l) for l in (SRC/'raw/oracles.jsonl').read_text().splitlines()]
assert len(runs)==512 and len(oracles)==64 and len(set(r['run_id'] for r in runs))==512
assert len(set(r['instance_id'] for r in oracles))==64
assert [r['run_id'] for r in runs]==list(range(512))
assert sealed['raw_sha256']==h(SRC/'raw/heuristics.jsonl') and sealed['planned']==sealed['recorded']==512 and sealed['oracle_main_calls_so_far']==0
assert read('freeze/PRE_GENERATION_FREEZE.json')['utc']<read('freeze/PRE_RUN_FREEZE.json')['utc']<started['utc']
assert started['freeze_sha256']==h(SRC/'freeze/PRE_RUN_FREEZE.json') and started['main_launch_number']==1
assert started['utc']<min(r['completed_utc'] for r in runs)<=max(r['completed_utc'] for r in runs)<sealed['utc']<min(o['completed_utc'] for o in oracles)<=max(o['completed_utc'] for o in oracles)<finished['utc']
assert finished['heuristic_runs']==512 and finished['oracle_runs']==64
mark('oracle_postseal_firewall_and_single_launch_evidence',{'heuristic_records':512,'oracle_records':64,'oracle_import_after_seal':True,'exclusive_creation_and_no_rerun_guards':True,'identifier_note':'instance_id includes Dxx but is echoed only; no structural label/expected-feasibility fields or branch inputs','qualification':'Local source/hash/timestamp/receipt evidence, not independent historical timestamp attestation or proof of absence of out-of-bundle runs.'})

# Independent exact combinatorial cross-check: no supplied oracle functions.
independent=[]; independent_k3={}; total_perms=0;total_partitions=0;total_tours=0
for o in oracles:
    iid=o['instance_id'];raw=inputs[iid];d=raw['demands'];xy=raw['coordinates'];oracle=o['result']
    assert o['input_sha256']==meta[iid]['input_sha256']
    dist=[[math.dist(a,b) for b in xy] for a in xy]
    costs={};best_route={};perm_count=0
    for mask in range(1,512):
        nodes=[i for i in range(1,10) if mask&(1<<(i-1))]
        if sum(d[i] for i in nodes)>9:continue
        best=math.inf;route=None
        for perm in itertools.permutations(nodes):
            perm_count+=1
            c=math.fsum([dist[0][perm[0]],*(dist[a][b] for a,b in zip(perm,perm[1:])),dist[perm[-1]][0]])
            if c<best:best,route=c,[0,*perm,0]
        costs[mask]=best;best_route[mask]=route
    assert set(map(int,oracle['tours']))==set(costs)
    for mask,c in costs.items():
        t=oracle['tours'][str(mask)];nodes=[i for i in range(1,10) if mask&(1<<(i-1))]
        assert close(c,t['cost']) and t['load']==sum(d[i] for i in nodes)
        validate(raw,[t['route']],t['cost'],1,nodes)
    exact=[math.inf]*10; witnesses=[None]*10;parts=[0]
    def partitions(j,bins,loads):
        if j==10:
            parts[0]+=1;k=len(bins);c=math.fsum(costs[b] for b in bins)
            if c<exact[k]:exact[k]=c;witnesses[k]=bins[:]
            return
        bit=1<<(j-1)
        for bi in range(len(bins)):
            if loads[bi]+d[j]<=9:
                bins[bi]|=bit;loads[bi]+=d[j];partitions(j+1,bins,loads);loads[bi]-=d[j];bins[bi]^=bit
        bins.append(bit);loads.append(d[j]);partitions(j+1,bins,loads);bins.pop();loads.pop()
    partitions(1,[],[])
    byk={}
    for k in range(1,10):
        exactk=min(range(1,k+1),key=lambda q:exact[q]);v=exact[exactk];orig=oracle['by_k'][str(k)]
        if not math.isfinite(v):assert orig is None;byk[str(k)]=None
        else:
            assert orig is not None and close(orig['cost'],v)
            validate(raw,orig['routes'],orig['cost'],k);assert len(orig['routes'])==orig['nonempty_routes']
            byk[str(k)]={'cost':v,'routes':[best_route[b] for b in witnesses[exactk]],'nonempty_routes':exactk}
    independent_k3[iid]=byk['3']
    pid=meta[iid]['pattern_id'];proof={}
    if pid=='D01':assert sum(d)==18 and byk['2'] is not None;proof={'feasible_by_two_routes':byk['2']}
    if pid=='D02':
        assert sum(d)==27 and byk['3'] is not None and byk['2'] is None
        proof={'feasible_by_three_routes':byk['3'],'demand_groups':[[d[j] for j in r[1:-1]] for r in byk['3']['routes']]}
    if pid=='D03':
        big=[j for j in range(1,10) if 2*d[j]>9];assert len(big)==4 and sum(d)==25 and byk['3'] is None and byk['4'] is not None
        proof={'infeasible_K3':'Four customers each demand5>Q/2 must occupy distinct vehicles.','above_half_capacity_customers':big,'minimum_vehicles':4}
    if pid=='D04':
        assert sum(d)==30>27 and byk['3'] is None and byk['4'] is not None
        proof={'infeasible_K3':'Total demand30 exceeds3*9=27.','total_demand':30,'fleet_capacity':27,'minimum_vehicles':4}
    independent.append({'instance_id':iid,'pattern_id':pid,'permutations':perm_count,'capacity_valid_set_partitions':parts[0],'by_k':byk,'proof':proof})
    total_perms+=perm_count;total_partitions+=parts[0];total_tours+=len(costs)
write('INDEPENDENT_ORACLE_CHECKS.json',independent)
mark('independent_oracle_all64_all_K1_to9',{'route_permutations':total_perms,'capacity_valid_subset_tours':total_tours,'capacity_valid_unordered_set_partitions':total_partitions,'oracle_feasible_inputs':sum(v is not None for v in independent_k3.values()),'oracle_infeasible_inputs':sum(v is None for v in independent_k3.values()),'algorithm':'Exhaustive customer permutations per capacity-valid subset plus canonical set-partition enumeration. No supplied solver/oracle execution. IEEE double, not an interval certificate.'})

metrics=read('reports/RUN_METRICS.json');assert len(metrics)==512
rows=[];trace_totals=Counter();partial_failure_checks=0;baseline_by_input={}
for e,r,saved in zip(schedule,runs,metrics):
    for key in ['run_id','instance_id','geometry_id','pattern_id','method','search_seed','input_sha256','family','pattern_name']:assert r[key]==e[key]==saved[key]
    raw=inputs[r['instance_id']];opt=independent_k3[r['instance_id']];feasible=opt is not None;pid=r['pattern_id']
    assert r['K']==3 and 0<=r['deltas']<=5000 and sum(r['delta_by_kind'].values())==r['deltas']
    assert r['matrix_distances']==100 and r['delta_by_kind']['savings']==36 and r['delta_by_kind']['removal']==0
    assert r['initialization']['deltas_after_savings']==36
    initial=r['initialization'];sv=initial['savings_routes']
    validate(raw,[[0,*rr,0] for rr in sv],k=9)
    assert len(sv)==initial['savings_route_count'] and initial['fallback_triggered']==(len(sv)>3)
    ini=(r['baseline'],initial)
    if r['instance_id'] in baseline_by_input:assert ini==baseline_by_input[r['instance_id']]
    else:baseline_by_input[r['instance_id']]=ini
    cost=None;gap=None;exact_hit=False;le1=False;prior=r['baseline'];local=Counter();delta=36
    if prior is not None:check_output(raw,prior)
    for ti,tr in enumerate(r['trace']):
        assert prior is not None and tr['iteration']==ti and delta<=tr['deltas']<=5000;delta=tr['deltas']
        assert tr['q'] in [2,3] and len(tr['removed'])==tr['q'] and len(set(tr['removed']))==tr['q'] and set(tr['removed'])<=set(range(1,10))
        # Verify recorded random-destroy selection against independent hashlib/random derivation, without running the solver.
        ds=lambda kind: int.from_bytes(hashlib.sha256(f"{r['search_seed']}/{kind}/{ti}".encode()).digest()[:8],'big')
        assert tr['q']==random.Random(ds('q')).randint(2,3)
        assert tr['removed']==random.Random(ds('removal')).sample(list(range(1,10)),tr['q'])
        st=tr['candidate_status'];local[st]+=1
        if st=='complete':
            c=check_output(raw,tr['candidate']);should=c<prior['reported_cost']-1e-9
            assert tr['accepted']==should
            if should:prior=tr['candidate'];local['accepted']+=1
        else:
            assert st in ['repair_failed','budget_discarded'] and tr['candidate'] is None and not tr['accepted']
            if st=='repair_failed':
                det=tr['detail'];part=det['partial_routes'];rem=det['remaining'];node=det['blocked_node']
                assert node in rem and sorted([j for rr in part for j in rr]+rem)==list(range(1,10))
                assert len(part)==3 and all(sum(raw['demands'][j] for j in rr)<=9 for rr in part)
                assert all(sum(raw['demands'][j] for j in rr)+raw['demands'][node]>9 for rr in part)
                partial_failure_checks+=1
        assert prior==tr['incumbent'];check_output(raw,tr['incumbent'])
    assert prior==r['output'] and local['accepted']==r['accepted_improvements'] and local['complete']==r['iterations_completed'] and local['repair_failed']==r['repair_failures']
    assert r['iterations_started']==len(r['trace'])
    trace_totals.update(local)
    if r['status']=='LEGAL_COMPLETION':
        assert feasible and r['deltas']==5000 and r['stop_reason']=='delta_budget' and r['error'] is None
        cost=check_output(raw,r['output']);gap=100*(cost-opt['cost'])/opt['cost'];tol=max(1e-8,1e-10*abs(opt['cost']))
        assert cost>=opt['cost']-tol
        exact_hit=abs(cost-opt['cost'])<=tol;le1=cost<=1.01*opt['cost']+tol
        category='LEGAL_OPTIMAL' if exact_hit else 'LEGAL_SUBOPTIMAL'
        assert r['check']['accepted'] and close(r['check']['cost'],cost)
    else:
        assert r['status']=='INIT_FAIL' and r['output'] is None and r['baseline'] is None and not r['trace']
        assert r['error']=={'type':'InitFailure','message':'ffd_capacity_construction_failed'}
        assert r['stop_reason']=='initialization_failed' and r['deltas']==36 and initial['fallback_triggered']
        category='INITIALIZATION_NOT_FOUND_ON_FEASIBLE' if feasible else 'ORACLE_INFEASIBLE_NULL_OUTPUT'
    row={k:r[k] for k in ['run_id','geometry_id','instance_id','pattern_id','method','search_seed','status','deltas','repair_failures']}
    row.update(oracle_feasible=feasible,output_legal=cost is not None,has_output=r['output'] is not None,cost=cost,independent_oracle_cost=None if not feasible else opt['cost'],gap_percent=gap,exact_hit=exact_hit,hit_le1_percent=le1,evaluation_category=category)
    for key in ['oracle_feasible','cost','gap_percent','exact_hit','hit_le1_percent','evaluation_category']:same(row[key],saved[key],str(r['run_id'])+'/'+key)
    assert row['output_legal']==saved['valid_output']==saved['legal_completion'] and not saved['illegal_output'] and not saved['search_failure']
    rows.append(row)
write('STATUS_LIST_ALL512.json',rows)
with (OUT/'STATUS_LIST_ALL512.csv').open('w') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
mark('full_trajectory_legal_assignment_fixedKQ_and_atomic_rollback',{'status_counts':dict(Counter(r['status'] for r in rows)),'trace_counts':dict(trace_totals),'blocked_insertion_failure_witnesses':partial_failure_checks,'common_initialization_inputs':64,'illegal_outputs':0,'raw_record_omissions':0})

# Recompute all planned denominators, rather than selecting successful seeds.
def stats(rs):
    legal=[r for r in rs if r['output_legal']];feasible=[r for r in rs if r['oracle_feasible']];infeasible=[r for r in rs if not r['oracle_feasible']]
    return {'planned':len(rs),'feasible_planned':len(feasible),'infeasible_planned':len(infeasible),'status_counts':dict(Counter(r['status'] for r in rs)),'category_counts':dict(Counter(r['evaluation_category'] for r in rs)),'legal':len(legal),'feasible_init_fail':sum(r['status']=='INIT_FAIL' for r in feasible),'infeasible_null':sum(not r['has_output'] for r in infeasible),'exact':sum(r['exact_hit'] for r in rs),'le1':sum(r['hit_le1_percent'] for r in rs),'legal_suboptimal':sum(r['evaluation_category']=='LEGAL_SUBOPTIMAL' for r in rs),'delta_total':sum(r['deltas'] for r in rs),'repair_failures':sum(r['repair_failures'] for r in rs),'legal_rate_feasible':len(legal)/len(feasible) if feasible else None,'le1_rate_feasible':sum(r['hit_le1_percent'] for r in rs)/len(feasible) if feasible else None}
overall=stats(rows);methods={m:stats([r for r in rows if r['method']==m]) for m in cfg['methods']}
summary=read('reports/SUMMARY.json')
mapping={'planned':'planned','feasible_planned':'oracle_feasible_planned','infeasible_planned':'oracle_infeasible_planned','status_counts':'status_counts','category_counts':'category_counts','legal':'legal_completion_count','feasible_init_fail':'feasible_init_fail_count','infeasible_null':'infeasible_null_output_count','exact':'exact_hit_count','le1':'le1_percent_count','legal_suboptimal':'legal_suboptimal_count','delta_total':'delta_sum','repair_failures':'repair_failed_candidate_count','legal_rate_feasible':'feasible_legal_return_rate','le1_rate_feasible':'le1_rate_oracle_feasible'}
def assert_stats(a,b):
    for k,v in mapping.items():same(a[k],b[v],k)
assert_stats(overall,summary['overall'])
for m in cfg['methods']:assert_stats(methods[m],summary['methods'][m])
assert overall['status_counts']=={'INIT_FAIL':368,'LEGAL_COMPLETION':144}
assert (overall['feasible_planned'],overall['legal'],overall['feasible_init_fail'],overall['infeasible_null'],overall['exact'],overall['legal_suboptimal'])==(256,144,112,256,138,6)
assert methods['cheapest']['le1']==68 and methods['regret2']['le1']==70
patterns={};geometry=[];saved_cells={c['instance_id']:c for c in read('reports/INPUT_CELL_RESULTS.json')};saved_geoms={g['geometry_id']:g for g in read('reports/GEOMETRY_RESULTS.json')}
for p in cfg['patterns']:
    pid=p['id'];ps={m:stats([r for r in rows if r['pattern_id']==pid and r['method']==m]) for m in cfg['methods']}; common=[];gaps={m:[] for m in cfg['methods']};wins=[0,0,0]
    for g in gm:
        rs=[r for r in rows if r['geometry_id']==g['geometry_id'] and r['pattern_id']==pid];iid=g['geometry_id']+'-'+pid
        assert len(rs)==8
        support=all(r['output_legal'] for r in rs);assert support==saved_cells[iid]['common_quality_support']
        for m in cfg['methods']:assert_stats(stats([r for r in rs if r['method']==m]),saved_cells[iid][m])
        if support:
            common.append(g['geometry_id']);costs={}
            for m in cfg['methods']:
                mrs=[r for r in rs if r['method']==m];v=mean([r['gap_percent'] for r in mrs]);gaps[m].append(v);costs[m]=mean([r['cost'] for r in mrs]);same(v,saved_cells[iid][m]['mean_gap_all4'])
            diff=costs['regret2']-costs['cheapest'];wins[0 if diff < -1e-8 else 2 if diff>1e-8 else 1]+=1
    patterns[pid]={'methods':ps,'common_geometry_ids':common,'equal_geometry_mean_gap_percent':{m:mean(gaps[m]) for m in cfg['methods']},'regret2_win_tie_loss_geometry_mean_cost':wins}
    for m in cfg['methods']:
        assert_stats(ps[m],summary['patterns'][pid]['methods'][m]);same(mean(gaps[m]),summary['patterns'][pid]['quality_secondary'][m]['equal_geometry_mean_gap_percent'])
    same(wins,summary['patterns'][pid]['quality_secondary']['regret2_win_tie_loss_geometry_mean_cost'])
for g in gm:
    gid=g['geometry_id'];common=all(gid in patterns[p]['common_geometry_ids'] for p in ['D01','D02']);assert common==saved_geoms[gid]['both_feasible_patterns_common_support']
    geometry.append({'geometry_id':gid,'family':g['family'],'both_feasible_patterns_common_support':common,'patterns':{p:{m:stats([r for r in rows if r['geometry_id']==gid and r['pattern_id']==p and r['method']==m]) for m in cfg['methods']} for p in ['D01','D02','D03','D04']}})
assert patterns['D01']['common_geometry_ids']==[g['geometry_id'] for g in gm]
assert patterns['D02']['common_geometry_ids']==['FS04','FS09']
assert summary['both_feasible_patterns_common_geometry_ids']==['FS04','FS09']
for family in ['uniform','two_cluster']:
    gids={g['geometry_id'] for g in gm if g['family']==family}
    for p in cfg['patterns']:
        for m in cfg['methods']:assert_stats(stats([r for r in rows if r['geometry_id'] in gids and r['pattern_id']==p['id'] and r['method']==m]),summary['family_breakdowns_descriptive'][family][p['id']][m])
ledger=read('failures/FAILURE_LEDGER.json')
assert len(ledger['all_non_legal_return_records'])==368 and not ledger['not_run'] and not ledger['malformed_raw_records']
assert set(r['run_id'] for r in ledger['all_non_legal_return_records'])==set(r['run_id'] for r in rows if not r['output_legal'])
write('GEOMETRY_RESULTS_INDEPENDENT.json',geometry)
write('DENOMINATORS_INDEPENDENT.json',{'overall':overall,'methods':methods,'patterns':patterns,'independent_geometry_count':16,'geometry_variant_count':64,'repeated_seed_calls':512})
mark('denominators_and_independent_geometry_aggregation',{'overall':overall,'methods':methods,'tight_feasible_failure_geometries':[g['geometry_id'] for g in gm if g['geometry_id'] not in ['FS04','FS09']],'quality_difference_geometry_ids':sorted(set(r['geometry_id'] for r in rows if r['evaluation_category']=='LEGAL_SUBOPTIMAL')),'independent_units':16,'conditional_quality_warning':'Common successful cells: D01=16 geometries, D02=2. Seeds and demand variants are repeated observations, not independent geometries.'})

receipt=read('receipts/main.json');resource=read('reports/RESOURCE_ACCOUNTING.json')
assert receipt['complete'] and receipt['exit_code']==0 and receipt['signal'] is None and not receipt['wall_limit_kill']
assert close(receipt['child_user_cpu_seconds']+receipt['child_system_cpu_seconds'],receipt['child_total_cpu_seconds'])
assert receipt['child_total_cpu_seconds']==2.724492 and close(receipt['elapsed_wall_seconds'],2.763320832993486)
assert receipt['child_total_cpu_seconds']<receipt['cpu_hard_limit_seconds']==90 and receipt['elapsed_wall_seconds']<receipt['wall_limit_seconds']==150
assert resource['main_calls']==512 and resource['formal_oracle_inputs']==64 and resource['delta_total']==733248
assert resource['stages']['main']==receipt and summary['main_receipt']==receipt
assert sum(r['child_total_cpu_seconds'] for r in resource['stages'].values())==resource['observed_total_child_cpu_seconds_before_packaging']
assert close(sum(r['elapsed_wall_seconds'] for r in resource['stages'].values()),resource['observed_total_elapsed_wall_seconds_before_packaging'])
assert overall['delta_total']==144*5000+368*36==733248
for key in ['external_api_calls','scientific_model_calls','dependency_installs','uploads']:assert resource[key]==0
mark('main_resource_receipt_and_one_formal_launch_scope',{'main_cpu_seconds':receipt['child_total_cpu_seconds'],'main_wall_seconds':receipt['elapsed_wall_seconds'],'main_exit_code':0,'delta_total':733248,'external_research_api_calls':0,'qualification':'Receipts reconcile local measured child-process usage. They do not include all assistant/token CPU or independent-audit cost; no monetary-zero claim.'})
after={str(p.relative_to(SRC)):h(p) for p in SRC.rglob('*') if p.is_file()}
assert before==after
result={'verdict':'PASS_WITH_LIMITATIONS','created_utc':utc(),'target':str(SRC),'audit_script_sha256':h(__file__),'target_archive_sha256':EXPECTED_ZIP_SHA,'target_archive_bytes':778754,'target_files_unchanged':True,'checks':checks,'scientific_conclusion':'The common initializer is the demonstrated bottleneck:112/256 feasible calls fail initialization, all from14/16 tight-pattern geometries. Infeasible256 calls are expected null outputs, not ability failures. Per-method feasible <=1% hits68/128 vs70/128; quality differences confined to FS07. No general superiority or natural-distribution failure-rate claim.','limitations':['Deliberate stress patterns,16 independent generated geometries,4 blocked variants and4 repeated seeds; no representativeness or significance claim.','The objective uses at most3 nonempty routes, not exactly3.','Only saved trajectories, raw outputs, source, freeze and receipts were audited; no original heuristic rerun.','Local seals/hashes/timestamps and exclusive-creation guards support one visible formal run and delayed scoring; cannot prove absence of out-of-bundle runs or provide third-party time attestation.','Independent permutation/partition enumeration uses IEEE doubles with numerical tolerance, not certified interval arithmetic.','Equal5000 delta ceilings do not mean equal CPU/FLOPs; initialization failures consume36 with no replenishment.','Original package stays unchanged and its embedded independent-review status remains pending; this separate audit supplies the verdict.'],'audit_process_cpu_seconds_checkpoint':time.process_time()-START_CPU,'audit_elapsed_wall_seconds_checkpoint':time.perf_counter()-START_WALL,'supplied_solver_calls':0,'supplied_oracle_calls':0,'external_api_calls':0,'research_model_calls':0,'dependency_installs':0,'financial_cost':'No billable research API or purchases invoked; assistant/platform token costs are unavailable, not asserted zero.'}
write('INDEPENDENT_AUDIT.json',result)
print(json.dumps({'verdict':result['verdict'],'checks':len(checks),'target_unchanged':True,'cpu_checkpoint':result['audit_process_cpu_seconds_checkpoint'],'wall_checkpoint':result['audit_elapsed_wall_seconds_checkpoint'],'permutations':total_perms,'partitions':total_partitions,'trace_counts':dict(trace_totals)},ensure_ascii=False))
