"""Independent saved-output audit. No original solver, checker or oracle imports."""
import json, math, hashlib, itertools, random, time, resource, signal
from pathlib import Path
from functools import lru_cache
ROOT=Path('/workspace/shared/fixed_fleet_cvrp_20261008'); OUT=Path(__file__).parent
resource.setrlimit(resource.RLIMIT_CPU,(14,15)); signal.alarm(30)
t0=time.process_time(); w0=time.perf_counter()
def read(p): return json.loads((ROOT/p).read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def close(a,b): assert math.isclose(a,b,rel_tol=1e-10,abs_tol=1e-8),(a,b)
def distances(f):return [[math.sqrt((a[0]-b[0])**2+(a[1]-b[1])**2) for b in f['coordinates']] for a in f['coordinates']]
def routecost(rs,d): return math.fsum(d[a][b] for r in rs for a,b in zip(r,r[1:]))
def check(f,out,d,k=None):
    assert out is not None
    rs=out['routes']; assert 0<len(rs)<= (f['K'] if k is None else k)
    visits=[]
    for r in rs:
        assert len(r)>=3 and r[0]==r[-1]==0
        assert all(type(x)==int and 1<=x<len(f['demands']) for x in r[1:-1])
        assert sum(f['demands'][x] for x in r[1:-1])<=f['capacity']
        visits+=r[1:-1]
    assert sorted(visits)==list(range(1,len(f['demands'])))
    c=routecost(rs,d);close(c,out.get('reported_cost',out.get('cost')));return c

def exact(f):
    # Exhaustive permutations for each feasible subset, followed by independent forward partition DP.
    n=len(f['demands'])-1; d=distances(f); tour={}; route={}; perms=0
    for mask in range(1,1<<n):
        ns=[i+1 for i in range(n) if mask>>i&1]
        if sum(f['demands'][i] for i in ns)>f['capacity']:continue
        best=math.inf; bp=None
        for p in itertools.permutations(ns):
            perms+=1;c=routecost([[0,*p,0]],d)
            if c<best:best=c;bp=[0,*p,0]
        tour[mask]=best;route[mask]=bp
    costs=[math.inf]*(1<<n); costs[0]=0.;byk={};paths={0:[]}
    for k in range(1,n+1):
        nxt=costs[:];np=paths.copy()
        for mask,c in enumerate(costs):
            if not math.isfinite(c):continue
            remaining=((1<<n)-1)^mask
            if not remaining:continue
            anchor=remaining&-remaining
            for sub,v in tour.items():
                if sub&anchor and sub&remaining==sub:
                    new=mask|sub
                    if c+v<nxt[new]:nxt[new]=c+v;np[new]=paths[mask]+[route[sub]]
        costs=nxt;paths=np
        byk[str(k)]=None if not math.isfinite(costs[-1]) else {'cost':costs[-1],'routes':paths[(1<<n)-1]}
    return {'by_k':byk,'tours':tour,'permutations':perms}

def brute_toy(f):
    n=len(f['demands'])-1;d=distances(f);best=[math.inf]*(n+1);count=0
    for p in itertools.permutations(range(1,n+1)):
        for cut in range(1<<max(0,n-1)):
            count+=1; groups=[];start=0
            for j in range(n-1):
                if cut>>j&1:groups.append(p[start:j+1]);start=j+1
            groups.append(p[start:])
            if any(sum(f['demands'][v] for v in g)>f['capacity'] for g in groups):continue
            c=routecost([[0,*g,0] for g in groups],d);r=len(groups);best[r]=min(best[r],c)
    for k in range(2,n+1):best[k]=min(best[k],best[k-1])
    return best,count

freeze=read('freeze/PRE_RUN_FREEZE.json'); checked_hashes=[]
for p,h in freeze['sha256'].items():assert sha(ROOT/p)==h,p;checked_hashes.append(p)
for p in ['freeze/PRE_TOY_FREEZE.json','freeze/PRE_GENERATION_FREEZE.json']:
    for f,h in read(p)['sha256'].items():assert sha(ROOT/f)==h,(p,f)
assert sha(ROOT/'reports/TOY_VALIDATION.json')==read('freeze/PRE_GENERATION_FREEZE.json')['toy_validation_sha256']
for e in read('freeze/SOURCE_PROVENANCE.json'):assert sha(ROOT/e['copy'])==e['sha256']==sha(Path(e['source']))
schedule=read('freeze/SCHEDULE.json');raw=[json.loads(l) for l in (ROOT/'raw/heuristics.jsonl').read_text().splitlines()];oracles={r['geometry_id']:r for r in map(json.loads,(ROOT/'raw/oracles.jsonl').read_text().splitlines())}
assert len(schedule)==len(raw)==128 and len(oracles)==16
assert len({(r['geometry_id'],r['method'],r['search_seed']) for r in raw})==128
hf=read('raw/HEURISTICS_FINISHED.json');assert sha(ROOT/'raw/heuristics.jsonl')==hf['raw_sha256'] and hf['oracle_main_calls_so_far']==0
assert freeze['utc']<read('raw/STARTED.json')['utc']<hf['utc']<min(o['completed_utc'] for o in oracles.values())
assert max(r['completed_utc'] for r in raw)<=hf['utc']
exact_rows=[]; metrics=[]; traces=complete=failures=discards=0; geoms=[]; regen=[]; diffs=[]
old=read('freeze/OLD_GEOMETRY_HASHES.json');newhashes=[]
for e in read('freeze/INPUT_MANIFEST.json'):
    f=read(e['input_file']); gid=f['instance_id'];d=distances(f);assert len(d)==10 and f['capacity']==9 and f['K']==3
    seed=f['generation_seed'];rng=random.Random(seed);xy=[[0.,0.]]
    for j in range(9):
        pt=[rng.uniform(-50,50),rng.uniform(-50,50)] if f['family']=='uniform' else [rng.gauss(c,8) for c in ((-30,-20) if j%2==0 else (30,20))]
        xy.append([round(v,6) for v in pt])
    dem=[1,1,2,2,3,3,4,4,4];random.Random(seed+1000000).shuffle(dem)
    assert xy==f['coordinates'] and [0]+dem==f['demands'];regen.append(gid)
    assert e['coordinates_sha256'] not in old['ordered_hashes'] and e['unordered_coordinates_sha256'] not in old['unordered_hashes'];newhashes.append(e['coordinates_sha256'])
    ex=exact(f);o=oracles[gid]['result']
    assert set(ex['tours'])==set(map(int,o['tours']))
    for mask,v in ex['tours'].items():close(v,o['tours'][str(mask)]['cost'])
    for k,b in ex['by_k'].items():
        a=o['by_k'][k];assert (a is None)==(b is None)
        if a is not None:close(a['cost'],b['cost']);check(f,a,d,int(k))
    exact_rows.append({'geometry_id':gid,**{k:v for k,v in ex.items() if k!='tours'}})
    opt=ex['by_k']['3']['cost'];gr={}
    rr=[r for r in raw if r['geometry_id']==gid];assert len(rr)==8
    assert all(r['baseline']==rr[0]['baseline'] and r['initialization']==rr[0]['initialization'] for r in rr)
    for r in rr:
        ent=schedule[r['run_id']];assert all(r[x]==ent[x] for x in ['geometry_id','method','search_seed','input_sha256'])
        assert r['input_sha256']==sha(ROOT/e['input_file']) and r['status']=='LEGAL_COMPLETION'
        c=check(f,r['output'],d);prev=r['baseline'];check(f,prev,d);delta=r['initialization']['deltas_after_initialization'];assert delta in (36,54)
        rf=0;dc=0;ac=0
        for tr in r['trace']:
            traces+=1;assert delta<=tr['deltas']<=5000;delta=tr['deltas'];check(f,tr['incumbent'],d)
            if tr['candidate_status']=='complete':
                complete+=1;cc=check(f,tr['candidate'],d)
                assert tr['accepted']==(cc<prev['reported_cost']-1e-9)
                assert tr['incumbent']==(tr['candidate'] if tr['accepted'] else prev)
                ac+=tr['accepted']
            else:
                assert tr['candidate'] is None and not tr['accepted'] and tr['incumbent']==prev
                if tr['candidate_status']=='repair_failed':rf+=1;failures+=1
                else:assert tr['candidate_status']=='budget_discarded';dc+=1;discards+=1
            prev=tr['incumbent']
        assert prev==r['output'] and rf==r['repair_failures'] and ac==r['accepted_improvements'] and dc==1
        assert r['deltas']==sum(r['delta_by_kind'].values())==5000
        gap=(c/opt-1)*100;metrics.append({'geometry_id':gid,'method':r['method'],'seed':r['search_seed'],'cost':c,'oracle_cost':opt,'gap_percent':gap,'repair_failures':rf,'fallback':r['initialization']['fallback_triggered'],'hit_le1':c<=opt*1.01+max(1e-8,abs(opt)*1e-10)})
    for method in ['cheapest','regret2']:
        m=[x for x in metrics if x['geometry_id']==gid and x['method']==method];gr[method]={'mean_gap_percent':sum(x['gap_percent'] for x in m)/4,'worst_gap_percent':max(x['gap_percent'] for x in m),'hits_le1':sum(x['hit_le1'] for x in m)}
    if abs(gr['cheapest']['mean_gap_percent']-gr['regret2']['mean_gap_percent'])>1e-8:diffs.append(gid)
    geoms.append({'geometry_id':gid,**gr})
assert len(set(newhashes))==16 and diffs==['FK06','FK08']
summary=read('reports/SUMMARY.json');ms={}
for method in ['cheapest','regret2']:
    m=[r for r in metrics if r['method']==method];ms[method]={'planned':64,'legal':len(m),'init_fail':0,'hit_le1':sum(x['hit_le1'] for x in m),'mean_gap_percent':sum(x['gap_percent'] for x in m)/64,'worst_gap_percent':max(x['gap_percent'] for x in m),'repair_failures':sum(x['repair_failures'] for x in m),'fallback_trajectories':sum(x['fallback'] for x in m)}
    s=summary['methods'][method];assert ms[method]['hit_le1']==s['le1_percent_count_planned'];close(ms[method]['mean_gap_percent'],s['common_geometry_mean_gap_percent']);close(ms[method]['worst_gap_percent'],s['worst_seed']['gap_percent']);assert ms[method]['repair_failures']==s['repair_failure_count']
assert [ms[m]['repair_failures'] for m in ['cheapest','regret2']]==[185,18]
toyout=[];oldtoy={t['id']:t for t in read('reports/TOY_VALIDATION.json')['oracle_crosschecks']}
for f in read('input/TOY_FIXTURES.json'):
    ex=exact(f);b,count=brute_toy(f);o=oldtoy[f['instance_id']];assert count==o['brute_candidates']
    for k in range(1,len(f['demands'])):
        v=ex['by_k'][str(k)];assert (v is None)==(not math.isfinite(b[k]))
        if v is not None:close(v['cost'],b[k]);close(v['cost'],o['K_results'][k-1]['exact_cost'])
    toyout.append({'id':f['instance_id'],'permutation_cut_candidates':count,'passed':True})
report={'status':'PASS','scope':'Independent output/trace validity, direct Euclidean objective, feasible-subset permutation and partition optimum re-computation; no original heuristic/checker/oracle execution. Mechanism implementation inspected statically; saved toy failure evidence reviewed, not re-run.','input_source_freeze_hashes_checked':len(checked_hashes),'input_regeneration_passed':regen,'historical_novelty_scope':'Four archived bundles and their inherited hashes only; not universal novelty.','planned_runs':128,'legal_outputs':128,'init_fail_main':0,'exact_main_instances':16,'methods':ms,'geometry_difference_ids':diffs,'trace_entries_checked':traces,'complete_candidates_checked':complete,'repair_failed_discarded':failures,'budget_discarded':discards,'small_exhaustive_checks':toyout,'oracle_timing':'128 persisted heuristic outputs preceded first formal oracle; statically no oracle import in heuristic and only post-stage import in run.py. Timestamps and hashes are local provenance, not externally timestamped attestations.','limitations':['16 fresh development geometries only; 4 seeds per geometry are repeats, not 64 independent cases.','Fixed demands multiset totals 24, Q9, K3. Main INIT_FAIL=0 does not imply general feasibility; saved toy demonstrates feasible instance where FFD fails.','Performance differences confined to the two FFD geometries FK06/FK08. Post-hoc stratification, not a separately preregistered confirmation.','Unrounded Euclidean objectives use floating point. Complete combinatorial optimum, not certified interval arithmetic.','5000 delta includes savings and insertion initialization; equal delta is not equal compute. No rerun of heuristic means runtime behavior is supported by source plus saved traces, not a fresh execution.'],'resource':{'audit_process_cpu_seconds':time.process_time()-t0,'audit_wall_seconds':time.perf_counter()-w0,'cpu_cap_seconds':15,'wall_cap_seconds':30,'main_solver_reruns':0,'external_api_calls':0,'scientific_model_calls':0,'installs':0,'monetary_cost':'No billable external API or purchase; assistant/platform token cost unavailable, not asserted zero.'}}
for name,obj in [('AUDIT.json',report),('INDEPENDENT_EXACT.json',exact_rows),('RUN_METRICS.json',metrics),('GEOMETRY_METRICS.json',geoms)]: (OUT/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(report,ensure_ascii=False))
