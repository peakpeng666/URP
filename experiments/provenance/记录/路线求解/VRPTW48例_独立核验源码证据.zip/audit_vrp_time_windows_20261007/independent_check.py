import csv, hashlib, itertools, json, math, resource, statistics, time
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CPU,(9,10))
start=time.process_time()
P=Path('/workspace/shared/vrp_time_windows_20261007')
O=Path(__file__).resolve().parent
I=json.loads((P/'inputs.json').read_text()); B={i['id']:i for i in I}
R=[json.loads(x) for x in (P/'routes.jsonl').read_text().splitlines()]
T=json.loads((P/'oracle_tables.json').read_text()); S=json.loads((P/'summary.json').read_text())
# Independent replay, not importing either experiment.py or checker.py.
def replay(i,routes,windows=True,return_limit=True):
    seen=[]; distance=0.; late=0; overload=0; depot_late=0
    for route in routes:
        now=i['depart_time']; prev=0; load=0
        for j in route:
            a,b=i['nodes'][prev],i['nodes'][j]
            leg=((a['x']-b['x'])**2+(a['y']-b['y'])**2)**0.5
            now+=leg; distance+=leg; load+=b['demand']; seen.append(j)
            if windows:
                now=max(now,b['window'][0]); late+=now>b['window'][1]+1e-9
            now+=b['service']; prev=j
        a,b=i['nodes'][prev],i['nodes'][0]
        leg=((a['x']-b['x'])**2+(a['y']-b['y'])**2)**0.5
        now+=leg; distance+=leg
        overload+=load>i['capacity']
        depot_late+=return_limit and now>i['return_deadline']+1e-9
    feasible=len(routes)==i['vehicles'] and len(set(seen))==len(seen) and not(late or overload or depot_late)
    return {'feasible':feasible,'full':feasible and set(seen)==set(range(1,8)),'served':len(set(seen)), 'distance':distance,'late':late,'overload':overload,'depot_late':depot_late}
assert len(I)==48 and len(B)==48 and len(R)==240
for gi in range(1,17):
    tri=[B[f'G{gi:02d}_{x}'] for x in ('tight','medium','wide')]
    for i in tri:
        assert len(i['nodes'])==8 and i['vehicles']==2 and i['capacity']==6
        assert [n['demand'] for n in i['nodes'][1:]]==[2,1,2,1,2,1,1]
        assert all(n['service']==2 for n in i['nodes'][1:])
        assert i['depart_time']==0 and i['return_deadline']==120
    for j in range(8):
        assert len({(x['nodes'][j]['x'],x['nodes'][j]['y']) for x in tri})==1
        wins=[x['nodes'][j]['window'] for x in tri]
        assert wins[2][0]<=wins[1][0]<=wins[0][0]<=wins[0][1]<=wins[1][1]<=wins[2][1]
    for x in tri[1:]:assert replay(x,x['reference_routes'])['full']
for r in R:
    if r['routes'] is None:
        assert r['method']=='oracle_full' and not T[r['instance']]['full_feasible']
        assert r['full_oracle_objective'] is None and r['full_gap_percent'] is None
        continue
    x=replay(B[r['instance']],r['routes']); a=r['audit']
    assert x['feasible']==a['route_feasible'] and x['full']==a['full_service_feasible']
    assert x['served']==a['served_unique'] and abs(x['distance']-a['total_distance'])<1e-7
    assert (x['late'],x['overload'],x['depot_late'])==(a['late_starts'],a['overloaded_vehicles'],a['late_depot_returns'])
    table=T[r['instance']]['best_two_vehicle_by_served_mask']
    mask=sum(1<<(j-1) for route in r['routes'] for j in route)
    if r['full_gap_percent'] is not None:
        assert x['full'] and abs(r['full_gap_percent']-100*(x['distance']/table['127']['distance']-1))<1e-7
    else:assert not x['full']
    if r['same_served_mask_gap_percent'] is not None:
        assert x['feasible'] and abs(r['same_served_mask_gap_percent']-100*(x['distance']/table[str(mask)]['distance']-1))<1e-7
    if r['method'] in ('distance_first','time_window_first'):
        assert r['coverage_shortfall']==max(int(m).bit_count() for m in table)-x['served']
count=0
for iid,t in T.items():
    assert t['ordered_subsets_evaluated']==13699
    assert t['full_feasible']==('127' in t['best_two_vehicle_by_served_mask'])
    for m,sol in t['best_two_vehicle_by_served_mask'].items():
        x=replay(B[iid],sol['routes']); assert x['feasible']
        assert sum(1<<(j-1) for route in sol['routes'] for j in route)==int(m)
        assert abs(x['distance']-sol['distance'])<1e-7
        count+=1
# Only three additional exhaustive spot checks, not a rerun of the 48 oracles.
# Independent full-permutation/cut enumeration includes empty routes.
checks=[]
for iid,windows in [('G02_tight',True),('G12_tight',True),('G02_wide',False)]:
    i=B[iid]; best=None; candidates=0
    for perm in itertools.permutations(range(1,8)):
        for cut in range(8):
            candidates+=1
            x=replay(i,[perm[:cut],perm[cut:]],windows=windows,return_limit=windows)
            if x['full'] and (best is None or x['distance']<best):best=x['distance']
    rr=next(r for r in R if r['instance']==iid and r['method']==('oracle_full' if windows else 'capacity_only_diagnostic'))
    reported=rr['audit']['total_distance'] if rr['audit'] else None
    assert (best is None)==(reported is None)
    if best is not None:assert abs(best-reported)<1e-7
    checks.append({'instance':iid,'mode':'VRPTW' if windows else 'capacity_only_without_return_limit','full_permutation_cuts':candidates,'reported':reported,'independent_best':best,'pass':True})
by={(r['instance'],r['method']):r for r in R}
def full(iid,m):return by[iid,m]['audit']['full_service_feasible']
common=[i['id'] for i in I if full(i['id'],'distance_first') and full(i['id'],'time_window_first')]
metrics={}
for m in ('distance_first','time_window_first','capacity_only_diagnostic'):
    rr=[r for r in R if r['method']==m]; aa=[r['audit'] for r in rr]
    metrics[m]={'full':sum(a['full_service_feasible'] for a in aa),'served':sum(a['served_unique'] for a in aa),'late_starts':sum(a['late_starts'] for a in aa),'overloads':sum(a['overloaded_vehicles'] for a in aa),'late_depot':sum(a['late_depot_returns'] for a in aa)}
    for key,expected in [('full_service_feasible',metrics[m]['full']),('served_unique',metrics[m]['served']),('late_starts',metrics[m]['late_starts'])]:assert S['by_level']['all']['methods'][m][key]==expected
results={'passed':True,'independent_replayed_non_null_records':sum(r['routes'] is not None for r in R),'subset_witnesses_checked':count,'oracle_full_feasible':sum(t['full_feasible'] for t in T.values()),'oracle_full_infeasible':sum(not t['full_feasible'] for t in T.values()),'oracle_max_coverage_total':sum(max(int(m).bit_count() for m in t['best_two_vehicle_by_served_mask']) for t in T.values()),'methods':metrics,'diagnostic_oracle_feasible_failures':sum(t['full_feasible'] and not full(iid,'capacity_only_diagnostic') for iid,t in T.items()),'tight_full_feasible_ids':[iid for iid,t in T.items() if iid.endswith('tight') and t['full_feasible']],'extra_independent_exhaustive_spotchecks':checks,'common_full_n':len(common),'common_full_gap_mean_percent':{m:statistics.mean(by[iid,m]['full_gap_percent'] for iid in common) for m in ('distance_first','time_window_first')},'common_full_distance_pair_counts':{'tw_better':sum(by[iid,'time_window_first']['audit']['total_distance']<by[iid,'distance_first']['audit']['total_distance']-1e-7 for iid in common),'distance_better':sum(by[iid,'distance_first']['audit']['total_distance']<by[iid,'time_window_first']['audit']['total_distance']-1e-7 for iid in common),'tie':sum(abs(by[iid,'distance_first']['audit']['total_distance']-by[iid,'time_window_first']['audit']['total_distance'])<=1e-7 for iid in common)},'input_sha256':hashlib.sha256((P/'inputs.json').read_bytes()).hexdigest(),'routes_sha256':hashlib.sha256((P/'routes.jsonl').read_bytes()).hexdigest(),'cpu_seconds':time.process_time()-start,'note':'Original experiment directory read-only. Independent script imports no experiment or checker code. Stored witness checks validate feasibility, not exhaustiveness; oracle exhaustiveness is supported by inspected source and limited independent full-permutation checks.'}
(O/'independent_results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(results,ensure_ascii=False,indent=2))
