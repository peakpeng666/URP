"""Archive only the independent audit's own evidence; never copy source bundle raw."""
from pathlib import Path
import hashlib,json,zipfile,time
OUT=Path(__file__).resolve().parent; ZIP=OUT.with_suffix('.zip')
T=time.process_time();W=time.perf_counter()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
files=[p for p in OUT.iterdir() if p.is_file() and p.name not in ('FILE_MANIFEST.json','PACKAGING_RECEIPT.json','packaging.stdout.log','packaging.stderr.log','PACKAGING_CHECKPOINT.json')]
manifest={p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(files)}
(OUT/'FILE_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
(OUT/'PACKAGING_CHECKPOINT.json').write_text(json.dumps({'cpu_seconds':time.process_time()-T,'wall_seconds':time.perf_counter()-W,'scope':'Before ZIP write; exact full wait4 receipt is stored externally after ZIP creation.'},indent=2)+'\n')
files += [OUT/'FILE_MANIFEST.json',OUT/'PACKAGING_CHECKPOINT.json']
with zipfile.ZipFile(ZIP,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(files):z.write(p,arcname=OUT.name+'/'+p.name)
with zipfile.ZipFile(ZIP) as z:
    assert z.testzip() is None
    for p in files: assert hashlib.sha256(z.read(OUT.name+'/'+p.name)).hexdigest()==sha(p)
print(json.dumps({'zip_path':str(ZIP),'bytes':ZIP.stat().st_size,'sha256':sha(ZIP),'members':len(files),'crc_and_member_sha256_verified':True}))
