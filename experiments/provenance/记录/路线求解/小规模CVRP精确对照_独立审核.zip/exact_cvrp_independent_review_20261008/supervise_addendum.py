import os,sys,time,resource,signal,subprocess,json,hashlib,datetime
from pathlib import Path
out=Path(__file__).resolve().parent
if (out/'ADDENDUM_RECEIPT.json').exists(): raise SystemExit('Refuse to overwrite receipt')
start=time.perf_counter();cpu=time.process_time()
def limits():
    os.setsid(); resource.setrlimit(resource.RLIMIT_CPU,(9,10))
with (out/'addendum.stdout.log').open('x') as stdout,(out/'addendum.stderr.log').open('x') as stderr:
    child=subprocess.Popen([sys.executable,'-B',str(out/'addendum.py')],stdout=stdout,stderr=stderr,preexec_fn=limits)
    killed=False
    while True:
        pid,status,usage=os.wait4(child.pid,os.WNOHANG)
        if pid: break
        if time.perf_counter()-start>30:
            killed=True;os.killpg(child.pid,signal.SIGKILL);pid,status,usage=os.wait4(child.pid,0);break
        time.sleep(.025)
    code=os.waitstatus_to_exitcode(status);child.returncode=code
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stage':'independent_read_only_addendum','exit_code':code,'wall_limit_kill':killed,'cpu_soft_limit_seconds':9,'cpu_hard_limit_seconds':10,'wall_limit_seconds':30,'child_user_cpu_seconds':usage.ru_utime,'child_system_cpu_seconds':usage.ru_stime,'child_total_cpu_seconds':usage.ru_utime+usage.ru_stime,'elapsed_wall_seconds':time.perf_counter()-start,'maxrss_kib':usage.ru_maxrss,'supervisor_cpu_checkpoint_seconds':time.process_time()-cpu,'scope':'Only this read-only audit child and supervisor checkpoint; excludes interactive source review and authoring.'}
(out/'ADDENDUM_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt));sys.exit(0 if code==0 else 1)
