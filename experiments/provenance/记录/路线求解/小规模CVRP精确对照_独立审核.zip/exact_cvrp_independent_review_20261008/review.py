"""Read-only review. Never imports or executes any experimental/solver code."""
from pathlib import Path
from collections import Counter
import datetime, hashlib, json, math, random, statistics, time
ROOT=Path('/workspace/shared/exact_cvrp_controls_20261008')
OUT=Path(__file__).resolve().parent
T=time.process_time(); W=time.perf_counter()
def load(path): return json.loads(Path(path).read_text())
def read(name): return load(ROOT/name)
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def digest(v): return hashlib.sha256(json.dumps(v,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def rows(name): return [json.loads(s) for s in (ROOT/name).read_text().splitlines() if s]
def near(a,b): return math.isclose(a,b,abs_tol=1e-8,rel_tol=1e-10)
failures=[]; checks=Counter()
def test(ok,label,detail=None):
    checks[label]+=1
    if not ok: failures.append({'check':label,'detail':detail})

def routes_check(raw,o,K,expected=None):
    target=list(range(1,len(raw['demands']))) if expected is None else list(expected)
    rr=o['routes']; points=raw['coordinates']; dem=raw['demands']; loads=[]; edges=[]; served=[]; errs=[]
    if len(rr)>K: errs.append('vehicle_upper_bound_exceeded')
    for route in rr:
        if not isinstance(route,list) or len(route)<3 or route[0]!=0 or route[-1]!=0 or any(type(i)!=int or not 0<i<len(dem) for i in route[1:-1]):
            errs.append('route_shape_or_depot'); continue
        served+=route[1:-1]; loads.append(sum(dem[i] for i in route[1:-1]))
        if loads[-1]>raw['capacity']: errs.append('capacity_exceeded')
        for a,b in zip(route,route[1:]):
            dx=points[a][0]-points[b][0]; dy=points[a][1]-points[b][1]
            edges.append(math.sqrt(dx*dx+dy*dy))
    if sorted(served)!=sorted(target): errs.append('service_multiplicity')
    cost=math.fsum(edges); claimed=o.get('reported_cost',o.get('cost'))
    if type(claimed) not in (int,float) or not math.isfinite(claimed) or not near(cost,claimed): errs.append('cost_mismatch')
    return {'accepted':not errs,'errors':errs,'cost':cost,'loads':loads,'route_count':len(rr),'residual':cost-claimed}

snapshot={str(p.relative_to(ROOT)):sha(p) for p in ROOT.rglob('*') if p.is_file()}
cfg=read('freeze/PROTOCOL.json'); manifest=read('freeze/INPUT_MANIFEST.json'); schedule=read('freeze/SCHEDULE.json'); rawrows=rows('raw/TRAJECTORIES.jsonl'); orows=rows('raw/ORACLES.jsonl')
freezes={}
for name in ['freeze/PRE_GENERATION_FREEZE.json','freeze/PRE_RUN_FREEZE.json']:
    f=read(name); bad=[p for p,h in f['sha256'].items() if sha(ROOT/p)!=h]
    test(not bad,'frozen_hashes',{'freeze':name,'bad':bad}); freezes[name]={'entries':len(f['sha256']),'bad':bad,'sha256':sha(ROOT/name)}
for p in read('freeze/SOURCE_PROVENANCE.json'):
    test(sha(ROOT/p['copy'])==p['sha256']==sha(p['source']),'legacy_byte_identity',p['copy'])
inputs={e['geometry_id']:read(e['input_file']) for e in manifest}; omap={r['geometry_id']:r for r in orows}
old=read('freeze/OLD_GEOMETRY_HASHES.json'); old_ordered=set(old['inherited_ordered_hashes']); old_unordered=set(); old_cache={}
for item in old['records']:
    p=item['file']; value=old_cache.setdefault(p,load(p))
    test(sha(p)==item['file_sha256'],'old_source_file_hash',p)
    vs=value if isinstance(value,list) else [value]
    selected=[v for v in vs if isinstance(v,dict) and v.get('instance_id',v.get('id'))==item['id']]
    test(len(selected)==1,'old_record_identity',p)
    if len(selected)==1:
        v=selected[0]; xy=v.get('coordinates')
        if xy is None and 'nodes' in v: xy=[[q['x'],q['y']] for q in v['nodes']]
        test(digest(xy)==item['ordered_coordinate_sha256'] and digest(sorted(xy))==item['unordered_coordinate_sha256'],'old_coordinates_hash',p)
    old_ordered.add(item['ordered_coordinate_sha256']); old_unordered.add(item['unordered_coordinate_sha256'])
new_ordered=[]; new_unordered=[]
for i,e in enumerate(manifest):
    raw=inputs[e['geometry_id']]; seed=cfg['geometry_seeds'][i]; family=cfg['families'][i]
    rng=random.Random(seed); xy=[[0.,0.]]
    for j in range(9):
        if family=='uniform': pt=[rng.uniform(-50,50),rng.uniform(-50,50)]
        else: pt=[rng.gauss(c,8) for c in ((-30,-20) if j%2==0 else (30,20))]
        xy.append([round(x,6) for x in pt])
    dem=[1,1,2,2,3,3,4,4,4]; random.Random(seed+1000000).shuffle(dem)
    test(raw['coordinates']==xy and raw['demands']==[0]+dem and raw['generation_seed']==seed and raw['family']==family,'input_generator_reconstruction',e['geometry_id'])
    test(raw['capacity']==9 and raw['fleet']=='unlimited_identical_vehicles' and sum(raw['demands'])==24,'input_contract',e['geometry_id'])
    h=digest(raw['coordinates']); u=digest(sorted(raw['coordinates'])); new_ordered.append(h); new_unordered.append(u)
    test(h==e['coordinates_sha256'] and u==e['unordered_coordinates_sha256'] and sha(ROOT/e['input_file'])==e['input_sha256'],'input_manifest_hash',e['geometry_id'])
    test(h not in old_ordered and u not in old_unordered,'no_recorded_old_geometry_duplicate',e['geometry_id'])
test(len(set(new_ordered))==len(set(new_unordered))==16,'new_geometry_uniqueness')
expected={(e['geometry_id'],s,'_'.join(p)) for e in manifest for s in cfg['search_seeds'] for p in cfg['pairs']}
getkey=lambda r:(r['geometry_id'],r['search_seed'],r['algorithm'])
test(len(rawrows)==len(schedule)==128 and set(map(getkey,rawrows))==set(map(getkey,schedule))==expected,'plan_complete')
test(len({r['run_id'] for r in rawrows})==128 and set(r['run_id'] for r in rawrows)==set(range(128)),'trajectory_ids_unique')
test(len(omap)==len(orows)==16 and set(omap)==set(inputs),'oracle_coverage')
byrun={r['run_id']:r for r in rawrows}
for planned in schedule:
    r=byrun[planned['run_id']]; test(all(r[k]==v for k,v in planned.items()),'schedule_identity',r['run_id'])
route_results=[]; subset_results=[]; oracle_results=[]
for gid,record in omap.items():
    raw=inputs[gid]; o=record['oracle']; previous=math.inf
    test(set(o['by_k'])==set(map(str,range(1,10))),'all_K_reported',gid)
    for k in range(1,10):
        out=o['by_k'][str(k)]
        if out is None:
            test(sum(raw['demands'])>k*raw['capacity'],'infeasibility_capacity_bound',{'geometry':gid,'K':k})
            oracle_results.append({'geometry_id':gid,'K':k,'feasible':False,'reason':'total_demand_exceeds_KQ'}); continue
        a=routes_check(raw,out,k); test(a['accepted'],'oracle_routes_feasibility_cost',{'geometry':gid,'K':k,'audit':a})
        test(out['nonempty_routes']==a['route_count'],'oracle_route_count',{'geometry':gid,'K':k})
        test(a['cost']<=previous+1e-8,'at_most_K_monotonic',{'geometry':gid,'K':k}); previous=a['cost']
        oracle_results.append({'geometry_id':gid,'K':k,'feasible':True,**a})
    feasible_masks={m for m in range(1,1<<9) if sum(raw['demands'][j+1] for j in range(9) if m>>j&1)<=raw['capacity']}
    test(set(map(int,o['tours']))==feasible_masks,'all_capacity_feasible_subset_tours',gid)
    for mask,tour in o['tours'].items():
        members=[j+1 for j in range(9) if int(mask)>>j&1]
        a=routes_check(raw,{'routes':[tour['route']],'cost':tour['cost']},1,members)
        test(a['accepted'] and a['loads']==[tour['load']],'subset_tour_feasibility_cost',{'geometry':gid,'mask':mask})
        subset_results.append({'geometry_id':gid,'mask':int(mask),**a})

recomputed=[]
for r in rawrows:
    rid=r['run_id']; raw=inputs[r['geometry_id']]; res=r['result']; a=routes_check(raw,res['output'],9); b=routes_check(raw,res['baseline'],9); a3=routes_check(raw,res['output'],3)
    route_results.append({'run_id':rid,'geometry_id':r['geometry_id'],'final':a,'baseline':b,'K3':a3})
    test(a['accepted'] and b['accepted'],'all_final_baseline_routes',rid)
    for label,x in [('independent_audit',a),('baseline_audit',b),('K3_diagnostic_audit',a3)]:
        y=r[label]; test(x['accepted']==y['accepted'] and x['loads']==y['loads'] and x['route_count']==y['nonempty_routes'] and near(x['cost'],y['cost']),'stored_route_audits',{'run':rid,'type':label})
    test(r['status']=='complete' and res['error'] is None and res['stop_reason']=='delta_budget','run_terminal_state',rid)
    test(res['deltas']==5000 and res['delta_by_kind']=={'savings':36,'removal':0,'insertion':4964} and res['matrix_distances']==100,'delta_ledger',rid)
    test(res['solver_cpu_seconds']<2 and res['solver_wall_seconds']<10,'per_trajectory_time_bound',rid)
    test(res['pair']==r['algorithm'] and res['destroy']=='random' and res['repair']==r['pair'][1] and res['search_seed']==r['search_seed'],'fixed_control_identity',rid)
    canonical=hashlib.sha256(json.dumps(raw,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
    test(res['instance_sha256']==canonical,'legacy_instance_hash',rid)
    optimum=omap[r['geometry_id']]['oracle']['by_k']['9']['cost']; gap=100*(a['cost']/optimum-1); hit=abs(a['cost']-optimum)<=max(1e-8,1e-10*abs(optimum))
    test(near(optimum,r['primary_optimum']) and near(gap,r['raw_gap_percent']) and hit==r['optimal_hit'] and gap>=-1e-7,'primary_gap_and_hit',rid)
    g3=100*(a3['cost']/omap[r['geometry_id']]['oracle']['by_k']['3']['cost']-1) if a3['accepted'] else None
    test((g3 is None and r['K3_feasible_gap_percent'] is None) or (g3 is not None and r['K3_feasible_gap_percent'] is not None and near(g3,r['K3_feasible_gap_percent'])),'K3_gap_scope',rid)
    prior=res['baseline']['reported_cost']; last_delta=36; accepted=0
    for j,tr in enumerate(res['trace']):
        ok=tr['candidate_cost']<prior-1e-9; expected_cost=tr['candidate_cost'] if ok else prior
        seed=int.from_bytes(hashlib.sha256(f"{r['search_seed']}/q/{j}".encode()).digest()[:8],'big'); q=random.Random(seed).randint(2,3)
        test(tr['iteration']==j and tr['q']==q and tr['accepted']==ok and near(tr['incumbent_cost'],expected_cost) and last_delta<tr['deltas']<=5000,'trace_acceptance_and_parameter_ledger',{'run':rid,'iteration':j})
        accepted+=ok; prior=tr['incumbent_cost']; last_delta=tr['deltas']
    test(len(res['trace'])==res['iterations_completed'] and res['iterations_started']==res['iterations_completed']+1 and accepted==res['accepted_improvements'] and near(prior,a['cost']) and a['cost']<=b['cost']+1e-8,'trace_terminal_consistency',rid)
    recomputed.append({'run_id':rid,'geometry_id':r['geometry_id'],'family':r['family'],'algorithm':r['algorithm'],'search_seed':r['search_seed'],'cost':a['cost'],'baseline_cost':b['cost'],'gap_percent':gap,'hit':hit,'K3_valid':a3['accepted'],'K3_over':a3['route_count']>3,'baseline_gap_percent':100*(b['cost']/optimum-1)})

summary=read('reports/SUMMARY.json'); geometry=read('reports/GEOMETRY_LEVEL.json'); gmap={g['geometry_id']:g for g in geometry}; geocalc=[]
for gid in inputs:
    rr=[r for r in recomputed if r['geometry_id']==gid]; calc={'geometry_id':gid,'methods':{}}
    for alg in ['random_cheapest','random_regret2']:
        ar=[r for r in rr if r['algorithm']==alg]
        c={'n_seeds':len(ar),'mean_cost':statistics.mean(r['cost'] for r in ar),'mean_gap_percent':statistics.mean(r['gap_percent'] for r in ar),'hit_fraction':statistics.mean(r['hit'] for r in ar),'K3_valid_fraction':statistics.mean(r['K3_valid'] for r in ar)}
        test(len(ar)==4 and set(r['search_seed'] for r in ar)==set(cfg['search_seeds']),'geometry_seed_unit',{'geometry':gid,'algorithm':alg})
        test(all(near(v,gmap[gid]['methods'][alg][k]) for k,v in c.items()),'geometry_aggregate',{'geometry':gid,'algorithm':alg}); calc['methods'][alg]=c
    delta=calc['methods']['random_cheapest']['mean_cost']-calc['methods']['random_regret2']['mean_cost']
    calc['regret2_outcome']='win' if delta>1e-8 else 'loss' if delta < -1e-8 else 'tie'
    calc['gap_difference_cheapest_minus_regret2_pp']=calc['methods']['random_cheapest']['mean_gap_percent']-calc['methods']['random_regret2']['mean_gap_percent']
    test(calc['regret2_outcome']==gmap[gid]['regret2_outcome'] and near(calc['gap_difference_cheapest_minus_regret2_pp'],gmap[gid]['gap_difference_cheapest_minus_regret2_pp']),'paired_geometry',gid)
    geocalc.append(calc)
    test(len({json.dumps(byrun[r['run_id']]['result']['baseline'],sort_keys=True) for r in rr})==1,'baseline_identical_within_geometry',gid)
methodcalc={}
for alg in ['random_cheapest','random_regret2']:
    ar=[r for r in recomputed if r['algorithm']==alg]; gs=[g['methods'][alg] for g in geocalc]; legacy=[r['result'] for r in rawrows if r['algorithm']==alg]
    m={'planned':64,'complete':len(ar),'legal_K9':len(ar),'geometry_mean_gap_percent':statistics.mean(g['mean_gap_percent'] for g in gs),'median_geometry_mean_gap_percent':statistics.median(g['mean_gap_percent'] for g in gs),'maximum_observed_gap_percent':max(r['gap_percent'] for r in ar),'optimal_hits':sum(r['hit'] for r in ar),'optimal_hit_denominator':64,'geometry_average_hit_fraction':statistics.mean(g['hit_fraction'] for g in gs),'K3_valid_outputs':sum(r['K3_valid'] for r in ar),'K3_over_vehicle_limit':sum(r['K3_over'] for r in ar),'deltas':sum(r['deltas'] for r in legacy),'solver_cpu_seconds':sum(r['solver_cpu_seconds'] for r in legacy),'solver_wall_seconds':sum(r['solver_wall_seconds'] for r in legacy),'matrix_distances':sum(r['matrix_distances'] for r in legacy),'objective_edges':sum(r['objective_edges'] for r in legacy),'iterations_completed':sum(r['iterations_completed'] for r in legacy)}
    test(all(near(v,summary['methods'][alg][k]) for k,v in m.items()),'method_summary',alg); methodcalc[alg]=m
    w=max(ar,key=lambda r:r['gap_percent']); test(w['run_id']==summary['methods'][alg]['worst_case']['run_id'],'worst_case_identity',alg)
    for fam in ['uniform','two_cluster']:
        famvalues=[g['methods'][alg]['mean_gap_percent'] for g in geocalc if inputs[g['geometry_id']]['family']==fam]
        test(near(statistics.mean(famvalues),summary['families'][fam][alg]),'family_summary',{'family':fam,'algorithm':alg})
outcomes=dict(Counter(g['regret2_outcome'] for g in geocalc)); diff=statistics.mean(g['gap_difference_cheapest_minus_regret2_pp'] for g in geocalc)
test(outcomes==summary['paired_geometry_outcomes'] and near(diff,summary['mean_paired_gap_difference_cheapest_minus_regret2_pp']),'paired_summary')
baselines=[next(r for r in recomputed if r['geometry_id']==gid) for gid in inputs]; baseline_gap=statistics.mean(r['baseline_gap_percent'] for r in baselines)
test(near(baseline_gap,summary['baseline']['mean_gap_percent']) and summary['baseline']['geometries']==16,'baseline_geometry_summary')
bl=read('reports/BASELINE_BY_GEOMETRY.json')
for r in bl:
    b=next(b for b in baselines if b['geometry_id']==r['geometry_id']); opt=omap[r['geometry_id']]['oracle']['by_k']['9']['cost']; hit=abs(b['baseline_cost']-opt)<=max(1e-8,1e-10*abs(opt))
    test(near(b['baseline_cost'],r['cost']) and near(b['baseline_gap_percent'],r['gap_percent']) and hit==r['hit'],'baseline_by_geometry',r['geometry_id'])
test(summary['baseline']['optimal_hits']==sum(r['hit'] for r in bl),'baseline_hits')
k3calc=[]
for r in read('reports/K3_DIAGNOSTIC.json'):
    ok=omap[r['geometry_id']]['oracle']['by_k']; a=ok['9']; b=ok['3']; premium=100*(b['cost']/a['cost']-1)
    test(r['K3_feasible'] and near(r['K9_optimum'],a['cost']) and near(r['K3_optimum'],b['cost']) and r['K9_nonempty_routes']==a['nonempty_routes'] and near(r['K3_premium_percent'],premium),'K3_diagnostic_report',r['geometry_id']); k3calc.append(premium)
test(summary['K3_diagnostic']['oracle_feasible']==16 and summary['K3_diagnostic']['higher_optimum_than_K9']==sum(x>1e-8 for x in k3calc) and near(summary['K3_diagnostic']['mean_premium_percent'],statistics.mean(k3calc)) and near(summary['K3_diagnostic']['max_premium_percent'],max(k3calc)),'K3_diagnostic_summary')

cross=read('raw/ORACLE_CROSSCHECK.json'); fixtures=read('input/CROSSCHECK_FIXTURES.json'); fmap={x['instance_id']:x for x in fixtures}; fixture_audits=[]
test(len(fixtures)==len(cross['fixtures'])==13 and cross['all_passed'],'recorded_crosscheck_coverage')
for record in cross['fixtures']:
    raw=fmap[record['id']]; n=len(raw['demands'])-1
    test(record['enumerated_candidates']==math.factorial(n)*2**max(0,n-1) and len(record['checks'])==n,'recorded_exhaustive_candidate_count',record['id'])
    for c in record['checks']:
        a=c['oracle']; b=c['brute']; test(c['pass'] and (a is None)==(b is None),'recorded_crosscheck_status',{'fixture':record['id'],'K':c['K']})
        if a is not None and b is not None:
            aa=routes_check(raw,a,c['K']); bb=routes_check(raw,b,c['K']); test(aa['accepted'] and bb['accepted'] and near(a['cost'],b['cost']) and near(a['cost']-b['cost'],c['residual']),'crosscheck_output_routes',{'fixture':record['id'],'K':c['K']}); fixture_audits.append({'fixture':record['id'],'K':c['K'],'oracle':aa,'brute':bb})
completion=read('raw/COMPLETION.json'); receipts={s:read(f'receipts/{s}.json') for s in ['prepare','main','audit']}
for stage,r in receipts.items():
    test(r['exit_code']==0 and r['complete'] and not r['wall_limit_kill'] and r['child_total_cpu_seconds']<=r['cpu_hard_limit_seconds'] and r['elapsed_wall_seconds']<=r['wall_limit_seconds'],'resource_receipt',stage)
test(receipts['main']['cpu_hard_limit_seconds']==90 and receipts['main']['wall_limit_seconds']==150,'main_hard_limits')
test(completion['failure_count']==0 and completion['expected_rows']==128 and read('failures/FAILURES.json')['count']==0,'failure_completion_accounting')
test(read('freeze/PRE_GENERATION_FREEZE.json')['utc']<read('freeze/PRE_RUN_FREEZE.json')['utc']<read('raw/STARTED.json')['utc']<completion['utc'],'recorded_freeze_chronology')
changed=[p for p,h in snapshot.items() if not (ROOT/p).exists() or sha(ROOT/p)!=h]; test(not changed,'read_only_snapshot_unchanged',changed)

limitations=[
'No n=9 solver rerun, trajectory replay, or permutation enumeration was performed. Feasible route and objective recomputation is not an independent proof of global optimality; the oracle conclusion relies on reviewed complete recurrences and recorded n<=6 crosschecks.',
'IEEE double plus tolerance is a numerical validation, not an interval or symbolic certificate. A tolerance hit is not a proof of exact real-valued equality.',
'Delta counters are internally consistent and instrumented directly before expressions in the byte-identical source. Saved traces do not include all intermediate candidate routes or every insertion evaluation, so per-expression runtime counts cannot be independently reconstructed solely from saved traces.',
'Local freeze hashes and UTC fields establish internal consistency of the supplied snapshot, not independently authenticated preregistration or proof that no unrecorded pilot existed.',
'K=9 is nonbinding for nine customers. This is an unlimited-fleet control experiment; it does not validate the heuristics for fixed K=3.',
'There are 16 geometry sampling units, not 128 independent samples. Four paired search seeds are within-geometry replicates; eight geometries per family. No population superiority conclusion is supported.',
'Resource receipts cover numerical child stages and supervisor checkpoints, not all interaction, code authoring, review, packaging, network, or total task costs. This review has its own external wait4 receipt.'
]
source_review={
'held_karp':'For each feasible mask and terminal j, recurrence enumerates every i in mask without j. Positive/nonnegative demand makes all predecessor masks feasible, and numeric mask order places them earlier. Add return-to-depot edge and minimize terminal states to cover every feasible subset tour.',
'partition':'For nonempty mask, any partition has exactly one block containing its least-significant customer. Enumerating all feasible such blocks and recursively partitioning the complement covers every partition without requiring an ordering of vehicles. mask==0 returns zero for any remaining k; thus at most K nonempty routes. k==0 and total demand > kQ prune only infeasible states.',
'K9_semantics':'Any valid solution serving each of nine customers exactly once has at most nine nonempty routes, so K9 is equivalent to the legacy unlimited identical vehicles contract and checker.',
'fixed_controls':'Legacy files are compared byte-for-byte with their declared earlier sources. Savings baseline, random removal q=2..3 at n9, cheapest or regret2 repair, deterministic seed derivation and strict improvement epsilon 1e-9 remain intact.',
'regret2_definition':'Second-best regret is over each existing route\'s best insertion plus a new singleton route, not over the two best insertion positions regardless of route. This is the preserved legacy definition.',
'delta_definition':'One charged savings/removal/insertion expression. Savings costs 36, random removal evaluates no removal deltas, insertion costs 4964 per run. Distance matrix and full objective edge work are separate. Equal deltas do not imply equal CPU or FLOPs.',
'K3_handling':'The primary denominator is always K9. K3 conditional gaps are absent whenever final route count exceeds 3. K3 diagnostics are not combined with primary geometry averages.'}
result={'review_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Independent read-only review; no imported experimental code, no solver or trajectory reruns','source_bundle':str(ROOT),'verdict':'No observed discrepancy in the reviewed frozen controls, supplied route feasibility/costs, accounting ledgers or geometry-level aggregates' if not failures else 'Discrepancies detected','mismatch_count':len(failures),'mismatches':failures,'check_counts':dict(checks),'frozen_snapshots':freezes,'source_files_sha256':{p:h for p,h in snapshot.items() if p.startswith('source/')},'input_artifact_sha256':{p:h for p,h in snapshot.items() if p.startswith(('raw/','reports/','receipts/'))},'source_review':source_review,'counts':{'planned_trajectories':len(schedule),'completed_trajectories':sum(r['status']=='complete' for r in rawrows),'geometry_sampling_units':16,'search_seeds_per_geometry':4,'final_baseline_route_outputs_recomputed':2*len(route_results),'feasible_by_K_route_outputs_recomputed':sum(x['feasible'] for x in oracle_results),'infeasible_by_K_capacity_bounds':sum(not x['feasible'] for x in oracle_results),'subset_tour_outputs_recomputed':len(subset_results),'crosscheck_K_records':sum(len(f['checks']) for f in cross['fixtures']),'crosscheck_feasible_output_pairs_recomputed':len(fixture_audits),'total_charged_deltas':sum(r['result']['deltas'] for r in rawrows)},'recomputed_methods':methodcalc,'recomputed_paired_geometry_outcomes':outcomes,'recomputed_mean_paired_gap_difference_pp':diff,'recomputed_baseline_mean_gap_percent':baseline_gap,'recomputed_geometry_level':geocalc,'all_final_baseline_audits':route_results,'all_by_K_audits':oracle_results,'all_subset_tour_audits':subset_results,'crosscheck_route_audits':fixture_audits,'resource_receipts_inspected':receipts,'limitations':limitations,'own_process_checkpoint':{'cpu_seconds':time.process_time()-T,'wall_seconds':time.perf_counter()-W,'scope':'Checkpoint before writing outputs; full child wait4 receipt is external.'},'main_bundle_files_changed_during_review':changed}
(OUT/'INDEPENDENT_REVIEW.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
report='''独立只读科研审计\n\n范围：从坐标重算全部128个final、128个baseline、112个可行各K最优参考输出及全部容量可行子集tour；独立核对128计划、预算、冻结hash、旧源码身份与16geometry聚合。没有运行求解器、重放搜索轨迹或修改主包。\n\n实质缺陷：本次检查发现的数据或代码语义矛盾数量：%d。严格限定于当前已保存材料；不把未发现矛盾等同于证明全部运行历史。\n\n审计重算：cheapest/regret2 geometry平均gap为%.12f%%/%.12f%%；容差命中%d/64、%d/64；最坏gap %.12f%%/%.12f%%。regret2几何胜/平/负%d/%d/%d，平均gap差%.12f个百分点。更低均值没有消除regret2本次更差最坏值。\n\n每次5000 delta，合计640000；初始化36、随机移除0、插入4964。矩阵、完整目标边和计时另计。128/128完成。K3超车分别%d/64、%d/64，相应K3 gap均为空。K9与9客户无限车辆语义一致；K3没有成为主实验目标。\n\n算法覆盖说明：Held–Karp按末客户递推覆盖每个容量可行子集的所有访问次序；每个分区唯一包含最小编号客户的块，锚定枚举加余集递归覆盖所有容量可行分区。空mask不要求用满剩余车辆，因此是至多K条非空路线。\n\n证据边界：\n%s\n\n费用：主跑OS wait4 CPU %.6f秒、wall %.6f秒；内部后审计CPU %.6f秒。独审自身运行见REVIEW_RECEIPT.json。完整机器可读明细见INDEPENDENT_REVIEW.json；本审计所有输出位于独立目录。\n'''%(len(failures),methodcalc['random_cheapest']['geometry_mean_gap_percent'],methodcalc['random_regret2']['geometry_mean_gap_percent'],methodcalc['random_cheapest']['optimal_hits'],methodcalc['random_regret2']['optimal_hits'],methodcalc['random_cheapest']['maximum_observed_gap_percent'],methodcalc['random_regret2']['maximum_observed_gap_percent'],outcomes.get('win',0),outcomes.get('tie',0),outcomes.get('loss',0),diff,methodcalc['random_cheapest']['K3_over_vehicle_limit'],methodcalc['random_regret2']['K3_over_vehicle_limit'],'\n'.join('- '+x for x in limitations),receipts['main']['child_total_cpu_seconds'],receipts['main']['elapsed_wall_seconds'],receipts['audit']['child_total_cpu_seconds'])
(OUT/'REVIEW_ZH.txt').write_text(report)
print(json.dumps({'mismatch_count':len(failures),'mismatches':failures,'counts':result['counts'],'files':{p.name:sha(p) for p in [OUT/'INDEPENDENT_REVIEW.json',OUT/'REVIEW_ZH.txt']},'cpu_checkpoint_seconds':time.process_time()-T},ensure_ascii=False))
