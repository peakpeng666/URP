"""Additional read-only spotlight checks requested after base audit; no solver calls."""
from pathlib import Path
import json,math,hashlib,time,datetime
ROOT=Path('/workspace/shared/exact_cvrp_controls_20261008'); OUT=Path(__file__).resolve().parent
T=time.process_time();W=time.perf_counter()
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(name): return json.loads((ROOT/name).read_text())
rows=[json.loads(s) for s in (ROOT/'raw/TRAJECTORIES.jsonl').read_text().splitlines()]
oracles=[json.loads(s) for s in (ROOT/'raw/ORACLES.jsonl').read_text().splitlines()]
r=next(r for r in rows if r['run_id']==115);o=next(o for o in oracles if o['geometry_id']=='EX06');raw=read(r['input_file']);base=json.loads((OUT/'INDEPENDENT_REVIEW.json').read_text())
def route_cost(rs):
    xy=raw['coordinates']; return math.fsum(math.sqrt((xy[a][0]-xy[b][0])**2+(xy[a][1]-xy[b][1])**2) for route in rs for a,b in zip(route,route[1:]))
out=r['result']['output']['routes']; served=[j for route in out for j in route[1:-1]];loads=[sum(raw['demands'][j] for j in route[1:-1]) for route in out];cost=route_cost(out);ref=o['oracle']['by_k']['9'];opt=route_cost(ref['routes']);gap=100*(cost/ref['cost']-1)
assert r['geometry_id']=='EX06' and r['search_seed']==83027 and r['algorithm']=='random_regret2'
assert r['input_sha256']==o['input_sha256']==sha(ROOT/r['input_file'])
assert sorted(served)==list(range(1,10)) and len(out)==3 and loads==[6,9,9] and all(x<=9 for x in loads)
assert math.isclose(cost,453.9254750224464,abs_tol=1e-10) and math.isclose(opt,415.25760226207774,abs_tol=1e-10)
assert math.isclose(gap,9.311779615768367,abs_tol=1e-10)
cluster=[r for r in rows if r['family']=='two_cluster']; assert len(cluster)==64 and len({r['geometry_id'] for r in cluster})==8 and all(r['optimal_hit'] for r in cluster)
cheap6=[r for r in rows if r['geometry_id']=='EX06' and r['algorithm']=='random_cheapest'];assert len(cheap6)==4 and all(r['optimal_hit'] for r in cheap6)
assert all(o['oracle']['by_k']['3'] is not None for o in oracles)
newnames=['reports/SHORT_REPORT_ZH.txt','reports/REPRODUCE.txt'];newhash={p:sha(ROOT/p) for p in newnames}
report={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'mismatch_count':0,'base_review_sha256':sha(OUT/'INDEPENDENT_REVIEW.json'),'EX06_worst_regret2':{'run_id':115,'search_seed':83027,'geometry_id':'EX06','input_sha256':r['input_sha256'],'oracle_input_sha256':o['input_sha256'],'routes':out,'loads':loads,'all_customers_exactly_once':True,'route_count':3,'K9_legal':True,'K3_legal':True,'recomputed_cost':cost,'claimed_K9_oracle_cost':ref['cost'],'recomputed_K9_reference_route_cost':opt,'gap_percent':gap,'EX06_cheapest_hits':4,'EX06_cheapest_runs':4},'two_cluster':{'geometry_units':8,'all_rows':64,'tolerance_hits':64,'hits_each_method':32},'K3_scope':'All 16 instances have feasible K3 reference routes. 8 cheapest and 4 regret2 outputs exceed K3; those outputs are infeasible for K3, not the instances. They remain valid K9 results.','new_report_hashes':newhash,'new_report_manual_review':'The short report values and K3 interpretation match independently recomputed findings. Reproduction instructions statically match source/replay.py/common.py/supervise.py; instructions were not executed.','resource_checkpoint':{'cpu_seconds':time.process_time()-T,'wall_seconds':time.perf_counter()-W}}
(OUT/'SPOTLIGHT_ADDENDUM.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
zh='''独立只读审计结论\n\n当前保存材料中发现的数值、路线可行性、预算账本或冻结源码语义矛盾：0项。本结论有明确证据边界，不是运行历史认证或形式化最优证明。\n\n核查范围\n- 128/128计划完成；重算256个final/baseline、112个可行各K参考输出、2,352个容量可行子集tour。K1/K2共32个无解记录由总需求24大于K×9独立确认。\n- 逐文件冻结SHA一致，旧控制源码与申报来源逐字节一致。每次5,000 delta（savings36、random-removal0、insertion4,964），总640,000；矩阵距离与完整目标边另计。\n- 独立核对16个geometry单元、每个4个搜索seed；不能将128次运行视为128个独立样本。\n\n主要复算结果\n- cheapest：几何等权平均gap 0.346618243190%，容差命中56/64，最坏3.706944471008%。\n- regret2：几何等权平均gap 0.183546448877%，容差命中62/64，最坏9.311779615768%。\n- regret2按几何胜/平/负2/13/1；8个双簇几何、两法各32次均容差命中。均值较好不意味着最坏结果较好，也不足以宣称普遍优势。\n\n点名核查EX06\nregret2、seed83027、run115：3条路线，载荷6/9/9，1至9全部恰好服务一次，独立重算453.9254750224464。与同一输入SHA的EX06 K9参考415.25760226207774配对，gap为9.311779615768367%。它同时是合法K9与合法K3解，劣化不能归因于这条输出超车。同几何cheapest四seed均容差命中；本审计不推断失败机制。\n\n车辆语义\nHeld–Karp按末客户覆盖全部可行子集访问次序；锚定最小客户所在块的分区递归覆盖全部可行分区。空客户集直接返回0，不强迫用满车辆，故是至多K条非空回仓路线。9客户的K9与旧无限车辆任务等价。K3只作诊断：16个实例全部有K3可行参考；cheapest的8个、regret2的4个输出超过3条路线，表示这些输出在K3下不合法，不表示实例本身无解。\n\n必须保留的限制\n1. 没有重跑n9求解、搜索轨迹或独立排列穷举。输出成本核对不能独立证明全局最优；完备性判断来自递推源码审查及现有n≤6交叉核查材料。\n2. 浮点容差命中只是数值一致，不是实数精确相等或区间认证证明。\n3. delta计费有源码插桩及一致账本，但原trace未保存所有候选路线和逐次插入求值，不能仅凭trace独立重建每条算术计费事件。\n4. 本地hash及UTC先后只能建立提供材料内部一致性，不能独立认证预注册，也不能证明不存在未记录pilot。\n5. 数值子进程收据不代表包含交互、编写、检查和封包的全任务成本。独审费用单列。\n\n本次独审主体OS wait4：CPU0.373124秒、wall0.379000秒；追加点名检查与封包费用另有收据。未修改主包。完整逐输出明细见INDEPENDENT_REVIEW.json，点名核查见SPOTLIGHT_ADDENDUM.json。\n'''
(OUT/'FINAL_REVIEW_ZH.txt').write_text(zh)
print(json.dumps({'done':True,'mismatch_count':0,'files':{p:sha(OUT/p) for p in ['SPOTLIGHT_ADDENDUM.json','FINAL_REVIEW_ZH.txt']}},ensure_ascii=False))
