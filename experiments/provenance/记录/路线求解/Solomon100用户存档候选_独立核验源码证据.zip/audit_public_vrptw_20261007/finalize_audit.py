"""Write independent audit report and package only its own generated evidence."""
import hashlib,json,resource,time,zipfile
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CPU,(5,5));start=time.process_time()
p=Path(__file__).resolve().parent;b=Path('/workspace/shared/public_vrptw_benchmark_20261007')
s=json.loads((p/'independent_summary.json').read_text());snap=json.loads((p/'source_snapshot.json').read_text())
hashbytes=lambda v:hashlib.sha256(v).hexdigest()
unchanged={n:hashbytes((b/n).read_bytes())==h for n,h in snap.items()}
assert all(unchanged.values())
zp=b.parent/(b.name+'.zip')
with zipfile.ZipFile(zp) as z:
    names=z.namelist();crc=z.testzip();assert crc is None
    assert not any('/inputs/' in n or '/.venv/' in n or '__pycache__' in n for n in names)
    package_matches={n:hashbytes(z.read(b.name+'/'+n))==h for n,h in snap.items()}
    assert all(package_matches.values())
    listed={line[66:]:line[:64] for line in z.read(b.name+'/SHA256SUMS.txt').decode().splitlines()}
    assert all(hashbytes(z.read(b.name+'/'+n))==h for n,h in listed.items())
package={'audited_zip':zp.name,'sha256':hashbytes(zp.read_bytes()),'entries':len(names),'crc_pass':crc is None,'frozen_and_raw_snapshot_matches':package_matches,'all_manifest_hashes_match':True,'original_inputs_excluded':True,'audit_recheck_unchanged':unchanged}
(p/'package_verification.json').write_text(json.dumps(package,indent=2)+'\n')
lines=['# 56个Solomon用户存档候选：独立复核报告','','## 结论','通过。本次112个返回解全部在原连续坐标下满足完整服务、容量、服务开始时间窗和返仓约束。冻结文件、原始记录、作者统计与最终实验ZIP相互一致；未发现需要重跑求解或改变实验控制的问题。','','## 检查范围与方法','本复核只读实验目录，独立编写纯Python标准库解析与路线重放程序。未导入或调用作者checker、求解器或OR-Tools；未求解、下载数据、访问外部账号、修改实验原目录或调整参数。连续路长使用原坐标math.dist和math.fsum；服务时间逐弧加入，允许等待，以最早可行开始服务时刻检查窗上界并检查返仓。容差1e-9。另以50位Decimal平方根独立复算最近整数成本和向上取整时间，与作者isqrt实现交叉验证。九个合成测试包含等待有效解和覆盖、重复客户、容量、开始窗、返仓、内部仓库、起点、重复车辆等违规案例，全部按预期判定。','','## 全集与可行性','- 原输入56份，全部101节点（仓库0与100客户），K=25；容量C2为700，R2/RC2为1000，其余为200','- 六类各档分母：C1=9、C2=8、R1=12、R2=11、RC1=8、RC2=8','- 冻结请求与raw逐条一致，共112条，顺序、run_id、实例、budget、seed均相符，无重复或漏项','- 112/112独立重放有效；每份恰好覆盖100客户一次，车辆编号唯一且不超限，负载/开始服务窗/返仓均通过','- 112个独立量化目标与raw整数目标完全相等；每解弧数=100+使用车辆数，原距离与编码成本的误差均在每弧0.5e-6的界内','- 作者与本复核原距离最大差4.547473508864641e-13；车数、状态、六类分母完全一致','- 全部请求有返回解，UNKNOWN/FAIL/TIMEOUT/未运行均为0；不存在把未找到解判为原问题无解的个案','','## 汇总结果','','|预算ms|类别|有效/全集|平均连续距离|平均车辆数|','|---:|---|---:|---:|---:|']
for g in s['groups']:lines.append(f"|{g['budget_ms']}|{g['family']}|{g['success']}/{g['n']}|{g['distance']['mean']:.6f}|{g['vehicles']['mean']:.6f}|")
lines+=['','同一56实例配对：1000ms相对250ms的距离改善36份、持平20份、变差0份，平均绝对差−25.157089851原距离单位。两预算不是112个独立实验样本。这是每实例各档一次的固定配置记录，没有方差估计、显著性判断或跨硬件性能保证。部分实例/类别使用车数可增加，因为车数并非优化的第一目标。','','## 时间、版本与实际控制','- 环境与启动版本断言：OR-Tools9.14.6206、Linux CPython3.12.14','- 两份参数textproto除time_limit外完全一致；PCI+GLS，lambda=0.1，Routing CP启用，CP-SAT与fallback关闭','- 250ms档实际SolveWithParameters调用wall范围0.249321–0.257363秒，均值0.250411秒；1000ms档0.999342–1.024298秒，均值1.001204秒','- 请求搜索时限总和70秒。调用开销及共享云负载造成实测wall偏差；不能将请求限时视为精确实测时长或CPU预算','- benchmark子进程CPU71.394016秒，supervisor记录正常exit0且未触发wall timeout；runner完成112条','- 独立主审计CPU0.153224秒（进程上限10秒），远低于额外10秒授权，也低于原包预留5秒。本报告与ZIP验证为纯本地轻量后处理，单独记录其资源','- 代码调用Routing CP solver.ReSeed(2026100708)。textproto亦存有sat_parameters.random_seed，但CP-SAT关闭，该字段不构成本次有效CP-SAT随机控制。固定seed不保证短wall预算下跨运行、跨硬件路线一致','','## 冻结与来源边界',f"冻结文件SHA256：{s['freeze_sha256']}",'冻结记录覆盖的14个文件全部保持原哈希；输入56个SHA256均匹配冻结manifest。运行入口先验证冻结哈希，日志完整按冻结单遍顺序写112条；本次检查范围内未见重跑、按结果筛选/调参或冻后更改求解控制。事后增加的finalize.py只负责打包，不属于预冻结求解控制。','实际输入来自用户既有Drive存档URP/工程文件/Resources/Solomon/instances/In。文件名、格式与规模符合Solomon候选结构，但官方字节同一性未经核实。官方ZIP403及未绕过来自实验保存的取数说明，本审计未再次请求外部网站。应称“用户存档Solomon候选”，不升级为已认证官方原版。','本实验目标是K上限内的总距离，未设置车辆固定成本或丢点，所有客户强制服务。它不等价于SINTEF先车辆数、再距离的词典序目标；不得计算或暗示跨口径BKS gap。','保守时间ceil编码可能排除连续边界可行路线；未返回解或编码模型不可行不能据此宣布原连续问题无解。','','## 交付完整性',f"实验ZIP：{zp.name}",f"实验ZIP SHA256：{package['sha256']}",f"38条目CRC和SHA清单全部通过；冻结控制、原raw与实验ZIP内容逐项相符。ZIP无inputs/、虚拟环境或缓存。原输入不再分发，未从存在文件推定再分发许可。实验包含用户私有Drive来源ID，只应保留在已授权私有项目交付中。",'本独审包包含独立脚本、112条指标、逐路线连续重放、56对预算比较、输入哈希审计、源码/raw快照和ZIP验证，不包含原始实例。','','## 文件索引','- independent_audit.py：标准库独立校验实现','- independent_summary.json：结论、全部分组、测试与资源','- independent_metrics.csv / .json：112条独立结果','- independent_replays.json：每路线负载、距离及逐站连续到达/开始服务时间','- independent_pairs.json：56个配对结果','- input_audit.json：56份输入结构与哈希复核','- source_snapshot.json：冻结控制与本次raw的哈希快照','- package_verification.json：实验ZIP完整性与复核后未变核对']
(p/'audit_report_zh.md').write_text('\n'.join(lines)+'\n')
# Adjust only explanatory evidence bounds; not a failure or extra experiment gate.
s['limitations'][1]='Within the checked source, frozen manifests and exact single-pass raw/stdout records, no changed solver controls, duplicate reruns, result-based filtering or tuning were observed.'
(p/'independent_summary.json').write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n')
resource_note={'main_audit_cpu_s':s['resources']['independent_audit_cpu_s'],'report_and_original_zip_validation_cpu_s':time.process_time()-start,'auditor_total_accounted_cpu_s_before_zip':s['resources']['independent_audit_cpu_s']+time.process_time()-start,'no_solver_calls':True,'no_external_requests':True,'original_directory_unchanged':all(unchanged.values())}
(p/'audit_resource.json').write_text(json.dumps(resource_note,indent=2)+'\n')
files=sorted(x for x in p.iterdir() if x.is_file() and x.name!='SHA256SUMS.txt')
(p/'SHA256SUMS.txt').write_text(''.join(hashbytes(x.read_bytes())+'  '+x.name+'\n' for x in files));files.append(p/'SHA256SUMS.txt')
output=p.parent/(p.name+'.zip')
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as z:
    for f in files:z.write(f,p.name+'/'+f.name)
with zipfile.ZipFile(output) as z:assert z.testzip() is None
receipt={'path':str(output),'bytes':output.stat().st_size,'sha256':hashbytes(output.read_bytes()),'entries':len(files),'total_independent_main_and_finalizer_cpu_s':s['resources']['independent_audit_cpu_s']+time.process_time()-start}
(output.parent/(output.name+'.sha256')).write_text(receipt['sha256']+'  '+output.name+'\n')
print(json.dumps(receipt,indent=2))
