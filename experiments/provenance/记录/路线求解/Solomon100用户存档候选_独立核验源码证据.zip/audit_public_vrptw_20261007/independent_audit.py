"""Independent stdlib-only verification. Does not import or run benchmark/checker/OR-Tools."""
import collections, copy, csv, hashlib, json, math, re, resource, statistics, time
from datetime import datetime, timezone
from decimal import Decimal, localcontext, ROUND_CEILING, ROUND_HALF_UP
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CPU,(10,10))
T=time.process_time()
BASE=Path('/workspace/shared/public_vrptw_benchmark_20261007')
OUT=Path(__file__).resolve().parent
EXPECTED_FREEZE='560b8ea1bc131d51417cfe6eb50992168edff17a0c58465ee89fe1793ee82972'
SCALE=1000000
TOL=1e-9
errors=[]
def require(condition,message):
    if not condition: errors.append(message)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(p):return json.loads((BASE/p).read_text())
def dump(name,obj):(OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def parse_original(path):
    lines=path.read_text().splitlines()
    vi=next(i for i,l in enumerate(lines) if l.strip()=='VEHICLE')
    rows=[l.split() for l in lines[vi+1:] if l.strip()]
    vehicle_row=next(r for r in rows if len(r)==2 and all(t.isdecimal() for t in r))
    k,q=map(int,vehicle_row)
    points=[]
    for line in lines:
        fields=line.split()
        if len(fields)!=7:continue
        try: nums=[int(x) for x in fields]
        except ValueError:continue
        points.append(nums)
    if [x[0] for x in points] != list(range(101)):raise ValueError('Not exactly depot 0 and customers 1..100')
    if lines[0].strip().casefold()!=path.stem.casefold():raise ValueError('Name mismatch')
    if any(x[3]<0 or x[4]>x[5] or x[6]<0 for x in points):raise ValueError('Invalid node data')
    if points[0][3:5]!=[0,0] or points[0][6]!=0:raise ValueError('Unexpected depot data')
    return {'k':k,'q':q,'points':points}
# Decimal square root, unrelated to the benchmark's isqrt rounding implementation.
def encoded_arc(a,b):
    with localcontext() as c:
        c.prec=50
        v=Decimal((a[1]-b[1])**2+(a[2]-b[2])**2).sqrt()*SCALE
        return int(v.to_integral_value(rounding=ROUND_HALF_UP)),int(v.to_integral_value(rounding=ROUND_CEILING))
def replay(data,routes,check_ranges=True):
    issues=[];points=data['points'];seen=[];vehicles=[];arcs=[];integer_cost=0;route_details=[]
    if len(routes)>data['k']:issues.append('vehicle_limit')
    for route in routes:
        vid=route.get('vehicle');vehicles.append(vid);nodes=route['nodes']
        if not isinstance(vid,int) or not 0<=vid<data['k']:issues.append('vehicle_id')
        if len(nodes)<3 or nodes[0]!=0 or nodes[-1]!=0:issues.append('depot_endpoints');continue
        if any(not isinstance(n,int) or not 1<=n<len(points) for n in nodes[1:-1]):issues.append('bad_internal_node');continue
        seen.extend(nodes[1:-1]);load=sum(points[n][3] for n in nodes[1:-1])
        if load>data['q']:issues.append('capacity')
        current=float(points[0][4]);encoded=points[0][4]*SCALE;last=0;rd=[];rdistance=0.;mins=[]
        ranges=route.get('encoded_cumul_ranges')
        if check_ranges and (ranges is None or len(ranges)!=len(nodes)-1):issues.append('cumul_count');ranges=None
        for j,node in enumerate(nodes[1:]):
            a,b=points[last],points[node];distance=math.dist((a[1],a[2]),(b[1],b[2]));arcs.append(distance);rdistance+=distance
            arrival=current+a[6]+distance;current=max(arrival,float(b[4]))
            if current>b[5]+TOL:issues.append('return_depot_window' if node==0 else 'service_start_window')
            ic,it=encoded_arc(a,b);integer_cost+=ic;encoded=max(encoded+a[6]*SCALE+it,b[4]*SCALE)
            if encoded>b[5]*SCALE:issues.append('conservative_encoded_window')
            if ranges is not None and check_ranges:
                z=ranges[j]
                if z['node']!=node or z['min']>z['max'] or z['min']<b[4]*SCALE or z['max']>b[5]*SCALE:issues.append('cumul_metadata')
                encoded=max(encoded,z['min'])
                if encoded>z['max']:issues.append('cumul_chain_inconsistent')
            mins.append(b[5]-current);rd.append({'node':node,'arrival':arrival,'service_start':current})
            last=node
        route_details.append({'vehicle':vid,'customers':len(nodes)-2,'load':load,'capacity':data['q'],'distance':rdistance,'return_time':current,'depot_due':points[0][5],'minimum_due_slack':min(mins),'continuous_schedule':rd})
    if collections.Counter(seen)!=collections.Counter(range(1,len(points))):issues.append('customer_exactly_once_coverage')
    if len(vehicles)!=len(set(vehicles)):issues.append('duplicate_vehicle_id')
    return {'valid':not issues,'issues':sorted(set(issues)),'customer_count':len(seen),'vehicles_used':len(routes),'distance':math.fsum(arcs),'integer_cost':integer_cost,'arc_count':len(arcs),'routes':route_details}
# Direct fixtures exercise all validity guards without invoking a solver.
synth={'k':2,'q':3,'points':[[0,0,0,0,0,30,0],[1,3,4,2,6,15,2],[2,0,4,1,0,20,1]]}
route=[{'vehicle':0,'nodes':[0,1,2,0]}]
tests=[]
def test(name,d,r,valid):
    got=replay(d,r,False);require(got['valid']==valid,'selftest:'+name);tests.append({'name':name,'passed':got['valid']==valid,'issues':got['issues']})
test('waiting_and_service_valid',synth,route,True)
test('missing_customer',synth,[{'vehicle':0,'nodes':[0,1,0]}],False)
test('duplicate_customer',synth,[{'vehicle':0,'nodes':[0,1,2,1,0]}],False)
x=copy.deepcopy(synth);x['q']=2;test('capacity_violation',x,route,False)
x=copy.deepcopy(synth);x['points'][1][5]=4;test('start_window_violation',x,route,False)
x=copy.deepcopy(synth);x['points'][0][5]=10;test('depot_return_violation',x,route,False)
test('interior_depot',synth,[{'vehicle':0,'nodes':[0,1,0,2,0]}],False)
test('missing_start',synth,[{'vehicle':0,'nodes':[1,2,0]}],False)
test('duplicate_vehicle',[synth][0],[{'vehicle':0,'nodes':[0,1,0]},{'vehicle':0,'nodes':[0,2,0]}],False)
# Snapshot all referenced immutable evidence, plus completed run files.
freeze=read('protocol/freeze.json');freeze_hash=sha(BASE/'protocol/freeze.json')
require(freeze_hash==EXPECTED_FREEZE,'freeze SHA mismatch')
frozen_checks={name:sha(BASE/name)==digest for name,digest in freeze['sha256'].items()}
for name,okay in frozen_checks.items():require(okay,'frozen file changed:'+name)
family_counts={'C1':9,'C2':8,'R1':12,'R2':11,'RC1':8,'RC2':8}
expected_names=sorted(f'{f.lower()}{n:02d}' for f,count in family_counts.items() for n in range(1,count+1))
files=sorted((BASE/'inputs').glob('*.txt'));require([p.stem for p in files]==expected_names,'instance set differs')
manifest=read('protocol/input_manifest.json');md={m['name']:m for m in manifest};require(len(md)==len(manifest)==56,'manifest count/duplicates')
inputs={};input_audit=[]
for file in files:
    d=parse_original(file);inputs[file.stem]=d;m=md[file.name];fam=re.match(r'(RC|R|C)[12]',file.stem.upper()).group(0)
    okay=sha(file)==m['sha256'];require(okay,'input digest:'+file.name)
    require(d['k']==25,'K not 25:'+file.name);require(d['q']==(700 if fam=='C2' else 1000 if fam in ('R2','RC2') else 200),'unexpected capacity:'+file.name)
    require(m['family']==fam and m['vehicle_limit']==d['k'] and m['capacity']==d['q'] and m['n_customers']==100,'manifest semantics:'+file.name)
    input_audit.append({'instance':file.stem,'sha256':sha(file),'hash_passed':okay,'family':fam,'node_count':len(d['points']),'k':d['k'],'q':d['q']})
requests=read('protocol/requests.json');raw_path=BASE/'raw/results.jsonl';raw=[json.loads(x) for x in raw_path.read_text().splitlines()]
expected=[(name,ms) for i,name in enumerate(expected_names) for ms in ([250,1000] if i%2==0 else [1000,250])]
require(len(requests)==len(raw)==112,'requests/raw not complete112')
require([(r['instance'],r['budget_ms']) for r in requests]==expected,'request order/set')
require([r['run_id'] for r in raw]==[r['run_id'] for r in requests],'raw order/duplicates/missing')
require(len(set(r['run_id'] for r in raw))==len(raw),'raw duplicate IDs')
all_rows=[];replays=[]
for req,row in zip(requests,raw):
    for key,value in req.items():require(row.get(key)==value,'request mismatch:'+key+':'+req['run_id'])
    rec={'run_id':row['run_id'],'instance':row['instance'],'family':row['family'],'budget_ms':row['budget_ms'],'raw_status':row.get('ortools_status_name'),'raw_outcome':row['outcome'],'assignment_returned':row.get('assignment_returned',False),'solve_wall_s':row.get('solve_wall_s'),'solve_cpu_s':row.get('solve_cpu_s'),'model_wall_s':row.get('model_wall_s')}
    if row.get('assignment_returned'):
        rr=replay(inputs[row['instance']],row['routes']);replays.append({'run_id':row['run_id'],**rr})
        require(rr['valid'],'invalid solution:'+row['run_id']+':'+','.join(rr['issues']))
        require(rr['vehicles_used']==row['vehicles_used'],'vehicle mismatch:'+row['run_id'])
        require(rr['integer_cost']==row['objective_integer'],'integer cost mismatch:'+row['run_id'])
        require(rr['arc_count']==100+rr['vehicles_used'],'arc count:'+row['run_id'])
        e=row['objective_integer']/SCALE-rr['distance'];bound=rr['arc_count']/(2*SCALE)
        require(abs(e)<=bound+TOL,'cost error bound:'+row['run_id'])
        rec.update(outcome='SUCCESS' if rr['valid'] else 'FAIL',valid=rr['valid'],vehicles_used=rr['vehicles_used'],distance=rr['distance'],integer_cost=rr['integer_cost'],cost_error=e,error_bound=bound)
    else:
        rec['outcome']='TIMEOUT' if row.get('ortools_status')==4 else 'FAIL' if row.get('ortools_status')==5 or 'error' in row else 'UNKNOWN'
        require(not row.get('routes'),'nonassignment with routes:'+row['run_id'])
    all_rows.append(rec)
require(sum(r['budget_ms'] for r in requests)==70000,'request search budget not70s')
# Independently compare protocol parameter text, ignoring only the requested time_limit.
p250=(BASE/'protocol/parameters_250ms.textproto').read_text();p1000=(BASE/'protocol/parameters_1000ms.textproto').read_text()
striptime=lambda s:re.sub(r'(?m)^time_limit \{[^}]*\}', 'time_limit { REMOVED }',s)
require(striptime(p250)==striptime(p1000),'parameter differences beyond time budget')
require(re.search(r'(?m)^time_limit \{\s+nanos: 250000000\s+\}',p250) is not None,'250ms cap')
require(re.search(r'(?m)^time_limit \{\s+seconds: 1\s+\}',p1000) is not None,'1000ms cap')
env=read('evidence/environment.json');require(env['ortools']=='9.14.6206','version evidence mismatch')
runner=read('raw/runner_resource.json');supervisor=read('raw/supervisor_resource.json')
require(runner['requests_completed']==112 and supervisor['exit_code']==0 and not supervisor['wall_timeout'],'run termination')
require((BASE/'raw/stderr.log').read_text()=='','nonempty stderr')
log=(BASE/'raw/stdout.log').read_text().splitlines();require([l.split()[0] for l in log]==[r['run_id'] for r in requests],'stdout alignment')
def descriptive(values):
    return {'n':len(values),'mean':statistics.mean(values) if values else None,'median':statistics.median(values) if values else None,'min':min(values) if values else None,'max':max(values) if values else None}
groups=[]
for ms in [250,1000]:
    for fam in ['ALL',*family_counts]:
        rs=[r for r in all_rows if r['budget_ms']==ms and (fam=='ALL' or r['family']==fam)];s=[r for r in rs if r['outcome']=='SUCCESS']
        denom=56 if fam=='ALL' else family_counts[fam];require(len(rs)==denom,'family denominator:'+fam+str(ms))
        groups.append({'budget_ms':ms,'family':fam,'n':len(rs),'success':len(s),'outcomes':dict(collections.Counter(r['outcome'] for r in rs)),'distance':descriptive([r['distance'] for r in s]),'vehicles':descriptive([r['vehicles_used'] for r in s]),'solve_wall_s':descriptive([r['solve_wall_s'] for r in rs if r['solve_wall_s'] is not None]),'solve_cpu_s':descriptive([r['solve_cpu_s'] for r in rs if r['solve_cpu_s'] is not None])})
by={(r['instance'],r['budget_ms']):r for r in all_rows};pairs=[]
for name in expected_names:
    a,b=by[name,250],by[name,1000];p={'instance':name,'250ms':a['outcome'],'1000ms':b['outcome']}
    if a['outcome']==b['outcome']=='SUCCESS':p.update(distance_delta=b['distance']-a['distance'],vehicle_delta=b['vehicles_used']-a['vehicles_used'])
    pairs.append(p)
deltas=[p['distance_delta'] for p in pairs if 'distance_delta' in p]
pair_stats={'complete_pairs':len(deltas),'improved':sum(d<-TOL for d in deltas),'same':sum(abs(d)<=TOL for d in deltas),'worse':sum(d>TOL for d in deltas),'delta':descriptive(deltas)}
# Comparison to author's independently produced postprocessing when available.
author_comparison={'present':(BASE/'reports/evaluated_results.json').exists()}
if author_comparison['present']:
    aa=read('reports/evaluated_results.json');ad={r['run_id']:r for r in aa};require(len(aa)==len(ad)==112,'author evaluated count')
    maximum=0.
    for r in all_rows:
        a=ad[r['run_id']];require(a['outcome']==r['outcome'],'author outcome:'+r['run_id'])
        if r['outcome']=='SUCCESS':
            difference=abs(a['original_distance']-r['distance']);maximum=max(maximum,difference)
            require(difference<=TOL and a['vehicles_used']==r['vehicles_used'],'author metric mismatch:'+r['run_id'])
    author_comparison.update(max_distance_discrepancy=maximum,all_records_compared=True)
    if (BASE/'reports/summary.json').exists():
        ag=read('reports/summary.json')['groups'];require(len(ag)==len(groups),'author group count')
        for a,g in zip(ag,groups):require(a['budget_ms']==g['budget_ms'] and a['family']==g['family'] and a['attempted']==g['n'] and a['success']==g['success'],'author group mismatch')
        author_comparison['family_denominators_compared']=True
# Fixed evidence snapshot enables verification after report/packaging steps.
snap_paths=list(freeze['sha256'])+['protocol/freeze.json','raw/results.jsonl','raw/runner_resource.json','raw/supervisor_resource.json','raw/stdout.log','raw/stderr.log']
snapshot={n:sha(BASE/n) for n in snap_paths}
summary={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'scope':'Read-only input/source/raw audit; independent implementation; no solver import/call, no downloads/accounts, no modifications to original experiment directory.','pass':not errors,'errors':errors,'freeze_sha256':freeze_hash,'frozen_files_all_unchanged':all(frozen_checks.values()),'input_count':len(inputs),'request_count':len(requests),'raw_count':len(raw),'outcomes':dict(collections.Counter(r['outcome'] for r in all_rows)),'selftests':tests,'groups':groups,'paired':pair_stats,'author_comparison':author_comparison,'resources':{'runner':runner,'supervisor':supervisor,'prepare':read('evidence/prepare_resource.json'),'independent_audit_cpu_s':time.process_time()-T,'audit_hard_cpu_cap_s':10},'limitations':['Input identities pinned only to user archive bytes; no official byte equivalence independently verified.','Local source and immutable manifest, exact single-pass logs and startup hash validation support the observed one-pass/no-controls-change claim; no independent attestation of all past processes or zero hidden prior runs.','The two budgets are correlated observations on 56 instances, not 112 independent trials. Single wall-clock-capped runs provide no variance estimate, determinism guarantee or broad hardware/performance conclusion.','Routing CP solver.ReSeed(2026100708) is called. sat_parameters.random_seed is stored but CP-SAT is disabled; its presence does not establish active seed control. No cross-platform determinism claim.','Objective is rounded total distance with K<=25, not lexicographic vehicle-first. No official BKS gap is calculated.','Conservative ceil travel times may exclude continuous boundary-feasible routes; lack of returned solution is not original infeasibility.','Process CPU timing is not equal to requested per-search wall-clock budget. Actual timings and overshoots are reported.','Official-download403 and upstream licensing limits are documented but not independently refetched in this read-only audit. Archive ownership metadata is not independently established; use existing user-account archive wording.']}
dump('independent_summary.json',summary);dump('independent_replays.json',replays);dump('independent_metrics.json',all_rows);dump('independent_pairs.json',pairs);dump('input_audit.json',input_audit);dump('source_snapshot.json',snapshot)
with (OUT/'independent_metrics.csv').open('w') as f:
    fields=list(dict.fromkeys(k for r in all_rows for k in r));w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(all_rows)
print(json.dumps({k:summary[k] for k in ['pass','errors','outcomes','paired','author_comparison','resources']},ensure_ascii=False,indent=2))
