"""Independent read-only audit. No solver imports, runs, model or network calls."""
import collections,csv,datetime,hashlib,json,math,random,statistics,sys,time
from pathlib import Path
R=Path('/workspace/shared/vrp_partial_perturbation_20261008')
O=Path(__file__).resolve().parent
start=time.process_time(); errors=[]; checks=collections.Counter(); route_counts=collections.Counter()
def read(p): return json.loads(Path(p).read_text())
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def ck(ok,label,detail=None):
    checks[label]+=1
    if not ok: errors.append({'check':label,'detail':detail})
def near(a,b): return math.isclose(a,b,rel_tol=1e-11,abs_tol=1e-9)
def route(inst,obj,stage,where):
    route_counts[stage]+=1
    rr=obj['routes']; nodes=[]; edges=[]; loads=[]
    ok=isinstance(rr,list) and bool(rr)
    for r in rr:
        ok &= len(r)>=3 and r[0]==r[-1]==0 and all(type(i)==int and 1<=i<=50 for i in r[1:-1])
        nodes+=r[1:-1]; loads.append(sum(inst['demands'][i] for i in r[1:-1]))
        edges += [math.dist(inst['coordinates'][i],inst['coordinates'][j]) for i,j in zip(r,r[1:])]
    value=math.fsum(edges)
    ck(ok and sorted(nodes)==list(range(1,51)) and max(loads)<=30 and near(value,obj['reported_cost']), 'coordinate_route_cost',where)
    return value
cfg=read(R/'freeze/PROTOCOL.json'); schedule=read(R/'freeze/SCHEDULE.json'); manifest=read(R/'freeze/INPUT_MANIFEST.json')
raw=[json.loads(line) for line in (R/'raw/TRAJECTORIES.jsonl').read_text().splitlines()]; summary=read(R/'reports/SUMMARY.json')
ck(len(raw)==len(schedule)==192,'192_rows')
ck(len({r['run_id'] for r in raw})==192,'unique_ids')
ck([r['run_id'] for r in raw]==list(range(192)),'schedule_execution_order')
for name in ['PRE_GENERATION_FREEZE','PRE_RUN_FREEZE']:
    for p,h in read(R/f'freeze/{name}.json')['sha256'].items(): ck(sha(R/p)==h,'freeze_hash',p)
for ln in (R/'SHA256SUMS.txt').read_text().splitlines():
    h,p=ln.split('  ',1); ck(sha(R/p)==h,'package_sha256',p)
for e in read(R/'MANIFEST.json')['files']: ck(sha(R/e['path'])==e['sha256'] and (R/e['path']).stat().st_size==e['bytes'],'manifest',e['path'])
for e in read(R/'freeze/SOURCE_PROVENANCE.json'):
    ck(sha(R/e['path'])==e['sha256'],'provenance_new_hash',e['path'])
    if e['source_sha256']:
        ck(sha(e['source'])==e['source_sha256'],'provenance_old_hash',e['path'])
        ck((sha(e['source'])==sha(R/e['path']))==e['byte_identical'],'provenance_identity_flag',e['path'])
old=read(R/'freeze/OLD_GEOMETRIES.json')
for e in old['sources']: ck(sha(e['path'])==e['sha256'],'old_source_hash',e['path'])
old_inputs=[]
for source in old['sources']:
    ob=read(source['path'])
    if isinstance(ob,list): old_inputs += [(Path(source['path']).parents[1],e) for e in ob]
    elif 'sources' in ob:
        for src in ob['sources']:
            ck(sha(src['path'])==src['sha256'],'older_source_hash',src['path'])
            entries=read(src['path'])
            if isinstance(entries,list): old_inputs += [(Path(src['path']).parents[1],e) for e in entries]
for root,e in old_inputs:
    if 'input_file' in e and (root/e['input_file']).exists():
        ob=read(root/e['input_file']); co=ob.get('coordinates')
        if co is not None:
            h=hashlib.sha256(json.dumps(co,separators=(',',':')).encode()).hexdigest()
            ck(h in old['coordinate_hashes'],'old_actual_coordinate_covered',str(root/e['input_file']))
insts={}; ghash={}; families={}
for e in manifest:
    p=R/e['input_file']; ins=read(p); insts[e['input_file']]=ins
    h=hashlib.sha256(json.dumps(ins['coordinates'],separators=(',',':')).encode()).hexdigest()
    ck(sha(p)==e['input_sha256'] and h==e['coordinate_sha256'],'input_hash',e['input_file'])
    ck(h not in old['coordinate_hashes'] and e['geometry_seed'] not in old['geometry_seeds'],'new_geometry_no_overlap',e['geometry_id'])
    ck(len(ins['coordinates'])==51 and ins['capacity']==30 and ins['demands'][0]==0,'instance_shape',e['input_file'])
    expected=[5]*50 if e['demand_mode']=='constant5' else [1]*25+[9]*25
    ck(sorted(ins['demands'][1:])==expected and sum(ins['demands'])==250,'demand_distribution',e['input_file'])
    if e['demand_mode']!='constant5':
        rng=random.Random(e['geometry_seed']+cfg['demand_seed_offset']);rng.shuffle(expected)
        ck(ins['demands'][1:]==expected,'demand_shuffle',e['input_file'])
    ck(e['geometry_id'] not in ghash or ghash[e['geometry_id']]==h,'demand_shares_geometry',e['geometry_id'])
    ghash[e['geometry_id']]=h;families[e['geometry_id']]=e['family']
ck(len(manifest)==32 and len(ghash)==len(set(ghash.values()))==16,'new_geometry_count')
ck(collections.Counter(families.values())=={'uniform':8,'clustered':8},'family_balance')
expected={(e['geometry_id'],e['demand_mode'],s,a) for e in manifest for s in cfg['search_seeds'] for a in cfg['arms']}
actual=[(r['geometry_id'],r['demand_mode'],r['search_seed'],r['arm']) for r in raw]
ck(len(set(actual))==192 and set(actual)==expected,'factorial_complete')
base={}; obs=collections.defaultdict(list); events=[]; mech=[]; prefixes=collections.defaultdict(dict); event_rows=[]
for call,r in zip(schedule,raw):
    rid=r['run_id']; ins=insts[r['input_file']]; arm=r['arm']; geo=r['geometry_id']
    ck(all(r[k]==v for k,v in call.items()),'call_metadata',rid)
    ck(r['status']=='executed' and r['stop_reason']=='delta_budget' and not r['error'] and not r['missing_budgets'],'status',rid)
    ck(r['deltas']==160000 and r['solver_cpu_seconds']<3 and r['solver_wall_seconds']<10,'budget_and_local_caps',rid)
    curr=best=route(ins,r['baseline'],'baseline',rid)
    key=r['input_file']; ck(key not in base or base[key]==r['baseline'],'same_baseline_all_controls',rid);base[key]=r['baseline']
    stag=0; pending=None; starts=[]; completed=[]; delta_cost=0; niter=0; naccept=0; nbest=0; last_delta=1225
    states=[]; prefix=[]
    for ev in r['trace']:
        typ=ev['event'];ck(last_delta<=ev['deltas']<=160000,'trace_delta_monotone',rid);last_delta=ev['deltas']
        if typ=='perturbation_start':
            ck(arm!='none' and pending is None and stag==8==ev['stagnation'] and ev['perturbation_id']==len(starts),'trigger_8_current',rid)
            ck(near(ev['before_current_cost'],curr) and near(ev['before_best_cost'],best),'event_pre_cost',rid)
            ck(near(route(ins,ev['before_current_output'],'perturbation_pre',rid),curr),'event_pre_route',rid)
            pending=ev;starts.append(ev)
        elif typ=='perturbation_complete':
            ck(pending is not None and ev['perturbation_id']==pending['perturbation_id'] and ev['deltas_before']==pending['deltas'],'event_pair',rid)
            cost=route(ins,ev['output'],'perturbation_post',rid)
            ck(near(cost,ev['current_cost']) and near(ev['before_current_cost'],curr) and near(ev['before_best_cost'],best),'event_costs',rid)
            improved=cost<best-1e-9;ck(ev['best_improved']==improved,'event_best_flag',rid)
            if improved:best=cost;nbest+=1
            ck(near(ev['best_cost'],best),'event_best_retained',rid)
            if arm=='partial40':
                removed=ev['removed']; sd=int.from_bytes(hashlib.sha256(f"{r['search_seed']}/partial_perturbation/{ev['perturbation_id']}".encode()).digest()[:8],'big')
                ck(removed==random.Random(sd).sample(list(range(1,51)),20),'partial_sample_20',rid)
                selected=set(removed)
                before=[[x for x in rr[1:-1] if x not in selected] for rr in pending['before_current_output']['routes']]
                after=[[x for x in rr[1:-1] if x not in selected] for rr in ev['output']['routes']]
                ck([x for x in before if x]==[x for x in after if x],'retained_30_route_order',rid)
            else:ck(ev['removed']==list(range(1,51)),'full_removes_50',rid)
            current_degrade=100*(cost/curr-1);best_gap=100*(cost/ev['before_best_cost']-1)
            events.append({'geometry_id':geo,'arm':arm,'current_degradation':current_degrade,'best_gap':best_gap})
            delta_cost+=ev['deltas']-ev['deltas_before'];completed.append(ev);pending=None;curr=cost;stag=0
        else:
            ck(typ=='iteration' and pending is None and ev['iteration']==niter,'iteration_sequence',rid)
            sd=int.from_bytes(hashlib.sha256(f"{r['search_seed']}/q/{niter}".encode()).digest()[:8],'big')
            ck(ev['q']==random.Random(sd).randint(5,15),'ordinary_q_5_15',rid)
            accepted=ev['candidate_cost']<curr-1e-9;improved=ev['candidate_cost']<best-1e-9
            ck(ev['accepted_current']==accepted and ev['best_improved']==improved,'strict_current_and_best_flags',rid)
            if accepted:curr=ev['candidate_cost'];stag=0;naccept+=1
            else:stag+=1
            if improved:best=ev['candidate_cost'];nbest+=1
            ck(near(curr,ev['current_cost']) and near(best,ev['best_cost']) and stag==ev['stagnation'],'trace_state_replay',rid)
            niter+=1
            if not starts:prefix.append(ev)
        states.append((ev['deltas'],curr,best,niter,stag))
    prefixes[(key,r['search_seed'])][arm]=prefix
    if pending:
        ck(r['current_output']==pending['before_current_output'] and near(r['current_cost'],pending['before_current_cost']),'incomplete_not_committed',rid)
        delta_cost+=160000-pending['deltas']
    ck((len(starts),len(completed),delta_cost,niter,naccept,nbest)==(r['perturbations_started'],r['perturbations_completed'],r['perturbation_deltas'],r['iterations_completed'],r['current_improvements'],r['accepted_improvements']),'trace_aggregate',rid)
    ck(near(route(ins,r['current_output'],'final_current',rid),curr) and near(route(ins,r['output'],'final_best',rid),best),'final_cost_state',rid)
    ck([c['budget'] for c in r['checkpoints']]==[40000,160000],'checkpoint_pair',rid)
    prior=r['baseline']['reported_cost']
    for cp in r['checkpoints']:
        b=cp['budget'];bc=route(ins,cp['output'],'checkpoint_best',rid);cc=route(ins,cp['current_output'],'checkpoint_current',rid)
        ledger=cp['delta_by_kind'];ck(cp['deltas']==b==sum(ledger.values()) and ledger['savings']==1225 and ledger['removal']==0 and cp['matrix_distances']==2601,'checkpoint_delta_ledger',rid)
        st=[s for s in states if s[0]<=b][-1]
        ck(near(bc,st[2]) and near(cc,st[1]) and cp['iterations_completed']==st[3] and cp['stagnation']==st[4],'checkpoint_trace_match',rid)
        pds=sum(max(0,min(b,e['deltas'])-e['deltas_before']) for e in completed)
        if pending:pds+=max(0,b-pending['deltas'])
        ck(pds==cp['perturbation_deltas'],'checkpoint_perturbation_cost',rid)
        ck(bc<=prior+1e-9 and bc<=cc+1e-9 and cp['scoreable'],'checkpoint_best_monotone',rid);prior=bc
        obs[geo,r['demand_mode'],b,arm].append(bc)
    first=completed[0] if completed else None
    later=[e for e in r['trace'] if first and e['deltas']>=first['deltas'] and e['event'] in ('iteration','perturbation_complete')]
    mech.append({'geometry_id':geo,'arm':arm,'started':len(starts),'completed':len(completed),'incomplete':len(starts)-len(completed),'perturbation_deltas':delta_cost,'remaining':160000-first['deltas'] if first else None,'best_improvement':100*(first['before_best_cost']-best)/first['before_best_cost'] if first else None,'best_updates':sum(e['best_improved'] for e in later),'recovered':any(e['current_cost']<=first['before_best_cost']+1e-9 for e in later) if first else False})
for k,p in prefixes.items():ck(p['full']==p['partial40'] and p['full']==p['none'][:len(p['full'])],'identical_pretrigger_3_arms',k)
means={k:statistics.fmean(v) for k,v in obs.items()};ck(all(len(v)==2 for v in obs.values()),'two_seeds_each_cell')
geos=sorted(ghash);geo_values={};contrasts={'partial_vs_full':('partial40','full'),'partial_vs_none':('partial40','none'),'full_vs_none':('full','none')}
for b in cfg['checkpoints']:
    for name,(lhs,rhs) in contrasts.items():
        geo_values[b,name]={g:statistics.fmean(100*(means[g,d,b,rhs]-means[g,d,b,lhs])/means[g,d,b,rhs] for d in cfg['demand_modes']) for g in geos}
rng=random.Random(cfg['bootstrap_seed']); blocks=[[g for g in geos if families[g]==fam] for fam in cfg['families']]
samples=[[rng.choice(block) for block in blocks for _ in range(8)] for _ in range(10000)]
def percentile(v,q):
    v=sorted(v);x=q*(len(v)-1);i=int(x);return v[i]+(v[min(i+1,len(v)-1)]-v[i])*(x-i)
statistics_out=[]
for key,vals in geo_values.items():
    bs=[statistics.fmean(vals[g] for g in draw) for draw in samples];vs=list(vals.values())
    r={'budget':key[0],'contrast':key[1],'geometry_count':16,'mean_percent':statistics.fmean(vs),'ci_low':percentile(bs,.025),'ci_high':percentile(bs,.975),'wins':sum(v>1e-9 for v in vs),'ties':sum(abs(v)<=1e-9 for v in vs),'losses':sum(v< -1e-9 for v in vs)}
    published=next(x for x in summary['contrasts'] if (x['budget'],x['contrast'])==key)
    ck(all(near(v,published[k]) if isinstance(v,float) else v==published[k] for k,v in r.items()),'independent_bootstrap_summary',key);statistics_out.append(r)
arm_out=[]
def geomavg(rows,key):
    d=collections.defaultdict(list)
    for r in rows:
        if r[key] is not None:d[r['geometry_id']].append(r[key])
    return statistics.fmean(statistics.fmean(v) for v in d.values()) if d else None
for arm in cfg['arms']:
    mm=[m for m in mech if m['arm']==arm];ee=[e for e in events if e['arm']==arm]
    a={'arm':arm,'trajectories':len(mm),'triggered_trajectories':sum(m['started']>0 for m in mm),'total_started':sum(m['started'] for m in mm),'total_completed':sum(m['completed'] for m in mm),'total_incomplete':sum(m['incomplete'] for m in mm),'total_perturbation_deltas':sum(m['perturbation_deltas'] for m in mm),'perturbation_budget_percent':100*sum(m['perturbation_deltas'] for m in mm)/(64*160000),'geom_equal_event_current_degradation_percent':geomavg(ee,'current_degradation'),'geom_equal_event_best_gap_percent':geomavg(ee,'best_gap'),'geom_equal_budget_after_first_completion':geomavg(mm,'remaining'),'geom_equal_best_improvement_since_first_start_percent':geomavg(mm,'best_improvement'),'geom_equal_best_updates_since_first_start':geomavg(mm,'best_updates') if ee else None,'trajectories_with_best_improvement_since_first_start':sum(m['best_updates']>0 for m in mm),'trajectories_recovered_preperturbation_best':sum(m['recovered'] for m in mm)}
    pub=next(x for x in summary['arms'] if x['arm']==arm)
    ck(all(v==pub[k] if v is None or not isinstance(v,float) else near(v,pub[k]) for k,v in a.items()),'independent_mechanism_summary',arm);arm_out.append(a)
account=read(R/'reports/RESOURCE_ACCOUNTING.json');receipt=read(R.parent/(R.name+'_archive_receipt.json'))
ck(all(e['exit_code']==0 and not e['wall_timeout'] for e in account['phases']),'all_phase_exits_zero')
run=next(e for e in account['phases'] if e['phase']=='run');ck(run['child_total_cpu_seconds']<=120 and run['wall_seconds']<=180,'main_resource_cap')
ck(sha(receipt['archive'])==receipt['sha256'] and Path(receipt['archive']).stat().st_size==receipt['bytes'],'archive_integrity')
ck(read(R/'freeze/PRE_GENERATION_FREEZE.json')['utc']<read(R/'freeze/PRE_RUN_FREEZE.json')['utc']<read(R/'raw/STARTED.json')['utc']<min(r['started_utc'] for r in raw),'freeze_timestamp_order')
ck(all(r['finished_utc']>=r['started_utc'] for r in raw),'trajectory_time_order')
ck(read(R/'failures/FAILURES.json')=={'count':0,'rows':[],'retries':0},'failure_receipt')
smoke=read(R/'raw/SMOKE_TESTS.json');ck(len(smoke['tests'])==9 and all(x['passed'] for x in smoke['tests']),'recorded_smoke_tests')
source=(R/'source/perturbation.py').read_text();oldsource=(R/'source/reference_ablation.py').read_text()
ck("state['stagnation']>=cfg['restart_stagnation_iterations']" in source and "state['stagnation']>=cfg['restart_stagnation_iterations']" in oldsource,'same_current_trigger_source')
result={'status':'PASS' if not errors else 'FAIL','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Independent read-only coordinate, trace, freeze, archive and statistical audit. No solver execution or solver/checker imports. Source and receipts inspected.','errors':errors,'checks':dict(checks),'route_audits':dict(route_counts),'total_route_audits':sum(route_counts.values()),'raw_trajectories':len(raw),'checkpoints':sum(len(r['checkpoints']) for r in raw),'independent_geometries':16,'old_geometry_hashes':len(old['coordinate_hashes']),'old_actual_inputs_checked':checks['old_actual_coordinate_covered'],'statistics':statistics_out,'mechanism':arm_out,'resource_source':{'run_cpu':run['child_total_cpu_seconds'],'run_wall':run['wall_seconds'],'all_stage_cpu':account['measured_stage_cpu_seconds'],'archive_supervisor_cpu':receipt['supervisor_cpu_seconds']},'definitions_and_limits':['1.593602% partial and 87.430677% full are new-current / pre-best gaps, not new-current / pre-current degradation. The latter is 1.407836% vs 85.570559%.','Event diagnostics are event-weighted within geometry, then geometry-equal; they are conditional descriptive comparisons, not isolated causal effects.','High-variance demands are a randomly permuted balanced bimodal vector: 25 ones + 25 nines, not uniform random integers 1..9.','Primary interval favors partial over this legacy full constructor; partial vs none interval spans zero and has 8 wins / 8 losses. No superiority over none is established.','Partial regret2 vs legacy full random-order cheapest also changes construction procedure, so this is not a pure destruction-fraction ablation.','Checkpoint delta ledger includes initial savings and direct insertion comparisons; removal makes no distance-delta arithmetic. Objective edges, matrix distance and auditing CPU are separate. Not equal FLOPs, CPU or objective calls.','Static source identity, trace replay and recorded smoke support control preservation; no independent rerun of solver, initial savings or repairs was done. Ordinary rejected candidates have costs but not stored route outputs, so those transient route states cannot be independently audited.','Freeze timestamps and no-call resource counts are process-generated evidence, not an external timestamp authority or complete infrastructure billing ledger. No audit API/model/paid resource calls occurred.','New inputs do not overlap the registered old coordinate hashes and source manifests checked; this does not prove no data exist outside the registered history.','No report change or solver rerun was performed. Audit costs are separate from the experiment.'],'cpu_seconds_before_write':time.process_time()-start}
with (O/'INDEPENDENT_REVIEW.json').open('x') as f:json.dump(result,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
print(json.dumps({'status':result['status'],'errors':errors,'routes':result['total_route_audits'],'cpu':time.process_time()-start},ensure_ascii=False))
sys.exit(0 if not errors else 1)
