公开基准与solver portfolio后端独立核验

最终结论：PASS。首次独审发现同步raw/evaluated可接受负CPU耗时；修复后完整重跑，18项错误包均拒绝。初版证据保留在initial_findings.json。

独立检查结果
- 两新归档共336条运行：112条公开候选基线全部合法；224条配置组合中217合法、7 TIMEOUT。
- 以独立输入解析和标准库算术逐项核验329合法候选：2,842条原生车辆路线、32,900条客户逐站记录，包括坐标、需求、到达/等待/开始/离开、返仓、累计服务需求、连续距离及整数目标。
- 全部56输入的原字节hash、解析语义hash和完整编码hash独立重算一致；坐标仅4个geometry groups。
- 每次搜索预算保留毫秒wall-clock上限；3,360个实际计时字段不替换、不合并、不与预算混同。
- 7 TIMEOUT保留no_solution，问题可行性unknown；routes、missing、audit及距离保持null/不适用，不伪造空路线或无解证明。
- 与上一版后端分别重新导入旧240+96条：实验fingerprint、全部index字段、列表、run和vehicle API字段hash均完全相同。
- 84次真实本机HTTP请求通过；49项原证据附件逐字节核对；路线POST拒绝，跨不同原问题比较拒绝。
- 新两实验比较为336条、56逻辑输入、6组算法/预算；7次失败留在分母，不按零距离排名。
- 四份原档案导入前后逐文件SHA-256相同。没有运行solver、导入归档Python、调用外部API、修改UI、push或upload。

拒绝反例（18项）
同步重写协议再冻结、改算法参数再冻结、假编码hash、改原输入字节、改checker、伪造逐站时刻、重复原vehicle ID、错误用车数、伪造整数目标、错误超时码、超时假空路线、错误几何分组、负实际CPU耗时、布尔CPU耗时、字符串CPU耗时、非有限CPU耗时、负first-solution耗时、缺请求。

复现
PYTHONDONTWRITEBYTECODE=1 python -B independent_audit.py
脚本默认使用本轮已授权的/workspace/shared档案与前后版本后端。输出本目录及临时数据库；临时数据库自动清理。运行时约40秒，不安装依赖。以下环境变量可覆盖全部路径，默认值保留便于本环境重跑：
- RESEARCH_CONSOLE_CANDIDATE_ROOT：待核验research_console源码根目录
- RESEARCH_CONSOLE_BASELINE_ROOT：上一版research_console源码根目录
- PUBLIC_VRPTW_SOURCE_ROOT：112条公开候选原归档
- PORTFOLIO_VRPTW_SOURCE_ROOT：224条组合原归档
- VRPTW_SOURCE_ROOT：旧240条原归档
- MATURE_VRPTW_SOURCE_ROOT：旧96条成熟求解器原归档
- PUBLIC_VRPTW_INPUT_ROOT：共享授权输入目录，默认PUBLIC_VRPTW_SOURCE_ROOT/inputs
- PUBLIC_ROUTE_AUDIT_OUTPUT：证据输出目录，默认脚本所在目录
环境变量覆盖解析及缓存过滤另通过environment_override_smoke.json核验。完整数据独审已在文档更新后再次运行。

证据
independent_audit.py：独立核验脚本。
independent_audit_report.json：最终结构化报告，包含源码快照、旧指纹、新收据和拒绝错误码。
independent_audit_report.txt：最终简报。
independent_audit.log：最终运行输出。
source_hashes_before.json / source_hashes_after.json：四源档案前后逐文件hash。
initial_findings.json：首轮发现及修复前证据，非最终失败。
documentation_refresh.json：前次完整独审以后仅README.md、config/sources.json、docs/PUBLIC_ROUTE_API.md变化，生产后端无变化；当前完整重跑报告已刷新源码hash。
pre_documentation_refresh_report.json：文档更新前已通过的报告，留作来源对照。
源码manifest排除__pycache__、*.pyc、*.pyo，原档案字节核验仍保留全文件范围。
frontend_core_95_manifest.json：历史95项前端/core清单已重新定位并逐项hash核对；原面板目录、历史full_source与历史全源码ZIP字节相同。verify_frontend_core_manifest.py可重跑此检查。此证据仅适用于历史包，本次research_console后端-only源码不包含这些95文件，亦未作前端联调、视觉验收或本次新全源码包一致性声明。

科学与环境边界
官方上游字节同一性仍未认证；56个命名实例只有4套坐标几何，不能当56独立几何或泛化证据。
目标为固定车辆K上限下距离单目标；与官方车辆优先词典序不同，不提供官方BKS gap。
load_before/load_after是累计已服务需求，onboard_load=null，不冒充实时载荷。
本轮实际在云端CPython3.12运行。Python3.10仅静态AST语法兼容；未在Ubuntu22.04/Python3.10实机验收。
