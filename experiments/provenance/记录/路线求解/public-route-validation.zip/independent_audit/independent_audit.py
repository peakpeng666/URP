#!/usr/bin/env python3
"""Read-only source/experiment audit. Writes only this audit directory and temp dirs.
Does not import archive code, run solvers, call external APIs, alter UI or upload.
"""
import ast
import copy
import hashlib
import http.client
import json
import math
import os
import platform
import re
import subprocess
import sys
import tempfile
import threading
import time
from collections import Counter
from pathlib import Path

sys.dont_write_bytecode = True
SCRIPT_DIR = Path(__file__).resolve().parent
BASE = Path('/workspace/shared')

def environment_path(name, default):
    return Path(os.environ.get(name, str(default))).expanduser().resolve()

HERE = environment_path('PUBLIC_ROUTE_AUDIT_OUTPUT', SCRIPT_DIR)
CANDIDATE = environment_path('RESEARCH_CONSOLE_CANDIDATE_ROOT', BASE/'panel_public_routes_backend_20261007/research_console')
BASELINE = environment_path('RESEARCH_CONSOLE_BASELINE_ROOT', BASE/'panel_route_mature_backend_20261007/research_console')
PUBLIC = environment_path('PUBLIC_VRPTW_SOURCE_ROOT', BASE/'public_vrptw_benchmark_20261007')
PORTFOLIO = environment_path('PORTFOLIO_VRPTW_SOURCE_ROOT', BASE/'solver_portfolio_headroom_20261007')
OLD = environment_path('VRPTW_SOURCE_ROOT', BASE/'vrp_time_windows_20261007')
MATURE = environment_path('MATURE_VRPTW_SOURCE_ROOT', BASE/'vrptw_mature_solver_20261007')
INPUTS = environment_path('PUBLIC_VRPTW_INPUT_ROOT', PUBLIC/'inputs')
ROOTS = [PUBLIC, PORTFOLIO, OLD, MATURE]
SOURCE_ROOTS = ROOTS if any(INPUTS.is_relative_to(root) for root in ROOTS) else ROOTS + [INPUTS]
SCALE = 1000000

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False)

def digest(blob):
    return hashlib.sha256(blob).hexdigest()

def hash_value(value):
    return digest(canonical(value).encode())

def snapshot(root, omit_caches=False):
    return {str(p.relative_to(root)):digest(p.read_bytes()) for p in sorted(root.rglob('*'))
            if p.is_file() and (not omit_caches or ('__pycache__' not in p.parts and p.suffix not in {'.pyc','.pyo'}))}

def close(a,b):
    assert math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-9), (a,b)

def parse_original(path):
    lines=path.read_text().splitlines()
    offset=lines.index(next(x for x in lines if x.strip()=='VEHICLE'))
    fleet,capacity=[int(x) for x in lines[offset+2].split()]
    nodes={}
    for line in lines:
        parts=line.split()
        if len(parts)==7 and all(re.fullmatch('-?[0-9]+',x) for x in parts):
            nid,x,y,demand,ready,due,service=map(int,parts)
            assert nid not in nodes
            nodes[nid]={'id':nid,'x':x,'y':y,'demand':demand,'ready':ready,'due':due,'service':service}
    assert sorted(nodes)==list(range(101))
    name=path.stem
    family=re.match('(rc|r|c)[12]',name).group(0).upper()
    return {'id':name,'family':family,'vehicles':fleet,'capacity':capacity,'nodes':[nodes[i] for i in sorted(nodes)]}

def encoded_hash(data):
    cost=[]; travel=[]
    for a in data['nodes']:
        cr=[];tr=[]
        for b in data['nodes']:
            square=((a['x']-b['x'])**2+(a['y']-b['y'])**2)*SCALE*SCALE
            floor=math.isqrt(square)
            cr.append(floor+(4*square>=(2*floor+1)**2))
            tr.append(floor+(floor*floor<square))
        cost.append(cr);travel.append(tr)
    return hash_value({'cost_nearest':cost,'travel_ceil':travel,'service_exact':[n['service']*SCALE for n in data['nodes']]})

def baseline_result():
    code='''import hashlib,json,sys,tempfile\nfrom pathlib import Path\nfrom backend.store import Store,canonical\nfrom backend.routes import import_vrptw,RouteReader\nfrom backend.mature_routes import import_mature\ndef hv(x):return hashlib.sha256(canonical(x).encode()).hexdigest()\nwith tempfile.TemporaryDirectory() as d:\n s=Store(Path(d)/"old.sqlite3");rs=[import_vrptw(s,Path(sys.argv[1])),import_mature(s,Path(sys.argv[2]))];out={}\n for r in rs:\n  rr=RouteReader(s,r["id"]);views={"instances":rr.instances(),"runs":rr.runs(),"run_detail":{k:rr.run(k) for k in rr.index["runs"]},"vehicles":{k:[rr.vehicle(k,i) for i in range(rr.index["instances"][v["instance_id"]]["vehicles"])] for k,v in rr.index["runs"].items()}}\n  out[r["id"]]={"receipt":r,"index_sha256":hv(rr.index),"api_fields_sha256":hv(views),"run_count":len(rr.index["runs"])}\n print(json.dumps(out))'''
    env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':str(BASELINE)}
    completed=subprocess.run([sys.executable,'-B','-c',code,str(OLD),str(MATURE)],cwd=HERE,env=env,capture_output=True,text=True,check=True)
    return json.loads(completed.stdout)

def load_package(root,fmt):
    freeze=json.loads((root/'protocol/freeze.json').read_text())
    names=list(freeze['sha256'])+['protocol/freeze.json','raw/results.jsonl','reports/evaluated_results.json','evidence/verification.json']
    if 'portfolio' in fmt:names+=['raw/continuous_checks.jsonl']
    return {name:(root/name).read_bytes() for name in names}

def replace_json(blobs,name,value,refreeze=False):
    blobs[name]=(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode()
    if refreeze:
        freeze=json.loads(blobs['protocol/freeze.json'])
        freeze['sha256'][name]=digest(blobs[name])
        blobs['protocol/freeze.json']=json.dumps(freeze).encode()

def replace_rows(blobs, rows, results=None):
    blobs['raw/results.jsonl']=('\n'.join(json.dumps(x,ensure_ascii=False) for x in rows)+'\n').encode()
    if results is not None:replace_json(blobs,'reports/evaluated_results.json',results)

def main():
    began=time.time()
    HERE.mkdir(parents=True, exist_ok=True)
    before={str(root):snapshot(root) for root in SOURCE_ROOTS}
    (HERE/'source_hashes_before.json').write_text(json.dumps(before,indent=2)+'\n')
    baseline=baseline_result()
    sys.path.insert(0,str(CANDIDATE))
    from backend.store import Store,StoreError
    from backend.routes import RouteReader,import_vrptw
    from backend.mature_routes import import_mature
    from backend.public_routes import import_public,normalize_public,PUBLIC_FORMAT,PORTFOLIO_FORMAT
    from backend.route_comparison import compare_routes
    from backend.server import make_server
    report={'status':'RUNNING','environment':{'python':sys.version,'platform':platform.platform()},'source_code_sha256':snapshot(CANDIDATE, omit_caches=True),
            'legacy_baseline':baseline,'checks':{},'mutation_checks':[], 'failures':[],
            'path_configuration':{'candidate':str(CANDIDATE),'baseline':str(BASELINE),'public_archive':str(PUBLIC),
                'portfolio_archive':str(PORTFOLIO),'old_archive':str(OLD),'mature_archive':str(MATURE),
                'authorized_inputs':str(INPUTS),'output':str(HERE)},'source_manifest_excludes':['__pycache__','*.pyc','*.pyo']}
    failures=report['failures']
    report['checks']['no_solver_imported']=not any(k=='ortools' or k.startswith('ortools.') for k in sys.modules)
    parsed={path.stem:parse_original(path) for path in sorted(INPUTS.glob('*.txt'))}
    assert len(parsed)==56
    geometries={hash_value({'depot':[x['nodes'][0]['x'],x['nodes'][0]['y']], 'customers':sorted([n['x'],n['y']] for n in x['nodes'][1:])}) for x in parsed.values()}
    assert len(geometries)==4
    report['checks']['independently_parsed_inputs']=56
    report['checks']['independently_computed_geometry_groups']=4
    encoded={name:encoded_hash(value) for name,value in parsed.items()}
    manifest=json.loads((PUBLIC/'protocol/input_manifest.json').read_text())
    for row in manifest:
        data=parsed[Path(row['name']).stem]
        assert row['semantic_sha256']==hash_value(data)
        assert row['encoded_sha256']==encoded[data['id']]
        assert digest((INPUTS/row['name']).read_bytes())==row['sha256']
    report['checks']['manifest_encoded_hashes_independently_verified']=56
    with tempfile.TemporaryDirectory(prefix='independent-public-audit-',dir=HERE) as tmp:
        store=Store(Path(tmp)/'fresh.sqlite3')
        old_receipts=[import_vrptw(store,OLD),import_mature(store,MATURE)]
        for receipt in old_receipts:
            rid=receipt['id'];rr=RouteReader(store,rid)
            views={'instances':rr.instances(),'runs':rr.runs(),'run_detail':{k:rr.run(k) for k in rr.index['runs']},
                   'vehicles':{k:[rr.vehicle(k,i) for i in range(rr.index['instances'][v['instance_id']]['vehicles'])] for k,v in rr.index['runs'].items()}}
            assert receipt==baseline[rid]['receipt'],(rid,'receipt differs')
            assert hash_value(rr.index)==baseline[rid]['index_sha256'],(rid,'index differs')
            assert hash_value(views)==baseline[rid]['api_fields_sha256'],(rid,'API differs')
        report['checks']['legacy_336_all_fields_and_fingerprints_unchanged']=True
        readers={};receipts={};raws={};all_vehicles=all_stops=0;timing_fields=0
        for root,fmt,total,passed in [(PUBLIC,PUBLIC_FORMAT,112,112),(PORTFOLIO,PORTFOLIO_FORMAT,224,217)]:
            receipt=import_public(store,root,fmt,input_dir=INPUTS);eid=receipt['id'];receipts[eid]=receipt
            assert import_public(store,root,fmt,input_dir=INPUTS)['reused']
            reader=RouteReader(store,eid);readers[eid]=reader
            index=reader.index;rows=[json.loads(x) for x in (root/'raw/results.jsonl').read_text().splitlines()];raws[eid]=rows
            rawlines=(root/'raw/results.jsonl').read_bytes().splitlines()
            evaluated=json.loads((root/'reports/evaluated_results.json').read_text())
            assert index['summary']['run_count']==total
            assert index['summary']['geometry_group_count']==4
            assert sum(r['full_service_success'] for r in index['runs'].values())==passed
            assert index['semantics']['official_byte_identity']=='unverified'
            assert index['semantics']['objective']=='distance_only_with_fixed_vehicle_upper_bound'
            assert index['semantics']['is_road_network'] is False
            assert 'cumulative_served_demand' in index['semantics']['load']
            assert 'inclusive_service_start'==index['semantics']['time_window']
            for row in manifest:
                instance=index['instances'][Path(row['name']).stem];original=parsed[instance['id']]
                for key in ['id','family','vehicles','capacity']:assert instance[key]==original[key]
                for actual,source in zip(instance['nodes'],original['nodes']):
                    for key,value in source.items():assert actual[key]==value
                    assert actual['window']==[source['ready'],source['due']]
            for line_number,(raw,result) in enumerate(zip(rows,evaluated)):
                run=reader.run(raw['run_id']);data=parsed[raw['instance']];nodes={n['id']:n for n in data['nodes']}
                assert run['budget']=={'value':raw['budget_ms'],'unit':'milliseconds','scope':'per_call_search_wall_clock'}
                assert run['source_routes']==raw['routes']
                assert run['provenance']['run_sha256']==digest(rawlines[line_number])
                assert run['source_status']==result['outcome']
                assert run['provenance']['source_run_id']==raw['run_id']
                assert run['metrics']['bks_gap_percent'] is None
                for key,value in raw.items():
                    if key.endswith('_s'):
                        assert run['metrics'][key]==value
                        timing_fields+=1
                assert run['solver_status']['code']==raw.get('ortools_status')
                assert run['solver_status']['name']==raw.get('ortools_status_name')
                if raw['routes'] is None:
                    assert raw['outcome']=='TIMEOUT'
                    assert run['solution_status']=='no_solution'
                    assert run['full_service_success'] is False
                    assert run['problem_feasibility']['status']=='unknown'
                    for k in ['routes','unserved_task_ids']:assert run[k] is None
                    assert run['vehicles']==[]
                    assert run['checker']['audit'] is None
                    assert run['checker']['recorded_audit'] is None
                    assert run['checker']['recomputed_at_import'] is False
                    assert run['metrics']['full_service_distance'] is None
                    for vehicle in range(data['vehicles']):assert reader.vehicle(raw['run_id'],vehicle)['vehicle'] is None
                    continue
                assert run['solution_status']=='feasible'
                assert len(run['vehicles'])==raw['vehicles_used']
                total_distance=0.0;integer_objective=0;served=[]
                assert run['routes']==[r['nodes'][1:-1] for r in raw['routes']]
                for source,vehicle in zip(raw['routes'],run['vehicles']):
                    all_vehicles+=1
                    vid=source['vehicle'];path=source['nodes'];served.extend(path[1:-1])
                    assert vehicle['vehicle_id']==vehicle['vehicle']==vid
                    assert vehicle['path_node_ids']==path
                    assert vehicle['route']==path[1:-1]
                    assert reader.vehicle(raw['run_id'],vid)['vehicle']==vehicle
                    assert vehicle['encoded_cumul_ranges']==source['encoded_cumul_ranges']
                    assert vehicle['path_coordinates']==[[nodes[n]['x'],nodes[n]['y']] for n in path]
                    now=0.0;distance=0.0;load=0
                    assert len(vehicle['stops'])==len(path)-2
                    for position,(a,b) in enumerate(zip(path,path[1:])):
                        na,nb=nodes[a],nodes[b]
                        leg=math.hypot(na['x']-nb['x'],na['y']-nb['y'])
                        square=((na['x']-nb['x'])**2+(na['y']-nb['y'])**2)*SCALE*SCALE
                        floor=math.isqrt(square);integer_objective+=floor+(4*square>=(2*floor+1)**2)
                        arrival=now+leg;start=max(arrival,nb['ready']);depart=start+nb['service']
                        assert start<=nb['due']+1e-9
                        distance+=leg
                        if b:
                            actual=vehicle['stops'][position];all_stops+=1
                            expected={'arrival':arrival,'wait':start-arrival,'start':start,'service_start':start,'depart':depart,
                                      'window_open':nb['ready'],'window_close':nb['due'],'lateness':0.0,'demand':nb['demand'],
                                      'leg_distance':leg,'load_before':load,'load_after':load+nb['demand']}
                            assert actual['node']==b and actual['sequence']==position+1
                            for key,value in expected.items():close(actual[key],value)
                            assert actual['onboard_load'] is None
                            load+=nb['demand']
                        else:
                            close(vehicle['return_time'],start);close(vehicle['return_leg_distance'],leg)
                        now=depart
                    close(vehicle['distance'],distance);assert vehicle['load']==load<=data['capacity']
                    total_distance+=distance
                assert sorted(served)==list(range(1,101))
                close(run['metrics']['original_distance'],total_distance)
                close(run['metrics']['full_service_distance'],total_distance)
                assert run['metrics']['objective_integer']==integer_objective
            source_artifacts=0
            for name,expected in index['sources'].items():
                aid=name.replace('/','-').replace('.','-')
                ref,blob=store.artifact(eid,aid)
                assert blob==(root/name).read_bytes()
                assert ref['sha256']==expected==digest(blob)
                source_artifacts+=1
            assert all(not a['filename'].endswith('.txt') for a in store.get(eid)['artifacts'])
            report['checks'][fmt]={'runs':total,'legal':passed,'timeouts':total-passed,'source_artifacts_byte_exact':source_artifacts,'idempotent':True}
        report['receipts']=receipts
        report['checks']['all_new_valid_vehicles']=all_vehicles
        report['checks']['all_new_valid_stops']=all_stops
        report['checks']['actual_timing_fields_preserved']=timing_fields
        public_id=next(iter(readers));portfolio_id=list(readers)[1]
        comparison=compare_routes(store,[{'experiment_id':eid} for eid in readers])
        assert comparison['row_count']==336 and comparison['unique_input_count']==56
        assert len(comparison['groups'])==6
        assert comparison['same_known_budget'] is False
        for row in comparison['rows']:
            if row['solution_status']!='feasible':
                assert row['full_service_distance'] is None and row['distance_minus_best_returned_full'] is None
        report['checks']['new_comparison']={'runs':336,'inputs':56,'groups':6,'timeouts_in_denominator':7}
        try:compare_routes(store,[{'experiment_id':public_id},{'experiment_id':old_receipts[0]['id']}])
        except StoreError as exc:assert exc.status==409
        else:raise AssertionError('incompatible problems accepted')
        report['checks']['legacy_public_comparison_rejected']=True
        server=make_server(store,PUBLIC,0);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();request_count=0
        def get(url,method='GET'):
            nonlocal request_count
            c=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=20)
            c.request(method,url);r=c.getresponse();b=r.read();headers=dict(r.getheaders());c.close();request_count+=1
            return r.status,headers,b
        try:
            assert get('/api/health')[0]==200
            for eid,reader in readers.items():
                for path in ['/instances','/runs','/runs?solution_status=no_solution']:
                    assert get('/api/experiments/'+eid+path)[0]==200
                selected=[raws[eid][0]]+[r for r in raws[eid] if r['routes'] is None]
                nonzero=next((r for r in raws[eid] if r['routes'] and r['routes'][0]['vehicle']!=0),None)
                if nonzero:selected.append(nonzero)
                for row in selected:
                    path='/api/experiments/'+eid+'/runs/'+row['run_id']
                    status,_,b=get(path);assert status==200 and json.loads(b)==reader.run(row['run_id'])
                    vid=row['routes'][0]['vehicle'] if row['routes'] else 0
                    status,_,b=get(path+'/vehicles/'+str(vid));assert status==200 and json.loads(b)==reader.vehicle(row['run_id'],vid)
                assert get('/api/experiments/'+eid+'/runs','POST')[0]==405
                for artifact in store.get(eid)['artifacts']:
                    status,headers,blob=get('/api/experiments/'+eid+'/artifacts/'+artifact['id'])
                    assert status==200 and digest(blob)==headers['X-Content-SHA256']==artifact['sha256']
            assert get('/api/route-comparison?experiments='+','.join(readers))[0]==200
            assert get('/api/route-comparison?experiments='+public_id+','+old_receipts[0]['id'])[0]==409
        finally:
            server.shutdown();server.server_close();thread.join()
        report['checks']['http_requests']=request_count
    input_blobs={p.name:p.read_bytes() for p in INPUTS.glob('*.txt')}
    pb=load_package(PUBLIC,PUBLIC_FORMAT);fb=load_package(PORTFOLIO,PORTFOLIO_FORMAT)
    def reject(label,base,fmt,change):
        blobs=copy.deepcopy(base);inputs=copy.deepcopy(input_blobs)
        try:
            change(blobs,inputs)
            normalize_public(blobs,inputs,fmt)
        except StoreError as e:report['mutation_checks'].append({'name':label,'status':'PASS','rejected_with':e.code})
        except Exception as e:
            report['mutation_checks'].append({'name':label,'status':'ERROR','error':repr(e)});failures.append(label+': uncontrolled exception '+repr(e))
        else:
            report['mutation_checks'].append({'name':label,'status':'FAIL','error':'incorrect archive accepted'});failures.append(label+': incorrect archive accepted')
    def semantic_change(blobs,inputs):
        protocol=json.loads(blobs['protocol/protocol.json']);protocol['objective']='vehicles-first lexicographic; Manhattan distance'
        replace_json(blobs,'protocol/protocol.json',protocol,True)
    reject('rewritten_protocol_with_refreeze',pb,PUBLIC_FORMAT,semantic_change)
    def parameter_change(blobs,inputs):
        name='protocol/parameters_250ms.textproto';blobs[name]=blobs[name].replace(b'PARALLEL_CHEAPEST_INSERTION',b'PATH_CHEAPEST_ARC')
        freeze=json.loads(blobs['protocol/freeze.json']);freeze['sha256'][name]=digest(blobs[name]);replace_json(blobs,'protocol/freeze.json',freeze)
    reject('changed_algorithm_parameters_with_refreeze',pb,PUBLIC_FORMAT,parameter_change)
    def encoded_change(blobs,inputs):
        man=json.loads(blobs['protocol/input_manifest.json']);man[0]['encoded_sha256']='0'*64
        replace_json(blobs,'protocol/input_manifest.json',man,True)
    reject('false_encoded_input_hash_with_refreeze',pb,PUBLIC_FORMAT,encoded_change)
    def input_change(blobs,inputs):inputs['c101.txt']+=b'\n'
    reject('changed_original_input_bytes',pb,PUBLIC_FORMAT,input_change)
    def frozen_change(blobs,inputs):blobs['source/checker.py']+=b'\n'
    reject('changed_frozen_checker',pb,PUBLIC_FORMAT,frozen_change)
    def schedule_change(blobs,inputs):
        result=json.loads(blobs['reports/evaluated_results.json']);result[0]['continuous_check']['route_audits'][0]['steps'][0]['arrival']+=1
        replace_json(blobs,'reports/evaluated_results.json',result)
    reject('forged_recorded_continuous_arrival',pb,PUBLIC_FORMAT,schedule_change)
    def modify_raw(blobs,mutator):
        rows=[json.loads(x) for x in blobs['raw/results.jsonl'].splitlines()]
        results=json.loads(blobs['reports/evaluated_results.json']);mutator(rows,results);replace_rows(blobs,rows,results)
    def dup_vehicle(blobs,inputs):
        def f(rows,results):
            rows[0]['routes'][1]['vehicle']=rows[0]['routes'][0]['vehicle'];results[0]['routes']=rows[0]['routes']
        modify_raw(blobs,f)
    reject('duplicate_native_vehicle_id',pb,PUBLIC_FORMAT,dup_vehicle)
    def wrong_vehicle(blobs,inputs):
        def f(rows,results):rows[0]['vehicles_used']+=1;results[0]['vehicles_used']=rows[0]['vehicles_used']
        modify_raw(blobs,f)
    reject('wrong_vehicles_used',pb,PUBLIC_FORMAT,wrong_vehicle)
    def wrong_obj(blobs,inputs):
        def f(rows,results):rows[0]['objective_integer']+=1;results[0]['objective_integer']=rows[0]['objective_integer']
        modify_raw(blobs,f)
    reject('forged_integer_objective',pb,PUBLIC_FORMAT,wrong_obj)
    def false_timeout(blobs,inputs):
        def f(rows,results):
            pos=next(i for i,r in enumerate(rows) if r['routes'] is None)
            rows[pos]['ortools_status']=3;results[pos]['ortools_status']=3
        modify_raw(blobs,f)
    reject('timeout_with_wrong_solver_code',fb,PORTFOLIO_FORMAT,false_timeout)
    def false_timeout_route(blobs,inputs):
        def f(rows,results):
            pos=next(i for i,r in enumerate(rows) if r['routes'] is None)
            rows[pos]['routes']=[];results[pos]['routes']=[]
        modify_raw(blobs,f)
    reject('timeout_with_fake_empty_routes',fb,PORTFOLIO_FORMAT,false_timeout_route)
    def false_geometry(blobs,inputs):
        value=json.loads(blobs['protocol/shared_geometry.json']);value['geometry_sha256'][0]['instances']=[]
        replace_json(blobs,'protocol/shared_geometry.json',value,True)
    reject('false_geometry_groups',fb,PORTFOLIO_FORMAT,false_geometry)
    def negative_time(blobs,inputs):
        def f(rows,results):rows[0]['solve_cpu_s']=-1;results[0]['solve_cpu_s']=-1
        modify_raw(blobs,f)
    reject('negative_recorded_cpu_time',pb,PUBLIC_FORMAT,negative_time)
    def malformed_time(value, nested=False):
        def change(blobs,inputs):
            def f(rows,results):
                if nested:
                    rows[0]['first_solution']['cpu_s']=value
                    results[0]['first_solution']=rows[0]['first_solution']
                else:
                    rows[0]['solve_cpu_s']=value;results[0]['solve_cpu_s']=value
            modify_raw(blobs,f)
        return change
    reject('boolean_recorded_cpu_time',pb,PUBLIC_FORMAT,malformed_time(True))
    reject('string_recorded_cpu_time',pb,PUBLIC_FORMAT,malformed_time('0.25'))
    reject('nonfinite_recorded_cpu_time',pb,PUBLIC_FORMAT,malformed_time(float('nan')))
    reject('negative_first_solution_cpu_time',pb,PUBLIC_FORMAT,malformed_time(-1,nested=True))
    def missing_request(blobs,inputs):
        request=json.loads(blobs['protocol/requests.json']);request.pop()
        replace_json(blobs,'protocol/requests.json',request,True)
    reject('incomplete_request_matrix',pb,PUBLIC_FORMAT,missing_request)
    pyfiles=[p for p in CANDIDATE.rglob('*.py') if '__pycache__' not in p.parts]
    for path in pyfiles:ast.parse(path.read_text(),filename=str(path),feature_version=(3,10))
    report['checks']['python310_static_parse_files']=len(pyfiles)
    report['checks']['ubuntu2204_python310_runtime_verified']=False
    report['checks']['no_solver_imported']=not any(k=='ortools' or k.startswith('ortools.') for k in sys.modules)
    after={str(root):snapshot(root) for root in SOURCE_ROOTS}
    (HERE/'source_hashes_after.json').write_text(json.dumps(after,indent=2)+'\n')
    assert before==after,'source archive bytes changed'
    report['checks']['all_four_source_archives_unchanged']=True
    report['checks']['source_code_unchanged_during_audit']=report['source_code_sha256']==snapshot(CANDIDATE, omit_caches=True)
    report['limits']=['Official upstream byte identity remains unverified.', '56 named instances share four coordinate geometry groups; no independent-geometry or generalization claim.',
                      'Fixed vehicle upper bound and distance-only objective; no official vehicles-first BKS gap.', 'Cumulative served demand is not live onboard load.',
                      'Actual runtime is the recorded cloud Python environment; Ubuntu 22.04/Python 3.10 receives static syntax compatibility only.',
                      'This audit replays archived routes using independent arithmetic, never runs an optimizer or any archived Python source.']
    report['elapsed_wall_s']=time.time()-began
    report['status']='PASS' if not failures else 'FAIL'
    (HERE/'independent_audit_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    summary=['Independent backend audit: '+report['status'],'', 'Coverage: 112 public runs, 224 portfolio runs, 329 legal candidates, seven TIMEOUT records.',
             f'Checked {all_vehicles} native vehicle routes and {all_stops} customer-stop records using independent input parsing and arithmetic.',
             'Old 336 run indices and all route/vehicle API fields match the previous backend exactly.',
             'All four source archives retained their initial file bytes.',f'HTTP requests: {request_count}; mutation tests: {len(report["mutation_checks"])}.',
             '']+['FAIL: '+f for f in failures]+['']+report['limits']
    (HERE/'independent_audit_report.txt').write_text('\n'.join(summary)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in {'source_code_sha256','legacy_baseline'}},ensure_ascii=False,indent=2))
    return int(bool(failures))

if __name__=='__main__':
    raise SystemExit(main())
