#!/usr/bin/env python3
"""Read-only reconstruction of the historical 95-file frontend/core scope.
No source content is copied into the report; only names, lengths and digests.
This is a legacy package check, not frontend integration or current-bundle validation.
"""
import hashlib
import json
import os
from pathlib import Path
import zipfile

BASE = Path('/workspace/shared')
SOURCE = Path(os.environ.get('FRONTEND_BASELINE_ROOT',str(BASE/'research_panel_backend_20261007/bpp-research-console'))).resolve()
PRESERVED = Path(os.environ.get('FRONTEND_PRESERVED_ROOT',str(BASE/'panel_route_backend_20261007/full_source/bpp-research-console'))).resolve()
ARCHIVE = Path(os.environ.get('FRONTEND_ARCHIVE_PATH',str(BASE/'panel_route_backend_20261007/research-panel-route-full-source-20261007.zip'))).resolve()
OUTPUT = Path(os.environ.get('PUBLIC_ROUTE_AUDIT_OUTPUT',str(Path(__file__).resolve().parent))).resolve()
PREFIXES = ['src','core','preview','public/favicon.svg','index.html','package.json','package-lock.json','tsconfig.json','vite.config.ts']

def sha(blob):
    return hashlib.sha256(blob).hexdigest()

def main():
    paths=[]
    for p in SOURCE.rglob('*'):
        if not p.is_file() or '__pycache__' in p.parts or p.suffix=='.pyc':continue
        rel=p.relative_to(SOURCE).as_posix()
        if any(rel==prefix or rel.startswith(prefix+'/') for prefix in PREFIXES):paths.append(rel)
    paths=sorted(set(paths))
    assert len(paths)==95,('Historical scope differs from expected95',len(paths))
    entries=[]
    with zipfile.ZipFile(ARCHIVE) as z:
        for rel in paths:
            original=(SOURCE/rel).read_bytes();preserved=(PRESERVED/rel).read_bytes()
            archived=z.read('bpp-research-console/'+rel)
            assert original==preserved==archived,rel
            entries.append({'path':rel,'bytes':len(original),'source_sha256':sha(original),'preserved_sha256':sha(preserved),'archive_member_sha256':sha(archived)})
    report={'status':'PASS','file_count':len(entries),'scope_prefixes':PREFIXES,
            'historical_scope_definition':str(BASE/'panel_route_backend_20261007/package_delivery.py')+':48-58',
            'source_root':str(SOURCE),'preserved_root':str(PRESERVED),'archive':str(ARCHIVE),
            'archive_sha256':sha(ARCHIVE.read_bytes()),'files':entries,
            'limits':['This verifies the historical frontend/core preserved copy and its historical archive against the original panel bytes.',
                      'The current public-route candidate is a backend-only research_console directory and does not contain these95 frontend/core files.',
                      'This result does not claim frontend integration, browser QA, or inclusion/byte identity in a not-yet-built new full-source bundle.']}
    OUTPUT.mkdir(parents=True,exist_ok=True)
    (OUTPUT/'frontend_core_95_manifest.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='files'},ensure_ascii=False,indent=2))

if __name__=='__main__':
    main()
