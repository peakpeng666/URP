#!/usr/bin/env python3
"""Read-only independent scalar replay audit. Never imports study/solver/model code.
Only own output directory is written. Standard library, hard CPU <=5 s.
"""
import resource
resource.setrlimit(resource.RLIMIT_CPU,(5,5))
import sys
sys.dont_write_bytecode=True
import ast, collections, hashlib, json, math, re, statistics, time, zipfile
from pathlib import Path
from datetime import datetime, timezone
O=Path(__file__).resolve().parent.parent
P=Path('/workspace/shared/frozen_selector_transfer_20261007')
S=Path('/workspace/shared/diverse_geometry_selection_20261007')
T=Path('/workspace/shared/solver_portfolio_headroom_20261007')
I=Path('/workspace/shared/public_vrptw_benchmark_20261007/inputs')
Z=P.with_name(P.name+'_FINAL.zip')
C=['pci250','pca250','sav250']
METHODS=['primary_1nn4','spatial_1nn8']
CONTROLS={'source_training_sbs':'pci250','historical_target_sbs':'sav250'}
F4=['capacity_over_total_demand','demand_population_cv','mean_window_width_over_depot_duration','mean_service_over_depot_duration']
F8=F4+['rms_radius_over_horizon','mean_nn_over_rms_radius','covariance_anisotropy','depot_centroid_over_rms_radius']
def read(p): return json.loads(p.read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def digest(v): return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def write(name,v): (O/name).write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def close(a,b): assert math.isclose(a,b,rel_tol=1e-13,abs_tol=1e-12),(a,b)
def manifest_check(root):
    entries={}
    for line in (root/'SHA256SUMS.txt').read_text().splitlines():
        h,n=line.split('  ',1); assert n not in entries and not Path(n).is_absolute() and '..' not in Path(n).parts
        entries[n]=h; assert sha(root/n)==h,n
    actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}
    assert actual==set(entries)|{'SHA256SUMS.txt'}
    return entries
entries=manifest_check(P)
original_snap={n:sha(P/n) for n in set(entries)|{'SHA256SUMS.txt'}}
assert sha(Z)=='fcf00a6a3205df1a87ebce5925fb945e545b15b0980371dc18a406474b6a6b07'
assert Z.stat().st_size==89398
with zipfile.ZipFile(Z) as z:
    assert len(z.namelist())==len(set(z.namelist()))
    assert set(z.namelist())==set(original_snap)
    assert z.testzip() is None
    for n in z.namelist(): assert z.read(n)==(P/n).read_bytes()
freeze=read(P/'protocol/freeze.json')
for n,h in freeze['files'].items(): assert sha(P/n)==h
for ref in read(P/'protocol/source_references.json'):
    assert sha(Path(ref['original_path']))==sha(P/ref['copied_path'])==ref['sha256']
source_seal=read(S/'evidence/prediction_seal.json')
assert source_seal['model_sha256']==sha(S/'raw/training_models.json')==sha(P/'protocol/training_models.json')
assert source_seal['train_results_sha256']==sha(S/'raw/train_results.jsonl')
assert source_seal['freeze_sha256']==sha(S/'protocol/freeze.json')
source_freeze=read(S/'protocol/freeze.json')
# The source model, feature extractor and tie-rule implementation are pinned.
models=read(P/'protocol/training_models.json'); source_features=read(S/'protocol/features.json')
assert list(models)==METHODS
train=[json.loads(x) for x in (S/'raw/train_results.jsonl').read_text().splitlines()]
tr={(r['instance'],r['config_id']):r for r in train}
split=read(S/'protocol/split.json'); train_names=sorted(split['train'])
assert len(train_names)==80 and len(tr)==len(train)==240
assert set(tr)=={(n,c) for n in train_names for c in C}
coverage={c:sum(tr[n,c]['outcome']=='SUCCESS' for n in train_names) for c in C}
best_cover=[c for c in C if coverage[c]==max(coverage.values())]
oracle={n:min(tr[n,c]['check_summary']['distance'] for c in C if tr[n,c]['outcome']=='SUCCESS') for n in train_names}
common=[n for n in train_names if all(tr[n,c]['outcome']=='SUCCESS' for c in best_cover)]
sbs_scores={c:statistics.mean(tr[n,c]['check_summary']['distance']/oracle[n] for n in common) for c in best_cover}
sbs=min(best_cover,key=lambda c:(sbs_scores[c],C.index(c)))
assert sbs=='pci250'
labels={}
for n in train_names:
    tied=[c for c in C if tr[n,c]['outcome']=='SUCCESS' and tr[n,c]['check_summary']['distance']<=oracle[n]+1e-6]
    labels[n]=min(tied,key=lambda c:(c!=sbs,C.index(c)))
for method,fields in zip(METHODS,[F4,F8]):
    m=models[method]
    assert m['features']==fields and m['train_instances']==train_names and m['labels']==labels and m['sbs']==sbs
    assert m['coverage']==coverage and m['sbs_score_common_instances']==common and m['sbs_scores']==sbs_scores
    assert not m['skipped_unlabelable_training_instances'] and set(m['vectors'])==set(train_names)
    for f in fields:
        vals=[source_features[n][f] for n in train_names]
        assert m['feature_means'][f]==statistics.mean(vals)
        assert m['feature_population_stds'][f]==statistics.pstdev(vals)
        assert m['feature_scales'][f]==(statistics.pstdev(vals) or 1.)
    for n in train_names:
        assert m['vectors'][n]==[(source_features[n][f]-m['feature_means'][f])/m['feature_scales'][f] for f in fields]
# Parse the original text ourselves, and derive the eight scalar features.
manifest=read(P/'protocol/target_input_manifest.json')
assert manifest==read(T/'protocol/input_manifest.json') and len(manifest)==56
features={};metadata={};input_hashes={}
for item in manifest:
    p=I/item['name']; input_hashes[item['name']]=sha(p)
    assert input_hashes[item['name']]==item['sha256']==freeze['target_input_hashes'][item['name']]
    lines=p.read_text().splitlines(); name=lines[0].strip().lower(); vi=lines.index('VEHICLE')
    k,q=map(int,lines[vi+2].split()); rows=[]
    for line in lines:
        tokens=line.split()
        if len(tokens)==7 and all(re.fullmatch(r'-?\d+',v) for v in tokens): rows.append(list(map(int,tokens)))
    assert name==p.stem and len(rows)==101 and [r[0] for r in rows]==list(range(101))
    depot=rows[0];cs=rows[1:];h=depot[5]-depot[4]
    demands=[r[3] for r in cs];cx=statistics.mean(r[1] for r in cs);cy=statistics.mean(r[2] for r in cs)
    vx=statistics.mean((r[1]-cx)**2 for r in cs);vy=statistics.mean((r[2]-cy)**2 for r in cs)
    cov=statistics.mean((r[1]-cx)*(r[2]-cy) for r in cs); trace=vx+vy; radius=math.sqrt(trace)
    nearest=[min(math.hypot(a[1]-b[1],a[2]-b[2]) for b in cs if a[0]!=b[0]) for a in cs]
    vals=[q/sum(demands),statistics.pstdev(demands)/statistics.mean(demands),statistics.mean(r[5]-r[4] for r in cs)/h,statistics.mean(r[6] for r in cs)/h,radius/h,statistics.mean(nearest)/radius if radius else 0.,(trace+math.sqrt((vx-vy)**2+4*cov**2))/(2*trace) if trace else .5,math.hypot(cx-depot[1],cy-depot[2])/radius if radius else 0.]
    features[name]={'instance':name,**dict(zip(F8,vals))}
    geometry=digest({'depot':depot[1:3],'customers':sorted(r[1:3] for r in cs)})
    metadata[name]={'family':re.match(r'(rc|r|c)[12]',name).group(0).upper(),'geometry_sha256':geometry,'vehicle_limit':k,'capacity':q,'horizon':h,'mean_customer_service':statistics.mean(r[6] for r in cs),'min_customer_service':min(r[6] for r in cs),'max_customer_service':max(r[6] for r in cs)}
saved_features=read(P/'raw/target_features.json'); names=sorted(features)
assert len(names)==56 and not set(names)&set(train_names)
max_feature_error=0.
for n in names:
    assert set(features[n])==set(saved_features[n])
    for f in F8:
        close(features[n][f],saved_features[n][f]); max_feature_error=max(max_feature_error,abs(features[n][f]-saved_features[n][f]))
assert metadata==read(P/'raw/target_metadata.json')
preds=read(P/'raw/predictions_sealed.json');assert [r['instance'] for r in preds]==names
pred_by={r['instance']:r['methods'] for r in preds}; new={}; max_distance_error=0.
for n in names:
    new[n]={}
    for method in METHODS:
        m=models[method];x=[(features[n][f]-m['feature_means'][f])/m['feature_scales'][f] for f in m['features']]
        ds={}
        for ident,v in m['vectors'].items():
            acc=0.
            for j in range(len(x)): acc+=(x[j]-v[j])**2
            ds[ident]=acc
        low=min(ds.values()); ties=sorted(ident for ident,d in ds.items() if d<=low+1e-12)
        neighbor=sorted(ties,key=lambda ident:(m['labels'][ident]!=sbs,ident))[0]
        out={'selected_config':m['labels'][neighbor],'neighbor':neighbor,'neighbor_squared_distance':ds[neighbor],'neighbor_tie_count':len(ties),'neighbor_tie_instances':ties}
        for key,v in out.items():
            if key=='neighbor_squared_distance':
                close(v,pred_by[n][method][key]);max_distance_error=max(max_distance_error,abs(v-pred_by[n][method][key]))
            else: assert v==pred_by[n][method][key]
        new[n][method]=out
    for method,c in CONTROLS.items():
        assert pred_by[n][method]=={'selected_config':c};new[n][method]={'selected_config':c}
seal=read(P/'evidence/prediction_seal.json')
for key,path in [('prediction_sha256','raw/predictions_sealed.json'),('features_sha256','raw/target_features.json'),('metadata_sha256','raw/target_metadata.json'),('model_sha256','protocol/training_models.json'),('freeze_sha256','protocol/freeze.json')]: assert seal[key]==sha(P/path)
events=[json.loads(x) for x in (P/'evidence/events.jsonl').read_text().splitlines()]
assert [r['event'] for r in events]==['protocol_frozen','all_predictions_sealed','target_archive_open_started']
assert events[0]['utc']<seal['sealed_utc']<events[1]['utc']<events[2]['utc']
assert events[0]['monotonic_ns']<events[1]['monotonic_ns']<events[2]['monotonic_ns']
assert seal['predictions_n']==56 and seal['target_outcome_rows_consumed_in_this_replay_before_seal']==0
assert seal['target_outcomes_previously_observed_in_research']
code=(P/'source/replay.py').read_text();tree=ast.parse(code)
assert not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='fit' for n in ast.walk(tree))
# Manual path review is supplemented by a static order check; this is not remote attestation.
run=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='run')
segment=ast.get_source_segment(code,run)
assert segment.index("write(P/'raw/predictions_sealed.json'")<segment.index("write(P/'evidence/prediction_seal.json'")<segment.index("event('target_archive_open_started'")<segment.index("raw_bytes = (TARGET/'raw/results.jsonl').read_bytes()")
assert 'os.fsync(f.fileno())' in code
# Only now consume original target costs in this independent audit too.
receipt=read(P/'evidence/target_archive_receipt.json');assert sha(T/'raw/results.jsonl')==receipt['sha256']
archive=[json.loads(x) for x in (T/'raw/results.jsonl').read_text().splitlines()]
assert len(archive)==224
cost={(r['instance'],r['config_id']):r for r in archive if r['config_id'] in C}
assert len(cost)==168 and set(cost)=={(n,c) for n in names for c in C}
strategies=dict(zip(C,['PARALLEL_CHEAPEST_INSERTION','PATH_CHEAPEST_ARC','SAVINGS']))
for r in train+list(cost.values()):
    assert r['strategy']==strategies[r['config_id']] and r['budget_ms']==250 and r['seed']==2026100708
    if r['outcome']=='SUCCESS': assert r['check_summary']['valid'] and r['check_summary']['distance']>0
parameter_shas={}
for c in C:
    assert (S/f'protocol/parameters_{c}.textproto').read_bytes()==(T/f'protocol/parameters_{c}.textproto').read_bytes()
    parameter_shas[c]=sha(T/f'protocol/parameters_{c}.textproto')
assert sha(S/'source/core.py')==sha(T/'source/core.py')
projection=read(P/'raw/archived_costs_projection.json');assert len(projection)==168
for r in projection:
    a=cost[r['instance'],r['config_id']]
    expected={k:a[k] for k in ['instance','config_id','outcome','ortools_status_name','run_id']}
    expected.update(valid=a['outcome']=='SUCCESS',distance=a['check_summary']['distance'] if a['outcome']=='SUCCESS' else None)
    assert r==expected
scored=read(P/'reports/all56_scored.json');assert [r['instance'] for r in scored]==names
for r in scored:
    n=r['instance'];assert {k:v for k,v in r.items() if k not in ['instance','methods']}==metadata[n]
    for method in METHODS+list(CONTROLS):
        expected=new[n][method];a=cost[n,expected['selected_config']];got=r['methods'][method]
        assert got['outcome']==a['outcome'] and got['valid']==(a['outcome']=='SUCCESS')
        assert got['distance']==(a['check_summary']['distance'] if got['valid'] else None)
        for ctrl,c in CONTROLS.items():
            b=cost[n,c];delta=100*(got['distance']/b['check_summary']['distance']-1) if got['valid'] and b['outcome']=='SUCCESS' else None
            assert got['delta_vs_'+ctrl+'_pct']==delta

def aggregate(ids):
    out={'n_all_predictions':len(ids),'methods':{}}
    for method in METHODS+list(CONTROLS):
        selections={n:cost[n,new[n][method]['selected_config']] for n in ids}
        valid=[n for n in ids if selections[n]['outcome']=='SUCCESS']
        row={'selected_config_counts':dict(collections.Counter(new[n][method]['selected_config'] for n in ids)),'valid_count':len(valid),'total_count':len(ids),'valid_rate':len(valid)/len(ids),'outcome_counts':dict(collections.Counter(selections[n]['outcome'] for n in ids)),'failed_instances':[n for n in ids if n not in valid],'comparisons':{}}
        for ctrl,c in CONTROLS.items():
            together=[n for n in valid if cost[n,c]['outcome']=='SUCCESS']
            a=[selections[n]['check_summary']['distance'] for n in together];b=[cost[n,c]['check_summary']['distance'] for n in together]
            rel=[100*(x/y-1) for x,y in zip(a,b)];dif=[x-y for x,y in zip(a,b)]
            row['comparisons'][ctrl]={'common_valid_n':len(together),'all_prediction_n':len(ids),'mean_instance_delta_pct':statistics.mean(rel),'median_instance_delta_pct':statistics.median(rel),'ratio_of_distance_sums_delta_pct':100*(sum(a)/sum(b)-1),'selector_wins':sum(x< -1e-6 for x in dif),'ties':sum(abs(x)<=1e-6 for x in dif),'control_wins':sum(x>1e-6 for x in dif),'selector_fail_control_success':sum(selections[n]['outcome']!='SUCCESS' and cost[n,c]['outcome']=='SUCCESS' for n in ids)}
        out['methods'][method]=row
    return out
summary=aggregate(names);groups=[]
for geom in sorted({r['geometry_sha256'] for r in metadata.values()}):
    ids=[n for n in names if metadata[n]['geometry_sha256']==geom]
    groups.append({'geometry_sha256':geom,'families':sorted({metadata[n]['family'] for n in ids}),'instances':ids,**aggregate(ids)})
assert len(groups)==4 and groups==read(P/'reports/all4_geometries.json')
summary['geometry_count']=len(groups)
summary['geometry_equal_weight_mean_conditional_delta_pct']={m:{b:{'usable_geometry_n':len(groups),'mean_pct':statistics.mean(g['methods'][m]['comparisons'][b]['mean_instance_delta_pct'] for g in groups)} for b in CONTROLS} for m in METHODS}
assert summary==read(P/'reports/summary.json')
shift=read(P/'reports/input_distribution_shift.json');outside={}
for n in names:
    outside[n]=[f for f in F8 if not min(source_features[t][f] for t in train_names)<=features[n][f]<=max(source_features[t][f] for t in train_names)]
assert outside==shift['outside_features_by_instance']
assert len(outside)==56 and min(map(len,outside.values()))>=2
assert {str(k):v for k,v in collections.Counter(map(len,outside.values())).items()}==shift['outside_feature_count_histogram']
for f in F8:
    expected={'min':min(source_features[t][f] for t in train_names),'max':max(source_features[t][f] for t in train_names),'target_min':min(features[n][f] for n in names),'target_max':max(features[n][f] for n in names),'target_outside_train_range_count':sum(f in outside[n] for n in names),'denominator':56}
    for key,v in expected.items(): close(v,shift['features'][f][key])
# No modifications to original inputs, source model or audited replay directory.
assert all(sha(P/n)==h for n,h in original_snap.items())
assert all(sha(I/n)==h for n,h in input_hashes.items())
assert sha(S/'raw/training_models.json')==source_seal['model_sha256']
def shell_cpu(p):
    d=dict(line.split('=',1) for line in p.read_text().splitlines() if line.startswith(('user_s=','sys_s=')))
    return float(d['user_s'])+float(d['sys_s'])
author_cpu=sum(shell_cpu(P/'evidence'/f) for f in ['run_shell_time.txt','verify_shell_time.txt','audit_attempt01_shell_time.txt','audit_attempt02_shell_time.txt'])+shell_cpu(P.with_name(P.name+'_FINAL_shell_time.txt'))
close(author_cpu,.533)
write('summary_recomputed.json',summary)
result={'audit_utc':datetime.now(timezone.utc).isoformat(),'verdict':'PASS_WITH_SCOPE_LIMITATIONS','independent_of_author_code':True,'source_zip':{'sha256':sha(Z),'bytes':Z.stat().st_size,'file_count_dynamic':len(original_snap),'dynamic_manifest_all_members_and_crc_verified':True},'checks':{'frozen_source_model_features_scaler_vectors_labels_sbs_ties_unchanged':True,'source80_training_labels_and_scaler_independently_rederived':True,'target56_original_input_sha_verified':True,'target448_features_independently_recomputed':True,'target112_predictions_and_neighbor_ties_recomputed':True,'preseal_code_log_hash_order_consistent':True,'no_target_rows_in_source_training_or_replay_fit':True,'three_short_configs_and250ms_parameter_bytes_match':True,'all168_costs_match_original_archive':True,'all56_success_denominators_conditional_statistics_and4_geometry_tables_recomputed':True,'all56_have_at_least2_out_of_source_train_range_features':True,'source_and_target_inputs_unchanged':True},'max_abs_feature_roundoff':max_feature_error,'max_abs_neighbor_squared_distance_roundoff':max_distance_error,'parameter_sha256':parameter_shas,'source_model_sha256':source_seal['model_sha256'],'seal_utc':seal['sealed_utc'],'target_archive_open_event_utc':events[2]['utc'],'target_archive_sha256':receipt['sha256'],'out_of_range_count_histogram':shift['outside_feature_count_histogram'],'author_completed_process_cpu_s':author_cpu,'author_audit_tool_retries':2,'audit_solver_calls':0,'audit_model_api_calls':0,'audit_installs':0,'audit_route_revalidations':0,'audit_process_cpu_s_through_scientific_checks':time.process_time(),'limitations':['Previously observed target archive, exploratory cross-source replay only, not fresh external blind test.','56 rows share4 coordinate-set geometries, not56 independent samples.','Conditional distance gains cannot offset failures or establish overall dominance.','Source-trained parameter provenance is verified; prior researcher knowledge of target outcomes is explicitly acknowledged.','Sealing order supported by code, hashes and self-recorded dual-clock logs; not external tamper-proof time attestation.','Prior archived route validation is relied upon; this audit does not repeat217 route checks.','250ms is a historical wall-clock search cap, not current compute or equal total CPU.','Feature range shift is explanatory, not a gate or a demonstrated causal failure mechanism.']}
write('audit.json',result)
text='''固定选择器跨来源回放：独立短审计\n\n结论：在声明的探索性回放范围内通过，未发现影响结果的算术、选择或档案映射差异。\n\n1. 独立从56份原始输入重新解析与计算448个特征值；不用作者的特征、预测或汇总函数。冻结模型、4/8特征顺序、源80例均值/总体标准差、标签、近邻向量、SBS与两类tie规则均核对。源模型SHA 52328f15e700562453095399fa10a4dd895af7ed70c89672c22f1b2d08d44ef2 未变。112次选择与近邻tie集合一致。\n2. 三个250ms候选配置、策略/seed与原档对应；源目标参数快照及求解核心字节相同。排除PCI750。读原档168条短预算结果，只复算标量，不再求解、不调用模型、不安装、不重验既有217条路线。\n3. 56预测于2026-10-07 08:02:05.500395Z封存；目标成本打开事件为08:02:05.500679Z。代码先写并fsync预测、seal及事件，后读取目标成本；日志顺序与哈希相符。此为存档一致性核查，不是独立外部不可篡改时间认证。\n\n核心结果（所有失败保留，成功率分母均56）：\n- 8特征：55/56成功，PCI与SAV均56/56；r101选择PCA超时。共同合法55例对PCI平均相对差-1.769989%，对SAV -0.736012%。\n- 4特征：50/56成功；r102、r103、r105、r106、rc101、rc105失败。共同合法50例对PCI -1.440965%，对SAV -0.363066%。\n- 上述质量数字是平均100×(选择器/控制-1)，负值较好；不能丢掉失败而宣称全样本胜出。全部统计、中位数、距离和比率、胜平负及4几何分层均独立重算一致。\n\n解释边界：\n- 目标旧结果早已观察；源协议也承认历史知识。固定模型的直接参数可仅由源训练80例重推，未在回放中用目标标签训练或调参，但这不等于研究者从未知道目标表现。只能称探索性跨来源回放，不能称全新外部盲测。\n- 56条只有4个坐标几何，不能当56个独立几何；不推导显著性或外部泛化。\n- 56例均至少2特征超源训练范围；仅用于描述，未据此拒绝样本或改预测，也不证明失败原因。\n- 250ms为既有求解的单配置wall搜索上限，非新实验CPU或全部开销；单位保留原抽象单位，不是官方Solomon BKS gap。\n\n完整性与资源：\n原FINAL.zip 89398字节，SHA fcf00a6a3205df1a87ebce5925fb945e545b15b0980371dc18a406474b6a6b07；按实际manifest检查全部成员、哈希和CRC，没有硬编码包文件数。源目录、模型与输入只读保持不变。\n作者两次失败仅为独立审计浮点等值断言、资源收据解析故障，记录仍在；修正未改变封存模型/预测/成本，不应称模型重跑。其全部完成实验进程CPU合计0.533秒。\n本次独审硬限5 CPU秒，详见audit.json与shell_time.txt；源码编写和只读查阅不计实验进程CPU。仅在本审计目录写最小源码、标量审计结果和中文报告；无私有原始坐标、路线、密钥或凭证。\n复算：python3 -B source/audit.py（需上述本地原始存档路径；只写本审计目录）。\n'''
(O/'report_zh.txt').write_text(text)
print(json.dumps({'verdict':result['verdict'],'max_abs_feature_roundoff':max_feature_error,'max_abs_neighbor_distance_roundoff':max_distance_error,'audit_cpu_s':time.process_time(),'author_cpu_s':author_cpu,'file_count_dynamic':len(original_snap)},ensure_ascii=False))
