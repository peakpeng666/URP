#!/usr/bin/env python3
"""Dynamic manifest and clean ZIP packaging, writes only own artifact paths."""
import resource
resource.setrlimit(resource.RLIMIT_CPU,(5,5))
import hashlib,json,time,zipfile
from pathlib import Path
P=Path(__file__).resolve().parent.parent
S=Path('/workspace/shared/diverse_geometry_selection_20261007')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
frozen=json.loads((S/'protocol/freeze.json').read_text())['sha256']
source_files=['source/selector.py','source/generator.py','source/core.py','protocol/features.json','protocol/protocol.json','protocol/split.json']
for name in source_files: assert sha(S/name)==frozen[name]
write(P/'additional_source_freeze_check.json',{'all_relevant_source_features_rules_and_split_match_original_prefit_freeze':True,'file_sha256':{name:sha(S/name) for name in source_files},'source_prefit_freeze_sha256':sha(S/'protocol/freeze.json')})
d=dict(line.split('=',1) for line in (P/'shell_time.txt').read_text().splitlines() if line.startswith(('user_s=','sys_s=')))
prior=float(d['user_s'])+float(d['sys_s']);assert prior+time.process_time()<5
files=sorted(p for p in P.rglob('*') if p.is_file() and p.name!='SHA256SUMS.txt')
for p in files:
    assert p.suffix in {'.py','.json','.txt','.log'},p
    assert not any(x in p.parts for x in ['__pycache__','.venv','.git','inputs'])
    if p.suffix=='.json':
        def check(v):
            if isinstance(v,dict):
                for key,val in v.items():
                    assert key not in {'routes','nodes','credentials','password','access_token','api_key'}
                    check(val)
            elif isinstance(v,list):
                for val in v:check(val)
        check(json.loads(p.read_text()))
(P/'SHA256SUMS.txt').write_text(''.join(f'{sha(p)}  {p.relative_to(P)}\n' for p in files))
files.append(P/'SHA256SUMS.txt');expected={str(p.relative_to(P)):p for p in files}
assert set(expected)=={str(p.relative_to(P)) for p in P.rglob('*') if p.is_file()}
zpath=P.with_name(P.name+'_FINAL.zip');assert not zpath.exists()
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,p in sorted(expected.items()):z.write(p,name)
with zipfile.ZipFile(zpath) as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))
    assert set(z.namelist())==set(expected)
    for name,p in expected.items():assert z.read(name)==p.read_bytes()
receipt={'zip_path':str(zpath),'bytes':zpath.stat().st_size,'sha256':sha(zpath),'dynamic_file_count':len(expected),'dynamic_manifest_exact_member_bytes_and_crc_pass':True,'clean_package_pass':True,'audit_complete_shell_cpu_s':prior,'package_process_cpu_s_before_receipt':time.process_time(),'external_package_shell_timing_path':str(P.with_name(P.name+'_FINAL_shell_time.txt')),'solver_calls':0,'model_api_calls':0,'installations':0,'routes_revalidated':0,'original_inputs_and_results_unchanged':True}
write(P.with_name(P.name+'_FINAL_receipt.json'),receipt)
print(json.dumps(receipt,ensure_ascii=False))
