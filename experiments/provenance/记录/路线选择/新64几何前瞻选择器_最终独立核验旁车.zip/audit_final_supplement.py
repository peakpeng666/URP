"""Narrow postrun audit: existing-control arithmetic and fixed final ZIP only.
No route replay, feature extraction, fitting or solver work is repeated.
"""
import resource
resource.setrlimit(resource.RLIMIT_CPU,(2,2))
import sys,json,time,math,random,hashlib,zipfile,re
from pathlib import Path
from datetime import datetime,timezone
T=time.perf_counter();O=Path(__file__).resolve().parent;P=Path('/workspace/shared/diverse_geometry_selection_20261007')
def read(p):return json.loads(p.read_text())
def write(n,v):(O/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def avg(v):return math.fsum(v)/len(v) if v else None
def near(a,b):return (a is b) if a is None or b is None else abs(a-b)<1e-8*max(1,abs(a),abs(b))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
rows=read(O/'test48_recomputed.json');report=read(P/'reports/summary_with_both_controls.json')
def compare(rs,m,b):
    co=[r for r in rs if r[m]['valid'] and r[b]['valid']];a=sum(r[m]['distance'] for r in co);s=sum(r[b]['distance'] for r in co)
    return {'method':m,'baseline':b,'n_all':len(rs),'method_successes':sum(r[m]['valid'] for r in rs),'baseline_successes':sum(r[b]['valid'] for r in rs),'common_success_n':len(co),'method_only_success':sum(r[m]['valid'] and not r[b]['valid'] for r in rs),'baseline_only_success':sum(not r[m]['valid'] and r[b]['valid'] for r in rs),'both_failed':sum(not r[m]['valid'] and not r[b]['valid'] for r in rs),'wins':sum(r[m]['distance']<r[b]['distance']-1e-6 for r in co),'ties':sum(abs(r[m]['distance']-r[b]['distance'])<=1e-6 for r in co),'losses':sum(r[m]['distance']>r[b]['distance']+1e-6 for r in co),'mean_relative_method_vs_baseline_pct':avg([100*(r[m]['distance']/r[b]['distance']-1) for r in co]),'sum_distance_reduction_vs_baseline_pct':100*(1-a/s) if s else None,'method_common_distance_sum':a,'baseline_common_distance_sum':s}
rng=random.Random(202610071902);ix=[[rng.randrange(24) for _ in range(24)] for _ in range(5000)]
comparisons=[]
for m in ['primary_1nn4','spatial_1nn8']:
    for b in ['training_sbs','fixed_sav250']:
        c=compare(rows,m,b);gs=[compare([r for r in rows if r['geometry_id']==g],m,b) for g in sorted({r['geometry_id'] for r in rows})]
        q=[g['mean_relative_method_vs_baseline_pct'] for g in gs];cov=[100*(g['method_successes']-g['baseline_successes'])/2 for g in gs]
        qs=sorted(avg([q[i] for i in r if q[i] is not None]) for r in ix);cs=sorted(avg([cov[i] for i in r]) for r in ix)
        boot={'geometry_units':24,'usable_common_success_geometry_units':sum(v is not None for v in q),'equal_geometry_mean_relative_pct':avg([v for v in q if v is not None]),'conditional_quality_percentile95_pct':[qs[124],qs[4874]],'mean_coverage_difference_percentage_points':avg(cov),'coverage_difference_percentile95_percentage_points':[cs[124],cs[4874]],'replicates':5000,'seed':202610071902}
        old=next(s for s in report['direct_two_control_comparisons'] if s['method']==m and s['baseline']==b)
        assert all(near(v,old[k]) if isinstance(v,(float,int)) else v==old[k] for k,v in c.items())
        for k,v in boot.items():
            expected=old['geometry_bootstrap'][k];assert all(near(a,b) for a,b in zip(v,expected)) if isinstance(v,list) else near(v,expected)
        c['geometry_bootstrap']=boot;comparisons.append(c)
write('both_controls_independent.json',comparisons)

archive=Path(sys.argv[1]);expected_hash=sys.argv[2];actual=sha(archive);assert actual==expected_hash
with zipfile.ZipFile(archive) as z:
    names=z.namelist();assert len(names)==len(set(names)) and z.testzip() is None
    assert all(not n.startswith('/') and '..' not in Path(n).parts and not re.search(r'(^|/)(\.venv|__pycache__|\.git|\.env)(/|$)|\.(key|pem|pyc)$|credential|secret',n,re.I) for n in names)
    manifests=[n for n in names if Path(n).name.startswith('SHA256SUMS') and n.endswith('.txt')]
    manifest_candidates=[]
    for name in manifests:
        entries=dict((n,h) for h,n in (s.split('  ',1) for s in z.read(name).decode().splitlines()))
        if set(entries)==set(names)-{name}:manifest_candidates.append((name,entries))
    assert len(manifest_candidates)==1,manifest_candidates
    manifest_name,hs=manifest_candidates[0]
    assert all(hashlib.sha256(z.read(n)).hexdigest()==h for n,h in hs.items())
    assert all(n in {'README_zh.txt','README_DELIVERY_zh.txt','SHA256SUMS.txt','SHA256SUMS_FINAL.txt'} or n.split('/')[0] in {'inputs','source','protocol','evidence','raw','reports','audit'} for n in names)
    with zipfile.ZipFile(P.parent/(P.name+'.zip')) as original:
        assert all(n in names and original.read(n)==z.read(n) for n in original.namelist())
    freeze=read(P/'protocol/freeze.json')
    assert all(n in names and hashlib.sha256(z.read(n)).hexdigest()==h for n,h in freeze['sha256'].items() if n!='evidence/shell_time.txt')
    seal=read(P/'evidence/prediction_seal.json')
    assert hashlib.sha256(z.read('raw/training_models.json')).hexdigest()==seal['model_sha256'] and hashlib.sha256(z.read('raw/test_predictions_sealed.json')).hexdigest()==seal['prediction_sha256']
    assert z.read('evidence/final_shell_time.txt')==(P/'evidence/shell_time.txt').read_bytes()
    err=json.loads(z.read('evidence/archive_erratum.json'));assert err['frozen_entry']=='evidence/shell_time.txt' and err['final_sha256']==hashlib.sha256(z.read('evidence/final_shell_time.txt')).hexdigest()
    assert all(z.read(n)==(P/n).read_bytes() for n in ['reports/summary_with_both_controls.json','reports/report_with_both_controls_zh.txt','source/present_existing_controls.py','evidence/archive_erratum.json','evidence/final_shell_time.txt','evidence/original_package_receipt.json'])
pack={'archive':archive.name,'sha256':actual,'bytes':archive.stat().st_size,'member_count':len(names),'manifest_name':manifest_name,'manifest_entries':len(hs),'passed':True,'all_member_hashes_crc_and_dynamic_whitelist_checked':True,'all_scientific_freeze_hashes_and_sealed_model_predictions_preserved':True,'runtime_receipt_exception_disclosed':True}
final_receipt=read(P.parent/(P.name+'_FINAL_package_receipt.json'))
assert final_receipt['sha256']==actual and final_receipt['bytes']==pack['bytes'] and final_receipt['file_count']==len(names)
assert final_receipt['unmetered_additional_readonly_audit_disclosed'] is True
write('final_archive_audit.json',pack)
with (O/'report_zh.txt').open('a') as f:
    f.write('\n\n最终主对照核验：训练SBS=PCI250（仅本轮80训练问题选择）\n')
    for c in comparisons:
        if c['baseline']=='training_sbs':
            f.write(f"{c['method']}：成功{c['method_successes']}/48 对训练SBS{c['baseline_successes']}/48；共同成功{c['common_success_n']}；平均相对距离差{c['mean_relative_method_vs_baseline_pct']:.9f}%；总距离降低{c['sum_distance_reduction_vs_baseline_pct']:.9f}%；胜平负{c['wins']}/{c['ties']}/{c['losses']}；24几何描述性区间{c['geometry_bootstrap']['conditional_quality_percentile95_pct']}。\n")
    f.write('空间方法本次全48均成功且观察到更短平均路程，为这一特定合成分布/单次短预算下的积极描述结果；不宣称真实农业泛化、全局最优或已部署。\n')
    f.write(f'最终交付ZIP：{archive.name}\nSHA256：{actual}\n动态白名单/CRC/全部内部hash核验通过，共{len(names)}成员；双对照补表算术独立吻合。科学冻结内容不变，运行回执例外已勘误并补件。\n')
    f.write('计量限制补充：作者另有一位审计员确认其审计脚本未单独计CPU，不能追认零，也不能把工具wall当CPU。主实验101.860秒和本独审有实测，作者补表/打包另列；因此不能宣称所有审计在内的精确累计CPU或完整全链180秒硬上限证据。先前本报告的合计仅指作者主进程加本独审，未包含该未计量部分。\n')
receipt={'finished_utc':datetime.now(timezone.utc).isoformat(),'supplement_cpu_s':time.process_time(),'supplement_wall_s':time.perf_counter()-T,'main_audit_shell_cpu_s':.662,'total_own_audit_cpu_s_before_teardown':.662+time.process_time(),'other_author_side_audit_cpu_s':None,'all_chain_exact_total_cpu_claim_supported':False,'scope':'Only comparison arithmetic, documented bootstrap and final archive; no route replay or experimental rerun. Author-side other auditor reports its CPU was not separately metered; do not treat it as zero.'}
write('final_supplement_receipt.json',receipt)
print(json.dumps({'status':'PASS','archive':pack,'comparisons':comparisons,'resource':receipt},ensure_ascii=False))
