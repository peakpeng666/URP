"""Independent, read-only stdlib audit; no author modules and no solver imported.
Run once against fixed author artefacts. CPU hard limit 5s includes all checks.
"""
import resource
resource.setrlimit(resource.RLIMIT_CPU, (5, 5))
import time, json, hashlib, math, statistics, random, re, collections, zipfile, csv
from pathlib import Path
from decimal import Decimal, localcontext, ROUND_HALF_UP
from datetime import datetime, timezone

START = time.perf_counter()
ROOT = Path('/workspace/shared/diverse_geometry_selection_20261007')
OUT = Path(__file__).resolve().parent
CONFIGS = ['pci250', 'pca250', 'sav250']
METHODS = ['primary_1nn4', 'spatial_1nn8', 'fixed_sav250', 'training_sbs']
FAMILIES = ['uniform', 'clustered', 'jitter_grid', 'elongated']
FEATURES = ['capacity_over_total_demand','demand_population_cv','mean_window_width_over_depot_duration','mean_service_over_depot_duration','rms_radius_over_horizon','mean_nn_over_rms_radius','covariance_anisotropy','depot_centroid_over_rms_radius']
failures = []
checks = []
def ck(ok, label, details=None):
    checks.append({'check': label, 'passed': bool(ok), 'details': details})
    if not ok: failures.append(label)
def j(name): return json.loads((ROOT/name).read_text())
def jl(name): return [json.loads(s) for s in (ROOT/name).read_text().splitlines()]
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def digest(v): return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def mean(v): return math.fsum(v)/len(v) if v else None
def close(a,b,tol=1e-8):
    if a is None or b is None: return a is b
    return abs(a-b) <= tol*max(1,abs(a),abs(b))
def write(name,value): (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')

freeze=j('protocol/freeze.json'); protocol=j('protocol/protocol.json')
manifest=j('protocol/input_manifest.json'); geom=j('protocol/geometries.json')
split=j('protocol/split.json'); requests=j('protocol/requests.json')
data=j('inputs/instances.json'); sealed=j('raw/test_predictions_sealed.json')
models=j('raw/training_models.json'); seal=j('evidence/prediction_seal.json')
events=jl('raw/events.jsonl'); train=jl('raw/train_results.jsonl'); test=jl('raw/test_results.jsonl'); results=train+test
summary=j('reports/summary.json'); features_record=j('protocol/features.json')
receipts=j('evidence/resource_accounting.json')
package=json.loads((ROOT.parent/(ROOT.name+'_package_receipt.json')).read_text())

# Freeze verification: a shell time receipt is naturally changed after process exit.
changed=[name for name,h in freeze['sha256'].items() if not (ROOT/name).is_file() or sha(ROOT/name)!=h]
substantive_changes=[n for n in changed if n!='evidence/shell_time.txt']
ck(not substantive_changes,'Substantive frozen files unchanged',substantive_changes)
ck(changed==['evidence/shell_time.txt'] or not changed,'Only expected shell completion receipt differs',changed)
ck(all(sha(ROOT/p)==seal[k] for p,k in [('raw/test_predictions_sealed.json','prediction_sha256'),('raw/training_models.json','model_sha256'),('raw/train_results.jsonl','train_results_sha256'),('protocol/freeze.json','freeze_sha256')]),'Prediction, model, training archive and freeze hashes match seal')

# Fresh parse original seven-integer-column text, independent of author parser.
parsed={}
for row in manifest:
    name=row['instance']; path=ROOT/'inputs'/(name+'.txt'); lines=path.read_text().splitlines()
    nums=[list(map(int,x.split())) for x in lines if re.fullmatch(r'\s*-?\d+(?:\s+-?\d+){6}\s*',x)]
    assert len(nums)==101 and [r[0] for r in nums]==list(range(101))
    vi=lines.index('VEHICLE'); fleet,capacity=map(int,lines[vi+2].split())
    parsed[name]={'nodes':{r[0]:r[1:] for r in nums},'fleet':fleet,'capacity':capacity,'meta':row}
    assert path.stem==lines[0] and sha(path)==row['input_sha256']
    assert fleet==10 and capacity==100 and nums[0][1:]==[50,50,0,0,2000,0]
    assert all(r[6]==2 and r[5]-r[4]==row['window_width'] and 1<=r[3]<=10 for r in nums[1:])
ck(len(parsed)==128 and len(set(parsed))==128,'128 original inputs and fixed semantics verified')
data_by={d['id']:d for d in data}
ck(all([[n[k] for k in ['x','y','demand','ready','due','service']] for n in data_by[name]['nodes']]==list(d['nodes'].values()) for name,d in parsed.items()),'JSON inputs equal original text')
geohashes={}
for g in geom:
    ds=[v for v in parsed.values() if v['meta']['geometry_id']==g['geometry_id']]
    assert len(ds)==2
    hashes=[digest({'depot':v['nodes'][0][:2], 'customers':sorted([n[:2] for i,n in v['nodes'].items() if i])}) for v in ds]
    assert hashes[0]==hashes[1]==g['geometry_sha256']
    assert {v['meta']['split'] for v in ds}=={g['split']}
    assert {v['meta']['window_width'] for v in ds}=={60,180}
    assert [n[:3] for n in ds[0]['nodes'].values()]==[n[:3] for n in ds[1]['nodes'].values()]
    geohashes[g['geometry_id']]=hashes[0]
ck(len(geohashes)==len(set(geohashes.values()))==64,'64 coordinate-multiset hashes unique; widths paired within split')
counts={f:{s:sum(g['family']==f and g['split']==s for g in geom) for s in ['train','test']} for f in FAMILIES}
ck(all(v=={'train':10,'test':6} for v in counts.values()),'Four families each 10 train / 6 test geometries',counts)
ck(len(split['train'])==80 and len(split['test'])==48 and not set(split['train'])&set(split['test']) and set(split['train']+split['test'])==set(parsed),'80/48 problem split and complete coverage')
ck(all(d['meta']['split']==part for part in split for n in split[part] for d in [parsed[n]]),'Split list agrees with instance metadata')
# Independently repeat the documented seeded generation of coordinates/demand/split.
srng=random.Random(202610071901); expected_test={f:set(srng.sample(range(16),6)) for f in FAMILIES}
for gi,g in enumerate(geom):
    f=FAMILIES[gi//16]; rng=random.Random(202610071900+1009*gi)
    if f=='uniform': xy=[(rng.randrange(101),rng.randrange(101)) for _ in range(100)]
    elif f=='clustered':
        centers=[(rng.uniform(12,88),rng.uniform(12,88)) for _ in range(4)]
        xy=[tuple(max(0,min(100,round(v+rng.gauss(0,6)))) for v in centers[i%4]) for i in range(100)];rng.shuffle(xy)
    elif f=='jitter_grid':
        xy=[(round(5+10*x+rng.uniform(-3,3)),round(5+10*y+rng.uniform(-3,3))) for x in range(10) for y in range(10)];rng.shuffle(xy)
    else: xy=[(rng.randrange(-100,201),rng.randrange(40,61)) for _ in range(100)]
    demands=[rng.randint(1,10) for _ in range(100)]
    ds=parsed[f'g{gi:03d}_w060']['nodes']
    assert [ds[n][:3] for n in range(1,101)]==[[*xy[n],demands[n]] for n in range(100)]
    assert g['family']==f and g['seed']==202610071900+1009*gi and g['split']==('test' if gi%16 in expected_test[f] else 'train')
ck(True,'All 64 documented independent seeded coordinate/demand draws and family-stratified split reproduce')

# Chronology and exact request ledger, with failures retained.
starts=[e for e in events if e['event']=='request_started']; ends=[e for e in events if e['event']=='request_finished']; pe=[e for e in events if e['event']=='predictions_sealed']; fe=events[0]
ck([e['event_sequence'] for e in events]==list(range(len(events))) and all(a['monotonic_ns']<b['monotonic_ns'] and a['utc']<=b['utc'] for a,b in zip(events,events[1:])),'Event sequence and both clocks ordered')
first_test=next(e for e in starts if e['phase']=='test')
ck(len(pe)==1 and fe['event']=='protocol_frozen' and fe['freeze_sha256']==sha(ROOT/'protocol/freeze.json') and freeze['frozen_utc']<starts[0]['utc'],'Freeze before first request')
ck(len(train)==240 and len(test)==144 and len(starts)==len(ends)==len(results)==384 and len({r['run_id'] for r in results})==384,'Exactly 384 unique results / starts / finishes, 240 train and 144 test')
ck([r['run_id'] for r in results]==[r['run_id'] for r in requests]==[e['run_id'] for e in starts]==[e['run_id'] for e in ends],'Frozen request order and identifiers match all logs')
ck(all(all(r[k]==q[k] for k in q) for r,q in zip(results,requests)),'Every returned request retains all frozen request fields')
ck(sum(e['phase']=='train' and e['monotonic_ns']<pe[0]['monotonic_ns'] for e in ends)==240 and not any(e['phase']=='test' and e['monotonic_ns']<pe[0]['monotonic_ns'] for e in starts) and pe[0]['monotonic_ns']<first_test['monotonic_ns'] and seal['sealed_utc']<first_test['utc'],'All 240 training calls completed; predictions/models sealed before all 144 test requests')
ck({(r['instance'],r['config_id']) for r in results}=={(n,c) for n in parsed for c in CONFIGS},'Complete 128 by 3 denominator; no omitted or duplicate run')
partexts=[(ROOT/f'protocol/parameters_{c}.textproto').read_text() for c in CONFIGS]
ck(len({p.split('\n',1)[1] for p in partexts})==1 and all('nanos: 250000000' in p and 'local_search_metaheuristic: GUIDED_LOCAL_SEARCH' in p for p in partexts),'Three frozen configurations only differ in first solution strategy; 250 ms GLS')

# Entire returned route corpus and all known-feasible witnesses replayed from text.
sqrtcache={}
def route_replay(name,routes,objective=None):
    ds=parsed[name]; nodes=ds['nodes']; visits=[]; total=0.; integer=0; arcs=0; margin=math.inf; maxreturn=0.; maxload=0
    assert isinstance(routes,list) and len(routes)<=ds['fleet']
    for entry in routes:
        route=entry['nodes'] if isinstance(entry,dict) else entry
        assert isinstance(route,list) and len(route)>=3 and route[0]==route[-1]==0 and 0 not in route[1:-1]
        assert all(type(n)==int and n in nodes for n in route)
        visits+=route[1:-1]; load=sum(nodes[n][2] for n in route[1:-1]);assert load<=ds['capacity'];maxload=max(maxload,load)
        now=nodes[0][3]; ret=0.
        for a,b in zip(route,route[1:]):
            x,y=nodes[a],nodes[b]; sq=(x[0]-y[0])**2+(x[1]-y[1])**2
            dist=math.sqrt(sq);total+=dist;arcs+=1
            now=max(now+x[5]+dist,y[3]);margin=min(margin,y[4]-now);assert now<=y[4]+1e-9
            if objective is not None:
                if sq not in sqrtcache:
                    with localcontext() as ctx:
                        ctx.prec=50;sqrtcache[sq]=int((Decimal(sq).sqrt()*1_000_000).to_integral_value(rounding=ROUND_HALF_UP))
                integer+=sqrtcache[sq]
        maxreturn=max(maxreturn,now)
    assert sorted(visits)==list(range(1,101))
    assert objective is None or integer==objective
    assert objective is None or abs(integer/1_000_000-total)<=arcs*.5/1_000_000+1e-9
    return {'valid':True,'distance':total,'vehicles':len(routes),'arcs':arcs,'integer_objective':integer if objective is not None else None,'minimum_window_margin':margin,'maximum_return_time':maxreturn,'maximum_load':maxload}

replay={}; witness=[]
for name in parsed:
    v=route_replay(name,data_by[name]['witness_routes']);witness.append({'instance':name,**v})
for r in results:
    if r['assignment_returned']:
        v=route_replay(r['instance'],r['routes'],r['objective_integer']);replay[r['run_id']]=v
        assert r['outcome']=='SUCCESS' and close(v['distance'],r['check_summary']['distance'],1e-12)
    else:
        assert not r['routes'] and r['outcome']!='SUCCESS'
ck(len(replay)==372,'All 372 returned assignments independently continuous-replayed with coverage, fleet, capacity, service start, service duration, depot return and Decimal objective')
ck(len(witness)==128,'All 128 feasible witnesses independently replayed')
ck(len(results)-len(replay)==12 and len(j('reports/all_failures.json'))==12,'All 12 failed requests retained; no inferred infeasibility',dict(collections.Counter(r['outcome'] for r in results)))
write('route_replay.json',replay);write('witness_replay.json',witness)

# Features and all fitted parameters independently reconstructed from original text.
features={}
for name,ds in parsed.items():
    ns=list(ds['nodes'].values())[1:];demand=[n[2] for n in ns];cx=mean([n[0] for n in ns]);cy=mean([n[1] for n in ns]);h=2000
    xx=mean([(n[0]-cx)**2 for n in ns]);yy=mean([(n[1]-cy)**2 for n in ns]);xy=mean([(n[0]-cx)*(n[1]-cy) for n in ns]);trace=xx+yy;rms=math.sqrt(trace)
    nn=mean([min(math.hypot(a[0]-b[0],a[1]-b[1]) for bi,b in enumerate(ns) if ai!=bi) for ai,a in enumerate(ns)])
    vec=[100/sum(demand),statistics.pstdev(demand)/mean(demand),mean([n[4]-n[3] for n in ns])/h,mean([n[5] for n in ns])/h,rms/h,nn/rms if rms else 0.,(trace+math.sqrt((xx-yy)**2+4*xy*xy))/(2*trace) if trace else .5,math.hypot(cx-50,cy-50)/rms if rms else 0.]
    features[name]=dict(zip(FEATURES,vec));assert all(close(v,features_record[name][f],1e-12) for f,v in features[name].items())
ck(True,'All eight features independently recomputed for 128 inputs; no identity or outcomes as features')
trainby={(r['instance'],r['config_id']):r for r in train};testby={(r['instance'],r['config_id']):r for r in test}
def valid(r):return r['run_id'] in replay
def distance(r):return replay[r['run_id']]['distance'] if valid(r) else None
names=sorted(split['train']);cov={c:sum(valid(trainby[n,c]) for n in names) for c in CONFIGS}
cand=[c for c in CONFIGS if cov[c]==max(cov.values())];oracle={n:min([distance(trainby[n,c]) for c in CONFIGS if valid(trainby[n,c])],default=None) for n in names}
common=[n for n in names if all(valid(trainby[n,c]) for c in cand)]
scores={c:mean([distance(trainby[n,c])/oracle[n] for n in common]) for c in cand}
sbs=min(cand,key=lambda c:(scores[c] if common else 0,CONFIGS.index(c)))
labels={n:min([c for c in CONFIGS if valid(trainby[n,c]) and distance(trainby[n,c])<=oracle[n]+1e-6],key=lambda c:(c!=sbs,CONFIGS.index(c))) for n in names if oracle[n] is not None}
predictions={p['instance']:{'fixed_sav250':'sav250','training_sbs':sbs} for p in sealed}
for method,fnames in [('primary_1nn4',FEATURES[:4]),('spatial_1nn8',FEATURES)]:
    m=models[method];means={f:mean([features[n][f] for n in names]) for f in fnames};stds={f:statistics.pstdev([features[n][f] for n in names]) for f in fnames};scales={f:stds[f] or 1. for f in fnames}
    vectors={n:[(features[n][f]-means[f])/scales[f] for f in fnames] for n in labels}
    assert m['features']==fnames and m['train_instances']==names and m['sbs']==sbs and m['coverage']==cov and m['labels']==labels and m['sbs_score_common_instances']==common
    assert all(close(m['feature_means'][f],means[f],1e-12) and close(m['feature_population_stds'][f],stds[f],1e-12) and close(m['feature_scales'][f],scales[f],1e-12) for f in fnames)
    assert all(close(m['sbs_scores'][c],scores[c],1e-12) for c in cand)
    assert m['skipped_unlabelable_training_instances']==[n for n in names if n not in labels]
    assert all(all(close(a,b,1e-12) for a,b in zip(vectors[n],m['vectors'][n])) for n in vectors)
    for p in sealed:
        n=p['instance'];v=[(features[n][f]-means[f])/scales[f] for f in fnames]
        distances={x:sum((a-b)**2 for a,b in zip(v,w)) for x,w in vectors.items()};best=min(distances.values());tied=sorted(x for x,d in distances.items() if d<=best+1e-12);nb=min(tied,key=lambda x:(labels[x]!=sbs,x));old=p['methods'][method]
        assert old['neighbor']==nb and old['neighbor_tie_instances']==tied and old['neighbor_tie_count']==len(tied) and close(old['neighbor_squared_distance'],distances[nb],1e-12) and old['selected_config']==labels[nb]
        predictions[n][method]=labels[nb]
ck(sbs=='pci250','Train-only SBS, scaling, labels, vectors and 96 1NN predictions reproduce independently',{'coverage':cov,'sbs':sbs,'labels':dict(collections.Counter(labels.values()))})
ck(len(sealed)==48 and {p['instance'] for p in sealed}==set(split['test']) and all(p['methods']['fixed_sav250']['selected_config']=='sav250' and p['methods']['training_sbs']['selected_config']==sbs for p in sealed),'All 48 sealed four-policy selections valid with fixed SAV and training-only SBS')

# Scoring is performed only now, after model reconstruction and sealed choice checks.
rows=[]
for name in sorted(split['test']):
    meta=parsed[name]['meta'];row={'instance':name,'geometry_id':meta['geometry_id'],'family':meta['family'],'width':meta['window_width']}
    for m in METHODS:
        c=predictions[name][m];r=testby[name,c];row[m]={'config':c,'valid':valid(r),'distance':distance(r)}
    rows.append(row)
def compare(rs,m):
    common=[r for r in rs if r[m]['valid'] and r['fixed_sav250']['valid']]
    deltas=[100*(r[m]['distance']/r['fixed_sav250']['distance']-1) for r in common]
    a=sum(r[m]['distance'] for r in common);b=sum(r['fixed_sav250']['distance'] for r in common)
    return {'method':m,'n_all':len(rs),'successes':sum(r[m]['valid'] for r in rs),'failures':sum(not r[m]['valid'] for r in rs),'common_success_n':len(common),'mean_relative_method_vs_sav_pct':mean(deltas),'sum_distance_reduction_vs_sav_pct':100*(1-a/b) if b else None,'wins':sum(r[m]['distance']<r['fixed_sav250']['distance']-1e-6 for r in common),'ties':sum(abs(r[m]['distance']-r['fixed_sav250']['distance'])<=1e-6 for r in common),'losses':sum(r[m]['distance']>r['fixed_sav250']['distance']+1e-6 for r in common),'method_only_success':sum(r[m]['valid'] and not r['fixed_sav250']['valid'] for r in rs),'sav_only_success':sum(not r[m]['valid'] and r['fixed_sav250']['valid'] for r in rs),'both_failed':sum(not r[m]['valid'] and not r['fixed_sav250']['valid'] for r in rs),'selected_config_counts':dict(collections.Counter(r[m]['config'] for r in rs))}
comparisons=[compare(rows,m) for m in METHODS]
for c in comparisons:
    old=next(s for s in summary['methods'] if s['method']==c['method'])
    for k,v in c.items(): assert (close(v,old[k],1e-10) if isinstance(v,(int,float)) else v==old[k]),(k,v,old[k])
georows=[{'geometry_id':g,'comparisons':[compare([r for r in rows if r['geometry_id']==g],m) for m in METHODS]} for g in sorted({r['geometry_id'] for r in rows})]
oldgeos={g['geometry_id']:g for g in j('reports/per_geometry.json')}
for g in georows:
    for c in g['comparisons']:
        old=next(v for v in oldgeos[g['geometry_id']]['comparisons'] if v['method']==c['method'])
        for k,v in c.items():assert (close(v,old[k],1e-10) if isinstance(v,(int,float)) else v==old[k])
ck(len(georows)==24 and all(sum(r['geometry_id']==g['geometry_id'] for r in rows)==2 for g in georows),'All 48 test outcomes and 24 geometry aggregations match reported results')
rng=random.Random(202610071902);indexes=[[rng.randrange(24) for _ in range(24)] for _ in range(5000)];boots={}
for mi,m in enumerate(METHODS):
    quality=[g['comparisons'][mi]['mean_relative_method_vs_sav_pct'] for g in georows]
    coverage=[100*(g['comparisons'][mi]['successes']-sum(r['fixed_sav250']['valid'] for r in rows if r['geometry_id']==g['geometry_id']))/2 for g in georows]
    qb=sorted(mean([quality[i] for i in ix if quality[i] is not None]) for ix in indexes);cb=sorted(mean([coverage[i] for i in ix]) for ix in indexes)
    b={'equal_geometry_mean_relative_pct':mean([v for v in quality if v is not None]),'conditional_quality_percentile95_pct':[qb[int(.025*(len(qb)-1))],qb[int(.975*(len(qb)-1))]],'mean_coverage_difference_percentage_points':mean(coverage),'coverage_difference_percentile95_percentage_points':[cb[int(.025*(len(cb)-1))],cb[int(.975*(len(cb)-1))]],'usable_common_success_geometry_units':sum(v is not None for v in quality)}
    for k,v in b.items():
        old=summary['geometry_bootstrap'][m][k]
        assert all(close(a,c,1e-10) for a,c in zip(v,old)) if isinstance(v,list) else close(v,old,1e-10)
    boots[m]=b
ck(True,'5000 documented seeded geometry-cluster bootstrap resamples reproduce; conditional-quality interpretation retained')
vbs={n:min([distance(testby[n,c]) for c in CONFIGS if valid(testby[n,c])],default=None) for n in split['test']}
vbs_common=[n for n in split['test'] if vbs[n] is not None and valid(testby[n,'sav250'])]
vbs_delta=mean([100*(vbs[n]/distance(testby[n,'sav250'])-1) for n in vbs_common])
ck(sum(v is not None for v in vbs.values())==summary['oracle']['valid'] and len(vbs_common)==summary['oracle']['common_with_sav_n'] and close(vbs_delta,summary['oracle']['mean_relative_oracle_vs_sav_pct'],1e-10),'Descriptive VBS equals best valid output among three recorded configurations only')
write('test48_recomputed.json',rows);write('comparisons_recomputed.json',comparisons);write('geometry24_recomputed.json',georows);write('bootstrap_recomputed.json',boots)

# Resource accounting: archive request costs are not prediction latency.
fc=j('evidence/feature_extraction.json');oh=j('raw/recommendation_overhead.json')
cost={'joint_eight_features_train_cpu_s':sum(fc[n]['cpu_s'] for n in split['train']),'joint_eight_features_test_cpu_s':sum(fc[n]['cpu_s'] for n in split['test']),'joint_eight_features_train_wall_s':sum(fc[n]['wall_s'] for n in split['train']),'joint_eight_features_test_wall_s':sum(fc[n]['wall_s'] for n in split['test']),'recorded_fit_prediction':oh,'selected_solver_request_cpu_s':{m:sum(testby[n,predictions[n][m]]['request_accounted_cpu_s'] for n in split['test']) for m in METHODS},'author_whole_cpu_s':package['whole_process_cpu_s_including_packaging'],'author_shell_cpu_s':101.860,'warning':'Individual short process_time deltas include zeros and ~0.004 second quantization; zero is below effective accounting resolution, not proof of no computational cost. Joint 8-feature extraction is an upper bound for primary 4-feature extraction.'}
for key,field in [('actual_solver_cpu_s','solve_cpu_s'),('actual_model_cpu_s','model_cpu_s'),('actual_checker_cpu_s','check_cpu_s'),('actual_all_requests_cpu_s','request_accounted_cpu_s')]:assert close(receipts[key],sum(r.get(field,0) for r in results),1e-10)
ck(True,'Measured feature, model fitting and prediction costs separate from actual archived solver requests')
write('resource_recomputed.json',cost)

# Fixed archive: dynamic manifest count, exact expected file set and byte hashes.
archive=Path(package['archive']);archive_hash=sha(archive)
with zipfile.ZipFile(archive) as z:
    names=z.namelist();assert len(names)==len(set(names)) and z.testzip() is None
    hs={n:h for h,n in (line.split('  ',1) for line in z.read('SHA256SUMS.txt').decode().splitlines())}
    allowed_root={'README_zh.txt','SHA256SUMS.txt'};allowed_dirs={'inputs','source','protocol','evidence','raw','reports'}
    assert all((n in allowed_root or n.split('/')[0] in allowed_dirs) and not n.startswith('/') and '..' not in Path(n).parts and not any(x in n.lower() for x in ['.venv','__pycache__','.env','.pem','.key','credential','token']) for n in names)
    assert set(names)==set(hs)|{'SHA256SUMS.txt'}
    assert all(hashlib.sha256(z.read(n)).hexdigest()==h and (ROOT/n).is_file() and sha(ROOT/n)==h for n,h in hs.items())
    ck(len(names)==package['file_count'] and archive_hash==package['sha256'],'Final author ZIP CRC, path whitelist, dynamic manifest, every file hash and receipt match',{'archive_sha256':archive_hash,'members':len(names),'manifest_entries':len(hs)})
    missing_frozen=sorted(set(freeze['sha256'])-set(names))
write('archive_audit.json',{'archive':archive.name,'sha256':archive_hash,'bytes':archive.stat().st_size,'members':len(names),'manifest_count':len(hs),'missing_frozen_file_members':missing_frozen,'strict_freeze_exception':changed,'path_allowlist':['README_zh.txt','SHA256SUMS.txt','inputs/','source/','protocol/','evidence/','raw/','reports/'],'crc_all_hashes_checked':True})

observations=[
 '研究分析核验通过。严格全文件冻结口径有一个非分析性例外：freeze列入当时为空的evidence/shell_time.txt，退出后回执写入导致hash改变；原ZIP又有意排除该文件。其余所有冻结文件一致。作者verification.json的frozen_files_unchanged只在退出前成立，不能泛指最终目录。',
 '原始ZIP没有shell/stdout/stderr回执，也不包含同目录外的最终package_receipt。原ZIP内部资源报告仅打包前CPU；打包后CPU来自单独回执，shell user+sys为更保守进程总数。应随交付保留这些补充证据，不修改冻结内容。',
 '4特征主方法45/48成功，低于固定SAV46/48。仅在45共同成功问题上平均距离低1.527594%；不能把这一条件质量优势称为全样本优胜。',
 '预定8特征方法48/48成功，在46共同成功问题上平均距离低1.554589%；24几何等权条件质量均值低1.329827%，描述性95%区间跨0。训练SBS=PCI也48/48成功。',
 '64为独立种子合成几何，两个窗口共享几何/需求且同分组；窗口围绕特定角度分区+最近邻构造，存在已披露生成偏置。不能声称真实农业外泛化、已部署或问题全局最优。',
 '源码及自记录日志支持先训练后封存再测试；非外部可信时间戳或不可篡改远端预注册，审计不将其夸大。',
 '仅重算审计，无求解器导入、求解重跑、超参数调整、模型/API请求或第三方数据传输。CPU限5秒，所有检查采用Python标准库。',
 '测得非常短的训练/预测CPU记录有0及约4ms量化，0必须解释为低于实际采样分辨率，不能说免费。壁钟训练/预测值非0。'
]
report={'audited_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_ANALYSIS_WITH_NONANALYTIC_RECEIPT_FREEZE_EXCEPTION' if not failures else 'FAIL','failures':failures,'checks':checks,'comparisons':comparisons,'geometry_bootstrap':boots,'resource_costs':cost,'observations':observations,'author_archive_sha256':archive_hash,'independent_audit_cpu_s':time.process_time(),'independent_audit_wall_s':time.perf_counter()-START}
write('audit_report.json',report)
lines=['64新合成几何前瞻选择实验独立审计','', '结论：分析核验通过；封存运行回执有一个非分析性例外。', '',*observations,'','复算结果：']
for s in comparisons:lines.append(f"{s['method']}：成功{s['successes']}/48，共同合法{s['common_success_n']}/48，平均相对SAV距离差{s['mean_relative_method_vs_sav_pct']:.9f}%，总距离降低{s['sum_distance_reduction_vs_sav_pct']:.9f}%，胜/平/负{s['wins']}/{s['ties']}/{s['losses']}。")
lines += ['',f"核验：{len(checks)}项，失败{len(failures)}；原ZIP {archive.name}；SHA256 {archive_hash}。", f"作者打包后CPU {cost['author_whole_cpu_s']:.9f}秒；shell user+sys 101.860秒；本独审脚本CPU截至报告写出 {time.process_time():.9f}秒。最终CPU单独回执记录。"]
(OUT/'report_zh.txt').write_text('\n'.join(lines)+'\n')
receipt={'finished_utc':datetime.now(timezone.utc).isoformat(),'cpu_s_before_final_receipt':time.process_time(),'wall_s':time.perf_counter()-START,'cpu_hard_limit_s':5,'author_cpu_including_packaging_s':cost['author_whole_cpu_s'],'author_conservative_shell_cpu_s':101.860,'author_shell_plus_audit_cpu_s':101.860+time.process_time(),'combined_under_180_seconds':101.860+time.process_time()<180,'scope':'Pure stdlib read-only audit of all returned routes, all witnesses, features, fit, predictions, aggregates, bootstrap and fixed archive; no solve rerun.'}
write('audit_resource_receipt.json',receipt)
print(json.dumps({'status':report['status'],'checks':len(checks),'failures':failures,'cpu_s':time.process_time(),'combined_cpu_s':101.860+time.process_time(),'archive_sha256':archive_hash},ensure_ascii=False))
