"""Read-only independent audit; never imports or invokes either study's code."""
import resource
resource.setrlimit(resource.RLIMIT_CPU, (2, 2))
import ast, collections, csv, hashlib, json, math, time, zipfile
from pathlib import Path
from datetime import datetime, timezone
A=Path('/workspace/shared/solver_portfolio_headroom_20261007')
R=Path('/workspace/shared/geometry_heldout_selection_20261007')
I=Path('/workspace/shared/public_vrptw_benchmark_20261007/inputs')
O=Path('/workspace/shared/audit_geometry_selector_20261007')
C=['pci250','pca250','sav250']
F=['capacity_over_total_demand','demand_population_cv','mean_window_width_over_depot_duration','mean_service_over_depot_duration']
start=time.process_time()
def read(p): return json.loads(p.read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def avg(v): return math.fsum(v)/len(v)
def eq(a,b): assert math.isclose(a,b,rel_tol=1e-11,abs_tol=1e-11),(a,b)
def snapshot(d): return {str(p.relative_to(d)):sha(p) for p in d.rglob('*') if p.is_file()}
before={str(d):snapshot(d) for d in [A,R,I]}
checks=[]
def ok(s): checks.append(s)
def manifest(base,p):
    entries={}
    for line in p.read_text().splitlines():
        h,n=line.split('  ',1); assert sha(base/n)==h,(p,n); entries[n]=h
    return entries
oldmanifest=manifest(A,A/'SHA256SUMS.txt')
currentmanifest=manifest(R,R/'SHA256SUMS_POSTAUDIT.txt')
initialmanifest=manifest(R,R/'SHA256SUMS.txt')
assert set(currentmanifest)==set(before[str(R)])-{'SHA256SUMS_POSTAUDIT.txt'}
freeze=read(R/'protocol/freeze.json')
for n,h in freeze['sha256'].items(): assert sha(R/n)==h,n
for n,v in read(R/'protocol/archive_identity.json').items():
    assert sha(A/n)==v['sha256'] and (A/n).stat().st_size==v['bytes'],n
ok('Frozen files, all source archive manifest entries, source identity snapshot and complete current manifest match')
features={}; groups=collections.defaultdict(list)
inputs=read(R/'protocol/input_manifest.json'); assert len(inputs)==56
source_manifest={r['name']:r for r in read(A/'protocol/input_manifest.json')}
saved_features={r['instance']:r for r in read(R/'protocol/features.json')}
for r in inputs:
    p=I/r['name']; data=p.read_bytes()
    assert len(data)==r['bytes'] and sha(p)==r['sha256']
    assert all(source_manifest[r['name']][k]==v for k,v in r.items())
    lines=data.decode().splitlines(); vi=lines.index('VEHICLE')
    fleet,capacity=[int(x) for x in lines[vi+2].split()]
    nodes=[]
    for line in lines:
        values=line.split()
        if len(values)==7:
            try: nodes.append([int(x) for x in values])
            except ValueError: pass
    assert len(nodes)==101 and [r[0] for r in nodes]==list(range(101))
    depot=nodes[0]; customer=nodes[1:]; demand=[r[3] for r in customer]; mean=avg(demand)
    duration=depot[5]-depot[4]
    x=[capacity/math.fsum(demand),math.sqrt(avg([(v-mean)**2 for v in demand]))/mean,
       avg([r[5]-r[4] for r in customer])/duration,avg([r[6] for r in customer])/duration]
    shape={'depot':depot[1:3],'customers':sorted(r[1:3] for r in customer)}
    g=hashlib.sha256(json.dumps(shape,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    n=p.stem; features[n]=x; groups[g].append(n)
    assert saved_features[n]['geometry_sha256']==g
    for k,v in zip(F,x): eq(saved_features[n][k],v)
assert len(features)==56 and len(groups)==4
ok('Recomputed four raw-input features and complete-coordinate hashes from all 56 original input files')
raw={}; lines=(A/'raw/results.jsonl').read_bytes().splitlines()
for lineno,line in enumerate(lines,1):
    r=json.loads(line)
    if r['config_id'] not in C: continue
    key=(r['instance'],r['config_id']); assert key not in raw
    legal=r['outcome']=='SUCCESS'
    if legal: assert r['check_summary']['valid'] and not r['check_summary']['errors'] and r['check_summary']['distance']>0
    raw[key]={'distance':r['check_summary']['distance'] if legal else None,'valid':legal,'outcome':r['outcome'],
              'run_id':r['run_id'],'source_line':lineno,'source_line_sha256':hashlib.sha256(line).hexdigest()}
assert len(raw)==168
extract=read(R/'raw/archive_outcome_extract.json'); assert len(extract)==168
for r in extract:
    actual=raw[r['instance'],r['config']]
    for k,v in actual.items(): assert r[k]==v,(r['instance'],k)
assert sum(not v['valid'] for v in raw.values())==7
assert all(v['outcome']=='TIMEOUT' and k[1]=='pca250' and v['distance'] is None for k,v in raw.items() if not v['valid'])
ok('All 168 candidate outcomes agree with source rows; all seven PCA TIMEOUTs remain null and preserved')
folds=read(R/'protocol/folds.json'); models={r['fold']:r for r in read(R/'raw/training_models.json')}
predlist=read(R/'raw/predictions_before_scoring.json'); pred={r['instance']:r for r in predlist}
scoredlist=read(R/'reports/predictions_all56.json'); scored={r['instance']:r for r in scoredlist}
assert len(folds)==4 and len(predlist)==len(pred)==len(scoredlist)==len(scored)==56
with (R/'reports/predictions_all56.csv').open() as f: csvrows=list(csv.DictReader(f))
assert len(csvrows)==56 and {r['instance'] for r in csvrows}==set(features)
independent=[]; seen=[]; foldresults=[]
for fold,g in zip(folds,sorted(groups)):
    test=sorted(groups[g]); train=sorted(set(features)-set(test)); seen.extend(test)
    assert fold['test_geometry_sha256']==g and fold['test_instances']==test and fold['train_instances']==train
    assert fold['n_train']==len(train) and fold['n_test']==len(test) and not set(train)&set(test)
    assert all(saved_features[n]['geometry_sha256']!=g for n in train)
    oracle={n:min(raw[n,c]['distance'] for c in C if raw[n,c]['valid']) for n in train}
    coverage={c:sum(raw[n,c]['valid'] for n in train) for c in C}
    candidates=[c for c in C if coverage[c]==max(coverage.values())]
    common=[n for n in train if all(raw[n,c]['valid'] for c in candidates)]
    scores={c:avg([raw[n,c]['distance']/oracle[n] for n in common]) for c in candidates}
    sbs=min(candidates,key=lambda c:(scores[c],C.index(c)))
    labels={n:min([c for c in C if raw[n,c]['valid'] and raw[n,c]['distance']<=oracle[n]+1e-6],key=lambda c:(c!=sbs,C.index(c))) for n in train}
    means=[avg([features[n][j] for n in train]) for j in range(4)]
    stds=[math.sqrt(avg([(features[n][j]-means[j])**2 for n in train])) for j in range(4)]
    scale=[v or 1. for v in stds]
    m=models[fold['fold']]
    assert m['train_instances']==train and m['sbs']==sbs and m['coverage']==coverage and m['labels']==labels
    assert m['sbs_score_common_instances']==common and m['skipped_unlabelable_training_instances']==[]
    for c,v in scores.items(): eq(m['sbs_scores'][c],v)
    for j,k in enumerate(F):
        eq(m['feature_means'][k],means[j]); eq(m['feature_population_stds'][k],stds[j]); eq(m['feature_scales'][k],scale[j])
    for n in train:
        for j in range(4): eq(m['vectors'][n][j],(features[n][j]-means[j])/scale[j])
    foldrows=[]
    for n in test:
        # Algebraically independent nearest-neighbor computation: raw differences / train-only scale.
        distance={t:math.fsum(((features[n][j]-features[t][j])/scale[j])**2 for j in range(4)) for t in train}
        best=min(distance.values()); tied=sorted(t for t,v in distance.items() if v<=best+1e-12)
        neighbor=min(tied,key=lambda t:(labels[t]!=sbs,t)); chosen=labels[neighbor]
        p=pred[n]
        assert p['selected_config']==chosen and p['neighbor']==neighbor and p['fold_sbs_config']==sbs
        assert p['fold']==fold['fold'] and p['geometry_sha256']==g and p['n_train']==len(train) and p['n_test']==len(test)
        assert p['neighbor_tie_instances']==tied and p['neighbor_tie_count']==len(tied)
        eq(p['neighbor_squared_distance'],distance[neighbor])
        choice=raw[n,chosen]; baseline=raw[n,sbs]; ob=min(raw[n,c]['distance'] for c in C if raw[n,c]['valid'])
        row=scored[n]
        for k in p:
            if k!='neighbor_tie_instances': assert row[k]==p[k]
        assert row['selected_valid']==choice['valid'] and row['selected_failed']==(not choice['valid'])
        assert row['selected_distance']==choice['distance'] and row['sbs_distance']==baseline['distance'] and row['oracle_distance']==ob
        assert row['sbs_valid']==baseline['valid'] and row['selected_outcome']==choice['outcome'] and row['sbs_outcome']==baseline['outcome']
        for k in ['run_id','source_line','source_line_sha256']: assert row['selected_'+k]==choice[k]
        q={'instance':n,'fold':fold['fold'],'selected_config':chosen,'neighbor':neighbor,'sbs':sbs,
           'selected':choice['distance'],'baseline':baseline['distance'],'oracle':ob,'selected_valid':choice['valid'],'sbs_valid':baseline['valid']}
        independent.append(q); foldrows.append(q)
    foldresults.append({'fold':fold['fold'],'n_train':len(train),'n_test':len(test),'sbs':sbs,
      'mean_relative_change_pct':avg([100*(v['selected']/v['baseline']-1) for v in foldrows]),
      'total_relative_change_pct':100*(math.fsum(v['selected'] for v in foldrows)/math.fsum(v['baseline'] for v in foldrows)-1)})
assert sorted(seen)==sorted(features)
ok('Independent train-only SBS, best labels, scaling and raw-difference nearest neighbors exactly reproduce all 56 choices across disjoint LOgeo folds')
sel=math.fsum(r['selected'] for r in independent); sbs=math.fsum(r['baseline'] for r in independent)
metrics={'n':56,'selected_successes':sum(r['selected_valid'] for r in independent),'sbs_successes':sum(r['sbs_valid'] for r in independent),
 'mean_relative_change_pct':avg([100*(r['selected']/r['baseline']-1) for r in independent]),'total_relative_change_pct':100*(sel/sbs-1),
 'better':sum(r['selected']<r['baseline']-1e-6 for r in independent),'tied':sum(abs(r['selected']-r['baseline'])<=1e-6 for r in independent),'worse':sum(r['selected']>r['baseline']+1e-6 for r in independent),
 'mean_selected_oracle_gap_pct':avg([100*(r['selected']/r['oracle']-1) for r in independent]),'mean_sbs_oracle_gap_pct':avg([100*(r['baseline']/r['oracle']-1) for r in independent]),
 'selected_config_counts':dict(collections.Counter(r['selected_config'] for r in independent)),'all_geometry_aggregate_changes_positive':all(r['total_relative_change_pct']>0 for r in foldresults)}
assert (metrics['selected_successes'],metrics['sbs_successes'],metrics['better'],metrics['tied'],metrics['worse'])==(56,56,15,21,20)
for key,val in [('mean_relative_change_pct',0.587605),('total_relative_change_pct',0.520791),('mean_selected_oracle_gap_pct',3.173431),('mean_sbs_oracle_gap_pct',2.609732)]: assert abs(metrics[key]-val)<0.0000005
summary=read(R/'reports/summary.json')
for key,out in [('mean_relative_change_pct','mean_relative_selected_vs_sbs_pct'),('mean_selected_oracle_gap_pct','mean_selected_gap_to_oracle_pct_common'),('mean_sbs_oracle_gap_pct','mean_sbs_gap_to_oracle_pct_common')]: eq(metrics[key],summary[out])
eq(metrics['total_relative_change_pct'],-summary['sum_distance_reduction_selected_vs_sbs_pct'])
ok('All main quality and success statistics independently recomputed; every geometry aggregate worsens')
seal=read(R/'evidence/predictions_sealed.json')
assert sha(R/'raw/predictions_before_scoring.json')==seal['prediction_sha256'] and sha(R/'raw/training_models.json')==seal['model_sha256']
assert freeze['frozen_utc']<seal['sealed_utc']<read(R/'evidence/verification.json')['completed_utc']
code=ast.parse((R/'source/study.py').read_text())
predict=next(n for n in code.body if isinstance(n,ast.FunctionDef) and n.name=='predict')
assert [a.arg for a in predict.args.args]==['model','test_vector']
assert not any(isinstance(n,ast.Name) and n.id in {'outcomes','by_feature','name_test','ARCHIVE','INPUTS'} for n in ast.walk(predict))
ok('Freeze and prediction-seal hashes/timestamps match; source review confirms train-only fit and no test-cost gate or free fallback')
receipt=read(R.parent/(R.name+'_final_receipt.json')); z=Path(receipt['zip_path'])
assert sha(z)==receipt['zip_sha256'] and z.stat().st_size==receipt['zip_bytes']
with zipfile.ZipFile(z) as bundle:
    names=bundle.namelist(); assert len(names)==len(set(names)) and bundle.testzip() is None
    assert set(names)==set(before[str(R)])
    for n in names: assert hashlib.sha256(bundle.read(n)).hexdigest()==sha(R/n),n
    assert not any(n.endswith('.pyc') or '__pycache__' in n or n.startswith('inputs/') for n in names)
ok('Final ZIP receipt SHA256, CRC, no duplicate members and all member bytes agree with complete directory/manifest')
assert before=={str(d):snapshot(d) for d in [A,R,I]}
ok('Entire source archive, selector directory and original input tree byte identities unchanged during independent audit')
result={'audit_utc':datetime.now(timezone.utc).isoformat(),'pass':True,'checks':checks,'metrics':metrics,'per_geometry':foldresults,
 'input_count':56,'original_archive_manifest_entries_verified':len(oldmanifest),'frozen_file_count':len(freeze['sha256']),
 'current_manifest_entries_verified':len(currentmanifest),'zip_path':str(z),'zip_sha256':sha(z),'zip_bytes':z.stat().st_size,
 'zip_member_count':len(names),'input_tree_and_archive_unchanged_during_audit':True,
 'limitations':['Retrospective exploratory reanalysis of a previously observed archive, not new external or blind heldout testing.',
 'Current hashes match recorded pre-run evidence; this cannot prove no transient historical edits or prove analyst lack of prior knowledge.',
 'No solver, API/model, installation or route replay. Historical feasibility is inherited from archived continuous checks.',
 'Oracle/VBS headroom is descriptive, not evidence of model utility or predictability. This fixed selector has a negative result.'],
 'resource':{'audit_process_cpu_s_including_imports_at_report':time.process_time(),'audit_cpu_s_since_checks_start':time.process_time()-start,'hard_cpu_limit_s':2,'extra_cpu_budget_s':5},
 'new_solver_calls':0,'new_model_calls':0,'new_installs':0}
(O/'audit_result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
(O/'recomputed_predictions.json').write_text(json.dumps(sorted(independent,key=lambda r:r['instance']),ensure_ascii=False,indent=2)+'\n')
(O/'source_snapshot.json').write_text(json.dumps(before,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
