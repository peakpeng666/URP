"""Package audit evidence only. Does not execute either solver or checker."""
import resource
resource.setrlimit(resource.RLIMIT_CPU, (1, 1))
import json, hashlib, zipfile, time
from pathlib import Path
P = Path(__file__).resolve().parent
names = ['audit.py','audit_initial.py','package_audit.py','audit_summary.json','audit_initial_summary.json',
         'audit_resource.json','audit_initial_resource.json','evidence.json','route_replay.jsonl',
         'report_zh.txt','report_initial_zh.txt']
assert json.loads((P/'audit_summary.json').read_text())['issues'] == []
hashes = {name:hashlib.sha256((P/name).read_bytes()).hexdigest() for name in names}
(P/'SHA256SUMS.txt').write_text(''.join(value+'  '+name+'\n' for name,value in hashes.items()))
names.append('SHA256SUMS.txt')
archive = P.with_suffix('.zip')
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name in names:z.write(P/name,name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(names)
    for name,h in hashes.items():assert hashlib.sha256(z.read(name)).hexdigest()==h
prior = json.loads((P/'audit_resource.json').read_text())
receipt = {'archive':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,
           'file_count':len(names),'whitelist':names,'conclusion':'PASS_WITH_REPORTING_CAVEATS',
           'author_archive_sha256':json.loads((P/'audit_summary.json').read_text())['archive_sha256'],
           'packaging_cpu_snapshot_s':time.process_time(),'packaging_cpu_hard_limit_s':1,
           'cumulative_audit_and_package_cpu_snapshot_s':prior['cumulative_audit_snapshot_cpu_s']+time.process_time(),
           'scope_note':'Two independent stdlib replay passes, second solely to correct an obsolete50-member assertion after a transparent52-member report-only author package. Initial failed assertion/source/results preserved. No solver calls. CPU snapshots omit final receipt writes and interpreter teardown.',
           'crc_and_hashes_verified':True}
P.with_name(P.name+'_package_receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
P.with_suffix('.zip.sha256').write_text(receipt['sha256']+'  '+archive.name+'\n')
print(json.dumps(receipt,ensure_ascii=False))
