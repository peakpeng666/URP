"""Read-only, standard-library audit. Never imports study, checker or OR-Tools."""
import resource
resource.setrlimit(resource.RLIMIT_CPU, (3, 3))
import collections, csv, hashlib, io, json, math, re, statistics, time, zipfile
from decimal import Decimal, localcontext, ROUND_HALF_UP, ROUND_CEILING
from pathlib import Path
from datetime import datetime

ROOT = Path('/workspace/shared/solver_portfolio_headroom_20261007')
INPUT = Path('/workspace/shared/public_vrptw_benchmark_20261007/inputs')
OUT = Path(__file__).resolve().parent
SCALE = 1_000_000
TOL = 1e-9
CONF = ['pci250', 'pca250', 'sav250', 'pci750']
SHORT = CONF[:3]
start_wall = time.perf_counter()
issues = []
checks = collections.Counter()

def require(condition, what):
    checks['assertions'] += 1
    if not condition:
        issues.append(what)

def close(a, b, name, tol=1e-8):
    require(abs(a-b) <= tol, f'{name}: {a!r} != {b!r}')

def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()

def read(name):
    return json.loads((ROOT/name).read_text())

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write(name, value):
    (OUT/name).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+'\n')

# Read every protocol, source, evidence, raw, and report file as bytes, including logs.
file_bytes = {str(p.relative_to(ROOT)): p.read_bytes() for p in ROOT.rglob('*')
              if p.is_file() and '__pycache__' not in p.parts}
freeze = read('protocol/freeze.json')
for name, expected in freeze['sha256'].items():
    require(sha(file_bytes[name]) == expected, 'frozen hash: '+name)
require(freeze['solver_calls_before_freeze'] == 0, 'recorded pre-freeze calls')
require(freeze['request_count'] == 224 and freeze['input_count'] == 56, 'freeze denominator')
for line in file_bytes['SHA256SUMS.txt'].decode().splitlines():
    expected, name = line.split('  ', 1)
    require(sha(file_bytes[name]) == expected, 'manifest hash: '+name)
receipt = json.loads((ROOT.parent/(ROOT.name+'_package_receipt.json')).read_text())
archive = ROOT.parent/receipt['archive']
require(sha(archive.read_bytes()) == receipt['sha256'], 'archive SHA256')
with zipfile.ZipFile(archive) as z:
    require(z.testzip() is None, 'archive CRC')
    require(len(z.namelist()) == receipt['file_count'] == 52, 'archive file count')
    require(set(z.namelist()) == set(file_bytes), 'archive is exact final artifact set')
    for name in z.namelist():
        require(z.read(name) == file_bytes[name], 'archive bytes: '+name)
        require(not any(x in Path(name).parts for x in ['inputs', '__pycache__', '.venv']), 'unsafe package path: '+name)

# Parse the original text independently; no author parser or encoded matrices are loaded.
manifest = read('protocol/input_manifest.json')
instances = {}
distance_cache = {}
def values(sq):
    if sq not in distance_cache:
        with localcontext() as ctx:
            ctx.prec = 50
            d = Decimal(sq).sqrt()*SCALE
            distance_cache[sq] = (int(d.to_integral_value(rounding=ROUND_HALF_UP)),
                                  int(d.to_integral_value(rounding=ROUND_CEILING)))
    return distance_cache[sq]

geometry = {k:collections.defaultdict(list) for k in ['geometry_sha256', 'geometry_demand_sha256', 'geometry_demand_service_sha256', 'ordered_geometry_sha256']}
for m in manifest:
    data = (INPUT/m['name']).read_bytes()
    require(sha(data) == m['sha256'] and len(data) == m['bytes'], 'original identity: '+m['name'])
    text = data.decode()
    fleet_match = re.search(r'NUMBER\s+CAPACITY\s*\n\s*(\d+)\s+(\d+)', text)
    assert fleet_match, m['name']
    k, capacity = map(int, fleet_match.groups())
    rows = []
    for line in text.splitlines():
        if re.fullmatch(r'\s*-?\d+(?:\s+-?\d+){6}\s*', line):
            rows.append(tuple(map(int, line.split())))
    require(len(rows) == 101 and [r[0] for r in rows] == list(range(101)), 'original customer IDs: '+m['name'])
    name = m['name'][:-4]
    require(text.splitlines()[0].strip().lower() == name, 'original header: '+name)
    nodes = {r[0]: r[1:] for r in rows}
    require(nodes[0][2:] == (0,0,m['depot_due'],0), 'depot semantics: '+name)
    require(k == m['vehicle_limit'] and capacity == m['capacity'], 'fleet/capacity manifest: '+name)
    family = re.match(r'(?:rc|r|c)[12]', name).group().upper()
    semantic = {'id':name,'family':family,'vehicles':k,'capacity':capacity,
                'nodes':[dict(zip(['id','x','y','demand','ready','due','service'],r)) for r in rows]}
    require(digest(semantic) == m['semantic_sha256'], 'semantic SHA256: '+name)
    cost, travel = [], []
    for a in rows:
        vals = [values((a[1]-b[1])**2+(a[2]-b[2])**2) for b in rows]
        cost.append([v[0] for v in vals]); travel.append([v[1] for v in vals])
    encoded = {'cost_nearest':cost,'travel_ceil':travel,'service_exact':[r[6]*SCALE for r in rows]}
    require(digest(encoded) == m['encoded_sha256'], 'independent Decimal encoded SHA256: '+name)
    geom_values = {
        'geometry_sha256': {'depot':list(nodes[0][:2]), 'customers':sorted([list(r[1:3]) for r in rows[1:]])},
        'geometry_demand_sha256': {'depot':list(nodes[0][:2]), 'customers':sorted([list(r[1:4]) for r in rows[1:]])},
        'geometry_demand_service_sha256': {'depot':list(nodes[0][:2]), 'customers':sorted([[r[1],r[2],r[3],r[6]] for r in rows[1:]])},
        'ordered_geometry_sha256': [list(r[:3]) for r in rows]
    }
    for key, value in geom_values.items(): geometry[key][digest(value)].append(name)
    instances[name] = {'nodes':nodes, 'fleet':k, 'capacity':capacity, 'family':family}
require(len(instances) == 56, 'unique original instances')
for key, groups in geometry.items():
    require(len(groups) == 4, 'four real geometry groups: '+key)
    expected = {x['sha256']: x['instances'] for x in read('protocol/shared_geometry.json')[key]}
    require(dict(groups) == expected, 'geometry membership: '+key)

requests = read('protocol/requests.json')
raw = [json.loads(line) for line in file_bytes['raw/results.jsonl'].decode().splitlines()]
author_checks = [json.loads(line) for line in file_bytes['raw/continuous_checks.jsonl'].decode().splitlines()]
author_by_id = {r['run_id']:r for r in author_checks}
require(len(raw) == len(requests) == 224, 'complete request denominator')
require(len({r['run_id'] for r in raw}) == 224, 'unique raw request IDs')
require(len(author_by_id) == len(author_checks), 'unique author replay IDs')
order_counts = {c:collections.Counter() for c in CONF}
for index, (request, result) in enumerate(zip(requests, raw)):
    require(all(result.get(k) == v for k,v in request.items()), 'request/raw metadata: '+request['run_id'])
    require(request['sequence'] == index, 'request sequence')
    expected_conf = CONF[(index//4%4 + index%4)%4]
    require(request['config_id'] == expected_conf, 'cyclic configuration order')
    require(request['instance'] == sorted(instances)[index//4], 'alphabetical instance order')
    require(request['budget_ms'] == (750 if expected_conf == 'pci750' else 250), 'budget assignment')
    order_counts[expected_conf][index%4] += 1
require(all(list(sorted(v.values())) == [14]*4 for v in order_counts.values()), 'balanced order positions')
require(sum(r['budget_ms'] for r in requests) == 84000, '84 second nominal total')

base_parameters = file_bytes['protocol/parameters_pci250.textproto'].decode()
strategies = {'pci250':'PARALLEL_CHEAPEST_INSERTION','pca250':'PATH_CHEAPEST_ARC','sav250':'SAVINGS','pci750':'PARALLEL_CHEAPEST_INSERTION'}
for c in CONF:
    p = file_bytes[f'protocol/parameters_{c}.textproto'].decode()
    require(p.startswith('first_solution_strategy: '+strategies[c]+'\n'), 'first solution enum: '+c)
    p = re.sub(r'^first_solution_strategy: \w+', 'first_solution_strategy: PARALLEL_CHEAPEST_INSERTION', p)
    if c == 'pci750': p = p.replace('nanos: 750000000','nanos: 250000000')
    require(p == base_parameters, 'only authorized parameter difference: '+c)
require('local_search_metaheuristic: GUIDED_LOCAL_SEARCH' in base_parameters and 'guided_local_search_lambda_coefficient: 0.1' in base_parameters, 'shared GLS')

replays = []
distances = {}
for r in raw:
    rid = r['run_id']; d = instances[r['instance']]; nodes = d['nodes']
    if not r['assignment_returned']:
        require(r['routes'] is None and r['outcome'] == 'TIMEOUT' and r['ortools_status'] == 4, 'nonassignment classification: '+rid)
        require(rid not in author_by_id, 'nonassignment must not have feasible replay: '+rid)
        replays.append({'run_id':rid, 'returned':False, 'outcome':r['outcome']})
        continue
    before = len(issues)
    routes = r['routes']; visits = []; route_details = []; legs_all = []; integer_obj = 0; min_margin = math.inf
    vehicles = [route['vehicle'] for route in routes]
    require(len(set(vehicles)) == len(vehicles) and all(type(v)==int and 0<=v<d['fleet'] for v in vehicles), 'vehicle IDs: '+rid)
    require(len(routes) <= d['fleet'], 'fleet limit: '+rid)
    author = author_by_id[rid]
    for route_index, route in enumerate(routes):
        seq = route['nodes']
        require(len(seq)>=3 and seq[0]==seq[-1]==0 and 0 not in seq[1:-1], 'depot structure: '+rid)
        require(all(type(i)==int and i in nodes for i in seq), 'node IDs: '+rid)
        visits.extend(seq[1:-1])
        load = sum(nodes[i][2] for i in seq[1:-1])
        require(load <= d['capacity'], 'capacity: '+rid)
        now = 0.; encoded_now = 0; route_legs = []
        recorded = author['route_audits'][route_index]
        require(recorded['nodes'] == seq and recorded['load'] == load, 'author route identity/load: '+rid)
        require(len(recorded['steps']) == len(seq)-1, 'author route step count: '+rid)
        require(len(route['encoded_cumul_ranges']) == len(seq)-1, 'encoded cumul count: '+rid)
        for edge_index in range(len(seq)-1):
            a, b = seq[edge_index:edge_index+2]
            origin, dest = nodes[a], nodes[b]
            sq = (origin[0]-dest[0])**2+(origin[1]-dest[1])**2
            leg = math.sqrt(sq)
            arrival = now + origin[5] + leg
            now = max(arrival, dest[3])
            margin = dest[4] - now
            require(margin >= -TOL, 'continuous time window/depot return: '+rid)
            min_margin = min(min_margin, margin)
            route_legs.append(leg); legs_all.append(leg)
            rounded, ceiling = values(sq); integer_obj += rounded
            encoded_now = max(encoded_now + origin[5]*SCALE + ceiling, dest[3]*SCALE)
            require(encoded_now <= dest[4]*SCALE, 'encoded conservative feasibility: '+rid)
            cr = route['encoded_cumul_ranges'][edge_index]
            require(cr['node'] == b and cr['min'] <= cr['max'] and cr['min'] >= encoded_now and cr['min'] >= dest[3]*SCALE and cr['max'] <= dest[4]*SCALE, 'encoded cumul range consistency: '+rid)
            step = recorded['steps'][edge_index]
            require(step['node']==b and step['due']==dest[4], 'author step identity: '+rid)
            for key, expected in [('arrival',arrival),('service_start',now),('margin',margin),('leg',leg)]: close(step[key],expected,'author '+key+': '+rid)
        route_distance = math.fsum(route_legs)
        close(recorded['distance'],route_distance,'author route distance: '+rid)
        close(recorded['return_time'],now,'author route return: '+rid)
        route_details.append({'vehicle':route['vehicle'],'customers':len(seq)-2,'load':load,'distance':route_distance,'return_time':now})
    require(sorted(visits) == list(range(1,101)), 'all customers exactly once: '+rid)
    distance = math.fsum(legs_all)
    require(integer_obj == r['objective_integer'] == author['independent_objective_integer'], 'integer objective: '+rid)
    bound = len(legs_all)*0.5/SCALE
    require(abs(integer_obj/SCALE-distance) <= bound+TOL, 'cost rounding bound: '+rid)
    require(len(legs_all) == 100+len(routes), 'nonempty arc count: '+rid)
    require(r['outcome']=='SUCCESS' and author['valid'] and not author['errors'], 'success classification: '+rid)
    for record in [author,r['check_summary']]:
        close(record['distance'],distance,'reported distance: '+rid)
        close(record['minimum_window_margin'],min_margin,'reported window margin: '+rid)
        require(record['served_unique']==100 and record['vehicles_used']==len(routes), 'reported coverage: '+rid)
    distances[rid] = distance
    replays.append({'run_id':rid,'returned':True,'valid':len(issues)==before,'distance':distance,'integer_objective':integer_obj,'rounding_error':abs(integer_obj/SCALE-distance),'rounding_bound':bound,'minimum_window_margin':min_margin,'route_details':route_details})
require(len(distances) == len(author_checks) == 217, '217 returned assignments checked')

summary = read('reports/summary.json')
by = {c:{r['instance']:r for r in raw if r['config_id']==c} for c in CONF}
computed_methods = []
for c in CONF:
    records = list(by[c].values()); valid = [r for r in records if r['run_id'] in distances]
    method = {'method':c,'requests':len(records),'legal_count':len(valid),'legal_rate':len(valid)/56,
              'outcome_counts':dict(collections.Counter(r['outcome'] for r in records)),
              'distance_valid_sum':math.fsum(distances[r['run_id']] for r in valid),
              'cpu_s':math.fsum(r['request_accounted_cpu_s'] for r in records),
              'wall_s':math.fsum(r['request_accounted_wall_s'] for r in records)}
    method['distance_valid_mean'] = method['distance_valid_sum']/len(valid)
    computed_methods.append(method)
    original = next(x for x in summary['methods'] if x['method']==c)
    for key in ['requests','legal_count','outcome_counts']: require(method[key]==original[key],'method '+key+': '+c)
    for key in ['legal_rate','distance_valid_sum','distance_valid_mean','cpu_s','wall_s']: close(method[key],original[key],'method '+key+': '+c)
    for r in records:
        close(r['request_accounted_cpu_s'],r['total_cpu_s']+r['parse_cpu_s']+r['check_cpu_s'],'CPU components: '+r['run_id'])
        close(r['request_accounted_wall_s'],r['total_wall_s']+r['parse_wall_s']+r['check_wall_s'],'wall components: '+r['run_id'])
failures = [r for r in raw if r['run_id'] not in distances]
require(failures == read('reports/failures.json'), 'all seven full failures preserved')
require(raw == read('reports/evaluated_results.json'), 'evaluated results exactly raw')
names = sorted(instances)
vbs = {i:min(distances[by[c][i]['run_id']] for c in SHORT if by[c][i]['run_id'] in distances) for i in names}
coverage = {c:sum(by[c][i]['run_id'] in distances for i in names) for c in SHORT}
top = [c for c in SHORT if coverage[c] == max(coverage.values())]
common = [i for i in names if all(by[c][i]['run_id'] in distances for c in top)]
scores = {c:statistics.mean(distances[by[c][i]['run_id']]/vbs[i] for i in common) for c in top}
sbs = min(top,key=lambda c:(scores[c],SHORT.index(c)))
gaps = [100*(distances[by[sbs][i]['run_id']]/vbs[i]-1) for i in names]
reduction = [100*(1-vbs[i]/distances[by[sbs][i]['run_id']]) for i in names]
improved = [i for i in names if distances[by[sbs][i]['run_id']]-vbs[i]>1e-6]
unique = collections.Counter(); tied = collections.Counter()
for i in names:
    winners = [c for c in SHORT if by[c][i]['run_id'] in distances and abs(distances[by[c][i]['run_id']]-vbs[i]) <= 1e-6]
    tied.update(winners)
    if len(winners)==1: unique.update(winners)
headroom = summary['posthoc_headroom']
require(sbs==headroom['posthoc_sbs']=='sav250','posthoc SBS')
require(improved==headroom['complementary_improvement_instances'],'complementary instance list')
close(statistics.mean(gaps),headroom['mean_sbs_over_vbs_gap_pct'],'SBS/VBS mean')
close(statistics.median(gaps),headroom['median_sbs_over_vbs_gap_pct'],'SBS/VBS median')
close(statistics.mean(reduction),headroom['mean_oracle_reduction_vs_sbs_pct'],'oracle mean reduction')
require(dict(unique)==summary['configuration_wins']['unique_wins'],'unique wins')
require(dict(tied)==summary['configuration_wins']['wins_including_ties'],'tied wins')

def paired(ids, first, second):
    delta = [first[i]-second[i] for i in ids]
    return {'n':len(ids),'wins':sum(d < -1e-6 for d in delta),'ties':sum(abs(d)<=1e-6 for d in delta),'losses':sum(d>1e-6 for d in delta),'first_distance_sum':math.fsum(first[i] for i in ids),'second_distance_sum':math.fsum(second[i] for i in ids),'total_distance_reduction_pct':100*(1-math.fsum(first[i] for i in ids)/math.fsum(second[i] for i in ids)),'mean_instance_relative_pct':statistics.mean(100*(first[i]/second[i]-1) for i in ids)}

long = {i:distances[by['pci750'][i]['run_id']] for i in names}
comp = paired(names,vbs,long)
reported = summary['paired_comparisons'][1]
for a,b in [('n','both_valid_count'),('wins','first_wins'),('ties','ties'),('losses','second_wins')]: require(comp[a]==reported[b], 'long comparison '+a)
for a,b in [('first_distance_sum','first_distance_sum'),('second_distance_sum','second_distance_sum'),('total_distance_reduction_pct','sum_distance_reduction_first_vs_second_pct'),('mean_instance_relative_pct','mean_per_instance_first_vs_second_pct')]: close(comp[a],reported[b],'long comparison '+a)
geometric_results = []
for group_hash, ids in geometry['geometry_sha256'].items():
    x = paired(ids,vbs,long)
    rep = next(g for g in summary['geometry_results'] if g['sha256']==group_hash)['portfolio_vs_long']
    for a,b in [('wins','first_wins'),('ties','ties'),('losses','second_wins')]: require(x[a]==rep[b],'geometry comparison '+a)
    close(x['total_distance_reduction_pct'],rep['sum_distance_reduction_first_vs_second_pct'],'geometry reduction')
    geometric_results.append({'families':sorted(set(instances[i]['family'] for i in ids)), 'instances':ids, **x})
portfolio_cpu = math.fsum(m['cpu_s'] for m in computed_methods[:3]) + summary['executed_portfolio']['selection_cpu_s']
cpu_ratio = portfolio_cpu/computed_methods[3]['cpu_s']
close(portfolio_cpu,summary['executed_portfolio']['cpu_s'],'executed portfolio CPU')
close(cpu_ratio,summary['actual_portfolio_cpu_over_long'],'CPU ratio')
for r in read('reports/instance_comparisons.json'):
    i = r['instance']
    for c in CONF:
        require(r[c+'_outcome'] == by[c][i]['outcome'], 'per-instance outcome')
        if by[c][i]['run_id'] in distances: close(r[c+'_distance'],distances[by[c][i]['run_id']],'per-instance distance')
        else: require(r[c+'_distance'] is None,'failure distance must remain absent')
    close(r['best_of_3_distance'],vbs[i],'per-instance VBS')

stdout = file_bytes['raw/stdout.log'].decode().splitlines()
require(stdout[0]=='FROZEN 56 inputs,224 requests;zero pilot calls.' and stdout[-1]=='ALL224 FINISHED AND INDEPENDENTLY CHECKED', 'freeze/run stdout ordering')
require(len(stdout)==226, '224 progress records')
for r,line in zip(raw,stdout[1:-1]):
    fields=line.split()
    require(fields[:3]==[str(r['sequence']+1),r['run_id'],r['outcome']], 'stdout/raw ordering')
resources = read('evidence/resource_accounting.json')
prior = read('evidence/preflight_01_resource.json')
recovery = read('evidence/preflight_recovery.json')
require(prior['exit_code']==1 and recovery['solver_calls']==0 and recovery['prior_frozen_protocol_existed'] is False,'retained zero-solve preflight')
require('resource.setrlimit' in file_bytes['evidence/preflight_01_stderr.log'].decode(), 'preflight fails before solver import')
require(datetime.fromisoformat(prior['finished_utc']) < datetime.fromisoformat(freeze['frozen_utc']) < datetime.fromisoformat(resources['finished_utc']), 'recorded freeze timeline')
require(resources['exit_code']==0 and read('raw/runner_resource.json')['requests_completed']==224, 'successful process/224 completion')
require(resources['child_cpu_s'] <=169 and receipt['supervisor_cpu_including_packaging_s'] <=5,'author CPU caps observed')
require(sum(resources['hard_cpu_limits_s'].values())==179,'169+5+5 hard limits are 179')
require(179+receipt['prior_preflight_cpu_s']+receipt['postrun_pass_cpu_hard_limit_s']<180,'known preflight plus current hard caps and report-only pass under180')
require(file_bytes['raw/stderr.log']==b'', 'main run stderr empty')

result = {
 'conclusion':'PASS_WITH_REPORTING_CAVEATS' if not issues else 'FAIL',
 'issues':issues, 'assertions':checks['assertions'], 'stdlib_only':True, 'solver_calls_by_auditor':0,
 'author_code_imports':0, 'hard_cpu_limit_s':3, 'original_instances_verified':len(instances),
 'frozen_files_verified':len(freeze['sha256']), 'all_artifact_files_read':len(file_bytes),
 'raw_requests':len(raw),'returned_assignments_replayed':len(distances),'retained_timeouts':[r['run_id'] for r in failures],
 'methods':computed_methods,'posthoc_sbs':sbs,'mean_sbs_over_vbs_gap_pct':statistics.mean(gaps),
 'median_sbs_over_vbs_gap_pct':statistics.median(gaps),'mean_oracle_reduction_vs_sbs_pct':statistics.mean(reduction),
 'complementary_instances':len(improved),'rescued_sbs_failures':0,'unique_wins':dict(unique),'wins_including_ties':dict(tied),
 'portfolio_vs_pci750':comp,'portfolio_cpu_s':portfolio_cpu,'long_cpu_s':computed_methods[3]['cpu_s'],'portfolio_cpu_ratio':cpu_ratio,
 'geometry_groups':geometric_results,'geometry_hash_group_counts':{k:len(v) for k,v in geometry.items()},
 'minimum_returned_solution_window_margin':min(x['minimum_window_margin'] for x in replays if x['returned']),
 'archive_sha256':receipt['sha256'], 'archive_file_count':receipt['file_count'],
 'author_total_recorded_cpu_s_before_audit':receipt['total_measured_cpu_s'],
 'caveats':[
  'SBS and VBS are in-sample descriptive statistics for these three observed outputs; no learned-selector or generalization evidence.',
  'Three 250ms runs versus PCI750 has equal nominal search allowance only; measured build/check/request CPU differs. Never compare best-of-3 to a single250ms as equal compute.',
  'Four independent coordinate group identities C1,C2,R,RC; 56 names are correlated time-window/capacity variants, not56 independent geometries.',
  'Selection CPU is recorded as0.0 by the process clock; this is below measurement resolution, not physically zero cost.',
  'Final report corrects the former169+5+5=180 wording. Actual caps sum179; known preflight0.044444159 plus report-only pass hard0.8 still totals179.844444159<180.',
  'Raw file hashes establish identity with user archive only; no official byte authentication or official lexicographic BKS gap is claimed.',
  'Freeze evidence is checked from retained chronology, source flow and immutable hashes; not an investigation of hypothetical unrecorded history.',
  'One run/configuration with wall-clock truncation provides no repeatability/noise estimate; near ties are descriptive.',
  'Distance means over valid outputs are not directly comparable when valid coverage differs, notably PCA49/56.'
 ]
}
write('audit_summary.json',result)
with (OUT/'route_replay.jsonl').open('w') as f:
    for r in replays: f.write(json.dumps(r,ensure_ascii=False,allow_nan=False)+'\n')
evidence = {
 'source_lines':{'core.py':'46-81: exact integer encoding, mandatory full-customer fixed-fleet distance-only model, original capacity/service/windows; fresh SolveWithParameters',
                 'study.py':'39-103: freeze; 105-150: full request loop and raw output; 162-209: inclusive denominators and descriptive SBS/VBS; 226-229: prepare before run',
                 'supervise.py':'1-38: single child, RLIMIT_CPU169/5, retained exit/rusage, clean archive'},
 'freeze_utc':freeze['frozen_utc'],'preflight_finished_utc':prior['finished_utc'],'run_finished_utc':resources['finished_utc'],
 'input_hashes':{m['name']:m['sha256'] for m in manifest},
 'artifact_hashes':{name:sha(data) for name,data in sorted(file_bytes.items())},
 'author_resource_receipt':receipt,
 'audit_source_sha256':sha(Path(__file__).read_bytes())
}
write('evidence.json',evidence)
lines = [
 '成熟求解器配置互补实验：独立只读核验',
 '结论：'+result['conclusion']+'。未发现改变主要实验结论的错误。' if not issues else '发现错误：'+repr(issues),
 f'56份原始存档字节、语义与完整量化矩阵hash相符；224/224请求、每实例4条、217个返回解均以本审计的独立连续坐标checker重放通过，7个PCA超时完整保留。无作者模块导入、无OR-Tools导入、无求解或安装。',
 f'事后SBS=SAVINGS250ms。平均SBS/VBS-1={statistics.mean(gaps):.6f}%，33/56例有互补改进，SBS失败救回0例。唯一赢家PCI/PCA/SAV=14/17/17，另8例并列。',
 f'实际执行best-of-3对PCI750：胜/平/负={comp["wins"]}/{comp["ties"]}/{comp["losses"]}；总距离下降{comp["total_distance_reduction_pct"]:.6f}%，逐实例相对差均值{comp["mean_instance_relative_pct"]:.6f}%。',
 f'组合请求CPU={portfolio_cpu:.9f}s，PCI750={computed_methods[3]["cpu_s"]:.9f}s，比例={cpu_ratio:.9f}。仅名义搜索预算750ms相同，不能称严格等总计算量；3×250ms也不能与单次250ms当公平算力对比。',
 '核实仅4组坐标几何：C1 9例、C2 8例、R 23例、RC 16例。56个文件不是56个独立几何。SBS/VBS仅当前同集事后描述，不能证明泛化、LLM收益或学习选择器有效。',
 '原车辆数量是最多K的上限，并非强制恰好K条非空路线。全100客户恰好服务一次；目标只有量化距离，无弃客罚项、固定车辆成本或车数优先目标。',
 '量化：1e6、距离最近整数中点向上、行驶时间ceil、服务和窗口整数精确缩放。独立50位Decimal核全矩阵与所有解目标；按原坐标检查等待、服务开始窗、容量与返仓。保守行驶取整可排除边界可行解，超时不证明连续问题不可行。',
 '冻结证据：源码、参数、规则、输入清单hash全部相符；stdout先FROZEN后224条记录。保留的首次资源设置故障在求解前发生且记录0调用；只审这些记录与代码顺序，不作未记录历史的假设调查。',
 '作者终版已明确修正：①169+5+5=179秒，加入已记录预检0.044444159秒和报表修订0.8秒硬限，总上界179.844444159秒；②选择CPU记为0只表示时钟测量未分辨出开销，选择wall约98微秒，不能解释为真实零成本。',
 'PCA的合法距离均值仅49例，不能与其他56例均值直接排优劣。一次wall-clock截断运行不提供噪声/稳定性估计。',
 '未认证官方输入字节，不计算官方车辆数优先词典序BKS gap。终包SHA256及52个成员与工作目录逐字节一致，无原始实例、venv或缓存。C2几何簇组合总距离比PCI750高约0.1502%，其他3几何簇较低，改善具有条件性。',
 f'作者含打包、澄清及已记录预检CPU={receipt["total_measured_cpu_s"]:.9f}s；首次审计CPU快照0.625338632秒，因旧50成员断言与作者52成员终包不符而仅该断言失败，初始证据保留。修正断言后本次仍为独立stdlib单进程重放，硬RLIMIT_CPU收紧到3秒，实际与累计CPU见audit_resource.json。没有重新求解。',
 '最小证据：audit.py、audit_summary.json、route_replay.jsonl、evidence.json、audit_resource.json。原实验源码定位见evidence.json。',
]
(OUT/'report_zh.txt').write_text('\n'.join(lines)+'\n')
# Captured after substantive parsing, replay, statistics, packaging verification and report writes.
usage = resource.getrusage(resource.RUSAGE_SELF)
prior_audit_cpu = json.loads((OUT/'audit_initial_resource.json').read_text())['audit_process_cpu_s']
audit_resource = {'audit_process_cpu_s':time.process_time(),'prior_audit_snapshot_cpu_s':prior_audit_cpu,'cumulative_audit_snapshot_cpu_s':prior_audit_cpu+time.process_time(),'user_s':usage.ru_utime,'system_s':usage.ru_stime,
 'wall_s':time.perf_counter()-start_wall,'hard_cpu_limit':list(resource.getrlimit(resource.RLIMIT_CPU)),
 'maxrss_kib':usage.ru_maxrss,'subprocesses_spawned':0,'solver_calls':0,'new_installs':0,
 'scope':'Entire single Python interpreter including stdlib imports, all original hashes/encoding, full217 route replays, artifact/report reads, statistics, ZIP verification and report writes; final receipt write and interpreter teardown are after snapshot.',
 'author_plus_audit_snapshot_cpu_s':receipt['total_measured_cpu_s']+prior_audit_cpu+time.process_time()}
write('audit_resource.json',audit_resource)
print(json.dumps({'conclusion':result['conclusion'],'issues':issues,'assertions':checks['assertions'],'cpu_s':audit_resource['audit_process_cpu_s'],'report':str(OUT/'report_zh.txt')},ensure_ascii=False))
if issues: raise SystemExit(1)
