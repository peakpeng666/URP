"""Frozen-order supervisor; invokes only the predeclared official CLI slots."""
import argparse
import hashlib
import importlib.util
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
APPROVED = "549c3197a5a050ab35a189b5087efb349ad000cfe6b579c3e1ed05dd4c4c8427"

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--block", type=int, choices=range(1, 5), required=True)
    args = parser.parse_args()
    data = (ROOT / "manifest.json").read_bytes()
    assert hashlib.sha256(data).hexdigest() == APPROVED
    manifest = json.loads(data)
    for path, expected in manifest["source_input_files"].items():
        raw = (ROOT / "input" / path).read_bytes()
        assert len(raw) == expected["bytes"] and hashlib.sha256(raw).hexdigest() == expected["sha256"]
    assert hashlib.sha256((ROOT / "input/generation_transfer_manifest.json").read_bytes()).hexdigest() == manifest["transfer_manifest_sha256"]
    assert hashlib.sha256((ROOT / "capture_runner.py").read_bytes()).hexdigest() == manifest["runner_sha256"]
    stop_path = ROOT.parent / "batch-stop.json"
    if stop_path.exists():
        print(json.dumps({"dispatch_blocked_by_prior_stop": True}), flush=True)
        return
    spec = importlib.util.spec_from_file_location("frozen_capture", ROOT / "capture_runner.py")
    runner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner)
    for entry in manifest["candidates"]:
        if entry["block"] != args.block:
            continue
        current = {"id": entry["id"], "block": args.block, "started_utc": datetime.now(timezone.utc).isoformat(), "state": "running"}
        (ROOT.parent / "current-slot.json").write_text(json.dumps(current) + "\n", encoding="utf-8")
        print(json.dumps({"starting_slot": entry["id"], "representation": entry["representation"], "reasoning_effort": entry["reasoning_effort"]}), flush=True)
        result = runner.run_candidate(entry["id"], APPROVED, True)
        current["state"] = "terminal"
        (ROOT.parent / "current-slot.json").write_text(json.dumps(current) + "\n", encoding="utf-8")
        summary = {key: result.get(key) for key in ("candidate_id", "model", "capture_completed_normally", "capture_succeeded", "process_exit_code", "finish_reasons", "stop_reason", "wall_clock_seconds", "response_bytes", "response_sha256", "token_usage", "tool_events", "distinct_model_message_count", "http_status_codes", "error_names")}
        print(json.dumps({"terminal_slot": summary}), flush=True)
        resource_stops = {"wall_clock_timeout", "event_capture_limit", "raw_text_capture_limit"}
        reason = result.get("stop_reason")
        material = bool(result.get("raw_error_events_omitted") or result.get("authentication_file_created") or result.get("tool_events"))
        material = material or result.get("distinct_model_message_count", 0) > 1
        material = material or (reason is not None and reason not in resource_stops)
        material = material or (result.get("process_exit_code") != 0 and reason not in resource_stops)
        if reason is None and result.get("finish_reasons") and result["finish_reasons"][-1] not in {"stop", "length"}:
            material = True
        if material:
            stop = {"halt_after_slot": entry["id"], "reason": "material_access_configuration_or_capture_infrastructure_block", "source_stop_reason": reason, "process_exit_code": result.get("process_exit_code"), "http_status_codes": result.get("http_status_codes", []), "error_names": result.get("error_names", []), "remaining_slots": "not_run", "no_retry_or_alternate_route": True}
            stop_path.write_text(json.dumps(stop, indent=2) + "\n", encoding="utf-8")
            print(json.dumps({"batch_halted": stop}), flush=True)
            return

if __name__ == "__main__":
    main()
