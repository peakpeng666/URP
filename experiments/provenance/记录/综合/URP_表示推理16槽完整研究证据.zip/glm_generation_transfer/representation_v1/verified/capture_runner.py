"""One official OpenCode invocation per frozen candidate; no model call by default.

Never persist raw error events, stderr, authentication fields, or request headers.
Successful CLI event lines and terminal part.text strings retain their bytes/content.
This is a capture harness for the official CLI, not a model API client.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import selectors
import signal
import subprocess
import tempfile
import time

ROOT = Path(__file__).resolve().parent
EVENT_LIMIT = 1_048_576
WALL_LIMIT = 900.0
RAW_TEXT_LIMIT = 262_144
MODELS = {f"slot_{i:02d}": "glm-5.3" for i in range(1, 17)}
FORBIDDEN_KEYS = {"authorization", "proxyauthorization", "headers", "requestheaders",
                  "responseheaders", "apikey", "password", "token", "secret",
                  "request", "requestbody", "requestbodyvalues"}
SAFE_EVENT_TYPES = {"text", "step_start", "step_finish"}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _has_auth_fields(value: object) -> bool:
    if isinstance(value, dict):
        for key in value:
            normalized = str(key).lower().replace("_", "").replace("-", "")
            if normalized in FORBIDDEN_KEYS:
                return True  # Do not retrieve or inspect this field's value.
            if _has_auth_fields(value[key]):
                return True
    elif isinstance(value, list):
        return any(_has_auth_fields(item) for item in value)
    return False


def capture(command: list[str], work: Path, input_path: Path, output: Path,
            *, wall_limit: float = WALL_LIMIT, event_limit: int = EVENT_LIMIT) -> dict:
    """Start exactly one subprocess and capture bounded, safe official CLI events."""
    output.mkdir(parents=True, exist_ok=False)
    report = {"logical_cli_invocations": 1, "outer_retries": 0,
              "wall_clock_limit_seconds": wall_limit, "event_byte_limit": event_limit,
              "stdout_bytes_observed": 0, "stderr_bytes_discarded": 0,
              "safe_event_bytes_saved": 0, "step_start_events": 0,
              "distinct_model_message_count": 0, "tool_events": 0,
              "http_attempt_count": "unknown", "http_attempt_upper_bound_normal_single_message": 6,
              "http_status_codes": [], "error_names": [], "finish_reasons": [],
              "token_usage": [], "stop_reason": None,
              "raw_error_events_omitted": 0, "auth_field_events_omitted": 0}
    selector = selectors.DefaultSelector()
    buffer = b""
    message_ids = set()
    texts: dict[str, str] = {}
    text_order: list[str] = []
    started = time.monotonic()
    with input_path.open("rb") as source, (output / "cli.events.ndjson").open("xb") as events:
        process = subprocess.Popen(command, cwd=work, stdin=source, stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE, start_new_session=True)
        for name, stream in (("stdout", process.stdout), ("stderr", process.stderr)):
            os.set_blocking(stream.fileno(), False)
            selector.register(stream, selectors.EVENT_READ, name)

        def terminate(reason: str) -> None:
            if report["stop_reason"] is None:
                report["stop_reason"] = reason
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass

        def handle(line: bytes) -> None:
            if report["stop_reason"] is not None:
                return
            try:
                item = json.loads(line)
            except (ValueError, UnicodeDecodeError, RecursionError):
                terminate("invalid_cli_json_event")
                return
            if not isinstance(item, dict):
                terminate("invalid_cli_event_shape")
                return
            kind = item.get("type")
            part = item.get("part", {})
            if not isinstance(part, dict):
                terminate("invalid_cli_part_shape")
                return
            message_id = part.get("messageID")
            if isinstance(message_id, str):
                message_ids.add(message_id)
                report["distinct_model_message_count"] = len(message_ids)
                if len(message_ids) > 1:
                    terminate("second_model_message")
                    return
            if kind == "error":
                report["raw_error_events_omitted"] += 1
                error = item.get("error", {})
                if isinstance(error, dict):
                    name = error.get("name")
                    if isinstance(name, str) and name.isalnum():
                        report["error_names"].append(name)
                    data = error.get("data", {})
                    if isinstance(data, dict):
                        status = data.get("statusCode")
                        if type(status) is int and 100 <= status <= 599:
                            report["http_status_codes"].append(status)
                terminate("official_cli_error")
                return  # Never write the original error line or error messages.
            if kind == "tool_use":
                report["tool_events"] += 1
                terminate("tool_event")
                return  # Tool arguments and metadata are not persisted.
            if kind not in SAFE_EVENT_TYPES:
                terminate("unexpected_cli_event_type")
                return
            try:
                forbidden = _has_auth_fields(item)
            except RecursionError:
                terminate("invalid_cli_event_nesting")
                return
            if forbidden:
                report["auth_field_events_omitted"] += 1
                terminate("forbidden_auth_or_request_field")
                return
            if kind == "step_start":
                report["step_start_events"] += 1
                if report["step_start_events"] > 6:
                    terminate("step_start_event_budget")
            elif kind == "step_finish":
                reason = part.get("reason")
                if reason in {"stop", "length", "tool-calls", "unknown", "error", "content-filter"}:
                    report["finish_reasons"].append(reason)
                tokens = part.get("tokens")
                if isinstance(tokens, dict):
                    usage = {key: tokens[key] for key in ("input", "output", "reasoning")
                             if type(tokens.get(key)) in (int, float)}
                    cache = tokens.get("cache")
                    if isinstance(cache, dict):
                        usage["cache"] = {key: cache[key] for key in ("read", "write")
                                          if type(cache.get(key)) in (int, float)}
                    report["token_usage"].append(usage)
                if reason in {"tool-calls", "unknown"}:
                    terminate("tool_or_unknown_finish")
            elif kind == "text":
                text, part_id = part.get("text"), part.get("id")
                if not isinstance(text, str) or not isinstance(part_id, str):
                    terminate("invalid_terminal_text_part")
                    return
                accumulated_bytes = sum(len(value.encode("utf-8")) for key, value in texts.items() if key != part_id)
                if accumulated_bytes + len(text.encode("utf-8")) > RAW_TEXT_LIMIT:
                    terminate("raw_text_capture_limit")
                    return
                if part_id not in texts:
                    text_order.append(part_id)
                elif texts[part_id] != text:
                    terminate("terminal_text_changed")
                    return
                texts[part_id] = text  # No trim, repair, Markdown removal, or JSON parsing.
            if report["safe_event_bytes_saved"] + len(line) > event_limit:
                terminate("event_capture_limit")
                return
            events.write(line)
            report["safe_event_bytes_saved"] += len(line)

        while selector.get_map():
            remaining = wall_limit - (time.monotonic() - started)
            if remaining <= 0:
                terminate("wall_clock_timeout")
            for key, _ in selector.select(timeout=max(0.0, min(0.05, remaining))):
                allowance = event_limit - report["stdout_bytes_observed"]
                read_size = 65536 if key.data == "stderr" else max(1, min(65536, allowance + 1))
                try:
                    chunk = os.read(key.fileobj.fileno(), read_size)
                except BlockingIOError:
                    continue
                if not chunk:
                    if key.data == "stdout" and buffer:
                        handle(buffer)
                        buffer = b""
                    selector.unregister(key.fileobj)
                    continue
                if key.data == "stderr":
                    report["stderr_bytes_discarded"] += len(chunk)
                    continue
                report["stdout_bytes_observed"] += len(chunk)
                if report["stdout_bytes_observed"] > event_limit:
                    terminate("event_capture_limit")
                    buffer = b""
                    selector.unregister(key.fileobj)
                    continue
                buffer += chunk
                while b"\n" in buffer:
                    line, buffer = buffer.split(b"\n", 1)
                    handle(line + b"\n")
            if time.monotonic() - started > wall_limit + 1.0:
                break
        process.wait(timeout=2)
    selector.close()
    text_bytes = "".join(texts[key] for key in text_order).encode("utf-8")
    (output / "response.txt").write_bytes(text_bytes)
    report.update({"process_exit_code": process.returncode,
                   "wall_clock_seconds": round(time.monotonic() - started, 6),
                   "response_bytes": len(text_bytes), "response_sha256": sha256(text_bytes),
                   "response_exceeds_32768_bytes": len(text_bytes) > 32768,
                   "response_is_unmodified_cli_terminal_text": True,
                   "response_is_raw_http": False,
                   "capture_completed_normally": process.returncode == 0 and report["stop_reason"] is None,
                   "capture_succeeded": process.returncode == 0 and report["stop_reason"] is None
                       and len(message_ids) == 1 and bool(text_bytes)
                       and bool(report["finish_reasons"])
                       and report["finish_reasons"][-1] in {"stop", "length"}})
    (output / "metadata.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    return report


def run_candidate(candidate: str, approved_manifest_sha256: str,
                  acknowledge_native_context: bool) -> dict:
    manifest_bytes = (ROOT / "manifest.json").read_bytes()
    if sha256(manifest_bytes) != approved_manifest_sha256:
        raise SystemExit("Approved manifest hash mismatch; no CLI started")
    if not acknowledge_native_context:
        raise SystemExit("Native client context boundary not acknowledged; no CLI started")
    manifest = json.loads(manifest_bytes)
    if manifest["status"] != "prepared_not_executed":
        raise SystemExit("Preparation status mismatch; no CLI started")
    if sha256(Path(__file__).read_bytes()) != manifest["runner_sha256"]:
        raise SystemExit("Runner differs from frozen manifest; no CLI started")
    index = [entry["id"] for entry in manifest["candidates"]].index(candidate)
    entry = manifest["candidates"][index]
    if entry["model"] != MODELS[candidate]:
        raise SystemExit("Frozen model order mismatch; no CLI started")
    prompt = ROOT / entry["prompt_path"]
    config_source = ROOT / entry["config_path"]
    if sha256(prompt.read_bytes()) != entry["prompt_sha256"]:
        raise SystemExit("Frozen prompt differs; no CLI started")
    if sha256(config_source.read_bytes()) != entry["config_sha256"]:
        raise SystemExit("Frozen config differs; no CLI started")
    runs = ROOT.parent / "runs"
    runs.mkdir(exist_ok=True)
    for prior in manifest["candidates"][:index]:
        if not (runs / prior["id"] / "capture" / "metadata.json").is_file():
            raise SystemExit("Previous slot has not terminated; no CLI started")
    slot = runs / candidate
    slot.mkdir(exist_ok=False)  # Permanent one-slot claim; never retry or replace a claimed slot.
    temporary_state = tempfile.TemporaryDirectory(prefix="urp-math-" + candidate + "-")
    runtime = Path(temporary_state.name)
    for name in ("work", "config", "xdg-config", "xdg-data", "xdg-cache", "xdg-state"):
        (runtime / name).mkdir()
    config = runtime / "config" / "opencode.json"
    config.write_bytes(config_source.read_bytes())
    settings = {"XDG_CONFIG_HOME": str(runtime / "xdg-config"),
                "XDG_DATA_HOME": str(runtime / "xdg-data"),
                "XDG_CACHE_HOME": str(runtime / "xdg-cache"),
                "XDG_STATE_HOME": str(runtime / "xdg-state"),
                "PWD": str(runtime / "work"), "OPENCODE_CONFIG_DIR": str(runtime / "config"),
                "OPENCODE_CONFIG": str(config), "OPENCODE_DISABLE_AUTOUPDATE": "true",
                "OPENCODE_DISABLE_MODELS_FETCH": "true",
                "OPENCODE_DISABLE_DEFAULT_PLUGINS": "true",
                "OPENCODE_DISABLE_CLAUDE_CODE": "true",
                "OPENCODE_DISABLE_PROJECT_CONFIG": "true",
                "OPENCODE_DISABLE_AUTOCOMPACT": "true",
                "OPENCODE_DISABLE_LSP_DOWNLOAD": "true",
                "OPENCODE_EXPERIMENTAL_DISABLE_FILEWATCHER": "true"}
    binary = Path(manifest["installed_binary"])
    # Enumerate names only; never retrieve inherited credential/configuration values.
    cleared = [argument for name in sorted(os.environ) if name.startswith("OPENCODE_")
               for argument in ("-u", name)]
    command = ["env", *cleared, *(f"{key}={value}" for key, value in settings.items()), str(binary),
               "--log-level", "ERROR", "--pure", "run", "--dir", str(runtime / "work"),
               "--agent", "candidate", "--model", "zhipuai-coding-plan/" + entry["model"],
               "--title", candidate, "--format", "json"]  # Prompt is only stdin, no message argv.
    try:
        report = capture(command, runtime / "work", prompt, slot / "capture")
    except Exception as error:
        report = {"capture_succeeded": False, "stop_reason": "capture_or_launch_exception",
                  "error_type": type(error).__name__, "process_exit_code": None,
                  "http_attempt_count": "unknown", "logical_cli_invocations": 1, "outer_retries": 0}
        if isinstance(error, OSError):
            report["error_errno"] = error.errno
        (slot / "capture").mkdir(exist_ok=True)
        if not (slot / "capture/response.txt").exists():
            (slot / "capture/response.txt").write_bytes(b"")
    report.update({"research_id": manifest["research_id"],
                   "research_freeze_sha256": manifest["research_freeze_sha256"],
                   "candidate_id": candidate, "model": entry["model"],
                   "provider": "zhipuai-coding-plan", "cli_version": "1.18.34",
                   "prompt_sha256": entry["prompt_sha256"],
                   "configuration_sha256": entry["config_sha256"],
                   "temperature": 0.7, "top_p": 0.9, "seed": "uncontrolled",
                   "max_output_tokens": 32000,
                   "steps": 2, "model_options": entry["model_options"],
                   "explicit_variant": None, "output_token_flag_override": None,
                   "raw_text_byte_limit": RAW_TEXT_LIMIT,
                   "settings_provenance": "configured_metadata_not_observed_HTTP",
                   "capture_truncated": report.get("stop_reason") in {"event_capture_limit", "raw_text_capture_limit", "wall_clock_timeout"},
                   "external_opencode_override_variables_cleared": len(cleared) // 2,
                   "authentication_file_created": any((runtime / "xdg-data").rglob("auth.json"))})
    if report["authentication_file_created"]:
        report["capture_succeeded"] = False
        report["stop_reason"] = report["stop_reason"] or "unexpected_authentication_file"
    # Remove all client state, including logs/databases, without reading their contents.
    temporary_state.cleanup()
    report["temporary_cli_state_removed"] = True
    (slot / "capture/metadata.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate", choices=MODELS, required=True)
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--approved-manifest-sha256")
    parser.add_argument("--acknowledge-native-client-context", action="store_true")
    args = parser.parse_args()
    if not args.execute or not args.approved_manifest_sha256:
        parser.error("Execution is disabled without explicit approval and the frozen manifest hash")
    result = run_candidate(args.candidate, args.approved_manifest_sha256,
                           args.acknowledge_native_client_context)
    print(json.dumps(result))


if __name__ == "__main__":
    main()
