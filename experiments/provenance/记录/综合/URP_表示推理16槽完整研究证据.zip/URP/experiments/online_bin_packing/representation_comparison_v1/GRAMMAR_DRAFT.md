# Restricted Python surface grammar, written before adapter implementation
Status: draft for parent review; no generation authorized or initiated.

This is static AST lowering to math-dag-v1, not execution or a Python sandbox.
Generated input is never executed, evaluated, compiled to bytecode, imported, or used as a module.
Python ast.parse is used solely to obtain data nodes (internally Python's parser may use its AST-only compiler implementation); no application call to compile/eval/exec is permitted.

## Exact surface
One module containing exactly `def score(item, bins):` with no decorator, annotations,
defaults, positional-only, keyword-only, variadic or type parameters. The first statement
must be a string-literal docstring holding the nonempty one-line public algorithm description.
Then zero or more simple, fresh local-name assignments, followed by exactly one final return.
Names must be ASCII identifiers, may not start with underscore, and cannot shadow score,
item, bins, or the eight operator names. No reassignment, multiple targets or destructuring.
References can use only item, bins, or previously assigned local names.

Expressions: finite int/float literals (absolute value <=1000, bool excluded); unary minus
on a numeric literal only; references; binary +, -, *, /; a single > comparison;
and unqualified positional-only calls add(a,b), sub(a,b), mul(a,b), div(a,b),
exp(a), sqrt(a), gt(a,b), where(condition,a,b), exactly those arities.
Nested expressions lower left to right in postorder. Assignments preserve statement order;
node references/aliases do not add operations. Typed constants are interned by (type,value),
with float bit representation retaining signed zero. Explicit constant assignments count even
if unused. No constant folding, algebraic simplification, node merging, dead-node removal,
implicit cast, or automatic root promotion. Literal 1 is i32; literal 1.0 is f64.
Every operator becomes one unchanged IR operation. Return must resolve to an existing vf64
node, never a scalar, bins input, integer-vector root, or constant.

All unlisted AST forms are rejected, including imports, attributes (np.exp included),
subscripts, comprehensions, lambdas, arbitrary calls, keywords, starred arguments, loops,
if/conditional expressions, boolean operators, chained comparisons, power, strings outside
the description, nested functions/classes, async/yield/await, global/nonlocal, exception
handling, context managers, and expression statements. Lexical comments are permitted.
Source cap 32768 UTF-8 bytes; AST cap 4096 nodes; expression depth cap 128; at most64
lowered operations and16 typed constants. These adapter-only parser caps are disclosed;
they cannot exclude any canonical straight-line rendering of a valid64-node DAG.

## Shared semantic restrictions, intentionally retained
Both arms use unmodified validator and interpreter, i32 item, vi64 feasible bins;
scalar-vector broadcasting only; gt must produce vb; where requires vb and floating
branches, and evaluates both eagerly; integer bound1e6; final finite vf64 vector;
maximum64 operations/16 constants. No reduction/index/state. Intermediate nonfinite
float nodes have precisely existing interpreter behavior (counted, not universally rejected).
The artificial float-root and floating-where constraints are a known typing bias.
BF expressed as item-bins alone is rejected in BOTH arms; a deliberate floating constant
such as 0.0-bins is needed. Do not silently change both arms while claiming old semantics.

## Acceptance / extraction
Strict metric: entire stripped response is a raw payload or exactly one lower-case
json/python fenced payload, without external prose. Unique-block metric: strict successes,
or exactly one complete correct-language fenced block surrounded by prose and no other
fence marker; no recovery from truncated fences, multiple blocks, or arbitrary JSON fragments.
Python description is function docstring; DAG description is JSON description field.
No repair or quality-based extraction/selection. Both metrics use the same adapter/validator.

## Parent-reviewed grammar amendment (2026-10-05, before amendment implementation)
Permit an optional exact leading `import numpy as np` AST (one imported name, exact alias).
It is never executed and adds no operation. With that declaration only, permit calls to
np.exp, np.sqrt, np.where, np.greater with exact positional arities, mapped respectively
to exp/sqrt/where/gt. No other import, attribute or call is permitted; np is reserved.
This overrides the earlier blanket no-import/no-attribute clause, without expanding
the mathematical space, changing types, adding casts, or repairing candidate output.
