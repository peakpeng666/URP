"""Seal reviewed offline inputs only; never authorize or perform model dispatch."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import sys
import zipfile

HERE=Path(__file__).resolve().parent
BASE=HERE.parent

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--scorer-ready', action='store_true', required=True,
                        help='Use only after scoring worker explicitly reports source/tests ready.')
    args=parser.parse_args()
    if (HERE/'freeze.json').exists(): raise RuntimeError('Freeze exists; no overwrite')
    required=['protocol.json','order.json','adapter.py','GRAMMAR_DRAFT.md','runner_contract.json',
              'official_support_notes.json','client_budget_evidence.json','source_hashes.json',
              'test_adapter.py','test_results.json','prepare_final.py','preflight.py',
              'seal_preparation.py','scoring_admission.py','score_run.py','score_audit.py',
              'score_report.py','test_scoring.py','SCORING_CONTRACT.json','score_tests_results.json',
              'controls/bf.python.txt','controls/bf.dag.json','controls/eoh.python.txt',
              'controls/eoh_numpy.python.txt','controls/eoh.dag.json',
              'controls/increasing_slack.python.txt','controls/increasing_slack.dag.json','scoring_preflight.json',
              'PRE_DISPATCH_REVISION.json','revisions/pre_dispatch_r1_superseded/backup_manifest.json',
              'revisions/pre_dispatch_r1_superseded/freeze.json','revisions/pre_dispatch_r1_superseded/exact_source_backup.zip']
    for name in required:
        if not (HERE/name).is_file(): raise RuntimeError('Missing '+name)
    p=json.loads((HERE/'protocol.json').read_text())
    order=json.loads((HERE/'order.json').read_text())
    assert len(order['slots'])==16 and p['generation_slots']==order['slots']
    assert p['generation']['max_completion_tokens']==32000
    assert p['budget']['aggregate_numerical_cpu_seconds']==1800
    assert p['budget']['aggregate_numerical_active_wall_seconds']==2700
    evaluator=BASE/'paper_scale_dag_evaluator_v1/freeze.json'
    assert sha(evaluator)==p['scoring']['runner_freeze_sha256']
    ef=json.loads(evaluator.read_text())
    ready=json.loads((HERE/'scoring_preflight.json').read_text())
    tests=json.loads((HERE/'score_tests_results.json').read_text())
    assert ready['ready_for_joint_refreeze'] is True and tests['passed'] is True and tests['test_methods']==26
    assert ready['actual16slot_generation_calls']==0 and ready['actual16slot_candidate_scores']==0
    hashes=dict(ef['sha256'])
    hashes.update(ready['source_sha256'])
    hashes.update(tests['source_sha256'])
    hashes[str(evaluator.resolve())]=sha(evaluator)
    for path,digest in json.loads((HERE/'source_hashes.json').read_text())['sha256'].items():
        path=Path(path)
        if not path.is_absolute(): path=HERE.parents[3]/path
        hashes[str(path.resolve())]=digest
    files=[HERE/name for name in required]+list((HERE/'controls').glob('*'))+[HERE/x['prompt_file'] for x in order['slots']]
    for panel in ['main5000','development256','validation256']:
        prefix='design5000_historical_design_5k' if panel=='main5000' else 'regression256_'+('development' if panel=='development256' else 'validation')
        for i in range(5):
            for method in ['BF','EOH']:
                f=BASE/f'paper_scale_dag_evaluator_v1/results/{prefix}_{i}_{method}.observation.json'
                if not f.is_file(): raise RuntimeError('Missing saved baseline '+str(f))
                files.append(f)
    for rel in ['programs/BF.json','programs/EOH.json','data/design_5000.json','data/regression_development_256.json','data/regression_validation_256.json']:
        files.append(BASE/'paper_scale_dag_evaluator_v1'/rel)
    files += [Path(sys.executable).resolve()]
    for path in files:
        if path.is_file(): hashes[str(path.resolve())]=sha(path)
    for path,digest in hashes.items():
        if sha(path)!=digest: raise RuntimeError('Dependency changed: '+path)
    freeze={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'status':'offline_preparation_frozen_no_model_dispatch_authorization',
            'pre_dispatch_revision':p.get('pre_dispatch_revision'),
            'new_model_calls':0,'generated_candidate_scoring_started':False,
            'offline_fixed_control_tests_completed':True,
            'preparation_and_orchestration_cost':'Separately unmetered, not zero',
            'original_math_freeze_sha256':ef['original_math_freeze_sha256'],
            'evaluator_freeze_sha256':sha(evaluator),
            'python_executable':str(Path(sys.executable).resolve()),
            'sha256':dict(sorted(hashes.items()))}
    with (HERE/'freeze.json').open('x') as f: json.dump(freeze,f,indent=2);f.write('\n')
    transfer_files=[HERE/'protocol.json',HERE/'order.json']+[HERE/s['prompt_file'] for s in order['slots']]
    manifest={'status':'inputs_frozen_root_dispatch_authorization_still_required',
              'identity':p['identity'],'preparation_freeze_sha256':sha(HERE/'freeze.json'),
              'files':{str(f.relative_to(HERE)):{'sha256':sha(f),'bytes':f.stat().st_size} for f in transfer_files}}
    (HERE/'generation_transfer_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    with zipfile.ZipFile(HERE/'generation_transfer.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
        for path in transfer_files+[HERE/'generation_transfer_manifest.json']:
            info=zipfile.ZipInfo(str(path.relative_to(HERE)),date_time=(2026,10,5,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o644 << 16
            z.writestr(info,path.read_bytes())
    print(json.dumps({'freeze_sha256':sha(HERE/'freeze.json'),'files':len(hashes),
                      'protocol_sha256':sha(HERE/'protocol.json'),
                      'transfer_zip_sha256':sha(HERE/'generation_transfer.zip'),
                      'model_dispatch_authorized':False},indent=2))

if __name__=='__main__':main()
