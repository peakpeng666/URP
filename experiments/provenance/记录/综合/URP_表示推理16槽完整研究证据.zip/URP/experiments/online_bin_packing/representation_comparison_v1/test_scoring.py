"""Synthetic metadata/mocked scheduling and three trusted handwritten smoke controls.
No new model requests, no actual16-slot candidate fitness, no private reasoning.
"""
import time
START=time.monotonic()
import argparse,base64,copy,hashlib,io,json,pathlib,resource,sys,tempfile,unittest
from unittest.mock import patch
import scoring_admission as A
import score_run as S
ROOT=pathlib.Path(__file__).resolve().parent;BASE=ROOT.parent
ADAPTER=A.mod('test_only_static_adapter',ROOT/'adapter.py')
GEN={'temperature':0.7,'top_p':0.9,'max_completion_tokens':32000,'wall_seconds_per_slot':900,'client':{'steps':2,'cli_version':'1.18.34'}}
SLOTS=A.json_load(ROOT/'order.json')['slots'];SMOKE={}
PRIOR_BUDGET=A.json_load(ROOT/'scoring_test_artifacts/attempt_002/final_score_tests_results.json')['budget']
FIXTURES=ROOT/'scoring_test_artifacts/real_capture_fixtures'
def from_real_metadata(m):
 return {'status':'generation_failed','cli_exit_code':m['process_exit_code'],'capture_completed_normally':m['capture_completed_normally'],'capture_succeeded':m['capture_succeeded'],'tool_events':m['tool_events'],'model_messages':m['distinct_model_message_count'],'capture_truncated':m.get('capture_truncated',False),'finish_reasons':m['finish_reasons'],'stop_reason':m['stop_reason']}

def digest(b):return hashlib.sha256(b).hexdigest()
def record(slot,prompt_hash='a'*64):
 return {'id':f"slot_{slot['slot']:02d}",'slot':slot['slot'],'block':slot['block'],'representation':slot['representation'],'model_id':slot['model'],'prompt_sha256':prompt_hash,'cli_version':'1.18.34','terminal':True,'status':'completed','configured':{'reasoning_effort':slot['reasoning_effort'],'temperature':0.7,'top_p':0.9,'max_completion_tokens':32000,'wall_seconds':900,'steps':2,'tools':False,'outer_retries':0},'settings_provenance':'configured_metadata_not_observed_HTTP','physical_http_attempts_observed':None,'sampling_seed':None,'logical_cli_requests':1,'payload_provenance':'OpenCode JSON part.text','configuration_sha256':'c'*64,'cli_exit_code':0,'capture_completed_normally':True,'capture_succeeded':True,'tool_events':0,'model_messages':1,'capture_truncated':False,'finish_reasons':['stop'],'stop_reason':None}
def metadata(rec,raw):
 return {'model':rec['model_id'],'prompt_sha256':rec['prompt_sha256'],'cli_version':rec['cli_version'],'configuration_sha256':rec['configuration_sha256'],'response_sha256':digest(raw),'response_bytes':len(raw),'process_exit_code':rec['cli_exit_code'],'capture_completed_normally':rec['capture_completed_normally'],'capture_succeeded':rec['capture_succeeded'],'tool_events':rec['tool_events'],'distinct_model_message_count':rec['model_messages'],'finish_reasons':rec['finish_reasons'],'stop_reason':rec['stop_reason'],'logical_cli_invocations':rec['logical_cli_requests'],'temperature':.7,'top_p':.9,'max_output_tokens':32000,'wall_clock_limit_seconds':900,'steps':2,'outer_retries':0,'model_options':{'reasoningEffort':rec['configured']['reasoning_effort']},'response_is_unmodified_cli_terminal_text':True,'response_is_raw_http':False,'http_attempt_count':'unknown','seed':'uncontrolled','capture_truncated':rec['capture_truncated']}
def simple_raw(rep):return (ROOT/'controls'/('bf.dag.json' if rep=='dag' else 'bf.python.txt')).read_bytes()
def reseal_obs(obs):
 raw=json.dumps(obs['result'],separators=(',',':'),allow_nan=False).encode();obs['raw_stdout_base64']=base64.b64encode(raw).decode();obs['raw_output_bytes']=len(raw);obs['raw_output_sha256']=digest(raw)

class AdmissionTests(unittest.TestCase):
 def test_real_old_empty_length_metadata_preserved_and_rejected_only_structurally(self):
  p=FIXTURES/'empty_length.metadata.json';before=p.read_bytes();m=A.json_load(p);raw=(FIXTURES/'empty_length.response.txt').read_bytes()
  self.assertFalse(m['capture_succeeded']);self.assertTrue(m['capture_completed_normally']);self.assertEqual(m['response_bytes'],0);self.assertEqual(m['finish_reasons'],['length']);self.assertEqual(digest(raw),m['response_sha256'])
  r=from_real_metadata(m);self.assertEqual(A.capture_category(r),'generation_length');r['status']='completed';self.assertEqual(A.capture_category(r),'generation_length')
  rows,candidate=A.admit_both(raw,'dag',ADAPTER);self.assertIsNone(candidate);self.assertNotEqual(rows['unique_block']['status'],'admitted');self.assertEqual(p.read_bytes(),before)
 def test_real_old_nonempty_stop_metadata_and_program(self):
  m=A.json_load(FIXTURES/'nonempty_stop.metadata.json');raw=(FIXTURES/'nonempty_stop.response.txt').read_bytes();self.assertTrue(m['capture_succeeded']);self.assertEqual(digest(raw),m['response_sha256']);self.assertEqual(A.capture_category(from_real_metadata(m)),'normal_stop');rows,p=A.admit_both(raw,'dag',ADAPTER);self.assertEqual(rows['strict']['status'],'admitted');self.assertIsNotNone(p)
 def test_existing_original_capture_harness_eight_results_reused(self):
  evidence=A.json_load(FIXTURES/'existing_capture_harness_results.json');self.assertEqual(len(evidence['results']),8)
  for case in evidence['results']:
   m=case['metadata'];expected='normal_stop' if m['finish_reasons']==['stop'] else 'generation_length';self.assertEqual(A.capture_category(from_real_metadata(m)),expected)
   if case['name']=='reasoning_only_length':self.assertFalse(m['capture_succeeded']);self.assertEqual(m['response_bytes'],0)
 def test_stop_and_length_are_distinct_but_intact(self):
  slot=SLOTS[0];r=record(slot);self.assertEqual(A.validate_capture_record(r,slot,'a'*64,GEN),'normal_stop');r['finish_reasons']=['length'];r['status']='generation_failed';self.assertEqual(A.validate_capture_record(r,slot,'a'*64,GEN),'generation_length')
 def test_capture_failure_cannot_be_rescued(self):
  slot=SLOTS[0]
  for field,value in [('capture_truncated',True),('capture_completed_normally',False),('tool_events',1),('model_messages',2),('stop_reason','event_byte_limit')]:
   r=record(slot);r['status']='generation_failed';r[field]=value;self.assertEqual(A.validate_capture_record(r,slot,'a'*64,GEN),'capture_or_generation_failed')
 def test_success_envelope_contradiction_is_infrastructure(self):
  slot=SLOTS[0];r=record(slot);r['model_messages']=2
  with self.assertRaises(A.Infrastructure):A.validate_capture_record(r,slot,'a'*64,GEN)
 def test_conditions_and_seed_binding(self):
  slot=SLOTS[0]
  for field,value in [('model_id','other'),('prompt_sha256','b'*64),('physical_http_attempts_observed',1),('sampling_seed',17),('settings_provenance','observed_HTTP')]:
   r=record(slot);r[field]=value
   with self.assertRaises(A.Infrastructure):A.validate_capture_record(r,slot,'a'*64,GEN)
  r=record(slot);r['configured']['max_completion_tokens']=32768
  with self.assertRaises(A.Infrastructure):A.validate_capture_record(r,slot,'a'*64,GEN)
 def test_both_metrics_same_payload(self):
  for rep in ['dag','python']:
   raw=simple_raw(rep);rows,c=A.admit_both(raw,rep,ADAPTER);self.assertEqual(rows['strict']['status'],'admitted');self.assertEqual(rows['strict']['payload_sha256'],rows['unique_block']['payload_sha256']);self.assertIsNotNone(c)
 def test_complete_block_prose_allowed_unique_only(self):
  for rep in ['dag','python']:
   language='json' if rep=='dag' else 'python';raw=(f'```{language}\n'.encode()+simple_raw(rep).rstrip()+b'\n```\nExplanation after the complete block.')
   rows,c=A.admit_both(raw,rep,ADAPTER);self.assertEqual(rows['strict']['status'],'extraction_rejected');self.assertEqual(rows['unique_block']['status'],'admitted')
 def test_no_partial_fence_json_or_multiple_answer_recovery(self):
  for raw in [b'{"schema":',b'```json\n'+simple_raw('dag'),b'```json\n'+simple_raw('dag').rstrip()+b'\n```\n```json\n{}\n```']:
   rows,c=A.admit_both(raw,'dag',ADAPTER);self.assertIsNone(c);self.assertNotEqual(rows['unique_block']['status'],'admitted')
 def test_empty_terminal_is_structural_missing_not_infrastructure(self):
  for rep in ['dag','python']:
   rows,c=A.admit_both(b'',rep,ADAPTER);self.assertIsNone(c);self.assertNotEqual(rows['unique_block']['status'],'admitted')
 def test_source_metadata_crosscheck(self):
  rec=record(SLOTS[0]);raw=simple_raw(SLOTS[0]['representation']);rec['raw_text_sha256']=digest(raw);m=metadata(rec,raw);A.crosscheck_metadata(m,rec,raw)
  m['max_output_tokens']=32768
  with self.assertRaises(A.Infrastructure):A.crosscheck_metadata(m,rec,raw)
 def test_prepare_16_slots_zero_fitness_with_length_empty_and_capture_failure(self):
  with tempfile.TemporaryDirectory(prefix='p3_scoring_mock_') as td:
   root=pathlib.Path(td);slots=copy.deepcopy(SLOTS);records=[]
   for slot in slots:
    prompt=root/slot['prompt_file'];prompt.parent.mkdir(parents=True,exist_ok=True);prompt.write_text('HANDWRITTEN TEST PROMPT '+str(slot['slot']))
    rec=record(slot,A.sha(prompt));rep=slot['representation'];raw=simple_raw(rep)
    if slot['slot']==2:
     rec['status']='generation_failed';rec['finish_reasons']=['length'];raw=(('```json\n' if rep=='dag' else '```python\n').encode()+raw.rstrip()+b'\n```\nExtra prose')
    if slot['slot']==3:rec['status']='generation_failed';rec['finish_reasons']=['length'];rec['capture_succeeded']=False;raw=b''
    if slot['slot']==4:rec['status']='generation_failed';rec['capture_truncated']=True;rec['capture_completed_normally']=False;rec['stop_reason']='watchdog'
    text=root/(rec['id']+'.txt');text.write_bytes(raw);rec['raw_text_path']=str(text);rec['raw_text_sha256']=digest(raw)
    meta=root/(rec['id']+'.metadata.json');A.save(meta,metadata(rec,raw));rec['metadata_path']=str(meta);rec['metadata_sha256']=A.sha(meta);records.append(rec)
   A.save(root/'protocol.json',{'generation':GEN,'design':{'order_file':'order.json'}});A.save(root/'order.json',{'slots':slots});A.save(root/'input.json',{'records':records})
   with patch.object(A,'ROOT',root),patch.object(A,'verify_freeze',return_value={}),patch.object(A,'mod',return_value=ADAPTER):
    result=A.prepare(root/'input.json',A.sha(root/'input.json'),'f'*64,root/'out')
   self.assertEqual(result['score_calls'],0);self.assertEqual(result['strict_admitted'],13);self.assertEqual(result['unique_admitted'],14)
   rows=A.json_load(root/'out/preparation/admissions.json');self.assertEqual(rows[1]['generation_status'],'generation_length');self.assertEqual(rows[2]['raw_text_bytes'],0);self.assertEqual(rows[2]['generation_status'],'generation_length');self.assertEqual(rows[3]['generation_status'],'capture_or_generation_failed')
   seal=A.json_load(root/'out/preparation_seal.json');self.assertTrue(all(A.sha(p)==h for p,h in seal['prepared_file_sha256'].items()))

class SchedulingTests(unittest.TestCase):
 def test_240_rows_main_before_diagnostics(self):
  rows=S.fresh_ledger();self.assertEqual(len(rows),240);self.assertTrue(all(x['panel']=='main5000' for x in rows[:80]));self.assertEqual([x['slot'] for x in rows[:16]],list(range(1,17)))
 def test_reservation_inclusive_boundary(self):
  c=[0.];w=[0.];b=S.Budget(clock=lambda:w[0],cpu=lambda:c[0]);c[0]=1697;w[0]=2567;self.assertTrue(b.reserve());c[0]=1698;self.assertFalse(b.reserve());c[0]=0;w[0]=2568;self.assertFalse(b.reserve())
 def test_budget_stop_preserves_all_rows(self):
  class B:
   count=0
   def reserve(self):self.count+=1;return self.count<=2
  rows=S.fresh_ledger();n,halt=S.schedule(rows,{f'slot_{i:02d}':b'X' for i in range(1,17)},B(),lambda *_:{},lambda *_:{'status':'feasible','reason':None},lambda *_:None)
  self.assertEqual((n,halt),(2,'budget'));self.assertEqual(sum(x['status']=='not_run' for x in rows),238)
 def test_infrastructure_halts_not_algorithm_quality(self):
  def dispatch(*_):raise A.Infrastructure('mock source change')
  rows=S.fresh_ledger();n,halt=S.schedule(rows,{'slot_01':b'X'},type('B',(),{'reserve':lambda _:True})(),dispatch,lambda *_:{},lambda *_:None)
  self.assertEqual((n,halt),(1,'infrastructure'));self.assertEqual(rows[0]['status'],'infrastructure_failure');self.assertEqual(rows[16]['reason'],'stopped_infrastructure')
 def test_numeric_failure_does_not_drop_later_panels(self):
  rows=S.fresh_ledger();n,halt=S.schedule(rows,{'slot_01':b'X'},type('B',(),{'reserve':lambda _:True})(),lambda *_:{},lambda row,*_:{'status':'numeric_invalid' if row['panel']=='main5000' else 'feasible','reason':None},lambda *_:None)
  self.assertEqual((n,halt),(15,None));self.assertEqual(sum(x['status']=='numeric_invalid' for x in rows),5);self.assertEqual(sum(x['status']=='feasible' for x in rows),10)
 def test_identical_programs_across_slots_are_not_cached(self):
  rows=S.fresh_ledger();n,_=S.schedule(rows,{'slot_01':b'X','slot_02':b'X'},type('B',(),{'reserve':lambda _:True})(),lambda *_:{},lambda *_:{'status':'feasible','reason':None},lambda *_:None);self.assertEqual(n,30)
 def test_static_mismatch_and_undetermined_pass_review_gate(self):
  aa=[{'id':f'slot_{i:02d}','unique_block':{'status':'admitted'},'capture':{'raw_text_sha256':'a'*64},'payload_sha256':'b'*64} for i in range(1,17)]
  review={'preparation_seal_sha256':'c'*64,'reviewer_identity':'independent_synthetic_test_reviewer','independent_of_candidate_fitness':True,'policy_execution_performed':False,'review_scope':'public_description_and_static_code_only','records':[{'id':a['id'],'raw_text_sha256':'a'*64,'payload_sha256':'b'*64,'classification':'mismatch' if i%2 else 'undetermined','rationale':'Synthetic static review; not a real model candidate'} for i,a in enumerate(aa)]}
  with tempfile.TemporaryDirectory() as td:
   p=pathlib.Path(td)/'review.json';A.save(p,review);self.assertEqual(len(S.review_gate(p,A.sha(p),'c'*64,aa)['records']),16)
 def test_resource_limits_are_not_quality_failures(self):
  raw=(ROOT/'controls/bf.dag.json').read_bytes();obs={'reaped':True,'cpu_evidence_complete':True,'error':None,'termination':'wall_timeout','worker_cpu_seconds':1.,'wall_seconds':90.,'worker_peak_rss_kib':20000}
  self.assertEqual(S.checked(raw,[1],obs)['status'],'resource_unresolved');obs.update(termination=None,returncode=-9);self.assertEqual(S.checked(raw,[1],obs)['status'],'resource_unresolved');obs['reaped']=False
  with self.assertRaises(A.Infrastructure):S.checked(raw,[1],obs)

class SmokeObservationTests(unittest.TestCase):
 def test_three_handwritten_controls_valid(self):
  self.assertEqual(set(SMOKE),{'bf','eoh','increasing_slack'})
  for m,(raw,items,obs) in SMOKE.items():self.assertEqual(S.checked(raw,items,obs)['status'],'feasible')
 def test_raw_digest_corruption_rejected(self):
  raw,items,obs=SMOKE['bf'];bad=copy.deepcopy(obs);bad['raw_output_sha256']='0'*64
  with self.assertRaises(A.Infrastructure):S.checked(raw,items,bad)
 def test_fake_bin_claim_checker_rejected(self):
  raw,items,obs=SMOKE['bf'];bad=copy.deepcopy(obs);bad['result']['result']['used_bins']+=1;reseal_obs(bad);self.assertEqual(S.checked(raw,items,bad)['status'],'checker_rejected')
 def test_work_accounting_corruption_halts(self):
  raw,items,obs=SMOKE['bf'];bad=copy.deepcopy(obs);bad['result']['work_units']+=1;bad['result']['result']['work_units']+=1;reseal_obs(bad)
  with self.assertRaises(A.Infrastructure):S.checked(raw,items,bad)
 def test_effective_limit_mismatch_halts(self):
  raw,items,obs=SMOKE['bf'];bad=copy.deepcopy(obs);bad['result']['limits']['RLIMIT_CPU']=[20,20];reseal_obs(bad)
  with self.assertRaises(A.Infrastructure):S.checked(raw,items,bad)

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--attempt',default='001');args=parser.parse_args();out=ROOT/'scoring_test_artifacts'/('attempt_'+args.attempt);out.mkdir(parents=True,exist_ok=False)
 resource.setrlimit(resource.RLIMIT_AS,(2147483648,2147483648));resource.setrlimit(resource.RLIMIT_CPU,(90,90));sys.dont_write_bytecode=True
 evaluator=BASE/'paper_scale_dag_evaluator_v1';runtime=A.mod('scoring_smoke_runtime',evaluator/'src/runtime.py');items=[60,40,55,45,30,70,100,1,99]
 numeric_errors=[]
 for name in ['bf','eoh','increasing_slack']:
  usage=resource.getrusage(resource.RUSAGE_CHILDREN)
  if 1+time.process_time()+usage.ru_utime+usage.ru_stime+62+20>120 or time.monotonic()-START+92+20>180:raise RuntimeError('handwritten test budget reservation')
  raw=(ROOT/'controls'/f'{name}.dag.json').read_bytes();py=(ROOT/'controls'/f'{name}.python.txt').read_bytes();d=ADAPTER.admit(raw,'dag');p=ADAPTER.admit(py,'python');left=json.loads(d['payload']);right=json.loads(p['payload']);left.pop('description');right.pop('description');assert left==right,'handwritten surfaces must lower to sameIR'
  obs=runtime.request({'mode':'pack','program_json':raw.decode(),'items':items,'capacity':100});A.save(out/(name+'.observation.json'),obs);SMOKE[name]=(raw,items,obs)
  checked=S.checked(raw,items,obs);assert checked['status']=='feasible'
  if name=='bf':assert checked['assignment']==[0,0,1,1,2,2,3,4,4]
  if name=='increasing_slack':assert checked['assignment']==list(range(len(items)))
 suite=unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__]);log=io.StringIO();result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
 usage=resource.getrusage(resource.RUSAGE_CHILDREN);budget={'cpu_seconds':PRIOR_BUDGET['cpu_seconds']+1+time.process_time()+usage.ru_utime+usage.ru_stime,'active_wall_seconds':PRIOR_BUDGET['active_wall_seconds']+1+time.monotonic()-START,'startup_allowance_seconds':1,'previous_attempts_debit':PRIOR_BUDGET}
 report={'passed':result.wasSuccessful(),'test_methods':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'log':log.getvalue(),'handwritten_numerical_smoke_dispatches':6,'handwritten_smoke_this_attempt':3,'prior_smoke_dispatches':3,'handwritten_items_per_control':len(items),'actual16slot_candidate_scores':0,'model_calls':0,'budget':budget,'artifact_sha256':{str(x.resolve()):A.sha(x) for x in sorted(out.glob('*')) if x.is_file()},'real_capture_fixture_sha256':{str(x.resolve()):A.sha(x) for x in sorted(FIXTURES.iterdir()) if x.is_file()},'source_sha256':{str((ROOT/x).resolve()):A.sha(ROOT/x) for x in ['scoring_admission.py','score_run.py','score_audit.py','score_report.py','test_scoring.py','SCORING_CONTRACT.json','adapter.py']}}
 A.save(out/'test_report.json',report)
 if result.wasSuccessful():A.save(ROOT/'score_tests_results.json',report)
 print(json.dumps({k:v for k,v in report.items() if k not in ['log','artifact_sha256','source_sha256']},indent=2));print(log.getvalue());return 0 if result.wasSuccessful() else 1
if __name__=='__main__':raise SystemExit(main())
