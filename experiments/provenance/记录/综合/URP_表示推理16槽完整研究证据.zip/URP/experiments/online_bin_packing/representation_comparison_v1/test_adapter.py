"""Offline tests use handwritten fixtures only, never execute candidate source."""
import hashlib
import json
from pathlib import Path
import warnings
import numpy as np
from adapter import SurfaceError, StructureError, admit, lower_python, validate_program
from interpreter import WorkBudget, evaluate, pack

HERE = Path(__file__).resolve().parent
B = HERE.parent


def reference(name, item, bins):
    # Fixed trusted references with precisely the handwritten operation order.
    if name == 'bf':
        return np.subtract(np.float64(0.0), bins)
    if name == 'increasing_slack':
        slack = np.subtract(bins, item)
        return np.add(slack, np.float64(0.0))
    slack = np.subtract(bins, item)
    exponential = np.exp(slack)
    root = np.sqrt(slack)
    fraction = np.divide(slack, bins)
    complement = np.subtract(np.int32(1), fraction)
    base = np.multiply(complement, root)
    threshold = np.multiply(item, np.int32(3))
    condition = np.greater(slack, threshold)
    high = np.add(base, np.float64(0.8))
    low = np.add(base, np.float64(0.3))
    bonus = np.where(condition, high, low)
    shifted_exp = np.add(exponential, np.float64(0.7))
    denominator = np.multiply(shifted_exp, exponential)
    correction = np.divide(bins, denominator)
    return np.add(correction, bonus)


def wrapped(body):
    return ('def score(item, bins):\n    """test"""\n' + body + '\n').encode()


def main():
    results = {'model_calls': 0, 'candidate_python_executions': 0,
               'controls': {}, 'rejections': {}, 'extraction_cases': 0}
    for name in ['bf', 'eoh', 'increasing_slack']:
        raw = (HERE / 'controls' / (name + '.python.txt')).read_bytes()
        lowered = lower_python(raw)
        p = lowered['program']
        q = validate_program((HERE / 'controls' / (name + '.dag.json')).read_bytes())
        assert (p.constants, p.nodes, p.types, p.return_node) == (q.constants, q.nodes, q.types, q.return_node)
        numpy_program = lower_python((HERE/'controls/eoh_numpy.python.txt').read_bytes())['program'] if name == 'eoh' else p
        assert (numpy_program.constants, numpy_program.nodes, numpy_program.types, numpy_program.return_node) == (p.constants, p.nodes, p.types, p.return_node)
        count = 0
        with warnings.catch_warnings():
            warnings.simplefilter('ignore', RuntimeWarning)
            for capacity in [100, 500]:
                for item in range(1, 101):
                    bins = np.arange(item, capacity + 1, dtype=np.int64)
                    # Include unsorted, tied inputs in a second vector per domain point.
                    for vector in [bins, bins[::-1].repeat(2)]:
                        a = evaluate(p, np.int32(item), vector, WorkBudget(), trace=True)
                        b = evaluate(q, np.int32(item), vector, WorkBudget(), trace=True)
                        r = reference(name, np.int32(item), vector)
                        assert a['scores'].tobytes() == b['scores'].tobytes() == r.tobytes()
                        assert a['trace'] == b['trace']
                        if name == 'eoh':
                            n=evaluate(numpy_program,np.int32(item),vector,WorkBudget(),trace=True)
                            assert n['scores'].tobytes()==a['scores'].tobytes() and n['trace']==a['trace']
                        count += len(vector)
        packs = []
        for split in ['development', 'validation']:
            data = json.loads((B / 'glm53_math_dag_pilot_v1' / 'data' / (split + '.json')).read_text())
            rows = data['cases'] if isinstance(data, dict) else data
            for row in rows:
                items = row['items']
                a = pack(p, items, 100, WorkBudget())
                b = pack(q, items, 100, WorkBudget())
                assert a == b
                if name == 'eoh':
                    assert pack(numpy_program,items,100,WorkBudget()) == a
                if name == 'increasing_slack':
                    assert a['used_bins'] == len(items)
                packs.append({'split': split, 'used_bins': a['used_bins'],
                              'assignment_sha256': hashlib.sha256(json.dumps(a['assignment']).encode()).hexdigest()})
        results['controls'][name] = {'nodes': len(p.nodes), 'vectors': 400,
                                    'score_elements': count, 'bitwise_equal': True,
                                    'all_node_traces_equal': True, 'packing_pairs': packs}
    bad_bodies = {
        'unicode_identifier': '    ｘ = bins+0.0\n    return ｘ',
        'import': '    import os\n    return 0.0-bins',
        'attribute': '    return bins.__class__',
        'numpy_attribute': '    return np.exp(bins)',
        'subscript': '    return bins[0]',
        'open': '    return open("/tmp/no")',
        'builtin_eval': '    return eval("1")',
        'builtin_exec': '    return exec("pass")',
        'builtin_compile': '    return compile("1", "x", "eval")',
        'dunder_import': '    return __import__("os")',
        'lambda': '    return (lambda x: x)(bins)',
        'comprehension': '    return [x for x in bins]',
        'loop': '    for x in bins:\n        pass\n    return 0.0-bins',
        'if': '    if item:\n        return 0.0-bins\n    return 0.0-bins',
        'if_expression': '    return bins if item else bins',
        'and': '    return bins and item',
        'power': '    return bins ** 2',
        'chain_compare': '    return bins > item > 0',
        'keywords': '    return exp(x=bins)',
        'starred': '    return exp(*bins)',
        'wrong_arity': '    return exp(bins, item)',
        'forward_ref': '    x = y+0.0\n    y = bins\n    return x',
        'reassign': '    x = bins\n    x = x+0.0\n    return x',
        'shadow_input': '    bins = bins+0.0\n    return bins',
        'shadow_operator': '    exp = bins\n    return exp',
        'dunder_name': '    __x = bins\n    return 0.0-bins',
        'annotated_assignment': '    x: int = bins\n    return 0.0-bins',
        'destructure': '    x,y = bins\n    return 0.0-bins',
        'multiple_targets': '    x=y=bins\n    return 0.0-bins',
        'expression_statement': '    exp(bins)\n    return 0.0-bins',
        'boolean_constant': '    return bins+True',
        'nonfinite_literal': '    return bins+1e999',
        'oversize_literal': '    return bins+1001',
        'string': '    return bins+"hi"',
        'unary_expression': '    return -bins',
        'scalar_root': '    return 1.0+item',
        'integer_root': '    return bins-item',
        'input_root': '    return bins',
        'int_where_branches': '    return where(bins>item, bins, item)',
        'scalar_gt': '    return where(item>1, 0.0, 1.0)',
        'global': '    global x\n    return 0.0-bins',
        'yield': '    return (yield bins)',
        'delete': '    del bins\n    return 0.0-bins',
        'context_manager': '    with bins as x:\n        pass\n    return 0.0-bins',
        'nested_function': '    def other():\n        return 1\n    return 0.0-bins',
        'many_nodes': ''.join('    n%d = bins+0.0\n' % i for i in range(65)) + '    return n64',
        'many_constants': ''.join('    c%d = %d\n' % (i,i) for i in range(17)) + '    return bins+0.0',
    }
    bad = {k: wrapped(v) for k,v in bad_bodies.items()}
    good = (HERE/'controls/bf.python.txt').read_bytes()
    for name, prefix in [('decorator', '@anything\n'), ('module_import','import os\n')]:
        bad[name] = prefix.encode() + good
    for name, signature in [('default','def score(item, bins=1):'), ('annotation','def score(item: int, bins):'),
                             ('vararg','def score(item, bins, *args):'), ('async','async def score(item, bins):')]:
        bad[name] = good.replace(b'def score(item, bins):', signature.encode())
    bad['source_limit'] = b' ' * 32769
    for name, source in {
        'numpy_other_alias':'import numpy as n\n'+good.decode(),
        'numpy_no_alias':'import numpy\n'+good.decode(),
        'numpy_from_import':'from numpy import exp\n'+good.decode(),
        'numpy_multi_import':'import numpy as np, os\n'+good.decode(),
        'numpy_reimport':'import numpy as np\nimport numpy as np\n'+good.decode(),
        'numpy_shadow':'import numpy as np\n'+wrapped('    np = bins\n    return 0.0-bins').decode(),
        **{('numpy_forbidden_'+str(i)):'import numpy as np\n'+wrapped('    return '+expr).decode() for i,expr in enumerate([
            'np.load(1)', 'np.save(1, bins)', 'np.__dict__', 'np.random.exp(bins)',
            'np.exp.__call__(bins)', 'np.exp(bins, item)', 'np.exp(x=bins)',
            'np.where(*(bins, bins, bins))', 'np.add(bins, 0.0)', 'np.exp'])}
    }.items():
        bad[name]=source.encode()
    for name, raw in bad.items():
        try:
            lower_python(raw)
        except (SurfaceError, StructureError) as exc:
            results['rejections'][name] = type(exc).__name__ + ': ' + str(exc)
        else:
            raise AssertionError('not rejected: ' + name)
    for rep, filename in [('python','bf.python.txt'), ('dag','bf.dag.json')]:
        payload=(HERE/'controls'/filename).read_bytes().strip()
        lang=b'python' if rep=='python' else b'json'
        fence=b'```'+lang+b'\n'+payload+b'\n```'
        for metric in ['strict','unique_block']:
            for text in [payload,fence]:
                admit(text,rep,metric); results['extraction_cases']+=1
        prose=b'Description outside\n'+fence+b'\nExplanation'
        admit(prose,rep,'unique_block'); results['extraction_cases']+=1
        for text,metric in [(prose,'strict'),(fence+b'\n'+fence,'unique_block'),
                            (fence[:-3],'unique_block'),(fence+b'```','unique_block')]:
            try: admit(text,rep,metric)
            except (SurfaceError,StructureError): pass
            else: raise AssertionError('bad extraction accepted')
            results['extraction_cases']+=1
    # No silent float root promotion; floats and ints remain distinguishable.
    p = lower_python(wrapped('    return bins + 1.0'))['program']
    assert p.constants == (('f64',1.0),)
    signed = lower_python(wrapped('    a = -0.0\n    b = 0.0\n    return bins+a'))['program']
    assert len(signed.constants) == 2
    eager = lower_python(wrapped('    bad = sqrt(0.0-bins)\n    return where(bins>0, bins+0.0, bad)'))['program']
    with warnings.catch_warnings():
        warnings.simplefilter('ignore',RuntimeWarning)
        w=WorkBudget(); r=evaluate(eager,np.int32(1),np.array([1,2],dtype=np.int64),w)
    assert w.numeric_counts['nan_elements'] == 2 and np.isfinite(r['scores']).all()
    results['eager_where_nonfinite_unselected_branch_counted'] = True
    results['numpy_spelling']={'exact_IR_equal':True,'vectors_bitwise_equal':400,'packing_pairs_equal':10,'all_four_allowed_attributes_tested':True,'import_executed':False}
    results['rejection_count'] = len(bad)
    results['status']='passed'
    (HERE/'test_results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps({k:v for k,v in results.items() if k not in ['controls','rejections']},indent=2))

if __name__ == '__main__':
    main()
