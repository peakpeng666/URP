"""Hash deliverable files; this is deliberately not a pre-generation freeze."""
import hashlib
import json
from pathlib import Path
HERE=Path(__file__).resolve().parent
files={str(p.relative_to(HERE)):hashlib.sha256(p.read_bytes()).hexdigest()
       for p in sorted(HERE.rglob('*'))
       if p.is_file() and p.name!='artifact_hashes.json' and '__pycache__' not in p.parts}
(HERE/'artifact_hashes.json').write_text(json.dumps({'status':'draft_delivery_snapshot_not_frozen','sha256':files},indent=2)+'\n')
print('Draft snapshot:',len(files),'files; no generation freeze created')
