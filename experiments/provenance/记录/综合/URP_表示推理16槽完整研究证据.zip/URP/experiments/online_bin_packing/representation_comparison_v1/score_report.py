"""Report all16slots including missing outcomes; no model or policy calls."""
import time
START=time.monotonic()
import argparse,collections,json,pathlib
from scoring_admission import json_load,sha,save
ROOT=pathlib.Path(__file__).resolve().parent

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',required=True);a=p.parse_args();out=pathlib.Path(a.output).resolve();results=out/'scores';r=json_load(results/'report.json',100000000);audit=json_load(results/'independent_audit.json',10000000);account=json_load(results/'completion_accounting.json')
 counts=dict(collections.Counter(x['status'] for x in r['scores']));lines=['# 表示×推理：16槽探索先导评分','',f"流程终态：{r['state']}；独立保存证据审计通过：{audit['passed']}。所有16个生成槽及240个预定评分行均保留。",'', '## 分层结果','',f"- 实际runtime请求{r['runtime_requests']}，观测到worker {r['workers_observed']}；派发前检查尝试{r['dispatch_attempts']}；终态分布{counts}",'- 完整5000历史设计集为主评价，256面板只诊断。没有按前缀质量、description一致性或之前数值成功筛选候选','- strict/unique是同一原始响应的两口径；同槽只评分一次。跨生成槽重复IR仍各自保存，不能称为独立新算法；模型采样seed未受控，区组顺序seed不等于配对采样seed','- length与正常stop分列；只有捕获完整、单模型消息且无工具的完整语法payload才准入。事件上限/超时截断未救回，未修复代码','', '## 四个条件格（各4槽）']
 for cell in r.get('summary',{}).get('cells',[]):lines.append('- '+json.dumps(cell,ensure_ascii=False))
 lines+=['', '## 每槽主评价（不对缺失值造分数）']
 adm=r['generation_admission'];groups=r.get('summary',{}).get('groups',[])
 for slot in adm:
  g=next((x for x in groups if x['id']==slot['id'] and x['panel']=='main5000'),None);lines.append(f"- {slot['id']} / {slot['representation']} / {slot['reasoning_effort']}：生成{slot['generation_status']}，strict={slot['strict']['status']}，unique={slot['unique_block']['status']}")
  if g and g['feasible']==5:lines.append(f"  - 箱数{g['bins']}，合计{g['sum_bins']}；对BF差{g['BF']['delta_sum_bins']:+d}，对发表EoH差{g['EOH']['delta_sum_bins']:+d}；论文口径超下界{g['paper_percent_excess']:.6f}%")
  else:lines.append(f"  - 完整可行实例{g['feasible'] if g else 0}/5；不计算完整面板质量")
 lines+=['', '## 指标与证据','- 主质量口径为100×(sum箱数−sumL1)/sumL1；L1为体积下界，不是最优值。mean(L1/箱数)另存精确分数，不替换主指标',f"- 独立重验保存BF/EoH基线{r['saved_baseline_rechecks']}份，没有新基线策略调用；审计候选分配{audit['candidate_saved_assignments_checked']}份、基线{audit['baseline_saved_assignments_checked']}份",f"- 不含description的不同IR数：{r.get('summary',{}).get('distinct_IRs_excluding_description','未完成')}；含description canonical数：{r.get('summary',{}).get('distinct_canonical_programs_including_description','未完成')}",f"- 静态审阅hash {r['review_sha256']}；先审阅后fitness，不因mismatch/undetermined丢弃候选",'- 原始正文、捕获元数据及所有hash保存；configured low/high与32000总completion是配置证据，物理HTTP参数/尝试次数没有因此被观察到','', '## 预算与限制',f"- 评分阶段（已计本研究mock/手写控制与静态准入debit）{account}；独立审计另{audit['budget']}",'- 每实例60CPU秒/90wall秒/2GiB/1,625,000,000工作量；合计1800CPU/2700activewall，提前预留下一请求62/92及终结40/40。资源/预算缺失不是算法质量失败，基础设施失败停止剩余派发','- 数据全部研究范围内已暴露；开发256前缀与完整5000相关。每条件仅4次探索生成，不能声称强因果、统计显著性、模型排名、通用编程能力或完整Python额外表达力','- 限定Python只做白名单AST转同一IR，从未执行候选Python。此项不是原EoH完整多代进化复现','', '## 文件','- preparation_seal.json与preparation/：原文、metadata、两口径准入及payload','- scores/static_review.json：独立公开description/code静态审阅','- scores/report.json：全部240终态、面板与分层统计','- scores/*observation.json：真实worker原始输出、限额与成本','- scores/independent_audit.json：整数负载独立复算']
 with (out/'RESULTS_ZH.md').open('x') as f:f.write('\n'.join(lines)+'\n')
 final={'cpu_seconds':account['cpu_seconds']+audit['budget']['cpu_seconds']+1+time.process_time(),'active_wall_seconds':account['active_wall_seconds']+audit['budget']['active_wall_seconds']+1+time.monotonic()-START,'report_startup_allowance_seconds':1,'generation_and_review_wait_excluded':True}
 final['within_cap']=final['cpu_seconds']<=1800 and final['active_wall_seconds']<=2700
 save(out/'final_accounting.json',final);manifest={str(x.relative_to(out)):sha(x) for x in sorted(out.rglob('*')) if x.is_file()};save(out/'artifact_manifest.json',manifest)
 print(json.dumps({'report':str(out/'RESULTS_ZH.md'),'within_cap':final['within_cap'],'audit_passed':audit['passed']},indent=2));return 0 if final['within_cap'] and audit['passed'] else 1
if __name__=='__main__':raise SystemExit(main())
