"""Read-only preflight for frozen inputs; never starts generation or scoring."""
import hashlib
import json
from collections import Counter
from pathlib import Path
import zipfile
HERE=Path(__file__).resolve().parent

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def check():
    p=json.loads((HERE/'protocol.json').read_text())
    o=json.loads((HERE/'order.json').read_text())
    slots=o['slots']
    assert len(slots)==16 and p['generation_slots']==slots
    assert [x['slot'] for x in slots]==list(range(1,17))
    assert len({x['id'] for x in slots})==16
    assert Counter((x['representation'],x['reasoning_effort']) for x in slots)=={('dag','low'):4,('dag','high'):4,('python','low'):4,('python','high'):4}
    for field in ['block','within_block_position']:
        for k in range(1,5):
            assert len({(x['representation'],x['reasoning_effort']) for x in slots if x[field]==k})==4
    common=set()
    for x in slots:
        f=HERE/x['prompt_file']
        assert sha(f)==x['prompt_sha256'] and f.stat().st_size==x['prompt_bytes']
        common.add(f.read_text().split('Representation:')[0])
    assert len(common)==1
    assert p['generation']['max_completion_tokens']==32000 and p['generation']['wall_seconds_per_slot']==900
    assert p['generation']['temperature']==0.7 and p['generation']['top_p']==0.9
    assert p['generation']['max_logical_calls_total']==16
    assert p['generation']['client']['namespace_provider']=='zhipuai-coding-plan'
    assert p['budget']['aggregate_numerical_cpu_seconds']==1800
    assert p['budget']['aggregate_numerical_active_wall_seconds']==2700
    assert p['scoring']['attempts_max']==240
    tests=json.loads((HERE/'test_results.json').read_text())
    assert tests['status']=='passed' and tests['rejection_count']==70 and tests['extraction_cases']==18
    deps=json.loads((HERE/'source_hashes.json').read_text())['sha256']
    for path,digest in deps.items():
        f=Path(path)
        if not f.is_absolute(): f=HERE.parents[3]/f
        assert sha(f)==digest, str(f)
    manifest=json.loads((HERE/'generation_transfer_manifest.json').read_text())
    allowed=set(manifest['files'])|{'generation_transfer_manifest.json'}
    assert allowed=={'protocol.json','order.json','generation_transfer_manifest.json'}|{x['prompt_file'] for x in slots}
    with zipfile.ZipFile(HERE/'generation_transfer.zip') as z:
        assert len(z.namelist())==len(allowed) and set(z.namelist())==allowed
        for name in allowed:
            assert z.read(name)==(HERE/name).read_bytes()
        for name,record in manifest['files'].items():
            assert sha(HERE/name)==record['sha256']
    scorer_files=['scoring_admission.py','score_run.py','score_audit.py','score_report.py','test_scoring.py','SCORING_CONTRACT.json']
    missing=[x for x in scorer_files if not (HERE/x).is_file()]
    scoring_tests_passed=False
    if (HERE/'scoring_preflight.json').exists():
        ready=json.loads((HERE/'scoring_preflight.json').read_text())
        st=json.loads((HERE/'score_tests_results.json').read_text())
        assert ready['ready_for_joint_refreeze'] is True and st['passed'] is True and st['test_methods']==26
        for path,digest in ready['source_sha256'].items(): assert sha(Path(path))==digest,path
        assert p['generation']['export_manifest_contract_sha256']==sha(HERE/'SCORING_CONTRACT.json')
        contract=json.loads((HERE/'SCORING_CONTRACT.json').read_text())
        assert all(p['generation']['export_manifest_contract'][k]==v for k,v in contract.items())
        assert contract['budget']['aggregate_cpu_seconds']==p['budget']['aggregate_numerical_cpu_seconds']
        assert contract['budget']['aggregate_active_wall_seconds']==p['budget']['aggregate_numerical_active_wall_seconds']
        assert contract['budget']['next_reserve_cpu']==p['budget']['next_worker_reservation_cpu_seconds']
        assert contract['budget']['next_reserve_wall']==p['budget']['next_worker_reservation_wall_seconds']
        assert contract['budget']['finalization_reserve_cpu']==p['budget']['finalization_reservation_cpu_seconds']
        assert contract['budget']['finalization_reserve_wall']==p['budget']['finalization_reservation_wall_seconds']
        scoring_tests_passed=True
    frozen=False
    if (HERE/'freeze.json').exists():
        f=json.loads((HERE/'freeze.json').read_text())
        for path,digest in f['sha256'].items():
            assert Path(path).is_absolute() and sha(Path(path))==digest,path
        frozen=True
    out={'input_checks':'passed','logical_slots':16,'zip_entries':19,
         'common_prompt_byte_identical':True,'order_position_balanced':True,
         'missing_scorer_files':missing,'scoring_tests_passed':scoring_tests_passed,'frozen_inputs_verified':frozen,
         'model_dispatch_authorized_by_this_check':False,
         'protocol_sha256':sha(HERE/'protocol.json'),
         'order_sha256':sha(HERE/'order.json'),
         'transfer_zip_sha256':sha(HERE/'generation_transfer.zip'),
         'freeze_sha256':sha(HERE/'freeze.json') if frozen else None}
    (HERE/'preflight_result.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))

if __name__=='__main__': check()
