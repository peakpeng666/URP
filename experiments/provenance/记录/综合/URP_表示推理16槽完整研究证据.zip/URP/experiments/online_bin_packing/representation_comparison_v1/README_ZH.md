# 教师P3 表面表示对照：离线准备与自审

当前状态（2026-10-05 06:51 UTC）：修订2联合freeze与preflight通过，仍0模型调用/0科学候选评分；父任务须重新审阅并另行授权派发。第一版freeze已明确superseded且原字节完整保留。

当前freeze：0e391943802dcd7138ed21d34ed9259f52846423a88b329639015d3d95e99c47
当前protocol：27d16c7f394f079edc77800f9ffd83e230e630ff48c12763de7bf697fa120392
当前transfer ZIP：fd39e45235864a94edfcda9e057eab6b1f48681e4fcc1f1be548512cd37b286d

精确provider为zhipuai-coding-plan。26项评分测试及真实capture语义回归通过；真实空length的capture_succeeded=false原样保留，按generation_length和结构拒绝分层，不能再误当批次基础设施失败。旧empty metadata缺steps，测试只核实其真实捕获语义，没有补造字段；真实非空metadata另作完整schema核验。累计测试成本3.801470965 CPU秒/3.777716854 wall秒，保留之前所有尝试成本。

以下记录按准备时间展开，较早草案、上限与freeze记录仅供追溯，以本段、protocol.json及preflight_result.json为当前依据。

状态：待父任务审阅的草案，不是冻结实验；新增模型调用0，未创建Codex任务，没有读取凭据或执行生成Python。

## 本轮实际完成

先写GRAMMAR_DRAFT.md再实现adapter.py。限定Python仅用AST白名单解析，静态降为原math-dag-v1；随后调用原validator。评分仍走原解释器，完整5000使用另一个独立冻结的paper_scale_dag_evaluator_v1。任何候选文本都不经exec/eval/应用层compile，不import为模块。父任务审阅后允许精确的import numpy as np声明以及np.exp/np.sqrt/np.where/np.greater，全部仅静态映射到既有运算，不执行import；其他属性、导入和调用仍拒绝。ast.parse内部使用Python的AST-only解析实现，这不代表执行输入程序。它不是一般Python沙箱，也不是完整Python搜索空间。

固定BF、发表EoH、递增残量三组手写双表示，完全保留运算顺序。EoH是原15节点5常数，不以代数化简掩盖浮点差异。每组400向量（容量100/500、item1..100、正序/逆序重复容量）和150300个分数，通过两表示及独立手写固定NumPy参考的逐bit核对；所有节点trace也一致。每组在已暴露10条256实例上双表示完整packing字典相同，包括每次分配、残量、箱数、可行计数与工作量。总计1200向量450900分数、30对packing。70种恶意/不支持/越界/类型输入拒绝；18个双提取测试通过。另增NumPy白名单拼写EoH，同15节点在400向量及10条256实例上再次逐bit/全分配核对。见test_results.json，均为人工固定控制，不是模型生成成绩。

## 严格保留的局限

- 原vf64根、where浮点分支、整数界和eager分支的人工负担仍在。item-bins作为整数向量根仍被拒绝；不悄悄将两臂改成更宽松合同
- 两表示共享运算和可表达数学空间；语法/常数表达便利性不完全相同。Python同类型同值literal intern（保留浮点signed zero），DAG显式常数槽。字节/AST限制可能造成表示特有失败，须单列
- 原解释器只要求最终分数finite，中间浮点非有限允许计数并继续；未选where分支NaN也会先计算。我们保留并测试这个事实，不虚构全节点finite规范
- ast白名单+输入上界降低风险，但不是对所有解析器/运行时漏洞的形式证明；资源隔离仍须用于正式评分
- 400向量/控制不是独立实验样本；对同一固定程序重算不增加模型独立重复
- BF/EoH/递增残量是adapter正确性控制，不是新算法或模型能力结论

## 16逻辑调用草案

glm-5.3 ×2表示 ×low/high ×4个独立新会话请求（不保证provider RNG独立）。官方2026-10-05页面明确支持low/high/max且推理始终启用：https://docs.z.ai/guides/llm/glm-5.3 。但当前客户端的字段映射尚需审阅；保存配置不等于观察到HTTP发送。若不能核实第二设置，须在执行前公开修订为8槽，不用猜测参数。

两个prompt共享完全相同问题、Weibull提示、5000主评价/256诊断信息、不要求胜BF目标、description及数学合同，只更换表示规范。四个区组均含全部四条件，且每条件在四个顺序位置各一次；随机种子20261005仅用于顺序，采样seed未控。每槽独立新会话，无tools、修复、补抽或按质量挑选。

同一原始响应同时计算整段严格准入与唯一完整块准入；允许后者有块外解释，但拒绝多代码块、不完整块和任意片段救回。同一提取候选最多评分一次，两准入口径共享该评价。所有槽保留传输/length/终文/格式/schema/数值/资源/可行/质量层次。结构有效者都去完整5000面板，绝不按256前缀质量筛选。description与实现一致性以不知道fitness的静态审阅标记consistent/mismatch/undetermined，不把公开description叫作供应商私有推理。

建议统一32768 completion、900秒/槽，理论配置总上限524288 completion token及4小时串行生成墙钟。它较此前成功的low16384更宽裕，但不是high充分性的证据，预算仍需父任务审阅。价格/实际HTTP重试/远端CPU未知；任何length仍记资源层失败，不归咎算法能力。最多16×15=240候选评分dispatch，主面板80个；独立评估器实际15次完整控制合计约19秒，预算硬上界不代表预计耗时，复杂64节点余量另核实。正式评分另行冻结独立资源ledger，不拿旧256预算硬跑5000。

## 待冻结前的必要检查

1. 审阅语法、实现、共同prompt和采样/预算配置，校验实际客户端与system追加内容
2. pin并核验5000 evaluator freeze，确认最复杂64节点资源余量，保留资源失败类别
3. 冻结全部prompt、数据、实现、客户端配置与顺序哈希，保存每次原始响应/终止/token/wall观测
4. 获取模型调用具体预算授权，才开始16槽；本目录没有自动调用代码

新5000评估器来自并行独立验证：原/新各24单测、30条256回归、15条5000控制；BF10335、发表EoH10007、递增型坏控制25000，BF/EoH分配与历史逐物品一致。这些是对方交付，不能冒算本adapter自己的执行。见runner_contract.json。

运行本目录离线测试：OPENBLAS_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 python test_adapter.py。prepare_draft.py仅生成本目录草案文件；不请求模型或服务。artifact_hashes.json是可更新交付快照，不是冻结声明。

## 独立最大节点补充压力结果

paper_scale_dag_maxnode_control_v1另行冻结的一次64节点浮点恒等链×5000控制已完成：
工作量1,486,519,744/1,625,000,000（91.478%），320000节点求值；CPU4.768757秒、墙钟4.770222秒、RSS26056KiB；0警告/非有限。
5000箱且assignment为0..4999，独立checker和整数重算通过。它与原15控制研究分开，不追加进原计数。
该单一运算链给出实际资源余量证据，不保证所有含复杂exp/sqrt/where的64节点程序同速，也不解除逐次资源隔离。
对应freeze及报告定位见runner_contract.json；原5000评价器freeze保持不变。

## 父任务最终准备审阅（尚未启动模型）

最终名protocol.json、order.json及prompts/slot_01.txt至slot_16.txt已生成，预备transfer ZIP仅含提示、协议、顺序和哈希清单。
数值总预算现为1800 CPU秒/2700 active-wall秒，含主机、worker、checker、收尾开销；下一worker预留62 CPU/92 wall秒，收尾另预留40 CPU/40 wall秒。
主评价先跑5条5000实例，之后才跑256诊断；不按诊断质量筛选。跨生成槽即使程序相同也不复用评分，同一槽strict/unique两口径只共享一次评分。
正式GLM科学调用路线是已有用户授权access任务中的官方CLI及其已有Network配置，不创建新的Codex开发任务；当前准备阶段不读取或打包凭据，不发模型请求。
四个fresh-session请求不保证服务端随机源独立；编排/准备消耗资源，单列且未计量，不称零成本。
遇到重大鉴权、配额/限流或provider访问变化就停止并保留未跑槽，不换账号或付费回退。
最终freeze需通用240槽评分器就绪并与协议一致，随后父任务另行授权才可启动16次GLM请求。

### 最终客户端上限勘误（冻结前）

预审发现客户端source默认OUTPUT_TOKEN_MAX=32000，实际构造取min(model.limit.output, outputTokenMax)。因此最终统一显式model.limit.output=32000，completion上限32000/槽，16槽配置总上限512000；900秒/槽不变。
不通过环境flag强行增加768 token。先前草案32768是已纠正提案；32768 UTF-8程序字节限制仍保持，勿与token混淆。source路径、行号与哈希在client_budget_evidence.json和最终协议中；source/配置不冒充实际HTTP观测。

### 终止与可提取算法分层（冻结前明确）

若finish_reason=length，但捕获正常完整、恰好一个模型消息且没有工具事件，则可按预定strict/unique规则对完整payload准入并评分；仍保留generation_length资源结果，绝不改称normal stop。
事件字节上限、watchdog、未知/不完整capture不能救回；完整capture中的断fence、partial JSON及多替代答案仍拒绝。这里仅取出完整算法，不修复截断代码。四个条件统一执行。

## 最终准备状态：联合freeze已完成，模型尚未启动

preflight_result.json确认16槽映射、共同前缀、19项transfer及全部405个冻结文件通过核验。评分侧23项测试、3个手写微控制通过；前一次测试夹具CPU上限设置不匹配失败已保留并保守计入预算，不隐藏失败，也不算生成候选执行。
最终generation_transfer.zip SHA256：c1ee514a9957c1d98ba944c356ccfe50dada8383ad82861d87f64b59b744d5e8。
freeze SHA256：ba881071f0194edb3e28abfc41b324540abf27c3d91fe94ab51e6f67ec24e743。
protocol SHA256：4b65942c6609a0de1489e74d35c2d486fcedd4eecd5ebeb0012a45ee0a2e6b0f。
父任务须审阅最终协议并另行授权现有access任务，才可开始最多16次GLM请求。冻结不等于调用授权。后续源、协议和提示不再改动，结果写新输出目录。

## 冻结前派发审阅修订2：第一版已明确作废，仍0模型调用

父任务发现精确provider应为zhipuai-coding-plan，旧简称codingplan不够准确。还发现真实capture_runner的capture_succeeded表示是否交付非空终文，故完整捕获的空length响应可合法为false；第一版mock误把它当捕获完整性条件。
第一版freeze及405个冻结源的原始字节、协议、transfer等均已备份至revisions/pre_dispatch_r1_superseded，414项回读验证通过并标注superseded/0calls。
当前没有有效freeze；必须等真实旧empty-length与非空capture fixture回归后重新冻结并交父任务审阅，不能继续引用第一版通过结论作派发依据。
