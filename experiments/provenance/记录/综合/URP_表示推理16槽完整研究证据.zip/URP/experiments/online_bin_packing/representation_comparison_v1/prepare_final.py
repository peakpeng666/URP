"""Prepare bounded protocol and transfer materials; no network or model execution."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile

HERE = Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--scorer-ready', action='store_true')
args=parser.parse_args()
if (HERE/'freeze.json').exists():
    raise RuntimeError('Preparation is already frozen; do not rewrite frozen inputs.')

def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

common = '''Design ONE online bin-packing scoring heuristic. Aim to minimize the number of used bins; beating Best Fit is not required. Give one nonempty, one-line public algorithm description and one implementation that matches it. Do not provide alternative candidates or use tools.

The bin capacity is 100. Item sizes are integers from 1 to 100, with representative Weibull(shape=3, scale=45) sizes rounded and clipped to 1..100. Main evaluation uses five fixed 5000-item design sequences. The 256-item panels are diagnostics and never a quality-based gate for main evaluation. Each run preallocates one bin per item, including unused bins of capacity 100. At each arrival you see only item (an i32 scalar) and bins (a vi64 vector of ALL feasible remaining capacities, including unused bins), in original bin-index order. Feasibility includes exact fit: bins >= item. Return one finite float64 score per feasible bin. The highest score wins; ties choose the first bin. No future items, position, state, reductions, indexing or external data are available.

Shared mathematical contract: only add, sub, mul, div, exp, sqrt, gt and where; 1..64 operations and 0..16 typed constants. Each constant is finite and has absolute value at most 1000. Integer literals are i32 and floating literals are f64; item is i32 and bins is vi64. add/sub/mul promote to floating if either operand is floating, and to a vector if either operand is a vector. div/exp/sqrt produce floating results with the same scalar/vector rule. gt needs at least one vector and returns vb. where takes vb plus two f64/vf64 branches and evaluates both eagerly. Other numeric operators reject booleans. All integer intermediates have absolute value at most 1000000. The return must reference a vf64 operation node; an integer vector or scalar root is not automatically converted. The description is at most 1024 UTF-8 bytes with no control characters. The implementation payload is at most 32768 UTF-8 bytes. Keep division, sqrt and final scores well-defined on the feasible domain.
'''
suffixes = {
'dag': '''Representation: mathematical DAG JSON. Return only one complete JSON object, optionally inside one lower-case json fence. Keys are exactly schema="math-dag-v1", description, constants, nodes, return_node. constants is an array of {"type":"i32" or "f64","value":number}; i32 values require integer JSON literals. Each nodes entry is [op,arg,...]. add/sub/mul/div/gt have 2 arguments, exp/sqrt have 1, and where has 3. An argument is "item", "bins", "cK" for constant index K, or an integer global zero-based index of an earlier node. No literal operands or forward references are permitted. return_node is the global index of a vf64 node. All nodes execute in array order, including dead nodes.
''',
'python': '''Representation: restricted Python mathematical surface, statically lowered without executing Python. Return one function, optionally inside one lower-case python fence: def score(item, bins):. You may precede it with exactly import numpy as np; this declaration is recognized statically and never executed. The first statement inside the function is a string-literal docstring containing the one-line public description. Then write zero or more simple assignments to fresh ASCII names, followed by exactly one final return. No other imports, decorators, annotations, defaults, reassignment or names beginning with underscore are allowed. Do not shadow the inputs, score, np or operator names. References use inputs or earlier assignments. Expressions allow numeric literals, unary minus only on a literal, parentheses, + - * /, one > comparison, and only unqualified positional calls add/sub/mul/div/exp/sqrt/gt/where with their stated arities. If the exact numpy declaration is present, np.exp/np.sqrt/np.where/np.greater are also permitted and mapped to exp/sqrt/where/gt with identical arities. No other attributes or imports, arbitrary calls, keywords, indexing, loops, conditionals, comprehensions, power or other syntax are allowed. Literal 1 is integer; 1.0 is floating. Identical typed literals share a constant slot. Expressions lower left to right in postorder, one operation per operator; assignments and aliases preserve earlier references. No algebraic optimization, casting or dead-node removal occurs. Return a vf64 operation result. Parser caps are 4096 AST nodes and expression depth 128, sufficient for canonical straight-line 64-operation programs.
'''
}
order = json.loads((HERE/'order_draft.json').read_text())
order['status'] = 'parent_approved_balanced_condition_order'
(HERE/'prompts').mkdir(exist_ok=True)
for slot in order['slots']:
    slot['id'] = 'slot_%02d' % slot['slot']
    slot['prompt_file'] = 'prompts/' + slot['id'] + '.txt'
    prompt = HERE/slot['prompt_file']
    prompt.write_text(common+'\n'+suffixes[slot['representation']])
    slot['prompt_sha256'] = sha(prompt)
    slot['prompt_bytes'] = prompt.stat().st_size
order['sampling_seed'] = None
dump(HERE/'order.json', order)
protocol = json.loads((HERE/'protocol_draft.json').read_text())
protocol['status'] = 'reviewed_for_freeze_no_model_dispatch_authorization' if args.scorer_ready else 'parent_approved_conditions_prepared_pending_scorer_review_not_frozen'
protocol['design']['order_file'] = 'order.json'
protocol['design'].pop('independent_replicates_per_cell', None)
protocol['design']['fresh_session_generations_per_cell'] = 4
protocol['design']['sampling_seed'] = 'Uncontrolled; four separate fresh sessions per cell do not guarantee independent provider RNG. Blocks are not paired sampling seeds.'
protocol['generation'] = protocol.pop('proposed_generation')
protocol['generation']['max_completion_tokens'] = 32000
protocol['generation']['client']['model.limit.output'] = 32000
protocol['generation']['client']['namespace_provider'] = 'zhipuai-coding-plan'
protocol['generation']['client']['output_token_flag_override'] = None
protocol['generation']['client']['effective_output_cap_basis'] = 'Pinned source default OUTPUT_TOKEN_MAX=32000; maxOutputTokens returns min(model.limit.output, outputTokenMax) or outputTokenMax. No environment override. Configured/intended effective cap, not observed HTTP proof.'
protocol['generation']['client']['source_audit'] = json.loads((HERE/'client_budget_evidence.json').read_text())
protocol['generation']['rationale'] = 'Parent approved common bounded caps, not a guarantee of adequate reasoning budget. Length exhaustion remains a resource outcome, not proof of algorithmic inability.'
protocol['generation']['no_paid_fallback'] = True
protocol['generation']['route'] = 'Existing user-authorized saved access task with official CLI under exact provider namespace zhipuai-coding-plan and its configured Network secret; root owncloud performs offline preparation and numerical scoring. No new Codex development task is created.'
protocol['generation']['stop_on'] = ['material authentication or provider access change', 'rate limit or quota block', 'unexpected paid fallback requirement', 'unexpected tool execution or material configuration mismatch']
protocol['generation']['blocked_slots'] = 'Retain remaining slots as not_run; no alternate account, paid provider, retry refill or unapproved access change.'
protocol['generation']['authorization'] = 'No model dispatch until root explicitly authorizes the existing access task after final preflight.'
if (HERE/'SCORING_CONTRACT.json').is_file():
    contract=json.loads((HERE/'SCORING_CONTRACT.json').read_text())
    protocol['generation']['export_manifest_contract'] = contract
    protocol['generation']['export_manifest_contract_sha256'] = sha(HERE/'SCORING_CONTRACT.json')
    protocol['generation']['execution_role_boundary'] = 'The access task only generates and exports responses and non-secret capture metadata. The embedded scoring/admission CLI commands are for the root owncloud workflow and must not be run by the access task.'
    protocol['generation']['export_manifest_contract']['condition_binding'] = 'The record example is illustrative, not the actual condition for slot_01; fill every record from generation_slots and its frozen prompt SHA256. Exactly 16 terminal records, including failed/not_run slots.'
    protocol['generation']['export_manifest_contract']['no_secrets'] = 'Export raw responses and non-secret metadata only. Do not export access tokens, credentials, secrets or complete sensitive configuration files.'
protocol['generation']['source_capture'] = 'Save each exact raw response and metadata under its slot ID, including empty output, finish reasons, token usage, configured options, configured and observed fields, wall time, CLI exit, tool events, system suffix and errors. Do not replace failed slots.'
protocol['generation_slots'] = order['slots']
protocol['pre_dispatch_revision'] = {'revision':2,'model_calls_before_amendment':0,'candidate_scores_before_amendment':0,'superseded_freeze_sha256':'ba881071f0194edb3e28abfc41b324540abf27c3d91fe94ab51e6f67ec24e743','backup':'revisions/pre_dispatch_r1_superseded','backup_zip_sha256':'010aac1f6208a54958d83a2a762c8bd6c35fb51f22d5f0f7271046aeb16b2557','reason':'Exact provider namespace and actual source capture_succeeded semantics for intact empty length outputs corrected before dispatch; first freeze and source bytes preserved.'}
protocol['budget'] = protocol.pop('budget_proposal')
protocol['budget']['max_configured_completion_tokens'] = 512000
protocol['budget']['aggregate_numerical_cpu_seconds'] = 1800
protocol['budget']['aggregate_numerical_active_wall_seconds'] = 2700
protocol['budget']['includes_numerical_host_and_checker_overhead'] = True
protocol['budget']['orchestration_accounting'] = 'Preparation and orchestration use resources but are outside the 16 GLM candidate calls. Offline preparation is separately unmetered, not zero-cost. Remote orchestration CPU and provider physical attempts remain unknown.'
protocol['budget']['next_worker_reservation_cpu_seconds'] = 62
protocol['budget']['next_worker_reservation_wall_seconds'] = 92
protocol['budget']['finalization_reservation_cpu_seconds'] = 40
protocol['budget']['finalization_reservation_wall_seconds'] = 40
protocol['budget']['numerical_budget_excludes'] = ['remote generation wall and CPU', 'elapsed wait for independent static review', 'unmetered static code authoring and orchestration']
protocol['budget']['numerical_budget_includes'] = ['measured mock and handwritten numerical preparation tests', 'static admission runtime', 'scoring supervisor and workers', 'baseline rechecks', 'independent final audit/report and finalization']
protocol['scoring']['aggregate_budget'] = '1800 total numerical CPU seconds and 2700 active wall seconds, including host, worker, checker and finalization overhead. Reserve the next worker plus finalization before dispatch. Stop on infrastructure or insufficient budget and preserve every pending not_run row.'
protocol['scoring']['dispatch_order'] = 'Main full panel first: for each of 5 historical instances, visit candidates in frozen generation order. Then diagnostic development instances 0..4 and validation instances 0..4, each visiting candidates in the same order. Never filter full-size scoring by prefix performance.'
protocol['scoring']['cross_slot_score_cache'] = False
protocol['scoring']['per_slot_accounting'] = 'Even identical or equivalent payloads in different generation slots receive separate fixed scoring executions; only the two extraction metrics within a slot share one score.'
protocol['scoring']['primary_panel'] = 'All five historical 5000-item sequences, capacity 100'
protocol['scoring']['candidate_eligibility'] = 'Valid unique-block admission from the identical raw response. Strict and unique-block metrics remain paired. Score that candidate once, even when both extraction rules admit it; no quality-dependent selection or repair.'
protocol['scoring']['missing'] = 'Retain structural/numerical/resource/checker/transport/length errors and all not_run rows; never rank or aggregate incomplete panels. Infrastructure or budget stops have explicit stop reasons.'
if args.scorer_ready:
    ready=json.loads((HERE/'scoring_preflight.json').read_text())
    assert ready['ready_for_joint_refreeze'] is True and ready['revision']=='r2_pre_dispatch_real_capture_semantics_fix'
    for path,digest in ready['source_sha256'].items():
        assert sha(Path(path))==digest, path
    protocol['scoring']['readiness'] = {'scoring_preflight_sha256':sha(HERE/'scoring_preflight.json'),'static_mock_tests_passed':ready['tests'],'handwritten_numerical_microcontrols_total':ready['handwritten_microcontrol_evaluations_total'],'existing_capture_harness_cases_reused':ready['existing_original_capture_harness_cases_reused_without_rerun'],'real_empty_length_capture_succeeded_value':False,'real_empty_length_source_preserved':True,'candidate_score_calls':0,'model_calls':0,'prior_fixture_startup_failure':'Preserved in scoring_test_artifacts/attempt_001 and conservatively debited; no candidate model or policy execution in that failed attempt.'}
protocol['scoring']['pilot_runner'] = 'score_run.py, with scoring_admission.py, score_audit.py and score_report.py; see SCORING_CONTRACT.json. Operational only after explicit readiness and freeze checks.'
protocol['admission']['termination_separation'] = {'normal_stop':'Intact normal capture with finish_reason stop', 'generation_length':'Intact normally completed capture with finish_reason length; retained as a generation-resource outcome, never relabeled normal stop', 'structural_eligibility':'Either stop or length may undergo both extraction rules only with intact capture, exactly one model message, no tools, no byte-cap truncation and no watchdog termination', 'length_scoring':'A fully parseable whole payload or one complete unique block may be scored; never repair partial JSON/code, truncated fences or ambiguous alternatives', 'capture_failure':'No structural recovery from incomplete or truncated event capture, byte cap, watchdog kill, unknown completeness, or multiple alternatives'}
protocol['admission']['capture_succeeded_semantics'] = 'Preserve the original boolean. The actual capture runner uses false for intact empty terminal text; it is a nonempty-output outcome, not a capture-integrity hard gate. Integrity is separately checked from normal capture, exit, finish reason, message/tool counts, stop reason, truncation and raw-byte/hash evidence.'
protocol['admission']['empty_intact_terminal_text'] = 'Keep its observed normal_stop or generation_length category and raw byte count zero, then reject the empty structural payload through the normal extractor/parser. Empty final text alone is not a batch infrastructure failure.'
protocol['analysis']['primary'] = ['termination distribution: normal stop, generation length, capture/transport failure and not_run', 'strict structural admission fraction over all 16 slots', 'unique-block structural admission fraction over all 16 slots', 'full five-instance finite feasible scoring fraction over all 16 slots', 'complete full-panel sum of bins and delta to BF and published EoH; incomplete panels are not ranked']
protocol['admission']['normalization'] = 'Only the predeclared outer whitespace/fence wrapper extraction; no code rewriting, repairs, casts, candidate selection or return-node search.'
protocol['analysis']['description_consistency'] = {'timing':'Record before candidate fitness is computed or revealed','values':['consistent','mismatch','undetermined'],'meaning':'Public description vs lowered implementation; no claim about private model reasoning','required_artifact':'Hash-sealed per-slot static review before scorer starts','does_not_filter_scoring':True}
protocol['freeze_gates'] = [
    'Conditions, representation grammar, common prompts and budget approved by parent',
    'All 16 individual prompt hashes and balanced condition mappings checked',
    'Adapter and numpy whitelist tests pass without changing prior source hashes',
    'Generic maximum-240-dispatch scorer implemented, tested and explicitly declared ready',
    'Protocol and scorer agree on budgets, reserve rules, eligibility and dispatch order',
    'Freeze all relevant code, prompts, protocol, order and data hashes only after scorer review',
    'Root checks final preflight and separately authorizes model dispatch in the existing access task'
]
protocol['fallback'] = 'No automatic setting change, paid-provider fallback, repair, extra model call or refill. Stop for parent review when the verified access or configuration cannot support this bounded design.'
protocol['prohibited'] = ['New Codex development tasks', 'Model/API calls during offline preparation or before root authorization', 'Reading or bundling secrets in this preparation', 'Arbitrary generated Python execution', 'Mutating prior frozen experiments', 'Paid fallback or alternate-account bypass', 'Unapproved publication or push']
dump(HERE/'protocol.json', protocol)

# Minimal transferable input bundle only. Readiness/freeze are intentionally not claimed.
transfer_files = [HERE/'protocol.json', HERE/'order.json'] + [HERE/s['prompt_file'] for s in order['slots']]
manifest = {'status':'prepared_not_frozen_no_dispatch_authorization', 'identity':protocol['identity'],
            'files':{str(p.relative_to(HERE)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in transfer_files}}
dump(HERE/'generation_transfer_manifest.json', manifest)
with zipfile.ZipFile(HERE/'generation_transfer.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
    for path in transfer_files+[HERE/'generation_transfer_manifest.json']:
        info=zipfile.ZipInfo(str(path.relative_to(HERE)),date_time=(2026,10,5,0,0,0))
        info.compress_type=zipfile.ZIP_DEFLATED
        info.external_attr=0o644 << 16
        z.writestr(info,path.read_bytes())
print(json.dumps({'status':'prepared_not_frozen','slots':len(order['slots']),
                  'protocol_sha256':sha(HERE/'protocol.json'), 'order_sha256':sha(HERE/'order.json'),
                  'transfer_zip_sha256':sha(HERE/'generation_transfer.zip')},indent=2))
