# URP 表示×推理16槽：完整研究证据

终态研究；包含所有16原文/安全metadata、两口径提取、限定Python转同IR代码、195实际评分的原始stdout和完整分配、45未运行行、独立审计及最终报告。原生成58文件与原ZIP均保存，源hash见STUDY_MANIFEST.json；只排除一份已被终态记录取代的中间交接状态说明，排除路径/hash明示，未改科学数据。

入口：URP/experiments/online_bin_packing/representation_comparison_v1/runs/representation_actual_20261005_01/RESULTS_ZH.md。详细240行见scores/report.json。16次均正常stop；strict5、唯一块13；13槽、11个不含description的IR。完整主面板10槽与BF10335箱同分配，slot09为10744，slots04/14为25000，没有候选胜BF或固定EoH10007。两个先盲审mismatch候选保留并评分。

195候选+30旧基线保存分配审计通过。最终数值计费CPU63.263606秒/activewall63.114098秒，含已记账数值准备、准入与终审；不含远端生成、等待及未计量编写。原累计研究11+本轮16=27，固定复制传输控制另1；最初接入smoke不并入科学样本。物理HTTP次数/线上参数未知，low/high是配置证据。n=4每格、已暴露数据、相同受限IR，不能模型排名/能力归因/强因果或完整Python结论。

保留URP/...和glm_generation_transfer/...相对结构。DEPENDENCIES.json列出旧URP/评价器/运行时未包含项；本包不是自包含执行环境。冻结清单的原绝对路径不被改写；复验应准备匹配环境和明确路径映射，使用新输出目录，不覆盖原结果。没有打包缓存、vendor依赖、秘密、论文全文或尚未完成的NumPy隔离可行性研究。

PACKAGING_CHECKS.json只证明打包读取/源hash核查，不表示本次重跑了实验。未调用模型、未新评分、未恢复暂停的人工反馈。

## 相关已核对交付
- 改进与验证记录：https://drive.google.com/file/d/1-61-KrYcsOnmXL9hJyNroFTe4EQq7cWO/view?usp=drivesdk
- 先前完整P3证据（含5000评价器）：https://drive.google.com/file/d/1-RWPvVrkVPPv5BADBNwnf_M-2QYkuXxa/view?usp=drivesdk
- 前两张报告图：https://drive.google.com/file/d/12_KBP3YtjXgw8FQanoCvJwCpzXE0-tac/view?usp=drivesdk
这些是已核对的既有文件链接；本新研究包的上传与回读由最终交付另行确认。
