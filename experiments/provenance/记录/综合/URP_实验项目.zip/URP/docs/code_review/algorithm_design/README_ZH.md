# 自动算法设计：首批六篇核心源码对照

核查日期：2026-10-04。本轮只做官方公开源码读取、文本/元数据解析；没有导入或执行研究源码、安装依赖、调用生成模型、下载权重或大数据。源文件以 `.txt` 保存，防止误作为可执行包。源码可读、程序可运行、数值复现是三种不同状态。

## 1 范围与来源

先检查既有 `urp_cleanup_20261004/reading_original/结果_M01/逐篇笔记`，不是按热门列表临时加论文。本批为P177 EoH、P321 FunSearch、P416 ReEvo、P312 LLM4AD、P043 AEL、P532 EPS。六篇均已有全文阅读记录；本轮重新追踪所列源码链，未重新通读六份PDF。论文主张依据既有逐篇笔记和 `05_论文与代码对照.md`，源码结论依据本轮实际读取文件。其余40篇M01笔记列入 `review_index.json`，明确未在本轮重新深核。

固定版本：
- EoH H：`e4b5ddba03b2b88025747e11c6049f8b529a4368`，2024时期版本；C：`472545785c936dcfc863d2bc0d6109cf23c7ce62`。H不是已证实的某次论文实验环境
- FunSearch：`cc53f274237d7ab05c19df939edbc1f9616a7c19`
- ReEvo及其AEL移植：`6dce18257da5e11db2d138e417a2fffc5c72d05f`
- LLM4AD：`ffb6acf64497be93932c98d25369352efd3865cf`
- EPS原作者库：`ab09bfabe6b5ed2037cf72ce0074ca89ee8d9185`

EoH复用当前云端已有固定版源码，其余从GitHub只读取清单文件。`source_manifest.json`记录commit、Git blob SHA、SHA256、字节量及永久链接。根目录README与论文引用用于身份确认，不作为已读算法实现的替代。

## 2 P177 EoH：版本不是可互换参数

官方来源：https://github.com/FeiLiu36/EoH 。本轮复核H的 `eoh_interface_EC.py`、`eoh.py`、`eoh_evolution.py` 与C的 `eoh/eoh.py`；完整历史链已在项目 `docs/P3_EoH_thought_code_演化就绪差距.md` 记录，不能当本轮新发现重复计数。

- H：`population_generation`先做两批N初始化；`_get_alg`仅I1/E1/E2/M1/M2，没有M3；每个算子一整批N后立即选优。`get_prompt_*`把思想与代码放入提示，排名通过父选择间接影响生成，并非每次都把数值成绩写入提示
- H主循环L144–165的权重是整批是否启用的Bernoulli门；不是算子分类概率。低于1时`offsprings`可能未定义或沿用前批。旧默认4算子，不是论文5算子
- C `eoh.py`L237–290先预占slot，再随机抽一算子，逐个完成即更新；预算默认G×N，加2N初始化；失败也占slot。这和H的2N+4GN、论文描述N+5GN不相同
- 论文M3确有描述，H缺实现，C有新增实现但提示版本与描述解析规则仍须冻结。M3重构不能冒充原模板
- H代码重复重试、解析重试、HTTP重试是不同层；静态上界与真实计费次数必须分账。H评分舍入与同分去重可压缩种群，不保证N个不同功能个体
- 装箱宿主是给可行箱打分再argmax；包括未用箱，允许恰好放下。目标平均箱数相对平均L1的excess，与论文平均每例利用率不是相同聚合
- 当前项目已有历史容量更正与固定公式核对；公开历史数据再用不叫新盲测。完整EoH模型/候选空间/种群规模未数值对齐

可复用的是思想-代码-谱系记录和明确算子契约，不能直接照当前main启动冒称原论文。旧版本生成线程timeout不是对任意代码的安全隔离证明。

## 3 P321 FunSearch：公开管线有核心空接口

[固定源码入口](https://github.com/google-deepmind/funsearch/tree/cc53f274237d7ab05c19df939edbc1f9616a7c19/implementation)。本轮完整读取funsearch、sampler、evaluator、programs_database、config五个核心文件。

链：`funsearch.main`识别run/evolve装饰器→评价模板种子→`Sampler.sample`取岛提示→LLM续写→Evaluator裁函数体/重命名→Sandbox对每输入评价→ProgramsDatabase归岛/分簇→下一提示。

- `sampler.py`L25–36 `_draw_sample`、`evaluator.py`L88–100 `Sandbox.run`均NotImplementedError。模型服务、安全运行设施、分布式调度不在这份公开骨架内；不可当现成可运行论文框架
- `programs_database.py`L49–56：聚合取最后输入分数；signature排序输入键但只保留值。`evaluator.py`L141–155允许只要有任一成功输入就归档，因此移植时必须另设完整实例集合及失败处理；不能将不同缺失输入集的相同分数元组当同一行为
- 岛随机选，簇以退火softmax选择，同簇按短代码偏好采样；四小时重置较差半数岛。参数：10岛、2父槽、每提示4样本、温度0.1/周期30000。样本选择默认可有放回
- `get_prompt`返回版本号len+1，`_generate_prompt`新header用len；递归自调用重命名存在静态偏移疑点，未执行反例
- `sample`无限循环无总预算；main声明只有第一sampler实际运行，配置15sampler/140evaluator不等于并行集群已提供
- 本轮未读取大型notebook的数据/结果，不把其下载或旧阅读记录列成新增数值复验。完整论文内部模型快照、seed、分布式账本仍不可恢复

可复用接口：固定宿主模板+单函数、逐例分数、行为簇与短程序偏好；必须新建获准且独立验约束的执行途径，并强制有限值、全实例成功与硬预算。

## 4 P416 ReEvo：100评价不是100请求

[固定主循环](https://github.com/ai4co/reevo/blob/6dce18257da5e11db2d138e417a2fffc5c72d05f/reevo.py)。本轮完整读488行主文件和公共客户端、AEL、CVRP宿主关键文件。

链：seed评价→30份高温初始化→随机选不等分父对→短期反思→交叉10份→评价→长期反思→elite突变5份→评价→轮前检查FE。每轮保留elite供下轮，不是维护互补算法库。

- FE在有无代码检查前增加；100上限仅轮首判断。正常不中断路径1+30+5×15=106个FE，是静态推导，不是作者真实日志
- 默认temperature加0.3只用于初始化；反思也调用模型却不计候选FE。`BaseClient.chat_completion`最多1000次尝试；全部失败时`response_cur`可能未赋值，不能承诺干净停止。temperature=0会被`temperature or self.temperature`覆盖
- `_run_code`调用`block_until_running`等首次stdout，无截止时间；`communicate(timeout)`在之后才开始。子进程并非完整沙箱，NaN/Inf stdout评分无显式有限性校验
- `main.py`只对训练赢家跑val，无自动完整独立test流程。不能把公开val与最终test混用
- CVRP生成`heuristics`矩阵，固定ACO负责访问和容量mask、回仓清载、终止。100迭代×30蚁、容量50；负吸引度裁至1e-9，实际语义要连这个宿主一起解释
- 数据生成seed1234；train50十例，val/test20/50/100各64例；ACO用torch Categorical采样，所读入口未固定torch随机种子，因此数据seed不等于搜索轨迹可重放
- 重要静态新风险：`eval.py`将距离矩阵对角设1；ACO已完成的蚁在其他蚁未完成时仍追加仓库0，`gen_path_costs`按全部相邻边累加，可能为完成较早的蚁多计0→0边费用。当前完整batch轨迹下影响多大未运行；独立CVRP检查应将仓库等待/填充边费用单独核验，不能默认返回分数等于真实闭合路线长度

可复用：相对好坏的反思接口、外部知识初值、训练赢家后置验证。缺口：独立距离/容量重算、严格预算预占、反思token账本、训练/验证/最终测试冻结与随机源。

## 5 P043 AEL：只取得后续移植，不冒称原版

[ReEvo中的AEL](https://github.com/ai4co/reevo/blob/6dce18257da5e11db2d138e417a2fffc5c72d05f/baselines/ael/ga.py)。作者资料将早期AEL接到EoH家族，当前没有锁定2023原实验commit。本轮标记`derivative_code_inspected`，不是`original_pipeline_verified`。

- init prompt→描述/代码解析→rank_select按1/rank→交叉→逐子代Bernoulli变异→统一评价→整代替换；全局elite只是记录，不在此分支父子合并
- 论文笔记记载随机父选择、精英合并、变异0.2；移植默认排名选择、整代替换、0.5；fitness用正目标倒数，TSP宿主报告平均长度，不能当Gurobi逐例gap
- timeout代码硬写10秒，而配置20秒；同样有首次stdout等待问题
- 新接线核查：main为AEL提供公共BaseClient；其`multi_chat_completion`返回`list[str]`，AEL `crossover`L285–290和`mutate`L320–324把每项再取[0]传给`response_to_individual`，后者L72读取`.message.content`。默认此路径的返回类型不一致，预计会发生属性错误；这是静态合同冲突，没有运行或修补它
- 还须核全无效/仅一成功父代、空变异列表和完整原始请求日志。原AEL源码缺口不能用移植框架的可读性抹平

## 6 P312 LLM4AD：统一接口也需要独立验收

[固定EoH文件](https://github.com/Optima-CityU/LLM4AD/blob/ffb6acf64497be93932c98d25369352efd3865cf/llm4ad/method/eoh/eoh.py)。本轮读EoH、prompt、sampler、population及SecureEvaluator/CVRP链；不是把平台全部任务都标完成。

链：Evaluation(template/task)→I1/E1/E2/M1/M2→花括号思想+函数解析→SecureEvaluator→score/耗时注册→Population生存和排名抽样。没有M3；每累积N新候选就生存，不能按论文一代5N理解。

- `_tot_sample_nums += 1`在`profiler is not None`内部；解析失败提前return不计。文档的“有效无效都计”不是完整模型请求账本；无Profiler且只靠该计数时有停止风险
- 新配置核查：文档允许`max_sample_nums=None`，但构造器 `_adjust_pop_size`立即做`None >= 10000`，且初始化上限调用min(None,2N)。该默认路径与“None禁用预算”的说明不一致，静态可见，未执行
- 相同代码或相同score被降为-inf；不能当行为等价。选择过滤inf不等于过滤NaN。rank权重这里r从0起为1/(r+N)，与EoH H的1/(rank_1_based+N)有细微差异
- SecureEvaluator子进程里仍exec；超时/kill不是文件系统网络权限安全证明。protected division会改变候选语义，必须记录开关
- CVRP默认50客户×16实例、Q40、20秒，seed2024；生成的是下一节点接口。宿主给可行集合，但未强制返回节点在集合中，累计载荷也未事后拒绝超容量；末尾只验节点集合大小。不能把低负平均距离当已证实可行解
- 生成器每次实例化重置全局numpy seed2024；重复构造同参数评价器不会产生新独立验证集。构造参数`**kwargs`未传给父Evaluation，预期通过它覆盖random_seed等也应核实际接线
- HTTPS层非debug无限重试；外层采样数不封顶实际HTTP尝试和token。模型配置取外部LLM实例，平台仓库不构成论文历史模型快照

可复用模板/Evaluation协议，避免直接复用缺输出验收的CVRP评分器。新候选必须与现有URP独立容量/距离检查器对接。

## 7 P532 EPS：此次补回原作者库，不再只读伪码

[原库固定版本](https://github.com/zhichao-lu/llm-eps/tree/ab09bfabe6b5ed2037cf72ce0074ca89ee8d9185)。既有笔记明确未提供此仓；本轮新增追踪hill_climb的装箱completion路径，不以LLM4AD移植替代。

链：decorated template→seed评价→ProgramsDatabase→Cluster.sample_program直接取Profiler.the_best_function→续写→AST函数体→装箱Sandbox→均值分数→Profiler更新全局best。

- 名称仍有FunSearch岛/簇骨架，但实际取父是全局best；默认functions_per_prompt=1。`cur_best.py`另一个best变量不在已核主链，不将文件名当实际状态源
- 选择状态耦合Profiler：`Cluster.sample_program`返回`Profiler.the_best_function`，其更新在`Profiler._record_and_verbose`；main在log_dir=None时不创建Profiler，初值为Ellipsis，不能当“关闭日志不影响算法”
- sampler类计数初值1，种子单独评价；样本按整批取4，轮前检查10000。成功满批路径计数1+4k，可能结束于10001。该计数不是API次数；重复在同进程启动没有显式重置类计数会影响下一run
- 示例LocalLLM每请求动态读配置，可在运行时改endpoint/batch/samples；因此实验必须保存每次实际配置，不能只保存启动CLI。异常无限重试，requests.post未设timeout；temperature/top_k/top_p为None交给服务端，实际采样参数未在此文件锁定
- 装箱固定宿主过滤可行箱、argmax、负平均箱数。模板seed包含除零与-inf的可能路径；其有效性依赖实际数值和宿主，不能仅因是seed视为已验收
- 沙箱为multiprocessing+join timeout+exec，注释称防网络/RAM但所读实现未设网络禁用或内存限制；不能以注释当安全事实
- aggregation改为成功输入分数均值，但仍允许部分输入失败后非空归档；配置samples_per_prompt默认末尾逗号使值为tuple，具体装箱入口显式传4避开此项
- 本轮未取数据pickle、模型服务、四方法×四任务×九模型×五run的全部配置/结果，没有完成论文全矩阵审计。仅新增一条必要原库链

## 8 与现有URP实验的真实距离

最新现存 `experiments/online_bin_packing/math_dag_evolution_compact_v2/delivery/RESULTS_ZH.md` 已不是早期“完全未生成”的状态：22次本地模型请求、7份进入设计评分、4份四例有效；两臂最后都选手写FF，第二代仍只有FF/BF父代。此处只读取已完成报告，没有重跑。

所以缺口应更新为：已有受限DAG生成/拒绝/评分/冻结选择证据，但没有生成父代接力产生收益；没有原论文完整Python候选空间、GPT历史后端、N20/G20和原设计规模；没有ReEvo反思、FunSearch群岛或EPS同预算原库实证。下一项应先把可验证的不同机制接到同一有限预算与问题合同，而非宣称缺口只剩模型大小。

统一应记录：候选slot、模型逻辑请求、网络尝试、响应、解析拒绝、语义拒绝、评分调用、有效实例集合、逐例值、wall/CPU/tokens、最终选择承诺。源数据种子、父代抽样种子、torch/NumPy/Python随机源和并发顺序分别保存。任何看过验证结果后的修改都需重新标开发数据。

## 9 操作方式、许可及后续停止条件

1. 先读review_index.json选择paper_id，再按source_manifest永久链接和SHA核文件；不运行sources中的任何程序
2. 只将新增机制/独立验证缺口转为具体实验卡；每卡固定目标表、实现版本、问题合同、预算及失败分母后才讨论执行
3. `code_inspected`仅代表注明的路径；本轮所有作者研究源码`executed=false`、论文主结果`numerically_aligned=false`。已有URP缩小实验另列，不冒充原库执行
4. 许可：ReEvo MIT；FunSearch Apache-2.0，原许可已保留。EoH两个固定commit均另取LICENSE，均为MIT，存于licenses/，须保留各版本版权声明。LLM4AD根许可为两条BSD式条件，但部分源文件头另写research-only/引用/商业联系，存在文本范围不一致；保留两者并待许可澄清，不承诺可商用
5. EPS根LICENSE本轮返回未取得；继承文件有Apache头，新增文件未统一声明，数据许可未确认。本地源码只作研究工作证据，默认不得随对外交付打包；对外给分析与固定链接。各仓数据来源与软件许可不同，代码许可证不自动授权原数据/模型
6. 本批停止于六篇所列链路静态检查。后续优先P304 LLaMEA、P326 MCTS-AHD、P125 CoupleEvo及P212 G-LNS；后两项须与路由专项合并去重。其他论文保持范围清单，不能把46个标题或摘要算46篇代码精读
