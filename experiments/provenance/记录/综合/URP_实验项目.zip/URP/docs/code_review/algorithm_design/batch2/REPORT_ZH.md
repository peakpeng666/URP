# 第二批：父代保留、生成修复与VRP算子共演化

2026-10-04至05 UTC，静态源码核查。实际取得并读取4个作者仓库的限定核心路径；另外2篇只有来源检索结果。未运行作者研究程序、未安装、未调用模型或下载权重/数据。首批源码及其source_manifest保持不变；累计review_index修正元数据字段并增加本批范围。

## 对下一实验最直接的结论

1. **MCTS-AHD适合检验“先变差后变好”**：树保留有效非精英节点，节点Q由优秀后代回传；不能只改变top-k池大小冒充同一机制。必须同时记录父本自身分数和子树价值
2. **ShinkaEvolve可借少繁殖父本的采样奖励，但不等于保留全部差父代**：只从正确且在archive的程序中采样；满archive后的替换策略仍可淘汰差程序。embedding新颖性不等于数学行为差异
3. **LLaMEA的最简plus/comma选择是更便宜的先行消融**：固定同一生成器与预算，只改父子合并或仅后代存活；避免一开始同时加树、反思、模型路由
4. **G-LNS值得借destroy/repair成对接口，不宜照搬其“synergy分数”作互补性证据**：分数是累计奖励，受被选次数与当前解影响，且代码中的单算子分数与配对分数跨轮累计范围不同
5. 四个当前作者仓都不能直接充当我们的硬预算与独立执行验收器；借机制时须保留已有受限执行、完整失败账本和独立CVRP约束检查

## P304 LLaMEA

官方仓 https://github.com/XAI-liacs/LLaMEA ，本批固定 `0b08a42789d130081ee3dd3ab2b65b2ee339dced`。既有笔记固定的是`2a200f6…`；此次另取版本，不能将当前新增接口倒推为2025论文设置。正式题名核于 https://arxiv.org/abs/2405.20132 。MIT许可随文件保存。

### 实际读取链
`llamea.py`初始化510–580→`llm.py`121–183采样与代码提取→用户f评价599–613→构造提示668–751→算子采样及生成1131–1198→父代选择1203–1273→生存1028–1093→run1276–1383。

- 生成对象是完整优化器类；评价由传入f负责，框架不是自带合法性证明
- 提示包含当前population摘要、选中父代代码/描述/feedback/error；不是所有历史完整代码。单亲变异与多亲交叉共享Operator接口
- 单目标elitism=True合并父子后排序截断，False只保留后代；默认随机父代有放回，可用rank轮盘或锦标赛。global best另存，不等于逗号策略下一父本
- 外层budget实际按run_history候选数，非docstring的代数；整批后代使剩余额度不整除时可能越界。示例实际n_parents=2、n_offspring=5，尽管注释写1+1
- BBOB示例：5维，24函数×3实例×3重复，内层budget=200×dim=1000；AOCC按log目标裁剪归一化、提前停时补齐。外层100候选不等于100个BBOB函数评价，不能同原论文10000内预算比较
- 示例exec(code,globals())，超时依joblib外围；没有从框架评价接口推出OS级隔离

### 当前固定版仍可见的接线问题
1. Operator字段顺序prompt,name,…，但默认构造为Operator("mutation",长指令,…)，所以repr进入提示的是"mutation"；使用关键字自定义Operator可避开，不能扩大为所有提示失效
2. adaptive_mutation生成比例字符串后只写self.mutation_prompts；已读construct_prompt实际拼operator repr，未用该新字符串。该路径无法据开关就保证比例指令已发送
3. `weights=[operator.weight or 1.0 ...]`会把显式0权重变成1，不能用weight=0关闭一个算子
4. 上述为静态合同结论，没有运行异常/行为测试；不据此宣称历史论文实验用了这些代码

尚未读完多目标、MAP-Elites/novelty、HPO、diff保护及全部提供商路径；没有恢复原论文运行commit与逐请求账本。

## P326 MCTS-AHD：此次取得原作者实现

官方仓 https://github.com/zz1358m/MCTS-AHD-master ，固定 `ee9c4f424503c65a5fd2b899e6620ce86079fedb`，MIT。正式题名见 https://arxiv.org/abs/2501.08603 。原笔记只核LLM4AD移植，此次不再混同。

### 从入口到树
`main.py`→`ahd_adapter.py`把Hydra参数与client接入Paras→`source/mcts_ahd.py`→`evolution_interface.py`→`evolution.py`→`problem_adapter.py`外部任务评价。

- 根虚节点；先I1一个，再E1初始化到4根孩子。精英池10；默认FE1000、超时60秒。Python random.seed(2024)，所核链未同样固定NumPy和内层任务所有随机源
- `MCTSNode.reward=-obj`，Q初值同reward；`backpropagate`把父Q设为最大child.Q并增visits，因此祖先Q可优于自身；树仍留非精英代码，精英池只截断nodes_set
- UCT为全局q_min/q_max归一化Q＋0.1×剩余预算比例×sqrt(log(parent.visits+1)/visits)。深度上限10；渐进扩宽用floor(visits^0.5)>children数
- 根扩宽E1跨根子树采样；非根扩宽固定E2。叶扩展权重[0,1,2,2,1]对应E1/E2/M1/M2/S1；默认6个动作槽，S1只有一个独特祖先时跳过
- 每个生成候选先产thought/code，再调用post_thought→get_prompt_refine重写少于3句思想。alignment调用不增加FE，不能把1000 FE当1000 LLM请求
- 解析使用从import/def到最后return的正则，再拼输出变量；这是主动代码变换，应保留原响应与实际评估版本，不算纯原文执行

### 边界与平台期风险
- 初始化`get_algorithm`在timeout、inf或同目标值时无限循环，没有检查fe_max；`get_offspring`异常也无限重试。若受限语言只产生FF/BF这类少数同分程序，可能永远填不满4个异分初始节点。不能以此拒绝循环掩盖生成能力不足
- 后续单次扩展最多3次评价重试，但六动作整批及扩宽没有逐次剩余预算门。必须在每个请求与评价前预占额度
- UCT分母未加epsilon，尽管类里有epsilon成员。全相同零Q场景会除零；初始化同分过滤通常减少该情形，但不能当一般零范围保护
- problem_adapter读stdout倒数第二行，要求原值>0再翻转max目标；这限制可用任务分数范围。首次stdout等待继承外部工具，尚未在本批独立全读工具实现，不能凭60秒标全流程严格超时
- 主入口只在训练赢家后跑val。CVRP ACO文件已取得供后续逐项对照，但本批未重新通读其全部宿主，不新增数值/安全结论

可做独立实验卡：固定生成语言/评分/请求上限，比较精英池淘汰与保留差父树；对每一后代保存own_score、subtree_Q、父ID、实际提示、是否来自非精英节点及全成本。树不是自动保证收益。

## P465 ShinkaEvolve：档案多样性与预算要连调用链看

官方 https://github.com/SakanaAI/ShinkaEvolve ，固定 `9912af12d423504b8d580f4179fd15f5f88b8c50`，Apache-2.0；与既有笔记同commit。论文身份 https://arxiv.org/abs/2509.19349 ，当前代码含2026统一异步runner，不是2025论文的原runner。

### 本批重核范围
父选择parents.py235–432、sampler.py77–209、async_novelty_judge.py30–235、async_runner.py852–886/2702–2860/4076–4145/4398–4508、prioritization.py470–509/601–653、dbase.py2321–2390、circle评价文件全读、wrap_eval.py330–410、local.py74–142。大runner/数据库虽已存档，未全行重读。

- weighted parent从correct archive取候选，weight=sigmoid(lambda×(score−median)/max(MAD,1e−6))/(1+children_count)。后项让少被繁殖者更易抽到，并非任务行为新颖度。MAD是当前实现相对论文公式的改动
- archive未满时接纳所有correct；满后fitness或crowding替换。weighted采样无法复活已被删出archive的程序，所以它与MCTS全树保留不同
- prompt明确传parent code、combined score/public metrics、可选文本反馈与inspiration；diff/full/cross分开；无inspiration时过滤cross并重新归一
- runner选一次生成LLM，再嵌套novelty attempts×patch resamples；无正确程序可走fix mode。embedding缺失直接接受，novelty判断部分异常/空LLM回复也放行，故新颖性不是严格证明或唯一性约束
- 正确性来自任务validate_fn；circle检查shape/finite/非负/边界/重叠，atol0，但reported_sum一致性仍有np.isclose默认rtol，且最终score用reported_sum。应用时优先独立重算目标，不把候选自报值直接当事实
- Local提交Popen继承环境，仅加输出配置，无从此路径证明恶意代码文件/网络隔离。只读到这些实现，不因注释“SAFE PROCESSING”就称安全执行证明
- LLM bandit以相对parent/seed收益更新，失败reward=None，正增益可指数变换；当前可混成本项，非论文已验证的等美元比较
- 预算“committed”=已记费+活跃proposal×历史平均，初期无均值则在途估0；它是估计，不保证绝不超用户硬额度。meta总结成本也应计入
- 当前circle small示例200代、$20，与论文150评价不能直接等同。没有运行这些配置，也不请求任何外部模型

迁移优先级：先借有限archive+繁殖计数，并用真实DAG行为签名判断复制；不要在22请求量级先增加embedding/novelty judge/LLM路由多层成本。不同模块应分别消融。

## P212 G-LNS：补齐CVRP算子实际契约

官方 https://github.com/ZBoyn/G-LNS ，固定 `ea834aaa23a6952ff5e47d377940ec38b7e97482`，MIT。题名 https://arxiv.org/abs/2602.08253 。本批完整读主循环、ALNS评价、种群、工具注册、CVRP评价与生成器主要链；不执行。

### 双种群与反馈
- destroy返回(removed,partial)，repair接partial/removed/problem_data返完整路线；固定ALNS负责接受、温度和评分，不是LLM直接生成一条路线
- 各池5，专家seed各3，LLM补各2；每10个外层generation才剪2并补新。示例max_generations400，不是论文叙述200；40次演化触发不等400次LLM调用
- mutation先随机选一个父，再按当前rank赋best/worst/random策略；同类交叉按非负累计score概率不放回挑2亲
- `_evolve_operators`先以新random<.5判mutation，失败后再次抽random<.8判homogeneous，其真实条件概率为.5/.4/.1，不是单次阈值.5/.8的.5/.3/.2
- ALNS按weight选d/r，用1.5/1.2/.8/.1奖励更新weight与两个算子score、pair score。weight在整次evaluate开始重置，但不同实例之间延续，因此实例顺序影响后续抽样
- population个体score累积10代后reset；run每代覆盖self._pair_scores，因此联合交叉取的是最后一次evaluate的配对统计，不是同样10代累计。先prune再找配对，最佳配对成员若被剪掉便不生成替代；种群规模可能少于目标
- 每份代码本地生成修复最多4次尝试；失败后不保证補滿pop_size。Joint一次返回两个算子，不能按一个程序/一次评价的口径简单比较EoH

### 有效性、随机性与执行边界
1. `CVRPTask(seed=1234)`仅保存seed，_load_instances没有传给GetData；实际生成器硬写np.random.seed(2024)。显式seed参数不代表数据变化
2. 主循环调用每个d/r函数在当前进程直接执行，`op_timeout`只存配置未用于调用；注册阶段先exec再做子进程check。因此check_timeout10秒不能覆盖代码加载或正式ALNS调用
3. 总客户长度检查＋CVRP容量与unique数量检查确实存在，不能说完全不查重复。但未断言客户集合恰为1..n，可用仓库0或负索引替代合法客户形成相同长度/基数，潜在越界语义未封死；没有运行构造反例
4. 预检用随机距离矩阵与随机坐标且两者不一致，只能当接口烟雾测试，不是可信欧氏CVRP质量验证。预检未独立校验repair容量，正式评分才检查
5. `problem_data`传入实例数组对象，生成函数可能原地改变distance/demands；所见正式调用未深拷贝这些数组。需要独立只读输入与目标重算，不能因为route复制就以为实例不可污染
6. 重试提示附错误文字，但不一定包含完整前次代码；不能认定修复属于同一候选的纯局部修正。主运行末尾只有日志，不自动完成独立验证集选best pair再测试500步

下一步应先在既有CVRP独立验收器下定义可信固定repair＋有限destroy接口，再比较共同评分与分开评分；双生成开放Python与完整协同统计另列，不跳过有效性边界。

## P125 CoupleEvo：真实源地址仍未取得

正式元数据 https://arxiv.org/abs/2605.06341 明确指向 https://github.com/tb-git-kit-research/CoupleEvo 。本批GitHub commits/HEAD读返回404，网页读取也未成功；只说明本轮该地址不可取得，不能断言从未开源或永久关闭。没有commit、源码内容或许可可核验。

既有论文记录提供sequential/iterative/integrated协调及完整耦合目标评分，但旧搭档分数是否重新评价、实例遍历、缓存和预算没有代码证据。CEoH/LitCEoH不是本篇，未借来凑完成。状态：source_not_obtained，code_inspected=false，executed=false，numerically_aligned=false。

## P240 DGS：只核身份及可得性，不伪造代理实现

正式题名与作者核于 https://arxiv.org/abs/2607.13911 。本批以正式题名/arXiv ID检索，没有取得作者GitHub实现或独立supplement；检索无结果不等证明未公开。第三方“复现”入口不是作者代码，本批没有运行或采用。

当前能用于下一实验的是论文层假说：生成前联合挑算子与父集合，需要真实parent→child转移数据；topK均值父池仍会提前排除暂差但有潜力父本。不能只接一个embedding打分器就叫DGS。网络维度、训练循环、失败计数、模型服务与成本均未由源码核验。状态同上，保留null commit及许可。

## 证据与后续

本批4篇有源码限定范围阅读、2篇缺源；不是6篇全部代码读完。`batch2/source_manifest.json`记录源码SHA256/字节/永久链接；`batch2/coverage.json`区分已读行段、仅取得文件、未取得内容。源文件版权头完整保留；四库根许可已取得，但模型/任务数据许可尚未逐项核完。累计索引把原title改为note_heading；paper_title来自正式论文页面，未核实者为null。

下一实验最小优先序建议：同语言与硬预算下plus/comma→少繁殖父采样→保留非精英父树；VRP先可信repair/有限destroy再成对生成。本文不改实验代码、不追加生成请求或结果。
