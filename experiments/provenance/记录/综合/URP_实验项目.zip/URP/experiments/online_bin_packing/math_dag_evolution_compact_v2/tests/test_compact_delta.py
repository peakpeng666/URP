"""Pure-data delta/profile/provenance and actual Budget integration tests."""
import copy,hashlib,json,pathlib,sys,unittest
P=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'src'))
from policy import validate_generated_program,validate_program,StructureError,structural_changes
from guard import Budget,load_cases
EX=(P/'examples/public_example.json').read_bytes();Q=json.loads((P/'protocol.json').read_text())
class Tests(unittest.TestCase):
 def test_example_and_seeds_admitted(self):
  validate_generated_program(EX)
  for n in ['ff','bf']:validate_generated_program((P/'seeds'/(n+'.json')).read_bytes())
 def test_limits_apply_to_generated(self):
  for key,value in [('description','x'*65),('constants',json.loads(EX)['constants']*2),('nodes',json.loads(EX)['nodes']+[json.loads(EX)['nodes'][-1]])]:
   x=json.loads(EX);x[key]=value
   with self.assertRaises(StructureError):validate_generated_program(json.dumps(x).encode())
 def test_full_reference_still_allowed_only_by_full_validator(self):
  raw=(P.parent/'math_dag_v1/fixtures/programs/published_eoh.json').read_bytes();validate_program(raw)
  with self.assertRaises(StructureError):validate_generated_program(raw)
 def test_copy_and_parameter_diagnostics(self):
  self.assertTrue(structural_changes(EX,EX)['same_graph_identity']);d=json.loads(EX);d['constants'][0]['value']=50;change=structural_changes(EX,json.dumps(d).encode());self.assertFalse(change['nodes_changed']);self.assertTrue(change['parameter_only_observed'])
 def test_exact_new_fragments(self):
  source=P.parent/'paper_baseline_v1/data/historical_numeric.json';raw=source.read_bytes();self.assertEqual(hashlib.sha256(raw).hexdigest(),'97b77d4d5f98a32b46240e18a85c99d39f5fd5cfea4df83782abe330a7b21fd5');sets=json.loads(raw)['sets']
  panel=json.loads((P/'data/panel.json').read_text());self.assertEqual(len(panel['sequences']),4)
  for s in panel['sequences']:
   p=s['provenance'];self.assertEqual(s['items'],sets[p['source_set']][p['source_index']][128:256]);self.assertEqual(len(s['items']),128)
 def test_split_exact_order_and_parent_hash(self):
  ph=hashlib.sha256((P/'data/panel.json').read_bytes()).hexdigest()
  for split in ['design','validation']:
   path=P/'data'/f'{split}.json';self.assertEqual(json.loads(path.read_text())['parent_panel_sha256'],ph);self.assertEqual(len(load_cases(path,split,Q['data'][split+'_case_ids'])),4)
 def test_profile_schema_is_accepted_diagnostic_schema(self):
  self.assertEqual((P/'generation_schema_v2.json').read_bytes(),(P.parent/'math_dag_interface_v2_1/generation_schema.json').read_bytes())
 def test_real_budget_new_protocol(self):
  b=Budget(Q);b.reserve('model');b.reserve('score');r=b.terminal();self.assertTrue(r['within_charged_budget']);self.assertGreaterEqual(r['charged_cpu_seconds'],300);self.assertGreaterEqual(r['charged_active_wall_seconds'],200)
 def test_slots_pairing_new_seeds(self):
  s=Q['slots'];self.assertEqual([x['seed']for x in s[:2]],[2026100700,2026100701]);self.assertEqual(len(s),22)
  for p in range(10):self.assertEqual([x['seed']for x in s if x.get('pair')==p],[2026100710+p]*2)
if __name__=='__main__':unittest.main()
