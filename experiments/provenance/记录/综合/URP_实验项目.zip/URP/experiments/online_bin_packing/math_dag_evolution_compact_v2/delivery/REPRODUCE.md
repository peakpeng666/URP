# Evidence and reproduction

Start with summary.json. Its evidence and per-request links are relative to the URP root. The full report retains run-relative score observation paths. The manifest explicitly unions prior accepted evidence; deduplicate identical paths when combining packages and do not count shared stages as repeated executions.

The complete source, generated JSON, fixed data, event/assignment evidence and dependency hashes are retained. Weights, runtime/dependency environments, bytecode caches, private authorization and review records are excluded. Rebuild the pinned official model/runtime and NumPy environment, preserve the sibling source layout, then create a fresh environment-specific integrity snapshot and a new user-controlled one-use authorization before any new execution. Historical runs must not be overwritten or automatically replayed.

Model strings are bounded mathematical data interpreted by a fixed dispatcher, never Python source. The evaluator/scoring/backend/resource code is unchanged from the reviewed base; source_delta.json identifies the compact contract, data/seed and reporting changes. The larger published formula remains a fixed post-commit reference outside the generated four-node search space.

Historical preparation documents describe the prospective plan; terminal reports state what actually ran. The first stale-expectation offline regression log and its corrected final regression are both retained. No extra model or numerical experiment was used to produce the public projection.
