# Compact two-generation teaching comparison v2 — prospective only

Canonical protocol.json fixes22requests:2 shared initializations +10 evolution +10 independent-control. N=2,2generations,five operators,FF/BF seeds,paired newseeds,120score ceiling,208ledger,duplicate retention,ties and durable winner commitment all follow acceptedv1. No model/scoreworker has run for thisversion.

Changes are limited to the validated4node/3constant/64character generatedprofile, equally public handwrittenexample,newseeds/newhistoricalfragments,copy diagnostics,and preparation debit. source_delta.json gives executable diffs. The interpreter,scoring checker,backend,tokenizer andguard/Budget are unchanged. Larger publishedformula stays postcommit reference-only; valid examplecopies remain eligible and scored, not removed after seeing outcomes.

Design:historical_design_5k[2],[3]. Validation:test_dataset_1k[1],test_dataset_5k[1]. Each usesitems[128:256] crossed with100/500capacity. Original absolute items retained. Four sourceidentities andfragments differ from theoldselection; thetwo validationwholeinstances already participated in earlierbaseline runs. This isexploratory publichistoricalreuse, not independentnewtest, privateholdout or pretraining-unseen data. Logical validationisolation applies tothisrunonly.

Both winners must be durably committed before validationloads. No validationfeedback,promptrevision,repair,reselection orresampling. A context/resource/infrastructure/integrity stop preserves incompletepairs andnot_runrows. Final120CPU/120wall overheadreserve andfullper-calllimits remain; no latecall gets smallerlimits.

Total5900CPU/3660activewall chargedceiling unchanged. Preparation debit300CPU/200wall leaves5600/3460formal. Stable-ID knownprerequisites currently249.238835CPU seconds; currentfreeze/testoverhead separatelyrecorded. Historical22research actual2443.875398CPU seconds remains aseparateresearchstage. Sharedprerequisites countonce inprojectwidemeasuredcosts; chargedreserves mustnotbesummed asmeasuredcosts. Unknownediting/audit/import/persistenceportions aredisclosed, notzero orproved bounded bydebit.

Report observedtopologycopies,exactexampleidentities,constant-onlyedits,designassignment signatures,and actualgeneration1-parentuse ingeneration2. No automaticinnovation orsemantic-equivalence claim. Seed-inclusive andgenerated-onlyresults separate; equalcalls donotmeanequaltokens/CPU. One small seededsearch perarm cannot supportsignificance ororiginalEoHfullreproduction.

Offline regression112tests passed, includingactual Budget withthisprotocol. Firstregressionlogretained:three stalev1ID/seedexpectations andone200→300budgetboundary were corrected intest expectations, withoutchangingoperator/selection/runtimebehavior. Nomodel,tokenizer,NumPygraphinterpreter orscoreworker ran inthosemocktests. Finalexactfreeze andnewone-use authorization required before actualexecution.
