"""One prospective source/request snapshot; hashes assets without executing them."""
import ast,hashlib,json,pathlib,sys,time
ROOT=pathlib.Path(__file__).resolve().parent
OLD=ROOT.parent/'math_dag_evolution_v1'
def sha(p):
 h=hashlib.sha256()
 with pathlib.Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def main():
 start=time.monotonic();cpu=time.process_time()
 expected='036c265d2ba88647a66460ab816609c217d6170de7eb0348f37b73523d3bab39'
 if sha(OLD/'final_freeze.json')!=expected:raise ValueError('preceding immutable study')
 old=json.loads((OLD/'final_freeze.json').read_text());assets=dict(old['assets'])
 # Bind reused seed and worker/source identities, in addition to exact old dependency assets.
 for rel,want in old['files'].items():
  if sha(OLD/rel)!=want:raise ValueError('old frozen file changed')
  assets[str(OLD/rel)]=want
 assets[str(OLD/'final_freeze.json')]=expected
 diag=ROOT.parent/'math_dag_interface_v2_1'
 if sha(diag/'final_freeze.json')!='d19bf8f5befdfefda8e49298b1706b0e0b9e96394ac7a19532cda81f7f64f134':raise ValueError('compact diagnostic identity')
 df=json.loads((diag/'final_freeze.json').read_text())
 for rel,want in df['files'].items():
  if sha(diag/rel)!=want:raise ValueError('compact diagnostic file changed')
  assets[str(diag/rel)]=want
 for path in [diag/'final_freeze.json',diag/'runs/dag_interface_v2_1_20261004_01/report.json',diag/'runs/dag_interface_v2_1_20261004_01/generation/fixed_transcription/effective_grammar.gbnf',ROOT.parent/'paper_baseline_v1/data/historical_numeric.json',OLD/'runs/dag_twogen_20261004_01/report.json']:
  assets[str(path)]=sha(path)
 for path,want in assets.items():
  if sha(path)!=want:raise ValueError('dependency asset changed: '+path)
 for p in ROOT.rglob('*.py'):ast.parse(p.read_text())
 files={str(p.relative_to(ROOT)):sha(p) for p in sorted(ROOT.rglob('*')) if p.is_file() and p.name!='final_freeze.json' and p.relative_to(ROOT).parts[0] not in {'runs','.authorization_uses'}}
 importable=sorted(k for k in files if pathlib.Path(k).suffix in {'.py','.pyc','.so','.pyd'})
 d={'identity':'p3_compact_dag_twogen_v2_frozen','scope':'Prospective22-request compact teaching comparison; no execution authority granted by this file.','files':files,'assets':assets,'symlinks':old['symlinks'],'importable_files':importable,'python_executable':old['python_executable'],'python_executable_sha256':old['python_executable_sha256'],'math_evaluator_freeze':old['math_evaluator_freeze'],'model_requests_max':22,'score_requests_max':120,'ledger_rows':208,'schema_sha256':sha(ROOT/'generation_schema_v2.json'),'protocol_sha256':sha(ROOT/'protocol.json'),'case_panel_sha256':sha(ROOT/'data/panel.json'),'source_study_freeze_sha256':expected,'snapshot_hash_cpu_seconds':time.process_time()-cpu,'snapshot_hash_wall_seconds':time.monotonic()-start}
 with (ROOT/'final_freeze.json').open('x') as f:json.dump(d,f,indent=2);f.write('\n')
 print(json.dumps({'sha256':sha(ROOT/'final_freeze.json'),'files':len(files),'assets':len(assets),'snapshot_hash_cpu_seconds':d['snapshot_hash_cpu_seconds'],'snapshot_hash_wall_seconds':d['snapshot_hash_wall_seconds']}))
if __name__=='__main__':main()
