"""Frozen tokenize-only extraction; candidate text is never compiled or executed."""
import io
import token
import tokenize


def extract_initial_function(source):
    """Take a prefix only if tokenize emits a suite DEDENT before a real top-level token.

    Does not treat synthetic EOF DEDENT as a model-produced function boundary.
    It never fixes an interior syntax error, reindents, closes brackets or strings,
    drops interior statements, or evaluates code. Tokenization may stop at the first
    observed boundary, so later malformed suffixes do not invalidate an earlier boundary.
    """
    unchanged = {"source": source, "boundary_observed": False, "changed": False,
                 "reason": "no_observed_top_level_boundary", "boundary_line": None,
                 "rule": "tokenize_dedent_then_real_top_level_token_v1"}
    if not source.startswith("def sort_numbers(values):\n"):
        return dict(unchanged, reason="unexpected_function_prefix")
    depth = 0
    seen_indent = False
    pending = False
    ignored = {tokenize.NL, tokenize.NEWLINE, tokenize.COMMENT, tokenize.ENCODING}
    try:
        for item in tokenize.generate_tokens(io.StringIO(source).readline):
            if item.type == tokenize.ERRORTOKEN:
                return dict(unchanged, reason="lexical_error_before_boundary", error_type="ERRORTOKEN")
            if item.type == tokenize.INDENT:
                depth += 1
                seen_indent = True
                continue
            if item.type == tokenize.DEDENT:
                depth -= 1
                if seen_indent and depth == 0:
                    pending = True
                continue
            if not pending or item.type in ignored:
                continue
            if item.type == tokenize.ENDMARKER:
                return dict(unchanged, reason="eof_only_dedent")
            if item.start[1] != 0 or item.type == tokenize.ERRORTOKEN:
                return dict(unchanged, reason="ambiguous_boundary_token")
            prefix = "".join(source.splitlines(keepends=True)[:item.start[0] - 1])
            return {"source": prefix, "boundary_observed": True, "changed": prefix != source,
                    "reason": "real_top_level_token_after_suite", "boundary_line": item.start[0],
                    "boundary_token_type": token.tok_name[item.type],
                    "rule": "tokenize_dedent_then_real_top_level_token_v1"}
    except (tokenize.TokenError, IndentationError, SyntaxError) as exc:
        return dict(unchanged, reason="lexical_error_before_boundary", error_type=type(exc).__name__)
    return unchanged
