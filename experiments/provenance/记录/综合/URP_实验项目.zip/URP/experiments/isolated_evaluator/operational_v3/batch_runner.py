"""Approval-gated v3 ledger and accounting. Source is guest runtime data only."""
import argparse
import collections
import json
import os
import platform
import importlib.metadata
import pathlib
import resource
import time

from adapter import admission, digest, load_cases, load_forms, make_request
from checker import classify
from integrity import HERE, bounded_json, file_hash, verify_approval, verify_freeze

UNKNOWN = {'pending', 'resource_unresolved', 'infrastructure_error',
           'not_run_budget_exhausted', 'not_run_infrastructure_stop'}


def run_one(request):
    from one_request import launch
    return launch(request)


def complete_ledger(forms, cases, scope):
    rows = []
    for form in forms:
        gate = admission(form['source'])
        for case in cases:
            status = 'pending'
            if form['variant'] not in scope:
                status = 'not_run_scope_unapproved'
            elif gate['stage'] == 'structural_rejection':
                status = 'not_run_structural_rejection'
            elif gate['stage'] == 'grammar_rejection':
                status = 'not_run_grammar_rejection'
            rows.append({k: form[k] for k in ('form_id', 'round', 'candidate_id', 'prompt_id', 'variant')} | {
                'fixture_id': case['id'], 'fixture_valid': case['valid'],
                'source_sha256': digest(form['source'].encode()), 'admission': gate,
                'status': status, 'conformant': None})
    return rows


def execution_metadata(observation):
    keys = ('returncode', 'worker_pid', 'supervisor_pid', 'termination', 'guest_entry_observed',
            'wall_seconds', 'worker_user_seconds', 'worker_sys_seconds', 'worker_peak_rss_kib_cumulative',
            'supervisor_effective_rlimit_as', 'supervisor_peak_rss_kib', 'protocol_error',
            'worker_unreaped', 'source_sha256', 'input_sha256')
    result = {k: observation.get(k) for k in keys}
    worker = observation.get('worker') or {}
    result.update(worker_status=worker.get('status'), worker_fuel_remaining=worker.get('fuel_remaining'),
                  worker_effective_rlimits=worker.get('effective_rlimits'))
    payload = worker.get('payload')
    result['candidate_completion_reported'] = (type(payload) is dict and payload.get('stage') == 'candidate_completed')
    return result


def compact(observation):
    result = execution_metadata(observation)
    payload = (observation.get('worker') or {}).get('payload')
    if payload is not None:
        encoded = json.dumps(payload, ensure_ascii=True, separators=(',', ':'), allow_nan=False).encode()
        result['payload_sha256'] = digest(encoded)
        result['payload_preview'] = encoded[:256].decode('ascii')
    return result


def summarize(forms, cases, rows, scope):
    outcomes = []
    for form in forms:
        selected = [r for r in rows if r['form_id'] == form['form_id']]
        states = [r['status'] for r in selected]
        gate = admission(form['source'])
        if form['variant'] not in scope:
            conclusion = 'scope_unapproved'
        elif gate['stage'] in ('structural_rejection', 'grammar_rejection'):
            conclusion = gate['stage']
        elif states and all(s == 'case_conformant' for s in states):
            conclusion = 'all_required_cases_conformant'
        elif any(s == 'case_nonconformant' for s in states):
            conclusion = 'observed_semantic_nonconformant'
        else:
            conclusion = 'incomplete_unknown'
        outcomes.append({k: form[k] for k in ('form_id', 'round', 'candidate_id', 'prompt_id', 'variant')} | {
            'source_sha256': digest(form['source'].encode()), 'conclusion': conclusion,
            'required_cases': len(cases),
            'eligible_cases': len(cases) if gate['stage'] == 'eligible_pending_guest_gate' and form['variant'] in scope else 0,
            'clean_semantic_measurements': sum(s in ('case_conformant', 'case_nonconformant') for s in states),
            'case_conformant': states.count('case_conformant'),
            'case_nonconformant': states.count('case_nonconformant'),
            'resource_unresolved': states.count('resource_unresolved'),
            'unknown_cases': sum(s in UNKNOWN for s in states),
            'case_coverage_complete': not any(s in UNKNOWN for s in states)})
    groups = []
    for key in sorted({(f['round'], f['prompt_id'], f['variant']) for f in forms}):
        group = [o for o in outcomes if (o['round'], o['prompt_id'], o['variant']) == key]
        counts = collections.Counter(o['conclusion'] for o in group)
        n = len(group)
        passed = counts['all_required_cases_conformant']
        unknown = counts['incomplete_unknown']
        unapproved = counts['scope_unapproved']
        complete = not unapproved and all(o['case_coverage_complete'] for o in group)
        groups.append({'round': key[0], 'prompt_id': key[1], 'variant': key[2],
                       'original_denominator': n, 'passed': passed,
                       'eligible_cases': sum(o['eligible_cases'] for o in group),
                       'clean_semantic_measurements': sum(o['clean_semantic_measurements'] for o in group),
                       'case_coverage_interpretation': 'resolution of admitted cases; rejected forms have no executed semantic measurements',
                       'structural_rejected': counts['structural_rejection'],
                       'grammar_rejected': counts['grammar_rejection'],
                       'observed_semantic_nonconformant': counts['observed_semantic_nonconformant'],
                       'incomplete_unknown': unknown, 'scope_unapproved': unapproved,
                       'case_coverage_complete': complete,
                       'pass_fraction': passed / n if complete else None,
                       'pass_fraction_lower_bound': passed / n if not unapproved else None,
                       'pass_fraction_upper_bound': (passed + unknown) / n if not unapproved else None})
    duplicates = collections.defaultdict(list)
    for form in forms:
        duplicates[digest(form['source'].encode())].append(form['form_id'])
    return {'forms': outcomes, 'groups': groups,
            'identical_source_groups': [{'source_sha256': k, 'form_ids': v} for k, v in duplicates.items() if len(v) > 1],
            'primary_raw_records': sum(f['variant'] == 'raw' for f in forms),
            'secondary_existing_forms': sum(f['variant'] == 'extracted' for f in forms),
            'pooled_raw_count_is_descriptive_only': True,
            'extracted_forms_are_not_independent_new_records': True}


def journal(output_dir, event):
    if output_dir:
        with (output_dir / 'events.jsonl').open('a') as stream:
            stream.write(json.dumps(event, ensure_ascii=True, allow_nan=False) + '\n')
            stream.flush()
            os.fsync(stream.fileno())


def run_forms(forms, cases, scope, *, output_dir, executor=run_one, integrity_check=lambda: None,
              cpu_budget=600, wall_budget=900, clock=time.monotonic, started_at=None):
    start = clock() if started_at is None else started_at
    self_cpu = time.process_time()
    rows = complete_ledger(forms, cases, scope)
    output_dir.mkdir(parents=True, exist_ok=False)
    (output_dir / 'initial_ledger.json').write_text(json.dumps(rows, indent=2))
    (output_dir / 'observations').mkdir()
    by_form = {f['form_id']: f for f in forms}
    by_case = {c['id']: c for c in cases}
    cpu = 0.0
    dispatches = 0
    stop = None
    integrity_wall = integrity_cpu = 0.0

    def verify_now():
        nonlocal integrity_wall, integrity_cpu
        before_wall, before_cpu = clock(), time.process_time()
        try:
            integrity_check()
        finally:
            integrity_wall += clock() - before_wall
            integrity_cpu += time.process_time() - before_cpu

    for row in rows:
        if row['status'] != 'pending':
            continue
        if cpu_budget - cpu < 2 or wall_budget - (clock() - start) < 6:
            stop = 'budget_exhausted'
            break
        try:
            verify_now()
        except Exception as exc:
            row['status'] = 'infrastructure_error'
            row['reason'] = 'integrity_check_failed'
            row['error'] = type(exc).__name__ + ': ' + str(exc)[:400]
            stop = 'integrity_failure'
            journal(output_dir, {'event': 'integrity_failure', 'row': row})
            break
        # Never consume the full request reservation on preceding hash work.
        if cpu_budget - cpu < 2 or wall_budget - (clock() - start) < 6:
            stop = 'budget_exhausted'
            break
        form, case = by_form[row['form_id']], by_case[row['fixture_id']]
        dispatches += 1
        row['request_index'] = dispatches
        journal(output_dir, {'event': 'start', 'request_index': dispatches,
                             'form_id': row['form_id'], 'fixture_id': row['fixture_id'],
                             'worker_cpu_before': cpu, 'elapsed_before': clock() - start})
        try:
            request = make_request(form['source'], case)
            observation = executor(request)
            row['observation_summary'] = execution_metadata(observation)
            cpu += observation.get('worker_user_seconds', 0) + observation.get('worker_sys_seconds', 0)
            row['observation_summary'] = compact(observation)
            if (observation.get('source_sha256') != request['source_sha256']
                    or observation.get('input_sha256') != request['input_sha256']):
                row['status'], row['conformant'], row['reason'] = 'infrastructure_error', None, 'request_observation_hash_mismatch'
            else:
                row['status'], row['conformant'], row['reason'] = classify(observation, case)
            path = output_dir / 'observations' / f'{dispatches:06d}.json'
            with path.open('x') as stream:
                json.dump(observation, stream, ensure_ascii=True, allow_nan=False)
            row['observation_file'] = str(path.relative_to(output_dir))
            if row['status'] == 'infrastructure_error':
                stop = 'infrastructure_error'
        except Exception as exc:
            row['status'] = 'infrastructure_error'
            row['conformant'] = None
            row['error'] = type(exc).__name__ + ': ' + str(exc)[:400]
            stop = 'infrastructure_error'
        journal(output_dir, {'event': 'complete', 'request_index': dispatches, 'row': row})
        if stop:
            break
    for row in rows:
        if row['status'] == 'pending':
            row['status'] = 'not_run_budget_exhausted' if stop == 'budget_exhausted' else 'not_run_infrastructure_stop'
    try:
        verify_now()
        final_integrity = 'verified'
    except Exception as exc:
        final_integrity = 'failed'
        stop = 'final_integrity_failure'
        journal(output_dir, {'event': 'final_integrity_failure', 'error': type(exc).__name__ + ': ' + str(exc)[:400]})
    elapsed = clock() - start
    report = summarize(forms, cases, rows, scope)
    marked = [r for r in rows if r.get('observation_summary', {}).get('guest_entry_observed') is True]
    completed = [r for r in rows if r.get('observation_summary', {}).get('candidate_completion_reported') is True]
    report.update(rows=rows, dispatches=dispatches,
                  execution_count_caveat='Worker and completion counts use returned evidence; dispatched executor exceptions without evidence retain unknown launch/invocation state',
                  requests_without_returned_execution_evidence=sum('request_index' in r and 'error' in r and 'observation_summary' not in r for r in rows),
                  workers_started=sum(r.get('observation_summary', {}).get('worker_pid') is not None for r in rows),
                  requests_with_guest_call_marker=len(marked),
                  source_forms_with_guest_call_marker=len({r['form_id'] for r in marked}),
                  original_records_with_guest_call_marker=len({(r['round'], r['candidate_id']) for r in marked}),
                  candidate_completions_reported=len(completed),
                  clean_schema_validated_completions=sum(r['status'] in ('case_conformant', 'case_nonconformant') for r in rows),
                  source_forms_with_candidate_completion=len({r['form_id'] for r in completed}),
                  original_records_with_candidate_completion=len({(r['round'], r['candidate_id']) for r in completed}),
                  guest_marker_caveat='Host reached the Wasm call; not proof of a candidate instruction or invocation',
                  worker_cpu_seconds=cpu, supervisor_cpu_seconds=time.process_time() - self_cpu,
                  elapsed_seconds=elapsed, integrity_wall_seconds=integrity_wall, integrity_cpu_seconds=integrity_cpu,
                  stop_reason=stop, final_integrity=final_integrity,
                  result_certification_valid=final_integrity == 'verified' and stop != 'integrity_failure',
                  budgets={'worker_cpu_seconds': cpu_budget, 'wall_seconds': wall_budget},
                  accounting_overshoot={'worker_cpu_seconds': max(0, cpu - cpu_budget), 'wall_seconds': max(0, elapsed - wall_budget)},
                  supervisor_peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                  supervisor_effective_rlimit_as=resource.getrlimit(resource.RLIMIT_AS))
    if not report['result_certification_valid']:
        for form in report['forms']:
            form['observed_conclusion_before_integrity_failure'] = form['conclusion']
            form['conclusion'] = 'uncertified_integrity_failure'
        for group in report['groups']:
            group['observed_passed_before_integrity_failure'] = group['passed']
            group['passed'] = None
            group['certification_valid'] = False
            group['pass_fraction'] = None
            group['pass_fraction_lower_bound'] = None
            group['pass_fraction_upper_bound'] = None
    else:
        for group in report['groups']:
            group['certification_valid'] = True
    (output_dir / 'report.json').write_text(json.dumps(report, indent=2, allow_nan=False))
    return report


def claim_authorization(approval, output_dir, usage_dir):
    usage_dir.mkdir(parents=True, exist_ok=True)
    marker = usage_dir / (approval['batch_id'] + '.json')
    with marker.open('x') as stream:
        json.dump({'batch_id': approval['batch_id'], 'operational_freeze_sha256': approval['operational_freeze_sha256'],
                   'output_dir': str(output_dir), 'status': 'claimed_once_before_batch'}, stream)
    return marker


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--approved-batch', type=pathlib.Path, required=True)
    parser.add_argument('--output', type=pathlib.Path, required=True)
    args = parser.parse_args()
    started = time.monotonic()
    self_cpu = time.process_time()
    freeze_path = HERE / 'operational_freeze.json'
    freeze_digest = file_hash(freeze_path)
    approval = bounded_json(args.approved_batch, 4096)
    scope = verify_approval(approval, freeze_digest)
    verify_freeze(freeze_path, freeze_digest)  # BEFORE any generated source record is loaded.
    cfg = bounded_json(HERE / 'protocol.json', 16384)
    if cfg['execution_gate'] != 'requires_explicit_external_matching_freeze_authorization':
        raise PermissionError('unexpected execution state')
    if args.output.exists():
        raise FileExistsError(args.output)
    forms, cases = load_forms(), load_cases()
    claim_authorization(approval, args.output, HERE / 'authorization_uses')
    report = run_forms(forms, cases, scope, output_dir=args.output,
                       integrity_check=lambda: verify_freeze(freeze_path, freeze_digest),
                       cpu_budget=cfg['batch_worker_cpu_seconds'], wall_budget=cfg['batch_wall_seconds'], started_at=started)
    report.update(protocol_id=cfg['protocol_id'], operational_freeze_sha256=freeze_digest,
                  batch_id=approval['batch_id'], authorized_scope=approval['scope'],
                  whole_batch_wall_seconds=time.monotonic() - started,
                  whole_batch_supervisor_cpu_seconds=time.process_time() - self_cpu,
                  runtime_versions={'host_python': platform.python_version(), 'guest_python': '3.14.0 (frozen prototype provenance)', 'wasmtime': importlib.metadata.version('wasmtime'), 'componentize_py': importlib.metadata.version('componentize-py')})
    (args.output / 'report.json').write_text(json.dumps(report, indent=2, allow_nan=False))
    print(json.dumps({k: report[k] for k in ('groups', 'dispatches', 'stop_reason', 'result_certification_valid')}))

if __name__ == '__main__':
    main()
