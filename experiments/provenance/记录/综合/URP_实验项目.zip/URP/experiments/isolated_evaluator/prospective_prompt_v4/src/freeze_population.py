"""Freeze ten selected runtime-data sources after a separately authorized generation."""
import argparse
import json
import os
import pathlib
from v3_reuse import HERE,bounded_json,strict_json,file_hash,digest,admission
from evaluation_integrity import verify_preparation
from extract import extract_initial_function
from generation_integrity import jobs


def read_records(path):
    records=[]
    if not path.exists():return records
    with path.open('rb') as stream:
        while True:
            line=stream.readline(2*1024**2+1)
            if not line:break
            if len(line)>2*1024**2 or not line.endswith(b'\n'):raise ValueError('record line bound or incomplete line')
            records.append(strict_json(line))
            if len(records)>10:raise ValueError('extra generation records')
    return records


def derive_forms(output,preparation_digest,config):
    status=bounded_json(output/'process_status.json',65536)
    ledger=bounded_json(output/'generation_ledger.json',1024**2)
    if status.get('integrity_before')!='passed' or status.get('integrity_after')!='passed' or status.get('cleanup_complete') is not True:
        raise ValueError('generation integrity or cleanup not certified')
    if (ledger.get('journal_integrity') is not True or status.get('journal_integrity') is not True
            or ledger.get('preparation_freeze_sha256')!=preparation_digest
            or status.get('preparation_freeze_sha256')!=preparation_digest
            or status.get('batch_id')!=ledger.get('batch_id')):
        raise ValueError('generation journal or preparation identity mismatch')
    if ledger.get('generation_retry_count')!=0 or ledger.get('generated_code_executed') is not False:
        raise ValueError('unexpected generation scope')
    planned=jobs(config);slots=ledger.get('slots');records=read_records(output/'raw_generations.jsonl')
    if type(slots) is not list or len(slots)!=10:raise ValueError('missing complete ten-slot ledger')
    ids=[r.get('id') for r in records]
    if len(set(ids))!=len(ids):raise ValueError('duplicate raw generation record')
    if set(ids)-{j['id'] for j in planned}:raise ValueError('unexpected raw generation identity')
    by_id={r['id']:(i+1,r) for i,r in enumerate(records)};forms=[]
    for slot,job in zip(slots,planned):
        if any(slot.get(k)!=job[k] for k in ('id','seed','prompt_id','slot')):raise ValueError('generation slot order mismatch')
        state=slot.get('state')
        if state not in ('complete','generation_error','interrupted','not_started'):raise ValueError('unknown generation state')
        form={'form_id':job['id']+'/selected','round':'prospective_v4','candidate_id':job['id'],
              'prompt_id':job['prompt_id'],'seed':job['seed'],'variant':'selected',
              'generation_status':state,'source':'','source_sha256':None,
              'raw_source_sha256':None,'raw_admission':None,'extraction':None}
        record_pair=by_id.get(job['id'])
        if state=='complete':
            if record_pair is None or slot.get('raw_record_line')!=record_pair[0]:raise ValueError('completed slot missing exact record')
            record=record_pair[1]
            if record.get('status')!='generated' or record.get('seed')!=job['seed'] or record.get('prompt_id')!=job['prompt_id']:
                raise ValueError('record identity or status mismatch')
            prompt=(HERE/config['prompts'][job['prompt_id']]).read_text()
            source=record.get('candidate_source');continuation=record.get('continuation')
            if record.get('prompt')!=prompt or type(continuation) is not str or source!=prompt+continuation:
                raise ValueError('source was not exact frozen prompt plus continuation')
            if len(source.encode())>65536:raise ValueError('source retention limit exceeded')
            extraction=extract_initial_function(source)
            if extraction!=record.get('extraction'):raise ValueError('extraction differs from frozen tokenizer rule')
            chosen=extraction['source']
            if record.get('candidate_source_sha256')!=digest(source.encode()) or record.get('extracted_source_sha256')!=digest(chosen.encode()):
                raise ValueError('generation source hash mismatch')
            for label,key,text in [('raw','raw_source_path',source),('extracted','extracted_source_path',chosen)]:
                expected_path=f"sources/{job['id']}.{label}.txt"
                if record.get(key)!=expected_path or (output/expected_path).read_bytes()!=text.encode():
                    raise ValueError('retained source artifact mismatch')
            form.update(generation_status='generated',source=chosen,source_sha256=digest(chosen.encode()),
                        raw_source_sha256=digest(source.encode()),raw_admission=admission(source),extraction=extraction)
        elif record_pair:
            line,record=record_pair
            allowed_statuses={'generation_error'} if state=='generation_error' else {'generated','generation_error'} if state=='interrupted' else set()
            if (slot.get('raw_record_line')!=line or record.get('status') not in allowed_statuses
                    or record.get('seed')!=job['seed'] or record.get('prompt_id')!=job['prompt_id']):
                raise ValueError('unavailable slot has inconsistent raw record')
            # A durable raw row without a completion event remains unavailable.
            # Keep its evidence frozen, but NEVER promote its source to scoring.
        elif slot.get('raw_record_line') is not None:
            raise ValueError('slot refers to absent record')
        forms.append(form)
    return forms


def freeze(output,preparation_digest,destination):
    verify_preparation(HERE/'preparation_freeze.json',preparation_digest)
    config=bounded_json(HERE/'generation_config.json',32768)
    forms=derive_forms(output,preparation_digest,config)
    files={}
    for p in sorted(output.rglob('*')):
        if p.is_symlink():raise ValueError('generation evidence may not contain symlinks')
        if p.is_file():files[os.path.relpath(p,HERE)]=file_hash(p)
    document={'protocol_id':'urp-p2-paired-contract-prompt-v4-prospective-20261004',
              'state':'exact_population_frozen_no_evaluation_authorization',
              'preparation_freeze_sha256':preparation_digest,'generation_output_root':os.path.relpath(output,HERE),
              'generation_evidence_files':files,'scheduled_generations':10,'selected_forms_per_generation':1,
              'forms':forms}
    with destination.open('x') as stream:json.dump(document,stream,indent=2,allow_nan=False);stream.write('\n')
    return {'population_freeze_sha256':file_hash(destination),'forms':len(forms),
            'available_sources':sum(f['generation_status']=='generated' for f in forms)}


def main():
    p=argparse.ArgumentParser();p.add_argument('--generation-output',type=pathlib.Path,required=True)
    p.add_argument('--preparation-freeze-sha256',required=True);p.add_argument('--output',type=pathlib.Path,required=True)
    a=p.parse_args();print(json.dumps(freeze(a.generation_output,a.preparation_freeze_sha256,a.output)))

if __name__=='__main__':main()
