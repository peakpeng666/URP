"""V4 population adapter over the byte-identical reviewed v3 run_forms function."""
import json
import resource
import time
from v3_reuse import run_one, execution_metadata, compact, journal, make_request, classify
from population import complete_ledger, summarize

def run_forms(forms, cases, scope, *, output_dir, executor=run_one, integrity_check=lambda: None,
              cpu_budget=600, wall_budget=900, clock=time.monotonic, started_at=None):
    start = clock() if started_at is None else started_at
    self_cpu = time.process_time()
    rows = complete_ledger(forms, cases, scope)
    output_dir.mkdir(parents=True, exist_ok=False)
    (output_dir / 'initial_ledger.json').write_text(json.dumps(rows, indent=2))
    (output_dir / 'observations').mkdir()
    by_form = {f['form_id']: f for f in forms}
    by_case = {c['id']: c for c in cases}
    cpu = 0.0
    dispatches = 0
    stop = None
    integrity_wall = integrity_cpu = 0.0

    def verify_now():
        nonlocal integrity_wall, integrity_cpu
        before_wall, before_cpu = clock(), time.process_time()
        try:
            integrity_check()
        finally:
            integrity_wall += clock() - before_wall
            integrity_cpu += time.process_time() - before_cpu

    for row in rows:
        if row['status'] != 'pending':
            continue
        if cpu_budget - cpu < 2 or wall_budget - (clock() - start) < 6:
            stop = 'budget_exhausted'
            break
        try:
            verify_now()
        except Exception as exc:
            row['status'] = 'infrastructure_error'
            row['reason'] = 'integrity_check_failed'
            row['error'] = type(exc).__name__ + ': ' + str(exc)[:400]
            stop = 'integrity_failure'
            journal(output_dir, {'event': 'integrity_failure', 'row': row})
            break
        # Never consume the full request reservation on preceding hash work.
        if cpu_budget - cpu < 2 or wall_budget - (clock() - start) < 6:
            stop = 'budget_exhausted'
            break
        form, case = by_form[row['form_id']], by_case[row['fixture_id']]
        dispatches += 1
        row['request_index'] = dispatches
        journal(output_dir, {'event': 'start', 'request_index': dispatches,
                             'form_id': row['form_id'], 'fixture_id': row['fixture_id'],
                             'worker_cpu_before': cpu, 'elapsed_before': clock() - start})
        try:
            request = make_request(form['source'], case)
            observation = executor(request)
            row['observation_summary'] = execution_metadata(observation)
            cpu += observation.get('worker_user_seconds', 0) + observation.get('worker_sys_seconds', 0)
            row['observation_summary'] = compact(observation)
            if (observation.get('source_sha256') != request['source_sha256']
                    or observation.get('input_sha256') != request['input_sha256']):
                row['status'], row['conformant'], row['reason'] = 'infrastructure_error', None, 'request_observation_hash_mismatch'
            else:
                row['status'], row['conformant'], row['reason'] = classify(observation, case)
            path = output_dir / 'observations' / f'{dispatches:06d}.json'
            with path.open('x') as stream:
                json.dump(observation, stream, ensure_ascii=True, allow_nan=False)
            row['observation_file'] = str(path.relative_to(output_dir))
            if row['status'] == 'infrastructure_error':
                stop = 'infrastructure_error'
        except Exception as exc:
            row['status'] = 'infrastructure_error'
            row['conformant'] = None
            row['error'] = type(exc).__name__ + ': ' + str(exc)[:400]
            stop = 'infrastructure_error'
        journal(output_dir, {'event': 'complete', 'request_index': dispatches, 'row': row})
        if stop:
            break
    for row in rows:
        if row['status'] == 'pending':
            row['status'] = 'not_run_budget_exhausted' if stop == 'budget_exhausted' else 'not_run_infrastructure_stop'
    try:
        verify_now()
        final_integrity = 'verified'
    except Exception as exc:
        final_integrity = 'failed'
        stop = 'final_integrity_failure'
        journal(output_dir, {'event': 'final_integrity_failure', 'error': type(exc).__name__ + ': ' + str(exc)[:400]})
    elapsed = clock() - start
    report = summarize(forms, cases, rows, scope)
    marked = [r for r in rows if r.get('observation_summary', {}).get('guest_entry_observed') is True]
    completed = [r for r in rows if r.get('observation_summary', {}).get('candidate_completion_reported') is True]
    report.update(rows=rows, dispatches=dispatches,
                  execution_count_caveat='Worker and completion counts use returned evidence; dispatched executor exceptions without evidence retain unknown launch/invocation state',
                  requests_without_returned_execution_evidence=sum('request_index' in r and 'error' in r and 'observation_summary' not in r for r in rows),
                  workers_started=sum(r.get('observation_summary', {}).get('worker_pid') is not None for r in rows),
                  requests_with_guest_call_marker=len(marked),
                  source_forms_with_guest_call_marker=len({r['form_id'] for r in marked}),
                  original_records_with_guest_call_marker=len({(r['round'], r['candidate_id']) for r in marked}),
                  candidate_completions_reported=len(completed),
                  clean_schema_validated_completions=sum(r['status'] in ('case_conformant', 'case_nonconformant') for r in rows),
                  source_forms_with_candidate_completion=len({r['form_id'] for r in completed}),
                  original_records_with_candidate_completion=len({(r['round'], r['candidate_id']) for r in completed}),
                  guest_marker_caveat='Host reached the Wasm call; not proof of a candidate instruction or invocation',
                  worker_cpu_seconds=cpu, supervisor_cpu_seconds=time.process_time() - self_cpu,
                  elapsed_seconds=elapsed, integrity_wall_seconds=integrity_wall, integrity_cpu_seconds=integrity_cpu,
                  stop_reason=stop, final_integrity=final_integrity,
                  result_certification_valid=final_integrity == 'verified' and stop != 'integrity_failure',
                  budgets={'worker_cpu_seconds': cpu_budget, 'wall_seconds': wall_budget},
                  accounting_overshoot={'worker_cpu_seconds': max(0, cpu - cpu_budget), 'wall_seconds': max(0, elapsed - wall_budget)},
                  supervisor_peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                  supervisor_effective_rlimit_as=resource.getrlimit(resource.RLIMIT_AS))
    if not report['result_certification_valid']:
        for form in report['forms']:
            form['observed_conclusion_before_integrity_failure'] = form['conclusion']
            form['conclusion'] = 'uncertified_integrity_failure'
        for group in report['groups']:
            group['observed_passed_before_integrity_failure'] = group['passed']
            group['passed'] = None
            group['certification_valid'] = False
            group['pass_fraction'] = None
            group['pass_fraction_lower_bound'] = None
            group['pass_fraction_upper_bound'] = None
    else:
        for group in report['groups']:
            group['certification_valid'] = True
    (output_dir / 'report.json').write_text(json.dumps(report, indent=2, allow_nan=False))
    return report
