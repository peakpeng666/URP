"""One approved prospective population; uses unchanged v3 Wasm execution limits."""
import argparse
import importlib.metadata
import json
import pathlib
import platform
import time
from v3_reuse import HERE, bounded_json, file_hash, digest, admission
from evaluation_integrity import verify_preparation, verify_population, verify_evaluation_approval
from evaluation_core import run_forms
from population import load_cases, panel_and_pair_analysis


def load_forms(pop):
    from generation_integrity import jobs
    config=bounded_json(HERE/'generation_config.json',32768)
    planned=jobs(config)
    forms=pop['forms']
    if type(forms) is not list or len(forms)!=10:raise ValueError('expected all ten selected forms')
    # Generation job order is also the per-case paired evaluation order.
    for f,job in zip(forms,planned):
        if f['candidate_id']!=job['id'] or f['seed']!=job['seed'] or f['prompt_id']!=job['prompt_id']:
            raise ValueError('population order/identity mismatch')
        if f['variant']!='selected' or f['round']!='prospective_v4' or f['form_id']!=job['id']+'/selected':
            raise ValueError('population source-form mismatch')
        if type(f['source']) is not str:raise ValueError('source must be data string')
        if f['generation_status']=='generated':
            if len(f['source'].encode())>65536 or digest(f['source'].encode())!=f['source_sha256']:
                raise ValueError('frozen source hash/retention bound mismatch')
        elif f['source']!='' or f['source_sha256'] is not None:
            raise ValueError('unavailable generation cannot acquire replacement source')
    return forms


def claim(approval,output,usage_dir):
    usage_dir.mkdir(parents=True,exist_ok=True)
    with (usage_dir/'evaluation.json').open('x') as stream:
        json.dump({'batch_id':approval['batch_id'],'preparation_freeze_sha256':approval['preparation_freeze_sha256'],
                   'population_freeze_sha256':approval['population_freeze_sha256'],'output':str(output),
                   'state':'claimed_once_before_dispatch'},stream)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--approval',type=pathlib.Path,required=True)
    parser.add_argument('--population-freeze',type=pathlib.Path,required=True)
    parser.add_argument('--output',type=pathlib.Path,required=True)
    args=parser.parse_args()
    started=time.monotonic();cpu=time.process_time()
    approval=bounded_json(args.approval,4096)
    prep_path=HERE/'preparation_freeze.json'
    prep_digest=file_hash(prep_path);pop_digest=file_hash(args.population_freeze)
    scope=verify_evaluation_approval(approval,prep_digest,pop_digest)
    verify_preparation(prep_path,prep_digest)
    pop=verify_population(args.population_freeze,pop_digest,prep_digest)
    config=bounded_json(HERE/'evaluation_config.json',16384)
    if config['execution_gate']!='requires_separate_exact_population_authorization':raise PermissionError('evaluation disabled')
    if args.output.exists():raise FileExistsError(args.output)
    forms=load_forms(pop);cases=load_cases()
    claim(approval,args.output,HERE/'authorization_uses')
    def verify():
        verify_preparation(prep_path,prep_digest)
        verify_population(args.population_freeze,pop_digest,prep_digest)
    report=run_forms(forms,cases,scope,output_dir=args.output,integrity_check=verify,
                     cpu_budget=config['batch_worker_cpu_seconds'],wall_budget=config['batch_wall_seconds'],started_at=started)
    report.update(panel_and_pair_analysis(report,forms,cases,scope))
    report.update(protocol_id=config['protocol_id'],preparation_freeze_sha256=prep_digest,
                  population_freeze_sha256=pop_digest,batch_id=approval['batch_id'],
                  whole_batch_wall_seconds=time.monotonic()-started,whole_batch_supervisor_cpu_seconds=time.process_time()-cpu,
                  runtime_versions={'host_python':platform.python_version(),'guest_python':'3.14.0 (unchanged reviewed v3 guest)',
                                    'wasmtime':importlib.metadata.version('wasmtime'),'componentize_py':importlib.metadata.version('componentize-py')},
                  interpretation=config['interpretation'])
    (args.output/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(json.dumps({k:report[k] for k in ('dispatches','groups','stop_reason','result_certification_valid')}))

if __name__=='__main__':main()
