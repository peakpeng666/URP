"""Trusted bounded measurements for the closed language; no arbitrary-Python claim."""
import builtins
import json
import math
from limited_validator import parse_and_validate, RejectedLanguage

# Captured trusted references are never exposed in the candidate mapping.
_TYPE=type;_LIST=list;_TUPLE=tuple;_DICT=dict;_INT=int;_BOOL=bool;_FLOAT=float;_STR=str
_NONE_TYPE=type(None);_LEN=len;_BIT_LENGTH=int.bit_length;_COMPILE=compile;_EXEC=exec
_BASE_EXCEPTION=BaseException;_TYPE_ERROR=TypeError;_VALUE_ERROR=ValueError
_PARSE=parse_and_validate;_LOADS=json.loads;_DUMPS=json.dumps;_FINITE=math.isfinite
_SAFE={'type':type,'isinstance':isinstance,'len':len,'list':list,'set':set,'sorted':sorted,
       'range':range,'all':all,'int':int,'tuple':tuple,'float':float,'complex':complex,
       'TypeError':TypeError,'ValueError':ValueError}
_MAX_ITEMS=512;_MAX_INT_BITS=256


def _bad_constant(value):
    raise ValueError('invalid_fixture_json')


def _finite_float(value):
    number=_FLOAT(value)
    if not _FINITE(number):raise ValueError('invalid_fixture_json')
    return number


def _no_duplicate_keys(items):
    result={}
    for key,value in items:
        if key in result:raise ValueError('invalid_fixture_json')
        result[key]=value
    return result


def _fixture(input_json):
    descriptor=_LOADS(input_json,parse_constant=_bad_constant,parse_float=_finite_float,object_pairs_hook=_no_duplicate_keys)
    if _TYPE(descriptor) is not _DICT or set(descriptor)!= {'kind','value','valid_fixture'}:
        raise ValueError('invalid_fixture_descriptor')
    if _TYPE(descriptor['valid_fixture']) is not _BOOL:raise ValueError('invalid_fixture_descriptor')
    kind=descriptor['kind'];value=descriptor['value']
    if _TYPE(kind) is not _STR:raise ValueError('invalid_fixture_descriptor')
    expected={'list':_LIST,'tuple':_LIST,'dict':_DICT,'bool':_BOOL,'int':_INT,'float':_FLOAT,'str':_STR,'none':_NONE_TYPE}
    if kind not in expected or _TYPE(value) is not expected[kind]:raise ValueError('invalid_fixture_descriptor')
    # Inputs are trusted JSON data only, with a bounded object graph. No class,
    # callable, evaluator object or reference answer is given to the function.
    count=0;stack=[(value,0)]
    while stack:
        item,depth=stack.pop();count+=1;t=_TYPE(item)
        if count>1024 or depth>16:raise ValueError('invalid_fixture_descriptor')
        if t in (_LIST,_DICT):
            if _LEN(item)>_MAX_ITEMS:raise ValueError('invalid_fixture_descriptor')
            if t is _DICT:
                if any(_TYPE(k) is not _STR or _LEN(k)>128 for k in item):raise ValueError('invalid_fixture_descriptor')
                stack.extend((v,depth+1) for v in item.values())
            else:stack.extend((v,depth+1) for v in item)
        elif t is _INT:
            if _BIT_LENGTH(item)>_MAX_INT_BITS:raise ValueError('invalid_fixture_descriptor')
        elif t is _FLOAT:
            if not _FINITE(item):raise ValueError('invalid_fixture_descriptor')
        elif t is _STR:
            if _LEN(item)>1024:raise ValueError('invalid_fixture_descriptor')
        elif t not in (_BOOL,_NONE_TYPE):raise ValueError('invalid_fixture_descriptor')
    if kind=='tuple':value=_TUPLE(value)
    valid=descriptor['valid_fixture']
    if valid and not _flat_int_list(value):raise ValueError('invalid_fixture_descriptor')
    return value,valid


def _flat_int_list(value):
    if _TYPE(value) is not _LIST or _LEN(value)>_MAX_ITEMS:return False
    # Never recursively compare/serialize candidate graphs: one-level exact type
    # checks reject bools, nesting, cycles, custom objects and oversized integers.
    for item in value:
        if _TYPE(item) is not _INT or _BIT_LENGTH(item)>_MAX_INT_BITS:return False
    return True


def _same_final_input(original,snapshot):
    if not _flat_int_list(original) or _LEN(original)!=_LEN(snapshot):return False
    for i in range(_LEN(snapshot)):
        if original[i]!=snapshot[i]:return False
    return True


def evaluate(source,input_json):
    try:
        tree=_PARSE(source)
    except (RejectedLanguage,SyntaxError,ValueError,RecursionError):
        return {'stage':'source_rejected','reason':'unsupported_language'}
    except _BASE_EXCEPTION:
        return {'stage':'validation_error'}
    try:
        value,valid=_fixture(input_json)
        original=value
        snapshot=_TUPLE(value) if valid else None
        namespace={'__builtins__':_DICT(_SAFE)}
        # Compile the SAME validated guest AST, with no alias or source rewrite.
        code=_COMPILE(tree,'<limited-candidate>','exec',dont_inherit=True)
        _EXEC(code,namespace,namespace)
        function=namespace['sort_numbers']
    except _BASE_EXCEPTION:
        return {'stage':'setup_error'}
    # Exception identity is captured ONLY around actual candidate invocation.
    invocation='returned';result=None
    try:
        result=function(value)
    except _BASE_EXCEPTION as exc:
        invocation='exact_type_error' if _TYPE(exc) is _TYPE_ERROR else 'other_exception'
    try:
        shape=invocation=='returned' and _flat_int_list(result)
        # Measurements precede any candidate-result serialization. Invalid inputs
        # impose only exact TypeError semantics, not a new mutation requirement.
        response={'stage':'candidate_completed','invocation':invocation,
                  'result_shape_valid':shape,
                  'result':_LIST(result) if shape else None,
                  'returned_same_object':result is original if invocation=='returned' else None,
                  'final_input_unchanged':_same_final_input(original,snapshot) if valid else None,
                  'valid_fixture':valid}
        return response
    except _BASE_EXCEPTION:
        return {'stage':'measurement_error'}


def serialize(response):
    # Only fixed trusted fields and already-bounded flat integer lists arrive here.
    return _DUMPS(response,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('ascii')
