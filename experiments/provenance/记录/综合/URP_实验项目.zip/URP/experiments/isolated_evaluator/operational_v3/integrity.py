"""Bounded authorization parsing and full frozen-deployment verification."""
import hashlib
import json
import math
import os
import pathlib

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parent
PROTOTYPE = ROOT / 'limited_semantics_v3'
PROTOTYPE_DIGEST = '0cf4954262d10470a4dc49fda11b305b74ba0ff2bc8fd61f30810f20f5435dfd'
V2_DIGEST = '1e441a5599d3c9bf553c31b0cca2bd9c1558885396a18343796bd2bdf622baa4'


def file_hash(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def strict_json(raw):
    def bad(value):
        raise ValueError('non-standard JSON')
    def number(value):
        f = float(value)
        if not math.isfinite(f):
            raise ValueError('non-finite JSON')
        return f
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError('duplicate JSON key')
            result[key] = value
        return result
    return json.loads(raw, parse_constant=bad, parse_float=number, object_pairs_hook=unique)


def bounded_json(path, limit):
    with path.open('rb') as stream:
        raw = stream.read(limit + 1)
    if len(raw) > limit:
        raise ValueError('JSON file size limit')
    return strict_json(raw)


def verify_approval(approval, operational_digest):
    keys = {'explicit_batch_authorization', 'operational_freeze_sha256',
            'prototype_freeze_sha256', 'scope', 'batch_id'}
    if type(approval) is not dict or set(approval) != keys or approval['explicit_batch_authorization'] is not True:
        raise PermissionError('explicit scoped batch authorization absent')
    if approval['operational_freeze_sha256'] != operational_digest or approval['prototype_freeze_sha256'] != PROTOTYPE_DIGEST:
        raise PermissionError('approved freeze digest mismatch')
    if approval['scope'] not in ('raw_only', 'raw_and_existing_extracted'):
        raise PermissionError('invalid source scope')
    batch_id = approval['batch_id']
    if type(batch_id) is not str or not (1 <= len(batch_id) <= 80) or not all(c in 'abcdefghijklmnopqrstuvwxyz0123456789_-' for c in batch_id):
        raise PermissionError('invalid batch identifier')
    return {'raw'} if approval['scope'] == 'raw_only' else {'raw', 'extracted'}


def dependency_state():
    base = ROOT / '.venv'
    files = sorted(os.path.relpath(p, HERE) for p in base.rglob('*') if p.is_file())
    links = sorted([os.path.relpath(p, HERE), os.readlink(p)] for p in base.rglob('*') if p.is_symlink())
    return files, links


def source_inventory():
    return sorted(str(p.relative_to(HERE)) for p in HERE.glob('*.py')) + sorted(
        str(p.relative_to(HERE)) for p in (HERE / 'tests').rglob('*.py'))


def verify_freeze(path, expected_digest):
    # Bind every check to the originally approved manifest, hashing the SAME
    # bounded bytes that are parsed rather than reopening after verification.
    with path.open('rb') as stream:
        raw = stream.read(2 * 1024**2 + 1)
    if len(raw) > 2 * 1024**2:
        raise ValueError('operational manifest size limit')
    if hashlib.sha256(raw).hexdigest() != expected_digest:
        raise ValueError('operational manifest digest changed')
    frozen = strict_json(raw)
    files, links = dependency_state()
    if files != frozen['dependency_files'] or links != frozen['dependency_symlinks']:
        raise ValueError('dependency inventory or symlinks changed')
    if source_inventory() != frozen['operational_source_inventory']:
        raise ValueError('operational source inventory changed')
    proto = PROTOTYPE / 'prototype_freeze.json'
    legacy = ROOT / 'proposed_p2_value_v2/operational_freeze.json'
    if file_hash(proto) != PROTOTYPE_DIGEST or file_hash(legacy) != V2_DIGEST:
        raise ValueError('reviewed antecedent freeze changed')
    p = bounded_json(proto, 2 * 1024**2)
    actual_proto_sources = sorted(str(q.relative_to(PROTOTYPE)) for folder in ('src', 'tests')
                                  for q in (PROTOTYPE / folder).rglob('*.py'))
    if actual_proto_sources != p['source_inventory']:
        raise ValueError('prototype source inventory changed')
    for rel, expected in frozen['files'].items():
        if file_hash(HERE / rel) != expected:
            raise ValueError('frozen file changed: ' + rel)
    return frozen
