"""Internal bounded request worker; model inputs require approved batch entrypoint.

No WASI, host functions, filesystem, environment, network, subprocess, or JS
capabilities are linked into the component. Runtime source data may enter only
through the approved batch or reviewed handwritten-test entrypoint.
"""
import hashlib, json, pathlib, resource, sys, time, threading, os, math
ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'src'))
from runtime_config import make_engine
from wasmtime import Store
from wasmtime.component import Component, Linker, FuncType, U32, String

MAX_OUTPUT = 8192

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

def reject_constant(value):
    raise ValueError('non-standard JSON constant: '+value)

def unique_object(pairs):
    result={}
    for key,value in pairs:
        if key in result:raise ValueError('duplicate JSON key')
        result[key]=value
    return result

def finite_float(value):
    number=float(value)
    if not math.isfinite(number):raise ValueError('non-finite JSON number')
    return number

def strict_json(raw):
    return json.loads(raw,parse_constant=reject_constant,parse_float=finite_float,object_pairs_hook=unique_object)

def check_resource_setup():
    expected={resource.RLIMIT_AS:(8*1024**3,8*1024**3),resource.RLIMIT_CPU:(2,2),
              resource.RLIMIT_FSIZE:(0,0),resource.RLIMIT_NOFILE:(32,32),resource.RLIMIT_CORE:(0,0)}
    for kind,limits in expected.items():
        require(resource.getrlimit(kind)==limits,'required worker resource limits absent')

def own_memory():
    return {line.split(':')[0]: line.split(':')[1].strip()
            for line in pathlib.Path('/proc/self/status').read_text().splitlines()
            if line.startswith(('VmPeak:', 'VmSize:', 'VmHWM:', 'VmRSS:'))}

def read_request():
    raw = sys.stdin.buffer.read(65537)
    require(len(raw) <= 65536, 'stdin too large')
    req = strict_json(raw)
    require(type(req) is dict and set(req) == {'source','input_json','source_sha256','input_sha256'}, 'invalid request schema')
    for key, limit in [('source',16384),('input_json',8192)]:
        require(type(req[key]) is str, 'request fields must be strings')
        require(len(req[key].encode('utf-8')) <= limit, 'decoded request size exceeded')
    require(hashlib.sha256(req['source'].encode()).hexdigest() == req['source_sha256'], 'source hash mismatch')
    require(hashlib.sha256(req['input_json'].encode()).hexdigest() == req['input_sha256'], 'input hash mismatch')
    return req

def main():
    t = time.monotonic()
    check_resource_setup()
    probe = read_request()
    manifest = json.loads((ROOT/'build/trusted_clean_manifest.json').read_text())
    cache_path = ROOT/'build/evaluator_clean.cwasm'
    # Only deserialize locally compiled trusted machine code with frozen integrity hash.
    with cache_path.open('rb') as f:
        cache_size = os.fstat(f.fileno()).st_size
        require(cache_size <= 64*1024**2, 'cache too large')
        cache_bytes = f.read(cache_size+1)
        require(len(cache_bytes) == cache_size, 'cache size changed')
    require(len(cache_bytes) <= 64*1024**2, 'cache too large')
    require(hashlib.sha256(cache_bytes).hexdigest() == manifest['cache_sha256'], 'cache digest mismatch')
    engine = make_engine()
    # Deserialize the same verified bytes, avoiding a hash/reopen TOCTOU gap.
    component = Component.deserialize(engine, cache_bytes)
    del cache_bytes
    require(component.type.imports(engine) == {}, 'component imports forbidden')
    exports = {k:v.ty for k,v in component.type.exports(engine).items()}
    require(set(exports) == {'exports','run','output-byte'}, 'unexpected root exports')
    for name in ('run','output-byte'):
        require(isinstance(exports[name], FuncType) and isinstance(exports[name].result, U32), 'only scalar function results allowed')
    require([type(t) for _,t in exports['run'].params] == [String,String], 'wrong run inputs')
    require([type(t) for _,t in exports['output-byte'].params] == [U32], 'wrong output input')
    store = Store(engine)
    store.set_limits(memory_size=64*1024**2, table_elements=100000, instances=64, tables=8, memories=2)
    fuel = 200_000_000
    store.set_fuel(fuel)
    # Epoch budget is complemented by external hard wall and CPU limits.
    store.set_epoch_deadline(1)
    linker = Linker(engine)  # deliberately empty, never add_wasip2/define_func/etc
    timer = threading.Timer(4.0, engine.increment_epoch)
    timer.daemon = True
    timer.start()
    instance = linker.instantiate(store, component)
    run = instance.get_func(store, 'run')
    output = instance.get_func(store, 'output-byte')
    source = probe['source']; input_json = probe['input_json']
    require(len(source.encode())<=16384 and len(input_json.encode())<=8192, 'input size exceeded')
    try:
        print('{"event":"guest_entry"}', flush=True)
        n = run(store, source, input_json)
        run.post_return(store)
        if not isinstance(n,int) or n<0 or n>MAX_OUTPUT:
            result = {'status':'output_rejected','advertised_length':n}
        else:
            # Never allocate from untrusted n until it is checked. Each Wasm result
            # is scalar u32; hostile guest cannot trigger canonical string lifting.
            buf = bytearray()
            for i in range(n):
                byte = output(store, i)
                output.post_return(store)
                if type(byte) is not int or not 0 <= byte <= 255:
                    raise ValueError('invalid scalar byte')
                buf.append(byte)
            payload = strict_json(bytes(buf))
            result = {'status':'returned','payload':payload}
    except Exception as exc:
        result = {'status':'trapped','error_type':type(exc).__name__,'error':str(exc)[:400]}
    result.update({'probe':'runtime-request', 'fuel_budget':fuel,'fuel_remaining':store.get_fuel(), 'effective_rlimits':{'as':resource.getrlimit(resource.RLIMIT_AS),'cpu':resource.getrlimit(resource.RLIMIT_CPU),'fsize':resource.getrlimit(resource.RLIMIT_FSIZE),'nofile':resource.getrlimit(resource.RLIMIT_NOFILE)}, 'store_limits':{'per_memory_bytes':64*1024**2,'memories':2,'per_table_elements':100000,'tables':8,'instances':64},
                   'wall_seconds':time.monotonic()-t,'memory':own_memory(),
                   'maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss})
    timer.cancel()
    encoded = json.dumps(result, ensure_ascii=True, separators=(',',':'),allow_nan=False)
    # Limit worker->supervisor output independently of any guest state.
    if len(encoded)>16000:
        encoded = json.dumps({'probe':'runtime-request','status':'host_output_rejected'})
    print(encoded, flush=True)

if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print(json.dumps({'status':'initialization_or_request_error','error_type':type(exc).__name__,'error':str(exc)[:400]}),flush=True)
        raise SystemExit(2)
