"""Compile only the fixed wrapper to a cache; never accept a candidate path."""
import hashlib, json, pathlib, resource, time, sys
from wasmtime.component import Component, FuncType, U32, String, ComponentInstanceType
from runtime_config import make_engine
root = pathlib.Path(__file__).resolve().parents[1]
if sys.argv[1:] not in ([], ['clean']):
    raise ValueError('only fixed clean artifact selector accepted')
artifact = 'evaluator_clean' if sys.argv[1:] == ['clean'] else 'evaluator'
manifest_name = 'trusted_clean_manifest.json' if artifact == 'evaluator_clean' else 'trusted_manifest.json'
t = time.monotonic()
engine = make_engine()
component = Component.from_file(engine, root / f'build/{artifact}.wasm')
imports = component.type.imports(engine)
if imports: raise RuntimeError('component imports forbidden: '+str(list(imports)))
exports = component.type.exports(engine)
print('EXPORTS', {k: type(v.ty).__name__ for k,v in exports.items()}, flush=True)
if set(exports) != {'exports', 'run', 'output-byte'}: raise RuntimeError('unexpected exports')
if not isinstance(exports['exports'].ty, ComponentInstanceType): raise RuntimeError('unexpected metadata namespace')
def describe_exports(items):
    description = {}
    for name, item in items.items():
        ty=item.ty
        if isinstance(ty, ComponentInstanceType):
            description[name]={'kind':'instance','exports':describe_exports(ty.exports(engine))}
        elif isinstance(ty, FuncType):
            description[name]={'kind':'func','params':[(n,type(t).__name__) for n,t in ty.params],'result':type(ty.result).__name__}
        else:
            description[name]={'kind':type(ty).__name__}
    return description
export_description=describe_exports(exports)
print('EXPORT_DETAIL', export_description, flush=True)
run, output = exports['run'].ty, exports['output-byte'].ty
if not (isinstance(run, FuncType) and isinstance(output, FuncType)): raise RuntimeError('exports must be functions')
if [type(t) for _, t in run.params] != [String, String]: raise RuntimeError('wrong run inputs')
if not isinstance(run.result, U32): raise RuntimeError('run result must be scalar u32')
if [type(t) for _, t in output.params] != [U32]: raise RuntimeError('wrong byte input')
if not isinstance(output.result, U32): raise RuntimeError('byte result must be scalar u32')
cache = component.serialize()
(root / f'build/{artifact}.cwasm').write_bytes(cache)
manifest = {'component_sha256': hashlib.sha256((root / f'build/{artifact}.wasm').read_bytes()).hexdigest(),
            'cache_sha256': hashlib.sha256(cache).hexdigest(),
            'wasmtime': '49.0.0', 'componentize_py': '0.25.1',
            'imports': [], 'export_introspection': export_description, 'exports': {'run': '(string,string)->u32', 'output-byte': '(u32)->u32'},
            'compile_wall_seconds': time.monotonic()-t,
            'maxrss_kib': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            'source_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in [root/'src/guest/trusted_guest.py',root/'src/guest/semantic_evaluator.py',root/'src/guest/limited_validator.py',root/'src/guest/evaluator.wit',root/'src/runtime_config.py']}}
(root / f'build/{manifest_name}').write_text(json.dumps(manifest, indent=2))
print(json.dumps(manifest))
