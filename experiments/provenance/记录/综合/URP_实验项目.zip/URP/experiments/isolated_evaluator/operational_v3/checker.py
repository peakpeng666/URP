"""Independent typed observation validation and conservative outcome categories."""
def payload_schema(payload, case):
    keys = {'stage', 'invocation', 'result_shape_valid', 'result', 'returned_same_object',
            'final_input_unchanged', 'valid_fixture'}
    if type(payload) is not dict or set(payload) != keys or payload['stage'] != 'candidate_completed':
        return False
    if payload['valid_fixture'] is not case['valid'] or type(payload['result_shape_valid']) is not bool:
        return False
    if payload['invocation'] not in ('returned', 'exact_type_error', 'other_exception'):
        return False
    if case['valid']:
        if type(payload['final_input_unchanged']) is not bool:
            return False
    elif payload['final_input_unchanged'] is not None:
        return False
    if payload['invocation'] == 'returned':
        if type(payload['returned_same_object']) is not bool:
            return False
    elif payload['returned_same_object'] is not None or payload['result_shape_valid'] is not False:
        return False
    if payload['result_shape_valid']:
        value = payload['result']
        if payload['invocation'] != 'returned' or type(value) is not list or len(value) > 512:
            return False
        if any(type(x) is not int or x.bit_length() > 256 for x in value):
            return False
    elif payload['result'] is not None:
        return False
    return True


def semantic_conformance(payload, case):
    if not payload_schema(payload, case):
        return False
    if case['valid']:
        expected = sorted(case['input'])
        if expected != case['expected']:
            raise ValueError('original fixture expected value changed')
        return (payload['invocation'] == 'returned' and payload['result_shape_valid'] is True
                and payload['result'] == expected and payload['returned_same_object'] is False
                and payload['final_input_unchanged'] is True)
    return payload['invocation'] == 'exact_type_error'


def classify(observation, case):
    worker = observation.get('worker') or {}
    clean = (observation.get('returncode') == 0 and observation.get('termination') is None
             and observation.get('protocol_error') is False and not observation.get('supervisor_error')
             and not observation.get('worker_unreaped') and observation.get('guest_entry_observed') is True)
    if clean and worker.get('status') == 'returned':
        payload = worker.get('payload')
        if type(payload) is dict and payload.get('stage') == 'source_rejected':
            return 'infrastructure_error', None, 'host_guest_admission_mismatch'
        if not payload_schema(payload, case):
            return 'infrastructure_error', None, 'evaluator_stage_or_payload_schema_error'
        ok = semantic_conformance(payload, case)
        return ('case_conformant' if ok else 'case_nonconformant'), ok, None
    if clean and worker.get('status') in ('wasm_execution_unresolved', 'output_rejected'):
        return 'resource_unresolved', None, worker['status']
    cpu = observation.get('worker_user_seconds', 0) + observation.get('worker_sys_seconds', 0)
    resource_exit = (observation.get('guest_entry_observed') is True
                     and observation.get('returncode') in (-9, -24)
                     and not observation.get('protocol_error') and not observation.get('supervisor_error')
                     and not observation.get('worker_unreaped')
                     and (observation.get('termination') in ('wall_timeout', 'wall_timeout_after_eof')
                          or (observation.get('returncode') == -9 and cpu >= 1.9)))
    if resource_exit:
        reason = 'supervisor_wall_limit' if observation.get('termination') else 'probable_cpu_limit'
        return 'resource_unresolved', None, reason
    return 'infrastructure_error', None, 'unclean_or_preentry_transport'
