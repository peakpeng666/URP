"""Data-only original-source and fixture adapter; no native candidate execution."""
import ast
import hashlib
import json
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parent
PROTOTYPE = ROOT / 'limited_semantics_v3'
SORTING = ROOT.parent / 'sorting_generation'
sys.path.insert(0, str(PROTOTYPE / 'src/guest'))
from limited_validator import parse_and_validate, RejectedLanguage

SOURCES = [
    ('round1', SORTING / 'results/raw_generations.jsonl'),
    ('round2', SORTING / 'runs/function_completion_pilot/results/raw_generations.jsonl'),
]
LEGACY_ALIAS = '\nsolve = sort_numbers\n'  # Only legacy gate accounting; NEVER appended in v3.


def digest(data):
    return hashlib.sha256(data).hexdigest()


def structural_gate(source):
    if type(source) is not str or len((source + LEGACY_ALIAS).encode()) > 16384:
        return 'source_size_rejected'
    try:
        tree = ast.parse(source)
    except (SyntaxError, ValueError, RecursionError):
        return 'syntax_rejected'
    if len(tree.body) != 1 or not isinstance(tree.body[0], ast.FunctionDef):
        return 'single_function_structure_rejected'
    f = tree.body[0]
    a = f.args
    if not (f.name == 'sort_numbers' and not f.decorator_list and len(a.args) == 1
            and a.args[0].arg == 'values' and not a.posonlyargs and not a.kwonlyargs
            and a.vararg is None and a.kwarg is None and not a.defaults):
        return 'signature_rejected'
    return 'structurally_eligible'


def admission(source):
    structure = structural_gate(source)
    if structure != 'structurally_eligible':
        return {'stage': 'structural_rejection', 'reason': structure}
    try:
        parse_and_validate(source)  # Host AST-only precheck, never compiled/executed.
    except (RejectedLanguage, SyntaxError, ValueError, RecursionError):
        return {'stage': 'grammar_rejection', 'reason': 'unsupported_closed_language'}
    return {'stage': 'eligible_pending_guest_gate', 'reason': None}


def load_forms():
    raw, extracted = [], []
    for round_name, path in SOURCES:
        for line in path.read_text().splitlines():
            r = json.loads(line)
            common = {'round': round_name, 'candidate_id': r['id'], 'prompt_id': r['prompt_id']}
            raw.append({**common, 'variant': 'raw', 'source': r['candidate_source']})
            if round_name == 'round2':
                extracted.append({**common, 'variant': 'extracted', 'source': r['extraction']['source']})
    if len(raw) != 32 or len(extracted) != 10:
        raise ValueError('original source population changed')
    forms = raw + extracted
    for f in forms:
        f['form_id'] = f['round'] + '/' + f['candidate_id'] + '/' + f['variant']
        f['source_sha256'] = digest(f['source'].encode())
        f['admission'] = admission(f['source'])
    if len({f['form_id'] for f in forms}) != 42:
        raise ValueError('duplicate source-form identity')
    return forms


def load_cases():
    cases = json.loads((SORTING / 'fixtures/cases.json').read_text())
    if len(cases) != 72 or len({c['id'] for c in cases}) != 72 or sum(c['valid'] for c in cases) != 60:
        raise ValueError('fixture population changed')
    for c in cases:
        if c['valid']:
            if type(c['input']) is not list or any(type(x) is not int for x in c['input']):
                raise ValueError('invalid valid-fixture data')
            if sorted(c['input']) != c['expected']:
                raise ValueError('fixture oracle mismatch')
        elif c['expected_exception'] != 'TypeError':
            raise ValueError('unsupported invalid-fixture contract')
        fixture_json(c)
    return cases


def fixture_json(case):
    kind = case['kind']
    if kind == 'identity':
        kind = {dict: 'dict', bool: 'bool', int: 'int', float: 'float', str: 'str', type(None): 'none'}[type(case['input'])]
    raw = json.dumps({'kind': kind, 'value': case['input'], 'valid_fixture': case['valid']},
                     separators=(',', ':'), ensure_ascii=True, allow_nan=False)
    if len(raw.encode()) > 8192:
        raise ValueError('fixture size exceeded; never truncate')
    return raw


def make_request(source, case):
    if len(source.encode()) > 16384:
        raise ValueError('source size exceeded')
    raw = fixture_json(case)
    return {'source': source, 'source_sha256': digest(source.encode()),
            'input_json': raw, 'input_sha256': digest(raw.encode())}
