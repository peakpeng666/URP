"""Fixed, manually reviewed wrapper. Only this module is componentized.

This is NOT a Python sandbox. The WebAssembly component boundary is the sandbox.
Guest observations of aliasing/mutation/exceptions are not tamper-proof evidence.
No generated source is imported at build time. All source is runtime string data.
All guest-to-host returns are fixed-width u32, never a guest-selected bulk length.
"""
import wit_world
import json
import math
import os
import sys
import builtins

_OUTPUT = b''
_MAX_OUTPUT = 8192
_MAX_SOURCE = 16384
_MAX_INPUT = 8192

class WitWorld(wit_world.WitWorld):
    def run(self, source: str, input_json: str) -> int:
        global _OUTPUT
        _OUTPUT = b''
        if len(source.encode('utf-8')) > _MAX_SOURCE or len(input_json.encode('utf-8')) > _MAX_INPUT:
            return 0xFFFFFFFE
        try:
            value = json.loads(input_json)
            before = json.dumps(value, sort_keys=True, separators=(',', ':'))
            namespace = {'__name__': '__runtime_probe__'}
            # Full Python builtins intentionally retained: no builtin filter is a boundary.
            exec(compile(source, '<runtime-probe>', 'exec'), namespace, namespace)
            function = namespace['solve']
            result = function(value)
            # Refuse unbounded serialization in normal operation; hostile manipulation
            # still cannot grow a host output allocation because exports are scalar.
            if type(result) is list:
                if len(result) > 512 or any(type(x) is not int or abs(x).bit_length() > 256 for x in result):
                    return 0xFFFFFFFD
            elif type(result) is str:
                if len(result) > 2048:
                    return 0xFFFFFFFD
            elif type(result) not in (int, bool, type(None), dict):
                return 0xFFFFFFFD
            response = {'ok': True, 'result': result,
                        'guest_claim_same_object': result is value,
                        'guest_claim_input_unchanged': before == json.dumps(value, sort_keys=True, separators=(',', ':'))}
        except BaseException as exc:
            response = {'ok': False, 'guest_claim_exception': type(exc).__name__}
        payload = json.dumps(response, sort_keys=True, separators=(',', ':'), ensure_ascii=True).encode('ascii')
        if len(payload) > _MAX_OUTPUT:
            return 0xFFFFFFFD
        _OUTPUT = payload
        return len(payload)

    def output_byte(self, index: int) -> int:
        if index >= len(_OUTPUT) or index >= _MAX_OUTPUT:
            return 0xFFFFFFFF
        return _OUTPUT[index]
