"""Bounded supervisor: only registered handwritten probes, no arbitrary code/files.

Original 2s CPU / 5s wall / 256MiB total contract is tested explicitly. The
8GiB address-space diagnostic is a separate, candidate-free feasibility probe,
not silent approval of an increased candidate-execution budget.
"""
import argparse, hashlib, json, os, pathlib, resource, selectors, signal, subprocess, time
from handwritten_probes import PROBES
ROOT = pathlib.Path(__file__).resolve().parents[1]
SUPERVISOR_AS = 128*1024**2
PIPE_LIMIT = 32768

def launch(probe, as_bytes, cpu_seconds=2, wall_seconds=5.0, fuel=20_000_000):
    if probe not in PROBES:
        raise ValueError('Unknown handwritten probe')
    command = [str(ROOT/'.venv/bin/python'), '-B', str(ROOT/'src/host_worker.py'), probe, str(fuel)]
    def limits():
        resource.setrlimit(resource.RLIMIT_AS,(as_bytes,as_bytes))
        resource.setrlimit(resource.RLIMIT_CPU,(cpu_seconds,cpu_seconds))
        resource.setrlimit(resource.RLIMIT_CORE,(0,0))
        resource.setrlimit(resource.RLIMIT_FSIZE,(0,0))
        resource.setrlimit(resource.RLIMIT_NOFILE,(32,32))
    before = resource.getrusage(resource.RUSAGE_CHILDREN)
    start = time.monotonic()
    p = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                         env={'ISOLATION_FAKE_HOST_SECRET':'not-a-real-secret'}, preexec_fn=limits,
                         start_new_session=True)
    resource.setrlimit(resource.RLIMIT_AS,(SUPERVISOR_AS,SUPERVISOR_AS))
    selector = selectors.DefaultSelector();selector.register(p.stdout,selectors.EVENT_READ)
    collected = bytearray();reason = None
    while selector.get_map():
        remaining = wall_seconds-(time.monotonic()-start)
        if remaining <= 0:
            reason = 'wall_timeout';break
        for key,_ in selector.select(min(remaining,0.05)):
            piece = os.read(key.fd, min(4096,PIPE_LIMIT+1-len(collected)))
            if not piece:
                selector.unregister(key.fileobj);break
            collected.extend(piece)
            if len(collected)>PIPE_LIMIT:
                reason='supervisor_output_limit';break
        if reason:
            break
    if reason:
        os.killpg(p.pid,signal.SIGKILL)
    # No descendant escape is available in the import-free Wasm guest.
    rc = p.wait(timeout=1)
    selector.close();p.stdout.close()
    after = resource.getrusage(resource.RUSAGE_CHILDREN)
    raw = bytes(collected[:PIPE_LIMIT]).decode('utf-8','replace')
    try: worker = json.loads(raw)
    except (ValueError,TypeError): worker = None
    result = {'probe':probe,'returncode':rc,'termination':reason,'wall_seconds':time.monotonic()-start,
              'user_seconds':after.ru_utime-before.ru_utime,'sys_seconds':after.ru_stime-before.ru_stime,
              'child_peak_rss_kib_cumulative':after.ru_maxrss,
              'limits':{'worker_as_bytes':as_bytes,'cpu_seconds':cpu_seconds,'wall_seconds':wall_seconds,
                        'output_bytes':PIPE_LIMIT,'fuel':fuel,'supervisor_as_bytes':SUPERVISOR_AS},
              'supervisor_peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
              'worker':worker,'diagnostic':None if worker is not None else raw,
              'source_sha256':hashlib.sha256(PROBES[probe]['source'].encode()).hexdigest()}
    return result

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--profile',choices=['original','worker256','diagnostic','cpu','wall','outputbudget'],required=True)
    parser.add_argument('--probe',choices=sorted(PROBES),default='sort');parser.add_argument('--output',required=True)
    args=parser.parse_args()
    # Keep parent allocation soft cap while permitting the just-forked worker
    # to lower its own inherited hard cap to the diagnostic budget.
    resource.setrlimit(resource.RLIMIT_AS,(SUPERVISOR_AS,8*1024**3))
    if args.profile=='original':
        # Combined worker + supervisor virtual allocations are <=256 MiB.
        kwargs={'as_bytes':128*1024**2}
    elif args.profile=='worker256':
        kwargs={'as_bytes':256*1024**2}
    else:
        kwargs={'as_bytes':8*1024**3}
        if args.profile=='outputbudget':kwargs.update(fuel=200_000_000)
        if args.profile=='cpu':kwargs.update(cpu_seconds=2,wall_seconds=5.0,fuel=10**12)
        if args.profile=='wall':kwargs.update(cpu_seconds=2,wall_seconds=0.20,fuel=10**12)
    result=launch(args.probe,**kwargs);result['profile']=args.profile
    destination=ROOT/args.output
    if destination.exists():raise FileExistsError(destination)
    destination.write_text(json.dumps(result,indent=2))
    print(json.dumps(result))
if __name__=='__main__':main()
