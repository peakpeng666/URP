"""Freeze/verify only this handwritten prototype, never authorize model execution."""
import hashlib,json,os,pathlib,sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
FREEZE=ROOT/'prototype_freeze.json'
def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def dependency_state():
    base=ROOT.parent/'.venv'
    files=sorted(os.path.relpath(p,ROOT) for p in base.rglob('*') if p.is_file())
    links=sorted((os.path.relpath(p,ROOT),os.readlink(p)) for p in base.rglob('*') if p.is_symlink())
    return files,[list(x) for x in links]
def source_state():
    return sorted(str(p.relative_to(ROOT)) for base in ('src','tests') for p in (ROOT/base).rglob('*.py'))
if sys.argv[1:]==['--verify']:
    f=json.loads(FREEZE.read_text());deps,links=dependency_state()
    if deps!=f['dependency_files'] or links!=f['dependency_symlinks'] or source_state()!=f['source_inventory']:raise ValueError('inventory/symlinks changed')
    for rel,h in f['files'].items():
        if digest(ROOT/rel)!=h:raise ValueError('hash changed '+rel)
    print(json.dumps({'verified':True,'files':len(f['files']),'dependencies':len(deps),'freeze_sha256':digest(FREEZE)}))
elif sys.argv[1:]==['--create']:
    if FREEZE.exists():raise FileExistsError(FREEZE)
    deps,links=dependency_state();files=set(deps)|set(source_state())
    for folder in ('provenance','results','logs'):
        files.update(str(p.relative_to(ROOT)) for p in (ROOT/folder).rglob('*') if p.is_file())
    for rel in ('src/guest/evaluator.wit','protocol.json','build/evaluator_clean.wasm','build/evaluator_clean.cwasm','build/trusted_clean_manifest.json','../../sorting_generation/fixtures/cases.json','../../sorting_generation/results/raw_generations.jsonl','../../sorting_generation/runs/function_completion_pilot/results/raw_generations.jsonl'):
        files.add(rel)
    f={'protocol_id':'urp-p2-limited-language-final-state-v3-handwritten-20261004','scope':'handwritten prototype only; no generated batch authorization or operational model runner','state':'pending_independent_final_review','source_inventory':source_state(),'dependency_files':deps,'dependency_symlinks':links,'files':{rel:digest(ROOT/rel) for rel in sorted(files)}}
    FREEZE.write_text(json.dumps(f,indent=2)+'\n');print(json.dumps({'files':len(files),'dependencies':len(deps),'freeze_sha256':digest(FREEZE)}))
else:raise SystemExit('use --create or --verify')
