"""Trusted one-request host; CLI accepts only reviewed, handwritten probe IDs.

No WASI, host functions, filesystem, environment, network, subprocess, or JS
capabilities are linked into the component. No model candidate input interface.
"""
import hashlib, json, pathlib, resource, sys, time, threading, os
from runtime_config import make_engine
from handwritten_probes import PROBES
from host_checker import check_payload_value
from wasmtime import Store
from wasmtime.component import Component, Linker, FuncType, U32, String

ROOT = pathlib.Path(__file__).resolve().parents[1]
MAX_OUTPUT = 8192

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

def own_memory():
    return {line.split(':')[0]: line.split(':')[1].strip()
            for line in pathlib.Path('/proc/self/status').read_text().splitlines()
            if line.startswith(('VmPeak:', 'VmSize:', 'VmHWM:', 'VmRSS:'))}

def main():
    t = time.monotonic()
    probe = PROBES[sys.argv[1]]
    manifest = json.loads((ROOT/'build/trusted_clean_manifest.json').read_text())
    cache_path = ROOT/'build/evaluator_clean.cwasm'
    # Only deserialize locally compiled trusted machine code with frozen integrity hash.
    with cache_path.open('rb') as f:
        cache_size = os.fstat(f.fileno()).st_size
        require(cache_size <= 64*1024**2, 'cache too large')
        cache_bytes = f.read(cache_size+1)
        require(len(cache_bytes) == cache_size, 'cache size changed')
    require(len(cache_bytes) <= 64*1024**2, 'cache too large')
    require(hashlib.sha256(cache_bytes).hexdigest() == manifest['cache_sha256'], 'cache digest mismatch')
    engine = make_engine()
    # Deserialize the same verified bytes, avoiding a hash/reopen TOCTOU gap.
    component = Component.deserialize(engine, cache_bytes)
    del cache_bytes
    require(component.type.imports(engine) == {}, 'component imports forbidden')
    exports = {k:v.ty for k,v in component.type.exports(engine).items()}
    require(set(exports) == {'exports','run','output-byte'}, 'unexpected root exports')
    for name in ('run','output-byte'):
        require(isinstance(exports[name], FuncType) and isinstance(exports[name].result, U32), 'only scalar function results allowed')
    require([type(t) for _,t in exports['run'].params] == [String,String], 'wrong run inputs')
    require([type(t) for _,t in exports['output-byte'].params] == [U32], 'wrong output input')
    store = Store(engine)
    store.set_limits(memory_size=64*1024**2, table_elements=100000, instances=64, tables=8, memories=2)
    fuel = int(sys.argv[2]) if len(sys.argv)>2 else 20_000_000
    store.set_fuel(fuel)
    # Epoch budget is complemented by external hard wall and CPU limits.
    store.set_epoch_deadline(1)
    linker = Linker(engine)  # deliberately empty, never add_wasip2/define_func/etc
    timer = threading.Timer(4.0, engine.increment_epoch)
    timer.daemon = True
    timer.start()
    instance = linker.instantiate(store, component)
    run = instance.get_func(store, 'run')
    output = instance.get_func(store, 'output-byte')
    source = probe['source']; input_json = json.dumps(probe['input'], separators=(',',':'))
    require(len(source.encode())<=16384 and len(input_json.encode())<=8192, 'input size exceeded')
    try:
        n = run(store, source, input_json)
        run.post_return(store)
        if not isinstance(n,int) or n<0 or n>MAX_OUTPUT:
            result = {'status':'output_rejected','advertised_length':n}
        else:
            # Never allocate from untrusted n until it is checked. Each Wasm result
            # is scalar u32; hostile guest cannot trigger canonical string lifting.
            buf = bytearray()
            for i in range(n):
                byte = output(store, i)
                output.post_return(store)
                if type(byte) is not int or not 0 <= byte <= 255:
                    raise ValueError('invalid scalar byte')
                buf.append(byte)
            payload = json.loads(bytes(buf))
            result = {'status':'returned','payload':payload}
            # This is outside the guest, always uses pristine original fixture.
            if 'expected_result' in probe:
                result['host_value_check'] = check_payload_value(payload, probe['expected_result'])
    except Exception as exc:
        result = {'status':'trapped','error_type':type(exc).__name__,'error':str(exc)[:400]}
    result.update({'probe':sys.argv[1], 'fuel_budget':fuel,'fuel_remaining':store.get_fuel(), 'store_limits':{'per_memory_bytes':64*1024**2,'memories':2,'per_table_elements':100000,'tables':8,'instances':64},
                   'wall_seconds':time.monotonic()-t,'memory':own_memory(),
                   'maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss})
    timer.cancel()
    encoded = json.dumps(result, ensure_ascii=True, separators=(',',':'))
    # Limit worker->supervisor output independently of any guest state.
    if len(encoded)>16000:
        encoded = json.dumps({'probe':sys.argv[1],'status':'host_output_rejected'})
    print(encoded, flush=True)

if __name__ == '__main__':
    main()
