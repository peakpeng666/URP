"""Handwritten/fake-observation tests; saved generated sources are AST-inspected only."""
import copy
import json
import pathlib
import sys
import tempfile
import unittest
from unittest.mock import patch

HERE = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))
from adapter import admission, digest, load_cases, load_forms
from batch_runner import claim_authorization, complete_ledger, run_forms
from checker import classify, payload_schema
from integrity import PROTOTYPE_DIGEST, bounded_json, strict_json, verify_approval, verify_freeze, dependency_state, source_inventory, file_hash

SOURCE = 'def sort_numbers(values):\n    return sorted(values)\n'
FORM = {'form_id': 'handwritten/reference/raw', 'round': 'handwritten', 'candidate_id': 'reference',
        'prompt_id': 'reference', 'variant': 'raw', 'source': SOURCE}
CASE = {'id': 'one', 'kind': 'list', 'valid': True, 'input': [1], 'expected': [1]}


def good(case=CASE):
    payload = {'stage': 'candidate_completed', 'invocation': 'returned', 'result_shape_valid': True,
               'result': case['expected'], 'returned_same_object': False,
               'final_input_unchanged': True, 'valid_fixture': True}
    return {'returncode': 0, 'termination': None, 'protocol_error': False, 'supervisor_error': None,
            'worker_unreaped': False, 'guest_entry_observed': True, 'worker_pid': 123, 'supervisor_pid': 1,
            'worker_user_seconds': 1, 'worker_sys_seconds': 0, 'wall_seconds': 1,
            'worker': {'status': 'returned', 'payload': payload}}


def approval():
    return {'explicit_batch_authorization': True, 'operational_freeze_sha256': 'a' * 64,
            'prototype_freeze_sha256': PROTOTYPE_DIGEST, 'scope': 'raw_and_existing_extracted', 'batch_id': 'handwritten_gate_test'}


class FakeClock:
    def __init__(self): self.value = 0
    def __call__(self): return self.value


class OperationalTests(unittest.TestCase):
    def run_fake(self, executor, *, forms=None, cases=None, **kwargs):
        def with_hashes(request):
            observation = executor(request)
            if type(observation) is dict:
                observation.setdefault('source_sha256', request['source_sha256'])
                observation.setdefault('input_sha256', request['input_sha256'])
            return observation
        with tempfile.TemporaryDirectory() as tmp:
            return run_forms(forms or [FORM], cases or [CASE], {'raw', 'extracted'},
                             output_dir=pathlib.Path(tmp) / 'out', executor=with_hashes, **kwargs)

    def test_frozen_population_ast_only(self):
        forms, cases = load_forms(), load_cases()
        rows = complete_ledger(forms, cases, {'raw', 'extracted'})
        self.assertEqual(len(rows), 3024)
        self.assertEqual(sum(r['status'] == 'pending' for r in rows), 864)
        self.assertEqual(sum(r['status'] == 'not_run_structural_rejection' for r in rows), 2088)
        self.assertEqual(sum(r['status'] == 'not_run_grammar_rejection' for r in rows), 72)
        self.assertEqual(len({(r['form_id'], r['fixture_id']) for r in rows}), 3024)
        hashes = [digest(f['source'].encode()) for f in forms]
        self.assertLess(len(set(hashes)), len(hashes))
        self.assertEqual([r['fixture_id'] for r in rows[:72]], [c['id'] for c in cases])
        self.assertTrue(all(f['variant'] == 'raw' for f in forms[:32]))

    def test_auth_exact_scope_hash_and_boolean(self):
        self.assertEqual(verify_approval(approval(), 'a' * 64), {'raw', 'extracted'})
        for key, value in [('explicit_batch_authorization', 1), ('scope', 'all'),
                           ('prototype_freeze_sha256', 'bad'), ('operational_freeze_sha256', 'bad'),
                           ('batch_id', '../escape')]:
            a = approval(); a[key] = value
            with self.subTest(key=key), self.assertRaises(PermissionError): verify_approval(a, 'a' * 64)
        a = approval(); a['extra'] = True
        with self.assertRaises(PermissionError): verify_approval(a, 'a' * 64)

    def test_single_use_batch_id(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            claim_authorization(approval(), root / 'one', root / 'uses')
            with self.assertRaises(FileExistsError): claim_authorization(approval(), root / 'two', root / 'uses')

    def test_approval_json_is_bounded_and_strict(self):
        for raw in ['{"a":1,"a":2}', '{"a":NaN}', '{"a":1e9999}']:
            with self.assertRaises(ValueError): strict_json(raw)
        with tempfile.TemporaryDirectory() as tmp:
            p = pathlib.Path(tmp) / 'oversize.json'; p.write_text(' ' * 4097)
            with self.assertRaisesRegex(ValueError, 'size limit'): bounded_json(p, 4096)

    def test_unclean_transport_cannot_pass(self):
        for change in ({'returncode': 2}, {'termination': 'wall_timeout'}, {'protocol_error': True},
                       {'guest_entry_observed': False}, {'worker_unreaped': True}, {'worker': None}):
            o = good(); o.update(change)
            with self.subTest(change=change): self.assertEqual(classify(o, CASE)[0], 'infrastructure_error')

    def test_evaluator_stages_cannot_satisfy_invalid_fixture(self):
        case = {'id': 'invalid', 'kind': 'identity', 'valid': False, 'input': 7, 'expected_exception': 'TypeError'}
        for stage in ('source_rejected', 'validation_error', 'setup_error', 'measurement_error', 'serialization_error'):
            o = good(); o['worker']['payload'] = {'stage': stage, 'invocation': 'exact_type_error'}
            self.assertEqual(classify(o, case)[0], 'infrastructure_error')

    def test_exact_semantic_counterexamples(self):
        for key, value in [('result', [2]), ('returned_same_object', True), ('final_input_unchanged', False)]:
            o = good(); o['worker']['payload'][key] = value
            self.assertEqual(classify(o, CASE)[0], 'case_nonconformant')
        for value in ([True], [1.0], 'one'):
            o = good(); o['worker']['payload']['result'] = value
            self.assertEqual(classify(o, CASE)[0], 'infrastructure_error')
        o = good(); p = o['worker']['payload']; p['result_shape_valid'] = False; p['result'] = None
        self.assertEqual(classify(o, CASE)[0], 'case_nonconformant')

    def test_exact_type_error_only(self):
        c = {'id': 'invalid', 'kind': 'identity', 'valid': False, 'input': True, 'expected_exception': 'TypeError'}
        o = good(); o['worker']['payload'] = {'stage': 'candidate_completed', 'invocation': 'exact_type_error',
              'result_shape_valid': False, 'result': None, 'returned_same_object': None,
              'final_input_unchanged': None, 'valid_fixture': False}
        self.assertEqual(classify(o, c)[0], 'case_conformant')
        o['worker']['payload']['invocation'] = 'other_exception'
        self.assertEqual(classify(o, c)[0], 'case_nonconformant')

    def test_resource_unresolved_and_known_counterexample(self):
        cases = [CASE, {**CASE, 'id': 'two'}]
        sequence = [good(), good()]
        sequence[0]['worker'] = {'status': 'wasm_execution_unresolved'}
        result = self.run_fake(lambda q: sequence.pop(0), cases=cases)
        self.assertEqual(result['forms'][0]['conclusion'], 'incomplete_unknown')
        self.assertIsNone(result['groups'][0]['pass_fraction'])
        self.assertEqual(result['groups'][0]['pass_fraction_upper_bound'], 1)
        sequence = [good(), good()]
        sequence[0]['worker']['payload']['result'] = [2]
        sequence[1]['worker'] = {'status': 'wasm_execution_unresolved'}
        result = self.run_fake(lambda q: sequence.pop(0), cases=cases)
        self.assertEqual(result['forms'][0]['conclusion'], 'observed_semantic_nonconformant')
        self.assertFalse(result['groups'][0]['case_coverage_complete'])
        self.assertEqual(result['groups'][0]['pass_fraction_upper_bound'], 0)

    def test_mid_batch_cpu_stop(self):
        cases = [CASE, {**CASE, 'id': 'two'}, {**CASE, 'id': 'three'}]
        result = self.run_fake(lambda q: good(), cases=cases, cpu_budget=3)
        self.assertEqual(result['dispatches'], 2)
        self.assertEqual(result['rows'][2]['status'], 'not_run_budget_exhausted')
        self.assertEqual(result['worker_cpu_seconds'], 2)

    def test_mid_batch_wall_stop_and_full_reservation(self):
        clock = FakeClock()
        def executor(q): clock.value += 4; return good()
        result = self.run_fake(executor, cases=[CASE, {**CASE, 'id': 'two'}, {**CASE, 'id': 'three'}], clock=clock, wall_budget=10)
        self.assertEqual(result['dispatches'], 2)
        self.assertEqual(result['rows'][2]['status'], 'not_run_budget_exhausted')
        clock = FakeClock()
        def integrity(): clock.value += 2
        result = self.run_fake(lambda q: good(), clock=clock, integrity_check=integrity, wall_budget=7)
        self.assertEqual(result['dispatches'], 0)
        self.assertEqual(result['stop_reason'], 'budget_exhausted')

    def test_integrity_failure_invalidates_scores(self):
        counter = [0]
        def integrity():
            counter[0] += 1
            if counter[0] == 2: raise ValueError('changed frozen input')
        result = self.run_fake(lambda q: good(), integrity_check=integrity)
        self.assertEqual(result['rows'][0]['status'], 'case_conformant')
        self.assertFalse(result['result_certification_valid'])
        self.assertEqual(result['forms'][0]['conclusion'], 'uncertified_integrity_failure')
        self.assertIsNone(result['groups'][0]['passed'])
        self.assertIsNone(result['groups'][0]['pass_fraction'])
        self.assertIsNone(result['groups'][0]['pass_fraction_upper_bound'])

    def test_infrastructure_preserves_remaining_rows(self):
        result = self.run_fake(lambda q: {**good(), 'returncode': 2}, cases=[CASE, {**CASE, 'id': 'two'}])
        self.assertEqual([r['status'] for r in result['rows']], ['infrastructure_error', 'not_run_infrastructure_stop'])
        self.assertEqual(result['candidate_completions_reported'], 1)
        self.assertEqual(result['workers_started'], 1)
        self.assertEqual(result['groups'][0]['passed'], 0)

    def test_scope_structural_and_grammar_rows_preserved(self):
        forms = [FORM, {**FORM, 'form_id': 'handwritten/bad/raw', 'source': 'not python ?'},
                 {**FORM, 'form_id': 'handwritten/grammar/raw', 'source': 'def sort_numbers(values):\n    return values[:]\n'},
                 {**FORM, 'form_id': 'handwritten/extracted/extracted', 'variant': 'extracted'}]
        rows = complete_ledger(forms, [CASE], {'raw'})
        self.assertEqual([r['status'] for r in rows], ['pending', 'not_run_structural_rejection', 'not_run_grammar_rejection', 'not_run_scope_unapproved'])

    def test_observations_streamed_not_retained_in_rows(self):
        o = good(); o['worker']['payload']['result'] = [123456789] * 512
        result = self.run_fake(lambda q: o)
        row = result['rows'][0]
        self.assertNotIn('payload', row['observation_summary'])
        self.assertLessEqual(len(row['observation_summary']['payload_preview']), 256)


    def test_replaced_consistent_manifest_is_rejected(self):
        files, links = dependency_state()
        frozen = {'dependency_files': files, 'dependency_symlinks': links,
                  'operational_source_inventory': source_inventory(), 'files': {}}
        with tempfile.TemporaryDirectory() as tmp:
            p = pathlib.Path(tmp) / 'freeze.json'
            p.write_text(json.dumps(frozen))
            approved_digest = file_hash(p)
            verify_freeze(p, approved_digest)
            # All listed underlying inputs still match, but approved manifest bytes changed.
            frozen['replacement_note'] = 'internally consistent replacement'
            p.write_text(json.dumps(frozen))
            with self.assertRaisesRegex(ValueError, 'manifest digest changed'):
                verify_freeze(p, approved_digest)

    def test_observation_persistence_failure_retains_execution_evidence(self):
        original_open = pathlib.Path.open
        def fail_observation(path, mode='r', *args, **kwargs):
            if path.parent.name == 'observations' and mode == 'x':
                raise OSError('handwritten observation persistence fault')
            return original_open(path, mode, *args, **kwargs)
        with patch.object(pathlib.Path, 'open', fail_observation):
            result = self.run_fake(lambda q: good())
        self.assertEqual(result['rows'][0]['status'], 'infrastructure_error')
        self.assertEqual(result['workers_started'], 1)
        self.assertEqual(result['requests_with_guest_call_marker'], 1)
        self.assertEqual(result['candidate_completions_reported'], 1)
        self.assertEqual(result['worker_cpu_seconds'], 1)
        self.assertEqual(result['groups'][0]['passed'], 0)


    def test_worker_distinguishes_protocol_from_wasm_errors(self):
        from runtime_worker import invoke_and_decode
        from wasmtime import WasmtimeError
        class FakeFunction:
            def __init__(self, action): self.action = action
            def __call__(self, *args): return self.action(*args)
            def post_return(self, store): return None
        for raw in (b'{', b'{"x":NaN}', b'{"x":1e9999}', b'{"x":1,"x":2}'):
            result = invoke_and_decode(FakeFunction(lambda *args, raw=raw: len(raw)),
                                       FakeFunction(lambda store, i, raw=raw: raw[i]), None, '', '')
            self.assertEqual(result['status'], 'host_protocol_error')
            o = good(); o['worker'] = result
            self.assertEqual(classify(o, CASE)[0], 'infrastructure_error')
        result = invoke_and_decode(FakeFunction(lambda *args: 1), FakeFunction(lambda *args: 256), None, '', '')
        self.assertEqual(result['status'], 'host_protocol_error')
        def fail(*args): raise WasmtimeError('handwritten execution-error control')
        result = invoke_and_decode(FakeFunction(fail), None, None, '', '')
        self.assertEqual(result['status'], 'wasm_execution_unresolved')
        o = good(); o['worker'] = result
        self.assertEqual(classify(o, CASE)[0], 'resource_unresolved')


    def test_main_denied_approval_never_loads_sources(self):
        import batch_runner
        bad = approval(); bad['explicit_batch_authorization'] = False
        with patch.object(sys, 'argv', ['batch_runner.py', '--approved-batch', 'unused.json', '--output', 'unused-result']), \
             patch.object(batch_runner, 'file_hash', return_value='a' * 64), \
             patch.object(batch_runner, 'bounded_json', return_value=bad), \
             patch.object(batch_runner, 'load_forms') as loader:
            with self.assertRaisesRegex(PermissionError, 'authorization absent'):
                batch_runner.main()
            loader.assert_not_called()

    def test_hash_mismatch_cannot_pass(self):
        o = good(); o['source_sha256'] = 'wrong'
        result = self.run_fake(lambda q: o)
        self.assertEqual(result['rows'][0]['reason'], 'request_observation_hash_mismatch')
        self.assertEqual(result['rows'][0]['status'], 'infrastructure_error')
        self.assertEqual(result['workers_started'], 1)
        self.assertEqual(result['clean_schema_validated_completions'], 0)

    def test_host_envelope_limit_is_infrastructure(self):
        o = good(); o['worker'] = {'status': 'host_output_rejected'}
        self.assertEqual(classify(o, CASE)[0], 'infrastructure_error')


    def test_prelaunch_integrity_failure_has_no_unknown_launch(self):
        def fail(): raise ValueError('handwritten initial integrity failure')
        result = self.run_fake(lambda q: good(), integrity_check=fail)
        self.assertEqual(result['dispatches'], 0)
        self.assertEqual(result['workers_started'], 0)
        self.assertEqual(result['requests_without_returned_execution_evidence'], 0)

if __name__ == '__main__':
    unittest.main(verbosity=2)
