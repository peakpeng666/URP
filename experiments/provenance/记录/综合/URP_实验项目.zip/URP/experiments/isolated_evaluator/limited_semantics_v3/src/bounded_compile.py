"""One-off trusted compile only, separately metered from evaluation."""
import json,pathlib,resource,subprocess,time,sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
def limits():
    resource.setrlimit(resource.RLIMIT_CPU,(60,60))
    resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,16*1024**3))
    resource.setrlimit(resource.RLIMIT_CORE,(0,0))
suffix=sys.argv[1] if len(sys.argv)>1 else 'final'
if not (suffix.isalnum() or suffix.replace('_','').isalnum()):raise ValueError('invalid suffix')
log=ROOT/f'logs/compile_trusted_{suffix}.log'
if log.exists():raise FileExistsError(log)
before=resource.getrusage(resource.RUSAGE_CHILDREN)
start=time.monotonic()
with log.open('wb') as f:
    p=subprocess.Popen([str(ROOT.parent/'.venv/bin/python'),'-B',str(ROOT/'src/compile_trusted.py')] + (['clean'] if suffix.startswith('clean') else []),
                       stdout=f,stderr=subprocess.STDOUT,env={'PATH':'/usr/bin:/bin'},preexec_fn=limits)
    try:rc=p.wait(timeout=65)
    except subprocess.TimeoutExpired:p.kill();rc=p.wait()
u=resource.getrusage(resource.RUSAGE_CHILDREN)
result={'returncode':rc,'wall_seconds':time.monotonic()-start,'user_seconds':u.ru_utime-before.ru_utime,'sys_seconds':u.ru_stime-before.ru_stime,
        'maxrss_kib':u.ru_maxrss,'limits':{'cpu_seconds':60,'wall_seconds':65,'as_bytes':16*1024**3}}
(ROOT/f'logs/compile_trusted_{suffix}_time.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result));print(log.read_text()[-4000:])
