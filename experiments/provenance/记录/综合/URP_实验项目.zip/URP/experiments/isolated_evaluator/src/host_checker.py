"""Independent checker; this module is never part of the Wasm build path."""
def exact_value_equal(actual, expected):
    if type(actual) is not type(expected):
        return False
    if type(expected) is list:
        return len(actual) == len(expected) and all(exact_value_equal(a,b) for a,b in zip(actual,expected))
    if type(expected) is dict:
        return actual.keys() == expected.keys() and all(exact_value_equal(actual[k],expected[k]) for k in expected)
    return actual == expected

def check_payload_value(payload, expected):
    return type(payload) is dict and payload.get('ok') is True and 'result' in payload and exact_value_equal(payload['result'],expected)
