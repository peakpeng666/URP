# Source and compatibility record

Accessed 2026-10-04.

- Official package, 0.25.1: https://pypi.org/project/componentize-py/0.25.1/
- Official project: https://github.com/bytecodealliance/componentize-py
- Runtime, 49.0.0: https://pypi.org/project/wasmtime/49.0.0/
- Security architecture: https://docs.wasmtime.dev/security.html
- Fuel and epoch interruption: https://docs.wasmtime.dev/examples-interrupting-wasm.html
- Store limits: https://docs.wasmtime.dev/api/wasmtime/struct.StoreLimitsBuilder.html
- Maintainer-selected embedded CPython source as declared by this exact package's
  build.rs: https://github.com/dicej/cpython/tarball/v3.14.0-wasi-sdk-30
- Embedded source base directory declaration: `dicej-cpython-0e13686`
- Python upstream license: https://github.com/python/cpython/blob/v3.14.0/LICENSE

Exact PyPI JSON responses and the sdist source excerpts are saved alongside this
record. Wheel hashes match that metadata. This validates official distribution
integrity, not a reproducible-build audit or proof against supply-chain compromise.
PyPI reports the componentize-py wheel was uploaded with Twine, not Trusted
Publishing. The full embedded fork has not been audited or rebuilt here.

The 0.25.1 release example uses `wit_world.WitWorld` and an old generated host
binding flow capped at Wasmtime 38. The current main README uses a newer `wit`
decorator API and Wasmtime 48 direct component APIs. We deliberately use the
installed release's generated guest bindings, and the official Wasmtime 49 direct
component API. Compatibility must be established by actual prototype tests rather
than mixing those README snippets. Initial host introspection API mistakes are
retained in compile logs and are not counted as successful checks.

Licenses: componentize-py is Apache-2.0; Wasmtime is Apache-2.0 WITH LLVM-exception;
CPython includes its PSF license and historical notices. The build also references
WASI libc, libc++ and other bundled libraries. Retained top-level license texts
are not represented as a complete transitive-binary-license audit. Compiled binaries
and vendored wheels should not be redistributed in the lightweight research
artifact until notices are reconciled. No separately downloaded fork code is
executed; the official PyPI wheel supplies the embedded runtime.

Exact fork LICENSE retrieval at the declared short revision returned HTTP 404;
the stock upstream 3.14.0 LICENSE was retrieved for context only and must not be
misrepresented as verified fork provenance. Upstream issue 215 confirms that
this release family patches CPython and intends to return to stock CPython 3.15:
https://github.com/bytecodealliance/componentize-py/issues/215
