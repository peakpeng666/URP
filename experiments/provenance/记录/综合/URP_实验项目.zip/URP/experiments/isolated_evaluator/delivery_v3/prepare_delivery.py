"""Data-only public projection of the one saved v3 batch; never runs sources."""
import collections
import hashlib
import json
import pathlib
import statistics

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parent
URP = ROOT.parents[1]
RUN = ROOT / 'runs/generated_v3_batch_20261004_01'
RESULTS = RUN / 'results'
REPORT = json.loads((RESULTS / 'report.json').read_text())
CASES = {c['id']: c for c in json.loads((ROOT.parent / 'sorting_generation/fixtures/cases.json').read_text())}

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def rel(path):
    return str(path.relative_to(URP))

def write(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')

observations = []
failures = []
dimensions = collections.Counter()
by_form = collections.defaultdict(collections.Counter)
for row in REPORT['rows']:
    if 'observation_file' not in row:
        continue
    obs = json.loads((RESULTS / row['observation_file']).read_text())
    observations.append(obs)
    payload = obs['worker']['payload']
    case = CASES[row['fixture_id']]
    reasons = []
    if case['valid']:
        if payload['invocation'] != 'returned': reasons.append('valid_did_not_return')
        if not payload['result_shape_valid']: reasons.append('result_shape_not_established')
        if payload['result_shape_valid'] and payload['result'] != case['expected']: reasons.append('wrong_value')
        if payload['returned_same_object'] is True: reasons.append('same_object')
        if payload['final_input_unchanged'] is not True: reasons.append('final_input_changed')
    elif payload['invocation'] != 'exact_type_error':
        reasons.append('invalid_missing_exact_TypeError')
    if bool(reasons) != (row['status'] == 'case_nonconformant'):
        raise ValueError('derived reasons disagree with frozen result')
    dimensions.update(reasons)
    by_form[row['form_id']].update(reasons)
    if reasons:
        failures.append({'form_id': row['form_id'], 'fixture_id': row['fixture_id'],
                         'source_sha256': row['source_sha256'], 'dimensions': reasons,
                         'observation_file': rel(RESULTS / row['observation_file'])})

wall = [o['wall_seconds'] for o in observations]
summary = {k: v for k, v in REPORT.items() if k != 'rows'}
summary.update(
    public_schema='urp-p2-v3-public-summary-1',
    independent_saved_output_verification='passed_all864_observations_3024_rows_1728_events_1226_frozen_hashes_no_replay',
    title_zh='P2：受限 Python 语言的 72 用例观测实验',
    headline_zh='全部 864 次请求完成；12 个实际执行形式均有反例，没有 72/72 通过形式',
    claim_zh='统计的是通过结构与语言准入、并满足 72 个观测用例的协议成功率；不能外推为任意 Python 程序的正确率',
    case_status_counts=dict(collections.Counter(r['status'] for r in REPORT['rows'])),
    form_conclusion_counts=dict(collections.Counter(f['conclusion'] for f in REPORT['forms'])),
    valid_fixture_count=60, invalid_fixture_count=12,
    fixture_count=72, ledger_rows=len(REPORT['rows']), event_records=1728,
    unexecuted_grammar_form='round2/sample_463_compact_docstring/extracted',
    grammar_explanation_zh='该形式含 .format 和 type(values).__name__，不在预先冻结的闭合语言内；原样拒绝，无修补',
    failure_dimensions_overlap=dict(dimensions),
    failure_dimensions_caveat='One case may have several failed dimensions; these counts do not sum to the 344 unique failed cases. result_shape_not_established includes valid-input exceptions where no result was returned to inspect',
    per_form_failure_dimensions={k: dict(v) for k, v in by_form.items()},
    max_worker_peak_rss_kib=max(o['worker']['maxrss_kib'] for o in observations),
    max_parent_reported_child_peak_rss_kib=max(o['worker_peak_rss_kib_cumulative'] for o in observations),
    request_wall_seconds={'sum':sum(wall),'min':min(wall),'median':statistics.median(wall),'max':max(wall)},
    maximum_request_fuel_consumed=max(o['worker']['fuel_budget']-o['worker']['fuel_remaining'] for o in observations),
    distinct_worker_pids=len({o['worker_pid'] for o in observations}),
    distinct_supervisor_pids=len({o['supervisor_pid'] for o in observations}),
    forced_terminations=sum(o['termination'] is not None for o in observations),
    unreaped_workers=sum(o['worker_unreaped'] for o in observations),
    per_request_protocol=json.loads((ROOT / 'operational_v3/protocol.json').read_text()),
    preserved_failure_zh='首次可选外围计时命令因 /usr/bin/time 不存在而未启动运行器，候选请求数为 0；保存该失败后直接启动一次冻结运行器。候选批次没有重试',
    limitations_zh=[
      '只测最终输入状态；先修改再恢复不能被排除',
      '对象身份、最终状态与异常观测依赖冻结的闭合语言及隔离测量代码；没有对任意 Python 或形式化完整性作证明',
      '8 GiB 地址空间上限与每段 64 MiB 线性内存上限不能证明原先 256 MiB 进程树总 RSS 硬约束',
      '计时包括启动与序列化；完整哈希复核计入监督进程开销，不能作为候选算法速度',
      '首轮每组 11 包含 1 个 greedy 与 10 个 sampled；raw32 是描述性总数，secondary10 不是新生成的独立样本',
      '本次所有已准入请求都有干净测量；其他实验若触发资源或预算限制，应保留为未知，不能算功能失败'],
    comparison_v2_zh='v2 的 sample_541_explicit_docstring/extracted 达到 60/60 响应值一致；v3 为 69/72，布尔元素、浮点元素和嵌套列表三个无效输入没有触发 exact TypeError。v2 的结果仍按其原响应值协议保留',
    evidence={
      'report':rel(RESULTS / 'report.json'), 'initial_ledger':rel(RESULTS / 'initial_ledger.json'),
      'events':rel(RESULTS / 'events.jsonl'), 'observations_directory':rel(RESULTS / 'observations'),
      'failure_dimensions':rel(HERE / 'failure_dimensions.json'),
      'source_hashes':rel(HERE / 'source_hashes.json'),
      'operational_freeze':rel(ROOT / 'operational_v3/operational_freeze.json'),
      'prototype_freeze':rel(ROOT / 'limited_semantics_v3/prototype_freeze.json'),
      'component_manifest':rel(ROOT / 'limited_semantics_v3/build/trusted_clean_manifest.json'),
      'protocol':rel(ROOT / 'operational_v3/protocol.json')})
write('summary.json', summary)
write('failure_dimensions.json', {'unique_nonconformant_cases':len(failures), 'dimension_counts_overlap':dict(dimensions), 'rows':failures})
write('source_hashes.json', {'raw_records':32, 'secondary_existing_forms':10, 'source_policy':'Original source bytes; no repair, alias or new extraction',
    'identical_source_groups':REPORT['identical_source_groups'],
    'forms':[{k:f[k] for k in ('form_id','round','candidate_id','prompt_id','variant','source_sha256','conclusion')} for f in REPORT['forms']]})
write('launch_diagnostics.json', {'pre_runner_attempt':{'outcome':'optional_external_timer_missing','candidate_requests':0,'stderr':(RUN/'stderr.log').read_text()},
    'generated_batch':{'launches':1,'requests':REPORT['dispatches'],'retries':0,'exit_code':0,'stderr_bytes':(RUN/'stderr_direct.log').stat().st_size},
    'outer_shell_time':(RUN/'outer_shell_time.txt').read_text().strip(),
    'timing_caveat':'External shell time includes process exit; report snapshots precede final report serialization. Batch wall is monotonic, not inferred from filesystem timestamps.'})
print(json.dumps({'summary_bytes':(HERE/'summary.json').stat().st_size, 'unique_failures':len(failures),'projection_complete':True}))
