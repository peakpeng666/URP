"""One-use bounded supervisor for the trusted generation process, never candidates.

All preflight and worker verification/model/generation
share a 1200-second wall deadline from main entry. Terminal cleanup adds at most
2 seconds TERM grace + 3 seconds KILL/reap. Emergency ledger/status publication
has a separately bounded 2-second envelope. Every phase is reported explicitly.
"""
import argparse
import json
import os
from pathlib import Path
import resource
import secrets
import signal
import subprocess
import sys
import time

from generation_integrity import (ROOT, consume_authorization, parse_json_bytes,
                                  read_json, sha256_file, verify_frozen_inputs,
                                  write_json)
from run_generation import FIXED_LIMITS, fixed_jobs, initialize_ledger, usage, utc


class WholeWallExpired(Exception):
    pass


class SupervisorInterrupted(Exception):
    pass


def _stop_signal(signum, frame):
    raise SupervisorInterrupted("Supervisor interrupted by signal " + str(signum))


def _wall_alarm(signum, frame):
    raise WholeWallExpired("Whole generation wall deadline expired")


def _limit_child():
    resource.setrlimit(resource.RLIMIT_AS, (6 * 1024**3, 6 * 1024**3))
    resource.setrlimit(resource.RLIMIT_CPU, (900, 910))
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))


def _signal_group(process, sig):
    try:
        os.killpg(process.pid, sig)
    except ProcessLookupError:
        pass


def wait4_until(process, deadline):
    """Bounded wait with exact per-child rusage; never mixes Popen.poll/wait reaping."""
    while True:
        pid, status, rusage = os.wait4(process.pid, os.WNOHANG)
        if pid:
            process.returncode = os.waitstatus_to_exitcode(status)
            return process.returncode, rusage
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return None, None
        time.sleep(min(FIXED_LIMITS["poll_seconds"], remaining))


def group_exists(process):
    try:
        os.killpg(process.pid, 0)
        return True
    except ProcessLookupError:
        return False


def cleanup(process):
    """Return within the single fixed five-second cleanup envelope."""
    started = time.monotonic()
    _signal_group(process, signal.SIGTERM)
    code, rusage = (process.returncode, None) if process.returncode is not None else wait4_until(process, started + 2)
    term_elapsed = time.monotonic() - started
    if code is None:
        _signal_group(process, signal.SIGKILL)
        code, rusage = wait4_until(process, started + 5)
    # Best effort kill any residual group members even if the direct child exited.
    _signal_group(process, signal.SIGKILL)
    while group_exists(process) and time.monotonic() < started + 5:
        time.sleep(min(0.05, max(0, started + 5 - time.monotonic())))
    group_gone = not group_exists(process)
    return code, rusage, {"term_phase_seconds": term_elapsed,
                          "cleanup_wall_seconds": time.monotonic() - started,
                          "cleanup_complete": code is not None and group_gone,
                          "process_group_absent": group_gone,
                          "cleanup_bound_seconds": 5}


def _journal_prefix(path, line_limit, total_limit=32 * 1024**2):
    result, errors = [], []
    consumed = 0
    with Path(path).open("rb") as stream:
        for index in range(1000):
            line = stream.readline(line_limit + 1)
            if not line:
                return result, errors
            consumed += len(line)
            if len(line) > line_limit or consumed > total_limit:
                errors.append("journal_byte_limit")
                return result, errors
            if not line.endswith(b"\n"):
                errors.append("partial_final_line")
                return result, errors
            try:
                record = parse_json_bytes(line)
                if type(record) is not dict:
                    raise ValueError("Expected record object")
                result.append(record)
            except (ValueError, UnicodeError):
                errors.append("invalid_json_line_" + str(index + 1))
                return result, errors
    errors.append("journal_line_limit")
    return result, errors


def reconcile_ledger(output, config, terminal_status):
    """Retain the complete ten-slot denominator, including interrupted starts."""
    output = Path(output)
    _, ledger = read_json(output / "generation_ledger.json", 65536)
    jobs = fixed_jobs(config)
    if [{key: item[key] for key in ("id", "seed", "prompt_id", "slot")} for item in ledger["slots"]] != jobs:
        raise ValueError("Initial ten-slot ledger changed")
    events, errors = _journal_prefix(output / "attempt_events.jsonl", FIXED_LIMITS["event_line_bytes"])
    records, raw_errors = _journal_prefix(output / "raw_generations.jsonl", FIXED_LIMITS["record_line_bytes"])
    errors.extend(raw_errors)
    allowed = {job["id"]: job for job in jobs}
    starts, completions, by_id = {}, {}, {}
    started_ids, call_ids = [], []
    active = None
    failure_completed = False
    for event in events:
        kind, candidate = event.get("event"), event.get("candidate_id")
        if kind in ("candidate_attempt_started", "generate_call_started", "candidate_attempt_completed"):
            if candidate not in allowed:
                errors.append("unknown_event_candidate")
                continue
            if kind == "candidate_attempt_started":
                if active is not None or failure_completed:
                    errors.append("attempt_after_incomplete_or_failed_slot")
                active = candidate
                if candidate in starts:
                    errors.append("duplicate_attempt_start")
                starts[candidate] = event
                started_ids.append(candidate)
            elif kind == "generate_call_started":
                if candidate != active or candidate not in starts or candidate in call_ids:
                    errors.append("invalid_generate_start")
                call_ids.append(candidate)
            else:
                if candidate != active or candidate in completions or candidate not in starts:
                    errors.append("invalid_completion")
                completions[candidate] = event
                active = None
                if event.get("status") == "generation_error":
                    failure_completed = True
    if started_ids != [job["id"] for job in jobs[:len(started_ids)]] or len(started_ids) > 10:
        errors.append("attempt_order_changed")
    if len(call_ids) > 10 or call_ids != [item for item in started_ids if item in call_ids]:
        errors.append("generate_order_or_count_changed")
    if [record.get("id") for record in records] != started_ids[:len(records)]:
        errors.append("raw_record_order_changed")
    for line, record in enumerate(records, 1):
        candidate = record.get("id")
        if candidate not in allowed or candidate in by_id:
            errors.append("unknown_or_duplicate_raw_record")
            continue
        if candidate not in starts:
            errors.append("raw_without_start")
        if any(record.get(key) != allowed[candidate][key] for key in ("seed", "prompt_id", "slot")):
            errors.append("raw_identity_changed")
        if record.get("status") == "generated" and candidate not in call_ids:
            errors.append("generated_record_without_call")
        if record.get("status") not in ("generated", "generation_error"):
            errors.append("unknown_raw_status")
        for form, path_key, hash_key in (("raw", "raw_source_path", "candidate_source_sha256"),
                                       ("extracted", "extracted_source_path", "extracted_source_sha256")):
            if path_key in record:
                expected_path = f"sources/{candidate}.{form}.txt"
                if record[path_key] != expected_path or sha256_file(output / expected_path) != record.get(hash_key):
                    errors.append("source_artifact_mismatch")
        by_id[candidate] = (line, record)
    for slot in ledger["slots"]:
        candidate = slot["id"]
        if candidate in starts:
            slot["state"] = "interrupted"
            slot["attempt_started_at_utc"] = starts[candidate].get("utc")
        if candidate in by_id:
            line, record = by_id[candidate]
            slot.update(raw_record_line=line, raw_record_status=record["status"])
            for key in ("raw_source_path", "extracted_source_path", "candidate_source_sha256", "extracted_source_sha256"):
                if key in record:
                    slot[key] = record[key]
            completion = completions.get(candidate)
            if completion and completion.get("raw_record_line") == line and completion.get("status") == record["status"]:
                slot["state"] = "complete" if record["status"] == "generated" else "generation_error"
            elif completion:
                errors.append("completion_record_mismatch")
        elif candidate in completions:
            errors.append("completion_without_raw")
        # A killed write can still leave durable raw/extracted bytes without a JSONL row.
        retained = []
        for form in ("raw", "extracted"):
            relative = f"sources/{candidate}.{form}.txt"
            path = output / relative
            if path.is_file():
                retained.append({"path": relative, "sha256": sha256_file(path), "bytes": path.stat().st_size})
        if retained:
            slot["retained_source_artifacts"] = retained
    ledger.update(terminal_status=terminal_status, journal_integrity=not errors,
                  journal_errors=errors, generation_calls_started=len(call_ids),
                  attempts_started=len(starts), raw_records=len(records))
    write_json(output / "generation_ledger.json", ledger)
    return ledger


def clean_environment():
    # No PYTHONPATH, inherited Hugging Face credentials, user site, or online fallback.
    return {"PATH": "/usr/bin:/bin", "LANG": "C.UTF-8", "LC_ALL": "C.UTF-8",
            "HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1",
            "HF_HUB_DISABLE_TELEMETRY": "1", "HF_HUB_DISABLE_IMPLICIT_TOKEN": "1",
            "TORCH_FORCE_WEIGHTS_ONLY_LOAD": "1", "TOKENIZERS_PARALLELISM": "false",
            "PYTHONDONTWRITEBYTECODE": "1", "PYTHONNOUSERSITE": "1",
            "OMP_NUM_THREADS": "1", "MKL_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1"}


def main():
    started = time.monotonic()
    supervisor_started = usage()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--approval", type=Path, required=True)
    parser.add_argument("--preparation-freeze-sha256", required=True)
    parser.add_argument("--batch-id", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    previous_handlers = {sig: signal.getsignal(sig) for sig in (signal.SIGALRM, signal.SIGTERM, signal.SIGINT)}
    signal.signal(signal.SIGALRM, _wall_alarm)
    signal.signal(signal.SIGTERM, _stop_signal)
    signal.signal(signal.SIGINT, _stop_signal)
    signal.setitimer(signal.ITIMER_REAL, max(0.001, started + 1200 - time.monotonic()))
    output = args.output.resolve()
    process = None
    child_usage = None
    code = None
    marker = None
    initialized = False
    timed_out = False
    ledger = None
    worker_started = None
    cleanup_report = {"cleanup_complete": True, "cleanup_wall_seconds": 0, "cleanup_bound_seconds": 5}
    result = {"status": "not_started", "started_at_utc": utc(),
              "batch_id": args.batch_id, "preparation_freeze_sha256": args.preparation_freeze_sha256,
              "generation_retry_count": 0, "generated_code_executed": False,
              "integrity_before": "unknown", "integrity_after": "unknown"}
    try:
        if output.exists() or output.is_symlink():
            raise ValueError("Output directory already exists; preserve evidence and never retry")
        try:
            relative_output = output.relative_to(ROOT.resolve())
        except ValueError:
            raise ValueError("Generation output must be inside the v4 generation output tree")
        if len(relative_output.parts) < 2 or relative_output.parts[0] not in {"generation_outputs", "generation_results"}:
            raise ValueError("Use a separate generation_outputs/batch or generation_results/batch directory")
        verify_frozen_inputs(ROOT, args.preparation_freeze_sha256, dependencies=False)
        _, config = read_json(ROOT / "generation_config.json", 65536)
        fixed_jobs(config)
        marker = consume_authorization(ROOT, args.approval, args.preparation_freeze_sha256,
                                       args.batch_id, output, secrets.token_hex(32))
        output.mkdir(parents=True, exist_ok=False)
        initialize_ledger(output, config, args.batch_id, args.preparation_freeze_sha256)
        initialized = True
        read_fd, write_fd = os.pipe()
        try:
            lease = json.dumps(marker).encode("utf-8")
            os.write(write_fd, lease)
            os.close(write_fd)
            write_fd = None
            with (output / "generation.log").open("xb") as log:
                worker_started = time.monotonic()
                process = subprocess.Popen([str(ROOT / config["model"]["python"]), "-u", "-B", "-s",
                                            str(ROOT / "src/run_generation.py"), "--lease-fd", str(read_fd)],
                                           cwd=ROOT, stdout=log, stderr=subprocess.STDOUT,
                                           env=clean_environment(), preexec_fn=_limit_child,
                                           pass_fds=(read_fd,), start_new_session=True)
                os.close(read_fd)
                read_fd = None
                code, child_usage = wait4_until(process, started + 1200)
                if code is None:
                    raise WholeWallExpired("Whole generation deadline expired")
            result["status"] = "worker_exited"
        finally:
            if read_fd is not None:
                os.close(read_fd)
            if write_fd is not None:
                os.close(write_fd)
    except WholeWallExpired as exc:
        timed_out = True
        result.update(status="wall_timeout", error=str(exc))
    except BaseException as exc:
        result.update(status="supervisor_error", error_type=type(exc).__name__, error=str(exc)[:4096])
    finally:
        # Signal timer also bounds preflight, not merely subprocess.wait.
        signal.setitimer(signal.ITIMER_REAL, 0)
        if process is not None and (process.returncode is None or group_exists(process)):
            signal.setitimer(signal.ITIMER_REAL, 5)
            try:
                code, reaped_usage, cleanup_report = cleanup(process)
                if reaped_usage is not None:
                    child_usage = reaped_usage
            except BaseException as exc:
                cleanup_report = {"cleanup_complete": False, "cleanup_bound_seconds": 5,
                                  "cleanup_error": type(exc).__name__}
                _signal_group(process, signal.SIGKILL)
            finally:
                signal.setitimer(signal.ITIMER_REAL, 0)
        phase_end = time.monotonic()
        # Fixed-size bounded evidence publication; no model/dependency rehash outside worker.
        signal.setitimer(signal.ITIMER_REAL, 2)
        try:
            if initialized:
                if (output / "worker_status.json").exists():
                    _, worker = read_json(output / "worker_status.json", 65536)
                    result["worker_status"] = worker
                    result["integrity_after"] = worker.get("integrity_after", "unknown")
                events, event_errors = _journal_prefix(output / "attempt_events.jsonl", FIXED_LIMITS["event_line_bytes"])
                if any(event.get("event") == "integrity_before_passed" for event in events):
                    result["integrity_before"] = "passed"
                ledger = reconcile_ledger(output, config, result["status"])
                complete = (not timed_out and result["status"] == "worker_exited"
                            and code == 0 and result.get("worker_status", {}).get("status") == "complete"
                            and result["integrity_before"] == result["integrity_after"] == "passed"
                            and cleanup_report["cleanup_complete"] and ledger["journal_integrity"]
                            and not event_errors and all(slot["state"] == "complete" for slot in ledger["slots"]))
                if complete:
                    result["status"] = "complete"
                elif result["status"] == "worker_exited":
                    result["status"] = "incomplete_or_failed"
                final_supervisor = usage()
                supervisor_cpu = final_supervisor["process_cpu_seconds"]
                worker_cpu = None if child_usage is None else child_usage.ru_utime + child_usage.ru_stime
                result.update(exit_code=code, wall_timeout=timed_out, journal_integrity=ledger["journal_integrity"], **cleanup_report,
                              supervisor_initial_usage=supervisor_started, supervisor_final_usage=final_supervisor,
                              supervisor_cpu_seconds=supervisor_cpu,
                              worker_cpu_seconds=worker_cpu,
                              combined_cpu_seconds=None if worker_cpu is None else supervisor_cpu + worker_cpu,
                              worker_wall_seconds=None if worker_started is None else phase_end - worker_started,
                              worker_user_cpu_seconds=None if child_usage is None else child_usage.ru_utime,
                              worker_system_cpu_seconds=None if child_usage is None else child_usage.ru_stime,
                              worker_peak_rss_kib=None if child_usage is None else child_usage.ru_maxrss,
                              main_and_cleanup_wall_seconds=phase_end - started,
                              whole_wall_limit_seconds=1200, cleanup_grace_seconds=5,
                              publication_limit_seconds=2, ended_at_utc=utc(),
                              publication_elapsed_before_final_write_seconds=time.monotonic() - phase_end,
                              measured_whole_wall_before_final_write_seconds=time.monotonic() - started,
                              final_status_write_included_in_measurement=False)
                ledger["terminal_status"] = result["status"]
                write_json(output / "generation_ledger.json", ledger)
                write_json(output / "process_status.json", result, exclusive=True)
        except BaseException as exc:
            # Existing journal/slot plan remains authoritative evidence of incomplete work.
            result.update(status="publication_failed", publication_error_type=type(exc).__name__)
        finally:
            signal.setitimer(signal.ITIMER_REAL, 0)
    for sig, previous in previous_handlers.items():
        signal.signal(sig, previous)
    print(json.dumps(result, ensure_ascii=False, allow_nan=False), flush=True)
    return 0 if result["status"] == "complete" else 1


if __name__ == "__main__":
    raise SystemExit(main())
