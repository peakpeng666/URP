"""Trusted handwritten host-helper fault tests; never model candidate code."""
import json,os,pathlib,subprocess,sys
from unittest.mock import patch
import one_request
from batch_runner import make_request
HERE=pathlib.Path(__file__).resolve().parent;ROOT=HERE.parent
REQUEST=make_request('def sort_numbers(values):\n    return sorted(values)\n',{'id':'one','valid':True,'kind':'list','input':[1],'expected':[1]})
REAL_POPEN=subprocess.Popen

def helper_factory(program):
    def factory(command,*args,**kwargs):
        return REAL_POPEN([str(ROOT/'.venv/bin/python'),'-B','-c',program],*args,**kwargs)
    return factory

def check_reaped(result):
    if result['worker_unreaped'] or result['returncode'] is None:raise AssertionError('worker not reaped')
    try:os.kill(result['worker_pid'],0)
    except ProcessLookupError:return
    raise AssertionError('worker PID still exists')

def main():
    out=HERE/'supervisor_fault_validation.json'
    if out.exists():raise FileExistsError(out)
    results=[]
    with patch.object(one_request.subprocess,'Popen',helper_factory('import os,time; os.close(1); os.close(2); time.sleep(30)')):
        r=one_request.launch(REQUEST)
    if r['termination']!='wall_timeout_after_eof':raise AssertionError(r)
    check_reaped(r);results.append({'case':'EOF_before_exit','result':r})
    real_selector=one_request.selectors.DefaultSelector
    class RaisingSelector:
        def __init__(self):self.inner=real_selector()
        def __getattr__(self,name):return getattr(self.inner,name)
        def select(self,*args):raise OSError('handwritten selector fault injection')
    with patch.object(one_request.selectors,'DefaultSelector',RaisingSelector):r=one_request.launch(REQUEST)
    if r['termination']!='supervisor_error':raise AssertionError(r)
    check_reaped(r);results.append({'case':'selector_exception','result':r})
    with patch.object(one_request.subprocess,'Popen',helper_factory('import os,time; os.write(1,b"x"*40000); time.sleep(30)')):
        r=one_request.launch(REQUEST)
    if r['termination']!='output_limit':raise AssertionError(r)
    check_reaped(r);results.append({'case':'worker_output_overflow','result':r})
    out.write_text(json.dumps({'all_reaped':True,'results':results,'generated_candidates_executed':0},indent=2))
    print(json.dumps({'all_reaped':True,'cases':len(results),'generated_candidates_executed':0}))
if __name__=='__main__':main()
