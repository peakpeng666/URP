import ast,json,pathlib,sys,unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src/guest'));sys.path.insert(0,str(ROOT/'tests'))
from limited_validator import parse_and_validate,Validator,RejectedLanguage
from handwritten_programs import REFERENCE,REJECTED,SEMANTIC

class GrammarTests(unittest.TestCase):
    def test_reference_and_admitted_handwritten(self):
        for name,source in {'reference':REFERENCE,**SEMANTIC}.items():
            with self.subTest(name=name):parse_and_validate(source)
    def test_all_denied_handwritten(self):
        for name,source in REJECTED.items():
            with self.subTest(name=name):
                with self.assertRaises((RejectedLanguage,SyntaxError)):parse_and_validate(source)
    def test_unknown_ast_field(self):
        t=ast.parse(REFERENCE);t.body[0]._fields=tuple(t.body[0]._fields)+('unexpected_future_field',)
        with self.assertRaises(RejectedLanguage):Validator().validate(t)
    def test_node_and_source_bounds(self):
        for source in [REFERENCE+'#'*16384,'def sort_numbers(values):\n'+'    a = 0\n'*300]:
            with self.assertRaises(RejectedLanguage):parse_and_validate(source)
    def test_tuple_store_and_loop_else(self):
        for source in ['def sort_numbers(values):\n    a, b = values\n    return []\n','def sort_numbers(values):\n    for x in values:\n        x = 0\n    else:\n        return []\n']:
            with self.assertRaises(RejectedLanguage):parse_and_validate(source)

if __name__=='__main__':unittest.main(verbosity=2)
