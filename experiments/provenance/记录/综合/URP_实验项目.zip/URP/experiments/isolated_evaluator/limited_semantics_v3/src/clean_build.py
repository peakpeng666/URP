"""Rebuild fixed guest from frozen, explicit input directories only.

Must be reviewed before --execute. Never accepts candidate source paths.
"""
import hashlib,json,os,pathlib,resource,subprocess,sys,time
ROOT=pathlib.Path(__file__).resolve().parents[1]
ENV={'PATH':'/usr/bin:/bin','RAYON_NUM_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1','VIRTUAL_ENV':str(ROOT.parent/'.venv')}

def inventory():
    items={}
    for base in (ROOT/'src/guest',ROOT.parent/'.venv'):
        for p in sorted(base.rglob('*')):
            if p.is_file():
                with p.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
                items[os.path.relpath(p,ROOT)]={'bytes':p.stat().st_size,'sha256':digest,'symlink':os.readlink(p) if p.is_symlink() else None}
    return items

def limits():
    resource.setrlimit(resource.RLIMIT_CPU,(110,110))
    resource.setrlimit(resource.RLIMIT_AS,(32*1024**3,32*1024**3))
    resource.setrlimit(resource.RLIMIT_CORE,(0,0))

command=[str(ROOT.parent/'.venv/bin/componentize-py'),'-d','evaluator.wit','-w','evaluator','componentize','--stub-wasi','-p','.','trusted_guest','-o',str(ROOT/'build/evaluator_clean.wasm')]
config={'command':command,'cwd':str(ROOT/'src/guest'),'environment':ENV,
        'explicit_site_packages':str(ROOT.parent/'.venv/lib/python3.12/site-packages'),
        'expected_runtime_environment_keys':['PYTHONUNBUFFERED','PYTHONHOME','PYTHONPATH'],
        'guest_files':['evaluator.wit','trusted_guest.py','limited_validator.py','semantic_evaluator.py'],
        'allowed_new_build_outputs':['src/guest/__pycache__/'+name+'.cpython-314.pyc' for name in ('trusted_guest','limited_validator','semantic_evaluator')],
        'model_candidate_inputs':False}
if sys.argv[1:] == ['--prepare']:
    (ROOT/'provenance/clean_build_config.json').write_text(json.dumps(config,indent=2))
    data=inventory()
    (ROOT/'provenance/clean_build_inputs.json').write_text(json.dumps(data,indent=2))
    print(json.dumps({'files':len(data),'total_bytes':sum(i['bytes'] for i in data.values()),'config':config}))
elif sys.argv[1:] == ['--execute']:
    if (ROOT/'logs/clean_build.log').exists():raise FileExistsError('clean rebuild already attempted')
    expected=json.loads((ROOT/'provenance/clean_build_inputs.json').read_text())
    if inventory()!=expected:raise RuntimeError('build inputs changed')
    if json.loads((ROOT/'provenance/clean_build_config.json').read_text())!=config:raise RuntimeError('build config changed')
    before=resource.getrusage(resource.RUSAGE_CHILDREN)
    start=time.monotonic()
    with (ROOT/'logs/clean_build.log').open('wb') as f:
        p=subprocess.Popen(command,cwd=ROOT/'src/guest',env=ENV,stdout=f,stderr=subprocess.STDOUT,preexec_fn=limits)
        try:rc=p.wait(timeout=115)
        except subprocess.TimeoutExpired:p.kill();rc=p.wait()
    u=resource.getrusage(resource.RUSAGE_CHILDREN)
    after=inventory()
    added={k:v for k,v in after.items() if k not in expected}
    allowed=set(config['allowed_new_build_outputs'])
    allowed_output=(set(added)<=allowed and all(v['bytes']<=65536 and v['symlink'] is None for v in added.values()))
    unchanged=all(after.get(k)==v for k,v in expected.items()) and allowed_output
    d={'returncode':rc,'wall_seconds':time.monotonic()-start,'user_seconds':u.ru_utime-before.ru_utime,'sys_seconds':u.ru_stime-before.ru_stime,'maxrss_kib':u.ru_maxrss,
       'inputs_unchanged':unchanged,'new_build_outputs':added,'limits':{'cpu_seconds':110,'wall_seconds':115,'as_bytes':32*1024**3},'config':config}
    (ROOT/'logs/clean_build_result.json').write_text(json.dumps(d,indent=2));print(json.dumps(d));print((ROOT/'logs/clean_build.log').read_text())
    if rc or not unchanged:raise RuntimeError('clean build failed')
else:raise SystemExit('use --prepare or --execute')
