"""Documented single handwritten recheck after fixing a truncated-message assertion."""
import json,pathlib,sys,time
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'));sys.path.insert(0,str(ROOT/'tests'))
from one_request import launch
from validate_handwritten import request,descriptor,clean
from handwritten_programs import SEMANTIC
OUT=ROOT/'results/fuel_control_recheck.json'
if OUT.exists():raise FileExistsError(OUT)
original=json.loads((ROOT/'results/handwritten_validation/report.json').read_text())
row=next(x for x in original['rows'] if x['name']=='resource/fuel_loop')
old=json.loads((ROOT/'results/handwritten_validation'/row['observation']).read_text())
if not (clean(old) and old['worker']['status']=='trapped' and old['worker']['fuel_remaining']==0):raise RuntimeError('original evidence does not support correction')
case={'kind':'list','input':[],'valid':True,'expected':[]}
req=request(SEMANTIC['fuel_loop'],descriptor(case));result=launch(req)
passed=clean(result) and result['worker']['status']=='trapped' and result['worker']['fuel_remaining']==0
out={'generated_candidates_executed':0,'handwritten_calls':1,'passed':passed,'original_assertion_failure_preserved':True,'correction':'Trapped plus zero fuel from trusted Store counter; bounded traceback prefix may omit textual cause','artifact_changed':False,'limits_changed':False,'result':result}
OUT.write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k!='result'}))
if not passed:raise RuntimeError('fuel control failed')
