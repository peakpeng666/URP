"""Strictly load the verified official model; never invoke generation or candidates."""
import argparse
import json
import os
from pathlib import Path
import resource
import sys
import time

from generation_integrity import ROOT, read_json, sha256_file, verify_frozen_inputs, write_json
from run_generation import fixed_jobs, verify_model_provenance, usage, utc
from safe_model_load import load_trusted_components

ORIGINAL_FREEZE = "0ecf0ade247065f7ed38a948082383d093d485bfb1e621add32dfb8096dbf0ab"
LOAD_ONLY_LIMITS = {resource.RLIMIT_AS: (6 * 1024**3, 6 * 1024**3),
                    resource.RLIMIT_CPU: (120, 120), resource.RLIMIT_CORE: (0, 0),
                    resource.RLIMIT_FSIZE: (4 * 1024**2, 4 * 1024**2)}


def check_load_only_limits():
    if any(resource.getrlimit(key) != value for key, value in LOAD_ONLY_LIMITS.items()):
        raise RuntimeError("Model-load-only effective limits mismatch")
    return {str(key): list(resource.getrlimit(key)) for key in LOAD_ONLY_LIMITS}


def verify_original_preserved():
    original = ROOT.with_name("prospective_prompt_v4")
    _, saved = read_json(ROOT / "original_preservation_inventory.json", 1024**2)
    if saved["original_preparation_freeze_sha256"] != ORIGINAL_FREEZE:
        raise RuntimeError("Original preparation identity changed")
    actual = sorted(str(path.relative_to(original)) for path in original.rglob("*") if path.is_file())
    if actual != sorted(saved["all_original_files"]):
        raise RuntimeError("Original preparation/failed-attempt file inventory changed")
    for name, expected in saved["all_original_files"].items():
        if sha256_file(original / name) != expected:
            raise RuntimeError("Original preparation/failed-attempt file changed: " + name)
    return {"all_original_files": len(actual), "original_preparation_freeze_sha256": ORIGINAL_FREEZE,
            "preserved": True}


class LoadJournal:
    def __init__(self, output):
        self.stream = (Path(output) / "model_load_events.jsonl").open("xb")
    def event(self, kind, **fields):
        data = (json.dumps({"event": kind, "utc": utc(), **usage(), **fields}, allow_nan=False) + "\n").encode()
        if len(data) > 1024**2:
            raise RuntimeError("Load-only event line cap exceeded")
        self.stream.write(data)
        self.stream.flush()
        os.fsync(self.stream.fileno())
    def close(self):
        self.stream.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--preparation-freeze-sha256", required=True)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    output = args.output.resolve(strict=True)
    if output.parent != (ROOT / "results").resolve() or output.is_symlink():
        raise ValueError("Load-only output must be a direct results child")
    effective = check_load_only_limits()
    journal = LoadJournal(output)
    status = {"stage": "compatibility_model_load_only", "status": "failed",
              "generation_calls": 0, "candidate_executions": 0,
              "generation_authorization_created_or_consumed": False,
              "preparation_freeze_sha256": args.preparation_freeze_sha256,
              "effective_limits": effective, "initial_usage": usage()}
    try:
        freeze = verify_frozen_inputs(ROOT, args.preparation_freeze_sha256)
        status["original_before"] = verify_original_preserved()
        _, config = read_json(ROOT / "generation_config.json", 65536)
        fixed_jobs(config)
        verify_model_provenance(config, freeze)
        journal.event("load_only_integrity_before_passed")
        torch, tokenizer, model, set_seed, audit = load_trusted_components(config, journal, load_only=True)
        status.update(status="passed", load_audit=audit)
        del model, tokenizer, set_seed, torch
    except Exception as exc:
        status.update(status="failed", error_type=type(exc).__name__, error=str(exc)[:4096])
        journal.event("load_only_error", **status)
    finally:
        try:
            verify_frozen_inputs(ROOT, args.preparation_freeze_sha256)
            status["original_after"] = verify_original_preserved()
            status["integrity_after"] = "passed"
        except Exception as exc:
            status.update(status="failed", integrity_after="failed", integrity_error=str(exc)[:4096])
        status["final_usage"] = usage()
        write_json(output / "model_load_status.json", status, exclusive=True)
        journal.event("load_only_completed", status=status["status"], generation_calls=0, candidate_executions=0)
        journal.close()
    return 0 if status["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
