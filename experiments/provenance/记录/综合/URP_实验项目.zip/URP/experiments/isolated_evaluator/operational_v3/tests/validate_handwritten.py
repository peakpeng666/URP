"""Operational runner end-to-end tests; manually written programs only."""
import json
import pathlib
import sys
import time
import resource

HERE = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parent / 'limited_semantics_v3/tests'))
from handwritten_programs import REFERENCE, SEMANTIC, body
from adapter import load_cases, make_request
from batch_runner import run_forms
from checker import classify
from integrity import file_hash, verify_freeze
from one_request import launch, worker_limits

OUT = HERE / 'results/handwritten_validation'
FREEZE = HERE / 'operational_freeze.json'


def form(name, source, variant='raw'):
    return {'form_id': 'handwritten/' + name + '/' + variant, 'round': 'handwritten',
            'candidate_id': name, 'prompt_id': 'manual_control', 'variant': variant, 'source': source}


def main():
    OUT.mkdir(exist_ok=False)
    approved_inputs = file_hash(FREEZE)
    verify = lambda: verify_freeze(FREEZE, approved_inputs)
    verify()
    checks = []
    all_reports = []
    cases = load_cases()
    reference = run_forms([form('reference', REFERENCE)], cases, {'raw'}, output_dir=OUT / 'reference72', integrity_check=verify)
    all_reports.append(reference)
    checks.append({'name': 'reference_all72', 'passed': reference['forms'][0]['conclusion'] == 'all_required_cases_conformant'
                   and reference['clean_schema_validated_completions'] == 72 and reference['result_certification_valid']})
    one = {'id': 'manual_one', 'kind': 'list', 'valid': True, 'input': [1], 'expected': [1]}
    invalid = {'id': 'manual_invalid_bool', 'kind': 'identity', 'valid': False, 'input': True, 'expected_exception': 'TypeError'}
    controls = [
        ('wrong_value', SEMANTIC['wrong_value'], one, 'case_nonconformant'),
        ('same_object', SEMANTIC['same_object'], one, 'case_nonconformant'),
        ('mutation_only', body('copy = sorted(values)\nvalues[0] = values[0] + 1\nreturn copy'), one, 'case_nonconformant'),
        ('invalid_wrong_exception', SEMANTIC['other_exception'], invalid, 'case_nonconformant'),
        ('invalid_return', body('return []'), invalid, 'case_nonconformant'),
        ('restore_mutation_limit', SEMANTIC['restore_mutation'], one, 'case_conformant'),
        ('fuel_unresolved', SEMANTIC['fuel_loop'], one, 'resource_unresolved'),
        ('grammar_rejected_no_dispatch', 'def sort_numbers(values):\n    return values[:]\n', one, 'not_run_grammar_rejection'),
        ('structural_rejected_no_dispatch', 'definitely not python ???', one, 'not_run_structural_rejection'),
    ]
    for name, source, case, expected in controls:
        result = run_forms([form(name, source)], [case], {'raw'}, output_dir=OUT / name, integrity_check=verify)
        all_reports.append(result)
        checks.append({'name': name, 'passed': result['rows'][0]['status'] == expected and result['result_certification_valid']})
    # Exact source hash corruption must fail before guest entry, with a real worker
    # launched under the same limits, never as a vacuous missing-limit rejection.
    request = make_request(REFERENCE, one); request['source_sha256'] = '0' * 64
    observation = launch(request)
    (OUT / 'corrupt_request_hash.json').write_text(json.dumps(observation, indent=2))
    checks.append({'name': 'corrupt_request_hash_preentry', 'passed': observation['returncode'] == 2
                   and observation['guest_entry_observed'] is False
                   and observation['worker']['status'] == 'initialization_or_request_error'
                   and 'source hash mismatch' in observation['worker']['error']})
    # Internal worker stdin is explicitly bounded before JSON decode. This trusted
    # direct subprocess receives the exact required resource limits as preexec.
    import subprocess
    before = resource.getrusage(resource.RUSAGE_CHILDREN)
    started = time.monotonic()
    child = subprocess.run([str(HERE.parent / '.venv/bin/python'), '-B', str(HERE / 'runtime_worker.py')],
                           input=b'x' * 65537, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                           env={}, preexec_fn=worker_limits, timeout=6)
    after = resource.getrusage(resource.RUSAGE_CHILDREN)
    response = json.loads(child.stdout)
    stdin_observation = {'returncode': child.returncode, 'response': response, 'wall_seconds': time.monotonic() - started,
                         'worker_user_seconds': after.ru_utime - before.ru_utime, 'worker_sys_seconds': after.ru_stime - before.ru_stime}
    (OUT / 'oversize_stdin.json').write_text(json.dumps(stdin_observation, indent=2))
    checks.append({'name': 'bounded_stdin_predecode', 'passed': child.returncode == 2
                   and response['status'] == 'initialization_or_request_error' and 'stdin too large' in response['error']})
    verify()
    summary = {'generated_sources_executed': 0, 'operational_freeze_sha256': approved_inputs,
               'all_passed': all(c['passed'] for c in checks), 'checks': checks,
               'clean_reference_cases': reference['clean_schema_validated_completions'],
               'runner_dispatches': sum(r['dispatches'] for r in all_reports),
               'extra_preentry_worker_tests': 2,
               'worker_cpu_seconds': sum(r['worker_cpu_seconds'] for r in all_reports)
                   + observation['worker_user_seconds'] + observation['worker_sys_seconds']
                   + stdin_observation['worker_user_seconds'] + stdin_observation['worker_sys_seconds'],
               'runner_wall_seconds_sum': sum(r['elapsed_seconds'] for r in all_reports),
               'runner_supervisor_cpu_seconds_sum': sum(r['supervisor_cpu_seconds'] for r in all_reports),
               'integrity_wall_seconds_sum': sum(r['integrity_wall_seconds'] for r in all_reports),
               'integrity_cpu_seconds_sum': sum(r['integrity_cpu_seconds'] for r in all_reports)}
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary))
    if not summary['all_passed']:
        raise RuntimeError('operational handwritten validation failed')

if __name__ == '__main__':
    main()
