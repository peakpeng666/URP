"""Public data-only projection; never runs a model or a candidate."""
import collections
import hashlib
import json
import pathlib
import statistics

HERE=pathlib.Path(__file__).resolve().parent
ROOT=HERE.parent; URP=ROOT.parents[1]
STUDY=ROOT/'prospective_prompt_v4_compat'
GEN=STUDY/'generation_outputs/generated_v4_compat_20261004_01'
EVAL=STUDY/'evaluation_outputs/evaluated_v4_compat_20261004_01'
OLD=ROOT/'prospective_prompt_v4'
report=json.loads((EVAL/'report.json').read_text())
generation=json.loads((GEN/'process_status.json').read_text())
records=[json.loads(x) for x in (GEN/'raw_generations.jsonl').read_text().splitlines()]
pop=json.loads((STUDY/'populations/generated_v4_compat_20261004_01.json').read_text())

def rel(p):return str(p.relative_to(URP))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,v):(HERE/n).write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n')

observations=[]; failures=[]
for row in report['rows']:
    if 'observation_file' not in row:continue
    p=EVAL/row['observation_file'];o=json.loads(p.read_text());observations.append(o)
    if row['status']=='case_nonconformant':
        if row['fixture_valid'] or o['worker']['payload']['invocation']!='returned':
            raise ValueError('new failure pattern requires explicit projection review')
        failures.append({'candidate_id':row['candidate_id'],'prompt_id':row['prompt_id'],'panel':row['panel'],
            'fixture_id':row['fixture_id'],'reason':'invalid_input_returned_instead_of_exact_TypeError',
            'observation':rel(p),'source_sha256':row['source_sha256']})

reason={
'sample_601_A':'sorted(..., reverse=True) keyword form',
'sample_631_A':'sorted(..., reverse=True) keyword form',
'sample_661_A':'any(generator)',
'sample_661_B':'type(i) used as a data value',
'sample_701_B':'all(isinstance(...)) generator differs from sole admitted exact-type idiom',
'sample_701_A':'Boolean or',
'sample_751_B':'zero-argument list()'}
rejections=[{'candidate_id':f['candidate_id'],'prompt_id':f['prompt_id'],'source_sha256':f['source_sha256'],
             'stage':'grammar_rejection','first_frozen_rule_rejection':reason[f['candidate_id']],
             'interpretation':'Unsupported syntax under the frozen measurement-integrity language; functional behavior not executed'}
            for f in report['forms'] if f['conclusion']=='grammar_rejection']
source_forms=[]
for record in records:
    for variant,key,hkey in [('raw','candidate_source','candidate_source_sha256'),('selected','extraction','extracted_source_sha256')]:
        source=record[key] if variant=='raw' else record[key]['source']
        actual=hashlib.sha256(source.encode()).hexdigest()
        if actual!=record[hkey]:raise ValueError('source hash mismatch')
        source_forms.append({'candidate_id':record['id'],'seed':record['seed'],'prompt_id':record['prompt_id'],
            'variant':variant,'sha256':actual,'bytes':len(source.encode()),
            'source_path':rel(GEN/record['raw_source_path' if variant=='raw' else 'extracted_source_path']),
            'dynamic_scoring_scope':variant=='selected'})
duplicates=collections.defaultdict(list)
for f in source_forms:duplicates[f['sha256']].append(f['candidate_id']+'/'+f['variant'])
write('source_hashes.json',{'model_generation_records':10,'selected_primary_forms':10,'raw_static_diagnostic_forms':10,
    'forms':source_forms,'identical_source_groups':[{'sha256':h,'form_ids':ids} for h,ids in duplicates.items() if len(ids)>1]})
write('failure_cases.json',{'unique_cases':len(failures),'reason':'invalid inputs did not raise exact TypeError','cases':failures})
write('grammar_rejections.json',{'count':len(rejections),'first_rejection_only':True,'forms':rejections})

arms={}
for arm in ('A','B'):
    values=[r for r in records if r['prompt_id']==arm]
    arms[arm]={'calls':len(values),'input_tokens':sum(r['input_token_count'] for r in values),
        'output_tokens':sum(r['output_token_count'] for r in values),'call_wall_seconds':sum(r['elapsed_seconds'] for r in values),
        'call_cpu_seconds':sum(r['cpu_seconds'] for r in values)}
summary={k:v for k,v in report.items() if k!='rows'}
summary.update(public_schema='urp-p2-v4-public-summary-1',independent_outcome_verification='passed_all432_observations_864_events_1440_rows_and_frozen_hashes_no_replay',
 title_zh='P2：五对新种子、两种提示词的前瞻性小样本实验',
 headline_zh='A 与 B 的完整协议通过数均为0/5；没有观察到完整契约通过率提升',
 selected_forms=10,paired_seeds=[601,631,661,701,751],ledger_rows=1440,evaluation_events=864,
 case_status_counts=dict(collections.Counter(r['status'] for r in report['rows'])),
 valid_observations=360,valid_conformant=360,invalid_observations=72,invalid_conformant=48,invalid_nonconformant=24,
 grammar_rejections=rejections,
 generation={'attempted_successful_stage_calls':10,'predecessor_stage_calls':0,'fresh_generation_stage_attempts':1,
     'earlier_infrastructure_attempts':1,'automatic_retries':0,'records':10,'output_tokens':4300,
     'eos_stops':sum(r['stop_reason']=='eos' for r in records),'token_cap_stops':sum(r['stop_reason']=='token_cap' for r in records),
     'arms':arms,'whole_wall_seconds':generation['measured_whole_wall_before_final_write_seconds'],
     'worker_cpu_seconds':generation['worker_cpu_seconds'],'supervisor_cpu_seconds':generation['supervisor_cpu_seconds'],
     'combined_cpu_seconds':generation['combined_cpu_seconds'],'worker_peak_rss_kib':generation['worker_peak_rss_kib'],
     'cleanup_complete':generation['cleanup_complete'],'integrity_before':generation['integrity_before'],'integrity_after':generation['integrity_after']},
 failure_context={'earlier_stage':'framework initialization guard stopped before generation;10 slots not_started and1,440 unavailable planned rows retained',
     'earlier_stage_wall_seconds':9.720806643999822,'earlier_stage_worker_cpu_seconds':9.61018,
     'compatibility_probe_wall_seconds':11.488795565004693,'compatibility_probe_worker_cpu_seconds':12.414457,
     'compatibility_probe_peak_rss_kib':2488556,'compatibility_probe_generated_calls':0,
     'compatibility_change':'Complete pinned trusted imports, record84 registrations, clear process-local added registry once; retain empty-registry/base-only checkpoint scanning and every real weights_only load guard; no allowlist expansion'},
 successful_generation_plus_evaluation_wall_seconds=generation['measured_whole_wall_before_final_write_seconds']+report['whole_batch_wall_seconds'],
 successful_generation_plus_evaluation_worker_cpu_seconds=generation['worker_cpu_seconds']+report['worker_cpu_seconds'],
 evaluation_max_worker_rss_kib=max(o['worker']['maxrss_kib'] for o in observations),
 evaluation_max_supervisor_rss_kib=max(o['supervisor_peak_rss_kib'] for o in observations),
 evaluation_request_wall_seconds={'sum':sum(o['wall_seconds'] for o in observations),'max':max(o['wall_seconds'] for o in observations),
    'median':statistics.median(o['wall_seconds'] for o in observations)},
 maximum_request_fuel_consumed=max(o['worker']['fuel_budget']-o['worker']['fuel_remaining'] for o in observations),
 distinct_worker_pids=len({o['worker_pid'] for o in observations}),forced_terminations=sum(o['termination'] is not None for o in observations),
 unreaped_workers=sum(o['worker_unreaped'] for o in observations),
 panel_design={'development_count':72,'prospective_count':72,'valid_per_panel':60,'invalid_per_panel':12,
    'prospective_sha256':sha(STUDY/'fixtures/prospective72.json'),'typed_exact_instance_overlap':0,
    'semantic_category_overlap':True,'development_only_non_novel_anchors':['empty list','scalar None'],
    'claim':'Prospectively frozen new instances within a known task; not new semantic categories or cross-task generalization'},
 model={'repo':'Salesforce/codegen-350M-mono','revision':'d9107f71cca463240db1143f4a75a927a27fcb27',
    'weight_sha256':'90e20f4887289739a435452f26974d97937adb41485f9c1a7b3d3810aac6773d',
    'torch':'2.14.1+cpu','transformers':'5.18.0','device':'cpu','dtype':'float32','threads':1,
    'checkpoint_warning':'20 legacy transformer.h.*.attn.causal_mask keys are unexpected; identical warning in prior runs; pinned implementation computes masks dynamically. No claim of original-training-runtime numerical equivalence'},
 interpretation_zh=[
    '10次真正的新生成，预先固定每次首函数提取；raw仅作静态诊断，不在结果中择优挑形式',
    'A/B各5次，完整协议通过均为0；五对种子均无通过者，不能据此宣称两种提示词等效',
    '7段语言不支持而未执行，不能说它们运行后都存在功能错误',
    '3段实际执行形式在各120个有效输入上均满足所有观测；24个失败点均为无效输入未抛精确TypeError',
    'result=null且result_shape_valid=false表示返回对象未按合法平面整数列表序列化，不能解读为实际返回None',
    '只有5对样本，且可执行形式数不同，不能用条件于语法准入后的平均用例分数证明A或B优越',
    '旧72是开发证据，新72事前冻结且实例不重叠，但测试类型/合同已知；不是广义无偏泛化验证',
    '只测最终输入状态，不排除先修改再恢复；闭合语言完整性不是任意Python或形式化安全证明',
    '内置sorted被允许；这项小试验不等于发现了新排序算法',
    '各阶段CPU/RSS分别记录；不证明原256MiB进程树总RSS硬限。字节缓存/依赖须重建'],
 evidence={'report':rel(EVAL/'report.json'),'initial_ledger':rel(EVAL/'initial_ledger.json'),'evaluation_events':rel(EVAL/'events.jsonl'),
    'observations_directory':rel(EVAL/'observations'),'generation_records':rel(GEN/'raw_generations.jsonl'),
    'generation_events':rel(GEN/'attempt_events.jsonl'),'generation_ledger':rel(GEN/'generation_ledger.json'),
    'generation_status':rel(GEN/'process_status.json'),'source_hashes':rel(HERE/'source_hashes.json'),
    'failures':rel(HERE/'failure_cases.json'),'preparation_freeze':rel(STUDY/'preparation_freeze.json'),
    'population_freeze':rel(STUDY/'populations/generated_v4_compat_20261004_01.json'),
    'earlier_failed_stage':rel(OLD/'generation_outputs/generated_v4_20261004_01/process_status.json'),
    'earlier_unavailable_plan':rel(OLD/'results/failed_generation_unexecuted_plan.json'),
    'safe_load_probe':rel(STUDY/'results/model_load_only_01/model_load_status.json')})
manual=json.loads((OLD/'results/handwritten_validation/summary.json').read_text())
failed=json.loads((OLD/'generation_outputs/generated_v4_20261004_01/process_status.json').read_text())
probe=json.loads((STUDY/'results/model_load_only_01/model_load_supervisor_status.json').read_text())
costs=[
 {'stage':'handwritten_preparation_validation','wall_seconds':manual['runner_wall_seconds'],'worker_cpu_seconds':manual['worker_cpu_seconds'],'supervisor_cpu_seconds':manual['runner_supervisor_cpu_seconds']},
 {'stage':'earlier_framework_failure_zero_model_calls','wall_seconds':failed['measured_whole_wall_before_final_write_seconds'],'worker_cpu_seconds':failed['worker_cpu_seconds'],'supervisor_cpu_seconds':failed['supervisor_cpu_seconds']},
 {'stage':'safe_model_load_only_zero_generate_calls','wall_seconds':probe['whole_wall_seconds'],'worker_cpu_seconds':probe['worker_rusage']['user_seconds']+probe['worker_rusage']['system_seconds'],'supervisor_cpu_seconds':None},
 {'stage':'fresh_ten_generation_stage','wall_seconds':generation['measured_whole_wall_before_final_write_seconds'],'worker_cpu_seconds':generation['worker_cpu_seconds'],'supervisor_cpu_seconds':generation['supervisor_cpu_seconds']},
 {'stage':'one_scoring_batch','wall_seconds':report['whole_batch_wall_seconds'],'worker_cpu_seconds':report['worker_cpu_seconds'],'supervisor_cpu_seconds':report['whole_batch_supervisor_cpu_seconds']}]
summary['recorded_stage_costs']=costs
summary['recorded_stage_wall_seconds_sum']=sum(c['wall_seconds'] for c in costs)
summary['recorded_stage_worker_cpu_seconds_sum']=sum(c['worker_cpu_seconds'] for c in costs)
summary['recorded_stage_known_supervisor_cpu_seconds_sum']=sum(c['supervisor_cpu_seconds'] or 0 for c in costs)
summary['cost_accounting_caveat']='The model-load-only supervisor CPU was not instrumented. Stage wall snapshots have documented final-publication boundaries. Implementation, independent audits, freeze creation and all static checks are not a fully metered total; do not label these sums total project cost.'
summary['stopping_rule_status']='Closed as preregistered because both arms have zero full-protocol passes; no further prompt tuning or extra model runs in this study'
write('summary.json',summary)
print(json.dumps({'summary_bytes':(HERE/'summary.json').stat().st_size,'failure_cases':len(failures),'selected_forms':len(report['forms'])}))
