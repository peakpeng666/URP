"""Only manually authored programs; never loads generated candidate records."""
REFERENCE='''def sort_numbers(values):
    if type(values) != list:
        raise TypeError("plain list required")
    if not all(type(v) == int for v in values):
        raise TypeError("plain int required")
    return sorted(values)
'''

def body(text):
    return 'def sort_numbers(values):\n'+''.join('    '+line+'\n' for line in text.splitlines())

REJECTED={
'callable_alias':body('f = sorted\nreturn f(values)'),
'callable_return':body('return sorted'),
'method_escape':body('f = values.append\nreturn []'),
'builtin_in_container':body('return [list]'),
'type_escape':body('return type(values)'),
'reflection_chain':body('return type(values).__name__'),
'three_argument_type':body('if type(1, 2, 3) == list:\n    return []\nreturn []'),
'dynamic_callee':body('return values[0](values)'),
'recursive_call':body('return sort_numbers(values)'),
'sorted_keyword':body('return sorted(values, reverse=1)'),
'sort_callback':body('values.sort(key=sorted)\nreturn values'),
'star_args':body('return sorted(*values)'),
'kw_args':body('return sorted(**values)'),
'extra_range_argument':body('for i in range(0, 1, 1):\n    values.append(i)\nreturn values'),
'import':body('import json\nreturn []'),
'global':body('global sorted\nreturn []'),
'nonlocal':body('nonlocal values\nreturn []'),
'nested_function':body('def f(x):\n    return x\nreturn []'),
'class':body('class C:\n    x = 0\nreturn []'),
'lambda':body('f = lambda x: x\nreturn []'),
'comprehension':body('return [v for v in values]'),
'escaped_generator':body('return (v for v in values)'),
'generator_filter':body('if all(type(v) == int for v in values if v):\n    return []\nreturn []'),
'generator_other_iter':body('other = values\nif all(type(v) == int for v in other):\n    return []\nreturn []'),
'generator_extra_iter':body('if all(type(v) == int for v in values for x in values):\n    return []\nreturn []'),
'generator_nonfresh':body('v = 0\nif all(type(v) == int for v in values):\n    return []\nreturn []'),
'generator_wrong_element':body('if all(v == 1 for v in values):\n    return []\nreturn []'),
'exception_escape':body('error = TypeError("x")\nreturn []'),
'exception_dynamic_message':body('raise TypeError(values)'),
'raise_from':body('raise TypeError("x") from ValueError("y")'),
'bare_raise':body('raise'),
'attribute_write':body('values.append = sorted\nreturn []'),
'attribute_chain':body('values.copy.append(1)\nreturn []'),
'string_format':body('raise TypeError("{}".format(values))'),
'fstring':body('raise TypeError(f"{values}")'),
'slice':body('return values[:]'),
'multiple_assign':body('a = b = 0\nreturn []'),
'unpacking_bind':body('type, value = values\nreturn []'),
'protected_dict':body('return __builtins__'),
'evaluator_name':body('return _OUTPUT'),
'call_exec':body('exec(values)\nreturn []'),
'list_nonempty_literal':body('return [1]'),
'float_literal':body('return 1.0'),
'bool_literal':body('return True'),
'large_literal':body('return '+str(2**257)),
'chained_comparison':body('if 0 < 1 < 2:\n    return []\nreturn []'),
'unsupported_operator':body('return 2 * 2'),
'shadow_parameter':'def sort_numbers(type):\n    return []\n',
'decorator':'@sorted\ndef sort_numbers(values):\n    return []\n',
'default':'def sort_numbers(values=sorted([])):\n    return []\n',
'annotation':'def sort_numbers(values: sorted([])):\n    return []\n',
'return_annotation':'def sort_numbers(values) -> sorted([]):\n    return []\n',
'posonly':'def sort_numbers(values, /):\n    return []\n',
'keywordonly':'def sort_numbers(*, values):\n    return []\n',
'varargs':'def sort_numbers(values, *args):\n    return []\n',
'type_parameter':'def sort_numbers[T](values):\n    return []\n',
'multiple_functions':'def sort_numbers(values):\n    return []\ndef second(values):\n    return []\n',
'unicode_normalized_builtin':body('ｌｅｎ = 0\nreturn []'),
'unicode_nonascii_local':body('μ = 0\nreturn []'),
'old_serializer_spoofer':body('json = __import__("json")\njson.dumps = lambda value: "{}"\nreturn []'),
}
for name in ('type','list','sorted','len','all','TypeError','sort_numbers'):
    REJECTED['assign_'+name]=body(name+' = 0\nreturn []')
    REJECTED['augassign_'+name]=body(name+' += 1\nreturn []')
    REJECTED['for_'+name]=body('for '+name+' in values:\n    return []\nreturn []')
    REJECTED['generator_'+name]=body('if all(type('+name+') == int for '+name+' in values):\n    return []\nreturn []')

SEMANTIC={
'wrong_value':body('result = []\nresult.append(999)\nreturn result'),
'exact_type_error':body('raise TypeError("manual")'),
'other_exception':body('raise ValueError("manual")'),
'implicit_none':body('x = 0'),
'same_object':body('return values'),
'mutate_new_return':body('values[0] = values[0] + 1\nreturn sorted(values)'),
'bool_int_mutation':body('values[0] = 1 == 1\nreturn []'),
'local_rebind':body('values = sorted(values)\nreturn values'),
'restore_mutation':body('old = values[0]\nvalues[0] = old + 1\nvalues[0] = old\nreturn sorted(values)'),
'cyclic_result':body('result = []\nresult.append(result)\nreturn result'),
'cyclic_input':body('values.append(values)\nreturn []'),
'deep_result':body('result = []\nfor i in range(0, 100):\n    nextlist = []\n    nextlist.append(result)\n    result = nextlist\nreturn result'),
'oversize_result':body('result = []\nfor i in range(0, 513):\n    result.append(i)\nreturn result'),
'oversize_input':body('for i in range(0, 513):\n    values.append(i)\nreturn []'),
'huge_int_result':body('number = 1\nfor i in range(0, 257):\n    number += number\nresult = []\nresult.append(number)\nreturn result'),
'huge_int_input':body('number = 1\nfor i in range(0, 257):\n    number += number\nvalues[0] = number\nreturn []'),
'fuel_loop':body('index = 0\nwhile 1 == 1:\n    index += 1\nreturn []'),
'guest_memory_growth':body('result = []\nresult.append(1)\nfor i in range(0, 30):\n    result += result\nreturn result'),
}
