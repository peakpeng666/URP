"""Self-contained standard-library data tests; no generated source/runtime imports."""
import copy
import hashlib
import json
from pathlib import Path
import random
import sys
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE / 'src'))
import build_fixtures as fixture


def independent_descriptor(case):
    kind = case['kind']
    if kind == 'identity':
        kind = {dict: 'dict', bool: 'bool', int: 'int', float: 'float',
                str: 'str', type(None): 'none'}[type(case['input'])]
    return json.dumps({'kind': kind, 'value': case['input'], 'valid_fixture': case['valid']},
                      separators=(',', ':'), ensure_ascii=True, allow_nan=False)


class FixtureTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.old_bytes = (HERE / 'fixtures/development72.json').read_bytes()
        cls.old = json.loads(cls.old_bytes)
        cls.new = json.loads((HERE / 'fixtures/prospective72.json').read_bytes())
        cls.manifest = json.loads((HERE / 'fixtures/panel_manifest.json').read_bytes())
        cls.records = [json.loads(line) for line in
                       (HERE / 'fixtures/descriptors.jsonl').read_bytes().splitlines()]

    def test_development_original_bytes_ids_oracles_and_hashes(self):
        self.assertEqual(self.old_bytes, fixture.OLD_CASES.read_bytes())
        self.assertEqual(hashlib.sha256(self.old_bytes).hexdigest(), fixture.OLD_SHA256)
        for record, case in zip(self.records[:72], self.old):
            old_hash = hashlib.sha256(json.dumps(case, sort_keys=True,
                                                 separators=(',', ':')).encode()).hexdigest()
            self.assertEqual(record['id'], case['id'])
            self.assertEqual(record['fixture_sha256'], old_hash)

    def test_exact_counts_and_unmodified_case_shape(self):
        for panel in (self.old, self.new):
            self.assertEqual(len(panel), 72)
            self.assertEqual(sum(c['valid'] is True for c in panel), 60)
            self.assertEqual(sum(c['valid'] is False for c in panel), 12)
            self.assertEqual(len({c['id'] for c in panel}), 72)
            for case in panel:
                expected_keys = {'id', 'kind', 'input', 'valid', 'family',
                                 'expected' if case['valid'] else 'expected_exception'}
                self.assertEqual(set(case), expected_keys)
                fixture.validate_case(case)

    def test_exact_random_rng_order_distributions_and_values(self):
        rng = random.Random(202610041337)
        index = 0
        for length in (4, 5, 9, 17, 33, 65, 129, 258):
            for family, low, high in (('wide', -1000000, 1000000), ('duplicates', -3, 3)):
                for replicate in range(3):
                    case = self.new[index]
                    self.assertEqual(case['id'], f'prospective_random_{family}_{length}_{replicate}')
                    self.assertEqual(case['input'], [rng.randint(low, high) for _ in range(length)])
                    self.assertEqual(case['family'], family)
                    self.assertTrue(all(low <= n <= high for n in case['input']))
                    index += 1
        self.assertEqual(index, 48)
        self.assertEqual(self.manifest['rng']['rejected_draws'], 0)
        log = json.loads((HERE / 'fixtures/random_draw_log.json').read_bytes())
        self.assertEqual(len(log), 48)
        self.assertEqual([r['draws'] for r in log], [1] * 48)
        self.assertEqual([r['cell_draws'] for r in log], [1, 2, 3] * 16)

    def test_exact_fixed_edge_order_values(self):
        expected = [[104729], [104723, -104729], [13, -17, 13, 19, -17, 0, 13],
                    [104729] * 11, [-104729, -104723, -104759, -104729],
                    [100003, -100019, 0, 100043, -100003],
                    [100003, 100019, 100043, 100049, 100057],
                    [100057, 100049, 100043, 100019, 100003], [0] * 11,
                    [2**95 - 1, -(2**95 - 1), 2**63, -(2**63), 0],
                    [100003, -100003] * 7, [-104729]]
        self.assertEqual([c['input'] for c in self.new[48:60]], expected)
        self.assertEqual([c['family'] for c in self.new[48:60]], ['edge'] * 12)

    def test_exact_invalid_order_types_and_typeerror_oracles(self):
        values = [[101, -103, 101, 0], {'sample': 29, 'other': -31}, False, 104729,
                  -1234.25, '-103 101 0', [101, True, -103, 0], [False, 101, -103],
                  [101, -103.25, 0], [101, '-103', 0], [101, None, -103, 0],
                  [[101], -103, [0]]]
        kinds = ['tuple', 'dict', 'bool', 'int', 'float', 'str'] + ['list'] * 6
        for case, value, kind in zip(self.new[60:], values, kinds):
            self.assertEqual(fixture.json_bytes(case['input']), fixture.json_bytes(value))
            self.assertEqual(fixture.actual_kind(case), kind)
            self.assertIs(case['valid'], False)
            self.assertEqual(case['expected_exception'], 'TypeError')

    def test_distinct_typed_instances_and_category_overlap(self):
        old_keys = {fixture.canonical_typed_key(c) for c in self.old}
        new_keys = {fixture.canonical_typed_key(c) for c in self.new}
        self.assertEqual(len(old_keys), 72)
        self.assertEqual(len(new_keys), 72)
        self.assertFalse(old_keys & new_keys)
        self.assertEqual({c['family'] for c in self.old}, {c['family'] for c in self.new})
        self.assertIn('edge_empty', [c['id'] for c in self.old])
        self.assertIn('invalid_none', [c['id'] for c in self.old])
        self.assertFalse(any(c['input'] is None or c['input'] == [] for c in self.new))
        self.assertTrue(self.manifest['overlap']['category_overlap_deliberate'])
        self.assertEqual(self.manifest['overlap']['exact_typed_instances'], 0)

    def test_canonical_equivalence_retains_types_kind_validity(self):
        # Deliberately invalid synthetic descriptors exercise dedup representation
        # only; they are not accepted as fixtures or added to either panel.
        def key(kind, value, valid=False):
            return fixture.canonical_typed_key({'kind': kind, 'input': value, 'valid': valid})
        keys = [key('identity', v) for v in (True, 1, 1.0, '1', None, False, 0, 0.0)]
        self.assertEqual(len(set(keys)), len(keys))
        self.assertNotEqual(key('list', [True]), key('list', [1]))
        self.assertNotEqual(key('tuple', [1]), key('list', [1]))
        self.assertNotEqual(key('list', [1], False), key('list', [1], True))
        self.assertEqual(key('identity', {'a': 1, 'b': False}),
                         key('identity', {'b': False, 'a': 1}))

    def test_descriptor_shape_serialization_and_oracle_output_limits(self):
        self.assertEqual(len(self.records), 144)
        for record, case in zip(self.records, self.old + self.new):
            self.assertEqual(record['input_json'], independent_descriptor(case))
            self.assertEqual(set(json.loads(record['input_json'])), {'kind', 'value', 'valid_fixture'})
            self.assertEqual(record['input_sha256'], hashlib.sha256(record['input_json'].encode()).hexdigest())
            self.assertLessEqual(len(record['input_json'].encode()), 8192)
            payload = fixture.oracle_payload(case)
            self.assertEqual(set(payload), {'stage', 'invocation', 'result_shape_valid', 'result',
                                           'returned_same_object', 'final_input_unchanged', 'valid_fixture'})
            self.assertEqual(record['conforming_output_bytes'], len(fixture.json_bytes(payload)))
            self.assertLessEqual(record['conforming_output_bytes'], 8192)
            self.assertLessEqual(fixture.validate_case(case)['max_items'], 258)
            self.assertLessEqual(fixture.validate_case(case)['max_int_bits'], 96)
            if case['valid']:
                self.assertTrue(all(type(x) is int for x in case['expected']))
                self.assertEqual(case['expected'], sorted(case['input']))
            else:
                self.assertEqual(payload['invocation'], 'exact_type_error')

    def test_explicit_panel_labels_and_case_order(self):
        for panel_index, (name, cases) in enumerate(zip(fixture.PANELS, (self.old, self.new))):
            rows = self.records[panel_index * 72:(panel_index + 1) * 72]
            self.assertEqual([r['index'] for r in rows], list(range(72)))
            self.assertEqual([r['id'] for r in rows], [c['id'] for c in cases])
            self.assertEqual({r['panel'] for r in rows}, {name})
            self.assertEqual({r['role'] for r in rows}, {fixture.ROLES[name]})
        combined = fixture.load_cases()
        self.assertEqual(len({c['test_id'] for c in combined}), 144)
        self.assertEqual([c['panel_index'] for c in combined], list(range(72)) * 2)

    def test_random_collision_advances_same_rng_and_fixed_collision_fails(self):
        # Block the first prospective draw by adding that data to development;
        # the first accepted row must be the next exact whole-list RNG draw.
        rng = random.Random(fixture.SEED)
        first = [rng.randint(-1000000, 1000000) for _ in range(4)]
        second = [rng.randint(-1000000, 1000000) for _ in range(4)]
        blocked = fixture.make_case('collision_control', 'list', first, 'wide', True)
        cases, log = fixture.generate_prospective(self.old + [blocked])
        self.assertEqual(cases[0]['input'], second)
        self.assertEqual(log[0]['draws'], 2)
        fixed = fixture.fixed_cases()[0]
        with self.assertRaisesRegex(ValueError, 'fixed fixture collision'):
            fixture.generate_prospective(self.old + [fixed])

    def test_cell_draw_cap_does_not_replace_or_change_distribution(self):
        class ConstantRandom:
            calls = 0
            def __init__(self, seed):
                self.seed = seed
            def randint(self, low, high):
                self.__class__.calls += 1
                self.bounds = low, high
                return 42
        with patch.object(fixture.random, 'Random', ConstantRandom):
            with self.assertRaisesRegex(ValueError, 'random dedup draw cap reached'):
                fixture.generate_prospective(self.old)
        self.assertEqual(ConstantRandom.calls, 1000 * 4)

    def test_type_oracle_and_bound_mutations_are_rejected(self):
        mutations = []
        bad = copy.deepcopy(self.new[0]); bad['expected'][0] = True; mutations.append(bad)
        bad = copy.deepcopy(self.new[0]); bad['input'][0] = True; mutations.append(bad)
        bad = copy.deepcopy(self.new[0]); bad['valid'] = 1; mutations.append(bad)
        bad = copy.deepcopy(self.new[0]); bad['input'] = [0] * 259; bad['expected'] = [0] * 259; mutations.append(bad)
        bad = copy.deepcopy(self.new[0]); bad['input'] = [2**96]; bad['expected'] = [2**96]; mutations.append(bad)
        bad = copy.deepcopy(self.new[60]); bad['expected_exception'] = 'ValueError'; mutations.append(bad)
        for bad in mutations:
            with self.assertRaises((ValueError, TypeError)):
                fixture.validate_case(bad)
        with self.assertRaises(ValueError):
            fixture.fixture_json({'kind': 'str', 'input': 'x' * 8192, 'valid': False})

    def test_reproducibility_and_all_artifact_hashes(self):
        generated1 = fixture.prepared_artifacts()
        generated2 = fixture.prepared_artifacts()
        self.assertEqual(generated1, generated2)
        for name, expected in generated1.items():
            self.assertEqual((HERE / 'fixtures' / name).read_bytes(), expected)
        for name, info in self.manifest['files'].items():
            data = (HERE / 'fixtures' / name).read_bytes()
            self.assertEqual(info, {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
        for field in ('generator', 'tests', 'proposal'):
            info = self.manifest[field]
            self.assertEqual(info['sha256'], hashlib.sha256((HERE / info['path']).read_bytes()).hexdigest())


if __name__ == '__main__':
    unittest.main()
