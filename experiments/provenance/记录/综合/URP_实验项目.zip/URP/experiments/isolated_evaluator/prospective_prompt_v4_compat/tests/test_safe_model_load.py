"""Mocked loader tests. No torch import, model deserialization or generation."""
import ast
import copy
import hashlib
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
import safe_model_load as loader
import check_model_load_only as probe
import supervise_model_load_only as supervisor


class Journal:
    def __init__(self): self.events = []
    def event(self, name, **fields): self.events.append((name, copy.deepcopy(fields)))


class FakeSerialization:
    def __init__(self):
        self.registry = []
        self.unsafe = []
        self.scans = []
        self.clear_calls = 0
        self.scan_effect = None
    def get_safe_globals(self): return list(self.registry)
    def clear_safe_globals(self):
        self.clear_calls += 1
        self.registry.clear()
    def get_unsafe_globals_in_checkpoint(self, file):
        self.scans.append(file)
        if self.scan_effect: self.scan_effect()
        return list(self.unsafe)


class FakeTorch:
    float32 = "float32"
    def __init__(self):
        self.serialization = FakeSerialization()
        self.loads = []
        self.effect = None
        self.load = self.original_load
    def original_load(self, file, **kwargs):
        self.loads.append((file, kwargs))
        if self.effect: self.effect()
        return {"fake": "handwritten data"}
    def set_num_threads(self, value): self.threads = value
    def set_num_interop_threads(self, value): self.interop = value
    def use_deterministic_algorithms(self, value): self.deterministic = value
    def get_num_threads(self): return self.threads
    def get_num_interop_threads(self): return self.interop
    def are_deterministic_algorithms_enabled(self): return self.deterministic


class BoundaryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / "pytorch_model.bin"
        self.path.write_bytes(b"handwritten mock: never deserialize")
        self.sha = hashlib.sha256(self.path.read_bytes()).hexdigest()
        self.torch = FakeTorch()
        self.journal = Journal()
        self.original = self.torch.load
    def tearDown(self): self.temp.cleanup()
    def guard(self): return loader.guarded_checkpoint_loads(self.torch, self.path, self.sha, self.journal)
    def load(self, **kwargs):
        return self.torch.load(str(self.path), map_location="cpu", weights_only=True, **kwargs)
    def test_all_real_loads_scanned_meta_then_cpu_and_restored(self):
        with self.guard() as records:
            self.torch.load(str(self.path), map_location="meta", weights_only=True)
            self.torch.load(str(self.path), map_location="cpu", weights_only=True, mmap=True)
        self.assertEqual(len(records), 2)
        self.assertEqual(len(self.torch.serialization.scans), 2)
        self.assertEqual([r[1]["map_location"] for r in self.torch.loads], ["meta", "cpu"])
        self.assertIs(self.torch.load, self.original)
        self.assertEqual(self.torch.serialization.clear_calls, 0)
    def test_nonempty_registry_rejected_without_clear_or_scan(self):
        self.torch.serialization.registry = [RuntimeError]
        with self.assertRaisesRegex(RuntimeError, "Extra user"):
            with self.guard(): self.load()
        self.assertFalse(self.torch.loads)
        self.assertFalse(self.torch.serialization.scans)
        self.assertEqual(self.torch.serialization.clear_calls, 0)
    def test_unknown_checkpoint_globals_rejected_before_real_load(self):
        self.torch.serialization.unsafe = ["untrusted.NotAllowed"]
        with self.assertRaisesRegex(RuntimeError, "requires extra"):
            with self.guard(): self.load()
        self.assertFalse(self.torch.loads)
        self.assertIs(self.torch.load, self.original)
    def test_wrong_path_and_nonpath_rejected(self):
        other = self.path.with_name("other.bin"); other.write_bytes(self.path.read_bytes())
        for path in (str(other), SimpleNamespace(read=lambda: b"")):
            with self.assertRaises(RuntimeError):
                with self.guard(): self.torch.load(path, map_location="cpu", weights_only=True)
        self.assertFalse(self.torch.loads)
    def test_wrong_weight_digest_rejected(self):
        self.path.write_bytes(b"changed mock")
        with self.assertRaisesRegex(RuntimeError, "digest changed"):
            with self.guard(): self.load()
        self.assertFalse(self.torch.loads)
    def test_absent_false_numeric_weights_only_and_pickle_rejected(self):
        options = ({}, {"weights_only":False}, {"weights_only":1},
                   {"weights_only":True, "pickle_module": object()},
                   {"weights_only":True, "pickle_module":None},
                   {"weights_only":True, "encoding":"bytes"})
        for kwargs in options:
            with self.assertRaises(RuntimeError, msg=str(kwargs)):
                with self.guard(): self.torch.load(str(self.path), map_location="cpu", **kwargs)
        self.assertFalse(self.torch.loads)
    def test_gpu_callable_map_and_positional_overrides_rejected(self):
        for location in ("cuda", None, lambda storage, location: storage):
            with self.assertRaises(RuntimeError):
                with self.guard(): self.torch.load(str(self.path), map_location=location, weights_only=True)
        with self.assertRaises(RuntimeError):
            with self.guard(): self.torch.load(str(self.path), "cpu", weights_only=True)
        self.assertFalse(self.torch.loads)
    def test_registry_repopulation_after_scan_blocks_actual_load(self):
        self.torch.serialization.scan_effect = lambda: self.torch.serialization.registry.append(RuntimeError)
        with self.assertRaisesRegex(RuntimeError, "after checkpoint scan"):
            with self.guard(): self.load()
        self.assertFalse(self.torch.loads)
        self.assertEqual(self.torch.serialization.clear_calls, 0)
    def test_registry_repopulation_during_load_fails_and_restores(self):
        self.torch.effect = lambda: self.torch.serialization.registry.append(RuntimeError)
        with self.assertRaisesRegex(RuntimeError, "after actual torch.load"):
            with self.guard(): self.load()
        self.assertEqual(len(self.torch.loads), 1)
        self.assertEqual(self.torch.serialization.clear_calls, 0)
        self.assertIs(self.torch.load, self.original)
    def test_registry_repopulation_between_loads_blocks_second(self):
        with self.assertRaisesRegex(RuntimeError, "before checkpoint scan"):
            with self.guard():
                self.load()
                self.torch.serialization.registry.append(RuntimeError)
                self.load()
        self.assertEqual(len(self.torch.loads), 1)
    def test_registry_repopulation_after_model_load_fails(self):
        with self.assertRaisesRegex(RuntimeError, "after model load"):
            with self.guard():
                self.load()
                self.torch.serialization.registry.append(RuntimeError)
        self.assertIs(self.torch.load, self.original)
    def test_exception_and_empty_load_cleanup(self):
        for error in (RuntimeError("mock failure"), KeyboardInterrupt()):
            with self.assertRaises(type(error)):
                with self.guard(): raise error
            self.assertIs(self.torch.load, self.original)
        with self.assertRaisesRegex(RuntimeError, "No complete"):
            with self.guard(): pass
        self.assertIs(self.torch.load, self.original)
    def test_real_load_exception_never_retried(self):
        def fail(): raise RuntimeError("mock deserialization failure")
        self.torch.effect = fail
        with self.assertRaisesRegex(RuntimeError, "mock deserialization"):
            with self.guard(): self.load()
        self.assertEqual(len(self.torch.loads), 1)
        self.assertIs(self.torch.load, self.original)


class FreshImportTests(unittest.TestCase):
    def test_trusted_import_sequence_recorded_then_one_clear(self):
        torch = FakeTorch()
        root = (ROOT / "../../sorting_generation/.venv").resolve()
        names = []
        def fake_import(name):
            names.append(name)
            module = torch if name == "torch" else SimpleNamespace()
            module.__file__ = str(root / "lib/python3.12/site-packages" / (name.replace(".", "/") + ".py"))
            torch.serialization.registry.append(RuntimeError)
            return module
        journal = Journal()
        with mock.patch.object(loader.importlib, "import_module", side_effect=fake_import):
            modules, audit = loader.import_trusted_runtime(journal)
        self.assertEqual(tuple(names), loader.TRUSTED_IMPORTS)
        self.assertEqual(torch.serialization.clear_calls, 1)
        self.assertFalse(torch.serialization.get_safe_globals())
        self.assertEqual(audit["clear_safe_globals_calls"], 1)
        self.assertEqual(audit["official_registered_globals_before_clear"][0]["object"], "builtins.RuntimeError")
        self.assertFalse(torch.loads)
    def test_reused_process_rejected_before_clear(self):
        torch = FakeTorch()
        with mock.patch.dict(sys.modules, {"torch": torch}):
            with self.assertRaisesRegex(RuntimeError, "fresh process"):
                loader.import_trusted_runtime(Journal())
        self.assertEqual(torch.serialization.clear_calls, 0)
    def test_unverified_import_origin_rejected_before_clear(self):
        torch = FakeTorch(); torch.__file__ = "/tmp/untrusted/torch.py"
        with mock.patch.object(loader.importlib, "import_module", return_value=torch):
            with self.assertRaisesRegex(RuntimeError, "outside the verified venv"):
                loader.import_trusted_runtime(Journal())
        self.assertEqual(torch.serialization.clear_calls, 0)


class NoGenerationTests(unittest.TestCase):
    def test_tripwire_blocks_and_restores_inherited_generate(self):
        class Base:
            def generate(self): raise AssertionError("Original generate must never execute")
        class Model(Base): pass
        with self.assertRaisesRegex(RuntimeError, "Generation is prohibited"):
            with loader.prohibit_generation(Model, Journal()): Model().generate()
        self.assertNotIn("generate", Model.__dict__)
        self.assertIs(Model.generate, Base.generate)
    def test_tripwire_restores_local_method_on_error(self):
        class Model:
            def generate(self): raise AssertionError("Original must never execute")
        original = Model.generate
        with self.assertRaises(ValueError):
            with loader.prohibit_generation(Model, Journal()): raise ValueError("mock")
        self.assertIs(Model.generate, original)
    def test_load_only_source_has_no_generate_call_or_generation_authorization(self):
        for relative in ("src/safe_model_load.py", "src/check_model_load_only.py", "src/supervise_model_load_only.py"):
            source = (ROOT / relative).read_text()
            calls = [n for n in ast.walk(ast.parse(source)) if isinstance(n, ast.Call)]
            self.assertFalse(any(isinstance(n.func, ast.Attribute) and n.func.attr == "generate" for n in calls))
            self.assertFalse(any(isinstance(n.func, ast.Name) and n.func.id in
                {"run_jobs", "consume_authorization", "initialize_ledger", "run_one"} for n in calls))
        self.assertNotIn("torch", sys.modules)
        self.assertNotIn("transformers", sys.modules)
    def test_probe_cpu_as_wall_and_cleanup_bounds(self):
        self.assertEqual(probe.LOAD_ONLY_LIMITS[probe.resource.RLIMIT_CPU], (120,120))
        self.assertEqual(probe.LOAD_ONLY_LIMITS[probe.resource.RLIMIT_AS], (6*1024**3,6*1024**3))
        self.assertEqual(supervisor.WALL_SECONDS, 180)
        self.assertEqual(supervisor.CLEANUP_SECONDS, 5)
        self.assertEqual(supervisor.REPORT_SECONDS, 2)
        with mock.patch.object(supervisor.resource, "setrlimit") as setting:
            supervisor.limit_child()
        self.assertEqual(setting.call_count, len(probe.LOAD_ONLY_LIMITS))
        with mock.patch.object(probe.resource, "getrlimit", return_value=(-1,-1)):
            with self.assertRaises(RuntimeError): probe.check_load_only_limits()
    def test_offline_env_and_supervisor_commands(self):
        env = supervisor.clean_environment()
        for name in ("HF_HUB_OFFLINE", "TRANSFORMERS_OFFLINE", "TORCH_FORCE_WEIGHTS_ONLY_LOAD", "PYTHONDONTWRITEBYTECODE"):
            self.assertEqual(env[name], "1")
        self.assertFalse(set(env) & {"HF_TOKEN", "PYTHONPATH", "HTTP_PROXY", "HTTPS_PROXY"})
        self.assertIn('"-B", "-s"', (ROOT / "src/supervise_model_load_only.py").read_text())


class ComponentTests(unittest.TestCase):
    def test_load_only_components_keep_exact_options_without_generate(self):
        torch = FakeTorch()
        torch.set_num_threads(1); torch.set_num_interop_threads(1); torch.use_deterministic_algorithms(True)
        generation_calls = []
        class Model:
            training = True
            def to(self, device): self.device = device
            def eval(self): self.training = False
            def parameters(self): return [SimpleNamespace(device=SimpleNamespace(type="cpu"), dtype="float32")]
            def generate(self): generation_calls.append(True); raise AssertionError("Must never execute")
        config = json.loads((ROOT / "generation_config.json").read_text())
        model_path = (ROOT / config["model"]["directory"]).resolve()
        def model_from(path, **kwargs):
            torch.load(str(path / "pytorch_model.bin"), map_location="meta", weights_only=kwargs["weights_only"])
            torch.load(str(path / "pytorch_model.bin"), map_location="cpu", weights_only=kwargs["weights_only"], mmap=True)
            return Model()
        tokenizer_factory = mock.Mock(return_value=SimpleNamespace())
        model_factory = mock.Mock(side_effect=model_from)
        modules = {"torch": torch,
            "transformers.models.codegen.modeling_codegen": SimpleNamespace(CodeGenForCausalLM=Model),
            "transformers.models.auto.tokenization_auto": SimpleNamespace(AutoTokenizer=SimpleNamespace(from_pretrained=tokenizer_factory)),
            "transformers.models.auto.modeling_auto": SimpleNamespace(AutoModelForCausalLM=SimpleNamespace(from_pretrained=model_factory)),
            "transformers.trainer_utils": SimpleNamespace(set_seed=mock.Mock())}
        with mock.patch.object(loader, "verify_runtime_metadata"), \
             mock.patch.object(loader, "import_trusted_runtime", return_value=(modules, {})), \
             mock.patch.object(loader, "sha256_file", return_value=loader.OFFICIAL_WEIGHT_SHA256):
            result = loader.load_trusted_components(config, Journal(), load_only=True)
        model_factory.assert_called_once_with(model_path, local_files_only=True, trust_remote_code=False,
            weights_only=True, use_safetensors=False, dtype="float32", attn_implementation="eager")
        tokenizer_factory.assert_called_once_with(model_path, local_files_only=True, trust_remote_code=False)
        self.assertEqual(result[-1]["actual_load_count"], 2)
        self.assertEqual(result[-1]["prohibited_generation_attempts"], 0)
        self.assertFalse(generation_calls)
        self.assertEqual(torch.serialization.clear_calls, 0)


class SupervisorTests(unittest.TestCase):
    def test_cleanup_is_required_before_success_and_no_generation_markers(self):
        for complete in (True, False):
            with tempfile.TemporaryDirectory() as temp:
                root = Path(temp); (root / "results").mkdir()
                output = root / "results/check"
                argv = ["supervisor", "--reviewed-preparation-sha256", "a" * 64, "--output", str(output)]
                process = SimpleNamespace(pid=1234, returncode=0)
                used = SimpleNamespace(ru_utime=1.0, ru_stime=0.1, ru_maxrss=256)
                def popen(command, **kwargs):
                    self.assertIn("-B", command); self.assertIn("-s", command)
                    self.assertEqual(kwargs["env"], supervisor.clean_environment())
                    self.assertTrue(kwargs["start_new_session"])
                    return process
                worker = {"status":"passed", "integrity_after":"passed", "generation_calls":0, "candidate_executions":0}
                detail = {"cleanup_complete":complete, "process_group_absent":complete}
                with mock.patch.object(supervisor, "ROOT", root), mock.patch.object(sys, "argv", argv), \
                     mock.patch.object(supervisor.subprocess, "Popen", side_effect=popen), \
                     mock.patch.object(supervisor, "wait4_until", return_value=(0, used)), \
                     mock.patch.object(supervisor, "cleanup", return_value=(0, used, detail)), \
                     mock.patch.object(supervisor, "read_json", return_value=(b"", worker)), \
                     mock.patch.object(supervisor.signal, "signal"), \
                     mock.patch.object(supervisor.signal, "setitimer"), mock.patch("builtins.print"):
                    self.assertEqual(supervisor.main(), 0 if complete else 1)
                status = json.loads((output / "model_load_supervisor_status.json").read_text())
                self.assertEqual(status["status"], "passed" if complete else "failed")
                self.assertFalse((root / "approvals").exists())
                self.assertFalse((root / "authorization_uses").exists())


if __name__ == "__main__": unittest.main()
