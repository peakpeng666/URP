# Proposed P2 paired prompt study, v4

Status: proposal only. No new model generation or candidate execution is authorized
by this document. The completed v2/v3 evidence and their freezes remain unchanged.

## Question and scope

Does a prospectively fixed type-versus-value clarification improve full-contract
conformance for this local CodeGen model, relative to the existing explicit
function-completion prompt? This is an exploratory development study on one
sorting task. The old72 cases and observed failures are development evidence.
Allowing built-in sorted does not demonstrate invention of a sorting algorithm.

Generate ten genuinely new outputs: five paired seeds, two prompts. Use exactly
one prospectively selected extraction per generation as the primary source form.
Retain raw bytes and extraction decisions, with raw structural/grammar admission
as secondary diagnostics. Do not dynamically run both forms or select the better
one after observing results. Each arm's denominator is five attempted generations.

## Fixed generation plan

- Existing local Salesforce/codegen-350M-mono, revision
  `d9107f71cca463240db1143f4a75a927a27fcb27`
- Recorded official weight SHA256
  `90e20f4887289739a435452f26974d97937adb41485f9c1a7b3d3810aac6773d`
- Reverify all local model/tokenizer hashes before and after generation. No download,
  paid API, remote code or new model checkpoint is required
- Host CPython3.12.14; recorded torch2.14.1+cpu, transformers5.18.0,
  tokenizers0.23.2. Pin and verify the actual environment before execution
- CPU float32, one torch thread and one inter-op thread; deterministic algorithms,
  eval/inference mode, reset seed for each call; local_files_only and weights_only,
  trust_remote_code=False, no extra unpickler globals
- Sampling: temperature0.7, top_p0.95, top_k0, repetition_penalty1.0;
  one beam, one sequence, max_new_tokens512, total context maximum2048
- Seeds601,631,661,701,751. Order:601 A/B;631 B/A;661 A/B;701 B/A;751 A/B
- Exactly ten calls maximum, no greedy extra, repairs, replacement samples,
  adaptive prompt changes or automatic retries
- Generation retains prior bounds: AS6GiB, CPU soft900s/hard910s,
  external wall1200s. Cleanup grace/reap and any overshoot must be explicitly
  bounded and recorded by the reviewed trusted supervisor
- Record every start/completion, seed, prompt/token IDs, input/output token counts,
  EOS/token-cap termination, raw/extracted bytes/hashes, per-call and whole-process
  CPU/wall/RSS. The two arms have equal maximum output tokens, not identical compute

### Prompt A

Byte-identical existing explicit prompt:
`sorting_generation/runs/function_completion_pilot/prompts/explicit_docstring.txt`

SHA256 `6dad5083b4454ac7e111827a1033b0c2d41f620af7a98125789567acbfb05b6c`.

### Prompt B

The following exact text, including final newline, will be frozen before generation:

```python
def sort_numbers(values):
    """Return a new ascending list containing every input integer.

    Accept values exactly when it is a plain Python list and every element
    is a plain Python int. Booleans are not plain ints.
    Validate the outer type and every element type; otherwise raise TypeError.
    Empty, repeated, negative, zero, sorted, and unsorted integer values are valid.
    Do not reject a valid input because of its contents or ordering.
    Preserve every duplicate and leave the input list unchanged.
    Return a different list object for every valid input, including an empty list.
    Built-in sorted is allowed.
    Implement only this function, with no imports, demonstrations, or test calls.
    """
```

This compares two prompt packages motivated by prior development findings. It is
not a clean isolated estimate of a single wording feature. Neither contains a
reference implementation or actual fixture values.

### Extraction and host restrictions

Preserve the existing `tokenize_dedent_then_real_top_level_token_v1` algorithm from
`function_completion_pilot/src/analyze.py` (file SHA256
`61f9f1dfa9308792fa5d80cd6068ca0f7527ec9814b96915b9c8b34da7581b98`).
Copy/use only its data-only extraction function; do not call its `review()` helper,
which contains a host compilation step. No new candidate source may be host
compiled, imported, evaluated or executed. No internal repairs, reindentation,
brace/string closure, added aliases or changed statements. An absent extraction
boundary leaves the original source untouched.

## Separate development and prospective held-out panels

Keep all original72 fixtures, labelled development. Freeze a new72-case panel
before any new generation. It contains60 valid and12 invalid exact-instance-disjoint
cases. Category overlap with the original contract is deliberate and must be
reported. Only within-task prospective instance performance is measured; no
cross-task or unbiased universal-Python generalization claim is justified.

Use `random.Random(202610041337)`. In order: length4,5,9,17,33,65,129,258;
for each length use uniform integers [-1000000,1000000], then [-3,3]; draw three
replicates per cell. This gives48 valid random cases. Reject exact canonical typed
fixture duplicates against both development and earlier prospective cases,
advancing the same RNG and retrying that cell at most1000 draws; then stop fixture
preparation rather than silently alter distributions.

Append these12 valid edge lists in exactly this order:

1. `[104729]`
2. `[104723, -104729]`
3. `[13, -17, 13, 19, -17, 0, 13]`
4. eleven copies of104729
5. `[-104729, -104723, -104759, -104729]`
6. `[100003, -100019, 0, 100043, -100003]`
7. `[100003, 100019, 100043, 100049, 100057]`
8. `[100057, 100049, 100043, 100019, 100003]`
9. eleven zeroes
10. `[2**95-1, -(2**95-1), 2**63, -(2**63), 0]`, materialized as integer literals
11. `[100003, -100003]` repeated seven times
12. `[-104729]`

Append these12 invalid inputs, each expecting exact TypeError:

1. tuple `(101,-103,101,0)`
2. dict `{"sample":29,"other":-31}`
3. scalar `False`
4. scalar integer104729
5. scalar float-1234.25
6. string `"-103 101 0"`
7. list `[101,True,-103,0]`
8. list `[False,101,-103]`
9. list `[101,-103.25,0]`
10. list `[101,"-103",0]`
11. list `[101,None,-103,0]`
12. list `[[101],-103,[0]]`

Canonical typed descriptors include actual kind, exact JSON scalar types and
validity; Boolean is not collapsed into integer. Reject any fixed edge/invalid
collision rather than changing it after generation. Empty list and scalar None
remain only in development since they cannot become novel exact instances.

Freeze the generator, materialized descriptors/oracles, case order and hashes.
Check all against exact plain-list/int bounds, <=96-bit new integers,
length<=258, input<=8192 bytes and measured output limits. Validate with handwritten
controls only before generating candidates. Keep the held-out file out of model
inputs and prompts; no prompt/grammar/threshold changes after held-out observations.

## Evaluation and minimal implementation change

The existing b5a8612f... operational adapter is fixed to42 old forms/72 fixtures;
it cannot authorize this population. Make one small, separate population adapter
and immutable source/test manifests. Reuse the exact reviewed guest artifact,
closed validator, semantic checker and runtime resource policies byte-for-byte.
Do not build a general arbitrary-language executor or rebuild the guest.

All ten selected forms retain all144 test IDs, maximum1440 requests. Rejected forms
keep their rows unexecuted. Generation errors or budget-unattempted calls retain
unknown coverage; never replace them. Do not stop a candidate after its first
semantic counterexample. Check both panels for all admitted forms.

Deterministic paired schedule: for case index0..71, development case then new-panel
case; for each case, seed pairs in601,631,661,701,751 order, with the same fixed A/B
or B/A ordering above. This balances progress across both panels/arms. A terminal
budget stop still may leave an unmatched final request; preserve it transparently.

Primary success: admission and all144 clean conformance observations. Also report
separate development72 and held-out72 full-pass outcomes, admission counts, semantic
counterexamples, resource unknowns, and per-case descriptive rates. Paired
wins/losses/ties use the five generated-program pairs, with unresolved pairs
identified. Five pairs are exploratory; even five unopposed wins do not yield a
two-sided exact sign-test p below0.05. Do not tune again to improve a reported score.

Keep each request at200M fuel,2s workerCPU,5s external deadline+1s reap,8GiB AS,
128MiB supervisor softAS, the same per-memory/table limits and8KiB input/output.
Batch workerCPU600s and wall900s, with full request reservation and separate
supervisor/integrity costs. No source repairs or relaxed limits. All current
resource/infrastructure/integrity unknown/stop rules carry forward.

The generator's model provenance is frozen separately. Evaluation checks bind the
new source bytes and provenance plus the existing evaluator dependency inventory;
loading or rehashing the full torch environment on every Wasm request is unnecessary
because it is not in the runtime evaluation trust boundary.

## Cost and decision gates

Closest prior ten-generation batch:421.454s wall,422.711s CPU,4100 output tokens,
2,465,924KiB peak RSS (~2.35GiB). New output ceiling is5120 tokens total:2560/arm.
Estimate generation7–9min, then at most1440 evaluations at v3 observed throughput:
about621s wall,225s workerCPU,396s supervisorCPU. Combined expected18–20min, plus
small handwritten validation/review work. This is an estimate, not a promise;
slower/infinite programs can exhaust the unchanged budgets and leave unknowns.

Generation1200s + evaluation900s yields up to35min configured process/batch wall
budgets, plus recorded cleanup/publication overhead. No paid API or paid compute
purchase is proposed; the cloud's monetary compute accounting is unavailable.
No new software/model download is needed if local hash verification passes.

Before launch:
1. Approve this exact bounded experimental design
2. Freeze the minimal generation/population code, prompts, fixtures, extraction,
   analysis and model identities; independently inspect and test handwritten-only
3. Authorize one generation batch. Freeze all resulting bytes regardless of quality
4. Verify the evaluation source population against the reviewed adapter and grant
   a separate one-batch authorization for the resulting exact manifest
5. Coordinate the CPU window, run once, and reconcile saved evidence independently

If both arms fail, record that result and close this experiment. A further prompt
revision requires a separate prospective experiment and new held-out evidence.
