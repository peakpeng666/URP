"""Reviewed v4 manual controls only; never loads model or generated source records."""
import argparse
import json
import pathlib
import sys
HERE=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE/'src'))
sys.path.insert(0,str(HERE.parent/'limited_semantics_v3/tests'))
from handwritten_programs import REFERENCE
from v3_reuse import file_hash
from evaluation_integrity import verify_preparation
from population import load_cases,panel_and_pair_analysis
from evaluation_core import run_forms


def form(name,source,arm='A'):
    return {'form_id':'handwritten/'+name+'/selected','round':'handwritten_v4','candidate_id':name,
            'prompt_id':arm,'seed':601,'variant':'selected','source':source,'generation_status':'generated'}


def main():
    p=argparse.ArgumentParser();p.add_argument('--expected-freeze-sha256',required=True);a=p.parse_args()
    path=HERE/'preparation_freeze.json';expected=a.expected_freeze_sha256
    verify=lambda:verify_preparation(path,expected)
    verify();out=HERE/'results/handwritten_validation';out.mkdir(exist_ok=False)
    cases=load_cases();forms=[form('reference',REFERENCE)]
    report=run_forms(forms,cases,{'selected'},output_dir=out/'reference144',integrity_check=verify)
    report.update(panel_and_pair_analysis(report,forms,cases,{'selected'}))
    (out/'reference144/report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    one={'id':'development/manual_pair','panel':'development','original_fixture_id':'manual_pair',
         'valid':True,'kind':'list','input':[2,1],'expected':[1,2]}
    other={**one,'id':'prospective/manual_pair','panel':'prospective','input':[-3,5,0],'expected':[-3,0,5]}
    paired=[form('paired_good','def sort_numbers(values):\n    return sorted(values)\n','A'),
            form('paired_wrong','def sort_numbers(values):\n    return []\n','B')]
    pair_report=run_forms(paired,[one,other],{'selected'},output_dir=out/'manual_pair',integrity_check=verify)
    pair_report.update(panel_and_pair_analysis(pair_report,paired,[one,other],{'selected'}))
    (out/'manual_pair/report.json').write_text(json.dumps(pair_report,indent=2,allow_nan=False)+'\n')
    checks={'reference144_all_conformant':report['dispatches']==144 and report['forms'][0]['conclusion']=='all_required_cases_conformant',
            'each_panel72_clean':all(x['forms'][0]['case_conformant']==72 for x in report['panels'].values()),
            'manual_paired_order':[r['prompt_id'] for r in pair_report['rows']]==['A','B','A','B'],
            'manual_paired_outcome':pair_report['paired_program_outcomes']['all144']['counts']=={'A_win':1},
            'both_integrity_valid':report['result_certification_valid'] and pair_report['result_certification_valid']}
    verify()
    summary={'all_passed':all(checks.values()),'checks':checks,'preparation_freeze_sha256':expected,
             'model_generations':0,'generated_candidate_executions':0,'handwritten_wasm_requests':148,
             'worker_cpu_seconds':report['worker_cpu_seconds']+pair_report['worker_cpu_seconds'],
             'runner_wall_seconds':report['elapsed_seconds']+pair_report['elapsed_seconds'],
             'runner_supervisor_cpu_seconds':report['supervisor_cpu_seconds']+pair_report['supervisor_cpu_seconds'],
             'integrity_wall_seconds':report['integrity_wall_seconds']+pair_report['integrity_wall_seconds'],
             'integrity_cpu_seconds':report['integrity_cpu_seconds']+pair_report['integrity_cpu_seconds']}
    (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
    if not summary['all_passed']:raise RuntimeError('handwritten v4 validation failed')

if __name__=='__main__':main()
