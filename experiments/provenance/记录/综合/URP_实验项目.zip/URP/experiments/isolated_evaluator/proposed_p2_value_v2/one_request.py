"""Persistent trusted supervisor; only approved batch / handwritten entrypoints.

Supervisor allocation soft limit is128MiB; hard8GiB is inherited for worker setup.
Candidate source is only bounded data and never executes in this host process.
"""
import json,os,pathlib,resource,selectors,signal,subprocess,sys,time,math
HERE=pathlib.Path(__file__).resolve().parent;ROOT=HERE.parent
SUPERVISOR_AS=128*1024**2;MAX_PIPE=32768

def worker_limits():
    for kind,value in [(resource.RLIMIT_AS,8*1024**3),(resource.RLIMIT_CPU,2),
                       (resource.RLIMIT_CORE,0),(resource.RLIMIT_FSIZE,0),(resource.RLIMIT_NOFILE,32)]:
        resource.setrlimit(kind,(value,value))

def configure_supervisor():
    soft,hard=resource.getrlimit(resource.RLIMIT_AS)
    soft=SUPERVISOR_AS if soft==resource.RLIM_INFINITY else min(soft,SUPERVISOR_AS)
    hard=8*1024**3 if hard==resource.RLIM_INFINITY else min(hard,8*1024**3)
    resource.setrlimit(resource.RLIMIT_AS,(soft,hard))

def _kill_group(p):
    if p.poll() is not None:return
    try:os.killpg(p.pid,signal.SIGKILL)
    except ProcessLookupError:pass

def _strict_loads(raw):
    def bad(value):raise ValueError('non-standard JSON')
    def finite(value):
        number=float(value)
        if not math.isfinite(number):raise ValueError('non-finite JSON number')
        return number
    return json.loads(raw,parse_constant=bad,parse_float=finite)

def launch(request):
    configure_supervisor()
    raw=json.dumps(request,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()
    if len(raw)>65536:raise ValueError('request wire size exceeded')
    before=resource.getrusage(resource.RUSAGE_CHILDREN);start=time.monotonic();deadline=start+5
    p=None;sel=selectors.DefaultSelector();output=bytearray();sent=0
    termination=None;internal_error=None;unreaped=False;rc=None
    try:
        p=subprocess.Popen([str(ROOT/'.venv/bin/python'),'-B',str(HERE/'runtime_worker.py')],
                           stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                           env={},preexec_fn=worker_limits,start_new_session=True)
        os.set_blocking(p.stdin.fileno(),False);os.set_blocking(p.stdout.fileno(),False)
        sel.register(p.stdin,selectors.EVENT_WRITE);sel.register(p.stdout,selectors.EVENT_READ)
        while sel.get_map():
            left=deadline-time.monotonic()
            if left<=0:termination='wall_timeout';break
            for key,mask in sel.select(min(left,0.05)):
                if key.fileobj is p.stdin:
                    try:sent+=os.write(key.fd,raw[sent:sent+4096])
                    except BrokenPipeError:sent=len(raw)
                    except BlockingIOError:continue
                    if sent==len(raw):sel.unregister(p.stdin);p.stdin.close()
                else:
                    try:piece=os.read(key.fd,min(4096,MAX_PIPE+1-len(output)))
                    except BlockingIOError:continue
                    if not piece:sel.unregister(p.stdout);continue
                    output.extend(piece)
                    if len(output)>MAX_PIPE:termination='output_limit';break
            if termination:break
        if not termination:
            try:rc=p.wait(timeout=max(0,deadline-time.monotonic()))
            except subprocess.TimeoutExpired:termination='wall_timeout_after_eof'
    except Exception as exc:
        internal_error=type(exc).__name__+': '+str(exc)[:400]
        termination='supervisor_error'
    finally:
        sel.close()
        if p is not None:
            # Every path, including selector/write/read exceptions or early EOF,
            # terminates and reaps a still-live worker before another request.
            if p.poll() is None:_kill_group(p)
            try:rc=p.wait(timeout=1)
            except subprocess.TimeoutExpired:unreaped=True;termination='cleanup_unreaped'
            for pipe in (p.stdin,p.stdout):
                if pipe is not None and not pipe.closed:pipe.close()
    after=resource.getrusage(resource.RUSAGE_CHILDREN)
    frames=[];bad=False
    for line in bytes(output[:MAX_PIPE]).splitlines():
        try:frames.append(_strict_loads(line))
        except ValueError:bad=True
    entered=bool(frames and frames[0]=={'event':'guest_entry'})
    worker=frames[-1] if frames and type(frames[-1]) is dict and 'status' in frames[-1] else None
    frame_shape_ok=((len(frames)==2 and entered and worker is not None)
        or (len(frames)==1 and worker is not None and worker.get('status')=='initialization_or_request_error')
        or (len(frames)==1 and entered and rc is not None and rc<0)
        or (len(frames)==0 and rc is not None and rc!=0))
    result={'returncode':rc,'worker_pid':p.pid if p else None,'supervisor_pid':os.getpid(),'termination':termination,'guest_entry_observed':entered,'worker_unreaped':unreaped,
            'supervisor_error':internal_error,'wall_seconds':time.monotonic()-start,
            'worker_user_seconds':after.ru_utime-before.ru_utime,'worker_sys_seconds':after.ru_stime-before.ru_stime,
            'worker_peak_rss_kib_cumulative':after.ru_maxrss,'supervisor_effective_rlimit_as':resource.getrlimit(resource.RLIMIT_AS),
            'supervisor_peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            'worker':worker,'protocol_error':bad or not frame_shape_ok,
            'diagnostic':None if worker else bytes(output[:2048]).decode('utf-8','replace'),
            'source_sha256':request.get('source_sha256'),'input_sha256':request.get('input_sha256')}
    return result

if __name__=='__main__':
    raw=sys.stdin.buffer.read(65537)
    if len(raw)>65536:raise SystemExit('supervisor stdin too large')
    request=_strict_loads(raw);result=launch(request)
    encoded=json.dumps(result,ensure_ascii=True,separators=(',',':'),allow_nan=False).encode()
    if len(encoded)>32768:encoded=json.dumps({'returncode':None,'termination':'supervisor_result_limit','worker':None}).encode()
    sys.stdout.buffer.write(encoded+b'\n');sys.stdout.buffer.flush()
