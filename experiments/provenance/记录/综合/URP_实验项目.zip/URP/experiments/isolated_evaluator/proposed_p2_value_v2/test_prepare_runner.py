import json,pathlib,unittest
from prepare_runner import request_spec,execute_candidates,static_gate,ALIAS
HERE=pathlib.Path(__file__).resolve().parent
class ProposalTests(unittest.TestCase):
    def test_execution_is_disabled(self):
        with self.assertRaises(RuntimeError):execute_candidates()
    def test_adapter_preserves_original_bytes(self):
        source='def sort_numbers(values):\n    return sorted(values)\n'
        r=request_spec(source,{'id':'probe','valid':True,'kind':'list','input':[3,1]})
        self.assertEqual(r['source'],source+ALIAS)
        self.assertEqual(json.loads(r['input_json']),[3,1])
    def test_invalid_fixture_never_silently_converted(self):
        with self.assertRaises(ValueError):request_spec('def sort_numbers(values):\n    return values\n',{'id':'tuple','valid':False,'kind':'tuple','input':[3,1]})
    def test_full_ledger_preserved(self):
        p=json.loads((HERE/'prepared_plan.json').read_text())
        self.assertEqual(len(p['fixtures']),72)
        self.assertEqual(sum(c['valid'] for c in p['fixtures']),60)
        self.assertEqual(len(p['primary_raw_variants']),32)
        self.assertEqual(len(p['secondary_extracted_variants']),10)
        self.assertEqual(p['candidates_executed'],0)
    def test_size_and_structure_rejections(self):
        self.assertEqual(static_gate('x'*16385),'source_size_rejected')
        self.assertEqual(static_gate('def sort_numbers(values):\n    return values\nprint(1)\n'),'single_function_structure_rejected')
if __name__=='__main__':unittest.main()
