"""Freeze an operational implementation without granting batch authorization."""
import json
import os
import pathlib
import sys
from integrity import HERE, ROOT, PROTOTYPE, file_hash, dependency_state, source_inventory, verify_freeze

PATH = HERE / 'operational_freeze.json'
if sys.argv[1:] == ['--create']:
    if PATH.exists():
        raise FileExistsError(PATH)
    files, links = dependency_state()
    selected = set(files) | set(source_inventory()) | {'protocol.json', 'prepared_plan.json'}
    for base, manifest in [(PROTOTYPE, PROTOTYPE / 'prototype_freeze.json'),
                           (ROOT, ROOT / 'proposed_p2_value_v2/operational_freeze.json')]:
        selected.add(os.path.relpath(manifest, HERE))
        for rel in json.loads(manifest.read_text())['files']:
            selected.add(os.path.relpath((base / rel).resolve(), HERE))
    document = {'protocol_id': 'urp-p2-limited-language-observation-v3-operational-20261004',
                'state': 'frozen_for_handwritten_validation_and_independent_review_no_batch_authorization',
                'dependency_files': files, 'dependency_symlinks': links,
                'operational_source_inventory': source_inventory(),
                'files': {rel: file_hash(HERE / rel) for rel in sorted(selected)}}
    PATH.write_text(json.dumps(document, indent=2) + '\n')
    print(json.dumps({'freeze_sha256': file_hash(PATH), 'files': len(selected), 'dependencies': len(files)}))
elif sys.argv[1:] == ['--verify']:
    digest = file_hash(PATH)
    frozen = verify_freeze(PATH, digest)
    print(json.dumps({'verified': True, 'freeze_sha256': digest, 'files': len(frozen['files'])}))
else:
    raise SystemExit('use --create or --verify')
