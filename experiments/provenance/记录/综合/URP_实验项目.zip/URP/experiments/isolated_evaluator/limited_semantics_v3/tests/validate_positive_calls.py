"""Additional fixed handwritten positive controls for the admitted call grammar."""
import json,pathlib,sys,time
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'));sys.path.insert(0,str(ROOT/'tests'))
from one_request import launch
from validate_handwritten import request,descriptor,clean
from handwritten_programs import body
OUT=ROOT/'results/positive_call_controls.json'
if OUT.exists():raise FileExistsError(OUT)
programs={
'set_length':body('if type(values) == set:\n    raise ValueError("fixture is not a set")\nresult = []\nresult.append(len(set(values)))\nreturn result'),
'tuple_list_sort':body('if type(values) != tuple:\n    raise ValueError("tuple expected")\ncopy = list(values)\ncopy.sort()\nreturn copy'),
'isinstance_tokens':body('if isinstance(values, list):\n    if isinstance(values[0], (int, float, complex)):\n        return []\n    raise ValueError("numeric expected")\nelif isinstance(values, int):\n    return []\nelse:\n    raise ValueError("unexpected input")'),
'ordinary_control_ops':body('result = []\nindex = 0\nwhile index < len(values) and index <= 99999:\n    item = values[index]\n    if item > 0:\n        if item not in result:\n            result.append(item)\n    index += 1\nresult.sort()\nlast = values[len(values) - 1]\nreturn result'),
}
cases=[
 ('set_unique_count','set_length',{'kind':'list','input':[2,2,1],'valid':True},[2]),
 ('set_unhashable_exact_type_error','set_length',{'kind':'list','input':[[1]],'valid':False},'exact_type_error'),
 ('tuple_materialized_conversion_sort','tuple_list_sort',{'kind':'tuple','input':[3,1],'valid':False},[1,3]),
 ('isinstance_fixed_tuple_int','isinstance_tokens',{'kind':'list','input':[1],'valid':True},[]),
 ('isinstance_fixed_tuple_float','isinstance_tokens',{'kind':'list','input':[1.5],'valid':False},[]),
 ('isinstance_int_token','isinstance_tokens',{'kind':'identity','input':7,'valid':False},[]),
 ('control_arithmetic_membership','ordinary_control_ops',{'kind':'list','input':[3,1,1],'valid':True},[1,3]),
]
start=time.monotonic();cpu=0;rows=[]
for name,program,case,expected in cases:
    if 30-cpu<2 or 60-(time.monotonic()-start)<6:raise RuntimeError('positive controls budget exhausted')
    source=programs[program];o=launch(request(source,descriptor(case)));cpu+=o['worker_user_seconds']+o['worker_sys_seconds'];w=o.get('worker') or {};p=w.get('payload')
    passed=(clean(o) and w.get('status')=='returned' and p.get('stage')=='candidate_completed')
    if expected=='exact_type_error':passed=passed and p['invocation']=='exact_type_error'
    else:passed=passed and p['invocation']=='returned' and p['result_shape_valid'] is True and p['result']==expected and p['returned_same_object'] is False
    rows.append({'name':name,'source':source,'case':case,'expected_control_result':expected,'passed':passed,'observation':o})
result={'generated_candidates_executed':0,'all_passed':all(x['passed'] for x in rows),'calls':len(rows),'worker_cpu_seconds':cpu,'wall_seconds':time.monotonic()-start,'rows':rows}
OUT.write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='rows'}))
if not result['all_passed']:raise RuntimeError('positive controls failed')
