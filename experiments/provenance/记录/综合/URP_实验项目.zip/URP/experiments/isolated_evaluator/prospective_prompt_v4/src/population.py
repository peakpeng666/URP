"""Prospective selected-source population, paired rows and separated panel analysis."""
import collections
import json
from v3_reuse import HERE, admission, digest, bounded_json

UNKNOWN={'pending','resource_unresolved','infrastructure_error','not_run_budget_exhausted',
         'not_run_infrastructure_stop','not_run_generation_unavailable'}


def load_cases():
    development=bounded_json(HERE/'fixtures/development72.json',2*1024**2)
    prospective=bounded_json(HERE/'fixtures/prospective72.json',2*1024**2)
    if len(development)!=72 or len(prospective)!=72:raise ValueError('expected two72 panels')
    cases=[]
    for i in range(72):
        for panel,original in [('development',development[i]),('prospective',prospective[i])]:
            case=dict(original)
            case['original_fixture_id']=case['id'];case['panel']=panel
            case['id']=panel+'/'+case['id']
            cases.append(case)
    if len({c['id'] for c in cases})!=144:raise ValueError('duplicate case identity')
    for c in cases:
        if c['valid']:
            if type(c['input']) is not list or any(type(x) is not int for x in c['input']) or sorted(c['input'])!=c['expected']:
                raise ValueError('fixture oracle/type mismatch')
        elif c['expected_exception']!='TypeError':raise ValueError('invalid fixture contract')
    return cases


def gate(form):
    if form.get('generation_status','generated')!='generated':
        return {'stage':'generation_unavailable','reason':form.get('generation_status')}
    return admission(form['source'])


def complete_ledger(forms,cases,scope):
    rows=[]
    gates={f['form_id']:gate(f) for f in forms}
    # Cases already interleave development/prospective; forms preserve fixed paired order.
    for case in cases:
        for form in forms:
            g=gates[form['form_id']]
            status='pending'
            if form['variant'] not in scope:status='not_run_scope_unapproved'
            elif g['stage']=='generation_unavailable':status='not_run_generation_unavailable'
            elif g['stage']=='structural_rejection':status='not_run_structural_rejection'
            elif g['stage']=='grammar_rejection':status='not_run_grammar_rejection'
            rows.append({k:form[k] for k in ('form_id','round','candidate_id','prompt_id','variant')} | {
                'seed':form.get('seed'),'panel':case['panel'],'fixture_id':case['id'],
                'original_fixture_id':case.get('original_fixture_id',case['id']),'fixture_valid':case['valid'],
                'source_sha256':digest(form['source'].encode()) if g['stage']!='generation_unavailable' else None,
                'admission':g,'status':status,'conformant':None})
    return rows


def summarize(forms,cases,rows,scope):
    outcomes=[]
    for form in forms:
        selected=[r for r in rows if r['form_id']==form['form_id']]
        states=[r['status'] for r in selected];g=gate(form)
        if form['variant'] not in scope:conclusion='scope_unapproved'
        elif g['stage']=='generation_unavailable':conclusion='incomplete_unknown'
        elif g['stage'] in ('structural_rejection','grammar_rejection'):conclusion=g['stage']
        elif states and all(s=='case_conformant' for s in states):conclusion='all_required_cases_conformant'
        elif 'case_nonconformant' in states:conclusion='observed_semantic_nonconformant'
        else:conclusion='incomplete_unknown'
        outcomes.append({k:form[k] for k in ('form_id','round','candidate_id','prompt_id','variant')} | {
            'seed':form.get('seed'),'generation_status':form.get('generation_status','generated'),
            'source_sha256':digest(form['source'].encode()) if g['stage']!='generation_unavailable' else None,
            'conclusion':conclusion,'required_cases':len(cases),
            'eligible_cases':len(cases) if g['stage']=='eligible_pending_guest_gate' and form['variant'] in scope else 0,
            'clean_semantic_measurements':sum(s in ('case_conformant','case_nonconformant') for s in states),
            'case_conformant':states.count('case_conformant'),'case_nonconformant':states.count('case_nonconformant'),
            'resource_unresolved':states.count('resource_unresolved'),'unknown_cases':sum(s in UNKNOWN for s in states),
            'case_coverage_complete':not any(s in UNKNOWN for s in states)})
    groups=[]
    for arm in sorted({f['prompt_id'] for f in forms}):
        group=[o for o in outcomes if o['prompt_id']==arm];counts=collections.Counter(o['conclusion'] for o in group)
        n=len(group);passed=counts['all_required_cases_conformant'];unknown=counts['incomplete_unknown']
        approved=not counts['scope_unapproved'];complete=approved and all(o['case_coverage_complete'] for o in group)
        groups.append({'prompt_id':arm,'original_denominator':n,'passed':passed,
                       'structural_rejected':counts['structural_rejection'],'grammar_rejected':counts['grammar_rejection'],
                       'observed_semantic_nonconformant':counts['observed_semantic_nonconformant'],'incomplete_unknown':unknown,
                       'generation_unavailable':sum(o['generation_status']!='generated' for o in group),
                       'eligible_cases':sum(o['eligible_cases'] for o in group),
                       'clean_semantic_measurements':sum(o['clean_semantic_measurements'] for o in group),
                       'case_coverage_complete':complete,
                       'pass_fraction':passed/n if complete else None,
                       'pass_fraction_lower_bound':passed/n if approved else None,
                       'pass_fraction_upper_bound':(passed+unknown)/n if approved else None})
    duplicate=collections.defaultdict(list)
    for o in outcomes:
        if o['source_sha256'] is not None:duplicate[o['source_sha256']].append(o['form_id'])
    return {'forms':outcomes,'groups':groups,'scheduled_generations':len(forms),
            'selected_forms_per_generation':1,'raw_sources_are_static_diagnostics_only':True,
            'identical_source_groups':[{'source_sha256':h,'form_ids':ids} for h,ids in duplicate.items() if len(ids)>1]}


def panel_and_pair_analysis(report,forms,cases,scope):
    valid=report['result_certification_valid'];result={}
    for panel in ('development','prospective'):
        panel_cases=[c for c in cases if c['panel']==panel]
        panel_rows=[r for r in report['rows'] if r['panel']==panel]
        analysis=summarize(forms,panel_cases,panel_rows,scope)
        analysis['certification_valid']=valid
        if not valid:
            for f in analysis['forms']:f['conclusion']='uncertified_integrity_failure'
            for g in analysis['groups']:
                for key in ('passed','pass_fraction','pass_fraction_lower_bound','pass_fraction_upper_bound'):g[key]=None
        result[panel]=analysis
    comparisons={}
    for label,analysis in [('all144',report),*result.items()]:
        by={(f.get('seed'),f['prompt_id']):f for f in analysis['forms']};pairs=[]
        for seed in sorted({f.get('seed') for f in forms if f.get('seed') is not None}):
            a,b=by.get((seed,'A')),by.get((seed,'B'))
            if a is None or b is None:continue
            decisions=[f['conclusion'] for f in (a,b)]
            unresolved=not valid or any(x in ('incomplete_unknown','scope_unapproved','uncertified_integrity_failure') for x in decisions)
            if unresolved:outcome='unknown'
            else:
                ap=decisions[0]=='all_required_cases_conformant';bp=decisions[1]=='all_required_cases_conformant'
                outcome='B_win' if bp and not ap else 'A_win' if ap and not bp else 'tie_pass' if ap else 'tie_no_protocol_pass'
            pairs.append({'seed':seed,'A':decisions[0],'B':decisions[1],'outcome':outcome,
                          'both_case_coverages_complete':a['case_coverage_complete'] and b['case_coverage_complete']})
        comparisons[label]={'pairs':pairs,'counts':dict(collections.Counter(p['outcome'] for p in pairs)),
                            'interpretation':'Five-pair exploratory protocol-success comparison; categories overlap across panels and programs may share source bytes'}
    return {'panels':result,'paired_program_outcomes':comparisons}
