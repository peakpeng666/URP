"""Independent original-fixture checks; never part of the guest build."""
def check_payload(payload,case):
    keys={'stage','invocation','result_shape_valid','result','returned_same_object','final_input_unchanged','valid_fixture'}
    if type(payload) is not dict or set(payload)!=keys or payload['stage']!='candidate_completed':return False
    if payload['valid_fixture'] is not case['valid']:return False
    if case['valid']:
        result=payload['result']
        return (payload['invocation']=='returned' and payload['result_shape_valid'] is True
            and type(result) is list and all(type(x) is int for x in result)
            and result==case['expected'] and result==sorted(case['input'])
            and payload['returned_same_object'] is False and payload['final_input_unchanged'] is True)
    return (payload['invocation']=='exact_type_error' and payload['result_shape_valid'] is False
        and payload['result'] is None and payload['returned_same_object'] is None and payload['final_input_unchanged'] is None)
