"""Saved handwritten evidence only; no candidate execution."""
import collections,hashlib,json,pathlib,statistics
ROOT=pathlib.Path(__file__).resolve().parents[1]
base=ROOT/'results/handwritten_validation';r=json.loads((base/'report.json').read_text())
obs=[json.loads((base/x['observation']).read_text()) for x in r['rows']]
fuel=json.loads((ROOT/'results/fuel_control_recheck.json').read_text())
positive=json.loads((ROOT/'results/positive_call_controls.json').read_text())
cleanup=json.loads((ROOT/'results/supervisor_fault_validation.json').read_text())
if not (r['failed']==['resource/fuel_loop'] and fuel['passed'] and positive['all_passed'] and cleanup['all_reaped']):raise ValueError('unresolved validation failure')
ref=[(row,o) for row,o in zip(r['rows'],obs) if row['name'].startswith('reference/')]
full=next(o for row,o in zip(r['rows'],obs) if row['name']=='boundary/full_8192_response')
summary={
'protocol_id':'urp-p2-limited-language-final-state-v3-handwritten-20261004',
'generated_candidates_executed':0,'generated_sources_built_or_imported':0,
'original_reference_fixtures_passed':sum(row['passed'] for row,o in ref),'original_reference_fixtures':72,
'initial_matrix_requests':r['calls'],'initial_report_passed':r['passed'],'initial_report_failed':r['failed'],
'corrected_initial_matrix_controls_supported':182,
'fuel_assertion_correction':{'original_failure_preserved':True,'reason':'Bounded traceback prefix omitted the textual fuel cause; trusted Store fuel counter was zero','handwritten_repeat_requests':1,'repeat_passed':fuel['passed'],'artifact_or_resource_changes':False},
'positive_grammar_control_requests':positive['calls'],'positive_grammar_controls_passed':sum(x['passed'] for x in positive['rows']),
'handwritten_wasm_requests_total':r['calls']+1+positive['calls'],
'host_cleanup_fault_controls':len(cleanup['results']),'all_cleanup_workers_reaped':cleanup['all_reaped'],
'initial_matrix_worker_cpu_seconds':r['worker_cpu_seconds'],'initial_matrix_supervisor_cpu_seconds':r['supervisor_cpu_seconds'],'initial_matrix_wall_seconds':r['wall_seconds'],
'fuel_repeat_worker_cpu_seconds':fuel['result']['worker_user_seconds']+fuel['result']['worker_sys_seconds'],'fuel_repeat_wall_seconds':fuel['result']['wall_seconds'],
'positive_controls_worker_cpu_seconds':positive['worker_cpu_seconds'],'positive_controls_wall_seconds':positive['wall_seconds'],
'cleanup_controls_worker_cpu_seconds':sum(x['result']['worker_user_seconds']+x['result']['worker_sys_seconds'] for x in cleanup['results']),
'cleanup_controls_request_wall_sum_seconds':sum(x['result']['wall_seconds'] for x in cleanup['results']),
'cleanup_accounting':'Routine reap included in request walls. EOF helper deliberately used5s deadline; selector and output-overflow helpers exercise finally cleanup. These are trusted host helper tests, not guest execution.',
'reference72_worker_cpu_seconds':sum(o['worker_user_seconds']+o['worker_sys_seconds'] for row,o in ref),
'reference72_request_wall_sum_seconds':sum(o['wall_seconds'] for row,o in ref),
'reference72_max_fuel':max(o['worker']['fuel_budget']-o['worker']['fuel_remaining'] for row,o in ref),
'full8192_response_fuel':full['worker']['fuel_budget']-full['worker']['fuel_remaining'],'full8192_response_wall_seconds':full['wall_seconds'],
'initial_matrix_request_wall_median_seconds':statistics.median(o['wall_seconds'] for o in obs),
'initial_matrix_worker_peak_rss_kib':max(o['worker']['maxrss_kib'] for o in obs),'initial_matrix_supervisor_peak_rss_kib':r['supervisor_peak_rss_kib'],
'initial_matrix_distinct_worker_pids':len({o['worker_pid'] for o in obs}),
'initial_matrix_distinct_supervisor_pids':len({o['supervisor_pid'] for o in obs}),
'limits':json.loads((ROOT/'protocol.json').read_text()),
'resource_caveats':['RSS is measured, not a hard totalRSS cap; original256MiB contract remains unmet.','Memory-growth probe also exhausted fuel; it does not independently establish a memory-limit hit.','CPU/epoch limits were configured and recorded; no independent candidate CPU/epoch-limit hit was exercised.','Wall cleanup helper tests supervisor behavior; they are not proof of interruption after a guest instruction.'],
'semantic_caveats':['Final input state only: mutate-then-restore control intentionally passes.','Closed language admission, not universal Python or formal proof.','Host AST-only predicted12/13 source-form coverage; no generated source has reached the v3 guest.'],
'build':json.loads((ROOT/'logs/clean_build_result.json').read_text()),
'cold_compile':json.loads((ROOT/'logs/compile_trusted_clean_time.json').read_text()),
'artifacts':json.loads((ROOT/'build/trusted_clean_manifest.json').read_text()),
'independent_final_review':'pending'
}
(ROOT/'results/summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ('limits','build','cold_compile','artifacts')},indent=2))
