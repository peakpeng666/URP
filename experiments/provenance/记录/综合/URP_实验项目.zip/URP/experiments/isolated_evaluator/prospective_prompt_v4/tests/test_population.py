"""Handwritten/fake-transport tests only; no model programs are run."""
import copy
import inspect
import json
import pathlib
import sys
import tempfile
import unittest
from unittest.mock import patch
HERE=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE/'src'))
from v3_reuse import v3_batch,digest,make_request,classify,v3_checker
from population import complete_ledger,summarize,panel_and_pair_analysis,load_cases
from evaluation_core import run_forms
from evaluation_integrity import verify_evaluation_approval,parse_frozen
from evaluate_population import claim

SOURCE='def sort_numbers(values):\n    return sorted(values)\n'

def form(arm='A',seed=601,source=SOURCE,status='generated'):
    name=f'sample_{seed}_{arm}'
    return {'form_id':name+'/selected','round':'prospective_v4','candidate_id':name,'prompt_id':arm,
            'variant':'selected','seed':seed,'source':source,'generation_status':status}

def case(panel='development'):
    return {'id':panel+'/one','original_fixture_id':'one','panel':panel,'valid':True,'kind':'list','input':[2,1],'expected':[1,2]}


def good(request):
    data=json.loads(request['input_json']);value=data['value']
    return {'returncode':0,'termination':None,'protocol_error':False,'worker_unreaped':False,
            'supervisor_error':None,'guest_entry_observed':True,'worker_pid':11,'supervisor_pid':1,
            'worker_user_seconds':1,'worker_sys_seconds':0,'wall_seconds':1,
            'source_sha256':request['source_sha256'],'input_sha256':request['input_sha256'],
            'worker':{'status':'returned','payload':{'stage':'candidate_completed','invocation':'returned',
            'result_shape_valid':True,'result':sorted(value),'returned_same_object':False,
            'final_input_unchanged':True,'valid_fixture':True}}}

class PopulationTests(unittest.TestCase):
    def execute(self,forms,cases,executor=good,**kwargs):
        with tempfile.TemporaryDirectory() as tmp:
            return run_forms(forms,cases,{'selected'},output_dir=pathlib.Path(tmp)/'out',executor=executor,**kwargs)

    def test_run_loop_is_byte_identical_reviewed_function(self):
        self.assertEqual(inspect.getsource(run_forms),inspect.getsource(v3_batch.run_forms))
        self.assertIs(classify,v3_checker.classify)

    def test_full_plan_order(self):
        forms=[]
        for i,seed in enumerate([601,631,661,701,751]):
            forms.extend(form(a,seed) for a in (['A','B'] if i%2==0 else ['B','A']))
        cases=load_cases();rows=complete_ledger(forms,cases,{'selected'})
        self.assertEqual(len(rows),1440)
        self.assertEqual(len({(r['form_id'],r['fixture_id']) for r in rows}),1440)
        self.assertEqual([r['form_id'] for r in rows[:10]],[f['form_id'] for f in forms])
        self.assertEqual([rows[i*10]['panel'] for i in range(144)],['development','prospective']*72)

    def test_missing_generation_is_unknown_not_rejection(self):
        result=self.execute([form(status='not_started',source='')],[case()])
        self.assertEqual(result['dispatches'],0)
        self.assertEqual(result['rows'][0]['status'],'not_run_generation_unavailable')
        self.assertEqual(result['forms'][0]['conclusion'],'incomplete_unknown')
        self.assertIsNone(result['groups'][0]['pass_fraction'])
        self.assertEqual(result['groups'][0]['pass_fraction_upper_bound'],1)

    def test_structural_and_grammar_distinct(self):
        result=self.execute([form('A',source='invalid ???'),form('B',source='def sort_numbers(values):\n    return values[:]\n')],[case()])
        self.assertEqual(result['dispatches'],0)
        self.assertEqual([f['conclusion'] for f in result['forms']],['structural_rejection','grammar_rejection'])

    def test_mid_cpu_stop_preserves_paired_rows(self):
        forms=[form('A'),form('B')];cases=[case(),case('prospective')]
        result=self.execute(forms,cases,cpu_budget=3)
        self.assertEqual(result['dispatches'],2)
        self.assertEqual(result['worker_cpu_seconds'],2)
        self.assertEqual([r['status'] for r in result['rows']],['case_conformant']*2+['not_run_budget_exhausted']*2)
        self.assertTrue(all(g['pass_fraction'] is None for g in result['groups']))

    def test_mid_wall_stop_preserves_reservation(self):
        tick=[0]
        def clock():return tick[0]
        def execute(request):tick[0]+=4;return good(request)
        r=self.execute([form('A'),form('B')],[case(),case('prospective')],executor=execute,clock=clock,wall_budget=13)
        self.assertEqual(r['dispatches'],2)
        self.assertEqual(r['stop_reason'],'budget_exhausted')
        self.assertEqual(r['elapsed_seconds'],8)

    def test_panel_and_pair_outcomes(self):
        forms=[form('A'),form('B')];cases=[case(),case('prospective')]
        rows=complete_ledger(forms,cases,{'selected'})
        for r in rows:r['status']='case_nonconformant' if r['prompt_id']=='A' and r['panel']=='prospective' else 'case_conformant'
        base=summarize(forms,cases,rows,{'selected'});base.update(rows=rows,result_certification_valid=True)
        analysis=panel_and_pair_analysis(base,forms,cases,{'selected'})
        self.assertEqual(analysis['paired_program_outcomes']['all144']['counts'],{'B_win':1})
        self.assertEqual(analysis['paired_program_outcomes']['development']['counts'],{'tie_pass':1})
        self.assertEqual(analysis['paired_program_outcomes']['prospective']['counts'],{'B_win':1})

    def test_integrity_failure_invalidates_panel_certification(self):
        forms=[form('A'),form('B')];cases=[case()];checks=[0]
        def verify():
            checks[0]+=1
            if checks[0]==2:raise ValueError('changed')
        r=self.execute(forms,cases,integrity_check=verify)
        self.assertFalse(r['result_certification_valid'])
        self.assertTrue(all(f['conclusion']=='uncertified_integrity_failure' for f in r['forms']))
        analysis=panel_and_pair_analysis(r,forms,cases,{'selected'})
        self.assertTrue(all(g['passed'] is None for a in analysis['panels'].values() for g in a['groups']))

    def test_pre_dispatch_integrity_has_no_unknown_launch(self):
        def fail():raise ValueError('changed')
        r=self.execute([form()],[case()],integrity_check=fail)
        self.assertEqual(r['dispatches'],0)
        self.assertEqual(r['requests_without_returned_execution_evidence'],0)

    def test_clean_payload_on_bad_transport_never_passes(self):
        def bad(request):r=good(request);r['returncode']=2;return r
        r=self.execute([form()],[case()],executor=bad)
        self.assertEqual(r['rows'][0]['status'],'infrastructure_error')

    def test_exact_evaluation_approval_and_single_use(self):
        a={'explicit_authorization':True,'stage':'evaluation','preparation_freeze_sha256':'a'*64,
           'population_freeze_sha256':'b'*64,'scope':'ten_selected_forms_all144','batch_id':'manual_gate'}
        self.assertEqual(verify_evaluation_approval(a,'a'*64,'b'*64),{'selected'})
        for key,value in [('explicit_authorization',1),('stage','generation'),('scope','any'),('population_freeze_sha256','bad')]:
            bad=dict(a);bad[key]=value
            with self.assertRaises(PermissionError):verify_evaluation_approval(bad,'a'*64,'b'*64)
        with tempfile.TemporaryDirectory() as tmp:
            root=pathlib.Path(tmp);claim(a,root/'one',root/'uses')
            with self.assertRaises(FileExistsError):claim(a,root/'two',root/'uses')

    def test_replaced_manifest_bytes_fail(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=pathlib.Path(tmp)/'m.json';p.write_text('{"files":{}}');d=digest(p.read_bytes())
            self.assertEqual(parse_frozen(p,d),{'files':{}})
            p.write_text('{"files":{},"consistent":true}')
            with self.assertRaisesRegex(ValueError,'changed'):parse_frozen(p,d)

if __name__=='__main__':unittest.main()
