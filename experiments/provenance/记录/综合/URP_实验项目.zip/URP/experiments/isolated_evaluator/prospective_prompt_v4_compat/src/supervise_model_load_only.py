"""Reviewed load-only check: 180s whole wall + bounded 5s cleanup + 2s report.

This command needs separate parent review and authorization. It never creates or
consumes generation approval/use markers. No automatic retry; output is exclusive.
"""
import argparse
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys
import time

from generation_integrity import ROOT, read_json, write_json
from check_model_load_only import LOAD_ONLY_LIMITS
from supervise_generation import (WholeWallExpired, SupervisorInterrupted, _wall_alarm,
    _stop_signal, clean_environment, cleanup, wait4_until, group_exists)

WALL_SECONDS = 180
CLEANUP_SECONDS = 5
REPORT_SECONDS = 2


def limit_child():
    for key, limits in LOAD_ONLY_LIMITS.items():
        resource.setrlimit(key, limits)


def main():
    started = time.monotonic()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reviewed-preparation-sha256", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    output = args.output.absolute()
    if output.parent.resolve() != (ROOT / "results").resolve():
        raise ValueError("Output must be a new direct child of compatibility results")
    output.mkdir(exist_ok=False)
    deadline = started + WALL_SECONDS
    process = None
    status = {"stage": "compatibility_model_load_only", "status": "failed",
              "preparation_freeze_sha256": args.reviewed_preparation_sha256,
              "wall_limit_seconds": WALL_SECONDS, "cleanup_limit_seconds": CLEANUP_SECONDS,
              "report_limit_seconds": REPORT_SECONDS, "generation_calls": 0,
              "candidate_executions": 0, "automatic_retry": False,
              "generation_authorization_created_or_consumed": False,
              "clean_environment": clean_environment()}
    signal.signal(signal.SIGALRM, _wall_alarm)
    signal.signal(signal.SIGTERM, _stop_signal)
    signal.signal(signal.SIGINT, _stop_signal)
    signal.setitimer(signal.ITIMER_REAL, max(0.001, deadline - time.monotonic()))
    try:
        python = ROOT / "../../sorting_generation/.venv/bin/python"
        command = [str(python), "-B", "-s", str(ROOT / "src/check_model_load_only.py"),
                   "--preparation-freeze-sha256", args.reviewed_preparation_sha256,
                   "--output", str(output)]
        status["command"] = command
        with (output / "stdout.log").open("xb") as out, (output / "stderr.log").open("xb") as err:
            process = subprocess.Popen(command, cwd=ROOT, env=clean_environment(), stdin=subprocess.DEVNULL,
                stdout=out, stderr=err, start_new_session=True, preexec_fn=limit_child)
        status["worker_pid"] = process.pid
        code, used = wait4_until(process, deadline)
        status["returncode"] = code
        if used is not None:
            status["worker_rusage"] = {"user_seconds": used.ru_utime, "system_seconds": used.ru_stime,
                                        "peak_rss_kib": used.ru_maxrss}
        status["status"] = "worker_completed" if code is not None else "wall_timeout"
    except (WholeWallExpired, SupervisorInterrupted) as exc:
        status.update(status="interrupted_or_wall_timeout", error=str(exc))
    except Exception as exc:
        status.update(status="supervisor_error", error_type=type(exc).__name__, error=str(exc)[:4096])
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGINT, signal.SIG_IGN)
        signal.signal(signal.SIGTERM, signal.SIG_IGN)
        status["pre_cleanup_wall_seconds"] = time.monotonic() - started
        if process is not None:
            code, used, detail = cleanup(process)
            status.update(cleanup=detail, returncode=code)
        else:
            status["cleanup"] = {"cleanup_complete": True, "process_group_absent": True,
                                  "cleanup_wall_seconds": 0, "cleanup_bound_seconds": CLEANUP_SECONDS}
        # The only post-cleanup work is bounded report reading/publication.
        signal.setitimer(signal.ITIMER_REAL, REPORT_SECONDS)
        try:
            if status["status"] == "worker_completed" and status["returncode"] == 0:
                _, worker = read_json(output / "model_load_status.json", 2 * 1024**2)
                if (worker["status"] == "passed" and worker["integrity_after"] == "passed"
                        and worker["generation_calls"] == 0 and worker["candidate_executions"] == 0
                        and status["cleanup"]["cleanup_complete"]):
                    status["status"] = "passed"
            if status["status"] == "worker_completed":
                status["status"] = "failed"
            status["whole_wall_seconds"] = time.monotonic() - started
            write_json(output / "model_load_supervisor_status.json", status, exclusive=True)
            print(status["status"])
        finally:
            signal.setitimer(signal.ITIMER_REAL, 0)
    return 0 if status["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
