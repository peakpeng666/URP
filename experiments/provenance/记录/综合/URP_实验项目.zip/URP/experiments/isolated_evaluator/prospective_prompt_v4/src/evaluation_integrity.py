"""Preparation/population freeze checks; no generation or source execution."""
import hashlib
import os
import pathlib
import re
from v3_reuse import HERE, EVALUATOR, V3, V3_DIGEST, v3_integrity, bounded_json, strict_json, file_hash


def source_inventory():
    return sorted(str(p.relative_to(HERE)) for d in ('src', 'tests') for p in (HERE/d).rglob('*.py'))


def parse_frozen(path, expected, limit=32*1024**2):
    with path.open('rb') as stream: raw=stream.read(limit+1)
    if len(raw)>limit: raise ValueError('freeze file size limit')
    if hashlib.sha256(raw).hexdigest()!=expected: raise ValueError('approved freeze changed')
    return strict_json(raw)


def verify_preparation(path, expected):
    frozen=parse_frozen(path,expected)
    if frozen['v3_operational_sha256']!=V3_DIGEST or file_hash(V3/'operational_freeze.json')!=V3_DIGEST:
        raise ValueError('v3 antecedent changed')
    if source_inventory()!=frozen['source_inventory']: raise ValueError('v4 source inventory changed')
    files,links=v3_integrity.dependency_state()
    if files!=frozen['evaluator_dependency_files'] or links!=frozen['evaluator_dependency_symlinks']:
        raise ValueError('evaluator dependency inventory changed')
    if v3_integrity.source_inventory()!=frozen['v3_source_inventory']:
        raise ValueError('v3 source inventory changed')
    proto=EVALUATOR/'limited_semantics_v3'
    inventory=sorted(str(p.relative_to(proto)) for d in ('src','tests') for p in (proto/d).rglob('*.py'))
    if inventory!=frozen['prototype_source_inventory']:raise ValueError('prototype source inventory changed')
    for rel,expected_hash in (frozen['core_files'] | frozen['evaluator_files']).items():
        if file_hash(HERE/rel)!=expected_hash:raise ValueError('frozen core file changed: '+rel)
    return frozen


def verify_population(path, expected, preparation_digest):
    pop=parse_frozen(path,expected,2*1024**2)
    if pop['preparation_freeze_sha256']!=preparation_digest:raise ValueError('population preparation mismatch')
    for rel,expected_hash in pop['generation_evidence_files'].items():
        if file_hash(HERE/rel)!=expected_hash:raise ValueError('generation evidence changed: '+rel)
    return pop


def verify_evaluation_approval(value, preparation_digest, population_digest):
    keys={'explicit_authorization','stage','preparation_freeze_sha256','population_freeze_sha256','scope','batch_id'}
    if type(value) is not dict or set(value)!=keys or value['explicit_authorization'] is not True:
        raise PermissionError('explicit evaluation authorization absent')
    if value['stage']!='evaluation' or value['scope']!='ten_selected_forms_all144':raise PermissionError('wrong evaluation scope')
    if value['preparation_freeze_sha256']!=preparation_digest or value['population_freeze_sha256']!=population_digest:
        raise PermissionError('approved evaluation digest mismatch')
    if type(value['batch_id']) is not str or re.fullmatch('[a-z0-9_-]{1,80}',value['batch_id']) is None:
        raise PermissionError('invalid batch identifier')
    return {'selected'}
