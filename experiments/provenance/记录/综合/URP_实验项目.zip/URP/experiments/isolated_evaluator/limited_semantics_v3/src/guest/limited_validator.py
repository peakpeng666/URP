"""Closed, version-pinned measurement language, NOT the host sandbox.

The exact AST validated here is compiled inside the guest. No source rewriting.
Every admitted node's fields, context, call shape and binding are checked.
"""
import ast

MAX_SOURCE=16384
MAX_NODES=1024
MAX_DEPTH=64
TYPE_TEST_TOKENS=frozenset(('list','int','tuple','set'))
INSTANCE_TOKENS=frozenset(('list','int','float','complex'))
RESERVED=frozenset(('sort_numbers','type','isinstance','list','int','tuple','set','float','complex','bool','str','len','range','sorted','all','TypeError','ValueError'))

class RejectedLanguage(Exception):
    pass


def _reject():
    raise RejectedLanguage('unsupported_language')


def _shape(node,kind,fields):
    if type(node) is not kind or tuple(node._fields)!=fields:
        _reject()


def _context(node,kind):
    _shape(node,kind,())


def _identifier(name):
    # ast.parse already normalizes Python identifiers (NFKC). Non-ASCII remnants,
    # leading underscores and every provided builtin/evaluator token are forbidden.
    if type(name) is not str or not name.isascii() or not name.isidentifier() or len(name)>48 or name.startswith('_') or name in RESERVED:
        _reject()


class Validator:
    def __init__(self):
        self.locals={'values'}

    def bind(self,node):
        _shape(node,ast.Name,('id','ctx'));_context(node.ctx,ast.Store)
        _identifier(node.id);self.locals.add(node.id)

    def name(self,node,locals=None):
        _shape(node,ast.Name,('id','ctx'));_context(node.ctx,ast.Load)
        _identifier(node.id)
        if node.id not in (self.locals if locals is None else locals):_reject()

    def token(self,node,allowed):
        _shape(node,ast.Name,('id','ctx'));_context(node.ctx,ast.Load)
        if node.id not in allowed:_reject()

    def int_literal(self,node):
        _shape(node,ast.Constant,('value','kind'))
        if node.kind is not None or type(node.value) is not int or node.value.bit_length()>256:_reject()

    def string_literal(self,node,limit):
        _shape(node,ast.Constant,('value','kind'))
        if node.kind is not None or type(node.value) is not str or len(node.value.encode('utf-8'))>limit:_reject()

    def call_shape(self,node,arity):
        _shape(node,ast.Call,('func','args','keywords'))
        if node.keywords or len(node.args)!=arity:_reject()

    def type_call(self,node,locals=None):
        self.call_shape(node,1);self.token(node.func,{'type'});self.data(node.args[0],locals)

    def special_all(self,node):
        self.call_shape(node,1);self.token(node.func,{'all'})
        g=node.args[0];_shape(g,ast.GeneratorExp,('elt','generators'))
        if len(g.generators)!=1:_reject()
        comp=g.generators[0];_shape(comp,ast.comprehension,('target','iter','ifs','is_async'))
        if comp.ifs or comp.is_async!=0:_reject()
        _shape(comp.target,ast.Name,('id','ctx'));_context(comp.target.ctx,ast.Store)
        _identifier(comp.target.id)
        if comp.target.id in self.locals:_reject()
        self.name(comp.iter)
        if comp.iter.id!='values':_reject()
        e=g.elt;_shape(e,ast.Compare,('left','ops','comparators'))
        if len(e.ops)!=1 or len(e.comparators)!=1:_reject()
        _context(e.ops[0],ast.Eq)
        self.type_call(e.left,self.locals|{comp.target.id})
        if type(e.left.args[0]) is not ast.Name or e.left.args[0].id!=comp.target.id:_reject()
        self.token(e.comparators[0],{'int'})

    def compare(self,node,locals=None):
        _shape(node,ast.Compare,('left','ops','comparators'))
        if len(node.ops)!=1 or len(node.comparators)!=1:_reject()
        op=node.ops[0]
        if type(op) not in (ast.Eq,ast.NotEq,ast.Lt,ast.LtE,ast.Gt,ast.NotIn):_reject()
        _context(op,type(op))
        if type(node.left) is ast.Call and type(node.left.func) is ast.Name and node.left.func.id=='type':
            if type(op) not in (ast.Eq,ast.NotEq):_reject()
            self.type_call(node.left,locals);self.token(node.comparators[0],TYPE_TEST_TOKENS)
        else:
            self.data(node.left,locals);self.data(node.comparators[0],locals)

    def method(self,node):
        _shape(node,ast.Call,('func','args','keywords'))
        attr=node.func;_shape(attr,ast.Attribute,('value','attr','ctx'));_context(attr.ctx,ast.Load)
        self.name(attr.value)
        if attr.attr=='append':
            self.call_shape(node,1);self.data(node.args[0])
        elif attr.attr=='sort':self.call_shape(node,0)
        else:_reject()
        # Closed data reachability excludes classes/custom objects; among admitted
        # ordinary builtin data, only an exact list supplies these two methods.

    def data(self,node,locals=None):
        kind=type(node)
        if kind is ast.Name:self.name(node,locals)
        elif kind is ast.Constant:self.int_literal(node)
        elif kind is ast.List:
            _shape(node,ast.List,('elts','ctx'));_context(node.ctx,ast.Load)
            if node.elts:_reject()
        elif kind is ast.Subscript:
            _shape(node,ast.Subscript,('value','slice','ctx'));_context(node.ctx,ast.Load)
            self.name(node.value,locals);self.data(node.slice,locals)
        elif kind is ast.BinOp:
            _shape(node,ast.BinOp,('left','op','right'))
            if type(node.op) not in (ast.Add,ast.Sub):_reject()
            _context(node.op,type(node.op));self.data(node.left,locals);self.data(node.right,locals)
        elif kind is ast.BoolOp:
            _shape(node,ast.BoolOp,('op','values'));_context(node.op,ast.And)
            if len(node.values)<2 or len(node.values)>8:_reject()
            for v in node.values:self.data(v,locals)
        elif kind is ast.UnaryOp:
            _shape(node,ast.UnaryOp,('op','operand'));_context(node.op,ast.Not);self.data(node.operand,locals)
        elif kind is ast.Compare:self.compare(node,locals)
        elif kind is ast.Call:
            _shape(node,ast.Call,('func','args','keywords'))
            _shape(node.func,ast.Name,('id','ctx'));_context(node.func.ctx,ast.Load)
            name=node.func.id
            if name in ('list','sorted'):
                self.call_shape(node,1);self.data(node.args[0],locals)
            elif name=='len':
                self.call_shape(node,1);arg=node.args[0]
                if type(arg) is ast.Call and type(arg.func) is ast.Name and arg.func.id=='set':
                    self.call_shape(arg,1);self.token(arg.func,{'set'});self.name(arg.args[0],locals)
                    if arg.args[0].id!='values':_reject()
                else:self.data(arg,locals)
            elif name=='range':
                self.call_shape(node,2)
                for x in node.args:self.data(x,locals)
            elif name=='isinstance':
                self.call_shape(node,2);self.data(node.args[0],locals)
                token=node.args[1]
                if type(token) is ast.Tuple:
                    _shape(token,ast.Tuple,('elts','ctx'));_context(token.ctx,ast.Load)
                    if len(token.elts)!=3:_reject()
                    for item,expected in zip(token.elts,('int','float','complex')):self.token(item,{expected})
                else:self.token(token,{'list','int'})
            elif name=='all':self.special_all(node)
            else:_reject()
        else:_reject()

    def target(self,node):
        if type(node) is ast.Name:self.bind(node)
        elif type(node) is ast.Subscript:
            _shape(node,ast.Subscript,('value','slice','ctx'));_context(node.ctx,ast.Store)
            self.name(node.value);self.data(node.slice)
        else:_reject()

    def statements(self,nodes,docstring=False):
        if type(nodes) is not list or len(nodes)>256:_reject()
        for i,node in enumerate(nodes):
            k=type(node)
            if k is ast.If:
                _shape(node,ast.If,('test','body','orelse'));self.data(node.test);self.statements(node.body);self.statements(node.orelse)
            elif k is ast.Return:
                _shape(node,ast.Return,('value',));self.data(node.value)
            elif k is ast.Assign:
                _shape(node,ast.Assign,('targets','value','type_comment'))
                if len(node.targets)!=1 or node.type_comment is not None:_reject()
                self.target(node.targets[0]);self.data(node.value)
            elif k is ast.AugAssign:
                _shape(node,ast.AugAssign,('target','op','value'));self.bind(node.target);_context(node.op,ast.Add);self.data(node.value)
            elif k is ast.For:
                _shape(node,ast.For,('target','iter','body','orelse','type_comment'))
                if node.orelse or node.type_comment is not None:_reject()
                self.bind(node.target);self.data(node.iter);self.statements(node.body)
            elif k is ast.While:
                _shape(node,ast.While,('test','body','orelse'))
                if node.orelse:_reject()
                self.data(node.test);self.statements(node.body)
            elif k is ast.Expr:
                _shape(node,ast.Expr,('value',))
                if docstring and i==0 and type(node.value) is ast.Constant and type(node.value.value) is str:self.string_literal(node.value,4096)
                else:self.method(node.value)
            elif k is ast.Raise:
                _shape(node,ast.Raise,('exc','cause'))
                if node.cause is not None:_reject()
                self.call_shape(node.exc,1);self.token(node.exc.func,{'TypeError','ValueError'});self.string_literal(node.exc.args[0],1024)
            else:_reject()

    def validate(self,tree):
        _shape(tree,ast.Module,('body','type_ignores'))
        if tree.type_ignores or len(tree.body)!=1:_reject()
        f=tree.body[0];_shape(f,ast.FunctionDef,('name','args','body','decorator_list','returns','type_comment','type_params'))
        if f.name!='sort_numbers' or f.decorator_list or f.returns is not None or f.type_comment is not None or f.type_params:_reject()
        a=f.args;_shape(a,ast.arguments,('posonlyargs','args','vararg','kwonlyargs','kw_defaults','kwarg','defaults'))
        if a.posonlyargs or len(a.args)!=1 or a.vararg is not None or a.kwonlyargs or a.kw_defaults or a.kwarg is not None or a.defaults:_reject()
        arg=a.args[0];_shape(arg,ast.arg,('arg','annotation','type_comment'))
        if arg.arg!='values' or arg.annotation is not None or arg.type_comment is not None:_reject()
        count=0;stack=[(tree,0)]
        while stack:
            node,depth=stack.pop();count+=1
            if count>MAX_NODES or depth>MAX_DEPTH:_reject()
            stack.extend((child,depth+1) for child in ast.iter_child_nodes(node))
            # Precollect ordinary locals so unbound reads remain ordinary Python
            # exceptions and generator targets cannot shadow any outer binding.
            if type(node) in (ast.Assign,ast.AugAssign,ast.For):
                targets=node.targets if type(node) is ast.Assign else [node.target]
                for target in targets:
                    if type(target) is ast.Name:self.bind(target)
        self.statements(f.body,docstring=True)
        return tree


def parse_and_validate(source):
    if type(source) is not str or len(source.encode('utf-8'))>MAX_SOURCE:_reject()
    tree=ast.parse(source,filename='<limited-candidate>',mode='exec',type_comments=True)
    return Validator().validate(tree)
