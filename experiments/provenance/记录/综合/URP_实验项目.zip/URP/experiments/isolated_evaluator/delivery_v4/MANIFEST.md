# Accepted public v4 delivery

`manifest.json` lists 715 payload files, 27,520,371 bytes, with paths relative to
URP and exact SHA256 hashes. The manifest and this index are additional files,
not included in the payload count.

Manifest SHA256:
`91955169106d7f2ec85a91dbbef36bfc93c8dcaacaff98ec78d62c8a4ddbeb50`

Start with `RESULTS_ZH.md`, `summary.json` and `REPRODUCE.md`. Full ledgers,
observations, generated text/token records, failed precursor and load-only probe
remain original relative downloads. Existing v2/v3 deliveries are unchanged.

All public projection fields and payload hashes were reconciled against saved
evidence, without rerunning candidates. Both arms had zero full-protocol passes,
and this pilot is closed under its predeclared stopping rule.

Installed environments, model weights, binary caches, local run-authorization
records and the full local preservation inventory are excluded. Historical
freezes require fresh environment/inventory validation for any reproduction.
