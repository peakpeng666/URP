import ast
import hashlib
import json
import pathlib
import sys
import unittest
ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from handwritten_probes import PROBES
from host_checker import check_payload_value

class StaticGates(unittest.TestCase):
    def test_host_checker_rejects_bool_int_alias(self):
        self.assertFalse(check_payload_value({'ok':True,'result':[True]},[1]))
        self.assertFalse(check_payload_value({'ok':True,'result':[1.0]},[1]))
        self.assertTrue(check_payload_value({'ok':True,'result':[1]},[1]))
    def test_registered_handwritten_only(self):
        for name,p in PROBES.items():
            self.assertLessEqual(len(p['source'].encode()),16384)
            self.assertLessEqual(len(json.dumps(p['input']).encode()),8192)
            ast.parse(p['source'])
    def test_no_candidate_file_reads(self):
        for name in ('host_worker.py','run_probes.py','compile_trusted.py','guest/trusted_guest.py'):
            s=(ROOT/'src'/name).read_text()
            self.assertNotIn('raw_generations',s)
            self.assertNotIn('sorting_generation/',s)
    def test_scalar_exports_only(self):
        s=(ROOT/'src/guest/evaluator.wit').read_text()
        self.assertEqual(s.count('-> u32'),2)
        self.assertNotIn('-> string',s)
        self.assertNotIn('-> list',s)
        self.assertNotIn('import ',s)
    def test_empty_linker_no_host_capabilities(self):
        t=ast.parse((ROOT/'src/host_worker.py').read_text())
        forbidden={'define','define_func','add_wasi','add_wasip2','set_wasi','set_wasi_http'}
        self.assertFalse(any(isinstance(n,ast.Attribute) and n.attr in forbidden for n in ast.walk(t)))
    def test_no_builtin_filter_claim(self):
        s=(ROOT/'src/guest/trusted_guest.py').read_text()
        self.assertNotIn("'__builtins__':",s)
        self.assertIn('This is NOT a Python sandbox',s)
    def test_no_reduced_wasm_guards(self):
        s=(ROOT/'src/runtime_config.py').read_text()
        self.assertNotIn('memory_guard_size =',s)
        self.assertNotIn('memory_reservation =',s)
    def test_wheel_hashes_match_pypi(self):
        for d in json.loads((ROOT/'provenance/dependencies.json').read_text()):
            with (ROOT/'vendor'/d['filename']).open('rb') as f:
                self.assertEqual(hashlib.file_digest(f,'sha256').hexdigest(),d['sha256'])
if __name__=='__main__':unittest.main()
