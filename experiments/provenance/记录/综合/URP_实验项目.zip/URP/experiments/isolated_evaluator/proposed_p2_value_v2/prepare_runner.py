"""Execution-disabled proposed runner: prepare ledger and bounded runtime requests.

No exec/eval/compile of candidates, no generated module import, no Wasmtime call.
This prepares a reviewable specification, not authorization to score candidates.
"""
import ast,hashlib,json,pathlib
HERE=pathlib.Path(__file__).resolve().parent
ROOT=HERE.parent
SORTING=ROOT.parent/'sorting_generation'
ALIAS='\nsolve = sort_numbers\n'
SOURCES=[('round1_raw', SORTING/'results/raw_generations.jsonl'),
         ('round2_raw', SORTING/'runs/function_completion_pilot/results/raw_generations.jsonl')]

def digest(data):
    return hashlib.sha256(data).hexdigest()

def static_gate(source):
    adapted=source+ALIAS
    if len(adapted.encode())>16384:return 'source_size_rejected'
    try:tree=ast.parse(source)
    except (SyntaxError,ValueError,RecursionError):return 'syntax_rejected'
    if len(tree.body)!=1 or not isinstance(tree.body[0],ast.FunctionDef):return 'single_function_structure_rejected'
    f=tree.body[0];a=f.args
    if not (f.name=='sort_numbers' and not f.decorator_list and len(a.args)==1 and a.args[0].arg=='values' and not a.posonlyargs and not a.kwonlyargs and a.vararg is None and a.kwarg is None and not a.defaults):
        return 'signature_rejected'
    return 'static_eligible_not_executed'

def request_spec(source,case):
    """Pure data adapter; never runs the returned source string."""
    if not case['valid'] or case['kind']!='list':
        raise ValueError('invalid-input/exception-contract fixtures are explicitly not run')
    if static_gate(source)!='static_eligible_not_executed':
        raise ValueError('source rejected by frozen static contract')
    value=case['input']
    if type(value) is not list or any(type(x) is not int for x in value):raise ValueError('bad fixture')
    inp=json.dumps(value,separators=(',',':'),ensure_ascii=True)
    if len(inp.encode())>8192:raise ValueError('input too large; never silently truncate')
    return {'source':source+ALIAS,'input_json':inp,'original_source_sha256':digest(source.encode()),
            'adapted_source_sha256':digest((source+ALIAS).encode()),'fixture_id':case['id']}

def execute_candidates(*args,**kwargs):
    raise RuntimeError('Execution disabled. Independent review and a separately reviewed operational runner are required.')

def main():
    config=json.loads((HERE/'protocol.json').read_text())
    if config.get('execution_gate')!='requires_external_matching_freeze_and_explicit_parent_approval':raise RuntimeError('unexpected proposal gate')
    fixture_path=SORTING/'fixtures/cases.json';cases=json.loads(fixture_path.read_text())
    if len(cases)!=72 or sum(c['valid'] for c in cases)!=60:raise RuntimeError('fixture contract changed')
    fixture_plan=[]
    for c in cases:
        fixture_plan.append({'id':c['id'],'kind':c['kind'],'valid':c['valid'],
            'value_score_applicability':'eligible_pending_execution' if c['valid'] else 'not_run_untrusted_exception_observation',
            'tuple_materialization_supported':False if c['kind']=='tuple' else None,
            'legacy_semantic_checks':'not_scored_guest_claims_untrusted',
            'input_sha256':digest(json.dumps(c,sort_keys=True,separators=(',',':')).encode())})
    primary=[];secondary=[];source_manifests=[]
    for round_name,path in SOURCES:
        data=path.read_bytes();source_manifests.append({'round':round_name,'path':str(path.relative_to(ROOT.parent)),'sha256':digest(data)})
        for line in data.decode().splitlines():
            r=json.loads(line);s=r['candidate_source']
            row={'id':r['id'],'round':round_name,'prompt_id':r['prompt_id'],'seed':r['seed'],
                 'source_sha256':digest(s.encode()),'source_bytes':len(s.encode()),'source_selector':'candidate_source',
                 'adapted_source_sha256':digest((s+ALIAS).encode()),'static_gate':static_gate(s),
                 'execution_status':'not_run_protocol_unapproved','eligible_fixture_count':60,'unsupported_fixture_count':12}
            primary.append(row)
            if round_name=='round2_raw':
                extracted=r['extraction']['source']
                secondary.append({**row,'source_selector':'extraction.source','round':'round2_extracted_secondary',
                    'source_sha256':digest(extracted.encode()),'source_bytes':len(extracted.encode()),
                    'adapted_source_sha256':digest((extracted+ALIAS).encode()),'static_gate':static_gate(extracted),
                    'execution_status':'not_run_secondary_scope_unapproved'})
    if len(primary)!=32 or len(secondary)!=10:raise RuntimeError('candidate record population changed')
    plan={'protocol_id':config['protocol_id'],'execution_enabled':False,'fixture_sha256':digest(fixture_path.read_bytes()),
          'source_manifests':source_manifests,'distinct_candidate_records':32,'primary_raw_variants':primary,
          'secondary_extracted_variants':secondary,'fixtures':fixture_plan,'candidates_executed':0}
    (HERE/'prepared_plan.json').write_text(json.dumps(plan,indent=2))
    freeze={p.name:digest(p.read_bytes()) for p in [HERE/'protocol.json',HERE/'prepare_runner.py',HERE/'prepared_plan.json',ROOT/'build/trusted_clean_manifest.json']}
    (HERE/'proposal_freeze.json').write_text(json.dumps({'sha256':freeze,'state':'pending_independent_review'},indent=2))
    print(json.dumps({'primary_records':len(primary),'secondary_variants':len(secondary),'eligible_fixtures':60,'explicitly_not_run_fixtures':12,'candidates_executed':0,'primary_static_eligible':sum(x['static_gate']=='static_eligible_not_executed' for x in primary),'secondary_static_eligible':sum(x['static_gate']=='static_eligible_not_executed' for x in secondary)}))
if __name__=='__main__':main()
