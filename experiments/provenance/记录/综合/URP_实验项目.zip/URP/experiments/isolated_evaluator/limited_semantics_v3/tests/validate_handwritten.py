"""Handwritten-only Wasm validation. No generated source file is read or executed."""
import hashlib,json,pathlib,sys,time,resource
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'));sys.path.insert(0,str(ROOT/'tests'))
from one_request import launch
from host_checker import check_payload
from handwritten_programs import REFERENCE,REJECTED,SEMANTIC
OUT=ROOT/'results/handwritten_validation'
CPU_CAP=600;WALL_CAP=900

def digest(s):return hashlib.sha256(s.encode()).hexdigest()

def descriptor(case):
    kind=case['kind']
    if kind=='identity':kind={dict:'dict',bool:'bool',int:'int',float:'float',str:'str',type(None):'none'}[type(case['input'])]
    return json.dumps({'kind':kind,'value':case['input'],'valid_fixture':case['valid']},separators=(',',':'),ensure_ascii=True,allow_nan=False)

def request(source,raw):return {'source':source,'source_sha256':digest(source),'input_json':raw,'input_sha256':digest(raw)}

def clean(o):
    return o['returncode']==0 and o['termination'] is None and not o['protocol_error'] and not o['supervisor_error'] and not o['worker_unreaped'] and o['guest_entry_observed'] is True

def main():
    OUT.mkdir(exist_ok=False);start=time.monotonic();self_cpu=time.process_time();cpu=0;rows=[];calls=0
    def run(name,source,case,expect,raw=None):
        nonlocal cpu,calls
        if CPU_CAP-cpu<2 or WALL_CAP-(time.monotonic()-start)<6:raise RuntimeError('handwritten test budget exhausted')
        spec=request(source,descriptor(case) if raw is None else raw)
        with (OUT/'events.jsonl').open('a') as f:f.write(json.dumps({'event':'start','name':name,'cpu_before':cpu,'elapsed_before':time.monotonic()-start})+'\n')
        o=launch(spec);calls+=1;cpu+=o['worker_user_seconds']+o['worker_sys_seconds']
        filename=f'{calls:04d}.json';(OUT/filename).write_text(json.dumps(o,indent=2,allow_nan=False))
        w=o.get('worker') or {};p=w.get('payload')
        passed=clean(o) and expect(w,p,case)
        row={'name':name,'passed':passed,'source':source,'source_sha256':spec['source_sha256'],'input_json':spec['input_json'],'input_sha256':spec['input_sha256'],'observation':filename,'worker_status':w.get('status'),'payload':p,'cpu_seconds':o['worker_user_seconds']+o['worker_sys_seconds'],'wall_seconds':o['wall_seconds']}
        rows.append(row)
        with (OUT/'events.jsonl').open('a') as f:f.write(json.dumps({'event':'complete','row':row},allow_nan=False)+'\n')
        if not clean(o):raise RuntimeError('unclean handwritten transport '+name)
        return row
    cases=json.loads((ROOT.parent.parent/'sorting_generation/fixtures/cases.json').read_text())
    # All original 72 descriptors, including real tuple materialization, use the
    # same manually written reference and independent host oracle.
    for case in cases:run('reference/'+case['id'],REFERENCE,case,lambda w,p,c:w['status']=='returned' and check_payload(p,c))
    one={'id':'manual_one','kind':'list','input':[1],'valid':True,'expected':[1]}
    empty={'id':'manual_empty','kind':'list','input':[],'valid':True,'expected':[]}
    for name,source in REJECTED.items():run('rejected/'+name,source,one,lambda w,p,c:w['status']=='returned' and p=={'stage':'source_rejected','reason':'unsupported_language'})
    expectations={
      'wrong_value':lambda p:p['result']==[999] and not check_payload(p,one),
      'exact_type_error':lambda p:p['invocation']=='exact_type_error',
      'other_exception':lambda p:p['invocation']=='other_exception',
      'implicit_none':lambda p:p['invocation']=='returned' and p['result_shape_valid'] is False,
      'same_object':lambda p:p['returned_same_object'] is True and p['final_input_unchanged'] is True,
      'mutate_new_return':lambda p:p['returned_same_object'] is False and p['final_input_unchanged'] is False,
      'bool_int_mutation':lambda p:p['final_input_unchanged'] is False,
      'local_rebind':lambda p:p['returned_same_object'] is False and p['final_input_unchanged'] is True,
      # This intentionally passes final-state checks despite transient writes.
      'restore_mutation':lambda p:check_payload(p,one),
      'cyclic_result':lambda p:p['result_shape_valid'] is False,
      'cyclic_input':lambda p:p['final_input_unchanged'] is False,
      'deep_result':lambda p:p['result_shape_valid'] is False,
      'oversize_result':lambda p:p['result_shape_valid'] is False,
      'oversize_input':lambda p:p['final_input_unchanged'] is False,
      'huge_int_result':lambda p:p['result_shape_valid'] is False,
      'huge_int_input':lambda p:p['final_input_unchanged'] is False,
    }
    for name,test in expectations.items():run('semantic/'+name,SEMANTIC[name],one,lambda w,p,c,test=test:w['status']=='returned' and p['stage']=='candidate_completed' and test(p))
    run('resource/fuel_loop',SEMANTIC['fuel_loop'],empty,lambda w,p,c:w['status']=='trapped' and w.get('fuel_remaining')==0)
    run('resource/guest_memory_growth',SEMANTIC['guest_memory_growth'],empty,lambda w,p,c:w['status']=='trapped' or (w['status']=='returned' and p['stage']=='candidate_completed' and p['invocation']=='other_exception'))
    # Malformed evaluator input must never be mistaken for a candidate TypeError.
    run('phase/setup_type_error_is_not_candidate',SEMANTIC['exact_type_error'],one,lambda w,p,c:p=={'stage':'setup_error'},raw='{"kind":"tuple","value":1,"valid_fixture":false}')
    run('phase/source_reject_is_not_candidate',REJECTED['default'],one,lambda w,p,c:p=={'stage':'source_rejected','reason':'unsupported_language'},raw=descriptor({'kind':'identity','input':7,'valid':False}))
    # Calibrate the entire valid response (including scalar byte transport) at the
    # exact 8192-byte cap without enlarging any protocol limit.
    expected_payload={'stage':'candidate_completed','invocation':'returned','result_shape_valid':True,'result':[], 'returned_same_object':False,'final_input_unchanged':True,'valid_fixture':True}
    fixed=len(json.dumps(expected_payload,sort_keys=True,separators=(',',':')).encode())
    count=500;digits_needed=8192-fixed-(count-1)
    width,remainder=divmod(digits_needed,count)
    numbers=[10**(width-1)]*(count-remainder)+[10**width]*remainder
    boundary={'id':'manual_max_response','kind':'list','input':numbers,'valid':True,'expected':sorted(numbers)}
    expected_payload['result']=boundary['expected']
    if len(json.dumps(expected_payload,sort_keys=True,separators=(',',':')).encode())!=8192:raise ValueError('boundary construction')
    run('boundary/full_8192_response',REFERENCE,boundary,lambda w,p,c:w['status']=='returned' and check_payload(p,c))
    larger=list(numbers);larger[0]=10**width
    if remainder==count:raise ValueError('unexpected boundary width')
    over={'id':'manual_oversize_response','kind':'list','input':larger,'valid':True,'expected':sorted(larger)}
    run('boundary/8193_response_rejected',REFERENCE,over,lambda w,p,c:w['status']=='output_rejected' and w.get('advertised_length')==0xFFFFFFFD)
    report={'protocol_id':'urp-p2-limited-language-final-state-v3-handwritten-20261004','generated_candidates_executed':0,'calls':calls,'all_passed':all(r['passed'] for r in rows),'passed':sum(r['passed'] for r in rows),'failed':[r['name'] for r in rows if not r['passed']], 'original_reference_fixtures':72,'rows':rows,'worker_cpu_seconds':cpu,'supervisor_cpu_seconds':time.process_time()-self_cpu,'wall_seconds':time.monotonic()-start,'supervisor_peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'supervisor_rlimit_as':resource.getrlimit(resource.RLIMIT_AS),'budgets':{'worker_cpu_seconds':CPU_CAP,'wall_seconds':WALL_CAP},'budget_overshoot':{'cpu':max(0,cpu-CPU_CAP),'wall':max(0,time.monotonic()-start-WALL_CAP)}}
    (OUT/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False));print(json.dumps({k:v for k,v in report.items() if k!='rows'}))
    if not report['all_passed']:raise RuntimeError('handwritten validation failures')

if __name__=='__main__':main()
