"""Candidate-free operational tests. Only literal handwritten functions execute."""
import hashlib,json,pathlib,resource,subprocess,sys,time
from batch_runner import run_forms,run_one,make_request,verify_approval,verify_freeze,complete_ledger,summarize,classify_observation
from one_request import worker_limits
from prepare_runner import request_spec
HERE=pathlib.Path(__file__).resolve().parent;ROOT=HERE.parent
label=sys.argv[1] if len(sys.argv)>1 else 'initial'
if not label.replace('_','').isalnum():raise ValueError('bad validation label')
OUT=HERE/('handwritten_validation_'+label)
REFERENCE='def sort_numbers(values):\n    return sorted(values)\n'

def form(name,source):return {'form_id':'handwritten/'+name,'candidate_id':name,'round':'handwritten','prompt_id':'diagnostic','variant':'raw','source':source}
def case(value):return {'id':'handwritten_case','kind':'list','valid':True,'input':value,'expected':sorted(value)}
def execute(source,c=case([3,1])):return run_one(make_request(source,c))
def expect_status(name,source,expected,c=case([3,1])):
    obs=execute(source,c);status=(obs.get('worker') or {}).get('status')
    if status!=expected:raise AssertionError((name,status,expected,obs))
    return {'name':name,'observation':obs}

def main():
    OUT.mkdir(exist_ok=False)
    all_cases=json.loads((ROOT.parent/'sorting_generation/fixtures/cases.json').read_text())
    reference=run_forms([form('reference',REFERENCE)],all_cases,{'raw'},output_dir=OUT/'reference_60')
    if reference['groups'][0]['passed']!=1 or reference['calls']!=60:raise AssertionError('reference coverage failed')
    if sum(r['status']=='not_run_unsupported_contract' for r in reference['rows'])!=12:raise AssertionError('invalid fixtures lost')
    details=[]
    for name,source,c in [('bool_elements','def sort_numbers(values):\n    return [True]\n',case([1])),
                          ('float_elements','def sort_numbers(values):\n    return [1.0]\n',case([1])),
                          ('false_scalar','def sort_numbers(values):\n    return False\n',case([1])),
                          ('wrong_values','def sort_numbers(values):\n    return [99]\n',case([1]))]:
        r=run_forms([form(name,source)],[c],{'raw'})
        if r['groups'][0]['observed_nonconformant']!=1:raise AssertionError(name)
        details.append({'name':name,'report':r})
    malformed='def sort_numbers(values):\n    import json\n    json.dumps = lambda *a, **k: "not-json"\n    return values\n'
    details.append(expect_status('malformed_json',malformed,'trapped'))
    oversized='def sort_numbers(values):\n    import json\n    import trusted_guest as g\n    g._MAX_OUTPUT = 100000\n    json.dumps = lambda *a, **k: "x" * 65536\n    return values\n'
    details.append(expect_status('oversized_claim',oversized,'output_rejected'))
    byte='def sort_numbers(values):\n    import trusted_guest as g\n    g.WitWorld.output_byte = lambda self, i: 256\n    return values\n'
    details.append(expect_status('invalid_scalar_byte',byte,'trapped'))
    spoof='def sort_numbers(values):\n    import json\n    fake = json.dumps({"ok": True, "result": sorted(values)})\n    json.dumps = lambda *a, **k: fake\n    return [999]\n'
    r=run_forms([form('wrong_python_return_spoofer',spoof)],[case([3,1])],{'raw'})
    if r['groups'][0]['passed']!=1:raise AssertionError('expected mutable-wrapper limitation not demonstrated')
    details.append({'name':'wrong_python_return_spoofer','report':r,'interpretation':'Observable response conforms although handwritten Python return is [999]; this is a demonstrated limitation, not a model result'})
    for name,mutator in [('corrupt_source_hash',lambda r:r.update(source_sha256='0'*64)),
                         ('decoded_source_oversize',lambda r:r.update(source='x'*16385,source_sha256=hashlib.sha256(('x'*16385).encode()).hexdigest()))]:
        req=make_request(REFERENCE,case([1]));mutator(req);obs=run_one(req)
        if (obs.get('worker') or {}).get('status')!='initialization_or_request_error' or obs['guest_entry_observed']:raise AssertionError(name)
        details.append({'name':name,'observation':obs})
    # Direct worker input rejection is before deserialization; inherited supervisor
    # allocation limit is sufficient and no generated source enters these probes.
    for name,wire in [('stdin_oversize',b'x'*65537),('malformed_request_json',b'{')]:
        p=subprocess.run([str(ROOT/'.venv/bin/python'),'-B',str(HERE/'runtime_worker.py')],input=wire,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=3,env={},preexec_fn=worker_limits)
        d=json.loads(p.stdout)
        if p.returncode!=2 or d.get('status')!='initialization_or_request_error':raise AssertionError(name)
        if name=='stdin_oversize' and d.get('error')!='stdin too large':raise AssertionError('wrong stdin rejection reason')
        if name=='malformed_request_json' and d.get('error_type')!='JSONDecodeError':raise AssertionError('wrong malformed JSON reason')
        details.append({'name':name,'returncode':p.returncode,'worker':d})
    calls=[]
    exhausted=run_forms([form('reference',REFERENCE)],all_cases,{'raw'},executor=lambda request:calls.append(request),cpu_budget=1.9,wall_budget=900)
    if calls or exhausted['calls'] or exhausted['groups'][0]['incomplete_unknown']!=1 or exhausted['groups'][0]['pass_fraction'] is not None:raise AssertionError('budget stop ledger failed')
    details.append({'name':'reserve_budget_stop','report':exhausted})
    wall=run_forms([form('reference',REFERENCE)],all_cases,{'raw'},executor=lambda request:calls.append(request),cpu_budget=600,wall_budget=5.9)
    if calls or wall['calls'] or wall['groups'][0]['pass_fraction'] is not None:raise AssertionError('wall reservation failed')
    details.append({'name':'wall_reserve_stop','report':wall})
    try:verify_approval({'explicit_parent_batch_authorization':True,'scope':'raw_only','operational_freeze_sha256':'wrong'},'expected')
    except PermissionError:details.append({'name':'corrupt_approval_hash','rejected':True})
    else:raise AssertionError('approval hash accepted')
    try:verify_approval({'explicit_parent_batch_authorization':False},'expected')
    except PermissionError:details.append({'name':'missing_parent_authorization','rejected':True})
    else:raise AssertionError('missing parent authorization accepted')
    for name,bad_json in [('nonstandard_nan','{"ok":true,"result":[1],"ignored":NaN}'),('duplicate_keys','{"ok":true,"result":[1],"result":[1]}'),('overflowing_float','{"ok":true,"result":[1],"ignored":1e9999}')]:
        source='def sort_numbers(values):\n    import json\n    json.dumps = lambda *a, **k: '+repr(bad_json)+'\n    return [1]\n'
        details.append(expect_status(name,source,'trapped',case([1])))
    good={'returncode':0,'termination':None,'protocol_error':False,'guest_entry_observed':True,'worker_unreaped':False,'supervisor_error':None,
          'worker_user_seconds':0.1,'worker_sys_seconds':0,'worker':{'status':'returned','payload':{'ok':True,'result':[1]}}}
    for name,updates in [('nonzero_with_correct_payload',{'returncode':1}),('malformed_transport',{'protocol_error':True}),
                         ('preentry_with_correct_payload',{'guest_entry_observed':False}),('missing_worker',{'worker':None})]:
        fake=good|updates;status,ok,_=classify_observation(fake,[1])
        if status!='infrastructure_error' or ok is not None:raise AssertionError(name)
        details.append({'name':name,'rejected_as_infrastructure':True})
    def fake_pass(req,cpu=2.0):
        value=sorted(json.loads(req['input_json']))
        return good|{'worker_user_seconds':cpu,'worker':{'status':'returned','payload':{'ok':True,'result':value}}}
    mid=run_forms([form('reference',REFERENCE)],all_cases,{'raw'},executor=fake_pass,cpu_budget=2.5,wall_budget=900)
    if mid['calls']!=1 or sum(r['status']=='not_run_budget_exhausted' for r in mid['rows'])!=59 or mid['groups'][0]['pass_fraction'] is not None:raise AssertionError('mid CPU stop')
    details.append({'name':'mid_cpu_stop','report':mid})
    now=[0.0]
    def advancing(req):now[0]+=2;return fake_pass(req,0.1)
    midwall=run_forms([form('reference',REFERENCE)],all_cases,{'raw'},executor=advancing,cpu_budget=600,wall_budget=7,clock=lambda:now[0])
    if midwall['calls']!=1 or midwall['groups'][0]['incomplete_unknown']!=1:raise AssertionError('mid wall stop')
    details.append({'name':'mid_wall_stop','report':midwall})
    over=run_forms([form('reference',REFERENCE)],all_cases,{'raw'},executor=lambda req:fake_pass(req,2.05),cpu_budget=2,wall_budget=900)
    if abs(over['accounting_overshoot']['worker_cpu_seconds']-0.05)>1e-9:raise AssertionError('overshoot accounting')
    details.append({'name':'accounting_overshoot','report':over})
    for row in reference['rows']:
        if row['status']=='response_conformant':
            limits=row['observation_summary']['worker_effective_rlimits']
            if limits['as'] not in ([8589934592,8589934592],(8589934592,8589934592)) or limits['cpu'] not in ([2,2],(2,2)):raise AssertionError('worker rlimits')
    if resource.getrlimit(resource.RLIMIT_AS)!=(134217728,8589934592):raise AssertionError('supervisor rlimits')
    summary={'reference_valid_cases_passed':60,'unsupported_original_cases_preserved':12,'other_diagnostics':len(details),
             'generated_candidates_executed':0,'supervisor_effective_rlimit_as':resource.getrlimit(resource.RLIMIT_AS),
             'all_expected_checks_passed':True,'observable_response_is_not_python_return_proof':True}
    (OUT/'details.json').write_text(json.dumps(details,indent=2));(OUT/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary))
if __name__=='__main__':main()
