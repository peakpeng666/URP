"""Import only reviewed trusted v3 modules; candidate bytes remain data."""
import pathlib
import sys
HERE = pathlib.Path(__file__).resolve().parents[1]
EVALUATOR = HERE.parent
V3 = EVALUATOR / 'operational_v3'
sys.path.insert(0, str(V3))
import adapter as v3_adapter
import batch_runner as v3_batch
import checker as v3_checker
import integrity as v3_integrity
import one_request as v3_request
V3_DIGEST = 'b5a8612f0e8b71ee051eb530ae171f5798794404eac7ccdfa5c1be59b2687d8a'
PROTOTYPE_DIGEST = '0cf4954262d10470a4dc49fda11b305b74ba0ff2bc8fd61f30810f20f5435dfd'
admission = v3_adapter.admission
digest = v3_adapter.digest
make_request = v3_adapter.make_request
classify = v3_checker.classify
bounded_json = v3_integrity.bounded_json
strict_json = v3_integrity.strict_json
file_hash = v3_integrity.file_hash
run_one = v3_batch.run_one
execution_metadata = v3_batch.execution_metadata
compact = v3_batch.compact
journal = v3_batch.journal
