"""Handwritten diagnostic inputs, not generated model candidates or benchmarks."""
PROBES = {
 'sort': {'source': 'def solve(x):\n    return sorted(x)\n', 'input': [3, -1, 3, 0], 'expected_result': [-1, 0, 3, 3]},
 'mutate': {'source': 'def solve(x):\n    x.sort()\n    return x\n', 'input': [3, -1, 3, 0]},
 'read_host_file': {'source': 'def solve(x):\n    return open("/etc/passwd").read()\n', 'input': None},
 'write_host_file': {'source': 'def solve(x):\n    return open("/tmp/urp_isolation_probe_DO_NOT_CREATE", "w").write("probe")\n', 'input': None},
 'read_build_mount': {'source': 'def solve(x):\n    return open("/0/trusted_guest.py").read()\n', 'input': None},
 'read_host_environ': {'source': 'def solve(x):\n    import os\n    return dict(os.environ)\n', 'input': None},
 'subprocess': {'source': 'def solve(x):\n    import os\n    return os.system("true")\n', 'input': None},
 'fork': {'source': 'def solve(x):\n    import os\n    return os.fork()\n', 'input': None},
 'network': {'source': 'def solve(x):\n    import socket\n    return str(socket.socket())\n', 'input': None},
 'javascript': {'source': 'def solve(x):\n    import js\n    return str(js.globalThis)\n', 'input': None},
 'infinite_loop': {'source': 'def solve(x):\n    while True:\n        pass\n', 'input': None},
 'huge_allocation': {'source': 'def solve(x):\n    return "x" * (1024 * 1024 * 1024)\n', 'input': None},
 'stdout_flood': {'source': 'def solve(x):\n    while True:\n        print("x" * 10000)\n', 'input': None},
 'oversized_result': {'source': 'def solve(x):\n    return list(range(10000))\n', 'input': None},
 'falsify_length': {'source': 'def solve(x):\n    import trusted_guest as g\n    import json\n    g._MAX_OUTPUT = 100000\n    json.dumps = lambda *a, **k: "x" * 65536\n    return 1\n', 'input': None},
 'out_of_range_byte': {'source': 'def solve(x):\n    import trusted_guest as g\n    g.WitWorld.output_byte = lambda self, i: 256\n    return 42\n', 'input': None},
 'poison_builtins': {'source': 'def solve(x):\n    import builtins\n    builtins._urp_probe_poison = 1\n    return 42\n', 'input': None, 'expected_result': 42},
 'check_fresh': {'source': 'def solve(x):\n    import builtins\n    return hasattr(builtins, "_urp_probe_poison")\n', 'input': None, 'expected_result': False},
 'spoof_guest_claims': {'source': 'def solve(x):\n    import json\n    json.dumps = lambda *a, **k: \'{"ok":true,"result":[-1,0,3,3],"guest_claim_same_object":false,"guest_claim_input_unchanged":true}\'\n    x.sort()\n    return x\n', 'input': [3, -1, 3, 0]},
}

# Explicit boundary-size probes, added after initial diagnostic matrix.
PROBES['max_valid_output'] = {'source': 'def solve(x):\n    return {"blob": "x" * 8093}\n', 'input': None, 'expected_result': {'blob': 'x' * 8093}}
PROBES['one_byte_oversize'] = {'source': 'def solve(x):\n    return {"blob": "x" * 8094}\n', 'input': None}
