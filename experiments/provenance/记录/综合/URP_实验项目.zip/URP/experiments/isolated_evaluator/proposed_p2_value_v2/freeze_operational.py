"""Freeze operational inputs for review; never executes candidates."""
import hashlib,json,pathlib
HERE=pathlib.Path(__file__).resolve().parent;ROOT=HERE.parent

def hash_file(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
files={}
for p in HERE.glob('*.py'):files[str(p.relative_to(ROOT))]=hash_file(p)
for p in [HERE/'protocol.json',HERE/'prepared_plan.json',ROOT/'src/host_checker.py',ROOT/'src/runtime_config.py',
          ROOT/'src/guest/trusted_guest.py',ROOT/'src/guest/evaluator.wit',ROOT/'requirements.lock.txt',
          ROOT/'build/trusted_clean_manifest.json',ROOT/'build/evaluator_clean.wasm',ROOT/'build/evaluator_clean.cwasm',
          ROOT/'provenance/dependencies.json',ROOT/'provenance/clean_build_config.json',ROOT/'provenance/clean_build_inputs.json']:
    files[str(p.relative_to(ROOT))]=hash_file(p)
dependencies=[]
for p in sorted((ROOT/'.venv').rglob('*')):
    if p.is_file():
        rel=str(p.relative_to(ROOT));files[rel]=hash_file(p);dependencies.append(rel)
for rel in ['../sorting_generation/fixtures/cases.json','../sorting_generation/results/raw_generations.jsonl',
            '../sorting_generation/runs/function_completion_pilot/results/raw_generations.jsonl']:
    files[rel]=hash_file(ROOT/rel)
plan=json.loads((HERE/'prepared_plan.json').read_text())
result={'protocol_id':json.loads((HERE/'protocol.json').read_text())['protocol_id'],'state':'frozen_for_final_review_no_batch_authorization',
        'files':dict(sorted(files.items())),'dependency_files':sorted(dependencies),
        'source_forms':{'primary_raw':[{k:r[k] for k in ('id','round','source_sha256','adapted_source_sha256')} for r in plan['primary_raw_variants']],
                        'secondary_extracted':[{k:r[k] for k in ('id','round','source_sha256','adapted_source_sha256')} for r in plan['secondary_extracted_variants']]},
        'operational_python_files':sorted(str(p.relative_to(ROOT)) for p in HERE.glob('*.py')),
        'approval_scopes':{'raw_only':'32 original raw records only; secondary ledger remains scope-unapproved',
                           'raw_and_existing_extracted':'32 raw forms plus10 existing extracted secondary variants; not42 independent candidates'},
        'fixture_count':72,'scored_valid_fixtures':60,'unsupported_invalid_fixtures':12,'generated_candidates_executed':0}
path=HERE/'operational_freeze.json'
if path.exists():raise FileExistsError(path)
path.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'files':len(files),'dependency_files':len(dependencies),'freeze_sha256':hash_file(path),'generated_candidates_executed':0}))
