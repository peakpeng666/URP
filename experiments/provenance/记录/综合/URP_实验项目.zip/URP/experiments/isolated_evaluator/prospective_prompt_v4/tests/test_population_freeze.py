"""Synthetic generation records only; validates data freeze and no source repair."""
import copy
import json
import pathlib
import sys
import tempfile
import unittest
HERE=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE/'src'))
from v3_reuse import digest
from generation_integrity import jobs
from freeze_population import derive_forms
from evaluate_population import load_forms
from extract import extract_initial_function

class FreezePopulationTests(unittest.TestCase):
    def fixture(self,root,complete=10):
        config=json.loads((HERE/'generation_config.json').read_text());planned=jobs(config);slots=[];records=[]
        (root/'sources').mkdir()
        for job in planned:
            slot={**job,'state':'not_started','raw_record_line':None}
            if job['slot']<complete:
                prompt=(HERE/config['prompts'][job['prompt_id']]).read_text();continuation='    return sorted(values)\n'
                source=prompt+continuation;extraction=extract_initial_function(source)
                raw=f"sources/{job['id']}.raw.txt";ex=f"sources/{job['id']}.extracted.txt"
                (root/raw).write_text(source);(root/ex).write_text(extraction['source'])
                records.append({**job,'status':'generated','prompt':prompt,'continuation':continuation,
                                'candidate_source':source,'extraction':extraction,'candidate_source_sha256':digest(source.encode()),
                                'extracted_source_sha256':digest(extraction['source'].encode()),'raw_source_path':raw,'extracted_source_path':ex})
                slot.update(state='complete',raw_record_line=len(records))
            slots.append(slot)
        ledger={'batch_id':'manual','preparation_freeze_sha256':'a'*64,'generation_retry_count':0,
                'generated_code_executed':False,'journal_integrity':True,'slots':slots}
        status={'integrity_before':'passed','integrity_after':'passed','cleanup_complete':True,'journal_integrity':True,
                'batch_id':'manual','preparation_freeze_sha256':'a'*64}
        (root/'generation_ledger.json').write_text(json.dumps(ledger));(root/'process_status.json').write_text(json.dumps(status))
        (root/'raw_generations.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in records))
        return config,ledger,status,records

    def test_exact_ten_selected_and_no_alias(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=pathlib.Path(tmp);config,*_=self.fixture(root)
            forms=derive_forms(root,'a'*64,config)
            self.assertEqual(len(forms),10);self.assertTrue(all(f['generation_status']=='generated' for f in forms))
            self.assertTrue(all('solve =' not in f['source'] for f in forms))
            self.assertEqual(load_forms({'forms':forms}),forms)

    def test_certified_partial_retains_all_slots(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=pathlib.Path(tmp);config,*_=self.fixture(root,complete=2)
            forms=derive_forms(root,'a'*64,config)
            self.assertEqual(len(forms),10);self.assertEqual(sum(f['generation_status']=='generated' for f in forms),2)
            self.assertTrue(all(f['source']=='' and f['source_sha256'] is None for f in forms[2:]))

    def test_interrupted_durable_generated_record_remains_unknown(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=pathlib.Path(tmp);config,ledger,_,_=self.fixture(root,complete=2)
            ledger['slots'][1]['state']='interrupted'
            (root/'generation_ledger.json').write_text(json.dumps(ledger))
            forms=derive_forms(root,'a'*64,config)
            self.assertEqual(forms[1]['generation_status'],'interrupted')
            self.assertEqual(forms[1]['source'],'')
            self.assertIsNone(forms[1]['source_sha256'])
            self.assertEqual(sum(f['generation_status']=='generated' for f in forms),1)

    def test_uncertified_cleanup_or_integrity_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=pathlib.Path(tmp);config,ledger,status,_=self.fixture(root)
            for key,value in [('integrity_after','unknown'),('cleanup_complete',False),('journal_integrity',False)]:
                broken={**status,key:value};(root/'process_status.json').write_text(json.dumps(broken))
                with self.subTest(key=key),self.assertRaises(ValueError):derive_forms(root,'a'*64,config)

    def test_changed_extraction_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=pathlib.Path(tmp);config,_,_,records=self.fixture(root)
            records[0]['extraction']['source']+='\n# changed'
            (root/'raw_generations.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in records))
            with self.assertRaisesRegex(ValueError,'extraction'):derive_forms(root,'a'*64,config)

    def test_changed_prompt_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=pathlib.Path(tmp);config,_,_,records=self.fixture(root)
            records[0]['prompt']+='changed'
            (root/'raw_generations.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in records))
            with self.assertRaisesRegex(ValueError,'frozen prompt'):derive_forms(root,'a'*64,config)

    def test_changed_retained_source_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=pathlib.Path(tmp);config,_,_,records=self.fixture(root)
            (root/records[0]['raw_source_path']).write_text('changed')
            with self.assertRaisesRegex(ValueError,'artifact mismatch'):derive_forms(root,'a'*64,config)

    def test_duplicate_raw_record_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=pathlib.Path(tmp);config,_,_,records=self.fixture(root,complete=2)
            records.append(records[0]);(root/'raw_generations.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in records))
            with self.assertRaisesRegex(ValueError,'duplicate'):derive_forms(root,'a'*64,config)

    def test_unapproved_population_order_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=pathlib.Path(tmp);config,*_=self.fixture(root)
            forms=derive_forms(root,'a'*64,config);forms.reverse()
            with self.assertRaisesRegex(ValueError,'order'):load_forms({'forms':forms})

if __name__=='__main__':unittest.main()
