"""One prospective source/test/model freeze; never grants generation authority."""
import argparse
import json
import os
import pathlib
import sys
from v3_reuse import HERE,EVALUATOR,V3,V3_DIGEST,file_hash,bounded_json,v3_integrity
from evaluation_integrity import source_inventory,verify_preparation
from generation_integrity import dependency_inventory


def create():
    path=HERE/'preparation_freeze.json'
    if path.exists():raise FileExistsError(path)
    antecedent=v3_integrity.verify_freeze(V3/'operational_freeze.json',V3_DIGEST)
    files,links=v3_integrity.dependency_state()
    core=set(source_inventory())|{'PROPOSAL.md','generation_config.json','evaluation_config.json','original_preservation_inventory.json','README.md'}
    for directory in ('prompts','fixtures'):
        core.update(str(p.relative_to(HERE)) for p in (HERE/directory).rglob('*') if p.is_file())
    evaluator_files={os.path.relpath(V3/rel,HERE):value for rel,value in antecedent['files'].items()}
    evaluator_files[os.path.relpath(V3/'operational_freeze.json',HERE)]=V3_DIGEST
    generation_files,generation_links=dependency_inventory(HERE)
    selected=set(generation_files)|{'../../sorting_generation/results/model_download.json',
                                     '../../sorting_generation/requirements.lock.txt'}
    generation_hashes={rel:file_hash(HERE/rel) for rel in sorted(selected)}
    proto=EVALUATOR/'limited_semantics_v3'
    manifest={'protocol_id':'urp-p2-paired-contract-prompt-v4-compat-preparation-20261004',
              'original_preparation_freeze_sha256':'0ecf0ade247065f7ed38a948082383d093d485bfb1e621add32dfb8096dbf0ab',
              'state':'frozen_preparation_no_generation_or_evaluation_authorization',
              'v3_operational_sha256':V3_DIGEST,
              'source_inventory':source_inventory(),
              'v3_source_inventory':v3_integrity.source_inventory(),
              'prototype_source_inventory':sorted(str(p.relative_to(proto)) for d in ('src','tests') for p in (proto/d).rglob('*.py')),
              'evaluator_dependency_files':files,'evaluator_dependency_symlinks':links,
              'generation_dependency_files':generation_files,'generation_dependency_symlinks':generation_links,
              'core_files':{rel:file_hash(HERE/rel) for rel in sorted(core)},
              'evaluator_files':dict(sorted(evaluator_files.items())),
              'generation_files':generation_hashes}
    with path.open('x') as stream:json.dump(manifest,stream,indent=2);stream.write('\n')
    digest=file_hash(path);verify_preparation(path,digest)
    return {'preparation_freeze_sha256':digest,'core_files':len(core),'evaluator_files':len(evaluator_files),
            'generation_files':len(generation_hashes),'generation_dependency_inventory':len(generation_files)}


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--create',action='store_true');parser.add_argument('--verify',metavar='EXPECTED_SHA256')
    args=parser.parse_args()
    if args.create and not args.verify:print(json.dumps(create()))
    elif args.verify and not args.create:
        f=verify_preparation(HERE/'preparation_freeze.json',args.verify)
        print(json.dumps({'verified':True,'preparation_freeze_sha256':args.verify,'core_files':len(f['core_files'])}))
    else:raise SystemExit('choose exactly --create or --verify EXPECTED_SHA256')

if __name__=='__main__':main()
