"""Fixed candidate-free build input for limited-language v3 measurements.

Wasm is the host capability boundary; closed grammar protects measurement
integrity only. Candidate source is never imported or componentized on the host.
"""
import wit_world
from semantic_evaluator import evaluate, serialize
_OUTPUT=b''
_MAX_OUTPUT=8192

class WitWorld(wit_world.WitWorld):
    def run(self,source:str,input_json:str)->int:
        global _OUTPUT
        _OUTPUT=b''
        if len(source.encode('utf-8'))>16384 or len(input_json.encode('utf-8'))>8192:return 0xFFFFFFFE
        response=evaluate(source,input_json)
        try:payload=serialize(response)
        except BaseException:payload=b'{"stage":"serialization_error"}'
        if len(payload)>_MAX_OUTPUT:return 0xFFFFFFFD
        _OUTPUT=payload
        return len(payload)

    def output_byte(self,index:int)->int:
        if index>=len(_OUTPUT) or index>=_MAX_OUTPUT:return 0xFFFFFFFF
        return _OUTPUT[index]
