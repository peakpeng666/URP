"""Fresh-process compatibility for the pinned, trusted, weights-only CodeGen load.

All model/venv bytes MUST be verified against the preparation freeze before entry.
No registry addition, unsafe deserializer, online fallback or model generation.
"""
from contextlib import contextmanager
import importlib
import importlib.metadata
import os
from pathlib import Path
import platform
import sys

from generation_integrity import ROOT, sha256_file

TRUSTED_IMPORTS = (
    "torch",
    "torch.distributed.distributed_c10d",
    "torch.nested",
    "torch._dynamo",
    "torch.distributed.device_mesh",
    "torch.distributed.tensor",
    "torch.distributed._serialization",
    "transformers.models.codegen.modeling_codegen",
    "transformers.models.codegen.tokenization_codegen",
    "transformers.models.auto.modeling_auto",
    "transformers.models.auto.tokenization_auto",
    "transformers.trainer_utils",
)
OFFICIAL_WEIGHT_SHA256 = "90e20f4887289739a435452f26974d97937adb41485f9c1a7b3d3810aac6773d"


def require_empty_registry(torch, phase):
    if torch.serialization.get_safe_globals():
        raise RuntimeError("Extra user unpickler globals are prohibited: " + phase)


def registry_names(torch):
    """Diagnostic names only. These objects are never accepted by the unpickler."""
    result = []
    for value in torch.serialization.get_safe_globals():
        if isinstance(value, tuple):
            obj, registered_name = value
            result.append({"object": obj.__module__ + "." + obj.__qualname__,
                           "registered_name": registered_name})
        else:
            result.append({"object": value.__module__ + "." + value.__qualname__})
    return sorted(result, key=lambda value: (value["object"], value.get("registered_name", "")))


def verify_runtime_metadata(config):
    if platform.python_version() != config["environment"]["python"] or platform.python_implementation() != "CPython":
        raise RuntimeError("Frozen CPython version mismatch")
    versions = {name: importlib.metadata.version(name) for name in config["environment"]["versions"]}
    if versions != config["environment"]["versions"]:
        raise RuntimeError("Frozen generation package versions mismatch")
    if (not sys.flags.dont_write_bytecode or os.environ.get("TORCH_FORCE_WEIGHTS_ONLY_LOAD") != "1"
            or os.environ.get("HF_HUB_OFFLINE") != "1" or os.environ.get("TRANSFORMERS_OFFLINE") != "1"):
        raise RuntimeError("Fresh bytecode-disabled, forced weights-only offline process required")
    return versions


def import_trusted_runtime(journal):
    # A reused process could contain externally registered globals. Never erase them.
    if any(name == "torch" or name.startswith("torch.") or name == "transformers"
           or name.startswith("transformers.") for name in sys.modules):
        raise RuntimeError("Trusted runtime imports require a fresh process")
    modules = {}
    imports = []
    for name in TRUSTED_IMPORTS:
        module = importlib.import_module(name)
        modules[name] = module
        path = Path(module.__file__).resolve()
        trusted_root = (ROOT / "../../sorting_generation/.venv").resolve()
        if not path.is_relative_to(trusted_root):
            raise RuntimeError("Trusted import resolved outside the verified venv: " + name)
        entry = {"module": name, "file": str(path),
                 "registered_globals": registry_names(modules["torch"])}
        imports.append(entry)
        journal.event("trusted_import_completed", **entry)
    torch = modules["torch"]
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    before = registry_names(torch)
    journal.event("official_import_registry_before_clear", registered_globals=before)
    # Exactly one supported process-local clear, after all fixed trusted imports.
    # Do NOT replace with safe_globals([]), which does not clear existing entries.
    torch.serialization.clear_safe_globals()
    require_empty_registry(torch, "after one-time compatibility clear")
    journal.event("official_import_registry_cleared", registered_globals=[])
    return modules, {"trusted_imports": imports, "official_registered_globals_before_clear": before,
                     "clear_safe_globals_calls": 1, "extra_unpickler_globals": []}


@contextmanager
def guarded_checkpoint_loads(torch, checkpoint, expected_sha256, journal):
    """Guard every real torch.load, including official meta and CPU inspection.

    Restoration is guaranteed on ordinary exceptions. Unexpected registry additions
    at any later boundary are errors; never clear them or retry the deserialization.
    """
    checkpoint = Path(checkpoint).resolve(strict=True)
    original_load = torch.load
    records = []
    require_empty_registry(torch, "before installing load guard")

    def guarded_load(file, *args, **kwargs):
        if args:
            raise RuntimeError("Positional load overrides are prohibited")
        if kwargs.get("weights_only") is not True:
            raise RuntimeError("Every torch.load must explicitly set weights_only=True")
        if "pickle_module" in kwargs:
            raise RuntimeError("Custom pickle_module is prohibited")
        if set(kwargs) - {"weights_only", "map_location", "mmap"}:
            raise RuntimeError("Unexpected torch.load keyword")
        if kwargs.get("map_location") not in ("meta", "cpu"):
            raise RuntimeError("Only official meta/CPU checkpoint inspection is allowed")
        if "mmap" in kwargs and type(kwargs["mmap"]) is not bool:
            raise RuntimeError("Invalid mmap argument")
        if not isinstance(file, (str, Path)):
            raise RuntimeError("Only the exact pinned checkpoint path is allowed")
        if Path(os.path.abspath(file)) != checkpoint or Path(file).resolve(strict=True) != checkpoint:
            raise RuntimeError("Checkpoint path is not the exact pinned official file")
        require_empty_registry(torch, "before checkpoint scan")
        if sha256_file(checkpoint) != expected_sha256:
            raise RuntimeError("Pinned checkpoint digest changed")
        unsafe = torch.serialization.get_unsafe_globals_in_checkpoint(checkpoint)
        require_empty_registry(torch, "after checkpoint scan")
        journal.event("checkpoint_scan_completed", checkpoint=str(checkpoint), unsupported_globals=unsafe,
                      extra_unpickler_globals=[])
        if unsafe:
            raise RuntimeError("Checkpoint requires extra unpickler globals")
        record = {"index": len(records) + 1, "checkpoint": str(checkpoint),
                  "checkpoint_sha256": expected_sha256, "weights_only": True,
                  "map_location": kwargs["map_location"], "mmap": kwargs.get("mmap", False),
                  "extra_unpickler_globals": [], "state": "started"}
        records.append(record)
        journal.event("guarded_torch_load_started", **record)
        require_empty_registry(torch, "immediately before actual torch.load")
        try:
            value = original_load(file, **kwargs)
            require_empty_registry(torch, "immediately after actual torch.load")
        except BaseException as exc:
            record.update(state="failed", error_type=type(exc).__name__)
            journal.event("guarded_torch_load_failed", **record)
            raise
        record["state"] = "completed"
        journal.event("guarded_torch_load_completed", **record)
        return value

    torch.load = guarded_load
    try:
        yield records
        require_empty_registry(torch, "after model load")
        if not records or any(record["state"] != "completed" for record in records):
            raise RuntimeError("No complete guarded checkpoint load was observed")
    finally:
        torch.load = original_load
        journal.event("torch_load_guard_restored")


@contextmanager
def prohibit_generation(model_class, journal):
    """Load-only probe tripwire; restored without altering inherited class shape."""
    local = model_class.__dict__.get("generate")
    had_local = "generate" in model_class.__dict__
    calls = []
    def forbidden(*args, **kwargs):
        calls.append(True)
        journal.event("prohibited_generation_attempt")
        raise RuntimeError("Generation is prohibited during the load-only check")
    model_class.generate = forbidden
    try:
        yield calls
        if calls:
            raise RuntimeError("A prohibited generation attempt was observed")
    finally:
        if had_local:
            model_class.generate = local
        else:
            delattr(model_class, "generate")


def load_trusted_components(config, journal, *, load_only=False):
    verify_runtime_metadata(config)
    if config["model"]["official_weight_sha256"] != OFFICIAL_WEIGHT_SHA256:
        raise RuntimeError("Official weight identity changed")
    modules, audit = import_trusted_runtime(journal)
    torch = modules["torch"]
    model_class = modules["transformers.models.codegen.modeling_codegen"].CodeGenForCausalLM
    tokenizer_class = modules["transformers.models.auto.tokenization_auto"].AutoTokenizer
    auto_model = modules["transformers.models.auto.modeling_auto"].AutoModelForCausalLM
    set_seed = modules["transformers.trainer_utils"].set_seed
    model_path = (ROOT / config["model"]["directory"]).resolve()
    from contextlib import nullcontext
    tripwire = prohibit_generation(model_class, journal) if load_only else nullcontext([])
    with tripwire as prohibited_calls:
        with guarded_checkpoint_loads(torch, model_path / "pytorch_model.bin", OFFICIAL_WEIGHT_SHA256, journal) as records:
            tokenizer = tokenizer_class.from_pretrained(model_path, local_files_only=True, trust_remote_code=False)
            require_empty_registry(torch, "after tokenizer load")
            model = auto_model.from_pretrained(model_path, local_files_only=True,
                trust_remote_code=False, weights_only=True, use_safetensors=False,
                dtype=torch.float32, attn_implementation="eager")
            if type(model) is not model_class:
                raise RuntimeError("Unexpected model implementation")
            model.to("cpu")
            model.eval()
            require_empty_registry(torch, "after model configuration")
            if (torch.get_num_threads() != 1 or torch.get_num_interop_threads() != 1
                    or not torch.are_deterministic_algorithms_enabled() or model.training
                    or any(p.device.type != "cpu" or p.dtype != torch.float32 for p in model.parameters())):
                raise RuntimeError("Model effective CPU/dtype/thread/eval configuration mismatch")
        audit.update(actual_loads=records, actual_load_count=len(records),
                     prohibited_generation_attempts=len(prohibited_calls), model_class=type(model).__name__,
                     load_only=load_only)
    journal.event("safe_model_load_completed", **audit)
    return torch, tokenizer, model, set_seed, audit
