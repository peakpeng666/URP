"""Prepare immutable source/fixture ledger using data and host AST checks only."""
import json
from adapter import HERE, digest, load_forms, load_cases
from batch_runner import complete_ledger

forms, cases = load_forms(), load_cases()
plan = {'generated_sources_executed': 0, 'source_adapter': 'none',
        'forms': [{k: f[k] for k in ('form_id','round','candidate_id','prompt_id','variant','source_sha256','admission')} for f in forms],
        'fixtures': [{'id': c['id'], 'valid': c['valid'], 'kind': c['kind'],
                      'fixture_sha256': digest(json.dumps(c, sort_keys=True, separators=(',', ':')).encode())} for c in cases],
        'rows': complete_ledger(forms, cases, {'raw', 'extracted'})}
path = HERE / 'prepared_plan.json'
if path.exists():
    raise FileExistsError(path)
path.write_text(json.dumps(plan, indent=2))
print(json.dumps({'forms': len(forms), 'cases': len(cases), 'rows': len(plan['rows']),
                  'eligible_requests': sum(r['status']=='pending' for r in plan['rows']),
                  'structural_rejection_rows': sum(r['status']=='not_run_structural_rejection' for r in plan['rows']),
                  'grammar_rejection_rows': sum(r['status']=='not_run_grammar_rejection' for r in plan['rows'])}))
