"""Deterministically prepare data-only P2 v4 panels; never execute candidates.

Default mode creates new files and refuses to overwrite changed bytes. --check
recomputes every artifact without writing. The development file remains an exact
copy of old72; panel labels live in descriptors.jsonl and panel_manifest.json.
This is fixture preparation, not the experiment's final approval/freeze gate.
"""
import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import random

HERE = Path(__file__).resolve().parents[1]
OLD_CASES = HERE.parent.parent / 'sorting_generation/fixtures/cases.json'
OLD_SHA256 = '08ffe8c926434072638dea41e16b53b3c2e7988b3fa613acb078a532fce435b3'
SEED = 202610041337
LENGTHS = (4, 5, 9, 17, 33, 65, 129, 258)
DISTRIBUTIONS = (('wide', -1000000, 1000000), ('duplicates', -3, 3))
REPLICATES = 3
MAX_DRAWS_PER_CELL = 1000
MAX_ITEMS = 258
MAX_INT_BITS = 96
MAX_BYTES = 8192
PANELS = ('development72', 'prospective72')
ROLES = {'development72': 'development', 'prospective72': 'prospective_held_out'}
KIND_TYPES = {'list': list, 'tuple': list, 'dict': dict, 'bool': bool,
              'int': int, 'float': float, 'str': str, 'none': type(None)}
IDENTITY_KINDS = {dict: 'dict', bool: 'bool', int: 'int', float: 'float',
                  str: 'str', type(None): 'none'}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def json_bytes(value, *, pretty=False):
    options = {'sort_keys': True, 'ensure_ascii': True, 'allow_nan': False}
    options.update({'indent': 2} if pretty else {'separators': (',', ':')})
    return json.dumps(value, **options).encode('ascii')


def actual_kind(case):
    kind = case['kind']
    if kind == 'identity':
        kind = IDENTITY_KINDS.get(type(case['input']))
    if kind not in KIND_TYPES or type(case['input']) is not KIND_TYPES[kind]:
        raise ValueError('fixture kind/value type mismatch')
    if type(case['valid']) is not bool:
        raise ValueError('fixture validity must be exact bool')
    return kind


def fixture_json(case):
    """Exact unchanged v3 wire descriptor, including field order/serialization."""
    raw = json.dumps({'kind': actual_kind(case), 'value': case['input'],
                      'valid_fixture': case['valid']}, separators=(',', ':'),
                     ensure_ascii=True, allow_nan=False)
    if len(raw.encode('ascii')) > MAX_BYTES:
        raise ValueError('fixture size exceeded; never truncate')
    return raw


def canonical_typed_key(case):
    """Actual kind + recursively exact JSON types + validity, excluding labels.

    Canonical JSON retains true/false vs integer 1/0, integer vs floating-point
    tokens, string vs numeric tokens, and tuple vs list. Object-key ordering is
    ignored. No Python equality/hash comparison can collapse bool into int.
    """
    return json_bytes(json.loads(fixture_json(case))).decode('ascii')


def oracle_payload(case):
    """Trusted data-only conforming observation, not execution of any program."""
    valid = case['valid']
    return {'stage': 'candidate_completed',
            'invocation': 'returned' if valid else 'exact_type_error',
            'result_shape_valid': valid,
            'result': case['expected'] if valid else None,
            'returned_same_object': False if valid else None,
            'final_input_unchanged': True if valid else None,
            'valid_fixture': valid}


def validate_case(case):
    required = {'id', 'kind', 'input', 'valid', 'family'}
    if type(case) is not dict or not required <= set(case):
        raise ValueError('invalid case fields')
    if type(case['id']) is not str or type(case['family']) is not str:
        raise ValueError('invalid case label')
    kind = actual_kind(case)
    value = case['input']
    is_valid = kind == 'list' and all(type(x) is int for x in value)
    if case['valid'] is not is_valid:
        raise ValueError('validity disagrees with exact plain-list/int contract')
    if is_valid:
        if set(case) != required | {'expected'}:
            raise ValueError('valid case fields changed')
        if (type(case['expected']) is not list
                or any(type(x) is not int for x in case['expected'])
                or case['expected'] != sorted(value)):
            raise ValueError('fixture oracle/type mismatch')
    elif set(case) != required | {'expected_exception'} or case['expected_exception'] != 'TypeError':
        raise ValueError('invalid case must expect exact TypeError')
    # Stronger study bounds than unchanged guest bounds (512 items/256-bit ints).
    stack = [(value, 0)]
    nodes = 0
    max_items = max_bits = 0
    while stack:
        item, depth = stack.pop()
        nodes += 1
        if nodes > 1024 or depth > 16:
            raise ValueError('fixture graph limit exceeded')
        t = type(item)
        if t in (list, dict):
            max_items = max(max_items, len(item))
            if len(item) > MAX_ITEMS:
                raise ValueError('fixture length exceeded')
            if t is dict and any(type(k) is not str or len(k) > 128 for k in item):
                raise ValueError('invalid fixture dictionary keys')
            stack.extend((v, depth + 1) for v in (item.values() if t is dict else item))
        elif t is int:
            max_bits = max(max_bits, item.bit_length())
            if item.bit_length() > MAX_INT_BITS:
                raise ValueError('fixture integer bits exceeded')
        elif t is float:
            if not math.isfinite(item):
                raise ValueError('nonfinite fixture float')
        elif t is str:
            if len(item) > 1024:
                raise ValueError('fixture string exceeded')
        elif t not in (bool, type(None)):
            raise ValueError('unsupported fixture scalar')
    input_bytes = len(fixture_json(case).encode('ascii'))
    output_bytes = len(json_bytes(oracle_payload(case)))
    if output_bytes > MAX_BYTES:
        raise ValueError('conforming output envelope exceeded')
    return {'input_bytes': input_bytes, 'conforming_output_bytes': output_bytes,
            'max_items': max_items, 'max_int_bits': max_bits}


def make_case(case_id, kind, value, family, valid):
    case = {'id': case_id, 'kind': kind, 'input': value, 'valid': valid, 'family': family}
    case.update({'expected': sorted(value)} if valid else {'expected_exception': 'TypeError'})
    validate_case(case)
    return case


def fixed_cases():
    # Exact proposal order. Large values are literal integers, not expressions.
    edges = [
        ('singleton', [104729]),
        ('two_reversed', [104723, -104729]),
        ('duplicates', [13, -17, 13, 19, -17, 0, 13]),
        ('all_equal', [104729] * 11),
        ('negative_only', [-104729, -104723, -104759, -104729]),
        ('mixed_signs', [100003, -100019, 0, 100043, -100003]),
        ('already_sorted', [100003, 100019, 100043, 100049, 100057]),
        ('reverse_sorted', [100057, 100049, 100043, 100019, 100003]),
        ('zeros', [0] * 11),
        ('large_ints', [39614081257132168796771975167, -39614081257132168796771975167,
                        9223372036854775808, -9223372036854775808, 0]),
        ('alternating', [100003, -100003] * 7),
        ('negative_singleton', [-104729]),
    ]
    invalid = [
        ('tuple', 'tuple', [101, -103, 101, 0]),
        ('dict', 'identity', {'sample': 29, 'other': -31}),
        ('bool', 'identity', False),
        ('int', 'identity', 104729),
        ('float', 'identity', -1234.25),
        ('str', 'identity', '-103 101 0'),
        ('list_true', 'list', [101, True, -103, 0]),
        ('list_false', 'list', [False, 101, -103]),
        ('list_float', 'list', [101, -103.25, 0]),
        ('list_str', 'list', [101, '-103', 0]),
        ('list_none', 'list', [101, None, -103, 0]),
        ('list_nested', 'list', [[101], -103, [0]]),
    ]
    return ([make_case('prospective_edge_' + name, 'list', value, 'edge', True)
             for name, value in edges]
            + [make_case('prospective_invalid_' + name, kind, value, 'invalid', False)
               for name, kind, value in invalid])


def generate_prospective(development):
    seen = {canonical_typed_key(c) for c in development}
    rng = random.Random(SEED)
    cases, draw_log = [], []
    # A draw means one entire list. At most 1000 total draws per length/range
    # cell across its three replicates; collisions advance this same RNG.
    for length in LENGTHS:
        for family, low, high in DISTRIBUTIONS:
            cell_draws = 0
            for replicate in range(REPLICATES):
                case_id = f'prospective_random_{family}_{length}_{replicate}'
                for draws in range(1, MAX_DRAWS_PER_CELL - cell_draws + 1):
                    cell_draws += 1
                    case = make_case(case_id, 'list',
                                     [rng.randint(low, high) for _ in range(length)], family, True)
                    key = canonical_typed_key(case)
                    if key not in seen:
                        seen.add(key)
                        cases.append(case)
                        draw_log.append({'id': case_id, 'draws': draws, 'cell_draws': cell_draws})
                        break
                else:
                    raise ValueError('random dedup draw cap reached: ' + case_id)
    for case in fixed_cases():
        key = canonical_typed_key(case)
        if key in seen:
            raise ValueError('fixed fixture collision; never redraw/change: ' + case['id'])
        seen.add(key)
        cases.append(case)
    return cases, draw_log


def validate_panel(cases):
    if type(cases) is not list or len(cases) != 72:
        raise ValueError('panel must contain exactly 72 cases')
    if len({c['id'] for c in cases}) != 72:
        raise ValueError('duplicate case ID')
    measurements = [validate_case(c) for c in cases]
    if sum(c['valid'] for c in cases) != 60:
        raise ValueError('panel must contain 60 valid and 12 invalid cases')
    if len({canonical_typed_key(c) for c in cases}) != 72:
        raise ValueError('within-panel typed duplicate')
    return {key: max(m[key] for m in measurements) for key in measurements[0]}


def load_cases(panel=None):
    """Read materialized cases; original IDs retained, unique test_id added.

    Panel-specific loading preserves original v3 case keys exactly. Combined
    loading adds explicit panel metadata for the new population adapter.
    """
    if panel is not None:
        if panel not in PANELS:
            raise ValueError('unknown panel')
        cases = json.loads((HERE / 'fixtures' / (panel + '.json')).read_bytes())
        validate_panel(cases)
        return cases
    return [{**c, 'panel': name, 'panel_role': ROLES[name], 'panel_index': index,
             'test_id': name + '/' + c['id']}
            for name in PANELS for index, c in enumerate(load_cases(name))]


def prepared_artifacts():
    old_bytes = OLD_CASES.read_bytes()
    if digest(old_bytes) != OLD_SHA256:
        raise ValueError('original72 file hash changed')
    development = json.loads(old_bytes)
    development_limits = validate_panel(development)
    prospective, draw_log = generate_prospective(development)
    prospective_limits = validate_panel(prospective)
    old_keys = {canonical_typed_key(c) for c in development}
    if old_keys & {canonical_typed_key(c) for c in prospective}:
        raise ValueError('cross-panel typed collision')
    artifacts = {'development72.json': old_bytes,
                 'prospective72.json': json.dumps(prospective, indent=2, ensure_ascii=True,
                                                  allow_nan=False).encode('ascii') + b'\n'}
    records = []
    for panel, cases in zip(PANELS, (development, prospective)):
        for index, case in enumerate(cases):
            raw = fixture_json(case)
            records.append({'panel': panel, 'role': ROLES[panel], 'index': index,
                            'id': case['id'], 'test_id': panel + '/' + case['id'],
                            'fixture_sha256': digest(json_bytes(case)),
                            'input_json': raw, 'input_sha256': digest(raw.encode('ascii')),
                            'conforming_output_bytes': len(json_bytes(oracle_payload(case)))})
    artifacts['descriptors.jsonl'] = b''.join(json_bytes(r) + b'\n' for r in records)
    artifacts['random_draw_log.json'] = json_bytes(draw_log, pretty=True) + b'\n'
    manifest = {
        'schema': 'urp-p2-v4-data-only-panels-v1',
        'status': 'materialized_for_parent_final_freeze_before_any_new_generation',
        'candidate_or_model_execution': False,
        'original72': {'path': '../../sorting_generation/fixtures/cases.json',
                       'sha256': OLD_SHA256, 'copy_byte_identical': True,
                       'original_case_ids_and_canonical_case_hashes_preserved': True},
        'generator': {'path': 'src/build_fixtures.py', 'sha256': digest(Path(__file__).read_bytes())},
        'tests': {'path': 'tests/test_fixtures.py',
                  'sha256': digest((HERE / 'tests/test_fixtures.py').read_bytes())},
        'proposal': {'path': 'PROPOSAL.md', 'sha256': digest((HERE / 'PROPOSAL.md').read_bytes())},
        'rng': {'algorithm': 'random.Random', 'seed': SEED, 'lengths_in_order': list(LENGTHS),
                'distributions_in_order': [[name, lo, hi] for name, lo, hi in DISTRIBUTIONS],
                'replicates_per_cell': REPLICATES, 'max_total_draws_per_cell': MAX_DRAWS_PER_CELL,
                'rejected_draws': sum(r['draws'] - 1 for r in draw_log),
                'fixed_collision_policy': 'fail_without_redraw_or_replacement'},
        'canonical_equivalence': 'actual kind + exact JSON scalar/container types + validity; '
                                 'object-key order ignored; IDs/family/panel/oracle excluded; bool != int',
        'panels': [],
        'overlap': {'exact_typed_instances': 0, 'category_overlap_deliberate': True,
                    'shared_families': ['duplicates', 'edge', 'invalid', 'wide'],
                    'development_only_anchors': ['edge_empty', 'invalid_none'],
                    'empty_list_and_scalar_none_prospective_count': 0,
                    'claim': 'within-task prospective exact-instance performance only',
                    'not_claimed': ['new-category generalization', 'cross-task generalization',
                                    'unbiased universal Python correctness']},
        'bounds': {'max_items': MAX_ITEMS, 'max_integer_bits': MAX_INT_BITS,
                   'input_json_bytes': MAX_BYTES, 'guest_output_bytes': MAX_BYTES,
                   'output_measurement': 'serialized conforming observation from materialized oracle; '
                                         'arbitrary candidate output still enforced by unchanged runtime'},
        'files': {name: {'sha256': digest(data), 'bytes': len(data)}
                  for name, data in artifacts.items()},
    }
    for panel, cases, limits in zip(PANELS, (development, prospective),
                                    (development_limits, prospective_limits)):
        manifest['panels'].append({'panel': panel, 'role': ROLES[panel], 'case_file': panel + '.json',
                                   'cases': len(cases), 'valid': 60, 'invalid': 12,
                                   'family_counts': dict(sorted(Counter(c['family'] for c in cases).items())),
                                   'ordered_ids_sha256': digest(json_bytes([c['id'] for c in cases])),
                                   'observed_maxima': limits})
    artifacts['panel_manifest.json'] = json_bytes(manifest, pretty=True) + b'\n'
    return artifacts


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true', help='verify exact bytes without writing')
    args = parser.parse_args()
    artifacts = prepared_artifacts()
    directory = HERE / 'fixtures'
    # Preflight every existing file before writing anything; never silently replace.
    for name, data in artifacts.items():
        path = directory / name
        if args.check and not path.is_file():
            raise FileNotFoundError(path)
        if path.exists() and path.read_bytes() != data:
            raise ValueError('materialized artifact differs; no overwrite: ' + str(path))
    if not args.check:
        directory.mkdir(exist_ok=True)
        for name, data in artifacts.items():
            path = directory / name
            if not path.exists():
                with path.open('xb') as output:
                    output.write(data)
    print(json.dumps({'status': 'verified' if args.check else 'materialized',
                      'panels': 2, 'cases': 144, 'generated_sources_executed': 0,
                      'panel_manifest_sha256': digest(artifacts['panel_manifest.json'])}))


if __name__ == '__main__':
    main()
