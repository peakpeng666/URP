"""Lightweight handwritten-only tests: never import torch, load a model or run candidates."""
import copy
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from extract import extract_initial_function
from generation_integrity import (APPROVAL_KEYS, REQUIRED_CORE, consume_authorization,
                                  dependency_inventory, jobs, parse_json_bytes,
                                  read_bound_freeze, sha256_bytes, sha256_file,
                                  validate_approval, verify_frozen_inputs, write_json)
from run_generation import (FIXED_GENERATION, FIXED_LIMITS, Journal, check_limits,
                            fixed_jobs, initialize_ledger, run_jobs)
from supervise_generation import clean_environment, reconcile_ledger
import supervise_generation as supervisor

CONFIG = json.loads((ROOT / "generation_config.json").read_text())
PROMPTS = {arm: (ROOT / filename).read_text() for arm, filename in CONFIG["prompts"].items()}


class PlanTests(unittest.TestCase):
    def test_exact_jobs_and_total_caps(self):
        plan = fixed_jobs(CONFIG)
        self.assertEqual(plan, jobs(CONFIG))
        self.assertEqual([(job["seed"], job["prompt_id"]) for job in plan],
                         [(601, "A"), (601, "B"), (631, "B"), (631, "A"), (661, "A"),
                          (661, "B"), (701, "B"), (701, "A"), (751, "A"), (751, "B")])
        self.assertEqual(len(plan), 10)
        self.assertEqual(CONFIG["generation"]["max_new_tokens"] * len(plan), 5120)
        self.assertEqual([job["id"] for job in plan], [f"sample_{job['seed']}_{job['prompt_id']}" for job in plan])

    def test_mutated_caps_order_or_repair_rejected(self):
        for key, value in (("max_new_tokens", 513), ("maximum_generation_calls", 11), ("automatic_retry", True)):
            config = copy.deepcopy(CONFIG)
            config["generation"][key] = value
            with self.assertRaises(ValueError):
                fixed_jobs(config)
        config = copy.deepcopy(CONFIG)
        config["arm_orders"][1] = ["A", "B"]
        with self.assertRaises(ValueError):
            fixed_jobs(config)

    def test_prompt_a_identity_and_b_proposal_exact(self):
        self.assertEqual(sha256_bytes(PROMPTS["A"].encode()), "6dad5083b4454ac7e111827a1033b0c2d41f620af7a98125789567acbfb05b6c")
        proposal = (ROOT / "PROPOSAL.md").read_text()
        exact_b = proposal.split("```python\n", 1)[1].split("```", 1)[0]
        self.assertEqual(PROMPTS["B"], exact_b)

    def test_exact_original_extraction_function_copy(self):
        original = ROOT / "../../sorting_generation/runs/function_completion_pilot/src/analyze.py"
        self.assertEqual(sha256_file(original), "61f9f1dfa9308792fa5d80cd6068ca0f7527ec9814b96915b9c8b34da7581b98")
        expected = original.read_text().split("def extract_initial_function(source):", 1)[1]
        current = (ROOT / "src/extract.py").read_text().split("def extract_initial_function(source):", 1)[1]
        self.assertEqual(current, expected)
        self.assertNotIn("review(", (ROOT / "src/run_generation.py").read_text())

    def test_extraction_no_repair(self):
        for source in ("def sort_numbers(values):\n    return [\n", "def sort_numbers(values):\n    return values\n",
                       "def sort_numbers(values):\n    return missing(\n"):
            self.assertEqual(extract_initial_function(source)["source"], source)
        source = "def sort_numbers(values):\n    return values\nprint('unexecuted')\n"
        extracted = extract_initial_function(source)
        self.assertEqual(extracted["source"], "def sort_numbers(values):\n    return values\n")
        self.assertTrue(extracted["boundary_observed"])

    def test_offline_environment_and_effective_limit_rejection(self):
        env = clean_environment()
        self.assertEqual(env["HF_HUB_OFFLINE"], "1")
        self.assertEqual(env["TORCH_FORCE_WEIGHTS_ONLY_LOAD"], "1")
        self.assertNotIn("PYTHONPATH", env)
        self.assertNotIn("HF_TOKEN", env)
        with mock.patch("run_generation.resource.getrlimit", return_value=(-1, -1)):
            with self.assertRaises(RuntimeError):
                check_limits()
        self.assertNotIn("torch", sys.modules)
        self.assertNotIn("transformers", sys.modules)


class AuthorizationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.freeze_bytes = b'{"phase":"handwritten mock only"}\n'
        (self.root / "preparation_freeze.json").write_bytes(self.freeze_bytes)
        self.digest = sha256_bytes(self.freeze_bytes)
        self.approval = {"explicit_authorization": True, "stage": "generation",
                         "preparation_freeze_sha256": self.digest,
                         "scope": "ten_paired_new_generations", "batch_id": "fake-batch"}
        self.path = self.root / "approval.json"
        self.path.write_text(json.dumps(self.approval))

    def tearDown(self):
        self.temp.cleanup()

    def test_exact_gate_and_single_use(self):
        validate_approval(self.approval, self.digest, "fake-batch")
        consume_authorization(self.root, self.path, self.digest, "fake-batch", self.root / "outputs", "fake-nonce")
        with self.assertRaises(FileExistsError):
            consume_authorization(self.root, self.path, self.digest, "fake-batch", self.root / "different-output", "other")

    def test_authorization_stage_scope_hash_and_unknown_keys(self):
        for field, value in (("explicit_authorization", 1), ("explicit_authorization", False),
                             ("stage", "evaluation"), ("scope", "arbitrary_generations"),
                             ("batch_id", "other"), ("preparation_freeze_sha256", "0" * 64),
                             ("extra", True)):
            approval = dict(self.approval)
            approval[field] = value
            with self.assertRaises(ValueError, msg=field):
                validate_approval(approval, self.digest, "fake-batch")
        (self.root / "preparation_freeze.json").write_bytes(self.freeze_bytes + b" ")
        with self.assertRaises(ValueError):
            read_bound_freeze(self.root, self.digest)

    def test_missing_or_oversize_approval_blocked(self):
        with self.assertRaises(FileNotFoundError):
            consume_authorization(self.root, self.root / "missing", self.digest, "fake-batch", self.root / "out", "n")
        self.path.write_bytes(b" " * 16385)
        with self.assertRaises(ValueError):
            consume_authorization(self.root, self.path, self.digest, "fake-batch", self.root / "out", "n")
        self.assertFalse((self.root / "authorization_uses/generation.json").exists())

    def test_strict_json_rejects_duplicate_nonfinite_and_overflow(self):
        for payload in (b'{"x":1,"x":2}', b'{"x":NaN}', b'{"x":Infinity}', b'{"x":1e9999}'):
            with self.assertRaises(ValueError):
                parse_json_bytes(payload)

    def test_dependency_checks_cover_existing_bytecode_and_symlinks(self):
        root = self.root / "experiments/isolated/prospective"
        root.mkdir(parents=True)
        model = root / "../../sorting_generation/.model"
        env = root / "../../sorting_generation/.venv"
        model.mkdir(parents=True)
        env.mkdir(parents=True)
        (model / "weights.bin").write_bytes(b"fake handwritten weights data")
        (env / "__pycache__").mkdir()
        (env / "__pycache__/fake.pyc").write_bytes(b"not executable test bytes")
        (env / "filelink").symlink_to("__pycache__/fake.pyc")
        (env / "dirlink").symlink_to("__pycache__", target_is_directory=True)
        files, links = dependency_inventory(root)
        self.assertIn("../../sorting_generation/.venv/__pycache__/fake.pyc", files)
        self.assertEqual(links["../../sorting_generation/.venv/dirlink"], "__pycache__")
        self.assertIn("../../sorting_generation/.venv/filelink", files)
        self.assertNotIn("../../sorting_generation/.venv/dirlink/fake.pyc", files)
        for relative in REQUIRED_CORE:
            path = root / relative
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(b"handwritten fake core bytes")
        provenance = root / "../../sorting_generation/results/model_download.json"
        provenance.parent.mkdir(parents=True)
        provenance.write_bytes(b"{}")
        generation = {relative: sha256_file(root / relative) for relative in files}
        generation["../../sorting_generation/results/model_download.json"] = sha256_file(provenance)
        freeze = {"core_files": {relative: sha256_file(root / relative) for relative in REQUIRED_CORE},
                  "generation_files": generation, "generation_dependency_files": files,
                  "generation_dependency_symlinks": links}
        write_json(root / "preparation_freeze.json", freeze)
        digest = sha256_file(root / "preparation_freeze.json")
        verify_frozen_inputs(root, digest)
        (env / "__pycache__/fake.pyc").write_bytes(b"changed")
        with self.assertRaises(ValueError):
            verify_frozen_inputs(root, digest)


class FakeGenerationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.output = Path(self.temp.name)
        initialize_ledger(self.output, CONFIG, "fake", "0" * 64)
        self.journal = Journal(self.output)

    def tearDown(self):
        self.journal.close()
        self.temp.cleanup()

    @staticmethod
    def fake(prompt, seed, mark_call):
        mark_call([1, 2], {"max_new_tokens": 512})
        return {"input_ids": [1, 2], "output_ids": [7, 99], "eos_token_id": 99,
                "continuation": "    return sorted(values)\n# handwritten, never executed\n"}

    def test_ten_calls_and_source_bytes_preserved(self):
        calls = []
        def fake(prompt, seed, mark_call):
            calls.append((seed, prompt))
            return self.fake(prompt, seed, mark_call)
        status = run_jobs(CONFIG, PROMPTS, self.output, fake, self.journal)
        ledger = reconcile_ledger(self.output, CONFIG, status["status"])
        self.assertEqual(status["generation_calls"], 10)
        self.assertEqual(len(calls), 10)
        self.assertTrue(ledger["journal_integrity"])
        self.assertEqual([slot["state"] for slot in ledger["slots"]], ["complete"] * 10)
        records = [json.loads(line) for line in (self.output / "raw_generations.jsonl").read_text().splitlines()]
        for record in records:
            expected = PROMPTS[record["prompt_id"]] + self.fake("", 0, lambda a, b: None)["continuation"]
            self.assertEqual(record["candidate_source"], expected)
            self.assertEqual((self.output / record["raw_source_path"]).read_bytes(), expected.encode())
            self.assertEqual(record["extraction"]["source"], expected)
            self.assertEqual(record["stop_reason"], "eos")
        with self.assertRaises(FileExistsError):
            run_jobs(CONFIG, PROMPTS, self.output, fake, self.journal)

    def test_generation_failure_retains_all_slots_no_retry(self):
        def fake(prompt, seed, mark_call):
            mark_call([1], {})
            raise RuntimeError("handwritten simulated load/generation failure")
        status = run_jobs(CONFIG, PROMPTS, self.output, fake, self.journal)
        ledger = reconcile_ledger(self.output, CONFIG, status["status"])
        self.assertEqual(status["generation_calls"], 1)
        self.assertEqual(ledger["slots"][0]["state"], "generation_error")
        self.assertEqual([slot["state"] for slot in ledger["slots"]][1:], ["not_started"] * 9)

    def test_cap_violation_preserves_returned_raw_data(self):
        def fake(prompt, seed, mark_call):
            result = self.fake(prompt, seed, mark_call)
            result["output_ids"] = [7] * 513
            return result
        status = run_jobs(CONFIG, PROMPTS, self.output, fake, self.journal)
        self.assertEqual(status["status"], "generation_error")
        ledger = reconcile_ledger(self.output, CONFIG, status["status"])
        self.assertEqual(ledger["slots"][0]["state"], "generation_error")
        self.assertTrue((self.output / "sources/sample_601_A.raw.txt").exists())
        self.assertEqual(ledger["generation_calls_started"], 1)

    def test_context_cap_blocks_model_call(self):
        def fake(prompt, seed, mark_call):
            mark_call([1] * 1537, {})
            self.fail("Model call must not be reached")
        status = run_jobs(CONFIG, PROMPTS, self.output, fake, self.journal)
        self.assertEqual(status["generation_calls"], 0)
        self.assertEqual(status["status"], "generation_error")

    def test_interrupted_attempt_and_partial_line_retained(self):
        self.journal.event("candidate_attempt_started", "sample_601_A", seed=601, prompt_id="A")
        self.journal.events.write(b'{"unfinished":')
        self.journal.events.flush()
        ledger = reconcile_ledger(self.output, CONFIG, "wall_timeout")
        self.assertEqual(ledger["slots"][0]["state"], "interrupted")
        self.assertEqual(len(ledger["slots"]), 10)
        self.assertFalse(ledger["journal_integrity"])
        self.assertIn("partial_final_line", ledger["journal_errors"])

    def test_double_generate_marker_prevents_second_call(self):
        def fake(prompt, seed, mark_call):
            mark_call([1], {})
            mark_call([1], {})
            self.fail("Second model call must not be reached")
        status = run_jobs(CONFIG, PROMPTS, self.output, fake, self.journal)
        self.assertEqual(status["generation_calls"], 1)
        self.assertEqual(status["status"], "generation_error")


class SupervisorMockTests(unittest.TestCase):
    def test_full_mock_supervisor_status_and_one_use_marker(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "generation_config.json").write_text(json.dumps(CONFIG))
            freeze = b'{"handwritten_mock":true}\n'
            (root / "preparation_freeze.json").write_bytes(freeze)
            digest = sha256_bytes(freeze)
            approval = {"explicit_authorization": True, "stage": "generation",
                        "preparation_freeze_sha256": digest,
                        "scope": "ten_paired_new_generations", "batch_id": "mock-only"}
            approval_path = root / "approval.json"
            approval_path.write_text(json.dumps(approval))
            output = root / "generation_outputs/mock-only"
            argv = ["supervisor", "--approval", str(approval_path),
                    "--preparation-freeze-sha256", digest, "--batch-id", "mock-only",
                    "--output", str(output)]

            def fake_popen(command, **kwargs):
                self.assertIn("-B", command)
                self.assertIn("--lease-fd", command)
                self.assertEqual(kwargs["env"]["HF_HUB_OFFLINE"], "1")
                journal = Journal(output)
                journal.event("integrity_before_passed")
                result = run_jobs(CONFIG, PROMPTS, output, FakeGenerationTests.fake, journal)
                journal.event("integrity_after_passed")
                journal.close()
                write_json(output / "worker_status.json", {**result, "integrity_after": "passed"})
                return SimpleNamespace(pid=100000000, returncode=0)

            rusage = SimpleNamespace(ru_utime=0.02, ru_stime=0.01, ru_maxrss=1000)
            with mock.patch.object(supervisor, "ROOT", root), mock.patch.object(supervisor, "verify_frozen_inputs"), \
                    mock.patch.object(sys, "argv", argv), mock.patch.object(supervisor.subprocess, "Popen", side_effect=fake_popen), \
                    mock.patch.object(supervisor, "wait4_until", return_value=(0, rusage)), \
                    mock.patch.object(supervisor, "group_exists", return_value=False), mock.patch("builtins.print"):
                self.assertEqual(supervisor.main(), 0)
            status = json.loads((output / "process_status.json").read_text())
            ledger = json.loads((output / "generation_ledger.json").read_text())
            self.assertEqual(status["status"], "complete")
            self.assertTrue(status["cleanup_complete"])
            self.assertTrue(status["journal_integrity"])
            self.assertEqual(status["integrity_before"], "passed")
            self.assertEqual(status["integrity_after"], "passed")
            self.assertEqual(ledger["terminal_status"], "complete")
            self.assertEqual(status["worker_cpu_seconds"], 0.03)
            self.assertTrue((root / "authorization_uses/generation.json").exists())

    def test_term_then_kill_uses_bounded_waits_only(self):
        process = SimpleNamespace(pid=100000000, returncode=None)
        rusage = SimpleNamespace(ru_utime=1, ru_stime=0, ru_maxrss=1000)
        with mock.patch.object(supervisor, "_signal_group") as send, \
                mock.patch.object(supervisor, "wait4_until", side_effect=[(None, None), (-9, rusage)]) as wait, \
                mock.patch.object(supervisor, "group_exists", return_value=False), \
                mock.patch.object(supervisor.time, "monotonic", return_value=100):
            code, usage, result = supervisor.cleanup(process)
        self.assertEqual(code, -9)
        self.assertTrue(result["cleanup_complete"])
        self.assertEqual(wait.call_args_list[0].args[1], 102)
        self.assertEqual(wait.call_args_list[1].args[1], 105)
        self.assertEqual(result["cleanup_bound_seconds"], 5)

    def test_supervisor_signal_enters_exception_cleanup_path(self):
        with self.assertRaises(supervisor.SupervisorInterrupted):
            supervisor._stop_signal(15, None)


if __name__ == "__main__":
    unittest.main()
