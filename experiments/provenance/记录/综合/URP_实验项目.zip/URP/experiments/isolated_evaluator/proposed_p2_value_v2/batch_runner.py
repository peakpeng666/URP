"""Observable-response value runner. Model CLI stays approval-gated.

Candidate source is only a runtime string. No host exec/eval/import of it.
"""
import argparse,hashlib,json,pathlib,subprocess,sys,time,resource
HERE=pathlib.Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path.insert(0,str(ROOT/'src'))
from host_checker import check_payload_value
from prepare_runner import request_spec,static_gate,SOURCES,digest

def make_request(source,case):
    d=request_spec(source,case)
    return {'source':d['source'],'input_json':d['input_json'],'source_sha256':d['adapted_source_sha256'],
            'input_sha256':digest(d['input_json'].encode())}

def run_one(request):
    from one_request import launch
    return launch(request)

def classify_observation(observation,expected):
    worker=observation.get('worker') or {}
    entered=observation.get('guest_entry_observed') is True
    clean=(observation.get('returncode')==0 and observation.get('termination') is None
           and observation.get('protocol_error') is False and not observation.get('supervisor_error')
           and not observation.get('worker_unreaped') and entered)
    if clean and worker.get('status') in ('returned','trapped','output_rejected','host_output_rejected'):
        ok=worker.get('status')=='returned' and check_payload_value(worker.get('payload'),expected)
        return ('response_conformant' if ok else 'response_nonconformant'),ok,None
    cpu=observation.get('worker_user_seconds',0)+observation.get('worker_sys_seconds',0)
    verified_resource_exit=(entered and observation.get('returncode') in (-9,-24) and not observation.get('worker_unreaped')
        and not observation.get('supervisor_error') and not observation.get('protocol_error')
        and (observation.get('termination') in ('wall_timeout','wall_timeout_after_eof')
             or (observation.get('returncode')==-9 and cpu>=1.9)))
    if verified_resource_exit:
        reason='supervisor_wall_limit_exit' if observation.get('termination') else 'probable_cpu_limit_exit'
        return 'response_nonconformant',False,reason
    return 'infrastructure_error',None,'unclean_or_preentry_transport'

def compact_observation(observation):
    worker=observation.get('worker') or {}
    data={k:observation.get(k) for k in ('returncode','worker_pid','supervisor_pid','termination','guest_entry_observed','wall_seconds','worker_user_seconds','worker_sys_seconds','worker_peak_rss_kib_cumulative','supervisor_effective_rlimit_as','supervisor_peak_rss_kib','protocol_error','worker_unreaped','source_sha256','input_sha256')}
    data['worker_status']=worker.get('status');data['worker_fuel_remaining']=worker.get('fuel_remaining')
    data['worker_effective_rlimits']=worker.get('effective_rlimits')
    if 'payload' in worker:
        encoded=json.dumps(worker['payload'],ensure_ascii=True,separators=(',',':'),allow_nan=False).encode()
        data['payload_sha256']=digest(encoded);data['payload_preview']=encoded[:256].decode('ascii')
    return data

def complete_ledger(forms,cases,scope):
    rows=[]
    for form in forms:
        gate=static_gate(form['source'])
        for case in cases:
            status='pending'
            if not case['valid']:status='not_run_unsupported_contract'
            elif form['variant'] not in scope:status='not_run_scope_unapproved'
            elif gate!='static_eligible_not_executed':status='not_run_static_rejection'
            rows.append({'form_id':form['form_id'],'candidate_id':form['candidate_id'],'round':form['round'],
                         'prompt_id':form['prompt_id'],'variant':form['variant'],'fixture_id':case['id'],
                         'fixture_valid':case['valid'],'source_gate':gate,'status':status,'conformant':None})
    return rows

def summarize(forms,cases,rows,scope):
    outcomes=[]
    for form in forms:
        relevant=[r for r in rows if r['form_id']==form['form_id'] and r['fixture_valid']]
        states=[r['status'] for r in relevant]
        if form['variant'] not in scope:outcome='scope_unapproved'
        elif static_gate(form['source'])!='static_eligible_not_executed':outcome='static_rejected'
        elif all(s=='response_conformant' for s in states):outcome='all_60_response_conformant'
        elif any(s=='response_nonconformant' for s in states):outcome='observed_nonconformant'
        else:outcome='incomplete_unknown'
        outcomes.append({k:form[k] for k in ('form_id','candidate_id','round','prompt_id','variant')}|{'outcome':outcome,
                         'executed_valid_cases':sum(s in ('response_conformant','response_nonconformant') for s in states),
                         'eligible_cases':len(relevant),'unresolved_cases':sum(s in ('pending','not_run_budget_exhausted','infrastructure_error','not_run_infrastructure_stop') for s in states)})
    groups=[]
    keys=sorted(set((f['round'],f['prompt_id'],f['variant']) for f in forms))
    for key in keys:
        selected=[o for o in outcomes if (o['round'],o['prompt_id'],o['variant'])==key]
        n=len(selected);passed=sum(o['outcome']=='all_60_response_conformant' for o in selected)
        unknown=sum(o['outcome']=='incomplete_unknown' for o in selected)
        unapproved=sum(o['outcome']=='scope_unapproved' for o in selected)
        incomplete=unknown>0 or any(o['unresolved_cases'] for o in selected)
        groups.append({'round':key[0],'prompt_id':key[1],'variant':key[2],'original_denominator':n,
                       'passed':passed,'observed_nonconformant':sum(o['outcome']=='observed_nonconformant' for o in selected),
                       'static_rejected':sum(o['outcome']=='static_rejected' for o in selected),'incomplete_unknown':unknown,
                       'scope_unapproved':unapproved,'coverage_complete':not incomplete and not unapproved,
                       'pass_fraction':passed/n if not incomplete and not unapproved else None,
                       'pass_fraction_lower_bound':passed/n if not unapproved else None,
                       'pass_fraction_upper_bound':(passed+unknown)/n if not unapproved else None,
                       'metric':'observable decoded-response value conformance, not tamper-proof Python return correctness'})
    return {'forms':outcomes,'groups':groups,'pooled_raw_count_is_descriptive_only':sum(f['variant']=='raw' for f in forms)}

def run_forms(forms,cases,scope,executor=run_one,cpu_budget=600,wall_budget=900,output_dir=None,clock=time.monotonic,started_at=None):
    start=clock() if started_at is None else started_at;rows=complete_ledger(forms,cases,scope);cpu=0.0;calls=0;stop=None
    if output_dir:
        output_dir.mkdir(parents=True,exist_ok=False)
        (output_dir/'initial_ledger.json').write_text(json.dumps(rows,indent=2))
    forms_by_id={f['form_id']:f for f in forms};case_by_id={c['id']:c for c in cases}
    for row in rows:
        if row['status']!='pending':continue
        # Reserve full per-call worker budget and deadline+reap; never shrink late calls.
        if cpu_budget-cpu<2 or wall_budget-(clock()-start)<6:
            stop='budget_exhausted';break
        form=forms_by_id[row['form_id']];case=case_by_id[row['fixture_id']]
        event={'form_id':row['form_id'],'fixture_id':row['fixture_id'],'event':'start','worker_cpu_before':cpu,'elapsed_before':clock()-start}
        if output_dir:
            with (output_dir/'events.jsonl').open('a') as out:out.write(json.dumps(event)+'\n');out.flush()
        try:
            observation=executor(make_request(form['source'],case))
            calls+=1;cpu+=observation.get('worker_user_seconds',0)+observation.get('worker_sys_seconds',0)
            worker=observation.get('worker') or {}
            expected=sorted(case['input'])
            if expected!=case['expected']:raise ValueError('frozen expected value mismatch')
            status,ok,reason=classify_observation(observation,expected)
            row['status']=status;row['conformant']=ok;row['failure_kind']=reason
            if status=='infrastructure_error':stop='infrastructure_error'
            if output_dir:
                observations=output_dir/'observations';observations.mkdir(exist_ok=True)
                observation_path=observations/f'{calls:06d}.json'
                observation_path.write_text(json.dumps(observation,ensure_ascii=True,allow_nan=False))
                row['observation_file']=str(observation_path.relative_to(output_dir))
            row['observation_summary']=compact_observation(observation)
        except Exception as exc:
            row['status']='infrastructure_error';row['error']=type(exc).__name__+': '+str(exc)[:400];stop='infrastructure_error'
        if output_dir:
            with (output_dir/'events.jsonl').open('a') as out:out.write(json.dumps({'event':'complete','row':row})+'\n');out.flush()
        if stop:break
    for row in rows:
        if row['status']=='pending':row['status']='not_run_budget_exhausted' if stop=='budget_exhausted' else 'not_run_infrastructure_stop'
    elapsed=clock()-start
    report=summarize(forms,cases,rows,scope)|{'rows':rows,'calls':calls,'worker_cpu_seconds':cpu,'elapsed_seconds':elapsed,
        'stop_reason':stop,'budgets':{'worker_cpu_seconds':cpu_budget,'wall_seconds':wall_budget},
        'accounting_overshoot':{'worker_cpu_seconds':max(0,cpu-cpu_budget),'wall_seconds':max(0,elapsed-wall_budget)},
        'supervisor_peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'generated_candidates_executed':None,'supervisor_effective_rlimit_as':resource.getrlimit(resource.RLIMIT_AS)}
    if output_dir:(output_dir/'report.json').write_text(json.dumps(report,indent=2))
    return report

def verify_freeze(path):
    frozen=json.loads(path.read_text())
    actual_sources=sorted(str(p.relative_to(ROOT)) for p in HERE.glob('*.py'))
    if actual_sources!=frozen['operational_python_files']:raise ValueError('operational source inventory changed')
    actual_dependencies=sorted(str(p.relative_to(ROOT)) for p in (ROOT/'.venv').rglob('*') if p.is_file())
    if actual_dependencies!=frozen['dependency_files']:raise ValueError('dependency inventory changed')
    for rel,expected in frozen['files'].items():
        p=ROOT/rel
        with p.open('rb') as stream: actual=hashlib.file_digest(stream,'sha256').hexdigest()
        if actual!=expected:raise ValueError('frozen input changed: '+rel)
    return frozen

def verify_approval(approval,freeze_sha):
    if type(approval) is not dict or approval.get('explicit_parent_batch_authorization') is not True:
        raise PermissionError('explicit parent batch authorization absent')
    if approval.get('operational_freeze_sha256')!=freeze_sha:raise PermissionError('approved freeze digest mismatch')
    if approval.get('scope') not in ('raw_only','raw_and_existing_extracted'):raise PermissionError('unapproved scope')
    return {'raw'} if approval['scope']=='raw_only' else {'raw','extracted'}

def load_model_forms():
    forms=[]
    for name,path in SOURCES:
        for line in path.read_text().splitlines():
            r=json.loads(line);round_name='round1' if name=='round1_raw' else 'round2'
            forms.append({'form_id':round_name+'/'+r['id']+'/raw','candidate_id':r['id'],'round':round_name,
                          'prompt_id':r['prompt_id'],'variant':'raw','source':r['candidate_source']})
            if round_name=='round2':
                forms.append({'form_id':round_name+'/'+r['id']+'/extracted','candidate_id':r['id'],'round':round_name,
                              'prompt_id':r['prompt_id'],'variant':'extracted','source':r['extraction']['source']})
    # Deterministic raw primary order first, then existing secondary order; fixture file order inside each.
    return [f for f in forms if f['variant']=='raw']+[f for f in forms if f['variant']=='extracted']

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--approved-batch',type=pathlib.Path,required=True);p.add_argument('--output',type=pathlib.Path,required=True)
    args=p.parse_args();batch_started=time.monotonic();self_cpu_before=time.process_time();freeze_path=HERE/'operational_freeze.json'
    # Approval and all frozen bytes are checked BEFORE reading candidate source forms.
    scope=verify_approval(json.loads(args.approved_batch.read_text()),digest(freeze_path.read_bytes()))
    freeze=verify_freeze(freeze_path)
    forms=load_model_forms();cases=json.loads((ROOT.parent/'sorting_generation/fixtures/cases.json').read_text())
    cfg=json.loads((HERE/'protocol.json').read_text())
    result=run_forms(forms,cases,scope,cpu_budget=cfg['batch_limits_proposed']['worker_cpu_seconds_total'],wall_budget=cfg['batch_limits_proposed']['elapsed_wall_seconds'],output_dir=args.output,started_at=batch_started)
    result['supervisor_cpu_seconds']=time.process_time()-self_cpu_before
    result['whole_batch_wall_seconds']=time.monotonic()-batch_started
    marked=[r for r in result['rows'] if r.get('observation_summary',{}).get('guest_entry_observed') is True]
    result['requests_with_worker_started']=sum(r.get('observation_summary',{}).get('worker_pid') is not None for r in result['rows'])
    result['requests_with_guest_call_marker']=len(marked)
    result['source_forms_with_guest_call_marker']=len({r['form_id'] for r in marked})
    result['original_candidate_records_with_guest_call_marker']=len({(r['round'],r['candidate_id']) for r in marked})
    result['guest_call_marker_interpretation']='host marker after instantiation immediately before Wasm call; includes later infrastructure failures and is not proof of a specific instruction executing'
    result.pop('generated_candidates_executed',None)
    (args.output/'report.json').write_text(json.dumps(result,indent=2,allow_nan=False))
    print(json.dumps({'groups':result['groups'],'calls':result['calls'],'stop_reason':result['stop_reason']}))
