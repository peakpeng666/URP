"""One fixed matrix of handwritten probes. Every subprocess is separately bounded."""
import hashlib,json,pathlib,subprocess,sys,time
from handwritten_probes import PROBES
ROOT=pathlib.Path(__file__).resolve().parents[1]
sources={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/'src').rglob('*')) if p.is_file() and '__pycache__' not in str(p)}
(ROOT/'results/clean_runtime_source_freeze.json').write_text(json.dumps(sources,indent=2))
commands=[('original','sort','clean_original_sort'),('worker256','sort','clean_worker256_sort')]
commands += [('diagnostic',name,'clean_'+name) for name in PROBES]
commands += [('diagnostic','sort','clean_sort_repeat2'),('diagnostic','sort','clean_sort_repeat3')]
commands += [('cpu','infinite_loop','clean_cpu_limit'),('wall','infinite_loop','clean_wall_limit')]
for profile,probe,name in commands:
    result=ROOT/f'results/{name}.json'
    if result.exists():raise FileExistsError(result)
    command=[str(ROOT/'.venv/bin/python'),'-B',str(ROOT/'src/run_probes.py'),'--profile',profile,'--probe',probe,'--output',f'results/{name}.json']
    p=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=10)
    (ROOT/f'logs/{name}.log').write_bytes(p.stdout)
    if p.returncode:raise RuntimeError(f'{name}: runner failed {p.returncode}: {p.stdout[:1000]!r}')
    d=json.loads(result.read_text());w=d['worker'] or {}
    print(name, d['returncode'],d['termination'],w.get('status'),round(d['wall_seconds'],4),d['child_peak_rss_kib_cumulative'],flush=True)
    if profile=='diagnostic' and probe=='sort' and (w.get('status')!='returned' or not w.get('host_value_check')):
        raise RuntimeError('benign sort gate failed; matrix stopped')
after={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/'src').rglob('*')) if p.is_file() and '__pycache__' not in str(p)}
if after!=sources:raise RuntimeError('runtime sources changed during matrix')
(ROOT/'results/matrix_integrity.json').write_text(json.dumps({'sources_unchanged':True,'runs':len(commands),'generated_candidates':0},indent=2))
