"""One immutable configuration for trusted compilation and runtime."""
from wasmtime import Config, Engine

def make_engine():
    config = Config()
    config.consume_fuel = True
    config.epoch_interruption = True
    config.parallel_compilation = False
    config.memory_init_cow = False  # copied guest initialization; preserves guards
    # Preserve Wasmtime memory reservations and guard mitigations unchanged.
    # Memory/CPU limits are imposed by the supervisor and Store.
    return Engine(config)
