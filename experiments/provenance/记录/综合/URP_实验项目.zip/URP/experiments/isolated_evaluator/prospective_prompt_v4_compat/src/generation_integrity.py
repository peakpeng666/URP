"""Bounded data-only generation authorization and immutable dependency checks.

No model library is imported here. A preparation freeze is evidence, not authority:
its bounded exact bytes must match both the external CLI digest and explicit approval.
"""
import hashlib
import json
import math
import os
from pathlib import Path
import re
import stat
import time

ROOT = Path(__file__).resolve().parents[1]
FREEZE_LIMIT = 32 * 1024**2
APPROVAL_LIMIT = 16 * 1024
APPROVAL_KEYS = {"explicit_authorization", "stage", "preparation_freeze_sha256", "scope", "batch_id"}
REQUIRED_CORE = {
    "PROPOSAL.md", "generation_config.json", "prompts/A.txt", "prompts/B.txt",
    "src/extract.py", "src/generation_integrity.py", "src/run_generation.py",
    "src/supervise_generation.py", "tests/test_generation.py",
    "src/safe_model_load.py", "src/check_model_load_only.py", "src/supervise_model_load_only.py",
    "tests/test_safe_model_load.py", "original_preservation_inventory.json", "README.md",
}
MODEL_PREFIX = "../../sorting_generation/.model"
ENV_PREFIX = "../../sorting_generation/.venv"


def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


def sha256_file(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as stream:
        while block := stream.read(1024 * 1024):
            value.update(block)
    return value.hexdigest()


def _pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key")
        result[key] = value
    return result


def strict_float(value):
    parsed = float(value)
    if not math.isfinite(parsed):
        raise ValueError("Non-finite JSON number")
    return parsed


def parse_json_bytes(data):
    return json.loads(data.decode("utf-8"), object_pairs_hook=_pairs, parse_float=strict_float,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError("Non-finite JSON")))


def read_json(path, limit):
    with Path(path).open("rb") as stream:
        data = stream.read(limit + 1)
    if len(data) > limit:
        raise ValueError("JSON byte limit exceeded")
    value = parse_json_bytes(data)
    return data, value


def fsync_directory(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def write_json(path, value, *, exclusive=False):
    path = Path(path)
    payload = (json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n").encode("utf-8")
    if exclusive:
        with path.open("xb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
    else:
        temporary = path.with_name(path.name + ".tmp")
        with temporary.open("xb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    fsync_directory(path.parent)


def validate_approval(approval, expected_digest, batch_id):
    if type(approval) is not dict or set(approval) != APPROVAL_KEYS:
        raise ValueError("Approval must contain exactly the five stage-specific keys")
    if not isinstance(expected_digest, str) or not re.fullmatch(r"[0-9a-f]{64}", expected_digest):
        raise ValueError("An explicit external preparation SHA256 is required")
    if not isinstance(batch_id, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,79}", batch_id):
        raise ValueError("Invalid bounded batch ID")
    expected = {"explicit_authorization": True, "stage": "generation",
                "preparation_freeze_sha256": expected_digest,
                "scope": "ten_paired_new_generations", "batch_id": batch_id}
    if approval != expected or approval["explicit_authorization"] is not True:
        raise ValueError("Generation authorization, stage, scope, digest or batch ID mismatch")


def read_bound_freeze(root, expected_digest):
    data, freeze = read_json(Path(root) / "preparation_freeze.json", FREEZE_LIMIT)
    if sha256_bytes(data) != expected_digest:
        raise ValueError("Preparation freeze bytes do not match external approved digest")
    if type(freeze) is not dict:
        raise ValueError("Preparation freeze must be an object")
    return freeze


def _relative_path(name, *, core=False):
    if not isinstance(name, str) or not name or "\x00" in name or Path(name).is_absolute():
        raise ValueError("Freeze paths must be nonempty relative strings")
    if str(Path(name)) != name or (core and ".." in Path(name).parts):
        raise ValueError("Noncanonical or escaping core path")
    return Path(name)


def verify_hash_mapping(root, mapping, *, core=False):
    if type(mapping) is not dict or not mapping:
        raise ValueError("Missing nonempty freeze hash mapping")
    for name, expected in mapping.items():
        path = Path(root) / _relative_path(name, core=core)
        if not isinstance(expected, str) or not re.fullmatch(r"[0-9a-f]{64}", expected):
            raise ValueError("Invalid frozen digest")
        if not path.is_file() or sha256_file(path) != expected:
            raise ValueError("Frozen file changed: " + name)


def dependency_inventory(root):
    """Inventory two pinned trees without traversing directory symlinks.

    Existing bytecode caches are included; execution disables new bytecode writes.
    All file symlinks are files AND links; directory symlink topology is also bound.
    """
    files, links = [], {}
    for prefix in (MODEL_PREFIX, ENV_PREFIX):
        base = Path(root) / prefix
        if not base.is_dir() or base.is_symlink():
            raise ValueError("Trusted generation tree is missing or symlinked")
        for directory, dirs, names in os.walk(base, followlinks=False):
            dirs[:] = sorted(dirs)
            for name in dirs + sorted(names):
                path = Path(directory) / name
                relative = os.path.relpath(path, root)
                mode = path.lstat().st_mode
                if stat.S_ISLNK(mode):
                    links[relative] = os.readlink(path)
                    if path.is_file():
                        files.append(relative)
                    elif not path.is_dir():
                        raise ValueError("Dangling or unusual generation symlink")
                elif stat.S_ISREG(mode):
                    files.append(relative)
                elif not stat.S_ISDIR(mode):
                    raise ValueError("Nonregular generation dependency")
    return sorted(files), dict(sorted(links.items()))


def verify_frozen_inputs(root, expected_digest, *, dependencies=True):
    freeze = read_bound_freeze(root, expected_digest)
    core = freeze.get("core_files")
    if type(core) is not dict or not REQUIRED_CORE.issubset(core):
        raise ValueError("Preparation freeze omits required generation core files")
    verify_hash_mapping(root, core, core=True)
    if dependencies:
        hashes = freeze.get("generation_files")
        inventory = freeze.get("generation_dependency_files")
        symlinks = freeze.get("generation_dependency_symlinks")
        if type(inventory) is not list or inventory != sorted(set(inventory)):
            raise ValueError("Dependency inventory must be a sorted unique list")
        if type(symlinks) is not dict:
            raise ValueError("Missing dependency symlink inventory")
        actual_files, actual_links = dependency_inventory(root)
        if inventory != actual_files or symlinks != actual_links:
            raise ValueError("Generation dependency tree inventory changed")
        if type(hashes) is not dict or not set(inventory).issubset(hashes):
            raise ValueError("Generation hashes omit inventoried dependencies")
        verify_hash_mapping(root, hashes)
        provenance_path = "../../sorting_generation/results/model_download.json"
        if provenance_path not in hashes:
            raise ValueError("Model provenance must be generation-frozen")
    return freeze


def consume_authorization(root, approval_path, expected_digest, batch_id, output, nonce):
    approval_bytes, approval = read_json(approval_path, APPROVAL_LIMIT)
    validate_approval(approval, expected_digest, batch_id)
    read_bound_freeze(root, expected_digest)
    directory = Path(root) / "authorization_uses"
    directory.mkdir(exist_ok=True)
    if directory.is_symlink():
        raise ValueError("Authorization directory must not be a symlink")
    marker = directory / "generation.json"
    value = {**approval, "approval_sha256": sha256_bytes(approval_bytes),
             "consumed_at_unix_seconds": time.time(), "supervisor_pid": os.getpid(),
             "output_directory": str(Path(output).resolve()), "launch_nonce": nonce,
             "automatic_retry": False}
    write_json(marker, value, exclusive=True)
    return value


def validate_worker_lease(root, lease):
    _, marker = read_json(Path(root) / "authorization_uses/generation.json", APPROVAL_LIMIT)
    if lease != marker or marker.get("supervisor_pid") != os.getppid():
        raise ValueError("Worker requires this supervisor's one-use launch lease")
    validate_approval({key: marker.get(key) for key in APPROVAL_KEYS},
                      marker.get("preparation_freeze_sha256"), marker.get("batch_id"))
    return marker


def jobs(config):
    """Data-only canonical ten-slot population, shared with the evaluation adapter."""
    seeds = [601, 631, 661, 701, 751]
    orders = [["A", "B"], ["B", "A"], ["A", "B"], ["B", "A"], ["A", "B"]]
    if config.get("seeds") != seeds or config.get("arm_orders") != orders:
        raise ValueError("Generation pairing/order changed")
    return [{"id": f"sample_{seed}_{arm}", "seed": seed, "prompt_id": arm,
             "slot": index * 2 + offset}
            for index, (seed, arms) in enumerate(zip(seeds, orders))
            for offset, arm in enumerate(arms)]
