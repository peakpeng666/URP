# Reproducing the prospective paired-prompt study

This public package preserves the exact prompts, seeds, prospective/development
fixtures, source forms, original records, token IDs, events, full ledgers and
observations. Its paths are relative to URP. The v2/v3 deliveries remain separate,
unchanged antecedents. Installed environments, model weights, wheels/native caches,
local run-authorization records and internal review material are not distributed.

Use official pinned dependencies and the recorded model identity in the generation
configuration/provenance. Rebuild the trusted v3 Wasm component and native cache as
described in delivery_v3/REPRODUCE.md. Generated programs must never be imported,
compiled to host code or used as componentization inputs. Runtime string data
inside the verified import-free guest is the only generated execution route.

A new installation/path/toolchain requires a newly inspected freeze. Historical
freezes are environment-specific evidence, not portable build promises. Because
private local authorization and full installed environments are omitted, the
historical full-input checks are not expected to pass in a downloaded copy.
Prepare a fresh local preservation inventory and new freeze for the available
antecedent files; retain the historical records unchanged rather than editing
old hashes or removing the checks. Each generated/evaluation run still requires
its own explicit local user-controlled authorization.

The current trusted loading implementation is in
prospective_prompt_v4_compat/src/safe_model_load.py. It completes pinned official
imports in a fresh offline process, records then clears the process-local added
registry once, and enforces empty-registry and supported-global checks at the
actual exact-file weights-only deserialization boundary. It does not add an
allowlist, remove guards or permit unsafe deserialization. A load-only tripwire
and mocked tests precede generation. Keep the observed legacy causal-mask warning
and the runtime-version caveat; no original-runtime logit-equivalence is claimed.

Experimental configuration is immutable: two prompts, paired seeds
601/631/661/701/751, fixed A/B order, 512 new tokens/call, one predeclared tokenizer
prefix extraction, no repairs or outcome-dependent replacements. Raw forms are
retained static diagnostics. The model is Salesforce/codegen-350M-mono at revision
d9107f71cca463240db1143f4a75a927a27fcb27; exact official weight SHA256 and environment
versions are in the configuration and summary. Reuse requires matching official
assets, not an arbitrary similarly named checkpoint.

Generation and evaluation are separate gated entrypoints. Generation freezes all
ten slots, including incomplete/error slots. A second source-population freeze
binds exact saved bytes before any scoring. The scoring protocol preserves every
selected-form × test pair, distinguishes syntax/language refusal from measured
semantic failure, and stops on integrity/infrastructure faults. Resource or budget
gaps remain unknown. The actual study had three eligible forms and 432 requests;
the 1,440-row denominator was retained in full.

The prospective72 panel was fixed before new output existed, is typed-instance
unique relative to development, and intentionally reuses known semantic categories.
The old72 panel is development evidence. Do not put case values into model inputs,
tune against the new observations, or claim broad algorithmic/generalization
results from five pairs. Both arms had zero full-protocol passes, so this study is
closed under its predeclared stopping rule. A future study needs a new plan and
separate evidence; this reproduction guide does not authorize additional runs.

Recorded costs include the earlier zero-generation initialization failure, the
safe load-only check, successful generation, manual validation and actual scoring.
The load-only supervisor CPU and all development/review overhead were not fully
instrumented; sums are labelled accordingly. No paid model/API was used; monetary
cloud compute accounting is unavailable. Runtime binaries/model weights must be
retrieved from the recorded official sources and verified rather than copied from
unrecognized locations.
