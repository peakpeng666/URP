"""Read-only validation of frozen evidence, followed by descriptive derived artifacts.
Does not call optimize or rerun any search. Re-evaluates only saved best points.
"""
from pathlib import Path
import csv, hashlib, json, os
import numpy as np
os.environ.setdefault('MPLCONFIGDIR','/tmp/de-matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from de import p1, P1
ROOT=Path(__file__).resolve().parents[1]
R=ROOT/'results'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def js(p,o): p.write_text(json.dumps(o,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def csvout(p,rows):
    with p.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
freeze=json.loads((ROOT/'preregistration.json').read_text())
assert sha(ROOT/'preregistration.json')=='2381bbf0d69dd388e9acdb9caa7569a67f3a7f44861929d5c5025fd690c8abea'
for rel,h in freeze['files_sha256'].items(): assert sha(ROOT/rel)==h,rel
for a in json.loads((P1/'manifest.json').read_text())['artifacts']: assert sha(P1/a['path'])==a['sha256'],a['path']
config=json.loads((ROOT/'config.json').read_text())
runs=json.loads((R/'runs.json').read_text()); old=json.loads((P1/'results/run_records.json').read_text())
assert len(runs)==60 and len({r['run_id'] for r in runs})==60
assert json.loads((R/'failures.json').read_text())==[]
assert json.loads((R/'preregistration.json').read_text())==freeze
raw=np.load(R/'raw_objective_values.npz');initial=np.load(R/'initial_populations.npz');pinit=np.load(P1/'results/initial_populations.npz')
assert set(raw.files)==set(initial.files)=={r['run_id'] for r in runs}
lookup={(r['function'],r['algorithm'],r['seed']):r for r in old+runs}
for fi,f in enumerate(config['functions']):
    for seed in config['seeds']:
        r=lookup[f['name'],'DE',seed];key=r['run_id'];v=raw[key];x=initial[key];curve=np.asarray(r['curve'])
        assert r==json.loads((R/(key+'.json')).read_text())
        assert r['status']=='ok' and r['evaluations']==len(v)==10000 and np.isfinite(v).all()
        assert x.shape==(50,10) and np.array_equal(x,pinit[f"{f['name']}_seed{seed:02d}"])
        assert r['initial_population_sha256']==p1.population_hash(x)
        assert np.array_equal(x,p1.initial_population(config,fi,seed))
        assert np.isfinite(r['best_x']).all() and len(r['best_x'])==10
        assert np.all(np.asarray(r['best_x'])>=f['lower']) and np.all(np.asarray(r['best_x'])<=f['upper'])
        assert float(v.min())==r['final_best']
        assert np.isclose(p1.FUNCTIONS[f['name']](np.asarray(r['best_x'])),r['final_best'],rtol=1e-13,atol=1e-14)
        assert curve.shape==(200,4) and np.array_equal(curve[:,0],np.arange(50,10001,50))
        assert np.array_equal(curve[:,1],np.minimum.accumulate(v)[49::50])
        assert np.array_equal(curve[:,2],v.reshape(200,50).min(axis=1))
        assert np.allclose(curve[:,3],v.reshape(200,50).mean(axis=1),rtol=1e-14,atol=1e-14)
        for alg in ['GA','PSO']: assert lookup[f['name'],alg,seed]['initial_population_sha256']==r['initial_population_sha256']
with (R/'runs.csv').open() as f:
    rows=list(csv.DictReader(f));assert len(rows)==60
    for r,t in zip(runs,rows): assert t['run_id']==r['run_id'] and float(t['final_best'])==r['final_best'] and int(t['evaluations'])==10000
summary=[];paired=[];deltas=[]
for f in config['functions']:
    fn=f['name']
    for alg in ['GA','PSO','DE']:
        vals=np.array([lookup[fn,alg,s]['final_best'] for s in config['seeds']]);q=np.quantile(vals,[.25,.75])
        summary.append(dict(function=fn,algorithm=alg,n=20,median=float(np.median(vals)),mean=float(vals.mean()),std_sample=float(vals.std(ddof=1)),q25=float(q[0]),q75=float(q[1]),iqr=float(q[1]-q[0]),minimum=float(vals.min()),maximum=float(vals.max()),success_count=int((vals<=1e-6).sum())))
    for alg in ['GA','PSO']:
        diffs=[]
        for s in config['seeds']:
            a=lookup[fn,'DE',s]['final_best'];b=lookup[fn,alg,s]['final_best'];d=a-b;diffs.append(d)
            deltas.append(dict(function=fn,seed=s,reference_algorithm=alg,de_final=a,reference_final=b,de_minus_reference=d,outcome='DE_win' if d < -1e-12 else ('DE_loss' if d > 1e-12 else 'tie')))
        d=np.array(diffs)
        paired.append(dict(function=fn,reference_algorithm=alg,n_pairs=20,de_wins=int((d < -1e-12).sum()),de_losses=int((d>1e-12).sum()),ties=int((np.abs(d)<=1e-12).sum()),median_paired_difference=float(np.median(d)),mean_paired_difference=float(d.mean())))
csvout(R/'descriptive_summary.csv',summary);csvout(R/'paired_descriptive.csv',paired);csvout(R/'paired_seed_differences.csv',deltas)
figdir=ROOT/'figures';figdir.mkdir(exist_ok=True)
fig,axes=plt.subplots(1,3,figsize=(15,4.6),constrained_layout=True)
for ax,f in zip(axes,config['functions']):
    for alg,col in [('GA','#e69f00'),('PSO','#0072b2'),('DE','#009e73')]:
        curves=[]
        for s in config['seeds']:
            c=lookup[f['name'],alg,s]['curve'];curves.append([row[1] if alg=='DE' else row['best_so_far'] for row in c])
        curves=np.asarray(curves); q=np.quantile(curves,[.25,.5,.75],axis=0); xs=np.arange(50,10001,50)
        ax.plot(xs,np.maximum(q[1],1e-16),label=alg,color=col);ax.fill_between(xs,np.maximum(q[0],1e-16),np.maximum(q[2],1e-16),alpha=.17,color=col)
    ax.set(title=f['name'],xlabel='Objective evaluations',ylabel='Best objective (log scale)',yscale='log');ax.grid(alpha=.2);ax.legend()
fig.suptitle('Fixed 10D baseline: median and IQR across 20 paired seeds; display floor 1e-16')
for ext in ['png','pdf']: fig.savefig(figdir/f'convergence_comparison.{ext}',dpi=180)
plt.close(fig)
check=dict(all_passed=True,formal_runs=60,formal_objective_evaluations=600000,failed_runs=0,additional_full_budget_reruns=0,read_only_best_point_function_checks=60,raw_arrays_checked=60,raw_values_checked=600000,initial_populations_exactly_equal_to_p1=60,trajectories_rebuilt_from_raw_values=60,frozen_files_checked=32,p1_manifest_verified=True,preregistration_sha256=sha(ROOT/'preregistration.json'),wall_seconds=7.789,wall_seconds_source='Observed bash time output in execution tool transcript; transcribed, not independently derived or retained as original timer log',statistics='Descriptive only; no significance tests or post-hoc tuning')
js(R/'postrun_audit.json',check)
print(json.dumps(dict(audit=check,summary=summary,paired=paired),indent=2))
