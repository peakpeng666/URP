"""Explicitly gated 60-run DE extension; no full-budget verification reruns."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import platform
import sys
import time
from datetime import datetime, timezone
import numpy as np
from de import optimize, p1, P1

ROOT = Path(__file__).resolve().parents[1]

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+'\n')

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--execute-approved', action='store_true', help='Use only after CPU window and protocol approval')
    parser.add_argument('--output', type=Path, default=ROOT/'results')
    args = parser.parse_args()
    if not args.execute_approved:
        parser.error('Formal execution is locked: CPU-window/protocol approval is required')
    freeze = json.loads((ROOT/'preregistration.json').read_text())
    for rel, sha in freeze['files_sha256'].items():
        if digest(ROOT/rel) != sha:
            raise ValueError('Frozen file changed: '+rel)
    config = json.loads((ROOT/'config.json').read_text())
    args.output.mkdir(parents=True, exist_ok=False)
    write_json(args.output/'preregistration.json', freeze)
    write_json(args.output/'environment.json', dict(python=sys.version, numpy=np.__version__, platform=platform.platform(), started_utc=datetime.now(timezone.utc).isoformat(), external_model_calls=0))
    raw, initials, runs, failures = {}, {}, [], []
    for fi, func in enumerate(config['functions']):
        for seed in config['seeds']:
            key = f"{func['name']}_DE_seed{seed:02d}"
            start = time.perf_counter()
            try:
                obj, x0 = optimize(config, fi, seed)
                values = np.concatenate(obj.all_values)
                assert len(values) == obj.count == config['evaluation_budget']
                assert np.all(np.diff(np.array(obj.trace)[:, 1]) <= 0)
                assert float(values.min()) == obj.best_f
                assert np.isclose(float(p1.FUNCTIONS[func['name']](obj.best_x)), obj.best_f, rtol=1e-13, atol=1e-14)
                raw[key], initials[key] = values, x0
                row = dict(run_id=key, function=func['name'], algorithm='DE', seed=seed, status='ok', evaluations=obj.count, final_best=obj.best_f, best_x=obj.best_x.tolist(), initial_population_sha256=p1.population_hash(x0), elapsed_seconds=time.perf_counter()-start, curve=obj.trace)
                write_json(args.output/(key+'.json'), row)
                runs.append(row)
            except Exception as exc:
                failures.append(dict(run_id=key, error=repr(exc)))
                write_json(args.output/'failures.json', failures)
                raise
    write_json(args.output/'runs.json', runs)
    write_json(args.output/'failures.json', failures)
    np.savez_compressed(args.output/'raw_objective_values.npz', **raw)
    np.savez_compressed(args.output/'initial_populations.npz', **initials)
    fields = ['run_id','function','algorithm','seed','status','evaluations','final_best','initial_population_sha256','elapsed_seconds']
    with (args.output/'runs.csv').open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction='ignore'); writer.writeheader(); writer.writerows(runs)
    write_json(args.output/'verification.json', dict(all_passed=True, runs=len(runs), evaluations=sum(r['evaluations'] for r in runs), additional_full_budget_reruns=0))
    print(f'Completed {len(runs)} runs; preserved raw objectives and trajectories')

if __name__ == '__main__':
    main()
