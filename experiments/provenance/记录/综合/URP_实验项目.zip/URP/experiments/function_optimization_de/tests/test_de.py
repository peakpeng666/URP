import copy
import json
from pathlib import Path
import sys
import unittest
import numpy as np
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'src'))
from de import optimize, run_de, trials_from_draws, select, p1, P1

class TestDE(unittest.TestCase):
    def setUp(self):
        self.config = json.loads((ROOT/'config.json').read_text())

    def test_hand_calculated_mutation_and_crossover(self):
        pop=np.array([[0.,0.],[1.,2.],[3.,4.],[5.,6.]])
        donors=np.array([[1,2,3],[0,2,3],[0,1,3],[0,1,2]])
        result=trials_from_draws(pop,donors,np.full((4,2),.5),np.array([0,1,0,1]),.5,0.,-10,10)
        np.testing.assert_array_equal(result,[[0,0],[1,-1],[-2,4],[5,-1]])
        # CR=1 copies complete mutants; clipping only affects out-of-range entries.
        result=trials_from_draws(pop,donors,np.full((4,2),.5),np.zeros(4,dtype=int),.5,1.,-1,6)
        np.testing.assert_array_equal(result,[[0,1],[-1,-1],[-1,-1],[-1,-1]])

    def test_invalid_donors(self):
        with self.assertRaises(ValueError):
            trials_from_draws(np.zeros((4,2)),np.zeros((4,3),dtype=int),np.zeros((4,2)),np.zeros(4,dtype=int),.5,.9,-1,1)

    def test_selection_is_strict_and_elementwise(self):
        p=np.array([[1.],[2.],[3.]])
        new, f=select(p,np.array([1.,2.,3.]),-p,np.array([0.,2.,4.]))
        np.testing.assert_array_equal(new,[[-1],[2],[3]])
        np.testing.assert_array_equal(f,[0,2,3])

    def test_same_initial_populations_as_all_60_recorded_P1_arrays(self):
        prior=np.load(P1/'results/initial_populations.npz')
        for fi, f in enumerate(self.config['functions']):
            for seed in self.config['seeds']:
                x0=p1.initial_population(self.config,fi,seed)
                np.testing.assert_array_equal(x0,prior[f"{f['name']}_seed{seed:02d}"])

    def test_small_budget_determinism_bounds_and_budget(self):
        cfg=copy.deepcopy(self.config);cfg['population_size']=6;cfg['evaluation_budget']=30
        for fi in range(3):
            a,x0=optimize(cfg,fi,999);b,_=optimize(cfg,fi,999)
            self.assertEqual(a.count,30)
            self.assertEqual(len(a.trace),5)
            np.testing.assert_array_equal(np.concatenate(a.all_values),np.concatenate(b.all_values))
            self.assertTrue(np.all(np.diff(np.array(a.trace)[:,1])<=0))
            np.testing.assert_array_equal(x0,p1.initial_population(cfg,fi,999))
            self.assertEqual(float(np.min(np.concatenate(a.all_values))),a.best_f)

    def test_invalid_budget_before_evaluation(self):
        obj=p1.CountedObjective('Sphere',2,-1,1,21)
        with self.assertRaises(ValueError):
            run_de(obj,np.zeros((4,2)),np.random.default_rng(999),self.config['de'])
        self.assertEqual(obj.count,0)

    def test_synchronous_generation(self):
        import de
        obj=p1.CountedObjective('Sphere',1,-10,10,8)
        old=np.array([[1.],[2.],[3.],[4.]])
        original=de.make_trials
        seen=[]
        def fake(pop,*args):
            seen.append(pop.copy());return pop/2
        de.make_trials=fake
        try: run_de(obj,old,np.random.default_rng(999),self.config['de'])
        finally: de.make_trials=original
        self.assertEqual(len(seen),1)
        np.testing.assert_array_equal(seen[0],old)
        np.testing.assert_array_equal(old,[[1],[2],[3],[4]])
        np.testing.assert_array_equal(obj.all_values[1],[.25,1,2.25,4])

if __name__=='__main__':unittest.main()
