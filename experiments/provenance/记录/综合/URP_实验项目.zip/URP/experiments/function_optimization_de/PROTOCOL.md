# P1 DE 扩展：执行前冻结协议

状态：仅准备，60次正式运行未开始。必须先获CPU窗口和本方案核对；入口无 `--execute-approved` 时拒绝执行。此开关是误运行防护，不代替人工授权。

## 范围与可比性

教师材料 §2.2.1 的DE教学条目补充；不宣称1997论文原实验全复现、完整教师课程完成或LLM算法设计结果。GA/PSO的已有结果已知，本轮是预先固定DE参数的探索性扩展，不能声称独立盲测。原P1目录只读，其源码、配置和已有证据指纹冻结在本目录预登记。

同Sphere/Rastrigin/Ackley、同函数公式、10维；Sphere/Rastrigin为[-5.12,5.12]，Ackley为[-32.768,32.768]。种群50、seed 0–19、根种子20261004；测试逐元素核对P1保存的全部60组初始种群，非仅核对seed。总计60运行×10000=600000个目标评估，每次初始50+199代×50；重复点评估计费，无缓存、提前终止或已知最优初始化。

## 算法精确定义

DE/rand/1/bin，F=0.5、CR=0.9，三函数一致、运行后不追调。对旧代每个目标i，从除i外所有索引中均匀无放回抽r1/r2/r3，v=x[r1]+F*(x[r2]-x[r3])。每坐标独立U[0,1)<CR时使用v，否则保留目标；另均匀抽一坐标强制来自v。交叉完的trial逐坐标截断到边界，不重采样、不另扣目标预算。强制来源不保证数值不同（重复点或截断可相同）。整代trial全部产生、批量评价后再同步选择；仅trial目标值严格更小时替换，平局保留目标。无polish或其他局部搜索。

float64，NumPy PCG64；初始化调用P1冻结实现SeedSequence([root, function_index, seed, 0])，DE独立SeedSequence([root, function_index, seed, 3])，GA/PSO原流1/2不改。每代先按i次序抽完donors，再抽(n,d)交叉uniforms，最后抽n个强制坐标。function_index顺序Sphere、Rastrigin、Ackley。F/CR、截断和严格平局规则是本扩展明示选择，不声称是原论文最优参数。

## 输出与解释

逐运行JSON含最优点、所有50评价检查点、耗时、初始化SHA256；另有runs.csv、runs.json、原始600000目标值NPZ、初始种群NPZ、环境、失败记录、预算核验。拒绝覆盖已有输出目录。运行时间包含验证/记录的内存开销但不含落盘，不用于速度优劣结论；小预算单元测试和计时估计另记logs，不作为60正式样本，不自动添加全预算复验。

后续比较必须按函数和seed配对读取旧GA/PSO证据，不重算或覆盖。描述统计中位数/均值/样本标准差/IQR，阈值1e-6，胜负绝对容差1e-12；如做显著性，DE对GA、DE对PSO的3×2=6个双侧Wilcoxon统一Holm校正，不能继承P1仅3比较的校正族。任何效应量绘图log地板1e-16仅用于显示，不改原值。原P1的GA对PSO结论不重新包装成新的发现。只有三种未旋转/未平移函数、一个维度/预算/参数配置，不能外推算法普遍优劣。

## 精确来源（2026-10-04核对）

- Storn, R.; Price, K. (1997), Differential Evolution – A Simple and Efficient Heuristic for Global Optimization over Continuous Spaces. Journal of Global Optimization 11, 341–359. DOI https://doi.org/10.1023/A:1008202821328 。原论文§2，印刷页344式(2)为差分变异与排除目标/互异抽样；页345式(4)为二项交叉及强制坐标；页345选择段；页346命名DE/rand/1/bin。已阅读原文PDF：https://sci2s.ugr.es/sites/default/files/files/Teaching/GraduatesCourses/Metaheuristicas/Bibliography/DE-Storn-Price-1997.pdf 。本次不复刻论文测试床或参数表。
- 函数公式和边界继承 `../function_optimization/src/baselines.py`、`../function_optimization/config.json`；原始冻结 `../function_optimization/results/preregistration.json`。函数公式出处为P1 README列出的SFU三函数页面。
- 教师条目定位来自 `../../docs/教师材料与文献复现覆盖计划.md`，原件链接 https://drive.google.com/file/d/1fPzAfeKgEEDRPsnRTqd6unm7lHA0v4l9/view 。本任务未重新读取该DOCX，避免把覆盖计划误称为本轮原件复核。

## 检查与执行

从项目根运行 `python -m unittest discover -s experiments/function_optimization_de/tests -v`。
正式60次运行仅在批准后：`python experiments/function_optimization_de/src/run_experiment.py --execute-approved --output experiments/function_optimization_de/results`。
SHA256预登记是本地执行前冻结，不是公开注册。正式入口在创建输出前核对全部冻结文件；如协议变动，必须明确新版本并重新冻结，不悄悄放宽。
