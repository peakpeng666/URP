import copy
import json
from pathlib import Path
import sys
import unittest
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from baselines import (FUNCTIONS, CountedObjective, initial_population, optimize,
                       polynomial_mutation, population_hash, pso_step, sbx_children)

CONFIG = json.loads((Path(__file__).resolve().parents[1] / "config.json").read_text())


class BaselineTests(unittest.TestCase):
    def test_known_global_optima(self):
        for d in [1, 2, 10, 30]:
            for name, fn in FUNCTIONS.items():
                self.assertAlmostEqual(float(fn(np.zeros(d))), 0.0, places=14, msg=name)

    def test_known_nonzero_values(self):
        x = np.ones((2, 10))
        np.testing.assert_allclose(FUNCTIONS["Sphere"](x), 10.0)
        np.testing.assert_allclose(FUNCTIONS["Rastrigin"](x), 10.0)
        np.testing.assert_allclose(FUNCTIONS["Ackley"](x), 20.0*(1.0-np.exp(-.2)), atol=1e-13)

    def test_objectives_independent_scalar_reference(self):
        import math
        rng = np.random.default_rng(101)
        for _ in range(100):
            x = rng.uniform(-5, 5, 10)
            expected = {
                "Sphere": sum(float(t)**2 for t in x),
                "Rastrigin": 100 + sum(float(t)**2-10*math.cos(2*math.pi*float(t)) for t in x),
                "Ackley": -20*math.exp(-.2*math.sqrt(sum(float(t)**2 for t in x)/10))-math.exp(sum(math.cos(2*math.pi*float(t)) for t in x)/10)+20+math.e}
            for name, fn in FUNCTIONS.items():
                self.assertAlmostEqual(float(fn(x)), expected[name], places=11)
                self.assertGreaterEqual(float(fn(x)), 0.0)

    def test_budget_and_bound_guards(self):
        obj = CountedObjective("Sphere", 2, -1, 1, 3)
        obj.evaluate(np.zeros((2, 2)))
        with self.assertRaisesRegex(ValueError, "budget"):
            obj.evaluate(np.zeros((2, 2)))
        self.assertEqual(obj.count, 2)
        with self.assertRaisesRegex(ValueError, "bounds"):
            obj.evaluate(np.array([[2, 0]]))
        with self.assertRaisesRegex(ValueError, "Nonfinite"):
            obj.evaluate(np.array([[np.nan, 0]]))

    def test_mutation_and_crossover_bounds(self):
        rng = np.random.default_rng(9)
        x = rng.uniform(-1, 1, (2000, 10))
        for _ in range(5):
            y = sbx_children(x, rng, -1, 1, 15, .9, .5)
            y = polynomial_mutation(y, rng, -1, 1, 20, .1)
            self.assertTrue(np.all(np.isfinite(y)))
            self.assertTrue(np.all((y >= -1) & (y <= 1)))
        np.testing.assert_array_equal(polynomial_mutation(x, rng, -1, 1, 20, 0), x)
        np.testing.assert_array_equal(sbx_children(x, rng, -1, 1, 15, 0, .5), x)

    def test_identical_parent_crossover(self):
        x = np.full((100, 10), .35)
        y = sbx_children(x, np.random.default_rng(1), -1, 1, 15, 1, 1)
        np.testing.assert_allclose(y, x, atol=1e-15)

    def test_pso_boundary_velocity_and_immutability(self):
        p = copy.deepcopy(CONFIG["pso"])
        p.update(cognitive=0, social=0, velocity_limit_fraction_of_range=1)
        x = np.array([[.9, -.9]])
        v = np.array([[1., -1.]])
        out, vel = pso_step(x, v, x, x[0], np.random.default_rng(1), 1, p, -1, 1)
        np.testing.assert_array_equal(out, [[1, -1]])
        np.testing.assert_array_equal(vel, [[0, 0]])
        np.testing.assert_array_equal(x, [[.9, -.9]])

    def test_exact_budget_monotonicity_and_determinism(self):
        c = copy.deepcopy(CONFIG)
        c["evaluation_budget"] = 500
        for f in range(3):
            pair = []
            for alg in ["GA", "PSO"]:
                a, x0 = optimize(c, f, 999, alg)
                b, again_x0 = optimize(c, f, 999, alg)
                self.assertEqual(a.count, 500)
                self.assertEqual(len(a.trace), 10)
                np.testing.assert_array_equal(a.trace, b.trace)
                np.testing.assert_array_equal(a.best_x, b.best_x)
                np.testing.assert_array_equal(x0, again_x0)
                self.assertTrue(np.all(np.diff(np.asarray(a.trace)[:, 1]) <= 0))
                self.assertEqual(a.best_f, min(np.concatenate(a.all_values)))
                pair.append(population_hash(x0))
            self.assertEqual(pair[0], pair[1])

    def test_initialization_independent_and_reproducible(self):
        a = initial_population(CONFIG, 0, 0)
        b = initial_population(CONFIG, 0, 1)
        np.testing.assert_array_equal(a, initial_population(CONFIG, 0, 0))
        self.assertFalse(np.array_equal(a, b))


if __name__ == "__main__":
    unittest.main(verbosity=2)
