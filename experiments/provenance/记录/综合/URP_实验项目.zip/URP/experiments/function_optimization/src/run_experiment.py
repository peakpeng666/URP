"""Run the frozen pilot once, preserve all outcomes, then analyze and audit it."""
from __future__ import annotations
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parents[1]
os.environ.setdefault("MPLCONFIGDIR", str(ROOT / ".matplotlib_cache"))
import numpy as np
import scipy
from scipy.stats import wilcoxon
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from baselines import FUNCTIONS, optimize, population_hash


def utcnow():
    return datetime.now(timezone.utc).isoformat()


def write_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def write_csv(path, rows):
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def environment():
    osrelease = Path("/etc/os-release").read_text() if Path("/etc/os-release").exists() else "unavailable"
    return dict(python=sys.version, executable=sys.executable, platform=platform.platform(),
                os_release=osrelease, processor=platform.processor(), logical_cpu_count=os.cpu_count(),
                numpy=np.__version__, scipy=scipy.__version__, matplotlib=matplotlib.__version__,
                dtype="float64", bit_generator="PCG64", execution_scope="dot cloud only",
                ubuntu_22_04_validated=False, external_model_api_calls=0, packages_installed=0)


def holm(pvalues):
    order = np.argsort(pvalues)
    out = np.empty(len(pvalues))
    running = 0.0
    for rank, idx in enumerate(order):
        running = max(running, (len(pvalues) - rank) * pvalues[idx])
        out[idx] = min(1.0, running)
    return out.tolist()


def analyze(config, runs):
    summaries, comparisons = [], []
    rng = np.random.default_rng(config["statistics"]["bootstrap_seed"])
    for f in config["functions"]:
        by_algorithm = {}
        for algorithm in ("GA", "PSO"):
            rows = sorted([r for r in runs if r["function"] == f["name"] and r["algorithm"] == algorithm
                           and r["status"] == "ok"], key=lambda r: r["seed"])
            by_algorithm[algorithm] = rows
            values = np.array([r["final_best"] for r in rows])
            summaries.append(dict(function=f["name"], algorithm=algorithm, n=len(values),
                median=float(np.median(values)), mean=float(np.mean(values)), std_sample=float(np.std(values, ddof=1)),
                q25=float(np.quantile(values, .25)), q75=float(np.quantile(values, .75)), minimum=float(np.min(values)),
                maximum=float(np.max(values)), success_count=int(np.sum(values <= config["statistics"]["success_absolute_error_threshold"])),
                median_elapsed_seconds=float(np.median([r["elapsed_seconds"] for r in rows]))))
        ga_rows, pso_rows = by_algorithm["GA"], by_algorithm["PSO"]
        if [r["seed"] for r in ga_rows] != [r["seed"] for r in pso_rows]:
            raise ValueError("Missing paired seeds: cannot perform paired analysis")
        ga = np.array([r["final_best"] for r in ga_rows])
        pso = np.array([r["final_best"] for r in pso_rows])
        difference = ga - pso
        tol = config["statistics"]["paired_win_absolute_tolerance"]
        floor = config["statistics"]["log10_floor"]
        log_difference = np.log10(np.maximum(ga, floor)) - np.log10(np.maximum(pso, floor))
        indices = rng.integers(0, len(ga), (config["statistics"]["bootstrap_resamples"], len(ga)))
        medians = np.median(log_difference[indices], axis=1)
        ci = np.quantile(medians, [.025, .975])
        if np.all(difference == 0):
            stat, p = 0.0, 1.0
        else:
            stat, p = wilcoxon(difference, alternative="two-sided", zero_method="wilcox", method="auto")
        comparisons.append(dict(function=f["name"], n_pairs=len(ga),
            ga_wins=int(np.sum(difference < -tol)), pso_wins=int(np.sum(difference > tol)), ties=int(np.sum(np.abs(difference) <= tol)),
            median_log10_ga_minus_pso=float(np.median(log_difference)),
            bootstrap_paired_median_log10_ci95_lower=float(ci[0]), bootstrap_paired_median_log10_ci95_upper=float(ci[1]),
            wilcoxon_statistic=float(stat), wilcoxon_p_two_sided=float(p)))
    for comparison, adjusted in zip(comparisons, holm([c["wilcoxon_p_two_sided"] for c in comparisons])):
        comparison["holm_adjusted_p"] = adjusted
    return summaries, comparisons


def make_figures(config, runs, output):
    colors = {"GA": "#3b6fb6", "PSO": "#d66b2b"}
    floor = config["statistics"]["log10_floor"]
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.4), constrained_layout=True)
    for ax, func in zip(axes, config["functions"]):
        for algorithm in ("GA", "PSO"):
            chosen = [r for r in runs if r["function"] == func["name"] and r["algorithm"] == algorithm and r["status"] == "ok"]
            x = [row["evaluations"] for row in chosen[0]["curve"]]
            y = np.array([[c["best_so_far"] for c in r["curve"]] for r in chosen])
            median = np.median(y, axis=0)
            lo, hi = np.quantile(y, [.25, .75], axis=0)
            ax.plot(x, np.maximum(median, floor), color=colors[algorithm], label=algorithm, lw=2)
            ax.fill_between(x, np.maximum(lo, floor), np.maximum(hi, floor), color=colors[algorithm], alpha=.18)
        ax.set(title=func["name"], xlabel="Objective evaluations (initial 50 included)", ylabel="Best objective, log scale")
        ax.set_yscale("log")
        ax.grid(alpha=.22)
        ax.legend()
    fig.suptitle("P1 pilot | 10 dimensions, 20 paired seeds | median and interquartile band", fontsize=13)
    fig.savefig(output / "convergence.png", dpi=180)
    fig.savefig(output / "convergence.pdf")
    plt.close(fig)

    fig, axes = plt.subplots(1, 3, figsize=(13, 4.5), constrained_layout=True)
    for ax, func in zip(axes, config["functions"]):
        vals = [[r["final_best"] for r in runs if r["function"] == func["name"] and r["algorithm"] == alg and r["status"] == "ok"] for alg in ("GA", "PSO")]
        ax.boxplot([np.maximum(v, floor) for v in vals], tick_labels=["GA", "PSO"], showfliers=False, widths=.45)
        # Every seed is visible; connected points indicate paired initializations.
        for i, (ga, pso) in enumerate(zip(*vals)):
            jitter = ((i % 5) - 2) * .025
            ax.plot([1+jitter, 2+jitter], [max(ga, floor), max(pso, floor)], color="#81909a", alpha=.25, lw=.7)
        for j, (alg, v) in enumerate(zip(("GA", "PSO"), vals), 1):
            offsets = np.array([((i % 5)-2)*.025 for i in range(len(v))])
            ax.scatter(j+offsets, np.maximum(v, floor), color=colors[alg], s=18, zorder=4)
        ax.set(title=func["name"], ylabel="Final objective, log scale")
        ax.set_yscale("log")
        ax.grid(axis="y", alpha=.22)
    fig.suptitle("P1 pilot | final values at exactly 10,000 evaluations | all 20 seeds", fontsize=13)
    fig.savefig(output / "final_distribution.png", dpi=180)
    fig.savefig(output / "final_distribution.pdf")
    plt.close(fig)


def audit(config, runs, raw, root):
    checks = []
    expected = len(config["functions"]) * len(config["seeds"]) * 2
    checks.append(dict(check="all_expected_runs_succeeded", passed=len(runs)==expected and all(r["status"]=="ok" for r in runs), expected=expected, actual=len(runs)))
    for r in runs:
        if r["status"] != "ok":
            continue
        vals = raw[r["run_id"]]
        curve = r["curve"]
        checks.append(dict(check="run_budget_finite_monotone_min_and_final_point", run_id=r["run_id"], passed=bool(
            len(vals)==config["evaluation_budget"]==r["evaluations"]==curve[-1]["evaluations"]
            and np.all(np.isfinite(vals))
            and np.all(np.diff([c["best_so_far"] for c in curve])<=0)
            and float(np.min(vals))==r["final_best"]
            and np.isclose(float(FUNCTIONS[r["function"]](np.array(r["best_x"]))), r["final_best"], rtol=1e-13, atol=1e-14))))
    for fidx, f in enumerate(config["functions"]):
        for seed in config["seeds"]:
            pair = [r for r in runs if r["function"]==f["name"] and r["seed"]==seed]
            checks.append(dict(check="paired_identical_initial_population", function=f["name"], seed=seed,
                passed=len(pair)==2 and pair[0]["initial_population_sha256"]==pair[1]["initial_population_sha256"] and pair[0]["initial_best"]==pair[1]["initial_best"]))
        for alg in ("GA", "PSO"):
            seed = config["seeds"][0]
            rerun, _ = optimize(config, fidx, seed, alg)
            run_id = f"{f['name']}_{alg}_seed{seed:02d}"
            checks.append(dict(check="full_budget_bitwise_reproduction_of_seed0", run_id=run_id,
                passed=bool(np.array_equal(np.concatenate(rerun.all_values), raw[run_id])), validation_evaluations=rerun.count))
    result = dict(timestamp_utc=utcnow(), all_passed=all(c["passed"] for c in checks), checks=checks,
        main_experiment_evaluations=sum(r["evaluations"] for r in runs),
        additional_reproducibility_evaluations=sum(c.get("validation_evaluations",0) for c in checks),
        note="Unit tests use separate sentinel seed 999 and additional evaluations; these are not experimental samples.")
    write_json(root / "verification.json", result)
    if not result["all_passed"]:
        raise AssertionError("Post-run verification failed; inspect verification.json")
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=ROOT / "config.json")
    parser.add_argument("--output", type=Path, default=ROOT / "results")
    args = parser.parse_args()
    cfg = json.loads(args.config.read_text())
    out = args.output
    out.mkdir(parents=True, exist_ok=True)
    if (out / "runs.csv").exists() or (out / "preregistration.json").exists():
        raise SystemExit("Refusing to overwrite prior results. Choose a new --output directory.")
    if cfg["evaluation_budget"] % cfg["population_size"] or cfg["population_size"] % 2:
        raise ValueError("Invalid divisible-budget/even-population design")
    source_hashes = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in [args.config, Path(__file__), ROOT/"src/baselines.py", ROOT/"tests/test_baselines.py"]}
    metadata = environment()
    write_json(out/"preregistration.json", dict(frozen_at_utc=utcnow(), source_sha256=source_hashes,
        config=cfg, note="Local run-plan freeze before pilot sampling; not an external preregistration service. Tests only used sentinel seed 999."))
    write_json(out/"environment.json", metadata)
    runs, raw, initials, failures = [], {}, {}, []
    start = time.perf_counter()
    for fi, func in enumerate(cfg["functions"]):
        for seed in cfg["seeds"]:
            # Alternate execution order to reduce an obvious runtime-order bias.
            algorithms = ("GA", "PSO") if seed % 2 == 0 else ("PSO", "GA")
            for algorithm in algorithms:
                run_id = f"{func['name']}_{algorithm}_seed{seed:02d}"
                began = time.perf_counter()
                try:
                    obj, x0 = optimize(cfg, fi, seed, algorithm)
                    elapsed = time.perf_counter()-began
                    row = dict(run_id=run_id, function=func["name"], algorithm=algorithm, seed=seed,
                        dimension=cfg["dimension"], evaluation_budget=cfg["evaluation_budget"], evaluations=obj.count,
                        initial_best=obj.trace[0][1], final_best=obj.best_f, elapsed_seconds=elapsed, status="ok",
                        initial_population_sha256=population_hash(x0),
                        boundary_coordinate_count=obj.boundary_coordinate_count, best_x=obj.best_x.tolist(),
                        curve=[dict(evaluations=t[0],best_so_far=t[1],batch_min=t[2],batch_mean=t[3]) for t in obj.trace])
                    raw[run_id] = np.concatenate(obj.all_values)
                    initials[f"{func['name']}_seed{seed:02d}"] = x0
                    runs.append(row)
                    print(f"{utcnow()} {run_id}: {obj.count} evaluations; best={obj.best_f:.12g}; {elapsed:.4f}s", flush=True)
                except Exception:
                    failure = dict(run_id=run_id, function=func["name"], algorithm=algorithm, seed=seed,
                                   status="failed", timestamp_utc=utcnow(), traceback=traceback.format_exc())
                    failures.append(failure)
                    print(failure["traceback"], flush=True)
                write_json(out/"failures.json", failures)
                write_json(out/"run_records.json", runs)
    flat = [{k:v for k,v in r.items() if k not in ("curve","best_x")} | {"best_x_json":json.dumps(r["best_x"])} for r in runs]
    traces = [dict(run_id=r["run_id"], function=r["function"], algorithm=r["algorithm"], seed=r["seed"], **c) for r in runs for c in r["curve"]]
    write_csv(out/"runs.csv", flat)
    write_csv(out/"convergence.csv", traces)
    np.savez_compressed(out/"raw_objective_values.npz", **raw)
    np.savez_compressed(out/"initial_populations.npz", **initials)
    if failures:
        raise RuntimeError("Pilot had failed runs, retained in failures.json. No automatic exclusion or analysis.")
    verification = audit(cfg, runs, raw, out)
    summary, comparisons = analyze(cfg, runs)
    write_csv(out/"summary.csv", summary)
    write_csv(out/"paired_comparisons.csv", comparisons)
    write_json(out/"viewer_data.json", dict(schema_version=1, experiment_id=cfg["experiment_id"], config=cfg,
        environment=metadata, summary=summary, comparisons=comparisons, runs=runs, verification={k:v for k,v in verification.items() if k!="checks"}))
    figures = ROOT/"figures" if out.resolve()==(ROOT/"results").resolve() else out/"figures"
    figures.mkdir(exist_ok=True)
    make_figures(cfg, runs, figures)
    print(json.dumps(dict(summary=summary, comparisons=comparisons, verification=verification["all_passed"],
                         total_wall_seconds=time.perf_counter()-start), ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
