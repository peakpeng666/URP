"""Post-run independent hand-calculation checks; no experimental tuning."""
import math
from pathlib import Path
import sys
import unittest
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from baselines import sbx_children, polynomial_mutation, pso_step


class SequenceRNG:
    def __init__(self, arrays):
        self.arrays = iter(arrays)

    def random(self, shape):
        x = np.asarray(next(self.arrays), dtype=float)
        if x.shape != shape:
            raise AssertionError(f"Unexpected random request {shape} instead of {x.shape}")
        return x


class OperatorFormulaTests(unittest.TestCase):
    def test_sbx_hand_calculation(self):
        # p1=2, p2=6, eta=1: beta=sqrt(0.5); symmetric children.
        rng = SequenceRNG([[[0.0]], [[0.0]], [[0.25]]])
        got = sbx_children(np.array([[2.0], [6.0]]), rng, -10, 10, 1, 1, 1)
        np.testing.assert_allclose(got, [[4-2*math.sqrt(.5)], [4+2*math.sqrt(.5)]], rtol=1e-14)

    def test_polynomial_mutation_hand_calculation(self):
        # At x=3 in [1,8], left scale=2 and right scale=5.
        rng = SequenceRNG([[[0.,0.]], [[.125,.875]]])
        got = polynomial_mutation(np.array([[3.,3.]]), rng, 1, 8, 1, 1)
        np.testing.assert_allclose(got, [[2.,5.5]], rtol=1e-14)

    def test_pso_velocity_hand_calculation(self):
        rng = SequenceRNG([[[.2]], [[.4]]])
        params = {"cognitive":1.5,"social":1.5,"velocity_limit_fraction_of_range":1.0}
        x, v = pso_step(np.array([[1.]]), np.array([[2.]]), np.array([[3.]]),
                        np.array([-1.]), rng, .5, params, -10, 10)
        # .5*2 + 1.5*.2*(3-1) + 1.5*.4*(-1-1) = .4
        np.testing.assert_allclose(v, [[.4]], atol=1e-14)
        np.testing.assert_allclose(x, [[1.4]], atol=1e-14)


if __name__ == "__main__":
    unittest.main(verbosity=2)
