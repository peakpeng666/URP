"""Read-only independent checks of saved numeric results; no solver imports/reruns."""
import json, math, hashlib, random, statistics, time, itertools, datetime
from pathlib import Path
from collections import Counter, defaultdict

OUT=Path(__file__).resolve().parent
C=OUT.parent/'cvrp_scale_20261007'
D=OUT.parent/'curvature_routes_20261007'
start=time.process_time()
def read(p): return json.loads(p.read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def mean(x): return statistics.fmean(x)
def near(a,b,tol=1e-8): assert abs(a-b)<tol,(a,b)
def checksum_file(root,p):
    pairs=[line.split(None,1) for line in p.read_text().splitlines()]
    for h,n in pairs: assert sha(root/n.lstrip('*'))==h,n
    return len(pairs)
hashes={}
for root in [C,D]: hashes[root.name]=checksum_file(root,root/'SHA256SUMS.txt')
for name in ['PRE_GENERATION_FREEZE','PRE_RUN_FREEZE']:
    z=read(C/'freeze'/f'{name}.json')
    for p,h in z['sha256'].items(): assert sha(C/p)==h,p
for name in ['freeze.sha256','evidence/pre_run.sha256']:
    checksum_file(D,D/name)
provenance_count=0
for entry in read(C/'freeze/SOURCE_PROVENANCE.json'):
    if entry['byte_identical_to_original']:
        assert sha(C/entry['file'])==sha(Path(entry['source']))==entry['sha256']
        provenance_count+=1
cfg=read(C/'freeze/PROTOCOL.json')
schedule=read(C/'freeze/SCHEDULE.json')
rows=[json.loads(x) for x in (C/'raw/TRAJECTORIES.jsonl').read_text().splitlines()]
assert len(rows)==len(schedule)==384
keys=['geometry_id','demand_mode','algorithm','search_seed','input_file','input_sha256','run_id']
assert [[r[k] for k in keys] for r in rows]==[[r[k] for k in keys] for r in schedule]
assert len({tuple(r[k] for k in keys[:4]) for r in rows})==384
assert read(C/'freeze/PRE_GENERATION_FREEZE.json')['utc']<read(C/'freeze/PRE_RUN_FREEZE.json')['utc']<read(C/'raw/STARTED.json')['utc']
inputs={r['input_file']:read(C/r['input_file']) for r in rows}
geo={r['geometry_id']:(r['family'],r['n']) for r in rows}
assert len(geo)==16 and Counter(geo.values())=={('uniform',100):4,('uniform',200):4,('clustered',100):4,('clustered',200):4}
assert len(inputs)==48
max_error=0.;outputs=0;costs=defaultdict(list);progress=defaultdict(list)
for r in rows:
    assert r['status']=='executed' and r['error'] is None and r['stop_reason']=='delta_budget' and not r['missing_budgets']
    assert sha(C/r['input_file'])==r['input_sha256']
    x=inputs[r['input_file']];n=r['n'];assert len(x['coordinates'])==len(x['demands'])==n+1
    assert sum(x['demands'])==5*n and x['capacity']==30 and max(x['demands'])<=30
    assert [cp['budget'] for cp in r['checkpoints']]==[40000,160000]
    previous=math.inf
    for item in [r['baseline']]+[cp['output'] for cp in r['checkpoints']]:
        visited=[];terms=[]
        for route in item['routes']:
            assert route[0]==route[-1]==0 and 0 not in route[1:-1]
            visited.extend(route[1:-1]);assert sum(x['demands'][i] for i in route[1:-1])<=30
            terms.extend(math.dist(x['coordinates'][i],x['coordinates'][j]) for i,j in zip(route,route[1:]))
        assert sorted(visited)==list(range(1,n+1))
        actual=math.fsum(terms);near(actual,item['reported_cost']);assert actual<=previous+1e-8;previous=actual
        max_error=max(max_error,abs(actual-item['reported_cost']));outputs+=1
    for cp in r['checkpoints']:
        assert cp['deltas']==cp['budget']==sum(cp['delta_by_kind'].values())
        assert cp['delta_by_kind']['savings']==n*(n-1)//2
        assert cp['scoreable'] and cp['check']['accepted']
        assert cp['solver_cpu_seconds']<2 and cp['solver_wall_seconds']<30
        costs[r['geometry_id'],r['demand_mode'],r['algorithm'],cp['budget']].append(cp['output']['reported_cost'])
        progress[n,cp['budget'],r['algorithm']].append(cp)
assert all(len(v)==2 for v in costs.values())
means={k:mean(v) for k,v in costs.items()}
gains={}
for g in sorted(geo):
    for budget in cfg['checkpoints']:
        gains[g,budget]=mean(100*(means[g,d,'random_cheapest',budget]-means[g,d,'random_regret2',budget])/means[g,d,'random_cheapest',budget] for d in cfg['demand_modes'])
strata=[[g for g in sorted(geo) if geo[g]==(f,n)] for f in cfg['families'] for n in cfg['customer_counts']]
rng=random.Random(cfg['bootstrap_seed']);bs={b:[] for b in cfg['checkpoints']}
for _ in range(10000):
    draw=[rng.choice(gs) for gs in strata for _ in range(4)]
    for b in bs: bs[b].append(mean(gains[g,b] for g in draw))
def quantile(xs,p):
    s=sorted(xs);z=(len(s)-1)*p;i=int(z);return s[i]+(s[min(i+1,len(s)-1)]-s[i])*(z-i)
comparisons=[]
summary=read(C/'reports/SUMMARY.json')
for b in cfg['checkpoints']:
    val=mean(gains[g,b] for g in geo);ci=[quantile(bs[b],.025),quantile(bs[b],.975)]
    saved=next(r for r in summary['paired_comparisons'] if r['budget']==b and r['competitor']=='random_cheapest')
    near(val,saved['mean_rr_cost_improvement_pct']);near(ci[0],saved['ci95_lower_pct']);near(ci[1],saved['ci95_upper_pct'])
    comparisons.append(dict(budget=b,improvement_percent=val,ci95_percent=ci,wins=sum(gains[g,b]>1e-9 for g in geo)))
starvation=[]
for (n,b,a),v in progress.items():
    if n==200:
        starvation.append(dict(n=n,budget=b,algorithm=a,trajectories=len(v),zero_complete_iterations=sum(p['iterations_completed']==0 for p in v),accepted_improvement=sum(p['accepted_improvements']>0 for p in v)))
assert all(x['accepted_improvement']==0 for x in starvation if x['budget']==40000)
assert all(x['zero_complete_iterations']==48 for x in starvation if x['budget']==40000 and x['algorithm'].startswith('random'))
z=next(x for x in starvation if x['budget']==160000 and x['algorithm']=='random_regret2')
assert z['zero_complete_iterations']==21 and z['accepted_improvement']==15
resource_c=read(C/'reports/RESOURCE_ACCOUNTING.json')
near(sum(x['child_total_cpu_seconds']+x['wrapper_cpu_seconds'] for x in resource_c['measured_stages']),resource_c['measured_preparation_run_analysis_and_wrappers_cpu_seconds'])
assert resource_c['cpu_through_finalization_plus_allowance_seconds']<180
archive_resource=read(C.parent/'cvrp_scale_20261007_ARCHIVE_RESOURCE.json')
assert sha(Path(archive_resource['archive_path']))==archive_resource['archive_sha256']
near(archive_resource['measured_cpu_plus_allowance_including_archive'],resource_c['cpu_through_finalization_plus_allowance_seconds']+archive_resource['archive_and_manifest_cpu_seconds'])
assert archive_resource['measured_cpu_plus_allowance_including_archive']<180
cvrp=dict(status='passed',geometry_blocks=16,paired_demand_inputs=48,trajectories=len(rows),checkpoints=sum(len(r['checkpoints']) for r in rows),independent_route_outputs_recomputed=outputs,max_objective_error=max_error,formal_failures=0,primary_comparisons= comparisons,n200_starvation=starvation,resource=resource_c,archive_resource=archive_resource,byte_identical_source_provenance_checks=provenance_count,freeze_hashes_verified=True)

cfgd=read(D/'freeze.json');rr=read(D/'raw/results.json');graphs={x['instance_id']:x for x in read(D/'raw/graphs.json')};inst={x['geometry_id']:x for x in read(D/'instances.json')}
assert len(rr)==72 and len(graphs)==72 and len(inst)==24
assert cfgd['frozen_utc']<read(D/'evidence/run_status.json')['started_utc']
assert {(x['geometry_id'],x['R']) for x in rr}==set(itertools.product(inst,[1.,3.,6.]))
assert Counter(x['group'] for x in inst.values())=={'interior':12,'near_boundary':12}
edge_count=candidate_count=segment_count=feasible_candidates=0;edgekeys=set();sample=[]
for line in (D/'raw/edges.jsonl').open():
    e=json.loads(line);edge_count+=1;k=(e['instance_id'],e['i'],e['j']);assert k not in edgekeys;edgekeys.add(k)
    paths=e['candidates'];candidate_count+=len(paths);segment_count+=sum(len(p['segments']) for p in paths)
    fp=[p for p in paths if p['feasible']];feasible_candidates+=len(fp)
    best=min(fp,key=lambda p:(p['length'],p['word'])) if fp else None
    assert e['cost']==(best['length'] if best else None) and e['selected_word']==(best['word'] if best else None)
    assert graphs[e['instance_id']]['cost'][e['i']][e['j']]==e['cost']
    if e['i']==0 and e['j']==1 and e['instance_id'].startswith(('interior_00_','near_boundary_00_','near_boundary_01_','near_boundary_09_')): sample.append(e)
assert (edge_count,candidate_count,segment_count,feasible_candidates)==(4032,18294,54882,13311)
# Small predetermined geometry spot check: 12 edges, every stored candidate.
sample_paths=0;endpoint_max=heading_max=bbox_max=0.
for e in sample:
    for p in e['candidates']:
        sample_paths+=1;q=e['q0'][:];boxes=[]
        for word,u,sg in zip(p['word'],p['params'],p['segments']):
            near(sg['length'],u*e['R']);k=0 if word=='S' else (1 if word=='L' else -1)/e['R'];near(k,sg['curvature'])
            def point(s):
                return [q[0]+(math.sin(q[2]+k*s)-math.sin(q[2]))/k,q[1]+(math.cos(q[2])-math.cos(q[2]+k*s))/k] if k else [q[0]+s*math.cos(q[2]),q[1]+s*math.sin(q[2])]
            length=u*e['R'];times=[0,length]
            if k:
                lo,hi=sorted([q[2],q[2]+k*length])
                times += [(j*math.pi/2-q[2])/k for j in range(math.ceil(lo/(math.pi/2)),math.floor(hi/(math.pi/2))+1)]
            pts=[point(t) for t in times];box=[min(t[0] for t in pts),max(t[0] for t in pts),min(t[1] for t in pts),max(t[1] for t in pts)];boxes.append(box)
            bbox_max=max(bbox_max,max(abs(a-b) for a,b in zip(box,sg['bbox'])))
            q=point(length)+[q[2]+k*length]
        endpoint_max=max(endpoint_max,math.dist(q[:2],e['q1'][:2]));heading_max=max(heading_max,abs(math.remainder(q[2]-e['q1'][2],2*math.pi)))
        b=[min(x[0] for x in boxes),max(x[1] for x in boxes),min(x[2] for x in boxes),max(x[3] for x in boxes)]
        assert p['feasible']==(min(b[0],40-b[1],b[2],30-b[3])>=-1e-9)
        near(p['length'],sum(p['params'])*e['R'])
assert endpoint_max<2e-8 and heading_max<2e-10 and bbox_max<2e-8
route_count=0;tour_max=0.;gaps=[];certificates=[]
for r in rr:
    m=graphs[r['instance_id']]['cost']
    for prefix in ['baseline','dubins_dp']:
        if r[prefix+'_feasible']:
            route=r[prefix+'_route'];assert route[0]==route[-1]==0 and sorted(route[1:-1])==list(range(1,8))
            terms=[m[a][b] for a,b in zip(route,route[1:])];assert None not in terms
            err=abs(math.fsum(terms)-r[prefix+'_cost']);tour_max=max(tour_max,err);assert err<1e-8;route_count+=1
    if r['baseline_feasible'] and r['dubins_dp_feasible']:
        gap=(r['baseline_cost']/r['dubins_dp_cost']-1)*100;near(gap,r['common_feasible_gap_pct']);gaps.append(gap)
    if not r['dubins_dp_feasible']:
        outgoing=[i for i in range(8) if all(v is None for v in m[i])]
        incoming=[j for j in range(8) if all(m[i][j] is None for i in range(8))]
        assert outgoing or incoming
        assert outgoing==r['outgoing_missing_nodes'] and incoming==r['incoming_missing_nodes']
        certificates.append(dict(instance_id=r['instance_id'],nodes_with_no_outgoing_edge=outgoing,nodes_with_no_incoming_edge=incoming,scope='Finite six-candidate graph only.'))
counts=dict(instances=len(rr),baseline_feasible=sum(r['baseline_feasible'] for r in rr),dubins_dp_feasible=sum(r['dubins_dp_feasible'] for r in rr),common_feasible=len(gaps),ordering_only_failures=sum(r['ordering_only_failure'] for r in rr),both_failures=len(certificates))
assert list(counts.values())==[72,65,67,65,2,5]
saved=read(D/'summary.json')[0]
near(mean(gaps),saved['gap_mean_pct']);near(statistics.median(gaps),saved['gap_median_pct'])
# Three small all-permutation spot checks on saved graphs, no solver runs.
brute=[]
for ident in ['interior_00_R1','near_boundary_00_R6','near_boundary_09_R6']:
    row=next(r for r in rr if r['instance_id']==ident);m=graphs[ident]['cost'];best=math.inf
    for perm in itertools.permutations(range(1,8)):
        route=(0,)+perm+(0,);terms=[m[a][b] for a,b in zip(route,route[1:])]
        if None not in terms: best=min(best,math.fsum(terms))
    near(best,row['dubins_dp_cost']);brute.append(dict(instance_id=ident,orders_checked=5040,minimum=best))
proof=read(D/'evidence/verification.json');assert proof['status']=='passed' and proof['candidates_checked']==candidate_count
assert len(read(D/'evidence/bruteforce_all_instances.json'))==72
dubins=dict(status='passed',counts=counts,gap_mean_percent=mean(gaps),gap_median_percent=statistics.median(gaps),gap_formula='100 * (baseline / graph_DP - 1)',edges=edge_count,candidates=candidate_count,segments=segment_count,selected_edge_minima_checked=edge_count,feasible_tour_objectives_recomputed=route_count,max_tour_cost_error=tour_max,small_geometry_spot_check=dict(edges=len(sample),candidate_paths=sample_paths,max_endpoint_error=endpoint_max,max_heading_error=heading_max,max_bbox_error=bbox_max),small_bruteforce_spot_check=brute,finite_graph_failure_certificates=certificates,existing_full_verification_evidence=proof,resource=read(D/'resource.json'),freeze_hashes_verified=True)
result=dict(audit_id=OUT.name,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='passed_with_scope_notes',archivable=True,blocking_issues=[],manifest_entries_verified=hashes,cvrp=cvrp,dubins=dubins,notes=['Stored freeze hashes and recorded timestamp ordering agree; no external timestamp attestation is claimed.','CVRP has 16 geometry blocks, not 384 or 768 independent samples. Delta counts do not equate CPU time or FLOPs.','n200 budget starvation materially limits scale conclusions.','Dubins 18.94% is baseline excess relative to graph optimum, not average saving relative to baseline.','Five Dubins failures are certified only for the finite candidate graph; continuous-domain infeasibility is not established.','Dubins total measured Python CPU excludes compiler child CPU and startup/import overhead; 120 s whole-task hard-cap compliance is not independently certified.','No production solver or original verifier rerun; original files were read only.'],audit_compute_cpu_seconds=time.process_time()-start)
(OUT/'AUDIT_RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
print(json.dumps(dict(status=result['status'],archivable=result['archivable'],cvrp_trajectories=len(rows),cvrp_checkpoints=768,cvrp_recomputed_outputs=outputs,cvrp_max_cost_error=max_error,cvrp_main=comparisons[-1],dubins=counts,dubins_gap=mean(gaps),audit_cpu=result['audit_compute_cpu_seconds']),ensure_ascii=False,indent=2))
