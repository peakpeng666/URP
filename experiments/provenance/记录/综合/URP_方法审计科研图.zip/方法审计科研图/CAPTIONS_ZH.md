# 中期报告插图说明（2026-10-05）

## 图 1 图注
candidate_01 原始保存程序的评分语义。固定物品大小 item=40、容量100，对全部可行整数剩余容量 b=40,…,100 绘制 S(b)=(b−40)²−0.01b。三个标记点为 S(40)=−0.4、S(60)=399.4、S(100)=3599。相邻整数的评分增量严格为正；当空箱参与可行集合且内层采用首次 argmax 时，选择剩余100的空箱。该图为原程序的数学示意，不是新候选、装箱实验或额外样本。原响应文字声称“negative squared slack”，但实际节点为正平方；本图不推断生成错误的心理或因果根源，也未修复原程序。

## 图 2 图注
固定发表 EoH 数学策略与 BF 在 historical_design_5k 同五条序列（原索引0–4）上的保存结果。A为各序列前256项，B为完整5000项；容量均为100，保留到达顺序。每个点显示 100×(EoH箱数−BF箱数)/BF箱数，右列给出原始箱数。菱形合计使用总数之比，而非逐实例百分比均值。前缀合计555 vs 546（+1.6484%），全长合计10007 vs 10335（−3.1737%）。两面板共享同源序列并相互依赖，不是10个独立样本；均为已暴露设计数据，不作盲测、总体优劣、置信区间、显著性或长度因果规律的声称。固定发表公式不等于完整EoH进化流程复现。

## 数据与可复现性
本目录脚本直接解析已保存JSON，验证原候选四节点和常数、五条256项前缀与5000项序列逐项匹配，以及256项回归箱数一致；仅计算图中算术，不重跑装箱、不调用模型、不新增实验。CSV、figure_data.json 保留整数箱数及相对百分比精确分数。SVG保留可编辑文本（需安装Noto Sans CJK字体），PDF内嵌字体，PNG为240 dpi。

复现：在同一仓库执行 python URP/docs/figures/20261005_method_audit/generate_figures.py。完整源文件 SHA-256 见 source_hashes.json；图及脚本哈希见 artifact_hashes.json。

### 源文件与 SHA-256

- `URP/experiments/online_bin_packing/glm53_concise_generation_v1/results/candidate_01.program.json`
  - SHA-256: `51388d17771429aff327faf15dfb8d9c67a0f7738133f59a82c6afbc75edb876`

- `URP/experiments/online_bin_packing/glm53_concise_generation_v1/results/candidate_01.raw.txt`
  - SHA-256: `db142fdf1525d26033836ae3fdd3cf5fc29224485ac882b1328edfa29710f7c7`

- `URP/experiments/online_bin_packing/scoring_semantics_audit_v1/REPORT_ZH.md`
  - SHA-256: `2d7ed041af9c802ebecdc6ebaad1047a3a15202fa031c9f5f1e8cc3ee44dab05`

- `URP/experiments/online_bin_packing/published_eoh_scoring_control_v1/results/report.json`
  - SHA-256: `cbc59ff16539584f7a52403159f9294447fe589e5b327880669c935644cc316e`

- `URP/experiments/online_bin_packing/paper_scale_dag_evaluator_v1/results/report.json`
  - SHA-256: `775bd129cda66b429f435915dc60d186944f0dca43f0b99c5369918c3a423648`

- `URP/experiments/online_bin_packing/paper_scale_dag_evaluator_v1/data/design_5000.json`
  - SHA-256: `5358c41aa758e1d399d29157f8cbdc5fb422f4c8acd56b2cb95c41af3f1750ca`

- `URP/experiments/online_bin_packing/paper_scale_dag_evaluator_v1/data/regression_development_256.json`
  - SHA-256: `faad2801738475368cd83dd6fd018ebf4963a3a6462bbbae7122c631f0e16482`
