#!/usr/bin/env python3
"""Read saved evidence and render figures; no policy replay, model call, or sampling."""
import os
os.environ.setdefault('MPLCONFIGDIR','/tmp/urp_method_figures_mpl')
import json, csv, hashlib
from pathlib import Path
from fractions import Fraction
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
ROOT=next(p for p in Path(__file__).resolve().parents if (p/'URP/experiments').exists())
OUT=Path(__file__).resolve().parent
BASE=ROOT/'URP/experiments/online_bin_packing'
sources={}
def read(rel, parse=True):
 p=BASE/rel; raw=p.read_bytes(); sources[str(p.relative_to(ROOT))]=hashlib.sha256(raw).hexdigest()
 return json.loads(raw) if parse else raw.decode()
def writejson(name,obj): (OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def csvout(name,rows):
 with (OUT/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
program=read('glm53_concise_generation_v1/results/candidate_01.program.json')
read('glm53_concise_generation_v1/results/candidate_01.raw.txt',False)
read('scoring_semantics_audit_v1/REPORT_ZH.md',False)
assert program['nodes']==[['sub','bins','item'],['mul',0,0],['mul','c0','bins'],['sub',1,2]]
assert program['constants'][0]['value']==.01 and program['return_node']==3
short=read('published_eoh_scoring_control_v1/results/report.json')
long=read('paper_scale_dag_evaluator_v1/results/report.json')
full=read('paper_scale_dag_evaluator_v1/data/design_5000.json')
prefix=read('paper_scale_dag_evaluator_v1/data/regression_development_256.json')
assert len(full['cases'])==len(prefix['cases'])==5
assert all(a['items'][:256]==b['items'] and len(a['items'])==5000 for a,b in zip(full['cases'],prefix['cases']))
assert short['state']==long['state']=='completed' and not short['errors'] and not long['errors']
g=next(g for g in short['groups'] if g['split']=='development')
rows=[]
for n in [256,5000]:
 for i in range(5):
  if n==256: e,b=g['bins'][i],g['BF']['bins'][i]
  else:
   vals={r['method']:r['used_bins'] for r in long['scores'] if r['phase']=='design5000' and r['instance']==i};e,b=vals['EOH'],vals['BF']
  if n==256:
   reg={r['method']:r['used_bins'] for r in long['scores'] if r['phase']=='regression256' and r['split']=='development' and r['instance']==i};assert (e,b)==(reg['EOH'],reg['BF'])
  rows.append(dict(n_items=n,instance=str(i),eoh_bins=e,bf_bins=b,delta_bins=e-b,relative_percent=100*(e-b)/b,relative_percent_exact=str(Fraction(100*(e-b),b))))
 sub=[r for r in rows if r['n_items']==n];e=sum(r['eoh_bins'] for r in sub);b=sum(r['bf_bins'] for r in sub)
 rows.append(dict(n_items=n,instance='aggregate',eoh_bins=e,bf_bins=b,delta_bins=e-b,relative_percent=100*(e-b)/b,relative_percent_exact=str(Fraction(100*(e-b),b))))
curve=[dict(item=40,b=b,score=float(Fraction((b-40)**2)-Fraction(b,100)),score_exact=str(Fraction((b-40)**2)-Fraction(b,100))) for b in range(40,101)]
csvout('figure_01_score_values.csv',curve);csvout('figure_02_bin_counts.csv',rows)
writejson('figure_data.json',dict(score_formula='S(b)=(b-item)^2-0.01*b',score_domain='integer b=40,...,100; item=40; capacity=100',score_values=curve,bin_comparison=rows,relative_formula='100*(EoH_bins-BF_bins)/BF_bins',aggregate_formula='100*(sum(EoH_bins)-sum(BF_bins))/sum(BF_bins)',verified_same_sequence_prefixes=True))
font='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
font_manager.fontManager.addfont(font)
plt.rcParams.update({'font.family':font_manager.FontProperties(fname=font).get_name(),'font.size':10,'axes.titlesize':12,'axes.labelsize':11,'axes.spines.top':False,'axes.spines.right':False,'axes.edgecolor':'#9ba3aa','text.color':'#202a33','axes.labelcolor':'#303b44','xtick.color':'#46515b','ytick.color':'#46515b','svg.fonttype':'none','pdf.fonttype':42,'axes.unicode_minus':False,'savefig.facecolor':'white'})
BLUE='#315b78';RED='#a15a44';GRID='#e4e8eb'
def save(fig,stem):
 for ext in ['svg','pdf','png']:fig.savefig(OUT/f'{stem}.{ext}',dpi=240)
 plt.close(fig)
fig=plt.figure(figsize=(10.2,6.2));ax=fig.add_axes([.11,.23,.79,.56])
fig.text(.075,.93,'图 1  原候选的正平方评分偏向更大剩余容量',fontsize=16)
fig.text(.075,.865,'candidate_01 实际程序：S(b) = (b − 40)² − 0.01b；箱容量为 100',fontsize=11)
x=np.arange(40,101);y=(x-40)**2-.01*x
ax.plot(x,y,color=BLUE,lw=1.6,marker='.',ms=3)
ax.set(xlim=(38,102),ylim=(-170,4100),xlabel='放入物品前的箱子剩余容量 b（可行整数：40–100）',ylabel='箱子优先级 S(b)（越大越优先）')
ax.set_xticks([40,50,60,70,80,90,100]);ax.set_yticks([0,1000,2000,3000,4000]);ax.grid(axis='y',color=GRID,lw=.7)
for b,label,xytext in [(40,'b = 40：−0.4\n恰好放下', (44,550)),(60,'b = 60：399.4',(63,1000)),(100,'b = 100：3599\nargmax 选择空箱',(77,3450))]:
 s=(b-40)**2-.01*b
 ax.scatter([b],[s],s=48,color=RED if b==100 else BLUE,zorder=5)
 ax.annotate(label,(b,s),xytext=xytext,fontsize=10,arrowprops=dict(arrowstyle='-',color='#6d7780',lw=.8))
fig.text(.11,.105,'整数域：S(b+1) − S(b) = 2(b−40) + 0.99 > 0；含空箱的可行集合按首次 argmax 选箱',fontsize=10)
fig.text(.11,.05,'说明：保存原程序的数学示意；连线仅辅助阅读，不是新算法、装箱运行或新增实验样本',fontsize=9,color='#58646f')
save(fig,'figure_01_candidate_score')
fig,axes=plt.subplots(1,2,figsize=(12.2,6.6),sharey=True)
fig.subplots_adjust(left=.085,right=.95,top=.75,bottom=.22,wspace=.38)
fig.text(.07,.94,'图 2  固定发表 EoH 在同五条序列上的前缀与全长结果',fontsize=16)
fig.text(.07,.881,'相对箱数差 Δ = 100 × (EoH − BF) / BF；负值表示 EoH 使用更少箱子',fontsize=11)
for ax,n,panel in zip(axes,[256,5000],['A','B']):
 rs=[r for r in rows if r['n_items']==n];yy=np.array([5,4,3,2,1,-.25])
 ax.set_title(f'{panel}   '+('前 256 项' if n==256 else '完整 5000 项'),loc='left',pad=28)
 ax.axvline(0,color='#68747e',lw=.8);ax.axhline(.35,color=GRID,lw=1)
 ax.set_xlim(-4,5.2);ax.set_ylim(-.85,5.75);ax.set_xticks([-4,-2,0,2,4]);ax.set_xticklabels(['−4%','−2%','0','+2%','+4%'])
 ax.set_yticks(yy);ax.set_yticklabels(['实例 0','实例 1','实例 2','实例 3','实例 4','合计'])
 ax.grid(axis='x',color=GRID,lw=.6);ax.set_axisbelow(True);ax.set_xlabel('相对箱数差 Δ')
 ax.text(1.04,1.04,'EoH / BF\n（箱数）',transform=ax.transAxes,ha='right',fontsize=9)
 for r,y in zip(rs,yy):
  v=r['relative_percent'];color=BLUE if v<0 else RED
  ax.hlines(y,min(v,0),max(v,0),color=color,lw=1.1)
  ax.scatter([v],[y],s=48 if r['instance']=='aggregate' else 34,marker='D' if r['instance']=='aggregate' else 'o',color=color,zorder=4)
  ax.annotate(f'{v:+.2f}%' if v else '0.00%',(v,y),xytext=(0,10),textcoords='offset points',ha='center',fontsize=9,color=color)
  ax.text(1.04,y,f"{r['eoh_bins']} / {r['bf_bins']}",transform=ax.get_yaxis_transform(),ha='right',va='center',fontsize=9,bbox=dict(facecolor='white',edgecolor='none',pad=1.2))
fig.text(.085,.12,'合计由总箱数计算，非逐实例百分比的平均：256 项为 +9 / 546 = +1.6484%；5000 项为 −328 / 10335 = −3.1737%',fontsize=9)
fig.text(.085,.06,'同源前缀与全长相互依赖，均为已暴露设计数据；仅作描述性比较，不报告置信区间、显著性或长度的因果规律',fontsize=9,color='#58646f')
save(fig,'figure_02_prefix_full_comparison')
writejson('source_hashes.json',sources)
caption='''# 中期报告插图说明（2026-10-05）

## 图 1 图注
candidate_01 原始保存程序的评分语义。固定物品大小 item=40、容量100，对全部可行整数剩余容量 b=40,…,100 绘制 S(b)=(b−40)²−0.01b。三个标记点为 S(40)=−0.4、S(60)=399.4、S(100)=3599。相邻整数的评分增量严格为正；当空箱参与可行集合且内层采用首次 argmax 时，选择剩余100的空箱。该图为原程序的数学示意，不是新候选、装箱实验或额外样本。原响应文字声称“negative squared slack”，但实际节点为正平方；本图不推断生成错误的心理或因果根源，也未修复原程序。

## 图 2 图注
固定发表 EoH 数学策略与 BF 在 historical_design_5k 同五条序列（原索引0–4）上的保存结果。A为各序列前256项，B为完整5000项；容量均为100，保留到达顺序。每个点显示 100×(EoH箱数−BF箱数)/BF箱数，右列给出原始箱数。菱形合计使用总数之比，而非逐实例百分比均值。前缀合计555 vs 546（+1.6484%），全长合计10007 vs 10335（−3.1737%）。两面板共享同源序列并相互依赖，不是10个独立样本；均为已暴露设计数据，不作盲测、总体优劣、置信区间、显著性或长度因果规律的声称。固定发表公式不等于完整EoH进化流程复现。

## 数据与可复现性
本目录脚本直接解析已保存JSON，验证原候选四节点和常数、五条256项前缀与5000项序列逐项匹配，以及256项回归箱数一致；仅计算图中算术，不重跑装箱、不调用模型、不新增实验。CSV、figure_data.json 保留整数箱数及相对百分比精确分数。SVG保留可编辑文本（需安装Noto Sans CJK字体），PDF内嵌字体，PNG为240 dpi。

复现：在同一仓库执行 python URP/docs/figures/20261005_method_audit/generate_figures.py。完整源文件 SHA-256 见 source_hashes.json；图及脚本哈希见 artifact_hashes.json。

### 源文件与 SHA-256
'''
for path,h in sources.items():caption+=f'\n- `{path}`\n  - SHA-256: `{h}`\n'
(OUT/'CAPTIONS_ZH.md').write_text(caption)
writejson('artifact_hashes.json',{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(OUT.iterdir()) if p.is_file() and p.name!='artifact_hashes.json'})
print('Rendered two figures; verified source program, five prefix relations, saved 256 regression counts.')
print([(r['n_items'],r['eoh_bins'],r['bf_bins'],r['relative_percent']) for r in rows if r['instance']=='aggregate'])
