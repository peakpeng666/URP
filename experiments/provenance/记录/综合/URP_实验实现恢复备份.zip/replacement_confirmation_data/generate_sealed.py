"""Pre-call confirmation replacement after an access deviation, never policy scoring."""
from pathlib import Path
import json,hashlib,sys,datetime
import numpy as np
ROOT=Path(__file__).resolve().parent;BASE=ROOT.parent
H=lambda b:hashlib.sha256(b).hexdigest()
C=lambda x:json.dumps(x,separators=(',',':'),ensure_ascii=False).encode()
old=(BASE/'eoh_evolution_holdout_v1/instances.json').read_bytes()
assert H(old)=='7cece4f062468f5f2c0daa54c11b106abba77c5fa2619f298a415390b4142011'
prior=[r['items'] for r in json.loads(old)['instances']];sources=[]
paths=[BASE/'paper_baseline_v1/data'/n for n in ('historical_numeric.json','numeric_datasets.json','instances.json')]+[BASE/n/'data/panel.json' for n in ('math_dag_evolution_v1','math_dag_evolution_compact_v2')]
def collect(x):
 if type(x)is list:
  if len(x)>=256 and all(type(v)in(int,float) for v in x):prior.append(x)
  else:
   for v in x:collect(v)
 elif type(x)is dict:
  for v in x.values():collect(v)
for p in paths:
 b=p.read_bytes();collect(json.loads(b));sources.append({'path':str(p.relative_to(BASE)),'sha256':H(b)})
rows=[]
for i,seed in enumerate(range(611050001,611050021),1):
 a=np.round(np.clip(np.random.RandomState(seed).weibull(3,5000)*45,1,100)).astype(np.int64).tolist()
 assert all(type(v)is int and 1<=v<=100 for v in a)
 assert not any(a[:min(len(a),len(b))]==b[:min(len(a),len(b))] for b in prior)
 assert not any(a==r['items'] for r in rows)
 rows.append({'id':f'confirmation_{i:02d}','capacity':100,'num_items':5000,'seed':seed,'items':a,'items_sha256':H(C(a))})
data=C({'schema_version':2,'purpose':'unscored confirmation set replaced before all new generation requests','instances':rows})+b'\n'
out=ROOT/'instances.json'
if out.exists():assert out.read_bytes()==data
else:out.write_bytes(data)
manifest={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'sealed_bytes_unscored','data_sha256':H(data),'data_bytes':len(data),'instances':20,'items_per_instance':5000,'capacity':100,'numpy':np.__version__,'python':sys.version,'generator_sha256':H(Path(__file__).read_bytes()),'source_commit':'e4b5ddba03b2b88025747e11c6049f8b529a4368','distribution':'45*RandomState(seed).weibull(3,5000), clip1..100, round, int64','replacement_reason':'Preparation worker accessed prior holdout through an inspection glob; no model request or policy fitness was computed. Replace before first new request and use fresh-context prompt work.','superseded_data_sha256':H(old),'prior_numeric_sequences_checked':len(prior),'prior_sources':sources,'new_model_calls_before_seal':0,'policy_evaluations':0,'scope':'New research instances, not official instances. Verify generator/protocol receipt and prohibit evaluation-model/prompt-builder access until locked-winner confirmation.'}
(ROOT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
public={'status':'sealed_bytes_unscored','data_sha256':H(data),'data_bytes':len(data),'count':20,'items_per_instance':5000,'capacity':100,'source_manifest_sha256':H((ROOT/'manifest.json').read_bytes()),'generator_sha256':manifest['generator_sha256'],'replaces_sha256':H(old),'model_calls':0,'policy_evaluations':0}
(ROOT/'HASH_ONLY_SEAL.json').write_text(json.dumps(public,indent=2)+'\n')
print(json.dumps(public))
