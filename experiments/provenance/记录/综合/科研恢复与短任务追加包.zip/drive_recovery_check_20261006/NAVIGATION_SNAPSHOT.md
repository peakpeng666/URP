# URP 实验入口与当前结果

## 新增离线分析与工程交接（2026-10-06 10:05 UTC）

本节补齐已交付的留族分析与 P2 工程材料。P1 第一代的独立接受、报告交付和 UI 评审候选交付状态保持不变；下方 08:15 UTC 及更早状态仍按各自时间戳阅读。

### BPP 前缀选择器留族分析（LOFO）

[归档目录](https://drive.google.com/drive/folders/1_rOpm-XeLt5_P2NTthNN8cKw9UcYXUCT) · [中文报告](https://docs.google.com/document/d/1YW3CbwG3Pst15adhtWYSis0nXCV6c6xb/edit) · [报告代码数据审计 ZIP](https://drive.google.com/file/d/1AgHWY6tBVEFTHZmzRvSBQEoIgMGNL9mG/view) · [完整结果 JSON](https://drive.google.com/file/d/1e2t-vfkEhi7kPbabEYBM6JSR0y_I18qK/view) · [本轮最终 CPU 账](https://drive.google.com/file/d/1Mb61EACt1u18zqPzVAcYrohAJKTLO6qO/view) · [交付下载与哈希核验](https://drive.google.com/file/d/1IvTPIzCCVVPDkHLHcUraB4pm_ChSN0gn/view)

这是对 **108 条已保存确认流**的追加离线反事实分析。六折每次留出一个分布族，仅用其余五族既有训练集的 **120 条流**拟合，在留出族的18条已保存确认流上评估；六折合并覆盖108条流各一次。没有新增 policy 运行或模型请求，也不是盲新资料评估。

选择器相对各折训练 SBS 的平均最终箱数差为 **+30.519 箱**，逐流 **35 胜、53 平、20 负**。相对同一前缀状态下合法分支的事后 oracle，最大后悔为 **622 箱**；相对 SBS 的最坏额外用箱也为622。结果保留为负面迁移证据，不作显著性或普遍泛化结论。

与先前同族分析相比，训练规模同时由144降为120，并剔除一个族；因此两次分析的差值不能单独归因于“分布外”因素。该分析与原132研究隔离，不将这些新结果反馈到原主线。CPU账单独列出，不改变早期研究历史900 CPU秒总合规仍无法认证的限制。

报告、结果与ZIP已下载核验，ZIP为12,984,997字节，SHA-256：`951e4987e9aafd92e0baaa82f165eb2ce8677d2ae9dc405be0987aa4b4c6bde8`；含1,307个文件、1,306条manifest内容核验。最终CPU账及交付核验亦在同目录。

### P2 工程交接与待确认动作

- [已绑定禁用输入的可移植预备包](https://drive.google.com/file/d/1vHrzTaZJqHgbzf31nTIBf4BwIab2ymQq/view)
- [跨环境静态补件 R2](https://drive.google.com/file/d/1pX5NQmDTVh0XCXAl-45fPqrVP_G6Gjy3/view)
- [生成接线 GEN 禁用操作包](https://drive.google.com/file/d/19BeOZsza2fYTc7yy3AmieUjF7O-qIXEm/view)
- [零模型 INIT 单次条件许可工程包](https://drive.google.com/file/d/1yztVXdHFWreM63BCtMSKSxk9WdCx90gj/view)

截至 **2026-10-06 10:05 UTC**，原生产任务已完成前三包的静态导入及静态补全，全部输入源保持不变，**第二代模型请求仍为0**。这些交接动作不等于第二代生成已经开始。

INIT 初始化派发被审批拒绝，当前等待用户明确确认是否允许新建两个私有 ChatGPT 云端实验记录文件：索引（index）与归档（archive）。**尚未取得该项用户确认，也未完成初始化。** 工程包中的条件许可不等于外部工具动作已经获准，不能把包已交付表述成初始化已执行。

UI 真实浏览器重试同样仍待用户答复。UI目前维持“已交付评审候选、真实双端验收未完成”的状态；P1已独立接受，但整个132槽研究尚未完成。

以下全部既有报告、导航链接与历史状态原样保留。

## 最新交付与阶段状态（2026-10-06 08:15 UTC）

本节补充已完成的 P1 阶段交付与科研界面实现候选。较早段落中的“P1 验收待定”“UI 实现进行中”等文字保留为其标注时刻的历史状态，当前已核交付以本节为准。

### 原 132 槽研究的 P1 阶段已独立接受

[中文阶段报告 PDF](https://drive.google.com/file/d/1zXi5eb-BeppN8FdhfJd4AmnnInG8r2Ks/view) · [可编辑报告 DOCX](https://docs.google.com/document/d/1CMhV7qWyRBfLEM4j5JpCRPEbL78s5w0L/edit) · [完整可审交付 ZIP](https://drive.google.com/file/d/1SYo9awdPdO9uVQBY6I18Llp0v4B7LFSO/view)

P1 的精确终态证据已于 **2026-10-06 07:55 UTC** 通过独立接受。该阶段共 60 次生成终态，包含 31 次空公开输出（length）；29 份准入输出完成 **145 个设计评分包**。加上 P0，累计为 **72/132 次生成、165 个设计评分包**。生成终态、准入输出与评分包是不同计数，不能互相替代。

这是 **P1 阶段完成并接受**，整个 132 槽研究尚未完成。现有交付没有 control、heldout 或 P2 结果，不据此提前宣称最终算法优势或留出集结论。P1 报告与完整证据已下载核验；完整 ZIP 为 5,368,638 字节，SHA-256：`aa14a4a33993850df91c2195b247ae5d29b9cb9d9d1ac845f913ce3b33b6178c`。

截至 **08:15 UTC**，P2 输入准备中，尚未发起该阶段模型请求；云模型接入正在恢复检查。后续生成、control 与 heldout 继续按各自阶段另行记录，本次导航不将输入准备计作实验运行。

### 科研界面已交付评审候选版

[响应式科研界面候选 ZIP](https://drive.google.com/file/d/1BQumnCvqEzham2WnMeV4AWm_aioedEo3/view) · [使用方法与验收边界](https://drive.google.com/file/d/1QQ7SYjpEgHUcnpGqHr6v8U_IJzUxsUz7/view)

已交付的实现候选提供四类真实保存历史记录的回放：函数检查点、装箱分配、NAS 候选／采样概率、DAG 身份与失败记录。新测试 **38/38**、旧完整回归 **229/229**、独立审阅 **42/42**通过；接受范围仅为 **review candidate（评审候选）**。

首屏静态／mock 预算为 **139,024 字节、7 个文件、2 个分片**，这不是实际手机加载速度、内存或帧率测量。**桌面与手机真实浏览器、触摸、原生文件导入下载及真实性能尚未验收**，不能称为双端浏览器验收通过。浏览器重试仍待确认；目前没有 GitHub 正式发布。

候选 ZIP 与说明已在原设计目录交付并下载核验。ZIP 为 33,223,861 字节，SHA-256：`9633598638684971968675ba16714b2d38bf217de40487f58af18a61984c05bb`。数据来自已保存历史快照，不能把 UI 日期当作实时研究状态，也不接入原 132 未决候选或留出结果。

以下保留全部既有导航、报告入口和带时间戳的历史记录。

导航核验日期：2026 年 10 月 6 日 06:37 UTC。本页集中列出已交付的独立研究、机制验证和私有 GitHub 工程。完整研究材料经 Google Drive 中转；原 EoH／IID 在线装箱部分保留带日期的历史进度，不能当作实时状态。

本次新增交付补充核验：2026 年 10 月 6 日 06:58 UTC。仅补充固定 EoH 分布与顺序检验及用途索引的快照说明，下方已有材料继续保留。

本次补充：2026 年 10 月 6 日 07:53 UTC 阶段状态，新增 BPP 前缀选择交付、科研界面设计交付和原主线数值阶段说明。下方较早时间的记录继续作为历史快照保留。

总目录：[实验项目](https://drive.google.com/drive/folders/1zs4eHCumbKPNV0ZnI9JWK6JnQHV1569T)

## 本轮新增交付导航

- [BPP 前缀算法选择与异未来风险](https://drive.google.com/drive/folders/1iaOJtPT5y1E6cPnfxmivpFFDODYCrY_H)：[中文报告](https://docs.google.com/document/d/1IU8_3fLsJ_GzqUP2Km4yoPIWBBJyj3CL/edit)、完整源码数据 ZIP、独立终审及资源回执；正面确认结果与风险负例并列。
- [科研界面响应式设计与参考](https://drive.google.com/drive/folders/1N3nLYmJCT0l0ZgWgv7MyrcUh87m5dWau)：[设计与只读评估](https://drive.google.com/file/d/1upXAPvUdUYQuVk_sysvCZfbZs2383vbp/view)已经交付；这是设计材料，界面实现与双端浏览器验收尚未完成。
- [固定 EoH 分布与到达顺序检验](https://drive.google.com/drive/folders/1vkmuCpl3CeC0cLrp15QdZ5q33KSvb4n2)：[中文报告](https://docs.google.com/document/d/1BVpQMGUHjN3mEct4qnqJ7gKi-zWIbxfZ/edit?usp=drivesdk&ouid=117339614533704968786&rtpof=true&sd=true)、完整证据 ZIP 与独立验收；固定公开公式的压力测试，与原 132 槽主线隔离。
- [P102 有限异构车具机制复验](https://drive.google.com/drive/folders/1afHMN-PhRV2_D2icaurqnyB9An2nq828)：[中文报告](https://drive.google.com/file/d/1v5FUZH5G7R8T807X2h54yFRwEhhEej_I/view)与[报告、源码、数据及独立审计 ZIP](https://drive.google.com/file/d/1CKDuVPp_7uLjqaaRG9nFuykrSUv_EqQ8/view)。
- [M06 DE 自适应评测预算复验](https://drive.google.com/drive/folders/11hu0vwmmPu5KhQI8YvCfBx092qXIZwUA)：[完整报告](https://drive.google.com/file/d/1Rko7CWtlRZcicDwva97iap2wJQ3skm8t/view)、[报告代码 ZIP](https://drive.google.com/file/d/1Mnw2PPlzFIAB3OsUK9MKFcP_BZyWaKBr/view)及原始轨迹；33 件正式交付已全部下载核验。
- [当前已核工程版 0.2.0rc1，NAS 第四模块](https://drive.google.com/drive/folders/1UfOdjlnBj_NjYfvvU1svO2481bHjmeez)：源码、独立工程审计、最终差分审计与[发布回执](https://drive.google.com/file/d/1YB3r3sMDzxacmYFve2IhPYzQJxBhvpOI/view)。原 0.1.0rc2 归档继续留存。
- [P4训练保真度与独立重训](https://drive.google.com/drive/folders/1REkWhOogD2FtnuG80QDj66soVD3JM5j5)：2/20轮排名、5个新seed确认、全部日志及权重；先读[阅读入口](https://drive.google.com/file/d/11PFoC39O_M1R0QaqgSOo1wrQPFQM1KES/view?usp=drivesdk)。
- [TSP 引导局部搜索](https://drive.google.com/drive/folders/1GtxAH6oDFEBxyc2s4Mwsj2uc6LMOdNlO)：实验报告、完整 ZIP 与结果图。
- [FSSP 固定扰动 ILS](https://drive.google.com/drive/folders/1MDQ4-mz-veUFPL9h66jEiqXRUGBgyVTW)：实验报告、完整 ZIP、汇总及随机种子结果图。排程示意图已在完整 ZIP 内。
- [父代选择离线回放](https://drive.google.com/drive/folders/15qPx716z4le9RsuQYMAPMLz7F90eqq-3)：中文报告 PDF 与完整实验 ZIP；行为多样性回放不等于后代搜索收益。
- [全库论文应用与两项机制验证](https://drive.google.com/drive/folders/1pwEHkEJF_p03mq-qmriPQ_c7Px8LrdV4)：先读目录内“阅读入口.md”；包含全库用途映射、CVRP 选择与 CRC、服务模式与转弯状态，以及各自证据边界。
- [历史工程交付 0.1.0rc2](https://drive.google.com/drive/folders/1SidtS8XEmGEfTZw9ELrfHW8R9BCTTMqj)：冻结源码 ZIP、独立审计 ZIP 和原始发布回执。
- [私有 GitHub 工程 peakpeng666/urp-research](https://github.com/peakpeng666/urp-research)：交付级源码、测试和复现配置。截至本页核验，0.2.0rc1 在父代选择、CVRP 选择与 CRC、转弯服务模式之外加入 NAS 训练保真度第四模块；其他独立实验仍从各自 Drive 目录读取。

全库 574 条资料的用途索引属于早期用途初筛快照，后续实验完成状态以本入口各独立报告为准。该索引不表示已完成 574 项独立研究，本次导航补充也不表示重新全文阅读全库；原用途索引及冻结 ZIP 保持原样。

上述新增目录及其文件清单已重新核对，用户保有所有者访问权限。各项报告中的限制继续有效，不将独立机制验证合并表述为完整论文复现或农业现场验证。以下 CVRP 固定算子配对与 DE 数值调参的已核验结果保留。

## BPP 前缀算法选择与异未来风险

[中文报告](https://docs.google.com/document/d/1IU8_3fLsJ_GzqUP2Km4yoPIWBBJyj3CL/edit) · [完整源码数据与审计 ZIP](https://drive.google.com/file/d/17k8juaylNTEpPsazDPTHq8CtySguGd9M/view) · [独立终审](https://drive.google.com/file/d/1Ad7FHiozmbdfWGEtQje-fjBl_oWfc5ZE/view) · [交付验收与资源回执](https://drive.google.com/file/d/1waMkGs6DZRFuk6NFk3om076m_TZmkIoR/view) · [归档目录](https://drive.google.com/drive/folders/1iaOJtPT5y1E6cPnfxmivpFFDODYCrY_H)

全部 **768 次真实运行**完成，保存完整 5,000 步轨迹，**3,840,000 步**独立复核通过。在预定 108 条合成确认流中，SELECTOR 相对训练得到的单一最佳分支 SBS（BF_then_EoH），平均最终箱数差为 **−21.454 箱**；按多重集分组 bootstrap 的 95%百分位区间为 **[−23.917, −19.380] 箱**。这是一项相对预定 SBS 的主比较，不能换成对所有算法或任意未来的优势。

12 条“相同合法前缀、不同未来”的构造风险流中，相对同一训练 SBS 反而平均 **多 25.333 箱，最坏多 152 箱**。这些风险流与主确认集分开统计。前缀信息合法不等于性能安全保证；本结果不支持新分布普遍优势，也不是完整 AutoFolio 复现。

科学数据终审通过，并披露一次验证器 I/O 缓存修订和重启；policy 本身没有失败重跑。**历史总计是否符合 900 CPU 秒预算仍为 NOT_ESTABLISHED（无法认证）**，不能把已测成本子集或前瞻余额称为完整历史成本。原始中断证据与未知项保留在独立终审和资源回执中。该独立研究继续与原 132 槽、P1 及 heldout 隔离，研究反馈不用于改写原主线。

完整 ZIP、中文 DOCX、独立终审及资源回执共 4 件已交付；ZIP、报告与审计均下载核验 SHA-256，回执另行下载核验。ZIP 为 25,366,752 字节，SHA-256：`5f47d49fade8f926bb5751818b038288a772b711d4249d70a7a392eeb9719350`；包内 1,915 个文件、1,914 条 manifest 内容校验通过。

## 科研界面响应式设计交付状态

[设计与只读评估](https://drive.google.com/file/d/1upXAPvUdUYQuVk_sysvCZfbZs2383vbp/view) · [设计及参考目录](https://drive.google.com/drive/folders/1N3nLYmJCT0l0ZgWgv7MyrcUh87m5dWau)

已交付的是科研控制台的桌面／手机响应式设计与现有静态代码评估，参考用户提供的截图组织方式。**原视频来源尚未确认**，不能据截图确认视频作者或原内容。设计交付不等于界面已经实现。

截至 **2026-10-06 07:53 UTC**，独立 UI 实现仍在进行，尚未通过桌面与手机双端真实浏览器验收。当前材料可以用于评审设计、历史快照／记录回放方式和验收条件，不能标为已上线产品或实时研究仪表盘。

## 固定 EoH 分布与到达顺序检验

[中文报告](https://docs.google.com/document/d/1BVpQMGUHjN3mEct4qnqJ7gKi-zWIbxfZ/edit?usp=drivesdk&ouid=117339614533704968786&rtpof=true&sd=true) · [完整证据 ZIP](https://drive.google.com/file/d/13vYkAN2cm52n3RR4PjIkBu6TEh6cWibS/view?usp=drivesdk) · [最终包独立验收](https://drive.google.com/file/d/1hzAoksDp4JymjRL1N359hqBo0322QZXD/view?usp=drivesdk) · [材料目录](https://drive.google.com/drive/folders/1vkmuCpl3CeC0cLrp15QdZ5q33KSvb4n2)

固定已发表 EoH 评分公式与 Best Fit，在 6 个随机分布族、每族 4 个新 seed 的同一多重集上比较随机、升序、降序三种输入流，另有 3 个互补构造。每流始终为 **5,000 件物品、容量 100**。共 172 次策略运行，其中 **162 次新压力测试、10 次历史公开设计校准**；全部 860,000 步放置及独立决策复核通过。三种顺序是配对压力条件，不是三份独立抽样，也没有赋予在线算法读取未来或自行排序的权限。

同一 Weibull 多重集上，随机到达时 EoH 平均比 Best Fit **少 66.75 箱**，降序到达时反而 **多 96 箱**，4 个 seed 全部出现排名反转。正面构造结果也完整保留：40+60 与 49+51 的升序流，EoH 用 2,500 箱达到有证 OPT，Best Fit 用 3,750 箱；25+75 的升序流则两者都用 3,125 箱，不能宣称所有构造均达到最优。

这是固定公开公式的有限分布与顺序压力测试，没有执行完整 EoH 演化或 RAISE 对抗搜索。本轮未读取原 132 槽 heldout 或进行中 P1 结果，新数据与反馈不进入原 132 第二代。不能把这些新 seed 称为原主线确认集，也不能将局部正负结果推广到所有 EoH 生成算法或现实部署分布。

完整 ZIP 为 7,171,683 字节，SHA-256：`ec92e7311f79c77aaaa73458017324c779af01ca03361c9c857e29d802b46019`。ZIP、中文 DOCX 和独立验收共 3 件均已下载回核；ZIP 含 317 个文件，316 条 manifest 内容校验及 CRC 通过。复查方案、全部流与轨迹、源代码、逐项结果和审计见完整包。

## P102 有限异构车具机制复验

[中文报告](https://drive.google.com/file/d/1v5FUZH5G7R8T807X2h54yFRwEhhEej_I/view) · [完整交付 ZIP](https://drive.google.com/file/d/1CKDuVPp_7uLjqaaRG9nFuykrSUv_EqQ8/view) · [材料目录](https://drive.google.com/drive/folders/1afHMN-PhRV2_D2icaurqnyB9An2nq828)

16 个随机配置中，遍历阶段一所有同值最优解的强两阶段基线 **16/16 达到联合最优**。因此没有证据表明联合优化在该随机面板普遍更好。预先构造的 E05/E06 边界例才展示固定阶段一目标可能排除完整可行方案或更低车辆成本的局限；固定任意 tie 的大差距不能冒充两阶段机制本身的普遍失败。随机配置与边界例分开报告，不能据此估计现实发生率。

中文 PDF、两张图与完整 ZIP 共 4 件已下载回核；ZIP 内 47 个文件及清单核验通过。独立审计结论为 PASS_WITH_SCOPE_LIMITATIONS，范围是共同仓库的有限异构车具机制，不是原论文完整复现或农业现场验证。

## M06 DE 自适应评测预算复验

[完整报告](https://drive.google.com/file/d/1Rko7CWtlRZcicDwva97iap2wJQ3skm8t/view) · [报告代码 ZIP](https://drive.google.com/file/d/1Mnw2PPlzFIAB3OsUK9MKFcP_BZyWaKBr/view) · [全部交付目录](https://drive.google.com/drive/folders/11hu0vwmmPu5KhQI8YvCfBx092qXIZwUA)

12 个独立候选池的配对调参试验中，逐次减半（SH）与均匀分配支付相同搜索目标评价预算；选出的配置在新实例和新 RNG 上从头确认。SH 相对均匀分配的块级胜/同/负为 **8/3/1**，但总体差值主要由 Sphere 推动，Ellipsoid 与 Rastrigin 的平均结果反而更差。这个结果不支持各类任务均改善或普遍收益，也不代表完整 Hyperband 或 LLaMEA-HPO 复现。

截至 2026-10-06 06:33 UTC 的交付回执，报告代码 ZIP、24 个原始轨迹 ZIP、8 件报告/图表/说明/清单，共 **33/33 件**均已下载并核验 SHA-256；无缺失文件。独立审计结论为 PASS_WITH_SCOPE_LIMITATIONS。原始分段和轨迹保留，续训分段不能重复计为独立运行。

## 当前已核工程版 0.2.0rc1 与冻结归档

[工程归档](https://drive.google.com/drive/folders/1UfOdjlnBj_NjYfvvU1svO2481bHjmeez) · [版本发布回执](https://drive.google.com/file/d/1YB3r3sMDzxacmYFve2IhPYzQJxBhvpOI/view)

- 精确源码快照为 [`ccda7d6f18e73812512f315e7cbd9483ef2c0d91`](https://github.com/peakpeng666/urp-research/commit/ccda7d6f18e73812512f315e7cbd9483ef2c0d91)，62 个文件与原 0.2.0rc1 源码 ZIP 对齐。
- 06:37 UTC 只读核验的 main 为文档修订 [`700b0723ba3faa989cc879b1dd0fbb11ca5d0e3f`](https://github.com/peakpeng666/urp-research/commit/700b0723ba3faa989cc879b1dd0fbb11ca5d0e3f)，仓库仍为 private。它只修订 README 与对应 manifest 条目；另外 60 个源码清单文件不变。此文档版本不能冒称与原源码 ZIP 逐字节一致。
- 三个 ZIP 和一份发布回执共 4 件已下载核验。源码 ZIP SHA-256：`fa3c5ad6b099ab493986f6f33e4b852cf27de86b3c009b375c4821912a9993d8`。完整逐文件身份与审计证据见版本发布回执。
- 发布验证记录为 73 项单测与 3 项原机制 smoke 通过；工程发布没有重新跑完一套新的 80 条轨迹/1,600 epoch，也未验证全新机器依赖安装、Windows、GPU或跨硬件一致性。原 NAS 研究结果与工程验证分开记账。

本次仅维护 Drive 导航，没有 GitHub 写入、实验重跑、冻结包替换或分享权限变更。下方 0.1.0rc2 章节是历史版本对齐记录，不代表当前 main。

## P4训练保真度与独立重训（2026-10-06新完成）

[先读简版](https://drive.google.com/file/d/11PFoC39O_M1R0QaqgSOo1wrQPFQM1KES/view?usp=drivesdk) · [完整中文报告](https://drive.google.com/file/d/1FJ47kgwZFrTxvQ9u1VMBt57dX1rPKI3-/view?usp=drivesdk) · [结果图与完整材料目录](https://drive.google.com/drive/folders/1REkWhOogD2FtnuG80QDj66soVD3JM5j5)

原8种CNN、原4,000训练/1,000验证划分与Adam配方固定，完成5个发现seed和另外5个确认seed，共80条从零训练轨迹、1,600epoch。独立验收4,635项通过，全部160个端点以不同batch重算的逐图预测一致，所有冻结文件与原P4文件未改。

5-seed均值下，2轮和20轮都选d3_w16_k5；独立重训validation均值40.92%，相对本面板确认组经验最好结构的后悔均0。但2/20轮全排名Kendall τ仅0.500；20轮排名对确认τ=0.929，2轮对确认τ=0.571。按单seed看，2轮有2/5选中不同于确认经验最好结构的模型，确认均值分别低8.86和5.24个百分点。这是本批小面板的描述，不能推作普适失败率，也不能把5-seed平均选择当原RL单次reward可靠。

正式训练主体36.63分钟单线程CPU，独立审核另20.66秒墙钟与160,000次validation推理；数据恢复、失败下载、安装和审核分账，GPU与新增模型API调用均0。20轮并无收敛证明，确认独立性仅限新训练seed；官方test未提取、未解析为样本、未推理。不是完整P176/P408/NAS复现，也没有证明RL优于随机。

报告代码与全部原始日志、两组权重分成[报告代码包](https://drive.google.com/file/d/1pP9hV6fTSV7juRhppanl9Ax7ezNGcklQ/view?usp=drivesdk)、[发现组权重包](https://drive.google.com/file/d/1cGEeJ24LfXHudGXMTCSfTF4ntESiK5wV/view?usp=drivesdk)、[独立重训权重包](https://drive.google.com/file/d/1Rj4g2qdx0fVqadMn2rYX-opMOq97oOLu/view?usp=drivesdk)。合并解压共683文件，9个正式交付文件已从Drive下载回核SHA256，三个ZIP内部CRC及682条内容hash全过。官方数据集/venv不随包分发，数据来源、原split及hash完整保留。本段保留原研究交付结果；其后发布的 NAS 第四模块工程与原研究分开验证，见上方 0.2.0rc1 说明。

## 历史工程版 0.1.0rc2 的文档与归档对齐

- 原候选冻结日期为 **2026-10-06 UTC**。精确发布快照为 [`06b551e3d4638c8634a8b9f3bc79bd5477de0cb3`](https://github.com/peakpeng666/urp-research/commit/06b551e3d4638c8634a8b9f3bc79bd5477de0cb3)，41 个文件与原源码 ZIP 相符。原 [发布回执](https://drive.google.com/file/d/1Lpti_H7YOJUOmOI12pWpHQc_OvMKLu3G/view) 的 hash 与审计结论均对应此快照。
- 该历史版本的 **docs-only revision** 为 [`3e5250b01fa32ea50776f38b139f93ecb5a7e4a3`](https://github.com/peakpeng666/urp-research/commit/3e5250b01fa32ea50776f38b139f93ecb5a7e4a3)，直接承接上述 commit。仅修改 README 的当前发布说明及 `SOURCE_PACKAGE_MANIFEST.json` 中对应的字节数和 SHA-256；另外 39 个文件不变。该修订当时已回读验证；现行已核 main 见上方 0.2.0rc1 记录。
- 该历史文档修订的 README：5931 字节，SHA-256 `4ad1d661badd8d3d6747e83874526d0b2fe0c72d25f627f22c73ee0718982af9`；对应 manifest：SHA-256 `e09c8f6cf641f0df6a52c2697991f9f077c2c93ccbb538731578c995dce2e1d4`。40 条文件校验全部通过，51 项单测与 3 项合成 smoke 通过；本次没有重跑完整历史实验，GitHub Actions 无此 commit 的运行记录。
- 原 README：4551 字节，SHA-256 `f4360781305180539f87fedb985e0ff56c37eba4fbd351d20f90c523b09695d1`。原源码 ZIP 的 SHA-256 仍为 `e93c1b19f9a3dc3e57eb34c60501becf52ded7a08322ab37135b20bc0c5984ae`；原审计 ZIP、原发布回执及研究结果均未改。本次文档修订不重新命名、替换或重发冻结包。

原源码 ZIP 与 `docs/RELEASE_CHECKLIST.md` 中的“尚未提交”“远程仅有初始化 README”等句子保留为候选审核时的历史陈述。本节仅说明 0.1.0rc2 的历史对齐关系；现行已核工程发布状态见上方 0.2.0rc1 记录。逐字节复核 0.1.0rc2 原审计快照时使用 `06b551e3`，不能把后续版本的 README 当作该冻结 README。

## 先前已交付的两项独立结果

### CVRP 固定算子配对

[实验报告](https://drive.google.com/file/d/1XzKa-qM1pTLWge-DSElMEI2Sv_q2WJXQ/view) · [完整材料目录](https://drive.google.com/drive/folders/1_s35K25Mw17HDbj26DSlNxYAvE9KuHt_)

8 个新合成开发实例，每实例比较 4 种 destroy／repair 配对、各 3 个搜索种子，共 96 次正式运行；另有 16 次独立 smoke 检查。全部通过可行性和成本重算。以每实例内先平均种子、再对 8 个实例等权平均，random + regret-2 相对统一 savings 初解改善 **1.4952%**，为本面板四种配对中最高。

可写入中期报告的结论：固定破坏与修复组件已经形成可复核的配对实验；在本轮小型合成开发面板及统一预算上限下，random + regret-2 的平均路线改善最高。统计单位为 8 个实例，种子只是实例内重复。43 次正式运行触及 delta 预算，相同上限并不代表相同实际工作量，因此不据此作纯算子因果或普适排名结论。

报告、冻结计划、实现、全部实例、逐次路线、CSV、图和审计均在 [CVRP 算子配对实验 ZIP](https://drive.google.com/file/d/1Vkl3nAuvnCu98PdFKf0No3zakzlHEAam/view)。解压后先读 REPORT_ZH.md；原始记录见 results/formal.jsonl，复核见 results/AUDIT.json。该实验验证固定组件，未运行完整 G-LNS、LLM 共演化或农业田间试验。

### 固定 DE 的数值调参

[实验报告](https://drive.google.com/file/d/1E4Jw_kqgvOKdj8COKxNBded2PrBp4veC/view) · [完整材料目录](https://drive.google.com/drive/folders/1SmmpdRQ6swkXOJnXjx63TebIGzgKy-zv)

固定 DE/rand/1/bin 结构，网格和随机搜索各用 162000 次目标评价选择参数，再用 270000 次评价作新开发重复。总计 **216 次运行、594000 次优化器目标评价**。全部候选点已保存，并以另一套目标公式独立重算通过。

网格选中 F=0.3、CR=0.5；随机选中 F≈0.37926634、CR≈0.53140763。两位赢家在 Sphere、Rastrigin、Ackley 各 6 个新种子上均优于默认 F=0.5、CR=0.9。

可写入中期报告的结论：固定 DE 结构的少量数值调参，在相同三个函数的新开发重复上改善了默认参数表现。调参成本须与赢家复评成本一并报告。新种子不等于新函数，当前证据不支持跨函数泛化、网格普遍优于随机搜索或完整 LLaMEA-HPO 复现。

先按[阅读说明](https://drive.google.com/file/d/1uInq8iTJVG4KBR8vrX7uIEFiJjWGiwnh/view)打开材料。代码、报告、汇总与审计在[报告代码 ZIP](https://drive.google.com/file/d/1CIn099yrJJb9AmeB9gSlQoFFtTHjbR5P/view)；[原始评价数据](https://drive.google.com/drive/folders/1KNvCKrJSUFzpjQLMjOBE0eHNin852z-G)按两个阶段和三个函数分成 6 个独立 ZIP，共 216 个 NPZ、594000 个评价点。七个 ZIP 解压到同一父目录即可合并；校验清单为 archive_manifest.json，包内 file_manifest.json 可检查文件完整性。

以上两项均在 dot 云端独立目录完成，**实验运行各为 0 次 LLM 调用**，与下列原装箱研究分开记账。新增材料 14/14 个文件、8 个 ZIP 已完成下载回读与完整性检查；03:15 UTC 的最终复核包含 CVRP 两处出版文字更新，实验数据未改变。

## 原在线装箱主线的已确认阶段状态

### 2026-10-06 07:53 UTC 阶段更新

原 132 槽研究的第一代数值阶段已完成 **145 个评分包（packs）**，正在进行独立终态验收（acceptance）；**P2 尚未启动**。这只标记该阶段数值执行完成，不表示整个 132 槽研究完成，也不提前宣布独立验收通过或算法改进。后续阶段以正式终态验收结论为准。

截至 **2026-10-06 06:24 UTC** 的阶段证据，固定 60 请求批次已全部生成终态，其中 31 次没有可用公开输出。数值评测阶段已启动，该时点尚无整个批次的数值终审结论。60 个生成终态不等于 60 个有效算法；本入口不发布未经最终核查的即时评分包数，也不据部分结果宣称算法改进。下面 03:08 UTC 的 37 终态记录继续作为历史快照保留。

## 原在线装箱研究的历史进度快照

以下记录对应 **2026-10-06 03:08 UTC** 的历史状态，本次只保留记录，不作为当前在线任务进度。原研究预定 132 个生成槽，比较 EoH 与独立采样（IID）。当时首批已完成 12 次生成、4 份准入输出和 20 次设计实例评分。20 次评分均可行，完整分配轨迹均与相同输入的 Best Fit（BF）一致，尚无优于 BF 的证据。

当时后续固定 60 请求批次在同一已有生产任务中运行。**截至 2026-10-06 03:08 UTC 的索引 v75，有 37 个生成请求达到终态，当时后续数值评测尚未开展。** 终态可能包含正常结束或失败，不能写成 37 个有效算法；生成完成也不能作为算法改进的结论。该数字仅是上述日期与时刻的历史快照，不是当前进度；后续以保存终态和数值审计为准。

## 独立诊断与后验评测已经完成

推理强度诊断另做 6 次请求：low 准入 3/3，high 准入 2/3。该诊断本身没有调用评分函数，不产生算法质量结论。

随后对其中 5 份固定源码，在 5 个已暴露设计输入上另做 25 次后验评测，25/25 可行，独立终态审计通过：3 份源码与 BF 的完整分配一致，2 份比 BF 用箱更多，无改进。评测阶段没有新增模型调用。这 6 次生成和 25 次评分独立保留，均不计入原 132 槽研究；两档各 3 次也不足以判断推理强度的稳定优劣。

报告可在下方恢复证据包中查找 fixed_design_results_report_20261005/report_zh.md；逐次结果来自 glm53_fixed_design_followon_20261005/RESULTS.json，推理诊断见 glm53_effort_diagnostic6_report_20261005/推理强度诊断.md。

## 旧项目与过程证据在哪里

- [URP 实验项目基底包](https://drive.google.com/file/d/1aP70xUxndLe35IcgKN5wspz7A1wiNccx/view)：云端版本最后更新于 10 月 5 日 00:57 UTC，用于基础代码、教师实践和早期结果。它不包含本页新增导航中的独立交付，包内状态文字应按其快照日期阅读
- [运行恢复证据包](https://drive.google.com/file/d/1NpbwW0kLd4eC23hBlrwlyFGnXrh_1HAs/view)：保留原研究、独立诊断及后验评测的阶段证据。过程快照不等于原研究已经全部完成；本轮已交付结果以本页导航列出的各独立目录为准

已有教师基础实验与历史研究不因本次整理重算。完整 EoH 演化收益、多问题统一系统、原创方法验收及农业场景有效性，仍需各自的后续证据。
