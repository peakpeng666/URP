# 科研 Drive 交付恢复性只读核验

核验日期：2026-10-06，11:13–11:20 UTC。此报告是交付材料的当前可访问性及有限完整性核验，不是重新运行实验或生产恢复。

## 结论

- 总入口中的 57 个独立 Drive 链接均可访问。连同入口本身及新发现的 INIT 停止证据，共核验 59 个对象；元数据读取失败 0、空文件 0。
- 17 个导航目录均可列出非空内容；返回的直接子项均不足 100，没有触及本次目录读取上限。没有声称递归核验目录内全部原始训练文件。
- 59 个对象均显示用户为唯一 owner、shared=false。未修改任何权限。
- 重新下载 28 件较小文件及核心包，合计 9,965,711 字节。23 件与已归档回执中的精确 SHA-256 匹配，失配 0；另 5 件计算了当前原字节 SHA-256，但本轮没有将其绑定到独立的旧 hash 记录，不能称为跨时点字节一致。
- P1、P2 输入、R2、GEN、INIT、最新停止证据共 6 个 ZIP 的 CRC 及 1,988 条 manifest 内容 hash 全部通过。没有执行包内代码。
- 没有发现核心链接误指空文件、其他阶段包或不相符的标题/类型。UI 大包及训练/历史大包等 14 件文件未在本轮重新全量下载，当前内容仍以已有回执配合元数据佐证，不能由“存在”推出本轮全部字节不变。

## 重要时效差异：入口尚未列出新的 INIT 停止证据

[总入口](https://drive.google.com/file/d/1FRH6xcIu9dogrib7XftIUF1GekevOsAL/view?usp=drivesdk)最后修改于 10:08:26 UTC，正文最新状态截至 10:05 UTC。当前下载为 30,789 字节，SHA-256 为 17e42889aaf12afd3145d8c840be45cd318a30277c9c7a67322f12824633b081，与 10:08 的历史回执一致。

总目录于 11:11:53 UTC 新增[INIT 停止证据 ZIP](https://drive.google.com/file/d/1Rlor7jbZ7eoeTVnW0VhUpLyeXj1tAIx8/view?usp=drivesdk)，旧入口未列出。包内 STOP_REPORT.json 的观察时刻为 11:10:39 UTC，记录：

- index 写入响应为 succeeded，版本 0，859 字节，但读回未确认。
- archive 创建未尝试，尚无 archive ID；pending fence 仍保留，未清除。
- 完整 INIT 测量/回执链未完成；模型请求、候选执行、数值运行均为 0。
- 因此入口中的“尚未取得确认、未初始化”只能按其 10:05 历史时间阅读。恢复时应采用新的“部分写入已确认、读回未确认并停止”边界，不能据旧入口重放创建、清空 fence 或启动 GEN。

本轮只读取停止包并验证其 30 个成员的 CRC、29 条内容 hash，没有尝试补全初始化、读写其 Library 记录或解除停止状态。精确 index 身份与证据摘要保存在 INDEX.json 的 important_update 字段，属于恢复定位材料。

## 指定核心交付

### P1 完整可审包

[原132槽研究_P1阶段完整可审交付_20261006.zip](https://drive.google.com/file/d/1SYo9awdPdO9uVQBY6I18Llp0v4B7LFSO/view?usp=drivesdk)

- 大小：5,368,638 字节
- 核验：当前完整原字节已下载；与旧回执 hash 一致。
- SHA-256：aa14a4a33993850df91c2195b247ae5d29b9cb9d9d1ac845f913ce3b33b6178c

### P1 中文 PDF

[原132槽研究_P1中文阶段报告_20261006.pdf](https://drive.google.com/file/d/1zXi5eb-BeppN8FdhfJd4AmnnInG8r2Ks/view?usp=drivesdk)

- 大小：571,764 字节
- 核验：当前完整原字节已下载；与旧回执 hash 一致。
- SHA-256：cfa37c10078a3999e6e37c5e8ba5d6062c113de729d75406c449264fcdd92a3e

### UI 评审候选 ZIP

[responsive_research_console_20261006_REVIEW_CANDIDATE.zip](https://drive.google.com/file/d/1BQumnCvqEzham2WnMeV4AWm_aioedEo3/view?usp=drivesdk)

- 大小：33,223,861 字节
- 核验：本轮核验元数据；以下 hash 来自既有下载回执，本轮未重下大包。
- SHA-256：9633598638684971968675ba16714b2d38bf217de40487f58af18a61984c05bb

### P2 已绑定禁用输入

[原132槽研究_P2已绑定禁用输入_可移植预备包_20261006.zip](https://drive.google.com/file/d/1vHrzTaZJqHgbzf31nTIBf4BwIab2ymQq/view?usp=drivesdk)

- 大小：1,944,110 字节
- 核验：当前完整原字节已下载；与旧回执 hash 一致。
- SHA-256：b48fcbf84aab8def4f676d3b12873926683d116c309ccdd3efb5116726a13760

### P2 静态补件 R2

[原132槽研究_P2跨环境静态补件_R2_20261006.zip](https://drive.google.com/file/d/1pX5NQmDTVh0XCXAl-45fPqrVP_G6Gjy3/view?usp=drivesdk)

- 大小：915,390 字节
- 核验：当前完整原字节已下载；与旧回执 hash 一致。
- SHA-256：a344c7651a0cabdbe1f5ec4ba68192b8c41a41657d1b01e62e74392576d14ace

### P2 GEN 禁用操作包

[原132槽研究_P2生成接线_禁用操作包_20261006.zip](https://drive.google.com/file/d/19BeOZsza2fYTc7yy3AmieUjF7O-qIXEm/view?usp=drivesdk)

- 大小：99,840 字节
- 核验：当前完整原字节已下载；与旧回执 hash 一致。
- SHA-256：f82d52e6095b810acb1991db8cbb386480a1c96559c22190ee0b336e74022918

### P2 INIT 条件许可工程包

[原132槽研究_P2零模型初始化_单次条件许可包_20261006.zip](https://drive.google.com/file/d/1yztVXdHFWreM63BCtMSKSxk9WdCx90gj/view?usp=drivesdk)

- 大小：51,408 字节
- 核验：当前完整原字节已下载；与旧回执 hash 一致。
- SHA-256：373ae922980bc25c6fe8a41d2fdba8978a53b5d2281512cad419a409add83540

### BPP 留族分析 DOCX

[BPP前缀选择器留族外推分析.docx](https://docs.google.com/document/d/1YW3CbwG3Pst15adhtWYSis0nXCV6c6xb/edit?usp=drivesdk&ouid=117339614533704968786&rtpof=true&sd=true)

- 大小：39,833 字节
- 核验：当前完整原字节已下载；与旧回执 hash 一致。
- SHA-256：ee3be218c477a1f7ad10436c0242398d918ccc112b2899b558a26b9b11a0be1b

### P2 INIT 最新停止证据

[原132槽研究_P2_INIT停止证据_index读回未确认_20261006.zip](https://drive.google.com/file/d/1Rlor7jbZ7eoeTVnW0VhUpLyeXj1tAIx8/view?usp=drivesdk)

- 大小：45,392 字节
- 核验：当前原字节已下载，CRC 与内容 manifest 通过；当前 hash 不冒称为旧回执的独立交叉认证。
- SHA-256：ca21bf7717fefb52d27437cd2373ac6021ea6260182a29a1d9a1a15ca287c04e

## 恢复阅读顺序与版本边界

1. 从用户自有的[实验项目目录](https://drive.google.com/drive/folders/1zs4eHCumbKPNV0ZnI9JWK6JnQHV1569T)及总入口进入；保留本报告和 INDEX.json 作为当前链接、名称、大小、hash 与来源回执索引。
2. 原 132 槽研究先恢复 P1 阶段包和报告。P1 被接受不代表全部 132 槽研究完成，P2 工程包存在不代表 P2 生成/数值已执行。
3. P2 保留输入包 → R2 → GEN → INIT 的角色顺序，并同时保留最新停止证据。后续动作须先处理既有写入与 pending fence 的证据一致性，不能重复创建或把静态工程验收当作生产成功。
4. UI 包明确为 REVIEW_CANDIDATE，真实桌面/手机浏览器验收仍有边界；目录内设计文件并非新的 UI 实现版本。
5. 0.2.0rc1 工程目录位于 0.1.0rc2 归档目录下，这是本次读取到的实际层级。导航已明确区分当前已核工程版和历史版本，不应将历史基底/恢复包当作包含全部新增研究的总包。
6. LOFO、P1 可编辑报告、BPP 前缀选择报告、固定 EoH 报告虽使用 docs.google.com 链接，实际 MIME 均为 DOCX；恢复下载应保留原始 .docx 字节，不能把它们误当原生 Google 文档导出。

## 本轮未重新全字节核验的 14 件文件

- [responsive_research_console_20261006_REVIEW_CANDIDATE.zip](https://drive.google.com/file/d/1BQumnCvqEzham2WnMeV4AWm_aioedEo3/view?usp=drivesdk)：33,223,861 字节
- [BPP留族外推_报告代码数据审计_20261006.zip](https://drive.google.com/file/d/1AgHWY6tBVEFTHZmzRvSBQEoIgMGNL9mG/view?usp=drivesdk)：12,984,997 字节
- [LOFO完整结果.json](https://drive.google.com/file/d/1e2t-vfkEhi7kPbabEYBM6JSR0y_I18qK/view?usp=drivesdk)：1,006,445 字节
- [P102_有限异构车具机制_中文报告.pdf](https://drive.google.com/file/d/1v5FUZH5G7R8T807X2h54yFRwEhhEej_I/view?usp=drivesdk)：676,555 字节
- [P102_报告源码数据与独立审计_20261006.zip](https://drive.google.com/file/d/1CKDuVPp_7uLjqaaRG9nFuykrSUv_EqQ8/view?usp=drivesdk)：2,872,012 字节
- [M06_report_code.zip](https://drive.google.com/file/d/1Mnw2PPlzFIAB3OsUK9MKFcP_BZyWaKBr/view?usp=drivesdk)：3,184,302 字节
- [BPP前缀安全选择_完整源码数据与审计_20261006.zip](https://drive.google.com/file/d/17k8juaylNTEpPsazDPTHq8CtySguGd9M/view?usp=drivesdk)：25,366,752 字节
- [固定EoH分布与顺序检验_完整证据_20261006.zip](https://drive.google.com/file/d/13vYkAN2cm52n3RR4PjIkBu6TEh6cWibS/view?usp=drivesdk)：7,171,683 字节
- [P4_报告代码与原始日志_20261006.zip](https://drive.google.com/file/d/1pP9hV6fTSV7juRhppanl9Ax7ezNGcklQ/view?usp=drivesdk)：9,553,403 字节
- [P4_发现组权重_20261006.zip](https://drive.google.com/file/d/1cGEeJ24LfXHudGXMTCSfTF4ntESiK5wV/view?usp=drivesdk)：24,732,887 字节
- [P4_独立重训权重_20261006.zip](https://drive.google.com/file/d/1Rj4g2qdx0fVqadMn2rYX-opMOq97oOLu/view?usp=drivesdk)：24,727,814 字节
- [independent_de_hpo_20261006_report_code.zip](https://drive.google.com/file/d/1CIn099yrJJb9AmeB9gSlQoFFtTHjbR5P/view?usp=drivesdk)：907,174 字节
- [URP_实验项目.zip](https://drive.google.com/file/d/1aP70xUxndLe35IcgKN5wspz7A1wiNccx/view?usp=drivesdk)：62,376,435 字节
- [URP_实验实现恢复备份_20261005.zip](https://drive.google.com/file/d/1NpbwW0kLd4eC23hBlrwlyFGnXrh_1HAs/view?usp=drivesdk)：13,532,986 字节

这些项只证明本轮元数据可访问。INDEX.json 逐项列明可定位的历史 hash 及 source_receipt；未定位到明确旧 hash 的项保留空值，没有补造验证结果。两个 CVRP 文件的旧编辑前 hash 与编辑后 hash 同时保留，当前重新下载匹配的是最终 03:13 版本；不会把历史 hash 差异误报为当前损坏。

5 件已新下载但本轮未绑定独立旧 pin 的文件为：本轮最终 CPU 账、交付下载与哈希核验、科研界面设计与只读评估、最终交付验收与资源回执，以及最新 INIT 停止证据。其当前 hash 可直接用于今后下载校验。

## 明确未做及不作保证的事项

- 未上传、改写、移动或删除云端文件，未更改分享权限；没有模型调用、实验重跑或外部状态恢复。
- 未重下数百 MB 原始轨迹/训练资料；未验证全新机器环境、依赖安装或实际执行可复现性。
- 导航中的 5 个 GitHub 链接不属此次 Drive 检查范围，未以本报告宣称其当前可访问。
- 本结果只证明上述时点的访问与所述范围的完整性，不承诺永久保存、会员变化后工具仍可用，或未来账号、文件、权限永远不变。

## 配套索引

INDEX.json 是结构化恢复索引，含 59 对象的 ID、已验证 Drive URL、名称、MIME、大小、修改时间、父目录、owner/shared、原字节抽验结果、历史 SHA-256 来源和目录直接子项列表。NAVIGATION_SNAPSHOT.md 是本轮下载的入口原字节副本，未经改写。
