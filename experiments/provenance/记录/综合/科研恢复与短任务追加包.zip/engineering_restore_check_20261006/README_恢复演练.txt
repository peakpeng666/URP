URP 工程源码恢复小演练
2026-10-06 UTC

结论
从已审源码 ZIP 新解压后，73 项标准库单元测试与 3 项离线合成 smoke 全部通过，退出码均为 0。
本次是现有 Linux / CPython 3.12.14 云环境内的 ZIP 恢复演练，不是新操作系统、干净安装或跨平台验收。

源码与发布身份
- 私有仓库：https://github.com/peakpeng666/urp-research
- 当前 main：700b0723ba3faa989cc879b1dd0fbb11ca5d0e3f
- 精确已审源码快照：ccda7d6f18e73812512f315e7cbd9483ef2c0d91
- 源包：urp-research-v0.2.0-rc.1-source.zip，188,579 字节
- SHA-256：fa3c5ad6b099ab493986f6f33e4b852cf27de86b3c009b375c4821912a9993d8
- 全部 62 文件逐 Git blob 身份匹配精确快照，内置 61 条清单全通过；测试后源码与原 ZIP 哈希未变。
- main 只改 README 与对应清单。冻结 ZIP 中“尚未发布”等旧措辞按审核时的历史状态阅读，当前私有发布状态以 main 为准。不要为更新状态而修改冻结 ZIP。

最快恢复
1. 解压上述精确源码 ZIP，进入 urp-research 目录。
2. 使用 Python 3.10+；本次实测为 CPython 3.12.14，无需安装任何第三方依赖。
3. 运行 python -S scripts/test.py。
4. 运行 python -S scripts/urp.py smoke。
不要使用 -O 或 -OO。测试中的优化模式调用是故意检查“拒绝运行”的边界用例。

本次为限制风险，用独立标准库 harness 执行未经修改的原脚本，而非修改源码：
- 单测主进程硬 CPU 限额 90 秒；仅允许原测试的 4 个子进程，各硬 CPU 限额 5 秒；smoke 主进程 10 秒，合计前瞻分配 120 秒。
- 两阶段合用 300 秒墙钟截止时间，超时杀死活动进程组。
- 实测受测进程树 CPU 0.761185 秒，墙钟约 0.833 秒。
- 监督、准备、生成报告及打包开销另列；此数值不代表整个历史工程、整个会话或所有工具 CPU 总量。

完整历史数据入口
源码包不含历史数据。旧三模块按 docs/DATA_RESTORE.md 下载两份有权限的固定 Drive 包，再通过 restore 导入白名单文件。具体来源、字节数、SHA-256 与命令在本报告 JSON 的 data_restoration 中保留。
NAS 按 docs/NAS_FIDELITY.md 分开恢复三份证据 ZIP 与官方 CIFAR binary 归档，后者只导入五个训练 batch。
旧模块测试/smoke 和 NAS sources/restore/import-data/verify 不需要 NumPy 或 PyTorch；NAS 数值命令文档固定为独立 CPython 3.12 + NumPy 2.5.3 + CPU PyTorch 2.14.1+cpu。本次未安装或验证这些可选依赖，也未运行 NAS 数值复算。
缺数据或哈希不符应停止，不要修改清单、补随机数据或覆盖已有输出。

须分开的界面候选
responsive_research_console_20261006_REVIEW_CANDIDATE.zip 是另一份已审实现候选，不属于本工程源码或这次测试结果。其本地交接仍注明真实浏览器/手机/桌面视觉验收未完成；本次没有补验界面。
界面展示历史保存快照，不是原132实时状态、未决分数或留出结果，不能将其当作正式双端视觉验收通过或本工程的新正式发布。

明确未验
未测干净安装、Windows、GPU、跨硬件一致性、GitHub CI、完整历史数据恢复/重放、NAS 160 端点、任何新训练/实验、界面视觉验收。
未安装依赖、调用模型/API、做网络测试、上传、推仓库或改权限。原源码包与原工程目录未作为写入目标。

证据文件
- engineering_restore_check_20261006.json：完整机器可读结论与范围
- source_inventory.json / source_inventory.sha256：62 文件身份清单
- execution_receipt.json：命令、exit、CPU/墙钟、前瞻硬限制
- unit.stdout.log / unit.stderr.log：73 项测试输出
- smoke.stdout.log / smoke.stderr.log：3 项合成 smoke 输出
- nested_process_slots.jsonl：4 个原测试子进程分配
- evidence/：只读 GitHub 源快照/当前树身份及当前 README
- guarded_worker.py / run_restore_check.py：此次资源限制与执行 harness
- framework_save_accounting.json / ZIP旁附的 package_receipt.json：报告和打包开销另列

本证据包不代替原已审源码 ZIP；恢复应使用上面固定身份的原 ZIP。
