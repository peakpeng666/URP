"""Frozen matched-size diagnostic, legal archived branch lookup only.
No input generation, policy invocation, model API calls or source-file writes.
"""
import pathlib,json,hashlib,itertools,collections,csv,datetime,time
import numpy as np
H=pathlib.Path(__file__).resolve().parent; ROOT=H.parent
O=ROOT/'independent_bpp_prefix_selection_20261006'; L=ROOT/'independent_bpp_selector_family_transfer_20261006'
START=time.process_time(); FROZEN_PROTOCOL='b6d1e301e5643920b6a8f4f9ce911824c4833de3718f824b791ede18eae2bc5f'
read=lambda p:json.loads(p.read_bytes()); sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
P=read(H/'PROTOCOL.json'); assert sha(H/'PROTOCOL.json')==FROZEN_PROTOCOL
B=['BF','BF_then_EoH']; F=P['families']; E={}; phases=[]
def put(name,value):
    with (H/name).open('x') as out:json.dump(value,out,ensure_ascii=False,indent=2,allow_nan=False);out.write('\n')
def pin(path,expected=None):
    digest=sha(path)
    if expected is not None:assert digest==expected,('source hash mismatch',str(path))
    E[str(path.relative_to(ROOT))]=digest
    return digest

def gate():
    # Artifact roots and original audit evidence are inherited, then current bytes
    # are verified. No trajectory decompression or score/policy calls occur.
    pin(L/'MANIFEST.json'); lm=read(L/'MANIFEST.json')['files']
    relatives=['PROTOCOL.json','PREEXEC_FREEZE.json','analysis/SOURCE_PANEL.json','analysis/RESULTS.json','audit/INDEPENDENT_AUDIT.json','audit/COUNTERFACTUAL_SUFFICIENCY.json','evidence/SOURCE_MANIFEST.json']
    for rel in relatives:pin(L/rel,lm[f'{L.name}/{rel}']['sha256'])
    lp=read(L/'PROTOCOL.json')
    for rel,digest in lp['immutable_source_files'].items():pin(O/rel,digest)
    original_manifest=read(O/'independent_audit/RESULT_EVIDENCE_MANIFEST.json')['files']
    transfer_evidence=read(L/'evidence/SOURCE_MANIFEST.json')['files']
    audit=read(L/'audit/INDEPENDENT_AUDIT.json'); proof=read(L/'audit/COUNTERFACTUAL_SUFFICIENCY.json')
    assert audit['passed'] and audit['checks']['archives']==504 and audit['checks']['common_prefix_streams']==252
    assert audit['checks']['state_transition_steps']==2520000 and audit['all_108_predictions_recomputed']
    assert proof['passed'] and proof['complete_legal_branches']==504 and proof['common_first500_arrays_and_state']
    assert proof['prefix_only_features_recomputed']==252
    meta=[r for r in read(O/'PROTOCOL.json')['instances'] if r['split'] in ('train','confirmation')]
    assert len(meta)==252 and len({r['instance_id'] for r in meta})==252
    # Freeze actual group draws before producer feature/cost panel is consulted.
    train_meta=[r for r in meta if r['split']=='train']; assert len(train_meta)==144
    specifications=[]
    for rep,pair in enumerate(itertools.combinations(F,2)):
        rng=np.random.Generator(np.random.PCG64(202610060000+rep)); keep=set(); groups_by_family={}
        for f in F:
            groups=list(dict.fromkeys(r['group_id'] for r in train_meta if r['family']==f)); assert len(groups)==8
            selection=set(rng.choice(len(groups),size=6 if f in pair else 7,replace=False).tolist())
            selected=[g for i,g in enumerate(groups) if i in selection]
            groups_by_family[f]=selected; keep.update(selected)
        ids=[r['instance_id'] for r in train_meta if r['group_id'] in keep]
        assert len(keep)==40 and len(ids)==120
        specifications.append({'rep_index':rep,'seed':202610060000+rep,'six_group_families':list(pair),'groups_by_family':groups_by_family,'train_ids':ids})
    put('SAMPLES_FROZEN.json',{'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'selection_uses':'original metadata and specified RNG only; no features, labels or confirmation rows','replicates':specifications})
    rows=read(L/'analysis/SOURCE_PANEL.json'); assert len(rows)==252
    assert [r['instance_id'] for r in rows]==[r['instance_id'] for r in meta]
    group_counts=collections.Counter(r['group_id'] for r in rows); assert set(group_counts.values())=={3}
    for m,r in zip(meta,rows):
        for key in ['instance_id','group_id','split','family','replicate','order']:assert r[key]==m[key]
        assert len(r['features'])==31 and all(np.isfinite(r['features']))
        pair=[]
        for ix,b in enumerate(B):
            rel=f"raw/{r['instance_id']}__{b}.json"; pin(O/rel,original_manifest[rel]); assert E[f'{O.name}/{rel}']==transfer_evidence[rel]
            raw=read(O/rel)
            assert raw['instance_id']==r['instance_id'] and raw['branch']==b and raw['policy']==b
            assert raw['status']=='complete' and raw['error'] is None and raw['steps']==5000 and raw['selector_consumed_count']==500
            assert raw['prefix_features']==r['features'] and raw['used_bins']==r['costs'][ix]
            assert raw['prefix_remaining_sha256']==r['prefix_state_sha256']
            traj=f"raw/{r['instance_id']}__{b}.npz"; assert raw['trajectory_file']==traj
            pin(O/traj,original_manifest[traj]); assert E[f'{O.name}/{traj}']==raw['trajectory_sha256']==transfer_evidence[traj]
            pair.append(raw)
        assert pair[0]['items_sha256']==pair[1]['items_sha256']
        assert pair[0]['prefix_remaining_sha256']==pair[1]['prefix_remaining_sha256']
    for split,ngroup in [('train',8),('confirmation',6)]:
        for f in F:
            part=[r for r in rows if r['family']==f and r['split']==split]
            assert len(part)==3*ngroup and len({r['group_id'] for r in part})==ngroup
            for g in {r['group_id'] for r in part}:assert [r['order'] for r in part if r['group_id']==g]==P['orders']
    for rel in ['analysis/SUMMARY.json','analysis/confirmation_per_stream.csv']:pin(O/rel,original_manifest[rel])
    put('SOURCE_SUFFICIENCY.json',{'passed':True,'streams':252,'legal_branch_metadata_verified':504,'trajectory_file_hashes_verified':504,'prefix_feature_vectors_matched':252,'common_prefix_hash_pairs_matched':252,'inherited_full_state_transition_steps':2520000,'new_full_state_transition_steps':0,'inherited_audit':f'{L.name}/audit/INDEPENDENT_AUDIT.json','inherited_legality':f'{L.name}/audit/COUNTERFACTUAL_SUFFICIENCY.json','scope':'Current metadata, feature, cost and source/trajectory-byte integrity checked; full BF500 common arrays, prefix feature reconstruction and full trajectory legality inherited from referenced already-completed independent audits. No new packing execution; no original 132-stream dataset consulted.'})
    return rows,specifications

c=time.process_time();rows,specs=gate();phases.append({'phase':'source_hashes_sufficiency_and_frozen_sampling','cpu_seconds':time.process_time()-c})
train={r['instance_id']:r for r in rows if r['split']=='train'}; tests=[r for r in rows if r['split']=='confirmation']
assert len(tests)==108 and not ({r['group_id'] for r in train.values()}&{r['group_id'] for r in tests})

def aggregate(preds):
    n=len(preds); costs=np.array([p['costs'] for p in preds],dtype=np.int64)
    selected=np.array([p['selected_index'] for p in preds],dtype=np.int64); sbs=np.array([p['sbs_index'] for p in preds],dtype=np.int64)
    values=costs[np.arange(n),selected]; base=costs[np.arange(n),sbs]; oracle=costs.min(axis=1); delta=values-base; regret=values-oracle
    return {'n':n,'mean_bins':{'selector':float(values.mean()),'SBS':float(base.mean()),'branch_oracle':float(oracle.mean())},'selector_minus_SBS_mean':float(delta.mean()),'selector_oracle_regret_mean':float(regret.mean()),'selector_oracle_regret_max':int(regret.max()),'worst_harm_vs_SBS':int(delta.max()),'best_gain_vs_SBS':int(-delta.min()),'W_T_L_vs_SBS':[int((delta<0).sum()),int((delta==0).sum()),int((delta>0).sum())],'choices':{'BF':int((selected==0).sum()),'BF_then_EoH':int((selected==1).sum())},'different_from_SBS_count':int((selected!=sbs).sum()),'prediction_tie_count':sum(p.get('prediction_tie',False) for p in preds),'worst_regret_instances':[p['instance_id'] for p,v in zip(preds,regret) if v==regret.max()]}

def describe(values):
    v=np.array(values);return {'mean':float(v.mean()),'median':float(np.median(v)),'min':float(v.min()),'max':float(v.max()),'values':values}
def summarize_distribution(reps):
    def block(agg):return {'selector_minus_SBS_mean':describe([a['selector_minus_SBS_mean'] for a in agg]),'selector_oracle_regret_mean':describe([a['selector_oracle_regret_mean'] for a in agg]),'worst_regret':describe([a['selector_oracle_regret_max'] for a in agg]),'worst_harm_vs_SBS':describe([a['worst_harm_vs_SBS'] for a in agg]),'BF_count':describe([a['choices']['BF'] for a in agg]),'BF_then_EoH_count':describe([a['choices']['BF_then_EoH'] for a in agg])}
    return {'pooled':block([r['pooled'] for r in reps]),'per_family':{f:block([r['per_family'][f] for r in reps]) for f in F}}

c=time.process_time(); models=[]
for spec in specs:
    tr=[train[i] for i in spec['train_ids']]; assert len(tr)==120
    assert len({r['family'] for r in tr})==6 and len({r['group_id'] for r in tr})==40
    x=np.array([r['features'] for r in tr],dtype=np.float64); y=np.array([r['costs'] for r in tr],dtype=np.int64)
    mu=x.mean(0); sd=x.std(0,ddof=0); sd=np.where(sd==0,1.0,sd); z=(x-mu)/sd
    sbs=int(np.argmin(y.mean(0)))
    models.append({'train_ids':spec['train_ids'],'mean':mu.tolist(),'scale':sd.tolist(),'z':z.tolist(),'costs':y.tolist(),'training_mean_costs':y.mean(0).tolist(),'sbs_index':sbs})
put('TRAINING_MODELS_FROZEN.json',{'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'before_producer_predictions':True,'models':models})
replicates=[]
for spec,model in zip(specs,models):
    preds=[]; z=np.array(model['z']); y=np.array(model['costs']); mu=np.array(model['mean']); sd=np.array(model['scale']); sbs=model['sbs_index']
    for r in tests:
        query=(np.array(r['features'])-mu)/sd; distances=np.sum((z-query)**2,axis=1); nn=np.argsort(distances,kind='stable')[:5]
        pc=y[nn].mean(0); tie=bool(pc[0]==pc[1]); ix=sbs if tie else int(np.argmin(pc)); costs=r['costs']; oracle=min(costs)
        preds.append({**{k:r[k] for k in ['instance_id','group_id','family','order','costs']},'neighbor_indices':nn.tolist(),'neighbor_ids':[model['train_ids'][i] for i in nn],'squared_distances':distances[nn].tolist(),'predicted_costs':pc.tolist(),'prediction_tie':tie,'selected_index':ix,'sbs_index':sbs,'selector_bins':costs[ix],'SBS_bins':costs[sbs],'oracle_bins':oracle,'selector_minus_SBS':costs[ix]-costs[sbs],'selector_regret':costs[ix]-oracle})
    replicates.append({'rep_index':spec['rep_index'],'model':model,'predictions':preds,'pooled':aggregate(preds),'per_family':{f:aggregate([p for p in preds if p['family']==f]) for f in F}})
result={'schema':'bpp-matched-size-results-v1','interpretation':P['status'],'replicates':replicates,'distribution':summarize_distribution(replicates),'policy_runs':0,'generated_inputs':0,'model_API_calls':0}
put('RESULTS.json',result); phases.append({'phase':'15_numpy_models_1620_predictions_and_aggregates','cpu_seconds':time.process_time()-c})

# Separate implementation runs before reading any primary predictions for comparison.
c=time.process_time(); import verify_separately
second=verify_separately.verify(O,P,specs)
put('SECOND_IMPLEMENTATION_RESULTS.json',second)
compared=0; maximum_abs=0.0

def compare(a,b,path='root'):
    global compared,maximum_abs
    if isinstance(a,dict):
        assert set(a)==set(b),(path,'keys',set(a)^set(b))
        for k in a:compare(a[k],b[k],path+'.'+k)
    elif isinstance(a,list):
        assert len(a)==len(b),(path,'list length')
        for i,(x,y) in enumerate(zip(a,b)):compare(x,y,path+f'[{i}]')
    elif isinstance(a,bool) or isinstance(a,str) or a is None:assert a==b,(path,a,b)
    elif isinstance(a,int) and isinstance(b,int):assert a==b,(path,a,b);compared+=1
    else:
        difference=abs(a-b);maximum_abs=max(maximum_abs,difference);compared+=1
        assert difference<=1e-10,(path,a,b,difference)
compare({'replicates':replicates,'distribution':result['distribution']},second)
phases.append({'phase':'independent_stdlib_recomputation_and_exact_decision_comparison','cpu_seconds':time.process_time()-c})

# References are descriptive only and are loaded after all fixed new decisions.
c=time.process_time(); original_csv=list(csv.DictReader((O/'analysis/confirmation_per_stream.csv').open()))
refs=[]
for r in original_csv:
    costs=[int(r[b]) for b in B]; ix=B.index(r['selected_branch']); sbs=1
    assert int(r['SBS'])==costs[sbs] and int(r['SELECTOR'])==costs[ix] and int(r['branch_oracle'])==min(costs)
    refs.append({'instance_id':r['instance_id'],'family':r['family'],'costs':costs,'selected_index':ix,'sbs_index':sbs})
assert [r['instance_id'] for r in refs]==[r['instance_id'] for r in tests]
full=aggregate(refs); published=read(O/'analysis/SUMMARY.json')['confirmation']
assert full['selector_minus_SBS_mean']==published['selector_minus_SBS_mean']
assert full['choices']==published['choices'] and full['W_T_L_vs_SBS']==published['W_T_L_vs_SBS']
lf=read(L/'analysis/RESULTS.json'); lfref=lf['pooled']
ref_lofo=aggregate(lf['predictions'])
for key in ['selector_minus_SBS_mean','selector_oracle_regret_mean','selector_oracle_regret_max','worst_harm_vs_SBS','W_T_L_vs_SBS']:assert ref_lofo[key]==lfref[key]
assert ref_lofo['choices']['BF_then_EoH']==lfref['switch_to_EoH_count']
references={'original_full_family_144':{'training_streams':144,'train_families':6,'aggregate':full,'per_family':{f:aggregate([r for r in refs if r['family']==f]) for f in F},'prediction_tie_count_available':False},'LOFO_120':{'training_streams_per_fold':120,'train_families_per_fold':5,'aggregate':ref_lofo,'per_family':{a['family']:a for a in lf['per_family']},'fold_SBS_branches':[m['sbs_branch'] for m in lf['models']]},'interpretation':'Same 108 confirmation streams. The full144 model predicts all108; each LOFO120 model predicts only its heldout18, pooled across6 folds. Matched-size reps each predict all108, including families represented in training. No causal or significant-difference inference.'}
# Existing CSV does not store prediction ties, so explicitly omit the unknown field.
del references['original_full_family_144']['aggregate']['prediction_tie_count']
for aggregate_ref in references['original_full_family_144']['per_family'].values():del aggregate_ref['prediction_tie_count']
put('DESCRIPTIVE_REFERENCES.json',references)
for rel,digest in E.items():assert sha(ROOT/rel)==digest,('source changed',rel)
put('SOURCE_MANIFEST.json',{'root':'parent directory of this analysis','files':E,'verified_unchanged_after_analysis':True,'total_files':len(E),'sources_read_only':True})
validation={'passed':True,'author_independence':'Two independently written numerical implementations by the same agent, not different reviewers. Shared prescribed PCG64 sampler family but independently constructed group lists. Second numeric fit/prediction/aggregation uses standard library and original raw JSON, not producer arrays or helpers.','replicates_verified':15,'predictions_verified':1620,'exact_neighbor_ids_verified':True,'exact_branch_decisions_verified':True,'exact_training_SBS_verified':True,'all_pooled_and_family_aggregates_verified':True,'all_distribution_summaries_verified':True,'numeric_values_compared':compared,'numeric_absolute_tolerance':1e-10,'maximum_absolute_difference':maximum_abs,'source_files_unchanged':len(E),'inherited_trajectory_audit':True,'new_policy_runs':0,'new_inputs':0,'model_API_calls':0}
put('VALIDATION.json',validation)
phases.append({'phase':'descriptive_references_and_postanalysis_source_integrity','cpu_seconds':time.process_time()-c})

D=result['distribution']['pooled']; delta=D['selector_minus_SBS_mean']; reg=D['worst_regret']; count=D['BF_then_EoH_count']
fmt=lambda n:f'{n:.6f}'
lines=['# 全族匹配训练规模诊断（探索性离线重放）','','## 结论',f"15个预定全6族、120条训练子样本，在同108条已观察确认流上，selector−本rep训练SBS的均值分布：平均 {fmt(delta['mean'])} 箱，中位 {fmt(delta['median'])} 箱，范围 [{fmt(delta['min'])}, {fmt(delta['max'])}] 箱；负数为selector较好。",f"描述性对照：原全6族144条训练为 {fmt(full['selector_minus_SBS_mean'])} 箱；原120条、缺1族LOFO为 {fmt(lfref['selector_minus_SBS_mean'])} 箱。",'','这些固定全族120子样本给出一个同训练条数的参照，可帮助判断原LOFO落差是否在保留所有族时同样出现。它没有单独识别“缺一族”的因果效应：训练分布、每族样本密度、所预测族是否被训练覆盖与kNN几何均不同，144→120也仍可能与覆盖及样本选择交互。15个子样本大量重叠，同组的三顺序相关，不能当作15次独立试验或新的盲测；不做显著性声明，也不选最佳rep作为结论。','','## 冻结方案与计量口径','- 原6族顺序下枚举15个二族组合；rep从0编号，PCG64种子202610060000+rep。二族各选6个multiset，其余四族各选7个，每组3顺序全留，共40组、120条。抽样只使用组元数据和固定随机数，保留原训练行序。','- 沿原31个BF500前缀特征、每rep训练集标准化、k=5、稳定邻居与训练SBS平局规则；每rep训练SBS仅来自自身120条训练标签。','- 只查BF与BF_then_EoH两条共享BF500状态的完整旧分支；oracle仅为这两条分支的逐流较优者，全程EoH未作为oracle。新策略运行、输入生成、模型API调用均为0。',f"- 每rep的训练SBS分支：{dict(collections.Counter(B[m['sbs_index']] for m in models))}。",'- 一次数值+验证子进程，CPU硬限117秒；简单启动器硬限2秒，合计名义119秒并留1秒余量。真实exit、用户/系统CPU与stdout/stderr见PROCESS_RESOURCE.json和RUN.log。工具/LLM/前期文本检查不在此计量范围；启动器最终日志写入及退出尾不精确测量，不能宣称完全all-in。','','## 15个rep全数结果','|rep|各留6组的两个族|selector−SBS均值|BF / BF→EoH选择数|最坏合法分支后悔|','|---:|---|---:|---:|---:|']
for spec,rep in zip(specs,replicates):
    a=rep['pooled'];lines.append(f"|{spec['rep_index']}|{'、'.join(spec['six_group_families'])}|{fmt(a['selector_minus_SBS_mean'])}|{a['choices']['BF']} / {a['choices']['BF_then_EoH']}|{a['selector_oracle_regret_max']}|")
lines+=['',f"每rep BF→EoH选择数平均 {fmt(count['mean'])}，中位 {fmt(count['median'])}，范围 [{count['min']:g}, {count['max']:g}] /108；最坏单流合法分支后悔在rep间平均 {fmt(reg['mean'])}，中位 {fmt(reg['median'])}，范围 [{reg['min']:g}, {reg['max']:g}] 箱。",'','## 逐族selector−SBS均值分布','每族每rep均为18条确认流；“范围”是15个固定rep之间的范围，不是置信区间。','|族|15rep平均|中位|范围|原144|原LOFO120|','|---|---:|---:|---:|---:|---:|']
for f in F:
    d=result['distribution']['per_family'][f]['selector_minus_SBS_mean']; of=references['original_full_family_144']['per_family'][f]['selector_minus_SBS_mean']; lo=references['LOFO_120']['per_family'][f]['selector_minus_SBS_mean']
    lines.append(f"|{f}|{fmt(d['mean'])}|{fmt(d['median'])}|[{fmt(d['min'])}, {fmt(d['max'])}]|{fmt(of)}|{fmt(lo)}|")
lines+=['','## 核验与恢复入口',f"- 第二份实现独立重读原始分支JSON，用标准库重算15个模型、1620条预测、SBS、邻居和全部聚合；{compared}个数值对比通过，最大绝对差 {maximum_abs:.3g}。由同一agent编写两种实现，不称为不同审阅员。",f"- {len(E)}个已用源文件哈希前后相同；504条分支metadata与504个轨迹文件哈希核对通过。共同前500步数组、状态转移与特征重建继承原已审证据，没有再次跑252万步。",'- PROTOCOL.json及PROTOCOL.sha256：结果读取/计算前的固定方案；SAMPLES_FROZEN.json列每rep组ID与训练行；TRAINING_MODELS_FROZEN.json记录预测前模型。','- RESULTS.json含全15rep/逐流邻居、两分支预测、选择结果及逐族指标；SECOND_IMPLEMENTATION_RESULTS.json与VALIDATION.json为重算和核验。','- DESCRIPTIVE_REFERENCES.json保存原144与LOFO对照；SOURCE_SUFFICIENCY.json / SOURCE_MANIFEST.json引用原合法共同前缀证据及逐文件哈希。','- analyze.py、verify_separately.py、bounded_run.py为两实现与限额启动器；MANIFEST.json列交付文件。恢复时需保留同级两个原实验目录，脚本不读取其他实验。','- 这是附加诊断，不修改或替代原研究协议、原报告或原结果。']
(H/'REPORT_ZH.md').write_text('\n'.join(lines)+'\n')
(H/'README.md').write_text('本目录为已观察确认集上的一次探索性匹配训练规模诊断。先读REPORT_ZH.md，再读VALIDATION.json与PROCESS_RESOURCE.json。结果不包含新策略运行或新盲测。原实验目录保持只读；复现需同级两个source目录，复现时先复制本目录到新输出目录，避免覆盖当前证据。代码在报告/JSON已存在时会拒绝覆写。\n')
put('PHASE_TIMING.json',{'phases':phases,'process_cpu_through_before_final_status_seconds':time.process_time()-START,'scope':'Internal partial timing only; actual whole child plus wrapper scope in PROCESS_RESOURCE.json.'})
put('COMPLETION.json',{'status':'complete','completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'replicates':15,'predictions':1620,'validation_passed':True,'primary':delta,'provenance':'exploratory matched-size offline diagnostic, not fresh blind confirmation','source_policy_runs':0})
print(json.dumps({'status':'complete','primary':delta,'per_family':{f:result['distribution']['per_family'][f]['selector_minus_SBS_mean'] for f in F},'choices_EoH':count,'worst_regret':reg,'validation':validation},ensure_ascii=False,indent=2),flush=True)
