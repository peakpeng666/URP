"""Second implementation by the same agent; stdlib numeric fit/predict/aggregate.
Only the mandated PCG64 group sampler uses NumPy. No producer numeric helpers.
Re-reads original branch JSON; does not import/reuse the SOURCE_PANEL features.
"""
import json, math, pathlib, statistics

def verify(original, protocol, expected_sample_specs):
    import numpy as np
    read=lambda p:json.loads(p.read_text())
    meta=[m for m in read(original/'PROTOCOL.json')['instances'] if m['split'] in ('train','confirmation')]
    families=protocol['families']; branch=('BF','BF_then_EoH')
    combinations=[]
    for a in range(5):
        for b in range(a+1,6):combinations.append((a,b))
    specifications=[]
    for rep,(a,b) in enumerate(combinations):
        gen=np.random.Generator(np.random.PCG64(202610060000+rep)); keep=set(); chosen={}
        for pos,family in enumerate(families):
            groups=[]
            for m in meta:
                if m['split']=='train' and m['family']==family and m['group_id'] not in groups:groups.append(m['group_id'])
            assert len(groups)==8
            pick=gen.choice(len(groups),size=6 if pos in (a,b) else 7,replace=False)
            chosen[family]=[g for i,g in enumerate(groups) if i in set(int(x) for x in pick)]
            keep.update(chosen[family])
        ids=[m['instance_id'] for m in meta if m['split']=='train' and m['group_id'] in keep]
        spec={'rep_index':rep,'seed':202610060000+rep,'six_group_families':[families[a],families[b]],'groups_by_family':chosen,'train_ids':ids}
        assert spec==expected_sample_specs[rep]
        specifications.append(spec)
    def row(m):
        first=read(original/'raw'/f"{m['instance_id']}__BF.json")
        second=read(original/'raw'/f"{m['instance_id']}__BF_then_EoH.json")
        assert first['prefix_features']==second['prefix_features']
        assert first['prefix_remaining_sha256']==second['prefix_remaining_sha256']
        return dict(m,features=first['prefix_features'],costs=[first['used_bins'],second['used_bins']])
    training={m['instance_id']:row(m) for m in meta if m['split']=='train'}
    models=[]
    for spec in specifications:
        tr=[training[i] for i in spec['train_ids']]; n=len(tr); assert n==120
        means=[math.fsum(r['features'][j] for r in tr)/n for j in range(31)]
        scales=[math.sqrt(math.fsum((r['features'][j]-means[j])**2 for r in tr)/n) for j in range(31)]
        scales=[s if s!=0 else 1.0 for s in scales]
        zx=[[ (r['features'][j]-means[j])/scales[j] for j in range(31)] for r in tr]
        total=[sum(r['costs'][j] for r in tr) for j in range(2)]; sbs=0 if total[0]<=total[1] else 1
        models.append({'train_ids':spec['train_ids'],'mean':means,'scale':scales,'z':zx,'costs':[r['costs'] for r in tr],'training_mean_costs':[t/n for t in total],'sbs_index':sbs})
    # All models are fitted before second-implementation confirmation JSON reads.
    tests=[row(m) for m in meta if m['split']=='confirmation']; assert len(tests)==108
    output=[]
    for spec,model in zip(specifications,models):
        predictions=[]
        for test in tests:
            q=[(test['features'][j]-model['mean'][j])/model['scale'][j] for j in range(31)]
            ds=[math.fsum((train[j]-q[j])**2 for j in range(31)) for train in model['z']]
            neighbors=sorted(range(len(ds)),key=lambda idx:(ds[idx],idx))[:5]
            sums=[sum(model['costs'][idx][j] for idx in neighbors) for j in range(2)]
            decision=model['sbs_index'] if sums[0]==sums[1] else (0 if sums[0]<sums[1] else 1)
            costs=test['costs']; sb=model['sbs_index']; minimum=min(costs)
            predictions.append({'instance_id':test['instance_id'],'group_id':test['group_id'],'family':test['family'],'order':test['order'],'costs':costs,'neighbor_indices':neighbors,'neighbor_ids':[model['train_ids'][idx] for idx in neighbors],'squared_distances':[ds[idx] for idx in neighbors],'predicted_costs':[s/5 for s in sums],'prediction_tie':sums[0]==sums[1],'selected_index':decision,'sbs_index':sb,'selector_bins':costs[decision],'SBS_bins':costs[sb],'oracle_bins':minimum,'selector_minus_SBS':costs[decision]-costs[sb],'selector_regret':costs[decision]-minimum})
        output.append({'rep_index':spec['rep_index'],'model':model,'predictions':predictions,'pooled':summarize(predictions),'per_family':{f:summarize([p for p in predictions if p['family']==f]) for f in families}})
    return {'replicates':output,'distribution':distribution(output,families)}

def summarize(predictions):
    n=len(predictions); selector=[p['selector_bins'] for p in predictions]; sbs=[p['SBS_bins'] for p in predictions]
    delta=[a-b for a,b in zip(selector,sbs)]; regrets=[p['selector_bins']-min(p['costs']) for p in predictions]
    return {'n':n,'mean_bins':{'selector':sum(selector)/n,'SBS':sum(sbs)/n,'branch_oracle':sum(min(p['costs']) for p in predictions)/n},'selector_minus_SBS_mean':sum(delta)/n,'selector_oracle_regret_mean':sum(regrets)/n,'selector_oracle_regret_max':max(regrets),'worst_harm_vs_SBS':max(delta),'best_gain_vs_SBS':-min(delta),'W_T_L_vs_SBS':[sum(x<0 for x in delta),sum(x==0 for x in delta),sum(x>0 for x in delta)],'choices':{'BF':sum(p['selected_index']==0 for p in predictions),'BF_then_EoH':sum(p['selected_index']==1 for p in predictions)},'different_from_SBS_count':sum(p['selected_index']!=p['sbs_index'] for p in predictions),'prediction_tie_count':sum(p.get('prediction_tie',False) for p in predictions),'worst_regret_instances':[p['instance_id'] for p,x in zip(predictions,regrets) if x==max(regrets)]}

def distribution(replicates,families):
    def desc(values):return {'mean':statistics.mean(values),'median':statistics.median(values),'min':min(values),'max':max(values),'values':values}
    def block(aggregates):return {'selector_minus_SBS_mean':desc([a['selector_minus_SBS_mean'] for a in aggregates]),'selector_oracle_regret_mean':desc([a['selector_oracle_regret_mean'] for a in aggregates]),'worst_regret':desc([a['selector_oracle_regret_max'] for a in aggregates]),'worst_harm_vs_SBS':desc([a['worst_harm_vs_SBS'] for a in aggregates]),'BF_count':desc([a['choices']['BF'] for a in aggregates]),'BF_then_EoH_count':desc([a['choices']['BF_then_EoH'] for a in aggregates])}
    return {'pooled':block([r['pooled'] for r in replicates]),'per_family':{f:block([r['per_family'][f] for r in replicates]) for f in families}}
