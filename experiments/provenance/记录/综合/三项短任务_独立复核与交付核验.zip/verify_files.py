#!/usr/bin/env python3
"""Read-only verification of this recovery package. Never runs experiment code."""
from pathlib import Path
import hashlib,json,sys
root=Path(__file__).resolve().parent
m=json.loads((root/'FILE_MANIFEST.json').read_text(encoding='utf-8'))
failed=[]
for rel,row in m['files'].items():
 p=root/rel
 if p.is_symlink() or not p.is_file() or root not in p.resolve().parents:
  failed.append(rel+': missing, symlink, or outside package');continue
 b=p.read_bytes()
 if len(b)!=row['bytes'] or hashlib.sha256(b).hexdigest()!=row['sha256']:
  failed.append(rel+': size/hash mismatch')
print(json.dumps({'passed':not failed,'files_checked':len(m['files']),'failures':failed},ensure_ascii=False,indent=2))
sys.exit(1 if failed else 0)
