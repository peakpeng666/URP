# 三项短实验独立复核恢复入口

本目录为独立旁件，不修改三项实验的原始协议、代码、记录或报告。

先读 SHORT_AUDIT_REPORT_ZH.md；每项的完整发现见 BPP_AUDIT_ZH.md、DE_AUDIT_ZH.md、PATHFINDING_AUDIT_ZH.md。机器可读结论与所查来源分别保存在 *_AUDIT.json 和 *_SOURCE_MANIFEST.json。PATHFINDING_CPU_TIMING_AUDIT.json 保存原先缺失的 CPU 零时长分组诊断。

检查源码：audit_bpp.py、audit_de.py、audit_pathfinding.py、pathfinding_check_core.py。三份 *.log 和 *_resources.json 是各受限验证的原始输出、实测 CPU/wall 与退出码。run_bounded_audit.py 为简单有界启动器。AUDIT_PLAN.json 与 AUDIT_FINALIZATION_PLAN.json 记录前瞻范围及限额；RESOURCE_TOTALS.json 汇总实际计算，FINAL_DELIVERY_INTEGRITY.json 另核最终生产交付清单。

恢复需要本目录与三项生产目录放在同一级，并保留原 BPP 源实验目录。检查脚本重执行会进行同输入验证，但当前日志使用独占创建，应先复制为新审计输出目录，避免覆盖当前证据。不要把同字节审计重放计成新增科学样本。
