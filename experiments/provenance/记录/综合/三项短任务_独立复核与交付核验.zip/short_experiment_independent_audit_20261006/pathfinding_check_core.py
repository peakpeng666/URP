"""Independent reviewer arithmetic and traversal, no producer imports."""
import heapq,collections
V=((1,0),(0,1),(-1,0),(0,-1))

def angle(before,after):
    dot=V[before][0]*V[after][0]+V[before][1]*V[after][1]
    return (0 if dot==1 else 2 if dot==-1 else 1)

def lower(state,goal,weight,mode):
    if mode=='dijkstra':return 0
    x,y,d=state;ax=goal[0]-x;ay=goal[1]-y;walk=abs(ax)+abs(ay)
    if mode=='astar_manhattan' or not walk:return walk
    needs=[]
    if ax:needs.append(0 if ax>0 else 2)
    if ay:needs.append(1 if ay>0 else 3)
    # Explicitly minimize heading changes along all orders of required axes.
    turn=min(angle(d,a) for a in needs) if len(needs)==1 else min(angle(d,needs[0])+1,angle(d,needs[1])+1)
    return walk+weight*turn

def exact_cost(rows,start,goal,w):
    # Integer-cost bucket queue, different ordering/representation from tested heap.
    n=len(rows); total=n*n*4; infinity=10**18
    def ix(x,y,h):return 4*(y*n+x)+h
    dist=[infinity]*total; sid=ix(*start);dist[sid]=0
    buckets=collections.defaultdict(collections.deque);buckets[0].append(sid)
    active=1;now=0
    while active:
        if not buckets.get(now):now+=1;continue
        sid=buckets[now].popleft();active-=1
        if dist[sid]!=now:continue
        cell,h=divmod(sid,4);y,x=divmod(cell,n)
        if [x,y]==list(goal):return now
        for d,(vx,vy) in enumerate(V):
            nx=x+vx;ny=y+vy
            if nx<0 or ny<0 or nx>=n or ny>=n or rows[ny][nx]!='.':continue
            nid=ix(nx,ny,d);nd=now+1+w*angle(h,d)
            if nd<dist[nid]:dist[nid]=nd;buckets[nd].append(nid);active+=1
    return None

def replay_counters(rows,start,goal,w,mode):
    # Exact frozen heap ordering is necessary to reproduce claimed counts.
    start=tuple(start);goal=tuple(goal);q=[(lower(start,goal,w,mode),0,*start,0)];best={start:0};seen=set();sequence=0
    counter=dict(expansions=0,accepted_pops=0,stale_pops=0,heap_pushes=1,max_heap=1,reexpansions=0,successor_candidates=0,traversable_successors=0)
    n=len(rows);goal_cost=None
    while q:
        _,cost,x,y,h,_=heapq.heappop(q);state=(x,y,h)
        if cost!=best[state]:counter['stale_pops']+=1;continue
        counter['accepted_pops']+=1
        if state[:2]==goal:goal_cost=cost;break
        counter['expansions']+=1
        if state in seen:counter['reexpansions']+=1
        seen.add(state)
        for nxt in range(4):
            counter['successor_candidates']+=1
            a=x+V[nxt][0];b=y+V[nxt][1]
            if a<0 or b<0 or a>=n or b>=n or rows[b][a]!='.':continue
            counter['traversable_successors']+=1
            target=(a,b,nxt);tentative=cost+1+w*angle(h,nxt)
            if target in best and tentative>=best[target]:continue
            best[target]=tentative;sequence+=1
            heapq.heappush(q,(tentative+lower(target,goal,w,mode),tentative,*target,sequence))
            counter['heap_pushes']+=1;counter['max_heap']=max(counter['max_heap'],len(q))
    assert counter['accepted_pops']==counter['expansions']+(goal_cost is not None)
    assert counter['successor_candidates']==counter['expansions']*4
    assert counter['reexpansions']==0
    return goal_cost,counter

def verify_route(rows,start,goal,w,r,cost):
    assert r['reachable']==(cost is not None) and r['cost']==cost
    if cost is None:assert r['path']==[];return {'steps':None,'turn_units':None,'recomputed_cost':None}
    path=r['path'];assert path and path[0]==list(start) and path[-1][:2]==list(goal)
    for x,y,d in path:assert 0<=y<len(rows) and 0<=x<len(rows[y]) and rows[y][x]=='.' and d in range(4)
    turns=0
    for (x,y,d),(a,b,e) in zip(path,path[1:]):
        assert (a-x,b-y)==V[e];turns+=angle(d,e)
    assert len(path)-1+w*turns==cost
    return {'steps':len(path)-1,'turn_units':turns,'recomputed_cost':cost}
