"""Independent matched-size audit. No producer numeric helpers imported."""
import json,pathlib,hashlib,itertools,collections,statistics,math,datetime,csv
import numpy as np
H=pathlib.Path(__file__).resolve().parent; ROOT=H.parent
B=ROOT/'independent_bpp_matched_size_20261006'; O=ROOT/'independent_bpp_prefix_selection_20261006'
read=lambda p:json.loads(p.read_text()); sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
P=read(B/'PROTOCOL.json'); producer=read(B/'RESULTS.json'); sample=read(B/'SAMPLES_FROZEN.json')['replicates']
manifest=read(B/'MANIFEST.json')['files']; integrity={}
for rel,v in manifest.items():
    assert sha(B/rel)==v['sha256'],rel
    integrity[str((B/rel).relative_to(ROOT))]=v['sha256']
source=read(B/'SOURCE_MANIFEST.json')['files']
for rel,v in source.items():
    assert sha(ROOT/rel)==v,rel
    integrity[rel]=v
meta=[r for r in read(O/'PROTOCOL.json')['instances'] if r['split'] in ['train','confirmation']]
trainmeta=[r for r in meta if r['split']=='train']; confirm=[r for r in meta if r['split']=='confirmation']
assert len(trainmeta)==144 and len(confirm)==108
assert not (set(r['group_id'] for r in trainmeta)&set(r['group_id'] for r in confirm))
assert not (set(r['multiset_sha256'] for r in trainmeta)&set(r['multiset_sha256'] for r in confirm))
# Draw only from original metadata, before loading features/costs.
families=P['families']; specs=[]
for rep,small in enumerate(itertools.combinations(families,2)):
    rng=np.random.Generator(np.random.PCG64(202610060000+rep)); selected={}
    for f in families:
        groups=[]
        for row in trainmeta:
            if row['family']==f and row['group_id'] not in groups:groups.append(row['group_id'])
        assert len(groups)==8
        draws=rng.choice(8,6 if f in small else 7,replace=False)
        selected[f]=[g for ix,g in enumerate(groups) if ix in draws]
    selectedgroups=set(g for groups in selected.values() for g in groups)
    ids=[r['instance_id'] for r in trainmeta if r['group_id'] in selectedgroups]
    s={'rep_index':rep,'seed':202610060000+rep,'six_group_families':list(small),'groups_by_family':selected,'train_ids':ids}
    assert s==sample[rep]
    assert len(ids)==120 and len(selectedgroups)==40 and len(selected)==6
    for g in selectedgroups:assert [r['order'] for r in trainmeta if r['group_id']==g]==P['orders']
    specs.append(s)
raw={}
for row in meta:
    first=read(O/'raw'/f"{row['instance_id']}__BF.json");second=read(O/'raw'/f"{row['instance_id']}__BF_then_EoH.json")
    for r in (first,second):
        assert r['instance_id']==row['instance_id'] and r['status']=='complete' and r['error'] is None
        assert r['selector_consumed_count']==500 and r['steps']==5000
        assert len(r['prefix_features'])==31 and all(math.isfinite(x) for x in r['prefix_features'])
    assert first['prefix_features']==second['prefix_features']
    assert first['prefix_remaining_sha256']==second['prefix_remaining_sha256']
    assert first['items_sha256']==second['items_sha256']
    raw[row['instance_id']]={'metadata':row,'features':first['prefix_features'],'costs':[first['used_bins'],second['used_bins']]}
maxerr=0.; numeric_comparisons=0

def same(actual,reported,path=''):
    global maxerr,numeric_comparisons
    if isinstance(actual,dict):
        assert actual.keys()==reported.keys(),path
        for k in actual:same(actual[k],reported[k],path+'/'+k)
    elif isinstance(actual,(list,tuple)):
        assert len(actual)==len(reported),path
        for i,(a,b) in enumerate(zip(actual,reported)):same(a,b,path+'/'+str(i))
    elif isinstance(actual,(bool,str)) or actual is None:assert actual==reported,(path,actual,reported)
    elif isinstance(actual,int):assert actual==reported,(path,actual,reported);numeric_comparisons+=1
    else:
        err=abs(actual-reported);maxerr=max(maxerr,err);numeric_comparisons+=1
        assert err<=1e-10,(path,actual,reported,err)

def aggregate(preds):
    delta=[p['selector_minus_SBS'] for p in preds]; regret=[p['selector_regret'] for p in preds];n=len(preds)
    return {'n':n,'mean_bins':{'selector':statistics.mean(p['selector_bins'] for p in preds),'SBS':statistics.mean(p['SBS_bins'] for p in preds),'branch_oracle':statistics.mean(p['oracle_bins'] for p in preds)},'selector_minus_SBS_mean':sum(delta)/n,'selector_oracle_regret_mean':sum(regret)/n,'selector_oracle_regret_max':max(regret),'worst_harm_vs_SBS':max(delta),'best_gain_vs_SBS':-min(delta),'W_T_L_vs_SBS':[sum(d<0 for d in delta),sum(d==0 for d in delta),sum(d>0 for d in delta)],'choices':{'BF':sum(p['selected_index']==0 for p in preds),'BF_then_EoH':sum(p['selected_index']==1 for p in preds)},'different_from_SBS_count':sum(p['selected_index']!=p['sbs_index'] for p in preds),'prediction_tie_count':sum(p['prediction_tie'] for p in preds),'worst_regret_instances':[p['instance_id'] for p in preds if p['selector_regret']==max(regret)]}

reconstructed=[]
for spec,reported in zip(specs,producer['replicates']):
    train=[raw[i] for i in spec['train_ids']];columns=list(zip(*(r['features'] for r in train)))
    means=[statistics.mean(col) for col in columns]; scales=[statistics.pstdev(col) or 1. for col in columns]
    scores=[sum(r['costs'][i] for r in train) for i in (0,1)];sbs=0 if scores[0]<=scores[1] else 1
    same(means,reported['model']['mean'],'means');same(scales,reported['model']['scale'],'scale')
    same([v/120 for v in scores],reported['model']['training_mean_costs'],'training_mean_costs')
    assert sbs==reported['model']['sbs_index']
    preds=[]
    for row in confirm:
        r=raw[row['instance_id']]
        # Direct standardized differences cancel the shared training mean. No producer z arrays used.
        distances=[math.fsum(((a-b)/s)**2 for a,b,s in zip(t['features'],r['features'],scales)) for t in train]
        neighbor=sorted(range(120),key=lambda i:(distances[i],i))[:5]
        sums=[sum(train[i]['costs'][j] for i in neighbor) for j in (0,1)]
        chosen=sbs if sums[0]==sums[1] else int(sums[1]<sums[0]);costs=r['costs']
        pred={k:row[k] for k in ['instance_id','group_id','family','order']}
        pred.update(costs=costs,neighbor_indices=neighbor,neighbor_ids=[spec['train_ids'][i] for i in neighbor],squared_distances=[distances[i] for i in neighbor],predicted_costs=[v/5 for v in sums],prediction_tie=sums[0]==sums[1],selected_index=chosen,sbs_index=sbs,selector_bins=costs[chosen],SBS_bins=costs[sbs],oracle_bins=min(costs),selector_minus_SBS=costs[chosen]-costs[sbs],selector_regret=costs[chosen]-min(costs))
        preds.append(pred)
    same(preds,reported['predictions'],'predictions')
    pooled=aggregate(preds); per={f:aggregate([p for p in preds if p['family']==f]) for f in families}
    same(pooled,reported['pooled'],'pooled');same(per,reported['per_family'],'per_family')
    assert pooled['n']==108 and all(a['n']==18 for a in per.values())
    reconstructed.append({'pooled':pooled,'per_family':per})

def desc(values):return {'mean':statistics.mean(values),'median':statistics.median(values),'min':min(values),'max':max(values),'values':values}
def block(aggs):
    keys={'selector_minus_SBS_mean':'selector_minus_SBS_mean','selector_oracle_regret_mean':'selector_oracle_regret_mean','worst_regret':'selector_oracle_regret_max','worst_harm_vs_SBS':'worst_harm_vs_SBS'}
    result={a:desc([r[b] for r in aggs]) for a,b in keys.items()}
    for k in ['BF','BF_then_EoH']:result[k+'_count']=desc([r['choices'][k] for r in aggs])
    return result
dist={'pooled':block([r['pooled'] for r in reconstructed]),'per_family':{f:block([r['per_family'][f] for r in reconstructed]) for f in families}}
same(dist,producer['distribution'],'distribution')
assert len(producer['replicates'])==len(specs)==15
refs=read(B/'DESCRIPTIVE_REFERENCES.json');csvrows=list(csv.DictReader((O/'analysis/confirmation_per_stream.csv').open()))
full=sum(int(r['SELECTOR'])-int(r['SBS']) for r in csvrows)/len(csvrows)
assert len(csvrows)==108 and full==refs['original_full_family_144']['aggregate']['selector_minus_SBS_mean']
lofo=read(ROOT/'independent_bpp_selector_family_transfer_20261006/analysis/RESULTS.json')
assert len(lofo['predictions'])==108
lf=sum(p['costs'][p['selected_index']]-p['costs'][p['sbs_index']] for p in lofo['predictions'])/108
assert lf==refs['LOFO_120']['aggregate']['selector_minus_SBS_mean']
for rel,digest in integrity.items():assert sha(ROOT/rel)==digest
result={'status':'passed','completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'separate review agent with new computation, no producer helper imports','replicates':15,'predictions_verified':1620,'training_rows_per_rep':120,'training_groups_per_rep':40,'training_families_per_rep':6,'confirmation_rows_per_rep':108,'confirmation_family_rows_per_rep':18,'source_hashes_verified_unchanged':len(source),'producer_delivery_hashes_verified':len(manifest),'metadata_group_and_multiset_split_disjoint':True,'sampling_reconstructed_from_metadata_only':True,'training_only_normalization_and_SBS':True,'all_neighbors_decisions_and_aggregates_verified':True,'numeric_comparisons':numeric_comparisons,'maximum_absolute_error':maxerr,'primary':dist['pooled']['selector_minus_SBS_mean'],'descriptive_full144':full,'descriptive_LOFO120':lf,'limitations':['Already observed confirmation panel; sampling prescription is outcome-independent in code, but audit cannot establish that design was not influenced by previously seen results.','15 subsamples overlap and are not independent trials. Equal120 training rows does not isolate a family-absence causal effect.','Full packing state-transition legality and prefix-feature extraction are inherited from prior hash-anchored audits, not freshly replayed.','No new packing strategies, input streams or model calls.']}
(H/'BPP_AUDIT.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
(H/'BPP_SOURCE_MANIFEST.json').write_text(json.dumps({'files':integrity},indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
