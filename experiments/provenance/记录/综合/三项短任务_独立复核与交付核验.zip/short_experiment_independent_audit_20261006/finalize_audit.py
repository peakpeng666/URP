"""Final source-package checks and resource summary; no experiment computation."""
import resource
resource.setrlimit(resource.RLIMIT_CPU,(1,1))
import pathlib,json,hashlib,time,datetime
H=pathlib.Path(__file__).resolve().parent;ROOT=H.parent
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
started=time.monotonic();cpu=time.process_time();entries=[]
for name in ['independent_bpp_matched_size_20261006','independent_de_rotation_sensitivity_20261006','independent_turn_aware_search_20261006']:
    manifest=ROOT/name/'MANIFEST.json';m=read(manifest)
    for rel,e in m['files'].items():
        p=ROOT/name/rel
        assert p.stat().st_size==e['bytes'] and sha(p)==e['sha256'],str(p)
    entries.append({'directory':name,'manifest_sha256':sha(manifest),'file_count':len(m['files']),'all_bytes_and_sha256_verified':True})
(H/'FINAL_DELIVERY_INTEGRITY.json').write_text(json.dumps({'status':'passed','checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'producers':entries,'scope':'Final producer manifests include reports and support files that were outside selected numerical-source manifests. This is byte integrity, not a new report-content or numerical rerun.'},indent=2)+'\n')
resources=[read(H/(stem+'_resources.json')) for stem in ['audit_bpp','audit_de','audit_pathfinding']]
assert all(r['child_exit_code']==0 and not r['wall_timeout'] for r in resources)
result={'numeric_audit_attempts':3,'numeric_audit_exit_codes':[r['child_exit_code'] for r in resources],'timeouts':0,'measured_numeric_child_cpu_seconds':sum(r['child_cpu_seconds'] for r in resources),'measured_numeric_wall_seconds':sum(r['wall_seconds'] for r in resources),'measured_launcher_partial_cpu_seconds':sum(r['launcher_cpu_through_wait_seconds'] for r in resources),'prospective_numeric_child_and_launcher_hard_caps_sum_seconds':117,'prospective_numeric_wall_limits_sum_seconds':540,'final_integrity_process_hard_cpu_cap_seconds':1,'final_integrity_wall_limit_seconds':10,'final_integrity_process_partial_cpu_seconds':time.process_time()-cpu,'final_integrity_process_partial_wall_seconds':time.monotonic()-started,'total_budget_cpu_seconds':120,'total_budget_wall_seconds':600,'scope':'Numeric children have wait4 whole-process measurement. Their launchers are measured through wait completion; writing/exit tails are bounded but not exactly measured. Final integrity timing here is partial; external finalization.time gives rounded whole-command CPU and wall, plus finalization.exit gives shell exit. Text inspection, editing, preliminary py_compile, shell/tool/LLM orchestration and subsequent delivery-manifest writing are not claimed exact all-in.'}
(H/'RESOURCE_TOTALS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':'passed','source_manifest_counts':{e['directory']:e['file_count'] for e in entries},'resources':result},ensure_ascii=False,indent=2))
