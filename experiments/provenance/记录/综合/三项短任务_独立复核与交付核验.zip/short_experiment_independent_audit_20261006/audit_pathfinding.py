"""Independent pathfinding, lower-bound, count and timing aggregation audit."""
import pathlib,json,hashlib,random,itertools,statistics,collections,datetime
from pathfinding_check_core import V,angle,lower,exact_cost,replay_counters,verify_route
H=pathlib.Path(__file__).resolve().parent;R=H.parent/'independent_turn_aware_search_20261006'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
freeze=read(R/'PRE_RUN_FREEZE.json');sources={}
assert sha(R/'PRE_RUN_FREEZE.json')=='fd9e7e35ee44d888964b2ee880b7f7431db017b02c2c585856118c053ce30574'
for name,e in freeze['files'].items():assert sha(R/name)==e['sha256'];sources[name]=e['sha256']
for name in ['PRE_RUN_FREEZE.json','LAUNCH_EXIT.json','checks/FAILURE.json','checks/post_run_checks.json','checks/execution_journal.jsonl','checks/launcher_resource_usage.txt','recovery/RECOVERY_NOTICE.json','recovery/POSTPROCESS_EXIT.json','recovery/postprocess_existing.py']:
    sources[name]=sha(R/name)
for f in (R/'outputs').glob('*'):
    if f.is_file():sources[str(f.relative_to(R))]=sha(f)
S=read(R/'outputs/summary.json');maps=read(R/'inputs/maps.json');cases=read(R/'inputs/cases.json');bm=read(R/'inputs/boundary_maps.json');bc=read(R/'inputs/boundary_cases.json')
main=[json.loads(l) for l in (R/'outputs/main_runs.jsonl').read_text().splitlines()];boundary=[json.loads(l) for l in (R/'outputs/boundary_runs.jsonl').read_text().splitlines()]
assert len(maps)==24 and len(cases)==72 and len(main)==648 and len(bm)==5 and len(bc)==15 and len(boundary)==45
assert set((m['n'],m['seed'],m['obstacle_probability']) for m in maps)==set(itertools.product([16,32,48],[871211,871229,871247,871283],[.1,.25]))
# Reconstruct frozen draws only to verify the recorded input bytes; no replacement maps.
for m in maps:
    n=m['n'];p=m['obstacle_probability'];key=f"turn-aware-grid-v1|n={n}|seed={m['seed']}|p={p:.2f}"
    seed=int.from_bytes(hashlib.sha256(key.encode()).digest(),'big');rng=random.Random(seed)
    rows=[''.join('#' if rng.random()<p else '.' for x in range(n)) for y in range(n)]
    free=[(x,y) for y in range(n) for x in range(n) if rows[y][x]=='.'];start,goal=rng.sample(free,2);heading=rng.randrange(4)
    assert rows==m['rows'] and [*start,heading]==m['start'] and list(goal)==m['goal']
    assert n*n-len(free)==m['obstacle_count'] and hex(seed)==m['rng_seed_hex'] and key==m['rng_key']
# Independent reverse integer-cost bucket solution for the archived 13x13 preflight.
checks=collections.Counter();goal=(6,6);n=13
for w in [0,2,8]:
    dist={(6,6,h):0 for h in range(4)};queue=collections.defaultdict(collections.deque);queue[0].extend(dist);active=4;timekey=0
    while active:
        if not queue.get(timekey):timekey+=1;continue
        state=queue[timekey].popleft();active-=1
        if dist[state]!=timekey:continue
        x,y,newh=state;px=x-V[newh][0];py=y-V[newh][1]
        if not (0<=px<n and 0<=py<n):continue
        for oldh in range(4):
            prev=(px,py,oldh);candidate=timekey+1+w*angle(oldh,newh)
            if candidate<dist.get(prev,10**20):dist[prev]=candidate;queue[candidate].append(prev);active+=1
    assert len(dist)==676
    for state,optimal in dist.items():
        assert lower(state,goal,w,'astar_turn')==optimal;checks['exact_turn_heuristic_states']+=1
        for alg in ['dijkstra','astar_manhattan','astar_turn']:
            h=lower(state,goal,w,alg);assert 0<=h<=optimal;checks['admissibility_checks']+=1;checks['nonnegative_checks']+=1
            if state[:2]==goal:assert h==0;checks['goal_zero_checks']+=1
            for direction,(dx,dy) in enumerate(V):
                x,y,d=state;nx=x+dx;ny=y+dy
                if not(0<=nx<n and 0<=ny<n):continue
                assert h<=1+w*angle(d,direction)+lower((nx,ny,direction),goal,w,alg);checks['consistency_checks']+=1
assert dict(checks)==read(R/'checks/preflight.json')['checks']
algs=['dijkstra','astar_manhattan','astar_turn'];counter_keys=['expansions','accepted_pops','stale_pops','heap_pushes','max_heap','reexpansions','successor_candidates','traversable_successors']
verified_routes=0;replayed_counts=0;optimal_costs={}
for category,maplist,caselist,records,repeats in [('main',maps,cases,main,3),('boundary',bm,bc,boundary,1)]:
    mapping={m['map_id']:m for m in maplist};lookup={(r['case_id'],r['algorithm'],r['repeat']):r for r in records}
    assert len(lookup)==len(records)
    oracles={r['case_id']:r for r in read(R/f'outputs/{category}_oracles.json')}
    assert len(oracles)==len(caselist)
    for index,c in enumerate(caselist):
        m=mapping[c['map_id']];rows=m['rows'];start=m['start'];goal=m['goal'];w=c['weight']
        cost=exact_cost(rows,start,goal,w);optimal_costs[c['case_id']]=cost
        assert cost==oracles[c['case_id']]['exact_cost'] and oracles[c['case_id']]['reachable']==(cost is not None)
        if category=='boundary':
            expected=m['expected_base_steps']+w*m['expected_turn_units'] if m['expected_reachable'] else None
            assert cost==expected==oracles[c['case_id']]['manual_expected_cost']
        for algorithm in algs:
            replaycost,counters=replay_counters(rows,start,goal,w,algorithm);assert replaycost==cost;replayed_counts+=1
            baseline=lookup[c['case_id'],algorithm,0]
            for k in counter_keys:assert counters[k]==baseline[k],(c['case_id'],algorithm,k,counters[k],baseline[k])
            for repeat in range(repeats):
                r=lookup[c['case_id'],algorithm,repeat]
                route=verify_route(rows,start,goal,w,r,cost);verified_routes+=1
                assert r['exact_cost']==cost and r['path_valid']
                assert r['steps']==route['steps'] and r['turn_units']==route['turn_units']
                assert all(r[k]==baseline[k] for k in counter_keys+['path','reachable','cost'])
                assert algs[(index+repeat+r['within_repeat_order'])%3]==algorithm
                assert r['cpu_ns']>=0 and r['wall_ns']>0
assert verified_routes==693 and replayed_counts==261
assert sum(optimal_costs[c['case_id']] is not None for c in cases)==69
journal=[json.loads(l) for l in (R/'checks/execution_journal.jsonl').read_text().splitlines()]
counts=collections.Counter(e['event'] for e in journal)
assert counts['search_start']==counts['search_complete']==693 and counts['oracle_start']==counts['oracle_complete']==90
failure=read(R/'checks/FAILURE.json');assert failure['error_type']=='ZeroDivisionError'
assert read(R/'LAUNCH_EXIT.json')['exit_code']==1 and read(R/'recovery/POSTPROCESS_EXIT.json')['exit_code']==0
recovery=read(R/'recovery/RECOVERY_NOTICE.json');assert recovery['solver_reruns']==0 and recovery['oracle_reruns']==0
assert recovery['original_sources_modified']==recovery['original_inputs_modified']==recovery['original_raw_records_modified']==False
primary=[r for r in main if r['repeat']==0];by={(r['case_id'],r['algorithm']):r for r in primary};pairs=[]
for c in cases:
    a=by[c['case_id'],'astar_turn'];b=by[c['case_id'],'astar_manhattan']
    pairs.append({'case_id':c['case_id'],'weight':c['weight'],'n':a['n'],'reachable':a['reachable'],'manhattan_expansions':b['expansions'],'turn_expansions':a['expansions'],'expansion_reduction_percent':100*(b['expansions']-a['expansions'])/b['expansions'],'manhattan_heap_pushes':b['heap_pushes'],'turn_heap_pushes':a['heap_pushes'],'push_reduction_percent':100*(b['heap_pushes']-a['heap_pushes'])/b['heap_pushes']})
assert sorted(pairs,key=lambda p:p['case_id'])==S['paired_cases']
groups=[];timings=[]
for w in [0,2,8,'all']:
    selected=[r for r in primary if w=='all' or r['weight']==w];pair=[r for r in pairs if w=='all' or r['weight']==w];totals={}
    for alg in algs:
        unique=[r for r in selected if r['algorithm']==alg];raw=[r for r in main if r['algorithm']==alg and (w=='all' or r['weight']==w)]
        wall=[statistics.median(r['wall_ns'] for r in raw if r['case_id']==u['case_id']) for u in unique]
        cpumed=[statistics.median(r['cpu_ns'] for r in raw if r['case_id']==u['case_id']) for u in unique]
        totals[alg]={'cases':len(unique),'expansions':sum(r['expansions'] for r in unique),'heap_pushes':sum(r['heap_pushes'] for r in unique),'sum_case_median_wall_ms':sum(wall)/1e6,'median_case_wall_ms':statistics.median(wall)/1e6,'cpu_comparison':None}
        timings.append({'weight':w,'algorithm':alg,'raw_runs':len(raw),'zero_cpu_records':sum(r['cpu_ns']==0 for r in raw),'unique_cases':len(unique),'zero_median_cpu_cases':sum(x==0 for x in cpumed),'sum_case_median_cpu_ns':sum(cpumed)})
    reductions={base:{metric:100*(1-totals['astar_turn'][metric]/totals[base][metric]) for metric in ['expansions','heap_pushes']} for base in ['dijkstra','astar_manhattan']}
    groups.append({'weight':w,'cases':len(pair),'reachable':sum(r['reachable'] for r in pair),'totals':totals,'pooled_reduction_percent_vs':reductions,'median_paired_expansion_reduction_percent':statistics.median(r['expansion_reduction_percent'] for r in pair),'expansion_win_tie_loss':{'win':sum(r['turn_expansions']<r['manhattan_expansions'] for r in pair),'tie':sum(r['turn_expansions']==r['manhattan_expansions'] for r in pair),'loss':sum(r['turn_expansions']>r['manhattan_expansions'] for r in pair)}})
assert groups==S['groups']
zeros=sum(r['cpu_ns']==0 for r in main+boundary);assert zeros==483==S['cpu_timing']['zero_records'] and S['cpu_timing']['usable']==False
cpu_report={'total_raw_runs':693,'zero_cpu_records':zeros,'main_raw_runs':648,'main_zero_cpu_records':sum(r['cpu_ns']==0 for r in main),'boundary_raw_runs':45,'boundary_zero_cpu_records':sum(r['cpu_ns']==0 for r in boundary),'main_groups':timings,'interpretation':'Raw zero durations are not zero work. The actual clock mechanism behind zero observations has not been independently diagnosed. Do not use the per-search CPU series for speedup claims. Wall medians are arithmetically verified observational measurements only.'}
for name,digest in sources.items():assert sha(R/name)==digest,name
report={'status':'passed_with_recorded_timing_and_recovery_limitations','completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'Different reviewer; independent bucket shortest paths, lower-bound arithmetic and heap counter replay without producer imports.','main_cases':72,'distinct_maps':24,'independent_main_cost_solutions':72,'boundary_cases':15,'recorded_routes_verified':693,'unique_algorithm_counter_replays':261,'all_path_costs_optimal':True,'reachable_main_cases':69,'unreachable_main_cases':3,'preflight_checks_recomputed':dict(checks),'frozen_map_draws_reconstructed':24,'source_files_verified_unchanged':len(sources),'pooled_main_counts':groups[-1]['totals'],'pooled_count_reduction_vs_manhattan':groups[-1]['pooled_reduction_percent_vs']['astar_manhattan'],'expansion_win_tie_loss':groups[-1]['expansion_win_tie_loss'],'cpu_zero_records':zeros,'original_solver_process_exit':1,'original_failure_after_search_completion':'ZeroDivisionError while computing CPU summary ratio','recovery_exit':0,'scientific_conclusion':'All costs, reachability, lower-bound checks and expansion/push aggregates verified. Formal execution history is not an all-clean exit: search and checks completed, then first summary failed; separate existing-data postprocessing succeeded.','limitations':['Synthetic static four-neighbor heading graph; no curvature, acceleration, turn-radius or vehicle-dynamics guarantee.','Only24 maps and4 seeds; same maps shared across3 weights and repetitions are not independent samples.','CPU per-search series is unreliable and speedup ratios are not supported. Wall-time aggregation is checked but is an observational shared-cloud measure, not an independently reproduced performance benchmark.','No rerun of producer experiments or change to frozen inputs; audit replay uses the same archived inputs only.']}
(H/'PATHFINDING_AUDIT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');(H/'PATHFINDING_CPU_TIMING_AUDIT.json').write_text(json.dumps(cpu_report,ensure_ascii=False,indent=2)+'\n');(H/'PATHFINDING_SOURCE_MANIFEST.json').write_text(json.dumps({'root':R.name,'files':sources},indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(cpu_report,ensure_ascii=False,indent=2))
