import os,sys,time,resource,signal,json,pathlib,datetime
out=pathlib.Path(__file__).resolve().parent
stem=sys.argv[1]
assert stem in ('audit_bpp','audit_pathfinding','audit_de')
start=time.monotonic(); cpu=time.process_time(); now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
started=now(); pid=os.fork()
if pid==0:
    resource.setrlimit(resource.RLIMIT_CPU,(36,38))
    f=os.open(out/(stem+'.log'),os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o644)
    os.dup2(f,1);os.dup2(f,2)
    for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[key]='1'
    os.execv(sys.executable,[sys.executable,str(out/(stem+'.py'))])
resource.setrlimit(resource.RLIMIT_CPU,(1,1))
timed_out=False
while True:
    got,status,usage=os.wait4(pid,os.WNOHANG)
    if got:break
    if time.monotonic()-start>180:
        timed_out=True;os.kill(pid,signal.SIGKILL);got,status,usage=os.wait4(pid,0);break
    time.sleep(.05)
record={'started_utc':started,'finished_utc':now(),'child_exit_code':os.waitstatus_to_exitcode(status),'wait_status':status,'wall_timeout':timed_out,'child_user_cpu_seconds':usage.ru_utime,'child_system_cpu_seconds':usage.ru_stime,'child_cpu_seconds':usage.ru_utime+usage.ru_stime,'launcher_cpu_through_wait_seconds':time.process_time()-cpu,'wall_seconds':time.monotonic()-start,'child_cpu_hard_limit':38,'launcher_cpu_hard_limit':1,'wall_limit':180,'scope':'Child computation fully measured. Launcher measurement excludes final record/manifest writing and exit tail; all shell/editor/text-inspection/orchestration/LLM work excluded.'}
with (out/(stem+'_resources.json')).open('x') as f:json.dump(record,f,indent=2)
print(json.dumps(record));sys.exit(record['child_exit_code'] if record['child_exit_code']>=0 else 128-record['child_exit_code'])
