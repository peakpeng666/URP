"""Independent DE byte-input replay and numerical ledger audit, no producer imports."""
import pathlib,json,hashlib,math,itertools,statistics,csv,datetime
import numpy as np
H=pathlib.Path(__file__).resolve().parent;R=H.parent/'independent_de_rotation_sensitivity_20261006'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
P=read(R/'protocol.json');M=read(R/'PRE_RUN_MANIFEST.json');sources={}
for name,e in M['files'].items():assert sha(R/name)==e['sha256'];sources[name]=e['sha256']
for folder in ['results','validation']:
    for f in (R/folder).glob('*'):
        if f.is_file():sources[str(f.relative_to(R))]=sha(f)
for name in ['PRE_RUN_MANIFEST.json','provenance/execution_attempt_01.json']:sources[name]=sha(R/name)
assert sha(R/'PRE_RUN_MANIFEST.json')=='851ecd43272dde7241a7969ed573fd6e6ba1f596c49ab04322b404a46ad58fd7'
assert P['planned_runs']==256 and P['fe_per_run']==2000 and P['population']==20 and P['generations']==99
runs=[json.loads(s) for s in (R/'results/runs.jsonl').read_text().splitlines()];S=read(R/'results/summary.json');validation=read(R/'validation/validation.json')
assert len(runs)==256 and sum(r['fe'] for r in runs)==512000
expected=set(itertools.product(P['families'],P['orientations'],[c['id'] for c in P['configs']],P['search_seeds']))
index={(r['family'],r['orientation'],r['config_id'],r['seed']):r for r in runs}
assert len(index)==256 and set(index)==expected
q=np.load(R/'inputs/Q.npy',allow_pickle=False);assert q.shape==(10,10)
orth=max(abs(math.fsum(float(q[k,i])*float(q[k,j]) for k in range(10))-(i==j)) for i in range(10) for j in range(10))
det=float(np.linalg.det(q));assert orth<=1e-12 and abs(det-1)<1e-12
weights=np.array([10**(6*i/9) for i in range(10)])
tapes={};donors={}
for seed in P['search_seeds']:
    t=dict(np.load(R/f'inputs/random_tape_{seed}.npz',allow_pickle=False));tapes[seed]=t
    assert t['initial_population'].shape==(20,10) and np.all(np.abs(t['initial_population'])<=5)
    assert t['crossover_uniform'].shape==(99,20,10) and np.all((t['crossover_uniform']>=0)&(t['crossover_uniform']<1))
    d=np.empty((99,20,3),dtype=int)
    for g in range(99):
        for target in range(20):
            options=[i for i in range(20) if i!=target]
            for pos,key in enumerate(['donor_rank_a','donor_rank_b','donor_rank_c']):
                rank=int(t[key][g,target]);assert 0<=rank<len(options);d[g,target,pos]=options.pop(rank)
            assert len(set([target,*d[g,target]]))==4
            assert 0<=int(t['forced_coordinate'][g,target])<10
    donors[seed]=d
own_vector_fe=0;scalar_fe=0;max_final_rel=0.;max_eval_relative=0.;batch_hashes=0

def objective(x,family,orientation):
    global own_vector_fe
    own_vector_fe+=len(x);z=np.dot(x,q.T) if orientation=='rotated' else x
    return np.sum(z*z,axis=1) if family=='sphere' else np.sum((z*weights)*z,axis=1)
def scalar(x,family,orientation):
    global scalar_fe
    scalar_fe+=1
    coords=[math.fsum(float(a)*float(b) for a,b in zip(row,x)) for row in q] if orientation=='rotated' else list(map(float,x))
    return math.fsum(c*c for c in coords) if family=='sphere' else math.fsum(10**(6*i/9)*c*c for i,c in enumerate(coords))
def close(a,b,rtol=1e-11,atol=1e-11):assert np.allclose(a,b,rtol=rtol,atol=atol),(np.max(np.abs(np.asarray(a)-np.asarray(b))))
points=np.load(R/'inputs/objective_test_points.npy',allow_pickle=False);assert points.shape==(64,10)
recorded_points=dict(np.load(R/'validation/objective_test_values.npz',allow_pickle=False));point_ref={}
for family,orientation in itertools.product(P['families'],P['orientations']):
    v=[scalar(x,family,orientation) for x in points];point_ref[family+'_'+orientation]=v
    close(v,recorded_points[family+'_'+orientation],1e-12,1e-12)
close(point_ref['sphere_axis'],point_ref['sphere_rotated'],1e-12,1e-12)

for row in runs:
    assert row['fe']==2000 and row['F'] in [.4,.6,.8,1.] and row['CR'] in [.1,.3,.7,.9]
    assert sha(R/row['output_file'])==row['output_sha256']
    a=dict(np.load(R/row['output_file'],allow_pickle=False));t=tapes[row['seed']];d=donors[row['seed']]
    assert a['eval_values'].shape==(100,20) and a['curve_best_loss'].shape==(100,) and a['point_batch_sha256'].shape==(100,)
    pop=t['initial_population'].copy();scores=None;curve=[];evaluated=[]
    for generation in range(100):
        if generation==0:batch=pop.copy()
        else:
            g=generation-1;mutant=pop[d[g,:,0]]+row['F']*(pop[d[g,:,1]]-pop[d[g,:,2]])
            mask=t['crossover_uniform'][g]<row['CR']
            mask[np.arange(20),t['forced_coordinate'][g]]=True
            batch=np.minimum(5.,np.maximum(-5.,np.where(mask,mutant,pop)))
        # Verifies every evaluated coordinate batch, not only final solutions.
        assert hashlib.sha256(batch.astype('<f8').tobytes()).hexdigest()==str(a['point_batch_sha256'][generation]),(row['run_id'],generation,'point hash')
        batch_hashes+=1
        y=objective(batch,row['family'],row['orientation']);close(y,a['eval_values'][generation],1e-12,1e-12)
        max_eval_relative=max(max_eval_relative,float(np.max(np.abs(y-a['eval_values'][generation])/np.maximum(np.abs(y),1e-300))))
        evaluated.append(y)
        if scores is None:scores=y.copy()
        else:
            improve=y<scores;pop=np.where(improve[:,None],batch,pop);scores=np.minimum(scores,y)
        curve.append(float(min(scores)))
    assert np.array_equal(pop,a['final_population']),row['run_id']
    close(scores,a['final_fitness']);close(curve,a['curve_best_loss']);close(np.min(a['eval_values'],axis=0),a['final_fitness'],0,0)
    best=int(np.argmin(scores));assert np.array_equal(a['best_vector'],pop[best]);assert row['best_vector']==a['best_vector'].tolist()
    assert row['final_best_loss']==float(min(a['final_fitness'])) and row['log10_loss_eps']==math.log10(row['final_best_loss']+1e-12)
    scalars=np.array([scalar(x,row['family'],row['orientation']) for x in pop]);close(scalars,a['final_fitness'],1e-10,1e-10)
    max_final_rel=max(max_final_rel,float(np.max(np.abs(scalars-a['final_fitness'])/np.maximum(np.abs(scalars),1e-300))))
assert own_vector_fe==512000 and scalar_fe==5376 and batch_hashes==25600
# Curves CSV is checked independently from all corresponding NPZ arrays.
curve_csv=list(csv.DictReader((R/'results/curves.csv').open()));assert len(curve_csv)==25600
byid={r['run_id']:r for r in runs};cached={}
for c in curve_csv:
    key=c['run_id'];generation=int(c['generation'])
    if key not in cached:cached[key]=np.load(R/byid[key]['output_file'],allow_pickle=False)['curve_best_loss']
    assert int(c['fe'])==20*(generation+1) and float(c['best_loss'])==float(cached[key][generation])
results={};computed_pair={};computed_configs={}
for fam in P['families']:
    orders={};ranks={};means={}
    for ori in P['orientations']:
        means[ori]={cfg['id']:math.fsum(math.log10(index[fam,ori,cfg['id'],seed]['final_best_loss']+1e-12) for seed in P['search_seeds'])/4 for cfg in P['configs']}
        orders[ori]=sorted(means[ori],key=lambda key:(means[ori][key],key));ranks[ori]={key:i+1 for i,key in enumerate(orders[ori])}
        assert orders[ori]==S['rankings'][fam][ori]['order'] and ranks[ori]==S['rankings'][fam][ori]['ranks']
        for key,mean in means[ori].items():assert abs(mean-S['rankings'][fam][ori]['mean_log10_loss_eps'][key])<1e-12
    deltas=[];rankdiff=[]
    for cfg in P['configs']:
        cid=cfg['id'];d=[]
        for seed in P['search_seeds']:
            axis=index[fam,'axis',cid,seed]['final_best_loss'];rot=index[fam,'rotated',cid,seed]['final_best_loss']
            diff=math.log10(rot+1e-12)-math.log10(axis+1e-12);d.append(diff)
            computed_pair[fam,cid,seed]={'axis_loss':axis,'rotated_loss':rot,'paired_log10_delta':diff}
        rd=ranks['rotated'][cid]-ranks['axis'][cid];rankdiff.append(rd);deltas.extend(d)
        computed_configs[fam,cid]={'F':cfg['F'],'CR':cfg['CR'],'axis_mean_log10_loss_eps':means['axis'][cid],'rotated_mean_log10_loss_eps':means['rotated'][cid],'axis_rank':ranks['axis'][cid],'rotated_rank':ranks['rotated'][cid],'rank_change_rotated_minus_axis':rd,'paired_mean_delta':statistics.mean(d),'paired_median_delta':statistics.median(d),'paired_min_delta':min(d),'paired_max_delta':max(d)}
    spearman=1-6*sum(d*d for d in rankdiff)/(16*(16**2-1))
    inv=sum((ranks['axis'][a]-ranks['axis'][b])*(ranks['rotated'][a]-ranks['rotated'][b])<0 for a,b in itertools.combinations(ranks['axis'],2))
    expected_summary={'n_pairs':64,'mean_delta':statistics.mean(deltas),'median_delta':statistics.median(deltas),'min_delta':min(deltas),'max_delta':max(deltas),'positive':sum(d>0 for d in deltas),'negative':sum(d<0 for d in deltas),'exact_zero':sum(d==0 for d in deltas)}
    for k,v in expected_summary.items():assert abs(v-S['rankings'][fam]['all_config_seed_paired_summary'][k])<1e-12
    assert spearman==S['rankings'][fam]['rank_spearman'] and inv==S['rankings'][fam]['pairwise_inversions']
    results[fam]={'spearman':spearman,'pairwise_inversions':inv,'possible_pairs':120,'axis_best_config':orders['axis'][0],'rotated_best_config':orders['rotated'][0],**expected_summary}
paired_csv=list(csv.DictReader((R/'results/paired_differences.csv').open()));assert len(paired_csv)==128
for r in paired_csv:
    exp=computed_pair[r['family'],r['config_id'],int(r['seed'])]
    for k,v in exp.items():assert abs(float(r[k])-v)<1e-12
config_csv=list(csv.DictReader((R/'results/config_summary.csv').open()));assert len(config_csv)==32
for r in config_csv:
    for k,v in computed_configs[r['family'],r['config_id']].items():assert abs(float(r[k])-v)<1e-12
assert S['optimization_fe']==512000 and S['validation_fe']==21632 and S['all_objective_evaluations']==533632
assert validation['core_objective_test_fe']==256 and validation['reference_total_fe']==21376 and validation['validation_fe']==21632
assert len(validation['reference_replays'])==8 and all(x['fe']==2000 for x in validation['reference_replays'])
receipt=read(R/'provenance/execution_attempt_01.json');assert receipt['status']=='completed' and receipt['return_code']==0 and receipt['attempt']==1
for name,digest in sources.items():assert sha(R/name)==digest,name
report={'status':'passed','completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'independence':'Separate reviewer. All256 same-input traces replayed by new implementation with explicit donor exclusion; no producer helpers imported. Scalar objective independently checks every final individual. No new scientific sample or parameter setting.','runs_replayed':256,'fe_per_run':2000,'optimization_fe_verified':512000,'producer_validation_fe_verified':21632,'auditor_validation_vector_objective_evaluations':own_vector_fe,'auditor_validation_scalar_objective_evaluations':scalar_fe,'auditor_point_batch_hashes_verified':batch_hashes,'exact_final_population_matches':256,'curve_records_verified':25600,'q_orthogonality_error':orth,'q_determinant':det,'maximum_eval_relative_error':max_eval_relative,'maximum_scalar_final_relative_error':max_final_rel,'source_files_verified_unchanged':len(sources),'rankings':results,'limitations':['One fixed rotation matrix, four search seeds and two D=10 synthetic functions; descriptive parameter-grid sensitivity only.','Axis-aligned box clipping is retained across orientations. This is not globally rotation-equivariant DE and does not isolate crossover from clipping or initialization effects.','Sphere negative control checks an invariant objective; it does not establish that the optimizer itself is generally rotation-invariant.','Full same-byte replay verifies implementation and records, not an independently resampled experimental replication.','Recorded wall/CPU durations are not externally hardware-instrumented or independently reproduced.']}
(H/'DE_AUDIT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');(H/'DE_SOURCE_MANIFEST.json').write_text(json.dumps({'root':R.name,'files':sources},indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))
