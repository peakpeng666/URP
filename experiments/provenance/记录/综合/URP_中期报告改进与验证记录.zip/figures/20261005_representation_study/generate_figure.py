#!/usr/bin/env python3
"""Render saved 16-slot study; no experiment or model execution."""
import os
os.environ.setdefault('MPLCONFIGDIR','/tmp/urp_representation_mpl')
from pathlib import Path
import json,hashlib,csv
from collections import Counter
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.lines import Line2D
OUT=Path(__file__).resolve().parent
ROOT=next(p for p in OUT.parents if (p/'URP/experiments').exists())
BASE=ROOT/'URP/experiments/online_bin_packing/representation_comparison_v1/runs/representation_actual_20261005_01'
sources={}
def read(rel,parse=True):
 p=BASE/rel;b=p.read_bytes();sources[str(p.relative_to(ROOT))]=hashlib.sha256(b).hexdigest();return json.loads(b) if parse else b.decode()
r=read('scores/report.json');a=read('scores/independent_audit.json');read('RESULTS_ZH.md',False)
assert r['state']=='terminal' and not r['errors']
assert a['passed'] and not a['errors'] and a['candidate_saved_assignments_checked']==195
assert Counter(s['status'] for s in r['scores'])=={'feasible':195,'not_run':45}
assert r['runtime_requests']==r['workers_observed']==195
slots=[];instance_rows=[]
for g in r['generation_admission']:
 group=next(x for x in r['summary']['groups'] if x['id']==g['id'] and x['panel']=='main5000')
 valid=group['feasible']==5
 if valid: assert group['BF']['sum_bins']==10335 and group['EOH']['sum_bins']==10007
 slots.append(dict(slot=g['id'],representation=g['representation'],reasoning_effort=g['reasoning_effort'],strict_admitted=g['strict']['status']=='admitted',unique_block_admitted=g['unique_block']['status']=='admitted',main_status='complete_feasible' if valid else 'not_admitted_no_quality',sum_bins=group['sum_bins'] if valid else None,BF_sum_bins=10335,EOH_sum_bins=10007,BF_identical_assignments=all(x==0 for x in group['BF']['different_assignments']) if valid else None))
 for s in r['scores']:
  if s['id']==g['id'] and s['panel']=='main5000': instance_rows.append(dict(slot=g['id'],instance=s['instance'],status=s['status'],used_bins=s.get('used_bins'),runtime_request_attempted=s.get('runtime_request_attempted',False)))
assert len(slots)==16 and len(instance_rows)==80
assert sum(s['strict_admitted'] for s in slots)==5 and sum(s['unique_block_admitted'] for s in slots)==13
assert sum(s['BF_identical_assignments'] is True for s in slots)==10
assert sorted(s['slot'] for s in slots if s['sum_bins'] is None)==['slot_03','slot_12','slot_13']
for name,data in [('slot_outcomes.csv',slots),('main_instance_outcomes.csv',instance_rows),('admission_cells.csv',r['summary']['cells'])]:
 with (OUT/name).open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
def write(name,obj): (OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
write('figure_data.json',dict(slots=slots,main_instances=instance_rows,cells=r['summary']['cells'],actual_ratings=195,not_run_rows=45,planned_rows=240,admitted_generation_slots=13,distinct_IRs_excluding_description=11,primary_panel='same five exposed historical_design_5k sequences, 5000 items each',box_count_formula='sum of bins across five complete instances; null when not admitted',missing_is_zero=False))
font='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc';font_manager.fontManager.addfont(font)
plt.rcParams.update({'font.family':font_manager.FontProperties(fname=font).get_name(),'font.size':10,'axes.unicode_minus':False,'svg.fonttype':'none','pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False,'axes.spines.left':False,'axes.edgecolor':'#9aa4ad','text.color':'#22313c','xtick.color':'#52616d','ytick.color':'#35434e','savefig.facecolor':'white'})
BLUE='#315b78';BAD='#a15a44';GRAY='#7b858d';EOH='#669484'
fig,axs=plt.subplots(2,2,figsize=(12,8.5));fig.subplots_adjust(left=.09,right=.96,top=.735,bottom=.22,hspace=.66,wspace=.25)
fig.text(.065,.95,'图 3  表示 × 推理设置：16 次探索生成的准入与主评价',fontsize=16)
fig.text(.065,.897,'每格 4 个生成槽；主评价为同 5 条已暴露序列 × 5000 项，总箱数越少越好',fontsize=11)
legend=[Line2D([0],[0],marker='o',color='none',markerfacecolor=BLUE,markeredgecolor=BLUE,label='严格准入'),Line2D([0],[0],marker='o',color='none',markerfacecolor='white',markeredgecolor=BLUE,label='仅唯一代码块口径准入'),Line2D([0],[0],color=GRAY,ls='--',label='BF：10335 箱'),Line2D([0],[0],color=EOH,ls=':',label='发表 EoH：10007 箱')]
fig.legend(handles=legend,loc='upper left',bbox_to_anchor=(.064,.861),frameon=False,ncol=4,columnspacing=1.7,handlelength=1.8,fontsize=9)
for ax,(rep,eff),letter in zip(axs.flat,[('dag','low'),('dag','high'),('python','low'),('python','high')],'ABCD'):
 ss=[s for s in slots if s['representation']==rep and s['reasoning_effort']==eff]
 cell=next(c for c in r['summary']['cells'] if c['representation']==rep and c['reasoning_effort']==eff)
 ax.set_title(f'{letter}  '+('数学 DAG' if rep=='dag' else '限定 Python')+' · '+eff,loc='left',fontsize=12,pad=37)
 ax.text(0,1.075,f"严格准入 {cell['strict_admitted']}/4    唯一代码块准入 {cell['unique_admitted']}/4",transform=ax.transAxes,fontsize=10)
 ax.axvline(10335,color=GRAY,ls='--',lw=1,zorder=1);ax.axvline(10007,color=EOH,ls=':',lw=1,zorder=1)
 ax.set(xlim=(8900,28500),ylim=(-.5,3.7));ax.set_xticks([10000,15000,20000,25000]);ax.set_xticklabels(['10000','15000','20000','25000'])
 ax.set_yticks([3,2,1,0]);ax.set_yticklabels([s['slot'].replace('slot_','槽 ') for s in ss]);ax.tick_params(axis='y',length=0,pad=9)
 ax.grid(axis='x',color='#edf0f2',lw=.6);ax.set_axisbelow(True)
 for s,y in zip(ss,[3,2,1,0]):
  v=s['sum_bins']
  if v is None:
   ax.text(12400,y,'未准入 · 无质量分数',va='center',color=GRAY,fontsize=10)
  else:
   color=BLUE if v==10335 else BAD
   ax.scatter([v],[y],s=55,facecolor=color if s['strict_admitted'] else 'white',edgecolor=color,lw=1.6,zorder=4)
   ax.text(v+540,y,f'{v}',va='center',fontsize=10,color=color)
 for spine in ['bottom']: ax.spines[spine].set_color('#b6bdc3')
for ax in axs[1]:ax.set_xlabel('五实例总箱数',labelpad=9)
fig.text(.09,.142,'共 13 槽准入、11 个不同 IR；实际评分 195 次且均可行，另 45 个预定评分行未运行（非零分）',fontsize=10)
fig.text(.09,.096,'10 槽在这 5 个实例上的分配与 BF 完全一致；未发现优于 BF 或发表 EoH 的候选，不据此证明普遍等价',fontsize=9)
fig.text(.09,.05,'每格仅 4 次探索生成；不计算掩盖缺失的条件均值，不作显著性、因果或能力排名；195 次评分不是 195 个独立样本',fontsize=9,color='#586570')
for ext in ['svg','pdf','png']:fig.savefig(OUT/f'figure_03_representation_study.{ext}',dpi=240)
plt.close(fig)
write('source_hashes.json',sources)
caption='''# 图 3：表示与推理设置探索研究

图注：GLM-5.3 在数学 DAG / 限定 Python 与配置 low / high 的四个条件中各生成4次，共16槽。严格准入与唯一代码块准入是同一响应的两种提取口径，不是重复生成；唯一代码块准入不代表算法去重。四格严格/唯一代码块准入分别为 DAG low 2/4、4/4；DAG high 3/4、4/4；Python low 0/4、1/4；Python high 0/4、4/4。每个点给出准入候选在同五条已暴露5000项历史设计序列上的总箱数，实心表示严格准入，空心表示仅唯一代码块口径准入。槽03、12、13未准入，无质量分数，不作零分或算法质量失败。BF与固定发表EoH保存基线总箱数分别为10335与10007。

结果边界：13槽进入评分，去除description后有11个不同IR。195次实际评分全部可行；其余45个预定行未运行，不能称240次已执行。10槽在主面板五实例上的分配逐项与BF相同，只是这些输入上的行为证据，不是普遍等价证明。每格仅4次生成，未控制模型采样seed；没有条件均值、置信区间、显著性、因果或能力排名结论。五个主实例及其256项前缀已暴露、彼此有关联，195次评分不构成195个独立样本。限定Python经白名单AST转同一IR，未直接执行候选Python，也不是完整EoH进化或通用编程能力基准。low/high来自配置元数据，不冒称已观察物理HTTP参数。

计算：每槽主评价总箱数 B = sum(i=0..4) B_i，仅当五个实例全部可行时有值；未准入记录在JSON为null、CSV数值格留空。主图为解释性原始箱数展示，不替换研究预定质量指标 100×(sum B−sum L1)/sum L1；L1为体积下界而非最优值。

文件：SVG保留可编辑文字；PDF嵌入字体；PNG为240 dpi。slot_outcomes.csv有全部16槽，main_instance_outcomes.csv有全部80个主面板预定行，admission_cells.csv保留四格统计。源数据只读，不重跑任何模型或装箱策略。

复现：python URP/docs/figures/20261005_representation_study/generate_figure.py

## 源文件与SHA-256
'''
for p,h in sources.items():caption+=f'\n- `{p}`\n  - `{h}`\n'
(OUT/'CAPTIONS_ZH.md').write_text(caption)
write('artifact_hashes.json',{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(OUT.iterdir()) if p.is_file() and p.name!='artifact_hashes.json'})
print('Rendered; 16 slots, 80 main rows, 195 actual ratings, 45 not run; all source values checked.')
