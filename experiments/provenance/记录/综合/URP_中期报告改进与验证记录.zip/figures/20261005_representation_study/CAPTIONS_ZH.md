# 图 3：表示与推理设置探索研究

图注：GLM-5.3 在数学 DAG / 限定 Python 与配置 low / high 的四个条件中各生成4次，共16槽。严格准入与唯一代码块准入是同一响应的两种提取口径，不是重复生成；唯一代码块准入不代表算法去重。四格严格/唯一代码块准入分别为 DAG low 2/4、4/4；DAG high 3/4、4/4；Python low 0/4、1/4；Python high 0/4、4/4。每个点给出准入候选在同五条已暴露5000项历史设计序列上的总箱数，实心表示严格准入，空心表示仅唯一代码块口径准入。槽03、12、13未准入，无质量分数，不作零分或算法质量失败。BF与固定发表EoH保存基线总箱数分别为10335与10007。

结果边界：13槽进入评分，去除description后有11个不同IR。195次实际评分全部可行；其余45个预定行未运行，不能称240次已执行。10槽在主面板五实例上的分配逐项与BF相同，只是这些输入上的行为证据，不是普遍等价证明。每格仅4次生成，未控制模型采样seed；没有条件均值、置信区间、显著性、因果或能力排名结论。五个主实例及其256项前缀已暴露、彼此有关联，195次评分不构成195个独立样本。限定Python经白名单AST转同一IR，未直接执行候选Python，也不是完整EoH进化或通用编程能力基准。low/high来自配置元数据，不冒称已观察物理HTTP参数。

计算：每槽主评价总箱数 B = sum(i=0..4) B_i，仅当五个实例全部可行时有值；未准入记录在JSON为null、CSV数值格留空。主图为解释性原始箱数展示，不替换研究预定质量指标 100×(sum B−sum L1)/sum L1；L1为体积下界而非最优值。

文件：SVG保留可编辑文字；PDF嵌入字体；PNG为240 dpi。slot_outcomes.csv有全部16槽，main_instance_outcomes.csv有全部80个主面板预定行，admission_cells.csv保留四格统计。源数据只读，不重跑任何模型或装箱策略。

复现：python URP/docs/figures/20261005_representation_study/generate_figure.py

## 源文件与SHA-256

- `URP/experiments/online_bin_packing/representation_comparison_v1/runs/representation_actual_20261005_01/scores/report.json`
  - `69870bae8780bbd6f938683f454587a18c3e481a7fc8201019fd843fe77fdd33`

- `URP/experiments/online_bin_packing/representation_comparison_v1/runs/representation_actual_20261005_01/scores/independent_audit.json`
  - `9d23639828922920b89bf0e4d76aca24034f67987e06fd6db86e2a0379b8f607`

- `URP/experiments/online_bin_packing/representation_comparison_v1/runs/representation_actual_20261005_01/RESULTS_ZH.md`
  - `642559056328976f4d158309ca7d130c957833a21660041f2582e3d21a2510a3`
