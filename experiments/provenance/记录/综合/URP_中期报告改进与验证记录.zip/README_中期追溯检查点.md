# URP中期报告改进追溯检查点（第五版）

2026-10-05 08:38 UTC。[改进与验证记录](改进与验证记录.md)及[JSON账本](改进与验证记录.json)共22条；前四版原ZIP与正文保留。本版已纳入终态16槽，第四版“未开始”的说法只属历史状态。

本轮16正常stop；strict5、唯一块13；13槽11不同IR；195实际评分全部可行、45未运行；225候选/旧基线分配独立审计通过。完整主面板10槽与BF10335箱同分配，09为10744，04/14为25000，无候选胜BF或固定EoH10007。两个盲审mismatch照常评分。研究累计27次，简单传输控制另1；物理HTTP未知，初始接入smoke不计科学样本。人工诊断反馈仍暂停0次。

[新图PDF](figures/20261005_representation_study/figure_03_representation_study.pdf)、[SVG](figures/20261005_representation_study/figure_03_representation_study.svg)、[PNG](figures/20261005_representation_study/figure_03_representation_study.png)及同目录CSV/图注/来源hash均随包。每格n4、已暴露数据、无模型采样seed控制、限定Python仅转同IR，不支持通用能力排名、强因果、任意Python执行或完整EoH多代复现。

完整新研究另交URP_表示推理16槽完整研究证据_20261005.zip，641来源文件、645ZIP项，包含原始58文件生成证据与原ZIP、代码、所有原始stdout/分配/metadata和审计；只排除一份被终态取代的中间传递状态说明，未改科学字节。DEPENDENCIES.json列遗漏旧URP/运行时依赖，本包不是自包含环境。秘密、缓存、vendor、论文全文和未完成NumPy隔离研究未打包。文件/hash见[包内清单](traceability_evidence_20261005/manifest.json)。上传仍由最终交付确认。

相关已核对既有交付：[改进记录](https://drive.google.com/file/d/1-61-KrYcsOnmXL9hJyNroFTe4EQq7cWO/view?usp=drivesdk)、[先前P3完整证据](https://drive.google.com/file/d/1-RWPvVrkVPPv5BADBNwnf_M-2QYkuXxa/view?usp=drivesdk)、[前两张图](https://drive.google.com/file/d/12_KBP3YtjXgw8FQanoCvJwCpzXE0-tac/view?usp=drivesdk)。

[静态核查](追溯记录静态核查.json)验证字节、链接、原freeze、旧版备份及图表产物。本次文档打包没有重跑实验、调用模型或恢复反馈。
