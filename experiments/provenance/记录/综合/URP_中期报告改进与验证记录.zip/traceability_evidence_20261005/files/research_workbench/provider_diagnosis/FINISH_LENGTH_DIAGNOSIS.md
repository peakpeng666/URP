# finish_reason=length 的终稿捕获离线核查

## 结果与边界
7项合成SSE测试全部通过。本地固定版本路径不会仅因finish_reason=length删除已接收的content；有content时会生成text-delta和text-end。reasoning-only+length则没有终稿文本。该结果仅排除了这组本地正常SSE样例中的通用length丢文本行为，不能证明真实供应商没有发送content，也不能定位9次历史失败根因。

测试覆盖真实OpenCode LLMRequestPrep.prepare、ProviderTransform、AI SDK streamText/wrapLanguageModel、安装@ai-sdk/openai-compatible 2.0.41及真实OpenCode LLMAISDK.toLLMEvents。所有HTTP响应来自注入mock fetch；未访问网络、未读取认证、未检查headers、未读取实际推理；推理片段只是合成常量。

未动态执行SessionProcessor持久化、CLI stdout事件消费、父任务捕获脚本或远端compiled CLI。远端已核CLI版本1.18.34，但内嵌SDK版本未知，不能用本地2.0.41测试等同远端验证。

## 测试工件
- finish-length-stream-test.ts：可复现离线测试代码
- finish-length-stream-results.json：各case的已知终稿marker、事件类型、finish与合成usage；不保存真实推理
- 7种条件：content+stop、content+length、reasoning-only+length、reasoning+content+length、reasoning+分段content+length、content与length同chunk、底层7-byte分片跨UTF-8中文字符
- 每case恰好1次mock调用；有content的6项在AI SDK response.text与OpenCode适配器text-delta拼接结果均准确得到KNOWN_MARKER_终稿，text-end恰好1个；reasoning-only项两处均空且无text-end；finish正确保持stop/length
- 测试采用model.options.reasoningEffort:low、completion上限16384，无真实任务提示词，不是历史原请求重放

## 固定源码证据
OpenCode固定commit：aec0b9a6d8898f68f923aaf08b7306d931fd9d76。SDK官方tag对应commit：99327b1d7b3d172ed0aae7230ae153f2d32b0ebb。本地SDK含OpenCode官方error处理patch；未改length/content处理。

1. [SDK聊天流处理](https://github.com/vercel/ai/blob/99327b1d7b3d172ed0aae7230ae153f2d32b0ebb/packages/openai-compatible/src/chat/openai-compatible-chat-language-model.ts#L457-L521)：finish_reason映射为状态，delta.content独立生成text-start/text-delta；后续flush（656–672）结束活跃reasoning/text，不要求finish为stop
2. [OpenCode事件适配器](https://github.com/anomalyco/opencode/blob/aec0b9a6d8898f68f923aaf08b7306d931fd9d76/packages/opencode/src/session/llm/ai-sdk.ts#L140-L159)：text-delta原样传text，text-end转为LLMEvent.textEnd；finish-step/finish独立保留reason（83–121），不因length清空文本
3. [SessionProcessor文本持久化](https://github.com/anomalyco/opencode/blob/aec0b9a6d8898f68f923aaf08b7306d931fd9d76/packages/opencode/src/session/processor.ts#L500-L549)：delta累加currentText，text-end运行experimental.text.complete hook、设置time.end并updatePart；finish本身不清空内容。该层仅源码检查，没有动态持久化测试；第三方text.complete插件仍可能修改文本，不能由本测试排除
4. [CLI输出](https://github.com/anomalyco/opencode/blob/aec0b9a6d8898f68f923aaf08b7306d931fd9d76/packages/opencode/src/cli/cmd/run.ts#L749-L764)：JSON模式在part.type=text且time.end存在时emit(text,{part})，没有以finish_reason=stop为前提。普通终端模式会trim文本。两种模式应区分，不可用UI显示代替字节级JSON捕获

## 后续更新
2026-10-05：安全导出的原capture_runner.py现已取得，并在独立mock测试8/8通过；此前“脚本不可得”的限制已解除，远端实流/嵌入SDK未知的限制仍保留。最终收口见LOCAL_DIAGNOSIS_CLOSURE.md，以下保留本报告最初核查时的状态。

## 父捕获脚本最初可得性
本地glm_generation_transfer目录及其结果ZIP清单没有.py/.js/.ts/.sh捕获脚本，本次没有打开实际模型推理或原始事件内容。completion_budget_verified/manifest.json:79声明响应为未改动CLI part.text UTF-8字节、不添加分隔/换行；这只是捕获约定，不是已审查的脚本实现，不能据此排除stdout过滤/进程结束竞态。

下一项有用证据是原捕获脚本的无密钥代码，以及真实运行安全计数：text事件数、text字符数、text-end数、finish、进程退出/超时顺序。若必须做新的有界实测，应由父任务明确决定；本报告不自动建议花费更多模型额度，也不声称终稿为空必然来自供应商。

## 复现
从cli_closure/packages/opencode目录，以本地已安装build_baseline/toolchain/package/bin/bun运行../../../provider_diagnosis/finish-length-stream-test.ts；XDG各目录指向provider_diagnosis/isolated。无需密钥、网络或新安装。未改原始研究、源码、已交付ZIP。
