# 本地诊断收口：原捕获器与variant路径

## 结论
原远端捕获脚本已取得安全导出并直接测试：收到终端text事件时，length不会让它丢弃文本，reasoning也不会被当成终稿。固定源码的CLI/config均未指定variant时，没有在这条非交互路径自动选择high/max；可用variant列表不等于选中了variant。

结合此前本地SDK/SSE测试，目前没有发现可解释历史空终稿的通用length丢文本或自动variant覆盖行为；但这不是历史根因排除证明。实际远端内嵌SDK版本、真实模型流是否含content、运行时插件与解析是否完全等于本地路径仍未知，不宣称供应商一定没发终稿。

## 新来源与哈希
已直接读取glm_generation_transfer/safe_diagnostic/capture_verified/：
- capture_runner.py SHA256：358f4ae171d75f8e24704dfbb7f5bbc39f366a39abddb8b72f2798e7563969e9
- safe-invocation.json SHA256：99264b04a6f204825b1f44715d8f75981910b93a5c6ea0e7c470be990f3d7051
- evidence-index.json SHA256：4fd7ad945dc55c26f7730c5b579f0182ae3a7a6bbdc8cd5e76d2bf880aded2df
- 父任务提供已校验外包ZIP SHA256：1fed8a8deecc29068a876af2eb90773ba3f10b037de465c84db70ba16d20f492；本线程没有重新打开外包
safe-invocation确认CLI argv无--variant、agent variant null、top-level variant null、configured model variants absent。该导出不推断自动variant，由下述源码审计补充。

## 原捕获函数mock测试
capture-harness-test.py按上列源码哈希导入原模块，仅调用capture()。不会调用run_candidate()，不会启动OpenCode，也不会读取认证或实际推理。子进程仅是Python合成CLI事件输出器，每项墙钟10秒、事件64KiB限制。

capture-harness-results.json记录8/8通过：
1. text+stop
2. text+length
3. reasoning-only+length（capture正常完成，但无终稿，capture_succeeded false）
4. reasoning+text+length
5. 重复同part ID同文本，去重不重复拼接
6. 多个text part按到达次序连接；stdout每7字节拆分，含UTF-8中文
7. step_finish:length先于terminal text，仍保留后到文本
8. 最后事件无换行，EOF时处理剩余buffer

有终稿的7项，response.txt都与已知字符串“两个空格 + KNOWN_MARKER_终稿 + 换行”的UTF-8字节完全相等。reasoning合成常量从不进入response.txt。原源码测试前后hash相同。JSON结果中logical_cli_invocations=1是原函数给synthetic subprocess的计数字段，并非真实CLI；每项真实模型请求均0。

代码位置：capture_runner.py:141记录length；158–164收集唯一text part；187–190在EOF处理未换行buffer；205–206按arrival order写原始text字节；214–218允许length非空结果成功。达到超时/事件上限/异常状态后会停收后续事件，这是明确保护策略，不是length特有丢失；此次测试未覆盖所有异常竞态。

## 无variant时的源码链
OpenCode固定commit aec0b9a6d8898f68f923aaf08b7306d931fd9d76：
- [run.ts:212–215](https://github.com/anomalyco/opencode/blob/aec0b9a6d8898f68f923aaf08b7306d931fd9d76/packages/opencode/src/cli/cmd/run.ts#L212-L215)：--variant无默认值
- run.ts:833–877非交互分支，868把args.variant传给session.prompt
- server/routes/instance/httpapi/handlers/session.ts:300附近使用SessionPrompt服务；本路径不是TUI选择器
- [agent.ts:272–282](https://github.com/anomalyco/opencode/blob/aec0b9a6d8898f68f923aaf08b7306d931fd9d76/packages/opencode/src/agent/agent.ts#L272-L282)：新自定义agent初值不含variant；value.variant缺失时不会添加
- [prompt.ts:646–666](https://github.com/anomalyco/opencode/blob/aec0b9a6d8898f68f923aaf08b7306d931fd9d76/packages/opencode/src/session/prompt.ts#L646-L666)：优先显式input.variant，否则只采用有效ag.variant；两者缺失则undefined
- [request.ts:80–91](https://github.com/anomalyco/opencode/blob/aec0b9a6d8898f68f923aaf08b7306d931fd9d76/packages/opencode/src/session/llm/request.ts#L80-L91)：只有user.model.variant存在才取model.variants；否则空对象，不改model.options
- provider.ts:1619–1627可能生成/合并variant目录，但不是选定variant的逻辑；不能把configured variants缺失解读为运行时完全没有可用variants

variant-options-test.ts对真实LLMRequestPrep.prepare执行3/3通过：model low、目录有high/max、user.variant缺失→low；显式high→high；显式max→max。结果variant-options-results.json。SessionPrompt/CLI选择链是源码检查，并非动态完整CLI测试；不外推所有交互TUI/v2/恢复会话路径。

## 最小下一项真实控制（仅建议，未执行）
父任务提出的方案优于同时降低token cap或改模型的marker测试：保持远端同一官方CLI、同模型glm-5.3、同已正确配置、16384 completion cap、480秒墙钟、相同采样/step2/工具禁用/空会话/捕获器；只把原复杂研究提示换成“原样序列化既有固定BestFit mathDAG合法fixture”的短明确提示。不要求创造、优化、搜索或运行候选，不能改成新研究样本。

需要冻结：既有合法fixture来源和SHA256、预期输出的规范化文本或字节SHA256、短提示精确UTF-8与SHA256、配置/CLI/捕获器哈希。不得临时编造新fixture或“修复”输出。此处未给fixture正文，因为本线程未取得父任务选定的具体合法fixture，不猜测结构。

执行预算应写成“最多1次逻辑CLI invocation、无外部重试/续写/修复”，不是保证仅1次HTTP。官方内部SessionRetry仍可能最多5次重试；原捕获器将实际HTTP次数记unknown，正常单message上界6，须保留该限制。若用户只授权严格1次HTTP而不能容忍此上界，不能直接使用未改变的CLI来承诺该控制。

可区分结果：
- 非空且与固定fixture一致，finish stop：远端端到端至少对简单明确任务可产生并保留终稿；原任务复杂度/推理预算依赖更值得研究。不能由此证明原任务一定是预算问题或质量合格
- 非空但length/不完整/错误：捕获链可见终稿，但简单序列化仍有截断或指令失败；不得修复后计成功
- 空且length、正常退出：简单任务也复现问题，削弱“仅复杂研究提示”解释；仍不能区别供应商无content与远端内部流/解析丢失
- stop但空：更提示需要安全事件计数/解析差异调查，不能直接归因服务端
- 超时/API error/tool/第二message/捕获限制：控制无效或另类失败，停止，不重试，不进入研究评分

此控制属于诊断，不是质量实验，不替换9个失败槽位，不做得分填补、不纳入进化代次。完成一次即关闭控制，后续是否需要调查由用户/父任务决定。本地诊断阶段到此收口，不扩展OpenCode开发。

## 工件与限制
- capture-harness-test.py / capture-harness-results.json
- variant-options-test.ts / variant-options-results.json
- 既有finish-length-stream-test.ts/results.json覆盖7种SSE条件；本次捕获器补齐下游，但两段不是远端实流一体化复现
- 未改官方源码、导出捕获脚本、真实研究、已交付ZIP；未调用模型、未安装依赖
