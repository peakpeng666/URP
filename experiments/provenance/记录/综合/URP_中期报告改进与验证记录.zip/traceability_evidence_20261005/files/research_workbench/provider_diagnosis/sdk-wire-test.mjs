import assert from 'node:assert/strict';
import { writeFile } from 'node:fs/promises';
import { createOpenAICompatible } from '../cli_closure/packages/opencode/node_modules/@ai-sdk/openai-compatible/dist/index.mjs';

// Offline only: injected fetch never calls a transport and never reads headers.
const results = [];
for (const [label, options, expected] of [
  ['snake_only', { reasoning_effort: 'low' }, undefined],
  ['camel_only', { reasoningEffort: 'low' }, 'low'],
  ['both_conflicting', { reasoning_effort: 'low', reasoningEffort: 'high' }, 'high'],
  ['camel_max', { reasoningEffort: 'max' }, 'max'],
]) {
  for (const mode of ['generate', 'stream']) {
    let body;
    let calls = 0;
    const provider = createOpenAICompatible({
      name: 'zhipuai-coding-plan', baseURL: 'https://offline.invalid/v4',
      fetch: async (_url, init) => {
        calls++;
        body = JSON.parse(init.body);
        if (mode === 'stream') return new Response('data: [DONE]\n\n', {headers: {'content-type': 'text/event-stream'}});
        return Response.json({id:'offline', model:'glm-5.3', created:0, choices:[{index:0,message:{role:'assistant',content:'mock'},finish_reason:'stop'}],usage:{prompt_tokens:1,completion_tokens:1,total_tokens:2}});
      },
    });
    const model = provider.chatModel('glm-5.3');
    const input = {prompt:[{role:'user',content:[{type:'text',text:'Offline fixture'}]}], maxOutputTokens:2048,
      providerOptions:{'zhipuai-coding-plan':{thinking:{type:'enabled',clear_thinking:false},...options}}};
    const response = await (mode === 'stream' ? model.doStream(input) : model.doGenerate(input));
    if (mode === 'stream') for await (const _ of response.stream) {}
    assert.equal(calls,1);
    assert.equal(body.reasoning_effort, expected);
    assert.equal(body.max_tokens,2048);
    assert.deepEqual(body.thinking,{type:'enabled',clear_thinking:false});
    results.push({label,mode,calls,body});
  }
}
await writeFile(new URL('./sdk-wire-results.json',import.meta.url),JSON.stringify({sdk:'@ai-sdk/openai-compatible@2.0.41',network:'none; injected mock fetch',headers:'not inspected or persisted',results},null,2)+'\n');
console.log('PASS: 8 offline SDK serialization cases; snake-only drops reasoning_effort, camelCase reaches wire');
