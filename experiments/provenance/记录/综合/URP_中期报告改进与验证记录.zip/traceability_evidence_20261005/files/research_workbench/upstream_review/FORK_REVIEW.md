# OpenCode v1.18.34 科研 fork 最小内核审计

## 固定证据与验证边界

- 官方仓库：https://github.com/anomalyco/opencode
- 官方 tag v1.18.34，解引用 commit：aec0b9a6d8898f68f923aaf08b7306d931fd9d76
- tag 证据：https://api.github.com/repos/anomalyco/opencode/git/ref/tags/v1.18.34
- 本目录 SOURCE_MANIFEST.json 记录 17 个相关文件的固定 commit URL 和 Git blob SHA；全部本地字节已经按 Git blob 哈希校验一致
- MIT LICENSE 原文保留。LICENSE:5–13 允许使用、修改、分发，要求副本/实质部分保留版权和许可。第三方依赖、商标、服务方接入条款没有因此自动获得同样权限
- 本次只读审计官方源码；未运行项目、未安装、未修改正在运行的 CLI/环境，未调用模型，未验证 fork 对 Coding Plan 的真实兼容性。下文设计与测试为建议，未实现、未执行
- 所有行号均相对本目录保存的官方固定版本文件。链接格式为 https://github.com/anomalyco/opencode/blob/aec0b9a6d8898f68f923aaf08b7306d931fd9d76/{path}#L{line}

## 关键结论

### 1. steps:1 的污染来自首轮前置注入，不是模型自己的判断

packages/opencode/src/session/prompt.ts:
- 1132：step++ 在调用模型前
- 1178–1179：maxSteps = agent.steps ?? Infinity；isLastStep = step >= maxSteps
- 1255：experimental.chat.messages.transform 执行
- 1281：在转换后的 modelMsgs 后追加 assistant 角色 MAX_STEPS_PROMPT
- 1283–1286：仍传 tools；toolChoice 只根据结构化格式决定，不因 isLastStep 强制 none
- 1319–1343：没有 maxSteps 硬 break。模型若继续 tool-calls，仍可能继续循环

packages/core/src/session/runner/max-steps.ts:1–16 明确要求：说明达到最大步数、总结已完成工作、列未完成任务、给下一步建议。由此 steps:1 首次请求已经被污染。steps:2 只避免首轮注入，不等于“一次请求”，也不保证不附总结。MAX_STEPS_PROMPT 宣称工具已禁用，但审计到的这条路径本身未按 isLastStep 从代码层禁用工具。

插件 messages.transform 在注入前，因此不能用这个 hook 删除稍后追加的 MAX_STEPS_PROMPT；system.transform 只拿 system，不拿这条 assistant 消息。text.complete 后处理删除文本无法挽回已浪费的推理与违背原任务的生成。

### 2. “一次生成”必须区分一次主回答、一次 LLM 调用、一次 HTTP 尝试

prompt.ts:1133–1139 首轮异步 fork title()；title() 的 194–241 包含独立 llm.stream，234 行 retries:2。只盯主 assistant 消息会漏算标题请求。title() 在已有非默认标题或子 session 等情况下会跳过，但生产级严格模式应明确禁用辅助生成，而非依赖偶然跳过。

prompt.ts:1252–1253 的 summary.summarize() 对应 session/summary.ts:102–127，只更新代码 diff/summary 元数据，没有模型调用。不能把这个方法误判为自动文字总结根因。

prompt.ts:1150–1167 的 compaction 分支和 compaction.ts:425 的 processor.process() 会生成压缩内容；compaction.ts:468–537 存在 auto-continue。严格单次模式必须拒绝/跳过这类额外生成，而不是等其发出后再取消。

建议新增独立 execution policy（名称自定）：single_generation，主生成数1、HTTP attempts上限1、辅助模型调用关闭、auto-compaction关闭、tools为空且 toolChoice none、不注入 max-steps提示；一次流终止后直接返回原始输出与真实 finish/status。遇长度截断返回 partial/truncated，不追加“修复/总结”调用。若科研流程需要检索，先显式完成检索阶段，再用该模式生成最终产物；不能同时承诺单次模型请求与任意多轮 agent 工具推理。

### 3. SDK maxRetries:0 不会取消 SessionRetry

session/llm.ts:323：AI SDK streamText maxRetries = input.retries ?? 0。
session/processor.ts:654、674–688：llm.stream 外包 Effect.retry(SessionRetry.policy(...))。
session/retry.ts:31：RETRY_MAX_RETRIES = 5；183–205 定义策略；193 在 meta.attempt > 5 时停止。
test/session/retry.test.ts:127–146 官方测试明确“stops after five retries”，期望 [1,2,3,4,5]。
因此主回答一次 process 可发生初次+5次重试（6次尝试），不能用 AI SDK 的0宣布“无重试”。title 自己使用 retries:2 则是另一个调用路径。
建议让 SessionRetry 显式接受每次运行 retry policy，严格单次为0，其余科研运行以总预算为上限；预算拒绝必须是不可重试的类型化错误；中途已有输出时禁止无提示重放，记录 partial/unknown usage。

### 4. 请求预算应在发送前原子预留，完成后核对；usage 不能充当前置闸门

processor.ts:452–468 在 finish 事件才记录 usage/cost，459 是赋值 tokens，不是全运行累计；多个调用/尝试/子任务/辅助调用必须独立汇总。
LLM 准备 seam：llm.ts:106–113 获取 prepared；request.ts:101–175 组装 messages、params、tools。chat.params 可设置 maxOutputTokens（plugin/src/index.ts:247–256；request.ts:114–132）。
最终 provider transform 还会发生于 llm.ts:330–337；native-runtime.ts:90–113 有另一条请求路径。不能仅在 UI SDK 层计一次 prompt 就认为计完网络请求。

推荐共同 BudgetLedger + transport guard：
1. 每次逻辑生成记录 runID/sessionID/attemptID/purpose；确定允许的模型与输出上限
2. 在实际 generation HTTP dispatch 前，原子检查并扣除请求额度；并发标题/子任务/重试共用 run ledger，越界零发包
3. 输入估算须包含最终 system/messages/tools schema/多模态以及 provider包装，按供应商兼容 tokenizer 或有根据的保守上界；预留 input bound + enforced maxOutputTokens（需明确 reasoning 是否包含于该上限）
4. 响应 usage 到达再核对与结算；失败、abort、流断且 usage 缺失不能按0回滚当作没花费；保留不确定预留并标记 unknown
5. 无可证明 token 上界/供应商不会遵守上限时，不承诺“真实总token硬上限”；严格模式 fail closed，或明确只提供估算预算
6. provider.ts:96–125 timeoutFetch 在118实际 fetch；1849 将其交给SDK，可作选定AI-SDK provider的最终发包闸门。必须同样覆盖 native/特殊provider路径，不能声称一个 wrapper 覆盖全部运行时
7. SDK client.ts:50–60 的 custom fetch 只封装客户端→OpenCode Server，不能替代模型端 HTTP guard

日志只允许结构化白名单：run/attempt、purpose、模型、非敏感请求ID、开始结束、状态、估算/预留/实际token、重试类别。不得记录 auth/provider option 整体、headers、URL query、请求正文、原始错误对象。llm.ts:281–291 当前直接 log error；processor.ts:614 附近亦记录错误；必须统一 sanitize，而不是仅新预算日志不带key。测试用诱饵 Authorization/API key 放入嵌套 cause、URL、header、错误文本，断言均不出现。遥测同样审查。

## 插件/SDK可以做什么，哪些需要core改造

已验证插件定义 packages/plugin/src/index.ts:
- config / custom tool / auth / provider：222–230
- chat.message：234–243
- chat.params（含 maxOutputTokens）：247–256
- chat.headers：257–260
- tool.execute.before/after：266–281
- experimental.chat.messages.transform / system.transform：282–296
- experimental.session.compacting：305–308
- experimental.compaction.autocontinue：316–326
- experimental.text.complete：327–330
- tool.definition：334

可以插件化：科研系统提示、工具定义、证据收集和引用校验工具、工具结果规范、输出上限、诚实client header、可观测事件、压缩提示/是否合成继续消息。
不能仅依靠这些公开hooks可靠实现：移除注入后的MAX_STEPS、严格单次网络请求、所有路径的硬token账本、SessionRetry policy、并发原子全局预算。chat.params 可抛错阻止某次运行，但hook并没有完整最终请求与专用预算协议，不应包装成已证明的全运行硬限额。
Plugin.trigger（opencode/src/plugin/index.ts:284–296）依次 await hooks。auth.loader 的返回 options可以影响特定provider fetch（需实现测试）；它不是稳定、通用的所有provider HTTP审计接口，不建议通过改认证插件实现核心预算。

SDK v2 generated sdk.gen.ts:3742–3794 的 prompt 支持 model/agent/noReply/tools/format/system/variant/parts；4095 起 promptAsync 类似。没有此处公开的 strictSingle/maxRequests/totalTokens/maxRetries 参数；noReply 是不生成答复，不是只生成一次。SDK适合会话编排、独立科研UI、事件与结果展示；其请求不能覆盖服务端内部调用。增加执行策略后应扩展 server schema 并正规再生SDK，避免手改生成文件。

## 诚实身份与兼容性边界

request.ts:18 默认UA是 opencode/版本；187–206 headers 最后合并 model.headers 与 chat.headers（插件可以覆盖）。x-opencode-client 只在 providerID startsWith opencode 分支使用。
科研fork建议如 research-workbench/0.x (based-on opencode/1.18.34)，保留upstream来源但不冒称官方客户端。其他provider adapter亦有UA硬编码（provider.ts:666,799,869），选定首发provider之外的身份覆盖须另审。
官方CLI成功调用智谱 Coding Plan 不证明fork或自定义SDK获服务端接受，也不构成接入条款许可。用诚实身份做明确授权下的小额兼容测试；若被拒绝，获取服务方支持或用其认可API路线，不伪装官方绕过限制。

## 最小维护patch集合（建议，不是完成声明）

P1 执行策略：prompt.ts + 输入schema/config定义。新策略与旧steps语义分离；关闭标题/压缩/自动续写；生成计数硬停止；无MAX_STEPS注入；纯文本模式禁止工具。
P2 重试策略：retry.ts、processor.ts、llm.ts 统一显式retry额度和不可重试BudgetDenied；严格模式所有路径0重试。
P3 预算与安全日志：新增小型独立BudgetLedger模块；LLM准备后预留、AI-SDK/native transport前闸门、finish/异常结算；shared run ledger；统一日志sanitize。未覆盖运行时必须拒绝启动严格模式。
P4 API/SDK：暴露策略、预算、终止原因、usage unknown及预算事件；从schema再生SDK；前端仅展示真实状态，不伪造助手总结。
其余科研领域功能留在插件/独立UI，避免广泛fork工具和provider实现。身份可先用受支持chat.headers覆盖，并给发行物独立命名/版本/许可来源说明。

## 必要测试（均尚未执行）

- steps:1基线：首个模型输入包含MAX_STEPS；strict模式不含；原始输出不附污染文本
- steps:2基线：工具返回后可以发生第二轮，验证它不是硬一次限制
- strict纯文本：exactly1 generation dispatch；标题/compaction/工具/自动继续均0；finish length/error不触发补全
- Retry：429/500/超时默认5重试基线；strict0；预算耗尽不可重试；abort不重试
- 竞态：两个并发attempt抢最后1额度仅1个实际发包；parent/child/title共享额度；重启/恢复不重新获得已消耗额度
- Token：估算包含system/tools；不足时0发包；输出上限不超过预留；usage缺失不当0；cache/reasoning避免双计；供应商超预期使用如实报超出/不可保证
- 两运行时与fallback：AI SDK、native及native→SDK fallback都不会双预留/漏计；不支持的provider严格模式拒绝
- 日志：诱饵秘密在header/query/body/cause/error全链不泄漏；不会把原始provider response带入遥测
- SDK：策略schema参数穿透与返回原因；noReply仍0生成；普通模式旧行为回归
- 身份：实际发包UA准确声明fork；没有悄悄回退官方伪装；Coding Plan兼容性标记pending直到真实测试
