import assert from 'node:assert/strict'
import { streamText, wrapLanguageModel } from '../cli_closure/packages/opencode/node_modules/ai/dist/index.mjs'
import { Effect } from '../cli_closure/packages/opencode/node_modules/effect/dist/index.js'
import { prepare } from '../cli_closure/packages/opencode/src/session/llm/request'
import { providerOptions, message } from '../cli_closure/packages/opencode/src/provider/transform'
import { adapterState, toLLMEvents } from '../cli_closure/packages/opencode/src/session/llm/ai-sdk'
import { createOpenAICompatible } from '../cli_closure/packages/opencode/node_modules/@ai-sdk/openai-compatible/dist/index.mjs'

const marker='KNOWN_MARKER_终稿'
const cases=[
  {name:'content_stop',finish:'stop',pieces:[marker],reasoning:false},
  {name:'content_length',finish:'length',pieces:[marker],reasoning:false},
  {name:'reasoning_only_length',finish:'length',pieces:[],reasoning:true},
  {name:'reasoning_content_length',finish:'length',pieces:[marker],reasoning:true},
  {name:'reasoning_fragmented_content_length',finish:'length',pieces:['KNOWN_','MARKER_','终','稿'],reasoning:true},
  {name:'content_in_finish_chunk_length',finish:'length',pieces:[marker],reasoning:true,coincident:true},
  {name:'fragmented_utf8_bytes_length',finish:'length',pieces:['KNOWN_','MARKER_','终稿'],reasoning:true,byteFragments:true},
]
const model={id:'glm-5.3',name:'GLM-5.3',providerID:'zhipuai-coding-plan',api:{id:'glm-5.3',npm:'@ai-sdk/openai-compatible',url:'https://offline.invalid/v4'},capabilities:{temperature:true,reasoning:true,toolcall:true,input:{text:true},output:{text:true}},options:{reasoningEffort:'low'},headers:{},limit:{context:1000000,output:16384}}
const prepared=await Effect.runPromise(prepare({model,provider:{id:model.providerID,options:{}},auth:undefined,agent:{name:'offline',prompt:'Synthetic fixture only.',options:{},permission:[]},user:{id:'msg_offline',model:{providerID:model.providerID,modelID:model.id}},sessionID:'ses_offline',messages:[{role:'user',content:'Synthetic capture test.'}],system:[],tools:{},flags:{outputTokenMax:16384,client:'offline-diagnosis'},isWorkflow:false,plugin:{trigger:(_name,_input,output)=>Effect.succeed(output)}} as never))
const results=[]
for (const test of cases) {
  const chunks=[]
  const add=(delta,finish=null)=>chunks.push({id:'offline',object:'chat.completion.chunk',created:0,model:'glm-5.3',choices:[{index:0,delta,finish_reason:finish}]})
  add({role:'assistant'})
  if(test.reasoning)add({reasoning_content:'SYNTHETIC_REASONING_FIXTURE'})
  for(const piece of test.pieces)add({content:piece},test.coincident?test.finish:null)
  if(!test.coincident)add({},test.finish)
  chunks.push({id:'offline',object:'chat.completion.chunk',created:0,model:'glm-5.3',choices:[],usage:{prompt_tokens:10,completion_tokens:8,total_tokens:18,completion_tokens_details:{reasoning_tokens:test.reasoning?5:0}}})
  const sse=chunks.map(x=>'data: '+JSON.stringify(x)+'\n\n').join('')+'data: [DONE]\n\n'
  let calls=0
  const sdk=createOpenAICompatible({name:model.providerID,baseURL:'https://offline.invalid/v4',fetch:async()=>{
    calls++
    // Do not inspect arguments, including headers. Never call a network transport.
    const bytes=new TextEncoder().encode(sse)
    const body=test.byteFragments?new ReadableStream({start(controller){for(let i=0;i<bytes.length;i+=7)controller.enqueue(bytes.slice(i,i+7));controller.close()}}):sse
    return new Response(body,{headers:{'content-type':'text/event-stream'}})
  }})
  const response=streamText({model:wrapLanguageModel({model:sdk.chatModel(model.id),middleware:{specificationVersion:'v3',transformParams:async(args)=>({...args.params,prompt:message(args.params.prompt,model as never,prepared.messageTransformOptions)})}}),messages:prepared.messages,providerOptions:providerOptions(model as never,prepared.params.options),maxOutputTokens:prepared.params.maxOutputTokens,maxRetries:0})
  const state=adapterState()
  const events=[]
  const sdkTypes=[]
  for await(const event of response.fullStream){sdkTypes.push(event.type);events.push(...await Effect.runPromise(toLLMEvents(state,event)))}
  const expected=test.pieces.join('')
  const text=events.filter(x=>x.type==='text-delta').map(x=>x.text).join('')
  const end=events.filter(x=>x.type==='text-end').length
  const finish=events.findLast(x=>x.type==='finish')
  assert.equal(calls,1)
  assert.equal(await response.text,expected)
  assert.equal(text,expected)
  assert.equal(finish?.reason,test.finish)
  assert.equal(end,expected?1:0)
  assert.equal(events.some(x=>x.type==='error'),false)
  results.push({name:test.name,calls,expectedText:expected,aiSdkText:await response.text,opencodeAdapterText:text,textEndEvents:end,finish,aiSdkEventTypes:sdkTypes,opencodeEventTypes:events.map(x=>x.type),reasoningDeltaEvents:events.filter(x=>x.type==='reasoning-delta').length})
}
await Bun.write(new URL('./finish-length-stream-results.json',import.meta.url),JSON.stringify({network:'none; synthetic SSE mock fetch; no headers inspected; no actual reasoning used',localSdk:'@ai-sdk/openai-compatible@2.0.41 + upstream patch',coverage:'actual request preparation, provider transform, AI SDK streamText, OpenCode ai-sdk event adapter; not SessionProcessor persistence or compiled remote CLI',remoteEmbeddedSdkVersion:'unknown',results},null,2)+'\n')
console.log('PASS: 7 synthetic SSE cases; content survives length including fragmented UTF-8; reasoning-only remains empty; text-end emitted when content exists')
