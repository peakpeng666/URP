# 智谱参数映射诊断：条件性序列化缺陷已复现，真实失败根因未定位
日期：2026-10-05。范围：OpenCode v1.18.34 commit aec0b9a6d8898f68f923aaf08b7306d931fd9d76；本地cli_closure安装 @ai-sdk/openai-compatible 2.0.41；远端已编译CLI嵌入的SDK版本尚未独立核实；离线请求序列化。未调用真实模型、未读取真实认证、未检查或保存请求头、未保存模型推理内容。

## 重要更正：真实配置已经是camelCase，不能归因此次失败
已直接读取导出的非秘密配置诊断glm_generation_transfer/safe_diagnostic/preflight-options-diagnostic.json，文件SHA-256经本地核验为180c26546ba0e7fc2d141da79afaa3c54bc26cd8073897b721d9faf579dec2c6。其original_configuration_sha256为ed5102f21196c32a8aebc019c8a757f65301aef3bfa5104543605f520fc41bda；model_options为reasoningEffort:low、agent_options_present:false、agent_options为空；provider是zhipuai-coding-plan、model是glm-5.3。预检新增CLI/模型请求均0，未改配置，既往失败根因not_determined。

已将以上安全导出值逐项与existing reported_actual_model_camel_agent_empty fixture比较并断言通过（SAFE_EXPORT_CHECK.json）。真实OpenCode准备/合并/命名空间→本地AI SDK→mock fetch测试中，该结构生成reasoning_effort:low。比较仅覆盖provider/model与model/agent options，并非完整真实请求重放：fixture completion cap2048，而导出中的校准cap16384，模型context也有差别；真实temperature0.7、top_p0.9、steps2未被该fixture完整模拟。

版本边界必须保留：安全导出只确认远端native包opencode-linux-x64-baseline版本1.18.34；@ai-sdk/openai-compatible的远端嵌入版本为null，因独立package metadata不可检查。本地2.0.41来自固定OpenCode源码依赖，不可冒称已经证实与远端编译CLI内嵌SDK相同。所以上述离线映射既不能替代实际请求证据，也不能单独证明远端发包行为。
因此：snake_case缺陷存在，但不能解释当前真实失败；“实际调用遗漏effort因而落入默认max”的归因假设撤回。当前证据不支持修改这项已正确配置，也不支持宣称修复/真实改善。2048与16384终稿为空的根因仍需调查，候选包括供应商实际模型/effort语义、completion预算分配、流解析/终稿展示、实际配置覆盖等，均尚未证实。应先核对有限安全元数据、model/provider/runtime、最终非敏感effort/max_tokens字段与stream finish/text计数，不能盲目再加预算或改名重跑。

## 已证实的条件性映射结论（与本次真实失败分开）
当且仅当模型/agent合并后的options只设置reasoning_effort:low而没有reasoningEffort时，SDK先展开自定义snake_case字段，再被compatibleOptions.reasoningEffort（undefined）覆盖，JSON序列化丢掉字段。此条件下把配置改为reasoningEffort:low可修正发包；本次实际配置不满足该前提，因此不需要该修改。

已通过离线8个SDK case及3个真实OpenCode准备流水线case。测试证明字段映射，不证明真实模型完成率、速度、质量或token改善。官方GLM-5.3接受enabled+low/high/max，缺省max，不接受disabled。low不是严格推理token数量上限，也不能据离线测试保证2048或16384内必出终稿。选择variant时，其选项优先级高于agent/model，需在实案另核；本次fixture无variant。

## 精确来源
1. [官方SDK固定commit源码](https://github.com/vercel/ai/blob/99327b1d7b3d172ed0aae7230ae153f2d32b0ebb/packages/openai-compatible/src/chat/openai-compatible-chat-language-model.ts#L231-L244)
   - 231–241展开额外自定义字段；243行覆盖 reasoning_effort: compatibleOptions.reasoningEffort
   - 146–163用schema解析provider命名空间；chat-options.ts:15识别的是 reasoningEffort
   - 已核实官方annotated tag @ai-sdk/openai-compatible@2.0.41 → tag object 1d28226094dd98b2664799c8dd212f06606781b4 → commit 99327b1d7b3d172ed0aae7230ae153f2d32b0ebb
   - 官方源码已保存为upstream-sdk-chat.ts，blob SHA 8c622db23c2d9a7373701f5a1b0c2ba109e24602
   - 安装版包含OpenCode官方patch，仅改变442附近流错误处理；与参数序列化无关。实际运行dist/index.mjs:538也有相同覆盖。patch在cli_closure/patches/@ai-sdk%2Fopenai-compatible@2.0.41.patch；SDK许可保存在SDK-LICENSE
2. [OpenCode配置归一化](https://github.com/anomalyco/opencode/blob/aec0b9a6d8898f68f923aaf08b7306d931fd9d76/packages/core/src/v1/config/agent.ts#L62-L80)
   - 顶层未知字段原名搬入options；不把snake_case变camelCase
   - opencode/src/agent/agent.ts:292合并value.options
3. [真实请求准备](https://github.com/anomalyco/opencode/blob/aec0b9a6d8898f68f923aaf08b7306d931fd9d76/packages/opencode/src/session/llm/request.ts#L80-L132)
   - 91行合并顺序base→model.options→agent.options→variant；129给maxOutputTokens
   - [ProviderTransform](https://github.com/anomalyco/opencode/blob/aec0b9a6d8898f68f923aaf08b7306d931fd9d76/packages/opencode/src/provider/transform.ts#L1265-L1273) 自动设thinking.enabled、clear_thinking:false
   - 同文件1421–1482为providerOptions，openai-compatible采用providerID命名空间；本例是zhipuai-coding-plan，字段名保持原样
   - session/llm.ts:316把映射后的options给AI SDK；330–337执行最终message transform
4. [智谱官方GLM-5.3说明](https://docs.bigmodel.cn/cn/guide/models/text/glm-5.3)
   - 功能变更：始终开启思考，只接受low/high/max，缺省max；不再支持disabled
   - 示例用wire格式reasoning_effort，不能据此推断OpenCode配置同名
   - [Z.ai同模型官方说明](https://docs.z.ai/guides/llm/glm-5.3)给出一致参数约束
   - 两站说明有Coding Plan历史的用户当前只能使用OpenAI Chat Completion协议；不要把切换Responses/Anthropic当作已验证修复
以上网页于本次核查读取，模型控制以供应商最新官方文档为准。

## 已执行测试与证据
- sdk-wire-test.mjs → sdk-wire-results.json：8/8通过。generate/stream各测snake-only、camel-only、两者冲突、camel max。snake丢失；camel low保留；冲突camel high覆盖snake low；max可序列化
- opencode-pipeline-test.ts → opencode-pipeline-results.json：3/3通过。使用真实ConfigAgentV1.Info解码、真实LLMRequestPrep.prepare（假插件无变更、auth undefined）、真实ProviderTransform.providerOptions、真实AI SDK streamText/wrapLanguageModel/message transform、安装provider SDK和注入mock fetch
- snake-only body没有reasoning_effort；agent camel-only及真实配置结构等价model camel-only body均有reasoning_effort:"low"。三者max_tokens2048、thinking enabled/clear_thinking false一致。第三个case证明本次已知配置字段位置能够正确穿透，并非对安全云实际发包的抓取
- 测试prompt全部是Offline fixture，不包含用户研究资料。mock fetch不调用网络、不查看headers
- isolated/仅为模块初始化必须的XDG隔离目录和缓存；未改现有用户配置。首次测试因默认XDG目录只读失败；隔离后首次fixture协议格式不匹配，改用生产同款AI SDK streamText后通过
- PROVENANCE.json记录读取到的源码/dist/patch哈希与固定source相等性；所有核对的OpenCode源码均与固定source一致。测试未执行整套CLI/UI、未验证真实服务端

## Native分支：精确边界
[native-runtime.ts:54–60](https://github.com/anomalyco/opencode/blob/aec0b9a6d8898f68f923aaf08b7306d931fd9d76/packages/opencode/src/session/llm/native-runtime.ts#L54-L60) 只准openai、anthropic或以opencode开头的provider。zhipuai-coding-plan在认证检查之前返回unsupported，llm.ts:224–269回退AI SDK。因此native并非此次字段丢失的执行路径。

native-mapping-test.ts → native-mapping-results.json已验证gate拒绝；另运行4个纯函数反事实lowering+1个max拒绝断言，不执行网络：
- native-request.ts:171–176选择OpenAICompatible；192原样传providerOptions
- llm/src/protocols/openai-compatible-chat.ts:17–21复用OpenAIChat.protocol
- protocols/utils/openai-options.ts:46、53–55只读providerOptions.openai.reasoningEffort；不读取zhipuai-coding-plan命名空间，亦不读snake_case
- openai-chat.ts:333–340将该camel值降成reasoning_effort；有效集排除max（utils/openai-options.ts:5–7）
- native协议fromRequest:344–370不输出thinking扩展
- 反事实测试：智谱命名空间snake/camel都无effort；openai命名空间snake无effort、camel low有effort；openai camel max报错；thinking均不输出
这是未来native支持智谱时须修复的兼容边界，不能把简单开放gate视为完成适配；当前AI SDK路线若已是camelCase则无需此修复；native路线不能用于当前智谱运行。

## 中期报告可用的改进记录
分类：工程集成诊断与回归测试，非科研创新。
问题证据：预算耗尽空终稿（父任务实测）与参数映射差异（本目录离线复现）分开记录。
依据：上述固定源码与智谱官方文档。
现状：安全导出确认选项是camelCase，第三个fixture确认在本地固定SDK可穿透；无需参数改名。条件性snake缺陷作为回归保护而非本次修复。
完成状态：离线映射验证通过；真实失败归因未解决；不声称完成率/质量提升。
更正记录：早期依据任务描述提出snake缺陷可能解释空输出；后真实配置核查排除此解释，撤回归因，校准在0调用预检终止。保留负面结果与更正是可追溯研究记录的一部分。
下一步：只做原任务允许的安全元数据与解析证据核查，任何真实模型调用由父任务另行决定；不默认新增校准。

## 复现
从工作区根运行node research_workbench/provider_diagnosis/sdk-wire-test.mjs。
其余两项从cli_closure/packages/opencode目录使用已安装build_baseline/toolchain/package/bin/bun，设置XDG_DATA_HOME、XDG_CONFIG_HOME、XDG_CACHE_HOME、XDG_STATE_HOME到provider_diagnosis/isolated相应子目录，再运行../../../provider_diagnosis/opencode-pipeline-test.ts及native-mapping-test.ts。不需要密钥，不需要网络，也不需要安装新依赖。
