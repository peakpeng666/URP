# 固定发表 EoH DAG：已暴露小样本上的管线正对照

结论：10/10 装箱输出可行，但没有优于主比较对象 BF。开发总箱数 555 vs BF 546（多 9 箱，+1.6484%）；已暴露验证总箱数 547 vs BF 542（多 5 箱，+0.9225%）。这是一条可追溯的负面质量结果，不能包装成 GLM 成功、算法创新或未见数据确认。

## 固定方法与结果

|数据|实例|EoH|BF|FF|EoH−BF|
|---|---:|---:|---:|---:|---:|
|development|0|112|112|113|+0|
|development|1|114|110|110|+4|
|development|2|106|105|105|+1|
|development|3|113|110|111|+3|
|development|4|110|109|110|+1|
|validation|0|108|109|111|-1|
|validation|1|109|110|109|-1|
|validation|2|105|103|104|+2|
|validation|3|112|108|109|+4|
|validation|4|113|112|112|+1|

开发 EoH 对 BF：0 胜、1 平、4 负；验证：2 胜、0 平、3 负。开发对 FF 多 6 箱；验证对 FF 多 2 箱。保留全部十条实例，没有按结果排除或换公式。

质量定义为每条 L1/箱数再平均（越大越好）；L1 是体积下界，不能当最优值或最优性证明：
- development: EoH 0.931716353；BF 0.946917868；FF 0.941821454；精确分数见 report.json
- validation: EoH 0.938068512；BF 0.946596748；FF 0.941330577；精确分数见 report.json

## 数据、出处和执行合同

- 每个 split 固定 5 条 × 256 物品，容量 100；使用原文件完整顺序，不重新抽样或排序
- development：historical_design_5k 第 0–4 条各前 256 项，直接对应已冻结 design_prefixes.json；来源文件未记录这些历史实现的随机 seed，本轮不捏造 seed，精确物化字节及哈希才是复现输入
- validation：seed 2026100505300、2026100505301、2026100505302、2026100505303、2026100505304；各自 random.Random(seed)，256 次 weibullvariate(45.0,3.0)，Python ties-to-even round，再限制到 [1,100]。本轮直接读取保存数据，不重新生成；这些数据在此前 GLM 试验已暴露
- 固定出处：[FeiLiu36/EoH，commit 472545785c936dcfc863d2bc0d6109cf23c7ce62](https://github.com/FeiLiu36/EoH/blob/472545785c936dcfc863d2bc0d6109cf23c7ce62/examples/bp_online/evaluation/heuristic_original_EoH_paper.py)，文件 examples/bp_online/evaluation/heuristic_original_EoH_paper.py，原文 SHA256 f3d50f0e81ca061a0377b9fb61b75cf16ecde9f091876db0d8baca8323655995
- 使用既有15节点 published_eoh.json 数学 DAG 和可信 math_dag_v1 解释器；不执行作者原始 Python，也不执行生成任意 Python。先前的600向量/200400分数等价性证据仅作数值来源门槛，不当作本轮装箱质量结果
- 每个实例预分配256个空箱，全部可行箱（含未使用空箱）参与打分，first argmax 处理平局；按到达顺序不可撤销分配。checker 独立从原始物品和分配复算负载，checker 单独不证明在线性；在线性来自固定可信 pack/evaluate 的信息接口

## 独立验收与计数

- 新增实际装箱评分：10；确定性策略重放：0；外部模型调用：0
- 复核20份旧 FF/BF 原始请求、stdout哈希、分配和残余容量，不计为新评分或新样本
- 第二次独立保存证据审计使用简单整数负载复算，30/30通过；没有调用策略或解释器；0条自然失败、0条数值警告
- 新EoH实际评分元素总数：527120；这是10个装箱运行中的所有可行箱打分数，不等于独立实例数
- 原121项依赖、源码、数据、历史结果在执行前后SHA256一致。原 GLM 协议、runner、主比较对象 BF、原结果及固定数值门槛均未改写

## 时间和限额

- 冻结时间 2026-10-05T05:21:30.096998+00:00；本轮所有评分均在冻结之后。准备始于 2026-10-05 05:18:53 UTC；准备期间无评分，准备CPU未单独计量，不混称完整任务CPU
- 含1秒保守启动计费的执行+终审记录：CPU 2.935758s；active wall 2.922558s
- 10个数值子进程：CPU合计 1.146193s；wall合计 1.159197s；峰值RSS最大 41872 KiB（含解释器）
- 另行保存证据审计：CPU 0.059445s，wall 0.060767s；与前述执行合计仍远低于120 CPU秒/180 active wall秒
- 数值进程保持20 CPU秒、30 wall秒、2GiB、5000000工作量上限，顺序启动；下一个启动预留22 CPU秒/32 wall秒，终止保存预留15秒，主启动器40 CPU秒、外层180秒watchdog。使用逐进程rlimit及聚合已观测计费，不能称cgroup级硬进程树保证

## 解释边界与下一步

这项正对照验证的是“固定发表数学策略能沿既有管线完成评分与独立验收”。“正对照”不表示它必须赢 BF。原发表策略在这批256项前缀/小样本中较差，不足以否定完整论文结果，也不支持总体优劣结论。未进行完整 EoH 进化复现、显著性检验、模型排序、最优性求证或新方法测试。

下一步应把这条负面结果纳入老师P3证据链，保持现有BF主基线；任何后续改策略/调参都作为新的开发实验登记，不能回填本轮或把已暴露验证重新称盲测。

## 复核入口

- protocol.json：评分前独立预冻结合同
- freeze.json：121项前置哈希；results/hashes_after.json：后置哈希
- results/report.json：完整十条评分、精确质量、逐实例差异
- results/*observation.json：原始有界子进程输出及stdout原字节base64
- results/baseline_rechecks.json：旧基线独立验收
- results/independent_audit.json：第二次整数负载审计
- results/completion_accounting.json、preparation_accounting.json：分别记执行和准备

本目录拒绝覆盖已有结果；如需重复必须另建独立目录并冻结，重放不得计为新增独立样本。
