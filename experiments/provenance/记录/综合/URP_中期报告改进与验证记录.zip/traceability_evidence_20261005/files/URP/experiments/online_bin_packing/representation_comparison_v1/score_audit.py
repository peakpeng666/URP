"""Independent saved-evidence integer audit; never execute candidate policy."""
import time
START=time.monotonic();CPU=time.process_time()
import argparse,base64,hashlib,json,pathlib,resource,sys
from fractions import Fraction
from scoring_admission import json_load,sha,save,verify_freeze
ROOT=pathlib.Path(__file__).resolve().parent;BASE=ROOT.parent;EVALUATOR=BASE/'paper_scale_dag_evaluator_v1'

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',required=True);a=ap.parse_args();out=pathlib.Path(a.output).resolve();results=out/'scores'
 resource.setrlimit(resource.RLIMIT_AS,(2147483648,2147483648));resource.setrlimit(resource.RLIMIT_CPU,(25,25))
 report=json_load(results/'report.json',100000000);errors=[];checked=[];baseline_rows=[]
 try:
  f=verify_freeze(report['freeze_sha256']);seal=json_load(out/'preparation_seal.json');assert sha(out/'preparation_seal.json')==report['preparation_sha256']
  after=json_load(results/'hashes_after.json',10000000);assert all(sha(pathlib.Path(p))==h for p,h in after.items())
  assert all(after[p]==h for p,h in f['sha256'].items());assert all(after[p]==h for p,h in seal['source_sha256'].items());assert all(after[p]==h for p,h in seal['prepared_file_sha256'].items())
  admissions=json_load(out/'preparation/admissions.json');by={x['id']:x for x in admissions};rows=report['scores']
  assert len(rows)==240 and [(r['panel'],r['instance'],r['slot']) for r in rows]==[(p,i,s) for p in ['main5000','development256','validation256'] for i in range(5) for s in range(1,17)]
  assert report['runtime_requests']==sum(r.get('runtime_request_attempted',False) for r in rows)
  data={'main5000':[x['items'] for x in json_load(EVALUATOR/'data/design_5000.json')['cases']],'development256':[x['items'] for x in json_load(EVALUATOR/'data/regression_development_256.json')['cases']],'validation256':[x['items'] for x in json_load(EVALUATOR/'data/regression_validation_256.json')['cases']]}
  def integer_check(row,obs,items):
   b=obs['result'];result=b['result'];assign=result['assignment'];n=len(items);raw=base64.b64decode(obs['raw_stdout_base64'],validate=True)
   assert json.loads(raw)==b and hashlib.sha256(raw).hexdigest()==obs['raw_output_sha256'] and len(raw)==obs['raw_output_bytes']
   assert len(assign)==len(result['residuals'])==n and all(type(x)is int and 0<=x<n for x in assign)
   loads=[0]*n
   for item,label in zip(items,assign):loads[label]+=item;assert loads[label]<=100
   used=sum(x>0 for x in loads);L1=(sum(items)+99)//100
   assert row['used_bins']==result['used_bins']==used and row['L1']==L1 and row['assignment']==assign and row['residuals']==result['residuals']==[100-x for x in loads]
   assert b['status']=='packing_returned' and b['warnings']['complete'] is True
   return {'panel':row['panel'],'instance':row['instance'],'id':row.get('id',row.get('method')),'used_bins':used,'L1':L1,'passed':True}
  for row in rows:
   admission=by[row['id']];admitted=admission['unique_block']['status']=='admitted'
   if not admitted:assert row['status']=='not_run' and row['reason']=='candidate_not_admitted'
   if row['status']=='not_run':assert not row.get('runtime_request_attempted',False);continue
   if row.get('observation_file'):
    obs=json_load(row['observation_file']);request=json_load(results/f"{row['panel']}_{row['instance']}_{row['id']}.request.json");payload=(out/'preparation'/row['id']/'payload.json').read_bytes()
    assert request=={'mode':'pack','program_json':payload.decode(),'items':data[row['panel']][row['instance']],'capacity':100}
    assert sha(out/'preparation'/row['id']/'payload.json')==admission['payload_sha256']
   else:
    assert row['status']=='infrastructure_failure';continue
   if row['status']=='feasible':
    item=integer_check(row,obs,data[row['panel']][row['instance']]);k=len(json.loads(payload)['nodes']);n=len(data[row['panel']][row['instance']]);assert row['work_units']==n*n+k*sum(obs['result']['result']['feasible_counts'])<=n*n*65;checked.append(item)
   else:assert row['status'] in ['numeric_invalid','resource_unresolved','diagnostic_unresolved','checker_rejected','infrastructure_failure'] and 'used_bins' not in row
  baselines=json_load(results/'baseline_rechecks.json',10000000)
  assert len(baselines)==30
  for row in baselines:
   assert sha(row['source'])==row['source_sha256'];baseline_rows.append(integer_check(row,json_load(row['source']),data[row['panel']][row['instance']]))
  for g in report.get('summary',{}).get('groups',[]):
   matched=[x for x in checked if x['id']==g['id'] and x['panel']==g['panel']];assert g['feasible']==len(matched)
   if len(matched)!=5:assert 'sum_bins' not in g;continue
   total=sum(x['used_bins'] for x in matched);lb=sum(x['L1'] for x in matched);assert total==g['sum_bins'] and lb==g['sum_L1'] and g['paper_percent_excess_exact']==str(Fraction(100*(total-lb),lb))
   for method in ['BF','EOH']:
    refs=[x for x in baseline_rows if x['id']==method and x['panel']==g['panel']];assert g[method]['sum_bins']==sum(x['used_bins'] for x in refs) and g[method]['delta_sum_bins']==total-g[method]['sum_bins']
  # Review classifications are all retained; they never remove admissible rows.
  assert len(report['summary']['description_reviews'])==16
 except Exception as e:errors.append(type(e).__name__+': '+str(e))
 accounting={'cpu_seconds':1+time.process_time(),'active_wall_seconds':1+time.monotonic()-START,'startup_allowance_seconds':1}
 result={'passed':not errors,'errors':errors,'candidate_saved_assignments_checked':len(checked),'baseline_saved_assignments_checked':len(baseline_rows),'policy_dispatches':0,'model_calls':0,'checks':checked,'baseline_checks':baseline_rows,'budget':accounting,'source_sha256':sha(pathlib.Path(__file__))}
 save(results/'independent_audit.json',result);print(json.dumps({k:v for k,v in result.items() if k not in ['checks','baseline_checks']},indent=2));return 0 if not errors else 1
if __name__=='__main__':raise SystemExit(main())
