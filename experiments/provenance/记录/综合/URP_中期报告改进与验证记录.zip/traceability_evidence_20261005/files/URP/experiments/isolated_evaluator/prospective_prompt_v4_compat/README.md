# Prospective prompt v4: separately versioned safe-loader compatibility preparation

This sibling starts from exactly the 27 core payload files in original preparation
`0ecf0ade247065f7ed38a948082383d093d485bfb1e621add32dfb8096dbf0ab`.
`original_preservation_inventory.json` records all original file hashes, including
the sole failed attempt. That attempt began zero generation calls and left all ten
slots unstarted. It is not retried or rewritten by this preparation.

The only functional changes are safe-loader compatibility, its unit tests, and a
separate model-load-only diagnostic. Prompts, paired seeds/order, generation settings,
fixture panels, selected extraction, evaluation code and all Wasm limits are unchanged.
The original proposal describes those unchanged prospective semantics; this README
records the compatibility delta. Preparation does not grant generation/evaluation authority.

## Safe load

All pinned official model and virtualenv hashes are verified before any library import.
A fresh process imports the fixed CodeGen implementation, tokenizer/auto modules and
known official Torch registry-producing dependencies. Module names/origins and actual
registered globals are logged. One supported `clear_safe_globals()` call then removes
that process-local added registry. It does not add or accept any unpickler permission.
`safe_globals([])` is deliberately not used as a substitute.

Each actual `torch.load` is wrapped. It must use the exact pinned checkpoint pathname
and hash, explicitly `weights_only=True`, no custom pickle module, and only meta/CPU
mapping. The wrapper scans with an empty added registry, rejects unsupported globals,
rechecks immediately before/after deserialization, records each real load and restores
`torch.load` on exit. The registry must still be empty after model setup. Any late
repopulation fails closed without clearing or retrying. CPU float32, one intra/inter-op
thread, eager attention, deterministic algorithms, local-only and no remote code remain
mandatory. Multiple official meta/CPU loads are logged rather than assuming one load.

## Review and load-only check

Light tests use handwritten mock objects only:

`python -B -m unittest discover -s tests -p 'test_*.py' -v`

After source review and an explicit parent go-ahead, the separate load-only supervisor is:

`python -B src/supervise_model_load_only.py --reviewed-preparation-sha256 DIGEST --output results/model_load_only_1`

This starts the already-pinned interpreter with `-B -s`, a clean offline environment,
6 GiB address space, 120s CPU, 180s whole wall, at most 5s cleanup and 2s report publication.
The worker verifies preparation/model/venv hashes before and after loading and checks
all original artifacts unchanged. A load-only generation tripwire rejects any generate
attempt. No generation function, candidates, approvals or authorization-use markers
are invoked or created. The output directory must be new; there is no automatic retry.

A successful load-only check does not authorize generation. A new preparation freeze,
independent review and parent authorization bound to that new freeze are required
before any fresh generation attempt. Existing generation authorization cannot be used.
