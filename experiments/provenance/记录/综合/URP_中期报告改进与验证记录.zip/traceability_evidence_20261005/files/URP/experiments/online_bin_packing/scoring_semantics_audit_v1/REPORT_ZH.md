# candidate_01 评分语义独立审计

## 结论，按证据强弱区分

1. **已核实的数学不一致**：原始终端响应的 description 说“negative squared slack”，同一响应的四个节点实际计算 `(b-item)^2 - 0.01*b`。正平方在送入我们解释器前就已存在。严格说这是“文字与程序不一致”，无法观察模型内部意图，因此不能把“模型本来想实现负平方但漏掉符号”当作已证实心理原因。
2. **此次未发现的管线问题**：原字节、fence 去壳、保存 JSON、常数解析、全局节点引用、解释器、可行集合、argmax 映射及保存结果，均与独立手写标量参考一致。不能把有限审计表述为证明整个框架无 bug。
3. **未知根因**：为什么这次生成出现不一致、是否提示压缩/采样参数/模型能力/偶然性造成，本审计不能识别。一次样本不能支持模型排名或提示因果判断。

## 原字节到数学含义

原文件：`glm_generation_transfer/concise_generation_verified/runs/candidate_01/response.txt`

- 原始 SHA256：`db142fdf1525d26033836ae3fdd3cf5fc29224485ac882b1328edfa29710f7c7`
- 独立按观察到的开闭 fence 精确切片，再与既有 extractor 对照，正文未修改
- 正文与 `glm53_concise_generation_v1/results/candidate_01.program.json` 逐字节相同
- 正文 SHA256：`51388d17771429aff327faf15dfb8d9c67a0f7738133f59a82c6afbc75edb876`
- bundle 所有7个列举文件的长度/哈希与索引相符；metadata 的 response hash 相符。这仅核实本地捕获证据，不把终端文本冒称原始 HTTP 载荷
- c0 是 f64 的 0.01；不是把数字索引0读成常数
- node0 = bins-item；node1 = node0*node0；node2 = c0*bins；node3 = node1-node2；返回 node3
- item 是 np.int32；bins 是 np.int64 剩余容量向量；节点 dtype 顺序 int64、int64、float64、float64
- 解释器 `resolve` 将整数引用解析为全局 `values[arg]`，不存在子树局部索引转换
- description 不参与数值执行

## 为什么一定偏向空箱

对固定整数 item=i、可行整数剩余容量 b≥i，S(b)=(b-i)^2-0.01b。

相邻整数容量差：S(b+1)-S(b)=2(b-i)+0.99≥0.99>0。

因此本合法整数域中，容量越大分数严格越大；0.01 不是足以抵消正平方的修正，也不会让不同容量出现精确相等。所有未用箱剩余100且相互同分，first argmax 选择其中原索引最小者。正物品使已用箱容量小于100，所以只要还有未用箱，每个到达物品都会开一个新箱。这里预分配箱数等于物品数，得到256箱不是这10个随机序列的偶然现象。

透明例子 item=20，bins=[20,30,100]：
- node0=[0,10,80]
- node1=[0,100,6400]
- node2=[0.2,0.3,1.0]
- 最终分数=[-0.2,99.7,6399.0]，选100容量箱

这里 bins 是剩余量而不是载荷，不排序、不删除未开箱；可行原索引按升序保留，用评分位置映射回原索引。重复容量按第一个最大值打破平局。即使把程序文字所述负平方作为一种可构造替代，也不能据此静默修复原候选或把替代结果当成原生成结果。本次没有修复、选优或新模型调用。

## 数值独立性与精确新执行记录

新脚本 `audit.py` 的 reference_score/reference_pack 是人工写定的 Python 标量算术和首次最大值循环，不解析节点、不执行生成Python、不使用 eval，不调用原解释器作为参考。原解释器只作为被测对象。

本次一次执行（与历史运行分开）：
- 4个透明向量用例，包括乱序容量、重复最大值、完全贴合、容量500
- 100次完整合法容量向量评估，覆盖45,050个 item∈[1,100], b∈[item,500] 组合，参考和解释器 score IEEE-754 字节相同，并逐项严格递增
- 小域容量6、物品1..6、长度1..4的全部1,554个有序序列，独立参考与原 pack 的 assignment/residuals/used_bins/feasible_counts/placements 均相同
- 10个保存数据实例，重新执行原 pack 各一次；再逐步比较2,560个完整评分向量，共601,980个评分，参考与解释器逐位相同
- 与原保存 request、stdout 原字节/哈希、observation 解析对象、checked assignment/bin count 全部一致
- 另用逐箱累计载荷的独立检查核对可行性、箱数和剩余量
- 每个实例均256箱，assignment=[0,1,...,255]
- 约1.5394 CPU秒、1.5437墙钟秒；峰值RSS 25,660 KiB；限制60 CPU秒、120墙钟秒、2GiB地址空间
- 0个模型请求，0个远端调用；被检查源与数据的哈希均前后不变

完整每一步的可行原索引、剩余容量、参考评分、解释器评分、选择结果保留在 `full_score_vectors.jsonl.gz`，不是只保存最终箱数或 argmax。

溢出排除：扩大解释器合法域最大差499，平方249001，小于整数中间量界1000000，更远小于 int64 上界；这10个容量100实例最大平方9801。float64 0.01不是精确十进制，但本次完整向量逐位对照、合法容量穷举以及至少0.99的数学间隔排除了此处由浮点精度翻转排序的假设。

## 与原EoH约定核对

此处仅引用本地已保存、哈希绑定的作者源码，没有联网/运行作者Python。论文为 Liu 等 ICML 2024 “Evolution of Heuristics: Towards Efficient Automatic Algorithm Design Using Large Language Model”：https://proceedings.mlr.press/v235/liu24bs.html 。算法调用和空箱处理的具体证据来自源码，不能只凭论文标题推断。

历史固定版本：
https://github.com/FeiLiu36/EoH/blob/e4b5ddba03b2b88025747e11c6049f8b529a4368/examples/bp_online/evaluation/evaluation.py#L10-L31
- L12：对 bins-item≥0 取可行原索引
- L24：alg.score(item,bins[valid_bin_indices])
- L27：valid_bin_indices[np.argmax(priorities)]
- L28：bins[best_bin]-=item
- L46-L60：items 数组、预分配 num_items 个容量箱、按剩余量不等于容量统计已用箱
- L61-L63：负平均箱数是整个启发式的外层 fitness，不是把每个箱子优先级取 argmin

当前固定版本的 evaluator 相同约定：
https://github.com/FeiLiu36/EoH/blob/472545785c936dcfc863d2bc0d6109cf23c7ce62/examples/bp_online/evaluation/evaluation.py#L10-L63

当前训练入口独立可见相同方向：
https://github.com/FeiLiu36/EoH/blob/472545785c936dcfc863d2bc0d6109cf23c7ce62/examples/bp_online/prob.py#L42-L66

历史和当前的 evaluator 的对应 SHA256、Git blob SHA1均在 `upstream_source_check.json` 重新核对；因此“外层目标最小化/负箱数”不能解释或正当化把内层 argmax 当作 argmin。没有发现本研究在空箱、剩余量或最大化方向上偏离该源码。

## 必须收窄的旧表述

原 `glm53_concise_generation_v1/audit.py` 自述“Check stored assignments ... never run policy”；其 `independent_audit.json` 明确 `policy_replay_dispatches=0`。它是独立可行性/计数检查，不能称作独立评分公式重算或端到端算法语义证明。本次新增的手写参考才补上这一缺口。

如果之前将“256箱已经核对”直接升级成“我们已独立排除评分管线问题”，证据越界；如果只说“该保存方案确实用了256个可行箱”，原证据足够。另一方面，程序实际正平方是原文本直接可见的事实，不应因保持谨慎而抹掉。

“数学行为确认”与“生成为何出错”是两个问题；本次解决前者，后者仍未知。
