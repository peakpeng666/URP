"""Trusted scoring orchestration; generated input is mathematical JSON only."""
import time
RUN_START=time.monotonic()
import argparse,hashlib,importlib.util,json,math,os,pathlib,resource,signal,sys,time
from fractions import Fraction
sys.dont_write_bytecode=True
ROOT=pathlib.Path(__file__).resolve().parent;STUDY=ROOT.parent;BASE=STUDY.parent
STUDY_HASH='3202877a5d76cdc147611cc9d4b846774132d1be96281850e567204853fceee3'
METHODS=['FF','BF','candidate_01','candidate_02','candidate_03','candidate_04']
LIMITS={'RLIMIT_AS':[2147483648,2147483648],'RLIMIT_CPU':[20,20],'RLIMIT_FSIZE':[0,0],'RLIMIT_NOFILE':[32,32]}
class Infrastructure(Exception):pass
class Deadline(Exception):pass

def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def load(p,cap=2000000):
 with pathlib.Path(p).open('rb') as f:b=f.read(cap+1)
 if len(b)>cap:raise ValueError('input byte bound')
 def pairs(ps):
  d={}
  for k,v in ps:
   if k in d:raise ValueError('duplicate key')
   d[k]=v
  return d
 def reject(x):raise ValueError('nonfinite JSON')
 return json.loads(b,object_pairs_hook=pairs,parse_constant=reject)
def save(p,d):
 with pathlib.Path(p).open('x') as f:json.dump(d,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
def module(name,p):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m

def verify(expected,full=False):
 if sha(ROOT/'freeze.json')!=expected or sha(STUDY/'freeze.json')!=STUDY_HASH:raise Infrastructure('freeze hash mismatch')
 f=load(ROOT/'freeze.json');sf=load(STUDY/'freeze.json')
 for path,h in f.get('dependencies',{}).items():
  if sha(path)!=h:raise Infrastructure('runner predecessor changed: '+path)
 for rel,h in f['files'].items():
  if sha(ROOT/rel)!=h:raise Infrastructure('runner source changed: '+rel)
 for rel,h in sf['files'].items():
  if sha(STUDY/rel)!=h:raise Infrastructure('study file changed: '+rel)
 for p,h in sf['dependencies'].items():
  if sha(p)!=h:raise Infrastructure('dependency changed: '+p)
 if sys.executable!=sf['python_executable'] or sha(sys.executable)!=sf['python_sha256']:raise Infrastructure('Python mismatch')
 if full:module('frozen_math_integrity',BASE/'math_dag_v1/src/integrity.py').verify(sf['math_evaluator_freeze_sha256'])
 return sf

class Budget:
 def __init__(self,cpu=None,clock=None):
  self.cpu=cpu or self.actual_cpu;self.clock=clock or time.monotonic;self.c0=0. if cpu is None else self.cpu();self.t0=RUN_START if clock is None else self.clock()
 @staticmethod
 def actual_cpu():
  x=resource.getrusage(resource.RUSAGE_CHILDREN);return time.process_time()+x.ru_utime+x.ru_stime
 def totals(self):return {'cpu_seconds':1+self.cpu()-self.c0,'wall_seconds':1+self.clock()-self.t0}
 def reserve(self):
  x=self.totals();return x['cpu_seconds']+22+40<=600 and x['wall_seconds']+32+40<=900

def fresh_ledger():return [{'method':m,'split':s,'instance':i,'status':'not_run','reason':'not_reached'} for s in ['development','validation'] for i in range(5) for m in METHODS]

def schedule(ledger,programs,data,budget,dispatch,check,emit):
 halted=False
 for row in ledger:
  if halted:row['reason']='stopped_infrastructure';continue
  if row['method'] not in programs:row['reason']='candidate_not_admitted';continue
  if not budget.reserve():row['reason']='insufficient_budget';continue
  row.update(status='pre_dispatch',reason=None);emit('score_start',row)
  try:
   obs=dispatch(row,programs[row['method']],data[row['split']][row['instance']]);r=check(row,programs[row['method']],data[row['split']][row['instance']],obs)
   row.update(r);emit('score_terminal',row)
  except Exception as e:
   row.update(status='infrastructure_failure',reason=type(e).__name__+': '+str(e)[:2000]);emit('score_terminal',row);halted=True
 return halted

def admit_inputs(path,expected,out):
 if sha(path)!=expected:raise Infrastructure('generation manifest hash mismatch')
 m=load(path,100000);records=m['records'];slots=load(STUDY/'generation_contract.json')['slots']
 if type(records)is not list or len(records)!=4 or [r.get('id') for r in records]!=[s['id'] for s in slots]:raise Infrastructure('exact four ordered terminal generation slots required')
 if any(r.get('terminal')is not True or r.get('status') not in ['completed','not_run','model_or_cli_failed','generation_failed'] for r in records):raise Infrastructure('unterminated/unknown model slots')
 # Verify all source identities before admitting any program.
 for r,s in zip(records,slots):
  if r.get('model_id')!=s['official_model_id'] or r.get('prompt_sha256')!=s['prompt_sha256'] or r.get('cli_version')!='1.18.34':raise Infrastructure('model/prompt/CLI source binding')
  if r.get('payload_provenance')!='OpenCode JSON part.text' or r.get('physical_http_attempts_observed') is not None:raise Infrastructure('payload/count provenance')
  if r.get('logical_cli_requests') not in [0,1]:raise Infrastructure('CLI request count')
  if r['status']=='completed' and (r.get('logical_cli_requests')!=1 or r.get('cli_exit_code')!=0 or r.get('completed_normally')is not True or r.get('tool_event_seen')is not False or r.get('model_messages')!=1 or r.get('truncated')is not False):raise Infrastructure('successful CLI envelope')
  if r.get('raw_text_path') is not None:
   p=pathlib.Path(r['raw_text_path']);p=p if p.is_absolute() else pathlib.Path(path).parent/p
   if not p.is_file() or p.stat().st_size>1048576 or sha(p)!=r.get('raw_text_sha256'):raise Infrastructure('raw text source hash/size')
  elif r['status']=='completed':raise Infrastructure('completed slot has no raw text')
 extract=module('frozen_extract',STUDY/'verify_preparation.py').extract_payload
 sys.path.insert(0,str(BASE/'math_dag_v1/src'));from schema import validate_program
 programs={};rows=[]
 for r in records:
  row=dict(r)
  if r['status']!='completed':row['admission']='not_admitted';rows.append(row);continue
  p=pathlib.Path(r['raw_text_path']);p=p if p.is_absolute() else pathlib.Path(path).parent/p;raw=p.read_bytes()
  (out/(r['id']+'.raw.txt')).write_bytes(raw)
  try:
   body,kind=extract(raw);prog=validate_program(body);programs[r['id']]=body;(out/(r['id']+'.program.json')).write_bytes(body)
   row.update(admission='admitted',extraction=kind,program_sha256=prog.raw_sha256,canonical_program_sha256=prog.canonical_sha256,nodes=len(prog.nodes),constants=len(prog.constants))
  except (ValueError,RecursionError,UnicodeError) as e:row.update(admission='structural_rejected',reason=str(e)[:1000])
  rows.append(row)
 return programs,rows

def checked(raw,items,obs):
 from schema import validate_program
 p=validate_program(raw)
 if obs.get('returncode')!=0 or obs.get('termination')is not None or obs.get('error')is not None or obs.get('reaped')is not True or obs.get('cpu_evidence_complete')is not True:raise Infrastructure('worker transport/cleanup')
 b=obs.get('result',{})
 if b.get('pid')!=obs.get('pid') or b.get('limits')!=LIMITS or b.get('program_sha256')!=p.raw_sha256 or b.get('canonical_program_sha256')!=p.canonical_sha256 or b.get('phase')!='pack':raise Infrastructure('worker source/identity/phase')
 if type(b.get('work_units'))is not int or not 0<=b['work_units']<=5000000:raise Infrastructure('work accounting')
 w=b.get('warnings',{})
 if set(w)!={'events','kinds','complete','incomplete_reason'} or type(w['events'])is not list or type(w['kinds'])is not list or len(w['events'])>12000 or len(w['kinds'])>32:raise Infrastructure('warning envelope')
 for e in w['events']:
  if type(e)is not list or len(e)!=3 or any(type(x)is not int for x in e) or not 0<=e[0]<256 or not 0<=e[1]<len(p.nodes) or not 0<=e[2]<len(w['kinds']):raise Infrastructure('warning event')
 for k in w['kinds']:
  if k.get('category')!='RuntimeWarning' or k.get('file')!='interpreter.py' or type(k.get('message'))is not str or len(k['message'].encode())>1024:raise Infrastructure('warning kind')
 st=b.get('status')
 if st in ['numeric_invalid','resource_unresolved','diagnostic_unresolved']:
  if b.get('result')is not None or type(b.get('error'))is not dict:raise Infrastructure('failure envelope')
  return {'status':st,'reason':b['error'],'work_units':b['work_units']}
 if st!='packing_returned' or b.get('error')is not None or w['complete']is not True or w['incomplete_reason']is not None:raise Infrastructure('packing status/warnings')
 r=b['result'];checker=module('independent_checker',BASE/'paper_baseline_v1/src/checker.py')
 try:c=checker.check_assignment(items,100,r['assignment'],r['used_bins'],r['residuals'])
 except ValueError as e:return {'status':'checker_rejected','reason':str(e)}
 if r.get('placements')!=256 or r.get('work_units')!=b['work_units']:raise Infrastructure('placements/work mismatch')
 return {'status':'feasible','reason':None,'used_bins':c['used_bins'],'L1':c['L1'],'assignment':r['assignment'],'work_units':b['work_units']}

def summarize(ledger):
 groups=[];by={}
 for m in METHODS:
  for s in ['development','validation']:
   rows=[r for r in ledger if r['method']==m and r['split']==s];valid=[r for r in rows if r['status']=='feasible'];g={'method':m,'split':s,'feasible_count':len(valid),'denominator':5}
   if len(valid)==5:g.update(bins=[r['used_bins'] for r in valid],sum_bins=sum(r['used_bins'] for r in valid),exact_mean_L1_over_bins=str(sum((Fraction(r['L1'],r['used_bins']) for r in valid),Fraction())/5))
   groups.append(g);by[m,s]=g
 for g in groups:
  for b in ['FF','BF']:
   ref=by[b,g['split']]
   if 'sum_bins' in g and 'sum_bins' in ref:g['delta_'+b]=g['sum_bins']-ref['sum_bins']
 comparisons=[]
 for m in METHODS[2:]:
  for split in ['development','validation']:
   for baseline in ['FF','BF']:
    for i in range(5):
     candidate=next(r for r in ledger if r['method']==m and r['split']==split and r['instance']==i);ref=next(r for r in ledger if r['method']==baseline and r['split']==split and r['instance']==i)
     if candidate['status']==ref['status']=='feasible' and 'assignment' in candidate and 'assignment' in ref:comparisons.append({'method':m,'baseline':baseline,'split':split,'instance':i,'assignment_equal':candidate['assignment']==ref['assignment'],'different_assignments':sum(a!=b for a,b in zip(candidate['assignment'],ref['assignment']))})
 return {'groups':groups,'trajectory_comparisons':comparisons,'candidates':[{'method':m,'promising':all(by[m,s].get('delta_BF',0)<0 for s in ['development','validation']),'primary_validation_delta_BF':by[m,'validation'].get('delta_BF'),'development_delta_BF':by[m,'development'].get('delta_BF')} for m in METHODS[2:]]}

def execute(a):
 out=pathlib.Path(a.output);out.mkdir(parents=True,exist_ok=False);ledger=fresh_ledger();budget=Budget();errors=[];generation=[];dispatches=0
 save(out/'initial_ledger.json',{'generation':[{'id':m,'status':'not_run'} for m in METHODS[2:]],'scores':ledger})
 events=(out/'events.jsonl').open('x')
 def emit(kind,row):events.write(json.dumps({'kind':kind,'value':row},allow_nan=False)+'\n');events.flush();os.fsync(events.fileno())
 def alarm(*_):raise Deadline('active wall reservation reached')
 old=signal.signal(signal.SIGALRM,alarm);signal.setitimer(signal.ITIMER_REAL,max(.001,859-(time.monotonic()-RUN_START)))
 try:
  verify(a.expected_runner_freeze,full=True)
  programs,generation=admit_inputs(a.input_manifest,a.expected_input_sha256,out);save(out/'generation_ledger.json',generation)
  for m in ['FF','BF']:programs[m]=(BASE/f'math_dag_evolution_v1/seeds/{m.lower()}.json').read_bytes()
  data={s:[c['items'] for c in load(STUDY/f'data/{s}.json')['cases']] for s in ['development','validation']}
  from runtime import request
  def dispatch(row,raw,items):
   nonlocal dispatches
   verify(a.expected_runner_freeze);dispatches+=1
   payload={'mode':'pack','program_json':raw.decode('utf-8'),'items':items,'capacity':100};name=f"{row['split']}_{row['instance']}_{row['method']}";save(out/(name+'.request.json'),payload)
   obs=request(payload);save(out/(name+'.observation.json'),obs);return obs
  halted=schedule(ledger,programs,data,budget,dispatch,lambda row,raw,items,obs:checked(raw,items,obs),emit)
  if halted:errors.append('infrastructure_stop')
 except Exception as e:errors.append(type(e).__name__+': '+str(e)[:2000])
 finally:
  signal.setitimer(signal.ITIMER_REAL,0)
  for r in ledger:
   if r['status']=='pre_dispatch':r.update(status='infrastructure_failure',reason='interrupted_dispatch')
   elif r.get('reason')=='not_reached':r['reason']='stopped_infrastructure'
  # No live worker remains on the trusted request return path; final accounting gets40seconds.
  signal.setitimer(signal.ITIMER_REAL,40)
  try:
   verify(a.expected_runner_freeze,full=True);summary=summarize(ledger)
  except Exception as e:errors.append('terminal:'+str(e));summary={}
  totals=budget.totals()
  if totals['cpu_seconds']>600 or totals['wall_seconds']>900:errors.append('budget_exceeded')
  report={'state':'incomplete' if errors or any(r['status']!='feasible' for r in ledger) else 'completed','errors':errors,'generation':generation,'scores':ledger,'summary':summary,'dispatches':dispatches,'budget':totals,'runner_freeze_sha256':a.expected_runner_freeze,'study_freeze_sha256':STUDY_HASH,'input_sha256':a.expected_input_sha256,'budget_amendment_sha256':sha(ROOT/'budget_amendment.json'),'remote_generation_wall':'Excluded; separately reported by source manifest; max4*180s','timing_boundary':'Measured through final integrity and summary; remaining terminal reserve covers serialization.'}
  save(out/'report.json',report);events.close();save(out/'completion_accounting.json',{'measured_after_report':budget.totals(),'startup_allowance_seconds':1,'preparation_excluded':True,'final_small_completion_record_serialization':'covered by remaining40second reserve','within_cap':budget.totals()['cpu_seconds']<=600 and budget.totals()['wall_seconds']<=900});signal.setitimer(signal.ITIMER_REAL,0);signal.signal(signal.SIGALRM,old)
 return report

def main():
 p=argparse.ArgumentParser();p.add_argument('--expected-runner-freeze',required=True);p.add_argument('--input-manifest');p.add_argument('--expected-input-sha256');p.add_argument('--output');p.add_argument('--execute-approved',action='store_true');a=p.parse_args()
 if not a.execute_approved:verify(a.expected_runner_freeze);print('static verified; model_calls=0 score_calls=0');return
 if not all([a.input_manifest,a.expected_input_sha256,a.output]):p.error('manifest hash and fresh output required')
 r=execute(a);print(json.dumps({'state':r['state'],'dispatches':r['dispatches'],'budget':r['budget']}))
if __name__=='__main__':main()
