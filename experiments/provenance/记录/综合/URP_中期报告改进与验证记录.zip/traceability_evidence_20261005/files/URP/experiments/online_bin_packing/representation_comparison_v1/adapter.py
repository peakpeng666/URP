"""Trusted static lowering only. Never execute candidate Python source."""
import ast
import hashlib
import io
import json
import math
from pathlib import Path
import re
import sys
import tokenize

IR_DIR = Path(__file__).resolve().parents[1] / 'math_dag_v1' / 'src'
sys.path.insert(0, str(IR_DIR))
from schema import ARITY, MAX_BYTES, MAX_CONSTANTS, MAX_NODES, StructureError, validate_program

class SurfaceError(ValueError):
    pass

RESERVED = set(ARITY) | {'score', 'item', 'bins', 'np'}
BINARY = {ast.Add: 'add', ast.Sub: 'sub', ast.Mult: 'mul', ast.Div: 'div'}

def lower_python(raw):
    if type(raw) is not bytes or len(raw) > MAX_BYTES:
        raise SurfaceError('source byte limit/type')
    try:
        source = raw.decode('utf-8')
        for token in tokenize.generate_tokens(io.StringIO(source).readline):
            if token.type == tokenize.NAME and not token.string.isascii():
                raise SurfaceError('ASCII identifiers required')
        tree = ast.parse(source, mode='exec')
    except (SyntaxError, ValueError, UnicodeError, RecursionError, tokenize.TokenError, IndentationError) as exc:
        raise SurfaceError('Python syntax/encoding') from exc
    if sum(1 for _ in ast.walk(tree)) > 4096:
        raise SurfaceError('AST node limit')
    numpy_declared = False
    if tree.body and type(tree.body[0]) is ast.Import:
        imports = tree.body[0].names
        if len(imports) != 1 or imports[0].name != 'numpy' or imports[0].asname != 'np':
            raise SurfaceError('only exact import numpy as np allowed')
        numpy_declared = True
        tree.body = tree.body[1:]
    if len(tree.body) != 1 or type(tree.body[0]) is not ast.FunctionDef:
        raise SurfaceError('exactly one function required')
    f = tree.body[0]
    a = f.args
    if (f.name != 'score' or f.decorator_list or f.returns or f.type_comment
            or getattr(f, 'type_params', []) or a.posonlyargs or a.kwonlyargs
            or a.vararg or a.kwarg or a.defaults or a.kw_defaults
            or [x.arg for x in a.args] != ['item', 'bins']
            or any(x.annotation or x.type_comment for x in a.args)):
        raise SurfaceError('function signature')
    if (len(f.body) < 2 or type(f.body[0]) is not ast.Expr
            or type(f.body[0].value) is not ast.Constant
            or type(f.body[0].value.value) is not str
            or type(f.body[-1]) is not ast.Return):
        raise SurfaceError('description and final return required')
    d = {'schema': 'math-dag-v1', 'description': f.body[0].value.value,
         'constants': [], 'nodes': [], 'return_node': None}
    env = {'item': 'item', 'bins': 'bins'}
    constants = {}

    def literal(v):
        if type(v) not in (int, float) or abs(v) > 1000 or not math.isfinite(v):
            raise SurfaceError('literal type/value')
        tag = 'i32' if type(v) is int else 'f64'
        key = (tag, v if type(v) is int else v.hex())
        if key not in constants:
            if len(d['constants']) >= MAX_CONSTANTS:
                raise SurfaceError('constant limit')
            constants[key] = 'c' + str(len(d['constants']))
            d['constants'].append({'type': tag, 'value': v})
        return constants[key]

    def expression(e, depth=0):
        if depth > 128:
            raise SurfaceError('expression depth limit')
        if type(e) is ast.Name and type(e.ctx) is ast.Load:
            if e.id not in env:
                raise SurfaceError('unknown or forward name')
            return env[e.id]
        if type(e) is ast.Constant:
            return literal(e.value)
        if (type(e) is ast.UnaryOp and type(e.op) is ast.USub
                and type(e.operand) is ast.Constant
                and type(e.operand.value) in (int, float)):
            return literal(-e.operand.value)
        if type(e) is ast.BinOp and type(e.op) in BINARY:
            op, args = BINARY[type(e.op)], [e.left, e.right]
        elif (type(e) is ast.Compare and len(e.ops) == 1
              and type(e.ops[0]) is ast.Gt and len(e.comparators) == 1):
            op, args = 'gt', [e.left, e.comparators[0]]
        elif (type(e) is ast.Call and type(e.func) is ast.Name
              and e.func.id in ARITY and not e.keywords
              and len(e.args) == ARITY[e.func.id]):
            op, args = e.func.id, e.args
        elif (type(e) is ast.Call and numpy_declared and type(e.func) is ast.Attribute
              and type(e.func.value) is ast.Name and e.func.value.id == 'np'
              and e.func.attr in {'exp', 'sqrt', 'where', 'greater'}
              and not e.keywords
              and len(e.args) == ARITY[{'greater':'gt'}.get(e.func.attr, e.func.attr)]):
            op, args = {'greater':'gt'}.get(e.func.attr, e.func.attr), e.args
        else:
            raise SurfaceError('forbidden AST: ' + type(e).__name__)
        refs = [expression(arg, depth + 1) for arg in args]
        if len(d['nodes']) >= MAX_NODES:
            raise SurfaceError('operation limit')
        result = len(d['nodes'])
        d['nodes'].append([op, *refs])
        return result

    for s in f.body[1:-1]:
        if (type(s) is not ast.Assign or len(s.targets) != 1
                or type(s.targets[0]) is not ast.Name or s.type_comment):
            raise SurfaceError('simple assignment required')
        name = s.targets[0].id
        if (not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*', name)
                or name in RESERVED or name in env):
            raise SurfaceError('fresh nonreserved ASCII name required')
        env[name] = expression(s.value)
    d['return_node'] = expression(f.body[-1].value)
    if type(d['return_node']) is not int:
        raise SurfaceError('return must reference operation')
    payload = json.dumps(d, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode()
    program = validate_program(payload)
    return {'payload': payload, 'program': program,
            'source_sha256': hashlib.sha256(raw).hexdigest(),
            'lowered_sha256': hashlib.sha256(payload).hexdigest()}


def extract_payload(raw, representation, metric='strict'):
    """Deterministic extraction independent of candidate validity or fitness."""
    if type(raw) is not bytes or len(raw) > 262144:
        raise SurfaceError('response byte limit/type')
    if representation not in {'dag', 'python'} or metric not in {'strict', 'unique_block'}:
        raise ValueError('extraction configuration')
    try:
        text = raw.decode('utf-8').strip()
    except UnicodeError as exc:
        raise SurfaceError('response UTF8') from exc
    language = 'json' if representation == 'dag' else 'python'
    pattern = r'```' + language + r'\r?\n([\s\S]*?)\r?\n```'
    whole = re.fullmatch(pattern, text)
    if whole and text.count('```') == 2:
        return whole.group(1).encode()
    if '```' not in text:
        return text.encode()  # Whole raw payload only; parsing decides validity.
    if metric == 'unique_block' and text.count('```') == 2:
        blocks = list(re.finditer(pattern, text))
        if len(blocks) == 1:
            return blocks[0].group(1).encode()
    raise SurfaceError('fence/whole-response contract')


def admit(raw, representation, metric='strict'):
    payload = extract_payload(raw, representation, metric)
    if representation == 'python':
        return lower_python(payload)
    return {'payload': payload, 'program': validate_program(payload),
            'source_sha256': hashlib.sha256(payload).hexdigest(),
            'lowered_sha256': hashlib.sha256(payload).hexdigest()}
