"""Independent fixed-formula scalar oracle; no generated code/eval/exec/network.
NumPy interpreter is imported only as system under test, never as reference.
"""
import sys, pathlib, json, hashlib, base64, resource, time, signal, itertools, gzip, struct, importlib.util
sys.dont_write_bytecode=True
resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
resource.setrlimit(resource.RLIMIT_CPU,(60,60))
signal.alarm(120)
start=time.monotonic();cpu=time.process_time()
ROOT=pathlib.Path(__file__).resolve().parent; BASE=ROOT.parent; WORK=BASE.parents[2]
STUDY=BASE/'glm53_concise_generation_v1'; RESULTS=STUDY/'results'; BUNDLE=WORK/'glm_generation_transfer/concise_generation_verified'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_bytes())
sources=[p for p in STUDY.rglob('*') if p.is_file() and '__pycache__' not in str(p)]+list(BUNDLE.rglob('*.json'))+list(BUNDLE.rglob('*.txt'))
sources += list((BASE/'math_dag_v1/src').glob('*.py'))+[BASE/'glm53_math_dag_pilot_v1/verify_preparation.py']+list((BASE/'glm53_math_dag_pilot_v1/data').glob('*.json'))
upstream=BASE/'paper_baseline_v1/upstream'
sources += [upstream/'historical/examples/bp_online/evaluation/evaluation.py',upstream/'examples/bp_online/evaluation/evaluation.py',upstream/'examples/bp_online/prob.py',upstream/'provenance.json']
hashes={str(p.relative_to(WORK)):sha(p) for p in sources}
raw=(BUNDLE/'runs/candidate_01/response.txt').read_bytes(); assert raw.startswith(b'```json\n') and raw.endswith(b'\n```')
# Independently remove precisely observed delimiters, retaining inner bytes.
body=raw[len(b'```json\n'):-len(b'```')]
assert body==(RESULTS/'candidate_01.program.json').read_bytes()
assert raw==(RESULTS/'candidate_01.raw.txt').read_bytes()
parsed=json.loads(body)
assert parsed['constants']==[{'type':'f64','value':0.01}]
assert parsed['nodes']==[['sub','bins','item'],['mul',0,0],['mul','c0','bins'],['sub',1,2]] and parsed['return_node']==3
meta=read(BUNDLE/'runs/candidate_01/metadata.json');assert hashlib.sha256(raw).hexdigest()==meta['response_sha256']
index=read(BUNDLE/'bundle-index.json')
for entry in index['files']:
 p=BUNDLE/entry['path'];assert sha(p)==entry['sha256'] and p.stat().st_size==entry['bytes']
spec=importlib.util.spec_from_file_location('extract_sut',BASE/'glm53_math_dag_pilot_v1/verify_preparation.py'); m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
assert m.extract_payload(raw)==(body,'single_json_fence')
sys.path.insert(0,str(BASE/'math_dag_v1/src'))
import numpy as np
from schema import validate_program
from interpreter import evaluate, pack, WorkBudget
program=validate_program(body)
assert program.types==('vi64','vi64','vf64','vf64')

def reference_score(item,b):
 # Fixed hand-derived arithmetic, Python integers unbounded. No AST or DAG eval.
 slack=b-item
 return slack*slack-0.01*b

def reference_pack(items,capacity):
 remaining=[capacity for _ in items];assignment=[];counts=[]
 for item in items:
  ids=[k for k,b in enumerate(remaining) if b>=item]
  scores=[reference_score(item,remaining[k]) for k in ids]
  winner=0
  for j in range(1,len(ids)):
   if scores[j]>scores[winner]:winner=j
  k=ids[winner];remaining[k]-=item;assignment.append(k);counts.append(len(ids))
 return dict(assignment=assignment,residuals=remaining,used_bins=sum(b!=capacity for b in remaining),feasible_counts=counts,placements=len(items))

def compare_vector(item,bins):
 expected=[reference_score(item,b) for b in bins]
 actual=evaluate(program,np.int32(item),np.array(bins,dtype=np.int64),WorkBudget(),trace=True)
 assert actual['scores'].tobytes()==b''.join(struct.pack('=d',s) for s in expected)
 assert [v.dtype.name for v in actual['values']]==['int64','int64','float64','float64']
 return expected,actual

examples=[]
for item,bins in [(20,[20,30,100]),(10,[100,10,50,100]),(100,[100,100]),(1,[1,2,500])]:
 s,a=compare_vector(item,bins);examples.append(dict(item=item,bins=bins,scores=s,first_argmax=int(np.argmax(a['scores'])),intermediate_values=[v.tolist() for v in a['values']]))
# Exhaust all valid single-item/capacity pairs in interpreter domain.
exhaustive_elements=0
for item in range(1,101):
 bins=list(range(item,501));s,a=compare_vector(item,bins);exhaustive_elements+=len(bins)
 assert all(s[j+1]>s[j] for j in range(len(s)-1))
# Bounded exhaustive ordered streams, includes tight fits and repeated ties.
small_cases=0
for n in range(1,5):
 for items in itertools.product(range(1,7),repeat=n):
  reference=reference_pack(list(items),6);actual=pack(program,list(items),6,WorkBudget())
  assert all(actual[k]==v for k,v in reference.items());small_cases+=1
records=[];score_elements=0
with gzip.open(ROOT/'full_score_vectors.jsonl.gz','wt') as out:
 for split in ['development','validation']:
  data=read(BASE/f'glm53_math_dag_pilot_v1/data/{split}.json')
  for instance in range(5):
   name=f'{split}_{instance}_candidate_01';req=read(RESULTS/(name+'.request.json'));obs=read(RESULTS/(name+'.observation.json'));checked=read(RESULTS/(name+'.checked.json'))
   assert req['items']==data['cases'][instance]['items'] and req['program_json'].encode()==body and req['capacity']==100
   stdout=base64.b64decode(obs['raw_stdout_base64'],validate=True);assert len(stdout)==obs['raw_output_bytes'] and hashlib.sha256(stdout).hexdigest()==obs['raw_output_sha256'] and json.loads(stdout)==obs['result']
   saved=obs['result']['result'];reference=reference_pack(req['items'],100);actual=pack(program,req['items'],100,WorkBudget())
   assert all(saved[k]==v==actual[k] for k,v in reference.items())
   assert reference['assignment']==checked['assignment'] and reference['used_bins']==checked['used_bins']==256
   remaining=[100]*len(req['items']);vector_count=0
   for t,item in enumerate(req['items']):
    ids=[k for k,b in enumerate(remaining) if b>=item];bins=[remaining[k] for k in ids];s,a=compare_vector(item,bins)
    winner=max(range(len(s)),key=s.__getitem__);chosen=ids[winner];assert chosen==saved['assignment'][t]
    out.write(json.dumps(dict(instance=name,placement=t,item=item,feasible_indices=ids,remaining_capacities=bins,reference_scores=s,interpreter_scores=a['scores'].tolist(),chosen=chosen),separators=(',',':'))+'\n')
    score_elements+=len(s);vector_count+=1;remaining[chosen]-=item
   # Third independent assignment checker: accumulate loads, rather than replay residual updates.
   loads=[0]*len(req['items'])
   for item,k in zip(req['items'],saved['assignment']):assert type(k) is int and 0<=k<len(loads);loads[k]+=item
   assert all(0<=load<=100 for load in loads) and [100-load for load in loads]==saved['residuals']
   assert sum(load>0 for load in loads)==saved['used_bins']
   records.append(dict(instance=name,used_bins=256,placements=vector_count,full_score_vector_bitwise_equal=True,saved_assignment_and_residuals_equal=True,independent_load_checker_passed=True))
assert all(sha(WORK/p)==h for p,h in hashes.items())
report=dict(status='passed',classification='verified description/program mathematical inconsistency; no detected pipeline sign or index bug',reference='hand-authored fixed Python scalar arithmetic and independent first-max packing',new_runs=dict(interpreter_exhaustive_eval_calls=100,exhaustive_score_elements=exhaustive_elements,small_stream_pack_calls=small_cases,saved_data_pack_calls=10,saved_data_full_vector_eval_calls=2560,saved_data_score_elements=score_elements,transparent_example_eval_calls=4,model_calls=0,remote_calls=0),examples=examples,instances=records,types=dict(item='numpy.int32',bins='numpy.int64 remaining capacities',nodes=list(program.types),score='numpy.float64'),raw_sha256=hashlib.sha256(raw).hexdigest(),program_sha256=hashlib.sha256(body).hexdigest(),all_source_hashes_unchanged=True,environment=dict(python=sys.version,numpy=np.__version__),resources=dict(cpu_seconds=time.process_time()-cpu,wall_seconds=time.monotonic()-start,peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,cpu_limit_seconds=60,wall_limit_seconds=120,address_space_limit_bytes=2*1024**3))
(ROOT/'source_hashes.json').write_text(json.dumps(hashes,indent=2)+'\n')
(ROOT/'results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['instances','examples']},indent=2))
