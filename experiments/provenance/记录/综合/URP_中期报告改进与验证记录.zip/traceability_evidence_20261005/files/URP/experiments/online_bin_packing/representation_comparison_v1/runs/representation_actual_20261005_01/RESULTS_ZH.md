# 表示×推理：16槽探索先导评分

流程终态：terminal；独立保存证据审计通过：True。所有16个生成槽及240个预定评分行均保留。

## 分层结果

- 实际runtime请求195，观测到worker 195；派发前检查尝试195；终态分布{'feasible': 195, 'not_run': 45}
- 完整5000历史设计集为主评价，256面板只诊断。没有按前缀质量、description一致性或之前数值成功筛选候选
- strict/unique是同一原始响应的两口径；同槽只评分一次。跨生成槽重复IR仍各自保存，不能称为独立新算法；模型采样seed未受控，区组顺序seed不等于配对采样seed
- length与正常stop分列；只有捕获完整、单模型消息且无工具的完整语法payload才准入。事件上限/超时截断未救回，未修复代码

## 四个条件格（各4槽）
- {"representation": "dag", "reasoning_effort": "low", "denominator": 4, "generation_normal_stop_nonempty": 4, "generation_length": 0, "nonempty_terminal_texts": 4, "intact_terminal_captures": 4, "strict_admitted": 2, "unique_admitted": 4, "main_complete_feasible": 4, "main_complete_strict_feasible": 2, "no_mean_over_incomplete_candidates": true}
- {"representation": "dag", "reasoning_effort": "high", "denominator": 4, "generation_normal_stop_nonempty": 4, "generation_length": 0, "nonempty_terminal_texts": 4, "intact_terminal_captures": 4, "strict_admitted": 3, "unique_admitted": 4, "main_complete_feasible": 4, "main_complete_strict_feasible": 3, "no_mean_over_incomplete_candidates": true}
- {"representation": "python", "reasoning_effort": "low", "denominator": 4, "generation_normal_stop_nonempty": 4, "generation_length": 0, "nonempty_terminal_texts": 4, "intact_terminal_captures": 4, "strict_admitted": 0, "unique_admitted": 1, "main_complete_feasible": 1, "main_complete_strict_feasible": 0, "no_mean_over_incomplete_candidates": true}
- {"representation": "python", "reasoning_effort": "high", "denominator": 4, "generation_normal_stop_nonempty": 4, "generation_length": 0, "nonempty_terminal_texts": 4, "intact_terminal_captures": 4, "strict_admitted": 0, "unique_admitted": 4, "main_complete_feasible": 4, "main_complete_strict_feasible": 0, "no_mean_over_incomplete_candidates": true}

## 每槽主评价（不对缺失值造分数）
- slot_01 / dag / high：生成normal_stop，strict=admitted，unique=admitted
  - 箱数[2094, 2059, 2057, 2067, 2058]，合计10335；对BF差+0，对发表EoH差+328；论文口径超下界3.984304%
- slot_02 / python / high：生成normal_stop，strict=extraction_rejected，unique=admitted
  - 箱数[2094, 2059, 2057, 2067, 2058]，合计10335；对BF差+0，对发表EoH差+328；论文口径超下界3.984304%
- slot_03 / python / low：生成normal_stop，strict=extraction_rejected，unique=schema_or_surface_rejected
  - 完整可行实例0/5；不计算完整面板质量
- slot_04 / dag / low：生成normal_stop，strict=admitted，unique=admitted
  - 箱数[5000, 5000, 5000, 5000, 5000]，合计25000；对BF差+14665，对发表EoH差+14993；论文口径超下界151.534360%
- slot_05 / python / high：生成normal_stop，strict=extraction_rejected，unique=admitted
  - 箱数[2094, 2059, 2057, 2067, 2058]，合计10335；对BF差+0，对发表EoH差+328；论文口径超下界3.984304%
- slot_06 / python / low：生成normal_stop，strict=extraction_rejected，unique=admitted
  - 箱数[2094, 2059, 2057, 2067, 2058]，合计10335；对BF差+0，对发表EoH差+328；论文口径超下界3.984304%
- slot_07 / dag / low：生成normal_stop，strict=admitted，unique=admitted
  - 箱数[2094, 2059, 2057, 2067, 2058]，合计10335；对BF差+0，对发表EoH差+328；论文口径超下界3.984304%
- slot_08 / dag / high：生成normal_stop，strict=admitted，unique=admitted
  - 箱数[2094, 2059, 2057, 2067, 2058]，合计10335；对BF差+0，对发表EoH差+328；论文口径超下界3.984304%
- slot_09 / dag / low：生成normal_stop，strict=extraction_rejected，unique=admitted
  - 箱数[2174, 2142, 2139, 2150, 2139]，合计10744；对BF差+409，对发表EoH差+737；论文口径超下界8.099406%
- slot_10 / dag / high：生成normal_stop，strict=extraction_rejected，unique=admitted
  - 箱数[2094, 2059, 2057, 2067, 2058]，合计10335；对BF差+0，对发表EoH差+328；论文口径超下界3.984304%
- slot_11 / python / high：生成normal_stop，strict=extraction_rejected，unique=admitted
  - 箱数[2094, 2059, 2057, 2067, 2058]，合计10335；对BF差+0，对发表EoH差+328；论文口径超下界3.984304%
- slot_12 / python / low：生成normal_stop，strict=extraction_rejected，unique=schema_or_surface_rejected
  - 完整可行实例0/5；不计算完整面板质量
- slot_13 / python / low：生成normal_stop，strict=extraction_rejected，unique=schema_or_surface_rejected
  - 完整可行实例0/5；不计算完整面板质量
- slot_14 / dag / low：生成normal_stop，strict=extraction_rejected，unique=admitted
  - 箱数[5000, 5000, 5000, 5000, 5000]，合计25000；对BF差+14665，对发表EoH差+14993；论文口径超下界151.534360%
- slot_15 / dag / high：生成normal_stop，strict=admitted，unique=admitted
  - 箱数[2094, 2059, 2057, 2067, 2058]，合计10335；对BF差+0，对发表EoH差+328；论文口径超下界3.984304%
- slot_16 / python / high：生成normal_stop，strict=extraction_rejected，unique=admitted
  - 箱数[2094, 2059, 2057, 2067, 2058]，合计10335；对BF差+0，对发表EoH差+328；论文口径超下界3.984304%

## 指标与证据
- 主质量口径为100×(sum箱数−sumL1)/sumL1；L1为体积下界，不是最优值。mean(L1/箱数)另存精确分数，不替换主指标
- 独立重验保存BF/EoH基线30份，没有新基线策略调用；审计候选分配195份、基线30份
- 不含description的不同IR数：11；含description canonical数：13
- 静态审阅hash 9cb1257707dce2bca218fa77534e0d260dc388fd6f97128c8f04a4c2e6d47c10；先审阅后fitness，不因mismatch/undetermined丢弃候选
- 原始正文、捕获元数据及所有hash保存；configured low/high与32000总completion是配置证据，物理HTTP参数/尝试次数没有因此被观察到

## 预算与限制
- 评分阶段（已计本研究mock/手写控制与静态准入debit）{'cpu_seconds': 60.64638107, 'active_wall_seconds': 60.51542702499137}；独立审计另{'cpu_seconds': 1.5331390599999999, 'active_wall_seconds': 1.5245426460023737, 'startup_allowance_seconds': 1}
- 每实例60CPU秒/90wall秒/2GiB/1,625,000,000工作量；合计1800CPU/2700activewall，提前预留下一请求62/92及终结40/40。资源/预算缺失不是算法质量失败，基础设施失败停止剩余派发
- 数据全部研究范围内已暴露；开发256前缀与完整5000相关。每条件仅4次探索生成，不能声称强因果、统计显著性、模型排名、通用编程能力或完整Python额外表达力
- 限定Python只做白名单AST转同一IR，从未执行候选Python。此项不是原EoH完整多代进化复现

## 文件
- preparation_seal.json与preparation/：原文、metadata、两口径准入及payload
- scores/static_review.json：独立公开description/code静态审阅
- scores/report.json：全部240终态、面板与分层统计
- scores/*observation.json：真实worker原始输出、限额与成本
- scores/independent_audit.json：整数负载独立复算
