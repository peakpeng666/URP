# 固定 published EoH DAG 数值正控制（独立补充）

## 结论

通过。固定公式可在原始 math_dag_v1 的 64 节点上限内表示：本图只用 15 节点、5 常数及既有的 sub/exp/sqrt/div/mul/gt/where/add。未扩充解释器、未修复或截断浮点结果、未更改旧冻结文件。该结论是固定公式的表达能力与当前环境的数值合同核验，不是新候选质量或装箱性能结论。

已有 math_dag_v1/fixtures/programs/published_eoh.json 包含同结构历史固定图；本次在新目录重新手工列出图并执行独立门槛，不声称首次发现该表达。

## 预先固定与边界

执行前保存 published_eoh.json、protocol.json、numeric_gate.py、launch.py，以及 freeze.json 的14项源码/解释器/历史冻结文件 SHA-256。结束后与独立证据审计均核对这些文件未变。

- 可信参考：published_eoh_formula_v1/src/formula.py；SHA-256 282deba5a6c4a0f5247a0750fdd11b78d2e2dbec88738787f9ef72d034fdb3e4
- 新图 SHA-256：7e74a8399a455b4fe35330fe34949b218b465fd523c314bf39f72abf7bb0a4b4
- 预执行 freeze.json SHA-256：b39e0d3c5cf4be37f5de5152e299b6ba59fefb9063dc9693524f721113578608
- Python 3.12.14；NumPy 2.3.5
- 输入维持 np.int32 item、1D int64 bins；浮点运算/最终分数 float64；整数与布尔节点保持原合同
- 实际使用原 runtime.py 的更紧 worker 限制：CPU20s、wall30s（cleanup1s）、地址空间2GiB、文件增长0、32文件描述符、stdout400000B/stderr16384B
- launcher CPU30s/地址空间2GiB，外层总wall120s；两个进程CPU上限合计50s，小于所要求60s，但2GiB是逐进程地址空间上限，非进程树聚合RSS保证
- 无网络/安装/模型调用；只运行手写测试数据、既有可信公式与可信数学解释器，没有作者下载源码或模型生成Python

## 运算序列

0 diff=bins-item；1 exp=exp(diff)；2 sqrt=sqrt(diff)；3 diff/bins；4 ulti=1-node3；5 comb=ulti*sqrt；6 item*3；7 diff>node6；8 comb+0.8；9 comb+0.3；10 adjust=where(node7,node8,node9)；11 exp+0.7；12 denominator=node11*exp；13 hybrid_exp=bins/denominator；14 scores=hybrid_exp+adjust。

整数常数1和3为i32，0.8/0.3/0.7为f64。逐节点执行，无代数化简、无exact-fit捷径。与参考中9个命名中间量逐一比较dtype、shape、原始bytes；另外6个子表达式由固定图结构和类型推导记录，本轮没有独立参考函数逐个重算这6个值。

## 原始数值检查摘要

- C100：全部5050个可行(item,remaining)对；每个item覆盖升序、降序、每值相邻重复的向量，共300向量、20200个分数
- C500：全部45050个解释器允许的可行对（item仍为1..100）；同样300向量、180200个分数
- 共600向量、200400个分数，全部与可信参考bitwise一致；9个命名中间量均逐向量bitwise一致
- 最终分数全部finite；首argmax全部一致，以参考最大值的第一个索引核验，并检查重复向量选择偶数索引（相邻重复中的第一个）
- 升降序重排与重复扩展保持相应分数序列；输入未修改
- 9000个完成节点；共享抽象工作量3006000，低于原5000000上限
- C100双方无警告
- C500参考与DAG各300条 RuntimeWarning: overflow encountered in multiply；分别位于 formula.py:26 和 interpreter.py:67/node12，逐例数量及类型核对一致
- 中间正无穷元素累计38200，NaN/负无穷均0；这些Inf来自原分母乘法，随后的除法仍给出有限结果。原解释器已允许此行为，本次未放宽限制

## 实际成本与证据

worker CPU 0.365985s，wall 0.367094591s，峰值RSS 26152KiB；launcher至返回/校验阶段CPU 0.099898052s、wall 0.465880417s。两者CPU合计0.465883052s，不包括之后结果序列化、静态报告编写和证据审计开销。stderr为空，worker退出码0且已回收。

原始stdout 326191B，SHA-256 e130254b08035657f7524151dc816f6d749fd6589a23e2dbc2bdf69ab557307c；完整字节保留于 results/raw_observation.json 的base64字段，已反解并核对摘要/大小。

- results/summary.json：检查摘要及实测资源
- results/cases.jsonl：600条逐向量记录、参考/实际分数hash、首argmax、中间量匹配数和Inf/警告数量
- results/warnings.json：双方全部600条原始警告事件
- results/raw_observation.json：完整stdout/stderr原始字节、解析结果、进程状态及资源
- results/evidence_audit.json：独立静态证据/源码未变复核

## 局限与研究隔离

只核验固定参考与固定DAG在一个可信NumPy环境、规定三种向量组织上的一致性；未穷举任意向量排列/长度，未证明跨平台浮点一致性，共享NumPy也不是独立数值实现的证据。没有运行装箱实例，没有评分任何新GLM候选，没有读取这些候选，没有追加开发验证实例。已有四候选研究及预定BF主判据均保持独立；未来若为候选补充EoH评分，必须标为独立补充，不能改写原主判据。

闭合数学图没有文件/网络/任意Python调用入口。rlimits不是通用不可信Python沙箱，也没有宣称设置了网络namespace；执行代码严格限于此次手工控制和既有可信代码。
