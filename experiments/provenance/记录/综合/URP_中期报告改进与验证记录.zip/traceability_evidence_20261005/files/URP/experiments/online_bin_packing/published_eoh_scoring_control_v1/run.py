"""Trusted fixed-policy study, not a generated-code executor. No model calls."""
import time
START=time.monotonic()
import base64,datetime,hashlib,importlib.util,json,os,pathlib,resource,signal,sys
from fractions import Fraction
sys.dont_write_bytecode=True
ROOT=pathlib.Path(__file__).resolve().parent;BASE=ROOT.parent;STUDY=BASE/'glm53_math_dag_pilot_v1'
resource.setrlimit(resource.RLIMIT_AS,(2147483648,2147483648))
resource.setrlimit(resource.RLIMIT_CPU,(40,40))
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(pathlib.Path(p).read_bytes())
def save(p,d):
 with pathlib.Path(p).open('x') as f:json.dump(d,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
def mod(name,p):
 spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
def totals():
 r=resource.getrusage(resource.RUSAGE_CHILDREN)
 return {'cpu_seconds':1+time.process_time()+r.ru_utime+r.ru_stime,'active_wall_seconds':1+time.monotonic()-START}
def within():
 t=totals();return t['cpu_seconds']+22+15<=120 and t['active_wall_seconds']+32+15<=180
freeze=read(ROOT/'freeze.json')
def verify():
 for p,h in freeze['sha256'].items():
  if sha(p)!=h:raise RuntimeError('hash mismatch: '+p)
def transport(obs):
 raw=base64.b64decode(obs['raw_stdout_base64'],validate=True)
 if hashlib.sha256(raw).hexdigest()!=obs['raw_output_sha256'] or len(raw)!=obs['raw_output_bytes'] or json.loads(raw)!=obs['result']:raise RuntimeError('raw observation binding')
def alarm(*_):raise TimeoutError('active deadline reached; terminal reserve retained')
def main():
 out=ROOT/'results';out.mkdir(exist_ok=False);rows=[{'split':s,'instance':i,'method':'published_EoH','status':'not_run','reason':'not_reached'} for s in ['development','validation'] for i in range(5)]
 save(out/'initial_ledger.json',rows);errors=[];baselines=[];calls=0;groups=[]
 signal.signal(signal.SIGALRM,alarm);signal.setitimer(signal.ITIMER_REAL,max(.01,164-(time.monotonic()-START)))
 try:
  verify()
  sys.path.insert(0,str(BASE/'math_dag_v1/src'))
  from runtime import request
  from integrity import verify as integrity
  integrity(freeze['math_evaluator_freeze_sha256'])
  checked=mod('existing_score_checks',STUDY/'scoring_runner_v2/run.py').checked
  data={s:read(STUDY/f'data/{s}.json')['cases'] for s in ['development','validation']}
  historical=STUDY/'runs/official_glm53_20261005_01';old=read(historical/'report.json')
  # Check full raw baseline observations against the exact frozen requests/data.
  for s in ['development','validation']:
   for i,c in enumerate(data[s]):
    for m in ['FF','BF']:
     raw=(BASE/f'math_dag_evolution_v1/seeds/{m.lower()}.json').read_bytes();stem=f'{s}_{i}_{m}'
     req=read(historical/(stem+'.request.json'));obs=read(historical/(stem+'.observation.json'))
     if req!={'mode':'pack','program_json':raw.decode(),'items':c['items'],'capacity':100}:raise RuntimeError('baseline request mismatch')
     transport(obs);r=checked(raw,c['items'],obs)
     prior=next(x for x in old['scores'] if x['split']==s and x['instance']==i and x['method']==m)
     if r['status']!='feasible' or any(prior[k]!=r[k] for k in r):raise RuntimeError('saved baseline mismatch')
     baselines.append({'split':s,'instance':i,'method':m,**r,'source_observation':str(historical/(stem+'.observation.json'))})
  save(out/'baseline_rechecks.json',baselines)
  raw=(BASE/'published_eoh_dag_control_v1/published_eoh.json').read_bytes()
  for row in rows:
   if not within():row['reason']='insufficient_budget';continue
   verify();s=row['split'];i=row['instance'];items=data[s][i]['items'];name=f'{s}_{i}_published_EoH'
   req={'mode':'pack','program_json':raw.decode(),'items':items,'capacity':100};save(out/(name+'.request.json'),req)
   row.update(status='dispatched',reason=None);calls+=1
   obs=request(req);save(out/(name+'.observation.json'),obs);transport(obs)
   row.update(checked(raw,items,obs))
   row.update(worker_cpu_seconds=obs['worker_cpu_seconds'],wall_seconds=obs['wall_seconds'],worker_peak_rss_kib=obs['worker_peak_rss_kib'],warning_events=len(obs['result']['warnings']['events']),score_elements=sum(obs['result']['result']['feasible_counts']) if obs['result'].get('result') else None)
   save(out/(name+'.checked.json'),row)
  for s in ['development','validation']:
   selected=[r for r in rows if r['split']==s];g={'split':s,'feasible_count':sum(r['status']=='feasible' for r in selected),'denominator':5}
   if g['feasible_count']==5:
    bins=[r['used_bins'] for r in selected];g.update(bins=bins,sum_bins=sum(bins),exact_mean_L1_over_bins=str(sum((Fraction(r['L1'],r['used_bins']) for r in selected),Fraction())/5))
    for m in ['BF','FF']:
     refs=[r for r in baselines if r['split']==s and r['method']==m];rb=[r['used_bins'] for r in refs];ds=[a-b for a,b in zip(bins,rb)]
     g[m]={'bins':rb,'sum_bins':sum(rb),'delta_bins':sum(ds),'per_instance_delta':ds,'wins_ties_losses':[sum(d<0 for d in ds),sum(d==0 for d in ds),sum(d>0 for d in ds)],'relative_total_bin_reduction':str(Fraction(sum(rb)-sum(bins),sum(rb))),'exact_mean_L1_over_bins':str(sum((Fraction(r['L1'],r['used_bins']) for r in refs),Fraction())/5),'different_assignments':[sum(a!=b for a,b in zip(x['assignment'],y['assignment'])) for x,y in zip(selected,refs)]}
   groups.append(g)
 except Exception as e:errors.append(type(e).__name__+': '+str(e))
 finally:
  signal.setitimer(signal.ITIMER_REAL,15)
  for r in rows:
   if r['status']=='dispatched':r.update(status='infrastructure_failure',reason='interrupted_dispatch')
   elif r['reason']=='not_reached':r['reason']='stopped_infrastructure'
  try:verify();post={p:sha(p) for p in freeze['sha256']};unchanged=True
  except Exception as e:errors.append('terminal integrity: '+str(e));post={};unchanged=False
  save(out/'hashes_after.json',post)
  t=totals()
  if t['cpu_seconds']>120 or t['active_wall_seconds']>180:errors.append('budget exceeded')
  report={'state':'completed' if not errors and all(r['status']=='feasible' for r in rows) else 'incomplete','errors':errors,'actual_score_dispatches':calls,'policy_replay_dispatches':0,'saved_baseline_assignment_rechecks':len(baselines),'scores':rows,'groups':groups,'budget':t,'source_and_data_unchanged':unchanged,'freeze_sha256':sha(ROOT/'freeze.json'),'preparation_excluded':True,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
  save(out/'report.json',report);save(out/'completion_accounting.json',{'measured_after_report':totals(),'startup_allowance_seconds':1,'terminal_reserve_seconds':15,'numeric_workers_total_cpu_seconds':sum(r.get('worker_cpu_seconds',0) for r in rows),'numeric_workers_total_wall_seconds':sum(r.get('wall_seconds',0) for r in rows)})
  signal.setitimer(signal.ITIMER_REAL,0)
 print(json.dumps({'state':report['state'],'groups':groups,'budget':totals(),'errors':errors},indent=2))
 return 0 if report['state']=='completed' else 1
if __name__=='__main__':raise SystemExit(main())
