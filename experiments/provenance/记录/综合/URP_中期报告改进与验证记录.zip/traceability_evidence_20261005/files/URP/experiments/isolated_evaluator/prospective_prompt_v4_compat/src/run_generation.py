"""Trusted offline paired generation. Candidate strings are data only.

Entry requires a consumed stage-specific supervisor lease. Unit tests call only the
pure fixed-plan / journal driver with handwritten fake generation results.
"""
import argparse
import datetime
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import resource
import sys
import time

from extract import extract_initial_function
from generation_integrity import (ROOT, APPROVAL_LIMIT, read_json, sha256_bytes,
                                  sha256_file, validate_worker_lease,
                                  verify_frozen_inputs, write_json, fsync_directory, jobs, parse_json_bytes)

SEEDS = [601, 631, 661, 701, 751]
ORDERS = [["A", "B"], ["B", "A"], ["A", "B"], ["B", "A"], ["A", "B"]]
FIXED_GENERATION = {
    "max_new_tokens": 512, "maximum_total_tokens": 2048,
    "maximum_generation_calls": 10, "maximum_output_tokens_total": 5120,
    "num_beams": 1, "num_return_sequences": 1, "temperature": 0.7, "top_p": 0.95,
    "top_k": 0, "repetition_penalty": 1.0, "do_sample": True,
    "device": "cpu", "dtype": "float32", "torch_num_threads": 1,
    "torch_num_interop_threads": 1, "deterministic_algorithms": True,
    "automatic_retry": False, "candidate_execution": False,
    "extraction_rule": "tokenize_dedent_then_real_top_level_token_v1",
}
FIXED_LIMITS = {"address_space_bytes": 6 * 1024**3, "cpu_soft_seconds": 900,
                "cpu_hard_seconds": 910, "whole_wall_seconds": 1200,
                "terminate_grace_seconds": 2, "kill_reap_seconds": 3,
                "poll_seconds": 0.05, "freeze_bytes": 32 * 1024**2,
                "approval_bytes": 16384, "event_line_bytes": 1048576,
                "record_line_bytes": 2097152}


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def usage():
    current = resource.getrusage(resource.RUSAGE_SELF)
    return {"process_user_cpu_seconds": current.ru_utime,
            "process_system_cpu_seconds": current.ru_stime,
            "process_cpu_seconds": current.ru_utime + current.ru_stime,
            "process_peak_rss_kib": current.ru_maxrss,
            "monotonic_seconds": time.monotonic()}


def fixed_jobs(config):
    if config["seeds"] != SEEDS or config["arm_orders"] != ORDERS:
        raise ValueError("Only the prospectively fixed five paired seeds/order are permitted")
    if config["generation"] != FIXED_GENERATION or config["limits"] != FIXED_LIMITS:
        raise ValueError("Generation parameters or whole-process limits changed")
    if config["prompts"] != {"A": "prompts/A.txt", "B": "prompts/B.txt"}:
        raise ValueError("Prompt arms changed")
    return jobs(config)


def initialize_ledger(output, config, batch_id, digest):
    ledger = {"schema_version": "p2-v4-generation-ledger-1", "batch_id": batch_id,
              "preparation_freeze_sha256": digest, "generation_retry_count": 0,
              "generated_code_executed": False,
              "slots": [{**job, "state": "not_started", "raw_record_line": None}
                        for job in fixed_jobs(config)]}
    write_json(Path(output) / "generation_ledger.json", ledger, exclusive=True)
    for name in ("attempt_events.jsonl", "raw_generations.jsonl"):
        with (Path(output) / name).open("xb") as stream:
            stream.flush()
            os.fsync(stream.fileno())
    fsync_directory(output)
    return ledger


class Journal:
    def __init__(self, output):
        self.output = Path(output)
        self.events = (self.output / "attempt_events.jsonl").open("ab")
        self.records = (self.output / "raw_generations.jsonl").open("ab")
        self.record_count = 0

    @staticmethod
    def append(stream, value, limit):
        payload = (json.dumps(value, ensure_ascii=False, allow_nan=False) + "\n").encode("utf-8")
        if len(payload) > limit:
            raise ValueError("Evidence JSONL line byte cap exceeded")
        stream.write(payload)
        stream.flush()
        os.fsync(stream.fileno())

    def event(self, kind, candidate_id=None, **fields):
        self.append(self.events, {"event": kind, "candidate_id": candidate_id,
                                 "utc": utc(), **usage(), **fields}, FIXED_LIMITS["event_line_bytes"])

    def record(self, value):
        self.append(self.records, value, FIXED_LIMITS["record_line_bytes"])
        self.record_count += 1
        return self.record_count

    def close(self):
        self.records.close()
        self.events.close()


def write_source(output, candidate_id, form, source):
    data = source.encode("utf-8")
    relative = f"sources/{candidate_id}.{form}.txt"
    with (Path(output) / relative).open("xb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    fsync_directory(Path(output) / "sources")
    return relative, sha256_bytes(data), len(data)


def run_jobs(config, prompts, output, generate, journal):
    """Execute fixed driver, preserving failures. generate is a trusted callable.

    It must call mark_call(input_ids, kwargs) exactly once immediately before the
    model invocation. Production has no plugin/configurable callable entry point.
    An infrastructure/error slot terminates the batch without retries/replacements.
    """
    jobs = fixed_jobs(config)
    calls = 0
    total_tokens = 0
    Path(output, "sources").mkdir(exist_ok=False)
    for job in jobs:
        started = time.monotonic()
        cpu_started = time.process_time()
        record = {**job, "mode": "sample", "prompt": prompts[job["prompt_id"]],
                  "generated_code_executed": False, "started_at_utc": utc()}
        journal.event("candidate_attempt_started", job["id"], seed=job["seed"], prompt_id=job["prompt_id"])
        marked = False

        def mark_call(input_ids, kwargs):
            nonlocal calls, marked
            if marked or calls >= 10:
                raise RuntimeError("An extra model call is prohibited")
            if type(input_ids) is not list or any(type(item) is not int for item in input_ids):
                raise ValueError("Input token IDs must be exact integers")
            if not input_ids or len(input_ids) + 512 > 2048:
                raise ValueError("Fixed context token cap exceeded")
            record.update(input_ids=input_ids, input_token_count=len(input_ids), generation_kwargs=kwargs)
            journal.event("generate_call_started", job["id"], seed=job["seed"],
                          prompt_id=job["prompt_id"], input_ids=input_ids,
                          input_token_count=len(input_ids), generation_kwargs=kwargs)
            marked = True
            calls += 1

        try:
            result = generate(record["prompt"], job["seed"], mark_call)
            if not marked:
                raise RuntimeError("Missing durable generate-call start event")
            # Keep returned data before testing generation invariants; never repair it.
            output_ids = result["output_ids"]
            continuation = result["continuation"]
            if type(continuation) is not str or type(output_ids) is not list:
                raise TypeError("Generation returned invalid data types")
            source = record["prompt"] + continuation
            extraction = extract_initial_function(source)
            raw_path, raw_hash, raw_bytes = write_source(output, job["id"], "raw", source)
            chosen_path, chosen_hash, chosen_bytes = write_source(output, job["id"], "extracted", extraction["source"])
            record.update(continuation=continuation, candidate_source=source, extraction=extraction,
                          output_ids=output_ids, output_token_count=len(output_ids),
                          candidate_source_sha256=raw_hash, extracted_source_sha256=chosen_hash,
                          raw_source_path=raw_path, extracted_source_path=chosen_path,
                          raw_source_bytes=raw_bytes, extracted_source_bytes=chosen_bytes,
                          eos_token_id=result["eos_token_id"])
            if any(type(token) is not int for token in output_ids) or len(output_ids) > 512:
                raise ValueError("Output token ID/type cap violated")
            if result["input_ids"] != record["input_ids"]:
                raise ValueError("Generation changed recorded input token IDs")
            total_tokens += len(output_ids)
            if total_tokens > 5120:
                raise ValueError("Whole-batch output token cap violated")
            ended_eos = bool(output_ids and output_ids[-1] == result["eos_token_id"])
            if not ended_eos and len(output_ids) != 512:
                raise ValueError("Generation stopped without EOS or token cap")
            record.update(status="generated", stop_reason="eos" if ended_eos else "token_cap")
        except Exception as exc:
            record.update(status="generation_error", error_type=type(exc).__name__, error=str(exc)[:4096])
        record.update(ended_at_utc=utc(), elapsed_seconds=time.monotonic() - started,
                      cpu_seconds=time.process_time() - cpu_started, **usage())
        line = journal.record(record)
        journal.event("candidate_attempt_completed", job["id"], status=record["status"],
                      raw_record_line=line, elapsed_seconds=record["elapsed_seconds"],
                      cpu_seconds=record["cpu_seconds"])
        if record["status"] != "generated":
            return {"status": "generation_error", "generation_calls": calls,
                    "output_token_count": total_tokens, "stopped_after": job["id"]}
    return {"status": "complete", "generation_calls": calls, "output_token_count": total_tokens}


def check_limits():
    expected = {resource.RLIMIT_AS: (6 * 1024**3, 6 * 1024**3), resource.RLIMIT_CPU: (900, 910)}
    actual = {str(key): list(resource.getrlimit(key)) for key in expected}
    if any(resource.getrlimit(key) != limits for key, limits in expected.items()):
        raise RuntimeError("Worker effective resource limits do not match frozen bounds")
    return actual


def verify_model_provenance(config, freeze):
    model = config["model"]
    if (model["repo_id"] != "Salesforce/codegen-350M-mono"
            or model["revision"] != "d9107f71cca463240db1143f4a75a927a27fcb27"
            or model["official_weight_sha256"] != "90e20f4887289739a435452f26974d97937adb41485f9c1a7b3d3810aac6773d"
            or model["directory"] != "../../sorting_generation/.model"
            or model["python"] != "../../sorting_generation/.venv/bin/python"
            or model["provenance"] != "../../sorting_generation/results/model_download.json"):
        raise ValueError("Model identity or trusted local asset path changed")
    _, provenance = read_json(ROOT / model["provenance"], 65536)
    if (provenance.get("repo_id") != model["repo_id"] or provenance.get("revision") != model["revision"]
            or provenance.get("verified_official_weight_sha256") is not True):
        raise ValueError("Official pinned model provenance mismatch")
    for entry in provenance["files"]:
        filename = entry["filename"]
        if Path(filename).name != filename:
            raise ValueError("Model provenance filename must be a basename")
        name = model["directory"] + "/" + filename
        if freeze["generation_files"].get(name) != entry["sha256"]:
            raise ValueError("Frozen model digest does not match official provenance")
    weight = model["directory"] + "/pytorch_model.bin"
    if freeze["generation_files"].get(weight) != model["official_weight_sha256"]:
        raise ValueError("Official weight digest mismatch")


def load_trusted_generator(config, output, journal):
    # Metadata is checked before importing torch/transformers or deserializing weights.
    if platform.python_version() != config["environment"]["python"] or platform.python_implementation() != "CPython":
        raise RuntimeError("Frozen CPython version mismatch")
    versions = {name: importlib.metadata.version(name) for name in config["environment"]["versions"]}
    if versions != config["environment"]["versions"]:
        raise RuntimeError("Frozen generation package versions mismatch")
    journal.event("model_load_started")
    started = time.monotonic()
    from safe_model_load import load_trusted_components
    torch, tokenizer, model, set_seed, load_audit = load_trusted_components(config, journal)
    write_json(Path(output) / "generation_environment.json", {
        "python": sys.version, "versions": versions, "device": "cpu", "dtype": "float32",
        "threads": 1, "interop_threads": 1, "deterministic_algorithms": True,
        "inference_mode": True, "weights_only": True, "extra_unpickler_globals": [],
        "trust_remote_code": False, "local_files_only": True, "generated_code_executed": False,
        "effective_limits": check_limits(), "safe_load_audit": load_audit}, exclusive=True)
    journal.event("model_load_completed", elapsed_seconds=time.monotonic() - started,
                  model_class=type(model).__name__)

    def generate(prompt, seed, mark_call):
        set_seed(seed)
        inputs = tokenizer(prompt, return_tensors="pt", return_token_type_ids=False)
        input_ids = inputs["input_ids"][0].tolist()
        kwargs = {"max_new_tokens": 512, "num_beams": 1, "num_return_sequences": 1,
                  "do_sample": True, "temperature": 0.7, "top_p": 0.95, "top_k": 0,
                  "repetition_penalty": 1.0, "pad_token_id": tokenizer.eos_token_id,
                  "eos_token_id": tokenizer.eos_token_id}
        mark_call(input_ids, kwargs)
        with torch.inference_mode():
            generated = model.generate(**inputs, **kwargs)
        if len(generated) != 1:
            raise RuntimeError("Model returned a non-singleton sequence")
        output_ids = generated[0, len(input_ids):].tolist()
        return {"input_ids": input_ids, "output_ids": output_ids,
                "continuation": tokenizer.decode(output_ids, skip_special_tokens=True,
                                                   clean_up_tokenization_spaces=False),
                "eos_token_id": tokenizer.eos_token_id}
    return generate


def main():
    started = usage()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lease-fd", type=int, required=True)
    args = parser.parse_args()
    check_limits()
    with os.fdopen(args.lease_fd, "rb") as stream:
        lease_data = stream.read(APPROVAL_LIMIT + 1)
    if len(lease_data) > APPROVAL_LIMIT:
        raise ValueError("Oversized generation launch lease")
    lease = validate_worker_lease(ROOT, parse_json_bytes(lease_data))
    output = Path(lease["output_directory"])
    journal = Journal(output)
    status = {"status": "infrastructure_error"}
    integrity_after = "not_checked"
    try:
        journal.event("worker_started", initial_usage=started, effective_limits=check_limits())
        digest = lease["preparation_freeze_sha256"]
        freeze = verify_frozen_inputs(ROOT, digest)
        _, config = read_json(ROOT / "generation_config.json", 65536)
        fixed_jobs(config)
        verify_model_provenance(config, freeze)
        journal.event("integrity_before_passed")
        prompts = {arm: (ROOT / path).read_bytes().decode("utf-8") for arm, path in config["prompts"].items()}
        generator = load_trusted_generator(config, output, journal)
        status = run_jobs(config, prompts, output, generator, journal)
    except Exception as exc:
        status = {"status": "infrastructure_error", "error_type": type(exc).__name__, "error": str(exc)[:4096]}
        journal.event("worker_error", **status)
    finally:
        try:
            verify_frozen_inputs(ROOT, lease["preparation_freeze_sha256"])
            integrity_after = "passed"
            journal.event("integrity_after_passed")
        except Exception as exc:
            integrity_after = "failed"
            status.update(status="integrity_error", integrity_error_type=type(exc).__name__, integrity_error=str(exc)[:4096])
        status.update(integrity_after=integrity_after, initial_usage=started, final_usage=usage(),
                      whole_worker_wall_seconds=time.monotonic() - started["monotonic_seconds"],
                      generated_code_executed=False)
        write_json(output / "worker_status.json", status, exclusive=True)
        journal.event("worker_completed", **status)
        journal.close()
    return 0 if status["status"] == "complete" and integrity_after == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
