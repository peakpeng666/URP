"""Source-bound static admission for16 slots; never evaluate a candidate policy."""
import argparse,datetime,hashlib,importlib.util,json,pathlib,sys,time
ROOT=pathlib.Path(__file__).resolve().parent;BASE=ROOT.parent
sys.dont_write_bytecode=True
class Infrastructure(ValueError):pass

def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def json_load(p,limit=2000000):
 p=pathlib.Path(p)
 if p.stat().st_size>limit:raise Infrastructure('JSON byte bound: '+str(p))
 def pairs(xs):
  out={}
  for k,v in xs:
   if k in out:raise Infrastructure('duplicate JSON key')
   out[k]=v
  return out
 def reject(x):raise Infrastructure('nonfinite JSON')
 return json.loads(p.read_bytes(),object_pairs_hook=pairs,parse_constant=reject)
def save(p,x):
 with pathlib.Path(p).open('x') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')
def mod(name,p):
 spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m

def verify_freeze(expected):
 if sha(ROOT/'freeze.json')!=expected:raise Infrastructure('freeze identity')
 f=json_load(ROOT/'freeze.json')
 for p,h in f['sha256'].items():
  if not pathlib.Path(p).is_absolute() or sha(p)!=h:raise Infrastructure('frozen source/data changed: '+p)
 return f

def validate_capture_record(r,slot,prompt_hash,generation):
 """Validate metadata provenance; return declared generation terminal category."""
 if r.get('slot')!=slot['slot'] or r.get('id')!=f"slot_{slot['slot']:02d}" or r.get('block')!=slot['block'] or r.get('representation')!=slot['representation'] or r.get('model_id')!=slot['model']:raise Infrastructure('slot/model/block/representation binding')
 if r.get('prompt_sha256')!=prompt_hash or r.get('cli_version')!=generation['client']['cli_version']:raise Infrastructure('prompt/CLI binding')
 if r.get('terminal') is not True or r.get('status') not in ['completed','generation_failed','not_run']:raise Infrastructure('all16generation slots must be terminal')
 configured={'reasoning_effort':slot['reasoning_effort'],'temperature':generation['temperature'],'top_p':generation['top_p'],'max_completion_tokens':generation['max_completion_tokens'],'wall_seconds':generation['wall_seconds_per_slot'],'steps':generation['client']['steps'],'tools':False,'outer_retries':0}
 if r.get('configured')!=configured:raise Infrastructure('configured condition mismatch')
 if r.get('settings_provenance')!='configured_metadata_not_observed_HTTP' or r.get('physical_http_attempts_observed','missing') is not None or r.get('sampling_seed','missing') is not None:raise Infrastructure('configured/observed/seed distinction')
 if r.get('logical_cli_requests') not in [0,1] or r.get('payload_provenance')!='OpenCode JSON part.text':raise Infrastructure('logicalrequest/payload provenance')
 if r['status']=='not_run':
  if r['logical_cli_requests']!=0:raise Infrastructure('not_run request count')
  return 'not_run'
 if r['logical_cli_requests']!=1:raise Infrastructure('dispatched request count')
 category=capture_category(r)
 if category in ['normal_stop','generation_length'] and (not isinstance(r.get('configuration_sha256'),str) or len(r['configuration_sha256'])!=64):raise Infrastructure('configuration hash missing')
 return category


def capture_category(r):
 """Intact capture is independent of capture_succeeded's nonempty-text meaning."""
 required={'cli_exit_code':0,'capture_completed_normally':True,'tool_events':0,'model_messages':1,'capture_truncated':False}
 safe=not any(r.get(k)!=v or (type(v)is bool and type(r.get(k))is not bool) for k,v in required.items()) and r.get('finish_reasons') in [['stop'],['length']] and r.get('stop_reason','missing') is None
 if not safe:
  if r['status']=='completed':raise Infrastructure('completed envelope conflicts with capture evidence')
  return 'capture_or_generation_failed'
 # Preserve the capture runner's semantic nonempty-output flag, even whenfalse.
 if type(r.get('capture_succeeded')) is not bool:raise Infrastructure('original capture_succeeded boolean missing')
 return 'normal_stop' if r['finish_reasons']==['stop'] else 'generation_length'



def crosscheck_metadata(meta,rec,raw):
 """Check normalized manifest against unchanged non-secret CLI capture fields."""
 direct={'model':'model_id','prompt_sha256':'prompt_sha256','cli_version':'cli_version','configuration_sha256':'configuration_sha256','response_sha256':'raw_text_sha256','process_exit_code':'cli_exit_code','capture_completed_normally':'capture_completed_normally','capture_succeeded':'capture_succeeded','tool_events':'tool_events','distinct_model_message_count':'model_messages','finish_reasons':'finish_reasons','stop_reason':'stop_reason','logical_cli_invocations':'logical_cli_requests'}
 for source,target in direct.items():
  if source not in meta or meta[source]!=rec.get(target):raise Infrastructure('normalized capture metadata mismatch: '+source)
 configured=rec['configured']
 for source,target in [('temperature','temperature'),('top_p','top_p'),('max_output_tokens','max_completion_tokens'),('wall_clock_limit_seconds','wall_seconds'),('steps','steps'),('outer_retries','outer_retries')]:
  if meta.get(source)!=configured[target]:raise Infrastructure('configured metadata mismatch: '+source)
 if meta.get('model_options',{}).get('reasoningEffort')!=configured['reasoning_effort']:raise Infrastructure('model-level reasoning setting metadata')
 if meta.get('response_bytes')!=len(raw) or meta.get('response_is_unmodified_cli_terminal_text') is not True or meta.get('response_is_raw_http') is not False or meta.get('http_attempt_count')!='unknown':raise Infrastructure('raw text/capture versus HTTP evidence')
 if meta.get('seed')!='uncontrolled':raise Infrastructure('uncontrolled sampling seed evidence')
 if 'capture_truncated' in meta and meta['capture_truncated'] is not False:raise Infrastructure('source capture explicitly truncated')


def admit_both(raw,representation,adapter):
 rows={};admitted={}
 for metric in ['strict','unique_block']:
  try:
   body=adapter.extract_payload(raw,representation,metric)
  except (ValueError,UnicodeError,RecursionError) as e:
   rows[metric]={'status':'extraction_rejected','reason':str(e)[:1000]};continue
  try:
   out=adapter.admit(raw,representation,metric);program=out['program'];admitted[metric]=out
   rows[metric]={'status':'admitted','payload_sha256':hashlib.sha256(out['payload']).hexdigest(),'canonical_program_sha256':program.canonical_sha256,'description':program.description,'nodes':len(program.nodes),'constants':len(program.constants)}
  except (ValueError,UnicodeError,RecursionError) as e:rows[metric]={'status':'schema_or_surface_rejected','reason':str(e)[:1000]}
 if 'strict' in admitted and 'unique_block' not in admitted:raise Infrastructure('strict admission not subset of unique')
 if len(admitted)==2 and admitted['strict']['payload']!=admitted['unique_block']['payload']:raise Infrastructure('strict/unique did not resolve to same program')
 return rows,admitted.get('unique_block')

def prepare(input_manifest,expected_input,expected_freeze,output):
 start=time.monotonic();cpu=time.process_time()
 verify_freeze(expected_freeze)
 input_manifest=pathlib.Path(input_manifest).resolve()
 if sha(input_manifest)!=expected_input:raise Infrastructure('manifest hash')
 manifest=json_load(input_manifest);protocol=json_load(ROOT/'protocol.json');generation=protocol.get('generation',protocol.get('proposed_generation'));order=json_load(ROOT/protocol['design']['order_file']);slots=order['slots'];records=manifest['records']
 if len(slots)!=16 or [x['slot'] for x in slots]!=list(range(1,17)) or len(records)!=16 or [x.get('slot') for x in records]!=list(range(1,17)):raise Infrastructure('exact16orderedslots required')
 out=pathlib.Path(output);out.mkdir(parents=True,exist_ok=False);prep=out/'preparation';prep.mkdir();sources={str(input_manifest):expected_input};admission=[];adapter=mod('static_surface_adapter',ROOT/'adapter.py')
 save(prep/'original_input_manifest.json',manifest)
 for rec,slot in zip(records,slots):
  prompt_hash=sha(ROOT/slot['prompt_file']);terminal=validate_capture_record(rec,slot,prompt_hash,generation);sid=rec['id'];where=prep/sid;where.mkdir()
  row={'id':sid,'slot':rec['slot'],'block':rec['block'],'representation':rec['representation'],'reasoning_effort':slot['reasoning_effort'],'model_id':rec['model_id'],'generation_status':terminal,'prompt_sha256':prompt_hash,'capture':rec,'strict':{'status':'generation_not_admitted'},'unique_block':{'status':'generation_not_admitted'}}
  for field,dest,cap in [('raw_text_path','raw.txt',1048576),('metadata_path','metadata.json',1048576)]:
   if rec.get(field) is None:
    if terminal in ['normal_stop','generation_length']:raise Infrastructure('completed missing '+field)
    continue
   source=pathlib.Path(rec[field]);source=source if source.is_absolute() else input_manifest.parent/source;source=source.resolve();hashkey='raw_text_sha256' if field=='raw_text_path' else 'metadata_sha256'
   if not source.is_file() or source.stat().st_size>cap or sha(source)!=rec.get(hashkey):raise Infrastructure(field+' source identity/bound')
   sources[str(source)]=rec[hashkey];(where/dest).write_bytes(source.read_bytes())
  if terminal in ['normal_stop','generation_length']:
   raw=(where/'raw.txt').read_bytes()
   row['raw_text_bytes']=len(raw)
   crosscheck_metadata(json_load(where/'metadata.json'),rec,raw)
   results,candidate=admit_both(raw,slot['representation'],adapter);row.update(results)
   if candidate is not None:
    (where/'payload.json').write_bytes(candidate['payload']);row['payload_file']=str((where/'payload.json').resolve());row['payload_sha256']=sha(where/'payload.json')
  save(where/'admission.json',row);admission.append(row)
 verify_freeze(expected_freeze)
 for source,h in sources.items():
  if sha(source)!=h:raise Infrastructure('input source changed during preparation')
 save(prep/'admissions.json',admission);save(prep/'source_hashes.json',sources)
 sealed={str(p.resolve()):sha(p) for p in sorted(prep.rglob('*')) if p.is_file()}
 seal={'state':'static_admission_complete_no_fitness','freeze_sha256':expected_freeze,'input_manifest_sha256':expected_input,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'model_calls':0,'policy_score_calls':0,'preparation_accounting':{'cpu_seconds':1+time.process_time()-cpu,'active_wall_seconds':1+time.monotonic()-start,'startup_allowance_seconds':1},'prepared_file_sha256':sealed,'source_sha256':sources,'rows':16,'output':str(out.resolve())}
 save(out/'preparation_seal.json',seal)
 return {'output':str(out.resolve()),'preparation_seal_sha256':sha(out/'preparation_seal.json'),'strict_admitted':sum(x['strict']['status']=='admitted' for x in admission),'unique_admitted':sum(x['unique_block']['status']=='admitted' for x in admission),'score_calls':0}

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--input-manifest',required=True);p.add_argument('--expected-input',required=True);p.add_argument('--expected-freeze',required=True);p.add_argument('--output',required=True);a=p.parse_args();print(json.dumps(prepare(a.input_manifest,a.expected_input,a.expected_freeze,a.output),indent=2))
