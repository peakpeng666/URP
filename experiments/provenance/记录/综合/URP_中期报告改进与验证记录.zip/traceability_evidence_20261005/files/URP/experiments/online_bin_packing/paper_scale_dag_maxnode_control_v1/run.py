"""Exactly one frozen64-node5000-item fixed resource control; no model/search."""
import time
START=time.monotonic();CPU=time.process_time()
import argparse,base64,datetime,hashlib,importlib.util,json,pathlib,resource,signal,sys
ROOT=pathlib.Path(__file__).resolve().parent;BASE=ROOT.parent;EVAL=BASE/'paper_scale_dag_evaluator_v1'
resource.setrlimit(resource.RLIMIT_AS,(2147483648,2147483648));resource.setrlimit(resource.RLIMIT_CPU,(90,90))
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(pathlib.Path(p).read_bytes())
def save(p,d):
 with pathlib.Path(p).open('x') as f:json.dump(d,f,indent=2,allow_nan=False);f.write('\n')
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
f=read(ROOT/'freeze.json');protocol=read(ROOT/'protocol.json')
def verify():
 for p,h in f['sha256'].items():
  if sha(p)!=h:raise RuntimeError('source hash mismatch '+p)
def accounting():
 usage=resource.getrusage(resource.RUSAGE_CHILDREN);now=datetime.datetime.now(datetime.timezone.utc)
 return {'supplement_cpu_seconds':1+time.process_time()+usage.ru_utime+usage.ru_stime,'supplement_monotonic_wall_seconds':1+time.monotonic()-START,'cumulative_cpu_upper_accounting':protocol['previous_cpu_conservative_seconds']+1+time.process_time()+usage.ru_utime+usage.ru_stime,'cumulative_elapsed_utc_seconds':(now-datetime.datetime.fromisoformat(protocol['original_phase_start_conservative_utc'])).total_seconds()}
def deadline(*_):raise TimeoutError('supplement active deadline')
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--expected-freeze',required=True);args=ap.parse_args()
 if sha(ROOT/'freeze.json')!=args.expected_freeze:raise ValueError('freeze identity')
 out=ROOT/'results';out.mkdir(exist_ok=False);errors=[];result={};dispatches=0
 signal.signal(signal.SIGALRM,deadline);signal.setitimer(signal.ITIMER_REAL,150)
 try:
  verify();budget=accounting()
  if budget['cumulative_cpu_upper_accounting']+62+30>600 or budget['cumulative_elapsed_utc_seconds']+92+30>900:raise RuntimeError('cumulative budget reservation insufficient')
  module('original_integrity',BASE/'math_dag_v1/src/integrity.py').verify(f['original_math_freeze_sha256'])
  sys.path.insert(0,str(EVAL/'src'));from runtime import request
  from schema import validate_program
  raw=(ROOT/'control.json').read_bytes();p=validate_program(raw);assert len(p.nodes)==64
  items=read(EVAL/'data/design_5000.json')['cases'][0]['items'];assert len(items)==5000
  req={'mode':'pack','program_json':raw.decode(),'items':items,'capacity':100};save(out/'request.json',req);dispatches=1
  obs=request(req);save(out/'observation.json',obs)
  assert obs['returncode']==0 and obs['termination'] is None and obs['error'] is None and obs['reaped'] and obs['cpu_evidence_complete']
  output=base64.b64decode(obs['raw_stdout_base64'],validate=True);b=obs['result'];assert json.loads(output)==b and hashlib.sha256(output).hexdigest()==obs['raw_output_sha256']
  assert b['limits']=={'RLIMIT_AS':[2147483648,2147483648],'RLIMIT_CPU':[60,60],'RLIMIT_FSIZE':[0,0],'RLIMIT_NOFILE':[32,32]}
  assert b['pid']==obs['pid'] and b['status']=='packing_returned' and b['phase']=='pack' and b['error'] is None
  assert b['program_sha256']==p.raw_sha256 and b['canonical_program_sha256']==p.canonical_sha256
  assert b['warnings']=={'events':[],'kinds':[],'complete':True,'incomplete_reason':None}
  pack=b['result'];checker=module('independent_checker',BASE/'paper_baseline_v1/src/checker.py');checked=checker.check_assignment(items,100,pack['assignment'],pack['used_bins'],pack['residuals'])
  assert pack['placements']==5000 and pack['assignment']==list(range(5000)) and pack['used_bins']==5000
  assert len(pack['feasible_counts'])==5000 and b['work_units']==pack['work_units']==25000000+64*sum(pack['feasible_counts'])<=1625000000
  assert b['numeric_intermediates']=={'completed_nodes':320000,'nan_elements':0,'positive_infinity_elements':0,'negative_infinity_elements':0}
  # Separate integer reconstruction; this does not call the solver/checker.
  loads=[0]*5000
  for item,label in zip(items,pack['assignment']):assert type(label)is int and 0<=label<5000;loads[label]+=item;assert loads[label]<=100
  assert sum(x>0 for x in loads)==5000 and pack['residuals']==[100-x for x in loads]
  historical=read(EVAL/'results/design5000_historical_design_5k_0_BAD.observation.json')['result']['result']
  assert all(pack[k]==historical[k] for k in ['assignment','residuals','used_bins','feasible_counts'])
  result={'status':'feasible_expected_policy','used_bins':checked['used_bins'],'L1':checked['L1'],'nodes':64,'placements':5000,'work_units':pack['work_units'],'maximum_work_units':1625000000,'work_fraction':pack['work_units']/1625000000,'score_elements':sum(pack['feasible_counts']),'completed_node_evaluations':b['numeric_intermediates']['completed_nodes'],'warning_events':0,'all_intermediates_finite':True,'independent_checker_passed':True,'independent_integer_reconstruction_passed':True,'known_policy_assignment_matches':True,'previous_BAD_assignment_and_feasibility_match':True,'worker_cpu_seconds':obs['worker_cpu_seconds'],'worker_wall_seconds':obs['wall_seconds'],'worker_peak_rss_kib':obs['worker_peak_rss_kib'],'assignment':pack['assignment'],'residuals':pack['residuals']}
 except Exception as e:errors.append(type(e).__name__+': '+str(e))
 finally:
  signal.setitimer(signal.ITIMER_REAL,30)
  try:verify();module('original_integrity_post',BASE/'math_dag_v1/src/integrity.py').verify(f['original_math_freeze_sha256']);save(out/'hashes_after.json',{p:sha(p) for p in f['sha256']});unchanged=True
  except Exception as e:errors.append('terminal:'+str(e));unchanged=False
  budget=accounting()
  if budget['cumulative_cpu_upper_accounting']>600 or budget['cumulative_elapsed_utc_seconds']>900:errors.append('cumulative budget exceeded')
  report={'passed':not errors,'errors':errors,'actual_supplemental_pack_dispatches':dispatches,'original_full_control_count_unchanged':15,'original_regression_count_unchanged':30,'new_independent_samples':0,'models_called':0,'source_and_old_results_unchanged':unchanged,'result':result,'budget':budget,'freeze_sha256':sha(ROOT/'freeze.json'),'limitation':'One64-nodefloatidentitychain ononehistoricalinstance; not a worst-casecost proof for all64-node DAGs; no extra algorithmoptimization'}
  save(out/'report.json',report);save(out/'completion_accounting.json',accounting());signal.setitimer(signal.ITIMER_REAL,0)
 print(json.dumps({**report,'result':{k:v for k,v in result.items() if k not in ['assignment','residuals']}},indent=2))
 return 0 if report['passed'] else 1
if __name__=='__main__':raise SystemExit(main())
