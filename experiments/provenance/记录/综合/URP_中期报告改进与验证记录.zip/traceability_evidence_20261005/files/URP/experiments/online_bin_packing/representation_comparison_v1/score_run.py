"""Offline240-slot bounded evaluation. No model calls or candidate Python execution."""
import time
START=time.monotonic()
import argparse,base64,datetime,hashlib,json,pathlib,resource,signal,sys
from fractions import Fraction
from scoring_admission import Infrastructure,json_load,save,sha,mod,verify_freeze,admit_both
ROOT=pathlib.Path(__file__).resolve().parent;BASE=ROOT.parent;EVALUATOR=BASE/'paper_scale_dag_evaluator_v1'
LIMITS={'RLIMIT_AS':[2147483648,2147483648],'RLIMIT_CPU':[60,60],'RLIMIT_FSIZE':[0,0],'RLIMIT_NOFILE':[32,32]}
PANELS=['main5000','development256','validation256'];METHODS=['BF','EOH']
class Budget:
 def __init__(self,debit=None,clock=None,cpu=None):
  self.debit=debit or {'cpu_seconds':0,'active_wall_seconds':0};self.clock=clock or time.monotonic;self.cpu=cpu or self.actual_cpu;self.t0=START if clock is None else self.clock();self.c0=0 if cpu is None else self.cpu()
 @staticmethod
 def actual_cpu():
  x=resource.getrusage(resource.RUSAGE_CHILDREN);return time.process_time()+x.ru_utime+x.ru_stime
 def totals(self):return {'cpu_seconds':1+self.debit['cpu_seconds']+self.cpu()-self.c0,'active_wall_seconds':1+self.debit['active_wall_seconds']+self.clock()-self.t0}
 def reserve(self):
  t=self.totals();return t['cpu_seconds']+62+40<=1800 and t['active_wall_seconds']+92+40<=2700

def fresh_ledger():return [{'panel':p,'instance':i,'slot':s,'id':f'slot_{s:02d}','status':'not_run','reason':'not_reached'} for p in PANELS for i in range(5) for s in range(1,17)]

def schedule(rows,programs,budget,dispatch,check,emit):
 halted=None;count=0
 for row in rows:
  if row['id'] not in programs:row['reason']='candidate_not_admitted';continue
  if halted:row['reason']='stopped_'+halted;continue
  if not budget.reserve():halted='budget';row['reason']='stopped_budget';continue
  row.update(status='dispatched',reason=None);count+=1;emit('start',row)
  try:
   obs=dispatch(row,programs[row['id']]);row.update(check(row,programs[row['id']],obs));emit('terminal',row)
  except Exception as e:
   row.update(status='infrastructure_failure',reason=type(e).__name__+': '+str(e)[:2000]);emit('terminal',row);halted='infrastructure'
 return count,halted

def checked(raw,items,obs):
 """Classify runtime resources separately from algorithm quality; verify saved solution."""
 from schema import validate_program
 p=validate_program(raw);n=len(items)
 if obs.get('reaped') is not True or obs.get('cpu_evidence_complete') is not True:raise Infrastructure('unreaped/incomplete CPU evidence')
 common={'worker_cpu_seconds':obs.get('worker_cpu_seconds'),'worker_wall_seconds':obs.get('wall_seconds'),'worker_peak_rss_kib':obs.get('worker_peak_rss_kib')}
 if obs.get('error') is not None:raise Infrastructure('worker transport: '+str(obs['error']))
 if obs.get('termination') in ['wall_timeout','wall_timeout_after_eof']:
  return {**common,'status':'resource_unresolved','reason':'worker_wall_limit','quality':None}
 if obs.get('termination') in ['output_limit','stderr_limit']:
  return {**common,'status':'diagnostic_unresolved','reason':obs['termination'],'quality':None}
 if obs.get('termination') is not None:raise Infrastructure('unknown termination')
 if obs.get('returncode') in [-9,-24]:
  return {**common,'status':'resource_unresolved','reason':'worker_signal_'+str(-obs['returncode'])+'_cause_not_fully_observed','quality':None}
 if obs.get('returncode')!=0:raise Infrastructure('unexpected worker exit '+str(obs.get('returncode')))
 b=obs.get('result');rawout=base64.b64decode(obs['raw_stdout_base64'],validate=True)
 if not isinstance(b,dict) or json.loads(rawout)!=b or len(rawout)!=obs['raw_output_bytes'] or hashlib.sha256(rawout).hexdigest()!=obs['raw_output_sha256']:raise Infrastructure('raw result identity')
 if b.get('limits')!=LIMITS or b.get('pid')!=obs['pid'] or b.get('program_sha256')!=p.raw_sha256 or b.get('canonical_program_sha256')!=p.canonical_sha256 or b.get('phase')!='pack':raise Infrastructure('worker identity/phase/limits')
 if type(b.get('work_units'))is not int or not 0<=b['work_units']<=1625000000:raise Infrastructure('work envelope')
 w=b.get('warnings',{})
 if set(w)!={'events','kinds','complete','incomplete_reason'} or len(w['events'])>12000 or len(w['kinds'])>32:raise Infrastructure('warning envelope')
 for event in w['events']:
  if type(event)is not list or len(event)!=3 or any(type(x)is not int for x in event) or not 0<=event[0]<n or not 0<=event[1]<len(p.nodes) or not 0<=event[2]<len(w['kinds']):raise Infrastructure('warning event')
 for kind in w['kinds']:
  if kind.get('category')!='RuntimeWarning' or kind.get('file')!='interpreter.py' or not isinstance(kind.get('message'),str) or len(kind['message'].encode())>1024:raise Infrastructure('warning kind')
 if b['status'] in ['numeric_invalid','resource_unresolved','diagnostic_unresolved']:
  if b.get('result') is not None or not isinstance(b.get('error'),dict):raise Infrastructure('failure envelope')
  return {**common,'status':b['status'],'reason':b['error'],'work_units':b['work_units'],'warning_events':len(w['events']),'quality':None}
 if b['status']!='packing_returned' or b.get('error') is not None or w['complete'] is not True or w['incomplete_reason'] is not None:raise Infrastructure('success status/warnings')
 result=b['result'];checker=mod('independent_packing_checker',BASE/'paper_baseline_v1/src/checker.py')
 try:c=checker.check_assignment(items,100,result['assignment'],result['used_bins'],result['residuals'])
 except ValueError as e:return {**common,'status':'checker_rejected','reason':str(e),'quality':None}
 counts=result['feasible_counts']
 if result['placements']!=n or len(counts)!=n or any(type(x)is not int or not 1<=x<=n for x in counts) or result['work_units']!=b['work_units'] or b['work_units']!=n*n+len(p.nodes)*sum(counts):raise Infrastructure('work/placement accounting identity')
 return {**common,'status':'feasible','reason':None,'used_bins':c['used_bins'],'L1':c['L1'],'assignment':result['assignment'],'residuals':result['residuals'],'work_units':b['work_units'],'score_elements':sum(counts),'warning_events':len(w['events']),'numeric_intermediates':b['numeric_intermediates']}

def review_gate(path,expected,seal_hash,admissions):
 if sha(path)!=expected:raise Infrastructure('review manifest hash')
 review=json_load(path)
 if review.get('preparation_seal_sha256')!=seal_hash or review.get('independent_of_candidate_fitness') is not True or review.get('policy_execution_performed') is not False or review.get('review_scope')!='public_description_and_static_code_only':raise Infrastructure('pre-fitness static review gate')
 if not isinstance(review.get('reviewer_identity'),str) or not review['reviewer_identity'].strip():raise Infrastructure('independent reviewer identity')
 rows=review['records']
 if len(rows)!=16 or [x.get('id') for x in rows]!=[x['id'] for x in admissions]:raise Infrastructure('16static review slots')
 for r,a in zip(rows,admissions):
  admitted=a['unique_block']['status']=='admitted';expected_hash=a['capture'].get('raw_text_sha256')
  if r.get('raw_text_sha256')!=expected_hash or r.get('payload_sha256')!=a.get('payload_sha256'):raise Infrastructure('review source binding')
  allowed=['consistent','mismatch','undetermined'] if admitted else ['not_applicable','undetermined']
  if r.get('classification') not in allowed or not isinstance(r.get('rationale'),str) or not r['rationale'].strip():raise Infrastructure('static classification/rationale')
 return review

def summarize(rows,admissions,baselines,review):
 groups=[]
 for admission in admissions:
  for panel in PANELS:
   rr=[r for r in rows if r['id']==admission['id'] and r['panel']==panel];valid=[x for x in rr if x['status']=='feasible'];g={'id':admission['id'],'panel':panel,'feasible':len(valid),'denominator':5,'strict_admitted':admission['strict']['status']=='admitted','unique_admitted':admission['unique_block']['status']=='admitted'}
   if len(valid)==5:
    total=sum(x['used_bins'] for x in valid);lb=sum(x['L1'] for x in valid);g.update(bins=[x['used_bins'] for x in valid],sum_bins=total,sum_L1=lb,paper_percent_excess_exact=str(Fraction(100*(total-lb),lb)),paper_percent_excess=float(Fraction(100*(total-lb),lb)),exact_mean_L1_over_bins=str(sum((Fraction(x['L1'],x['used_bins']) for x in valid),Fraction())/5))
    for method in METHODS:
     refs=[x for x in baselines if x['panel']==panel and x['method']==method];base=sum(x['used_bins'] for x in refs);g[method]={'bins':[x['used_bins'] for x in refs],'sum_bins':base,'delta_sum_bins':total-base,'instance_deltas':[x['used_bins']-y['used_bins'] for x,y in zip(valid,refs)],'different_assignments':[sum(a!=b for a,b in zip(x['assignment'],y['assignment'])) for x,y in zip(valid,refs)]}
   groups.append(g)
 cells=[]
 for rep in ['dag','python']:
  for effort in ['low','high']:
   aa=[a for a in admissions if a['representation']==rep and a['reasoning_effort']==effort];ids={a['id'] for a in aa};gg=[g for g in groups if g['id'] in ids and g['panel']=='main5000'];cells.append({'representation':rep,'reasoning_effort':effort,'denominator':4,'generation_normal_stop_nonempty':sum(a['generation_status']=='normal_stop' and a.get('raw_text_bytes',0)>0 for a in aa),'generation_length':sum(a['capture'].get('finish_reasons')==['length'] for a in aa),'nonempty_terminal_texts':sum(a.get('raw_text_bytes',0)>0 for a in aa),'intact_terminal_captures':sum(a['generation_status'] in ['normal_stop','generation_length'] for a in aa),'strict_admitted':sum(a['strict']['status']=='admitted' for a in aa),'unique_admitted':sum(a['unique_block']['status']=='admitted' for a in aa),'main_complete_feasible':sum(g['feasible']==5 for g in gg),'main_complete_strict_feasible':sum(g['feasible']==5 and g['strict_admitted'] for g in gg),'no_mean_over_incomplete_candidates':True})
 canonical=[a['unique_block'].get('canonical_program_sha256') for a in admissions if a['unique_block']['status']=='admitted'];structural=[]
 for a in admissions:
  if a['unique_block']['status']=='admitted':
   p=json_load(pathlib.Path(a['payload_file']));p.pop('description');structural.append(hashlib.sha256(json.dumps(p,sort_keys=True,separators=(',',':')).encode()).hexdigest())
 return {'groups':groups,'cells':cells,'distinct_canonical_programs_including_description':len(set(canonical)),'distinct_IRs_excluding_description':len(set(structural)),'admitted_generation_slots':len(canonical),'description_reviews':review['records'],'duplicates_not_independent_algorithm_samples':True}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',required=True);ap.add_argument('--expected-freeze',required=True);ap.add_argument('--expected-preparation',required=True);ap.add_argument('--review-manifest',required=True);ap.add_argument('--expected-review',required=True);a=ap.parse_args()
 resource.setrlimit(resource.RLIMIT_AS,(2147483648,2147483648));resource.setrlimit(resource.RLIMIT_CPU,(300,300));sys.dont_write_bytecode=True
 out=pathlib.Path(a.output).resolve();sealpath=out/'preparation_seal.json'
 if sha(sealpath)!=a.expected_preparation:raise Infrastructure('preparation seal identity')
 seal=json_load(sealpath)
 if seal['freeze_sha256']!=a.expected_freeze or seal['policy_score_calls']!=0:raise Infrastructure('preparation provenance')
 admissions=json_load(out/'preparation/admissions.json');review=review_gate(a.review_manifest,a.expected_review,a.expected_preparation,admissions)
 sources={**seal['source_sha256'],**seal['prepared_file_sha256'],str(sealpath):a.expected_preparation,str(pathlib.Path(a.review_manifest).resolve()):a.expected_review}
 def verify():
  f=verify_freeze(a.expected_freeze)
  for path,h in sources.items():
   if sha(path)!=h:raise Infrastructure('sealed input/review changed: '+path)
  return f
 verify();results=out/'scores';results.mkdir(exist_ok=False);save(results/'static_review.json',review);rows=fresh_ledger();save(results/'initial_ledger.json',rows)
 tests=json_load(ROOT/'score_tests_results.json');debit={'cpu_seconds':seal['preparation_accounting']['cpu_seconds']+tests['budget']['cpu_seconds'],'active_wall_seconds':seal['preparation_accounting']['active_wall_seconds']+tests['budget']['active_wall_seconds']};budget=Budget(debit);errors=[];baselines=[];dispatches=0;halted=None;summary={}
 events=(results/'events.jsonl').open('x')
 def emit(kind,row):events.write(json.dumps({'event':kind,'row':row},allow_nan=False)+'\n');events.flush()
 def alarm(*_):raise TimeoutError('active scoring deadline;40secondfinalreserve')
 signal.signal(signal.SIGALRM,alarm);signal.setitimer(signal.ITIMER_REAL,max(.01,2659-debit['active_wall_seconds']-(time.monotonic()-START)))
 try:
  evaluator_freeze=json_load(EVALUATOR/'freeze.json');mod('original_integrity',BASE/'math_dag_v1/src/integrity.py').verify(evaluator_freeze['original_math_freeze_sha256'])
  adapter=mod('score_static_adapter',ROOT/'adapter.py');programs={}
  for admission in admissions:
   if admission['generation_status'] not in ['normal_stop','generation_length']:continue
   raw=(out/'preparation'/admission['id']/'raw.txt').read_bytes();check,candidate=admit_both(raw,admission['representation'],adapter)
   if any(check[metric]!=admission[metric] for metric in ['strict','unique_block']):raise Infrastructure('admission replay changed')
   if candidate is not None:
    payload=(out/'preparation'/admission['id']/'payload.json').read_bytes()
    if payload!=candidate['payload']:raise Infrastructure('lowering replay changed')
    programs[admission['id']]=payload
  data={'main5000':[c['items'] for c in json_load(EVALUATOR/'data/design_5000.json')['cases']],'development256':[c['items'] for c in json_load(EVALUATOR/'data/regression_development_256.json')['cases']],'validation256':[c['items'] for c in json_load(EVALUATOR/'data/regression_validation_256.json')['cases']]}
  sys.path.insert(0,str(EVALUATOR/'src'));runtime=mod('paper_scale_runtime',EVALUATOR/'src/runtime.py')
  for panel in PANELS:
   for i,items in enumerate(data[panel]):
    if len(items)!=(5000 if panel=='main5000' else 256):raise Infrastructure('data length')
    for method in METHODS:
     prefix='design5000_historical_design_5k' if panel=='main5000' else 'regression256_'+('development' if panel=='development256' else 'validation');path=EVALUATOR/f'results/{prefix}_{i}_{method}.observation.json';obs=json_load(path);raw=(EVALUATOR/f'programs/{method}.json').read_bytes();val=checked(raw,items,obs)
     if val['status']!='feasible':raise Infrastructure('saved baseline failed independentcheck')
     baselines.append({'panel':panel,'instance':i,'method':method,'source':str(path),'source_sha256':sha(path),**val})
  save(results/'baseline_rechecks.json',baselines)
  def dispatch(row,raw):
   verify();items=data[row['panel']][row['instance']];request={'mode':'pack','program_json':raw.decode(),'items':items,'capacity':100};stem=f"{row['panel']}_{row['instance']}_{row['id']}";save(results/(stem+'.request.json'),request);row['runtime_request_attempted']=True;obs=runtime.request(request);save(results/(stem+'.observation.json'),obs);row['observation_file']=str(results/(stem+'.observation.json'));row['worker_pid_observed']=obs.get('pid');return obs
  dispatches,halted=schedule(rows,programs,budget,dispatch,lambda row,raw,obs:checked(raw,data[row['panel']][row['instance']],obs),emit)
  if halted=='infrastructure':errors.append('infrastructure_stop')
  summary=summarize(rows,admissions,baselines,review)
 except Exception as e:errors.append(type(e).__name__+': '+str(e))
 finally:
  signal.setitimer(signal.ITIMER_REAL,40)
  for row in rows:
   if row['status']=='dispatched':row.update(status='infrastructure_failure',reason='interrupted_dispatch')
   elif row['reason']=='not_reached':row['reason']='stopped_infrastructure'
  # Recover actual dispatched count even if an asynchronous deadline interruptedschedule.
  dispatches=sum(row['status']!='not_run' for row in rows)
  try:frozen=verify();save(results/'hashes_after.json',{path:sha(path) for path in {**frozen['sha256'],**sources}});source_ok=True
  except Exception as e:errors.append('terminalintegrity:'+str(e));source_ok=False
  totals=budget.totals()
  if totals['cpu_seconds']>1800 or totals['active_wall_seconds']>2700:errors.append('aggregate_budget_exceeded')
  report={'state':'stopped_infrastructure' if errors else ('stopped_budget' if halted=='budget' else 'terminal'),'all240_feasible':all(row['status']=='feasible' for row in rows),'errors':errors,'scores':rows,'summary':summary,'generation_admission':admissions,'dispatch_attempts':dispatches,'runtime_requests':sum(row.get('runtime_request_attempted',False) for row in rows),'workers_observed':sum(row.get('worker_pid_observed') is not None for row in rows),'saved_baseline_rechecks':len(baselines),'new_model_calls':0,'policy_replays':0,'source_hashes_unchanged':source_ok,'budget':totals,'budget_debit_admission_and_tests':debit,'freeze_sha256':a.expected_freeze,'preparation_sha256':a.expected_preparation,'review_sha256':a.expected_review,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'interpretation':'Partialresource/budget outcomes are missingquality, notalgorithmfailure; descriptionmismatch/undetermined didnotfilter; no prefixqualitygate; sameinstance/duplicateIR notindependent samples'}
  save(results/'report.json',report);events.close();save(results/'completion_accounting.json',budget.totals());signal.setitimer(signal.ITIMER_REAL,0)
 print(json.dumps({'state':report['state'],'dispatches':dispatches,'budget':budget.totals(),'errors':errors},indent=2));return 0 if not errors else 1
if __name__=='__main__':raise SystemExit(main())
