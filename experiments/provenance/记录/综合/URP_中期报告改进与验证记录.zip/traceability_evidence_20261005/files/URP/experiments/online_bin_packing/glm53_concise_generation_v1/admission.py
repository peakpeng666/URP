"""Strict source-envelope admission and unchanged mathematical schema; no repairs."""
import hashlib,json,pathlib
ROOT=pathlib.Path(__file__).resolve().parent

def admit(manifest_path,expected,extract,validate):
 p=pathlib.Path(manifest_path);raw=p.read_bytes()
 if len(raw)>100000 or hashlib.sha256(raw).hexdigest()!=expected:raise ValueError('manifest hash/size')
 from schema import strict_json
 records=strict_json(raw)['records'];slots=json.loads((ROOT/'protocol.json').read_text())['generation_slots']
 if len(records)!=2 or [r.get('id') for r in records]!=[s['id'] for s in slots]:raise ValueError('exact two ordered terminal slots required')
 programs={};rows=[]
 for r,s in zip(records,slots):
  if r.get('terminal') is not True or r.get('status') not in ['completed','generation_failed','not_run']:raise ValueError('terminal slot status')
  if r.get('cli_version')!='1.18.34':raise ValueError('CLI version binding')
  if r.get('model_id')!=s['model_id'] or r.get('prompt_sha256')!=s['prompt_sha256']:raise ValueError('model/prompt binding')
  if r.get('payload_provenance')!='OpenCode JSON part.text' or r.get('physical_http_attempts_observed') is not None:raise ValueError('payload provenance/count')
  if r.get('logical_cli_requests') not in [0,1]:raise ValueError('logical request count')
  row=dict(r)
  if r['status']!='completed':row['admission']='not_admitted';rows.append(row);continue
  if r.get('logical_cli_requests')!=1 or r.get('cli_exit_code')!=0 or r.get('completed_normally') is not True or r.get('tool_event_seen') is not False or r.get('model_messages')!=1 or r.get('truncated') is not False:raise ValueError('generation success envelope')
  if r.get('steps')!=2 or r.get('model_options')!={'reasoning_effort':'low','max_tokens':16384} or r.get('max_wall_seconds')!=480 or r.get('outer_retries')!=0:raise ValueError('generation settings binding')
  q=pathlib.Path(r['raw_text_path']);q=q if q.is_absolute() else p.parent/q
  if not q.is_file() or q.stat().st_size>1048576:raise ValueError('raw source absent/too large')
  text=q.read_bytes()
  if hashlib.sha256(text).hexdigest()!=r.get('raw_text_sha256'):raise ValueError('raw text hash mismatch')
  try:
   body,kind=extract(text);prog=validate(body);programs[r['id']]=body
   row.update(admission='admitted',extraction=kind,program_sha256=prog.raw_sha256,canonical_program_sha256=prog.canonical_sha256,nodes=len(prog.nodes),constants=len(prog.constants))
  except (ValueError,UnicodeError,RecursionError) as e:row.update(admission='structural_rejected',reason=str(e)[:1000])
  rows.append(row)
 return programs,rows
