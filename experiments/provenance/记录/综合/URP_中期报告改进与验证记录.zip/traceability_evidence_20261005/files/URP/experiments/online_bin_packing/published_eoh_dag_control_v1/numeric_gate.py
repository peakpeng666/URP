"""Fixed numerical data only: compare the trusted fixed formula to a fixed DAG."""
import hashlib,json,os,pathlib,resource,sys,warnings
ROOT=pathlib.Path(__file__).resolve().parent
BASE=ROOT.parent
sys.path.insert(0,str(BASE/'math_dag_v1/src'))
from runtime import require_limits,limits
require_limits()
import numpy as np
from schema import validate_program
from interpreter import evaluate,WorkBudget
from warnings_log import WarningLog
sys.path.insert(0,str(BASE/'published_eoh_formula_v1/src'))
from formula import score_trace
assert np.__version__=='2.3.5'
program=validate_program((ROOT/'published_eoh.json').read_bytes())
work=WorkBudget()
named={0:'diff',1:'exp',2:'sqrt',4:'ulti',5:'comb',10:'adjust',12:'denominator',13:'hybrid_exp',14:'scores'}
rows=[];failures=[];domain_rows=[];reference_warnings=[];dag_warnings=[];case_id=0

def digest(a):return hashlib.sha256(a.tobytes()).hexdigest()
def equal(a,b):return a.dtype==b.dtype and a.shape==b.shape and a.tobytes()==b.tobytes()
for capacity in (100,500):
    start=len(rows);elements=0;warning_count=0
    for iv in range(1,101):
        item=np.int32(iv);ascending=np.arange(iv,capacity+1,dtype=np.int64)
        baseline=None
        for variant,bins in [('ascending',ascending),('descending',ascending[::-1].copy()),('duplicated',np.repeat(ascending,2))]:
            before=bins.tobytes()
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter('always')
                with np.errstate(divide='warn',over='warn',invalid='warn',under='ignore'):
                    reference=score_trace(item,bins)
            ref_events=[{'case':case_id,'category':w.category.__name__,'file':pathlib.Path(w.filename).name,'line':w.lineno,'message':str(w.message)} for w in caught]
            reference_warnings.extend(ref_events)
            log=WarningLog()
            with log:actual=evaluate(program,item,bins,work,log,case_id,trace=True)
            for placement,node,kind in log.events:
                dag_warnings.append({'case':placement,'node':node,**log.kinds[kind]})
            s=actual['scores'];r=reference['scores']
            matched=[name for index,name in named.items() if equal(np.asarray(actual['values'][index]),reference[name])]
            first=int(np.flatnonzero(r==np.max(r))[0]);arg=int(np.argmax(s))
            metamorphic= True
            if variant=='ascending':baseline=s.copy()
            elif variant=='descending':metamorphic=equal(s,baseline[::-1])
            else:metamorphic=equal(s,np.repeat(baseline,2)) and arg%2==0
            expected_warnings=1 if capacity==500 else 0
            warning_ok=(len(caught)==len(log.events)==expected_warnings and all(w['category']=='RuntimeWarning' and w['file']=='formula.py' and w['message']=='overflow encountered in multiply' for w in ref_events) and all(e[1]==12 for e in log.events) and all(k['category']=='RuntimeWarning' and k['message']=='overflow encountered in multiply' for k in log.kinds) and log.payload()['complete'])
            ok=(len(matched)==len(named) and equal(s,r) and np.all(np.isfinite(s)) and arg==first and bins.tobytes()==before and metamorphic and warning_ok)
            row={'case':case_id,'capacity':capacity,'item':iv,'variant':variant,'length':len(bins),'passed':bool(ok),'score_sha256':digest(s),'reference_sha256':digest(r),'first_argmax':arg,'reference_first_argmax':first,'named_intermediates_matched':len(matched),'reference_warning_count':len(caught),'dag_warning_count':len(log.events),'denominator_inf_count':int(np.isposinf(reference['denominator']).sum())}
            rows.append(row)
            if not ok:failures.append({'case':case_id,'matched':matched,'warning_ok':warning_ok,'metamorphic':metamorphic})
            elements+=len(bins);warning_count+=len(caught);case_id+=1
    domain_rows.append({'capacity':capacity,'unique_feasible_pairs':sum(capacity-i+1 for i in range(1,101)),'vector_cases':len(rows)-start,'compared_score_elements':elements,'reference_warning_events':warning_count,'dag_warning_events':warning_count,'all_cases_passed':all(r['passed'] for r in rows[start:])})
result={'passed':not failures,'numpy_version':np.__version__,'python_version':sys.version,'node_count':len(program.nodes),'constant_count':len(program.constants),'node_types':list(program.types),'named_intermediates':named,'domains':domain_rows,'failures':failures,'work_units':work.used,'numeric_intermediates':work.numeric_counts,'cases':rows,'reference_warnings':reference_warnings,'dag_warnings':dag_warnings}
print(json.dumps({'status':'completed_finite' if not failures else 'infrastructure_failure','pid':os.getpid(),'limits':limits(),'result':result},separators=(',',':'),allow_nan=False))
