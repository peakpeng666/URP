# 论文规模5000物品：独立版本DAG评价器验证

## 结论

已建立并实际验证独立的5000物品评价器，可以用于后续另行冻结、另行授权的有界数学DAG候选评价。没有调用模型，没有恢复已暂停的单反馈，也没有进行16槽候选试验。

完整5×5000历史设计集：发表EoH合计10007箱，BF10335箱，EoH少328箱（相对BF约3.17%）；递增残量反例25000箱。15/15完整运行可行，0自然失败、0警告。历史BF/EoH逐物品分配、残量和每步可行箱数量完全一致，不只是总箱数碰巧一致。

|实例|BF|发表EoH|递增残量反例|EoH−BF|
|---|---:|---:|---:|---:|
|0|2094|2025|5000|-69|
|1|2059|1994|5000|-65|
|2|2057|1995|5000|-62|
|3|2067|2001|5000|-66|
|4|2058|1992|5000|-66|

论文口径主指标为100×(sum箱数−sumL1)/sumL1；本组sumL1=9939，L1为下界，不是已求得最优：
- BF：3.984304256%（精确分数13200/3313）
- EOH：0.684173458%（精确分数6800/9939）
- BAD：151.534359594%（精确分数1506100/9939）

mean(L1/箱数)另存精确分数，不能与上述论文口径互换。没有显著性、总体优越性或模型能力结论。

## 版本改变与工作量合同

- 原math_dag_v1及所有原冻结结果未修改。新代码、数据、结果全部在paper_scale_dag_evaluator_v1
- interpreter.py仅改变pack长度上限256→5000，WorkBudget默认/最大5000000→1625000000。schema.py及warnings_log.py逐字节未变
- worker资源改为60CPU秒/90wall秒/2GiB；其余原输入输出边界保持：stdin100000B、stdout400000B、stderr16384B、warning最多12000事件/32类型/单条1024B
- 最大工作量推导：n²次可行性扫描 + 节点数×sum(每步可行箱数) ≤ n²×(节点数+1) ≤ 5000²×65 = 1,625,000,000。旧500万上限不能用于5000规模，未把旧资源拒绝当算法失败
- 64节点/16常量/32768字节，算子顺序、dtype、整数中间量abs≤1e6、eager-where、最终有限值、全部预分配空箱、最大分数、first-argmax均保持原语义
- 只保存分配、残量、每步可行箱数及工作量/warnings/原始stdout证据，不保存每一步全部评分向量。不得把评分元素计为独立样本

## 回归与独立验收

- 原可信手写24项单元测试通过；新版本24项通过。新测试只把变更的最大work非法值5000001改为1625000001、非法长度257改为5001，其余数值/类型/精度/警告测试原样保留，差异见source_diff.json
- 同三固定控制，在原开发和验证10×256面板上执行30次回归；全部assignment/residuals/used_bins/feasible_counts/work_units/placements与保存的原运行精确相等
- 15个完整控制均经独立checker验收；之后另用整数负载重算45份保存分配，45/45通过，复核未重新运行策略
- BF/EoH的10个完整结果与旧paper_design_panel_v1逐项一致；BAD全部分配[0..4999]，符合其固定递增容量公式偏好空箱的代数解释
- 所有314项冻结源码/数据/参考结果前后hash一致；原Python、NumPy和依赖清单还在全部评分后再次用原integrity.verify完整核查通过

## 历史数据与来源

- source：paper_baseline_v1/data/historical_numeric.json；SHA256 97b77d4d5f98a32b46240e18a85c99d39f5fd5cfea4df83782abe330a7b21fd5
- set：historical_design_5k，5条完整5000项，容量100。逐条紧凑JSON数组hash与paper_design_panel_v1/protocol_frozen.json一致，并完整保存于data/design_5000.json
- 历史数据commit e4b5ddba03b2b88025747e11c6049f8b529a4368；未另造seed或重采样。来源未提供可确认的历史随机seed，复现以物化字节及hash为准
- 固定发表公式commit 472545785c936dcfc863d2bc0d6109cf23c7ce62，examples/bp_online/evaluation/heuristic_original_EoH_paper.py；来源源码SHA256 f3d50f0e81ca061a0377b9fb61b75cf16ecde9f091876db0d8baca8323655995。该后期仓库文件标为original paper，不证明它在2024已以相同字节存在
- 实际执行的是已审查数学DAG及可信解释器，没有运行任意生成Python或作者原Python字节

## 成本与预算
- 主数值阶段（含1秒保守启动计费）：CPU 19.354665s；activewall 19.314814s
- 保存分配审计：CPU 0.137826s、wall 0.140299s；最终完整依赖复核：CPU 0.247779s、wall 0.247797s
- 加两次额外启动各1秒后保守合计CPU 21.740270s；主阶段启动至本报告含间隔UTC约191.467s，均低于600CPU/900activewall总预算
- 完整实例最慢worker：CPU 1.342486s、wall 1.344526s；最大worker峰值RSS 46520 KiB（含解释器）
- 顺序派发；下个worker最坏预留62CPU秒/92wall秒，另留30秒终止保存；主进程90CPU秒、2GiB，外层900秒watchdog。不是cgroup级聚合硬限额
- 15次完整装箱 + 30次256策略回归 + 2个单元测试worker，计数分开；没有新增独立数据实例、模型调用、付费模型行为、上传或推送
- 静态准备始于2026-10-05 06:09:36 UTC，另记preparation_accounting.json；准备CPU未单独计量，没有混称全部任务CPU

## 教学解释与下一步边界

这完成的是教师P3原5000设计规模的评价基础与固定组件复验。此前同5条前256项上EoH555箱对BF546较差；恢复完整长度后EoH10007对BF10335更好。前缀不代表完整历史，且两种长度不是独立样本；不能把这当普遍长度因果律。

后续表示×推理试验可固定此版本、相同操作语义及这批5000数据，再单独冻结候选来源和预算。当前三个固定控制能在限额内完成，不保证任意64节点图一定在60秒内结束，也不证明完整Python搜索表达力或通用恶意代码隔离。长图和高警告程序仍可能明确资源/诊断失败，必须照实记录。

尚未完成新的模型质量试验、thought/code多代演化、原论文完整查询预算或未见确认。已暂停的单反馈维持暂停；本任务至报告停止。

## 可追溯文件

- protocol.json、freeze.json、source_diff.json：评分前冻结、语义差异和界限
- src/runtime.py、src/worker.py、src/interpreter.py：独立新版本
- data/design_5000.json：完整五条已核验历史序列
- results/report.json、final_summary.json：45条终态与完整规模指标
- results/*observation.json：子进程原始输出、limits、warnings、CPU/RSS
- results/independent_audit.json：整数负载验收
- results/runtime_post_integrity.json、hashes_after.json：运行库/全部冻结来源后验核查
