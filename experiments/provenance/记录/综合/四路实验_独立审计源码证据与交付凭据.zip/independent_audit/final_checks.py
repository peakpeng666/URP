import json,pathlib,hashlib,time
root=pathlib.Path('/workspace/shared');out=root/'audit_four_numeric_20261007';start=time.process_time();res={}
for name in ['fleet','turn_routes','selector_sizes','search_budget']:
 r=root/(name+'_20261007');sf=r/('SHA256SUMS' if name=='fleet' else 'SHA256SUMS.txt');lines=sf.read_text().splitlines();ok=[]
 for line in lines:
  if not line.strip():continue
  h,p=line.split(None,1);p=p.lstrip('*').strip();assert hashlib.sha256((r/p).read_bytes()).hexdigest()==h,(name,p);ok.append(p)
 res[name]={'verified_file_count':len(ok),'sha256sums_file':sf.name,'sha256sums_sha256':hashlib.sha256(sf.read_bytes()).hexdigest()}
for name,rel in [('fleet','REPORT.zh.md'),('turn_routes','README.md'),('selector_sizes','REPORT_ZH.txt'),('search_budget','reports/REPORT_ZH.md')]:res[name]['report_file']=rel;res[name]['report_sha256']=hashlib.sha256((root/(name+'_20261007')/rel).read_bytes()).hexdigest()
r=root/'selector_sizes_20261007';raw=[json.loads(l) for l in (r/'RAW_PREDICTIONS.jsonl').read_text().splitlines()];ss=[x for x in raw if x['track']=='family_holdout' and x['groups_per_training_family']==8 and x['seed']==2026100701 and x['family']=='normal_50_15' and x['order']=='ascending'];assert len(ss)==6 and all(x['selected_index']==0 and all('bimodal_20_30_70_80' in n and n.endswith('__ascending') for n in x['neighbors']) for x in ss);delta=[x['selected_bins']-x['subset_sbs_bins'] for x in ss];assert max(delta)==622
res['selector_sizes']['posthoc_normal_ascending_mean_harm']=sum(delta)/6;res['selector_sizes']['distinct_subsets']=len({tuple(x['train_ids']) for x in json.loads((r/'SPLITS.json').read_text())});assert res['selector_sizes']['distinct_subsets']==427
res['verification_cpu_seconds']=time.process_time()-start;(out/'final_deliverable_hash_receipt.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res,indent=2))
