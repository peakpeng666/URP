import json,pathlib,hashlib,math,random,collections,itertools,statistics,time,resource,csv
resource.setrlimit(resource.RLIMIT_CPU,(100,105));t0=time.process_time();R=pathlib.Path('/workspace/shared/search_budget_20261007');O=pathlib.Path(__file__).parent
load=lambda p:json.loads((R/p).read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cfg=load('freeze/PROTOCOL.json');freeze=load('freeze/PRE_RUN_FREEZE.json')
assert all(sha(R/p)==h for p,h in freeze['sha256'].items())
for s in load('reports/SOURCE_MANIFEST.json')['legacy_files']:assert (R/s['source']).read_bytes()==(R/s['copy']).read_bytes()
schedule=load('freeze/SCHEDULE.json');raw=[json.loads(l) for l in (R/'raw/TRAJECTORIES.jsonl').read_text().splitlines()];assert len(raw)==len(schedule)==288
assert all(all(r[k]==s[k] for k in s) for r,s in zip(raw,schedule));assert len({(r['geometry_id'],r['demand_mode'],r['search_seed'],r['algorithm']) for r in raw})==288
assert freeze['frozen_utc']<min(r['started_utc'] for r in raw)
instances={r['input_file']:load(r['input_file']) for r in raw};assert len(instances)==24
for r in raw:assert sha(R/r['input_file'])==r['input_sha256']

def check(I,out):
 seen=[];edges=[]
 for rt in out['routes']:
  assert rt[0]==rt[-1]==0 and len(rt)>2 and 0 not in rt[1:-1]
  assert sum(I['demands'][j] for j in rt[1:-1])<=I['capacity'];seen+=rt[1:-1]
  edges.extend(math.dist(I['coordinates'][a],I['coordinates'][b]) for a,b in zip(rt,rt[1:]))
 assert sorted(seen)==list(range(1,len(I['coordinates'])))
 val=math.fsum(edges);assert abs(val-out['reported_cost'])<1e-8
 return val

class End(Exception):pass
# Independent implementation of the frozen four operator combinations. No author module imports.
def replay(I,pair,seed,checkpoints):
 coords=I['coordinates'];q=I['demands'];n=len(coords)-1;cap=I['capacity'];dm=[[math.hypot(a[0]-b[0],a[1]-b[1]) for b in coords] for a in coords]
 count=0;kinds={'savings':0,'removal':0,'insertion':0};best=None;cost=None;started=done=improved=edges=0;receipts={};tr=[]
 def tick(kind):
  nonlocal count
  if count in checkpoints and count not in receipts:
   receipts[count]={'output':{'routes':[[0]+rt+[0] for rt in best],'reported_cost':cost},'delta_by_kind':kinds.copy(),'iterations_started':started,'iterations_completed':done,'accepted_improvements':improved,'objective_edges':edges}
  if count==max(checkpoints):raise End()
  count+=1;kinds[kind]+=1
 def distance(rs):
  nonlocal edges
  es=[dm[a][b] for rt in rs for a,b in zip([0]+rt,rt+[0])];edges+=len(es);return math.fsum(es)
 routes={j:[j] for j in range(1,n+1)};owner={j:j for j in routes};loads={j:q[j] for j in routes};sav=[]
 for i in range(1,n+1):
  for j in range(i+1,n+1):tick('savings');sav.append((-(dm[0][i]+dm[0][j]-dm[i][j]),i,j))
 for value,i,j in sorted(sav):
  a,b=owner[i],owner[j]
  if value>=0 or a==b or loads[a]+loads[b]>cap:continue
  ra,rb=routes[a],routes[b]
  if i not in (ra[0],ra[-1]) or j not in (rb[0],rb[-1]):continue
  ra=ra if ra[-1]==i else ra[::-1];rb=rb if rb[0]==j else rb[::-1];routes[a]=ra+rb;loads[a]+=loads[b];del routes[b];del loads[b]
  for node in routes[a]:owner[node]=a
 best=[routes[k] for k in sorted(routes)];cost=distance(best);baseline={'routes':[[0]+r+[0] for r in best],'reported_cost':cost}
 def seed_for(kind,k):return int.from_bytes(hashlib.sha256(f'{seed}/{kind}/{k}'.encode()).digest()[:8],'big')
 try:
  for iteration in itertools.count():
   started+=1;k=random.Random(seed_for('q',iteration)).randint(min(n,max(2,math.ceil(.1*n))),min(n,max(2,math.ceil(.1*n),math.ceil(.3*n))))
   rs=[rt[:] for rt in best]
   if pair[0]=='random':
    removed=random.Random(seed_for('removal',iteration)).sample(sorted(j for rt in rs for j in rt),k);ss=set(removed);rs=[[j for j in rt if j not in ss] for rt in rs]
   else:
    removed=[]
    for _ in range(k):
     cand=[]
     for a,rt in enumerate(rs):
      for b,node in enumerate(rt):
       left=rt[b-1] if b else 0;right=rt[b+1] if b+1<len(rt) else 0;tick('removal');v=dm[left][node]+dm[node][right]-dm[left][right];cand.append((-v,node,a,b))
     _,node,a,b=min(cand);removed.append(node);rs[a].pop(b)
   rs=[rt for rt in rs if rt];loads=[sum(q[j] for j in rt) for rt in rs];left=set(removed)
   while left:
    choices=[]
    for node in sorted(left):
     opts=[]
     for a,rt in enumerate(rs):
      if loads[a]+q[node]>cap:continue
      positions=[]
      for b in range(len(rt)+1):
       bef=rt[b-1] if b else 0;aft=rt[b] if b<len(rt) else 0;tick('insertion');v=dm[bef][node]+dm[node][aft]-dm[bef][aft];positions.append((v,a,b))
      opts.append(min(positions))
     if q[node]<=cap:tick('insertion');opts.append((dm[0][node]+dm[node][0],len(rs),0))
     opts.sort();v,a,b=opts[0]
     key=(v,node,a,b) if pair[1]=='cheapest' else (-(opts[1][0]-v if len(opts)>1 else math.inf),v,node,a,b)
     choices.append((key,node,a,b))
    _,node,a,b=min(choices)
    if a==len(rs):rs.append([node]);loads.append(q[node])
    else:rs[a].insert(b,node);loads[a]+=q[node]
    left.remove(node)
   value=distance(rs);done+=1;accepted=value<cost-1e-9
   if accepted:best=rs;cost=value;improved+=1
   tr.append({'iteration':iteration,'q':k,'candidate_cost':value,'accepted':accepted,'incumbent_cost':cost,'deltas':count})
 except End:pass
 return baseline,receipts,tr

start_replay=time.process_time();traces=0
for pos,r in enumerate(raw):
 assert r['status']=='executed' and r['stop_reason']=='delta_budget' and r['error'] is None and r['missing_budgets']==[]
 I=instances[r['input_file']];check(I,r['baseline'])
 baseline,cps,tr=replay(I,r['pair'],r['search_seed'],cfg['checkpoints'])
 assert baseline==r['baseline'] and tr==r['trace'],('replay',r['run_id']);traces+=len(tr)
 for cp in r['checkpoints']:
  check(I,cp['output']);expected=cps[cp['budget']]
  assert all(cp[k]==v for k,v in expected.items()),('checkpoint',r['run_id'],cp['budget'])
  assert cp['deltas']==cp['budget']==sum(cp['delta_by_kind'].values()) and cp['matrix_distances']==len(I['coordinates'])**2 and cp['scoreable']
 if (pos+1)%72==0:print('Independently replayed',pos+1,'CPU',time.process_time()-t0,flush=True)
replay_cpu=time.process_time()-start_replay
# Recompute all smoke checkpoint references independently, including their standalone prefixes.
smoke=load('raw/SMOKE.json');smokei=load(load('freeze/SMOKE.json')['file']);smoke_refs={}
for p in cfg['pairs']:
 b,cps,tr=replay(smokei,p,cfg['smoke_seed'],cfg['checkpoints']);smoke_refs[tuple(p)]=cps
for s in smoke['tests']:
 if s['kind']=='standalone_equivalence':assert s['reference']['output']==smoke_refs[tuple(s['pair'])][s['budget']]['output'] and s['passed']
# Seed-mean, then equally weighted geometry/demand aggregation.
groups=collections.defaultdict(list);base={}
for r in raw:
 base[r['geometry_id'],r['demand_mode']]=r['baseline']['reported_cost']
 for cp in r['checkpoints']:groups[r['geometry_id'],r['demand_mode'],r['algorithm'],cp['budget']].append(cp)
assert len(groups)==384 and all(len(v)==3 for v in groups.values())
mean=statistics.mean;aggreg={k:mean(c['output']['reported_cost'] for c in vv) for k,vv in groups.items()};alg=['_'.join(p) for p in cfg['pairs']];geos=sorted({r['geometry_id'] for r in raw});modes=cfg['demand_modes'];s=load('reports/SUMMARY.json')
for row in s['summary']:
 b,a=row['budget'],row['algorithm'];ds=modes if row['demand_mode']=='all' else [row['demand_mode']];vals=[]
 for g,d in itertools.product(geos,ds):
  costs={aa:aggreg[g,d,aa,b] for aa in alg};cost=costs[a];best=min(costs.values());cps=groups[g,d,a,b]
  vals.append({'mean_relative_regret_pct':100*(cost/best-1),'mean_midrank':1+sum(v<cost-1e-9 for v in costs.values())+sum(abs(v-cost)<=1e-9 for aa,v in costs.items() if aa!=a)/2,'mean_baseline_improvement_pct':100*(base[g,d]-cost)/base[g,d],'mean_distance':cost,'mean_vehicles':mean(len(c['output']['routes']) for c in cps),'mean_prefix_cpu_seconds':mean(c['solver_cpu_seconds'] for c in cps),'mean_prefix_wall_seconds':mean(c['solver_wall_seconds'] for c in cps)})
 assert row['n_geometries']==8 and row['n_geometry_demand_blocks']==len(vals)
 assert all(abs(row[k]-mean(v[k] for v in vals))<1e-9 for k in vals[0])
for key,rank in s['rankings'].items():
 dm,b=key.split('/');rs=[row for row in s['summary'] if row['demand_mode']==dm and row['budget']==int(b)];expected=sorted(rs,key=lambda r:(r['mean_relative_regret_pct'],r['algorithm']));assert rank==[r['algorithm'] for r in expected]
for row in s['budget_gains']:
 a,lo,hi=row['algorithm'],row['from_budget'],row['to_budget'];ds=modes if row['demand_mode']=='all' else [row['demand_mode']];gains=[100*(aggreg[g,d,a,lo]-aggreg[g,d,a,hi])/aggreg[g,d,a,lo] for g,d in itertools.product(geos,ds)]
 expected={'mean_paired_gain_pct':mean(gains),'median_paired_gain_pct':statistics.median(gains),'min_gain_pct':min(gains),'max_gain_pct':max(gains),'fraction_gain_le_0_5_pct':mean(v<=.5+1e-12 for v in gains),'block_count':len(gains),'practical_plateau_rule_met':lo==40000 and hi==160000 and mean(gains)<=.5 and mean(v<=.5+1e-12 for v in gains)>=.75}
 assert all(abs(row[k]-v)<1e-9 for k,v in expected.items())
for row in csv.DictReader((R/'reports/paired_algorithm_comparisons.csv').open()):
 a,aa,b=row['algorithm_a'],row['algorithm_b'],int(row['budget']);ds=[mean(100*(aggreg[g,d,a,b]/aggreg[g,d,aa,b]-1) for d in modes) for g in geos]
 assert all(abs(x-y)<1e-9 for x,y in zip(ds,json.loads(row['geometry_deltas_pct'])))
 assert abs(float(row['mean_geometry_relative_cost_a_minus_b_pct'])-mean(ds))<1e-9
 assert int(row['a_wins_geometries'])==sum(x<-1e-9 for x in ds) and int(row['a_loses_geometries'])==sum(x>1e-9 for x in ds)
res={'status':'accepted_with_scope_limits','all_freeze_hashes_match':True,'formal_trajectories_reimplemented':288,'formal_checkpoint_outputs_checked':1152,'baseline_outputs_checked':288,'independent_trace_rows_recomputed':traces,'independent_smoke_replays':4,'smoke_standalone_equivalences_checked':16,'primary_independent_geometry_blocks':8,'independent_replay_cpu_seconds':replay_cpu,'audit_cpu_seconds':time.process_time()-t0,'overall_rankings':{k:v for k,v in s['rankings'].items() if k.startswith('all/')},'all_demand_last_budget_gains':[r for r in s['budget_gains'] if r['demand_mode']=='all' and r['from_budget']==40000],'limits':['Equal candidate-delta evaluations do not imply equal FLOPs, wall time, or objective/checking work.','Checkpoints are prefixes of288 trajectories, not1152 independent runs.','Only8 reused development geometries; no fresh held-out or SOTA evidence.','Preregistered practical plateau is local finite-budget behavior, not asymptotic convergence or optimality.','Independent audit cost is separate from author process-tree timing.']}
(O/'search_budget_audit.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res,indent=2))
