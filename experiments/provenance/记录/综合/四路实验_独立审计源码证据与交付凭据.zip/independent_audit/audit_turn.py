import json,pathlib,csv,itertools,collections,functools,math,hashlib,statistics,time,resource
resource.setrlimit(resource.RLIMIT_CPU,(55,58))
t0=time.process_time();R=pathlib.Path('/workspace/shared/turn_routes_20261007');O=pathlib.Path(__file__).parent
load=lambda p:json.loads((R/p).read_text()); readcsv=lambda p:list(csv.DictReader((R/p).open()))
for line in (R/'pre_run.sha256').read_text().splitlines():
 h,p=line.split('  ',1);assert hashlib.sha256((R/p).read_bytes()).hexdigest()==h
cfg=load('freeze.json');data=load('instances.json');raw=[json.loads(l) for l in (R/'routes.jsonl').read_text().splitlines()]; assert len(raw)==750 and all(r['success'] for r in raw)
idx={(r['instance_id'],r['lambda'],r['strategy']):r for r in raw};assert len(idx)==750
by={i['instance_id']:i for i in data}
# Independent vector geometry. A perpendicular change costs1; exact reversal2.
def geom(poly):
 dirs=[];length=0
 for (x,y),(a,b) in zip(poly,poly[1:]):
  dx,dy=a-x,b-y;assert bool(dx)!=bool(dy);length+=abs(dx)+abs(dy);dirs.append((0 if not dx else (1 if dx>0 else -1),0 if not dy else (1 if dy>0 else -1)))
 units=[0 if a==b else 2 if a==(-b[0],-b[1]) else 1 for a,b in zip(dirs,dirs[1:])]
 return length,sum(units),sum(bool(v) for v in units),dirs

def candidates(a,b):
 if a[0]==b[0] or a[1]==b[1]:return [(a,b)]
 return [(a,(b[0],a[1]),b),(a,(a[0],b[1]),b)]
def change(a,b):return 0 if a is None or a==b else 2 if a==(-b[0],-b[1]) else 1

def route(I,order,options):
 assert sorted(order)==list(range(len(I['tasks']))) and len(options)==len(order)+1
 stops=[I['start']]+[I['tasks'][j] for j in order]+[I['goal']];poly=[tuple(stops[0])]
 for a,b,k in zip(stops,stops[1:],options):poly+=list(candidates(tuple(a),tuple(b))[k][1:])
 return poly

for r in raw:
 p=route(by[r['instance_id']],r['order'],r['leg_options']);d,t,e,_=geom(p)
 assert [list(x) for x in p]==r['polyline'] and (d,t,e)==(r['distance'],r['turn_quarter_units'],r['turn_events']) and d+r['lambda']*t==r['J']
assert load('failures.json')==[]

def pareto(I):
 pts=[tuple(p) for p in I['tasks']+[I['start'],I['goal']]];n=len(I['tasks']);legs={}
 for a,b in itertools.permutations(range(n+2),2):
  legs[a,b]=[(g[0],g[1],g[3][0],g[3][-1]) for p in candidates(pts[a],pts[b]) for g in [geom(p)]]
 @functools.lru_cache(None)
 def solve(todo,last,heading):
  vals=[]
  if todo==0:return tuple(sorted(set((d,t+change(heading,inc)) for d,t,inc,out in legs[last,n+1])))
  for j in range(n):
   if not (todo>>j)&1:continue
   for d,t,inc,out in legs[last,j]:
    vals.extend((d+dd,t+change(heading,inc)+tt) for dd,tt in solve(todo^(1<<j),j,out))
  # Positive-weight objectives are fully represented by nondominated length-turn pairs.
  vals=sorted(set(vals));kept=[];best=math.inf
  for d,t in vals:
   if t<best:kept.append((d,t));best=t
  return tuple(kept)
 frontier=solve((1<<n)-1,n,None)
 def fixed(order):
  states={None:0};distance=0;stops=[n]+list(order)+[n+1]
  for a,b in zip(stops,stops[1:]):
   ns={};distance+=legs[a,b][0][0]
   for h,t in states.items():
    for d,tt,inc,out in legs[a,b]:ns[out]=min(ns.get(out,math.inf),t+tt+change(h,inc))
   states=ns
  return distance,min(states.values())
 return frontier,fixed,solve.cache_info().currsize
frontiers=[];tie_expected=[];local_checks=0
for I in data:
 ident=I['instance_id'];front,fixed,states=pareto(I);frontiers.append({'instance_id':ident,'length_turn_pareto':front,'states':states})
 for lam in cfg['lambdas']:
  oracle=idx[ident,lam,'joint_dp_oracle'];opt=min(d+lam*t for d,t in front);assert oracle['J']==opt
  aa=idx[ident,lam,'distance_order_heading_paths'];d,t=fixed(aa['order']);assert aa['J']==d+lam*t
  local=idx[ident,lam,'turn_2opt'];ld,lt=fixed(local['order']);assert local['J']==ld+lam*lt
  if local['2opt_stop']=='no_strict_improvement':
   oo=local['order']
   for a in range(len(oo)):
    for b in range(a+1,len(oo)):
     d2,t2=fixed(oo[:a]+oo[a:b+1][::-1]+oo[b+1:]);assert d2+lam*t2>=local['J'];local_checks+=1
  d0,t0_=min(front);tie_expected.append({'instance_id':ident,'lambda':lam,'distance':d0,'turns':t0_,'J':d0+lam*t0_,'gap_pct':100*((d0+lam*t0_)/opt-1)})
# Independent exhaustive complete 5-task routes, not calling author verifier.
smallidx={(r['instance_id'],r['lambda']):r for r in load('validation_dp_results.json')};smallroutes=0
for I in load('validation_instances.json'):
 best={lam:math.inf for lam in cfg['lambdas']}
 for order in itertools.permutations(range(5)):
  stops=[tuple(I['start'])]+[tuple(I['tasks'][i]) for i in order]+[tuple(I['goal'])]
  choices=[candidates(a,b) for a,b in zip(stops,stops[1:])]
  for legs in itertools.product(*choices):
   poly=[stops[0]]+[p for leg in legs for p in leg[1:]];d,t,_,_=geom(poly);smallroutes+=1
   for lam in best:best[lam]=min(best[lam],d+lam*t)
 for lam,val in best.items():assert smallidx[I['instance_id'],lam]['J']==val
for c in readcsv('summary.csv'):
 rr=[r for r in raw if r['lambda']==float(c['lambda']) and r['strategy']==c['strategy'] and (c['family']=='ALL' or r['family']==c['family'])];gap=[100*(r['J']/idx[r['instance_id'],r['lambda'],'joint_dp_oracle']['J']-1) for r in rr]
 expected={'n':len(rr),'mean_J':statistics.mean(r['J'] for r in rr),'mean_distance':statistics.mean(r['distance'] for r in rr),'mean_turn_quarter_units':statistics.mean(r['turn_quarter_units'] for r in rr),'mean_gap_pct':statistics.mean(gap),'median_gap_pct':statistics.median(gap),'max_gap_pct':max(gap),'strict_suboptimal_count':sum(g>1e-7 for g in gap)}
 assert all(abs(float(c[k])-v)<1e-9 for k,v in expected.items()),c
for c in readcsv('paired_comparisons.csv'):
 ds=[idx[i['instance_id'],float(c['lambda']),c['strategy_A']]['J']-idx[i['instance_id'],float(c['lambda']),c['strategy_B']]['J'] for i in data]
 expected={'n':len(ds),'mean_A_minus_B':statistics.mean(ds),'median_A_minus_B':statistics.median(ds),'min_A_minus_B':min(ds),'max_A_minus_B':max(ds),'positive_count':sum(x>0 for x in ds),'zero_count':sum(x==0 for x in ds)}
 assert all(abs(float(c[k])-v)<1e-9 for k,v in expected.items())
if (R/'tie_audit_raw.csv').exists():
 tidx={(c['instance_id'],float(c['lambda'])):c for c in readcsv('tie_audit_raw.csv')}
 for e in tie_expected:assert all(abs(float(tidx[e['instance_id'],e['lambda']][k])-e[k])<1e-9 for k in ['distance','turns','J','gap_pct'])
ties=[{'lambda':lam,'mean_gap_pct':statistics.mean(x['gap_pct'] for x in tie_expected if x['lambda']==lam),'strictly_suboptimal':sum(x['gap_pct']>1e-9 for x in tie_expected if x['lambda']==lam)} for lam in cfg['lambdas']]
res={'status':'accepted_with_scope_limits','all_pre_run_hashes_match':True,'main_routes_checked':750,'independent_full_pareto_fronts':30,'independent_main_exact_objectives':150,'independent_small_exact_objectives':30,'independent_small_routes':smallroutes,'independent_2opt_neighbor_checks':local_checks,'summary_rows_checked':len(readcsv('summary.csv')),'paired_rows_checked':len(readcsv('paired_comparisons.csv')),'posthoc_best_distance_tie':ties,'audit_cpu_seconds':time.process_time()-t0,'limits':['New synthetic rectilinear service-order problem, no empirical agricultural or kinematic validation.','Exact only among x-first/y-first shortest L paths; no arbitrary path, obstacles, curvature or collisions.','750 observations are repeated within30 geometries, not750 independent problems.','Lambda0.5 difference vanishes after best distance-optimal tie resolution; cannot claim genuine distance-turn tradeoff there.','Posthoc tie correction is diagnostic and not preregistered primary evidence.']}
(O/'turn_audit.json').write_text(json.dumps(res,indent=2)+'\n');(O/'turn_independent_frontiers.json').write_text(json.dumps(frontiers,indent=2)+'\n');print(json.dumps(res,indent=2))
