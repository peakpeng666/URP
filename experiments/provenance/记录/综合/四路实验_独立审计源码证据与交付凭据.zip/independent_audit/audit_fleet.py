import json,pathlib,hashlib,itertools,collections,time,zipfile,resource,math
resource.setrlimit(resource.RLIMIT_CPU,(30,32))
start=time.process_time();R=pathlib.Path('/workspace/shared/fleet_20261007');O=pathlib.Path(__file__).parent
load=lambda p:json.loads((R/p).read_text())
F=load('FREEZE.json'); data=load('data/instances.json'); rows=[json.loads(l) for l in (R/'results/raw.jsonl').read_text().splitlines()]; summary=load('results/summary.json')
assert all(hashlib.sha256((R/p).read_bytes()).hexdigest()==h for p,h in F['files'].items())
assert len(data)==len(rows)==144 and len({r['id'] for r in rows})==144
assert all(r['execution']=='OK' for r in rows)
assert F['frozen_utc']<min(r['started_utc'] for r in rows)
with zipfile.ZipFile(R/'source_P102.zip') as z:
 prefix='independent_heterogeneous_fleet_20261006/'
 preserved=['CONTRACT.json','src/solver.py','src/oracle.py','src/checker.py','src/generate_data.py','tests/test_contract.py']
 assert all((R/p).read_bytes()==z.read(prefix+p) for p in preserved)

def validate(I,A,full=True):
 ts={t['id']:t for t in I['tasks']};ms={m['id']:m for m in I['implements']};vs={v['id']:v for v in I['vehicles']};xy={0:I['depot'],**{i:t['xy'] for i,t in ts.items()}}
 seen=[];used=[];ds=collections.Counter()
 for r in A['routes']:
  m=ms[r['implement_id']];v=vs[r['vehicle_id']];ns=r['nodes'];used.append(m['id'])
  assert m['id'] in v['compatible_implements'] and ns[0]==ns[-1]==0 and len(ns)>2 and 0 not in ns[1:-1]
  assert all(ts[i]['operation']==m['operation'] for i in ns[1:-1]);assert sum(ts[i]['demand'] for i in ns[1:-1])<=m['capacity']
  seen+=ns[1:-1];ds[v['id']]+=sum(abs(xy[a][0]-xy[b][0])+abs(xy[a][1]-xy[b][1]) for a,b in zip(ns,ns[1:]))
 assert len(seen)==len(set(seen)) and len(used)==len(set(used));assert all(ds[k]<=v['distance_limit'] for k,v in vs.items())
 if full:assert set(seen)==set(ts)
 value=sum(ds[k]*v['cost_per_distance'] for k,v in vs.items());assert A['objective_total']==value
 return value

def reference(I):
 # Fresh route-first enumeration; no solver, checker, oracle or author cache imported.
 ts=I['tasks'];ms=I['implements'];vs=I['vehicles'];xy={0:I['depot'],**{t['id']:t['xy'] for t in ts}}
 options=[]
 for m in ms:
  ids=[t['id'] for t in ts if t['operation']==m['operation']];op={0:0}
  for n in range(1,len(ids)+1):
   for sub in itertools.combinations(ids,n):
    if sum(ts[i-1]['demand'] for i in sub)>m['capacity']:continue
    length=min(sum(sum(abs(x-y) for x,y in zip(xy[a],xy[b])) for a,b in zip((0,)+p,p+(0,))) for p in itertools.permutations(sub))
    op[sum(1<<(i-1) for i in sub)]=length
  options.append(op)
 best=math.inf;stage=math.inf;stage_lex=None;stage_lex_val=math.inf;stage_best=math.inf;partitions=0
 for masks in itertools.product(*(list(op) for op in options)):
  if sum(m.bit_count() for m in masks)!=len(ts) or (masks[0]|masks[1]|masks[2]|masks[3])!=(1<<len(ts))-1:continue
  partitions+=1;lens=[op[m] for op,m in zip(options,masks)];distance=sum(lens);cost=math.inf
  for assignments in itertools.product(*([[v for v in range(len(vs)) if ms[i]['id'] in vs[v]['compatible_implements']] if mask else [-1] for i,mask in enumerate(masks)])):
   miles=[sum(lens[i] for i,v in enumerate(assignments) if v==j) for j in range(len(vs))]
   if all(d<=v['distance_limit'] for d,v in zip(miles,vs)):cost=min(cost,sum(d*v['cost_per_distance'] for d,v in zip(miles,vs)))
  best=min(best,cost)
  if distance<stage:stage=distance;stage_lex=masks;stage_lex_val=cost;stage_best=cost
  elif distance==stage:
   if masks<stage_lex:stage_lex=masks;stage_lex_val=cost
   stage_best=min(stage_best,cost)
 def out(cost,name):return ('FEASIBLE',cost) if cost<math.inf else (('PHASE_ONE_INFEASIBLE' if partitions==0 else 'STAGE_FIXED_INFEASIBLE') if name!='joint_exact' else 'INFEASIBLE_PROVEN',None)
 return {name:out(val,name) for name,val in [('joint_exact',best),('two_stage_lex',stage_lex_val),('two_stage_best_tie',stage_best)]}

checked=partial=0;ref_results=[]
for I,r in zip(data,rows):
 assert I['id']==r['id'];ref=reference(I)
 for name,v in ref.items():assert v==(r['outputs'][name]['status'],r['outputs'][name]['objective_total']),(I['id'],name,v)
 assert ref['joint_exact']==(r['oracle']['status'],r['oracle']['objective_total'])
 for A in list(r['outputs'].values())+[r['oracle']]:
  if A['status']=='FEASIBLE':validate(I,A);checked+=1
  elif A['routes']:validate(I,A,False);partial+=1
 for A in r['outputs']['greedy']['all_start_outputs']:validate(I,A,A['status']=='FEASIBLE');partial+=1
 ref_results.append({'id':I['id'],'reference':ref})
# Fixed panel and pairing assertions.
keys={(i['metadata']['seed'],i['metadata']['capacity_h'],i['metadata']['geometry']):i for i in data}
for seed in F['seeds']:
 block=[keys[seed,h,g] for h in [0,2,4] for g in ['four_quadrants','two_clusters']]
 for I in block:
  assert [t['demand'] for t in I['tasks']]==[t['demand'] for t in block[0]['tasks']]
  assert [list(map(abs,t['xy'])) for t in I['tasks']]==[list(map(abs,t['xy'])) for t in block[0]['tasks']]
  assert I['vehicles']==block[0]['vehicles']
  assert all(sum(m['capacity'] for m in I['implements'] if m['operation']==op)==10 for op in [0,1])
for c in summary['cells']:
 rr=[r for r in rows if r['metadata']['capacity_h']==c['capacity_h'] and r['metadata']['geometry']==c['geometry']];a=c['algorithm'];vals=[(r['outputs'][a]['objective_total']/r['outputs']['joint_exact']['objective_total']-1)*100 for r in rr if r['outputs'][a]['status']=='FEASIBLE']
 assert c['all_instances']==len(rr)==24 and c['complete']==c['gap_n']==len(vals)
 assert c['exact_feasible']==sum(r['outputs']['joint_exact']['status']=='FEASIBLE' for r in rr)
 assert c['statuses']==dict(collections.Counter(r['outputs'][a]['status'] for r in rr))
 assert abs(c['gap_mean_pct']-sum(vals)/len(vals))<1e-10 and abs(c['gap_max_pct']-max(vals))<1e-10
for c in summary['pairwise']:
 co=collections.Counter();diff=[]
 for r in rows:
  if r['outputs']['joint_exact']['status']!='FEASIBLE':continue
  a=r['outputs'][c['a']];b=r['outputs'][c['b']];ao=a['status']=='FEASIBLE';bo=b['status']=='FEASIBLE'
  if not ao and not bo:co['both_failed']+=1;continue
  v=a['objective_total']-b['objective_total'] if ao and bo else -1 if ao else 1
  if ao and bo:diff.append(v)
  co['a_wins' if v<0 else 'a_losses' if v>0 else 'ties']+=1
 assert all(c[k]==co[k] for k in ['a_wins','a_losses','ties','both_failed'])
 assert c['both_complete_n']==len(diff) and abs(c['a_minus_b_cost_mean_on_both_complete']-sum(diff)/len(diff))<1e-10
by={(r['metadata']['seed'],r['metadata']['capacity_h'],r['metadata']['geometry']):r for r in rows}
for c in summary['paired_feasibility_transitions']:
 co=collections.Counter()
 for seed in F['seeds']:
  vals=[by[seed,c[s+'_h'],c[s+'_geometry']]['outputs'][c['algorithm']]['status']=='FEASIBLE' for s in ['from','to']];co[''.join('T' if b else 'F' for b in vals)]+=1
 assert all(c[k]==co[k] for k in ['FF','FT','TF','TT'])
totals={a:sum(r['outputs'][a]['status']=='FEASIBLE' for r in rows) for a in rows[0]['outputs']}
result={'status':'accepted_with_scope_limits','instances':144,'independent_blocks':24,'preserved_original_files':preserved,'all_freeze_hashes_match':True,'independent_exact_references':144,'complete_routes_checked':checked,'partial_or_per_start_routes_checked':partial,'summary_cells_checked':len(summary['cells']),'pairwise_checked':3,'paired_transitions_checked':len(summary['paired_feasibility_transitions']),'complete_by_algorithm':totals,'exact_infeasible':144-totals['joint_exact'],'audit_cpu_seconds':time.process_time()-start,'limits':['Synthetic common-depot integer Manhattan subset; not original P102 full model or field validation.','Two-stage procedures are exact small-instance baselines, not scalable heuristics.','No inferential independent n=144: effective paired blocks=24.','Preparation/report/platform costs remain unknown; formal child tree 0.742232 CPU s separately reported.']}
(O/'fleet_audit.json').write_text(json.dumps(result,indent=2)+'\n');(O/'fleet_independent_references.json').write_text(json.dumps(ref_results,indent=2)+'\n');print(json.dumps(result,indent=2))
