import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import json,pathlib,hashlib,collections,time,math,resource,statistics,random
import numpy as np
resource.setrlimit(resource.RLIMIT_CPU,(45,48));t0=time.process_time();R=pathlib.Path('/workspace/shared/selector_sizes_20261007');O=pathlib.Path(__file__).parent
load=lambda p:json.loads((R/p).read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();canon=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
f=load('FREEZE.json');assert all(sha(R/p)==h for p,h in f['files'].items());assert f['created_utc']<=load('RUN_STARTED.json')['utc']<=load('RUN_COMPLETE.json')['utc']
manifest=load('original/MANIFEST.json');assert all(sha(R/'original'/p)==v['sha256'] for p,v in manifest['files'].items())
data=load('DATA.json');by={d['instance_id']:d for d in data};plans=load('SPLITS.json');fits=load('FITS.json');raw=[json.loads(s) for s in (R/'RAW_PREDICTIONS.jsonl').read_text().splitlines()];assert (len(data),len(plans),len(raw))==(252,560,17280)
# Validate every historical label's assignments and reconstruct prefix features without original code.
for d in data:
 I=load('original/inputs/'+d['instance_id']+'.json');items=np.array(I['items']);assert len(items)==5000
 assert hashlib.sha256(canon(sorted(I['items'])).encode()).hexdigest()==d['multiset_sha256']
 prefix_remaining=None
 for j,b in enumerate(['BF','BF_then_EoH']):
  a=load('original/raw/'+d['instance_id']+'__'+b+'.json');assert a['status']=='complete' and a['steps']==5000 and a['error'] is None
  assert sha(R/'original'/a['trajectory_file'])==a['trajectory_sha256'];assert hashlib.sha256(canon(I['items']).encode()).hexdigest()==a['items_sha256']
  ar=np.load(R/'original'/a['trajectory_file'],allow_pickle=False);assign=ar['assignment'];assert len(assign)==5000 and np.all((assign>=0)&(assign<5000))
  totals=np.bincount(assign,weights=items,minlength=5000);assert np.all(totals<=100) and np.array_equal(100-totals,ar['remaining']);assert int(np.count_nonzero(totals))==a['used_bins']==d['costs'][j]
  rem=np.full(5000,100,dtype=np.int64);used=0
  for q,idx in zip(items[:500],assign[:500]):
   eligible=np.flatnonzero(rem[:used+1]>=q);choice=eligible[np.argmin(rem[eligible])];assert idx==choice
   if rem[idx]==100:used+=1
   rem[idx]-=q
  if prefix_remaining is not None:assert np.array_equal(rem,prefix_remaining)
  prefix_remaining=rem.copy();assert np.allclose(a['prefix_features'],d['features'],atol=1e-14,rtol=0)
 p=items[:500];used=rem[rem<100];hist=[sum((p-1)//10==i)/500 for i in range(10)];rs=[sum(used//10==i)/len(used) for i in range(10)]
 vals=hist+[float(p.mean()/100),float(p.std()/100)]+list(np.quantile(p,[.1,.5,.9])/100)+[float(np.mean(np.diff(p)>0)),float(np.mean(np.diff(p)<0)),float((p[-100:].mean()-p[:100].mean())/100),len(used)/500]+rs+[float(used.mean()/100),float(used.std()/100)]
 assert len(vals)==31 and np.allclose(vals,d['features'],atol=1e-14,rtol=0)
# Reproduce every shuffled grouped split from historical metadata only.
old=load('original/PROTOCOL.json');families=old['families'];metadata=[d for d in old['instances'] if d['split'] in ['train','confirmation']];runs=collections.defaultdict(list)
for r in raw:runs[r['run_id']].append(r)
chains=collections.defaultdict(list)
for run,p in enumerate(plans):
 track,fold,seed,size=[p[k] for k in ['track','fold','seed','groups_per_training_family']]
 pool=[d for d in metadata if d['split']=='train' and (track=='within_family' or d['family']!=fold)];test=[d for d in metadata if d['split']=='confirmation' and (track=='within_family' or d['family']==fold)]
 selected=set()
 for fam in families:
  gg=sorted({d['group_id'] for d in pool if d['family']==fam});rr=random.Random(int(hashlib.sha256(f'{seed}|{fam}'.encode()).hexdigest()[:16],16));rr.shuffle(gg);selected.update(gg[:size])
 assert p['pool_ids']==[d['instance_id'] for d in pool] and p['train_ids']==[d['instance_id'] for d in pool if d['group_id'] in selected] and p['test_ids']==[d['instance_id'] for d in test]
 tr=[by[k] for k in p['train_ids']];te=[by[k] for k in p['test_ids']]
 for k in ['group_id','multiset_sha256']:assert not {d[k] for d in tr}&{d[k] for d in te}
 assert all(n==3 for n in collections.Counter(d['group_id'] for d in tr).values())
 if track=='family_holdout':assert not {d['family'] for d in tr}&{d['family'] for d in te}
 chains[track,fold,seed].append(p)
 x=np.array([d['features'] for d in tr]);y=np.array([d['costs'] for d in tr]);mu=x.sum(0)/len(x);sd=np.sqrt(((x-mu)**2).sum(0)/len(x));sd[sd==0]=1;sbs=int(y[:,1].sum()<y[:,0].sum());py=np.array([by[k]['costs'] for k in p['pool_ids']]);psbs=int(py[:,1].sum()<py[:,0].sum())
 model=load(f'models/{run:04d}.json');assert sha(R/f'models/{run:04d}.json')==fits[run]['model_sha256'];assert np.allclose(mu,model['mean'],atol=1e-14,rtol=0) and np.allclose(sd,model['scale'],atol=1e-14,rtol=0)
 assert sorted(r['instance_id'] for r in runs[run])==sorted(p['test_ids'])
 for r in runs[run]:
  z=np.array(by[r['instance_id']]['features']);ds=np.sum(((x-z)/sd)**2,axis=1);nn=sorted(range(len(x)),key=lambda i:(float(ds[i]),i))[:5];costs=y[nn].sum(0);ch=sbs if costs[0]==costs[1] else int(costs[1]<costs[0]);truth=by[r['instance_id']]['costs']
  assert r['selected_index']==ch and r['neighbors']==[p['train_ids'][i] for i in nn] and np.allclose(r['squared_distances'],ds[nn],atol=1e-10,rtol=1e-12)
  assert r['selected_bins']==truth[ch] and r['subset_sbs_bins']==truth[sbs] and r['pool_sbs_bins']==truth[psbs] and r['oracle_bins']==min(truth)
for ps in chains.values():
 ps=sorted(ps,key=lambda p:p['groups_per_training_family']);assert all(set(a['train_ids'])<set(b['train_ids']) and a['test_ids']==b['test_ids'] for a,b in zip(ps,ps[1:]))

def metrics(rr):
 mean=lambda xs:sum(xs)/len(rr);dd=[r['selected_bins']-r['subset_sbs_bins'] for r in rr];reg=mean([r['selected_bins']-r['oracle_bins'] for r in rr]);sreg=mean([r['subset_sbs_bins']-r['oracle_bins'] for r in rr])
 return {'n':len(rr),'mean_bins':mean([r['selected_bins'] for r in rr]),'subset_sbs_mean_bins':mean([r['subset_sbs_bins'] for r in rr]),'pool_sbs_mean_bins':mean([r['pool_sbs_bins'] for r in rr]),'oracle_mean_bins':mean([r['oracle_bins'] for r in rr]),'delta_vs_subset_sbs':mean(dd),'regret':reg,'sbs_regret':sreg,'gap_recovered':None if not sreg else 1-reg/sreg,'wins':sum(v<0 for v in dd),'ties':sum(v==0 for v in dd),'losses':sum(v>0 for v in dd),'worst_harm':max(dd),'eoh_selected':sum(r['selected_index']==1 for r in rr)}
seed_groups=collections.defaultdict(list);cell_groups=collections.defaultdict(list)
for r in raw:
 key=r['track'],r['groups_per_training_family'],r['seed'];seed_groups[key].append(r);cell_groups[key+(r['family'],r['order'])].append(r)
for fn,grp in [('SEED_METRICS.json',seed_groups),('CELL_METRICS.json',cell_groups)]:
 for s in load(fn):
  key=(s['track'],s['groups_per_training_family'],s['seed'])+((s['family'],s['order']) if fn.startswith('CELL') else ());expected=metrics(grp[key]);assert all((s[k] is None and v is None) or (s[k] is not None and v is not None and abs(s[k]-v)<1e-9) for k,v in expected.items())
summary=load('SUMMARY.json')
for s in summary:
 sms=[metrics(rr) for k,rr in seed_groups.items() if k[:2]==(s['track'],s['groups_per_training_family'])];assert len(sms)==20
 for k,v in s.items():
  if isinstance(v,dict):
   vals=[sm[k] for sm in sms if sm[k] is not None];assert abs(v['mean']-statistics.mean(vals))<1e-9 and abs(v['min']-min(vals))<1e-9 and abs(v['max']-max(vals))<1e-9
res={'status':'accepted_with_scope_limits','all_frozen_and_historical_manifest_hashes_match':True,'historical_assignment_labels_checked':504,'prefix_feature_streams_checked':252,'model_splits_checked':560,'independent_predictions_checked':17280,'seed_metric_rows_checked':len(seed_groups),'family_order_metric_rows_checked':len(cell_groups),'distinct_test_streams':len({r['instance_id'] for r in raw}),'distinct_test_multisets':len({r['multiset_sha256'] for r in raw}),'family_holdout_full_size_delta_bins':next(s for s in summary if s['track']=='family_holdout' and s['groups_per_training_family']==8)['delta_vs_subset_sbs']['mean'],'audit_cpu_seconds':time.process_time()-t0,'limits':['Offline refits on old observed synthetic streams, no new online policy executions or new blind test data.','20 seeds are training-subset randomizations; same108 streams/36 multisets reused.','At full size all20 seeds use identical data; they do not provide20 independent replications.','Oracle is only hindsight minimum of two fixed branches after identical BF500 prefix, not optimal bin packing.','Nonmonotonic family-holdout outcome prevents claiming more training data always helps.']}
(O/'selector_audit.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res,indent=2))
