import pathlib,json,re,sys
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_CELL_VERTICAL_ALIGNMENT
from docx.opc.constants import RELATIONSHIP_TYPE as RT
R=pathlib.Path(__file__).resolve().parent
ns={};exec((R/'report_content.py').read_text(),ns); sections=ns['sections']
ns={};exec((R/'report_extra.py').read_text(),ns); extra=ns['extra']
sections=sections[:10]+extra[:4]+sections[10:14]+[extra[4]]+sections[14:]
# update project state with confirmed latest report without inventing winner
for s in sections:
 s['paragraphs']=[p.replace('原BPP132试验的72项生成终态与尚未真实调用的60项，以及36模型×档位筛选的在途状态，都不得用于提前挑选VRP赢家。','原BPP132主线仍未启动新的模型调用。36模型×档位筛选已结束并归档，但它属于文本装箱代码生成的小样本筛选，不是多模态地图或VRP证据，不能据此选VRP模型赢家。') for p in s['paragraphs']]
refs=json.loads((R/'sources_all.json').read_text());refmap={r['source_id']:r for r in refs}
doc=Document();sec=doc.sections[0];sec.page_width=Inches(8.5);sec.page_height=Inches(11);sec.top_margin=Inches(.7);sec.bottom_margin=Inches(.65);sec.left_margin=Inches(.75);sec.right_margin=Inches(.75);sec.header_distance=Inches(.25);sec.footer_distance=Inches(.25)
styles=doc.styles
for name in ['Normal','Title','Subtitle','Heading 1','Heading 2','Heading 3','Caption','Header','Footer']:
 st=styles[name];st.font.name='Noto Sans CJK SC';st.font.color.rgb=RGBColor(0,0,0)
 st.element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'),'Noto Sans CJK SC')
styles['Normal'].font.size=Pt(11)
styles['Normal'].paragraph_format.line_spacing=1.3
styles['Normal'].paragraph_format.space_after=Pt(6)
styles['Title'].font.size=Pt(23);styles['Title'].font.bold=True
styles['Subtitle'].font.size=Pt(11)
styles['Heading 1'].font.size=Pt(15);styles['Heading 1'].font.bold=True;styles['Heading 1'].paragraph_format.space_before=Pt(15);styles['Heading 1'].paragraph_format.space_after=Pt(8)
styles['Heading 1'].paragraph_format.keep_with_next=True
styles['Caption'].font.size=Pt(9);styles['Caption'].paragraph_format.space_after=Pt(7)
# prevent borders inherited from any template
for st in [styles['Title'],styles['Subtitle']]:
 ppr=st.element.find(qn('w:pPr'))
 if ppr is not None:
  for x in list(ppr):
   if x.tag==qn('w:pBdr'):ppr.remove(x)
header=sec.header.paragraphs[0];header.text='提示词到可编辑多车任务地图  技术调研与实验方案';header.style=styles['Header'];header.runs[0].font.size=Pt(8)
foot=sec.footer.paragraphs[0];foot.alignment=WD_ALIGN_PARAGRAPH.RIGHT
foot.add_run('2026年10月7日  ·  ')
fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');foot._p.append(fld)
for r in foot.runs:r.font.size=Pt(8)
def link(p,label,url,size=None):
 h=OxmlElement('w:hyperlink');h.set(qn('r:id'),p.part.relate_to(url,RT.HYPERLINK,is_external=True));r=OxmlElement('w:r');rp=OxmlElement('w:rPr');col=OxmlElement('w:color');col.set(qn('w:val'),'264F73');rp.append(col)
 if size:
  sz=OxmlElement('w:sz');sz.set(qn('w:val'),str(int(size*2)));rp.append(sz)
 r.append(rp);t=OxmlElement('w:t');t.text=label;r.append(t);h.append(r);p._p.append(h)
def addtext(p,text):
 for part in re.split(r'(\[(?:N|D|T|P)\d{2}\])',text):
  m=re.fullmatch(r'\[((?:N|D|T|P)\d{2})\]',part)
  if m:
   rid=m.group(1);rr=refmap.get(rid)
   if rr and rr['primary_url']:link(p,part,rr['primary_url'])
   else:p.add_run(part)
  else:p.add_run(part)
def table(data):
 t=doc.add_table(rows=1,cols=len(data[0]));t.alignment=WD_TABLE_ALIGNMENT.CENTER;t.autofit=False
 total=7.0
 if len(data[0])==3:ws=[1.35,2.8,2.85]
 else:ws=[total/len(data[0])]*len(data[0])
 for i,w in enumerate(ws):t.columns[i].width=Inches(w)
 for ri,row in enumerate(data):
  cells=t.rows[0].cells if ri==0 else t.add_row().cells
  for ci,text in enumerate(row):
   c=cells[ci];c.width=Inches(ws[ci]);c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
   p=c.paragraphs[0];p.paragraph_format.space_after=Pt(3);p.paragraph_format.space_before=Pt(3);p.paragraph_format.line_spacing=1.1;addtext(p,text)
   for r in p.runs:r.font.size=Pt(9.3);r.bold=(ri==0);r.font.color.rgb=RGBColor(255,255,255) if ri==0 else RGBColor(0,0,0)
   pr=c._tc.get_or_add_tcPr();shade=OxmlElement('w:shd');shade.set(qn('w:fill'),'28485D' if ri==0 else ('F2F5F7' if ri%2==0 else 'FFFFFF'));pr.append(shade)
   margins=OxmlElement('w:tcMar')
   for side in ['top','left','bottom','right']:
    x=OxmlElement('w:'+side);x.set(qn('w:w'),'90');x.set(qn('w:type'),'dxa');margins.append(x)
   pr.append(margins)
  trpr=t.rows[ri]._tr.get_or_add_trPr();n=OxmlElement('w:cantSplit');trpr.append(n)
  if ri==0:
   rep=OxmlElement('w:tblHeader');trpr.append(rep)
 borders=OxmlElement('w:tblBorders')
 for name in ['top','left','bottom','right','insideH','insideV']:
  b=OxmlElement('w:'+name);b.set(qn('w:val'),'single');b.set(qn('w:sz'),'4');b.set(qn('w:color'),'D9D9D9');borders.append(b)
 t._tbl.tblPr.append(borders)
 doc.add_paragraph().paragraph_format.space_after=Pt(1)
 return t
doc.add_paragraph('提示词到可编辑多车任务地图',style='Title')
doc.add_paragraph('VRP可视化路线的批判性调研与公平实验方案',style='Subtitle')
doc.add_paragraph('研究快照  2026年10月7日    适用对象  本科科研项目与工程原型',style='Subtitle')
p=doc.add_paragraph('阅读重点：先看第1至5节的系统边界，再看第9至10节的算法取舍，实施时按第15至20节的实验和校验协议推进。');p.paragraph_format.space_after=Pt(8)
for i,s in enumerate(sections,1):
 doc.add_heading(f'{i}  {s["title"]}',1)
 for text in s['paragraphs']:
  p=doc.add_paragraph();addtext(p,text)
 if s.get('table'):table(s['table'])
 if s.get('image'):
  p=doc.add_paragraph();p.paragraph_format.keep_with_next=True;p.add_run().add_picture(str(R/s['image']),width=Inches(7))
  doc.add_paragraph(s['caption'],style='Caption')
doc.add_page_break();doc.add_heading('来源索引与阅读审计',1)
p=doc.add_paragraph('本轮合并83组外部证据记录及2项项目报告，共85组，包含论文、官方数据、代码、文档和登记记录，不等于85篇论文。83个主入口及其支持链接去重后共135个URL。未统计搜索引擎全部命中，不能视为穷尽检索。逐条阅读范围、代码状态、限制及访问日期见sources_all.csv。以下编号与正文引用一致。');p.paragraph_format.space_after=Pt(10)
for r in refs:
 p=doc.add_paragraph();p.paragraph_format.line_spacing=1.15;p.paragraph_format.space_after=Pt(5);p.paragraph_format.keep_together=True
 text=f'[{r["source_id"]}] {r["title"]}'+(f' ({r["year"]})' if r['year'] else '')+'。'+r['reading_depth']+'。 '
 run=p.add_run(text);run.font.size=Pt(9)
 if r['primary_url']:link(p,'原始来源',r['primary_url'],9)
 else:p.add_run('项目归档报告 '+r['local_retrieval_id']).font.size=Pt(9)
 # do not reproduce the entire audit or raw third-party paper text
 if r['source_id'] in ['N01','N17','N19']:
  rr=p.add_run('  '+r['code_status']);rr.font.size=Pt(9)
doc.core_properties.title='提示词到可编辑多车任务地图'
doc.core_properties.subject='VRP可视化路线调研与公平实验方案'
doc.core_properties.author='项目研究助理'
doc.core_properties.comments='外部研究未在本轮复现；所有性能结论保留来源与适用条件。'
doc.save(R/'visual_vrp_research_20261007.docx')
(R/'report_sections.json').write_text(json.dumps(sections,ensure_ascii=False,indent=2))
print('sections',len(sections),'chars',sum(sum(len(p) for p in x['paragraphs']) for x in sections),'sources',len(refs))
