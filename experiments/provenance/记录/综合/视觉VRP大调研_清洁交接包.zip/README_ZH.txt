提示词到可编辑多车任务地图
批判性调研交付包  2026年10月7日

先读：visual_vrp_research_20261007.pdf。需要修改时用同名DOCX。
主结论：先完成带来源、可编辑、固定求解器、独立checker的VRP闭环；算法选择保持SBS默认，LLM局部算子在公平对照中证明收益后再接入。

主要文件
- visual_vrp_research_20261007.docx / .pdf：22页中文报告，正文引用可点击。
- sources_all.csv / .json：85组证据记录，其中83组外部来源和2项项目报告；不是85篇论文。含阅读范围、官方代码状态、限制和访问日期。
- search_audit.json / screening_decisions.csv：主分支13轮52条定向检索记录、筛选和去重口径。不是所有搜索命中的完整导出，亦非穷尽检索。
- experiment_matrix.csv：四条主路线及可分辨的变体。
- research_protocol.json：拟议预算、数据分层、独立校验、统计与阶段闸门。
- task_contract.json：建议的输入输出字段、来源状态、阻塞未知项及编辑规则。是协议草案，不是已经实现的JSON Schema/API。
- dataset_matrix.csv / data_import_validation_plan.txt：13类数据源比较和数据导入验证计划。
- stack_reading_audit.txt：工具版本、读取文件和能力边界。
- CVRP_SCALE_REPORT_ZH.md / CURVATURE_CONCLUSIONS_ZH.txt：被本报告引用的项目内现成报告副本，保留其限定条件；本次未重跑。
- component_route_example.png：合成Dubins几何组件图，不是实地地图或多车实验。
- build_report.py / report_content.py / report_extra.py：报告生成源码；需要Python及python-docx，放在同一目录并保留sources_all.json与图，可重新生成DOCX。PDF需要另行渲染；不含模型请求或规划实验。
- QA_REPORT.json / MANIFEST.json / SHA256SUMS.txt：交付校验和文件清单。

边界
本次进行了公开原文、文档、源码片段和有限数据格式核查，没有复现外部论文，没有安装运行新的规划器，没有新的付费模型调用、API密钥或部署。项目内既有实跑结果另列来源，不冒充本轮新实验。
本包不打包第三方论文全文、网页缓存、下载数据大包或密钥。来源链接与读取审计用于回查，不能替代来源本身的许可。
