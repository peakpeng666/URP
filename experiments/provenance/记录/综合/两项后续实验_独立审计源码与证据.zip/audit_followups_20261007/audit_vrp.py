"""Single targeted pass over new CVRP evidence; only four frozen search replays."""
import collections, csv, hashlib, json, math, pathlib, random, resource, statistics, sys, time
ROOT=pathlib.Path('/workspace/shared/vrp_unseen_geometry_20261007')
OUT=pathlib.Path(__file__).resolve().parent
OLD=pathlib.Path('/workspace/shared/search_budget_20261007/input/independent_cvrp_demand_shift_20261006')
resource.setrlimit(resource.RLIMIT_CPU,(30,31))
START=time.process_time()
read=lambda p:json.loads(pathlib.Path(p).read_text())
cfg=read(ROOT/'freeze/PROTOCOL.json');manifest=read(ROOT/'freeze/INPUT_MANIFEST.json');schedule=read(ROOT/'freeze/SCHEDULE.json')
summary=read(ROOT/'reports/SUMMARY.json')
rows=[json.loads(s) for s in (ROOT/'raw/TRAJECTORIES.jsonl').read_text().splitlines()]
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
chash=lambda obj:hashlib.sha256(json.dumps(obj['coordinates'],separators=(',',':')).encode()).hexdigest()
close=lambda a,b:math.isclose(a,b,rel_tol=1e-10,abs_tol=1e-9)
old_entries=read(OLD/'data/manifest.json')['entries']
old_hashes=set();old_seeds=set()
for e in old_entries:
    obj=read(OLD/e['file']);h=chash(obj)
    assert h==e['coordinate_sha256']
    old_hashes.add(h);old_seeds.add(e['geometry_seed'])
assert old_hashes==set(read(ROOT/'freeze/OLD_GEOMETRY_HASHES.json')['hashes'])
new_hashes={};geometry_meta={};objects={}
for e in manifest:
    obj=read(ROOT/e['input_file']);objects[e['input_file']]=obj
    assert sha(ROOT/e['input_file'])==e['input_sha256']
    assert obj['generation_seed']==e['geometry_seed'] and e['geometry_seed'] not in old_seeds
    h=chash(obj);assert h==e['coordinate_sha256'] and h not in old_hashes
    if e['geometry_id'] in new_hashes:assert new_hashes[e['geometry_id']]==h
    new_hashes[e['geometry_id']]=h;geometry_meta[e['geometry_id']]=e
    d=obj['demands'][1:];n=e['n']
    assert len(d)==n and sum(d)==5*n and obj['capacity']==30 and max(d)<=30
    assert obj['family']==e['family'] and len(obj['coordinates'])==n+1
    if e['demand_mode']=='constant5':assert d==[5]*n
    else:
        assert sorted(d)==[1]*(n//2)+[9]*(n//2)
        expected=[1]*(n//2)+[9]*(n//2)
        if e['demand_mode']=='high_variance_random':
            random.Random(e['geometry_seed']+cfg['demand_seed_offset']).shuffle(expected)
        else:
            expected=[1]*n
            nodes=sorted(range(1,n+1),key=lambda i:(obj['coordinates'][i][0],obj['coordinates'][i][1],i))
            for j in nodes[n//2:]:expected[j-1]=9
        assert d==expected
assert len(manifest)==96 and len(new_hashes)==len(set(new_hashes.values()))==32
assert {e['geometry_seed'] for e in manifest}==set(cfg['geometry_seeds'])
assert collections.Counter((m['family'],m['n']) for m in geometry_meta.values())=={('uniform',20):8,('uniform',50):8,('clustered',20):8,('clustered',50):8}
for name,h in read(ROOT/'freeze/PRE_RUN_FREEZE.json')['sha256'].items():assert sha(ROOT/name)==h
for rec in read(ROOT/'freeze/SOURCE_PROVENANCE.json'):
    if rec['byte_identical_to_original']:
        assert sha(ROOT/rec['file'])==sha(rec['source'])==rec['sha256']
assert read(ROOT/'freeze/PRE_GENERATION_FREEZE.json')['utc']<read(ROOT/'freeze/PRE_RUN_FREEZE.json')['utc']<read(ROOT/'raw/STARTED.json')['utc']

def direct(obj,output):
    visits=[];lengths=[];loads=[]
    for route in output['routes']:
        assert len(route)>=3 and route[0]==route[-1]==0
        assert all(isinstance(i,int) and 1<=i<len(obj['demands']) for i in route[1:-1])
        visits.extend(route[1:-1]);load=sum(obj['demands'][i] for i in route[1:-1]);loads.append(load)
        assert load<=obj['capacity']
        for a,b in zip(route,route[1:]):
            x,y=obj['coordinates'][a],obj['coordinates'][b]
            lengths.append(math.hypot(x[0]-y[0],x[1]-y[1]))
    assert sorted(visits)==list(range(1,len(obj['demands'])))
    cost=math.fsum(lengths);assert close(cost,output['reported_cost'])
    return cost,loads

obs={};checked=0;maxerr=0.0
assert len(rows)==len(schedule)==1152
for call,r in zip(schedule,rows):
    assert all(r[k]==v for k,v in call.items())
    assert r['status']=='executed' and r['stop_reason']=='delta_budget' and r['error'] is None and not r['missing_budgets']
    obj=objects[r['input_file']];previous,_=direct(obj,r['baseline'])
    assert [c['budget'] for c in r['checkpoints']]==cfg['checkpoints']
    for cp in r['checkpoints']:
        cost,loads=direct(obj,cp['output']);checked+=1
        assert close(cost,cp['check']['recomputed_cost']) and cp['check']['route_loads']==loads
        maxerr=max(maxerr,abs(cost-cp['output']['reported_cost']))
        assert cp['scoreable'] and cp['check']['accepted'] and cp['check']['feasible'] and cp['check']['cost_consistent']
        assert cp['deltas']==cp['budget']==sum(cp['delta_by_kind'].values())
        assert cost<=previous+1e-9;previous=cost
        key=(r['geometry_id'],r['demand_mode'],r['algorithm'],r['search_seed'],cp['budget'])
        assert key not in obs;obs[key]=cost
assert len(obs)==2304
geos=sorted(geometry_meta);demands=cfg['demand_modes'];algorithms=['_'.join(p) for p in cfg['pairs']];budgets=cfg['checkpoints'];seeds=cfg['search_seeds']
means={};regrets={};ranks={};gains={}
for g in geos:
    for d in demands:
        for b in budgets:
            costs={a:statistics.fmean(obs[g,d,a,s,b] for s in seeds) for a in algorithms}
            for a,v in costs.items():
                means[g,d,a,b]=v
                regrets[g,d,a,b]=100*(v/min(costs.values())-1)
                ranks[g,d,a,b]=1+sum(w<v-1e-9 for w in costs.values())+.5*sum(abs(w-v)<=1e-9 for aa,w in costs.items() if aa!=a)
rr=cfg['primary_algorithm'];competitors=[a for a in algorithms if a!=rr]
for g in geos:
    for b in budgets:
        for a in competitors:gains[g,b,a]=statistics.fmean(100*(means[g,d,a,b]-means[g,d,rr,b])/means[g,d,a,b] for d in demands)
csv_rows=0
for row in csv.DictReader((ROOT/'reports/geometry_demand_aggregates.csv').open()):
    key=row['geometry_id'],row['demand_mode'],row['algorithm'],int(row['budget'])
    assert close(float(row['seed_mean_cost']),means[key]) and close(float(row['relative_regret_pct']),regrets[key]) and close(float(row['midrank']),ranks[key]);csv_rows+=1
groups=[[g for g in geos if (geometry_meta[g]['family'],geometry_meta[g]['n'])==(f,n)] for f in cfg['families'] for n in cfg['customer_counts']]
boot={(b,a):[] for b in budgets for a in competitors};rng=random.Random(cfg['bootstrap_seed'])
for _ in range(cfg['bootstrap_replicates']):
    draw=[gs[rng.randrange(len(gs))] for gs in groups for _ in range(len(gs))]
    for b,a in boot:boot[b,a].append(statistics.fmean(gains[g,b,a] for g in draw))
def pct(vals,p):
    ss=sorted(vals);z=(len(ss)-1)*p;lo=math.floor(z)
    return ss[lo]+(ss[min(lo+1,len(ss)-1)]-ss[lo])*(z-lo)
independent_contrasts=[]
for saved in summary['paired_comparisons']:
    b,a=saved['budget'],saved['competitor'];vals=[gains[g,b,a] for g in geos]
    rec=dict(budget=b,competitor=a,primary=saved['primary'],geometry_count=len(geos),mean_rr_cost_improvement_pct=statistics.fmean(vals),median_pct=statistics.median(vals),min_pct=min(vals),max_pct=max(vals),ci95_lower_pct=pct(boot[b,a],.025),ci95_upper_pct=pct(boot[b,a],.975),wins=sum(v>1e-9 for v in vals),ties=sum(abs(v)<=1e-9 for v in vals),losses=sum(v< -1e-9 for v in vals))
    for k,v in rec.items():assert close(v,saved[k]) if isinstance(v,(float,int)) else v==saved[k], (k,v,saved[k])
    independent_contrasts.append(rec)
for b in budgets:
    for saved in summary['rankings'][str(b)]:
        a=saved['algorithm']
        assert close(saved['mean_relative_regret_pct'],statistics.fmean(regrets[g,d,a,b] for g in geos for d in demands))
        assert close(saved['mean_midrank'],statistics.fmean(ranks[g,d,a,b] for g in geos for d in demands))
assert summary['usable_geometries']==32 and summary['formal_failures']==0 and not summary['excluded_geometries']

# Four selected before opening TRAJECTORIES, written to AUDIT_PLAN.json.
sys.path.insert(0,str(ROOT/'source'));import budget_engine as engine
replays=[];replay_cpu=time.process_time()
for selection in read(OUT/'AUDIT_PLAN.json')['vrp_replay_selections']:
    call=schedule[selection['run_id']];saved=rows[selection['run_id']]
    result=engine.trajectory(engine.from_dict(objects[call['input_file']]),call['pair'],call['search_seed'],cfg)
    # Disk JSON represents checker tuple fields as lists. Compare like serialization.
    result=json.loads(json.dumps(result))
    assert result['stop_reason']==saved['stop_reason']=='delta_budget' and not result['error'] and not result['missing_budgets']
    assert result['baseline']==saved['baseline'] and result['trace']==saved['trace']
    for c,s in zip(result['checkpoints'],saved['checkpoints']):
        for key in ['budget','output','iterations_started','iterations_completed','accepted_improvements','deltas','delta_by_kind','matrix_distances','objective_edges','budget_checks','check','scoreable']:
            assert c[key]==s[key],(selection['run_id'],key)
    replays.append(dict(selection,passed=True,checkpoint_outputs_identical=True,full_trace_identical=True))
replay_cpu=time.process_time()-replay_cpu
primary=next(c for c in independent_contrasts if c['primary'])
negative=[{'geometry_id':g,'rr_cost_improvement_pct':gains[g,40000,'random_cheapest']} for g in geos if gains[g,40000,'random_cheapest']< -1e-9]
strata=[{'family':f,'n':n,'geometries':len(gs),'primary_improvement_pct':statistics.fmean(gains[g,40000,'random_cheapest'] for g in gs)} for (f,n),gs in zip([(f,n) for f in cfg['families'] for n in cfg['customer_counts']],groups)]
report={'status':'passed','new_unique_geometries':len(geos),'old_reference_geometries':len(old_hashes),'old_new_geometry_seed_overlap':0,'old_new_coordinate_overlap':0,'new_inputs_checked':len(manifest),'trajectories_checked':len(rows),'new_checkpoint_outputs_independently_checked':checked,'baseline_outputs_checked':len(rows),'max_objective_absolute_difference':maxerr,'geometry_demand_algorithm_budget_cells_recomputed':csv_rows,'geometry_block_bootstrap_recomputed':cfg['bootstrap_replicates'],'all_six_paired_contrasts_recomputed':True,'geometry_not_trajectory_inference_unit':True,'unchanged_frozen_engine_and_source_verified':True,'prespecified_search_replays':replays,'replay_cpu_seconds':replay_cpu,'primary':primary,'strata':strata,'negative_primary_geometries':negative,'paired_comparisons':independent_contrasts,'cpu_seconds':time.process_time()-START,'historical_trajectories_replayed':0,'external_calls':0,'limits':['New geometry seeds from unchanged synthetic generators; not a new distribution family or real field validation','Bootstrap conditional on selected generators and fixed search seeds','Candidate delta budget does not equal wall time or total FLOPs','Four-method oracle is not global CVRP optimum']}
(OUT/'VRP_AUDIT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['paired_comparisons','prespecified_search_replays']},ensure_ascii=False))
