"""Targeted independent audit, consuming immutable features and observed costs only."""
import collections, hashlib, json, math, pathlib, resource, statistics, time

ROOT = pathlib.Path('/workspace/shared/selector_reject_20261007')
OUT = pathlib.Path(__file__).resolve().parent
resource.setrlimit(resource.RLIMIT_CPU, (15, 16))
START = time.process_time()
read = lambda name: json.loads((ROOT/name).read_text())
lines = lambda name: [json.loads(x) for x in (ROOT/name).read_text().splitlines()]
data = {r['instance_id']: r for r in read('DATA.json')}
plans, fits = read('SPLITS.json'), read('FITS.json')
raw, cal = lines('RAW_PREDICTIONS.jsonl'), lines('RAW_CALIBRATION.jsonl')
cal_idx = {(r['model_id'], r['instance_id']): r for r in cal}
baseline = {(r['run_id'],r['instance_id']):r for r in lines('SOURCE_BASELINE.jsonl')}
close = lambda a,b: math.isclose(a,b,rel_tol=1e-11,abs_tol=1e-11)
max_distance_error = 0.0
scores_checked = 0

def independent_distances(train, query):
    cols = list(zip(*(data[i]['features'] for i in train)))
    means = [statistics.fmean(c) for c in cols]
    variances = [statistics.fmean((v-m)**2 for v in c) or 1.0 for c,m in zip(cols,means)]
    # Algebraically equivalent standardized distance; does not use author fit/predict.
    ds = [math.fsum((a-b)**2/v for a,b,v in zip(data[query]['features'],data[i]['features'],variances)) for i in train]
    nearest = sorted(range(len(train)), key=lambda j:(ds[j],j))[:5]
    return [train[j] for j in nearest], [ds[j] for j in nearest], means, variances

for mid,(p,m) in enumerate(zip(plans,fits)):
    assert mid == m['model_id'] and p['train_ids']==m['train_ids']
    tr,te=p['train_ids'],p['test_ids']
    assert len(tr)==len(set(tr)) and len(te)==len(set(te))
    assert all(data[i]['split']=='train' for i in tr)
    assert all(data[i]['split']=='confirmation' for i in te)
    tg={data[i]['group_id'] for i in tr}; vg={data[i]['group_id'] for i in te}
    assert not tg & vg
    assert not {data[i]['multiset_sha256'] for i in tr}&{data[i]['multiset_sha256'] for i in te}
    if p['track']=='family_holdout':
        assert all(data[i]['family']!=p['fold'] for i in tr)
        assert all(data[i]['family']==p['fold'] for i in te)
    scores=[]
    for group in sorted(tg):
        hold=[i for i in tr if data[i]['group_id']==group]
        keep=[i for i in tr if data[i]['group_id']!=group]
        assert len(hold)==3 and {data[i]['order'] for i in hold}=={'random','ascending','descending'}
        for i in hold:
            neighbors,dist,_,_=independent_distances(keep,i)
            saved=cal_idx[mid,i]
            assert neighbors==saved['neighbor_ids'] and close(dist[-1],saved['d5_squared'])
            max_distance_error=max(max_distance_error,abs(dist[-1]-saved['d5_squared']))
            scores.append(dist[-1]);scores_checked+=1
    threshold=sorted(scores)[math.ceil(.95*len(scores))-1]
    assert close(threshold,m['threshold']) and m['calibration_n']==len(scores)
    sbs=min(range(2),key=lambda k:(sum(data[i]['costs'][k] for i in tr),k))
    rr=[r for r in raw if r['model_id']==mid]
    assert [r['instance_id'] for r in rr]==te
    for r in rr:
        neighbors,dist,means,variances=independent_distances(tr,r['instance_id'])
        assert all(close(a,b) for a,b in zip(means,m['mean']))
        assert all(close(math.sqrt(a),b) for a,b in zip(variances,m['scale']))
        pred=[statistics.fmean(data[i]['costs'][k] for i in neighbors) for k in range(2)]
        knn=sbs if pred[0]==pred[1] else int(pred[1]<pred[0])
        fire=dist[-1]>threshold; gated=sbs if fire else knn
        assert neighbors==r['neighbors'] and all(close(a,b) for a,b in zip(pred,r['predicted_costs']))
        assert all(close(a,b) for a,b in zip(dist,r['squared_distances']))
        assert (sbs,knn,fire,gated)==(r['sbs_index'],r['knn_index'],r['trigger'],r['gated_index'])
        b=baseline[p['source_run_id'],r['instance_id']]
        assert (knn,sbs,neighbors)==(b['selected_index'],b['subset_sbs_index'],b['neighbors'])
        for method,k in [('knn',knn),('gated',gated),('sbs',sbs)]:assert r[method+'_bins']==data[r['instance_id']]['costs'][k]
        assert r['oracle_bins']==min(data[r['instance_id']]['costs'])

def metrics(rr,method):
    vals=[r[method+'_bins'] for r in rr]
    sdiff=[y-r['sbs_bins'] for y,r in zip(vals,rr)]
    kdiff=[y-r['knn_bins'] for y,r in zip(vals,rr)]
    regret=statistics.fmean(y-r['oracle_bins'] for y,r in zip(vals,rr))
    gap=statistics.fmean(r['sbs_bins']-r['oracle_bins'] for r in rr)
    return dict(method=method,n=len(rr),mean_bins=statistics.fmean(vals),regret=regret,delta_vs_sbs=statistics.fmean(sdiff),gap_recovered=None if gap==0 else 1-regret/gap,wins_vs_sbs=sum(x<0 for x in sdiff),ties_vs_sbs=sum(x==0 for x in sdiff),losses_vs_sbs=sum(x>0 for x in sdiff),worst_harm_vs_sbs=max(0,*sdiff),delta_vs_knn=statistics.fmean(kdiff),wins_vs_knn=sum(x<0 for x in kdiff),ties_vs_knn=sum(x==0 for x in kdiff),losses_vs_knn=sum(x>0 for x in kdiff))

def detection(rr):
    fired=[r for r in rr if r['trigger']]
    return dict(n=len(rr),triggers=len(fired),changed_decisions=sum(r['gated_index']!=r['knn_index'] for r in rr),harmful_detected=sum(r['knn_bins']>r['sbs_bins'] for r in fired),harmful_missed=sum(not r['trigger'] and r['knn_bins']>r['sbs_bins'] for r in rr),beneficial_rejected=sum(r['knn_bins']<r['sbs_bins'] for r in fired),neutral_triggers=sum(r['knn_bins']==r['sbs_bins'] for r in fired),bins_rescued=sum(max(0,r['knn_bins']-r['gated_bins']) for r in rr),bins_sacrificed=sum(max(0,r['gated_bins']-r['knn_bins']) for r in rr))

all_metrics=read('CELL_METRICS.json')
independent_summaries=[]
for s in read('SUMMARY.json'):
    rr=[r for r in raw if r['track']==s['track']]
    assert len(rr)==108 and len({r['instance_id'] for r in rr})==108
    assert detection(rr)==s['gate_detection']
    independent_summaries.append({'track':s['track'],'gate_detection':detection(rr),'metrics':[metrics(rr,m['method']) for m in s['metrics']]})
    all_metrics.extend(dict(m,track=s['track']) for m in s['metrics'])
for m in all_metrics:
    rr=[r for r in raw if r['track']==m['track'] and ('family' not in m or (r['family'],r['order'])==(m['family'],m['order']))]
    for k,v in metrics(rr,m['method']).items():
        assert close(v,m[k]) if isinstance(v,(float,int)) else v==m[k], (k,v,m[k])
    if 'family' in m:
        for k,v in detection(rr).items():assert m['gate_'+k]==v
for fn,h in read('FREEZE.json')['files'].items():assert hashlib.sha256((ROOT/fn).read_bytes()).hexdigest()==h
report={'status':'passed','calibration_scores_independently_recomputed':scores_checked,'test_predictions_independently_recomputed':len(raw),'aggregate_rows_independently_recomputed':len(all_metrics),'maximum_calibration_absolute_difference':max_distance_error,'training_only_group_heldout_thresholds':True,'train_test_group_and_multiset_disjoint':True,'source_freeze_unchanged':True,'historical_trajectories_replayed':0,'cpu_seconds':time.process_time()-START,'summaries':independent_summaries,'limits':['Known historical panel, not new blinded testing','95% distance quantile is a heuristic, not an error or OOD guarantee','Negative outcome preserved without tuning']}
(OUT/'SELECTOR_AUDIT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='summaries'},ensure_ascii=False))
