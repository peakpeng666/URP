"""Independent integer-only saved-assignment validation; no policy replay."""
import time,resource
START=time.monotonic();CPU=time.process_time()
resource.setrlimit(resource.RLIMIT_CPU,(20,20));resource.setrlimit(resource.RLIMIT_AS,(2147483648,2147483648))
import json,pathlib,hashlib,base64
from fractions import Fraction
ROOT=pathlib.Path(__file__).resolve().parent;BASE=ROOT.parent
read=lambda p:json.loads(p.read_bytes());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=read(ROOT/'results/report.json');f=read(ROOT/'freeze.json');rows=[];errors=[]
try:
 assert len(r['scores'])==45 and r['actual_pack_dispatches']<=45
 assert read(ROOT/'results/hashes_after.json')==f['sha256']
 assert all(sha(pathlib.Path(p))==h for p,h in f['sha256'].items())
 design=read(ROOT/'data/design_5000.json')['cases'];reg={s:read(ROOT/f'data/regression_{s}_256.json')['cases'] for s in ['development','validation']}
 for x in r['scores']:
  if x['status']!='feasible':continue
  i=x['instance'];items=design[i]['items'] if x['phase']=='design5000' else reg[x['split']][i]['items'];n=len(items)
  stem=f"{x['phase']}_{x['split']}_{i}_{x['method']}";obs=read(ROOT/'results'/(stem+'.observation.json'));b=obs['result'];result=b['result'];a=result['assignment'];res=result['residuals'];raw=base64.b64decode(obs['raw_stdout_base64'],validate=True)
  assert json.loads(raw)==b and hashlib.sha256(raw).hexdigest()==obs['raw_output_sha256']
  assert len(a)==len(res)==n and all(type(v)is int and 0<=v<n for v in a)
  loads=[0]*n
  for item,label in zip(items,a):loads[label]+=item;assert loads[label]<=100
  used=sum(v>0 for v in loads);L1=(sum(items)+99)//100
  assert used==x['used_bins']==result['used_bins'] and L1==x['L1'] and res==[100-v for v in loads]
  assert a==x['assignment'] and res==x['residuals'] and b['status']=='packing_returned' and b['warnings']['complete'] is True
  k=len(read(ROOT/f"programs/{x['method']}.json")['nodes']);assert x['work_units']==n*n+k*sum(result['feasible_counts'])<=n*n*65<=1625000000
  if x['phase']=='regression256':
   previous=read(pathlib.Path(x['prior_source']))['result']['result'];assert all(result[z]==previous[z] for z in ['assignment','residuals','used_bins','feasible_counts','work_units','placements'])
  elif x['method'] in ['BF','EOH']:
   previous=read(pathlib.Path(x['historical_source']));assert all(result[z]==previous[z] for z in ['assignment','residuals','used_bins','feasible_counts'])
  else:assert a==list(range(5000)) and used==5000
  rows.append({'phase':x['phase'],'split':x['split'],'instance':i,'method':x['method'],'used_bins':used,'L1':L1,'passed':True})
 for g in r['groups']:
  matched=[x for x in rows if x['phase']=='design5000' and x['method']==g['method']];assert len(matched)==g['feasible']
  if len(matched)==5:
   total=sum(x['used_bins'] for x in matched);lb=sum(x['L1'] for x in matched);assert total==g['sum_bins'] and lb==g['sum_L1'] and g['paper_percent_excess_exact']==str(Fraction(100*(total-lb),lb))
except Exception as e:errors.append(type(e).__name__+': '+str(e))
result={'passed':not errors,'errors':errors,'saved_assignments_checked':len(rows),'policy_dispatches':0,'rows':rows,'cpu_seconds':time.process_time()-CPU,'wall_seconds':time.monotonic()-START,'source_sha256':sha(pathlib.Path(__file__))}
with (ROOT/'results/independent_audit.json').open('x') as w:json.dump(result,w,indent=2);w.write('\n')
print(json.dumps({k:v for k,v in result.items() if k!='rows'}));raise SystemExit(bool(errors))
