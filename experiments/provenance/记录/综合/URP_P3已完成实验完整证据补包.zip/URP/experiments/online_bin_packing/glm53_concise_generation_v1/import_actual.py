"""Verify delivered non-secret capture evidence; normalize explicit metadata only."""
import hashlib,json,pathlib,datetime
ROOT=pathlib.Path(__file__).resolve().parent;WORK=ROOT.parents[3];BUNDLE=WORK/'glm_generation_transfer/concise_generation_verified'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_bytes())
def save(p,x):
 with p.open('x') as f:json.dump(x,f,indent=2,ensure_ascii=False);f.write('\n')
index=read(BUNDLE/'bundle-index.json');source=read(BUNDLE/'manifest.json');protocol=read(ROOT/'protocol.json')
assert sha(ROOT/'protocol.json')==index['parent_protocol_sha256']==source['parent_protocol_sha256']
assert sha(ROOT/'freeze.json')==index['research_freeze_sha256']==source['research_freeze_sha256']
assert index['candidate_order']==['candidate_01','candidate_02'] and index['execution_status']=='both_predeclared_slots_terminated'
assert sha(BUNDLE/'manifest.json')==index['approved_child_manifest_sha256']
files={};assert len(index['files'])==7
for entry in index['files']:
 rel=pathlib.PurePosixPath(entry['path']);assert not rel.is_absolute() and '..' not in rel.parts
 p=BUNDLE/rel;assert p.is_file() and not p.is_symlink() and p.stat().st_size==entry['bytes'] and sha(p)==entry['sha256']
 assert str(p) not in files;files[str(p)]=sha(p)
assert {str(p.relative_to(BUNDLE)) for p in BUNDLE.rglob('*') if p.is_file()}=={e['path'] for e in index['files']}|{'bundle-index.json'}
files[str(BUNDLE/'bundle-index.json')]=sha(BUNDLE/'bundle-index.json')
records=[]
for slot,src,idx in zip(protocol['generation_slots'],source['candidates'],index['candidates']):
 id=slot['id'];metadata=BUNDLE/f'runs/{id}/metadata.json';m=read(metadata);raw=BUNDLE/f'runs/{id}/response.txt';prompt=BUNDLE/f'prompts/{id}.txt'
 assert m['candidate_id']==idx['candidate_id']==src['id']==id and m['model']==idx['model']==src['model']==slot['model_id']
 assert prompt.read_bytes()==(ROOT/slot['prompt_file']).read_bytes() and sha(prompt)==slot['prompt_sha256']==m['prompt_sha256']==src['prompt_sha256']==idx['prompt_sha256']
 assert sha(raw)==m['response_sha256']==idx['response_sha256'] and raw.stat().st_size==m['response_bytes']==idx['response_bytes']>0
 assert m['configuration_sha256']==src['config_sha256']==idx['configuration_sha256']
 assert m['model_options']=={'reasoningEffort':'low'} and m['steps']==2 and m['max_output_tokens']==16384
 assert m['logical_cli_invocations']==1 and m['outer_retries']==0 and m['tool_events']==0 and m['distinct_model_message_count']==1
 assert m['process_exit_code']==0 and m['finish_reasons']==['stop'] and m['stop_reason'] is None and m['capture_completed_normally'] and m['capture_succeeded']
 assert m['response_is_unmodified_cli_terminal_text'] and not m['response_is_raw_http'] and m['http_attempt_count']=='unknown'
 records.append({'id':id,'terminal':True,'status':'completed','model_id':m['model'],'prompt_sha256':m['prompt_sha256'],'cli_version':m['cli_version'],'payload_provenance':'OpenCode JSON part.text','physical_http_attempts_observed':None,'logical_cli_requests':m['logical_cli_invocations'],'cli_exit_code':m['process_exit_code'],'completed_normally':m['capture_completed_normally'],'tool_event_seen':False,'model_messages':m['distinct_model_message_count'],'truncated':False,'truncation_evidence':'Nonempty unmodified terminal text; capture_succeeded true; exit0; finish_reasons exactly [stop]; no watchdog stop. This is CLI capture evidence, not provider HTTP observation.','steps':m['steps'],'model_options':{'reasoning_effort':m['model_options']['reasoningEffort'],'max_tokens':m['max_output_tokens']},'settings_provenance':'Configured model.options.reasoningEffort low normalized to metadata.reasoning_effort low; configured max_output_tokens normalized to max_tokens. These are configured values, NOT observed HTTP parameters.','configuration_sha256':m['configuration_sha256'],'max_wall_seconds':m['wall_clock_limit_seconds'],'outer_retries':m['outer_retries'],'raw_text_path':str(raw),'raw_text_sha256':sha(raw),'metadata_path':str(metadata),'metadata_sha256':sha(metadata),'generation_wall_seconds':m['wall_clock_seconds'],'token_usage':m['token_usage'],'finish_reasons':m['finish_reasons'],'observed_capture_sampling_metadata':{'temperature':m['temperature'],'top_p':m['top_p'],'seed':m['seed']}})
manifest={'records':records,'source_bundle_index_sha256':sha(BUNDLE/'bundle-index.json'),'source_zip_sha256_parent_verified':'b0bbcea0aa44478a79cb51f09d6a2e5dad6542a2b4b401b034e2a002e3b69f75','settings_note':'Configured settings only; actual physical HTTP count/parameters unavailable. Source manifest is pre-execution record; final metadata and bundle-index establish both terminal captures.','protocol_deviation':'Frozen local protocol says no custom temperature/top_p overrides, capture metadata reports0.7/0.9. Preserved explicitly; parent instructed scoring of this delivered bundle; no edit to original frozen protocol. No causal prompt claim.','new_model_calls_by_import_or_scoring':0}
save(ROOT/'actual_input_manifest.json',manifest);save(ROOT/'import_verification.json',{'verified_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'all7_indexed_files_match_bytes_and_hash':True,'exact_frozen_prompts':True,'source_hashes':files,'manifest_sha256':sha(ROOT/'actual_input_manifest.json'),'model_calls':0,'score_calls':0,'normalization':manifest['settings_note'],'protocol_deviation':manifest['protocol_deviation']})
print(json.dumps({'manifest_sha256':sha(ROOT/'actual_input_manifest.json'),'index_sha256':sha(BUNDLE/'bundle-index.json'),'records':len(records)}))
