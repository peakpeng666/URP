"""Produce a descriptive Chinese report from saved results only."""
import json,pathlib,hashlib
from fractions import Fraction
ROOT=pathlib.Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
r=read(ROOT/'results/report.json');a=read(ROOT/'results/independent_audit.json');c=read(ROOT/'results/completion_accounting.json')
lines=['# GLM 简洁提示：两候选已暴露数据先导','',f"执行状态：{r['state']}；独立保存证据审计通过：{a['passed']}。每模型仅一个候选，不做模型排序、显著性推断或提示因果效果归因。",'', '## 生成与准入']
for g in r['generation']:lines.append(f"- {g['id']} / {g['model_id']}：生成 {g['status']}；准入 {g['admission']}；原因 {g.get('reason','无')}；输出hash {g.get('raw_text_sha256','无')}")
lines+=['', '## 全部固定候选的结果（箱数越少越好）']
for g in r['groups']:
 lines.append(f"- {g['method']} / {g['split']}：可行 {g['feasible_count']}/5")
 if 'sum_bins' in g:lines.append(f"  - 箱数 {g['bins']}，合计 {g['sum_bins']}；BF {g['BF']['sum_bins']}，差 {g['BF']['delta_bins']:+d}；FF {g['FF']['sum_bins']}，差 {g['FF']['delta_bins']:+d}；mean(L1/箱数) {g['exact_mean_L1_over_bins']}；L1是下界而非最优值")
lines+=['', '## 证据与预算',f"- 实际新增评分 {r['actual_score_dispatches']}；策略重放0；已保存基线复核 {r['saved_baseline_assignment_rechecks']}；独立整数负载审计 {a['rechecked_saved_assignments']} 条",f"- 执行预算（含1秒保守启动计费）：{c['measured_after_report']}；另行审计CPU {a['cpu_seconds']:.6f}s、wall {a['wall_seconds']:.6f}s",f"- 前后源/数据/原始生成输出哈希一致：{r['source_and_data_unchanged']}；freeze SHA256 {r['freeze_sha256']}",'- 保留原始正文、原始子进程stdout、warnings、失败与未执行原因；无修复、无重试、无挑选最好返回节点；所有准入的固定候选依原顺序计分','', '## 数据与限制','- 沿用已暴露的5×256开发序列、5×256验证序列，容量100；直接读取先前保存数据，不重新生成或筛选','- 开发：historical_design_5k第0–4序列各前256项；历史seed未在输入内记录，以物化数据与hash复现。验证seed：2026100505300–2026100505304；原生成方式为独立random.Random(seed)调用weibullvariate(45,3)，round后截到[1,100]','- 主比较始终BF；双split均严格少箱才满足预定描述性promising标准。n=1/model不能解释模型总体能力；数据已暴露不能称盲测。短提示与先前失败有多处实验设置变化，不能声称简化提示造成成功','- 数学DAG仍为原64节点/16常量/32768字节合同；无深度限制、语义修复、任意Python执行或新增算法运算。前置空箱、最大分数、first-argmax、dtype与eager-where语义不变','- 这不是完整EoH进化复现。生成用时、模型token与失败证据按generation_ledger单独报告；远程模型CPU未知，不能算作本地CPU','- 原始研究失败没有删除或改写。本文只汇报本轮两个预定槽位，不把历史失败排除后宣称首次成功率','', '## 文件','- protocol.json、freeze.json：生成前冻结的提示、合同与来源','- results/generation_ledger.json、input_manifest.json：真实模型输出来源','- results/report.json：逐实例分配、比较与终态','- results/independent_audit.json：不执行策略的整数负载复核','- results/*observation.json：有界子进程原始证据','- 历史来源：glm53_math_dag_pilot_v1；固定发表控制：published_eoh_scoring_control_v1；本轮不冒充发表公式或GLM总体成功']
with (ROOT/'RESULTS_ZH.md').open('x') as w:w.write('\n'.join(lines)+'\n')
manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(ROOT.rglob('*')) if p.is_file()}
with (ROOT/'artifact_manifest.json').open('x') as w:json.dump(manifest,w,indent=2);w.write('\n')
