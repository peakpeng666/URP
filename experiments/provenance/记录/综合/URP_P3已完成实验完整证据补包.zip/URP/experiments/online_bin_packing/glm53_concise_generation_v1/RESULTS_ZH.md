# GLM 简洁提示：两候选已暴露数据先导

执行状态：incomplete；独立保存证据审计通过：True。每模型仅一个候选，不做模型排序、显著性推断或提示因果效果归因。

## 生成与准入
- candidate_01 / glm-5.3：生成 completed；准入 admitted；原因 无；输出hash db142fdf1525d26033836ae3fdd3cf5fc29224485ac882b1328edfa29710f7c7
- candidate_02 / glm-5.3-flash：生成 completed；准入 structural_rejected；原因 Expecting value: line 1 column 1 (char 0)；输出hash 896b05bf1f2d8ead2aede98dc5fbdeec8037b85da32d2ca2c133d9a867d71650

## 全部固定候选的结果（箱数越少越好）
- candidate_01 / development：可行 5/5
  - 箱数 [256, 256, 256, 256, 256]，合计 1280；BF 546，差 +734；FF 549，差 +731；mean(L1/箱数) 517/1280；L1是下界而非最优值
- candidate_01 / validation：可行 5/5
  - 箱数 [256, 256, 256, 256, 256]，合计 1280；BF 542，差 +738；FF 545，差 +735；mean(L1/箱数) 513/1280；L1是下界而非最优值
- candidate_02 / development：可行 0/5
- candidate_02 / validation：可行 0/5

## 证据与预算
- 实际新增评分 10；策略重放0；已保存基线复核 20；独立整数负载审计 30 条
- 执行预算（含1秒保守启动计费）：{'cpu_seconds': 2.7840471379999996, 'active_wall_seconds': 2.7709157490025973}；另行审计CPU 0.060316s、wall 0.062842s
- 前后源/数据/原始生成输出哈希一致：True；freeze SHA256 59efad9d309aa56f3ef83869097f6269d105c56f1f1a16a75424746eb4c4da4d
- 保留原始正文、原始子进程stdout、warnings、失败与未执行原因；无修复、无重试、无挑选最好返回节点；所有准入的固定候选依原顺序计分

## 数据与限制
- 沿用已暴露的5×256开发序列、5×256验证序列，容量100；直接读取先前保存数据，不重新生成或筛选
- 开发：historical_design_5k第0–4序列各前256项；历史seed未在输入内记录，以物化数据与hash复现。验证seed：2026100505300–2026100505304；原生成方式为独立random.Random(seed)调用weibullvariate(45,3)，round后截到[1,100]
- 主比较始终BF；双split均严格少箱才满足预定描述性promising标准。n=1/model不能解释模型总体能力；数据已暴露不能称盲测。短提示与先前失败有多处实验设置变化，不能声称简化提示造成成功
- 数学DAG仍为原64节点/16常量/32768字节合同；无深度限制、语义修复、任意Python执行或新增算法运算。前置空箱、最大分数、first-argmax、dtype与eager-where语义不变
- 这不是完整EoH进化复现。生成用时、模型token与失败证据按generation_ledger单独报告；远程模型CPU未知，不能算作本地CPU
- 原始研究失败没有删除或改写。本文只汇报本轮两个预定槽位，不把历史失败排除后宣称首次成功率

## 文件
- protocol.json、freeze.json：生成前冻结的提示、合同与来源
- results/generation_ledger.json、input_manifest.json：真实模型输出来源
- results/report.json：逐实例分配、比较与终态
- results/independent_audit.json：不执行策略的整数负载复核
- results/*observation.json：有界子进程原始证据
- 历史来源：glm53_math_dag_pilot_v1；固定发表控制：published_eoh_scoring_control_v1；本轮不冒充发表公式或GLM总体成功
