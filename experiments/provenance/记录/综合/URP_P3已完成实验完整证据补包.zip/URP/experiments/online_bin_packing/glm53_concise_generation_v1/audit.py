"""Check stored assignments with independent integer arithmetic, never run policy."""
import time,resource
START=time.monotonic();CPU=time.process_time()
resource.setrlimit(resource.RLIMIT_CPU,(10,10));resource.setrlimit(resource.RLIMIT_AS,(2147483648,2147483648))
import json,pathlib,hashlib,base64
from fractions import Fraction
ROOT=pathlib.Path(__file__).resolve().parent;BASE=ROOT.parent
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
f=read(ROOT/'freeze.json');r=read(ROOT/'results/report.json');rows=[];errors=[]
try:
 assert len(r['scores'])==20 and r['actual_score_dispatches']<=20 and r['policy_replay_dispatches']==0
 assert r['freeze_sha256']==sha(ROOT/'freeze.json')
 expected={**f['sha256'],**read(ROOT/'results/generation_source_hashes.json')}
 assert read(ROOT/'results/hashes_after.json')==expected and all(sha(pathlib.Path(p))==h for p,h in expected.items())
 by={x['id']:x for x in r['generation']};assert set(by)=={'candidate_01','candidate_02'}
 for m,g in by.items():
  if g['admission']!='admitted':assert all(x['status']=='not_run' and x['reason']=='candidate_not_admitted' for x in r['scores'] if x['method']==m)
 actual_files=list((ROOT/'results').glob('*_candidate_*.observation.json'));assert len(actual_files)==r['actual_score_dispatches']
 allrows=[x for x in r['scores'] if x['status']=='feasible']+read(ROOT/'results/baseline_rechecks.json')
 for x in allrows:
  items=read(BASE/f"glm53_math_dag_pilot_v1/data/{x['split']}.json")['cases'][x['instance']]['items']
  stem=f"{x['split']}_{x['instance']}_{x['method']}";p=ROOT/'results'/(stem+'.observation.json') if x['method'].startswith('candidate_') else pathlib.Path(x['source_observation'])
  obs=read(p);raw=base64.b64decode(obs['raw_stdout_base64'],validate=True);b=obs['result'];a=b['result']['assignment'];res=b['result']['residuals']
  assert json.loads(raw)==b and hashlib.sha256(raw).hexdigest()==obs['raw_output_sha256']
  assert len(a)==len(items)==256 and len(res)==256 and all(type(i)is int and 0<=i<256 for i in a)
  loads=[0]*256
  for item,bin_id in zip(items,a):loads[bin_id]+=item;assert loads[bin_id]<=100
  used=sum(v>0 for v in loads);L1=(sum(items)+99)//100
  assert used==x['used_bins']==b['result']['used_bins'] and L1==x['L1']
  assert res==[100-v for v in loads] and a==x['assignment']
  assert b['status']=='packing_returned' and b['warnings']['complete'] is True
  rows.append({'method':x['method'],'split':x['split'],'instance':x['instance'],'used_bins':used,'L1':L1,'passed':True})
 for g in r['groups']:
  rr=[x for x in rows if x['split']==g['split'] and x['method']==g['method']];assert g['feasible_count']==len(rr)
  if len(rr)!=5:assert 'sum_bins' not in g;continue
  assert g['bins']==[x['used_bins'] for x in rr] and g['sum_bins']==sum(g['bins'])
  assert g['exact_mean_L1_over_bins']==str(sum((Fraction(x['L1'],x['used_bins']) for x in rr),Fraction())/5)
  for m in ['BF','FF']:
   refs=[x for x in rows if x['split']==g['split'] and x['method']==m];assert g[m]['bins']==[x['used_bins'] for x in refs] and g[m]['sum_bins']==sum(g[m]['bins'])
   assert g[m]['delta_bins']==g['sum_bins']-g[m]['sum_bins']
except Exception as e:errors.append(type(e).__name__+': '+str(e))
out={'passed':not errors,'errors':errors,'rechecked_saved_assignments':len(rows),'policy_dispatches':0,'policy_replay_dispatches':0,'rows':rows,'cpu_seconds':time.process_time()-CPU,'wall_seconds':time.monotonic()-START,'audit_source_sha256':sha(pathlib.Path(__file__))}
with (ROOT/'results/independent_audit.json').open('x') as w:json.dump(out,w,indent=2);w.write('\n')
print(json.dumps({k:v for k,v in out.items() if k!='rows'}));raise SystemExit(bool(errors))
