"""Bounded fixed-control validation of a separately versioned5000-item DAG evaluator."""
import time
START=time.monotonic()
import argparse,base64,datetime,hashlib,importlib.util,json,os,pathlib,resource,signal,sys
from fractions import Fraction
sys.dont_write_bytecode=True
ROOT=pathlib.Path(__file__).resolve().parent;BASE=ROOT.parent
resource.setrlimit(resource.RLIMIT_AS,(2147483648,2147483648));resource.setrlimit(resource.RLIMIT_CPU,(90,90))
LIMITS={'RLIMIT_AS':[2147483648,2147483648],'RLIMIT_CPU':[60,60],'RLIMIT_FSIZE':[0,0],'RLIMIT_NOFILE':[32,32]}
WORK_MAX=1625000000
read=lambda p:json.loads(pathlib.Path(p).read_bytes())
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def save(p,d):
 with pathlib.Path(p).open('x') as f:json.dump(d,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
def totals():
 ru=resource.getrusage(resource.RUSAGE_CHILDREN);return {'cpu_seconds':1+time.process_time()+ru.ru_utime+ru.ru_stime,'active_wall_seconds':1+time.monotonic()-START}
def reserve():
 t=totals();return t['cpu_seconds']+62+30<=600 and t['active_wall_seconds']+92+30<=900
class Infrastructure(Exception):pass
class BudgetStop(Exception):pass

def transport(obs):
 if obs.get('returncode')!=0 or obs.get('termination') is not None or obs.get('error') is not None or obs.get('reaped') is not True or obs.get('cpu_evidence_complete') is not True:raise Infrastructure('worker transport or cleanup: '+str({k:obs.get(k) for k in ['returncode','termination','error','reaped']}))
 raw=base64.b64decode(obs['raw_stdout_base64'],validate=True)
 if hashlib.sha256(raw).hexdigest()!=obs['raw_output_sha256'] or len(raw)!=obs['raw_output_bytes'] or json.loads(raw)!=obs['result']:raise Infrastructure('raw stdout identity')

def checked(raw,items,obs):
 from schema import validate_program
 p=validate_program(raw);transport(obs);b=obs['result'];n=len(items)
 if b.get('pid')!=obs['pid'] or b.get('limits')!=LIMITS or b.get('program_sha256')!=p.raw_sha256 or b.get('canonical_program_sha256')!=p.canonical_sha256 or b.get('phase')!='pack':raise Infrastructure('worker identity/limits/phase')
 if type(b.get('work_units')) is not int or not 0<=b['work_units']<=WORK_MAX:raise Infrastructure('work bound')
 w=b['warnings']
 if set(w)!={'events','kinds','complete','incomplete_reason'} or len(w['events'])>12000 or len(w['kinds'])>32:raise Infrastructure('warning envelope')
 for event in w['events']:
  if len(event)!=3 or any(type(x)is not int for x in event) or not 0<=event[0]<n or not 0<=event[1]<len(p.nodes) or not 0<=event[2]<len(w['kinds']):raise Infrastructure('warning event')
 for kind in w['kinds']:
  if kind['category']!='RuntimeWarning' or kind['file']!='interpreter.py' or len(kind['message'].encode())>1024:raise Infrastructure('warning kind')
 if b['status'] in ['numeric_invalid','resource_unresolved','diagnostic_unresolved']:
  if b['result'] is not None or not isinstance(b['error'],dict):raise Infrastructure('failure envelope')
  return {'status':b['status'],'reason':b['error'],'work_units':b['work_units']}
 if b['status']!='packing_returned' or b['error'] is not None or w['complete'] is not True or w['incomplete_reason'] is not None:raise Infrastructure('packing status')
 result=b['result'];checker=module('independent_assignment_checker',BASE/'paper_baseline_v1/src/checker.py')
 try:validation=checker.check_assignment(items,100,result['assignment'],result['used_bins'],result['residuals'])
 except ValueError as e:return {'status':'checker_rejected','reason':str(e)}
 counts=result['feasible_counts']
 if result['placements']!=n or len(counts)!=n or any(type(x)is not int or not 1<=x<=n for x in counts) or result['work_units']!=b['work_units'] or b['work_units']!=n*n+len(p.nodes)*sum(counts):raise Infrastructure('work accounting identity')
 return {'status':'feasible','reason':None,'used_bins':validation['used_bins'],'L1':validation['L1'],'assignment':result['assignment'],'residuals':result['residuals'],'score_elements':sum(counts),'work_units':b['work_units'],'warning_events':len(w['events']),'numeric_intermediates':b['numeric_intermediates'],'worker_cpu_seconds':obs['worker_cpu_seconds'],'worker_wall_seconds':obs['wall_seconds'],'peak_rss_kib':obs['worker_peak_rss_kib']}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--expected-freeze',required=True);a=ap.parse_args()
 if sha(ROOT/'freeze.json')!=a.expected_freeze:raise Infrastructure('freeze identity')
 freeze=read(ROOT/'freeze.json')
 def verify():
  for p,h in freeze['sha256'].items():
   if sha(p)!=h:raise Infrastructure('changed source/data: '+p)
 out=ROOT/'results';out.mkdir(exist_ok=False)
 rows=[{'phase':'regression256','split':s,'instance':i,'method':m,'status':'not_run','reason':'not_reached'} for s in ['development','validation'] for i in range(5) for m in ['BF','EOH','BAD']]+[{'phase':'design5000','split':'historical_design_5k','instance':i,'method':m,'status':'not_run','reason':'not_reached'} for i in range(5) for m in ['BF','EOH','BAD']]
 save(out/'initial_ledger.json',rows);units=[];errors=[];dispatches=0;groups=[];source_ok=False
 def alarm(*_):raise TimeoutError('active deadline reached with30s terminal reserve')
 signal.signal(signal.SIGALRM,alarm);signal.setitimer(signal.ITIMER_REAL,max(.01,869-(time.monotonic()-START)))
 try:
  verify();module('old_integrity',BASE/'math_dag_v1/src/integrity.py').verify(freeze['original_math_freeze_sha256'])
  sys.path.insert(0,str(ROOT/'src'));import runtime
  oldruntime=module('original_runtime',BASE/'math_dag_v1/src/runtime.py')
  # All tests are trusted handwritten code, never model-generated Python.
  for label,rt,path in [('original_units',oldruntime,BASE/'math_dag_v1/tests/run_unit_worker.py'),('new_units',runtime,ROOT/'tests/run_unit_worker.py')]:
   if not reserve():raise BudgetStop('before '+label)
   verify();obs=rt.request({},command=[sys.executable,'-I','-B',str(path)]);save(out/(label+'.observation.json'),obs);transport(obs)
   result=obs['result']
   if result['status']!='completed_finite' or result['result']['successful'] is not True:raise Infrastructure(label+' failed')
   units.append({'label':label,'tests':result['result']['tests'],'cpu_seconds':obs['worker_cpu_seconds'],'wall_seconds':obs['wall_seconds'],'passed':True})
  data={s:read(ROOT/f'data/regression_{s}_256.json')['cases'] for s in ['development','validation']};design=read(ROOT/'data/design_5000.json')['cases'];programs={m:(ROOT/f'programs/{m}.json').read_bytes() for m in ['BF','EOH','BAD']}
  regression_sources={'BF':BASE/'glm53_math_dag_pilot_v1/runs/official_glm53_20261005_01','EOH':BASE/'published_eoh_scoring_control_v1/results','BAD':BASE/'glm53_concise_generation_v1/results'};suffix={'BF':'BF','EOH':'published_EoH','BAD':'candidate_01'}
  for row in rows:
   if not reserve():raise BudgetStop('before '+str({k:row[k] for k in ['phase','instance','method']}))
   verify();m=row['method'];i=row['instance'];s=row['split'];items=design[i]['items'] if row['phase']=='design5000' else data[s][i]['items'];raw=programs[m];name=f"{row['phase']}_{s}_{i}_{m}";request={'mode':'pack','program_json':raw.decode(),'items':items,'capacity':100}
   save(out/(name+'.request.json'),request);row.update(status='dispatched',reason=None);dispatches+=1
   obs=runtime.request(request);save(out/(name+'.observation.json'),obs);row.update(checked(raw,items,obs))
   if row['status']=='feasible':
    if row['phase']=='regression256':
     refpath=regression_sources[m]/f'{s}_{i}_{suffix[m]}.observation.json';ref=read(refpath)['result']['result'];keys=['assignment','residuals','used_bins','feasible_counts','work_units','placements'];row['prior_source']=str(refpath);row['exact_original_pack_result_match']=all(obs['result']['result'][k]==ref[k] for k in keys)
     if not row['exact_original_pack_result_match']:raise Infrastructure('256regression semantic mismatch')
    elif m in ['BF','EOH']:
     refpath=BASE/f'paper_design_panel_v1/slot_{i}_{m}.stdout.json';ref=read(refpath);row['historical_source']=str(refpath);row['historical_bins_match']=row['used_bins']==ref['used_bins'];row['historical_assignment_match']=row['assignment']==ref['assignment'];row['historical_residual_match']=row['residuals']==ref['residuals'];row['historical_feasible_counts_match']=obs['result']['result']['feasible_counts']==ref['feasible_counts']
    else:row['increasing_slack_proof_matches']=row['used_bins']==len(items) and row['assignment']==list(range(len(items)))
   save(out/(name+'.checked.json'),row)
   if row['phase']=='design5000':print(json.dumps({'progress':'design5000','instance':i,'method':m,'status':row['status'],'bins':row.get('used_bins'),'cpu_seconds':row.get('worker_cpu_seconds')}),flush=True)
  for m in ['BF','EOH','BAD']:
   selected=[r for r in rows if r['phase']=='design5000' and r['method']==m];g={'method':m,'feasible':sum(r['status']=='feasible' for r in selected),'denominator':5}
   if g['feasible']==5:
    bins=[r['used_bins'] for r in selected];lb=sum(r['L1'] for r in selected);total=sum(bins);g.update(bins=bins,sum_bins=total,sum_L1=lb,paper_percent_excess_exact=str(Fraction(100*(total-lb),lb)),paper_percent_excess=float(Fraction(100*(total-lb),lb)),exact_mean_L1_over_bins=str(sum((Fraction(r['L1'],r['used_bins']) for r in selected),Fraction())/5))
   groups.append(g)
 except Exception as e:errors.append(type(e).__name__+': '+str(e))
 finally:
  signal.setitimer(signal.ITIMER_REAL,30)
  for row in rows:
   if row['status']=='dispatched':row.update(status='infrastructure_failure',reason='interrupted_dispatch')
   elif row['status']=='not_run':row['reason']='budget_stop' if errors and errors[-1].startswith('BudgetStop') else 'stopped_infrastructure'
  try:verify();save(out/'hashes_after.json',{p:sha(p) for p in freeze['sha256']});source_ok=True
  except Exception as e:errors.append('terminal:'+str(e))
  evidence_match=all(r.get('historical_bins_match',True) and r.get('historical_assignment_match',True) and r.get('historical_residual_match',True) and r.get('historical_feasible_counts_match',True) and r.get('increasing_slack_proof_matches',True) for r in rows)
  t=totals();within=t['cpu_seconds']<=600 and t['active_wall_seconds']<=900
  report={'state':'completed' if not errors and all(r['status']=='feasible' for r in rows) else 'incomplete','ready_for_bounded_5000_evaluation':not errors and evidence_match and source_ok and within and len(units)==2 and all(r['status']=='feasible' for r in rows),'errors':errors,'all_historical_and_proof_checks_match':evidence_match,'unit_workers':units,'actual_pack_dispatches':dispatches,'regression_pack_dispatches':sum(r['status']!='not_run' for r in rows if r['phase']=='regression256'),'full5000_pack_dispatches':sum(r['status']!='not_run' for r in rows if r['phase']=='design5000'),'new_independent_datasets':0,'model_calls':0,'scores':rows,'groups':groups,'sources_unchanged':source_ok,'budget':t,'within_budget':within,'freeze_sha256':sha(ROOT/'freeze.json'),'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
  save(out/'report.json',report);save(out/'completion_accounting.json',{'measured_after_report':totals(),'startup_allowance_seconds':1,'terminal_reserve_seconds':30,'preparation_excluded':True});signal.setitimer(signal.ITIMER_REAL,0)
 print(json.dumps({k:v for k,v in report.items() if k not in ['scores']},indent=2),flush=True)
 return 0 if report['ready_for_bounded_5000_evaluation'] else 1
if __name__=='__main__':raise SystemExit(main())
