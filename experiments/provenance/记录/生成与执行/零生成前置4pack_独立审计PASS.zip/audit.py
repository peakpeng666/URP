"""Read-only evidence audit: no candidate, worker, solver, or archived code is executed."""
import json,hashlib,zipfile,pathlib,time,resource,sys
from fractions import Fraction
start=time.monotonic(); cpu=time.process_time()
resource.setrlimit(resource.RLIMIT_CPU,(8,9))
p=pathlib.Path(sys.argv[1]); out=pathlib.Path(sys.argv[2]);z=zipfile.ZipFile(p)
sha=lambda b:hashlib.sha256(b).hexdigest()
canon=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
J=lambda n:json.loads(z.read(n))
H=lambda n:sha(z.read(n))
checks=[]
def ck(name,condition):
 checks.append({'check':name,'passed':bool(condition)})
 if not condition: raise AssertionError(name)
ck('original ZIP SHA256',sha(p.read_bytes())=='ccb822b4d18c1be34723e4f6cba15b0716c15ae0325dc55340ae11a9332bc2bc')
m=J('MANIFEST.json');ck('151 evidence entries plus manifest, no duplicate names',len(m)==151 and len(z.namelist())==152 and len(set(z.namelist()))==152 and set(m)==set(z.namelist())-{'MANIFEST.json'})
ck('151 manifest bytes and hashes',all(H(n)==r['sha256'] and len(z.read(n))==r['bytes'] for n,r in m.items()))
for n in ['SOURCE_FREEZE.json','PREPARATION_SEAL.json','technical-r1/SOURCE_FREEZE.json','forward-r1/SOURCE_FREEZE.json']:
 f=J('precheck/'+n)['files'];ck(n+' file hashes',all(H('precheck/'+name)==h for name,h in f.items()))
ck('35 preparation seal files',len(J('precheck/PREPARATION_SEAL.json')['files'])==35)
s=J('precheck/forward-r1/SEAL.json');ck('forward authorization and seal chain',s['preparation_seal_sha256']==H('precheck/PREPARATION_SEAL.json') and s['source_freeze_sha256']==H('precheck/forward-r1/SOURCE_FREEZE.json') and s['authorization_sha256']==H('precheck/EXECUTION_AUTHORIZATION.json'))
methods=J('precheck/METHODS.json')['methods'];ck('exact two fixed method sources',set(methods)=={'BF','published_EoH'} and all(sha(v['code'].encode())==v['code_sha256'] for v in methods.values()))
plan=J('precheck/PLAN.json');acts=['W_BF','W_published_EoH','U_published_EoH','U_BF'];ck('four fixed planned packs zero models', [r['id'] for r in plan['packs']]==acts and plan['models']==0 and plan['no_model_calls'] and not plan['training_main_authorized'])
guard=z.read('precheck/forward-r1/guard.py').decode();ck('guard exact whitelist, durable claim and retained old HALT',"science=['W_BF','W_published_EoH','U_published_EoH','U_BF']" in guard and 'A in science' in guard and "read('HALT.json')['action']=='toy_BF'" in guard and "put('claims/'+A+'.json',claim)" in guard)
rows=[]; allcpu=0; sciencecpu=0
for n in m:
 if n.startswith('precheck/results/'):
  r=J(n);v=r['resources'];ck(n+' driver reaped',v['driver_reaped']);allcpu+=v['driver_wait4_inclusive_CPU']
for a in acts:
 payload_name='precheck/payload_'+a+'.json';pyl=J(payload_name);r=J('precheck/results/'+a+'.json');c=J('precheck/claims/'+a+'.json');rep=pyl['original_pack_report'];w=rep['worker'];sup=rep['supervisor_evidence'];binding=rep['binding'];family=pyl['family'];idx={'W':0,'U':1}[family]
 dat=J('precheck/inputs/'+family+'.json');items=dat['items'];capacity=dat['capacity'];im=next(x for x in J('precheck/INPUT_MANIFEST.json')['entries'] if x['family']==family)
 ck(a+' result claim payload binding',r['claim_sha256']==sha(canon(c))==binding['claim_sha256'] and r['payload_sha256']==H(payload_name))
 ck(a+' exact frozen input',len(items)==1000 and capacity==100 and all(type(i)is int and 1<=i<=capacity for i in items) and sha(canon(dat))==pyl['input_sha256']==im['input_sha256'] and H('precheck/inputs/'+family+'.json')==im['file_sha256'])
 eid=binding['claim_id']+'/instance/'+str(idx)
 ck(a+' execution ID W0/U1 binding',binding['claim_id']==sha(canon([plan['id'],a])) and all(x['execution_id']==eid and x['instance_index']==idx for x in [rep,w,sup]) and w['registry_binding']==binding)
 ck(a+' fixed source and post-gate admission',pyl['code_sha256']==methods[pyl['method']]['code_sha256']==binding['source_sha256']==w['source_sha256']==w['admission']['source_sha256'] and w['source_after_host_gate'] and w['admission']['admitted'])
 ck(a+' three complete success exits',r['status']=='passed' and r['resources']['driver_exit_code']==0 and r['resources']['driver_reaped'] and w['returncode']==sup['returncode']==0 and w['reaped'] and sup['reaped'] and w['cleanup_error'] is None and sup['cleanup_error'] is None and rep['outcome']=='ok')
 ck(a+' wait4 CPU inclusive consistency',abs(sup['wait4_cpu_seconds']-sup['actual_supervisor_cpu_seconds']-w['cpu_seconds'])<1e-6 and r['resources']['driver_wait4_inclusive_CPU']>=sup['wait4_cpu_seconds'])
 rr=rep['result'];ass=rr['assignment'];ck(a+' 1000 integer assignments',len(ass)==1000 and all(type(x)is int and 0<=x<1000 for x in ass))
 loads=[0]*1000
 for weight,binid in zip(items,ass):loads[binid]+=weight;assert loads[binid]<=capacity
 used=sum(v>0 for v in loads);lb=(sum(items)+capacity-1)//capacity;f=str(Fraction(lb,used))
 ck(a+' independent integer replay/checker',used==rr['used_bins']==pyl['checker']['used_bins'] and [capacity-v for v in loads]==rr['remaining'] and sum(loads)==sum(items) and sha(canon(ass))==pyl['checker']['assignment_sha256'] and pyl['checker']['checker_status']=='passed' and lb==pyl['L1'])
 expected={'W_BF':(417,400),'W_published_EoH':(410,400),'U_BF':(537,514),'U_published_EoH':(547,514)};ck(a+' expected bins/LB',(used,lb)==expected[a])
 rows.append({'action':a,'n':len(items),'total_weight':sum(items),'bins':used,'L1':lb,'F':f,'execution_id':eid,'driver_CPU':r['resources']['driver_wait4_inclusive_CPU'],'supervisor_wait4_CPU':sup['wait4_cpu_seconds'],'worker_CPU':w['cpu_seconds']});sciencecpu+=r['resources']['driver_wait4_inclusive_CPU']
old=J('precheck/results/toy_BF.json');diag=J('precheck/TOY_FAILURE_READONLY_DIAGNOSIS.json');oldclaim=J('precheck/claims/toy_BF.json')
ck('original failure preserved and charged',old['status']=='blocked_no_retry' and old['resources']['driver_exit_code']==1 and J('precheck/HALT.json')['action']=='toy_BF' and oldclaim['no_retry'] and oldclaim['CPU_reserve']==20 and oldclaim['wall_reserve']==10 and diag['observed']['nested_supervisor_exit_code'] is None)
for a in ['toy_BF_technical_r1','toy_published_EoH']:
 t=J('precheck/payload_'+a+'.json')['original_pack_report'];ck(a+' new successful separate toy',J('precheck/results/'+a+'.json')['status']=='passed' and t['worker']['reaped'] and t['supervisor_evidence']['reaped'] and t['worker']['returncode']==t['supervisor_evidence']['returncode']==0)
claims=[J(n) for n in m if n.startswith('precheck/claims/')];cpu_res=sum(c['CPU_reserve'] for c in claims);wall_res=sum(c['wall_reserve'] for c in claims)
ck('11 consumed claims incl old failure',len(claims)==11 and cpu_res==690 and wall_res==576)
ck('total reservation remains within cap',(cpu_res+22+10,wall_res+60+20)==(722,656) and 722<=900 and 656<=700)
ck('driver CPU totals no double counting',abs(sciencecpu-8.329597)<1e-6 and abs(allcpu-10.528843)<1e-6)
close=J('precheck/forward-r1/CLOSEOUT.json');ck('no invented all-in or main authorization',close['costs']['exact_global_all_in_CPU'] is None and not close['main76_or8_generation_authorized'])
report={'status':'PASS_WITH_SCOPE_LIMITS','source_zip_sha256':sha(p.read_bytes()),'evidence_files':151,'checks':checks,'rows':rows,'assignments_independently_replayed':4000,'scientific_driver_tree_CPU':sciencecpu,'all_eleven_reaped_driver_tree_CPU':allcpu,'reservation':{'CPU':722,'wall':656,'cap_CPU':900,'cap_wall':700},'limitations':['One sequence per family, two sequences total; descriptive interface exploration only.','No family efficacy, 5000-item scale, achievable improvement, or solver optimality claim.','Old BF toy nested supervisor termination remains unknown; static execution-ID mismatch is not an observed exit receipt.','Driver wait4 CPU includes descendants; do not add worker/supervisor CPU again. Control-plane overhead and guard tail are not measured global all-in CPU.','Archive consistency and recorded receipts verified; no historical process re-execution or independent observation claimed.','Main 8-model/76-pack study remains unauthorized.'],'audit_execution':{'CPU_before_write':time.process_time()-cpu,'wall_before_write':time.monotonic()-start,'candidate_or_solver_runs':0,'model_calls':0,'read_only_inputs':True}}
out.mkdir(parents=True,exist_ok=True);(out/'AUDIT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
(out/'独立审计.txt').write_text('结论：PASS_WITH_SCOPE_LIMITS。151份证据文件及ZIP摘要一致，35项准备seal、冻结链与4项白名单通过。\n独立整数重建4000项分配：W BF417/pub410，LB400；U BF537/pub547，LB514。4pack driver/supervisor/worker退出、wait4、W0/U1绑定和source-after-gate通过。\n旧BF toy失败、HALT、claim及20CPU/10wall占用保留；其监督器历史终局仍未知。technical-r1另立toy成功，不恢复旧失败。\n预算722CPU/656wall≤900/700；4科学driver树8.329597CPU，全部11已reaped driver树10.528843CPU，均不可冒称all-in。\n每族仅1条1000项序列，只证链路探索；不证族效能、5000规模、可实现改进或最优性。未重跑候选/solver；主案8模型/76pack仍未授权。\n')
print(json.dumps({'status':report['status'],'checks':len(checks),'rows':rows,'audit_execution':report['audit_execution']},ensure_ascii=False))
