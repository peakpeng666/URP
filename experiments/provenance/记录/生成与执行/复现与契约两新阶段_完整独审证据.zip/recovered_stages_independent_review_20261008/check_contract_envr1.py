# Read-only evidence verification. No fixture/extractor/runtime imports or execution.
import json,hashlib,math,zipfile,datetime,collections
from pathlib import Path
R=Path('/workspace/shared/recovered_stages_independent_review_20261008');C=Path('/workspace/shared/generation_contract_validation_20261008/environment_rebind_r1');P=C.parent
seen={};bad=[];checks=0

def sha(p):
 p=Path(p);h=hashlib.sha256(p.read_bytes()).hexdigest();seen[str(p)]=h;return h
def read(p):sha(p);return json.loads(Path(p).read_text())
def ck(v,msg):
 global checks
 checks+=1
 if not v:bad.append(msg)
def dig(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
f=read(C/'FREEZE.json');plan=read(C/'PLAN.json');start=read(C/'START.json');complete=read(C/'RUN_COMPLETE.json');cases=read(C/'CASES.json');auth=read(C/'EXECUTION_AUTHORIZATION.json')
ck(sha(C/'FREEZE.json')=='809e4b2452fa0728c3b864ebdf7c65d0d336b86f470836575f9a3e75a4fc4afa','parent-attested freeze hash')
for rel,h in f['files'].items():ck(sha(C/rel)==h,'frozen file '+rel)
for p,h in f['runtime_files'].items():ck(sha(p)==h,'runtime frozen path '+p)
ck(auth['freeze_sha256']==sha(C/'FREEZE.json') and auth['authorized'],'auth exact freeze')
zpath=P/'generation_contract_envr1_PREEXEC_20261008.zip';ck(sha(zpath)=='48cf1d4a950f6d2bec878b57d94d051812faec4ea6cad6adb8ca536ea71c8dd6','preexec archive attested SHA')
with zipfile.ZipFile(zpath) as z:
 ck(z.testzip() is None,'preexec archive CRC')
 for rel in z.namelist():
  if not rel.endswith('/'):ck(z.read(rel)==(C/rel).read_bytes(),'preexec archive unchanged '+rel)
rb=read(C/'PREEXEC_ARCHIVE_READBACK.json');ck(rb['downloaded_byte_for_byte_match'] and rb['drive_file_id']=='1ywT-PB3LHUnAljOgCwGgsv_R0HZcZ-Jp','prior cloud readback record')
oldrt=Path(read(C/'ENVIRONMENT_REBIND_PROOF.json')['old_runtime']);rt=C/'frozen_runtime';changes=[]
for op in oldrt.iterdir():
 if op.is_file():
  if sha(op)!=sha(rt/op.name):changes.append(op.name)
ck(sorted(changes)==['pre_run_freeze.json','worker_freeze.json'],'exactly two environmental freeze files changed')
ow=read(oldrt/'worker_freeze.json');nw=read(rt/'worker_freeze.json');of=read(oldrt/'pre_run_freeze.json');nf=read(rt/'pre_run_freeze.json')
ck({k:v for k,v in ow.items() if k!='dependencies'}=={k:v for k,v in nw.items() if k!='dependencies'},'worker freeze only dependencies changed')
ck({k:v for k,v in of.items() if k not in ['dependencies','worker_freeze_sha256']}=={k:v for k,v in nf.items() if k not in ['dependencies','worker_freeze_sha256']},'pre-run only dependencies + cross-reference')
ck(nf['worker_freeze_sha256']==sha(rt/'worker_freeze.json'),'new cross-reference')
changed=[];same=[]
ck(set(ow['dependencies'])==set(nw['dependencies']),'dependency path set identical')
for p,h in nw['dependencies'].items():
 ck(sha(p)==h,'actual new dependency '+p)
 (same if ow['dependencies'][p]==h else changed).append(p)
ck(len(changed)==469 and all(x.endswith('.pyc') for x in changed) and len(same)==526,'469 pyc changes,526 same')
ck(nw['dependencies']==nf['dependencies'],'both new dependency maps identical')
# Input, expectation and source identities retained; only destination paths change.
prior=read(P/'CASES.json');draft=read(P/'recovered_contract_reference/OFFLINE_CONTRACT_TEST_DRAFT.json')
ck(cases['source_draft_sha256']==sha(P/'recovered_contract_reference/OFFLINE_CONTRACT_TEST_DRAFT.json'),'original draft binding')
for new,old,d in zip(cases['cases'],prior['cases'],draft['source_cases']):
 for k in ['id','input_data','expected','source_sha256','source_text']:ck(new[k]==old[k],'unchanged case '+new['id']+k)
 ck(new['expected']==d['expected'] and new['input_data']==d['input_data'],'original draft expectation '+new['id'])
 ck(sha(new['source_path'])==new['source_sha256']==f['candidate_fixture_source_hashes'][new['id']],'source hash '+new['id'])
for new,old in zip(cases['format_cases'],prior['format_cases']):
 for k in ['id','raw_sha256','expected_extraction']:ck(new[k]==old[k],'unchanged format '+new['id']+k)
 ck(sha(new['raw_path'])==new['raw_sha256'],'format bytes '+new['id'])
counts=collections.Counter();rows=[];claimids=set()
ck([x['id'] for x in complete['results']]==plan['actions'],'complete action order')
ck(len(list((C/'claims').glob('*.json')))==24,'exactly24 claims')
for action in plan['actions']:
 claim=read(C/'claims'/f'{action}.json');res=read(C/'results'/f'{action}.json');p=read(C/f'payload_{action}.json')
 ck(claim['attempt']==1 and claim['no_retry'] and claim['freeze_sha256']==sha(C/'FREEZE.json'),'claim '+action)
 ck(res['payload_sha256']==sha(C/f'payload_{action}.json'),'payload hash '+action)
 ck(res['status']=='completed' and res['driver_exit']==0 and res['driver_reaped'] and not res['timed_out'] and not res['adopted_reaped'],'completed/reaped '+action)
 ck(p['driver_rlimits']=={'as':[134217728,536870912],'cpu':[1,2],'nofile':[64,64]},'driver inherited limits '+action)
 ck(p['single_attempt'] and p['toy_count']==0 and p['driver_parent_pid']==start['pid'],'driver claim parent '+action)
 ck(res in complete['results'],'summary raw equality '+action)
 if action=='FORMAT':
  ck(len(p['results'])==6,'six format receipts')
  for row,case in zip(p['results'],cases['format_cases']):
   ck(row['id']==case['id'] and row['raw_sha256']==case['raw_sha256'] and row['attempts']==1,'format input association '+row['id'])
   status=row['observed']['status'];expect=case['expected_extraction'];ck(status==('passed' if expect.startswith('passed') else 'format_failure'),'format outcome '+row['id'])
   if status=='passed':ck(row['observed']['source_sha256']==case['expected_source_sha256'],'format unchanged extracted hash '+row['id'])
   counts['format_cases']+=1
  continue
 w=p['worker'];ck(w['reaped'] and w['returncode']==0 and w['cleanup_error'] is None,'worker cleanup '+action)
 ck(w['host_observed_limits']['cpu_seconds']==[1,1] and w['host_observed_limits']['address_space_bytes']==[536870912,536870912],'worker limits '+action)
 ck(w['security']['NoNewPrivs']==1 and w['security']['Seccomp']==2 and w['security']['Threads']==1,'worker sandbox flags '+action)
 if action=='DUMMY':ck(not w['source_sent'] and w['admission'] is None and w['steps']==0,'dummy zero source');continue
 case=next(x for x in cases['cases'] if x['id']==action);e=case['expected'];o=p['observed'];binding=w['registry_binding']
 ck(binding['batch_id']==plan['id'] and binding['slot_id']==action and binding['claim_id']==dig([plan['id'],action]) and binding['claim_sha256']==dig(claim),'worker unique claim binding '+action);claimids.add(binding['claim_id'])
 ck(binding['source_sha256']==case['source_sha256']==w['source_sha256']==p['source_sha256'] and binding['registry_sha256']==sha(C/'CASES.json') and w['dependency_freeze_sha256']==sha(rt/'worker_freeze.json'),'worker source/freeze binding '+action)
 ck(o['admission']==e['bounded_admission'],'actual vs frozen admission '+action)
 if e['bounded_admission']=='static_rejection':
  ck(w['admission']['admitted']==False and w['admission']['kind']=='static' and w['steps']==0 and w['arithmetic_steps_checked']==0 and o['numeric']=='not_run_ineligible','negative no score '+action);counts['static_rejections']+=1
 else:
  ck(w['admission']['admitted'] and w['arithmetic_steps_checked']==1,'one admitted score request '+action);counts['admitted']+=1
  ex=e['numeric_outcome'];ck(o['numeric']==ex['status'],'numeric status '+action)
  if ex['status']=='passed':
   vals=o['scores'];ck(o['first_max_index']==ex['first_max_index'] and o['first_max_index']==max(range(len(vals)),key=lambda i:vals[i]),'argmax '+action)
   ck(len(vals)==len(case['input_data']['bins']) and all(math.isfinite(x) for x in vals),'finite shape '+action)
   if 'scores' in ex:ck(vals==ex['scores'],'exact expected score '+action)
   if action=='C20':ck(all(abs(x-y)<=1e-12 for x,y in zip(vals,[0,math.log(20),math.log(60)])) and o['arithmetic_events']['instance']['divide']>=1,'C20 expected log/arithmetic event')
   counts['numeric_pass']+=1
  else:ck(o['exception_category']==ex['exception_category']=='NumericContractError' and w['numerical_failure']['exception_kind']=='NumericContractError','expected numeric failure '+action);counts['expected_numeric_failure']+=1
 rows.append({'id':action,'admission':o['admission'],'numeric':o['numeric'],'steps':w['steps'],'score_requests':w['arithmetic_steps_checked']})
ck(len(claimids)==22,'22 unique worker claims')
old=read(C/'prior_attempt/payload_DUMMY.json');oldcomp=read(C/'prior_attempt/RUN_COMPLETE.json');ck(old['worker']['returncode']==70 and not old['worker']['source_sent'] and old['worker']['steps']==0 and old['worker']['reaped'],'retained failed old dummy')
cpu=math.fsum(x['inclusive_driver_CPU'] for x in complete['results']);ck(abs(cpu-complete['inclusive_driver_CPU'])<1e-10,'inclusive CPU counted once')
ck(sum(plan['CPU_per_action'].values())+4==75 and plan['budget']['prior_and_new_configured_CPU_upper_sum']==82<=90,'configured CPU reservations');ck(sum(plan['wall_per_action'].values())==141 and 174+6<=180,'wall reservations')
out={'status':'PASS_WITH_SCOPE_LIMITATIONS' if not bad else 'ISSUES_FOUND','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':checks,'failures':bad,'counts':dict(counts),'dependency_differences':{'pyc':len(changed),'unchanged':len(same),'missing':0},'changed_runtime_files':changes,'preexecution_zip_sha256':sha(zpath),'frozen_claim_sha256':sha(C/'FREEZE.json'),'CPU':{'new_driver_inclusive_once':cpu,'new_controller':complete['controller_CPU'],'old_failed_dummy_driver_inclusive':oldcomp['inclusive_driver_CPU'],'old_failed_controller':oldcomp['controller_CPU'],'bounded_execution_measured_combined':cpu+complete['controller_CPU']+oldcomp['inclusive_driver_CPU']+oldcomp['controller_CPU'],'configured_two_phase_envelope':82,'exact_preparation_recovery_analysis_all_in':None},'rows':rows,'caveats':['New environment-binding phase; original failed dummy retained, no old model candidates rerun.','28 handwritten interface fixtures are not scientific packing evaluation or evidence of prompt-quality improvement.','Memory limits and peaks are per-process; aggregate RSS and hard aggregate cap not measured.','wait4 driver CPU includes reaped worker CPU, which must not be added again. Preparation/recovery/analysis all-in cost remains unmeasured.','Outer 174-second timeout is declared in plan; observed short executions, per-action enforcement and worker/driver rlimits were checked from code/receipts; no long-timeout test was rerun.'],'review_execution_count':0}
(R/'CONTRACT_ENVR1_REVIEW.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');(R/'CONTRACT_READ_EVIDENCE_SHA256.json').write_text(json.dumps(seen,indent=2)+'\n');print(json.dumps(out,ensure_ascii=False,indent=2))
