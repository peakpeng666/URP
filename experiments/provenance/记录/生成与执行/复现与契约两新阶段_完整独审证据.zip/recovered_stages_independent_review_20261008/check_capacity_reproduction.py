# Independent saved-record arithmetic/hashes only. Never imports or runs experiment code.
import json,math,hashlib,zipfile,collections,datetime
from pathlib import Path
from fractions import Fraction as F
R=Path('/workspace/shared/recovered_stages_independent_review_20261008');B=Path('/workspace/shared/capacity_cross_structure_reproduction_20261008_r1');seen={};bad=[];checks=0

def sha(p):p=Path(p);h=hashlib.sha256(p.read_bytes()).hexdigest();seen[str(p)]=h;return h
def read(p):sha(p);return json.loads(Path(p).read_text())
def ck(v,msg):
 global checks
 checks+=1
 if not v:bad.append(msg)
def near(a,b,msg,tol=1e-9):ck(abs(a-b)<=tol,msg)
# The additional 36 hashes below are manually transcribed from THIS reviewer's
# pre-loss tool output at 12:05:12, exec_command chunk f0614a. They are NOT
# obtained from the new reproduction freeze and do not reconstruct old raw bytes.
prior36='''04 7249fc13b0d501bceab3e3fa22859813bb06a8c5783037e8ead655f74b6b79eb
05 cd11602e9b7be362da04e86481ac3d1f58ed3b9097145010b7e3661bab645181
06 cc698442170a042459b32cba5a5469f82ba141e025fe95a20096e79906a6566b
07 61492553f86758c1219c558f098ff70d598c1696139f8eed76a49237f01f6868
08 54e6cbdee5e2e1c9b963eee36d450e82e5d05c878463b7224012c1420ec233be
09 799fe35985230bdbf77a8a16d4db85d7e7356c0daed26bfa88ecb80e57fae410
10 4fbf8fcdf5fc486ecc48efaf235f8bfdbf964b87795d4989bade0149fa40ce88
11 39ad60173125c1aeaf2223b51e80035eacf43c3ba0ce153ae277743ddcd228ad
12 25d19afb48faaf614ac082dbe8aa7e71bafcab889499b05a3ea977b4136ef141
16 090b445f44f882421f97b2169e66e169d47e3d5b90f5501d8188e22eb7a5552d
17 d6be89566209eb0ef79307d02ba3ea7526550fa346b9d38525a5c1d899bf8208
18 ac62a9212c75efb21866fddad702751dab2fa02191298c8152ab4ff866228d58
19 fc0c95a2a23f8e3b09afe0e0ac949484b0aaef7bc324a60604744717af9f486f
20 d2a6c460d38aaad9d75b31fadded845adfcf8dd156e5b56db862b38e48a1e132
21 c6a13475c1ed26f12c7b7202ed23dc9a15b8e10d779ad8d0c87c1cd7b6465e56
22 1b2f96815d8edbf0bd07e439e97428897a987355012306eb54e8b7ea5aff50d7
23 1b6f5e959fcff9e49be6c384aca7303ae31b678c8489ac257173465aff02f6ba
24 17400046d2c3914a7242d5ab4613f3543f434f706552672cc39c9b384c1c2e35
28 c07593ae0d4727cc336df983e36364dc3e392c4abddca49452fe9adf4314e506
29 56434ec91a4a292d31d74c4e09369ad2d2ae669cb9601094ec822896b9b7dea2
30 64c3572219b99694c202353a5cc80d858288f5a83cee7c474759b37848255e76
31 64330dd400e3a7a60dbe61dce8280e5c0e7651408d3f8aeeb0f4b13bc7e4d169
32 944038d3c7e0fc5862a3c1752510e646063a4770a6bfda6ae8f5e60bc161a640
33 02b3b0cc2221e00423f1c7913389292fec45a8b6dfcd16784ccb8bc8217a0c19
34 1d801c697fd90dd92cce54acff2715372e48e314ae58a77197296007c8e42271
35 d04737b150f09186dc405a33e5203daea87aeb625221705ea2f401dd60e7c2f1
36 3dac4805c7c2c3dbd5fb66155628c3d14890296243868941f3a60ba3db1d7a62
40 30935ded0c7c22a75957f7bdcdd5392f095c4d7274ef760b2295f3cd83e52af5
41 777c32dc4d930aed609a0f0d538c0979fbee022e780d5490a11a5c646d6b80a3
42 ab77299b27b7ee5b357f4e232422824bd8b77da7158ed3bc8c46509bad4a1d7d
43 d3be1c18a9cc20ad1cfbfe518e54d4e35f46e2bd61cd557cf274e60b6a611b16
44 53b147c26c48796b1414d5a653001e32bf49a04537ca8573913f48db714ca835
45 3c600d8d9706db1be00d482adf67e802368e84533c21f9fec80228e22e5813a6
46 85ee23591a812371e3f738cf7bebd356e82ff632d427e94afa032dc9480d29a5
47 0d6e148580f7343e0e98314ec55b7bcb10e776ce7ec08d6d906966c2fac15064
48 859b29a0985485b786fa7d0d2a41b6bad53f19e7db68e5abecd90989823d0202'''
extra=dict(x.split() for x in prior36.splitlines());known=read(B/'provenance/KNOWN_PRIOR_INPUT_HASHES.json')['hashes'];recovered={}
for p in sorted((B/'input').glob('*.json')):
 oldhash=known.get(p.stem,extra.get(p.stem[1:3]));ck(oldhash==sha(p),'historical input hash '+p.stem);recovered[p.stem]=oldhash
ck(len(extra)==36 and len(known)==12 and len(recovered)==48,'36 additional +12 known hashes')
proof={'source':'Reviewer pre-loss visible exec_command tool output, chunk f0614a, 2026-10-08 12:05:12 UTC; original PRE_RUN_FREEZE.json was printed up to 7000 characters including every input entry','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reproduction_pre_execution_known_count':12,'additional_hashes_recovered_after_execution':36,'matching_input_count':48,'historical_input_hashes':recovered,'boundary':'Only historical hash evidence recovered, not old raw results, original full archive or original generator source hash. Do not amend old preparation record retroactively.'}
(R/'RECOVERED_HISTORICAL_INPUT_HASHES.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
f=read(B/'freeze/PRE_RUN_FREEZE.json');s=read(B/'raw/STARTED.json');done=read(B/'raw/FINISHED.json');matrix=read(B/'freeze/MATRIX.json');schedule=read(B/'freeze/SCHEDULE.json')
for p,h in f['sha256'].items():ck(sha(B/p)==h,'frozen '+p)
ck(s['freeze_sha256']==sha(B/'freeze/PRE_RUN_FREEZE.json'),'run-start freeze identity');ck(f['utc']<s['utc']<done['utc'],'freeze-start-end chronology')
namespace='capacity-cross-structure-reproduction-20261008-r1';ck(s['claim_namespace']==done['claim_namespace']==namespace,'new namespace')
zp=Path(str(B)+'_PREEXECUTION_SNAPSHOT.zip');ck(sha(zp)=='97c6a0467761831d41d122d85807df9d3968a1dddb3bb8397928f219741a1521','cloud-attested preexec archive hash')
with zipfile.ZipFile(zp) as z:
 ck(z.testzip() is None,'preexec ZIP CRC')
 for name in z.namelist():
  if not name.endswith('/'):ck(z.read(name)==(B.parent/name).read_bytes(),'preexec member same '+name)
of=read(B/'freeze/ORACLE_SOURCE_FREEZE.json')
# This declared oracle was added after the initial cloud snapshot; retain its own freeze.
for key,val in of.items():
 if key.endswith('sha256') and isinstance(val,str) and len(val)==64:pass
protocol=read(B/'freeze/REPRODUCTION_PROTOCOL.json');ck(protocol['new_outputs_must_not_be_presented_as_prior_outputs'],'new scientific claim caveat')
origin=read(B/'provenance/SOURCE_ORIGIN.json');oldroot=Path(origin['old_root'])
for name in ['capacity_solver.py','pruned_solver.py','waste_solver.py','audit.py']:ck(sha(B/'source'/name)==sha(oldroot/'source'/name),'restored old algorithm '+name)
insts={x['instance_id']:read(B/'input'/f"{x['instance_id']}.json") for x in matrix};norm={(x['K'],tuple(sorted(F(d,x['capacity']) for d in x['demands'][1:]))) for x in insts.values()};ck(len(norm)==48,'48 normalized structures')
records=[json.loads(x) for x in (B/'raw/results.jsonl').read_text().splitlines()];ck(sha(B/'raw/results.jsonl')==done['results_sha256'],'raw hash');ck(len(records)==len(schedule)==432 and len({x['call_id'] for x in records})==432,'432 unique scheduled calls')
summary={};prunes=success=0;maxerr=0;bykey={}
def diagnostic(row):return (row['diagnostic'] or {}).get('capacity_partition',{}) if row['endpoint']=='initialize_256' else row['diagnostic'] or {}
def groups(gs,x,label,complete=True):
 ids=[i for g in gs for i in g];ck(len(ids)==len(set(ids)) and all(1<=i<=x['n'] for i in ids),label+' unique valid IDs')
 if complete:ck(sorted(ids)==list(range(1,x['n']+1)),label+' full coverage')
 ck(len(gs)<=x['K'] and all(sum(x['demands'][i] for i in g)<=x['capacity'] for g in gs),label+' capacity/vehicles');return ids
for expected,row in zip(schedule,records):
 cid=row['call_id'];x=insts[row['instance_id']];ck(all(row[k]==v for k,v in expected.items()),cid+' frozen schedule');ck(row['claim_namespace']==namespace,cid+' namespace');ck(row['input_sha256']==sha(B/'input'/f"{row['instance_id']}.json"),cid+' input hash')
 stdout=read(B/f'raw/calls/{cid}.stdout');ck(all(row[k]==v for k,v in stdout.items()),cid+' stdout record');ck(row['process_returncode']==0,cid+' process exit');ck(not (B/f'raw/calls/{cid}.stderr').read_text(),cid+' stderr')
 dg=diagnostic(row);ck(dg.get('nodes',0)<=row['node_limit'],cid+' node cap');ck(len(dg.get('prune_trace',[]))==dg.get('prunes',0),cid+' trace completeness')
 if row['status']=='SUCCESS':
  success+=1
  if row['output']:
   routes=row['output']['routes'];ck(all(r[0]==r[-1]==0 for r in routes),cid+' depot');gs=[r[1:-1] for r in routes];coords=x['coordinates'];cost=math.fsum(math.dist(coords[a],coords[b]) for r in routes for a,b in zip(r,r[1:]));maxerr=max(maxerr,abs(cost-row['output']['reported_cost']));near(cost,row['output']['reported_cost'],cid+' route score',1e-8)
  else:gs=row['groups']
  groups(gs,x,cid)
 else:ck(row['status'] in ['NODE_LIMIT','INITFAIL'] and dg.get('limit_reached') and dg.get('outcome')=='NODE_LIMIT',cid+' unknown failure')
 order=sorted(range(1,x['n']+1),key=lambda i:(-x['demands'][i],i))
 for t in dg.get('prune_trace',[]):
  ids=groups(t['groups'],x,cid+' prune',False);res=[x['capacity']-sum(x['demands'][i] for i in g) for g in t['groups']];remain=[x['demands'][i] for i in order[t['depth']:]];ck(set(ids)==set(order[:t['depth']]),cid+' DFS prefix')
  ck(t['remaining']==remain and t['residual']==res and t['depth']==len(ids),cid+' full saved state');U=sum(res)-sum(remain);m=min(v for v in remain if v>0);W=sum(v for v in res if 0<v<m);ck(U==x['K']*x['capacity']-sum(x['demands']) and W>U,cid+' prune necessity');prunes+=1
 key=row['endpoint']+'/'+row['arm'];v=summary.setdefault(key,{'success':0,'nodes':0,'prunes':0,'CPU':0.,'partition_CPU':0.,'zero_CPU':0});v['success']+=row['status']=='SUCCESS';v['nodes']+=dg.get('nodes',0);v['prunes']+=dg.get('prunes',0);v['CPU']+=row['measured_cpu_seconds'];v['partition_CPU']+=(dg.get('cpu_seconds',0) if row['endpoint']=='initialize_256' else row['measured_cpu_seconds']);v['zero_CPU']+=row['measured_cpu_seconds']==0;bykey[(row['instance_id'],row['endpoint'],row['arm'])]=row
witness=0
for p in (B/'witness').glob('*.json'):groups(read(p)['groups'],insts[p.stem],'witness '+p.stem);witness+=1
paired={}
for end in ['partition_256','partition_4096','initialize_256']:
 d=collections.Counter()
 for iid,x in insts.items():
  a,t,b=[bykey[(iid,end,arm)] for arm in ['capacity_solver','pruned_solver','waste_solver']]
  ck(a['status']==t['status'] and a['output']==t['output'] and a['groups']==t['groups'] and diagnostic(a).get('nodes',0)==diagnostic(t).get('nodes',0),'baseline-tight '+iid+end)
  d['added_success']+=b['status']=='SUCCESS' and a['status']!='SUCCESS';d['lost_success']+=a['status']=='SUCCESS' and b['status']!='SUCCESS'
  delta=diagnostic(b).get('nodes',0)-diagnostic(a).get('nodes',0);d['fewer_nodes' if delta<0 else 'more_nodes' if delta>0 else 'equal_nodes']+=1
  if x['family']=='nontrigger_high_slack':ck(x['K']*x['capacity']-sum(x['demands'])>=x['K']*(min(x['demands'][1:])-1) and diagnostic(b).get('prunes',0)==0,'control '+iid+end)
 paired[end]=dict(d)
child=math.fsum(x['process_cpu_seconds'] for x in records);near(child,done['per_call_cpu_sum_seconds'],'per-call math fsum');near(child,done['children_cpu_seconds'],'baseline-adjusted children');near(child,done['children_cpu_final_absolute_seconds']-done['children_cpu_initial_seconds'],'absolute counter delta');near(s['children_cpu_initial_seconds'],done['children_cpu_initial_seconds'],'same initial baseline')
# Check stored independent oracle records and bound arithmetic, without optimization.
oracle=read(B/'reports/ORACLE.json');toy=[json.loads(x) for x in (B/'raw/toy_states.jsonl').read_text().splitlines()];tp=[json.loads(x) for x in (B/'raw/toy_partition.jsonl').read_text().splitlines()]
ck(len(toy)==40346 and len(tp)==2268,'oracle case counts');ck(sha(B/'raw/toy_states.jsonl')==oracle['toy_states_sha256'] and sha(B/'raw/toy_partition.jsonl')==oracle['toy_partition_sha256'],'oracle raw hashes')
for t in toy:
 ds=t['demands'];rs=t['residual'];pos=[d for d in ds if d>0];U=sum(rs)-sum(ds);block=bool(ds) and (U<0 or (bool(pos) and sum(r for r in rs if 0<r<min(pos))>U));ck(block==t['new_reject'] and not ((t['new_reject'] or t['tight_reject']) and t['oracle_feasible']),'toy saved predicate/truth')
ck(all(t['solver_feasible']==[t['oracle_feasible']]*3 for t in tp),'saved toy complete partition truth')
ck({x['instance_id'] for x in oracle['main_exact']}=={k for k,v in insts.items() if v['n']<=16},'predeclared main oracle scope')
out={'status':'PASS_WITH_SCOPE_LIMITATIONS' if not bad else 'ISSUES_FOUND','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':checks,'failures':bad,'claim_namespace':namespace,'freeze_sha256':sha(B/'freeze/PRE_RUN_FREEZE.json'),'preexec_zip_sha256':sha(zp),'raw_results_sha256':sha(B/'raw/results.jsonl'),'structures':48,'calls':432,'successful_outputs_checked':success,'witnesses_checked':witness,'prune_states_checked':prunes,'max_route_score_error':maxerr,'summary':summary,'paired':paired,'historical_identity':{'known_before_execution':12,'additional_prior_hashes_recovered_by_reviewer_after_execution':36,'input_hashes_now_matched_to_historical_tool_output':48,'old_generator_original_file_hash_known':False,'old_raw_results_recovered':False},'CPU':{'children_initial':done['children_cpu_initial_seconds'],'children_final_absolute':done['children_cpu_final_absolute_seconds'],'per_call_and_delta':child,'parent':done['parent_cpu_seconds'],'parent_plus_children':child+done['parent_cpu_seconds']},'oracle_review':'40346 saved bounds arithmetically checked;2268 stored solver truth comparisons and12 main oracle scope checked; no oracle recomputation by reviewer','scope':['Independent reproduction claim, not a new independent random sample and not recovery of old raw result bytes.','Original preparation stated12 matched36unknown; post-run reviewer recovery of additional historical hashes is appended, never retroactively changing pre-execution knowledge.','Original new generator/runner byte identity remains unproved.','Node-limit failure is unknown; unique synthetic structures do not establish population generalization.','One-run short CPU timing with zeros is not robust speed evidence.','No candidate/solver/oracle/generator ran during this review.']}
(R/'CAPACITY_REPRODUCTION_REVIEW.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');(R/'CAPACITY_READ_EVIDENCE_SHA256.json').write_text(json.dumps(seen,indent=2)+'\n');print(json.dumps(out,ensure_ascii=False,indent=2))
