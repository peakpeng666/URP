import json,hashlib,zipfile,datetime,math
from pathlib import Path
R=Path('/workspace/shared/recovered_stages_independent_review_20261008');B=Path('/workspace/shared/capacity_cross_structure_reproduction_20261008_r1');C=Path('/workspace/shared/generation_contract_validation_20261008');bad=[];checks=0

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def ck(v,msg):
 global checks
 checks+=1
 if not v:bad.append(msg)
packages=[(C/'generation_contract_validation_20261008_FINAL.zip',C,'d29818d65d5d38d1453493963c82d67a25f1bc6712691cf6beca80626538580d'),(Path(str(B)+'_REPORT_AND_EVIDENCE.zip'),B.parent,'fa78e37d0210a5fbe09c15361e0715b4fb546a74a36e371307c25a3aeb26f5c2')];audit=[]
for zp,root,h in packages:
 ck(sha(zp)==h,'ZIP author hash '+str(zp))
 with zipfile.ZipFile(zp) as z:
  ck(z.testzip() is None,'ZIP CRC '+str(zp));count=0
  for name in z.namelist():
   if name.endswith('/'):continue
   ck(z.read(name)==(root/name).read_bytes(),'ZIP member identity '+name);count+=1
 audit.append({'path':str(zp),'bytes':zp.stat().st_size,'sha256':h,'members_checked':count})
for line in (B/'FINAL_SHA256SUMS.txt').read_text().splitlines():
 h,p=line.split(None,1);ck(sha(B/p.lstrip('*'))==h,'capacity final manifest '+p)
of=read(B/'freeze/ORACLE_SOURCE_FREEZE.json');orr=read(B/'reports/ORACLE.json');start=read(B/'raw/STARTED.json')
ck(sha(B/'source/oracle.py')==of['oracle_source_sha256'],'supplemental oracle source hash');ck(of['utc']<orr['utc']<start['utc'],'supplemental oracle frozen before oracle and main results');ck(orr['claim_namespace']==start['claim_namespace'],'oracle new namespace')
rt=C/'environment_rebind_r1/frozen_runtime';old=Path(read(C/'environment_rebind_r1/ENVIRONMENT_REBIND_PROOF.json')['old_runtime']);ow=read(old/'worker_freeze.json');nw=read(rt/'worker_freeze.json');unchanged=[p for p in nw['dependencies'] if ow['dependencies'][p]==nw['dependencies'][p]];ck(all(not p.endswith('.pyc') for p in unchanged),'526 unchanged dependencies nonpyc')
a=read(C/'deliverables/ACTUAL_RESULTS.json');ck(a['admission_counts']=={'passed':9,'static_rejection':13} and a['numeric_counts']=={'passed':7,'not_run_ineligible':13,'numeric_failure':2} and a['format_counts']=={'passed':2,'format_failure':4},'final actual summary counts')
ck((C/'deliverables/VALIDATED_MINIMAL_EXAMPLE.py').read_bytes()==(C/'environment_rebind_r1/sources/C01.txt').read_bytes(),'minimal example exact tested bytes');ck((C/'deliverables/VALIDATED_NUMPY_EXAMPLE.py').read_bytes()==(C/'environment_rebind_r1/sources/C02.txt').read_bytes(),'numpy example exact tested bytes')
reports={}
for p,h in [(C/'deliverables/REPORT_zh.txt','d834a8aaa6a2132eb05fb82201b11d8da63722fd7a63da1ffa013dbd7bdfcee9'),(C/'deliverables/GENERATOR_CONTRACT_EN_v1.txt','db74944a8de386fda2274a556c085bf155abda87d56a2cac83fd344150531965'),(B/'reports/REPORT_REPRODUCTION_ZH.txt','0db8ce0a72c78db733c96fd3f0b750098e5789d976e2be7ea8dc8924be2e0a26')]:ck(sha(p)==h,'final report identity '+str(p));reports[str(p)]=h
out={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_WITH_SCOPE_LIMITATIONS' if not bad else 'ISSUES_FOUND','checks':checks,'failures':bad,'packages':audit,'reports':reports,'report_scope_review':['Contract report correctly distinguishes 28 expected outcomes from28 successful programs, preserves old failed dummy, distinguishes rebind from original environment recovery, and makes no algorithm performance or full security claim.','Proposed English generation contract is an unsent conservative appendix. C01/C02 examples exactly equal tested source bytes. It does not amend current frozen prompts.','Capacity report numerical counts and corrected CPU agree with independent raw arithmetic. Its 12 known/36 unknown description reflects preparation-time evidence; deliver alongside RECOVERED_HISTORICAL_INPUT_HASHES.json, which records post-run recovery of remaining36 hashes from the reviewer prior tool output.','Original raw results and full original archive remain lost. New results are separate reproducibility evidence, not new independent samples.']}
(R/'FINAL_PACKAGE_REVIEW.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out,indent=2))
