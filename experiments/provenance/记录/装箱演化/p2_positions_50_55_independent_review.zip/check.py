"""Read-only ZIP/JSON/hash review. Never imports or executes candidate/runner code."""
from pathlib import Path, PurePosixPath
import argparse, ast, collections, datetime, hashlib, json, time, zipfile

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read_archive(path):
    raw = path.read_bytes()
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        names = z.namelist()
        assert len(names) == len(set(names))
        assert all(not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts for n in names)
        payload = {n: z.read(n) for n in names}
    manifest = json.loads(payload['FILE_MANIFEST.json'])
    assert set(payload) == set(manifest) | {'FILE_MANIFEST.json'}
    for name, rec in manifest.items():
        assert len(payload[name]) == rec['bytes']
        assert sha(payload[name]) == rec['sha256']
    return payload, {'bytes': len(raw), 'sha256': sha(raw), 'members': len(payload),
                     'member_hashes_verified': len(manifest), 'CRC_pass': True,
                     'manifest_covers_all_payload_files': True}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--data-zip', required=True, type=Path)
    ap.add_argument('--audit-zip', required=True, type=Path)
    ap.add_argument('--reference-dir', required=True, type=Path)
    ap.add_argument('--prior-reviews', required=True, type=Path)
    ap.add_argument('--output', required=True, type=Path)
    args = ap.parse_args()
    started = time.process_time()
    data, dmeta = read_archive(args.data_zip)
    audit, ameta = read_archive(args.audit_zip)
    assert (dmeta['bytes'], ameta['bytes']) == (106179, 15503)
    assert (dmeta['member_hashes_verified'], ameta['member_hashes_verified']) == (34, 9)
    baseline = args.prior_reviews / 'p2_minimal_batch8_review' / 'data'
    for name in ('runner.py', 'frozen_inputs.json'):
        assert data['executor/' + name] == (args.reference_dir / name).read_bytes()
        assert data['executor/' + name] == (baseline / 'executor' / name).read_bytes()
    f = json.loads(data['executor/frozen_inputs.json'])
    config_bytes = data['frozen_requested_configuration.raw.json']
    assert config_bytes == f['config_raw'].encode('utf-8')
    assert config_bytes == (baseline / 'frozen_requested_configuration.raw.json').read_bytes()
    requested = {'effort':'high','max_completion_tokens':64000,'model':'glm-5.3',
                 'outer_retries':0,'paid_provider_fallback':False,'steps':2,
                 'temperature':0.7,'tools':False,'top_p':0.9,'wall_seconds':900}
    assert f['freeze']['configuration'] == requested
    assert data['COLLECTION_RECORD.json'] == audit['COLLECTION_RECORD.json']
    collection = json.loads(data['COLLECTION_RECORD.json'])
    assert collection['approved_runner_SHA256'] == sha(data['executor/runner.py'])
    assert collection['frozen_inputs_SHA256'] == sha(data['executor/frozen_inputs.json'])
    assert collection['configuration'] == requested
    report = json.loads(audit['BATCH_REPORT.json'])
    assert report['positions'] == [50,55] and report['configuration'] == requested
    assert report['runner_SHA256'] == collection['approved_runner_SHA256']
    assert report['frozen_inputs_SHA256'] == collection['frozen_inputs_SHA256']
    assert report['data_Drive_receipt']['sha256'] == dmeta['sha256']
    assert report['data_Drive_receipt']['bytes'] == dmeta['bytes']
    assert report['data_Drive_receipt']['Drive_ID'] == '1UIWGHewy1iEvnfnmR93AoyLcNjy1UaPQ'
    frozen_slots = f['slots'][49:55]
    expected_ids = {s['record']['slot_id'] for s in frozen_slots}
    actual_ids = {n.split('/')[1] for n in data if n.startswith('ledger/')}
    assert len(frozen_slots) == 6 and actual_ids == expected_ids
    prior_dispatch_path = next((baseline / 'ledger').glob('*/dispatch.json'))
    prior_dispatch = json.loads(prior_dispatch_path.read_text())
    reported = {s['position']: s for s in report['slots']}
    assert set(reported) == set(range(50,56))
    results = []
    previous_end = None
    for slot in frozen_slots:
        rec, pack = slot['record'], slot['pack']
        prefix = 'ledger/' + rec['slot_id'] + '/'
        dispatch = json.loads(data[prefix+'dispatch.json'])
        result = json.loads(data[prefix+'result.json'])
        resource = json.loads(data[prefix+'resource_observation.json'])
        prompt, answer = data[prefix+'prompt.txt'], data[prefix+'answer.txt']
        assert prompt == pack['prompt'].encode('utf-8')
        assert sha(prompt) == rec['prompt_sha256'] == pack['prompt_sha256'] == dispatch['prompt_sha256']
        assert sha(config_bytes) == rec['config_file_sha256'] == dispatch['config_sha256']
        assert dispatch['configuration'] == pack['configuration'] == requested
        assert dispatch['frozen_inputs_sha256'] == sha(data['executor/frozen_inputs.json'])
        assert dispatch['position'] == rec['position'] == result['position'] == resource['position']
        assert dispatch['order'] == rec['order']
        assert dispatch['arm'] == rec['arm'] == pack['arm']
        assert dispatch['slot_id'] == rec['slot_id'] == pack['slot_id'] == result['slot_id'] == resource['slot_id']
        assert dispatch['cli_version'] == prior_dispatch['cli_version']
        assert dispatch['binary_sha256'] == prior_dispatch['binary_sha256']
        assert dispatch['safe_environment_overrides']['OPENCODE_EXPERIMENTAL_OUTPUT_TOKEN_MAX'] == '64000'
        cmd = dispatch['command']
        assert cmd[cmd.index('--model')+1] == 'zhipuai-coding-plan/glm-5.3'
        assert cmd[cmd.index('--format')+1] == 'json'
        assert '--pure' in cmd and dispatch['stdin_file'] == 'prompt.txt'
        assert not dispatch['fixture_only'] and not result['fixture_only']
        assert sha(answer) == result['answer_sha256'] and len(answer) == result['answer_bytes']
        assert result['cli_process_started'] and result['requested_timeout_seconds'] == 900
        assert not result['capture_issues'] and result['wall_seconds'] > 0
        assert result['scientific_validity'] == 'not_evaluated'
        if result['client_state'] == 'timeout':
            category = 'timeout_empty'
            assert result['exit_code'] == -9 and not answer and result['finish_reasons'] == []
            assert 900 <= result['wall_seconds'] < 901
            assert all(v is None for v in result['cli_reported_tokens'].values())
            assert result['cli_reported_usage_records'] == []
            assert resource['explicit_client_timeout_is_failure'] is True
        else:
            category = 'stop_nonempty'
            assert result['client_state'] == 'exited' and result['exit_code'] == 0
            assert result['finish_reasons'] == ['stop'] and len(answer) > 0
            assert result['wall_seconds'] < 900
            assert resource['explicit_client_timeout_is_failure'] is False
        assert result['provider_usage'] is None and result['provider_cost'] is None
        assert result['physical_http_attempts'] is None and result['provider_outcome'] == 'unknown'
        assert resource['model_capture_wall_seconds'] == result['wall_seconds']
        assert resource['local_inclusive_wall_seconds'] >= result['wall_seconds']
        assert resource['historical_balance_or_whole_CPU_cap_certified'] is False
        assert resource['provider_CPU_seconds'] is None
        r = reported[result['position']]
        for key in ('slot_id','client_state','exit_code','finish_reasons','answer_bytes','answer_sha256','capture_issues','cli_reported_tokens','wall_seconds'):
            assert r[key] == result[key]
        assert r['original_order'] == rec['order'] and r['arm'] == rec['arm']
        start = dispatch['dispatch_boundary_utc_seconds']
        if previous_end is not None:
            assert start >= previous_end - 0.1
        previous_end = start + result['wall_seconds']
        results.append({'position':result['position'],'slot_id':result['slot_id'],
                        'category':category,'answer_bytes':len(answer),'answer_sha256':sha(answer),
                        'wall_seconds':result['wall_seconds'],'exit_code':result['exit_code'],
                        'finish_reasons':result['finish_reasons'],'CLI_reported_tokens':result['cli_reported_tokens'],
                        'prompt_sha256':sha(prompt),'dispatch_boundary_utc_seconds':start,
                        'dispatch_utc':datetime.datetime.fromtimestamp(start,datetime.timezone.utc).isoformat(),
                        'recorded_end_utc':datetime.datetime.fromtimestamp(start+result['wall_seconds'],datetime.timezone.utc).isoformat()})
    counts = collections.Counter(x['category'] for x in results)
    assert counts == {'stop_nonempty':5,'timeout_empty':1}
    assert report['terminal_count'] == 6 and report['client_successes'] == 5
    assert report['nonempty_public_answers'] == 5 and report['explicit_client_timeout_failures'] == 1
    assert report['empty_public_answer_terminals'] == [55]
    assert report['length_finish_terminals'] == [] and report['other_client_terminals'] == 0
    assert report['admissions_scores_heldout_performed'] is False
    # These are already reviewed history summaries, not a re-audit of older batches.
    prior1 = json.loads((args.prior_reviews/'p2_minimal_batch1_review/REVIEW.json').read_text())
    prior2 = json.loads((args.prior_reviews/'p2_minimal_batch2_review/REVIEW.json').read_text())
    assert prior1['CLI_terminal_successes'] == 6 and prior2['nonempty_public_answers'] == 4
    prior8 = json.loads((args.prior_reviews/'p2_minimal_batch8_review/REVIEW.json').read_text())
    previous = prior8['cumulative_using_previously_reviewed_history']
    cumulative = {
        'positions_2_to_55_terminal': previous['positions_2_to_49_terminal'] + len(results),
        'positions_2_to_55_nonempty': previous['positions_2_to_49_nonempty'] + counts['stop_nonempty'],
        'P2_including_previously_reviewed_first_slot_terminal': previous['P2_including_previously_reviewed_first_slot_terminal'] + len(results),
        'P2_nonempty': previous['P2_nonempty'] + counts['stop_nonempty'],
        'P2_length_empty': previous['P2_length_empty'],
        'P2_client_timeout_empty': previous['P2_client_timeout_empty'] + counts['timeout_empty'],
        'original_132_logical_generation_terminal': previous['original_132_logical_generation_terminal'] + len(results),
        'historical_first_slot_and_batches_reused_not_reexecuted': True}
    assert cumulative['P2_including_previously_reviewed_first_slot_terminal'] == 55
    assert cumulative['P2_nonempty'] == 46 and cumulative['P2_client_timeout_empty'] == 8
    for n in ['CONTINUATION_CONTROLLER.py','TRANSPORT_RECOVERY_CONTINUATION.json','CONTINUATION_CONTROL_SESSION.json']:
        assert audit[n] == (args.prior_reviews/'p2_minimal_batch8_review/audit'/n).read_bytes()
    prefix49_end = datetime.datetime.fromisoformat(prior8['slots'][-1]['recorded_end_utc']).timestamp()
    assert results[0]['position']==50 and results[0]['dispatch_boundary_utc_seconds']>prefix49_end
    # Bind recorded command paths to the same immutable slot claim directories.
    for slot in frozen_slots:
        prefix='ledger/'+slot['record']['slot_id']+'/'
        dispatch=json.loads(data[prefix+'dispatch.json'])
        path='/workspace/urp132-minimal-generation-r1/ledger/'+slot['record']['slot_id']
        assert 'HOME='+path+'/home' in dispatch['command']
        assert dispatch['command'][dispatch['command'].index('--dir')+1] == path+'/work'
    recovery = json.loads(audit['TRANSPORT_RECOVERY_CONTINUATION.json'])
    session = json.loads(audit['CONTINUATION_CONTROL_SESSION.json'])
    snapshot = json.loads(audit['STATUS_SNAPSHOT.json'])
    code = audit['CONTINUATION_CONTROLLER.py'].decode()
    tree = ast.parse(code)
    assert recovery['original_collector_observed_not_running'] is True and recovery['active_OpenCode_observed'] == 0
    assert recovery['earlier_terminal_positions'] == [1,49] and recovery['unresolved_slot_directories'] == []
    assert recovery['original_unstarted_positions'] == [50,60] and recovery['new_logical_CLI_launches_maximum'] == 11
    assert recovery['total_new_logical_CLI_launches_maximum_in_original_authorization'] == 59
    assert recovery['same_approved_runner_SHA256'] == sha(data['executor/runner.py'])
    assert recovery['same_frozen_inputs_SHA256'] == sha(data['executor/frozen_inputs.json'])
    assert recovery['same_configuration'] == requested and recovery['same_resource_caps'] == collection['resource_caps']
    assert recovery['same_unique_ledger'] == collection['unique_persistent_ledger'] == session['sole_ledger']
    assert recovery['original_controller_final_SELF_measurement'] is None and recovery['original_controller_exit_status'] is None
    assert recovery['no_old_HALT_INIT_or_claim_write'] is True and recovery['credential_values_read_or_saved'] is False
    assert session['launch_sent_once'] is True and session['existing_positions_1_49_never_replayed'] is True
    assert session['original_unstarted_positions'] == [50,60] and session['original_scope_new_CLI_maximum'] == 59
    assert any(isinstance(n,ast.For) and isinstance(n.iter,ast.Call) and isinstance(n.iter.func,ast.Name) and n.iter.func.id=='range' and [ast.literal_eval(x) for x in n.iter.args]==[50,61] for n in ast.walk(tree))
    for fragment in ("data['slots'][:49]", "collection.launch_abnormality(result)", "folder / 'prompt.txt'", "data['slots'][49:]", "'A continuation slot already exists; never replay'", "collection.OLD_OBSERVED_CPU + prior_observed_cpu", "collection.OLD_OBSERVED_LOCAL + collection.FIRST_OBSERVED_CAPTURE_WALL", "runner.run_one(data, collection.LEDGER, position, [collection.BINARY])", "collection.journal_sha() != collection.OLD_JOURNAL_SHA"):
        assert fragment in code
    assert "folder.mkdir()" in data['executor/runner.py'].decode()
    assert snapshot['new_terminal_positions'] == list(range(2,57)) and snapshot['current_position'] == 57
    assert snapshot['original_controller_final_SELF_measurement'] is None and snapshot['original_controller_exit_status'] is None
    assert snapshot['server_terminal_and_cancellation'] == 'unknown'
    assert 'ledger/'+f['slots'][49]['pack']['slot_id']+'/dispatch.json' in data
    continuation_checks = {
        'status':'PASS_static_guard_and_record_consistency_WITH_OBSERVATION_LIMITS',
        'archived_recovery_record_sha256':sha(audit['TRANSPORT_RECOVERY_CONTINUATION.json']),
        'archived_controller_sha256':sha(audit['CONTINUATION_CONTROLLER.py']),
        'same_runner_frozen_inputs_config_ledger_and_caps':True,
        'reads_prior1_49_results_and_checks_terminal_and_prompt_before_continuation':True,
        'requires_no50_60_directory_before_loop':True,
        'dispatch_loop_exactly50_through60':True,
        'original_runner_atomic_mkdir_prevents_reclaiming_existing_slot':True,
        'known_prior_slot_resource_observations_carried_forward':True,
        'missing_original_controller_final_cpu_and_exit_remain_unknown':True,
        'host_process_absence_recorded_but_not_independently_probed_by_this_review':True,
        'continuation_controller_no_self_contained_proc_probe':True,
        'original_collector_proc_probe_is_inside_main_not_invoked_by_import':True,
        'original_host_proc_observation_artifact_in_package':False,
        'snapshot_claims_terminal_through':56,'snapshot_current_position':57,
        'independently_byte_reviewed_generation_through':55,
        'position50_dispatch_or_result_payload_in_package':True,
        'position50_exact_dispatch_time_verified':True,
        'position50_dispatch_utc':results[0]['dispatch_utc'],
        'position50_recorded_end_utc':results[0]['recorded_end_utc'],
        'raw_capture_contains_one_permanent_record_per_new_slot':True,
        'no_claim_to_exclude_unrecorded_external_attempts':True,
        'client_process_absence_does_not_prove_server_cancel_or_zero_billing':True}
    output = {'status':'PASS_targeted_generation_archive_review','scope':'positions 50-55 including raw first continuation dispatch and archived code/record checks',
              'archive_member_hashes':43,'original_base_payload_hashes':40,'extra_continuation_payload_hashes':3,'data_archive':dmeta,'audit_archive':ameta,'slots':results,
              'frozen_inputs_runner_and_config_equal_previously_reviewed':True,
              'six_prompt_bytes_equal_original_frozen_pack':True,'configuration':requested,'continuation_checks':continuation_checks,
              'recorded_native_CLI_binary_and_version_equal_prior':True,
              'serial_dispatch_timing_consistent_with_recorded_durations':True,
              'nonempty_public_answers':5,'CLI_exit_zero':5,'length_empty':0,'client_timeout_empty':1,
              'cumulative_using_previously_reviewed_history':cumulative,
              'scientific_admission_or_scoring_performed':False,'candidate_code_executed':False,
              'provider_request_body_or_usage_independently_verified':False,
              'historical_resource_full_cap_certification':False,
              'archive_written_after_reported_1115_disconnection':True,
              'post_1115_serial_generation_progress_recorded':True,
              'live_process_liveness_independently_verified':False,
              'notes':'Read-only archived byte/record check. No candidate, runner or collector execution. CLI tokens are self-reported, not provider usage/cost evidence. This archive establishes generation payloads through position55 and includes the raw position50 dispatch/result with its exact recorded start. The three continuation files are byte-identical to batch8. One permanent ledger capture per slot and unchanged atomic-claim code support no replay within this archived scope, not absence of unrecorded external attempts. Old-controller CPU/exit remain unknown; client process absence is not provider cancellation or zero billing. Snapshot through56/current57 lacks raw56/57 captures here. Public scoring1-49 was separately audited and is pending archive; this review performs no scoring. All external writes remain paused.',
              'cpu_seconds':time.process_time()-started}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(output,ensure_ascii=False,indent=2))

if __name__ == '__main__':
    main()
