# 原132 P2恢复工程 r2：未验收候选

仅离线开发和可信fixture。已发布r1 ZIP SHA `509dca0f7863b00c2f96e6891051c1c782916ac225854e4670466ec7e79a6b91` 保持不变。r2开发grant仍为execution/review/GEN/numeric=false；没有生产恢复、真实Library或模型请求。

实际结果：17项Python单元测试、30个真实原组件联调场景、20个JS可信fixture场景通过。解压根换为另一个任意目录后，源码、测试、reference字节未改，全部相同套件再次通过；见 `audit/PORTABILITY_RESULTS.json` 和三个portable日志。生产grant的硬绑定不改，仅测试fixture在运行时生成自己的临时路径和TEST_ONLY身份。

## 独审七项修复

|问题|r2改动|实际验证|
|---|---|---|
|恢复measurement无wall_semantics|真实sample明确记录monotonic局部区间、不扣wait；验证三个wall字段与区间一致|真实旧Sidecar.finish确认46条，无unknown；所有32个delta process checkpoint存在并计入原init_final池|
|新callable被旧固定路径gate拒绝|新入口明确复用预先验证原9文件pin的原LOCAL_FUNCTIONS；旧Sidecar路径/name/hash校验不改|真实旧invoke_local接受原reserve_next callable，形成begin/end计量；在producer加载前由fixture主动抛哨兵停止|
|isError=true携正确内容仍接受|显式拒绝错误/unknown read|正确内容但isError=true负例不推进effect，pending保留|
|额外helper receipt漏检|原intent/receipt集合必须恰为精确连续前缀|helper-99.receipt与intent负例在enter前拒绝|
|CPU回退/wall不一致|同process按时间拒绝累计SELF回退，检查wall_seconds与实际记录区间一致|两个独审边界负例及原high-water/重叠wall负例通过|
|archive throw的原错误被覆盖，exception未留存|新增仅失败留存的窄门控，原exception retention helper真实执行；独立记录失败guard及helper开销，永久unknown/halt，最初Error优先返回|真实原helper09得到unknown receipt，原exception.json与新证据相同；1次create、pending保留、无helper10或v2，无重放|
|恢复后接受base v1漏delta|恢复journal存在时强制已完成且精确pin的v2；旧v1仅在无恢复journal的旧契约可走|真实完成46条的namespace拒绝base v1，完整v2导入及旧Sidecar恰好一次初始化通过|

源码/测试的明确r1→r2差异在 `audit/REVISION1_TO_REVISION2.diff`。原INIT七文件、科学/exporter依赖与旧GEN九文件均是原字节副本，未修改。r2六个新源pin与兼容路径草案见两个禁用JSON。

## 联调怎样运行

`real_fixture_support.py` 在本包fixtures下创建临时namespace。原helper0–4真实执行形成可用停点；它们属于新的TEST_ONLY fixture，不是生产五条receipt的替代或补写。测试专用OLD_INIT grant仅满足原本地代码门控，路径全部绑定fixture，绝不赋予真实Library/GEN权限；recovery开发grant始终false。

新suffix的显式offline fixture入口要求标记的fixture transport、TEST_ONLY两ID及本包fixture路径。broker不用shell，只接受三个固定本地launcher；实际调用原05/06、archive07–12和原assembler。Library read/create的返回由可信本地工具fixture提供，无连接器调用、无网络访问、无成功helper替身。

成功链有真实base14 measurements/16 receipt引用，加32条真实新本地控制进程计量，共46条；真实旧Sidecar.finish逐条接收并将全部process checkpoint计入同一个init_final池。真实旧Sidecar.begin拒绝重复初始化。14个后缀阶段各有CPU与wall阈值探针，共28场景；先前helper与delta均真实执行并入账，只有用于测试预算阈值的当前guard样本明确标记为SYNTHETIC_BUDGET_PROBE，不是实际耗时/CPU上界。

`audit/REAL_INTEGRATION_RESULTS.json` 含30场景实际fixture路径、计量及结果。成功和异常场景的原始journal/工具roundtrip/原组件字节封存在 `evidence/actual_success`、`evidence/actual_archive_throw`。二者是本轮测试证据，不是生产恢复记录。

## 精确未覆盖范围

真实平台Library行为、原生产namespace恢复、真实GEN及数值工作均未执行。为保持GEN=false，sidecar测试只用TEST_ONLY授权门控，原begin/finish/invoke_local/journal及计量代码真实运行；未宣称完整生产generation grant/科学契约激活通过。首local测试证明路径/hash门控和计量连线，主动停在producer加载前，未执行完整reserve事务或任何后续科学阶段。

历史CPU/wall尾部、JS/Library/provider成本、原失败read raw及新checkpoint后成本继续unknown；CPU_cap_certification=NOT_ESTABLISHED，没有硬CPU上界声明。预算探针不能解释为完整实际额度。对抗性getter/TOCTOU复现未运行。

## 从解压根复现

要求Python 3.10+和Node.js已存在。无需安装、网络、生产文件、凭证或Library。以下只在解压包的fixtures内写文件：

```sh
python3 -I -B tests/test_recovery.py
python3 -I -B tests/test_real_integration.py
node tests/test_bridge.js
```

测试动态绑定自己的路径、源pin和TEST_ONLY身份。不得把fixture绑定套用到生产；不得编辑禁用开发grant为true。本包仅供独审，下一步是独立工程复核r2差异和实际证据，然后另行形成精确激活文件。
