原132 P2 GEN 精确禁用候选，仅供独审。

所有 GEN/gate 启用、实现审阅开关均 false；真实 GEN 需要父另行批准新的精确全文、文件路径与 SHA。
唯一资源入口是已接受真实 v2 35587B / 2645a52293ad256e90d50729bac7fb015209d950e516035f82ebeb86253a1f66，共46条；BASE仅作为历史证据，不得作为导入入口。
原60请求/78 tickets/180 contexts、glm-5.3 high/32000/900s/no retry、P1 source/state和预算均保持。source digest绑定完整35路径，六local targets映射原reference entry。
BLOCKERS.json列精确组合待独审、fresh P1 current-head fact和生产连接未完整运行验证。未为补证启动原CLI、sidecar/importer或任何模型、Library、数值、恢复代码。
SOURCE_PATH_MAP映射源码/证据的原绝对路径到原字节副本；consumer633依赖为原冻结元数据，材料/prompts和候选代码正文未打包。
候选不能原地翻转：启用gate会改变其SHA，须重新绑定GEN的gate路径/SHA及新批准全文。原模板字节保留。
