"""Standalone stdlib-only disabled binding preparation. No repository imports."""
import time
ENTRY = time.monotonic()
import ast, copy, hashlib, json, math, os, resource, shutil, datetime
from pathlib import Path

D = Path(__file__).resolve().parent
X = Path('/workspace/original132-phase2-import-20261006-ba1y1szn/extracted')
P = X / 'original132_phase2_continuation_draft_20261006'
G = Path('/workspace/original132-phase2-generation-wiring-20261006-f_5psble')
R = Path('/workspace/original132-phase2-recovery-dev-20261006-8sdu8cov/revision2')
F = R / 'references/generation'
Q = Path('/workspace/original132-phase2-import-20261006-ba1y1szn/portability-r2/bundle/original132_phase2_portability_supplement_20261006/payload')
W = Path('/workspace/original132-phase2-producer-20261006')
J = Path(str(W) + '.namespace-init'); K = Path(str(W) + '.namespace-recovery')
A = Path('/workspace/original132-init-only-precheck-20261006-g2uks153/INIT_ONLY_ACTIVATION.APPROVED.json')
INIT = Path('/workspace/original132-init-only-recovery-execution-20261006-t1vw57km')
sha = lambda b: hashlib.sha256(b).hexdigest()
def canon(v): return json.dumps(v, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode('utf-8')
def read(p): return json.loads(Path(p).read_bytes())
def need(v, label):
    if not v: raise RuntimeError(label)
def fh(p): return sha(Path(p).read_bytes())
def ref(p): return {'path': str(p), 'file_sha256': fh(p)}
def publish(p, v):
    p = Path(p); b = v if isinstance(v, bytes) else canon(v)
    with p.open('xb') as f: f.write(b); f.flush(); os.fsync(f.fileno())
    return ref(p)
sources_to_package = {}
def evidence(p, name):
    p = Path(p); target = D / 'evidence' / name
    publish(target, p.read_bytes()); sources_to_package[str(p)] = 'evidence/' + name
    return ref(p)
def snapshot():
    return {str(p): {'bytes': p.stat().st_size, 'sha256': fh(p)} for root in (W, J, K) for p in sorted(root.rglob('*')) if p.is_file()}

before = read(D / 'audit/INIT_PRODUCTION_BEFORE.json')
need(snapshot() == before, 'INIT production changed during read-only preparation')
need(not (W / 'phase2-generation-accounting').exists() and not (W / 'phase2-bridge-journal').exists(), 'GEN already has state; stop')
need(fh(A) == '59d96a0a5deb67de3272d9991bfd4a83fb1c56844901bb512b5d73d7d917eb6b', 'reconciliation grant drift')
reconciliation = read(A)
hpath = K / 'RECONCILED_HANDOFF.v2.json'; h = read(hpath)
need(hpath.stat().st_size == 35587 and fh(hpath) == '2645a52293ad256e90d50729bac7fb015209d950e516035f82ebeb86253a1f66', 'exact independently accepted real v2 required')
need(h['schema'] == 'phase2-namespace-init-reconciled-handoff-v2' and h['status'] == 'CONFIRMED' and len(h['measurements']) == 46 and h['base_measurement_count'] == 14 and h['recovery_measurement_count'] == 32, 'real46 v2 scope')
need(h['model_calls'] == h['candidate_executions'] == 0 and h['generation_execution_granted'] is False and h['numeric_execution_granted'] is False, 'INIT not a GEN grant')
need(h['pool'] == {'SELF_checkpoint_seconds': 60, 'local_inclusive_wall_seconds': 240, 'new_budget': False}, 'original pool unchanged')
need(read(K / 'finish.receipt.json') == {'outcome': 'confirmed', 'handoff_ref': ref(hpath)}, 'v2 seal exact')

paths = read(G / 'consumer-paths.draft.json'); binding = read(G / 'consumer-contract.draft.json')
need(fh(G / 'consumer-contract.draft.json') == 'dcee9d28311bf06d3efb6d656cac0847e3fb08492138064683f05c6aba049141' == sha(canon(binding)), 'unchanged canonical consumer contract')
template_path = Path(paths['disabled_grant_template_path']); template = read(template_path)
need(fh(template_path) == paths['disabled_grant_template_file_sha256'] == '97859da447ba953070e0da78a2cd9d53e020cd36d60f58fa75c0aa5c760c2cbe', 'original GEN template pin')
gate_template_path = P / 'inputs/EXECUTION_SWITCH.json'; gate_template = read(gate_template_path)
need(fh(gate_template_path) == '2e04edb1abdf5d726729d94f205517e99fa67e7a2d53b2610e665a1236af2e29', 'original bridge gate template pin')
plan = read(P / 'PLAN.json'); roster = read(P / 'inputs/roster.json'); freeze = read(P / 'inputs/freeze.json'); manifest = read(P / 'PACKAGE_MANIFEST.json')
for v in (plan, roster, freeze, manifest): need(v['sha256'] == sha(canon({k: x for k, x in v.items() if k != 'sha256'})), 'original metadata seal')
records = roster['records']
need(records == binding['records'] and len(records) == roster['count'] == 60 and [x['position'] for x in records] == list(range(1,61)) and [x['order'] for x in records] == list(range(73,133)), 'exact original60 requests')
need(len({x['slot_id'] for x in records}) == len({x['request_sha256'] for x in records}) == 60 and sum(len(x['parents']) for x in records) == 78, 'unique slots/requests and original78 multiplicities')
dependencies = []
for root, field in ((P, 'source_files'), (X, 'external_source_files')):
    for name, digest in binding[field].items():
        need(not any(s in name.lower() for s in ('heldout','holdout')), 'heldout dependency forbidden')
        p = root / name; need(p.is_file() and fh(p) == digest, 'frozen dependency drift: ' + str(p))
        dependencies.append({'path': str(p), 'file_sha256': digest})
need(len(dependencies) == 633, 'original177+456 contract')

provenance = read(P / 'INTERNAL_PARENT_PROVENANCE.json')
prov_by_id = {x['id']: x for x in provenance['records']}
tickets = []; request_bindings = []
for r in records:
    pack_path = P / 'inputs/packs' / (r['slot_id'] + '.json'); pack = read(pack_path)
    claim_path = P / 'inputs/uncommitted-claims' / (r['slot_id'] + '.json'); claim = read(claim_path)
    need(pack['sha256'] == sha(canon({k:x for k,x in pack.items() if k!='sha256'})) == r['request_sha256'] and pack['parents'] == r['parents'] and pack['parent_snapshot_sha256'] == r['parent_snapshot_sha256'], 'frozen pack metadata drift')
    need(claim['sha256'] == r['claim_sha256'] and claim['request_sha256'] == r['request_sha256'], 'frozen claim drift')
    pr = prov_by_id[r['slot_id']]
    need(pr['parents'] == r['parents'] and pr['parent_snapshot_sha256'] == r['parent_snapshot_sha256'] and len(pack['parent_pair_hashes']) == len(r['parents']) == len(pr['parent_provenance']), 'parent ticket binding')
    for n, (pid, pair, pv) in enumerate(zip(r['parents'], pack['parent_pair_hashes'], pr['parent_provenance'])):
        need(pv['id'] == pid and pv['pair_sha256'] == pair, 'parent artifact digest mismatch')
        tickets.append({'position': r['position'], 'order': r['order'], 'slot_id': r['slot_id'], 'request_sha256': r['request_sha256'], 'ticket_position': n+1, 'parent_id': pid, 'parent_snapshot_sha256': r['parent_snapshot_sha256'], **{k: pv[k] for k in ('code_sha256','description_sha256','pair_sha256')}})
    request_bindings.append({'record': r, 'pack_ref': ref(pack_path), 'claim_ref': ref(claim_path), 'parent_pair_hashes': pack['parent_pair_hashes'], 'parent_ticket_count': len(r['parents']), 'model_slots': 1})
need(len(tickets) == 78, 'exact original78 parent tickets')
for s in provenance['P1']: need(s['sha256'] == sha(canon({k:x for k,x in s.items() if k!='sha256'})), 'P1 snapshot seal')
publish(D / 'PARENT_TICKETS.FROZEN.json', {'source_ref': ref(P / 'INTERNAL_PARENT_PROVENANCE.json'), 'count': 78, 'duplicates_and_ticket_order_preserved': True, 'tickets': tickets})
publish(D / 'PARENT_SNAPSHOTS.FROZEN.json', {'source_ref': ref(P / 'INTERNAL_PARENT_PROVENANCE.json'), 'snapshots': provenance['P1'], 'model_input': False})
publish(D / 'FROZEN_REQUEST_BINDINGS.json', {'consumer_contract_ref': ref(G / 'consumer-contract.draft.json'), 'request_count': 60, 'parent_ticket_count': 78, 'records': request_bindings})

readback_path = Q / 'original132_phase1_authenticated_readback_20261006/readback.receipt.json'
fence_path = Q / 'original132_phase1_authenticated_readback_20261006/producer-fence-status.stdout.json'
acceptance_path = Q / 'audit_original132_phase1_terminal_independent_20261006/P1_INDEPENDENT_REVIEWER_ACCEPTANCE.json'
boundary = read(P / 'history/parent-boundary.json')
for key, p in (('generation_readback', readback_path), ('producer_fence', fence_path), ('reviewer', acceptance_path)):
    need(fh(p) == boundary['evidence'][key]['file_sha256'], 'consumer-local immutable P1 evidence pin: ' + key)
parent_bindings = {'schema': 'frozen-parent-evidence-bindings-v1', 'boundary_ref': ref(P / 'history/parent-boundary.json'), 'historical_P1_index_identity': plan['predecessor'], 'historical_authenticated_readback_ref': ref(readback_path), 'historical_producer_fence_ref': ref(fence_path), 'P1_independent_acceptance_ref': ref(acceptance_path), 'P1_snapshots_ref': ref(D / 'PARENT_SNAPSHOTS.FROZEN.json'), 'parent_artifact_ticket_receipts_ref': ref(D / 'PARENT_TICKETS.FROZEN.json'), 'request_bindings_ref': ref(D / 'FROZEN_REQUEST_BINDINGS.json'), 'fresh_P1_head_current_confirmed_this_round': False, 'fresh_P1_authenticated_read_this_round': 0, 'P1_sources_and_state_unchanged': True, 'heldout_reads': 0}
publish(D / 'PARENT_BINDINGS.CANDIDATE.json', parent_bindings)

local_helpers = {str(W/'src/external_commit_fence_v2.py'): paths['original_v2_source_files6'][str(X/'original132_phase1_preparation_20261005/exporter/src/external_commit_fence_v2.py')], str(W/'src/commit_receipt_v2.py'): paths['original_v2_source_files6'][str(X/'original132_phase1_preparation_20261005/exporter/src/commit_receipt_v2.py')], str(W/'.library-helpers-current/library_file_transfer.py'): reconciliation['original_implementation_pins'][reconciliation['original_implementation_root']+'/pinned_originals/library_file_transfer.py'], str(Path(paths['original_retention_helper_path'])): paths['original_retention_helper_file_sha256']}
operational = dict(paths['operational_source_files9']); operational.update(paths['entry_source_file_pins']); operational.update(local_helpers)
for key in ('commit','retention'): operational[paths['js_source_paths'][key]] = fh(paths['js_source_paths'][key])
need(len(operational) == 20, 'explicit original20 source set')
old20 = dict(operational)
operational.update(reconciliation['new_source_pins'])
fm = read(F / 'OPERATING_SOURCE_MANIFEST.json')
need(fh(F / 'OPERATING_SOURCE_MANIFEST.json') == '268030b9810ba65a7444948e6ba5056bff6c11a2ee7cd82f96bf34699423e84b' and len(fm['production_files']) == 9, 'original reference9 manifest pin')
operational.update({str(F / n): digest for n, digest in fm['production_files'].items()})
need(len(operational) == 35, 'full exact35 source paths required')
for p, digest in operational.items(): need(fh(p) == digest, 'operational source drift: ' + p)
original_entry = F / 'production_generation_entry.py'
tree = ast.parse(original_entry.read_text()); mapping = None
for node in tree.body:
    if isinstance(node, ast.Assign) and any(isinstance(x, ast.Name) and x.id == 'LOCAL_FUNCTIONS' for x in node.targets):
        need(isinstance(node.value, ast.DictComp) and isinstance(node.value.generators[0].iter, ast.Tuple), 'unchanged original callable mapping shape')
        mapping = {x.id:x.id for x in node.value.generators[0].iter.elts}
need(set(mapping) == {'reserve_next','prepare_reserved','collect_reserved','build_wave_archive','finish_index','finish_position'}, 'six original callable targets')
need('LOCAL_FUNCTIONS = original_entry.LOCAL_FUNCTIONS' in (R/'src/production_generation_entry_v2.py').read_text(), 'v2 delegates unchanged original map')
targets = {stage: {'function': function, 'path': str(original_entry), 'sha256': fh(original_entry)} for stage,function in mapping.items()}

gate = copy.deepcopy(gate_template)
gate.update(enabled=False, parent_review_accepted=False, package_manifest_sha256=manifest['sha256'], producer_workspace=str(W), bridge_journal_root=str(W/'phase2-bridge-journal'), storage={'index_library_file_id': h['index_receipt']['library_file_id'], 'archive_library_file_id': h['archive_receipt']['library_file_id']}, original_head_current_confirmed=False)
gate['namespace_initialization_handoff'] = ref(hpath)
gate['parent_evidence_binding_ref'] = ref(D/'PARENT_BINDINGS.CANDIDATE.json')
gate['generation_execution_granted'] = False; gate['numeric_execution_granted'] = False
gate['reason'] = gate_template['reason']
gate_ref = publish(D/'BRIDGE_GATE.CANDIDATE.json', gate)
index_receipt_path = W/'state/commits'/(h['index_receipt']['library_file_id']+'-0.json')
archive_receipt_path = W/'state/commits'/(h['archive_receipt']['library_file_id']+'-0.json')
need(read(index_receipt_path) == h['index_receipt'] and read(archive_receipt_path) == h['archive_receipt'], 'exact actual v0 commits')
grant = copy.deepcopy(template)
grant.update(generation_execution_granted=False, implementation_review_accepted=False, binding_sha256=sha(canon(binding)), sidecar_root=str(W/'phase2-generation-accounting'), producer_workspace=str(W), inclusive_wall_supplement_path=paths['inclusive_wall_supplement_path'], bridge_gate_path=gate_ref['path'], bridge_gate_file_sha256=gate_ref['file_sha256'], operational_source_manifest_file_sha256=fh(F/'OPERATING_SOURCE_MANIFEST.json'), operational_source_files=operational, authorized_slot_order=[r['slot_id'] for r in records], authorized_request_sha256=[r['request_sha256'] for r in records], entry_source_files=paths['entry_source_files'], local_call_targets=targets, local_helper_source_files=local_helpers, entry_initial_head={'index_path': str(W/'index.initial.json'), 'index_file_sha256': fh(W/'index.initial.json'), 'receipt_path': str(index_receipt_path), 'receipt_file_sha256': fh(index_receipt_path)}, entry_initial_archive_receipt=h['archive_receipt'], retention_audit_directory=str(W/'retained-library-replies'), initializationFinalizationOps={'initialization': 'urp132-phase2-GEN-initialization', 'finalization': 'urp132-phase2-GEN-finalization'}, namespace_initialization_handoff=ref(hpath))
grant.update(reconciliation_grant_ref=ref(A), numeric_execution_granted=False, parent_evidence_binding_ref=ref(D/'PARENT_BINDINGS.CANDIDATE.json'), request_scope={'phase': 2, 'logical_requests': 60, 'orders': [73,132], 'model_slots_per_original_request': 1, 'native_CLI_invocations_per_original_request_max': 1, 'outer_retries': 0, 'replacement_requests': 0, 'parent_tickets': 78, 'Library_contexts': 180}, v2_generation_entry_ref=ref(R/'src/production_generation_entry_v2.py'), v2_importer_ref=ref(R/'src/gen_importer_v2.py'), operational_source_manifest_path=str(F/'OPERATING_SOURCE_MANIFEST.json'), init_resource_import={'only_handoff_ref': ref(hpath), 'measurement_count': 46, 'base_measurements': 14, 'recovery_measurements': 32, 'import_max': 1, 'v1_downgrade_allowed': False, 'pool': h['pool'], 'observed_init_SELF_seconds': h['observed_init_final_self_cpu_seconds'], 'observed_init_local_inclusive_wall_seconds': h['observed_init_final_local_wall_seconds'], 'new_budget': False}, preparation_execution_counts={'GEN': 0, 'models': 0, 'candidates': 0, 'numeric': 0, 'recovery': 0, 'Library_calls': 0, 'heldout_reads': 0})
grant_ref = publish(D/'GEN_GRANT.CANDIDATE.json', grant)
source_digest = sha(canon(operational))
contexts = [{'position':r['position'], 'context':{'scope':'slot', 'slotId':r['slot_id'], 'stage':stage, 'operationId':r['slot_id']+':'+stage, 'request_sha256':r['request_sha256'], 'plan_sha256':binding['plan_sha256'], 'roster_sha256':binding['roster_sha256'], 'source_sha256':source_digest, 'binding_sha256':sha(canon(binding))}} for r in records for stage in ('claim_commit','archive_commit','terminal_commit')]
need(len(contexts) == len({x['context']['operationId'] for x in contexts}) == 180, 'exact180 contexts')
publish(D/'LIBRARY_CONTEXTS.CANDIDATE.json', {'source_digest_semantics':'SHA256(canonical full35 operational_source_files), no old20 downgrade', 'source_sha256':source_digest, 'context_count':180, 'contexts':contexts})
launch_prefixes = [{'python':'python3 -I','scriptPath':str(W/'src/external_commit_fence_v2.py')}, {'python':'python3 -I','scriptPath':str(W/'src/commit_receipt_v2.py')}, {'python':'python3','scriptPath':str(W/'.library-helpers-current/library_file_transfer.py')}, {'python':'python3 -I','scriptPath':paths['original_retention_helper_path']}]
composition = {'generation_execution_granted':False, 'GEN_grant_ref':grant_ref, 'binding_ref':ref(G/'consumer-contract.draft.json'), 'generation_entry_ref':ref(R/'src/production_generation_entry_v2.py'), 'local_call_targets':targets, 'JS_composition_ref':ref(X/'original132_phase2_generation_accounting_20261006/production_library_commit.js'), 'JS_source_refs':{key:ref(p) for key,p in paths['js_source_paths'].items()}, 'paths':{'hooksCliPath':paths['fixed_hooks_cli_path'], 'launcherPath':paths['fixed_helper_launcher_path'], 'journalRoot':str(W/'phase2-generation-accounting'), 'grantPath':grant_ref['path'], 'originalLaunchPrefixes':launch_prefixes, 'retentionAuditDirectory':str(W/'retained-library-replies'), 'retentionHelperPath':paths['original_retention_helper_path']}, 'accountingSupplementSha256':paths['inclusive_wall_supplement_file_sha256'], 'slotIds':grant['authorized_slot_order'], 'context_ref':ref(D/'LIBRARY_CONTEXTS.CANDIDATE.json'), 'pending':None, 'real_tools_required':True, 'pending_and_token_must_come_from_future_real_library_begin':True, 'arbitrary_positive_callback_allowed':False, 'runtime_link_executed_or_approved_by_this_file':False}
publish(D/'GEN_COMPOSITION.CANDIDATE.json', composition)

def differences(old,new,prefix=''):
    if isinstance(old,dict) and isinstance(new,dict):
        result=[]
        for key in sorted(set(old)|set(new)):
            p=prefix+'/'+key.replace('~','~0').replace('/','~1')
            if key not in old: result.append({'pointer':p,'kind':'add','after':new[key]})
            elif key not in new: result.append({'pointer':p,'kind':'remove','before':old[key]})
            else: result.extend(differences(old[key],new[key],p))
        return result
    return [] if old==new else [{'pointer':prefix,'kind':'replace','before':old,'after':new}]
diff = {'GEN_template_ref':ref(template_path), 'bridge_gate_template_ref':ref(gate_template_path), 'GEN_candidate_ref':grant_ref, 'bridge_gate_candidate_ref':gate_ref, 'GEN_changes':differences(template,grant), 'bridge_gate_changes':differences(gate_template,gate), 'old20_operational_source_files':old20, 'full35_operational_source_files':operational, 'old20_source_digest':sha(canon(old20)), 'full35_source_digest':source_digest, 'local_target_mapping':'six original callable names and bytes remain; absolute path is the actual r2 references/generation/production_generation_entry.py imported by the accepted v2 entry', 'future_activation_requires_new_full_file_and_SHA_bindings':'Do not flip existing template/candidate bytes in place. Any parent-approved enabled gate changes its file SHA and requires a newly pinned GEN bridge_gate_path/file_sha256. No approved files are created here.'}
publish(D/'BINDING_DIFF.json',diff)

blockers = [
 {'id':'exact_disabled_candidate_review_pending','detail':'Parent GEN independent reviewer must accept this exact canonical pair, full35 source digest,180 contexts and original immutable gates before any new activation.'},
 {'id':'fresh_original_P1_head_confirmation_pending','detail':'Original check_gate requires original_head_current_confirmed=True. Candidate retains False; consumer-local historical readback/fence are exact but this round performed no fresh P1 Library/status read. Parent must substantiate the required current clean-head fact; no fabricated positive value.'},
 {'id':'full_production_composition_not_runtime_validated','detail':'r2 README explicitly limits sidecar/invoke_local integration to offline TEST_ONLY and stops before full producer loading. Original JS hooks close via original entry; v2 initializes via reference sidecar. Both source roots are pinned, but this exact production grant/180-context composition remains for independent connection review. No accepted source is modified.'}
]
publish(D/'BLOCKERS.json',{'GEN_execution_granted':False,'INIT_terminal_review':'accepted by explicit parent message; separate evidence copy retained','new_source_code_required_by_observed_static_checks':False,'blockers':blockers})
accepted_message = '真实INIT独审终态已接受：309manifest/55refs/44真实工具顺序/全部pins/原5不变/46测量全过；原index未重建、新archive仅1create，独立Library完整字节/当前head与backing两v0通过（新远端字节证据另存，不改旧receipt remote_bytes_verified=false）。唯一v2 handoff路径/workspace/original132-phase2-producer-20261006.namespace-recovery/RECONCILED_HANDOFF.v2.json，35587B SHA2645a52293ad256e90d50729bac7fb015209d950e516035f82ebeb86253a1f66。SELF2.26894/local1.1660925439937273，原同池观测余57.73106/238.83390745600627，全局未知保持。请将此精确hand off binding用于正准备的disabled GEN候选，不降级旧v1，不重置资源。仍未批准GEN执行。'
publish(D/'evidence/PARENT_INIT_FINAL_ACCEPTANCE_MESSAGE.txt', accepted_message.encode('utf-8'))
for p,name in ((template_path,'GENERATION_GRANT_TEMPLATE.original.json'), (F/'GENERATION_GRANT_TEMPLATE.json','R2_GENERATION_GRANT_TEMPLATE.original.json'), (gate_template_path,'BRIDGE_GATE_TEMPLATE.original.json'), (G/'consumer-contract.draft.json','CONSUMER_CONTRACT.original.json'), (G/'consumer-paths.draft.json','CONSUMER_PATHS.original.json'), (hpath,'RECONCILED_HANDOFF.v2.exact.json'), (J/'INIT_RESOURCE_HANDOFF.json','BASE_HANDOFF.evidence_only.exact.json'), (A,'INIT_ONLY_ACTIVATION.exact.json'), (readback_path,'P1_AUTHENTICATED_READBACK.original.json'), (fence_path,'P1_PRODUCER_FENCE.original.json'), (acceptance_path,'P1_ACCEPTANCE.original.json'), (P/'history/parent-boundary.json','P1_BOUNDARY.original.json'), (P/'PLAN.json','PLAN.original.json'), (P/'inputs/roster.json','ROSTER.original.json'), (P/'inputs/freeze.json','FREEZE.original.json'), (P/'PACKAGE_MANIFEST.json','PACKAGE_MANIFEST.original.json'), (Path(paths['inclusive_wall_supplement_path']),'INCLUSIVE_SUPPLEMENT.original.json'), (Path(paths['policy_path']),'POLICY.original.json'), (Path(paths['accounting_path']),'ACCOUNTING.original.json'), (F/'OPERATING_SOURCE_MANIFEST.json','REFERENCE9_MANIFEST.original.json'), (Path(paths['operating_source_manifest_path']),'ORIGINAL9_MANIFEST.original.json'), (X/'handoff_evidence/BOUND_INPUTS_ACCEPTANCE.json','BOUND_INPUTS_ACCEPTANCE.original.json'), (INIT/'DRIVE_READBACK_VERIFICATION.json','ACCEPTED_INIT_BUNDLE_READBACK.original.json'), (R/'README.md','R2_REVIEW_SCOPE.original.md')):
    evidence(p,name)
for n,(p,digest) in enumerate(sorted(operational.items())):
    target='sources/'+('%02d_'%n)+Path(p).name
    publish(D/target,Path(p).read_bytes()); sources_to_package[p]=target
publish(D/'SOURCE_PATH_MAP.json',sources_to_package)
publish(D/'SOURCE_PINS.json',{'full_operational_source_files':operational,'count':35,'old20_count':20,'r2_six_count':6,'reference_nine_count':9,'full35_source_digest':source_digest,'r2_manifest_ref':ref(R/'FILE_MANIFEST.json'),'reconciliation_grant_ref':ref(A),'consumer_contract_ref':ref(G/'consumer-contract.draft.json')})
publish(D/'audit/FROZEN_DEPENDENCY_CHECKS.json',{'total_checked':633,'heldout_named_dependency_count':0,'all_exact':True,'files':dependencies,'repository_modules_imported':0})
after=snapshot(); need(after==before,'INIT changed; preserve disabled candidate but stop')
publish(D/'audit/INIT_PRODUCTION_AFTER.json',after)
need(fh(template_path)==paths['disabled_grant_template_file_sha256'] and fh(gate_template_path)=='2e04edb1abdf5d726729d94f205517e99fa67e7a2d53b2610e665a1236af2e29' and binding['generation_execution_granted'] is False and fh(G/'consumer-contract.draft.json')=='dcee9d28311bf06d3efb6d656cac0847e3fb08492138064683f05c6aba049141','original templates and contract unchanged')
booleans={'GEN.generation_execution_granted':grant['generation_execution_granted'],'GEN.implementation_review_accepted':grant['implementation_review_accepted'],'GEN.numeric_execution_granted':grant['numeric_execution_granted'],'gate.enabled':gate['enabled'],'gate.parent_review_accepted':gate['parent_review_accepted'],'gate.generation_execution_granted':gate['generation_execution_granted'],'gate.numeric_execution_granted':gate['numeric_execution_granted']}
need(all(x is False for x in booleans.values()),'any execution/review enable is forbidden')
report={'schema':'disabled-GEN-binding-preparation-v1','UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'EXACT_DISABLED_CANDIDATES_READY_FOR_INDEPENDENT_REVIEW','candidate_root':str(D),'GEN_candidate_ref':grant_ref,'bridge_gate_candidate_ref':gate_ref,'GEN_raw_SHA_equals_canonical_SHA':fh(D/'GEN_GRANT.CANDIDATE.json')==sha(canon(grant)),'serialization':'UTF-8 ensure_ascii=false sort_keys=true compact separators allow_nan=false; no trailing LF','operational_source_count':35,'operational_source_digest':source_digest,'local_targets':targets,'request_count':60,'parent_ticket_count':78,'Library_context_count':180,'model_slots_per_original_request':1,'frozen_configuration':freeze['configuration'],'sole_INIT_resource_ref':ref(hpath),'sole_INIT_measurement_count':46,'initial_final_pool':h['pool'],'original_INIT_pool_not_reset':True,'INIT_production_before_after_identical':after==before,'INIT_final_review':'parent explicitly accepted; original receipt fields retained','all_execution_enable_fields':booleans,'actual_call_counts':grant['preparation_execution_counts'],'consumer_dependencies_exact':633,'templates_and_consumer_bytes_unchanged':True,'accepted_source_bytes_unchanged':True,'new_or_modified_production_sources':0,'blockers':blockers,'unknown_resource_scope':h['unknown'],'CPU_cap_certification':'NOT_ESTABLISHED','preparation_cost_scope':'Separate standalone engineering preparation; not substituted for46 production checkpoints or a budget reset','SELF_CPU_checkpoint_seconds':resource.getrusage(resource.RUSAGE_SELF).ru_utime+resource.getrusage(resource.RUSAGE_SELF).ru_stime,'local_inclusive_wall_checkpoint_seconds':time.monotonic()-ENTRY,'startup_and_post_checkpoint_CPU_wall':None,'assistant_tool_JS_and_Drive_CPU_wall':None,'complete_CPU_upper_bound_claimed':False}
publish(D/'PREPARATION_REPORT.json',report)
publish(D/'README.md',('原132 P2 GEN 精确禁用候选，仅供独审。\n\n所有 GEN/gate 启用、实现审阅开关均 false；真实 GEN 需要父另行批准新的精确全文、文件路径与 SHA。\n唯一资源入口是已接受真实 v2 35587B / 2645a52293ad256e90d50729bac7fb015209d950e516035f82ebeb86253a1f66，共46条；BASE仅作为历史证据，不得作为导入入口。\n原60请求/78 tickets/180 contexts、glm-5.3 high/32000/900s/no retry、P1 source/state和预算均保持。source digest绑定完整35路径，六local targets映射原reference entry。\nBLOCKERS.json列精确组合待独审、fresh P1 current-head fact和生产连接未完整运行验证。未为补证启动原CLI、sidecar/importer或任何模型、Library、数值、恢复代码。\nSOURCE_PATH_MAP映射源码/证据的原绝对路径到原字节副本；consumer633依赖为原冻结元数据，材料/prompts和候选代码正文未打包。\n候选不能原地翻转：启用gate会改变其SHA，须重新绑定GEN的gate路径/SHA及新批准全文。原模板字节保留。\n').encode('utf-8'))
print(json.dumps({k:report[k] for k in ('status','candidate_root','GEN_candidate_ref','bridge_gate_candidate_ref','operational_source_count','operational_source_digest','request_count','parent_ticket_count','Library_context_count','sole_INIT_resource_ref','INIT_production_before_after_identical','actual_call_counts')},ensure_ascii=False))
