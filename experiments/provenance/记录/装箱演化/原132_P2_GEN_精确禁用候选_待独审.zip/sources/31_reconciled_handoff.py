"""Final dedicated local process; its checkpoint is included in the v2 delta."""
from pathlib import Path
from recovery_core import *
def assemble_v2(ledger,measure=sample):
    ledger.check()
    g=ledger.g;root=ledger.root
    need(ledger.progress()==len(STAGES),"suffix incomplete")
    need(not (root/"finish.intent.json").exists(),"reconciled assembly once only")
    base_path=path(g["original_journal_root"])/"INIT_RESOURCE_HANDOFF.json"
    base=validate_base(read(base_path),g)
    prior=ledger.measurements();admission(prior,measure())
    deltas=ledger.delta();delta_refs=[ref(root/f"delta-{i:04d}.receipt.json") for i in range(len(deltas))]
    publish(root/"finish.intent.json",{"base_handoff_ref":ref(base_path),
                                     "reconciliation_grant_ref":ledger.grant_ref})
    n=len(deltas);ip=root/f"delta-{n:04d}.intent.json"
    publish(ip,{"label":"v2.assemble","reconciliation_grant_ref":ledger.grant_ref})
    ms=base["measurements"]+[r["measurement"] for r in deltas]
    result=dict(schema=V2,status="CONFIRMED",producer_workspace=g["producer_workspace"],
        operational_run_id=g["operational_run_id"],base_handoff_ref=ref(base_path),
        reconciliation_grant_ref=ledger.grant_ref,old_grant_ref=g["old_grant_ref"],
        old_stop_zip_ref=g["stop_zip_ref"],old_bridge_error_ref=g["old_bridge_error_ref"],
        new_authenticated_read_refs=[ref(root/"read.backing.raw.json"),ref(root/"read.head.raw.json")],
        index_receipt=base["index_receipt"],archive_receipt=base["archive_receipt"],
        base_measurement_count=14,base_receipt_count=16,recovery_measurement_count=len(deltas)+1,
        recovery_receipt_files=delta_refs,measurements=ms,
        observed_init_final_self_cpu_seconds=None,observed_init_final_local_wall_seconds=None,
        pool=g["pool"],unknown=g["unknown"],CPU_cap_certification="NOT_ESTABLISHED",
        complete_CPU_upper_bound_claimed=False,generation_execution_granted=False,
        numeric_execution_granted=False,model_calls=0,candidate_executions=0,
        new_source_pins=g["new_source_pins"],new_post_checkpoint_CPU_tails=None,
        new_post_checkpoint_wall_tails=None,measurement_checkpoint="after draft assembly before final sealing")
    canon(result)  # Include draft construction/serialization in this process checkpoint.
    m=measure()
    try:admission(prior,m)
    except BaseException as e:
        publish(root/f"delta-{n:04d}.receipt.json",dict(outcome="unknown",intent_file_sha256=filehash(ip),
             measurement=m,reconciliation_grant_ref=ledger.grant_ref,label="v2.assemble"))
        publish(root/"HALTED.json",{"reason":str(e)});raise
    rp=root/f"delta-{n:04d}.receipt.json"
    publish(rp,dict(outcome="confirmed",intent_file_sha256=filehash(ip),measurement=m,
                   reconciliation_grant_ref=ledger.grant_ref,label="v2.assemble",
                   post_checkpoint_CPU_tail=None,post_checkpoint_wall_tail=None))
    result["recovery_receipt_files"]=[*delta_refs,ref(rp)]
    result["measurements"]=[*ms,m]
    cpu,wall=totals(result["measurements"])
    result["observed_init_final_self_cpu_seconds"]=cpu
    result["observed_init_final_local_wall_seconds"]=wall
    publish(root/"RECONCILED_HANDOFF.v2.json",result)
    publish(root/"finish.receipt.json",{"outcome":"confirmed","handoff_ref":ref(root/"RECONCILED_HANDOFF.v2.json")})
    return result
