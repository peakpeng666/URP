/* Bind this wrapper as the tools argument to the unchanged, hash-pinned
 * commitV2 source. One operationId per commit. No retry is implemented.
 * It preserves the full returned object serialized as JSON, not wire bytes.
 * It returns the original object unchanged only AFTER local fsync succeeds.
 */
function retainLibraryReplies(client, {auditDirectory, operationId, helperPath}) {
  if (!/^[A-Za-z0-9_.-]{1,96}$/.test(operationId) || ['.', '..'].includes(operationId))
    throw new Error('unsafe_operation_id');
  const methods = new Set(['mcp__codex_apps__library_create_library_file',
                          'mcp__codex_apps__library_replace_library_file']);
  const directory = auditDirectory + '/' + operationId;
  const quote = value => "'" + String(value).replaceAll("'", "'\\''") + "'";
  let used = false;
  async function save(action, value) {
    const serialized = JSON.stringify(value);
    if (serialized === undefined) throw new Error('unserializable_tool_result_stop');
    const out = await client.exec_command({
      cmd: 'python3 -I ' + quote(helperPath) + ' ' + quote(action) + ' ' + quote(directory) +
           " <<'RETAIN_LIBRARY_OBJECT_JSON'\n" + serialized + '\nRETAIN_LIBRARY_OBJECT_JSON',
      login: false, max_output_tokens: 300
    });
    if (out.exit_code !== 0) throw new Error('tool_result_retention_failed_stop');
    return JSON.parse(out.output);
  }
  return new Proxy(client, {get(target, property) {
    if (!methods.has(property)) return target[property];
    return async args => {
      if (used) throw new Error('operation_already_attempted_no_retry');
      used = true;
      await save('start', {schema: 'retained-library-tool-intent-v1',
                           operation_id: operationId, method: property, arguments: args});
      let response;
      try { response = await target[property](args); }
      catch (error) {
        await save('exception', {schema: 'library-tool-threw-v1',
                                name: String(error?.name), message: String(error?.message),
                                write_outcome: 'unknown'});
        throw error;
      }
      // This happens before success checks, xattrs, metadata refresh or readback.
      await save('response', response);
      return response;
    };
  }});
}
