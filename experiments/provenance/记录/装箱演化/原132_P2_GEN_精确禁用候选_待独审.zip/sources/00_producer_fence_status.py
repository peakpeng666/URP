"""Read-only producer-side status. Run in the actual authorized producer root.

Exact stdout must be carried by the parent from this tool invocation with its
independently retained byte SHA-256; running against a copied package is invalid.
No subprocess, model, numerical worker, network, secret or write is involved.
"""
import base64
import hashlib
import json
from pathlib import Path
import sys


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode()


def inspect(root, library_id, version, index_path):
    root = Path(root)
    pending = root / 'state/external-pending.json'
    if pending.exists() or pending.is_symlink():
        raise ValueError('external_write_pending_stop_reconcile')
    raw = Path(index_path).read_bytes()
    index = json.loads(raw)
    if any(row['state'] != 'terminal' for row in index['rows']):
        raise ValueError('unresolved_claim_stop_reconcile')
    receipt_path = root / 'state/commits' / (library_id + '-' + str(version) + '.json')
    if not receipt_path.is_file() or receipt_path.is_symlink():
        raise ValueError('missing_actual_producer_ack')
    receipt = json.loads(receipt_path.read_bytes())
    if receipt['library_file_id'] != library_id or receipt['current_version_number'] != version or receipt['local_blob_sha256'] != hashlib.sha256(raw).hexdigest():
        raise ValueError('producer_ack_head_mismatch')
    rows = {row['claim']['claim_id']: row for row in index['rows']}
    dispatch_root = root / 'dispatch-fences'
    if not dispatch_root.is_dir() or dispatch_root.is_symlink():
        raise ValueError('missing_actual_dispatch_journal')
    fences = list(dispatch_root.iterdir())
    if {f.name for f in fences} != set(rows):
        raise ValueError('unresolved_or_missing_dispatch_fence')
    for fence in fences:
        if not fence.is_dir() or fence.is_symlink():
            raise ValueError('unknown_dispatch_fence')
        row = rows[fence.name]
        invocation = json.loads((fence / 'invocation.json').read_bytes())
        if invocation['claim_id'] != fence.name or invocation['invocation_id'] != row['reservation']['invocation_id']:
            raise ValueError('dispatch_fence_identity')
        retained = root / 'retained' / row['claim']['slot_id']
        export_raw = (retained / 'export.json').read_bytes()
        export = json.loads(export_raw)
        if hashlib.sha256(export_raw).hexdigest() != row['terminal']['artifact_sha256']:
            raise ValueError('dispatch_terminal_export_binding')
        if (fence / 'raw.txt').read_bytes() != (retained / 'raw.txt').read_bytes() or base64.b64decode(export['raw_b64'], validate=True) != (fence / 'raw.txt').read_bytes():
            raise ValueError('dispatch_terminal_raw_binding')
        if hashlib.sha256((fence / 'session-evidence.json').read_bytes()).hexdigest() != row['terminal']['session_evidence_sha256']:
            raise ValueError('dispatch_terminal_session_binding')
    if pending.exists() or pending.is_symlink():
        raise ValueError('external_write_pending_stop_reconcile')
    return {'schema': 'producer-fence-status-v1', 'observation_kind': 'actual_producer_status_tool_stdout',
            'external_write_pending': False, 'unresolved_dispatch_fences': 0,
            'library_file_id': library_id, 'file_id': receipt['file_id'], 'current_version_number': version,
            'index_blob_sha256': hashlib.sha256(raw).hexdigest(), 'run_id': index['run_id'],
            'freeze_sha256': index['freeze_sha256'], 'commit_receipt': receipt}


if __name__ == '__main__':
    root, library_id, version, index_path = sys.argv[1:]
    sys.stdout.buffer.write(canonical(inspect(root, library_id, int(version), index_path)))
