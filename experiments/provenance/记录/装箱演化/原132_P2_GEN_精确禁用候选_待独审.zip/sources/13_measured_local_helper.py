"""Run one pinned existing local Python helper, preserving argv/stdin/stdout.

Only the operational launch prefix changes. The original helper bytes, body,
return/exception, and Library/producer fences are untouched. No retry or limit.
A parent-reviewed generation grant and a pending Library stage are required.
"""
import argparse
import hashlib
import os
from pathlib import Path
import re
import runpy
import sys
import time

ENTRY_MONOTONIC = time.monotonic()
ORIGINAL_INTERPRETER_PATH = tuple(sys.path)
sys.path.insert(0, str(Path(__file__).resolve().parent))
import durable_generation_sidecar as d


def run_helper(sidecar, invocation_id, command_sha256, script, argv):
    d.need(re.fullmatch(r'[A-Za-z0-9_.:-]{1,180}', invocation_id), 'unsafe helper invocation ID')
    d.need(re.fullmatch(r'[0-9a-f]{64}', command_sha256), 'helper original command hash')
    script = d.absolute(script)
    d.need(str(script) in sidecar.grant['local_helper_source_files']
           and d.filehash(script) == sidecar.grant['local_helper_source_files'][str(script)], 'unpinned local helper')
    prefix = 'helper-' + hashlib.sha256(invocation_id.encode()).hexdigest()
    with sidecar.locked():
        sidecar._check_sources()
        state = sidecar._state(sidecar._events())
        token = state['pending']
        d.need(token and (token['stage'] in d.LIBRARY_STAGES or token['scope'] == 'init_final'), 'pending Library scope required')
        d.need(not state['halt'], 'halted sidecar')
        starts = list(sidecar.root.glob('helper-*.intent.json'))
        pending_cpu_by_process = {}
        pending_wall = 0.0
        for intent_path in starts:
            value = d.read(intent_path)
            if value['token_sha256'] == d.sha(d.canon(token)):
                receipt_path = intent_path.with_name(intent_path.name.replace('.intent.json','.receipt.json'))
                d.need(receipt_path.exists(), 'unresolved local helper; never rerun')
                prior = d.read(receipt_path);d.verify(prior)
                d.need(prior['outcome']=='confirmed', 'prior helper outcome unknown')
                observed=prior['measurement']; process=observed['process']
                pending_cpu_by_process[process]=max(pending_cpu_by_process.get(process,0.0), observed['end']['self_cpu'])
                pending_wall += observed['local_inclusive_wall_seconds']
        now = d.self_sample()
        pending_cpu_by_process[now['process']] = max(pending_cpu_by_process.get(now['process'],0.0),now['self_cpu'])
        extra_cpu=sum(max(0.0,amount-state['process_CPU_checkpoints'].get(process,0.0))
                      for process,amount in pending_cpu_by_process.items())
        scope=token['scope'];spent=state['scopes'].get(scope,[0,0])
        d.need(state['self_cpu_seconds']+extra_cpu < 1860
               and spent[0]+extra_cpu < (60 if scope=='init_final' else 30)
               and state['local_inclusive_wall_seconds']+pending_wall < d.WALL_TOTAL
               and spent[1]+pending_wall < (d.WALL_INIT_FINAL if scope=='init_final' else d.WALL_PER_SLOT),
               'observed coordination allowance exhausted before helper')
        intent = d.sealed({'schema':'measured-local-helper-intent-v1','invocation_id':invocation_id,
                           'command_sha256':command_sha256,'token_sha256':d.sha(d.canon(token)),
                           'script_path':str(script),'script_sha256':d.filehash(script),
                           'argv_sha256':d.sha(d.canon([str(script),*argv])),
                           'launcher_source_sha256':d.filehash(__file__)})
        d.publish_once(sidecar.root / (prefix+'.intent.json'), intent)
    start = d.self_sample()
    # SELF is cumulative from this dedicated helper process's birth. Unlike
    # elapsed exec-tool time, this includes observable Python startup CPU.
    start['self_cpu'] = 0.0
    start['monotonic'] = ENTRY_MONOTONIC
    saved_argv, saved_path = sys.argv, list(sys.path)
    raised = None
    try:
        sys.argv = [str(script), *argv]
        # Match normal script search-path semantics; -I helpers insert their
        # own source directory where needed in the unchanged accepted source.
        sys.path[:] = ORIGINAL_INTERPRETER_PATH
        if not sys.flags.isolated:
            # A normal script launch contributes exactly one script directory;
            # replace the launcher's slot, preserving configured PYTHONPATH.
            sys.path[0:1] = [str(script.parent)]
        runpy.run_path(str(script), run_name='__main__')
    except BaseException as exc:
        raised = exc
    finally:
        sys.argv, sys.path[:] = saved_argv, saved_path
    try:
        end = d.self_sample()
        measured = d.local_measurement(start, end)
    except BaseException:
        if raised is not None: raise raised
        raise
    ok = raised is None or (isinstance(raised, SystemExit) and raised.code in (0, None))
    receipt = d.sealed({'schema':'measured-local-helper-receipt-v1','invocation_id':invocation_id,
                        'command_sha256':command_sha256,'measurement_scope':'SELF',
                        'intent_sha256':intent['sha256'],'token_sha256':intent['token_sha256'],
                        'script_sha256':intent['script_sha256'],'launcher_source_sha256':intent['launcher_source_sha256'],
                        'measurement':measured,'outcome':'confirmed' if ok else 'unknown',
                        'self_CPU_through_receipt_checkpoint_includes_process_startup':True,
                        'receipt_emission_exit_tail_not_in_this_checkpoint':True,
                        'exec_tool_roundtrip_is_not_active_wall':True})
    try:
        with sidecar.locked():
            d.publish_once(sidecar.root / (prefix+'.receipt.json'), receipt)
    except BaseException:
        if raised is not None: raise raised
        raise
    if raised is not None: raise raised
    return receipt


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--journal', required=True)
    parser.add_argument('--grant', required=True)
    parser.add_argument('--grant-sha256', required=True)
    parser.add_argument('--invocation-id', required=True)
    parser.add_argument('--command-sha256', required=True)
    parser.add_argument('--script', required=True)
    parser.add_argument('arguments', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    identity = d.read(Path(args.journal) / 'identity.json')
    grant = d.read(args.grant)
    sidecar = d.Sidecar(args.journal, identity['binding'], grant, args.grant_sha256)
    argv = args.arguments[1:] if args.arguments[:1] == ['--'] else args.arguments
    run_helper(sidecar, args.invocation_id, args.command_sha256, args.script, argv)


if __name__ == '__main__':
    main()
