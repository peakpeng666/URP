/* Passive wait accounting for the unchanged assistant-only V2 Library route.
 *
 * Composition (do not invert these layers):
 *   meter = createLibraryWaitObserver(rawTools, options)
 *   measured = meter.bindStage({scope:'slot', slotId, stage, operationId})
 *   tools = retainLibraryReplies(measured, originalRetentionOptions)
 *   await unchangedCommitV2(...)
 *   meter.assertCanContinue() // accounting-integrity gate, not CPU admission
 *   // Outer durable sidecar must independently establish generation readiness.
 *
 * Thus original retention intent precedes the authenticated write, and its
 * returned object is still fsynced by the ORIGINAL retention wrapper before
 * unchanged V2 validation/fence confirmation. This wrapper is not a producer,
 * retention replacement, CPU meter, retry implementation, or byte proof.
 *
 * beforeOperation(intent) must durably persist its intent or throw. The exact
 * tool await starts AFTER that hook. afterObservation(receipt) must durably
 * persist the receipt. A post-hook failure never replaces the original return
 * or thrown value; it poisons this meter. The outer sidecar must persist/reconcile
 * that state and reject another generation. A crash after intent is unresolved,
 * not zero usage. Durable aggregate admission/restart checks belong to the
 * caller's sidecar; fresh JS instances cannot reset that durable accounting.
 *
 * No imports or tool calls are performed at load time. CommonJS export is only
 * for offline fake-tool tests; the function can be evaluated in the bridge's JS
 * context. Initialization/finalization must be explicitly pinned at creation.
 * Monotonic timing requires an explicitly injected now function and clock ID;
 * their suitability must be verified by the caller, never inferred from Node.
 * No default performance clock or Date.now elapsed accounting is provided.
 * Supplement-pinned unobservable mode retains actual outcomes with null timing;
 * it calls no clock. Timing unknown is separate from unresolved write outcomes.
 * The supplement does not authorize production execution or import of a passive
 * wait observer into the local Python production accounting path.
 */
'use strict';

function createLibraryWaitObserver(client, options = {}) {
  const ACCOUNTING_SUPPLEMENT_SHA256 = '778f9e487fc3a9201c8dc0de061b6195f6e3e8045cd5e4dcd30464e1830c3193';
  const timingMode = options.timingMode || 'monotonic';
  const METHODS = Object.freeze({
    mcp__codex_apps__library_create_library_file: 'write',
    mcp__codex_apps__library_replace_library_file: 'write',
    mcp__codex_apps__library_read: 'read',
    mcp__codex_apps__library_search: 'search'
  });
  const INDEX_LIMIT = Object.freeze({write: 1, read: 2, search: 1});
  const ARCHIVE_LIMIT = Object.freeze({write: 1, read: 0, search: 0});
  const SLOT_LIMIT = Object.freeze({write: 3, read: 4, search: 2});
  const HELPERS = new Set(['exec_command']);
  const UNOBSERVABLE = new Set(['apply_patch', 'write_stdin']);
  const DIGEST_FIELDS = ['request_sha256', 'plan_sha256', 'roster_sha256', 'source_sha256', 'binding_sha256'];
  // Dependency-free SHA-256 of UTF-8 text; no process, network, or tool call.
  function sha256(text) {
    const bytes = [];
    for (const ch of text) {
      const c = ch.codePointAt(0);
      if (c < 128) bytes.push(c);
      else if (c < 2048) bytes.push(192 | c >> 6, 128 | c & 63);
      else if (c < 65536) bytes.push(224 | c >> 12, 128 | c >> 6 & 63, 128 | c & 63);
      else bytes.push(240 | c >> 18, 128 | c >> 12 & 63, 128 | c >> 6 & 63, 128 | c & 63);
    }
    const length = bytes.length;
    bytes.push(128);
    while (bytes.length % 64 !== 56) bytes.push(0);
    const high = Math.floor(length / 0x20000000), low = (length * 8) >>> 0;
    for (const part of [high, low]) for (let shift = 24; shift >= 0; shift -= 8) bytes.push(part >>> shift & 255);
    const k = [0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
      0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
      0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
      0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
      0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
      0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
      0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
      0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
    const h = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
    const r = (x,n) => (x >>> n) | (x << (32-n));
    for (let offset = 0; offset < bytes.length; offset += 64) {
      const w = new Uint32Array(64);
      for (let i = 0; i < 16; i++) {
        const j = offset + i * 4;
        w[i] = bytes[j] << 24 | bytes[j+1] << 16 | bytes[j+2] << 8 | bytes[j+3];
      }
      for (let i = 16; i < 64; i++) {
        const a=w[i-15], b=w[i-2];
        w[i] = w[i-16] + (r(a,7)^r(a,18)^(a>>>3)) + w[i-7] + (r(b,17)^r(b,19)^(b>>>10));
      }
      let [a,b,c,d,e,f,g,j] = h;
      for (let i = 0; i < 64; i++) {
        const t1 = (j + (r(e,6)^r(e,11)^r(e,25)) + ((e&f)^(~e&g)) + k[i] + w[i]) | 0;
        const t2 = ((r(a,2)^r(a,13)^r(a,22)) + ((a&b)^(a&c)^(b&c))) | 0;
        j=g;g=f;f=e;e=(d+t1)|0;d=c;c=b;b=a;a=(t1+t2)|0;
      }
      [a,b,c,d,e,f,g,j].forEach((value, i) => { h[i] = (h[i] + value) | 0; });
    }
    return h.map(x => (x>>>0).toString(16).padStart(8,'0')).join('');
  }
  const COVERAGE = Object.freeze({
    library_await_wall: timingMode === 'unobservable'
      ? 'unknown_authenticated_monotonic_clock_unavailable'
      : 'measured_in_one_explicitly_injected_javascript_clock_domain',
    included_in_local_inclusive_61440_proof: false,
    wait_deduction_ms: 0,
    library_await_wall_is_cpu: false,
    javascript_cpu: 'unknown',
    plugin_cpu: 'unknown',
    exec_command: 'passthrough_separate_local_helper_resource_receipt_required',
    apply_patch: 'passthrough_service_cpu_unknown',
    write_stdin: 'passthrough_service_and_session_coordination_cpu_unknown',
    all_other_tools: 'passthrough_not_measured',
    caller_sidecar_cpu: 'separate_local_helper_self_receipt_required',
    retention_durability: 'original_retention_wrapper_required',
    remote_bytes: 'not_proven_by_tool_acknowledgment'
  });
  const fail = code => Object.assign(new Error(code), {code});
  const safeId = value => typeof value === 'string' &&
    /^[A-Za-z0-9_.-]{1,96}$/.test(value) && !['.', '..'].includes(value);
  const freeze = value => {
    if (value && typeof value === 'object') {
      for (const key of Object.keys(value)) freeze(value[key]);
      Object.freeze(value);
    }
    return value;
  };
  // JSON tool objects only: do not invoke getters/toJSON, silently omit fields,
  // or claim that cyclic, non-JSON, sparse, or special objects were retained.
  function canonical(value, seen = new Set()) {
    if (value === null || typeof value === 'string' || typeof value === 'boolean')
      return JSON.stringify(value);
    if (typeof value === 'number' && Number.isFinite(value) && !Object.is(value, -0))
      return JSON.stringify(value);
    if (!value || typeof value !== 'object' || seen.has(value))
      throw fail('non_json_observation');
    const proto = Object.getPrototypeOf(value);
    if (!Array.isArray(value) && proto !== Object.prototype && proto !== null)
      throw fail('non_json_observation');
    if (Object.getOwnPropertySymbols(value).length) throw fail('non_json_observation');
    seen.add(value);
    try {
      const keys = Object.keys(value);
      for (const key of keys) {
        const descriptor = Object.getOwnPropertyDescriptor(value, key);
        if (!descriptor || !Object.hasOwn(descriptor, 'value')) throw fail('non_json_observation');
      }
      if (Array.isArray(value)) {
        if (keys.length !== value.length || keys.some((key, i) => key !== String(i)))
          throw fail('non_json_observation');
        return '[' + keys.map(key => canonical(value[key], seen)).join(',') + ']';
      }
      return '{' + keys.sort().map(key => JSON.stringify(key) + ':' + canonical(value[key], seen)).join(',') + '}';
    } finally { seen.delete(value); }
  }
  const noteError = error => {
    try { return {name: String(error?.name), message: String(error?.message)}; }
    catch (_) { return {name: 'unavailable', message: 'exception_properties_unavailable'}; }
  };
  if (!client || typeof client !== 'object') throw fail('raw_tools_required');
  if (!['monotonic', 'unobservable'].includes(timingMode)) throw fail('invalid_timing_mode');
  if (timingMode === 'unobservable' && options.accountingSupplementSha256 !== ACCOUNTING_SUPPLEMENT_SHA256)
    throw fail('unobservable_timing_requires_exact_accounting_supplement');
  if (timingMode === 'monotonic' && !safeId(options.clockDomainId)) throw fail('clock_domain_id_required');
  if (timingMode === 'monotonic' && typeof options.now !== 'function')
    throw fail('explicit_verified_monotonic_clock_required');
  if (timingMode === 'monotonic' && options.now === Date.now)
    throw fail('date_now_is_diagnostic_only_not_monotonic_proof');
  if (typeof options.beforeOperation !== 'function' || typeof options.afterObservation !== 'function')
    throw fail('durable_observer_hooks_required');
  if (!Array.isArray(options.slotIds) || options.slotIds.length === 0 ||
      options.slotIds.some(id => !safeId(id)) || new Set(options.slotIds).size !== options.slotIds.length)
    throw fail('explicit_unique_slot_ids_required');
  const clockDomainId = timingMode === 'unobservable' ? 'unobservable' : options.clockDomainId;
  const accountingSupplementSha256 = timingMode === 'unobservable' ? ACCOUNTING_SUPPLEMENT_SHA256 : null;
  const beforeOperation = options.beforeOperation;
  const afterObservation = options.afterObservation;
  const verifyLocalHelperReceipt = options.verifyLocalHelperReceipt;
  const clock = timingMode === 'monotonic' ? options.now : null;
  const externalPins = options.initializationFinalizationOps || {};
  if (Object.keys(externalPins).some(key => !['initialization', 'finalization'].includes(key)) ||
      Object.values(externalPins).some(id => !safeId(id)) ||
      new Set(Object.values(externalPins)).size !== Object.values(externalPins).length)
    throw fail('invalid_pinned_phase');
  const pins = Object.freeze({...externalPins});
  const slots = new Map(options.slotIds.map(id => [id, {write: 0, read: 0, search: 0}]));
  const stages = new Map();
  const operationIds = new Set();
  const receipts = [];
  const helpers = [];
  const unobservableTools = [];
  const persistence = [];
  let invocationOrder = 0;
  const reasons = [];
  let active = false;
  let currentStage = null;
  let lastTime = null;
  let elapsedTotal = 0;
  let clockValid = timingMode === 'monotonic';
  function poison(code, detail = {}) { reasons.push(freeze({code, ...detail})); }
  function stamp() {
    const t = clock();
    if (!Number.isFinite(t) || t < 0 || (lastTime !== null && t < lastTime))
      throw fail('invalid_monotonic_clock');
    lastTime = t;
    return t;
  }
  function assertMeterHealthy() {
    if (active) throw fail('library_observation_in_flight');
    if (reasons.length) throw fail('library_meter_unknown_stop');
    return true;
  }
  function assertStageComplete(stage) {
    if (!stage) return;
    const observations = receipts.filter(r => r.operation_id === stage.binding.operation_id);
    const write = observations.find(r => r.kind === 'write');
    if (!write || write.write_outcome !== 'acknowledged_not_remote_byte_proof')
      throw fail('prior_stage_library_sequence_incomplete');
    if (stage.binding.stage !== 'archive') {
      const reads = observations.filter(r => r.kind === 'read');
      if (!reads.length || (stage.counts.search === 1 && reads.length !== 2))
        throw fail('prior_stage_library_sequence_incomplete');
      const row = structured(JSON.parse(reads[reads.length - 1].result_json))?.results?.[0];
      const item = structured(JSON.parse(write.result_json));
      if (row?.file_id !== item?.file_id || row?.has_more !== false)
        throw fail('prior_stage_library_sequence_incomplete');
    }
    if (stage.helpersSeen && !stage.fenceConfirmInvoked)
      throw fail('prior_stage_original_fence_sequence_incomplete');
  }
  function assertCanContinue() {
    assertMeterHealthy();
    if (helpers.some(h => !h.self_receipt_verified)) throw fail('local_helper_self_receipts_required');
    assertStageComplete(currentStage);
    return true;
  }
  function enterStage(stage) {
    if (currentStage === stage) return; // Finish this original route even when its observer failed.
    if (stage.retired) throw fail('stage_no_longer_active_stop');
    assertCanContinue(); // Recheck at ACTUAL entry, including prebound handles.
    if (currentStage) currentStage.retired = true;
    currentStage = stage;
  }
  async function recordLocalHelperReceipt(invocationId, receipt) {
    const helper = helpers.find(h => h.invocation_id === invocationId);
    if (!helper || helper.self_receipt_verified) throw fail('unknown_or_already_verified_helper');
    if (typeof verifyLocalHelperReceipt !== 'function') throw fail('local_helper_self_verifier_required');
    if (!receipt || typeof receipt !== 'object' || receipt.invocation_id !== helper.invocation_id ||
        receipt.command_sha256 !== helper.command_sha256 || receipt.measurement_scope !== 'SELF' ||
        !/^[a-f0-9]{64}$/.test(receipt.resource_receipt_sha256 || ''))
      throw fail('local_helper_self_receipt_binding_required');
    const receiptJson = canonical(receipt);
    let verified;
    try { verified = await verifyLocalHelperReceipt(freeze({...helper}), freeze(JSON.parse(receiptJson))); }
    catch (error) {
      poison('local_helper_self_verification_failed', {operation_id: helper.operation_id, invocation_id: invocationId});
      throw error;
    }
    if (verified !== true) {
      poison('local_helper_self_receipt_rejected', {operation_id: helper.operation_id, invocation_id: invocationId});
      throw fail('local_helper_self_receipt_rejected');
    }
    helper.self_receipt_verified = true;
    helper.self_receipt_sha256 = sha256(receiptJson);
    helper.self_receipt_json = receiptJson;
  }
  function structured(response) {
    let item = response?.structuredContent;
    if (!item) for (const c of response?.content ?? []) {
      if (c.type === 'text') { try { item = JSON.parse(c.text); break; } catch (_) {} }
    }
    while (item?.structuredContent) item = item.structuredContent;
    return item;
  }
  function acknowledged(response, method, args) {
    const item = structured(response);
    if (response?.isError || item?.status !== 'succeeded' ||
        typeof item.library_file_id !== 'string' || typeof item.file_id !== 'string' ||
        !Number.isInteger(item.current_version_number)) return false;
    if (method === 'mcp__codex_apps__library_replace_library_file') {
      return item.library_file_id === args[0]?.library_file_id &&
        item.current_version_number > args[0]?.expected_current_version;
    }
    return item.current_version_number > 0;
  }
  function snapshot() {
    return freeze({
      schema: 'library-wait-meter-v1', clock_domain_id: clockDomainId,
      timing_mode: timingMode, accounting_supplement_sha256: accountingSupplementSha256,
      timing_status: clockValid ? 'observed' : 'unknown',
      status: reasons.length ? 'unknown' : active ? 'in_flight' : 'observed',
      // Unknown intervals are never represented as a complete numeric total.
      library_await_wall_ms: clockValid ? elapsedTotal : null,
      observed_library_await_wall_ms: elapsedTotal, // Sum of known intervals only; never the unknown total.
      observed_known_interval_count: receipts.filter(r => r.elapsed_ms !== null).length,
      observed_library_await_wall_ms_is_partial: !clockValid,
      interval_coverage_complete: clockValid,
      resources: {...COVERAGE},
      slot_limits: {...SLOT_LIMIT},
      counts_semantics: 'reserved_attempts_including_before_hook_failures',
      slots: Object.fromEntries([...slots].map(([key, value]) => [key, {...value}])),
      pinned_phases: {...pins},
      stages: [...stages.values()].map(s => {
        const op = s.binding.operation_id;
        const observations = receipts.filter(r => r.operation_id === op);
        const local = helpers.filter(h => h.operation_id === op);
        const service = unobservableTools.filter(h => h.operation_id === op);
        const unknown = reasons.filter(r => r.operation_id === op ||
          (r.observation_id && r.observation_id.startsWith(op + ':')));
        return {...s.binding, counts: {...s.counts}, limits: {...s.limits},
          meter_status: unknown.length ? 'unknown' : 'observed',
          stage_entry_status: s.retired ? 'retired' : currentStage === s ? 'current' : 'not_entered',
          timing_status: clockValid ? 'observed' : 'unknown',
          observation_ids: observations.map(r => r.observation_id),
          write_outcomes: observations.filter(r => r.kind === 'write').map(r => r.write_outcome),
          local_helper_invocation_ids: local.map(h => h.invocation_id),
          local_helper_self_receipts_complete: local.every(h => h.self_receipt_verified),
          unobservable_invocation_ids: service.map(h => h.invocation_id),
          unobservable_service_cpu: service.length ? 'unknown' : 'not_invoked',
          javascript_cpu: 'unknown', plugin_cpu: 'unknown', unknown_reasons: unknown};
      }),
      local_helpers: helpers.map(h => ({...h})),
      local_helper_self_receipts_complete: helpers.every(h => h.self_receipt_verified),
      unobservable_tools: unobservableTools.map(h => ({...h})),
      observation_persistence: persistence.map(p => ({...p})),
      generation_resource_ready: false, // JS and plugin CPU remain unknown; sidecar owns readiness.
      unknown_reasons: reasons.map(r => ({...r})), observations: receipts.slice()
    });
  }
  function bindStage(binding) {
    assertCanContinue();
    const {scope, slotId, operationId} = binding || {};
    const stage = ({claim_commit:'claim',archive_commit:'archive',terminal_commit:'terminal'})[binding?.stage] || binding?.stage;
    const digests = {};
    for (const field of DIGEST_FIELDS) {
      if (!/^[a-f0-9]{64}$/.test(binding?.[field] || '')) throw fail('missing_or_invalid_' + field);
      digests[field] = binding[field];
    }
    if (!safeId(operationId)) throw fail('unsafe_operation_id');
    if (operationIds.has(operationId)) throw fail('operation_id_already_bound_no_retry');
    let limits, key, slot = null;
    if (scope === 'slot') {
      if (!slots.has(slotId) || !['claim', 'archive', 'terminal'].includes(stage))
        throw fail('unpinned_slot_or_stage');
      if (Object.values(pins).includes(operationId)) throw fail('operation_id_reserved_for_pinned_phase');
      key = 'slot:' + slotId + ':' + stage;
      limits = stage === 'archive' ? ARCHIVE_LIMIT : INDEX_LIMIT;
      slot = slots.get(slotId);
    } else {
      if (!['initialization', 'finalization'].includes(scope) || stage !== 'index' ||
          slotId !== undefined || pins[scope] !== operationId)
        throw fail('unpinned_initialization_or_finalization');
      key = scope;
      limits = INDEX_LIMIT;
    }
    if (stages.has(key)) throw fail('stage_already_bound_no_retry');
    operationIds.add(operationId);
    const stageState = {binding: freeze({scope, ...(slotId === undefined ? {} : {slot_id: slotId}), stage,
      operation_id: operationId, ...digests, timing_mode: timingMode,
      accounting_supplement_sha256: accountingSupplementSha256}), counts: {write: 0, read: 0, search: 0}, limits,
      retired: false, helpersSeen: false, fenceConfirmInvoked: false};
    stages.set(key, stageState);
    const wrappers = new Map();
    return new Proxy(client, {get(target, property) {
      if (HELPERS.has(property) || UNOBSERVABLE.has(property)) {
        if (wrappers.has(property)) return wrappers.get(property);
        // Synchronous forwarding preserves even Promise and exception identity.
        // Merely observing a helper is NOT a resource measurement.
        const helper = (...args) => {
          enterStage(stageState);
          stageState.helpersSeen = true;
          if (property === 'exec_command' && typeof args[0]?.cmd === 'string' &&
              /external_commit_fence_v2\.py['"]?\s+confirm(?:\s|$)/.test(args[0].cmd))
            stageState.fenceConfirmInvoked = true;
          invocationOrder++;
          let argumentDigest = null, commandDigest = null;
          try {
            argumentDigest = sha256(canonical(args));
            if (property === 'exec_command' && typeof args[0]?.cmd === 'string') commandDigest = sha256(args[0].cmd);
          } catch (_) { poison('helper_arguments_not_bound', {method: property, operation_id: operationId}); }
          const helperInvocation = {...stageState.binding, invocation_id: operationId + ':helper:' + invocationOrder,
            method: property, order: invocationOrder, tool_arguments_sha256: argumentDigest,
            command_sha256: commandDigest};
          if (HELPERS.has(property)) helpers.push({...helperInvocation,
            self_receipt_verified: false, self_receipt_sha256: null, self_receipt_json: null,
            cpu: 'unknown_until_separate_process_self_receipt'});
          else unobservableTools.push({...helperInvocation,
            cpu: 'unobservable_service_cpu_unknown', process_self_claim: false});
          return Reflect.apply(target[property], target, args);
        };
        wrappers.set(property, helper);
        return helper;
      }
      if (!Object.hasOwn(METHODS, property)) return Reflect.get(target, property, target);
      if (wrappers.has(property)) return wrappers.get(property);
      const wrapped = async (...args) => {
        const kind = METHODS[property];
        if (currentStage !== stageState) enterStage(stageState);
        if (active) throw fail('concurrent_library_await_not_allowed');
        if (typeof target[property] !== 'function') throw fail('library_tool_unavailable');
        if (stageState.counts[kind] >= limits[kind] || (slot && slot[kind] >= SLOT_LIMIT[kind]))
          throw fail(kind === 'write' ? 'write_already_attempted_no_retry' : 'library_stage_ceiling_exceeded');
        if (kind !== 'write' && stageState.counts.write !== 1)
          throw fail('index_read_requires_prior_write');
        if (kind === 'search' && stageState.counts.read !== 1)
          throw fail('index_search_requires_first_read');
        if (kind === 'read' && stageState.counts.read === 1 && stageState.counts.search !== 1)
          throw fail('second_index_read_requires_search');
        if (kind === 'read' && stageState.counts.read === 0 && stageState.counts.search !== 0)
          throw fail('first_index_read_must_precede_search');
        // This stage remains usable after a post-hook failure, preserving the
        // current V2 route. A newly bound stage/generation is always blocked.
        const ordinal = stageState.counts[kind] + 1;
        const base = {...stageState.binding, method: property, kind,
          observation_id: operationId + ':' + kind + ':' + ordinal,
          clock_domain_id: clockDomainId};
        let argumentJson;
        try { argumentJson = canonical(args); }
        catch (error) {
          poison('unserializable_arguments', {observation_id: base.observation_id});
          throw error;
        }
        base.tool_arguments_sha256 = sha256(argumentJson);
        base.order = ++invocationOrder;
        stageState.counts[kind]++;
        if (slot) slot[kind]++;
        active = true;
        const intent = freeze({schema: 'library-wait-intent-v1', ...base,
          arguments_json: argumentJson, resources: {...COVERAGE}});
        try { await beforeOperation(intent); }
        catch (error) {
          poison('before_operation_persistence_failed', {observation_id: base.observation_id, error: noteError(error)});
          active = false;
          throw error;
        }
        // beforeOperation awaits caller code. Preserve the original argument
        // identity, but reject any change before dispatching the authenticated
        // call; the durable intent must describe the actual request exactly.
        try {
          if (canonical(args) !== argumentJson) throw fail('tool_arguments_changed_before_dispatch');
        } catch (error) {
          poison('tool_arguments_changed_before_dispatch', {observation_id: base.observation_id});
          active = false;
          throw error;
        }
        let start = null;
        if (timingMode === 'monotonic') {
          try { start = stamp(); }
          catch (error) {
            clockValid = false;
            poison('clock_failed_before_operation', {observation_id: base.observation_id});
            active = false;
            throw error;
          }
        }
        let result, thrown, didThrow = false;
        try { result = await Reflect.apply(target[property], target, args); }
        catch (error) { didThrow = true; thrown = error; }
        let end = null;
        if (timingMode === 'monotonic') {
          try { end = stamp(); }
          catch (_) {
            clockValid = false;
            poison('clock_failed_after_operation', {observation_id: base.observation_id});
          }
        }
        const elapsed = end === null ? null : end - start;
        if (elapsed !== null) elapsedTotal += elapsed;
        let serialized = null, serializedException = null, writeOutcome = null;
        let serializationStatus = 'complete_json_object';
        if (didThrow) {
          serializationStatus = 'exception_descriptor';
          try { serializedException = canonical(thrown); } catch (_) {}
          if (kind === 'write') writeOutcome = 'unknown';
        } else {
          try {
            serialized = canonical(result);
            if (kind === 'write') writeOutcome = acknowledged(JSON.parse(serialized), property, args)
              ? 'acknowledged_not_remote_byte_proof' : 'unknown';
          } catch (_) {
            serializationStatus = 'unknown';
            poison('result_serialization_failed', {observation_id: base.observation_id});
            if (kind === 'write') writeOutcome = 'unknown';
          }
        }
        if (writeOutcome === 'unknown') poison('write_outcome_unknown', {observation_id: base.observation_id});
        const receipt = freeze({schema: 'library-wait-observation-v1', ...base,
          arguments_json: argumentJson,
          await_start_ms: start, await_end_ms: end, elapsed_ms: elapsed,
          timing_status: elapsed === null ? 'unknown' : 'observed',
          outcome: didThrow ? 'threw' : 'returned',
          write_outcome: writeOutcome,
          serialization_status: serializationStatus,
          result_json: serialized,
          result_sha256: serialized === null ? null : sha256(serialized),
          exception_json: serializedException,
          exception: didThrow ? noteError(thrown) : null,
          resources: {...COVERAGE}});
        receipts.push(receipt);
        try {
          await afterObservation(receipt);
          persistence.push({observation_id: base.observation_id, status: 'hook_returned_caller_must_verify_durable_receipt'});
        }
        catch (error) {
          persistence.push({observation_id: base.observation_id, status: 'hook_failed'});
          poison('after_observation_persistence_failed', {observation_id: base.observation_id, error: noteError(error)});
        } finally { active = false; }
        if (didThrow) throw thrown;
        return result;
      };
      wrappers.set(property, wrapped);
      return wrapped;
    }});
  }
  return Object.freeze({bindStage, assertCanContinue, recordLocalHelperReceipt, snapshot});
}

if (typeof module !== 'undefined' && module.exports)
  module.exports = {createLibraryWaitObserver};
