"""Fixed measured local CLI. Production requires a separately reviewed enabled grant."""
import argparse, json, sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from recovery_core import *
from reconciled_handoff import assemble_v2
def payload(ledger,kind,measure=sample):
    g=ledger.g;w=path(g["producer_workspace"]);r=ledger.root
    n=STAGES.index(kind+".payload")
    need(read(r/f"effect-{n:02d}.intent.json")=={"stage":kind+".payload","reconciliation_grant_ref":ledger.grant_ref}
         and not (r/f"effect-{n:02d}.receipt.json").exists()
         and len(list(r.glob("effect-*.intent.json")))==n+1
         and len(list(r.glob("effect-*.receipt.json")))==n,"payload admitted prefix required")
    if kind=="index":
        item=unwrap(read(checked_ref(g["historical_create_ref"])))
        rb=validate_read(read(r/"read.backing.raw.json"),g["index"],(w/"index.initial.json").read_bytes())
    else:item=unwrap(read(r/"archive-create.raw.json"));rb=None
    p=w/"state"/("readback-"+item["library_file_id"]+"-"+str(item["current_version_number"])+".json")
    obj={"item":{k:item[k] for k in ("status","library_file_id","file_id","current_version_number")},"readback":rb}
    return ledger.meter(kind+".payload.write",lambda:{"payload_ref":publish(p,obj)},measure)
def failure_before(ledger,o):
    g=ledger.g;r=ledger.root;n=STAGES.index('archive.create')
    need(set(o)=={'schema','name','message','write_outcome'} and o['schema']=='library-tool-threw-v1'
         and o['write_outcome']=='unknown' and isinstance(o['message'],str),'exact original throw evidence')
    need(read(r/f'effect-{n:02d}.intent.json')=={'stage':'archive.create','reconciliation_grant_ref':ledger.grant_ref}
         and not (r/f'effect-{n:02d}.receipt.json').exists()
         and len(list(r.glob('effect-*.intent.json')))==n+1
         and len(list(r.glob('effect-*.receipt.json')))==n,'only unresolved archive throw')
    need(len(base_records(g))==9,'fixed failure retention prefix')
    def body():
        publish(r/'archive-exception.raw.json',o)
        publish(r/'failure.retention.intent.json',{'reconciliation_grant_ref':ledger.grant_ref,
            'exception_ref':ref(r/'archive-exception.raw.json'),
            'original_confirmed_prefix':[ref(Path(g['original_journal_root'])/f'helper-{i:02d}.receipt.json') for i in range(9)]})
        return {'failure_evidence_admitted':True}
    return ledger.meter('failure.retention.prepare',body)
def failure_after(ledger,local_result):
    ledger.check();g=ledger.g;r=ledger.root;intent=read(r/'failure.retention.intent.json')
    prior=[read(checked_ref(x))['measurement'] for x in intent['original_confirmed_prefix']]
    prior.extend(x['measurement'] for x in ledger.delta());n=len(ledger.delta());ip=r/f'delta-{n:04d}.intent.json'
    publish(ip,{'label':'failure.retention.close','reconciliation_grant_ref':ledger.grant_ref})
    helper=Path(g['original_journal_root'])/'helper-09.receipt.json';helper_ref=None;error=None
    try:
        v=read(helper);need(v['step']=='archive.retain-response' and v['outcome']=='unknown' and
          v['init_grant_file_sha256']==g['old_grant_ref']['file_sha256'] and
          v['intent_file_sha256']==filehash(helper.with_name('helper-09.intent.json')),'actual original failed-retention receipt')
        validate_measurement(v['measurement']);prior.append(v['measurement']);helper_ref=ref(helper)
        checked_ref(intent['exception_ref'])
        retained=read(Path(g['producer_workspace'])/'retained-library-replies/phase2-init-archive/exception.json')
        need(retained==read(checked_ref(intent['exception_ref'])),'original exception retained intact')
    except BaseException as e:error=type(e).__name__+': '+str(e)
    m=sample();observed=None
    try:observed=admission(prior,m)
    except BaseException as e:error=error or str(e)
    publish(r/f'delta-{n:04d}.receipt.json',{'outcome':'unknown','label':'failure.retention.close',
       'intent_file_sha256':filehash(ip),'reconciliation_grant_ref':ledger.grant_ref,'measurement':m,
       'known_failed_helper_ref':helper_ref,'observed_shared_pool':observed,'error':error,
       'post_checkpoint_CPU_tail':None,'post_checkpoint_wall_tail':None})
    publish(r/'failure.retention.receipt.json',{'outcome':'unknown','original_throw_ref':intent['exception_ref'],
       'original_failed_helper_ref':helper_ref,'local_result':local_result,'observed_shared_pool':observed,'error':error})
    publish(r/'HALTED.json',{'reason':'original archive throw; external outcome unknown','original_throw_ref':intent['exception_ref']})
    return {'halted':True,'original_failure_preserved':True}
def main():
    a=argparse.ArgumentParser();a.add_argument("--grant",required=True);a.add_argument("--grant-sha256",required=True)
    a.add_argument("--offline-fixture",action="store_true")
    a.add_argument("action",choices=("enter","before","after","payload","finish","failure-before","failure-after"));v=a.parse_args()
    gp=path(v.grant);need(filehash(gp)==v.grant_sha256,"recovery grant file pin")
    g=read(gp);ledger=Ledger(g,ref(gp),fixture=v.offline_fixture);body=json.loads(sys.stdin.read() or "{}")
    if v.action=="enter":out=ledger.enter()
    elif v.action=="before":
        if v.offline_fixture and g.get("TEST_budget_before_stage")==body["stage"]:
            # Explicitly synthetic guard-only threshold probe. It never supplies a success receipt.
            m=sample();m.update(TEST_ONLY=True,probe="SYNTHETIC_BUDGET_PROBE")
            if g["TEST_budget_kind"]=="cpu":
                m["self_cpu_seconds"]=m["end"]["self_cpu"]=60.0
            else:
                m["end"]["monotonic"]=m["start"]["monotonic"]+240.0
                m["wall_seconds"]=m["local_inclusive_wall_seconds"]=240.0
            out=ledger.before(body["stage"],measure=lambda:m)
        else:out=ledger.before(body["stage"])
    elif v.action=="after":out=ledger.after(body["stage"],body["observation"])
    elif v.action=="payload":
        need(body["kind"] in ("index","archive"),"fixed payload")
        n=STAGES.index(body["kind"]+".payload")
        need((ledger.root/f"effect-{n:02d}.intent.json").exists(),"payload admission required")
        out=payload(ledger,body["kind"])
    elif v.action=='failure-before':out=failure_before(ledger,body['observation'])
    elif v.action=='failure-after':out=failure_after(ledger,body['local_result'])
    else:out=assemble_v2(ledger)
    sys.stdout.write(canon(out).decode())
if __name__=="__main__":main()
