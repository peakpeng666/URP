/* Fixed assistant-only composition. Exact source bytes, two new IDs, no retries.
 * rawTools must be the authenticated assistant's original tools, not a callback
 * registry. Sources are data and are evaluated only after exact SHA256 checks.
 */
'use strict';
function initSha256(text) {
  const bytes=Array.from(unescape(encodeURIComponent(text)),c=>c.charCodeAt(0));
  const bits=bytes.length*8;bytes.push(128);while(bytes.length%64!==56)bytes.push(0);
  const hi=Math.floor(bits/4294967296),lo=bits>>>0;
  for(const n of [hi,lo])for(let s=24;s>=0;s-=8)bytes.push((n>>>s)&255);
  const K=[0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
  let H=[0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
  const r=(x,n)=>(x>>>n)|(x<<(32-n));
  for(let p=0;p<bytes.length;p+=64){
    const w=Array(64).fill(0);for(let i=0;i<16;i++)w[i]=(bytes[p+i*4]<<24)|(bytes[p+i*4+1]<<16)|(bytes[p+i*4+2]<<8)|bytes[p+i*4+3];
    for(let i=16;i<64;i++){const a=w[i-15],b=w[i-2];w[i]=((r(a,7)^r(a,18)^(a>>>3))+w[i-16]+(r(b,17)^r(b,19)^(b>>>10))+w[i-7])|0;}
    let [a,b,c,d,e,f,g,h]=H;
    for(let i=0;i<64;i++){const t1=(h+(r(e,6)^r(e,11)^r(e,25))+((e&f)^(~e&g))+K[i]+w[i])|0;
      const t2=((r(a,2)^r(a,13)^r(a,22))+((a&b)^(a&c)^(b&c)))|0;
      h=g;g=f;f=e;e=(d+t1)|0;d=c;c=b;b=a;a=(t1+t2)|0;}
    H=H.map((x,i)=>(x+[a,b,c,d,e,f,g,h][i])|0);
  }
  return H.map(x=>(x>>>0).toString(16).padStart(8,'0')).join('');
}
'use strict';
/* New entry: old initializeNamespace is never loaded or called.
 * CLI is a new, pinned meter; original 05/06 and archive source bytes stay unchanged.
 * Both helper and tool effects have before/after admission in the same pool.
 */
async function recoverSuffixMode(rawTools, grantText, grantFileSha, grantPath, sources, offlineFixture=false) {
  const need=(v,s)=>{if(!v)throw Error(s);};
  const sha=s=>initSha256(s);
  need(sha(grantText)===grantFileSha,'recovery_grant_file_pin');
  const g=JSON.parse(grantText);
  if(offlineFixture)need(rawTools.offlineFixtureTransport===true&&g.index.library_file_id==='libfile_TEST_ONLY_index'&&
    g.index.file_id==='file_TEST_ONLY_index','offline_fixture_transport_required');
  const fixtureRoot=g.recovery_cli_path.replace(/\/src\/recovery_cli\.py$/,'/fixtures/');
  need((offlineFixture ? g.TEST_ONLY===true&&g.execution_granted===false&&
    g.producer_workspace.startsWith(fixtureRoot)&&grantPath.startsWith(fixtureRoot) :
    g.execution_granted===true&&g.independent_review_accepted===true)&&
    g.generation_execution_granted===false&&g.numeric_execution_granted===false&&
    g.model_requests===0&&g.candidate_executions===0,'recovery_disabled');
  need(g.new_index_create_count===0&&g.index_replace_count===0&&g.archive_create_max===1,
    'suffix_write_quota');
  need(typeof g.old_grant_file_text==='string'&&sha(g.old_grant_file_text)===g.old_grant_ref.file_sha256,
    'old_grant_file_pin');
  const old=JSON.parse(g.old_grant_file_text);
  need(g.original_implementation_root===old.implementation_root&&g.producer_workspace===old.producer_workspace&&
    g.original_journal_root===old.journal_root&&g.operational_run_id===old.operational_run_id&&
    g.recovery_journal_root===g.producer_workspace+'.namespace-recovery','exact_bound_namespace');
  const keys=['commit','retention','adapter'];
  const snap={};for(const k of keys){
    const d=Object.getOwnPropertyDescriptor(sources,k);
    need(d&&Object.prototype.hasOwnProperty.call(d,'value')&&typeof d.value==='string','own_source_text');
    snap[k]=d.value;
  }
  Object.freeze(snap);
  const pins={commit:'a870f16d05b5db17a94be6544beb725d69fe6a429b41d3bb5ba7fe646811270d',
    retention:'e44fec0c2059aa184825fd1d75c9eed851858c55230f22cb1650a7ab89ff0f6c',
    adapter:g.original_implementation_pins[g.original_implementation_root+'/init_exec_adapter.js']};
  for(const k of keys)need(sha(snap[k])===pins[k],'original_source_'+k);
  const q=x=>"'"+String(x).replaceAll("'","'\\''")+"'";
  for(const p of [grantPath,g.recovery_cli_path,g.producer_workspace,g.original_implementation_root])
    need(/^\/[A-Za-z0-9_./-]+$/.test(p)&&!p.split('/').includes('..'),'fixed_path');
  const cli=async(action,body={})=>{
    const cmd="python3 -I -B "+q(g.recovery_cli_path)+(offlineFixture?' --offline-fixture':'')+" --grant "+q(grantPath)+
      " --grant-sha256 "+q(grantFileSha)+" "+action+" <<'RECOVERY_JSON'\n"+
      JSON.stringify(body)+"\nRECOVERY_JSON";
    const r=await rawTools.exec_command({cmd,login:false,max_output_tokens:30000,yield_time_ms:30000});
    need(r.exit_code===0&&!r.session_id,'recovery_control_unknown_'+action);return JSON.parse(r.output);
  };
  const effect=async(stage,fn)=>{
    await cli('before',{stage});
    // An exception leaves a durable unresolved intent. No retry/finally resume.
    const value=await fn();await cli('after',{stage,observation:value});return value;
  };
  await cli('enter');
  const idx=g.index,w=g.producer_workspace,impl=g.original_implementation_root;
  await effect('read.backing',()=>rawTools.mcp__codex_apps__library_read({
    read:[{ref_id:idx.file_id,mode:'full',max_lines:2}]}));
  await effect('read.head',()=>rawTools.mcp__codex_apps__library_read({
    read:[{ref_id:idx.library_file_id,mode:'full',max_lines:2}]}));
  await effect('index.payload',()=>cli('payload',{kind:'index'}));
  const helper=async(stage,script,args,stdin,marker)=>{
    const prefix="python3 -I "+q(impl+'/init_local_helper.py')+" --grant "+q(g.old_grant_ref.path)+
      " --grant-sha256 "+q(g.old_grant_ref.file_sha256)+" --step "+q(stage)+" --script "+q(script)+" -- ";
    let cmd=prefix+args.map(q).join(' ');
    if(marker)cmd+=" <<'"+marker+"'\n"+JSON.stringify(stdin)+"\n"+marker;
    return effect(stage,async()=>{const r=await rawTools.exec_command({cmd,login:false,max_output_tokens:30000,
      yield_time_ms:30000});need(r.exit_code===0&&!r.session_id,'original_helper_unknown');return r;});
  };
  const p=w+'/state/readback-'+idx.library_file_id+'-'+idx.version+'.json';
  const r=await helper('index.receipt',w+'/src/commit_receipt_v2.py',
    [w+'/index.initial.json','-1','index',p]);
  const receipt={...JSON.parse(r.output),file_name:g.index.file_name};
  await helper('index.confirm',w+'/src/external_commit_fence_v2.py',
    ['confirm',w,w+'/index.initial.json','null','-1','index'],receipt,'CONFIRMED_RECEIPT_JSON');
  // Gate every unchanged original archive helper, write, and payload.
  let firstArchiveError=null;
  const guarded=new Proxy(rawTools,{get(target,key){
    if(key==='exec_command')return async args=>{
      const match=/--step 'archive\.(begin|retain-start|retain-response|xattrs|receipt|confirm)'/.exec(args.cmd||'');
      need(match,'only_original_archive_helper');
      const failed=match[1]==='retain-response'&&/ -- 'exception' /.test(args.cmd);
      if(failed&&firstArchiveError){
        const m=/ <<'RETAIN_LIBRARY_OBJECT_JSON'\n([^\n]*)\nRETAIN_LIBRARY_OBJECT_JSON$/.exec(args.cmd);
        need(m,'exact_original_exception_retention');
        await cli('failure-before',{observation:JSON.parse(m[1])});
        let local;
        try {local=await target.exec_command(args);return local;}
        finally {await cli('failure-after',{local_result:local??null});}
      }
      return effect('archive.'+match[1],async()=>{const x=await target.exec_command(args);
        need(x.exit_code===0&&!x.session_id,'archive_helper_unknown');return x;});
    };
    if(key==='mcp__codex_apps__library_create_library_file')return args=>{
      need(JSON.stringify(Object.keys(args).sort())===JSON.stringify(['file','library_artifact_type'])&&
        args.file===w+'/archive.initial.zip'&&args.library_artifact_type==='other','archive_only_create');
      return effect('archive.create',async()=>{try{return await target[key](args);}
        catch(e){firstArchiveError=e;throw e;}});
    };
    if(key==='apply_patch')return async patch=>{
      const prefix='*** Begin Patch\n*** Add File: '+w+'/state/readback-';
      need(typeof patch==='string'&&patch.startsWith(prefix),'archive_payload_only');
      return effect('archive.payload',()=>cli('payload',{kind:'archive'}));
    };
    throw Error('recovery_tool_not_allowlisted_'+String(key));
  }});
  const create=Function(snap.adapter+'\nreturn createInitExecAdapter;')();
  const retain=Function(snap.retention+'\nreturn retainLibraryReplies;')();
  const adapted=create(guarded,{workspace:w,launcherPath:impl+'/init_local_helper.py',
    grantPath:g.old_grant_ref.path,grantSha256:g.old_grant_ref.file_sha256,
    retentionHelperPath:old.original_source_root+'/original132_phase1_preparation_20261005/retention/retain_tool_result.py',
    kind:'archive'});
  const retained=retain(adapted,{auditDirectory:w+'/retained-library-replies',operationId:'phase2-init-archive',
    helperPath:old.original_source_root+'/original132_phase1_preparation_20261005/retention/retain_tool_result.py'});
  const commit=Function('tools',snap.commit+'\nreturn commitV2;')(retained);
  try {await commit(w,w+'/archive.initial.zip',null,-1,false);}
  catch(e){if(firstArchiveError)throw firstArchiveError;throw e;}
  await effect('base.assemble',async()=>{
    const cmd="python3 -I "+q(impl+'/assemble_handoff.py')+" --grant "+q(g.old_grant_ref.path)+
      " --grant-sha256 "+q(g.old_grant_ref.file_sha256);
    const out=await rawTools.exec_command({cmd,login:false,max_output_tokens:30000,yield_time_ms:30000});
    need(out.exit_code===0&&!out.session_id,'base_assembly_unknown');return out;
  });
  // Last measured command includes its own delta. No later unaccounted local guard.
  return cli('finish');
}
async function recoverSuffix(rawTools,text,digest,path,sources){return recoverSuffixMode(rawTools,text,digest,path,sources,false);}
async function recoverSuffixOfflineFixture(rawTools,text,digest,path,sources){return recoverSuffixMode(rawTools,text,digest,path,sources,true);}
if(typeof module!=='undefined'&&module.exports)module.exports={recoverSuffix,recoverSuffixOfflineFixture};
