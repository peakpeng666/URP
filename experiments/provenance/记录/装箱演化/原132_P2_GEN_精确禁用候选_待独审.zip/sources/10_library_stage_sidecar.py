"""Durable adapters for library_wait_observer hooks; no external tool calls."""
import hashlib
import json
import math
from pathlib import Path
import re

import durable_generation_sidecar as d

def structured(result):
    value = result.get('structuredContent') if isinstance(result,dict) else None
    if value is None and isinstance(result,dict):
        for item in result.get('content',[]):
            if item.get('type') == 'text':
                try:
                    value=json.loads(item['text']);break
                except (ValueError,TypeError,KeyError):
                    pass
    while isinstance(value,dict) and 'structuredContent' in value:
        value=value['structuredContent']
    return value


STAGE_MAP = {'claim_commit':'claim','archive_commit':'archive','terminal_commit':'terminal'}


def _path(sidecar, observation_id, suffix):
    d.need(type(observation_id) is str and re.fullmatch(r'[A-Za-z0-9_.:-]{1,180}', observation_id), 'observation ID')
    return sidecar.root / ('library-'+hashlib.sha256(observation_id.encode()).hexdigest()+'.'+suffix+'.json')


def _bind(sidecar, token, row):
    d.need(row['binding_sha256'] == d.sha(d.canon(sidecar.binding))
           and row['plan_sha256'] == sidecar.binding['plan_sha256']
           and row['roster_sha256'] == sidecar.binding['roster_sha256']
           and row['source_sha256'] == d.sha(d.canon(sidecar.grant['operational_source_files'])), 'Library source/context binding')
    if token['scope'] == 'init_final':
        d.need(row['scope'] == token['stage'] and row['stage'] == 'index'
               and row['operation_id'] == sidecar.grant['initializationFinalizationOps'][token['stage']], 'phase operation not pinned')
    else:
        d.need(row['scope'] == 'slot' and row['slot_id'] == token['scope']
               and row['stage'] == STAGE_MAP[token['stage']]
               and row['request_sha256'] == token['request_sha256'], 'Library slot/request/stage binding')


def persist_intent(sidecar, token, intent):
    start = d.self_sample()
    with sidecar.locked():
        d.need(sidecar._state(sidecar._events())['pending'] == token, 'exact durable stage required')
        _bind(sidecar, token, intent)
        prior=[]
        for path in sidecar.root.glob('library-*.intent.json'):
            item=d.read(path);d.verify(item)
            if item['token_sha256']==d.sha(d.canon(token)):prior.append(item['intent'])
        d.need(all(row['operation_id']==intent['operation_id'] for row in prior),
               'Library operation alias cannot reset durable stage')
        counts={kind:sum(row['kind']==kind for row in prior) for kind in ('write','read','search')}
        kind=intent['kind'];index=token['stage']!='archive_commit'
        d.need(kind in counts,'unknown Library kind')
        d.need(counts[kind] < (1 if kind=='write' else 2 if kind=='read' and index else 1 if kind=='search' and index else 0),
               'durable Library stage ceiling; never replay write')
        arguments=json.loads(intent['arguments_json'])
        d.need(isinstance(arguments,list) and len(arguments)==1 and isinstance(arguments[0],dict), 'Library argument envelope')
        arguments=arguments[0]
        position=next((i for i,r in enumerate(sidecar.binding['records'],1) if r['slot_id']==token['scope']),None)
        d.need(position is not None,'production Library writes only in pinned slot stages')
        control=d.read(sidecar.root/f'entry-{position:02d}-{token["stage"]}-begin-control.json');d.verify(control)
        expected=control['commit_arguments']
        d.need(control['token_sha256']==d.sha(d.canon(token)) and control['position']==position
               and control['stage']==token['stage'] and len(expected)==5
               and expected[0]==sidecar.grant['producer_workspace'] and expected[4] is index,
               'exact entry commit arguments required before tool')
        if kind=='write':
            d.need(not prior,'write must be first and once-only')
            d.need(intent['method']=='mcp__codex_apps__library_replace_library_file' and arguments=={
                'library_file_id':expected[2],'file':expected[1],'expected_current_version':expected[3],
                'version_reason':'V2 bounded journal/wave persistence; retain identity'},
                'Library write target/file/version differs from durable entry contract')
            payload=d.absolute(expected[1])
            d.need(payload.is_relative_to(d.absolute(sidecar.grant['producer_workspace']))
                   and d.filehash(payload)==control['local_blob_sha256'], 'entry payload bytes changed before Library write')
        else:
            d.need(counts['write']==1,'read/search without durable write')
            write=next(row for row in prior if row['kind']=='write')
            observed=d.read(_path(sidecar,write['observation_id'],'receipt'));d.verify(observed)
            d.need(observed['observation']['outcome']=='returned'
                   and observed['observation']['write_outcome']=='acknowledged_not_remote_byte_proof',
                   'write outcome unknown before read/search')
            item=structured(json.loads(observed['observation']['result_json']))
            d.need(isinstance(item,dict),'write result identity unavailable')
            if kind=='search':
                d.need(counts['read']==1 and counts['search']==0,'search outside original fallback order')
                d.need(intent['method']=='mcp__codex_apps__library_search' and arguments=={
                    'search_query':[{'q':json.dumps(item['file_name'],ensure_ascii=False,separators=(',',':')),'search_title_only':True}],
                    'scope':{'file_refs':[{'file_id':item['file_id'],'library_file_id':item['library_file_id']}],'surfaces':['library']},
                    'surfaces':['library'],'top_k':1,'result_format':'metadata_only'}, 'Library search target differs from actual write')
            if kind=='read':
                d.need(counts['search']==(1 if counts['read']==1 else 0),'read outside original sequence')
                d.need(intent['method']=='mcp__codex_apps__library_read' and arguments=={'read':[{'ref_id':item['file_id'],'mode':'full','max_lines':2}]},
                       'Library read target differs from actual write')
        d.need(intent['schema'] == 'library-wait-intent-v1'
               and d.sha(intent['arguments_json'].encode()) == intent['tool_arguments_sha256'], 'Library intent hash')
        entry = d.sealed({'token_sha256':d.sha(d.canon(token)), 'intent':intent,
                          'local_control':d.local_measurement(start,d.self_sample())})
        d.publish_once(_path(sidecar,intent['observation_id'],'intent'), entry)
        return entry['sha256']


def persist_observation(sidecar, token, observation):
    start = d.self_sample()
    with sidecar.locked():
        d.need(sidecar._state(sidecar._events())['pending'] == token, 'exact durable stage required')
        _bind(sidecar, token, observation)
        intent = d.read(_path(sidecar,observation['observation_id'],'intent')); d.verify(intent)
        d.need(intent['token_sha256'] == d.sha(d.canon(token)), 'Library intent token')
        for key in ('method','kind','observation_id','clock_domain_id','tool_arguments_sha256','arguments_json','order'):
            d.need(observation[key] == intent['intent'][key], 'Library operation changed: '+key)
        d.need(observation['schema'] == 'library-wait-observation-v1', 'Library receipt schema')
        entry = d.sealed({'token_sha256':d.sha(d.canon(token)), 'observation':observation,
                          'local_control':d.local_measurement(start,d.self_sample())})
        d.publish_once(_path(sidecar,observation['observation_id'],'receipt'), entry)
        return entry['sha256']


def verify_helper(sidecar, token, invocation, envelope):
    d.need(invocation['invocation_id'] == envelope['invocation_id']
           and invocation['command_sha256'] == envelope['command_sha256'], 'helper invocation mismatch')
    prefix = 'helper-'+hashlib.sha256(invocation['invocation_id'].encode()).hexdigest()
    intent = d.read(sidecar.root/(prefix+'.intent.json')); d.verify(intent)
    receipt = d.read(sidecar.root/(prefix+'.receipt.json')); d.verify(receipt)
    d.need(receipt['intent_sha256'] == intent['sha256'] and receipt['token_sha256'] == d.sha(d.canon(token))
           and receipt['command_sha256'] == invocation['command_sha256']
           and receipt['outcome'] == 'confirmed' and receipt['measurement_scope'] == 'SELF'
           and envelope['resource_receipt_sha256'] == receipt['sha256'], 'helper receipt unknown/unbound')
    d.need(receipt['launcher_source_sha256'] in sidecar.grant['operational_source_files'].values()
           and receipt['script_sha256'] in sidecar.grant['local_helper_source_files'].values(), 'helper source drift')
    return receipt


def close_stage(sidecar, token, snapshot, existing_receipt, extra_local_receipts=()):
    """Verify actual durable hooks and original fence before sidecar terminal ack."""
    close_control_start=d.self_sample()
    unknown_time = snapshot.get('timing_mode') == 'unobservable'
    d.need(not unknown_time or snapshot.get('accounting_supplement_sha256') == d.INCLUSIVE_SUPPLEMENT_SHA,
           'Library timing unknown requires exact supplement')
    d.need(snapshot.get('schema') == 'library-wait-meter-v1' and snapshot.get('status') == 'observed'
           and (snapshot.get('interval_coverage_complete') is True or unknown_time)
           and not snapshot.get('unknown_reasons'), 'Library meter outcome/persistence unknown')
    local, waits, matching = list(extra_local_receipts), [], []
    covered = set()
    for path in sidecar.root.glob('hook-*.intent.json'):
        hook_intent=d.read(path);d.verify(hook_intent)
        if hook_intent['token_sha256']==d.sha(d.canon(token)):
            d.need(path.with_name(path.name.replace('.intent.json','.receipt.json')).exists(),
                   'unfinished hook process; local resource unknown')
    for path in sidecar.root.glob('hook-*.receipt.json'):
        hook=d.read(path);d.verify(hook)
        if hook['token_sha256']!=d.sha(d.canon(token)):continue
        d.need(hook['outcome']=='confirmed'
               and hook['source_sha256'] in sidecar.grant['operational_source_files'].values(),
               'hook source/outcome unknown')
        local.extend(hook['measurements'])
        if hook.get('covers_library_observation'):
            row=hook['covers_library_observation'];covered.add((row['observation_id'],row['record']))
    all_intents = [d.read(p) for p in sidecar.root.glob('library-*.intent.json')]
    expected_ids = {v['intent']['observation_id'] for v in all_intents if v['token_sha256'] == d.sha(d.canon(token))}
    for observation in snapshot['observations']:
        try:
            _bind(sidecar,token,observation)
        except d.Stop:
            continue # Earlier stages in the same JS meter have different bindings.
        matching.append(observation)
        persisted = d.read(_path(sidecar,observation['observation_id'],'receipt')); d.verify(persisted)
        intent = d.read(_path(sidecar,observation['observation_id'],'intent')); d.verify(intent)
        d.need(persisted['observation'] == observation, 'Library returned object changed after retention')
        a,b,elapsed = observation['await_start_ms'],observation['await_end_ms'],observation['elapsed_ms']
        if unknown_time:
            d.need(a is None and b is None and elapsed is None and observation.get('timing_status') == 'unknown',
                   'unknown Library time must not become fabricated elapsed')
        else:
            d.need(all(type(v) in (int,float) and math.isfinite(v) for v in (a,b,elapsed))
                   and b >= a and elapsed == b-a, 'Library timing invalid')
        d.need(observation['outcome'] == 'returned', 'Library result unknown')
        d.need(observation['result_json'] is not None and d.sha(observation['result_json'].encode()) == observation['result_sha256'],
               'Library result hash mismatch')
        if observation['kind'] == 'write':
            d.need(observation['write_outcome'] == 'acknowledged_not_remote_byte_proof', 'unresolved Library write')
        if (observation['observation_id'],'intent') not in covered:local.append(intent['local_control'])
        if (observation['observation_id'],'receipt') not in covered:local.append(persisted['local_control'])
        waits.append({'clock_domain_id':observation['clock_domain_id'],'elapsed_seconds':None if unknown_time else elapsed/1000,
                      'timing_status':'unknown' if unknown_time else 'known', 'outcome':'confirmed','observation_sha256':persisted['sha256']})
    d.need({o['observation_id'] for o in matching} == expected_ids and matching, 'missing durable Library observation')
    counts={kind:sum(o['kind']==kind for o in matching) for kind in ('write','read','search')}
    index = token['stage'] != 'archive_commit'
    d.need(counts['write']==1 and counts['read'] <= (2 if index else 0) and counts['search'] <= (1 if index else 0), 'Library route ceiling')
    if index: d.need(counts['read'] >= 1, 'index readback missing')
    expected_helpers=[]
    for invocation in snapshot['local_helpers']:
        try:
            _bind(sidecar,token,invocation)
        except d.Stop:
            continue
        d.need(invocation['self_receipt_verified'] is True and invocation['self_receipt_json'], 'local helper SELF missing')
        envelope=json.loads(invocation['self_receipt_json'])
        d.need(d.sha(invocation['self_receipt_json'].encode()) == invocation['self_receipt_sha256'], 'helper envelope hash')
        receipt=verify_helper(sidecar,token,invocation,envelope)
        local.append(receipt['measurement']);expected_helpers.append(invocation['invocation_id'])
    actual_helpers=[d.read(p)['invocation_id'] for p in sidecar.root.glob('helper-*.intent.json')
                    if d.read(p)['token_sha256']==d.sha(d.canon(token))]
    d.need(set(actual_helpers)==set(expected_helpers) and expected_helpers, 'missing/unexpected local helper process')
    workspace=Path(sidecar.grant['producer_workspace'])
    writes=[o for o in matching if o['kind']=='write']
    write=writes[0];args=json.loads(write['arguments_json'])[0]
    item=structured(json.loads(write['result_json']))
    d.need(isinstance(item,dict) and item.get('status')=='succeeded', 'actual write acknowledgment missing')
    gate=d.read(sidecar.grant['bridge_gate_path'])
    expected_storage=gate['storage']['index_library_file_id' if index else 'archive_library_file_id']
    d.need(write['method']=='mcp__codex_apps__library_replace_library_file'
           and args.get('library_file_id')==expected_storage
           and existing_receipt.get('library_file_id')==item.get('library_file_id')==expected_storage
           and existing_receipt.get('file_id')==item.get('file_id')
           and existing_receipt.get('current_version_number')==item.get('current_version_number')
           and item['current_version_number']>args['expected_current_version'], 'stale/foreign stage write receipt')
    source_file=d.absolute(args['file'])
    d.need(source_file.is_relative_to(workspace)
           and d.filehash(source_file)==existing_receipt.get('local_blob_sha256'), 'stage local payload mismatch')
    retention=d.absolute(sidecar.grant['retention_audit_directory'])
    d.need(retention.is_relative_to(workspace), 'retention path outside original workspace')
    retained_intent=d.read(retention/write['operation_id']/'intent.json')
    retained_response=d.read(retention/write['operation_id']/'response.json')
    d.need(retained_intent.get('operation_id')==write['operation_id']
           and retained_intent.get('method')==write['method']
           and retained_intent.get('arguments')==args
           and retained_response==json.loads(write['result_json']), 'original retained intent/response mismatch')
    d.need(not (workspace/'state/external-pending.json').exists(), 'original Library write fence unresolved')
    actual=d.read(workspace/'state/commits'/f"{existing_receipt['library_file_id']}-{existing_receipt['current_version_number']}.json")
    d.need(actual == existing_receipt and actual.get('write_result_confirmed') is True
           and (not index or actual.get('index_readback_confirmed') is True), 'original fence/readback receipt mismatch')
    local.append(d.local_measurement(close_control_start,d.self_sample()))
    return sidecar.finish(token, local_receipts=local, library_waits=waits, evidence={
        'existing_external_fence_confirmed':True,'existing_receipt_sha256':d.sha(d.canon(actual)),
        'all_observed_local_helpers_have_SELF_receipts':True,'library_observer_healthy':True,
        'snapshot_sha256':d.sha(d.canon(snapshot)), 'verified_observation_ids':sorted(expected_ids),
        'verified_local_helper_invocation_ids':sorted(expected_helpers),
        'JS_plugin_and_unobservable_service_CPU':None})
