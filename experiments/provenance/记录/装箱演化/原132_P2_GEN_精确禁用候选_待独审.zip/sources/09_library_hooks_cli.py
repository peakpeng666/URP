"""Fixed stdin-JSON sidecar hooks for the authenticated JS bridge; no API calls."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import time

ENTRY_MONOTONIC = time.monotonic()
sys.path.insert(0,str(Path(__file__).resolve().parent))
import durable_generation_sidecar as d
import library_stage_sidecar as lib


def hook_path(root, hook_id, suffix):
    d.need(type(hook_id) is str and 1 <= len(hook_id) <= 200, 'hook ID')
    return root / ('hook-'+hashlib.sha256(hook_id.encode()).hexdigest()+'.'+suffix+'.json')


def _measure(start):
    return d.local_measurement(start,d.self_sample())


def invoke(action, body):
    start=d.self_sample();start['monotonic']=ENTRY_MONOTONIC
    root=d.absolute(body['journal_root'])
    identity=d.read(root/'identity.json');d.verify(identity)
    grant=d.read(d.absolute(body['grant_path']))
    sidecar=d.Sidecar(root,identity['binding'],grant,body['grant_sha256'])
    own=str(Path(__file__).resolve())
    d.need(grant['operational_source_files'].get(own)==d.filehash(own),'hook CLI source not pinned')
    sidecar._check_sources()
    token=body['token'];token_hash=d.sha(d.canon(token))
    d.need(sidecar.status()['pending']==token,'exact pending hook stage required')
    hook_id=body['hook_id']
    lease_path=root/('library-run-'+token_hash+'.json')
    if action!='enter':
        lease=d.read(lease_path);d.verify(lease)
        d.need(lease['token_sha256']==token_hash,'exact once-only Library run lease required')
    if action=='close':
        # Persist the close process prelude as an observed prefix; Entry.close
        # measures its own body and finish observes this process's later SELF.
        measurement=_measure(start)
        prefix=d.sealed({'schema':'library-hook-resource-v1','token_sha256':token_hash,
                         'hook_id':hook_id,'action':'close_prefix','measurements':[measurement],
                         'covers_library_observation':None,'outcome':'confirmed',
                         'local_Python_post_checkpoint_CPU_tail':None,'local_Python_wall_tail':None,
                         'source_sha256':d.filehash(own)})
        with sidecar.locked():d.publish_once(hook_path(root,hook_id,'receipt'),prefix)
        from production_generation_entry import ProductionEntry
        pending=body['pending']
        d.need(pending['token']==token,'pending entry token mismatch')
        state=ProductionEntry(sidecar).close_library(pending['position'],pending['stage'],body['snapshot'],body['receipt'])
        return {'pending':state['pending'],'halt':state['halt'],
                'self_cpu_seconds':state['self_cpu_seconds'],
                'local_inclusive_wall_seconds':state['local_inclusive_wall_seconds'],
                'CPU_cap_certification':'NOT_ESTABLISHED','generation_execution_granted_by_hook':False}
    d.need(action in ('enter','before','after','get','verify'),'fixed hook action only')
    with sidecar.locked():
        for path in root.glob('hook-*.intent.json'):
            prior=d.read(path);d.verify(prior)
            if prior['token_sha256']==token_hash:
                d.need(path.with_name(path.name.replace('.intent.json','.receipt.json')).exists(),
                       'prior hook outcome unknown; no replay')
        intent=d.sealed({'schema':'library-hook-intent-v1','token_sha256':token_hash,
                         'hook_id':hook_id,'action':action,'body_sha256':d.sha(d.canon(body)),
                         'source_sha256':d.filehash(own)})
        d.publish_once(hook_path(root,hook_id,'intent'),intent)
    covers=None
    if action=='enter':
        pending=body['pending']
        d.need(pending['token']==token and pending['stage']==token['stage'],'exact pending entry required')
        control=d.read(root/f'entry-{pending["position"]:02d}-{pending["stage"]}-begin-control.json');d.verify(control)
        d.need(control['token_sha256']==token_hash and control['commit_arguments']==pending['commit_arguments'],
               'Library entry arguments differ from durable controller')
        with sidecar.locked():
            d.publish_once(lease_path,d.sealed({'schema':'once-only-library-stage-run-v1',
                'token_sha256':token_hash,'hook_intent_sha256':intent['sha256'],
                'commit_arguments_sha256':d.sha(d.canon(pending['commit_arguments']))}))
        result={'once_only_stage_entered':True,'token_sha256':token_hash}
    elif action=='before':
        row=body['intent'];result=lib.persist_intent(sidecar,token,row)
        covers={'observation_id':row['observation_id'],'record':'intent'}
    elif action=='after':
        row=body['observation'];result=lib.persist_observation(sidecar,token,row)
        covers={'observation_id':row['observation_id'],'record':'receipt'}
    elif action=='get':
        invocation=body['invocation']
        name='helper-'+hashlib.sha256(invocation['invocation_id'].encode()).hexdigest()+'.receipt.json'
        resource=d.read(root/name);d.verify(resource)
        result={'invocation_id':invocation['invocation_id'],'command_sha256':invocation['command_sha256'],
                'measurement_scope':'SELF','resource_receipt_sha256':resource['sha256']}
        lib.verify_helper(sidecar,token,invocation,result)
    else:
        lib.verify_helper(sidecar,token,body['invocation'],body['envelope']);result=True
    receipt=d.sealed({'schema':'library-hook-resource-v1','token_sha256':token_hash,
                      'hook_id':hook_id,'action':action,'measurements':[_measure(start)],
                      'covers_library_observation':covers,'outcome':'confirmed',
                      'local_Python_post_checkpoint_CPU_tail':None,'local_Python_wall_tail':None,
                      'source_sha256':d.filehash(own)})
    with sidecar.locked():d.publish_once(hook_path(root,hook_id,'receipt'),receipt)
    return result


def main():
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=('enter','before','after','get','verify','close'))
    action=parser.parse_args().action
    raw=sys.stdin.buffer.read(8*1024*1024+1)
    d.need(0<len(raw)<=8*1024*1024,'hook JSON bound')
    body=json.loads(raw)
    result=invoke(action,body)
    print(json.dumps(result,separators=(',',':'),ensure_ascii=False,allow_nan=False))


if __name__=='__main__':main()
