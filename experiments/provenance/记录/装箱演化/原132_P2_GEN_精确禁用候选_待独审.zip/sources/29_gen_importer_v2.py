"""Read-only explicit schema compatibility; never activates or dispatches GEN."""
from recovery_core import *
def load_handoff(reference,g):
    Ledger(g,g["_grant_ref"],fixture=g.get("TEST_ONLY") is True).check()
    p=checked_ref(reference);h=read(p)
    if h.get("schema")==V1:
        need(not path(g["recovery_journal_root"]).exists(),"recovered namespace requires completed exact v2; no v1 downgrade")
        return validate_base(h,g)["measurements"],reference["file_sha256"]
    need(h.get("schema")==V2,"explicit v1/v2 required")
    need(h["status"]=="CONFIRMED" and h["generation_execution_granted"] is False
         and h["numeric_execution_granted"] is False and h["model_calls"]==h["candidate_executions"]==0,"v2 scope")
    need(h["producer_workspace"]==g["producer_workspace"] and h["operational_run_id"]==g["operational_run_id"]
         and h["reconciliation_grant_ref"]==g["_grant_ref"] and h["old_grant_ref"]==g["old_grant_ref"]
         and h["old_stop_zip_ref"]==g["stop_zip_ref"] and h["old_bridge_error_ref"]==g["old_bridge_error_ref"],"v2 binding")
    need(h["unknown"]==UNKNOWN and h["CPU_cap_certification"]=="NOT_ESTABLISHED"
         and h["complete_CPU_upper_bound_claimed"] is False and h["pool"]==g["pool"],"scope drift")
    for field in ("original_source_pins","original_implementation_pins","generation_original_pins","new_source_pins"):
        for name,digest in g[field].items():need(filehash(name)==digest,"import source drift")
    base=validate_base(read(checked_ref(h["base_handoff_ref"])),g)
    need(h["base_measurement_count"]==14 and h["base_receipt_count"]==16,"base counts")
    need(h["index_receipt"]==base["index_receipt"] and h["archive_receipt"]==base["archive_receipt"],"v2 receipts")
    need(h["new_source_pins"]==g["new_source_pins"],"new importer/source version")
    need(len(h["new_authenticated_read_refs"])==2,"two new reads")
    root=path(g["recovery_journal_root"])
    need([r["path"] for r in h["new_authenticated_read_refs"]]==
         [str(root/"read.backing.raw.json"),str(root/"read.head.raw.json")],"exact new read paths")
    for r in h["new_authenticated_read_refs"]:
        validate_read(read(checked_ref(r)),g["index"],Path(g["producer_workspace"]+"/index.initial.json").read_bytes())
    refs=h["recovery_receipt_files"];need(len(refs)==h["recovery_measurement_count"] and len(refs)>0,"delta count")
    expected=[str(root/f"delta-{i:04d}.receipt.json") for i in range(len(refs))]
    need([r["path"] for r in refs]==expected and len(list(root.glob("delta-*.intent.json")))==len(refs),"complete delta journal")
    delta=[]
    for i,r in enumerate(refs):
        v=read(checked_ref(r));need(v["outcome"]=="confirmed" and v["reconciliation_grant_ref"]==g["_grant_ref"]
           and v["intent_file_sha256"]==filehash(root/f"delta-{i:04d}.intent.json"),"delta binding")
        delta.append(v["measurement"])
    need(h["measurements"]==base["measurements"]+delta,"all14+k exactly, no omitted/extra checkpoint")
    c,w=totals(h["measurements"]);need(abs(c-h["observed_init_final_self_cpu_seconds"])<1e-8 and
        abs(w-h["observed_init_final_local_wall_seconds"])<1e-8,"v2 totals")
    admission(h["measurements"])
    need(not (root/"HALTED.json").exists() and
         Ledger(g,g["_grant_ref"],fixture=g.get("TEST_ONLY") is True).progress()==len(STAGES),"complete suffix")
    need(read(root/"entry.intent.json")=={"reconciliation_grant_ref":g["_grant_ref"]} and
         read(root/"finish.intent.json")=={"base_handoff_ref":h["base_handoff_ref"],"reconciliation_grant_ref":g["_grant_ref"]}
         and read(root/"finish.receipt.json")=={"outcome":"confirmed","handoff_ref":reference},"completed v2 seal")
    need(h["new_post_checkpoint_CPU_tails"] is None and h["new_post_checkpoint_wall_tails"] is None,
         "new tails remain unknown")
    return h["measurements"],reference["file_sha256"]
class ImportOnce:
    """Offline integration harness: same pool, durable import lease, exact rows once."""
    def __init__(self,root):self.root=path(root)
    def import_handoff(self,reference,g):
        ms,digest=load_handoff(reference,g);admission(ms)
        publish(self.root/"init-handoff-import.intent.json",{"digest":digest})
        publish(self.root/"init-handoff-import.receipt.json",{"digest":digest,"measurements":ms,
            "observed":totals(ms),"generation_execution_granted":False})
        return ms
