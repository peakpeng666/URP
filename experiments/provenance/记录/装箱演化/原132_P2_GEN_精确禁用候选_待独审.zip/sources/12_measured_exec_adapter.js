/* Operational launcher adapter only. Original V2 source remains unchanged.
 * Place BELOW the Library observer so its helper record hashes the original
 * command. Only a reviewed Python launch prefix is replaced; stdin heredoc,
 * script argv, tool options, returned Promise/value and thrown object survive.
 * No retries, extra exec calls, CPU limits, model calls or authentication.
 */
'use strict';
function createMeasuredExecAdapter(rawTools, options) {
  const quote = value => "'" + String(value).replaceAll("'", "'\\''") + "'";
  const required = ['launcherPath','journalRoot','grantPath','grantSha256'];
  for (const key of required) if (typeof options[key] !== 'string' || !options[key]) throw new Error('missing_'+key);
  if (!/^[0-9a-f]{64}$/.test(options.grantSha256) || typeof options.currentHelperInvocation !== 'function')
    throw new Error('unbound_helper_launcher');
  const routes = (options.originalLaunchPrefixes || []).map(route => {
    if (!['python3','python3 -I'].includes(route.python) || typeof route.scriptPath !== 'string' || !route.scriptPath.startsWith('/'))
      throw new Error('unsafe_original_helper_route');
    return Object.freeze({...route,prefix:route.python+' '+quote(route.scriptPath)+' '});
  });
  if (!routes.length) throw new Error('no_pinned_helper_routes');
  return new Proxy(rawTools,{get(target,property){
    if (property !== 'exec_command') return Reflect.get(target,property,target);
    return args => {
      const current=options.currentHelperInvocation();
      if (!current || current.method!=='exec_command' || !/^[0-9a-f]{64}$/.test(current.command_sha256 || '') ||
          !/^[A-Za-z0-9_.:-]{1,180}$/.test(current.invocation_id || '')) throw new Error('no_observed_helper_invocation');
      const matching=routes.filter(route => typeof args?.cmd==='string' && args.cmd.startsWith(route.prefix));
      if (matching.length!==1) throw new Error('unrecognized_helper_command_stop');
      const route=matching[0];
      const prefix=route.python+' '+quote(options.launcherPath)+' --journal '+quote(options.journalRoot)+
        ' --grant '+quote(options.grantPath)+' --grant-sha256 '+quote(options.grantSha256)+
        ' --invocation-id '+quote(current.invocation_id)+' --command-sha256 '+quote(current.command_sha256)+
        ' --script '+quote(route.scriptPath)+' -- ';
      return Reflect.apply(target.exec_command,target,[{...args,cmd:prefix+args.cmd.slice(route.prefix.length)}]);
    };
  }});
}
if (typeof module!=='undefined' && module.exports) module.exports={createMeasuredExecAdapter};
