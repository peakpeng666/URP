/* Fixed real-executor hook factory; every action uses the pinned local CLI.
 * Call with raw tools, never the measured Library proxy (avoids recursion).
 * No arbitrary Python snippets, API requests, writes to Library, or retries.
 */
'use strict';
function createProductionLibraryHooks(rawTools,config){
  const q=x=>"'"+String(x).replaceAll("'","'\\''")+"'";
  if(typeof rawTools?.exec_command!=='function' || !config?.cliPath?.startsWith('/') ||
     !config?.journalRoot?.startsWith('/') || !config?.grantPath?.startsWith('/') ||
     !/^[a-f0-9]{64}$/.test(config.grantSha256||''))throw new Error('unbound_hook_CLI');
  let number=0;
  async function run(action,token,fields){
    const body={journal_root:config.journalRoot,grant_path:config.grantPath,
      grant_sha256:config.grantSha256,token,hook_id:token.nonce+'.hook.'+(++number),...fields};
    const json=JSON.stringify(body);
    const cmd='python3 -I '+q(config.cliPath)+' '+q(action)+" <<'SIDECAR_HOOK_JSON'\n"+json+"\nSIDECAR_HOOK_JSON";
    const result=await rawTools.exec_command({cmd,login:false,max_output_tokens:3000,yield_time_ms:30000});
    if(result?.exit_code!==0 || typeof result.output!=='string')throw new Error('durable_sidecar_hook_unknown_'+action);
    try{return JSON.parse(result.output);}catch(_){throw new Error('sidecar_hook_output_unknown_'+action);}
  }
  return Object.freeze({
    enterStage:pending=>run('enter',pending.token,{pending}),
    beforeOperation:(token,intent)=>run('before',token,{intent}),
    afterObservation:(token,observation)=>run('after',token,{observation}),
    getHelperReceipt:(token,invocation)=>run('get',token,{invocation}),
    verifyHelperReceipt:(token,invocation,envelope)=>run('verify',token,{invocation,envelope}),
    closeStage:(pending,snapshot,receipt)=>run('close',pending.token,{pending,snapshot,receipt})
  });
}
if(typeof module!=='undefined'&&module.exports)module.exports={createProductionLibraryHooks};
