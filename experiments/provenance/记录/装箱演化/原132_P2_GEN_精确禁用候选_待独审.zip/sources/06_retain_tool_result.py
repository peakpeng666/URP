"""Local durability only. This helper never calls Library or clears a fence.

start DIRECTORY accepts an exact serialized request envelope on stdin and
creates DIRECTORY exclusively. response/exception DIRECTORY retains one exact
serialized tool-result/error envelope. Existing records are never overwritten.
"""
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile


def fsync_directory(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def no_symlinks(path):
    for p in [path, *path.parents]:
        if p.is_symlink():
            raise ValueError('symlink_path_stop')


def retain(path, raw):
    no_symlinks(path)
    fd, temporary = tempfile.mkstemp(prefix='.record-tmp-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        os.link(temporary, path)  # Atomic exclusive publish; never overwrite.
        fsync_directory(path.parent)
    finally:
        os.unlink(temporary)
        fsync_directory(path.parent)


if __name__ == '__main__':
    action, directory = sys.argv[1:]
    directory = Path(directory)
    if '..' in directory.parts:
        raise ValueError('parent_component_stop')
    no_symlinks(directory)
    raw = sys.stdin.buffer.read(8 * 1024 * 1024 + 1)
    if not 0 < len(raw) <= 8 * 1024 * 1024:
        raise ValueError('record_size_stop')
    json.loads(raw)
    if action == 'start':
        # The caller must create/pin the parent audit directory separately.
        directory.mkdir(mode=0o700, exist_ok=False)
        fsync_directory(directory.parent)
        target = directory / 'intent.json'
    elif action in ('response', 'exception'):
        no_symlinks(directory / 'intent.json')
        if not (directory / 'intent.json').is_file():
            raise ValueError('missing_durable_intent_stop')
        target = directory / (action + '.json')
    else:
        raise ValueError('unsupported_action')
    retain(target, raw)
    print(json.dumps({'path': str(target), 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}))
