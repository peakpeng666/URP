from pathlib import Path
import json,hashlib,time
r=Path(__file__).parent; start=time.process_time(); n=0
for kind in ('data','audit'):
 p=r/kind;m=json.loads((p/'FILE_MANIFEST.json').read_text())
 for f,meta in m.items():
  b=(p/f).read_bytes();assert len(b)==meta['bytes'] and hashlib.sha256(b).hexdigest()==meta['sha256'];n+=1
p=r/'data'; original=Path('/workspace/shared/minimal_generation_runner_20261007')
for name in ('runner.py','frozen_inputs.json'): assert (p/'executor'/name).read_bytes()==(original/name).read_bytes()
f=json.loads((p/'executor/frozen_inputs.json').read_text());out=[]
for s in f['slots'][7:13]:
 rec=s['record'];q=p/'ledger'/rec['slot_id'];d=json.loads((q/'dispatch.json').read_text());v=json.loads((q/'result.json').read_text())
 assert d['position']==rec['position']==v['position'] and d['order']==rec['order']
 assert d['slot_id']==rec['slot_id']==v['slot_id'] and d['arm']==rec['arm']
 assert hashlib.sha256((q/'prompt.txt').read_bytes()).hexdigest()==rec['prompt_sha256']==d['prompt_sha256']
 assert d['configuration']==f['freeze']['configuration']
 assert d['config_sha256']==rec['config_file_sha256']
 assert hashlib.sha256((q/'answer.txt').read_bytes()).hexdigest()==v['answer_sha256']
 assert len((q/'answer.txt').read_bytes())==v['answer_bytes']
 assert not v['capture_issues'] and v['requested_timeout_seconds']==900
 if v['client_state']=='timeout':
  category='timeout_empty';assert v['answer_bytes']==0 and v['exit_code']!=0 and not v['finish_reasons']
 elif v['finish_reasons']==['length']:
  category='length_empty';assert v['answer_bytes']==0 and v['exit_code']==0
 else:
  category='stop_nonempty';assert v['client_state']=='exited' and v['exit_code']==0 and v['finish_reasons']==['stop'] and v['answer_bytes']>0
 assert v['wall_seconds']>0
 out.append({'position':v['position'],'slot_id':v['slot_id'],'answer_bytes':v['answer_bytes'],'wall_seconds':v['wall_seconds'],'category':category,'CLI_reported_tokens':v['cli_reported_tokens']})
assert len(list((p/'ledger').iterdir()))==6
assert sorted(x['category'] for x in out)==sorted(['stop_nonempty']*4+['length_empty','timeout_empty'])
res={'status':'PASS_targeted_generation_archive_review','archive_member_hashes':n,'slots':out,'frozen_inputs_and_runner_equal_previously_reviewed':True,'parameters_and_frozen_prompt_hashes_equal':True,'empty_answers':2,'CLI_exit_zero':5,'nonempty_public_answers':4,'length_empty':1,'client_timeout_empty':1,'readback_data_sha256':'9fbf2ac1558b39c8b371ab9dc8363724e725332fb9239d3b36cbdd3ee57deef1','readback_audit_sha256':'1fe34d134709db0e24f3b667cc311d26a3e348e803a3b3f7ae8569ee4625d940','scientific_admission_or_scoring_performed':False,'provider_request_body_or_usage_independently_verified':False,'historical_resource_full_cap_certification':False,'notes':'CLI records and archive bytes checked; not proof of provider HTTP attempts, billed usage, algorithm correctness, or complete historical resource balance. Existing original generation scope included local 61440 seconds; no new budget inferred from elapsed observation.','cpu_seconds':time.process_time()-start}
(r/'REVIEW.json').write_text(json.dumps(res,ensure_ascii=False,indent=2));print(json.dumps(res,ensure_ascii=False,indent=2))
