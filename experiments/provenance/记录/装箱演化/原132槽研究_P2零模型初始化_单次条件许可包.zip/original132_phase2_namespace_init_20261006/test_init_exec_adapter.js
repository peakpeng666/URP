'use strict';
const assert=require('node:assert/strict'), fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const {createInitExecAdapter}=require('./init_exec_adapter');
const source=path.resolve(__dirname,'..','original132_phase1_preparation_20261005');
const commitSource=fs.readFileSync(source+'/exporter/src/library_commit_v2.js','utf8');
const retentionSource=fs.readFileSync(source+'/retention/retain_library_replies.js','utf8');
const config=kind=>({workspace:'/fixture/p2',launcherPath:'/fixture/init/init_local_helper.py',grantPath:'/fixture/grant.json',
  grantSha256:'a'.repeat(64),retentionHelperPath:'/fixture/original/retain_tool_result.py',kind});
async function one(kind){
 const calls=[], c=config(kind),id='libfile_fixture_'+kind;
 const item={status:'succeeded',library_file_id:id,file_id:'file_fixture_'+kind,current_version_number:0,file_name:'fixture.json',xattrs:[]};
 const raw={
  exec_command:async x=>{calls.push(['exec',x]);return {exit_code:0,output:x.cmd.includes("--step '"+kind+".receipt'")?
    JSON.stringify({library_file_id:id,file_id:item.file_id,current_version_number:0,write_result_confirmed:true,
    remote_bytes_verified:false,index_readback_confirmed:kind==='index',local_blob_sha256:'b'.repeat(64),local_blob_bytes:3}):'{}'};},
  mcp__codex_apps__library_create_library_file:async x=>{calls.push(['create',x]);return {structuredContent:item};},
  mcp__codex_apps__library_read:async x=>{calls.push(['read',x]);return {structuredContent:{results:[{file_id:item.file_id,library_file_id:id,has_more:false,content:['{}']}]}};},
  mcp__codex_apps__library_search:async()=>{throw Error('unneeded search in fixture');},
  apply_patch:async x=>{calls.push(['patch',x]);return {};}
 };
 const adapted=createInitExecAdapter(raw,c);
 const retain=vm.runInNewContext(retentionSource+'\nretainLibraryReplies');
 const tools=retain(adapted,{auditDirectory:c.workspace+'/retained-library-replies',operationId:'phase2-init-'+kind,helperPath:c.retentionHelperPath});
 const commit=vm.runInNewContext(commitSource+'\ncommitV2',{tools});
 const result=await commit(c.workspace,c.workspace+(kind==='index'?'/index.initial.json':'/archive.initial.zip'),null,-1,kind==='index');
 assert.equal(result.library_file_id,id);assert.equal(calls.filter(x=>x[0]==='create').length,1);
 const execs=calls.filter(x=>x[0]==='exec');assert.equal(execs.length,6);
 for(const x of execs){assert.ok(x[1].cmd.includes("--original-command 'python3"));assert.equal(x[1].login,false);}
 assert.ok(execs.find(x=>x[1].cmd.includes("--step '"+kind+".xattrs'")).at(1).cmd.startsWith('python3 '));
 assert.ok(execs.find(x=>x[1].cmd.includes("--step '"+kind+".retain-response'")).at(1).cmd.includes("<<'RETAIN_LIBRARY_OBJECT_JSON'\n"+JSON.stringify({structuredContent:item})));
 await assert.rejects(adapted.exec_command({cmd:'python3 -c "print(1)"'}),/unknown_or_arbitrary/);
 await assert.rejects(adapted.mcp__codex_apps__library_create_library_file({file:c.workspace+'/index.initial.json',library_artifact_type:'other'}),/only_once/);
 assert.throws(()=>adapted.mcp__codex_apps__library_replace_library_file,/not_allowlisted/);
}
(async()=>{await one('index');await one('archive');console.log('PASS original commitV2 + original retainLibraryReplies, both fixed zero-model create routes; 12 mocked helpers; stdout/options/stdin preserved; arbitrary command, replacement and repeat blocked.');})().catch(e=>{console.error(e);process.exitCode=1;});
