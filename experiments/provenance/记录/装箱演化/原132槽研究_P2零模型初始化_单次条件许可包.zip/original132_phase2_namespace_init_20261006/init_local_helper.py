"""Fixed zero-model INIT launcher. Checkpoints only; no supervisor/hard cap/retry."""
import time
ENTRY_MONOTONIC = time.monotonic()
import argparse
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import resource
import runpy
import sys
import uuid
ORIGINAL_SYS_PATH = tuple(sys.path)
PROCESS = str(os.getpid()) + ':' + uuid.uuid4().hex
HERE = Path(__file__).resolve().parent
STEPS = ['build'] + [kind + '.' + action for kind in ('index', 'archive')
                            for action in ('begin', 'retain-start', 'retain-response', 'xattrs', 'receipt', 'confirm')]
IMPL = ('init_local_helper.py', 'empty_artifact_builder.py', 'init_exec_adapter.js',
        'assemble_handoff.py', 'init_bridge.js', 'ORIGINAL_SOURCE_PINS.json', 'pinned_originals/library_file_transfer.py')

def need(ok, why):
    if not ok: raise RuntimeError(why)
def canon(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode()
def sha(raw): return hashlib.sha256(raw).hexdigest()
def read(path): return json.loads(Path(path).read_bytes())
def filehash(path): return sha(Path(path).read_bytes())
def absolute(path):
    p = Path(path)
    need(p.is_absolute() and '..' not in p.parts and str(p) == str(p.resolve()), 'noncanonical path')
    need(not any(x.is_symlink() for x in (p, *p.parents)), 'symlink path')
    return p

def publish(path, value):
    # Any partial record is intentionally blocking. Never repair or overwrite it.
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(canon(value)); stream.flush(); os.fsync(stream.fileno())
    fd = os.open(Path(path).parent, os.O_RDONLY | os.O_DIRECTORY)
    try: os.fsync(fd)
    finally: os.close(fd)

def sample():
    r = resource.getrusage(resource.RUSAGE_SELF)
    return {'process': PROCESS, 'pid': os.getpid(), 'monotonic': time.monotonic(), 'self_cpu': r.ru_utime+r.ru_stime}
def measurement(entry=ENTRY_MONOTONIC):
    end = sample(); start = dict(end, monotonic=entry, self_cpu=0.0)
    wall = end['monotonic']-entry
    need(math.isfinite(wall) and wall >= 0, 'unknown monotonic sample')
    return {'process': PROCESS, 'start': start, 'end': end, 'self_cpu_seconds': end['self_cpu'],
        'wall_seconds': wall, 'local_inclusive_wall_seconds': wall, 'native_wait_union_seconds': 0,
        'measurement_status': 'known', 'wall_semantics': 'local_stage_inclusive_no_wait_deduction',
        'RUSAGE_kind': 'RUSAGE_SELF', 'native_CLI_CPU': None, 'provider_CPU': None}

def validate_grant(path, digest):
    path = absolute(path); need(filehash(path) == digest, 'grant exact file hash mismatch')
    g = read(path)
    need(g.get('schema') == 'phase2-namespace-init-grant-v1' and g.get('init_execution_granted') is True
         and g.get('independent_review_accepted') is True, 'INIT disabled or unreviewed')
    need(g.get('generation_execution_granted') is False and g.get('model_requests') == 0
         and g.get('candidate_executions') == 0 and g.get('library_create_count') == 2, 'zero-model INIT only')
    need(g.get('original_scientific_run_id') == 'urp132_20261005_b01'
         and g.get('operational_run_id') == 'urp132_20261005_b01_phase2', 'wrong run identities')
    need(g.get('init_final_self_cpu_allowance_seconds') == 60
         and g.get('init_final_local_wall_allowance_seconds') == 240, 'shared init_final allowance changed')
    w = absolute(g['producer_workspace']); j = absolute(g['journal_root'])
    need(j == w.parent/(w.name+'.namespace-init') and absolute(g['implementation_root']) == HERE, 'fixed INIT namespace')
    need(len(g['forbidden_prior_library_file_ids']) == 4
         and len(set(g['forbidden_prior_library_file_ids'])) == 4
         and all(x.startswith('libfile_') for x in g['forbidden_prior_library_file_ids']), 'pin all four P0/P1 identities')
    need(set(g['implementation_files']) == set(IMPL), 'exact implementation pins required')
    for name, digest in g['implementation_files'].items():
        need(filehash(HERE/name) == digest, 'implementation drift: '+name)
    pins = read(HERE/'ORIGINAL_SOURCE_PINS.json'); source = absolute(g['original_source_root'])
    expected = {str(source/name):digest for name,digest in pins['files'].items()}
    expected[str(HERE/pins['bundled_xattrs_helper']['path'])] = pins['bundled_xattrs_helper']['file_sha256']
    need(g['exact_original_source_pins'] == expected, 'original source map changed')
    for name,digest in expected.items():
        need(filehash(absolute(name)) == digest, 'original source drift: '+name)
    need(sha(canon(pins['exporter_files'])) == pins['exporter_aggregate_sha256'] ==
         'bf12db4c3524087bd70bce7b6e76b8f7f85e07207d507d7d6a2408feb008b08c', 'original V2 aggregate')
    return g

def paths(g):
    w = Path(g['producer_workspace']); s = Path(g['original_source_root'])
    return {'builder': HERE/'empty_artifact_builder.py', 'fence': w/'src/external_commit_fence_v2.py',
        'retention': s/'original132_phase1_preparation_20261005/retention/retain_tool_result.py',
        'xattrs': w/'.library-helpers-current/library_file_transfer.py', 'receipt': w/'src/commit_receipt_v2.py'}

def route(g, step, script, argv, isolated, grant_path):
    p = paths(g); w = Path(g['producer_workspace'])
    if step == 'build':
        need(script == p['builder'] and argv == [str(grant_path)] and isolated, 'fixed empty builder only')
        need(not w.exists(), 'fresh producer workspace required; never reuse')
        return
    kind, action = step.split('.')
    blob = str(w/('index.initial.json' if kind == 'index' else 'archive.initial.zip'))
    if action in ('begin','confirm'):
        expected = [action,str(w),blob,'null','-1',kind]; key='fence'
    elif action.startswith('retain-'):
        key='retention'; a = argv[0] if argv else ''
        need(a == ('start' if action == 'retain-start' else 'response') or
             (action == 'retain-response' and a == 'exception'), 'fixed retention action')
        expected = [a,str(w/'retained-library-replies'/('phase2-init-'+kind))]
    elif action == 'xattrs':
        key='xattrs'; need(len(argv)==3 and argv[0]=='apply-xattrs' and argv[1]==blob, 'xattrs exact target')
        need(argv[2].startswith('libfile_') and argv[2] not in g['forbidden_prior_library_file_ids'], 'prior Library identity forbidden')
        expected = argv
    else:
        key='receipt'; need(len(argv)==4, 'receipt arguments')
        payload = absolute(argv[3]); need(payload.parent == w/'state' and payload.name.startswith('readback-libfile_')
            and payload.suffix == '.json', 'fixed V2 readback path')
        expected = [blob,'-1',kind,str(payload)]
    need(script == p[key] and argv == expected and isolated == (key != 'xattrs'), 'unrecognized helper/argv/launch mode')
    pins = read(HERE/'ORIGINAL_SOURCE_PINS.json')
    expected_hash = (pins['files']['original132_phase1_preparation_20261005/retention/retain_tool_result.py'] if key=='retention'
        else pins['bundled_xattrs_helper']['file_sha256'] if key=='xattrs'
        else pins['exporter_files']['src/'+script.name])
    need(filehash(script) == expected_hash, 'helper target source drift')
    for name,digest in pins['exporter_files'].items():
        need(filehash(w/name) == digest, 'copied V2 dependency drift')
    need(set(x.name for x in (w/'src').glob('*.py')) | set(x.name for x in (w/'src').glob('*.js')) ==
         {Path(x).name for x in pins['exporter_files']}, 'extra V2 source forbidden')

def records(g, expected_count=None):
    j = Path(g['journal_root']); receipts=[]
    actual = sorted(x.name for x in j.glob('helper-*.intent.json'))
    for n, step in enumerate(STEPS):
        ip = j/f'helper-{n:02d}.intent.json'; rp = j/f'helper-{n:02d}.receipt.json'
        if not ip.exists():
            need(not rp.exists(), 'orphan receipt'); continue
        need(n==len(receipts) and rp.exists(), 'unresolved helper; never rerun')
        intent=read(ip); r=read(rp)
        need(intent['step']==step and r['step']==step and r['intent_file_sha256']==filehash(ip)
             and r['init_grant_file_sha256']==g['_file_sha256'] and r['outcome']=='confirmed', 'unknown helper outcome')
        m=r['measurement']; need(m['measurement_status']=='known' and m['native_wait_union_seconds']==0, 'unknown measurement')
        need(m['start']['self_cpu']==0 and m['self_cpu_seconds']==m['end']['self_cpu'], 'cumulative SELF checkpoint required')
        need(all(type(m[k]) in (int,float) and math.isfinite(m[k]) and m[k]>=0
                 for k in ('self_cpu_seconds','wall_seconds','local_inclusive_wall_seconds')), 'invalid measurement')
        receipts.append(r)
    need(len(actual)==len(receipts), 'unexpected helper intent')
    if expected_count is not None: need(len(receipts)==expected_count, 'fixed helper order required')
    return receipts

def within(receipts, current):
    checkpoints={}
    for r in receipts:
        m=r['measurement']; checkpoints[m['process']]=max(checkpoints.get(m['process'],0),m['end']['self_cpu'])
    checkpoints[current['process']]=max(checkpoints.get(current['process'],0),current['end']['self_cpu'])
    cpu=sum(checkpoints.values()); wall=sum(r['measurement']['local_inclusive_wall_seconds'] for r in receipts)+current['local_inclusive_wall_seconds']
    return cpu < 60 and wall < 240, cpu, wall

def execute(grant_path, grant_sha, step, script, argv, original_command=None):
    g=validate_grant(grant_path,grant_sha); g['_file_sha256']=grant_sha
    need(step in STEPS,'unknown helper step'); script=absolute(script)
    route(g,step,script,argv,bool(sys.flags.isolated),absolute(grant_path))
    j=Path(g['journal_root'])
    if step=='build': j.mkdir(mode=0o700,exist_ok=False)
    need(j.is_dir(),'missing INIT journal')
    with (j/'lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        n=STEPS.index(step); prior=records(g,n)
        need(not (j/'assembly.intent.json').exists(),'INIT already assembled; never replay')
        need(within(prior,measurement())[0], 'observed shared init_final allowance exhausted')
        ip=j/f'helper-{n:02d}.intent.json'; rp=j/f'helper-{n:02d}.receipt.json'
        publish(ip,{'schema':'phase2-init-helper-intent-v1','step':step,'init_grant_file_sha256':grant_sha,
            'script_path':str(script),'script_sha256':filehash(script),'argv':[str(script),*argv],
            'original_command_sha256':None if original_command is None else sha(original_command.encode()),
            'isolated':bool(sys.flags.isolated)})
        saved_argv=sys.argv; saved_path=list(sys.path); raised=None
        try:
            sys.argv=[str(script),*argv]; sys.path[:]=ORIGINAL_SYS_PATH
            if not sys.flags.isolated: sys.path[0:1]=[str(script.parent)]
            runpy.run_path(str(script),run_name='__main__')
        except BaseException as exc: raised=exc
        finally: sys.argv=saved_argv; sys.path[:]=saved_path
        try:
            m=measurement(); ok,cpu,wall=within(prior,m)
            success=(raised is None or isinstance(raised,SystemExit) and raised.code in (0,None)) and ok
            retained_exception=step.endswith('retain-response') and argv[0]=='exception'
            publish(rp,{'schema':'phase2-init-helper-receipt-v1','step':step,'init_grant_file_sha256':grant_sha,
                'intent_file_sha256':filehash(ip),'script_sha256':filehash(script),'measurement':m,
                'outcome':'confirmed' if success and not retained_exception else 'unknown',
                'observed_init_final_self_cpu_seconds':cpu,'observed_init_final_local_wall_seconds':wall,
                'post_checkpoint_receipt_and_exit_tail_CPU':None,
                'post_checkpoint_receipt_and_exit_tail_wall':None,'CPU_cap_certification':'NOT_ESTABLISHED'})
        except BaseException:
            # Original helper exception wins; unreceipted durable intent remains unknown.
            if raised is not None: raise raised
            raise
        if raised is not None: raise raised
        # A successful exception-retention helper keeps its original zero exit.
        # Its unknown journal outcome blocks EVERY subsequent invocation, while
        # unchanged retainLibraryReplies can rethrow the original Library error.
        need(success,'helper exception or observed allowance exceeded; global stop')

def main():
    a=argparse.ArgumentParser(); a.add_argument('--grant',required=True);a.add_argument('--grant-sha256',required=True)
    a.add_argument('--step',required=True,choices=STEPS);a.add_argument('--script',required=True)
    a.add_argument('--original-command');a.add_argument('arguments',nargs=argparse.REMAINDER);v=a.parse_args()
    execute(v.grant,v.grant_sha256,v.step,v.script,v.arguments[1:] if v.arguments[:1]==['--'] else v.arguments,v.original_command)
if __name__=='__main__': main()
