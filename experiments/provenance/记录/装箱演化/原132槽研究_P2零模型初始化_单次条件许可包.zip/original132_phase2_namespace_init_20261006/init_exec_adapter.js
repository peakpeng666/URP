/* Prefix-only adapter below unchanged retainLibraryReplies + commitV2.
 * Explicitly fixed INIT routes. It preserves original stdin, argv and exec options.
 * No evaluation, shell command API, model route, replacements or retry is added.
 */
'use strict';
function createInitExecAdapter(rawTools, c) {
  const q=x=>"'"+String(x).replaceAll("'","'\\''")+"'";
  const need=(x,s)=>{if(!x)throw Error(s);};
  for(const k of ['workspace','launcherPath','grantPath','retentionHelperPath'])
    need(/^\/[A-Za-z0-9_./-]+$/.test(c[k]||'')&&!c[k].split('/').includes('..'),'canonical_simple_path_'+k);
  need(['index','archive'].includes(c.kind)&&/^[a-f0-9]{64}$/.test(c.grantSha256||''),'unbound_INIT_adapter');
  const w=c.workspace,kind=c.kind,blob=w+(kind==='index'?'/index.initial.json':'/archive.initial.zip');
  const routes=[
    {script:w+'/src/external_commit_fence_v2.py',python:'python3 -I',action:'begin',tail:'begin '+[w,blob,'null','-1',kind].map(q).join(' ')},
    {script:c.retentionHelperPath,python:'python3 -I',action:'retain-start',tail:q('start')+' '+q(w+'/retained-library-replies/phase2-init-'+kind),marker:'RETAIN_LIBRARY_OBJECT_JSON'},
    {script:c.retentionHelperPath,python:'python3 -I',action:'retain-response',tail:q('response')+' '+q(w+'/retained-library-replies/phase2-init-'+kind),marker:'RETAIN_LIBRARY_OBJECT_JSON'},
    {script:c.retentionHelperPath,python:'python3 -I',action:'retain-response',tail:q('exception')+' '+q(w+'/retained-library-replies/phase2-init-'+kind),marker:'RETAIN_LIBRARY_OBJECT_JSON'},
    {script:w+'/.library-helpers-current/library_file_transfer.py',python:'python3',action:'xattrs',dynamic:'xattrs',marker:'LIBRARY_XATTRS_JSON'},
    {script:w+'/src/commit_receipt_v2.py',python:'python3 -I',action:'receipt',dynamic:'receipt'},
    {script:w+'/src/external_commit_fence_v2.py',python:'python3 -I',action:'confirm',tail:'confirm '+[w,blob,'null','-1',kind].map(q).join(' '),marker:'CONFIRMED_RECEIPT_JSON'}
  ];
  let created=false,halted=false,item=null,readCount=0,searched=false,lastRow=null,patched=false;
  function structured(r){let x=r?.structuredContent;if(!x)for(const b of r?.content??[])if(b.type==='text'){try{x=JSON.parse(b.text);break;}catch{}}
    while(x?.structuredContent)x=x.structuredContent;return x;}
  const equal=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
  const identityReady=()=>item&&/^libfile_[A-Za-z0-9_-]+$/.test(item.library_file_id)&&
    /^file_[A-Za-z0-9_-]+$/.test(item.file_id)&&Number.isInteger(item.current_version_number)&&item.current_version_number>=0;
  const wrap=new Proxy(rawTools,{get(target,key){
    if(key==='exec_command')return async args=>{
      need(!halted,'INIT_adapter_halted');
      const cmd=args?.cmd; need(typeof cmd==='string','missing_original_command');
      let chosen=null;
      for(const r of routes){
        const prefix=r.python+' '+q(r.script)+' ';
        if(!cmd.startsWith(prefix))continue;
        let suffix=cmd.slice(prefix.length),head=suffix;
        if(r.marker){
          const split=" <<'"+r.marker+"'\n",end='\n'+r.marker;
          const at=suffix.indexOf(split);
          if(at<0||!suffix.endsWith(end))continue;
          head=suffix.slice(0,at);const body=suffix.slice(at+split.length,-end.length);
          if(body.includes('\n'))continue;
          try{JSON.parse(body);}catch(_){continue;}
        } else if(suffix.includes('\n'))continue;
        let good=head===r.tail;
        if(r.dynamic==='xattrs')good=head.startsWith('apply-xattrs '+q(blob)+' ')&&
          /^'libfile_[A-Za-z0-9_-]+'$/.test(head.slice(('apply-xattrs '+q(blob)+' ').length));
        if(r.dynamic==='receipt')good=head.startsWith([blob,'-1',kind].map(q).join(' ')+' ')&&
          new RegExp("^'"+w.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+"/state/readback-libfile_[A-Za-z0-9_-]+-[0-9]+\\.json'$").test(head.slice(([blob,'-1',kind].map(q).join(' ')+' ').length));
        if(good){need(chosen===null,'ambiguous_route');chosen={...r,prefix};}
      }
      need(chosen!==null,'unknown_or_arbitrary_command_stop');
      const r=chosen;
      const launch=r.python+' '+q(c.launcherPath)+' --grant '+q(c.grantPath)+' --grant-sha256 '+q(c.grantSha256)+
        ' --step '+q(kind+'.'+r.action)+' --script '+q(r.script)+' --original-command '+q(cmd)+' -- ';
      let result;
      try{result=await target.exec_command({...args,cmd:launch+cmd.slice(r.prefix.length)});}catch(e){halted=true;throw e;}
      if(result?.exit_code!==0)halted=true;
      return result;
    };
    if(key==='mcp__codex_apps__library_create_library_file')return async args=>{
      need(!halted&&!created&&JSON.stringify(Object.keys(args).sort())===JSON.stringify(['file','library_artifact_type'])&&
        args.file===blob&&args.library_artifact_type==='other','only_once_new_empty_artifact');
      created=true;const response=await target[key](args);item=structured(response);return response;
    };
    if(key==='mcp__codex_apps__library_read')return async args=>{
      need(!halted&&kind==='index'&&created&&identityReady()&&readCount<2&&
        (readCount===0||searched)&&equal(args,{read:[{ref_id:item.file_id,mode:'full',max_lines:2}]}),'only_initial_index_readback');
      readCount++;const result=await target[key](args);lastRow=structured(result)?.results?.[0];return result;
    };
    if(key==='mcp__codex_apps__library_search')return args=>{
      need(!halted&&kind==='index'&&created&&identityReady()&&readCount===1&&!searched&&
        (lastRow?.file_id!==item.file_id||lastRow?.has_more!==false)&&equal(args,
        {search_query:[{q:JSON.stringify(item.file_name),search_title_only:true}],
          scope:{file_refs:[{file_id:item.file_id,library_file_id:item.library_file_id}],surfaces:['library']},
          surfaces:['library'],top_k:1,result_format:'metadata_only'}),'only_original_bounded_refresh');
      searched=true;return target[key](args);
    };
    if(key==='apply_patch')return patch=>{
      need(!halted&&created&&identityReady()&&!patched&&typeof patch==='string','only_original_receipt_payload');
      const prefix='*** Begin Patch\n*** Add File: '+w+'/state/readback-'+item.library_file_id+'-'+item.current_version_number+'.json\n+';
      const suffix='\n*** End Patch';need(patch.startsWith(prefix)&&patch.endsWith(suffix),'exact_readback_path_required');
      const body=patch.slice(prefix.length,-suffix.length);need(!body.includes('\n'),'one_payload_only');
      let payload;try{payload=JSON.parse(body);}catch{throw Error('invalid_readback_payload');}
      let readback=null;
      if(kind==='index'){
        need(lastRow?.file_id===item.file_id&&lastRow?.has_more===false&&Array.isArray(lastRow.content),'confirmed_readback_required');
        readback={file_id:lastRow.file_id,library_file_id:lastRow.library_file_id,content:lastRow.content.join('\n'),has_more:lastRow.has_more};
      }
      need(equal(payload,{item:{status:item.status,library_file_id:item.library_file_id,file_id:item.file_id,
        current_version_number:item.current_version_number},readback}),'exact_original_payload_required');
      patched=true;return target.apply_patch(patch);
    };
    throw Error('INIT_tool_not_allowlisted_'+String(key));
  }});
  return wrap;
}
if(typeof module!=='undefined'&&module.exports)module.exports={createInitExecAdapter};
