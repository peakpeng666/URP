"""Once-only local handoff assembly after both original commits; no Library calls."""
import time
ENTRY=time.monotonic()
import argparse
import fcntl
import json
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import init_local_helper as h

def assemble(grant_path,grant_sha):
    g=h.validate_grant(grant_path,grant_sha);g['_file_sha256']=grant_sha
    w=Path(g['producer_workspace']);j=Path(g['journal_root'])
    with (j/'lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        prior=h.records(g,13)
        h.need(h.within(prior,h.measurement(ENTRY))[0],'observed shared init_final exhausted before assembly')
        h.publish(j/'assembly.intent.json',{'schema':'phase2-init-assembly-intent-v1','init_grant_file_sha256':grant_sha})
        h.need(not (w/'state/external-pending.json').exists(),'unresolved original external fence')
        receipts={}; receipt_files=[]
        for kind in ('index','archive'):
            raw=h.read(w/'retained-library-replies'/('phase2-init-'+kind)/'response.json')
            item=raw.get('structuredContent')
            if not item:
                for block in raw.get('content',[]):
                    if block.get('type')=='text':
                        try:item=json.loads(block['text']);break
                        except (ValueError,TypeError):pass
            while isinstance(item,dict) and item.get('structuredContent'):item=item['structuredContent']
            h.need(not raw.get('isError') and isinstance(item,dict) and item.get('status')=='succeeded','unknown Library create')
            identity=item['library_file_id'];version=item['current_version_number']
            h.need(identity not in g['forbidden_prior_library_file_ids'] and type(version) is int and version>=0,'prior identity or version')
            rp=w/'state/commits'/(identity+'-'+str(version)+'.json'); receipt=h.read(rp)
            blob=w/('index.initial.json' if kind=='index' else 'archive.initial.zip')
            h.need(receipt['library_file_id']==identity and receipt['file_id']==item['file_id']
                and receipt['current_version_number']==version and receipt['write_result_confirmed'] is True
                and receipt['local_blob_sha256']==h.filehash(blob) and receipt['local_blob_bytes']==blob.stat().st_size
                and receipt['remote_bytes_verified'] is False and receipt['index_readback_confirmed']==(kind=='index'), 'original receipt mismatch')
            receipts[kind]=receipt;receipt_files.append({'path':str(rp),'file_sha256':h.filehash(rp)})
        h.need(receipts['index']['library_file_id']!=receipts['archive']['library_file_id'],'new identities must differ')
        for n in range(13):
            rp=j/f'helper-{n:02d}.receipt.json';receipt_files.append({'path':str(rp),'file_sha256':h.filehash(rp)})
        measured=h.measurement(ENTRY);ok,cpu,wall=h.within(prior,measured)
        h.need(ok,'observed shared init_final allowance exhausted at final assembly checkpoint')
        ar={'schema':'phase2-init-assembly-receipt-v1','outcome':'confirmed','measurement':measured,
            'init_grant_file_sha256':grant_sha,'intent_file_sha256':h.filehash(j/'assembly.intent.json'),
            'post_checkpoint_receipt_handoff_and_exit_tail_CPU':None,'post_checkpoint_receipt_handoff_and_exit_tail_wall':None}
        h.publish(j/'assembly.receipt.json',ar)
        receipt_files.append({'path':str(j/'assembly.receipt.json'),'file_sha256':h.filehash(j/'assembly.receipt.json')})
        result={'schema':'phase2-namespace-init-resource-handoff-v1','status':'CONFIRMED',
            'init_grant_file_sha256':grant_sha,'exact_original_source_pins':g['exact_original_source_pins'],
            'original_scientific_run_id':g['original_scientific_run_id'],'operational_run_id':g['operational_run_id'],
            'producer_workspace':str(w),'index_receipt':receipts['index'],'archive_receipt':receipts['archive'],
            'model_calls':0,'candidate_executions':0,'measurements':[r['measurement'] for r in prior]+[measured],
            'receipt_files':receipt_files,'observed_init_final_self_cpu_seconds':cpu,
            'observed_init_final_local_wall_seconds':wall,'pool':'same_init_final_60_SELF_CPU_240_local_wall',
            'CPU_cap_certification':'NOT_ESTABLISHED','complete_CPU_upper_bound_claimed':False,
            'unknown':{'post_checkpoint_local_CPU_tails':None,'post_checkpoint_local_wall_tails':None,
                'Python_pre_entry_monotonic_startup_wall':None,'Library_wait_seconds':None,
                'assistant_bridge_JS_CPU':None,'provider_CPU':None},
            'generation_execution_granted':False,'original_total_CPU_1860_and_wall_61440':'observed checkpoint/stage-window admission thresholds only'}
        target=j/'INIT_RESOURCE_HANDOFF.json';h.publish(target,result)
        print(json.dumps({'path':str(target),'file_sha256':h.filehash(target),'status':'CONFIRMED'}))
        return result

def main():
    a=argparse.ArgumentParser();a.add_argument('--grant',required=True);a.add_argument('--grant-sha256',required=True);v=a.parse_args()
    assemble(v.grant,v.grant_sha256)
if __name__=='__main__':main()
