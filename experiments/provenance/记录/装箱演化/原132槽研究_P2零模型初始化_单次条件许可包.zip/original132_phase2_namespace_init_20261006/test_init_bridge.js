'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {initializeNamespace,initSha256}=require('./init_bridge');
const base=path.resolve(__dirname,'..','original132_phase1_preparation_20261005');
const sources={commit:fs.readFileSync(base+'/exporter/src/library_commit_v2.js','utf8'),
  retention:fs.readFileSync(base+'/retention/retain_library_replies.js','utf8'),adapter:fs.readFileSync(__dirname+'/init_exec_adapter.js','utf8')};
const grant={schema:'phase2-namespace-init-grant-v1',init_execution_granted:true,independent_review_accepted:true,
  generation_execution_granted:false,model_requests:0,candidate_executions:0,library_create_count:2,
  implementation_root:'/fixture/init',original_source_root:'/fixture/source',producer_workspace:'/fixture/producer',
  implementation_files:{'init_exec_adapter.js':initSha256(sources.adapter)}};
function fakeTools(fail){
 const calls=[];let current;
 const tools={exec_command:async args=>{calls.push(['helper',args]);return {exit_code:0,output:args.cmd.includes(".receipt'")?
    JSON.stringify({library_file_id:current.library_file_id,file_id:current.file_id,current_version_number:0,
      write_result_confirmed:true,remote_bytes_verified:false,index_readback_confirmed:current.file_id.endsWith('index'),
      local_blob_sha256:'b'.repeat(64),local_blob_bytes:3}):'{}'};},
  mcp__codex_apps__library_create_library_file:async args=>{calls.push(['create',args]);if(fail)throw fail;
    const kind=args.file.endsWith('.json')?'index':'archive';current={status:'succeeded',library_file_id:'libfile_fixture_'+kind,
      file_id:'file_fixture_'+kind,current_version_number:0,file_name:kind+'.json',xattrs:[]};return {structuredContent:current};},
  mcp__codex_apps__library_read:async()=>({structuredContent:{results:[{file_id:current.file_id,library_file_id:current.library_file_id,has_more:false,content:['{}']}]}}),
  mcp__codex_apps__library_search:async()=>{throw Error('unneeded refresh');},apply_patch:async args=>{calls.push(['patch',args]);return {};}};
 return {tools,calls};
}
(async()=>{
 for(const s of ['', 'abc','中文🧮','a'.repeat(1234)])assert.equal(initSha256(s),crypto.createHash('sha256').update(s).digest('hex'));
 const text=JSON.stringify(grant),digest=initSha256(text),f=fakeTools();
 const r=await initializeNamespace(f.tools,text,digest,'/fixture/grant.json',sources);
 assert.equal(r.index.current_version_number,0);assert.equal(r.archive.current_version_number,0);
 assert.equal(f.calls.filter(x=>x[0]==='create').length,2);assert.equal(f.calls.filter(x=>x[0]==='helper').length,12);
 for(const bad of [ {...sources,commit:sources.commit+'\n'}, {...sources,retention:sources.retention+'\n'}, {...sources,adapter:sources.adapter+'\n'}, {...sources,arbitrary:'x'}]){
  const unused=fakeTools();await assert.rejects(initializeNamespace(unused.tools,text,digest,'/fixture/grant.json',bad));assert.equal(unused.calls.length,0);
 }
 const disabled=JSON.stringify({...grant,init_execution_granted:false});await assert.rejects(initializeNamespace({},disabled,initSha256(disabled),'/fixture/grant.json',sources));
 await assert.rejects(initializeNamespace({},text,'f'.repeat(64),'/fixture/grant.json',sources));
 const sentinel=Object.freeze({message:'original Library sentinel'}),fault=fakeTools(sentinel);
 try{await initializeNamespace(fault.tools,text,digest,'/fixture/grant.json',sources);assert.fail('expected original exception');}catch(error){assert.equal(error,sentinel);}
 assert.equal(fault.calls.filter(x=>x[0]==='create').length,1);
 console.log('PASS fixed bridge: exact grant bytes and original JS source hashes; two fixed null/-1 creates with v0; no source injection; original exception stops before archive; SHA256 vectors.');
})().catch(e=>{console.error(e);process.exitCode=1;});
