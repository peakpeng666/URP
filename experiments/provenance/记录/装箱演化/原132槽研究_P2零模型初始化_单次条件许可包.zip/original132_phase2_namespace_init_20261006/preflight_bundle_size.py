"""Read-only preparation, before signing/using INIT; never initializes a namespace."""
import hashlib
import json
from pathlib import Path
import sys

def main():
    gp=Path(sys.argv[1]);g=json.loads(gp.read_bytes());here=Path(g['implementation_root']);s=Path(g['original_source_root']);w=Path(g['producer_workspace'])
    files={'commit':s/'original132_phase1_preparation_20261005/exporter/src/library_commit_v2.js',
           'retention':s/'original132_phase1_preparation_20261005/retention/retain_library_replies.js',
           'adapter':here/'init_exec_adapter.js'}
    sources={name:path.read_text('utf-8') for name,path in files.items()}
    for name,path in files.items():
        expected=g['implementation_files']['init_exec_adapter.js'] if name=='adapter' else g['exact_original_source_pins'][str(path)]
        if hashlib.sha256(sources[name].encode()).hexdigest()!=expected:raise RuntimeError('source drift')
    bridge=(here/'init_bridge.js').read_text('utf-8')
    if hashlib.sha256(bridge.encode()).hexdigest()!=g['implementation_files']['init_bridge.js']:raise RuntimeError('bridge drift')
    archive={'local_blob_path':str(w/'archive.initial.zip'),'local_blob_sha256':'f'*64,'local_blob_bytes':99999999,'slot_count':0,'phase':2}
    payload={'empty_index_path':str(w/'index.initial.json'),'archive':archive,'model_requests':0,'candidate_executions':0,
        'grant_file_text':gp.read_text('utf-8'),'fixed_bridge_source':bridge,'sources':sources}
    n=len(json.dumps(payload).encode()+b'\n')
    if n>26000:raise RuntimeError('source bundle exceeds 26000-byte ceiling; do not authorize or run INIT')
    print(json.dumps({'preparation_only':True,'namespace_created':False,'grant_file_sha256':hashlib.sha256(gp.read_bytes()).hexdigest(),
        'stdout_UTF8_byte_upper_bound':n,'conservative_byte_token_upper_bound':n,'required_exec_max_output_tokens':30000,
        'runtime_stdout_byte_ceiling':26000,'bound_reason':'ASCII JSON; SHA strings fixed64; archive byte-count uses 8-digit ceiling; all actual consumer-local grant paths/source bytes included',
        'tool_hard_cap_independently_verified':False,'if_tool_truncates':'read existing durable helper receipt and saved bundle bytes/SHA only; never repeat builder or create'}))
if __name__=='__main__':main()
