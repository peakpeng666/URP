"""No Library/model calls. Only temporary fixture namespaces and synthetic replies."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest import mock
sys.path.insert(0,str(Path(__file__).resolve().parent))
import init_local_helper as h
HERE=Path(__file__).resolve().parent
SOURCE=HERE.parent

def grant(directory):
    g={'schema':'phase2-namespace-init-grant-v1','init_execution_granted':True,
       'independent_review_accepted':True,'generation_execution_granted':False,'model_requests':0,
       'candidate_executions':0,'library_create_count':2,'original_scientific_run_id':'urp132_20261005_b01',
       'operational_run_id':'urp132_20261005_b01_phase2','init_final_self_cpu_allowance_seconds':60,
       'init_final_local_wall_allowance_seconds':240,'producer_workspace':str(directory/'fixture-producer'),
       'journal_root':str(directory/'fixture-producer.namespace-init'),'implementation_root':str(HERE),
       'original_source_root':str(SOURCE),'forbidden_prior_library_file_ids':['libfile_fixture_p0_i','libfile_fixture_p0_a','libfile_fixture_p1_i','libfile_fixture_p1_a'],
       'implementation_files':{n:h.filehash(HERE/n) for n in h.IMPL},
       'exact_original_source_pins':{str(SOURCE/n):v for n,v in h.read(HERE/'ORIGINAL_SOURCE_PINS.json')['files'].items()}}
    pin=h.read(HERE/'ORIGINAL_SOURCE_PINS.json')['bundled_xattrs_helper']
    g['exact_original_source_pins'][str(HERE/pin['path'])]=pin['file_sha256']
    gp=directory/'fixture.grant.json';gp.write_bytes(h.canon(g));return g,gp,h.filehash(gp)

def invoke(g,gp,digest,step,key,args,stdin=None):
    script=h.paths(g)[key]
    command=[sys.executable]+([] if key=='xattrs' else ['-I'])+[str(HERE/'init_local_helper.py'),
      '--grant',str(gp),'--grant-sha256',digest,'--step',step,'--script',str(script),'--',*args]
    return subprocess.run(command,input=stdin,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)

class Fixtures(unittest.TestCase):
    def assert_ok(self,result):self.assertEqual(result.returncode,0,result.stderr);return result.stdout
    def test_disabled_blocks_before_namespace(self):
        with tempfile.TemporaryDirectory(prefix='trusted-init-fixture-') as t:
            g,gp,d=grant(Path(t));g['init_execution_granted']=False;gp.write_bytes(h.canon(g))
            r=invoke(g,gp,h.filehash(gp),'build','builder',[str(gp)])
            self.assertNotEqual(r.returncode,0);self.assertFalse(Path(g['producer_workspace']).exists())
    def test_source_drift_blocks(self):
        with tempfile.TemporaryDirectory(prefix='trusted-init-fixture-') as t:
            g,gp,d=grant(Path(t));g['implementation_files']['init_local_helper.py']='0'*64;gp.write_bytes(h.canon(g))
            self.assertNotEqual(invoke(g,gp,h.filehash(gp),'build','builder',[str(gp)]).returncode,0)
    def test_actual_original_helpers_empty_artifacts_and_handoff(self):
        with tempfile.TemporaryDirectory(prefix='trusted-init-fixture-') as t:
            g,gp,d=grant(Path(t));w=Path(g['producer_workspace']);j=Path(g['journal_root'])
            built=json.loads(self.assert_ok(invoke(g,gp,d,'build','builder',[str(gp)])))
            self.assertEqual(built['grant_file_text'],gp.read_text())
            saved_bundle=w/'state/INIT_BRIDGE_BUNDLE.json'
            self.assertEqual(h.read(saved_bundle),built)
            saved_meta=h.read(w/'state/INIT_BRIDGE_BUNDLE.sha256.json')
            self.assertEqual(saved_meta['file_sha256'],h.filehash(saved_bundle))
            bound=subprocess.run([sys.executable,'-I',str(HERE/'preflight_bundle_size.py'),str(gp)],capture_output=True,text=True)
            self.assert_ok(bound)
            self.assertGreaterEqual(json.loads(bound.stdout)['stdout_UTF8_byte_upper_bound'],saved_bundle.stat().st_size)
            self.assertEqual(h.sha(built['fixed_bridge_source'].encode()),g['implementation_files']['init_bridge.js'])
            self.assertEqual(set(built['sources']),{'commit','retention','adapter'})
            self.assertNotEqual(invoke(g,gp,d,'build','builder',[str(gp)]).returncode,0)
            self.assertEqual(h.read(w/'index.initial.json')['rows'],[])
            for kind in ('index','archive'):
                blob=w/('index.initial.json' if kind=='index' else 'archive.initial.zip')
                common=[str(w),str(blob),'null','-1',kind]
                self.assert_ok(invoke(g,gp,d,kind+'.begin','fence',['begin',*common]))
                rd=w/'retained-library-replies'/('phase2-init-'+kind)
                intent={'schema':'retained-library-tool-intent-v1','operation_id':'phase2-init-'+kind,
                    'method':'mcp__codex_apps__library_create_library_file','arguments':{'file':str(blob),'library_artifact_type':'other'}}
                self.assert_ok(invoke(g,gp,d,kind+'.retain-start','retention',['start',str(rd)],json.dumps(intent)+'\n'))
                item={'status':'succeeded','library_file_id':'libfile_fixture_'+kind,'file_id':'file_fixture_'+kind,
                      'current_version_number':0,'xattrs':[]}
                response={'structuredContent':item}
                self.assert_ok(invoke(g,gp,d,kind+'.retain-response','retention',['response',str(rd)],json.dumps(response)+'\n'))
                self.assert_ok(invoke(g,gp,d,kind+'.xattrs','xattrs',['apply-xattrs',str(blob),item['library_file_id']],'[]\n'))
                readback=None if kind=='archive' else {'file_id':item['file_id'],'library_file_id':item['library_file_id'],
                           'content':blob.read_text(),'has_more':False}
                payload=w/'state'/('readback-'+item['library_file_id']+'-0.json');payload.write_text(json.dumps({'item':item,'readback':readback}))
                text=self.assert_ok(invoke(g,gp,d,kind+'.receipt','receipt',[str(blob),'-1',kind,str(payload)]))
                receipt=json.loads(text);self.assertIs(receipt['remote_bytes_verified'],False)
                self.assert_ok(invoke(g,gp,d,kind+'.confirm','fence',['confirm',*common],json.dumps(receipt)+'\n'))
            result=subprocess.run([sys.executable,'-I',str(HERE/'assemble_handoff.py'),'--grant',str(gp),'--grant-sha256',d],capture_output=True,text=True)
            self.assert_ok(result); handoff=h.read(j/'INIT_RESOURCE_HANDOFF.json')
            self.assertEqual(len(handoff['measurements']),14);self.assertEqual(len(handoff['receipt_files']),16)
            self.assertEqual(handoff['index_receipt']['current_version_number'],0)
            self.assertEqual(handoff['archive_receipt']['index_readback_confirmed'],False)
            self.assertEqual(handoff['CPU_cap_certification'],'NOT_ESTABLISHED')
            self.assertTrue(all(h.filehash(x['path'])==x['file_sha256'] for x in handoff['receipt_files']))
            repeated=subprocess.run([sys.executable,'-I',str(HERE/'assemble_handoff.py'),'--grant',str(gp),'--grant-sha256',d],capture_output=True,text=True)
            self.assertNotEqual(repeated.returncode,0)
    def test_unresolved_helper_blocks_next(self):
        with tempfile.TemporaryDirectory(prefix='trusted-init-fixture-') as t:
            g,gp,d=grant(Path(t));self.assert_ok(invoke(g,gp,d,'build','builder',[str(gp)]))
            j=Path(g['journal_root']);(j/'helper-00.receipt.json').unlink()
            w=Path(g['producer_workspace'])
            r=invoke(g,gp,d,'index.begin','fence',['begin',str(w),str(w/'index.initial.json'),'null','-1','index'])
            self.assertNotEqual(r.returncode,0);self.assertFalse((w/'state/external-pending.json').exists())
    def test_original_exception_identity_survives_end_sample_or_receipt_failure(self):
        class Sentinel(BaseException):pass
        for fault in ('none','sample','publish'):
            with self.subTest(fault=fault), tempfile.TemporaryDirectory(prefix='trusted-init-fixture-') as t:
                g,gp,d=grant(Path(t));sentinel=Sentinel('original helper sentinel')
                real_publish=h.publish
                def failing_publish(path,value):
                    if Path(path).name.endswith('.receipt.json'):raise RuntimeError('receipt publication failed')
                    return real_publish(path,value)
                with mock.patch.object(h,'route'), mock.patch.object(h.runpy,'run_path',side_effect=sentinel):
                    if fault=='sample':
                        first=h.measurement()
                        with mock.patch.object(h,'measurement',side_effect=[first,RuntimeError('end sample failed')]):
                            with self.assertRaises(Sentinel) as caught:h.execute(gp,d,'build',HERE/'empty_artifact_builder.py',[str(gp)])
                    elif fault=='publish':
                        with mock.patch.object(h,'publish',side_effect=failing_publish):
                            with self.assertRaises(Sentinel) as caught:h.execute(gp,d,'build',HERE/'empty_artifact_builder.py',[str(gp)])
                    else:
                        with self.assertRaises(Sentinel) as caught:h.execute(gp,d,'build',HERE/'empty_artifact_builder.py',[str(gp)])
                self.assertIs(caught.exception,sentinel)
                j=Path(g['journal_root']);self.assertTrue((j/'helper-00.intent.json').exists())
                if fault=='none':self.assertEqual(h.read(j/'helper-00.receipt.json')['outcome'],'unknown')
                else:self.assertFalse((j/'helper-00.receipt.json').exists())
    def test_exception_retention_preserves_exit_zero_but_blocks_followup(self):
        with tempfile.TemporaryDirectory(prefix='trusted-init-fixture-') as t:
            g,gp,d=grant(Path(t));w=Path(g['producer_workspace'])
            self.assert_ok(invoke(g,gp,d,'build','builder',[str(gp)]))
            self.assert_ok(invoke(g,gp,d,'index.begin','fence',['begin',str(w),str(w/'index.initial.json'),'null','-1','index']))
            rd=w/'retained-library-replies/phase2-init-index'
            self.assert_ok(invoke(g,gp,d,'index.retain-start','retention',['start',str(rd)],'{}\n'))
            self.assert_ok(invoke(g,gp,d,'index.retain-response','retention',['exception',str(rd)],'{"write_outcome":"unknown"}\n'))
            self.assertEqual(h.read(Path(g['journal_root'])/'helper-03.receipt.json')['outcome'],'unknown')
            self.assertNotEqual(invoke(g,gp,d,'index.xattrs','xattrs',['apply-xattrs',str(w/'index.initial.json'),'libfile_fixture_index'],'[]\n').returncode,0)
            self.assertTrue((w/'state/external-pending.json').exists())
    def test_shared_pool_and_unknown_measurements(self):
        current={'process':'p','end':{'self_cpu':3},'local_inclusive_wall_seconds':4}
        prior=[{'measurement':{'process':'q','end':{'self_cpu':57},'local_inclusive_wall_seconds':5}}]
        self.assertFalse(h.within(prior,current)[0])
        prior[0]['measurement']['end']['self_cpu']=1;prior[0]['measurement']['local_inclusive_wall_seconds']=236
        self.assertFalse(h.within(prior,current)[0])
        prior[0]['measurement']['process']='p';prior[0]['measurement']['local_inclusive_wall_seconds']=5
        self.assertEqual(h.within(prior,current),(True,3,9))
if __name__=='__main__':unittest.main(verbosity=2)
