/* Fixed assistant-only composition. Exact source bytes, two new IDs, no retries.
 * rawTools must be the authenticated assistant's original tools, not a callback
 * registry. Sources are data and are evaluated only after exact SHA256 checks.
 */
'use strict';
function initSha256(text) {
  const bytes=Array.from(unescape(encodeURIComponent(text)),c=>c.charCodeAt(0));
  const bits=bytes.length*8;bytes.push(128);while(bytes.length%64!==56)bytes.push(0);
  const hi=Math.floor(bits/4294967296),lo=bits>>>0;
  for(const n of [hi,lo])for(let s=24;s>=0;s-=8)bytes.push((n>>>s)&255);
  const K=[0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
  let H=[0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
  const r=(x,n)=>(x>>>n)|(x<<(32-n));
  for(let p=0;p<bytes.length;p+=64){
    const w=Array(64).fill(0);for(let i=0;i<16;i++)w[i]=(bytes[p+i*4]<<24)|(bytes[p+i*4+1]<<16)|(bytes[p+i*4+2]<<8)|bytes[p+i*4+3];
    for(let i=16;i<64;i++){const a=w[i-15],b=w[i-2];w[i]=((r(a,7)^r(a,18)^(a>>>3))+w[i-16]+(r(b,17)^r(b,19)^(b>>>10))+w[i-7])|0;}
    let [a,b,c,d,e,f,g,h]=H;
    for(let i=0;i<64;i++){const t1=(h+(r(e,6)^r(e,11)^r(e,25))+((e&f)^(~e&g))+K[i]+w[i])|0;
      const t2=((r(a,2)^r(a,13)^r(a,22))+((a&b)^(a&c)^(b&c)))|0;
      h=g;g=f;f=e;e=(d+t1)|0;d=c;c=b;b=a;a=(t1+t2)|0;}
    H=H.map((x,i)=>(x+[a,b,c,d,e,f,g,h][i])|0);
  }
  return H.map(x=>(x>>>0).toString(16).padStart(8,'0')).join('');
}
async function initializeNamespace(rawTools, grantFileText, expectedGrantFileSha256, grantPath, sources) {
  const need=(v,s)=>{if(!v)throw Error(s);};
  need(typeof grantFileText==='string'&&initSha256(grantFileText)===expectedGrantFileSha256,'INIT_grant_exact_file_hash');
  const g=JSON.parse(grantFileText);
  need(g.schema==='phase2-namespace-init-grant-v1'&&g.init_execution_granted===true&&g.independent_review_accepted===true&&
    g.generation_execution_granted===false&&g.model_requests===0&&g.candidate_executions===0&&g.library_create_count===2,
    'INIT_disabled_or_wrong_scope');
  const fixed={commit:'a870f16d05b5db17a94be6544beb725d69fe6a429b41d3bb5ba7fe646811270d',
    retention:'e44fec0c2059aa184825fd1d75c9eed851858c55230f22cb1650a7ab89ff0f6c',
    adapter:g.implementation_files['init_exec_adapter.js']};
  need(sources!==null&&typeof sources==='object','fixed_JS_source_data');
  const descriptors=Object.getOwnPropertyDescriptors(sources);
  need(Object.keys(descriptors).sort().join(',')==='adapter,commit,retention','fixed_three_JS_sources');
  const snapshot={};
  for(const name of ['adapter','commit','retention']){
    const descriptor=descriptors[name];
    need(descriptor&&Object.prototype.hasOwnProperty.call(descriptor,'value')&&typeof descriptor.value==='string',
      'JS_sources_must_be_own_primitive_data_no_accessors');
    snapshot[name]=descriptor.value;
  }
  const verifiedSources=Object.freeze(snapshot);
  for(const [name,digest] of Object.entries(fixed))need(/^[a-f0-9]{64}$/.test(digest)&&initSha256(verifiedSources[name])===digest,'INIT_source_pin_'+name);
  const create=Function(verifiedSources.adapter+'\nreturn createInitExecAdapter;')();
  const retain=Function(verifiedSources.retention+'\nreturn retainLibraryReplies;')();
  const results={};
  // Exactly this fixed pair; no caller-supplied step, callbacks or identities.
  for(const kind of ['index','archive']){
    const c={workspace:g.producer_workspace,launcherPath:g.implementation_root+'/init_local_helper.py',
      grantPath,grantSha256:expectedGrantFileSha256,
      retentionHelperPath:g.original_source_root+'/original132_phase1_preparation_20261005/retention/retain_tool_result.py',kind};
    const guarded=create(rawTools,c);
    const retained=retain(guarded,{auditDirectory:c.workspace+'/retained-library-replies',operationId:'phase2-init-'+kind,helperPath:c.retentionHelperPath});
    const commit=Function('tools',verifiedSources.commit+'\nreturn commitV2;')(retained);
    results[kind]=await commit(c.workspace,c.workspace+(kind==='index'?'/index.initial.json':'/archive.initial.zip'),null,-1,kind==='index');
  }
  return results;
}
if(typeof module!=='undefined'&&module.exports)module.exports={initializeNamespace,initSha256};
