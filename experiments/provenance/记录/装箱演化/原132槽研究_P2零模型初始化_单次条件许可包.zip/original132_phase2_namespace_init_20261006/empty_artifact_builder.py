"""Fixed empty P2 namespace only; launched once by the reviewed INIT wrapper."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys

def main():
    grant=json.loads(Path(sys.argv[1]).read_bytes()); w=Path(grant['producer_workspace'])
    # Wrapper has already checked grant, every original source pin and absence.
    if not grant.get('init_execution_granted') or w.exists(): raise RuntimeError('disabled or nonfresh namespace')
    w.mkdir(mode=0o700)
    for name in ('src','state','dispatch-fences','retained','retained-library-replies','.library-helpers-current'):
        (w/name).mkdir(mode=0o700)
    source=Path(grant['original_source_root'])
    pins=json.loads((Path(__file__).parent/'ORIGINAL_SOURCE_PINS.json').read_bytes())
    for name,digest in pins['exporter_files'].items():
        shutil.copyfile(source/'original132_phase1_preparation_20261005/exporter'/name,w/name)
        if hashlib.sha256((w/name).read_bytes()).hexdigest()!=digest: raise RuntimeError('copied source hash')
    shutil.copyfile(Path(__file__).parent/'pinned_originals/library_file_transfer.py',
                    w/'.library-helpers-current/library_file_transfer.py')
    index=source/'original132_phase2_continuation_draft_20261006/inputs/index.initial.json'
    raw=index.read_bytes(); obj=json.loads(raw)
    if obj['rows']!=[] or obj['archives']!={} or obj['run_id']!='urp132_20261005_b01_phase2': raise RuntimeError('nonempty initial index')
    (w/'index.initial.json').write_bytes(raw)
    sys.path.insert(0,str(w/'src'))
    from protocol_v2 import verify_index
    from driver_v2 import build_wave_archive
    verify_index(obj)
    result=build_wave_archive(w/'archive.initial.zip',phase=2)
    if result['slot_count']!=0: raise RuntimeError('nonempty archive')
    here=Path(__file__).resolve().parent
    selected={'commit':source/'original132_phase1_preparation_20261005/exporter/src/library_commit_v2.js',
        'retention':source/'original132_phase1_preparation_20261005/retention/retain_library_replies.js',
        'adapter':here/'init_exec_adapter.js'}
    sources={name:path.read_text('utf-8') for name,path in selected.items()}
    for name,path in selected.items():
        expected=(grant['implementation_files']['init_exec_adapter.js'] if name=='adapter'
                  else grant['exact_original_source_pins'][str(path)])
        if hashlib.sha256(sources[name].encode()).hexdigest()!=expected:raise RuntimeError('bridge source text pin')
    bridge=(here/'init_bridge.js').read_text('utf-8')
    if hashlib.sha256(bridge.encode()).hexdigest()!=grant['implementation_files']['init_bridge.js']:raise RuntimeError('fixed bridge source pin')
    bundle=json.dumps({'empty_index_path':str(w/'index.initial.json'),'archive':result,'model_requests':0,'candidate_executions':0,
        'grant_file_text':Path(sys.argv[1]).read_text('utf-8'),'fixed_bridge_source':bridge,'sources':sources}).encode()+b'\n'
    if len(bundle)>26000:raise RuntimeError('prepared bundle exceeded 26000-byte stdout ceiling; stop')
    def publish_bytes(path,raw):
        temporary=path.with_name('.'+path.name+'.pending')
        fd=os.open(temporary,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(fd,'wb') as stream:stream.write(raw);stream.flush();os.fsync(stream.fileno())
        os.link(temporary,path);os.unlink(temporary)
        fd=os.open(path.parent,os.O_RDONLY|os.O_DIRECTORY)
        try:os.fsync(fd)
        finally:os.close(fd)
    target=w/'state/INIT_BRIDGE_BUNDLE.json'
    publish_bytes(target,bundle)
    publish_bytes(w/'state/INIT_BRIDGE_BUNDLE.sha256.json',json.dumps({'path':str(target),'file_sha256':hashlib.sha256(bundle).hexdigest(),'bytes':len(bundle)}).encode())
    sys.stdout.buffer.write(bundle);sys.stdout.buffer.flush()
if __name__=='__main__': main()
