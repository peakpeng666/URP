# P2 namespace INIT: disabled, zero-model, once-only

This is preparation and trusted-fixture evidence only. No real INIT grant, new Library identity, model request, candidate execution, CLI invocation, or GEN activation is included. Parent authorization after independent review is still required. Execute real INIT only in the original producer thread, never in this preparation workspace. Do not alter the bound P2 package's 177 members or any original exporter/retention source.

## Parent must bind before signing once

Create a NEW grant from `INIT_GRANT_TEMPLATE.json`; do not merely flip the template. Set the exact file SHA-256 of that grant out of band. Its schema is `phase2-namespace-init-grant-v1`.

1. `original_source_root`: the consumer-local absolute import root, currently reported as `/workspace/original132-phase2-import-20261006-ba1y1szn/extracted`; verify its actual files before using this value. The grant's `exact_original_source_pins` must contain all nine source-root-relative files in `ORIGINAL_SOURCE_PINS.json`, plus the tenth absolute source path under `implementation_root/pinned_originals/library_file_transfer.py`. Every exact digest is provided in that pin file. If any file is missing, stop and supply that exact pinned file through the authorized delivery route. Do not choose a replacement implementation or current newer helper.
2. `implementation_root`: parent selected `/workspace/original132-phase2-init-implementation-20261006/original132_phase2_namespace_init_20261006`; verify this is the consumer-local directory containing this INIT supplement. Pin all seven files listed by `implementation_files`. The bundled xattrs helper is an exact unmodified copy of the historical helper, SHA-256 `5c81478cd94a59d721a1677d0bd36f7cec23c18a21b48740b1c9ff94d27fb26f`.
3. `producer_workspace`: parent selected `/workspace/original132-phase2-producer-20261006`; it must NOT exist. The selected journal is `/workspace/original132-phase2-producer-20261006.namespace-init`. It cannot be the P0 or P1 producer, dispatch, or retained namespace. `journal_root` must equal its parent directory plus `<producer_workspace basename>.namespace-init`, and must also NOT exist. Parents of these two paths must already exist; no symlinks or `..`. Adapter paths deliberately use only `/A-Za-z0-9_.-` with no whitespace or quotes.
4. `forbidden_prior_library_file_ids`: fill exactly the four independently confirmed P0/P1 index/archive Library identities. These are forbidden; do not put proposed P2 IDs here. No fresh P2 ID may be guessed or pre-created.
5. Preserve scientific run `urp132_20261005_b01`, operational run `urp132_20261005_b01_phase2`, two create operations, zero model requests and candidates, and `generation_execution_granted=false`. Set `init_execution_granted=true` and `independent_review_accepted=true` only in the parent's once-authorized exact grant.
6. The 60 SELF-CPU seconds / 240 local-stage wall seconds are the SAME init+final pool later imported by GEN. They are not a new allowance. Keep the original observed thresholds 1860/61440, no hard-cap or complete-CPU-bound claim. Existing OpenCode 1.18.34 stays untouched; INIT never runs any CLI/model/candidate.

`SOURCE_PINS.json` provides supplement implementation pins. Recheck all original and implementation bytes on the consumer before signing the grant. Before the once-only INIT, run the read-only preparation check `python3 -I <implementation_root>/preflight_bundle_size.py <grant_path>` using the actual completed consumer-local grant. It creates no namespace and invokes no helper/Library/model. Require its exact stdout upper bound <=26,000 UTF-8 bytes; use `max_output_tokens=30000` for the builder. ASCII JSON byte length is a conservative token upper bound; the tool's possible independent platform hard cap is not claimed verified. All real path lengths and source texts are included, with an 8-digit archive byte-count ceiling. If the check fails, do not authorize/run INIT. After signing, do not edit any pin, path or code in place.

## Exact local and assistant-tool sequence

The only executable local INIT entrypoints are the fixed wrapper and final assembler. Both require the exact externally pinned grant. All commands are conceptual templates here; none was run against a real producer.

### 1. Measured fixed empty-artifact builder (one invocation)

Use `exec_command(login=false, max_output_tokens=30000)` once. Preserve the complete returned JSON stdout in assistant code-mode storage. Builder atomically saves identical bytes to `state/INIT_BRIDGE_BUNDLE.json` and its exact size/SHA to `state/INIT_BRIDGE_BUNDLE.sha256.json` before emitting stdout. A truncated tool display is not permission to rerun. Read only the existing helper receipt and retained bundle evidence; continue only if the original helper is confirmed, the full existing bundle and its SHA are verified, and no Library create was attempted. If the helper outcome itself is unknown, stop. Do not discard or fabricate the original tool response:

```text
python3 -I '<implementation_root>/init_local_helper.py' --grant '<grant_path>' --grant-sha256 '<grant_file_sha256>' --step build --script '<implementation_root>/empty_artifact_builder.py' -- '<grant_path>'
```

The wrapper first verifies all pins and the fresh path, exclusively creates its journal and first helper intent, and runs only the fixed builder. Builder creates the new producer, `state`, `dispatch-fences`, `retained`, `retained-library-replies`, `.library-helpers-current`, and `src`. The six original exporter files are copied byte-for-byte into `src`; no extra Python/JS source belongs there, so the original aggregate remains `bf12db4c3524087bd70bce7b6e76b8f7f85e07207d507d7d6a2408feb008b08c`. It copies the exact bound empty P2 index to `index.initial.json`, and calls only original `driver_v2.build_wave_archive(..., phase=2)` to make `archive.initial.zip` with zero slots. It never invokes `capture_once`, a producer dispatch, admission, or scoring. Do not rerun if exit/receipt is unknown.

### 2. Fixed assistant bridge, initial index first

The complete saved bundle, identical to builder stdout, also contains `grant_file_text`, `fixed_bridge_source` and exactly three `sources` strings (original commit, original retention, and the adapter), each checked against the exact grant pins inside the measured builder. This avoids a later unmeasured local `cat`/source-loader process. Preserve this stdout tool result; no source text may come from user prompts, callbacks, arbitrary files, or newer implementations.

The actual assistant entry is `init_bridge.js::initializeNamespace`. Parent must have pinned this entry's exact file SHA in the once-authorized grant. From the successfully measured builder's complete returned JSON, bind ONLY that verified `fixed_bridge_source` and invoke:

```javascript
const initializeNamespace = Function(builderResult.fixed_bridge_source + '\nreturn initializeNamespace;')();
const bothReceipts = await initializeNamespace(
  tools, // The original authenticated assistant tool object, never custom callbacks.
  builderResult.grant_file_text,
  '<parent-pinned INIT grant exact FILE SHA-256>',
  '<grant_path>',
  builderResult.sources
);
```

The fixed entry independently verifies SHA-256 of exact grant UTF-8 bytes and all source strings before evaluating any original JS. Original commit SHA is `a870f16d05b5db17a94be6544beb725d69fe6a429b41d3bb5ba7fe646811270d`; original retention SHA is `e44fec0c2059aa184825fd1d75c9eed851858c55230f22cb1650a7ab89ff0f6c`; the adapter's exact hash is in the parent grant. It then binds adapter BELOW unchanged retention BELOW unchanged commit, and runs only the fixed pair `index` then `archive`. There is no callback registry, input step list, arbitrary helper/command, caller-provided identity, alternative route, or retry.

Index call is exactly `commitV2(workspace, workspace+'/index.initial.json', null, -1, true)`, using retention operation `phase2-init-index` under `workspace/retained-library-replies`.

The fixed local order is `index.begin`, `index.retain-start`, `index.retain-response`, `index.xattrs`, `index.receipt`, `index.confirm`. Original retention persists the full returned tool object before checking it or applying xattrs. Initial create uses `libraryFileId=null` and `expectedVersion=-1`; a genuine v0 result is valid. Never perform an extra write merely to produce v1.

The original V2 index read must be real and complete. Its existing bounded fallback is unchanged: first `read`, at most one exact identity-scoped `search` refresh, then at most one further `read`. This is not a create retry. Receipt validation verifies canonical remote index bytes against the local blob. The original receipt nevertheless retains `remote_bytes_verified=false`, while `index_readback_confirmed=true`.

### 3. Initial archive create once through the same original sources

Only after the index commit returned confirmed and its durable helper receipt exists, the SAME fixed `initializeNamespace` invocation creates its archive adapter, uses retention `operationId='phase2-init-archive'`, and calls original `commitV2(workspace, workspace+'/archive.initial.zip', null, -1, false)` exactly once. Do not issue a separate manual archive call. Its six steps are `archive.begin`, `archive.retain-start`, `archive.retain-response`, `archive.xattrs`, `archive.receipt`, `archive.confirm`.

The archive acknowledgment/version/local SHA prove only write acknowledgment and locally retained bytes. There is no archive byte download or remote byte verification in INIT. Require `remote_bytes_verified=false` and `index_readback_confirmed=false`. Both new identities must differ from all four old identities and from each other. Do not overwrite or replace any Library identity in this INIT.

For each original helper call, the adapter changes ONLY the Python launch prefix. It preserves original command stdin/heredoc, argv, stdout/stderr, exec options and `-I` versus non-isolated launch mode. The wrapper runs the unchanged helper in its own process with original script search-path semantics. Each fixed helper gets one durable exclusive intent and receipt. No arbitrary commands, helper retries, supervisor, CPU hard limit, or active GEN sidecar are introduced.

### 4. Once-only measured final assembly

After both complete original commits, run exactly once:

```text
python3 -I '<implementation_root>/assemble_handoff.py' --grant '<grant_path>' --grant-sha256 '<grant_file_sha256>'
```

This checks all thirteen helper receipts, the two original retained create responses, the two original durable commit receipts, current local blob hashes, fresh identities, and cleared external pending fence. It creates its own exclusive intent and records a fourteenth SELF/monotonic measurement before publishing its receipt and `journal_root/INIT_RESOURCE_HANDOFF.json`. It performs no Library operation. Its stdout reports that handoff path and exact file SHA-256.

INIT grant and handoff hashes always mean exact file-byte SHA-256, including any trailing newline; they are NOT GEN's separate canonical-JSON grant digest. The actual handoff has 14 measurements and 16 exact receipt-file references: 13 helper receipts, two original durable Library commit receipts, and one assembly receipt. Every receipt-file entry is `{path,file_sha256}`. The disabled template carries no genuine ID or claimed outcome.

### 5. Parent review and later GEN grant

Read the resulting handoff and verify every referenced receipt file's exact SHA. Check the confirmed index/archive identities and original V2 receipts. Only then may the parent issue a separate actual GEN grant with:

```json
"namespace_initialization_handoff": {"path":"<actual handoff absolute path>","file_sha256":"<actual exact hash>"}
```

Use the exact same `producer_workspace`; set the GEN initial index-head and archive receipt to the full original durable receipt objects. The original generation gate and storage IDs stay disabled/unbound until these actual IDs are confirmed and explicitly bound. GEN `entry.initialize` must import all INIT measurements into its existing `init_final` pool along with its own initialization measurement. Finalization spends only what remains of the same 60/240 pool. INIT does not authorize generation.

## Stop / uncertainty / measurement meaning

Any attempted local helper, external create or final assembly is once-only. Existing intent without a confirmed receipt, unknown response/outcome, source drift, old/repeated identity, unresolved original fence, unknown measurement, or an exhausted observed pool blocks all subsequent work. Never delete a fence/intent, resubmit a create, or rerun the helper to recover. Parent must reconcile the already-attempted action under the original rules.

If Library throws, the original retention exception is durably saved. Successful local exception-retention preserves its original zero exit so original `retainLibraryReplies` rethrows the original Library error unchanged; its INIT measurement receipt is marked `outcome=unknown`, which blocks every later local action. If the original helper throws and checkpoint/receipt publication also fails, the original helper exception wins; the pending intent remains blocking.

Each dedicated local process records cumulative `RUSAGE_SELF` CPU from process birth and monotonic wall from the earliest Python launcher entry checkpoint. The pool aggregates per-process maxima, never sums repeated checkpoints of one process. The helper's Python startup CPU is observable in cumulative SELF; startup wall before the entry monotonic checkpoint is unknown. The final sample precedes receipt/handoff writes and exit, so those tails remain explicitly unknown. No fixed tail estimate is inserted. Every helper's synchronous local stage wall is inclusive, without wait subtraction; tool roundtrip, assistant scheduling and Library waits are not falsely counted as local stage wall.

CPU cap certification is `NOT_ESTABLISHED`. Complete process CPU upper bound is not claimed. Library wait, assistant bridge JS CPU, provider CPU and post-checkpoint tails remain `null`/unknown. Original 1860/61440 are observed checkpoint/stage-window admission thresholds, not proof of complete end-to-end CPU/wall caps. No historical budget reset occurs.

## Trusted tests only

`python3 test_trusted_fixtures.py` uses ephemeral fixture namespaces, synthetic Library responses, and the pinned original zero-model local helpers. It tests disabled and drift rejection, all 13 helper steps, v0 receipts, 14-measurement assembly, no replay, unknown intent blocking, shared pool exhaustion, and exception identity under measurement/publication failures. `node test_init_bridge.js` verifies the fixed source-hashed two-create entry, v0, disabled/hash-drift rejection, original exception identity, and no archive after index failure. `node test_init_exec_adapter.js` combines unchanged original commit/retention JS with fake tools; it never invokes a real Library tool. Test execution does not authorize real INIT.

## Review scope

The source-string snapshot fix is a static own-data-descriptor check and one frozen primitive-string snapshot, used unchanged by both SHA checks and all Function compilation. Final dynamic rechecks use the ordinary original trusted fixtures only. Independent adversarial getter/TOCTOU execution was not rerun. This package does not authorize any such test or real INIT.
