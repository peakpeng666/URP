#!/usr/bin/env python3
"""Summarize completed ledger records and verified archive receipts only."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path('/workspace/urp132-minimal-generation-r1')
REPORTS = ROOT / 'remaining59'
OLD = Path('/workspace/original132-phase2-producer-20261006')
BINARY = Path('/tmp/urp-opencode-check-i8yzygra/native/node_modules/opencode-linux-x64-baseline/bin/opencode')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def raw_json(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()


def main():
    frozen_raw = (ROOT / 'executor/frozen_inputs.json').read_bytes()
    frozen = json.loads(frozen_raw)
    status = json.loads((REPORTS / 'status.json').read_bytes())
    authorization = json.loads((REPORTS / 'COLLECTION_RECORD.json').read_bytes())
    first_reference = json.loads((ROOT / 'FIRST_SLOT_VERIFICATION.json').read_bytes())
    assert status['state'] == 'completed'
    assert status['new_terminal_positions'] == list(range(2, 61))
    assert status['remaining_unstarted'] == 0
    rows, measurements = [], []
    for position, item in enumerate(frozen['slots'], 1):
        folder = ROOT / 'ledger' / item['pack']['slot_id']
        result = json.loads((folder / 'result.json').read_bytes())
        dispatch = json.loads((folder / 'dispatch.json').read_bytes())
        answer = (folder / 'answer.txt').read_bytes()
        assert result['position'] == dispatch['position'] == position
        assert result['answer_sha256'] == sha(answer)
        assert result['answer_bytes'] == len(answer)
        assert item['pack']['prompt_sha256'] == sha((folder / 'prompt.txt').read_bytes())
        assert dispatch['configuration'] == frozen['freeze']['configuration']
        assert dispatch['binary_sha256'] == frozen['freeze']['cli_binary_sha256']
        assert dispatch['config_sha256'] == frozen['freeze']['config_file_sha256']
        assert not result['fixture_only'] and result['cli_process_started']
        row = {key: result.get(key) for key in ('position', 'slot_id', 'client_state',
              'exit_code', 'wall_seconds', 'answer_bytes', 'answer_sha256', 'finish_reasons',
              'capture_issues', 'cli_reported_tokens', 'cli_reported_usage_records')}
        row.update(order=item['record']['order'], arm=item['record']['arm'],
                   serialized_messages_sha256=item['record']['serialized_messages_sha256'],
                   prompt_sha256=item['pack']['prompt_sha256'])
        rows.append(row)
        if position > 1:
            measurements.append(json.loads((folder / 'resource_observation.json').read_bytes()))
    new = rows[1:]
    archive_batches = []
    for start in range(2, 61, 6):
        end = min(start + 5, 60)
        folder = REPORTS / 'archives' / f'positions_{start:02d}_{end:02d}'
        receipts = {}
        for kind, metadata_file in (('data', 'DATA_ARCHIVE.json'), ('audit', 'AUDIT_ARCHIVE.json')):
            meta = json.loads((folder / metadata_file).read_bytes())
            receipt = json.loads(Path(meta['path'].replace(f'_{kind}.zip', f'_{kind}_DRIVE_VERIFIED.json')).read_bytes())
            assert receipt['sha256'] == meta['sha256'] and receipt['bytes'] == meta['bytes']
            assert receipt['ZIP_CRC_pass'] and receipt['member_hashes_verified'] == meta['member_hashes_verified']
            assert receipt['parent_folder_ID'] == meta['parent_folder_id'] and receipt['ACL_changed'] is False
            receipts[kind] = receipt
        archive_batches.append({'positions': [start, end], **receipts})
    journal = OLD / 'phase2-generation-accounting'
    journal_map = {p.name: sha(p.read_bytes()) for p in sorted(journal.glob('*.json'))}
    journal_hash = sha(json.dumps(journal_map, sort_keys=True, separators=(',', ':')).encode())
    first = ROOT / 'ledger' / frozen['slots'][0]['pack']['slot_id']
    checks = {
        'runner_unchanged': sha((ROOT / 'executor/runner.py').read_bytes()) == authorization['approved_runner_SHA256'],
        'frozen_inputs_unchanged': sha(frozen_raw) == authorization['frozen_inputs_SHA256'],
        'frozen_configuration_unchanged': sha(frozen['config_raw'].encode()) == frozen['freeze']['config_file_sha256'],
        'official_CLI_binary_unchanged': sha(BINARY.read_bytes()) == frozen['freeze']['cli_binary_sha256'],
        'first_result_unchanged': sha((first / 'result.json').read_bytes()) == first_reference['result_file_SHA256'],
        'first_dispatch_unchanged': sha((first / 'dispatch.json').read_bytes()) == first_reference['dispatch_file_SHA256'],
        'old_journal_unchanged': journal_hash == authorization['old_journal_SHA256'],
        'old_claim_local_receipt_unchanged': sha((journal / 'entry-01-claimed-index.json').read_bytes()) == '8a3196e0569b9c5801fbfbd25ce6d4a6c3d74bcd271ad648bb9fdabc0c1a1c23',
        'old_dispatch_fence_empty': not any((OLD / 'dispatch-fences').iterdir()),
    }
    active = 0
    for path in Path('/proc').iterdir():
        if path.name.isdigit():
            try:
                active += (path / 'comm').read_text().strip() == 'opencode'
            except (FileNotFoundError, ProcessLookupError, PermissionError):
                pass
    assert all(checks.values())
    observed = {}
    for key in ('input', 'output', 'reasoning'):
        values = [row['cli_reported_tokens'].get(key) for row in new]
        numbers = [v for v in values if isinstance(v, (int, float))]
        observed[key] = {'sum_available_CLI_reports': sum(numbers),
                         'slots_with_available_reports': len(numbers),
                         'slots_with_unknown_reports': len(values) - len(numbers)}
    report = {
        'schema': 'urp132-minimal-r1-remaining59-final-report-v1',
        'checked_UTC': datetime.now(timezone.utc).isoformat(), 'state': status['state'],
        'unique_persistent_ledger': str(ROOT / 'ledger'), 'generation_revision': frozen['revision'],
        'new_positions': [2, 60], 'new_logical_CLI_launches': len(new), 'remaining_unstarted': 0,
        'first_slot_preserved_without_redispatch': checks['first_result_unchanged'] and checks['first_dispatch_unchanged'],
        'nonempty_public_answers': sum(row['answer_bytes'] > 0 for row in new),
        'empty_public_answer_positions': [row['position'] for row in new if row['answer_bytes'] == 0],
        'explicit_client_timeout_failure_positions': [row['position'] for row in new if row['client_state'] == 'timeout'],
        'length_finish_positions': [row['position'] for row in new if 'length' in row['finish_reasons']],
        'client_states': dict(Counter(row['client_state'] for row in new)),
        'slots': new, 'configuration': frozen['freeze']['configuration'],
        'official_CLI_version': frozen['freeze']['cli_version'], 'official_CLI_SHA256': frozen['freeze']['cli_binary_sha256'],
        'runner_SHA256': authorization['approved_runner_SHA256'], 'frozen_inputs_SHA256': sha(frozen_raw),
        'original_60_inputs_orders_arms_message_hashes_verified': True,
        'original_orders': [rows[0]['order'], rows[-1]['order']],
        'original_arms': dict(Counter(row['arm'] for row in rows)),
        'original_parent_draws': sum(len(item['record']['parents']) for item in frozen['slots']),
        'Coding_Plan_endpoint': 'https://open.bigmodel.cn/api/coding/paas/v4',
        'outer_retries_probes_replacement_samples': 0, 'paid_route_purchase_or_fallback_used': False,
        'CLI_reported_tokens_partial': observed,
        'provider_usage': None, 'provider_cost': None, 'physical_HTTP_attempts': None, 'provider_quota_remaining': None,
        'timeout_server_terminal_and_cancellation': 'unknown',
        'resource_caps': authorization['resource_caps'],
        'observed_new_slot_Python_SELF_seconds_sum': round(sum(m['Python_SELF_seconds'] for m in measurements), 6),
        'observed_new_slot_local_inclusive_wall_seconds_sum': round(sum(m['local_inclusive_wall_seconds'] for m in measurements), 6),
        'per_slot_observed_resource_cap_exceedances': [m['position'] for m in measurements
            if m['Python_SELF_seconds'] > authorization['resource_caps']['slot_SELF_seconds']
            or m['local_inclusive_wall_seconds'] > authorization['resource_caps']['slot_inclusive_wall_seconds']],
        'full_historical_resource_balance': None, 'whole_CPU_cap_certified': False,
        'first_minimal_Python_SELF_and_original_controller_final_SELF': None,
        'native_CLI_CPU_and_provider_CPU_not_in_Python_SELF_sum': True,
        'old_preservation_checks': checks, 'old_journal_file_map_SHA256': journal_hash,
        'old_journal_json_files': len(journal_map), 'old_events': len(list(journal.glob('event-*.json'))),
        'old_HALT_preserved_from_unchanged_journal': first_reference['old_HALT'],
        'old_collect_outcome_preserved': first_reference['old_collect_outcome'],
        'old_Library_claim_local_version_preserved': '2', 'Library_writes_performed': 0,
        'old_72_results_failures_and_historical_costs_written_or_reset': False,
        'active_OpenCode_processes': active,
        'continuation_exec_session': 76713, 'continuation_exec_exit_status': 0,
        'original_exec_transport_lost_but_persisted_prefix_reconciled': True,
        'original_controller_exit_status_and_final_SELF': None,
        'scientific_admission_numerical_scoring_heldout_performed': False,
        'credential_values_read_saved_or_hashed': False, 'runtime_HOME_XDG_auth_cache_logs_archived': False,
        'old_rejected_evidence_ZIP_retry_or_reroute_performed': False,
        'Drive_permission_changes_performed': False, 'archive_batches': archive_batches,
    }
    final = REPORTS / 'FINAL_COLLECTION_REPORT.json'
    with final.open('xb') as out:
        out.write(raw_json(report))
    spec = importlib.util.spec_from_file_location('safe_archiver', ROOT / 'archive_batch.py')
    archiver = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(archiver)
    members = {'FINAL_COLLECTION_REPORT.json': raw_json(report),
               'STATUS_SNAPSHOT.json': (REPORTS / 'status.json').read_bytes(),
               'COLLECTION_RECORD.json': (REPORTS / 'COLLECTION_RECORD.json').read_bytes(),
               'TRANSPORT_RECOVERY_CONTINUATION.json': (REPORTS / 'TRANSPORT_RECOVERY_CONTINUATION.json').read_bytes(),
               'REPORT_BUILDER.py': Path(__file__).read_bytes()}
    meta = archiver.write_zip(REPORTS / 'urp132_P2_minimal_r1_remaining59_final_index_audit.zip', members)
    meta['parent_folder_id'] = authorization['audit_folder_ID']
    with (REPORTS / 'FINAL_INDEX_ARCHIVE.json').open('xb') as out:
        out.write(raw_json(meta))
    print(json.dumps({'archive': meta, 'nonempty_public_answers': report['nonempty_public_answers'],
          'timeouts': report['explicit_client_timeout_failure_positions'], 'length_finishes': report['length_finish_positions'],
          'old_preservation_checks': checks, 'active_OpenCode_processes': active}))


if __name__ == '__main__':
    main()
