"""Stdlib-only fresh-head validation and minimal disabled candidate revision."""
import time
ENTRY=time.monotonic()
import json, hashlib, copy, re, resource, datetime, zipfile
from pathlib import Path
D=Path(__file__).resolve().parent
OLD=Path('/workspace/original132-phase2-gen-disabled-bindings-20261006-66g8t9xp')
W=Path('/workspace/original132-phase2-producer-20261006');J=Path(str(W)+'.namespace-init');K=Path(str(W)+'.namespace-recovery')
X=Path('/workspace/original132-phase2-import-20261006-ba1y1szn/extracted')
sha=lambda b:hashlib.sha256(b).hexdigest()
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf-8')
def read(p):return json.loads(Path(p).read_bytes())
def fh(p):return sha(Path(p).read_bytes())
def ref(p):return {'path':str(p),'file_sha256':fh(p)}
def need(v,s):
    if not v:raise RuntimeError(s)
def put(name,v):
    p=D/name;b=v if isinstance(v,bytes) else canon(v)
    with p.open('xb') as f:f.write(b)
    return ref(p)
g0=read(OLD/'GEN_GRANT.CANDIDATE.json');b0=read(OLD/'BRIDGE_GATE.CANDIDATE.json')
need(fh(OLD/'GEN_GRANT.CANDIDATE.json')=='fbc45c7828a74e5e4640148c5f6c0b690cfc0f0755d91bafad5ea3a0e79903ee' and fh(OLD/'BRIDGE_GATE.CANDIDATE.json')=='d1ed011a6accca47acf2984c4970fabf600799ebd2dd94ddc383b05cc1c2fd63','prior candidates changed')
raw=read(D/'evidence/AUTHENTICATED_P1_READ.raw.json');call=read(D/'evidence/AUTHENTICATED_P1_READ.call.json')
plan=read(OLD/'evidence/PLAN.original.json');expect=plan['predecessor'];frozen=read(OLD/'evidence/FREEZE.original.json')
P1freeze_path=X/'original132_phase1_preparation_20261005/inputs/freeze.json';P1freeze=read(P1freeze_path)
need(P1freeze['sha256']==expect['freeze_sha256'] and P1freeze['configuration']==frozen['configuration'],'original P1/P2 config binding')
need(raw.get('isError') is False and len(raw['structuredContent']['results'])==2,'complete real successful fresh read required')
rows=[];decoded=[];checks=[]
for item,requested in zip(raw['structuredContent']['results'],(expect['library_file_id'],expect['file_id'])):
    content='\n'.join(item['content']).encode('utf-8');index=json.loads(content)
    need(item['ref_id']==requested and item['library_file_id']==expect['library_file_id'] and item['file_id']==expect['file_id'] and item['version_id']=='120' and item['size_bytes']==len(content)==96872 and item['has_more'] is False and not item.get('warnings'),'fresh explicit identity/version/completeness')
    need(sha(content)==expect['index_blob_sha256'] and index['sha256']==sha(canon({k:v for k,v in index.items() if k!='sha256'})),'complete expected original P1 index bytes/seal')
    need(index['run_id']=='urp132_20261005_b01_phase1' and index['freeze_sha256']==expect['freeze_sha256'] and index['mode']=='official_cli','original P1 run/freeze route')
    need(len(index['rows'])==60 and all(r['state']=='terminal' and r['phase']==1 and r['claim']['run_id']==index['run_id'] and r['claim']['freeze_sha256']==P1freeze['sha256'] and r['reservation']['config_file_sha256']==r['terminal']['config_file_sha256']==P1freeze['config_file_sha256'] for r in index['rows']),'original60 terminal rows and frozen configuration')
    decoded.append(index)
    rows.append({'requested_ref_id':requested,'library_file_id':item['library_file_id'],'file_id':item['file_id'],'observed_version_id':item['version_id'],'observed_version_number':120,'version_basis':'explicit version_id=120 in fresh authenticated tool result','content_bytes':len(content),'content_sha256':sha(content),'created_at':item.get('created_at'),'modified_at':item.get('modified_at'),'all60_rows_terminal':True,'claimed_or_other_state_rows':0,'all_rows_config_sha256':P1freeze['config_file_sha256']})
need(decoded[0]==decoded[1],'fresh head/backing conflict')
accept=read(OLD/'evidence/P1_ACCEPTANCE.original.json');snaps=read(OLD/'PARENT_SNAPSHOTS.FROZEN.json')['snapshots']
need(accept['authenticated_index_identity']=={'file_id':expect['file_id'],'library_file_id':expect['library_file_id'],'sha256':expect['index_blob_sha256'],'version':120},'accepted original P1 index linkage')
need({s['arm']:s['sha256'] for s in snaps}==accept['P1_snapshot_sha256'],'original terminal snapshot linkage')
gate_source=X/'original132_phase2_continuation_draft_20261006/phase2_producer_bridge.py'
need(fh(gate_source)==g0['operational_source_files'][str(gate_source)],'accepted gate source drift')
source=gate_source.read_text()
need("gate.get('original_head_current_confirmed') is True" in source and "gate.get('original_index_blob_sha256')==plan['predecessor']['index_blob_sha256']" in source,'field semantics differ; stop without guessing')
evidence={'schema':'fresh-authenticated-original-P1-head-v1','observed_UTC_interval':{'before':call['clock_before']['current_time'],'after':call['clock_after']['current_time']},'actual_tool_name':call['raw_tool_name'],'actual_tool_calls':1,'requested_read_targets':2,'authentication_basis':'actual Library tool result, no copied historical file used as fresh observation','raw_result_ref':ref(D/'evidence/AUTHENTICATED_P1_READ.raw.json'),'call_and_actual_clock_returns_ref':ref(D/'evidence/AUTHENTICATED_P1_READ.call.json'),'raw_serialization':'faithful canonical JSON of complete tool result object; not claimed original HTTP wire bytes','expected_original_P1_head':expect,'fresh_reads':rows,'current_original_head_matches_expected':True,'original_head_current_confirmed':True,'gate_field_semantics':{'source_ref':ref(gate_source),'meaning':'Original P1 current Library index head, because the unchanged gate pairs this fact with plan.predecessor.index_blob_sha256; it is not the new P2 index','enable_or_GEN_authority':False},'comparison':{'exact_96872_bytes_SHA':True,'explicit_current_version120':True,'current_head_and_backing_equal':True,'original_P1_run_and_freeze':True,'all60_terminal_no_claimed_head_rows':True,'same_original_config_sha256':P1freeze['config_file_sha256'],'accepted_P1_snapshot_linkage':{s['arm']:s['sha256'] for s in snaps},'snapshot_linkage_basis':'unchanged independently accepted P1 index + accepted terminal snapshot metadata; no numerical replay','no_new_version_or_changed_head_bytes_observed':True},'coverage_limits':{'point_in_time_reads_only':True,'P1_archive_fresh_read':False,'fresh_producer_status_script_executed':False,'historical_local_fence_used_as_fresh_status':False,'uncommitted_or_concurrent_P1_operations':None,'global_OS_or_third_party_state':None,'future_head_changes_after_observation':None,'heldout_reads':0},'P1_and_Library_mutations_by_this_task':0,'GEN_calls':0,'model_calls':0,'numeric_calls':0,'recovery_calls':0}
fresh_ref=put('FRESH_P1_HEAD_EVIDENCE.json',evidence)
parent=copy.deepcopy(read(OLD/'PARENT_BINDINGS.CANDIDATE.json'));parent.update(fresh_P1_head_current_confirmed_this_round=True,fresh_P1_authenticated_read_this_round=1,fresh_P1_authenticated_read_targets=2,fresh_P1_head_evidence_ref=fresh_ref)
parent_ref=put('PARENT_BINDINGS.CANDIDATE.json',parent)
ctx0=read(OLD/'LIBRARY_CONTEXTS.CANDIDATE.json');ctx=copy.deepcopy(ctx0);mapping=[]
retention=X/'original132_phase1_preparation_20261005/retention/retain_library_replies.js'
need(fh(retention)==g0['operational_source_files'][str(retention)],'retention source changed')
need('^[A-Za-z0-9_.-]{1,96}$' in retention.read_text(),'reviewed operation ID regex changed')
for row in ctx['contexts']:
    c=row['context'];old_id=c['operationId'];new_id='p2_%02d_%s'%(row['position'],c['stage'])
    need(re.fullmatch(r'[A-Za-z0-9_.-]{1,96}',new_id),'illegal operation ID')
    c['operationId']=new_id;mapping.append({'position':row['position'],'slot_id':c['slotId'],'stage':c['stage'],'request_sha256':c['request_sha256'],'old_operation_id':old_id,'restored_operation_id':new_id})
need(len(mapping)==len({r['restored_operation_id'] for r in mapping})==180,'180 one-to-one safe IDs')
for a,b in zip(ctx0['contexts'],ctx['contexts']):
    need(a['position']==b['position'] and {k:v for k,v in a['context'].items() if k!='operationId'}=={k:v for k,v in b['context'].items() if k!='operationId'},'slot/request/stage semantics changed')
ctx_ref=put('LIBRARY_CONTEXTS.CANDIDATE.json',ctx)
put('OPERATION_ID_MAPPING_DIFF.json',{'basis':'Parent independent reviewer supplied existing legal unique p2_01_claim_commit etc mapping; exact p2_<position:02d>_<stage> restored','retention_source_ref':ref(retention),'unchanged_retention_regex':'^[A-Za-z0-9_.-]{1,96}$','count':180,'only_context_field_changed':'operationId','mapping':mapping})
gate=copy.deepcopy(b0);gate.update(original_head_current_confirmed=True,parent_evidence_binding_ref=parent_ref,fresh_P1_head_evidence_ref=fresh_ref)
gate_ref=put('BRIDGE_GATE.CANDIDATE.json',gate)
grant=copy.deepcopy(g0);grant.update(bridge_gate_path=gate_ref['path'],bridge_gate_file_sha256=gate_ref['file_sha256'],parent_evidence_binding_ref=parent_ref,fresh_P1_head_evidence_ref=fresh_ref)
grant['preparation_execution_counts']['Library_calls']=1
grant_ref=put('GEN_GRANT.CANDIDATE.json',grant)
comp0=read(OLD/'GEN_COMPOSITION.CANDIDATE.json');comp=copy.deepcopy(comp0);comp['GEN_grant_ref']=grant_ref;comp['context_ref']=ctx_ref;comp['paths']['grantPath']=grant_ref['path'];comp_ref=put('GEN_COMPOSITION.CANDIDATE.json',comp)
need(all(grant[k] is False for k in ('generation_execution_granted','implementation_review_accepted','numeric_execution_granted')) and all(gate[k] is False for k in ('enabled','parent_review_accepted','generation_execution_granted','numeric_execution_granted')),'enable field changed')
need(grant['operational_source_files']==g0['operational_source_files'] and len(grant['operational_source_files'])==35 and all(fh(p)==h for p,h in grant['operational_source_files'].items()),'accepted sources changed')
need(sha(canon(grant['operational_source_files']))==ctx['source_sha256']=='57e9937bd8693fb7fc6cc58c4ab52bacdc57d73887e92d619239f82865a76a73' and all(c['context']['source_sha256']==ctx['source_sha256'] for c in ctx['contexts']),'source digest downgrade')
need(grant['namespace_initialization_handoff']==g0['namespace_initialization_handoff'] and grant['local_call_targets']==g0['local_call_targets'] and grant['authorized_slot_order']==g0['authorized_slot_order'] and grant['authorized_request_sha256']==g0['authorized_request_sha256'] and grant['init_resource_import']==g0['init_resource_import'],'accepted scope changed')
def diff(old,new):return [{'field':k,'before':old.get(k),'after':new.get(k)} for k in sorted(set(old)|set(new)) if old.get(k)!=new.get(k)]
put('BINDING_DIFF.json',{'previous_bundle':{'Drive_file_id':'1aDca9peaqCwAEriFCN2KUPjXEIkZHLzM','file_sha256':'91f725388763feaf44734a77c7f518847866bd2f40c33862cf189c2397865163'},'previous_GEN_ref':ref(OLD/'GEN_GRANT.CANDIDATE.json'),'previous_gate_ref':ref(OLD/'BRIDGE_GATE.CANDIDATE.json'),'GEN_changes':diff(g0,grant),'gate_changes':diff(b0,gate),'composition_changes':diff(comp0,comp),'context_changes_ref':ref(D/'OPERATION_ID_MAPPING_DIFF.json'),'candidate_refs':{'GEN':grant_ref,'gate':gate_ref,'contexts':ctx_ref,'composition':comp_ref},'all_source_bytes_and_full35_digest_unchanged':True,'accepted_v2_and46_measurements_unchanged':True,'new_framework_or_source_modifications':0})
for name in ('GEN_GRANT.CANDIDATE.json','BRIDGE_GATE.CANDIDATE.json','LIBRARY_CONTEXTS.CANDIDATE.json','GEN_COMPOSITION.CANDIDATE.json'):
    put('evidence/PREVIOUS_'+name,(OLD/name).read_bytes())
put('evidence/P1_FREEZE.original.json',P1freeze_path.read_bytes())
put('evidence/P1_ACCEPTANCE.original.json',(OLD/'evidence/P1_ACCEPTANCE.original.json').read_bytes())
put('SOURCE_PINS.UNCHANGED.json',{'operational_source_files':grant['operational_source_files'],'count':35,'source_digest':ctx['source_sha256'],'unique_v2_ref':grant['namespace_initialization_handoff'],'prior_complete35_source_bundle':'https://drive.google.com/file/d/1aDca9peaqCwAEriFCN2KUPjXEIkZHLzM/view'})
after={str(p):{'bytes':p.stat().st_size,'sha256':fh(p)} for root in (W,J,K) for p in sorted(root.rglob('*')) if p.is_file()}
need(after==read(D/'audit/INIT_PRODUCTION_BEFORE.json'),'INIT production modified')
put('audit/INIT_PRODUCTION_AFTER.json',after)
need(fh(OLD/'GEN_GRANT.CANDIDATE.json')=='fbc45c7828a74e5e4640148c5f6c0b690cfc0f0755d91bafad5ea3a0e79903ee' and fh(OLD/'BRIDGE_GATE.CANDIDATE.json')=='d1ed011a6accca47acf2984c4970fabf600799ebd2dd94ddc383b05cc1c2fd63','old candidates overwritten')
report={'status':'FRESH_P1_CONFIRMED_LEGAL_OPERATION_IDS_RESTORED_DISABLED','candidate_root':str(D),'fresh_evidence_ref':fresh_ref,'GEN_candidate_ref':grant_ref,'gate_candidate_ref':gate_ref,'contexts_ref':ctx_ref,'composition_ref':comp_ref,'requests':60,'parent_tickets':78,'contexts':180,'source_count':35,'source_digest':ctx['source_sha256'],'INIT_measurements':46,'INIT_v2_unchanged':True,'INIT_production_unchanged':True,'previous_candidates_unchanged':True,'GEN_calls':0,'model_calls':0,'numeric_calls':0,'recovery_calls':0,'Library_read_calls':1,'Library_targets':2,'Library_writes':0,'repository_modules_executed':0,'heldout_reads':0,'remaining_blockers':['Parent independent reviewer must accept these exact revised files and source/context bindings before a separately issued enabled GEN grant.'],'SELF_CPU_checkpoint_seconds':resource.getrusage(resource.RUSAGE_SELF).ru_utime+resource.getrusage(resource.RUSAGE_SELF).ru_stime,'local_wall_checkpoint_seconds':time.monotonic()-ENTRY,'JS_Library_and_post_checkpoint_CPU_wall':None,'complete_CPU_upper_bound_claimed':False}
put('REVISION_REPORT.json',report)
put('README.md',('仅补 fresh P1 current head 证据和恢复既有合法180 operationId。原disabled候选字节保留，所有GEN启用字段仍false。\n认证读取于16:21:23–16:21:24 UTC，head/backing均明确version_id=120，96872B与原冻结SHA完全相同，60行terminal，无claimed head。原gate字段指P1 index；snapshot由原独审终态元数据连结，不重新数值回放。\n未承诺读窗之外、尚未提交的操作或全局OS状态；旧本地fence不伪称fresh。\n180 operationId仅由slot:stage恢复为已审p2_01_claim_commit等位置/动作一一映射，source35 digest和slot/request/stage不变，retention源码不改。\n上一完整源码/冻结包Drive 1aDca9peaqCwAEriFCN2KUPjXEIkZHLzM / SHA91f725388763feaf44734a77c7f518847866bd2f40c33862cf189c2397865163保持。\n本修订仍须独审与父另行精确启用批准；未执行GEN/模型/数值/恢复。\n').encode('utf-8'))
include=[p for p in D.rglob('*') if p.is_file() and p.suffix!='.jsonpart']
members={p.relative_to(D).as_posix():{'bytes':p.stat().st_size,'sha256':fh(p)} for p in sorted(include)}
put('FILE_MANIFEST.json',{'files':members,'full_authenticated_raw_result_preserved':True,'original_result_reassembly_chunks_retained_locally_not_duplicated_in_minimal_zip':True})
zip_path=D/'原132_GEN_禁用修订_freshP1_合法180ID_20261006.zip'
with zipfile.ZipFile(zip_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name in sorted([*members,'FILE_MANIFEST.json']):z.write(D/name,name)
with zipfile.ZipFile(zip_path) as z:
    m=json.loads(z.read('FILE_MANIFEST.json'))['files'];need(z.testzip() is None and set(z.namelist())==set(m)|{'FILE_MANIFEST.json'} and all(len(z.read(n))==v['bytes'] and sha(z.read(n))==v['sha256'] for n,v in m.items()),'revision ZIP verification')
proof={'zip_path':str(zip_path),'bytes':zip_path.stat().st_size,'sha256':fh(zip_path),'members':len(m)+1,'manifest_refs':len(m),'all_verified':True,'fresh_evidence_ref':fresh_ref,'GEN_candidate_ref':grant_ref,'gate_candidate_ref':gate_ref,'contexts_ref':ctx_ref}
put('LOCAL_BUNDLE_VERIFICATION.json',proof)
print(json.dumps(proof,ensure_ascii=False))
