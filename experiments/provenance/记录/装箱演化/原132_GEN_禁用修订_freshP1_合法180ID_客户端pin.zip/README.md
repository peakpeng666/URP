仅补 fresh P1 current head 证据和恢复既有合法180 operationId。原disabled候选字节保留，所有GEN启用字段仍false。
认证读取于16:21:23–16:21:24 UTC，head/backing均明确version_id=120，96872B与原冻结SHA完全相同，60行terminal，无claimed head。原gate字段指P1 index；snapshot由原独审终态元数据连结，不重新数值回放。
未承诺读窗之外、尚未提交的操作或全局OS状态；旧本地fence不伪称fresh。
180 operationId仅由slot:stage恢复为已审p2_01_claim_commit等位置/动作一一映射，source35 digest和slot/request/stage不变，retention源码不改。
上一完整源码/冻结包Drive 1aDca9peaqCwAEriFCN2KUPjXEIkZHLzM / SHA91f725388763feaf44734a77c7f518847866bd2f40c33862cf189c2397865163保持。
本修订仍须独审与父另行精确启用批准；未执行GEN/模型/数值/恢复。
