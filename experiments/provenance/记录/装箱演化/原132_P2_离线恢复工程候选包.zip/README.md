# 原132 P2停点：离线恢复工程候选包

2026-10-06。已完成新目录内的实现与普通可信 fixture 验证，真实恢复未执行。开发 grant 的 `execution_granted`、`independent_review_accepted`、GEN/numeric 权限全部为 false。包不是 INIT 完成凭证，也不是恢复激活文件。

## 实际状态与证据

原生产 namespace 仍为 `original132-phase2-producer-20261006`，已确认 helper 00–04 共5条；pending 原字节保留。index 的 Library/backing identity、v0历史create、859 B冻结内容未改。原archive create、commit、assembler、handoff、恢复journal、GEN和bridge journal均未执行或创建。`audit/PRODUCTION_UNCHANGED.json` 记录45个文件前后 SHA 完全一致，并复核旧grant、停止ZIP、bridge错误、历史create、pending和源pin。

14项 Python 测试通过（包括多个子场景），20个 JavaScript 可信fixture场景通过。原始运行日志在 `audit/tests.python.log`、`audit/tests.javascript.log`，实际命令和日志SHA在 `audit/TEST_RESULTS.json`。未执行被平台停止的 getter/TOCTOU 对抗复现。没有真实 Library、OpenCode、模型或GEN调用，没有科研数值计算、Git推送、服务发布、权限/网络策略更改。

## 新代码及固定后缀

- `src/suffix_bridge.js`：只接原index的两次新read，首次payload和原05/06，然后调用精确原adapter/retention/commit源码的archive后缀，最后原assembler和独立v2封存。没有原index create/replace或00–04入口，也不调用旧initializeNamespace。
- `src/recovery_core.py`、`src/recovery_cli.py`：精确grant/源pin/历史stop绑定，固定namespace、14个后缀阶段、独占intent和不可重放journal。每次动作前重新核验绑定；本地控制进程每次动作前后检查相同60 SELF/240 local-wall池，缺失或unknown receipt阻断后继。payload由新计量CLI首次发布，commit/fence变化只留给原confirm。
- `src/reconciled_handoff.py`：保留原真实14 measurements/16 receipts的v1作为base，新v2显式包含全部恢复增量和自己的构建checkpoint，合计14+k。
- `src/gen_importer_v2.py`、`src/production_generation_entry_v2.py`：显式v1/v2兼容，精确验证base+delta、身份、版本、源及完成seal，返回全部measurement。新入口只替换bootstrap导入及依赖预核验；科学选择、60个P2位置、原候选和heldout代码不改。兼容草案见 `GEN_IMPORT_COMPATIBILITY.DRAFT.json`，GEN继续禁用。

`RECOVERY_GRANT.DEVELOPMENT.json` 绑定六个新源码的精确pin、旧所有源码、原5条intent/receipt及所有停点证据；future recovery root只作为绑定字符串出现，本轮并未创建。`references/` 是原源码逐字节副本；`audit/GEN_ENTRY_CHANGE.diff` 给出新GEN入口的窄变更。旧文件和旧grant完全不改。

## 验证范围与计量限制

Python fixture只在本开发目录下的独立临时namespace运行新控制代码，复制旧5条原始证据，使用明确TEST_ONLY的合成剩余helper、assembler和工具结果。新增payload使用实际新代码。JavaScript fixture运行固定后缀及精确原JS源组合，但所有工具返回均由可信合成对象提供，不启动原helper/assembler进程或连接真实Library。新GEN入口测试只调用bootstrap；无initialization、producer加载或GEN派发。

覆盖固定14阶段前后中断、confirm写commit/清pending之间、archive抛错、assembler intent/receipt/handoff停点、二次进入拒绝、源/旧证据/pending/identity漂移、坏read、缺receipt、接近池阈值、稳定process CPU high-water、重叠wall拒绝、严格v1与v2分支、完整14+k恰好一次导入。测试预算样本是合成值，不能当成实际恢复耗时或硬CPU上界。

历史checkpoint后CPU/wall、Python启动前wall、JS/Library/provider成本和原失败read完整raw继续unknown。新receipt/封存checkpoint后的成本也明确unknown。`CPU_cap_certification=NOT_ESTABLISHED`、`complete_CPU_upper_bound_claimed=false`。本次工程开发和审阅成本未做完整计量，不能报0，也不塞进原helper账本。archive仍保持 `remote_bytes_verified=false`。

工具throw会保留未解决的stage intent并阻断后继；普通fixture验证了不再create或执行下一个helper。实际工具异常对象和平台工具绑定语义须在独立工程审阅时检查，不能凭合成fixture宣称真实平台已端到端验收。

## 下一步（工程门控，非要求用户重新授权科研）

先由独立工程审阅接受新源码、单次journal、共享池、真实工具异常边界和v2导入契约。若通过，形成另外的精确pin激活文件；绝不改旧grant或仅把本开发grant的false改true。原producer再次只读核验实际停点，并在新计量入口中获取本次真实read，两者都不是原失败read记录的补写。然后首次执行原05/06、最多一次原archive后缀、原assembler，生成实际base+delta v2；任何未知/失败保持停住，不自动重放。

实际恢复结果须另行终审，之后才能精确更新GEN工程激活文件和operational source map；需包含新的入口、六个新源码和入口实际使用的原GEN副本依赖，绑定实际v2 SHA、两条实际namespace receipts和未增发的原init_final池。当前archive/handoff未知，所以兼容草案相关字段为null。已确认index或offline PASS均不自动启用GEN。

## 本地重现

只运行本包新测试，文件写入在开发目录fixture下：

```sh
python3 -I -B tests/test_recovery.py
node tests/test_bridge.js
```

本开发grant绝对路径绑定当前workspace，包移动后必须形成新的独立审阅绑定，不能编辑路径并沿用旧SHA。不要运行production入口、原INIT脚本或把真实工具对象传入bridge。本轮不提供自动激活或真实恢复命令。

交付ZIP的 `FILE_MANIFEST.json` 列出成员大小与SHA；原诊断报告、两条独立read raw和旧停止ZIP作为历史证据一起保全，其来源与本轮fixture清楚分离。
