import sys, unittest, copy, subprocess
from types import SimpleNamespace
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from fixture_support import *
class RecoveryTests(unittest.TestCase):
    def test_success_suffix_and_explicit_v2_import_once(self):
        f=Fixture();h=f.run()
        self.assertEqual(len(h["measurements"]),14+h["recovery_measurement_count"])
        self.assertGreater(h["recovery_measurement_count"],0)
        self.assertEqual((f.index_creates,f.archive_creates),(0,1));self.assertEqual(len(f.helpers),8)
        self.assertFalse((f.w/"state/external-pending.json").exists())
        base=read(f.j/"INIT_RESOURCE_HANDOFF.json")
        self.assertEqual((len(base["measurements"]),len(base["receipt_files"])),(14,16))
        im=f.root/"import";im.mkdir();refh=ref(f.r/"RECONCILED_HANDOFF.v2.json")
        imported=ImportOnce(im).import_handoff(refh,f.g);self.assertEqual(imported,h["measurements"])
        with self.assertRaises(FileExistsError):ImportOnce(im).import_handoff(refh,f.g)
        with self.assertRaises(Stop):f.enter()
    def test_disabled_public_grant_never_touches_production(self):
        g=read(ROOT/"RECOVERY_GRANT.DEVELOPMENT.json")
        with self.assertRaisesRegex(Stop,"disabled"):Ledger(g,{"path":"unused","file_sha256":"unused"})
    def test_pin_pending_and_identity_drift_before_effect(self):
        for field in ("pending","identity","version","index_hash","source","old_receipt","old_intent"):
            with self.subTest(field=field):
                f=Fixture()
                if field=="pending":(f.w/"state/external-pending.json").write_text("{}")
                elif field=="identity":f.g["index"]["library_file_id"]="libfile_wrong"
                elif field=="version":f.g["index"]["version"]=1
                elif field=="index_hash":f.g["index"]["sha256"]="f"*64
                elif field=="source":f.g["new_source_pins"][str(ROOT/"src/recovery_core.py")]="f"*64
                elif field=="old_receipt":(f.j/"helper-03.receipt.json").write_text("{}")
                else:(f.j/"helper-03.intent.json").write_text("{}")
                with self.assertRaises((Stop,KeyError)):f.enter()
                self.assertEqual(f.archive_creates,0)
    def test_every_stage_interruption_never_replays(self):
        for stage in STAGES:
            for point in ("before","after"):
                with self.subTest(stage=stage,point=point):
                    f=Fixture()
                    with self.assertRaises(Stop):f.run((stage,point))
                    calls=f.archive_creates;helpers=list(f.helpers)
                    with self.assertRaises(Stop):f.enter()
                    self.assertEqual(f.archive_creates,calls);self.assertEqual(f.helpers,helpers)
    def test_bad_read_does_not_create_index_or_clear_pending(self):
        for field in ("file_id","library_file_id","has_more","content"):
            with self.subTest(field=field):
                f=Fixture();f.enter();f.invoke_meter(f.ledger.before,"read.backing")
                raw=f.readraw();row=raw["structuredContent"]["results"][0]
                row[field]=["bad"] if field=="content" else (True if field=="has_more" else "wrong")
                with self.assertRaises(Stop):f.invoke_meter(f.ledger.after,"read.backing",raw)
                self.assertTrue((f.w/"state/external-pending.json").exists())
                self.assertEqual(f.index_creates,0)
    def test_unknown_original_helper_and_missing_delta_stop(self):
        f=Fixture();f.enter();(f.r/"delta-0000.receipt.json").unlink()
        with self.assertRaises(Stop):f.invoke_meter(f.ledger.before,"read.backing")
        f=Fixture();(f.j/"helper-04.receipt.json").unlink()
        with self.assertRaises(Stop):f.enter()
    def test_shared_pool_counts_old_and_delta_before_next_effect(self):
        f=Fixture();f.enter()
        with self.assertRaises(Stop):f.invoke_meter(f.ledger.before,"read.backing",cpu=59.9)
        self.assertFalse((f.r/"effect-00.intent.json").exists())
        f=Fixture();f.enter()
        with self.assertRaises(Stop):f.invoke_meter(f.ledger.before,"read.backing",wall=240)
        self.assertFalse((f.r/"effect-00.intent.json").exists())
    def test_cpu_highwater_and_no_nested_wall(self):
        c=Clock();a=c.command(.1,.1);b=c.command(.2,.1)
        b["process"]=a["process"];b["start"]["process"]=b["end"]["process"]=a["process"]
        self.assertAlmostEqual(totals([a,b])[0],.2)
        b["start"]["monotonic"]=a["start"]["monotonic"];b["end"]["monotonic"]=a["end"]["monotonic"]
        with self.assertRaises(Stop):totals([a,b])
    def test_v1_not_silent_v2_and_receipt_or_measurement_drift(self):
        f=Fixture();h=f.run();base=ref(f.j/"INIT_RESOURCE_HANDOFF.json")
        self.assertEqual(len(load_handoff(base,f.g)[0]),14)
        for field in ("schema","receipt","measurement","namespace","source"):
            with self.subTest(field=field):
                v=copy.deepcopy(h)
                if field=="schema":v["schema"]=V1
                elif field=="receipt":v["recovery_receipt_files"]=v["recovery_receipt_files"][:-1]
                elif field=="measurement":v["measurements"]=v["measurements"][:-1]
                elif field=="namespace":v["producer_workspace"]="/wrong"
                else:v["new_source_pins"]={}
                p=f.root/(field+".json");publish(p,v)
                with self.assertRaises((Stop,KeyError)):load_handoff(ref(p),f.g)
    def test_new_unknown_tail_not_filled_with_zero(self):
        f=Fixture();h=f.run();self.assertEqual(h["unknown"],UNKNOWN)
        self.assertEqual(h["CPU_cap_certification"],"NOT_ESTABLISHED")
    def test_live_tools_rejected(self):
        f=Fixture()
        for name in ("Library.create","Library.replace","OpenCode","model","GEN"):
            with self.subTest(name=name):
                with self.assertRaises(Stop):f.real_tool(name)
    def test_internal_confirm_archive_and_assembly_interruptions(self):
        points=[k+"."+p for k in ("index.confirm","archive.confirm") for p in ("after_commit","after_clear")]
        points+=["archive.create.throw"]+["base.assemble."+p for p in ("after_intent","after_receipt","after_handoff")]
        for point in points:
            with self.subTest(point=point):
                f=Fixture();f.crash_internal=point
                with self.assertRaises(Stop):f.run()
                old_calls=f.archive_creates;old_helpers=list(f.helpers)
                with self.assertRaises(Stop):f.enter()
                self.assertEqual(f.archive_creates,old_calls);self.assertEqual(f.helpers,old_helpers)
    def test_new_production_entry_imports_all_rows_once_without_dispatch(self):
        from production_generation_entry_v2 import ProductionEntry
        f=Fixture();h=f.run();entry=ProductionEntry.__new__(ProductionEntry)
        entry.sidecar=SimpleNamespace(grant=dict(reconciliation_grant_ref=f.gr,
            namespace_initialization_handoff=ref(f.r/"RECONCILED_HANDOFF.v2.json"),
            entry_initial_archive_receipt=h["archive_receipt"]))
        rows,digest=entry.bootstrap_receipts(h["index_receipt"])
        self.assertEqual(rows,h["measurements"]);self.assertEqual(digest,filehash(f.r/"RECONCILED_HANDOFF.v2.json"))
        with self.assertRaises(Exception):entry.bootstrap_receipts(h["index_receipt"])
        self.assertFalse(hasattr(entry,"modules"))
    def test_isolated_cli_disabled_before_any_dispatch(self):
        gp=ROOT/"RECOVERY_GRANT.DEVELOPMENT.json"
        p=subprocess.run([sys.executable,"-I","-B",str(ROOT/"src/recovery_cli.py"),"--grant",str(gp),
                          "--grant-sha256",filehash(gp),"enter"],input="{}",capture_output=True,text=True)
        self.assertNotEqual(p.returncode,0);self.assertIn("recovery disabled",p.stderr)
        self.assertNotIn("ModuleNotFoundError",p.stderr)
if __name__=="__main__":unittest.main(verbosity=2)
