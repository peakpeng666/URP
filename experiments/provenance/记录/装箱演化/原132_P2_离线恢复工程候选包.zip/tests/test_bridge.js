'use strict';
// Trusted, synthetic tool responses only. This file never launches a process or connector.
const fs=require('fs'),path=require('path'),crypto=require('crypto'),assert=require('assert/strict');
const root=path.resolve(__dirname,'..');
const {recoverSuffix}=require('../src/suffix_bridge.js');
const digest=s=>crypto.createHash('sha256').update(s).digest('hex');
const text=fs.readFileSync(path.join(root,'RECOVERY_GRANT.DEVELOPMENT.json'),'utf8');
const original=JSON.parse(text);
const stages=original.suffix_actions;
const sources={commit:fs.readFileSync(path.join(root,'references/init/library_commit_v2.js'),'utf8'),
  retention:fs.readFileSync(path.join(root,'references/retention/retain_library_replies.js'),'utf8'),
  adapter:fs.readFileSync(path.join(root,'references/init/init_exec_adapter.js'),'utf8')};
function trustedTools(throwArchive=false,interruptStage=null){
  const calls={reads:[],archive:0,index:0,replace:0,helpers:[],stages:[],pending:null,position:0};
  const receipt=kind=>({library_file_id:kind==='index'?original.index.library_file_id:'libfile_TEST_ONLY_archive',
    file_id:kind==='index'?original.index.file_id:'file_TEST_ONLY_archive',current_version_number:0,
    local_blob_sha256:original[kind].sha256,local_blob_bytes:original[kind].bytes,
    write_result_confirmed:true,index_readback_confirmed:kind==='index',remote_bytes_verified:false});
  const tools={
    async exec_command(a){
      assert.equal(a.login,false);
      if(a.cmd.includes(original.recovery_cli_path)){
        const m=/ (enter|before|after|payload|finish) <<'RECOVERY_JSON'\n([^\n]*)\nRECOVERY_JSON$/.exec(a.cmd);
        assert.ok(m,'fixed CLI command');const action=m[1],b=JSON.parse(m[2]);
        if(action==='before'){
          assert.equal(calls.pending,null,'unresolved effect stops');assert.equal(b.stage,stages[calls.position]);
          calls.pending=b.stage;calls.stages.push(b.stage);
          if(b.stage===interruptStage)throw Error('TEST_ONLY trusted interruption');
        }
        if(action==='after'){assert.equal(b.stage,calls.pending);calls.pending=null;calls.position++;}
        if(action==='finish'){assert.equal(calls.position,stages.length);assert.equal(calls.pending,null);}
        return {exit_code:0,output:JSON.stringify(action==='finish'?{TEST_ONLY:true,suffix_complete:true}:{}),session_id:null};
      }
      if(a.cmd.includes('/assemble_handoff.py'))return {exit_code:0,output:'{}'};
      const m=/--step '(index|archive)\.(receipt|confirm|begin|retain-start|retain-response|xattrs)'/.exec(a.cmd);
      assert.ok(m,'only fixed original helper commands');calls.helpers.push(m[1]+'.'+m[2]);
      return {exit_code:0,output:JSON.stringify(m[2]==='receipt'?receipt(m[1]):{})};
    },
    async mcp__codex_apps__library_read(a){
      assert.ok([original.index.file_id,original.index.library_file_id].includes(a.read[0].ref_id));calls.reads.push(a.read[0].ref_id);
      return JSON.parse(fs.readFileSync(path.join(root,'evidence/recovery_diagnostic/CURRENT_READ.raw.json'),'utf8'));
    },
    async mcp__codex_apps__library_create_library_file(a){
      assert.equal(a.file,original.producer_workspace+'/archive.initial.zip');calls.archive++;
      assert.equal(calls.archive,1);if(throwArchive)throw Error('TEST_ONLY archive outcome unknown');
      return {isError:false,structuredContent:{status:'succeeded',library_file_id:'libfile_TEST_ONLY_archive',
        file_id:'file_TEST_ONLY_archive',current_version_number:0,file_name:'archive.initial.zip',xattrs:[]}};
    },
    async mcp__codex_apps__library_replace_library_file(){calls.replace++;throw Error('real/replace tools refused');},
    async apply_patch(){throw Error('raw payload writer refused');}
  };return {tools,calls};
}
async function main(){
  let x=trustedTools();await assert.rejects(recoverSuffix(x.tools,text,digest(text),path.join(root,'RECOVERY_GRANT.DEVELOPMENT.json'),sources),/recovery_disabled/);
  assert.equal(x.calls.reads.length+x.calls.archive+x.calls.helpers.length,0);
  // This JSON is in-memory only and is used solely with the synthetic tool object.
  const enabledFixture=JSON.stringify({...original,execution_granted:true,independent_review_accepted:true});
  for(const field of ['commit','retention','adapter']){
    x=trustedTools();await assert.rejects(recoverSuffix(x.tools,enabledFixture,digest(enabledFixture),'/tmp/TEST_ONLY.grant.json',
      {...sources,[field]:sources[field]+'\nDRIFT'}),/original_source_/);
    assert.equal(x.calls.helpers.length+x.calls.reads.length+x.calls.archive,0);
  }
  x=trustedTools();const value=await recoverSuffix(x.tools,enabledFixture,digest(enabledFixture),'/tmp/TEST_ONLY.grant.json',sources);
  assert.equal(value.TEST_ONLY,true);assert.deepEqual(x.calls.stages,stages);
  assert.deepEqual(x.calls.helpers,['index.receipt','index.confirm','archive.begin','archive.retain-start',
    'archive.retain-response','archive.xattrs','archive.receipt','archive.confirm']);
  assert.deepEqual(x.calls.reads,[original.index.file_id,original.index.library_file_id]);
  assert.equal(x.calls.archive,1);assert.equal(x.calls.replace,0);assert.equal(x.calls.index,0);
  x=trustedTools(true);await assert.rejects(recoverSuffix(x.tools,enabledFixture,digest(enabledFixture),'/tmp/TEST_ONLY.grant.json',sources));
  assert.equal(x.calls.archive,1);assert.equal(x.calls.replace,0);assert.ok(!x.calls.helpers.includes('archive.xattrs'));
  for(const stage of stages){
    x=trustedTools(false,stage);await assert.rejects(recoverSuffix(x.tools,enabledFixture,digest(enabledFixture),'/tmp/TEST_ONLY.grant.json',sources));
    assert.ok(x.calls.archive<=1);assert.equal(x.calls.index+x.calls.replace,0);
    assert.ok(!x.calls.stages.includes(stages[stages.indexOf(stage)+1]));
  }
  process.stdout.write(JSON.stringify({status:'PASS',fixture_only:true,cases:20,fixed_stages:14,index_new_creates:0,
    replacements:0,archive_creates_in_success:1,actual_connector_calls:0,actual_helper_processes:0})+'\n');
}
main().catch(e=>{process.stderr.write(e.stack+'\n');process.exitCode=1;});
