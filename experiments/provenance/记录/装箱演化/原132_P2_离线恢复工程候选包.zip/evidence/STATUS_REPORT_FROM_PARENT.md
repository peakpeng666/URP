# 原132主线恢复诊断与实际停点

2026年10月6日13时03分UTC状态补充。

只读技术诊断已完成。精确index再次读到859字节，SHA-256与冻结输入相符；这不补造原失败调用的回执，不闭合原V2提交链。pending fence仍未清，archive、assembler、GEN均未执行。

随后尝试向原生产任务发起“只离线实现与可信fixture测试”的工作消息，服务因所选模型容量不足返回动作未执行。没有启动新的执行轮次，没有恢复代码实现、生产写入或模型生成。本文中的恢复bridge、共享预算guard、新版handoff和导入兼容均仍是技术方案，不是已经实现或验收的代码。

保持旧失败证据及原grant/输入字节；不能重放index create或用替代路线绕过这次未执行。未来真正恢复仍需新的工程契约、实现和独立验收，并对新增恢复开销单独计量。

本次诊断包含静态校验与两次只读查询，没有实验run或API模型请求。诊断/编写的全量CPU和实际平台账单未计量，不把未知成本写成0。

先读本页的实际状态，再读RECOVERY_REVIEW.md内技术路线；相关机器记录与原只读返回一并保留。


# 原132 P2停点：最小安全恢复路线（只读技术审阅）

时间：2026-10-06 13:00 UTC。结论：可设计无重复index create的恢复，但旧固定入口不具备恢复接口，纯读不能将它变成已完成INIT。本轮建议仅让原producer在新目录离线实现和可信fixture测试；真实恢复、archive写入、assembler和GEN保持未执行。用户已明确要求继续实验；本文的新grant指工程门控和精确源代码/动作绑定，不是在泛化请求用户再次批准继续研究。

## 1. 已得到的新证据

- 当前原精确read请求已成功：backing ID file_00000000d48881f58e04687a2b2eb6b4，Library ID libfile_d711508ec1888191ba87324ac424a529，has_more=false，859 B完整index。单独以Library ID读取也回到同一backing ID和相同内容。工具返回version_id=null；v0来自原已留存create结果，不伪称当前read另行报告了版本号。
- 新read文本字节与冻结initial index及停止ZIP内index逐字节相同，SHA256 83007fa4f9c1cfa8691bf23aa5f07d4a96881d356ee437197b2695774ad313c6。两个真实read原始返回均保存在本报告目录。这是新的独立读证据，不是原失败调用的补写记录，更不是commit receipt。
- 停止ZIP SHA256 ca21bf7717fefb52d27437cd2373ac6021ea6260182a29a1d9a1a15ca287c04e；29个manifest成员大小/哈希均通过。原grant SHA256 fd7e0df05db28dc38b14a3231662c8f775db8472d46625f3c3a02a3c6e26166e，7个本地补充实现pin与它一致。
- 五个真实helper（00 build、01 index.begin、02 retain-start、03 retain-response、04 xattrs）的intent/grant哈希与confirmed receipt一致。停止包未含05–12 intent。原producer的实时磁盘仍需它自己在实施前核验，本报告未访问或改写其环境。
- 原部分观测开销：SELF 0.225943 s，local inclusive wall 0.17413645899796393 s。只是已记录checkpoint合计，不是完整耗时/硬上界。

## 2. 为什么不能直接继续旧入口

init_bridge.js:57–65总是从index开始执行完整固定两次commit。重调不是resume，会重新进入index.begin；原helper的顺序检查及已有intent/fence本应挡住它。init_exec_adapter闭包中的created/item/readCount无法从已终止调用恢复，不能伪造create返回或把旧返回伪装成这次新工具调用。

原library_commit_v2.js:9–22已完成的是begin/create/xattrs；失败点在33行的read检查。尚未执行的尾部是36–47行真实payload→receipt→confirm。原helper对05的顺序要求恰为已有5条confirmed；这说明技术上可调用原05/06，不代表旧grant已覆盖新的控制流。RUNBOOK要求archive在同一次原initializeNamespace中执行，所以独立suffix bridge必须作为明确的新工程契约。

纯读只能消除“当前index内容不可读”的事实障碍，不能重启旧JS栈、产生真实helper receipt、清fence、创建archive或完成handoff。

## 3. 最小代码/契约增量（新目录，原文件字节不变）

1. 新固定suffix-only恢复bridge及窄工具allowlist；输入只允许原grant、独立reconciliation grant、其pin、原停点证据和冻结源快照。拒绝回调、可选任意步骤、任意identity、create-index/replace接口；不能以修改旧initializeNamespace、hydrate旧adapter或假工具返回的方式恢复。
2. 新恢复检查/计量/一次性journal组件。它只处理明确白名单动作和证据，不提供泛化shell接口。自己的本地进程必须前置SELF/monotonic采样、独占intent、真实receipt。原13个helper和原assembler仍通过未修改的原wrapper与原代码执行。
3. 新versioned reconciled handoff assembler：保留原assembler真正输出的14/16 v1作为base evidence，另外准确包含恢复增量和失败历史。
4. 后续GEN importer只做窄兼容扩展来导入新handoff与全部恢复计量；保持旧科学选择、60个P2槽、源候选、P1和heldout规则不变。新代码单独pin/审阅，更新新工程激活文件；不改老grant或老源pin来伪称未变化。本轮仅离线实现/测试该兼容分支，不激活GEN。

建议reconciliation grant字段至少绑定：原grant exact-file SHA；producer/journal准确路径；stop ZIP及原bridge错误记录SHA；原5条intent/receipt SHA；pending SHA 28d28fe5af6521d9e855487bdd50438fb90bcfccc0ecf871ad5099159fdd1092；原create response SHA 9b60293b0f0ea36a07e14f58935234161c8808ae0597b01aa0d3cf8608cc0326；index两ID/v0/859B/hash；archive本地478B/hash bb644cab41cf25559f1bdc7fe3212ccbf0d61362a16dd0f717e2c1ff3795f43f；原及新实现pin；允许动作顺序；同一个60/240池；实际index额外create/replace=0；最多1次尚未发生的archive create；GEN/model/candidate/numeric均false/0。本轮开发grant必须execution_granted=false。

## 4. 将来原producer的严格执行顺序

A. 独占恢复入口并测量式核验：原5条及所有源pin不变，精确pending仍在，无05–12或assembly未知intent，无额外commit/readback/dispatch活动，index/archive本地哈希一致，原producer仍为唯一操作者。任何不一致停止，不整理或删除冲突证据。

B. 真实authenticated read精确index identity，完整保留新工具返回及hash/时间/来源。校验同一Library/backing identity、canonical完整内容、freeze/run/rows=[]；当前Library头指向相同backing。原create结果仍来自已保全的历史响应，明确其历史来源。新的读证据不得标成原失败read/search的返回。

C. 只首次新增原readback payload；它由历史真实create身份与本次真实read组成。通过原wrapper执行helper05 index.receipt，原commit_receipt_v2验证canonical hash；通过原wrapper执行helper06 index.confirm，使用刚取得的真实receipt。只允许原confirm函数在验证成功后写原durable commit并清pending。禁止手写commit、手动删pending、重跑00–04、重新create、强制改v1。

D. 独立新bridge里明确获准的archive后缀：在index确实确认后，绑定原adapter+retention+commit源，仅对原archive.initial.zip执行一次原commitV2(null,-1,false)，生成原helper07–12的六条真实receipt。新archive ID必须不同于index及四个P0/P1 ID；任何throw或unknown停止。绝不因index恢复而调用完整旧initializeNamespace。

E. 原13条helper齐全且无pending之后，原assembler首次执行，形成原14 measurement/16 receipt base链。接着新reconciled handoff把base与恢复增量一起封存。其自身汇编成本也必须真实测量并入同池；最后checkpoint之后的写入/退出尾部继续unknown。

F. 独立终审接受新handoff、所有pin/receipt及成本导入后，另行工程激活GEN。已确认index+archive不自动授权GEN。

## 5. 旧5条 + 新9条 + 恢复增量如何记账

- 原5条保持原文件、process ID、起止样本和数值，不能重新测一次替代。
- 尚缺9条是未执行动作：05/06两条 + 07–12六条 + assembler一条。将来首次真实执行后产生9条；不是“补造已发生但丢失的9次测量”。原链自然成为14条measurement、16个receipt引用。
- 额外恢复验证、证据留存、guard、handoff构建等新本地进程产生k条真实增量。总账是原14+k，不能删减/合并成虚构process以勉强保持14，不能只在receipt_files旁挂增量而不进measurements。
- CPU按稳定process身份累计SELF checkpoint取增量/最大值；wall按真实非重叠本地阶段窗口处理，不能将外层包含内层的窗口与内层再次相加。优先顺序执行独立测量的小检查进程，避免新增嵌套监督器与跨进程重叠歧义。
- 每个后续helper、archive调用、assembler之前，guard按“原已确认checkpoint + 恢复已确认checkpoint + 当前guard checkpoint”检查同一60 SELF/240 local-wall池；每个动作后再次汇入其新原receipt及恢复receipt并检查。任何未知/缺receipt/超额阻断下一步。仅在最后GEN导入时扣费是不够的。
- 原within函数只看原helper，不能把它误当成已包含recovery。新guard是额外已审计的门控，原within仍保留作为次级检查。
- 不重新发放60/240额度。仅按当前五条计算的理论余量59.774057 SELF/239.82586354100204 local-wall，还须扣所有未来恢复/原剩余初始化/GEN边界/最终化的观测成本；它不是完整真实余量或硬预算保证。
- 新handoff建议使用独立版本，例如phase2-namespace-init-reconciled-handoff-v2，包含base_handoff_ref、reconciliation_grant_ref、旧停止/真实新read evidence、恢复receipt与measurements、总汇入清单、观测总额和unknown清单。严格校验path/hash/namespace/identity/顺序/唯一process区间及零GEN。
- 原GEN bootstrap仅检查v1 schema及非空数组（production_generation_entry.py:104–123），且只返回handoff.measurements（157–158导入）。不利用其未硬检14/16来塞一个偷换语义的v1；增加显式v2分支并测“全部增量恰好一次入账”。旧base继续14/16，v2总账显式可变。

## 6. 失败与重放防护断言

- recovery grant单次：独占durable intent在第一个可变动作之前；已存在intent且无confirmed recovery结果时停止，不重入。新grant不能仅换ID绕过原pending或不明helper。
- index create/replace在恢复allowlist中不可达，测试观测次数严格0；历史总index create仍1。00–04也不可达；05/06只能首次顺序运行。
- 每一步按真实journal状态确认前缀；已有目标payload/receipt/commit、未知intent、额外helper、不同路径/源码或并发均fail closed，不覆盖也不“修复”。
- 原confirm是唯一允许改变pending的地方；调用前必须有同一pending hash、真实read、真实05 receipt；失败不直接unlink。
- archive create计数最多1；若工具抛出、结果不明、retention失败、helper或checkpoint失败，不重新create。持久保留exception/intent，后续人工式证据再审，而非自动重放。
- 崩溃注入点：新增payload前后、05前后、06写commit与清pending之间、archive intent/response/xattrs/receipt/confirm之间、assembler intent/receipt/handoff之间。每个中断点要证明停住且无重复external write。
- 原停止报告、bridge错误、旧grant和receipt不会被重命名/覆盖/删除；恢复完成也不删除失败历史。

## 7. 最小离线可信fixture验收

1. 成功停点：可信fixture有五条真实fixture helper与合成Library成功结果，模拟本次相同shape的完整read；恢复只执行后缀，原链14/16，总账14+k，index新create=0/archive create=1/model=0。
2. 缺损/篡改：任意旧receipt/intents/source/pending/create响应/hash/identity/version/canonical内容不符即在可变动作前停止。
3. 失败不重放：上述中断点 + helper unknown + archive throw + 第二次入口，均证明无额外create/无重复helper/无删fence。
4. 预算：旧5条必须计入；recovery增量必须影响每一步admission；接近60/240时阻断下一步；不能归零、用0补unknown、重复计算同process、遗漏增量或重复计nested wall。
5. 交接：原base schema14/16独立通过；v2导入base+delta恰好一次；receipt少一条、hash漂移、外namespace、新应计checkpoint缺失/unknown、错run/identity/源版本均拒绝；历史已明示允许的未知尾部/JS/Library等继续如实保留；v1旧读法不能静默当v2。
6. 永久禁用边界：offline fixture工具对象遇真实Library、OpenCode/模型/GEN调用即抛错；所有文件只在新开发目录/临时fixture namespace。生产原文件只读pin对照，不向原namespace写一字节。
7. 使用此前允许的普通可信fixtures；不重复先前被平台停止的对抗性getter/TOCTOU复现，不换路绕过该限制。

## 8. 无法恢复、必须保持unknown的缺口

原5进程最后checkpoint后的CPU/wall尾部、Python entry前wall、原JS/plugin CPU、原Library等待、provider CPU、原完整task/bookkeeping成本没有计量，不能靠现在时钟/新读/报告生成耗时倒推出。原失败read/search完整raw返回和每个helper完整exec roundtrip JSON当时未持久留存，本地stop包明确承认缺失；不能重建成原始证据。新的read可作为新证据，但不能解释过去读为什么失败。

恢复本地代码从现在起要计量；已经发生的本报告/独立审阅开销不是原helper账本里的已测成本，应单列“研究/审阅开销未作全量计量”，不冒充0或挪入已测GEN总数。

CPU_cap_certification始终NOT_ESTABLISHED，complete_CPU_upper_bound_claimed=false；1860/61440保持观测checkpoint/阶段窗口admission阈值意义。原receipt的remote_bytes_verified=false语义不改，新的独立index字节验证单独记录；archive仍不能宣称远端字节下载核验。

## 9. 本次边界和交付

本次仅静态读取原代码、校验停止ZIP、进行两次真实Library只读查询，并在新本地诊断目录写报告。未运行原helper/assembler、未修改原namespace、未清fence、未创建/替换Library文件、未启动新Codex、未调用模型/GEN。

伴随文件：CURRENT_READ.raw.json、CURRENT_HEAD_READ.raw.json、READ_ONLY_OBSERVATION.json、STATIC_VERIFICATION.json。精确原producer操作前，必须由原producer自己检查其实际路径与当前磁盘停点；本地ZIP副本不能代替该检查。
