"""Pinned, once-only recovery controls. All production entry grants default disabled."""
import hashlib, json, math, os, resource, time, uuid
from pathlib import Path
ENTRY = time.monotonic()
PROCESS = str(os.getpid()) + ":" + uuid.uuid4().hex
V1 = "phase2-namespace-init-resource-handoff-v1"
V2 = "phase2-namespace-init-reconciled-handoff-v2"
STAGES = ("read.backing","read.head","index.payload","index.receipt","index.confirm",
          "archive.begin","archive.retain-start","archive.create","archive.retain-response",
          "archive.xattrs","archive.payload","archive.receipt","archive.confirm","base.assemble")
OLD_STEPS = ["build"] + [k+"."+a for k in ("index","archive")
                         for a in ("begin","retain-start","retain-response","xattrs","receipt","confirm")]
UNKNOWN = dict(historical_CPU_tails=None, historical_startup_wall=None,
               JS_Library_provider_CPU_wait=None, original_failed_read_raw=None)
class Stop(RuntimeError): pass
def need(ok, reason):
    if not ok: raise Stop(reason)
def canon(v): return json.dumps(v,sort_keys=True,separators=(",",":"),ensure_ascii=False,allow_nan=False).encode()
def sha(b): return hashlib.sha256(b).hexdigest()
def read(p): return json.loads(Path(p).read_bytes())
def path(p):
    p=Path(p);need(p.is_absolute() and ".." not in p.parts and p.resolve()==p,"noncanonical path")
    need(not any(q.is_symlink() for q in (p,*p.parents)),"symlink");return p
def filehash(p):
    p=path(p);need(p.is_file(),"missing pinned file");return sha(p.read_bytes())
def ref(p): return dict(path=str(path(p)),file_sha256=filehash(p))
def checked_ref(r):
    need(set(r)=={"path","file_sha256"},"exact file reference")
    p=path(r["path"]);need(filehash(p)==r["file_sha256"],"file pin drift");return p
def publish(p,v):
    p=path(p);b=canon(v);fd=os.open(p,os.O_CREAT|os.O_EXCL|os.O_WRONLY|os.O_NOFOLLOW,0o600)
    with os.fdopen(fd,"wb") as f: f.write(b);f.flush();os.fsync(f.fileno())
    fd=os.open(p.parent,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
    try: os.fsync(fd)
    finally: os.close(fd)
    return ref(p)
def sample():
    r=resource.getrusage(resource.RUSAGE_SELF);end=time.monotonic()
    return dict(process=PROCESS,start=dict(process=PROCESS,monotonic=ENTRY,self_cpu=0.0),
                end=dict(process=PROCESS,monotonic=end,self_cpu=r.ru_utime+r.ru_stime),
                self_cpu_seconds=r.ru_utime+r.ru_stime,wall_seconds=end-ENTRY,
                local_inclusive_wall_seconds=end-ENTRY,native_wait_union_seconds=0,
                measurement_status="known",RUSAGE_kind="RUSAGE_SELF")
def validate_measurement(m):
    need(m.get("measurement_status")=="known" and m.get("RUSAGE_kind")=="RUSAGE_SELF"
         and m.get("native_wait_union_seconds")==0,"unknown measurement")
    need(m["process"]==m["start"]["process"]==m["end"]["process"],"process mismatch")
    for x in (m["start"]["monotonic"],m["end"]["monotonic"],m["start"]["self_cpu"],
              m["end"]["self_cpu"],m["self_cpu_seconds"],m["local_inclusive_wall_seconds"]):
        need(type(x) in (int,float) and math.isfinite(x) and x>=0,"invalid sample")
    need(m["end"]["self_cpu"]>=m["start"]["self_cpu"],"CPU backwards")
    need(abs(m["self_cpu_seconds"]-(m["end"]["self_cpu"]-m["start"]["self_cpu"]))<1e-7,
         "CPU checkpoint mismatch")
    need(m["end"]["monotonic"]>=m["start"]["monotonic"] and
         abs(m["local_inclusive_wall_seconds"]-(m["end"]["monotonic"]-m["start"]["monotonic"]))<1e-7,
         "window mismatch")
def totals(ms):
    """Stable-process cumulative high-water CPU; never sum nested/overlapping wall."""
    cpu={};windows=[]
    for m in ms:
        validate_measurement(m);cpu[m["process"]]=max(cpu.get(m["process"],0),m["end"]["self_cpu"])
        s,e=m["start"]["monotonic"],m["end"]["monotonic"]
        if e>s: windows.append((s,e))
    windows.sort()
    need(all(a[1]<=b[0]+1e-10 for a,b in zip(windows,windows[1:])),"overlapping local windows")
    return sum(cpu.values()),sum(e-s for s,e in windows)
def admission(ms,current=None):
    values=ms+([] if current is None else [current]);c,w=totals(values)
    need(c<60 and w<240,"shared init_final pool exhausted")
    return c,w
def unwrap(r):
    x=r.get("structuredContent")
    if not x:
        for c in r.get("content",[]):
            if c.get("type")=="text":
                try:x=json.loads(c["text"]);break
                except (ValueError,TypeError):pass
    while isinstance(x,dict) and x.get("structuredContent"):x=x["structuredContent"]
    return x
def validate_read(raw,index,frozen):
    x=unwrap(raw);rows=x.get("results") if isinstance(x,dict) else None
    need(isinstance(rows,list) and len(rows)==1,"one authenticated index row")
    row=rows[0];need(row.get("file_id")==index["file_id"] and
        row.get("library_file_id")==index["library_file_id"] and row.get("has_more") is False,
        "read identity/incomplete")
    need(isinstance(row.get("content"),list) and all(isinstance(s,str) for s in row["content"]),"read text")
    text="\n".join(row["content"]);b=text.encode();need(len(b)==index["bytes"] and sha(b)==index["sha256"]
        and b==frozen,"frozen index bytes")
    obj=json.loads(b);need(obj["rows"]==[] and obj["archives"]=={},"index not empty")
    # version_id may be null: v0 provenance is the historical create, never the new read.
    return dict(file_id=row["file_id"],library_file_id=row["library_file_id"],content=text,has_more=False)
def check_grant(g,fixture=False):
    need(g["schema"]=="phase2-stop-reconciliation-grant-v1","recovery schema")
    need(g["generation_execution_granted"] is False and g["numeric_execution_granted"] is False
         and g["model_requests"]==g["candidate_executions"]==0,"zero GEN/model/candidate scope")
    need(g["new_index_create_count"]==g["index_replace_count"]==0 and
         g["archive_create_max"]==1 and g["historical_index_create_count"]==1,"write quota")
    need(g["pool"]=={"SELF_checkpoint_seconds":60,"local_inclusive_wall_seconds":240,"new_budget":False},"no new pool")
    need(g["CPU_cap_certification"]=="NOT_ESTABLISHED" and g["unknown"]==UNKNOWN,"unknown history")
    if fixture:
        p=path(g["producer_workspace"]);root=Path(__file__).resolve().parents[1]/"fixtures"
        need(g.get("TEST_ONLY") is True and p.is_relative_to(root) and
             g["execution_granted"] is False,"fixture isolation")
    else:
        need(g["execution_granted"] is True and g["independent_review_accepted"] is True,"recovery disabled")
    for key in ("old_grant_ref","stop_zip_ref","old_bridge_error_ref","historical_create_ref"):
        checked_ref(g[key])
    old=read(checked_ref(g["old_grant_ref"]))
    need(g["original_implementation_root"]==old["implementation_root"] and
         g["old_grant_file_text"].encode()==Path(g["old_grant_ref"]["path"]).read_bytes(),"old grant exact bytes")
    need(g["operational_run_id"]==old["operational_run_id"] and
         g["scientific_run_id"]==old["original_scientific_run_id"] and
         g["forbidden_prior_library_file_ids"]==old["forbidden_prior_library_file_ids"],"old grant namespace")
    need(g["original_source_pins"]==old["exact_original_source_pins"] and
         g["original_implementation_pins"]=={str(Path(old["implementation_root"])/n):h
             for n,h in old["implementation_files"].items()},"complete original source maps")
    manifest=checked_ref(g["generation_original_manifest_ref"])
    need(filehash(manifest)==old["generation_operating_manifest_file_sha256"] and
         g["generation_original_pins"]=={str(manifest.parent/n):h
             for n,h in read(manifest)["production_files"].items()},"complete original generation map")
    if not fixture:
        need(g["producer_workspace"]==old["producer_workspace"] and
             g["original_journal_root"]==old["journal_root"],"exact production namespace")
    need(g["original_journal_root"]==g["producer_workspace"]+".namespace-init" and
         g["recovery_journal_root"]==g["producer_workspace"]+".namespace-recovery" and
         g["suffix_actions"]==list(STAGES),"fixed recovery namespace and suffix")
    src=Path(__file__).resolve().parent
    expected={str(src/n) for n in ("recovery_core.py","recovery_cli.py","reconciled_handoff.py",
                                  "gen_importer_v2.py","production_generation_entry_v2.py","suffix_bridge.js")}
    need(set(g["new_source_pins"])==expected and g["recovery_cli_path"]==str(src/"recovery_cli.py"),
         "complete new source set")
    for group in ("original_source_pins","original_implementation_pins","generation_original_pins","new_source_pins"):
        need(bool(g[group]),"full source pins required: "+group)
        for p,h in g[group].items():need(filehash(p)==h,"source drift")
    need(len(g["old_five"])==5,"five historical helpers")
    for n,pair in enumerate(g["old_five"]):
        need(all(pair[k]["path"]==str(Path(g["original_journal_root"])/f"helper-{n:02d}.{k}.json")
                 for k in ("intent","receipt")),"exact historical helper paths")
        checked_ref(pair["intent"]);checked_ref(pair["receipt"])
    return g
def base_records(g):
    j=path(g["original_journal_root"]);out=[]
    actual=list(j.glob("helper-*.intent.json"))
    for n,step in enumerate(OLD_STEPS):
        ip=j/f"helper-{n:02d}.intent.json";rp=j/f"helper-{n:02d}.receipt.json"
        if not ip.exists():
            need(not rp.exists(),"orphan original receipt");continue
        need(n==len(out) and rp.exists(),"unknown original helper")
        i,r=read(ip),read(rp)
        need(i["step"]==r["step"]==step and r["outcome"]=="confirmed" and
             r["intent_file_sha256"]==filehash(ip) and
             r["init_grant_file_sha256"]==g["old_grant_ref"]["file_sha256"],"original helper binding")
        validate_measurement(r["measurement"]);out.append(r)
    need(len(actual)==len(out),"extra original intent")
    ap=j/"assembly.intent.json";ar=j/"assembly.receipt.json"
    if ap.exists() or ar.exists():
        need(len(out)==13 and ap.exists() and ar.exists(),"unknown base assembler")
        r=read(ar);need(r["outcome"]=="confirmed" and r["intent_file_sha256"]==filehash(ap)
                       and r["init_grant_file_sha256"]==g["old_grant_ref"]["file_sha256"],"base assembly binding")
        out.append(r)
    return out
def validate_stop(g):
    w=path(g["producer_workspace"]);j=path(g["original_journal_root"])
    checked_ref(g["pending_ref"]);create=unwrap(read(checked_ref(g["historical_create_ref"])))
    idx=g["index"];need(create["status"]=="succeeded" and
        all(create[k]==idx[v] for k,v in (("library_file_id","library_file_id"),("file_id","file_id"),
                                         ("current_version_number","version"),("file_size_bytes","bytes"))),
        "historical identity")
    need(create["file_name"]==idx["file_name"],"historical index name")
    need(idx["version"]==0 and idx["library_file_id"] not in g["forbidden_prior_library_file_ids"],"index version/old ID")
    for kind,filename in (("index","index.initial.json"),("archive","archive.initial.zip")):
        b=(w/filename).read_bytes();need(len(b)==g[kind]["bytes"] and sha(b)==g[kind]["sha256"],"blob drift")
    pending=read(w/"state/external-pending.json")
    need(pending["kind"]=="index" and pending["library_file_id"] is None and
         pending["expected_current_version"]==-1 and pending["local_blob_sha256"]==idx["sha256"],"pending binding")
    need(len(base_records(g))==5 and not (j/"assembly.intent.json").exists()
         and not (w/"state/commits").exists(),"not exact stopped prefix")
    need(not list((w/"state").glob("readback-*.json")) and
         not (w/"retained-library-replies/phase2-init-archive").exists(),"extra stopped activity")
    need(not (w/"phase2-generation-accounting").exists() and not (w/"phase2-bridge-journal").exists(),"unexpected GEN activity")
class Ledger:
    def __init__(self,g,grant_ref,fixture=False):
        self.g=check_grant(g,fixture);self.grant_ref=grant_ref;self.root=path(g["recovery_journal_root"])
        self.fixture=fixture
    def check(self):
        need(read(checked_ref(self.grant_ref))=={k:v for k,v in self.g.items() if not k.startswith("_")},
             "recovery grant binding drift")
        check_grant(self.g,self.fixture)
    def delta(self):
        out=[]
        for n,ip in enumerate(sorted(self.root.glob("delta-*.intent.json"))):
            need(ip.name==f"delta-{n:04d}.intent.json","noncontiguous recovery journal")
            rp=ip.with_name(ip.name.replace(".intent.",".receipt."))
            need(rp.exists(),"unknown recovery process")
            r=read(rp);need(r["outcome"]=="confirmed" and r["intent_file_sha256"]==filehash(ip)
                           and r["reconciliation_grant_ref"]==self.grant_ref,"unknown recovery receipt")
            validate_measurement(r["measurement"]);out.append(r)
        need(len(list(self.root.glob("delta-*.receipt.json")))==len(out),"orphan recovery receipt")
        return out
    def measurements(self):return [r["measurement"] for r in base_records(self.g)+self.delta()]
    def meter(self,label,body,measure=sample):
        self.check()
        need(not (self.root/"HALTED.json").exists(),"recovery halted")
        prior=self.measurements()
        n=len(self.delta());ip=self.root/f"delta-{n:04d}.intent.json"
        publish(ip,{"label":label,"reconciliation_grant_ref":self.grant_ref})
        try:
            admission(prior,measure())
            result=body();m=measure();admission(prior,m)
        except BaseException as e:
            m=measure()
            publish(self.root/f"delta-{n:04d}.receipt.json",
                    dict(outcome="unknown",intent_file_sha256=filehash(ip),measurement=m,
                         reconciliation_grant_ref=self.grant_ref,error=type(e).__name__+": "+str(e)))
            if not (self.root/"HALTED.json").exists():publish(self.root/"HALTED.json",{"reason":str(e)})
            raise
        receipt=dict(outcome="confirmed",intent_file_sha256=filehash(ip),measurement=m,
                     reconciliation_grant_ref=self.grant_ref,label=label,
                     post_checkpoint_CPU_tail=None,post_checkpoint_wall_tail=None)
        publish(self.root/f"delta-{n:04d}.receipt.json",receipt);return result
    def enter(self,measure=sample):
        self.check()
        need(not self.root.exists(),"recovery once-only lease exists")
        validate_stop(self.g);admission([r["measurement"] for r in base_records(self.g)],measure())
        self.root.mkdir(mode=0o700);publish(self.root/"entry.intent.json",{"reconciliation_grant_ref":self.grant_ref})
        return self.meter("enter",lambda:{"entered":True},measure)
    def progress(self):
        n=0
        for stage in STAGES:
            ip=self.root/f"effect-{n:02d}.intent.json";rp=self.root/f"effect-{n:02d}.receipt.json"
            if not ip.exists():
                need(not rp.exists(),"orphan effect");break
            need(rp.exists(),"unresolved effect; never replay")
            r=read(rp);need(r["stage"]==stage and r["outcome"]=="confirmed"
                           and r["intent_file_sha256"]==filehash(ip),"effect binding");n+=1
        need(len(list(self.root.glob("effect-*.intent.json")))==n,"unexpected effect")
        return n
    def before(self,stage,measure=sample):
        def body():
            n=self.progress();need(n<len(STAGES) and STAGES[n]==stage,"fixed suffix order")
            expected=(5,5,5,5,6,7,8,9,9,10,11,11,12,13)[n]
            need(len(base_records(self.g))==expected,"original suffix prefix drift")
            if n<=4:checked_ref(self.g["pending_ref"])
            publish(self.root/f"effect-{n:02d}.intent.json",{"stage":stage,"reconciliation_grant_ref":self.grant_ref})
            return {"stage":stage,"number":n}
        return self.meter("before:"+stage,body,measure)
    def after(self,stage,observation,measure=sample):
        def body():
            n=STAGES.index(stage);ip=self.root/f"effect-{n:02d}.intent.json"
            need(ip.exists() and not (self.root/f"effect-{n:02d}.receipt.json").exists(),"effect not pending")
            need(read(ip)=={"stage":stage,"reconciliation_grant_ref":self.grant_ref} and
                 len(list(self.root.glob("effect-*.intent.json")))==n+1 and
                 len(list(self.root.glob("effect-*.receipt.json")))==n,"pending effect prefix")
            validate_effect(self.g,self.root,stage,observation)
            publish(self.root/f"effect-{n:02d}.receipt.json",
                    {"stage":stage,"outcome":"confirmed","intent_file_sha256":filehash(ip)})
            return {"confirmed":stage}
        return self.meter("after:"+stage,body,measure)
def validate_effect(g,root,stage,o):
    w=path(g["producer_workspace"]);j=path(g["original_journal_root"])
    if stage.startswith("read."):
        r=validate_read(o,g["index"],(w/"index.initial.json").read_bytes())
        publish(root/(stage+".raw.json"),o);return r
    if stage=="archive.create":
        x=unwrap(o);need(not o.get("isError") and x["status"]=="succeeded" and
            x["library_file_id"] not in [g["index"]["library_file_id"],*g["forbidden_prior_library_file_ids"]]
            and type(x["current_version_number"]) is int and x["current_version_number"]>=0,"archive acknowledgement")
        publish(root/"archive-create.raw.json",o);return x
    if stage in ("index.payload","archive.payload"):
        identity=g["index"]["library_file_id"] if stage=="index.payload" else unwrap(read(root/"archive-create.raw.json"))["library_file_id"]
        version=g["index"]["version"] if stage=="index.payload" else unwrap(read(root/"archive-create.raw.json"))["current_version_number"]
        p=w/"state"/f"readback-{identity}-{version}.json"
        need(p.exists(),"missing actual payload")
        create=unwrap(read(checked_ref(g["historical_create_ref"]))) if stage=="index.payload" else unwrap(read(root/"archive-create.raw.json"))
        rb=validate_read(read(root/"read.backing.raw.json"),g["index"],(w/"index.initial.json").read_bytes()) if stage=="index.payload" else None
        need(read(p)=={"item":{k:create[k] for k in ("status","library_file_id","file_id","current_version_number")},
                       "readback":rb},"exact actual payload")
        return
    if stage=="base.assemble":
        p=j/"INIT_RESOURCE_HANDOFF.json";need(p.exists(),"missing actual base handoff")
        validate_base(read(p),g);return
    step=OLD_STEPS.index(stage);records=base_records(g);need(len(records)==step+1,"missing original helper receipt")
    if stage in ("index.confirm","archive.confirm"):
        need(not (w/"state/external-pending.json").exists(),"pending remains")
        kind=stage.split('.')[0]
        create=unwrap(read(checked_ref(g["historical_create_ref"]))) if kind=="index" else unwrap(read(root/"archive-create.raw.json"))
        p=w/"state/commits"/(create["library_file_id"]+"-"+str(create["current_version_number"])+".json")
        r=read(p);need(r["index_readback_confirmed"]==(kind=="index") and r["write_result_confirmed"] is True
             and r["library_file_id"]==create["library_file_id"] and r["file_id"]==create["file_id"]
             and r["current_version_number"]==create["current_version_number"]
             and r["local_blob_sha256"]==g[kind]["sha256"] and r["remote_bytes_verified"] is False,
             "actual original commit required")
def validate_base(base,g):
    need(base["schema"]==V1 and base["status"]=="CONFIRMED" and
         base["producer_workspace"]==g["producer_workspace"] and
         base["operational_run_id"]==g["operational_run_id"] and
         base["init_grant_file_sha256"]==g["old_grant_ref"]["file_sha256"],"base namespace")
    need(base["model_calls"]==base["candidate_executions"]==0 and base["generation_execution_granted"] is False,"base scope")
    need(len(base["measurements"])==14 and len(base["receipt_files"])==16,"strict base14/16")
    rs=base_records(g);need(len(rs)==14 and base["measurements"]==[r["measurement"] for r in rs],"actual base measurements")
    w=path(g["producer_workspace"]);j=path(g["original_journal_root"]);expected={str(j/f"helper-{n:02d}.receipt.json") for n in range(13)}
    expected.add(str(j/"assembly.receipt.json"))
    for kind in ("index","archive"):
        r=base[kind+"_receipt"];p=w/"state/commits"/(r["library_file_id"]+"-"+str(r["current_version_number"])+".json")
        need(read(p)==r and r["write_result_confirmed"] is True and r["remote_bytes_verified"] is False
             and r["index_readback_confirmed"]==(kind=="index"),"actual original commit")
        expected.add(str(p))
        need(r["local_blob_sha256"]==g[kind]["sha256"] and r["local_blob_bytes"]==g[kind]["bytes"],"base frozen blobs")
    need(base["index_receipt"]["library_file_id"]==g["index"]["library_file_id"]
         and base["index_receipt"]["file_id"]==g["index"]["file_id"]
         and base["archive_receipt"]["library_file_id"] not in [g["index"]["library_file_id"],*g["forbidden_prior_library_file_ids"]],"base identities")
    need(len({r["path"] for r in base["receipt_files"]})==16 and {r["path"] for r in base["receipt_files"]}==expected,"base receipt set")
    for r in base["receipt_files"]:checked_ref(r)
    totals(base["measurements"]);return base
