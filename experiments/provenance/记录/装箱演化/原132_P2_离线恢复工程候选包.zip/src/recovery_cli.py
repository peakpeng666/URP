"""Fixed measured local CLI. Production requires a separately reviewed enabled grant."""
import argparse, json, sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from recovery_core import *
from reconciled_handoff import assemble_v2
def payload(ledger,kind,measure=sample):
    g=ledger.g;w=path(g["producer_workspace"]);r=ledger.root
    n=STAGES.index(kind+".payload")
    need(read(r/f"effect-{n:02d}.intent.json")=={"stage":kind+".payload","reconciliation_grant_ref":ledger.grant_ref}
         and not (r/f"effect-{n:02d}.receipt.json").exists()
         and len(list(r.glob("effect-*.intent.json")))==n+1
         and len(list(r.glob("effect-*.receipt.json")))==n,"payload admitted prefix required")
    if kind=="index":
        item=unwrap(read(checked_ref(g["historical_create_ref"])))
        rb=validate_read(read(r/"read.backing.raw.json"),g["index"],(w/"index.initial.json").read_bytes())
    else:item=unwrap(read(r/"archive-create.raw.json"));rb=None
    p=w/"state"/("readback-"+item["library_file_id"]+"-"+str(item["current_version_number"])+".json")
    obj={"item":{k:item[k] for k in ("status","library_file_id","file_id","current_version_number")},"readback":rb}
    return ledger.meter(kind+".payload.write",lambda:{"payload_ref":publish(p,obj)},measure)
def main():
    a=argparse.ArgumentParser();a.add_argument("--grant",required=True);a.add_argument("--grant-sha256",required=True)
    a.add_argument("action",choices=("enter","before","after","payload","finish"));v=a.parse_args()
    gp=path(v.grant);need(filehash(gp)==v.grant_sha256,"recovery grant file pin")
    g=read(gp);ledger=Ledger(g,ref(gp));body=json.loads(sys.stdin.read() or "{}")
    if v.action=="enter":out=ledger.enter()
    elif v.action=="before":out=ledger.before(body["stage"])
    elif v.action=="after":out=ledger.after(body["stage"],body["observation"])
    elif v.action=="payload":
        need(body["kind"] in ("index","archive"),"fixed payload")
        n=STAGES.index(body["kind"]+".payload")
        need((ledger.root/f"effect-{n:02d}.intent.json").exists(),"payload admission required")
        out=payload(ledger,body["kind"])
    else:out=assemble_v2(ledger)
    sys.stdout.write(canon(out).decode())
if __name__=="__main__":main()
