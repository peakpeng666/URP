原132主线 P2 第四批20–25：独立只读归档核验
2026-10-07 10:24 UTC

本包只含本次审核证据；两个原始ZIP已在原私有实验资料/报告目录，SOURCE_REFERENCES.json列出真实Drive入口、大小和SHA，不重复上传。

40项manifest内容hash及两个ZIP CRC通过。6份prompt均与原冻结pack逐字节一致；原runner、frozen_inputs、配置原文和记录的CLI版本/二进制pin与此前已审基线一致。记录配置仍为GLM-5.3/high、max64000、temperature0.7、top_p0.9、900秒、tools=false、outer_retries=0，无按量付费fallback。

20/21/23/25：正常stop且回答非空，分别965/1544/1160/999字节。22/24：客户端timeout、exit -9，回答空，wall900.045243/900.051659秒，usage未知。非空及exit0不等于科学准入/有效候选；客户端超时不证明服务端已取消。

与既有首槽和前三批核验累计：前25/60生成终态已归档，19非空、1 length空、5 timeout空；原计划97/132逻辑生成终态，不代表97个科学合格结果。原STATUS_SNAPSHOT的current_position=26仅为归档时生产者快照；本审计没有独立查询活进程。生产者计数remaining_unstarted=35含活动槽，而BATCH_REPORT依据26个永久槽目录列出34尚未启动，两者口径差异原样保留。

前19公开数值评分已在独立归档中完成并审计通过；本次不重做评分，不执行20–25的候选、runner或collector，不另建stage、不向生成器反馈。provider真实请求体/HTTP次数/usage/扣费与全历史资源余额仍未独立认证。
check.py是标准库只读ZIP/JSON/hash检查器；可指定已下载原包和原冻结基线进行复核。审计CPU约0.02018秒，不含后续打包和云端归档。
