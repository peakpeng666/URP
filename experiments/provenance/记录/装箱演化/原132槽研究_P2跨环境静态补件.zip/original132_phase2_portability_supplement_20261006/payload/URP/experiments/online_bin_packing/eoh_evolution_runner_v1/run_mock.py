"""Run fabricated lifecycle examples. Has no API/executor/credential integration."""
import argparse
import json
from pathlib import Path
from audit import audit
from fixtures import capture, panel, run_fake, score_records
from runner import Runner


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--scenario', choices=('full', 'empty_eoh', 'truncated_budget', 'integrity_stop'), default='full')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    runner = Runner(panel(), logical_budget=17 if args.scenario == 'truncated_budget' else 132)
    if args.scenario == 'integrity_stop':
        slot = runner.next_request()
        response = capture(slot)
        scores = score_records(slot, response)
        scores[0]['evidence']['cleanup_status'] = 'failed'
        runner.observe(slot['id'], response, scores)
        ledger = runner.export()
    else:
        def response(slot):
            if args.scenario == 'empty_eoh' and slot['arm'] == 'EOH_TC':
                return {'status': 'timeout', 'capture_complete': False, 'raw': ''}
            return capture(slot)
        ledger = run_fake(runner, response)
    result = audit(ledger)
    for name, data in [('ledger', ledger), ('independent_audit', result), ('summary', ledger['summary'])]:
        (args.output / (name + '.json')).write_text(json.dumps(data, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
    print(json.dumps({'scenario': args.scenario, 'audit_passed': result['passed'], **ledger['summary']}, indent=2))
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
