"""Strict textual extraction and receiver-side CLI export verification.

This defines a NEW bounded export protocol, not an official CLI implementation.
Authenticity/durability must come from the receiver's independently trusted store.
No ast.parse, eval, compile, rewriting, code repair, or candidate invocation.
"""
import re
from common import (MAX_EXPORT, MAX_RAW, MAX_SOURCE, decode_bytes, digest,
                    require, sha, strict_json, verify_seal)

TERMINALS = {'ok', 'timeout', 'transport_failure', 'cli_failure', 'cancelled'}


def extract(capture):
    raw = capture.get('raw')
    result = {'raw_sha256': None,
              'strict': False, 'unique': False, 'reason': None, 'candidate': None}
    if type(raw) is not str or len(raw) > MAX_RAW or len(raw.encode()) > MAX_RAW:
        result['reason'] = 'raw_byte_bound'
        return result
    result['raw_sha256'] = sha(raw.encode())
    if capture.get('status') != 'ok':
        result['reason'] = capture.get('status', 'transport_failure')
        return result
    if capture.get('capture_complete') is not True:
        result['reason'] = 'capture_incomplete'
        return result
    if capture.get('tool_calls'):
        result['reason'] = 'tool_call'
        return result
    if capture.get('finish_reason') not in ('stop', 'length'):
        result['reason'] = 'unknown_finish_reason'
        return result
    if raw.count('```') != 2:
        result['reason'] = 'nonunique_code_block'
        return result
    # Anchoring rejects all extraneous outside text. Public text may not contain
    # nested braces. The captured source bytes are neither stripped nor appended.
    match = re.fullmatch(r'\s*\{([^{}]+)\}\s*```python\r?\n(.*?)```\s*', raw, re.DOTALL)
    if match is None or not match.group(1).strip():
        result['reason'] = 'strict_response_format'
        return result
    description, code = match.group(1).strip(), match.group(2)
    if not code.endswith('\n'):
        result['reason'] = 'incomplete_code_block'
        return result
    if not code or len(code.encode()) > MAX_SOURCE:
        result['reason'] = 'source_byte_bound'
        return result
    candidate = {'description': description, 'code': code,
                 'description_sha256': sha(description.encode()),
                 'code_sha256': sha(code.encode()),
                 'pair_sha256': digest({'description': description, 'code': code}),
                 'description_consistency': 'undetermined'}
    result.update(strict=True, unique=True, candidate=candidate)
    return result


def import_capture(artifact, receiver_sha256, claim, freeze):
    """Validate bytes received through a trusted external receipt/transfer channel.

    The receiver digest must be recorded outside the candidate/CLI artifact itself.
    Providing a hash from the same untrusted file would not authenticate it.
    """
    verify_seal(claim)
    verify_seal(freeze)
    require(type(artifact) is bytes and len(artifact) <= MAX_EXPORT, 'export_byte_bound')
    require(sha(artifact) == receiver_sha256, 'receiver_artifact_hash')
    env = strict_json(artifact)
    require(type(env) is dict and set(env) == {'schema', 'claim_id', 'slot_id', 'request_sha256',
            'configuration_sha256', 'cli', 'terminal', 'raw_b64', 'raw_sha256'}, 'export_fields')
    require(env['schema'] == 'bounded-official-cli-export-v1', 'export_schema')
    require(env['claim_id'] == claim['claim_id'] and env['slot_id'] == claim['slot_id'], 'claim_binding')
    require(env['request_sha256'] == claim['request_sha256'], 'request_hash')
    require(env['configuration_sha256'] == digest(freeze['configuration']), 'configuration_hash')
    cli = env['cli']
    require(type(cli) is dict and set(cli) == {'binary_sha256', 'source_sha256', 'version',
            'mode', 'session_id', 'effective_configuration'}, 'cli_fields')
    require(cli['mode'] == freeze['mode'], 'cli_mode')
    require(cli['binary_sha256'] == freeze['cli_binary_sha256'] and
            cli['source_sha256'] == freeze['cli_source_sha256'] and
            cli['version'] == freeze['cli_version'], 'cli_provenance')
    require(cli['session_id'] == claim['claim_id'], 'fresh_session_binding')
    require(cli['effective_configuration'] == freeze['configuration'], 'effective_configuration')
    terminal = env['terminal']
    require(type(terminal) is dict and set(terminal) == {'status', 'capture_complete', 'finish_reason',
            'tool_calls', 'usage', 'physical_http_attempts', 'exit_code', 'process_terminal'}, 'terminal_fields')
    require(terminal['status'] in TERMINALS and terminal['process_terminal'] is True, 'terminal_status')
    require(type(terminal['capture_complete']) is bool and type(terminal['tool_calls']) is list, 'terminal_types')
    require(type(terminal['exit_code']) is int or terminal['exit_code'] is None, 'exit_code_type')
    attempts = terminal['physical_http_attempts']
    require(attempts is None or type(attempts) is int and attempts >= 1, 'attempt_count')
    require(terminal['status'] != 'ok' or terminal['exit_code'] == 0, 'success_exit_code')
    require(type(terminal['usage']) is dict and set(terminal['usage']) == {
        'input_tokens', 'output_tokens', 'reasoning_tokens', 'wall_seconds'}, 'usage_fields')
    for key, value in terminal['usage'].items():
        require(value is None or (type(value) in (int, float) and value >= 0), 'usage_value')
        if key != 'wall_seconds':
            require(value is None or type(value) is int, 'usage_token_type')
    raw = decode_bytes(env['raw_b64'], MAX_RAW)
    require(sha(raw) == env['raw_sha256'], 'raw_hash')
    text = raw.decode('utf-8', errors='strict')
    return dict(terminal, raw=text, receiver_artifact_sha256=receiver_sha256,
                cli_provenance=cli, claim_id=claim['claim_id'])
