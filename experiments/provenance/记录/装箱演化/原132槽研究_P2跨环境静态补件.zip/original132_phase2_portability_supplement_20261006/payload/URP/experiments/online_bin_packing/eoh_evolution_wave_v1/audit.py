"""Independent numerical/scheduling replay. Never imports Runner or parses code.

Authenticates no provider or kernel: the trust root remains external receipts.
Uses separate Fraction ranking, pool-local dedup and SHA-counter parent draws.
"""
from copy import deepcopy
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
from common import digest, verify_seal
from capture import extract, import_capture
from receipts import verify_bundle
from contracts import generation_config

BASE = Path(__file__).resolve().parent.parent


def ratio(value):
    return Fraction(value['numerator'], value['denominator'])


def rational(value):
    return {'numerator': value.numerator, 'denominator': value.denominator}


def draw(population, count, seed, slot_id):
    m = len(population)
    weights = [Fraction(1, rank + m) for rank in range(1, m + 1)]
    den = math.lcm(*(value.denominator for value in weights))
    integers = [int(value * den) for value in weights]
    total = sum(integers)
    limit = (2**256 // total)*total
    counter, ids, tickets = 0, [], []
    domain = f'parent-v1|{seed}|{slot_id}'
    before = digest([domain, 0])
    while len(ids) < count:
        value = int(hashlib.sha256(f'{domain}|{counter}'.encode()).hexdigest(), 16)
        counter += 1
        if value >= limit:
            continue
        ticket = value % total
        tickets.append(ticket)
        boundary = 0
        for candidate, weight in zip(population, integers):
            boundary += weight
            if ticket < boundary:
                ids.append(candidate['id'])
                break
    return {'ids': ids, 'distinct_count': len(set(ids)),
            'multiplicities': {x: ids.count(x) for x in sorted(set(ids))},
            'weights': [rational(w) for w in weights], 'integer_weights': integers,
            'replacement': True, 'tickets': tickets, 'rng_algorithm': 'sha256-counter-rejection-v1',
            'rng_state_before_sha256': before, 'rng_state_after_sha256': digest([domain, counter]),
            'rng_counter_after': counter}


def audit(ledger, external_snapshot, freeze):
    errors = []

    def check(condition, reason):
        if not condition:
            errors.append(reason)

    try:
        verify_seal(ledger)
        verify_seal(external_snapshot)
        verify_seal(freeze)
        fixed = json.loads((BASE / 'eoh_evolution_runner_v1/generation_slots.json').read_text())['records']
        score_plan = json.loads((BASE / 'eoh_evolution_runner_v1/score_slots.json').read_text())['records']
        spec = json.loads((BASE / 'eoh_evolution_runner_v1/scheduler_spec.json').read_text())
        check(ledger['spec'] == spec, 'pinned_spec')
        check(freeze['configuration'] == generation_config(), 'frozen_configuration')
        slots = ledger['generation']
        check(len(slots) == 132 and len(ledger['scores']) == 780, 'fixed_denominators')
        check([s['id'] for s in slots] == [s['id'] for s in fixed], 'fixed_slot_order')
        check([s['id'] for s in ledger['scores']] == [s['id'] for s in score_plan], 'fixed_score_order')
        for row, plan in zip(ledger['scores'], score_plan):
            for key in ('id', 'phase', 'policy', 'source_generation_slot', 'split', 'instance_index'):
                check(row[key] == plan[key], 'fixed_score_metadata:' + row['id'] + ':' + key)
        by_id = {s['id']: s for s in slots}
        archive = {c['id']: c for c in ledger['archive']}
        check(len(archive) == len(ledger['archive']), 'unique_archive_ids')
        for slot, plan in zip(slots, fixed):
            for key in ('id', 'order', 'block', 'arm', 'phase', 'operator', 'paired_stage_operator', 'parent_draws', 'parent_snapshot'):
                check(slot[key] == plan[key], 'fixed_slot:' + slot['id'] + ':' + key)
            priority = hashlib.sha256(f"tie-v1|{spec['seeds']['ties']}|{slot['id']}".encode()).hexdigest()
            check(slot['tie_priority'] == priority, 'tie:' + slot['id'])
        claims, terminal_hashes, verified_hashes, verification_started = {}, {}, {}, set()
        previous = None
        for index, event in enumerate(external_snapshot['events']):
            body = verify_seal(event)
            check(body['index'] == index and body['previous_sha256'] == previous, 'external_event_chain')
            previous = event['sha256']
            kind, value = body['kind'], body['value']
            if kind == 'claim':
                verify_seal(value)
                check(value['claim_id'] not in claims, 'duplicate_claim_id')
                check(value['slot_id'] not in [v['slot_id'] for v in claims.values()], 'duplicate_slot_claim')
                claims[value['claim_id']] = value
            elif kind == 'terminal':
                cid = value['claim_id']
                check(cid in claims and cid not in terminal_hashes, 'terminal_without_unique_claim')
                terminal_hashes[cid] = value['artifact_sha256']
            elif kind == 'begin_verification':
                check(value in terminal_hashes and value not in verification_started, 'verification_before_terminal_or_duplicate')
                verification_started.add(value)
            elif kind == 'verified':
                cid = value['claim_id']
                check(cid in verification_started and cid not in verified_hashes, 'verified_before_start_or_duplicate')
                verified_hashes[cid] = value['result_sha256']
            else:
                check(False, 'unknown_external_event')
        records = external_snapshot['records']
        check(len(records) == len(claims), 'external_record_count')
        check([r['claim']['slot_id'] for r in records] == [s['id'] for s in slots if s['logical_requests_observed']], 'external_claim_order')
        admitted, expected_archive, results_by_slot = {}, set(), {}
        for record in records:
            claim = record['claim']; cid = claim['claim_id']; sid = claim['slot_id']
            check(claim == claims[cid], 'claim_event_binding')
            slot = by_id[sid]
            check(claim['phase'] == slot['phase'] and claim['freeze_sha256'] == freeze['sha256'], 'claim_phase_freeze')
            check(cid == digest(['wave-claim-v1', claim['run_id'], sid]), 'deterministic_claim_id')
            # Independently reconstruct the complete public transfer pack. No
            # dataset path or bytes can enter this exact field projection.
            source_lock = json.loads((Path(__file__).resolve().parent / 'dependency_lock.json').read_text())
            pack = {'schema': 'wave-prompt-pack-v1', 'run_id': claim['run_id'], 'slot_id': sid,
                    'phase': slot['phase'], 'arm': slot['arm'], 'operator': slot['operator'],
                    'prompt': slot['prompt'], 'prompt_sha256': slot['prompt_sha256'],
                    'configuration': freeze['configuration'], 'configuration_sha256': digest(freeze['configuration']),
                    'freeze_sha256': freeze['sha256'], 'source_dependency_hashes': source_lock,
                    'parent_snapshot_sha256': slot['parent_snapshot_sha256'], 'parents': slot['parents'],
                    'parent_pair_hashes': [p['pair_sha256'] for p in slot['parent_provenance']],
                    'contains_data_bytes': False, 'mode': freeze['mode']}
            check(digest(pack) == claim['request_sha256'], 'claim_prompt_pack_binding')
            check(record['state'] == 'verified', 'unresolved_external_claim:' + sid)
            if record['state'] != 'verified':
                continue
            check(digest(record['terminal']) == terminal_hashes[cid], 'terminal_event_binding')
            result = record['result']
            results_by_slot[sid] = result
            check(digest(result) == verified_hashes[cid], 'verified_event_binding')
            check(by_id[sid]['capture'] == result['capture'], 'capture_binding:' + sid)
            if result['integrity_error']:
                check(by_id[sid]['state'] == 'integrity_failed', 'integrity_failure_state')
                continue
            captured = import_capture(bytes.fromhex(record['terminal']['artifact_hex']), record['terminal']['receiver_sha256'], claim, freeze)
            check(captured == result['capture'], 'receiver_replay')
            extracted = extract(captured)
            scores = []
            if extracted['unique']:
                candidate, scores = verify_bundle(result['bundle'], extracted['candidate'], claim, ledger['panel'], freeze)
                if candidate is None:
                    extracted.update(unique=False, reason='admission_' + result['bundle']['admission']['kind'], candidate=None)
                else:
                    extracted['candidate'] = candidate
            check(extracted == result['extraction'] and scores == result['scores'], 'receipt_replay:' + sid)
            check(by_id[sid]['extraction'] == {k:v for k,v in extracted.items() if k != 'candidate'}, 'extraction_binding')
            if not extracted['unique']:
                check(by_id[sid]['state'] == 'generation_failed' and sid not in archive, 'unadmitted_archive')
                continue
            cand = archive[sid]
            expected_archive.add(sid)
            for key in ('id', 'arm', 'phase', 'order', 'tie_priority', 'parents'):
                check(cand[key] == by_id[sid][key], 'archive_slot_metadata:' + sid + ':' + key)
            for key, value in extracted['candidate'].items():
                check(cand[key] == value, 'candidate_binding:' + sid + ':' + key)
            rows = [r for r in ledger['scores'] if r['source_generation_slot'] == sid]
            check(len(rows) == 5, 'five_potential_rows')
            for row in rows:
                receipt = next((s for s in scores if s['instance_index'] == row['instance_index']), None)
                check(row['evidence'] == receipt, 'score_evidence_binding')
                if receipt:
                    check(row['used_bins'] == receipt['used_bins'] and row['L1'] == receipt['L1'], 'score_value_binding')
                    expected_state = 'verified' if receipt['outcome'] == 'ok' else 'not_run' if receipt['outcome'] == 'not_run' else 'failed'
                    check(row['state'] == expected_state and row['reason'] == (None if receipt['outcome'] == 'ok' else receipt['outcome']), 'score_state_reason')
                else:
                    check(row['state'] == 'not_run' and row['used_bins'] is None and row['reason'] == 'missing_verified_observation', 'missing_score_state')
            complete = len(scores) == 5 and all(s['outcome'] == 'ok' for s in scores)
            check(cand['eligible'] == complete, 'eligibility:' + sid)
            if complete:
                f = sum((Fraction(s['L1'], s['used_bins']) for s in scores), Fraction()) / 5
                q = 100*Fraction(sum(s['used_bins'] - s['L1'] for s in scores), sum(s['L1'] for s in scores))
                check(cand['fitness'] == rational(f), 'exact_fitness:' + sid)
                check(cand['report_gap'] == rational(q), 'report_gap:' + sid)
                admitted[sid] = cand
                check(by_id[sid]['state'] == 'eligible', 'eligible_state')
            else:
                check(cand['fitness'] is None and by_id[sid]['state'] == 'evaluation_failed', 'failed_score_state')
        check(set(archive) == expected_archive, 'exact_archive_id_set')
        for row in ledger['scores']:
            sid = row['source_generation_slot']
            if row['policy'] != 'candidate':
                check(row['state'] == 'not_run' and row['reason'] == 'out_of_scope_no_execution_adapter'
                      and row['evidence'] is None and row['used_bins'] is None and row['L1'] is None,
                      'no_control_or_confirmation_execution')
            elif by_id[sid]['state'] in ('generation_failed', 'integrity_failed'):
                reason = 'integrity_failure' if by_id[sid]['state'] == 'integrity_failed' else 'generation_' + str(by_id[sid]['reason'])
                check(row['state'] == 'not_run' and row['evidence'] is None and row['used_bins'] is None
                      and row['reason'] == reason, 'failed_generation_score_rows')
            elif by_id[sid]['state'] in ('planned', 'dispatched', 'not_run'):
                reason = by_id[sid]['reason'] if by_id[sid]['state'] == 'not_run' else 'awaiting_candidate'
                check(row['state'] == 'not_run' and row['evidence'] is None and row['used_bins'] is None
                      and row['L1'] is None and row['code_hash'] is None and row['runtime_hash'] is None
                      and row['reason'] == reason, 'unexecuted_candidate_score_rows')
            check(row['no_cross_slot_cache'] is True, 'no_cross_slot_cache_flag')
        snapshots = {(s['phase'], s['arm']): s for s in ledger['snapshots']}
        check(len(snapshots) == len(ledger['snapshots']), 'duplicate_snapshot')
        completed = [phase for phase in range(3) if all(slot['state'] in
                     ('eligible', 'generation_failed', 'evaluation_failed', 'integrity_failed', 'not_run')
                     for slot in slots if slot['phase'] <= phase)]
        expected_snapshots = {(phase, arm) for phase in completed for arm in ('EOH_TC', 'IID_TC')}
        check(set(snapshots) == expected_snapshots, 'complete_snapshot_set')
        populations = {}
        for phase in range(3):
            for arm in ('EOH_TC', 'IID_TC'):
                if (phase, arm) not in snapshots:
                    continue
                snap = snapshots[(phase, arm)]
                verify_seal(snap)
                old = populations.get((phase-1, arm), []) if arm == 'EOH_TC' else []
                current = [c for c in admitted.values() if c['arm'] == arm and
                           (c['phase'] == phase if arm == 'EOH_TC' else c['phase'] <= phase)]
                pool = old + current
                unique, duplicates = {}, {}
                for cand in sorted(pool, key=lambda c: c['order']):
                    if cand['joint_identity'] in unique:
                        duplicates[cand['id']] = unique[cand['joint_identity']]['id']
                    else:
                        unique[cand['joint_identity']] = cand
                ranked = sorted(unique.values(), key=lambda c: (-ratio(c['fitness']), c['tie_priority'], c['id']))
                survivors = ranked[:6 if arm == 'EOH_TC' else 1]
                populations[(phase, arm)] = survivors
                check(snap['survivor_ids'] == [c['id'] for c in survivors], 'selection_snapshot')
                check(snap['decisions']['duplicates'] == duplicates, 'pool_local_duplicates')
                check(snap['decisions']['ranked_ids'] == [c['id'] for c in ranked], 'ranking')
                check(snap['population_size'] == len(survivors), 'population_size')
                check(snap['decisions']['eligible_ids'] == [c['id'] for c in sorted(pool, key=lambda c:c['order'])], 'selection_eligible_ids')
                expected_reasons = {c['id']: ('exact_joint_duplicate' if c['id'] in duplicates else
                    'retained' if c in survivors else 'outside_capacity') for c in pool}
                check(snap['decisions']['reasons'] == expected_reasons, 'selection_reasons')
                members = [{key:deepcopy(c[key]) for key in ('id', 'pair_sha256', 'code_identity',
                    'joint_identity', 'fitness', 'report_gap', 'tie_priority', 'initial_lineages')} for c in survivors]
                check(snap['members'] == members, 'snapshot_member_binding')
                check(snap['underfilled'] == (len(survivors) < (6 if arm == 'EOH_TC' else 1)), 'snapshot_underfilled')
                check(snap['distinct_code_count'] == len({c['code_identity'] for c in survivors}), 'snapshot_code_count')
                check(snap['active_initial_lineages'] == sorted({line for c in survivors for line in c['initial_lineages']}), 'snapshot_lineages')
                failed = [{'id':slot['id'], 'state':slot['state'], 'reason':slot['reason']} for slot in slots
                          if slot['phase'] == phase and slot['arm'] == arm and slot['state'] != 'eligible']
                check(snap['failed_offspring'] == failed, 'snapshot_failed_offspring')
        iid_prompt = None
        for slot in slots:
            if not slot['logical_requests_observed']:
                continue
            check(slot['prompt_sha256'] == digest(slot['prompt']), 'prompt_hash')
            if slot['arm'] == 'IID_TC':
                if iid_prompt is None:
                    iid_prompt = slot['prompt']
                check(slot['prompt'] == iid_prompt, 'iid_identical_prompt')
            if slot['parent_draws']:
                pop = populations[(slot['phase']-1, 'EOH_TC')]
                replay = draw(pop, slot['parent_draws'], spec['seeds']['parents'], slot['id'])
                check(slot['parent_draw'] == replay and slot['parents'] == replay['ids'], 'parent_draw')
                check(slot['parent_snapshot_sha256'] == snapshots[(slot['phase']-1, 'EOH_TC')]['sha256'], 'parent_snapshot_binding')
            if slot['id'] in archive:
                expected_lineage = [slot['id']] if slot['phase'] == 0 or slot['arm'] == 'IID_TC' else sorted({
                    line for pid in slot['parents'] for line in archive[pid]['initial_lineages']})
                check(archive[slot['id']]['initial_lineages'] == expected_lineage, 'lineage')
        previous, state, dispatched, halted = None, {}, 0, False
        for index, event in enumerate(ledger['events']):
            body = verify_seal(event)
            check(body['index'] == index and body['previous_sha256'] == previous, 'scheduler_event_chain')
            previous = event['sha256']; kind = body['kind']; payload = body['payload']
            if kind == 'dispatch':
                sid = payload['id']; phase = by_id[sid]['phase']
                check(not halted and sid not in state, 'no_retry_or_dispatch_after_halt')
                for key, value in payload.items():
                    check(by_id[sid].get(key) == value, 'dispatch_event_binding:' + key)
                check(all(state.get(s['id']) == 'terminal' for s in slots if s['phase'] < phase), 'generation_barrier')
                state[sid] = 'dispatched'; dispatched += 1
            elif kind == 'observe':
                sid = payload['id']
                check(state.get(sid) == 'dispatched', 'observation_unique_dispatch')
                result = results_by_slot[sid]
                bundle = result['bundle']
                expected_observation = {'id': sid, 'capture': result['capture'], 'extraction': result['extraction'],
                    'verified_scores': result['scores'], 'admission': bundle.get('admission') if type(bundle) is dict else None,
                    'integrity_error': result['integrity_error']}
                check(payload == expected_observation, 'observe_event_external_binding')
                state[sid] = 'terminal'
            elif kind == 'skip':
                state[payload['id']] = 'terminal'
            elif kind == 'halt':
                halted = True
                for slot in slots:
                    if slot['id'] not in state:
                        state[slot['id']] = 'terminal'
            else:
                check(kind == 'init' and index == 0, 'event_kind')
                if kind == 'init':
                    check(payload['panel'] == ledger['panel'] and payload['budget'] == ledger['budget']
                          and payload['spec_sha256'] == digest(spec), 'init_binding')
        check(dispatched == ledger['reserved']['logical_requests'] == len(records), 'request_denominator')
        check(ledger['reserved']['completion_tokens'] == dispatched*32000 and
              ledger['reserved']['generation_wall_seconds'] == dispatched*900, 'reservation_arithmetic')
        budget = ledger['budget']
        check(dispatched <= budget['logical_requests'] and dispatched*32000 <= budget['completion_tokens'] and
              (not dispatched or dispatched*900 + budget['finalization_wall_reserve'] <= budget['generation_wall_seconds']), 'reservation_budget_limit')
        terminal_states = ('eligible', 'generation_failed', 'evaluation_failed', 'integrity_failed', 'not_run')
        for slot in slots:
            check((slot['state'] in terminal_states) == (state.get(slot['id']) == 'terminal'), 'final_event_slot_state:' + slot['id'])
            check(type(slot['logical_requests_observed']) is int and slot['logical_requests_observed'] ==
                  int(any(r['claim']['slot_id'] == slot['id'] for r in records)), 'slot_request_count')
        check(ledger['summary']['terminal'] == all(s['state'] in terminal_states for s in slots), 'terminal_summary')
        summary = ledger['summary']
        check(summary['verified_score_records'] == sum(r['state'] == 'verified' for r in ledger['scores']), 'verified_score_summary')
        check(summary['scheduler_request_records'] == len(records), 'scheduler_request_summary')
        check(summary['planned_generation_slots'] == 132 and summary['planned_scoring_rows'] == 780, 'planned_summary_denominators')
        for arm in ('EOH_TC', 'IID_TC'):
            check(summary['generation_counts_by_arm'][arm] == sum(s['logical_requests_observed'] for s in slots if s['arm'] == arm), 'arm_request_summary')
        for arm in ('EOH_TC', 'IID_TC'):
            pop = populations.get((2, arm))
            if pop is not None:
                check(ledger['summary']['winners'][arm] == (pop[0]['id'] if pop else None), 'winner_binding')
        check(ledger['summary']['actual_provider_calls'] == 0 and ledger['summary']['candidate_executions'] == 0,
              'mock_execution_claim')
    except Exception as exc:
        errors.append(type(exc).__name__ + ':' + str(exc))
    return {'passed': not errors, 'errors': errors, 'scope': 'mock external receipt and independent schedule replay; no authenticity or runtime certificate'}
