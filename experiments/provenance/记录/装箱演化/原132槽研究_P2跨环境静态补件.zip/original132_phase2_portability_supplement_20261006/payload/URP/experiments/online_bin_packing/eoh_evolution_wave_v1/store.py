"""External compare-and-set journal interface plus IN-MEMORY TEST implementation.

A deployment must supply an independently durable, authenticated store. This
mock is deliberately non-durable and must never authorize model dispatch.
"""
from copy import deepcopy
from common import digest, require, seal, sha, verify_seal


class NeedsResolution(RuntimeError):
    pass


class ExternalStore:
    """Required operations are atomic, write-once, and read-after-write verified.

    claim(record): global CAS on claim_id AND slot_id; fails on either duplicate.
    terminal(claim_id, bytes, receiver_hash): durable exact raw bytes before parse.
    begin_verification(claim_id): durable CAS before any admission/scoring action.
    verified(claim_id, result): immutable complete receipt, including failures.
    read_all(): ordered, authenticated records; ambiguous reads stop all dispatch.
    """
    durable_external = False


class MockExternalStore(ExternalStore):
    def __init__(self):
        self.records = []
        self.events = []
        self.quarantined_bytes = {}
        self.unresolved_verifier_outputs = {}

    def _entry(self, claim_id):
        return next(entry for entry in self.records if entry['claim']['claim_id'] == claim_id)

    def _event(self, kind, value):
        self.events.append(seal({'index': len(self.events), 'kind': kind, 'value': deepcopy(value),
                                 'previous_sha256': self.events[-1]['sha256'] if self.events else None}))

    def claim(self, record):
        verify_seal(record)
        require(not any(x['claim']['claim_id'] == record['claim_id'] or
                        x['claim']['slot_id'] == record['slot_id'] for x in self.records), 'duplicate_external_claim')
        self.records.append({'claim': deepcopy(record), 'state': 'claimed', 'terminal': None, 'result': None})
        self._event('claim', record)
        return deepcopy(self._entry(record['claim_id']))

    def terminal(self, claim_id, artifact, receiver_hash):
        row = self._entry(claim_id)
        require(row['state'] == 'claimed', 'terminal_already_recorded')
        require(type(artifact) is bytes, 'terminal_artifact_type')
        row.update(state='terminal', terminal={'artifact_hex': artifact.hex(), 'receiver_sha256': receiver_hash})
        self._event('terminal', {'claim_id': claim_id, 'artifact_sha256': digest(row['terminal'])})
        return deepcopy(row)

    def begin_verification(self, claim_id):
        row = self._entry(claim_id)
        require(row['state'] == 'terminal', 'verification_already_claimed')
        row['state'] = 'verification_claimed'
        self._event('begin_verification', claim_id)
        return deepcopy(row)

    def quarantine(self, claim_id, artifact, receiver_hash):
        """Mock raw retention by immutable bytes reference, without hex expansion.

        Production transport must stream oversized raw to external quarantine and
        provide a bounded authenticated reference; no such transport exists here.
        """
        row = self._entry(claim_id)
        require(row['state'] == 'claimed' and type(artifact) is bytes, 'quarantine_state')
        self.quarantined_bytes[claim_id] = artifact
        row.update(state='terminal', terminal={'quarantine': True, 'byte_length': len(artifact),
            'artifact_sha256': sha(artifact), 'receiver_sha256': receiver_hash,
            'raw_retention': 'MOCK_BYTE_REFERENCE_NOT_DURABLE'})
        self._event('terminal', {'claim_id': claim_id, 'artifact_sha256': digest(row['terminal'])})
        return deepcopy(row)

    def retain_unresolved_verifier_output(self, claim_id, output):
        # Not a receipt or success state. Keep the object for test diagnostics
        # without recursion/copying; the outstanding claim still stops recovery.
        self.unresolved_verifier_outputs[claim_id] = output

    def verified(self, claim_id, result):
        row = self._entry(claim_id)
        require(row['state'] == 'verification_claimed', 'verification_state')
        row.update(state='verified', result=deepcopy(result))
        self._event('verified', {'claim_id': claim_id, 'result_sha256': digest(result)})
        return deepcopy(row)

    def read_all(self):
        return deepcopy(self.records)

    def snapshot(self):
        return seal({'schema': 'MOCK_EXTERNAL_STORE_NOT_DURABLE', 'records': self.read_all(), 'events': deepcopy(self.events)})
