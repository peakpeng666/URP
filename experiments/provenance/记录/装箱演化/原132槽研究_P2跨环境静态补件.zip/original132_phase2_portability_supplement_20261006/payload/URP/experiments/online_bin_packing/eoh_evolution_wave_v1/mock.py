"""Fabricated transport/admission/numeric records. Zero API or source execution."""
import base64
from common import canonical, digest, seal, sha


def panel():
    return {'kind': 'mock', 'name': 'FAKE_NUMBERS_NO_DATA_READ_OR_EXECUTION',
            'instances': [{'instance_index': i, 'input_sha256': digest(['fake_input', i]),
                           'n': 5000, 'capacity': 100, 'L1': 100 + 20*i} for i in range(5)]}


def export(prepared, freeze, *, raw=None, status='ok', finish_reason='stop', complete=True,
           tool_calls=None, exit_code=0):
    claim, pack = prepared['claim'], prepared['pack']
    if raw is None:
        raw = '{Mock strategy ' + pack['slot_id'] + '.}\n```python\ndef score(item, bins):\n    return bins - item\n```'
    encoded = raw.encode() if isinstance(raw, str) else raw
    value = {'schema': 'bounded-official-cli-export-v1', 'claim_id': claim['claim_id'],
        'slot_id': claim['slot_id'], 'request_sha256': pack['sha256'],
        'configuration_sha256': digest(freeze['configuration']),
        'cli': {'binary_sha256': freeze['cli_binary_sha256'], 'source_sha256': freeze['cli_source_sha256'],
            'version': freeze['cli_version'], 'mode': freeze['mode'], 'session_id': claim['claim_id'],
            'effective_configuration': freeze['configuration']},
        'terminal': {'status': status, 'capture_complete': complete, 'finish_reason': finish_reason,
            'tool_calls': tool_calls or [], 'usage': {'input_tokens': None, 'output_tokens': None,
                'reasoning_tokens': None, 'wall_seconds': None}, 'physical_http_attempts': None,
            'exit_code': exit_code, 'process_terminal': True},
        'raw_b64': base64.b64encode(encoded).decode(), 'raw_sha256': sha(encoded)}
    artifact = canonical(value).encode()
    return artifact, sha(artifact)


class MockBackend:
    def __init__(self, *, rejection=None, failure=None, canonical_text=None):
        self.rejection, self.failure, self.canonical_text = rejection, failure, canonical_text
        self.calls = []

    def verify(self, candidate, claim, panel, freeze):
        self.calls.append(claim['claim_id'])
        text = self.canonical_text or candidate['code']
        admission = {'admitted': not bool(self.rejection), 'source_sha256': candidate['code_sha256'],
                     'bounded_child_verified': True, 'runtime_sha256': freeze['runtime_sha256'],
                     'isolation_profile_sha256': freeze['isolation_profile_sha256'], 'cleanup_status': 'passed',
                     'notice': 'FABRICATED; no child, AST parsing, compilation or execution occurred'}
        identity = {'method': 'mock-canonical-text-v1', 'canonical_text': text,
                    'code_identity': sha(text.encode()), 'joint_identity': digest([candidate['description'].strip(), text])}
        scores = []
        if self.rejection:
            admission['kind'] = self.rejection
            identity = None
        else:
            for inst in panel['instances']:
                idx = inst['instance_index']
                scores.append({'kind': 'mock', 'instance_index': idx, 'input_sha256': inst['input_sha256'],
                    'code_sha256': candidate['code_sha256'], 'outcome': self.failure or 'ok',
                    'used_bins': None if self.failure else inst['L1'] + 30 - 8*claim['phase'], 'L1': inst['L1'],
                    'evidence': {'slot_id': claim['slot_id'], 'claim_id': claim['claim_id'],
                        'execution_id': f"{claim['claim_id']}/instance/{idx}",
                        'intake_manifest_sha256': freeze['intake_manifest_sha256'], 'no_cross_slot_cache': True,
                        'runtime_sha256': freeze['runtime_sha256'],
                        'isolation_profile_sha256': freeze['isolation_profile_sha256'],
                        'checker_sha256': freeze['checker_sha256'], 'cleanup_status': 'passed',
                        'checker_status': 'not_run' if self.failure else 'passed',
                        'assignment_sha256': None if self.failure else digest(['fake_assignment', claim['claim_id'], idx]),
                        'notice': 'FABRICATED_TEST_RECEIPT_NO_NUMERICAL_EXECUTION'}})
        return seal({'schema': 'wave-bounded-verification-v1', 'mode': freeze['mode'],
                     'claim_id': claim['claim_id'], 'slot_id': claim['slot_id'],
                     'source_sha256': candidate['code_sha256'], 'description_sha256': candidate['description_sha256'],
                     'freeze_sha256': freeze['sha256'], 'intake_manifest_sha256': freeze['intake_manifest_sha256'],
                     'admission': admission, 'identity': identity, 'scores': scores})
