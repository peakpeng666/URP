"""12/60/60 wave integration. Only mocks are enabled in this implementation."""
from copy import deepcopy
from pathlib import Path
import json
import re
from capture import extract, import_capture
from common import MAX_EXPORT, bound_value, digest, require, seal, sha, verify_seal
from contracts import generation_config
from dependencies import verify_dependencies
from receipts import verify_bundle
from safe_scheduler import SafeRunner
from store import NeedsResolution


def preflight(freeze, store):
    verify_seal(freeze)
    verify_dependencies()
    if freeze.get('mode') != 'mock_only':
        raise RuntimeError('LIVE_BLOCKED: reviewed generated intake, bounded exporter, external store and runtime gates unresolved')
    require(freeze.get('live_launch_ready') is False, 'mock_cannot_claim_live_ready')
    require(freeze.get('configuration') == generation_config(), 'configuration_not_frozen_32k_900s')


class WaveAdapter:
    def __init__(self, panel, freeze, store, backend, *, run_id='mock-wave-v1', **budget):
        preflight(freeze, store)
        require(panel.get('kind') == 'mock', 'only_mock_panel_enabled')
        require(type(run_id) is str and re.fullmatch('[A-Za-z0-9_-]{1,80}', run_id), 'run_id')
        self.panel, self.freeze = deepcopy(panel), deepcopy(freeze)
        self.store, self.backend, self.run_id, self.budget = store, backend, run_id, budget
        self.runner = SafeRunner(panel, **budget)
        self.issued, self.dispatch_attempted = set(), set()
        self.blocked = False
        self.recovery_known_integrity = False
        self.packs = {}

    def _make_pack(self, request):
        configuration = self.freeze['configuration']
        body = {'schema': 'wave-prompt-pack-v1', 'run_id': self.run_id, 'slot_id': request['id'],
                'phase': request['phase'], 'arm': request['arm'], 'operator': request['operator'],
                'prompt': request['prompt'], 'prompt_sha256': request['prompt_sha256'],
                'configuration': configuration, 'configuration_sha256': digest(configuration),
                'freeze_sha256': self.freeze['sha256'], 'source_dependency_hashes': verify_dependencies(),
                'parent_snapshot_sha256': request['parent_snapshot_sha256'],
                'parents': request['parents'], 'parent_pair_hashes': [p['pair_sha256'] for p in request['parent_provenance']],
                'contains_data_bytes': False, 'mode': self.freeze['mode']}
        return seal(body)

    def _claim(self, pack):
        return seal({'schema': 'wave-external-claim-v1', 'run_id': self.run_id,
                     'claim_id': digest(['wave-claim-v1', self.run_id, pack['slot_id']]),
                     'slot_id': pack['slot_id'], 'phase': pack['phase'],
                     'request_sha256': pack['sha256'], 'freeze_sha256': self.freeze['sha256']})

    def _guard(self):
        if self.blocked:
            raise NeedsResolution('adapter stopped after unknown or uncommitted external state')
        for entry in self.store.read_all():
            require(entry['claim']['run_id'] == self.run_id and
                    entry['claim']['freeze_sha256'] == self.freeze['sha256'], 'external_store_namespace')
            if entry['state'] not in ('claimed', 'terminal', 'verification_claimed', 'verified'):
                raise NeedsResolution('unknown external record state')
            if entry['state'] == 'verification_claimed':
                raise NeedsResolution('verification began without durable result; resolve, never rerun')
            if entry['state'] == 'claimed' and entry['claim']['claim_id'] not in self.issued:
                raise NeedsResolution('existing claim has unknown dispatch outcome; resolve, never rerun')

    def prepare_next(self):
        self._guard()
        request = self.runner.next_request()
        if request is None:
            return None
        pack = self._make_pack(request)
        claim = self._claim(pack)
        try:
            committed = self.store.claim(claim)
            require(committed['claim'] == claim and committed['state'] == 'claimed', 'claim_readback')
        except Exception:
            self.blocked = True
            raise
        # No transport may see a pack before the external claim is confirmed.
        self.issued.add(claim['claim_id'])
        self.packs[claim['claim_id']] = deepcopy(pack)
        return {'claim': claim, 'pack': pack}

    def prepare_wave(self):
        """Build only the current generation. Caller cannot cross its terminal barrier."""
        phase = self.runner._phase
        out = []
        while self.runner._phase == phase:
            prepared = self.prepare_next()
            if prepared is None:
                break
            out.append(prepared)
        return out

    def dispatch_mock(self, prepared, transport):
        """Exercise ordering with a fake callback. This is never a live CLI launcher."""
        self._guard()
        require(self.runner._halt_reason is None, 'dispatch_after_integrity_halt')
        claim_id = prepared['claim']['claim_id']
        require(claim_id in self.issued and claim_id not in self.dispatch_attempted, 'no_duplicate_dispatch')
        row = next(x for x in self.store.read_all() if x['claim']['claim_id'] == claim_id)
        require(row['state'] == 'claimed' and row['claim'] == prepared['claim'], 'durable_claim_before_dispatch')
        require(prepared['pack'] == self.packs[claim_id], 'dispatch_pack_mutation')
        self.dispatch_attempted.add(claim_id)
        try:
            artifact, receiver_hash = transport(prepared)
        except Exception as exc:
            self.blocked = True
            raise NeedsResolution('unknown dispatch outcome; preserve claim and reconcile external terminal') from exc
        return self.accept(claim_id, artifact, receiver_hash)

    def accept(self, claim_id, artifact, receiver_hash):
        """Import one terminal. Invalid bytes are retained, then halt all new work."""
        prior = next(entry for entry in self.store.read_all() if entry['claim']['claim_id'] == claim_id)
        require(prior['state'] == 'claimed', 'terminal_already_recorded')
        require(prior['claim']['run_id'] == self.run_id and
                prior['claim']['freeze_sha256'] == self.freeze['sha256'], 'terminal_wrong_run')
        require(type(artifact) is bytes, 'terminal_artifact_type')
        try:
            if len(artifact) > MAX_EXPORT:
                row = self.store.quarantine(claim_id, artifact, receiver_hash)
                require(row['terminal']['byte_length'] == len(artifact) and row['terminal']['artifact_sha256'] == sha(artifact), 'quarantine_readback')
            else:
                row = self.store.terminal(claim_id, artifact, receiver_hash)
                require(row['terminal']['artifact_hex'] == artifact.hex() and row['state'] == 'terminal', 'terminal_readback')
        except Exception as exc:
            self.blocked = True
            raise NeedsResolution('terminal commit uncertain; reconcile external raw record before continuing') from exc
        if self.blocked:
            raise NeedsResolution('terminal preserved; reconcile prior unknown state before any verification')
        return self._process_terminal(row)

    def _process_terminal(self, row):
        claim = row['claim']
        claim_id = claim['claim_id']
        try:
            begun = self.store.begin_verification(claim_id)
            require(begun['state'] == 'verification_claimed', 'verification_claim_readback')
        except Exception as exc:
            self.blocked = True
            raise NeedsResolution('verification reservation uncertain; stop and reconcile') from exc
        quarantined = row['terminal'].get('quarantine') is True
        artifact = b'' if quarantined else bytes.fromhex(row['terminal']['artifact_hex'])
        extraction = {'raw_sha256': None, 'strict': False, 'unique': False,
                      'reason': 'capture_import_failure', 'candidate': None}
        capture = {'status': 'capture_import_failure', 'raw': '',
                   'retained_artifact_sha256': row['terminal']['artifact_sha256'] if quarantined else sha(artifact), 'claim_id': claim_id}
        bundle, scores, integrity_error = None, [], None
        try:
            require(not quarantined, 'export_byte_bound_quarantined')
            capture = import_capture(artifact, row['terminal']['receiver_sha256'], claim, self.freeze)
            extraction = extract(capture)
        except (ValueError, KeyError, TypeError, UnicodeError) as exc:
            integrity_error = 'capture_import:' + str(exc)
        if integrity_error is None and self.runner._halt_reason is not None:
            integrity_error = 'halted_before_admission:' + self.runner._halt_reason
        if integrity_error is None and self.recovery_known_integrity:
            integrity_error = 'halted_before_admission:prior_external_integrity_failure'
        if integrity_error is None and extraction['unique']:
            try:
                bundle = self.backend.verify(deepcopy(extraction['candidate']), deepcopy(claim),
                    deepcopy(self.panel), deepcopy(self.freeze))
            except Exception as exc:
                # The callback may have consumed execution resources before failure.
                # Do NOT turn this into an invitation to rerun admission or scoring.
                self.blocked = True
                raise NeedsResolution('verification outcome unknown; external claim remains unresolved') from exc
            try:
                bound_value(bundle)
            except (ValueError, UnicodeError) as exc:
                self.store.retain_unresolved_verifier_output(claim_id, bundle)
                self.blocked = True
                raise NeedsResolution('unbounded verifier output retained outside ledger; resolve without rerun') from exc
            try:
                candidate, scores = verify_bundle(bundle, extraction['candidate'], claim, self.panel, self.freeze)
                if candidate is None:
                    extraction.update(unique=False, reason='admission_' + bundle['admission']['kind'], candidate=None)
                else:
                    extraction['candidate'] = candidate
            except (ValueError, KeyError, TypeError) as exc:
                integrity_error = 'verification:' + str(exc)
                scores = []
        result = {'capture': capture, 'extraction': extraction, 'bundle': bundle,
                  'scores': scores, 'integrity_error': integrity_error}
        try:
            committed = self.store.verified(claim_id, result)
            require(committed['result'] == result and committed['state'] == 'verified', 'verified_readback')
        except Exception as exc:
            self.blocked = True
            raise NeedsResolution('verification result commit uncertain; stop and reconcile') from exc
        self._apply(claim, result)
        return deepcopy(result)

    def _apply(self, claim, result):
        bundle = result.get('bundle')
        admission = bundle.get('admission') if type(bundle) is dict else None
        try:
            self.runner.observe_verified(claim['slot_id'], result['capture'], result['extraction'],
                result['scores'], admission, result['integrity_error'])
        except Exception as exc:
            self.blocked = True
            raise NeedsResolution('durable result could not advance scheduler; reconcile without callback rerun') from exc

    def checkpoint(self):
        return seal({'schema': 'wave-checkpoint-v1', 'run_id': self.run_id, 'freeze': self.freeze,
                     'panel': self.panel, 'budget': self.budget,
                     'external_records_sha256': digest(self.store.read_all()),
                     'ledger': self.runner.export()})

    def save_checkpoint(self, path):
        path = Path(path)
        temporary = path.with_suffix(path.suffix + '.tmp')
        temporary.write_text(json.dumps(self.checkpoint(), ensure_ascii=False, indent=2) + '\n')
        temporary.replace(path)

    @classmethod
    def resume(cls, checkpoint, store, backend):
        """Rebuild from external claims, not a mutable serialized Python object.

        A stale checkpoint is acceptable only as configuration. The authoritative
        journal is independently verified and replayed without re-dispatching.
        Claimed/verification-claimed entries stop rather than retry.
        """
        verify_seal(checkpoint)
        obj = cls(checkpoint['panel'], checkpoint['freeze'], store, backend,
                  run_id=checkpoint['run_id'], **checkpoint['budget'])
        records = store.read_all()
        # Resolve every ambiguous reservation before recovering even the first
        # terminal-only record; otherwise recovery itself could consume new
        # numerical work before discovering a later unknown state.
        prescan_claims, prescan_slots = set(), set()
        for row in records:
            claim = row['claim']
            verify_seal(claim)
            require(claim['run_id'] == obj.run_id and claim['freeze_sha256'] == obj.freeze['sha256'], 'resume_namespace')
            require(type(claim['phase']) is int and claim['phase'] in (0, 1, 2), 'resume_phase')
            require(claim['claim_id'] not in prescan_claims and claim['slot_id'] not in prescan_slots, 'duplicate_resume_claim')
            prescan_claims.add(claim['claim_id']); prescan_slots.add(claim['slot_id'])
            if row['state'] in ('claimed', 'verification_claimed'):
                raise NeedsResolution('unresolved ' + row['state'] + ':' + claim['claim_id'])
            require(row['state'] in ('terminal', 'verified'), 'unknown_resume_state')
            if row['state'] == 'verified' and row['result'].get('integrity_error'):
                obj.recovery_known_integrity = True
        seen, slots = set(), set()
        phase_claims = []
        # Stage all claims for a wave before observations, reproducing wave packs.
        for phase in range(3):
            stage = [row for row in records if row['claim']['phase'] == phase]
            for row in stage:
                claim = row['claim']
                verify_seal(claim)
                require(claim['claim_id'] not in seen and claim['slot_id'] not in slots, 'duplicate_resume_claim')
                seen.add(claim['claim_id']); slots.add(claim['slot_id'])
                request = obj.runner.next_request()
                require(request is not None, 'claim_after_terminal_or_wrong_wave')
                pack = obj._make_pack(request)
                require(obj._claim(pack) == claim, 'resume_claim_request_mismatch')
                obj.packs[claim['claim_id']] = pack
                phase_claims.append((claim, row))
            for claim, row in phase_claims:
                if claim['phase'] != phase:
                    continue
                if row['state'] in ('claimed', 'verification_claimed'):
                    raise NeedsResolution('unresolved ' + row['state'] + ':' + claim['claim_id'])
                require(row['state'] in ('terminal', 'verified'), 'unknown_resume_state')
                if row['state'] == 'terminal':
                    obj._process_terminal(row)
                else:
                    result = row['result']
                    # Validate imported bytes and successful receipts again; no
                    # callback or numerical execution occurs during receipt replay.
                    if result['integrity_error'] is None:
                        capture = import_capture(bytes.fromhex(row['terminal']['artifact_hex']),
                            row['terminal']['receiver_sha256'], claim, obj.freeze)
                        require(capture == result['capture'], 'resume_capture_binding')
                        extracted = extract(capture)
                        if extracted['unique']:
                            candidate, scores = verify_bundle(result['bundle'], extracted['candidate'], claim, obj.panel, obj.freeze)
                            if candidate is None:
                                extracted.update(unique=False, reason='admission_' + result['bundle']['admission']['kind'], candidate=None)
                            else:
                                extracted['candidate'] = candidate
                            require(scores == result['scores'], 'resume_score_binding')
                        require(extracted == result['extraction'], 'resume_extraction_binding')
                    obj._apply(claim, result)
        require(len(seen) == len(records), 'unknown_claim_phase')
        return obj
