"""Independent replay auditor: does NOT call Runner, metrics, select or draw_parents.

Extraction and prompt formatting are shared stateless format definitions; identities,
fitness, ranks, ties, duplicates, parent RNG, budgets and event ordering are recomputed.
This detects inconsistencies/tampering, not authenticity against a party able to
replace the whole input log and all its trusted source observations.
"""
import ast
from copy import deepcopy
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
from core import assemble_prompt, canonical, digest, parse_capture, text_hash

ROOT = Path(__file__).resolve().parent


def audit(ledger):
    errors = []

    def check(condition, message):
        if not condition:
            errors.append(message)

    try:
        obj = deepcopy(ledger)
        root_hash = obj.pop('sha256')
        check(digest(obj) == root_hash, 'ledger digest')
        spec = json.loads((ROOT / 'scheduler_spec.json').read_text())
        check(ledger['spec'] == spec, 'pinned scheduler spec')
        generation = ledger['generation']
        expected = json.loads((ROOT / 'generation_slots.json').read_text())['records']
        score_plan = json.loads((ROOT / 'score_slots.json').read_text())['records']
        check(len(generation) == 132 and len(ledger['scores']) == 780, 'complete planned row counts')
        check([s['id'] for s in generation] == [s['id'] for s in expected], 'generation plan/order')
        check([r['id'] for r in ledger['scores']] == [r['id'] for r in score_plan], 'score plan/order')
        slot_map = {s['id']: s for s in generation}
        for s, p in zip(generation, expected):
            for key in ('order', 'id', 'block', 'arm', 'phase', 'operator', 'paired_stage_operator',
                        'parent_snapshot', 'parent_draws'):
                check(s[key] == p[key], f'fixed slot field {s["id"]}:{key}')
            priority = hashlib.sha256(f'tie-v1|{spec["seeds"]["ties"]}|{s["id"]}'.encode()).hexdigest()
            check(s['tie_priority'] == priority, 'preassigned tie ' + s['id'])
        check(ledger['mode'] == ('mock_only' if ledger['panel']['kind'] == 'mock' else 'external_records_only'), 'provenance mode')
        initial_generation = deepcopy(expected)
        for row in initial_generation:
            row.update(state='planned', reason=None,
                tie_priority=text_hash(f'tie-v1|{spec["seeds"]["ties"]}|{row["id"]}'),
                capture=None, extraction=None, parent_draw=None, parent_snapshot_sha256=None,
                parent_provenance=[], prompt=None, configured=None, observed=None, physical_http_attempts=None)
        initial_scores = deepcopy(score_plan)
        for row in initial_scores:
            row.update(state='not_run', reason='awaiting_candidate' if row['policy'] == 'candidate'
                else 'out_of_scope_no_execution_adapter', used_bins=None, L1=None,
                evidence=None, no_cross_slot_cache=True)
        check(bool(ledger['events']) and ledger['events'][0]['kind'] == 'init', 'required init event')
        states = {s['id']: 'planned' for s in expected}
        observations, dispatches, skips = {}, {}, {}
        previous, halt, dispatched = None, None, 0
        for i, raw_event in enumerate(ledger['events']):
            event = deepcopy(raw_event)
            checksum = event.pop('sha256')
            check(event['index'] == i and event['previous_sha256'] == previous, f'event chain order {i}')
            check(digest(event) == checksum, f'event digest {i}')
            previous = checksum
            kind, p = event['kind'], event['payload']
            if kind == 'init':
                check(i == 0 and p['panel'] == ledger['panel'] and p['budget'] == ledger['budget'], 'init binding')
                check(p['spec_sha256'] == digest(spec), 'init spec hash')
                check(p['generation_plan_sha256'] == digest(initial_generation), 'init generation plan hash')
                check(p['score_plan_sha256'] == digest(initial_scores), 'init score plan hash')
            elif kind == 'dispatch':
                sid = p['id']
                check(halt is None and states[sid] == 'planned', 'dispatch after halt/retry ' + sid)
                pending = [s for s in expected if states[s['id']] == 'planned']
                check(bool(pending) and pending[0]['id'] == sid, 'planned dispatch order ' + sid)
                phase = slot_map[sid]['phase']
                check(all(states[s['id']] in ('terminal', 'skipped') for s in expected if s['phase'] < phase),
                      'generation barrier ' + sid)
                states[sid] = 'dispatched'
                dispatches[sid] = p
                dispatched += 1
                b, cap = ledger['budget'], spec['generation_config_proposal']
                check(dispatched <= b['logical_requests'] and dispatched * cap['max_completion_tokens'] <= b['completion_tokens']
                      and dispatched * cap['wall_seconds'] + b['finalization_wall_reserve'] <= b['generation_wall_seconds'],
                      'full request reservation ' + sid)
            elif kind == 'observe':
                sid = p['id']
                check(states[sid] == 'dispatched', 'observation without unique dispatch ' + sid)
                states[sid] = 'terminal'
                observations[sid] = p
            elif kind == 'skip':
                sid = p['id']
                check(states[sid] == 'planned' and p['reason'] == 'parent_unavailable', 'invalid skip ' + sid)
                states[sid] = 'skipped'
                skips[sid] = p['reason']
            elif kind == 'halt':
                check(halt is None, 'multiple halts')
                halt = p['reason']
                for sid in states:
                    if states[sid] == 'planned':
                        states[sid] = 'skipped'
            else:
                check(False, 'unknown event ' + kind)
        check(len(dispatches) == ledger['reserved']['logical_requests'], 'logical reservation total')
        check(ledger['reserved']['completion_tokens'] == dispatched * 32000, 'completion reservation total')
        check(ledger['reserved']['generation_wall_seconds'] == dispatched * 900, 'wall reservation total')
        check(ledger['summary']['halt_reason'] == halt, 'halt summary')

        candidates = {}
        score_map = {r['id']: r for r in ledger['scores']}
        for sid, event in observations.items():
            slot, capture = slot_map[sid], event['capture']
            check(slot['capture'] == capture, 'raw capture binding ' + sid)
            expected_usage = capture.get('usage', {'input_tokens': None, 'output_tokens': None,
                'reasoning_tokens': None, 'wall_seconds': None})
            check(slot['observed'] == expected_usage, 'observed usage binding ' + sid)
            check(slot['physical_http_attempts'] == capture.get('physical_http_attempts'), 'physical attempts binding ' + sid)
            extracted = parse_capture(capture)
            check(slot['extraction'] == {k: v for k, v in extracted.items() if k != 'candidate'}, 'admission ' + sid)
            expected_rows = [r for r in score_plan if r['source_generation_slot'] == sid]
            supplied = event['verified_scores']
            for row in expected_rows:
                stored = score_map[row['id']]
                item = next((r for r in supplied if isinstance(r, dict) and r.get('instance_index') == row['instance_index']), None)
                if stored['evidence'] is not None:
                    check(stored['evidence'] == item, 'score evidence binding ' + row['id'])
                    check(stored['used_bins'] == item['used_bins'] and stored['L1'] == item['L1'],
                          'score value binding ' + row['id'])
            if not extracted['unique']:
                check(slot['state'] in ('generation_failed', 'integrity_failed'), 'failed capture eligibility ' + sid)
                continue
            c = extracted['candidate']
            normalized = ast.dump(ast.parse(c['code']), annotate_fields=True, include_attributes=False)
            check(c['code_identity'] == text_hash(normalized), 'code AST identity ' + sid)
            check(c['joint_identity'] == digest([c['description'].strip(), normalized]), 'joint identity ' + sid)
            c.update(id=sid, arm=slot['arm'], phase=slot['phase'], order=slot['order'],
                     tie_priority=slot['tie_priority'], eligible=False, fitness=None, report_gap=None,
                     parents=slot['parents'], joint_duplicate_of=None, code_duplicate_of=None)
            complete = len(supplied) == 5 and all(isinstance(r, dict) for r in supplied) and {r.get('instance_index') for r in supplied} == set(range(5))
            valid = True
            ratios, bin_total, lower_total = [], 0, 0
            for r in supplied:
                if not isinstance(r, dict):
                    valid = False
                    continue
                idx = r.get('instance_index')
                if type(idx) is not int or not 0 <= idx < 5:
                    valid = False
                    continue
                instance, evidence = ledger['panel']['instances'][idx], r.get('evidence', {})
                if not isinstance(evidence, dict):
                    valid = False
                    continue
                valid &= (r.get('kind') == ledger['panel']['kind'] and r.get('code_sha256') == c['code_sha256']
                          and r.get('input_sha256') == instance['input_sha256'] and type(r.get('L1')) is int and r.get('L1') == instance['L1']
                          and evidence.get('cleanup_status') == 'passed')
                valid &= all(isinstance(evidence.get(k), str) and len(evidence[k]) == 64
                             and set(evidence[k]) <= set('0123456789abcdef')
                             for k in ('runtime_sha256', 'isolation_profile_sha256', 'checker_sha256'))
                bins = r.get('used_bins')
                if r.get('outcome') != 'ok':
                    complete = False
                    continue
                is_ok = (type(bins) is int and instance['L1'] <= bins <= instance['n']
                         and evidence.get('checker_status') == 'passed'
                         and isinstance(evidence.get('assignment_sha256'), str)
                         and len(evidence['assignment_sha256']) == 64
                         and set(evidence['assignment_sha256']) <= set('0123456789abcdef'))
                valid &= is_ok
                if is_ok:
                    ratios.append(Fraction(instance['L1'], bins))
                    bin_total += bins
                    lower_total += instance['L1']
            if complete and valid:
                f, q = sum(ratios, Fraction()) / 5, Fraction(100 * (bin_total - lower_total), lower_total)
                c.update(eligible=True, fitness={'numerator': f.numerator, 'denominator': f.denominator},
                         report_gap={'numerator': q.numerator, 'denominator': q.denominator})
                check(slot['state'] == 'eligible', 'complete panel eligibility ' + sid)
            else:
                check(slot['state'] in ('evaluation_failed', 'integrity_failed'), 'incomplete panel eligibility ' + sid)
            candidates[sid] = c
        # Lineages in phase/order order, not event completion order.
        seen_joint, seen_code = {}, {}
        for c in sorted(candidates.values(), key=lambda x: x['order']):
            c['initial_lineages'] = ([c['id']] if c['phase'] == 0 or c['arm'] == 'IID_TC' else
                                    sorted({x for p in c['parents'] for x in candidates[p]['initial_lineages']}))
            joint, code = (c['arm'], c['joint_identity']), (c['arm'], c['code_identity'])
            c['joint_duplicate_of'], c['code_duplicate_of'] = seen_joint.get(joint), seen_code.get(code)
            seen_joint.setdefault(joint, c['id'])
            seen_code.setdefault(code, c['id'])
        check(ledger['archive'] == sorted(candidates.values(), key=lambda c: c['order']), 'complete candidate archive replay')

        reconstructed = {}
        for phase in range(3):
            if not all(states[s['id']] in ('terminal', 'skipped') for s in expected if s['phase'] <= phase):
                break
            for arm in ('EOH_TC', 'IID_TC'):
                current = [s for s in generation if s['phase'] == phase and s['arm'] == arm]
                if arm == 'EOH_TC':
                    previous_pop = reconstructed[(arm, phase - 1)]['survivor_ids'] if phase else []
                    pool = [candidates[i] for i in previous_pop] + [candidates[s['id']] for s in current
                                                                         if s['state'] == 'eligible']
                    cap = 6
                else:
                    pool = [c for c in candidates.values() if c['arm'] == arm and c['phase'] <= phase and c['eligible']]
                    cap = 1
                representatives, dup = {}, {}
                for c in sorted(pool, key=lambda x: x['order']):
                    if c['joint_identity'] in representatives:
                        dup[c['id']] = representatives[c['joint_identity']]['id']
                    else:
                        representatives[c['joint_identity']] = c
                ranked = sorted(representatives.values(), key=lambda c:
                                (-Fraction(c['fitness']['numerator'], c['fitness']['denominator']),
                                 c['tie_priority'], c['id']))
                survivors = ranked[:cap]
                decisions = {'eligible_ids': [c['id'] for c in sorted(pool, key=lambda x: x['order'])],
                             'ranked_ids': [c['id'] for c in ranked], 'duplicates': dup,
                             'reasons': {c['id']: ('exact_joint_duplicate' if c['id'] in dup else
                                  'retained' if c in survivors else 'outside_capacity') for c in pool}}
                snap = {'name': f'P{phase}', 'arm': arm, 'phase': phase,
                        'survivor_ids': [c['id'] for c in survivors],
                        'members': [{k: c[k] for k in ('id', 'pair_sha256', 'code_identity', 'joint_identity',
                                                     'fitness', 'report_gap', 'tie_priority', 'initial_lineages')}
                                    for c in survivors], 'decisions': decisions,
                        'failed_offspring': [{'id': s['id'], 'state': s['state'], 'reason': s['reason']}
                                             for s in current if s['state'] != 'eligible'],
                        'population_size': len(survivors), 'underfilled': len(survivors) < cap,
                        'distinct_code_count': len({c['code_identity'] for c in survivors}),
                        'behavior_diversity': 'unknown_without_assignment_evidence',
                        'active_initial_lineages': sorted({x for c in survivors for x in c['initial_lineages']})}
                snap['sha256'] = digest(snap)
                reconstructed[(arm, phase)] = snap
        check(ledger['snapshots'] == list(reconstructed.values()), 'all snapshot selection replay')

        for sid, d in dispatches.items():
            slot = slot_map[sid]
            parents, draws, snap_hash = [], None, None
            if slot['parent_draws']:
                snap = reconstructed[('EOH_TC', slot['phase'] - 1)]
                snap_hash = snap['sha256']
                population = snap['survivor_ids']
                m = len(population)
                check(m > 0, 'dispatch without parents ' + sid)
                ws = [Fraction(1, m + r) for r in range(1, m + 1)]
                den = math.lcm(*(w.denominator for w in ws))
                weights = [int(w * den) for w in ws]
                total, counter, tickets, ids = sum(weights), 0, [], []
                domain = f'parent-v1|{spec["seeds"]["parents"]}|{sid}'
                while len(ids) < slot['parent_draws']:
                    value = int(hashlib.sha256(f'{domain}|{counter}'.encode()).hexdigest(), 16)
                    counter += 1
                    if value >= (2**256 // total) * total:
                        continue
                    ticket, acc = value % total, 0
                    tickets.append(ticket)
                    for pid, weight in zip(population, weights):
                        acc += weight
                        if ticket < acc:
                            ids.append(pid)
                            break
                draws = {'ids': ids, 'distinct_count': len(set(ids)),
                         'multiplicities': {p: ids.count(p) for p in sorted(set(ids))},
                         'weights': [{'numerator': w.numerator, 'denominator': w.denominator} for w in ws],
                         'integer_weights': weights, 'replacement': True, 'tickets': tickets,
                         'rng_algorithm': 'sha256-counter-rejection-v1',
                         'rng_state_before_sha256': digest([domain, 0]),
                         'rng_state_after_sha256': digest([domain, counter]), 'rng_counter_after': counter}
                parents = [candidates[i] for i in ids]
            prompt = assemble_prompt(slot['operator'], parents)
            provenance = [{k: p[k] for k in ('id', 'pair_sha256', 'description_sha256', 'code_sha256', 'fitness')}
                          for p in parents]
            computed = {'id': sid, 'prompt': prompt, 'prompt_sha256': digest(prompt), 'parent_draw': draws,
                        'parents': [p['id'] for p in parents], 'parent_snapshot_sha256': snap_hash,
                        'parent_provenance': provenance, 'configured': spec['generation_config_proposal']}
            check(d == computed, 'dispatch prompt/parent replay ' + sid)
            check(all(slot[k] == v for k, v in computed.items()), 'dispatch ledger binding ' + sid)
        for sid in skips:
            s = slot_map[sid]
            check(s['arm'] == 'EOH_TC' and s['phase'] > 0 and
                  not reconstructed[('EOH_TC', s['phase'] - 1)]['survivor_ids'], 'parent-unavailable justification ' + sid)
        for s in generation:
            check(s['logical_requests_observed'] == int(s['id'] in dispatches), 'dispatch accounting ' + s['id'])
            check((s['state'] == 'not_run') == (states[s['id']] == 'skipped'), 'not-run event binding ' + s['id'])
        for row in ledger['scores']:
            check(row['no_cross_slot_cache'] is True, 'cross-slot score cache')
            if row['policy'] != 'candidate':
                check(row['state'] == 'not_run' and row['used_bins'] is None
                      and row['reason'] == 'out_of_scope_no_execution_adapter', 'out-of-scope score executed')
        # Reconstruct every potential score row, including absent/rejected observations.
        # This prevents an attacker from deleting a receipt while retaining its score.
        rebuilt_rows = deepcopy(score_plan)
        for row in rebuilt_rows:
            row.update(state='not_run', reason='awaiting_candidate' if row['policy'] == 'candidate'
                       else 'out_of_scope_no_execution_adapter', used_bins=None, L1=None,
                       evidence=None, no_cross_slot_cache=True)
        for slot in generation:
            sid = slot['id']
            rows = [r for r in rebuilt_rows if r['source_generation_slot'] == sid]
            if states[sid] == 'skipped':
                reason = skips.get(sid, halt)
                check(slot['reason'] == reason, 'not-run reason ' + sid)
                for r in rows:
                    r['reason'] = reason
                continue
            if sid not in observations:
                continue
            event = observations[sid]
            ex = parse_capture(event['capture'])
            if not ex['unique']:
                for r in rows:
                    r['reason'] = 'generation_' + str(ex['reason'])
                continue
            supplied, c = event['verified_scores'], candidates[sid]
            indices = [r.get('instance_index') if isinstance(r, dict) else None for r in supplied]
            integrity = (any(type(i) is not int or not 0 <= i < 5 for i in indices)
                         or len(indices) != len(set(indices)))
            for obs in ([] if integrity else supplied):
                idx, evidence = obs['instance_index'], obs.get('evidence', {})
                if not isinstance(evidence, dict):
                    integrity = True
                    break
                inst = ledger['panel']['instances'][idx]
                is_hash = lambda v: isinstance(v, str) and len(v) == 64 and set(v) <= set('0123456789abcdef')
                bad = (obs.get('kind') != ledger['panel']['kind']
                       or obs.get('code_sha256') != c['code_sha256']
                       or obs.get('input_sha256') != inst['input_sha256'] or type(obs.get('L1')) is not int or obs.get('L1') != inst['L1']
                       or any(not is_hash(evidence.get(k)) for k in
                              ('runtime_sha256', 'isolation_profile_sha256', 'checker_sha256'))
                       or evidence.get('cleanup_status') != 'passed')
                if obs.get('outcome') == 'ok':
                    bins = obs.get('used_bins')
                    bad |= (evidence.get('checker_status') != 'passed'
                            or not is_hash(evidence.get('assignment_sha256'))
                            or type(bins) is not int or not inst['L1'] <= bins <= inst['n'])
                else:
                    bad |= (obs.get('outcome') not in ('numeric_failure', 'infeasible', 'timeout',
                            'resource_limit', 'exception', 'prohibited_capability', 'not_run')
                            or obs.get('used_bins') is not None)
                if bad:
                    integrity = True
                    break
                rows[idx].update(state='verified' if obs['outcome'] == 'ok' else 'not_run' if obs['outcome'] == 'not_run' else 'failed',
                         reason=None if obs['outcome'] == 'ok' else obs['outcome'],
                         used_bins=obs.get('used_bins'), L1=obs['L1'], code_hash=c['code_sha256'],
                         runtime_hash=evidence['runtime_sha256'], evidence=deepcopy(obs))
            for r in rows:
                if r['state'] == 'not_run' and r['evidence'] is None:
                    r['reason'] = 'integrity_failure' if integrity else 'missing_verified_observation'
            expected_state = ('integrity_failed' if integrity else 'eligible' if
                              all(r['state'] == 'verified' for r in rows) else 'evaluation_failed')
            check(slot['state'] == expected_state, 'terminal score state ' + sid)
        check(ledger['scores'] == rebuilt_rows, 'complete score ledger replay')
        for slot in generation:
            if states[slot['id']] in ('planned', 'dispatched'):
                check(slot['state'] == states[slot['id']], 'pending event state ' + slot['id'])
                check(slot['capture'] is None and slot['observed'] is None and slot['physical_http_attempts'] is None,
                      'pending observation fields ' + slot['id'])
        summary = ledger['summary']
        counts = {a: sum(s['logical_requests_observed'] for s in generation if s['arm'] == a)
                  for a in ('EOH_TC', 'IID_TC')}
        check(summary['planned_generation_slots'] == 132 and summary['planned_scoring_rows'] == 780, 'planned summary counts')
        remaining = [s['id'] for s in generation if states[s['id']] not in ('terminal', 'skipped')]
        check(summary['remaining_generation_slots'] == remaining, 'remaining slot summary')
        check(summary['terminal'] == (not remaining), 'terminal summary')
        lineage = sorted({p for s in generation if s['arm'] == 'EOH_TC' and s['phase'] == 2
                          for p in s['parents'] if candidates[p]['phase'] == 1})
        check(summary['actual_g1_to_g2_parent_ids'] == lineage, 'lineage summary')
        check(summary['generation_counts_by_arm'] == counts, 'arm count summary')
        check(summary['scheduler_request_records'] == dispatched, 'observed request summary')
        check(summary['equal_full_66_request_records'] == all(c == 66 for c in counts.values()), 'equal budget claim')
        check(summary['not_run_generation_slots'] == sum(s['state'] == 'not_run' for s in generation), 'not-run summary')
        check(summary['verified_score_records'] == sum(r['state'] == 'verified' for r in ledger['scores']), 'score summary')
        check(summary['actual_provider_calls'] == summary['candidate_executions'] == 0
              and ledger['native_execution_ready'] is False, 'execution scope')
        for arm in counts:
            final = reconstructed.get((arm, 2))
            expected_winner = final['survivor_ids'][0] if final and final['survivor_ids'] else None
            check(summary['winners'][arm] == expected_winner, 'winner replay ' + arm)
    except (KeyError, ValueError, TypeError, AttributeError, StopIteration, ZeroDivisionError, IndexError) as exc:
        errors.append(f'malformed ledger: {type(exc).__name__}: {exc}')
    return {'passed': not errors, 'errors': errors, 'independent_selection_replay': True,
            'shared_components': ['response extraction format', 'prompt serialization'],
            'real_model_requests': 0, 'generated_source_executions': 0}


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('ledger')
    args = parser.parse_args()
    result = audit(json.loads(Path(args.ledger).read_text()))
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result['passed'] else 1)
