"""External verifier contract. Mock records are explicitly NOT execution evidence."""
from copy import deepcopy
from common import MAX_AST_TEXT, bound_value, digest, is_hash, require, sha, verify_seal


def verify_bundle(bundle, candidate, claim, panel, freeze):
    bound_value(bundle)
    verify_seal(bundle)
    require(bundle.get('schema') == 'wave-bounded-verification-v1', 'verification_schema')
    require(bundle.get('mode') == freeze['mode'] == panel['kind'].replace('mock', 'mock_only'), 'verification_mode')
    require(bundle.get('claim_id') == claim['claim_id'] and bundle.get('slot_id') == claim['slot_id'], 'verification_claim')
    require(bundle.get('source_sha256') == candidate['code_sha256'] and
            bundle.get('description_sha256') == candidate['description_sha256'], 'verification_source')
    require(bundle.get('freeze_sha256') == freeze['sha256'], 'verification_freeze')
    require(bundle.get('intake_manifest_sha256') == freeze['intake_manifest_sha256'], 'candidate_intake_manifest')
    admission, scores = bundle.get('admission'), bundle.get('scores')
    require(type(admission) is dict and type(scores) is list, 'verification_fields')
    require(admission.get('source_sha256') == candidate['code_sha256'], 'admission_source')
    require(admission.get('admitted') is True or admission.get('admitted') is False, 'admission_boolean')
    require(admission.get('cleanup_status') == 'passed', 'admission_cleanup')
    require(admission.get('bounded_child_verified') is True, 'bounded_child_gate')
    require(admission.get('runtime_sha256') == freeze['runtime_sha256'] and
            admission.get('isolation_profile_sha256') == freeze['isolation_profile_sha256'], 'admission_runtime')
    if not admission['admitted']:
        require(admission.get('kind') in ('source_protocol', 'static', 'compile'), 'admission_failure_kind')
        require(not scores and bundle.get('identity') is None, 'unadmitted_scores_or_identity')
        return None, []
    identity = bundle.get('identity')
    require(type(identity) is dict, 'missing_child_identity')
    method = 'mock-canonical-text-v1' if freeze['mode'] == 'mock_only' else 'bounded-child-ast-dump-v1'
    require(identity.get('method') == method, 'identity_method')
    text = identity.get('canonical_text')
    require(type(text) is str and 0 < len(text.encode()) <= MAX_AST_TEXT, 'canonical_text_bound')
    # The parent hashes a child-produced canonical representation; it never parses
    # source or trusts a source-provided hash as a certificate of AST admission.
    out = deepcopy(candidate)
    out.update(code_identity=sha(text.encode()), joint_identity=digest([candidate['description'].strip(), text]))
    require(identity.get('code_identity') == out['code_identity'] and
            identity.get('joint_identity') == out['joint_identity'], 'canonical_identity_hash')
    require(len(scores) <= 5, 'score_count')
    indices, execution_ids = set(), set()
    for record in scores:
        require(type(record) is dict, 'score_type')
        idx = record.get('instance_index')
        require(type(idx) is int and 0 <= idx < 5 and idx not in indices, 'score_instance_index')
        indices.add(idx)
        expected = panel['instances'][idx]
        require(record.get('kind') == panel['kind'] and record.get('code_sha256') == candidate['code_sha256'], 'score_provenance')
        require(record.get('input_sha256') == expected['input_sha256'] and
                type(record.get('L1')) is int and record['L1'] == expected['L1'], 'score_panel_binding')
        ev = record.get('evidence')
        require(type(ev) is dict, 'score_evidence')
        require(ev.get('slot_id') == claim['slot_id'] and ev.get('claim_id') == claim['claim_id'], 'score_claim_binding')
        execution_id = ev.get('execution_id')
        require(execution_id == f"{claim['claim_id']}/instance/{idx}" and execution_id not in execution_ids, 'score_execution_binding')
        execution_ids.add(execution_id)
        require(ev.get('no_cross_slot_cache') is True and ev.get('intake_manifest_sha256') == freeze['intake_manifest_sha256'], 'score_intake_or_cache')
        for key in ('runtime_sha256', 'isolation_profile_sha256', 'checker_sha256'):
            require(is_hash(ev.get(key)) and ev[key] == freeze[key], 'score_' + key)
        require(ev.get('cleanup_status') == 'passed', 'score_cleanup')
        if record.get('outcome') == 'ok':
            require(type(record.get('used_bins')) is int and expected['L1'] <= record['used_bins'] <= expected['n'], 'score_bin_count')
            require(ev.get('checker_status') == 'passed' and is_hash(ev.get('assignment_sha256')), 'score_checker')
        else:
            require(record.get('outcome') in ('numeric_failure', 'infeasible', 'timeout', 'resource_limit',
                    'exception', 'prohibited_capability', 'not_run'), 'score_outcome')
            require(record.get('used_bins') is None, 'failure_invented_bins')
    return out, deepcopy(scores)
