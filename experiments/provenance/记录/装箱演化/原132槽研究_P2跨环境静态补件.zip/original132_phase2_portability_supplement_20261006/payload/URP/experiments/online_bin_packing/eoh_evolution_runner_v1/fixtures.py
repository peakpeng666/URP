"""Deliberately fabricated responses and observations, never performance evidence."""
from core import parse_capture, text_hash


def panel():
    return {'kind': 'mock', 'name': 'FAKE_NUMBERS_NOT_BIN_PACKING_EXECUTION',
            'instances': [{'instance_index': i, 'input_sha256': text_hash(f'mock-input-{i}'),
                           'n': 5000, 'capacity': 100, 'L1': 100 + 20 * i} for i in range(5)]}


def capture(slot, *, code=None, description=None):
    code = code or f'def score(item, bins):\n    return bins - item + {slot["order"]}\n'
    description = description or f'Fake fixture for planned candidate {slot["id"]}.'
    return {'status': 'ok', 'capture_complete': True, 'finish_reason': 'stop', 'tool_calls': [],
            'raw': '{' + description + '}\n```python\n' + code.rstrip() + '\n```',
            'usage': {'input_tokens': None, 'output_tokens': None, 'reasoning_tokens': None,
                      'wall_seconds': None}, 'physical_http_attempts': None}


def score_records(slot, response, manifest=None):
    manifest = manifest or panel()
    parsed = parse_capture(response)
    if not parsed['unique']:
        return []
    return [{'kind': manifest['kind'], 'instance_index': i['instance_index'],
             'input_sha256': i['input_sha256'], 'code_sha256': parsed['candidate']['code_sha256'],
             'outcome': 'ok', 'used_bins': i['L1'] + 30 - 8 * slot['phase'] + slot['order'] % 6,
             'L1': i['L1'], 'evidence': {
                 'runtime_sha256': text_hash('mock-no-runtime'),
                 'isolation_profile_sha256': text_hash('mock-no-isolation-certification'),
                 'checker_sha256': text_hash('mock-no-real-checker'),
                 'assignment_sha256': text_hash('mock-no-assignment:' + slot['id'] + str(i['instance_index'])),
                 'checker_status': 'passed', 'cleanup_status': 'passed',
                 'cpu_seconds': None, 'wall_seconds': None, 'max_rss_bytes': None,
                 'limits': None, 'notice': 'FABRICATED TEST RECEIPT; no source was executed'}}
            for i in manifest['instances']]


def run_fake(runner, response_fn=None):
    while not runner.done:
        slot = runner.next_request()
        if slot is None:
            if runner.done:
                break
            raise RuntimeError('fixture driver unexpectedly waiting for observations')
        response = response_fn(slot) if response_fn else capture(slot)
        runner.observe(slot['id'], response, score_records(slot, response))
    return runner.export()
