"""Supplement-only byte installation. No imports of experiment code or execution.

Default is a read-only plan. --apply requires separate parent approval in the
consumer environment. All sources/destinations are checked before first write.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import stat
import uuid


def need(test, message):
    if not test:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def canonical(path):
    p = Path(path)
    need(p.is_absolute() and '..' not in p.parts and p.resolve() == p
         and not any(q.is_symlink() for q in (p, *p.parents)), 'noncanonical or symlink path')
    return p


def directory_fd(path, create=False):
    """Walk from / using inode-relative O_NOFOLLOW opens, never a path follow."""
    p = Path(path)
    need(p.is_absolute() and '..' not in p.parts, 'absolute directory required')
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
    fd = os.open('/', flags)
    try:
        for component in p.parts[1:]:
            if create:
                try:
                    os.mkdir(component, dir_fd=fd)
                except FileExistsError:
                    pass
            child = os.open(component, flags, dir_fd=fd)
            os.close(fd); fd = child
        return fd
    except BaseException:
        os.close(fd)
        raise


def read_at(parent_fd, name):
    fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=parent_fd)
    try:
        info = os.fstat(fd)
        need(stat.S_ISREG(info.st_mode), 'regular file required')
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            return stream.read(), (info.st_dev, info.st_ino)
    finally:
        os.close(fd)


def final_identity(path, expected_inode):
    """A concurrent rename/replacement is unknown, never successful completion."""
    parent_fd = directory_fd(path.parent)
    try:
        raw, inode = read_at(parent_fd, path.name)
        need(inode == expected_inode, 'target path changed during publication; unknown')
        return raw
    finally:
        os.close(parent_fd)


def prepare(mapping, payload_root, import_root, *, test_mirror_root=None):
    """test_mirror_root is only a synthetic test injection, not a CLI option."""
    payload_root, import_root = canonical(payload_root), canonical(import_root)
    parent = canonical(mapping['parent_workspace_prefix'])
    need(str(parent).startswith('/workspace/'), 'parent mirror must stay inside /workspace')
    rows = []
    for item in mapping['files']:
        relative = Path(item['payload_path'])
        need(not relative.is_absolute() and '..' not in relative.parts, 'unsafe payload path')
        source = canonical(payload_root / relative)
        need(source.is_file() and sha(source) == item['file_sha256'], 'source missing or changed')
        if item['target_kind'] == 'import_root_relative':
            target_name = Path(item['target'])
            need(not target_name.is_absolute() and '..' not in target_name.parts, 'unsafe import target')
            target = canonical(import_root / target_name)
        else:
            need(item['target_kind'] == 'exact_parent_absolute_mirror', 'unknown target kind')
            target = canonical(item['target'])
            need(target.is_relative_to(parent), 'mirror outside pinned parent prefix')
            if test_mirror_root is not None:
                target = canonical(Path(test_mirror_root) / target.relative_to(parent))
        if target.exists():
            need(target.is_file() and sha(target) == item['file_sha256'], 'existing target differs; never overwrite')
        rows.append((source, target, item['file_sha256']))
    need(len({str(target) for _, target, _ in rows}) == len(rows), 'duplicate target')
    return rows


def apply(rows):
    copied = same = 0
    for source, target, digest in rows:
        canonical(source); canonical(target)
        source_fd = directory_fd(source.parent)
        try:
            raw, _ = read_at(source_fd, source.name)
        finally:
            os.close(source_fd)
        need(hashlib.sha256(raw).hexdigest() == digest, 'source changed since preflight')
        parent_fd = directory_fd(target.parent, create=True)
        temporary = '.mirror-pending-' + uuid.uuid4().hex
        made_temporary = False
        try:
            try:
                existing, inode = read_at(parent_fd, target.name)
            except FileNotFoundError:
                existing = None
            if existing is not None:
                need(hashlib.sha256(existing).hexdigest() == digest, 'target changed since preflight')
                need(hashlib.sha256(final_identity(target, inode)).hexdigest() == digest, 'target path changed')
                same += 1
                continue
            fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=parent_fd)
            made_temporary = True
            with os.fdopen(fd, 'wb') as out:
                out.write(raw); out.flush(); os.fsync(out.fileno())
                info = os.fstat(out.fileno()); inode = (info.st_dev, info.st_ino)
            os.link(temporary, target.name, src_dir_fd=parent_fd, dst_dir_fd=parent_fd, follow_symlinks=False)
            os.fsync(parent_fd)
            need(hashlib.sha256(final_identity(target, inode)).hexdigest() == digest, 'final mirror hash')
            copied += 1
        finally:
            if made_temporary:
                os.unlink(temporary, dir_fd=parent_fd)
                os.fsync(parent_fd)
            os.close(parent_fd)
    return {'copied': copied, 'already_identical': same, 'total': len(rows),
            'model_calls': 0, 'candidate_executions': 0, 'overwrites': 0}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--mapping', required=True)
    parser.add_argument('--mapping-sha256', required=True)
    parser.add_argument('--payload-root', required=True)
    parser.add_argument('--import-root', required=True)
    parser.add_argument('--apply', action='store_true')
    args = parser.parse_args()
    path = canonical(args.mapping)
    need(sha(path) == args.mapping_sha256, 'mapping not externally pinned')
    mapping = json.loads(path.read_bytes())
    need(mapping['schema'] == 'phase2-portability-supplement-v1'
         and mapping['generation_execution_granted'] is False
         and mapping['numeric_execution_granted'] is False, 'non-executing supplement required')
    rows = prepare(mapping, args.payload_root, args.import_root)
    result = apply(rows) if args.apply else {'dry_run': True, 'total': len(rows),
                  'would_copy': sum(not target.exists() for _, target, _ in rows),
                  'targets': [str(target) for _, target, _ in rows]}
    print(json.dumps(result, sort_keys=True))


if __name__ == '__main__':
    main()
