# P2 包外跨环境补件（仍禁用）

原 disabled bound 目录 177 文件和 SOURCE_INPUT_PLAN 456 pins 一律不改。

本包携带原 SOURCE_PINS 的 57 个依赖（其中 23 个未在原 456 计划内）以及 parent-boundary 引用的 7 份最终 P1 证据。所有文件仅按原路径和 SHA 复制，无新父代选择、重算、侧实验或候选执行。

## 真实生产需要什么

生产生成入口使用原 bound 177 包文件、456 source plan、原 producer/exporter，以及另行审过的 operational sidecar、scope supplement、activation。它不调用 phase2_binding.load_bound_package / validate_final_p1，不重新读取 P1 分数，也不需要绝对父证据路径参与每次生成。

57 原静态依赖和 7 个父绝对路径供保持原样的 R2 数值/历史校验入口使用。数值仍只由父原云端独立批准执行；此处携带材料不授予 producer 数值、输入重绑定或生成权限。

## 两种路径，均不改原 JSON

- 57 个依赖：放入现有 extracted 源根，保持相对路径。已存在且同 SHA 的文件只核验，无覆盖。
- 7 份 evidence：原 JSON 内绝对路径保持；可在 producer 的 /workspace/scratch/27470b7a9f17/ 精确创建同路径同字节镜像。不使用 symlink，不修改 resolver 或原代码。
- PATH_MAPPING.json 列出每一个目标和精确 SHA。所有 source 和既有 target 必须在第一次写入前验证。冲突或 symlink 即停。
- install_exact_mirrors.py 默认 dry run；只有父在 consumer 环境明确批准后才可加 --apply。它只作 byte copies，绝不 import 实验模块、启动 CLI 或运行候选。

## 调用模板

使用 consumer 实际绝对路径替换下方占位符，不改 payload 或 mapping：

```
python -I -B /ABS/SUPPLEMENT/install_exact_mirrors.py \
 --mapping /ABS/SUPPLEMENT/PATH_MAPPING.json \
 --mapping-sha256 6213277a24efe047973407d7214681ff2362b4289c7513559d2b64e34d4dae5b \
 --payload-root /ABS/SUPPLEMENT/payload \
 --import-root /workspace/original132-phase2-import-20261006-ba1y1szn/extracted
```

先保留真实 dry-run tool result。父批准后同命令添加 --apply，再独立逐 pin 检查。失败或未知时停并核实现有文件；不重新执行模型或写 Library。

七项测试仅在临时目录复制 trusted text，包含 no-write dry run、同字节幂等验证、损坏 payload、冲突 target、symlink、目录替换竞态和越界拒绝。没有执行任何真实 install。

R2安装器使用逐层 O_DIRECTORY|O_NOFOLLOW 目录FD，以及 dir_fd 相对 exclusive 创建、link、unlink、fsync；不以可替换路径执行发布。发布后重新核目标 inode，目录移动/替换报 unknown。没有声称对抗进程永久冻结文件系统名称；任何事后改变都需重新核 pin。
