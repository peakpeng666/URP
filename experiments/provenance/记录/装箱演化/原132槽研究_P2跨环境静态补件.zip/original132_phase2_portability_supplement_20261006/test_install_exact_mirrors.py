import copy
import importlib.util
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

spec=importlib.util.spec_from_file_location('mirror',Path(__file__).with_name('install_exact_mirrors.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)


class Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name);self.payload=self.root/'payload';self.payload.mkdir()
        self.imp=self.root/'import';self.mirror=self.root/'mirror'
        (self.payload/'a').write_bytes(b'trusted fixture a');(self.payload/'b').write_bytes(b'trusted fixture b')
        self.mapping={'parent_workspace_prefix':'/workspace/scratch/TEST_ONLY','files':[
            {'payload_path':'a','target_kind':'import_root_relative','target':'deps/a','file_sha256':m.sha(self.payload/'a')},
            {'payload_path':'b','target_kind':'exact_parent_absolute_mirror','target':'/workspace/scratch/TEST_ONLY/evidence/b','file_sha256':m.sha(self.payload/'b')}]}
    def plan(self):return m.prepare(self.mapping,self.payload,self.imp,test_mirror_root=self.mirror)
    def test_exact_copy_and_idempotent_equal_only(self):
        self.assertEqual(m.apply(self.plan())['copied'],2)
        self.assertEqual(m.apply(self.plan())['already_identical'],2)
    def test_dry_plan_no_writes(self):
        self.assertEqual(len(self.plan()),2);self.assertFalse(self.imp.exists());self.assertFalse(self.mirror.exists())
    def test_changed_source_fails_before_any_write(self):
        (self.payload/'b').write_bytes(b'tampered')
        with self.assertRaises(ValueError):self.plan()
        self.assertFalse(self.imp.exists())
    def test_conflicting_existing_target_never_overwritten(self):
        (self.imp/'deps').mkdir(parents=True);(self.imp/'deps/a').write_bytes(b'existing different')
        with self.assertRaises(ValueError):self.plan()
        self.assertEqual((self.imp/'deps/a').read_bytes(),b'existing different');self.assertFalse(self.mirror.exists())
    def test_symlink_parent_rejected(self):
        self.imp.symlink_to(self.payload,target_is_directory=True)
        with self.assertRaises(ValueError):self.plan()
    def test_target_outside_pinned_prefix_rejected(self):
        self.mapping['files'][1]['target']='/tmp/escape'
        with self.assertRaises(ValueError):self.plan()
    def test_parent_swap_after_directory_open_never_follows_link(self):
        rows=self.plan();outside=self.root/'outside';outside.mkdir()
        original=m.os.link;swapped=[]
        def attack(*args,**kwargs):
            if not swapped:
                (self.imp/'deps').rename(self.root/'moved-original-directory')
                (self.imp/'deps').symlink_to(outside,target_is_directory=True)
                swapped.append(True)
            return original(*args,**kwargs)
        with patch.object(m.os,'link',side_effect=attack):
            with self.assertRaises((OSError,ValueError)):m.apply(rows)
        self.assertEqual(swapped,[True]);self.assertFalse((outside/'a').exists())


if __name__=='__main__':unittest.main()
