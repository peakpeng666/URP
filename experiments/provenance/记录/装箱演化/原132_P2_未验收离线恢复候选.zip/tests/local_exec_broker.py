"""No shell, credentials or network. Only three exact fixture launcher routes."""
import sys,json,shlex,subprocess,re
from pathlib import Path
cfg=json.loads(Path(sys.argv[1]).read_bytes());root=Path(cfg['root']);R=Path(__file__).resolve().parents[1]
assert cfg['TEST_ONLY'] is True and root.is_relative_to(R/'fixtures')
a=json.load(sys.stdin);cmd=a['cmd'];stdin=''
m=re.search(r" <<'([A-Z_]+)'\n([^\n]*)\n\1$",cmd)
if m:stdin=m[2];cmd=cmd[:m.start()]
argv=shlex.split(cmd);assert argv[0]=='python3';argv[0]=cfg['python']
script=next(Path(p) for p in argv[1:] if p.startswith('/') and p.endswith('.py'))
allowed={R/'src/recovery_cli.py',root/'implementation/init_local_helper.py',root/'implementation/assemble_handoff.py'}
assert script in allowed,(script,allowed)
assert '--grant' in argv and Path(argv[argv.index('--grant')+1]).is_relative_to(root)
if script==R/'src/recovery_cli.py':assert '--offline-fixture' in argv
res=subprocess.run(argv,input=stdin,capture_output=True,text=True,env={'PATH':'/usr/bin:/bin','PYTHONDONTWRITEBYTECODE':'1'})
out={'exit_code':res.returncode,'output':res.stdout,'stderr':res.stderr,'TEST_ONLY':True}
log=root/'exec-roundtrips';n=len(list(log.glob('suffix-*.json')));(log/f'suffix-{n:03d}.json').write_text(json.dumps({'arguments':a,'result':out},ensure_ascii=False))
sys.stdout.write(json.dumps(out))
