'use strict';
const fs=require('fs'),path=require('path'),cp=require('child_process'),assert=require('assert/strict');
const R=path.resolve(__dirname,'..');
const {recoverSuffixOfflineFixture}=require('../src/suffix_bridge.js');
const config=JSON.parse(fs.readFileSync(process.argv[2],'utf8')),gtext=fs.readFileSync(config.grant_path,'utf8'),g=JSON.parse(gtext);
const sources={commit:fs.readFileSync(path.join(R,'references/init/library_commit_v2.js'),'utf8'),
  retention:fs.readFileSync(path.join(R,'references/retention/retain_library_replies.js'),'utf8'),
  adapter:fs.readFileSync(path.join(R,'references/init/init_exec_adapter.js'),'utf8')};
const calls={reads:0,index_creates:0,archive_creates:0,replacements:0};
const tools={
  offlineFixtureTransport:true,
  async exec_command(args){
    const p=cp.spawnSync(config.python,['-I','-B',path.join(__dirname,'local_exec_broker.py'),process.argv[2]],
      {input:JSON.stringify(args),encoding:'utf8',env:{PATH:'/usr/bin:/bin',PYTHONDONTWRITEBYTECODE:'1'}});
    assert.equal(p.status,0,p.stderr);const r=JSON.parse(p.stdout);if(r.exit_code)r.output+=r.stderr;return r;
  },
  async mcp__codex_apps__library_read(args){
    assert.ok([g.index.file_id,g.index.library_file_id].includes(args.read[0].ref_id));calls.reads++;
    return {isError:false,TEST_ONLY:true,structuredContent:{results:[{file_id:g.index.file_id,
      library_file_id:g.index.library_file_id,has_more:false,content:[fs.readFileSync(g.producer_workspace+'/index.initial.json','utf8')],version_id:null}]}};
  },
  async mcp__codex_apps__library_create_library_file(args){
    assert.deepEqual(args,{file:g.producer_workspace+'/archive.initial.zip',library_artifact_type:'other'});
    calls.archive_creates++;assert.equal(calls.archive_creates,1);
    if(g.TEST_archive_throw)throw Error('TEST_ONLY original archive throw');
    return {isError:false,TEST_ONLY:true,content:[],structuredContent:{status:'succeeded',operation:'create',
      library_file_id:'libfile_TEST_ONLY_archive',file_id:'file_TEST_ONLY_archive',file_name:'archive.initial.zip',
      current_version_number:0,xattrs:[]}};
  },
  async mcp__codex_apps__library_replace_library_file(){calls.replacements++;throw Error('fixture forbids replacement');},
  async apply_patch(){throw Error('unmeasured writer forbidden');}
};
async function main(){
 let result,error=null;try{result=await recoverSuffixOfflineFixture(tools,gtext,config.grant_sha256,config.grant_path,sources);}
 catch(e){error=String(e.stack||e);}
 const out={TEST_ONLY:true,calls,result,error,success:error===null};
 fs.writeFileSync(path.join(config.root,'bridge.actual-result.json'),JSON.stringify(out,null,2));
 process.stdout.write(JSON.stringify({fixture:config.root,success:out.success,calls,error:error?.slice(0,1600)})+'\n');
 if(error&&!g.TEST_budget_before_stage&&!g.TEST_archive_throw)process.exitCode=1;
}
main().catch(e=>{process.stderr.write(e.stack);process.exitCode=1;});
