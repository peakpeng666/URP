"""Actual pinned original local components; only Library replies are synthetic."""
import sys,subprocess,json,unittest,inspect,copy,shutil
from pathlib import Path
sys.path[:0]=[str(Path(__file__).resolve().parent),str(Path(__file__).resolve().parents[1]/'src')]
from real_fixture_support import setup_fixture,ROOT
from recovery_core import *
from gen_importer_v2 import load_handoff,ImportOnce
from production_generation_entry_v2 import ProductionEntry,LOCAL_FUNCTIONS,d
from types import SimpleNamespace
RESULTS=[]
def run_bridge(stage=None,budget=None,archive_throw=False):
    cp=setup_fixture(stage,budget,archive_throw);config=read(cp)
    node=shutil.which('node');need(node is not None,'Node.js prerequisite missing')
    p=subprocess.run([node,str(ROOT/'tests/test_real_bridge.js'),str(cp)],capture_output=True,text=True,
                     env={'PATH':'/usr/bin:/bin','PYTHONDONTWRITEBYTECODE':'1'})
    need(p.returncode==0,'actual bridge fixture failed: '+p.stdout+p.stderr)
    root=Path(config['root']);g=read(config['grant_path']);g['_grant_ref']=ref(config['grant_path'])
    out=read(root/'bridge.actual-result.json');return root,g,out
class OfflineAccountingSidecar(d.Sidecar):
    """Only authorization is fixture scoped; original begin/finish/invoke code runs."""
    def _check_sources(self):
        d.need(self.grant['TEST_ONLY'] is True and self.grant['generation_execution_granted'] is False
               and self.root.is_relative_to(ROOT/'fixtures'),'offline sidecar isolation')
        for p,h in self.grant['operational_source_files'].items():d.need(d.filehash(p)==h,'offline actual dependency drift')
def accounting_fixture(root):
    sc=OfflineAccountingSidecar.__new__(OfflineAccountingSidecar);sc.root=root/'producer/phase2-generation-accounting';sc.root.mkdir()
    sc.binding={'TEST_ONLY':True,'package_path':str(root/'empty-package'),'external_source_root':str(ROOT/'references/original_source'),
        'source_files':{},'external_source_files':{},'records':[{'slot_id':'TEST_ONLY_slot01','request_sha256':'1'*64}]}
    old=ROOT/'references/generation/production_generation_entry.py'
    operational={str(p):filehash(p) for p in (ROOT/'references/generation').glob('*.py')}
    operational.update({str(p):filehash(p) for p in (ROOT/'src').glob('*.py')})
    sc.grant={'TEST_ONLY':True,'generation_execution_granted':False,'producer_workspace':str(root/'producer'),
       'operational_source_files':operational,'inclusive_wall_supplement_file_sha256':d.INCLUSIVE_SUPPLEMENT_SHA,
       'local_call_targets':{k:{'path':str(old),'sha256':filehash(old),'function':f.__name__} for k,f in LOCAL_FUNCTIONS.items()}}
    sc.identity=d.sealed({'schema':'generation-sidecar-identity-v1','root':str(sc.root),'binding':sc.binding,
                           'grant_sha256':d.sha(d.canon(sc.grant))});d.publish_once(sc.root/'identity.json',sc.identity)
    return sc
class RealIntegration(unittest.TestCase):
    def test_actual_suffix_original_base_v2_and_real_sidecar_accounting(self):
        root,g,out=run_bridge();self.assertTrue(out['success']);self.assertEqual(out['calls'],{'reads':2,'index_creates':0,'archive_creates':1,'replacements':0})
        j=Path(g['original_journal_root']);r=Path(g['recovery_journal_root']);base=read(j/'INIT_RESOURCE_HANDOFF.json');h=read(r/'RECONCILED_HANDOFF.v2.json')
        self.assertEqual((len(base['measurements']),len(base['receipt_files'])),(14,16));self.assertEqual(len(h['measurements']),46)
        self.assertEqual(h['recovery_measurement_count'],32)
        self.assertTrue(all(m['measurement_status']=='known' and not m.get('TEST_ONLY') for m in h['measurements']))
        for n in range(13):
            v=read(j/f'helper-{n:02d}.receipt.json');self.assertEqual(v['outcome'],'confirmed');self.assertEqual(v['script_sha256'],read(j/f'helper-{n:02d}.intent.json')['script_sha256'])
        self.assertFalse((root/'producer/state/external-pending.json').exists())
        reference=ref(r/'RECONCILED_HANDOFF.v2.json');rows,digest=load_handoff(reference,g);self.assertEqual(rows,h['measurements'])
        entry=ProductionEntry.__new__(ProductionEntry);entry.sidecar=SimpleNamespace(grant={
            'reconciliation_grant_ref':g['_grant_ref'],'namespace_initialization_handoff':reference,'entry_initial_archive_receipt':h['archive_receipt']})
        self.assertEqual(entry.bootstrap_receipts(h['index_receipt'])[0],rows)
        with self.assertRaises(Exception):entry.bootstrap_receipts(h['index_receipt'])
        with self.assertRaisesRegex(Stop,'v1 downgrade'):load_handoff(ref(j/'INIT_RESOURCE_HANDOFF.json'),g)
        sc=accounting_fixture(root);token=sc.begin('init_final','initialization');state=sc.finish(token,local_receipts=rows)
        self.assertEqual(state['halt'],[]);self.assertEqual(state['done'][0]['result']['outcome'],'confirmed')
        self.assertEqual(len(state['done'][0]['result']['local_receipts']),46)
        expected_cpu,expected_wall=totals(rows)
        self.assertAlmostEqual(state['scopes']['init_final'][0]-state['process_CPU_checkpoints'][d.PROCESS],expected_cpu)
        self.assertAlmostEqual(state['scopes']['init_final'][1]-state['done'][0]['result']['sidecar_control_receipt']['local_inclusive_wall_seconds'],expected_wall)
        self.assertEqual(set(m['process'] for m in rows),set(state['process_CPU_checkpoints'])-{d.PROCESS})
        with self.assertRaises(d.Stop):sc.begin('init_final','initialization')
        # First original local callable must pass the unchanged path/hash gate.
        f=LOCAL_FUNCTIONS['reserve_next'];self.assertEqual(Path(inspect.getsourcefile(f)),ROOT/'references/generation/production_generation_entry.py')
        record=sc.binding['records'][0];sc.reserve_slot(record)
        class StopBeforeProducer(RuntimeError):pass
        class Entry:
            def _load(self):raise StopBeforeProducer('TEST_ONLY: stop before producer import/GEN')
        with self.assertRaises(StopBeforeProducer):sc.invoke_local(record['slot_id'],'reserve_next',f,Entry(),1)
        s=sc.status();self.assertEqual(s['done'][-1]['stage'],'reserve_next');self.assertEqual(s['done'][-1]['result']['evidence']['original_callable_source_sha256'],filehash(inspect.getsourcefile(f)))
        self.assertEqual(s['done'][-1]['result']['local_receipts'][0]['measurement_status'],'known')
        RESULTS.append({'case':'actual_success_and_real_sidecar','fixture':str(root),'base':{'measurements':14,'receipts':16},'delta_count':32,'combined':46,
          'actual_original_helper_count':13,'actual_original_assembler_count':1,'actual_recovery_control_processes':32,'actual_SELF':expected_cpu,
          'actual_local_window_sum':expected_wall,'all46_in_sidecar_checkpoints':True,'same_pool_imported_once':True,'original_callable_gate_passed':True,
          'stopped_before_producer_import':True,'real_Library_calls':0,'GEN_calls':0})
    def test_every_stage_CPU_and_wall_before_effect(self):
        for stage in STAGES:
            for kind in ('cpu','wall'):
                with self.subTest(stage=stage,budget=kind):
                    root,g,out=run_bridge(stage,kind);self.assertFalse(out['success'])
                    r=Path(g['recovery_journal_root']);n=STAGES.index(stage)
                    self.assertFalse((r/f'effect-{n:02d}.intent.json').exists());self.assertTrue((r/'HALTED.json').exists())
                    last=read(sorted(r.glob('delta-*.receipt.json'))[-1]);self.assertEqual(last['outcome'],'unknown')
                    self.assertIn('shared init_final pool exhausted',last['error']);self.assertTrue(last['measurement']['TEST_ONLY'])
                    self.assertLessEqual(out['calls']['archive_creates'],1);self.assertEqual(out['calls']['index_creates']+out['calls']['replacements'],0)
                    RESULTS.append({'case':'budget_before_effect','stage':stage,'kind':kind,'fixture':str(root),'actual_previous_helpers':len(list(Path(g['original_journal_root']).glob('helper-*.receipt.json'))),
                      'new_effect_blocked':True,'probe':'SYNTHETIC_BUDGET_PROBE','all_prior_original_and_delta_measurements_checked':True})
    def test_original_archive_throw_retained_without_replay_or_success(self):
        root,g,out=run_bridge(archive_throw=True);self.assertFalse(out['success']);self.assertIn('TEST_ONLY original archive throw',out['error'])
        self.assertEqual(out['calls']['archive_creates'],1);j=Path(g['original_journal_root']);r=Path(g['recovery_journal_root'])
        self.assertEqual(read(j/'helper-09.receipt.json')['outcome'],'unknown');self.assertFalse((j/'helper-10.intent.json').exists())
        self.assertEqual(read(root/'producer/retained-library-replies/phase2-init-archive/exception.json'),read(r/'archive-exception.raw.json'))
        closed=read(r/'failure.retention.receipt.json');self.assertEqual(closed['outcome'],'unknown');self.assertIsNone(closed['error'])
        self.assertIsNotNone(closed['original_failed_helper_ref']);self.assertIsNotNone(closed['observed_shared_pool'])
        self.assertTrue((root/'producer/state/external-pending.json').exists());self.assertFalse((r/'RECONCILED_HANDOFF.v2.json').exists())
        with self.assertRaises(Stop):Ledger(g,g['_grant_ref'],fixture=True).enter()
        RESULTS.append({'case':'original_archive_exception_retention','fixture':str(root),'archive_creates':1,'original_retention_helper_executed':True,
          'original_error_preserved':True,'pending_preserved':True,'outcome':'unknown','original_failed_helper_cost_and_failure_controls_counted':True})
if __name__=='__main__':
    runner=unittest.TextTestRunner(verbosity=2);res=runner.run(unittest.defaultTestLoader.loadTestsFromTestCase(RealIntegration))
    (ROOT/'audit/REAL_INTEGRATION_RESULTS.json').write_bytes(canon({'success':res.wasSuccessful(),'test_methods':res.testsRun,'actual_scenarios':len(RESULTS),'results':RESULTS,'fixtures_only':True,'recovery_execution_granted':False}))
    raise SystemExit(0 if res.wasSuccessful() else 1)
