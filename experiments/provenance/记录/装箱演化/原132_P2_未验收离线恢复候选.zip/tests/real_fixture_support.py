"""Portable trusted fixture. Executes exact original local bytes, never a connector."""
import sys,json,tempfile,subprocess,shutil,hashlib,os
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from recovery_core import canon,sha,ref,read,filehash,STAGES,need
def setup_fixture(stage=None,budget=None,archive_throw=False):
    base=Path(tempfile.mkdtemp(prefix='real-',dir=ROOT/'fixtures'));w=base/'producer';j=base/'producer.namespace-init';impl=base/'implementation'
    shutil.copytree(ROOT/'references/init',impl)
    old=read(ROOT/'evidence/INIT_GRANT.APPROVED.original.json');pins=read(impl/'ORIGINAL_SOURCE_PINS.json');source=ROOT/'references/original_source'
    old.update(TEST_ONLY=True,producer_workspace=str(w),journal_root=str(j),implementation_root=str(impl),original_source_root=str(source),
               note='TEST_ONLY local original-code fixture; no real Library or GEN permitted')
    old['exact_original_source_pins']={str(source/n):h for n,h in pins['files'].items()}
    old['exact_original_source_pins'][str(impl/pins['bundled_xattrs_helper']['path'])]=pins['bundled_xattrs_helper']['file_sha256']
    gp=base/'OLD_INIT.TEST_ONLY.json';gp.write_bytes(canon(old));logs=base/'exec-roundtrips';logs.mkdir()
    def helper(step,script,args,stdin=None,isolated=True):
        argv=[sys.executable,*(['-I'] if isolated else []),'-B',str(impl/'init_local_helper.py'),'--grant',str(gp),
              '--grant-sha256',filehash(gp),'--step',step,'--script',str(script),'--',*map(str,args)]
        p=subprocess.run(argv,input='' if stdin is None else json.dumps(stdin),capture_output=True,text=True,
                         env={'PATH':'/usr/bin:/bin','PYTHONDONTWRITEBYTECODE':'1'})
        (logs/(step+'.json')).write_bytes(canon({'argv':argv,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'TEST_ONLY':True}))
        need(p.returncode==0,'original fixture helper failed: '+step+': '+p.stderr[-600:])
        return p
    helper('build',impl/'empty_artifact_builder.py',[gp])
    helper('index.begin',w/'src/external_commit_fence_v2.py',['begin',w,w/'index.initial.json','null','-1','index'])
    retained=w/'retained-library-replies/phase2-init-index';retain=source/'original132_phase1_preparation_20261005/retention/retain_tool_result.py'
    helper('index.retain-start',retain,['start',retained],{'TEST_ONLY':True,'method':'fixture index create'})
    item={'status':'succeeded','operation':'create','library_file_id':'libfile_TEST_ONLY_index','file_id':'file_TEST_ONLY_index',
          'file_name':'index.initial.json','current_version_number':0,'file_size_bytes':859,'xattrs':[]}
    raw={'structuredContent':item,'content':[],'isError':False,'TEST_ONLY':True}
    helper('index.retain-response',retain,['response',retained],raw)
    helper('index.xattrs',w/'.library-helpers-current/library_file_transfer.py',['apply-xattrs',w/'index.initial.json',item['library_file_id']],[],False)
    g=read(ROOT/'RECOVERY_GRANT.DEVELOPMENT.json');g.update(TEST_ONLY=True,execution_granted=False,independent_review_accepted=False,
      producer_workspace=str(w),original_journal_root=str(j),recovery_journal_root=str(base/'producer.namespace-recovery'),
      original_implementation_root=str(impl),old_grant_ref=ref(gp),old_grant_file_text=gp.read_text(),
      original_source_pins=old['exact_original_source_pins'],original_implementation_pins={str(impl/n):h for n,h in old['implementation_files'].items()},
      historical_create_ref=ref(retained/'response.json'),pending_ref=ref(w/'state/external-pending.json'),
      stop_zip_ref=ref(ROOT/'evidence/original-stop.zip'),old_bridge_error_ref=ref(ROOT/'evidence/BRIDGE_ERROR.original.json'),
      suffix_actions=list(STAGES),recovery_cli_path=str(ROOT/'src/recovery_cli.py'))
    m=ROOT/'references/generation/OPERATING_SOURCE_MANIFEST.json';g['generation_original_manifest_ref']=ref(m)
    g['generation_original_pins']={str(m.parent/n):h for n,h in read(m)['production_files'].items()}
    g['new_source_pins']={str(p):filehash(p) for p in (ROOT/'src').iterdir() if p.suffix in ('.py','.js')}
    g['index'].update(file_id=item['file_id'],library_file_id=item['library_file_id'],file_name=item['file_name'])
    g['archive'].update(bytes=(w/'archive.initial.zip').stat().st_size,sha256=filehash(w/'archive.initial.zip'))
    g['old_five']=[{k:ref(j/f'helper-{n:02d}.{k}.json') for k in ('intent','receipt')} for n in range(5)]
    if stage:g.update(TEST_budget_before_stage=stage,TEST_budget_kind=budget)
    if archive_throw:g['TEST_archive_throw']=True
    recovery=base/'RECOVERY.TEST_ONLY.DISABLED.json';recovery.write_bytes(canon(g))
    config={'root':str(base),'grant_path':str(recovery),'grant_sha256':filehash(recovery),'python':sys.executable,'TEST_ONLY':True}
    cp=base/'fixture-config.json';cp.write_bytes(canon(config));return cp
if __name__=='__main__':
    args=sys.argv[1:];p=setup_fixture(*(args+[None,None])[:2]);sys.stdout.write(str(p))
