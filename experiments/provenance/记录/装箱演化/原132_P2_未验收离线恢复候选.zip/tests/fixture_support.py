"""Trusted synthetic outcomes only; writes stay below development/fixtures."""
import sys, tempfile, shutil, copy, json, time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/"src")]
from recovery_core import *
from reconciled_handoff import assemble_v2
from gen_importer_v2 import *
from recovery_cli import payload
class Clock:
    def __init__(self):self.t=time.monotonic()+1;self.n=0
    def command(self,cpu=.003,wall=.003):
        self.n+=1;s=self.t;self.t+=wall+.001
        return dict(process="TEST_ONLY:"+str(self.n),start=dict(process="TEST_ONLY:"+str(self.n),monotonic=s,self_cpu=0),
          end=dict(process="TEST_ONLY:"+str(self.n),monotonic=s+wall,self_cpu=cpu),self_cpu_seconds=cpu,
          wall_seconds=wall,local_inclusive_wall_seconds=wall,native_wait_union_seconds=0,
          measurement_status="known",RUSAGE_kind="RUSAGE_SELF",TEST_ONLY=True,
          wall_semantics="local_stage_inclusive_no_wait_deduction")
class Fixture:
    def __init__(self):
        from real_fixture_support import setup_fixture
        cp=setup_fixture();config=read(cp);self.root=Path(config['root']);gp=Path(config['grant_path'])
        self.g=read(gp);self.clock=Clock();self.w=Path(self.g['producer_workspace']);self.j=Path(self.g['original_journal_root']);self.r=Path(self.g['recovery_journal_root'])
        self.gr=ref(gp);self.g['_grant_ref']=self.gr
        self.ledger=Ledger(self.g,self.gr,fixture=True);self.index_creates=0;self.archive_creates=0;self.helpers=[];self.crash_internal=None
    def interrupt(self,point):
        if self.crash_internal==point:raise Stop("trusted interruption: "+point)
    def m(self):return self.clock.command()
    def invoke_meter(self,method,*args,cpu=.003,wall=.003):
        m=self.clock.command(cpu,wall);return method(*args,measure=lambda:m)
    def enter(self):return self.invoke_meter(self.ledger.enter)
    def real_tool(self,*a,**k):raise Stop("real Library/OpenCode/GEN permanently refused in fixture")
    def readraw(self):
        return {"structuredContent":{"results":[{"file_id":self.g["index"]["file_id"],
            "library_file_id":self.g["index"]["library_file_id"],"has_more":False,
            "content":[(self.w/"index.initial.json").read_text()],"version_id":None}]},"isError":False}
    def old_helper(self,step):
        n=OLD_STEPS.index(step);need(n>=5 and step not in self.helpers,"no historical/repeated helper")
        self.helpers.append(step);ip=self.j/f"helper-{n:02d}.intent.json"
        publish(ip,{"step":step,"TEST_ONLY":True})
        if step.endswith("confirm"):
            kind=step.split(".")[0];create=unwrap(read(self.r/"archive-create.raw.json")) if kind=="archive" else unwrap(read(checked_ref(self.g["historical_create_ref"])))
            blob=self.w/("index.initial.json" if kind=="index" else "archive.initial.zip")
            receipt={k:create[k] for k in ("library_file_id","file_id","current_version_number")}
            receipt.update(write_result_confirmed=True,remote_bytes_verified=False,index_readback_confirmed=kind=="index",
                local_blob_sha256=filehash(blob),local_blob_bytes=blob.stat().st_size)
            d=self.w/"state/commits";d.mkdir(exist_ok=True);publish(d/(receipt["library_file_id"]+"-0.json"),receipt)
            self.interrupt(step+".after_commit")
            # This fixture simulates the ORIGINAL confirm effect, never recovery code.
            (self.w/"state/external-pending.json").unlink()
            self.interrupt(step+".after_clear")
        m=self.m();publish(self.j/f"helper-{n:02d}.receipt.json",dict(step=step,outcome="confirmed",
            intent_file_sha256=filehash(ip),init_grant_file_sha256=self.g["old_grant_ref"]["file_sha256"],
            measurement=m,TEST_ONLY=True))
        return {"TEST_ONLY":True}
    def act(self,stage):
        if stage.startswith("read."):return self.readraw()
        if stage.endswith("payload"):
            return self.invoke_meter(payload,self.ledger,stage.split('.')[0])
        if stage=="archive.create":
            self.archive_creates+=1;need(self.archive_creates==1,"archive once")
            self.interrupt("archive.create.throw")
            return {"structuredContent":{"status":"succeeded","library_file_id":"libfile_TEST_ONLY_archive",
               "file_id":"file_TEST_ONLY_archive","current_version_number":0},"isError":False}
        if stage=="base.assemble":
            publish(self.j/"assembly.intent.json",{"TEST_ONLY":True})
            self.interrupt("base.assemble.after_intent")
            m=self.m();publish(self.j/"assembly.receipt.json",dict(outcome="confirmed",measurement=m,TEST_ONLY=True,
                intent_file_sha256=filehash(self.j/"assembly.intent.json"),init_grant_file_sha256=self.g["old_grant_ref"]["file_sha256"]))
            self.interrupt("base.assemble.after_receipt")
            index=read(self.w/"state/commits"/(self.g["index"]["library_file_id"]+"-0.json"))
            archive=read(self.w/"state/commits/libfile_TEST_ONLY_archive-0.json")
            refs=[ref(self.j/f"helper-{n:02d}.receipt.json") for n in range(13)]+[
                ref(self.w/"state/commits"/(self.g["index"]["library_file_id"]+"-0.json")),
                ref(self.w/"state/commits/libfile_TEST_ONLY_archive-0.json"),ref(self.j/"assembly.receipt.json")]
            h=dict(schema=V1,status="CONFIRMED",producer_workspace=str(self.w),operational_run_id=self.g["operational_run_id"],
                init_grant_file_sha256=self.g["old_grant_ref"]["file_sha256"],model_calls=0,candidate_executions=0,
                generation_execution_granted=False,measurements=[r["measurement"] for r in base_records(self.g)],
                receipt_files=refs,index_receipt=index,archive_receipt=archive)
            publish(self.j/"INIT_RESOURCE_HANDOFF.json",h);self.interrupt("base.assemble.after_handoff");return {}
        if stage=="archive.begin":publish(self.w/"state/external-pending.json",{"TEST_ONLY":True,"kind":"archive"})
        return self.old_helper(stage)
    def run(self,crash=None):
        self.enter()
        for stage in STAGES:
            self.invoke_meter(self.ledger.before,stage)
            if crash==(stage,"before"):raise Stop("trusted interruption before")
            value=self.act(stage)
            if crash==(stage,"after"):raise Stop("trusted interruption after")
            self.invoke_meter(self.ledger.after,stage,value)
        h=self.invoke_meter(assemble_v2,self.ledger)
        return h
