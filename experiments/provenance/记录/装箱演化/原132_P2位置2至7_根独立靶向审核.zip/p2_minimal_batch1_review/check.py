from pathlib import Path
import json,hashlib,time
r=Path(__file__).parent; start=time.process_time(); n=0
for kind in ('data','audit'):
 p=r/kind;m=json.loads((p/'FILE_MANIFEST.json').read_text())
 for f,meta in m.items():
  b=(p/f).read_bytes();assert len(b)==meta['bytes'] and hashlib.sha256(b).hexdigest()==meta['sha256'];n+=1
p=r/'data'; original=Path('/workspace/shared/minimal_generation_runner_20261007')
for name in ('runner.py','frozen_inputs.json'): assert (p/'executor'/name).read_bytes()==(original/name).read_bytes()
f=json.loads((p/'executor/frozen_inputs.json').read_text());out=[]
for s in f['slots'][1:7]:
 rec=s['record'];q=p/'ledger'/rec['slot_id'];d=json.loads((q/'dispatch.json').read_text());v=json.loads((q/'result.json').read_text())
 assert d['position']==rec['position']==v['position'] and d['order']==rec['order']
 assert d['slot_id']==rec['slot_id']==v['slot_id'] and d['arm']==rec['arm']
 assert hashlib.sha256((q/'prompt.txt').read_bytes()).hexdigest()==rec['prompt_sha256']==d['prompt_sha256']
 assert d['configuration']==f['freeze']['configuration']
 assert d['config_sha256']==rec['config_file_sha256']
 assert hashlib.sha256((q/'answer.txt').read_bytes()).hexdigest()==v['answer_sha256']
 assert len((q/'answer.txt').read_bytes())==v['answer_bytes']>0
 assert v['client_state']=='exited' and v['exit_code']==0 and v['finish_reasons']==['stop'] and not v['capture_issues']
 assert 0<v['wall_seconds']<=900
 out.append({'position':v['position'],'slot_id':v['slot_id'],'answer_bytes':v['answer_bytes'],'wall_seconds':v['wall_seconds']})
assert len(list((p/'ledger').iterdir()))==6
res={'status':'PASS_targeted_generation_archive_review','archive_member_hashes':n,'slots':out,'frozen_inputs_and_runner_equal_previously_reviewed':True,'parameters_and_frozen_prompt_hashes_equal':True,'empty_answers':0,'CLI_terminal_successes':6,'readback_data_sha256':'94a80aee07b1901cf2d886f39f5d6f57f6ab1a69c52fcd4d2fd4d4a400f2567d','readback_audit_sha256':'70f71e4d35be94e627873effeea86a1efc71e0b7cf6f24e2f151074212e5677a','scientific_admission_or_scoring_performed':False,'provider_request_body_or_usage_independently_verified':False,'historical_resource_full_cap_certification':False,'notes':'CLI records and archive bytes checked; not proof of provider HTTP attempts, billed usage, algorithm correctness, or complete historical resource balance. Existing original generation scope included local 61440 seconds; no new budget inferred from elapsed observation.','cpu_seconds':time.process_time()-start}
(r/'REVIEW.json').write_text(json.dumps(res,ensure_ascii=False,indent=2));print(json.dumps(res,ensure_ascii=False,indent=2))
