# R1 independent implementation audit: NOT ACCEPTED

Date: 2026-10-06. Package: `509dca0f7863b00c2f96e6891051c1c782916ac225854e4670466ec7e79a6b91`, 189,616 bytes. This report applies only to this R1 package. R2 must be received separately and rerun against the same acceptance checklist.

## Result

R1 remains blocked despite the author's 14 Python and 20 JavaScript trusted scenarios passing on independent rerun. Two actual downstream GEN boundaries fail, and additional ordinary input/integrity tests expose error-handling and accounting gaps. **Do not use this candidate for real recovery or GEN activation.**

### Must-fix findings

1. **P1 / R1-01: Recovery measurements fail the actual GEN ledger contract.** `src/recovery_core.py:37–43` omits `wall_semantics`; unchanged `references/generation/durable_generation_sidecar.py:372–390` requires `local_stage_inclusive_no_wait_deduction`. `production_generation_entry_v2.py:161–162` passes inherited measurements unchanged. Actual `recovery.sample()` through actual `Sidecar.finish()` yields unknown outcome, a halt, and no imported delta process CPU checkpoint. An otherwise identical control with the required semantic field succeeds. A completed fixture has 14+32 rows; every delta lacks that field. Evidence: `importer_independent/boundary_results.json`, `completed_fixture_results.json`, `check_boundaries.py`.

2. **P1 / R1-02: New GEN callable path is rejected by the unchanged source gate.** The new entry's `local()` passes functions defined in `src/production_generation_entry_v2.py`; unchanged `durable_generation_sidecar.py:453–456` permits the fixed operational entry `references/generation/production_generation_entry.py`. Correct new path/hash in operational pins alone does not satisfy this gate. The new `reserve_next` function is rejected before `begin`; the original v1 control passes the gate and is stopped by a test-only sentinel before dispatch. Evidence: `importer_independent/boundary_results.json`, `check_boundaries.py`.

3. **P1 / R1-03: Error-marked read can be confirmed as successful evidence.** `recovery_core.py:80–91` does not reject `raw.isError`; an ordinary plain response with `isError=true` and otherwise correct frozen index data is accepted. Require explicit tool/error-envelope checks before receipt confirmation. Evidence: `CORE_BOUNDARY_RESULTS.json` / `read_error_flag`, `check_core_boundaries.py`.

4. **P1 / R1-04: Additional unknown original helper receipt is ignored.** `recovery_core.py:141–161` enumerates known receipts and counts intent files, but does not enforce the exact receipt-file set. Entry accepts a stopped fixture with extra `helper-99.receipt.json` containing outcome unknown. It cannot certify the exact stopped prefix while silently ignoring unexplained helper evidence. Evidence: `CORE_BOUNDARY_RESULTS.json` / `unexpected_old_receipt`.

5. **P2 / R1-05: Recovery measurement validation is weaker than its promised contract.** `recovery_core.py:44–66` accepts a later regressed SELF checkpoint for the same stable process through `max()`, and accepts `wall_seconds` inconsistent with start/end and local inclusive wall. These are ordinary trusted negative fixtures, not adversarial hooks. Reject inconsistent/unknown/regressed evidence rather than defer its failure to GEN. Evidence: `CORE_BOUNDARY_RESULTS.json` / `regressed_CPU_checkpoint`, `inconsistent_wall_seconds`.

6. **P2 / R1-06: Archive tool exception is masked and not retained.** `suffix_bridge.js:74–78,105–111` leaves `archive.create` unresolved after an ordinary tool throw. The unchanged retention wrapper's `save('exception')` then requests `archive.retain-response`, whose before gate rejects the unresolved prior effect. The final exception is the gate error rather than the original tool error, and the exception-retention helper is never invoked. One archive attempt remains fenced and there is no subsequent helper, so this finding concerns preservation/diagnostics, not a demonstrated replay. Require a narrow fail-only evidence path that preserves the original error and the unresolved fence without retry. Evidence: `EXCEPTION_BOUNDARY_RESULTS.json`, `check_exception_boundary.js`.

7. **P1 conditional / R1-07: Recovered namespace may downgrade to base v1 and omit all delta rows.** `gen_importer_v2.py:6–7` returns the 14-row base immediately, and the new bootstrap accepts it even when that namespace has a completed 46-row v2 recovery. The fixture omits 32 recovery rows in this branch. The author test explicitly accepts this behavior. An exact future grant pointing to the correct v2 would avoid the branch; the implementation nevertheless needs to forbid v1 whenever recovery history exists, retaining v1 only for the unrecovered legacy contract. Evidence: `importer_independent/completed_fixture_results.json`, `check_completed_fixture.py`.

P1 means a release-blocking control/data-accounting or operational wiring defect; P2 means a correctness/evidence defect that also needs correction before this narrowly scoped recovery is accepted. No finding authorizes removing existing source/admission checks.

## What was independently verified

- ZIP byte count and SHA match the supplied provenance; safe member paths and unique member names checked.
- All 51 manifest members match size/SHA; no unexpected members. Received package/source bytes remain unchanged after tests.
- 20 available copied original reference files match the previously present local originals byte-for-byte.
- All five prior intent/receipt pairs, pending fence and old grant match the stopped evidence and R1 bindings.
- Disabled recovery/GEN grants remain disabled. No automatic activation instructions were executed.
- Author JavaScript tests rerun unmodified: 20 trusted scenarios pass.
- Author Python tests cannot rerun directly after transfer because fixtures read author-executor absolute paths. After test-only input relocation, all 14 tests pass. All six new source files and all three supplied test files remain byte-identical; the disabled grant and synthetic historical seed grant/receipt bindings are explicitly labelled `TEST_ONLY_AUDIT_RELOCATION`. Original received evidence was not changed. See `RELOCATION_RECORD.json` and `prepare_relocated_fixtures.py`.
- Static suffix wiring does not call the old complete initializer. It calls original index helper05/06, archive-only original adapter/retention/commit, and original assembler; no reachable requested index create/replace was observed. Trusted JS success has index create/replace 0 and archive create 1.
- Existing admitted-stage ordering, original pending retention, explicit v2 counts and base+delta row identity work in the supplied synthetic fixtures. These are positive offline properties, not completion of the production recovery.

## Limits and deferred checks

- Original helper05–12 and assembler were not run by this R1 audit. R1's supplied fixtures simulate those Python outcomes. The author is preparing a separate R2 ordinary-fixture integration, which requires actual independent regression after receipt.
- Real Library, model, candidate, numerical experiment and GEN execution count is zero. Pure calls to GEN importer/ledger validation methods in trusted isolated fixtures did not create a real GEN journal or dispatch a producer.
- Original producer live disk was not inspected. The package's 45-file unchanged report is the producer's evidence; independent verification covers delivered bytes and locally available historical source, not a claim of access to that live disk.
- No prior platform-stopped getter/TOCTOU reproduction was run or recreated. No unbounded new audit expansion is planned; R2 reruns the frozen list and these concrete failures.
- Historical process tails, pre-entry wall, JS/plugin/Library/provider costs and missing historical raw observations stay unknown. Review/development overhead is not comprehensively metered and is not called zero or included as original helper evidence.
- `CPU_cap_certification=NOT_ESTABLISHED`; complete CPU upper-bound claims remain false. Successful mock acceptance cannot establish production recovery, complete historical resource accounting, or GEN readiness.

## Reproduction and evidence

- Author JS: `node execution/tests/test_bridge.js` (first run used the original disabled grant; log `logs/author_js_unmodified.log`).
- Original Python transfer failure: `python3 -I -B execution/tests/test_recovery.py`, log `logs/author_python_unmodified.log`.
- Test-only relocation: `python3 -I -B prepare_relocated_fixtures.py`; then the same original Python command, log `logs/author_python_relocated.log` (14 tests / OK).
- Core negatives: `python3 -I -B check_core_boundaries.py`.
- Exception preservation: `node check_exception_boundary.js`.
- Actual ledger/source-gate boundary checks and completed-fixture import inspection: scripts under `importer_independent/` and their paired JSON outputs.

This R1 evidence is frozen. Keep R2 code, logs and findings in a separate revision directory and do not overwrite these results.
