"""Audit-only test input relocation. Never alters received sources or producer data."""
from pathlib import Path
import hashlib, json, shutil, zipfile

BASE=Path(__file__).resolve().parent
ROOT=BASE/'execution'
LOCAL=BASE.parent
def read(p): return json.loads(p.read_text())
def write(p,v):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def ref(p): return {'path':str(p),'file_sha256':sha(p)}
g=read(ROOT/'RECOVERY_GRANT.DEVELOPMENT.json')
old=read(ROOT/'evidence/INIT_GRANT.APPROVED.original.json')
seed=ROOT/'fixtures/TEST_ONLY_relocated_seed'
prod=seed/'producer'; journal=seed/'producer.namespace-init'
prod.mkdir(parents=True,exist_ok=False);journal.mkdir()
(prod/'state').mkdir(); (prod/'retained-library-replies/phase2-init-index').mkdir(parents=True)
stop=zipfile.ZipFile(ROOT/'evidence/original-stop.zip')
for source,dest in [('empty_blobs/index.initial.json',prod/'index.initial.json'),
                    ('empty_blobs/archive.initial.zip',prod/'archive.initial.zip'),
                    ('pending/state.external-pending.json',prod/'state/external-pending.json'),
                    ('actual_tools/index-create.response.json',prod/'retained-library-replies/phase2-init-index/response.json'),
                    ('actual_tools/bridge.actual-error.json',seed/'bridge.actual-error.json')]:
    dest.write_bytes(stop.read(source))
source_root=ROOT/'references/TEST_ONLY_original_sources'
pins=read(ROOT/'references/init/ORIGINAL_SOURCE_PINS.json')
old['implementation_root']=str(ROOT/'references/init')
old['original_source_root']=str(source_root)
old['producer_workspace']=str(prod)
old['journal_root']=str(journal)
old['TEST_ONLY_AUDIT_RELOCATION']=True
new_old_sources={}
for name,digest in pins['files'].items():
    src=LOCAL/name;dest=source_root/name
    assert sha(src)==digest
    dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest)
    new_old_sources[str(dest)]=digest
xp=ROOT/'references/init'/pins['bundled_xattrs_helper']['path']
new_old_sources[str(xp)]=pins['bundled_xattrs_helper']['file_sha256']
old['exact_original_source_pins']=new_old_sources
og=seed/'TEST_ONLY_relocated_old_grant.json';write(og,old)
oldfive=[]
for n in range(5):
    ip=journal/f'helper-{n:02d}.intent.json';rp=journal/f'helper-{n:02d}.receipt.json'
    intent=json.loads(stop.read('namespace_journal/'+ip.name))
    receipt=json.loads(stop.read('namespace_journal/'+rp.name))
    intent['init_grant_file_sha256']=sha(og)
    intent['TEST_ONLY_AUDIT_RELOCATION']=True
    write(ip,intent)
    receipt['init_grant_file_sha256']=sha(og)
    receipt['intent_file_sha256']=sha(ip)
    receipt['TEST_ONLY_AUDIT_RELOCATION']=True
    write(rp,receipt)
    oldfive.append({'intent':ref(ip),'receipt':ref(rp)})
manifest=ROOT/'references/generation/OPERATING_SOURCE_MANIFEST.json'
g.update(producer_workspace=str(prod),original_journal_root=str(journal),
    recovery_journal_root=str(prod)+'.namespace-recovery',old_grant_ref=ref(og),
    old_grant_file_text=og.read_text(),old_five=oldfive,
    original_implementation_root=old['implementation_root'],
    original_implementation_pins={str(ROOT/'references/init'/n):h for n,h in old['implementation_files'].items()},
    original_source_pins=new_old_sources,
    generation_original_manifest_ref=ref(manifest),
    generation_original_pins={str(manifest.parent/n):h for n,h in read(manifest)['production_files'].items()},
    historical_create_ref=ref(prod/'retained-library-replies/phase2-init-index/response.json'),
    pending_ref=ref(prod/'state/external-pending.json'),
    old_bridge_error_ref=ref(seed/'bridge.actual-error.json'),
    stop_zip_ref=ref(ROOT/'evidence/original-stop.zip'),
    recovery_cli_path=str(ROOT/'src/recovery_cli.py'),
    new_source_pins={str(p):sha(p) for p in sorted((ROOT/'src').iterdir()) if p.suffix in ('.py','.js')},
    TEST_ONLY_AUDIT_RELOCATION=True)
assert g['execution_granted'] is False and g['generation_execution_granted'] is False
write(ROOT/'RECOVERY_GRANT.DEVELOPMENT.json',g)
source_comparison={str(p.relative_to(ROOT)):sha(p)==sha(BASE/'received'/p.relative_to(ROOT))
                   for folder in ('src','tests') for p in (ROOT/folder).iterdir() if p.is_file()}
assert all(source_comparison.values())
write(BASE/'RELOCATION_RECORD.json',{
    'purpose':'Run original trusted tests in independent audit workspace; not authentic production receipts.',
    'new_runtime_and_test_sources_byte_identical':source_comparison,
    'changes':'Relocated only execution-copy disabled grant and labeled TEST_ONLY historical seed grant/receipt bindings. Historical measurement values, source bytes, raw create response, pending and blobs unchanged.',
    'received_package_unchanged':True,'production_namespace_accessed':False,
    'disabled_fixture_grant':ref(ROOT/'RECOVERY_GRANT.DEVELOPMENT.json')})
print(json.dumps({'status':'TEST_ONLY_RELOCATION_READY','root':str(ROOT),'unchanged_source_tests':len(source_comparison)}))
