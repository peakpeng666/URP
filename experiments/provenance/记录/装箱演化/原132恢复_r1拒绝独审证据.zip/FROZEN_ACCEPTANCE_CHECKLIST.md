# Phase 2 recovery implementation: independent acceptance checklist

Frozen: 2026-10-06 13:58 UTC. Current disposition: **PREPARED / IMPLEMENTATION NOT RECEIVED / NOT ACCEPTED**.

This is an implementation audit, not approval of the design or authorization to recover production. The parent will provide the producer's downloadable package. No producer polling, duplicate assignment, user-computer access, real Library action, original helper invocation, assembler run in the original namespace, or real GEN execution is allowed in this audit.

## 1. Frozen reference and scope

- Primary design evidence: `audit_original132_phase2_stop_recovery_20261006/RECOVERY_REVIEW.md` and its `STATIC_VERIFICATION.json`.
- Original initializer files: `original132_phase2_namespace_init_20261006/`.
- Original exporter/fence/receipt and retention files: `original132_phase1_preparation_20261005/`.
- Original GEN importer and durable ledger: `original132_phase2_generation_accounting_20261006/production_generation_entry.py` and `durable_generation_sidecar.py`.
- Audit output, copies, trusted fixtures, logs and added tests remain under this independent audit directory. Author and production directories remain read-only.
- Review ordinary trusted value fixtures only. Do not run, recreate, rename, or route around previously platform-stopped getter/TOCTOU adversarial reproductions. Inspect the supplied test entry points before selecting tests; disallowed or real-service tests are not executed.
- All criteria below begin as **NOT RUN**. A checklist or author's success report alone cannot satisfy them.

## 2. Package intake gate

**I01.** Record confirmed package provenance, filename, byte length, exact SHA-256, and any producer release ID. A local path must actually exist and be readable in this executor.

**I02.** Inspect ZIP/member listing before extraction. Reject absolute/traversal/duplicate paths and symlink destinations. Extract only to a fresh audit-owned child directory.

**I03.** Validate every manifest member's path, size and SHA-256; flag omitted source, test, configuration or transitive runtime dependencies. Record manifest coverage and extras. A self-contained manifest is integrity evidence, not independent provenance.

**I04.** Verify original pinned files byte-for-byte against this audit's source baseline and the original grant. No replacement of old grant/source pins, five receipts, production namespace or historical stop evidence may be disguised as unchanged history.

**I05.** Inspect run instructions and test code before executing. Audit runs must contain ordinary offline fixtures and fail closed on real service/model/GEN routes. Developer grant must have execution disabled.

## 3. Suffix-only state machine and source binding

**S01.** New entry point admits only the exact stopped prefix: original helper 00–04 confirmed with matching intents, grant, pending fence, retained historical create response, original initial index/archive, and full original/new dependency pins.

**S02.** Any missing, unexpected, unresolved, duplicate, malformed or inconsistent prior helper/assembly/recovery intent or receipt stops before the next mutable action. Existing target payload/commit is not overwritten or repaired.

**S03.** All code paths reachable from the recovery entry lack index create/replace and helpers 00–04. Do not invoke the full old `initializeNamespace`; do not hydrate its terminated closure or fabricate a new create result.

**S04.** New reconciliation contract pins original grant, precise producer/journal/recovery paths, stop evidence, pending fence, five immutable intent/receipt pairs, retained create response, exact identities/version/content hashes, original and new sources, action order and shared pool.

**S05.** Exact index read uses authenticated-tool response shape; validates same Library and backing IDs, current head, complete/canonical bytes, run/freeze/empty rows and intended version provenance. A current response without a version is not falsely said to supply v0.

**S06.** New read evidence is retained as new evidence with source/time/hash. Historical create response stays historical. No failed historical read/search or exec response is fabricated or backfilled.

**S07.** Recovery forms the sole new original readback payload and calls unchanged original wrappers for helper 05 `index.receipt` and 06 `index.confirm`, in order. Only original confirm may write the durable commit and clear the original pending fence.

**S08.** After index confirm, use unchanged original archive adapter/retention/commit source with archive-only fixed arguments (`null`, `-1`, non-index). New archive identity differs from index and all four P0/P1 IDs. Original helpers 07–12 remain wrapped and ordered.

**S09.** Archive create is at most once over persistent history, not merely once per JS closure. Throw, uncertain result, retention failure, checkpoint failure or interrupted invocation cannot permit a second create.

**S10.** Original assembler is first-run-only, after exactly 13 helper receipts and no pending original write. Preserve original v1 base: exactly 14 measurements and 16 receipt references. Recovery must not falsify, merge or replace that base.

## 4. Durability, unknown outcomes and trusted interruption fixtures

**D01.** Durable exclusive recovery intent is created before the first recovery mutation. Lock and journal survive process loss. Existing unresolved recovery intent blocks reentry, including an attempted fresh grant ID.

**D02.** Per-stage durable admission/intent/results prove exact prefix and permitted next action; out-of-order or repeated requests stop. No caller-supplied callback, arbitrary step/identity, shell route, replacement API or unconstrained file write enters the production path.

**D03.** Ordinary trusted interruption fixtures cover before/after new payload, 05, 06, archive begin/retain response/xattrs/receipt/confirm, original assembly intent/receipt/handoff and new handoff sealing, as supported without forbidden adversarial reproduction.

**D04.** A confirmed external write followed by a missing local receipt remains unknown and cannot replay. Confirm interrupted between commit write and fence clearing must stop with evidence intact, not manually delete pending.

**D05.** Unknown/malformed/partial raw responses and unknown helper or measurement results block the next stage. Exception retention is evidence, not permission to continue. Retrying the entry after every tested failure adds no external create or repeated helper.

**D06.** Preserve stop report, original bridge error, old grant, raw create response, prior receipts/intents and failed recovery evidence. No deletion, rename, overwrite, or manual fence cleanup.

## 5. Same-pool accounting and admission

**A01.** The original five observed measurements remain exact: partial SELF sum 0.22594299999999998 s and local wall sum 0.17413645899796393 s. They are neither remeasured nor reset.

**A02.** Nine future original actions are genuinely new work (05/06, 07–12, original assembler). Their receipts create the 14-measurement base; they are not fabricated reconstructions of historical work.

**A03.** All k new local recovery verification, retention, guard and handoff-construction processes/checkpoints are actually measured and included in explicit delta measurements, not only file references or an informational total.

**A04.** Every subsequent original helper, external archive dispatch, original assembler and new handoff stage checks original confirmed + recovery confirmed + current guard checkpoint in the same 60 SELF / 240 local-wall pool. After-stage checks incorporate the new cost before the next action. Old `within()` alone does not satisfy this condition.

**A05.** Trusted low-budget fixtures demonstrate recovery delta and current admission cost block the next action, even when original-only totals would pass. Boundary fixtures separately cover CPU and wall, equality, just-below and exceeded values. No new 60/240 grant or final-import-only deduction.

**A06.** Stable process identities and cumulative SELF checkpoints admit only justified increments/maxima. Reject unknown, nonfinite, negative, regressed, missing, duplicated or substituted measurements. Do not treat unknown as zero.

**A07.** Local wall accounting uses actual nonoverlapping stage windows; outer encompassing windows and child windows are not both added. Explain clock-domain/process rules and any excluded/unknown portions. Ordinary fixtures cover repeated process checkpoints and duplicate/overlapping intervals without adversarial hooks.

**A08.** Handoff construction itself has a recorded checkpoint included in v2. Final post-checkpoint receipt/write/exit tails remain unknown. No circular self-hash, omission or zero-cost certification.

## 6. Explicit v2 handoff and future importer wiring

**H01.** Independent v2 schema explicitly binds original 14/16 base, reconciliation grant, recovery evidence/receipts, delta measurements, total import list, identities, pins, totals and unknowns. Do not silently inject extras into old v1 semantics.

**H02.** Validator verifies actual files and relationships, not only user-supplied totals/nonempty arrays: path/hash, namespace/run, exact source versions, sequential stage history, unique measurements/process intervals, all expected newly accountable checkpoints, correct receipts and zero model/GEN calls.

**H03.** Future GEN has a real explicit v2 branch at its importer/bootstrap boundary. It actually passes base + all delta measurements to the existing durable ledger once, preserving scientific selection, 60 slots, P1/heldout restrictions and existing stage/dispatch fences.

**H04.** Trusted end-to-end offline importer fixture exercises the actual compatibility module and durable ledger, not a separately coded arithmetic mock. Confirm imported CPU/wall contribution matches independently computed totals plus any genuine import/control costs.

**H05.** Replay/duplicate import attempts reject without doubling base or delta. Test missing receipt, mismatched hash, malformed/unknown delta, duplicate process interval, omitted expected checkpoint, wrong namespace/run/identity/source and unsupported schema. V1 path does not silently accept v2.

**H06.** Preserve original v1 compatibility only within its original contract. No monkey patch of old importer, hidden bypass or alternate production entry skips new validation/admission. Static call graph traces the provided future activation bindings through the actual importer to `Sidecar.finish`.

**H07.** Valid v2/mock acceptance does not activate GEN. Developer activation remains false; a real recovery/GEN grant needs its own exact reviewed source/evidence bindings after this audit.

## 7. Permanent reporting and safety assertions

**R01.** Actual new index create/replace = 0; archive create <= 1 per successful mocked execution history; old helpers 00–04 = 0 in recovery. Model/candidate/numeric/GEN and real Library calls = 0 throughout this audit.

**R02.** Historical original process tails, Python pre-entry wall, original JS/plugin CPU, Library waits, provider CPU, complete task/bookkeeping cost and missing past raw records stay unknown. Present review/audit cost is not silently charged as measured original helper work or called zero.

**R03.** `CPU_cap_certification = NOT_ESTABLISHED`; complete CPU upper-bound claims remain false. 60/240 and overall 1860/61440 remain observed checkpoint/stage-window admission thresholds, not full execution caps.

**R04.** Preserve `remote_bytes_verified=false` meaning for original receipts. Independent current index byte evidence is separate; archive acknowledgment is not remote-byte verification.

**R05.** Final audit records package hash, manifest coverage, original-file preservation, exact commands/exit codes, author and independent trusted-test results, static source locations, failures, untested boundaries, and verdict. Distinguish **offline implementation accepted**, **real recovery not executed**, and **GEN not activated**.

## 8. Execution order after package arrives

1. Intake and manifest verification; preserve a read-only received copy.
2. Static review of entry points, tests and service boundaries; verify original pins.
3. Rerun selected author trusted tests only in audit copies/fixtures; retain complete logs.
4. Add independent trusted boundary tests in this directory and trace real source wiring.
5. Report blockers immediately to the parent, with minimal source evidence. Do not edit author implementation or run real recovery to test a suspicion.
6. Recheck receipt/source preservation and deliver the evidence-backed implementation audit. Mock success alone cannot establish production recoverability or close the historical measurement gap.
