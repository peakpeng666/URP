"""Read-only completed TEST_ONLY fixture import; never creates or dispatches GEN."""
import json
from pathlib import Path
import sys
from types import SimpleNamespace
HERE=Path(__file__).resolve().parent
EXECUTION=HERE.parent/'execution'
sys.path[:0]=[str(EXECUTION/'src'),str(EXECUTION/'tests')]
import recovery_core as r
from gen_importer_v2 import load_handoff
from production_generation_entry_v2 import ProductionEntry

candidates=sorted((EXECUTION/'fixtures').glob('trusted-*/producer.namespace-recovery/RECONCILED_HANDOFF.v2.json'))
fixture=None
for candidate in candidates:
    root=candidate.parent.parent
    if (root/'producer.namespace-recovery/finish.receipt.json').exists() and (root/'fixture.disabled-grant.json').exists():
        fixture=root;break
assert fixture is not None
raw_grant=fixture/'fixture.disabled-grant.json'
g=r.read(raw_grant);g['_grant_ref']=r.ref(raw_grant)
ref_v2=r.ref(fixture/'producer.namespace-recovery/RECONCILED_HANDOFF.v2.json')
ref_v1=r.ref(fixture/'producer.namespace-init/INIT_RESOURCE_HANDOFF.json')
h=r.read(ref_v2['path'])
rows_v2,digest=load_handoff(ref_v2,g)
rows_v1,_=load_handoff(ref_v1,g)
assert len(rows_v2)==14+h['recovery_measurement_count']
assert rows_v2==h['measurements']
assert len(rows_v1)==14
entry=ProductionEntry.__new__(ProductionEntry)
entry.sidecar=SimpleNamespace(grant={'reconciliation_grant_ref':g['_grant_ref'],
    'namespace_initialization_handoff':ref_v1,
    'entry_initial_archive_receipt':h['archive_receipt']})
bootstrap_rows,_=entry.bootstrap_receipts(h['index_receipt'])
assert len(bootstrap_rows)==14
result={
    'scope':'Read-only completed TEST_ONLY fixture; no GEN, model, Library, or producer dispatch',
    'fixture':str(fixture),
    'v2_exact_base14_plus_k':len(rows_v2)==14+h['recovery_measurement_count'],
    'base_measurements':len(rows_v1),'k':h['recovery_measurement_count'],'v2_measurements':len(rows_v2),
    'recovery_delta_rows_with_wall_semantics':sum('wall_semantics' in m for m in rows_v2[14:]),
    'v2_unknown':h['unknown'],'CPU_cap_certification':h['CPU_cap_certification'],
    'complete_CPU_upper_bound_claimed':h['complete_CPU_upper_bound_claimed'],
    'load_handoff_accepts_v1_after_complete_recovery':len(rows_v1)==14,
    'v2_production_entry_bootstrap_accepts_v1_after_complete_recovery':len(bootstrap_rows)==14,
    'omitted_recovery_rows_if_GEN_grant_points_to_base_v1':len(rows_v2)-len(bootstrap_rows),
}
(HERE/'completed_fixture_results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
