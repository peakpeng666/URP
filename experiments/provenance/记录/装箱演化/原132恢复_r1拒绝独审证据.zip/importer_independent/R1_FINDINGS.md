# R1 independent GEN integration findings

**Decision: HOLD.** Two unconditional P1 compatibility blockers and one conditional P1 recovered-import gap. Reviewed actual received source against original GEN; no real GEN/producer, Library, model, INIT helper or assembler dispatch. Received/execution files were not modified by this review. No getter/TOCTOU reproduction.

Received `FILE_MANIFEST.json` SHA256: `822ab109e9463aafbf40631bf5453ae7976fe62a87282c6db7834be0fed94fce`. Post-check integrity: 51/51 manifest entries match; 11 available original GEN reference files match the baseline.

## R1-GEN-1 — P1: new deltas are rejected by the actual ledger

`recovery_core.py:37–43` omits `wall_semantics`; `gen_importer_v2.py:33–47` and `production_generation_entry_v2.py:148–163` return/forward rows unchanged. The pinned `references/generation/durable_generation_sidecar.py:372–390` requires `local_stage_inclusive_no_wait_deduction`, skips the missing-field row's CPU/wall accumulation, and records unknown. Its state halts at `:286`.

Independent trusted in-memory fixture: actual recovery sample → actual Sidecar.finish resulted in unknown/halt and no recovery-process CPU checkpoint. A control differing only by the semantic field passed. Completed TEST_ONLY v2 contains 14+32=46 rows; all32 deltas omit that field. This is fail-closed, not a successful import; the immutable initialization journal would be stranded.

Evidence: `check_boundaries.py`, `boundary_results.json`, `completed_fixture_results.json`.

## R1-GEN-2 — P1: v2 callables fail the unchanged operational path gate

New entry `local` (`production_generation_entry_v2.py:172–177`) forwards functions defined in the new v2 file (`:226–286`). Sidecar `invoke_local` only recognizes the exact operational entry `OPERATIONAL_ROOT/production_generation_entry.py` (`durable_generation_sidecar.py:444–458`), besides its pinned package/external-contract sources. Correct new operational-source hashes alone do not add a permitted path.

Independent fixture: actual v2 reserve_next with correct path/hash was rejected before begin; unchanged v1 callable passed the same source gate and hit a TEST_ONLY stop before any begin/dispatch. The ordinary entry reserves the slot before reaching the incompatible gate.

Evidence: `check_boundaries.py`, `boundary_results.json`.

## R1-GEN-3 — P1 conditional: base v1 can omit all recovery deltas

`gen_importer_v2.py:6–7` returns v1 rows immediately; `production_generation_entry_v2.py:117–127` does not require v2. `tests/test_recovery.py:71–73` explicitly expects that base-v1 acceptance after recovery.

Read-only completed-fixture test: load_handoff and v2 bootstrap both accepted recovered namespace base v1 and returned14, omitting32. This requires a future GEN grant to point to v1; an exact reviewed v2 pin prevents it. Treat this condition separately from the two unconditional blockers. The recovered activation contract must reject base-v1 selection.

Evidence: `check_completed_fixture.py`, `completed_fixture_results.json`.

## Supported results and coverage limit

The v2 importer structurally returns exact14+k, checks base14/16, receipt pins, completion seals and the original60 SELF/240wall pool, and preserves unknown/NOT_ESTABLISHED claims. Those checks do not establish downstream ledger acceptance. The author test uses `ProductionEntry.__new__` plus SimpleNamespace and only calls bootstrap (`test_recovery.py:102–111`); it misses both actual consumer boundaries. Disabled/null activation placeholders remain appropriate.

Full source analysis: `IMPORTER_AUDIT.md`. Integrity: `source_integrity.json`. No additional tests or changes are needed to establish these R1 findings.
