"""Audit-only ordinary trusted fixtures, no real GEN/producer/Library dispatch.
The received modules remain unchanged and are imported with bytecode disabled.
Sidecar journal publication is replaced by in-memory event capture. invoke_local
checks stop before begin and therefore cannot call the supplied stage function.
"""
import contextlib
import importlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
RECEIVED = HERE.parent / 'received'
sys.path[:0] = [str(RECEIVED / 'src'), str(RECEIVED / 'references/generation')]
import recovery_core as r
import durable_generation_sidecar as d
import production_generation_entry_v2 as v2
import production_generation_entry as original

class MemoryFinish(d.Sidecar):
    def __init__(self):
        self.token = {'scope': 'init_final', 'stage': 'initialization', 'started': d.self_sample()}
        self.events = [{'kind': 'begin', 'payload': self.token}]
        self.grant = {}
    def locked(self):
        return contextlib.nullcontext()
    def _events(self):
        return self.events
    def _append(self, events, kind, payload):
        event = {'kind': kind, 'payload': payload}
        self.events.append(event)
        return event

class BoundaryReached(Exception):
    pass

class NoDispatch(d.Sidecar):
    def __init__(self, module):
        target = str(Path(module.__file__).resolve())
        digest = d.filehash(target)
        self.grant = {
            'local_call_targets': {'reserve_next': {'path': target, 'sha256': digest, 'function': 'reserve_next'}},
            'operational_source_files': {target: digest},
        }
        self.binding = {'package_path': str(HERE / 'TEST_ONLY_package'),
                        'external_source_root': str(HERE / 'TEST_ONLY_external'),
                        'source_files': {}, 'external_source_files': {}}
        self.boundary_called = False
    def begin(self, *args, **kwargs):
        self.boundary_called = True
        raise BoundaryReached('TEST_ONLY stop before stage begin or callable dispatch')

measurement = r.sample()
raw_consumer = MemoryFinish()
raw_state = raw_consumer.finish(raw_consumer.token, local_receipts=[measurement])
assert 'unknown_stage_outcome_or_measurement' in raw_state['halt']
assert measurement['process'] not in raw_state['process_CPU_checkpoints']
assert raw_consumer.events[-1]['payload']['outcome'] == 'unknown'
# A control fixture changes only the one required schema field; no production
# code or receipt is edited. It demonstrates the exact incompatibility.
control = dict(measurement, wall_semantics='local_stage_inclusive_no_wait_deduction')
control_consumer = MemoryFinish()
control_state = control_consumer.finish(control_consumer.token, local_receipts=[control])
assert control_state['halt'] == []
assert measurement['process'] in control_state['process_CPU_checkpoints']

routing = {}
for label, module in [('new_v2_entry', v2), ('unchanged_v1_entry_control', original)]:
    consumer = NoDispatch(module)
    try:
        consumer.invoke_local('TEST_ONLY_slot', 'reserve_next', module.reserve_next, None, 1)
    except BoundaryReached as error:
        routing[label] = {'accepted_by_source_gate': True, 'begin_called': consumer.boundary_called,
                          'dispatches': 0, 'result': str(error)}
    except d.Stop as error:
        routing[label] = {'accepted_by_source_gate': False, 'begin_called': consumer.boundary_called,
                          'dispatches': 0, 'result': str(error)}
assert routing['new_v2_entry']['accepted_by_source_gate'] is False
assert routing['new_v2_entry']['begin_called'] is False
assert routing['unchanged_v1_entry_control']['accepted_by_source_gate'] is True

result = {
    'audit_scope': 'TEST_ONLY ordinary in-memory downstream contract fixtures; no production activation',
    'received_sources_unchanged': True,
    'real_Library_calls': 0, 'model_calls': 0, 'producer_dispatches': 0,
    'measurement_compatibility': {
        'raw_recovery_sample_has_wall_semantics': 'wall_semantics' in measurement,
        'raw_delta_imported_into_CPU_checkpoints': measurement['process'] in raw_state['process_CPU_checkpoints'],
        'raw_outcome': raw_consumer.events[-1]['payload']['outcome'],
        'raw_halt': raw_state['halt'],
        'semantic_field_only_control_outcome': control_consumer.events[-1]['payload']['outcome'],
        'semantic_field_only_control_halt': control_state['halt'],
    },
    'callable_source_gate': routing,
}
(HERE / 'boundary_results.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
