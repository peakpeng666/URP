# Independent Phase2 v2 handoff / GEN wiring audit

Date: 2026-10-06 UTC. Decision: **do not accept the current GEN integration for activation**. Two independently reproduced compatibility blockers prevent the shipped v2 rows/entry from working with its unchanged GEN sidecar. A third, conditional v1 selection gap must be covered by the explicit activation contract.

## Scope and evidence boundaries

Reviewed the actual received Python/JSON source and the original baseline at `original132_phase2_generation_accounting_20261006`. The received tree was read only. No real Library, model, producer, GEN, original INIT helper, or original assembler operation was run. No stopped getter/TOCTOU reproduction was run. No authorization file was activated. All new test scripts/results are in this audit directory.

The standalone boundary tests import unchanged received modules with `python3 -I -B`; they use ordinary in-memory journal capture and an explicit stop before any local stage begins. The completed-fixture check reads an already completed, labeled TEST_ONLY relocated fixture prepared by the parent audit. That fixture's historical values are retained, but paths and grant/receipt bindings are relocated test data, not authentic production completion evidence.

## Finding 1 — P1: recovery measurement schema is rejected by the actual GEN consumer

Source chain:

- `src/recovery_core.py:37–43` builds every genuine new recovery sample without `wall_semantics`.
- `src/recovery_core.py:44–56` validates samples without requiring that field, so internal recovery admission accepts them.
- `src/reconciled_handoff.py:39–47` includes those samples directly in the v2 handoff.
- `src/gen_importer_v2.py:33–47` validates and returns the same measurements without consumer-schema conversion.
- `src/production_generation_entry_v2.py:148–163` passes the inherited rows unchanged to `Sidecar.finish`.
- `references/generation/durable_generation_sidecar.py:372–390` requires `wall_semantics == 'local_stage_inclusive_no_wait_deduction'`. A missing value raises its Stop inside the receipt loop, marks the outcome unknown, and skips the row's CPU/checkpoint and wall accumulation.
- The resulting unknown outcome creates a durable halt at `durable_generation_sidecar.py:286`, and `_boundary` rejects that halt at `production_generation_entry_v2.py:163`.

Independent ordinary-fixture result: actual `recovery_core.sample()` supplied to actual `Sidecar.finish()` produced outcome `unknown`, halt `unknown_stage_outcome_or_measurement`, and no checkpoint entry for the recovery sample's process. A separate control receipt differing only by the required `wall_semantics` field produced `confirmed` and no halt. These were in-memory fixture events, not a live GEN run.

The parent's completed relocated fixture has 14 base rows + 32 recovery rows = 46. All 32 recovery rows lack the required semantic field. Genuine original INIT samples already contain it (`references/init/init_local_helper.py:48–55`). The fixture Clock also omits the field (`tests/fixture_support.py:12–17`), so the synthetic remaining base rows would have the same problem if sent to the real consumer.

Impact: this is fail-closed, not successful downstream import. A real initialization would save its initialization output before `finish`, then leave a halted accounting journal. It cannot prove all 14+k charges were imported once, and retry is intentionally forbidden. Merely editing the future source-map/activation grant cannot repair the schema mismatch.

## Finding 2 — P1: new local entry callables fail the unchanged sidecar source gate

Source chain:

- `src/production_generation_entry_v2.py:172–177` passes `LOCAL_FUNCTIONS[stage]` to `sidecar.invoke_local`.
- These functions are defined in the new file (`:226–286`), so `inspect.getsourcefile(function)` is `src/production_generation_entry_v2.py`.
- `references/generation/durable_generation_sidecar.py:444–458` admits package sources, fixed external source-contract sources, or the exact operational file `OPERATIONAL_ROOT / 'production_generation_entry.py'`.
- With the shipped dependency, that last path is `references/generation/production_generation_entry.py`, not the new v2 file.
- The draft lists the new file as a compatibility source (`GEN_IMPORT_COMPATIBILITY.DRAFT.json:16–22`) and the unchanged sidecar as a dependency (`:24–33`). Adding correct new operational hashes does not change the sidecar's exact-path allowlist.

Independent ordinary-fixture result: the actual new `reserve_next` function, with its correct path and SHA in `local_call_targets` and `operational_source_files`, was rejected with `callable outside approved package, external source contract and fixed operational entry` before `begin`. The unchanged original function with corresponding correct pins passed the source gate and then hit the fixture's explicit stop before any begin/dispatch. Neither callable was executed.

Impact: even after fixing measurement compatibility, the first v2 local stage fails. The normal entry reserves the first slot before this source gate (`production_generation_entry_v2.py:175–177`), so the failure can leave a reservation without its stage. It does not dispatch a model, but it is not an operational GEN route. An explicitly reviewed routing change or reuse of appropriately pinned original function objects is needed; no changes were made in this audit.

## Finding 3 — P1 / conditional activation contract: recovered namespace can still select base v1 and omit k

- `src/gen_importer_v2.py:6–7` immediately returns the base v1 measurements; it does not reject v1 when a recovery journal/full v2 exists.
- `src/production_generation_entry_v2.py:117–127` accepts that result without requiring schema v2.
- `tests/test_recovery.py:71–73` explicitly expects base v1 import after complete recovery.

The read-only completed-fixture check confirmed that both `load_handoff` and the new entry's `bootstrap_receipts` accepted the completed recovered namespace's base v1 and returned 14 rows, omitting all 32 recovery rows. This requires a future GEN grant to point to v1; a correctly reviewed exact v2 reference would avoid it. Therefore it is separate from the two unconditional compatibility blockers. The future activation must enforce explicit v2 for the recovered namespace, and a regression test should show base-v1 selection cannot silently satisfy the recovered-import contract.

## What is supported by the current code

- Strict base cardinality is retained: `recovery_core.py:293–314` requires 14 measurements and 16 exact receipt references, checks matching original records/commits, frozen hashes, and identity constraints.
- The v2 branch retains exact base+delta structural equality, receipt hashes, contiguous delta-intent references, observed-total checks, and same-pool admission (`gen_importer_v2.py:18–44`).
- In the completed trusted fixture, all 46 rows are returned exactly by the v2 importer. This is a structural importer result, not proof that the GEN ledger accepted the rows.
- `reconciled_handoff.py:27–31` and `gen_importer_v2.py:14–15,45–46` retain `CPU_cap_certification=NOT_ESTABLISHED`, no complete CPU upper-bound claim, the historical unknown object, and new post-checkpoint CPU/wall tails as null. The base handoff remains hash-referenced rather than rewritten.
- The shared pool is exactly 60 SELF checkpoint seconds / 240 local-inclusive wall seconds and `new_budget=false`; admission sums the existing and new measurements (`recovery_core.py:57–69,98`).
- The offline `ImportOnce` harness uses exclusive intent/receipt publication (`gen_importer_v2.py:48–55`). Production duplicate protection instead depends on the unchanged durable sidecar's initialization-stage journal and once-only root creation, not just the in-object `_bootstrap_handoff_imported` marker.
- The compatibility draft remains disabled, with actual v2/index/archive references null (`GEN_IMPORT_COMPATIBILITY.DRAFT.json:3–7,35–41`). Those nulls are honest pre-activation placeholders, not a separate defect.

## Test coverage limitation

`tests/test_recovery.py:102–111` creates the entry via `__new__`, supplies only a SimpleNamespace grant, and calls `bootstrap_receipts`. It does not call `_boundary`, `Sidecar.finish`, `local`, or the callable source gate. The `ImportOnce` success test at `:7–18` is a separate offline harness. Therefore the author test passes and “imports all rows once” assertion do not establish actual GEN consumer compatibility. The README acknowledges bootstrap-only testing (`README.md:22`).

The original baseline already contains trusted synthetic durable integration examples (`test_production_entry_durable_integration.py:14–20,140–157,164–205`) showing how to exercise the real sidecar without real producer/Library dispatch. Equivalent v2 coverage is needed after changes, including consumer accepted totals, once-only restart behavior, explicit v2 selection, unknown fields, and the first local source gate.

## Reproduction artifacts

- `check_boundaries.py` / `boundary_results.json`: two blockers and their narrow controls; no output files outside this audit directory.
- `check_completed_fixture.py` / `completed_fixture_results.json`: read-only 14+32 exact return, missing semantic tags, preserved unknown/cap claims, and conditional v1 fallback evidence.
- `source_integrity.json`: received manifest and original GEN reference comparisons after these checks.

Commands:

`python3 -I -B importer_independent/check_boundaries.py`

`python3 -I -B importer_independent/check_completed_fixture.py`

The latter depends on the parent's already prepared labeled TEST_ONLY execution fixture. It does not modify the fixture or generate real recovery evidence.
