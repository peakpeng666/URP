'use strict';
// Ordinary Error and plain trusted tool objects. No connector, process, getter or race.
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const root=path.join(__dirname,'received');
const {recoverSuffix}=require(path.join(root,'src/suffix_bridge.js'));
const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
const g=JSON.parse(fs.readFileSync(path.join(root,'RECOVERY_GRANT.DEVELOPMENT.json'),'utf8'));
const gt=JSON.stringify({...g,execution_granted:true,independent_review_accepted:true});
const sources={commit:fs.readFileSync(path.join(root,'references/init/library_commit_v2.js'),'utf8'),
 retention:fs.readFileSync(path.join(root,'references/retention/retain_library_replies.js'),'utf8'),
 adapter:fs.readFileSync(path.join(root,'references/init/init_exec_adapter.js'),'utf8')};
const state={pending:null,position:0,archiveCreates:0,helperCalls:[],beforeAttempts:[],retainedExceptionCalls:0};
const tools={
 async exec_command(a){
  if(a.cmd.includes(g.recovery_cli_path)){
   const m=/ (enter|before|after|payload|finish) <<'RECOVERY_JSON'\n([^\n]*)\nRECOVERY_JSON$/.exec(a.cmd);
   if(!m)throw Error('TEST_ONLY unexpected CLI command');
   const b=JSON.parse(m[2]);
   if(m[1]==='before'){
    state.beforeAttempts.push(b.stage);
    if(state.pending)throw Error('TEST_ONLY unresolved effect: '+state.pending);
    if(g.suffix_actions[state.position]!==b.stage)throw Error('TEST_ONLY wrong order');
    state.pending=b.stage;
   }
   if(m[1]==='after'){if(state.pending!==b.stage)throw Error('TEST_ONLY wrong close');state.pending=null;state.position++;}
   return {exit_code:0,output:'{}'};
  }
  const m=/--step '(index|archive)\.([^']+)'/.exec(a.cmd);
  if(!m)throw Error('TEST_ONLY unsupported helper');
  state.helperCalls.push(m[1]+'.'+m[2]);
  if(a.cmd.includes("'exception'"))state.retainedExceptionCalls++;
  return {exit_code:0,output:JSON.stringify(m[2]==='receipt'?{library_file_id:g.index.library_file_id,
   file_id:g.index.file_id,current_version_number:0,write_result_confirmed:true,
   index_readback_confirmed:true,remote_bytes_verified:false}: {})};
 },
 async mcp__codex_apps__library_read(){return JSON.parse(fs.readFileSync(path.join(root,'evidence/recovery_diagnostic/CURRENT_READ.raw.json'),'utf8'));},
 async mcp__codex_apps__library_create_library_file(){state.archiveCreates++;throw Error('TEST_ONLY ORIGINAL ARCHIVE ERROR');}
};
(async()=>{
 let thrown;
 try{await recoverSuffix(tools,gt,hash(gt),'/tmp/TEST_ONLY_NEVER_MATERIALIZED.grant.json',sources);}
 catch(e){thrown=e.message;}
 const out={fixtureOnly:true,actualConnectorCalls:0,actualHelperProcesses:0,...state,
  originalError:'TEST_ONLY ORIGINAL ARCHIVE ERROR',returnedError:thrown,
  originalErrorPreserved:thrown==='TEST_ONLY ORIGINAL ARCHIVE ERROR'};
 fs.writeFileSync(path.join(__dirname,'EXCEPTION_BOUNDARY_RESULTS.json'),JSON.stringify(out,null,2)+'\n');
 process.stdout.write(JSON.stringify(out,null,2)+'\n');
})().catch(e=>{process.stderr.write(e.stack+'\n');process.exitCode=1;});
