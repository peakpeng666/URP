'use strict';
// Transport only: execute the reviewed bridge once; platform tools are supplied by the assistant.
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const cfg=JSON.parse(fs.readFileSync(process.argv[2]));
if(cfg.offlineFixture===true)throw new Error('real migration refuses fixture mode');
if(crypto.createHash('sha256').update(fs.readFileSync(cfg.bridgePath)).digest('hex')!=='7861e63bc91ace8211d60603ff2538bd6be38ccfc95d17296806955b8f3a67b9')throw new Error('reviewed bridge source mismatch');
fs.mkdirSync(cfg.rpcRoot,{mode:0o700});
let ordinal=0;const methods=['exec_command','apply_patch','mcp__codex_apps__library_replace_library_file','mcp__codex_apps__library_read','mcp__codex_apps__library_search'];
async function relay(method,args){
 const id=ordinal++,base=path.join(cfg.rpcRoot,String(id).padStart(4,'0'));
 const request={kind:'tool',id,method,args};fs.writeFileSync(base+'.request.json',JSON.stringify(request),{flag:'wx'});
 process.stdout.write(JSON.stringify(request)+'\n');
 const response=await new Promise((resolve,reject)=>{
  const started=Date.now();const timer=setInterval(()=>{
   try{if(fs.existsSync(base+'.response.json')){clearInterval(timer);resolve(JSON.parse(fs.readFileSync(base+'.response.json')))}
    else if(Date.now()-started>180000){clearInterval(timer);reject(new Error('native transport outcome unknown; no retry'))}}
   catch(error){clearInterval(timer);reject(error)}
  },25);
 });
 if(response.error){const error=new Error(response.error.message);error.name=response.error.name;throw error}
 return response.result;
}
const rawTools=Object.fromEntries(methods.map(method=>[method,args=>relay(method,args)]));
(async()=>{
 let result,error;
 try{result=await require(cfg.bridgePath).migrateBudget64k(rawTools,cfg)}
 catch(ex){error={name:ex.name,message:ex.message,stack:ex.stack}}
 const report={native_platform_tools:true,offlineFixture:false,bridge_invocations:1,success:!error,result:result??null,error:error??null,
  tool_requests:ordinal,OpenCode_launches:0,model_calls:0,GEN_calls:0,INIT_executions:0};
 fs.writeFileSync(cfg.resultPath,JSON.stringify(report),{flag:'wx'});
 process.stdout.write(JSON.stringify({kind:'final',success:report.success,result_path:cfg.resultPath,tool_requests:ordinal,error:error?.message??null})+'\n');
 if(error)process.exitCode=1;
})();
