"""One explicit empty-index budget transition. No API client, GEN, INIT, or retry.
Authentic external tools remain in the assistant bridge; these are local controls.
"""
import argparse, contextlib, copy, fcntl, hashlib, json, math, os, re, resource, runpy, shlex, sys, time, uuid, zipfile
from pathlib import Path
sys.dont_write_bytecode = True
ENTRY = time.monotonic()
PROCESS = str(os.getpid()) + ":" + uuid.uuid4().hex
OLD_SRC = Path('/workspace/original132-phase2-recovery-dev-20261006-8sdu8cov/revision2/src')
need0 = lambda ok: None if ok else (_ for _ in ()).throw(RuntimeError("original read-only resource validator pin"))
need0(hashlib.sha256((OLD_SRC/'recovery_core.py').read_bytes()).hexdigest() == '101ba2facae086210c02f44882e3bc062376567a033039508a0e102dd8970fa1')
sys.path.insert(0,str(OLD_SRC))
import recovery_core as base

class Stop(RuntimeError): pass
def need(v,why):
    if not v: raise Stop(why)
def canon(v): return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def sha(v): return hashlib.sha256(v).hexdigest()
def seal(v): return dict(v,sha256=sha(canon({k:x for k,x in v.items() if k!='sha256'})))
def verify(v): need(v.get('sha256')==seal(v)['sha256'],'seal mismatch')
def path(p):
    p=Path(p);need(p.is_absolute() and '..' not in p.parts and p.resolve()==p,'canonical path')
    need(not any(q.is_symlink() for q in (p,*p.parents)),'symlink forbidden');return p
def read(p): return json.loads(path(p).read_bytes())
def ref(p):p=path(p);return {'path':str(p),'file_sha256':sha(p.read_bytes())}
def checked(r):
    need(set(r)=={'path','file_sha256'},'exact reference');p=path(r['path']);need(sha(p.read_bytes())==r['file_sha256'],'file pin drift');return p
def publish(p,v):
    p=path(p);b=v if isinstance(v,bytes) else canon(v)
    fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    with os.fdopen(fd,'wb') as f:f.write(b);f.flush();os.fsync(f.fileno())
    fd=os.open(p.parent,os.O_RDONLY|os.O_DIRECTORY)
    try:os.fsync(fd)
    finally:os.close(fd)
    return ref(p)
def sample():
    r=resource.getrusage(resource.RUSAGE_SELF);end=time.monotonic()
    return {'process':PROCESS,'start':{'process':PROCESS,'self_cpu':0.0,'monotonic':ENTRY},
      'end':{'process':PROCESS,'self_cpu':r.ru_utime+r.ru_stime,'monotonic':end},
      'self_cpu_seconds':r.ru_utime+r.ru_stime,'wall_seconds':end-ENTRY,'local_inclusive_wall_seconds':end-ENTRY,
      'native_wait_union_seconds':0,'measurement_status':'known','RUSAGE_kind':'RUSAGE_SELF',
      'wall_semantics':'local_stage_inclusive_no_wait_deduction'}
def structured(raw):return base.unwrap(raw)
def old_resources(g):
    gr=read(checked(g['original_reconciliation_grant_ref']));gr['_grant_ref']=g['original_reconciliation_grant_ref']
    from gen_importer_v2 import load_handoff
    rows,digest=load_handoff(g['old_INIT_v2_ref'],gr)
    need(len(rows)==46,'original46 required');return rows,digest
def grant(reference,offline=False):
    g=read(checked(reference))
    need(g['schema']=='p2-budget64k-empty-index-transition-grant-v1','transition grant schema')
    need(g['generation_execution_granted'] is False and g['numeric_execution_granted'] is False,'migration scope only')
    if offline:
        need(g.get('TEST_ONLY') is True and g['migration_execution_granted'] is False,'explicit offline scope')
        need(path(g['producer_workspace']).is_relative_to(Path(__file__).resolve().parents[1]/'fixtures'),'fixture workspace isolation')
    else:need(g['migration_execution_granted'] is True and g['independent_review_accepted'] is True and not g.get('TEST_ONLY'),'transition disabled')
    need(g['pool']=={'SELF_checkpoint_seconds':60,'local_inclusive_wall_seconds':240,'new_budget':False},'original same pool')
    for p,h in g['source_pins'].items():need(ref(p)['file_sha256']==h,'transition source drift')
    need(g['source_pins'].get(str(Path(__file__).resolve()))==ref(__file__)['file_sha256'],'core source missing')
    a=read(checked(g['budget_amendment_ref']));verify(a)
    need(a['completion_tokens_per_request']==64000 and a['scope']['logical_requests']==60
         and a['scope']['EOH_TC']==a['scope']['IID_TC']==30,'exact64k scope')
    cfg=read(checked(g['new_config_ref']));fr=read(checked(g['new_freeze_ref']));verify(fr)
    need(cfg['provider']['zhipuai-coding-plan']['models']['glm-5.3']['limit']['output']==64000
         and fr['configuration']['max_completion_tokens']==fr['configured_settings']['max_completion_tokens']==64000
         and fr['CLI_environment_budget_override']=={'OPENCODE_EXPERIMENTAL_OUTPUT_TOKEN_MAX':'64000'},'64k dual launch budget')
    need(fr['config_file_sha256']==g['new_config_ref']['file_sha256'] and fr['output_budget_amendment_ref']==g['budget_amendment_ref'],'budget freeze pins')
    need(g['journal_root']==g['producer_workspace']+'/phase2-budget-migration','one transition journal')
    need(g['operation_id']=='urp132_P2_budget64k_transition','fixed operation')
    return g
def verify_archive(g):
    archive=checked(g['original_archive_ref']);receipt=read(checked(g['original_archive_receipt_ref']))
    h=read(checked(g['old_INIT_v2_ref']))
    need(receipt==h['archive_receipt'] and receipt['current_version_number']==0
         and receipt['local_blob_sha256']==sha(archive.read_bytes()),'unchanged original archive')
    with zipfile.ZipFile(archive) as z:
        need(z.namelist()==['file-hashes.json','wave-manifest.json'] and z.testzip() is None,'original empty archive shape')
        m=json.loads(z.read('wave-manifest.json'));need(m['phase']==2 and m['slots']==[] and not {'freeze_sha256','config_file_sha256'}&set(m),'archive has no budget payload')
def verify_old(g,raw_refs):
    old=read(checked(g['old_index_ref']));verify(old);receipt=read(checked(g['old_index_receipt_ref']));h=read(checked(g['old_INIT_v2_ref']))
    need(old['rows']==[] and old['archives']=={} and receipt==h['index_receipt'],'original empty INIT head/receipt')
    need(old['freeze_sha256']==g['old_freeze_sha256'] and old['run_id']==g['operational_run_id']
         and receipt['current_version_number']==0 and receipt['library_file_id']==g['index_library_file_id']
         and receipt['file_id']==g['old_index_backing_file_id'] and receipt['local_blob_sha256']==g['old_index_ref']['file_sha256'],'exact old identity/version')
    need(1 <= len(raw_refs) <= 2,'old head and backing reads required')
    seen=set()
    for rr in raw_refs:
        raw=read(checked(rr));need(raw.get('isError') is False,'old read outcome')
        value=structured(raw);need(isinstance(value,dict) and 1 <= len(value.get('results',[])) <= 2,'old exact read result')
        for r in value['results']:
            need(r['ref_id'] not in seen,'duplicate old read target');seen.add(r['ref_id'])
            need(r['library_file_id']==receipt['library_file_id'] and r['file_id']==receipt['file_id']
                 and r['has_more'] is False and not r.get('warnings') and r.get('version_id') in (None,0,'0'),'old read identity/version')
            need(isinstance(r['content'],list) and all(type(x)is str for x in r['content'])
                 and '\n'.join(r['content']).encode()==checked(g['old_index_ref']).read_bytes(),'old read exact bytes')
    need(seen=={g['index_library_file_id'],g['old_index_backing_file_id']},'two exact old targets')
    return old,receipt

class Journal:
    def __init__(self,reference,offline=False):
        self.reference=reference;self.offline=offline;self.g=grant(reference,offline);self.root=path(self.g['journal_root']);self.w=path(self.g['producer_workspace'])
    def costs(self):
        out=[];refs=[]
        for i,p in enumerate(sorted(self.root.glob('cost-*.json'))):
            need(p.name==f'cost-{i:04d}.json','cost journal contiguous')
            v=read(p);verify(v);need(v['grant_ref']==self.reference and v['outcome']=='confirmed','unknown transition checkpoint')
            base.validate_measurement(v['measurement']);out.append(v['measurement']);refs.append(ref(p))
        return out,refs
    def admission(self,current=True):
        old,_=old_resources(self.g);new,_=self.costs() if self.root.exists() else ([],[])
        return base.admission(old+new,sample() if current else None)
    def cost(self,outcome='confirmed'):
        n=len(list(self.root.glob('cost-*.json')))
        return publish(self.root/f'cost-{n:04d}.json',seal({'grant_ref':self.reference,'outcome':outcome,'measurement':sample()}))
    def halt(self):
        if not (self.root/'HALTED.json').exists():publish(self.root/'HALTED.json',{'outcome':'unknown','no_retry':True})
    def ready(self):
        need(self.root.is_dir() and not (self.root/'HALTED.json').exists() and not (self.root/'transition.receipt.json').exists()
             and not (self.root/'finish.intent.json').exists(),'transition halted/finished/unknown; no replay')
        intent=read(self.root/'transition.intent.json');verify(intent);need(intent['grant_ref']==self.reference,'transition intent grant')
        self.admission();return intent
    def prepare(self,raw_refs):
        need(not self.root.exists(),'transition already reserved; never re-enter INIT')
        need(not any((self.w/f).exists() for f in ['phase2-generation-accounting','phase2-bridge-journal','state/external-pending.json']),'GEN or unknown producer state')
        old,receipt=verify_old(self.g,raw_refs);verify_archive(self.g);self.admission()
        new=copy.deepcopy(old);new['freeze_sha256']=read(checked(self.g['new_freeze_ref']))['sha256'];new=seal(new)
        need(new['freeze_sha256']!=old['freeze_sha256'],'budget freeze must change')
        target=path(self.g['new_index_path']);need(target.parent==self.w and not target.exists(),'new retained local head path')
        self.root.mkdir(mode=0o700)
        publish(self.root/'transition.intent.json',seal({'grant_ref':self.reference,'operation_id':self.g['operation_id'],'old_index_ref':self.g['old_index_ref'],
            'old_index_receipt_ref':self.g['old_index_receipt_ref'],'old_authenticated_reads':raw_refs,'new_index_sha256':sha(canon(new)),
            'index_library_file_id':receipt['library_file_id'],'expected_current_version':0,'same_pool':True,'INIT_execution':False}))
        publish(target,new)
        return {'new_index_path':str(target),'index_library_file_id':receipt['library_file_id'],'expected_current_version':0}
    def events(self):
        rows=[]
        for i,p in enumerate(sorted(self.root.glob('tool-*.intent.json'))):
            need(p.name==f'tool-{i:03d}.intent.json','tool intents contiguous');v=read(p);verify(v)
            rp=p.with_name(p.name.replace('.intent.','.receipt.'))
            if not rp.exists():need(i==len(list(self.root.glob('tool-*.intent.json')))-1,'earlier unresolved tool')
            else:
                r=read(rp);verify(r);need(r['intent_sha256']==v['sha256'] and r['outcome']=='confirmed','unknown tool, no retry');v['receipt']=r
            rows.append(v)
        return rows
    def tool_begin(self,method,args):
        self.ready();rows=self.events();need(not rows or 'receipt' in rows[-1],'unresolved tool; no replay')
        count=lambda name:sum(r['method']==name for r in rows)
        allowed={'exec_command','apply_patch','mcp__codex_apps__library_replace_library_file','mcp__codex_apps__library_read','mcp__codex_apps__library_search'}
        need(method in allowed,'unexpected transition tool')
        write=[r for r in rows if r['method']=='mcp__codex_apps__library_replace_library_file']
        if method=='mcp__codex_apps__library_replace_library_file':
            need(not write and count('exec_command')==1 and (self.w/'state/external-pending.json').exists(),'one fenced replacement only')
            need(args=={'library_file_id':self.g['index_library_file_id'],'file':self.g['new_index_path'],'expected_current_version':0,
                       'version_reason':'V2 bounded journal/wave persistence; retain identity'},'exact Library CAS target')
        elif method=='exec_command':
            need(count(method)<4,'exact four original local helper calls')
            cmd=args['cmd'];script,argv=self.helper_command(cmd);i=count(method)
            expected=[(str(self.w/'src/external_commit_fence_v2.py'),['begin',str(self.w),self.g['new_index_path'],self.g['index_library_file_id'],'0','index']),
              (str(self.w/'.library-helpers-current/library_file_transfer.py'),['apply-xattrs',self.g['new_index_path'],self.g['index_library_file_id']]),
              (str(self.w/'src/commit_receipt_v2.py'),[self.g['new_index_path'],'0','index',str(self.w/'state'/f'readback-{self.g["index_library_file_id"]}-1.json')]),
              (str(self.w/'src/external_commit_fence_v2.py'),['confirm',str(self.w),self.g['new_index_path'],self.g['index_library_file_id'],'0','index'])]
            need((script,argv)==expected[i],'original helper exact route/order/arguments')
            need(i==0 or len(write)==1,'helpers after confirmed write required')
        else:
            need(len(write)==1,'read/local staging without confirmed write')
            item=structured(write[0]['receipt']['raw'])
            if method=='mcp__codex_apps__library_read':
                need(count(method)<3,'bounded existing read/fallback plus current head')
                target=self.g['index_library_file_id'] if count('exec_command')==4 else item['file_id']
                need(args=={'read':[{'ref_id':target,'mode':'full','max_lines':2}]},'exact new backing/current head read')
            elif method=='mcp__codex_apps__library_search':
                need(count(method)==0 and count('mcp__codex_apps__library_read')==1,'only original read fallback search')
                need(args=={'search_query':[{'q':json.dumps(item['file_name'],ensure_ascii=False,separators=(',',':')),'search_title_only':True}],
                  'scope':{'file_refs':[{'file_id':item['file_id'],'library_file_id':item['library_file_id']}],'surfaces':['library']},
                  'surfaces':['library'],'top_k':1,'result_format':'metadata_only'},'exact original bounded fallback')
            else:
                need(count(method)==0 and count('exec_command')==2,'one retained readback patch')
                expected='*** Begin Patch\n*** Add File: '+str(self.w/'state'/f'readback-{self.g["index_library_file_id"]}-1.json')+'\n+'
                need(isinstance(args,str) and args.startswith(expected),'exact local readback staging path')
        value=seal({'grant_ref':self.reference,'ordinal':len(rows),'method':method,'arguments':args,
          'command_sha256':sha(args['cmd'].encode()) if method=='exec_command' else None,
          'invocation_id':f'budget64k_helper_{len(rows):03d}','operation_id':self.g['operation_id']})
        publish(self.root/f'tool-{len(rows):03d}.intent.json',value);return value
    def helper_command(self,cmd):
        prefix=cmd.split(" <<",1)[0];words=shlex.split(prefix)
        need(words[:1]==['python3'],'fixed original Python prefix')
        i=2 if words[1]=='-I' else 1;script=words[i];argv=words[i+1:]
        need(script in self.g['helper_source_pins'] and ref(script)['file_sha256']==self.g['helper_source_pins'][script],'pinned unchanged helper')
        return script,argv
    def tool_end(self,ordinal,raw):
        self.ready();p=self.root/f'tool-{ordinal:03d}.intent.json';intent=read(p);verify(intent)
        need(not p.with_name(p.name.replace('.intent.','.receipt.')).exists(),'tool observation already retained')
        method=intent['method'];ok=not raw.get('isError',False)
        if method=='exec_command':ok=ok and raw.get('exit_code')==0
        if method=='mcp__codex_apps__library_replace_library_file':
            item=structured(raw);ok=ok and isinstance(item,dict) and item.get('status')=='succeeded' and item.get('library_file_id')==self.g['index_library_file_id'] and item.get('current_version_number')==1
        r=seal({'intent_sha256':intent['sha256'],'outcome':'confirmed' if ok else 'unknown','raw':raw})
        publish(p.with_name(p.name.replace('.intent.','.receipt.')),r)
        if not ok:self.halt();raise Stop('tool outcome unknown; fence preserved, no retry')
        return {'observed':True}
    def run_helper(self,invocation,command_sha,script,argv):
        self.ready();rows=self.events();need(rows and rows[-1]['method']=='exec_command' and 'receipt' not in rows[-1],'exact pending original helper')
        current=rows[-1];need(current['invocation_id']==invocation and current['command_sha256']==command_sha,'helper invocation pin')
        need(self.helper_command(current['arguments']['cmd'])==(script,argv),'helper argv equality')
        ip=self.root/(invocation+'.intent.json');need(not ip.exists(),'helper replay forbidden')
        publish(ip,seal({'grant_ref':self.reference,'original_tool_intent_sha256':current['sha256'],'script':script,
                         'script_sha256':ref(script)['file_sha256'],'command_sha256':command_sha}))
        saved_argv,saved_path=sys.argv,list(sys.path);raised=None
        try:
            sys.argv=[script,*argv];sys.path[:]=[str(Path(script).parent),*saved_path];runpy.run_path(script,run_name='__main__')
        except BaseException as exc:raised=exc
        finally:sys.argv=saved_argv;sys.path[:]=saved_path
        ok=raised is None or isinstance(raised,SystemExit) and raised.code in (0,None)
        publish(self.root/(invocation+'.receipt.json'),seal({'intent_ref':ref(ip),'outcome':'confirmed' if ok else 'unknown','script_sha256':ref(script)['file_sha256']}))
        if raised is not None and not ok:raise raised
    def finish(self,receipt):
        self.ready();rows=self.events();need(all('receipt'in r for r in rows),'unknown tool remains')
        writes=[r for r in rows if r['method']=='mcp__codex_apps__library_replace_library_file']
        need(len(writes)==1 and sum(r['method']=='exec_command' for r in rows)==4,'single original commit route required')
        item=structured(writes[0]['receipt']['raw']);need(receipt['library_file_id']==item['library_file_id'] and receipt['file_id']==item['file_id']
             and receipt['current_version_number']==1 and receipt['index_readback_confirmed'] is True
             and receipt['local_blob_sha256']==ref(self.g['new_index_path'])['file_sha256'],'exact new actual receipt')
        remote=[]
        for row in rows:
            if row['method']!='mcp__codex_apps__library_read':continue
            raw=row['receipt']['raw'];value=structured(raw);need(isinstance(value,dict) and len(value.get('results',[]))==1,'one actual new read')
            r=value['results'][0]
            need(r['library_file_id']==receipt['library_file_id'] and r['file_id']==receipt['file_id'] and r.get('version_id') in (None,1,'1')
                 and r['has_more'] is False and not r.get('warnings'),'new read identity/version changed')
            need('\n'.join(r['content']).encode()==checked(ref(self.g['new_index_path'])).read_bytes(),'new full readback bytes')
            remote.append(row['arguments']['read'][0]['ref_id'])
        need(set(remote)=={receipt['library_file_id'],receipt['file_id']},'new head and backing readback required')
        need(not (self.w/'state/external-pending.json').exists(),'original fence remains')
        new_receipt_path=self.w/'state/commits'/f'{receipt["library_file_id"]}-1.json'
        need(read(new_receipt_path)==receipt and read(checked(self.g['old_index_receipt_ref']))['current_version_number']==0,'new receipt retained; original0 preserved')
        verify_archive(self.g)
        for row in rows:
            if row['method']=='exec_command':
                h=read(self.root/(row['invocation_id']+'.receipt.json'));verify(h);need(h['outcome']=='confirmed','helper unknown')
        publish(self.root/'finish.intent.json',{'grant_ref':self.reference,'new_index_receipt_ref':ref(new_receipt_path)})
        self.admission();self.cost()
        ms,refs=self.costs();old,digest=old_resources(self.g);cpu,wall=base.totals(old+ms)
        value=seal({'schema':'p2-budget64k-confirmed-head-transition-v1','status':'CONFIRMED','grant_ref':self.reference,
          'old_INIT_v2_ref':self.g['old_INIT_v2_ref'],'old_INIT_v2_digest':digest,'original_measurement_count':46,'old_index_ref':self.g['old_index_ref'],
          'old_index_receipt_ref':self.g['old_index_receipt_ref'],'new_index_ref':ref(self.g['new_index_path']),'new_index_receipt_ref':ref(new_receipt_path),
          'new_index_receipt':receipt,'original_archive_ref':self.g['original_archive_ref'],'original_archive_receipt_ref':self.g['original_archive_receipt_ref'],
          'transition_measurement_refs':refs,'transition_measurements':ms,'combined_count':46+len(ms),'observed_combined_SELF_seconds':cpu,
          'observed_combined_local_window_seconds':wall,'pool':self.g['pool'],'unknown':{'JS_Library_provider_CPU_wait':None,'post_checkpoint_CPU_tails':None,'post_checkpoint_wall_tails':None},
          'CPU_cap_certification':'NOT_ESTABLISHED','INIT_executions':0,'model_calls':0,'generation_execution_granted':False,'numeric_execution_granted':False,
          'TEST_ONLY':self.offline})
        result=publish(self.root/'transition.receipt.json',value);return result

def confirmed_transition(reference,grant_reference,old_INIT_ref,new_receipt,offline=False):
    j=Journal(grant_reference,offline);v=read(checked(reference));verify(v)
    need(reference==ref(j.root/'transition.receipt.json') and v['status']=='CONFIRMED' and v['grant_ref']==grant_reference
         and v['old_INIT_v2_ref']==old_INIT_ref and v['new_index_receipt']==new_receipt,'transition exact receipt/INIT bridge')
    need(not (j.root/'HALTED.json').exists() and not (j.w/'state/external-pending.json').exists(),'transition unresolved')
    need(v['TEST_ONLY'] is offline and v['generation_execution_granted'] is False and v['INIT_executions']==v['model_calls']==0,'transition scope')
    need(read(j.root/'finish.intent.json')=={'grant_ref':grant_reference,'new_index_receipt_ref':v['new_index_receipt_ref']},'finish intent pin')
    need(v['old_index_ref']==j.g['old_index_ref'] and v['old_index_receipt_ref']==j.g['old_index_receipt_ref'],'old head trace pins')
    need(v['new_index_ref']==ref(j.g['new_index_path']) and v['new_index_receipt_ref']==ref(j.w/'state/commits'/f'{new_receipt["library_file_id"]}-1.json'),'new head retained pins')
    need(read(checked(v['new_index_receipt_ref']))==new_receipt,'actual new receipt changed')
    head=read(checked(v['new_index_ref']));verify(head);old=read(checked(j.g['old_index_ref']))
    expected=copy.deepcopy(old);expected['freeze_sha256']=read(checked(j.g['new_freeze_ref']))['sha256'];expected=seal(expected)
    need(head==expected and head['rows']==[],'new empty budget head exact')
    verify_archive(j.g);ms,refs=j.costs();need(v['transition_measurement_refs']==refs and v['transition_measurements']==ms,'complete migration costs, no omission/replay')
    base.admission(old_resources(j.g)[0]+ms)
    need(all('receipt'in r for r in j.events()),'unfinished transition tool')
    return ms

def main():
    p=argparse.ArgumentParser();p.add_argument('--grant',required=True);p.add_argument('--grant-sha256',required=True);p.add_argument('--offline-fixture',action='store_true')
    p.add_argument('action',choices=['begin','tool-begin','tool-end','finish','helper']);p.add_argument('--invocation-id');p.add_argument('--command-sha256');p.add_argument('--script');p.add_argument('arguments',nargs=argparse.REMAINDER)
    args=p.parse_args();j=Journal({'path':args.grant,'file_sha256':args.grant_sha256},args.offline_fixture)
    failed=False;result=None;donecost=False
    try:
        if args.action=='helper':
            argv=args.arguments[1:] if args.arguments[:1]==['--'] else args.arguments;j.run_helper(args.invocation_id,args.command_sha256,args.script,argv)
        else:
            b=json.load(sys.stdin)
            if args.action=='begin':result=j.prepare(b['old_read_refs'])
            elif args.action=='tool-begin':result=j.tool_begin(b['method'],b['arguments'])
            elif args.action=='tool-end':result=j.tool_end(b['ordinal'],b['raw'])
            else:result=j.finish(b['receipt']);donecost=True
    except BaseException:
        failed=True
        if j.root.exists() and not (j.root/'transition.receipt.json').exists():j.halt()
        raise
    finally:
        if j.root.exists() and not donecost and not (j.root/'transition.receipt.json').exists():j.cost('unknown' if failed else 'confirmed')
    if result is not None:print(canon(result).decode())
if __name__=='__main__':main()
