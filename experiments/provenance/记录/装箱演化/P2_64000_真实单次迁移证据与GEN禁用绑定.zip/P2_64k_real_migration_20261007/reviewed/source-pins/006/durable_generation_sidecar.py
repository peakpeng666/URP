"""Prospective production sidecar. No activation is shipped and no retry exists.

Immutable source files are called only through a separately pinned parent grant.
This module never imports a producer during contract inspection or journal reads.
"""
import contextlib
import fcntl
import hashlib
import inspect
import json
import math
import os
from pathlib import Path
import resource
import tempfile
import time
import uuid

POLICY_SHA = '0c6f3cee75693e0eacdaed3d2688c8a68e2f56a8c06e3da8870c612ef25e6a69'
ACCOUNTING_SHA = '31613ba9a9a6b7740db10622e18de417e74e09f52779b04a007531d691ec82fb'
INCLUSIVE_SUPPLEMENT_SHA = 'c66e64733e5a27bd48a3ad7056049e65afb6e2552d9d06da09b514c6e6fc9768'
WALL_PER_SLOT = 1020.0
WALL_TOTAL = 61440.0
WALL_INIT_FINAL = 240.0
STAGES = ('reserve_next', 'prepare_reserved', 'claim_commit', 'collect_reserved',
          'build_wave_archive', 'archive_commit', 'finish_index', 'terminal_commit', 'finish_position')
LIBRARY_STAGES = ('claim_commit', 'archive_commit', 'terminal_commit')
LOCAL_STAGES = set(STAGES) - set(LIBRARY_STAGES)
PROCESS = str(os.getpid()) + ':' + uuid.uuid4().hex
OPERATIONAL_ROOT = Path(__file__).resolve().parent
REQUIRED_OPERATIONAL_FILES = ('durable_generation_sidecar.py','library_stage_sidecar.py',
    'library_wait_observer.js','measured_local_helper.py','measured_exec_adapter.js')


class Stop(RuntimeError):
    pass


def need(v, reason):
    if not v:
        raise Stop(reason)


def canon(v):
    return json.dumps(v, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode()


def sha(v):
    return hashlib.sha256(v).hexdigest()


def sealed(v):
    return dict(v, sha256=sha(canon(v)))


def verify(v):
    need(v.get('sha256') == sha(canon({k: x for k, x in v.items() if k != 'sha256'})), 'seal mismatch')


def read(p):
    return json.loads(Path(p).read_bytes())


def filehash(p):
    return sha(Path(p).read_bytes())


def absolute(p):
    p = Path(p)
    need(p.is_absolute() and '..' not in p.parts and str(p) == str(p.resolve()), 'noncanonical path')
    need(not any(x.is_symlink() for x in (p, *p.parents)), 'symlink path')
    return p


def fsync_dir(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def publish_once(path, value):
    """Atomic exclusive publication. Incomplete temporaries make recovery unknown."""
    fd, tmp = tempfile.mkstemp(prefix='.pending-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as out:
            out.write(canon(value)); out.flush(); os.fsync(out.fileno())
        os.link(tmp, path)
        fsync_dir(path.parent)
    finally:
        os.unlink(tmp)
        fsync_dir(path.parent)


def self_sample():
    r = resource.getrusage(resource.RUSAGE_SELF)
    return {'process': PROCESS, 'pid': os.getpid(), 'monotonic': time.monotonic(),
            'self_cpu': r.ru_utime + r.ru_stime}


def local_measurement(start, end, wait_seconds=0.0):
    need(start['process'] == end['process'], 'cross-process sample')
    need(wait_seconds == 0, 'inclusive policy rejects every wait deduction')
    cpu, wall = end['self_cpu'] - start['self_cpu'], end['monotonic'] - start['monotonic']
    need(all(type(x) in (int, float) and math.isfinite(x) and x >= 0 for x in (cpu, wall, wait_seconds))
         and wait_seconds <= wall + 1e-6, 'invalid local measurement')
    return {'process': start['process'], 'start': start, 'end': end, 'self_cpu_seconds': cpu,
            'wall_seconds': wall, 'native_wait_union_seconds': wait_seconds,
            'local_inclusive_wall_seconds': wall, 'measurement_status': 'known',
            'wall_semantics': 'local_stage_inclusive_no_wait_deduction',
            'RUSAGE_kind': 'RUSAGE_SELF', 'native_CLI_CPU': None, 'provider_CPU': None}


def inspect_contract(package, policy_path, accounting_path, source_root=None):
    """Read-only inspection of actual bound P2 metadata; never reads P1 results."""
    package = absolute(package)
    need(filehash(policy_path) == POLICY_SHA, 'approved policy bytes changed')
    need(filehash(accounting_path) == ACCOUNTING_SHA, 'approved accounting bytes changed')
    policy, accounting = read(policy_path), read(accounting_path)
    plan, roster, manifest = (read(package / p) for p in ('PLAN.json', 'inputs/roster.json', 'PACKAGE_MANIFEST.json'))
    for value in (plan, roster, manifest):
        verify(value)
    expected = {'CPU_admission_budget_seconds': 1860, 'per_slot_self_CPU_allowance_seconds': 30,
                'initial_final_self_CPU_allowance_seconds': 60, 'active_bookkeeping_wall_budget_seconds': 7440,
                'per_slot_active_bookkeeping_wall_seconds': 120, 'initial_final_active_wall_seconds': 240,
                'Library_IO_wait_budget_seconds': None, 'per_slot_Library_IO_wait_decision_seconds': None}
    need(all(policy['generation_coordination'].get(k) == v for k, v in expected.items()), 'policy field mismatch')
    generation = policy['generation']
    need(all(generation[k] == v for k, v in {'logical_requests': 60, 'completion_tokens_per_request': 64000,
         'capture_window_per_request_seconds': 900, 'summed_capture_window_seconds': 54000,
         'native_CLI_CPU_hard_limit': None, 'native_CLI_CPU_in_trusted_coordination_cap': False,
         'outer_retries': 0, 'replacement_slots': 0}.items()), 'scientific policy mismatch')
    need(policy['historical_shared_balance'] is None and policy['reset_old_budget'] is False, 'historical reset forbidden')
    need(accounting['input_binding_and_generation_bookkeeping_accounting']['allowance_or_verified_balance_file_sha256'] == POLICY_SHA,
         'accounting/policy binding mismatch')
    need(plan['resource_accounting_binding_sha256'] == ACCOUNTING_SHA and plan['roster_sha256'] == roster['sha256'], 'plan binding')
    need(roster['phase'] == 2 and roster['count'] == len(roster['records']) == 60
         and [r['order'] for r in roster['records']] == list(range(73, 133))
         and len({r['slot_id'] for r in roster['records']}) == 60
         and len({r['request_sha256'] for r in roster['records']}) == 60, 'fixed roster mismatch')
    # Verify the existing package as bytes, without parsing prompt/candidate artifacts.
    for name, digest in manifest['files'].items():
        p = Path(name)
        need(not p.is_absolute() and '..' not in p.parts and filehash(package / p) == digest, 'package source drift: ' + name)
    source_root = absolute(source_root or package.parent)
    external = {}
    if 'SOURCE_INPUT_PLAN.json' in manifest['files']:
        source_plan = read(package / 'SOURCE_INPUT_PLAN.json'); verify(source_plan)
        external = source_plan['source_and_input_files']
        for name, digest in external.items():
            relative = Path(name)
            need(not relative.is_absolute() and '..' not in relative.parts
                 and filehash(source_root / relative) == digest, 'external source dependency drift: ' + name)
    return {'schema': 'generation-sidecar-contract-v1', 'package_path': str(package),
            'external_source_root': str(source_root), 'external_source_files': external,
            'policy_file_sha256': POLICY_SHA, 'accounting_file_sha256': ACCOUNTING_SHA,
            'policy_path': str(absolute(policy_path)), 'accounting_path': str(absolute(accounting_path)),
            'package_manifest_file_sha256': filehash(package / 'PACKAGE_MANIFEST.json'),
            'package_manifest_sha256': manifest['sha256'], 'plan_sha256': plan['sha256'],
            'roster_sha256': roster['sha256'], 'run_id': plan['run_id'],
            'source_files': manifest['files'], 'records': roster['records'],
            'generation_execution_granted': False}


def validate_grant(binding, grant, expected_grant_sha256):
    need(sha(canon(grant)) == expected_grant_sha256, 'grant not externally pinned')
    need(grant.get('schema') == 'phase2-explicit-generation-sidecar-grant-v1'
         and grant.get('generation_execution_granted') is True
         and grant.get('implementation_review_accepted') is True, 'generation not granted/reviewed')
    need(grant.get('binding_sha256') == sha(canon(binding)), 'grant binding mismatch')
    need(INCLUSIVE_SUPPLEMENT_SHA is not None
         and grant.get('inclusive_wall_supplement_file_sha256') == INCLUSIVE_SUPPLEMENT_SHA
         and filehash(absolute(grant['inclusive_wall_supplement_path'])) == INCLUSIVE_SUPPLEMENT_SHA,
         'explicit reviewed inclusive-wall supplement required')
    supplement = read(grant['inclusive_wall_supplement_path'])
    expected_scope = {'CPU_kind':'RUSAGE_SELF','capture_wait_included':True,
        'CPU_cap_certification':'NOT_ESTABLISHED','complete_local_process_CPU_upper_bound_claimed':False,
        'arbitrary_fixed_tail_allowance_allowed':False,
        'per_slot_local_inclusive_wall_allowance_seconds':1020,
        'initial_final_local_inclusive_wall_allowance_seconds':240,
        'total_local_inclusive_wall_admission_budget_seconds':61440,
        'per_slot_self_CPU_allowance_seconds':30,'initial_final_self_CPU_allowance_seconds':60,
        'total_self_CPU_admission_budget_seconds':1860,'nonzero_wait_deduction':'reject',
        'production_path_observer_import_or_call':'forbidden','wall_clock':'time.monotonic'}
    need(supplement.get('schema') == 'phase2-inclusive-generation-accounting-supplement-v1'
         and supplement.get('mode') == 'local_stage_inclusive_wall'
         and supplement.get('policy_file_sha256') == POLICY_SHA
         and supplement.get('resource_accounting_binding_file_sha256') == ACCOUNTING_SHA
         and supplement.get('wait_deduction_seconds') == 0
         and supplement.get('production_wait_observer_allowed') is False
         and supplement.get('pure_active_bookkeeping_wall_seconds') is None
         and supplement.get('pure_active_7440_compliance_independently_certified') is False
         and all(supplement.get('local_python_measurement',{}).get(k)==v for k,v in expected_scope.items()),
         'inclusive supplement field mismatch')
    root, workspace = absolute(grant['sidecar_root']), absolute(grant['producer_workspace'])
    need(root == workspace / 'phase2-generation-accounting', 'one fixed sidecar namespace')
    need(grant['authorized_slot_order'] == [r['slot_id'] for r in binding['records']]
         and grant['authorized_request_sha256'] == [r['request_sha256'] for r in binding['records']], 'grant exact roster')
    need(binding['policy_file_sha256'] == POLICY_SHA and binding['accounting_file_sha256'] == ACCOUNTING_SHA,
         'unapproved resource policy')
    gate_path = absolute(grant['bridge_gate_path'])
    need(filehash(gate_path) == grant['bridge_gate_file_sha256'], 'exact existing bridge gate required')
    gate = read(gate_path)
    need(gate.get('enabled') is True and gate.get('parent_review_accepted') is True
         and gate.get('authorized_phase') == 2 and gate.get('plan_sha256') == binding['plan_sha256']
         and gate.get('roster_sha256') == binding['roster_sha256']
         and gate.get('resource_accounting_binding_sha256') == ACCOUNTING_SHA
         and gate.get('producer_workspace') == str(workspace)
         and gate.get('bridge_journal_root') == str(workspace / 'phase2-bridge-journal'),
         'original bridge activation missing or mismatched')
    for name in REQUIRED_OPERATIONAL_FILES:
        path = str(OPERATIONAL_ROOT / name)
        need(grant['operational_source_files'].get(path) == filehash(path), 'required operational source pin: ' + name)
    for path, digest in grant['operational_source_files'].items():
        need(filehash(absolute(path)) == digest, 'operational source drift: ' + path)
    return root


class Sidecar:
    def __init__(self, root, binding, grant, grant_sha256):
        self.root = absolute(root)
        need(self.root == validate_grant(binding, grant, grant_sha256), 'alternate sidecar root')
        self.binding, self.grant = binding, grant
        self.identity = sealed({'schema': 'generation-sidecar-identity-v1', 'root': str(self.root),
                                'binding': binding, 'grant_sha256': grant_sha256})
        need(read(self.root / 'identity.json') == self.identity, 'sidecar identity changed')

    @classmethod
    def create(cls, binding, grant, grant_sha256):
        root = validate_grant(binding, grant, grant_sha256)
        root.mkdir(mode=0o700, exist_ok=False)
        fsync_dir(root.parent)
        identity = sealed({'schema': 'generation-sidecar-identity-v1', 'root': str(root),
                           'binding': binding, 'grant_sha256': grant_sha256})
        publish_once(root / 'identity.json', identity)
        return cls(root, binding, grant, grant_sha256)

    @contextlib.contextmanager
    def locked(self):
        with (self.root / 'lock').open('a+b') as handle:
            fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
            need(not list(self.root.glob('.pending-*')), 'incomplete durable write: unknown')
            yield

    def _events(self):
        events = []
        previous = self.identity['sha256']
        for i, path in enumerate(sorted(self.root.glob('event-*.json')), 1):
            need(path.name == f'event-{i:06d}.json' and not path.is_symlink(), 'journal gap/path')
            event = read(path); verify(event)
            need(event['seq'] == i and event['previous_sha256'] == previous
                 and event['identity_sha256'] == self.identity['sha256'], 'journal chain')
            previous = event['sha256']; events.append(event)
        return events

    def _append(self, events, kind, payload):
        event = sealed({'seq': len(events) + 1, 'kind': kind, 'payload': payload,
                        'identity_sha256': self.identity['sha256'],
                        'previous_sha256': events[-1]['sha256'] if events else self.identity['sha256']})
        publish_once(self.root / f'event-{len(events)+1:06d}.json', event)
        return event

    def _state(self, events):
        reservations, done, pending, halt = [], [], None, []
        cpu = wall = library = 0.0
        library_duration_unknown = False
        cpu_checkpoints = {}
        process_interval_ends = {}
        scopes = {'init_final': [0.0, 0.0]}
        for event in events:
            p = event['payload']
            if event['kind'] == 'reserve_slot':
                reservations.append(p)
            elif event['kind'] == 'begin':
                need(pending is None, 'overlapping stage journal')
                pending = p
            elif event['kind'] == 'end':
                need(pending and p['token_sha256'] == sha(canon(pending)), 'completion without exact reservation')
                cpu_checkpoints.update(p.get('process_CPU_checkpoints', {}))
                process_interval_ends.update(p.get('process_interval_ends', {}))
                scope = pending['scope']; row = scopes.setdefault(scope, [0.0, 0.0])
                cpu += p['self_cpu_seconds']; wall += p['local_inclusive_wall_seconds']; library += p.get('observed_known_library_wait_seconds', p['library_wait_seconds'] or 0.0)
                library_duration_unknown = library_duration_unknown or p['library_wait_seconds'] is None
                row[0] += p['self_cpu_seconds']; row[1] += p['local_inclusive_wall_seconds']
                if p['outcome'] != 'confirmed': halt.append('unknown_stage_outcome_or_measurement')
                if row[0] > (60 if scope == 'init_final' else 30) or cpu > 1860: halt.append('CPU_inflight_overshoot_violation')
                if row[1] > (WALL_INIT_FINAL if scope == 'init_final' else WALL_PER_SLOT) or wall > WALL_TOTAL: halt.append('local_inclusive_wall_inflight_overshoot_violation')
                done.append(dict(pending, result=p)); pending = None
            else:
                raise Stop('unknown journal event')
        return {'reservations': reservations, 'done': done, 'pending': pending, 'halt': sorted(set(halt)),
                'self_cpu_seconds': cpu, 'local_inclusive_wall_seconds': wall, 'library_wait_seconds': None if library_duration_unknown else library,
                'observed_known_library_wait_seconds': library, 'scopes': scopes,
                'process_CPU_checkpoints': cpu_checkpoints, 'process_interval_ends': process_interval_ends}

    def _check_sources(self):
        validate_grant(self.binding, self.grant, self.identity['grant_sha256'])
        package = absolute(self.binding['package_path'])
        need(filehash(self.binding['policy_path']) == POLICY_SHA
             and filehash(self.binding['accounting_path']) == ACCOUNTING_SHA, 'approved policy/accounting changed')
        need(filehash(package / 'PACKAGE_MANIFEST.json') == self.binding['package_manifest_file_sha256'],
             'package manifest changed')
        for name, digest in self.binding['source_files'].items():
            need(filehash(package / name) == digest, 'package bytes changed: ' + name)
        source_root = absolute(self.binding['external_source_root'])
        for name, digest in self.binding['external_source_files'].items():
            need(filehash(source_root / name) == digest, 'external source dependency changed: ' + name)

    def _ready(self, state):
        need(not state['halt'], 'halted: ' + ','.join(state['halt']))
        need(state['pending'] is None, 'unfinished stage unknown; no replay')
        current = self_sample()
        unposted_CPU = max(0.0, current['self_cpu'] - state['process_CPU_checkpoints'].get(PROCESS, 0.0))
        need(state['self_cpu_seconds'] + unposted_CPU < 1860 and state['local_inclusive_wall_seconds'] < WALL_TOTAL, 'allowance exhausted')

    def reserve_slot(self, record):
        with self.locked():
            self._check_sources()
            events = self._events(); state = self._state(events); self._ready(state)
            need(any(r['stage'] == 'initialization' for r in state['done']), 'initialization incomplete')
            n = len(state['reservations'])
            need(n < 60 and record == self.binding['records'][n], 'slot replay/order/request mismatch')
            if n:
                need(any(r['scope'] == state['reservations'][-1]['record']['slot_id'] and r['stage'] == 'finish_position'
                         for r in state['done']), 'prior terminal not acknowledged')
            payload = {'record': record, 'self_CPU_reserved_seconds': 30, 'local_inclusive_wall_reserved_seconds': WALL_PER_SLOT,
                       'logical_requests': 1, 'completion_tokens': 64000, 'generation_window_seconds': 900}
            self._append(events, 'reserve_slot', payload)
            return payload

    def begin(self, scope, stage):
        method_start = self_sample()
        with self.locked():
            self._check_sources()
            events = self._events(); state = self._state(events); self._ready(state)
            done = [r['stage'] for r in state['done'] if r['scope'] == scope]
            if scope == 'init_final':
                expected = 'initialization' if not done else 'finalization' if done == ['initialization'] else None
                if stage == 'finalization':
                    need(sum(r['stage'] == 'finish_position' for r in state['done']) == 60, 'sixty terminal acks required')
                request_sha = None
            else:
                reserved = [r for r in state['reservations'] if r['record']['slot_id'] == scope]
                need(len(reserved) == 1, 'slot not reserved')
                expected = STAGES[len(done)] if len(done) < len(STAGES) else None
                request_sha = reserved[0]['record']['request_sha256']
            need(stage == expected, 'unique stage order mismatch')
            spent = state['scopes'].get(scope, [0, 0])
            need(spent[0] < (60 if scope == 'init_final' else 30)
                 and spent[1] < (WALL_INIT_FINAL if scope == 'init_final' else WALL_PER_SLOT), 'scope allowance exhausted')
            token = {'scope': scope, 'stage': stage, 'request_sha256': request_sha,
                     'binding_sha256': sha(canon(self.binding)), 'nonce': uuid.uuid4().hex, 'started': method_start}
            self._append(events, 'begin', token)
            return token

    def finish(self, token, *, local_receipts, library_waits=(), outcome='confirmed', evidence=None):
        control_start = self_sample()
        with self.locked():
            events = self._events(); state = self._state(events)
            need(state['pending'] == token, 'wrong/duplicate completion')
            need(outcome in ('confirmed', 'unknown'), 'outcome')
            if not local_receipts: outcome = 'unknown'
            local_receipts = sorted(local_receipts, key=lambda r: (str(r.get('process','')),
                r.get('start',{}).get('monotonic',float('inf'))))
            cpu = wall = library = 0.0
            checkpoints = dict(state['process_CPU_checkpoints'])
            process_intervals = {}
            interval_ends = dict(state['process_interval_ends'])
            for receipt in local_receipts:
                try:
                    need(receipt['native_wait_union_seconds'] == 0
                         and receipt.get('wall_semantics') == 'local_stage_inclusive_no_wait_deduction',
                         'inclusive policy rejects wait deduction/active-only receipt')
                    check = local_measurement(receipt['start'], receipt['end'], receipt['native_wait_union_seconds'])
                    need(all(receipt[k] == check[k] for k in ('process','self_cpu_seconds','local_inclusive_wall_seconds','wall_seconds'))
                         and receipt['RUSAGE_kind'] == 'RUSAGE_SELF', 'local receipt changed')
                    bounds = process_intervals.setdefault(receipt['process'], [])
                    a,b=receipt['start']['monotonic'],receipt['end']['monotonic']
                    need(a >= interval_ends.get(receipt['process'], 0.0), 'replayed local interval from earlier stage')
                    interval_ends[receipt['process']] = b
                    need(all(b <= x or a >= y for x,y in bounds), 'duplicate local interval')
                    bounds.append((a,b)); wall += receipt['local_inclusive_wall_seconds']
                    old_cpu = checkpoints.get(receipt['process'], 0.0)
                    need(receipt['end']['self_cpu'] >= old_cpu, 'process CPU checkpoint regressed')
                    cpu += receipt['end']['self_cpu'] - old_cpu
                    checkpoints[receipt['process']] = receipt['end']['self_cpu']
                    if receipt.get('measurement_status') != 'known': outcome = 'unknown'
                except (KeyError, TypeError, Stop):
                    outcome = 'unknown'
            library_duration_unknown = False
            for item in library_waits:
                if item.get('elapsed_seconds') is None:
                    need(item.get('timing_status') == 'unknown' and item.get('outcome') == 'confirmed'
                         and self.grant['inclusive_wall_supplement_file_sha256'] == INCLUSIVE_SUPPLEMENT_SHA,
                         'Library unknown timing not explicitly scoped')
                    library_duration_unknown = True
                    continue
                need(item.get('clock_domain_id') and type(item.get('elapsed_seconds')) in (int,float)
                     and math.isfinite(item['elapsed_seconds']) and item['elapsed_seconds'] >= 0, 'Library wait measurement')
                library += item['elapsed_seconds']
                if item.get('outcome') != 'confirmed': outcome = 'unknown'
            if token['stage'] in LIBRARY_STAGES:
                need(evidence and evidence.get('existing_external_fence_confirmed') is True
                     and evidence.get('all_observed_local_helpers_have_SELF_receipts') is True
                     and evidence.get('library_observer_healthy') is True, 'Library helper/fence evidence incomplete')
            if token['stage'] == 'finish_position':
                need(evidence and evidence.get('existing_terminal_ack_sha256'), 'existing terminal ack required')
            control = local_measurement(control_start, self_sample())
            if control['end']['self_cpu'] < checkpoints.get(PROCESS, 0.0):
                outcome = 'unknown'
            cpu += max(0.0, control['end']['self_cpu'] - checkpoints.get(PROCESS, 0.0))
            checkpoints[PROCESS] = max(control['end']['self_cpu'], checkpoints.get(PROCESS, 0.0))
            wall += control['local_inclusive_wall_seconds']
            result = {'sidecar_control_receipt': control, 'process_CPU_checkpoints': checkpoints,
                      'process_interval_ends': interval_ends,
                      'CPU_semantics': 'sum_of_per_process_SELF_checkpoint_increments_including_observable_startup_and_bookkeeping_CPU',
                      'token_sha256': sha(canon(token)), 'outcome': outcome, 'local_receipts': local_receipts,
                      'library_waits': list(library_waits), 'self_cpu_seconds': cpu, 'local_inclusive_wall_seconds': wall,
                      'library_wait_seconds': None if library_duration_unknown else library,
                      'observed_known_library_wait_seconds': library, 'evidence': evidence,
                      'assistant_plugin_background_CPU': None, 'native_CLI_CPU': None, 'provider_CPU': None,
                      'historical_shared_balance': None, 'no_kernel_aggregate_cap_claim': True,
                      'CPU_cap_certification':'NOT_ESTABLISHED',
                      'observed_SELF_checkpoint_sum_only':True,
                      'local_Python_post_checkpoint_CPU_tail':None,
                      'local_Python_final_post_checkpoint_wall_tail':None}
            self._append(events, 'end', result)
            return self.status()

    def status(self):
        # Called under an existing exclusive lock or as a read-only snapshot.
        state = self._state(self._events())
        return dict(state, production_activation_in_this_package=False,
                    pure_active_bookkeeping_wall_seconds=None, pure_active_7440_compliance_independently_certified=False,
                    wall_semantics='local_stage_inclusive_no_wait_deduction',
                    CPU_cap_certification='NOT_ESTABLISHED',
                    complete_local_process_CPU_upper_bound_claimed=False,
                    observed_SELF_checkpoint_sum_only=True,
                    local_Python_unmeasured_CPU_tail=None, local_Python_final_unmeasured_wall_tail=None,
                    JS_plugin_background_CPU=None, native_CLI_CPU=None, provider_CPU=None,
                    generation_window_reserved_seconds=900*len(state['reservations']))

    def invoke_local(self, scope, stage, function, *args, **kwargs):
        """Pinned original function and unchanged arguments. Full local wall; no wait observer."""
        need(stage in LOCAL_STAGES, 'local call stage unsupported')
        target = self.grant['local_call_targets'][stage]
        source = absolute(inspect.getsourcefile(function))
        package = absolute(self.binding['package_path'])
        external_root = absolute(self.binding['external_source_root'])
        in_package = source.is_relative_to(package) and self.binding['source_files'].get(source.relative_to(package).as_posix()) == target['sha256']
        in_external = source.is_relative_to(external_root) and self.binding['external_source_files'].get(source.relative_to(external_root).as_posix()) == target['sha256']
        in_operational = (source == OPERATIONAL_ROOT / 'production_generation_entry.py'
            and self.grant['operational_source_files'].get(str(source)) == target['sha256'])
        need(in_package or in_external or in_operational,
             'callable outside approved package, external source contract and fixed operational entry')
        need(str(source) == target['path'] and filehash(source) == target['sha256']
             and function.__name__ == target['function'], 'original callable source mismatch')
        token = self.begin(scope, stage)
        start = token['started']; raised = None; result = None
        try:
            result = function(*args, **kwargs)
        except BaseException as exc:
            raised = exc
        outcome = 'unknown' if raised else 'confirmed'
        evidence = {'original_callable_source_sha256': target['sha256'],
                    'inclusive_wall_supplement_file_sha256': INCLUSIVE_SUPPLEMENT_SHA,
                    'passive_wait_observer_imported_or_called': False}
        try:
            end = self_sample()
            measurement = local_measurement(start, end, 0.0)
        except BaseException as measurement_error:
            outcome = 'unknown'
            measurement = {'measurement_status': 'unknown', 'error_type': type(measurement_error).__name__}
            evidence['measurement_failed_after_original_call'] = True
        if stage == 'finish_position' and result is not None:
            evidence['existing_terminal_ack_sha256'] = sha(canon(result.get('original_terminal_ack', result)))
        try:
            state = self.finish(token, local_receipts=[measurement], outcome=outcome, evidence=evidence)
        except BaseException:
            # The durable begin survives. Do not replay the original call.
            if raised is not None: raise raised
            raise
        if raised is not None: raise raised
        need(not state['halt'], 'measurement or in-flight budget violation; original result retained, no next step')
        return result
