/* One guarded budget migration around unchanged commitV2. No GEN or model CLI. */
'use strict';
const fs=require('fs'),crypto=require('crypto');
const sha=x=>crypto.createHash('sha256').update(x).digest('hex');
const q=x=>"'"+String(x).replaceAll("'","'\\''")+"'";
async function migrateBudget64k(rawTools,config){
 const check=(ok,why)=>{if(!ok)throw new Error(why)};
 check(config&&config.grantRef&&config.corePath&&config.commitPath,'exact migration configuration');
 const grant=JSON.parse(fs.readFileSync(config.grantRef.path));
 check(sha(fs.readFileSync(config.grantRef.path))===config.grantRef.file_sha256,'migration grant bytes');
 const fixtures=config.offlineFixture===true;
 check(fixtures?grant.TEST_ONLY===true&&grant.migration_execution_granted===false:
   grant.TEST_ONLY!==true&&grant.migration_execution_granted===true&&grant.independent_review_accepted===true,'migration disabled');
 for(const name of ['corePath','commitPath'])check(grant.source_pins[config[name]]===sha(fs.readFileSync(config[name])),'migration source pin');
 const prefix='python3 -I '+q(config.corePath)+' --grant '+q(config.grantRef.path)+' --grant-sha256 '+q(config.grantRef.file_sha256)+(fixtures?' --offline-fixture':'');
 async function control(action,body){
  const cmd=prefix+' '+action+" <<'BUDGET_CONTROL_JSON'\n"+JSON.stringify(body)+"\nBUDGET_CONTROL_JSON";
  const r=await rawTools.exec_command({cmd,login:false,max_output_tokens:2500});
  check(r.exit_code===0&&typeof r.output==='string','migration control unknown_'+action);
  return JSON.parse(r.output);
 }
 await control('begin',{old_read_refs:config.oldReadRefs});
 const proxy=new Proxy(rawTools,{get(target,method){
  if(!['exec_command','apply_patch','mcp__codex_apps__library_replace_library_file','mcp__codex_apps__library_read','mcp__codex_apps__library_search'].includes(method))throw new Error('migration_unexpected_tool_'+String(method));
  return async args=>{
   const intent=await control('tool-begin',{method,arguments:args});
   let actual=args;
   if(method==='exec_command'){
    const routes=Object.keys(grant.helper_source_pins).flatMap(p=>['python3 -I ','python3 '].map(py=>({p,py,prefix:py+q(p)+' '}))).filter(r=>args.cmd.startsWith(r.prefix));
    check(routes.length===1,'fixed original helper route');
    const route=routes[0];
    const measured=prefix+' --invocation-id '+q(intent.invocation_id)+' --command-sha256 '+q(intent.command_sha256)+' --script '+q(route.p)+' helper -- ';
    actual={...args,cmd:measured+args.cmd.slice(route.prefix.length)};
   }
   let result;
   try{result=await Reflect.apply(target[method],target,[actual])}
   catch(error){
    try{await control('tool-end',{ordinal:intent.ordinal,raw:{isError:true,exception_retained_without_body:true}})}catch(_){}
    throw error;
   }
   await control('tool-end',{ordinal:intent.ordinal,raw:result??{}});
   return result;
  };
 }});
 const commitSource=fs.readFileSync(config.commitPath,'utf8');
 const commit=new Function('tools',commitSource+'\nreturn commitV2;')(proxy);
 const receipt=await commit(grant.producer_workspace,grant.new_index_path,grant.index_library_file_id,0,true);
 await proxy.mcp__codex_apps__library_read({read:[{ref_id:grant.index_library_file_id,mode:'full',max_lines:2}]});
 const reference=await control('finish',{receipt});
 return {status:'CONFIRMED',transition_ref:reference,receipt,GEN_calls:0,model_calls:0,INIT_executions:0};
}
module.exports={migrateBudget64k};

