"""One official CLI invocation, conditionally enabled; no direct model HTTP client."""
import json
import math
import os
from pathlib import Path
import selectors
import shutil
import signal
import sqlite3
import subprocess
import tempfile
import time

from protocol_v2 import (Stop, MAX_INPUT, MAX_RAW, canon, digest, need, read_json, sha,
                         verify_seal, atomic_write, session_semantics, identifier, is_hash)

BINARY = '/tmp/urp-opencode-check-i8yzygra/native/node_modules/opencode-linux-x64-baseline/bin/opencode'
BINARY_SHA = '9ca0b9953d49997601655e54f846a3efa464f237e47c6f1b04716d0f2e64c4c2'
ENDPOINT = 'https://open.bigmodel.cn/api/coding/paas/v4'
MODEL = 'zhipuai-coding-plan/glm-5.3'
EVENT_CAP = 1048576
TOOL_FIELDS = {'id', 'name', 'message_id', 'session_id'}


def check_input(pack, claim, freeze, config_bytes, base_bytes, route_profile_bytes):
    verify_seal(pack); verify_seal(claim); verify_seal(freeze)
    need(claim['request_sha256'] == pack['sha256'] and claim['slot_id'] == pack['slot_id'], 'request_claim_binding')
    need(pack['freeze_sha256'] == freeze['sha256'] == claim['freeze_sha256'], 'request_freeze_binding')
    need(pack['configuration'] == freeze['configuration'] and pack['configuration_sha256'] == digest(freeze['configuration']), 'configured_settings_binding')
    need(len(canon(pack)) <= MAX_INPUT, 'prompt_bound_failure:pack')
    need(sha(config_bytes) == freeze['config_file_sha256'], 'config_raw_bytes_hash')
    config = read_json(config_bytes, 65536)
    need(config.get('model') == MODEL and config.get('enabled_providers') == ['zhipuai-coding-plan'], 'other_model_or_provider')
    need(config.get('small_model') == MODEL, 'small_model_fallback_forbidden')
    p = config.get('provider', {})
    need(set(p) == {'zhipuai-coding-plan'}, 'other_provider')
    options = p['zhipuai-coding-plan']['options']
    need(options.get('baseURL') == ENDPOINT and options.get('apiKey') == '{env:ZHIPU_API_KEY}', 'endpoint_or_placeholder')
    need('headers' not in options and config.get('mcp', {}) == {} and config.get('plugin', []) == [], 'custom_auth_or_plugins')
    agent = config['agent']['candidate']
    settings = freeze['configuration']
    need(settings['model'] == 'glm-5.3' and settings['steps'] == agent.get('steps') == 2, 'model_steps')
    need(settings['tools'] is False and settings['outer_retries'] == 0 and settings['paid_provider_fallback'] is False, 'tools_retry_fallback')
    need(agent.get('tools') == {'*': False} and config.get('permission') == {'*': 'deny'} and agent.get('permission') == {'*': 'deny'}, 'tools_permissions')
    need(config['agent']['title'].get('disable') is True and config['agent']['summary'].get('disable') is True, 'title_summary')
    need(agent.get('temperature') == settings['temperature'] and agent.get('top_p') == settings['top_p'], 'sampling_config_mapping')
    model = p['zhipuai-coding-plan']['models']['glm-5.3']
    api = model.get('api')
    if type(api) is dict:
        need(api.get('url', ENDPOINT) == ENDPOINT, 'alternate_model_api_endpoint')
    elif api is not None:
        need(api == ENDPOINT, 'alternate_model_api_endpoint')
    need(model['options'].get('reasoningEffort') == settings['effort'] and model['limit']['output'] == settings['max_completion_tokens'], 'effort_completion_mapping')
    need(type(settings['wall_seconds']) in (int, float) and 0 < settings['wall_seconds'] <= 900, 'wall_bound')
    need(type(settings['max_completion_tokens']) is int and settings['max_completion_tokens'] == 64000, 'completion_bound')
    need(options.get('timeout') == settings['wall_seconds'] * 1000, 'timeout_config_mapping')
    need(config.get('share') == 'disabled' and config.get('snapshot') is False and config.get('compaction', {}).get('auto') is False, 'share_snapshot_compaction')
    need(type(pack['prompt']) is str and sha(pack['prompt'].encode()) == pack['prompt_sha256'], 'exact_user_prompt_hash')
    prompt = pack['prompt'].encode('utf-8')
    need(prompt and b'\x00' not in prompt, 'prompt_bound_failure:empty_or_nul')
    need(len(base_bytes) <= 65536 and sha(base_bytes) == freeze['base_artifact_sha256'], 'prompt_bound_failure:base_artifact')
    base = read_json(base_bytes, 65536)
    need(type(base) is list and len(base) == 2 and [m['role'] for m in base] == ['system', 'user'], 'base_two_messages')
    need(base[0]['content'] == agent['prompt'], 'system_prompt_in_config')
    actual_messages = [{'role': 'system', 'content': agent['prompt']}, {'role': 'user', 'content': pack['prompt']}]
    need(len(canon(actual_messages)) <= MAX_INPUT, 'prompt_bound_failure:two_message_artifact')
    worst_five_parents = len(base_bytes) + 6 * 5 * (16384 + 2048) + 1024
    need(worst_five_parents <= MAX_INPUT and len(pack.get('parents', [])) <= 5, 'prompt_bound_failure:five_parent_escaping')
    profile = read_json(route_profile_bytes, 65536)
    need(sha(route_profile_bytes) == freeze['input_route_evidence_sha256'], 'input_route_evidence_hash')
    need(profile['route'] in ('stdin', 'argv') and type(profile['maximum_user_prompt_bytes']) is int, 'input_route_profile')
    maximum = profile['maximum_user_prompt_bytes']
    if profile['route'] == 'argv':
        need(maximum <= 65536 and len(prompt) <= maximum, 'prompt_bound_failure:argv')
        need(b' ' not in prompt, 'prompt_bound_failure:argv_text_transform_use_stdin')
    else:
        need(profile.get('official_source_route_verified') is True and 0 < maximum <= MAX_INPUT, 'stdin_route_not_verified_or_bounded')
        need(len(prompt) <= maximum, 'prompt_bound_failure:stdin')
    return {'prompt': prompt, 'settings': settings, 'route': profile['route'],
            'two_message_bytes': len(canon(actual_messages)), 'worst_five_parent_bytes': worst_five_parents}


def check_live_gate(freeze, gate, exporter_source_sha256):
    need(gate.get('enabled') is True and gate.get('freeze_sha256') == freeze['sha256'], 'live_execution_switch_closed')
    need(freeze.get('mode') == 'official_cli' and freeze.get('live_launch_ready') is True, 'final_execution_freeze_missing')
    need(freeze['exporter_source_sha256'] == exporter_source_sha256, 'exporter_source_not_frozen')
    need(freeze['cli_binary_sha256'] == BINARY_SHA and freeze['cli_version'] == '1.18.34', 'official_cli_provenance')
    need(os.access(BINARY, os.X_OK), 'official_binary_not_executable')
    need(freeze.get('session_creation_profile_approved') is True and is_hash(freeze.get('resource_amendment_sha256'))
         and gate.get('resource_amendment_sha256') == freeze.get('resource_amendment_sha256'), 'session_or_resource_review_gate')
    need(sha(Path(BINARY).read_bytes()) == BINARY_SHA, 'official_binary_changed')


def creation_projection(runtime, profile, start, end, fixture=False):
    """Read only three public fields in the frozen local session database."""
    relative = profile['session_db_relative_path']
    need(type(relative) is str and '..' not in Path(relative).parts and not Path(relative).is_absolute(), 'session_db_path')
    db = runtime / relative
    missing = {'source': 'unavailable', 'id': None, 'parent_id': None, 'time_created': None}
    if not db.is_file() or db.is_symlink() or not db.resolve().is_relative_to(runtime.resolve()):
        return missing
    try:
        connection = sqlite3.connect(db.as_uri() + '?mode=ro', uri=True, timeout=1)
        try:
            connection.execute('PRAGMA query_only=ON')
            rows = connection.execute('SELECT id, parent_id, time_created FROM session LIMIT 2').fetchall()
        finally:
            connection.close()
        if len(rows) != 1:
            return missing
        sid, parent, created = rows[0]
        if type(sid) is not str or parent is not None or type(created) is not int or not start <= created <= end:
            return missing
        return {'source': 'fixture_local_session_row' if fixture else 'official_local_session_row',
                'id': sid, 'parent_id': parent, 'time_created': created}
    except sqlite3.Error:
        return missing


def command_for(runtime, slot_id, checked, fixture_command=None):
    if fixture_command is not None:
        return list(fixture_command), {}
    need(type(checked['settings']['max_completion_tokens']) is int
         and checked['settings']['max_completion_tokens'] == 64000, 'exact_completion_launch_bound')
    overrides = {k: str(runtime / v) for k, v in (
        ('XDG_CONFIG_HOME', 'xdg-config'), ('XDG_DATA_HOME', 'xdg-data'),
        ('XDG_CACHE_HOME', 'xdg-cache'), ('XDG_STATE_HOME', 'xdg-state'),
        ('OPENCODE_CONFIG_DIR', 'config'), ('PWD', 'work'))}
    overrides['OPENCODE_CONFIG'] = str(runtime / 'config/opencode.json')
    overrides['OPENCODE_EXPERIMENTAL_OUTPUT_TOKEN_MAX'] = '64000'
    for name in ('OPENCODE_DISABLE_AUTOUPDATE', 'OPENCODE_DISABLE_MODELS_FETCH',
                 'OPENCODE_DISABLE_DEFAULT_PLUGINS', 'OPENCODE_DISABLE_CLAUDE_CODE',
                 'OPENCODE_DISABLE_PROJECT_CONFIG', 'OPENCODE_DISABLE_AUTOCOMPACT',
                 'OPENCODE_DISABLE_LSP_DOWNLOAD', 'OPENCODE_EXPERIMENTAL_DISABLE_FILEWATCHER'):
        overrides[name] = 'true'
    cleared = [arg for name in sorted(os.environ) if name.startswith('OPENCODE_') for arg in ('-u', name)]
    command = ['env', *cleared, *(f'{k}={v}' for k, v in overrides.items()), BINARY,
               '--log-level', 'ERROR', '--pure', 'run', '--dir', str(runtime / 'work'),
               '--agent', 'candidate', '--model', MODEL, '--title', slot_id, '--format', 'json']
    if checked['route'] == 'argv':
        command.append(checked['prompt'].decode('utf-8'))
    return command, None  # Inherit placeholders through OS; never read their values.


def capture_once(workspace, claim, reservation, freeze, config_bytes, checked,
                 claim_receipt, *, gate=None, exporter_source_sha256=None, fixture_command=None):
    """Called ONLY immediately after a fresh external claim confirmation.

    Existing claims on restoration are never passed here. The assistant-owned
    orchestration reserves, confirms, and dispatches in one uninterrupted flow.
    """
    need(claim_receipt.get('write_result_confirmed') is True and claim_receipt.get('index_readback_confirmed') is True,
         'external_claim_unconfirmed')
    need(claim_receipt.get('claim_id') == claim['claim_id'] and claim_receipt.get('invocation_id') == reservation['invocation_id'], 'external_claim_identity')
    if fixture_command is None:
        check_live_gate(freeze, gate or {}, exporter_source_sha256)
    else:
        need(freeze['mode'] == 'fixture_only', 'fixture_cannot_impersonate_official')
    fence = Path(workspace) / 'dispatch-fences' / claim['claim_id']
    try:
        fence.mkdir(parents=True, exist_ok=False)
    except FileExistsError:
        raise Stop('already_dispatched_or_unknown_never_rerun') from None
    atomic_write(fence / 'invocation.json', canon({'claim_id': claim['claim_id'], 'invocation_id': reservation['invocation_id'],
                                                'state': 'may_have_started_once', 'claim_receipt': claim_receipt}))
    runtime = Path(tempfile.mkdtemp(prefix='fresh-opencode-', dir=workspace)).resolve()
    for name in ('work', 'config', 'xdg-config', 'xdg-data', 'xdg-cache', 'xdg-state'):
        (runtime / name).mkdir()
    state_was_empty = all(not list((runtime / n).iterdir()) for n in ('xdg-config', 'xdg-data', 'xdg-cache', 'xdg-state'))
    atomic_write(runtime / 'config/opencode.json', config_bytes)
    need(sha((runtime / 'config/opencode.json').read_bytes()) == sha(config_bytes), 'actual_config_copy_hash')
    atomic_write(runtime / 'user-prompt.txt', checked['prompt'])
    command, env = command_for(runtime, claim['slot_id'], checked, fixture_command)
    if fixture_command is not None:
        command += [str(runtime), claim['slot_id']]
    start_ms, started = int(time.time() * 1000), time.monotonic()
    observations, texts, finishes, usages, messages, tools = [], {}, [], [], set(), []
    stop, pending, stdout_bytes = None, b'', 0
    process = None
    exit_code = None
    selector = selectors.DefaultSelector()
    try:
        with (runtime / 'user-prompt.txt').open('rb') as stdin:
            process = subprocess.Popen(command, cwd=runtime / 'work', stdin=stdin if checked['route'] == 'stdin' else subprocess.DEVNULL,
                                       stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, env=env, start_new_session=True)
            selector.register(process.stdout, selectors.EVENT_READ)
            eof = False
            while not eof and stop is None:
                remaining = checked['settings']['wall_seconds'] - (time.monotonic() - started)
                if remaining <= 0:
                    stop = 'wall_clock_timeout'; break
                for key, _ in selector.select(min(remaining, 0.05)):
                    chunk = os.read(key.fd, 65536)
                    if not chunk:
                        eof = True; break
                    stdout_bytes += len(chunk)
                    if stdout_bytes > EVENT_CAP:
                        stop = 'event_byte_limit'; break
                    pending += chunk
                    while b'\n' in pending and stop is None:
                        line, pending = pending.split(b'\n', 1)
                        try:
                            item = read_json(line, EVENT_CAP)
                            kind, part = item.get('type'), item.get('part', {})
                            need(kind in ('step_start', 'text', 'step_finish', 'reasoning', 'tool_use', 'error') and type(part) is dict, 'unexpected_event')
                            need(len(observations) < 128, 'observation_bound')
                            observation = {'event_type': kind, 'session_id': item.get('sessionID'),
                                           'part_session_id': part.get('sessionID'), 'message_id': part.get('messageID')}
                            need(all(v is None or identifier(v) for k, v in observation.items() if k != 'event_type'), 'invalid_public_session_identifier')
                            observations.append(observation)
                            if observation['message_id'] is not None:
                                messages.add(observation['message_id'])
                            if len(messages) > 1:
                                stop = 'second_model_message'; break
                            ids = {v for o in observations for v in (o['session_id'], o['part_session_id']) if v is not None}
                            if len(ids) > 1:
                                stop = 'multiple_or_mismatched_sessions'; break
                            if kind == 'reasoning':
                                continue  # Never retain its text.
                            if kind == 'tool_use':
                                need(all(identifier(part.get(k)) for k in ('id', 'tool', 'messageID', 'sessionID')), 'invalid_tool_identity')
                                tools.append({'id': part.get('id'), 'name': part.get('tool'),
                                              'message_id': part.get('messageID'), 'session_id': part.get('sessionID')})
                                stop = 'tool_event'; break  # Never retain arguments/state/body.
                            if kind == 'error':
                                stop = 'cli_error_event'; break  # Never retain raw error object.
                            if kind == 'text':
                                pid, text = part.get('id'), part.get('text')
                                need(type(pid) is str and type(text) is str and len(texts) < 128, 'text_part_shape')
                                need(pid not in texts or texts[pid] == text, 'terminal_text_changed')
                                need(sum(len(x.encode()) for k, x in texts.items() if k != pid) + len(text.encode()) <= MAX_RAW, 'raw_text_byte_limit')
                                texts[pid] = text
                            elif kind == 'step_finish':
                                need(len(finishes) < 2, 'finish_event_bound')
                                need(part.get('reason') is None or identifier(part.get('reason')), 'finish_reason_bound')
                                finishes.append(part.get('reason'))
                                usage = part.get('tokens', {})
                                need(type(usage) is dict, 'usage_shape')
                                usages.append({k: usage.get(k) for k in ('input', 'output', 'reasoning')})
                        except (Stop, ValueError, UnicodeError, TypeError, AttributeError):
                            stop = 'invalid_or_unbounded_cli_event'; break
            if pending and stop is None:
                stop = 'partial_json_event'
            if stop is not None and process.poll() is None:
                os.killpg(process.pid, signal.SIGKILL)
            try:
                exit_code = process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL); exit_code = process.wait(timeout=3)
                stop = 'process_cleanup_timeout'
    except (OSError, subprocess.SubprocessError):
        stop = 'subprocess_failure'
    finally:
        selector.close()
        if process is not None:
            if process.poll() is None:
                os.killpg(process.pid, signal.SIGKILL); process.wait(timeout=3)
            exit_code = process.returncode
            process.stdout.close()
    end_ms = int(time.time() * 1000)
    evidence = {'schema': 'opencode-session-evidence-v2', 'claim_id': claim['claim_id'],
                'invocation_id': reservation['invocation_id'], 'config_file_sha256': sha(config_bytes),
                'resume_requested': False, 'state_was_empty': state_was_empty, 'process_started_unix_ms': start_ms,
                'process_terminal_unix_ms': end_ms, 'observations': observations,
                'creation': creation_projection(runtime, freeze['session_creation_profile'], start_ms, end_ms, fixture_command is not None)}
    evidence_bytes = canon(evidence)
    raw = ''.join(texts.values()).encode('utf-8')
    atomic_write(fence / 'raw.txt', raw)
    atomic_write(fence / 'session-evidence.json', evidence_bytes)
    semantics = session_semantics(evidence_bytes)
    normal = stop is None and exit_code == 0
    text_intact = normal and len(messages) == 1 and not tools and finishes in (['stop'], ['length'])
    complete = (text_intact
                and semantics['new_session_observed'] is True and len(semantics['observed_session_ids']) == 1)
    usage = {}
    for source, dest in (('input', 'input_tokens'), ('output', 'output_tokens'), ('reasoning', 'reasoning_tokens')):
        values = [u[source] for u in usages]
        usage[dest] = sum(values) if values and all(type(v) is int and v >= 0 for v in values) else None
    usage['wall_seconds'] = round(time.monotonic() - started, 6)
    status = 'ok' if complete else ('timeout' if stop == 'wall_clock_timeout' else 'cli_failure')
    terminal = {'status': status, 'process_terminal': True, 'capture_complete': complete,
                'finish_reason': finishes[0] if len(finishes) == 1 else None, 'tool_calls': tools,
                'usage': usage, 'physical_http_attempts': None, 'exit_code': exit_code}
    metadata = {'capture_completed_normally': normal, 'capture_succeeded': bool(text_intact and raw),
                'capture_truncated': stop is not None, 'stop_reason': stop,
                'model_messages': len(messages), 'finish_reasons': finishes,
                'stdout_bytes_observed': stdout_bytes, 'response_sha256': sha(raw), 'response_bytes': len(raw),
                'logical_cli_invocations': 1 if process is not None else 0, 'physical_http_attempts': None,
                'fixture_only': fixture_command is not None, 'auth_file_created': any((runtime / 'xdg-data').rglob('auth.json'))}
    if fixture_command is not None and (runtime / 'fixture-input-length.json').is_file():
        measured = read_json((runtime / 'fixture-input-length.json').read_bytes(), 1024)['bytes']
        need(type(measured) is int and 0 <= measured <= MAX_INPUT, 'fixture_input_length_bound')
        metadata['fixture_stdin_bytes_observed'] = measured
    if metadata['auth_file_created']:
        terminal.update(status='cli_failure', capture_complete=False)
        metadata['stop_reason'] = 'unexpected_auth_file'
    shutil.rmtree(runtime)  # Do not inspect/export CLI databases, messages, logs or caches.
    return raw, terminal, evidence_bytes, metadata
