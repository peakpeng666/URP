"""Narrow once-only phase2 bridge around unchanged accepted producer/exporter V2.

No external API is implemented here. Assistant-owned authenticated commits use
the accepted fence. Reservation survives interruption; uncertainty never retries.
This engineering draft has no activation, real plan, roster or parent selection.
Final P1 review and shared-resource bindings must be supplied by the parent.
"""
import contextlib
import copy
import fcntl
import hashlib
import json
import os
from pathlib import Path

HERE=Path(__file__).resolve().parent
# All original P0/P1 stable storage identities remain immutable in this adapter.
HISTORICAL_STORAGE_IDS=frozenset({
    'libfile_c904cc20ec4c81918b438f206e1b60ad',
    'libfile_911c5755e8b081918c4901ff766ee71f',
    'libfile_9afab4077ef48191ba90b2adbe95093f',
    'libfile_221f3504a0d081918fd9aab558c12577',
})

def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def sha(v):return hashlib.sha256(v).hexdigest()
def need(v,reason):
    if not v:raise ValueError(reason)
def verify(v):need(v.get('sha256')==sha(canon({k:x for k,x in v.items() if k!='sha256'})), 'seal mismatch')
def seal(v):return dict(v,sha256=sha(canon(v)))
def load(p):return json.loads(Path(p).read_bytes())
def write_once(p,v):
    fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'wb') as f:f.write(canon(v));f.flush();os.fsync(f.fileno())
    fd=os.open(Path(p).parent,os.O_RDONLY|os.O_DIRECTORY)
    try:os.fsync(fd)
    finally:os.close(fd)

@contextlib.contextmanager
def locked(root):
    root=Path(root);root.mkdir(parents=True,exist_ok=True)
    with (root/'run.lock').open('a+b') as f:
        fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);yield root


def verify_local_package():
    manifest=load(HERE/'PACKAGE_MANIFEST.json');verify(manifest)
    need({'PLAN.json','inputs/roster.json','phase2_producer_bridge.py'}<=set(manifest['files']),
         'reviewed phase2 package inputs required')
    for name,expected in manifest['files'].items():
        path=HERE/name
        need(path.is_file() and not path.is_symlink() and sha(path.read_bytes())==expected,'package drift: '+name)
    return manifest


def check_phase2_scope(plan,roster):
    need(plan.get('schema')=='original132-phase2-continuation-plan-v1'
         and roster.get('schema')=='original132-phase2-fixed-roster-v1'
         and roster.get('phase')==2,'phase2 plan and roster only')
    need(plan['roster_sha256']==roster['sha256'] and plan['run_id']==roster['run_id']
         and plan['freeze_sha256']==roster['freeze_sha256'],'phase2 roster binding')
    need(roster['count']==60 and len(roster['records'])==60
         and [r['position'] for r in roster['records']]==list(range(1,61))
         and [r['order'] for r in roster['records']]==list(range(73,133))
         and all(r['phase']==2 and r['run_id']==plan['run_id']
                 and r['freeze_sha256']==plan['freeze_sha256'] for r in roster['records']),
         'sixty exact phase2 positions')
    need(HISTORICAL_STORAGE_IDS<=set(plan['forbidden_storage_ids']),
         'all original P0/P1 storage must remain forbidden')


def check_gate(gate,plan,roster,*,root=None,workspace=None,storage=None):
    manifest=verify_local_package();verify(plan);verify(roster);check_phase2_scope(plan,roster)
    # These are independently reviewed final-P1/shared-ledger bindings, not a
    # self-authorizing boolean. This bridge never creates or approves evidence.
    for key in ('parent_boundary_sha256','parent_review_acceptance_sha256',
                'resource_accounting_binding_sha256'):
        value=plan.get(key)
        need(type(value) is str and len(value)==64 and set(value)<=set('0123456789abcdef')
             and gate.get(key)==value,'final reviewed binding required: '+key)
    need(gate.get('enabled') is True and gate.get('parent_review_accepted') is True,'phase2 disabled or unreviewed')
    need(gate.get('package_manifest_sha256')==manifest['sha256'],'activation package pin')
    need(gate.get('plan_sha256')==plan['sha256'] and gate.get('roster_sha256')==roster['sha256'],'activation plan/roster')
    need(gate.get('freeze_sha256')==plan['freeze_sha256'] and gate.get('authorized_phase')==2,'activation freeze/phase')
    need(gate.get('original_head_current_confirmed') is True
         and gate.get('original_index_blob_sha256')==plan['predecessor']['index_blob_sha256'],
         'fresh original clean-head verification required')
    need(gate.get('authorized_request_sha256')==[r['request_sha256'] for r in roster['records']]
         and gate.get('authorized_slot_order')==[r['slot_id'] for r in roster['records']],'activation exact scope')
    def exact_path(value):
        need(type(value) is str and Path(value).is_absolute(),'activation requires absolute canonical path')
        path=Path(value)
        need(str(path)==value and '..' not in path.parts and str(path.resolve())==value,'noncanonical path alias')
        need(not any(p.is_symlink() for p in [path,*path.parents]),'symlink path forbidden')
        return path
    fixed_workspace=exact_path(gate.get('producer_workspace'))
    fixed_root=exact_path(gate.get('bridge_journal_root'))
    need(fixed_root==fixed_workspace/'phase2-bridge-journal','one fixed journal beneath activated workspace')
    need(type(gate.get('storage')) is dict and set(gate['storage'])=={'index_library_file_id','archive_library_file_id'},
         'activation must pin exact fresh storage identities')
    need(len(set(gate['storage'].values()))==2 and not set(gate['storage'].values())&set(plan['forbidden_storage_ids']),
         'activation storage collision')
    if root is not None:need(exact_path(str(root))==fixed_root,'alternate bridge root forbidden')
    if workspace is not None:need(exact_path(str(workspace))==fixed_workspace,'alternate producer workspace forbidden')
    if storage is not None:need(storage==gate['storage'],'alternate storage identities forbidden')



def inspect_head(plan,roster,index,receipt,storage,protocol,status):
    verify(plan);verify(roster);check_phase2_scope(plan,roster);protocol.verify_index(index)
    need(plan['roster_sha256']==roster['sha256'],'roster binding')
    need(set(storage)=={'index_library_file_id','archive_library_file_id'},'storage shape')
    ids=list(storage.values())
    need(len(set(ids))==2 and all(type(v) is str and v.startswith('libfile_') for v in ids)
         and not set(ids)&set(plan['forbidden_storage_ids']),'fresh linked namespace required')
    need(index['run_id']==plan['run_id'] and index['freeze_sha256']==plan['freeze_sha256']
         and index['predecessor']==plan['predecessor'] and index['mode']=='official_cli'
         and index['arms']==['EOH_TC','IID_TC'],'operational/scientific lineage')
    need(receipt['write_result_confirmed'] is True and receipt['index_readback_confirmed'] is True
         and receipt['library_file_id']==storage['index_library_file_id']
         and receipt['local_blob_sha256']==sha(canon(index)),'confirmed index head')
    need(status['schema']=='producer-fence-status-v1' and status['observation_kind']=='actual_producer_status_tool_stdout'
         and status['external_write_pending'] is False and status['unresolved_dispatch_fences']==0,'producer uncertainty')
    for k,v in [('library_file_id',receipt['library_file_id']),('file_id',receipt['file_id']),
                ('current_version_number',receipt['current_version_number']),('index_blob_sha256',sha(canon(index))),
                ('run_id',plan['run_id']),('freeze_sha256',plan['freeze_sha256']),('commit_receipt',receipt)]:
        need(status.get(k)==v,'producer status head mismatch')
    need(len(index['rows'])<=60,'phase2 count ceiling')
    for row,record in zip(index['rows'],roster['records']):
        c=row['claim'];inv=row['reservation']
        need(row['phase']==2 and row['arm']==record['arm'] and c['slot_id']==record['slot_id']
             and c['sha256']==record['claim_sha256'] and c['claim_id']==record['claim_id']
             and c['request_sha256']==record['request_sha256'] and inv['config_file_sha256']==record['config_file_sha256'],
             'exact original phase2 order and identity')
    for phase,archive in index['archives'].items():
        need(phase=='2' and archive['library_file_id']==storage['archive_library_file_id'],'phase2 archive only')
    return index['rows']


def reserve_next(root,plan,roster,index,receipt,storage,protocol,status,gate):
    check_gate(gate,plan,roster,root=root,storage=storage)
    with locked(root) as state:
        need(not (state/'HALTED.json').exists(),'integrity halt')
        rows=inspect_head(plan,roster,index,receipt,storage,protocol,status)
        need(all(r['state']=='terminal' for r in rows),'unresolved claim never replay')
        identity=seal({'plan_sha256':plan['sha256'],'roster_sha256':roster['sha256'],'storage':storage})
        if not (state/'identity.json').exists():write_once(state/'identity.json',identity)
        need(load(state/'identity.json')==identity,'permanent journal namespace')
        n=len(rows)
        need(len(list(state.glob('*.reserved.json')))==len(list(state.glob('*.terminal.json')))==n,
             'unknown reservation or terminal acknowledgment; reconcile without replay')
        for pos,row in enumerate(rows,1):
            prior=load(state/f'{pos:02d}.reserved.json');terminal=load(state/f'{pos:02d}.terminal.json')
            verify(prior);verify(terminal)
            need(prior['record']==roster['records'][pos-1] and prior['plan_sha256']==plan['sha256']
                 and terminal['reservation_sha256']==prior['sha256'] and terminal['terminal']==row['terminal']
                 and terminal['claim_id']==row['claim']['claim_id'],'prior reservation identity')
        if n==60:return None
        r=roster['records'][n]
        value=seal({'schema':'original132-phase2-generation-reservation-v1','plan_sha256':plan['sha256'],
            'record':r,'index_sha256':sha(canon(index)),'producer_status_sha256':sha(canon(status)),
            'logical_requests':1,'configured_completion_tokens':64000,'generation_window_seconds':900,
            'state':'may_be_claimed_or_dispatched_once_no_replay'})
        write_once(state/f'{n+1:02d}.reserved.json',value)
        return value


def verify_reserved(root,reservation,plan,pack,claim,freeze,config):
    for obj in (reservation,plan,pack,claim,freeze):verify(obj)
    rec=reservation['record'];state=Path(root);position=rec['position']
    need(not (state/'HALTED.json').exists(),'integrity halt')
    need(load(state/f'{position:02d}.reserved.json')==reservation
         and not (state/f'{position:02d}.terminal.json').exists(),'fresh unresolved reservation')
    need(reservation['plan_sha256']==plan['sha256'],'reservation plan')
    need(rec['run_id']==pack['run_id']==claim['run_id']==freeze['run_id']==plan['run_id'],'run identity')
    need(rec['request_sha256']==pack['sha256']==claim['request_sha256']
         and rec['claim_id']==claim['claim_id'] and rec['claim_sha256']==claim['sha256'],'pack/claim identity')
    need(rec['freeze_sha256']==freeze['sha256']==pack['freeze_sha256']==claim['freeze_sha256'],'freeze identity')
    need(rec['slot_id']==pack['slot_id']==claim['slot_id'] and rec['order']==pack['order']
         and pack['phase']==claim['phase']==rec['phase']==2 and pack['arm']==rec['arm']
         and pack['parents']==rec['parents'] and pack['parent_snapshot_sha256']==rec['parent_snapshot_sha256'],'slot order/parents')
    need(rec['config_file_sha256']==sha(config)==freeze['config_file_sha256'],'unchanged config')
    need(sha(pack['prompt'].encode())==rec['prompt_sha256']
         and len(pack['prompt'].encode())==rec['actual_cli_payload_bytes'],'exact public prompt')


def prepare_reserved(*,root,reservation,plan,roster,index,receipt,pack,claim,freeze,config,base,route,gate,workspace,driver):
    check_gate(gate,plan,roster,root=root,workspace=workspace);verify_reserved(root,reservation,plan,pack,claim,freeze,config)
    need(sha(canon(index))==reservation['index_sha256']
         and receipt['library_file_id']==gate['storage']['index_library_file_id'], 'reserved exact index/storage')
    return driver.prepare(index,receipt,pack,claim,freeze,config,base,route,gate,workspace=workspace)


def collect_reserved(*,root,reservation,plan,roster,pack,claim,producer_reservation,freeze,config,base,route,
                     fresh_claim_receipt,gate,workspace,driver):
    check_gate(gate,plan,roster,root=root,workspace=workspace);verify_reserved(root,reservation,plan,pack,claim,freeze,config)
    verify(producer_reservation)
    need(producer_reservation['claim_id']==claim['claim_id'] and producer_reservation['claim_sha256']==claim['sha256']
         and producer_reservation['request_sha256']==pack['sha256']
         and producer_reservation['config_file_sha256']==sha(config),'exact producer reservation')
    need(fresh_claim_receipt['library_file_id']==gate['storage']['index_library_file_id'], 'claim receipt storage')
    checked=driver.check_input(pack,claim,freeze,config,base,route)
    summary=driver.collect_slot(workspace,claim,producer_reservation,freeze,config,checked,fresh_claim_receipt,gate=gate)
    retained=Path(workspace)/'retained'/claim['slot_id']
    reasons=integrity_halt_reasons(summary,load(retained/'metadata.json'),load(retained/'export.json'))
    if reasons:
        with locked(root) as state:write_once(state/'HALTED.json',seal({'plan_sha256':plan['sha256'],
            'slot_id':claim['slot_id'],'reservation_sha256':reservation['sha256'],'reasons':reasons}))
    summary['phase2_halt_required']=bool(reasons);summary['phase2_halt_reasons']=reasons
    return summary


def finish_position(root,reservation,plan,roster,index,receipt,storage,protocol,status):
    with locked(root) as state:
        rows=inspect_head(plan,roster,index,receipt,storage,protocol,status)
        verify(reservation);pos=reservation['record']['position']
        need(load(state/f'{pos:02d}.reserved.json')==reservation and reservation['plan_sha256']==plan['sha256'],
             'reservation exact')
        need(len(rows)==pos and all(r['state']=='terminal' for r in rows),'durable terminal before next call')
        row=rows[-1]
        value=seal({'schema':'original132-phase2-terminal-ack-v1','reservation_sha256':reservation['sha256'],
            'claim_id':row['claim']['claim_id'],'invocation_id':row['reservation']['invocation_id'],
            'terminal':row['terminal'],'index_receipt':receipt,'producer_status_sha256':sha(canon(status))})
        write_once(state/f'{pos:02d}.terminal.json',value);return value


def integrity_halt_reasons(summary,metadata,packet):
    reasons=[]
    if summary.get('schema_integrity_verified_locally') is not True:reasons.append('retained_capture_schema_integrity')
    stop=metadata.get('stop_reason')
    if stop in ('cli_error_event','tool_event','second_model_message','multiple_or_mismatched_sessions','unexpected_auth_file'):reasons.append(stop)
    cli=packet.get('cli',{});terminal=packet.get('terminal',{})
    if terminal.get('tool_calls'):reasons.append('observed_tool_calls')
    if cli.get('observed_session_ids') and cli.get('new_session_observed') is not True:reasons.append('freshness_unproven')
    if cli.get('resume_requested') is not False:reasons.append('resume_or_unknown_resume_state')
    return sorted(set(reasons))


def status_snapshot(plan,roster,index,receipt,storage,protocol,status):
    """Read-only fixed-denominator report. Never invent unissued captures."""
    rows=inspect_head(plan,roster,index,receipt,storage,protocol,status)
    by_slot={r['claim']['slot_id']:r for r in rows}
    return {'schema':'original132-phase2-generation-status-v1','scientific_run_id':plan['scientific_run_id'],
        'operational_run_id':plan['run_id'],'assigned_denominator':60,'planned_total_original':132,
        'phase0_historical_logical_requests':12,'phase1_historical_logical_requests':60,
        'generation_scope_phase':2,'phase2_claimed_requests':len(rows),
        'phase2_terminal_requests':sum(r['state']=='terminal' for r in rows),
        'configured_completion_reserved':64000*len(rows),'generation_window_reserved':900*len(rows),
        'rows':[{'position':r['position'],'order':r['order'],'slot_id':r['slot_id'],'arm':r['arm'],
            'state':by_slot[r['slot_id']]['state'] if r['slot_id'] in by_slot else 'not_dispatched',
            'terminal':copy.deepcopy(by_slot[r['slot_id']]['terminal']) if r['slot_id'] in by_slot else None}
            for r in roster['records']], 'phase2_generation_complete':len(rows)==60 and all(r['state']=='terminal' for r in rows),
        'numerical_activated':False,'holdout_activated':False}
