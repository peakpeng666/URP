"""Trusted TEST_ONLY authorization adapter; runtime hooks/helper/close bodies stay unchanged."""
import sys
sys.dont_write_bytecode=True
import pathlib,json,shlex,io,contextlib,hashlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'generation'))
import durable_generation_sidecar as d
BaseSidecar=d.Sidecar
SUP='c66e64733e5a27bd48a3ad7056049e65afb6e2552d9d06da09b514c6e6fc9768'
class OfflineSidecar(BaseSidecar):
 def __init__(self,root,binding,grant,grant_sha256):
  self.root=d.absolute(root);self.binding=binding;self.grant=grant
  d.need(d.sha(d.canon(grant))==grant_sha256,'fixture exact grant bytes')
  self.identity=d.sealed({'schema':'generation-sidecar-identity-v1','root':str(self.root),'binding':binding,'grant_sha256':grant_sha256})
  d.need(d.read(self.root/'identity.json')==self.identity,'fixture identity')
  self._check_sources()
 def _check_sources(self):
  d.need(self.root.is_relative_to(ROOT/'fixtures') and self.grant.get('TEST_ONLY') is True
   and self.grant['generation_execution_granted'] is False,'offline scope only')
  d.need(self.grant['inclusive_wall_supplement_file_sha256']==SUP==d.INCLUSIVE_SUPPLEMENT_SHA
   and d.filehash(self.grant['inclusive_wall_supplement_path'])==SUP,'same exact real supplement')
  for p,h in self.grant['operational_source_files'].items():d.need(d.filehash(p)==h,'fixture operational source drift')
d.Sidecar=OfflineSidecar

def setup(f):
 cfg=d.read(f/'config.json');g=d.read(cfg['grantPath']);binding=d.read(cfg['bindingPath']);root=pathlib.Path(cfg['journalRoot'])
 root.mkdir();identity=d.sealed({'schema':'generation-sidecar-identity-v1','root':str(root),'binding':binding,'grant_sha256':cfg['grantSha256']});d.publish_once(root/'identity.json',identity)
 sc=OfflineSidecar(root,binding,g,cfg['grantSha256'])
 # Fixture-only completed coordination; no namespace INIT, producer, model or actual GEN stage runs.
 for scope,stage in [('init_final','initialization')]:
  token=sc.begin(scope,stage);sc.finish(token,local_receipts=[d.local_measurement(token['started'],d.self_sample())])
 record=binding['records'][0];sc.reserve_slot(record)
 for stage in ['reserve_next','prepare_reserved']:
  token=sc.begin(record['slot_id'],stage);sc.finish(token,local_receipts=[d.local_measurement(token['started'],d.self_sample())])
 import production_generation_entry as entry_module
 entry=entry_module.ProductionEntry(sc)
 entry._load=lambda:(sc._check_sources(),setattr(entry,'storage',d.read(g['bridge_gate_path'])['storage']))
 payload=str(f/'producer/payload.json');prev=d.read(f/'producer/state/commits/libfile_TEST_ONLY_index-1.json')
 entry.save(0,'initialization',{'index':d.read(payload),'receipt':prev,'index_path':payload})
 entry.save(1,'prepare_reserved',{'index':d.read(payload),'index_path':payload})
 pending=entry.begin_library(1,'claim_commit')
 ctx=d.read(ROOT/'LIBRARY_CONTEXTS.64k.RUNTIME_FIX.DISABLED.json')['contexts'][0]['context'];ctx=dict(ctx)
 ctx['source_sha256']=d.sha(d.canon(g['operational_source_files']))
 (f/'pending.json').write_bytes(d.canon(pending));(f/'context.json').write_bytes(d.canon(ctx))
 return {'pending_created_by_actual_entry':True,'supplement':SUP,'TEST_ONLY':True}

def invoke_command(request):
 cmd=request['cmd'];prefix=cmd.split(' <<',1)[0];argv=shlex.split(prefix)
 d.need(argv[:1]==['python3'],'only unchanged Python helper transport')
 index=2 if argv[1]=='-I' else 1;script=pathlib.Path(argv[index]);args=argv[index+1:]
 body='\n'.join(cmd.split('\n')[1:-1]) if ' <<' in cmd else ''
 saved_argv,saved_stdin=sys.argv,sys.stdin;sys.stdin=io.TextIOWrapper(io.BytesIO(body.encode()));capture=io.StringIO()
 try:
  with contextlib.redirect_stdout(capture):
   if script==ROOT/'generation/library_hooks_cli.py':
    import library_hooks_cli as hooks
    result=hooks.invoke(args[0],json.loads(body));print(json.dumps(result,separators=(',',':'),ensure_ascii=False))
   elif script==ROOT/'generation/measured_local_helper.py':
    import measured_local_helper as helper
    sys.argv=[str(script),*args]
    try:helper.main()
    except SystemExit as error:
     if error.code not in (None,0):raise
   else:raise RuntimeError('TEST_ONLY refuses non-pinned runtime execution')
  return {'exit_code':0,'output':capture.getvalue()}
 finally:sys.argv=saved_argv;sys.stdin=saved_stdin

if __name__=='__main__':
 if sys.argv[1]=='setup':print(json.dumps(setup(pathlib.Path(sys.argv[2]))))
 else:
  request=json.load(sys.stdin)
  try:result=invoke_command(request)
  except BaseException as error:result={'exit_code':1,'output':'','error':{'name':type(error).__name__,'message':str(error)}}
  print(json.dumps(result,separators=(',',':'),ensure_ascii=False))
