'use strict';
const fs=require('fs'),path=require('path'),cp=require('child_process'),assert=require('assert');
const FIX=path.resolve(__dirname,'..'),root=path.resolve(process.argv[2]),cfg=JSON.parse(fs.readFileSync(root+'/config.json'));
const {runPendingLibraryStage}=require(FIX+'/generation/production_library_commit.js');
const {createLibraryWaitObserver}=require(FIX+'/generation/library_wait_observer.js');
const SUP='c66e64733e5a27bd48a3ad7056049e65afb6e2552d9d06da09b514c6e6fc9768',OLD_SUP='778f9e487fc3a9201c8dc0de061b6195f6e3e8045cd5e4dcd30464e1830c3193';
const original='/workspace/original132-p2-budget64k-implementation-20261007-7fkomf2v';
const source={commit:fs.readFileSync(original+'/exporter/src/library_commit_v2.js','utf8'),
 retention:fs.readFileSync('/workspace/original132-phase2-import-20261006-ba1y1szn/extracted/original132_phase1_preparation_20261005/retention/retain_library_replies.js','utf8'),
 libraryMeter:fs.readFileSync(FIX+'/generation/library_wait_observer.js','utf8'),execAdapter:fs.readFileSync(FIX+'/generation/measured_exec_adapter.js','utf8'),hooksFactory:fs.readFileSync(FIX+'/generation/production_library_hooks.js','utf8')};
const trace=[];let writes=0,reads=0;const originalError=new Error('TEST_ONLY unknown write');
const item={status:'succeeded',library_file_id:'libfile_TEST_ONLY_index',file_id:'file_TEST_ONLY_current',file_name:'payload.json',current_version_number:2,xattrs:[]};
const rawTools={
 async exec_command(args){
  const p=cp.spawnSync('/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3',['-I',FIX+'/tests/local_chain_broker.py','invoke'],{input:JSON.stringify(args),encoding:'utf8',env:{PATH:'/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin:/usr/bin:/bin'},maxBuffer:1024*1024});
  assert.strictEqual(p.status,0,p.stderr);const result=JSON.parse(p.stdout);
  const hook=args.cmd.includes("'/library_hooks_cli.py'")||args.cmd.includes('/library_hooks_cli.py');
  trace.push({kind:hook?'actual_hook':'actual_measured_helper',cmd:args.cmd,exit_code:result.exit_code,error:result.error??null});return result;
 },
 async mcp__codex_apps__library_replace_library_file(args){
  assert.strictEqual(args.library_file_id,'libfile_TEST_ONLY_index');assert.ok(args.file.startsWith(root+'/producer/'));writes++;trace.push({kind:'synthetic_Library_write'});
  if(cfg.scenario==='write_unknown')throw originalError;return {isError:false,structuredContent:item,TEST_ONLY:true};
 },
 async mcp__codex_apps__library_read(args){
  assert.strictEqual(args.read[0].ref_id,item.file_id);reads++;trace.push({kind:'synthetic_Library_read'});
  return {isError:false,structuredContent:{results:[{ref_id:item.file_id,file_id:item.file_id,library_file_id:item.library_file_id,has_more:false,warnings:[],version_id:null,content:[fs.readFileSync(root+'/producer/payload.json','utf8')]}]},TEST_ONLY:true};
 },
 async mcp__codex_apps__library_search(){throw new Error('TEST_ONLY unexpected search')},
 async apply_patch(patch){
  const lines=patch.trimEnd().split('\n');assert.strictEqual(lines[0],'*** Begin Patch');const dest=lines[1].slice('*** Add File: '.length);assert.ok(dest.startsWith(root+'/producer/state/readback-'));
  fs.writeFileSync(dest,lines.slice(2,-1).map(x=>{assert.ok(x.startsWith('+'));return x.slice(1)}).join('\n')+'\n',{flag:'wx'});trace.push({kind:'actual_local_readback_patch'});return {isError:false};
 }
};
const pending=JSON.parse(fs.readFileSync(root+'/pending.json')),context=JSON.parse(fs.readFileSync(root+'/context.json'));
const options={rawTools,pending,context,sources:source,paths:cfg.paths,grantSha256:cfg.grantSha256,slotIds:Array.from({length:60},(_,i)=>JSON.parse(fs.readFileSync(cfg.bindingPath)).records[i].slot_id),accountingSupplementSha256:SUP};
(async()=>{
 let result,error;
 if(cfg.scenario==='old_option')options.accountingSupplementSha256=OLD_SUP;
 if(cfg.scenario==='old_meter')options.sources={...source,libraryMeter:fs.readFileSync(original+'/generation/library_wait_observer.js','utf8')};
 if(cfg.scenario==='old_commit'){
  try{await require(original+'/generation/production_library_commit.js').runPendingLibraryStage(options)}catch(ex){error=ex}
 }else if(cfg.scenario==='meter_old_supplement'){
  try{createLibraryWaitObserver(rawTools,{timingMode:'unobservable',accountingSupplementSha256:OLD_SUP})}catch(ex){error=ex}
 }else{
  try{result=await runPendingLibraryStage(options)}catch(ex){error=ex}
 }
 fs.writeFileSync(root+'/DEBUG_LAST_TRACE.json',JSON.stringify({error:error?.message??null,trace,result:result??null}));
 let reentryError=null;
 if(cfg.scenario==='success'){
  assert.ok(!error,error?.message);assert.strictEqual(result.sidecar_state.pending,null);assert.deepStrictEqual(result.sidecar_state.halt,[]);
  assert.strictEqual(result.accounting_snapshot.accounting_supplement_sha256,SUP);assert.strictEqual(result.accounting_snapshot.library_await_wall_ms,null);
  assert.strictEqual(result.accounting_snapshot.local_helper_self_receipts_complete,true);assert.strictEqual(writes,1);assert.strictEqual(reads,1);
  const priorWrites=writes;try{await runPendingLibraryStage(options)}catch(ex){reentryError=ex.message}
  assert.ok(reentryError);assert.strictEqual(writes,priorWrites);
 }else{assert.ok(error);if(cfg.scenario==='write_unknown')assert.strictEqual(error,originalError);else assert.strictEqual(writes,0)}
 const report={TEST_ONLY:true,scenario:cfg.scenario,success:cfg.scenario==='success'?!error:!!error,error:error?.message??null,same_original_exception:cfg.scenario==='write_unknown'?error===originalError:null,
  result:result??null,trace,writes,reads,reentry_error:reentryError,native_external_calls:0,model_calls:0,GEN_calls:0,migration_calls:0,INIT_calls:0};
 fs.writeFileSync(root+'/CHAIN_RESULT.json',JSON.stringify(report),{flag:'wx'});console.log(JSON.stringify({scenario:cfg.scenario,passed:report.success,error:report.error,writes,reads,hooks:trace.filter(x=>x.kind==='actual_hook').length,helpers:trace.filter(x=>x.kind==='actual_measured_helper').length,native_external_calls:0}));
})().catch(error=>{console.error(error);process.exitCode=1});
