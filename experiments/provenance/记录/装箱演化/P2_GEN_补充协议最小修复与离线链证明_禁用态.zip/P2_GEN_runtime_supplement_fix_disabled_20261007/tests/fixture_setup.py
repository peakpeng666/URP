"""Existing pending-stage shape; all writes confined to this TEST_ONLY fixtures tree."""
import sys
sys.dont_write_bytecode=True
import pathlib,json,tempfile,shutil,hashlib,subprocess
ROOT=pathlib.Path(__file__).resolve().parents[1]
OLD=pathlib.Path('/workspace/original132-p2-budget64k-implementation-20261007-7fkomf2v')
PY='/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3'
NODE='/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node'
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def read(p):return json.loads(pathlib.Path(p).read_bytes())
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def setup(scenario):
 f=pathlib.Path(tempfile.mkdtemp(prefix=scenario+'-',dir=ROOT/'fixtures'));w=f/'producer';(w/'state/commits').mkdir(parents=True);(w/'src').mkdir();(w/'.library-helpers-current').mkdir();(w/'retained-library-replies').mkdir()
 real=pathlib.Path('/workspace/original132-phase2-producer-20261006')
 for name in ['protocol_v2.py','driver_v2.py','capture_v2.py','external_commit_fence_v2.py','commit_receipt_v2.py']:shutil.copyfile(real/'src'/name,w/'src'/name)
 shutil.copyfile(real/'.library-helpers-current/library_file_transfer.py',w/'.library-helpers-current/library_file_transfer.py')
 retention=pathlib.Path('/workspace/original132-phase2-import-20261006-ba1y1szn/extracted/original132_phase1_preparation_20261005/retention/retain_tool_result.py');shutil.copyfile(retention,w/'retain_tool_result.py')
 shutil.copyfile(real/'index.budget64k.proposed.json',w/'payload.json')
 prev=read(real/'state/commits/libfile_d711508ec1888191ba87324ac424a529-1.json');prev.update(library_file_id='libfile_TEST_ONLY_index',file_id='file_TEST_ONLY_previous',current_version_number=1)
 (w/'state/commits/libfile_TEST_ONLY_index-1.json').write_bytes(canon(prev))
 g=read(ROOT/'GEN_GRANT.64k.RUNTIME_FIX.DISABLED.json');g.update(TEST_ONLY=True,producer_workspace=str(w),sidecar_root=str(w/'phase2-generation-accounting'),retention_audit_directory=str(w/'retained-library-replies'))
 helpers=[w/'src/external_commit_fence_v2.py',w/'src/commit_receipt_v2.py',w/'.library-helpers-current/library_file_transfer.py',w/'retain_tool_result.py'];g['local_helper_source_files']={str(p):sha(p) for p in helpers}
 gate=read(ROOT/'BRIDGE_GATE.64k.RUNTIME_FIX.DISABLED.json');gate['storage']={'index_library_file_id':'libfile_TEST_ONLY_index','archive_library_file_id':'libfile_TEST_ONLY_archive'};gp=f/'gate.TEST_ONLY.json';gp.write_bytes(canon(gate));g['bridge_gate_path']=str(gp);g['bridge_gate_file_sha256']=sha(gp)
 grant=f/'GEN_GRANT.TEST_ONLY.json';grant.write_bytes(canon(g));binding=read(OLD/'consumer-contract.64k.CANDIDATE.json');bp=f/'binding.json';bp.write_bytes(canon(binding))
 comp=read(ROOT/'GEN_COMPOSITION.64k.RUNTIME_FIX.DISABLED.json');paths=dict(comp['paths'],grantPath=str(grant),journalRoot=g['sidecar_root'],retentionAuditDirectory=g['retention_audit_directory'],retentionHelperPath=str(w/'retain_tool_result.py'),originalLaunchPrefixes=[{'python':'python3 -I','scriptPath':str(w/'src/external_commit_fence_v2.py')},{'python':'python3 -I','scriptPath':str(w/'src/commit_receipt_v2.py')},{'python':'python3','scriptPath':str(w/'.library-helpers-current/library_file_transfer.py')},{'python':'python3 -I','scriptPath':str(w/'retain_tool_result.py')}])
 cfg={'TEST_ONLY':True,'root':str(f),'grantPath':str(grant),'grantSha256':sha(grant),'bindingPath':str(bp),'journalRoot':g['sidecar_root'],'paths':paths,'scenario':scenario};(f/'config.json').write_bytes(canon(cfg))
 cp=subprocess.run([PY,'-I',str(ROOT/'tests/local_chain_broker.py'),'setup',str(f)],capture_output=True,text=True,timeout=10,env={'PATH':str(pathlib.Path(PY).parent)+':/usr/bin:/bin'});assert cp.returncode==0,cp.stderr
 (f/'setup-result.json').write_text(cp.stdout);return f
if __name__=='__main__':print(setup(sys.argv[1] if len(sys.argv)>1 else 'success'))
