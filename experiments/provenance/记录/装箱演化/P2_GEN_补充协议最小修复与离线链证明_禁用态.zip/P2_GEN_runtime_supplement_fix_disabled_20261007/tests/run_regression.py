"""Six bounded offline cases; no original history suite, native Library, model or migration."""
import sys
sys.dont_write_bytecode=True
import pathlib,json,subprocess,hashlib,ast
from fixture_setup import ROOT,setup,NODE,PY,read,canon,sha
results=[]
for scenario in ['success','old_commit','old_option','old_meter','meter_old_supplement','write_unknown']:
 f=setup(scenario);cp=subprocess.run([NODE,str(ROOT/'tests/pending_chain.js'),str(f)],capture_output=True,text=True,timeout=30,env={'PATH':'/usr/bin:/bin'})
 assert cp.returncode==0,cp.stdout+cp.stderr
 r=read(f/'CHAIN_RESULT.json');assert r['success'] and r['native_external_calls']==0
 event=[read(p) for p in sorted((f/'producer/phase2-generation-accounting').glob('event-*.json'))]
 pending=event[-1]['kind']=='begin'
 if scenario=='success':
  assert not pending and event[-1]['payload']['outcome']=='confirmed'
  snapshot=r['result']['accounting_snapshot'];assert snapshot['accounting_supplement_sha256']=='c66e64733e5a27bd48a3ad7056049e65afb6e2552d9d06da09b514c6e6fc9768'
  assert r['result']['sidecar_state']['pending'] is None and r['result']['sidecar_state']['halt']==[]
  assert len(snapshot['local_helpers'])==6 and all(h['self_receipt_verified'] for h in snapshot['local_helpers'])
  assert event[-1]['payload']['library_wait_seconds'] is None and r['reentry_error']
 elif scenario=='write_unknown':assert pending and r['same_original_exception'] and (f/'producer/state/external-pending.json').exists()
 else:assert pending and r['writes']==0 and not r['trace']
 results.append({'scenario':scenario,'fixture':str(f),'passed':True,'writes_synthetic':r['writes'],'reads_synthetic':r['reads'],'error':r['error'],'pending_after':pending,'reentry_error':r['reentry_error'],'hook_calls':sum(x['kind']=='actual_hook' for x in r['trace']),'helper_calls':sum(x['kind']=='actual_measured_helper' for x in r['trace']),'native_external_calls':0})

# Source and import binding only: no initialization, local stage or production helper is invoked.
script="import sys,inspect;sys.dont_write_bytecode=True;sys.path.insert(0,"+repr(str(ROOT/'src'))+");import production_generation_entry_64k as e;assert str(e.d.OPERATIONAL_ROOT)=="+repr(str(ROOT/'references/generation'))+";assert all(str(inspect.getsourcefile(fn))=="+repr(str(ROOT/'references/generation/production_generation_entry.py'))+" for fn in e.LOCAL_FUNCTIONS.values());print('new entry import/manifest/callable pins valid')"
cp=subprocess.run([PY,'-I','-c',script],capture_output=True,text=True,timeout=10,env={'PATH':'/usr/bin:/bin'});assert cp.returncode==0,cp.stderr
pins=read(ROOT/'SOURCE_PINS.GEN_RUNTIME_FIX.json');assert len(pins)==84 and all(sha(p)==h for p,h in pins.items())
old=read(ROOT/'audit/ORIGINAL63_BEFORE.json');assert len(old)==63 and all(sha(p)==h for p,h in old.items())
for directory in ['generation','references/generation']:
 manifest=read(ROOT/directory/'OPERATING_SOURCE_MANIFEST.json')
 assert all(sha(ROOT/directory/name)==h for name,h in manifest['production_files'].items())
 for p in (ROOT/directory).glob('*.py'):ast.parse(p.read_text(),filename=str(p))
 for p in (ROOT/directory).glob('*.js'):
  check=subprocess.run([NODE,'--check',str(p)],capture_output=True,text=True,timeout=5,env={'PATH':'/usr/bin:/bin'});assert check.returncode==0,check.stderr
original=pathlib.Path('/workspace/original132-p2-budget64k-implementation-20261007-7fkomf2v');sys.path.insert(0,str(ROOT/'generation'));import durable_generation_sidecar as d
g=read(ROOT/'GEN_GRANT.64k.RUNTIME_FIX.DISABLED.json');binding=read(original/'consumer-contract.64k.CANDIDATE.json')
try:d.Sidecar.create(binding,g,d.sha(d.canon(g)))
except d.Stop as error:assert 'not granted/reviewed' in str(error)
else:raise AssertionError('disabled production grant must remain blocked')
real=pathlib.Path('/workspace/original132-phase2-producer-20261006')
head_hash=sha(real/'index.budget64k.proposed.json');receipt_hash=sha(real/'state/commits/libfile_d711508ec1888191ba87324ac424a529-1.json');transition_hash=sha(real/'phase2-budget-migration/transition.receipt.json')
assert head_hash=='1d5ffae597191df9fef60f2f35bab9d32e47bbc1c721820beb95c46258e7a100' and receipt_hash=='c3f316d8261d865ff050ac44bbb6b5a96f0d1c0a20d3a25e015779a550447e9b' and transition_hash=='85682e6c6451eb7045abb5ae10d7e2979418a44ffae12b968d40cf5cc02ed365'
assert not (real/'phase2-generation-accounting').exists() and not (real/'phase2-bridge-journal').exists()
report={'success':True,'cases':results,'entry_manifest_import_check':True,'disabled_production_grant_rejected':True,'GEN_execution_granted':False,'numeric_execution_granted':False,'native_external_calls':0,'model_calls':0,'GEN_calls':0,'migration_calls':0,'INIT_calls':0,'original63_unchanged':True,'new_GEN_source_pins':84,'actual_current_head_receipt_transition_unchanged':True,'real_HEAD_SHA256':head_hash,'real_RECEIPT_SHA256':receipt_hash,'real_TRANSITION_SHA256':transition_hash,'same_supplement_SHA256':d.INCLUSIVE_SUPPLEMENT_SHA,'unknown_timing_remains_null':True}
(ROOT/'audit/OFFLINE_REGRESSION_RESULTS.json').write_bytes(canon(report));print(canon({'success':True,'cases':len(results),'original63_unchanged':True,'new_GEN_source_pins':84,'native_external_calls':0,'model_calls':0}).decode())
