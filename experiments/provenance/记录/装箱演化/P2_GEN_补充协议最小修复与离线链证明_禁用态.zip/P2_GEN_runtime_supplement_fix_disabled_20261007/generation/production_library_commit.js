/* Executable composition for one already-reserved original Library stage.
 * No retries or generation are implemented. Source bytes are hash-checked
 * before evaluation; durable hooks and close use the Python sidecar APIs.
 * Actual entry still requires the separately pinned parent GEN grant.
 */
'use strict';
const ACCOUNTING_SUPPLEMENT_SHA = 'c66e64733e5a27bd48a3ad7056049e65afb6e2552d9d06da09b514c6e6fc9768';
const COMMIT_SHA = 'a870f16d05b5db17a94be6544beb725d69fe6a429b41d3bb5ba7fe646811270d';
const RETENTION_SHA = 'e44fec0c2059aa184825fd1d75c9eed851858c55230f22cb1650a7ab89ff0f6c';
function sha256(text) {
    const bytes = [];
    for (const ch of text) {
      const c = ch.codePointAt(0);
      if (c < 128) bytes.push(c);
      else if (c < 2048) bytes.push(192 | c >> 6, 128 | c & 63);
      else if (c < 65536) bytes.push(224 | c >> 12, 128 | c >> 6 & 63, 128 | c & 63);
      else bytes.push(240 | c >> 18, 128 | c >> 12 & 63, 128 | c >> 6 & 63, 128 | c & 63);
    }
    const length = bytes.length;
    bytes.push(128);
    while (bytes.length % 64 !== 56) bytes.push(0);
    const high = Math.floor(length / 0x20000000), low = (length * 8) >>> 0;
    for (const part of [high, low]) for (let shift = 24; shift >= 0; shift -= 8) bytes.push(part >>> shift & 255);
    const k = [0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
      0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
      0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
      0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
      0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
      0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
      0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
      0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
    const h = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
    const r = (x,n) => (x >>> n) | (x << (32-n));
    for (let offset = 0; offset < bytes.length; offset += 64) {
      const w = new Uint32Array(64);
      for (let i = 0; i < 16; i++) {
        const j = offset + i * 4;
        w[i] = bytes[j] << 24 | bytes[j+1] << 16 | bytes[j+2] << 8 | bytes[j+3];
      }
      for (let i = 16; i < 64; i++) {
        const a=w[i-15], b=w[i-2];
        w[i] = w[i-16] + (r(a,7)^r(a,18)^(a>>>3)) + w[i-7] + (r(b,17)^r(b,19)^(b>>>10));
      }
      let [a,b,c,d,e,f,g,j] = h;
      for (let i = 0; i < 64; i++) {
        const t1 = (j + (r(e,6)^r(e,11)^r(e,25)) + ((e&f)^(~e&g)) + k[i] + w[i]) | 0;
        const t2 = ((r(a,2)^r(a,13)^r(a,22)) + ((a&b)^(a&c)^(b&c))) | 0;
        j=g;g=f;f=e;e=(d+t1)|0;d=c;c=b;b=a;a=(t1+t2)|0;
      }
      [a,b,c,d,e,f,g,j].forEach((value, i) => { h[i] = (h[i] + value) | 0; });
    }
    return h.map(x => (x>>>0).toString(16).padStart(8,'0')).join('');
  }
const METER_SHA = '537af94a65fecfe7e56e2db6fedc1a4b55ee5345f7179e46688c1f0ccb02948a';
const EXEC_ADAPTER_SHA = 'fca4b13d3573b39807e93c150a280891fd659a260124857bea1d3137117b49f0';
const HOOK_FACTORY_SHA = 'fdc1e11ad91eae3836814c342c0af7eced25a8278bf6d73d51bc12253874e7ee';
function loadOriginal(text, expected, name, tools) {
  if (sha256(text)!==expected) throw new Error('original_source_hash_mismatch_'+name);
  return Function('tools','"use strict";\n'+text+'\nreturn '+name+';')(tools);
}
async function runPendingLibraryStage(options) {
  const {rawTools,pending,context,sources,paths,grantSha256,slotIds}=options;
  if (options.accountingSupplementSha256!==ACCOUNTING_SUPPLEMENT_SHA ||
      pending?.timing_mode!=='unobservable' || !pending?.token ||
      !['claim_commit','archive_commit','terminal_commit'].includes(pending.stage) ||
      context.stage!==pending.stage || context.slotId!==pending.token.scope ||
      context.request_sha256!==pending.token.request_sha256 ||
      context.binding_sha256!==pending.token.binding_sha256 ||
      !Array.isArray(pending.commit_arguments) || pending.commit_arguments.length!==5 ||
      !Array.isArray(slotIds) || slotIds.length!==60 || new Set(slotIds).size!==60)
    throw new Error('unbound_pending_stage_or_supplement');
  if (sha256(sources.commit)!==COMMIT_SHA || sha256(sources.retention)!==RETENTION_SHA)
    throw new Error('accepted_library_source_drift');
  const createLibraryWaitObserver=loadOriginal(sources.libraryMeter,METER_SHA,'createLibraryWaitObserver',undefined);
  const createMeasuredExecAdapter=loadOriginal(sources.execAdapter,EXEC_ADAPTER_SHA,'createMeasuredExecAdapter',undefined);
  const createProductionLibraryHooks=loadOriginal(sources.hooksFactory,HOOK_FACTORY_SHA,'createProductionLibraryHooks',undefined);
  const hooks=createProductionLibraryHooks(rawTools,{cliPath:paths.hooksCliPath,journalRoot:paths.journalRoot,
    grantPath:paths.grantPath,grantSha256});
  await hooks.enterStage(pending); // Durable token lease before any original helper or Library call.
  let meter;
  const measuredRaw=createMeasuredExecAdapter(rawTools,{
    launcherPath:paths.launcherPath,journalRoot:paths.journalRoot,grantPath:paths.grantPath,grantSha256,
    originalLaunchPrefixes:paths.originalLaunchPrefixes,
    currentHelperInvocation:()=>meter.snapshot().local_helpers.at(-1)
  });
  meter=createLibraryWaitObserver(measuredRaw,{
    timingMode:'unobservable',accountingSupplementSha256:ACCOUNTING_SUPPLEMENT_SHA,slotIds,
    beforeOperation:intent=>hooks.beforeOperation(pending.token,intent),
    afterObservation:receipt=>hooks.afterObservation(pending.token,receipt),
    verifyLocalHelperReceipt:(invocation,envelope)=>hooks.verifyHelperReceipt(pending.token,invocation,envelope)
  });
  const observed=meter.bindStage(context);
  const retain=loadOriginal(sources.retention,RETENTION_SHA,'retainLibraryReplies',undefined);
  const originalTools=retain(observed,{auditDirectory:paths.retentionAuditDirectory,
    operationId:context.operationId,helperPath:paths.retentionHelperPath});
  const commit=loadOriginal(sources.commit,COMMIT_SHA,'commitV2',originalTools);
  // One unchanged V2 call. Any exception leaves the already-durable stage pending.
  const receipt=await commit(...pending.commit_arguments);
  for(const invocation of meter.snapshot().local_helpers){
    const envelope=await hooks.getHelperReceipt(pending.token,invocation);
    await meter.recordLocalHelperReceipt(invocation.invocation_id,envelope);
  }
  meter.assertCanContinue();
  const snapshot=meter.snapshot();
  const state=await hooks.closeStage(pending,snapshot,receipt);
  return {receipt,accounting_snapshot:snapshot,sidecar_state:state};
}
if(typeof module!=='undefined'&&module.exports)module.exports={runPendingLibraryStage,sha256};
