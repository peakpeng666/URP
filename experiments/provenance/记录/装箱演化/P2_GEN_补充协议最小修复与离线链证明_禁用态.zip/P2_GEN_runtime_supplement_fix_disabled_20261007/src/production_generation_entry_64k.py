"""Fixed, separately activated P2 stage entry. No callbacks, retries or loop.

Every invocation performs one existing stage. Library commits remain in the
authenticated assistant bridge; begin/close bracket that unchanged route.
No producer is imported until its complete operational source pins pass.
"""
import argparse
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, '/workspace/original132-p2-budget64k-implementation-20261007-7fkomf2v/src')
sys.path.insert(0, '/workspace/original132-phase2-recovery-dev-20261006-8sdu8cov/revision2/src')
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "references" / "generation"))
import recovery_core as recovery
_reference_root = Path(__file__).resolve().parents[1] / 'references' / 'generation'
_reference_manifest = _reference_root / 'OPERATING_SOURCE_MANIFEST.json'
recovery.need(recovery.filehash(_reference_manifest) ==
              'caf9e5c828ade784f56e501ada9e1874ea19efa77362a79426d79882bcd78484', 'reference manifest drift')
for _name, _digest in recovery.read(_reference_manifest)['production_files'].items():
    recovery.need(recovery.filehash(_reference_root / _name) == _digest, 'reference source drift before import')
import durable_generation_sidecar as d
import library_stage_sidecar as library
import production_generation_entry as original_entry


class ProductionEntry:
    def __init__(self, sidecar):
        self.sidecar = sidecar
        self.package = d.absolute(sidecar.binding['package_path'])
        self.workspace = d.absolute(sidecar.grant['producer_workspace'])
        self.root = self.workspace / 'phase2-bridge-journal'
        self.modules = None

    def _load(self):
        self.sidecar._check_sources()
        if self.modules is not None:
            return
        paths = self.sidecar.grant['entry_source_files']
        names = {'protocol': 'protocol_v2', 'capture': 'capture_v2', 'driver': 'driver_v2',
                 'bridge': 'phase2_producer_bridge', 'status': 'producer_fence_status'}
        d.need(set(paths) == set(names), 'exact original entry module set required')
        pins = self.sidecar.grant['operational_source_files']
        for path in paths.values():
            p = d.absolute(path)
            d.need(str(p) in pins and d.filehash(p) == pins[str(p)], 'entry dependency drift before import')
        self.modules = {}
        for key, name in names.items():
            path = d.absolute(paths[key])
            old = sys.modules.get(name)
            if old is not None:
                d.need(Path(old.__file__).resolve() == path and d.filehash(path) == pins[str(path)],
                       'unexpected preloaded producer module')
                module = old
            else:
                spec = importlib.util.spec_from_file_location(name, path)
                module = importlib.util.module_from_spec(spec)
                sys.modules[name] = module
                spec.loader.exec_module(module)
            self.modules[key] = module
        self.plan = d.read(self.package / 'PLAN.json')
        self.roster = d.read(self.package / 'inputs/roster.json')
        self.gate = d.read(self.sidecar.grant['bridge_gate_path'])
        self.storage = self.gate['storage']

    def _path(self, position, stage):
        d.need(type(position) is int and 0 <= position <= 60 and stage in (*d.STAGES, 'initialization', 'finalization'),
               'entry position/stage')
        return self.sidecar.root / f'entry-{position:02d}-{stage}.json'

    def save(self, position, stage, value):
        result = d.sealed({'position': position, 'stage': stage, 'value': value,
                           'binding_sha256': d.sha(d.canon(self.sidecar.binding))})
        d.publish_once(self._path(position, stage), result)
        return value

    def saved(self, position, stage):
        value = d.read(self._path(position, stage)); d.verify(value)
        d.need(value['position'] == position and value['stage'] == stage
               and value['binding_sha256'] == d.sha(d.canon(self.sidecar.binding)), 'entry result binding')
        return value['value']

    def record(self, position):
        d.need(type(position) is int and 1 <= position <= 60, 'fixed sixty positions only')
        return self.sidecar.binding['records'][position - 1]

    def inputs(self, position):
        slot = self.record(position)['slot_id']
        base = self.package / 'inputs'
        return {'pack': d.read(base / 'packs' / (slot + '.json')),
                'claim': d.read(base / 'uncommitted-claims' / (slot + '.json')),
                'freeze': d.read(base / 'freeze.json'),
                'config': (base / 'config.raw.json').read_bytes(),
                'base': (base / 'base-artifact.json').read_bytes(),
                'route': (base / 'input-route.json').read_bytes()}

    def common(self, position):
        return dict(root=self.root, reservation=self.saved(position, 'reserve_next'),
                    plan=self.plan, roster=self.roster, gate=self.gate,
                    workspace=self.workspace, driver=self.modules['driver'], **self.inputs(position))

    def head(self, position):
        if position == 1:
            value = self.saved(0, 'initialization')
        else:
            value = self.saved(position - 1, 'finish_position')
        return value['index'], value['receipt'], value['index_path']

    def actual_status(self, index_path, receipt):
        return self.modules['status'].inspect(self.workspace, receipt['library_file_id'],
                                             receipt['current_version_number'], index_path)

    def bootstrap_receipts(self, index_receipt):
        # Explicit reviewed v2 branch; original v1 retains strict14/16 validation.
        from gen_importer_v2 import load_handoff
        import recovery_core
        d.need(not hasattr(self, '_bootstrap_handoff_imported'), 'handoff already imported')
        grant_ref = self.sidecar.grant['reconciliation_grant_ref']
        grant = recovery_core.read(recovery_core.checked_ref(grant_ref))
        grant['_grant_ref'] = grant_ref
        ref = self.sidecar.grant['namespace_initialization_handoff']
        rows, digest = load_handoff(ref, grant)
        handoff = d.read(ref['path'])
        d.need(handoff['archive_receipt'] == self.sidecar.grant['entry_initial_archive_receipt'],
               'original empty archive receipt remains exact')
        from budget_transition import confirmed_transition
        transition_ref = self.sidecar.grant['output_budget_transition_ref']
        transition_rows = confirmed_transition(transition_ref,
            self.sidecar.grant['output_budget_transition_grant_ref'], ref, index_receipt,
            offline=self.sidecar.grant.get('TEST_ONLY') is True)
        transition = d.read(transition_ref['path'])
        new_head = d.read(transition['new_index_ref']['path'])
        d.need(new_head['freeze_sha256'] == self.plan['freeze_sha256'],
               'new budget head/frozen plan binding')
        self._bootstrap_handoff_imported = digest
        return [*rows, *transition_rows], digest

    def _boundary(self, stage):
        token = self.sidecar.begin('init_final', stage)
        inherited_measurements = []
        try:
            self._load()
            if stage == 'initialization':
                initial = self.sidecar.grant['entry_initial_head']
                path = d.absolute(initial['index_path'])
                d.need(path.is_relative_to(self.workspace), 'initial head outside producer workspace')
                receipt_path = d.absolute(initial['receipt_path'])
                d.need(receipt_path.is_relative_to(self.workspace), 'initial receipt outside producer workspace')
                index, receipt = d.read(path), d.read(receipt_path)
                d.need(d.filehash(path) == initial['index_file_sha256'] and d.filehash(receipt_path) == initial['receipt_file_sha256'],
                       'initial current head pin')
                self.modules['bridge'].check_gate(self.gate, self.plan, self.roster, root=self.root,
                                                 workspace=self.workspace, storage=self.storage)
                rows = self.modules['bridge'].inspect_head(self.plan, self.roster, index, receipt, self.storage,
                            self.modules['protocol'], self.actual_status(path, receipt))
                d.need(rows == [], 'initial namespace is not empty')
                inherited_measurements, handoff_sha = self.bootstrap_receipts(receipt)
                result = self.save(0, stage, {'index': index, 'receipt': receipt, 'index_path': str(path),
                                             'namespace_initialization_handoff_file_sha256': handoff_sha,
                                             'output_budget_transition_ref': self.sidecar.grant['output_budget_transition_ref']})
            else:
                prior = self.saved(60, 'finish_position')
                rows = self.modules['bridge'].inspect_head(self.plan, self.roster, prior['index'], prior['receipt'],
                       self.storage, self.modules['protocol'], self.actual_status(prior['index_path'], prior['receipt']))
                d.need(len(rows) == 60 and all(row['state'] == 'terminal' for row in rows), 'final sixty terminals required')
                result = self.save(60, stage, {'logical_requests': 60, 'no_further_generation': True,
                                             'final_head': prior})
        except BaseException:
            # Durable pending stage survives; an uncertain original action cannot replay.
            raise
        state = self.sidecar.finish(token, local_receipts=[*inherited_measurements,
                                     d.local_measurement(token['started'], d.self_sample())])
        d.need(not state['halt'], 'boundary accounting violation')
        return result

    def initialize(self):
        return self._boundary('initialization')

    def finalize(self):
        return self._boundary('finalization')

    def local(self, position, stage):
        d.need(stage in LOCAL_FUNCTIONS, 'fixed local entry stage required')
        record = self.record(position)
        if stage == 'reserve_next':
            self.sidecar.reserve_slot(record)
        return self.sidecar.invoke_local(record['slot_id'], stage, LOCAL_FUNCTIONS[stage], self, position)

    def begin_library(self, position, stage):
        d.need(stage in d.LIBRARY_STAGES, 'fixed Library stage required')
        record = self.record(position)
        token = self.sidecar.begin(record['slot_id'], stage)
        self._load()
        if stage == 'claim_commit':
            value = self.saved(position, 'prepare_reserved')
            prior = self.head(position)[1]
            path = value['index_path']; is_index = True
        elif stage == 'archive_commit':
            value = self.saved(position, 'build_wave_archive')
            prior = (self.sidecar.grant['entry_initial_archive_receipt'] if position == 1
                     else self.saved(position - 1, 'archive_commit')['receipt'])
            path = value['local_blob_path']; is_index = False
        else:
            value = self.saved(position, 'finish_index')
            prior = self.saved(position, 'claim_commit')['receipt']
            path = value['index_path']; is_index = True
        d.need(prior['library_file_id'] == self.storage['index_library_file_id' if is_index else 'archive_library_file_id']
               and type(prior['current_version_number']) is int and prior['current_version_number'] >= 0,
               'exact activated Library namespace/version required before write')
        commit_arguments = [str(self.workspace), path, prior['library_file_id'], prior['current_version_number'], is_index]
        control = d.sealed({'token_sha256': d.sha(d.canon(token)), 'position': position, 'stage': stage,
                           'commit_arguments': commit_arguments,
                           'local_blob_sha256': d.filehash(d.absolute(path)),
                           'measurement': d.local_measurement(token['started'], d.self_sample())})
        d.publish_once(self.sidecar.root / f'entry-{position:02d}-{stage}-begin-control.json', control)
        return {'token': token, 'commit_arguments': commit_arguments, 'position': position, 'stage': stage,
                'timing_mode': 'unobservable', 'generation_execution_granted_by_this_result': False}

    def close_library(self, position, stage, snapshot, receipt):
        start = d.self_sample()
        d.need(stage in d.LIBRARY_STAGES, 'fixed Library close stage')
        token = self.sidecar.status()['pending']
        d.need(token and token['scope'] == self.record(position)['slot_id'] and token['stage'] == stage,
               'exact pending Library stage required')
        # Persist supplied actual receipt before closing the durable stage. If
        # verification fails, the pending stage remains and no stage can replay.
        self.save(position, stage, {'receipt': receipt})
        control = d.read(self.sidecar.root / f'entry-{position:02d}-{stage}-begin-control.json'); d.verify(control)
        d.need(control['token_sha256'] == d.sha(d.canon(token)), 'Library begin control binding')
        state = library.close_stage(self.sidecar, token, snapshot, receipt,
            extra_local_receipts=[control['measurement'], d.local_measurement(start, d.self_sample())])
        d.need(not state['halt'], 'Library stage outcome or measurement unknown')
        return state


def reserve_next(entry, position):
    entry._load()
    index, receipt, path = entry.head(position)
    value = entry.modules['bridge'].reserve_next(entry.root, entry.plan, entry.roster, index, receipt,
                entry.storage, entry.modules['protocol'], entry.actual_status(path, receipt), entry.gate)
    d.need(value is not None and value['record'] == entry.record(position), 'original scheduler position differs')
    return entry.save(position, 'reserve_next', value)


def prepare_reserved(entry, position):
    entry._load()
    index, receipt, _ = entry.head(position)
    updated, reservation, _checked = entry.modules['bridge'].prepare_reserved(
        **entry.common(position), index=index, receipt=receipt)
    path = entry.sidecar.root / f'entry-{position:02d}-claimed-index.json'
    d.publish_once(path, updated)
    return entry.save(position, 'prepare_reserved', {'index': updated, 'producer_reservation': reservation,
                                                   'index_path': str(path)})


def collect_reserved(entry, position):
    entry._load()
    value = entry.modules['bridge'].collect_reserved(**entry.common(position),
        producer_reservation=entry.saved(position, 'prepare_reserved')['producer_reservation'],
        fresh_claim_receipt=entry.saved(position, 'claim_commit')['receipt'])
    entry.save(position, 'collect_reserved', value)
    d.need(value.get('phase2_halt_required') is False, 'original capture integrity halt; no next stage')
    return value


def build_wave_archive(entry, position):
    entry._load()
    prior = None if position == 1 else entry.saved(position - 1, 'build_wave_archive')
    path = entry.sidecar.root / f'entry-{position:02d}-wave.zip'
    value = entry.modules['driver'].build_wave_archive(path, 2,
        prior_path=None if prior is None else prior['local_blob_path'],
        prior_sha256=None if prior is None else prior['local_blob_sha256'],
        additions=entry.modules['driver'].slot_additions(entry.workspace, entry.record(position)['slot_id']))
    return entry.save(position, 'build_wave_archive', value)


def finish_index(entry, position):
    entry._load()
    index = entry.modules['driver'].finish_index(entry.saved(position, 'prepare_reserved')['index'],
        entry.saved(position, 'collect_reserved'), entry.saved(position, 'archive_commit')['receipt'])
    path = entry.sidecar.root / f'entry-{position:02d}-terminal-index.json'
    d.publish_once(path, index)
    return entry.save(position, 'finish_index', {'index': index, 'index_path': str(path)})


def finish_position(entry, position):
    entry._load()
    head = entry.saved(position, 'finish_index'); receipt = entry.saved(position, 'terminal_commit')['receipt']
    ack = entry.modules['bridge'].finish_position(entry.root, entry.saved(position, 'reserve_next'), entry.plan,
        entry.roster, head['index'], receipt, entry.storage, entry.modules['protocol'],
        entry.actual_status(head['index_path'], receipt))
    return entry.save(position, 'finish_position', dict(head, receipt=receipt, original_terminal_ack=ack))


# Use the unchanged, already pinned original callables. The original Sidecar's
# operational path/name/hash checks remain intact; no new callable is whitelisted.
LOCAL_FUNCTIONS = original_entry.LOCAL_FUNCTIONS
for _function in LOCAL_FUNCTIONS.values():
    recovery.need(Path(__import__('inspect').getsourcefile(_function)).resolve() ==
                  _reference_root / 'production_generation_entry.py', 'original callable path drift')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--journal', required=True)
    parser.add_argument('--grant', required=True)
    parser.add_argument('--grant-sha256', required=True)
    parser.add_argument('--binding', help='Pinned read-only sidecar contract, required only for first initialize')
    parser.add_argument('--operation', required=True, choices=['initialize','local','library-begin','library-close','finalize'])
    parser.add_argument('--position', type=int)
    parser.add_argument('--stage')
    parser.add_argument('--snapshot')
    parser.add_argument('--receipt')
    args = parser.parse_args()
    journal = d.absolute(args.journal)
    grant = d.read(d.absolute(args.grant))
    if args.operation == 'initialize':
        d.need(args.binding is not None and not journal.exists(), 'initialize is once-only; existing/unknown journal cannot replay')
        binding = d.read(d.absolute(args.binding))
        d.need(journal == d.absolute(grant['sidecar_root']), 'exact grant journal')
        sidecar = d.Sidecar.create(binding, grant, args.grant_sha256)
    else:
        d.need(args.binding is None, 'binding only accepted for once-only initialization')
        identity = d.read(journal / 'identity.json')
        sidecar = d.Sidecar(journal, identity['binding'], grant, args.grant_sha256)
    entry = ProductionEntry(sidecar)
    if args.operation in ('initialize','finalize'):
        result = getattr(entry, args.operation)()
    elif args.operation == 'local':
        result = entry.local(args.position, args.stage)
    elif args.operation == 'library-begin':
        result = entry.begin_library(args.position, args.stage)
    else:
        result = entry.close_library(args.position, args.stage, d.read(d.absolute(args.snapshot)),
                                     d.read(d.absolute(args.receipt)))
    sys.stdout.buffer.write(d.canon(result))


if __name__ == '__main__':
    main()
