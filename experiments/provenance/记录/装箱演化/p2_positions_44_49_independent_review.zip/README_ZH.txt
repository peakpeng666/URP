原132主线P2第八批44–49：独立只读归档与恢复记录核验
2026-10-07 14:10 UTC

原data35成员/34hash，audit10成员/9hash：共43hash全部通过，包括原40项和新增3个恢复相关文件，ZIP CRC通过。6份prompt与原冻结pack逐字节相等，原runner/frozen_inputs/配置完全相同，CLI版本/binary pin和串行dispatch一致。未运行任何候选、runner、collector或恢复控制器。

44–48正常stop、exit0、回答非空，733/905/549/894/1596字节。49客户端timeout、exit -9、空输出，900.046862秒，usage未知；记录结束13:42:49.552400 UTC。累计P2前49/60有已核验原始包：41非空、1 length空、7 timeout空；原132计划121/132逻辑终态，不等于科学合格算法。

恢复核验范围：归档源码在继续前逐项读1–49的终态与prompt，要求50–60全部不存在永久槽目录，只循环50..60（最多11次），调用原runner同ledger。原runner原子mkdir永久claim未弱化；原日志和dispatch fence检查、已观察历史slot资源加总继续保留，原会话最终SELF计量和退出状态缺失仍为null，不重置历史预算、不认证全历史余额。

恢复JSON中的旧collector退出/active OpenCode=0是生产者记录的观察声明。续跑控制器自身没有进程探测；原collector的/proc检查在其main内，import不执行该main。包未包含当时ps/proc探测输出，本独审不能将声明升级为本次独立实时实测。客户端无进程不证明provider已取消、无服务器残留任务或零扣费。

data创建/修改均13:54:56.346Z，audit均13:56:50.099Z，均早于13:59。STATUS快照列50终态、current51；BATCH_REPORT列51永久目录/9未开始（STATUS剩余10含活动槽）。它们只是抓取时点快照，包内无50原dispatch/result，不能确定50准确启动时间或声称13:59后恢复；也不能确认当前活进程。只将44–49原data用于下一公开评分，50等后续完整批。

前43公开评分已独审交付，31完整/5AST拒绝/7生成失败；本审核不执行44–49评分、不另建stage、不发generation、不反馈生成器。恢复事实和脚本静态约束不代替provider真实HTTP/usage/账单或全历史资源证明。

原包仅引用不重复上传；本5文件小包包含check.py、REVIEW.json、来源与meta时间、说明及hash清单。只读审核CPU约0.03789秒，不含打包归档。
