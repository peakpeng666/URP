# R2 独立复审：仅离线实现接受

2026-10-06。范围限定为本次恢复实现与可信离线组件联调。**R1 的七项阻断/缺陷均已独立回归闭合，可接受 R2 的离线实现；尚未执行或批准实际生产恢复、Library 写入、GEN 激活或完整科学阶段。**

候选包 SHA-256：`0b8eac652f1d14290ccabf832ea3889141199cd0f64924c56bb7df9c82ba36d1`，604,369 B。425 个 manifest 成员大小/哈希全部通过，路径安全、无额外成员。R1 拒绝报告及其包保持原样。

## 七项逐项结论

| R1 项目 | R2 独立证据 | 结论 |
|---|---|---|
| R1-01 / P1：恢复计量缺失消费端必需语义 | 真实 `sample()` 记录真实 monotonic 区间且不扣 wait；旧 `Sidecar.finish` 接受。删掉语义字段的对照仍被恢复验证器及旧消费端拒绝。真实成功链全部 46 条被计入。 | 已修复；并非对旧历史样本补造语义 |
| R1-02 / P1：新 callable 被旧固定路径 gate 拒绝 | 新入口使用经完整旧 manifest/hash 核验的 `original_entry.LOCAL_FUNCTIONS`，六个函数均为旧函数对象；独立正确 path/hash 对照通过，六个错 hash 对照在 begin 前被拒绝。 | 已修复；旧 gate 未删除或放宽 |
| R1-03 / P1：错误 read 被接受 | 原独审普通 fixture 原样复跑：正确内容但 `isError=true` 被 `authenticated read error/unknown` 拒绝。 | 已修复 |
| R1-04 / P1：额外 unknown 旧 receipt 被忽略 | 原独审 fixture 原样复跑：额外 `helper-99.receipt.json` 被 `extra/orphan original receipt` 拒绝；作者也覆盖额外 intent。 | 已修复 |
| R1-05 / P2：回退 SELF / 不一致 wall 字段被接受 | 原独审脚本的同 process 累计 CPU 回退和 wall 字段不一致均被明确拒绝。 | 已修复 |
| R1-06 / P2：原 archive throw 被遮蔽且不留存 | 实际执行原 helper09 异常留存，得到 unknown receipt；原 exception 与新增失败证据一致，返回原 throw，archive 仅尝试一次。pending/HALT 保留，helper10 与 v2 均不存在。独立重算 10 条原 helper +19 条恢复 delta 与失败同池汇总完全一致。 | 已修复；异常没有被成功化或重放 |
| R1-07 / 条件性 P1：恢复后降级 v1 漏 delta | 对本次实际成功 fixture，`load_handoff` 和新 `ProductionEntry.bootstrap` 都拒绝 base v1；完整 v2 仍精确导入 14+32 条。 | 已修复；存在恢复 journal 必须完成 v2 |

证据：`CORE_BOUNDARY_RESULTS.json`、`EXCEPTION_INDEPENDENT_REGRESSION.json`、`importer_independent/boundary_results.json`、`importer_independent/completed_fixture_results.json`。相关独立检查脚本一并保留。

## 实际复跑范围

在独立 `execution/` 副本中执行，源码、测试、引用与开发 grant 均不改字节：

- Python 单元测试：17 项通过。
- 实际原组件联调：3 个测试方法、30 场景通过，包括成功链、14 个阶段各自 CPU/wall 阈值探针共 28 场景、原 archive 抛错留存场景。
- JavaScript 可信工具 fixture：20 场景通过。
- 阈值探针的当前 guard 样本明确标记为合成预算探针；它们只用于验证 admission，不能当成实测消耗或硬 CPU 上界。
- 成功链的原 helper00–12、原 assembler、32 个新增控制进程确实执行于新 TEST_ONLY namespace；它们的成本是真实本地测量，base 为 14 measurements /16 receipts，v2 为 46 measurements。
- 原生产五条 receipt 没有重跑或修改。测试的前五条由原代码在新的 fixture namespace 生成，绝不替换原历史测量。
- 实际旧 Sidecar 初始化接收全部 46 条；逐 process CPU checkpoint 和 wall 与独立重算结果一致，另含旧 Sidecar 自身控制成本。重复初始化被旧 begin 拒绝。
- 首个 local 阶段证明旧路径/hash gate 及真实 begin/end 计量连线；fixture 在 producer `_load` 前主动抛哨兵，未执行完整 reserve 事务、模型或科学代码。最终测试 journal 的 halt 正是此哨兵造成，成功的初始化不受影响。

日志在 `logs/`，明细在 `AUTHOR_SUITE_RESULTS.json`。测试侧替换的仅是授权源校验以保证 TEST_ONLY/GEN=false；因此未把它称为完整生产激活验证。

## 原始字节、路径与权限边界

- 与 R1 对比，16 类原绑定全部未变：原 grant、stop ZIP、bridge error、历史 create、pending、五对旧 intent/receipt、producer/journal/implementation 路径、原源 pin、原 GEN 源 pin/manifest、index/archive 与同一预算池。
- 20 份已有原引用源码与 R1 完全相同；六个新实现 pin 对应 R2 实际源码。
- 开发 grant 的 execution/review/GEN/numeric 标记均为 false。
- 只读检查了交付物及本地历史副本，未访问原 producer 实时磁盘。作者的 45 文件不变声明不能替代未来原 producer 在实际路径的复核。
- 没有真实 Library read/write、模型请求、生产 GEN、数值实验或科学 producer 派发。没有使用此前停止的 getter/TOCTOU 对抗复现。

## 小型交付问题

ZIP 未包含空的 `fixtures/` 目录，README 三条命令直接运行时第一条会因 `mkdtemp` 的父目录不存在而失败。独审仅补建空目录后全部套件通过，没有修改源码或 grant。

建议将复现命令前置 `mkdir -p fixtures`，或在 fixture 初始化时创建该目录，或把目录占位文件纳入 ZIP。这是复现前置条件遗漏，单列为非恢复逻辑阻断；它说明作者“换目录原样重跑”的证明没有覆盖没有预建目录的解压形态。

## 还缺的精确执行绑定

### A. 将来首次真实 suffix 恢复前

1. 形成独立的新 reconciliation 激活文件，而非把开发 grant 的 false 就地改为 true。绑定本次被接受的六个新源码的精确 hash、固定 `recoverSuffix` 入口、实际所在路径和全部不变的原 dependency pin；禁用 offline fixture 路径。
2. 绑定原 grant `fd7e0df05db28dc38b14a3231662c8f775db8472d46625f3c3a02a3c6e26166e`、原 stop/bridge error、历史 create、五条 intent/receipt、pending、实际 producer/journal 路径、index 的两个 ID /历史 v0 /859 B/hash、冻结 archive 的字节/hash、四个 P0/P1 禁止 ID。
3. 原 producer 在实际磁盘确认精确停点：没有原05–12、assembly、未知 recovery intent、额外 commit/readback、GEN/bridge 活动；旧五条和原源 pin 均未漂移。缺失、未知或冲突则停止，不删证据、不清 fence。
4. 明确固定动作顺序与同一 60 SELF /240 local-wall 池；index 新 create/replace=0，archive create≤1；未知不重放。计量包含原已观测 +所有新增 recovery +当前 guard，保留最后 checkpoint 之后成本 unknown。
5. 新 read 必须来自该次实际 authenticated 工具，并验证 backing 与当前 Library head。不能使用本次合成工具结果或历史 read raw 代替。历史 create 仍明确标作历史来源。
6. recovery 只允许原05/06、archive 后缀、原 assembler、新 v2 封存及已审失败留存窄路径。GEN、模型、candidate、numeric 均保持禁用。真实平台工具返回与异常行为尚未端到端验收；遇任何不符合已审边界的结果须停止。

### B. 成功真实恢复后才可准备 GEN

1. 独立终审实际 base14/16 和实际 v2 的 14+k、全部 recovery receipt/真实计量、finish seal、真实两条 namespace receipt 及新 unknown 清单；本次 fixture 的 k=32 不是生产实测证明。
2. GEN 激活精确 pin 实际 v2 文件和该次 reconciliation grant，不能指向 base v1；绑定实际 index/archive IDs、versions、receipt 文件与 head、producer/sidecar/bridge namespace。
3. GEN operational-source map 必须覆盖 R2 六个新源、入口实际加载的全部旧九个 reference dependency 以及原科学 contract。六个 local_call_targets 必须指向不变的原 `references/generation/production_generation_entry.py` 的真实路径、hash 和对应函数名，而不是新入口的重复函数定义。
4. 保留原 policy/accounting/inclusive supplement、原60个 P2 位置/请求/plan/roster/冻结来源、P1/heldout规则和全部源校验。实际 activation 仍须通过未覆盖的完整 `_check_sources`/原科学契约门控。
5. 在初始化时将真实 base+全部 delta 恰好一次计入同一个 init_final 池，之后的 GEN 边界与最终化继续共用该池。不得增发额度或在 import 之前宣称整阶段已验收。

## 无法通过本次离线审计改变的结论

历史 CPU/wall 尾部、Python pre-entry wall、JS/plugin/Library/provider 成本和历史缺失 raw 仍 unknown。新控制进程最后 checkpoint 后的尾部也 unknown。`CPU_cap_certification=NOT_ESTABLISHED`、完整 CPU 上界声明 false；60/240 和1860/61440只是已观测 checkpoint/阶段窗口 admission 阈值。mock 验收不等于生产恢复、真实平台验证或 GEN 激活。

R2 离线接受不自动产生任何外部操作权限。下一步由主线形成精确工程绑定并复核真实停点。
