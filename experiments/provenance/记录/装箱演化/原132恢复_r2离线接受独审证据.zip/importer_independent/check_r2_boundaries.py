"""Independent R2 ordinary trusted in-memory consumer fixtures; zero dispatch.
No received/execution files are edited. Local stage callables stop at a fixture
begin sentinel before executing. Receipt tests retain real downstream checks.
"""
import contextlib, hashlib, inspect, json
from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent
R=HERE.parent/'received'
sys.path[:0]=[str(R/'src'),str(R/'references/generation')]
import recovery_core as r
import durable_generation_sidecar as d
import production_generation_entry_v2 as v2
import production_generation_entry as original

class MemoryFinish(d.Sidecar):
    def __init__(self):
        self.token={'scope':'init_final','stage':'initialization','started':d.self_sample()}
        self.events=[{'kind':'begin','payload':self.token}]
        self.grant={}
    def locked(self):return contextlib.nullcontext()
    def _events(self):return self.events
    def _append(self,events,kind,payload):
        event={'kind':kind,'payload':payload};self.events.append(event);return event
class BoundaryReached(Exception):pass
class NoDispatch(d.Sidecar):
    def __init__(self,stage,function,wrong_hash=False):
        target=str(Path(inspect.getsourcefile(function)).resolve())
        digest=d.filehash(target)
        self.grant={'local_call_targets':{stage:{'path':target,'sha256':('0'*64 if wrong_hash else digest),'function':function.__name__}},
                    'operational_source_files':{target:digest}}
        self.binding={'package_path':str(HERE/'TEST_ONLY_package'),'external_source_root':str(HERE/'TEST_ONLY_external'),
                      'source_files':{},'external_source_files':{}}
        self.boundary_called=False
    def begin(self,*args,**kwargs):
        self.boundary_called=True;raise BoundaryReached('TEST_ONLY stop before begin or function dispatch')

m=r.sample();r.validate_measurement(m)
consumer=MemoryFinish();state=consumer.finish(consumer.token,local_receipts=[m])
assert state['halt']==[] and consumer.events[-1]['payload']['outcome']=='confirmed'
assert state['process_CPU_checkpoints'][m['process']]==m['end']['self_cpu']
# An intentionally incomplete ordinary data row still fails both validators.
bad={k:v for k,v in m.items() if k!='wall_semantics'}
try:r.validate_measurement(bad)
except r.Stop:recovery_rejects_missing=True
else:raise AssertionError('Recovery no longer requires semantics')
negative=MemoryFinish();badstate=negative.finish(negative.token,local_receipts=[bad])
assert badstate['halt']==['unknown_stage_outcome_or_measurement']
assert m['process'] not in badstate['process_CPU_checkpoints']

routes=[]
assert v2.LOCAL_FUNCTIONS is original.LOCAL_FUNCTIONS
for name,function in v2.LOCAL_FUNCTIONS.items():
    assert function is original.LOCAL_FUNCTIONS[name]
    source=Path(inspect.getsourcefile(function)).resolve()
    assert source==R/'references/generation/production_generation_entry.py'
    accepted=NoDispatch(name,function)
    try:accepted.invoke_local('TEST_ONLY_slot',name,function,None,1)
    except BoundaryReached:pass
    else:raise AssertionError('Test did not stop before dispatch')
    assert accepted.boundary_called
    rejected=NoDispatch(name,function,wrong_hash=True)
    try:rejected.invoke_local('TEST_ONLY_slot',name,function,None,1)
    except d.Stop as error:reason=str(error)
    else:raise AssertionError('Wrong hash unexpectedly passed')
    assert not rejected.boundary_called
    routes.append({'stage':name,'original_function_identity':True,'correct_source_gate_passed':True,
                   'wrong_hash_rejected_before_begin':True,'wrong_hash_reason':reason,'dispatches':0})

baseline=HERE.parents[2]/'original132_phase2_generation_accounting_20261006'
# Absolute baseline is the independent original package given to this audit.
baseline=Path('/workspace/scratch/27470b7a9f17/original132_phase2_generation_accounting_20261006')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
unchanged={name:sha(R/'references/generation'/name)==sha(baseline/name) for name in
           ('durable_generation_sidecar.py','production_generation_entry.py','library_stage_sidecar.py','OPERATING_SOURCE_MANIFEST.json')}
assert all(unchanged.values())
result={'scope':'Independent ordinary trusted in-memory offline fixtures; no GEN/producer/Library/model dispatch',
        'R1_01':{'real_sample_semantics':m['wall_semantics'],'no_wait_deduction':m['native_wait_union_seconds']==0,
                 'unchanged_sample_consumer_outcome':consumer.events[-1]['payload']['outcome'],
                 'halt':state['halt'],'CPU_checkpoint_present':m['process'] in state['process_CPU_checkpoints'],
                 'missing_semantics_rejected_by_recovery':recovery_rejects_missing,'missing_semantics_consumer_halt':badstate['halt']},
        'R1_02':{'all_six_routes':routes,'baseline_sources_unchanged':unchanged},
        'writes':'Only results under r2/importer_independent','dispatch_count':0}
(HERE/'boundary_results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
