"""Read-only R2 actual-local-process fixture result audit. No production dispatch.
Uses completed parent audit fixture outputs, verifies the unchanged importer,
and reads actual durable initialization events without writing to that fixture.
"""
import json,hashlib
from pathlib import Path
import sys
from types import SimpleNamespace
HERE=Path(__file__).resolve().parent
E=HERE.parent/'execution'
sys.path[:0]=[str(E/'src'),str(E/'references/generation')]
import recovery_core as r
from gen_importer_v2 import load_handoff
from production_generation_entry_v2 import ProductionEntry,d

fixtures=sorted((E/'fixtures').glob('real-*/producer/phase2-generation-accounting/identity.json'))
assert fixtures,'Waiting for completed parent actual integration fixture'
chosen=None
for identity in fixtures:
    root=identity.parents[2]
    events=sorted(identity.parent.glob('event-*.json'))
    if len(events)>=5 and (root/'producer.namespace-recovery/finish.receipt.json').exists():
        chosen=(root,identity,events);break
assert chosen,'Actual success fixture is not yet complete'
root,identity,eventpaths=chosen
for folder in ('src','tests'):
    for p in (E/folder).iterdir():
        if p.is_file():assert p.read_bytes()==(HERE.parent/'received'/folder/p.name).read_bytes()
gp=root/'RECOVERY.TEST_ONLY.DISABLED.json'
g=r.read(gp);g['_grant_ref']=r.ref(gp)
ref2=r.ref(root/'producer.namespace-recovery/RECONCILED_HANDOFF.v2.json')
ref1=r.ref(root/'producer.namespace-init/INIT_RESOURCE_HANDOFF.json')
h=r.read(ref2['path']);base=r.read(ref1['path']);rows,digest=load_handoff(ref2,g)
assert rows==h['measurements'] and len(rows)==46 and len(base['measurements'])==14 and len(base['receipt_files'])==16
assert h['recovery_measurement_count']==32
assert all(m['wall_semantics']=='local_stage_inclusive_no_wait_deduction' and not m.get('TEST_ONLY') for m in rows)
try:load_handoff(ref1,g)
except r.Stop as error:importer_v1_error=str(error)
else:raise AssertionError('v1 downgrade accepted')
entry=ProductionEntry.__new__(ProductionEntry)
entry.sidecar=SimpleNamespace(grant={'reconciliation_grant_ref':g['_grant_ref'],
    'namespace_initialization_handoff':ref1,'entry_initial_archive_receipt':h['archive_receipt']})
try:entry.bootstrap_receipts(h['index_receipt'])
except r.Stop as error:entry_v1_error=str(error)
else:raise AssertionError('Production bootstrap v1 downgrade accepted')
assert 'v1 downgrade' in importer_v1_error and 'v1 downgrade' in entry_v1_error
# Inspect exact real ledger initialization event produced by author's actual
# Sidecar begin/finish code. Read-only state reconstruction uses no locks/writes.
sc=d.Sidecar.__new__(d.Sidecar);sc.root=identity.parent;sc.identity=d.read(identity)
events=sc._events();state=sc._state(events)
init=[done for done in state['done'] if done['scope']=='init_final' and done['stage']=='initialization']
assert len(init)==1
posted=init[0]['result'];assert posted['outcome']=='confirmed'
assert sorted(posted['local_receipts'],key=r.canon)==sorted(rows,key=r.canon)
expected_cpu,expected_wall=r.totals(rows)
controls=posted['sidecar_control_receipt'];cp=controls['process']
assert abs(posted['self_cpu_seconds']-posted['process_CPU_checkpoints'][cp]-expected_cpu)<1e-7
assert abs(posted['local_inclusive_wall_seconds']-controls['local_inclusive_wall_seconds']-expected_wall)<1e-7
assert set(posted['process_CPU_checkpoints'])-{cp}=={m['process'] for m in rows}
assert h['pool']=={'SELF_checkpoint_seconds':60,'local_inclusive_wall_seconds':240,'new_budget':False}
assert h['unknown']==r.UNKNOWN and h['CPU_cap_certification']=='NOT_ESTABLISHED' and h['complete_CPU_upper_bound_claimed'] is False
assert h['new_post_checkpoint_CPU_tails'] is None and h['new_post_checkpoint_wall_tails'] is None
result={'scope':'Read-only completed isolated fixture; measured original local helpers/assembler and recovery processes, synthetic Library replies; zero production dispatch',
    'fixture':str(root),'new_source_and_test_bytes_match_received':True,
    'base_measurements':14,'base_receipts':16,'recovery_measured_delta_rows':32,'combined_rows':46,
    'all46_semantics_present_without_importer_normalization':True,'all46_without_TEST_ONLY_measurement_override':True,
    'v2_exact_import':True,'v1_importer_rejected':importer_v1_error,'v1_bootstrap_rejected':entry_v1_error,
    'real_sidecar_initialization_outcome':posted['outcome'],'real_sidecar_initialization_event_count':len(init),
    'all46_exact_rows_posted_once':True,'all46_process_checkpoints_present':True,
    'init_final_CPU_matches_rows_plus_original_sidecar_control':True,'init_final_wall_matches_rows_plus_original_sidecar_control':True,
    'pool':h['pool'],'unknown':h['unknown'],'CPU_cap_certification':h['CPU_cap_certification'],
    'complete_CPU_upper_bound_claimed':h['complete_CPU_upper_bound_claimed'],
    'observed_final_fixture_halt':state['halt'],
    'final_fixture_halt_explanation':'Expected intentional stop before producer import in reserve_next; initialization had confirmed with all46.',
    'real_GEN_Library_model_dispatches':0,'writes':'Only this result file in r2/importer_independent'}
(HERE/'completed_fixture_results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
