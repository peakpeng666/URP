# R2 independent v2 handoff / GEN importer audit

**Scoped conclusion: R1-01, R1-02 and R1-07 are closed by R2 in ordinary offline tests. No remaining blocker found in these three fixes. This is not production recovery/GEN activation approval.**

R2 package SHA256: `0b8eac652f1d14290ccabf832ea3889141199cd0f64924c56bb7df9c82ba36d1`. Received package remained read only. Independent post-check: all425 manifest entries and all11 available original GEN references match. R1 evidence remains preserved separately.

## R1-01: genuine sample now satisfies the unchanged consumer

- `src/recovery_core.py:37–44` obtains RUSAGE_SELF and monotonic end samples; wall is exactly end minus module-entry time, with zero wait deduction. It now labels those actual semantics at the source.
- `:45–60` requires the semantic field and verifies wall/CPU consistency. `gen_importer_v2.py:33–48` returns original rows unchanged; it does not retrofit a tag onto invalid evidence.
- Independent real-sample → actual original `Sidecar.finish` test: confirmed, no halt, recovery process checkpoint present. A separate missing-field negative control still fails both the recovery validator and the original consumer.
- Original `durable_generation_sidecar.py` is byte-identical, including its semantic checks at `:372–390`.

## R1-02: original callable objects are reused; path/hash gates remain

- `production_generation_entry_v2.py:16–24` validates the original reference manifest/files before importing the original entry.
- `:286–291` uses `original_entry.LOCAL_FUNCTIONS` and checks each function's actual source path. The v2 dispatch at `:173–178` therefore supplies the original function objects.
- Independent tests checked all six functions: object identity matches the original map; correct path/hash passes the unchanged `Sidecar.invoke_local` source gate; wrong-hash controls are still rejected before begin. Test sentinels prevented every callable dispatch.
- The draft now explicitly maps all six local targets to `references/generation/production_generation_entry.py`, hash `686811066a7d097302fe389aef22efc64e26f7f09ef923b10f44229341f68154` (`GEN_IMPORT_COMPATIBILITY.DRAFT.json:54–85`).

## R1-07: recovered v1 downgrade is rejected

- `gen_importer_v2.py:6–8` rejects v1 whenever the exact recovery journal root exists.
- Independent read-only test against the parent's completed original-local-code fixture verified both `load_handoff` and `ProductionEntry.bootstrap_receipts` reject its base v1 with `recovered namespace requires completed exact v2; no v1 downgrade`.
- Its exact v2 still passes and returns 14+32 rows unchanged. Author regression is at `tests/test_recovery.py:71–83` and actual-local-code integration at `tests/test_real_integration.py:48–53`.

## Actual original Sidecar coverage verified

Read-only evidence: parent's completed fixture `execution/fixtures/real-zjwkqynx`.

- Original base has14 measurements/16 receipts;32 recovery measurements produce46 total.
- All46 measurements have the required semantics without importer normalization or TEST_ONLY measurement substitution in the successful run. Their values were measured from isolated original helper/assembler and recovery processes; Library replies remain synthetic.
- Exact46 rows occur once in a confirmed original Sidecar initialization event. All46 process checkpoints are present. `init_final` CPU and wall equal their measured totals plus the original sidecar control contribution.
- Same60 SELF/240 local-inclusive-wall pool and `new_budget=false` remain. Unknown values, new null tails, `CPU_cap_certification=NOT_ESTABLISHED`, and no complete CPU-upper-bound claim remain.
- The author's code rejects repeated initialization (`test_real_integration.py:61`). Its later reserve_next deliberately throws before producer import; the final fixture halt is expected from that test sentinel, not an initialization/import failure.

Coverage limit: the integration uses a fixture-scoped `_check_sources` override (`test_real_integration.py:19–37`), invokes bootstrap separately, then actual `Sidecar.begin/finish/invoke_local` (`:48–70`). It does not execute full production `ProductionEntry.initialize/_boundary`, real producer `_load`, real Library, scientific GEN, all60 positions, finalization, or a production activation grant. This limitation is appropriate for the authorized offline audit and must remain explicit.

## Precise future activation bindings still required

1. Issue a separately reviewed recovery grant for the final consumer-local source paths/hashes, authentic original namespace/stop/pending/00–04 evidence, old grant and original source maps. The shipped development grant remains disabled. Do not repurpose TEST_ONLY fixture grants/receipts or edit historical evidence.
2. After actual authorized recovery succeeds and is separately reviewed, bind the actual completed v2 `{path,file_sha256}`, actual reconciliation grant reference, original base14/16 plus every actual delta, and exact current index/archive commit receipts. No actual k or runtime cost can be substituted from this fixture. Preserve the original60/240 pool, unknowns and cap status.
3. The separate GEN grant must bind the same producer workspace/run and original package/plan/roster/request contract, reviewed policy/accounting/inclusive-wall supplement, exact existing bridge gate, fixed generation sidecar root, and canonical grant/binding digest. Existing `Sidecar.validate_grant` requirements at `durable_generation_sidecar.py:166–216` still apply.
4. Populate `namespace_initialization_handoff`, `reconciliation_grant_ref`, `entry_initial_archive_receipt`, and `entry_initial_head` with the actual index/receipt paths and file hashes. The bootstrap receipt equality check remains at `production_generation_entry_v2.py:118–126`; current-head path/hash checks remain at `:136–143`. The compatibility draft's actual-reference fields are correctly null (`:35–41`), not activation-ready.
5. Pin the entire new six-file source set and every actual original GEN dependency in the consumer-local operational map, not only the new entry. Also pin the five producer entry modules (`entry_source_files`) and all unchanged local-helper/Library hook targets. Map all six `local_call_targets` to the **original referenced entry file** and its exact names/hash, while invoking the **new v2 entry** as the entrypoint. Do not bind local targets to the duplicate definitions in the new file, or relax the original sidecar source gate.

## Evidence / safety

`check_r2_boundaries.py` → `boundary_results.json`; `check_r2_completed_fixture.py` → `completed_fixture_results.json`; `source_integrity.json`.

Independent commands used `python3 -I -B`. Only report/test/result files under `r2/importer_independent` were written. Received and parent execution copies were not edited. Zero real Library/model/producer/scientific GEN dispatches; no stopped getter/TOCTOU reproduction; no production or author-source changes. Parent owns the full author-suite result; this report verifies the scoped boundaries and completed success-fixture evidence independently.

Final parent-suite artifact inspected after completion: `execution/audit/REAL_INTEGRATION_RESULTS.json` reports success,3 methods/30 scenarios. Its successful fixture is exactly the independently inspected fixture above. Full suite counts reported by parent:17 unit tests,30 actual-local-code scenarios,20 JavaScript cases.
