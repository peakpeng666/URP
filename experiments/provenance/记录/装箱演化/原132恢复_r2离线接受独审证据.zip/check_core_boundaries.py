"""Ordinary trusted data boundaries only. No live tools, getters or TOCTOU tests."""
from pathlib import Path
import sys,json,copy
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'execution/tests'))
from fixture_support import Fixture, Clock, validate_read, totals, canon

results={}
f=Fixture();raw=f.readraw();raw['isError']=True
try:
    validate_read(raw,f.g['index'],(f.w/'index.initial.json').read_bytes())
    results['read_error_flag']={'rejected':False,'actual':'validate_read accepted isError=true with otherwise correct frozen data'}
except Exception as e:results['read_error_flag']={'rejected':True,'error':str(e)}

f=Fixture();(f.j/'helper-99.receipt.json').write_bytes(canon({'outcome':'unknown','TEST_ONLY':True}))
try:
    f.enter()
    results['unexpected_old_receipt']={'rejected':False,'actual':'entry accepted additional unknown helper-99.receipt.json','fixture':str(f.root)}
except Exception as e:results['unexpected_old_receipt']={'rejected':True,'error':str(e)}

c=Clock();a=c.command(.2,.1);b=c.command(.1,.1)
b['process']=a['process'];b['start']['process']=b['end']['process']=a['process']
try:
    result=totals([a,b])
    results['regressed_CPU_checkpoint']={'rejected':False,'totals':result,'actual':'later SELF checkpoint regression accepted via max'}
except Exception as e:results['regressed_CPU_checkpoint']={'rejected':True,'error':str(e)}

c=Clock();a=c.command(.2,.1);a['wall_seconds']=999
try:
    result=totals([a])
    results['inconsistent_wall_seconds']={'rejected':False,'totals':result,'actual':'wall_seconds differs from real local interval but passes recovery validation'}
except Exception as e:results['inconsistent_wall_seconds']={'rejected':True,'error':str(e)}

(BASE/'CORE_BOUNDARY_RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
