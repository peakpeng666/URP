"""Read-only independent check of a completed trusted actual-component fixture."""
from pathlib import Path
import json,hashlib,math
BASE=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
summary=read(BASE/'execution/audit/REAL_INTEGRATION_RESULTS.json')
case=next(x for x in summary['results'] if x['case']=='original_archive_exception_retention')
root=Path(case['fixture']);w=root/'producer';j=root/'producer.namespace-init';r=root/'producer.namespace-recovery'
original=[read(p) for p in sorted(j.glob('helper-*.receipt.json'))]
delta=[read(p) for p in sorted(r.glob('delta-*.receipt.json'))]
failure=read(r/'failure.retention.receipt.json')
measurements=[x['measurement'] for x in original+delta]
checkpoints={}
for m in measurements:
    assert m['wall_semantics']=='local_stage_inclusive_no_wait_deduction' and not m.get('TEST_ONLY')
    checkpoints[m['process']]=max(checkpoints.get(m['process'],0),m['end']['self_cpu'])
cpu=sum(checkpoints.values())
wall=sum(m['end']['monotonic']-m['start']['monotonic'] for m in measurements)
assert math.isclose(cpu,failure['observed_shared_pool'][0],rel_tol=0,abs_tol=1e-8)
assert math.isclose(wall,failure['observed_shared_pool'][1],rel_tol=0,abs_tol=1e-8)
assert len(original)==10 and original[-1]['outcome']=='unknown'
assert original[-1]['step']=='archive.retain-response'
assert not (j/'helper-10.intent.json').exists() and not (r/'RECONCILED_HANDOFF.v2.json').exists()
assert (w/'state/external-pending.json').exists() and (r/'HALTED.json').exists()
assert read(w/'retained-library-replies/phase2-init-archive/exception.json')==read(r/'archive-exception.raw.json')
out=read(root/'bridge.actual-result.json')
assert out['calls']['archive_creates']==1 and out['calls']['index_creates']==out['calls']['replacements']==0
assert 'TEST_ONLY original archive throw' in out['error']
for p in j.glob('helper-*.intent.json'):
    intent=read(p)
    assert sha(Path(intent['script_path']))==intent['script_sha256']
    assert read(p.with_name(p.name.replace('.intent.','.receipt.')))['intent_file_sha256']==sha(p)
print(json.dumps({'PASS':True,'fixture':str(root),'original_helpers':len(original),'recovery_deltas':len(delta),
                  'observed_SELF':cpu,'observed_wall':wall,'real_Library_or_GEN_calls':0}))
