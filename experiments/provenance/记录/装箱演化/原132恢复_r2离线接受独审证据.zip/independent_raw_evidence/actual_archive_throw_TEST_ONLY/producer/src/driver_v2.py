"""Minimal producer stages; all authenticated Library commits are assistant-only.

prepare -> confirmed claim -> capture_once -> confirmed wave ZIP -> confirmed
terminal index. There is no automatic resume, reroll, scoring or extraction.
"""
import copy
import json
from pathlib import Path, PurePosixPath
import zipfile

from protocol_v2 import (canon, digest, sha, need, read_json, verify_index, verify_seal,
                         claim_index, terminal_index, build_export, make_invocation_receipt,
                         verify_export, atomic_write, MAX_INDEX)
from capture_v2 import check_input, check_live_gate, capture_once

MAX_ZIP = 48 * 1024 * 1024
MAX_EXPANDED = 64 * 1024 * 1024


def producer_source_sha(root=None):
    root = Path(root) if root is not None else Path(__file__).resolve().parent.parent
    paths = sorted((root / 'src').glob('*.py')) + sorted((root / 'src').glob('*.js'))
    return digest({p.relative_to(root).as_posix(): sha(p.read_bytes()) for p in paths})


def prepare(index, index_receipt, pack, claim, freeze, config_bytes, base_bytes, route_bytes, gate, workspace=None):
    """All prompt, configuration and launch checks occur before external claim."""
    verify_index(index)
    startup_guard(index)
    if workspace is not None:
        need(not (Path(workspace)/'state/external-pending.json').exists(), 'external_write_pending_stop_reconcile')
    need(index_receipt['write_result_confirmed'] is True and index_receipt['index_readback_confirmed'] is True
         and index_receipt['local_blob_sha256'] == sha(canon(index)), 'index_head_unconfirmed')
    checked = check_input(pack, claim, freeze, config_bytes, base_bytes, route_bytes)
    if freeze['mode'] == 'official_cli':
        need(workspace is not None, 'production_workspace_required')
        check_live_gate(freeze, gate, producer_source_sha())
        need(pack['phase'] == gate.get('authorized_phase') and pack['sha256'] in gate.get('authorized_request_sha256', []), 'request_outside_dispatch_authorization')
    else:
        need(freeze['mode'] == 'fixture_only', 'unsupported_mode')
    updated, reservation = claim_index(index, claim, pack['arm'], sha(config_bytes))
    return updated, reservation, checked


def collect_slot(root, claim, reservation, freeze, config_bytes, checked, fresh_claim_receipt,
                 *, gate=None, fixture_command=None):
    raw, terminal, evidence, metadata = capture_once(
        Path(root), claim, reservation, freeze, config_bytes, checked, fresh_claim_receipt,
        gate=gate, exporter_source_sha256=producer_source_sha(), fixture_command=fixture_command)
    directory = Path(root) / 'retained' / claim['slot_id']
    need(not directory.exists(), 'retained_slot_already_exists_never_rerun')
    directory.mkdir(parents=True)
    files = {'raw.txt': raw, 'config.raw.json': config_bytes, 'session-evidence.json': evidence,
             'metadata.json': canon(metadata)}
    receipt = make_invocation_receipt(claim, reservation, config_bytes, evidence)
    packet = build_export(claim, reservation, config_bytes, freeze['configuration'],
                          {'binary_sha256': freeze['cli_binary_sha256'], 'exporter_source_sha256': freeze['exporter_source_sha256'],
                           'version': freeze['cli_version'], 'mode': freeze['mode']}, evidence, raw, terminal)
    files.update({'export.json': packet, 'invocation-receipt.json': canon(receipt)})
    for name, value in files.items():
        atomic_write(directory / name, value)
    valid = True
    try:
        verify_export(packet, sha(packet), claim, reservation, freeze, receipt, config_bytes, evidence)
    except Exception:
        valid = False  # Retain full bounded artifacts; do not rescue a prefix.
    return {'slot_id': claim['slot_id'], 'claim_id': claim['claim_id'], 'invocation_id': reservation['invocation_id'],
            'artifact_sha256': sha(packet), 'session_evidence_sha256': sha(evidence),
            'invocation_receipt_sha256': sha(canon(receipt)), 'config_file_sha256': sha(config_bytes),
            'actual_session_id': receipt['actual_session_id'], 'status': terminal['status'],
            'capture_complete': terminal['capture_complete'], 'schema_integrity_verified_locally': valid,
            'model_requests': 0 if fixture_command is not None else None}


def read_archive(path, expected_hash=None):
    path = Path(path)
    need(path.is_file() and not path.is_symlink() and path.stat().st_size <= MAX_ZIP, 'local_archive_unavailable_or_large')
    data = path.read_bytes()
    need(expected_hash is None or sha(data) == expected_hash, 'local_archive_hash')
    files = {}
    with zipfile.ZipFile(path) as z:
        info = z.infolist()
        need(len(info) <= 512 and sum(x.file_size for x in info) <= MAX_EXPANDED, 'archive_expanded_bound')
        for e in info:
            n, p = e.filename, PurePosixPath(e.filename)
            need(not p.is_absolute() and '..' not in p.parts and '\\' not in n and ':' not in n and n not in files, 'unsafe_duplicate_archive_path')
            need(not e.is_dir() and (e.external_attr >> 16) & 0o170000 != 0o120000 and not e.flag_bits & 1, 'archive_special_or_encrypted')
            files[n] = z.read(n)  # Opaque bytes; never interpret candidate source.
        need(z.testzip() is None, 'archive_crc')
    return files


def build_wave_archive(path, phase, prior_path=None, prior_sha256=None, additions=None):
    files = {} if prior_path is None else read_archive(prior_path, prior_sha256)
    files.pop('wave-manifest.json', None); files.pop('file-hashes.json', None)
    for name, data in (additions or {}).items():
        need(name not in files, 'archive_slot_member_already_present')
        files[name] = data
    slots = sorted({n.split('/')[1] for n in files if n.startswith('slots/')})
    need(len(slots) <= (12, 60, 60)[phase], 'wave_archive_slot_cap')
    manifest = {'schema': 'eoh-raw-wave-archive-v2', 'phase': phase, 'slots': slots,
                'retention': 'unmodified_public_terminal_bytes_and_bounded_evidence',
                'remote_byte_verification': 'deferred_to_independent_consumer'}
    files['wave-manifest.json'] = canon(manifest)
    files['file-hashes.json'] = canon({n: {'bytes': len(d), 'sha256': sha(d)} for n, d in sorted(files.items())})
    need(len(files) <= 512 and sum(map(len, files.values())) <= MAX_EXPANDED, 'wave_archive_bound')
    path = Path(path)
    need(not path.exists(), 'archive_output_exists')
    path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(path, 'x', compression=zipfile.ZIP_DEFLATED) as z:
        for n, d in sorted(files.items()):
            z.writestr(n, d)
    need(path.stat().st_size <= MAX_ZIP, 'wave_zip_byte_bound')
    retained = read_archive(path)
    need(retained == files, 'archive_local_byte_identity')
    return {'local_blob_path': str(path), 'local_blob_sha256': sha(path.read_bytes()), 'local_blob_bytes': path.stat().st_size,
            'slot_count': len(slots), 'phase': phase}


def slot_additions(root, slot_id):
    directory = Path(root) / 'retained' / slot_id
    return {f'slots/{slot_id}/{name}': (directory / name).read_bytes() for name in
            ('raw.txt', 'export.json', 'metadata.json', 'session-evidence.json', 'invocation-receipt.json', 'config.raw.json')}


def finish_index(index, summary, archive_receipt):
    need(summary['schema_integrity_verified_locally'] is True, 'retained_capture_integrity_halt')
    ref = {k: summary[k] for k in ('artifact_sha256', 'session_evidence_sha256', 'invocation_receipt_sha256',
                                  'config_file_sha256', 'actual_session_id', 'status', 'capture_complete')}
    ref.update(archive_file_id=archive_receipt['file_id'], archive_version=archive_receipt['current_version_number'])
    return terminal_index(index, summary['claim_id'], ref, archive_receipt)


def safe_commit_receipt(result_identity, local_path, prior_version, *, index_readback_confirmed=False):
    """Library success metadata proves acknowledgment, never remote byte identity."""
    need(result_identity['status'] == 'succeeded' and type(result_identity['current_version_number']) is int
         and result_identity['current_version_number'] > prior_version, 'external_write_unconfirmed_or_version')
    data = Path(local_path).read_bytes()
    return {'library_file_id': result_identity['library_file_id'], 'file_id': result_identity['file_id'],
            'current_version_number': result_identity['current_version_number'], 'write_result_confirmed': True,
            'local_blob_sha256': sha(data), 'local_blob_bytes': len(data),
            'remote_bytes_verified': False, 'index_readback_confirmed': index_readback_confirmed}


def startup_guard(index):
    verify_index(index)
    need(not any(r['state'] == 'claimed' for r in index['rows']), 'existing_claim_unknown_dispatch_stop_never_rerun')
    return True
