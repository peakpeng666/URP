"""Durable local stop fence around an authenticated Library write."""
from pathlib import Path
import json
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from protocol_v2 import atomic_write, canon, need, read_json, sha

action, root, path, identity, prior, kind = sys.argv[1:7]
root, path, prior = Path(root), Path(path), int(prior)
pending = root / 'state/external-pending.json'
record = {'schema': 'library-write-pending-v2', 'local_blob_sha256': sha(path.read_bytes()),
          'local_blob_bytes': path.stat().st_size, 'library_file_id': None if identity == 'null' else identity,
          'expected_current_version': prior, 'kind': kind}
if action == 'begin':
    pending.parent.mkdir(parents=True, exist_ok=True)
    # Exclusive creation prevents concurrent or uncertain writes from being hidden.
    import os
    fd = os.open(pending, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(canon(record)); stream.flush(); os.fsync(stream.fileno())
        directory = os.open(pending.parent, os.O_RDONLY)
        try: os.fsync(directory)
        finally: os.close(directory)
    except BaseException:
        # An incomplete marker still blocks the next launch or write.
        raise
    print('{"pending_fence_created":true}')
elif action == 'confirm':
    need(read_json(pending.read_bytes(), 4096) == record, 'external_pending_identity_changed')
    receipt = json.load(sys.stdin)
    need(receipt['write_result_confirmed'] is True and receipt['local_blob_sha256'] == record['local_blob_sha256']
         and receipt['current_version_number'] > prior
         and (record['library_file_id'] is None or receipt['library_file_id'] == record['library_file_id'])
         and (kind != 'index' or receipt['index_readback_confirmed'] is True), 'external_confirm_mismatch')
    target = root / 'state/commits' / (receipt['library_file_id'] + '-' + str(receipt['current_version_number']) + '.json')
    need(not target.exists(), 'external_receipt_already_present')
    atomic_write(target, canon(receipt))
    pending.unlink()
    import os
    directory = os.open(pending.parent, os.O_RDONLY)
    try: os.fsync(directory)
    finally: os.close(directory)
    print('{"acknowledgment_retained":true,"pending_fence_cleared":true}')
else:
    raise ValueError('unsupported_fence_action')
