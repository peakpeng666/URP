from pathlib import Path
import json
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from protocol_v2 import need, read_json, canon, sha, verify_index
from driver_v2 import safe_commit_receipt

path, prior, kind = Path(sys.argv[1]), int(sys.argv[2]), sys.argv[3]
message=json.loads(Path(sys.argv[4]).read_text('utf-8')) if len(sys.argv)>4 else json.load(sys.stdin)
confirmed=False
if kind=='index':
    row=message['readback']
    need(row['has_more'] is False and row['file_id']==message['item']['file_id']
         and row['library_file_id']==message['item']['library_file_id'],'index_readback_identity')
    remote=read_json(row['content'].encode(),524288)
    verify_index(remote)
    need(sha(canon(remote))==sha(path.read_bytes()) and path.read_bytes()==canon(remote),'index_canonical_payload_hash')
    confirmed=True
print(json.dumps(safe_commit_receipt(message['item'],path,prior,index_readback_confirmed=confirmed)))
