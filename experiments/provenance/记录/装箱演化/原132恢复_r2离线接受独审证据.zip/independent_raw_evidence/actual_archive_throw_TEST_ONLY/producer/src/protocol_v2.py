"""V2 evidence contracts. Candidate terminal text is always opaque bytes."""
import base64
import copy
import hashlib
import json
import math
from pathlib import Path

MAX_RAW = 262144
MAX_EXPORT = 524288
MAX_INDEX = 524288
MAX_EVIDENCE = 65536
MAX_INPUT = 1048576
PHASE_CAPS = (12, 60, 60)
SETTINGS_EVIDENCE = 'configured_settings_not_observed_wire_parameters'


class Stop(RuntimeError):
    pass


def need(test, reason):
    if not test:
        raise Stop(reason)


def canon(v):
    return json.dumps(v, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8')


def sha(b):
    return hashlib.sha256(b).hexdigest()


def digest(v):
    return sha(canon(v))


def is_hash(v):
    return type(v) is str and len(v) == 64 and set(v) <= set('0123456789abcdef')


def identifier(v):
    return type(v) is str and 0 < len(v.encode()) <= 128 and all(c.isalnum() or c in '_.-' for c in v)


def sealed(v):
    need('sha256' not in v, 'already_sealed')
    return dict(v, sha256=digest(v))


def verify_seal(v):
    need(type(v) is dict and is_hash(v.get('sha256')), 'seal_type')
    body = {k: x for k, x in v.items() if k != 'sha256'}
    need(digest(body) == v['sha256'], 'seal_hash')
    return body


def read_json(raw, cap=MAX_EXPORT):
    need(type(raw) is bytes and 0 < len(raw) <= cap, 'json_byte_bound')
    def pairs(entries):
        out = {}
        for k, v in entries:
            need(k not in out, 'duplicate_json_key')
            out[k] = v
        return out
    def constant(_):
        raise Stop('nonfinite_json')
    v = json.loads(raw.decode('utf-8', errors='strict'), object_pairs_hook=pairs, parse_constant=constant)
    stack = [(v, 0)]
    count = 0
    while stack:
        x, d = stack.pop()
        count += 1
        need(d <= 16 and count <= 50000, 'json_structure_bound')
        if type(x) is dict:
            stack.extend((p, d + 1) for p in x.values())
        elif type(x) is list:
            stack.extend((p, d + 1) for p in x)
        elif type(x) is float:
            need(math.isfinite(x), 'nonfinite_json')
        elif type(x) is int:
            need(x.bit_length() <= 128, 'integer_bound')
    canon(v)
    return v


def session_semantics(evidence_bytes):
    e = read_json(evidence_bytes, MAX_EVIDENCE)
    need(set(e) == {'schema', 'claim_id', 'invocation_id', 'config_file_sha256',
                    'resume_requested', 'state_was_empty', 'process_started_unix_ms',
                    'process_terminal_unix_ms', 'observations', 'creation'}, 'session_evidence_fields')
    need(e['schema'] == 'opencode-session-evidence-v2' and e['resume_requested'] is False, 'resume_or_evidence_schema')
    need(type(e['state_was_empty']) is bool, 'state_evidence_type')
    need(type(e['observations']) is list and len(e['observations']) <= 128, 'session_observation_bound')
    ids = []
    for o in e['observations']:
        need(set(o) == {'event_type', 'session_id', 'part_session_id', 'message_id'}, 'session_observation_fields')
        need(o['event_type'] in ('step_start', 'text', 'step_finish', 'tool_use', 'error', 'reasoning'), 'session_event_type')
        for sid in (o['session_id'], o['part_session_id']):
            need(sid is None or identifier(sid), 'session_id_type')
            if sid is not None and sid not in ids:
                ids.append(sid)
        need(o['message_id'] is None or identifier(o['message_id']), 'message_id_type')
    need(len(ids) <= 2, 'unbounded_session_integrity_failure')
    actual = ids[0] if len(ids) == 1 else None
    c = e['creation']
    need(set(c) == {'source', 'id', 'parent_id', 'time_created'}, 'creation_fields')
    need(c['source'] in ('official_local_session_row', 'fixture_local_session_row', 'unavailable'), 'creation_source')
    need(c['id'] is None or identifier(c['id']), 'creation_id')
    need(c['parent_id'] is None or identifier(c['parent_id']), 'creation_parent')
    need(c['time_created'] is None or type(c['time_created']) is int, 'creation_time')
    start, end = e['process_started_unix_ms'], e['process_terminal_unix_ms']
    need(type(start) is int and type(end) is int and start <= end, 'process_time_evidence')
    created = (actual is not None and c['id'] == actual and c['parent_id'] is None
               and c['source'] != 'unavailable' and type(c['time_created']) is int
               and start <= c['time_created'] <= end and e['state_was_empty'] is True)
    return {'actual_session_id': actual, 'observed_session_ids': ids,
            'new_session_observed': created, 'resume_requested': False}


TOP = {'schema', 'claim_id', 'slot_id', 'invocation_id', 'request_sha256',
       'configured_settings_sha256', 'config_file_sha256', 'cli', 'terminal', 'raw_b64', 'raw_sha256'}
CLI = {'binary_sha256', 'exporter_source_sha256', 'version', 'mode', 'configured_settings',
       'settings_evidence', 'wire_parameters', 'actual_session_id', 'observed_session_ids',
       'new_session_observed', 'resume_requested', 'session_evidence_sha256'}
TERMINAL = {'status', 'process_terminal', 'capture_complete', 'finish_reason', 'tool_calls',
            'usage', 'physical_http_attempts', 'exit_code'}
USAGE = {'input_tokens', 'output_tokens', 'reasoning_tokens', 'wall_seconds'}


def build_export(claim, reservation, config_bytes, configured_settings, cli_provenance,
                 session_evidence_bytes, raw, terminal):
    verify_seal(claim)
    verify_seal(reservation)
    need(type(raw) is bytes and len(raw) <= MAX_RAW, 'raw_byte_bound')
    raw.decode('utf-8', errors='strict')
    evidence = read_json(session_evidence_bytes, MAX_EVIDENCE)
    need(evidence['claim_id'] == claim['claim_id'] and evidence['invocation_id'] == reservation['invocation_id'], 'session_identity_binding')
    need(evidence['config_file_sha256'] == sha(config_bytes), 'session_config_binding')
    cli = dict(cli_provenance, configured_settings=copy.deepcopy(configured_settings),
               settings_evidence=SETTINGS_EVIDENCE, wire_parameters=None,
               **session_semantics(session_evidence_bytes), session_evidence_sha256=sha(session_evidence_bytes))
    value = {'schema': 'bounded-official-cli-export-v2', 'claim_id': claim['claim_id'],
             'slot_id': claim['slot_id'], 'invocation_id': reservation['invocation_id'],
             'request_sha256': claim['request_sha256'], 'configured_settings_sha256': digest(configured_settings),
             'config_file_sha256': sha(config_bytes), 'cli': cli, 'terminal': copy.deepcopy(terminal),
             'raw_b64': base64.b64encode(raw).decode('ascii'), 'raw_sha256': sha(raw)}
    need(set(value) == TOP and set(cli) == CLI and set(terminal) == TERMINAL, 'export_exact_fields')
    data = canon(value)
    need(len(data) <= MAX_EXPORT, 'export_byte_bound')
    return data


def make_invocation_receipt(claim, reservation, retained_config_bytes, retained_evidence_bytes):
    """Re-derive from retained bytes independently of exporter JSON claims."""
    verify_seal(claim)
    verify_seal(reservation)
    e = read_json(retained_evidence_bytes, MAX_EVIDENCE)
    need(e['claim_id'] == claim['claim_id'] and e['invocation_id'] == reservation['invocation_id'], 'receipt_identity')
    need(e['config_file_sha256'] == sha(retained_config_bytes), 'retained_config_evidence_mismatch')
    return sealed({'schema': 'external-model-invocation-v2', 'invocation_id': reservation['invocation_id'],
                   'claim_id': claim['claim_id'], 'claim_sha256': claim['sha256'],
                   'request_sha256': claim['request_sha256'], 'config_file_sha256': sha(retained_config_bytes),
                   'session_evidence_sha256': sha(retained_evidence_bytes), **session_semantics(retained_evidence_bytes)})


def verify_export(artifact, independent_artifact_hash, claim, reservation, freeze,
                  invocation_receipt, retained_config_bytes, retained_evidence_bytes):
    need(sha(artifact) == independent_artifact_hash, 'independent_artifact_hash')
    value = read_json(artifact)
    need(set(value) == TOP and value['schema'] == 'bounded-official-cli-export-v2', 'v2_only_exact_fields')
    verify_seal(claim)
    verify_seal(reservation)
    verify_seal(freeze)
    verify_seal(invocation_receipt)
    need(invocation_receipt == make_invocation_receipt(claim, reservation, retained_config_bytes, retained_evidence_bytes), 'independent_receipt_semantics')
    for key in ('claim_id', 'slot_id', 'request_sha256'):
        need(value[key] == claim[key], 'claim_binding')
    need(value['invocation_id'] == reservation['invocation_id'], 'invocation_binding')
    need(value['configured_settings_sha256'] == digest(freeze['configuration']), 'configured_settings_hash')
    need(value['config_file_sha256'] == sha(retained_config_bytes) == freeze['config_file_sha256'], 'config_file_hash')
    cli, terminal = value['cli'], value['terminal']
    need(set(cli) == CLI and set(terminal) == TERMINAL, 'nested_exact_fields')
    need(cli['configured_settings'] == freeze['configuration'] and cli['settings_evidence'] == SETTINGS_EVIDENCE
         and cli['wire_parameters'] is None, 'configured_not_wire')
    for key, fk in (('binary_sha256', 'cli_binary_sha256'), ('exporter_source_sha256', 'exporter_source_sha256'),
                    ('version', 'cli_version'), ('mode', 'mode')):
        need(cli[key] == freeze[fk], 'cli_provenance')
    semantics = session_semantics(retained_evidence_bytes)
    need(cli['session_evidence_sha256'] == sha(retained_evidence_bytes), 'session_evidence_hash')
    need(all(cli[k] == semantics[k] for k in semantics), 'session_semantic_binding')
    need(cli['resume_requested'] is False and len(cli['observed_session_ids']) <= 1, 'session_integrity_failure')
    need(terminal['status'] in ('ok', 'timeout', 'transport_failure', 'cli_failure', 'cancelled'), 'terminal_status')
    need(terminal['process_terminal'] is True and type(terminal['capture_complete']) is bool, 'terminal_type')
    need(type(terminal['tool_calls']) is list and len(terminal['tool_calls']) <= 1, 'tool_bound')
    need(terminal['physical_http_attempts'] is None, 'unobserved_http_attempts')
    need(terminal['exit_code'] is None or type(terminal['exit_code']) is int, 'exit_type')
    need(set(terminal['usage']) == USAGE, 'usage_fields')
    for key, v in terminal['usage'].items():
        need(v is None or type(v) in (int, float) and math.isfinite(v) and v >= 0, 'usage_value')
        if key != 'wall_seconds':
            need(v is None or type(v) is int, 'token_type')
    if terminal['status'] == 'ok':
        need(terminal['exit_code'] == 0 and terminal['capture_complete'] is True, 'success_capture')
        need(cli['new_session_observed'] is True and len(cli['observed_session_ids']) == 1, 'successful_new_session_evidence')
        need(not terminal['tool_calls'] and terminal['finish_reason'] in ('stop', 'length'), 'success_finish_or_tools')
    encoded = value['raw_b64']
    need(type(encoded) is str and encoded.isascii() and len(encoded) <= 4 * ((MAX_RAW + 2) // 3), 'raw_b64_bound')
    raw = base64.b64decode(encoded, validate=True)
    need(len(raw) <= MAX_RAW and base64.b64encode(raw).decode('ascii') == encoded and sha(raw) == value['raw_sha256'], 'raw_hash_or_encoding')
    raw.decode('utf-8', errors='strict')
    return value


def initial_index(run_id, freeze_sha256, arms, mode, predecessor=None):
    need(identifier(run_id) and is_hash(freeze_sha256) and len(arms) == 2 and len(set(arms)) == 2, 'index_namespace')
    return sealed({'schema': 'eoh-cli-index-ledger-v2', 'mode': mode, 'run_id': run_id,
                   'freeze_sha256': freeze_sha256, 'arms': arms, 'caps': [12, 60, 60],
                   'rows': [], 'archives': {}, 'predecessor': predecessor})


def verify_index(index):
    verify_seal(index)
    need(index['schema'] == 'eoh-cli-index-ledger-v2' and index['caps'] == [12, 60, 60], 'index_schema')
    need(len(canon(index)) <= MAX_INDEX and len(index['rows']) <= 132, 'index_bound')
    claims, slots, invocations, sessions = set(), set(), set(), set()
    need(sum(r['state'] == 'claimed' for r in index['rows']) <= 1, 'multiple_unresolved_claims')
    for row in index['rows']:
        c, inv = row['claim'], row['reservation']
        verify_seal(c)
        verify_seal(inv)
        need(c['claim_id'] not in claims and c['slot_id'] not in slots and inv['invocation_id'] not in invocations, 'duplicate_claim_slot_invocation')
        claims.add(c['claim_id']); slots.add(c['slot_id']); invocations.add(inv['invocation_id'])
        need(c['run_id'] == index['run_id'] and c['freeze_sha256'] == index['freeze_sha256'], 'index_claim_namespace')
        need(inv['claim_id'] == c['claim_id'] and inv['claim_sha256'] == c['sha256'] and inv['request_sha256'] == c['request_sha256'], 'reservation_binding')
        need(row['phase'] == c['phase'] and row['phase'] in (0, 1, 2) and row['arm'] in index['arms'], 'phase_arm')
        need(row['state'] in ('claimed', 'terminal'), 'unknown_index_state')
        if row['state'] == 'terminal':
            need(type(row['terminal']) is dict, 'missing_terminal_ref')
            sid = row['terminal']['actual_session_id']
            if sid is not None:
                need(identifier(sid) and sid not in sessions, 'session_reused_across_slots')
                sessions.add(sid)
    for phase, cap in enumerate(PHASE_CAPS):
        need(sum(r['phase'] == phase for r in index['rows']) <= cap, 'wave_claim_cap')
    for arm in index['arms']:
        need(sum(r['arm'] == arm for r in index['rows']) <= 66, 'arm_claim_cap')


def claim_index(index, claim, arm, config_file_sha256):
    verify_index(index)
    need(not any(r['state'] == 'claimed' for r in index['rows']), 'unresolved_claim_stop_never_rerun')
    verify_seal(claim)
    need(is_hash(config_file_sha256), 'configuration_file_hash')
    inv = sealed({'schema': 'external-model-invocation-reservation-v2',
                  'invocation_id': digest(['invocation-v2', claim['run_id'], claim['claim_id']]),
                  'claim_id': claim['claim_id'], 'claim_sha256': claim['sha256'],
                  'request_sha256': claim['request_sha256'], 'config_file_sha256': config_file_sha256})
    body = copy.deepcopy(verify_seal(index))
    body['rows'].append({'claim': copy.deepcopy(claim), 'reservation': inv, 'phase': claim['phase'],
                         'arm': arm, 'state': 'claimed', 'terminal': None})
    updated = sealed(body)
    verify_index(updated)
    return updated, inv


def terminal_index(index, claim_id, terminal_ref, archive_receipt):
    verify_index(index)
    body = copy.deepcopy(verify_seal(index))
    row = next((r for r in body['rows'] if r['claim']['claim_id'] == claim_id), None)
    need(row is not None and row['state'] == 'claimed', 'terminal_requires_unique_open_claim')
    need(archive_receipt['write_result_confirmed'] is True and archive_receipt['remote_bytes_verified'] is False,
         'archive_write_not_confirmed_or_false_byte_claim')
    need(terminal_ref['archive_file_id'] == archive_receipt['file_id'] and terminal_ref['archive_version'] == archive_receipt['current_version_number'], 'terminal_archive_binding')
    row.update(state='terminal', terminal=copy.deepcopy(terminal_ref))
    body['archives'][str(row['phase'])] = copy.deepcopy(archive_receipt)
    updated = sealed(body)
    verify_index(updated)
    return updated


def atomic_write(path, data):
    import os
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name('.' + path.name + '.pending')
    need(not tmp.exists() and not path.is_symlink(), 'local_write_pending')
    with tmp.open('xb') as f:
        f.write(data); f.flush(); os.fsync(f.fileno())
    os.replace(tmp, path)
    fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)
