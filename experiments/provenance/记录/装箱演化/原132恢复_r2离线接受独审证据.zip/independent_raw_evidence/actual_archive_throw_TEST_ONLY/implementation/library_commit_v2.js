/* Assistant-only authenticated Library bridge. No private HTTP endpoints.
 * Every returned receipt distinguishes acknowledgment from remote byte proof.
 */
async function commitV2(root, localPath, libraryFileId, expectedVersion, isIndex) {
  const q=x=>"'"+String(x).replaceAll("'","'\\''")+"'";
  const check=(v,c)=>{if(!v)throw new Error(c)};
  function structured(r){let s=r?.structuredContent;if(!s)for(const c of r?.content??[])if(c.type==='text'){try{s=JSON.parse(c.text);break}catch{}}while(s?.structuredContent)s=s.structuredContent;return s}
  const fenceArgs=q(root)+' '+q(localPath)+' '+q(libraryFileId===null?'null':libraryFileId)+' '+q(String(expectedVersion))+' '+q(isIndex?'index':'archive');
  const fence=await tools.exec_command({cmd:'python3 -I '+q(root+'/src/external_commit_fence_v2.py')+' begin '+fenceArgs,login:false,max_output_tokens:100});
  check(fence.exit_code===0,'prior_or_uncertain_external_write_stop');
  const r=libraryFileId===null
    ? await tools.mcp__codex_apps__library_create_library_file({file:localPath,library_artifact_type:'other'})
    : await tools.mcp__codex_apps__library_replace_library_file({library_file_id:libraryFileId,file:localPath,
        expected_current_version:expectedVersion,version_reason:'V2 bounded journal/wave persistence; retain identity'});
  const item=structured(r);
  check(!r.isError && item?.status==='succeeded','external_commit_uncertain_stop');
  check(libraryFileId===null || item.library_file_id===libraryFileId,'external_identity_mismatch');
  check(Number.isInteger(item.current_version_number) && item.current_version_number>expectedVersion,'external_version_not_advanced');
  const attrs=await tools.exec_command({cmd:'python3 '+q(root+'/.library-helpers-current/library_file_transfer.py')+
    ' apply-xattrs '+q(localPath)+' '+q(item.library_file_id)+" <<'LIBRARY_XATTRS_JSON'\n"+JSON.stringify(item.xattrs??[])+"\nLIBRARY_XATTRS_JSON",
    login:false,max_output_tokens:200});
  check(attrs.exit_code===0,'local_library_identity_failed_stop');
  let readMessage=null;
  if(isIndex){
    const read=async()=>{const x=await tools.mcp__codex_apps__library_read({read:[{ref_id:item.file_id,mode:'full',max_lines:2}]});return structured(x)?.results?.[0]};
    let row=await read();
    if(row?.file_id!==item.file_id || row?.has_more!==false){
      await tools.mcp__codex_apps__library_search({search_query:[{q:JSON.stringify(item.file_name),search_title_only:true}],
        scope:{file_refs:[{file_id:item.file_id,library_file_id:item.library_file_id}],surfaces:['library']},
        surfaces:['library'],top_k:1,result_format:'metadata_only'});
      row=await read();
    }
    check(row?.file_id===item.file_id && row?.has_more===false,'index_readback_unavailable_stop');
    readMessage={file_id:row.file_id,library_file_id:row.library_file_id,content:row.content.join('\n'),has_more:row.has_more};
  }
  const payload={item:{status:item.status,library_file_id:item.library_file_id,file_id:item.file_id,
      current_version_number:item.current_version_number},readback:readMessage};
  const payloadPath=root+'/state/readback-'+item.library_file_id+'-'+item.current_version_number+'.json';
  const staged=await tools.apply_patch('*** Begin Patch\n*** Add File: '+payloadPath+'\n+'+JSON.stringify(payload)+'\n*** End Patch');
  check(!staged?.isError,'index_readback_staging_failed_stop');
  const validation=await tools.exec_command({cmd:'python3 -I '+q(root+'/src/commit_receipt_v2.py')+' '+q(localPath)+' '+
    q(String(expectedVersion))+' '+q(isIndex?'index':'archive')+' '+q(payloadPath),
    login:false,max_output_tokens:1000});
  check(validation.exit_code===0,'commit_or_index_hash_validation_failed_stop');
  const receipt={...JSON.parse(validation.output),file_name:item.file_name};
  const durable=await tools.exec_command({cmd:'python3 -I '+q(root+'/src/external_commit_fence_v2.py')+' confirm '+fenceArgs+
    " <<'CONFIRMED_RECEIPT_JSON'\n"+JSON.stringify(receipt)+"\nCONFIRMED_RECEIPT_JSON",login:false,max_output_tokens:100});
  check(durable.exit_code===0,'acknowledgment_retention_failed_stop');
  return receipt;
}
