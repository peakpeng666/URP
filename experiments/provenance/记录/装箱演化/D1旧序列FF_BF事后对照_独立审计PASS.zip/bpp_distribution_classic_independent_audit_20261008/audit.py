import json,csv,hashlib,pathlib,sys,time,resource,signal
from fractions import Fraction as Q
P=pathlib.Path('/workspace/shared/bpp_distribution_classic_baselines_20261008')
O=pathlib.Path(__file__).parent
resource.setrlimit(resource.RLIMIT_CPU,(10,10));signal.alarm(20)
def h(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def j(p):return json.loads(pathlib.Path(p).read_text())
def rows(p):return list(csv.DictReader(open(p)))
def snap():return {str(p):h(p) for p in P.rglob('*') if p.is_file()}
before=snap();original=j(P/'ORIGINAL_INPUT_HASHES.json')
assert all(h(p)==v for p,v in original.items())
freeze=j(P/'PREEXECUTION_FREEZE.json')['files'];assert all(h(P/p)==v for p,v in freeze.items())
seal=j(P/'evidence/data_seal.json');seals={(a['sequence_index'],a['method']):a for a in seal['packs']}
methods=j(P/'evidence/methods.json')['methods'];classic=j(P/'evidence/C1_baseline_definitions.json')
assert all(hashlib.sha256(v['code'].encode()).hexdigest()==v['code_sha256'] for v in methods.values())
assert all(hashlib.sha256(v['code'].encode()).hexdigest()==v['code_sha256'] for v in classic.values())
allrows=rows(P/'all60_sequence_results.csv');assert len(allrows)==60
lookup={(int(r['sequence_index']),r['method']):r for r in allrows};assert len(lookup)==60
oldrows=rows(P/'evidence/sequence_method_results.csv');assert len(oldrows)==36
oldlookup={(int(r['global_sequence_index']),r['method']):r for r in oldrows}
checked=[];computed={};counts={'FF':0,'BF':0};oldchecks=0
for i in range(12):
 data=j(P/f'inputs/{i:02}.json');xs=data['items'];assert data['capacity']==100 and len(xs)==1000 and all(type(x)==int and 0<x<=100 for x in xs)
 L=(sum(xs)+99)//100
 for method in ['FF','BF','EOH_original','EOH_nearfit_one','published_EoH']:
  row=lookup[i,method]
  if method in ['FF','BF']:
   f=P/f'trajectories/{i:02}_{method}.json';a=j(f);assignment=a['assignment'];assert len(assignment)==len(xs)
   assert a['input_file_sha256']==h(P/f'inputs/{i:02}.json') and a['implementation_sha256']==h(P/'run_once.py')
   assert a['c1_source_code_sha256']==classic[method]['code_sha256']
   assert a['input_sha256']==seals[i,'EOH_original']['input_sha256'] and a['capacity']==100
   loads=[]
   for step,(x,b) in enumerate(zip(xs,assignment)):
    feasible=[k for k,v in enumerate(loads) if v+x<=100]
    expected=(min(feasible) if method=='FF' else min(feasible,key=lambda k:(100-loads[k]-x,k))) if feasible else len(loads)
    assert b==expected,(i,method,step,b,expected)
    if b==len(loads):loads.append(0)
    prev=loads[b];loads[b]+=x
    assert a['events'][step]=={'bin':b,'item':x,'load_after':loads[b],'load_before':prev,'step':step}
   assert len(a['events'])==1000 and loads==a['final_integer_loads'] and a['used_bins']==len(loads) and a['L1']==L
   assert Q(a['F_numerator'],a['F_denominator'])==Q(L,len(loads))
   counts[method]+=len(xs)
  else:
   a=j(P/f'evidence/old_payloads/{i:02}_{method}.json');s=seals[i,method]
   assert a['code_sha256']==s['code_sha256']==methods[method]['code_sha256']
   assert a['input_sha256']==s['input_sha256'] and s['file_sha256']==h(P/f'inputs/{i:02}.json')
   assert a['method']==method and a['sequence_index']==i and a['capacity']==100 and a['n']==1000 and a['outcome']=='ok'
   assignment=a['original_pack_report']['result']['assignment'];assert len(assignment)==len(xs)
   loads=[]
   for x,b in zip(xs,assignment):
    assert type(b)==int and 0<=b<=len(loads)
    if b==len(loads):loads.append(0)
    loads[b]+=x;assert loads[b]<=100
   old=oldlookup[i,method]
   assert int(old['used_bins'])==len(loads) and int(old['L1'])==L and Q(int(old['F_numerator']),int(old['F_denominator']))==Q(L,len(loads))
   assert old['family']==row['family'] and old['family_sequence_index']==row['family_sequence_index']
   oldchecks+=1
  assert max(loads)<=100 and sum(loads)==sum(xs)
  assert int(row['used_bins'])==len(loads) and int(row['L1'])==L and Q(int(row['F_numerator']),int(row['F_denominator']))==Q(L,len(loads))
  computed[i,method]=(len(loads),Q(L,len(loads)))
  checked.append({'sequence':i,'method':method,'bins':len(loads),'F_exact':str(Q(L,len(loads)))})
assert len(list((P/'trajectories').glob('*.json')))==24
summaries=rows(P/'family_summary.csv');assert len(summaries)==15
for r in summaries:
 ids=sorted(int(a['sequence_index']) for a in allrows if a['family']==r['family'] and a['method']==r['method']);assert len(ids)==4
 vals=[computed[i,r['method']] for i in ids]
 assert r['bins_in_order']==','.join(str(a[0]) for a in vals)
 assert Q(r['mean_bins'])==sum(a[0] for a in vals)/Q(4) and Q(r['mean_F_exact'])==sum(a[1] for a in vals)/4
 assert abs(float(r['mean_F_decimal'])-float(sum(a[1] for a in vals)/4))<1e-15
contrasts=rows(P/'family_contrasts.csv');assert len(contrasts)==18
verified=[]
for r in contrasts:
 ids=sorted(int(a['sequence_index']) for a in allrows if a['family']==r['family'] and a['method']==r['method'])
 d=[computed[i,r['method']][0]-computed[i,r['baseline']][0] for i in ids];fs=[computed[i,r['method']][1]-computed[i,r['baseline']][1] for i in ids]
 assert r['delta_bins_method_minus_baseline']==','.join(map(str,d))
 wtl=[sum(x<0 for x in d),sum(x==0 for x in d),sum(x>0 for x in d)]
 assert r['wins_ties_losses_by_bins']=='/'.join(map(str,wtl)) and Q(r['mean_delta_bins'])==sum(d)/Q(4) and Q(r['mean_delta_F_exact'])==sum(fs)/4
 assert abs(float(r['mean_delta_F_decimal'])-float(sum(fs)/4))<1e-15
 verified.append({'family':r['family'],'method':r['method'],'baseline':r['baseline'],'delta_bins':d,'mean_delta_bins_exact':str(sum(d)/Q(4)),'wins_ties_losses':wtl,'mean_delta_F_exact':str(sum(fs)/4)})
after=snap();assert all(after.get(k)==v for k,v in before.items());assert all(h(p)==v for p,v in original.items())
result={'status':'PASS','scope':'Read-only independent assignment replay; no original candidate reruns, no LLM or solver; previously seen D1 inputs, not independent confirmation.','baseline_trajectories_checked':24,'items_checked_by_baseline':counts,'old_D1_payloads_reconstructed_without_candidate_execution':oldchecks,'source_and_input_hashes_unchanged':True,'audited_files_before':before,'original_inputs_sha256':original,'sequence_checks':checked,'family_contrasts':verified,'summary_rows_checked':15,'contrast_rows_checked':18}
(O/'AUDIT_RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['audited_files_before','original_inputs_sha256','sequence_checks','family_contrasts']},ensure_ascii=False))
