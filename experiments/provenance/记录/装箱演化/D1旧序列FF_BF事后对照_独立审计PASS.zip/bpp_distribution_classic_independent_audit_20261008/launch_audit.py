import os,time,json,pathlib,signal
p=pathlib.Path(__file__).parent;t=time.monotonic();pid=os.fork()
if pid==0:
 os.chdir(p);o=os.open('stdout.txt',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600);e=os.open('stderr.txt',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600);os.dup2(o,1);os.dup2(e,2);os.execlp('python','python',str(p/'audit.py'))
_,status,u=os.wait4(pid,0)
r={'exit_code':os.waitstatus_to_exitcode(status),'reaped':True,'wall_seconds':time.monotonic()-t,'user_cpu_seconds':u.ru_utime,'system_cpu_seconds':u.ru_stime,'cpu_total_seconds':u.ru_utime+u.ru_stime,'max_rss_kib':u.ru_maxrss,'cpu_hard_limit_seconds':10,'wall_alarm_seconds':20,'no_candidate_execution':True}
(p/'EXIT_RECEIPT.json').write_text(json.dumps(r,indent=2)+'\n');print(r)
