import pathlib,hashlib,json,tarfile,time,resource
P=pathlib.Path('/workspace/shared/bpp_distribution_classic_baselines_20261008');O=pathlib.Path(__file__).parent;A=P.with_suffix('.tar.gz');t=time.monotonic();c=time.process_time()
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
expected='a4d2bdfaa6b8e815eb06b098a14cf459168e1f9b5acdb25fa0b1155e59abec91'
assert h(A)==expected
m=json.loads((P/'DELIVERY_MANIFEST.json').read_text())['files'];assert all(h(P/k)==v for k,v in m.items())
audit=json.loads((O/'AUDIT_RESULT.json').read_text());assert all(h(pathlib.Path(k))==v for k,v in audit['audited_files_before'].items())
with tarfile.open(A) as tf:
 members=[m for m in tf.getmembers() if m.isfile()];assert len(members)==len(m)+1
 for f in members:
  rel=str(pathlib.PurePosixPath(f.name).relative_to(P.name));assert hashlib.sha256(tf.extractfile(f).read()).hexdigest()==h(P/rel)
r={'status':'PASS','author_archive':str(A),'author_archive_sha256':expected,'author_archive_bytes':A.stat().st_size,'delivery_manifest_sha256':h(P/'DELIVERY_MANIFEST.json'),'manifest_entries_verified':len(m),'tar_file_members_verified':len(members),'all_audited_bytes_equal_final_package':True,'binding_cpu_seconds':time.process_time()-c,'binding_wall_seconds':time.monotonic()-t}
(O/'FINAL_PACKAGE_BINDING.json').write_text(json.dumps(r,indent=2)+'\n');print(r)
