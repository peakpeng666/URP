"""Independent read-only terminal audit. Parses evidence; executes no supplied code."""
from pathlib import Path
import json,hashlib,math,re,shlex,collections,datetime
B=Path(__file__).resolve().parent;R=B/'received'
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
canon=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
mapping=read(R/'PATH_MAP.json')
def local(p):
    rel=Path(mapping[p]);assert not rel.is_absolute() and '..' not in rel.parts
    q=R/rel;assert q.is_file();return q
def refcheck(v):
    p=local(v['path']);assert sha(p)==v['file_sha256']
    if 'bytes' in v:assert p.stat().st_size==v['bytes']
    return p
manifest=read(R/'FILE_MANIFEST.json')['files']
assert len(manifest)==309
assert all((R/n).stat().st_size==v['bytes'] and sha(R/n)==v['sha256'] for n,v in manifest.items())
report=read(R/'EXECUTION_REPORT.json')
ap=refcheck(report['activation_ref']);g=read(ap)
proposal=B.parent/'candidate_1513/offline_proposal/INIT_ONLY_ACTIVATION.PROPOSED_NOT_EXECUTED.json'
assert ap.read_bytes()==proposal.read_bytes() and ap.stat().st_size==37461
assert sha(ap)=='59d96a0a5deb67de3272d9991bfd4a83fb1c56844901bb512b5d73d7d917eb6b'
oldgrant=read(refcheck(g['old_grant_ref']))
candidate=read(local(g['candidate_primary_path']))
assert {k for k in g if g[k]!=candidate[k]}=={'execution_granted','independent_review_accepted'}
assert g['execution_granted'] is g['independent_review_accepted'] is True
assert g['generation_execution_granted'] is g['numeric_execution_granted'] is False
assert g['model_requests']==g['candidate_executions']==g['new_index_create_count']==g['index_replace_count']==0
assert g['archive_create_max']==1 and g['pool']=={'SELF_checkpoint_seconds':60,'local_inclusive_wall_seconds':240,'new_budget':False}
assert g['old_grant_file_text'].encode()==local(g['old_grant_ref']['path']).read_bytes()
pin_checks={}
for group in ['new_source_pins','original_source_pins','original_implementation_pins','generation_original_pins']:
    for p,h in g[group].items():assert sha(local(p))==h;pin_checks[p]=h
assert len(g['new_source_pins'])==6
for n,pair in enumerate(g['old_five']):
    for kind in ['intent','receipt']:refcheck(pair[kind])
for field in ['stop_zip_ref','old_bridge_error_ref','historical_create_ref']:refcheck(g[field])
w=g['producer_workspace'];j=g['original_journal_root'];r=g['recovery_journal_root']
def at(root,name):return local(root+'/'+name)
oldsteps=['build']+[k+'.'+a for k in ['index','archive'] for a in ['begin','retain-start','retain-response','xattrs','receipt','confirm']]
original=[]
for n,step in enumerate(oldsteps):
    ip=at(j,f'helper-{n:02d}.intent.json');rp=at(j,f'helper-{n:02d}.receipt.json');i,v=read(ip),read(rp)
    assert i['step']==v['step']==step and v['outcome']=='confirmed'
    assert v['intent_file_sha256']==sha(ip) and v['init_grant_file_sha256']==g['old_grant_ref']['file_sha256']
    assert i['init_grant_file_sha256']==g['old_grant_ref']['file_sha256']
    assert sha(local(i['script_path']))==i['script_sha256']==v['script_sha256']
    original.append(v)
assembly=read(at(j,'assembly.receipt.json'))
assert assembly['outcome']=='confirmed' and assembly['intent_file_sha256']==sha(at(j,'assembly.intent.json'))
assert assembly['init_grant_file_sha256']==g['old_grant_ref']['file_sha256']
original.append(assembly)
bp=refcheck(report['base_handoff_ref']);base=read(bp)
hp=refcheck(report['v2_handoff_ref']);h=read(hp)
assert base['schema']=='phase2-namespace-init-resource-handoff-v1' and h['schema']=='phase2-namespace-init-reconciled-handoff-v2'
assert base['status']==h['status']=='CONFIRMED'
assert base['producer_workspace']==h['producer_workspace']==w
assert base['operational_run_id']==h['operational_run_id']==g['operational_run_id']
assert base['original_scientific_run_id']==g['scientific_run_id']
assert base['exact_original_source_pins']==g['original_source_pins']
assert len(base['measurements'])==14 and len(base['receipt_files'])==16
assert base['measurements']==[v['measurement'] for v in original]
expected_base={j+f'/helper-{n:02d}.receipt.json' for n in range(13)}|{j+'/assembly.receipt.json'}
for kind in ['index','archive']:
    receipt=base[kind+'_receipt'];assert receipt==h[kind+'_receipt']==report[kind+'_receipt']
    rp=w+'/state/commits/'+receipt['library_file_id']+'-'+str(receipt['current_version_number'])+'.json'
    assert read(local(rp))==receipt;expected_base.add(rp)
    blob=at(w,'index.initial.json' if kind=='index' else 'archive.initial.zip')
    assert sha(blob)==g[kind]['sha256']==receipt['local_blob_sha256']
    assert blob.stat().st_size==g[kind]['bytes']==receipt['local_blob_bytes']
    assert receipt['current_version_number']==0 and receipt['write_result_confirmed'] is True
    assert receipt['remote_bytes_verified'] is False and receipt['index_readback_confirmed']==(kind=='index')
assert {x['path'] for x in base['receipt_files']}==expected_base and len(expected_base)==16
assert h['index_receipt']['library_file_id']==g['index']['library_file_id']
assert h['index_receipt']['file_id']==g['index']['file_id']
ar=h['archive_receipt'];assert ar['library_file_id']=='libfile_0186168496ec8191a13d91cbc158d000'
assert ar['file_id']=='file_0000000092f8820cb55d553bffd3b828'
assert ar['library_file_id'] not in [g['index']['library_file_id'],*g['forbidden_prior_library_file_ids']]
activation_ref={'path':report['activation_ref']['path'],'file_sha256':sha(ap)}
assert h['reconciliation_grant_ref']==activation_ref
assert h['new_source_pins']==g['new_source_pins']
deltas=[]
for n in range(32):
    ip=at(r,f'delta-{n:04d}.intent.json');rp=at(r,f'delta-{n:04d}.receipt.json');i,v=read(ip),read(rp)
    assert v['outcome']=='confirmed' and v['intent_file_sha256']==sha(ip)
    assert i['reconciliation_grant_ref']==v['reconciliation_grant_ref']==activation_ref
    assert i['label']==v['label'];deltas.append(v)
assert h['recovery_receipt_files']==[{'path':r+f'/delta-{n:04d}.receipt.json','file_sha256':sha(at(r,f'delta-{n:04d}.receipt.json'))} for n in range(32)]
assert h['measurements']==base['measurements']+[d['measurement'] for d in deltas]
assert h['base_measurement_count']==14 and h['base_receipt_count']==16 and h['recovery_measurement_count']==32
refs=[h[k] for k in ['base_handoff_ref','reconciliation_grant_ref','old_grant_ref','old_stop_zip_ref','old_bridge_error_ref']]+h['new_authenticated_read_refs']+h['recovery_receipt_files']+base['receipt_files']
assert len(refs)==55
for v in refs:refcheck(v)
assert read(at(r,'entry.intent.json'))=={'reconciliation_grant_ref':activation_ref}
assert read(at(r,'finish.intent.json'))=={'base_handoff_ref':h['base_handoff_ref'],'reconciliation_grant_ref':activation_ref}
assert read(at(r,'finish.receipt.json'))=={'outcome':'confirmed','handoff_ref':{'path':report['v2_handoff_ref']['path'],'file_sha256':sha(hp)}}
stages=g['suffix_actions']
assert len(stages)==14
for n,stage in enumerate(stages):
    ip=at(r,f'effect-{n:02d}.intent.json');v=read(at(r,f'effect-{n:02d}.receipt.json'))
    assert read(ip)=={'stage':stage,'reconciliation_grant_ref':activation_ref}
    assert v=={'stage':stage,'outcome':'confirmed','intent_file_sha256':sha(ip)}
# Validate exact available journal file sets and terminal absent fences using snapshots plus archive.
local_r=at(r,'entry.intent.json').parent;local_j=at(j,'assembly.intent.json').parent
expected_delta={f'delta-{n:04d}.{kind}.json' for n in range(32) for kind in ['intent','receipt']}
assert {p.name for p in local_r.glob('delta-*.json')}==expected_delta
assert {p.name for p in local_j.glob('helper-*.json')}=={f'helper-{n:02d}.{kind}.json' for n in range(13) for kind in ['intent','receipt']}
for absent in [w+'/state/external-pending.json',w+'/phase2-generation-accounting',w+'/phase2-bridge-journal',r+'/HALTED.json']:
    assert not any(p==absent or p.startswith(absent+'/') for p in mapping)
# Independent measurement arithmetic, stable process identity and nonoverlap.
ms=h['measurements'];assert len(ms)==46;checkpoints={};windows=[]
for m in ms:
    assert m['measurement_status']=='known' and m['RUSAGE_kind']=='RUSAGE_SELF'
    assert m['native_wait_union_seconds']==0 and m['wall_semantics']=='local_stage_inclusive_no_wait_deduction'
    assert m['process']==m['start']['process']==m['end']['process'] and not m.get('TEST_ONLY')
    assert m['start']['self_cpu']==0
    for obj,key in [(m,'self_cpu_seconds'),(m,'wall_seconds'),(m,'local_inclusive_wall_seconds'),(m['start'],'monotonic'),(m['end'],'monotonic'),(m['end'],'self_cpu')]:
        assert type(obj[key]) in (int,float) and math.isfinite(obj[key]) and obj[key]>=0
    assert math.isclose(m['self_cpu_seconds'],m['end']['self_cpu'],abs_tol=1e-9)
    assert math.isclose(m['end']['monotonic']-m['start']['monotonic'],m['local_inclusive_wall_seconds'],abs_tol=1e-9)
    assert m['wall_seconds']==m['local_inclusive_wall_seconds']
    assert m['process'] not in checkpoints
    checkpoints[m['process']]=m['end']['self_cpu'];windows.append((m['start']['monotonic'],m['end']['monotonic']))
windows.sort();assert all(a[1]<=b[0] for a,b in zip(windows,windows[1:]))
cpu=sum(checkpoints.values());wall=sum(e-s for s,e in windows)
assert math.isclose(cpu,h['observed_init_final_self_cpu_seconds'],abs_tol=1e-9)
assert math.isclose(wall,h['observed_init_final_local_wall_seconds'],abs_tol=1e-9)
assert cpu<60 and wall<240
assert h['pool']==g['pool'] and h['CPU_cap_certification']=='NOT_ESTABLISHED' and h['complete_CPU_upper_bound_claimed'] is False
assert h['unknown']==g['unknown'] and h['new_post_checkpoint_CPU_tails'] is h['new_post_checkpoint_wall_tails'] is None
assert h['generation_execution_granted'] is h['numeric_execution_granted'] is False
assert h['model_calls']==h['candidate_executions']==0
# Check entire recorded actual call stream, not only producer's summary.
t=read(R/'COMPLETE_REAL_TOOL_TRANSCRIPT.json');calls=t['calls'];assert len(calls)==44
assert t['invocation']['entry']=='recoverSuffix' and t['invocation']['offlineFixture'] is False
assert t['terminal_result']==read(R/'BRIDGE_TERMINAL_RESULT.json')
assert t['terminal_result']['status']=='returned' and t['terminal_result']['result']==h
assert read(R/'BRIDGE_TERMINAL_RESULT.json')['result']==h
for name,digest in t['source_sha256'].items():assert sha(local(t['source_paths'][name]))==digest
counts=collections.Counter();parsed=[];delta_labels=[];native_exec_ids=set()
for n,c in enumerate(calls):
    assert c==read(R/f'raw_tool_returns/call-{n:03d}.json') and c['number']==n and c['outcome']=='returned'
    assert len(c['args'])==1 and c['started_UTC']<=c['completed_UTC']
    if n:assert calls[n-1]['completed_UTC']<=c['started_UTC']
    counts[c['tool']]+=1;a=c['args'][0]
    if c['tool']=='exec_command':
        assert c['result']['exit_code']==0 and not c['result'].get('session_id') and a['login'] is False
        assert c['result']['chunk_id'] not in native_exec_ids;native_exec_ids.add(c['result']['chunk_id'])
        lex=shlex.shlex(a['cmd'],posix=True);lex.whitespace_split=True;lex.commenters='';xs=[]
        for token in lex:
            if token.startswith('<<'):break
            xs.append(token)
        assert xs[0]=='python3' and '--offline-fixture' not in xs
        if g['recovery_cli_path'] in xs:
            assert xs[xs.index('--grant')+1]==activation_ref['path']
            assert xs[xs.index('--grant-sha256')+1]==activation_ref['file_sha256']
            action=xs[-1];body=json.loads(a['cmd'].split('\n',1)[1].rsplit('\n',1)[0])
            parsed.append(('cli',action,body))
            label=action if action=='enter' else 'v2.assemble' if action=='finish' else body['kind']+'.payload.write' if action=='payload' else action+':'+body['stage']
            delta_labels.append(label)
        elif '--step' in xs:
            step=xs[xs.index('--step')+1];assert step in oldsteps[5:]
            assert xs[xs.index('--grant')+1]==g['old_grant_ref']['path']
            assert xs[xs.index('--grant-sha256')+1]==g['old_grant_ref']['file_sha256']
            i=read(at(j,f'helper-{oldsteps.index(step):02d}.intent.json'))
            assert xs[xs.index('--script')+1]==i['script_path']
            if '--original-command' in xs:assert hashlib.sha256(xs[xs.index('--original-command')+1].encode()).hexdigest()==i['original_command_sha256']
            parsed.append(('helper',step,{}))
        else:
            assert g['original_implementation_root']+'/assemble_handoff.py' in xs
            assert xs[xs.index('--grant-sha256')+1]==g['old_grant_ref']['file_sha256'];parsed.append(('assembler','base.assemble',{}))
    else:
        assert c['result']['isError'] is False
        assert c['tool'] in ['mcp__codex_apps__library_read','mcp__codex_apps__library_create_library_file']
        parsed.append(('library','read' if c['tool'].endswith('_read') else 'create',{}))
assert counts=={'exec_command':41,'mcp__codex_apps__library_read':2,'mcp__codex_apps__library_create_library_file':1}
assert delta_labels==[d['label'] for d in deltas]
assert parsed[0]==('cli','enter',{}) and parsed[-1]==('cli','finish',{})
cursor=1;observations=[]
for number,stage in enumerate(stages):
    assert parsed[cursor]==('cli','before',{'stage':stage});assert json.loads(calls[cursor]['result']['output'])=={'number':number,'stage':stage}
    effect=cursor+1;after=cursor+2;value=calls[effect]['result']
    if stage.startswith('read.'):
        assert parsed[effect][:2]==('library','read')
        refid=g['index']['file_id'] if stage=='read.backing' else g['index']['library_file_id']
        assert calls[effect]['args'][0]=={'read':[{'ref_id':refid,'mode':'full','max_lines':2}]}
        assert read(at(r,stage+'.raw.json'))==value
        row=value['structuredContent']['results'][0];blob='\n'.join(row['content']).encode()
        assert row['file_id']==g['index']['file_id'] and row['library_file_id']==g['index']['library_file_id'] and row['has_more'] is False
        assert blob==at(w,'index.initial.json').read_bytes() and row['version_id'] is None
    elif stage=='archive.create':
        assert parsed[effect][:2]==('library','create')
        assert calls[effect]['args'][0]=={'file':w+'/archive.initial.zip','library_artifact_type':'other'}
        assert value==read(at(r,'archive-create.raw.json'))==read(at(w,'retained-library-replies/phase2-init-archive/response.json'))
        item=value['structuredContent'];assert all(item[k]==ar[k] for k in ['library_file_id','file_id','current_version_number'])
    elif stage.endswith('.payload'):
        assert parsed[effect]==('cli','payload',{'kind':stage.split('.')[0]});value=json.loads(value['output'])
        refcheck(value['payload_ref'])
    elif stage=='base.assemble':assert parsed[effect][:2]==('assembler',stage)
    else:assert parsed[effect][:2]==('helper',stage)
    assert parsed[after]==('cli','after',{'stage':stage,'observation':value})
    assert json.loads(calls[after]['result']['output'])=={'confirmed':stage}
    observations.append({'stage':stage,'actual_effect_call':effect,'before_call':cursor,'after_call':after})
    cursor+=3
assert cursor==43
assert json.loads(calls[-1]['result']['output'])==h
result={'verdict':'ACTUAL_INIT_TERMINAL_ACCEPTED_NO_GEN_ACTIVATION','package_manifest_members':309,'all55_handoff_refs_verified':True,
 'exact_activation_matches_parent_proposal':True,'old_five_bytes_unchanged':True,'source_pin_count':len(pin_checks),
 'actual_tool_counts':dict(counts),'all44_raw_calls_match_aggregate':True,'actual_call_order':observations,
 'only_one_recorded_entry_enter_and_archive_create':True,'helpers00_to04_not_reexecuted_in_suffix':True,
 'actual_base_measurements':14,'actual_base_receipt_refs':16,'actual_recovery_measurements':32,'actual_measurements':46,
 'unique_processes':len(checkpoints),'all_local_windows_nonoverlapping':True,'all_measured_costs_nonnegative_and_within_same_pool':True,
 'independent_observed_SELF_seconds':cpu,'independent_local_window_seconds':wall,'observed_remaining_SELF':60-cpu,'observed_remaining_local_wall':240-wall,
 'complete_budget_certified':False,'CPU_cap_certification':'NOT_ESTABLISHED','unknowns_preserved':True,
 'v2_handoff_ref':{'path':report['v2_handoff_ref']['path'],'file_sha256':sha(hp),'bytes':hp.stat().st_size},
 'base_handoff_ref':report['base_handoff_ref'],'activation_ref':report['activation_ref'],'index_receipt':h['index_receipt'],'archive_receipt':h['archive_receipt'],
 'new_source_pins':g['new_source_pins'],'generation_execution_granted':False,'numeric_execution_granted':False,'model_calls':0,'candidate_executions':0,
 'audit_did_not_execute_repository_recovery_or_GEN_code':True,'absent_terminal_paths_in_evidence':['external-pending.json','HALTED.json','phase2-generation-accounting','phase2-bridge-journal'],
 'scope_limit':'Verifies supplied actual producer transcript, exact copied records, source bytes and terminal snapshot. Does not claim all-OS/global exclusivity or complete CPU costs.'}
(B/'ACTUAL_TERMINAL_INDEPENDENT_VERIFICATION.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['actual_call_order','new_source_pins']},indent=2))
