"""Offline helper launch and durable Library-hook checks. No real source/helper/API."""
import contextlib
import io
import json
from pathlib import Path
import time
import unittest
from unittest.mock import patch

import durable_generation_sidecar as d
import library_stage_sidecar as lib
import measured_local_helper as helper
import test_durable_generation_sidecar as fixtures


class HelperAndLibraryTests(unittest.TestCase):
    def setUp(self):
        self.f = fixtures.DurableSidecarTests('test_disabled_grant_creates_no_directory')
        self.f.setUp();self.addCleanup(self.f.doCleanups)
        self.script=self.f.base/'TEST_ONLY_helper.py'
        self.script.write_text("import sys\nprint('TEST_ONLY:' + '|'.join(sys.argv[1:]))\n")
        self.f.grant['local_helper_source_files']={str(self.script):d.filehash(self.script)}
        self.f.grant['operational_source_files'][str(Path(helper.__file__).resolve())]=d.filehash(helper.__file__)
        self.f.grant['initializationFinalizationOps']={}
        self.f.pin_grant()
        self.sidecar=self.f.create()
        self.f.complete(self.sidecar,'init_final','initialization')
        self.slot=self.f.records[0]['slot_id'];self.sidecar.reserve_slot(self.f.records[0])
        self.f.complete(self.sidecar,self.slot,'reserve_next')
        self.f.complete(self.sidecar,self.slot,'prepare_reserved')
        self.token=self.sidecar.begin(self.slot,'claim_commit')
        self.payload=self.f.workspace/'TEST_ONLY_payload.json';self.payload.write_text('{}')
        d.publish_once(self.f.root/'entry-01-claim_commit-begin-control.json',d.sealed({
            'token_sha256':d.sha(d.canon(self.token)),'position':1,'stage':'claim_commit',
            'commit_arguments':[str(self.f.workspace),str(self.payload),'libfile_TEST_ONLY_index',1,True],
            'local_blob_sha256':d.filehash(self.payload)}))
        self.context={'scope':'slot','slot_id':self.slot,'stage':'claim','operation_id':'TEST_ONLY_claim',
                      'request_sha256':self.token['request_sha256'],'plan_sha256':self.f.binding['plan_sha256'],
                      'roster_sha256':self.f.binding['roster_sha256'],
                      'source_sha256':d.sha(d.canon(self.f.grant['operational_source_files'])),
                      'binding_sha256':d.sha(d.canon(self.f.binding))}

    def test_helper_preserves_argv_stdout_and_once_only_receipt(self):
        output=io.StringIO()
        with contextlib.redirect_stdout(output),patch.object(helper,'ENTRY_MONOTONIC',time.monotonic()):
            receipt=helper.run_helper(self.sidecar,'TEST_ONLY_claim:helper:1','a'*64,self.script,['one','two'])
        self.assertEqual(output.getvalue(),'TEST_ONLY:one|two\n')
        self.assertEqual(receipt['measurement_scope'],'SELF')
        self.assertEqual(receipt['outcome'],'confirmed')
        self.assertEqual(receipt['measurement']['native_wait_union_seconds'],0)
        with self.assertRaises(FileExistsError):
            helper.run_helper(self.sidecar,'TEST_ONLY_claim:helper:1','a'*64,self.script,['one','two'])

    def test_nonisolated_helper_restores_original_script_search_path(self):
        f=fixtures.DurableSidecarTests('test_disabled_grant_creates_no_directory')
        f.setUp();self.addCleanup(f.doCleanups)
        script=f.base/'TEST_ONLY_paths.py'
        script.write_text("import json,sys\nprint(json.dumps(sys.path))\n")
        f.grant['local_helper_source_files']={str(script):d.filehash(script)};f.pin_grant()
        sidecar=f.create();f.complete(sidecar,'init_final','initialization');sidecar.reserve_slot(f.records[0])
        slot=f.records[0]['slot_id'];f.complete(sidecar,slot,'reserve_next');f.complete(sidecar,slot,'prepare_reserved')
        sidecar.begin(slot,'claim_commit')
        captured=io.StringIO()
        with contextlib.redirect_stdout(captured),patch.object(helper,'ENTRY_MONOTONIC',time.monotonic()):
            helper.run_helper(sidecar,'TEST_ONLY_paths:helper:1','f'*64,script,[])
        expected=list(helper.ORIGINAL_INTERPRETER_PATH)
        if not __import__('sys').flags.isolated:expected[0:1]=[str(script.parent)]
        self.assertEqual(json.loads(captured.getvalue()),expected)

    def test_helper_unknown_retains_intent_and_blocks_repeat(self):
        self.script.write_text("raise RuntimeError('TEST_ONLY_failure')\n")
        self.f.grant['local_helper_source_files'][str(self.script)]=d.filehash(self.script)
        # Identity/grant pin must not be rewritten: drift is rejected before code.
        with self.assertRaises(d.Stop):
            helper.run_helper(self.sidecar,'TEST_ONLY_claim:helper:2','b'*64,self.script,[])

    def _intent(self,kind='write',number=1):
        args=d.canon([{'library_file_id':'libfile_TEST_ONLY_index','file':str(self.payload),'expected_current_version':1,
                      'version_reason':'V2 bounded journal/wave persistence; retain identity'}]).decode()
        return dict(self.context,schema='library-wait-intent-v1',method='mcp__codex_apps__library_replace_library_file',kind=kind,
                    observation_id=f'TEST_ONLY_claim:{kind}:{number}',clock_domain_id='TEST_ONLY_clock',
                    tool_arguments_sha256=d.sha(args.encode()),arguments_json=args,order=number,resources={})

    def test_library_intent_and_result_are_exclusive_and_bound(self):
        intent=self._intent()
        lib.persist_intent(self.sidecar,self.token,intent)
        with self.assertRaises(d.Stop):lib.persist_intent(self.sidecar,self.token,intent)
        result=d.canon({'TEST_ONLY_result':True}).decode()
        observation=dict(intent,schema='library-wait-observation-v1',await_start_ms=5,await_end_ms=15,elapsed_ms=10,
                         outcome='returned',write_outcome='acknowledged_not_remote_byte_proof',result_json=result,
                         result_sha256=d.sha(result.encode()),serialization_status='complete_json_object')
        lib.persist_observation(self.sidecar,self.token,observation)
        with self.assertRaises(FileExistsError):lib.persist_observation(self.sidecar,self.token,observation)
        self.assertIsNotNone(self.sidecar.status()['pending'])

    def test_library_changed_request_or_arguments_is_rejected(self):
        intent=self._intent()
        with self.assertRaises(d.Stop):lib.persist_intent(self.sidecar,self.token,dict(intent,request_sha256='c'*64))
        lib.persist_intent(self.sidecar,self.token,intent)
        with self.assertRaises(d.Stop):
            lib.persist_observation(self.sidecar,self.token,dict(intent,schema='library-wait-observation-v1',arguments_json='changed'))

    def test_missing_library_observation_never_closes_stage(self):
        lib.persist_intent(self.sidecar,self.token,self._intent())
        snapshot={'schema':'library-wait-meter-v1','status':'observed','interval_coverage_complete':True,
                  'unknown_reasons':[],'observations':[],'local_helpers':[]}
        with self.assertRaises(d.Stop):lib.close_stage(self.sidecar,self.token,snapshot,{})
        self.assertIsNotNone(self.sidecar.status()['pending'])

    def test_missing_actual_helper_receipt_cannot_be_verified(self):
        invocation=dict(self.context,invocation_id='TEST_ONLY_claim:helper:never',command_sha256='d'*64)
        envelope={'invocation_id':invocation['invocation_id'],'command_sha256':'d'*64,
                  'measurement_scope':'SELF','resource_receipt_sha256':'e'*64}
        with self.assertRaises(FileNotFoundError):lib.verify_helper(self.sidecar,self.token,invocation,envelope)


if __name__=='__main__':unittest.main(verbosity=2)
