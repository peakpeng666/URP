"""TEST_ONLY fixed entry + real durable sidecar integration.

The real production entry and durable accounting are exercised against a fully
synthetic, disposable 60-row package. Original producer modules are never
imported; trusted in-memory bridge/driver fakes supply deterministic results.
Library close uses explicitly TEST_ONLY fence evidence, while all entry begin
and close control receipts are passed to the real Sidecar.finish unchanged.
No model, native CLI, network, candidate, P1 result, or real Library call occurs.
"""

import copy
import importlib.util
from pathlib import Path
import types
import unittest
from unittest.mock import patch

import durable_generation_sidecar as d
import production_generation_entry as entry_module
import test_durable_generation_sidecar as fixtures


class ProductionEntryDurableIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.f = fixtures.DurableSidecarTests('test_disabled_grant_creates_no_directory')
        self.f.setUp()
        self.addCleanup(self.f.doCleanups)
        self.dispatches = []
        self.original_stage_calls = []
        self.library_closes = []
        self.capture_halt = False
        self.library_outcome = 'confirmed'

        # Pin the real fixed entry functions, while every scientific/producer
        # operation behind those functions remains a trusted TEST_ONLY fake.
        entry_path = Path(entry_module.__file__).resolve()
        entry_sha = d.filehash(entry_path)
        self.f.grant['operational_source_files'][str(entry_path)] = entry_sha
        self.f.grant['local_call_targets'] = {
            stage: {'path': str(entry_path), 'sha256': entry_sha, 'function': stage}
            for stage in d.LOCAL_STAGES
        }
        gate = d.read(self.f.gate_path)
        gate['storage'] = {'index_library_file_id': 'TEST_ONLY_index_library',
                           'archive_library_file_id': 'TEST_ONLY_archive_library'}
        self.f.write(self.f.gate_path, gate)
        self.f.grant['bridge_gate_file_sha256'] = d.filehash(self.f.gate_path)
        initial = self.f.workspace / 'TEST_ONLY_initial_index.json'
        receipt_path = self.f.workspace / 'TEST_ONLY_initial_receipt.json'
        self.f.write(initial, {'TEST_ONLY': True, 'rows': []})
        self.f.write(receipt_path, {'TEST_ONLY': True,
                                  'library_file_id': gate['storage']['index_library_file_id'],
                                  'current_version_number': 0})
        self.f.grant['entry_initial_head'] = {
            'index_path': str(initial), 'receipt_path': str(receipt_path),
            'index_file_sha256': d.filehash(initial),
            'receipt_file_sha256': d.filehash(receipt_path),
        }
        self.f.grant['entry_initial_archive_receipt'] = {
            'TEST_ONLY': True, 'library_file_id': gate['storage']['archive_library_file_id'],
            'current_version_number': 0,
        }
        from test_production_generation_entry import synthetic_bootstrap_handoff
        self.f.grant['namespace_initialization_handoff'] = synthetic_bootstrap_handoff(self.f.workspace,
            self.f.binding['run_id'], self.f.workspace, receipt_path, self.f.grant['entry_initial_archive_receipt'])
        self.f.pin_grant()
        self.sidecar = self.f.create()

        # Fixture setup has already loaded its own disposable mock module.
        # Refuse any subsequent importlib source load, including real producers.
        import_guard = patch.object(importlib.util, 'spec_from_file_location',
            side_effect=AssertionError('TEST_ONLY integration forbids producer/module loading'))
        import_guard.start()
        self.addCleanup(import_guard.stop)
        self.entry = self.make_entry(self.sidecar)
        self.entry.initialize()

    def make_entry(self, sidecar):
        entry = entry_module.ProductionEntry(sidecar)

        def reserve(root, plan, roster, index, receipt, storage, protocol, status, gate):
            record = sidecar.binding['records'][len(index['rows'])]
            self.original_stage_calls.append(('reserve_next', record['slot_id']))
            return {'TEST_ONLY': True, 'record': record}

        def prepare(**kwargs):
            slot = kwargs['claim']['slot_id']
            self.original_stage_calls.append(('prepare_reserved', slot))
            self.assertEqual(kwargs['pack'], {'TEST_ONLY': True, 'prompt': 'TEST_ONLY unchanged prompt'})
            self.assertEqual(kwargs['config'], b'TEST_ONLY unchanged config')
            return (dict(kwargs['index'], pending=slot),
                    {'TEST_ONLY': True, 'slot': slot}, {'TEST_ONLY': True})

        def collect(**kwargs):
            slot = kwargs['claim']['slot_id']
            self.original_stage_calls.append(('collect_reserved', slot))
            self.dispatches.append(slot)
            self.assertEqual(kwargs['config'], b'TEST_ONLY unchanged config')
            self.assertEqual(kwargs['pack']['prompt'], 'TEST_ONLY unchanged prompt')
            self.assertEqual(kwargs['producer_reservation']['slot'], slot)
            self.assertEqual(kwargs['fresh_claim_receipt']['library_file_id'], 'TEST_ONLY_index_library')
            return {'TEST_ONLY': True, 'slot_id': slot, 'phase2_halt_required': self.capture_halt}

        def archive(path, phase, prior_path, prior_sha256, additions):
            self.assertEqual(phase, 2)
            self.assertEqual(len(additions), 1)
            slot = next(iter(additions))
            self.original_stage_calls.append(('build_wave_archive', slot))
            self.assertEqual(additions[slot], b'TEST_ONLY opaque addition')
            if prior_path is not None:
                self.assertEqual(d.filehash(prior_path), prior_sha256)
            # This is an opaque synthetic payload, not a real candidate/archive.
            path.write_bytes(('TEST_ONLY opaque archive ' + slot).encode())
            return {'TEST_ONLY': True, 'local_blob_path': str(path),
                    'local_blob_sha256': d.filehash(path)}

        def finish_index(index, summary, receipt):
            slot = summary['slot_id']
            self.original_stage_calls.append(('finish_index', slot))
            self.assertEqual(receipt['library_file_id'], 'TEST_ONLY_archive_library')
            return {'TEST_ONLY': True, 'rows': index['rows'] + [{'state': 'terminal', 'slot': slot}]}

        def finish_position(root, reservation, plan, roster, index, *args):
            slot = reservation['record']['slot_id']
            self.original_stage_calls.append(('finish_position', slot))
            return {'TEST_ONLY': True, 'claim_id': slot, 'terminal_count': len(index['rows'])}

        bridge = types.SimpleNamespace(
            check_gate=lambda *args, **kwargs: None,
            inspect_head=lambda plan, roster, index, *args: index['rows'],
            reserve_next=reserve, prepare_reserved=prepare, collect_reserved=collect,
            finish_position=finish_position,
        )
        driver = types.SimpleNamespace(
            build_wave_archive=archive,
            slot_additions=lambda root, slot: {slot: b'TEST_ONLY opaque addition'},
            finish_index=finish_index,
        )

        def load_testonly_modules():
            # Preserve real source/grant validation on every mocked module load.
            sidecar._check_sources()
            entry.modules = {'bridge': bridge, 'driver': driver, 'protocol': object(),
                             'status': types.SimpleNamespace(inspect=lambda *args: {'TEST_ONLY': True})}
            entry.plan = d.read(self.f.package / 'PLAN.json')
            entry.roster = d.read(self.f.package / 'inputs/roster.json')
            entry.gate = d.read(self.f.gate_path)
            entry.storage = entry.gate['storage']

        entry._load = load_testonly_modules
        entry.inputs = lambda position: {
            'claim': {'TEST_ONLY': True, 'slot_id': entry.record(position)['slot_id']},
            'pack': {'TEST_ONLY': True, 'prompt': 'TEST_ONLY unchanged prompt'},
            'config': b'TEST_ONLY unchanged config', 'freeze': {'TEST_ONLY': True},
            'base': b'TEST_ONLY base', 'route': b'TEST_ONLY route',
        }
        return entry

    def reopen_entry(self):
        self.sidecar = self.f.reopen()
        self.entry = self.make_entry(self.sidecar)
        return self.entry

    def close_testonly_library(self, sidecar, token, snapshot, receipt, *, extra_local_receipts):
        """TEST_ONLY stand-in for already-verified Library/fence outcomes.

        This deliberately does not claim real Library route/fence verification.
        It exercises real durable accounting of the entry's two real local
        control receipts and one explicitly synthetic helper-process receipt.
        """
        self.assertTrue(snapshot['TEST_ONLY_verified_fence'])
        self.assertEqual(snapshot['token_sha256'], d.sha(d.canon(token)))
        self.assertEqual(len(extra_local_receipts), 2)
        self.assertTrue(all(r['process'] == d.PROCESS for r in extra_local_receipts))
        self.assertTrue(all(r['native_wait_union_seconds'] == 0 for r in extra_local_receipts))
        helper = self.f.receipt(token, cpu=0.01, wall=0.02)
        local_receipts = [*extra_local_receipts, helper]
        evidence = {'TEST_ONLY_verified_fence': True,
                    'existing_external_fence_confirmed': True,
                    'all_observed_local_helpers_have_SELF_receipts': True,
                    'library_observer_healthy': True,
                    'existing_receipt_sha256': d.sha(d.canon(receipt))}
        state = sidecar.finish(token, local_receipts=local_receipts, outcome=self.library_outcome,
            library_waits=[{'clock_domain_id': 'TEST_ONLY_unobservable_library_clock',
                            'elapsed_seconds': None, 'timing_status': 'unknown', 'outcome': 'confirmed'}],
            evidence=evidence)
        recorded = state['done'][-1]['result']['local_receipts']
        self.assertCountEqual(recorded, local_receipts)
        self.library_closes.append({'token': copy.deepcopy(token),
                                    'entry_receipts': copy.deepcopy(extra_local_receipts),
                                    'helper_receipt': copy.deepcopy(helper)})
        return state

    def commit(self, position, stage):
        job = self.entry.begin_library(position, stage)
        self.assertEqual(job['timing_mode'], 'unobservable')
        workspace, path, library_id, version, is_index = job['commit_arguments']
        self.assertEqual(workspace, str(self.f.workspace))
        self.assertTrue(Path(path).is_file())
        self.assertEqual(is_index, stage != 'archive_commit')
        receipt = {'TEST_ONLY': True, 'library_file_id': library_id,
                   'current_version_number': version + 1, 'local_blob_sha256': d.filehash(path)}
        snapshot = {'TEST_ONLY_verified_fence': True, 'token_sha256': d.sha(d.canon(job['token']))}
        with patch.object(entry_module.library, 'close_stage', side_effect=self.close_testonly_library):
            return self.entry.close_library(position, stage, snapshot, receipt)

    def position(self, position):
        for stage in d.STAGES:
            if stage in d.LIBRARY_STAGES:
                self.commit(position, stage)
            else:
                self.entry.local(position, stage)

    def assert_cpu_checkpoint_sum_once(self, state):
        prior_total = 0.0
        accumulated = 0.0
        for done in state['done']:
            result = done['result']
            checkpoint_total = sum(result['process_CPU_checkpoints'].values())
            self.assertAlmostEqual(result['self_cpu_seconds'], checkpoint_total - prior_total, places=7)
            accumulated += result['self_cpu_seconds']
            prior_total = checkpoint_total
        self.assertAlmostEqual(state['self_cpu_seconds'], accumulated, places=7)
        self.assertAlmostEqual(state['self_cpu_seconds'], sum(state['process_CPU_checkpoints'].values()), places=7)
        self.assertEqual(state['CPU_cap_certification'], 'NOT_ESTABLISHED')
        self.assertFalse(state['complete_local_process_CPU_upper_bound_claimed'])

    def prepare_first_claim(self):
        self.entry.local(1, 'reserve_next')
        self.entry.local(1, 'prepare_reserved')

    def test_entry_library_control_receipts_reach_real_durable_finish(self):
        self.prepare_first_claim()
        state = self.commit(1, 'claim_commit')
        self.assertFalse(state['halt'])
        self.assertEqual(len(self.library_closes), 1)
        result = state['done'][-1]['result']
        self.assertEqual(len(result['local_receipts']), 3)
        self.assertEqual(sum(r['process'] == d.PROCESS for r in result['local_receipts']), 2)
        for receipt in self.library_closes[0]['entry_receipts']:
            self.assertIn(receipt, result['local_receipts'])
        self.assertTrue(result['evidence']['TEST_ONLY_verified_fence'])
        self.assertIsNone(state['library_wait_seconds'])
        self.assert_cpu_checkpoint_sum_once(state)

    def test_pending_library_stage_survives_restart_and_forbids_retry_or_new_slot(self):
        self.prepare_first_claim()
        job = self.entry.begin_library(1, 'claim_commit')
        pending = copy.deepcopy(job['token'])
        files_before = {p.name: p.read_bytes() for p in self.f.root.glob('event-*.json')}
        entry = self.reopen_entry()
        self.assertEqual(self.sidecar.status()['pending'], pending)
        for operation in (lambda: entry.begin_library(1, 'claim_commit'),
                          lambda: entry.local(1, 'collect_reserved'),
                          lambda: entry.local(2, 'reserve_next')):
            with self.assertRaises(d.Stop):
                operation()
        self.assertEqual(files_before, {p.name: p.read_bytes() for p in self.f.root.glob('event-*.json')})
        self.assertEqual(self.dispatches, [])
        self.assertEqual(self.sidecar.status()['pending'], pending)

    def test_unknown_library_outcome_is_durable_and_blocks_capture_after_restart(self):
        self.prepare_first_claim()
        self.library_outcome = 'unknown'
        with self.assertRaises(d.Stop):
            self.commit(1, 'claim_commit')
        entry = self.reopen_entry()
        state = self.sidecar.status()
        self.assertIsNone(state['pending'])
        self.assertIn('unknown_stage_outcome_or_measurement', state['halt'])
        self.assertEqual(state['done'][-1]['result']['outcome'], 'unknown')
        self.assertEqual(len(state['done'][-1]['result']['local_receipts']), 3)
        for operation in (lambda: entry.begin_library(1, 'claim_commit'),
                          lambda: entry.local(1, 'collect_reserved'),
                          lambda: entry.local(2, 'reserve_next')):
            with self.assertRaises(d.Stop):
                operation()
        self.assertEqual(self.dispatches, [])
        self.assert_cpu_checkpoint_sum_once(state)

    def test_original_capture_halt_retains_result_once_and_blocks_later_stages(self):
        self.prepare_first_claim()
        self.commit(1, 'claim_commit')
        self.capture_halt = True
        with self.assertRaises(d.Stop):
            self.entry.local(1, 'collect_reserved')
        self.assertTrue(self.entry.saved(1, 'collect_reserved')['phase2_halt_required'])
        entry = self.reopen_entry()
        self.assertEqual(self.sidecar.status()['done'][-1]['result']['outcome'], 'unknown')
        for operation in (lambda: entry.local(1, 'collect_reserved'),
                          lambda: entry.local(1, 'build_wave_archive'),
                          lambda: entry.local(2, 'reserve_next')):
            with self.assertRaises(d.Stop):
                operation()
        self.assertEqual(self.dispatches, [self.f.records[0]['slot_id']])

    def test_z_full_sixty_slots_and_542_stages_with_no_double_counted_cpu(self):
        # Last test: this uses actual test-process SELF samples, so subsequent
        # fresh test journals must not re-admit this long-lived process startup.
        for position in range(1, 61):
            self.position(position)
        result = self.entry.finalize()
        state = self.f.reopen().status()
        self.assertTrue(result['no_further_generation'])
        self.assertEqual(result['logical_requests'], 60)
        self.assertEqual(len(state['reservations']), 60)
        self.assertEqual(len(state['done']), 542)
        self.assertEqual(sum(row['stage'] == 'finish_position' for row in state['done']), 60)
        self.assertEqual(self.dispatches, [row['slot_id'] for row in self.f.records])
        expected_calls = [(stage, row['slot_id']) for row in self.f.records
                          for stage in d.STAGES if stage in d.LOCAL_STAGES]
        self.assertEqual(self.original_stage_calls, expected_calls)
        self.assertEqual(len(self.original_stage_calls), 360)
        self.assertEqual(len(self.library_closes), 180)
        library_rows = [row for row in state['done'] if row['stage'] in d.LIBRARY_STAGES]
        self.assertEqual(sum(len(row['result']['local_receipts']) for row in library_rows), 540)
        self.assertEqual(sum(sum(r['process'] == d.PROCESS for r in row['result']['local_receipts'])
                             for row in library_rows), 360)
        self.assertAlmostEqual(state['process_CPU_checkpoints']['TEST_ONLY_receipt_process'], 1.8, places=10)
        self.assertFalse(state['halt'])
        self.assertIsNone(state['pending'])
        self.assertIsNone(state['library_wait_seconds'])
        self.assertEqual(state['generation_window_reserved_seconds'], 54000)
        self.assertEqual(sum(row['completion_tokens'] for row in state['reservations']), 1920000)
        self.assert_cpu_checkpoint_sum_once(state)
        for row in state['done']:
            if row['stage'] == 'finish_position':
                position = next(i + 1 for i, record in enumerate(self.f.records) if record['slot_id'] == row['scope'])
                original_ack = self.entry.saved(position, 'finish_position')['original_terminal_ack']
                self.assertEqual(row['result']['evidence']['existing_terminal_ack_sha256'], d.sha(d.canon(original_ack)))
        for position in (60, 61):
            with self.assertRaises(d.Stop):
                self.entry.local(position, 'reserve_next')
        self.assertEqual(len(self.dispatches), 60)
        with self.assertRaises(d.Stop):
            self.entry.finalize()


if __name__ == '__main__':
    unittest.main(verbosity=2)
