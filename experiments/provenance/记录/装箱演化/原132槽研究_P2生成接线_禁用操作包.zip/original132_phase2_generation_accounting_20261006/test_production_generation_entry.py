"""Trusted synthetic wiring, zero model/CLI/candidate/Library operations."""
import copy
import json
from pathlib import Path
import tempfile
import types
import unittest
from unittest.mock import patch
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
import durable_generation_sidecar as d
import production_generation_entry as e


def synthetic_bootstrap_handoff(root, run_id, workspace, receipt_path, archive_receipt):
    start={'process':'TEST_ONLY_namespace_bootstrap','pid':999999,'monotonic':1.0,'self_cpu':0.0}
    end=dict(start,monotonic=1.01,self_cpu=0.01)
    value={'schema':'phase2-namespace-init-resource-handoff-v1','status':'CONFIRMED',
        'TEST_ONLY':True,'producer_workspace':str(workspace),'operational_run_id':run_id,
        'index_receipt':d.read(receipt_path),'archive_receipt':archive_receipt,
        'model_calls':0,'candidate_executions':0,'measurements':[d.local_measurement(start,end)],
        'receipt_files':[{'path':str(receipt_path),'file_sha256':d.filehash(receipt_path)}]}
    path=root/'TEST_ONLY_bootstrap_handoff.json';path.write_bytes(d.canon(value))
    return {'path':str(path),'file_sha256':d.filehash(path)}


class MockSidecar:
    def __init__(self, root):
        self.root = root
        self.binding = {'package_path': str(root), 'run_id':'TEST_ONLY_run', 'records': [
            {'slot_id': f'slot_{n:02d}', 'request_sha256': str(n).zfill(64), 'order': 72+n}
            for n in range(1,61)]}
        self.grant = {'producer_workspace':str(root),'entry_initial_archive_receipt':
                      {'library_file_id':'libfile_archive','current_version_number':0}}
        self.pending=None;self.reserved=[];self.done=[];self.calls=[]
    def _check_sources(self): pass
    def reserve_slot(self, record):
        d.need(self.pending is None and len(self.reserved)<60, 'pending or sixty cap')
        d.need(record==self.binding['records'][len(self.reserved)],'order')
        if self.reserved:
            d.need(self.done[-1]['stage']=='finish_position','prior terminal missing')
        self.reserved.append(record)
    def begin(self, scope, stage):
        d.need(self.pending is None,'pending no replay')
        prior=[v['stage'] for v in self.done if v['scope']==scope]
        if scope=='init_final':
            expected='initialization' if not prior else 'finalization'
            if stage=='finalization':d.need(len(self.reserved)==60,'full60 required')
        else:
            expected=d.STAGES[len(prior)] if len(prior)<len(d.STAGES) else None
        d.need(stage==expected,'strict stage order')
        self.pending={'scope':scope,'stage':stage,'started':d.self_sample()};return self.pending
    def finish(self, token, **kw):
        d.need(self.pending==token,'wrong pending');self.done.append(token);self.pending=None
        return self.status()
    def status(self):return {'pending':self.pending,'done':self.done,'halt':[]}
    def invoke_local(self,scope,stage,fn,*args):
        token=self.begin(scope,stage);self.calls.append(stage)
        value=fn(*args);self.finish(token);return value


class WiringTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.s=MockSidecar(self.root);self.entry=e.ProductionEntry(self.s)
        self.dispatches=[];self.rows=[];self.halt=False
        initial=self.root/'initial.json';receipt_path=self.root/'receipt.json'
        self.write(initial,{'rows':[]});self.write(receipt_path,{'library_file_id':'libfile_index','current_version_number':0})
        self.s.grant['entry_initial_head']={'index_path':str(initial),'receipt_path':str(receipt_path),
            'index_file_sha256':d.filehash(initial),'receipt_file_sha256':d.filehash(receipt_path)}
        self.s.grant['namespace_initialization_handoff']=synthetic_bootstrap_handoff(self.root,
            self.s.binding['run_id'],self.root,receipt_path,self.s.grant['entry_initial_archive_receipt'])
        def reserve(root,plan,roster,index,receipt,storage,protocol,status,gate):
            return {'record':self.s.binding['records'][len(index['rows'])]}
        def prepare(**kw):
            return dict(kw['index'],pending=kw['claim']['slot_id']), {'slot':kw['claim']['slot_id']}, {'prompt':b'exact'}
        def collect(**kw):
            self.dispatches.append(kw['claim']['slot_id'])
            self.assertEqual(kw['config'],b'unchanged config')
            self.assertEqual(kw['pack']['prompt'],'unchanged prompt')
            self.assertEqual(kw['producer_reservation']['slot'],kw['claim']['slot_id'])
            return {'slot_id':kw['claim']['slot_id'],'phase2_halt_required':self.halt}
        def archive(path,phase,prior_path,prior_sha256,additions):
            self.assertEqual(phase,2);path.write_bytes(b'opaque mock ZIP')
            if prior_path:self.assertEqual(d.filehash(prior_path),prior_sha256)
            return {'local_blob_path':str(path),'local_blob_sha256':d.filehash(path)}
        bridge=types.SimpleNamespace(check_gate=lambda *a,**k:None,
            inspect_head=lambda plan,roster,index,*a:index['rows'],reserve_next=reserve,prepare_reserved=prepare,
            collect_reserved=collect,finish_position=lambda root,reservation,plan,roster,index,*a:
              {'claim_id':reservation['record']['slot_id'],'terminal_count':len(index['rows'])})
        driver=types.SimpleNamespace(build_wave_archive=archive,slot_additions=lambda root,slot:{slot:b'opaque'},
            finish_index=lambda index,summary,receipt:{'rows':index['rows']+[{'state':'terminal','slot':summary['slot_id']}]})
        def load():
            self.entry.modules={'bridge':bridge,'driver':driver,'protocol':object(),
                                'status':types.SimpleNamespace(inspect=lambda *a:{'actual':True})}
            self.entry.plan={};self.entry.roster={};self.entry.gate={}
            self.entry.storage={'index_library_file_id':'libfile_index','archive_library_file_id':'libfile_archive'}
        self.entry._load=load
        self.entry.inputs=lambda pos: {'claim':{'slot_id':self.entry.record(pos)['slot_id']},
          'pack':{'prompt':'unchanged prompt'},'config':b'unchanged config','freeze':{},'base':b'base','route':b'route'}
        self.entry.initialize()
    def tearDown(self):self.tmp.cleanup()
    def write(self,path,value):path.write_bytes(d.canon(value))
    def commit(self,pos,stage):
        job=self.entry.begin_library(pos,stage)
        self.assertEqual(job['timing_mode'],'unobservable')
        root,path,library_id,version,is_index=job['commit_arguments']
        self.assertTrue(Path(path).exists())
        self.assertEqual(is_index,stage!='archive_commit')
        receipt={'library_file_id':library_id,'current_version_number':version+1,'local_blob_sha256':d.filehash(path)}
        with patch.object(e.library,'close_stage',side_effect=lambda sidecar,token,snapshot,receipt,**kw:sidecar.finish(token)):
            self.entry.close_library(pos,stage,{'synthetic':True},receipt)
    def position(self,pos):
        for stage in d.STAGES:
            if stage in d.LIBRARY_STAGES:self.commit(pos,stage)
            else:self.entry.local(pos,stage)
    def test_full_sixty_fixed_flow_and_no_sixty_first(self):
        for pos in range(1,61):self.position(pos)
        result=self.entry.finalize()
        self.assertEqual(len(self.dispatches),60)
        self.assertEqual(self.dispatches,[r['slot_id'] for r in self.s.binding['records']])
        self.assertEqual(self.s.calls,list(e.LOCAL_FUNCTIONS)*60)
        self.assertEqual(len(self.s.done),542)
        self.assertTrue(result['no_further_generation'])
        with self.assertRaises(d.Stop):self.entry.local(61,'reserve_next')
        with self.assertRaises(d.Stop):self.entry.local(60,'reserve_next')
        self.assertEqual(len(self.dispatches),60)
    def test_missing_claim_commit_cannot_collect(self):
        self.entry.local(1,'reserve_next');self.entry.local(1,'prepare_reserved')
        with self.assertRaises(d.Stop):self.entry.local(1,'collect_reserved')
        self.assertEqual(self.dispatches,[])
    def test_pending_write_cannot_retry_or_dispatch(self):
        self.entry.local(1,'reserve_next');self.entry.local(1,'prepare_reserved')
        self.entry.begin_library(1,'claim_commit')
        with self.assertRaises(d.Stop):self.entry.begin_library(1,'claim_commit')
        with self.assertRaises(d.Stop):self.entry.local(1,'collect_reserved')
        self.assertEqual(self.dispatches,[])
    def test_original_capture_integrity_halt_preserves_once_only_result(self):
        self.entry.local(1,'reserve_next');self.entry.local(1,'prepare_reserved');self.commit(1,'claim_commit')
        self.halt=True
        with self.assertRaises(d.Stop):self.entry.local(1,'collect_reserved')
        self.assertTrue(self.entry.saved(1,'collect_reserved')['phase2_halt_required'])
        with self.assertRaises(d.Stop):self.entry.local(1,'collect_reserved')
        self.assertEqual(len(self.dispatches),1)
    def test_tampered_local_result_rejected(self):
        self.entry.local(1,'reserve_next')
        p=self.entry._path(1,'reserve_next');v=d.read(p);v['value']['record']['order']=999;self.write(p,v)
        with self.assertRaises(d.Stop):self.entry.local(1,'prepare_reserved')
        self.assertEqual(self.dispatches,[])
    def test_module_drift_refused_before_import(self):
        actual=e.ProductionEntry(self.s)
        bad=self.root/'bad.py';bad.write_text("raise AssertionError('MUST NOT IMPORT')\n")
        self.s.grant['entry_source_files']={k:str(bad) for k in ('protocol','capture','driver','bridge','status')}
        self.s.grant['operational_source_files']={str(bad):'0'*64}
        with self.assertRaisesRegex(d.Stop,'dependency drift'):actual._load()
    def test_finalization_before_sixty_rejected(self):
        with self.assertRaises(d.Stop):self.entry.finalize()
    def test_bootstrap_handoff_pin_or_namespace_change_rejected(self):
        ref=self.s.grant['namespace_initialization_handoff'];p=Path(ref['path'])
        index=self.entry.saved(0,'initialization')['receipt']
        value=d.read(p);value['archive_receipt']['library_file_id']='libfile_WRONG';self.write(p,value)
        with self.assertRaises(d.Stop):self.entry.bootstrap_receipts(index)
        ref['file_sha256']=d.filehash(p)
        with self.assertRaises(d.Stop):self.entry.bootstrap_receipts(index)
    def test_bootstrap_measurements_are_inherited_not_reset(self):
        index=self.entry.saved(0,'initialization')['receipt']
        measurements,pin=self.entry.bootstrap_receipts(index)
        self.assertEqual(len(measurements),1)
        self.assertEqual(measurements[0]['self_cpu_seconds'],0.01)
        self.assertEqual(pin,self.s.grant['namespace_initialization_handoff']['file_sha256'])


if __name__=='__main__':unittest.main()
