'use strict';
const assert=require('assert');
const fs=require('fs');
const path=require('path');
const {runPendingLibraryStage,sha256}=require('./production_library_commit.js');
const {createLibraryWaitObserver}=require('./library_wait_observer.js');
const {createMeasuredExecAdapter}=require('./measured_exec_adapter.js');
const base=path.resolve(__dirname,'..','original132_phase1_preparation_20261005');
const sources={commit:fs.readFileSync(path.join(base,'exporter/src/library_commit_v2.js'),'utf8'),
  retention:fs.readFileSync(path.join(base,'retention/retain_library_replies.js'),'utf8'),
  libraryMeter:fs.readFileSync(path.join(__dirname,'library_wait_observer.js'),'utf8'),
  execAdapter:fs.readFileSync(path.join(__dirname,'measured_exec_adapter.js'),'utf8'),
  hooksFactory:fs.readFileSync(path.join(__dirname,'production_library_hooks.js'),'utf8')};
const SUP='778f9e487fc3a9201c8dc0de061b6195f6e3e8045cd5e4dcd30464e1830c3193';
function fixture(){
  const root='/TEST_ONLY/work',trace=[],behavior={failVerify:false,entered:false};
  const result={status:'succeeded',library_file_id:'libfile_TEST_ONLY_index',file_id:'file_TEST_ONLY_current',current_version_number:2,file_name:'TEST_ONLY_index.json',xattrs:[]};
  const receipt={write_result_confirmed:true,index_readback_confirmed:true,library_file_id:result.library_file_id,
    file_id:result.file_id,current_version_number:2,local_blob_sha256:'a'.repeat(64),local_blob_bytes:2};
  const rawTools={
    exec_command(args){
      if(args.cmd.includes('library_hooks_cli.py')){
        const body=JSON.parse(args.cmd.split('\n').slice(1,-1).join('\n'));
        const action=args.cmd.match(/library_hooks_cli.py' '([^']+)'/)[1];trace.push(['hook',action]);
        let out=true;
        if(action==='enter'){if(behavior.entered)return Promise.resolve({exit_code:1,output:'already entered'});behavior.entered=true;}
        if(action==='before')trace.push(['before',body.intent.kind]);
        if(action==='after')trace.push(['after',body.observation.kind]);
        if(action==='get')out={invocation_id:body.invocation.invocation_id,command_sha256:body.invocation.command_sha256,measurement_scope:'SELF',resource_receipt_sha256:'9'.repeat(64),TEST_ONLY:true};
        if(action==='verify')out=!behavior.failVerify;
        if(action==='close'){trace.push(['close']);assert.strictEqual(body.snapshot.local_helper_self_receipts_complete,true);assert.strictEqual(body.snapshot.library_await_wall_ms,null);out={pending:null,halt:[],TEST_ONLY:true};}
        return Promise.resolve({exit_code:0,output:JSON.stringify(out)});
      }
      trace.push(['exec',args.cmd]);return Promise.resolve({exit_code:0,output:JSON.stringify(args.cmd.includes('commit_receipt_v2.py')?receipt:{TEST_ONLY_retained:true})});
    },
    apply_patch(args){trace.push(['patch',args]);return Promise.resolve({isError:false});},
    async mcp__codex_apps__library_replace_library_file(args){trace.push(['write',args]);return {structuredContent:result};},
    async mcp__codex_apps__library_read(args){trace.push(['read',args]);return {structuredContent:{results:[{file_id:result.file_id,library_file_id:result.library_file_id,has_more:false,content:['{}']}]}};},
    async mcp__codex_apps__library_search(){trace.push(['search']);throw new Error('unexpected fallback');}
  };
  const token={nonce:'TEST_ONLY_nonce',scope:'TEST_ONLY_slot_1',stage:'claim_commit',request_sha256:'b'.repeat(64),binding_sha256:'c'.repeat(64)};
  const pending={token,position:1,stage:'claim_commit',timing_mode:'unobservable',commit_arguments:[root,root+'/claim.json',result.library_file_id,1,true]};
  const context={scope:'slot',slotId:token.scope,stage:pending.stage,operationId:'TEST_ONLY_claim_1',
    request_sha256:token.request_sha256,binding_sha256:token.binding_sha256,plan_sha256:'d'.repeat(64),roster_sha256:'e'.repeat(64),source_sha256:'f'.repeat(64)};
  const hooks={
    async beforeOperation(_token,x){trace.push(['before',x.kind]);},
    async afterObservation(_token,x){trace.push(['after',x.kind]);},
    async getHelperReceipt(_token,x){trace.push(['helper_receipt',x.invocation_id]);return {invocation_id:x.invocation_id,command_sha256:x.command_sha256,measurement_scope:'SELF',resource_receipt_sha256:'9'.repeat(64),TEST_ONLY:true};},
    async verifyHelperReceipt(_token,x,r){return r.TEST_ONLY===true&&x.invocation_id===r.invocation_id;},
    async closeStage(_pending,s,r){trace.push(['close']);assert.strictEqual(s.timing_mode,'unobservable');assert.strictEqual(s.library_await_wall_ms,null);
      assert.strictEqual(s.local_helper_self_receipts_complete,true);assert.strictEqual(r.file_id,result.file_id);return {TEST_ONLY:true,pending:null,halt:[]};}
  };
  const files=[['python3 -I',root+'/src/external_commit_fence_v2.py'],['python3 -I',root+'/retain_tool_result.py'],
    ['python3',root+'/.library-helpers-current/library_file_transfer.py'],['python3 -I',root+'/src/commit_receipt_v2.py']];
  const options={rawTools,pending,context,hooks,sources,accountingSupplementSha256:SUP,grantSha256:'1'.repeat(64),
    slotIds:Array.from({length:60},(_,i)=>'TEST_ONLY_slot_'+(i+1)),createLibraryWaitObserver,createMeasuredExecAdapter,
    paths:{hooksCliPath:'/TEST_ONLY/library_hooks_cli.py',launcherPath:'/TEST_ONLY/meter.py',journalRoot:root+'/phase2-generation-accounting',grantPath:root+'/grant.json',
      retentionAuditDirectory:root+'/audit',retentionHelperPath:root+'/retain_tool_result.py',
      originalLaunchPrefixes:files.map(([python,scriptPath])=>({python,scriptPath}))}};
  return {options,trace,behavior};
}
(async()=>{
  assert.strictEqual(sha256('abc'),'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad');
  {const {options,trace}=fixture();const out=await runPendingLibraryStage(options);assert.strictEqual(out.sidecar_state.pending,null);
    assert.strictEqual(trace.filter(x=>x[0]==='write').length,1);assert.strictEqual(trace.filter(x=>x[0]==='read').length,1);
    assert.strictEqual(trace.filter(x=>x[0]==='exec').length,6);assert.strictEqual(trace.at(-1)[0],'close');
    const write=trace.findIndex(x=>x[0]==='write');assert.ok(trace.slice(0,write).some(x=>x[0]==='before'));assert.ok(trace.slice(write+1).some(x=>x[0]==='after'));
    assert.ok(trace.filter(x=>x[0]==='exec').every(x=>x[1].includes("'/TEST_ONLY/meter.py'")));}
  {const {options,trace}=fixture();await assert.rejects(()=>runPendingLibraryStage({...options,sources:{...sources,commit:sources.commit+' '}}),/source_drift/);assert.strictEqual(trace.length,0);}
  {const {options,trace}=fixture();await assert.rejects(()=>runPendingLibraryStage({...options,accountingSupplementSha256:'0'.repeat(64)}),/supplement/);assert.strictEqual(trace.length,0);}
  {const {options,trace}=fixture();const exact={TEST_ONLY_error:true};options.rawTools.mcp__codex_apps__library_replace_library_file=async()=>{trace.push(['write']);throw exact;};
    try{await runPendingLibraryStage(options);assert.fail();}catch(e){assert.strictEqual(e,exact);}assert.strictEqual(trace.filter(x=>x[0]==='write').length,1);assert.ok(!trace.some(x=>x[0]==='close'));}
  {const {options,trace,behavior}=fixture();behavior.failVerify=true;await assert.rejects(()=>runPendingLibraryStage(options));assert.ok(!trace.some(x=>x[0]==='close'));}
  {const {options,trace}=fixture();await runPendingLibraryStage(options);const originalCount=trace.filter(x=>x[0]==='exec'||x[0]==='write'||x[0]==='read').length;
    await assert.rejects(()=>runPendingLibraryStage(options),/hook_unknown_enter/);
    assert.strictEqual(trace.filter(x=>x[0]==='exec'||x[0]==='write'||x[0]==='read').length,originalCount);}
  console.log('7 production Library composition checks passed with unchanged hash-pinned V2 sources and fake tools; zero external calls');
})().catch(e=>{console.error(e);process.exitCode=1;});
