# Original 132 P2 generation coordination: disabled production preparation

Start with `PRODUCTION_ENTRY_GUIDE.md`. Accounting uses the separately approved inclusive/checkpoint supplement; no production path imports the diagnostic wait observer.

- Durable sidecar: 60 offline tests passed, including all 60 slots.
- Fixed Python entry: original bridge/driver order, separate Library begin/close.
- Executable JS composition: unchanged hash-pinned V2/retention sources and measured local helpers.
- `ACCOUNTING_SCOPE.json`: explicit CPU/window unknowns; no complete CPU-cap certification.
- `GENERATION_GRANT_TEMPLATE.json`: disabled; a separate parent GEN grant remains required.
- `READ_ONLY_INTERFACE_CHECK.json`: actual 177 package / 456 source / 60 roster compatibility, zero production execution.

All original scientific sources, policy/accounting and R2 files remain unchanged by this package. Final independent implementation acceptance and activation are separate.

The prohibited capture wait observer is `passive_wait_observer.py`. The production file `library_wait_observer.js` has a historical name: its production route records authenticated Library outcomes and explicitly unknown timing. It never subtracts capture waits.

Run each CPU-aware suite in a dedicated Python process, selecting its own TestCase. Combining repeated imported TestCases in one long-lived process changes SELF startup/checkpoint accounting and is not the dedicated-coordinator test contract.
