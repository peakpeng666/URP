"""TEST_ONLY durable sidecar checks, using disposable synthetic packages only.

No original producer, bridge, driver, capture, model, API, or P1 result is read
or invoked. Production policy constants are temporarily patched to hashes of
explicitly synthetic policy files, and restored after each test. The only
wrapper targets are functions in a freshly created TEST_ONLY mock module.
"""

import copy
import builtins
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import selectors
import socket
import stat
import subprocess
import tempfile
import time
import unittest
from unittest.mock import patch

import durable_generation_sidecar as g


HERE = Path(__file__).resolve().parent
MOCK_SOURCE = '''"""TEST_ONLY mock call targets. Never a production producer."""
import selectors
CALLS = []
def _call(stage, value, *args, **kwargs):
    CALLS.append((stage, value, args, kwargs.copy()))
    if kwargs.get("after_call") is not None:
        kwargs["after_call"]()
    if kwargs.get("failure") is not None:
        raise kwargs["failure"]
    return value
def reserve_next(value, *args, **kwargs):
    return _call("reserve_next", value, *args, **kwargs)
def prepare_reserved(value, *args, **kwargs):
    return _call("prepare_reserved", value, *args, **kwargs)
def collect_reserved(value, *args, **kwargs):
    selector = selectors.DefaultSelector()
    selector.select(timeout=0.002)
    return _call("collect_reserved", value, *args, **kwargs)
def build_wave_archive(value, *args, **kwargs):
    return _call("build_wave_archive", value, *args, **kwargs)
def finish_index(value, *args, **kwargs):
    return _call("finish_index", value, *args, **kwargs)
def finish_position(value, *args, **kwargs):
    return _call("finish_position", value, *args, **kwargs)
'''


class TestOnlySelector:
    """Local synthetic wait; production sidecar must never hook its method."""
    calls = []

    def select(self, *args, **kwargs):
        self.calls.append((args, kwargs.copy()))
        time.sleep(0.002)
        return []


class DurableSidecarTests(unittest.TestCase):
    def setUp(self):
        # Fence off process/network execution even if a mock unexpectedly drifts.
        for obj, name in ((socket, 'socket'), (subprocess, 'run'),
                          (subprocess.Popen, '__init__'), (os, 'system')):
            guard = patch.object(obj, name, side_effect=AssertionError('TEST_ONLY: live execution forbidden'))
            guard.start()
            self.addCleanup(guard.stop)
        self.tmp = tempfile.TemporaryDirectory(prefix='TEST_ONLY_durable_sidecar_')
        self.addCleanup(self.tmp.cleanup)
        self.synthetic_cpu = 0.0
        self.synthetic_wall = 1000.0
        self.base = Path(self.tmp.name).resolve()
        self.package = self.base / 'TEST_ONLY_package'
        (self.package / 'inputs').mkdir(parents=True)
        self.workspace = self.base / 'TEST_ONLY_workspace'
        self.workspace.mkdir()
        self.root = self.workspace / 'phase2-generation-accounting'
        self.policy_path = self.base / 'TEST_ONLY_POLICY.json'
        self.accounting_path = self.base / 'TEST_ONLY_ACCOUNTING.json'
        self.policy = {
            'TEST_ONLY': True,
            'generation_coordination': {
                'CPU_admission_budget_seconds': 1860,
                'per_slot_self_CPU_allowance_seconds': 30,
                'initial_final_self_CPU_allowance_seconds': 60,
                'active_bookkeeping_wall_budget_seconds': 7440,
                'per_slot_active_bookkeeping_wall_seconds': 120,
                'initial_final_active_wall_seconds': 240,
                'Library_IO_wait_budget_seconds': None,
                'per_slot_Library_IO_wait_decision_seconds': None,
            },
            'generation': {
                'logical_requests': 60, 'completion_tokens_per_request': 32000,
                'capture_window_per_request_seconds': 900,
                'summed_capture_window_seconds': 54000,
                'native_CLI_CPU_hard_limit': None,
                'native_CLI_CPU_in_trusted_coordination_cap': False,
                'outer_retries': 0, 'replacement_slots': 0,
            },
            'historical_shared_balance': None, 'reset_old_budget': False,
        }
        self.write(self.policy_path, self.policy)
        self.policy_sha = g.filehash(self.policy_path)
        self.accounting = {
            'TEST_ONLY': True,
            'input_binding_and_generation_bookkeeping_accounting': {
                'allowance_or_verified_balance_file_sha256': self.policy_sha,
            },
        }
        self.write(self.accounting_path, self.accounting)
        self.accounting_sha = g.filehash(self.accounting_path)
        self.supplement_path = self.base / 'TEST_ONLY_INCLUSIVE_SUPPLEMENT.json'
        self.write(self.supplement_path, {
            'TEST_ONLY': True, 'schema': 'phase2-inclusive-generation-accounting-supplement-v1',
            'mode': 'local_stage_inclusive_wall',
            'policy_file_sha256': self.policy_sha,
            'resource_accounting_binding_file_sha256': self.accounting_sha,
            'wait_deduction_seconds': 0, 'production_wait_observer_allowed': False,
            'pure_active_bookkeeping_wall_seconds': None,
            'pure_active_7440_compliance_independently_certified': False,
            'local_python_measurement': {
                'CPU_kind': 'RUSAGE_SELF', 'capture_wait_included': True,
                'CPU_cap_certification': 'NOT_ESTABLISHED',
                'complete_local_process_CPU_upper_bound_claimed': False,
                'arbitrary_fixed_tail_allowance_allowed': False,
                'per_slot_local_inclusive_wall_allowance_seconds': 1020,
                'initial_final_local_inclusive_wall_allowance_seconds': 240,
                'total_local_inclusive_wall_admission_budget_seconds': 61440,
                'per_slot_self_CPU_allowance_seconds': 30,
                'initial_final_self_CPU_allowance_seconds': 60,
                'total_self_CPU_admission_budget_seconds': 1860,
                'nonzero_wait_deduction': 'reject',
                'production_path_observer_import_or_call': 'forbidden',
                'wall_clock': 'time.monotonic',
            },
        })
        self.supplement_sha = g.filehash(self.supplement_path)
        for name, value in (('POLICY_SHA', self.policy_sha), ('ACCOUNTING_SHA', self.accounting_sha),
                            ('INCLUSIVE_SUPPLEMENT_SHA', self.supplement_sha)):
            guard = patch.object(g, name, value)
            guard.start()
            self.addCleanup(guard.stop)
        self.records = [
            {'order': order, 'slot_id': f'TEST_ONLY_slot_{order}',
             'request_sha256': g.sha(f'TEST_ONLY request {order}'.encode()),
             'prompt_sha256': g.sha(f'TEST_ONLY prompt {order}'.encode()),
             'config_sha256': g.sha(b'TEST_ONLY frozen config')}
            for order in range(73, 133)
        ]
        self.mock_path = self.package / 'TEST_ONLY_mock_producer.py'
        self.mock_path.write_text(MOCK_SOURCE)
        self.rebuild_package()
        spec = importlib.util.spec_from_file_location('TEST_ONLY_mock_producer', self.mock_path)
        self.mock = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.mock)
        self.gate_path = self.workspace / 'TEST_ONLY_GATE.json'
        self.rebuild_grant()

    @staticmethod
    def write(path, value):
        Path(path).write_bytes(g.canon(value))

    def rebuild_package(self):
        roster = g.sealed({'TEST_ONLY': True, 'phase': 2, 'count': len(self.records), 'records': self.records})
        plan = g.sealed({'TEST_ONLY': True, 'run_id': 'TEST_ONLY_run',
                         'resource_accounting_binding_sha256': self.accounting_sha,
                         'roster_sha256': roster['sha256']})
        self.write(self.package / 'inputs/roster.json', roster)
        self.write(self.package / 'PLAN.json', plan)
        files = {name: g.filehash(self.package / name)
                 for name in ('PLAN.json', 'inputs/roster.json', self.mock_path.name)}
        manifest = g.sealed({'TEST_ONLY': True, 'files': files})
        self.write(self.package / 'PACKAGE_MANIFEST.json', manifest)
        self.binding = g.inspect_contract(self.package, self.policy_path, self.accounting_path)

    def rebuild_grant(self):
        gate = {'TEST_ONLY': True, 'enabled': True, 'parent_review_accepted': True,
                'authorized_phase': 2, 'plan_sha256': self.binding['plan_sha256'],
                'roster_sha256': self.binding['roster_sha256'],
                'resource_accounting_binding_sha256': self.accounting_sha,
                'producer_workspace': str(self.workspace),
                'bridge_journal_root': str(self.workspace / 'phase2-bridge-journal')}
        self.write(self.gate_path, gate)
        self.grant = {
            'TEST_ONLY': True, 'schema': 'phase2-explicit-generation-sidecar-grant-v1',
            'generation_execution_granted': True, 'implementation_review_accepted': True,
            'binding_sha256': g.sha(g.canon(self.binding)),
            'inclusive_wall_supplement_path': str(self.supplement_path),
            'inclusive_wall_supplement_file_sha256': self.supplement_sha,
            'sidecar_root': str(self.root), 'producer_workspace': str(self.workspace),
            'authorized_slot_order': [r['slot_id'] for r in self.records],
            'authorized_request_sha256': [r['request_sha256'] for r in self.records],
            'bridge_gate_path': str(self.gate_path),
            'bridge_gate_file_sha256': g.filehash(self.gate_path),
            'operational_source_files': {str(self.mock_path): g.filehash(self.mock_path)},
            'local_call_targets': {
                stage: {'path': str(self.mock_path), 'sha256': g.filehash(self.mock_path), 'function': stage}
                for stage in g.LOCAL_STAGES
            },
        }
        # Hash the new accounting implementation only. These files are not
        # imported or executed as producer targets and no scientific source is read.
        self.grant['operational_source_files'].update({
            str(g.OPERATIONAL_ROOT / name): g.filehash(g.OPERATIONAL_ROOT / name)
            for name in g.REQUIRED_OPERATIONAL_FILES
        })
        self.pin_grant()

    def pin_grant(self):
        self.grant_sha = g.sha(g.canon(self.grant))

    def create(self):
        return g.Sidecar.create(self.binding, self.grant, self.grant_sha)

    def reopen(self):
        return g.Sidecar(self.root, self.binding, self.grant, self.grant_sha)

    def receipt(self, token, cpu=0.01, wall=0.02, wait=0.0):
        # All these resource deltas are fictional TEST_ONLY accounting fixtures.
        # A separately identified helper clock avoids pretending future samples
        # came from this running test process; its cumulative CPU starts at zero.
        start = {'process': 'TEST_ONLY_receipt_process', 'pid': 999999,
                 'self_cpu': self.synthetic_cpu, 'monotonic': self.synthetic_wall}
        self.synthetic_cpu += cpu
        self.synthetic_wall += wall
        end = dict(start, self_cpu=self.synthetic_cpu, monotonic=self.synthetic_wall)
        return g.local_measurement(start, end, wait)

    def complete(self, sidecar, scope, stage, *, cpu=0.01, wall=0.02, wait=0.0,
                 outcome='confirmed', local_receipts=None, library_waits=()):
        token = sidecar.begin(scope, stage)
        evidence = {'TEST_ONLY': True, 'existing_external_fence_confirmed': True,
                    'all_observed_local_helpers_have_SELF_receipts': True,
                    'library_observer_healthy': True,
                    'existing_terminal_ack_sha256': g.sha(b'TEST_ONLY terminal acknowledgement')}
        receipts = [self.receipt(token, cpu, wall, wait)] if local_receipts is None else local_receipts
        return sidecar.finish(token, local_receipts=receipts, library_waits=library_waits,
                              outcome=outcome, evidence=evidence)

    def first_slot(self):
        sidecar = self.create()
        self.complete(sidecar, 'init_final', 'initialization')
        sidecar.reserve_slot(self.records[0])
        return sidecar, self.records[0]['slot_id']

    def before_collect(self):
        sidecar, slot = self.first_slot()
        for stage in ('reserve_next', 'prepare_reserved', 'claim_commit'):
            self.complete(sidecar, slot, stage)
        return sidecar, slot

    def assert_blocked(self, sidecar, slot):
        before = list(self.root.glob('event-*.json'))
        with self.assertRaises(g.Stop):
            sidecar.begin(slot, 'prepare_reserved')
        with self.assertRaises(g.Stop):
            sidecar.reserve_slot(self.records[1])
        self.assertEqual(before, list(self.root.glob('event-*.json')))

    def test_inspection_is_disabled_read_only_and_fixed_sixty_rows(self):
        before = {str(p): p.read_bytes() for p in self.base.rglob('*') if p.is_file()}
        binding = g.inspect_contract(self.package, self.policy_path, self.accounting_path)
        after = {str(p): p.read_bytes() for p in self.base.rglob('*') if p.is_file()}
        self.assertEqual(before, after)
        self.assertFalse(binding['generation_execution_granted'])
        self.assertEqual([r['order'] for r in binding['records']], list(range(73, 133)))
        self.assertFalse(self.root.exists())

    def test_disabled_grant_creates_no_directory(self):
        for field in ('generation_execution_granted', 'implementation_review_accepted'):
            with self.subTest(field=field):
                grant = dict(self.grant, **{field: False})
                with self.assertRaises(g.Stop):
                    g.Sidecar.create(self.binding, grant, g.sha(g.canon(grant)))
                self.assertFalse(self.root.exists())

    def test_absent_grant_and_unpinned_grant_create_no_directory(self):
        for grant, pin in (({}, g.sha(g.canon({}))), (self.grant, '0' * 64)):
            with self.subTest(grant=bool(grant)):
                with self.assertRaises(g.Stop):
                    g.Sidecar.create(self.binding, grant, pin)
                self.assertFalse(self.root.exists())

    def test_no_reviewed_supplement_pin_creates_no_directory(self):
        with patch.object(g, 'INCLUSIVE_SUPPLEMENT_SHA', None):
            with self.assertRaises(g.Stop):
                self.create()
        self.assertFalse(self.root.exists())

    def test_supplement_grant_hash_and_file_bytes_must_match(self):
        grant = dict(self.grant, inclusive_wall_supplement_file_sha256='0' * 64)
        with self.assertRaises(g.Stop):
            g.Sidecar.create(self.binding, grant, g.sha(g.canon(grant)))
        self.assertFalse(self.root.exists())
        self.supplement_path.write_bytes(self.supplement_path.read_bytes() + b' ')
        with self.assertRaises(g.Stop):
            self.create()
        self.assertFalse(self.root.exists())

    def test_supplement_symlink_path_is_rejected(self):
        alias = self.base / 'TEST_ONLY_supplement_alias.json'
        alias.symlink_to(self.supplement_path)
        grant = dict(self.grant, inclusive_wall_supplement_path=str(alias))
        with self.assertRaises(g.Stop):
            g.Sidecar.create(self.binding, grant, g.sha(g.canon(grant)))
        self.assertFalse(self.root.exists())

    def test_supplement_drift_blocks_future_dispatch(self):
        sidecar, slot = self.first_slot()
        self.supplement_path.write_bytes(self.supplement_path.read_bytes() + b' ')
        with self.assertRaises(g.Stop):
            sidecar.begin(slot, 'reserve_next')
        self.assertFalse(self.mock.CALLS)

    def test_exact_supplement_semantics_are_required_even_with_matching_pin(self):
        original = g.read(self.supplement_path)
        fields = [(None, key) for key in original if key not in ('TEST_ONLY', 'local_python_measurement')]
        fields += [('local_python_measurement', key) for key in original['local_python_measurement']]
        for section, key in fields:
            with self.subTest(section=section, field=key):
                changed = copy.deepcopy(original)
                target = changed if section is None else changed[section]
                target[key] = 'TEST_ONLY_wrong_value'
                self.write(self.supplement_path, changed)
                pin = g.filehash(self.supplement_path)
                grant = dict(self.grant, inclusive_wall_supplement_file_sha256=pin)
                with patch.object(g, 'INCLUSIVE_SUPPLEMENT_SHA', pin):
                    with self.assertRaises(g.Stop):
                        g.Sidecar.create(self.binding, grant, g.sha(g.canon(grant)))
                self.assertFalse(self.root.exists())

    def test_no_external_source_plan_yields_empty_external_binding(self):
        self.assertEqual(self.binding['external_source_root'], str(self.base))
        self.assertEqual(self.binding['external_source_files'], {})

    def test_synthetic_external_source_dependency_is_bound_and_drift_blocks(self):
        external = self.base / 'TEST_ONLY_external_dependency.py'
        external.write_text('# TEST_ONLY synthetic dependency, never invoked\n')
        mapping = {external.name: g.filehash(external)}
        source_plan = g.sealed({'TEST_ONLY': True, 'source_and_input_files': mapping})
        self.write(self.package / 'SOURCE_INPUT_PLAN.json', source_plan)
        manifest = g.read(self.package / 'PACKAGE_MANIFEST.json')
        manifest['files']['SOURCE_INPUT_PLAN.json'] = g.filehash(self.package / 'SOURCE_INPUT_PLAN.json')
        manifest.pop('sha256')
        self.write(self.package / 'PACKAGE_MANIFEST.json', g.sealed(manifest))
        self.binding = g.inspect_contract(self.package, self.policy_path, self.accounting_path)
        self.assertEqual(self.binding['external_source_files'], mapping)
        self.rebuild_grant()
        sidecar, slot = self.first_slot()
        external.write_text('# TEST_ONLY changed dependency\n')
        with self.assertRaises(g.Stop):
            sidecar.begin(slot, 'reserve_next')
        with self.assertRaises(g.Stop):
            g.inspect_contract(self.package, self.policy_path, self.accounting_path)
        self.assertFalse(self.mock.CALLS)

    def test_exact_binding_and_ordered_grant_required(self):
        for field in ('binding_sha256', 'authorized_slot_order', 'authorized_request_sha256'):
            with self.subTest(field=field):
                grant = copy.deepcopy(self.grant)
                grant[field] = '0' * 64 if field == 'binding_sha256' else list(reversed(grant[field]))
                with self.assertRaises(g.Stop):
                    g.Sidecar.create(self.binding, grant, g.sha(g.canon(grant)))
                self.assertFalse(self.root.exists())

    def test_alternate_root_and_noncanonical_root_are_rejected(self):
        candidates = [str(self.workspace / 'alternate'),
                      str(self.workspace / 'x' / '..' / 'phase2-generation-accounting'),
                      'relative/phase2-generation-accounting']
        for candidate in candidates:
            with self.subTest(root=candidate):
                grant = dict(self.grant, sidecar_root=candidate)
                with self.assertRaises(g.Stop):
                    g.Sidecar.create(self.binding, grant, g.sha(g.canon(grant)))
                self.assertFalse(self.root.exists())

    def test_symlink_workspace_is_rejected(self):
        alias = self.base / 'TEST_ONLY_alias'
        alias.symlink_to(self.workspace, target_is_directory=True)
        grant = dict(self.grant, producer_workspace=str(alias),
                     sidecar_root=str(alias / 'phase2-generation-accounting'))
        with self.assertRaises(g.Stop):
            g.Sidecar.create(self.binding, grant, g.sha(g.canon(grant)))
        self.assertFalse(self.root.exists())

    def test_gate_hash_and_each_gate_binding_are_required(self):
        original = g.read(self.gate_path)
        for field in ('enabled', 'parent_review_accepted', 'authorized_phase', 'plan_sha256',
                      'roster_sha256', 'resource_accounting_binding_sha256',
                      'producer_workspace', 'bridge_journal_root'):
            with self.subTest(field=field):
                gate = dict(original)
                gate[field] = False if isinstance(gate[field], bool) else 'TEST_ONLY_wrong'
                self.write(self.gate_path, gate)
                grant = dict(self.grant, bridge_gate_file_sha256=g.filehash(self.gate_path))
                with self.assertRaises(g.Stop):
                    g.Sidecar.create(self.binding, grant, g.sha(g.canon(grant)))
                self.assertFalse(self.root.exists())
        self.write(self.gate_path, dict(original, TEST_ONLY_changed=True))
        with self.assertRaises(g.Stop):
            self.create()
        self.assertFalse(self.root.exists())

    def test_operational_source_drift_prevents_directory_creation(self):
        self.mock_path.write_text(MOCK_SOURCE + '\n# TEST_ONLY drift\n')
        with self.assertRaises(g.Stop):
            self.create()
        self.assertFalse(self.root.exists())

    def test_each_required_operational_source_pin_is_mandatory(self):
        for name in g.REQUIRED_OPERATIONAL_FILES:
            with self.subTest(source=name):
                grant = copy.deepcopy(self.grant)
                del grant['operational_source_files'][str(g.OPERATIONAL_ROOT / name)]
                with self.assertRaises(g.Stop):
                    g.Sidecar.create(self.binding, grant, g.sha(g.canon(grant)))
                self.assertFalse(self.root.exists())

    def test_policy_bytes_and_package_bytes_are_pinned(self):
        for path in (self.policy_path, self.accounting_path, self.mock_path):
            with self.subTest(path=path.name):
                original = path.read_bytes()
                path.write_bytes(original + b' ')
                with self.assertRaises(g.Stop):
                    g.inspect_contract(self.package, self.policy_path, self.accounting_path)
                path.write_bytes(original)

    def test_inspection_rejects_duplicate_slot_ids(self):
        self.records[1]['slot_id'] = self.records[0]['slot_id']
        with self.assertRaises(g.Stop):
            self.rebuild_package()

    def test_inspection_rejects_duplicate_request_hashes(self):
        self.records[1]['request_sha256'] = self.records[0]['request_sha256']
        with self.assertRaises(g.Stop):
            self.rebuild_package()

    def test_inspection_rejects_wrong_order(self):
        self.records[1]['order'] = self.records[0]['order']
        with self.assertRaises(g.Stop):
            self.rebuild_package()

    def test_creation_is_exclusive_private_and_fsynced(self):
        with patch.object(g.os, 'fsync', wraps=os.fsync) as sync:
            self.create()
        self.assertGreaterEqual(sync.call_count, 3)
        self.assertEqual(stat.S_IMODE(self.root.stat().st_mode), 0o700)
        self.assertTrue((self.root / 'identity.json').is_file())
        with self.assertRaises((FileExistsError, g.Stop)):
            self.create()

    def test_publish_once_fsyncs_file_and_directory_and_never_replaces(self):
        destination = self.base / 'TEST_ONLY_publish.json'
        synchronized = []
        real_sync = os.fsync
        def record(fd):
            synchronized.append('directory' if stat.S_ISDIR(os.fstat(fd).st_mode) else 'file')
            return real_sync(fd)
        with patch.object(g.os, 'fsync', side_effect=record):
            g.publish_once(destination, {'TEST_ONLY': 1})
        self.assertEqual(synchronized[0], 'file')
        self.assertIn('directory', synchronized[1:])
        with self.assertRaises(FileExistsError):
            g.publish_once(destination, {'TEST_ONLY': 2})
        self.assertEqual(g.read(destination), {'TEST_ONLY': 1})
        self.assertFalse(list(self.base.glob('.pending-*')))

    def test_stage_begin_and_end_are_durable_exclusive_events(self):
        sidecar = self.create()
        with patch.object(g.os, 'fsync', wraps=os.fsync) as sync:
            token = sidecar.begin('init_final', 'initialization')
        self.assertGreaterEqual(sync.call_count, 2)
        event = g.read(self.root / 'event-000001.json')
        self.assertEqual(event['payload'], token)
        with patch.object(g.os, 'fsync', wraps=os.fsync) as sync:
            sidecar.finish(token, local_receipts=[self.receipt(token)])
        self.assertGreaterEqual(sync.call_count, 2)
        with self.assertRaises(g.Stop):
            sidecar.finish(token, local_receipts=[self.receipt(token)])
        with self.assertRaises(g.Stop):
            sidecar.begin('init_final', 'initialization')
        self.assertEqual(len(list(self.root.glob('event-*.json'))), 2)

    def test_pending_stage_survives_fresh_module_and_forbids_retry_and_new_slot(self):
        sidecar, slot = self.first_slot()
        token = sidecar.begin(slot, 'reserve_next')
        # Reimport under a distinct module identity simulates coordinator state
        # loss without launching a process or invoking any real producer.
        spec = importlib.util.spec_from_file_location('TEST_ONLY_restarted_sidecar', g.__file__)
        restarted_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(restarted_module)
        restarted_module.POLICY_SHA = self.policy_sha
        restarted_module.ACCOUNTING_SHA = self.accounting_sha
        restarted_module.INCLUSIVE_SUPPLEMENT_SHA = self.supplement_sha
        fresh = restarted_module.Sidecar(self.root, self.binding, self.grant, self.grant_sha)
        self.assertEqual(fresh.status()['pending'], token)
        for operation in (lambda: fresh.begin(slot, 'reserve_next'),
                          lambda: fresh.begin(slot, 'prepare_reserved'),
                          lambda: fresh.reserve_slot(self.records[1])):
            with self.assertRaises(restarted_module.Stop):
                operation()
        self.assertEqual(fresh.status()['pending'], token)

    def test_wrong_slot_order_request_hash_and_duplicate_reservation_rejected(self):
        sidecar = self.create()
        self.complete(sidecar, 'init_final', 'initialization')
        wrong_hash = dict(self.records[0], request_sha256='0' * 64)
        for record in (self.records[1], wrong_hash):
            with self.assertRaises(g.Stop):
                sidecar.reserve_slot(record)
        sidecar.reserve_slot(self.records[0])
        with self.assertRaises(g.Stop):
            sidecar.reserve_slot(self.records[0])
        with self.assertRaises(g.Stop):
            sidecar.reserve_slot(self.records[1])

    def test_stages_cannot_be_skipped_or_repeated(self):
        sidecar, slot = self.first_slot()
        with self.assertRaises(g.Stop):
            sidecar.begin(slot, 'collect_reserved')
        self.complete(sidecar, slot, 'reserve_next')
        with self.assertRaises(g.Stop):
            sidecar.begin(slot, 'reserve_next')
        with self.assertRaises(g.Stop):
            sidecar.begin('init_final', 'finalization')

    def test_wrong_token_is_rejected_without_closing_pending_stage(self):
        sidecar, slot = self.first_slot()
        token = sidecar.begin(slot, 'reserve_next')
        with self.assertRaises(g.Stop):
            sidecar.finish(dict(token, nonce='TEST_ONLY_wrong'), local_receipts=[self.receipt(token)])
        self.assertEqual(sidecar.status()['pending'], token)

    def test_unknown_outcome_is_retained_and_blocks_after_reopen(self):
        sidecar, slot = self.first_slot()
        self.complete(sidecar, slot, 'reserve_next', outcome='unknown')
        fresh = self.reopen()
        self.assertIn('unknown_stage_outcome_or_measurement', fresh.status()['halt'])
        self.assertEqual(fresh.status()['done'][-1]['result']['outcome'], 'unknown')
        self.assert_blocked(fresh, slot)

    def test_missing_receipt_is_unknown_not_zero_acceptance(self):
        sidecar, slot = self.first_slot()
        self.complete(sidecar, slot, 'reserve_next', local_receipts=[])
        self.assertTrue(self.reopen().status()['halt'])
        self.assert_blocked(sidecar, slot)

    def test_tampered_receipt_and_duplicate_interval_fail_closed(self):
        sidecar, slot = self.first_slot()
        token = sidecar.begin(slot, 'reserve_next')
        receipt = self.receipt(token)
        changed = dict(receipt, self_cpu_seconds=0)
        state = sidecar.finish(token, local_receipts=[receipt, copy.deepcopy(receipt), changed])
        self.assertTrue(state['halt'])
        result = state['done'][-1]['result']
        self.assertGreaterEqual(result['self_cpu_seconds'], receipt['self_cpu_seconds'])
        self.assertAlmostEqual(result['process_CPU_checkpoints'][receipt['process']], receipt['end']['self_cpu'])
        self.assert_blocked(self.reopen(), slot)

    def test_cross_stage_repeated_local_receipt_is_rejected(self):
        sidecar, slot = self.first_slot()
        first = sidecar.begin(slot, 'reserve_next')
        receipt = self.receipt(first)
        sidecar.finish(first, local_receipts=[receipt])
        second = sidecar.begin(slot, 'prepare_reserved')
        try:
            state = sidecar.finish(second, local_receipts=[copy.deepcopy(receipt)])
        except g.Stop:
            self.assertEqual(sidecar.status()['pending'], second)
        else:
            self.assertTrue(state['halt'], 'an already-used local receipt must not confirm a later stage')
        fresh = self.reopen()
        with self.assertRaises(g.Stop):
            fresh.begin(slot, 'claim_commit')
        with self.assertRaises(g.Stop):
            fresh.reserve_slot(self.records[1])

    def test_cpu_overshoot_is_retained_without_clipping_and_blocks(self):
        sidecar, slot = self.first_slot()
        state = self.complete(sidecar, slot, 'reserve_next', cpu=30.5, wall=31)
        self.assertIn('CPU_inflight_overshoot_violation', state['halt'])
        self.assertGreaterEqual(state['scopes'][slot][0], 30.5)
        self.assert_blocked(self.reopen(), slot)

    def test_inclusive_wall_overshoot_is_retained_without_clipping_and_blocks(self):
        sidecar, slot = self.first_slot()
        state = self.complete(sidecar, slot, 'reserve_next', wall=1020.5)
        self.assertIn('local_inclusive_wall_inflight_overshoot_violation', state['halt'])
        self.assertGreaterEqual(state['scopes'][slot][1], 1020.5)
        self.assert_blocked(self.reopen(), slot)

    def test_scope_limit_plus_control_overhead_blocks_next_stage(self):
        sidecar, slot = self.first_slot()
        state = self.complete(sidecar, slot, 'reserve_next', cpu=30, wall=31)
        self.assertGreaterEqual(state['scopes'][slot][0], 30)
        with self.assertRaises(g.Stop):
            sidecar.begin(slot, 'prepare_reserved')

    def test_native_wait_cannot_hide_active_prepare_bookkeeping(self):
        sidecar, slot = self.first_slot()
        token = sidecar.begin(slot, 'reserve_next')
        receipt = self.receipt(token, wall=150)
        receipt['native_wait_union_seconds'] = 149
        receipt['local_inclusive_wall_seconds'] = 1
        try:
            state = sidecar.finish(token, local_receipts=[receipt])
        except g.Stop:
            self.assertEqual(sidecar.status()['pending'], token)
        else:
            self.assertTrue(state['halt'], 'non-collect native wait must fail closed')
        self.assert_blocked(self.reopen(), slot)

    def test_inclusive_sampler_rejects_any_nonzero_wait_deduction(self):
        start = {'process': 'TEST_ONLY', 'pid': 999999, 'self_cpu': 0, 'monotonic': 1000}
        end = dict(start, self_cpu=0.1, monotonic=1001)
        with self.assertRaises(g.Stop):
            g.local_measurement(start, end, 0.001)
        receipt = g.local_measurement(start, end, 0)
        self.assertEqual(receipt['local_inclusive_wall_seconds'], 1)
        self.assertEqual(receipt['wall_seconds'], 1)
        self.assertNotIn('active_wall_seconds', receipt)

    def test_inclusive_collect_receipt_cannot_subtract_generation_wait(self):
        sidecar, slot = self.before_collect()
        token = sidecar.begin(slot, 'collect_reserved')
        receipt = self.receipt(token, wall=900)
        receipt['native_wait_union_seconds'] = 899
        receipt['local_inclusive_wall_seconds'] = 1
        state = sidecar.finish(token, local_receipts=[receipt])
        self.assertTrue(state['halt'])
        self.assertEqual(state['done'][-1]['result']['outcome'], 'unknown')
        self.assert_blocked(self.reopen(), slot)

    def test_inclusive_collect_retains_full_nine_hundred_seconds(self):
        sidecar, slot = self.before_collect()
        state = self.complete(sidecar, slot, 'collect_reserved', wall=900)
        self.assertFalse(state['halt'])
        self.assertGreaterEqual(state['done'][-1]['result']['local_inclusive_wall_seconds'], 900)
        self.assertGreaterEqual(state['scopes'][slot][1], 900)
        self.assertLess(state['scopes'][slot][1], 1020)
        self.assertFalse(state['pure_active_7440_compliance_independently_certified'])
        self.assertIsNone(state['pure_active_bookkeeping_wall_seconds'])

    def test_library_wait_is_separate_unbounded_and_not_native_child_cpu(self):
        sidecar, slot = self.first_slot()
        for stage in ('reserve_next', 'prepare_reserved'):
            self.complete(sidecar, slot, stage)
        state = self.complete(sidecar, slot, 'claim_commit', library_waits=[
            {'clock_domain_id': 'TEST_ONLY_library_clock', 'elapsed_seconds': 10000,
             'outcome': 'confirmed'}])
        self.assertFalse(state['halt'])
        self.assertEqual(state['library_wait_seconds'], 10000)
        result = state['done'][-1]['result']
        self.assertIsNone(result['native_CLI_CPU'])
        self.assertIsNone(result['provider_CPU'])
        self.assertIsNone(result['historical_shared_balance'])
        self.assertTrue(result['no_kernel_aggregate_cap_claim'])

    def test_library_stage_requires_existing_fence_and_helper_evidence(self):
        sidecar, slot = self.first_slot()
        for stage in ('reserve_next', 'prepare_reserved'):
            self.complete(sidecar, slot, stage)
        token = sidecar.begin(slot, 'claim_commit')
        with self.assertRaises(g.Stop):
            sidecar.finish(token, local_receipts=[self.receipt(token)], evidence={})
        self.assertEqual(self.reopen().status()['pending'], token)

    def test_lock_contention_refuses_mutation(self):
        sidecar = self.create()
        with (self.root / 'lock').open('a+b') as handle:
            fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
            with self.assertRaises((BlockingIOError, g.Stop)):
                sidecar.begin('init_final', 'initialization')
        self.assertFalse(list(self.root.glob('event-*.json')))
        self.complete(sidecar, 'init_final', 'initialization')

    def test_leftover_pending_write_blocks_operations(self):
        sidecar = self.create()
        (self.root / '.pending-TEST_ONLY_crash').write_bytes(b'incomplete')
        with self.assertRaises(g.Stop):
            sidecar.begin('init_final', 'initialization')
        self.assertFalse(list(self.root.glob('event-*.json')))

    def test_directory_fsync_failure_after_begin_publication_does_not_allow_replay(self):
        sidecar, slot = self.first_slot()
        with patch.object(g, 'fsync_dir', side_effect=OSError('TEST_ONLY durability uncertainty')):
            with self.assertRaises(OSError):
                sidecar.begin(slot, 'reserve_next')
        fresh = self.reopen()
        self.assertEqual(fresh.status()['pending']['stage'], 'reserve_next')
        with self.assertRaises(g.Stop):
            fresh.begin(slot, 'reserve_next')
        self.assert_blocked(fresh, slot)

    def test_corrupted_event_seal_and_resealed_bad_chain_rejected(self):
        sidecar = self.create()
        sidecar.begin('init_final', 'initialization')
        path = self.root / 'event-000001.json'
        original = g.read(path)
        self.write(path, dict(original, kind='TEST_ONLY_corruption'))
        with self.assertRaises(g.Stop):
            sidecar.status()
        changed = {k: v for k, v in original.items() if k != 'sha256'}
        changed['previous_sha256'] = '0' * 64
        self.write(path, g.sealed(changed))
        with self.assertRaises(g.Stop):
            sidecar.status()

    def test_journal_sequence_gap_and_symlink_rejected(self):
        sidecar = self.create()
        sidecar.begin('init_final', 'initialization')
        path = self.root / 'event-000001.json'
        wrong = self.root / 'event-000002.json'
        path.rename(wrong)
        with self.assertRaises(g.Stop):
            sidecar.status()
        wrong.rename(path)
        outside = self.base / 'TEST_ONLY_event_copy.json'
        outside.write_bytes(path.read_bytes())
        path.unlink()
        path.symlink_to(outside)
        with self.assertRaises(g.Stop):
            sidecar.status()

    def test_identity_tampering_rejected_on_reopen(self):
        self.create()
        path = self.root / 'identity.json'
        self.write(path, dict(g.read(path), root='TEST_ONLY_other_root'))
        with self.assertRaises(g.Stop):
            self.reopen()

    def test_source_drift_blocks_next_stage_without_journal_change(self):
        sidecar, slot = self.first_slot()
        before = len(list(self.root.glob('event-*.json')))
        self.mock_path.write_text(MOCK_SOURCE + '\n# TEST_ONLY changed\n')
        with self.assertRaises(g.Stop):
            sidecar.begin(slot, 'reserve_next')
        self.assertEqual(len(list(self.root.glob('event-*.json'))), before)

    def test_policy_drift_blocks_next_stage(self):
        sidecar, slot = self.first_slot()
        self.policy_path.write_bytes(self.policy_path.read_bytes() + b' ')
        with self.assertRaises(g.Stop):
            sidecar.begin(slot, 'reserve_next')

    def test_local_wrapper_returns_identical_object_and_exact_arguments_once(self):
        sidecar, slot = self.first_slot()
        value, argument = object(), object()
        result = sidecar.invoke_local(slot, 'reserve_next', self.mock.reserve_next,
                                      value, argument, exact='TEST_ONLY unchanged')
        self.assertIs(result, value)
        self.assertEqual(self.mock.CALLS, [('reserve_next', value, (argument,), {'exact': 'TEST_ONLY unchanged'})])
        self.assertEqual(sidecar.status()['done'][-1]['stage'], 'reserve_next')
        with self.assertRaises(g.Stop):
            sidecar.invoke_local(slot, 'reserve_next', self.mock.reserve_next, value)
        self.assertEqual(len(self.mock.CALLS), 1)

    def test_local_wrapper_preserves_exact_exception_and_blocks_retry(self):
        sidecar, slot = self.first_slot()
        failure = RuntimeError('TEST_ONLY mock failure')
        with self.assertRaises(RuntimeError) as caught:
            sidecar.invoke_local(slot, 'reserve_next', self.mock.reserve_next, object(), failure=failure)
        self.assertIs(caught.exception, failure)
        self.assertEqual(len(self.mock.CALLS), 1)
        self.assertEqual(self.reopen().status()['done'][-1]['result']['outcome'], 'unknown')
        self.assert_blocked(sidecar, slot)

    def test_local_wrapper_preserves_baseexception_identity(self):
        sidecar, slot = self.first_slot()
        failure = KeyboardInterrupt('TEST_ONLY synthetic interruption')
        with self.assertRaises(KeyboardInterrupt) as caught:
            sidecar.invoke_local(slot, 'reserve_next', self.mock.reserve_next, object(), failure=failure)
        self.assertIs(caught.exception, failure)
        self.assertEqual(len(self.mock.CALLS), 1)
        self.assert_blocked(self.reopen(), slot)

    def test_local_wrapper_measurement_fault_never_replaces_original_exception(self):
        sidecar, slot = self.first_slot()
        failure = RuntimeError('TEST_ONLY original failure must survive')
        with patch.object(g, 'local_measurement', side_effect=ValueError('TEST_ONLY measurement failure')):
            with self.assertRaises(RuntimeError) as caught:
                sidecar.invoke_local(slot, 'reserve_next', self.mock.reserve_next, object(), failure=failure)
        self.assertIs(caught.exception, failure)
        self.assertEqual(len(self.mock.CALLS), 1)
        self.assert_blocked(self.reopen(), slot)

    def test_local_wrapper_end_sample_fault_never_replaces_original_exception(self):
        sidecar, slot = self.first_slot()
        failure = RuntimeError('TEST_ONLY original failure after sampling fault')
        sampler = patch.object(g, 'self_sample', side_effect=ValueError('TEST_ONLY sampling failed'))
        self.addCleanup(sampler.stop)
        with self.assertRaises(RuntimeError) as caught:
            sidecar.invoke_local(slot, 'reserve_next', self.mock.reserve_next, object(),
                                 failure=failure, after_call=sampler.start)
        self.assertIs(caught.exception, failure)
        sampler.stop()
        self.assertEqual(len(self.mock.CALLS), 1)
        self.assert_blocked(self.reopen(), slot)

    def test_local_wrapper_finish_failure_does_not_replay_or_replace_exception(self):
        sidecar, slot = self.first_slot()
        failure = RuntimeError('TEST_ONLY original failure')
        with patch.object(sidecar, 'finish', side_effect=OSError('TEST_ONLY disk failure')):
            with self.assertRaises(RuntimeError) as caught:
                sidecar.invoke_local(slot, 'reserve_next', self.mock.reserve_next, object(), failure=failure)
        self.assertIs(caught.exception, failure)
        self.assertEqual(self.reopen().status()['pending']['stage'], 'reserve_next')
        self.assertEqual(len(self.mock.CALLS), 1)
        self.assert_blocked(sidecar, slot)

    def test_wrong_callable_source_rejected_before_call_and_begin(self):
        sidecar, slot = self.first_slot()
        before = len(list(self.root.glob('event-*.json')))
        with self.assertRaises(g.Stop):
            sidecar.invoke_local(slot, 'reserve_next', lambda value: value, object())
        self.assertFalse(self.mock.CALLS)
        self.assertEqual(before, len(list(self.root.glob('event-*.json'))))

    def test_pinned_callable_outside_bound_package_is_rejected(self):
        outside_path = self.base / 'TEST_ONLY_external_mock.py'
        outside_path.write_text(MOCK_SOURCE)
        spec = importlib.util.spec_from_file_location('TEST_ONLY_external_mock', outside_path)
        outside_mock = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(outside_mock)
        self.grant['local_call_targets']['reserve_next'] = {
            'path': str(outside_path), 'sha256': g.filehash(outside_path), 'function': 'reserve_next'}
        self.grant['operational_source_files'][str(outside_path)] = g.filehash(outside_path)
        self.pin_grant()
        sidecar, slot = self.first_slot()
        before = len(list(self.root.glob('event-*.json')))
        with self.assertRaises(g.Stop):
            sidecar.invoke_local(slot, 'reserve_next', outside_mock.reserve_next, object())
        self.assertFalse(outside_mock.CALLS)
        self.assertEqual(before, len(list(self.root.glob('event-*.json'))))

    def test_collect_mock_selector_wait_is_fully_charged_and_returns_same_result(self):
        sidecar, slot = self.before_collect()
        TestOnlySelector.calls = []
        value = object()
        original_select = TestOnlySelector.select
        with patch.object(selectors, 'DefaultSelector', TestOnlySelector):
            result = sidecar.invoke_local(slot, 'collect_reserved', self.mock.collect_reserved,
                                          value, exact='TEST_ONLY argument')
        self.assertIs(result, value)
        self.assertIs(TestOnlySelector.select, original_select)
        self.assertEqual(TestOnlySelector.calls, [((), {'timeout': 0.002})])
        last = sidecar.status()['done'][-1]['result']
        self.assertFalse(last['evidence']['passive_wait_observer_imported_or_called'])
        self.assertNotIn('passive_observer_report', last['evidence'])
        receipt = last['local_receipts'][0]
        self.assertEqual(receipt['native_wait_union_seconds'], 0)
        self.assertEqual(receipt['wall_semantics'], 'local_stage_inclusive_no_wait_deduction')
        self.assertAlmostEqual(receipt['local_inclusive_wall_seconds'], receipt['wall_seconds'])
        self.assertGreaterEqual(receipt['wall_seconds'], 0.002)
        self.assertEqual(len(self.mock.CALLS), 1)

    def test_collect_exception_restores_hooks_and_is_not_retried(self):
        sidecar, slot = self.before_collect()
        failure = RuntimeError('TEST_ONLY collect failure')
        original_select = TestOnlySelector.select
        with patch.object(selectors, 'DefaultSelector', TestOnlySelector):
            with self.assertRaises(RuntimeError) as caught:
                sidecar.invoke_local(slot, 'collect_reserved', self.mock.collect_reserved,
                                     object(), failure=failure)
        self.assertIs(caught.exception, failure)
        self.assertIs(TestOnlySelector.select, original_select)
        self.assertEqual(len(self.mock.CALLS), 1)
        self.assert_blocked(self.reopen(), slot)

    def test_collect_does_not_import_passive_wait_observer(self):
        sidecar, slot = self.before_collect()
        value = object()
        original_import = builtins.__import__
        def guarded_import(name, *args, **kwargs):
            if 'passive_wait_observer' in name:
                raise AssertionError('TEST_ONLY: production must never import passive observer')
            return original_import(name, *args, **kwargs)
        with patch.object(builtins, '__import__', side_effect=guarded_import), \
             patch.object(selectors, 'DefaultSelector', TestOnlySelector):
            returned = sidecar.invoke_local(slot, 'collect_reserved', self.mock.collect_reserved, value)
        state = self.reopen().status()
        self.assertIs(returned, value)
        self.assertFalse(state['halt'])
        self.assertEqual(state['done'][-1]['result']['outcome'], 'confirmed')
        self.assertEqual(len(self.mock.CALLS), 1)

    def test_sixty_synthetic_slots_have_exact_reservations_and_finalization(self):
        sidecar = self.create()
        self.complete(sidecar, 'init_final', 'initialization')
        for record in self.records:
            reservation = sidecar.reserve_slot(record)
            self.assertEqual((reservation['logical_requests'], reservation['completion_tokens'],
                              reservation['generation_window_seconds']), (1, 32000, 900))
            for stage in g.STAGES:
                self.complete(sidecar, record['slot_id'], stage)
        self.complete(sidecar, 'init_final', 'finalization')
        state = self.reopen().status()
        self.assertFalse(state['halt'])
        self.assertIsNone(state['pending'])
        self.assertEqual(len(state['reservations']), 60)
        self.assertEqual(state['generation_window_reserved_seconds'], 54000)
        self.assertEqual(sum(r['completion_tokens'] for r in state['reservations']), 1920000)
        self.assertEqual(sum(r['self_CPU_reserved_seconds'] for r in state['reservations']) + 60, 1860)
        self.assertEqual(sum(r['local_inclusive_wall_reserved_seconds'] for r in state['reservations']) + 240, 61440)
        self.assertFalse(state['production_activation_in_this_package'])
        self.assertFalse(state['pure_active_7440_compliance_independently_certified'])
        self.assertIsNone(state['pure_active_bookkeeping_wall_seconds'])
        with self.assertRaises(g.Stop):
            sidecar.reserve_slot(self.records[0])
        with self.assertRaises(g.Stop):
            sidecar.begin('init_final', 'finalization')


if __name__ == '__main__':
    unittest.main(verbosity=2)
