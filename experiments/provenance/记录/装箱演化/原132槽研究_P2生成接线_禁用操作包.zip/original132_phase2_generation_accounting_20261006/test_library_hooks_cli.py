"""Fixed hook CLI functions against real durable sidecar + synthetic tool metadata."""
import contextlib
import io
import json
from pathlib import Path
import time
import unittest
from unittest.mock import patch

import durable_generation_sidecar as d
import library_hooks_cli as hooks
import library_stage_sidecar as lib
import measured_local_helper as helper
import test_durable_generation_sidecar as fixtures


class FixedHookTests(unittest.TestCase):
    def setUp(self):
        self.f=fixtures.DurableSidecarTests('test_disabled_grant_creates_no_directory')
        self.f.setUp();self.addCleanup(self.f.doCleanups)
        self.script=self.f.base/'TEST_ONLY_hook_helper.py';self.script.write_text("print('TEST_ONLY helper')\n")
        self.f.grant['local_helper_source_files']={str(self.script):d.filehash(self.script)}
        for p in (Path(hooks.__file__),Path(helper.__file__)):
            self.f.grant['operational_source_files'][str(p.resolve())]=d.filehash(p)
        self.audit=self.f.workspace/'audit'
        self.f.grant['retention_audit_directory']=str(self.audit)
        gate=d.read(self.f.gate_path);gate['storage']={'index_library_file_id':'libfile_TEST_ONLY_index','archive_library_file_id':'libfile_TEST_ONLY_archive'}
        self.f.write(self.f.gate_path,gate);self.f.grant['bridge_gate_file_sha256']=d.filehash(self.f.gate_path)
        self.f.pin_grant();self.grantfile=self.f.base/'TEST_ONLY_final_grant.json';self.f.write(self.grantfile,self.f.grant)
        self.sidecar=self.f.create();self.f.complete(self.sidecar,'init_final','initialization')
        self.record=self.f.records[0];self.sidecar.reserve_slot(self.record)
        self.f.complete(self.sidecar,self.record['slot_id'],'reserve_next');self.f.complete(self.sidecar,self.record['slot_id'],'prepare_reserved')
        self.token=self.sidecar.begin(self.record['slot_id'],'claim_commit');self.n=0
        self.payload=self.f.workspace/'TEST_ONLY_payload.json';self.payload.write_text('{}')
        d.publish_once(self.f.root/'entry-01-claim_commit-begin-control.json',d.sealed({
            'token_sha256':d.sha(d.canon(self.token)),'position':1,'stage':'claim_commit',
            'commit_arguments':[str(self.f.workspace),str(self.payload),'libfile_TEST_ONLY_index',1,True],
            'local_blob_sha256':d.filehash(self.payload)}))
        self.ctx={'scope':'slot','slot_id':self.token['scope'],'stage':'claim','operation_id':'TEST_ONLY_claim',
                  'request_sha256':self.token['request_sha256'],'plan_sha256':self.f.binding['plan_sha256'],
                  'roster_sha256':self.f.binding['roster_sha256'],'binding_sha256':self.token['binding_sha256'],
                  'source_sha256':d.sha(d.canon(self.f.grant['operational_source_files']))}
        self.pending={'token':self.token,'position':1,'stage':'claim_commit',
            'commit_arguments':[str(self.f.workspace),str(self.payload),'libfile_TEST_ONLY_index',1,True]}
        self.call('enter',pending=self.pending)

    def call(self,action,**kw):
        self.n+=1
        body={'journal_root':str(self.f.root),'grant_path':str(self.grantfile),'grant_sha256':self.f.grant_sha,
              'token':self.token,'hook_id':'TEST_ONLY_hook_'+str(self.n),**kw}
        # Model separate short-lived hook processes without spawning any real process.
        with patch.object(d,'PROCESS',f'TEST_ONLY_hook_process_{self.n}'),patch.object(hooks,'ENTRY_MONOTONIC',time.monotonic()):
            return hooks.invoke(action,body)

    def make_observation(self,kind,args,result,order):
        argjson=d.canon([args]).decode();resultjson=d.canon(result).decode()
        intent=dict(self.ctx,schema='library-wait-intent-v1',method='mcp__codex_apps__library_'+('replace_library_file' if kind=='write' else 'read'),
                    kind=kind,observation_id='TEST_ONLY_claim:'+kind+':1',clock_domain_id='unobservable',order=order,
                    tool_arguments_sha256=d.sha(argjson.encode()),arguments_json=argjson,resources={})
        obs=dict(intent,schema='library-wait-observation-v1',await_start_ms=None,await_end_ms=None,elapsed_ms=None,
                 timing_status='unknown',outcome='returned',write_outcome='acknowledged_not_remote_byte_proof' if kind=='write' else None,
                 serialization_status='complete_json_object',result_json=resultjson,result_sha256=d.sha(resultjson.encode()))
        self.call('before',intent=intent);self.call('after',observation=obs)
        return obs

    def full_metadata(self):
        payload=self.f.workspace/'TEST_ONLY_payload.json';payload.write_text('{}')
        args={'library_file_id':'libfile_TEST_ONLY_index','file':str(payload),'expected_current_version':1,'version_reason':'V2 bounded journal/wave persistence; retain identity'}
        item={'status':'succeeded','library_file_id':'libfile_TEST_ONLY_index','file_id':'file_TEST_ONLY_2','current_version_number':2}
        write=self.make_observation('write',args,{'structuredContent':item},1)
        read=self.make_observation('read',{'read':[{'ref_id':item['file_id'],'mode':'full','max_lines':2}]},{'structuredContent':{'results':[{'file_id':item['file_id'],'has_more':False,'content':['{}']}]}},2)
        opdir=self.audit/'TEST_ONLY_claim';opdir.mkdir(parents=True)
        self.f.write(opdir/'intent.json',{'operation_id':'TEST_ONLY_claim','method':write['method'],'arguments':args})
        self.f.write(opdir/'response.json',json.loads(write['result_json']))
        invocation=dict(self.ctx,invocation_id='TEST_ONLY_claim:helper:1',method='exec_command',command_sha256='a'*64)
        with patch.object(d,'PROCESS','TEST_ONLY_original_helper_process'),patch.object(helper,'ENTRY_MONOTONIC',time.monotonic()),contextlib.redirect_stdout(io.StringIO()):
            helper.run_helper(self.sidecar,invocation['invocation_id'],invocation['command_sha256'],self.script,[])
        envelope=self.call('get',invocation=invocation);self.assertTrue(self.call('verify',invocation=invocation,envelope=envelope))
        envelope_json=d.canon(envelope).decode()
        invocation.update(self_receipt_verified=True,self_receipt_json=envelope_json,self_receipt_sha256=d.sha(envelope_json.encode()))
        receipt={'library_file_id':item['library_file_id'],'file_id':item['file_id'],'current_version_number':2,
                 'write_result_confirmed':True,'index_readback_confirmed':True,'local_blob_sha256':d.filehash(payload)}
        commits=self.f.workspace/'state/commits';commits.mkdir(parents=True)
        self.f.write(commits/'libfile_TEST_ONLY_index-2.json',receipt)
        snapshot={'schema':'library-wait-meter-v1','status':'observed','timing_mode':'unobservable',
                  'accounting_supplement_sha256':self.f.supplement_sha,'interval_coverage_complete':False,
                  'unknown_reasons':[],'observations':[write,read],'local_helpers':[invocation]}
        return snapshot,receipt

    def test_fixed_hooks_include_every_process_and_do_not_double_count_inner_windows(self):
        snapshot,receipt=self.full_metadata()
        state=lib.close_stage(self.sidecar,self.token,snapshot,receipt)
        self.assertIsNone(state['pending']);self.assertFalse(state['halt']);self.assertIsNone(state['library_wait_seconds'])
        result=state['done'][-1]['result']
        self.assertEqual(len(result['local_receipts']),9) # six whole hooks + one original helper; inner controls excluded
        self.assertEqual(len(list(self.f.root.glob('hook-*.receipt.json'))),7)
        self.assertEqual(result['CPU_cap_certification'],'NOT_ESTABLISHED')

    def test_stale_actual_write_receipt_rejected_before_close(self):
        snapshot,receipt=self.full_metadata()
        with self.assertRaisesRegex(d.Stop,'stale/foreign'):
            lib.close_stage(self.sidecar,self.token,snapshot,dict(receipt,file_id='file_TEST_ONLY_stale'))
        self.assertIsNotNone(self.sidecar.status()['pending'])

    def test_changed_operation_id_cannot_issue_second_write_in_same_stage(self):
        args={'library_file_id':'libfile_TEST_ONLY_index','expected_current_version':1,'file':str(self.payload),
              'version_reason':'V2 bounded journal/wave persistence; retain identity'}
        result={'structuredContent':{'status':'succeeded','library_file_id':'libfile_TEST_ONLY_index','file_id':'file_TEST_ONLY','current_version_number':2}}
        observed=self.make_observation('write',args,result,1)
        attempted=dict(observed,schema='library-wait-intent-v1',operation_id='TEST_ONLY_new_alias',observation_id='TEST_ONLY_new_alias:write:1')
        with self.assertRaisesRegex(d.Stop,'alias'):
            self.call('before',intent=attempted)
        self.assertEqual(len(list(self.f.root.glob('library-*.intent.json'))),1)
        self.assertIsNotNone(self.sidecar.status()['pending'])

    def test_second_JS_run_lease_is_rejected_before_original_helpers(self):
        with self.assertRaises(FileExistsError):self.call('enter',pending=self.pending)
        self.assertEqual(len(list(self.f.root.glob('library-run-*.json'))),1)
        self.assertFalse(list(self.f.root.glob('helper-*.intent.json')))
        self.assertFalse(list(self.f.root.glob('library-*.intent.json')))

    def test_fixed_hook_missing_grant_does_not_run(self):
        with self.assertRaises((d.Stop,KeyError)):
            hooks.invoke('get',{'journal_root':str(self.f.root),'grant_path':str(self.grantfile),
                               'grant_sha256':'0'*64,'token':self.token,'hook_id':'bad'})


if __name__=='__main__':unittest.main(verbosity=2)
