# Minimal production entry, awaiting independent acceptance and GEN grant

## Bound accounting scope

- Local per-slot inclusive monotonic windows: 1,020 seconds; initial/final pool: 240; total: 61,440. Capture's original CLI wait stays inside the local window. Every nonzero wait deduction is rejected.
- Observed SELF CPU checkpoint sum: per-slot 30 seconds, initial/final pool 60, total stop threshold 1,860. This does not certify a complete-process CPU cap. Post-checkpoint write/fsync/exit CPU remains unknown local Python CPU; it is not reassigned to plugin/provider CPU.
- Pure active-bookkeeping component and independent 7,440-second compliance: unknown. Pre-window interpreter/import wall and final post-checkpoint wall are also not whole-process elapsed measurements.
- Library await duration is explicitly unknown in the actual JS environment without an authenticated monotonic clock. Date.now is never used as elapsed accounting or included in the 61,440 proof. Actual outcomes and original fences still must be known.
- Native CLI/provider/JS-plugin service CPU stay separately unknown. No new CPU cap, inherited RLIMIT, extra request, retry or replacement slot is introduced.
- Original 60 P2 positions, 900 seconds and 32,000 tokens per request, and 54,000 reserved generation-window seconds remain unchanged. Historical shared balance remains unknown.

The exact supplementary scope is pinned independently of the original frozen policy/accounting. It never grants execution.

## Files used in production

1. `durable_generation_sidecar.py`: inspect metadata/source hashes, require an explicit pinned parent grant and existing original bridge gate, exclusively reserve each slot/stage, fsync immutable journal records, retain unknown/overshoot and stop later work.
2. `production_generation_entry.py`: fixed Python stage dispatcher. It loads original bridge/protocol/capture/driver/status only after source verification. It records original stage outputs and exact terminal acknowledgment. It has no retry loop.
3. `production_library_commit.js`: one original V2 commit composition. It verifies the unchanged V2 and retention source bytes, forces the approved unobservable timing mode and uses all durable hooks below.
4. `library_wait_observer.js`: unchanged tool arguments/results/throw identity and original call order; original write/read/search ceilings; no replay; bound result metadata. Successors, including prebound handles, stop on unknown outcomes or incomplete predecessors.
5. `measured_exec_adapter.js` + `measured_local_helper.py`: replace only an explicitly pinned Python helper launch prefix; preserve original script bytes, argv, stdin, stdout and tool options. Each helper gets a unique durable intent and SELF checkpoint receipt. A missing/unknown helper is not zero usage.
6. `library_stage_sidecar.py`: persist each Library intent/result and verify full binding before closing. It checks actual current write ID/file ID/version, exact activated index/archive identity, current payload hash, original retention intent/response and original committed receipt. A stale receipt cannot close the stage.

`passive_wait_observer.py`, its tests, and `generation_accounting.py` are diagnostic/synthetic references only. They are not imported by the production entry.

## Consumer-local setup, without execution

Run `inspect_contract(package, policy_path, accounting_path, source_root)` in the consuming executor. The 177-file package root and the 456-file external source root are distinct. Check the complete source contract before the first producer import; do not equate the package count with all dependencies.

Create a consumer-local contract JSON from that result. The parent must later issue an independently reviewed GEN grant, binding:

- Canonical workspace and its sole `phase2-generation-accounting` journal; original `phase2-bridge-journal`
- Contract hash, exact policy/accounting/supplement hashes and the original active bridge gate file
- Exact original slot/request order, activated storage, initial confirmed head/archive, and retention audit directory
- Full operational source manifest and each absolute consumer-local source path, including both production entry files
- Fixed original source modules and fixed dispatcher targets; local helper source bytes and allowed original Python launch prefixes

Use `GENERATION_GRANT_TEMPLATE.json` only as a disabled shape reference. Do not flip its boolean or copy source paths from another executor.

## Fixed lifecycle

Initialization validates the already-created, fresh original namespace/head and records a measured local boundary. It does not create extra Library objects.

For each next original position:

1. Python entry reserves sidecar slot, then calls original bridge `reserve_next`
2. Original bridge `prepare_reserved`
3. Begin `claim_commit`; execute the retained original JS commit exactly once; verify/close the Library stage
4. Original bridge `collect_reserved` once; full call wall is measured with no observer/subtraction
5. Original driver `slot_additions` / `build_wave_archive`
6. Begin, execute and verify `archive_commit`
7. Original driver `finish_index`
8. Begin, execute and verify `terminal_commit`
9. Original bridge `finish_position`, retaining its actual terminal acknowledgment

After position 60, finalization checks the complete existing terminal head. There is no position 61, resampling or automatic recovery. Original initialization/finalization storage setup remains separately authorized and pinned.

## JS combination and durable hooks

Call `runPendingLibraryStage` only with the exact object returned by `ProductionEntry.begin_library`, the bound context and real raw tools. It uses:

`raw tools → measured helper launcher → Library observer → original retainLibraryReplies → original commitV2`

Required hooks are concrete adapters to the Python sidecar:

- `beforeOperation(token, intent)` → `persist_intent`
- `afterObservation(token, receipt)` → `persist_observation`
- `getHelperReceipt(token, invocation)` → read that exact durable helper receipt/envelope
- `verifyHelperReceipt(token, invocation, envelope)` → `verify_helper`, return true only on verified success
- `closeStage(pending, snapshot, originalReceipt)` → `ProductionEntry.close_library`

Use unwrapped raw tools for sidecar hook commands, to avoid recursively measuring the observer. Their local control receipts are included in finalization. No callback can substitute a successful boolean for missing actual Library/SELF/fence evidence.

The local executable CLI/assistant tool adapter for these hooks must use the same consuming executor and exact source pins; the functions supplied by this package do not themselves expose or emulate authenticated Library APIs.

## Failure handling

An unfinished stage, helper intent without matching receipt, unresolved Library outcome, source drift, integrity failure, duplicate stage or resource overshoot stops further generation. Do not create another journal, reset balances, reissue the write/model, or clear original fences to proceed. Original exceptions take priority if measurement also fails. The original durable begin remains available for evidence-only reconciliation.

All validations so far are synthetic/offline or read-only. A passing test is not a generation grant.

## Fixed callable hooks, no hand-written callbacks

`production_library_commit.js` now loads the Library outcome wrapper, local exec adapter and hook factory from their exact SHA-pinned source text. It does not accept arbitrary factory/hook callbacks. `production_library_hooks.js` constructs only fixed `library_hooks_cli.py` commands, with stdin JSON and the exact active grant/token.

The initial `enter` hook takes a durable, once-only token lease before any original helper or Library method runs. Recreating the JS instance, changing operation IDs or replaying the same pending object cannot recreate original helper work. Before each tool dispatch, the Python hook enforces the whole token's durable operation quota/order and the entry's sealed file/Library ID/version/payload-hash contract. The first write's real returned identity pins subsequent reads/search.

Every `enter/before/after/get/verify` hook records its own SELF checkpoint and measured local window. `close` records its prelude; the Python entry and close verifier record subsequent local work. Whole-hook windows replace overlapping inner persist windows. The durable close verifier's read/validation body is also timed. Unmeasured process entry/final tails stay separately unknown local Python work under the supplement.

In `sources`, supply exact text for `commit`, `retention`, `libraryMeter`, `execAdapter`, and `hooksFactory`. In `paths`, include `hooksCliPath`, `launcherPath`, `journalRoot`, `grantPath`, original Python launch prefixes, `retentionAuditDirectory`, and `retentionHelperPath`. `rawTools` is the actual authorized executor tool object. The fixed CLI resolves real receipts; it never accepts a mocked positive callback as production evidence.

## Namespace bootstrap handoff

Actual namespace creation is separate, zero-model work requiring the parent's explicit one-time initialization grant. This operating package did not perform it. Its measured resource handoff is debited to the existing initial/final 60 SELF-checkpoint / 240 measured-window pool; it is not an extra allowance.

The final GEN grant must pin `namespace_initialization_handoff.path` and `file_sha256`. Initialization verifies its exact workspace/run ID, actual initial index/archive receipts, zero model/candidate executions, nonempty measurements and every referenced receipt-file hash. It passes those measurements together with its own local receipt into the same sidecar pool.

Actual Library version zero is supported. The separate bootstrap's original create route uses the approved predecessor convention; subsequent generation commits use the observed existing version (including zero), never an invented positive starting version. Original P0/P1 storage IDs remain forbidden.

The `grant_sha256` argument is the SHA-256 of `durable_generation_sidecar.canon(grant)`. Store the grant using that canonical JSON encoding or compute its canonical digest explicitly. This is separate from raw-byte `*_file_sha256` fields. The operating manifest is an outer parent-activation/audit pin; runtime checks the listed absolute `operational_source_files` and the relevant entry/CLI/JS source gates directly.
