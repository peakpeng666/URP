'use strict';
const assert=require('assert');
const {createMeasuredExecAdapter}=require('./measured_exec_adapter.js');
const original="python3 -I '/TEST_ONLY/helper.py' begin '/TEST_ONLY/root' <<'JSON'\n{\"literal\":\"a; b\"}\nJSON";
const options={launcherPath:'/TEST_ONLY/meter.py',journalRoot:'/TEST_ONLY/journal',grantPath:'/TEST_ONLY/grant.json',
  grantSha256:'a'.repeat(64),currentHelperInvocation:()=>({method:'exec_command',command_sha256:'b'.repeat(64),invocation_id:'TEST_ONLY:helper:1'}),
  originalLaunchPrefixes:[{python:'python3 -I',scriptPath:'/TEST_ONLY/helper.py'}]};
let seen=[];const returned=Promise.resolve({TEST_ONLY:true});
const raw={exec_command(args){seen.push(args);return returned;},other:42};
const wrapped=createMeasuredExecAdapter(raw,options);
const args={cmd:original,login:false,max_output_tokens:100};
assert.strictEqual(wrapped.exec_command(args),returned);
assert.strictEqual(seen.length,1);assert.strictEqual(seen[0].login,false);assert.strictEqual(seen[0].max_output_tokens,100);
assert.ok(seen[0].cmd.startsWith("python3 -I '/TEST_ONLY/meter.py' "));
assert.ok(seen[0].cmd.endsWith(" -- begin '/TEST_ONLY/root' <<'JSON'\n{\"literal\":\"a; b\"}\nJSON"));
assert.strictEqual(args.cmd,original);assert.strictEqual(wrapped.other,42);
assert.throws(()=>wrapped.exec_command({cmd:"python3 '/wrong.py' anything"}),/unrecognized/);assert.strictEqual(seen.length,1);
const error={TEST_ONLY_error:true};
const throwing=createMeasuredExecAdapter({exec_command(){throw error;}},options);
try {throwing.exec_command(args);assert.fail();} catch(e){assert.strictEqual(e,error);}
assert.throws(()=>createMeasuredExecAdapter(raw,{...options,originalLaunchPrefixes:[]}),/no_pinned/);
console.log('5 measured-exec adapter offline checks passed; zero real tools or processes');
