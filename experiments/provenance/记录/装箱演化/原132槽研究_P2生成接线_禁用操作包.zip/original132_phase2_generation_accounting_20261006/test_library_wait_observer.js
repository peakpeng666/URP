/* Offline only. Unchanged, hash-pinned bridge + retention sources are evaluated
 * with in-memory fake tools. No producer, P1 results, API, model, actual Library,
 * shell helper, network operation, or persistent Library mutation is executed.
 */
'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const {createLibraryWaitObserver} = require('./library_wait_observer');
const sha = value => crypto.createHash('sha256').update(value, 'utf8').digest('hex');
const parent = path.resolve(__dirname, '../original132_phase1_preparation_20261005');
const bridge = fs.readFileSync(path.join(parent, 'exporter/src/library_commit_v2.js'), 'utf8');
const retention = fs.readFileSync(path.join(parent, 'retention/retain_library_replies.js'), 'utf8');
assert.equal(sha(bridge), 'a870f16d05b5db17a94be6544beb725d69fe6a429b41d3bb5ba7fe646811270d');
assert.equal(sha(retention), 'e44fec0c2059aa184825fd1d75c9eed851858c55230f22cb1650a7ab89ff0f6c');
const retain = new Function(retention + '\nreturn retainLibraryReplies;')();
const commitWith = tools => new Function('tools', bridge + '\nreturn commitV2;')(tools);
const SUPPLEMENT_SHA256 = '778f9e487fc3a9201c8dc0de061b6195f6e3e8045cd5e4dcd30464e1830c3193';
const M = {
  create:'mcp__codex_apps__library_create_library_file',
  replace:'mcp__codex_apps__library_replace_library_file',
  read:'mcp__codex_apps__library_read', search:'mcp__codex_apps__library_search'
};
const binding = (stage = 'claim', overrides = {}) => ({scope:'slot', slotId:'slot1', stage,
  operationId:'op-' + stage, request_sha256:'1'.repeat(64), plan_sha256:'2'.repeat(64),
  roster_sha256:'3'.repeat(64), source_sha256:'4'.repeat(64), binding_sha256:'5'.repeat(64), ...overrides});
const clone = value => JSON.parse(JSON.stringify(value));
const tests = [];
function test(name, fn) { tests.push({name, fn}); }
function fixture(config = {}) {
  const state = {time:0, trace:[], writes:0, reads:0, item:null, hookTrace:[]};
  function log(method, args) {
    state.trace.push({method, args:clone(args)});
    if (Object.values(M).includes(method)) state.time += 17;
    else state.time += 500;
  }
  function write(method, args) {
    log(method, args);
    state.writes++;
    state.reads = 0;
    if (config.thrown !== undefined) throw config.thrown;
    state.item = {status:'succeeded', library_file_id:args.library_file_id || 'library-archive',
      file_id:'file-' + state.writes, current_version_number:(args.expected_current_version || 0) + 1,
      file_name:'fixture-中文-😀.json', xattrs:[{name:'fixture',value:'unchanged'}]};
    if (config.unknown) return {isError:true, structuredContent:{status:'unknown'}, content:[]};
    return {structuredContent:clone(state.item), content:[{type:'text',text:'complete response'}]};
  }
  const tools = {
    exec_command(args) {
      log('exec_command', args);
      if (config.fenceFailure && args.cmd.includes('external_commit_fence_v2.py') &&
          args.cmd.includes(config.fenceFailure)) return Promise.resolve({exit_code:1,output:'fixture fence failure'});
      if (args.cmd.includes('commit_receipt_v2.py'))
        return Promise.resolve({exit_code:0,output:JSON.stringify({fixture:true,write:state.writes})});
      return Promise.resolve({exit_code:0,output:'{}'});
    },
    apply_patch(args) { log('apply_patch', args); return Promise.resolve({isError:false}); },
    write_stdin(args) { log('write_stdin', args); return Promise.resolve({exit_code:0,output:''}); },
    irrelevant(args) { return args; },
    [M.create](args) { return Promise.resolve(write(M.create,args)); },
    [M.replace](args) { return Promise.resolve(write(M.replace,args)); },
    [M.read](args) {
      log(M.read,args); state.reads++;
      const bad = config.fallback && state.reads === 1;
      return Promise.resolve({structuredContent:{results:[{file_id:bad?'wrong':state.item.file_id,
        library_file_id:state.item.library_file_id, has_more:false,content:['fixture content']} ]}});
    },
    [M.search](args) { log(M.search,args); return Promise.resolve({structuredContent:{results:[]}}); }
  };
  return {tools,state};
}
function meterFor(f, overrides = {}) {
  return createLibraryWaitObserver(f.tools, {slotIds:['slot1'],timingMode:'monotonic',clockDomainId:'fixture-clock',
    now:() => f.state.time,
    async beforeOperation(intent) {
      f.state.hookTrace.push({type:'before', value:intent});
      assert(Object.isFrozen(intent));
      f.state.time += 1000;
    },
    async afterObservation(receipt) {
      f.state.hookTrace.push({type:'after',value:receipt});
      assert(Object.isFrozen(receipt));
      f.state.time += 2000;
    },
    // Deliberately synthetic offline evidence, never presented as production CPU.
    verifyLocalHelperReceipt:async (invocation,receipt) => receipt.fixture === true &&
      receipt.invocation_id === invocation.invocation_id && receipt.measurement_scope === 'SELF',
    ...overrides});
}
async function fixtureVerifyHelpers(meter) {
  for (const h of meter.snapshot().local_helpers.filter(h => !h.self_receipt_verified))
    await meter.recordLocalHelperReceipt(h.invocation_id, {fixture:true,measurement_scope:'SELF',invocation_id:h.invocation_id,command_sha256:h.command_sha256,resource_receipt_sha256:'6'.repeat(64)});
}
async function runRoute(f, meter) {
  const outputs=[];
  for (const [stage,id,version,index] of [
    ['claim','library-index',1,true],['archive',null,0,false],['terminal','library-index',2,true]
  ]) {
    const operationId='op-'+stage;
    const raw = meter ? meter.bindStage(binding(stage)) : f.tools;
    const retained = retain(raw, {auditDirectory:'/fake/audit',operationId,helperPath:'/fake/retain.py'});
    outputs.push(await commitWith(retained)('/fake/root','/fake/'+stage+'.json',id,version,index));
    if (meter) await fixtureVerifyHelpers(meter);
  }
  return outputs;
}
for (const fallback of [false,true]) test('unchanged full V2 route ' + (fallback?'with fallback':'success'), async () => {
  const baseline=fixture({fallback}), observed=fixture({fallback}), meter=meterFor(observed);
  assert.deepEqual(await runRoute(observed,meter), await runRoute(baseline));
  assert.deepEqual(observed.state.trace,baseline.state.trace);
  const snapshot=meter.snapshot();
  assert.deepEqual(snapshot.slots.slot1,{write:3,read:fallback?4:2,search:fallback?2:0});
  assert.equal(snapshot.observations.length, fallback?9:5);
  assert.equal(snapshot.library_await_wall_ms,(fallback?9:5)*17);
  assert.equal(meter.assertCanContinue(),true);
  assert.equal(snapshot.generation_resource_ready,false);
  for (const r of snapshot.observations) {
    assert.equal(r.elapsed_ms,17); // All retention, hook and helper time excluded.
    assert.equal(r.tool_arguments_sha256,sha(r.arguments_json));
    assert.equal(r.result_sha256,sha(r.result_json));
    assert.equal(r.request_sha256,'1'.repeat(64));
    assert.equal(r.source_sha256,'4'.repeat(64));
    assert.equal(r.resources.javascript_cpu,'unknown');
    assert.equal(r.resources.plugin_cpu,'unknown');
    assert.equal(r.resources.library_await_wall_is_cpu,false);
    if (r.kind==='write') {
      assert.equal(r.write_outcome,'acknowledged_not_remote_byte_proof');
      const rawResult=JSON.parse(r.result_json);
      assert.equal(rawResult.content[0].text,'complete response');
      const retentionCall=observed.state.trace.find(x => x.method==='exec_command' &&
        x.args.cmd.includes("'response' '/fake/audit/"+r.operation_id+"'"));
      assert(retentionCall);
      const retained=JSON.parse(retentionCall.args.cmd.split("<<'RETAIN_LIBRARY_OBJECT_JSON'\n")[1].split('\nRETAIN_LIBRARY_OBJECT_JSON')[0]);
      assert.deepEqual(rawResult,retained);
    }
  }
  for (const h of snapshot.local_helpers) {
    assert.equal(h.self_receipt_verified,true);
    if (h.method==='exec_command') {
      const matching=observed.state.trace.find(t => t.method===h.method && sha(t.args.cmd)===h.command_sha256);
      assert(matching);
    }
  }
});
test('raw returned object and argument identity preserved',async () => {
  const f=fixture(), result={structuredContent:{status:'succeeded',library_file_id:'lib',file_id:'file',current_version_number:1}};
  const args={file:'/fake/中文😀',library_artifact_type:'other'};
  f.tools[M.create]=function (actual) { assert.strictEqual(this,f.tools); assert.strictEqual(actual,args);f.state.time+=7;return result; };
  const meter=meterFor(f), wrapped=meter.bindStage(binding());
  assert.strictEqual(await wrapped[M.create](args),result);
  const r=meter.snapshot().observations[0];
  assert.equal(r.tool_arguments_sha256,sha(r.arguments_json));
  assert.deepEqual(JSON.parse(r.result_json),result);
  assert.equal(r.elapsed_ms,7);
});
test('original thrown object identity preserved through retention and observer failure',async () => {
  const sentinel=Object.assign(new Error('original exception'),{fixture:1});
  const f=fixture({thrown:sentinel});
  const meter=meterFor(f,{afterObservation:async()=>{throw new Error('observer failure');}});
  const wrapped=retain(meter.bindStage(binding()),{auditDirectory:'/fake/audit',operationId:'op-claim',helperPath:'/fake/retain.py'});
  await assert.rejects(commitWith(wrapped)('/fake/root','/fake/input','library-index',1,true), e => e===sentinel);
  assert.equal(f.state.writes,1);
  assert.equal(meter.snapshot().observations[0].outcome,'threw');
  assert.equal(meter.snapshot().observations[0].write_outcome,'unknown');
  assert.throws(()=>meter.assertCanContinue(),/library_meter_unknown_stop/);
  assert.throws(()=>meter.bindStage(binding('archive')),/library_meter_unknown_stop/);
});
test('unknown write response is unchanged, retained, and stops later generation',async () => {
  const f=fixture({unknown:true}),meter=meterFor(f);
  const wrapped=retain(meter.bindStage(binding()),{auditDirectory:'/fake/audit',operationId:'op-claim',helperPath:'/fake/retain.py'});
  await assert.rejects(commitWith(wrapped)('/fake/root','/fake/input','library-index',1,true),/external_commit_uncertain_stop/);
  assert.equal(f.state.writes,1);
  assert(f.state.trace.some(x=>x.method==='exec_command' && x.args.cmd.includes("'response'")));
  assert.equal(meter.snapshot().observations[0].write_outcome,'unknown');
  assert.throws(()=>meter.assertCanContinue(),/library_meter_unknown_stop/);
});
test('before-hook failure prevents operation and consumes attempt',async () => {
  const f=fixture(),sentinel=new Error('durable before failed');
  const meter=meterFor(f,{beforeOperation:async()=>{throw sentinel;}}),wrapped=meter.bindStage(binding());
  await assert.rejects(wrapped[M.create]({file:'/fake/input'}),e=>e===sentinel);
  assert.equal(f.state.writes,0);
  await assert.rejects(wrapped[M.create]({file:'/fake/input'}),/write_already_attempted_no_retry/);
  assert.throws(()=>meter.assertCanContinue(),/library_meter_unknown_stop/);
});
test('post-hook failure preserves current full V2 return and call count',async () => {
  const baseline=fixture(),f=fixture();
  const meter=meterFor(f,{afterObservation:async()=>{throw new Error('disk full');}});
  const retained=raw=>retain(raw,{auditDirectory:'/fake/audit',operationId:'op-claim',helperPath:'/fake/retain.py'});
  const expected=await commitWith(retained(baseline.tools))('/fake/root','/fake/input','library-index',1,true);
  const actual=await commitWith(retained(meter.bindStage(binding())))('/fake/root','/fake/input','library-index',1,true);
  assert.deepEqual(actual,expected);
  assert.deepEqual(f.state.trace,baseline.state.trace);
  assert.throws(()=>meter.assertCanContinue(),/library_meter_unknown_stop/);
});
test('duplicate writes/stages/operation IDs and stage read/search limits',async () => {
  const f=fixture(),meter=meterFor(f),wrapped=meter.bindStage(binding('archive'));
  await wrapped[M.create]({file:'/fake/archive'});
  await assert.rejects(wrapped[M.create]({file:'/fake/archive'}),/write_already_attempted_no_retry/);
  await assert.rejects(wrapped[M.replace]({file:'/fake/archive'}),/write_already_attempted_no_retry/);
  await assert.rejects(wrapped[M.read]({read:[]}),/library_stage_ceiling_exceeded/);
  await assert.rejects(wrapped[M.search]({search_query:[]}),/library_stage_ceiling_exceeded/);
  assert.throws(()=>meter.bindStage(binding('archive',{operationId:'another'})),/stage_already_bound_no_retry/);
  assert.throws(()=>meter.bindStage(binding('terminal',{operationId:'op-archive'})),/operation_id_already_bound_no_retry/);
  assert.equal(f.state.writes,1);
  const index=meter.bindStage(binding('claim_commit'));
  await assert.rejects(index[M.read]({read:[]}),/index_read_requires_prior_write/);
  await index[M.create]({file:'/fake/index'});
  await assert.rejects(index[M.search]({search_query:[]}),/index_search_requires_first_read/);
  await index[M.read]({read:[]});
  await assert.rejects(index[M.read]({read:[]}),/second_index_read_requires_search/);
  await index[M.search]({search_query:[]});
  await index[M.read]({read:[]});
  await assert.rejects(index[M.read]({read:[]}),/library_stage_ceiling_exceeded/);
  await assert.rejects(index[M.search]({search_query:[]}),/library_stage_ceiling_exceeded/);
});
test('initialization/finalization require explicit pins and stay outside slot totals',async () => {
  const f=fixture(),without=meterFor(f);
  const init=binding('index',{scope:'initialization',slotId:undefined,operationId:'init-index'});
  assert.throws(()=>without.bindStage(init),/unpinned_initialization_or_finalization/);
  const meter=meterFor(f,{initializationFinalizationOps:{initialization:'init-index',finalization:'final-index'}});
  const a=meter.bindStage(init);await a[M.create]({file:'/fake/init'});
  await assert.rejects(a[M.create]({file:'/fake/init'}),/write_already_attempted_no_retry/);
  await a[M.read]({read:[]});
  const b=meter.bindStage({...init,scope:'finalization',operationId:'final-index'});
  await b[M.create]({file:'/fake/final'});
  await b[M.read]({read:[]});
  assert.deepEqual(meter.snapshot().slots.slot1,{write:0,read:0,search:0});
  assert.throws(()=>meter.bindStage({...init,operationId:'arbitrary'}),/unpinned_initialization_or_finalization/);
  assert.throws(()=>meter.bindStage(binding('claim',{slotId:'unexpected'})),/unpinned_slot_or_stage/);
});
test('helper forwarding preserves args, promise and thrown identity; SELF receipts hard-required',async () => {
  const f=fixture(),promise=Promise.resolve({fixture:true}),sentinel={fixture:'throw'},args={cmd:'printf 中文😀'};
  f.tools.exec_command=function(a){assert.strictEqual(a,args);assert.strictEqual(this,f.tools);return promise;};
  f.tools.apply_patch=function(a){assert.equal(a,'fixture patch');throw sentinel;};
  const meter=meterFor(f),wrapped=meter.bindStage(binding());
  assert.strictEqual(wrapped.exec_command(args),promise);
  assert.throws(()=>wrapped.apply_patch('fixture patch'),e=>e===sentinel);
  assert.strictEqual(wrapped.irrelevant,f.tools.irrelevant);
  const snapshot=meter.snapshot();
  assert.equal(snapshot.library_await_wall_ms,0);
  assert.equal(snapshot.local_helpers.length,1);
  assert.equal(snapshot.unobservable_tools.length,1);
  assert.equal(snapshot.unobservable_tools[0].process_self_claim,false);
  assert.equal(snapshot.local_helpers[0].command_sha256,sha(args.cmd));
  assert.equal(snapshot.local_helpers[0].cpu,'unknown_until_separate_process_self_receipt');
  assert.throws(()=>meter.assertCanContinue(),/local_helper_self_receipts_required/);
  await assert.rejects(meter.recordLocalHelperReceipt(snapshot.local_helpers[0].invocation_id,{kind:'wall'}),/local_helper_self_receipt_binding_required/);
  await fixtureVerifyHelpers(meter);
  assert.throws(()=>meter.assertCanContinue(),/prior_stage_library_sequence_incomplete/);
  assert.equal(meter.snapshot().generation_resource_ready,false);
});
test('nonserializable result and invalid clock never replace the tool result',async () => {
  const f=fixture(),cycle={};cycle.self=cycle;
  f.tools[M.create]=async()=>cycle;
  const meter=meterFor(f),wrapped=meter.bindStage(binding());
  assert.strictEqual(await wrapped[M.create]({file:'/fake/input'}),cycle);
  assert.equal(meter.snapshot().observations[0].serialization_status,'unknown');
  assert.throws(()=>meter.assertCanContinue(),/library_meter_unknown_stop/);
  const g=fixture();let ticks=0;
  const broken=meterFor(g,{now:()=>++ticks===1?50:40});
  const result=await broken.bindStage(binding())[M.create]({file:'/fake/input'});
  assert.equal(result.structuredContent.status,'succeeded');
  assert.equal(broken.snapshot().library_await_wall_ms,null);
  assert.equal(broken.snapshot().observations[0].elapsed_ms,null);
  assert.throws(()=>broken.assertCanContinue(),/library_meter_unknown_stop/);
});
test('missing bindings and non-JSON request fail closed without calling tools',async () => {
  const f=fixture(),meter=meterFor(f);
  assert.throws(()=>meter.bindStage(binding('claim',{plan_sha256:undefined})),/missing_or_invalid_plan_sha256/);
  const wrapped=meter.bindStage(binding());
  await assert.rejects(wrapped[M.create]({file:undefined}),/non_json_observation/);
  assert.equal(f.state.writes,0);
  assert.throws(()=>meter.assertCanContinue(),/library_meter_unknown_stop/);
});
test('concurrent Library awaits are rejected without extra call',async () => {
  const f=fixture();let resolve;
  f.tools[M.create]=()=>new Promise(r=>{resolve=r;});
  const meter=meterFor(f),wrapped=meter.bindStage(binding());
  const first=wrapped[M.create]({file:'/fake/input'});
  await new Promise(r=>setImmediate(r));
  await assert.rejects(wrapped[M.read]({read:[]}),/concurrent_library_await_not_allowed/);
  resolve({structuredContent:{status:'succeeded',library_file_id:'lib',file_id:'file',current_version_number:1}});
  await first;
  assert.equal(meter.snapshot().observations.length,1);
});

test('helper evidence must be verified, never accepted as a boolean',async () => {
  const f=fixture(),meter=meterFor(f,{verifyLocalHelperReceipt:async()=>false});
  const wrapped=meter.bindStage(binding());await wrapped.exec_command({cmd:'fixture command'});
  const h=meter.snapshot().local_helpers[0];
  await assert.rejects(meter.recordLocalHelperReceipt(h.invocation_id,true),/local_helper_self_receipt_binding_required/);
  await assert.rejects(meter.recordLocalHelperReceipt(h.invocation_id,{invocation_id:h.invocation_id,
    command_sha256:h.command_sha256,measurement_scope:'SELF',resource_receipt_sha256:'a'.repeat(64)}),
    /local_helper_self_receipt_rejected/);
  assert.equal(meter.snapshot().local_helpers[0].self_receipt_verified,false);
  assert.throws(()=>meter.assertCanContinue(),/library_meter_unknown_stop/);
});
test('primitive thrown values retain exact identity',async () => {
  for (const original of [null,undefined,'fixture error',17]) {
    const f=fixture();f.tools[M.create]=async()=>{throw original;};
    const meter=meterFor(f),wrapped=meter.bindStage(binding());
    let caught=false;
    try { await wrapped[M.create]({file:'/fake/input'}); }
    catch (error) { caught=true;assert.strictEqual(error,original); }
    assert(caught);
    assert.equal(meter.snapshot().observations[0].write_outcome,'unknown');
  }
});
test('snapshot retains per-stage health and authenticated response binding',async () => {
  const f=fixture({fallback:true}),meter=meterFor(f);
  await runRoute(f,meter);
  const snapshot=meter.snapshot();
  assert.equal(snapshot.stages.length,3);
  for(const stage of snapshot.stages) {
    assert.equal(stage.meter_status,'observed');
    assert.equal(stage.binding_sha256,'5'.repeat(64));
    assert.equal(stage.local_helper_self_receipts_complete,true);
    assert.equal(stage.unobservable_service_cpu,'unknown');
    assert.equal(stage.javascript_cpu,'unknown');
    assert.equal(stage.plugin_cpu,'unknown');
    assert.equal(stage.write_outcomes.length,1);
    assert(stage.local_helper_invocation_ids.length>0);
    assert.equal(stage.unobservable_invocation_ids.length,1);
  }
  for(const h of snapshot.local_helpers) {
    assert.equal(h.self_receipt_sha256,sha(h.self_receipt_json));
    const e=JSON.parse(h.self_receipt_json);
    assert.equal(e.command_sha256,h.command_sha256);
    assert.equal(e.invocation_id,h.invocation_id);
    assert.equal(e.measurement_scope,'SELF');
  }
  for(const p of snapshot.observation_persistence)
    assert.equal(p.status,'hook_returned_caller_must_verify_durable_receipt');
});


test('monotonic timing requires explicit injected clock and rejects Date.now accounting',async () => {
  const f=fixture();
  assert.throws(()=>meterFor(f,{now:undefined}),/explicit_verified_monotonic_clock_required/);
  assert.throws(()=>meterFor(f,{clockDomainId:undefined}),/clock_domain_id_required/);
  assert.throws(()=>meterFor(f,{now:Date.now}),/date_now_is_diagnostic_only_not_monotonic_proof/);
  assert.throws(()=>meterFor(f,{timingMode:'wall'}),/invalid_timing_mode/);
  assert.equal(f.state.trace.length,0);
});
test('unobservable timing requires exact supplement and never reads any clock',async () => {
  const f=fixture();
  for(const digest of [undefined,'a'.repeat(64)])
    assert.throws(()=>meterFor(f,{timingMode:'unobservable',accountingSupplementSha256:digest}),
      /unobservable_timing_requires_exact_accounting_supplement/);
  const descriptor=Object.getOwnPropertyDescriptor(globalThis,'performance');
  const oldDateNow=Date.now;
  try {
    Object.defineProperty(globalThis,'performance',{value:undefined,configurable:true});
    Date.now=()=>{throw new Error('Date.now must never be called for elapsed proof');};
    const baseline=fixture({fallback:true}),observed=fixture({fallback:true});
    const meter=meterFor(observed,{timingMode:'unobservable',clockDomainId:undefined,
      accountingSupplementSha256:SUPPLEMENT_SHA256,now:()=>{throw new Error('injected clock must not be called');}});
    assert.deepEqual(await runRoute(observed,meter),await runRoute(baseline));
    assert.deepEqual(observed.state.trace,baseline.state.trace);
    const snapshot=meter.snapshot();
    assert.equal(snapshot.timing_mode,'unobservable');
    assert.equal(snapshot.accounting_supplement_sha256,SUPPLEMENT_SHA256);
    assert.equal(snapshot.clock_domain_id,'unobservable');
    assert.equal(snapshot.status,'observed');
    assert.equal(snapshot.timing_status,'unknown');
    assert.deepEqual(snapshot.unknown_reasons,[]);
    assert.equal(snapshot.library_await_wall_ms,null);
    assert.equal(snapshot.observed_library_await_wall_ms,0); // Known partial sum of no measured intervals.
    assert.equal(snapshot.observed_known_interval_count,0);
    assert.equal(snapshot.observed_library_await_wall_ms_is_partial,true);
    assert.equal(snapshot.interval_coverage_complete,false);
    assert.equal(snapshot.resources.included_in_local_inclusive_61440_proof,false);
    assert.equal(snapshot.resources.wait_deduction_ms,0);
    assert.equal(meter.assertCanContinue(),true);
    for(const receipt of snapshot.observations) {
      assert.equal(receipt.await_start_ms,null);assert.equal(receipt.await_end_ms,null);
      assert.equal(receipt.elapsed_ms,null);assert.equal(receipt.timing_status,'unknown');
      assert.equal(receipt.result_sha256,sha(receipt.result_json));
    }
  } finally {
    Date.now=oldDateNow;
    if(descriptor) Object.defineProperty(globalThis,'performance',descriptor);
    else delete globalThis.performance;
  }
});
test('unobservable timing needs no clock and does not forgive unknown mutation or observer failures',async () => {
  for(const config of [{unknown:true},{thrown:new Error('fixture mutation outcome unknown')}]) {
    const f=fixture(config),meter=meterFor(f,{timingMode:'unobservable',now:undefined,clockDomainId:undefined,
      accountingSupplementSha256:SUPPLEMENT_SHA256});
    const retained=retain(meter.bindStage(binding()),{auditDirectory:'/fake/audit',operationId:'op-claim',helperPath:'/fake/retain.py'});
    await assert.rejects(commitWith(retained)('/fake/root','/fake/input','library-index',1,true));
    assert.equal(f.state.writes,1);
    assert.equal(meter.snapshot().timing_status,'unknown');
    assert.equal(meter.snapshot().status,'unknown');
    assert(meter.snapshot().unknown_reasons.some(r=>r.code==='write_outcome_unknown'));
    assert.throws(()=>meter.bindStage(binding('archive')),/library_meter_unknown_stop/);
  }
  const f=fixture(),meter=meterFor(f,{timingMode:'unobservable',now:undefined,
    accountingSupplementSha256:SUPPLEMENT_SHA256,afterObservation:async()=>{throw new Error('fixture persistence failure');}});
  await meter.bindStage(binding())[M.create]({file:'/fake/input'});
  assert.throws(()=>meter.assertCanContinue(),/library_meter_unknown_stop/);
  assert.equal(meter.snapshot().observations[0].elapsed_ms,null);
});
test('unobservable timing preserves original fence failure and poisons rejected SELF evidence',async () => {
  for(const failure of [' begin ',' confirm ']) {
    const baseline=fixture({fenceFailure:failure}),f=fixture({fenceFailure:failure});
    const meter=meterFor(f,{timingMode:'unobservable',now:undefined,accountingSupplementSha256:SUPPLEMENT_SHA256,
      verifyLocalHelperReceipt:async(_invocation,receipt)=>receipt.exit_code===0});
    const retained=raw=>retain(raw,{auditDirectory:'/fake/audit',operationId:'op-claim',helperPath:'/fake/retain.py'});
    const expected=failure===' begin '?/prior_or_uncertain_external_write_stop/:/acknowledgment_retention_failed_stop/;
    await assert.rejects(commitWith(retained(baseline.tools))('/fake/root','/fake/input','library-index',1,true),expected);
    await assert.rejects(commitWith(retained(meter.bindStage(binding())))('/fake/root','/fake/input','library-index',1,true),expected);
    assert.deepEqual(f.state.trace,baseline.state.trace);
    assert.throws(()=>meter.assertCanContinue(),/local_helper_self_receipts_required/);
    const command=f.state.trace.find(t=>t.method==='exec_command'&&t.args.cmd.includes('external_commit_fence_v2.py')&&t.args.cmd.includes(failure));
    const helper=meter.snapshot().local_helpers.find(h=>h.command_sha256===sha(command.args.cmd));
    await assert.rejects(meter.recordLocalHelperReceipt(helper.invocation_id,{invocation_id:helper.invocation_id,
      command_sha256:helper.command_sha256,measurement_scope:'SELF',resource_receipt_sha256:'6'.repeat(64),exit_code:1}),
      /local_helper_self_receipt_rejected/);
    assert.equal(meter.snapshot().status,'unknown');
    assert.equal(meter.snapshot().library_await_wall_ms,null);
    assert.throws(()=>meter.bindStage(binding('archive')),/library_meter_unknown_stop/);
  }
});


test('prebound successor cannot bypass poisoned stage through writes or any wrapped helper',async () => {
  for(const fault of ['post_hook','pre_hook','unknown_write']) {
    const f=fixture({unknown:fault==='unknown_write'});
    const overrides={timingMode:'unobservable',now:undefined,accountingSupplementSha256:SUPPLEMENT_SHA256};
    if(fault==='post_hook') overrides.afterObservation=async()=>{throw new Error('disk-full');};
    if(fault==='pre_hook') overrides.beforeOperation=async()=>{throw new Error('intent-failed');};
    const meter=meterFor(f,overrides),claim=meter.bindStage(binding('claim')),archive=meter.bindStage(binding('archive'));
    const retained=retain(claim,{auditDirectory:'/fake/audit',operationId:'op-claim',helperPath:'/fake/retain.py'});
    if(fault==='post_hook') await commitWith(retained)('/fake/root','/fake/input','library-index',1,true);
    else await assert.rejects(commitWith(retained)('/fake/root','/fake/input','library-index',1,true));
    const callsBefore=f.state.trace.length;
    await assert.rejects(archive[M.create]({file:'/fake/forbidden'}),/library_meter_unknown_stop/);
    for(const [method,args] of [['exec_command',{cmd:'must-not-run'}],['apply_patch','must-not-run'],['write_stdin',{session_id:999}]])
      assert.throws(()=>archive[method](args),/library_meter_unknown_stop/);
    assert.equal(f.state.trace.length,callsBefore);
    assert.equal(meter.snapshot().slots.slot1.write,1);
  }
});
test('prebound successor cannot bypass incomplete original stage or missing SELF receipts',async () => {
  const f=fixture(),meter=meterFor(f),claim=meter.bindStage(binding('claim')),archive=meter.bindStage(binding('archive'));
  const retained=retain(claim,{auditDirectory:'/fake/audit',operationId:'op-claim',helperPath:'/fake/retain.py'});
  await commitWith(retained)('/fake/root','/fake/input','library-index',1,true);
  const callsBefore=f.state.trace.length;
  await assert.rejects(archive[M.create]({file:'/fake/forbidden'}),/local_helper_self_receipts_required/);
  assert.throws(()=>archive.exec_command({cmd:'must-not-run'}),/local_helper_self_receipts_required/);
  assert.equal(f.state.trace.length,callsBefore);
  await fixtureVerifyHelpers(meter);
  await archive[M.create]({file:'/fake/allowed'});
  assert.throws(()=>claim.exec_command({cmd:'retired-stage'}),/stage_no_longer_active_stop/);
  const g=fixture(),meter2=meterFor(g),a=meter2.bindStage(binding('claim')),b=meter2.bindStage(binding('archive'));
  await a[M.create]({file:'/fake/claim'});
  await assert.rejects(b[M.create]({file:'/fake/forbidden'}),/prior_stage_library_sequence_incomplete/);
  assert.throws(()=>b.apply_patch('must-not-run'),/prior_stage_library_sequence_incomplete/);
  assert.equal(g.state.writes,1);
  await a[M.read]({read:[]});
  await b[M.create]({file:'/fake/archive'});
  assert.equal(g.state.writes,2);
});
test('argument mutation during durable before hook prevents authenticated dispatch without cloning',async () => {
  for(const mutate of [args=>{args.file='/fake/changed';},args=>{args.nested.value='changed';}]) {
    const f=fixture();let release,entered;
    const ready=new Promise(r=>{entered=r;});
    const gate=new Promise(r=>{release=r;});
    let intent;
    const meter=meterFor(f,{beforeOperation:async value=>{intent=value;entered();await gate;}});
    const wrapped=meter.bindStage(binding()),args={file:'/fake/original',nested:{value:'original'}};
    const pending=wrapped[M.create](args);
    await ready;mutate(args);release();
    await assert.rejects(pending,/tool_arguments_changed_before_dispatch/);
    assert.equal(f.state.writes,0);
    assert.equal(f.state.trace.length,0);
    assert.equal(JSON.parse(intent.arguments_json)[0].file,'/fake/original');
    assert.equal(intent.tool_arguments_sha256,sha(intent.arguments_json));
    assert.equal(meter.snapshot().status,'unknown');
    assert(meter.snapshot().unknown_reasons.some(r=>r.code==='tool_arguments_changed_before_dispatch'));
    await assert.rejects(wrapped[M.create](args),/write_already_attempted_no_retry/);
  }
});

(async()=>{
  for(const {name,fn} of tests){await fn();process.stdout.write('PASS '+name+'\n');}
  process.stdout.write(JSON.stringify({schema:'offline-library-wait-test-summary-v1',passed:tests.length,
    real_library_calls:0,real_api_calls:0,model_calls:0,real_helper_executions:0,
    coverage:'hash-pinned unchanged V2 and retention evaluated only against in-memory fake tools'})+'\n');
})().catch(error=>{console.error(error);process.exitCode=1;});
