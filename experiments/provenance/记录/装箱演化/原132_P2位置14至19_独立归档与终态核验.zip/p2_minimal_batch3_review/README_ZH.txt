P2位置14至19：独立归档与CLI终态核验

本包只含靶向检查源码、机器结果、来源哈希和本说明；不复制原始data/audit ZIP，不执行候选、runner或collector。

结果：两个源ZIP共40条内部内容hash及CRC通过；全部6个prompt原字节、配置原字节、runner/frozen_inputs与此前已核版本一致。位置14–17为stop且回答非空；18与19为约900秒客户端timeout、exit -9、回答为空，usage未知。本批没有length空回答。
累计复用已有审核历史：P2前19终态中15非空、1 length空、3 timeout空；原总91/132为逻辑生成终态，绝不等同评分通过。

REVIEW.json的科学评分为false表示本靶审没有执行准入或数值评分。09:22已另行批准启动原1–13公开数值评分，当前尚无经核验评分结果；不要把这个原归档审计字段当作未来评分永不发生。
09:14生成环境断连后，页面活动不等于执行已恢复；本审计只看归档字节，不建立恢复证据。源包的STATUS_SNAPSHOT属于生成时历史快照。

复核只需Python标准库，check.py接受data ZIP、audit ZIP、已核reference目录和前两批review根。源码只读取ZIP/JSON/文本并计算hash，候选代码从未作为模块导入或运行。具体用法可运行check.py --help。先前firstslot、batch1/2统计仅复用已完成审核，不重新执行历史生成。
SOURCE_REFERENCES.json给出本次Drive固定ID、源包字节数、SHA256与私有目录位置。所有CLI token均为自报，provider原始HTTP次数、usage、扣费与全历史资源上限未获独立认证。
