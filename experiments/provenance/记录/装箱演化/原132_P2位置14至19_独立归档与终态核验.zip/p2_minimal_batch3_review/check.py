"""Read-only ZIP/JSON/hash review. Never imports or executes candidate/runner code."""
from pathlib import Path, PurePosixPath
import argparse, collections, hashlib, json, time, zipfile

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read_archive(path):
    raw = path.read_bytes()
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        names = z.namelist()
        assert len(names) == len(set(names))
        assert all(not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts for n in names)
        payload = {n: z.read(n) for n in names}
    manifest = json.loads(payload['FILE_MANIFEST.json'])
    assert set(payload) == set(manifest) | {'FILE_MANIFEST.json'}
    for name, rec in manifest.items():
        assert len(payload[name]) == rec['bytes']
        assert sha(payload[name]) == rec['sha256']
    return payload, {'bytes': len(raw), 'sha256': sha(raw), 'members': len(payload),
                     'member_hashes_verified': len(manifest), 'CRC_pass': True,
                     'manifest_covers_all_payload_files': True}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--data-zip', required=True, type=Path)
    ap.add_argument('--audit-zip', required=True, type=Path)
    ap.add_argument('--reference-dir', required=True, type=Path)
    ap.add_argument('--prior-reviews', required=True, type=Path)
    ap.add_argument('--output', required=True, type=Path)
    args = ap.parse_args()
    started = time.process_time()
    data, dmeta = read_archive(args.data_zip)
    audit, ameta = read_archive(args.audit_zip)
    assert (dmeta['bytes'], ameta['bytes']) == (109639, 11188)
    assert (dmeta['member_hashes_verified'], ameta['member_hashes_verified']) == (34, 6)
    baseline = args.prior_reviews / 'p2_minimal_batch2_review' / 'data'
    for name in ('runner.py', 'frozen_inputs.json'):
        assert data['executor/' + name] == (args.reference_dir / name).read_bytes()
        assert data['executor/' + name] == (baseline / 'executor' / name).read_bytes()
    f = json.loads(data['executor/frozen_inputs.json'])
    config_bytes = data['frozen_requested_configuration.raw.json']
    assert config_bytes == f['config_raw'].encode('utf-8')
    assert config_bytes == (baseline / 'frozen_requested_configuration.raw.json').read_bytes()
    requested = {'effort':'high','max_completion_tokens':64000,'model':'glm-5.3',
                 'outer_retries':0,'paid_provider_fallback':False,'steps':2,
                 'temperature':0.7,'tools':False,'top_p':0.9,'wall_seconds':900}
    assert f['freeze']['configuration'] == requested
    assert data['COLLECTION_RECORD.json'] == audit['COLLECTION_RECORD.json']
    collection = json.loads(data['COLLECTION_RECORD.json'])
    assert collection['approved_runner_SHA256'] == sha(data['executor/runner.py'])
    assert collection['frozen_inputs_SHA256'] == sha(data['executor/frozen_inputs.json'])
    assert collection['configuration'] == requested
    report = json.loads(audit['BATCH_REPORT.json'])
    assert report['positions'] == [14,19] and report['configuration'] == requested
    assert report['runner_SHA256'] == collection['approved_runner_SHA256']
    assert report['frozen_inputs_SHA256'] == collection['frozen_inputs_SHA256']
    assert report['data_Drive_receipt']['sha256'] == dmeta['sha256']
    assert report['data_Drive_receipt']['bytes'] == dmeta['bytes']
    assert report['data_Drive_receipt']['Drive_ID'] == '1Synbb3wxkYxhpYPtbERYVKwIWwbSpFze'
    frozen_slots = f['slots'][13:19]
    expected_ids = {s['record']['slot_id'] for s in frozen_slots}
    actual_ids = {n.split('/')[1] for n in data if n.startswith('ledger/')}
    assert len(frozen_slots) == 6 and actual_ids == expected_ids
    prior_dispatch_path = next((baseline / 'ledger').glob('*/dispatch.json'))
    prior_dispatch = json.loads(prior_dispatch_path.read_text())
    reported = {s['position']: s for s in report['slots']}
    assert set(reported) == set(range(14,20))
    results = []
    previous_end = None
    for slot in frozen_slots:
        rec, pack = slot['record'], slot['pack']
        prefix = 'ledger/' + rec['slot_id'] + '/'
        dispatch = json.loads(data[prefix+'dispatch.json'])
        result = json.loads(data[prefix+'result.json'])
        resource = json.loads(data[prefix+'resource_observation.json'])
        prompt, answer = data[prefix+'prompt.txt'], data[prefix+'answer.txt']
        assert prompt == pack['prompt'].encode('utf-8')
        assert sha(prompt) == rec['prompt_sha256'] == pack['prompt_sha256'] == dispatch['prompt_sha256']
        assert sha(config_bytes) == rec['config_file_sha256'] == dispatch['config_sha256']
        assert dispatch['configuration'] == pack['configuration'] == requested
        assert dispatch['frozen_inputs_sha256'] == sha(data['executor/frozen_inputs.json'])
        assert dispatch['position'] == rec['position'] == result['position'] == resource['position']
        assert dispatch['order'] == rec['order']
        assert dispatch['arm'] == rec['arm'] == pack['arm']
        assert dispatch['slot_id'] == rec['slot_id'] == pack['slot_id'] == result['slot_id'] == resource['slot_id']
        assert dispatch['cli_version'] == prior_dispatch['cli_version']
        assert dispatch['binary_sha256'] == prior_dispatch['binary_sha256']
        assert dispatch['safe_environment_overrides']['OPENCODE_EXPERIMENTAL_OUTPUT_TOKEN_MAX'] == '64000'
        cmd = dispatch['command']
        assert cmd[cmd.index('--model')+1] == 'zhipuai-coding-plan/glm-5.3'
        assert cmd[cmd.index('--format')+1] == 'json'
        assert '--pure' in cmd and dispatch['stdin_file'] == 'prompt.txt'
        assert not dispatch['fixture_only'] and not result['fixture_only']
        assert sha(answer) == result['answer_sha256'] and len(answer) == result['answer_bytes']
        assert result['cli_process_started'] and result['requested_timeout_seconds'] == 900
        assert not result['capture_issues'] and result['wall_seconds'] > 0
        assert result['scientific_validity'] == 'not_evaluated'
        if result['client_state'] == 'timeout':
            category = 'timeout_empty'
            assert result['exit_code'] == -9 and not answer and result['finish_reasons'] == []
            assert 900 <= result['wall_seconds'] < 901
            assert all(v is None for v in result['cli_reported_tokens'].values())
            assert result['cli_reported_usage_records'] == []
            assert resource['explicit_client_timeout_is_failure'] is True
        else:
            category = 'stop_nonempty'
            assert result['client_state'] == 'exited' and result['exit_code'] == 0
            assert result['finish_reasons'] == ['stop'] and len(answer) > 0
            assert result['wall_seconds'] < 900
            assert resource['explicit_client_timeout_is_failure'] is False
        assert result['provider_usage'] is None and result['provider_cost'] is None
        assert result['physical_http_attempts'] is None and result['provider_outcome'] == 'unknown'
        assert resource['model_capture_wall_seconds'] == result['wall_seconds']
        assert resource['local_inclusive_wall_seconds'] >= result['wall_seconds']
        assert resource['historical_balance_or_whole_CPU_cap_certified'] is False
        assert resource['provider_CPU_seconds'] is None
        r = reported[result['position']]
        for key in ('slot_id','client_state','exit_code','finish_reasons','answer_bytes','answer_sha256','capture_issues','cli_reported_tokens','wall_seconds'):
            assert r[key] == result[key]
        assert r['original_order'] == rec['order'] and r['arm'] == rec['arm']
        start = dispatch['dispatch_boundary_utc_seconds']
        if previous_end is not None:
            assert start >= previous_end - 0.1
        previous_end = start + result['wall_seconds']
        results.append({'position':result['position'],'slot_id':result['slot_id'],
                        'category':category,'answer_bytes':len(answer),'answer_sha256':sha(answer),
                        'wall_seconds':result['wall_seconds'],'exit_code':result['exit_code'],
                        'finish_reasons':result['finish_reasons'],'CLI_reported_tokens':result['cli_reported_tokens'],
                        'prompt_sha256':sha(prompt)})
    counts = collections.Counter(x['category'] for x in results)
    assert counts == {'stop_nonempty':4,'timeout_empty':2}
    assert report['terminal_count'] == 6 and report['client_successes'] == 4
    assert report['nonempty_public_answers'] == 4 and report['explicit_client_timeout_failures'] == 2
    assert report['empty_public_answer_terminals'] == [18,19]
    assert report['length_finish_terminals'] == [] and report['other_client_terminals'] == 0
    assert report['admissions_scores_heldout_performed'] is False
    # These are already reviewed history summaries, not a re-audit of older batches.
    prior1 = json.loads((args.prior_reviews/'p2_minimal_batch1_review/REVIEW.json').read_text())
    prior2 = json.loads((args.prior_reviews/'p2_minimal_batch2_review/REVIEW.json').read_text())
    assert prior1['CLI_terminal_successes'] == 6 and prior2['nonempty_public_answers'] == 4
    cumulative = {'positions_2_to_19_terminal':18,'positions_2_to_19_nonempty':14,
                  'P2_including_previously_reviewed_first_slot_terminal':19,
                  'P2_nonempty':15,'P2_length_empty':1,'P2_client_timeout_empty':3,
                  'original_132_logical_generation_terminal':91,
                  'historical_first_slot_and_batches_reused_not_reexecuted':True}
    output = {'status':'PASS_targeted_generation_archive_review','scope':'positions 14-19 only',
              'archive_member_hashes':40,'data_archive':dmeta,'audit_archive':ameta,'slots':results,
              'frozen_inputs_runner_and_config_equal_previously_reviewed':True,
              'six_prompt_bytes_equal_original_frozen_pack':True,'configuration':requested,
              'recorded_native_CLI_binary_and_version_equal_prior':True,
              'serial_dispatch_timing_consistent_with_recorded_durations':True,
              'nonempty_public_answers':4,'CLI_exit_zero':4,'length_empty':0,'client_timeout_empty':2,
              'cumulative_using_previously_reviewed_history':cumulative,
              'scientific_admission_or_scoring_performed':False,'candidate_code_executed':False,
              'provider_request_body_or_usage_independently_verified':False,
              'historical_resource_full_cap_certification':False,
              'post_disconnection_execution_recovery_verified':False,
              'notes':'Read-only archived byte/record check. No candidate, runner or collector execution. CLI tokens are self-reported, not provider usage/cost evidence. Archive ledger/current-process status is a historical snapshot and does not establish execution recovery after the reported 09:14 disconnection.',
              'cpu_seconds':time.process_time()-started}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(output,ensure_ascii=False,indent=2))

if __name__ == '__main__':
    main()
