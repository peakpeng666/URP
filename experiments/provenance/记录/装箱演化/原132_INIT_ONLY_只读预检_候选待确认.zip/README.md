# INIT-only生产前只读预检：文件通过，排他事实待确认

40/40文件、身份、源pin及停点状态检查通过。核验r2 FILE_MANIFEST SHA `7740fa3e61f845a4a392c5556a804c2bd8842fade2f2f8e0134b8542cc236d44`，开发grant exact SHA `c24e15941c1a9caa4c6583e3ba14e5bd9b981c9b187349b5531a24f60c7ccff8`，父给定六源全部在原路径精确匹配。

原producer/journal仍只有00–04五对confirmed intent/receipt和原lock，无额外helper、orphan、assembly、payload、commit、archive、GEN或bridge活动。pending原SHA、kind=index/prior=-1/null新建identity保持。历史真实create的原两ID/v0、冻结index859B/archive478B、原INIT grant、stop ZIP/error/create记录及旧26源pin一致。45个原生产文件与此前baseline及本轮前后快照完全相同。

旧实现目录包含原已批准的诊断测试和文档。它们在原INIT grant绑定的完整包MANIFEST SHA `abcb6ea4d3fd940d6be7595a6ba2db2647193bf0f1cf8e3755d30370ec243b19` 中，22成员均精确匹配；不是新添加的可执行源码，运行allowlist仍只含原7文件。初次把全部非operating文件视作额外文件的过严检查已按完整manifest纠正，原记录保全在 `audit/first_pass`；未删改原文件。

可见进程两次观测均无该namespace写入FD，原lock可用。活动agent树只有/root；9个历史子进程已是僵尸，不再执行。dockerd/containerd两个基础进程FD无法读取，额外只读检查仍没有扩大可见性。因此本轮只报告“未观察到并行写入”，不把快照夸大为已证明全局唯一操作者。父要求在预检通过后才能生成候选，所以当前等待唯一应用操作者/无其他外部并行写入的事实确认；`INIT_ONLY_BINDING.CANDIDATE.json` 和enabled activation均未创建。

确认后将只新增禁用候选：保留原开发grant全部字段及原全文，附预检证据、精确SHA、未来activation路径，execution_granted=false和independent_review_accepted=false保持。仍须父独立接受绑定后，才能另建启用activation；本轮没有执行批准。预期路径在 `BINDING_STATUS.json`，固定生产namespace和未来.namespace-recovery没有创建或换路径。

两次独立预检进程已知SELF checkpoint合计0.117409 s，非重叠local窗口合计约0.084665251 s。原5条观测SELF 0.225943 s /local窗口0.174136459 s只读取复核，未重测替换。自己的其他工具/assistant/Drive/打包成本、启动前wall和checkpoint后尾部未全量计量，继续unknown。此预检为独立工程证据，未写入或冒充原生产账本；预算仍原60 SELF/240 local-wall，new_budget=false，无完整CPU上界声明。

未调用recoverSuffix、recovery CLI、旧INIT/helper/assembler、Library读写、OpenCode/模型、GEN；未修改源码、旧grant、pending、权限或网络策略。唯一写入是本新预检证据目录和被授权的私有Drive交付。

主要证据：PREFLIGHT_READ_ONLY.json、SOURCE_PINS.json、PRODUCTION_BEFORE/AFTER.json、PROCESS_SNAPSHOTS.json、两次成本checkpoint及原grant exact-byte副本。standalone `readonly_precheck.py` 只用标准库读取/校验，没有导入或运行仓库代码。
