#!/usr/bin/env python3
"""Build only safe generation artifacts; never walk slot runtime directories."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path('/workspace/urp132-minimal-generation-r1')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def raw_json(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()


def write_zip(path, members):
    manifest = {name: {'bytes': len(raw), 'sha256': sha(raw)} for name, raw in members.items()}
    with zipfile.ZipFile(path, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as output:
        for name, raw in members.items():
            output.writestr(name, raw)
        output.writestr('FILE_MANIFEST.json', raw_json(manifest))
    with zipfile.ZipFile(path) as check:
        assert check.testzip() is None
        assert all(sha(check.read(name)) == row['sha256'] for name, row in manifest.items())
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes()),
            'members': len(members) + 1, 'member_hashes_verified': len(members)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--start', type=int, required=True)
    parser.add_argument('--end', type=int, required=True)
    parser.add_argument('--dataset-receipt', type=Path)
    args = parser.parse_args()
    assert 2 <= args.start <= args.end <= 60
    inputs_raw = (ROOT / 'executor/frozen_inputs.json').read_bytes()
    assert sha(inputs_raw) == '52f1505c9bab0ef6a821be8a28564b8ee601a66d20bbe17e918226bb5719865f'
    frozen = json.loads(inputs_raw)
    directory = ROOT / 'remaining59' / 'archives' / f'positions_{args.start:02d}_{args.end:02d}'
    directory.mkdir(parents=True, exist_ok=True)
    report = {'positions': [args.start, args.end], 'terminal_count': args.end - args.start + 1,
              'unique_persistent_ledger': str(ROOT / 'ledger'),
              'generation_revision': 'minimal-local-execution-r1',
              'runner_SHA256': 'e642b00b208330612cc5b13d842508312420c228ff31962ac80b0b60eec73f73',
              'frozen_inputs_SHA256': sha(inputs_raw), 'configuration': frozen['freeze']['configuration'],
              'client_successes': 0, 'explicit_client_timeout_failures': 0, 'other_client_terminals': 0,
              'nonempty_public_answers': 0, 'empty_public_answer_terminals': [],
              'length_finish_terminals': [],
              'slots': [], 'provider_usage': None, 'provider_cost': None,
              'physical_HTTP_attempts': None, 'provider_quota_remaining': None,
              'provider_terminal_and_cancellation': 'unknown',
              'admissions_scores_heldout_performed': False,
              'historical_costs_and_old_HALT_not_reset': True,
              'runtime_HOME_XDG_auth_cache_logs_included': False,
              'credential_value_read_or_saved': False}
    report['authoritative_original_slot_directories_present'] = sum(
        (ROOT / 'ledger' / s['pack']['slot_id']).exists() for s in frozen['slots'])
    report['authoritative_remaining_unstarted'] = sum(
        not (ROOT / 'ledger' / s['pack']['slot_id']).exists() for s in frozen['slots'][1:])
    report['status_snapshot_counter_note'] = (
        'The controller prelaunch remaining counter may include its active slot; '
        'permanent ledger directories determine actual unstarted slots.')
    members = {'executor/frozen_inputs.json': inputs_raw,
               'executor/runner.py': (ROOT / 'executor/runner.py').read_bytes(),
               'frozen_requested_configuration.raw.json': frozen['config_raw'].encode(),
               'COLLECTION_RECORD.json': (ROOT / 'remaining59/COLLECTION_RECORD.json').read_bytes()}
    assert sha(members['executor/runner.py']) == report['runner_SHA256']
    for position in range(args.start, args.end + 1):
        item = frozen['slots'][position - 1]
        slot = item['pack']['slot_id']
        folder = ROOT / 'ledger' / slot
        # This explicit allowlist is the only access to a slot folder.
        for name in ('prompt.txt', 'dispatch.json', 'result.json', 'answer.txt', 'resource_observation.json'):
            members[f'ledger/{slot}/{name}'] = (folder / name).read_bytes()
        result = json.loads(members[f'ledger/{slot}/result.json'])
        dispatch = json.loads(members[f'ledger/{slot}/dispatch.json'])
        answer = members[f'ledger/{slot}/answer.txt']
        assert sha(answer) == result['answer_sha256'] and len(answer) == result['answer_bytes']
        assert sha(members[f'ledger/{slot}/prompt.txt']) == item['pack']['prompt_sha256']
        assert dispatch['configuration'] == frozen['freeze']['configuration']
        assert dispatch['position'] == result['position'] == position
        assert dispatch['binary_sha256'] == frozen['freeze']['cli_binary_sha256']
        row = {key: result.get(key) for key in ('position', 'slot_id', 'client_state', 'exit_code',
               'wall_seconds', 'answer_bytes', 'answer_sha256', 'finish_reasons', 'capture_issues',
               'cli_reported_tokens', 'cli_reported_usage_records')}
        row['original_order'] = item['record']['order']
        row['arm'] = item['record']['arm']
        report['slots'].append(row)
        if len(answer):
            report['nonempty_public_answers'] += 1
        else:
            report['empty_public_answer_terminals'].append(position)
        if 'length' in result['finish_reasons']:
            report['length_finish_terminals'].append(position)
        if result['client_state'] == 'timeout':
            report['explicit_client_timeout_failures'] += 1
        elif result['client_state'] == 'exited' and result['exit_code'] == 0 and not result['capture_issues'] and result['finish_reasons']:
            report['client_successes'] += 1
        else:
            report['other_client_terminals'] += 1
    name = f'urp132_P2_minimal_r1_positions_{args.start:02d}_{args.end:02d}'
    if args.dataset_receipt is None:
        metadata = write_zip(directory / f'{name}_data.zip', members)
        metadata['parent_folder_id'] = '129-0z2ejXZg2rAkJe_Yxz876foi5mTy6'
        (directory / 'DATA_ARCHIVE.json').write_bytes(raw_json(metadata))
        (directory / 'BATCH_REPORT.json').write_bytes(raw_json(report))
    else:
        report['data_archive'] = json.loads((directory / 'DATA_ARCHIVE.json').read_bytes())
        report['data_Drive_receipt'] = json.loads(args.dataset_receipt.read_bytes())
        report_members = {'BATCH_REPORT.json': raw_json(report),
                          'COLLECTION_RECORD.json': (ROOT / 'remaining59/COLLECTION_RECORD.json').read_bytes(),
                          'COLLECTOR.py': (ROOT / 'collect_remaining.py').read_bytes(),
                          'ARCHIVER.py': Path(__file__).read_bytes(),
                          'STATUS_SNAPSHOT.json': (ROOT / 'remaining59/status.json').read_bytes(),
                          'FIRST_SLOT_VERIFICATION_REFERENCE.json': (ROOT / 'FIRST_SLOT_VERIFICATION.json').read_bytes()}
        for member_name, path in (
            ('CONTINUATION_CONTROLLER.py', ROOT / 'continue_unstarted50.py'),
            ('TRANSPORT_RECOVERY_CONTINUATION.json', ROOT / 'remaining59/TRANSPORT_RECOVERY_CONTINUATION.json'),
            ('CONTINUATION_CONTROL_SESSION.json', ROOT / 'remaining59/CONTINUATION_CONTROL_SESSION.json')):
            if path.is_file():
                report_members[member_name] = path.read_bytes()
        metadata = write_zip(directory / f'{name}_audit.zip', report_members)
        metadata['parent_folder_id'] = '1LfnXbRzcZlr59nZEotn0QE6mnbvT7Hhm'
        (directory / 'AUDIT_ARCHIVE.json').write_bytes(raw_json(metadata))
    print(json.dumps(metadata))


if __name__ == '__main__':
    main()
