#!/usr/bin/env python3
"""Continue only the reconciled, unstarted original positions 50..60."""
import importlib.util
import json
import time
from pathlib import Path

ROOT = Path('/workspace/urp132-minimal-generation-r1')
spec = importlib.util.spec_from_file_location('serial_collection', ROOT / 'collect_remaining.py')
collection = importlib.util.module_from_spec(spec)
spec.loader.exec_module(collection)
runner = collection.runner


def main():
    data = runner.load_inputs()
    if runner.digest((ROOT / 'executor/runner.py').read_bytes()) != collection.RUNNER_SHA:
        raise ValueError('Approved runner changed')
    if collection.journal_sha() != collection.OLD_JOURNAL_SHA or any((collection.OLD / 'dispatch-fences').iterdir()):
        raise ValueError('Old production changed')
    measurements = []
    for position, item in enumerate(data['slots'][:49], 1):
        folder = collection.LEDGER / item['pack']['slot_id']
        result = json.loads((folder / 'result.json').read_bytes())
        if collection.launch_abnormality(result):
            raise ValueError('Earlier client terminal requires review')
        if runner.digest((folder / 'prompt.txt').read_bytes()) != item['pack']['prompt_sha256']:
            raise ValueError('Original prompt changed')
        if position > 1:
            measurements.append(json.loads((folder / 'resource_observation.json').read_bytes()))
    if any((collection.LEDGER / s['pack']['slot_id']).exists() for s in data['slots'][49:]):
        raise ValueError('A continuation slot already exists; never replay')
    prior_status = json.loads((collection.REPORTS / 'status.json').read_bytes())
    record = {'reason': 'Original unified exec transport disconnected and its session could not resume.',
              'original_collector_observed_not_running': True,
              'active_OpenCode_observed': 0, 'earlier_terminal_positions': [1, 49],
              'unresolved_slot_directories': [], 'original_unstarted_positions': [50, 60],
              'new_logical_CLI_launches_maximum': 11,
              'total_new_logical_CLI_launches_maximum_in_original_authorization': 59,
              'original_exec_session': 35987,
              'original_controller_final_SELF_measurement': None,
              'original_controller_exit_status': None,
              'same_approved_runner_SHA256': collection.RUNNER_SHA,
              'same_frozen_inputs_SHA256': runner.INPUT_SHA256,
              'same_unique_ledger': str(collection.LEDGER),
              'same_configuration': data['freeze']['configuration'],
              'same_resource_caps': collection.CAPS, 'no_old_HALT_INIT_or_claim_write': True,
              'prior_status_snapshot': prior_status,
              'credential_values_read_or_saved': False}
    runner.write_json(collection.REPORTS / 'TRANSPORT_RECOVERY_CONTINUATION.json', record)
    status = dict(prior_status)
    status.update(state='running', stop_reason=None, transport_reconciled=True,
                  original_controller_final_SELF_measurement=None,
                  original_controller_exit_status=None)
    started_cpu, started_wall = collection.cpu(), time.monotonic()
    prior_observed_cpu = sum(row['Python_SELF_seconds'] for row in measurements)
    stop = None
    for position in range(50, 61):
        known_cpu = collection.OLD_OBSERVED_CPU + prior_observed_cpu + collection.cpu() - started_cpu
        known_wall = collection.OLD_OBSERVED_LOCAL + collection.FIRST_OBSERVED_CAPTURE_WALL + sum(row['local_inclusive_wall_seconds'] for row in measurements)
        if known_cpu + collection.CAPS['slot_SELF_seconds'] > collection.CAPS['total_SELF_seconds']:
            stop = 'observed_total_SELF_budget_cannot_cover_next_original_slot'
            break
        if known_wall + collection.CAPS['slot_inclusive_wall_seconds'] > collection.CAPS['total_local_seconds']:
            stop = 'observed_total_local_budget_cannot_cover_next_original_slot'
            break
        status.update(current_position=position)
        collection.save_status(status)
        before_cpu, before_wall = collection.cpu(), time.monotonic()
        try:
            result = runner.run_one(data, collection.LEDGER, position, [collection.BINARY])
        except Exception as error:
            stop = 'dispatch_or_persistence_exception:' + type(error).__name__
            break
        measurement = {'position': position, 'slot_id': result['slot_id'],
                       'Python_SELF_seconds': round(collection.cpu() - before_cpu, 6),
                       'local_inclusive_wall_seconds': round(time.monotonic() - before_wall, 6),
                       'model_capture_wall_seconds': result['wall_seconds'],
                       'historical_balance_or_whole_CPU_cap_certified': False,
                       'provider_CPU_seconds': None,
                       'explicit_client_timeout_is_failure': result['client_state'] == 'timeout',
                       'server_outcome_and_cancellation': 'unknown'}
        runner.write_json(collection.LEDGER / result['slot_id'] / 'resource_observation.json', measurement)
        measurements.append(measurement)
        status['new_terminal_positions'].append(position)
        status['remaining_unstarted'] = 60 - position
        stop = collection.launch_abnormality(result)
        if measurement['Python_SELF_seconds'] > collection.CAPS['slot_SELF_seconds']:
            stop = 'observed_slot_SELF_budget_exceeded'
        if measurement['local_inclusive_wall_seconds'] > collection.CAPS['slot_inclusive_wall_seconds']:
            stop = 'observed_slot_local_budget_exceeded'
        if stop:
            break
        if len(status['new_terminal_positions']) % 6 == 0:
            collection.save_status(status)
            print(json.dumps({'event': 'six_new_terminals',
                              'positions': status['new_terminal_positions'][-6:],
                              'new_terminal_count': len(status['new_terminal_positions'])}), flush=True)
    status.update(state='stopped' if stop else 'completed', stop_reason=stop,
                  continuation_observed_SELF_seconds=round(collection.cpu() - started_cpu, 6),
                  continuation_elapsed_wall_seconds=round(time.monotonic() - started_wall, 6),
                  measurements=measurements, full_remaining_SELF_budget_seconds=None,
                  full_remaining_local_budget_seconds=None,
                  old_journal_unchanged=collection.journal_sha() == collection.OLD_JOURNAL_SHA,
                  old_dispatch_fence_entries=len(list((collection.OLD / 'dispatch-fences').iterdir())))
    status['remaining_unstarted'] = sum(not (collection.LEDGER / s['pack']['slot_id']).exists() for s in data['slots'][1:])
    collection.save_status(status)
    print(json.dumps({'event': status['state'], 'new_terminal_count': len(status['new_terminal_positions']),
                      'remaining_unstarted': status['remaining_unstarted'], 'stop_reason': stop}), flush=True)


if __name__ == '__main__':
    main()
