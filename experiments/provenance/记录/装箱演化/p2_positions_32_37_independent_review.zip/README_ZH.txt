原132主线 P2 第六批32–37：独立只读归档核验
2026-10-07 12:14 UTC

两个ZIP共40项manifest内容hash及CRC通过。6份prompt均与原冻结pack逐字节一致，原runner/frozen_inputs/配置原文与前批基线一致，记录的CLI版本/binary pin及串行dispatch一致。仍GLM-5.3/high、max64000、temperature0.7、top_p0.9、900秒、tools=false、outer_retries=0，无按量付费fallback。

32–37六项正常stop、非空输出，分别720/1563/1054/844/1275/710字节；无新增length空或timeout。复用原首槽和前五批，累计P2前37/60生成终态，30非空、1length空、6timeout空；原计划109/132逻辑终态。非空或exit0并不等于科学准入/评分通过。

Drive createdTime及modifiedTime：data均2026-10-07T12:07:29.514Z，audit均12:08:14.130Z。比仅看上传时间更直接的证据是原dispatch：33–37分别在11:16:23.307759、11:27:01.918986、11:38:04.913797、11:51:53.114648、11:59:12.856307 UTC开始且都有终态；原32在11:06:19开始、按记录wall在11:16:23结束。已证明11:15断连后有实际生成推进，不能继续将旧“尚无推进证据”视为最新状态。包内slot38 running仍只是归档时快照，不证明目前活进程。snapshot剩余23含活动槽，按38个永久目录尚未启动为22，口径原样保留。

本审计仅读取档案；没有执行候选、runner、collector或数值评分，没有新建stage或向生成器反馈。此前独审公开评分范围为前31，本小包不声称32–37已评分。provider原始请求体、HTTP次数、usage/扣费及全历史预算余额没有获得认证；CLI token为自报。审核CPU约0.01900秒，不含后续打包/归档。

原data/audit ZIP仅引用，不重复上传；真实链接、大小、SHA和metadata时间见SOURCE_REFERENCES.json。复核脚本、结果、说明和4项hash清单构成此5文件小包。
