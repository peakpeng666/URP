"""Rebind only independent64k copies; never activate, mutate originals, or run a producer."""
import sys
sys.dont_write_bytecode=True
import copy,json,hashlib,pathlib,difflib
N=pathlib.Path(__file__).resolve().parent
ORIG=pathlib.Path('/workspace/original132-phase2-import-20261006-ba1y1szn/extracted/original132_phase2_continuation_draft_20261006')
OLD=pathlib.Path('/workspace/original132-fresh-p1-head-disabled-r2-20261006-men6wl9t')
PREP=pathlib.Path('/workspace/original132-p2-budget64k-preparation-20261007-396h9f1c')
W=pathlib.Path('/workspace/original132-phase2-producer-20261006')
R=pathlib.Path('/workspace/original132-phase2-recovery-dev-20261006-8sdu8cov/revision2')
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_bytes())
def ref(p):return {'path':str(p),'file_sha256':sha(p.read_bytes())}
def put(p,v):p.write_bytes(canon(v));return ref(p)
def seal(v):return dict(v,sha256=sha(canon({k:x for k,x in v.items() if k!='sha256'})))
P=N/'package';a_ref=ref(PREP/'BUDGET_AMENDMENT.CANDIDATE.json')
policy=ref(N/'data/FORWARD_COORDINATION_POLICY.64k.CANDIDATE.json');account=ref(N/'data/RESOURCE_ACCOUNTING_BINDING.64k.CANDIDATE.json');supp=ref(N/'data/INCLUSIVE_ACCOUNTING_SUPPLEMENT.64k.CANDIDATE.json')
lineage=read(ORIG/'LINEAGE.json');lineage.update(resource_accounting_binding_sha256=account['file_sha256'],output_budget_amendment_ref=a_ref,completion_budget_by_phase={'P0_P1':32000,'P2':64000});lineage=seal(lineage);put(P/'LINEAGE.json',lineage)
sources={'src/'+p.name:sha(p.read_bytes()) for p in (N/'exporter/src').glob('*') if p.suffix in ['.py','.js']}
fr=read(PREP/'draft/freeze.64k.CANDIDATE.json');fr.update(lineage_sha256=lineage['sha256'],exporter_source_sha256=sha(canon(sources)),cli_exporter_source_sha256=sha(canon(sources)),status='DISABLED_64K_IMPLEMENTED_PENDING_INDEPENDENT_REVIEW');fr=seal(fr);put(P/'inputs/freeze.json',fr)
rows=[];mapping=[]
for row in read(ORIG/'inputs/roster.json')['records']:
 slot=row['slot_id'];oldpack=read(ORIG/'inputs/packs'/f'{slot}.json');oldclaim=read(ORIG/'inputs/uncommitted-claims'/f'{slot}.json')
 pack=copy.deepcopy(oldpack);pack['configuration']['max_completion_tokens']=64000;pack['configuration_sha256']=sha(canon(pack['configuration']));pack['freeze_sha256']=fr['sha256'];pack=seal(pack)
 claim=copy.deepcopy(oldclaim);claim.update(request_sha256=pack['sha256'],freeze_sha256=fr['sha256']);claim=seal(claim)
 put(P/'inputs/packs'/f'{slot}.json',pack);put(P/'inputs/uncommitted-claims'/f'{slot}.json',claim)
 newrow=copy.deepcopy(row);newrow.update(request_sha256=pack['sha256'],claim_sha256=claim['sha256'],freeze_sha256=fr['sha256'],config_file_sha256=fr['config_file_sha256']);rows.append(newrow)
 assert pack['prompt']==oldpack['prompt'] and pack['parents']==oldpack['parents'] and pack['serialized_messages_sha256']==oldpack['serialized_messages_sha256'] and claim['claim_id']==oldclaim['claim_id']
 mapping.append({'slot_id':slot,'position':row['position'],'arm':row['arm'],'old_request_sha256':row['request_sha256'],'new_request_sha256':pack['sha256'],'old_claim_sha256':row['claim_sha256'],'new_claim_sha256':claim['sha256'],'prompt_sha256_unchanged':row['prompt_sha256'],'claim_id_unchanged':row['claim_id'],'parent_list_unchanged':True,'parents':row['parents']})
roster=read(ORIG/'inputs/roster.json');roster.update(freeze_sha256=fr['sha256'],records=rows);roster=seal(roster);put(P/'inputs/roster.json',roster)
scope=read(N/'data/RESOURCE_SCOPE.64k.CANDIDATE.json');put(P/'RESOURCE_SCOPE.json',scope)
plan=read(ORIG/'PLAN.json');plan.update(freeze_sha256=fr['sha256'],roster_sha256=roster['sha256'],lineage_sha256=lineage['sha256'],resource_accounting_binding_sha256=account['file_sha256'],resource_scope_sha256=scope['sha256'],output_budget_amendment_ref=a_ref,completion_budget_protocol='P2_64k_mixed_budget_continuation');plan=seal(plan);put(P/'PLAN.json',plan)
bd=read(ORIG/'BINDINGS.json');bd.update(generation_freeze_sha256=fr['sha256'],resource_accounting_binding_sha256=account['file_sha256'],output_budget_amendment_ref=a_ref);put(P/'BINDINGS.json',seal(bd))
head=read(W/'index.initial.json');head['freeze_sha256']=fr['sha256'];head=seal(head);put(P/'inputs/index.budget64k.CANDIDATE.json',head)
gate=read(OLD/'BRIDGE_GATE.CANDIDATE.json');gate.update(freeze_sha256=fr['sha256'],roster_sha256=roster['sha256'],plan_sha256=plan['sha256'],resource_accounting_binding_sha256=account['file_sha256'],output_budget_amendment_ref=a_ref,output_budget_transition_ref=None,
 original_head_current_confirmed=False,authorized_request_sha256=[r['request_sha256'] for r in rows],authorized_slot_order=[r['slot_id'] for r in rows])
switch=copy.deepcopy(gate);switch['package_manifest_sha256']=None;put(P/'inputs/EXECUTION_SWITCH.json',switch)
manifest=read(P/'PACKAGE_MANIFEST.json');manifest['files']={k:sha((P/k).read_bytes()) for k in manifest['files']};manifest=seal(manifest);put(P/'PACKAGE_MANIFEST.json',manifest)
sys.path.insert(0,str(N/'references/generation'))
import durable_generation_sidecar as d
binding=d.inspect_contract(P,policy['path'],account['path'],ORIG.parent);bindingref=put(N/'consumer-contract.64k.CANDIDATE.json',binding)
gate['package_manifest_sha256']=manifest['sha256'];gateref=put(N/'BRIDGE_GATE.64k.CANDIDATE.json',gate)
mg=read(N/'MIGRATION_GRANT.64k.CANDIDATE.json');mg['source_pins']={k:sha(pathlib.Path(k).read_bytes()) for k in mg['source_pins']};mg['new_freeze_ref']=ref(P/'inputs/freeze.json');mg['new_config_ref']=ref(P/'inputs/config.raw.json');mgref=put(N/'MIGRATION_GRANT.64k.CANDIDATE.json',mg);put(N/'SOURCE_PINS.IMPLEMENTED.json',mg['source_pins'])
gen=read(OLD/'GEN_GRANT.CANDIDATE.json');gen.update(binding_sha256=bindingref['file_sha256'],bridge_gate_path=gateref['path'],bridge_gate_file_sha256=gateref['file_sha256'],inclusive_wall_supplement_path=supp['path'],inclusive_wall_supplement_file_sha256=supp['file_sha256'],
 authorized_request_sha256=[r['request_sha256'] for r in rows],authorized_slot_order=[r['slot_id'] for r in rows],operational_source_files=mg['source_pins'],output_budget_amendment_ref=a_ref,output_budget_transition_ref=None,output_budget_transition_grant_ref=mgref,
 entry_source_files={'protocol':str(N/'exporter/src/protocol_v2.py'),'capture':str(N/'exporter/src/capture_v2.py'),'driver':str(N/'exporter/src/driver_v2.py'),'bridge':str(P/'phase2_producer_bridge.py'),'status':gen['entry_source_files']['status']},
 entry_initial_head={'index_path':mg['new_index_path'],'index_file_sha256':sha(canon(head)),'receipt_path':str(W/'state/commits/libfile_d711508ec1888191ba87324ac424a529-1.json'),'receipt_file_sha256':None})
target=N/'references/generation/production_generation_entry.py'
gen['local_call_targets']={k:{'path':str(target),'sha256':sha(target.read_bytes()),'function':k} for k in d.LOCAL_STAGES}
gen['init_resource_import']['old_INIT_measurement_count']=46;gen['init_resource_import']['migration_measurement_refs']=None;gen['init_resource_import']['combined_measurement_count']=None
gen['note']='Disabled64k candidate. Original46 handoff retained. Migration receipt/new starting head SHA pending. No enabling fields may be flipped in place.'
genref=put(N/'GEN_GRANT.64k.CANDIDATE.json',gen)
contexts=read(OLD/'LIBRARY_CONTEXTS.CANDIDATE.json')
source_digest=sha(canon(mg['source_pins']));by_slot={r['slot_id']:r for r in rows}
for row in contexts['contexts']:
 ctx=row['context'];record=by_slot[ctx['slotId']]
 ctx['request_sha256']=record['request_sha256'];ctx['binding_sha256']=bindingref['file_sha256'];ctx['plan_sha256']=plan['sha256'];ctx['roster_sha256']=roster['sha256'];ctx['source_sha256']=source_digest
contexts['source_sha256']=source_digest
ctxref=put(N/'LIBRARY_CONTEXTS.64k.CANDIDATE.json',contexts)
composition=read(OLD/'GEN_COMPOSITION.CANDIDATE.json');composition['binding_ref']=bindingref;composition['context_ref']=ctxref;composition['generation_entry_ref']=ref(N/'src/production_generation_entry_64k.py');composition['GEN_grant_ref']=genref
composition['output_budget_transition_grant_ref']=mgref;composition['output_budget_transition_ref']=None
composition['output_budget_transition_bridge_ref']=ref(N/'src/budget_transition_bridge.js')
composition['paths'].update(grantPath=genref['path'],hooksCliPath=str(N/'generation/library_hooks_cli.py'),launcherPath=str(N/'generation/measured_local_helper.py'))
composition['accountingSupplementSha256']=supp['file_sha256'];composition['local_call_targets']=gen['local_call_targets']
# Rebind module references by actual basename into the independent generation root.
def route_refs(value):
 if isinstance(value,list):return [route_refs(x) for x in value]
 if isinstance(value,dict):
  result={k:route_refs(v) for k,v in value.items()}
  for field in ['path','scriptPath']:
   if isinstance(result.get(field),str):
    candidate=N/'generation'/pathlib.Path(result[field]).name
    if candidate.is_file():
     result[field]=str(candidate)
     for digest_key in ['sha256','file_sha256']:
      if digest_key in result:result[digest_key]=sha(candidate.read_bytes())
  return result
 return value
composition=route_refs(composition);put(N/'GEN_COMPOSITION.64k.CANDIDATE.json',composition)
put(N/'data/REQUEST_HASH_MAPPING.IMPLEMENTED64k.json',{'records':mapping,'new_freeze_ref':ref(P/'inputs/freeze.json'),'parent_tickets':sum(len(r['parents']) for r in rows),'status':'DISABLED_DERIVED_FILES_IMPLEMENTED'})
# Full byte diffs against original accepted sources, including the final launch guard.
for old,new in [(ORIG.parent/'original132_phase1_preparation_20261005/exporter/src/capture_v2.py',N/'exporter/src/capture_v2.py'),(ORIG/'phase2_producer_bridge.py',P/'phase2_producer_bridge.py'),(R/'references/generation/durable_generation_sidecar.py',N/'references/generation/durable_generation_sidecar.py'),(R/'src/production_generation_entry_v2.py',N/'src/production_generation_entry_64k.py')]:
 (N/'patches'/f'{new.name}.patch').write_text(''.join(difflib.unified_diff(old.read_text().splitlines(True),new.read_text().splitlines(True),fromfile=str(old),tofile=str(new))))
print(canon({'freeze':fr['sha256'],'GEN':genref,'gate':gateref,'source_pins':len(mg['source_pins']),'requests':60,'contexts':len(contexts['contexts']),'disabled':True}).decode())
