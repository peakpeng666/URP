# P2 64000：独立实现与离线证明，全部生产开关关闭

这份材料实现已确认的剩余60条 P2 请求预算补充。模型仍为 glm-5.3，high，temperature=0.7，top_p=0.9，steps=2，tools=false，900秒，outer_retries=0；唯一端点是 https://open.bigmodel.cn/api/coding/paas/v4。原72条与失败均保留，两个实验臂各30条、78个父票据及提示内容未变。未运行 OpenCode、模型推理、真实迁移、INIT 或数值/heldout任务。

## 审阅入口

- `IMPLEMENTATION_REPORT.json`：最终状态、当前freeze/文件引用、剩余动作。
- `patches/`：三个模块族的最小差异及单独的新GEN bootstrap适配。
- `src/budget_transition.py` / `src/budget_transition_bridge.js`：一次空索引版本迁移；工具意图/结果、原四个本地helper和全部可观测Python记录均持久化；未知结果停止，不重试、不手动清除fence。
- `GEN_GRANT.64k.CANDIDATE.json` / `BRIDGE_GATE.64k.CANDIDATE.json` / `MIGRATION_GRANT.64k.CANDIDATE.json`：禁用草案。真实新head receipt SHA与真实transition ref均未填，不能开启。原INIT handoff没有被改为新head。
- `audit/OFFLINE_TEST_RESULTS.json`：8项检查通过；完整的首轮和重入结果、原helper意图/结果及资源记录在选定 `fixtures/` 中。Library回复是明确TEST_ONLY替身，原本地fence/xattr/receipt helpers确实在隔离目录执行。SDK getArgs 与原输出min函数来自冻结二进制，离线执行得到 max_tokens=64000；没有调用doGenerate/doStream或观察HTTP请求。
- `audit/IMMUTABLE_REFERENCE_BYTE_MAP.json`：为跨环境审阅提供旧运行源文件与151份真实生产/INIT/recovery文件的字节快照，映射原绝对路径与ZIP成员。不是重新生成的生产回执。456项外部依赖保持原有hash引用，既有生产baseline必须继续使用。

## 预算与身份

新CLI仅额外白名单 `OPENCODE_EXPERIMENTAL_OUTPUT_TOKEN_MAX=64000`；所有继承 OPENCODE_* 仍清除。模型limit.output与配置预算也恰为整数64000。配置只含 `{env:ZHIPU_API_KEY}` 引用，未读回、展示、记录或哈希真实密钥。

同一P2索引 libfile_d711508ec1888191ba87324ac424a529 只计划一次CAS，从原v0/旧freeze到新freeze/v1。478字节初始archive只有 file-hashes.json 与 phase2 slots=[] 的wave-manifest，没有freeze/config字段，保持原v0与字节，无需迁移。新GEN bootstrap严格验证原46条真实INIT记录，再导入实际迁移新增测量；可信离线成功例为46+22=68，始终使用原SELF 60秒/local-window 240秒 init-final池，未重新执行INIT。JS/Library/provider CPU与wait、所有未观测尾部保持unknown；不声明完整CPU上界。

## 后续必须分两步批准

先独立审阅本包精确hash链和协议，再按真实最新的原索引/原backing读取证据批准一次迁移。前一份原索引读取证据时间为2026-10-07 01:22:05–01:22:09 UTC，两个native version_id均null；v0来自原真实receipt，不能说native读回了v0。实际迁移应保留原0回执与新1回执，实测迁移增量并入同一池。

只有真实迁移已确认后，才在另行审阅的GEN授权中绑定真实transition、当前新head文件和实际receipt的精确SHA，并取得原P1干净head的新确认。不要把本包TEST_ONLY回执当真实回执，也不要直接翻转草案布尔开关。套餐/服务器对实际请求的接受尚未观察；不明确时停止，不尝试标准付费端点或其他provider。

上一个禁用的数据补充包： https://drive.google.com/file/d/1Zl3OIVncniQa89yNzJ-UBOX-2DoyWq7Z/view 。本包派生freeze已经包含最终source/lineage约束，因此以IMPLEMENTATION_REPORT.json的当前freeze与refs为审阅对象，保留旧包不覆盖。
