'use strict';
const fs=require('fs'),path=require('path'),cp=require('child_process');
const root=path.resolve(process.argv[2]),scenario=process.argv[3]||'success',config=JSON.parse(fs.readFileSync(root+'/fixture-config.json'));
const {migrateBudget64k}=require(config.bridgePath);
const grant=JSON.parse(fs.readFileSync(config.grantRef.path));let writes=0,reads=0;
const subprocesses=[];
const reply=obj=>({content:[{type:'text',text:'TEST_ONLY fixture'}],structuredContent:obj,isError:false,TEST_ONLY:true});
const item={status:'succeeded',library_file_id:grant.index_library_file_id,file_id:'file_TEST_ONLY_budget64k_version1',
 current_version_number:1,file_name:'index.budget64k.proposed.json',xattrs:[]};
const rawTools={
 async exec_command(args){
  if(!args.cmd.startsWith('python3 -I '+("'"+config.corePath+"'")))throw new Error('TEST_ONLY forbids every non-migration executable');
  const result=cp.spawnSync('bash',['-c',args.cmd],{encoding:'utf8',env:{PATH:'/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin:/usr/bin:/bin'},maxBuffer:1024*1024});
  subprocesses.push({exit_code:result.status,action:args.cmd.includes(' helper -- ')?'original_pinned_helper':'migration_control',error:result.status===0?null:result.stderr.slice(-2400)});
  return {exit_code:result.status,output:result.stdout+(result.status===0?'':result.stderr)};
 },
 async mcp__codex_apps__library_replace_library_file(args){
  writes++;if(writes>1)throw new Error('TEST_ONLY external write replay');
  if(scenario==='write_unknown')return {isError:true,structuredContent:{status:'unknown'},TEST_ONLY:true};
  if(scenario==='wrong_identity')return reply({...item,library_file_id:'libfile_TEST_ONLY_wrong'});
  if(scenario==='wrong_version')return reply({...item,current_version_number:2});
  return reply(item);
 },
 async mcp__codex_apps__library_read(args){
  reads++;const target=args.read[0].ref_id;let data=fs.readFileSync(grant.new_index_path,'utf8');
  if(scenario==='wrong_readback')data=data.replace('"rows":[]','"rows":[{}]');
  return reply({results:[{library_file_id:item.library_file_id,file_id:item.file_id,ref_id:target,
    has_more:false,version_id:scenario==='stale_read_version'?0:1,warnings:[],content:[data]}],warnings:[]});
 },
 async mcp__codex_apps__library_search(){return reply({results:[]})},
 async apply_patch(patch){
  const lines=patch.trimEnd().split('\n');if(lines[0]!=='*** Begin Patch'||!lines[1].startsWith('*** Add File: '))throw new Error('TEST_ONLY patch shape');
  const dest=lines[1].slice('*** Add File: '.length);if(!dest.startsWith(grant.producer_workspace+'/state/readback-'))throw new Error('TEST_ONLY patch path');
  const b=lines.slice(2,-1).map(x=>{if(!x.startsWith('+'))throw new Error('patch line');return x.slice(1)}).join('\n')+'\n';
  fs.writeFileSync(dest,b,{flag:'wx'});return {isError:false};
 }
};
(async()=>{
 let result,failed=false,errorType;
 try{result=await migrateBudget64k(rawTools,config)}
 catch(error){failed=true;errorType=String(error.message).slice(0,180)}
 const report={TEST_ONLY:true,scenario,success:!failed,error:errorType??null,result:result??null,writes,reads,
   native_external_calls:0,model_calls:0,OpenCode_launches:0,INIT_executions:0,subprocesses,
   pending_preserved:fs.existsSync(grant.producer_workspace+'/state/external-pending.json')};
 const ordinal=fs.readdirSync(root).filter(name=>/^fixture-run-[0-9]{4}\.json$/.test(name)).length;
 fs.writeFileSync(root+'/fixture-run-'+String(ordinal).padStart(4,'0')+'.json',JSON.stringify(report),{flag:'wx'});
 fs.writeFileSync(root+'/fixture-result.json',JSON.stringify(report));console.log(JSON.stringify(report));
})();
