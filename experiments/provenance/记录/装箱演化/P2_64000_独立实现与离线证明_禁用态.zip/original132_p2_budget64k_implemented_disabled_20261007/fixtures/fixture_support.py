"""Bounded offline fixtures: original local fence/receipt helpers; external Library replies synthetic."""
import sys
sys.dont_write_bytecode=True
import copy,json,pathlib,tempfile,shutil,hashlib,subprocess
ROOT=pathlib.Path(__file__).resolve().parents[1]
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(pathlib.Path(p).read_bytes())
def ref(p):return {'path':str(p),'file_sha256':sha(p.read_bytes())}
def make_fixture(scenario='success'):
 f=pathlib.Path(tempfile.mkdtemp(prefix=scenario+'-',dir=ROOT/'fixtures'));w=f/'producer';(w/'state/commits').mkdir(parents=True);(w/'src').mkdir();(w/'.library-helpers-current').mkdir()
 g=read(ROOT/'MIGRATION_GRANT.64k.CANDIDATE.json')
 g['source_pins']={k:ref(pathlib.Path(k))['file_sha256'] for k in g['source_pins']}
 for p in (ROOT/'exporter/src').iterdir():
  if p.suffix in ['.py','.js']:shutil.copyfile(p,w/'src'/p.name)
 original=pathlib.Path('/workspace/original132-phase2-producer-20261006')
 shutil.copyfile(original/'.library-helpers-current/library_file_transfer.py',w/'.library-helpers-current/library_file_transfer.py')
 shutil.copyfile(original/'archive.initial.zip',w/'archive.initial.zip')
 shutil.copyfile(original/'index.initial.json',w/'index.initial.json')
 for p in (original/'state/commits').glob('*-0.json'):shutil.copyfile(p,w/'state/commits'/p.name)
 g.update(TEST_ONLY=True,producer_workspace=str(w),journal_root=str(w/'phase2-budget-migration'),new_index_path=str(w/'index.budget64k.proposed.json'))
 g['old_index_ref']=ref(w/'index.initial.json');g['old_index_receipt_ref']=ref(w/'state/commits/libfile_d711508ec1888191ba87324ac424a529-0.json')
 g['original_archive_ref']=ref(w/'archive.initial.zip');g['original_archive_receipt_ref']=ref(w/'state/commits/libfile_0186168496ec8191a13d91cbc158d000-0.json')
 g['helper_source_pins']={str(w/p):ref(w/p)['file_sha256'] for p in ['src/external_commit_fence_v2.py','src/commit_receipt_v2.py','.library-helpers-current/library_file_transfer.py']}
 # Independent grant stays disabled; fixture authorization is constrained to this fixtures tree.
 gpath=f/'MIGRATION_GRANT.TEST_ONLY.json';gpath.write_bytes(canon(g));gref=ref(gpath)
 cfg={'grantRef':gref,'corePath':str(ROOT/'src/budget_transition.py'),'commitPath':str(ROOT/'exporter/src/library_commit_v2.js'),
  'bridgePath':str(ROOT/'src/budget_transition_bridge.js'),'offlineFixture':True,'oldReadRefs':[ref(ROOT/'audit/FRESH_P2_READ.native.json')]}
 (f/'fixture-config.json').write_bytes(canon(cfg));return f
def run(f,scenario='success'):
 cp=subprocess.run(['/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node',str(ROOT/'fixtures/run_migration_fixture.js'),str(f),scenario],capture_output=True,text=True,env={'PATH':'/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin:/usr/bin:/bin'},timeout=60)
 if cp.returncode:raise AssertionError(cp.stderr+cp.stdout)
 return read(f/'fixture-result.json')
if __name__=='__main__':
 f=make_fixture();r=run(f);print(canon({'root':str(f),'report':r}).decode())
