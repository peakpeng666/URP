"""Trusted offline checks. External Library, GEN, INIT and model requests forbidden."""
import sys
sys.dont_write_bytecode=True
import copy,importlib.util,json,pathlib,shlex,subprocess,unittest
from types import SimpleNamespace
from unittest.mock import patch
from fixture_support import ROOT,make_fixture,run,read,ref,canon,sha
sys.path[:0]=[str(ROOT/'exporter/src'),str(ROOT/'src'),str(ROOT/'references/generation')]
import capture_v2 as capture
import budget_transition as transition
import durable_generation_sidecar as d
from production_generation_entry_64k import ProductionEntry

RESULTS=[]
P=ROOT/'package'
OLD=pathlib.Path('/workspace/original132-phase2-import-20261006-ba1y1szn/extracted/original132_phase2_continuation_draft_20261006')
W=pathlib.Path('/workspace/original132-phase2-producer-20261006')
DISABLED=pathlib.Path('/workspace/original132-fresh-p1-head-disabled-r2-20261006-men6wl9t')
NODE='/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node'

def inputs(slot):
 return [read(P/'inputs/packs'/f'{slot}.json'),read(P/'inputs/uncommitted-claims'/f'{slot}.json'),read(P/'inputs/freeze.json'),
  (P/'inputs/config.raw.json').read_bytes(),(P/'inputs/base-artifact.json').read_bytes(),(P/'inputs/input-route.json').read_bytes()]

def repin(f,g,raw=None):
 gp=f/'MIGRATION_GRANT.TEST_ONLY.json';gp.write_bytes(canon(g));cfg=read(f/'fixture-config.json');cfg['grantRef']=ref(gp)
 if raw is not None:
  rp=f/'old-read.TEST_ONLY.json';rp.write_bytes(canon(raw));cfg['oldReadRefs']=[ref(rp)]
 (f/'fixture-config.json').write_bytes(canon(cfg));return cfg

class OfflineAccountingSidecar(d.Sidecar):
 def _check_sources(self):
  d.need(self.grant['TEST_ONLY'] is True and self.grant['generation_execution_granted'] is False
   and self.root.is_relative_to(ROOT/'fixtures'),'offline accounting isolation')
  for p,h in self.grant['operational_source_files'].items():d.need(d.filehash(p)==h,'offline source drift')

def accounting_fixture(f):
 sc=OfflineAccountingSidecar.__new__(OfflineAccountingSidecar);sc.root=f/'accounting-only';sc.root.mkdir()
 sc.binding=read(ROOT/'consumer-contract.64k.CANDIDATE.json')
 sc.grant={'TEST_ONLY':True,'generation_execution_granted':False,'producer_workspace':str(f/'producer'),
  'operational_source_files':read(ROOT/'SOURCE_PINS.IMPLEMENTED.json'),'inclusive_wall_supplement_file_sha256':d.INCLUSIVE_SUPPLEMENT_SHA}
 sc.identity=d.sealed({'schema':'generation-sidecar-identity-v1','root':str(sc.root),'binding':sc.binding,'grant_sha256':d.sha(d.canon(sc.grant))})
 d.publish_once(sc.root/'identity.json',sc.identity);return sc

class Budget64k(unittest.TestCase):
 def test_01_exact_64k_and_rejected_32k_oversize(self):
  rows=read(P/'inputs/roster.json')['records']
  for row in rows:capture.check_input(*inputs(row['slot_id']))
  for budget in [32000,64001]:
   pack,claim,freeze,cfg,base,route=inputs(rows[0]['slot_id']);config=json.loads(cfg)
   freeze['configuration']['max_completion_tokens']=budget
   freeze['configured_settings']['max_completion_tokens']=budget
   config['provider']['zhipuai-coding-plan']['models']['glm-5.3']['limit']['output']=budget
   cfg=canon(config);freeze['config_file_sha256']=sha(cfg);freeze=transition.seal(freeze)
   pack['configuration']=copy.deepcopy(freeze['configuration']);pack['configuration_sha256']=sha(canon(pack['configuration']))
   pack['freeze_sha256']=freeze['sha256'];pack=transition.seal(pack)
   claim['freeze_sha256']=freeze['sha256'];claim['request_sha256']=pack['sha256'];claim=transition.seal(claim)
   with self.assertRaisesRegex(Exception,'completion_bound'):capture.check_input(pack,claim,freeze,cfg,base,route)
   with self.assertRaisesRegex(Exception,'exact_completion_launch_bound'):
    capture.command_for(ROOT/'fixtures/runtime.TEST_ONLY',rows[0]['slot_id'],{'settings':{'max_completion_tokens':budget}})
  RESULTS.append({'case':'exact64k_not_range','accepted_packs':60,'rejected_aligned_settings':[32000,64001],'OpenCode_launches':0})

 def test_02_launch_environment_and_actual_sdk_getArgs(self):
  row=read(P/'inputs/roster.json')['records'][0];checked=capture.check_input(*inputs(row['slot_id']))
  # This replaces os.environ before command preparation. No real environment is enumerated.
  with patch.object(capture.os,'environ',{'OPENCODE_TEST_FOREIGN':'TEST_ONLY','OPENCODE_EXPERIMENTAL_OUTPUT_TOKEN_MAX':'32000'}):
   command,launch_env=capture.command_for(ROOT/'fixtures/runtime.TEST_ONLY',row['slot_id'],checked)
  self.assertIsNone(launch_env)
  overrides={x.split('=',1)[0]:x.split('=',1)[1] for x in command if '=' in x}
  self.assertIn('-u',command);self.assertIn('OPENCODE_TEST_FOREIGN',command)
  self.assertEqual(overrides['OPENCODE_EXPERIMENTAL_OUTPUT_TOKEN_MAX'],'64000')
  self.assertEqual(command.count('OPENCODE_EXPERIMENTAL_OUTPUT_TOKEN_MAX=64000'),1)
  self.assertIn(capture.BINARY,command);self.assertIn('zhipuai-coding-plan/glm-5.3',command)
  binary=pathlib.Path(capture.BINARY).read_bytes();self.assertEqual(sha(binary),capture.BINARY_SHA)
  a=binary.index(b'async getArgs({prompt:G,maxOutputTokens:Y');b=binary.index(b'async doGenerate(G)',a)
  method=binary[a:b].decode();self.assertIn('max_tokens:Y',method)
  formula=b'function yy($,Z=V7){return Math.min($.limit.output,Z)||Z}'
  self.assertIn(formula,binary);self.assertIn(b'outputTokenMax:G("OPENCODE_EXPERIMENTAL_OUTPUT_TOKEN_MAX")',binary)
  # Execute the byte-exact frozen SDK getArgs method, not doGenerate/doStream.
  # Only non-budget dependencies are stubbed; the isolated VM has no fetch/network/client.
  js="""const vm=require('vm');let src='';process.stdin.on('data',x=>src+=x);process.stdin.on('end',async()=>{
   const input=JSON.parse(src);
   const sandbox={R:async({provider,providerOptions})=>providerOptions?.[provider],g:{shape:{}},h:x=>x,
    TG:()=>({tools:undefined,toolChoice:undefined,toolWarnings:[]}),MG:x=>x,yG:x=>x};
   const object=vm.runInNewContext('({'+input.method+'})',sandbox,{timeout:1000});
   const cap=vm.runInNewContext('('+input.maxFunction+')({limit:{output:64000}},64000)',{V7:32000}, {timeout:1000});
   const out=await object.getArgs.call({providerOptionsName:'zhipuai-coding-plan',modelId:'glm-5.3'},
    {prompt:[],maxOutputTokens:cap,temperature:0.7,topP:0.9,providerOptions:{'zhipuai-coding-plan':{reasoningEffort:'high'}}});
   console.log(JSON.stringify({TEST_ONLY:true,max_tokens:out.args.max_tokens,model:out.args.model,temperature:out.args.temperature,top_p:out.args.top_p,reasoning_effort:out.args.reasoning_effort,network_calls:0}));
  });"""
  cp=subprocess.run([NODE,'-e',js],input=json.dumps({'method':method,'maxFunction':formula.decode()}),text=True,capture_output=True,timeout=10,env={'PATH':'/usr/bin:/bin'})
  self.assertEqual(cp.returncode,0,cp.stderr);result=json.loads(cp.stdout)
  self.assertEqual(result['max_tokens'],64000);self.assertEqual(result['reasoning_effort'],'high')
  RESULTS.append({'case':'actual_frozen_SDK_mapping','binary_sha256':capture.BINARY_SHA,'SDK_getArgs_source_sha256':sha(method.encode()),
   'SDK_getArgs_source_offset':a,'launch_override':overrides['OPENCODE_EXPERIMENTAL_OUTPUT_TOKEN_MAX'],'result':result,
   'SDK_method_executed_offline':True,'HTTP_wire_observed':False,'OpenCode_launches':0})

 def test_03_roster_parent_prompt_and_hash_chain(self):
  old=read(OLD/'inputs/roster.json');new=read(P/'inputs/roster.json');self.assertEqual(len(new['records']),60)
  self.assertEqual(sum(len(r['parents']) for r in new['records']),78)
  self.assertEqual(sorted([r['arm'] for r in new['records']]).count('EOH_TC'),30)
  self.assertEqual(sorted([r['arm'] for r in new['records']]).count('IID_TC'),30)
  allowed={'request_sha256','claim_sha256','freeze_sha256','config_file_sha256'}
  for a,b in zip(old['records'],new['records']):
   self.assertEqual({k:v for k,v in a.items() if k not in allowed},{k:v for k,v in b.items() if k not in allowed})
   op=read(OLD/'inputs/packs'/f'{a["slot_id"]}.json');np=read(P/'inputs/packs'/f'{b["slot_id"]}.json')
   for field in ['prompt','prompt_sha256','serialized_messages_sha256','parents']:self.assertEqual(op[field],np[field])
  ctx=read(ROOT/'LIBRARY_CONTEXTS.64k.CANDIDATE.json');self.assertEqual(len(ctx['contexts']),180)
  byslot={r['slot_id']:r for r in new['records']};binding=read(ROOT/'consumer-contract.64k.CANDIDATE.json')
  for row in ctx['contexts']:
   c=row['context'];self.assertEqual(c['request_sha256'],byslot[c['slotId']]['request_sha256'])
   self.assertEqual(c['binding_sha256'],sha(canon(binding)))
   self.assertRegex(c['operationId'],r'^[A-Za-z0-9_.-]{1,96}$')
  manifest=read(P/'PACKAGE_MANIFEST.json');transition.verify(manifest)
  for name,h in manifest['files'].items():self.assertEqual(sha((P/name).read_bytes()),h)
  for name in ['PLAN.json','BINDINGS.json','LINEAGE.json','inputs/freeze.json','inputs/roster.json']:transition.verify(read(P/name))
  d.inspect_contract(P,ROOT/'data/FORWARD_COORDINATION_POLICY.64k.CANDIDATE.json',ROOT/'data/RESOURCE_ACCOUNTING_BINDING.64k.CANDIDATE.json',OLD.parent)
  RESULTS.append({'case':'roster_and_derived_pins','requests':60,'arms':{'EOH_TC':30,'IID_TC':30},'parent_tickets':78,'contexts':180,'package_pins':len(manifest['files']),'prompt_parent_bytes_unchanged':True})

 def test_04_old_grant_mixed_and_disabled_production(self):
  binding=read(ROOT/'consumer-contract.64k.CANDIDATE.json');g=read(DISABLED/'GEN_GRANT.CANDIDATE.json')
  # Enabled only in this in-memory negative input, never persisted or passed to a producer.
  g.update(generation_execution_granted=True,implementation_review_accepted=True,TEST_ONLY=True)
  with self.assertRaisesRegex(Exception,'binding mismatch'):d.validate_grant(binding,g,sha(canon(g)))
  with self.assertRaisesRegex(Exception,'transition disabled'):transition.grant(ref(ROOT/'MIGRATION_GRANT.64k.CANDIDATE.json'))
  for name in ['GEN_GRANT.64k.CANDIDATE.json','BRIDGE_GATE.64k.CANDIDATE.json','MIGRATION_GRANT.64k.CANDIDATE.json']:
   v=read(ROOT/name)
   for field in ['generation_execution_granted','migration_execution_granted','numeric_execution_granted','enabled','parent_review_accepted','implementation_review_accepted','independent_review_accepted']:
    if field in v:self.assertIs(v[field],False)
  self.assertIsNone(read(ROOT/'GEN_GRANT.64k.CANDIDATE.json')['entry_initial_head']['receipt_file_sha256'])
  RESULTS.append({'case':'disabled_and_mixed32k_grant_rejected','persisted_enable_files':0})

 def test_05_one_head_transition_and_same_pool_bootstrap(self):
  f=make_fixture('success-final');before={str(p):sha(p.read_bytes()) for p in (f/'producer').glob('*.initial.*')}
  cfg=read(f/'fixture-config.json');g=read(cfg['grantRef']['path']);out=run(f)
  self.assertTrue(out['success'],out);self.assertEqual((out['writes'],out['reads']),(1,2));self.assertFalse(out['pending_preserved'])
  self.assertEqual(sum(r['action']=='original_pinned_helper' for r in out['subprocesses']),4)
  tr=out['result']['transition_ref'];t=read(tr['path']);newr=t['new_index_receipt']
  self.assertEqual(newr['library_file_id'],g['index_library_file_id']);self.assertEqual(newr['current_version_number'],1)
  self.assertEqual(read(g['old_index_receipt_ref']['path'])['current_version_number'],0)
  for p,h in before.items():self.assertEqual(sha(pathlib.Path(p).read_bytes()),h)
  ms=transition.confirmed_transition(tr,cfg['grantRef'],g['old_INIT_v2_ref'],newr,offline=True)
  old,digest=transition.old_resources(g);self.assertEqual(len(old),46);self.assertGreater(len(ms),0)
  entry=ProductionEntry.__new__(ProductionEntry);entry.plan=read(P/'PLAN.json')
  entry.sidecar=SimpleNamespace(grant={'TEST_ONLY':True,'reconciliation_grant_ref':g['original_reconciliation_grant_ref'],
   'namespace_initialization_handoff':g['old_INIT_v2_ref'],'entry_initial_archive_receipt':read(g['old_INIT_v2_ref']['path'])['archive_receipt'],
   'output_budget_transition_ref':tr,'output_budget_transition_grant_ref':cfg['grantRef']})
  combined,gotdigest=entry.bootstrap_receipts(newr);self.assertEqual(combined,old+ms);self.assertEqual(gotdigest,digest)
  with self.assertRaisesRegex(Exception,'handoff already imported'):entry.bootstrap_receipts(newr)
  sc=accounting_fixture(f);token=sc.begin('init_final','initialization');state=sc.finish(token,local_receipts=combined)
  self.assertEqual(state['halt'],[]);cpu,wall=transition.base.totals(combined)
  self.assertAlmostEqual(state['scopes']['init_final'][0]-state['process_CPU_checkpoints'][d.PROCESS],cpu)
  self.assertAlmostEqual(state['scopes']['init_final'][1]-state['done'][0]['result']['sidecar_control_receipt']['local_inclusive_wall_seconds'],wall)
  with self.assertRaises(Exception):sc.begin('init_final','initialization')
  saved=pathlib.Path(tr['path']).read_bytes();again=run(f)
  self.assertFalse(again['success']);self.assertEqual(again['writes'],0);self.assertEqual(pathlib.Path(tr['path']).read_bytes(),saved)
  self.assertFalse((pathlib.Path(g['journal_root'])/'HALTED.json').exists())
  RESULTS.append({'case':'one_empty_head_transition_and_actual_bootstrap','fixture':str(f),'transition_ref':tr,
   'writes':1,'current_reads':2,'actual_original_helpers':4,'original_measurements':46,'new_migration_measurements':len(ms),
   'same_pool_combined_count':len(combined),'observed_SELF_seconds':cpu,'observed_local_window_seconds':wall,
   'pool':g['pool'],'archive_changed':False,'original0_trace_preserved':True,'reentry_additional_writes':0,
   'unknown_JS_Library_provider_CPU_wait':None,'CPU_cap_certification':'NOT_ESTABLISHED','INIT_executions':0,'model_calls':0,'TEST_ONLY':True})

 def test_06_unknown_write_no_retry_and_failed_receipts(self):
  for scenario in ['write_unknown','wrong_identity','wrong_version','wrong_readback','stale_read_version']:
   f=make_fixture(scenario);out=run(f,scenario);self.assertFalse(out['success']);self.assertEqual(out['writes'],1)
   g=read(read(f/'fixture-config.json')['grantRef']['path']);jr=pathlib.Path(g['journal_root'])
   self.assertTrue((jr/'HALTED.json').exists());self.assertFalse((jr/'transition.receipt.json').exists())
   again=run(f,scenario);self.assertFalse(again['success']);self.assertEqual(again['writes'],0)
   if scenario in ['write_unknown','wrong_identity','wrong_version']:self.assertTrue(out['pending_preserved'])
   RESULTS.append({'case':'failure_'+scenario,'fixture':str(f),'writes_before_halt':1,'additional_writes_on_reentry':0,
    'original_fence_pending':out['pending_preserved'],'manual_fence_clear':False,'TEST_ONLY':True})

 def test_07_bad_old_heads_rejected_before_write(self):
  for scenario in ['nonempty_old','wrong_old_freeze','old_read_identity','old_read_version']:
   f=make_fixture(scenario);cfg=read(f/'fixture-config.json');g=read(cfg['grantRef']['path']);raw=read(ROOT/'audit/FRESH_P2_READ.native.json')
   if scenario in ['nonempty_old','wrong_old_freeze']:
    p=pathlib.Path(g['old_index_ref']['path']);v=read(p)
    if scenario=='nonempty_old':v['rows']=[{'TEST_ONLY':True}]
    else:v['freeze_sha256']='0'*64
    p.write_bytes(canon(transition.seal(v)));g['old_index_ref']=ref(p)
   elif scenario=='old_read_identity':raw['structuredContent']['results'][0]['library_file_id']='libfile_TEST_ONLY_wrong'
   else:raw['structuredContent']['results'][0]['version_id']=9
   repin(f,g,raw);out=run(f,scenario);self.assertFalse(out['success']);self.assertEqual(out['writes'],0)
   self.assertFalse(pathlib.Path(g['new_index_path']).exists())
   RESULTS.append({'case':'reject_'+scenario,'fixture':str(f),'writes':0,'new_head_created':False})

 def test_08_same_pool_exhaustion(self):
  # Synthetic measurements are explicitly marked; no historical46 row is modified.
  old=read(W.with_name(W.name+'.namespace-recovery')/'RECONCILED_HANDOFF.v2.json')['measurements']
  for cpu,wall in [(60,0),(0,240)]:
   m={'TEST_ONLY':True,'process':'TEST_ONLY_budget_probe','start':{'process':'TEST_ONLY_budget_probe','self_cpu':0,'monotonic':1000000000000},
    'end':{'process':'TEST_ONLY_budget_probe','self_cpu':cpu,'monotonic':1000000000000+wall},'self_cpu_seconds':cpu,'wall_seconds':wall,
    'local_inclusive_wall_seconds':wall,'native_wait_union_seconds':0,'RUSAGE_kind':'RUSAGE_SELF','measurement_status':'known',
    'wall_semantics':'local_stage_inclusive_no_wait_deduction'}
   with self.assertRaisesRegex(Exception,'pool exhausted'):transition.base.admission(old+[m])
   f=make_fixture('pool-before-effect');cfg=read(f/'fixture-config.json');g=read(cfg['grantRef']['path'])
   journal=transition.Journal(cfg['grantRef'],offline=True);journal.prepare(cfg['oldReadRefs'])
   transition.publish(journal.root/'cost-0000.json',transition.seal({'grant_ref':cfg['grantRef'],'outcome':'confirmed','measurement':m}))
   helper=str(pathlib.Path(g['producer_workspace'])/'src/external_commit_fence_v2.py')
   args={'cmd':'python3 -I '+shlex.quote(helper)+' begin '+shlex.quote(g['producer_workspace'])+' '+shlex.quote(g['new_index_path'])+' '+shlex.quote(g['index_library_file_id'])+' 0 index'}
   with self.assertRaisesRegex(Exception,'pool exhausted'):journal.tool_begin('exec_command',args)
   self.assertEqual(list(journal.root.glob('tool-*.intent.json')),[])
  RESULTS.append({'case':'same60_240_pool_exhaustion_before_effect','synthetic_negative_probes_only':True,'old46_edited':False,'tool_effects_authorized':0})

if __name__=='__main__':
 result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Budget64k))
 report={'success':result.wasSuccessful(),'test_methods':result.testsRun,'results':RESULTS,'offline_only':True,
  'native_external_calls':0,'model_calls':0,'OpenCode_launches':0,'INIT_executions':0,'numeric_executions':0,
  'production_migration_execution_granted':False,'production_generation_execution_granted':False}
 (ROOT/'audit/OFFLINE_TEST_RESULTS.json').write_bytes(canon(report))
 sys.exit(0 if result.wasSuccessful() else 1)
