"""Package disabled copies and offline proof; no external app calls or activation."""
import sys
sys.dont_write_bytecode=True
import ast,hashlib,json,pathlib,shutil,subprocess,zipfile
N=pathlib.Path(__file__).resolve().parent
C=pathlib.Path('/workspace/original132-p2-budget64k-preparation-20261007-396h9f1c')
W=pathlib.Path('/workspace/original132-phase2-producer-20261006')
OLD=pathlib.Path('/workspace/original132-fresh-p1-head-disabled-r2-20261006-men6wl9t')
NODE='/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node'
PREFIX='original132_p2_budget64k_implemented_disabled_20261007'
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(pathlib.Path(p).read_bytes())
def put(p,v):p.write_bytes(canon(v))
def ref(p):return {'path':str(p),'file_sha256':sha(p.read_bytes())}
tests=read(N/'audit/OFFLINE_TEST_RESULTS.json');assert tests['success'] and tests['test_methods']==8
before=read(C/'evidence/PRODUCTION_BEFORE.json');after={p:sha(pathlib.Path(p).read_bytes()) for p in before};assert before==after and len(after)==151
assert all(not (W/p).exists() for p in ['phase2-generation-accounting','phase2-bridge-journal','phase2-budget-migration','index.budget64k.proposed.json'])
put(N/'audit/PRODUCTION_AFTER.json',after)
put(N/'audit/ORIGINAL_PRODUCTION_INVARIANTS.json',{'unchanged_files':151,'before_ref':ref(C/'evidence/PRODUCTION_BEFORE.json'),'after_ref':ref(N/'audit/PRODUCTION_AFTER.json'),
 'actual_migration_journal_exists':False,'actual_new_head_exists':False,'actual_GEN_journals_exist':False,'original46_handoff_ref':ref(W.with_name(W.name+'.namespace-recovery')/'RECONCILED_HANDOFF.v2.json')})
pins=read(N/'SOURCE_PINS.IMPLEMENTED.json');assert len(pins)==63
for p,h in pins.items():assert sha(pathlib.Path(p).read_bytes())==h

# Ship the old runtime bytes and true INIT journals for reviewers in other environments.
# Each copy is mapped to its immutable producer path; these are snapshots, not new receipts.
mapping={}
def snapshot(source,dest):
 source=pathlib.Path(source);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,dest)
 mapping[str(source)]={'member':PREFIX+'/'+dest.relative_to(N).as_posix(),'file_sha256':sha(source.read_bytes())}
for i,p in enumerate(sorted(pathlib.Path(p) for p in pins if not pathlib.Path(p).is_relative_to(N))):snapshot(p,N/'audit/immutable-runtime'/f'{i:03d}'/p.name)
for i,p in enumerate(sorted(pathlib.Path(p) for p in before)):snapshot(p,N/'audit/immutable-production'/f'{i:03d}'/p.name)
for p in [C/'BUDGET_AMENDMENT.CANDIDATE.json',C/'evidence/PRODUCTION_BEFORE.json',C/'evidence/FRESH_P2_READ.raw.json',C/'evidence/BINARY_SDK_STATIC_EVIDENCE.json',
 W.with_name(W.name+'.namespace-recovery')/'RECONCILED_HANDOFF.v2.json',pathlib.Path(read(N/'MIGRATION_GRANT.64k.CANDIDATE.json')['original_reconciliation_grant_ref']['path'])]:
 snapshot(p,N/'audit/immutable-prerequisites'/p.name)
for name in ['GEN_GRANT.CANDIDATE.json','BRIDGE_GATE.CANDIDATE.json','LIBRARY_CONTEXTS.CANDIDATE.json','GEN_COMPOSITION.CANDIDATE.json']:snapshot(OLD/name,N/'audit/immutable-disabled32k'/name)
put(N/'audit/IMMUTABLE_REFERENCE_BYTE_MAP.json',{'producer_path_to_member':mapping,'snapshot_only':True,'original_bytes_changed':False})

# Byte-exact SDK preparation methods from the frozen binary; doGenerate/doStream excluded.
binary_path=pathlib.Path('/tmp/urp-opencode-check-i8yzygra/native/node_modules/opencode-linux-x64-baseline/bin/opencode')
b=binary_path.read_bytes();a=b.index(b'async getArgs({prompt:G,maxOutputTokens:Y');z=b.index(b'async doGenerate(G)',a)
(N/'audit/FROZEN_SDK_GETARGS_METHOD.txt').write_bytes(b[a:z])
(N/'audit/FROZEN_OUTPUT_MAX_FUNCTION.txt').write_bytes(b'function yy($,Z=V7){return Math.min($.limit.output,Z)||Z}')
sdk=next(r for r in tests['results'] if r['case']=='actual_frozen_SDK_mapping')
assert sdk['SDK_getArgs_source_sha256']==sha(b[a:z])
del b

syntax=[]
for directory in ['src','exporter/src','generation','references/generation','fixtures']:
 syntax.extend(p for p in (N/directory).glob('*') if p.is_file() and p.suffix in ['.py','.js'])
syntax.extend((N/'package').glob('*.py'))
for p in syntax:
 if p.suffix=='.py':ast.parse(p.read_text(),filename=str(p))
 else:
  result=subprocess.run([NODE,'--check',str(p)],capture_output=True,text=True,timeout=10,env={'PATH':'/usr/bin:/bin'});assert result.returncode==0,result.stderr
put(N/'audit/SYNTAX_CHECKS.json',{'passed':True,'files':{str(p):sha(p.read_bytes()) for p in syntax},'Python_method':'ast.parse','JavaScript_method':'node --check','OpenCode_or_producer_executed':False})

selected=[pathlib.Path(r['fixture']) for r in tests['results'] if 'fixture' in r]
pool=sorted((N/'fixtures').glob('pool-before-effect-*'),key=lambda p:p.stat().st_mtime)[-2:];assert len(pool)==2
selected+=pool
for f in selected:
 assert f.is_relative_to(N/'fixtures') and read(f/'MIGRATION_GRANT.TEST_ONLY.json')['migration_execution_granted'] is False
 if (f/'fixture-run-0000.json').exists():assert read(f/'fixture-run-0000.json')['native_external_calls']==0
put(N/'audit/DELIVERED_FIXTURE_ROOTS.json',{'paths':[str(p) for p in selected],'TEST_ONLY':True,'external_replies_synthetic':True,'original_local_helpers_executed_only_in_isolated_fixtures':True})

transition=next(r for r in tests['results'] if r['case']=='one_empty_head_transition_and_actual_bootstrap')
fr=read(N/'package/inputs/freeze.json');manifest=read(N/'package/PACKAGE_MANIFEST.json')
binding=read(N/'consumer-contract.64k.CANDIDATE.json')
report={'status':'DISABLED_IMPLEMENTATION_AND_TRUSTED_OFFLINE_PROOF_READY_FOR_INDEPENDENT_REVIEW','completion_tokens_per_request':64000,
 'P2_requests':60,'arms':{'EOH_TC':30,'IID_TC':30},'parent_tickets':78,'operation_contexts':180,
 'old_original72_candidates_and_failures_preserved':True,'old32k_candidates_and_source_bytes_preserved':True,'original_production_files_unchanged':151,
 'source_pin_count':63,'package_member_pins':len(manifest['files']),'unchanged_external_dependency_pins':len(binding['external_source_files']),
 'runtime_families_modified':['capture_v2','phase2_producer_bridge','durable_generation_sidecar'],
 'narrow_new_controls':['budget_transition.py','budget_transition_bridge.js','production_generation_entry_64k.py'],
 'freeze_seal':fr['sha256'],'config_file_sha256':fr['config_file_sha256'],'official_binary_version':'1.18.34','official_binary_sha256':fr['cli_binary_sha256'],
 'SDK_preparation_max_tokens':64000,'HTTP_wire_observed':False,'SDK_getArgs_executes_offline_with_only_nonbudget_stubs':True,
 'production_migration_execution_granted':False,'production_generation_execution_granted':False,'production_numeric_execution_granted':False,
 'this_implementation_native_Library_writes':0,'this_implementation_native_Library_reads':0,'earlier_preparation_native_batched_read_calls':1,
 'earlier_preparation_native_read_targets':2,'earlier_read_UTC':['2026-10-07 01:22:05 UTC','2026-10-07 01:22:09 UTC'],
 'OpenCode_launches':0,'model_calls':0,'INIT_executions':0,'numeric_executions':0,'heldout_dataset_reads':0,
 'network_secret_original_read_output_hash_or_record':False,'archive_initial_unchanged_bytes':478,'archive_budget_migration_required':False,
 'offline_test_methods':8,'offline_checks_passed':True,'offline_transition_measurements':transition['new_migration_measurements'],
 'offline_original_measurements_imported':46,'offline_same_pool_combined_measurements':transition['same_pool_combined_count'],
 'offline_transition_is_not_a_production_receipt':True,'pool':transition['pool'],
 'unknown_JS_Library_provider_CPU_wait':None,'unmeasured_post_checkpoint_tails':None,'CPU_cap_certification':'NOT_ESTABLISHED',
 'refs':{name:ref(N/name) for name in ['MIGRATION_GRANT.64k.CANDIDATE.json','GEN_GRANT.64k.CANDIDATE.json','BRIDGE_GATE.64k.CANDIDATE.json','GEN_COMPOSITION.64k.CANDIDATE.json','LIBRARY_CONTEXTS.64k.CANDIDATE.json','consumer-contract.64k.CANDIDATE.json','SOURCE_PINS.IMPLEMENTED.json','audit/OFFLINE_TEST_RESULTS.json']},
 'preceding_preparation_Drive_file_id':'1Zl3OIVncniQa89yNzJ-UBOX-2DoyWq7Z','preceding_preparation_ZIP_SHA256':'7cae743f520c08c1ffa7ae7870a011df94714a1a03e2a7f924a82ddbc69c1366',
 'remaining':['Parent independent code/protocol review of these exact refs','Fresh native old-head/backing verification immediately before approved migration',
 'One explicitly approved native same-ID v0-to-v1 index CAS; preserve all original46/v0/archive bytes',
 'Pin that actual transition/new-head receipt in a separate reviewed GEN authorization before any generation',
 'Physical provider acceptance/output and complete process CPU remain unobserved; stop on uncertainty, quota or CLI error']}
put(N/'IMPLEMENTATION_REPORT.json',report)
(N/'README.md').write_text('''# P2 64000：独立实现与离线证明，全部生产开关关闭

这份材料实现已确认的剩余60条 P2 请求预算补充。模型仍为 glm-5.3，high，temperature=0.7，top_p=0.9，steps=2，tools=false，900秒，outer_retries=0；唯一端点是 https://open.bigmodel.cn/api/coding/paas/v4。原72条与失败均保留，两个实验臂各30条、78个父票据及提示内容未变。未运行 OpenCode、模型推理、真实迁移、INIT 或数值/heldout任务。

## 审阅入口

- `IMPLEMENTATION_REPORT.json`：最终状态、当前freeze/文件引用、剩余动作。
- `patches/`：三个模块族的最小差异及单独的新GEN bootstrap适配。
- `src/budget_transition.py` / `src/budget_transition_bridge.js`：一次空索引版本迁移；工具意图/结果、原四个本地helper和全部可观测Python记录均持久化；未知结果停止，不重试、不手动清除fence。
- `GEN_GRANT.64k.CANDIDATE.json` / `BRIDGE_GATE.64k.CANDIDATE.json` / `MIGRATION_GRANT.64k.CANDIDATE.json`：禁用草案。真实新head receipt SHA与真实transition ref均未填，不能开启。原INIT handoff没有被改为新head。
- `audit/OFFLINE_TEST_RESULTS.json`：8项检查通过；完整的首轮和重入结果、原helper意图/结果及资源记录在选定 `fixtures/` 中。Library回复是明确TEST_ONLY替身，原本地fence/xattr/receipt helpers确实在隔离目录执行。SDK getArgs 与原输出min函数来自冻结二进制，离线执行得到 max_tokens=64000；没有调用doGenerate/doStream或观察HTTP请求。
- `audit/IMMUTABLE_REFERENCE_BYTE_MAP.json`：为跨环境审阅提供旧运行源文件与151份真实生产/INIT/recovery文件的字节快照，映射原绝对路径与ZIP成员。不是重新生成的生产回执。456项外部依赖保持原有hash引用，既有生产baseline必须继续使用。

## 预算与身份

新CLI仅额外白名单 `OPENCODE_EXPERIMENTAL_OUTPUT_TOKEN_MAX=64000`；所有继承 OPENCODE_* 仍清除。模型limit.output与配置预算也恰为整数64000。配置只含 `{env:ZHIPU_API_KEY}` 引用，未读回、展示、记录或哈希真实密钥。

同一P2索引 libfile_d711508ec1888191ba87324ac424a529 只计划一次CAS，从原v0/旧freeze到新freeze/v1。478字节初始archive只有 file-hashes.json 与 phase2 slots=[] 的wave-manifest，没有freeze/config字段，保持原v0与字节，无需迁移。新GEN bootstrap严格验证原46条真实INIT记录，再导入实际迁移新增测量；可信离线成功例为46+22=68，始终使用原SELF 60秒/local-window 240秒 init-final池，未重新执行INIT。JS/Library/provider CPU与wait、所有未观测尾部保持unknown；不声明完整CPU上界。

## 后续必须分两步批准

先独立审阅本包精确hash链和协议，再按真实最新的原索引/原backing读取证据批准一次迁移。前一份原索引读取证据时间为2026-10-07 01:22:05–01:22:09 UTC，两个native version_id均null；v0来自原真实receipt，不能说native读回了v0。实际迁移应保留原0回执与新1回执，实测迁移增量并入同一池。

只有真实迁移已确认后，才在另行审阅的GEN授权中绑定真实transition、当前新head文件和实际receipt的精确SHA，并取得原P1干净head的新确认。不要把本包TEST_ONLY回执当真实回执，也不要直接翻转草案布尔开关。套餐/服务器对实际请求的接受尚未观察；不明确时停止，不尝试标准付费端点或其他provider。

上一个禁用的数据补充包： https://drive.google.com/file/d/1Zl3OIVncniQa89yNzJ-UBOX-2DoyWq7Z/view 。本包派生freeze已经包含最终source/lineage约束，因此以IMPLEMENTATION_REPORT.json的当前freeze与refs为审阅对象，保留旧包不覆盖。
''',encoding='utf-8')

files=[]
for directory in ['src','exporter','generation','references','package','data','patches','audit']:
 files.extend(p for p in (N/directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
files.extend(p for p in (N/'fixtures').glob('*') if p.is_file())
for f in selected:files.extend(p for p in f.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
files.extend(p for p in N.glob('*') if p.is_file() and p.suffix in ['.py','.json','.md'])
files=sorted(set(files));members={PREFIX+'/'+p.relative_to(N).as_posix():sha(p.read_bytes()) for p in files}
delivery={'schema':'disabled64k-delivery-byte-manifest-v1','members':members,'production_activated':False,'only_selected_latest_offline_fixtures':True}
manifest_bytes=canon(delivery)
zip_path=N/'P2_64000_独立实现与离线证明_禁用态_20261007.zip'
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files:z.write(p,PREFIX+'/'+p.relative_to(N).as_posix())
 z.writestr(PREFIX+'/DELIVERY_MANIFEST.json',manifest_bytes)
with zipfile.ZipFile(zip_path) as z:
 assert z.testzip() is None and len(z.namelist())==len(members)+1
 for member,h in members.items():assert sha(z.read(member))==h
packaged={'ZIP_path':str(zip_path),'ZIP_bytes':zip_path.stat().st_size,'ZIP_SHA256':sha(zip_path.read_bytes()),'member_count':len(members)+1,'member_hashes_verified':len(members),
 'freeze_seal':fr['sha256'],'final_refs':report['refs'],'offline_checks':8,'production_activated':False}
put(N/'LOCAL_DELIVERY_VERIFICATION.json',packaged)
print(canon({k:v for k,v in packaged.items() if k!='final_refs'}).decode())
