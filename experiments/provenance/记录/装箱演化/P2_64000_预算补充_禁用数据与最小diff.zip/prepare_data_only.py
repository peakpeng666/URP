import copy,difflib,hashlib,json,mmap,os,pathlib,resource,time
N=pathlib.Path("/workspace/original132-p2-budget64k-preparation-20261007-396h9f1c")
P=pathlib.Path('/workspace/original132-phase2-import-20261006-ba1y1szn/extracted/original132_phase2_continuation_draft_20261006')
W=pathlib.Path('/workspace/original132-phase2-producer-20261006')
R=pathlib.Path('/workspace/original132-phase2-recovery-dev-20261006-8sdu8cov/revision2')
O=pathlib.Path('/workspace/original132-fresh-p1-head-disabled-r2-20261006-men6wl9t')
start=time.monotonic();cpu=resource.getrusage(resource.RUSAGE_SELF)
def canon(v): return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def sha(b): return hashlib.sha256(b).hexdigest()
def seal(v): return dict(v,sha256=sha(canon({k:x for k,x in v.items() if k!='sha256'})))
def read(p):return json.loads(p.read_bytes())
def put(name,v):
 p=N/name;p.parent.mkdir(parents=True,exist_ok=True)
 data=v if isinstance(v,bytes) else canon(v)
 if p.exists(): assert p.read_bytes()==data, 'candidate file drift'
 else:
  with p.open('xb') as f:f.write(data)
 return {'path':str(p),'file_sha256':sha(p.read_bytes())}
def ref(p):return {'path':str(p),'file_sha256':sha(p.read_bytes())}
def snapshot():
 roots=[W,pathlib.Path(str(W)+'.namespace-init'),pathlib.Path(str(W)+'.namespace-recovery')]
 return {str(p):sha(p.read_bytes()) for root in roots for p in sorted(root.rglob('*')) if p.is_file()}
before=snapshot()
put('evidence/PRODUCTION_BEFORE.json',before)
oldconfig=(P/'inputs/config.raw.json').read_bytes();config=read(P/'inputs/config.raw.json')
assert config['provider']['zhipuai-coding-plan']['options']['apiKey']=='{env:ZHIPU_API_KEY}'
config['provider']['zhipuai-coding-plan']['models']['glm-5.3']['limit']['output']=64000
configref=put('draft/config.64k.CANDIDATE.json',config)
oldfreeze=read(P/'inputs/freeze.json');oldroster=read(P/'inputs/roster.json');oldplan=read(P/'PLAN.json');oldhead=read(W/'index.initial.json')
v=read(N/'evidence/FRESH_P2_READ.raw.json');rs=v['returned']['structuredContent']['results']
assert v['returned']['isError'] is False and not v['returned']['structuredContent']['warnings']
for result in rs:
 assert result['library_file_id']=='libfile_d711508ec1888191ba87324ac424a529' and result['file_id']=='file_00000000d48881f58e04687a2b2eb6b4'
 assert result['has_more'] is False and not result['warnings'] and isinstance(result['content'][0],str)
 observed=''.join(result['content']).encode()
 assert observed==(W/'index.initial.json').read_bytes() and len(observed)==859
 assert read(W/'index.initial.json')['rows']==[]
assert not (W/'phase2-generation-accounting').exists() and not (W/'phase2-bridge-journal').exists()
pending=[str(p) for p in [W/'state/external-pending.json',W/'state/dispatch-pending.json'] if p.exists()]
assert not pending
handoffpath=pathlib.Path(str(W)+'.namespace-recovery/RECONCILED_HANDOFF.v2.json');h=read(handoffpath)
assert sha(handoffpath.read_bytes())=='2645a52293ad256e90d50729bac7fb015209d950e516035f82ebeb86253a1f66'
assert len(h['measurements'])==46 and h['status']=='CONFIRMED'
oldreceipt=read(W/'state/commits/libfile_d711508ec1888191ba87324ac424a529-0.json')
fresh=put('evidence/FRESH_P2_EMPTY_HEAD.json',{'interval':{'before':v['before'],'after':v['after']},'native_read_calls':1,'targets':2,'returned_version_id':[r['version_id'] for r in rs],'known_original_receipt_version':oldreceipt['current_version_number'],'content_bytes':859,'content_sha256':sha(observed),'rows':0,'freeze_sha256':oldhead['freeze_sha256'],'remote_content_equal_original_v0_bytes':True,'point_in_time_only':True,'global_inflight_status':None,'GEN_journals_absent':True,'known_pending_files':pending,'raw_result_ref':ref(N/'evidence/FRESH_P2_READ.raw.json')})
amendment={'schema':'original132-phase2-output-budget-amendment-candidate-v1','status':'DISABLED_REVIEW_REQUIRED','generation_execution_granted':False,'numeric_execution_granted':False,'Library_migration_execution_granted':False,'implementation_review_accepted':False,'operational_run_id':oldplan['run_id'],'scientific_run_id':oldplan['scientific_run_id'],'scope':{'phase':2,'orders':[73,132],'logical_requests':60,'EOH_TC':30,'IID_TC':30,'slot_order':[r['slot_id'] for r in oldroster['records']]},'old_completion_tokens_per_request':32000,'completion_tokens_per_request':64000,'configured_completion_reserved_maximum':3840000,'unchanged_settings':{k:x for k,x in oldfreeze['configuration'].items() if k!='max_completion_tokens'},'CLI_override':{'OPENCODE_EXPERIMENTAL_OUTPUT_TOKEN_MAX':'64000'},'endpoint':'https://open.bigmodel.cn/api/coding/paas/v4','model':'glm-5.3','quota_policy':'Stop before any next slot on CLI error or exhausted Coding Plan quota; no upgrade, purchase, paid fallback, outer retry, or replacement slot. Physical HTTP attempts remain unobserved.','original_refs':{'config':ref(P/'inputs/config.raw.json'),'freeze':ref(P/'inputs/freeze.json'),'plan':ref(P/'PLAN.json'),'roster':ref(P/'inputs/roster.json'),'disabled_grant':ref(O/'GEN_GRANT.CANDIDATE.json'),'INIT_v2':ref(handoffpath),'index_v0':ref(W/'index.initial.json'),'index_v0_receipt':ref(W/'state/commits/libfile_d711508ec1888191ba87324ac424a529-0.json')},'phase_label':'P0/P1 original72 at32k; P2 remaining60 proposed64k; mixed-budget continuation, no all132 same32k claim','original72_and_failed_results':'preserve immutable; no retrospective rerun or replacement','parent_prompts_and_seeds':'unchanged; source metadata only; no new parent selection','namespace_proposal':{'action':'Once-only versioned replacement of same previously initialized empty P2 index after separate approval','index_library_file_id':'libfile_d711508ec1888191ba87324ac424a529','archive_library_file_id':'libfile_0186168496ec8191a13d91cbc158d000','old_version':0,'new_version':None,'new_receipt':None,'reinitialize':False,'preserve_run_id_predecessor_arms_caps_and_empty_rows':True,'budget_transition_evidence_required':True,'entry_receipt_adapter_required':True},'accounting':{'old_v2_measurements':46,'old_v2_imports_max':1,'initial_final_pool_SELF_seconds':60,'initial_final_pool_local_wall_seconds':240,'reset_or_new_pool':False,'migration_local_measurements':'append exactly once to original46 in same INIT/FINAL pool; required dedicated once-only migration intent/receipt and source pins','Library_elapsed_and_post_checkpoint_tails':None,'overall_CPU_cap_certification':'NOT_ESTABLISHED'},'fresh_P2_evidence_ref':fresh,'user_intent_source':'Parent delegation2026-10-07: user confirms60 generations and larger than32000; parent communicates64000; model/high/900 unchanged','parent_failure_evidence':'Parent independently verified31 P1 length failures with no public content and32000 reasoning+output; not re-read or re-calculated here','physical_HTTP_or_wire_capture':None}
amendref=put('BUDGET_AMENDMENT.CANDIDATE.json',seal(amendment))
capture=P.parent/'original132_phase1_preparation_20261005/exporter/src/capture_v2.py'
bridge=P/'phase2_producer_bridge.py'
sidecar=R/'references/generation/durable_generation_sidecar.py'
policy=P.parent/'handoff_evidence/parent_approval/FORWARD_COORDINATION_POLICY.json'
account=P.parent/'handoff_evidence/parent_approval/RESOURCE_ACCOUNTING_BINDING.json'
supp=P.parent/'original132_phase2_inclusive_accounting_supplement_20261006/INCLUSIVE_ACCOUNTING_SUPPLEMENT.json'
newpolicy=read(policy);newpolicy['generation']['completion_tokens_per_request']=64000;newpolicy['generation']['completion_tokens_reserved']=3840000
for k in ['parent_review_accepted','input_binding_execution_granted','generation_execution_granted','numeric_execution_granted','generation_coordination_activation_granted']:newpolicy[k]=False
newpolicy['status']='DISABLED_64K_DERIVED_POLICY_PENDING_REVIEW';newpolicy['budget_amendment_ref']=amendref
pref=put('draft/FORWARD_COORDINATION_POLICY.64k.CANDIDATE.json',newpolicy)
newaccount=read(account);newaccount['input_binding_and_generation_bookkeeping_accounting']['allowance_or_verified_balance_file_sha256']=pref['file_sha256']
newaccount['parent_review_accepted']=False;newaccount['status']='DISABLED_64K_DERIVED_ACCOUNTING_PENDING_REVIEW';newaccount['budget_amendment_ref']=amendref
aref=put('draft/RESOURCE_ACCOUNTING_BINDING.64k.CANDIDATE.json',newaccount)
newsupp=read(supp);newsupp['policy_file_sha256']=pref['file_sha256'];newsupp['resource_accounting_binding_file_sha256']=aref['file_sha256'];newsupp['budget_amendment_ref']=amendref;newsupp['implementation_independently_reviewed']=False;newsupp['generation_execution_granted']=False
sref=put('draft/INCLUSIVE_ACCOUNTING_SUPPLEMENT.64k.CANDIDATE.json',newsupp)
originalsrc={str(p):p.read_bytes() for p in [capture,bridge,sidecar]};proposed={}
text=originalsrc[str(capture)].decode()
text=text.replace("0 < settings['max_completion_tokens'] <= 32000","settings['max_completion_tokens'] == 64000")
text=text.replace("    overrides['OPENCODE_CONFIG'] = str(runtime / 'config/opencode.json')","    overrides['OPENCODE_CONFIG'] = str(runtime / 'config/opencode.json')\n    overrides['OPENCODE_EXPERIMENTAL_OUTPUT_TOKEN_MAX'] = str(checked['settings']['max_completion_tokens'])")
proposed[str(capture)]=text.encode()
text=originalsrc[str(bridge)].decode().replace("'configured_completion_tokens':32000","'configured_completion_tokens':64000").replace("'configured_completion_reserved':32000*len(rows)","'configured_completion_reserved':64000*len(rows)").replace("('tool_event','second_model_message'","('cli_error_event','tool_event','second_model_message'")
proposed[str(bridge)]=text.encode()
text=originalsrc[str(sidecar)].decode().replace("'completion_tokens_per_request': 32000","'completion_tokens_per_request': 64000").replace("'completion_tokens': 32000","'completion_tokens': 64000")
for old,new in [('17a7fdb770fd0d4c5a92c6b607060c96c9887312e37deca521d9b78646a1767a',pref['file_sha256']),('e28098a5fb12468e3b0cad5b55f43c243806128d999f0698b93e6adc78aa4db7',aref['file_sha256']),('778f9e487fc3a9201c8dc0de061b6195f6e3e8045cd5e4dcd30464e1830c3193',sref['file_sha256'])]:text=text.replace(old,new)
proposed[str(sidecar)]=text.encode()
changes=[]
for path,data in proposed.items():
 assert data!=originalsrc[path]
 patch=''.join(difflib.unified_diff(originalsrc[path].decode().splitlines(True),data.decode().splitlines(True),fromfile=path,tofile='PROPOSED_64K_COPY/'+pathlib.Path(path).name))
 pref0=put('patches/'+pathlib.Path(path).name+'.patch',patch.encode())
 changes.append({'original_path':path,'original_SHA256':sha(originalsrc[path]),'proposed_exact_bytes_SHA256':sha(data),'patch_ref':pref0,'applied':False,'production_execution':False})
put('PATCH_PIN_DIFF.json',changes)
exporterfiles={}
oldsource=read(P.parent/'original132_phase1_preparation_20261005/exporter/SOURCE_FREEZE.json') if (P.parent/'original132_phase1_preparation_20261005/exporter/SOURCE_FREEZE.json').exists() else None
for f in sorted((capture.parent).glob('*.py'))+sorted((capture.parent).glob('*.js')):
 exporterfiles['src/'+f.name]=sha(proposed.get(str(f),f.read_bytes()))
new_exporter_sha=sha(canon(exporterfiles))
scope=read(P/'RESOURCE_SCOPE.json');scope['configured_completion_tokens_maximum']=3840000;scope['forward_accounting_binding_sha256']=aref['file_sha256'];scope['budget_amendment_ref']=amendref;scope=seal(scope)
put('draft/RESOURCE_SCOPE.64k.CANDIDATE.json',scope)
freeze=copy.deepcopy(oldfreeze)
for k in ['configuration','configured_settings']:freeze[k]['max_completion_tokens']=64000
freeze['config_file_sha256']=configref['file_sha256'];freeze['exporter_source_sha256']=new_exporter_sha;freeze['cli_exporter_source_sha256']=new_exporter_sha
freeze['phase2_resource_scope_sha256']=scope['sha256'];freeze['resource_accounting_binding_sha256']=aref['file_sha256'];freeze['output_budget_amendment_ref']=amendref;freeze['original_phase2_32k_freeze_sha256']=oldfreeze['sha256'];freeze['CLI_environment_budget_override']={'OPENCODE_EXPERIMENTAL_OUTPUT_TOKEN_MAX':'64000'};freeze['status']='DISABLED_64K_PROPOSAL_SOURCE_PATCHES_NOT_APPLIED'
freeze=seal(freeze);fref=put('draft/freeze.64k.CANDIDATE.json',freeze)
mapping=[];newrecords=[]
for row in oldroster['records']:
 slot=row['slot_id'];pack=read(P/'inputs/packs'/f'{slot}.json');claim=read(P/'inputs/uncommitted-claims'/f'{slot}.json')
 for obj in [pack,claim]:assert obj['sha256']==sha(canon({k:x for k,x in obj.items() if k!='sha256'}))
 newpack=copy.deepcopy(pack);newpack['configuration']['max_completion_tokens']=64000;newpack['configuration_sha256']=sha(canon(newpack['configuration']));newpack['freeze_sha256']=freeze['sha256'];newpack=seal(newpack)
 newclaim=copy.deepcopy(claim);newclaim['request_sha256']=newpack['sha256'];newclaim['freeze_sha256']=freeze['sha256'];newclaim=seal(newclaim)
 newrow=copy.deepcopy(row)
 newrow.update(request_sha256=newpack['sha256'],claim_sha256=newclaim['sha256'],config_file_sha256=configref['file_sha256'],freeze_sha256=freeze['sha256'])
 assert newpack['prompt']==pack['prompt'] and newpack.get('parents')==pack.get('parents')
 assert newpack['serialized_messages_sha256']==pack['serialized_messages_sha256'] and newclaim['claim_id']==claim['claim_id']
 put('draft/packs/'+slot+'.json',newpack);put('draft/uncommitted-claims/'+slot+'.json',newclaim)
 mapping.append({'position':row['position'],'order':row['order'],'slot_id':slot,'arm':row['arm'],'old_request_sha256':row['request_sha256'],'new_request_sha256':newrow['request_sha256'],'old_claim_sha256':row['claim_sha256'],'new_claim_sha256':newrow['claim_sha256'],'claim_id_unchanged':True,'prompt_bytes_sha256':sha(pack['prompt'].encode()),'serialized_messages_sha256_unchanged':True,'parents_unchanged':True,'parent_snapshot_sha256_unchanged':True,'old_config_sha256':row['config_file_sha256'],'new_config_sha256':newrow['config_file_sha256'],'old_freeze_sha256':row['freeze_sha256'],'new_freeze_sha256':freeze['sha256']})
 newrecords.append(newrow)
put('REQUEST_HASH_MAPPING.64k.CANDIDATE.json',{'status':'DERIVED_DATA_ONLY_PENDING_ENTRY_MIGRATION_REVIEW','basis_freeze_ref':fref,'records':mapping,'parent_tickets':sum(len(r['parents']) for r in oldroster['records'])})
roster=copy.deepcopy(oldroster);roster['records']=newrecords;roster['freeze_sha256']=freeze['sha256'];roster=seal(roster);put('draft/roster.64k.CANDIDATE.json',roster)
head=copy.deepcopy(oldhead);head['freeze_sha256']=freeze['sha256'];head=seal(head);put('draft/index.budget64k.CANDIDATE.json',head)
put('draft/GEN_BINDING_REQUIREMENTS.json',{'generation_execution_granted':False,'numeric_execution_granted':False,'producer_init_reentry':False,'new_policy_ref':pref,'new_accounting_ref':aref,'new_inclusive_supplement_ref':sref,'new_config_ref':configref,'new_freeze_ref':fref,'new_roster_sha256':roster['sha256'],'new_request_sha256':[r['request_sha256'] for r in newrecords],'same_slot_order':[r['slot_id'] for r in newrecords],'pending': ['Review and apply independent source copies from3 budget patches, plus narrow bootstrap migration adaptation','Build revised PLAN/package manifest/consumer contract/gate/context/composition after source and migration review; all180 context request hashes and roster/plan/binding hashes change; operationIds unchanged','Separately authorize one same-identity empty-head migration with once-only journal and exact source/oldhead/newhead refs, retain real receipt/readback; no GEN','New entry must import old46 costs once plus measured migration increments into unchanged60SELF/240local pool; no INIT execution','Only after migration independent acceptance issue new exact64k GEN grant, never change old32k grant'], 'real_migrated_head_receipt':None,'new_generation_activation':None})
checks={'same_slot_order':True,'60_unique_requests':len(mapping)==len({r['new_request_sha256'] for r in mapping})==60,'30_each':{a:sum(r['arm']==a for r in mapping) for a in ['EOH_TC','IID_TC']},'78_parent_tickets':sum(len(r['parents']) for r in oldroster['records'])==78,'all_prompt_message_parents_unchanged':True,'old_capture_rejects64000':not (0<64000<=32000),'only_config_change_output_limit':True,'SDK_default_cap_with64k_model':min(64000,32000),'SDK_with_explicit64k_override':min(64000,64000),'same_legacy_head_rejected_by_new_freeze':oldhead['freeze_sha256']!=freeze['sha256'],'bootstrap_receipt_exact_equality_requires_adapter':True,'fixtures_kind':'stdlib metadata/invariant fixture; no repository imports, CLI launch, SDK request, or actual migration; production integration not claimed'}
assert checks['60_unique_requests'] and checks['30_each']=={'EOH_TC':30,'IID_TC':30} and checks['78_parent_tickets']
b=copy.deepcopy(config);b['provider']['zhipuai-coding-plan']['models']['glm-5.3']['limit']['output']=32000
assert b==json.loads(oldconfig)
put('OFFLINE_DATA_FIXTURE_REPORT.json',checks)
after=snapshot();assert before==after;put('evidence/PRODUCTION_AFTER.json',after)
for p,data in originalsrc.items():assert pathlib.Path(p).read_bytes()==data
c=resource.getrusage(resource.RUSAGE_SELF)
report={'status':'FEASIBLE_WITH_REVIEWED_BUDGET_AMENDMENT_AND_ONE_EMPTY_HEAD_MIGRATION; NOT_RUNNABLE_YET','root':str(N),'requests':60,'parent_tickets':78,'old_original72_preserved':True,'production_files_unchanged':len(before),'original_sources_unchanged':True,'old32k_candidates_preserved':True,'INIT_handoff_SHA256':sha(handoffpath.read_bytes()),'original_INIT_measurements':46,'Library_authenticated_read_calls':1,'Library_read_targets':2,'Library_writes':0,'GEN_calls':0,'model_calls':0,'CLI_launches':0,'numerical_runs':0,'heldout_dataset_reads':0,'credential_reads_or_outputs':0,'scope_correction':'An overbroad rg earlier read historical scheduler/parent metadata; no dataset or candidate code executed, those values not used for this amendment. Subsequent reads restricted to named configuration/request/source bindings.','CPU_self_checkpoint_seconds':(c.ru_utime+c.ru_stime)-(cpu.ru_utime+cpu.ru_stime),'local_wall_checkpoint_seconds':time.monotonic()-start,'checkpoint_tails':None,'remaining_blockers':['No approved migration adapter/source exists in current contract; only proposed diff and protocol here','3 budget module patches are not applied; reference manifest/v2 entry bootstrap require separately versioned pins','No migration receipt/new GEN grant, hence GEN disabled'],'refs':{'amendment':amendref,'config':configref,'freeze':fref,'fresh_P2':fresh}}
put('REPORT.json',report)
print(json.dumps({'root':str(N),'requests':60,'parent_tickets':78,'new_config_SHA256':configref['file_sha256'],'new_freeze_seal':freeze['sha256'],'amendment_ref':amendref,'production_unchanged':True,'Library_writes':0,'model_calls':0,'pending_migration_adapter':True}))
