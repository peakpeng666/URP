# P2 64000 预算补充：禁用准备稿

结论：可以复用已初始化的 P2 Library 身份，通过一次明确的空头预算版本迁移承接。当前已审 32k 契约不会自然接受 64k，需要审阅新预算文件、独立源码副本和窄的启动 head/INIT 证据适配。本目录不具备生产启用条件；所有原文件保持原字节。

## 实际出站字段

config 的 provider.zhipuai-coding-plan.models.glm-5.3.limit.output 原为 32000。冻结 OpenCode 1.18.34 二进制和同版官方源码均采用 min(model.limit.output, outputTokenMax)，默认 outputTokenMax=32000；其结果进入 SDK maxOutputTokens，openai-compatible SDK 将它编码为 max_tokens。模型侧最大输出并不能解除 CLI 的默认截断。

因此两个值必须同步为 64000：
- 新 config 的 limit.output=64000。
- 原 command_for 清除全部继承的 OPENCODE_* 后，在自己的 overrides 中显式加入 OPENCODE_EXPERIMENTAL_OUTPUT_TOKEN_MAX=64000。仅设置外部环境无效。

该变量为冻结官方 CLI 已有的数值开关，CLI 不替换、不伪装、无新增 provider/客户端。证据见 evidence/BINARY_SDK_STATIC_EVIDENCE.json。官方原始源码：
- https://raw.githubusercontent.com/anomalyco/opencode/v1.18.34/packages/opencode/src/provider/transform.ts
- https://raw.githubusercontent.com/anomalyco/opencode/v1.18.34/packages/opencode/src/session/llm.ts

这里验证的是配置和静态代码链。没有发送模型请求，没有 HTTP 抓包，wire_parameters 与物理 HTTP 尝试次数继续未知。

## 最小已审代码 diff（均未应用）

patches 中给出3个唯一模块的精确差异及预计字节 SHA；只做语法解析，没有 import/执行这些源码：
1. capture_v2.py：精确接受本预算阶段的64000；显式 CLI 数值开关。
2. phase2_producer_bridge.py：reservation/status 两处从32000改64000；收到 cli_error_event 后停止下一 slot，覆盖额度不足不能被安全辨识时的保守停止。
3. durable_generation_sidecar.py：policy 与 slot ledger 精确预算改64000；政策、会计、inclusive supplement 常量钉本目录的独立禁用派生文件，所有 CPU/wall 池额度保持原值。

尚需第四处入口差异：production_generation_entry_v2.py.bootstrap_receipts 目前把真实 INIT v2 的旧 index receipt 与 GEN 启动 head receipt 比较相等。一次迁移产生新 receipt 后，此条件必失败。应按 BOOTSTRAP_MIGRATION_PROTOCOL.json 的窄分支验证 old INIT -> 确认迁移 -> new head，仍原样调用 gen_importer_v2 读取并验证原46项；然后只追加真实迁移的计量。原恢复模块、真实 INIT、其 grant 与 source pins 不改、不执行。这里只列验证协议，未引入一个可以越过 gate 的实现。

reference/generation/OPERATING_SOURCE_MANIFEST.json、入口硬钉的 manifest SHA、双根 Library hooks 的 source bindings 也要随独立副本重新钉定。原代码路径和原35 pins 均保留，不原地改。源路径迁移的重绑定不得误把未改代码计为新科学配置。

## 数据与 hash 影响

本目录已经派生新 config、freeze、60 packs/claims、roster、RESOURCE_SCOPE、政策/会计/inclusive supplement，以及60项旧→新 request/claim hash 映射。配置只改变 output；freeze 的配置、config/exporter/资源 binding 和附加预算谱系字段相应改变；全部 request configuration/freeze/seal、claim request/freeze/seal、roster records/seal 相应改变。claim_id 按原 run+slot 标识保持不变。prompt、serialized messages、slot/order/arm/operator、父列表和重复父票、snapshot/种子选择来源保持原样。30 EOH、30 IID、78张亲本票。

派生 freeze 当前钉定的是3个预算 diff 中的预计 exporter bytes。入口迁移适配及其 pin 尚未落地，因此这些是明确禁用的数据候选，不能拿此 mapping 直接启用。

随后还必须更新新 PLAN、PACKAGE_MANIFEST、consumer contract、bridge gate、GEN grant、180个上下文及 composition 中的派生 plan/roster/request/binding/source hashes。operationId继续原合法格式。这些未发成生产启用文件；不得把64k直接塞进旧32k grant。

原模型 glm-5.3、high、temperature0.7、top_p0.9、steps2、tools=false、900秒、outer_retries0、Coding Plan端点、无付费fallback都保留。预算按阶段标注：P0/P1原72请求32k；P2尚未执行60请求64k。不可声称132全程相同32k。旧失败不补跑。

## namespace 与成本

真实只读拿到现有 P2 head/backing 完整859字节，与原空头v0字节相等，rows=0。本次原生 read 的 version_id 为 null；版本0来自原真实 commit receipt，不能伪称本次工具返回版本0。原GEN journals不存在；不声称证明全局没有未提交并发进程。

推荐：一次独立授权的同身份 index 版本迁移，只修改 freeze 到新预算并重新seal；run、P1 predecessor、arms/caps、空 rows/archives均不变。Library新版本号/receipt/readback须取自真实工具结果，当前均为null。archive及其receipt不变。原index.initial.json、v0receipt、原INIT证据仍保留。这个额外动作并非现有契约的普通GEN stage，故需要一次性迁移 intent/receipt 验证协议与精确启用授权。无需第二次 INIT 或重新做科研流程。

原 v2 SHA 2645a52293ad256e90d50729bac7fb015209d950e516035f82ebeb86253a1f66、46计量原样保留，仅导入一次。迁移本地预检/写回/核对等所有可观测SELF及monotonic窗口追加到原初末池60SELF/240local；Library elapsed、JS CPU、fsync/exit尾部未知仍未知，禁止用0填补，禁止新池/重置。当前准备成本的观测 checkpoint 单列在 REPORT.json，完整CPU上限仍未建立。

仅在没有可审计迁移协议、旧头已非空或存在未决派发时，才讨论独立预算分支；不自行另起namespace消除旧INIT成本。

## 当前验证范围与待执行顺序

OFFLINE_DATA_FIXTURE_REPORT.json 验证60哈希映射、30/30、78票、prompt不变、旧32k gate拒64k、SDK双开关预算。OFFLINE_PATCH_SYNTAX_REPORT.json验证3个diff预计字节和语法。均不声称生产迁移适配已通过可信执行fixture。

1. 独立审阅预算补充、3个diff及入口迁移协议；允许后在独立源码副本实现窄适配、重新钉全部派生绑定，做完全离线的成功/陈旧head/未决写/重复迁移/超池 fixture。
2. 精确授权并只做一次真实空头迁移，保留原v0及真实新receipt/readback/计量；未知即停。
3. 独立验收迁移后，发新的精确64k GEN grant，再执行原60slot。CLI error/额度不足即停，剩余未发slot保留，不切换按量端点、不购买、不重试、不替换。

本轮模型/CLI/GEN/数值执行/Library写入均0。此目录仅本地准备；未上传或发布。

