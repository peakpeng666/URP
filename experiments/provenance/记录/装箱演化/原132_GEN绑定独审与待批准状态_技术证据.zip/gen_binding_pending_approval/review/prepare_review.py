import json,hashlib,pathlib,collections
R=pathlib.Path(__file__).resolve().parent.parent; O=R/'review_phase2_gen_binding_20261006'
def read(p):return json.loads((R/p).read_bytes())
def sha(b):return hashlib.sha256(b).hexdigest()
def canon(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def out(n,v):(O/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
P='original132_phase2_gen_activation_prefill_20261006/'
g=read(P+'GEN_GRANT.disabled.json');b=read(P+'BRIDGE_GATE.disabled.json');c=read(P+'CONSUMER_CONTRACT.candidate.json');rt=read(P+'LIBRARY_RUNTIME.disabled.json');r2=read('audit_phase2_recovery_implementation_20261006/r2/received/GEN_IMPORT_COMPATIBILITY.DRAFT.json');mf=read('original132_phase2_generation_accounting_20261006/OPERATING_SOURCE_MANIFEST.json')
checks={}
checks['old_prefill_canonical_contract_pin']=sha(canon(c))==g['binding_sha256']=='dcee9d28311bf06d3efb6d656cac0847e3fb08492138064683f05c6aba049141'
checks['sixty_unique_original_requests']=len(c['records'])==len(set(x['request_sha256'] for x in c['records']))==60
checks['sixty_unique_original_slots']=len(set(x['slot_id'] for x in c['records']))==60
checks['original_orders_73_to_132']=[x['order'] for x in c['records']]==list(range(73,133))
checks['original_78_parent_tickets']=sum(len(x['parents']) for x in c['records'])==78
checks['all_original_slot_request_arrays_equal']=g['authorized_slot_order']==b['authorized_slot_order']==rt['slotIds']==[x['slot_id'] for x in c['records']] and g['authorized_request_sha256']==b['authorized_request_sha256']==[x['request_sha256'] for x in c['records']]
ctx=rt['contexts']; expected=[]
for i,rec in enumerate(c['records'],1):
 for stage in ('claim_commit','archive_commit','terminal_commit'):
  expected.append({'binding_sha256':sha(canon(c)),'operationId':f'p2_{i:02d}_{stage}','plan_sha256':c['plan_sha256'],'request_sha256':rec['request_sha256'],'roster_sha256':c['roster_sha256'],'scope':'slot','slotId':rec['slot_id'],'source_sha256':sha(canon(g['operational_source_files'])),'stage':stage})
checks['all_180_original_contexts_exact']=ctx==expected
checks['180_unique_legal_op_ids']=len(ctx)==len(set(x['operationId'] for x in ctx))==180 and all(':' not in x['operationId'] for x in ctx)
checks['old_all_execution_review_flags_false']=not g['generation_execution_granted'] and not g['implementation_review_accepted'] and not b['enabled'] and not b['parent_review_accepted'] and not b['original_head_current_confirmed'] and not rt['generation_execution_granted']
checks['old_nine_implementation_hashes_match']=all(sha((R/'original132_phase2_generation_accounting_20261006'/n).read_bytes())==s for n,s in mf['production_files'].items())
checks['r2_six_hashes_match']=len(r2['new_compatibility_source_files'])==6 and all(sha((R/'audit_phase2_recovery_implementation_20261006/r2/received/src'/pathlib.Path(p).name).read_bytes())==s for p,s in r2['new_compatibility_source_files'].items())
checks['r2_nine_reference_hashes_match']=len(r2['generation_reference_dependencies'])==9 and all(sha((R/'audit_phase2_recovery_implementation_20261006/r2/received/references/generation'/pathlib.Path(p).name).read_bytes())==s for p,s in r2['generation_reference_dependencies'].items())
checks['r2_original_function_mapping']=set(g['local_call_targets'])==set(r2['local_call_targets']) and all(v['function']==k and v['sha256']==mf['production_files']['production_generation_entry.py'] and v['path'].endswith('/references/generation/production_generation_entry.py') for k,v in r2['local_call_targets'].items())
checks['original_manifest_file_pin']=sha((R/'original132_phase2_generation_accounting_20261006/OPERATING_SOURCE_MANIFEST.json').read_bytes())==g['operational_source_manifest_file_sha256']=='268030b9810ba65a7444948e6ba5056bff6c11a2ee7cd82f96bf34699423e84b'
summary={'schema':'phase2-gen-independent-review-preparation-v1','status':'PREPARATION_ONLY_WAIT_ACTUAL_DISABLED_GEN_CANDIDATE','checks':checks,'all_checks_pass':all(checks.values()),'baseline_sizes':{'old_operational_map':len(g['operational_source_files']),'package_files':len(c['source_files']),'external_source_files':len(c['external_source_files']),'original_gen_sources':9,'new_r2_sources':6,'r2_original_reference_sources':9,'local_call_targets':6,'library_contexts':len(ctx),'requests':60,'parent_tickets':sum(len(x['parents']) for x in c['records'])},'old_pins':{'contract_canonical_sha256':sha(canon(c)),'operational_source_map_canonical_sha256':sha(canon(g['operational_source_files'])),'plan_sealed_sha256':c['plan_sha256'],'roster_sealed_sha256':c['roster_sha256'],'package_manifest_sealed_sha256':c['package_manifest_sha256'],'package_manifest_file_sha256':c['package_manifest_file_sha256']},'r2_required_sources':r2['new_compatibility_source_files'],'r2_required_original_references':r2['generation_reference_dependencies'],'r2_required_local_targets':r2['local_call_targets'],'mutation_counters':{'production':0,'source':0,'models':0,'candidates':0,'heldout_reads':0,'library_writes':0},'claims_not_made':['actual producer contract freshness','actual GEN candidate accepted','production activation permission','whole CPU upper bound']}
out('PREPARATION_CHECKS.json',summary)
inputs=[*list((R/P).glob('*.json')),R/'original132_phase2_generation_accounting_20261006/OPERATING_SOURCE_MANIFEST.json',*[R/'original132_phase2_generation_accounting_20261006'/n for n in mf['production_files']],R/'audit_original132_phase2_generation_accounting_20261006/GENERATION_ENGINEERING_ACCEPTANCE.json',R/'audit_phase2_recovery_implementation_20261006/r2/R2_AUDIT_REPORT.md',R/'audit_phase2_recovery_implementation_20261006/r2/R2_AUDIT_STATUS.json',R/'audit_phase2_recovery_implementation_20261006/r2/importer_independent/R2_FINDINGS.md',*[R/'audit_phase2_recovery_implementation_20261006/r2/received/src'/pathlib.Path(p).name for p in r2['new_compatibility_source_files']],*[R/'audit_phase2_recovery_implementation_20261006/r2/received/references/generation'/pathlib.Path(p).name for p in r2['generation_reference_dependencies']]]
out('READ_ONLY_BASELINE.json',{str(p.relative_to(R)):{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in inputs})
print(json.dumps({'all_checks_pass':all(checks.values()),'checks':checks,'baselines':len(inputs)},indent=2))
