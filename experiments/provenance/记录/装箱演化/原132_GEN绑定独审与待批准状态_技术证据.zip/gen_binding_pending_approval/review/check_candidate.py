from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parent.parent; O=R/'review_phase2_gen_binding_20261006/candidate_1615'; C=O/'received'
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def digest(v):return hashlib.sha256(canon(v)).hexdigest()
def ck(k,b):checks[k]=bool(b)
checks={}; mf=read(C/'FILE_MANIFEST.json'); pathmap=read(C/'SOURCE_PATH_MAP.json');g=read(C/'GEN_GRANT.CANDIDATE.json'); gate=read(C/'BRIDGE_GATE.CANDIDATE.json'); co=read(C/'GEN_COMPOSITION.CANDIDATE.json'); ctx=read(C/'LIBRARY_CONTEXTS.CANDIDATE.json'); c=read(C/'evidence/CONSUMER_CONTRACT.original.json');old=read(R/'original132_phase2_gen_activation_prefill_20261006/CONSUMER_CONTRACT.candidate.json'); init=read(R/'audit_phase2_recovery_implementation_20261006/actual_terminal_1552/GEN_BINDING_INPUTS.NOT_ACTIVATION.json');pre=read(R/'review_phase2_gen_binding_20261006/PREPARATION_CHECKS.json');src=g['operational_source_files']; cr='/workspace/original132-phase2-gen-disabled-bindings-20261006-66g8t9xp/'
ck('manifest_exact84',len(mf['files'])==84 and set(mf['files'])=={str(p.relative_to(C)) for p in C.rglob('*') if p.is_file()}-{'FILE_MANIFEST.json'} and all((C/n).stat().st_size==v['bytes'] and sha(C/n)==v['sha256'] for n,v in mf['files'].items()))
ck('canonical_candidate_files',all((C/f).read_bytes()==canon(read(C/f)) for f in ['GEN_GRANT.CANDIDATE.json','BRIDGE_GATE.CANDIDATE.json']))
ck('original_consumer_contract_exact',c==old and sha(C/'evidence/CONSUMER_CONTRACT.original.json')==digest(c)==g['binding_sha256'])
ck('full35pins_exact',len(src)==35 and all(p in pathmap and sha(C/pathmap[p])==h for p,h in src.items()))
ck('r2_six_and_reference_nine_exact',all(src.get(p)==h for key in ['new_source_pins','entry_runtime_original_reference_pins'] for p,h in init[key].items()))
ck('all35_known_reviewed_hashes',set(src.values()) <= set(read(R/'original132_phase2_gen_activation_prefill_20261006/GEN_GRANT.disabled.json')['operational_source_files'].values())|set(init['new_source_pins'].values()))
ck('manifest_and_policy_pins_unchanged',g['operational_source_manifest_file_sha256']==sha(C/'evidence/ORIGINAL9_MANIFEST.original.json')==sha(C/'evidence/REFERENCE9_MANIFEST.original.json')=='268030b9810ba65a7444948e6ba5056bff6c11a2ee7cd82f96bf34699423e84b' and c['policy_file_sha256']==sha(C/'evidence/POLICY.original.json') and c['accounting_file_sha256']==sha(C/'evidence/ACCOUNTING.original.json') and g['inclusive_wall_supplement_file_sha256']==sha(C/'evidence/INCLUSIVE_SUPPLEMENT.original.json'))
ck('exact_original_six_function_targets',g['local_call_targets']==co['local_call_targets']==init['local_call_targets'])
ck('all_entry_helpers_pinned',len(g['entry_source_files'])==5 and all(p in src for p in g['entry_source_files'].values()) and len(g['local_helper_source_files'])==4 and all(src.get(p)==h for p,h in g['local_helper_source_files'].items()))
ck('original_sixty_arrays',g['authorized_slot_order']==gate['authorized_slot_order']==co['slotIds']==[r['slot_id'] for r in old['records']] and g['authorized_request_sha256']==gate['authorized_request_sha256']==[r['request_sha256'] for r in old['records']])
expected=[]
for i,r in enumerate(c['records'],1):
 for stage in ['claim_commit','archive_commit','terminal_commit']:
  expected.append({'binding_sha256':digest(c),'operationId':f"{r['slot_id']}:{stage}",'plan_sha256':c['plan_sha256'],'request_sha256':r['request_sha256'],'roster_sha256':c['roster_sha256'],'scope':'slot','slotId':r['slot_id'],'source_sha256':digest(src),'stage':stage})
ck('all180contexts_exact35digest',ctx['context_count']==180 and [v['context'] for v in ctx['contexts']]==expected and [v['position'] for v in ctx['contexts']]==[i for i in range(1,61) for _ in range(3)] and ctx['source_sha256']==digest(src)=='57e9937bd8693fb7fc6cc58c4ab52bacdc57d73887e92d619239f82865a76a73')
ck('180unique_operation_ids',len({v['context']['operationId'] for v in ctx['contexts']})==180)
ck('operation_ids_compatible_with_retention',all(':' not in v['context']['operationId'] for v in ctx['contexts']))
ck('v2_actual_refs_exact',all(g[k]==init[k] for k in ['namespace_initialization_handoff','reconciliation_grant_ref','entry_initial_head','entry_initial_archive_receipt']))
h=read(C/'evidence/RECONCILED_HANDOFF.v2.exact.json');ck('v2_actual_resource_only46',sha(C/'evidence/RECONCILED_HANDOFF.v2.exact.json')==g['namespace_initialization_handoff']['file_sha256'] and len(h['measurements'])==46 and g['init_resource_import']['only_handoff_ref']==g['namespace_initialization_handoff'] and g['init_resource_import']['v1_downgrade_allowed'] is False and g['init_resource_import']['new_budget'] is False and g['init_resource_import']['pool']==init['pool'])
ck('same_exact_initial_receipts',sha(C/'evidence/P2_INDEX_COMMIT.exact.json')==g['entry_initial_head']['receipt_file_sha256'] and sha(C/'evidence/P2_INDEX_INITIAL.exact.json')==g['entry_initial_head']['index_file_sha256'] and read(C/'evidence/P2_ARCHIVE_COMMIT.exact.json')==g['entry_initial_archive_receipt'] and h['index_receipt']==read(C/'evidence/P2_INDEX_COMMIT.exact.json') and h['archive_receipt']==g['entry_initial_archive_receipt'])
ck('gate_file_binding',g['bridge_gate_path']==cr+'BRIDGE_GATE.CANDIDATE.json' and g['bridge_gate_file_sha256']==sha(C/'BRIDGE_GATE.CANDIDATE.json'))
ck('all_candidate_flags_disabled',all(g[k] is False for k in ['generation_execution_granted','implementation_review_accepted','numeric_execution_granted']) and all(gate[k] is False for k in ['enabled','generation_execution_granted','numeric_execution_granted','parent_review_accepted','original_head_current_confirmed']) and co['generation_execution_granted'] is False)
ck('fixed_single_namespaces',g['sidecar_root']==co['paths']['journalRoot']==g['producer_workspace']+'/phase2-generation-accounting' and gate['producer_workspace']==g['producer_workspace'] and gate['bridge_journal_root']==g['producer_workspace']+'/phase2-bridge-journal')
refs=[];missing=[]
def walk(v):
 if isinstance(v,dict):
  if set(v)=={'path','file_sha256'}:
   p=v['path'];q=C/p[len(cr):] if p.startswith(cr) else C/pathmap[p] if p in pathmap else None
   if q is not None:refs.append({'ref':v,'verified':q.is_file() and sha(q)==v['file_sha256']})
   else:missing.append(v)
  for v1 in v.values():walk(v1)
 elif isinstance(v,list):
  for v1 in v:walk(v1)
for f in ['GEN_GRANT.CANDIDATE.json','BRIDGE_GATE.CANDIDATE.json','GEN_COMPOSITION.CANDIDATE.json','PARENT_BINDINGS.CANDIDATE.json']:walk(read(C/f))
ck('all_direct_activation_refs_exact',not missing and all(v['verified'] for v in refs))
fr=read(C/'FROZEN_REQUEST_BINDINGS.json');ck('frozen_records_and78tickets_exact',fr['request_count']==60 and [r['record'] for r in fr['records']]==c['records'] and fr['parent_ticket_count']==78 and all(r['model_slots']==1 and r['parent_ticket_count']==len(r['record']['parents'])  for r in fr['records']))
ck('request_pack_claim_pins_exact',all(fr0[key]['path']==c['package_path']+'/'+folder+'/'+fr0['record']['slot_id']+'.json' and fr0[key]['file_sha256']==c['source_files'][folder+'/'+fr0['record']['slot_id']+'.json'] for fr0 in fr['records'] for key,folder in [('pack_ref','inputs/packs'),('claim_ref','inputs/uncommitted-claims')]))
deps=read(C/'audit/FROZEN_DEPENDENCY_CHECKS.json');exp={c['package_path']+'/'+p:h for p,h in c['source_files'].items()};exp.update({c['external_source_root']+'/'+p:h for p,h in c['external_source_files'].items()});ck('producer633_dependency_attestation_exact',len(deps['files'])==633 and {v['path']:v['file_sha256'] for v in deps['files']}==exp and deps['all_exact'] is True and deps['heldout_named_dependency_count']==0)
local_drift=[];missing_local=[]
for p,h0 in c['source_files'].items():
 q=R/'original132_phase2_continuation_draft_20261006'/p
 if not q.is_file():missing_local.append(str(q))
 elif sha(q)!=h0:local_drift.append(str(q))
for p,h0 in c['external_source_files'].items():
 q=R/p
 if not q.is_file():missing_local.append(str(q))
 elif sha(q)!=h0:local_drift.append(str(q))
ck('local_original633_byte_hashes',not local_drift and not missing_local)
prov=read(R/'original132_phase2_continuation_draft_20261006/INTERNAL_PARENT_PROVENANCE.json');byid={r['id']:r for r in prov['records']};tickets=[]
for r,fr0 in zip(c['records'],fr['records']):
 pr=byid[r['slot_id']]
 for i,(pid,pv) in enumerate(zip(r['parents'],pr['parent_provenance']),1):
  tickets.append({'position':r['position'],'order':r['order'],'slot_id':r['slot_id'],'request_sha256':r['request_sha256'],'ticket_position':i,'parent_id':pid,'parent_snapshot_sha256':r['parent_snapshot_sha256'],**{k:pv[k] for k in ['code_sha256','description_sha256','pair_sha256']}})
ck('all78_parent_artifact_tickets_exact',read(C/'PARENT_TICKETS.FROZEN.json')['tickets']==tickets and len(tickets)==78)
ck('original_P1_snapshots_exact',read(C/'PARENT_SNAPSHOTS.FROZEN.json')['snapshots']==prov['P1'])
ck('all60_request_parent_pair_arrays_exact',all(r['parent_pair_hashes']==[p['pair_sha256'] for p in byid[r['record']['slot_id']]['parent_provenance']] for r in fr['records']))
ck('frozen_model_config_exact',read(C/'evidence/FREEZE.original.json')['configuration']==read(R/'original132_phase2_gen_activation_prefill_20261006/NATIVE_AND_SCIENCE_EXPECTATIONS.json')['configuration'])
ck('INIT_before_after_identical',read(C/'audit/INIT_PRODUCTION_BEFORE.json')==read(C/'audit/INIT_PRODUCTION_AFTER.json'))
res={'status':'INDEPENDENT_STATIC_REVIEW','checks':checks,'passed':sum(checks.values()),'total':len(checks),'all_passed':all(checks.values()),'direct_refs_checked':len(refs),'direct_refs_missing':missing,'local633_missing':missing_local,'local633_drift':local_drift,'candidate_pair':{f:sha(C/f) for f in ['GEN_GRANT.CANDIDATE.json','BRIDGE_GATE.CANDIDATE.json']},'unresolved':['All180 candidate operation IDs contain colon and must be rebound','Fresh P1 current-head evidence pending'],'production_activation_authorized':False}
(O/'INDEPENDENT_STATIC_VERIFICATION.json').write_text(json.dumps(res,indent=2,ensure_ascii=False)+'\n');print(json.dumps(res,indent=2,ensure_ascii=False))
