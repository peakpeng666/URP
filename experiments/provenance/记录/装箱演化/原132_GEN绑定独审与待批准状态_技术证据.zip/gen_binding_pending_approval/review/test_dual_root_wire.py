"""Bounded TEST_ONLY wire fixture, zero network/model/candidate/real Library calls.
Copies exact35 source bytes into a disposable review namespace. Uses original
real policy gates and full633 byte checks. Does not execute production stages.
Original46 measurements are copied as inherited evidence into this TEST_ONLY
journal only; this is not production import and does not modify their source.
One benign TEST_ONLY pass helper is the only runnable helper allowed by setup.
"""
from pathlib import Path
import copy,hashlib,json,sys,subprocess,shutil,inspect,os
R=Path(__file__).resolve().parent.parent;O=R/'review_phase2_gen_binding_20261006/candidate_1615';C=O/'received';T=O/'TEST_ONLY_dual_root_wire';T.mkdir(exist_ok=False)
def rd(p):return json.loads(Path(p).read_bytes())
def canon(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def hs(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def digest(x):return hashlib.sha256(canon(x)).hexdigest()
def wr(p,v):Path(p).parent.mkdir(parents=True,exist_ok=True);Path(p).write_bytes(canon(v))
g0=rd(C/'GEN_GRANT.CANDIDATE.json');m=rd(C/'SOURCE_PATH_MAP.json');g=copy.deepcopy(g0);c=rd(C/'evidence/CONSUMER_CONTRACT.original.json'); co=rd(C/'GEN_COMPOSITION.CANDIDATE.json')
pathmap={p:str(T/'source_copy'/p.removeprefix('/')) for p in g['operational_source_files']}
for p,h in g['operational_source_files'].items():
 q=Path(pathmap[p]);q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(C/m[p],q);assert hs(q)==h
v2p=Path(pathmap[g['v2_generation_entry_ref']['path']]);refroot=v2p.parent.parent/'references/generation'
shutil.copyfile(C/'evidence/REFERENCE9_MANIFEST.original.json',refroot/'OPERATING_SOURCE_MANIFEST.json')
# Source code itself stays byte-identical; bindings alone are relocated for TEST_ONLY.
for key in ['operational_source_files','local_helper_source_files']:g[key]={pathmap[p]:h for p,h in g[key].items()}
g['entry_source_files']={k:pathmap[p] for k,p in g['entry_source_files'].items()}
g['local_call_targets']={k:dict(v,path=pathmap[v['path']]) for k,v in g['local_call_targets'].items()}
workspace=T/'TEST_ONLY_workspace';workspace.mkdir();g['TEST_ONLY']=True;g['producer_workspace']=str(workspace);g['sidecar_root']=str(workspace/'phase2-generation-accounting');g['retention_audit_directory']=str(workspace/'retained-library-replies')
g['generation_execution_granted']=g['implementation_review_accepted']=True
c['package_path']=str(R/'original132_phase2_continuation_draft_20261006');c['external_source_root']=str(R);c['policy_path']=str(C/'evidence/POLICY.original.json');c['accounting_path']=str(C/'evidence/ACCOUNTING.original.json');g['binding_sha256']=digest(c);g['inclusive_wall_supplement_path']=str(C/'evidence/INCLUSIVE_SUPPLEMENT.original.json')
gate=rd(C/'BRIDGE_GATE.CANDIDATE.json');gate.update(TEST_ONLY=True,producer_workspace=str(workspace),bridge_journal_root=str(workspace/'phase2-bridge-journal'),enabled=True,parent_review_accepted=True,original_head_current_confirmed=True)
gate['storage']={'index_library_file_id':'libfile_TEST_ONLY_index','archive_library_file_id':'libfile_TEST_ONLY_archive'}
gp=workspace/'TEST_ONLY_gate.json';wr(gp,gate);g['bridge_gate_path']=str(gp);g['bridge_gate_file_sha256']=hs(gp)
# A benign local pass helper replaces all production helper dispatch authority.
helper=T/'TEST_ONLY_noop.py';helper.write_text('"""TEST_ONLY benign helper, no network or candidate code."""\npass\n');g['local_helper_source_files']={str(helper):hs(helper)};g['operational_source_files'][str(helper)]=hs(helper)
grantpath=T/'TEST_ONLY_grant.json';wr(grantpath,g);grantsha=digest(g)
sys.path.insert(0,str(v2p.parent));import production_generation_entry_v2 as v2
d=v2.d;assert Path(d.__file__).parent==refroot;assert d.POLICY_SHA==c['policy_file_sha256'];assert d.ACCOUNTING_SHA==c['accounting_file_sha256'];assert d.INCLUSIVE_SUPPLEMENT_SHA==g['inclusive_wall_supplement_file_sha256']
sc=d.Sidecar.create(c,g,grantsha);sc._check_sources();entry=v2.ProductionEntry(sc);entry._load()
assert all(Path(inspect.getsourcefile(fn))==refroot/'production_generation_entry.py' for fn in v2.LOCAL_FUNCTIONS.values())
# No call is made to producer functions. Prepare a test ledger and saved state only.
h=rd(C/'evidence/RECONCILED_HANDOFF.v2.exact.json');t=sc.begin('init_final','initialization');ss=sc.finish(t,local_receipts=h['measurements']);assert not ss['halt'];assert len(ss['done'][-1]['result']['local_receipts'])==46
initial=workspace/'TEST_ONLY_index.json';wr(initial,{'TEST_ONLY':True,'rows':[]});prior={'TEST_ONLY':True,'library_file_id':'libfile_TEST_ONLY_index','file_id':'file_TEST_ONLY_initial','current_version_number':0,'write_result_confirmed':True,'index_readback_confirmed':True,'local_blob_sha256':hs(initial)}
entry.save(0,'initialization',{'index':rd(initial),'receipt':prior,'index_path':str(initial)})
rec=c['records'][0];sc.reserve_slot(rec)
for stage in ['reserve_next','prepare_reserved']:
 t=sc.begin(rec['slot_id'],stage);sc.finish(t,local_receipts=[d.local_measurement(t['started'],d.self_sample())])
payload=workspace/'TEST_ONLY_claimed_index.json';wr(payload,{'TEST_ONLY':True,'rows':[],'claim':rec['slot_id']});entry.save(1,'prepare_reserved',{'index':rd(payload),'index_path':str(payload)})
pending=entry.begin_library(1,'claim_commit');token=pending['token'];hooks=Path(pathmap[co['paths']['hooksCliPath']]);launcher=Path(pathmap[co['paths']['launcherPath']]);assert hooks.parent!=refroot
n=0;calls=[]
def call(action,**kw):
 global n
 n+=1;body={'journal_root':str(sc.root),'grant_path':str(grantpath),'grant_sha256':grantsha,'token':token,'hook_id':'TEST_ONLY_hook_'+str(n),**kw}
 p=subprocess.run([sys.executable,'-I','-B',str(hooks),action],input=canon(body),capture_output=True,env={'PATH':'/usr/bin:/bin','PYTHONDONTWRITEBYTECODE':'1'},timeout=10)
 calls.append({'action':action,'exit':p.returncode,'stdout':p.stdout.decode(),'stderr':p.stderr.decode()})
 assert p.returncode==0,(action,p.stderr.decode());return json.loads(p.stdout)
entered=call('enter',pending=pending);assert entered['once_only_stage_entered']
context={'scope':'slot','slot_id':rec['slot_id'],'stage':'claim','operation_id':'p2_01_claim_commit','request_sha256':rec['request_sha256'],'plan_sha256':c['plan_sha256'],'roster_sha256':c['roster_sha256'],'binding_sha256':digest(c),'source_sha256':digest(g['operational_source_files'])}
observations=[]
def observed(kind,args,result,order):
 method='mcp__codex_apps__library_'+('replace_library_file' if kind=='write' else 'read');a=canon([args]).decode();b=canon(result).decode();intent=dict(context,schema='library-wait-intent-v1',method=method,kind=kind,observation_id=context['operation_id']+':'+kind+':1',clock_domain_id='unobservable',order=order,tool_arguments_sha256=hashlib.sha256(a.encode()).hexdigest(),arguments_json=a,resources={});obs=dict(intent,schema='library-wait-observation-v1',await_start_ms=None,await_end_ms=None,elapsed_ms=None,timing_status='unknown',outcome='returned',write_outcome='acknowledged_not_remote_byte_proof' if kind=='write' else None,serialization_status='complete_json_object',result_json=b,result_sha256=hashlib.sha256(b.encode()).hexdigest());call('before',intent=intent);call('after',observation=obs);observations.append(obs);return obs
args={'library_file_id':'libfile_TEST_ONLY_index','file':str(payload),'expected_current_version':0,'version_reason':'V2 bounded journal/wave persistence; retain identity'};item={'TEST_ONLY':True,'status':'succeeded','library_file_id':'libfile_TEST_ONLY_index','file_id':'file_TEST_ONLY_after','current_version_number':1}
obs=observed('write',args,{'structuredContent':item},1);observed('read',{'read':[{'ref_id':item['file_id'],'mode':'full','max_lines':2}]},{'structuredContent':{'results':[{'file_id':item['file_id'],'has_more':False,'content':[payload.read_text()]}]}},2)
retention=Path(g['retention_audit_directory'])/context['operation_id'];wr(retention/'intent.json',{'operation_id':context['operation_id'],'method':obs['method'],'arguments':args});wr(retention/'response.json',json.loads(obs['result_json']))
invocation=dict(context,invocation_id=context['operation_id']+':helper:1',method='exec_command',command_sha256='a'*64)
p=subprocess.run([sys.executable,'-I','-B',str(launcher),'--journal',str(sc.root),'--grant',str(grantpath),'--grant-sha256',grantsha,'--invocation-id',invocation['invocation_id'],'--command-sha256',invocation['command_sha256'],'--script',str(helper)],capture_output=True,env={'PATH':'/usr/bin:/bin','PYTHONDONTWRITEBYTECODE':'1'},timeout=10);assert p.returncode==0,p.stderr.decode()
env=call('get',invocation=invocation);assert call('verify',invocation=invocation,envelope=env);envjson=canon(env).decode();invocation.update(self_receipt_verified=True,self_receipt_json=envjson,self_receipt_sha256=hashlib.sha256(envjson.encode()).hexdigest())
receipt={'TEST_ONLY':True,'library_file_id':item['library_file_id'],'file_id':item['file_id'],'current_version_number':1,'write_result_confirmed':True,'index_readback_confirmed':True,'local_blob_sha256':hs(payload)};wr(workspace/'state/commits/libfile_TEST_ONLY_index-1.json',receipt)
snap={'schema':'library-wait-meter-v1','status':'observed','timing_mode':'unobservable','accounting_supplement_sha256':d.INCLUSIVE_SUPPLEMENT_SHA,'interval_coverage_complete':False,'unknown_reasons':[],'observations':observations,'local_helpers':[invocation]}
closed=call('close',pending=pending,snapshot=snap,receipt=receipt);assert closed['pending'] is None and not closed['halt'];status=sc.status();assert status['done'][-1]['stage']=='claim_commit' and not status['halt'];assert entry.saved(1,'claim_commit')['receipt']==receipt
# The resumed v2 sidecar sees the old-root close and rejects a repeated stage.
repeat_rejected=False
try:entry.begin_library(1,'claim_commit')
except Exception:repeat_rejected=True
assert repeat_rejected
result={'status':'PASS_BOUNDED_DUAL_ROOT_WIRE','checks':{'all35_exact_source_copies':True,'original633_full_source_checks_no_override':True,'real_policy_constants_no_override':True,'v2_load_real_five_modules_without_dispatch':True,'six_original_callable_paths':True,'exact46_rows_in_TEST_ONLY_ledger_once':True,'v2_begin_original_old_root_hooks_enter':True,'old_root_hooks_before_after_get_verify_close':True,'v2_reads_old_root_close':True,'repeat_stage_rejected':True},'source_mutations':0,'real_Library_calls':0,'model_calls':0,'candidate_executions':0,'heldout_reads':0,'native_CLI_calls':0,'boundaries_not_claimed':['actual producer GEN activation','live Library wire','actual importer execution in this fixture','scientific reserve/prepare/collect functions'], 'fixture_source_count':36,'extra_fixture_source':'TEST_ONLY benign pass helper','corrected_operation_id_only_in_fixture':'p2_01_claim_commit','original_candidate_colon_blocker_unresolved':True,'hook_processes':len(calls),'init46_evidence_only':True,'status_after':{'halt':status['halt'],'pending':status['pending'],'scopes':status['scopes']}}
wr(O/'DUAL_ROOT_WIRE_RESULTS.json',result);wr(O/'DUAL_ROOT_HOOK_TRANSCRIPT.json',calls);print(json.dumps(result,indent=2))
