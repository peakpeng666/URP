'use strict';
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const root=path.resolve(__dirname,'candidate_1615/received');
const read=f=>JSON.parse(fs.readFileSync(path.join(root,f),'utf8'));
const map=read('SOURCE_PATH_MAP.json'),co=read('GEN_COMPOSITION.CANDIDATE.json'),g=read('GEN_GRANT.CANDIDATE.json'),rows=read('LIBRARY_CONTEXTS.CANDIDATE.json').contexts;
const src=p=>fs.readFileSync(path.join(root,map[p]),'utf8');
const runner=Function(src(co.JS_composition_ref.path)+'\nreturn runPendingLibraryStage;')();
(async()=>{
 const cases=[];
 for(const mode of ['original_candidate','TEST_ONLY_legal_id']){
  const context=structuredClone(rows[0].context);if(mode!=='original_candidate')context.operationId='p2_01_claim_commit';
  const rawCalls=[];const rawTools={exec_command:async arg=>{rawCalls.push({kind:'exec',cmd:arg.cmd});if(rawCalls.length===1)return{exit_code:0,output:'{"TEST_ONLY":true,"once_only_stage_entered":true}'};throw new Error('TEST_ONLY_STOP_AT_FIRST_HELPER');}};
  const pending={timing_mode:'unobservable',stage:'claim_commit',position:1,token:{nonce:'TEST_ONLY',scope:context.slotId,request_sha256:context.request_sha256,binding_sha256:context.binding_sha256},commit_arguments:[g.producer_workspace,g.entry_initial_head.index_path,g.entry_initial_archive_receipt.library_file_id,0,true]};
  let error=null;try{await runner({rawTools,pending,context,sources:Object.fromEntries(Object.entries(co.JS_source_refs).map(([k,v])=>[k,src(v.path)])),paths:co.paths,grantSha256:co.GEN_grant_ref.file_sha256,slotIds:co.slotIds,accountingSupplementSha256:co.accountingSupplementSha256});}catch(e){error=e.message;}
  cases.push({mode,operation_id:context.operationId,error,raw_exec_calls:rawCalls.length,only_TEST_ONLY_fake_tools:true});
 }
 if(cases[0].error!=='unsafe_operation_id'||cases[0].raw_exec_calls!==1)throw new Error('negative control failed');
 if(cases[1].error!=='TEST_ONLY_STOP_AT_FIRST_HELPER'||cases[1].raw_exec_calls!==2)throw new Error('legal control failed: '+JSON.stringify(cases[1]));
 const result={status:'REPRODUCED_BLOCKER_AND_LEGAL_CONTROL',cases,all180_original_ids_invalid:rows.every(r=>!(/^[A-Za-z0-9_.-]{1,96}$/).test(r.context.operationId)),real_tools_called:0};
 fs.writeFileSync(path.resolve(__dirname,'candidate_1615/OPERATION_ID_BOUNDARY_RESULTS.json'),JSON.stringify(result,null,2)+'\n');process.stdout.write(JSON.stringify(result,null,2));
})();
