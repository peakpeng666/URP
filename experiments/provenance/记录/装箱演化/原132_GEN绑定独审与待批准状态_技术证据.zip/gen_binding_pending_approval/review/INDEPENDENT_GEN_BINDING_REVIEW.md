# 原132 P2 GEN 精确绑定独审

2026-10-06。结论：接受修订后的禁用绑定；未发现剩余源码/绑定阻断，可以由父线在原producer完成最后只读一致性检查后，另行批准精确GEN-only激活。此审阅没有写生产授权文件、启动GEN、调用模型/候选或真实Library写入。

## 接受的精确候选

修订ZIP：`59479af71edf4a27c37a3fab322a0dadcf3bc600e7c61810a6c464e8901a44c7`，127,500 B，24成员/23 manifest。

- GEN候选：`59644c8cbdc88cc80d2013fe0a95edb5ae2ba41c0908f2bda1cc77fc46fb7ebf`
- gate候选：`faa1f83bcb7e609450389390001dec78f64fb09a538f82c02a6c1300cc6f927d`
- 合法180contexts：`f9043f6c935d4df78452d2d9ef78a0e3f27b95070e6bbbd6eef0b7c5270fd36e`
- fresh P1证据：`591b2fcc9e0b59ef529430f4144f7ea2416cf0822aef422ad0f85b3ef13fd227`

修订18项检查全部通过。原完整源码包ZIP `91f725388763feaf44734a77c7f518847866bd2f40c33862cf189c2397865163` 及其被拒绝的初候选均保留，没有原地替换。

## 初候选阻断及闭合

初候选全部180个operationId含冒号，原library_wait_observer.bindStage和retainLibraryReplies均拒绝。有限可信JS测试使用真实原composition，确认会先取得durable enter租约再抛unsafe_operation_id。若直接执行会留下不可重放的pending。

修订仅把ID逐项恢复为旧预填中 `p2_01_claim_commit` 等位置/动作唯一合法映射，更新被影响refs，原slot/request/stage和source digest不变。全部180项格式、唯一性及逐位置对应独立核过。原validator源码没有放宽或修改。

## 不变科学与资源接口

原633项package/external依赖的本地原字节逐hash核验，无缺失或漂移。原consumer contract canonical SHA为 `dcee9d28311bf06d3efb6d656cac0847e3fb08492138064683f05c6aba049141`，真实producer交付字节相同。

原60请求、73..132顺序、78 parent tickets（含重复顺序）、P1 snapshots及各请求parent pair数组完全相同。glm-5.3、high、temperature0.7、top_p0.9、32000 completion、CLI900秒、steps2、tools=false、outer_retries0、无paid fallback不变。原P1候选与当前72/132 generation、165designpacks/33admissions不改；heldout未读。

35源覆盖原九源、新r2六源及其references/generation九源，同时保留所有实际entry、helper和JS路径。source-map canonical SHA仍为 `57e9937bd8693fb7fc6cc58c4ab52bacdc57d73887e92d619239f82865a76a73`。六local targets精确映射到r2目录中原reference entry及其原函数对象，SHA `686811066a7d097302fe389aef22efc64e26f7f09ef923b10f44229341f68154`。v2入口/importer正确，未退回base v1。

唯一资源入口为已独审接受的实际v2 handoff `2645a52293ad256e90d50729bac7fb015209d950e516035f82ebeb86253a1f66`，实际reconciliation grant `59d96a0a5deb67de3272d9991bfd4a83fb1c56844901bb512b5d73d7d917eb6b`，全部46=14+32 measurements恰好一次进入init_final。完整index/archive v0 receipts和初始head与实际终态相同。

生产继承观测为SELF2.2689399999999997秒、local-window1.1660925439937273秒；同60/240池不重置，GEN边界和最终化继续用此池。原slot30/1020和全阶段1860/61440是已观测admission阈值；完整CPU上界未知，NOT_ESTABLISHED。历史和checkpoint后尾部、pre-entry、JS/plugin/provider/native CPU、Library时间的unknown保持。

## 本次新增有限wire覆盖

初包静态28/29通过（唯一失败即已修复ID）。新增可信fixture针对新v2/reference sidecar与旧源路径hooks共用journal这一新连接，不重写框架。

- 35份源码逐字节复制到隔离TEST_ONLY目录，原633字节检查和policy常量真实执行，未覆盖或替换_check_sources。
- v2加载五个原模块，仅import/绑定，不调用原科学producer函数；六原callable路径保持。
- 原实际46测量原样复制到TEST_ONLY ledger用于消费端语义检查；这不是第二次生产import，没有执行生产importer。
- v2的library-begin产生真实测试pending，旧源根8个独立Python hooks进程执行enter/before/after/get/verify/close；Library返回、retention/commit为明确合成测试对象，唯一可运行helper为本地无操作pass脚本。
- v2读取到同journal的旧根close，pending为空无halt，重复同stage被拒绝。

此fixture通过；它不声称实际生产激活、真实Library wire或完整60stage科学运行。r2 importer本身与真实INIT已经分别独审，本次没有重复其全链。

## fresh P1与CLI证据

对新认证read的完整raw独立重算：2026-10-06 16:21:23–24 UTC，两目标分别为P1 stable head与backing，均明确v120，96,872 B，同SHA `c8a8f6ecabd3ee5f58d61e61f1a4c9ff04ee4dbcb534479e068d69fb05188717`，60行全部terminal，没有claimed行，原run/freeze/seal/snapshot链接相同。该证据足以支持原gate对已提交P1 current index head的字段含义。

边界明确：它是读窗内的已提交head证明，没有新执行P1本地status脚本，没有证明未提交/并发OS状态或未来不变；历史fence没有被冒称fresh。原P2当前状态仍需原producer在启动前检查。

CLI16:30只读报告显示原185,632,896 B binary存在可执行，稳定stat，SHA `9ca0b9953d49997601655e54f846a3efa464f237e47c6f1b04716d0f2e64c4c2`。没有启动binary/探测模型，也未安装替换。原capture仍会在prepare按同SHA再检查。

## 离线拟APPROVED文件，尚未执行

目录 `offline_proposed_activation/` 含完整JSON和逐字段diff，只为父线读全文后决定是否授权。它们含拟启用布尔值，但仅保存在独审本地，未写原producer。

1. `GEN_BRIDGE_GATE.PROPOSED_APPROVED.json`：7,487 B，raw与canonical SHA均为 `b61ea36e5fb107bfe32a133de4d3ef60d1d8e0a1cf13fa7274a1b2abf4704e62`。只改enabled、parent_review_accepted、generation_execution_granted三布尔为true。预期producer路径 `/workspace/original132-phase2-producer-20261006/GEN_BRIDGE_GATE.json`。
2. `GEN_SIDECAR_GRANT.PROPOSED_APPROVED.json`：19,777 B，raw与canonical SHA均为 `64ae9bd089bf634cfb936271ee92592b4d3d8c59a0f2186fea48561af9efb6f8`。只改generation_execution_granted、implementation_review_accepted两布尔与gate path/raw SHA。预期路径 `/workspace/original132-phase2-producer-20261006/GEN_SIDECAR_GRANT.json`。

均用canonical UTF-8、ensure_ascii=false、sort_keys=true、紧凑分隔、allow_nan=false、无末尾换行。raw恰好等于canonical是序列化结果，概念仍不同。正确单向顺序：gate raw SHA进入GEN grant；GEN canonical SHA进入CLI --grant-sha256与runtime grantSha256。gate不反向引用grant，不创建循环。

`GEN_RUNTIME_ARGUMENTS.PROPOSED_NOT_EXECUTED.json`提供对应固定runtime参数，保持合法contexts的精确ref，更新grant path/ref及canonical digest；它不要求新增生产代码或另一套运行框架。原描述性template note/reason保留，权威仅由父线的精确审批与明确布尔/绑定组成。

## 父线可执行决策的边界

父线必须自行审全文及新SHA，并在原producer完成只读preflight：35源、633绑定输入、实际v2/receipt/head、CLI pin未漂移；新GEN gate/grant与唯一sidecar/bridge journal未存在、无未知pending/dispatch。发现不一致立即停止，不删证据或换namespace。

父若批准，原producer仅新建上述精确文件，v2 initialize恰好一次。核46条完整继承入同池后，按原固定序列最多60逻辑请求及180真实pending Library阶段，60后finalize。未知/失败/资源越界停机，不补抽、不重放；numeric与heldout仍禁用。科学后续完成须另审，不由本报告预先证明。
