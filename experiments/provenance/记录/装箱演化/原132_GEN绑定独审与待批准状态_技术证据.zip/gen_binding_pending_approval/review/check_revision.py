from pathlib import Path
import json,hashlib,re
R=Path(__file__).resolve().parent; O=R/'revision_1631';C=O/'received';P=R/'candidate_1615/received'
def rd(p):return json.loads(p.read_bytes())
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def dg(x):return hashlib.sha256(canon(x)).hexdigest()
checks={}
def ck(k,v):checks[k]=bool(v)
mf=rd(C/'FILE_MANIFEST.json');ck('all23manifest_members',len(mf['files'])==23 and set(mf['files'])=={str(p.relative_to(C)) for p in C.rglob('*') if p.is_file()}-{'FILE_MANIFEST.json'} and all(h(C/n)==v['sha256'] and (C/n).stat().st_size==v['bytes'] for n,v in mf['files'].items()))
g=rd(C/'GEN_GRANT.CANDIDATE.json');gate=rd(C/'BRIDGE_GATE.CANDIDATE.json');co=rd(C/'GEN_COMPOSITION.CANDIDATE.json');ctx=rd(C/'LIBRARY_CONTEXTS.CANDIDATE.json');ev=rd(C/'FRESH_P1_HEAD_EVIDENCE.json');newroot=rd(C/'REVISION_REPORT.json')['candidate_root']
ck('primary_expected_hashes',h(C/'GEN_GRANT.CANDIDATE.json')=='59644c8cbdc88cc80d2013fe0a95edb5ae2ba41c0908f2bda1cc77fc46fb7ebf' and h(C/'BRIDGE_GATE.CANDIDATE.json')=='faa1f83bcb7e609450389390001dec78f64fb09a538f82c02a6c1300cc6f927d' and h(C/'FRESH_P1_HEAD_EVIDENCE.json')=='591b2fcc9e0b59ef529430f4144f7ea2416cf0822aef422ad0f85b3ef13fd227')
ck('preserved_prior_candidate_bytes',all(h(C/'evidence'/('PREVIOUS_'+f))==h(P/f) for f in ['GEN_GRANT.CANDIDATE.json','BRIDGE_GATE.CANDIDATE.json','GEN_COMPOSITION.CANDIDATE.json','LIBRARY_CONTEXTS.CANDIDATE.json']))
diff=rd(C/'BINDING_DIFF.json'); observed={}
for f,key,allowed in [('GEN_GRANT.CANDIDATE.json','GEN_changes',{'bridge_gate_file_sha256','bridge_gate_path','fresh_P1_head_evidence_ref','parent_evidence_binding_ref','preparation_execution_counts'}),('BRIDGE_GATE.CANDIDATE.json','gate_changes',{'fresh_P1_head_evidence_ref','original_head_current_confirmed','parent_evidence_binding_ref'}),('GEN_COMPOSITION.CANDIDATE.json','composition_changes',{'GEN_grant_ref','context_ref','paths'})]:
 a,b=rd(P/f),rd(C/f);actual=[{'field':k,'before':a.get(k),'after':b.get(k)} for k in sorted(set(a)|set(b)) if a.get(k)!=b.get(k)];observed[key]=actual;ck('minimal_exact_'+key,actual==diff[key] and {x['field'] for x in actual}==allowed)
a,b=rd(P/'LIBRARY_CONTEXTS.CANDIDATE.json')['contexts'],ctx['contexts'];expected=[]
for i,(a0,b0) in enumerate(zip(a,b)):
 x=json.loads(json.dumps(a0));x['context']['operationId']=f"p2_{x['position']:02d}_{x['context']['stage']}";expected.append(x)
ck('180_IDs_only_revised_to_exact_old_mapping',len(b)==len(a)==180 and b==expected)
ck('180_unique_retention_legal_ids',len({v['context']['operationId'] for v in b})==180 and all(re.fullmatch('[A-Za-z0-9_.-]{1,96}',v['context']['operationId']) for v in b))
ck('all_sources_handoff_resources_arrays_unchanged',all(g[k]==rd(P/'GEN_GRANT.CANDIDATE.json')[k] for k in ['operational_source_files','local_call_targets','entry_source_files','local_helper_source_files','namespace_initialization_handoff','reconciliation_grant_ref','init_resource_import','entry_initial_head','entry_initial_archive_receipt','authorized_slot_order','authorized_request_sha256','request_scope']))
ck('GEN_all_execution_disabled',g['generation_execution_granted'] is False and g['implementation_review_accepted'] is False and g['numeric_execution_granted'] is False and gate['enabled'] is False and gate['parent_review_accepted'] is False and gate['generation_execution_granted'] is False and gate['numeric_execution_granted'] is False and co['generation_execution_granted'] is False)
raw=rd(C/'evidence/AUTHENTICATED_P1_READ.raw.json');call=rd(C/'evidence/AUTHENTICATED_P1_READ.call.json');rows=raw['structuredContent']['results'];fresh_checks=[]
assert not raw['isError'];assert len(rows)==2
expected=ev['expected_original_P1_head'];localindex=rd(P/'evidence/P1_AUTHENTICATED_READBACK.original.json')
for r in rows:
 b='\n'.join(r['content']).encode();j=json.loads(b);fresh_checks.append({'id':r['file_id'],'library_file_id':r['library_file_id'],'version_id':r['version_id'],'has_more':r['has_more'],'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'seal':j['sha256']==dg({k:v for k,v in j.items() if k!='sha256'}),'run':j['run_id'],'freeze':j['freeze_sha256'],'terminals':sum(x['state']=='terminal' for x in j['rows']),'rows':len(j['rows']),'phases':list({x['phase'] for x in j['rows']})})
ck('fresh_head_backing_authentic_complete_shape',call['arguments']=={'read':[{'ref_id':expected['library_file_id'],'mode':'full','max_lines':2},{'ref_id':expected['file_id'],'mode':'full','max_lines':2}]} and call['real_authenticated_tool'] is True and raw['isError'] is False and all(r.get('isError',False) is False and r['has_more'] is False and str(r['version_id'])=='120' for r in rows))
ck('fresh_p1_exact_expected96872bytes60terminals',all(v['bytes']==96872 and v['sha256']==expected['index_blob_sha256']=='c8a8f6ecabd3ee5f58d61e61f1a4c9ff04ee4dbcb534479e068d69fb05188717' and v['id']==expected['file_id'] and v['library_file_id']==expected['library_file_id'] and v['seal'] and v['rows']==v['terminals']==60 and v['run']=='urp132_20261005_b01_phase1' and v['freeze']==expected['freeze_sha256'] and v['phases']==[1] for v in fresh_checks))
ck('fresh_raw_refs_exact',ev['raw_result_ref']['file_sha256']==h(C/'evidence/AUTHENTICATED_P1_READ.raw.json') and ev['call_and_actual_clock_returns_ref']['file_sha256']==h(C/'evidence/AUTHENTICATED_P1_READ.call.json'))
ck('fresh_report_preserves_status_limits',ev['coverage_limits']['fresh_producer_status_script_executed'] is False and ev['coverage_limits']['historical_local_fence_used_as_fresh_status'] is False and ev['coverage_limits']['uncommitted_or_concurrent_P1_operations'] is None)
ck('fresh_bound_to_unchanged_P1_plan',expected==rd(P/'PARENT_BINDINGS.CANDIDATE.json')['historical_P1_index_identity'] and ev['comparison']['accepted_P1_snapshot_linkage']=={s['arm']:s['sha256'] for s in rd(P/'PARENT_SNAPSHOTS.FROZEN.json')['snapshots']})
bin=rd(C/'BINARY_PRESENCE_VERIFICATION.json');ck('consumer_readonly_binary_pin_report',bin['path']=='/tmp/urp-opencode-check-i8yzygra/native/node_modules/opencode-linux-x64-baseline/bin/opencode' and bin['sha256']==bin['expected_sha256']=='9ca0b9953d49997601655e54f846a3efa464f237e47c6f1b04716d0f2e64c4c2' and bin['bytes']==185632896 and all(bin[k] is True for k in ['exists','executable','is_regular_file','stable_stat_during_hash','matches_expected']) and bin['binary_executed'] is False and bin['CLI_probes']==bin['install_or_replace_operations']==0)
ck('INIT_production_preserved',rd(C/'audit/INIT_PRODUCTION_BEFORE.json')==rd(C/'audit/INIT_PRODUCTION_AFTER.json'))
refok=[]
for obj in [g,gate,co,rd(C/'PARENT_BINDINGS.CANDIDATE.json')]:
 def walk(v):
  if isinstance(v,dict):
   if set(v)=={'path','file_sha256'} and v['path'].startswith(newroot+'/'):refok.append(h(C/v['path'].removeprefix(newroot+'/'))==v['file_sha256'])
   for x in v.values():walk(x)
  elif isinstance(v,list):
   for x in v:walk(x)
 walk(obj)
ck('new_revision_direct_refs_exact',all(refok) and len(refok)>0)
res={'status':'REVISED_DISABLED_BINDING_ACCEPTED' if all(checks.values()) else 'REVIEW_FAILURE','checks':checks,'all_passed':all(checks.values()),'revision_ref_checks':len(refok),'pass_count':sum(checks.values()),'check_count':len(checks),'fresh_independent_recomputation':fresh_checks,'actual_top_level_diffs':observed,'production_execution_performed':False,'remaining_code_blockers':[] if all(checks.values()) else [k for k,v in checks.items() if not v],'point_in_time_only':True,'uncommitted_P1_OS_fence_not_newly_proved':True};(O/'INDEPENDENT_REVISION_VERIFICATION.json').write_text(json.dumps(res,ensure_ascii=False,indent=2)+'\n');print(json.dumps(res,ensure_ascii=False,indent=2))
