# GEN 第一禁用候选独审：暂不放行

## 最小阻断

候选 ZIP SHA `91f725388763feaf44734a77c7f518847866bd2f40c33862cf189c2397865163` 保持只读。

1. 全部180个 context.operationId 使用 `slot_id:stage`，含冒号。原 meter.bindStage 及 retainLibraryReplies 都只接受 `[A-Za-z0-9_.-]{1,96}`。可信 fake 调用真实已审 JS composition，首个context会在 enter durable租约之后抛 `unsafe_operation_id`。这样直接激活会消费一次性 Library阶段租约，不能重放。最小修复仅改候选180个ID为旧已审 `p2_01_claim_commit` 等合法唯一映射，并重新封context/composition引用；不得改源validator。原候选不能按当前SHA激活。
2. fresh P1 current clean-head事实尚未补入；原候选正确保留original_head_current_confirmed=false。父线已安排原producer只读取证，必须审证据后再决定对应新绑定，不能把历史readback变成fresh。

没有发现需要改动已接受源码的额外阻断。

## 静态独立核验

28/29项通过，唯一失败为operationId格式。核验了84个manifest成员、35条真实源码路径/hash、r2六源和两个原九源目录、633项科学package/external文件原字节、25条直接引用、完整60原请求/slot顺序、78 parent artifact tickets（含重复票顺序）、P1冻结snapshots、180 context除ID格式外的全部request/binding/source/plan/roster字段。没有读取heldout数据，没有解析候选程序正文。

actual v2 handoff `2645a522…53a1f66`、实际reconciliation grant `59d96a0a…917eb6b`、完整index/archive v0 receipts与初始head全部与已接受INIT终审相同。实际46=14+32测量保留，同60 SELF/240local-window池，不降级base v1，不重置预算。

consumer contract 原字节与早先冻结重建结果相同，canonical/file SHA均为 `dcee9d28…049141`。原35source-map canonical SHA为 `57e9937b…5a76a73`。所有38份审前旧基线无字节漂移。

## 本次新增的有限跨根连接fixture

`test_dual_root_wire.py`在独立TEST_ONLY目录保留原35份源码的逐字节副本。只重定位测试bindings，加一个不做事的TEST_ONLY pass helper。原policy/accounting/supplement常量不替换，_check_sources不替换，原633个package/external字节检查真实执行。

- 新v2入口加载五个原模块成功，仅import和绑定，不派发原科学stage。
- 六个local targets均为原references/generation/production_generation_entry.py的函数对象，路径/hash gate保持。
- 实际46measurement数组原样复制进TEST_ONLY测试journal用于核验consumer计量语义；没有调用生产importer，不是第二次生产资源导入。
- v2/reference sidecar生成pending；旧源根hooks通过8个独立本地Python进程完成enter、before/after、get、verify、close；使用明确合成的Library返回/retention/commit记录，真实Library调用0。
- v2随后读到旧根close后的同一journal与receipt，pending为空、无halt；重复同阶段被拒绝。
- 测试使用合法ID，仅验证修订方向；不掩盖原候选中的冒号阻断。

该fixture关闭本次新增的“新v2/reference sidecar→旧路径hooks→同journal close”连接疑问。它不是完整生产激活、原科学reserve/prepare/collect或真实Library wire验收。实际v2 importer自身已有R2独审，实际INIT证据另有终审，不在本次重复全部链路。

## 激活前精确步骤

待修订context及fresh P1证据重新交付，独立核变化范围及全部被影响SHA。随后才能由父线形成新的approved gate/grant/runtime：gate raw SHA写入grant，grant canonical SHA写入runtime；明确只激活原60逻辑请求、每个唯一slot/dispatch最多一次。原禁用候选与历史证据不原地改。

原CLI在科学prepare路径仍按固定binary SHA检查。执行端应先只读验证该现有binary可执行/字节未漂移、35sources及633inputs、namespace clean、唯一journal未创建；不运行CLI做探测，不更换provider或模型。

全部检查的模型、候选、真实Library、生产GEN调用均为0。CPU总上界仍未知，NOT_ESTABLISHED；新fixture不改变生产预算或unknown项。
