from pathlib import Path
import json,hashlib
r=Path(__file__).resolve().parent
m=json.loads((r/"FILE_MANIFEST.json").read_text())
for n,e in m["files"].items():
 b=(r/n).read_bytes();assert len(b)==e["bytes"] and hashlib.sha256(b).hexdigest()==e["sha256"],n
print("PASS",len(m["files"]),"files; no experiment executed")
