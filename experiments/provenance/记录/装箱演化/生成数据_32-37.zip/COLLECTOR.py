#!/usr/bin/env python3
"""Serial positions 2..60 through the unchanged, approved minimal runner.

Results in the existing ledger are authoritative. This program has no restart,
retry, model HTTP client, scoring, credential inspection, or upload function.
"""
import importlib.util
import json
import resource
import time
from pathlib import Path

ROOT = Path('/workspace/urp132-minimal-generation-r1')
LEDGER = ROOT / 'ledger'
REPORTS = ROOT / 'remaining59'
BINARY = '/tmp/urp-opencode-check-i8yzygra/native/node_modules/opencode-linux-x64-baseline/bin/opencode'
OLD = Path('/workspace/original132-phase2-producer-20261006')
RUNNER_SHA = 'e642b00b208330612cc5b13d842508312420c228ff31962ac80b0b60eec73f73'
OLD_JOURNAL_SHA = 'e47c1bc88400892ccdab6e205af7e3d3b11af718d3f017dbf9e93cfa0794085f'
CAPS = {'slot_SELF_seconds': 30, 'slot_inclusive_wall_seconds': 1020,
        'total_SELF_seconds': 1860, 'total_local_seconds': 61440,
        'model_wall_seconds': 900}
OLD_OBSERVED_CPU = 7.38129
OLD_OBSERVED_LOCAL = 4.701348356946255
FIRST_OBSERVED_CAPTURE_WALL = 561.799376

spec = importlib.util.spec_from_file_location('approved_minimal_runner', ROOT / 'executor/runner.py')
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)


def cpu():
    measured = resource.getrusage(resource.RUSAGE_SELF)
    return measured.ru_utime + measured.ru_stime


def save_status(value):
    pending = REPORTS / 'status.pending.json'
    with pending.open('w', encoding='utf-8') as out:
        out.write(json.dumps(value, indent=2, ensure_ascii=False) + '\n')
        out.flush()
        runner.os.fsync(out.fileno())
    runner.os.replace(pending, REPORTS / 'status.json')
    runner.sync_dir(REPORTS)


def journal_sha():
    mapping = {p.name: runner.digest(p.read_bytes())
               for p in sorted((OLD / 'phase2-generation-accounting').glob('*.json'))}
    return runner.digest(json.dumps(mapping, sort_keys=True, separators=(',', ':')).encode())


def launch_abnormality(result):
    if not result.get('cli_process_started') or result.get('fixture_only'):
        return 'CLI_not_started_or_fixture'
    issues = result.get('capture_issues') or []
    if result['client_state'] == 'timeout':
        # A truncated stdout line at the client deadline does not undo the
        # explicit timeout terminal or establish successful provider cancellation.
        issues = [issue for issue in issues if issue != 'incomplete_final_event']
    if issues:
        return 'CLI_capture_issue:' + ','.join(issues)
    if result['client_state'] == 'timeout':
        return None  # Explicit client failure; server termination/cancellation unknown.
    if result['client_state'] != 'exited' or result.get('exit_code') != 0:
        return 'non_successful_or_ambiguous_client_terminal'
    if not result.get('finish_reasons'):
        return 'missing_model_finish_evidence'
    return None


def main():
    if runner.digest((ROOT / 'executor/runner.py').read_bytes()) != RUNNER_SHA:
        raise ValueError('Approved runner changed')
    data = runner.load_inputs()
    first = LEDGER / data['slots'][0]['pack']['slot_id']
    if runner.digest((first / 'result.json').read_bytes()) != '062684d7a7d56641a02b8da342c6023c9945234f81fadadaee592d95197f40a1':
        raise ValueError('Preserved first terminal changed')
    if any((LEDGER / s['pack']['slot_id']).exists() for s in data['slots'][1:]):
        raise ValueError('A remaining slot already exists; never redispatch')
    if journal_sha() != OLD_JOURNAL_SHA or any((OLD / 'dispatch-fences').iterdir()):
        raise ValueError('Old history or dispatch evidence changed')
    for p in Path('/proc').iterdir():
        if p.name.isdigit():
            try:
                if (p / 'comm').read_text().strip() == 'opencode':
                    raise ValueError('Active OpenCode exists')
            except (FileNotFoundError, ProcessLookupError, PermissionError):
                pass
    # One metadata record for this explicitly authorized collection; not a second ledger.
    REPORTS.mkdir(exist_ok=True)
    record = {'schema': 'urp132-minimal-r1-remaining59-authorization-v1',
              'authorized_positions': [2, 60], 'max_new_logical_CLI_launches': 59,
              'mode': 'serial', 'outer_retries': 0, 'first_slot_never_replayed': True,
              'unique_persistent_ledger': str(LEDGER), 'approved_runner_SHA256': RUNNER_SHA,
              'frozen_inputs_SHA256': runner.INPUT_SHA256,
              'configuration': data['freeze']['configuration'],
              'experiment_folder_ID': '129-0z2ejXZg2rAkJe_Yxz876foi5mTy6',
              'audit_folder_ID': '1LfnXbRzcZlr59nZEotn0QE6mnbvT7Hhm',
              'old_journal_SHA256': OLD_JOURNAL_SHA,
              'prior_costs_claims_HALT_and_11_events_preserved': True,
              'resource_caps': CAPS,
              'historical_observed_SELF_seconds': OLD_OBSERVED_CPU,
              'historical_observed_local_seconds': OLD_OBSERVED_LOCAL,
              'first_minimal_capture_wall_seconds': FIRST_OBSERVED_CAPTURE_WALL,
              'first_minimal_SELF_seconds': None,
              'full_historical_resource_balance': None,
              'provider_quota_remaining': None, 'provider_cost': None,
              'native_CLI_CPU_in_numerical_CPU_total': False,
              'scientific_evaluation_performed': False,
              'credential_value_read_or_saved': False}
    runner.write_json(REPORTS / 'COLLECTION_RECORD.json', record)
    measurements = []
    status = {'state': 'running', 'new_terminal_positions': [], 'current_position': None,
              'remaining_unstarted': 59, 'stop_reason': None, 'provider_quota_remaining': None,
              'physical_HTTP_attempts': None, 'provider_cost': None,
              'server_terminal_and_cancellation': 'unknown', 'scientific_evaluation': 'not_performed'}
    started_cpu = cpu()
    started_wall = time.monotonic()
    stop = None
    for position in range(2, 61):
        known_cpu_lower = OLD_OBSERVED_CPU + cpu() - started_cpu
        known_wall_lower = OLD_OBSERVED_LOCAL + FIRST_OBSERVED_CAPTURE_WALL + sum(m['local_inclusive_wall_seconds'] for m in measurements)
        if known_cpu_lower + CAPS['slot_SELF_seconds'] > CAPS['total_SELF_seconds']:
            stop = 'observed_total_SELF_budget_cannot_cover_next_original_slot'
            break
        if known_wall_lower + CAPS['slot_inclusive_wall_seconds'] > CAPS['total_local_seconds']:
            stop = 'observed_total_local_budget_cannot_cover_next_original_slot'
            break
        status.update(current_position=position)
        save_status(status)
        before_cpu, before_wall = cpu(), time.monotonic()
        try:
            result = runner.run_one(data, LEDGER, position, [BINARY])
        except Exception as error:
            stop = 'dispatch_or_persistence_exception:' + type(error).__name__
            # No exception body, environment, transport transcript or credential data.
            break
        after_cpu, after_wall = cpu(), time.monotonic()
        measurement = {'position': position, 'slot_id': result['slot_id'],
                       'Python_SELF_seconds': round(after_cpu - before_cpu, 6),
                       'local_inclusive_wall_seconds': round(after_wall - before_wall, 6),
                       'model_capture_wall_seconds': result['wall_seconds'],
                       'historical_balance_or_whole_CPU_cap_certified': False,
                       'provider_CPU_seconds': None,
                       'explicit_client_timeout_is_failure': result['client_state'] == 'timeout',
                       'server_outcome_and_cancellation': 'unknown'}
        runner.write_json(LEDGER / result['slot_id'] / 'resource_observation.json', measurement)
        measurements.append(measurement)
        status['new_terminal_positions'].append(position)
        status['remaining_unstarted'] = 60 - position
        stop = launch_abnormality(result)
        if measurement['Python_SELF_seconds'] > CAPS['slot_SELF_seconds']:
            stop = 'observed_slot_SELF_budget_exceeded'
        if measurement['local_inclusive_wall_seconds'] > CAPS['slot_inclusive_wall_seconds']:
            stop = 'observed_slot_local_budget_exceeded'
        if stop:
            break
        if len(measurements) % 6 == 0:
            save_status(status)
            print(json.dumps({'event': 'six_new_terminals', 'positions': status['new_terminal_positions'][-6:],
                              'new_terminal_count': len(measurements),
                              'remaining_unstarted': status['remaining_unstarted']}), flush=True)
    status.update(state='stopped' if stop else 'completed', stop_reason=stop,
                  controller_observed_SELF_seconds=round(cpu() - started_cpu, 6),
                  collection_elapsed_wall_seconds=round(time.monotonic() - started_wall, 6),
                  measurements=measurements,
                  full_remaining_SELF_budget_seconds=None,
                  full_remaining_local_budget_seconds=None,
                  old_journal_unchanged=journal_sha() == OLD_JOURNAL_SHA,
                  old_dispatch_fence_entries=len(list((OLD / 'dispatch-fences').iterdir())))
    # Derive actual unstarted count from the authoritative permanent slot folders.
    status['remaining_unstarted'] = sum(not (LEDGER / s['pack']['slot_id']).exists() for s in data['slots'][1:])
    save_status(status)
    print(json.dumps({'event': status['state'], 'new_terminal_count': len(measurements),
                      'remaining_unstarted': status['remaining_unstarted'], 'stop_reason': stop}), flush=True)


if __name__ == '__main__':
    main()
