原132：唯一真实 INIT-only suffix 已完成，生产停在 INIT。

activation 37461 字节，SHA256 59d96a0a5deb67de3272d9991bfd4a83fb1c56844901bb512b5d73d7d917eb6b。
完整原生工具返回为 COMPLETE_REAL_TOOL_TRANSCRIPT.json / raw_tool_returns；原工具对象按 JSON 忠实序列化，非宣称原始 HTTP 字节。
真实两次 index 读取、一次 archive create，41 次本地命令。base14/16，v2 14+32=46。
CPU cap NOT_ESTABLISHED；原/新检查点尾耗、JS/Library/provider、打包/Drive、全局OS状态仍 unknown。
production/** 保留绝对工作路径对应镜像；PATH_MAP.json 将源路径映射到 ZIP 成员。FILE_MANIFEST.json 覆盖所有其他 ZIP 成员。
evidence/RECOVERY_R2_REVIEWED_PACKAGE.exact.zip 为原 r2 离线验收包逐字节副本；历史停点包和旧 INIT grant 也原样保留。
未执行 GEN、模型、候选或数值计算；不要重复恢复入口。后续由父独立复核。
