"""Read-only production reconciliation and standalone evidence packaging."""
import time
ENTRY = time.monotonic()
import json, hashlib, math, os, resource, zipfile, shutil, datetime
from pathlib import Path

E = Path(__file__).resolve().parent
D = Path('/workspace/original132-init-only-precheck-20261006-g2uks153')
R = Path('/workspace/original132-phase2-recovery-dev-20261006-8sdu8cov/revision2')
W = Path('/workspace/original132-phase2-producer-20261006')
J = Path(str(W) + '.namespace-init')
K = Path(str(W) + '.namespace-recovery')
A = D / 'INIT_ONLY_ACTIVATION.APPROVED.json'
sha = lambda b: hashlib.sha256(b).hexdigest()
def read(p): return json.loads(Path(p).read_bytes())
def canon(v): return json.dumps(v, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')
def dump(p, v): Path(p).write_bytes(canon(v))
def ref(p): return {'path': str(p), 'file_sha256': sha(Path(p).read_bytes()), 'bytes': Path(p).stat().st_size}

g = read(A)
t = read(E / 'COMPLETE_REAL_TOOL_TRANSCRIPT.json')
v = t['terminal_result']['result']
base = read(J / 'INIT_RESOURCE_HANDOFF.json')
disk_v2 = read(K / 'RECONCILED_HANDOFF.v2.json')
checks = []
def check(label, ok, details=None): checks.append({'check': label, 'passed': bool(ok), 'details': details})
check('single_real_entry_terminal_return', t['invocation']['entry'] == 'recoverSuffix' and not t['invocation']['offlineFixture'] and t['terminal_result']['status'] == 'returned')
check('exact_activation_37461_and_parent_SHA', A.stat().st_size == 37461 and sha(A.read_bytes()) == '59d96a0a5deb67de3272d9991bfd4a83fb1c56844901bb512b5d73d7d917eb6b')
candidate = read(D / 'INIT_ONLY_BINDING.CANDIDATE.json')
check('candidate_unchanged_two_fields_only', sha((D / 'INIT_ONLY_BINDING.CANDIDATE.json').read_bytes()) == '6ee7a6948aa0562e0c49280280f60496b675a15a59ce20837b2a70d5f4c555d2' and set(candidate) == set(g) and [k for k in candidate if candidate[k] != g[k]] == ['execution_granted', 'independent_review_accepted'])
counts = {name: sum(c['tool'] == name for c in t['calls']) for name in {c['tool'] for c in t['calls']}}
check('44_complete_actual_tool_returns', len(t['calls']) == 44 and all(c['number'] == i and c['outcome'] == 'returned' and 'result' in c for i, c in enumerate(t['calls'])))
check('exact_tool_quota_and_no_other_tools', counts == {'exec_command': 41, 'mcp__codex_apps__library_read': 2, 'mcp__codex_apps__library_create_library_file': 1}, counts)
reads = [c for c in t['calls'] if c['tool'] == 'mcp__codex_apps__library_read']
check('backing_then_head_exact_requests', [c['args'] for c in reads] == [[{'read': [{'ref_id': g['index']['file_id'], 'mode': 'full', 'max_lines': 2}]}], [{'read': [{'ref_id': g['index']['library_file_id'], 'mode': 'full', 'max_lines': 2}]}]])
read_summary = []
for c, name in zip(reads, ('read.backing', 'read.head')):
    raw = c['result']; x = raw['structuredContent']['results'][0]
    content = '\n'.join(x['content']).encode('utf-8')
    check(name + '_actual_raw_and_index_content', raw == read(K / (name + '.raw.json')) and raw.get('isError') is False and x['library_file_id'] == g['index']['library_file_id'] and x['file_id'] == g['index']['file_id'] and x['size_bytes'] == 859 and content == (W / 'index.initial.json').read_bytes() and x['has_more'] is False)
    read_summary.append({'stage': name, 'ref_id': x['ref_id'], 'library_file_id': x['library_file_id'], 'file_id': x['file_id'], 'version_id': x['version_id'], 'version_number_source': 'historical original create receipt, not inferred from read.version_id', 'content_bytes': len(content), 'content_sha256': sha(content), 'raw_ref': ref(K / (name + '.raw.json'))})
create = next(c for c in t['calls'] if c['tool'] == 'mcp__codex_apps__library_create_library_file')
check('one_archive_create_exact_args_and_raw', create['args'] == [{'file': str(W / 'archive.initial.zip'), 'library_artifact_type': 'other'}] and create['result'] == read(K / 'archive-create.raw.json') == read(W / 'retained-library-replies/phase2-init-archive/response.json'))
archive_xattrs = create['result']['structuredContent']['xattrs']
xattr_checks = []
for x in archive_xattrs:
    try: ok = os.getxattr(W / 'archive.initial.zip', x['name']).decode('utf-8') == x['value']
    except OSError: ok = False
    xattr_checks.append({'name': x['name'], 'matches_returned_value': ok})
check('returned_archive_xattrs_applied', bool(xattr_checks) and all(x['matches_returned_value'] for x in xattr_checks), xattr_checks)
old_five = []
for pair in g['old_five']:
    for kind in ('intent', 'receipt'):
        p = Path(pair[kind]['path'])
        old_five.append({'path': str(p), 'unchanged': sha(p.read_bytes()) == pair[kind]['file_sha256']})
check('original_five_pairs_unchanged', all(x['unchanged'] for x in old_five), old_five)
helper_pairs = []
for n in range(13):
    ip = J / ('helper-%02d.intent.json' % n); rp = J / ('helper-%02d.receipt.json' % n)
    iv = read(ip); rv = read(rp)
    helper_pairs.append({'number': n, 'step': rv['step'], 'outcome': rv['outcome'], 'intent_ref': ref(ip), 'receipt_ref': ref(rp), 'valid': rv['outcome'] == 'confirmed' and rv['step'] == iv['step'] and rv['intent_file_sha256'] == sha(ip.read_bytes())})
check('all_thirteen_original_helpers_confirmed', all(x['valid'] for x in helper_pairs))
effects = []
for n, stage in enumerate(g['suffix_actions']):
    ip = K / ('effect-%02d.intent.json' % n); rp = K / ('effect-%02d.receipt.json' % n)
    rv = read(rp)
    effects.append({'number': n, 'stage': stage, 'outcome': rv['outcome'], 'intent_ref': ref(ip), 'receipt_ref': ref(rp), 'valid': rv['stage'] == stage and rv['outcome'] == 'confirmed' and rv['intent_file_sha256'] == sha(ip.read_bytes())})
check('all_fourteen_effects_fixed_confirmed', len(effects) == 14 and all(x['valid'] for x in effects))
deltas = [read(K / ('delta-%04d.receipt.json' % n)) for n in range(32)]
check('32_complete_delta_pairs', len(list(K.glob('delta-*.receipt.json'))) == len(list(K.glob('delta-*.intent.json'))) == 32 and all(x['outcome'] == 'confirmed' and x['intent_file_sha256'] == sha((K / ('delta-%04d.intent.json' % n)).read_bytes()) for n, x in enumerate(deltas)))
check('base_real14_16_and_v2_real46', len(base['measurements']) == 14 and len(base['receipt_files']) == 16 and v['base_measurement_count'] == 14 and v['recovery_measurement_count'] == 32 and len(v['measurements']) == 46 and v['measurements'] == base['measurements'] + [x['measurement'] for x in deltas])
check('v2_disk_and_return_equal', v == disk_v2 and v['status'] == 'CONFIRMED' and read(K / 'finish.receipt.json')['handoff_ref']['file_sha256'] == sha((K / 'RECONCILED_HANDOFF.v2.json').read_bytes()))
ref_checks = []
for rr in [v['base_handoff_ref'], v['reconciliation_grant_ref'], v['old_grant_ref'], v['old_bridge_error_ref'], v['old_stop_zip_ref'], *base['receipt_files'], *v['recovery_receipt_files'], *v['new_authenticated_read_refs']]:
    ref_checks.append({'path': rr['path'], 'exact': sha(Path(rr['path']).read_bytes()) == rr['file_sha256']})
check('all_handoff_external_refs_exact', all(x['exact'] for x in ref_checks), {'count': len(ref_checks)})
cpu = {}
wall = 0.0
for m in v['measurements']:
    check('measurement_process_' + m['process'], m['measurement_status'] == 'known' and m['RUSAGE_kind'] == 'RUSAGE_SELF' and m['process'] == m['start']['process'] == m['end']['process'] and all(isinstance(m[k], (int, float)) and math.isfinite(m[k]) and m[k] >= 0 for k in ('self_cpu_seconds', 'local_inclusive_wall_seconds')) and m['native_wait_union_seconds'] == 0)
    cpu[m['process']] = max(cpu.get(m['process'], 0.0), m['end']['self_cpu'])
    wall += m['local_inclusive_wall_seconds']
SELF = sum(cpu.values())
check('exact_all46_highwater_SELF_and_inclusive_windows', abs(SELF - v['observed_init_final_self_cpu_seconds']) < 1e-12 and abs(wall - v['observed_init_final_local_wall_seconds']) < 1e-12)
check('original_shared_pool_below_limits_without_reset', v['pool'] == {'SELF_checkpoint_seconds': 60, 'local_inclusive_wall_seconds': 240, 'new_budget': False} and SELF < 60 and wall < 240)
check('index_original_identity_confirmed', v['index_receipt']['library_file_id'] == g['index']['library_file_id'] and v['index_receipt']['file_id'] == g['index']['file_id'] and v['index_receipt']['current_version_number'] == 0 and v['index_receipt']['index_readback_confirmed'] is True and v['index_receipt']['write_result_confirmed'] is True and v['index_receipt']['remote_bytes_verified'] is False)
check('archive_new_identity_confirmed_without_remote_byte_claim', v['archive_receipt']['library_file_id'] not in [g['index']['library_file_id'], *g['forbidden_prior_library_file_ids']] and v['archive_receipt']['write_result_confirmed'] is True and v['archive_receipt']['index_readback_confirmed'] is False and v['archive_receipt']['remote_bytes_verified'] is False)
check('original_pending_removed_only_after_real_confirm', not (W / 'state/external-pending.json').exists() and effects[4]['outcome'] == effects[12]['outcome'] == 'confirmed')
check('GEN_and_model_stopped', v['generation_execution_granted'] is False and v['numeric_execution_granted'] is False and v['model_calls'] == v['candidate_executions'] == 0 and not (W / 'phase2-generation-accounting').exists() and not (W / 'phase2-bridge-journal').exists() and not any((W / 'dispatch-fences').iterdir()) and not any((W / 'retained').iterdir()))
source_checks = []
for group in ('new_source_pins', 'original_source_pins', 'original_implementation_pins', 'generation_original_pins'):
    for p, h in g[group].items():
        source_checks.append({'group': group, 'path': p, 'expected_sha256': h, 'exact': sha(Path(p).read_bytes()) == h})
check('all_approved_source_pins_unchanged_after_real_execution', all(x['exact'] for x in source_checks))
check('unknowns_preserved_no_CPU_certificate', v['CPU_cap_certification'] == 'NOT_ESTABLISHED' and v['complete_CPU_upper_bound_claimed'] is False and all(x is None for x in v['unknown'].values()) and v['new_post_checkpoint_CPU_tails'] is None and v['new_post_checkpoint_wall_tails'] is None)
dump(E / 'audit/POST_INIT_RECONCILIATION_CHECKS.json', checks)
dump(E / 'audit/REAL_EFFECT_SEQUENCE.json', effects)
dump(E / 'audit/ORIGINAL_HELPER_SEQUENCE.json', helper_pairs)
dump(E / 'audit/POST_INIT_SOURCE_PIN_CHECKS.json', source_checks)
dump(E / 'audit/HANDOFF_REFERENCE_VERIFICATION.json', ref_checks)
current_files = {str(p): {'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())} for root in (W, J, K) for p in sorted(root.rglob('*')) if p.is_file()}
dump(E / 'audit/POST_INIT_PRODUCTION_SNAPSHOT.json', current_files)
report = {
    'schema': 'real-once-INIT-only-suffix-execution-report-v1',
    'UTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'production_execution_result': 'CONFIRMED', 'post_INIT_reconciliation_passed': all(x['passed'] for x in checks),
    'real_recoverSuffix_invocations': 1, 'offline_fixture_entry_calls': 0, 'native_tool_counts': counts,
    'activation_ref': ref(A), 'source_bridge_ref': ref(R / 'src/suffix_bridge.js'),
    'most_recent_confirmed_effect': 'base.assemble', 'final_control': 'v2 finish confirmed',
    'actual_action_sequence': [{'stage': x['stage'], 'outcome': x['outcome']} for x in effects],
    'authenticated_index_reads': read_summary, 'index_receipt': v['index_receipt'], 'archive_receipt': v['archive_receipt'],
    'base_handoff_ref': ref(J / 'INIT_RESOURCE_HANDOFF.json'), 'v2_handoff_ref': ref(K / 'RECONCILED_HANDOFF.v2.json'),
    'actual_base_measurements': 14, 'actual_base_receipt_refs': 16, 'actual_recovery_measurements': 32, 'actual_total_measurements': 46,
    'pool': v['pool'], 'observed_init_SELF_seconds': SELF, 'observed_local_inclusive_window_seconds': wall,
    'remaining_after_observed_checkpoints_SELF_seconds': 60 - SELF, 'remaining_after_observed_local_windows_seconds': 240 - wall,
    'remaining_values_are_not_a_complete_future_budget_certification': True,
    'CPU_cap_certification': 'NOT_ESTABLISHED', 'complete_CPU_upper_bound_claimed': False,
    'unknown': v['unknown'], 'new_post_checkpoint_CPU_tails': v['new_post_checkpoint_CPU_tails'],
    'new_post_checkpoint_wall_tails': v['new_post_checkpoint_wall_tails'],
    'global_OS_or_third_party_state': None, 'infrastructure_process_FDs': None,
    'post_INIT_evidence_preparation_and_Drive_CPU_wall': None,
    'original_five_measurements_and_bytes_preserved': all(x['unchanged'] for x in old_five),
    'generation_execution_granted': False, 'numeric_execution_granted': False, 'model_calls': 0, 'candidate_executions': 0,
    'next_step': 'Parent independently reviews exact real v2 handoff and bundle; no GEN request or repeated recovery is authorized by this completion.',
    'remaining_blockers': [] if all(x['passed'] for x in checks) else [x['check'] for x in checks if not x['passed']],
}
dump(E / 'EXECUTION_REPORT.json', report)
(E / 'README.md').write_text(
    '原132：唯一真实 INIT-only suffix 已完成，生产停在 INIT。\n\n'
    'activation 37461 字节，SHA256 59d96a0a5deb67de3272d9991bfd4a83fb1c56844901bb512b5d73d7d917eb6b。\n'
    '完整原生工具返回为 COMPLETE_REAL_TOOL_TRANSCRIPT.json / raw_tool_returns；原工具对象按 JSON 忠实序列化，非宣称原始 HTTP 字节。\n'
    '真实两次 index 读取、一次 archive create，41 次本地命令。base14/16，v2 14+32=46。\n'
    'CPU cap NOT_ESTABLISHED；原/新检查点尾耗、JS/Library/provider、打包/Drive、全局OS状态仍 unknown。\n'
    'production/** 保留绝对工作路径对应镜像；PATH_MAP.json 将源路径映射到 ZIP 成员。FILE_MANIFEST.json 覆盖所有其他 ZIP 成员。\n'
    'evidence/RECOVERY_R2_REVIEWED_PACKAGE.exact.zip 为原 r2 离线验收包逐字节副本；历史停点包和旧 INIT grant 也原样保留。\n'
    '未执行 GEN、模型、候选或数值计算；不要重复恢复入口。后续由父独立复核。\n', encoding='utf-8')

reviewed_zip = R / '原132_P2_未验收离线恢复候选_r2_20261006.zip'
if sha(reviewed_zip.read_bytes()) != '0b8eac652f1d14290ccabf832ea3889141199cd0f64924c56bb7df9c82ba36d1':
    raise RuntimeError('reviewed r2 ZIP drift; keep original evidence, do not execute anything')
shutil.copyfile(reviewed_zip, E / 'evidence/RECOVERY_R2_REVIEWED_PACKAGE.exact.zip')
pack = E / 'evidence_bundle'
pack.mkdir(exist_ok=False)
path_map = {}
def copy_source(p, member):
    p = Path(p); dest = pack / member
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(p.read_bytes())
    path_map[str(p)] = member
audit_files = [p for p in E.rglob('*') if p.is_file() and pack not in p.parents]
for p in audit_files:
    copy_source(p, p.relative_to(E).as_posix())
sources = set()
for root in (W, J, K): sources.update(p for p in root.rglob('*') if p.is_file())
for group in ('new_source_pins', 'original_source_pins', 'original_implementation_pins', 'generation_original_pins'):
    sources.update(map(Path, g[group]))
for key in ('old_grant_ref', 'stop_zip_ref', 'old_bridge_error_ref', 'historical_create_ref', 'pending_ref', 'generation_original_manifest_ref'):
    p = Path(g[key]['path'])
    if p.exists(): sources.add(p)
sources.update((A, D / 'INIT_ONLY_BINDING.CANDIDATE.json', R / 'FILE_MANIFEST.json', R / 'RECOVERY_GRANT.DEVELOPMENT.json'))
impl = Path(g['original_implementation_root'])
sources.update(impl / n for n in read(impl / 'MANIFEST.json')['files'])
sources.add(impl / 'MANIFEST.json')
sources.update(p for p in (D / 'binding_candidate').rglob('*') if p.is_file())
for p in sorted(sources):
    copy_source(p, 'production/' + p.relative_to('/workspace').as_posix())
cost = {'scope': 'standalone post-INIT reconciliation and copying checkpoint, separate engineering evidence',
        'SELF_CPU_checkpoint_seconds': resource.getrusage(resource.RUSAGE_SELF).ru_utime + resource.getrusage(resource.RUSAGE_SELF).ru_stime,
        'local_wall_checkpoint_seconds': time.monotonic() - ENTRY, 'startup_and_after_checkpoint_CPU_wall': None,
        'JS_tool_wait_and_Drive_CPU_wall': None, 'complete_CPU_upper_bound_claimed': False}
dump(E / 'audit/RECONCILIATION_COPY_COST_CHECKPOINT.json', cost)
copy_source(E / 'audit/RECONCILIATION_COPY_COST_CHECKPOINT.json', 'audit/RECONCILIATION_COPY_COST_CHECKPOINT.json')
dump(pack / 'PATH_MAP.json', path_map)
files = {p.relative_to(pack).as_posix(): {'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())} for p in sorted(pack.rglob('*')) if p.is_file()}
dump(pack / 'FILE_MANIFEST.json', {'schema': 'real-INIT-evidence-members-v1', 'files': files})
zip_path = E / '原132_INIT_ONLY_唯一真实恢复_完整证据_20261006.zip'
with zipfile.ZipFile(zip_path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for p in sorted(pack.rglob('*')):
        if p.is_file(): z.write(p, p.relative_to(pack).as_posix())
with zipfile.ZipFile(zip_path) as z:
    manifest = json.loads(z.read('FILE_MANIFEST.json'))['files']
    bad = [n for n, m in manifest.items() if len(z.read(n)) != m['bytes'] or sha(z.read(n)) != m['sha256']]
    verified = z.testzip() is None and not bad and len(z.namelist()) == len(manifest) + 1 and len(set(z.namelist())) == len(z.namelist())
local_proof = {'zip_path': str(zip_path), 'bytes': zip_path.stat().st_size, 'sha256': sha(zip_path.read_bytes()),
               'members': len(files) + 1, 'manifest_refs': len(files), 'all_member_bytes_and_CRC_verified': verified,
               'post_INIT_reconciliation_passed': report['post_INIT_reconciliation_passed']}
dump(E / 'LOCAL_BUNDLE_VERIFICATION.json', local_proof)
print(json.dumps({'report': {k: report[k] for k in ('production_execution_result', 'post_INIT_reconciliation_passed', 'actual_total_measurements', 'observed_init_SELF_seconds', 'observed_local_inclusive_window_seconds', 'remaining_blockers')}, 'local_bundle': local_proof}, ensure_ascii=False))
