"""Publish the single parent-approved activation; never import repository code."""
import json, hashlib, os, datetime
from pathlib import Path

E = Path(__file__).resolve().parent
D = Path('/workspace/original132-init-only-precheck-20261006-g2uks153')
R = Path('/workspace/original132-phase2-recovery-dev-20261006-8sdu8cov/revision2')
C = D / 'INIT_ONLY_BINDING.CANDIDATE.json'
A = D / 'INIT_ONLY_ACTIVATION.APPROVED.json'
EXPECTED_C = '6ee7a6948aa0562e0c49280280f60496b675a15a59ce20837b2a70d5f4c555d2'
EXPECTED_A = '59d96a0a5deb67de3272d9991bfd4a83fb1c56844901bb512b5d73d7d917eb6b'
sha = lambda b: hashlib.sha256(b).hexdigest()
def canon(v):
    return json.dumps(v, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')
def need(v, label):
    if not v:
        raise RuntimeError(label)

need(not A.exists() and not A.is_symlink(), 'activation already exists; stop without overwrite')
b = C.read_bytes()
need(len(b) == 37463 and sha(b) == EXPECTED_C, 'candidate exact bytes/SHA drift')
g = json.loads(b)
need(g['execution_granted'] is False and g['independent_review_accepted'] is False, 'candidate already enabled')
need(g['generation_execution_granted'] is False and g['numeric_execution_granted'] is False
     and g['model_requests'] == g['candidate_executions'] == 0, 'INIT-only scope')
pre = json.loads((E / 'PREFLIGHT_READ_ONLY.json').read_bytes())
need(pre['file_identity_source_state_checks_passed'] and pre['production_unchanged'], 'read-only preflight failed')
baseline = json.loads((E / 'audit/PRODUCTION_AFTER.json').read_bytes())
W = Path(g['producer_workspace']); J = Path(g['original_journal_root'])
current_paths = {Path(p) for p in baseline}
for root in (W, J):
    current_paths.update(p for p in root.rglob('*') if p.is_file())
current = {str(p): {'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())} for p in sorted(current_paths)}
need(current == baseline, 'production changed after precheck')
need(not Path(g['recovery_journal_root']).exists(), 'recovery journal already exists')
for group in ('new_source_pins', 'original_source_pins', 'original_implementation_pins', 'generation_original_pins'):
    for p, h in g[group].items():
        need(sha(Path(p).read_bytes()) == h, 'source pin drift: ' + p)
coord = D / 'binding_candidate/audit/PARENT_COORDINATION_ATTESTATION.json'
cv = json.loads(coord.read_bytes())
need(cv['parent_reports_parallel_INIT_recovery_GEN_Library_writes'] is False, 'coordinated exclusivity missing')
dev = (R / 'RECOVERY_GRANT.DEVELOPMENT.json').read_bytes()
need(sha(dev) == 'c24e15941c1a9caa4c6583e3ba14e5bd9b981c9b187349b5531a24f60c7ccff8', 'development grant pin')
active = dict(g)
active['execution_granted'] = True
active['independent_review_accepted'] = True
changed = [k for k in g if active[k] != g[k]]
need(changed == ['execution_granted', 'independent_review_accepted'], 'exact two-field change')
ab = canon(active)
need(len(ab) == 37461 and sha(ab) == EXPECTED_A and not ab.endswith(b'\n'), 'activation bytes/SHA mismatch')
fd = os.open(A, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
with os.fdopen(fd, 'wb') as f:
    f.write(ab)
    f.flush()
    os.fsync(f.fileno())
observed = A.read_bytes()
need(observed == ab and sha(C.read_bytes()) == EXPECTED_C, 'published activation verification')
(E / 'evidence/INIT_ONLY_BINDING.CANDIDATE.exact.json').write_bytes(b)
(E / 'evidence/INIT_ONLY_ACTIVATION.APPROVED.exact.json').write_bytes(observed)
report = {
    'schema': 'exact-parent-approved-activation-publication-v1',
    'UTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'candidate_path': str(C), 'candidate_bytes': len(b), 'candidate_sha256': EXPECTED_C,
    'activation_path': str(A), 'activation_bytes': len(observed), 'activation_sha256': EXPECTED_A,
    'changed_top_level_fields': changed, 'exclusive_create': True,
    'all_other_values_unchanged': True, 'historical_metadata_unchanged': True,
    'source_pins_rechecked': True, 'production_matches_readonly_snapshot': True,
    'parent_current_instruction_authorizes_exactly_one_real_INIT_suffix': True,
    'coordination_ref': {'path': str(coord), 'file_sha256': sha(coord.read_bytes())},
    'global_OS_or_third_party_state': None, 'infrastructure_process_FDs': None,
    'generation_execution_granted': False, 'model_requests': 0, 'candidate_executions': 0,
    'execution_started': False,
}
(E / 'ACTIVATION_VERIFICATION.json').write_bytes(canon(report))
print(json.dumps(report, ensure_ascii=False))
