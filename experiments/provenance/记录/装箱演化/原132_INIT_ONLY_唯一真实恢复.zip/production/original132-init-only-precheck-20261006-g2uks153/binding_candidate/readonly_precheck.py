"""Standalone standard-library read-only checks. Imports/runs no repository code."""
import time
ENTRY=time.monotonic()
import resource,sys,json,hashlib,math,os,fcntl,stat,zipfile,uuid,datetime
from pathlib import Path
D=Path(__file__).resolve().parent
R=Path('/workspace/original132-phase2-recovery-dev-20261006-8sdu8cov/revision2')
W=Path('/workspace/original132-phase2-producer-20261006');J=Path(str(W)+'.namespace-init')
PROCESS=str(os.getpid())+':'+uuid.uuid4().hex
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
def fh(p):return sha(Path(p).read_bytes())
def dump(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,sort_keys=True,indent=2))
def ref(p):return {'path':str(p),'file_sha256':fh(p)}
CHECKS=[]
def check(name,ok,details=None):CHECKS.append({'check':name,'passed':bool(ok),'details':details})
EXPECTED={
 'suffix_bridge.js':'d31cd3e8de99cdc73fb715ec3d6dcfbf846684bf270d1853ec16b97ba4407209',
 'recovery_cli.py':'59695355a32f72bd77532c07d19e895b921a27e6e1a771bbf6aff7924e0a2c54',
 'recovery_core.py':'101ba2facae086210c02f44882e3bc062376567a033039508a0e102dd8970fa1',
 'reconciled_handoff.py':'af79d1a8dea7b01d64bc193bce0acde04bd4e43698216b5bf8939b328b097e28',
 'gen_importer_v2.py':'024b106fcebc907b9dc449a230621f18542aa2190f71bb36418664d938a7776d',
 'production_generation_entry_v2.py':'69a6a2e06562a52c71a9c8bea5c5a4fe6f837725b36b167db570c43656f8c9a1'}
gp=R/'RECOVERY_GRANT.DEVELOPMENT.json';g=read(gp)
historical=read(R.parent/'audit/production.before.json')
def snapshot():
    files={Path(p) for p in historical['files']}
    for root in (W,J):files.update(p for p in root.rglob('*') if p.is_file())
    return {str(p):{'bytes':p.stat().st_size,'sha256':fh(p)} for p in sorted(files)}
def process_scan():
    result={'processes_seen':0,'scope_write_fds':[],'unreadable_live_processes':[],'inactive_zombies':0}
    roots=(str(W)+'/',str(J)+'/')
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():continue
        result['processes_seen']+=1
        try:fds=list((p/'fd').iterdir())
        except FileNotFoundError:continue
        except PermissionError:
            try:
                status={s.split(':',1)[0]:s.split(':',1)[1].strip() for s in (p/'status').read_text().splitlines() if s.startswith(('Name:','State:','Uid:'))}
                if status.get('State','').startswith('Z'):result['inactive_zombies']+=1
                else:result['unreadable_live_processes'].append({'pid':p.name,**status})
            except OSError:result['unreadable_live_processes'].append({'pid':p.name,'status':'unreadable'})
            continue
        for fd in fds:
            try:target=os.readlink(fd)
            except OSError:continue
            if target not in (str(W),str(J)) and not target.startswith(roots):continue
            try:
                info=(p/'fdinfo'/fd.name).read_text();flags=int(next(s.split()[1] for s in info.splitlines() if s.startswith('flags:')),8)
                if flags&3 in (1,2):result['scope_write_fds'].append({'pid':p.name,'comm':(p/'comm').read_text().strip(),'path':target})
            except OSError:result['unreadable_live_processes'].append({'pid':p.name,'scope_fd_info_unreadable':True})
    with (J/'lock').open('rb') as f:
        try:fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);result['init_lock_available']=True;fcntl.flock(f,fcntl.LOCK_UN)
        except BlockingIOError:result['init_lock_available']=False
    return result
before=snapshot();scan_before=process_scan()
check('production_matches_original_45_file_baseline',before==historical['files'],{'files':len(before)})
check('development_grant_exact_SHA',fh(gp)=='c24e15941c1a9caa4c6583e3ba14e5bd9b981c9b187349b5531a24f60c7ccff8')
mp=R/'FILE_MANIFEST.json';check('r2_manifest_exact_SHA',fh(mp)=='7740fa3e61f845a4a392c5556a804c2bd8842fade2f2f8e0134b8542cc236d44')
manifest=read(mp);manifest_bad=[]
for name,v in manifest['files'].items():
    p=R/name
    if not p.is_file() or p.stat().st_size!=v['bytes'] or fh(p)!=v['sha256']:manifest_bad.append(name)
check('r2_all425_manifest_members_exact',len(manifest['files'])==425 and not manifest_bad,{'mismatches':manifest_bad})
check('disabled_scope_and_original_pool',g['execution_granted'] is False and g['independent_review_accepted'] is False
      and g['generation_execution_granted'] is False and g['numeric_execution_granted'] is False
      and g['model_requests']==g['candidate_executions']==g['new_index_create_count']==g['index_replace_count']==0
      and g['archive_create_max']==1 and g['pool']=={'SELF_checkpoint_seconds':60,'local_inclusive_wall_seconds':240,'new_budget':False})
actual_pins={str(R/'src'/name):fh(R/'src'/name) for name in EXPECTED}
expected_pins={str(R/'src'/name):h for name,h in EXPECTED.items()}
check('six_independently_accepted_sources_exact',actual_pins==expected_pins==g['new_source_pins'])
check('no_additional_source_in_new_src',{p.name for p in (R/'src').iterdir()}==set(EXPECTED))
pin_bad=[]
for key in ('original_source_pins','original_implementation_pins','generation_original_pins'):
    for p,h in g[key].items():
        if not Path(p).is_file() or fh(p)!=h:pin_bad.append({'group':key,'path':p})
check('all_26_old_source_pins_exact',not pin_bad,{'mismatches':pin_bad})
refs={}
for key in ('old_grant_ref','stop_zip_ref','old_bridge_error_ref','historical_create_ref','pending_ref','generation_original_manifest_ref'):
    rr=g[key];actual=fh(rr['path']);refs[key]={'reference':rr,'actual_sha256':actual};check(key+'_exact_SHA',actual==rr['file_sha256'])
check('old_INIT_grant_approved_exact_SHA',fh(g['old_grant_ref']['path'])=='fd7e0df05db28dc38b14a3231662c8f775db8472d46625f3c3a02a3c6e26166e')
old=read(g['old_grant_ref']['path'])
check('old_grant_full_text_and_source_maps_unchanged',g['old_grant_file_text'].encode()==Path(g['old_grant_ref']['path']).read_bytes()
      and g['original_source_pins']==old['exact_original_source_pins'] and
      g['original_implementation_pins']=={str(Path(old['implementation_root'])/n):h for n,h in old['implementation_files'].items()})
with zipfile.ZipFile(g['stop_zip_ref']['path']) as z:
    check('original_stop_ZIP_CRC',z.testzip() is None,{'members':len(z.namelist())})
check('exact_production_and_future_paths',g['producer_workspace']==str(W) and g['original_journal_root']==str(J)
      and g['recovery_journal_root']==str(W)+'.namespace-recovery' and g['original_implementation_root']==old['implementation_root'])
steps=['build','index.begin','index.retain-start','index.retain-response','index.xattrs'];measurements=[];pair_refs=[]
expected_entries={'lock'}|{f'helper-{n:02d}.{k}.json' for n in range(5) for k in ('intent','receipt')}
check('journal_exact_five_pairs_no_orphans_or_assembly',{p.name for p in J.iterdir()}==expected_entries)
for n,step in enumerate(steps):
    ip=J/f'helper-{n:02d}.intent.json';rp=J/f'helper-{n:02d}.receipt.json';i,r=read(ip),read(rp);pair=g['old_five'][n]
    valid=pair=={'intent':ref(ip),'receipt':ref(rp)} and i['step']==r['step']==step and r['outcome']=='confirmed'
    valid=valid and r['intent_file_sha256']==fh(ip) and i['init_grant_file_sha256']==r['init_grant_file_sha256']==g['old_grant_ref']['file_sha256']
    m=r['measurement'];valid=valid and m['measurement_status']=='known' and m['RUSAGE_kind']=='RUSAGE_SELF' and m['native_wait_union_seconds']==0
    valid=valid and m['process']==m['start']['process']==m['end']['process'] and m['start']['self_cpu']==0 and m['self_cpu_seconds']==m['end']['self_cpu']
    valid=valid and all(type(m[k]) in (int,float) and math.isfinite(m[k]) and m[k]>=0 for k in ('self_cpu_seconds','wall_seconds','local_inclusive_wall_seconds'))
    valid=valid and abs(m['wall_seconds']-(m['end']['monotonic']-m['start']['monotonic']))<1e-8 and m['wall_seconds']==m['local_inclusive_wall_seconds']
    check('original_helper_'+str(n)+'_confirmed_bound',valid);measurements.append(m);pair_refs.append(pair)
pending=read(W/'state/external-pending.json')
check('pending_original_exact_bytes_and_index_begin_identity',fh(W/'state/external-pending.json')=='28d28fe5af6521d9e855487bdd50438fb90bcfccc0ecf871ad5099159fdd1092'
    and pending['kind']=='index' and pending['library_file_id'] is None and pending['expected_current_version']==-1
    and pending['local_blob_sha256']=='83007fa4f9c1cfa8691bf23aa5f07d4a96881d356ee437197b2695774ad313c6' and pending['local_blob_bytes']==859)
for name,size,h in [('index.initial.json',859,'83007fa4f9c1cfa8691bf23aa5f07d4a96881d356ee437197b2695774ad313c6'),
                    ('archive.initial.zip',478,'bb644cab41cf25559f1bdc7fe3212ccbf0d61362a16dd0f717e2c1ff3795f43f')]:
    p=W/name;check(name+'_frozen_exact_bytes',p.stat().st_size==size and fh(p)==h)
index=read(W/'index.initial.json');check('index_empty_original_run',index['rows']==[] and index['archives']=={} and index['run_id']==g['operational_run_id'])
raw=read(g['historical_create_ref']['path']);item=raw.get('structuredContent')
check('historical_create_real_two_IDs_v0_identity',raw.get('isError') is False and item['status']=='succeeded'
    and item['library_file_id']==g['index']['library_file_id']=='libfile_d711508ec1888191ba87324ac424a529'
    and item['file_id']==g['index']['file_id']=='file_00000000d48881f58e04687a2b2eb6b4'
    and item['current_version_number']==g['index']['version']==0 and item['file_size_bytes']==859)
absent=[Path(str(W)+'.namespace-recovery'),W/'phase2-generation-accounting',W/'phase2-bridge-journal',W/'state/commits',
        W/'retained-library-replies/phase2-init-archive',J/'assembly.intent.json',J/'assembly.receipt.json',J/'INIT_RESOURCE_HANDOFF.json']
check('no_recovery_GEN_commit_archive_or_assembly_activity',all(not p.exists() for p in absent),{'must_remain_absent':[str(p) for p in absent]})
check('no_payload_no_dispatch_no_retained_candidates',not list((W/'state').glob('readback-*')) and not list((W/'dispatch-fences').iterdir()) and not list((W/'retained').iterdir()))
oldpy={Path(n).name for n in read(Path(old['implementation_root'])/'ORIGINAL_SOURCE_PINS.json')['exporter_files']}
check('no_extra_producer_executable_source',{p.name for p in (W/'src').iterdir() if p.suffix in ('.py','.js','.sh','.mjs','.cjs')}==oldpy)
check('one_exact_bundled_library_helper',{p.name for p in (W/'.library-helpers-current').iterdir()}=={'library_file_transfer.py'})
impl=Path(old['implementation_root']);impl_manifest=read(impl/'MANIFEST.json')
approved_impl=set(impl_manifest['files'])|{'MANIFEST.json'}
check('old_full_package_manifest_exact',fh(impl/'MANIFEST.json')==old['package_manifest_file_sha256']==
      'abcb6ea4d3fd940d6be7595a6ba2db2647193bf0f1cf8e3755d30370ec243b19' and
      all(fh(impl/name)==h for name,h in impl_manifest['files'].items()),{'approved_members':len(impl_manifest['files'])})
check('no_unmanifested_old_implementation_source',{p.relative_to(impl).as_posix() for p in impl.rglob('*') if p.is_file()}==approved_impl,
      {'operating_allowlist_files':len(g['original_implementation_pins']),'other_original_diagnostic_files_manifest_bound':True})
check('nonsymlink_bound_paths',all(not p.is_symlink() and not any(a.is_symlink() for a in p.parents) for p in [W,J,R/'src',gp,*map(Path,actual_pins)]))
actions=['read.backing','read.head','index.payload','index.receipt','index.confirm','archive.begin','archive.retain-start','archive.create','archive.retain-response','archive.xattrs','archive.payload','archive.receipt','archive.confirm','base.assemble']
check('fixed_INIT_only_action_order',g['suffix_actions']==actions)
cpu=sum(max(m['end']['self_cpu'] for m in measurements if m['process']==pid) for pid in {m['process'] for m in measurements})
wall=sum(m['local_inclusive_wall_seconds'] for m in measurements)
check('old_observed_five_below_original_pool_no_reset',cpu<60 and wall<240,{'observed_SELF_seconds':cpu,'observed_local_windows_seconds':wall,'new_budget':False,'complete_CPU_upper_bound':False})
after=snapshot();scan_after=process_scan();check('production_before_after_bytes_identical',before==after)
check('no_observed_scope_write_FD_and_old_lock_available',not scan_before['scope_write_fds'] and not scan_after['scope_write_fds'] and scan_before['init_lock_available'] and scan_after['init_lock_available'])
dump(D/'audit/PRODUCTION_BEFORE.json',before);dump(D/'audit/PRODUCTION_AFTER.json',after)
dump(D/'audit/PROCESS_SNAPSHOTS.json',{'before':scan_before,'after':scan_after,'credentials_environments_and_cmdlines_not_read':True,'sole_agent_observed':'/root','global_exclusive_operator_attestation':'PENDING'})
dump(D/'SOURCE_PINS.json',{'parent_accepted_six_sources':expected_pins,'all_exact':actual_pins==expected_pins,'old_source_groups':{k:g[k] for k in ('original_source_pins','original_implementation_pins','generation_original_pins')}})
dump(D/'evidence/ORIGINAL_STOP_REFERENCES.json',refs);dump(D/'evidence/ORIGINAL_FIVE_REFERENCES.json',pair_refs)
(D/'evidence/RECOVERY_GRANT.DEVELOPMENT.exact.json').write_bytes(gp.read_bytes())
(D/'evidence/OLD_INIT_GRANT.exact.json').write_bytes(Path(g['old_grant_ref']['path']).read_bytes())
rr=resource.getrusage(resource.RUSAGE_SELF);end=time.monotonic();m={'process':PROCESS,'pid':os.getpid(),'start':{'process':PROCESS,'monotonic':ENTRY,'self_cpu':0.0},
    'end':{'process':PROCESS,'monotonic':end,'self_cpu':rr.ru_utime+rr.ru_stime},'self_cpu_seconds':rr.ru_utime+rr.ru_stime,
    'wall_seconds':end-ENTRY,'local_inclusive_wall_seconds':end-ENTRY,'native_wait_union_seconds':0,
    'measurement_status':'known','RUSAGE_kind':'RUSAGE_SELF','wall_semantics':'local_stage_inclusive_no_wait_deduction',
    'scope':'this standalone engineering precheck, separately reported, not replacing original five',
    'Python_pre_entry_wall':None,'post_checkpoint_report_packaging_exit_CPU':None,'post_checkpoint_report_packaging_exit_wall':None,
    'other_assistant_tool_processes_and_Drive_cost':None,'CPU_cap_certification':'NOT_ESTABLISHED','complete_CPU_upper_bound_claimed':False}
dump(D/'audit/PRECHECK_COST_CHECKPOINT.json',m)
report={'schema':'INIT-only-production-read-only-precheck-v1','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'file_identity_source_state_checks_passed':all(c['passed'] for c in CHECKS),'checks':CHECKS,'production_workspace':str(W),
    'original_journal':str(J),'production_unchanged':before==after,'source_execution_count':0,'recovery_or_CLI_calls':0,
    'old_INIT_helper_assembler_calls':0,'real_Library_calls':0,'GEN_calls':0,'model_requests':0,
    'old_observed_five_SELF_seconds':cpu,'old_observed_five_local_windows_seconds':wall,'original_measurements_not_replaced':True,
    'precheck_cost_ref':ref(D/'audit/PRECHECK_COST_CHECKPOINT.json'),'concurrency_evidence_ref':ref(D/'audit/PROCESS_SNAPSHOTS.json'),
    'global_exclusive_operator_attestation':'PENDING','candidate_creation_allowed':False,
    'candidate_not_created_reason':'Required sole-operator fact not independently established: infrastructure process FDs remain unreadable; parent confirmation pending.',
    'future_recovery_root_created':False,'enabled_grant_created':False,'CPU_cap_certification':'NOT_ESTABLISHED'}
dump(D/'PREFLIGHT_READ_ONLY.json',report)
print(json.dumps({'file_checks_passed':report['file_identity_source_state_checks_passed'],'check_count':len(CHECKS),'failed_checks':[c['check'] for c in CHECKS if not c['passed']],
  'production_files':len(after),'old_SELF':cpu,'old_local_wall':wall,'precheck_SELF':m['self_cpu_seconds'],'precheck_local_wall':m['wall_seconds'],'candidate_created':False,'operator_attestation':'PENDING'},ensure_ascii=False))
