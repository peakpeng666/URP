# INIT-only禁用候选绑定：待父精确文件核验

本次只创建禁用候选及证据。40项文件/身份/源pin/停点检查再次全部通过；45个原生产文件在复验前后及候选创建后均字节一致。

候选原路径：`/workspace/original132-init-only-precheck-20261006-g2uks153/INIT_ONLY_BINDING.CANDIDATE.json`。包内同名文件为完全相同的原字节副本，37,463 B，SHA256 `6ee7a6948aa0562e0c49280280f60496b675a15a59ce20837b2a70d5f4c555d2`。

原r2禁用grant的37个字段全部保留、逐值一致；完整原文另附在候选字段中，原grant原文件SHA仍为 `c24e15941c1a9caa4c6583e3ba14e5bd9b981c9b187349b5531a24f60c7ccff8`。execution_granted=false、independent_review_accepted=false，GEN/numeric=false，model/candidate/new-index-create/replace均0，archive最多1。源pin、原旧grant全文、原5条intent/receipt、pending/hash/两ID/v0、冻结859B/478B、固定动作顺序、60SELF/240local-wall及new_budget=false均保留。

门控只接受以下限定事实：父协调/授权任务范围内仅本producer可能写原namespace；其他审计在不同云机副本，当前父未启动或授权并行INIT/恢复/GEN/Library写入；两次可见进程快照无namespace writer，原锁可用，精确状态复验一致。声明原文及source_thread_id见 `evidence/PARENT_COORDINATION_DECLARATION.txt`、`audit/PARENT_COORDINATION_ATTESTATION.json`。

两个系统进程FD及所有外部OS/第三方全局状态继续unknown。未声称全OS排他性或未来永久锁定。声明不是执行批准；候选的父精确SHA接受仍待完成。原只读报告里“PENDING”是产生时尚未纳入父声明的原始状态，新的完整门控结论在 `INIT_ONLY_PREFLIGHT_REPORT.json`；原证据未改写。

未来独立activation预期路径仍为 `/workspace/original132-init-only-precheck-20261006-g2uks153/INIT_ONLY_ACTIVATION.APPROVED.json`，该文件不存在，固定生产 `.namespace-recovery` 也未创建。只有父独立接受候选全文/SHA和门控条件并另行作出执行决定后，才能创建未来activation；到时仍须复核操作协调、精确源/状态和单次入口条件。本条没有启用两个字段，没有运行恢复。

三次独立预检进程已知SELF checkpoint合计0.17329 s，非重叠local窗口合计0.12647194301825948 s；原五条观测SELF 0.225943 s /local 0.174136459 s只读保留。预检为独立工程证据，不替代或补造原生产receipt。其余工具/assistant/Drive/打包及checkpoint后尾部继续unknown，CPU_cap_certification=NOT_ESTABLISHED，无完整CPU上界声明，也未增发预算。

未调用recoverSuffix、recovery CLI、旧INIT/helper/assembler、Library读写、模型/OpenCode或GEN；未重新开发/修改六源、原grant、pending、权限或网络策略。主要交付是候选全文、精确SHA证明、40项预检、全部源pins、协调声明、前后45文件哈希及成本边界。
