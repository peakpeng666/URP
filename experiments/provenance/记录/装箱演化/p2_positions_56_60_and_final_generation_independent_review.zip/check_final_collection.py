"""Read-only final generation closure. No imported candidate/collector modules."""
from pathlib import Path
import collections, datetime, hashlib, json, time, zipfile

W=Path('/workspace/shared')
D=W/'p2_minimal_batch10_review'
A=W/'archive_p2_batch10_20261007'
def sha(b):return hashlib.sha256(b).hexdigest()
def j(p):return json.loads(p.read_text())
started=time.process_time()
paths=j(A/'source_paths.json')
idxmeta=paths['final_index']['metadata'];raw=Path(paths['final_index']['path']).read_bytes()
assert len(raw)==20518 and sha(raw)=='0acf864baf3fcb5771144ff85bcb9c925679d8a3ff4afffbf7e779c3fb70de18'
with zipfile.ZipFile(paths['final_index']['path']) as z:
 assert z.testzip() is None and len(z.namelist())==6
 mf=json.loads(z.read('FILE_MANIFEST.json'));assert len(mf)==5
 assert set(z.namelist())==set(mf)|{'FILE_MANIFEST.json'}
 for name,rec in mf.items():
  b=z.read(name);assert len(b)==rec['bytes'] and sha(b)==rec['sha256']
first_archive_raw=Path(j(A/'first_slot_source.json')['path']).read_bytes()
assert len(first_archive_raw)==76865 and sha(first_archive_raw)=='6f456fd7eb4ed0318de82e14e87a5bd4faa5a08a8bde110d1a8ac347cc722d6f'
first=D/'first_slot'
fm=j(first/'FILE_MANIFEST.json')['members']
assert len(fm)==9
for name,rec in fm.items():
 b=(first/name).read_bytes();assert len(b)==rec['bytes'] and sha(b)==rec['SHA256']
report=j(D/'final_index/FINAL_COLLECTION_REPORT.json')
status=j(D/'final_index/STATUS_SNAPSHOT.json')
assert (D/'final_index/STATUS_SNAPSHOT.json').read_bytes()==(D/'audit/STATUS_SNAPSHOT.json').read_bytes()
for n in ['COLLECTION_RECORD.json','TRANSPORT_RECOVERY_CONTINUATION.json']:
 assert (D/'final_index'/n).read_bytes()==(D/'audit'/n).read_bytes()
f=j(D/'data/executor/frozen_inputs.json')
cfg=f['freeze']['configuration']
assert cfg==report['configuration']
assert report['runner_SHA256']==sha((D/'data/executor/runner.py').read_bytes())
assert report['frozen_inputs_SHA256']==sha((D/'data/executor/frozen_inputs.json').read_bytes())
assert report['official_CLI_SHA256']==f['freeze']['cli_binary_sha256']
assert report['official_CLI_version']==f['freeze']['cli_version']
assert len(f['slots'])==60 and [x['record']['position'] for x in f['slots']]==list(range(1,61))
assert [x['record']['order'] for x in f['slots']]==list(range(73,133))
assert report['original_parent_draws']==sum(len(x['record']['parents']) for x in f['slots'])==78
assert report['original_arms']==dict(collections.Counter(x['record']['arm'] for x in f['slots']))=={'IID_TC':30,'EOH_TC':30}
folders={};batch_checks=[]
# Re-read each already-downloaded data and audit payload manifest, without rerunning any program.
for k,batch in enumerate(report['archive_batches'],1):
 root=W/f'p2_minimal_batch{k}_review'
 lo,hi=batch['positions'];assert (lo,hi)==(2+(k-1)*6,min(7+(k-1)*6,60))
 rv=j(root/'REVIEW.json')
 for kind in ('data','audit'):
  manifest=j(root/kind/'FILE_MANIFEST.json')
  actual={str(p.relative_to(root/kind)) for p in (root/kind).rglob('*') if p.is_file()}
  assert actual==set(manifest)|{'FILE_MANIFEST.json'}
  for n,e in manifest.items():
   b=(root/kind/n).read_bytes();assert len(b)==e['bytes'] and sha(b)==e['sha256']
  known_sha=rv['readback_'+kind+'_sha256'] if k<=2 else rv[kind+'_archive']['sha256']
  assert known_sha==batch[kind]['sha256']
  assert len(manifest)==batch[kind]['member_hashes_verified']
  assert batch[kind]['ACL_changed'] is False
  assert batch[kind]['parent_folder_ID']==('129-0z2ejXZg2rAkJe_Yxz876foi5mTy6' if kind=='data' else '1LfnXbRzcZlr59nZEotn0QE6mnbvT7Hhm')
 for n in ['executor/runner.py','executor/frozen_inputs.json','frozen_requested_configuration.raw.json']:
  assert (root/'data'/n).read_bytes()==(D/'data'/n).read_bytes()
 for folder in (root/'data/ledger').iterdir():
  assert folder.name not in folders;folders[folder.name]=folder
 batch_checks.append({'positions':[lo,hi],'data_id':batch['data']['Drive_ID'],'audit_id':batch['audit']['Drive_ID'],'data_zip_sha256':batch['data']['sha256'],'audit_zip_sha256':batch['audit']['sha256'],'stored_payload_hashes_reverified':len(j(root/'data/FILE_MANIFEST.json'))+len(j(root/'audit/FILE_MANIFEST.json'))})
first_folder=next((first/'ledger').iterdir());assert first_folder.name not in folders;folders[first_folder.name]=first_folder
assert len(folders)==60
rowmap={x['position']:x for x in report['slots']};assert set(rowmap)==set(range(2,61))
measuremap={x['position']:x for x in status['measurements']};assert set(measuremap)==set(range(2,61))
rows=[];previous_end=None;measurements=[]
for item in f['slots']:
 rec,pack=item['record'],item['pack'];pos=rec['position'];folder=folders[rec['slot_id']]
 result=j(folder/'result.json');dispatch=j(folder/'dispatch.json')
 prompt=(folder/'prompt.txt').read_bytes();answer=(folder/'answer.txt').read_bytes()
 assert prompt==pack['prompt'].encode() and sha(prompt)==pack['prompt_sha256']==rec['prompt_sha256']==dispatch['prompt_sha256']
 assert pack['serialized_messages_sha256']==rec['serialized_messages_sha256']
 assert dispatch['configuration']==cfg and dispatch['config_sha256']==f['freeze']['config_file_sha256']
 assert dispatch['frozen_inputs_sha256']==report['frozen_inputs_SHA256']
 assert dispatch['binary_sha256']==f['freeze']['cli_binary_sha256'] and dispatch['cli_version']==f['freeze']['cli_version']
 assert dispatch['position']==result['position']==pos and dispatch['slot_id']==result['slot_id']==rec['slot_id']
 assert result['answer_sha256']==sha(answer) and result['answer_bytes']==len(answer)
 assert result['cli_process_started'] and not result['fixture_only'] and not dispatch['fixture_only']
 assert result['provider_usage'] is None and result['provider_cost'] is None and result['physical_http_attempts'] is None
 assert result['provider_outcome']=='unknown'
 start=dispatch['dispatch_boundary_utc_seconds'];end=start+result['wall_seconds']
 if previous_end is not None:assert start>=previous_end-0.1
 previous_end=end
 if result['client_state']=='timeout':
  category='timeout_empty';assert result['exit_code']==-9 and not answer and result['finish_reasons']==[]
 elif result['finish_reasons']==['length']:
  category='length_empty';assert not answer and result['exit_code']==0
 else:
  category='stop_nonempty';assert result['finish_reasons']==['stop'] and result['exit_code']==0 and answer
 if pos>1:
  out=rowmap[pos]
  for key in ('position','slot_id','client_state','exit_code','wall_seconds','answer_bytes','answer_sha256','finish_reasons','capture_issues','cli_reported_tokens','cli_reported_usage_records'):
   assert out[key]==result[key]
  for key in ('order','arm','serialized_messages_sha256','prompt_sha256'):assert out[key]==rec[key]
  measurement=j(folder/'resource_observation.json')
  assert measurement==measuremap[pos]
  assert not measurement['historical_balance_or_whole_CPU_cap_certified'] and measurement['provider_CPU_seconds'] is None
  assert measurement['model_capture_wall_seconds']==result['wall_seconds']
  assert measurement['Python_SELF_seconds']<=30 and measurement['local_inclusive_wall_seconds']<=1020
  measurements.append(measurement)
 rows.append({'position':pos,'arm':rec['arm'],'category':category,'answer_bytes':len(answer),'answer_sha256':sha(answer),'dispatch_utc':datetime.datetime.fromtimestamp(start,datetime.timezone.utc).isoformat(),'end_utc':datetime.datetime.fromtimestamp(end,datetime.timezone.utc).isoformat()})
counts=dict(collections.Counter(x['category'] for x in rows));assert counts=={'stop_nonempty':50,'length_empty':1,'timeout_empty':9}
assert report['state']==status['state']=='completed' and report['remaining_unstarted']==status['remaining_unstarted']==0
assert status['new_terminal_positions']==list(range(2,61))
assert report['new_logical_CLI_launches']==59 and report['new_positions']==[2,60]
assert report['nonempty_public_answers']==49 and report['client_states']=={'exited':50,'timeout':9}
assert report['empty_public_answer_positions']==[x['position'] for x in rows[1:] if x['category']!='stop_nonempty']
assert report['explicit_client_timeout_failure_positions']==[x['position'] for x in rows if x['category']=='timeout_empty']
assert report['length_finish_positions']==[10]
for key in ('input','output','reasoning'):
 values=[rowmap[p]['cli_reported_tokens'][key] for p in range(2,61)]
 known=[x for x in values if isinstance(x,(int,float))]
 assert report['CLI_reported_tokens_partial'][key]=={'sum_available_CLI_reports':sum(known),'slots_with_available_reports':len(known),'slots_with_unknown_reports':len(values)-len(known)}
assert round(sum(x['Python_SELF_seconds'] for x in measurements),6)==report['observed_new_slot_Python_SELF_seconds_sum']==35.696424
assert round(sum(x['local_inclusive_wall_seconds'] for x in measurements),6)==report['observed_new_slot_local_inclusive_wall_seconds_sum']==30820.448394
assert report['per_slot_observed_resource_cap_exceedances']==[]
for key in ('provider_usage','provider_cost','physical_HTTP_attempts','provider_quota_remaining','full_historical_resource_balance','first_minimal_Python_SELF_and_original_controller_final_SELF','original_controller_exit_status_and_final_SELF'):assert report[key] is None
assert report['timeout_server_terminal_and_cancellation']=='unknown' and report['whole_CPU_cap_certified'] is False
ref=j(first/'FIRST_SLOT_VERIFICATION.json');cut=j(first/'CUTOVER_RECORD.json')
assert ref==j(D/'audit/FIRST_SLOT_VERIFICATION_REFERENCE.json')
assert sha((first_folder/'result.json').read_bytes())==ref['result_file_SHA256']
assert sha((first_folder/'dispatch.json').read_bytes())==ref['dispatch_file_SHA256']
assert report['old_journal_file_map_SHA256']==ref['original_journal_file_map_SHA256']==cut['old_production']['journal_file_map_SHA256']
assert report['old_journal_json_files']==ref['original_journal_json_files']==70
assert report['old_events']==ref['old_events']==11
assert report['old_HALT_preserved_from_unchanged_journal']==ref['old_HALT']==['unknown_stage_outcome_or_measurement']
assert report['old_collect_outcome_preserved']==ref['old_collect_outcome']=='unknown'
assert report['old_Library_claim_local_version_preserved']==str(cut['old_production']['Library_index_receipt']['current_version_number'])=='2'
assert all(report['old_preservation_checks'].values())
assert report['old_72_results_failures_and_historical_costs_written_or_reset'] is False
assert report['Library_writes_performed']==0
result={'status':'PASS_final_generation_archive_cross_check_WITH_SCOPE_LIMITS','P2_generation_terminals':60,'original132_logical_generation_terminals_including_previously_audited72':132,'counts':counts,'all_60_prompt_config_binary_and_order_bindings_rechecked':True,'all59_final_report_rows_match_original_archived_slot_records':True,'all59_measurement_records_match_original_archived_slot_records':True,'ten_archive_pairs_match_prior_download_SHA_receipts':True,'archive_batches':batch_checks,'first_slot_redownload_sha256':sha(first_archive_raw),'final_index_sha256':sha(raw),'final_index_bytes':len(raw),'final_index_payload_hashes_verified':5,'first_slot_manifest_hashes_verified':9,'serial_timing_all60_consistent':True,'last_generation_end_utc':rows[-1]['end_utc'],'empty_positions':report['empty_public_answer_positions'],'timeout_positions':report['explicit_client_timeout_failure_positions'],'length_positions':[10],'observed_new59_Python_SELF_seconds':35.696424,'observed_new59_local_inclusive_wall_seconds':30820.448394,'continuation_reported_self_seconds':status['continuation_observed_SELF_seconds'],'resource_scope':'Python SELF excludes native CLI/provider CPU. Continuation SELF overlaps some slot bookkeeping and is not added again. First SELF/original controller final SELF and historical balance remain unknown.','old_journal_preservation_evidence':'Final recorded map hash matches cutover and first-slot references,70 JSON/11 events/HALT/unknown outcome/local claim version2 consistent; original70 journal files not attached, so this review did not independently rehash those files or remote Library bytes.','producer_host_process_observation':'Report says active_OpenCode_processes=0 and builder includes /proc scan; no independent live probe or raw process transcript performed here.','reported_continuation_exit_status':report['continuation_exec_exit_status'],'continuation_exit_status_not_independent_process_wait_receipt':True,'provider_HTTP_usage_cost_quota_server_cancel':'unknown','scientific_admission_or_scoring_performed_by_this_review':False,'candidate_or_collector_execution':False,'network_model_calls':False,'external_writes':False,'cpu_seconds':time.process_time()-started}
(D/'FINAL_COLLECTION_REVIEW.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
(D/'ALL60_TERMINAL_ROWS.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='archive_batches'},ensure_ascii=False,indent=2))
