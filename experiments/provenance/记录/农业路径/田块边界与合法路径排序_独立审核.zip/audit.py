"""Independent geometry/result audit: imports no experiment implementation."""
import csv, hashlib, itertools, json, math, random, resource, signal, statistics, time
from fractions import Fraction as F
from pathlib import Path
ROOT=Path('/workspace/shared/field_geometry_route_test_20261008');OUT=Path(__file__).parent
resource.setrlimit(resource.RLIMIT_CPU,(14,15));signal.alarm(30)
t0=time.process_time();w0=time.perf_counter()
def read(p):return json.loads((ROOT/p).read_text())
def close(a,b):assert abs(a-b)<=1e-9,(a,b)
def length(a,b):return math.sqrt((a[0]-b[0])**2+(a[1]-b[1])**2)
def inside(p,poly):
    # Orthogonal boundary checks plus exact horizontal ray parity.
    crossings=0
    for a,b in zip(poly,poly[1:]+poly[:1]):
        if a[0]==b[0]:
            if p[0]==a[0] and min(a[1],b[1])<=p[1]<=max(a[1],b[1]):return True
            if (a[1]>p[1])!=(b[1]>p[1]) and a[0]>p[0]:crossings+=1
        elif p[1]==a[1] and min(a[0],b[0])<=p[0]<=max(a[0],b[0]):return True
    return crossings%2==1

def segment(a,b,poly):
    # All horizontal/vertical supporting-line crossings partition this segment
    # into intervals where orthogonal polygon membership is constant.
    cuts={F(0),F(1)}
    for axis in (0,1):
        v=b[axis]-a[axis]
        if v:
            for c in {p[axis] for p in poly}:
                t=F(c-a[axis],v)
                if 0<=t<=1:cuts.add(t)
    cuts=sorted(cuts);probes=cuts+[(x+y)/2 for x,y in zip(cuts,cuts[1:])]
    return all(inside((F(a[0])+t*(b[0]-a[0]),F(a[1])+t*(b[1]-a[1])),poly) for t in probes)

def union_segment(a,b,rects):
    # Separate rectangle clipping + exact union of parameter intervals.
    intervals=[]
    for rect in rects:
        lo,hi=F(0),F(1)
        for axis in (0,1):
            v=b[axis]-a[axis];mn,mx=rect[axis],rect[axis+2]
            if not v:
                if not mn<=a[axis]<=mx:lo,hi=F(1),F(0);break
            else:
                x,y=sorted((F(mn-a[axis],v),F(mx-a[axis],v)));lo=max(lo,x);hi=min(hi,y)
        if lo<=hi:intervals.append((lo,hi))
    end=F(0)
    for lo,hi in sorted(intervals):
        if lo>end:return False
        end=max(end,hi)
    return end>=1

def validpoly(poly):
    assert all(type(c)==int for p in poly for c in p) and len(set(map(tuple,poly)))==len(poly)
    edges=list(zip(poly,poly[1:]+poly[:1]))
    for a,b in edges:assert (a[0]==b[0]) != (a[1]==b[1])
    for i,(a,b) in enumerate(edges):
        for j,(c,d) in enumerate(edges):
            if j<=i or j==i+1 or (i==0 and j==len(edges)-1):continue
            touch=all(max(min(a[k],b[k]),min(c[k],d[k]))<=min(max(a[k],b[k]),max(c[k],d[k])) for k in (0,1))
            assert not touch
    area=F(sum(a[0]*b[1]-b[0]*a[1] for a,b in edges),2);assert area>0;return area

def regen(inst):
    r=random.Random(inst['seed']);w,h=r.randint(60,100),r.randint(60,100)
    left,right=r.randint(w//5,w//3),w-r.randint(w//5,w//3)
    bottom,top=r.randint(h//5,h//3),h-r.randint(h//5,h//3)
    assert inst['dimensions']==dict(width=w,height=h,left=left,right=right,bottom=bottom,top=top)
    fs=inst['family']
    rects={'rectangle':[[0,0,w,h]],'L':[[0,0,w,bottom],[0,bottom,left,h]],'U':[[0,0,w,bottom],[0,bottom,left,h],[right,bottom,w,h]],'H':[[0,0,left,h],[right,0,w,h],[left,bottom,right,top]]}[fs]
    assert inst['rectangle_decomposition']==rects and inst['depot']==[1,1]
    tasks=[];draws=[]
    while len(tasks)<7:
        p=[r.randint(1,w-1),r.randint(1,h-1)]
        accepted=any(x0<=p[0]<=x1 and y0<=p[1]<=y1 for x0,y0,x1,y1 in rects) and p!=[1,1] and p not in tasks
        draws.append(dict(point=p,accepted=accepted))
        if accepted:tasks.append(p)
    assert tasks==inst['tasks'] and draws==inst['sampling_draws']

def cost(order,d):
    rs=(0,)+tuple(order)+(0,);return math.fsum(d[a][b] for a,b in zip(rs,rs[1:]))

hashes=[]
for line in (ROOT/'evidence/pre_run.sha256').read_text().splitlines():
    h,p=line.split('  ',1);assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h;hashes.append(p)
assert len(hashes)==8
cfg=read('freeze.json');launch=read('evidence/launch_status.json');status=read('evidence/run_status.json')
assert cfg['formal_frozen_utc']<launch['start_utc'] and launch['exit_code']==0 and status['successful_fields']==16 and not read('raw/failures.json')
assert (ROOT/'evidence/launch_attempt_01/exit_code.txt').read_text().strip()=='127'
insts=read('instances.json');assert len(insts)==16
rows=[];matrices=[];pairs=legs=segments=enum=0
for pos,inst in enumerate(insts):
    gid=inst['instance_id'];assert inst['seed']==cfg['master_seed']+100*(pos//4)+pos%4
    assert inst['family']==cfg['families'][pos//4];regen(inst)
    raw=read('raw/'+gid+'.json');poly=inst['polygon'];rects=inst['rectangle_decomposition'];area=validpoly(poly)
    assert area==sum((r[2]-r[0])*(r[3]-r[1]) for r in rects)
    for a,b in itertools.combinations(rects,2):assert not all(max(a[k],b[k])<min(a[k+2],b[k+2]) for k in (0,1))
    xs=sorted({p[0] for p in poly}|{v for r in rects for v in [r[0],r[2]]});ys=sorted({p[1] for p in poly}|{v for r in rects for v in [r[1],r[3]]})
    xs=xs+[F(a+b,2) for a,b in zip(xs,xs[1:])];ys=ys+[F(a+b,2) for a,b in zip(ys,ys[1:])]
    for x,y in itertools.product(xs,ys):assert inside((x,y),poly)==any(x0<=x<=x1 and y0<=y<=y1 for x0,y0,x1,y1 in rects)
    services=[inst['depot']]+inst['tasks'];nodes=[]
    for p in poly+services:
        if p not in nodes:nodes.append(p)
    assert raw['nodes']==nodes and raw['services']==services and len(set(map(tuple,services)))==8
    ids=[nodes.index(p) for p in services];assert raw['service_nodes']==ids
    nv=len(nodes);fw=[[math.inf]*nv for _ in nodes]
    for i in range(nv):fw[i][i]=0.
    edges={};covered={}
    for i,j in itertools.combinations(range(nv),2):
        ok=segment(nodes[i],nodes[j],poly);assert ok==union_segment(nodes[i],nodes[j],rects);covered[i,j]=ok;pairs+=1
        if ok:edges[i,j]=length(nodes[i],nodes[j]);fw[i][j]=fw[j][i]=edges[i,j]
    assert len(raw['visibility_pair_checks'])==len(covered) and {(e['i'],e['j']) for e in raw['visibility_graph_edges']}==set(edges)
    for e in raw['visibility_pair_checks']:assert e['covered']==e['independent_covered']==covered[e['i'],e['j']]
    for e in raw['visibility_graph_edges']:close(e['length'],edges[e['i'],e['j']])
    for k in range(nv):
        for i in range(nv):
            for j in range(nv):fw[i][j]=min(fw[i][j],fw[i][k]+fw[k][j])
    geo=[[fw[i][j] for j in ids] for i in ids];eu=[[length(a,b) for b in services] for a in services]
    for i,j in itertools.product(range(8),repeat=2):
        legs+=1;close(geo[i][j],raw['geodesic_matrix'][i][j]);close(eu[i][j],raw['euclidean_matrix'][i][j]);assert math.isfinite(geo[i][j])
        path=raw['legal_leg_paths'][i][j];pts=path['points'];assert pts==[nodes[k] for k in path['node_ids']] and pts[0]==services[i] and pts[-1]==services[j]
        v=math.fsum(length(a,b) for a,b in zip(pts,pts[1:]));close(v,path['length_recomputed']);close(v,geo[i][j])
        for a,b in zip(pts,pts[1:]):assert segment(a,b,poly) and union_segment(a,b,rects);segments+=1
    orders=list(itertools.permutations(range(1,8)));ind=[(cost(o,eu),cost(o,geo),o) for o in orders];assert len(ind)==5040;enum+=5040
    # Exact float tie counts and lex tie-break are evaluated on frozen original matrices;
    # independent sqrt/Floyd can differ in last-bit arithmetic, so optimal cost cross-check is numeric.
    saved=[(cost(o,raw['euclidean_matrix']),cost(o,raw['geodesic_matrix']),o) for o in orders]
    eo=min(saved,key=lambda r:(r[0],r[2]));go=min(saved,key=lambda r:(r[1],r[2]))
    for k,opt in [(0,eo[0]),(1,go[1])]:
        prefix='euclidean' if k==0 else 'geodesic';assert raw['validation'][prefix+'_exact_float_ties']==sum(t[k]==opt for t in saved)
        assert raw['validation'][prefix+'_near_ties_1e9']==sum(abs(t[k]-opt)<=1e-9 for t in saved)
    assert raw['euclidean_order_solution']['order']==list(eo[2]) and raw['geodesic_order_solution']['order']==list(go[2])
    for key,v in [('euclidean_objective',eo[0]),('repaired_euclidean_order_cost',eo[1]),('geodesic_optimal_cost',go[1])]:close(raw[key],v)
    close(min(t[0] for t in ind),eo[0]);close(min(t[1] for t in ind),go[1]);close(cost(eo[2],geo),eo[1])
    with (ROOT/'raw'/f'{gid}_all_orders.csv').open() as f:
        records=list(csv.DictReader(f));assert len(records)==5040
        for idx,(rec,t) in enumerate(zip(records,saved)):
            assert int(rec['permutation_index'])==idx and tuple(map(int,rec['task_service_ids'].split()))==t[2]
            close(float(rec['euclidean_cost']),t[0]);close(float(rec['geodesic_cost']),t[1]);close(float(rec['euclidean_cost']),ind[idx][0]);close(float(rec['geodesic_cost']),ind[idx][1])
    for sol in ['euclidean_order_solution','geodesic_order_solution']:
        rr=raw[sol];stops=[0]+rr['order']+[0];assert rr['stops']==stops and sorted(rr['order'])==list(range(1,8)) and len(rr['legs'])==8
        ill=[];polyline=[services[0]]
        for (a,b),leg in zip(zip(stops,stops[1:]),rr['legs']):
            ok=segment(services[a],services[b],poly)
            if not ok:ill.append([a,b])
            assert leg['from_service']==a and leg['to_service']==b and leg['direct_covered']==ok
            assert leg['legal_path']==raw['legal_leg_paths'][a][b]['points'];close(leg['legal_cost'],geo[a][b]);polyline+=leg['legal_path'][1:]
        assert ill==rr['direct_illegal_legs'] and len(ill)==rr['direct_illegal_leg_count'] and polyline==rr['legal_polyline']
        close(rr['legal_length_recomputed'],math.fsum(length(a,b) for a,b in zip(polyline,polyline[1:])))
    penalty=eo[1]-go[1];close(penalty,raw['absolute_cost_penalty']);close(penalty/go[1],raw['relative_cost_penalty'])
    assert raw['same_order_up_to_reversal']==(eo[2] in [go[2],go[2][::-1]])
    if inst['family']=='rectangle':
        assert all(abs(geo[i][j]-eu[i][j])<=1e-9 for i,j in itertools.product(range(8),repeat=2)) and abs(penalty)<=1e-9 and raw['euclidean_order_solution']['direct_illegal_leg_count']==0
    rows.append({'id':gid,'family':inst['family'],'euclidean_objective':eo[0],'legal_repaired_cost':eo[1],'legal_optimum':go[1],'illegal_legs':raw['euclidean_order_solution']['direct_illegal_leg_count'],'order_penalty_percent':100*penalty/go[1],'repair_increase_percent':100*(eo[1]/eo[0]-1)})
    matrices.append({'id':gid,'independent_euclidean':eu,'independent_geodesic':geo,'independent_optimum_euclidean':min(t[0] for t in ind),'independent_optimum_geodesic':min(t[1] for t in ind)})
conc=[r for r in rows if r['family']!='rectangle'];cs={'fields':12,'positive_penalty_fields':sum(r['order_penalty_percent']>1e-9 for r in conc),'illegal_direct_legs':sum(r['illegal_legs'] for r in conc),'total_direct_legs':96,'mean_order_penalty_percent':statistics.mean(r['order_penalty_percent'] for r in conc),'worst_order_penalty_percent':max(r['order_penalty_percent'] for r in conc),'mean_legal_repair_increase_percent':statistics.mean(r['repair_increase_percent'] for r in conc)}
ss=next(x for x in read('summary.json') if x['group']=='concave');close(cs['mean_order_penalty_percent'],ss['mean_order_penalty_pct']);close(cs['mean_legal_repair_increase_percent'],ss['mean_legal_repair_increase_pct']);assert cs['positive_penalty_fields']==6 and cs['illegal_direct_legs']==17 and enum==80640
report={'status':'PASS','input_source_frozen_hashes_checked':8,'input_draws_independently_regenerated':16,'source_imports_or_main_reruns':0,'geometry':'Independent exact Fraction supporting-line subdivision with orthogonal polygon ray membership, cross-checked with rectangle interval union; no buffer or feasibility tolerance. All16 simple positive-area polygons and rectangle decomposition equality verified.','full_graph_pairs_checked':pairs,'service_legs_verified':legs,'path_segments_verified':segments,'permutation_rows_verified':enum,'matrix_cost_evaluations':enum*2,'tie_rule':'Original strict float minimum then lexicographic order confirmed against all CSV rows; exact and 1e-9 near-tie counts checked. Independently recomputed sqrt/Floyd optimum costs agree to 1e-9; an alternative last-bit-tied order would not be a mathematical contradiction.','rectangle_negative_controls_passed':4,'concave':cs,'launch_provenance':{'failed_launcher_exit':127,'failed_launch_statement':'Recorded evidence says missing /usr/bin/time failed before experiment.py; preserved explanatory note and exit code, not an independently timestamped execution trace.','formal_launch_exit':0,'formal_launch_child_cpu_seconds':launch['child_total_cpu_seconds'],'formal_launch_wall_seconds':launch['external_wall_seconds'],'claim':'One saved numerical main pass after the launcher failure; frozen input/source hashes unchanged.'},'limitations':['16 synthetic orthogonal fields and point robot; no footprint, minimum turning radius, crop/soil model, working swath or headland.','Closed boundary travel with instantaneous turns is allowed; direct Euclidean segments in concave fields are not all legal.','Task service order is exact; incidental traversal of another task without service is allowed by protocol.','9.608848% is mean (legal repaired cost / direct Euclidean objective -1); 0.825227% is mean (legal repaired cost / legal optimum -1). Different denominators and different questions.','Geometric membership is exact rational; lengths and path/route objective arithmetic are floating point, not certified interval optimality.','No generalization to realistic agricultural machines or representative field distribution. Hashes/times are local provenance, not tamper-proof proof of unique historic execution.'],'resource':{'audit_cpu_seconds':time.process_time()-t0,'audit_wall_seconds':time.perf_counter()-w0,'cpu_cap_seconds':15,'wall_cap_seconds':30,'main_solver_reruns':0,'external_api_calls':0,'scientific_model_calls':0,'installs':0,'monetary_cost':'No external API purchase; platform/assistant token charges unavailable, not asserted zero.'}}
for name,obj in [('AUDIT.json',report),('FIELD_RESULTS.json',rows),('INDEPENDENT_MATRICES.json',matrices)]: (OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False))
