Independent read-only audit of field_aware_cvrp_20261008.
See REPORT_ZH.txt and AUDIT.json for conclusions and limits.
No experiment source was imported or executed. The original directory and evidence ZIP remain unchanged.
To repeat only this audit, copy audit.py to a new output directory and run python audit.py with the original inputs available at the declared paths. It reads the original package, ZIP, previous dataset and provenance source copies, and writes only alongside its copied script. Standard-library Python; CPU cap15s, wall alarm30s. This is an independent verification pass, not a new research experiment.
