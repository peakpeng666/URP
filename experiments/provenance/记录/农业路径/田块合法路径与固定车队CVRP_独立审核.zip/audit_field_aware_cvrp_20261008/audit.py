"""Independent read-only CVRP evidence audit. No original implementation import or execution.
Exact geometry methods reused from prior independent field geometry audit.
New restricted-growth capacity partitioning, permutation enumeration and evidence checks.
"""
import csv, datetime, gzip, hashlib, itertools, json, math, random, resource, signal, statistics, time, zipfile
from fractions import Fraction as F
from pathlib import Path
ROOT=Path('/workspace/shared/field_aware_cvrp_20261008')
OUT=Path(__file__).resolve().parent
ZIP=Path('/workspace/shared/field_aware_cvrp_20261008_evidence.zip')
OLD=Path('/workspace/shared/field_geometry_route_test_20261008/instances.json')
resource.setrlimit(resource.RLIMIT_CPU,(14,15)); signal.alarm(30)
t0=time.process_time(); w0=time.perf_counter()
def read(p): return json.loads((ROOT/p).read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def close(a,b): assert math.isfinite(a) and math.isfinite(b) and abs(a-b)<=1e-9,(a,b)
def length(a,b): return math.sqrt((a[0]-b[0])**2+(a[1]-b[1])**2)
def save(p,v): (OUT/p).write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def inside(p,poly):
    # Orthogonal boundary checks plus exact horizontal ray parity.
    crossings=0
    for a,b in zip(poly,poly[1:]+poly[:1]):
        if a[0]==b[0]:
            if p[0]==a[0] and min(a[1],b[1])<=p[1]<=max(a[1],b[1]):return True
            if (a[1]>p[1])!=(b[1]>p[1]) and a[0]>p[0]:crossings+=1
        elif p[1]==a[1] and min(a[0],b[0])<=p[0]<=max(a[0],b[0]):return True
    return crossings%2==1

def segment(a,b,poly):
    # All horizontal/vertical supporting-line crossings partition this segment
    # into intervals where orthogonal polygon membership is constant.
    cuts={F(0),F(1)}
    for axis in (0,1):
        v=b[axis]-a[axis]
        if v:
            for c in {p[axis] for p in poly}:
                t=F(c-a[axis],v)
                if 0<=t<=1:cuts.add(t)
    cuts=sorted(cuts);probes=cuts+[(x+y)/2 for x,y in zip(cuts,cuts[1:])]
    return all(inside((F(a[0])+t*(b[0]-a[0]),F(a[1])+t*(b[1]-a[1])),poly) for t in probes)

def union_segment(a,b,rects):
    # Separate rectangle clipping + exact union of parameter intervals.
    intervals=[]
    for rect in rects:
        lo,hi=F(0),F(1)
        for axis in (0,1):
            v=b[axis]-a[axis];mn,mx=rect[axis],rect[axis+2]
            if not v:
                if not mn<=a[axis]<=mx:lo,hi=F(1),F(0);break
            else:
                x,y=sorted((F(mn-a[axis],v),F(mx-a[axis],v)));lo=max(lo,x);hi=min(hi,y)
        if lo<=hi:intervals.append((lo,hi))
    end=F(0)
    for lo,hi in sorted(intervals):
        if lo>end:return False
        end=max(end,hi)
    return end>=1

def validpoly(poly):
    assert all(type(c)==int for p in poly for c in p) and len(set(map(tuple,poly)))==len(poly)
    edges=list(zip(poly,poly[1:]+poly[:1]))
    for a,b in edges:assert (a[0]==b[0]) != (a[1]==b[1])
    for i,(a,b) in enumerate(edges):
        for j,(c,d) in enumerate(edges):
            if j<=i or j==i+1 or (i==0 and j==len(edges)-1):continue
            touch=all(max(min(a[k],b[k]),min(c[k],d[k]))<=min(max(a[k],b[k]),max(c[k],d[k])) for k in (0,1))
            assert not touch
    area=F(sum(a[0]*b[1]-b[0]*a[1] for a,b in edges),2);assert area>0;return area


def regenerate(a,cfg,pos):
    family=cfg['families'][pos//3];seed=cfg['master_seed']+100*(pos//3)+pos%3
    assert a['family']==family and a['geometry_seed']==seed and a['demand_seed']==seed+1000000
    r=random.Random(seed); w,h=r.randint(72,116),r.randint(72,116)
    left,right=r.randint(w//5,w//3),w-r.randint(w//5,w//3)
    bottom,top=r.randint(h//5,h//3),h-r.randint(h//5,h//3)
    rects={'rect':[[0,0,w,h]],'L':[[0,0,w,bottom],[0,bottom,left,h]],'U':[[0,0,w,bottom],[0,bottom,left,h],[right,bottom,w,h]],'H':[[0,0,left,h],[right,0,w,h],[left,bottom,right,top]]}[family]
    polygons={'rect':[[0,0],[w,0],[w,h],[0,h]],'L':[[0,0],[w,0],[w,bottom],[left,bottom],[left,h],[0,h]],'U':[[0,0],[w,0],[w,h],[right,h],[right,bottom],[left,bottom],[left,h],[0,h]],'H':[[0,0],[left,0],[left,bottom],[right,bottom],[right,0],[w,0],[w,h],[right,h],[right,top],[left,top],[left,h],[0,h]]}
    pts=[];draws=[]
    while len(pts)<10:
        p=[r.randint(1,w-1),r.randint(1,h-1)]
        ok=any(x0<=p[0]<=x1 and y0<=p[1]<=y1 for x0,y0,x1,y1 in rects) and p not in pts
        draws.append({'point':p,'accepted':ok})
        if ok:pts.append(p)
    d=[1,1,2,2,3,3,4,4,4];random.Random(seed+1000000).shuffle(d)
    gid=f'FAC_{family}_{pos%3+1:02d}'
    b={'instance_id':gid,'base_field_id':gid,'family':family,'geometry_seed':seed,'demand_seed':seed+1000000,'polygon':polygons[family],'rectangle_decomposition':rects,'coordinates':pts,'demands':[0]+d,'capacity':9,'max_vehicles':3,'dimensions':dict(width=w,height=h,left=left,right=right,bottom=bottom,top=top),'sampling_draws':draws}
    assert b==a;return b

def canonical(plan):return tuple(sorted(min(tuple(r),tuple(r)[::-1]) for r in plan))
def validplan(p,demands):
    assert len(p)==3 and all(p) and sorted(x for r in p for x in r)==list(range(1,10))
    assert all(sum(demands[x] for x in r)<=9 for r in p)

def enumerate_plans(d):
    # Restricted-growth labels: each ascending customer joins an existing block,
    # or starts exactly one new block. This visits every unlabeled partition once.
    parts=[]
    def visit(i,bins,loads):
        if i==10:
            if len(bins)==3:parts.append(tuple(tuple(b) for b in bins))
            return
        if len(bins)+(10-i)<3:return
        for j in range(len(bins)):
            if loads[j]+d[i]<=9:
                bins[j].append(i);loads[j]+=d[i];visit(i+1,bins,loads);loads[j]-=d[i];bins[j].pop()
        if len(bins)<3:visit(i+1,bins+[[i]],loads+[d[i]])
    visit(1,[],[])
    routes={}
    for n in range(1,10):
        for s in itertools.combinations(range(1,10),n):
            if sum(d[x] for x in s)<=9:routes[s]=[p for p in itertools.permutations(s) if len(p)==1 or p[0]<p[-1]]
    plans=set()
    for blocks in parts:
        for p in itertools.product(*(routes[b] for b in blocks)):
            c=tuple(sorted(p));assert c not in plans;plans.add(c)
    return sorted(plans),len(parts),len(routes),sum(map(len,routes.values()))

def costs(p,mat):return math.fsum(mat[a][b] for r in p for a,b in zip((0,)+r,r+(0,)))

assert sha(ZIP)=='d311e3fa9a81a89f04978e5d323a516ad02151bf805aebe5549eac9ca02be990'
manifest={}
for ln in (ROOT/'SHA256SUMS.txt').read_text().splitlines():
    h,p=ln.split('  ',1);assert sha(ROOT/p)==h;manifest[p]=h
assert set(manifest)=={str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file() and p.name!='SHA256SUMS.txt'}
with zipfile.ZipFile(ZIP) as z:
    members={n.split('/',1)[1]:n for n in z.namelist() if '/' in n and not n.endswith('/')}
    assert set(members)==set(manifest)|{'SHA256SUMS.txt'}
    for p,n in members.items():assert z.read(n)==(ROOT/p).read_bytes()
pre=read('freeze/PRE_GENERATION_FREEZE.json');frozen=read('freeze/PRE_RUN_FREEZE.json')
for f in [pre,frozen]:
    for p,h in f['sha256'].items():assert sha(ROOT/p)==h
cfg=read('freeze/PROTOCOL.json');gen=read('evidence/GENERATION.json');start=read('evidence/STARTED.json');run=read('evidence/RUN_STATUS.json');launch=read('evidence/MAIN_LAUNCH_RECEIPT.json')
assert pre['utc']<gen['utc']<frozen['utc']<start['utc']<run['utc']<launch['utc']
assert cfg['main_runs']==start['main_run_number']==run['main_run_number']==1
assert launch['exit_code']==0 and not launch['wall_timeout'] and (ROOT/'evidence/MAIN_EXIT_CODE.txt').read_text().strip()=='0'
assert run['status']=='PASS' and run['planned_fields']==run['attempted_fields']==run['completed_fields']==12 and run['failed_fields']==0 and read('raw/failures.json')==[]
assert run['cpu_seconds']<=90 and run['wall_seconds']<=150 and launch['outer_wall_seconds']>=run['wall_seconds']
assert (ROOT/'evidence/LAUNCH_ATTEMPT_1_EXIT_CODE.txt').read_text().strip()=='127'
assert '/usr/bin/time: No such file or directory' in (ROOT/'evidence/LAUNCH_ATTEMPT_1_STDERR.log').read_text()
assert not (ROOT/'evidence/MAIN_STDERR.log').read_text().strip()
std=[json.loads(x) for x in (ROOT/'evidence/MAIN_STDOUT.log').read_text().splitlines()]
assert len(std)==13 and std[-1]==run and len({x['instance_id'] for x in std[:-1]})==12
provenance=read('freeze/SOURCE_PROVENANCE.json')
for p,m in provenance['copies'].items():assert sha(ROOT/p)==m['copy_sha256']==m['original_sha256']==sha(Path(m['origin'])) and m['unchanged']
insts=read('input/instances.json');assert len(insts)==12
fresh=[regenerate(a,cfg,i) for i,a in enumerate(insts)]
regenerated_bytes=(json.dumps(fresh,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
assert regenerated_bytes==(ROOT/'input/instances.json').read_bytes() and hashlib.sha256(regenerated_bytes).hexdigest()==gen['sha256']
old=json.loads(OLD.read_text());assert len(old)==16
assert len({json.dumps(a['polygon']) for a in fresh})==12 and all(a['polygon']!=b['polygon'] for a in fresh for b in old)
rows=[];matrices=[];counts={'graph_pairs':0,'service_matrix_entries':0,'all_pair_path_segments':0,'selected_plan_legs':0,'selected_plan_path_segments':0,'enumerated_plans':0,'matrix_objective_evaluations':0,'raw_csv_rows':0,'incidental_service_waypoints':0,'incidental_depot_waypoints':0}
for inst in insts:
    gid=inst['instance_id'];poly=inst['polygon'];rects=inst['rectangle_decomposition'];services=inst['coordinates'];demands=inst['demands'];area=validpoly(poly)
    assert len(services)==len(set(map(tuple,services)))==10 and len(demands)==10 and demands[0]==0
    assert sum(demands)==24 and sorted(demands[1:])==[1,1,2,2,3,3,4,4,4] and inst['capacity']==9 and inst['max_vehicles']==3
    assert sum(demands)>2*inst['capacity'] and all(inside(p,poly) for p in services)
    assert area==sum((r[2]-r[0])*(r[3]-r[1]) for r in rects)
    for a,b in itertools.combinations(rects,2):assert not all(max(a[k],b[k])<min(a[k+2],b[k+2]) for k in (0,1))
    xs=sorted({p[0] for p in poly}|{r[k] for r in rects for k in [0,2]});ys=sorted({p[1] for p in poly}|{r[k] for r in rects for k in [1,3]})
    xs=xs+[F(a+b,2) for a,b in zip(xs,xs[1:])];ys=ys+[F(a+b,2) for a,b in zip(ys,ys[1:])]
    for x,y in itertools.product(xs,ys):assert inside((x,y),poly)==any(x0<=x<=x1 and y0<=y<=y1 for x0,y0,x1,y1 in rects)
    raw=read(f'raw/{gid}/matrices_and_paths.json');result=read(f'raw/{gid}/result.json');nodes=[]
    for p in poly+services:
        if p not in nodes:nodes.append(p)
    sn=[nodes.index(p) for p in services];assert raw['nodes']==nodes and raw['services']==services and raw['service_node_ids']==sn
    nv=len(nodes);fw=[[math.inf]*nv for _ in nodes];covered={};edges={}
    for i in range(nv):fw[i][i]=0.;covered[i,i]=True
    for i,j in itertools.combinations(range(nv),2):
        ok=segment(nodes[i],nodes[j],poly);assert ok==union_segment(nodes[i],nodes[j],rects);covered[i,j]=covered[j,i]=ok;counts['graph_pairs']+=1
        if ok:fw[i][j]=fw[j][i]=length(nodes[i],nodes[j]);edges[i,j]=fw[i][j]
    assert len(raw['visibility_checks'])==nv*(nv-1)//2
    assert {tuple(z['nodes']) for z in raw['visibility_checks']}==set(itertools.combinations(range(nv),2))
    for z in raw['visibility_checks']:assert z['covered']==z['independent_covered']==covered[tuple(z['nodes'])]
    assert len(raw['visibility_edges'])==len(edges) and {tuple(z['nodes']) for z in raw['visibility_edges']}==set(edges)
    for z in raw['visibility_edges']:close(z['distance'],edges[tuple(z['nodes'])])
    for k in range(nv):
        for i in range(nv):
            for j in range(nv):fw[i][j]=min(fw[i][j],fw[i][k]+fw[k][j])
    E=[[length(a,b) for b in services] for a in services];G=[[fw[i][j] for j in sn] for i in sn]
    sE,sG=raw['euclidean_matrix'],raw['legal_matrix'];node_lookup={tuple(p):i for i,p in enumerate(nodes)}
    max_matrix_error=0.
    for i,j in itertools.product(range(10),repeat=2):
        counts['service_matrix_entries']+=1;close(sE[i][j],E[i][j]);close(sG[i][j],G[i][j]);assert sE[i][j]==sE[j][i] and sG[i][j]==sG[j][i] and sG[i][j]>=sE[i][j]-1e-9
        max_matrix_error=max(max_matrix_error,abs(sG[i][j]-G[i][j]))
        assert raw['direct_covered_matrix'][i][j]==covered[sn[i],sn[j]]
        pp=raw['legal_leg_paths'][i][j];ns=pp['node_ids'];pts=pp['points']
        assert pts==[nodes[t] for t in ns] and ns[0]==sn[i] and ns[-1]==sn[j]
        assert ns==raw['legal_leg_paths'][j][i]['node_ids'][::-1]
        assert all(covered[a,b] for a,b in zip(ns,ns[1:]));counts['all_pair_path_segments']+=len(ns)-1
        value=math.fsum(length(a,b) for a,b in zip(pts,pts[1:]));close(value,pp['cost']);close(value,G[i][j]);assert value==sG[i][j]
    plans,part_count,subset_count,route_count=enumerate_plans(demands)
    assert (len(plans),part_count,subset_count,route_count)==(9918,303,147,753)
    enumer=result['enumeration']
    assert [enumer[x] for x in ['canonical_feasible_plan_count','feasible_unlabelled_customer_partitions','capacity_feasible_subsets','canonical_feasible_single_routes']]==[len(plans),part_count,subset_count,route_count]
    saved={};ind=[]
    for p in plans:
        validplan(p,demands);assert canonical(p)==p
        se,sg,ie,ig=costs(p,sE),costs(p,sG),costs(p,E),costs(p,G)
        close(se,ie);close(sg,ig);saved[p]=(se,sg);ind.append((ie,ig,p))
    counts['enumerated_plans']+=len(plans);counts['matrix_objective_evaluations']+=4*len(plans)
    seen=set()
    with gzip.open(ROOT/f'raw/{gid}/all_canonical_plans.csv.gz','rt',newline='') as f:
        for idx,rr in enumerate(csv.DictReader(f)):
            p=tuple(tuple(map(int,r.split('-'))) for r in rr['canonical_routes'].split('|'))
            assert int(rr['index'])==idx and p not in seen and p in saved;seen.add(p)
            assert (float(rr['euclidean_cost']),float(rr['legal_cost']))==saved[p];counts['raw_csv_rows']+=1
    assert seen==set(plans)
    ep=min(plans,key=lambda p:(saved[p][0],p));gp=min(plans,key=lambda p:(saved[p][1],p));eo,eg=saved[ep];go=saved[gp][1]
    close(min(t[0] for t in ind),eo);close(min(t[1] for t in ind),go)
    ties=enumer['tie_sensitivity']
    for name,width in [('euclidean_exact_float_optima',0.),('euclidean_within_1e_9',1e-9)]:
        matches=[p for p in plans if saved[p][0]==eo] if width==0 else [p for p in plans if saved[p][0]<=eo+width]
        lo=min(matches,key=lambda p:(saved[p][1],p));hi=max(matches,key=lambda p:(saved[p][1],p));record=ties[name]
        assert record['count']==len(matches)==1 and record['width_absolute']==width
        assert record['minimum_legal_plan']==[list(x) for x in lo] and record['maximum_legal_plan']==[list(x) for x in hi]
        for prefix,plan in [('minimum',lo),('maximum',hi)]:
            assert record[prefix+'_legal_cost']==saved[plan][1];close(record[prefix+'_relative_regret'],(saved[plan][1]-go)/go)
    assert ties['legal_exact_float_optima_count']==sum(saved[p][1]==go for p in plans)
    for name,i,v in [('euclidean',0,eo),('legal',1,go)]:
        gap=min(saved[p][i]-v for p in plans if saved[p][i]>v);assert enumer[name+'_next_distinct_float_gap']==gap
        dp=enumer['audited_dp_crosscheck'][name];assert dp['K1_infeasible'] and dp['K2_infeasible']
        dpplan=tuple(tuple(r[1:-1]) for r in dp['solution']['routes'])
        assert all(r[0]==r[-1]==0 for r in dp['solution']['routes']);validplan(dpplan,demands)
        close(costs(dpplan,[sE,sG][i]),dp['solution']['cost']);close(dp['solution']['cost'],v)
        close(abs(dp['solution']['cost']-v),dp['absolute_difference_from_full_enumeration'])
    for solname,plan in [('euclidean_solution',ep),('legal_solution',gp)]:
        sol=result[solname];assert sol['canonical_plan']==[list(r) for r in plan] and sol['vehicle_count']==3 and sol['customer_count']==9 and sol['coverage_exactly_once'] and sol['capacity_valid']
        assert sol['euclidean_cost']==costs(plan,sE) and sol['legal_cost']==costs(plan,sG)
        assert len(sol['routes'])==3;illegal=[];psegments=0
        for rid,(r,route) in enumerate(zip(plan,sol['routes'])):
            stops=(0,)+r+(0,);load=sum(demands[t] for t in r)
            assert route['vehicle']==rid and route['customers']==list(r) and route['stops']==list(stops) and route['load']==load<=9
            assert len(route['legs'])==len(stops)-1;polyline=[services[0]]
            for (a,b),leg in zip(zip(stops,stops[1:]),route['legs']):
                ok=covered[sn[a],sn[b]]
                assert leg['from']==a and leg['to']==b and leg['direct_covered']==ok
                if not ok:illegal.append({'vehicle':rid,'from':a,'to':b})
                path=raw['legal_leg_paths'][a][b]['points'];assert leg['legal_path']==path
                close(leg['euclidean_cost'],E[a][b]);close(leg['legal_cost'],G[a][b])
                ids=[node_lookup[tuple(p)] for p in path];assert all(covered[u,v] for u,v in zip(ids,ids[1:]))
                counts['selected_plan_legs']+=1;counts['selected_plan_path_segments']+=len(ids)-1;psegments+=len(ids)-1
                for x in ids[1:-1]:
                    if x in sn:
                        counts['incidental_service_waypoints']+=1
                        if x==sn[0]:counts['incidental_depot_waypoints']+=1
                polyline+=path[1:]
            assert route['legal_polyline']==polyline
            close(route['legal_polyline_cost'],math.fsum(length(a,b) for a,b in zip(polyline,polyline[1:])))
            close(route['euclidean_cost'],costs((r,),E));close(route['legal_cost'],costs((r,),G));close(route['legal_polyline_cost'],route['legal_cost'])
        assert sol['direct_illegal_legs']==illegal and sol['direct_illegal_leg_count']==len(illegal) and sol['total_service_legs']==12 and sol['path_segments_rechecked']==psegments
    metrics={'euclidean_optimal_cost':eo,'euclidean_plan_legal_cost':eg,'legal_optimal_cost':go,'euclidean_direct_illegal_legs':result['euclidean_solution']['direct_illegal_leg_count'],'total_service_legs':12,'legal_repair_estimation_bias_absolute':eg-eo,'legal_repair_estimation_bias_relative_to_euclidean':(eg-eo)/eo,'reoptimization_saved_absolute':eg-go,'reoptimization_relative_regret_to_legal_optimum':(eg-go)/go,'reoptimization_savings_fraction_of_repaired_euclidean':(eg-go)/eg}
    for k,v in metrics.items():close(result[k],v)
    assign=lambda p:sorted(sorted(r) for r in p)
    assert result['task_assignment_changed']==(assign(ep)!=assign(gp)) and result['canonical_plan_changed']==(ep!=gp)
    if inst['family']=='rect':assert sE==sG and E==G and eo==eg==go and metrics['euclidean_direct_illegal_legs']==0 and ep==gp
    rows.append(dict(instance_id=gid,family=inst['family'],node_count=nv,euclidean_plan=ep,legal_plan=gp,canonical_feasible_plan_count=len(plans),feasible_partitions=part_count,exact_E_optima=ties['euclidean_exact_float_optima']['count'],near_E_optima=ties['euclidean_within_1e_9']['count'],legal_exact_float_optima_count=ties['legal_exact_float_optima_count'],euclidean_next_gap=enumer['euclidean_next_distinct_float_gap'],max_matrix_error=max_matrix_error,task_assignment_changed=result['task_assignment_changed'],**metrics))
    matrices.append(dict(instance_id=gid,euclidean=E,legal_floyd=G,independent_euclidean_min=min(t[0] for t in ind),independent_legal_min=min(t[1] for t in ind)))
    print(json.dumps({'field':gid,'status':'PASS','plans':len(plans),'nodes':nv}),flush=True)
summary=read('reports/SUMMARY.json');assert summary['main_run']==run
metric_names=['legal_repair_estimation_bias_relative_to_euclidean','reoptimization_relative_regret_to_legal_optimum','reoptimization_savings_fraction_of_repaired_euclidean']
def compare_summary(rr,ss):
    for k,v in {'base_fields':len(rr),'fields_with_direct_illegal_legs':sum(x['euclidean_direct_illegal_legs']>0 for x in rr),'direct_illegal_legs_descriptive_only':sum(x['euclidean_direct_illegal_legs'] for x in rr),'total_legs_descriptive_only':sum(x['total_service_legs'] for x in rr),'fields_with_reoptimization_gain_above_1e_9':sum(x['reoptimization_saved_absolute']>1e-9 for x in rr),'fields_with_changed_task_assignment':sum(x['task_assignment_changed'] for x in rr),'exact_float_euclidean_tie_fields':sum(x['exact_E_optima']>1 for x in rr),'near_tie_band_fields':sum(x['near_E_optima']>1 for x in rr)}.items():assert ss[k]==v
    for k in metric_names:
        vv=[x[k] for x in rr]
        for name,fn in [('mean',statistics.mean),('median',statistics.median),('min',min),('max',max)]:close(ss[k][name],fn(vv))
compare_summary(rows,summary['all_12']);conc=[x for x in rows if x['family']!='rect'];compare_summary(conc,summary['concave_9'])
for family in cfg['families']:compare_summary([x for x in rows if x['family']==family],summary['by_family'][family])
with (ROOT/'reports/RESULTS.csv').open() as f:
    resultcsv=list(csv.DictReader(f));assert len(resultcsv)==12
    for row,rr in zip(resultcsv,rows):
        assert row['instance_id']==rr['instance_id'] and row['family']==rr['family'] and row['task_assignment_changed']==str(rr['task_assignment_changed'])
        for k in metric_names+['euclidean_optimal_cost','euclidean_plan_legal_cost','legal_optimal_cost','euclidean_direct_illegal_legs','canonical_feasible_plan_count','exact_E_optima']:close(float(row[k]),rr[k])
        assert int(row['near_E_optima_1e_9'])==rr['near_E_optima']
        close(float(row['near_E_min_legal_regret']),rr['reoptimization_relative_regret_to_legal_optimum']);close(float(row['near_E_max_legal_regret']),rr['reoptimization_relative_regret_to_legal_optimum'])
assert counts['enumerated_plans']==counts['raw_csv_rows']==119016 and counts['selected_plan_legs']==288
assert summary['concave_9']['fields_with_reoptimization_gain_above_1e_9']==2 and summary['concave_9']['direct_illegal_legs_descriptive_only']==25
# Recheck source and archive immutability after all read-only auditing.
for p,h in manifest.items():assert sha(ROOT/p)==h
assert sha(ZIP)=='d311e3fa9a81a89f04978e5d323a516ad02151bf805aebe5549eac9ca02be990'
report={'status':'PASS','defects':[],'audit_method':'No source imported and no experiment solver rerun. Reused independent exact Fraction segment subdivision and rectangle-union clipping, recomputed full visibility graph and Floyd distances; new restricted-growth capacity partition enumeration and route-reversal quotient; complete raw-plan set equality.','package_manifest_files_verified':len(manifest),'pre_generation_hashes_verified':len(pre['sha256']),'pre_run_hashes_verified':len(frozen['sha256']),'archive_sha256':sha(ZIP),'regenerated_input_byte_exact':True,'new_polygons_distinct_from_prior_16':True,'counts':counts,'node_counts_by_family':{f:sorted({r['node_count'] for r in rows if r['family']==f}) for f in cfg['families']},'every_field_counts':{'canonical_plans':9918,'feasible_customer_partitions':303,'capacity_feasible_subsets':147,'canonical_single_routes':753},'all_12':summary['all_12'],'concave_9':summary['concave_9'],'tie_audit':'On frozen binary64 matrices every exact E minimizer and every E<=Emin+1e-9 band has one canonical plan. Primary strict numeric minimum then lexicographic plan confirmed for both objectives; complete legal tie counts and both next gaps verified. Independently recomputed binary64 sqrt/Floyd matrix objectives agree within 1e-9 for every enumerated plan, including global minima.','service_semantics':'Customers are served exactly once according to logical route lists. Incidental geometric passage through service or depot coordinates does not count as service, arrival or a capacity reset. Selected route loads independently recomputed from logical customer IDs.','launch_evidence':{'saved_main_runs':1,'prior_launcher_exit':127,'main_cpu_seconds':run['cpu_seconds'],'main_wall_seconds':run['wall_seconds'],'outer_wall_seconds':launch['outer_wall_seconds'],'outer_child_cpu_seconds':launch['child_user_cpu_seconds']+launch['child_system_cpu_seconds'],'freeze_timestamps_ordered':True,'qualification':'Saved receipts, logs and frozen hashes are mutually consistent with one numerical main pass after a launcher failure before Python. This is local provenance, not tamper-proof proof that no unrecorded execution occurred.'},'limitations':['Synthetic 12-field descriptive comparison; nine concave fields are the units, not 108 legs or individual vehicles.','Only U_02 and U_03 benefit from reoptimization; seven concave fields and all three rectangles have zero benefit. Maximum 21.941939% legal-optimum-relative regret is not typical gain.','Repair bias denominator E(E*); regret denominator G(G*); realizable savings denominator G(E*). Never mix these three quantities.','Exact rational geometry with closed boundaries, point robot and allowed instantaneous turns; no real machine footprint, turn radius, work coverage or field distribution guarantee.','Binary64 square roots, sums and shortest-path comparisons; numeric exhaustive optima are not formally certified irrational/algebraic optima. The 1e-9 value is only objective validation/sensitivity, not geometry relaxation.'],'independently_reused_geometry_source':{'path':'/workspace/shared/audit_field_geometry_routes_20261008/audit.py','sha256':sha(Path('/workspace/shared/audit_field_geometry_routes_20261008/audit.py'))},'resource':{'audit_cpu_seconds':time.process_time()-t0,'audit_wall_seconds':time.perf_counter()-w0,'cpu_cap_seconds':15,'wall_cap_seconds':30,'experiment_solver_reruns':0,'original_source_imports':0,'model_api_calls':0,'new_research_solver_calls':0,'new_installs':0,'purchases':0,'external_paid_actions':0,'monetary_cost':'No external purchase/API action. Assistant tokens and platform CPU charge not exposed; total cost is not asserted zero.'}}
save('AUDIT.json',report);save('FIELD_RESULTS.json',rows);save('INDEPENDENT_MATRICES.json',matrices)
print(json.dumps({'status':'PASS','counts':counts,'cpu_seconds':report['resource']['audit_cpu_seconds'],'wall_seconds':report['resource']['audit_wall_seconds']}),flush=True)
