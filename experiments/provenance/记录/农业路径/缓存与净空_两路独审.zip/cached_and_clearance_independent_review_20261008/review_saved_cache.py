"""Independent read-only review of saved records. No author imports or solver calls."""
from pathlib import Path
import json,hashlib,math,statistics,collections,ast,zipfile,datetime
ROOT=Path('/workspace/shared/capacity_bound_cached_invariants_20261008_technical_r1')
OUT=Path('/workspace/shared/cached_and_clearance_independent_review_20261008')
OLD=Path('/workspace/shared/capacity_bound_cached_invariants_20261008')
SOURCE=Path('/workspace/shared/capacity_cross_structure_reproduction_20261008_r1')
def read(p): return json.loads(Path(p).read_text())
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dg(x): return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def strip(x):
 if isinstance(x,dict): return {k:strip(v) for k,v in x.items() if not any(s in k for s in ['cpu','wall','seconds'])}
 if isinstance(x,list): return [strip(v) for v in x]
 return x
def semantic(r):
 d={k:r.get(k) for k in ['status','output','diagnostic','budget','error','groups']}
 if 'non_time_diagnostic' in r:d['diagnostic']=r['non_time_diagnostic']
 return strip(d)
checks={}; details={}; failures=[]
def check(name,ok,detail=None):
 checks[name]=bool(ok)
 if not ok: failures.append(name)
 if detail is not None: details[name]=detail
before={str(p.relative_to(ROOT)):sha(p) for p in ROOT.rglob('*') if p.is_file()}
for file,key in [('freeze/PRE_RUN_FREEZE.json','sha256'),('freeze/COMPLETE_PREEXEC_WITH_FIXTURE.json','files_sha256'),('PREEXECUTION_SNAPSHOT_SHA256.json',None),('RAW_COMPLETE_UNAUDITED_SHA256.json',None),('REPORT_AND_EVIDENCE_SHA256.json',None)]:
 m=read(ROOT/file);m=m[key] if key else m
 bad=[p for p,h in m.items() if not (ROOT/p).is_file() or sha(ROOT/p)!=h]
 check('hashes:'+file,not bad,{'files':len(m),'mismatches':bad})
oldmap=read(ROOT/'provenance/OLD_FILES_BEFORE.json')
check('old_source_tree_preserved',all((SOURCE/p).is_file() and sha(SOURCE/p)==h for p,h in oldmap.items()),{'files':len(oldmap)})
zip_expected={
 'capacity_bound_cached_invariants_20261008_technical_r1_REPORT_AND_EVIDENCE.zip':'b72ae12199ae38804b06628ac4bb27603ed55e7874f0cd181675b787d84994cd',
 'capacity_bound_cached_invariants_20261008_RAW_COMPLETE_UNAUDITED.zip':'12e29484697a44e75e2b1554b641dfa842519fea02803462b386a32bcee2b2dd',
 'capacity_bound_cached_invariants_20261008_REPORT_AND_EVIDENCE.zip':'9082678ab4f6054f551214c22ac57e4d5fc4a1a63b961936b97924a70fac60e7',
 'capacity_bound_cached_invariants_20261008_PREEXECUTION_SNAPSHOT.zip':'8225864937685d69504b005788791ad861ad8ea45bcc48e60724b01a3a78cf7a'}
for name,h in zip_expected.items():
 p=ROOT.parent/name;bad=[]
 with zipfile.ZipFile(p) as z:
  for n in z.namelist():
   if n.endswith('/'):continue
   q=ROOT.parent/n
   if not q.is_file() or q.read_bytes()!=z.read(n):bad.append(n)
 check('archive:'+name,sha(p)==h and not bad,{'bytes':p.stat().st_size,'sha256':sha(p),'member_mismatches':bad})
for file in ['provenance/PREEXEC_ARCHIVE_VERIFIED.json','provenance/RAW_ARCHIVE_VERIFIED.json']:
 r=read(ROOT/file); p=Path(r['source']); d=Path(r['download_path'])
 check('receipt:'+file,r['verified'] and p.read_bytes()==d.read_bytes() and sha(p)==r['sha256'],{'drive_id':r.get('drive_id',r.get('file_id')),'sha256':sha(p)})
origin=read(ROOT/'provenance/TECHNICAL_STAGE_ORIGIN.json');r=origin['old_raw_archive_receipt']
check('failed_raw_download_byte_identical',Path(r['source']).read_bytes()==Path(r['download_path']).read_bytes())
complete=read(ROOT/'freeze/COMPLETE_PREEXEC_WITH_FIXTURE.json')
with zipfile.ZipFile(ROOT.parent/'capacity_bound_cached_invariants_20261008_technical_r1_PREEXECUTION_WITH_FIXTURE.zip') as z:
 check('additive_fixture_base_preserved',z.read('base_preexec/capacity_bound_cached_invariants_20261008_technical_r1_PREEXECUTION_SNAPSHOT.zip')==(ROOT.parent/'capacity_bound_cached_invariants_20261008_technical_r1_PREEXECUTION_SNAPSHOT.zip').read_bytes())
check('unchanged_candidate_hash',sha(ROOT/'source/solvers/cached_solver.py')==sha(OLD/'source/solvers/cached_solver.py')==origin['candidate_sha256'])
check('same_48_inputs',len(list((ROOT/'input').glob('*.json')))==48 and all(p.read_bytes()==(OLD/'input'/p.name).read_bytes()==(SOURCE/'input'/p.name).read_bytes() for p in (ROOT/'input').glob('*.json')))
check('unchanged_schedule',read(ROOT/'freeze/SCHEDULE.json')==read(OLD/'freeze/SCHEDULE.json'))
mods=[]
for f in ['waste_solver.py','cached_solver.py']:
 tree=ast.parse((ROOT/'source/solvers'/f).read_text());mods.append({n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))})
check('candidate_scoped_ast_changes',set(mods[1])-set(mods[0])=={'suffix_statistics','cached_waste_capacity_test'} and all(v==mods[1][k] for k,v in mods[0].items() if k!='bounded_partition'))
refs={r['instance_id']:r for r in read(ROOT/'provenance/REFERENCE_INITIALIZE.json')}
partrefs={r['instance_id']:r for r in read(ROOT/'provenance/REFERENCE_PARTITION.json')}
inputs={p.stem:read(p) for p in (ROOT/'input').glob('*.json')}
source_rows=[json.loads(l) for l in (SOURCE/'raw/results.jsonl').read_text().splitlines()]
check('references_match_old_results',all(r in source_rows for r in list(refs.values())+list(partrefs.values())))
calls=[json.loads(l) for l in (ROOT/'raw/calls.jsonl').read_text().splitlines()]
parts=[json.loads(l) for l in (ROOT/'raw/partitions.jsonl').read_text().splitlines()]
batches=[json.loads(l) for l in (ROOT/'raw/batches.jsonl').read_text().splitlines()]
schedule=read(ROOT/'freeze/SCHEDULE.json')
expected=[(b['batch_id']+'-'+i+f'-P{rep:02d}',b['phase'],b['round'],b['arm'],i,rep) for b in schedule for i in b['instance_order'] for rep in range(b['repetitions'])]
actual=[tuple(r[k] for k in ['call_id','phase','round','arm','instance_id','repetition']) for r in calls]
check('3936_calls_frozen_order',actual==expected,dict(collections.Counter(r['phase'] for r in calls)))
check('all_call_exact_semantics',all(semantic(r)==semantic(refs[r['instance_id']]) for r in calls))
check('all_saved_signatures_recomputed',all(dg(semantic(r))==r['functional_signature']==r['reference_signature'] and dg(r['output'])==r['output_sha256'] and dg(((r['non_time_diagnostic'] or {}).get('capacity_partition') or {}).get('prune_trace'))==r['prune_trace_sha256'] for r in calls))
check('all_call_input_hashes',all(r['input_unchanged'] and r['input_sha256']==sha(ROOT/'input'/(r['instance_id']+'.json')) for r in calls))
invalid=[];max_cost_residual=0
for r in calls:
 if r['status']!='SUCCESS':
  if r['status']!='INITFAIL' or r['output'] is not None:invalid.append(r['call_id'])
  continue
 raw=inputs[r['instance_id']];routes=r['output']['routes'];seen=[n for route in routes for n in route[1:-1]]
 valid=all(route[0]==route[-1]==0 and len(route)>2 for route in routes) and len(routes)<=raw['K'] and sorted(seen)==list(range(1,len(raw['demands']))) and all(sum(raw['demands'][n] for n in route)<=raw['capacity'] for route in routes)
 cost=sum(math.dist(raw['coordinates'][a],raw['coordinates'][b]) for route in routes for a,b in zip(route,route[1:]))
 delta=abs(cost-r['output']['reported_cost']);max_cost_residual=max(max_cost_residual,delta)
 if not valid or delta>1e-8:invalid.append(r['call_id'])
check('independent_saved_output_feasibility_cost',not invalid,{'success_records':sum(r['status']=='SUCCESS' for r in calls),'initfail_records':sum(r['status']=='INITFAIL' for r in calls),'max_cost_abs_residual':max_cost_residual,'bad_calls':invalid})
check('96_partitions_exact_reference_semantics',len(parts)==96 and all(semantic(r)==semantic(partrefs[r['instance_id']]) and dg(semantic(r))==r['functional_signature']==r['reference_signature'] for r in parts))
check('48_pairs_full_trace_assignment_prune_exact',all(a['instance_id']==b['instance_id'] and all(a[k]==b[k] for k in ['groups','diagnostic','node_trace','entry_calls','uncounted_budget_return_calls']) for a,b in zip(parts[::2],parts[1::2])))
trace_bad=[];totals=collections.defaultdict(collections.Counter)
for r in parts:
 raw=inputs[r['instance_id']];diag=r['diagnostic'];tr=r['node_trace'];order=sorted(range(1,len(raw['demands'])),key=lambda j:(-raw['demands'][j],j));slack=raw['K']*raw['capacity']-sum(raw['demands'])
 if not all(dg(v)==r[k] for k,v in [('node_trace_sha256',tr),('prune_trace_sha256',diag['prune_trace']),('assignment_sha256',r['groups'])]):trace_bad.append('hash:'+r['instance_id'])
 counted=0
 for idx,t in enumerate(tr,1):
  if t['entry_index']!=idx or t['nodes_before']!=counted or t['counted_by_algorithm']!=(counted<256):trace_bad.append('entry:'+r['instance_id'])
  if t['counted_by_algorithm']:counted+=1
  depth=t['depth'];assigned=[n for g in t['groups'] for n in g]
  if sorted(assigned)!=sorted(order[:depth]) or t['residual']!=[raw['capacity']-sum(raw['demands'][n] for n in g) for g in t['groups']] or sum(t['residual'])-sum(raw['demands'][n] for n in order[depth:])!=slack:trace_bad.append('state:'+r['instance_id'])
 for p in diag['prune_trace']:
  t=next((t for t in tr if t['counted_by_algorithm'] and t['nodes_before']+1==p['entered_node']),None)
  if t is None or any(t[k]!=p[k] for k in ['depth','residual','groups']) or p['remaining']!=[raw['demands'][n] for n in order[p['depth']:]]:trace_bad.append('prune:'+r['instance_id'])
 if counted!=diag['nodes'] or len(tr)!=r['entry_calls'] or len(tr)-counted!=r['uncounted_budget_return_calls'] or len(diag['prune_trace'])!=diag['prunes']:trace_bad.append('accounting:'+r['instance_id'])
 totals[r['arm']].update({'entry_calls':len(tr),'counted_nodes':counted,'uncounted_budget_return_calls':len(tr)-counted})
check('full_trace_arithmetic_accounting',not trace_bad,{'totals':dict(totals),'mismatches':trace_bad})
toys=[json.loads(l) for l in (ROOT/'raw/toy_states.jsonl').read_text().splitlines()]
toybad=[]
for idx,t in enumerate(toys,1):
 rem=t['remaining'];res=t['residual'];slack=sum(res)-sum(rem);positive=[d for d in rem if d>0]
 formula=[False,False,0] if not rem else ([True,True,0] if slack<0 else ([False,False,0] if not positive else [sum(r for r in res if 0<r<min(positive))>slack,True,len(res)]))
 sums=[sum(rem[i:]) for i in range(len(rem)+1)];mins=[min((x for x in rem[i:] if x>0),default=None) for i in range(len(rem)+1)]
 if t['state_id']!=idx or t['original']!=t['cached'] or t['cached']!=formula or t['slack']!=slack or t['suffix_sum']!=sums or t['suffix_min_positive']!=mins or t['suffix_has_negative']!=[any(x<0 for x in rem[i:]) for i in range(len(rem)+1)] or (t['cached'][0] and t['feasible_exhaustive']):toybad.append(idx)
expected_states={(tuple(rem),tuple(res)) for k in range(1,4) for res in __import__('itertools').product(range(4),repeat=k) for n in range(4) for rem in __import__('itertools').product(range(4),repeat=n)}
check('7140_toy_saved_arithmetic',len(toys)==7140 and {(tuple(t['remaining']),tuple(t['residual'])) for t in toys}==expected_states and not toybad,{'mismatches':toybad,'note':'Recomputed guard formula/suffix arithmetic; saved exhaustive feasibility labels were not regenerated.'})
neg=read(ROOT/'raw/NEGATIVE_DOMAIN_CHECKS.json');check('6_saved_negative_controls',len(neg)==6 and all(r['outcomes'][0]==r['outcomes'][1] and r['outcomes'][0]['error_type']=='ValueError' for r in neg))
check('12_batches_match_schedule',len(batches)==12 and all(b['batch_id']==s['batch_id'] and b['completed_calls']==b['expected_calls']==len(s['instance_order'])*s['repetitions'] for b,s in zip(batches,schedule)))
check('pretime_gate_passed',read(ROOT/'raw/PRETIMING_FUNCTIONAL_GATE.json')=={'passed':True,'partition_records':96,'errors':[],'timed_calls_before_gate':0,'warmup_calls_before_gate':0})
check('normal_exit',read(ROOT/'raw/FINISHED.json')['returncode']==0 and not read(ROOT/'raw/FINISHED.json')['timeout'] and read(ROOT/'raw/WORKER_FINISHED.json')['complete'])
timing={}
for metric in ['cpu','wall']:
 key='wrapper_inclusive_panel_'+metric+'_ns';arm={a:sum(b[key] for b in batches if b['phase']=='timed' and b['arm']==a) for a in ['waste_solver','cached_solver']}
 rr=[next(b[key] for b in batches if b['round']==r and b['arm']=='cached_solver')/next(b[key] for b in batches if b['round']==r and b['arm']=='waste_solver') for r in range(1,6)]
 timing[metric]={'totals_ns':arm,'cached_over_original':arm['cached_solver']/arm['waste_solver'],'round_ratios':rr,'median_ratio':statistics.median(rr),'faster_rounds':sum(x<1 for x in rr),'slower_rounds':sum(x>1 for x in rr),'min':min(rr),'max':max(rr)}
check('timing_report_recomputed',all(timing[m]['cached_over_original']==read(ROOT/'reports/SUMMARY.json')['timing'][m]['cached_over_original_ratio'] for m in timing))
clock=read(ROOT/'raw/CPU_CLOCK_TICKS.json');brackets=read(ROOT/'raw/CLOCK_BRACKETS.json')
check('zero_current_clock_probe',len(clock)==10000 and len(set(clock))==1 and len(brackets)==1000 and all(x['cpu_ns']==0 for x in brackets))
check('400ms_conservative_batch_floor',all(b['wrapper_inclusive_panel_cpu_ns']>=400_000_000 for b in batches if b['phase']=='timed'))
check('author_directory_not_modified',before=={str(p.relative_to(ROOT)):sha(p) for p in ROOT.rglob('*') if p.is_file()})
report={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_WITH_QUALIFICATIONS' if not failures else 'FAIL','scope':'Only saved JSON/ZIP, independent hashes, AST inspection, arithmetic. No author source imported or executed, no solver/candidate calls.','checks':checks,'details':details,'failures':failures,'timing':timing,'limitations':['Same fixed 48 inputs, no additional independent samples from repeated runs.','No stable speedup: cached slower in 3/5 paired rounds despite ~3% lower aggregate time.','This run short CPU clock probes have no positive increments; 4ms is inherited conservative floor, not newly observed.','README report phrase process_time actual ~4ms must be read with INTERPRETATION.json qualification.','Equivalence proof applies to exact integer demands/residuals; finite test labels are not a proof of all inputs.']}
(OUT/'CACHE_SAVED_RESULTS_REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':report['status'],'checks':len(checks),'failures':failures,'timing':timing},ensure_ascii=False,indent=2))
