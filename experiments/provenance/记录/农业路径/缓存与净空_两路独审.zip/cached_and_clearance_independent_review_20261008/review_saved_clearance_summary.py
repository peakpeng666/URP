"""Cross-review of frozen identities and all saved clearance classifications. No optimizer calls."""
from pathlib import Path
import json,hashlib,zipfile,collections,datetime,math
ROOT=Path('/workspace/shared/ee130_route_clearance_audit_20261008')
PEER=Path('/workspace/shared/ee130_route_clearance_independent_review_20261008')
OUT=Path('/workspace/shared/cached_and_clearance_independent_review_20261008')
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
checks={};details={};failures=[]
def check(name,ok,detail=None):
 checks[name]=bool(ok)
 if not ok:failures.append(name)
 if detail is not None:details[name]=detail
before={str(p.relative_to(ROOT)):sha(p) for d in ['input','freeze','raw'] for p in (ROOT/d).rglob('*') if p.is_file()}
for f in ['freeze/PREEXECUTION_FREEZE.json','evidence/RAW_COMPLETE_UNAUDITED_MANIFEST.json']:
 m=read(ROOT/f)['files'];bad=[p for p,h in m.items() if sha(ROOT/p)!=h]
 check('hashes:'+f,not bad,{'count':len(m),'mismatches':bad})
manifest=read(ROOT/'input/MANIFEST.json');bad=[]
for s in manifest['sources']:
 orig=Path(s['original_path']);p=ROOT/s['copy_path'] if 'copy_path' in s else orig
 if sha(p)!=s['sha256'] or p.stat().st_size!=s['bytes'] or not orig.exists() or sha(orig)!=s['sha256']:bad.append(s.get('copy_path',s['original_path']))
check('40_source_files_unchanged',not bad and len(manifest['sources'])==40,{'mismatches':bad})
check('original_source_archive_hash',sha(Path(manifest['original_archive']))==manifest['archive_sha256'])
for f in ['evidence/PREEXECUTION_DRIVE_RECEIPT.json','evidence/RAW_DRIVE_RECEIPT.json']:
 r=read(ROOT/f);p=Path(r['source']);q=Path(r['download_path'])
 check('receipt:'+f,r['verified'] and p.read_bytes()==q.read_bytes() and sha(p)==r['sha256'],{'drive_id':r.get('drive_id'),'sha256':sha(p),'bytes':p.stat().st_size})
rawzip=ROOT.parent/(ROOT.name+'_RAW_COMPLETE_UNAUDITED.zip');bad=[]
with zipfile.ZipFile(rawzip) as z:
 for n in z.namelist():
  if not n.endswith('/') and z.read(n)!=(ROOT.parent/n).read_bytes():bad.append(n)
check('raw_zip_members_byte_identical',not bad,{'mismatches':bad})
peer=read(PEER/'INDEPENDENT_SAVED_RESULT_AUDIT.json')
check('independent_geometry_source_and_records_bound',peer['status']=='PASS_INDEPENDENT_SAVED_RESULT_AUDIT' and not peer['failures'] and sha(PEER/'review_saved_clearance.py')==peer['review_source_sha256'] and all(sha(ROOT/p)==h for p,h in peer['raw_file_hashes'].items()),{'checks_executed':peer['checks_executed'],'rational_review':peer['rational_review']})
check('peer_geometry_distance_tolerance',max(peer['rational_review'][k] for k in ['maximum_all_pair_rational_vs_geos_abs_difference_m','maximum_saved_minimum_vs_rational_abs_difference_m','maximum_witness_location_or_distance_error_m'])<1e-8)
T=1e-8
# This implementation does not import the author or peer's classifiers.
def classify(record,r):
 if not record['closed_field_covered']:return 'FAIL_OUTSIDE_FIELD'
 d=record['minimum_clearance_m']
 if r==0:return 'PASS'
 if d<r-T:return 'FAIL_CLEARANCE'
 if d>r+T:return 'PASS'
 return 'BORDERLINE_WITHIN_TOLERANCE'
def combine(statuses):return 'FAIL' if any(s.startswith('FAIL') for s in statuses) else ('BORDERLINE' if any(s.startswith('BORDERLINE') for s in statuses) else 'PASS')
raw=read(ROOT/'raw/results.json');conditions=raw['conditions'];sv={r['instance_id']:r['services'] for r in read(ROOT/'raw/services.json')};idx=read(ROOT/'raw/routes_index.json')
check('exact_condition_keys',len(conditions)==96 and len({(c['instance_id'],c['method'],c['radius_m']) for c in conditions})==96 and {c['radius_m'] for c in conditions}=={0.,.5,1.,2.})
condition_bad=[];primitive_bad=[];route_bad=[];ranges=[]
for c in conditions:
 r=c['radius_m'];iid=c['instance_id'];route=read(ROOT/f'raw/{iid}_{c["method"]}_route.json');points=sv[iid];segments=route['segments']
 ss=[classify(p,r) for p in points];sg=[classify(s,r) for s in segments]
 for p,s in zip(points,ss):
  if p['radius_conditions'][str(r)]!=s:primitive_bad.append((iid,'service',p['service_id'],r))
 for p,s in zip(segments,sg):
  if p['radius_conditions'][str(r)]!=s:primitive_bad.append((iid,c['method'],p['segment_index'],r))
 expected={'status':combine(ss+sg),'failing_task_ids':[p['service_id'] for p,s in zip(points,ss) if p['service_id'] and s.startswith('FAIL')],'borderline_task_ids':[p['service_id'] for p,s in zip(points,ss) if p['service_id'] and s.startswith('BORDERLINE')],'depot_status':ss[0],'service_points_status':combine(ss),'connecting_segments_status':combine(sg),'failing_segment_indices':[p['segment_index'] for p,s in zip(segments,sg) if s.startswith('FAIL')],'borderline_segment_indices':[p['segment_index'] for p,s in zip(segments,sg) if s.startswith('BORDERLINE')],'connector_only_failure_all_service_points_pass':all(s=='PASS' for s in ss) and any(s.startswith('FAIL') for s in sg),'failing_leg_indices_with_passing_service_endpoints':sorted({p['service_leg_index'] for p,s in zip(segments,sg) if s.startswith('FAIL') and all(ss[i]=='PASS' for i in p['service_leg'])}),'full_centerline_covered':all(s['closed_field_covered'] for s in segments),'minimum_route_clearance_m':min(s['minimum_clearance_m'] for s in segments),'minimum_service_clearance_m':min(p['minimum_clearance_m'] for p in points)}
 if any(c[k]!=v for k,v in expected.items()):condition_bad.append({'key':[iid,c['method'],r],'mismatches':[k for k,v in expected.items() if c[k]!=v]})
 if route['minimum_clearance_m']!=expected['minimum_route_clearance_m'] or route['closed_field_covered']!=expected['full_centerline_covered']:route_bad.append((iid,c['method']))
 if r>0:ranges.extend(abs(p['minimum_clearance_m']-r) for p in points+segments)
check('96_conditions_rebuilt_from_saved_primitives',not condition_bad,{'mismatches':condition_bad})
check('all_saved_primitive_classifications',not primitive_bad,{'mismatches':primitive_bad})
check('route_global_from_all_segments',not route_bad,{'mismatches':route_bad})
check('no_real_conditions_near_threshold',min(ranges)>T,{'minimum_distance_to_positive_threshold_m':min(ranges)})
by_radius=[]
for r in [0.,.5,1.,2.]:
 cc=[c for c in conditions if c['radius_m']==r]
 row={'radius_m':r,**{k:sum(c['status']==k for c in cc) for k in ['PASS','FAIL','BORDERLINE']},'service_point_failing_routes':sum(c['service_points_status']=='FAIL' for c in cc),'depot_failing_routes':sum(c['depot_status'].startswith('FAIL') for c in cc),'task_failing_routes':sum(bool(c['failing_task_ids']) for c in cc),'connecting_segment_failing_routes':sum(c['connecting_segments_status']=='FAIL' for c in cc),'connector_only_failing_routes':sum(c['connector_only_failure_all_service_points_pass'] for c in cc)}
 by_radius.append(row)
check('reported_radius_summary_recomputed',by_radius==raw['summary']['by_radius']==peer['by_radius'])
check('24_centerlines_21_exact_zero',len(idx)==24 and all(x['closed_field_covered'] for x in idx) and sum(x['minimum_clearance_m']==0 for x in idx)==21)
check('all_depots_pass_up_to_2m',all(classify(v[0],r)=='PASS' for v in sv.values() for r in [0.,.5,1.,2.]),{'depot_minimum_clearances_m':{iid:v[0]['minimum_clearance_m'] for iid,v in sv.items()}})
pre=read(PEER/'PREEXECUTION_INDEPENDENT_REVIEW.json')
check('preexecution_threshold_tests_exist','classification_thresholds' in json.dumps(pre))
report=(ROOT/'reports/REPORT_zh.md').read_text()
check('report_limitations_explicit',all(s in report for s in ['不是已知农机尺寸','不是12个独立地块','测绘真值','没有声称第二种形式化全段包含证明','没有落入','没有自动改路线']))
check('readonly_frozen_inputs_and_raw',before=={str(p.relative_to(ROOT)):sha(p) for d in ['input','freeze','raw'] for p in (ROOT/d).rglob('*') if p.is_file()})
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_WITH_QUALIFICATIONS' if not failures else 'FAIL','scope':'Independent frozen/raw hashes and saved primitive classification/aggregation arithmetic; separately reviewed and bound peer Fraction/GEOS full geometric audit, without repeating it or executing solver.','checks':checks,'details':details,'failures':failures,'by_radius':by_radius,'source_report_sha256':sha(ROOT/'reports/REPORT_zh.md'),'peer_report_sha256':sha(PEER/'INDEPENDENT_SAVED_RESULT_AUDIT.json'),'peer_source_sha256':sha(PEER/'review_saved_clearance.py'),'limitations':peer['limitations']}
(OUT/'CLEARANCE_CROSS_REVIEW.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':result['status'],'checks':len(checks),'failures':failures,'by_radius':by_radius},ensure_ascii=False,indent=2))
