#!/usr/bin/python3
"""Independent read-only audit. Does not import or execute supplied experiment scripts."""
import pathlib,json,hashlib,csv,collections,math,zipfile,re,resource,signal,time
from osgeo import ogr,gdal
resource.setrlimit(resource.RLIMIT_CPU,(29,30)); signal.alarm(59)
t0=time.process_time(); w0=time.monotonic()
O=pathlib.Path(__file__).resolve().parent
A=pathlib.Path('/workspace/shared/cvrp_static_neighborhood_diagnostic_20261008'); B=pathlib.Path('/workspace/shared/real_field_geometry_preparation_20261008')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p): return json.loads(p.read_text())
before={str(p):sha(p) for d in [A,B] for p in d.rglob('*') if p.is_file()}
for line in (A/'SHA256SUMS.txt').read_text().splitlines():
 h,n=line.split(); assert sha(A/n)==h
for n,h in read(B/'SHA256SUMS.json').items(): assert sha(B/n)==h
for n,h in read(A/'INPUT_SHA256.json').items(): assert sha(pathlib.Path(n))==h
T=read(A/'TRAJECTORY_CHECKS.json'); assert len(T)==120
cache={}; original={}; seen={}; stats={}; info={}; checks=0
for t in T:
 tid=t['trajectory']; root,idx=tid.split(':'); base=pathlib.Path('/workspace/shared')/root
 if root not in original: original[root]=[json.loads(l) for l in (base/'raw/heuristics.jsonl').read_text().splitlines()]
 r=original[root][int(idx)]; assert r['output']==t['original']; assert r['search_seed']==t['seed']; assert r['instance_id']==t['instance']; assert r['method']==t['method']; assert r.get('acceptance_mode','strict')==t['mode']
 k=(root,t['instance'])
 if k not in cache:
  x=read(base/'input'/(t['instance']+'.json')); co=x['coordinates']; m=[[int(math.floor(math.hypot(a[0]-b[0],a[1]-b[1])+0.5)) for b in co] for a in co]; cache[k]=(x,m)
 x,m=cache[k]; rs=[z[1:-1] for z in t['original']['routes']]
 assert all(z[0]==z[-1]==0 for z in t['original']['routes'])
 def validate(routes,x=x,m=m):
  nodes=[v for route in routes for v in route]; loads=[sum(x['demands'][v] for v in route) for route in routes]
  assert sorted(nodes)==list(range(1,len(x['demands']))); assert max(loads)<=x['capacity']; assert sum(bool(z) for z in routes)<=x['K']
  cost=sum(m[u][v] for route in routes if route for u,v in zip([0]+route,route+[0])); return cost,loads
 cost,loads=validate(rs); assert cost==t['original']['reported_cost']==t['original_check']['cost']; assert loads==t['original_check']['loads']
 info[tid]=(t,rs,x,m,cost,loads,validate)
 n=sum(map(len,rs)); L=len(rs)+(len(rs)<x['K'])
 expected={'relocate':n*(n+L-2),'swap':n*(n-1)//2,'2opt':sum(len(z)*(len(z)-1)//2-(len(z)>1) for z in rs)}
 for op in expected:
  seen[tid,op]=set(); stats[tid,op]=collections.Counter(considered=0,capacity_rejected=0,evaluated_deltas=0,negative_deltas=0,best_delta=0)
  assert expected[op]==t['neighbors'][op]['considered']
for row in csv.DictReader((A/'ALL_DELTAS.csv').open()):
 tid,op=row['trajectory'],row['operator']; t,rs,x,m,cost,loads,validate=info[tid]
 a,i,b,j=[int(row[k]) for k in ['route_a','position_a','route_b','position_b']]; move=(a,i,b,j); key=(tid,op); assert move not in seen[key]; seen[key].add(move)
 can=[z[:] for z in rs]; assert 0<=a<len(rs) and 0<=i<len(rs[a])
 if op=='relocate':
  u=can[a].pop(i)
  if len(rs)<x['K']: can.append([])
  assert 0<=b<len(can) and 0<=j<=len(can[b]); assert a!=b or i!=j; can[b].insert(j,u)
 elif op=='swap':
  assert 0<=b<len(rs) and 0<=j<len(rs[b]); assert (a,i)<(b,j); can[a][i],can[b][j]=can[b][j],can[a][i]
 else:
  assert op=='2opt' and b==a and i<j<len(rs[a]); assert not (i==0 and j==len(rs[a])-1); can[a][i:j+1]=reversed(can[a][i:j+1])
 feasible=all(sum(x['demands'][v] for v in z)<=x['capacity'] for z in can)
 assert (row['feasible']=='True')==feasible; st=stats[key]; st['considered']+=1
 if feasible:
  new,_=validate(can); checks+=1; delta=new-cost; assert delta==int(row['delta'])==int(row['full_cost_delta']); st['evaluated_deltas']+=1; st['negative_deltas']+=delta<0; st['best_delta']=min(st['best_delta'],delta)
 else:
  assert row['delta']==row['full_cost_delta']==''; st['capacity_rejected']+=1
for (tid,op),st in stats.items():
 t,rs,x,m,cost,loads,validate=info[tid]; saved=t['neighbors'][op]
 for key,val in st.items(): assert saved[key]==val,(tid,op,key)
 bw=saved['best_witness']
 if bw:
  nc,nl=validate([z[1:-1] for z in bw['routes']]); assert nc-cost==st['best_delta']; assert nc==bw['check']['cost']; assert nl==[v for v in bw['check']['loads'] if v!=0] or nl==bw['check']['loads']
summary=read(A/'SUMMARY.json'); groups={}
for (tid,op),st in stats.items():
 t=info[tid][0]; key='|'.join([tid.split(':')[0],t['method'],t['mode'],op]); g=groups.setdefault(key,collections.Counter()); g['trajectories']+=1; g['with_improvement']+=st['best_delta']<0;g['sum_best_delta']+=st['best_delta'];g.update({k:v for k,v in st.items() if k!='best_delta'})
assert groups==summary['groups']; total=sum(s['considered'] for s in stats.values()); assert total==275715 and checks==112255
rr=[t for t in T if t['method']=='regret2']; assert all(t['neighbors'][op]['best_delta']==0 for t in rr for op in ['relocate','2opt'])
strict=[t for t in rr if t['mode']=='strict' and 'neutral_validation' in t['trajectory']]; good=[t for t in strict if t['neighbors']['swap']['best_delta']<0]; assert len(strict)==24 and len(good)==1
w=good[0]; assert w['instance']=='P-n50-k10' and w['original_check']['cost']==753 and w['neighbors']['swap']['best_witness']['check']['cost']==749
seeds=sorted({t['seed'] for t in T if 'neutral_validation' in t['trajectory']}); proposed=sorted(set(map(int,re.findall(r'2026100863\d\d',(A/'PROPOSED_PREREGISTRATION_ZH.txt').read_text()))))
assert seeds==[202610085201,202610085203,202610085207,202610085209]
manifest=read(B/'INPUT_MANIFEST.json'); archive=pathlib.Path(manifest['archive_local_path']); data=archive.read_bytes(); assert hashlib.sha256(data).hexdigest()==manifest['archive_sha256']; assert hashlib.md5(data).hexdigest()==manifest['archive_md5']; assert sha(B/'SELECTION_RULE_FROZEN.json')==manifest['rule_sha256']
z=zipfile.ZipFile(archive); wkt=[n for n in z.namelist() if n.endswith('.wkt')]; nl=sorted([n for n in wkt if re.fullmatch(r'wkt/nl_field_\d+\.wkt',n)],key=lambda n:int(re.search(r'(\d+)\.wkt$',n)[1])); assert len(wkt)==350 and len(nl)==140
inv=[{'member':n,'bytes':len(z.read(n)),'sha256':hashlib.sha256(z.read(n)).hexdigest()} for n in nl]; assert inv==read(B/'universe_inventory.json')
selected=[]; geo=[]
for n in nl:
 raw=z.read(n); g=ogr.CreateGeometryFromWkt(raw.decode()); valid=g is not None and not g.IsEmpty() and g.GetCoordinateDimension()==2 and g.GetGeometryName()=='POLYGON' and g.IsValid()
 if valid:
  ar=g.GetArea(); hull=g.ConvexHull().GetArea(); ratio=(hull-ar)/hull
  if ar>0 and ratio>1e-6:
   saved=manifest['selected'][len(selected)]; assert saved['member']==n and (B/saved['local_file']).read_bytes()==raw; assert saved['source_crs'] is None and saved['metric_ready'] is False; assert math.isclose(saved['source_coordinate_area'],ar,rel_tol=1e-12) and math.isclose(saved['convex_hull_deficit_ratio'],ratio,rel_tol=1e-12)
   selected.append(n); geo.append({'member':n,'valid':True,'concavity_ratio':ratio,'raw_bytes_preserved':True})
 if len(selected)==6: break
assert selected==['wkt/nl_field_'+str(i)+'.wkt' for i in [1,2,7,8,10,11]]
assert manifest['transforms']==manifest['repair_operations']==[] and manifest['solver_runs']==0 and manifest['status']=='RAW_GEOMETRY_FROZEN_METRIC_INGESTION_BLOCKED'
assert [r['member'] for r in read(B/'selection_audit.json')]==selected
for r in manifest['source_documents']: assert sha(B/r['file'])==r['sha256']
after={str(p):sha(p) for d in [A,B] for p in d.rglob('*') if p.is_file()}; assert before==after
receipt={'A':{'status':'PASS_WITH_DOCUMENTATION_DISCREPANCY','originals':120,'candidate_rows':total,'feasible_neighbors_full_cost_and_legality_recomputed':checks,'groups_match':True,'rr2_relocate_2opt_strict_descent':0,'new_six_strict_swap_improvement_trajectories':'1/24','witness_instance':w['instance'],'witness_seed':w['seed'],'witness_old_new_cost':[753,749],'actual_seeds':seeds,'proposal_seeds':proposed,'issue':'Historical proposal 630x differs from actual 520x; preserve historical proposal, downstream original 520x freeze required.'},'B':{'status':'PASS_RAW_ONLY_METRIC_BLOCKED','archive_sha256':manifest['archive_sha256'],'archive_md5':manifest['archive_md5'],'archive_bytes':len(data),'all_wkt_members':len(wkt),'NL_wkt_members':len(nl),'selected':geo,'OGR_module':ogr.__file__,'GDAL_version':gdal.VersionInfo(),'crs_proven':False,'metric_solver_blocked':True,'silent_repair_evidence':'Raw WKT byte-identical to archive; original preparation source reviewed, no repair or projection call.'},'original_directory_hashes_unchanged':True,'input_hashes':before,'solver_executed':False,'network_used':False,'limits':{'CPU_seconds':30,'wall_seconds':60},'elapsed_cpu_seconds':time.process_time()-t0,'elapsed_wall_seconds':time.monotonic()-w0}
(O/'RECEIPT.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n'); print(json.dumps({k:v for k,v in receipt.items() if k!='input_hashes'},ensure_ascii=False,indent=2))
