"""Read existing numeric records and hashes only. No solver, model or network calls."""
import json, hashlib, statistics, argparse
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--source-root',type=Path,default=Path('/workspace/shared'));p.add_argument('--package-root',type=Path,default=Path(__file__).resolve().parent);a=p.parse_args()
registry=json.loads((a.package_root/'来源校验清单.json').read_text());errors=[]
for e in registry['source_files']:
 f=a.source_root/e['path']
 if not f.is_file():errors.append([e['path'],'missing']);continue
 if hashlib.sha256(f.read_bytes()).hexdigest()!=e['sha256']:errors.append([e['path'],'hash mismatch'])
b=a.source_root
rr=[json.loads(l) for l in (b/'vrp_time_windows_20261007/routes.jsonl').read_text().splitlines()]
assert [sum(r['audit']['full_service_feasible'] for r in rr if r['method']==m) for m in ['distance_first','time_window_first']]==[27,31]
rr=json.loads((b/'public_vrptw_benchmark_20261007/reports/evaluated_results.json').read_text());pairs={}
for r in rr:pairs.setdefault(r['instance'],{})[r['budget_ms']]=r['original_distance']
d=[v[1000]-v[250] for v in pairs.values()]
assert [sum(x<-1e-7 for x in d),sum(abs(x)<=1e-7 for x in d),sum(x>1e-7 for x in d)]==[36,20,0]
p2=json.loads((b/'p2_public_scoring_38_43_independent_review_20261007.json').read_text());assert p2['cumulative_counts']=={'admission_rejected':5,'generation_failure':7,'scored':31}
assert not errors,errors
print(json.dumps({'status':'PASS','source_files':len(registry['source_files']),'scope':'source hashes and existing numeric aggregates; no solver/candidate/API/heldout access'},ensure_ascii=False))
