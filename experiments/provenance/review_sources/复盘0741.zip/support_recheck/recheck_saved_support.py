"""Exact arithmetic audit of saved classification; no route/partition optimizer."""
import argparse,collections,datetime,hashlib,io,json,pathlib,statistics,zipfile
from fractions import Fraction as F
p=argparse.ArgumentParser();p.add_argument('--source-root',type=pathlib.Path,required=True);p.add_argument('--out',type=pathlib.Path,required=True);p.add_argument('--parent-members',type=pathlib.Path);p.add_argument('--skip-full-freeze',action='store_true');a=p.parse_args();B=a.source_root;seen={};members={}
def H(b):return hashlib.sha256(b).hexdigest()
def R(rel):
 q=pathlib.Path(rel);q=q.relative_to('/workspace/shared/route_supported_frontier_20261009')if q.is_absolute()else q;b=(B/q).read_bytes();seen[str(q)]={'bytes':len(b),'sha256':H(b)};return b
def J(rel):return json.loads(R(rel))
def C(ok,m):
 if not ok:raise ValueError(m)
def frac(v):return F(v['numerator'],v['denominator'])
proto=J('freeze/PROTOCOL.json');frozen=J('freeze/FROZEN_FILES.json');ids=J('input/PARENT_MEMBER_IDENTITIES.json');sm=J('reports/SUMMARY.json')
if not a.skip_full_freeze:
 for rel,x in frozen['files'].items():
  b=(B/rel).read_bytes();C(len(b)==x['bytes']and H(b)==x['sha256'],'frozen file '+rel)
if not a.parent_members:
 b=R('input/PARENT_FINAL.zip');C(H(b)==ids['sha256'],'parent archive hash');z=zipfile.ZipFile(io.BytesIO(b))
def ancestor(rel):
 b=(a.parent_members/rel).read_bytes()if a.parent_members else z.read(rel);members[rel]={'bytes':len(b),'sha256':H(b)};return b
led=[]
for rel in ['raw/results.jsonl','independent_supervision/raw/results.jsonl']:
 rows=[json.loads(q)for q in R(rel).splitlines()];C(len(rows)==12,'12 slots');C(len({q['schedule']['instance_id']for q in rows})==12,'unique12')
 for r in rows:
  C(r['returncode']==0 and r['process_spawned']and r['child_reaped'],'process');C(r['finished_utc']<'2026-10-09T07:41:00','cutoff');C(H(R(r['stdout']))==r['stdout_sha256']and H(R(r['stderr']))==r['stderr_sha256'],'stdoutstderr hash')
 led.append({r['schedule']['instance_id']:r for r in rows})
counts=collections.Counter();fields=[];budget=[];constraints=0;pairwitness=0
for name in proto['fields']:
 main=J(led[0][name]['stdout']);ind=J(led[1][name]['stdout']);identity=main['input_identity'];ab=ancestor(identity['member']);C(len(ab)==identity['bytes']and H(ab)==identity['sha256'],'parent member identity');old=json.loads(ab);front=old['frontier'];C(len(front)==len(main['points'])==len(ind['points']),'fieldcount');supported=[];rows=[]
 for i,q in enumerate(front):
  si,mi=q['sum_G_mm'],q['max_route_G_mm'];lo,hi=F(0),F(1)
  for j,t in enumerate(front):
   if i==j:continue
   sj,mj=t['sum_G_mm'],t['max_route_G_mm'];aa=(si-mi)-(sj-mj);bb=mj-mi;constraints+=1
   if aa>0:hi=min(hi,F(bb,aa))
   elif aa<0:lo=max(lo,F(bb,aa))
   else:C(bb>=0,'constant dominated point')
  typ='UNSUPPORTED'if lo>hi else 'SUPPORTED_TIE_ONLY'if lo==hi else 'SUPPORTED_INTERVAL';v=main['points'][i];w=ind['points'][i]
  C(v['classification']==w['classification']==typ,'classification');C(frac(v['lower_bound'])==lo and frac(v['upper_bound'])==hi,'rational interval')
  C(v['sum_G_mm']==w['sum_G_mm']==si and v['max_route_G_mm']==w['max_route_G_mm']==mi,'saved values');C(v['inherited_witness']==w['inherited_witness'],'inherited witness crosscheck')
  C(all(v['inherited_witness'][k]==q[k]for k in ['partition','routes','group_masks','route_G_mm','assignment_multiplicity_unlabeled']),'parent witness')
  if typ!='UNSUPPORTED':
   C(frac(w['lower_bound'])==lo and frac(w['upper_bound'])==hi,'independent support interval');supported.append(i)
   for lam in [lo,hi,(lo+hi)/2]:
    C(all(lam*si+(1-lam)*mi<=lam*t['sum_G_mm']+(1-lam)*t['max_route_G_mm']for t in front),'supported endpoint midpoint inequality');pairwitness+=len(front)
  else:
   l,r=w['enclosing_hull_indices'];left,right=front[l],front[r];cross=(right['sum_G_mm']-left['sum_G_mm'])*(mi-left['max_route_G_mm'])-(right['max_route_G_mm']-left['max_route_G_mm'])*(si-left['sum_G_mm']);C(cross>0 and cross==w['positive_cross_product'],'independent unsupported hull witness')
  counts[typ]+=1;rows.append({'index':i,'sumG':si,'maxG':mi,'classification':typ,'lower':str(lo),'upper':str(hi)})
 C(supported==ind['supported_indices'],'supported indices')
 qby={q['p']:q for q in main['queries']};iby={q['p']:q for q in ind['queries']};fcount=collections.Counter(q['classification']for q in rows)
 C(dict(fcount)=={k:v for k,v in main['class_counts'].items()if v},'field counts')
 for p in(0,1,2,5,10,20):
  threshold=front[0]['sum_G_mm']*(100+p)//100;key=lambda i:(front[i]['max_route_G_mm'],front[i]['sum_G_mm'],front[i]['partition']);allidx=min((i for i,q in enumerate(front)if q['sum_G_mm']<=threshold),key=key);sidx=min((i for i in supported if front[i]['sum_G_mm']<=threshold),key=key);loss=front[sidx]['max_route_G_mm']-front[allidx]['max_route_G_mm'];q=qby[p];C({k:v for k,v in q.items()if k!='meaning'}==iby[p],'mainind scientific budget outputs');C((q['source_front_index'],q['ideal_support_front_index'],q['budget_total_G_mm'],q['ideal_complete_support_set_loss_G_mm'])==(allidx,sidx,threshold,loss),'budget loss');C(q['source_classification']==rows[allidx]['classification'],'budgetclass');budget.append({'instance_id':name,'p':p,'threshold_mm':threshold,'source_index':allidx,'supported_index':sidx,'source_class':rows[allidx]['classification'],'loss_mm':loss})
 fields.append({'instance_id':name,'counts':dict(fcount),'points':rows})
by=[]
for p in(0,1,2,5,10,20):
 ar=[q for q in budget if q['p']==p];loss=[q['loss_mm']for q in ar];by.append({'p':p,'denominator':12,'positive_fields':sum(v>0 for v in loss),'mean_loss_mm':statistics.mean(loss),'median_loss_mm':statistics.median(loss),'max_loss_mm':max(loss)})
C(counts=={'UNSUPPORTED':43,'SUPPORTED_INTERVAL':42},'43/42/0');C(sum(q['source_class']=='UNSUPPORTED'for q in budget)==18,'18 selected unsupported');C([q['positive_fields']for q in by]==[0,1,3,4,8,2],'budget positive counts')
res={'status':'PASS_SAVED_SUPPORT_RECHECK','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'result_cutoff_utc':'2026-10-09T07:41:00Z','new_route_optimization_calls':0,'new_native_calls':0,'full_freeze_verified':not a.skip_full_freeze,'frozen_member_count':len(frozen['files']),'parent_archive_hash_verified':not bool(a.parent_members),'parent_member_hashes_verified':True,'directed_exact_rational_constraints':constraints,'supported_lambda_pairwise_checks':pairwitness,'class_counts':dict(counts),'tie_only_count':0,'unsupported_budget_selections':18,'fields':fields,'budget_rows':budget,'by_budget':by,'source_files_read':seen,'parent_members_read':members,'limitations':['Exact classification only for supplied frozen integer value frontier','Inherited frontier completeness/route/G geometry not re-proved','Ideal complete supported-set loss is not observed algorithm performance','No new weighted-sum search or route optimization']}
a.out.write_text(json.dumps(res,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:res[k]for k in['status','frozen_member_count','directed_exact_rational_constraints','class_counts','unsupported_budget_selections','by_budget']},ensure_ascii=False))
