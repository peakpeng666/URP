import datetime,hashlib,json,pathlib,zipfile
B=pathlib.Path(__file__).resolve().parent;S=B.parent;now=datetime.datetime.now(datetime.timezone.utc).isoformat()
def J(p):return json.loads(p.read_text())
def H(b):return hashlib.sha256(b).hexdigest()
def put(n,d):(B/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def ident(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':H(b)}
s=J(B/'support_recheck/SAVED_SUPPORT_RECHECK.json');sp=J(B/'support_recheck/PORTABLE_SUPPORT_RECHECK.json');p=J(B/'priority_recheck/SAVED_PRIORITY_RECHECK.json');pp=J(B/'priority_recheck/PORTABLE_PRIORITY_RECHECK.json')
for k in ['fields','budget_rows','by_budget','class_counts','directed_exact_rational_constraints','parent_members_read']:assert s[k]==sp[k]
for k in ['rows','pairs','arms','pair_stats','E_search_G_deterioration','source_files_read']:assert p[k]==pp[k]
assert s['status']==sp['status']=='PASS_SAVED_SUPPORT_RECHECK'and p['status']==pp['status']=='PASS_SAVED_PRIORITY_RECHECK'
sources=J(B/'SELECTED_SOURCE_MANIFEST.json')
for rel,x in sources['files'].items():
 b=(B/'evidence'/rel).read_bytes();assert len(b)==x['bytes']and H(b)==x['sha256']and b==(S/rel).read_bytes()
for rel,x in sources['extracted_original_members'].items():
 b=(B/'evidence'/rel).read_bytes();assert len(b)==x['bytes']and H(b)==x['sha256']
protected=J(B/'SOURCE_PRESERVATION.json')['protected_deliverables']
for x in protected:
 b=pathlib.Path(x['path']).read_bytes();assert len(b)==x['bytes']and H(b)==x['sha256']
close=J(B/'evidence/current_experiment_supervision_20261009/FIXED_PRIORITY_FINAL_CLOSEOUT.json');assert close['status']=='PASS_FINAL_PRIVATE_DELIVERY_CLOSED'
put('增补更新条目.json',{'result_cutoff_utc':'2026-10-09T07:41:00Z','review_prepared_utc':now,'previous_cutoff_utc':'2026-10-09T07:06:00Z','stage_records_153_are_not_independent_experiments':True,'independent_field_addition':0,'updates':[
 {'source':'route_supported_frontier_20261009','changed_conclusion':'Fixed frontier support gap resolved:43of85 efficient value points unsupported; ideal complete supported set cannot reproduce18of72budget choices.','classification':s['class_counts'],'tie_only':0,'budget_stats_all12':s['by_budget'],'review_depth':{'rational_constraints':608,'point_classifications':85,'budget_choices':72},'remaining_limits':s['limitations']},
 {'source':'mature_field_capacity_priority_control_20261009','changed_conclusion':'Preselected input-derived fixedP has72/72valid and72own-exact in existing panel, versus historicalA60/72valid55/72own-exact. Prior failures remain in historical record.','arms':p['arms'],'pair_stats':p['pair_stats'],'E_search_G_deterioration':p['E_search_G_deterioration'],'full72paired_mean_cost_delta':None,'review_depth':{'raw_route_outputs':144,'native_matrix_entries':24336,'P_callback_rows':18000,'probe_scalars':216000,'toy_calls':2},'remaining_limits':p['limitations']}], 'report_gate_failure':'FirstP reader gate lacked explicit prediction wording; R2 same checker PASS, no solver/native repeat','delivery_resumption_record':'DELIVERY_STAGE_TIMELINE.json','pending_not_results':['Unseen-field source preparation and future task generation']})
(B/'README.txt').write_text('URP历史复盘07:41短增补，可复查小证据包\n\n结果截止2026-10-09 07:41 UTC。P交付晚于截止，取消、恢复确认、实际回读和独立闭环时间见DELIVERY_STAGE_TIMELINE.json，不能当新增科学运行。\n正文：URP历史复盘短增补_截至20261009T0741Z.txt\n结构化增量：增补更新条目.json\n支持性复核：support_recheck/SAVED_SUPPORT_RECHECK.json\n固定P复核：priority_recheck/SAVED_PRIORITY_RECHECK.json\n来源私有已回读身份：SOURCE_FINAL_IDENTITIES.json\n旧六版17交付件保护：SOURCE_PRESERVATION.json\n\n包内324份选择原文件和12份从冻结父ZIP直接读取的原成员。后12份为原始frontier stdout逐字节拷贝，不是重新生成结果；身份和父ZIPhash见SELECTED_SOURCE_MANIFEST.json。为保持小包，没有重复带入支持性23.7MB父全包。P保留Q5精确参照ZIP及历史A72原stdout。\n\n可搬移只读复核命令（从解压根目录执行）：\npython support_recheck/recheck_saved_support.py --source-root evidence/route_supported_frontier_20261009 --parent-members evidence/route_supported_frontier_20261009/input_saved_parent_members --skip-full-freeze --out support_replay.json\npython priority_recheck/recheck_saved_priority.py --source-root evidence/mature_field_capacity_priority_control_20261009 --skip-full-freeze --skip-history-archive --out priority_replay.json\n\n仅需Python标准库，无网络、solver、native构造、几何、任务采样或路线搜索。源全冻结162/479项hash与P历史A72在父档成员里的身份已在原源复核；小包命令显式跳过完整原目录和整父档校验，但仍校所供原文件/成员hash及全部科学计算。科学字段应与两份PORTABLE_*_RECHECK.json相同，路径和时间允许改变。\n\n本包继承原前沿、局部TSP和几何已审前提；独立复算支持性有理约束及预算限制损失，不冒充重证完整路线优化。P检查保存矩阵/路线/参数/公开观测与144行对照；原随机4/4/4和内部算子论证依赖保存源码审核，不冒充直接观测。\n\n原P报告第一次文字验收失败、R2修改与通过、FINAL取消后恢复均保留。support_recheck/reviewer_development记录本复盘检查器对主侧说明文字字段的比较纠正，未改变任何原实验，也不是新求解。\n\n本增补没有新增原田块实验或扩展面板，不改旧版本/索引，不重扫335ZIP。待root审阅后仅由既定唯一归档员进行私有归档和实际回读。\n')
put('QA_FINAL.json',{'status':'READY_FOR_ROOT_REVIEW','prepared_utc':now,'cutoff_utc':'2026-10-09T07:41:00Z','all_scientific_fields_equal_portable_replay':True,'selected_original_files':sources['copied_count'],'selected_extracted_original_members':sources['extracted_count'],'frozen_source_member_counts':[162,479],'prior_protected_artifacts':len(protected),'prior_six_versions_unchanged':True,'P_private_FINAL_independent_closeout_verified':True,'P_cancellation_and_resumption_preserved':True,'P_first_editorial_gate_failure_preserved':True,'historical_A_failures_preserved':12,'paired_fullpanel_cost_delta':None,'new_solver_calls':0,'new_native_reconstructions':0,'new_geometry_calls':0,'new_remote_downloads':0,'uploads':0})
manifest={}
for q in sorted(B.rglob('*')):
 if q.is_file()and q.name!='PACKAGE_MANIFEST.json':
  x=ident(q);manifest[str(q.relative_to(B))]={'bytes':x['bytes'],'sha256':x['sha256']}
put('PACKAGE_MANIFEST.json',{'utc':now,'files':manifest})
zp=S/'URP历史复盘短增补_截至20261009T0741Z_小证据包.zip'
with zipfile.ZipFile(zp,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for q in sorted(B.rglob('*')):
  if q.is_file():z.write(q,str(q.relative_to(B)))
with zipfile.ZipFile(zp)as z:
 assert z.testzip()is None and len(z.namelist())==len(manifest)+1
 for rel,x in manifest.items():
  b=z.read(rel);assert len(b)==x['bytes']and H(b)==x['sha256']
receipt={'status':'READY_FOR_ROOT_REVIEW_NOT_UPLOADED','result_cutoff_utc':'2026-10-09T07:41:00Z','prepared_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'report':ident(B/'URP历史复盘短增补_截至20261009T0741Z.txt'),'evidence_zip':{**ident(zp),'members':len(manifest)+1,'manifest_items':len(manifest),'CRC_and_all_manifest_hashes_pass':True},'prior_six_versions_preserved':True,'archive_owner':'archive_morning_research_results','root_review_required':True}
(S/'URP历史复盘短增补_截至20261009T0741Z_交付回执.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');print(json.dumps(receipt,ensure_ascii=False,indent=2))
