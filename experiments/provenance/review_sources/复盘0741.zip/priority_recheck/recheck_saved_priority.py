"""Saved fixed-P and historical A evidence only; no solver/native imports."""
import argparse,collections,datetime,hashlib,io,json,pathlib,statistics,zipfile
p=argparse.ArgumentParser();p.add_argument('--source-root',type=pathlib.Path,required=True);p.add_argument('--out',type=pathlib.Path,required=True);p.add_argument('--skip-full-freeze',action='store_true');p.add_argument('--skip-history-archive',action='store_true');a=p.parse_args();B=a.source_root;seen={}
def H(b):return hashlib.sha256(b).hexdigest()
def R(rel):
 b=(B/rel).read_bytes();seen[str(rel)]={'bytes':len(b),'sha256':H(b)};return b
def J(rel):return json.loads(R(rel))
def JL(rel):return [json.loads(q)for q in R(rel).splitlines()]
def C(x,m):
 if not x:raise ValueError(m)
proto=J('freeze/PROTOCOL.json');frozen=J('freeze/FROZEN_FILES.json');finished=J('raw/FINISHED.json');C(finished['utc']<'2026-10-09T07:41:00','cutoff');sm=J('reports/SUMMARY.json');schedule=J('freeze/SCHEDULE.json')
if not a.skip_full_freeze:
 for rel,x in frozen['files'].items():
  b=(B/rel).read_bytes();C(len(b)==x['bytes']and H(b)==x['sha256'],'frozen changed '+rel)
zbytes=R('input/Q5_FINAL.zip');C(H(zbytes)==proto['input']['sha256'],'Q5 reference hash');z=zipfile.ZipFile(io.BytesIO(zbytes));inputs={};refs={}
for name in proto['fields']:
 x=J('input/'+name+'.json');inputs[name]=x;eg=json.loads(z.read('raw/calls/'+name+'_E_G.stdout'));ge=json.loads(z.read('raw/calls/'+name+'_G_E.stdout'));C(x['matrices']==ge['input_matrices'],'frozen matrices');refs[name]={'E':eg['E'],'G':ge['G']}
hist=J('historical_reference/CONTROL_A72_ARCHIVE_IDENTITY.json');hr=J('historical_reference/DEFAULT_A72_REVIEWED_ROWS.json');C(len(hr)==len(hist['members'])==72,'historical72');hby={x['call_id']:x for x in hr}
if not a.skip_history_archive:
 b=pathlib.Path(hist['source_archive']).read_bytes();C(H(b)==hist['archive_sha256'],'source historical archive');hz=zipfile.ZipFile(io.BytesIO(b))
new=JL('raw/results.jsonl');C(len(new)==len(schedule)==72 and {r['call_id']for r in new}=={r['call_id']for r in schedule},'new72 full');C(len({r['call_id']for r in new})==72,'no duplicates');alljobs=[]
for r in new:
 C(r['returncode']==0 and r['process_spawned']and r['child_reaped'],'new process');C(H(R(r['stdout']))==r['stdout_sha256']and H(R(r['stderr']))==r['stderr_sha256'],'new rawhash');alljobs.append((r['schedule'],J(r['stdout'])))
for r in hist['members']:
 b=R(r['frozen_stdout']);C(len(b)==r['bytes']and H(b)==r['sha256'],'frozen historical raw')
 if not a.skip_history_archive:C(b==hz.read(r['archive_member']),'archive historical member byte match')
 alljobs.append((hby[r['call_id']],json.loads(b)))
rows=[];outputs={};probe_rows=0;statskeys={'current_cost','candidate_cost','best_cost','current_feas','candidate_feas','best_feas'}
for s,o in alljobs:
 name,proxy,arm=s['instance_id'],s['proxy'],s['arm'];x=inputs[name];mat=x['matrices'];C(o['model_instances']==o['solver_calls']==1 and o['explicit_solution_constructions']==0,'callcounter');C(o['native_distance_matrix']==mat[proxy]and o['native_matrix_entries_checked']==169,'native169');C(o['num_iterations']==len(o['stats'])==250 and all(set(q)==statskeys for q in o['stats']),'250 sixfield')
 m=o['native_model_parameters'];C(m['num_clients']==12 and m['num_vehicles']==3 and m['vehicle']['capacity']==[5]and m['vehicle']['num_available']==3,'modelQK');C([[v['x'],v['y']]for v in m['locations']]==x['coordinates'],'coordmapping');C([v['location']for v in m['clients']]==list(range(1,13))and all(v['required']and v['delivery']==[1]and v['pickup']==[0]for v in m['clients']),'customers');C(m['duration_matrix_all_zero']and m['vehicle']['fixed_cost']==0 and m['vehicle']['unit_distance_cost']==1 and m['vehicle']['unit_duration_cost']==0,'pure distance')
 routes=o['routes'];loads=[len(q)-2 for q in routes];C(all(q[0]==q[-1]==0 and all(1<=v<=12 for v in q[1:-1])for q in routes),'closed routes');C(sorted(v for q in routes for v in q[1:-1])==list(range(1,13))and len(routes)<=3,'coverage');ok=max(loads)<=5;C(ok==o['solver_is_feasible']and o['solver_is_complete'],'feasibility');cost={k:sum(ma[u][v]for q in routes for u,v in zip(q,q[1:]))for k,ma in mat.items()};C(cost[proxy]==o['reported_distance']==o['internal_route_cost'],'raw cost');C(o['reported_cost']==(cost[proxy]if ok else None),'reported scientific null');C([[t['node']for t in q['activities']]for q in o['native_routes']]==routes,'native routeidentity');gap=cost[proxy]-refs[name][proxy]if ok else None;C(gap is None or gap>=0,'own gap')
 row={'call_id':s['call_id'],'instance_id':name,'proxy':proxy,'seed':s['seed'],'arm':arm,'feasible':ok,'loads':loads,'routes':routes,'E':cost['E']if ok else None,'G':cost['G']if ok else None,'own_gap_mm':gap,'exact_hit':gap==0};outputs[(name,s['seed'],proxy,arm)]=o
 if arm=='P':
  maxedge=max(max(q)for q in mat[proxy]);U=15*maxedge;P=U+1;d=o['derived_penalty'];C((d['n_customers'],d['K'],d['max_edge'],d['U'],d['P'])==(12,3,maxedge,U,P),'P inputderived');C(1000*P<2**53 and 4*(U+12*P)<2**53,'numeric bound')
  pp=o['default_solve_params']['values']['penalty']['values'];C(pp['min_penalty']==pp['max_penalty']==P and pp['solutions_between_updates']==500,'fixedP params');obs=o['penalty_observation'];C(obs['initial_penalties']==[[P],P,P]and len(obs['rows'])==250,'fixedP snapshot');initial=obs['initial_solution_routes'];C(sorted(v for q in initial for v in q[1:-1])==list(range(1,13))and max(len(q)-2 for q in initial)<=5,'initial coverage feasible');C(obs['initial_solution_feasible']and obs['first_best_feasible_iteration']==0,'initial observation');C(all(q['current_feas']and q['best_feas']for q in o['stats']),'allcurrentbest feasible');expected=[{'violation':v,'load':P*v,'duration':P*v,'distance':P*v}for v in(1,2,7,1000)]
  for i,q in enumerate(obs['rows'],1):C(q['iteration']==i and q['best_is_feasible']and q['observed_post_registration_penalties']==[[P],P,P]and q['observed_search_evaluator_integer_probes']==expected,'all saved probes');probe_rows+=1
  row.update(P=P,U=U,max_edge=maxedge,initial_feasible=True,current_all250_feasible=True,PM_changes=0)
 rows.append(row)
reported={q['call_id']:q for q in sm['rows']};C(len(reported)==144,'144 report comparison rows')
for r in rows:
 q=reported[r['call_id']];C((r['feasible'],r['E'],r['G'],r['own_gap_mm'],r['routes'],r['loads'])==(q['valid'],q['base_E'],q['base_G'],q['own_gap_mm'],q['routes'],q['loads']),'reported results agreement')
by={(r['instance_id'],r['seed'],r['proxy'],r['arm']):r for r in rows};pairs=[]
for name in proto['fields']:
 for seed in(0,1,2):
  for proxy in('E','G'):
   old=by[(name,seed,proxy,'A')];newr=by[(name,seed,proxy,'P')];both=old['feasible']and newr['feasible'];own=newr[proxy]-old[proxy]if both else None;gdelta=newr['G']-old['G']if both else None;C(own is None or own<=0,'own no deterioration');pairs.append({'instance_id':name,'seed':seed,'proxy':proxy,'A_feasible':old['feasible'],'P_feasible':newr['feasible'],'own_delta_mm':own,'G_delta_mm':gdelta})
armstats={}
for arm in('A','P'):
 ar=[r for r in rows if r['arm']==arm];va=[r for r in ar if r['feasible']];armstats[arm]={'planned':72,'valid':len(va),'exact_hits':sum(r['exact_hit']for r in ar),'full_panel_gap':0 if len(va)==72 and all(r['own_gap_mm']==0 for r in va)else None,'by_proxy':{p:{'planned':36,'valid':sum(r['proxy']==p for r in va),'exact_hits':sum(r['proxy']==p and r['exact_hit']for r in ar)}for p in('E','G')}}
C((armstats['A']['valid'],armstats['A']['exact_hits'],armstats['P']['valid'],armstats['P']['exact_hits'])==(60,55,72,72),'60/55/72/72');valid=[q for q in pairs if q['own_delta_mm']is not None];C(len(valid)==60,'60 pairedsuccess');improvements={p:{'denominator':30,'mean_own_delta_mm':statistics.mean(q['own_delta_mm']for q in valid if q['proxy']==p),'min_own_delta_mm':min(q['own_delta_mm']for q in valid if q['proxy']==p),'max_own_delta_mm':max(q['own_delta_mm']for q in valid if q['proxy']==p)}for p in('E','G')}
worse=[q for q in valid if q['proxy']=='E'and q['G_delta_mm']>0];C(len(worse)==1 and(worse[0]['instance_id'],worse[0]['seed'],worse[0]['own_delta_mm'],worse[0]['G_delta_mm'])==('nl_field_67',0,-22067,31965),'E-G counterexample');C(all(q is None for q in sm['overall']['pairs']['A_vs_P']['complete_panel_mean_deltas'].values()),'fullpaired cost null')
tr=JL('selftests/toy/raw/results.jsonl');C(len(tr)==2,'toy2');to={}
for r in tr:
 C(r['returncode']==0 and r['process_spawned']and r['child_reaped'],'toyprocess');C(H(R(r['stdout']))==r['stdout_sha256']and H(R(r['stderr']))==r['stderr_sha256'],'toyhash');to[r['call_id']]=J(r['stdout'])
C(all(to['TOY_P_OBS'][k]==to['TOY_P_NOOBS'][k]for k in['routes','native_routes','reported_cost','stats','num_iterations','native_distance_matrix']),'toy observation invariance')
err=R('independent_supervision/results/FINAL_REVIEW.stderr').decode();r2=J('independent_supervision/results/FINAL_REVIEW_R2_EXECUTION.json');review=J('independent_supervision/results/READER_CLAIMS_REVIEW.json');C('ValueError: reader boundary 预测'in err and r2['returncode']==0 and r2['native_calls']==r2['solver_calls']==0 and review['status']=='PASS','editorial gate only then pass');R('source_evidence/CAPACITY_PRIORITY_PROOF_ZH.txt')
res={'status':'PASS_SAVED_PRIORITY_RECHECK','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cutoff_utc':'2026-10-09T07:41:00Z','formal_finished_utc':finished['utc'],'new_formal_slots':72,'historical_reference_slots':72,'historical_design':'nonconcurrent fixed A72; no new baseline solver calls','frozen_members':len(frozen['files']),'full_freeze_verified':not a.skip_full_freeze,'historical_archive_members_verified':not a.skip_history_archive,'native_matrix_entries_rechecked':144*169,'P_public_observer_rows_rechecked':probe_rows,'P_integer_probe_scalars_rechecked':probe_rows*12,'arms':armstats,'pair_stats':improvements,'both_success':60,'A_failure_to_P_success':12,'paired_fullpanel_mean_cost_delta':None,'E_search_G_deterioration':worse,'rows':rows,'pairs':pairs,'toy_calls':2,'toy_observation_invariance':True,'first_report_gate':'reader boundary 预测; editorial failure','second_report_gate':'PASS no solver/native calls','new_solver_calls':0,'new_native_constructions':0,'source_files_read':seen,'limitations':['Saved integer matrices/routes/observations only; no native reconstruction','P bound derivation checked arithmetically; version/source initialization and internal operators rely on saved prior source audit','No observation of original random4/4/4 or all internal candidates','Own-objective exact hits are observations, not a universal guarantee','Historic A72 has12null scientific costs; full paired cost mean remains null']}
a.out.write_text(json.dumps(res,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:res[k]for k in['status','frozen_members','native_matrix_entries_rechecked','P_public_observer_rows_rechecked','arms','pair_stats','E_search_G_deterioration']},ensure_ascii=False))
