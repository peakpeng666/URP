URP历史复盘增补证据包
结果截止2026-10-09 03:50 UTC。

先读 URP历史复盘增补_截至20261009T0350Z.txt。
增补更新条目.json 对应3项更新，不是新增独立实验数。
SAVED_EVIDENCE_RECHECK.json 是对原本地保存证据的本轮独立复核，三套冻结清单103/850/141成员hash通过。
SELECTED_SOURCE_MANIFEST.json 列出选定快照的源身份；它不声称包含三套完整证据，更不声称全历史335 ZIP复算。
SOURCE_PRESERVATION.json 记录选定原件未变。

从解压目录运行：
python audit_saved_addendum.py --source-root evidence --skip-complete-freeze --out replay.json
只读脚本仅使用Python标准库，不导入项目求解源码，不启动优化器、模型、子进程或网络。只写指定输出。选定快照不含完整冻结树，故使用skip-complete-freeze；完整成员检查记录来自原目录模式。
PORTABLE_REPLAY.json 保存本包快照重放结果。

阅读检查深度见正文第二节。物理几何、环境重建、全合成测试和远端权限回读未在本轮重复；依据各原始已审证据与既有归档回执。

本增补交付未修改第一版、三项目原件或原交接索引，没有上传或删除。是否已私有归档，以之后归档人员的真实交付回执为准。
