"""Read saved evidence only. No optimizer, model, subprocess or source imports.
Usage: python audit_saved_addendum.py --source-root /workspace/shared --out audit.json
Portable evidence: --source-root ./evidence --skip-complete-freeze
"""
import argparse,collections,datetime,hashlib,json,math,pathlib,statistics
p=argparse.ArgumentParser();p.add_argument('--source-root',type=pathlib.Path,required=True);p.add_argument('--out',type=pathlib.Path,required=True);p.add_argument('--skip-complete-freeze',action='store_true');a=p.parse_args()
S=a.source_root; accessed={}
def h(data):return hashlib.sha256(data).hexdigest()
def raw(path):
 path=pathlib.Path(path);b=path.read_bytes();accessed[str(path.relative_to(S))]={'bytes':len(b),'sha256':h(b)};return b
def J(path):return json.loads(raw(path))
def JL(path):return [json.loads(x)for x in raw(path).splitlines()]
def check(c,m):
 if not c:raise ValueError(m)
def match_float(x,y):return abs(x-y)<1e-10
F=S/'public_route_fixed_iterations_repro_20261009';E=S/'ee130_exact_small_field_20261009';K=S/'public_route_fleet_constraint_effects_20261009'
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cutoff_utc':'2026-10-09T03:50:00Z','optimizer_calls':0,'model_calls':0,'source_mode':'selected_snapshot'if a.skip_complete_freeze else'original_local_saved_evidence','limits':['No optimizer rerun, no DP-table certificate','No continuous geometry or vehicle feasibility recomputation','No environment replay or full historical corpus audit','Full frozen-member hashes checked only in original-source mode; portable snapshot verifies selected saved evidence']}
freeze=[]
for D in(F,E,K):
 m=J(D/'freeze/FROZEN_FILES.json');bad=[]
 if not a.skip_complete_freeze:
  for rel,info in m['files'].items():
   b=(D/rel).read_bytes()
   if len(b)!=info['bytes']or h(b)!=info['sha256']:bad.append(rel)
  check(not bad,'FROZEN_CHANGED '+D.name)
 freeze.append({'project':D.name,'members':len(m['files']),'full_member_hashes_checked':not a.skip_complete_freeze,'mismatches':bad})
result['freeze_checks']=freeze
# Independent original TSPLIB parser, nearest-integer distance without floating sqrt.
def vrp(path):
 head={};xy={};dem={};dep=[];section=None
 for line in raw(path).decode().splitlines():
  line=line.strip()
  if not line:continue
  if line in('NODE_COORD_SECTION','DEMAND_SECTION','DEPOT_SECTION'):section=line;continue
  if line=='EOF':break
  if section is None:
   k,v=line.split(':',1);head[k.strip()]=v.strip()
  elif section=='NODE_COORD_SECTION':
   z=list(map(int,line.split()));xy[z[0]-1]=z[1:]
  elif section=='DEMAND_SECTION':
   z=list(map(int,line.split()));dem[z[0]-1]=z[1]
  elif int(line)!=-1:dep.append(int(line)-1)
 check(dep==[0],'depot');n=int(head['DIMENSION']);check(set(xy)==set(dem)==set(range(n)),'input sets')
 check(head['EDGE_WEIGHT_TYPE']=='EUC_2D','metric')
 return xy,dem,int(head['CAPACITY'])
def dist(x,y):
 q=sum((u-v)**2 for u,v in zip(x,y));r=math.isqrt(q);return r+(4*q>=(2*r+1)**2)
def route_audit(out,inst,k):
 xy,dem,cap=inst;rs=out['routes'];seen=[];loads=[];cost=0
 for r in rs:
  check(len(r)>2 and r[0]==r[-1]==0 and 0 not in r[1:-1],'closed routes');seen+=r[1:-1];loads.append(sum(dem[i]for i in r[1:-1]));cost+=sum(dist(xy[u],xy[v])for u,v in zip(r,r[1:]))
 check(sorted(seen)==list(range(1,len(xy))),'customer coverage');check(len(rs)<=k,'vehicle limit')
 check(cost==out['reported_distance']==out['internal_route_cost'],'route cost');valid=max(loads)<=cap
 check(valid==out['solver_is_feasible']and out['solver_is_complete'],'feasibility flag')
 check(out['reported_cost']==(cost if valid else None),'reported feasible cost')
 check(out['num_iterations']==25 and len(out['stats'])==25,'ILS length')
 check(all(set(z)=={'current_cost','current_feas','candidate_cost','candidate_feas','best_cost','best_feas'}for z in out['stats']),'trajectory fields')
 model=out['native_model_parameters'];check(model['num_vehicles']==k and model['num_clients']==len(xy)-1,'native dimensions')
 check([[q['x'],q['y']]for q in model['locations']]==[xy[i]for i in range(len(xy))],'native coords')
 check([z['delivery'][0]for z in model['clients']]==[dem[i]for i in range(1,len(xy))],'native demands')
 return {'feasible':valid,'cost':cost,'vehicles':len(rs),'capacity':cap,'overloaded_routes':sum(v>cap for v in loads),'maximum_load':max(loads),'canonical':sorted(min(r[1:-1],r[1:-1][::-1])for r in rs)}
# Fixed iteration repeat outcomes and exact 144-line restoration mapping.
schedule=J(F/'freeze/SCHEDULE.json');records=JL(F/'raw/results.jsonl');events=JL(F/'raw/attempts.jsonl');lines=raw(F/'raw/attempts.jsonl').splitlines(keepends=True);mapping=J(F/'independent_supervision/postraw_amendment/DERIVED_EVENT_MAPPING.json');check(len(schedule)==len(records)==72 and len(events)==len(mapping['mapping'])==144,'fixed denominators')
for i,(s,r)in enumerate(zip(schedule,records)):
 u,v=events[2*i:2*i+2];check(set(u)==set(s)|{'utc'}and all(u[k]==x for k,x in s.items()),'fixed start exact schema');check({k:x for k,x in v.items()if k!='utc'}==r,'fixed end exact schema');check(all(r[k]==x for k,x in s.items()),'fixed schedule binding');check(u['utc']<=v['utc']and(i==71 or v['utc']<=events[2*i+2]['utc']),'fixed chronology')
 for q in range(2):
  m=mapping['mapping'][2*i+q];ev=events[2*i+q];check(m['original_line_number_1_based']==2*i+q+1 and m['original_line_including_newline_sha256']==h(lines[2*i+q]),'mapping line hash');check(m['call_id']==s['call_id']and m['original_numeric_phase']==ev['phase'],'mapping identity');check(m['derived_event_kind']==('DERIVED_START'if q==0 else'DERIVED_FINISH'),'derived label')
check(mapping['optimizer_calls']==0 and not mapping['raw_modified']and not mapping['frozen_source_modified'],'recovery scope')
instF={s['instance_id']:vrp(F/'input'/f"{s['instance_id']}.vrp")for s in schedule};fixed={};outF={}
for s,r in zip(schedule,records):
 check(r['process_spawned']and r['child_reaped']and r['returncode']==0,'fixed process');check(h(raw(F/r['stdout']))==r['stdout_sha256']and h(raw(F/r['stderr']))==r['stderr_sha256'],'fixed output hashes');o=J(F/r['stdout']);v=route_audit(o,instF[s['instance_id']],len(instF[s['instance_id']][0])-1);check(v['feasible'],'fixed feasible');fixed[s['call_id']]=v;outF[s['call_id']]=o
pairs=J(F/'reports/PAIR_COMPARISON.json');check(len(pairs)==36,'pair denom')
for z in pairs:
 u,v=z['A_call_id'],z['B_call_id'];check(fixed[u]['cost']==fixed[v]['cost']and fixed[u]['canonical']==fixed[v]['canonical']and outF[u]['stats']==outF[v]['stats'],'pair mismatch');check(z['status']=='PASS','pair report')
result['fixed']={'calls':72,'feasible_calls':72,'repeat_pairs':36,'matching_cost_route_trajectory_pairs':36,'schema_derived_lines_rechecked':144,'new_solve_calls':0,'event_labels_original':False,'rows':[{'call_id':k,**{q:v for q,v in r.items()if q!='canonical'}}for k,r in fixed.items()]}
# Fleet: parse actual original SOL route count, verify all witnesses and all36 outcomes.
tasks=J(K/'freeze/TASKS.json');baseline=J(K/'freeze/BASELINE_A.json');krefs={};instK={};witnesses=[]
for t in tasks:
 name=t['instance_id'];instK[name]=vrp(K/'input'/f'{name}.vrp');check(instK[name]==instF[name],'same input across arms');sol=raw(K/'references'/f'{name}.sol').decode().splitlines();rs=[[0]+list(map(int,l.split(':',1)[1].split()))+[0]for l in sol if l.startswith('Route')];xy,dm,cap=instK[name];check(sorted(z for r in rs for z in r[1:-1])==list(range(1,len(xy)))and all(sum(dm[z]for z in r[1:-1])<=cap for r in rs),'SOL witness');krefs[name]=len(rs);witnesses.append({'instance_id':name,'K_ref':len(rs),'witness_verified':True})
base={(z['instance_id'],z['seed']):z for z in baseline['cases']};recs=JL(K/'raw/results.jsonl');check(len(recs)==36,'fleet denom');reported={(z['instance_id'],z['seed']):z for z in J(K/'reports/PAIRED_RESULTS.json')};fleet=[]
for rec in recs:
 s=rec['schedule'];key=(s['instance_id'],s['seed']);b=base[key];check(b['call_A'].endswith('_rA'),'preselected A');check(raw(K/b['control_file'])==raw(F/'raw/calls'/f"{b['call_A']}.stdout"),'identical historical control');check(h(raw(K/rec['stdout']))==rec['stdout_sha256']and h(raw(K/rec['stderr']))==rec['stderr_sha256'],'fleet output hashes');check(rec['process_spawned']and rec['child_reaped']and rec['returncode']==0,'fleet process');o=J(K/rec['stdout']);v=route_audit(o,instK[key[0]],krefs[key[0]]);c=fixed[b['call_A']];z={'instance_id':key[0],'seed':key[1],'call_id':rec['call_id'],'K_ref':krefs[key[0]],**{q:x for q,x in v.items()if q!='canonical'},'delta_cost':v['cost']-c['cost']if v['feasible']else None,'relative_delta_pct':(v['cost']-c['cost'])/c['cost']*100 if v['feasible']else None,'delta_vehicles':v['vehicles']-c['vehicles']if v['feasible']else None};r=reported[key];check(r['valid_pair']==v['feasible']and r['delta_cost']==z['delta_cost']and r['delta_vehicles']==z['delta_vehicles'],'fleet report values');fleet.append(z)
valid=[z for z in fleet if z['feasible']];check(len(valid)==33,'valid33');summary=J(K/'reports/SUMMARY.json');mean=statistics.mean(z['relative_delta_pct']for z in valid);check(match_float(mean,summary['overall']['relative_delta_pct']['mean']),'conditional mean')
result['fleet']={'planned_treatment':36,'reused_controls':36,'valid_pairs':33,'complete_instances':11,'planned_instances':12,'conditional_relative_delta_pct_mean':mean,'conditional_cost_delta_mean':statistics.mean(z['delta_cost']for z in valid),'conditional_vehicle_delta_mean':statistics.mean(z['delta_vehicles']for z in valid),'lower_equal_higher':[sum(z['delta_cost']<0 for z in valid),sum(z['delta_cost']==0 for z in valid),sum(z['delta_cost']>0 for z in valid)],'infeasible_rows':[z for z in fleet if not z['feasible']],'all_rows':fleet,'reference_witnesses':witnesses}
# EE130: parse frozen integer matrices, rescore main16 and old48; compare saved16 scalar DP outputs.
main=JL(E/'raw/results.jsonl');ver=JL(E/'independent_supervision/raw/results.jsonl');check(len(main)==len(ver)==16,'exact denominators');vm={z['schedule']['call_id']:z for z in ver};ex={};matrices={};exrows=[]
for rec in main:
 s=rec['schedule'];cid=s['call_id'];b=raw(E/s['input']);check(h(b)==s['input_sha256'],'exact input identity');tokens=b.decode().split();tag,n,arm=tokens[:3];n=int(n);vals=list(map(int,tokens[3:]));N=n+1;check(tag=='HKLEX_V1'and len(vals)==2*N*N,'matrix format');M={'E':[vals[i*N:(i+1)*N]for i in range(N)],'G':[vals[N*N+i*N:N*N+(i+1)*N]for i in range(N)]};matrices[s['instance_id']]=(n,M)
 o=J(E/rec['stdout']);vrec=vm[cid];v=J(E/vrec['stdout'])
 for rr in(rec,vrec):
  check(rr['returncode']==0 and rr['process_spawned']and rr['child_reaped'],'exact process');check(h(raw(E/rr['stdout']))==rr['stdout_sha256']and h(raw(E/rr['stderr']))==rr['stderr_sha256'],'exact output hashes')
 r=o['route'];check(r[0]==r[-1]==0 and sorted(r[1:-1])==list(range(1,N)),'exact route coverage');cost={k:sum(mm[u][w]for u,w in zip(r,r[1:]))for k,mm in M.items()};check(cost=={'E':o['E'],'G':o['G']},'exact route objective');check(all(o[k]==v[k]for k in('primary','secondary','E','G')),'main scalar agreement');primary,secondary=arm.split('_');check((o['primary'],o['secondary'])==(cost[primary],cost[secondary]),'lex objective');B=N*max(max(row)for row in M[secondary])+1;check(v['encoding_base']==B and v['encoded_objective']==o['primary']*B+o['secondary']and 0<=o['secondary']<B,'encoding');check(v['safe_tour_bound']<v['sentinel'],'encoding overflow');check(o['valid_states']==v['states']==n*2**(n-1),'state count');check(o['internal_transitions']==v['extension_transitions']==n*(n-1)*2**(n-2),'transition count');ex[(s['instance_id'],arm)]=cost;exrows.append({'call_id':cid,'route_rescored':True,'cross_implementation_saved_values_match':True,**cost})
conds=[]
for ident,(n,M)in matrices.items():
 eg,ge=ex[(ident,'E_G')],ex[(ident,'G_E')];conds.append({'instance_id':ident,'n':n,'E_star':eg['E'],'G_among_E_star_min':eg['G'],'G_star':ge['G'],'E_among_G_star_min':ge['E'],'integer_proxy_gap_mm':eg['G']-ge['G']})
old=J(E/'reports/OLD_48_ROUTE_COMPARISON.json');check(len(old)==48,'old48');oldrows=[]
for z in old:
 o=J(E/'input/old/raw/calls'/f"{z['call_id']}.stdout");n,M=matrices[z['instance_id']];check(len(o['routes'])==1,'old single vehicle');r=o['routes'][0];check(r==z['route']and r[0]==r[-1]==0 and sorted(r[1:-1])==list(range(1,n+1)),'old route identity');cs={k:sum(mm[u][w]for u,w in zip(r,r[1:]))for k,mm in M.items()};check(all(cs[k]==z[k]for k in('E','G'))and o['reported_cost']==cs[z['arm']],'old cost');arm=z['arm'];other='G'if arm=='E'else'E';best=ex[(z['instance_id'],arm+'_'+other)];check(cs[arm]-best[arm]==z['primary_gap_mm']==0 and cs[other]-best[other]==z['conditional_secondary_tie_gap_mm']==0,'old optimum diagnostics');oldrows.append({'call_id':z['call_id'],'primary_gap_mm':0,'secondary_tie_gap_mm':0})
check(sum(z['integer_proxy_gap_mm']>0 for z in conds)==1 and max(z['integer_proxy_gap_mm']for z in conds)==3276,'exact gap')
result['exact']={'saved_main_DP_outputs':16,'saved_independent_DP_outputs':16,'saved_pair_value_matches':16,'main_routes_rescored':16,'old_routes_rescored':48,'old_primary_suboptimal':0,'old_secondary_tie_worse':0,'strict_gap_conditions':1,'conditions':conds,'main_rows':exrows,'old_rows':oldrows,'new_DP_calls':0,'optimality_basis':'Existing two source-distinct Held-Karp computations plus preserved inputs/outputs and source review; this recheck only rescores saved routes and verifies saved values, no DP proof certificate'}
# Bind standalone reports and local archive identity to already recorded private archive receipts.
receipts=[]
for D in(F,E,K):
 r=J(D/'provenance/FINAL_REVIEWED_DRIVE_RECEIPT.json');check(r['verified']and r['owner_only']and not r['shared']and r['sha256']==r['download_sha256'],'receipt');reports=[]
 for z in r['report_files']:
  local=D/pathlib.Path(z['source']).relative_to(pathlib.Path('/workspace/shared')/D.name);check(h(raw(local))==z['sha256'],'report receipt hash');reports.append({'url':z['url'],'sha256':z['sha256']})
 archive=S/pathlib.Path(r['source']).name;archive_checked=archive.is_file();
 if archive_checked:check(h(archive.read_bytes())==r['sha256'],'archive bytes')
 receipts.append({'project':D.name,'archive_url':r['url'],'archive_sha256':r['sha256'],'local_archive_bytes_checked':archive_checked,'existing_private_remote_readback_receipt':True,'new_remote_readback_by_this_review':False,'report_links':reports})
result['source_receipts']=receipts
result['source_files_read']=accessed;result['status']='PASS_SAVED_EVIDENCE_RECHECK';a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':result['status'],'fixed_pairs':36,'fleet_valid':33,'exact_saved_computations':32,'sources_read':len(accessed),'frozen_checks':freeze},ensure_ascii=False))
