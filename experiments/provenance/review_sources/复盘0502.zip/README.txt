URP历史复盘第二份增补
结果截止2026-10-09 05:02 UTC；审阅和交付稍后。

先读 URP历史复盘增补_截至20261009T0502Z.txt。
增补更新与未决问题.json 不计算新独立实验总数，153仍为第一版阶段记录。
SAVED_EVIDENCE_RECHECK.json 是原保存数据独立复核，三个冻结清单223/1375/217成员hash通过。
PORTABLE_REPLAY.json 是本包选定快照重放；三项结果与原目录复核一致。
FINAL_SOURCE_IDENTITIES.json 分列结果与源归档时间，adapter终审05:03、归档05:04，未倒写至05:02。
SOURCE_PRESERVATION.json 核原02:25与03:50交付封存hash及所选来源未变。

复核方法（仅Python标准库）：
python audit_saved_addendum.py --source-root evidence --skip-complete-freeze --out replay.json

脚本只读保存路线/原生输出/DP值/计数与hash，不导入求解器，不建原生模型、不求优、不联网。只写指定输出。快照未带完整冻结树，使用skip-complete-freeze；完整冻结成员身份检查已在原目录模式完成。历史25原始输出字节交叉比对在原目录模式完成，快照保存其副本与原始hash。

选定快照不是全项目档案，不代表全335ZIP重算。几何、CRS、全国SHP来源扫描、完整合成测试、真实远端回读均未在本增补重复，其已审证据和限制见正文。原官方源码许可与边界来源引用随包保留。

本包不会覆盖历史版本或交接索引。归档须在root审核后由唯一归档方进行；最终状态以独立归档回执为准。
