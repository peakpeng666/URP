"""Read-only arithmetic and identity checks of saved results. No solver imports or calls.
python audit_saved_addendum.py --source-root /workspace/shared --out RECHECK.json
For selected package snapshots add --skip-complete-freeze.
"""
import argparse,collections,datetime,hashlib,json,math,pathlib,statistics
p=argparse.ArgumentParser();p.add_argument('--source-root',type=pathlib.Path,required=True);p.add_argument('--out',type=pathlib.Path,required=True);p.add_argument('--skip-complete-freeze',action='store_true');a=p.parse_args();S=a.source_root;accessed={}
F=S/'public_route_fleet_budget_interaction_20261009';E=S/'cross_field_distance_proxy_exact_20261009';D=S/'public_route_fleet_feasibility_diagnosis_20261009';CUTOFF='2026-10-09T05:02:00+00:00'
def H(b):return hashlib.sha256(b).hexdigest()
def R(p):
 p=pathlib.Path(p);b=p.read_bytes();accessed[str(p.relative_to(S))]={'bytes':len(b),'sha256':H(b)};return b
def J(p):return json.loads(R(p))
def JL(p):return [json.loads(z)for z in R(p).splitlines()]
def CK(c,m):
 if not c:raise ValueError(m)
def local(root,p):
 p=pathlib.Path(p);return S/p.relative_to('/workspace/shared')if p.is_absolute()else root/p
def EQ(x,y):return abs(x-y)<1e-10
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'result_cutoff_utc':CUTOFF,'new_optimizer_calls':0,'new_model_calls':0,'new_native_constructions':0,'limits':['Saved result recheck only; no DP rerun or formal optimality certificate','Geometric/CRS/source provenance audits read but not rerun','Complete frozen hashes checked only with original full source root','Source-level ILS/penalty reasoning does not establish a unique failure cause']}
fc=[]
for root in(F,E,D):
 m=J(root/'freeze/FROZEN_FILES.json');bad=[]
 if not a.skip_complete_freeze:
  for rel,info in m['files'].items():
   b=(root/rel).read_bytes()
   if H(b)!=info['sha256']or len(b)!=info['bytes']:bad.append(rel)
  CK(not bad,'frozen changed '+root.name)
 fc.append({'project':root.name,'manifest_members':len(m['files']),'complete_hash_check_performed':not a.skip_complete_freeze,'mismatches':bad})
result['frozen_member_checks']=fc
result['completed_result_times']={}
for root,rel in [(F,'raw/FINISHED.json'),(E,'raw/FINISHED.json'),(E,'independent_supervision/raw/FINISHED.json'),(D,'raw/FINISHED.json')]:
 finish=J(root/rel);CK(datetime.datetime.fromisoformat(finish['utc'])<=datetime.datetime.fromisoformat(CUTOFF),'completion after cutoff');result['completed_result_times'][root.name+'/'+rel]=finish['utc']

def VRP(p):
 headers={};xy={};dm={};dep=[];sec=None
 for line in R(p).decode().splitlines():
  line=line.strip()
  if not line:continue
  if line=='EOF':break
  if line in ('NODE_COORD_SECTION','DEMAND_SECTION','DEPOT_SECTION'):sec=line;continue
  if sec is None:
   k,v=line.split(':',1);headers[k.strip()]=v.strip()
  elif sec=='NODE_COORD_SECTION':
   k,x,y=map(int,line.split());CK(k-1 not in xy,'duplicate point');xy[k-1]=(x,y)
  elif sec=='DEMAND_SECTION':
   k,v=map(int,line.split());CK(k-1 not in dm,'duplicate demand');dm[k-1]=v
  elif int(line)!=-1:dep.append(int(line)-1)
 n=int(headers['DIMENSION']);CK(dep==[0]and headers['EDGE_WEIGHT_TYPE']=='EUC_2D'and set(xy)==set(dm)==set(range(n)),'VRP identity');return xy,dm,int(headers['CAPACITY'])
def edge(x,y):
 q=sum((u-v)**2 for u,v in zip(x,y));r=math.isqrt(q);return r+int(4*q>=(2*r+1)**2)
def SOL(p):
 rr=[];cost=None
 for line in R(p).decode().splitlines():
  if line.startswith('Route'):rr.append([0]+list(map(int,line.split(':',1)[1].split()))+[0])
  elif line.startswith('Cost'):cost=int(line.split()[1])
 CK(cost is not None and rr,'SOL parse');return rr,cost
problems={t['instance_id']:VRP(F/'input'/f"{t['instance_id']}.vrp")for t in J(F/'freeze/TASKS.json')}
mhash={}
for name,(xy,dm,cap)in problems.items():
 mat=[[edge(xy[u],xy[v])for v in range(len(xy))]for u in range(len(xy))];mhash[name]=H(json.dumps(mat,separators=(',',':')).encode())
def audit_routes(routes,name,k):
 xy,dm,cap=problems[name];seen=[];loads=[];cost=0
 for r in routes:
  CK(len(r)>2 and r[0]==r[-1]==0 and all(0<v<len(xy)for v in r[1:-1]),'route closure');seen+=r[1:-1];loads.append(sum(dm[v]for v in r[1:-1]));cost+=sum(edge(xy[u],xy[v])for u,v in zip(r,r[1:]))
 CK(sorted(seen)==list(range(1,len(xy)))and len(routes)<=k,'route coverage / vehicle count')
 return {'feasible':max(loads)<=cap,'cost':cost,'vehicles':len(routes),'total_excess_load':sum(max(0,l-cap)for l in loads),'overloaded_routes':sum(l>cap for l in loads),'maximum_load':max(loads),'capacity':cap}
def native_model(o,name,k):
 xy,dm,cap=problems[name];m=o['native_model_parameters'];v=m['vehicle'];CK(m['num_vehicles']==k and v['num_available']==k and v['capacity']==[cap]and m['num_clients']==len(xy)-1,'native model constraints');CK([(z['x'],z['y'])for z in m['locations']]==[xy[i]for i in range(len(xy))],'native coordinates');CK([z['delivery'][0]for z in m['clients']]==[dm[i]for i in range(1,len(xy))],'native delivery');CK(o['model_matrix_sha256']==mhash[name],'full integer matrix hash')
def solved(o,name,k,budget):
 r=audit_routes(o['routes'],name,k);native_model(o,name,k);CK(r['feasible']==o['solver_is_feasible']and o['solver_is_complete'],'solver validity');CK(r['cost']==o['reported_distance']==o['internal_route_cost'],'saved route cost');CK(o['reported_cost']==(r['cost']if r['feasible']else None),'cost null for failure');CK(o['num_iterations']==len(o['stats'])==budget,'iteration count');CK(all(set(z)=={'current_cost','candidate_cost','best_cost','current_feas','candidate_feas','best_feas'}for z in o['stats']),'6fields');return r
def ledger_outputs(root,rel):
 rs=JL(root/rel)
 for r in rs:
  CK(r['returncode']==0 and r['process_spawned']and r['child_reaped'],'process failure');CK(H(R(local(root,r['stdout'])))==r['stdout_sha256']and H(R(local(root,r['stderr'])))==r['stderr_sha256'],'output hash')
  when=r.get('finished_utc',r.get('utc'))
  if when:CK(datetime.datetime.fromisoformat(when)<=datetime.datetime.fromisoformat(CUTOFF),'after result cutoff')
 return rs
# 144 cells: 72 new solves plus historical72. Original preselected controls retained.
hist=J(F/'freeze/HISTORICAL_CELLS.json')['cells'];CK(len(hist)==72,'historical count');cells={};outputs={}
for h in hist:
 o=J(F/h['output_file']);CK(H(R(F/h['output_file']))==h['stdout_sha256'],'historical output hash')
 if not a.skip_complete_freeze:CK(R(F/h['output_file'])==R(local(F,h['source_stdout'])),'original historical bytes')
 label=('standard'if h['arm']=='standard_n_clients'else'capped')+'25';key=(h['instance_id'],h['seed'],label);cells[key]=solved(o,h['instance_id'],h['K'],25);outputs[key]=o
rows=ledger_outputs(F,'raw/results.jsonl');CK(len(rows)==72,'new fleet count')
for r in rows:
 z=r['schedule'];o=J(F/r['stdout']);label=('standard'if z['arm']=='standard_n_clients'else'capped')+'250';key=(z['instance_id'],z['seed'],label);CK(key not in cells,'duplicate cell');cells[key]=solved(o,z['instance_id'],z['K'],250);outputs[key]=o
CK(len(cells)==144,'full cell count');prefix=[];pairs=[]
for name in problems:
 for seed in(0,1,2):
  z={label:cells[(name,seed,label)]for label in('standard25','capped25','standard250','capped250')};out={'instance_id':name,'seed':seed,'cells':z,'all_four_valid':all(v['feasible']for v in z.values())}
  for arm in('standard','capped'):
   old=outputs[(name,seed,arm+'25')];new=outputs[(name,seed,arm+'250')];CK(old['stats']==new['stats'][:25],'six field prefix');prefix.append({'instance_id':name,'seed':seed,'arm':arm,'six_field_prefix_equal':True})
  if out['all_four_valid']:
   for b in(25,250):
    c,s=z['capped'+str(b)],z['standard'+str(b)];out['delta'+str(b)]=c['cost']-s['cost'];out['relative'+str(b)]=(c['cost']-s['cost'])/s['cost']*100
   out['interaction_cost']=out['delta250']-out['delta25'];out['interaction_pp']=out['relative250']-out['relative25']
  pairs.append(out)
valid=[z for z in pairs if z['all_four_valid']];summary=J(F/'reports/SUMMARY.json');CK(len(valid)==33,'valid common33')
calc={'paired25_relative_delta_pct':statistics.mean(z['relative25']for z in valid),'paired250_relative_delta_pct':statistics.mean(z['relative250']for z in valid),'interaction_relative_pp':statistics.mean(z['interaction_pp']for z in valid),'interaction_delta_cost':statistics.mean(z['interaction_cost']for z in valid)}
for metric,v in calc.items():CK(EQ(v,summary['overall']['conditional_common_success'][metric]['mean']),'fleet metric '+metric);CK(summary['overall']['complete_primary'][metric]['mean']is None,'incomplete full primary must null')
fail=[]
for z in pairs:
 if not z['cells']['capped250']['feasible']:
  old=outputs[(z['instance_id'],z['seed'],'capped25')];new=outputs[(z['instance_id'],z['seed'],'capped250')];stats=new['stats'];CK(all(not t[f]for t in stats for f in('current_feas','candidate_feas','best_feas')),'failure flags');CK(len({t['best_cost']for t in stats})==1 and new['routes']==old['routes'],'failure best and route identity');fail.append({'instance_id':z['instance_id'],'seed':z['seed'],**z['cells']['capped250'],'best_penalized_constant':stats[0]['best_cost'],'current_penalized_min':min(t['current_cost']for t in stats),'all_iteration_end_feasibility_flags_false':True,'returned_routes_unchanged_from25':True})
result['fleet250']={'new_calls':72,'historical_cells':72,'four_cells_total':144,'planned_pairs':36,'valid_four_way_pairs':33,'feasible_counts':{q:sum(v['feasible']for k,v in cells.items()if k[2]==q)for q in('standard25','capped25','standard250','capped250')},'six_field_prefixes_equal':len(prefix),'conditional_metrics':calc,'pairs':pairs,'failures':fail,'scope':'Each prefix compares only six cost/feasibility fields; no full state or RNG equality claim'}
# Cross-field24 main routes and24 independently saved scalar values.
main=ledger_outputs(E,'raw/results.jsonl');ind=ledger_outputs(E,'independent_supervision/raw/results.jsonl');CK(len(main)==len(ind)==24,'DP denominator');iv={r['schedule']['call_id']:r for r in ind};values={};xr=[]
for r in main:
 s=r['schedule'];cid=s['call_id'];inp=R(E/r['input']);CK(H(inp)==r['input_sha256']==iv[cid]['input_sha256'],'DP input binding');z=inp.decode().split();n=int(z[1]);arm=z[2];N=n+1;v=list(map(int,z[3:]));CK(z[0]=='HKLEX_V1'and n==20 and len(v)==2*N*N,'DP input format');M={'E':[v[i*N:(i+1)*N]for i in range(N)],'G':[v[N*N+i*N:N*N+(i+1)*N]for i in range(N)]};o=J(local(E,r['stdout']));q=J(local(E,iv[cid]['stdout']));route=o['route'];CK(route[0]==route[-1]==0 and sorted(route[1:-1])==list(range(1,N)),'Hamilton route');c={k:sum(mat[u][w]for u,w in zip(route,route[1:]))for k,mat in M.items()};CK(c=={'E':o['E'],'G':o['G']}and all(o[k]==q[k]for k in('E','G','primary','secondary')),'DP cross values');p1,p2=arm.split('_');B=N*max(max(x)for x in M[p2])+1;CK(q['encoding_base']==B and q['encoded_objective']==c[p1]*B+c[p2]and c[p2]<B,'scalar encoding');CK(o['valid_states']==q['states']==n*2**(n-1)and o['internal_transitions']==q['extension_transitions']==n*(n-1)*2**(n-2),'DP state counts');CK(q['safe_tour_bound']<q['sentinel'],'overflow');values[(s['instance_id'],arm)]=c;xr.append({'call_id':cid,'integer_costs':c,'saved_independent_values_match':True,'route_rescored':True})
cs=J(E/'reports/SUMMARY.json');fieldrows=[]
for z in cs['fields']:
 name=z['instance_id'];eg,ge=values[(name,'E_G')],values[(name,'G_E')];delta=eg['G']-ge['G'];CK(delta==z['delta_integer_mm'],'cross delta');fieldrows.append({'instance_id':name,'stratum':z['stratum'],'E_star':eg['E'],'G_among_E_star_min':eg['G'],'G_star':ge['G'],'delta_integer_mm':delta})
CK(len(fieldrows)==12 and sum(z['delta_integer_mm']>0 for z in fieldrows)==1 and next(z['delta_integer_mm']for z in fieldrows if z['instance_id']=='nl_field_67')==5425,'cross conflict')
pre=ledger_outputs(E,'raw/field_results.jsonl');ipre=ledger_outputs(E,'independent_supervision/raw/field_results.jsonl');CK(len(pre)==len(ipre)==12,'preprocess/independent input count');CK(all(z['audit']['status']=='PASS_INPUT_AUDIT'for z in ipre),'input audit saved status')
result['cross_field']={'planned_fields':12,'saved_main_preprocess':12,'saved_independent_input_audits':12,'main_DP_outputs':24,'independent_DP_outputs':24,'main_routes_rescored':24,'saved_value_pair_matches':24,'new_DP_calls':0,'fields':fieldrows,'full_panel_mean_delta_mm':statistics.mean(z['delta_integer_mm']for z in fieldrows),'strict_conflicts':1,'zero_delta':11,'rows':xr,'scope':'Fixed NL-only boundaries and one synthetic task set per boundary. Input audit status read, not a new geometry or source scan.'}
# Adapter:12 known native Solution constructions,0 optimization. Independently verify original SOL exact order/cost/model.
rs=ledger_outputs(D,'raw/results.jsonl');CK(len(rs)==12,'adapter planned12');ar=[]
for rec in rs:
 z=rec['schedule'];name=z['instance_id'];problem=VRP(D/'input'/f'{name}.vrp');CK(problem==problems[name],'adapter same problem');routes,declared=SOL(D/'references'/f'{name}.sol');o=J(D/rec['stdout']);CK(o['routes']==routes,'SOL exact route order');CK([[v['node']for v in nr['activities']]for nr in o['native_routes']]==routes,'native activity roundtrip');CK(all(v['idx']==v['node']-1 and v['location']==v['node']for nr in o['native_routes']for v in nr['activities']if v['type']=='CLIENT'),'native CLIENT mapping');CK(o['native_route_constructions']==len(routes),'native route construction count');r=audit_routes(routes,name,len(routes));native_model(o,name,len(routes));n=o['native_observations'];CK(r['feasible']and r['cost']==declared==o['reference_declared_cost']==n['objective_cost']==n['distance'],'reference objective');CK(n['is_feasible']and n['is_complete']and n['excess_load']==[0]and n['num_routes']==len(routes),'native accepted');CK(o['native_solution_constructions']==o['model_constructions']==1 and o['optimization_calls']==o['search_iterations']==o['random_initialization_calls']==0,'construction/search counts');CK(o['blocked_optimizer_attempts']==[]and o['denied_io_events']==[],'no blocked optimizer attempts');ar.append({'instance_id':name,'K_ref':len(routes),'reference_cost':declared,'Q':problem[2],'native_accepted':True,'formal_solution_constructions':1,'optimization_calls':0,'exact_full_matrix_hash_verified':True})
ss=J(D/'reports/SUMMARY.json');CK(ss['accepted']==12 and ss['formal_solution_constructions_verified_from_outputs']==12 and ss['formal_optimization_calls_verified_from_outputs']==0,'adapter summary')
result['adapter']={'planned':12,'accepted':12,'formal_solution_constructions':12,'formal_optimization_calls':0,'rows':ar,'X524':next(z for z in ar if z['instance_id']=='X-n524-k153'),'scope':'Native acceptance checked from preserved output plus integer and identity recheck; no new native construction'}
result['source_files_read']=accessed;result['status']='PASS_SAVED_EVIDENCE_RECHECK';a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':result['status'],'fleet_valid':len(valid),'cross_field':12,'native_accepted':12,'files_read':len(accessed),'freeze_checks':fc},ensure_ascii=False))
