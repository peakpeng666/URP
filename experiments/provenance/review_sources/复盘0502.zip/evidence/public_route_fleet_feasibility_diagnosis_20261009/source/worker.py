"""One deterministic reference adapter construction; no optimiser/search calls."""
import sys,json,time,resource,hashlib,traceback
from importlib.metadata import version
from collections import Counter
from model_helpers import build_model,native_model_parameters,extract_routes

def configure_worker_limits():
    if not __debug__:raise RuntimeError('Assertions must be enabled')
    before={'AS_bytes':list(resource.getrlimit(resource.RLIMIT_AS)),'CPU_seconds':list(resource.getrlimit(resource.RLIMIT_CPU))}
    resource.setrlimit(resource.RLIMIT_CPU,(15,15))
    resource.setrlimit(resource.RLIMIT_AS,(1536*1024**2,1536*1024**2))
    after={'AS_bytes':list(resource.getrlimit(resource.RLIMIT_AS)),'CPU_seconds':list(resource.getrlimit(resource.RLIMIT_CPU))}
    return {'inherited':before,'effective':after}

def run(payload):
    from pyvrp import Activity,ActivityType,Route,Solution,CostEvaluator
    assert version('pyvrp')=='0.14.0'
    assert set(payload)=={'coordinates','demands','capacity','K','reference_routes','reference_declared_cost'}
    n=len(payload['demands'])-1;reference=payload['reference_routes']
    assert len(reference)==payload['K']
    assert all(len(r)>=3 and r[0]==r[-1]==0 and all(type(j)is int and 1<=j<=n for j in r[1:-1])for r in reference)
    assert Counter(j for r in reference for j in r[1:-1])==Counter(range(1,n+1))
    denied=[];blocked=[]
    def audit(event,args):
        if event=='open' or event.startswith(('socket.','subprocess.','os.system','os.exec','os.spawn')):
            denied.append(event);raise PermissionError('External IO forbidden during native reference adapter')
    def profile(frame,event,arg):
        if event=='call':
            path=frame.f_code.co_filename.replace('\\','/')
            if any(x in path for x in ('/pyvrp/search/','/pyvrp/solve.py','/pyvrp/IteratedLocalSearch.py','/pyvrp/minimise_fleet.py')):
                blocked.append({'event':event,'name':frame.f_code.co_name,'source':path});raise RuntimeError('Search invocation forbidden')
        if event=='c_call' and getattr(arg,'__name__','')=='make_random':
            blocked.append({'event':event,'name':'make_random'});raise RuntimeError('Random initialization forbidden')
    sys.addaudithook(audit)
    sys.setprofile(profile)
    wall,cpu=time.perf_counter(),time.process_time()
    try:
        data,matrix,mapping=build_model(payload)
        parameters=native_model_parameters(data,payload)
        built=time.perf_counter()
        # Route.cpp validates these as client indices and automatically adds
        # start/end depots from vehicle_type. An explicit DEPOT here is a reload.
        encoded=[[Activity(ActivityType.CLIENT,node-1) for node in route[1:-1]]for route in reference]
        routes=[Route(data,activities,vehicle_type=0)for activities in encoded]
        solution=Solution(data,routes)
        returned,native=extract_routes(solution,data,mapping)
        objective=CostEvaluator([0],0,0).cost(solution)
        observations={'is_feasible':solution.is_feasible(),'is_complete':solution.is_complete(),
            'num_routes':solution.num_routes(),'num_clients':solution.num_clients(),
            'num_missing_clients':solution.num_missing_clients(),'num_missing_groups':solution.num_missing_groups(),
            'num_missing_shipments':solution.num_missing_shipments(),'excess_load':solution.excess_load(),
            'excess_distance':solution.excess_distance(),'time_warp':solution.time_warp(),
            'distance':solution.distance(),'distance_cost':solution.distance_cost(),
            'duration_cost':solution.duration_cost(),'fixed_vehicle_cost':solution.fixed_vehicle_cost(),
            'uncollected_prizes':solution.uncollected_prizes(),'objective_cost':objective}
        checks={'native_feasible':observations['is_feasible'],'native_complete':observations['is_complete'],
            'all_customers':observations['num_clients']==n and observations['num_missing_clients']==0,
            'route_count_equals_K_ref':observations['num_routes']==payload['K'],
            'zero_violations':observations['excess_load']==[0]and observations['excess_distance']==0 and observations['time_warp']==0,
            'exact_route_order_roundtrip':returned==reference,
            'objective_matches_reference':objective==payload['reference_declared_cost']==observations['distance']==observations['distance_cost'],
            'only_distance_objective':observations['duration_cost']==observations['fixed_vehicle_cost']==observations['uncollected_prizes']==0,
            'route_loads_match':all(r['delivery']==[sum(payload['demands'][j]for j in rr)]for r,rr in zip(native,reference)),
            'route_capacity':all(r['delivery'][0]<=payload['capacity']and r['is_feasible']for r in native)}
        for i,r in enumerate(native):r.update(excess_load=routes[i].excess_load(),excess_distance=routes[i].excess_distance(),time_warp=routes[i].time_warp())
    finally:sys.setprofile(None)
    return {'status':'ADAPTER_CONSTRUCTION_OBSERVED','version':'0.14.0','seed':None,
            'model_constructions':1,'native_solution_constructions':1,'native_route_constructions':len(routes),
            'optimization_calls':0,'search_iterations':0,'random_initialization_calls':0,
            'reference_used':True,'fair_cold_start_quality_result':False,
            'mapping':'SOL node j -> Activity(CLIENT,j-1) -> data.client(j-1).location=j; Route adds depots from vehicle type',
            'K_ref':payload['K'],'reference_declared_cost':payload['reference_declared_cost'],
            'native_model_parameters':parameters,'native_observations':observations,'checks':checks,
            'routes':returned,'native_routes':native,
            'model_matrix_sha256':hashlib.sha256(json.dumps(matrix,separators=(',',':')).encode()).hexdigest(),
            'denied_io_events':denied,'blocked_optimizer_attempts':blocked,
            'build_wall_seconds_audit_only':built-wall,'total_wall_seconds_audit_only':time.perf_counter()-wall,
            'total_cpu_seconds_audit_only':time.process_time()-cpu}

if __name__=='__main__':
    limits=configure_worker_limits()
    payload=json.load(sys.stdin)
    result=run(payload)
    result['resource_limits']=limits
    result['worker_maxrss_KiB_audit_only']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    json.dump(result,sys.stdout,ensure_ascii=False,separators=(',',':'),allow_nan=False);sys.stdout.write('\n')
