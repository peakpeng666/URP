"""Exact three-route endpoint selection from an inherited local G-optimum table.

This module has no input-file access and never computes a local TSP. E is retained
only as part of the source witness contract; it is absent from the global key.
"""
import hashlib
import itertools
import json


def validate(local_rows, n, Q):
    if type(n) is not int or type(Q) is not int or not (3 <= n <= 12 and 1 <= Q <= 5 and n <= 3 * Q):
        raise ValueError('UNSUPPORTED_THREE_ROUTE_MODEL')
    minimum = max(1, n - 2 * Q)
    expected = {sum(1 << (x - 1) for x in group): group
                for size in range(minimum, min(Q, n) + 1)
                for group in itertools.combinations(range(1, n + 1), size)}
    local = {}
    for row in local_rows:
        mask = row['mask']
        if type(mask) is not int or mask not in expected or mask in local:
            raise ValueError('INVALID_OR_DUPLICATE_LOCAL_MASK')
        group = expected[mask]
        if row['customers'] != list(group) or any(type(x) is not int for x in row['customers']):
            raise ValueError('LOCAL_CUSTOMER_IDENTITY')
        route = row['route']
        if (not isinstance(route, list) or len(route) != len(group) + 2 or
                any(type(x) is not int for x in route) or route[0] != 0 or route[-1] != 0 or
                sorted(route[1:-1]) != list(group) or tuple(route[1:-1]) > tuple(reversed(route[1:-1]))):
            raise ValueError('INVALID_INHERITED_ROUTE')
        if any(type(row[k]) is not int or row[k] < 0 for k in ('E', 'G')):
            raise ValueError('INVALID_LOCAL_INTEGER_COST')
        local[mask] = row
    if set(local) != set(expected):
        raise ValueError('INCOMPLETE_LOCAL_TABLE')
    return local, minimum


def solve(local_rows, n, Q, objective):
    if objective not in ('SUM_MAX', 'MAX_SUM'):
        raise ValueError('UNKNOWN_OBJECTIVE')
    local, minimum = validate(local_rows, n, Q)

    def partitions(remaining, groups):
        if groups == 1:
            if minimum <= len(remaining) <= Q:
                yield (remaining,)
            return
        anchor, tail = remaining[0], remaining[1:]
        low = max(minimum, len(remaining) - (groups - 1) * Q)
        high = min(Q, len(remaining) - (groups - 1) * minimum)
        for size in range(low, high + 1):
            for other in itertools.combinations(tail, size - 1):
                group = (anchor,) + other
                members = set(group)
                rest = tuple(x for x in remaining if x not in members)
                for suffix in partitions(rest, groups - 1):
                    yield (group,) + suffix

    best = None
    coverage = set()
    size_counts = {}
    for partition in partitions(tuple(range(1, n + 1)), 3):
        if partition in coverage:
            raise AssertionError('DUPLICATE_UNLABELED_PARTITION')
        coverage.add(partition)
        rows = [local[sum(1 << (x - 1) for x in group)] for group in partition]
        lengths = [row['G'] for row in rows]
        total, longest = sum(lengths), max(lengths)
        key = ((total, longest) if objective == 'SUM_MAX' else (longest, total)) + (partition,)
        sizes = ','.join(map(str, sorted(map(len, partition))))
        size_counts[sizes] = size_counts.get(sizes, 0) + 1
        if best is None or key < best[0]:
            best = key, total, longest, partition, rows
    if best is None:
        raise ValueError('NO_FEASIBLE_PARTITION')
    encoded = json.dumps(sorted(coverage), separators=(',', ':')).encode()
    return {
        'objective': objective, 'n': n, 'Q': Q, 'K': 3,
        'sum_G_mm': best[1], 'max_route_G_mm': best[2],
        'partition': [list(group) for group in best[3]],
        'routes': [row['route'] for row in best[4]],
        'route_G_mm': [row['G'] for row in best[4]],
        'witness_rule': 'Inherited local (G,E,Rcode); E absent from global objective',
        'counters': {'local_subsets': len(local), 'new_local_tsp_evaluations': 0,
                     'unlabeled_partition_evaluations': len(coverage),
                     'unique_canonical_partitions': len(coverage),
                     'partition_size_counts': size_counts,
                     'canonical_partition_coverage_sha256': hashlib.sha256(encoded).hexdigest()},
    }
