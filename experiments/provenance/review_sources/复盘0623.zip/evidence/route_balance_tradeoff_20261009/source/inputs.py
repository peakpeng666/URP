"""Frozen parent bytes and catalog only; no cost recomputation or optimization."""
import hashlib
import json
import zipfile
from common import ROOT, read, sha


def load_input(field):
    protocol = read(ROOT / 'freeze/PROTOCOL.json')
    if field not in protocol['fields']:
        raise ValueError('UNSCHEDULED_FIELD')
    archive = ROOT / protocol['source']['archive']
    if sha(archive) != protocol['source']['archive_sha256']:
        raise ValueError('PARENT_ARCHIVE_IDENTITY')
    identities = read(ROOT / 'input/PARENT_MEMBER_IDENTITIES.json')['selected_members']
    member = f'raw/calls/{field}_G_E.stdout'
    audit_member = 'independent_supervision/FINAL_AUDIT.json'
    with zipfile.ZipFile(archive) as z:
        loaded = {}
        for name in (member, audit_member):
            raw = z.read(name)
            if len(raw) != identities[name]['bytes'] or hashlib.sha256(raw).hexdigest() != identities[name]['sha256']:
                raise ValueError('PARENT_MEMBER_IDENTITY')
            loaded[name] = json.loads(raw)
    row, audit = loaded[member], loaded[audit_member]
    if (audit['status'] != 'PASS' or field not in audit['eligible_instance_ids'] or
            audit['frozen_files_sha256'] != protocol['source']['source_frozen_files_sha256']):
        raise ValueError('SOURCE_NOT_INDEPENDENTLY_VERIFIED')
    if (row['instance_id'] != field or row['objective'] != 'G_E' or
            row['n'] != 12 or row['Q'] != 5 or row['K'] != 3 or
            row['status'] != 'PROCESS_SUCCESS_UNREVIEWED' or
            row['frozen_files_sha256'] != protocol['source']['source_frozen_files_sha256'] or
            len(row['local_routes']) != 1573):
        raise ValueError('SOURCE_MODEL_OR_TABLE_IDENTITY')
    identity = {'parent_archive_sha256': protocol['source']['archive_sha256'],
                'parent_member': member, 'parent_member_sha256': identities[member]['sha256'],
                'parent_audit_sha256': identities[audit_member]['sha256'],
                'local_table_canonical_json_sha256': hashlib.sha256(json.dumps(row['local_routes'], sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
                'derivation': 'Inherited complete local G minima and frozen (G,E,Rcode) witnesses; no new local optimization'}
    return row['local_routes'], identity
