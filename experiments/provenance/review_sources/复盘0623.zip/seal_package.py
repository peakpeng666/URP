import datetime,hashlib,json,pathlib,zipfile
S=pathlib.Path('/workspace/shared');B=S/'urp_history_review_addendum_20261009T0623Z'
def h(b):return hashlib.sha256(b).hexdigest()
def ident(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':h(b)}
def put(name,d):
 (B/name).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
a=json.loads((B/'SAVED_EVIDENCE_RECHECK.json').read_text());b=json.loads((B/'PORTABLE_REPLAY.json').read_text())
assert a['status']==b['status']=='PASS_SAVED_EVIDENCE_RECHECK'
assert a['balance']==b['balance'] and a['mature']==b['mature'] and a['source_files_read']==b['source_files_read']
selected=json.loads((B/'SELECTED_SOURCE_MANIFEST.json').read_text())['files']
for rel,x in selected.items():
 p=B/'evidence'/rel;v=ident(p);assert v['bytes']==x['bytes'] and v['sha256']==x['sha256'],rel
 p=S/rel;v=ident(p);assert v['bytes']==x['bytes'] and v['sha256']==x['sha256'],rel
# Check only the protected prior deliverables, not a broad history scan.
protected=[];o=S/'urp_history_review_20261009'
for rel,x in json.loads((o/'DELIVERY_MANIFEST.json').read_text())['files'].items():
 v=ident(o/'deliverables'/rel);assert v['bytes']==x['bytes']and v['sha256']==x['sha256'];protected.append(v)
x=json.loads((o/'PACKAGE_RECEIPT.json').read_text());v=ident(pathlib.Path(x['path']));assert v['bytes']==x['bytes']and v['sha256']==x['sha256'];protected.append(v)
old=[
('urp_history_review_addendum_20261009T0350Z/URP历史复盘增补_截至20261009T0350Z.txt','924dd04a4bf044d1af14e55f59faf20134925682f51648b9527e976987443396'),
('URP历史复盘增补_截至20261009T0350Z_小证据包.zip','a69ed0aae67a450e4d897ecf51bf322783a3745f46697b0856a48a09ea4d12a9'),
('urp_history_review_addendum_20261009T0502Z/URP历史复盘增补_截至20261009T0502Z.txt','92ed8ece13a3cd4a64ca2baa7a31ac7ba044d95f3e028110772b7f7eb7e92cf0'),
('URP历史复盘增补_截至20261009T0502Z_小证据包.zip','738a01f15d74c416a8da714b25497810e4b8288a201dcfa6209c03bbb1806d8a'),
('urp_history_review_addendum_20261009T0545Z/URP历史复盘短增补_截至20261009T0545Z.txt','dff036b5d5a5250f8725ad998b1c6c45004786d6d54a4ffb97b71e801e1b6c0a'),
('URP历史复盘短增补_截至20261009T0545Z_小证据包.zip','13a4e808e5030340cef15de3d443ee899c2a413903815e27be6c5c4f0e6bfd93')]
for rel,sha in old:
 v=ident(S/rel);assert v['sha256']==sha,rel;protected.append(v)
assert len(protected)==13
put('SOURCE_PRESERVATION.json',{'checked_utc':now,'protected_versions_cutoff_utc':['2026-10-09T02:25:00Z','2026-10-09T03:50:00Z','2026-10-09T05:02:00Z','2026-10-09T05:45:00Z'],'protected_deliverables':protected,'mismatches':[],'selected_source_count':len(selected),'selected_sources_and_copies_match':True,'original_309_and_1341_frozen_members_match':True,'old_cloud_handoff_indexes_read_or_written':False,'old_files_written':False,'full_history_rescanned':False})
put('增补更新条目.json',{'result_cutoff_utc':'2026-10-09T06:23:00Z','review_prepared_utc':now,'base_previous_cutoff_utc':'2026-10-09T05:45:00Z','stage_count_is_not_experiment_count':True,'added_global_independent_experiment_count':None,'new_studies':[
{'id':'route_balance_tradeoff_20261009','changed_conclusion':'同12田的总距优先与最长路线优先目标存在严格端点权衡，不能由总距改善推出最长距离改善。','direct_evidence':a['balance'],'scope':'同NL12、12客户、Q5、K≤3、冻结G毫米整数代理；48个分组目标调用分属主24和独24，0新局部TSP。','open_gaps':['完整Pareto前沿未求','最长距离不是工期','跨田跨任务泛化与实车约束未证']},
{'id':'mature_field_exact_gap_20261009','changed_conclusion':'该成熟默认配置在冻结小例仍有120/144可行、24超载及自身目标差距；60/72完整预算对25→250无自身成本改善。','direct_evidence':{'cells':a['mature']['cells'],'feasible':120,'failed':24,'paired_valid':60,'planned_pairs':72,'positive_own_gap_fields':['nl_field_67'],'example_E':a['mature']['example_E'],'example_G_same_seed':a['mature']['example_G_same_seed'],'toys':a['mature']['toy_records']},'scope':'主144新进程调用、两次25轮toy另列，E/G×25/250×同12田×3seed；不代表144独立实例。','open_gaps':['失败原因未定位；罚项尺度只是假设','运行时PM没有观测','自身gap与有符号跨目标偏移不可混同','全面板cost/gap为null','广泛强基线优势未证']}], 'pending_not_results':['完整前沿','单位尺度干预']})
(B/'README.txt').write_text('URP历史复盘06:23短增补，可复查证据包\n\n结果截止：2026-10-09 06:23 UTC。复核与交付发生时间另见各JSON，不挪动结果截止。\n\n正文：URP历史复盘短增补_截至20261009T0623Z.txt\n结构化变化：增补更新条目.json\n原源文件复核：SAVED_EVIDENCE_RECHECK.json\n本包可搬移复核：PORTABLE_REPLAY.json\n448份选定原件：evidence/，原路径与hash见SELECTED_SOURCE_MANIFEST.json。\n两原终审档身份和既有私有回读：FINAL_SOURCE_IDENTITIES.json。\n旧四版13个交付件保留检查：SOURCE_PRESERVATION.json。\n\n在解压根目录执行：\npython audit_saved_addendum.py --source-root evidence --skip-complete-freeze --out replay.json\n\n该命令只读取保存矩阵、路线、端点、轨迹与日志，输出新的JSON；不导入求解器，不构造native模型，不枚举优化候选，不联网。只需Python标准库。科学部分应与PORTABLE_REPLAY.json的balance和mature完全一致；utc会变化。\n\n完整冻结清单原309/1341成员的hash检查在原实验目录上完成；精选包只含本轮复核所需文件，所以可搬移命令明确跳过完整冻结目录检查。包中保存一份共同父CAPACITY_FINAL.zip用于精确参照和局部路线见证；原封保留，不重新执行。端点全局完备性依赖已执行且独审的原分组算法，本包只复算保存方案及主独一致性。\n\nreviewer_development/保留本次只读检查器的toy预算假设纠正记录，它不是新增实验，也没有修改原实验。\n\n本次没有扫描全库，没有改变旧正文或交接索引，没有上传；待root审阅通过后由唯一归档员私有上传及实际字节回读。\n')
put('QA_FINAL.json',{'status':'READY_FOR_ROOT_REVIEW','utc':now,'cutoff_utc':'2026-10-09T06:23:00Z','report_read_in_full':True,'portable_scientific_sections_equal_original_recheck':True,'selected_source_files':len(selected),'selected_source_bytes':sum(x['bytes']for x in selected.values()),'selected_source_hashes_match':True,'protected_prior_deliverables':13,'protected_prior_hashes_match':True,'new_solver_calls':0,'new_native_reconstructions':0,'new_local_TSP_calls':0,'new_geometry_calls':0,'new_remote_downloads':0,'uploads':0,'pending_studies_excluded':True,'all_failure_denominators_retained':True,'toy_authoritative_budget_each':25,'toy_calls':2})
manifest={}
for p in sorted(B.rglob('*')):
 if p.is_file()and p.name!='PACKAGE_MANIFEST.json':
  v=ident(p);manifest[str(p.relative_to(B))]={'bytes':v['bytes'],'sha256':v['sha256']}
put('PACKAGE_MANIFEST.json',{'utc':now,'scope':'06:23 short historical addendum; selected saved evidence only','files':manifest})
zp=S/'URP历史复盘短增补_截至20261009T0623Z_小证据包.zip'
with zipfile.ZipFile(zp,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(B.rglob('*')):
  if p.is_file():z.write(p,str(p.relative_to(B)))
with zipfile.ZipFile(zp)as z:
 assert z.testzip()is None
 assert len(z.namelist())==len(manifest)+1
 for rel,x in manifest.items():
  c=z.read(rel);assert len(c)==x['bytes']and h(c)==x['sha256']
 count=len(z.namelist())
report=B/'URP历史复盘短增补_截至20261009T0623Z.txt'
receipt={'status':'READY_FOR_ROOT_REVIEW_NOT_UPLOADED','result_cutoff_utc':'2026-10-09T06:23:00Z','prepared_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'report':ident(report),'evidence_zip':{**ident(zp),'members':count,'manifest_items':len(manifest),'CRC_and_all_manifest_hashes_pass':True},'prior_versions_preserved':True,'archive_owner':'archive_morning_research_results','private_upload_requires_root_review':True}
rp=S/'URP历史复盘短增补_截至20261009T0623Z_交付回执.json';rp.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');print(json.dumps(receipt,ensure_ascii=False,indent=2))
