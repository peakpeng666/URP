"""Read-only saved-route/endpoint/gap checks. No solver, native construction or optimization.
python audit_saved_addendum.py --source-root /workspace/shared --out RECHECK.json
Portable snapshots add --skip-complete-freeze.
"""
import argparse,collections,datetime,hashlib,io,json,pathlib,statistics,zipfile
p=argparse.ArgumentParser();p.add_argument('--source-root',type=pathlib.Path,required=True);p.add_argument('--out',type=pathlib.Path,required=True);p.add_argument('--skip-complete-freeze',action='store_true');a=p.parse_args();S=a.source_root;B=S/'route_balance_tradeoff_20261009';M=S/'mature_field_exact_gap_20261009';seen={};cutoff='2026-10-09T06:23:00+00:00'
def H(b):return hashlib.sha256(b).hexdigest()
def R(p):
 p=pathlib.Path(p);b=p.read_bytes();seen[str(p.relative_to(S))]={'bytes':len(b),'sha256':H(b)};return b
def J(p):return json.loads(R(p))
def JL(p):return [json.loads(x)for x in R(p).splitlines()]
def CK(c,m):
 if not c:raise ValueError(m)
def L(root,p):
 p=pathlib.Path(p);return S/p.relative_to('/workspace/shared')if p.is_absolute()else root/p
def records(root,rel,n):
 rr=JL(root/rel);CK(len(rr)==n,'slot count');ids=[]
 for r in rr:
  ids.append(r.get('call_id',r['schedule']['call_id']));CK(r['process_spawned']and r['child_reaped']and r['returncode']==0,'process');CK(H(R(L(root,r['stdout'])))==r['stdout_sha256']and H(R(L(root,r['stderr'])))==r['stderr_sha256'],'raw bytes')
  if r.get('finished_utc'):CK(datetime.datetime.fromisoformat(r['finished_utc'])<=datetime.datetime.fromisoformat(cutoff),'late result')
 CK(len(set(ids))==n,'duplicate slots');return rr
res={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'result_cutoff_utc':cutoff,'new_solver_calls':0,'new_native_constructions':0,'new_local_TSP':0,'limitations':['No new optimization or formal optimality certificate','No geometry shortest-path/Decimal80 re-evaluation','No runtime PM observation inferred from absence; penalty discussion remains source-derived','Exact endpoint completeness relies on preserved independent exact computations, not this saved recheck']}
fc=[]
for root in(B,M):
 m=J(root/'freeze/FROZEN_FILES.json');bad=[]
 if not a.skip_complete_freeze:
  for rel,x in m['files'].items():
   b=(root/rel).read_bytes()
   if H(b)!=x['sha256']or len(b)!=x['bytes']:bad.append(rel)
  CK(not bad,'frozen changed')
 f=J(root/'raw/FINISHED.json');CK(datetime.datetime.fromisoformat(f['utc'])<=datetime.datetime.fromisoformat(cutoff),'batch cutoff');fc.append({'project':root.name,'members':len(m['files']),'full_hash_check':not a.skip_complete_freeze,'mismatches':bad,'formal_finished_utc':f['utc']})
res['frozen_checks']=fc
# One pinned ancestor archive provides frozen E/G matrices and exact reference/local witnesses.
proto=J(B/'freeze/PROTOCOL.json');zbytes=R(B/'input/CAPACITY_FINAL.zip');CK(H(zbytes)==proto['source']['archive_sha256'],'parent hash');z=zipfile.ZipFile(io.BytesIO(zbytes));parent={};refs={}
for name in proto['fields']:
 eg=json.loads(z.read(f'raw/calls/{name}_E_G.stdout'));ge=json.loads(z.read(f'raw/calls/{name}_G_E.stdout'));parent[name]=ge;refs[name]={'E_star':eg['E'],'G_star':ge['G'],'Elex_G':eg['G'],'Elex_E':eg['E'],'matrices':ge['input_matrices']}
# All48 saved endpoint solutions, values and inherited local route identity.
main=records(B,'raw/results.jsonl',24);ind=records(B,'independent_supervision/raw/results.jsonl',24);iby={r['schedule']['call_id']:r for r in ind};out={}
for r in main:
 s=r['schedule'];name=s['instance_id'];o=J(L(B,r['stdout']));v=J(L(B,iby[s['call_id']]['stdout']));local={tuple(q['customers']):q for q in parent[name]['local_routes']};mat=refs[name]['matrices']['G']
 for q in(o,v):
  CK(q['n']==12 and q['Q']==5 and q['K']==3 and len(q['routes'])==3,'endpoint model');covered=[];costs=[]
  for group,route in zip(q['partition'],q['routes']):
   CK(route==local[tuple(group)]['route']and sorted(route[1:-1])==group and 2<=len(group)<=5,'inherited local witness');covered+=group;costs.append(sum(mat[u][w]for u,w in zip(route,route[1:])))
  CK(sorted(covered)==list(range(1,13))and costs==q['route_G_mm'],'endpoint coverage cost');CK((sum(costs),max(costs))==(q['sum_G_mm'],q['max_route_G_mm']),'endpoint sum max')
 CK(all(o[k]==v[k]for k in('sum_G_mm','max_route_G_mm','partition','routes','route_G_mm')),'independent endpoints');CK(o['counters']['new_local_tsp_evaluations']==v['counters']['additional_local_TSP_calls']==0,'no new local TSP');CK(o['counters']['canonical_partition_coverage_sha256']==v['counters']['canonical_partition_coverage_sha256'],'saved coverage hash');out[(name,s['objective'])]=o
bs=J(B/'reports/SUMMARY.json');br=[]
for f in bs['fields']:
 name=f['instance_id'];u=out[(name,'SUM_MAX')];v=out[(name,'MAX_SUM')];ds=v['sum_G_mm']-u['sum_G_mm'];dm=u['max_route_G_mm']-v['max_route_G_mm'];CK(ds>0 and dm>0 and(ds,dm)==(f['delta_sum_G_mm'],f['reduction_max_route_G_mm']),'strict endpoint tradeoff');CK(u['sum_G_mm']==refs[name]['G_star'],'sum endpoint equals parent G optimum');br.append({'instance_id':name,'sum_first_total':u['sum_G_mm'],'sum_first_max':u['max_route_G_mm'],'max_first_total':v['sum_G_mm'],'max_first_max':v['max_route_G_mm'],'extra_total_mm':ds,'longest_reduction_mm':dm})
CK(len(br)==12,'fields12');res['balance']={'planned_fields':12,'main_outputs':24,'independent_outputs':24,'saved_route_sets_rescored':48,'strict_tradeoff':12,'new_local_TSP':0,'mean_extra_total_mm':statistics.mean(r['extra_total_mm']for r in br),'mean_longest_reduction_mm':statistics.mean(r['longest_reduction_mm']for r in br),'median_extra_total_mm':statistics.median(r['extra_total_mm']for r in br),'median_longest_reduction_mm':statistics.median(r['longest_reduction_mm']for r in br),'fields':br}
# Mature144 cold-start results; exact input matrices, route costs and all failure denominators.
mp=J(M/'freeze/PROTOCOL.json');CK(mp['input']['sha256']==H(zbytes),'same Q5 provenance');inputs={name:J(M/'input'/f'{name}.json')for name in mp['fields']}
for name,x in inputs.items():CK(x['matrices']==refs[name]['matrices']and x['demands']==[0]+[1]*12 and x['capacity']==5 and x['K']==3,'mature frozen input')
schedule=J(M/'freeze/SCHEDULE.json');rr=records(M,'raw/results.jsonl',144);CK({r['call_id']for r in rr}=={s['call_id']for s in schedule},'full planned144');rows=[];outputs={};statskeys={'current_cost','candidate_cost','best_cost','current_feas','candidate_feas','best_feas'}
for r in rr:
 s=r['schedule'];name=s['instance_id'];proxy=s['proxy'];budget=s['max_iterations'];x=inputs[name];o=J(M/r['stdout']);mat=x['matrices'];CK(o['solver_calls']==o['model_instances']==1 and o['explicit_solution_constructions']==0,'observed call counters');CK(o['native_distance_matrix']==mat[proxy]and o['native_matrix_entries_checked']==169,'all169native matrix entries');CK(o['model_matrix_sha256']==H(json.dumps(mat[proxy],separators=(',',':')).encode()),'matrix hash');model=o['native_model_parameters'];CK([[v['x'],v['y']]for v in model['locations']]==x['coordinates'],'native coordinates');CK([c['location']for c in model['clients']]==list(range(1,13))and all(c['delivery']==[1]and c['pickup']==[0]and c['required']for c in model['clients']),'client mapping');CK(model['vehicle']['capacity']==[5]and model['vehicle']['num_available']==3 and model['num_vehicles']==3,'model QK');CK(model['duration_matrix_all_zero']and model['vehicle']['fixed_cost']==0 and model['vehicle']['unit_distance_cost']==1,'pure distance');routes=o['routes'];covered=[];loads=[];cost={'E':0,'G':0}
 for rt in routes:
  CK(rt[0]==rt[-1]==0 and all(1<=n<=12 for n in rt[1:-1]),'closed route');covered+=rt[1:-1];loads.append(len(rt)-2)
  for p,m in mat.items():cost[p]+=sum(m[u][v]for u,v in zip(rt,rt[1:]))
 CK(sorted(covered)==list(range(1,13))and len(routes)<=3,'covered complete12');ok=max(loads)<=5;CK(ok==o['solver_is_feasible']and o['solver_is_complete'],'capacity flag');CK(cost[proxy]==o['reported_distance']==o['internal_route_cost']and o['reported_cost']==(cost[proxy]if ok else None),'cost feasible null');CK([[a['node']for a in nr['activities']]for nr in o['native_routes']]==routes,'native route roundtrip');CK(o['num_iterations']==len(o['stats'])==budget and all(set(q)==statskeys for q in o['stats']),'stats length fields');CK('penalty_observation'not in o,'no runtime PM trace');pen=o['default_solve_params']['values']['penalty']['values'];CK(pen['solutions_between_updates']==500 and pen['max_penalty']==100000.0 and pen['min_penalty']==0.1,'default penalty configuration');gap=cost[proxy]-refs[name][proxy+'_star']if ok else None;CK(gap is None or gap>=0,'own objective gap');row={'call_id':r['call_id'],'instance_id':name,'seed':s['seed'],'proxy':proxy,'budget':budget,'feasible':ok,'E':cost['E']if ok else None,'G':cost['G']if ok else None,'own_gap':gap,'exact_hit':ok and gap==0,'total_excess_load':sum(max(0,v-5)for v in loads),'overloaded_routes':sum(v>5 for v in loads),'route_loads':loads,'G_excess_above_Gstar':cost['G']-refs[name]['G_star']if ok else None,'E_cross_offset_from_Elex_G':cost['G']-refs[name]['Elex_G']if ok and proxy=='E'else None};rows.append(row);outputs[(name,s['seed'],proxy,budget)]=(o,row)
sm=J(M/'reports/SUMMARY.json');reported={r['call_id']:r for r in sm['rows']}
for r in rows:
 q=reported[r['call_id']];CK(q['valid']==r['feasible']and q['own_gap_mm']==r['own_gap']and q['E']==r['E']and q['G']==r['G'],'report row')
cells=[]
for cell in sm['cells']:
 proxy,budget=cell['proxy'],cell['max_iterations'];allr=[r for r in rows if r['proxy']==proxy and r['budget']==budget];valid=[r for r in allr if r['feasible']];hits=sum(r['exact_hit']for r in allr);mean=statistics.mean(r['own_gap']for r in valid);CK(len(allr)==36 and len(valid)==cell['eligible']==30 and hits==cell['exact_hits'],'cell counts');CK(abs(mean-cell['valid_subset_mean_gap_mm'])<1e-9 and cell['complete_panel_mean_gap_mm']is None,'gap mean conditional');cells.append({'proxy':proxy,'budget':budget,'planned':36,'valid':len(valid),'exact_hits':hits,'conditional_gap_mean':mean,'full_gap_mean':None})
pairs=[]
for name in inputs:
 for seed in(0,1,2):
  for proxy in('E','G'):
   a25,r25=outputs[(name,seed,proxy,25)];a250,r250=outputs[(name,seed,proxy,250)];prefix=a25['stats']==a250['stats'][:25];valid=r25['feasible']and r250['feasible'];delta=r25['own_gap']-r250['own_gap']if valid else None;pairs.append({'instance_id':name,'seed':seed,'proxy':proxy,'both_feasible':valid,'own_improvement':delta,'sixfield_prefix_equal':prefix})
CK(sum(r['both_feasible']for r in pairs)==60 and all(r['own_improvement']==0 for r in pairs if r['both_feasible']),'budget60zero');fail=[r for r in rows if not r['feasible']];CK(len(fail)==24 and collections.Counter(r['instance_id']for r in fail)=={'nl_field_1':4,'nl_field_89':8,'nl_field_143':12},'failure denominator');CK(all(r['instance_id']=='nl_field_67'for r in rows if r['own_gap']is not None and r['own_gap']>0),'all positive gaps field67')
example=outputs[('nl_field_67',0,'E',250)][1];gexample=outputs[('nl_field_67',0,'G',250)][1];CK((example['own_gap'],example['E_cross_offset_from_Elex_G'],example['G_excess_above_Gstar'])==(22067,-31965,3356)and example['G']<gexample['G'],'signed cross objective example')
# Actual two toy records, only read output. No fresh native test.
toys=records(M,'selftests/toy/raw/results.jsonl',2);toy=[]
for r in toys:
 o=J(L(M,r['stdout']));CK(o['solver_calls']==o['model_instances']==1,'toy counts');toy.append({'call_id':r['call_id'],'iterations':o['num_iterations'],'solver_calls':1,'model_instances':1,'native_matrix_entries_checked':o['native_matrix_entries_checked']})
CK(sorted(t['iterations']for t in toy)==[2,25],'toy budgets')
res['mature']={'planned':144,'feasible':120,'capacity_failures':24,'native_matrix_entries_rechecked':144*169,'cells':cells,'budget_pairs':72,'both_feasible_budget_pairs':60,'own_improvements_nonzero':0,'budget_pair_rows':pairs,'rows':rows,'failure_rows':fail,'example_E':example,'example_G_same_seed':gexample,'toy_records':toy,'PM_runtime_observed':False}
res['source_files_read']=seen;res['status']='PASS_SAVED_EVIDENCE_RECHECK';a.out.write_text(json.dumps(res,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':res['status'],'frozen_checks':fc,'balance_strict12':True,'mature_feasible':120,'failures':24,'files':len(seen)},ensure_ascii=False))
