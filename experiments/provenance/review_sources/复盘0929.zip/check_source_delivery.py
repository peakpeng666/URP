"""Read already downloaded archives and local receipts; no remote operation."""
import pathlib,json,hashlib,zipfile,datetime
S=pathlib.Path('/workspace/shared');O=pathlib.Path(__file__).resolve().parent
def h(b):return hashlib.sha256(b).hexdigest()
records=[]
for base,receiptname in [('unseen_nl_field_preparation_20261009','FINAL_DRIVE_RECEIPT.json'),('nl124_capacitated_exact_reference_20261009','FINAL_DRIVE_RECEIPT.json'),('mature_unseen_nl_field_execution_20261009','FINAL_REVIEWED_DRIVE_RECEIPT.json')]:
 root=S/base;r=json.loads((root/'provenance'/receiptname).read_text());allrec=[r]+r['report_files'];verified=[]
 for q in allrec:
  b=pathlib.Path(q['source']).read_bytes();d=pathlib.Path(q['download_path']).read_bytes();assert b==d and len(b)==q['bytes']and h(b)==q['sha256'];assert q['owner_only']and not q['shared'];verified.append({'url':q['url'],'bytes':len(b),'sha256':h(b),'actual_readback_utc':q['confirmed_at_utc'],'existing_download_byte_equal':True})
 z=zipfile.ZipFile(r['download_path']);names=z.namelist();assert len(names)==len(set(names));prefix=base+'/' if names[0].startswith(base+'/')else'';frozen=json.loads(z.read(prefix+'freeze/FROZEN_FILES.json'))
 for rel,m in frozen['files'].items():
  b=z.read(prefix+rel);assert len(b)==m['bytes']and h(b)==m['sha256'];assert b==(root/rel).read_bytes()
 checked=0
 if 'PACKAGE_CONTENT_MANIFEST.json'in names:
  mf=json.loads(z.read('PACKAGE_CONTENT_MANIFEST.json'))['files'];assert set(names)==set(mf)|{'PACKAGE_CONTENT_MANIFEST.json'}
  for rel,m in mf.items():
   b=z.read(rel);assert len(b)==m['bytes']and h(b)==m['sha256'];checked+=1
 else:
  # This source ZIP has no whole-package manifest: inspect every saved member
  # against its same local path, plus its frozen and RAW identities.
  for rel in names:
   assert rel.startswith(prefix);assert z.read(rel)==(root/rel[len(prefix):]).read_bytes();checked+=1
  rawmf=json.loads(z.read(prefix+'raw/RAW_UNREVIEWED_MANIFEST.json'))['files']
  for rel,m in rawmf.items():
   b=z.read(prefix+rel);assert len(b)==m['bytes']and h(b)==m['sha256']
  review=json.loads(z.read(prefix+'independent_supervision/results/FINAL_REPORT_REVIEW.json'));assert review['status']=='PASS';assert h(z.read(prefix+'reports/REPORT_ZH.txt'))==review['report_sha256'];assert h(z.read(prefix+'reports/SUMMARY.json'))==review['summary_sha256'];assert h(z.read(prefix+'independent_supervision/results/SAVED_UNSEEN_AUDIT.json'))==review['independent_audit_sha256']
 dest=O/'sources'/base/'provenance'/receiptname;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((root/'provenance'/receiptname).read_bytes())
 records.append({'project':base,'receipt_sha256':h((root/'provenance'/receiptname).read_bytes()),'deliveries':verified,'zip_members':len(names),'members_individually_verified':checked,'verification_mode':'package manifest'if 'PACKAGE_CONTENT_MANIFEST.json'in names else'all archive members versus original local bytes, plus RAW/freeze/final report bindings','frozen_members_checked':len(frozen['files']),'permission_scope':'private status from archived receipt; no new permission query','new_remote_download':False})
q={'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scientific_cutoff_utc':'2026-10-09T09:29:00Z','status':'ALL_THREE_SOURCE_FINALS_ACTUAL_EXISTING_READBACK_VERIFIED','sources':records,'new_remote_operations':0,'native_science_status':'PASS_SAVED_NATIVE_496','addendum_delivery':'pending root review and sole archivist upload'};(O/'SOURCE_DELIVERY_STATUS.json').write_text(json.dumps(q,ensure_ascii=False,indent=2)+'\n');print([(r['project'],r['zip_members'],r['members_individually_verified'])for r in records])
