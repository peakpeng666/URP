"""Historical increment: saved input/exact evidence arithmetic only, no optimization."""
import argparse,collections,datetime,hashlib,json,math,pathlib,statistics
p=argparse.ArgumentParser();p.add_argument('--source-root',type=pathlib.Path,required=True);p.add_argument('--out',type=pathlib.Path,required=True);a=p.parse_args();S=a.source_root;I=S/'unseen_nl_field_preparation_20261009';X=S/'nl124_capacitated_exact_reference_20261009';seen={}
def H(b):return hashlib.sha256(b).hexdigest()
def R(p):
 p=pathlib.Path(p);b=p.read_bytes();seen[str(p.relative_to(S))]={'bytes':len(b),'sha256':H(b)};return b
def J(p):return json.loads(R(p))
def JL(p):return [json.loads(q)for q in R(p).splitlines()]
def L(root,p):
 p=pathlib.Path(p);return S/p.relative_to('/workspace/shared')if p.is_absolute()else root/p
def C(v,m):
 if not v:raise ValueError(m)
panel=J(I/'evidence/PROPOSED_124_PANEL.json');names=[q['id']for q in panel['candidates']];C(len(names)==len(set(names))==124,'panel124');hist=J(I/'evidence/HISTORICAL_PANEL_EXPOSURE.json');old=set(hist['located_historical_field_union']);C(old=={'nl_field_'+str(x)for x in[1,2,7,8,10,11,17,40,44,63,67,89,143,187]},'historical14');C(not set(names)&old,'new-old disjoint');C({x['id']for x in panel['additional_exclusions']}=={'nl_field_10','nl_field_11'},'extra geometry exclusions');ex=J(I/'evidence/NL140_EXCLUSIONS.json');C(ex['nl_count']==140 and ex['candidate_count']==126 and panel['source_candidate_count']==126,'140/126/124');C({'nl_field_22','nl_field_32'}<={r['id']for r in ex['excluded']},'original invalid retained')
binding=J(I/'provenance/FUTURE_ALGORITHM_POLICY_BINDING.json')
for rel,x in binding['files'].items():
 b=R(I/binding['copied_root']/rel);C(len(b)==x['bytes']and H(b)==x['sha256'],'before-input policy bytebind')
policy=J(I/binding['copied_root']/'design/ALGORITHM_POLICY_PREREGISTRATION.json');C(policy['panel_count']==124 and policy['planned_slots']==496 and policy['old_results_in_new_statistics']is False,'new data estimands isolated');C(policy['analysis_commitments']['P_invariant_transfer']['role'].startswith('Conditional'),'conditional prediction policy')
insm=J(I/'reports/SUMMARY.json');C(insm['planned_fields']==insm['input_ready_count']==insm['native_policy_ready_count']==insm['exact_integer_ready_count']==124,'ready124');C(set(insm['eligible_instance_ids'])==set(names),'sameinputpanel');C(insm['optimizer_calls']==insm['native_model_instances']==0,'input no solver');slots=J(I/'raw/ALL_FIELD_SLOTS.json');C(len(slots)==124 and {r['instance_id']for r in slots}==set(names),'inputslots124')
for r in slots:
 e=r['execution'];C(e['returncode']==0 and e['process_spawned']and e['child_reaped'],'input process');C(H(R(L(I,e['stdout'])))==e['stdout_sha256']and H(R(L(I,e['stderr'])))==e['stderr_sha256'],'input ledgerraw')
ins={}
for r in insm['fields']:
 name=r['instance_id'];b=R(I/r['preprocess_path']);C(H(b)==r['preprocess_sha256']and len(b)==r['preprocess_bytes'],'inputpreprocessbyte');v=json.loads(b);C(v['status']=='PASS_PREPROCESS'and v['n']==12 and v['K']==3 and v['capacity']==5 and v['demands']==[0]+[1]*12,'inputmodel');C(len(v['coordinates'])==13 and all(len(ma)==13 and all(len(q)==13 for q in ma)for ma in v['integer_matrices'].values()),'inputdimensions');ins[name]=v
sm=J(X/'reports/SUMMARY.json');C(sm['planned_fields']==sm['verified_fields']==124 and sm['verified_objective_slots']==248,'exactcomplete');C(set(sm['eligible_instance_ids'])==set(names),'sameexactpanel');main=JL(X/'raw/results.jsonl');ind=JL(X/'independent_supervision/raw/results.jsonl');C(len(main)==len(ind)==248,'248each');outputs=[];locals_scored=0;route_sets_scored=0
for rr in(main,ind):
 by={};C(len({r['schedule']['call_id']for r in rr})==248,'uniqueslots')
 for r in rr:
  s=r['schedule'];C(r['returncode']==0 and r['process_spawned']and r['child_reaped'],'exact process');C(H(R(L(X,r['stdout'])))==r['stdout_sha256']and H(R(L(X,r['stderr'])))==r['stderr_sha256'],'exactraw hash');q=J(L(X,r['stdout']));name=s['instance_id'];obj=s['objective'];ma=ins[name]['integer_matrices'];C(q['input_matrices']==ma,'matrix identity');C(q['input_identity']['preprocess_sha256']==H(R(I/'raw/fields'/name/'preprocess.json')),'preprocessbinding');C(q['n']==12 and q['Q']==5 and q['K']==3 and q['objective']==obj,'exactmodel')
  covered=[];sums={'E':0,'G':0};C(len(q['routes'])==len(q['partition'])==3,'three routes')
  for group,route in zip(q['partition'],q['routes']):
   C(route[0]==route[-1]==0 and sorted(route[1:-1])==group and 2<=len(group)<=5,'exact chosen routegroup');covered+=group
   for k,m in ma.items():sums[k]+=sum(m[u][v]for u,v in zip(route,route[1:]))
  C(sorted(covered)==list(range(1,13))and(sums['E'],sums['G'])==(q['E'],q['G']),'global cost coverage');route_sets_scored+=1
  lr=q['local_routes'];C(len(lr)==sum(math.comb(12,k)for k in range(2,6))==1573,'localcount');masks=set()
  for t in lr:
   g=t['customers'];route=t['route'];C(route[0]==route[-1]==0 and sorted(route[1:-1])==g and 2<=len(g)<=5 and len(set(g))==len(g)and all(1<=u<=12 for u in g),'localcoverage');mask=sum(1<<(u-1)for u in g);C(mask==t['mask']and mask not in masks,'localmask');masks.add(mask)
   for k,m in ma.items():C(sum(m[u][v]for u,v in zip(route,route[1:]))==t[k],'saved local cost')
   locals_scored+=1
  if 'scalarization'in q:
   sec='G'if obj=='E_G'else'E';pri='E'if obj=='E_G'else'G';maxsec=max(max(row)for row in ma[sec]);maxpri=max(max(row)for row in ma[pri]);M=15*maxsec+1;C(q['scalarization']['M']==M and q['scalarization']['secondary_total_upper_bound']==15*maxsec,'dynamiclexmultiplier');C(15*maxpri*M+15*maxsec==q['scalarization']['scalar_upper_bound']<2**63,'scalar bound')
  by[(name,obj)]=q
 outputs.append(by)
fields=[]
for name in names:
 for obj in('E_G','G_E'):
  q=outputs[0][(name,obj)];v=outputs[1][(name,obj)];C(all(q[k]==v[k]for k in ['E','G','partition','routes','local_routes']),'saved two implementations equality')
 eg=outputs[0][(name,'E_G')];ge=outputs[0][(name,'G_E')];localge={tuple(r['customers']):r for r in ge['local_routes']};fixed=sum(localge[tuple(g)]['G']for g in eg['partition']);delta=eg['G']-ge['G'];order=eg['G']-fixed;group=fixed-ge['G'];C(delta==order+group and min(delta,order,group)>=0,'nonnegative decomposition');f=next(r for r in sm['fields']if r['instance_id']==name);C((f['delta_integer_mm'],f['order_loss_integer_mm'],f['partition_loss_integer_mm'],f['fixed_partition_G'])==(delta,order,group,fixed),'summarydecomp');fields.append({'instance_id':name,'E_star':eg['E'],'G_star':ge['G'],'G_at_Elex':eg['G'],'fixed_E_partition_G':fixed,'delta_mm':delta,'order_mm':order,'partition_mm':group})
vals=[x['delta_mm']for x in fields];pos=[x for x in fields if x['delta_mm']>0];mx=max(fields,key=lambda x:x['delta_mm']);C(len(pos)==13 and sum(v==0 for v in vals)==111,'13positive111zero');C(statistics.mean(vals)==sm['complete_panel_mean_delta_integer_mm'],'mean');C(mx['instance_id']=='nl_field_42'and(mx['delta_mm'],mx['order_mm'],mx['partition_mm'])==(638238,95953,542285),'maxcase')
res={'status':'PASS_SAVED_INPUT_EXACT_PENDING_NATIVE','review_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'native_results_not_read':True,'new_solver_calls':0,'new_native_reconstructions':0,'new_geometry_or_task_generation':0,'input_fields':124,'input_author_slots':124,'input_independent_slots_in_report':insm['independent_counts'],'exclusions':{'NL':140,'invalid':2,'historical_union':14,'final':124,'additional_geometry_only':['nl_field_10','nl_field_11']},'history_exhaustive':False,'prior_policy_bound_before_input':binding['lock_sha256'],'exact_main_slots':248,'exact_independent_slots':248,'route_sets_rescored':route_sets_scored,'saved_local_routes_rescored':locals_scored,'verified_fields':124,'positive_delta_fields':13,'zero_delta_fields':111,'mean_delta_mm':statistics.mean(vals),'median_delta_mm':statistics.median(vals),'sum_delta_mm':sum(vals),'max_case':mx,'largest_case_share_of_total_delta':mx['delta_mm']/sum(vals),'positive_fields':pos,'fields':fields,'source_files_read':seen,'limitations':['No new projection/clearance/graph/shortest-path/task generation','No optimization; all local/global routes are supplied saved witnesses','Two original exact algorithms and saved local equality reused; global or local optimality not recomputed by new search','Source-only exposure not exhaustive335ZIP unseen proof','Native496 ongoing is separate; no partial outcomes read or scored','Runtime overlap of read-only evidence processing cannot support machine-idle or speed claims']}
a.out.write_text(json.dumps(res,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:res[k]for k in['status','route_sets_rescored','saved_local_routes_rescored','positive_delta_fields','zero_delta_fields','mean_delta_mm','median_delta_mm','max_case','largest_case_share_of_total_delta']},ensure_ascii=False))
