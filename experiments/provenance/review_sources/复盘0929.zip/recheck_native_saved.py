"""Read saved native outputs only: integer arithmetic, no imports from experiment code."""
import argparse,pathlib,json,hashlib,datetime,statistics,collections
ap=argparse.ArgumentParser();ap.add_argument('--source-root',type=pathlib.Path,required=True);ap.add_argument('--out',type=pathlib.Path,required=True);a=ap.parse_args();S=a.source_root;N=S/'mature_unseen_nl_field_execution_20261009';I=S/'unseen_nl_field_preparation_20261009';X=S/'nl124_capacitated_exact_reference_20261009';seen={}
def H(b):return hashlib.sha256(b).hexdigest()
def R(p):
 b=p.read_bytes();seen[str(p.relative_to(S))]={'bytes':len(b),'sha256':H(b)};return b
def J(p):return json.loads(R(p))
def C(v,msg):
 if not v:raise ValueError(msg)
def stats(v,den):return {'available':len(v),'planned':den,'missing':den-len(v),'conditional_mean':statistics.mean(v)if v else None,'median':statistics.median(v)if v else None,'min':min(v)if v else None,'max':max(v)if v else None,'complete_panel_mean':statistics.mean(v)if len(v)==den else None}
frozen=J(N/'freeze/FROZEN_FILES.json');C(H(R(N/'freeze/FROZEN_FILES.json'))=='15a2fb84d569e013812bfb5b3e050ed59540ed8a30b8802aecda9776cc29d373','native PREEXEC identity')
for rel,meta in frozen['files'].items():
 b=R(N/rel);C(H(b)==meta['sha256']and len(b)==meta['bytes'],'native frozen source bytes')
led=[json.loads(x)for x in R(N/'raw/results.jsonl').splitlines()];allslots=J(N/'raw/ALL_PLANNED_SLOTS.json');C(len(led)==len(allslots)==496 and led==allslots,'whole ledger496');C(len({r['call_id']for r in led})==496,'unique496');truth={r['instance_id']:r for r in J(X/'reports/SUMMARY.json')['fields']};audit=J(N/'independent_supervision/results/SAVED_UNSEEN_AUDIT.json');ar={r['call_id']:r for r in audit['rows']};rows=[];ins={};obs_count=0;probe_count=0
for record in led:
 s=record['schedule'];name=s['instance_id'];proxy=s['proxy'];arm=s['arm'];C(s['seed']==0 and s['max_iterations']==250 and s['scale']==1 and s['observe_penalties']is True,'fixed schedule');C(record['returncode']==0 and record['process_spawned']and record['child_reaped'],'spawn return reap');C(H(R(N/record['stdout']))==record['stdout_sha256']and H(R(N/record['stderr']))==record['stderr_sha256'],'raw stdout stderr hash');o=J(N/record['stdout'])
 if name not in ins:
  b=R(N/'input'/f'{name}.json');C(b==R(I/'raw/fields'/name/'preprocess.json'),'native same source input');ins[name]=json.loads(b)
 inp=ins[name];ma=inp['integer_matrices'];C(o['native_distance_matrix']==ma[proxy]and o['native_matrix_entries_checked']==169,'native matrix binding');C(o['seed']==0 and o['max_iterations']==o['num_iterations']==250 and o['arm']==arm and o['scale']==1,'returned fixed run');C(o['model_instances']==o['solver_calls']==1 and o['explicit_solution_constructions']==0,'native single call');C(o['denied_io_events']==[]and o['reference_or_history_payload_fields']==[],'IO and reference isolation')
 routes=o['routes'];loads=[len(r)-2 for r in routes];customers=[];scores={k:0 for k in ma};C(1<=len(routes)<=3 and len(o['native_routes'])==len(routes),'native routes at most K')
 for r,nr in zip(routes,o['native_routes']):
  C(r[0]==r[-1]==0 and all(1<=u<=12 for u in r[1:-1]),'closedroute');customers+=r[1:-1];C([ac['node']for ac in nr['activities']]==r and nr['delivery']==[len(r)-2],'native route load')
  for k,m in ma.items():scores[k]+=sum(m[u][v]for u,v in zip(r,r[1:]))
  C(nr['distance']==sum(ma[proxy][u][v]for u,v in zip(r,r[1:]))and nr['is_feasible']==(len(r)-2<=5),'native route scorefeasible')
 C(sorted(customers)==list(range(1,13)),'unique full coverage');feas=max(loads)<=5;C(o['solver_is_complete']is True and o['solver_is_feasible']==feas and o['internal_route_cost']==scores[proxy]and o['reported_distance']==scores[proxy],'final scores');C(o['reported_cost']==(scores[proxy]if feas else None),'infeasible cost null');C(o['reported_duration_cost']==o['reported_fixed_vehicle_cost']==0,'distance objective')
 po=o['penalty_observation'];ss=o['stats'];C(len(ss)==len(po['rows'])==250,'250saved endpoints');ir=po['initial_solution_routes'];C(sorted(u for rr in ir for u in rr[1:-1])==list(range(1,13))and all(rr[0]==rr[-1]==0 for rr in ir),'initial coverage');initial=max(len(rr)-2 for rr in ir)<=5;C(initial==po['initial_solution_feasible'],'initial feasibility');first=0 if initial else next((i+1 for i,st in enumerate(ss)if st['best_feas']),None);C(first==po['first_best_feasible_iteration'],'first best endpoint');C(ss[-1]['best_feas']==feas and (not feas or ss[-1]['best_cost']==scores[proxy]),'final best endpoint')
 params=o['default_solve_params']['values']['penalty']['values'];C(params['solutions_between_updates']==500,'precommitted adaptation interval');P=15*max(max(r)for r in ma[proxy])+1 if arm=='P'else None
 if arm=='P':C(o['derived_penalty']=={'formula':'(n_customers+K)*max_edge+1','n_customers':12,'K':3,'max_edge':(P-1)//15,'U':P-1,'P':P}and o['public_penalty_bounds']=={'min_penalty':float(P),'max_penalty':float(P)},'input-only fixedP')
 else:C(o['derived_penalty']is None and o['public_penalty_bounds']=={'min_penalty':0.1,'max_penalty':100000.0},'defaultA bounds')
 penalty=P if arm=='P'else 0.1+0.5*(100000.0-0.1);expected=[[float(penalty)],float(penalty),float(penalty)];C(po['initial_penalties']==expected,'initial publicPM')
 for j,(st,ob)in enumerate(zip(ss,po['rows']),1):
  C(ob['iteration']==j and ob['best_is_feasible']==st['best_feas'],'endpointalignment');C(ob['observed_post_registration_penalties']==ob['expected_search_penalties_source_derived']==expected,'no PMupdate');obs_count+=1
  for pr in ob['observed_search_evaluator_integer_probes']:
   val=int(penalty*pr['violation']);C(pr['load']==pr['distance']==pr['duration']==val,'public evaluator probe');probe_count+=1
  if arm=='P':C(st['current_feas']and st['best_feas'],'fixedP currentbest invariant observed')
 if arm=='P':C(initial and first==0 and feas,'fixedP initialfinalprediction')
 ref=truth[name];opt=ref['E_star']if proxy=='E'else ref['G_star'];gap=scores[proxy]-opt if feas else None;C(gap is None or gap>=0,'own gap');r={'call_id':s['call_id'],'instance_id':name,'proxy':proxy,'arm':arm,'seed':0,'feasible':feas,'routes':routes,'loads':loads,'diagnostic_E':scores['E'],'diagnostic_G':scores['G'],'E':scores['E']if feas else None,'G':scores['G']if feas else None,'own_gap_mm':gap,'exact_hit':gap==0 if feas else False,'initial_feasible':initial,'first_best_feasible_iteration':first,'current_feasible_all250':all(t['current_feas']for t in ss),'P':P};q=ar[s['call_id']];C(q['valid']==feas and q['base_E']==r['E']and q['base_G']==r['G']and q['own_gap_mm']==gap and q['exact_hit']==(r['exact_hit']if feas else None),'independent audit row agrees');rows.append(r)
C(len(ins)==124 and len(rows)==496,'all124');by={};paired=[]
for proxy in ['E','G']:
 by[proxy]={}
 for arm in ['A','P']:
  rr=[r for r in rows if(r['proxy'],r['arm'])==(proxy,arm)];C(len(rr)==124,'perarmproxy124');ok=[r for r in rr if r['feasible']];by[proxy][arm]={'planned':124,'valid':len(ok),'infeasible':124-len(ok),'exact_hits_all124':sum(r['exact_hit']for r in rr),'initial_feasible':sum(r['initial_feasible']for r in rr),'own_gap_mm':stats([r['own_gap_mm']for r in ok],124),'E_mm':stats([r['E']for r in ok],124),'G_mm':stats([r['G']for r in ok],124),'failures':[r['call_id']for r in rr if not r['feasible']]}
 lookup={(r['instance_id'],r['arm']):r for r in rows if r['proxy']==proxy}
 for name in ins:
  x,y=lookup[(name,'A')],lookup[(name,'P')];both=x['feasible']and y['feasible'];paired.append({'instance_id':name,'proxy':proxy,'common_success':both,'A_feasible':x['feasible'],'P_feasible':y['feasible'],'delta_own_mm':y[proxy]-x[proxy]if both else None,'delta_E_mm':y['E']-x['E']if both else None,'delta_G_mm':y['G']-x['G']if both else None})
 pp=[r for r in paired if r['proxy']==proxy];by[proxy]['pairs']={k:stats([r[k]for r in pp if r['common_success']],124)for k in['delta_own_mm','delta_E_mm','delta_G_mm']}
cross=[r['delta_G_mm']for r in paired if r['proxy']=='E'and r['common_success']];signs={k:sum((v>0 if k=='positive'else v==0 if k=='zero'else v<0)for v in cross)for k in['positive','zero','negative']};C(signs=={'positive':0,'zero':92,'negative':13},'secondary105signs');C(sum(r['feasible']for r in rows if r['arm']=='A')==207 and sum(r['exact_hit']for r in rows if r['arm']=='A')==181,'A207181');C(sum(r['feasible']and r['exact_hit']for r in rows if r['arm']=='P')==248,'P248')
res={'status':'PASS_SAVED_NATIVE_496','review_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'new_solver_calls':0,'new_native_reconstructions':0,'new_exact_computations':0,'native_preexec_freeze_sha256':H(R(N/'freeze/FROZEN_FILES.json')),'native_frozen_files_verified':len(frozen['files']),'planned_and_saved_calls':496,'fields':124,'seed_count':1,'all_endpoint_rows_checked':obs_count,'public_evaluator_probes_checked':probe_count,'by_proxy':by,'E_search_cross_G_P_minus_A':dict(signs,summary=stats(cross,124)),'newly_feasible_after_initialization':[r for r in rows if r['feasible']and not r['initial_feasible']],'rows':rows,'paired_rows':paired,'source_files_read':seen,'limits':['No new native model, optimization, or geometry. Score and saved endpoints checked only.','Current feasibility is a saved stats boolean; full intermediate routes absent.','P invariant is registered conditional prediction; own exact hits remain empirical single seed.','Common success pair metrics have null whole panel means if any missing.','No walltime or operation count advantage inference.']}
a.out.write_text(json.dumps(res,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:res[k]for k in ['status','native_frozen_files_verified','all_endpoint_rows_checked','public_evaluator_probes_checked','E_search_cross_G_P_minus_A','newly_feasible_after_initialization']},ensure_ascii=False))
