"""Exact bounded-capacity route enumeration. Pure optimizer; no file IO or live calls."""
import itertools


def validate(E, G, Q, K):
    n = len(E) - 1
    if not (1 <= n <= 12 and 1 <= Q <= 5 and 1 <= K <= 3 and K <= n <= K * Q):
        raise ValueError('UNSUPPORTED_MODEL')
    for matrix in (E, G):
        if len(matrix) != n + 1 or any(len(row) != n + 1 for row in matrix):
            raise ValueError('MATRIX_DIMENSIONS')
        for i, row in enumerate(matrix):
            for j, value in enumerate(row):
                if type(value) is not int or value < 0 or value != matrix[j][i] or (i == j and value):
                    raise ValueError('INVALID_INTEGER_SYMMETRIC_MATRIX')
    return n


def objective_key(E, G, objective):
    if objective == 'E_G':
        return E, G
    if objective == 'G_E':
        return G, E
    raise ValueError('UNKNOWN_OBJECTIVE')


def solve(E, G, Q, K, objective):
    n = validate(E, G, Q, K)
    objective_key(0, 0, objective)
    minimum_size = max(1, n - (K - 1) * Q)
    local = {}
    route_evaluations = 0
    for size in range(minimum_size, min(Q, n) + 1):
        for customers in itertools.combinations(range(1, n + 1), size):
            mask = sum(1 << (x - 1) for x in customers)
            best = None
            for order in itertools.permutations(customers):
                if size > 1 and order[0] > order[-1]:
                    continue
                route = (0,) + order + (0,)
                ev = sum(E[a][b] for a, b in zip(route, route[1:]))
                gv = sum(G[a][b] for a, b in zip(route, route[1:]))
                key = objective_key(ev, gv, objective) + (order,)
                route_evaluations += 1
                if best is None or key < best[0]:
                    best = key, ev, gv, route
            local[mask] = {'mask': mask, 'customers': list(customers), 'route': list(best[3]), 'E': best[1], 'G': best[2]}

    def partitions(remaining, groups):
        if groups == 1:
            if minimum_size <= len(remaining) <= Q:
                yield (tuple(remaining),)
            return
        anchor, tail = remaining[0], remaining[1:]
        low = max(minimum_size, len(remaining) - (groups - 1) * Q)
        high = min(Q, len(remaining) - (groups - 1) * minimum_size)
        for size in range(low, high + 1):
            for other in itertools.combinations(tail, size - 1):
                group = (anchor,) + other
                members = set(group)
                rest = tuple(x for x in remaining if x not in members)
                for suffix in partitions(rest, groups - 1):
                    yield (group,) + suffix

    best = None
    partition_evaluations = 0
    size_counts = {}
    for partition in partitions(tuple(range(1, n + 1)), K):
        rows = [local[sum(1 << (x - 1) for x in group)] for group in partition]
        ev, gv = sum(row['E'] for row in rows), sum(row['G'] for row in rows)
        route_code = tuple(tuple(row['route'][1:-1]) for row in rows)
        key = objective_key(ev, gv, objective) + (partition, route_code)
        partition_evaluations += 1
        sizes = ','.join(map(str, sorted(map(len, partition))))
        size_counts[sizes] = size_counts.get(sizes, 0) + 1
        if best is None or key < best[0]:
            best = key, ev, gv, partition, rows
    if best is None:
        raise ValueError('NO_FEASIBLE_PARTITION')
    return {'objective': objective, 'n': n, 'Q': Q, 'K': K, 'E': best[1], 'G': best[2],
            'partition': [list(group) for group in best[3]], 'routes': [row['route'] for row in best[4]],
            'local_routes': [local[mask] for mask in sorted(local)],
            'counters': {'local_subsets': len(local), 'local_route_evaluations': route_evaluations,
                         'unlabeled_partition_evaluations': partition_evaluations, 'partition_size_counts': size_counts}}
