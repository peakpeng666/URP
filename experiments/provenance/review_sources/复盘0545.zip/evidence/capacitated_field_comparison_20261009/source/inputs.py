"""Formal input reader. Copies frozen integer entries only; never rebuilds geometry."""
import hashlib, json, zipfile
from common import ROOT, read, sha


def load_input(field):
    protocol = read(ROOT / 'freeze/PROTOCOL.json')
    if field not in protocol['fields']:
        raise ValueError('UNSCHEDULED_FIELD')
    archive = ROOT / protocol['costs']['source_archive']
    archive_sha = sha(archive)
    if archive_sha != protocol['costs']['source_archive_sha256']:
        raise ValueError('PARENT_ARCHIVE_IDENTITY')
    identities = read(ROOT / 'input/PARENT_MEMBER_IDENTITIES.json')['selected_members']
    loaded, file_hashes = {}, {}
    with zipfile.ZipFile(archive) as z:
        for name in ('preprocess.json', 'services.json', 'graph.json'):
            member = 'raw/fields/' + field + '/' + name
            raw = z.read(member)
            digest = hashlib.sha256(raw).hexdigest()
            if digest != identities[member]['sha256'] or len(raw) != identities[member]['bytes']:
                raise ValueError('PARENT_MEMBER_IDENTITY')
            loaded[name] = json.loads(raw)
            file_hashes[member] = digest
    data, services, graph = loaded['preprocess.json'], loaded['services.json'], loaded['graph.json']
    if data['status'] != 'PASS_PREPROCESS' or data['n'] != 20 or services['n'] != 20:
        raise ValueError('SOURCE_PREPROCESS_NOT_PASSED')
    if data['coordinates'] != services['coordinates'] or len(data['coordinates']) != 21:
        raise ValueError('SOURCE_COORDINATE_IDENTITY')
    matrices = data['integer_matrices']
    for key in ('E', 'G'):
        matrix = matrices[key]
        if len(matrix) != 21 or any(len(row) != 21 for row in matrix):
            raise ValueError('SOURCE_MATRIX_DIMENSION')
        for i in range(21):
            for j in range(21):
                value = matrix[i][j]
                if type(value) is not int or not 0 <= value <= 394480 or value != matrix[j][i] or (i == j and value):
                    raise ValueError('SOURCE_MATRIX_VALUE')
    for i in range(13):
        for j in range(13):
            path = data['canonical_paths'][i][j]
            if path[0] != graph['service_node_ids'][i] or path[-1] != graph['service_node_ids'][j]:
                raise ValueError('SOURCE_PATH_ENDPOINT')
            if any(v >= graph['base_count'] for v in path[1:-1]):
                raise ValueError('SOURCE_PATH_TERMINAL_ONLY')
    selected = {key: [row[:13] for row in matrices[key][:13]] for key in ('E', 'G')}
    fingerprint = hashlib.sha256(json.dumps(selected, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    identity = {'parent_archive_sha256': archive_sha, 'members': file_hashes,
                'selected_original_ids': list(range(13)), 'selected_matrix_canonical_json_sha256': fingerprint,
                'derivation': 'Direct integer entry copying, no projection, graph, shortest-path or rounding computation'}
    return selected, identity
