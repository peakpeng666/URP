"""Read saved evidence; no optimization, candidate enumeration, solver imports or network.
Use --source-root /workspace/shared --out RECHECK.json.
Portable selected snapshot adds --skip-complete-freeze.
"""
import argparse,collections,datetime,hashlib,io,json,math,pathlib,statistics,zipfile
p=argparse.ArgumentParser();p.add_argument('--source-root',type=pathlib.Path,required=True);p.add_argument('--out',type=pathlib.Path,required=True);p.add_argument('--skip-complete-freeze',action='store_true');a=p.parse_args();S=a.source_root;C=S/'capacitated_field_comparison_20261009';P=S/'public_route_penalty_adaptation_control_20261009';accessed={};cutoff='2026-10-09T05:45:00+00:00'
def H(b):return hashlib.sha256(b).hexdigest()
def R(p):
 p=pathlib.Path(p);b=p.read_bytes();accessed[str(p.relative_to(S))]={'bytes':len(b),'sha256':H(b)};return b
def J(p):return json.loads(R(p))
def JL(p):return [json.loads(z)for z in R(p).splitlines()]
def CK(c,m):
 if not c:raise ValueError(m)
def loc(root,p):
 p=pathlib.Path(p);return S/p.relative_to('/workspace/shared')if p.is_absolute()else root/p
def outputs(root,rel,count):
 rr=JL(root/rel);CK(len(rr)==count,'planned slots');ids=[]
 for r in rr:
  cid=r.get('call_id',r['schedule']['call_id']);ids.append(cid);CK(r['process_spawned']and r['child_reaped']and r['returncode']==0,'process');CK(H(R(loc(root,r['stdout'])))==r['stdout_sha256']and H(R(loc(root,r['stderr'])))==r['stderr_sha256'],'stdout stderr hash')
  if r.get('finished_utc'):CK(datetime.datetime.fromisoformat(r['finished_utc'])<=datetime.datetime.fromisoformat(cutoff),'cutoff')
 CK(len(set(ids))==count,'duplicate calls');return rr
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'result_cutoff_utc':cutoff,'new_optimizer_calls':0,'new_model_calls':0,'new_native_constructions':0,'scope':'Rescore saved routes, compare saved exact witnesses, recover arithmetic and inspect saved PM traces; no new optimality computation'}
freeze=[]
for root in(C,P):
 m=J(root/'freeze/FROZEN_FILES.json');bad=[]
 if not a.skip_complete_freeze:
  for rel,z in m['files'].items():
   b=(root/rel).read_bytes()
   if H(b)!=z['sha256']or len(b)!=z['bytes']:bad.append(rel)
  CK(not bad,'frozen file change')
 finish=J(root/'raw/FINISHED.json');CK(datetime.datetime.fromisoformat(finish['utc'])<=datetime.datetime.fromisoformat(cutoff),'batch after cutoff');freeze.append({'project':root.name,'members':len(m['files']),'full_hash_check':not a.skip_complete_freeze,'mismatches':bad,'formal_finished_utc':finish['utc']})
result['freeze_checks']=freeze
# Exact capacity branch. Read former matrices from the pinned parent ZIP; only rescore saved witnesses.
proto=J(C/'freeze/PROTOCOL.json');parent=R(C/'input/PARENT_FINAL.zip');CK(H(parent)==proto['costs']['source_archive_sha256'],'parent archive');zmat=zipfile.ZipFile(io.BytesIO(parent));pm={}
for field in proto['fields']:
 b=zmat.read(f'raw/fields/{field}/preprocess.json');x=json.loads(b);pm[field]={k:[r[:13]for r in x['integer_matrices'][k][:13]]for k in('E','G')}
def score(routes,mat,whole=True):
 seen=[];cost={'E':0,'G':0}
 for r in routes:
  CK(r[0]==r[-1]==0 and 2<=len(r)-2<=5 and len(set(r[1:-1]))==len(r)-2,'Q5 route');seen+=r[1:-1]
  for k,M in mat.items():cost[k]+=sum(M[u][v]for u,v in zip(r,r[1:]))
 if whole:CK(len(routes)==3 and sorted(seen)==list(range(1,13)),'3route complete cover')
 return cost
main=outputs(C,'raw/results.jsonl',24);ind=outputs(C,'independent_supervision/raw/results.jsonl',24);ib={r['schedule']['call_id']:r for r in ind};sol={};local_count=0
for r in main:
 s=r['schedule'];cid=s['call_id'];field=s['instance_id'];arm=s['objective'];o=J(loc(C,r['stdout']));v=J(loc(C,ib[cid]['stdout']));mat=pm[field]
 for q in(o,v):
  CK(q['input_matrices']==mat and q['n']==12 and q['Q']==5 and q['K']==3,'exact input');CK(score(q['routes'],mat)=={'E':q['E'],'G':q['G']},'global route costs');CK(sorted(sorted(r[1:-1])for r in q['routes'])==q['partition'],'partition witness');CK(len(q['local_routes'])==1573,'local witnesses');seen=set()
  for z in q['local_routes']:
   CK(z['mask']not in seen,'duplicate mask');seen.add(z['mask']);CK(z['mask']==sum(1<<(i-1)for i in z['customers'])and sorted(z['route'][1:-1])==z['customers'],'local mask');CK(score([z['route']],mat,False)=={'E':z['E'],'G':z['G']},'local route costs');local_count+=1
 CK(all(o[k]==v[k]for k in('E','G','partition','routes')),'global cross-implementation witnesses');L=lambda q:{z['mask']:(z['E'],z['G'],z['route'])for z in q['local_routes']};CK(L(o)==L(v),'local cross-implementation witnesses');CK(v['scalarization']['M']==5917201 and v['scalarization']['scalar_upper_bound']<2**63,'scalar bound');sol[(field,arm)]=o
summary=J(C/'reports/SUMMARY.json');decomp=[]
for z in summary['fields']:
 f=z['instance_id'];eg,ge=sol[(f,'E_G')],sol[(f,'G_E')];lookup={r['mask']:r for r in ge['local_routes']};gfixed=sum(lookup[sum(1<<(i-1)for i in group)]['G']for group in eg['partition']);order=eg['G']-gfixed;group=gfixed-ge['G'];delta=eg['G']-ge['G'];CK(order>=0 and group>=0 and delta==order+group,'nonnegative decomposition');CK((delta,gfixed,order,group)==(z['delta_integer_mm'],z['fixed_selected_partition_G_integer_mm'],z['order_loss_integer_mm'],z['partition_loss_integer_mm']),'reported decomposition');decomp.append({'instance_id':f,'E_star':eg['E'],'G_among_E_star_min':eg['G'],'G_star':ge['G'],'fixed_selected_partition_G':gfixed,'delta':delta,'order_loss':order,'partition_loss':group})
CK(sum(z['delta']>0 for z in decomp)==1,'one conflict');result['capacity']={'fields':12,'main_outputs':24,'independent_outputs':24,'global_route_sets_rescored':48,'saved_local_route_witnesses_rescored':local_count,'saved_local_optimality_rerun':False,'fields_detail':decomp,'mean_delta':statistics.mean(z['delta']for z in decomp),'scope':'Optimum basis inherited from two exact implementations and their reviewed proof; this recheck does not run optimization or enumerate candidate routes/partitions.'}
# Fresh penalty72 outputs. Independent originalVRP integer distance and full matrix digest.
def vrp(p):
 hd={};xy={};dm={};dep=[];sec=None
 for l in R(p).decode().splitlines():
  l=l.strip()
  if not l:continue
  if l=='EOF':break
  if l in('NODE_COORD_SECTION','DEMAND_SECTION','DEPOT_SECTION'):sec=l;continue
  if sec is None:k,v=l.split(':',1);hd[k.strip()]=v.strip()
  elif sec=='NODE_COORD_SECTION':k,x,y=map(int,l.split());xy[k-1]=(x,y)
  elif sec=='DEMAND_SECTION':k,v=map(int,l.split());dm[k-1]=v
  elif int(l)!=-1:dep.append(int(l)-1)
 CK(dep==[0]and hd['EDGE_WEIGHT_TYPE']=='EUC_2D'and set(xy)==set(dm)==set(range(int(hd['DIMENSION']))),'VRP');return xy,dm,int(hd['CAPACITY'])
def edge(u,v):
 q=sum((x-y)**2 for x,y in zip(u,v));s=math.isqrt(q);return s+int(4*q>=(2*s+1)**2)
problems={t['instance_id']:vrp(P/'input'/f"{t['instance_id']}.vrp")for t in J(P/'freeze/TASKS.json')};matrixhash={f:H(json.dumps([[edge(xy[i],xy[j])for j in range(len(xy))]for i in range(len(xy))],separators=(',',':')).encode())for f,(xy,dm,q)in problems.items()}
rr=outputs(P,'raw/results.jsonl',72);outs={};pr=[]
for rec in rr:
 s=rec['schedule'];o=J(P/rec['stdout']);field=s['instance_id'];xy,dm,q=problems[field];routes=o['routes'];seen=[];loads=[];cost=0
 for r in routes:
  CK(r[0]==r[-1]==0 and all(1<=i<len(xy)for i in r[1:-1]),'closed route');seen+=r[1:-1];loads.append(sum(dm[i]for i in r[1:-1]));cost+=sum(edge(xy[i],xy[j])for i,j in zip(r,r[1:]))
 CK(sorted(seen)==list(range(1,len(xy)))and len(routes)<=s['K'],'cover and vehicles');ok=max(loads)<=q;CK(ok==o['solver_is_feasible']and o['solver_is_complete'],'saved feasible');CK(cost==o['reported_distance']==o['internal_route_cost']and o['reported_cost']==(cost if ok else None),'cost');CK(o['model_matrix_sha256']==matrixhash[field]and o['native_model_parameters']['vehicle']['capacity']==[q]and o['native_model_parameters']['num_vehicles']==s['K'],'native model');CK(o['num_iterations']==len(o['stats'])==250 and o['solutions_between_updates']==s['solutions_between_updates'],'budget and intervention');ob=o['penalty_observation'];CK(len(ob['rows'])==250,'observer count');prev=ob['initial_penalties'];changed=[]
 for i,z in enumerate(ob['rows'],1):
  CK(z['iteration']==i and z['expected_search_penalties_source_derived']==prev,'observer source-order binding')
  for probe in z['observed_search_evaluator_integer_probes']:
   v=probe['violation'];CK((probe['load'],probe['duration'],probe['distance'])==tuple(int(v*p)for p in(prev[0][0],prev[1],prev[2])),'integer probes')
  new=z['observed_post_registration_penalties']
  if new!=prev:changed.append(i);CK(i%s['solutions_between_updates']==0,'unexpected penalty change')
  prev=new
 first=next((i for i,z in enumerate(o['stats'],1)if z['best_feas']),None);r={'instance_id':field,'seed':s['seed'],'interval':s['solutions_between_updates'],'feasible':ok,'cost':cost if ok else None,'vehicles':len(routes),'total_excess':sum(max(0,l-q)for l in loads),'first_end_best_feasible_iteration':first,'numeric_penalty_changes':changed};pr.append(r);outs[(field,s['seed'],s['solutions_between_updates'])]=o
hist=J(P/'freeze/HISTORICAL_CELLS.json')['all36'];CK(len(hist)==36,'historical36');rows=[];trans=collections.Counter()
for h in hist:
 field,seed=h['instance_id'],h['seed'];old=J(P/h['output_file']);CK(H(R(P/h['output_file']))==h['stdout_sha256'],'historic hash');u,v=outs[(field,seed,500)],outs[(field,seed,50)];CK(u['stats']==old['stats']and u['routes']==old['routes'],'fresh500 history');CK(u['stats'][:50]==v['stats'][:50],'first50 sixfield prefix');up=json.loads(json.dumps(u['default_solve_params']));vp=json.loads(json.dumps(v['default_solve_params']));CK(up['values']['penalty']['values'].pop('solutions_between_updates')==500 and vp['values']['penalty']['values'].pop('solutions_between_updates')==50 and up==vp,'only parameter leaf');aok,bok=u['solver_is_feasible'],v['solver_is_feasible'];trans[('success'if aok else'failure')+'_'+('success'if bok else'failure')]+=1;row={'instance_id':field,'seed':seed,'p500_feasible':aok,'p50_feasible':bok,'delta_cost':None,'relative_pct':None}
 if aok and bok:row['delta_cost']=v['reported_cost']-u['reported_cost'];row['relative_pct']=100*row['delta_cost']/u['reported_cost']
 rows.append(row)
valid=[z for z in rows if z['delta_cost']is not None];sm=J(P/'reports/SUMMARY.json');mc=statistics.mean(z['delta_cost']for z in valid);mr=statistics.mean(z['relative_pct']for z in valid);CK(len(valid)==33 and abs(mc-sm['overall']['conditional_common_success']['delta_cost']['mean'])<1e-10 and abs(mr-sm['overall']['conditional_common_success']['relative_delta_pct']['mean'])<1e-10,'conditional costs');CK(sm['overall']['complete_primary']['delta_cost']['mean']is None,'fullcostnull');CK(all(trans.get(k,0)==v for k,v in sm['overall']['paired_success_transitions'].items()) and sum(trans.values())==36,'status transitions');recovered=[z for z in pr if z['instance_id']=='X-n524-k153'and z['interval']==50 and z['feasible']];CK(len(recovered)==1 and recovered[0]['seed']==1 and recovered[0]['cost']==157314 and recovered[0]['vehicles']==155 and recovered[0]['first_end_best_feasible_iteration']==90,'recovered endpoint');x524=[]
for seed in(0,1,2):
 ob=outs[('X-n524-k153',seed,50)]['penalty_observation'];CK(ob['rows'][49]['observed_post_registration_penalties'][0]==[75000.075]and ob['rows'][99]['observed_post_registration_penalties'][0]==[100000.0],'X524 penalty checkpoints');x524.append({'seed':seed,'load_penalty_after50':75000.075,'load_penalty_after100':100000.0})
# Synthetic actual8+2attempts, including retained original IO audit failures.
toy=[]
for rel,num in [('selftests/integration/results.jsonl',8),('selftests/warning_recheck/results.jsonl',2)]:
 rs=JL(P/rel);CK(len(rs)==num,'toy denominator')
 for r in rs:
  CK(H(R(P/r['stdout']))==r['stdout_sha256']and H(R(P/r['stderr']))==r['stderr_sha256'],'toy output hashes');o=J(P/r['stdout']);toy.append({'call_id':r['call_id'],'record_status':r['status'],'returncode':r['returncode'],'denied_io_events':o['denied_io_events'],'num_iterations':o['num_iterations']})
CK(sum(z['record_status']=='CALL_ERROR_UNDETERMINED'for z in toy)==2,'retained toy failures');prep=J(P/'selftests/PREPARATION_ACCEPTANCE.json');CK(prep['synthetic_solver_attempts']==10 and prep['initial_warning_io_audit_failed_cells']==2 and prep['recheck_attempts']==2,'toy disclosure')
result['penalty']={'fresh_planned_calls':72,'fresh_valid_p500':sum(z['interval']==500 and z['feasible']for z in pr),'fresh_valid_p50':sum(z['interval']==50 and z['feasible']for z in pr),'paired_transitions':dict(trans),'common_success':33,'conditional_mean_delta_cost':mc,'conditional_mean_relative_pct':mr,'full36_cost_difference':None,'historical_reference_not_primary':36,'fresh_first50_equal_pairs':36,'history_fresh500_equal_pairs':36,'public_observer_rows_verified':18000,'recovered':recovered,'X524_penalty_checkpoints':x524,'rows':pr,'pairs':rows,'toy_attempts':toy,'toy_attempt_count':10,'scope':'Iteration-end best first true is not an internal first-feasibility timestamp; public integer probes do not reconstruct all hidden doubles or registered-candidate windows.'}
result['source_files_read']=accessed;result['status']='PASS_SAVED_EVIDENCE_RECHECK';a.out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':result['status'],'freeze':freeze,'saved_local_witnesses':local_count,'penalty_pairs':len(rows),'toy_attempts':len(toy),'files':len(accessed)},ensure_ascii=False))
