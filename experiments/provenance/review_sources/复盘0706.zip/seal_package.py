import datetime,hashlib,json,pathlib,zipfile
B=pathlib.Path(__file__).resolve().parent;S=B.parent;now=datetime.datetime.now(datetime.timezone.utc).isoformat()
def J(p):return json.loads(p.read_text())
def H(b):return hashlib.sha256(b).hexdigest()
def put(n,d):(B/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def identity(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':H(b)}
f=J(B/'frontier_recheck/RESULT.json');fp=J(B/'frontier_portable/RESULT.json');a=J(B/'scale_recheck/SAVED_SCALE_RECHECK.json');ap=J(B/'scale_recheck/PORTABLE_SCALE_RECHECK.json')
for key in ['checks','fields','by_budget','frontier_sizes','frontier_points','budget_rows','saved_catalog_rows_checked']:assert f[key]==fp[key]
for key in ['arms','pairs','rows','failure_rows','toy_results','source_files_read']:assert a[key]==ap[key]
assert f['status']==fp['status']=='PASS'and a['status']==ap['status']=='PASS_SAVED_SCALE_RECHECK'
source=J(B/'SELECTED_SOURCE_MANIFEST.json')
for rel,x in source['files'].items():
 b=(B/'evidence'/rel).read_bytes();assert len(b)==x['bytes']and H(b)==x['sha256']and b==(S/rel).read_bytes()
protected=J(B/'SOURCE_PRESERVATION.json')['protected_deliverables']
for x in protected:
 b=pathlib.Path(x['path']).read_bytes();assert len(b)==x['bytes']and H(b)==x['sha256']
put('增补更新条目.json',{'result_cutoff_utc':'2026-10-09T07:06:00Z','review_prepared_utc':now,'previous_cutoff_utc':'2026-10-09T06:23:00Z','stage_records_153_not_independent_experiments':True,'new_independent_field_count':0,'updates':[
 {'source':'route_distance_frontier_20261009','old_gap':'Only two exact endpoints; full frontier absent','new_evidence':'Full integer objective-value frontier over the same12 fields,85 points,24 main/independent calls;0new localTSP','frontier_sizes':f['frontier_sizes'],'budget_statistics_all12':f['by_budget'],'changed_conclusion':'Complete fixed-model value-frontier gap closed; small-budget tradeoff now quantified with heterogeneous and zero benefits retained','actual_review_depth':f['independently_checked_now'],'inherited_assumptions':f['not_independently_reestablished_now'],'still_open':['Physical-length frontier membership','Completion-time and real-vehicle constraints','Unseen-field generalization','Supported classification not part of this result']},
 {'source':'mature_field_cost_scale_control_20261009','old_gap':'Scale mechanism untested and runtimePM absent in previous144calls','new_evidence':a['arms'],'actual_review_depth':{'saved_slots':216,'native_matrix_entries':36504,'PM_rows':54000,'probe_scalars':648000,'A_C_pairs':72,'legacy_full250_pairs':72,'toy_calls':4},'changed_conclusion':'Within this panel,10D/default changes feasibility60→4 and jointly scaling penalty bounds restores60; original12 failures persist. New public snapshots show0PM updates and no first-feasible emergence after initialization.','still_open':['Original12failures not attributed to scale alone','Initialization max and ILS midpoint causality inseparable','C not strictly10x homogeneous at public integer probes','Fullpanel costs null; B4valid not wholepanel performance','Unseen-field generalization and broad strong-baseline advantage']}], 'pending_not_results':['supported-frontier classification','capacity-priority policy']})
(B/'README.txt').write_text('URP历史复盘07:06短增补，可复查小证据包\n\n结果截止2026-10-09 07:06 UTC；复核和交付时间单列，不改动原截止。\n正文：URP历史复盘短增补_截至20261009T0706Z.txt\n结构化结论变化：增补更新条目.json\n前沿独立核查：frontier_recheck/RESULT.json及RECHECK_ZH.txt\n尺度独立核查：scale_recheck/SAVED_SCALE_RECHECK.json\n来源身份、冻结hash与既有实际下载字节：SOURCE_IDENTITIES_AND_FREEZE.json\n旧五版15交付件保护：SOURCE_PRESERVATION.json\n541份选定来源原件位于evidence/，清单SELECTED_SOURCE_MANIFEST.json。\n\n在解压根目录可重复以下只读保存证据核查：\npython frontier_recheck/recheck_saved_frontier.py --source-root evidence/route_distance_frontier_20261009 --output-dir replay_frontier\npython scale_recheck/recheck_saved_scale.py --source-root evidence/mature_field_cost_scale_control_20261009 --skip-full-freeze --out replay_scale.json\n\n仅Python标准库。脚本读取保存值、路线、证书和观察记录，不导入求解器、不构造native对象、不生成新分组、不做supported分类、无网络。新生成复核结果的时间/路径可变；科学字段应与frontier_portable/RESULT.json和scale_recheck/PORTABLE_SCALE_RECHECK.json一致。\n\n本轮完整冻结194/591项hash在原目录已核；本精选包没有带入全部冻结成员，故可搬移尺度命令显式跳过全目录冻结hash检查。前沿只检查供给目录的覆盖/证书与算术，继承局部G最优表及逐目录成本来源、原几何仍依赖原独审。尺度保留共同Q5父ZIP读取其精确真值，不执行其中代码。\n\nreviewer_development记录检查器最初中点浮点表达式假设的技术纠正，原实验没有改变，未新增求解。实验阶段的toy失败/准备期修订及正式超载原记录均保留于选定源件或原FINAL。\n\n本包不是全库复盘替代索引，也不是335ZIP原始复算。未上传、未删除、未改旧正文或索引；root审阅后由唯一归档员执行私有归档回读。\n')
put('QA_FINAL.json',{'status':'READY_FOR_ROOT_REVIEW','prepared_utc':now,'result_cutoff_utc':'2026-10-09T07:06:00Z','frontier_saved_and_portable_equal':True,'scale_saved_and_portable_equal':True,'source_files':source['selected_count'],'source_bytes':source['selected_bytes'],'all_selected_bytes_match_originals':True,'prior_five_versions_protected_files':len(protected),'prior_hashes_unchanged':True,'source_frozen_counts':[194,591],'new_solver_calls':0,'new_native_reconstructions':0,'new_candidate_generation':0,'new_supported_classification':0,'new_geometry_calls':0,'new_remote_downloads':0,'uploads':0,'all216_and_all72_query_denominators_retained':True,'cost_fullpanel_null_retained':True,'pending_studies_excluded':True})
manifest={}
for p in sorted(B.rglob('*')):
 if p.is_file()and p.name!='PACKAGE_MANIFEST.json':
  v=identity(p);manifest[str(p.relative_to(B))]={'bytes':v['bytes'],'sha256':v['sha256']}
put('PACKAGE_MANIFEST.json',{'utc':now,'files':manifest})
zp=S/'URP历史复盘短增补_截至20261009T0706Z_小证据包.zip'
with zipfile.ZipFile(zp,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(B.rglob('*')):
  if p.is_file():z.write(p,str(p.relative_to(B)))
with zipfile.ZipFile(zp)as z:
 assert z.testzip()is None and len(z.namelist())==len(manifest)+1
 for rel,x in manifest.items():
  b=z.read(rel);assert len(b)==x['bytes']and H(b)==x['sha256']
receipt={'status':'READY_FOR_ROOT_REVIEW_NOT_UPLOADED','result_cutoff_utc':'2026-10-09T07:06:00Z','prepared_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'report':identity(B/'URP历史复盘短增补_截至20261009T0706Z.txt'),'evidence_zip':{**identity(zp),'members':len(manifest)+1,'manifest_items':len(manifest),'CRC_and_all_manifest_hashes_pass':True},'prior_five_versions_preserved':True,'archive_owner':'archive_morning_research_results','root_review_required':True}
(S/'URP历史复盘短增补_截至20261009T0706Z_交付回执.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');print(json.dumps(receipt,ensure_ascii=False,indent=2))
