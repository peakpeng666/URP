"""Read only saved outputs. No native imports, reconstruction, optimizer or network."""
import argparse,collections,datetime,hashlib,io,json,pathlib,statistics,zipfile
p=argparse.ArgumentParser();p.add_argument('--source-root',type=pathlib.Path,required=True);p.add_argument('--out',type=pathlib.Path,required=True);p.add_argument('--skip-full-freeze',action='store_true');args=p.parse_args();B=args.source_root;seen={}
def H(b):return hashlib.sha256(b).hexdigest()
def R(rel):
 rel=str(rel);v=(B/rel).read_bytes();seen[rel]={'bytes':len(v),'sha256':H(v)};return v
def J(rel):return json.loads(R(rel))
def JL(rel):return [json.loads(q)for q in R(rel).splitlines()]
def C(c,m):
 if not c:raise ValueError(m)
penalty_source=R('source_evidence/installed__PenaltyManager.py');C(b'midpoint = self.min_penalty + (self.max_penalty - self.min_penalty) / 2' in penalty_source,'frozen midpoint expression');R('source_evidence/installed_pyvrp__solve.py');R('source/observer.py');proto=J('freeze/PROTOCOL.json');schedule=J('freeze/SCHEDULE.json');frozen=J('freeze/FROZEN_FILES.json');finished=J('raw/FINISHED.json');C(finished['utc']<'2026-10-09T07:06:00','result cutoff')
frozen_bad=[]
if not args.skip_full_freeze:
 for rel,x in frozen['files'].items():
  b=(B/rel).read_bytes()
  if len(b)!=x['bytes']or H(b)!=x['sha256']:frozen_bad.append(rel)
 C(not frozen_bad,'frozen source changed')
arch=R('input/Q5_FINAL.zip');C(H(arch)==proto['input']['sha256'],'parent exact archive');z=zipfile.ZipFile(io.BytesIO(arch));refs={};inputs={}
for name in proto['fields']:
 x=J('input/'+name+'.json');inputs[name]=x
 eg=json.loads(z.read('raw/calls/'+name+'_E_G.stdout'));ge=json.loads(z.read('raw/calls/'+name+'_G_E.stdout'));C(x['matrices']==ge['input_matrices'],'input parent matrices');refs[name]={'E':eg['E'],'G':ge['G']}
rr=JL('raw/results.jsonl');attempts=JL('raw/attempts.jsonl');C(len(rr)==len(schedule)==216 and {x['call_id']for x in rr}=={x['call_id']for x in schedule},'216 planned slots');C(len({x['call_id']for x in rr})==216,'no duplicate calls')
rows=[];outputs={};skeys={'current_cost','candidate_cost','best_cost','current_feas','candidate_feas','best_feas'};pmrows=0
for r in rr:
 s=r['schedule'];ident=s['call_id'];name=s['instance_id'];arm=s['arm'];proxy=s['proxy'];scale=s['scale'];x=inputs[name]
 C(r['returncode']==0 and r['process_spawned']and r['child_reaped'],'process success')
 C(H(R(r['stdout']))==r['stdout_sha256']and H(R(r['stderr']))==r['stderr_sha256'],'output hashes');o=J(r['stdout']);outputs[(name,s['seed'],proxy,arm)]=o
 C(o['model_instances']==o['solver_calls']==1 and o['explicit_solution_constructions']==0,'counters')
 C(o['num_iterations']==len(o['stats'])==250 and all(set(t)==skeys for t in o['stats']),'250 sixfield rows')
 C(o['scale']==scale and o['arm']==arm and o['seed']==s['seed']and o['observe_penalties'],'arm settings')
 matrix=[[v*scale for v in q]for q in x['matrices'][proxy]];C(matrix==o['native_distance_matrix'] and o['native_matrix_entries_checked']==169,'169 native matrix entries')
 C(H(json.dumps(matrix,separators=(',',':')).encode())==o['model_matrix_sha256'],'matrix hash')
 m=o['native_model_parameters'];C([[v['x'],v['y']]for v in m['locations']]==x['coordinates'],'coordinates')
 C(m['num_clients']==12 and m['num_vehicles']==3 and m['vehicle']['capacity']==[5]and m['vehicle']['num_available']==3,'native model QK')
 C([c['location']for c in m['clients']]==list(range(1,13)) and all(c['delivery']==[1]and c['pickup']==[0]and c['required']for c in m['clients']),'client mapping')
 C(m['duration_matrix_all_zero']and m['vehicle']['fixed_cost']==0 and m['vehicle']['unit_distance_cost']==1 and m['vehicle']['unit_duration_cost']==0,'pure distance model')
 routes=o['routes'];nodes=[];loads=[];cost={'E':0,'G':0}
 for route in routes:
  C(route[0]==route[-1]==0 and all(1<=v<=12 for v in route[1:-1]),'closed route');nodes+=route[1:-1];loads.append(len(route)-2)
  for key,mat in x['matrices'].items():cost[key]+=sum(mat[u][v]for u,v in zip(route,route[1:]))
 C(sorted(nodes)==list(range(1,13))and len(routes)<=3,'complete coverage');ok=max(loads)<=5;C(o['solver_is_complete']and ok==o['solver_is_feasible'],'feasible status')
 C(cost[proxy]*scale==o['reported_distance']==o['internal_route_cost'],'scaled route cost');C(o['reported_cost']==(cost[proxy]*scale if ok else None),'failure null cost')
 C([[t['node']for t in q['activities']]for q in o['native_routes']]==routes,'native route identity')
 pen=o['default_solve_params']['values']['penalty']['values'];C(pen['min_penalty']==s['min_penalty']and pen['max_penalty']==s['max_penalty']and pen['solutions_between_updates']==500,'min max settings')
 obs=o['penalty_observation'];C(obs is not None,'PM directly observed');mid=s['min_penalty']+(s['max_penalty']-s['min_penalty'])/2;ps=[[mid],mid,mid];C(obs['initial_penalties']==ps,'initial public snapshot')
 ir=obs['initial_solution_routes'];C(sorted(v for q in ir for v in q[1:-1])==list(range(1,13))and all(q[0]==q[-1]==0 for q in ir),'initial coverage');init_ok=max(len(q)-2 for q in ir)<=5;C(obs['initial_solution_feasible']==init_ok,'initial feasible independently checked')
 C(len(obs['rows'])==250,'250 observer rows');first=0 if init_ok else next((q['iteration']for q in obs['rows']if q['best_is_feasible']),None);C(first==obs['first_best_feasible_iteration'],'first best feasible')
 prev=ps;changes=0
 expected=[{'violation':v,'load':int(mid*v),'duration':int(mid*v),'distance':int(mid*v)}for v in(1,2,7,1000)]
 for i,q in enumerate(obs['rows'],1):
  C(q['iteration']==i and q['best_is_feasible']==o['stats'][i-1]['best_feas'],'observer iteration and stats')
  C(q['observed_post_registration_penalties']==ps,'PM snapshot constant');changes+=q['observed_post_registration_penalties']!=prev;prev=q['observed_post_registration_penalties']
  C(q['observed_search_evaluator_integer_probes']==expected,'all raw probes');pmrows+=1
 C(changes==0,'no observed PM updates');gap=cost[proxy]-refs[name][proxy]if ok else None;C(gap is None or gap>=0,'own objective gap')
 rows.append({'call_id':ident,'instance_id':name,'seed':s['seed'],'proxy':proxy,'arm':arm,'scale':scale,'feasible':ok,'loads':loads,'routes':routes,'base_E':cost['E']if ok else None,'base_G':cost['G']if ok else None,'own_gap_mm':gap,'initial_feasible':init_ok,'first_best_feasible_iteration':first,'PM_updates':changes,'probe_raw':expected,'overload':sum(max(0,v-5)for v in loads)})
sm=J('reports/SUMMARY.json');reported={q['call_id']:q for q in sm['rows']}
for row in rows:
 q=reported[row['call_id']];C((row['feasible'],row['base_E'],row['base_G'],row['own_gap_mm'],row['loads'],row['routes'])==(q['valid'],q['base_E'],q['base_G'],q['own_gap_mm'],q['loads'],q['routes']),'summary row agreement')
arms={}
for arm in'ABC':
 ar=[q for q in rows if q['arm']==arm];valid=[q for q in ar if q['feasible']];a=sm['overall']['arms'][arm];C(len(ar)==72 and len(valid)==a['valid_feasible']and a['complete_panel']is None,'all panel null and counts');C(sum(q['initial_feasible']for q in ar)==len(valid),'initial and final counts');C(all(q['first_best_feasible_iteration']in(0,None)for q in ar),'no new first feasible in ILS')
 arms[arm]={'planned':72,'valid':len(valid),'failed':72-len(valid),'initial_feasible':sum(q['initial_feasible']for q in ar),'full_panel_cost':None,'own_exact_hits':sum(q['own_gap_mm']==0 for q in valid),'by_proxy':{key:{'planned':36,'valid':sum(q['proxy']==key for q in valid),'mean_conditional_gap':statistics.mean(q['own_gap_mm']for q in valid if q['proxy']==key),'exact_hits':sum(q['proxy']==key and q['own_gap_mm']==0 for q in valid)}for key in('E','G')}}
C([arms[x]['valid']for x in'ABC']==[60,4,60],'60/4/60')
by={(r['instance_id'],r['seed'],r['proxy'],r['arm']):r for r in rows};pairs=[];common=[]
legacy=J('historical_reference/ALL72_LEGACY250_OUTPUTS.json');C(legacy['diagnostic_only']and len(legacy['rows'])==72,'legacy diagnostic72');old={(x['entry']['instance_id'],x['entry']['seed'],x['entry']['proxy']):x['answer']for x in legacy['rows']};legacy_equal=0
for name in proto['fields']:
 for seed in(0,1,2):
  for proxy in('E','G'):
   aa,bb,cc=[by[(name,seed,proxy,k)]for k in'ABC'];C(all(aa[q]==cc[q]for q in('feasible','routes','loads','base_E','base_G','own_gap_mm')),'A C same results');aout=outputs[(name,seed,proxy,'A')];o=old[(name,seed,proxy)];keys=['stats','routes','solver_is_feasible','reported_cost','reported_distance','native_routes','native_distance_matrix'];C(all(aout[q]==o[q]for q in keys),'fresh A old full250 trajectory and terminal');legacy_equal+=1
   pairs.append({'instance_id':name,'seed':seed,'proxy':proxy,'A':aa['feasible'],'B':bb['feasible'],'C':cc['feasible'],'A_C_routes_loads_equal':True,'legacy_A_equal':True})
   if all(q['feasible']for q in(aa,bb,cc)):common.append([name,seed,proxy])
C(len(common)==4 and {tuple(x)for x in common}=={('nl_field_187',s,p)for s in(1,2)for p in('E','G')},'common4 exact keys')
# Keep the four fixed toy outcomes, including the planned B overloaded result.
toyrr=JL('selftests/toy/raw/results.jsonl');C(len(toyrr)==4,'four toy');toys=[];toyo={}
for r in toyrr:
 C(r['returncode']==0 and r['process_spawned']and r['child_reaped'],'toy process');C(H(R(r['stdout']))==r['stdout_sha256']and H(R(r['stderr']))==r['stderr_sha256'],'toy hashes');o=J(r['stdout']);toyo[r['call_id']]=o;loads=[len(q)-2 for q in o['routes']];ok=max(loads)<=2;C(ok==o['solver_is_feasible']and o['num_iterations']==250 and o['model_instances']==o['solver_calls']==1,'toy load and counts');toys.append({'call_id':r['call_id'],'feasible':ok,'loads':loads,'iterations':250,'cost':o['reported_cost']})
C(not toyo['TOY_B_OBS']['solver_is_feasible'],'preserved B toy infeasible');C(all(toyo['TOY_A_OBS'][k]==toyo['TOY_A_NOOBS'][k]for k in['stats','routes','native_routes','reported_cost','native_distance_matrix']),'observer toy invariance')
res={'status':'PASS_SAVED_SCALE_RECHECK','review_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cutoff_utc':'2026-10-09T07:06:00Z','formal_finished_utc':finished['utc'],'new_solver_calls':0,'new_native_constructions':0,'new_geometry_calls':0,'frozen_members':len(frozen['files']),'full_freeze_verified':not args.skip_full_freeze,'frozen_mismatches':frozen_bad,'formal_slots':216,'native_matrix_entries_rechecked':216*169,'PM_observation_rows_rechecked':pmrows,'probe_scalar_values_rechecked':pmrows*4*3,'arms':arms,'total_valid':sum(x['valid']for x in arms.values()),'total_failed':sum(x['failed']for x in arms.values()),'pairs':pairs,'all_three_common_valid':common,'A_C_all72_state_route_load_equal':True,'fresh_A_legacy_full250_equal':legacy_equal,'failure_rows':[r for r in rows if not r['feasible']],'rows':rows,'toy_results':toys,'limitations':['Saved outputs only; no native model recreation or optimization','Official initialization max evaluator use inherited from source review; callback starts after initialization','Joint intervention does not separate initialization max and ILS midpoint causality','Integer probe multiplication uses recorded public coefficients and readback values, not new evaluator execution','No complete panel cost inferred from conditional subsets','Existing frozen G geometry evidence inherited, not revalidated here'],'source_files_read':seen}
args.out.write_text(json.dumps(res,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:res[k]for k in ['status','frozen_members','formal_slots','native_matrix_entries_rechecked','PM_observation_rows_rechecked','total_valid','total_failed','fresh_A_legacy_full250_equal']},ensure_ascii=False))
