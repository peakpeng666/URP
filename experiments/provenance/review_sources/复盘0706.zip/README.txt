URP历史复盘07:06短增补，可复查小证据包

结果截止2026-10-09 07:06 UTC；复核和交付时间单列，不改动原截止。
正文：URP历史复盘短增补_截至20261009T0706Z.txt
结构化结论变化：增补更新条目.json
前沿独立核查：frontier_recheck/RESULT.json及RECHECK_ZH.txt
尺度独立核查：scale_recheck/SAVED_SCALE_RECHECK.json
来源身份、冻结hash与既有实际下载字节：SOURCE_IDENTITIES_AND_FREEZE.json
旧五版15交付件保护：SOURCE_PRESERVATION.json
541份选定来源原件位于evidence/，清单SELECTED_SOURCE_MANIFEST.json。

在解压根目录可重复以下只读保存证据核查：
python frontier_recheck/recheck_saved_frontier.py --source-root evidence/route_distance_frontier_20261009 --output-dir replay_frontier
python scale_recheck/recheck_saved_scale.py --source-root evidence/mature_field_cost_scale_control_20261009 --skip-full-freeze --out replay_scale.json

仅Python标准库。脚本读取保存值、路线、证书和观察记录，不导入求解器、不构造native对象、不生成新分组、不做supported分类、无网络。新生成复核结果的时间/路径可变；科学字段应与frontier_portable/RESULT.json和scale_recheck/PORTABLE_SCALE_RECHECK.json一致。

本轮完整冻结194/591项hash在原目录已核；本精选包没有带入全部冻结成员，故可搬移尺度命令显式跳过全目录冻结hash检查。前沿只检查供给目录的覆盖/证书与算术，继承局部G最优表及逐目录成本来源、原几何仍依赖原独审。尺度保留共同Q5父ZIP读取其精确真值，不执行其中代码。

reviewer_development记录检查器最初中点浮点表达式假设的技术纠正，原实验没有改变，未新增求解。实验阶段的toy失败/准备期修订及正式超载原记录均保留于选定源件或原FINAL。

本包不是全库复盘替代索引，也不是335ZIP原始复算。未上传、未删除、未改旧正文或索引；root审阅后由唯一归档员执行私有归档回读。
