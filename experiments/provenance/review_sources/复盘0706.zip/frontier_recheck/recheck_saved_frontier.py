#!/usr/bin/env python3
"""Read-only check of supplied frontier certificates; no solver/source imports.

Only reads the named frontier batch. It does not read the embedded prior-batch
archives, generate partitions, solve TSPs, or extract a new frontier. Candidate
rows are only checked against the frontier and budget choices already supplied.
"""
from collections import Counter
import argparse
import csv
from datetime import datetime, timezone
from fractions import Fraction
import hashlib
import io
import json
import math
from pathlib import Path
import statistics
import time

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-root', type=Path, default=Path('/workspace/shared/route_distance_frontier_20261009'))
parser.add_argument('--output-dir', type=Path, default=Path(__file__).resolve().parent)
args = parser.parse_args()
ROOT = args.source_root.resolve()
OUT = args.output_dir.resolve()
FIELDS = ['nl_field_40','nl_field_44','nl_field_63','nl_field_187','nl_field_1','nl_field_2','nl_field_7','nl_field_8','nl_field_17','nl_field_67','nl_field_89','nl_field_143']
BUDGETS = [0,1,2,5,10,20]
SIZES = [4,8,8,5,3,6,10,5,6,7,13,10]
EXPECTED_PATTERNS = {
    '2,5,5': math.factorial(12)//(math.factorial(2)*math.factorial(5)**2*math.factorial(2)),
    '3,4,5': math.factorial(12)//(math.factorial(3)*math.factorial(4)*math.factorial(5)),
    '4,4,4': math.factorial(12)//(math.factorial(4)**3*math.factorial(3)),
}
EXPECTED_ROWS = sum(EXPECTED_PATTERNS.values())
manifest = {}
checks = Counter()
start = time.monotonic()

def require(condition, message):
    checks['assertions'] += 1
    if not condition:
        raise AssertionError(message)

def read(rel):
    path = ROOT / rel
    require(path.resolve().is_relative_to(ROOT.resolve()), f'outside source root: {rel}')
    data = path.read_bytes()
    entry = {'path': str(path), 'relative_path': rel, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    if rel in manifest:
        require(manifest[rel] == entry, f'source changed during read: {rel}')
    manifest[rel] = entry
    return data

def obj(rel):
    return json.loads(read(rel))

def pcode(partition):
    return tuple(tuple(g) for g in partition)

def groups_for_masks(masks):
    return tuple(tuple(i+1 for i in range(12) if m & (1<<i)) for m in masks)

def validate_witness(point, label):
    groups = pcode(point['partition'])
    masks = tuple(point['group_masks'])
    require(groups == groups_for_masks(masks), label + ': masks/groups')
    require(tuple(sorted(groups)) == groups, label + ': canonical Pcode')
    require(sorted(x for group in groups for x in group) == list(range(1,13)), label + ': customer coverage')
    require(len(groups) == 3 and all(2 <= len(g) <= 5 for g in groups), label + ': capacity/vehicles')
    routes = point['routes']
    costs = point['route_G_mm']
    require(len(routes) == len(costs) == 3, label + ': witness length')
    for group, route, cost in zip(groups, routes, costs):
        require(route[0] == route[-1] == 0 and tuple(sorted(route[1:-1])) == group, label + ': route membership')
        require(type(cost) is int and cost >= 0, label + ': saved route cost integer')
    require(sum(costs) == point['sum_G_mm'] and max(costs) == point['max_route_G_mm'], label + ': saved route-cost arithmetic')

protocol = obj('freeze/PROTOCOL.json')
summary = obj('reports/SUMMARY.json')
audit = obj('independent_supervision/FINAL_AUDIT.json')
review = obj('independent_supervision/FINAL_REPORT_REVIEW.json')
# Included because it was inspected for the historical scope explanation.
read('independent_supervision/PROOF_AND_SCOPE_ZH.txt')
report = read('reports/REPORT_ZH.txt')
export_rows = list(csv.DictReader(io.StringIO(read('reports/FRONTIERS.csv').decode())))
ledgers = [list(map(json.loads, read(rel).decode().splitlines())) for rel in ['raw/results.jsonl','independent_supervision/raw/results.jsonl']]
require(protocol['fields'] == FIELDS, 'field set/order')
require(protocol['budget_queries']['percentages'] == BUDGETS, 'budgets')
require(EXPECTED_ROWS == 41811, 'combinatorial count')
require(summary['status'] == 'COMPLETE_PANEL' and audit['status'] == review['status'] == 'PASS', 'saved status')
require(review['summary_sha256'] == manifest['reports/SUMMARY.json']['sha256'], 'review summary hash')
require(review['independent_audit_sha256'] == manifest['independent_supervision/FINAL_AUDIT.json']['sha256'], 'review audit hash')
require(summary['independent_audit_sha256'] == manifest['independent_supervision/FINAL_AUDIT.json']['sha256'], 'summary audit hash')
report_hash_matches_review = review['report_sha256'] == hashlib.sha256(report).hexdigest()
require(report_hash_matches_review, 'review report hash')
require(len(export_rows) == 85, 'export count')
for ledger in ledgers:
    require([x['schedule']['instance_id'] for x in ledger] == FIELDS, 'ledger unique ordered 12 slots')
    for row in ledger:
        require(row['returncode'] == 0 and row['process_spawned'] and row['child_reaped'], 'saved process success')
        require(row['registered_group_cleanup']['quiescent'] and not row['registered_group_cleanup']['remaining'], 'saved quiescence')
        require(row['configured_cpu_soft_hard_seconds'] == [15,15] and row['configured_as_soft_hard_bytes'] == [268435456,268435456] and row['configured_wall_seconds'] == 30, 'saved configured worker limits')

field_results = []
budget_results = []
for field_no, field in enumerate(FIELDS):
    main_rel = f'raw/calls/{field}_FRONTIER.stdout'
    independent_rel = f'independent_supervision/raw/calls/{field}_FRONTIER.stdout'
    main, independent = obj(main_rel), obj(independent_rel)
    sf, af = summary['fields'][field_no], audit['fields'][field_no]
    require(sf['instance_id'] == af['instance_id'] == main['instance_id'] == independent['instance_id'] == field, field+': identity')
    require(sf['eligible_for_primary'] and af['valid_for_exact_conclusion'], field+': saved eligibility')
    require(main['frontier'] == independent['frontier'] == af['frontier'], field+': all frontier records agree')
    front = main['frontier']
    require(len(front) == SIZES[field_no] == main['frontier_size'] == independent['frontier_size'] == sf['frontier_size'], field+': count')
    require(main['frozen_files_sha256'] == independent['frozen_files_sha256'] == audit['frozen_files_sha256'] == summary['frozen_files_sha256'], field+': frozen identity reference')
    for j, (rel, data) in enumerate([(main_rel,main),(independent_rel,independent)]):
        require(manifest[rel]['sha256'] == ledgers[j][field_no]['stdout_sha256'], field+': ledger stdout hash')
        require(data['endpoints_match_frozen_prior'] is True, field+': saved endpoint result')
        require(data['n'] == 12 and data['Q'] == 5 and data['K'] == 3, field+': model')
    require(manifest[main_rel]['sha256'] == af['main_stdout_sha256'], field+': audit stdout hash')
    require(main['counters']['new_local_tsp_evaluations'] == independent['counters']['additional_local_TSP_calls'] == 0, field+': saved zero TSP count')
    require(main['input_identity']['local_table_canonical_json_sha256'] == independent['input_identity']['local_table_canonical_json_sha256'], field+': inherited table identity references')
    for k, point in enumerate(front):
        require(point['index'] == k, field+': front index')
        validate_witness(point, field+f': point {k}')
        if k:
            require(front[k-1]['sum_G_mm'] < point['sum_G_mm'] and front[k-1]['max_route_G_mm'] > point['max_route_G_mm'], field+': strict order')
        for other in front[:k]:
            a,b = (point['sum_G_mm'],point['max_route_G_mm']), (other['sum_G_mm'],other['max_route_G_mm'])
            require(not (a[0]<=b[0] and a[1]<=b[1]) and not (b[0]<=a[0] and b[1]<=a[1]), field+': pairwise antichain')
            checks['frontier_pairwise_antichain_comparisons'] += 1
    cat_rel = f'raw/catalogs/{field}_FRONTIER.csv'
    independent_cat_rel = f'independent_supervision/raw/catalogs/{field}_FRONTIER.csv'
    cat, independent_cat = read(cat_rel), read(independent_cat_rel)
    require(cat == independent_cat, field+': main/independent full certificate bytes identical')
    for rel, data in [(cat_rel,main),(independent_cat_rel,independent)]:
        require(manifest[rel]['sha256'] == data['catalog']['sha256'] and len(cat) == data['catalog']['bytes'], field+': catalog hash/bytes')
    require(manifest[cat_rel]['sha256'] == af['catalog_sha256'] == sf['catalog']['sha256'], field+': audit/summary catalog hash')
    queries = main['queries']
    require([q['p'] for q in queries] == BUDGETS, field+': 6 supplied queries')
    choice_keys = []
    thresholds = []
    for qi,q in enumerate(queries):
        p = q['p']
        threshold = front[0]['sum_G_mm'] * (100+p) // 100
        require(q['budget_total_G_mm'] == threshold, field+': exact threshold')
        feasible_front = [v for v in front if 100*v['sum_G_mm'] <= (100+p)*front[0]['sum_G_mm']]
        # This only selects among already supplied saved frontier records.
        chosen = min(feasible_front, key=lambda v:(v['max_route_G_mm'],v['sum_G_mm'],pcode(v['partition'])))
        require(q['front_index'] == chosen['index'], field+': supplied-frontier budget selection')
        for key in ['sum_G_mm','max_route_G_mm','partition','routes','route_G_mm','group_masks']:
            require(q[key] == chosen[key], field+': query witness')
        for other_q in [independent['queries'][qi],af['queries'][qi],sf['queries'][qi]]:
            require(all(other_q[key] == value for key,value in q.items()), field+': saved query agreement')
        if qi:
            require(queries[qi-1]['sum_G_mm'] <= q['sum_G_mm'] and queries[qi-1]['max_route_G_mm'] >= q['max_route_G_mm'], field+': decision monotonicity')
        delta = q['sum_G_mm'] - front[0]['sum_G_mm']
        reduction = front[0]['max_route_G_mm'] - q['max_route_G_mm']
        require(sf['queries'][qi]['delta_sum_G_mm'] == delta and sf['queries'][qi]['reduction_max_route_G_mm'] == reduction, field+': saved delta')
        require(100*delta <= p*front[0]['sum_G_mm'], field+': exact budget feasibility')
        budget_results.append({'instance_id':field,'p':p,'threshold_mm':threshold,'front_index':chosen['index'],'sum_G_mm':q['sum_G_mm'],'max_route_G_mm':q['max_route_G_mm'],'delta_sum_G_mm':delta,'reduction_max_route_G_mm':reduction,'extra_total_percent':100*delta/front[0]['sum_G_mm'],'longest_reduction_percent':100*reduction/front[0]['max_route_G_mm']})
        choice_keys.append((q['max_route_G_mm'],q['sum_G_mm'],pcode(q['partition'])))
        thresholds.append(threshold)
    reader = csv.DictReader(io.StringIO(cat.decode()))
    require(','.join(reader.fieldnames) == protocol['catalog_schema']['header'], field+': catalog schema')
    normal = hashlib.sha256((protocol['catalog_schema']['normalized_hash_header']+'\n').encode())
    patterns, relations, equal_counts = Counter(), Counter(), Counter()
    objective_pairs = set()
    representatives = {pcode(point['partition']): point['index'] for point in front}
    representatives_seen = set()
    previous = None
    total_rows = 0
    budget_feasible_comparisons = 0
    for row in reader:
        masks = tuple(int(row[f'mask{i}']) for i in [1,2,3])
        groups = groups_for_masks(masks)
        require(all(0 < x < 4096 for x in masks) and not(masks[0]&masks[1] or masks[0]&masks[2] or masks[1]&masks[2]) and (masks[0]|masks[1]|masks[2]) == 4095, field+': catalog partition legality')
        require(groups == tuple(sorted(groups)) and all(2<=len(g)<=5 for g in groups), field+': catalog capacity/canonical groups')
        require(previous is None or previous < groups, field+': strict Pcode order and uniqueness')
        previous = groups
        pattern = ','.join(map(str,sorted(map(len,groups))))
        patterns[pattern] += 1
        s,m,k = int(row['sum_G_mm']),int(row['max_route_G_mm']),int(row['front_index'])
        require(0<=m<=s<=3*m and 0<=k<len(front), field+': cost consistency/front reference')
        point = front[k]
        pair, fpair = (s,m), (point['sum_G_mm'],point['max_route_G_mm'])
        relation = row['relation']
        require(relation in ['E','D'], field+': known relation')
        if groups in representatives:
            require(relation == 'E' and k == representatives[groups] and pair == fpair, field+': supplied representative occurs in catalog at same costs')
            representatives_seen.add(k)
        if relation == 'E':
            require(pair == fpair and pcode(point['partition']) <= groups, field+': equality/min-P certificate')
            equal_counts[k] += 1
        else:
            require(fpair[0]<=s and fpair[1]<=m and fpair!=pair, field+': strict dominance certificate')
        for qi,threshold in enumerate(thresholds):
            checks['saved_unlabeled_budget_feasibility_tests'] += 1
            if s <= threshold:
                require(choice_keys[qi] <= (m,s,groups), field+': supplied budget choice versus saved feasible row')
                budget_feasible_comparisons += 1
        normal.update((','.join(row[key] for key in reader.fieldnames[:5])+'\n').encode())
        objective_pairs.add(pair)
        relations[relation] += 1
        total_rows += 1
    require(total_rows == EXPECTED_ROWS and patterns == EXPECTED_PATTERNS, field+': complete distinct legal row count by combinatorics')
    require(representatives_seen == set(range(len(front))), field+': every supplied representative present')
    require(normal.hexdigest() == main['catalog']['normalized_objective_catalog_sha256'] == independent['catalog']['normalized_objective_catalog_sha256'] == af['normalized_objective_catalog_sha256'], field+': normalized catalog hash')
    require(relations == main['catalog']['relation_counts'] == independent['catalog']['relation_counts'] == af['certificate']['relation_counts'], field+': relation counts')
    require(len(objective_pairs) == main['unique_objective_pairs'] == independent['unique_objective_pairs'] == sf['unique_objective_pairs'] == af['unique_objective_pairs'], field+': unique pair count')
    for point in front:
        require(equal_counts[point['index']] == point['assignment_multiplicity_unlabeled'], field+': E-row multiplicity')
    exported = [r for r in export_rows if r['instance_id']==field]
    require(len(exported) == len(front), field+': export count')
    for row,point in zip(exported,front):
        require(int(row['front_index']) == point['index'] and int(row['sum_G_mm']) == point['sum_G_mm'] and int(row['max_route_G_mm']) == point['max_route_G_mm'], field+': export objective')
        require(json.loads(row['Pcode']) == point['partition'] and int(row['assignment_multiplicity_unlabeled']) == point['assignment_multiplicity_unlabeled'], field+': export Pcode/multiplicity')
        require([int(row[f'group_mask_{i}']) for i in [1,2,3]] == point['group_masks'], field+': export masks')
        require([json.loads(row[f'route_{i}']) for i in [1,2,3]] == point['routes'] and [int(row[f'route_{i}_G_mm']) for i in [1,2,3]] == point['route_G_mm'], field+': export witnesses')
    field_results.append({'instance_id':field,'frontier_points':len(front),'catalog_rows_checked':total_rows,'unique_objective_pairs':len(objective_pairs),'relation_counts':dict(relations),'certificate_bytes_identical_main_independent':True,'catalog_sha256':manifest[cat_rel]['sha256'],'normalized_catalog_sha256':normal.hexdigest(),'budget_feasible_rows_compared':budget_feasible_comparisons,'twenty_percent_reaches_last_frontier_point':queries[-1]['front_index']==len(front)-1})

aggregate=[]
for p in BUDGETS:
    selected=[r for r in budget_results if r['p']==p]
    row={'p':p,'denominator':len(selected),'strict_longest_improvement_fields':sum(r['reduction_max_route_G_mm']>0 for r in selected)}
    saved = next(r for r in summary['by_budget'] if r['p']==p)
    for metric in ['delta_sum_G_mm','reduction_max_route_G_mm','extra_total_percent','longest_reduction_percent']:
        values=[r[metric] for r in selected]
        mean,median=statistics.mean(values),statistics.median(values)
        require(math.isclose(mean,saved['complete_panel_mean_'+metric],rel_tol=1e-14,abs_tol=1e-10), f'aggregate mean {p}/{metric}')
        require(math.isclose(median,saved['complete_panel_median_'+metric],rel_tol=1e-14,abs_tol=1e-10), f'aggregate median {p}/{metric}')
        row['mean_'+metric],row['median_'+metric]=mean,median
        if metric.endswith('_mm'):
            row['exact_mean_'+metric]=str(Fraction(sum(values),len(values)))
    aggregate.append(row)
require([r['strict_longest_improvement_fields'] for r in aggregate] == [0,3,6,7,11,12], 'improvement counts')
require(sum(r['frontier_points'] for r in field_results)==85 and len(budget_results)==72, 'final totals')

result={
    'status':'PASS', 'checked_utc':datetime.now(timezone.utc).isoformat(),
    'historical_evidence_cutoff_utc':'2026-10-09T07:06:00Z',
    'source_root':str(ROOT), 'check_runtime_seconds':time.monotonic()-start,
    'frontier_sizes':SIZES, 'frontier_points':85, 'budget_rows':72,
    'main_recorded_calls':len(ledgers[0]), 'independent_recorded_calls':len(ledgers[1]),
    'new_partition_generation_calls':0, 'new_frontier_solver_calls':0, 'new_local_TSP_calls':0,
    'saved_catalog_rows_checked':sum(r['catalog_rows_checked'] for r in field_results),
    'unique_source_files_read':len(manifest), 'checks':dict(checks),
    'independently_checked_now':[
        '85 supplied objective pairs: strict S-increase/M-decrease and every within-field pair is incomparable.',
        'Saved route membership/capacity/depot closure and integer sum/max of supplied route_G_mm; not edge/path costs.',
        '501732 saved catalog rows: valid distinct canonical 12-customer partitions, allowed size counts equal closed-form combinatorial counts; no generated partitions.',
        'Every saved catalog E/D relation, referenced front index, supplied min-P and multiplicity certificate; main/independent certificate bytes identical.',
        'Saved stdout/catalog/review hashes, main/independent/audit/summary/export agreement and recorded 12+12 successful lifecycle slots.',
        '72 thresholds and choices recomputed over the already supplied frontier; each supplied choice also compared against every feasible supplied catalog row.',
        'Budget deltas, means, medians, percentages, improvement counts recomputed from saved integer objectives.'
    ],
    'not_independently_reestablished_now':[
        'Local G shortest-tour optimality, inherited 1573-entry tables and per-catalog-row S/M derivation from them; rely on original saved audit and identity references.',
        'Native geometry, G edge/path construction, legal physical travel, rounding/projection accuracy and raw path lengths; not read or recomputed.',
        'Prior endpoint records in embedded parent archives; only current saved equality flags and audit agreement checked.',
        'Original labeled enumeration, 6x multiplicity/repeat counters, process isolation or historical actual resource enforcement; recorded evidence only.',
        'Drive/cloud byte readbacks and private access controls; outside this local recheck.',
        'No supported/unsupported classification, weighted scalarization, new candidate enumeration or new global/local optimization.'
    ],
    'conditional_conclusion':'Given the originally audited catalog costs and local-table reduction, the supplied coverage, equality/dominance and antichain certificates certify all 85 nondominated objective-value pairs. This recheck proves saved-certificate consistency, not fresh geometry or local-optimality provenance.',
    'fields':field_results, 'by_budget':aggregate,
}
OUT.mkdir(parents=True,exist_ok=True)
(OUT/'RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
(OUT/'SOURCE_MANIFEST.json').write_text(json.dumps({'source_root':str(ROOT),'files':list(manifest.values())},ensure_ascii=False,indent=2)+'\n')
with (OUT/'BUDGET_RECALCULATED.csv').open('w',newline='') as file:
    writer=csv.DictWriter(file,fieldnames=budget_results[0].keys()); writer.writeheader();writer.writerows(budget_results)
print(json.dumps({'status':result['status'],'frontier_points':85,'budget_rows':72,'catalog_rows':result['saved_catalog_rows_checked'],'source_files':len(manifest),'checks':dict(checks),'by_budget':aggregate,'runtime_seconds':result['check_runtime_seconds']},ensure_ascii=False,indent=2))
