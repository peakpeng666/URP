# diag/ —— N* 搜索的原始诊断证据（2026-09-16）

本目录不是临时产物，是 README 增补第二节"n=48 不可达、瓶颈是解析而非难度"这一
结论的原始证据，勿删。

| 文件 | 内容 |
|---|---|
| `batch_status.txt` | 批次逐 run 的退出码与墙钟。n=42 五个 seed `rc=0 wall≈618s`；n=44 五个 `rc=0 wall≈795s`；n=48 两个 `rc=124 wall=800s`（撞硬超时） |
| `n44_s*.log` | n=44 的 gdb/HGS 完整输出。**关键行**：`\| Start of GA \| NbNodes : 44 \|` 之前一行 `CPU Time : 765.777 seconds` —— 解析耗时的直接读数 |
| `n48_s1.log` | 单点诊断：解析中途 `[Inferior 1 exited with code 01]`，从未进入 GA |
| `n48_s2.log` / `n48_s3.log` | 批次运行：800 s 被 `timeout` 杀死（`exited with code 0217`），同样从未出现 `Start of GA` |
| `n40_s5.log` | 补测 n=40 缺失的第 5 个 seed（单独跑，无并发争用；`ticks_total=418692`，对照并发时的 494k–506k） |
| `run_batch.sh` | 当次批次脚本（一次性）。每个 run 套 `timeout -k 5 800`，避免单个挂起吃光预算 |

读这些日志时注意：gdb 关于 `could not convert 'std::basic_ifstream' from the host
encoding (CP65001)` 的警告是 gdb 读取 MinGW 调试信息时的字符集噪声，与 HGS 本身
无关，不影响断点置零绕法（`ar_nbArcsDistance = 0`）生效。
