def sort_array(arr):
    """对列表 arr 中的元素做升序排序。

    输入：arr，元素可两两比较的列表
    输出：排序结果列表
    示例：sort_array([3, 1, 2]) -> [1, 2, 3]
    要求：自己实现排序逻辑，不得调用 sorted() 或 arr.sort()。
    """
    if len(arr) == 1:
        return arr

    for i in range(len(arr)-1):
        for j in range(len(arr)-1-i):
            if arr[j] > arr[j+1]:
                arr[j], arr[j+1] = arr[j+1], arr[j]

    return arr
