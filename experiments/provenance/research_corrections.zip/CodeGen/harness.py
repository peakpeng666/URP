"""P2 评测 harness。候选模块在子进程执行，超时 10 秒，判定规则见报告第 4 节。"""
import json
import re
import subprocess
import sys
import tempfile
import os

# 测试用例：名称 -> 输入列表
CASES = {
    "empty": [],
    "single": [7],
    "typical": [3, 1, 2],
    "duplicates": [5, 3, 5, 1, 3],
    "negatives": [-2, 5, -9, 0],
    "sorted": [1, 2, 3, 4, 5],
    "reverse": [9, 7, 5, 3, 1],
    "floats": [2.5, -1.0, 0.0, 3.75, 2.5],
    "strings": ["pear", "apple", "fig", "apple"],
    "large100": [58, 22, 91, 34, 6, 78, 45, 12, 83, 29, 67, 3, 95, 51, 18,
                 74, 39, 88, 27, 62, 9, 46, 71, 15, 84, 33, 57, 21, 93, 48,
                 66, 11, 79, 25, 54, 90, 36, 8, 72, 41, 17, 86, 31, 60, 23,
                 97, 44, 13, 76, 52, 28, 81, 38, 69, 5, 94, 49, 16, 63, 35,
                 87, 26, 55, 10, 92, 43, 19, 68, 30, 99, 47, 14, 77, 53, 24,
                 85, 37, 61, 7, 96, 50, 20, 73, 42, 89, 32, 65, 4, 98, 56,
                 1, 80, 40, 59, 2, 82, 64, 100, 70, 75],
}

DRIVER = '''\
import importlib.util, json, sys
sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location("cand", sys.argv[1])
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
f = getattr(mod, sys.argv[2])
cases = json.loads(sys.argv[3])
out = {"import_ok": True, "results": {}}
for name, x in cases.items():
    x = list(x)
    try:
        ref = sorted(x)        # 先算参照，避免原地排序改动 x 后参照失真
        arg = list(x)          # 传给 f 的那一份留住，原地排序的结果在这里
        y = f(arg)
        if y is None:
            y = arg            # 契约允许原地风格：回退到 f 实际改过的那份
        ok = (list(y) == ref)
        out["results"][name] = "pass" if ok else "wrong"
    except Exception as e:
        out["results"][name] = f"error:{type(e).__name__}"
print("RESULT_JSON:" + json.dumps(out))
'''

BUILTIN_RE = re.compile(r"\bsorted\s*\(|\.sort\s*\(")


def uses_builtin(code):
    return bool(BUILTIN_RE.search(code))


def evaluate_module(py_path, fname, timeout=10.0):
    """跑完整个用例组，返回判定记录。"""
    with tempfile.TemporaryDirectory() as td:
        driver_path = os.path.join(td, "driver.py")
        with open(driver_path, "w", encoding="utf-8") as fh:
            fh.write(DRIVER)
        try:
            proc = subprocess.run(
                [sys.executable, driver_path, os.path.abspath(py_path), fname,
                 json.dumps(CASES)],
                capture_output=True, text=True, timeout=timeout, cwd=td)
        except subprocess.TimeoutExpired:
            return {"verdict": "TIMEOUT", "detail": "subprocess timeout",
                    "first_fail": ""}
        line = next((ln for ln in proc.stdout.splitlines()
                     if ln.startswith("RESULT_JSON:")), None)
        if line is None:
            # 导入即失败，按编译错误处理
            err = (proc.stderr or proc.stdout or "").strip().splitlines()
            return {"verdict": "SYNTAX", "detail": " / ".join(err[-2:]) if err else "",
                    "first_fail": ""}
        out = json.loads(line[len("RESULT_JSON:"):])
        code_txt = open(py_path, encoding="utf-8").read()
        fails = {k: v for k, v in out["results"].items() if v != "pass"}
        if not fails:
            verdict = "PASS_BUILTIN" if uses_builtin(code_txt) else "PASS_NATIVE"
            return {"verdict": verdict, "detail": "", "first_fail": ""}
        first_name, first_why = next(iter(fails.items()))
        kind = "WRONG" if first_why == "wrong" else "ERROR"
        return {"verdict": kind, "detail": first_why, "first_fail": first_name}
