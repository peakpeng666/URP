#!/usr/bin/python3
"""Byte-preserving raw selection; run using system Python with preinstalled OGR."""
from pathlib import Path
import hashlib,json,zipfile,re,sys,importlib.util
from osgeo import ogr,gdal
import pyproj
ogr.UseExceptions()
BASE=Path(__file__).resolve().parent
SRC=Path('/workspace/shared/visual_vrp_data_research_20261007/evidence')
def digest(b): return hashlib.sha256(b).hexdigest()
def save(n,x): (BASE/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
rule_bytes=(BASE/'SELECTION_RULE_FROZEN.json').read_bytes()
archive=(SRC/'fields2benchmark_wkt.zip').read_bytes()
assert digest(archive)=='d00d0c9574212e29f7f18be775975f6b1ffd38a7dcd3501d7c05d2f63b7b26f7'
assert hashlib.md5(archive).hexdigest()=='dc054560af2a388996de201e3fe193dd'
z=zipfile.ZipFile(SRC/'fields2benchmark_wkt.zip')
names=sorted([n for n in z.namelist() if re.fullmatch(r'wkt/nl_field_\d+\.wkt',n)],key=lambda n:int(re.search(r'(\d+)\.wkt$',n)[1]))
assert len(names)==140
inventory=[{'member':n,'bytes':len(z.read(n)),'sha256':digest(z.read(n))} for n in names]
save('universe_inventory.json',inventory)
selected=[]; audit=[]
for n in names:
 b=z.read(n); row={'member':n,'sha256':digest(b),'bytes':len(b)}
 try:
  g=ogr.CreateGeometryFromWkt(b.decode('utf8'))
  row.update(geometry_type=g.GetGeometryName(),coordinate_dimension=g.GetCoordinateDimension(),valid=g.IsValid(),empty=g.IsEmpty(),ring_count=g.GetGeometryCount())
  if g.GetGeometryName()!='POLYGON' or g.IsEmpty() or g.GetCoordinateDimension()!=2 or not g.IsValid(): row['decision']='exclude_geometry_gate'
  else:
   a=g.GetArea(); h=g.ConvexHull().GetArea(); ratio=(h-a)/h if h>0 else 0
   row.update(source_coordinate_area=a,convex_hull_deficit_ratio=ratio,envelope=list(g.GetEnvelope()),point_count=sum(g.GetGeometryRef(i).GetPointCount() for i in range(g.GetGeometryCount())))
   row['decision']='select' if a>0 and ratio>1e-6 else 'exclude_not_concave_or_zero_area'
 except Exception as e: row.update(decision='exclude_parse_or_validation_error',error=str(e))
 audit.append(row)
 if row['decision']=='select':
  dest=BASE/'raw'/Path(n).name; dest.write_bytes(b); assert dest.read_bytes()==b
  selected.append(dict(row,local_file='raw/'+dest.name,source_crs=None,source_units='unconfirmed; values resemble longitude/latitude, not proof',metric_ready=False))
 if len(selected)==6: break
save('selection_audit.json',audit)
manifest={'dataset':'Fields2Benchmark v1.0','source_url':'https://zenodo.org/records/14524735','archive_url':'https://zenodo.org/records/14524735/files/wkt.zip?download=1','archive_local_path':str(SRC/'fields2benchmark_wkt.zip'),'archive_sha256':digest(archive),'archive_md5':hashlib.md5(archive).hexdigest(),'download_reused':True,'original_download_utc':'2026-10-07T05:21:15.068460+00:00','rule_sha256':digest(rule_bytes),'universe_count':len(names),'scanned_count':len(audit),'selected_count':len(selected),'selected':selected,'status':'RAW_GEOMETRY_FROZEN_METRIC_INGESTION_BLOCKED','blocker':'Dataset source CRS/axis order/units not explicitly established from reviewed official record or README; no projection performed.','transforms':[],'repair_operations':[],'license':'Archive LICENSE CC BY-SA 4.0; NL original source CC0/PDM as stated by authors. Preserve both notices and attribution.','versions':{'python':sys.version,'gdal':gdal.VersionInfo('--version'),'pyproj':pyproj.__version__,'proj':pyproj.proj_version_str,'shapely_installed':bool(importlib.util.find_spec('shapely'))},'solver_runs':0}
for source,target in [('fields2benchmark_README.md','SOURCE_README.md'),('fields2benchmark_LICENSE.txt','SOURCE_LICENSE.txt')]:
 b=(SRC/source).read_bytes(); (BASE/target).write_bytes(b)
 manifest.setdefault('source_documents',[]).append({'file':target,'sha256':digest(b),'md5':hashlib.md5(b).hexdigest()})
save('INPUT_MANIFEST.json',manifest)
print(json.dumps({'selected':[x['member'] for x in selected],'scanned':len(audit),'ratios':[x['convex_hull_deficit_ratio'] for x in selected],'status':manifest['status']},indent=2))
