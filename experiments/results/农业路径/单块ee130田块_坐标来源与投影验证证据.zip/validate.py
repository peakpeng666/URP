"""Read only official data; numerical checks using preinstalled GDAL/PROJ. No geometry repair."""
from pathlib import Path
import hashlib,json,math,csv,zipfile
from osgeo import gdal,ogr,osr
p=Path(__file__).resolve().parent
gdal.UseExceptions();ogr.UseExceptions();osr.UseExceptions()
a=(p/'input/official_ee_field_130.wkt').read_bytes();b=(p/'input/cache_ee_field_130.wkt').read_bytes();assert a==b
geo=ogr.CreateGeometryFromWkt(a.decode());assert geo and geo.GetGeometryName()=='POLYGON'
rings=[geo.GetGeometryRef(i) for i in range(geo.GetGeometryCount())]
coords=[(r.GetX(i),r.GetY(i)) for r in rings for i in range(r.GetPointCount())]
src=osr.SpatialReference();src.ImportFromEPSG(4326);src.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
zone=math.floor((coords[0][0]+180)/6)+1
assert zone==34 and coords[0][1]>0
dst=osr.SpatialReference();dst.ImportFromEPSG(32634);dst.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
fwd=osr.CoordinateTransformation(src,dst);rev=osr.CoordinateTransformation(dst,src)
proj=[fwd.TransformPoint(*v)[:2] for v in coords];back=[rev.TransformPoint(*v)[:2] for v in proj];again=[fwd.TransformPoint(*v)[:2] for v in back]
metric=geo.Clone();metric.Transform(fwd)
ringchecks=[]
for r in rings:
 pts=[r.GetPoint(i)[:2] for i in range(r.GetPointCount())];ringchecks.append({'point_count_including_closure':len(pts),'closed_exactly':pts[0]==pts[-1],'consecutive_duplicate_segments':sum(x==y for x,y in zip(pts,pts[1:]))})
bbox=lambda x:[min(v[0] for v in x),min(v[1] for v in x),max(v[0] for v in x),max(v[1] for v in x)]
origin=proj[0];local=[(x-origin[0],y-origin[1]) for x,y in proj]
result={'scope':'Exactly one documented official sample. Does not resolve CRS of any other dataset member. Original NL frozen inputs untouched; NL metric_ready=false.', 'binding':{'bytes_equal':a==b,'byte_count':len(a),'sha256':hashlib.sha256(a).hexdigest(),'commit':'93c0989ab2fc4a3f3d0a18bbd224d0e267a03fcc','repo_path':'data/ee_field_130.wkt','cached_zip_member':'wkt/ee_field_130.wkt'},'software':{'gdal':gdal.VersionInfo('--version'),'proj':'.'.join(str(x) for x in [osr.GetPROJVersionMajor(),osr.GetPROJVersionMinor(),osr.GetPROJVersionMicro()]),'python':'/usr/bin/python3'},'source':{'crs':'EPSG:4326','data_axis_order':'longitude,latitude','authority_axis_order':'latitude,longitude','data_to_srs_axis_mapping':src.GetDataAxisToSRSAxisMapping(),'angular_unit':src.GetAngularUnitsName(),'bbox_lon_lat':bbox(coords),'dimension':geo.GetCoordinateDimension(),'geometry_type':geo.GetGeometryName(),'is_empty':bool(geo.IsEmpty()),'is_valid':bool(geo.IsValid()),'is_simple':bool(geo.IsSimple()),'rings':ringchecks,'all_coordinates_finite':all(math.isfinite(v) for c in coords for v in c),'all_coordinates_in_geographic_range':all(-180<=x<=180 and -90<=y<=90 for x,y in coords)},'projection':{'crs':'EPSG:32634','equivalent_f2c_label':'UTM:34N datum:WGS84','axis_order':'easting,northing','linear_units':dst.GetLinearUnitsName(),'unit_to_metre':dst.GetLinearUnits(),'proj4':dst.ExportToProj4(),'parameters':{k:dst.GetProjParm(k) for k in ['latitude_of_origin','central_meridian','scale_factor','false_easting','false_northing']},'bbox_m':bbox(proj),'local_origin_m':origin,'local_bbox_m':bbox(local),'area_m2':metric.GetArea(),'perimeter_m':metric.Boundary().Length(),'is_valid':bool(metric.IsValid()),'all_points_in_zone34n_standard_bounds':all(18<=x<=24 and 0<=y<=84 for x,y in coords),'reference_selection':'First outer-ring vertex, matching fixed-commit Field constructor. Explicit EPSG:4326 bypasses optional ETRS89 inference.'},'roundtrip':{'vertex_count_including_closure':len(coords),'max_longitude_error_deg':max(abs(a[0]-b[0]) for a,b in zip(coords,back)),'max_latitude_error_deg':max(abs(a[1]-b[1]) for a,b in zip(coords,back)),'max_projected_return_error_m':max(math.dist(a,b) for a,b in zip(proj,again)),'max_local_origin_reconstruction_error_m':max(math.dist(a,(b[0]+origin[0],b[1]+origin[1])) for a,b in zip(proj,local))},'limitations':['No third-party repository code executed. No decomposition or route solver tested.','No geometry repaired, simplified, buffered, snapped or reordered.','Vertex round-trip is a numerical invertibility check, not independent proof of the source CRS, survey accuracy, or projection distortion.','Metric geometry connects projected original vertices directly; no edge densification.','Author test explicitly assigns EPSG:4326 to this byte-identical sample; this is an author usage declaration, not survey-grade metadata.']}
# Independent ellipsoidal area side-check, using already installed system pyproj.
from pyproj import Geod, __version__ as pyproj_version
geod=Geod(ellps='WGS84')
ellipsoid_rings=[]
for ring in rings:
    xs=[ring.GetX(i) for i in range(ring.GetPointCount())]
    ys=[ring.GetY(i) for i in range(ring.GetPointCount())]
    signed_area,perimeter=geod.polygon_area_perimeter(xs,ys)
    ellipsoid_rings.append({'signed_area_m2':signed_area,'perimeter_m':perimeter})
ellipsoid_area=abs(ellipsoid_rings[0]['signed_area_m2'])-sum(abs(r['signed_area_m2']) for r in ellipsoid_rings[1:])
result['ellipsoidal_crosscheck']={'library':'pyproj '+pyproj_version,'ellipsoid':'WGS84','edges':'geodesic between original vertices','rings':ellipsoid_rings,'net_area_m2':ellipsoid_area,'utm_minus_ellipsoidal_area_m2':metric.GetArea()-ellipsoid_area,'relative_area_difference':(metric.GetArea()-ellipsoid_area)/ellipsoid_area,'caveat':'Projection-area side-check, not survey accuracy. Both use the same author-declared source coordinates.'}
(p/'results/validation.json').write_text(json.dumps(result,indent=2)+'\n')
(p/'results/projected_epsg32634.wkt').write_text(metric.ExportToIsoWkt()+'\n')
(p/'results/source_crs.wkt').write_text(src.ExportToWkt()+'\n');(p/'results/projected_crs.wkt').write_text(dst.ExportToWkt()+'\n')
with (p/'results/vertex_roundtrip.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['index','lon','lat','easting_m','northing_m','return_lon','return_lat']);w.writerows((i,*c,*q,*b) for i,(c,q,b) in enumerate(zip(coords,proj,back)))
print(json.dumps(result,indent=2))
