"""One sequential MAIN12 saved-point classification batch, all slots retained."""
import time
from common import ROOT, read, save, append, utc
from gates import active_main_gate
from tree_runtime import run_command


def main():
    digest = active_main_gate()
    dest = ROOT / 'raw'
    dest.mkdir(exist_ok=False)
    (dest / 'calls').mkdir(); (dest / 'active').mkdir()
    schedule = read(ROOT / 'freeze/SCHEDULE.json')
    if len(schedule) != 12 or [s['instance_id'] for s in schedule] != read(ROOT / 'freeze/PROTOCOL.json')['fields']:
        raise ValueError('FULL_FIXED_12_FIELD_SCHEDULE_REQUIRED')
    started = time.monotonic(); deadline = started + 380
    save(dest / 'STARTED.json', {'utc': utc(), 'frozen_files_sha256': digest, 'planned_main_calls': 12,
                               'planned_fields': 12, 'new_route_optimization_calls': 0})
    rows = []
    for slot in schedule:
        remaining = deadline - time.monotonic()
        row = {'schedule': slot, 'utc': utc()}
        if remaining <= 0:
            row.update(status='NOT_STARTED_BATCH_BUDGET', process_spawned=False, child_reaped=False)
        else:
            cid = slot['call_id']
            append(dest / 'events.jsonl', {'event_kind': 'MATHEMATICAL_CLASSIFICATION_START_REQUESTED', 'schedule': slot, 'utc': utc()})
            row.update(run_command(['/usr/bin/python3', ROOT / 'source/author_worker.py', slot['instance_id'], slot['objective']],
                                   dest / 'calls' / cid, 15, 268435456, min(30, remaining), dest / 'active' / (cid + '.active.json')))
        append(dest / 'results.jsonl', row); rows.append(row)
    save(dest / 'FINISHED.json', {'utc': utc(), 'planned_main_calls': 12, 'recorded_slots': len(rows),
         'known_started_processes': sum(row.get('process_spawned') is True for row in rows),
         'wall_seconds': time.monotonic() - started, 'status': 'RAW_MAIN_UNREVIEWED',
         'note': 'Mathematical saved-frontier classification slots; no new route/TSP/frontier optimization.'})


if __name__ == '__main__':
    main()
