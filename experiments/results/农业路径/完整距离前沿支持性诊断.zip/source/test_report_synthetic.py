"""Saved-only aggregation fixtures; no real report or classification execution."""
import json
from report import summarize, PERCENTAGES


def run():
    rows=[]
    for name,loss in [('SYNTHETIC_A',0),('SYNTHETIC_B',3)]:
        rows.append({'instance_id':name,'eligible_for_primary':True,'class_counts':{'UNSUPPORTED':int(loss>0),'SUPPORTED_TIE_ONLY':1,'SUPPORTED_INTERVAL':2},
                     'queries':[{'p':p,'source_classification':'UNSUPPORTED' if loss else 'SUPPORTED_TIE_ONLY','ideal_complete_support_set_loss_G_mm':loss} for p in PERCENTAGES]})
    summary=summarize(rows,['SYNTHETIC_A','SYNTHETIC_B'])
    assert summary['complete_panel_class_counts']=={'UNSUPPORTED':1,'SUPPORTED_TIE_ONLY':2,'SUPPORTED_INTERVAL':4}
    for q in summary['by_budget']:
        assert q['complete_panel_positive_loss_fields']==1
        assert q['complete_panel_mean_loss_G_mm']=={'numerator':3,'denominator':2}
        assert q['complete_panel_median_loss_G_mm']=={'numerator':3,'denominator':2}
    rows[1]={'instance_id':'SYNTHETIC_B','eligible_for_primary':False,'class_counts':None,'queries':[{'p':p,'status':'UNVERIFIED'} for p in PERCENTAGES]}
    incomplete=summarize(rows,['SYNTHETIC_A','SYNTHETIC_B'])
    assert incomplete['verified_fields']==1 and incomplete['complete_panel_class_counts'] is None
    assert all(q['complete_panel_positive_loss_fields'] is None and q['complete_panel_sum_loss_G_mm'] is None for q in incomplete['by_budget'])
    try:summarize(rows,['SYNTHETIC_A','SYNTHETIC_A'])
    except ValueError:pass
    else:raise AssertionError('Duplicate panel identity accepted')
    return {'status':'PASS','synthetic_only':True,'cases':['complete_panel_exact_rational_summary','unknown_is_not_zero','duplicate_panel_rejected'],
            'real_report_calls':0,'real_classification_calls':0}


if __name__=='__main__':print(json.dumps(run(),indent=2))
