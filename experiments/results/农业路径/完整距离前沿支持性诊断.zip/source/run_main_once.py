"""Compatibility entry point; authoritative launcher is inherited launch_main_once."""
from launch_main_once import main
if __name__ == '__main__':
    main()
