"""Schedule/failure bookkeeping only: all runner/gate calls are synthetic mocks."""
import json
import pathlib
import tempfile
from unittest.mock import patch
import run_author_batch as batch
import launch_main_once as outer


def fixture(root):
    (root/'freeze').mkdir();(root/'provenance').mkdir()
    fields=['SYNTHETIC_FIELD_'+str(i) for i in range(12)]
    schedule=[{'instance_id':f,'call_id':f+'_SUPPORT','objective':'SUPPORT_CLASSIFICATION','index':i} for i,f in enumerate(fields)]
    (root/'freeze/SCHEDULE.json').write_text(json.dumps(schedule))
    (root/'freeze/PROTOCOL.json').write_text(json.dumps({'fields':fields}))
    return schedule


def run():
    cases=[]
    for expires in (False,True):
        with tempfile.TemporaryDirectory(prefix='support_ledger_SYNTHETIC_') as directory:
            root=pathlib.Path(directory);schedule=fixture(root)
            times=iter([0]+([1,381]+[382]*10 if expires else [1]*12)+[383])
            with patch.object(batch,'ROOT',root),patch.object(batch,'active_main_gate',return_value='SYNTHETIC_FREEZE'), \
                 patch.object(batch.time,'monotonic',side_effect=lambda:next(times)), \
                 patch.object(batch,'run_command',return_value={'status':'SYNTHETIC_MOCK_FAILURE','process_spawned':False,'child_reaped':False}) as runner:
                batch.main()
            rows=[json.loads(s) for s in (root/'raw/results.jsonl').read_text().splitlines()]
            assert len(rows)==12 and [r['schedule'] for r in rows]==schedule
            assert runner.call_count==(1 if expires else 12)
            assert sum(r['status']=='NOT_STARTED_BATCH_BUDGET' for r in rows)==(11 if expires else 0)
            assert json.loads((root/'raw/FINISHED.json').read_text())['known_started_processes']==0
            cases.append('batch_deadline_retains_twelve_slots' if expires else 'all_worker_failures_retained_without_retry')
    with tempfile.TemporaryDirectory(prefix='support_outer_SYNTHETIC_') as directory:
        root=pathlib.Path(directory);schedule=fixture(root)
        with patch.object(outer,'ROOT',root),patch.object(outer,'main_ready',return_value='SYNTHETIC_FREEZE'), \
             patch.object(outer.resource,'setrlimit'), \
             patch.object(outer,'run_command',return_value={'status':'SYNTHETIC_SUPERVISOR_TIMEOUT','process_spawned':False}), \
             patch.object(outer,'cleanup_registered',return_value={'quiescent':True,'groups':[]}):
            outer.main()
            try:outer.main()
            except FileExistsError:pass
            else:raise AssertionError('Second one-shot launch accepted')
        rows=json.loads((root/'raw/ALL_PLANNED_SLOTS.json').read_text())
        assert len(rows)==12 and all(r['process_spawned'] is False for r in rows)
        assert (root/'raw/RAW_MAIN_CONTENT_MANIFEST.json').exists()
        cases.append('aborted_supervisor_preserves_unstarted_slots_and_rejects_retry')
    with tempfile.TemporaryDirectory(prefix='support_bad_rows_SYNTHETIC_') as directory:
        root=pathlib.Path(directory);schedule=fixture(root);dest=root/'raw'
        (dest/'calls').mkdir(parents=True)
        first,second=schedule[:2]
        (dest/'results.jsonl').write_text(json.dumps({'schedule':first,'status':'PROCESS_FAILURE','process_spawned':True})+'\n{\n')
        (dest/'calls'/(second['call_id']+'.stdout')).write_text('')
        with patch.object(outer,'ROOT',root):outer.seal(dest,schedule,'SYNTHETIC_FREEZE',{'status':'SYNTHETIC_SUPERVISOR_FAILURE'})
        slots=json.loads((dest/'ALL_PLANNED_SLOTS.json').read_text())
        assert len(slots)==12 and slots[0]['status']=='PROCESS_FAILURE'
        assert slots[1]['status']=='UNKNOWN_AFTER_SUPERVISOR_FAILURE' and slots[1]['process_spawned']=='UNKNOWN'
        assert all(row['status']=='NOT_STARTED_SUPERVISOR_FAILURE' for row in slots[2:])
        assert json.loads((dest/'OUTER_FINISHED.json').read_text())['malformed_rows']==[1]
        cases.append('truncated_json_keeps_known_unknown_and_unstarted_slots')
    for worker_quiet,outer_quiet in [(False,True),(True,False)]:
        with tempfile.TemporaryDirectory(prefix='support_quiescence_SYNTHETIC_') as directory:
            root=pathlib.Path(directory);fixture(root)
            with patch.object(outer,'ROOT',root),patch.object(outer,'main_ready',return_value='SYNTHETIC_FREEZE'), \
                 patch.object(outer.resource,'setrlimit'), \
                 patch.object(outer,'run_command',return_value={'status':'SYNTHETIC','process_spawned':True,'registered_group_cleanup':{'quiescent':outer_quiet}}), \
                 patch.object(outer,'cleanup_registered',return_value={'quiescent':worker_quiet,'groups':[]}):
                try:outer.main()
                except RuntimeError as exc:assert str(exc)=='WHOLE_TREE_NOT_QUIESCENT'
                else:raise AssertionError('Nonquiescent tree was sealed')
            assert not (root/'raw/RAW_MAIN_CONTENT_MANIFEST.json').exists()
    cases.append('both_supervisor_and_worker_quiescence_required_before_seal')
    return {'status':'PASS','synthetic_only':True,'cases':cases,'real_classification_calls':0,'real_frontier_points_loaded':0,
            'note':'Gates/runners/resource setters are mocked only in temporary synthetic directories; no real authority is issued.'}


if __name__=='__main__':print(json.dumps(run(),indent=2))
