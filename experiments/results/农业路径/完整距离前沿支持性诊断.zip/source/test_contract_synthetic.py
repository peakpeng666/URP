"""Synthetic worker integration and authority-before-input-order tests."""
import contextlib
import copy
import hashlib
import io
import json
import pathlib
import sys
import tempfile
import zipfile
from unittest.mock import patch
import author_worker
from test_main_synthetic import points, queries


def run():
    cases = []
    with tempfile.TemporaryDirectory(prefix='support_contract_SYNTHETIC_') as directory:
        root = pathlib.Path(directory)
        (root/'freeze').mkdir(); (root/'input').mkdir()
        field = 'SYNTHETIC_FIELD_ONLY'
        protocol = {'fields': [field], 'inherited_field_point_counts': [3],
                    'input': {'parent_final_sha256': 'NOT_CREATED_YET', 'parent_frozen_sha256': 'SYNTHETIC_PARENT_FREEZE'}}
        (root/'freeze/PROTOCOL.json').write_text(json.dumps(protocol))
        args = ['author_worker.py', field, 'SUPPORT_CLASSIFICATION']
        with patch.object(author_worker, 'ROOT', root), patch.object(sys, 'argv', args):
            with patch.object(author_worker, 'active_main_gate', side_effect=RuntimeError('SYNTHETIC_GATE_BLOCK')):
                try:
                    author_worker.main()
                except RuntimeError as exc:
                    assert str(exc) == 'SYNTHETIC_GATE_BLOCK'
                else:
                    raise AssertionError('Blocked gate did not stop worker')
        cases.append('authority_gate_blocks_before_nonexistent_input_is_read')

        ps = points([(100, 60), (110, 56), (120, 40)])
        for p in ps:
            # Marker witnesses are for transmission identity, not routing proofs.
            p.update(partition=[[1], [2], [3]], group_masks=[1,2,4], routes=[[0,1,0],[0,2,0],[0,3,0]],
                     route_G_mm=[0,0,0], assignment_multiplicity_unlabeled=1)
        value = {'instance_id': field, 'frontier_size': 3, 'frozen_files_sha256': 'SYNTHETIC_PARENT_FREEZE',
                 'frontier': ps, 'queries': queries(ps), 'synthetic_only': True}
        member = 'raw/calls/' + field + '_FRONTIER.stdout'
        data = json.dumps(value).encode()
        archive = root/'input/PARENT_FINAL.zip'
        with zipfile.ZipFile(archive, 'w') as z:
            z.writestr(member, data)
        digest = hashlib.sha256(archive.read_bytes()).hexdigest()
        identity = {'status':'PARENT_FINAL_PRIVATE_ACTUAL_BYTE_READBACK_BOUND', 'synthetic_only':True,
                    'parent_zip':'input/PARENT_FINAL.zip', 'sha256':digest,
                    'selected_member_identities':{member:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}}}
        (root/'input/PARENT_MEMBER_IDENTITIES.json').write_text(json.dumps(identity))
        protocol['input']['parent_final_sha256'] = digest
        (root/'freeze/PROTOCOL.json').write_text(json.dumps(protocol))
        def invoke():
            output = io.StringIO()
            with patch.object(author_worker, 'ROOT', root), patch.object(sys, 'argv', args), \
                 patch.object(author_worker, 'active_main_gate', return_value='SYNTHETIC_CURRENT_FREEZE'), \
                 contextlib.redirect_stdout(output):
                author_worker.main()
            return json.loads(output.getvalue())
        result = invoke()
        assert result['instance_id'] == field
        assert result['class_counts'] == {'UNSUPPORTED':1, 'SUPPORTED_TIE_ONLY':0, 'SUPPORTED_INTERVAL':2}
        assert len(result['points']) == 3 and len(result['queries']) == 6
        assert result['queries'][4]['ideal_complete_support_set_loss_G_mm'] == 4
        assert result['input_identity']['sha256'] == hashlib.sha256(data).hexdigest()
        assert result['points'][1]['inherited_witness']['partition'] == ps[1]['partition']
        cases.append('synthetic_only_worker_reads_hashed_member_and_preserves_witness_identity')
        old = copy.deepcopy(identity)
        identity['selected_member_identities'][member]['sha256'] = '0'*64
        (root/'input/PARENT_MEMBER_IDENTITIES.json').write_text(json.dumps(identity))
        try:
            invoke()
        except ValueError as exc:
            assert str(exc) == 'PARENT_MAIN_MEMBER_IDENTITY'
        else:
            raise AssertionError('Changed source member accepted')
        cases.append('source_member_hash_mutation_rejected')
        (root/'input/PARENT_MEMBER_IDENTITIES.json').write_text(json.dumps(old))
        protocol['input']['parent_final_sha256'] = '0'*64
        (root/'freeze/PROTOCOL.json').write_text(json.dumps(protocol))
        try:
            invoke()
        except ValueError as exc:
            assert str(exc) == 'PARENT_FINAL_ARCHIVE_IDENTITY'
        else:
            raise AssertionError('Changed parent archive identity accepted')
        cases.append('source_archive_hash_mutation_rejected')
    return {'status':'PASS','synthetic_only':True,'cases':cases,
            'real_frontier_points_loaded':0,'real_classification_calls':0,
            'authority_note':'Only test-local monkeypatched gate and temporary synthetic archive; no real approval or receipt was created.'}


if __name__ == '__main__':
    print(json.dumps(run(), indent=2, sort_keys=True))
