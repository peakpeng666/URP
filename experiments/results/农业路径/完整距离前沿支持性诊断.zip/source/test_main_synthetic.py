"""Pure synthetic fixtures only. Does not open any real frontier inputs."""
import copy
import json
from fractions import Fraction
from classify_main import classify, join_budgets, PERCENTAGES


def points(pairs):
    return [{'index': i, 'sum_G_mm': s, 'max_route_G_mm': m} for i, (s, m) in enumerate(pairs)]


def fraction(row, key):
    f = row[key]
    return Fraction(f['numerator'], f['denominator'])


def intervals(result):
    return [(fraction(r, 'lower_bound'), fraction(r, 'upper_bound')) for r in result['points']]


def labels(result):
    return [r['classification'] for r in result['points']]


def queries(ps):
    out = []
    for p in PERCENTAGES:
        t = ps[0]['sum_G_mm'] * (100 + p) // 100
        selected = next(r for r in reversed(ps) if r['sum_G_mm'] <= t)
        out.append({'p': p, 'budget_total_G_mm': t, 'front_index': selected['index'],
                    **{k: v for k, v in selected.items() if k != 'index'}})
    return out


def reject(function, *args):
    try:
        function(*args)
    except (ValueError, TypeError, KeyError):
        return
    raise AssertionError('Malformed synthetic fixture was accepted')


def run():
    done = []
    a = points([(100, 60)])
    z = classify(a)
    assert intervals(z) == [(Fraction(0), Fraction(1))]
    assert z['directed_pair_constraints'] == 0
    assert all(q['ideal_complete_support_set_loss_G_mm'] == 0 for q in join_budgets(a, queries(a), z)['queries'])
    done.append('single_point_full_closed_weight_interval')

    a = points([(100, 60), (120, 40)])
    z = classify(a)
    assert intervals(z) == [(Fraction(1, 2), Fraction(1)), (Fraction(0), Fraction(1, 2))]
    assert labels(z) == ['SUPPORTED_INTERVAL'] * 2
    done.append('two_endpoints_zero_one_weights_and_shared_breakpoint')

    a = points([(100, 60), (110, 44), (120, 40)])
    z = classify(a)
    assert intervals(z) == [(Fraction(8, 13), Fraction(1)), (Fraction(2, 7), Fraction(8, 13)), (Fraction(0), Fraction(2, 7))]
    assert labels(z) == ['SUPPORTED_INTERVAL'] * 3
    done.append('strict_convex_vertex_positive_interval')

    a = points([(100, 60), (110, 56), (120, 40)])
    z = classify(a)
    assert intervals(z)[1] == (Fraction(8, 13), Fraction(2, 7))
    assert labels(z) == ['SUPPORTED_INTERVAL', 'UNSUPPORTED', 'SUPPORTED_INTERVAL']
    q = join_budgets(a, queries(a), z)
    assert [r['ideal_complete_support_set_loss_G_mm'] for r in q['queries']] == [0, 0, 0, 0, 4, 0]
    assert q['candidate_point_checks'] == 18
    done.append('unsupported_infeasible_interval_and_fixed_budget_loss')

    a = points([(100, 60), (105, 55), (110, 50), (120, 40)])
    z = classify(a)
    assert labels(z) == ['SUPPORTED_INTERVAL', 'SUPPORTED_TIE_ONLY', 'SUPPORTED_TIE_ONLY', 'SUPPORTED_INTERVAL']
    assert intervals(z)[1:3] == [(Fraction(1, 2), Fraction(1, 2))] * 2
    assert z['points'][1]['lower_bound_competitors'] == [2, 3]
    assert z['points'][2]['upper_bound_competitors'] == [0, 1]
    assert all(q['ideal_complete_support_set_loss_G_mm'] == 0 for q in join_budgets(a, queries(a), z)['queries'])
    done.append('multiple_collinear_interior_points_all_preserved_as_ties')

    a = points([(100, 80), (105, 75), (110, 60), (115, 55), (120, 50), (130, 45)])
    z = classify(a)
    assert labels(z) == ['SUPPORTED_INTERVAL', 'UNSUPPORTED', 'SUPPORTED_INTERVAL', 'SUPPORTED_TIE_ONLY', 'SUPPORTED_INTERVAL', 'SUPPORTED_INTERVAL']
    assert intervals(z)[0] == (Fraction(2, 3), Fraction(1))
    assert intervals(z)[2:] == [(Fraction(1, 2), Fraction(2, 3)), (Fraction(1, 2), Fraction(1, 2)),
                               (Fraction(1, 3), Fraction(1, 2)), (Fraction(0), Fraction(1, 3))]
    assert [q['ideal_complete_support_set_loss_G_mm'] for q in join_budgets(a, queries(a), z)['queries']] == [0, 0, 0, 5, 0, 0]
    done.append('mixed_hull_vertices_collinear_and_unsupported')

    base, base_result = a, z
    scaled = points([(7*r['sum_G_mm']+11, 3*r['max_route_G_mm']+13) for r in base])
    scaled_result = classify(scaled)
    def weight_map(x):
        return 3*x / (7*(1-x) + 3*x)
    assert labels(scaled_result) == labels(base_result)
    assert intervals(scaled_result) == [(weight_map(lo), weight_map(hi)) for lo, hi in intervals(base_result)]
    done.append('separate_positive_axis_scaling_support_invariance_and_exact_weight_map')

    swapped = points([(r['max_route_G_mm'], r['sum_G_mm']) for r in reversed(base)])
    swapped_result = classify(swapped)
    assert labels(swapped_result) == list(reversed(labels(base_result)))
    assert intervals(swapped_result) == [(1-hi, 1-lo) for lo, hi in reversed(intervals(base_result))]
    done.append('objective_swap_lambda_complement')

    k = 10**16
    for offset, label in [(1, 'UNSUPPORTED'), (0, 'SUPPORTED_TIE_ONLY'), (-1, 'SUPPORTED_INTERVAL')]:
        large = points([(100*k, 60*k), (110*k, 50*k+offset), (120*k, 40*k)])
        large_result = classify(large)
        assert labels(large_result)[1] == label
        assert large_result['directed_pair_constraints'] == 6
    done.append('large_integer_one_unit_above_on_below_chord_no_float')

    a = points([(101, 70), (102, 65), (103, 60), (121, 41)])
    q = queries(a)
    assert [r['budget_total_G_mm'] for r in q] == [101, 102, 103, 106, 111, 121]
    assert [r['front_index'] for r in q] == [0, 1, 2, 2, 2, 3]
    original_join = join_budgets(a, q, classify(a))
    large = points([(r['sum_G_mm']*1000, r['max_route_G_mm']*1000) for r in a])
    large_join = join_budgets(large, queries(large), classify(large))
    assert [r['source_front_index'] for r in original_join['queries']] == [r['source_front_index'] for r in large_join['queries']]
    assert [r['ideal_complete_support_set_loss_G_mm']*1000 for r in original_join['queries']] == [r['ideal_complete_support_set_loss_G_mm'] for r in large_join['queries']]
    done.append('integer_floor_thresholds_repeated_choices_last_endpoint_and_common_unit_scaling')

    zero = points([(0, 0)])
    assert all(r['ideal_complete_support_set_loss_G_mm'] == 0 for r in join_budgets(zero, queries(zero), classify(zero))['queries'])
    extra = copy.deepcopy(base)
    for p in extra:
        p['assignment_multiplicity_unlabeled'] = 10**9
        p['partition'] = [[1], [2], [3]]
    assert classify(extra) == base_result
    done.append('zero_singleton_and_partition_multiplicity_do_not_change_value_classification')

    reject(classify, [])
    for bad in [points([(100,60),(100,60)]), points([(100,60),(100,50)]),
                points([(100,60),(110,60)]), points([(100,60),(110,70)]),
                points([(100,60),(99,50)]), points([(100.0,60)]), points([(True,60)]), points([(-1,0)])]:
        reject(classify, bad)
    wrong_index = points([(100, 60)]); wrong_index[0]['index'] = True
    reject(classify, wrong_index)
    for key, value in [('budget_total_G_mm', 999), ('front_index', 999), ('sum_G_mm', 999), ('p', True)]:
        badq = copy.deepcopy(q); badq[0][key] = value
        reject(join_budgets, a, badq, classify(a))
    badq = copy.deepcopy(q); badq.pop()
    reject(join_budgets, a, badq, classify(a))
    badc = classify(a); badc['points'][0]['sum_G_mm'] += 1
    reject(join_budgets, a, q, badc)
    done.append('malformed_source_and_saved_query_mutations_fail_closed')
    return {'status': 'PASS', 'synthetic_only': True, 'case_groups': done,
            'case_group_count': len(done), 'real_frontier_points_loaded': 0,
            'real_classification_calls': 0, 'new_route_optimization_calls': 0}


if __name__ == '__main__':
    print(json.dumps(run(), indent=2, sort_keys=True))
