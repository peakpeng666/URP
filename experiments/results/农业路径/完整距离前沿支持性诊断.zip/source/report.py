"""Saved-only report and CSV exports. Never import classification or hull code."""
import csv
import json
from fractions import Fraction
from common import ROOT, read, save, sha, utc, verify_map
from gates import frozen, receipt

CLASSES = ('UNSUPPORTED', 'SUPPORTED_TIE_ONLY', 'SUPPORTED_INTERVAL')
PERCENTAGES = (0, 1, 2, 5, 10, 20)


def summarize(rows, expected_fields):
    if len(rows) != len(expected_fields) or [r['instance_id'] for r in rows] != expected_fields or len(set(expected_fields)) != len(expected_fields):
        raise ValueError('FIXED_REPORT_PANEL_IDENTITY')
    good = [r for r in rows if r['eligible_for_primary']]
    complete = len(good) == len(expected_fields)
    out = {'status': 'COMPLETE_PANEL' if complete else 'INCOMPLETE_PANEL_WITH_EXPLICIT_UNKNOWN_ROWS',
           'planned_fields': len(expected_fields), 'verified_fields': len(good),
           'unverified_fields': len(expected_fields)-len(good), 'fields': rows,
           'complete_panel_class_counts': {c:sum(r['class_counts'][c] for r in good) for c in CLASSES} if complete else None,
           'verified_only_class_counts': {c:sum(r['class_counts'][c] for r in good) for c in CLASSES},
           'by_budget': []}
    for p in PERCENTAGES:
        entries = [next(q for q in r['queries'] if q['p'] == p) for r in good]
        loss = sorted(q['ideal_complete_support_set_loss_G_mm'] for q in entries)
        row = {'p':p, 'planned_fields':len(expected_fields), 'verified_fields':len(entries),
               'complete_panel_available':len(entries)==len(expected_fields),
               'complete_panel_selected_class_counts':{c:sum(q['source_classification']==c for q in entries) for c in CLASSES} if complete else None,
               'complete_panel_positive_loss_fields':sum(v>0 for v in loss) if complete else None,
               'complete_panel_sum_loss_G_mm':sum(loss) if complete else None,
               'complete_panel_max_loss_G_mm':max(loss) if complete and loss else None,
               'complete_panel_mean_loss_G_mm':None, 'complete_panel_median_loss_G_mm':None}
        if complete and loss:
            mean = Fraction(sum(loss),len(loss)); mid=len(loss)//2
            median = Fraction(loss[mid]) if len(loss)%2 else Fraction(loss[mid-1]+loss[mid],2)
            for key,value in [('mean',mean),('median',median)]:
                row['complete_panel_'+key+'_loss_G_mm']={'numerator':value.numerator,'denominator':value.denominator}
        out['by_budget'].append(row)
    return out


def as_fraction(value):
    return str(value['numerator'])+'/'+str(value['denominator']) if value is not None else ''


def main():
    digest=frozen()
    main_receipt=receipt(ROOT/'provenance/RAW_MAIN_DRIVE_RECEIPT.json','RAW_MAIN',digest)
    independent_receipt=receipt(ROOT/'provenance/RAW_VERIFICATION_DRIVE_RECEIPT.json','RAW_VERIFICATION',digest)
    for path in ['raw/RAW_MAIN_CONTENT_MANIFEST.json','independent_supervision/raw/RAW_VERIFICATION_CONTENT_MANIFEST.json']:
        verify_map(ROOT,read(ROOT/path)['files'])
    audit=read(ROOT/'independent_supervision/FINAL_AUDIT.json')
    if (audit.get('status') not in ('PASS','AUDIT_COMPLETE_WITH_UNVERIFIED_SLOTS') or
            audit.get('frozen_files_sha256')!=digest or audit.get('raw_main_archive_sha256')!=main_receipt['sha256'] or
            audit.get('raw_verification_archive_sha256')!=independent_receipt['sha256']):
        raise ValueError('AUDIT_SOURCE_IDENTITY')
    protocol=read(ROOT/'freeze/PROTOCOL.json');fields=protocol['fields'];eligible=set(audit['eligible_instance_ids'])
    rows=[]; point_rows=[]; budget_rows=[]
    for field,expected_count in zip(fields,protocol['inherited_field_point_counts']):
        if field not in eligible:
            row={'instance_id':field,'eligible_for_primary':False,'status':'UNVERIFIED','frontier_size':expected_count,
                 'class_counts':None,'queries':[{'p':p,'status':'UNVERIFIED'} for p in PERCENTAGES]}
            point_rows.extend({'instance_id':field,'front_index':i,'classification':'UNKNOWN'} for i in range(expected_count))
            budget_rows.extend({'instance_id':field,'p':p,'source_classification':'UNKNOWN'} for p in PERCENTAGES)
        else:
            checked=next(r for r in audit['fields'] if r['instance_id']==field)
            path=ROOT/'raw/calls'/(field+'_SUPPORT.stdout')
            ipath=ROOT/'independent_supervision/raw/calls'/(field+'_SUPPORT.stdout')
            if (checked.get('valid_for_exact_conclusion') is not True or checked.get('main_stdout_sha256')!=sha(path) or
                    checked.get('independent_stdout_sha256')!=sha(ipath)):
                raise ValueError('AUDITED_OUTPUT_BYTE_IDENTITY')
            value=read(path)
            if (value['instance_id']!=field or value['frozen_files_sha256']!=digest or len(value['points'])!=expected_count or
                    [q['p'] for q in value['queries']]!=list(PERCENTAGES)):
                raise ValueError('AUDITED_OUTPUT_STRUCTURE')
            row={'instance_id':field,'eligible_for_primary':True,'status':'VERIFIED','frontier_size':expected_count,
                 'class_counts':value['class_counts'],'queries':value['queries']}
            for point in value['points']:
                point_rows.append({'instance_id':field,'front_index':point['index'],
                    'sum_G_mm':point['sum_G_mm'],'max_route_G_mm':point['max_route_G_mm'],
                    'classification':point['classification'],'lower_bound':as_fraction(point['lower_bound']),
                    'upper_bound':as_fraction(point['upper_bound']),'interval_empty':point['interval_empty'],
                    'lower_bound_competitors':json.dumps(point['lower_bound_competitors']),
                    'upper_bound_competitors':json.dumps(point['upper_bound_competitors']),
                    'inherited_witness':json.dumps(point['inherited_witness'],separators=(',',':')),
                    'source_main_stdout_sha256':checked['main_stdout_sha256']})
            budget_rows.extend({'instance_id':field,**{k:v for k,v in q.items() if k!='meaning'}} for q in value['queries'])
        rows.append(row)
    summary=summarize(rows,fields)
    summary.update(frozen_files_sha256=digest,raw_main_archive_sha256=main_receipt['sha256'],
                   raw_verification_archive_sha256=independent_receipt['sha256'],
                   independent_audit_sha256=sha(ROOT/'independent_supervision/FINAL_AUDIT.json'),utc=utc(),
                   planned_main_classification_calls=12,planned_independent_hull_calls=12,
                   planned_value_rows=85,planned_budget_comparison_rows=72,new_classification_calls=0,new_route_optimization_calls=0)
    for lane in ('main','independent'):
        counts=audit[lane+'_counts']
        if counts['planned']!=12 or counts['retained']!=12:
            raise ValueError('SAVED_ACTUAL_CALL_COUNT_DENOMINATOR')
        summary[lane+'_counts']=counts
    save(ROOT/'reports/SUMMARY.json',summary)
    schemas=[('POINT_CLASSIFICATION.csv',point_rows,['instance_id','front_index','sum_G_mm','max_route_G_mm','classification','lower_bound','upper_bound','interval_empty','lower_bound_competitors','upper_bound_competitors','inherited_witness','source_main_stdout_sha256']),
             ('BUDGET_SUPPORT_LOSS.csv',budget_rows,['instance_id','p','budget_total_G_mm','source_front_index','source_classification','source_sum_G_mm','source_max_route_G_mm','ideal_support_front_index','ideal_support_sum_G_mm','ideal_support_max_route_G_mm','ideal_complete_support_set_loss_G_mm'])]
    for name,records,columns in schemas:
        with (ROOT/'reports'/name).open('x',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=columns,lineterminator='\n');writer.writeheader();writer.writerows(records)
    lines=['完整距离前沿：全权重支持性与理想完整支持集预算损失',
           '固定原12田合成任务/容量/有限图G整数毫米模型，继承已审85个完整前沿值点。',
           '计划12主有理分类+12独整数凸包验证，新增路线/TSP/完整前沿优化均为0。',
           '实际主分类已知启动%s槽、启动未知%s槽；独立凸包已知启动%s槽、启动未知%s槽；每侧计划与保留均12槽。'%(summary['main_counts']['known_spawned'],summary['main_counts']['unknown_spawned_slots'],summary['independent_counts']['known_spawned'],summary['independent_counts']['unknown_spawned_slots']),
           '核验%s/12田；85值点、72固定预算行均保留。点/预算/分组不是独立科学样本。'%summary['verified_fields'],
           'UNSUPPORTED：没有任何非负非零权重可使该值点最优；SUPPORTED_TIE_ONLY：仅单点λ并列可达；SUPPORTED_INTERVAL：存在正长度权重区间。',
           'λS+(1−λ)M含端点0与1。支持不保证某固定tie规则返回给定Pcode，也不保证分组或路线唯一。',
           '各田分类：']
    for row in rows:
        lines.append(row['instance_id']+'：'+(json.dumps(row['class_counts'],ensure_ascii=False,sort_keys=True) if row['eligible_for_primary'] else '未知，保留全部预期行。'))
    lines.append('理想完整支持集在同预算下的可达损失（整数G毫米）：')
    for row in rows:
        for q in row['queries']:
            lines.append(row['instance_id']+' p='+str(q['p'])+'%：'+('未知' if not row['eligible_for_primary'] else str(q['ideal_complete_support_set_loss_G_mm'])+' mm；原预算点 '+q['source_classification']))
    lines.extend(['该损失假定所有支持值点和共线并列最优点均已得到；不是实际权重扫描、求解器或自动算法生成的实验表现。',
                  '原模型只比较总距和最长路线距离负担，不代表工期、速度、能耗、实车效果或未见泛化。',
                  '结论对冻结G整数代理精确；旧路径取整误差界不保证物理长度下的凸包/支持性成员关系。',
                  '横纵不同正系数缩放保持支持集合，但改变λ区间；区间宽度不是概率或与单位无关的重要性。'])
    with (ROOT/'reports/REPORT_ZH.txt').open('x') as f:f.write('\n'.join(lines)+'\n')


if __name__=='__main__':
    main()
