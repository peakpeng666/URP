"""Unique hash-gated formal launch; audited process-tree runtime reused unchanged."""
import resource
from common import ROOT, read, save, sha, utc, inventory
from gates import main_ready
from tree_runtime import run_command
from process_groups import cleanup_registered


def author_outer_limits():
    resource.setrlimit(resource.RLIMIT_CPU, (20, 60))
    resource.setrlimit(resource.RLIMIT_AS, (134217728, 268435456))
    return {'cpu': list(resource.getrlimit(resource.RLIMIT_CPU)), 'as': list(resource.getrlimit(resource.RLIMIT_AS))}


def seal(dest, schedule, digest, outer):
    import json
    dest.mkdir(exist_ok=True)
    rows, malformed = [], []
    if (dest / 'results.jsonl').exists():
        for line_no, line in enumerate((dest / 'results.jsonl').read_text().splitlines()):
            try:
                rows.append(json.loads(line))
            except (ValueError, TypeError):
                malformed.append(line_no)
    by = {row['schedule']['call_id']: row for row in rows}
    allslots = []
    for slot in schedule:
        cid = slot['call_id']
        evidence = (dest / 'calls' / (cid + '.stdout')).exists() or (dest / 'active' / (cid + '.active.json')).exists()
        allslots.append(by.get(cid, {'schedule': slot,
            'status': 'UNKNOWN_AFTER_SUPERVISOR_FAILURE' if evidence else 'NOT_STARTED_SUPERVISOR_FAILURE',
            'process_spawned': 'UNKNOWN' if evidence else False}))
    save(dest / 'ALL_PLANNED_SLOTS.json', allslots)
    save(dest / 'OUTER_FINISHED.json', {'utc': utc(), 'frozen_files_sha256': digest, 'outer': outer, 'planned_fields': 12,
        'planned_objective_slots': 12, 'duplicate_call_ids': len(by) != len(rows), 'malformed_rows': malformed, 'status': 'RAW_MAIN_UNREVIEWED'})
    save(dest / 'RAW_MAIN_CONTENT_MANIFEST.json', {'utc': utc(), 'frozen_files_sha256': digest,
        'files': inventory(ROOT, [p for p in dest.rglob('*') if p.is_file()])})


def main():
    assert __debug__
    limits = author_outer_limits()
    digest = main_ready()
    save(ROOT / 'provenance/MAIN_LAUNCH_STARTED.json', {'utc': utc(), 'frozen_files_sha256': digest,
         'planned_fields': 12, 'planned_main_calls': 12, 'planned_independent_calls': 12,
         'whole_supervisor_tree_wall_seconds': 400, 'outer_limits': limits})
    outer = run_command(['/usr/bin/python3', ROOT / 'source/run_author_batch.py'], ROOT / 'provenance/author_supervisor',
                        15, 134217728, 400, ROOT / 'provenance/author_supervisor.active.json', cpu_hard=60, as_hard=268435456)
    cleanup = cleanup_registered(ROOT / 'raw/active')
    save(ROOT / 'provenance/WHOLE_TREE_CLEANUP.json', cleanup)
    if not cleanup['quiescent'] or (outer.get('process_spawned') and not (outer.get('registered_group_cleanup') or {}).get('quiescent')):
        raise RuntimeError('WHOLE_TREE_NOT_QUIESCENT')
    seal(ROOT / 'raw', read(ROOT / 'freeze/SCHEDULE.json'), digest, outer)
    print('Main12 raw evidence sealed. Private actual-byte readback required before independent objective window.')


if __name__ == '__main__':
    main()
