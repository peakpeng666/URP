"""Independent report/CSV audit from certified saved rows, no classification."""
import csv,statistics
from saved_audit import *

def ratio(v):return {'numerator':v.numerator,'denominator':v.denominator}
def fraction_text(v):return str(v['numerator'])+'/'+str(v['denominator'])
def expected_summary(a,fields,counts):
    eligible=set(a['eligible_instance_ids']);by={r['instance_id']:r for r in a['fields']};assert len(by)==len(fields)and set(by)==set(fields)
    good=[];records=[]
    for field,n in zip(fields,counts):
        x=by[field];assert (field in eligible)==x['valid_for_exact_conclusion']
        if field in eligible:
            assert len(x['points'])==n;good.append(x);records.append({'instance_id':field,'eligible_for_primary':True,'status':'VERIFIED','frontier_size':n,'class_counts':x['class_counts'],'queries':x['queries']})
        else:records.append({'instance_id':field,'eligible_for_primary':False,'status':'UNVERIFIED','frontier_size':n,'class_counts':None,'queries':[{'p':p,'status':'UNVERIFIED'}for p in(0,1,2,5,10,20)]})
    complete=len(good)==len(fields);counts={c:sum(x['class_counts'][c]for x in good)for c in CLASSES};out={'status':'COMPLETE_PANEL'if complete else'INCOMPLETE_PANEL_WITH_EXPLICIT_UNKNOWN_ROWS','planned_fields':len(fields),'verified_fields':len(good),'unverified_fields':len(fields)-len(good),'fields':records,'complete_panel_class_counts':counts if complete else None,'verified_only_class_counts':counts,'by_budget':[]}
    for p in(0,1,2,5,10,20):
        q=[next(z for z in x['queries']if z['p']==p)for x in good];v=sorted(z['ideal_complete_support_set_loss_G_mm']for z in q)
        r={'p':p,'planned_fields':len(fields),'verified_fields':len(q),'complete_panel_available':complete,'complete_panel_selected_class_counts':{c:sum(z['source_classification']==c for z in q)for c in CLASSES}if complete else None,'complete_panel_positive_loss_fields':sum(x>0 for x in v)if complete else None,'complete_panel_sum_loss_G_mm':sum(v)if complete else None,'complete_panel_max_loss_G_mm':max(v)if complete and v else None,'complete_panel_mean_loss_G_mm':ratio(Fraction(sum(v),len(v)))if complete and v else None,'complete_panel_median_loss_G_mm':None}
        if complete and v:
            k=len(v)//2;r['complete_panel_median_loss_G_mm']=ratio(Fraction(v[k])if len(v)%2 else Fraction(v[k-1]+v[k],2))
        out['by_budget'].append(r)
    return out

def compare_summary(s,a,fields,counts):
    e=expected_summary(a,fields,counts)
    for k,v in e.items():assert s[k]==v,('summary',k)
    return True

def check_csv(a,fields,counts,pointpath,budgetpath):
    by={r['instance_id']:r for r in a['fields']};pointrows=list(csv.DictReader(pointpath.open()));budgetrows=list(csv.DictReader(budgetpath.open()));assert len(pointrows)==sum(counts)and len(budgetrows)==6*len(fields);idx=0
    for field,n in zip(fields,counts):
        x=by[field]
        for j in range(n):
            r=pointrows[idx];idx+=1;assert r['instance_id']==field and int(r['front_index'])==j
            if not x['valid_for_exact_conclusion']:
                assert r['classification']=='UNKNOWN'and all(v==''for k,v in r.items()if k not in('instance_id','front_index','classification'));continue
            p=x['points'][j];assert r['classification']==p['classification']and int(r['sum_G_mm'])==p['sum_G_mm']and int(r['max_route_G_mm'])==p['max_route_G_mm'];assert r['lower_bound']==fraction_text(p['lower_bound'])and r['upper_bound']==fraction_text(p['upper_bound'])and r['interval_empty']==str(p['interval_empty'])
            for k in('lower_bound_competitors','upper_bound_competitors','inherited_witness'):assert json.loads(r[k])==p[k]
            assert r['source_main_stdout_sha256']==x['main_stdout_sha256']
    idx=0
    for field in fields:
        x=by[field]
        for p in(0,1,2,5,10,20):
            r=budgetrows[idx];idx+=1;assert r['instance_id']==field and int(r['p'])==p
            if not x['valid_for_exact_conclusion']:
                assert r['source_classification']=='UNKNOWN'and all(v==''for k,v in r.items()if k not in('instance_id','p','source_classification'));continue
            q=next(v for v in x['queries']if v['p']==p)
            for k in QUERY_KEYS:assert r[k]==str(q[k]),('budget csv',k)
    return {'point_rows':len(pointrows),'budget_rows':len(budgetrows)}

def main():
    assert __debug__;resource.setrlimit(resource.RLIMIT_CPU,(15,15));resource.setrlimit(resource.RLIMIT_AS,(268435456,268435456));signal.alarm(30);c=time.process_time();w=time.monotonic();h=frozen();rm=receipt(ROOT/'provenance/RAW_MAIN_DRIVE_RECEIPT.json','RAW_MAIN',h);rv=receipt(ROOT/'provenance/RAW_VERIFICATION_DRIVE_RECEIPT.json','RAW_VERIFICATION',h);a=read(ROOT/'independent_supervision/FINAL_AUDIT.json');s=read(ROOT/'reports/SUMMARY.json');protocol=read(ROOT/'freeze/PROTOCOL.json')
    assert a['status']in('PASS','AUDIT_COMPLETE_WITH_UNVERIFIED_SLOTS')
    for x in(a,s):assert x['frozen_files_sha256']==h and x['raw_main_archive_sha256']==rm['sha256']and x['raw_verification_archive_sha256']==rv['sha256']
    assert s['independent_audit_sha256']==sha(ROOT/'independent_supervision/FINAL_AUDIT.json');compare_summary(s,a,protocol['fields'],protocol['inherited_field_point_counts']);assert s['planned_main_classification_calls']==s['planned_independent_hull_calls']==12 and s['planned_value_rows']==85 and s['planned_budget_comparison_rows']==72 and s['new_classification_calls']==s['new_route_optimization_calls']==0
    assert s['main_counts']==a['main_counts']and s['independent_counts']==a['independent_counts']
    csvs=check_csv(a,protocol['fields'],protocol['inherited_field_point_counts'],ROOT/'reports/POINT_CLASSIFICATION.csv',ROOT/'reports/BUDGET_SUPPORT_LOSS.csv')
    text=(ROOT/'reports/REPORT_ZH.txt').read_text()
    for phrase in('85','72','12','非负','并列','区间','整数','泛化','工期','同预算','实际'):assert phrase in text,('reader boundary',phrase)
    result={'status':'PASS','utc':utc(),'frozen_files_sha256':h,'raw_main_archive_sha256':rm['sha256'],'raw_verification_archive_sha256':rv['sha256'],'report_sha256':sha(ROOT/'reports/REPORT_ZH.txt'),'summary_sha256':sha(ROOT/'reports/SUMMARY.json'),'independent_audit_sha256':sha(ROOT/'independent_supervision/FINAL_AUDIT.json'),'point_csv_sha256':sha(ROOT/'reports/POINT_CLASSIFICATION.csv'),'budget_csv_sha256':sha(ROOT/'reports/BUDGET_SUPPORT_LOSS.csv'),'csv_rows':csvs,'new_classification_calls':0,'new_route_optimization_calls':0,'resources':{'cpu_seconds':time.process_time()-c,'wall_seconds':time.monotonic()-w}};save(ROOT/'independent_supervision/FINAL_REPORT_REVIEW.json',result);print(json.dumps(result))
if __name__=='__main__':main()
