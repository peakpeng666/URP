"""Check saved rational and convexity certificates, never run a classifier."""
import pathlib,sys,json,hashlib,zipfile,resource,signal,time,collections
from fractions import Fraction
ROOT=pathlib.Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'source'))
from common import read,save,sha,utc,verify_map
from gates import frozen,receipt
from read_frontier import load_input,FIELDS,PARENT_SHA
CLASSES=('UNSUPPORTED','SUPPORTED_TIE_ONLY','SUPPORTED_INTERVAL')
POINT_KEYS=('index','sum_G_mm','max_route_G_mm','classification','source_point_index')
QUERY_KEYS=('p','budget_total_G_mm','source_front_index','source_classification','source_sum_G_mm','source_max_route_G_mm','ideal_support_front_index','ideal_support_sum_G_mm','ideal_support_max_route_G_mm','ideal_complete_support_set_loss_G_mm')
WITNESS=('partition','group_masks','routes','route_G_mm','assignment_multiplicity_unlabeled')
def frac(x):
    assert set(x)=={'numerator','denominator'}and type(x['numerator'])is int and type(x['denominator'])is int and x['denominator']>0
    f=Fraction(x['numerator'],x['denominator']);assert f.numerator==x['numerator']and f.denominator==x['denominator'];return f

def raw_check(base,name,r,h):
    m=read(base/name);assert m['frozen_files_sha256']==h;verify_map(ROOT,m['files'])
    with zipfile.ZipFile(r['download_path'])as z:
        for rel,v in m['files'].items():
            b=z.read(rel);assert b==(ROOT/rel).read_bytes()and len(b)==v['bytes']and hashlib.sha256(b).hexdigest()==v['sha256']
        assert z.read(str((base/name).relative_to(ROOT)))==(base/name).read_bytes()
    return len(m['files'])
def ledger(base,schedule):
    rows=read(base/'ALL_PLANNED_SLOTS.json');assert len(rows)==12 and [r['schedule']for r in rows]==schedule
    o=read(base/'OUTER_FINISHED.json');assert not o['duplicate_call_ids']and not o['malformed_rows']
    return rows,{'planned':12,'known_spawned':sum(r.get('process_spawned')is True for r in rows),'unknown_spawned_slots':sum(r.get('process_spawned')not in(True,False)for r in rows),'retained':12}
def check_points(out,points,lane):
    rows=out['points'];assert len(rows)==len(points)and out['complete_weight_coverage']is True
    for i,(r,p)in enumerate(zip(rows,points)):
        assert r['index']==r['source_point_index']==i and r['sum_G_mm']==p['sum_G_mm']and r['max_route_G_mm']==p['max_route_G_mm'];assert r['classification']in CLASSES
        assert r['inherited_witness']=={k:p[k]for k in WITNESS};cat=r['classification']
        if lane=='independent'and cat=='UNSUPPORTED':
            assert r['lower_bound']is None and r['upper_bound']is None and r['interval_empty']is True and r['bounds_closed']is False
            left,right=r['enclosing_hull_indices'];assert 0<=left<i<right<len(points);a,b=points[left],points[right];area=(b['sum_G_mm']-a['sum_G_mm'])*(p['max_route_G_mm']-a['max_route_G_mm'])-(b['max_route_G_mm']-a['max_route_G_mm'])*(p['sum_G_mm']-a['sum_G_mm']);assert area==r['positive_cross_product']and area>0
            assert rows[left]['classification']!='UNSUPPORTED'and rows[right]['classification']!='UNSUPPORTED'
            continue
        lo,hi=frac(r['lower_bound']),frac(r['upper_bound']);assert 0<=lo<=1 and 0<=hi<=1
        assert (cat=='UNSUPPORTED')==(lo>hi)and(cat=='SUPPORTED_TIE_ONLY')==(lo==hi)and(cat=='SUPPORTED_INTERVAL')==(lo<hi)
        assert r['interval_empty']==(lo>hi)and r['bounds_closed']==(lo<=hi)
        if lane=='main':
            lower=[];upper=[]
            for j,q in enumerate(points):
                if i==j:continue
                ds=p['sum_G_mm']-q['sum_G_mm'];dm=p['max_route_G_mm']-q['max_route_G_mm'];bound=-Fraction(dm,ds-dm)
                if j<i:
                    assert hi<=bound
                    if hi==bound:upper.append(j)
                else:
                    assert lo>=bound
                    if lo==bound:lower.append(j)
            assert r['lower_bound_competitors']==lower and r['upper_bound_competitors']==upper
            assert lo==0 or lower;assert hi==1 or upper
        if cat!='UNSUPPORTED':
            for w in(lo,hi):
                value=w*p['sum_G_mm']+(1-w)*p['max_route_G_mm']
                assert all(w*q['sum_G_mm']+(1-w)*q['max_route_G_mm']>=value for q in points)
    assert out['class_counts']=={c:sum(r['classification']==c for r in rows)for c in CLASSES}
    assert rows[0]['classification']==rows[-1]['classification']=='SUPPORTED_INTERVAL'
    intervals=sorted((frac(r['lower_bound']),frac(r['upper_bound']))for r in rows if r['classification']=='SUPPORTED_INTERVAL')
    assert intervals[0][0]==0 and intervals[-1][1]==1 and all(a[1]==b[0]for a,b in zip(intervals,intervals[1:]))and sum((b-a for a,b in intervals),Fraction(0))==1
    assert out['new_route_optimization_calls']==out['new_frontier_optimization_calls']==0
    if lane=='main':assert out['directed_pair_constraints']==len(points)*(len(points)-1)
    return rows

def check_queries(out,points,oldqueries,labels):
    rows=out['queries'];assert len(rows)==6 and [r['p']for r in rows]==[0,1,2,5,10,20]and out['derived_comparison_rows']==6
    for r,old in zip(rows,oldqueries):
        threshold=points[0]['sum_G_mm']*(100+r['p'])//100;assert r['budget_total_G_mm']==old['budget_total_G_mm']==threshold
        src=points[r['source_front_index']];sup=points[r['ideal_support_front_index']];assert old['front_index']==src['index'];assert r['source_classification']==labels[src['index']]['classification'];assert labels[sup['index']]['classification']!='UNSUPPORTED'
        assert src['sum_G_mm']<=threshold and sup['sum_G_mm']<=threshold
        for prefix,p in(('source',src),('ideal_support',sup)):
            assert r[prefix+'_sum_G_mm']==p['sum_G_mm']and r[prefix+'_max_route_G_mm']==p['max_route_G_mm']
        for p,label in zip(points,labels):
            if p['sum_G_mm']<=threshold:
                assert src['max_route_G_mm']<=p['max_route_G_mm']
                if label['classification']!='UNSUPPORTED':assert sup['max_route_G_mm']<=p['max_route_G_mm']
        loss=sup['max_route_G_mm']-src['max_route_G_mm'];assert loss==r['ideal_complete_support_set_loss_G_mm']and loss>=0 and(loss>0)==(r['source_classification']=='UNSUPPORTED')
    return rows

def audit():
    h=frozen();rm=receipt(ROOT/'provenance/RAW_MAIN_DRIVE_RECEIPT.json','RAW_MAIN',h);rv=receipt(ROOT/'provenance/RAW_VERIFICATION_DRIVE_RECEIPT.json','RAW_VERIFICATION',h)
    manifests=[raw_check(ROOT/'raw','RAW_MAIN_CONTENT_MANIFEST.json',rm,h),raw_check(ROOT/'independent_supervision/raw','RAW_VERIFICATION_CONTENT_MANIFEST.json',rv,h)]
    schedule=read(ROOT/'freeze/SCHEDULE.json');assert len(schedule)==12 and [r['instance_id']for r in schedule]==list(FIELDS)
    main,mc=ledger(ROOT/'raw',schedule);ind,ic=ledger(ROOT/'independent_supervision/raw',schedule);fields=[];ident=read(ROOT/'input/PARENT_MEMBER_IDENTITIES.json')
    with zipfile.ZipFile(ROOT/'input/PARENT_FINAL.zip')as z:
        for slot,mrec,irec in zip(schedule,main,ind):
            cid,f=slot['call_id'],slot['instance_id'];row={'instance_id':f,'call_id':cid,'valid_for_exact_conclusion':False,'failure':None}
            try:
                for r in(mrec,irec):assert r.get('status')=='UNREVIEWED_PROCESS_SUCCESS'and not r.get('error')and r.get('process_spawned')is True and r.get('returncode')==0 and r.get('child_reaped')is True and(r.get('registered_group_cleanup')or{}).get('quiescent')is True
                points,oldqueries,identity=load_input(f);member=f'raw/calls/{f}_FRONTIER.stdout';b=z.read(member);expected=ident['selected_member_identities'][member];assert len(b)==expected['bytes']and hashlib.sha256(b).hexdigest()==expected['sha256'];oldmain=json.loads(b)
                for x,y in zip(oldmain['frontier'],points):assert x==y
                assert len(oldmain['frontier'])==len(points)
                aa=read(ROOT/f'raw/calls/{cid}.stdout');bb=read(ROOT/f'independent_supervision/raw/calls/{cid}.stdout')
                for obj in(aa,bb):assert obj['instance_id']==f and obj['objective']=='SUPPORT_CLASSIFICATION'and obj['frozen_files_sha256']==h
                assert aa['status']=='EXACT_MATHEMATICAL_CLASSIFICATION_UNAUDITED'and bb['status']=='PROCESS_SUCCESS_UNREVIEWED'
                assert aa['input_identity']=={'parent_final_sha256':PARENT_SHA,'member':member,**expected}and bb['input_identity']==identity
                ar=check_points(aa,points,'main');br=check_points(bb,points,'independent')
                for x,y in zip(ar,br):
                    assert all(x[k]==y[k]for k in POINT_KEYS)
                    if x['classification']!='UNSUPPORTED':assert x['lower_bound']==y['lower_bound']and x['upper_bound']==y['upper_bound']
                aq=check_queries(aa,points,oldqueries,ar);bq=check_queries(bb,points,oldqueries,br)
                for x,y in zip(aq,bq):assert all(x[k]==y[k]for k in QUERY_KEYS)
                row.update(valid_for_exact_conclusion=True,main_stdout_sha256=sha(ROOT/f'raw/calls/{cid}.stdout'),independent_stdout_sha256=sha(ROOT/f'independent_supervision/raw/calls/{cid}.stdout'),point_count=len(points),class_counts=aa['class_counts'],points=ar,queries=aq)
            except (AssertionError,KeyError,ValueError,TypeError,OSError,IndexError)as e:row['failure']=type(e).__name__+':'+str(e)
            fields.append(row)
    eligible=[r['instance_id']for r in fields if r['valid_for_exact_conclusion']]
    return {'status':'PASS'if len(eligible)==12 else'AUDIT_COMPLETE_WITH_UNVERIFIED_SLOTS','frozen_files_sha256':h,'raw_main_archive_sha256':rm['sha256'],'raw_verification_archive_sha256':rv['sha256'],'parent_final_sha256':PARENT_SHA,'eligible_instance_ids':eligible,'verified_fields':len(eligible),'planned_fields':12,'planned_main_calls':12,'planned_independent_calls':12,'planned_classification_slots':24,'planned_point_rows':85,'planned_derived_budget_rows':72,'main_counts':mc,'independent_counts':ic,'fields':fields,'raw_manifest_members_checked':manifests,'new_route_or_frontier_optimization_calls':0,'new_classification_calls_in_saved_audit':0}
def main():
    assert __debug__;resource.setrlimit(resource.RLIMIT_CPU,(15,15));resource.setrlimit(resource.RLIMIT_AS,(268435456,268435456));signal.alarm(30)
    c=time.process_time();w=time.monotonic();save(ROOT/'independent_supervision/SAVED_AUDIT_STARTED.json',{'utc':utc(),'new_classification_calls':0,'new_route_optimization_calls':0});x=audit();x.update(utc=utc(),resources={'cpu_seconds':time.process_time()-c,'wall_seconds':time.monotonic()-w,'maxrss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss});save(ROOT/'independent_supervision/FINAL_AUDIT.json',x);print(json.dumps({'status':x['status'],'verified_fields':x['verified_fields']}))
if __name__=='__main__':main()
