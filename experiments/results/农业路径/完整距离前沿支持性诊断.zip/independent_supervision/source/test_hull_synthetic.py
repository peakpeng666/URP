"""Invented integer antichains only; arrangement-of-weights oracle is test-only."""
import json,resource,signal,time
from pathlib import Path
from fractions import Fraction
from hull_support import classify,join_budgets,PERCENTAGES

def points(x):return [{'index':i,'sum_G_mm':s,'max_route_G_mm':m}for i,(s,m)in enumerate(x)]
def oracle(ps):
    weights={Fraction(0),Fraction(1)}
    for a in ps:
        for b in ps:
            ds=a['sum_G_mm']-b['sum_G_mm'];dm=a['max_route_G_mm']-b['max_route_G_mm']
            if ds!=dm:
                w=-Fraction(dm,ds-dm)
                if 0<=w<=1:weights.add(w)
    weights=sorted(weights);mids=[(a+b)/2 for a,b in zip(weights,weights[1:])];out=[]
    def winners(w):
        vals=[w*p['sum_G_mm']+(1-w)*p['max_route_G_mm']for p in ps];best=min(vals);return {i for i,v in enumerate(vals)if v==best}
    exact=[winners(w)for w in weights];open_=[winners(w)for w in mids]
    for i in range(len(ps)):
        wins=[w for w,ids in zip(weights,exact)if i in ids]
        category='SUPPORTED_INTERVAL'if any(i in ids for ids in open_)else'SUPPORTED_TIE_ONLY'if wins else'UNSUPPORTED'
        out.append((category,min(wins)if wins else None,max(wins)if wins else None))
    return out

def main():
    resource.setrlimit(resource.RLIMIT_CPU,(15,15));resource.setrlimit(resource.RLIMIT_AS,(256*1024**2,256*1024**2));signal.alarm(30);cpu=time.process_time();wall=time.monotonic()
    fixtures=[[(100,90)],[(100,90),(102,34)],[(100,90),(101,71),(102,34)],[(100,90),(101,62),(102,34)],[(100,90),(101,50),(102,34)],[(100,90),(101,82),(102,74),(103,73),(104,50),(105,20)],[(10**25,10**25+1),(10**25+1,10**25),(10**25+3,10**25-1)]]
    count=0
    for f in fixtures:
        for xs,ys in ((1,1),(7,3)):
            ps=points([(xs*s,ys*m)for s,m in f]);out=classify(ps);expected=oracle(ps);count+=1
            for p,(cat,lo,hi)in zip(out['points'],expected):
                assert p['classification']==cat
                if lo is not None:
                    assert Fraction(**{'numerator':p['lower_bound']['numerator'],'denominator':p['lower_bound']['denominator']})==lo
                    assert Fraction(p['upper_bound']['numerator'],p['upper_bound']['denominator'])==hi
            qs=[]
            for p in PERCENTAGES:
                t=ps[0]['sum_G_mm']*(100+p)//100;x=min((q for q in ps if q['sum_G_mm']<=t),key=lambda q:q['max_route_G_mm']);qs.append(dict(p=p,budget_total_G_mm=t,front_index=x['index'],sum_G_mm=x['sum_G_mm'],max_route_G_mm=x['max_route_G_mm']))
            rows=join_budgets(ps,qs,out)['queries']
            for r in rows:assert (r['ideal_complete_support_set_loss_G_mm']>0)==(r['source_classification']=='UNSUPPORTED')
    # A nonconvex middle point must be missed by every weighted sum.
    ps=points(fixtures[2]);a=classify(ps);assert [p['classification']for p in a['points']]==['SUPPORTED_INTERVAL','UNSUPPORTED','SUPPORTED_INTERVAL']
    # Collinear points are restored and count as obtainable ties.
    b=classify(points(fixtures[3]));assert b['points'][1]['classification']=='SUPPORTED_TIE_ONLY'
    invalid=[[],points([(1,1),(1,0)]),points([(1,1),(2,1)]),[{'index':0,'sum_G_mm':True,'max_route_G_mm':3}]]
    for p in invalid:
        try:classify(p)
        except ValueError:pass
        else:raise AssertionError('invalid accepted')
    out={'status':'PASS','invented_classification_calls':count+2,'new_route_or_frontier_optimization_calls':0,'real_classification_calls':0,'full_weight_arrangement_oracle_cases':count,'invalid_inputs_rejected':len(invalid),'resources':{'cpu_seconds':time.process_time()-cpu,'wall_seconds':time.monotonic()-wall}}
    root=Path(__file__).resolve().parents[1];p=root/'selftests/HULL_SYNTHETIC_R1.json'
    with p.open('x')as f:json.dump(out,f,indent=2);f.write('\n')
    print(json.dumps(out))
if __name__=='__main__':main()
