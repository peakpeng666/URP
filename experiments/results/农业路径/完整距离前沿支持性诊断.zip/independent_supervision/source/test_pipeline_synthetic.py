"""Two invented-only worker calls through the reused bounded runtime and saved certificate checker."""
import pathlib,sys,json,hashlib,zipfile,shutil,time,resource,signal,copy
BASE=pathlib.Path(__file__).resolve().parents[2];sys.path.insert(0,str(BASE/'source'))
from tree_runtime import run_command
from saved_audit import check_points,check_queries,POINT_KEYS,QUERY_KEYS

def write(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2))
def main():
    resource.setrlimit(resource.RLIMIT_CPU,(20,60));resource.setrlimit(resource.RLIMIT_AS,(268435456,268435456));signal.alarm(60);c=time.process_time();w=time.monotonic();r=BASE/'independent_supervision/selftests/pipeline_r1';r.mkdir();field='INVENTED_SUPPORT';h='INVENTED_ONLY_NO_REAL_AUTHORITY'
    (r/'INVENTED_ONLY.txt').write_text('Synthetic source archive and explicit gate stubs. No real field values or formal receipt. Two classification calls, zero route/frontier optimization.\n')
    points=[]
    for i,(S,M)in enumerate(((100,100),(101,80),(102,60),(103,59),(104,50))):points.append({'index':i,'sum_G_mm':S,'max_route_G_mm':M,'partition':[[1],[2],[3]],'group_masks':[1,2,4],'routes':[[0,1,0],[0,2,0],[0,3,0]],'route_G_mm':[M,S-M,0],'assignment_multiplicity_unlabeled':1})
    queries=[]
    for p in(0,1,2,5,10,20):
        threshold=100*(100+p)//100;v=next(q for q in reversed(points)if q['sum_G_mm']<=threshold);queries.append({'p':p,'budget_total_G_mm':threshold,'front_index':v['index'],**{k:v[k]for k in ('sum_G_mm','max_route_G_mm','partition','group_masks','routes','route_G_mm')}})
    prior={'instance_id':field,'objective':'FRONTIER','status':'PROCESS_SUCCESS_UNREVIEWED','frozen_files_sha256':'INVENTED_PARENT','frontier_size':5,'frontier':points,'queries':queries};prioraudit={'status':'PASS','eligible_instance_ids':[field],'fields':[{'instance_id':field,'valid_for_exact_conclusion':True,'frontier':points,'queries':queries}]};members={f'raw/calls/{field}_FRONTIER.stdout':json.dumps(prior).encode(),f'independent_supervision/raw/calls/{field}_FRONTIER.stdout':json.dumps(prior).encode(),'independent_supervision/FINAL_AUDIT.json':json.dumps(prioraudit).encode()}
    (r/'input').mkdir();zpath=r/'input/PARENT_FINAL.zip'
    with zipfile.ZipFile(zpath,'x')as z:
        for k,v in members.items():z.writestr(k,v)
    digest=hashlib.sha256(zpath.read_bytes()).hexdigest();write(r/'input/PARENT_MEMBER_IDENTITIES.json',{'status':'PARENT_FINAL_PRIVATE_ACTUAL_BYTE_READBACK_BOUND','parent_zip':'input/PARENT_FINAL.zip','sha256':digest,'selected_member_identities':{k:{'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()}for k,v in members.items()}})
    write(r/'freeze/PROTOCOL.json',{'fields':[field],'input':{'parent_final_sha256':digest,'parent_frozen_sha256':'INVENTED_PARENT'},'inherited_field_point_counts':[5]});write(r/'provenance/VALIDATION_LAUNCH_STARTED.json',{'frozen_files_sha256':h})
    replacements=[]
    for sub,names in [('source',['common.py','author_worker.py','classify_main.py']),('independent_supervision/source',['independent_worker.py','read_frontier.py','hull_support.py'])]:
        for name in names:
            source=BASE/sub/name;dest=r/sub/name;dest.parent.mkdir(parents=True,exist_ok=True);text=source.read_text()
            if name=='read_frontier.py':
                text=text.replace("PARENT_SHA='a6942279323fa38b743577653b6212893f9a33e585f5c2c9ed483ae9baf0b5d2'",'PARENT_SHA='+repr(digest)).replace("FIELDS=tuple('nl_field_'+str(i)for i in(40,44,63,187,1,2,7,8,17,67,89,143))",'FIELDS=("INVENTED_SUPPORT",)')
                replacements.append({'file':sub+'/'+name,'scope':'Fixture-only archive SHA and field whitelist; original production file unchanged'})
            dest.write_text(text)
    (r/'source/gates.py').write_text("from pathlib import Path\nassert 'selftests' in Path(__file__).parts\ndef active_main_gate():return '"+h+"'\ndef active_verification_gate():return '"+h+"'\n")
    runs=[];values=[]
    for lane,path in [('main','source/author_worker.py'),('independent','independent_supervision/source/independent_worker.py')]:
        record=run_command(['/usr/bin/python3','-B',r/path,field,'SUPPORT_CLASSIFICATION'],r/(lane+'_call'),15,268435456,30,r/'active'/(lane+'.active.json'));write(r/(lane+'_RUN.json'),record);assert record['status']=='UNREVIEWED_PROCESS_SUCCESS'and record['registered_group_cleanup']['quiescent'];out=json.loads((r/(lane+'_call.stdout')).read_text());values.append(out);check_points(out,points,lane);check_queries(out,points,queries,out['points']);runs.append(record['status'])
    a,b=values
    for x,y in zip(a['points'],b['points']):
        assert all(x[k]==y[k]for k in POINT_KEYS)
        if x['classification']!='UNSUPPORTED':assert x['lower_bound']==y['lower_bound']and x['upper_bound']==y['upper_bound']
    for x,y in zip(a['queries'],b['queries']):assert all(x[k]==y[k]for k in QUERY_KEYS)
    rejected=0
    for kind in ('bound','class','cross','budget'):
        d=copy.deepcopy(b)
        if kind=='bound':d['points'][0]['lower_bound']['numerator']+=1
        elif kind=='class':d['points'][1]['classification']='UNSUPPORTED'
        elif kind=='cross':d['points'][3]['positive_cross_product']+=1
        else:d['queries'][1]['ideal_complete_support_set_loss_G_mm']+=1
        try:check_points(d,points,'independent');check_queries(d,points,queries,d['points'])
        except (AssertionError,KeyError):rejected+=1
        else:raise AssertionError('changed certificate accepted:'+kind)
    result={'status':'PASS','invented_main_classification_calls':1,'invented_independent_classification_calls':1,'real_classification_calls':0,'new_route_or_frontier_optimization_calls':0,'source_copy_changes':replacements,'explicit_synthetic_gate_stub':True,'two_bounded_calls':runs,'certificate_mutations_rejected':rejected,'observed_classes':[p['classification']for p in b['points']],'resources':{'cpu_seconds':time.process_time()-c,'wall_seconds':time.monotonic()-w}};write(BASE/'independent_supervision/selftests/PIPELINE_R1.json',result);print(json.dumps(result))
if __name__=='__main__':main()
