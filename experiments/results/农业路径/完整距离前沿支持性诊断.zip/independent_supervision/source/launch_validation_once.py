import pathlib,sys,resource,json
ROOT=pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'source'))
from common import read,save,sha,utc,inventory
from gates import verification_ready
from tree_runtime import run_command
from process_groups import cleanup_registered

def seal(dest,schedule,digest,outer):
    dest.mkdir(exist_ok=True);rows=[];malformed=[]
    if (dest/'results.jsonl').exists():
        for i,line in enumerate((dest/'results.jsonl').read_text().splitlines()):
            try:rows.append(json.loads(line))
            except ValueError:malformed.append(i)
    by={r['schedule']['call_id']:r for r in rows};allslots=[]
    for slot in schedule:
        cid=slot['call_id'];evidence=(dest/'calls'/(cid+'.stdout')).exists() or (dest/'active'/(cid+'.active.json')).exists()
        allslots.append(by.get(cid,{'schedule':slot,'status':'UNKNOWN_AFTER_SUPERVISOR_FAILURE' if evidence else 'NOT_STARTED_SUPERVISOR_FAILURE','process_spawned':'UNKNOWN' if evidence else False}))
    save(dest/'ALL_PLANNED_SLOTS.json',allslots)
    save(dest/'OUTER_FINISHED.json',{'utc':utc(),'frozen_files_sha256':digest,'outer':outer,'planned_fields':12,
         'planned_objective_slots':12,'duplicate_call_ids':len(by)!=len(rows),'malformed_rows':malformed,'status':'RAW_VERIFICATION_UNREVIEWED'})
    save(dest/'RAW_VERIFICATION_CONTENT_MANIFEST.json',{'utc':utc(),'frozen_files_sha256':digest,
         'files':inventory(ROOT,[p for p in dest.rglob('*') if p.is_file()])})

def main():
    assert __debug__
    resource.setrlimit(resource.RLIMIT_CPU,(20,60));resource.setrlimit(resource.RLIMIT_AS,(134217728,268435456))
    digest=verification_ready();dest=ROOT/'independent_supervision/raw'
    assert not dest.exists()
    save(ROOT/'provenance/VALIDATION_LAUNCH_STARTED.json',{'utc':utc(),'frozen_files_sha256':digest,
         'planned_fields':12,'planned_independent_calls':12,'planned_verification_calls':12,'whole_supervisor_tree_wall_seconds':400,
         'outer_limits':{'cpu':list(resource.getrlimit(resource.RLIMIT_CPU)),'as':list(resource.getrlimit(resource.RLIMIT_AS))}})
    outer=run_command(['/usr/bin/python3',ROOT/'independent_supervision/source/run_validation_batch.py'],ROOT/'provenance/verification_supervisor',15,134217728,400,ROOT/'provenance/verification_supervisor.active.json',cpu_hard=60,as_hard=268435456)
    cleanup=cleanup_registered(dest/'active');save(ROOT/'provenance/VALIDATION_WHOLE_TREE_CLEANUP.json',cleanup)
    if not cleanup['quiescent'] or (outer.get('process_spawned') and not (outer.get('registered_group_cleanup') or {}).get('quiescent')):
        raise RuntimeError('WHOLE_TREE_NOT_QUIESCENT')
    seal(dest,read(ROOT/'freeze/SCHEDULE.json'),digest,outer)
    print('Independent12 raw sealed; private actual-byte readback required before comparison.')
if __name__=='__main__':main()
