"""Read only the former independent frontier output from its sealed parent ZIP."""
import hashlib,json,zipfile
from pathlib import Path
from hull_support import validate,require
ROOT=Path(__file__).resolve().parents[2]
PARENT_SHA='a6942279323fa38b743577653b6212893f9a33e585f5c2c9ed483ae9baf0b5d2'
FIELDS=tuple('nl_field_'+str(i)for i in(40,44,63,187,1,2,7,8,17,67,89,143))
def load_input(field):
    require(field in FIELDS,'fixed field');meta=json.loads((ROOT/'input/PARENT_MEMBER_IDENTITIES.json').read_text());archive=ROOT/'input/PARENT_FINAL.zip';require(hashlib.sha256(archive.read_bytes()).hexdigest()==meta['sha256']==PARENT_SHA,'parent archive')
    name=f'independent_supervision/raw/calls/{field}_FRONTIER.stdout';expected=meta['selected_member_identities'][name]
    with zipfile.ZipFile(archive)as z:
        b=z.read(name);require(len(b)==expected['bytes']and hashlib.sha256(b).hexdigest()==expected['sha256'],'parent independent raw bytes');data=json.loads(b)
        aname='independent_supervision/FINAL_AUDIT.json';ab=z.read(aname);require(hashlib.sha256(ab).hexdigest()==meta['selected_member_identities'][aname]['sha256'],'prior audit bytes');audit=json.loads(ab);require(audit['status']=='PASS'and field in audit['eligible_instance_ids'],'prior field verified')
    require(data['instance_id']==field and data['objective']=='FRONTIER'and data['status']=='PROCESS_SUCCESS_UNREVIEWED','parent output identity');points=data['frontier'];queries=data['queries'];validate(points);require(len(points)==data['frontier_size'],'parent point count')
    verified=next(r for r in audit['fields']if r['instance_id']==field);require(verified['valid_for_exact_conclusion']and verified['frontier']==points,'prior independently matched points')
    require(len(queries)==len(verified['queries'])==6,'six inherited queries')
    for q,x in zip(queries,verified['queries']):
        for k in('p','budget_total_G_mm','front_index','sum_G_mm','max_route_G_mm','partition','routes','route_G_mm'):require(q[k]==x[k],'prior matched query')
    return points,queries,{'parent_archive_sha256':PARENT_SHA,'member':name,'member_sha256':expected['sha256'],'source_side':'independent_saved_frontier','parent_final_audit_sha256':hashlib.sha256(ab).hexdigest()}
