"""Only copy saved invented five-point outputs; no classifier invocation."""
import pathlib,sys,json,hashlib,copy,importlib.util,resource,signal,time
BASE=pathlib.Path(__file__).resolve().parents[2];sys.path.insert(0,str(BASE/'source'))
from review_final import compare_summary,check_csv

def dump(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2))
def main():
 resource.setrlimit(resource.RLIMIT_CPU,(15,15));resource.setrlimit(resource.RLIMIT_AS,(268435456,268435456));signal.alarm(30);cpu=time.process_time();wall=time.monotonic();saved=json.loads((BASE/'independent_supervision/selftests/pipeline_r1/main_call.stdout').read_text());spec=importlib.util.spec_from_file_location('author_report_replay',BASE/'source/report.py');report=importlib.util.module_from_spec(spec);spec.loader.exec_module(report);fields=['INVENTED_REPORT_'+str(i)for i in range(12)];results=[]
 for partial in(False,True):
  root=BASE/'independent_supervision/selftests'/('report_partial'if partial else'report_full');root.mkdir();h='INVENTED_ONLY_NOT_FORMAL';entries=[];eligible=fields[:-1]if partial else fields
  for i,f in enumerate(fields):
   x=copy.deepcopy(saved);x.update(instance_id=f,frozen_files_sha256=h);mp=root/f'raw/calls/{f}_SUPPORT.stdout';ip=root/f'independent_supervision/raw/calls/{f}_SUPPORT.stdout';dump(mp,x);dump(ip,x);entries.append({'instance_id':f,'valid_for_exact_conclusion':f in eligible,'failure':None if f in eligible else'INVENTED_MISSING','main_stdout_sha256':hashlib.sha256(mp.read_bytes()).hexdigest(),'independent_stdout_sha256':hashlib.sha256(ip.read_bytes()).hexdigest(),'points':x['points'],'queries':x['queries'],'class_counts':x['class_counts']})
  a={'status':'PASS'if not partial else'AUDIT_COMPLETE_WITH_UNVERIFIED_SLOTS','frozen_files_sha256':h,'raw_main_archive_sha256':'INVENTED_MAIN','raw_verification_archive_sha256':'INVENTED_IND','eligible_instance_ids':eligible,'fields':entries,'main_counts':{'planned':12,'retained':12,'known_spawned':12,'unknown_spawned_slots':0},'independent_counts':{'planned':12,'retained':12,'known_spawned':11 if partial else 12,'unknown_spawned_slots':1 if partial else 0}}
  dump(root/'independent_supervision/FINAL_AUDIT.json',a);dump(root/'freeze/PROTOCOL.json',{'fields':fields,'inherited_field_point_counts':[5]*12});dump(root/'raw/RAW_MAIN_CONTENT_MANIFEST.json',{'files':{}});dump(root/'independent_supervision/raw/RAW_VERIFICATION_CONTENT_MANIFEST.json',{'files':{}})
  report.ROOT=root;report.frozen=lambda:h;report.receipt=lambda path,stage,digest:{'sha256':'INVENTED_MAIN'if stage=='RAW_MAIN'else'INVENTED_IND'};report.main();s=json.loads((root/'reports/SUMMARY.json').read_text());compare_summary(s,a,fields,[5]*12);csvs=check_csv(a,fields,[5]*12,root/'reports/POINT_CLASSIFICATION.csv',root/'reports/BUDGET_SUPPORT_LOSS.csv');assert s['main_counts']==a['main_counts']and s['independent_counts']==a['independent_counts'];results.append({'partial':partial,'verified_fields':s['verified_fields'],**csvs})
  if partial:assert s['complete_panel_class_counts']is None and all(r['complete_panel_mean_loss_G_mm']is None for r in s['by_budget'])
 out={'status':'PASS','invented_saved_report_cases':results,'explicit_fixture_gate_stubs':True,'new_classification_calls':0,'new_route_or_frontier_optimization_calls':0,'resources':{'cpu_seconds':time.process_time()-cpu,'wall_seconds':time.monotonic()-wall}};dump(BASE/'independent_supervision/selftests/REPORT_SAVED_R2.json',out);print(json.dumps(out))
if __name__=='__main__':main()
