"""Independent integer lower convex chain; collinear value points are restored.
No main-author imports, route selection, local TSP, or source-file reads.
"""
from fractions import Fraction

CLASSES=('UNSUPPORTED','SUPPORTED_TIE_ONLY','SUPPORTED_INTERVAL')
PERCENTAGES=(0,1,2,5,10,20)

def rat(v):return {'numerator':v.numerator,'denominator':v.denominator}
def require(ok,msg):
    if not ok:raise ValueError(msg)
def validate(points):
    require(type(points)is list and len(points)>0,'nonempty source frontier')
    for i,p in enumerate(points):
        require(type(p)is dict and type(p.get('index'))is int and p['index']==i,'source index')
        require(all(type(p.get(k))is int and p[k]>=0 for k in ('sum_G_mm','max_route_G_mm')),'integer objectives')
        if i:require(points[i-1]['sum_G_mm']<p['sum_G_mm'] and points[i-1]['max_route_G_mm']>p['max_route_G_mm'],'strict antichain')
def xy(p):return p['sum_G_mm'],p['max_route_G_mm']
def cross(a,b,c):
    x,y=xy(a);u,v=xy(b);s,t=xy(c)
    return (u-x)*(t-y)-(v-y)*(s-x)
def switch(a,b):
    ds=b['sum_G_mm']-a['sum_G_mm'];dm=a['max_route_G_mm']-b['max_route_G_mm']
    require(ds>0 and dm>0,'strict edge');return Fraction(dm,ds+dm)
def classify(points):
    validate(points);vertices=[];checks=0
    for i,p in enumerate(points):
        while len(vertices)>1:
            checks+=1
            if cross(points[vertices[-2]],points[vertices[-1]],p)>0:break
            vertices.pop()
        vertices.append(i)
    supported=set(vertices);certificates={};restoration_checks=0
    for left,right in zip(vertices,vertices[1:]):
        for i in range(left+1,right):
            restoration_checks+=1;area=cross(points[left],points[right],points[i]);require(area>=0,'point below lower convex hull')
            if area==0:supported.add(i)
            else:certificates[i]={'enclosing_hull_indices':[left,right],'positive_cross_product':area}
    ordered=sorted(supported);position={v:i for i,v in enumerate(ordered)};out=[];tight_checks=0
    for i,p in enumerate(points):
        r={'index':i,'sum_G_mm':p['sum_G_mm'],'max_route_G_mm':p['max_route_G_mm'],'source_point_index':i}
        if i not in supported:
            r.update(classification='UNSUPPORTED',lower_bound=None,upper_bound=None,interval_empty=True,bounds_closed=False,**certificates[i])
        else:
            k=position[i];lo=Fraction(0)if k==len(ordered)-1 else switch(p,points[ordered[k+1]]);hi=Fraction(1)if k==0 else switch(points[ordered[k-1]],p)
            require(lo<=hi,'convex switch order');r.update(classification='SUPPORTED_TIE_ONLY'if lo==hi else'SUPPORTED_INTERVAL',lower_bound=rat(lo),upper_bound=rat(hi),interval_empty=False,bounds_closed=True)
            for name,w in (('lower_bound_competitors',lo),('upper_bound_competitors',hi)):
                value=w*p['sum_G_mm']+(1-w)*p['max_route_G_mm'];ties=[]
                for j,q in enumerate(points):
                    tight_checks+=1;v=w*q['sum_G_mm']+(1-w)*q['max_route_G_mm'];require(v>=value,'boundary support witness')
                    if j!=i and v==value:ties.append(j)
                r[name]=ties
        out.append(r)
    intervals=sorted((Fraction(r['lower_bound']['numerator'],r['lower_bound']['denominator']),Fraction(r['upper_bound']['numerator'],r['upper_bound']['denominator']))for r in out if r['classification']=='SUPPORTED_INTERVAL')
    require(intervals[0][0]==0 and intervals[-1][1]==1 and all(a[1]==b[0]for a,b in zip(intervals,intervals[1:])),'complete closed weight coverage')
    require(sum((b-a for a,b in intervals),Fraction(0))==1,'interval interiors partition weight range')
    return {'points':out,'class_counts':{c:sum(r['classification']==c for r in out)for c in CLASSES},'strict_hull_vertex_indices':vertices,'supported_indices':ordered,'complete_weight_coverage':True,'counters':{'integer_orientation_checks':checks,'collinear_restoration_checks':restoration_checks,'saved_weight_boundary_checks':tight_checks},'new_route_optimization_calls':0,'new_frontier_optimization_calls':0}

def join_budgets(points,queries,classification):
    validate(points);require(type(queries)is list and [q.get('p')for q in queries]==list(PERCENTAGES),'six frozen budget rows')
    labels=classification['points'];require(len(labels)==len(points),'classification count');supported=[p for p,r in zip(points,labels)if r['classification']!='UNSUPPORTED'];out=[];checks=0
    for i,(p,r)in enumerate(zip(points,labels)):require(r['index']==i and r['sum_G_mm']==p['sum_G_mm']and r['max_route_G_mm']==p['max_route_G_mm'],'classification source values')
    for q in queries:
        p=q['p'];require(type(p)is int,'integer p');threshold=points[0]['sum_G_mm']*(100+p)//100;require(type(q.get('budget_total_G_mm'))is int and q['budget_total_G_mm']==threshold,'exact threshold')
        feasible=[r for r in points if r['sum_G_mm']<=threshold];eligible=[r for r in supported if r['sum_G_mm']<=threshold];checks+=len(points)+len(supported);require(feasible and eligible,'sum endpoint included')
        source=min(feasible,key=lambda r:(r['max_route_G_mm'],r['sum_G_mm']));ideal=min(eligible,key=lambda r:(r['max_route_G_mm'],r['sum_G_mm']))
        for key,src in (('front_index','index'),('sum_G_mm','sum_G_mm'),('max_route_G_mm','max_route_G_mm')):require(type(q.get(key))is int and q[key]==source[src],'frozen budget selection')
        for key in ('partition','group_masks','routes','route_G_mm'):
            if key in source:require(q.get(key)==source[key],'frozen budget witness')
        category=labels[source['index']]['classification'];loss=ideal['max_route_G_mm']-source['max_route_G_mm'];require(loss>=0 and (loss>0)==(category=='UNSUPPORTED'),'loss iff unsupported')
        out.append({'p':p,'budget_total_G_mm':threshold,'source_front_index':source['index'],'source_classification':category,'source_sum_G_mm':source['sum_G_mm'],'source_max_route_G_mm':source['max_route_G_mm'],'ideal_support_front_index':ideal['index'],'ideal_support_sum_G_mm':ideal['sum_G_mm'],'ideal_support_max_route_G_mm':ideal['max_route_G_mm'],'ideal_complete_support_set_loss_G_mm':loss})
    return {'queries':out,'candidate_point_checks':checks,'derived_comparison_rows':6,'new_route_optimization_calls':0}
