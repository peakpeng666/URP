"""One predeclared independent classification; no route/frontier optimization."""
import pathlib,sys,json,time,resource
ROOT=pathlib.Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'source'))
from gates import active_verification_gate
from read_frontier import load_input

def main():
    assert __debug__;digest=active_verification_gate();claim=json.loads((ROOT/'provenance/VALIDATION_LAUNCH_STARTED.json').read_text());assert claim['frozen_files_sha256']==digest
    field,objective=sys.argv[1:];assert objective=='SUPPORT_CLASSIFICATION'
    from hull_support import classify,join_budgets
    c=time.process_time();w=time.monotonic();points,queries,identity=load_input(field);result=classify(points);result.update(join_budgets(points,queries,result))
    for row,saved in zip(result['points'],points):row['inherited_witness']={k:saved[k]for k in ('partition','group_masks','routes','route_G_mm','assignment_multiplicity_unlabeled')}
    result.update(instance_id=field,objective=objective,input_identity=identity,source_frontier_size=len(points),frozen_files_sha256=digest,status='PROCESS_SUCCESS_UNREVIEWED',resources={'cpu_seconds':time.process_time()-c,'wall_seconds':time.monotonic()-w,'maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'cpu_limits':list(resource.getrlimit(resource.RLIMIT_CPU)),'as_limits':list(resource.getrlimit(resource.RLIMIT_AS))});print(json.dumps(result,allow_nan=False))
if __name__=='__main__':main()
