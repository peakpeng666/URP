"""One gated mathematical classification call; never runs a routing solver."""
import hashlib
import json
import sys
import zipfile
from common import ROOT, read, sha
from gates import active_main_gate


def main():
    if len(sys.argv) != 3 or sys.argv[2] != 'SUPPORT_CLASSIFICATION':
        raise ValueError('EXACT_SCHEDULE_ARGUMENTS_REQUIRED')
    field = sys.argv[1]
    protocol = read(ROOT / 'freeze/PROTOCOL.json')
    if field not in protocol['fields']:
        raise ValueError('FIELD_NOT_IN_FROZEN_SCHEDULE')
    # Authority and all immutable evidence are checked BEFORE real point parsing
    # and before importing the classifier.
    digest = active_main_gate()
    identity = read(ROOT / 'input/PARENT_MEMBER_IDENTITIES.json')
    archive = ROOT / identity['parent_zip']
    if (identity['status'] != 'PARENT_FINAL_PRIVATE_ACTUAL_BYTE_READBACK_BOUND' or
            identity['sha256'] != protocol['input']['parent_final_sha256'] or
            sha(archive) != identity['sha256']):
        raise ValueError('PARENT_FINAL_ARCHIVE_IDENTITY')
    member = 'raw/calls/' + field + '_FRONTIER.stdout'
    expected = identity['selected_member_identities'][member]
    with zipfile.ZipFile(archive) as z:
        raw = z.read(member)
    if len(raw) != expected['bytes'] or hashlib.sha256(raw).hexdigest() != expected['sha256']:
        raise ValueError('PARENT_MAIN_MEMBER_IDENTITY')
    value = json.loads(raw)
    if (value['instance_id'] != field or value['frozen_files_sha256'] != protocol['input']['parent_frozen_sha256'] or
            value['frontier_size'] != protocol['inherited_field_point_counts'][protocol['fields'].index(field)]):
        raise ValueError('PARENT_FRONTIER_METADATA_IDENTITY')
    from classify_main import classify, join_budgets
    classification = classify(value['frontier'])
    comparisons = join_budgets(value['frontier'], value['queries'], classification)
    for derived, saved in zip(classification['points'], value['frontier']):
        derived['inherited_witness'] = {k: saved[k] for k in ('partition', 'group_masks', 'routes', 'route_G_mm', 'assignment_multiplicity_unlabeled')}
    output = {'status': 'EXACT_MATHEMATICAL_CLASSIFICATION_UNAUDITED', 'instance_id': field,
              'objective': 'SUPPORT_CLASSIFICATION', 'frozen_files_sha256': digest,
              'input_identity': {'parent_final_sha256': identity['sha256'], 'member': member, **expected},
              **classification, **comparisons}
    print(json.dumps(output, sort_keys=True, separators=(',', ':'), allow_nan=False))


if __name__ == '__main__':
    main()
