"""Exact interval classifier. No file, network, route, partition, or solver operations.

This module is a pure mathematical kernel. Only synthetic callers are presently
authorized. A future real worker must enforce the frozen-input and phase gates.
"""
from fractions import Fraction

PERCENTAGES = (0, 1, 2, 5, 10, 20)
CLASSES = ('UNSUPPORTED', 'SUPPORTED_TIE_ONLY', 'SUPPORTED_INTERVAL')


def rational(value):
    return {'numerator': value.numerator, 'denominator': value.denominator}


def strict_integer(value, name):
    if type(value) is not int or value < 0:
        raise ValueError('NONNEGATIVE_EXACT_INTEGER_REQUIRED:' + name)
    return value


def validate_frontier(points):
    if not isinstance(points, list) or not points:
        raise ValueError('NONEMPTY_FRONTIER_REQUIRED')
    previous = None
    for i, point in enumerate(points):
        if not isinstance(point, dict) or type(point.get('index')) is not int or point['index'] != i:
            raise ValueError('SAVED_INDEX_IDENTITY')
        s = strict_integer(point.get('sum_G_mm'), 'sum_G_mm')
        m = strict_integer(point.get('max_route_G_mm'), 'max_route_G_mm')
        if previous is not None and not (previous[0] < s and previous[1] > m):
            raise ValueError('NOT_STRICT_S_UP_M_DOWN_ANTICHAIN')
        previous = (s, m)


def classify(points):
    validate_frontier(points)
    out, count = [], 0
    for i, point in enumerate(points):
        lo, hi = Fraction(0), Fraction(1)
        lower_by, upper_by = [], []
        si, mi = point['sum_G_mm'], point['max_route_G_mm']
        for j, other in enumerate(points):
            if i == j:
                continue
            count += 1
            a = (si - other['sum_G_mm']) - (mi - other['max_route_G_mm'])
            b = other['max_route_G_mm'] - mi
            if a == 0:
                # Impossible for distinct points of a strict 2D antichain.
                raise ValueError('DEGENERATE_PAIR_CONSTRAINT')
            bound = Fraction(b, a)
            if a > 0:
                if bound < hi:
                    hi, upper_by = bound, [j]
                elif bound == hi:
                    upper_by.append(j)
            else:
                if bound > lo:
                    lo, lower_by = bound, [j]
                elif bound == lo:
                    lower_by.append(j)
        category = ('UNSUPPORTED' if lo > hi else
                    'SUPPORTED_TIE_ONLY' if lo == hi else 'SUPPORTED_INTERVAL')
        out.append({'index': i, 'sum_G_mm': si, 'max_route_G_mm': mi,
                    'classification': category,
                    'lower_bound': rational(lo), 'upper_bound': rational(hi),
                    'interval_empty': lo > hi, 'bounds_closed': lo <= hi,
                    'lower_bound_competitors': lower_by,
                    'upper_bound_competitors': upper_by,
                    'source_point_index': i})
    positive = sorted((Fraction(r['lower_bound']['numerator'], r['lower_bound']['denominator']),
                       Fraction(r['upper_bound']['numerator'], r['upper_bound']['denominator']))
                      for r in out if r['classification'] == 'SUPPORTED_INTERVAL')
    if (not positive or positive[0][0] != 0 or positive[-1][1] != 1 or
            any(a[1] != b[0] for a, b in zip(positive, positive[1:])) or
            sum((hi - lo for lo, hi in positive), Fraction(0)) != 1):
        raise ValueError('WEIGHT_INTERVAL_COVERAGE_OR_OVERLAP')
    if out[0]['classification'] != 'SUPPORTED_INTERVAL' or out[-1]['classification'] != 'SUPPORTED_INTERVAL':
        raise ValueError('FINITE_STRICT_FRONTIER_ENDPOINT_MUST_HAVE_POSITIVE_INTERVAL')
    return {'points': out, 'class_counts': {c: sum(r['classification'] == c for r in out) for c in CLASSES},
            'directed_pair_constraints': count, 'complete_weight_coverage': True,
            'new_route_optimization_calls': 0, 'new_frontier_optimization_calls': 0}


def join_budgets(points, queries, classification):
    """Join only the six existing choices; compare ideal complete support set."""
    validate_frontier(points)
    if not isinstance(queries, list) or [q.get('p') for q in queries] != list(PERCENTAGES):
        raise ValueError('SIX_FIXED_BUDGET_ROWS_REQUIRED')
    labels = classification['points']
    if len(labels) != len(points) or any(
            r['index'] != i or r['sum_G_mm'] != points[i]['sum_G_mm'] or
            r['max_route_G_mm'] != points[i]['max_route_G_mm'] or r['classification'] not in CLASSES
            for i, r in enumerate(labels)):
        raise ValueError('CLASSIFICATION_SOURCE_BINDING')
    out, checks = [], 0
    smin = points[0]['sum_G_mm']
    for q in queries:
        p = strict_integer(q['p'], 'p')
        threshold = smin * (100 + p) // 100
        if type(q.get('budget_total_G_mm')) is not int or q['budget_total_G_mm'] != threshold:
            raise ValueError('INTEGER_BUDGET_THRESHOLD')
        selected, ideal = None, None
        for point, label in zip(points, labels):
            checks += 1
            if 100 * point['sum_G_mm'] <= (100 + p) * smin:
                selected = point
                if label['classification'] != 'UNSUPPORTED':
                    ideal = point
        if selected is None or ideal is None:
            raise ValueError('NONNEGATIVE_BUDGET_MUST_INCLUDE_SUM_ENDPOINT')
        if type(q.get('front_index')) is not int or q['front_index'] != selected['index']:
            raise ValueError('SAVED_BUDGET_SELECTION_IDENTITY')
        for key in ('sum_G_mm', 'max_route_G_mm'):
            if type(q.get(key)) is not int or q[key] != selected[key]:
                raise ValueError('SAVED_BUDGET_OBJECTIVE_IDENTITY:' + key)
        for key in ('partition', 'group_masks', 'routes', 'route_G_mm'):
            if key in selected and q.get(key) != selected[key]:
                raise ValueError('SAVED_BUDGET_WITNESS_IDENTITY:' + key)
        loss = ideal['max_route_G_mm'] - selected['max_route_G_mm']
        label = labels[selected['index']]['classification']
        if loss < 0 or (loss > 0) != (label == 'UNSUPPORTED'):
            raise ValueError('SUPPORT_SET_LOSS_CLASSIFICATION_IDENTITY')
        out.append({'p': p, 'budget_total_G_mm': threshold, 'source_front_index': selected['index'],
                    'source_classification': label, 'source_sum_G_mm': selected['sum_G_mm'],
                    'source_max_route_G_mm': selected['max_route_G_mm'],
                    'ideal_support_front_index': ideal['index'],
                    'ideal_support_sum_G_mm': ideal['sum_G_mm'],
                    'ideal_support_max_route_G_mm': ideal['max_route_G_mm'],
                    'ideal_complete_support_set_loss_G_mm': loss,
                    'meaning': 'Best possible loss after obtaining every supported value point including all ties; not a measured weighted-sum algorithm result'})
    return {'queries': out, 'candidate_point_checks': checks, 'derived_comparison_rows': len(out),
            'new_route_optimization_calls': 0}
