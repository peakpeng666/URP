from pathlib import Path
assert 'selftests' in Path(__file__).parts
def active_main_gate():return 'INVENTED_ONLY_NO_REAL_AUTHORITY'
def active_verification_gate():return 'INVENTED_ONLY_NO_REAL_AUTHORITY'
