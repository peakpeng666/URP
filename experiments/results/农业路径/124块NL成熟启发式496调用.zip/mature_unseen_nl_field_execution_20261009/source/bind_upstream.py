"""One-time pure extraction of the already privately read-back INPUT FINAL.

No optimization, native import, shortest paths, or reference computation.
Only validates pre-registered input admissibility and copies original bytes.
"""
from pathlib import Path
import json,hashlib,zipfile,resource,signal
from common import ROOT,read,save,sha,now
from gates import verify_scientific_lock,get_schedule
from input_projection import planned_input_status,project_payload

UPSTREAM=Path('/workspace/shared/unseen_nl_field_preparation_20261009')
FINAL_SHA='163618b1280131105a1de43dfe4825886baaa716810e970a16c9dde58140c987'
FREEZE_SHA='43a3a05519bbfa4689a071e1dc71e44c86585c2f215ead4319a8318f708e05ef'


def digest(data):return hashlib.sha256(data).hexdigest()


def private_receipt(receipt,stage):
    assert receipt['stage']==stage and receipt['status']=='ARCHIVE_VERIFIED'
    assert receipt['owner_only'] is True and receipt['shared'] is False
    assert receipt['remote_readback_sha256_verified'] is True and receipt['download_byte_identical'] is True
    assert receipt['sha256']==receipt['download_sha256']==sha(Path(receipt['download_path']))==sha(Path(receipt['source']))
    assert Path(receipt['download_path']).stat().st_size==receipt['bytes']
    assert receipt['frozen_files_sha256']==FREEZE_SHA


def main():
    resource.setrlimit(resource.RLIMIT_CPU,(60,60));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,1536*1024**2));signal.alarm(240)
    science=verify_scientific_lock();get_schedule('formal')
    receipt_path=UPSTREAM/'provenance/FINAL_DRIVE_RECEIPT.json'
    receipt_bytes=receipt_path.read_bytes();final_receipt=json.loads(receipt_bytes)
    private_receipt(final_receipt,'FINAL');assert final_receipt['sha256']==FINAL_SHA
    assert final_receipt['drive_id']=='1bYyWQS4PHplpAbSUVU-3F6c_Bb_O_A_u'
    fields=read('upstream_identity/PANEL_SOURCE_IDENTITY.json')['field_ids_in_source_order']
    members={};manifest_checks={}
    with zipfile.ZipFile(final_receipt['download_path']) as archive:
        assert len(archive.namelist())==len(set(archive.namelist()))
        assert digest(archive.read('freeze/FROZEN_FILES.json'))==FREEZE_SHA
        for name in ('freeze/FROZEN_FILES.json','raw/RAW_MAIN_CONTENT_MANIFEST.json','independent_supervision/raw/RAW_VERIFICATION_CONTENT_MANIFEST.json'):
            manifest=json.loads(archive.read(name))
            for relative,meta in manifest['files'].items():
                data=archive.read(relative)
                assert len(data)==meta['bytes'] and digest(data)==meta['sha256'],(name,relative)
            manifest_checks[name]=len(manifest['files'])
        final_audit=json.loads(archive.read('independent_supervision/FINAL_INPUT_AUDIT.json'))
        review=json.loads(archive.read('independent_supervision/FINAL_REPORT_REVIEW.json'))
        raw_receipts={stage:json.loads(archive.read('provenance/'+stage+'_DRIVE_RECEIPT.json')) for stage in ('RAW_MAIN','RAW_VERIFICATION')}
        for stage,rec in raw_receipts.items():private_receipt(rec,stage)
        assert final_audit['status']=='INPUT_EVIDENCE_AUDITED' and final_audit['planned_fields']==124
        assert review['status']=='PASS'
        for record in (final_audit,review):
            assert record['frozen_files_sha256']==FREEZE_SHA
            assert record['raw_main_archive_sha256']==raw_receipts['RAW_MAIN']['sha256']
            assert record['raw_verification_archive_sha256']==raw_receipts['RAW_VERIFICATION']['sha256']
        assert review['independent_audit_sha256']==digest(archive.read('independent_supervision/FINAL_INPUT_AUDIT.json'))
        assert review['report_sha256']==digest(archive.read('reports/REPORT_ZH.txt'))
        assert review['summary_sha256']==digest(archive.read('reports/SUMMARY.json'))
        author=json.loads(archive.read('raw/ALL_FIELD_SLOTS.json'))
        assert len(author)==len(final_audit['fields'])==124
        arows={r['instance_id']:r for r in author};irows={r['instance_id']:r for r in final_audit['fields']}
        assert len(arows)==len(irows)==124 and set(arows)==set(irows)==set(fields)
        copy_map={
            'freeze/FROZEN_FILES.json':'upstream_evidence/FROZEN_FILES.json',
            'freeze/INPUT_INTERFACE.json':'upstream_evidence/INPUT_INTERFACE.json',
            'raw/RAW_MAIN_CONTENT_MANIFEST.json':'upstream_evidence/RAW_MAIN_CONTENT_MANIFEST.json',
            'independent_supervision/raw/RAW_VERIFICATION_CONTENT_MANIFEST.json':'upstream_evidence/RAW_VERIFICATION_CONTENT_MANIFEST.json',
            'raw/ALL_FIELD_SLOTS.json':'upstream_evidence/ALL_FIELD_SLOTS.json',
            'independent_supervision/FINAL_INPUT_AUDIT.json':'upstream_evidence/FINAL_INPUT_AUDIT.json',
            'independent_supervision/FINAL_REPORT_REVIEW.json':'upstream_evidence/FINAL_REPORT_REVIEW.json',
            'provenance/PREEXEC_DRIVE_RECEIPT.json':'upstream_evidence/PREEXEC_DRIVE_RECEIPT.json',
            'provenance/RAW_MAIN_DRIVE_RECEIPT.json':'upstream_evidence/RAW_MAIN_DRIVE_RECEIPT.json',
            'provenance/RAW_VERIFICATION_DRIVE_RECEIPT.json':'upstream_evidence/RAW_VERIFICATION_DRIVE_RECEIPT.json'}
        identities={}
        for field in fields:
            original=irows[field];status=planned_input_status(field,arows[field],original)
            ready=status['status']=='INPUT_AUDIT_READY_FOR_BYTE_AND_NUMERIC_CHECK'
            member=f'raw/fields/{field}/preprocess.json';local=f'input/{field}.json'
            present=member in archive.namelist()
            if ready:
                assert present
                payload_bytes=archive.read(member)
                assert digest(payload_bytes)==status['preprocess_sha256'] and len(payload_bytes)==status['bytes']
                data=json.loads(payload_bytes);assert data['instance_id']==field
                for proxy in ('E','G'):
                    for arm in ('A','P'):project_payload(data,proxy,arm)
            if present:copy_map[member]=local
            identities[field]={'instance_id':field,'native_ready':ready,'status':status['status'],
                'readiness_evidence':status,'input_ready':original.get('input_ready'),
                'numeric_flags':original.get('numeric_flags'),'preprocess_sha256':original.get('preprocess_sha256'),
                'bytes':original.get('preprocess_bytes'),'upstream_preprocess_path':original.get('preprocess_path'),
                'local_input_path':local if present else None,'residual_file_present':present}
        # No partial output until all archive identity checks and all prospective guards pass.
        for member,relative in copy_map.items():
            data=archive.read(member);destination=ROOT/relative;destination.parent.mkdir(parents=True,exist_ok=True)
            with destination.open('xb') as handle:handle.write(data)
            members[relative]={'archive_member':member,'bytes':len(data),'sha256':digest(data)}
    destination=ROOT/'upstream_evidence/FINAL_DRIVE_RECEIPT.json'
    with destination.open('xb') as handle:handle.write(receipt_bytes)
    identity={'utc':now(),'status':'VERIFIED_FINAL_INPUT_ARCHIVE_MEMBER_EXTRACTION',
        'upstream_root':str(UPSTREAM),'upstream_final_archive_sha256':FINAL_SHA,
        'upstream_final_archive_bytes':final_receipt['bytes'],'upstream_final_drive_id':final_receipt['drive_id'],
        'upstream_frozen_files_sha256':FREEZE_SHA,'scientific_policy_lock_sha256':science,
        'verified_manifest_member_counts':manifest_checks,'extracted_members':members,
        'external_receipts':{'upstream_evidence/FINAL_DRIVE_RECEIPT.json':{'bytes':len(receipt_bytes),'sha256':digest(receipt_bytes)}},
        'native_calls':0,'solver_calls':0,'exact_computations':0,'new_field_preprocessing_calls':0,
        'restoration':'Formal gate/report use these frozen extraction bytes; original absolute paths are historical provenance, not runtime dependencies.'}
    save(ROOT/'upstream_identity/FINAL_INPUT_PACKAGE_IDENTITY.json',identity)
    save(ROOT/'input/IDENTITIES.json',{'utc':now(),'field_order':fields,'fields':identities,
        'upstream_final_archive_sha256':FINAL_SHA,
        'upstream_final_input_audit_sha256':sha(ROOT/'upstream_evidence/FINAL_INPUT_AUDIT.json')})
    signal.alarm(0)
    print(json.dumps({'bound_fields':len(fields),'native_ready':sum(r['native_ready'] for r in identities.values()),'extracted_members':len(members),'new_native_calls':0}))

if __name__=='__main__':main()
