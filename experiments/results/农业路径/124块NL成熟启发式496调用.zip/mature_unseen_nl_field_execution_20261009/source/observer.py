"""Public read-only observations; no construction/mutation of native solver objects."""
from pyvrp.IteratedLocalSearch import IteratedLocalSearchCallbacks
PROBE_VALUES=(1,2,7,1000)
def public_snapshot(manager):
    loads,duration,distance=manager.penalties()
    return [list(map(float,loads)),float(duration),float(distance)]
class ReadonlyPenaltyObserver(IteratedLocalSearchCallbacks):
    def __init__(self,extract):
        self._manager=None;self._initial=None;self._previous=None;self._rows=[]
        self._extract=extract;self._initial_routes=None;self._initial_feasible=None;self._first_feasible=None
    def on_start(self,ils):
        self._manager=ils.penalty_manager
        self._initial=public_snapshot(self._manager);self._previous=self._initial
        self._initial_routes=self._extract(ils.initial_solution)
        self._initial_feasible=bool(ils.initial_solution.is_feasible())
        if self._initial_feasible:self._first_feasible=0
    def on_iteration(self,current,candidate,best,cost_evaluator):
        # Candidate may differ from the object actually registered by ILS.
        post=public_snapshot(self._manager)
        probes=[{'violation':v,'load':int(cost_evaluator.load_penalty(v,0,0)),
                 'duration':int(cost_evaluator.tw_penalty(v)),
                 'distance':int(cost_evaluator.dist_penalty(v,0))}for v in PROBE_VALUES]
        iteration=len(self._rows)+1;feasible=bool(best.is_feasible())
        if feasible and self._first_feasible is None:self._first_feasible=iteration
        self._rows.append({'iteration':iteration,'expected_search_penalties_source_derived':self._previous,
                          'observed_post_registration_penalties':post,
                          'observed_search_evaluator_integer_probes':probes,'best_is_feasible':feasible})
        self._previous=post
    def observation(self):
        return {'schema':'public_scale_penalty_observer_v1','initial_penalties':self._initial,
                'initial_solution_feasible':self._initial_feasible,'initial_solution_routes':self._initial_routes,
                'first_best_feasible_iteration':self._first_feasible,'probe_values':list(PROBE_VALUES),'rows':self._rows,
                'scope':'on_start is AFTER initialization. Its max evaluator is source-derived only. Public PM snapshots and delivered evaluator integer probes; no registered candidate or hidden coefficients observed.'}
