"""No-process standard-library mock replay of deadline/finally/failed-RAW preservation."""
import sys,json,tempfile,subprocess,io,contextlib
from pathlib import Path
from unittest.mock import patch
import execute_and_seal as outer
from common import ROOT,save,now
from gates import get_schedule

class FakeSupervisor:
    pid=123456789
    returncode=None
    def __init__(self):self.waits=0
    def wait(self,timeout=None):
        self.waits+=1
        if self.waits==1:raise subprocess.TimeoutExpired('MOCK_NO_PROCESS',timeout)
        self.returncode=-9;return -9


def main():
    schedule=get_schedule('formal');events=[];fake=FakeSupervisor()
    with tempfile.TemporaryDirectory(prefix='unseen_outer_mock_') as directory:
        root=Path(directory);(root/'provenance').mkdir();(root/'freeze').mkdir()
        (root/'freeze/OLD_FILES_BEFORE.json').write_text('{"files":{}}\n')
        with patch.object(outer,'ROOT',root),patch.object(outer,'get_schedule',return_value=schedule),\
             patch.object(outer,'check_gate',return_value={'python':'MOCK_NEVER_EXECUTED','freeze_sha256':'f'*64}),\
             patch.object(outer,'verify_old',return_value=0),\
             patch.object(outer.resource,'setrlimit'),patch.object(outer.signal,'signal',return_value=None),\
             patch.object(outer.signal,'setitimer',side_effect=lambda *args:events.append(('timer',args))),\
             patch.object(outer.subprocess,'Popen',return_value=fake) as creation,\
             patch.object(outer.os,'killpg',side_effect=lambda *args:events.append(('mock_killpg',args))),\
             patch.object(outer,'wait_group_quiescent',return_value=[]),\
             patch('package.package',return_value={'sha256':'0'*64,'path':'MOCK_NO_ARCHIVE_CREATED'}) as package_mock,\
             patch.object(sys,'argv',['execute_and_seal.py','formal']),contextlib.redirect_stdout(io.StringIO()):
            assert outer.main()==0
        assert creation.call_count==1 and fake.waits==2 and any(e[0]=='mock_killpg' for e in events)
        assert any(e==('timer',(outer.signal.ITIMER_REAL,0)) for e in events)
        assert package_mock.call_count==1 and package_mock.call_args.args==('RAW_UNREVIEWED',)
        finish=json.loads((root/'raw/EXECUTOR_FINISHED.json').read_text())
        slots=json.loads((root/'raw/ALL_PLANNED_SLOTS.json').read_text())
        assert finish['external_timeout'] is True and finish['cleanup']['quiescent'] is True
        assert finish['cleanup']['child_reaped'] is True and len(slots)==496
        assert finish['known_spawned']==finish['unknown_spawned_slots']==0
        assert (root/'raw/PRESEAL_IDENTITY_VERIFICATION.json').exists()
        assert (root/'provenance/EXECUTION_COMMAND_COMPLETE.json').exists()
        assert (root/'provenance/FORMAL_EXECUTION_CLAIM.json').exists()
    with tempfile.TemporaryDirectory(prefix='unseen_gate_failure_mock_') as directory:
        root=Path(directory);(root/'provenance').mkdir()
        with patch.object(outer,'ROOT',root),patch.object(outer,'get_schedule',return_value=schedule),\
             patch.object(outer,'check_gate',side_effect=AssertionError('MOCK_GATE_REJECTION')),\
             patch.object(outer.resource,'setrlimit'),patch.object(outer.signal,'signal',return_value=None),\
             patch.object(outer.signal,'setitimer'),patch.object(outer.subprocess,'Popen') as creation,\
             patch('package.package') as package_mock,patch.object(sys,'argv',['execute_and_seal.py','formal']):
            try:outer.main()
            except RuntimeError as error:assert str(error)=='PRELAUNCH_GATE_FAILURE_NO_RAW_SEAL'
            else:raise AssertionError('Gate rejection was not retained')
        assert creation.call_count==package_mock.call_count==0
        assert len(json.loads((root/'raw/ALL_PLANNED_SLOTS.json').read_text()))==496
    marker=False
    try:
        try:outer.deadline_handler(None,None)
        finally:marker=True
    except outer.OuterDeadlineExceeded:pass
    assert marker
    assert not any(name=='pyvrp' or name.startswith('pyvrp.') for name in sys.modules)
    save(ROOT/'selftests/OUTER_DEADLINE_NO_PROCESS_MOCK.json',{'utc':now(),'status':'PASS',
        'mock_supervisor_timeout':'finally cleanup and496-slot retention; failedRAW mock seal permitted only after gate pass andquiescence',
        'mock_gate_rejection':'all496 retained; no process or package invocation',
        'exception_handler_finally':'PASS','actual_processes_launched':0,'actual_archives_created':0,'new_native_calls':0,'new_solver_calls':0,
        'scope':'Pure monkeypatched control-flow test, not a real lifetime/clock stress test or native toy'})
    print(json.dumps({'status':'PASS','actual_processes_launched':0,'actual_archives_created':0,'new_native_calls':0}))

if __name__=='__main__':main()
