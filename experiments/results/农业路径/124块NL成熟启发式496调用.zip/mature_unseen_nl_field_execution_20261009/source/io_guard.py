"""Keep default warning rendering; allow one exact verified source for read only."""
import hashlib
import os
from pathlib import Path

WARNING_SOURCE = '/workspace/shared/public_route_strong_baseline_20261009_venv/lib/python3.12/site-packages/pyvrp/PenaltyManager.py'
WARNING_SOURCE_SHA256 = '2f691640bb5a785920df1077653d2bf406bc0350594913f9fe8378c127a3e6d1'
READ_FLAGS = getattr(os, 'O_CLOEXEC', 0)


def verified_io_guard(denied, allowed):
    actual_hash = hashlib.sha256(Path(WARNING_SOURCE).read_bytes()).hexdigest()
    if actual_hash != WARNING_SOURCE_SHA256:
        raise RuntimeError('Frozen warning-source SHA256 mismatch')

    def audit(event, args):
        if event == 'open':
            if args == (WARNING_SOURCE, 'r', READ_FLAGS):
                allowed.append({'event': event, 'path': WARNING_SOURCE,
                                'mode': 'r', 'flags': READ_FLAGS,
                                'verified_source_sha256': actual_hash})
                return
            denied.append(event)
            raise PermissionError('Only the exact frozen warning source can be opened for read during search')
        if event.startswith(('socket.', 'subprocess.', 'os.system', 'os.exec', 'os.spawn')):
            denied.append(event)
            raise PermissionError('External process/network IO is forbidden during reference-free search')

    return audit, {'path': WARNING_SOURCE, 'sha256': actual_hash,
                   'verified_before_search': True, 'default_warning_behavior_preserved': True}
