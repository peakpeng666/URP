"""Pure upstream-to-worker projection. No filesystem access or native imports.

The caller must first verify upstream freezes, receipts, complete ledgers,
independent field readiness, and actual preprocess bytes against both hashes.
This module does not grant execution authority.
"""
from payload_contract import validate_payload

GRAPH_ID = 'DIRECT_13_TERMINAL_SERVICES_NOT_OLD_21_THEN_SUBMATRIX'


def project_payload(preprocess, proxy, arm):
    assert isinstance(preprocess, dict) and proxy in ('E', 'G') and arm in ('A', 'P')
    assert type(preprocess['n']) is int and preprocess['n'] == 12
    assert preprocess['graph_construction_identity'] == GRAPH_ID
    payload = {key: preprocess[key] for key in ('coordinates', 'demands', 'capacity', 'K')}
    payload.update(distance_matrix=preprocess['integer_matrices'][proxy],
                   seed=0, max_iterations=250, arm=arm, scale=1, observe_penalties=True)
    validate_payload(payload)
    return payload


def planned_input_status(instance_id, author_slot, independent_field):
    """Fail-closed decision before reading a success payload.

    INPUT_AUDIT_READY means byte reading/validation may proceed, not solver
    permission. Per-matrix numeric guards are enforced by project_payload.
    """
    if not isinstance(author_slot, dict) or not isinstance(independent_field, dict):
        return {'status': 'NOT_STARTED_INPUT_UNKNOWN', 'reason': 'Missing author or independent row'}
    assert author_slot['instance_id'] == independent_field['instance_id'] == instance_id
    if author_slot.get('author_pass_unreviewed') is not True:
        return {'status': 'NOT_STARTED_INPUT_FAILURE', 'reason': 'Author input did not pass'}
    if independent_field.get('input_ready') is not True:
        return {'status': 'NOT_STARTED_INPUT_AUDIT_BLOCKED', 'reason': independent_field.get('failure')}
    flags = independent_field.get('numeric_flags')
    if not isinstance(flags, dict) or flags.get('native_policy_admissible') is not True:
        return {'status': 'NOT_STARTED_NATIVE_POLICY_BLOCKED', 'reason': 'Independent numeric_flags.native_policy_admissible is not true'}
    meta = author_slot.get('preprocess') or {}
    digest = meta.get('sha256')
    if not isinstance(digest, str) or len(digest) != 64 or any(ch not in '0123456789abcdef' for ch in digest):
        return {'status': 'NOT_STARTED_INPUT_IDENTITY_BLOCKED', 'reason': 'Missing or malformed SHA256'}
    if meta.get('exists') is not True or digest != independent_field.get('preprocess_sha256'):
        return {'status': 'NOT_STARTED_INPUT_IDENTITY_BLOCKED', 'reason': 'Independent preprocess identity mismatch'}
    if type(meta.get('bytes')) is not int or meta['bytes'] <= 0 or meta['bytes'] != independent_field.get('preprocess_bytes'):
        return {'status': 'NOT_STARTED_INPUT_IDENTITY_BLOCKED', 'reason': 'Invalid or independently mismatched preprocess byte count'}
    expected_path = f'raw/fields/{instance_id}/preprocess.json'
    if meta.get('path') != expected_path or independent_field.get('preprocess_path') != expected_path:
        return {'status': 'NOT_STARTED_INPUT_IDENTITY_BLOCKED', 'reason': 'Unexpected or mismatched preprocess path'}
    return {'status': 'INPUT_AUDIT_READY_FOR_BYTE_AND_NUMERIC_CHECK',
            'reason': None, 'preprocess_sha256': meta['sha256'], 'bytes': meta['bytes']}
