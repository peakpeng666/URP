"""Standard-library-only resource inheritance check. Not a solver/native toy."""
import json
import os
from pathlib import Path
import resource
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
MIB = 1024**2


def limits():
    return {'CPU_seconds': list(resource.getrlimit(resource.RLIMIT_CPU)),
            'AS_bytes': list(resource.getrlimit(resource.RLIMIT_AS))}


def role(name):
    inherited = limits()
    cpu = {'outer': 120, 'supervisor': 60, 'worker': 15}[name]
    resource.setrlimit(resource.RLIMIT_CPU, (cpu, cpu))
    resource.setrlimit(resource.RLIMIT_AS, ((1536 if name == 'worker' else 512) * MIB, 1536 * MIB))
    out = {'role': name, 'inherited': inherited, 'effective': limits()}
    if name != 'worker':
        child = 'supervisor' if name == 'outer' else 'worker'
        result = subprocess.run([sys.executable, '-B', __file__, child],
                                check=True, capture_output=True, text=True, timeout=5)
        out['child'] = json.loads(result.stdout)
    print(json.dumps(out))


def main():
    result = subprocess.run([sys.executable, '-B', __file__, 'outer'],
                            check=True, capture_output=True, text=True, timeout=10)
    outer = json.loads(result.stdout)
    supervisor, worker = outer['child'], outer['child']['child']
    assert outer['effective']['CPU_seconds'] == [120, 120]
    assert supervisor['inherited'] == outer['effective']
    assert supervisor['effective']['CPU_seconds'] == [60, 60]
    assert worker['inherited'] == supervisor['effective']
    assert worker['effective'] == {'CPU_seconds': [15, 15], 'AS_bytes': [1536 * MIB, 1536 * MIB]}
    assert 12718 + 2 == 12720 and 496 * 25 == 12400 < 12600 < 12718
    report = {'status': 'PASS', 'scope': 'Pure stdlib fork chain validates configured inheritance only; not full future launcher integration.',
              'dummy_processes': 3, 'native_imports': 0, 'solver_calls': 0,
              'additional_native_toys': 0, 'tree': outer,
              'wall_bound_arithmetic': {'worker_sum': 12400, 'inner': 12600, 'outer_wait': 12718, 'quiescence': 2, 'outer_total': 12720}}
    path = ROOT / 'selftests/RESOURCE_INHERITANCE_STDLIB.json'
    with path.open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps({key: value for key, value in report.items() if key != 'tree'}))


if __name__ == '__main__':
    role(sys.argv[1]) if len(sys.argv) == 2 else main()
