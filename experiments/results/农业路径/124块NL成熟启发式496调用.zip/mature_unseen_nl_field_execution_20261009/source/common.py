"""Audit and packaging helpers; no solver imports."""
from pathlib import Path
import json, hashlib, datetime, os
ROOT=Path(__file__).resolve().parents[1]
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(relative):return json.loads((ROOT/relative).read_text())
def save(path,value):
    with Path(path).open('x') as f:
        json.dump(value,f,ensure_ascii=False,indent=2,allow_nan=False)
        f.write('\n');f.flush();os.fsync(f.fileno())
def append(path,value):
    with Path(path).open('a') as f:
        f.write(json.dumps(value,separators=(',',':'),allow_nan=False)+'\n');f.flush();os.fsync(f.fileno())
def verify_frozen():
    frozen=read('freeze/FROZEN_FILES.json')
    for rel,meta in frozen['files'].items():
        p=ROOT/rel
        assert p.stat().st_size==meta['bytes'] and sha(p)==meta['sha256'], f'Frozen file changed: {rel}'
    return sha(ROOT/'freeze/FROZEN_FILES.json')
def verify_old():
    expected=read('freeze/OLD_FILES_BEFORE.json')['files']
    for path,meta in expected.items():
        p=Path(path)
        assert p.stat().st_size==meta['bytes'] and sha(p)==meta['sha256'],f'Old file changed: {p}'
    return len(expected)

def receipt(stage):
    r=read(f'provenance/{stage}_DRIVE_RECEIPT.json')
    assert r['owner_only'] and r['remote_readback_sha256_verified'] and r['download_byte_identical'] and r['shared'] is False
    assert r['frozen_files_sha256']==sha(ROOT/'freeze/FROZEN_FILES.json')
    archive=ROOT.parent/(ROOT.name+'_'+stage+'.zip')
    assert r['sha256']==r['download_sha256']==sha(archive)==sha(Path(r['download_path']))
    return r
