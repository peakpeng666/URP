"""Pure input-only capacity-priority bound; never imports the optimizer."""

def derive_penalty(matrix, n_customers, K):
    assert type(n_customers) is int and type(K) is int
    assert (n_customers, K) in ((4, 2), (12, 3))
    assert len(matrix) == n_customers + 1
    assert all(len(row) == n_customers + 1 for row in matrix)
    assert all(type(v) is int and 0 <= v <= 3944800 for row in matrix for v in row)
    maximum = max(v for row in matrix for v in row)
    upper = (n_customers + K) * maximum
    penalty = upper + 1
    # Native double products are exact for every admitted violation/probe;
    # signed Cost is int64. No native saturation or range safety is assumed.
    assert 1000 * penalty < 2**53
    assert 4 * (upper + n_customers * penalty) < 2**53 < 2**63 - 1
    return {'formula': '(n_customers+K)*max_edge+1', 'n_customers': n_customers,
            'K': K, 'max_edge': maximum, 'U': upper, 'P': penalty}
