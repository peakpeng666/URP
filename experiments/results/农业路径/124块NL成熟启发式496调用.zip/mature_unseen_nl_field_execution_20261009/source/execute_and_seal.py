"""Preserved outer/supervisor/worker chain for one separately authorized 496-slot batch."""
import subprocess,sys,os,signal,time,json,resource
from common import ROOT,now,sha,read,save,verify_old
from run_once import child_environment
from process_lifecycle import parent_death,wait_group_quiescent
from gates import check_gate,get_schedule
from ledger import reconcile

def stop_process_group(p):
    if p is not None:
        cleanup_deadline=time.monotonic()+2
        try:os.killpg(p.pid,signal.SIGKILL)
        except ProcessLookupError:pass
        try:p.wait(timeout=max(0.001,cleanup_deadline-time.monotonic()))
        except subprocess.TimeoutExpired:
            remaining=wait_group_quiescent(p.pid,timeout=0)
            return {'quiescent':False,'child_reaped':False,'remaining_group_members':remaining,'cleanup_timeout':True}
        remaining=wait_group_quiescent(p.pid,timeout=max(0,cleanup_deadline-time.monotonic()))
        return {'quiescent':not remaining,'child_reaped':True,'remaining_group_members':remaining,'cleanup_timeout':bool(remaining)}
    return {'quiescent':True,'child_reaped':True,'remaining_group_members':[],'cleanup_timeout':False}

class OuterDeadlineExceeded(TimeoutError):
    pass


def deadline_handler(signum,frame):
    raise OuterDeadlineExceeded('OUTER_EXECUTION_DEADLINE_12720_SECONDS')


def main():
    started=time.monotonic();deadline=started+12720
    assert __debug__ and len(sys.argv)==2 and sys.argv[1]=='formal'
    mode=sys.argv[1]
    resource.setrlimit(resource.RLIMIT_CPU,(120,120))
    resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,1536*1024**2))
    dest=ROOT/'raw';dest.mkdir(exist_ok=True)
    assert not any((dest/name).exists() for name in ('EXECUTOR_STARTED.json','EXECUTOR_FINISHED.json','STARTED.json','results.jsonl','attempts.jsonl'))
    assert not (ROOT/'provenance/FORMAL_EXECUTION_CLAIM.json').exists()
    schedule=get_schedule(mode)
    out=dest/'supervisor.stdout';err=dest/'supervisor.stderr'
    p=None;timed_out=False;error=None;gate=None;parent=os.getpid()
    old_handler=signal.signal(signal.SIGALRM,deadline_handler)
    signal.setitimer(signal.ITIMER_REAL,max(0.001,deadline-time.monotonic()))
    try:
        # The deadline includes the gate: it is measured from main entry.
        gate=check_gate(mode)
        save(ROOT/'provenance/FORMAL_EXECUTION_CLAIM.json',{'utc':now(),'gate':gate,'planned_slots':496,'no_retries':True})
        save(dest/'EXECUTOR_STARTED.json',{'utc':now(),'mode':mode,'gate':gate,'no_retries':True,
            'execution_deadline_seconds_from_entry':12720,'cleanup_reserve_seconds':2})
        remaining=deadline-time.monotonic()-2
        if remaining<=0:raise OuterDeadlineExceeded('DEADLINE_EXHAUSTED_BEFORE_SUPERVISOR')
        with out.open('xb') as fo,err.open('xb') as fe:
            p=subprocess.Popen([gate['python'],'-B',str(ROOT/'source/run_once.py'),mode],
              stdout=fo,stderr=fe,env=child_environment(),cwd=dest,start_new_session=True,
              preexec_fn=lambda:parent_death(parent))
            try:p.wait(timeout=max(0.001,deadline-time.monotonic()-2))
            except subprocess.TimeoutExpired:timed_out=True
    except OuterDeadlineExceeded as exc:
        timed_out=True;error=repr(exc)
    except Exception as exc:error=repr(exc)
    finally:
        # Deadline is exception-based; never let an alarm bypass finally.
        signal.setitimer(signal.ITIMER_REAL,0)
        signal.signal(signal.SIGALRM,old_handler)
        execution_elapsed=time.monotonic()-started
        cleanup_started=time.monotonic();cleanup=stop_process_group(p)
        cleanup_wall=time.monotonic()-cleanup_started
    results=(dest/'results.jsonl').read_text() if (dest/'results.jsonl').exists() else ''
    attempts=(dest/'attempts.jsonl').read_text() if (dest/'attempts.jsonl').exists() else ''
    slots,ledger_errors=reconcile(schedule,results,attempts)
    save(dest/'ALL_PLANNED_SLOTS.json',slots)
    save(dest/'EXECUTOR_FINISHED.json',{'utc':now(),'mode':mode,
      'supervisor_returncode':p.returncode if p else None,'external_timeout':timed_out,
      'launcher_error':error,'process_group_kill_attempt_completed_before_seal':True,'cleanup':cleanup,
      'execution_deadline_seconds_from_entry':12720,'execution_wall_before_cleanup_seconds':execution_elapsed,
      'cleanup_wall_seconds_audit_only':cleanup_wall,'wall_seconds_before_seal_audit_only':time.monotonic()-started,
      'wall_semantics':'12720 execution deadline includes gate; cleanup and seal tail separately recorded. No whole-command compression wall guarantee.',
      'planned_slots':len(schedule),'retained_slots':len(slots),'ledger_errors':ledger_errors,
      'known_spawned':sum(r.get('process_spawned') is True for r in slots),
      'unknown_spawned_slots':sum(r.get('process_spawned') is None for r in slots)})
    if not cleanup['quiescent']:raise RuntimeError('WORKER_GROUP_NOT_QUIESCENT_NO_SEAL')
    # Approved timeout policy: preserve a failed RAW after valid gate + quiescence.
    if gate is None:raise RuntimeError('PRELAUNCH_GATE_FAILURE_NO_RAW_SEAL')
    old_count=verify_old();post_gate=check_gate(mode)
    save(dest/'PRESEAL_IDENTITY_VERIFICATION.json',{'utc':now(),'frozen_files_sha256':post_gate['freeze_sha256'],
        'old_files_verified_unchanged':old_count,'old_manifest_sha256':sha(ROOT/'freeze/OLD_FILES_BEFORE.json'),
        'method':'Actual original-workspace external-file hash recheck after child cleanup, before RAW seal'})
    from package import package
    seal_started=time.monotonic();archive=package('RAW_UNREVIEWED')
    completion={'utc':now(),'raw_archive_sha256':archive['sha256'],
       'complete_command_wall_seconds_audit_only':time.monotonic()-started,
       'seal_tail_wall_seconds_audit_only':time.monotonic()-seal_started,
       'cleanup_wall_seconds_audit_only':cleanup_wall,
       'execution_deadline_seconds_from_entry':12720,
       'note':'Written after RAW seal; retained with provenance for FINAL, not claimed as an original RAW member.'}
    save(ROOT/'provenance/EXECUTION_COMMAND_COMPLETE.json',completion)
    print(json.dumps({**archive,**completion}))
    return 0

if __name__=='__main__':
    raise SystemExit(main())
