"""Retain one record for every planned slot, including interrupted/unstarted calls."""
import json

def reconcile(schedule,results_text,attempts_text):
    by_id={};starts=set();errors=[]
    for i,line in enumerate(results_text.splitlines()):
        if not line.strip():continue
        try:
            row=json.loads(line);cid=row['call_id']
            if cid in by_id:errors.append('DUPLICATE_RESULT:'+cid)
            else:by_id[cid]=row
        except (ValueError,KeyError,TypeError):errors.append('MALFORMED_RESULT_LINE:'+str(i+1))
    for i,line in enumerate(attempts_text.splitlines()):
        if not line.strip():continue
        try:
            row=json.loads(line)
            if row['event_kind']=='STARTED':
                if row['call_id'] in starts:errors.append('DUPLICATE_START:'+row['call_id'])
                starts.add(row['call_id'])
        except (ValueError,KeyError,TypeError):errors.append('MALFORMED_EVENT_LINE:'+str(i+1))
    planned={e['call_id'] for e in schedule}
    if set(by_id)-planned or starts-planned:errors.append('UNSCHEDULED_CALL')
    rows=[]
    for e in schedule:
        cid=e['call_id']
        if cid in by_id:
            row=by_id[cid]
            if row.get('schedule')!=e:errors.append('SCHEDULE_MISMATCH:'+cid)
        else:
            row={'call_id':cid,'schedule':e,'status':'UNKNOWN_AFTER_SUPERVISOR_FAILURE' if cid in starts else 'NOT_STARTED_SUPERVISOR_FAILURE','process_spawned':None if cid in starts else False}
        rows.append(row)
    return rows,errors
