"""One-use fixed-matrix supervisor. Registered 496 logical slots; separate hash-bound execution authority required."""
import os,sys,json,time,resource,signal,subprocess,traceback,hashlib
from pathlib import Path
from process_lifecycle import parent_death
from common import ROOT,now,sha,read,save,append,verify_frozen,verify_old,receipt

def child_environment():
    return {'PATH':'/usr/local/bin:/usr/bin:/bin','HOME':'/tmp','LANG':'C.UTF-8','LC_ALL':'C.UTF-8',
            'PYTHONDONTWRITEBYTECODE':'1','PYTHONHASHSEED':'0','PYTHONNOUSERSITE':'1',
            'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1',
            'NUMEXPR_NUM_THREADS':'1','VECLIB_MAXIMUM_THREADS':'1'}

def configure_supervisor_limits():
    if not __debug__:raise RuntimeError('Assertions must be enabled')
    resource.setrlimit(resource.RLIMIT_CPU,(60,60))
    resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,1536*1024**2))
    return {'AS_bytes':list(resource.getrlimit(resource.RLIMIT_AS)),
            'CPU_seconds':list(resource.getrlimit(resource.RLIMIT_CPU))}

def execute_call(entry,payload,python,output_dir,worker_script=None):
    worker_script=Path(worker_script) if worker_script else ROOT/'source/worker.py'
    cid=entry['call_id'];out=output_dir/f'{cid}.stdout';err=output_dir/f'{cid}.stderr'
    encoded=json.dumps(payload,separators=(',',':')).encode()
    item={'call_id':cid,'schedule':entry,'status':'UNREVIEWED_PROCESS_SUCCESS','returncode':None,
          'stdout':str(out.relative_to(ROOT)),'stderr':str(err.relative_to(ROOT)),
          'payload_sha256':hashlib.sha256(encoded).hexdigest(),'process_spawned':False}
    started=time.monotonic();use=resource.getrusage(resource.RUSAGE_CHILDREN);before=use.ru_utime+use.ru_stime;p=None;parent=os.getpid()
    try:
        with out.open('xb') as fo,err.open('xb') as fe:
            p=subprocess.Popen([python,'-B',str(worker_script)],stdin=subprocess.PIPE,
                               stdout=fo,stderr=fe,env=child_environment(),cwd=output_dir,
                               preexec_fn=lambda:parent_death(parent))
            item['process_spawned']=True
            try:p.communicate(encoded,timeout=25)
            except subprocess.TimeoutExpired:p.kill();p.communicate();item['status']='WALL_TIMEOUT'
            item['returncode']=p.returncode
            if p.returncode and item['status']=='UNREVIEWED_PROCESS_SUCCESS':item['status']='PROCESS_FAILURE_OR_CPU_LIMIT'
        if item['status']=='UNREVIEWED_PROCESS_SUCCESS':
            answer=json.loads(out.read_text())
            assert answer['seed']==entry['seed'] and answer['version']=='0.14.0'
            assert answer['max_iterations']==entry['max_iterations']
            assert answer['num_iterations']==entry['max_iterations']==len(answer['stats'])
            assert answer['denied_io_events']==[] and answer['reference_or_history_payload_fields']==[]
            assert answer['model_instances']==answer['solver_calls']==1
            assert answer['native_distance_matrix']==payload['distance_matrix']
            assert answer['native_matrix_entries_checked']==len(payload['coordinates'])**2
            assert answer['arm']==entry['arm'] and answer['scale']==entry['scale'] and answer['observe_penalties']==entry['observe_penalties']
            from endpoint_core import validate_observation
            validate_observation(answer,payload)
            if not answer['solver_is_feasible']:item['status']='UNREVIEWED_INFEASIBLE'
    except Exception as exc:item.update(status='CALL_ERROR_UNDETERMINED',error=str(exc),traceback=traceback.format_exc())
    finally:
        if p is not None:
            if p.poll() is None:p.kill()
            p.wait()
    use=resource.getrusage(resource.RUSAGE_CHILDREN)
    item.update(cpu_seconds_audit_only=use.ru_utime+use.ru_stime-before,
                wall_seconds_audit_only=time.monotonic()-started,child_reaped=p is None or p.poll() is not None)
    for label,file in [('stdout',out),('stderr',err)]:
        if file.exists():item[label+'_sha256']=sha(file)
    return item

def logged_call(entry,payload,python,output_dir,ledger_dir,worker_script=None):
    """Only constructor of attempts; no entry/item expansion can shadow event_kind."""
    append(ledger_dir/'attempts.jsonl',{'event_kind':'STARTED','utc':now(),'call_id':entry['call_id'],'schedule':entry})
    item=execute_call(entry,payload,python,output_dir,worker_script)
    append(ledger_dir/'results.jsonl',item)
    append(ledger_dir/'attempts.jsonl',{'event_kind':'FINISHED','utc':now(),'call_id':entry['call_id'],'schedule':entry,'result':item})
    return item

def main():
    assert len(sys.argv)==2 and sys.argv[1]=='formal'
    mode=sys.argv[1]
    limits=configure_supervisor_limits()
    from gates import check_gate,get_schedule,load_payload
    signal.alarm(12600)
    wall,cpu=time.monotonic(),time.process_time()
    gate=check_gate(mode);schedule=get_schedule(mode)
    dest=ROOT/'raw'
    save(dest/'STARTED.json',{'utc':now(),'mode':mode,'gate':gate,'planned_calls':len(schedule),
                             'no_retries':True,'supervisor_limits':limits})
    output_dir=dest/'calls';output_dir.mkdir(exist_ok=False);results=[];completion='COMPLETED_UNREVIEWED'
    for entry in schedule:
        try:
            payload=load_payload(entry,mode)
        except Exception as exc:
            item={'call_id':entry['call_id'],'schedule':entry,'status':'NOT_STARTED_INPUT_FAILURE',
                  'process_spawned':False,'error':repr(exc)}
            append(dest/'results.jsonl',item);results.append(item);completion='STOPPED_INPUT_IDENTITY_OR_CONTRACT_FAILURE';break
        # Upstream eligibility is field-wide: any input/guard failure blocks all4
        # logical slots, with no native call and no substitute field.
        if payload is None:
            item={'call_id':entry['call_id'],'schedule':entry,'status':'NOT_STARTED_INPUT_OR_TECHNICAL_BLOCKED',
                  'process_spawned':False,'returncode':None,'child_reaped':True,
                  'input_readiness':read('input/IDENTITIES.json')['fields'][entry['instance_id']]}
            append(dest/'results.jsonl',item);results.append(item);continue
        item=logged_call(entry,payload,gate['python'],output_dir,dest);results.append(item)
        if item['status']=='CALL_ERROR_UNDETERMINED':
            completion='STOPPED_UNDETERMINED_OUTPUT_CONTRACT_FAILURE';break
    signal.alarm(0)
    check_gate(mode)
    save(dest/'FINISHED.json',{'utc':now(),'mode':mode,'status':completion,
      'planned_calls':len(schedule),'retained_calls':len(results),
      'spawned_calls':sum(r['process_spawned'] for r in results),
      'wall_seconds_audit_only':time.monotonic()-wall,'supervisor_cpu_seconds_audit_only':time.process_time()-cpu,
      'supervisor_maxrss_KiB_audit_only':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
      'supervisor_effective_limits':limits,'old_files_verified_unchanged':verify_old()})
    return 0
if __name__=='__main__':
    raise SystemExit(main())
