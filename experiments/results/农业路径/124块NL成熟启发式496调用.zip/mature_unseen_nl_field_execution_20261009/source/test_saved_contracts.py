"""Standard-library replay of saved history and fictional summary failure branches.
No native/solver invocation. No new-field output or exact reference is read.
"""
import sys,json,copy,resource,signal
from common import ROOT,read,save,sha,now
from endpoint_core import validate_saved
from payload_contract import public_penalty_settings
from input_projection import planned_input_status
from gates import get_schedule,verify_scientific_lock,verify_input_binding
from report_core import blank_row,build_summary,apply_reference
from ledger import reconcile


def rejects(callback):
    try:callback()
    except (AssertionError,KeyError,TypeError,ValueError):return True
    return False


def main():
    resource.setrlimit(resource.RLIMIT_CPU,(15,15));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,1536*1024**2));signal.alarm(30)
    replay=ROOT/'selftests/saved_contract_replay';identities=read('selftests/saved_contract_replay/ORIGINAL_IDENTITIES.json')
    for name,meta in identities['files'].items():
        assert sha(replay/name)==meta['sha256'] and (replay/name).stat().st_size==meta['bytes']
    problem=json.loads((replay/'problem.json').read_text());checked={};transforms={}
    for arm in ('A','P'):
        original=json.loads((replay/(arm+'_original.stdout')).read_text());answer=copy.deepcopy(original)
        entry={'instance_id':'nl_field_40','proxy':'E','seed':0,'max_iterations':250,'arm':arm,'scale':1,'observe_penalties':True}
        payload={key:problem[key] for key in ('coordinates','demands','capacity','K')}
        payload.update({key:entry[key] for key in ('seed','max_iterations','arm','scale','observe_penalties')});payload['distance_matrix']=problem['matrices']['E']
        changes=['Add new public_penalty_bounds metadata from unchanged registered public settings']
        answer['public_penalty_bounds']=public_penalty_settings(payload)
        if arm=='A':answer['derived_penalty']=None;changes.append('Add explicit derived_penalty=None in A schema')
        else:
            assert answer['resource_limits']['inherited']['CPU_seconds']==[30,30]
            assert rejects(lambda:validate_saved(problem,entry,answer))
            answer['resource_limits']['inherited']['CPU_seconds']=[60,60]
            changes.append('Pure metadata fixture only: replace historical30CPU parent with planned60CPU parent; no runtime-performance assertion')
        checked[arm]=validate_saved(problem,entry,answer)
        invalid=copy.deepcopy(answer);invalid['public_penalty_bounds']['max_penalty']+=1
        assert rejects(lambda:validate_saved(problem,entry,invalid))
        invalid=copy.deepcopy(answer);invalid['native_distance_matrix'][0][1]+=1
        assert rejects(lambda:validate_saved(problem,entry,invalid))
        trace_fixture=copy.deepcopy(answer)
        trace_fixture['penalty_observation']['rows'][0]['best_is_feasible']=False
        trace_fixture['stats'][0]['best_feas']=False
        trace_check=validate_saved(problem,entry,trace_fixture)
        assert trace_check['valid'] is checked[arm]['valid']
        assert trace_check['observations']['diagnostic_best_feasible_retention_observed'] is False
        transforms[arm]=changes
    # Actual upstream metadata only; test missing identity/readiness fails closed.
    authors=read('upstream_evidence/ALL_FIELD_SLOTS.json');independent=read('upstream_evidence/FINAL_INPUT_AUDIT.json')['fields']
    a=authors[0];i=independent[0];field=a['instance_id'];assert field==i['instance_id']
    assert planned_input_status(field,a,i)['status']=='INPUT_AUDIT_READY_FOR_BYTE_AND_NUMERIC_CHECK'
    negative=[]
    for change in ('native_flag_missing','native_flag_false','sha_missing','bytes_mismatch','path_mismatch','author_failed'):
        aa,ii=copy.deepcopy(a),copy.deepcopy(i)
        if change=='native_flag_missing':ii['numeric_flags'].pop('native_policy_admissible')
        elif change=='native_flag_false':ii['numeric_flags']['native_policy_admissible']=False
        elif change=='sha_missing':aa['preprocess']['sha256']=ii['preprocess_sha256']=None
        elif change=='bytes_mismatch':ii['preprocess_bytes']+=1
        elif change=='path_mismatch':ii['preprocess_path']='raw/fields/unplanned/preprocess.json'
        else:aa['author_pass_unreviewed']=False
        status=planned_input_status(field,aa,ii)['status'];assert status.startswith('NOT_STARTED_');negative.append({'case':change,'status':status})
    schedule=get_schedule('formal');fields=read('upstream_identity/PANEL_SOURCE_IDENTITY.json')['field_ids_in_source_order']
    slots,errors=reconcile(schedule,'','');assert not errors and len(slots)==496
    rows=[blank_row(e,s) for e,s in zip(schedule,slots)];summary=build_summary(rows,fields)
    assert summary['known_not_spawned']==496 and summary['confirmed_model_and_solver_calls']==0
    for proxy in ('E','G'):
        for arm in ('A','P'):
            value=summary['by_proxy'][proxy]['arms'][arm]
            assert value['planned']==124 and value['valid_feasible']==0
            assert value['metrics']['normalized_own_cost']['complete_panel_mean'] is None
    assert summary['secondary_cross_G_on_E_pairs']['common_success']==0
    started=json.dumps({'event_kind':'STARTED','call_id':schedule[0]['call_id']})+'\n'
    partial,errors=reconcile(schedule,'',started);assert not errors and partial[0]['process_spawned'] is None
    assert len(partial)==496 and sum(r.get('process_spawned') is None for r in partial)==1
    # Fictional scalar-only endpoint fixture; not a native model or new field result.
    fixture={'valid':True,'proxy':'E','base_E':10,'base_G':35,'normalized_own_cost':10,
             'own_reference_verified':False,'own_gap_mm':None,'own_gap_percent':None,'exact_hit':None,
             'G_realized_excess_mm':None,'E_offset_from_lex_reference_mm':None,'E_optimal_tie_difference_mm':None,'exact_proxy_reference_delta_mm':None}
    ref={'objectives':{'E_G':{'verified':True,'E':10,'G':30},'G_E':{'verified':False}},'E_star':10,'G_star':None,'delta_integer_mm':None}
    apply_reference(fixture,ref)
    assert fixture['valid'] is True and fixture['exact_hit'] is True and fixture['E_optimal_tie_difference_mm']==5
    assert fixture['G_realized_excess_mm'] is None and fixture['exact_proxy_reference_delta_mm'] is None
    verify_scientific_lock();verify_input_binding()
    assert not any(name=='pyvrp' or name.startswith('pyvrp.') for name in sys.modules)
    save(ROOT/'selftests/SAVED_CONTRACT_REPLAY.json',{'utc':now(),'status':'PASS','history_replay_count':2,
       'history_metadata_fixture_transformations':transforms,'negative_input_identity_cases':negative,
       'all496_missing_denominator_and_null_test':'PASS','one_unknown_started_slot_reconciliation':'PASS',
       'single_verified_reference_dependency_test':'PASS','fictional_best_retention_anomaly_kept_as_diagnostic':'PASS','historical_original_bytes_preserved':True,
       'new_field_outputs_or_truth_read':False,'new_native_calls':0,'new_solver_calls':0,'new_model_constructions':0,
       'scope':'Pure saved-output parser and scalar/metadata fixture checks, not a fresh run, native toy, or new124 performance observation'})
    print(json.dumps({'status':'PASS','new_native_calls':0,'new_solver_calls':0,'tests':'saved history + metadata/scalar failure branches'}))

if __name__=='__main__':main()
