"""Saved-only 496-slot report, gated by algorithm RAW and independently audited truth.

No solver, native construction, exact optimization, geometry or shortest paths.
"""
import json,math,hashlib,resource,signal
from pathlib import Path
from common import ROOT,read,save,sha,now,verify_frozen,receipt
from report_core import blank_row,apply_checked,apply_reference,build_summary,ROW_AUDIT_KEYS
from input_projection import project_payload


def checked_truth(raw_sha):
    binding=read('postprocess_reference/REFERENCE_BINDING.json')
    assert binding['status']=='EXACT_FINAL_ORIGINAL_BYTES_BOUND_AFTER_ALGORITHM_RAW'
    assert binding['algorithm_raw_archive_sha256']==raw_sha
    for relative,meta in binding['files'].items():
        path=ROOT/relative
        assert path.stat().st_size==meta['bytes'] and sha(path)==meta['sha256']
    truth=read('postprocess_reference/EXACT_REFERENCE.json')
    assert truth['status']=='EXACT_REFERENCE_AUDITED' and truth['planned_fields']==124
    assert all(truth[key] is True for key in ('input_final_actual_readback','raw_main_actual_readback','raw_verification_actual_readback'))
    input_binding=read('upstream_identity/FINAL_INPUT_PACKAGE_IDENTITY.json')
    assert truth['input_final_archive_sha256']==input_binding['upstream_final_archive_sha256']
    assert truth['input_final_frozen_files_sha256']==input_binding['upstream_frozen_files_sha256']
    for key in ('frozen_files_sha256','raw_main_archive_sha256','raw_verification_archive_sha256','independent_audit_sha256'):
        assert truth[key]==binding[key]
    assert len(truth['fields'])==124
    fields=read('upstream_identity/PANEL_SOURCE_IDENTITY.json')['field_ids_in_source_order']
    assert [r['instance_id'] for r in truth['fields']]==fields
    identities=read('input/IDENTITIES.json')['fields']
    for record in truth['fields']:
        field=record['instance_id'];assert record['input_preprocess_sha256']==identities[field]['preprocess_sha256']
        objectives=record['objectives'];assert set(objectives)=={'E_G','G_E'}
        for key in ('E_G','G_E'):
            target=objectives[key];assert type(target['verified']) is bool
            if target['verified']:
                assert target['failure'] is None
                assert all(type(target[p]) is int and target[p]>=0 for p in ('E','G'))
            else:
                assert target['failure'] is not None
                assert all(target[k] is None for k in ('E','G','canonical_routes','partition'))
        both=all(target['verified'] for target in objectives.values())
        assert record['valid_for_exact_conclusion'] is both
        assert record['E_star']==(objectives['E_G']['E'] if objectives['E_G']['verified'] else None)
        assert record['G_star']==(objectives['G_E']['G'] if objectives['G_E']['verified'] else None)
        assert record['delta_integer_mm']==(objectives['E_G']['G']-objectives['G_E']['G'] if both else None)
    return {r['instance_id']:r for r in truth['fields']},binding


def checked_reference_routes(reference,problem):
    from endpoint_core import route_cost
    for target in reference['objectives'].values():
        if not target['verified']:continue
        routes=target['canonical_routes'];assert isinstance(routes,list) and len(routes)==3
        seen=[];groups=[]
        for route in routes:
            assert isinstance(route,list) and 3<=len(route)<=7 and route[0]==route[-1]==0
            assert all(type(v) is int and 1<=v<=12 for v in route[1:-1])
            seen.extend(route[1:-1]);groups.append(sorted(route[1:-1]))
        assert sorted(seen)==list(range(1,13))
        # Partition encoding is retained unchanged; closed-route coverage/costs suffice here.
        for proxy in ('E','G'):
            assert route_cost(problem['matrices'][proxy],routes)==target[proxy]


def collect_saved_evidence():
    from endpoint_core import validate_saved
    from gates import get_schedule,verify_input_binding
    from ledger import reconcile
    digest=verify_frozen();input_sha=verify_input_binding();raw=receipt('RAW_UNREVIEWED')
    preseal=read('raw/PRESEAL_IDENTITY_VERIFICATION.json')
    assert preseal['frozen_files_sha256']==digest
    assert preseal['old_manifest_sha256']==sha(ROOT/'freeze/OLD_FILES_BEFORE.json')
    assert preseal['old_files_verified_unchanged']==len(read('freeze/OLD_FILES_BEFORE.json')['files'])
    protocol=read('freeze/PROTOCOL.json');schedule=get_schedule('formal')
    slots=read('raw/ALL_PLANNED_SLOTS.json');outer=read('raw/EXECUTOR_FINISHED.json')
    assert len(schedule)==len(slots)==496 and [r['schedule'] for r in slots]==schedule
    assert outer['cleanup']['quiescent'] is True
    results=(ROOT/'raw/results.jsonl').read_text() if (ROOT/'raw/results.jsonl').exists() else ''
    attempts=(ROOT/'raw/attempts.jsonl').read_text() if (ROOT/'raw/attempts.jsonl').exists() else ''
    recovered,errors=reconcile(schedule,results,attempts)
    assert slots==recovered and errors==outer['ledger_errors']
    references,reference_binding=checked_truth(raw['sha256'])
    identities=read('input/IDENTITIES.json')['fields'];problems={};rows=[]
    for field,identity in identities.items():
        if not identity['native_ready']:continue
        preprocess=read(identity['local_input_path'])
        problem={key:preprocess[key] for key in ('coordinates','demands','capacity','K')}
        problem['matrices']=preprocess['integer_matrices'];problem['preprocess']=preprocess
        checked_reference_routes(references[field],problem);problems[field]=problem
    for entry,slot in zip(schedule,slots):
        row=blank_row(entry,slot)
        try:
            assert slot['status'] in ('UNREVIEWED_PROCESS_SUCCESS','UNREVIEWED_INFEASIBLE'),'NON_SUCCESS_PROCESS_STATUS'
            assert slot['returncode']==0 and slot['process_spawned'] is True and slot['child_reaped'] is True
            assert not errors,'LEDGER_INTEGRITY_FAILURE'
            stdout=(ROOT/slot['stdout']).resolve();stderr=(ROOT/slot['stderr']).resolve()
            assert all(p.is_relative_to((ROOT/'raw/calls').resolve()) for p in (stdout,stderr))
            assert sha(stdout)==slot['stdout_sha256'] and sha(stderr)==slot['stderr_sha256'],'RAW_OUTPUT_HASH_MISMATCH'
            problem=problems[entry['instance_id']]
            payload=project_payload(problem['preprocess'],entry['proxy'],entry['arm'])
            encoded=json.dumps(payload,separators=(',',':')).encode()
            assert hashlib.sha256(encoded).hexdigest()==slot['payload_sha256'],'WORKER_PAYLOAD_IDENTITY_MISMATCH'
            answer=json.loads(stdout.read_text());checked=validate_saved(problem,entry,answer)
            assert checked['valid']==(slot['status']=='UNREVIEWED_PROCESS_SUCCESS')
            apply_checked(row,checked,answer)
        except (AssertionError,KeyError,TypeError,ValueError,OSError,IndexError,OverflowError) as exc:
            row=blank_row(entry,slot);row['failure']=type(exc).__name__+':'+str(exc)
        # A missing target reference never invalidates an otherwise valid route.
        # An inconsistent certified optimum is a report-level integrity failure.
        apply_reference(row,references[entry['instance_id']]);rows.append(row)
    summary=build_summary(rows,protocol['fields'])
    return {'utc':now(),'status':'AUTHOR_SAVED_REPORT_COMPLETE_PENDING_INDEPENDENT_REVIEW',
        'frozen_files_sha256':digest,'scientific_policy_lock_sha256':protocol['scientific_policy_lock_sha256'],
        'raw_archive_sha256':raw['sha256'],'input_final_archive_sha256':input_sha,
        'reference_final_archive_sha256':reference_binding['reference_final_archive_sha256'],
        'reference_truth_sha256':sha(ROOT/'postprocess_reference/EXACT_REFERENCE.json'),
        'planned_slots':496,'field_denominator':124,'planned_per_arm_proxy':124,'seeds_per_field':1,
        'formal_known_spawned':outer['known_spawned'],'formal_unknown_spawned_slots':outer['unknown_spawned_slots'],
        'ledger_errors':errors,'new_solver_calls_in_report':0,'new_native_constructions_in_report':0,
        'new_exact_computations_in_report':0,'historical_cells_in_statistics':0,
        'rows':rows,**summary,'analysis_commitments':protocol['analysis_commitments'],
        'complete_panel_policy':'Any missing required endpoint yields null complete-panel mean. Conditional subset denominator is shown.',
        'primary_statistical_unit':'124 registered fields; arms/proxies are repeated measurements, not independent samples.'}


def exact_match(expected,actual,path='root'):
    if isinstance(expected,dict):
        assert isinstance(actual,dict),path
        for key,value in expected.items():
            assert key in actual,path+'.'+key;exact_match(value,actual[key],path+'.'+key)
    elif isinstance(expected,list):
        assert isinstance(actual,list) and len(expected)==len(actual),path
        for i,(left,right) in enumerate(zip(expected,actual)):exact_match(left,right,path+'['+str(i)+']')
    elif isinstance(expected,float):
        assert type(actual) in (float,int) and math.isclose(expected,actual,rel_tol=1e-12,abs_tol=1e-12),path
    else:assert type(expected) is type(actual) and expected==actual,path


SECTIONS=('by_proxy','overall','per_field','paired_rows','secondary_cross_G_on_E_pairs','P_invariant_transfer')

def check_independent(data,audit):
    assert audit['status']=='SAVED_UNSEEN_AUDITED'
    for key in ('raw_archive_sha256','frozen_files_sha256','reference_truth_sha256','input_final_archive_sha256'):
        assert audit[key]==data[key]
    assert len(audit['rows'])==len(data['rows'])==496
    indexed={r['call_id']:r for r in audit['rows']};assert len(indexed)==496
    assert set(indexed)=={r['call_id'] for r in data['rows']}
    for row in data['rows']:
        for key in ROW_AUDIT_KEYS:exact_match(indexed[row['call_id']][key],row[key],row['call_id']+'.'+key)
    for key in SECTIONS:exact_match(audit[key],data[key],key)
    return ['496rows',*SECTIONS]


def readable(value,unit=''):
    return '不可估计' if value is None else f'{value}{unit}'


def report_text(data):
    lines=['124块NL田注册扩展：默认罚项与输入派生容量优先P，496个计划槽',
        '每田seed0，E/G分别搜索，默认A与P均为新运行，250次ILS在初始化之后计数。旧12田不进入本报告统计。',
        '固定P=15×当前单矩阵最大边+1；公开min=max影响全部罚项通道，当前模型仅容量约束可能产生有效违规。',
        'n12、单位需求、Q5、最多3车、完整覆盖、单趟、非负整数距离、无其它有效费用/时间约束。',
        '条件性源码预测是：原始4/4/4已可行，固定官方0.14.0与安全算术下的初始化/current/best可行不变式迁移。质量和精确命中是250预算下另行观察的结果。',
        f"计划496槽；已知进程启动{data['formal_known_spawned']}，进程是否启动未知{data['formal_unknown_spawned_slots']}；完整有效输出确认model/solver各{data['confirmed_model_and_solver_calls']}，另有{data['unconfirmed_possible_model_or_solver_calls']}槽可能调用但未确认。",'']
    for proxy in ('E','G'):
        for arm in ('A','P'):
            value=data['by_proxy'][proxy]['arms'][arm]
            lines.append(f"{proxy}/{arm}：合法可行{value['valid_feasible']}/124，已验证原生不可行{value['verified_native_infeasible']}，输入/技术/未知等{value['technical_or_unverified_or_not_run']}；已确认自身单目标精确命中{value['confirmed_exact_hits']}/124，精确可评分合法槽{value['exact_scored_valid']}。")
            own=value['metrics']['own_gap_mm']
            lines.append(f"  完整面板平均自身gap：{readable(own['complete_panel_mean'],'mm')}；可评分子集{own['available']}/124，条件均值{readable(own['conditional_mean'],'mm')}。")
        pair=data['by_proxy'][proxy]['pairs'];own=pair['deltas']['delta_own_cost_P_minus_A_mm']
        lines.append(f"{proxy}双方共同成功{pair['common_success']}/124；P-A自身成本差条件均值{readable(own['conditional_mean'],'mm')}，完整124对均值{readable(own['complete_panel_mean'],'mm')}。")
    cross=data['secondary_cross_G_on_E_pairs'];cs=cross['summary']
    lines+=['',f"E搜索路线的G实现成本差（P-A）：共同成功{cross['common_success']}/124，排除/缺失{cross['excluded_or_missing']}；正{cross['positive']}、零{cross['zero']}、负{cross['negative']}。",
        f"该配对ΔG条件均值{readable(cs['conditional_mean'],'mm')}，最小{readable(cs['min'],'mm')}，最大{readable(cs['max'],'mm')}。正值表示P的E搜索结果在G实现上更贵。",'',
        '解释与限制：',
        '- P初始化、全部250个current终点及返回best的真/假/未知分母，分别见SUMMARY的P_invariant_transfer；内部扰动候选不受完整性定理保证。',
        '- 自身E或G单目标精确命中不等于两个词典序参考都命中，也不代表另一代理或物理路线普遍改善。',
        '- 上述处理配对ΔG、精确代理参考Delta、自身gap和相对E_G的有符号偏移分别定义；真值缺失只令其依赖指标为null，合法路线可行性不会被降为不可行。',
        '- 两矩阵都按事先冻结技术guard准入；超限、输入失败、进程失败与未知均保留槽，不替换、不重试、不记为原生不可行。',
        '- 失败成本不填零。全496槽与每臂/代理124分母保留，完整面板与条件共同成功统计分列。',
        '- 这是既定面板之外的注册扩展，未证明跨全部历史全然未见；不作独立同分布、显著性、普遍泛化或速度结论。',
        '- 相同几何、首13服务点及base节点下，旧额外8终端禁止内部中转，删除它们本身不改变首13 E/G成本；本线直接12客户生成与旧20点全体通过门槛、检查规模及字段不同，不能作单一因素因果解释。',
        '- G是冻结有限候选图路径代理，非连续平面全局最短路。',
        '- P(sD)=sU+1并非sP；不宣称完整算法轨迹单位不变。',
        '- 精确真值只在算法RAW已私有实际原字节回读后的分析层读取，worker始终只收当前单一矩阵。报告新增solver/native/精确求解均0。',
        '- 496行及6组汇总经保存证据独审逐项比对；源预测与实际观察分开。']
    return '\n'.join(lines)+'\n'


def main():
    resource.setrlimit(resource.RLIMIT_CPU,(60,60));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,1536*1024**2));signal.alarm(240)
    data=collect_saved_evidence();audit_path='independent_supervision/results/SAVED_UNSEEN_AUDIT.json'
    compared=check_independent(data,read(audit_path))
    data['status']='INDEPENDENT_SAVED_VERIFIED_PENDING_REPORT_REVIEW'
    data['independent_saved_audit_sha256']=sha(ROOT/audit_path);data['independently_compared_sections']=compared
    save(ROOT/'reports/STARTED.json',{'utc':now(),'solver_calls':0,'native_constructions':0,'exact_computations':0,'independent_comparison_before_write':True})
    save(ROOT/'reports/SUMMARY.json',data)
    with (ROOT/'reports/REPORT_ZH.txt').open('x') as handle:handle.write(report_text(data))
    print(json.dumps({'report':'reports/REPORT_ZH.txt','planned_slots':496,'independently_compared_sections':compared}))

if __name__=='__main__':main()
