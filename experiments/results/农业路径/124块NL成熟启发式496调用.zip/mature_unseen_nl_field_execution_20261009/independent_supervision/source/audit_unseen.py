"""Independently audit saved fresh496 calls and post-RAW exact references."""
from unseen_inputs import *
from unseen_summary import endpoint,summarize,ROW_KEYS,SECTIONS
import resource,signal,time


def blank(entry, slot):
    row=dict(entry);status=slot.get('status','MISSING_RESULT')
    input_status=(slot.get('input_readiness') or {}).get('status')
    categories={'UNKNOWN_AFTER_SUPERVISOR_FAILURE':'UNKNOWN_PROCESS_OR_OUTPUT',
        'NOT_STARTED_SUPERVISOR_FAILURE':'NOT_STARTED_SUPERVISOR_FAILURE',
        'NOT_STARTED_INPUT_FAILURE':'RUNTIME_INPUT_IDENTITY_OR_CONTRACT_FAILURE',
        'WALL_TIMEOUT':'PROCESS_FAILURE_OR_LIMIT','PROCESS_FAILURE_OR_CPU_LIMIT':'PROCESS_FAILURE_OR_LIMIT'}
    category=categories.get(status,'UNVERIFIED_OUTPUT_OR_CALL_ERROR')
    if status=='NOT_STARTED_INPUT_OR_TECHNICAL_BLOCKED':
        category='TECHNICAL_GUARD_BLOCKED' if input_status and ('NATIVE_POLICY' in input_status or 'GUARD' in input_status) else 'INPUT_FAILURE_OR_UNVERIFIED'
    row.update(raw_status=status,process_spawned=slot.get('process_spawned'),valid=False,record_verified=False,
        routing_violation=None,failure=None,failure_class=category,input_readiness_status=input_status,
        base_E=None,base_G=None,normalized_own_cost=None,diagnostic_base_E=None,diagnostic_base_G=None,
        own_reference_verified=False,own_gap_mm=None,own_gap_percent=None,exact_hit=None,G_realized_excess_mm=None,
        E_offset_from_lex_reference_mm=None,E_optimal_tie_difference_mm=None,exact_proxy_reference_delta_mm=None,
        observations=None,routes=None,loads=None,offset_is_search_error=False)
    return row


def promote(row, checked, answer):
    row.update(record_verified=True,routing_violation=checked['routing_violation'],
        diagnostic_base_E=checked['base_E'],diagnostic_base_G=checked['base_G'],
        observations=checked['observations'],routes=checked['routes'],loads=checked['loads'])
    if not checked['valid']:
        row.update(failure='NO_FEASIBLE_INCUMBENT',failure_class='VERIFIED_NATIVE_INFEASIBLE')
    else:
        require(answer['reported_cost']==checked['normalized_own_cost'],'feasible direct integer cost')
        row.update(valid=True,failure_class='VALID_FEASIBLE',base_E=checked['base_E'],base_G=checked['base_G'],normalized_own_cost=checked['normalized_own_cost'])


def expected_schedule(fields):
    rows=[]
    for i,field in enumerate(fields):
        for j,proxy in enumerate(('E','G')):
            order=['A','P'] if (i+j)%2==0 else ['P','A']
            for pos,arm in enumerate(order,1):
                rows.append({'schedule_index':len(rows)+1,'call_id':f'{field}_{proxy}_s0_{arm}_i250',
                    'instance_id':field,'proxy':proxy,'seed':0,'arm':arm,'max_iterations':250,'scale':1,
                    'observe_penalties':True,'pair_index':2*i+j+1,'arm_position':pos,'arm_order':order})
    return rows


def collect(schedule,slots,items,events,errors,outer,problems,truth,params,fields):
    ledger,by=audit_ledger(schedule,events,items,slots,errors,outer)
    records={r['schedule']['call_id']:r for r in slots};rows=[]
    for entry in schedule:
        cid=entry['call_id'];slot=records[cid];row=blank(entry,slot)
        try:
            require(slot.get('status')in('UNREVIEWED_PROCESS_SUCCESS','UNREVIEWED_INFEASIBLE')and slot.get('process_spawned')is True and slot.get('child_reaped')is True and slot.get('returncode')==0 and not slot.get('error'),'completed native call')
            require(not ledger['errors']and not ledger['per_call_errors'][cid],'chronological complete process evidence')
            require(slot['stdout']==f'raw/calls/{cid}.stdout'and slot['stderr']==f'raw/calls/{cid}.stderr','fixed call stream paths')
            for stream in('stdout','stderr'):require(sha(ROOT/slot[stream])==slot[stream+'_sha256'],'saved stream bytes')
            problem=problems[entry['instance_id']];wire=payload(problem,entry)
            require(hashlib.sha256(compact(wire)).hexdigest()==slot['payload_sha256'],'single-matrix ten-key actual payload')
            answer=load(ROOT/slot['stdout']);checked=check_answer(problem,entry,answer,params)
            require(checked['valid']==(slot['status']=='UNREVIEWED_PROCESS_SUCCESS'),'saved status and independent feasibility')
            promote(row,checked,answer)
        except (ValueError,AssertionError,KeyError,TypeError,OSError,IndexError,OverflowError) as exc:
            row=blank(entry,slot);row['failure']=type(exc).__name__+':'+str(exc)
        endpoint(row,truth[entry['instance_id']]);rows.append(row)
    return {'status':'SAVED_UNSEEN_AUDITED','planned_slots':496,'field_denominator':124,'planned_per_arm_proxy':124,
        'seeds_per_field':1,'rows':rows,'ledger':ledger,'ledger_errors':ledger['errors'],
        'formal_known_spawned':ledger['known_spawned'],'formal_unknown_spawned_slots':ledger['unknown_spawned_slots'],
        'new_solver_calls':0,'new_native_constructions':0,'new_exact_computations':0,'historical_cells_in_statistics':0,
        **summarize(rows,fields)}


def old_preservation_evidence():
    path=ROOT/'raw/PRESEAL_IDENTITY_VERIFICATION.json'
    if not path.exists():return {'status':'UNKNOWN_NO_SAVED_POSTEXECUTION_CHECK','external_paths_reread':False}
    evidence=load(path);expected=load(ROOT/'freeze/OLD_FILES_BEFORE.json')['files']
    require(evidence['frozen_files_sha256']==sha(ROOT/'freeze/FROZEN_FILES.json'),'preseal frozen identity')
    require(evidence['old_manifest_sha256']==sha(ROOT/'freeze/OLD_FILES_BEFORE.json')and evidence['old_files_verified_unchanged']==len(expected),'preseal original-workspace check record')
    return {'status':'SAVED_POSTEXECUTION_CHECK_VERIFIED','external_files_count':len(expected),'external_paths_reread':False,'evidence_sha256':sha(path)}


def main():
    resource.setrlimit(resource.RLIMIT_CPU,(120,120));resource.setrlimit(resource.RLIMIT_AS,(536870912,1610612736));signal.alarm(300)
    receipt=gate();dest=ROOT/'independent_supervision/results';dest.mkdir(exist_ok=True)
    save_exclusive(dest/'SAVED_AUDIT_STARTED.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'new_solver_calls':0,'new_native_calls':0})
    cpu=time.process_time();wall=time.monotonic();fields,problems,readiness,ids=source_inputs()
    schedule=load(ROOT/'freeze/PROPOSED_SCHEDULE.json')['entries'];require(schedule==expected_schedule(fields),'fixed balanced fresh496 schedule')
    truth,binding=source_references(receipt['sha256'],fields,ids,problems)
    events,ee=lines(ROOT/'raw/attempts.jsonl');items,ie=lines(ROOT/'raw/results.jsonl')
    result=collect(schedule,load(ROOT/'raw/ALL_PLANNED_SLOTS.json'),items,events,ee+ie,load(ROOT/'raw/EXECUTOR_FINISHED.json'),
        problems,truth,load(ROOT/'environment/DEFAULT_SOLVE_PARAMS.json')['parameters'],fields)
    result.update(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),frozen_files_sha256=receipt['frozen_files_sha256'],
        raw_archive_sha256=receipt['sha256'],scientific_policy_lock_sha256=SCIENCE_SHA,input_final_archive_sha256=INPUT_SHA,
        reference_final_archive_sha256=binding['reference_final_archive_sha256'],reference_truth_sha256=sha(ROOT/'postprocess_reference/EXACT_REFERENCE.json'),
        old_file_preservation=old_preservation_evidence(),input_ready_fields=sum(readiness.values()),
        resources={'cpu_seconds':time.process_time()-cpu,'wall_seconds':time.monotonic()-wall,'maxrss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss})
    save_exclusive(dest/'SAVED_UNSEEN_AUDIT.json',result)
    print(json.dumps({'status':result['status'],'planned_slots':496,'confirmed_model_and_solver_calls':result['confirmed_model_and_solver_calls'],
        'valid_A':result['overall']['arms']['A']['valid_feasible'],'valid_P':result['overall']['arms']['P']['valid_feasible']}))


if __name__=='__main__':main()
