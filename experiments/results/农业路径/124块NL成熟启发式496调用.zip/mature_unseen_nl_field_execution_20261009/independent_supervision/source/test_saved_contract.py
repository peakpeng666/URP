"""Reuse two saved old outputs and invented endpoint JSON, never call native code."""
from audit_unseen import *
import copy,sys
sys.path.insert(0,str(ROOT/'source'))
from endpoint_core import validate_saved as author_check
from report_core import build_summary as author_summary,apply_reference as author_reference


def main():
    resource.setrlimit(resource.RLIMIT_CPU,(15,15));resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912));signal.alarm(60)
    folder=ROOT/'selftests/saved_contract_replay';ids=load(folder/'ORIGINAL_IDENTITIES.json')
    for name,item in ids['files'].items():require(sha(folder/name)==item['sha256']and(folder/name).stat().st_size==item['bytes'],'saved fixture identity')
    problem=load(folder/'problem.json');params=load(ROOT/'environment/DEFAULT_SOLVE_PARAMS.json')['parameters'];tests=[]
    for arm in('A','P'):
        original=load(folder/(arm+'_original.stdout'));answer=copy.deepcopy(original)
        entry={'instance_id':'nl_field_40','proxy':'E','seed':0,'max_iterations':250,'arm':arm,'scale':1,'observe_penalties':True}
        d=derive(problem['matrices']['E'],12,3) if arm=='P' else None
        answer['derived_penalty']=d;answer['public_penalty_bounds']={'min_penalty':float(d['P']),'max_penalty':float(d['P'])} if d else {'min_penalty':.1,'max_penalty':100000.0}
        answer['resource_limits']['inherited']['CPU_seconds']=[60,60]
        own=check_answer(problem,entry,answer,params);other=author_check(problem,entry,answer)
        for key in('valid','routing_violation','base_E','base_G','normalized_own_cost','routes','loads','observations'):equal(own[key],other[key],'saved fixture '+key)
        bad=copy.deepcopy(answer);bad['penalty_observation']['rows'][0]['best_is_feasible']=False;bad['stats'][0]['best_feas']=False
        checked=check_answer(problem,entry,bad,params);compared=author_check(problem,entry,bad)
        require(checked['valid']==own['valid']and checked['observations']['diagnostic_best_feasible_retention_observed']is False,'prediction counterexample kept')
        equal(checked['observations'],compared['observations'],'counterexample observation')
        malformed=copy.deepcopy(answer);malformed['native_distance_matrix'][0][1]+=1
        try:check_answer(problem,entry,malformed,params)
        except ValueError:pass
        else:raise AssertionError('Changed native matrix accepted')
        tests.append({'case':'saved_'+arm,'status':'PASS','transforms':'Pure metadata: public bounds/derived=None for A; inherited60CPU for new-stage schema. No fresh execution.'})
    fields=load(ROOT/'freeze/PROTOCOL.json')['fields'];schedule=expected_schedule(fields)
    rows=[blank(e,{'status':'NOT_STARTED_SUPERVISOR_FAILURE','process_spawned':False})for e in schedule]
    equal(summarize(rows,fields),author_summary(rows,fields),'all496 absent')
    for arm,E,G in [('A',10,35),('P',11,33)]:
        row=next(r for r in rows if r['instance_id']==fields[0]and r['proxy']=='E'and r['arm']==arm)
        row.update(valid=True,record_verified=True,routing_violation=False,process_spawned=True,
            raw_status='UNREVIEWED_PROCESS_SUCCESS',failure_class='VALID_FEASIBLE',base_E=E,base_G=G,normalized_own_cost=E)
        reference={'objectives':{'E_G':{'verified':True,'E':10,'G':30},'G_E':{'verified':False}},'E_star':10,'G_star':None,'delta_integer_mm':None}
        check=copy.deepcopy(row);endpoint(row,reference);author_reference(check,reference)
        for key in ROW_KEYS:equal(row[key],check[key],'partial truth '+key)
        require(row['G_realized_excess_mm']is None and row['exact_proxy_reference_delta_mm']is None,'unavailable reference stays null')
    result=summarize(rows,fields);equal(result,author_summary(rows,fields),'one invented pair')
    require(result['secondary_cross_G_on_E_pairs']['common_success']==1 and result['secondary_cross_G_on_E_pairs']['negative']==1,'paired signed G outcome')
    require(result['by_proxy']['E']['arms']['P']['metrics']['normalized_own_cost']['complete_panel_mean']is None,'missing not zero')
    assert not any(k=='pyvrp'or k.startswith('pyvrp.')for k in sys.modules)
    out={'status':'PASS','tests':tests,'all496_missing_and_one_partial_truth_pair':'PASS','source_prediction_counterexample_retained':'PASS',
        'new_field_results_read':False,'new_native_calls':0,'new_solver_calls':0,'new_synthetic_objective_calls':0,
        'scope':'Saved prior12 output reuse plus explicitly invented JSON-only summaries; no current124 algorithm performance.'}
    save_exclusive(ROOT/'independent_supervision/preparation/SAVED_CONTRACT_REPLAY.json',out);print(json.dumps(out))


if __name__=='__main__':main()
