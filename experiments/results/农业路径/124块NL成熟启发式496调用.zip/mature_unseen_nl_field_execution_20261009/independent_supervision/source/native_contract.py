from original_primitives import *
def expected_native(p):
    n=len(p['coordinates']);u=2**63-1
    v={'capacity':[p['capacity']],'num_available':p['K'],'start_depot':0,'end_depot':0,'fixed_cost':0,'unit_distance_cost':1,'unit_duration_cost':0,'unit_overtime_cost':0,'initial_load':[0],'reload_depots':[],'max_reloads':0,'max_trips':1,'max_overtime':0,'max_distance':u,'max_duration':u,'shift_duration':u,'start_late':u,'tw_early':0,'tw_late':u,'profile':0}
    c=[{'location':i,'delivery':[p['demands'][i]],'pickup':[0],'service_duration':0,'prize':0,'required':True,'release_time':0,'tw_early':0,'tw_late':u,'group':None}for i in range(1,n)]
    return {'locations':[{'x':q[0],'y':q[1]}for q in p['coordinates']],'num_vehicle_types':1,'num_profiles':1,'num_groups':0,'vehicle':v,'clients':c,'depot':{'location':0,'service_duration':0,'tw_early':0,'tw_late':u},'num_locations':n,'num_clients':n-1,'num_depots':1,'num_vehicles':p['K'],'num_shipments':0,'duration_matrix_all_zero':True}
