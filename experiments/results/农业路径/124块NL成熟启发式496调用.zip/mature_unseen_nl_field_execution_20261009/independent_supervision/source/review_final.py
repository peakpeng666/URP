"""Final496-row report check with direct semantic prose review kept separate."""
from audit_unseen import *

COUNTS=('confirmed_model_and_solver_calls','unconfirmed_possible_model_or_solver_calls',
        'known_process_spawned','unknown_process_spawned','known_not_spawned')


def compare(audit,summary):
    require(audit['status']=='SAVED_UNSEEN_AUDITED','independent audit complete')
    for key in ('frozen_files_sha256','raw_archive_sha256','input_final_archive_sha256','reference_truth_sha256','reference_final_archive_sha256'):
        require(audit[key]==summary[key],'report binding '+key)
    require(audit['planned_slots']==summary['planned_slots']==496 and audit['field_denominator']==summary['field_denominator']==124,'fixed denominator')
    require(len(audit['rows'])==len(summary['rows'])==496,'all496 rows')
    by={row['call_id']:row for row in audit['rows']};require(len(by)==496 and set(by)=={r['call_id']for r in summary['rows']},'complete unique call identity')
    for row in summary['rows']:
        for key in ROW_KEYS:equal(by[row['call_id']][key],row[key],row['call_id']+'.'+key)
    for key in SECTIONS+COUNTS:equal(audit[key],summary[key],key)
    require(summary['formal_known_spawned']==audit['formal_known_spawned']and summary['formal_unknown_spawned_slots']==audit['formal_unknown_spawned_slots'],'reported process counts')
    require(summary['new_solver_calls_in_report']==summary['new_native_constructions_in_report']==summary['new_exact_computations_in_report']==0,'saved-only final report')
    require(summary['historical_cells_in_statistics']==0,'old12 excluded')
    return True


def main():
    resource.setrlimit(resource.RLIMIT_CPU,(15,15));resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912));signal.alarm(60)
    started=time.monotonic();cpu=time.process_time();rec=gate()
    audit_path=ROOT/'independent_supervision/results/SAVED_UNSEEN_AUDIT.json'
    audit=load(audit_path);summary=load(ROOT/'reports/SUMMARY.json')
    require(audit['frozen_files_sha256']==rec['frozen_files_sha256']and audit['raw_archive_sha256']==rec['sha256'],'final audit/raw binding')
    require(summary['independent_saved_audit_sha256']==sha(audit_path),'report independent audit bytes')
    require(audit['reference_truth_sha256']==sha(ROOT/'postprocess_reference/EXACT_REFERENCE.json'),'final reference bytes')
    compare(audit,summary)
    out={'status':'PASS','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'frozen_files_sha256':rec['frozen_files_sha256'],'raw_archive_sha256':rec['sha256'],
        'report_sha256':sha(ROOT/'reports/REPORT_ZH.txt'),'summary_sha256':sha(ROOT/'reports/SUMMARY.json'),
        'independent_audit_sha256':sha(audit_path),'reference_truth_sha256':audit['reference_truth_sha256'],
        'input_final_archive_sha256':INPUT_SHA,'planned_slots':496,'field_denominator':124,
        'confirmed_model_and_solver_calls':audit['confirmed_model_and_solver_calls'],
        'unconfirmed_possible_model_or_solver_calls':audit['unconfirmed_possible_model_or_solver_calls'],
        'new_solver_calls':0,'new_native_calls':0,'new_exact_calls':0,
        'reader_review_method':'Separate direct semantic reading of actual report; no keyword gate.',
        'resources':{'cpu_seconds':time.process_time()-cpu,'wall_seconds':time.monotonic()-started}}
    save_exclusive(ROOT/'independent_supervision/results/FINAL_REPORT_REVIEW.json',out)
    print(json.dumps(out))


if __name__=='__main__':main()
