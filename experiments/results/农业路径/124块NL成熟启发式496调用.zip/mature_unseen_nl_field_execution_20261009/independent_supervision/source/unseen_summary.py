"""Independent registered endpoints and summaries from independently checked rows."""
from collections import Counter

ROW_KEYS=('call_id','instance_id','proxy','seed','arm','scale','max_iterations',
          'valid','record_verified','routing_violation','base_E','base_G','normalized_own_cost',
          'own_reference_verified','own_gap_mm','own_gap_percent','exact_hit','G_realized_excess_mm',
          'E_offset_from_lex_reference_mm','E_optimal_tie_difference_mm','exact_proxy_reference_delta_mm',
          'observations','process_spawned','raw_status','failure_class','input_readiness_status')
METRICS=('base_E','base_G','normalized_own_cost','own_gap_mm','own_gap_percent','G_realized_excess_mm',
         'E_offset_from_lex_reference_mm','E_optimal_tie_difference_mm')
SECTIONS=('by_proxy','overall','per_field','paired_rows','secondary_cross_G_on_E_pairs','P_invariant_transfer')


def endpoint(row, reference):
    if not row['valid']: return
    targets=reference['objectives']; own='E_G' if row['proxy']=='E' else 'G_E'
    eg,ge=targets['E_G'],targets['G_E']
    if targets[own]['verified']:
        star=targets[own][row['proxy']];gap=row['normalized_own_cost']-star
        if gap<0: raise ValueError('NEGATIVE_OWN_OBJECTIVE_GAP')
        row.update(own_reference_verified=True,own_gap_mm=gap,own_gap_percent=100*gap/star if star else None,exact_hit=(gap==0))
    if ge['verified']:
        excess=row['base_G']-ge['G']
        if excess<0: raise ValueError('NEGATIVE_REALIZED_G_EXCESS')
        row['G_realized_excess_mm']=excess
    if row['proxy']=='E' and eg['verified']:
        row['E_offset_from_lex_reference_mm']=row['base_G']-eg['G']
        if row['exact_hit'] is True:
            if row['E_offset_from_lex_reference_mm']<0:raise ValueError('NEGATIVE_E_OPTIMAL_TIE')
            row['E_optimal_tie_difference_mm']=row['E_offset_from_lex_reference_mm']
    if eg['verified'] and ge['verified']:
        delta=eg['G']-ge['G']
        if delta<0 or delta!=reference['delta_integer_mm']:raise ValueError('EXACT_PROXY_DELTA_IDENTITY')
        row['exact_proxy_reference_delta_mm']=delta
        if row['proxy']=='E' and row['G_realized_excess_mm']!=row['E_offset_from_lex_reference_mm']+delta:
            raise ValueError('CROSS_OBJECTIVE_DECOMPOSITION')


def values(numbers, denominator):
    n=len(numbers)
    return {'available':n,'planned':denominator,'missing':denominator-n,
            'conditional_mean':sum(numbers)/n if n else None,'min':min(numbers) if n else None,
            'max':max(numbers) if n else None,'complete_panel_mean':sum(numbers)/n if n==denominator and n else None}


def observations(rows):
    out={'planned':len(rows),'scope':'Saved public endpoint observations. Only the P arm tests the registered conditional source-invariant transfer; no general search-quality theorem.'}
    for key in ('initial_solution_feasible','source_prediction_current_feasible_all250_observed'):
        counts={'true':0,'false':0,'unknown_or_not_run':0}
        for row in rows:
            value=(row['observations'] or {}).get(key)
            counts['true' if value is True else 'false' if value is False else 'unknown_or_not_run']+=1
        out[key]=counts
    out['returned_best_feasible']={'true':sum(row['record_verified'] and row['valid'] for row in rows),
        'false':sum(row['record_verified'] and not row['valid'] for row in rows),
        'unknown_or_not_run':sum(not row['record_verified'] for row in rows)}
    return out


def arm_group(rows):
    n=len(rows);feasible=[r for r in rows if r['valid']]
    scored=[r for r in feasible if r['own_reference_verified']];hits=sum(r['exact_hit'] is True for r in scored)
    return {'planned':n,'valid_feasible':len(feasible),'valid_feasible_rate_all_planned':len(feasible)/n if n else None,
        'verified_native_infeasible':sum(r['record_verified'] and not r['valid'] for r in rows),
        'technical_or_unverified_or_not_run':sum(not r['record_verified'] for r in rows),
        'raw_status_counts':dict(Counter(r['raw_status'] for r in rows)),
        'failure_class_counts':dict(Counter(r['failure_class'] for r in rows)),
        'exact_scored_valid':len(scored),'confirmed_exact_hits':hits,'confirmed_hit_yield_all_planned':hits/n if n else None,
        'exact_hit_rate_scored_valid_only':hits/len(scored) if scored else None,'exact_score_missing_or_invalid':n-len(scored),
        'metrics':{key:values([r[key] for r in feasible if r[key] is not None],n) for key in METRICS},
        'observations':observations(rows)}


def pair_group(pairs):
    n=len(pairs);common=[p for p in pairs if p['common_success']]
    transitions=Counter(('valid' if p['A_valid'] else 'not_valid')+'->'+('valid' if p['P_valid'] else 'not_valid') for p in pairs)
    keys=('delta_own_cost_P_minus_A_mm','delta_E_P_minus_A_mm','delta_G_P_minus_A_mm','delta_own_gap_P_minus_A_mm')
    return {'planned_pairs':n,'common_success':len(common),'excluded_or_missing':n-len(common),
        'validity_transitions':dict(transitions),
        'transition_limit':'not_valid includes technical/input/unknown slots; it does not mean observed native infeasibility.',
        'deltas':{key:values([p[key] for p in common if p[key] is not None],n) for key in keys}}


def summarize(rows, fields):
    assert len(fields)==len(set(fields))==124 and len(rows)==496
    index={(r['instance_id'],r['proxy'],r['arm']):r for r in rows}
    assert len(index)==496 and set(index)=={(f,p,a)for f in fields for p in ('E','G') for a in ('A','P')}
    pairs={'E':[],'G':[]}
    for proxy in pairs:
        for field in fields:
            a,p=index[field,proxy,'A'],index[field,proxy,'P'];both=a['valid'] and p['valid']
            row={'instance_id':field,'proxy':proxy,'seed':0,'A_valid':a['valid'],'P_valid':p['valid'],
                 'A_record_verified':a['record_verified'],'P_record_verified':p['record_verified'],'common_success':both}
            for key,cost in [('delta_own_cost_P_minus_A_mm','normalized_own_cost'),('delta_E_P_minus_A_mm','base_E'),('delta_G_P_minus_A_mm','base_G'),('delta_own_gap_P_minus_A_mm','own_gap_mm')]:
                row[key]=p[cost]-a[cost] if both and p[cost] is not None and a[cost] is not None else None
            pairs[proxy].append(row)
    evalues=[r['delta_G_P_minus_A_mm'] for r in pairs['E'] if r['common_success']]
    cross={'definition':'G(P route from E search) - G(A route from E search), integer mm',
        'planned_E_pairs':124,'common_success':len(evalues),'excluded_or_missing':124-len(evalues),
        'positive':sum(v>0 for v in evalues),'zero':sum(v==0 for v in evalues),'negative':sum(v<0 for v in evalues),
        'summary':values(evalues,124),
        'interpretation':'Treatment-pair G realization; distinct from own E gap, exact proxy Delta, or signed offset from the E_G reference.'}
    return {'by_proxy':{proxy:{'arms':{arm:arm_group([index[f,proxy,arm] for f in fields]) for arm in ('A','P')},'pairs':pair_group(pairs[proxy])}for proxy in ('E','G')},
        'overall':{'arms':{arm:arm_group([r for r in rows if r['arm']==arm])for arm in ('A','P')},'mixed_proxy_costs_are_descriptive_only':True},
        'per_field':[{'instance_id':f,'slots':4,'valid_feasible':sum(index[f,p,a]['valid']for p in ('E','G')for a in ('A','P'))}for f in fields],
        'paired_rows':pairs,'secondary_cross_G_on_E_pairs':cross,
        'P_invariant_transfer':{p:observations([index[f,p,'P']for f in fields])for p in ('E','G')},
        'confirmed_model_and_solver_calls':sum(r['record_verified']for r in rows),
        'unconfirmed_possible_model_or_solver_calls':sum(r['process_spawned']is not False and not r['record_verified']for r in rows),
        'known_process_spawned':sum(r['process_spawned']is True for r in rows),
        'unknown_process_spawned':sum(r['process_spawned']is None for r in rows),
        'known_not_spawned':sum(r['process_spawned']is False for r in rows)}
