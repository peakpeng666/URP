"""Independent saved-byte primitives; no solver/model imports and no coordinate-derived costs."""
from pathlib import Path
from collections import Counter
import datetime,hashlib,json,math,sys,zipfile
ROOT=Path(__file__).resolve().parents[2]
def load(p): return json.loads(Path(p).read_text())
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def require(x,why):
    if not x: raise ValueError(why)
