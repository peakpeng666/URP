from original_primitives import *
from collections import Counter
import statistics

def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()

def save_exclusive(path,value):
    with Path(path).open('x')as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n')

def gate():
    r=load(ROOT/'provenance/RAW_UNREVIEWED_DRIVE_RECEIPT.json')
    require(r['owner_only']is True and r['shared']is False and r['remote_readback_sha256_verified']is True and r['download_byte_identical']is True,'RAW owner-only authenticated receipt')
    archive=ROOT.parent/(ROOT.name+'_RAW_UNREVIEWED.zip')
    require(sha(archive)==sha(r['download_path'])==r['sha256']==r['download_sha256'],'RAW actual downloaded bytes')
    require(sha(ROOT/'freeze/FROZEN_FILES.json')==r['frozen_files_sha256'],'RAW freeze identity')
    frozen=load(ROOT/'freeze/FROZEN_FILES.json');raw=load(ROOT/'raw/RAW_UNREVIEWED_MANIFEST.json')
    actual={str(p.relative_to(ROOT))for p in (ROOT/'raw').rglob('*')if p.is_file()and'__pycache__'not in p.parts}
    require(actual==set(raw['files'])|{'raw/RAW_UNREVIEWED_MANIFEST.json'},'exact immutable raw set')
    with zipfile.ZipFile(r['download_path'])as z:
        require(len(z.namelist())==len(set(z.namelist())),'no duplicate RAW archive members')
        for rel,m in (frozen['files']|raw['files']).items():
            p=ROOT/rel;require(p.stat().st_size==m['bytes']and sha(p)==m['sha256'],'frozen/raw local bytes '+rel)
            require(z.read(ROOT.name+'/'+rel)==p.read_bytes(),'actual RAW member '+rel)
        for rel in ('freeze/FROZEN_FILES.json','raw/RAW_UNREVIEWED_MANIFEST.json'):require(z.read(ROOT.name+'/'+rel)==(ROOT/rel).read_bytes(),'manifest member '+rel)
    # External old-workspace preservation was checked by the formal executor.
    # Saved evidence remains readable after restoration on another workspace.
    # Missing post-execution confirmation is reported separately, not fabricated.
    return r

def lines(path):
    if not Path(path).exists():return [],[]
    rows=[];errs=[]
    for n,s in enumerate(Path(path).read_text().splitlines(),1):
        try:
            x=json.loads(s);require(isinstance(x,dict),'object');rows.append(x)
        except Exception as e:errs.append(f'{Path(path).name} line {n}: {e}')
    return rows,errs

def check_ledger(schedule,events,items,parse_errors=()):
    expected={e['call_id']:e for e in schedule};byid={};errs=list(parse_errors);per={cid:[]for cid in expected}
    for item in items:
        cid=item.get('call_id')
        if cid not in expected:errs.append('UNEXPECTED_RESULT');continue
        if cid in byid:errs.append('DUPLICATE_RESULT')
        byid[cid]=item
    starts=[];finishes=[];active=None
    for e in events:
        cid=e.get('call_id');kind=e.get('event_kind')
        if cid not in expected:errs.append('UNEXPECTED_EVENT');continue
        if kind not in ('STARTED','FINISHED'):errs.append('INVALID_EVENT_KIND');continue
        if e.get('schedule')!=expected[cid]:per[cid].append('EVENT_SCHEDULE_MISMATCH')
        if set(e)!={'event_kind','utc','call_id','schedule'}|({'result'}if kind=='FINISHED'else set()):per[cid].append('EVENT_SCHEMA_MISMATCH')
        if kind=='STARTED':
            if active is not None:errs.append('OVERLAPPED_OR_UNFINISHED_CALL')
            active=cid;starts.append(cid)
        else:
            if active!=cid:errs.append('FINISH_WITHOUT_MATCHED_ACTIVE_START')
            active=None;finishes.append(cid)
            if e.get('result')!=byid.get(cid):per[cid].append('FINISHED_RESULT_MISMATCH')
    if starts!=[e['call_id']for e in schedule][:len(starts)]:errs.append('START_ORDER_MISMATCH')
    if len(starts)!=len(set(starts))or len(finishes)!=len(set(finishes)):errs.append('DUPLICATE_ATTEMPT')
    for cid in expected:
        kinds=[e.get('event_kind')for e in events if e.get('call_id')==cid]
        if kinds!=['STARTED','FINISHED']:per[cid].append('MISSING_OR_INVALID_START_FINISH_SEQUENCE')
        if cid not in byid:per[cid].append('MISSING_RESULT')
        elif byid[cid].get('schedule')!=expected[cid]:per[cid].append('RESULT_SCHEDULE_MISMATCH')
    return {'status':'PASS'if not errs and not any(per.values())else'INCOMPLETE_OR_INVALID','errors':errs,'planned_denominator':len(schedule),'observed_records':len(items),'observed_events':len(events),'started':len(starts),'finished':len(finishes),'calls':[{'call_id':cid,'errors':errors,'ledger_valid':not errs and not errors}for cid,errors in per.items()]},byid

def blank(status='INVALID_OUTPUT'):
    return {'status':status,'valid_record':False,'valid_feasible':False,'cost':None,'vehicles':None,'errors':[]}

def metric(vals,n,conditional):
    valid=[v for v in vals if v is not None];complete=len(valid)==n;ok=bool(valid)and(conditional or complete)
    return {'mean':statistics.mean(valid)if ok else None,'median':statistics.median(valid)if ok else None,'n':len(valid),'planned_denominator':n,'complete':complete,'conditional':conditional}

def equal(a,b,label):
    if isinstance(a,float):require(type(b)in(int,float)and math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-12),label)
    elif isinstance(a,dict):
        require(isinstance(b,dict),label)
        for k,v in a.items():require(k in b,label+'.'+k);equal(v,b[k],label+'.'+k)
    elif isinstance(a,list):
        require(isinstance(b,list)and len(a)==len(b),label)
        for i,(x,y)in enumerate(zip(a,b)):equal(x,y,f'{label}[{i}]')
    else:require(a==b,label)
