# ee130 路由规模与质量实验交接

先读 reports/REPORT_zh.md。它包括结果、限制、失败与技术修订、计算成本和复现口径。

- reports/summary.json：完整结构化汇总和全部12实例的记录
- reports/results.csv：每例长度、oracle gap、相对改善、CPU/wall、节点边数、候选数、失败计数
- reports/scale_quality.png：规模、质量、候选数和单次计时
- reports/all_n40_routes.png：三个40任务种子的全部NN与2-opt映射路径
- technical_r1/input：完整first-valid采样记录和冻结实例
- technical_r1/raw：visibility图、距离矩阵、各服务腿路径、完整解和小实例oracle输出
- technical_r1/freeze：实际运行技术版协议与执行前SHA256冻结
- technical_r1/evidence：实际运行各子进程日志和资源测量
- evidence/SAVED_ARTIFACT_AUDIT.json：保存结果复核30解、689线段
- 顶层source/input/freeze/evidence：保留初版资源继承启动失败以及未经改写的旧冻结

科学执行12/12 PASS；总启动2次（初版preexec失败且没有目标评估，技术版一次完成）。本目录没有做任何模型调用或上传。初版错误以及未先做资源继承dummy测试的流程缺口详见报告，不隐藏失败。

本实验仅比较固定合法距离矩阵上的最近邻与预算2-opt。它不能替换旧9任务4布局的几何重排结论，也不代表农业机器人可直接部署。

复现应复制到全新目录，保留当前证据；运行前先在无求解子进程验证资源限制。technical_r1/source/run_panel.py采用独立子进程与硬限，source/prepare.py用于重建相同输入规则。所有冻结输入与代码有SHA256，当前路径已有输出时脚本会拒绝覆盖。
