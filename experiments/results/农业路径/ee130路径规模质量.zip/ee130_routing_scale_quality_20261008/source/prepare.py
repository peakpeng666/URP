import random,math
from common import *
from osgeo import ogr,gdal
protocol={
 'study':'ee130_scale_quality_single_vehicle_point_robot_v1','created_utc':utc(),
 'geometry_sha256':'9c63c15979ce1915673e072621e4c88b70d3e17f97b353cb3e88d8ddf1b1e86a','geometry_crs':'EPSG:4326 to EPSG:32634, unchanged prior validated WKT; 3 holes retained',
 'sizes':[8,12,20,40],'seeds':[202610081001,202610081002,202610081003],
 'sampling':'For each fixed seed, random.Random(seed), draw integer easting then northing uniformly within ceil/floor field bounding box; retain first unique strictly interior points, first=depot, next40=tasks. Sizes use prefix of same 41 accepted points. Check rational strict containment against GDAL Contains. Save every draw. No objective evaluation before freeze, no quality screening, no new layouts after results.',
 'scenario':'One zero-footprint point robot, one depot-closed route, every synthetic task served once, unlimited capacity; no demands, service time, turn radius, vehicle interactions or coverage tasks. Boundary contact is allowed; all exterior and hole interiors excluded.',
 'distance':'Fresh GDAL/GEOS boundary-vertex visibility graph once; add current-instance service vertices and all edges involving them. Reuse boundary edge cache across instances, within each instance reuse the same full legal shortest-path matrix for all solvers. Dijkstra, symmetric paths chosen by lower service ID source; record and audit asymmetry. No geometry repair/buffer/snap/simplify.',
 'baselines':{'nearest_neighbor':'Start depot0; repeatedly choose minimum (legal distance, task ID); return depot.','nn_2opt_budget':'Same NN initialization timed independently; first-improvement symmetric 2-opt with at most10000 candidate reversals per instance. Lexicographic i,j (1<=i<j<=n), skip full-route reversal. Accept delta<-1e-9 m only if math.fsum full route cost strictly decreases; restart scan after accepted move. Stop full unsuccessful sweep or budget exhaustion. Includes NN init; excludes validation and precompute.'},
 'oracle':'Unchanged previous matrix_oracle.solve for n8 and n12, dummy demand1 and Q=n, report by_k[1]. Original solver internally computes all at-most-k partitions; measured time includes that overhead. Finite GEOS graph binary64 combinatorial optimum, not certified continuous optimum. Independently brute-force all permutations modulo reversal for n8; n12 has no second independent optimization oracle.',
 'audit':'Each solution service order exactly once, depot closure, recorded mapped polyline length matches matrix cost; every unique used segment checked by independent exact-decimal rational predicate against original outer+3hole rings and GEOS. Independent Floyd-Warshall on same frozen graph crosschecks full service matrix. Audit-only shared rational cache permitted; count hits/misses and time per instance.',
 'outcomes':'Per-size/seed raw routes, full mapped polylines, length metres, NN->2opt relative improvement; n8/12 gaps to oracle only. For n20/40 oracle null, do not call improvements optimality gaps. Precompute, solver, audit wall/CPU separately; graph nodes/edges, NN candidates,2opt candidates/moves, oracle states/transitions, maxRSS/failures. Three paired seeds, descriptive only; no significance/population/monotonicity claims.',
 'budgets':{'total_cpu_seconds':600,'total_wall_seconds':1200,'memory_bytes':1073741824,'instance_cpu_seconds':40,'instance_wall_seconds':75,'shared_preprocess_cpu_seconds':30,'shared_preprocess_wall_seconds':60,'supervisor_cpu_seconds':20,'scheduling':'12 serial instances; hard OS CPU/address-space limits and subprocess timeouts; before launch also enforce aggregate remaining budget; failed instance retained without rerun, continue other prespecified instances if resources remain.'},
 'numeric_validation_tolerance_m':1e-8,'timing_repeats':1,'timing_caveat':'Single-run microsecond solver times are descriptive and scheduler-sensitive; no stable speedup claim. Shared-base graph freshly rebuilt once for this run, not historical timing.',
 'external_actions':{'network':False,'installs':False,'model_api':False,'uploads':False},'formal_attempts':1,'stopping':'Single frozen pass, no retries or reselection; saved-result audit/report allowed without rerunning optimizer.'}
assert sha(R/'input/projected_epsg32634.wkt')==protocol['geometry_sha256']
save('freeze/PROTOCOL.json',protocol)
save('freeze/PRE_GENERATION_FREEZE.json',{'utc':utc(),'objective_evaluations':0,'hashes':{str(p.relative_to(R)):sha(p) for d in ['source','input'] for p in sorted((R/d).glob('*')) if p.is_file()}|{'freeze/PROTOCOL.json':sha(R/'freeze/PROTOCOL.json')}})
t=clock(); field,rings,S=geometry(); xs,ys=zip(*rings[0]); bounds=[math.ceil(min(xs)/S),math.floor(max(xs)/S),math.ceil(min(ys)/S),math.floor(max(ys)/S)]; panel=[]
for seed in protocol['seeds']:
 rng=random.Random(seed); points=[]; draws=[]
 while len(points)<41:
  p=[rng.randint(bounds[0],bounds[1]),rng.randint(bounds[2],bounds[3])]; ok=p not in points and point_strict(tuple(v*S for v in p),rings)
  q=ogr.Geometry(ogr.wkbPoint); q.AddPoint_2D(*p); assert ok==(p not in points and field.Contains(q))
  draws.append({'point':p,'accepted':ok})
  if ok: points.append(p)
 save(f'input/seed_{seed}.json',{'seed':seed,'coordinates':points,'draws':draws,'integer_bounds':bounds,'accepted':41,'objective_evaluations':0})
 for n in protocol['sizes']:
  id=f'n{n:02d}_s{seed}'; save(f'input/{id}.json',{'instance_id':id,'n':n,'seed':seed,'coordinates':points[:n+1]}); panel.append(id)
save('input/PANEL.json',panel)
save('evidence/GENERATION.json',{'utc':utc(),'sampling_resources':elapsed(t),'objective_evaluations':0,'distance_matrix_evaluations':0,'instances':12,'all_first_valid':'PASS','GDAL':gdal.VersionInfo()})
save('freeze/PRE_RUN_FREEZE.json',{'utc':utc(),'objective_evaluations':0,'hashes':{str(p.relative_to(R)):sha(p) for d in ['source','input','freeze'] for p in sorted((R/d).glob('*')) if p.is_file()}})
print('FROZEN',sha(R/'freeze/PRE_RUN_FREEZE.json'),flush=True)
