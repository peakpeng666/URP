"""Read-only post-run saved-artifact checks. No task sampling or optimizer execution."""
import json,hashlib,math,time,resource,itertools
from pathlib import Path
from osgeo import ogr
R=Path(__file__).resolve().parents[1]; T=R/'technical_r1'; t=time.perf_counter();c=time.process_time()
resource.setrlimit(resource.RLIMIT_CPU,(30,30));resource.setrlimit(resource.RLIMIT_AS,(1073741824,1073741824))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
checks=[]
for d in [R,T]:
 f=json.loads((d/'freeze/PRE_RUN_FREEZE.json').read_text())
 for p,h in f['hashes'].items():assert sha(d/p)==h,(d,p)
 checks.append({'scope':str(d.relative_to(R)),'frozen_hashes_unchanged':len(f['hashes'])})
assert all(sha(p)==sha(T/'input'/p.name) for p in (R/'input').glob('*') if p.is_file())
field=ogr.CreateGeometryFromWkt((T/'input/projected_epsg32634.wkt').read_text()); solution_count=0;segment_count=0; leg_count=0;max_delta=0.;rows=[]
for id in json.loads((T/'input/PANEL.json').read_text()):
 a=json.loads((T/f'raw/{id}_result.json').read_text());g=json.loads((T/f'raw/{id}_geometry.json').read_text());D=g['legal_distance_matrix'];nodes=g['nodes'];n=a['n'];assert a['status']=='PASS'
 for label,m in a['methods'].items():
  solution_count+=1;route=m['route'];assert len(route)==n+2 and route[0]==route[-1]==0 and sorted(route[1:-1])==list(range(1,n+1))
  poly=[]
  for u,v in zip(route,route[1:]):
   leg_count+=1;p=g['legal_leg_node_paths'][u][v];poly.extend(p if not poly else p[1:])
  assert poly==m['mapped_polyline_node_ids']
  coords=[nodes[i] for i in poly];assert coords==m['mapped_polyline_coordinates'];assert coords[0]==coords[-1]==g['coordinates'][0]
  for u,v in zip(coords,coords[1:]):
   segment_count+=1;line=ogr.Geometry(ogr.wkbLineString);line.AddPoint_2D(*u);line.AddPoint_2D(*v)
   assert line.Difference(field).IsEmpty()
  val=math.fsum(math.dist(u,v) for u,v in zip(coords,coords[1:]));val2=math.fsum(D[u][v] for u,v in zip(route,route[1:]));delta=max(abs(val-m['length_m']),abs(val-val2));max_delta=max(delta,max_delta);assert delta<1e-8
  assert m['solve_resources']['cpu_seconds']>=0 and m['solve_resources']['wall_seconds']>=0
  if label!='oracle':
   gap=m['gap_to_finite_graph_oracle_pct'];assert (gap is None)==(n>12)
   if gap is not None:assert abs(gap-100*(m['length_m']/a['methods']['oracle']['length_m']-1))<1e-10
 nn=a['methods']['nearest_neighbor'];opt=a['methods']['nn_2opt_budget'];route=list(nn['route'])
 for move in opt['operations']['moves']:
  i,j=move['i'],move['j'];before=math.fsum(D[u][v] for u,v in zip(route,route[1:]));assert abs(before-move['before_m'])<1e-8
  route=route[:i]+route[i:j+1][::-1]+route[j+1:];after=math.fsum(D[u][v] for u,v in zip(route,route[1:]));assert abs(after-move['after_m'])<1e-8 and after<before
 assert route==opt['route'] and opt['operations']['candidate_reversals']<=10000
 improvement=100*(nn['length_m']-opt['length_m'])/nn['length_m'];assert abs(improvement-a['relative_improvement_nn_to_2opt_pct'])<1e-10
 # Audit final 2-opt neighborhood only; do not apply any move or change outputs.
 deltas=[]
 for i in range(1,n):
  for j in range(i+1,n+1):
   if i==1 and j==n:continue
   u,v=route[i-1],route[i];x,y=route[j],route[j+1];deltas.append(math.fsum([D[u][x],D[v][y],-D[u][v],-D[x][y]]))
 assert min(deltas)>=-1e-9 if opt['operations']['termination']=='NO_IMPROVING_FULL_SWEEP' else True
 rows.append({'instance_id':id,'route_replay':'PASS','twoopt_min_final_delta_m':min(deltas),'termination':opt['operations']['termination']})
result={'status':'PASS','frozen_input_and_source_checks':checks,'unchanged_scientific_inputs_across_technical_revision':True,'solutions_checked':solution_count,'service_legs_checked':leg_count,'mapped_segments_checked':segment_count,'maximum_length_error_m':max_delta,'checks':rows,'wall_seconds':time.perf_counter()-t,'cpu_seconds':time.process_time()-c,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'optimization_runs':0,'sampling_runs':0,'scope':'Saved artifacts independently parsed, GEOS path coverage rechecked, all accepted 2-opt moves replayed, final neighborhood audited; no optimizer rerun and no independent n12 global proof.'}
with (R/'evidence/SAVED_ARTIFACT_AUDIT.json').open('x') as f:json.dump(result,f,ensure_ascii=False,indent=2)
print(json.dumps(result,ensure_ascii=False))
