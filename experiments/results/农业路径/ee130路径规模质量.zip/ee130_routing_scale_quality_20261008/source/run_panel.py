import os,resource,subprocess,sys,math
from common import *
def childcpu():
 r=resource.getrusage(resource.RUSAGE_CHILDREN); return r.ru_utime+r.ru_stime

def main():
 resource.setrlimit(resource.RLIMIT_CPU,(20,20)); resource.setrlimit(resource.RLIMIT_AS,(1073741824,1073741824))
 start=clock(); c0=childcpu(); frozen=json.loads((R/'freeze/PRE_RUN_FREEZE.json').read_text())
 for p,h in frozen['hashes'].items(): assert sha(R/p)==h,p
 save('evidence/STARTED.json',{'utc':utc(),'formal_attempt':1,'freeze_sha256':sha(R/'freeze/PRE_RUN_FREEZE.json'),'pid':os.getpid()})
 generation=json.loads((R/'evidence/GENERATION.json').read_text())['sampling_resources']; results=[]
 ids=['base']+json.loads((R/'input/PANEL.json').read_text())
 for id in ids:
  used_cpu=time.process_time()-start[1]+childcpu()-c0+generation['cpu_seconds']; used_wall=time.perf_counter()-start[0]+generation['wall_seconds']
  cpu=min(30 if id=='base' else 40,math.floor(600-used_cpu-20)); wall=min(60 if id=='base' else 75,1200-used_wall-20)
  if cpu<1 or wall<1:
   results.append({'instance_id':id,'status':'SKIPPED_BUDGET'}); continue
  def limits():
   resource.setrlimit(resource.RLIMIT_CPU,(cpu,cpu)); resource.setrlimit(resource.RLIMIT_AS,(1073741824,1073741824)); os.environ['PYTHONDONTWRITEBYTECODE']='1'
  t=clock(); c=childcpu()
  with (R/f'evidence/{id}_STDOUT.log').open('x') as out,(R/f'evidence/{id}_STDERR.log').open('x') as err:
   try: code=subprocess.run(['/usr/bin/python3','-B',str(R/'source/run_instance.py'),id],stdout=out,stderr=err,timeout=wall,preexec_fn=limits).returncode
   except subprocess.TimeoutExpired: code='WALL_TIMEOUT'
  status={'instance_id':id,'exit_code':code,'status':'PASS' if code==0 else 'FAIL','cpu_hard_limit_seconds':cpu,'wall_hard_limit_seconds':wall,'process_wall_seconds':time.perf_counter()-t[0],'process_cpu_seconds_including_imports':childcpu()-c}; results.append(status); save(f'evidence/{id}_PROCESS_STATUS.json',status); print(json.dumps(status),flush=True)
  if id=='base' and code!=0: break
 save('evidence/RUN_STATUS.json',{'utc':utc(),'status':'PASS' if len(results)==13 and all(x['status']=='PASS' for x in results) else 'INCOMPLETE_OR_FAILED','formal_attempts':1,'processes':results,'children_cpu_seconds':childcpu()-c0,'supervisor_resources':elapsed(start),'generation_resources':generation,'cpu_seconds_including_generation_supervisor_children':time.process_time()-start[1]+childcpu()-c0+generation['cpu_seconds'],'wall_seconds_including_generation':time.perf_counter()-start[0]+generation['wall_seconds'],'supervisor_maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'child_maxrss_kib':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'hard_memory_bytes':1073741824,'new_installs':0,'network_calls':0,'model_calls':0,'uploads':0})
if __name__=='__main__': main()
