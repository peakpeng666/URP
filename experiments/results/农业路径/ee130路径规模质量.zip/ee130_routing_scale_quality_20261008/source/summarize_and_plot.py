"""Summarize frozen saved outputs only. Does not sample points or run any solver."""
import json,csv,statistics,hashlib,datetime,resource,time,os,sys
from pathlib import Path
R=Path(__file__).resolve().parents[1];T=R/'technical_r1';start=time.perf_counter();cpu=time.process_time()
resource.setrlimit(resource.RLIMIT_CPU,(30,30));resource.setrlimit(resource.RLIMIT_AS,(1073741824,1073741824))
rows=[];results=[]
for p in sorted((T/'raw').glob('*_result.json')):
 x=json.loads(p.read_text());results.append(x);n=x['n'];nn=x['methods']['nearest_neighbor'];two=x['methods']['nn_2opt_budget'];o=x['methods'].get('oracle')
 rows.append({'instance_id':x['instance_id'],'n':n,'seed':x['seed'],'NN_length_m':nn['length_m'],'twoopt_length_m':two['length_m'],'oracle_length_m':None if o is None else o['length_m'],'NN_gap_pct':nn['gap_to_finite_graph_oracle_pct'],'twoopt_gap_pct':two['gap_to_finite_graph_oracle_pct'],'NN_to_twoopt_improvement_pct':x['relative_improvement_nn_to_2opt_pct'],'preprocess_wall_s':x['preprocessing']['wall_seconds'],'preprocess_cpu_s':x['preprocessing']['cpu_seconds'],'NN_wall_s':nn['solve_resources']['wall_seconds'],'NN_cpu_s':nn['solve_resources']['cpu_seconds'],'twoopt_wall_s':two['solve_resources']['wall_seconds'],'twoopt_cpu_s':two['solve_resources']['cpu_seconds'],'oracle_wall_s':None if o is None else o['solve_resources']['wall_seconds'],'oracle_cpu_s':None if o is None else o['solve_resources']['cpu_seconds'],'graph_nodes':x['graph_nodes'],'graph_edges':x['graph_edges'],'NN_distance_candidates':nn['operations']['distance_candidates'],'twoopt_candidates':two['operations']['candidate_reversals'],'twoopt_moves':two['operations']['accepted_moves'],'twoopt_termination':two['operations']['termination'],'mapped_path_violations':sum(len(m['audit']['mapped_path_violations']) for m in x['methods'].values()),'instance_wall_s':x['instance_internal_resources']['wall_seconds'],'instance_cpu_s':x['instance_internal_resources']['cpu_seconds'],'peak_rss_kib':x['peak_rss_kib']})
with (R/'reports/results.csv').open('x') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
summary=[]
for n in [8,12,20,40]:
 rs=[r for r in rows if r['n']==n];a={'n':n,'instances':len(rs)}
 for name in ['NN_to_twoopt_improvement_pct','NN_gap_pct','twoopt_gap_pct','preprocess_wall_s','preprocess_cpu_s','NN_wall_s','NN_cpu_s','twoopt_wall_s','twoopt_cpu_s','oracle_wall_s','oracle_cpu_s','twoopt_candidates','twoopt_moves','graph_nodes','graph_edges']:
  v=[r[name] for r in rs if r[name] is not None];a[name]=None if not v else {'mean':statistics.mean(v),'median':statistics.median(v),'min':min(v),'max':max(v)}
 summary.append(a)
run=json.loads((T/'evidence/RUN_STATUS.json').read_text());audit=json.loads((R/'evidence/SAVED_ARTIFACT_AUDIT.json').read_text());base=json.loads((T/'raw/boundary_graph.json').read_text());protocol=json.loads((T/'freeze/PROTOCOL.json').read_text())
value={'status':'PASS_WITH_RECORDED_LAUNCH_FAILURE_AND_PROCESS_DEVIATION','scientific_instance_status':'12/12 PASS','updated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'summary_by_n':summary,'rows':rows,'shared_boundary_graph_resources':base['resources'],'run_resources':run,'saved_result_audit':audit,'protocol':protocol,'workflow_disclosures':['Initial launch failed in preexec before any distance or solver evaluation; preserved.','Technical r1 modifies only supervisor hard CPU ceiling20 to600, soft limit20 unchanged; scientific inputs identical.','Root asked for dummy limit test after technical run had already started; no prelaunch dummy test existed, recorded as process deviation.','Run-level formal_attempts1 denotes technical scientific execution only; overall launch count2 including initial failure.'],'claim_boundary':'Descriptive 3-seed nested synthetic panel on one real polygon; n20/40 no oracle, no operational savings, no continuous geometry certification, no general asymptotic or population claims.'}
with (R/'reports/summary.json').open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2)
# Plot saved outcomes and operation/time scaling; points show all three seeds.
os.environ['MPLCONFIGDIR']=str(R/'evidence/mplconfig');import matplotlib;matplotlib.use('Agg');import matplotlib.pyplot as plt
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'white','axes.grid':True,'grid.alpha':.15})
fig,axs=plt.subplots(2,2,figsize=(11,8),constrained_layout=True);colors=['#176B87','#BC4749','#6A4C93'];seeds=[202610081001,202610081002,202610081003]
for si,seed in enumerate(seeds):
 rs=[r for r in rows if r['seed']==seed];ns=[r['n'] for r in rs]
 axs[0,0].plot(ns,[r['NN_to_twoopt_improvement_pct'] for r in rs],'-o',color=colors[si],label=f'Seed {si+1}')
 axs[1,0].plot(ns,[r['twoopt_candidates'] for r in rs],'-o',color=colors[si],label=f'Seed {si+1}')
axs[0,0].set(title='2-opt reduction from nearest neighbor',xlabel='Tasks',ylabel='Length reduction (%)');axs[0,0].legend()
for label,color in [('NN','#BC4749'),('twoopt','#176B87')]:
 for si,seed in enumerate(seeds):
  rs=[r for r in rows if r['seed']==seed and r['n']<=12]
  axs[0,1].plot([r['n']+(si-1)*.13 for r in rs],[r[label+'_gap_pct'] for r in rs],':o',color=color,alpha=.75,label=label if si==0 else None)
axs[0,1].set(title='Small cases: gap to finite-graph oracle',xlabel='Tasks',ylabel='Gap (%)',xticks=[8,12]);axs[0,1].legend()
axs[1,0].axhline(10000,color='#555',ls='--',label='Fixed 10,000 cap');axs[1,0].set(title='2-opt work before local stop',xlabel='Tasks',ylabel='Candidate reversals');axs[1,0].legend(fontsize=8)
for key,label,color in [('preprocess_wall_s','Per-instance geometry','#6A4C93'),('NN_wall_s','Nearest neighbor','#BC4749'),('twoopt_wall_s','NN + 2-opt','#176B87')]:
 axs[1,1].plot([s['n'] for s in summary],[s[key]['median']*1000 for s in summary],'-o',color=color,label=label)
axs[1,1].set(title='Single-run median wall times',xlabel='Tasks',ylabel='Milliseconds, log scale',yscale='log');axs[1,1].legend(fontsize=8)
fig.suptitle('ee130 scale-quality panel | 3 fixed seeds | 1 closed point-robot tour',fontsize=14)
fig.savefig(R/'reports/scale_quality.png',dpi=170);plt.close(fig)
# All n40 seeds, both algorithms; no result-based selection.
sys.path.insert(0,str(T/'source'));from common import geometry
field,rings,S=geometry();x0=min(x/S for x,y in rings[0]);y0=min(y/S for x,y in rings[0]);fig,axs=plt.subplots(2,3,figsize=(12,8),constrained_layout=True)
for j,seed in enumerate(seeds):
 x=next(x for x in results if x['seed']==seed and x['n']==40)
 for i,label in enumerate(['nearest_neighbor','nn_2opt_budget']):
  ax=axs[i,j]
  for ri,ring in enumerate(rings):
   px=[p[0]/S-x0 for p in ring];py=[p[1]/S-y0 for p in ring];ax.fill(px,py,color='#EDF1E7' if ri==0 else 'white',edgecolor='#444444',linewidth=.7)
  m=x['methods'][label];poly=m['mapped_polyline_coordinates'];ax.plot([p[0]-x0 for p in poly],[p[1]-y0 for p in poly],color='#BC4749' if i==0 else '#176B87',lw=1.1)
  ins=json.loads((T/f'input/{x["instance_id"]}.json').read_text());points=ins['coordinates'];ax.scatter([p[0]-x0 for p in points[1:]],[p[1]-y0 for p in points[1:]],s=8,color='#222',zorder=4);ax.scatter([points[0][0]-x0],[points[0][1]-y0],s=65,marker='*',color='#D99A00',edgecolor='black',lw=.4,zorder=5)
  ax.set_aspect('equal');ax.set_title(f'Seed {j+1}: '+('NN' if i==0 else 'NN + 2-opt')+f'  {m["length_m"]:.1f} m');ax.set_xlabel('Local easting (m)');ax.set_ylabel('Local northing (m)')
fig.suptitle('All three n=40 cases | unchanged field and three holes | star = depot',fontsize=14)
fig.savefig(R/'reports/all_n40_routes.png',dpi=170);plt.close(fig)
# Plain editable technical report accompanies machine-readable artifacts.
lines=['# ee130 单车任务数与路由质量实验报告','', '## 结论','', '固定真实地块、3 个预先指定种子、8／12／20／40 任务的 12 个实例全部完成。最近邻初始化后的固定预算 2-opt 在 12 例都缩短了合法闭合路径，降幅为 0.712% 至 20.588%。这说明该固定任务面板上存在最近邻局部改进空间，不是障碍重排收益、农业实机收益或跨地块普遍有效性的证据。','', '8 任务平均有限图 oracle gap 由 10.597% 降至 0.238%；12 任务由 12.227% 降至 1.561%。2-opt 仅在 6 个小实例中的 2 个达到 oracle 成本。20／40 任务不运行精确 oracle，所有改善均以最近邻为参照。', '', '12 个 2-opt 都在 10,000 次候选上限前找到无改进的完整扫描，最大使用 9,329 次；本轮没有预算耗尽实例。因此本实验不能回答加大该预算还有多少收益。','', '## 范围与冻结','', '几何沿用 Fields2Cover ee_field_130：作者明确 EPSG:4326，经原已验证流程投影至 EPSG:32634。投影 WKT 保留外环与 3 个 hole，不修复、不缓冲、不简化。任务位置和 depot 均为人工生成，点机器人允许接触边界，不进入地块外部或 hole 内部。单车闭合 TSP，不含容量、服务时间、转弯半径、机器人尺寸及作业覆盖。','', '固定种子为 202610081001、202610081002、202610081003。每种子随机整数坐标按 first-valid 接受，第一个为 depot、后40个为任务；8／12／20／40 使用同一序列的前缀，3个种子之间独立。这种嵌套设计带来配对关系，不能把12例当作12个独立抽样地块。所有拒绝采样记录保留，未按路线质量筛选。','', '原冻结 SHA256：51bf0dd13663f43a534773756d6f6a9d88d8393564eac8f6b0acf97a7781d53e。技术修订冻结 SHA256：9b20d63d3378d7660c0a93a64078abbc193af4bf42f1c038e6eba6a48d19e344。两版各26个冻结文件核验均通过，科学输入逐字节一致。','', '## 算法与成本口径','', '最近邻从 depot 出发，按合法最短路距离、任务编号依次择最小。2-opt 包含重新运行最近邻的初始化；按 i、j 字典序首次改进，候选反转上限10,000，delta 小于−1e−9米且完整路径和严格下降才接受，每次接受后重新扫描。','', '外环与hole顶点的GDAL/GEOS visibility图在本次运行重新建立一次，成本单列。每实例追加当前服务节点及相关边，Dijkstra求距离与路径；该矩阵在同实例各算法之间复用。每实例预处理不含共享边界图成本，不含合法性审计。小实例使用原始通用CVRP Held–Karp／分区oracle的单车结果，计时包含其内部为其他车数计算分区的额外开销，不能当作专门优化的TSP实现比较。n=8另用20,160个去反向对称排列检查最优成本。','', '## 逐规模结果','', '| 任务数 | 平均改善 % | 改善范围 % | NN平均gap % | 2-opt平均gap % | 2-opt候选范围 |', '|---:|---:|---:|---:|---:|---:|']
for a in summary:
 v=a['NN_to_twoopt_improvement_pct'];ng='未计算' if a['NN_gap_pct'] is None else f'{a["NN_gap_pct"]["mean"]:.3f}';tg='未计算' if a['twoopt_gap_pct'] is None else f'{a["twoopt_gap_pct"]["mean"]:.3f}';co=a['twoopt_candidates'];lines.append(f'| {a["n"]} | {v["mean"]:.3f} | {v["min"]:.3f}–{v["max"]:.3f} | {ng} | {tg} | {co["min"]}–{co["max"]} |')
lines+=['','gap = (算法成本／oracle成本−1)×100%；改善 = (NN成本−2-opt成本)／NN成本×100%。均值为3种子的等权算术均值。有限图、binary64算术的组合oracle不等于连续几何精确证明。','','## 分阶段计算成本','','| 任务数 | 图节点数 | 预处理中位 wall ms | NN中位 wall ms | 2-opt中位 wall ms | oracle中位 wall ms |','|---:|---:|---:|---:|---:|---:|']
for a in summary:
 o='未运行' if a['oracle_wall_s'] is None else f'{a["oracle_wall_s"]["median"]*1000:.3f}';lines.append(f'| {a["n"]} | {a["graph_nodes"]["median"]} | {a["preprocess_wall_s"]["median"]*1000:.3f} | {a["NN_wall_s"]["median"]*1000:.3f} | {a["twoopt_wall_s"]["median"]*1000:.3f} | {o} |')
lines +=['',f'共享边界图：{base["graph_nodes"]} 节点、{base["graph_edges"]} 无向边；构图 wall {base["resources"]["wall_seconds"]:.3f}秒、CPU {base["resources"]["cpu_seconds"]:.3f}秒。技术版科学执行（含采样、监督和子进程启动）wall {run["wall_seconds_including_generation"]:.3f}秒、CPU {run["cpu_seconds_including_generation_supervisor_children"]:.3f}秒，子进程峰值RSS {run["child_maxrss_kib"]/1024:.2f}MiB；单实例硬限40 CPU秒／75 wall秒，地址空间硬限1GiB。共享预处理硬限30 CPU秒／60 wall秒。初版启动失败的开销未精确纳入该实测总量，单独保留日志；没有达到600 CPU秒／1200 wall秒总预算。','', '上述是一次运行的描述性计时，算法仅需几十微秒至几毫秒，调度和测量噪声足以改变很小的差异，不能据此声称稳定倍速。完整CPU、wall、节点边数、候选数、操作记录在 results.csv 与原始JSON。几何处理明显高于这两个简单启发式的求解开销，真实端到端部署不能忽略它；共享缓存收益也必须单列。','', '## 合法性与保存结果复核','', '每例每算法检查任务恰好一次、depot闭合、完整mapped polyline逐段合法。运行时用独立有理数分段谓词核对原十进制几何，无几何epsilon；GEOS也检查覆盖。独立Floyd–Warshall在同图上核对Dijkstra矩阵。长度数值比较阈值为1e−8米，不用于几何放宽。','',f'保存后另解析并复核30个解、570个服务腿、689个映射线段，零路径违规；长度最大差 {audit["maximum_length_error_m"]:.3g}米。全部2-opt接受移动可从NN路径重放，最终局部邻域检查通过。n=12没有第二套全局优化证明；Floyd审计只针对同一个有限图。','', '## 失败与流程偏差','', '首次启动在preexec阶段失败，尚未执行任何距离或目标计算。原因是监督进程CPU软硬限均20秒，子进程无法把继承的硬限提高至30／40秒。原文件、原冻结、原失败日志全部保留。技术r1仅把监督硬限改为600秒，软限20秒及所有单实例限额、输入、算法保持不变；没有重新采样。','', '修订版已启动后才收到先做极小资源继承子进程测试的要求，故未满足该前置测试顺序；没有补造前置证据，也没有因此重复科学运行。r1 RUN_STATUS中的formal_attempts=1指该修订版的科学执行，总启动次数为2（含原失败）。应复用已经验证的软硬限分离实现，后续在无求解测试通过后再开正式运行。','', '## 解释边界与可复现材料','', '本轮改进来自NN与NN后2-opt的比较；旧9任务、4布局中的Euclidean最优映射与合法距离重排零收益结论不受影响。算法对比、样本和问题都不同。这里没有选布局找阳性，没有跨地块推断，没有证明误差随任务数单调增长，也没有声称n20／40近似最优。','', '三个40任务种子的两算法完整路径全部展示于 all_n40_routes.png；规模与质量图为 scale_quality.png。输入、协议、种子抽样记录、矩阵、各腿路径、映射折线、oracle原结果、失败与成功日志、保存结果审计全部随目录保留。技术版运行代码位于 technical_r1/source；冻结检查通过后方可在另一个新目录复现，避免覆盖本次证据。未联网、未安装依赖、未调用模型API、未上传。','', '数据来源：Fields2Cover 固定提交 93c0989ab2fc4a3f3d0a18bbd224d0e267a03fcc 的 data/ee_field_130.wkt；上游地址及代码证据SHA256见 input/crs_provenance.json。源地址：https://github.com/Fields2Cover/Fields2Cover/blob/93c0989ab2fc4a3f3d0a18bbd224d0e267a03fcc/data/ee_field_130.wkt','']
(R/'reports/REPORT_zh.md').write_text('\n'.join(lines))
with (R/'evidence/REPORTING_RESOURCE.json').open('x') as f:json.dump({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cpu_seconds':time.process_time()-cpu,'wall_seconds':time.perf_counter()-start,'optimization_runs':0,'sampling_runs':0,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},f,indent=2)
print(json.dumps(summary,ensure_ascii=False,indent=2))
