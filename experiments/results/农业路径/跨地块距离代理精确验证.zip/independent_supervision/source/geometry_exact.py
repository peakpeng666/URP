"""Independent exact decimal-grid geometry. No GDAL, author code, or planner imports.
Uses ray parity, exact segment cuts, dot/cross distances and shoelace area.
"""
from decimal import Decimal
from fractions import Fraction as F
from math import isqrt

def chunks(text):
    depth=0;start=0;result=[]
    for i,c in enumerate(text):
        depth+=(c=='(')-(c==')')
        assert depth>=0
        if c==',' and depth==0:result.append(text[start:i].strip());start=i+1
    assert depth==0
    result.append(text[start:].strip())
    return result

def unwrap(s):
    s=s.strip();assert s.startswith('(') and s.endswith(')');return s[1:-1]

def parse_wkt(text):
    kind,body=text.strip().split('(',1);body='('+body
    def polygon(t):
        rings=[]
        for r in chunks(unwrap(t)):
            pts=[tuple(p.split()) for p in chunks(unwrap(r))]
            assert all(len(p)==2 for p in pts) and pts[0]==pts[-1]
            rings.append(pts[:-1])
        return rings
    if kind.strip().upper()=='POLYGON':return [polygon(body)]
    assert kind.strip().upper()=='MULTIPOLYGON'
    return [polygon(t) for t in chunks(unwrap(body))]

def scale_for(values):
    return 10**max([0]+[-Decimal(str(v)).as_tuple().exponent for v in values])

def grid_point(p,scale):
    q=tuple(F(str(v))*scale for v in p)
    assert all(v.denominator==1 for v in q)
    return tuple(v.numerator for v in q)

def grid_geometry(polys,scale):return [[list(map(lambda p:grid_point(p,scale),ring)) for ring in poly] for poly in polys]
def cross(a,b):return a[0]*b[1]-a[1]*b[0]
def sub(a,b):return (a[0]-b[0],a[1]-b[1])
def orient(a,b,c):return cross(sub(b,a),sub(c,a))
def on(p,a,b):return orient(a,b,p)==0 and min(a[0],b[0])<=p[0]<=max(a[0],b[0]) and min(a[1],b[1])<=p[1]<=max(a[1],b[1])
def edges(rings):return [(r[i],r[(i+1)%len(r)]) for r in rings for i in range(len(r))]
def ring_location(p,ring):
    parity=False
    for a,b in edges([ring]):
        if on(p,a,b):return 0
        if (a[1]>p[1])!=(b[1]>p[1]):
            o=orient(a,b,p)
            if (o>0)==(b[1]>a[1]):parity=not parity
    return 1 if parity else -1

def polygon_location(p,rings):
    outer=ring_location(p,rings[0])
    if outer==-1:return -1
    hole=[ring_location(p,r) for r in rings[1:]]
    if 1 in hole:return -1
    if outer==0 or 0 in hole:return 0
    return 1

def memberships(p,polys,strict=False):return [i for i,rs in enumerate(polys) if polygon_location(p,rs)>(0 if strict else -1)]
def area(polys,scale=1):
    def a(r):return abs(sum(cross(u,v) for u,v in edges([r])))
    return F(sum(a(rs[0])-sum(a(r) for r in rs[1:]) for rs in polys),2*scale*scale)

def parameter_hits(a,b,c,d):
    u,v,w=sub(b,a),sub(d,c),sub(c,a);det=cross(u,v)
    if det:
        t,s=F(cross(w,v),det),F(cross(w,u),det)
        return [t] if 0<=t<=1 and 0<=s<=1 else []
    if a==b:return [F(0)] if on(a,c,d) else []
    if cross(w,u):return []
    k=0 if u[0] else 1
    lo,hi=sorted((F(c[k]-a[k],u[k]),F(d[k]-a[k],u[k])))
    lo,hi=max(F(0),lo),min(F(1),hi)
    return [lo,hi] if lo<=hi else []
def point_sq(p,a,b):
    u,w=sub(b,a),sub(p,a);norm=u[0]**2+u[1]**2;dot=u[0]*w[0]+u[1]*w[1]
    if not norm or dot<=0:return F(w[0]**2+w[1]**2)
    if dot>=norm:return F((p[0]-b[0])**2+(p[1]-b[1])**2)
    return F(cross(u,w)**2,norm)
def segment_sq(a,b,c,d):
    if parameter_hits(a,b,c,d):return F(0)
    return min(point_sq(a,c,d),point_sq(b,c,d),point_sq(c,a,b),point_sq(d,a,b))
def contained_segment(a,b,rings):
    if polygon_location(a,rings)<0 or polygon_location(b,rings)<0:return False
    cuts={F(0),F(1)}
    for c,d in edges(rings):cuts.update(parameter_hits(a,b,c,d))
    t=sorted(cuts)
    for l,r in zip(t,t[1:]):
        m=(l+r)/2;p=tuple(a[i]+m*(b[i]-a[i]) for i in (0,1))
        if polygon_location(p,rings)<0:return False
    return True

def audit_segment(a,b,rings,scale=1):
    q=min(segment_sq(a,b,c,d) for c,d in edges(rings))/(scale*scale)
    covered=(polygon_location(a,rings)>=0 and polygon_location(b,rings)>=0) if q>0 else contained_segment(a,b,rings)
    radius,tau=F(11,10),F(1,10**8)
    label='FAIL' if not covered or q<(radius-tau)**2 else 'PASS' if q>(radius+tau)**2 else 'UNCERTAIN_BOUNDARY'
    return {'q':q,'covered':covered,'exact':covered and q>=radius**2,'label':label}
def sqrt_interval(q,digits=12):
    mult=10**digits;k=isqrt(q.numerator*mult*mult//q.denominator);lo=F(k,mult);hi=lo if lo*lo==q else F(k+1,mult)
    return [str(Decimal(v.numerator)/Decimal(v.denominator)) for v in [lo,hi]]
