"""12 separately budgeted saved-input audits then <=24 declared independent real DP solves."""
if not __debug__:raise RuntimeError('Assertions must remain enabled')
from pathlib import Path
import sys,time,resource
from independent_runtime import ROOT,read,save,append,sha,utc,require,run_process

def execute(fields,schedule,base,dest,field_command,input_budget=2300,dp_budget=2300,binding=None):
 dest.mkdir(parents=True,exist_ok=True);(dest/'fields').mkdir(exist_ok=False);(dest/'calls').mkdir(exist_ok=False);start=time.monotonic();frows=[];byfield={}
 for field in fields:
  fid=field['id'];folder=dest/'fields'/fid;folder.mkdir();output=folder/'INPUT_AUDIT.json';remaining=input_budget-(time.monotonic()-start);row={'instance_id':fid,'utc':utc()};finished=base/'raw/fields'/fid/'FIELD_FINISHED.json'
  if remaining<=0:row.update(status='NOT_STARTED_INPUT_STAGE_BUDGET',process_spawned=False)
  elif not finished.exists()or read(finished).get('status')!='PASS_PREPROCESS':row.update(status='NOT_STARTED_MAIN_PREPROCESS_NONPASS',process_spawned=False)
  else:
   append(dest/'events.jsonl',{'event_kind':'INPUT_AUDIT_STARTED','instance_id':fid,'utc':utc()})
   row.update(run_process(field_command(fid,output),folder/'worker.stdout',folder/'worker.stderr',120,1024**3,min(180,remaining)))
   if output.exists():
    row['audit_sha256']=sha(output)
    try:row['audit']=read(output)
    except Exception as ex:row['audit']={'status':'NOT_VERIFIED','errors':['TRUNCATED_OR_MALFORMED_INPUT_AUDIT:'+str(ex)]}
   append(dest/'events.jsonl',{'event_kind':'INPUT_AUDIT_FINISHED','instance_id':fid,'utc':utc(),'result':row})
  append(dest/'field_results.jsonl',row);frows.append(row);byfield[fid]=row
 save(dest/'INPUT_STAGE_FINISHED.json',{'utc':utc(),'planned_fields':len(fields),'retained_fields':len(frows),'wall_seconds':time.monotonic()-start,'TSP_calls':0})
 dpstart=time.monotonic();rows=[]
 for entry in schedule:
  cid,fid=entry['call_id'],entry['instance_id'];remaining=dp_budget-(time.monotonic()-dpstart);prior=byfield[fid];row={'schedule':entry,'utc':utc()};input_file=base/'raw/fields'/fid/(entry['objective']+'.txt')
  audit=prior.get('audit',{});verified=audit.get('verified_dp_inputs',{}).get(entry['objective'],{})
  ready=prior.get('status')=='PROCESS_SUCCESS_UNREVIEWED'and audit.get('status')=='PASS_INPUT_AUDIT'and audit.get('field_id')==fid and audit.get('n')==entry['n']
  if binding is not None:ready=ready and audit.get('synthetic_only')is False and all(audit.get('gate_binding',{}).get(k)==binding.get(k)for k in('frozen_files_sha256','raw_main_archive_sha256','raw_main_receipt_sha256','verification_approval_sha256'))
  if ready:ready=input_file.is_file()and verified.get('path')==str(input_file)and verified.get('bytes')==input_file.stat().st_size and verified.get('sha256')==sha(input_file)
  if remaining<=0:row.update(status='NOT_STARTED_DP_STAGE_BUDGET',process_spawned=False)
  elif not ready:row.update(status='NOT_STARTED_INDEPENDENT_INPUT_UNVERIFIED',process_spawned=False)
  elif not input_file.is_file():row.update(status='NOT_STARTED_MISSING_DP_INPUT',process_spawned=False)
  else:
   row.update(input=str(input_file.relative_to(base)),input_sha256=sha(input_file));append(dest/'events.jsonl',{'event_kind':'DP_STARTED','schedule':entry,'utc':utc()})
   row.update(run_process([base/'independent_supervision/source/scalar_verify'],dest/'calls'/(cid+'.stdout'),dest/'calls'/(cid+'.stderr'),60,512*1024**2,min(90,remaining),input_file))
   append(dest/'events.jsonl',{'event_kind':'DP_FINISHED','schedule':entry,'utc':utc(),'result':row})
  append(dest/'results.jsonl',row);rows.append(row)
 save(dest/'FINISHED.json',{'utc':utc(),'planned_fields':len(fields),'planned_independent_DP_slots':len(schedule),'recorded_DP_slots':len(rows),'known_spawned_DP_calls':sum(r.get('process_spawned')is True for r in rows),'dp_stage_wall_seconds':time.monotonic()-dpstart,'total_wall_seconds':time.monotonic()-start,'status':'RAW_VERIFICATION_UNREVIEWED_NO_OUTCOME_COMPARISON'})
 return frows,rows

def main():
 resource.setrlimit(resource.RLIMIT_CPU,(20,120));resource.setrlimit(resource.RLIMIT_AS,(256*1024**2,1024**3))
 marker=read(ROOT/'independent_supervision/VALIDATION_LAUNCH_STARTED.json');require(marker['planned_fields']==12 and marker['planned_verification_calls']==24 and marker['raw_members_verified']is True,'active verification gate')
 require(marker['frozen_files_sha256']==sha(ROOT/'freeze/FROZEN_FILES.json')and marker['verification_approval_sha256']==sha(ROOT/'provenance/PARENT_VERIFICATION_APPROVAL.json'),'marker identity')
 fields=read(ROOT/'input/provenance/PANEL_SOURCE_READY_PROPOSAL.json')['candidates'];schedule=read(ROOT/'freeze/SCHEDULE.json');require(len(fields)==12 and len(schedule)==24,'fixed denominators')
 execute(fields,schedule,ROOT,ROOT/'independent_supervision/raw',lambda fid,out:['/usr/bin/python3','-B',ROOT/'independent_supervision/source/check_field.py',fid,out],binding=marker)
if __name__=='__main__':main()
