"""Final runtime extraction/robustness checks. Pure process/saved-output replay; no solver."""
import sys,os,time,subprocess,json,copy,signal
from pathlib import Path
from unittest.mock import patch
from independent_runtime import ROOT,save,read,sha,run_process
from launch_validation_once import run_group
from process_lifecycle import wait_group_quiescent
import run_validation_batch as b
D=ROOT/'independent_supervision/selftests/final_runtime_r1'
def worker():save(D/'worker.pid.json',{'pid':os.getpid()});time.sleep(30)
def supervisor():save(D/'supervisor.pid.json',{'pid':os.getpid()});run_process(['/usr/bin/python3','-B',__file__,'worker'],D/'worker.stdout',D/'worker.stderr',5,268435456,30)
def outer():save(D/'outer.pid.json',{'pid':os.getpid()});run_group(['/usr/bin/python3','-B',__file__,'supervisor'],D/'supervisor.stdout',D/'supervisor.stderr',30)
def alive(pid):
 try:s=Path('/proc',str(pid),'stat').read_text();return s[s.rfind(')')+2:].split()[0]not in('Z','X')
 except FileNotFoundError:return False
def main():
 D.mkdir(parents=True,exist_ok=False);checks={};p=subprocess.Popen(['/usr/bin/python3','-B',__file__,'outer'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True);deadline=time.monotonic()+5
 while not(D/'worker.pid.json').exists()and time.monotonic()<deadline:time.sleep(.01)
 assert(D/'worker.pid.json').exists();pids=[read(D/(k+'.pid.json'))['pid']for k in('outer','supervisor','worker')];p.kill();p.wait();deadline=time.monotonic()+3
 while any(alive(x)for x in pids)and time.monotonic()<deadline:time.sleep(.01)
 assert not any(alive(x)for x in pids);checks['extracted_PDEATHSIG_chain_after_outer_SIGKILL']=True
 result=run_group(['/usr/bin/python3','-c','import time; time.sleep(30)'],D/'timeout.stdout',D/'timeout.stderr',.15);assert result['timeout']and result['quiescent'];save(D/'TIMEOUT.json',result);checks['post_killpg_group_quiescence']=True
 B=ROOT/'independent_supervision/selftests/validation_chain_r1/fixture';fields=read(B.parent/'fields.json');schedule=read(B.parent/'schedule.json');old=B/'independent_supervision/raw';ors={r['schedule']['call_id']:r for r in[json.loads(l)for l in(old/'results.jsonl').read_text().splitlines()]};of={r['instance_id']:r for r in[json.loads(l)for l in(old/'field_results.jsonl').read_text().splitlines()]}
 def replay(command,stdout,stderr,*args,input_path=None,**kwargs):
  Path(stdout).write_text('SYNTHETIC_SAVED_REPLAY_ONLY\n');Path(stderr).write_text('')
  if command[0]=='saved_fixture':
   fid,out=command[1:];r=copy.deepcopy(of[fid]);a=read(old/'fields'/fid/'INPUT_AUDIT.json')
   if fid=='concave':Path(out).write_text('{"status":')
   else:
    if fid=='convex':a['verified_dp_inputs']['E_G']['sha256']='INTENTIONAL_MISMATCH'
    save(out,a)
   return {k:v for k,v in r.items()if k not in('audit','audit_sha256')}
  cid=Path(stdout).stem;return copy.deepcopy(ors[cid])
 with patch.object(b,'run_process',side_effect=replay):fs,rs=b.execute(fields,schedule,B,D/'replay',lambda fid,out:['saved_fixture',fid,out])
 assert len(fs)==5 and len(rs)==10 and sum(r['process_spawned']for r in rs)==3
 assert next(r for r in rs if r['schedule']['call_id']=='convex_E_G')['status']=='NOT_STARTED_INDEPENDENT_INPUT_UNVERIFIED'
 assert all(not r['process_spawned']for r in rs if r['schedule']['instance_id']=='concave');checks.update(truncated_input_audit_retained=True,verified_input_hash_mismatch_blocks_DP=True,all_ten_planned_slots_retained=True)
 q=subprocess.run(['/usr/bin/python3','-B',ROOT/'independent_supervision/source/launch_validation_once.py'],capture_output=True);(D/'missing_gate.stdout').write_bytes(q.stdout);(D/'missing_gate.stderr').write_bytes(q.stderr);assert q.returncode!=0 and not(ROOT/'independent_supervision/VALIDATION_LAUNCH_STARTED.json').exists()and not(ROOT/'independent_supervision/raw').exists();checks['missing_formal_gate_no_raw_or_start']=True
 save(D/'REPORT.json',{'status':'PASS','checks':checks,'solver_calls':0,'real_derivations':0,'known_worker_no_further_spawn_scope':True,'source_hashes':{p.name:sha(p)for p in Path(__file__).parent.glob('*.py')}});print('PASS',checks)
if __name__=='__main__':
 if len(sys.argv)==1:main()
 else:globals()[sys.argv[1]]()
