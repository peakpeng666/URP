"""Independent process/byte evidence only; no author planner imports."""
from pathlib import Path
import datetime,hashlib,json,os,resource,signal,subprocess,time,zipfile
from process_lifecycle import parent_death
ROOT=Path(__file__).resolve().parents[2]
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def read(p):return json.loads(Path(p).read_text())
def save(p,value):
 Path(p).parent.mkdir(parents=True,exist_ok=True)
 with Path(p).open('x')as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
def append(p,value):
 with Path(p).open('a')as f:f.write(json.dumps(value,separators=(',',':'),allow_nan=False)+'\n');f.flush();os.fsync(f.fileno())
def require(x,message):
 if not x:raise ValueError(message)
def freeze():
 p=ROOT/'freeze/FROZEN_FILES.json';d=read(p)
 for rel,m in d['files'].items():require((ROOT/rel).stat().st_size==m['bytes']and sha(ROOT/rel)==m['sha256'],'frozen '+rel)
 return sha(p)
def receipt(stage,digest):
 r=read(ROOT/f'provenance/{stage}_DRIVE_RECEIPT.json');require(r.get('stage')==stage and not r.get('synthetic_only'),'receipt stage')
 require(all(r.get(k)is True for k in('verified','owner_only','remote_readback_sha256_verified','download_byte_identical'))and r.get('shared')is False,'actual private readback')
 require(r['frozen_files_sha256']==digest and sha(r['source'])==sha(r['download_path'])==r['sha256']==r['download_sha256'],'receipt bytes')
 with zipfile.ZipFile(r['download_path'])as z:
  require(hashlib.sha256(z.read('freeze/FROZEN_FILES.json')).hexdigest()==digest,'archive embedded freeze')
 return r
def raw_members(stage,digest,prefix):
 r=receipt(stage,digest);checked=0
 with zipfile.ZipFile(r['download_path'])as z:
  names=[n for n in z.namelist()if n.startswith(prefix+'/')and not n.endswith('/')]
  actual={str(p.relative_to(ROOT))for p in(ROOT/prefix).rglob('*')if p.is_file()and '__pycache__'not in p.parts};require(set(names)==actual,'exact raw member set')
  for rel in names:require(hashlib.sha256(z.read(rel)).hexdigest()==sha(ROOT/rel),'archived raw '+rel);checked+=1
 return r,checked

def run_process(command,stdout,stderr,cpu,as_bytes,wall,input_path=None,cpu_hard=None,as_hard=None):
 require(0<wall<=4700 and cpu>0,'limits');cpu_hard=cpu if cpu_hard is None else cpu_hard;as_hard=as_bytes if as_hard is None else as_hard
 require(cpu<=cpu_hard<=120 and as_bytes<=as_hard<=1024**3,'approved ceilings')
 parent=os.getpid()
 def limits():
  parent_death(parent)
  resource.setrlimit(resource.RLIMIT_CPU,(cpu,cpu_hard));resource.setrlimit(resource.RLIMIT_AS,(as_bytes,as_hard));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
 started=utc();wall_start=time.monotonic();before=resource.getrusage(resource.RUSAGE_CHILDREN);p=None;timeout=False;error=None;reaped=None
 src=Path(input_path).open('rb')if input_path else open(os.devnull,'rb')
 with src,Path(stdout).open('xb')as out,Path(stderr).open('xb')as err:
  try:
   p=subprocess.Popen([str(x)for x in command],stdin=src,stdout=out,stderr=err,preexec_fn=limits,start_new_session=False,env={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C','PYTHONDONTWRITEBYTECODE':'1','PROJ_NETWORK':'OFF'})
   try:p.wait(timeout=wall)
   except subprocess.TimeoutExpired:timeout=True
  except Exception as ex:error=repr(ex)
  finally:
   if p is not None:
    if p.poll()is None:p.kill()
    p.wait();reaped=utc()
 after=resource.getrusage(resource.RUSAGE_CHILDREN)
 return {'status':'PROCESS_SUCCESS_UNREVIEWED'if p is not None and p.returncode==0 and not timeout and error is None else'WALL_TIMEOUT'if timeout else'PROCESS_FAILURE','started_utc':started,'reaped_utc':reaped,'finished_utc':utc(),'returncode':p.returncode if p else None,'process_spawned':p is not None,'child_reaped':p is not None and p.poll()is not None,'timeout':timeout,'error':error,'cpu_seconds':after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime,'wall_seconds':time.monotonic()-wall_start,'children_maxrss_kib_cumulative':after.ru_maxrss,'CPU_soft_hard':[cpu,cpu_hard],'AS_soft_hard':[as_bytes,as_hard],'stdout':str(stdout),'stderr':str(stderr),'stdout_sha256':sha(stdout),'stderr_sha256':sha(stderr)}
