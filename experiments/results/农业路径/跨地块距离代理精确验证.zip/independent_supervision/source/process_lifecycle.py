"""Shared Linux known-worker lifecycle helpers. No solver, user files, or permissions changes."""
from pathlib import Path
import os,signal,time,ctypes

def parent_death(parent):
 # Known workers do not spawn further children. Chain this at each parent edge.
 libc=ctypes.CDLL(None,use_errno=True)
 if libc.prctl(1,signal.SIGKILL,0,0,0)!=0:raise OSError(ctypes.get_errno(),'PR_SET_PDEATHSIG')
 if os.getppid()!=parent:os.kill(os.getpid(),signal.SIGKILL)

def group_members(group):
 members=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   q=(p/'stat').read_text();fields=q[q.rfind(')')+2:].split()
   if int(fields[2])==group and fields[0]not in('Z','X'):members.append(int(p.name))
  except (FileNotFoundError,ProcessLookupError,PermissionError):pass
 return members

def wait_group_quiescent(group,timeout=2):
 remain=group_members(group);deadline=time.monotonic()+timeout
 while remain and time.monotonic()<deadline:
  time.sleep(.02);remain=group_members(group)
 return remain
