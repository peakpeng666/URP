"""Saved synthetic evidence and pure negative mutations; zero additional solver calls."""
from pathlib import Path
import copy,json,shutil
from unittest.mock import patch
import saved_audit as a
from independent_runtime import ROOT,read,save,sha
D=ROOT/'independent_supervision/selftests/saved_audit_r2';D.mkdir(parents=True,exist_ok=False)
B=ROOT/'independent_supervision/selftests/validation_chain_r1/fixture';old=ROOT/'selftests/pipeline_r3/workspace/raw'
assert (B/'raw/calls').exists();fields=read(B.parent/'fields.json');schedule=read(B.parent/'schedule.json');main=read(old/'ALL_PLANNED_SLOTS.json');ver=[json.loads(x)for x in(B/'independent_supervision/raw/results.jsonl').read_text().splitlines()]
r=a.analyze(B,fields,schedule,main,ver);save(D/'MIXED_PANEL.json',r);assert r['verified_fields']==3 and r['complete_panel_mean_delta_integer_mm']is None and len(r['rows'])==10 and r['independent_counts']['known_spawned']==6
ids={'convex','concave','hole'};fs=[f for f in fields if f['id']in ids];ss=[s for s in schedule if s['instance_id']in ids];mm=[s for s in main if s['schedule']['instance_id']in ids];vv=[s for s in ver if s['schedule']['instance_id']in ids]
r=a.analyze(B,fs,ss,mm,vv);save(D/'COMPLETE_SYNTHETIC_PANEL.json',r);assert r['status']=='PASS'and r['verified_fields']==3
checks={'complete_saved_3_field_6_DP_value_route_comparison':True,'mixed_5_field_10_slots_preserved_full_panel_null':True};e=ss[0];m=mm[0];v=vv[0];audit=read(B/'independent_supervision/raw/fields'/e['instance_id']/'INPUT_AUDIT.json');mp=B/'raw/calls'/(e['call_id']+'.stdout');vp=B/'independent_supervision/raw/calls'/(e['call_id']+'.stdout')
for name,path,change in [
 ('bad_route',mp,lambda x:x.update(route=[0,1,1,2,3,0])),
 ('wrong_primary',vp,lambda x:x.update(primary=x['primary']+1)),
 ('wrong_state_count',vp,lambda x:x.update(states=x['states']-1)),
 ('wrong_limit',vp,lambda x:x.update(rlimit_cpu=[61,61])),
 ('bad_encoding',vp,lambda x:x.update(encoding_base=x['encoding_base']+1))]:
 value=copy.deepcopy(read(path));change(value);original=a.read
 with patch.object(a,'read',side_effect=lambda p:copy.deepcopy(value)if Path(p)==path else original(p)):
  x=a.verify_slot(B,e,m,v,audit)
 assert not x['valid_for_exact_conclusion'],name;save(D/(name+'.json'),x);checks[name]=True
for name,mainchange,indchange,auditchange in [
 ('missing_main',{},v,audit),('wrong_input_hash',m,{**v,'input_sha256':'bad'},audit),('unverified_input',m,v,{**audit,'status':'NOT_VERIFIED'}),('process_failed',m,{**v,'status':'WALL_TIMEOUT'},audit)]:
 x=a.verify_slot(B,e,mainchange,indchange,auditchange);assert not x['valid_for_exact_conclusion'];checks[name]=True;save(D/(name+'.json'),x)
x=a.analyze(B,fs,ss,mm+[mm[0]],vv);assert x['verified_fields']==0 and x['ledger_errors']['main'];checks['duplicate_ledger_failclosed']=True
x=a.analyze(B,fs,ss,mm[1:],vv);assert x['verified_fields']==2 and x['main_counts']['unknown_spawned_slots']==1;checks['missing_call_retained']=True
x=a.analyze(B,fs,ss,mm,vv,{'main':['MALFORMED_RAW_LEDGER']});assert x['verified_fields']==0;checks['outer_bad_ledger_preserved_unverified']=True
save(D/'REPORT.json',{'status':'PASS','checks':checks,'new_solver_calls':0,'synthetic_saved_evidence_only':True,'source_sha256':sha(Path(a.__file__))});print('PASS',len(checks),checks)
