"""Unique saved-audit wrapper with declared limits; zero optimization."""
import resource,sys
from independent_runtime import ROOT,freeze,receipt,save,utc
from launch_validation_once import run_group

def main():
 resource.setrlimit(resource.RLIMIT_CPU,(20,60));resource.setrlimit(resource.RLIMIT_AS,(268435456,536870912));d=freeze();receipt('RAW_MAIN',d);receipt('RAW_VERIFICATION',d)
 save(ROOT/'independent_supervision/SAVED_AUDIT_STARTED.json',{'utc':utc(),'frozen_files_sha256':d,'new_DP_calls':0,'CPU_soft_hard':[20,60],'AS_soft_hard':[268435456,536870912]})
 result=run_group([sys.executable,'-B',ROOT/'independent_supervision/source/saved_audit.py'],ROOT/'independent_supervision/saved_audit.stdout',ROOT/'independent_supervision/saved_audit.stderr',120)
 save(ROOT/'independent_supervision/SAVED_AUDIT_FINISHED.json',result)
 if result['returncode']!=0 or result['timeout']or not result['quiescent']:raise RuntimeError('SAVED_AUDIT_FAILED_EVIDENCE_PRESERVED')
if __name__=='__main__':main()
