"""Invented/saved four-client fixtures only; actual production limits and failure retention."""
import sys,os,json,shutil,subprocess,time,resource,itertools,signal
from pathlib import Path
from independent_runtime import ROOT,save,read,sha,run_process
from launch_validation_once import run_group,group_members
from run_validation_batch import execute
D=ROOT/'independent_supervision/selftests/validation_chain_r1'
def supervisor():
 resource.setrlimit(resource.RLIMIT_CPU,(20,120));resource.setrlimit(resource.RLIMIT_AS,(268435456,1073741824));base=D/'fixture';fields=read(D/'fields.json');schedule=read(D/'schedule.json')
 save(D/'supervisor_limits.json',{'cpu':list(resource.getrlimit(resource.RLIMIT_CPU)),'as':list(resource.getrlimit(resource.RLIMIT_AS))})
 execute(fields,schedule,base,base/'independent_supervision/raw',lambda fid,out:['/usr/bin/python3','-B',__file__,'field',fid,out],input_budget=90,dp_budget=90)
def field():
 from check_field import audit_synthetic
 fid=sys.argv[2];p=D/'fixture/raw/fields'/fid;r=audit_synthetic(p,fid);r['status']='PASS_INPUT_AUDIT'if r['status']=='PASS_SYNTHETIC_INPUT_AUDIT'else r['status'];r['fixture_only_adapter']=True;r['limits']={'cpu':list(resource.getrlimit(resource.RLIMIT_CPU)),'as':list(resource.getrlimit(resource.RLIMIT_AS))};save(sys.argv[3],r)
def outer():
 resource.setrlimit(resource.RLIMIT_CPU,(60,120));resource.setrlimit(resource.RLIMIT_AS,(536870912,1073741824));save(D/'outer_limits.json',{'cpu':list(resource.getrlimit(resource.RLIMIT_CPU)),'as':list(resource.getrlimit(resource.RLIMIT_AS))});save(D/'outer_result.json',run_group(['/usr/bin/python3','-B',__file__,'supervisor'],D/'supervisor.stdout',D/'supervisor.stderr',200))
def worker():
 save(D/(sys.argv[2]+'.pid.json'),{'pid':os.getpid()});time.sleep(30)
def death_supervisor():
 save(D/'death_supervisor.pid.json',{'pid':os.getpid()});run_process(['/usr/bin/python3','-B',__file__,'worker','death_worker'],D/'death_worker.stdout',D/'death_worker.stderr',5,268435456,30)
def death_outer():
 save(D/'death_outer.pid.json',{'pid':os.getpid()});run_group(['/usr/bin/python3','-B',__file__,'death_supervisor'],D/'death_supervisor.stdout',D/'death_supervisor.stderr',30)
def alive(pid):
 try:q=Path('/proc',str(pid),'stat').read_text();return q[q.rfind(')')+2:].split()[0]not in('Z','X')
 except FileNotFoundError:return False
def main():
 D.mkdir(parents=True,exist_ok=False);base=D/'fixture';(base/'raw').mkdir(parents=True);shutil.copytree(ROOT/'selftests/pipeline_r3/workspace/raw/fields',base/'raw/fields');(base/'independent_supervision/source').mkdir(parents=True);shutil.copy2(ROOT/'independent_supervision/source/scalar_verify',base/'independent_supervision/source/scalar_verify')
 ids=['convex','concave','hole','empty','split'];fields=[{'id':f,'stratum':'synthetic'}for f in ids];schedule=[{'call_id':f+'_'+a,'instance_id':f,'n':4,'objective':a}for f in ids for a in('E_G','G_E')];save(D/'fields.json',fields);save(D/'schedule.json',schedule)
 p=subprocess.run(['/usr/bin/python3','-B',__file__,'outer'],capture_output=True,timeout=220);(D/'outer.stdout').write_bytes(p.stdout);(D/'outer.stderr').write_bytes(p.stderr);assert p.returncode==0,p.stderr
 r=base/'independent_supervision/raw';rows=[json.loads(x)for x in(r/'results.jsonl').read_text().splitlines()];frows=[json.loads(x)for x in(r/'field_results.jsonl').read_text().splitlines()];assert len(rows)==10 and len(frows)==5 and sum(x['process_spawned']for x in rows)==6
 assert read(D/'outer_result.json')['quiescent'];checks={'12_and_24_logic_exercised_on_fixed_5_field_10_slot_synthetic_panel':True,'actual_outer_soft_hard':read(D/'outer_limits.json')=={'cpu':[60,120],'as':[536870912,1073741824]},'actual_supervisor_soft_hard':read(D/'supervisor_limits.json')=={'cpu':[20,120],'as':[268435456,1073741824]}}
 for f in frows:
  if f.get('process_spawned'):assert f['audit']['limits']=={'cpu':[120,120],'as':[1073741824,1073741824]}
 for row in rows:
  if not row['process_spawned']:continue
  e=row['schedule'];o=read(r/'calls'/(e['call_id']+'.stdout'));d=read(base/'raw/fields'/e['instance_id']/'preprocess.json');vals=[]
  for perm in itertools.permutations(range(1,5)):
   route=(0,)+perm+(0,);sums={a:sum(d['integer_matrices'][a][u][v]for u,v in zip(route,route[1:]))for a in('E','G')};vals.append(tuple(sums[a]for a in e['objective'].split('_')))
  assert(o['primary'],o['secondary'])==min(vals);assert o['rlimit_cpu']==[60,60]and o['rlimit_as']==[536870912,536870912]
 checks.update(input_worker_actual_120CPU_1GiB=True,DP_worker_actual_60CPU_512MiB=True,six_scalar_synthetic_calls_match_bruteforce=True,empty_and_split_four_DP_slots_retained_without_spawn=True)
 # Wall expiry uses the same cleanup path and verifies quiescence.
 wall=run_group(['/usr/bin/python3','-B',__file__,'worker','timeout_worker'],D/'timeout.stdout',D/'timeout.stderr',.3);assert wall['timeout']and wall['quiescent'];save(D/'wall_failure.json',wall);checks['wall_expiry_cleanup']=True
 # Hard outer death cascades parent-death signals through supervisor to worker.
 p=subprocess.Popen(['/usr/bin/python3','-B',__file__,'death_outer'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)
 deadline=time.monotonic()+5
 while not(D/'death_worker.pid.json').exists()and time.monotonic()<deadline:time.sleep(.02)
 assert(D/'death_worker.pid.json').exists();p.kill();p.wait();pids=[read(D/(name+'.pid.json'))['pid']for name in('death_outer','death_supervisor','death_worker')];deadline=time.monotonic()+3
 while any(alive(pid)for pid in pids)and time.monotonic()<deadline:time.sleep(.02)
 assert not any(alive(pid)for pid in pids);checks['hard_outer_death_cascade_no_live_known_workers']=True;save(D/'death_chain.json',{'pids':pids,'all_nonlive':True})
 assert all(checks.values());save(D/'REPORT.json',{'status':'PASS','synthetic_only':True,'real_input_derivations':0,'real_DP_calls':0,'synthetic_DP_calls':6,'checks':checks,'source_hashes':{p.name:sha(p)for p in Path(__file__).parent.glob('*.py')}});print('PASS',checks)
if __name__=='__main__':
 if len(sys.argv)==1:main()
 else:globals()[sys.argv[1]]()
