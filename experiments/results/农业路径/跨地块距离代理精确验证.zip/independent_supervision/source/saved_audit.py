"""Saved-only exact value/route/cost audit, after both actual RAW readbacks. Zero new DP."""
if not __debug__:raise RuntimeError('Assertions must remain enabled')
from pathlib import Path
from decimal import Decimal,localcontext
import json,math,resource,signal,statistics,time
from independent_runtime import ROOT,read,save,sha,utc,require,freeze,raw_members

def index_rows(rows,schedule):
 expected={e['call_id']:e for e in schedule};by={};errors=[]
 for row in rows:
  try:
   e=row['schedule'];cid=e['call_id'];require(cid in expected and e==expected[cid],'schedule identity');require(cid not in by,'duplicate call');by[cid]=row
  except Exception as ex:errors.append(str(ex))
 return by,errors

def verify_slot(base,entry,main,ind,audit):
 n=entry['n'];arm=entry['objective'];cid=entry['call_id'];fid=entry['instance_id'];out={'call_id':cid,'instance_id':fid,'objective':arm,'valid_for_exact_conclusion':False,'errors':[],'main_status':main.get('status','MISSING'),'independent_status':ind.get('status','MISSING')}
 try:
  require(audit.get('status')=='PASS_INPUT_AUDIT','INPUT_NOT_VERIFIED');require(audit['n']==n and audit.get('field_id')==fid,'input n/field')
  if n==20:require(audit.get('synthetic_only')is False,'REAL_INPUT_AUDIT_REQUIRED')
  require(main.get('status')=='UNREVIEWED_PROCESS_SUCCESS' and ind.get('status')=='PROCESS_SUCCESS_UNREVIEWED','PROCESS_NONPASS')
  require(main.get('process_spawned')is True and ind.get('process_spawned')is True,'spawn evidence')
  ip=base/'raw/fields'/fid/(arm+'.txt');require(audit['verified_dp_inputs'][arm]['sha256']==sha(ip)==main['input_sha256']==ind['input_sha256'],'INPUT_HASH_MISMATCH')
  mp=base/'raw/calls'/(cid+'.stdout');vp=base/'independent_supervision/raw/calls'/(cid+'.stdout');require(sha(mp)==main['stdout_sha256']and sha(vp)==ind['stdout_sha256'],'STDOUT_HASH_MISMATCH')
  m=read(mp);v=read(vp);d=read(base/'raw/fields'/fid/'preprocess.json');require(m['status']=='EXACT_ALGORITHM_COMPLETED_UNREVIEWED'and v['status']=='INDEPENDENT_EXACT_VALUE_UNREVIEWED','OUTPUT_STATUS')
  require(m['n']==v['n_customers']==n and m['objective']==v['objective']==arm,'OUTPUT_IDENTITY')
  for x in (m,v):
   require(all(type(x[k])is int and x[k]>=0 for k in('primary','secondary','E','G')),'INTEGER_OUTPUT')
   require((x['primary'],x['secondary'])==((x['E'],x['G'])if arm=='E_G'else(x['G'],x['E'])),'OBJECTIVE_MAPPING')
   require(x['rlimit_cpu']==[60,60]and x['rlimit_as']==[536870912,536870912],'ACTUAL_DP_LIMITS')
  require((m['primary'],m['secondary'])==(v['primary'],v['secondary']),'INDEPENDENT_OPTIMUM_MISMATCH')
  states=n*2**(n-1);trans=n*(n-1)*2**(n-2)if n>=2 else 0
  require(m['valid_states']==v['states']==states and m['internal_transitions']==v['extension_transitions']==trans,'DP_OPERATION_COUNTS')
  layers=[0]+[math.comb(n,k)*k for k in range(1,n+1)]
  require(m['states_by_cardinality']==v['states_by_cardinality']==layers,'DP_LAYER_COUNTS')
  require(m['transitions_by_cardinality']==[0]+[layers[k]*(k-1)for k in range(1,n+1)],'AUTHOR_TRANSITION_LAYERS')
  require(v['outgoing_transitions_by_cardinality']==[0]+[layers[k]*(n-k)for k in range(1,n+1)],'INDEPENDENT_TRANSITION_LAYERS')
  pmat,smat=(d['integer_matrices'][k]for k in(('E','G')if arm=='E_G'else('G','E')));pmax=max(map(max,pmat));smax=max(map(max,smat));B=(n+1)*smax+1
  require(v['encoding_base']==B and v['encoded_objective']==v['primary']*B+v['secondary']and 0<=v['secondary']<B,'ENCODING_DECODE')
  require(v['safe_tour_bound']==(n+1)*(pmax*B+smax)<v['sentinel']==(2**63-1)//4,'OVERFLOW_PROOF')
  route=m['route'];require(all(type(x)is int for x in route)and len(route)==n+2 and route[0]==route[-1]==0 and sorted(route[1:-1])==list(range(1,n+1)),'INVALID_HAMILTON_TOUR')
  values={a:sum(d['integer_matrices'][a][u][w]for u,w in zip(route,route[1:]))for a in('E','G')};require(values=={a:m[a]for a in('E','G')},'ROUTE_INTEGER_COST_MISMATCH')
  with localcontext()as ctx:
   ctx.prec=80;physical=sum((Decimal(audit['canonical_decimal80_path_length_m'][u][w])for u,w in zip(route,route[1:])),Decimal(0));stored=sum((Decimal(str(d['unrounded_matrices']['G'][u][w]))for u,w in zip(route,route[1:])),Decimal(0));require(abs(physical-stored)<=Decimal(n+1)*Decimal('1e-8'),'PHYSICAL_LENGTH_RESIDUAL')
  out.update(valid_for_exact_conclusion=True,main_primary=m['primary'],main_secondary=m['secondary'],independent_primary=v['primary'],independent_secondary=v['secondary'],E=m['E'],G=m['G'],route=route,realized_path_length_m_decimal80=str(physical),realized_minus_saved_G_m_decimal80=str(physical-stored),main_stdout_sha256=sha(mp),independent_stdout_sha256=sha(vp),input_sha256=sha(ip))
 except Exception as ex:out['errors'].append(str(ex))
 return out

def analyze(base,fields,schedule,mainrows,verrows,outer_ledger_errors=None):
 main,me=index_rows(mainrows,schedule);ver,ve=index_rows(verrows,schedule);me+=list((outer_ledger_errors or {}).get('main',[]));ve+=list((outer_ledger_errors or {}).get('independent',[]));rows=[];fieldrows=[];byfield={}
 for f in fields:
  p=base/'independent_supervision/raw/fields'/f['id']/'INPUT_AUDIT.json'
  try:a=read(p)if p.exists()else{'status':'NOT_VERIFIED'}
  except Exception as ex:a={'status':'NOT_VERIFIED','errors':[str(ex)]}
  byfield[f['id']]=a
 for e in schedule:
  r=verify_slot(base,e,main.get(e['call_id'],{}),ver.get(e['call_id'],{}),byfield[e['instance_id']])
  if me or ve:r['valid_for_exact_conclusion']=False;r['errors'].append('AMBIGUOUS_SLOT_LEDGER')
  rows.append(r)
 for f in fields:
  rr=[r for r in rows if r['instance_id']==f['id']];ok=len(rr)==2 and {r['objective']for r in rr}=={'E_G','G_E'}and all(r['valid_for_exact_conclusion']for r in rr)
  fr={'instance_id':f['id'],'stratum':f['stratum'],'eligible_for_primary':ok,'input_audit_status':byfield[f['id']].get('status','NOT_VERIFIED')}
  if ok:
   a=next(r for r in rr if r['objective']=='E_G');b=next(r for r in rr if r['objective']=='G_E');delta=a['G']-b['G'];require(delta>=0,'IMPOSSIBLE_LEX_DELTA')
   with localcontext()as ctx:ctx.prec=80;physical=Decimal(a['realized_path_length_m_decimal80'])-Decimal(b['realized_path_length_m_decimal80'])
   fr.update(delta_integer_mm=delta,realized_length_difference_m_decimal80=str(physical),relative_integer_percent=100*delta/b['G']if b['G']else None)
  fieldrows.append(fr)
 good=[f for f in fieldrows if f['eligible_for_primary']];complete=len(good)==len(fields)
 def count(which):
  return {'retained_slots':len(schedule),'observed_unique_records':len(which),'known_spawned':sum(r.get('process_spawned')is True for r in which.values()),'unknown_spawned_slots':sum(e['call_id']not in which or type(which[e['call_id']].get('process_spawned'))is not bool for e in schedule)}
 return {'status':'PASS'if complete else'AUDIT_COMPLETE_WITH_UNVERIFIED_SLOTS','planned_fields':len(fields),'planned_main_calls':len(schedule),'planned_independent_calls':len(schedule),'planned_total_DP_calls':2*len(schedule),'main_counts':count(main),'independent_counts':count(ver),'ledger_errors':{'main':me,'independent':ve},'eligible_instance_ids':[f['instance_id']for f in good],'verified_fields':len(good),'complete_panel_mean_delta_integer_mm':statistics.mean(f['delta_integer_mm']for f in good)if complete else None,'complete_case_mean_delta_integer_mm':statistics.mean(f['delta_integer_mm']for f in good)if good else None,'fields':fieldrows,'rows':rows,'new_DP_calls_in_saved_audit':0,'scope':'Independent exact recomputation agreement for frozen integer proxy and independently audited safe saved graph paths. No formal full-DP certificate or continuous-plane optimum.'}

def main():
 resource.setrlimit(resource.RLIMIT_CPU,(60,60));resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912));signal.signal(signal.SIGALRM,lambda *_:(_ for _ in()).throw(TimeoutError('SAVED_AUDIT_120S')));signal.alarm(120);start=time.monotonic();cpu=time.process_time();d=freeze();rm,nm=raw_members('RAW_MAIN',d,'raw');rv,nv=raw_members('RAW_VERIFICATION',d,'independent_supervision/raw');fields=read(ROOT/'input/provenance/PANEL_SOURCE_READY_PROPOSAL.json')['candidates'];schedule=read(ROOT/'freeze/SCHEDULE.json');require(len(fields)==12 and len(schedule)==24 and all(e['n']==20 for e in schedule),'FIXED_REAL_PANEL')
 mo=read(ROOT/'raw/OUTER_FINISHED.json');vo=read(ROOT/'independent_supervision/raw/OUTER_FINISHED.json');issues={'main':[],'independent':[]}
 if mo.get('duplicate_call_ids')or mo.get('malformed_rows'):issues['main'].append('OUTER_RECORDED_AMBIGUOUS_OR_MALFORMED_LEDGER')
 if vo.get('duplicate_record_ids')or vo.get('malformed_result_line_numbers'):issues['independent'].append('OUTER_RECORDED_AMBIGUOUS_OR_MALFORMED_LEDGER')
 result=analyze(ROOT,fields,schedule,read(ROOT/'raw/ALL_PLANNED_SLOTS.json'),read(ROOT/'independent_supervision/raw/OUTER_ALL_PLANNED_SLOTS.json'),issues)
 result.update(utc=utc(),frozen_files_sha256=d,raw_main_archive_sha256=rm['sha256'],raw_verification_archive_sha256=rv['sha256'],raw_members_checked=[nm,nv],CPU_seconds=time.process_time()-cpu,wall_seconds=time.monotonic()-start,maxrss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
 save(ROOT/'independent_supervision/FINAL_AUDIT.json',result);print(json.dumps({k:result[k]for k in('status','verified_fields','main_counts','independent_counts','complete_panel_mean_delta_integer_mm')}))
if __name__=='__main__':main()
