// Independent value-only forward Held--Karp with rigorously bounded integer lexicographic encoding.
#include <algorithm>
#include <cstdint>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
#include <sys/resource.h>
#include <vector>
using C=std::int64_t;
const C INF=std::numeric_limits<C>::max()/4;
void demand(bool ok,const char *why){if(!ok)throw std::runtime_error(why);}
int main(){try{
 std::string tag,mode,extra;int n=0;demand(bool(std::cin>>tag>>n>>mode),"header");
 demand(tag=="HKLEX_V1"&&(mode=="E_G"||mode=="G_E"),"input protocol");demand(n>=1&&n<=20,"clients must be1..20");
 const int N=n+1;std::vector<C> E(N*N),G(N*N);
 for(auto *mat:{&E,&G})for(auto &x:*mat){demand(bool(std::cin>>x),"integer input");demand(x>=0&&x<INF,"edge range");}
 demand(!(std::cin>>extra),"trailing input");
 for(const auto *mat:{&E,&G})for(int i=0;i<N;i++)for(int j=0;j<N;j++){demand((*mat)[i*N+j]==(*mat)[j*N+i],"asymmetric");if(i==j)demand((*mat)[i*N+j]==0,"diagonal");}
 const auto &P=mode=="E_G"?E:G;const auto &S=mode=="E_G"?G:E;
 const C pmax=*std::max_element(P.begin(),P.end()),smax=*std::max_element(S.begin(),S.end());
 // Every Hamilton tour has N=n+1 edges, so secondary_sum <= N*smax < B.
 demand(smax<=(INF-2)/N,"encoding base overflow");const C B=C(N)*smax+1;
 demand(pmax<=(INF-1-smax)/B,"encoded edge overflow");const C maxw=pmax*B+smax;
 demand(maxw<=(INF-1)/N,"encoded complete tour exceeds sentinel");
 std::vector<C>w(N*N);for(int i=0;i<N*N;i++)w[i]=P[i]*B+S[i];
 const std::uint32_t count=std::uint32_t(1)<<n,full=count-1;
 // Endpoint-major layout differs from the author's backward pair-valued implementation.
 std::vector<C> d(std::size_t(n)*count,INF);
 for(int j=0;j<n;j++)d[std::size_t(j)*count+(std::uint32_t(1)<<j)]=w[j+1];
 std::uint64_t states=0,extensions=0;std::vector<std::uint64_t>layers(n+1,0),outgoing(n+1,0);
 for(std::uint32_t mask=1;mask<count;mask++){
  const int k=__builtin_popcount(mask);
  for(int last=0;last<n;last++)if(mask&(std::uint32_t(1)<<last)){
   const C current=d[std::size_t(last)*count+mask];demand(current!=INF,"unreachable complete-graph state");states++;layers[k]++;
   for(int next=0;next<n;next++)if(!(mask&(std::uint32_t(1)<<next))){
    // Both operands are finite. Their sum is bounded by an at-most-N-edge path below INF.
    const C candidate=current+w[(last+1)*N+next+1];demand(candidate<INF,"partial overflow guard");
    C &target=d[std::size_t(next)*count+(mask|(std::uint32_t(1)<<next))];if(candidate<target)target=candidate;
    extensions++;outgoing[k]++;
   }
  }
 }
 C optimum=INF;for(int last=0;last<n;last++){const C c=d[std::size_t(last)*count+full]+w[(last+1)*N];if(c<optimum)optimum=c;}
 demand(optimum<INF,"no finite closed tour");const C primary=optimum/B,secondary=optimum%B;
 demand(states==std::uint64_t(n)*(std::uint64_t(1)<<(n-1)),"state count");
 demand(extensions==(n==1?0:std::uint64_t(n)*(n-1)*(std::uint64_t(1)<<(n-2))),"extension count");
 rusage use{};demand(getrusage(RUSAGE_SELF,&use)==0,"rusage");rlimit cpu{},as{};demand(getrlimit(RLIMIT_CPU,&cpu)==0&&getrlimit(RLIMIT_AS,&as)==0,"rlimit");
 std::cout<<"{\"status\":\"INDEPENDENT_EXACT_VALUE_UNREVIEWED\",\"algorithm\":\"forward_scalar_held_karp_v1\",\"n_customers\":"<<n<<",\"tour_edges\":"<<N<<",\"objective\":\""<<mode<<"\",\"encoding_base\":"<<B<<",\"encoded_objective\":"<<optimum<<",\"primary\":"<<primary<<",\"secondary\":"<<secondary<<",\"E\":"<<(mode=="E_G"?primary:secondary)<<",\"G\":"<<(mode=="E_G"?secondary:primary)<<",\"max_primary_edge\":"<<pmax<<",\"max_secondary_edge\":"<<smax<<",\"safe_tour_bound\":"<<C(N)*maxw<<",\"sentinel\":"<<INF<<",\"states\":"<<states<<",\"extension_transitions\":"<<extensions<<",\"array_bytes\":"<<std::size_t(n)*count*sizeof(C)<<",\"states_by_cardinality\":[";
 for(int i=0;i<=n;i++){std::cout<<(i?",":"")<<layers[i];}
 std::cout<<"],\"outgoing_transitions_by_cardinality\":[";
 for(int i=0;i<=n;i++){std::cout<<(i?",":"")<<outgoing[i];}
 std::cout<<"],\"rlimit_cpu\":["<<cpu.rlim_cur<<","<<cpu.rlim_max<<"],\"rlimit_as\":["<<as.rlim_cur<<","<<as.rlim_max<<"],\"maxrss_kib\":"<<use.ru_maxrss<<",\"cpu_seconds\":"<<(use.ru_utime.tv_sec+use.ru_stime.tv_sec+(use.ru_utime.tv_usec+use.ru_stime.tv_usec)/1e6)<<",\"route_produced\":false,\"full_dp_table_retained\":false}\n";
 return 0;
 }catch(const std::bad_alloc&){std::cerr<<"allocation failure\n";return 3;}catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 2;}}
