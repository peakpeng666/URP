"""Single outer-owned process group, authenticated RAW_MAIN gate, and loss-aware post-cleanup seal."""
if not __debug__:raise RuntimeError('Assertions must remain enabled')
from pathlib import Path
import sys,resource,subprocess,time,os,signal
from process_lifecycle import group_members,wait_group_quiescent
from independent_runtime import ROOT,read,save,sha,utc,require,freeze,raw_members,parent_death

def run_group(command,outpath,errpath,wall=4700):
 p=None;timedout=False;error=None;start=time.monotonic();started=utc();parent=os.getpid()
 with Path(outpath).open('xb')as out,Path(errpath).open('xb')as err:
  try:
   p=subprocess.Popen([str(x)for x in command],stdout=out,stderr=err,start_new_session=True,preexec_fn=lambda:parent_death(parent),env={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C','PYTHONDONTWRITEBYTECODE':'1','PROJ_NETWORK':'OFF'})
   try:p.wait(timeout=wall)
   except subprocess.TimeoutExpired:timedout=True
  except Exception as ex:error=repr(ex)
  finally:
   if p is not None:
    try:os.killpg(p.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    p.wait()
 remain=wait_group_quiescent(p.pid)if p else []
 return {'quiescent':not remain,'remaining_group_members':remain,'started_utc':started,'finished_utc':utc(),'returncode':p.returncode if p else None,'timeout':timedout,'error':error,'wall_seconds':time.monotonic()-start,'whole_group_cleanup_attempted_before_seal':True}

def main():
 resource.setrlimit(resource.RLIMIT_CPU,(60,120));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,1024**3))
 digest=freeze();r,members=raw_members('RAW_MAIN',digest,'raw');approval=read(ROOT/'provenance/PARENT_VERIFICATION_APPROVAL.json')
 require(approval.get('approved')is True and approval.get('frozen_files_sha256')==digest and approval.get('raw_main_archive_sha256')==r['sha256']and approval.get('verification_calls')==24 and approval.get('input_audit_fields')==12,'root hash and exact budget approval')
 dest=ROOT/'independent_supervision/raw';require(not dest.exists()or not any(p.is_file()for p in dest.rglob('*')),'no resume or overwrite');dest.mkdir(parents=True,exist_ok=True)
 save(ROOT/'independent_supervision/VALIDATION_LAUNCH_STARTED.json',{'utc':utc(),'frozen_files_sha256':digest,'raw_main_archive_sha256':r['sha256'],'raw_main_receipt_sha256':sha(ROOT/'provenance/RAW_MAIN_DRIVE_RECEIPT.json'),'verification_approval_sha256':sha(ROOT/'provenance/PARENT_VERIFICATION_APPROVAL.json'),'planned_fields':12,'planned_verification_calls':24,'raw_members_verified':True,'raw_members_checked':members,'planned_author_DP_slots':24,'total_planned_DP_slots':48,'no_retries':True,'CPU_soft_hard':[60,120],'AS_soft_hard':[512*1024**2,1024**3]})
 outer=run_group([sys.executable,'-B',ROOT/'independent_supervision/source/run_validation_batch.py'],dest/'supervisor.stdout',dest/'supervisor.stderr')
 require(outer['quiescent'],'WORKER_GROUP_NOT_QUIESCENT_NO_SEAL')
 rows=[];malformed=[];source=dest/'results.jsonl'
 if source.exists():
  for i,line in enumerate(source.read_text().splitlines(),1):
   try:
    row=__import__('json').loads(line);require(isinstance(row,dict)and isinstance(row.get('schedule'),dict)and isinstance(row['schedule'].get('call_id'),str),'MALFORMED_RESULT_SCHEMA');rows.append(row)
   except Exception:malformed.append(i)
 by={r['schedule']['call_id']:r for r in rows};schedule=read(ROOT/'freeze/SCHEDULE.json');allslots=[]
 for e in schedule:
  exists=(dest/'calls'/(e['call_id']+'.stdout')).exists();allslots.append(by.get(e['call_id'],{'schedule':e,'status':'UNKNOWN_AFTER_SUPERVISOR_FAILURE'if exists else'NOT_STARTED_AFTER_SUPERVISOR_FAILURE','process_spawned':'UNKNOWN'if exists else False}))
 fields=read(ROOT/'input/provenance/PANEL_SOURCE_READY_PROPOSAL.json')['candidates'];fieldslots=[]
 for f in fields:
  p=dest/'fields'/f['id']/'INPUT_AUDIT.json'
  try:audit=read(p)if p.exists()else{'status':'NOT_VERIFIED','errors':['NO_COMPLETED_INPUT_AUDIT']}
  except Exception as ex:audit={'status':'NOT_VERIFIED','errors':['MALFORMED_INPUT_AUDIT:'+str(ex)]}
  fieldslots.append({'instance_id':f['id'],'audit':audit})
 save(dest/'OUTER_ALL_PLANNED_SLOTS.json',allslots);save(dest/'OUTER_ALL_FIELD_SLOTS.json',fieldslots);save(dest/'OUTER_FINISHED.json',{'utc':utc(),**outer,'status':'RAW_VERIFICATION_UNREVIEWED','planned_DP_slots':24,'planned_fields':12,'duplicate_record_ids':len(by)!=len(rows),'malformed_result_line_numbers':malformed,'no_final_comparison_performed':True})
 save(dest/'RAW_VERIFICATION_CONTENT_MANIFEST.json',{'utc':utc(),'frozen_files_sha256':digest,'files':{str(p.relative_to(ROOT)):{'bytes':p.stat().st_size,'sha256':sha(p)}for p in sorted(dest.rglob('*'))if p.is_file()}})
 print('Independent inputs andDP stopped; RAW_VERIFICATION sealed. Unique package and actual private readback required before final comparison.')
if __name__=='__main__':main()
