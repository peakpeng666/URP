"""Independent audit of a frozen saved field. No author/planner imports or TSP.
Formal CLI requires the actual-readback, root-approved validation window. The only
ungated test API accepts hardcoded, explicitly synthetic, four-task fixtures.
"""
import hashlib, heapq, json, math, pathlib, random, resource, signal, sys, time, traceback, zipfile
from decimal import Decimal as D, localcontext, ROUND_HALF_UP
from fractions import Fraction as F
import geometry_exact as gx

ROOT = pathlib.Path(__file__).resolve().parents[2]
TOL = D('1e-8')
SYNTHETIC_WKT = {
 'convex':'POLYGON ((0 0,40 0,40 40,0 40,0 0))',
 'hole':'POLYGON ((0 0,50 0,50 50,0 50,0 0),(20 20,20 30,30 30,30 20,20 20))',
 'concave':'POLYGON ((0 0,40 0,40 15,15 15,15 40,0 40,0 0))',
 'empty':'POLYGON ((0 0,1 0,1 1,0 1,0 0))',
 'split':'POLYGON ((0 0,12 0,12 5,24 5,24 0,36 0,36 12,24 12,24 6,12 6,12 12,0 12,0 0))'}
KERNEL_SHA256 = '9977d8a7bff6e40c803475427d268343a1941029da44f1501391608e10881bae'

class AuditError(Exception): pass

def require(test, message):
    if not test: raise AuditError(message)

def read(path):
    def bad(v): raise AuditError('NONFINITE_JSON:'+v)
    def unique(items):
        out={}
        for k,v in items:
            require(k not in out, 'DUPLICATE_JSON_KEY:'+k);out[k]=v
        return out
    return json.loads(pathlib.Path(path).read_text(),parse_constant=bad,object_pairs_hook=unique)

def digest(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(1<<20), b''):h.update(chunk)
    return h.hexdigest()

def bsha(b):return hashlib.sha256(b).hexdigest()
def number(x):
    require(type(x) in (int,float), 'NONNUMERIC_COORDINATE_OR_DISTANCE')
    require(math.isfinite(x), 'NONFINITE_COORDINATE_OR_DISTANCE')
    return D(str(x))
def integer(x): return type(x) is int

def distance(a,b):
    with localcontext() as ctx:
        ctx.prec=80
        return sum(((number(a[k])-number(b[k]))**2 for k in (0,1)),D(0)).sqrt()

def rounded(v):
    with localcontext() as ctx:
        ctx.prec=80
        x=number(v);require(x>=0,'NEGATIVE_DISTANCE')
        return int((x*1000).to_integral_value(rounding=ROUND_HALF_UP))

def coords(polys): return [[[[float(v) for v in p] for p in ring] for ring in poly] for poly in polys]
def all_values(polys):return [v for poly in polys for ring in poly for p in ring for v in p]

def inspect_wkt(text):
    p=gx.parse_wkt(text)
    require(all(len(r)>=3 for rs in p for r in rs),'SHORT_RING')
    require(all(math.isfinite(float(v)) for v in all_values(p)),'NONFINITE_WKT')
    return p

def convex(polys):
    if len(polys)!=1 or len(polys[0])!=1:return False
    ring=[tuple(F(v) for v in p) for p in polys[0][0]];signs=set()
    for i,b in enumerate(ring):
        turn=gx.orient(ring[i-1],b,ring[(i+1)%len(ring)])
        if turn:signs.add(1 if turn>0 else -1)
    return len(signs)==1

def ogr_polys(geom):
    if geom.IsEmpty():return []
    kind=geom.GetGeometryName()
    require(kind in ('POLYGON','MULTIPOLYGON'),'UNSUPPORTED_OGR_GEOMETRY:'+kind)
    parts=[geom] if kind=='POLYGON' else [geom.GetGeometryRef(i) for i in range(geom.GetGeometryCount())]
    result=[]
    for part in parts:
        result.append([[[part.GetGeometryRef(r).GetX(k),part.GetGeometryRef(r).GetY(k)]
                         for k in range(part.GetGeometryRef(r).GetPointCount()-1)] for r in range(part.GetGeometryCount())])
    return result

def serialized(polys):
    def poly(rs):return '('+', '.join('('+', '.join(' '.join(repr(v) for v in p) for p in r+[r[0]])+')' for r in rs)+')'
    return ('POLYGON '+poly(polys[0])) if len(polys)==1 else 'MULTIPOLYGON ('+', '.join(poly(p) for p in polys)+')'


def verify_projection(fielddir, row, projected, report):
    # This function is reachable from the formal API only after all launch gates.
    from pyproj import CRS,Transformer,network,__version__ as pyproj_version,proj_version_str
    from osgeo import gdal
    meta=read(fielddir/'projection.json');src=ROOT/'input/wkt'/(row['id']+'.wkt')
    prjpath=ROOT/'input/provenance/NL_2020_source.prj';prj=prjpath.read_text()
    require(digest(src)==row['source_sha256'],'SOURCE_WKT_SHA_MISMATCH')
    require(digest(prjpath)==row['crs_provenance']['source_crs_prj_sha256'],'SOURCE_PRJ_SHA_MISMATCH')
    require(meta['source_crs_wkt']==prj and meta['target_epsg']==row['proposed_utm_epsg'],'PROJECTION_SOURCE_OR_TARGET_MISMATCH')
    require(meta['always_xy'] is True and meta['network_enabled'] is False,'AXIS_OR_NETWORK_MISMATCH')
    require(meta['pyproj_version']==pyproj_version and meta['proj_version']==proj_version_str and meta['gdal_version']==gdal.VersionInfo(),'PROJECTION_VERSION_MISMATCH')
    require(meta['serialization']=='repr binary64 round-trip coordinates; no simplification','PROJECTION_SERIALIZATION_RULE_MISMATCH')
    network.set_network_enabled(False)
    trans=Transformer.from_crs(CRS.from_wkt(prj),CRS.from_epsg(row['proposed_utm_epsg']),always_xy=True)
    require(meta['pipeline']==trans.definition and meta['description']==trans.description,'PROJECTION_PIPELINE_MISMATCH')
    original=inspect_wkt(src.read_text());require(len(original)==1,'SOURCE_NOT_SINGLE_POLYGON')
    expected=[];max_roundtrip=0.0
    for ring in original[0]:
        rr=[]
        for xy in ring:
            a,b=map(float,xy);x,y=trans.transform(a,b,errcheck=True)
            require(math.isfinite(x) and math.isfinite(y),'NONFINITE_PROJECTED_VERTEX')
            lon,lat=trans.transform(x,y,direction='INVERSE',errcheck=True)
            max_roundtrip=max(max_roundtrip,abs(lon-a),abs(lat-b));rr.append([x,y])
        expected.append(rr)
    require(coords(projected)==[expected],'PROJECTED_VERTEX_COORDINATES_OR_ORDER_MISMATCH')
    require((fielddir/'projected.wkt').read_text()==serialized([expected])+'\n','PROJECTED_SERIALIZED_BYTES_MISMATCH')
    counts=[len(r)+1 for r in original[0]]
    require(meta['original_vertex_counts']==meta['projected_vertex_counts']==counts,'PROJECTED_VERTEX_COUNTS_MISMATCH')
    require(max_roundtrip<=1e-8 and meta['maximum_roundtrip_absolute_degrees']==max_roundtrip,'PROJECTION_ROUNDTRIP_MISMATCH')
    require(meta['projected_convex_no_hole']==convex(projected),'PROJECTED_CONVEXITY_LABEL_MISMATCH')
    report['projection']={'status':'PASS','source_wkt_sha256':digest(src),'source_prj_sha256':digest(prjpath),
      'target_epsg':row['proposed_utm_epsg'],'always_xy':True,'maximum_roundtrip_absolute_degrees':max_roundtrip,
      'pipeline':trans.definition,'pyproj_version':pyproj_version,'proj_version':proj_version_str,
      'gdal_version':gdal.VersionInfo(),'projected_convex_no_hole':convex(projected)}


def verify_center(projected_text, center, meta, report):
    # Reproduction uses the same frozen GEOS buffer engine but independent code.
    # It is a numerical construction check, not the exact final safety argument.
    from osgeo import ogr
    ogr.UseExceptions();p=ogr.CreateGeometryFromWkt(projected_text)
    require(p.IsValid() and not p.IsEmpty(),'PROJECTED_GEOMETRY_INVALID')
    amount=(1.1+1e-5)/math.cos(math.pi/32)
    c=p.Buffer(-amount,16);actual=ogr_polys(c)
    require(c.IsValid() and actual==coords(center),'CENTER_BUFFER_COMPONENT_RING_VERTEX_MISMATCH')
    require(meta['buffer_distance_m']==amount and meta['quadrant_segments']==16,'CENTER_BUFFER_PARAMETERS_MISMATCH')
    require(c.Difference(p).IsEmpty(),'CENTER_NOT_WITHIN_P')
    parts=[c] if c.GetGeometryName()=='POLYGON' else [c.GetGeometryRef(i) for i in range(c.GetGeometryCount())]
    require(meta['components']==len(center) and meta['component_holes']==[len(rs)-1 for rs in center],'CENTER_COMPONENT_METADATA_MISMATCH')
    require(meta['component_areas_m2']==[g.GetArea() for g in parts],'CENTER_COMPONENT_AREA_MISMATCH')
    require(meta['center_area_m2']==c.GetArea() and meta['original_area_m2']==p.GetArea(),'CENTER_AREA_MISMATCH')
    minimum=c.Distance(p.Boundary())
    require(minimum>1.1+1e-8 and minimum==meta['minimum_numeric_clearance_m'],'CENTER_NUMERIC_CLEARANCE_MISMATCH')
    require(meta['center_convex_no_hole']==convex(center),'CENTER_CONVEXITY_LABEL_MISMATCH')
    require(meta['center_serialization_roundtrip'] is True and meta['center_vertex_order']=='component, ring, stored coordinate order','CENTER_ORDER_OR_SERIALIZATION_MISMATCH')
    report['center']={'status':'PASS','components':len(center),'holes':[len(rs)-1 for rs in center],
      'all_buffer_components_rings_vertices_byte_roundtrip_preserved':True,'minimum_numeric_clearance_m':minimum,
      'center_convex_no_hole':convex(center),'exact_safety_basis':'independent rational audit of actual full path segments and service endpoints'}


def replay_sampling(fielddir, projected, center, sampling, services, seed, n, report):
    require(sampling['seed']==seed and sampling['n']==n and sampling['target_points_including_depot']==n+1,'SAMPLING_IDENTITY_MISMATCH')
    require(sampling['cap']==100000 and sampling['complete'] is True,'SAMPLING_CAP_OR_COMPLETION_MISMATCH')
    points=[p for rs in coords(projected) for ring in rs for p in ring]
    xmin=min(p[0] for p in points);xmax=max(p[0] for p in points);ymin=min(p[1] for p in points);ymax=max(p[1] for p in points)
    # Fraction coordinates avoid imposing a finite grid scale on future RNG draws.
    cp=[[[tuple(F(x) for x in p) for p in ring] for ring in rs] for rs in center]
    rng=random.Random(seed);accepted=[];seen=set();rows=0;members=[]
    with open(fielddir/'candidate_trace.jsonl') as trace:
        for line in trace:
            rows+=1;require(rows<=100000,'TRACE_EXCEEDS_CAP');require(len(accepted)<n+1,'TRACE_CONTINUES_AFTER_FIRST_ACCEPTED_SET')
            rec=json.loads(line);ux,uy=rng.random(),rng.random()
            xy=[xmin+(xmax-xmin)*ux,ymin+(ymax-ymin)*uy]
            membership=gx.memberships(tuple(F(str(x)) for x in xy),cp,strict=True)
            inside=bool(membership);reason='OUTSIDE_C' if not inside else 'DUPLICATE' if tuple(xy) in seen else 'ACCEPT'
            if reason=='ACCEPT':
                accepted.append({'candidate_index':rows,'coordinate':xy});members.append(membership);seen.add(tuple(xy))
            expected={'candidate_index':rows,'unit_random':[ux,uy],'coordinate':xy,'strict_in_C':inside,'reason':reason,'accepted_rank':len(accepted) if reason=='ACCEPT' else None}
            require(rec==expected,'CANDIDATE_REPLAY_MISMATCH:'+str(rows))
    require(rows==sampling['draws'] and accepted==sampling['accepted'] and len(accepted)==n+1,'FIRST_ACCEPTED_SEQUENCE_MISMATCH')
    require(services['coordinates']==[p['coordinate'] for p in accepted],'SERVICES_DIFFER_FROM_FIRST_ACCEPTED_POINTS')
    require(services['component_membership']==members and all(len(m)==1 for m in members),'SERVICE_COMPONENT_MEMBERSHIP_MISMATCH')
    require(len(set(map(tuple,members)))==1,'DISCONNECTED_SERVICE_COMPONENTS')
    require(services['depot_rule']=='first accepted' and services['field_seed']==seed and services['n']==n,'SERVICE_METADATA_MISMATCH')
    report['sampling']={'status':'PASS','seed':seed,'draws':rows,'cap':100000,'n':n,'bbox':[xmin,xmax,ymin,ymax],
      'first_accepted_depot_and_next_n_tasks':True,'all_components_tested_without_conditioning':True,
      'trace_sha256':digest(fielddir/'candidate_trace.jsonl'),'services_sha256':digest(fielddir/'services.json')}


def shortest(adj,start,base):
    distances=[None]*len(adj);distances[start]=D(0);queue=[(D(0),start)]
    with localcontext() as ctx:
        ctx.prec=80
        while queue:
            cost,u=heapq.heappop(queue)
            if distances[u]!=cost:continue
            if u>=base and u!=start:continue
            for v,w in adj[u]:
                cand=cost+w
                if distances[v] is None or cand<distances[v]:
                    distances[v]=cand;heapq.heappush(queue,(cand,v))
    return distances


def segment_record(a,b,rings,scale, ids=None):
    check=gx.audit_segment(a,b,rings,scale);q=check['q']
    with localcontext() as ctx:
        ctx.prec=80;clearance=(D(q.numerator)/D(q.denominator)).sqrt()
    result={'closed_containment':check['covered'],'clearance_squared_fraction':[str(q.numerator),str(q.denominator)],
      'minimum_clearance_m_decimal80':str(clearance),'exact_safe':check['exact'],'tolerance_label':check['label']}
    if ids is not None:result['node_ids']=list(ids)
    return result


def require_safety_matches(author, independent, label):
    for key in ('closed_containment','clearance_squared_fraction','exact_safe','tolerance_label'):
        require(author[key]==independent[key],label+':'+key)
    require(abs(D(author['minimum_clearance_m_decimal80'])-D(independent['minimum_clearance_m_decimal80']))<=D('1e-70'),label+':clearance_decimal80')
    require(independent['exact_safe'],label+':UNSAFE_EXACT')


def verify_graph(fielddir, projected, center, meta, services, graph, data, n, report):
    N=n+1;points=services['coordinates'];nodes=graph['nodes'];base=graph['base_count']
    require(integer(base) and base>=3 and base<=800 and len(nodes)==base+N and len(nodes)<=821,'GRAPH_NODE_COUNT_MISMATCH')
    require(all(len(p)==2 and all(number(v).is_finite() for v in p) for p in nodes),'GRAPH_COORDINATE_SHAPE')
    require(len(set(map(tuple,nodes)))==len(nodes),'DUPLICATE_GRAPH_NODES')
    flattened=[p for rs in coords(center) for ring in rs for p in ring]
    require(nodes[:base]==flattened and nodes[base:]==points,'GRAPH_CENTER_OR_SERVICE_NODE_ORDER_MISMATCH')
    require(graph['service_node_ids']==list(range(base,base+N)),'GRAPH_SERVICE_NODE_IDS_MISMATCH')
    require(data['coordinates']==points and len(points)==N,'PREPROCESS_SERVICE_COORDINATES_MISMATCH')
    require(data['n']==n and data['K']==1 and data['capacity']==n and data['demands']==[0]+[1]*n,'TSP_ENCODING_METADATA_MISMATCH')
    require(data['interior_service_graph_nodes']==0 and data['length_quantization_bound_m']==N*0.0005,'PATH_RULE_OR_QUANTIZATION_BOUND_MISMATCH')
    ringmap=[];off=0
    for ci,rs in enumerate(center):
        for ri,ring in enumerate(rs):
            ringmap.append({'component':ci,'ring':ri,'nodes':list(range(off,off+len(ring)))});off+=len(ring)
    require(meta['rings']==ringmap and meta['vertices']==base,'CENTER_NODE_RING_MAP_MISMATCH')
    edgelist=graph['edges'];require(graph['edge_count']==len(edgelist),'GRAPH_EDGE_COUNT_MISMATCH')
    require(graph['candidate_edge_checks']==len(nodes)*(len(nodes)-1)//2,'GRAPH_CANDIDATE_CHECK_COUNT_MISMATCH')
    edge={};adj=[[] for _ in nodes];maximum_edge_residual=D(0);prior=(-1,-1)
    for entry in edgelist:
        require(len(entry)==3,'EDGE_SHAPE');u,v,w=entry
        require(integer(u) and integer(v) and 0<=u<v<len(nodes),'EDGE_INDEX_INVALID')
        require((u,v)>prior and (u,v) not in edge,'EDGE_ORDER_OR_DUPLICATION');prior=(u,v)
        require(number(w)>0,'NONPOSITIVE_EDGE_WEIGHT')
        require(w==math.hypot(nodes[u][0]-nodes[v][0],nodes[u][1]-nodes[v][1]),'EDGE_WEIGHT_NOT_FROZEN_HYPOT')
        residual=abs(number(w)-distance(nodes[u],nodes[v]));maximum_edge_residual=max(maximum_edge_residual,residual)
        require(residual<=TOL,'EDGE_GEOMETRIC_LENGTH_RESIDUAL')
        edge[(u,v)]=number(w);adj[u].append((v,number(w)));adj[v].append((u,number(w)))
    require(graph['unreachable_service_pairs']==[],'AUTHOR_UNREACHABLE_PAIRS_ON_PASS')
    paths=data['canonical_paths'];require(len(paths)==N and all(len(r)==N for r in paths),'CANONICAL_PATH_MATRIX_SHAPE')
    for name in ('E','G'):
        for group in ('integer_matrices','unrounded_matrices'):
            mat=data[group][name];require(len(mat)==N and all(len(r)==N for r in mat),'MATRIX_SHAPE:'+group+name)
            for i in range(N):
                for j in range(N):
                    val=mat[i][j];require(number(val)>=0 and val==mat[j][i], 'MATRIX_NEGATIVE_OR_ASYMMETRIC')
                    require(val==0 if i==j else (val>0 if group=='unrounded_matrices' else val>=0),'MATRIX_ZERO_DIAGONAL_OR_POSITIVE_DISTANCE')
                    if group=='integer_matrices':
                        require(integer(val) and val==rounded(data['unrounded_matrices'][name][i][j]),'MATRIX_HALF_UP_MISMATCH:'+name)
    matrices=data['unrounded_matrices'];precise=[['0']*N for _ in range(N)];stored=[['0']*N for _ in range(N)]
    allshort=[]
    for i in range(N):
        ds=shortest(adj,base+i,base)
        require(all(ds[base+j] is not None for j in range(N)),'INDEPENDENT_GRAPH_UNREACHABLE_PAIR')
        allshort.append(ds)
    pairrecords={tuple(p['pair']):p for p in data['pair_checks']}
    require(len(pairrecords)==len(data['pair_checks'])==N*(N-1)//2,'PAIR_CHECK_SET_SIZE_MISMATCH')
    unique=set();passages=[];max_path_residual=D(0);max_shortest_residual=D(0);max_symmetry=D(0);max_e_residual=D(0)
    scale=gx.scale_for(all_values(projected)+all_values(center)+[v for p in nodes for v in p])
    pg=gx.grid_geometry(projected,scale);cg=gx.grid_geometry(center,scale);ng=[gx.grid_point(p,scale) for p in nodes]
    require(len(pg)==1,'PROJECTED_NOT_SINGLE_POLYGON')
    for i in range(N):
        require(paths[i][i]==[base+i],'CANONICAL_DIAGONAL_PATH')
        for j in range(i+1,N):
            path=paths[i][j]
            require(isinstance(path,list) and len(path)>=2 and all(integer(v) and 0<=v<len(nodes) for v in path),'BAD_PATH_NODE_IDS')
            require(path[0]==base+i and path[-1]==base+j and paths[j][i]==path[::-1],'PATH_ENDPOINT_OR_REVERSE_MISMATCH')
            require(len(set(path))==len(path) and all(v<base for v in path[1:-1]),'PATH_REPETITION_OR_SERVICE_TRANSIT')
            with localcontext() as ctx:
                ctx.prec=80;length=D(0);saved_sum=D(0)
                for k,(u,v) in enumerate(zip(path,path[1:])):
                    key=tuple(sorted((u,v)));require(key in edge,'PATH_USES_MISSING_EDGE');unique.add(key)
                    length+=distance(nodes[u],nodes[v]);saved_sum+=edge[key]
                    for t in range(N):
                        if t not in (i,j) and ng[base+t] not in (ng[u],ng[v]) and gx.on(ng[base+t],ng[u],ng[v]):
                            passages.append({'service_leg':[i,j],'segment_index':k,'other_service':t,'event':'GEOMETRIC_PASSAGE_NOT_A_SERVICE_EVENT'})
                residual=length-number(matrices['G'][i][j]);rshort=saved_sum-allshort[i][base+j]
                sym=allshort[i][base+j]-allshort[j][base+i]
                require(abs(residual)<=TOL and abs(rshort)<=TOL and abs(sym)<=TOL and abs(number(matrices['G'][i][j])-allshort[i][base+j])<=TOL and abs(length-allshort[i][base+j])<=TOL,'PATH_MATRIX_OR_NUMERIC_SHORTEST_RESIDUAL')
                max_path_residual=max(max_path_residual,abs(residual));max_shortest_residual=max(max_shortest_residual,abs(rshort));max_symmetry=max(max_symmetry,abs(sym))
                require(matrices['E'][i][j]==math.hypot(points[i][0]-points[j][0],points[i][1]-points[j][1]),'E_MATRIX_HYPOT_MISMATCH')
                er=abs(distance(points[i],points[j])-number(matrices['E'][i][j]));max_e_residual=max(max_e_residual,er);require(er<=TOL,'E_MATRIX_GEOMETRIC_LENGTH_RESIDUAL')
                author=pairrecords.get((i,j));require(author is not None,'PAIR_CHECK_MISSING')
                require(abs(D(author['decimal80_path_length_m'])-length)<=D('1e-70') and author['saved_distance_m']==matrices['G'][i][j] and abs(D(author['residual_m'])-residual)<=D('1e-70'),'AUTHOR_PAIR_CHECK_MISMATCH')
            precise[i][j]=precise[j][i]=str(length);stored[i][j]=stored[j][i]=str(saved_sum)
    require(passages==data['geometric_passages'],'GEOMETRIC_PASSAGE_RECORD_MISMATCH')
    oldsegments={tuple(r['node_ids']):r for r in data['unique_path_segments']}
    require(len(oldsegments)==len(data['unique_path_segments']) and set(oldsegments)==unique,'UNIQUE_USED_SEGMENT_SET_MISMATCH')
    audited=[]
    for u,v in sorted(unique):
        rec=segment_record(ng[u],ng[v],pg[0],scale,(u,v))
        require_safety_matches(oldsegments[(u,v)],rec,'USED_SEGMENT:'+str((u,v)))
        common=set(gx.memberships(ng[u],cg)) & set(gx.memberships(ng[v],cg))
        require(any(gx.contained_segment(ng[u],ng[v],cg[c]) for c in common),'USED_SEGMENT_OUTSIDE_SAVED_C')
        audited.append(rec)
    oldpoints={p['service_id']:p for p in data['endpoint_checks']}
    require(len(oldpoints)==len(data['endpoint_checks'])==N and set(oldpoints)==set(range(N)),'ENDPOINT_CHECK_SET_MISMATCH')
    endpoints=[]
    for i in range(N):
        rec=segment_record(ng[base+i],ng[base+i],pg[0],scale);rec['service_id']=i
        require_safety_matches(oldpoints[i],rec,'SERVICE_ENDPOINT:'+str(i));endpoints.append(rec)
    minimum=min(D(x['minimum_clearance_m_decimal80']) for x in audited+endpoints)
    report.update(n=n,canonical_decimal80_path_length_m=precise,canonical_stored_edge_decimal80_length_m=stored,
      unique_path_segments=audited,endpoint_checks=endpoints,minimum_clearance_m_decimal80=str(minimum),
      geometric_passages=passages,geometric_passage_policy='Geometric crossings never add service visits or delete routes.',
      graph={'status':'PASS','nodes':len(nodes),'edges':len(edge),'service_nodes':N,'base_nodes':base,
       'max_edge_decimal80_length_residual_m':str(maximum_edge_residual),'max_E_decimal80_length_residual_m':str(max_e_residual),
       'max_saved_path_matrix_residual_m':str(max_path_residual),'max_stored_edge_shortest_residual_m':str(max_shortest_residual),
       'max_decimal80_shortest_asymmetry_m':str(max_symmetry),'shortest_scope':'Decimal80 numerical distances on saved finite graph; other service nodes terminal-only; no continuous-plane optimality claim.',
       'all_used_full_segments_and_endpoints_exact_safe':True,'E_and_G_use_same_legal_canonical_realizations':True})
    inputs={p['objective']:p for p in read(fielddir/'FIELD_FINISHED.json')['inputs']}
    require(len(inputs)==2 and set(inputs)=={'E_G','G_E'},'DP_INPUT_SET_MISMATCH')
    report['verified_dp_inputs']={}
    for arm in ('E_G','G_E'):
        path=fielddir/(arm+'.txt')
        expected='HKLEX_V1 '+str(n)+' '+arm+'\n'+'\n'.join(' '.join(map(str,r)) for name in ('E','G') for r in data['integer_matrices'][name])+'\n'
        require(path.read_text()==expected,'DP_INPUT_MATRIX_BYTES_MISMATCH:'+arm)
        require(inputs[arm]['filename']==path.name and inputs[arm]['sha256']==digest(path),'DP_INPUT_RECORDED_SHA_MISMATCH')
        report['verified_dp_inputs'][arm]={'path':str(path),'sha256':digest(path),'bytes':path.stat().st_size}


def audit_payload(fielddir, field_id, n, seed, projected_text, formal_row=None):
    started=time.monotonic();cpu=time.process_time()
    report={'status':'NOT_VERIFIED','field_id':field_id,'errors':[],'n':n,'synthetic_only':formal_row is None,
      'author_planner_imports':False,'TSP_calls':0,'graph_construction_calls':0,'hashes':{}}
    try:
        require(digest(pathlib.Path(__file__).with_name('geometry_exact.py'))==KERNEL_SHA256,'INDEPENDENT_GEOMETRY_KERNEL_CHANGED')
        finished=read(fielddir/'FIELD_FINISHED.json');report['owner_status']=finished.get('status')
        if finished.get('status')!='PASS_PREPROCESS':
            report['reason']='NO_OWNER_PASS_PREPROCESS; preserve slot, no replacement, no mathematical infeasibility claim'
            return report
        for p in fielddir.iterdir():
            if p.is_file():report['hashes'][p.name]={'sha256':digest(p),'bytes':p.stat().st_size}
        projected=inspect_wkt(projected_text);center=inspect_wkt((fielddir/'center.wkt').read_text())
        meta=read(fielddir/'center_metadata.json');sampling=read(fielddir/'sampling.json');services=read(fielddir/'services.json')
        graph=read(fielddir/'graph.json');data=read(fielddir/'preprocess.json')
        require(meta['status']=='CENTER_NUMERIC_PASS' and data['status']=='PASS_PREPROCESS' and finished['n']==n,'INCONSISTENT_OWNER_PASS')
        expected_id=field_id if formal_row is not None else 'synthetic_'+field_id
        require(services['instance_id']==data['instance_id']==expected_id,'INSTANCE_ID_MISMATCH')
        if formal_row is not None:verify_projection(fielddir,formal_row,projected,report)
        else:report['projection']={'status':'SYNTHETIC_METRIC_LITERAL_ONLY','formal_projection_validation':False,'wkt_sha256':bsha(projected_text.encode())}
        verify_center(projected_text,center,meta,report)
        require((fielddir/'center.wkt').read_text()==serialized(coords(center))+'\n','CENTER_SERIALIZED_BYTES_MISMATCH')
        replay_sampling(fielddir,projected,center,sampling,services,seed,n,report)
        verify_graph(fielddir,projected,center,meta,services,graph,data,n,report)
        report['status']='PASS_INPUT_AUDIT' if formal_row is not None else 'PASS_SYNTHETIC_INPUT_AUDIT'
    except Exception as e:
        report['errors'].append(str(e));report['exception_type']=type(e).__name__
        report['traceback']=traceback.format_exc()
    finally:
        report['wall_seconds']=time.monotonic()-started;report['cpu_seconds']=time.process_time()-cpu
        report['maxrss_kib']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    return report


def audit_synthetic(fielddir, field_id):
    fielddir=pathlib.Path(fielddir).resolve()
    require(field_id in SYNTHETIC_WKT and fielddir.name==field_id,'SYNTHETIC_FIXED_ID_REQUIRED')
    require(fielddir.is_relative_to(ROOT/'selftests') or fielddir.is_relative_to(ROOT/'independent_supervision/selftests'),'SYNTHETIC_FIXTURE_PATH_REQUIRED')
    require(read(fielddir/'FIELD_FINISHED.json').get('synthetic_only') is True,'EXPLICIT_SYNTHETIC_MARKER_REQUIRED')
    require(not (fielddir/'projection.json').exists() and not (fielddir/'projected.wkt').exists(),'NO_REAL_PROJECTION_IN_SYNTHETIC_API')
    return audit_payload(fielddir,field_id,4,991,SYNTHETIC_WKT[field_id])


def formal_gate(field_id):
    freeze=ROOT/'freeze/FROZEN_FILES.json';freeze_sha=digest(freeze);frozen=read(freeze)
    for rel,meta in frozen['files'].items():
        p=(ROOT/rel).resolve();require(p.is_relative_to(ROOT),'FROZEN_PATH_ESCAPE')
        require(p.stat().st_size==meta['bytes'] and digest(p)==meta['sha256'],'FROZEN_FILE_MISMATCH:'+rel)
    for p in (pathlib.Path(__file__).resolve(),pathlib.Path(__file__).with_name('geometry_exact.py').resolve()):
        require(str(p.relative_to(ROOT)) in frozen['files'],'INDEPENDENT_SOURCE_NOT_FROZEN')
    rp=ROOT/'provenance/RAW_MAIN_DRIVE_RECEIPT.json';ap=ROOT/'provenance/PARENT_VERIFICATION_APPROVAL.json'
    lp=ROOT/'independent_supervision/VALIDATION_LAUNCH_STARTED.json'
    receipt=read(rp);approval=read(ap);launch=read(lp)
    require(not receipt.get('synthetic_only') and receipt.get('stage')=='RAW_MAIN','REAL_RAW_MAIN_RECEIPT_REQUIRED')
    require(all(receipt.get(k) is True for k in ('verified','owner_only','remote_readback_sha256_verified','download_byte_identical')) and receipt.get('shared') is False,'PRIVATE_ACTUAL_BYTE_READBACK_REQUIRED')
    require(receipt.get('sha256')==receipt.get('download_sha256') and receipt.get('frozen_files_sha256')==freeze_sha,'RECEIPT_HASH_BINDING_MISMATCH')
    require(approval.get('approved') is True and approval.get('frozen_files_sha256')==freeze_sha and approval.get('raw_main_archive_sha256')==receipt['sha256'] and approval.get('verification_calls')==24 and approval.get('input_audit_fields')==12,'ROOT_INPUT_VALIDATION_WINDOW_REQUIRED')
    require(launch.get('frozen_files_sha256')==freeze_sha and launch.get('raw_main_archive_sha256')==receipt['sha256'] and launch.get('raw_main_receipt_sha256')==digest(rp) and launch.get('verification_approval_sha256')==digest(ap),'LAUNCH_HASH_BINDING_MISMATCH')
    require(launch.get('planned_fields')==12 and launch.get('planned_verification_calls')==24 and launch.get('raw_members_verified') is True,'ACTIVE_VALIDATION_LAUNCH_REQUIRED')
    rows=read(ROOT/'input/provenance/PANEL_SOURCE_READY_PROPOSAL.json')['candidates'];require(len(rows)==12,'FIXED_PANEL_SIZE')
    row=next((r for r in rows if r['id']==field_id),None);require(row is not None,'FIELD_NOT_IN_FIXED_PANEL')
    require(row['fixed_task_seed']==int.from_bytes(hashlib.sha256(('cross_field_v1|'+field_id).encode()).digest()[:8],'big'),'FIXED_SHA_SEED_MISMATCH')
    fielddir=ROOT/'raw/fields'/field_id
    archive=pathlib.Path(receipt['download_path']);require(archive.is_file(),'ACTUAL_READBACK_ZIP_MISSING')
    # Parent has hashed the complete archive and all members once. Recheck the
    # actual ZIP bytes for this field, source and manifest before using them.
    mp=ROOT/'raw/RAW_MAIN_CONTENT_MANIFEST.json';manifest=read(mp);require(manifest['frozen_files_sha256']==freeze_sha,'RAW_MANIFEST_FREEZE_MISMATCH')
    with zipfile.ZipFile(archive) as z:
        names=z.namelist();require(len(names)==len(set(names)),'DUPLICATE_ARCHIVE_MEMBERS')
        require(z.read('freeze/FROZEN_FILES.json')==freeze.read_bytes(),'ZIP_FREEZE_BYTES_MISMATCH')
        require(z.read('raw/RAW_MAIN_CONTENT_MANIFEST.json')==mp.read_bytes(),'ZIP_RAW_MANIFEST_BYTES_MISMATCH')
        expected={rel for rel in manifest['files'] if rel.startswith('raw/fields/'+field_id+'/')}
        actual={str(p.relative_to(ROOT)) for p in fielddir.rglob('*') if p.is_file()}
        require(expected==actual,'FIELD_MEMBER_SET_MISMATCH')
        for rel in expected:
            p=ROOT/rel;meta=manifest['files'][rel]
            require(p.stat().st_size==meta['bytes'] and digest(p)==meta['sha256'] and z.read(rel)==p.read_bytes(),'FIELD_MEMBER_BYTE_IDENTITY_MISMATCH:'+rel)
        for rel in ('input/wkt/'+field_id+'.wkt','input/provenance/NL_2020_source.prj','input/provenance/PANEL_SOURCE_READY_PROPOSAL.json'):
            require(z.read(rel)==(ROOT/rel).read_bytes(),'ZIP_INPUT_BYTES_MISMATCH:'+rel)
    return fielddir,row,{'frozen_files_sha256':freeze_sha,'raw_main_archive_sha256':receipt['sha256'],
      'raw_main_receipt_sha256':digest(rp),'verification_approval_sha256':digest(ap),'validation_launch_sha256':digest(lp),
      'raw_manifest_sha256':digest(mp),'field_members_byte_verified':len(expected)}


def main():
    require(len(sys.argv)==3,'USAGE: check_field.py <field_id> <output_json>')
    field_id=sys.argv[1];output=pathlib.Path(sys.argv[2]).resolve()
    require(output.is_relative_to(ROOT/'independent_supervision') and not output.is_relative_to(ROOT/'independent_supervision/source'),'AUDIT_OUTPUT_MUST_BE_UNDER_INDEPENDENT_SUPERVISION')
    require(not output.exists(),'AUDIT_OUTPUT_ALREADY_EXISTS_NO_RETRY')
    resource.setrlimit(resource.RLIMIT_AS,(1073741824,1073741824));resource.setrlimit(resource.RLIMIT_CPU,(120,120))
    signal.signal(signal.SIGALRM,lambda *_: (_ for _ in ()).throw(AuditError('INPUT_AUDIT_WALL_LIMIT_180S')));signal.alarm(180)
    start=time.monotonic();cpu=time.process_time();binding=None
    try:
        fielddir,row,binding=formal_gate(field_id)
        finish=read(fielddir/'FIELD_FINISHED.json')
        projected=(fielddir/'projected.wkt').read_text() if finish.get('status')=='PASS_PREPROCESS' else ''
        result=audit_payload(fielddir,field_id,20,row['fixed_task_seed'],projected,row)
    except Exception as e:
        result={'status':'NOT_VERIFIED','field_id':field_id,'errors':[str(e)],'exception_type':type(e).__name__,'traceback':traceback.format_exc(),'synthetic_only':False}
    finally:signal.alarm(0)
    result['gate_binding']=binding;result['total_worker_wall_seconds']=time.monotonic()-start;result['total_worker_cpu_seconds']=time.process_time()-cpu
    result['source_sha256']=digest(__file__);result['geometry_kernel_sha256']=digest(pathlib.Path(__file__).with_name('geometry_exact.py'))
    result['limits']={'cpu_seconds':120,'wall_seconds':180,'as_bytes':1073741824}
    output.parent.mkdir(parents=True,exist_ok=True)
    with output.open('x') as f:json.dump(result,f,indent=2,allow_nan=False);f.write('\n')
    print(json.dumps({'status':result['status'],'field_id':field_id,'output':str(output),'errors':result['errors']}))
    return 0 if result['status']=='PASS_INPUT_AUDIT' else 4

if __name__=='__main__':sys.exit(main())
