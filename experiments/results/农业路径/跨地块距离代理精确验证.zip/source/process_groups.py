"""Linux child-registration and bounded group quiescence, including supervisor death."""
import ctypes,json,os,pathlib,signal,time

def identity(pid):
    try:
        fields=pathlib.Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()
        return {'pid':pid,'state':fields[0],'pgrp':int(fields[2]),'session':int(fields[3]),'start_ticks':int(fields[19])}
    except FileNotFoundError:return None

def members(pgrp):
    found=[]
    for p in pathlib.Path('/proc').iterdir():
        if p.name.isdigit():
            try:x=identity(int(p.name))
            except(ProcessLookupError,PermissionError):continue
            if x and x['pgrp']==pgrp and x['state']!='Z':found.append(x)
    return found

def child_register(parent_pid,path=None):
    # Fork-to-registration race is closed by PDEATHSIG plus the parent-PID check.
    libc=ctypes.CDLL(None,use_errno=True)
    if libc.prctl(1,signal.SIGKILL,0,0,0)!=0:raise OSError(ctypes.get_errno(),'prctl PDEATHSIG failed')
    if os.getppid()!=parent_pid:os._exit(125)
    x=identity(os.getpid())
    if x is None or x['pgrp']!=x['pid']or x['session']!=x['pid']:raise RuntimeError('Child is not isolated session leader')
    x['parent_pid']=parent_pid
    if path is not None:
        with open(path,'x')as f:json.dump(x,f);f.flush();os.fsync(f.fileno())

def cleanup_record(record):
    leader=identity(record['pid'])
    if leader is not None and leader['start_ticks']!=record['start_ticks']:
        # A reused leader PID means the original process group no longer exists.
        return {'quiescent':True,'action':'ORIGINAL_GROUP_GONE_PID_REUSED','remaining':[]}
    try:os.killpg(record['pgrp'],signal.SIGKILL)
    except ProcessLookupError:pass
    remaining=[]
    for _ in range(100):
        remaining=members(record['pgrp'])
        if not remaining:break
        time.sleep(.01)
    return {'quiescent':not remaining,'action':'SIGKILL_GROUP_AND_VERIFY_NO_NONZOMBIE_MEMBERS','remaining':remaining}

def cleanup_registered(directory):
    results=[]
    if pathlib.Path(directory).exists():
        for p in sorted(pathlib.Path(directory).glob('*.active.json')):
            record=json.loads(p.read_text());closed=p.with_name(p.name.replace('.active.json','.closed.json'))
            result=json.loads(closed.read_text())if closed.exists()else cleanup_record(record)
            results.append({'registration':p.name,**result})
    return {'quiescent':all(x['quiescent']for x in results),'groups':results}
