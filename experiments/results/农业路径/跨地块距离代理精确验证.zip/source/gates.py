"""All externally issued receipts/approvals are read-only. This module never creates authorization."""
import hashlib,pathlib,zipfile,os
from common import ROOT,read,sha,verify_map

def frozen():
 p=ROOT/'freeze/FROZEN_FILES.json';verify_map(ROOT,read(p)['files']);return sha(p)
def receipt(path,stage,digest):
 r=read(path)
 if r.get('synthetic_only'):raise RuntimeError('SYNTHETIC_RECEIPT_NOT_AUTHORIZATION')
 if r.get('stage')!=stage:raise RuntimeError('WRONG_RECEIPT_STAGE')
 if not all(r.get(k)is True for k in('verified','owner_only','remote_readback_sha256_verified','download_byte_identical'))or r.get('shared')is not False:raise RuntimeError('ARCHIVE_NOT_VERIFIED_PRIVATE')
 if r.get('sha256')!=r.get('download_sha256')or r.get('frozen_files_sha256')!=digest:raise RuntimeError('ARCHIVE_HASH_OR_FREEZE_MISMATCH')
 for k in('source','download_path'):
  if not pathlib.Path(r[k]).is_file()or sha(r[k])!=r['sha256']:raise RuntimeError('ACTUAL_ARCHIVE_BYTES_MISMATCH')
 with zipfile.ZipFile(r['download_path'])as z:
  if hashlib.sha256(z.read('freeze/FROZEN_FILES.json')).hexdigest()!=digest:raise RuntimeError('ARCHIVE_EMBEDDED_FREEZE_MISMATCH')
  for rel,v in read(ROOT/'freeze/FROZEN_FILES.json')['files'].items():
   b=z.read(rel)
   if len(b)!=v['bytes']or hashlib.sha256(b).hexdigest()!=v['sha256']:raise RuntimeError('ARCHIVE_FROZEN_MEMBER_MISMATCH:'+rel)
 return r

def main_ready():
 d=frozen();r=receipt(ROOT/'provenance/PREEXEC_DRIVE_RECEIPT.json','PREEXEC',d);a=read(ROOT/'provenance/PARENT_MAIN_APPROVAL.json')
 if a.get('approved')is not True or a.get('frozen_files_sha256')!=d or a.get('preexec_archive_sha256')!=r['sha256']or a.get('preprocess_fields')!=12 or a.get('main_calls')!=24 or a.get('verification_calls')!=24:raise RuntimeError('PARENT_HASH_BOUND_APPROVAL_REQUIRED')
 q=read(ROOT/'freeze/INDEPENDENT_PRECHECK.json')
 if q.get('status')!='PASS':raise RuntimeError('INDEPENDENT_PRECHECK_REQUIRED')
 if not isinstance(q.get('reviewed_files'),dict)or not q['reviewed_files']:raise RuntimeError('PRECHECK_FILE_BINDING_REQUIRED')
 verify_map(ROOT,q['reviewed_files'])
 if not os.access(ROOT/'source/hklex',os.X_OK):raise RuntimeError('VERIFIED_BINARY_NOT_EXECUTABLE')
 return d

def active_main_gate():
 d=main_ready();a=read(ROOT/'provenance/MAIN_LAUNCH_STARTED.json')
 if a.get('frozen_files_sha256')!=d or a.get('planned_fields')!=12 or a.get('planned_main_calls')!=24:raise RuntimeError('ACTIVE_UNIQUE_LAUNCH_REQUIRED')
 return d

def verification_ready():
 d=frozen();r=receipt(ROOT/'provenance/RAW_MAIN_DRIVE_RECEIPT.json','RAW_MAIN',d);a=read(ROOT/'provenance/PARENT_VERIFICATION_APPROVAL.json')
 if a.get('approved')is not True or a.get('frozen_files_sha256')!=d or a.get('raw_main_archive_sha256')!=r['sha256']or a.get('verification_calls')!=24 or a.get('input_audit_fields')!=12:raise RuntimeError('INDEPENDENT_WINDOW_APPROVAL_REQUIRED')
 return d
