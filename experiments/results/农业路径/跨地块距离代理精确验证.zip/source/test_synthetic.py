"""Independent permutation oracle, synthetic inputs only. Full attempt outputs retained."""
import itertools,json,math,pathlib,random,sys,time
from bounded import run
ROOT=pathlib.Path(__file__).resolve().parents[1]
def write(path,n,E,G,arm):
    path.write_text('HKLEX_V1 '+str(n)+' '+arm+'\n'+'\n'.join(' '.join(map(str,row))for M in(E,G)for row in M)+'\n')
def costs(E,G,r):return tuple(sum(M[a][b]for a,b in zip(r,r[1:]))for M in(E,G))
def oracle(E,G,arm):
    n=len(E)-1;best=None
    for perm in itertools.permutations(range(1,n+1)):
        val=costs(E,G,(0,)+perm+(0,)); val=val if arm=='E_G'else val[::-1]
        if best is None or val<best:best=val
    return best

def main():
    dest=ROOT/'selftests'/sys.argv[1];dest.mkdir(exist_ok=False)
    rng=random.Random(202610090249);cases=[]
    for n in range(1,9):
        for typ in ('uniform','integer_pair','primary_ties'):
            E=[[0]*(n+1)for _ in range(n+1)];G=[[0]*(n+1)for _ in range(n+1)]
            for i in range(n+1):
                for j in range(i+1,n+1):
                    E[i][j]=E[j][i]=7 if typ in('uniform','primary_ties')else rng.randrange(0,25)
                    G[i][j]=G[j][i]=11 if typ=='uniform'else rng.randrange(0,25)
            cases.append((f'n{n}_{typ}',n,E,G,None))
    INF=(2**63-1)//4
    v=(INF-1)//2
    cases.append(('near_integer_bound',1,[[0,v],[v,0]],[[0,v-1],[v-1,0]],None))
    # Known n=20 uniform objective. Exercises same supervisor, array size and limits.
    n=20;E=[[0 if i==j else 7 for j in range(n+1)]for i in range(n+1)];G=[[0 if i==j else 11 for j in range(n+1)]for i in range(n+1)]
    cases.append(('n20_resource_uniform',n,E,G,(147,231)))
    rows=[]
    for ident,n,E,G,known in cases:
        for arm in ('E_G','G_E'):
            cid=ident+'_'+arm;p=dest/(cid+'.txt');write(p,n,E,G,arm)
            row={'id':cid,'n':n,'objective':arm,**run(ROOT/'source/hklex',p,dest/(cid+'.stdout'),dest/(cid+'.stderr'))}
            if row['returncode']==0:
                got=json.loads((dest/(cid+'.stdout')).read_text());expect=oracle(E,G,arm)if known is None else(known if arm=='E_G'else known[::-1])
                r=got['route']; valid=(r[0]==r[-1]==0 and sorted(r[1:-1])==list(range(1,n+1)))
                e,g=costs(E,G,r)
                checks={'optimal_pair':tuple((got['primary'],got['secondary']))==expect,'route_valid':valid,'route_costs':(got['E'],got['G'])==(e,g),'pair_mapping':(got['primary'],got['secondary'])==((e,g)if arm=='E_G'else(g,e)),'canonical_reverse':r<=r[::-1],'states':got['valid_states']==n*2**(n-1),'transitions':got['internal_transitions']==(n*(n-1)*2**(n-2)if n>1 else 0),'state_layers':got['states_by_cardinality']==[0]+[math.comb(n,k)*k for k in range(1,n+1)],'transition_layers':got['transitions_by_cardinality']==[0]+[math.comb(n,k)*k*(k-1)for k in range(1,n+1)],'limits_inherited':got['rlimit_as']==[536870912]*2 and got['rlimit_cpu']==[60]*2,'array_bytes':got['array_bytes']==17*n*2**n}
                row.update(checks=checks,expected=expect,output=got,pass_case=all(checks.values()))
            else:row['pass_case']=False
            rows.append(row)
            with(dest/'progress.jsonl').open('a')as f:f.write(json.dumps(row)+'\n')
    bad=[('n0','HKLEX_V1 0 E_G\n'),('n21','HKLEX_V1 21 E_G\n'),('bad_header','X 1 E_G\n'),('missing','HKLEX_V1 1 E_G\n0'),('negative','HKLEX_V1 1 E_G\n0 -1 -1 0\n0 1 1 0\n'),('asymmetric','HKLEX_V1 1 E_G\n0 1 2 0\n0 1 1 0\n'),('diagonal','HKLEX_V1 1 E_G\n1 1 1 0\n0 1 1 0\n'),('extra','HKLEX_V1 1 E_G\n0 1 1 0\n0 1 1 0\nEXTRA\n'),('overflow','HKLEX_V1 1 E_G\n0 '+str(INF//2+1)+' '+str(INF//2+1)+' 0\n0 1 1 0\n'),('integer_parse_overflow','HKLEX_V1 1 E_G\n0 999999999999999999999999999 1 0\n0 1 1 0\n')]
    for ident,data in bad:
        p=dest/(ident+'.txt');p.write_text(data);row={'id':ident,**run(ROOT/'source/hklex',p,dest/(ident+'.stdout'),dest/(ident+'.stderr'))};row['pass_case']=row['returncode']==2 and bool((dest/(ident+'.stderr')).read_text());rows.append(row)
    report={'status':'PASS'if all(r['pass_case']for r in rows)else'FAIL','all_cases':len(rows),'synthetic_optimization_calls':2*len(cases),'input_rejection_calls':len(bad),'production_calls':0,'known_n20_resource_calls':2,'rows':rows}
    (dest/'REPORT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='rows'}))
    if report['status']!='PASS':raise RuntimeError('Synthetic validation failure')
if __name__=='__main__':main()
