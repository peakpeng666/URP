"""Whole-process wall-bound report wrapper; no numerical optimization."""
import resource
from common import ROOT,save,utc
from tree_runtime import run_command
from gates import frozen,receipt

def main():
 resource.setrlimit(resource.RLIMIT_CPU,(20,60));resource.setrlimit(resource.RLIMIT_AS,(268435456,536870912));d=frozen();receipt(ROOT/'provenance/RAW_MAIN_DRIVE_RECEIPT.json','RAW_MAIN',d);receipt(ROOT/'provenance/RAW_VERIFICATION_DRIVE_RECEIPT.json','RAW_VERIFICATION',d)
 save(ROOT/'provenance/REPORT_STARTED.json',dict(utc=utc(),frozen_files_sha256=d));r=run_command(['/usr/bin/python3',ROOT/'source/report.py'],ROOT/'provenance/report_process',60,536870912,120,ROOT/'provenance/report_process.active.json');save(ROOT/'provenance/REPORT_PROCESS_FINISHED.json',r)
 if r['status']!='UNREVIEWED_PROCESS_SUCCESS':raise RuntimeError('REPORT_FAILED_EVIDENCE_RETAINED')
if __name__=='__main__':main()
