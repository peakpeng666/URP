// Original implementation for this experiment; no external source dependency.
// Held--Karp over client subsets, minimizing an ordered pair lexicographically.
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
#include <sys/resource.h>
#include <vector>

using I = std::int64_t;
constexpr I INF = std::numeric_limits<I>::max() / 4;
struct Pair { I a, b; };
bool less_pair(Pair x, Pair y) { return x.a < y.a || (x.a == y.a && x.b < y.b); }
void require(bool ok, const char* msg) { if (!ok) throw std::runtime_error(msg); }
int main() {
 try {
  const auto start = std::chrono::steady_clock::now();
  std::string magic, arm; int n = -1;
  require(bool(std::cin >> magic >> n >> arm), "MISSING_HEADER");
  require(magic == "HKLEX_V1" && (arm == "E_G" || arm == "G_E"), "BAD_HEADER");
  require(n >= 1 && n <= 20, "N_OUT_OF_RANGE_1_20");
  const int N = n + 1; std::vector<I> E(N*N), G(N*N); I maximum = 0;
  for (auto* M : {&E, &G}) for (I& v : *M) {
   require(bool(std::cin >> v), "MISSING_OR_INVALID_INTEGER");
   require(v >= 0 && v < INF, "EDGE_OUT_OF_RANGE"); maximum = std::max(maximum, v);
  }
  std::string extra; require(!(std::cin >> extra), "EXTRA_INPUT");
  // Division avoids overflow while validating every possible partial/closed sum.
  require(maximum <= (INF-1)/N, "TOUR_BOUND_EXCEEDS_INF");
  for (const auto* M : {&E, &G}) for (int i=0; i<N; ++i) for (int j=0; j<N; ++j) {
   require((*M)[i*N+j] == (*M)[j*N+i], "ASYMMETRIC_MATRIX");
   require(i != j || (*M)[i*N+j] == 0, "NONZERO_DIAGONAL");
  }
  const auto& A = arm == "E_G" ? E : G;
  const auto& B = arm == "E_G" ? G : E;
  const std::uint32_t masks = std::uint32_t(1) << n;
  const std::size_t slots = std::size_t(masks)*n;
  std::vector<I> a(slots, INF), b(slots, INF);
  std::vector<std::uint8_t> pred(slots, 255);
  std::vector<std::uint64_t> states(n+1,0), transitions(n+1,0);
  std::uint64_t total_states=0, total_transitions=0;
  for (std::uint32_t mask=1; mask<masks; ++mask) {
   const int card = __builtin_popcount(mask);
   std::uint32_t remaining = mask;
   while (remaining) {
    const int j = __builtin_ctz(remaining); remaining &= remaining-1;
    const std::uint32_t previous = mask ^ (std::uint32_t(1)<<j);
    const std::size_t here = std::size_t(mask)*n+j;
    Pair best{INF,INF}; std::uint8_t previous_node=255;
    if (!previous) { best={A[j+1],B[j+1]}; previous_node=254; }
    else {
     std::uint32_t ks=previous;
     while (ks) {
      const int k=__builtin_ctz(ks); ks &= ks-1;
      const std::size_t there = std::size_t(previous)*n+k;
      // Every enumerated predecessor contains k and was processed already.
      require(a[there] < INF && b[there] < INF, "UNREACHABLE_PREDECESSOR");
      const Pair candidate{a[there]+A[(k+1)*N+j+1],b[there]+B[(k+1)*N+j+1]};
      if (less_pair(candidate,best)) { best=candidate; previous_node=std::uint8_t(k); }
      ++transitions[card]; ++total_transitions;
     }
    }
    require(best.a < INF && best.b < INF && previous_node != 255, "UNFILLED_STATE");
    a[here]=best.a; b[here]=best.b; pred[here]=previous_node;
    ++states[card]; ++total_states;
   }
  }
  Pair optimum{INF,INF}; int endpoint=-1;
  for(int j=0;j<n;++j) {
   const std::size_t ix=std::size_t(masks-1)*n+j;
   Pair candidate{a[ix]+A[(j+1)*N],b[ix]+B[(j+1)*N]};
   if(less_pair(candidate,optimum)) { optimum=candidate; endpoint=j; }
  }
  require(endpoint>=0 && optimum.a<INF && optimum.b<INF,"NO_TOUR");
  std::vector<int> reverse_nodes; std::uint32_t mask=masks-1; int j=endpoint;
  while(mask) {
   require(j>=0 && j<n && bool(mask&(std::uint32_t(1)<<j)),"INVALID_BACKTRACK_NODE");
   reverse_nodes.push_back(j+1);
   const auto p=pred[std::size_t(mask)*n+j]; mask ^= std::uint32_t(1)<<j;
   if (!mask) require(p==254,"INVALID_BASE_PREDECESSOR");
   else require(p<n && bool(mask&(std::uint32_t(1)<<p)),"INVALID_PREDECESSOR");
   j=p;
  }
  std::reverse(reverse_nodes.begin(),reverse_nodes.end());
  std::vector<int> route{0}; route.insert(route.end(),reverse_nodes.begin(),reverse_nodes.end()); route.push_back(0);
  auto sum=[N](const std::vector<I>& M,const std::vector<int>& r) { I t=0;for(std::size_t i=1;i<r.size();++i)t+=M[r[i-1]*N+r[i]];return t; };
  const I old_E=sum(E,route), old_G=sum(G,route);
  require(sum(A,route)==optimum.a && sum(B,route)==optimum.b,"BACKTRACK_COST_MISMATCH");
  std::vector<int> canonical(route.rbegin(),route.rend()); if(canonical<route) route=canonical;
  require(sum(E,route)==old_E && sum(G,route)==old_G,"CANONICALIZATION_CHANGED_COST");
  auto sorted=route; std::sort(sorted.begin(),sorted.end());
  require(sorted.size()==std::size_t(n+2) && sorted[0]==0 && sorted[1]==0,"BAD_DEPOT_VISITS");
  for(int i=1;i<=n;++i)require(sorted[i+1]==i,"BAD_CLIENT_VISITS");
  const std::uint64_t expected_states=std::uint64_t(n)*(std::uint64_t(1)<<(n-1));
  const std::uint64_t expected_transitions=n==1 ? 0 : std::uint64_t(n)*(n-1)*(std::uint64_t(1)<<(n-2));
  require(total_states==expected_states && total_transitions==expected_transitions,"STATE_COVERAGE_MISMATCH");
  rusage usage{}; require(getrusage(RUSAGE_SELF,&usage)==0,"GETRUSAGE_FAILED");
  rlimit cpu{},as{};require(getrlimit(RLIMIT_CPU,&cpu)==0 && getrlimit(RLIMIT_AS,&as)==0,"GETRLIMIT_FAILED");
  const double wall=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
  std::cout << "{\"status\":\"EXACT_ALGORITHM_COMPLETED_UNREVIEWED\",\"algorithm\":\"held_karp_lex_pair_v1\",\"n\":" << n << ",\"objective\":\"" << arm << "\",\"primary\":" << optimum.a << ",\"secondary\":" << optimum.b << ",\"E\":" << old_E << ",\"G\":" << old_G << ",\"route\":[";
  for(std::size_t i=0;i<route.size();++i)std::cout<<(i?",":"")<<route[i];
  std::cout<<"],\"valid_states\":"<<total_states<<",\"internal_transitions\":"<<total_transitions<<",\"base_candidates\":"<<n<<",\"closure_candidates\":"<<n<<",\"dense_slots\":"<<slots<<",\"array_bytes\":"<<slots*17<<",\"states_by_cardinality\":[";
  for(int i=0;i<=n;++i)std::cout<<(i?",":"")<<states[i];
  std::cout<<"],\"transitions_by_cardinality\":[";
  for(int i=0;i<=n;++i)std::cout<<(i?",":"")<<transitions[i];
  std::cout<<"],\"rlimit_cpu\":["<<cpu.rlim_cur<<","<<cpu.rlim_max<<"],\"rlimit_as\":["<<as.rlim_cur<<","<<as.rlim_max<<"],\"maxrss_kib\":"<<usage.ru_maxrss<<",\"self_cpu_seconds\":"<<(usage.ru_utime.tv_sec+usage.ru_stime.tv_sec+(usage.ru_utime.tv_usec+usage.ru_stime.tv_usec)/1e6)<<",\"self_wall_seconds\":"<<wall<<",\"full_dp_table_retained\":false}\n";
  return 0;
 } catch(const std::bad_alloc&) { std::cerr<<"MEMORY_ALLOCATION_FAILED\n";return 3;
 } catch(const std::exception& error) { std::cerr<<error.what()<<"\n";return 2; }
}
