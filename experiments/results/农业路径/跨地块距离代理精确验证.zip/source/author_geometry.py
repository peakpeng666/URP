"""Author exact serialized-coordinate segment checks; no graph or order optimizer."""
import sys,re
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal,localcontext
sys.path.insert(0,str(Path(__file__).parent/'upstream'))
from geometry import intersection_parameters,on_segment,covered_point

def rational(p):return tuple(F(str(v)) for v in p)
def rings_from_wkt(text):
    rings=[[tuple(F(v) for v in pair.split()) for pair in part.split(',')] for part in re.findall(r'\(([^()]+)\)',text)]
    assert all(r[0]==r[-1] for r in rings)
    return [r[:-1] for r in rings]
def all_edges(rings):return [(a,b) for r in rings for a,b in zip(r,r[1:]+r[:1])]
def contains(p,rings):
    if any(on_segment(p,a,b) for a,b in all_edges(rings)):return True
    return covered_point(p,rings[0]) and not any(covered_point(p,r) for r in rings[1:])
def contained(a,b,rings):
    if not contains(a,rings) or not contains(b,rings):return False
    cuts={F(0),F(1)}
    for c,d in all_edges(rings):cuts.update(intersection_parameters(a,b,c,d))
    cuts=sorted(cuts)
    return all(contains(tuple(a[k]+(l+h)/2*(b[k]-a[k]) for k in (0,1)),rings) for l,h in zip(cuts,cuts[1:]))
def point_squared(p,a,b):
    v=tuple(b[k]-a[k] for k in (0,1));w=tuple(p[k]-a[k] for k in (0,1));den=sum(x*x for x in v)
    t=F(0) if den==0 else max(F(0),min(F(1),sum(v[k]*w[k] for k in (0,1))/den))
    return sum((p[k]-a[k]-t*v[k])**2 for k in (0,1))
def squared_segment(a,b,c,d):
    if intersection_parameters(a,b,c,d):return F(0)
    return min(point_squared(a,c,d),point_squared(b,c,d),point_squared(c,a,b),point_squared(d,a,b))
def segment_check(a,b,rings):
    a,b=rational(a),rational(b);q=min(squared_segment(a,b,c,d) for c,d in all_edges(rings));inside=contained(a,b,rings) if q==0 else contains(a,rings) and contains(b,rings)
    safe=inside and q>=F(121,100);tau=F(1,10**8);r=F(11,10)
    label='FAIL' if not inside or q<(r-tau)**2 else 'PASS' if q>(r+tau)**2 else 'UNCERTAIN_BOUNDARY'
    with localcontext() as ctx:
        ctx.prec=80;minimum=(Decimal(q.numerator)/Decimal(q.denominator)).sqrt()
    return {'closed_containment':inside,'clearance_squared_fraction':[str(q.numerator),str(q.denominator)],'minimum_clearance_m_decimal80':str(minimum),'exact_safe':safe,'tolerance_label':label}
def distance80(a,b):
    with localcontext() as ctx:
        ctx.prec=80
        return sum((Decimal(str(a[k]))-Decimal(str(b[k])))**2 for k in (0,1)).sqrt()
def interior(a,b,p):
    a,b,p=rational(a),rational(b),rational(p)
    return p!=a and p!=b and on_segment(p,a,b)
