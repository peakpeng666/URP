"""Synthetic watchdog, orphan-group, partial-ledger and authorization rejection checks."""
import os,sys,pathlib,subprocess,json,time,signal
from common import ROOT,save,read
from tree_runtime import run_command
from process_groups import cleanup_registered,identity
from launch_main_once import seal

def main():
 dest=ROOT/'selftests'/sys.argv[1];dest.mkdir(exist_ok=False);sleep=dest/'sleep.py';sleep.write_text('import time\ntime.sleep(300)\n')
 timeout=run_command(['/usr/bin/python3',sleep],dest/'timeout',2,134217728,.1,dest/'timeout.active.json');assert timeout['status']=='WALL_TIMEOUT'and timeout['child_reaped']and timeout['registered_group_cleanup']['quiescent']
 burn=dest/'burn.py';burn.write_text('while True: pass\n');cpu=run_command(['/usr/bin/python3',burn],dest/'cpu',1,134217728,4,dest/'cpu.active.json');assert cpu['status']=='PROCESS_FAILURE'and cpu['returncode']<0 and cpu['registered_group_cleanup']['quiescent']
 tree=dest/'tree';tree.mkdir();fork=tree/'fork.py';fork.write_text('import os,time\np=os.fork()\ntime.sleep(300)\n')
 driver=tree/'driver.py';driver.write_text('import sys,pathlib\nsys.path.insert(0,'+repr(str(ROOT/'source'))+')\nfrom tree_runtime import run_command\nrun_command(["/usr/bin/python3",'+repr(str(fork))+'],pathlib.Path('+repr(str(tree/'worker'))+'),5,134217728,300,pathlib.Path('+repr(str(tree/'active/worker.active.json'))+'))\n')
 outer=run_command(['/usr/bin/python3',driver],tree/'supervisor',5,134217728,.5,tree/'supervisor.active.json');assert outer['status']=='WALL_TIMEOUT';cleanup=cleanup_registered(tree/'active');assert cleanup['quiescent']and len(cleanup['groups'])==1
 # Loss-aware sealing keeps every intended input slot even after a corrupt final JSONL line.
 partial=dest/'partial';(partial/'raw/calls').mkdir(parents=True);s=[dict(call_id='f_E_G',instance_id='f',objective='E_G',n=4),dict(call_id='f_G_E',instance_id='f',objective='G_E',n=4)];(partial/'raw/calls/f_E_G.stdout').write_text('{partial');(partial/'raw/results.jsonl').write_text('{unfinished\n');seal(partial,partial/'raw',s,[dict(id='f')],'SYNTHETIC_NOT_AUTHORIZED',dict(synthetic_only=True));a=read(partial/'raw/ALL_PLANNED_SLOTS.json');assert len(a)==2 and a[0]['status']=='UNKNOWN_AFTER_SUPERVISOR_FAILURE'and a[1]['status']=='NOT_STARTED_SUPERVISOR_FAILURE';assert read(partial/'raw/OUTER_FINISHED.json')['malformed_rows']==[0]
 report=dict(status='PASS',synthetic_only=True,real_calls=0,wall_timeout=timeout,cpu_limit=cpu,supervisor_timeout=outer,orphan_worker_group_cleanup=cleanup,loss_aware_ledger=True);save(dest/'REPORT.json',report);print(json.dumps({'status':'PASS','synthetic_only':True,'real_calls':0,'wall_and_cpu_limits':True,'supervisor_death_cleanup':True,'all_missing_slots_retained':True}))
if __name__=='__main__':main()
