#!/usr/bin/env python3
"""Exact closed-polygon predicates, designed only for these integer simple polygons.
No epsilon/buffer. Fractions are used for all segment splitting and test points.
"""
from fractions import Fraction as F

def cross(a,b): return a[0]*b[1]-a[1]*b[0]
def sub(a,b): return a[0]-b[0],a[1]-b[1]
def on_segment(p,a,b):
    return cross(sub(p,a),sub(b,a))==0 and min(a[0],b[0])<=p[0]<=max(a[0],b[0]) and min(a[1],b[1])<=p[1]<=max(a[1],b[1])
def covered_point(p,polygon):
    parity=False
    for a,b in zip(polygon,polygon[1:]+polygon[:1]):
        if on_segment(p,a,b): return True
        if (a[1]>p[1])!=(b[1]>p[1]):
            x=F(a[0])+F((p[1]-a[1])*(b[0]-a[0]),b[1]-a[1])
            if p[0]<x: parity=not parity
    return parity

def intersection_parameters(a,b,c,d):
    """Parameters t in [0,1] where segment ab meets cd; collinear endpoints suffice."""
    r,s=sub(b,a),sub(d,c); den=cross(r,s); ca=sub(c,a)
    if r==(0,0): return [F(0)] if on_segment(a,c,d) else []
    if den:
        t,u=F(cross(ca,s),den),F(cross(ca,r),den)
        return [t] if 0<=t<=1 and 0<=u<=1 else []
    if cross(ca,r): return []
    axis=0 if r[0] else 1
    ts=sorted((F(c[axis]-a[axis],r[axis]),F(d[axis]-a[axis],r[axis])))
    low,high=max(F(0),ts[0]),min(F(1),ts[1])
    return [] if low>high else [low,high]

def covered_segment(a,b,polygon):
    if not covered_point(a,polygon) or not covered_point(b,polygon): return False
    if a==b: return True
    cuts={F(0),F(1)}
    for c,d in zip(polygon,polygon[1:]+polygon[:1]):
        cuts.update(intersection_parameters(a,b,c,d))
    cuts=sorted(cuts)
    for t0,t1 in zip(cuts,cuts[1:]):
        t=(t0+t1)/2
        p=(F(a[0])+t*(b[0]-a[0]),F(a[1])+t*(b[1]-a[1]))
        if not covered_point(p,polygon): return False
    return True

def validate_polygon(poly):
    assert len(poly)>=4 and len({tuple(p) for p in poly})==len(poly)
    edges=list(zip(poly,poly[1:]+poly[:1]))
    for a,b in edges:
        assert a!=b and ((a[0]==b[0]) != (a[1]==b[1])), 'Must be nondegenerate orthogonal edges'
    twice_area=sum(a[0]*b[1]-b[0]*a[1] for a,b in edges)
    assert twice_area>0, 'Polygon must be CCW with positive area'
    for i,(a,b) in enumerate(edges):
        for j,(c,d) in enumerate(edges):
            if j<=i or j==i+1 or (i==0 and j==len(edges)-1): continue
            assert not intersection_parameters(a,b,c,d), 'Nonadjacent edges intersect'
    return twice_area/2
