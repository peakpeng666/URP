"""Only formal author entry point; unique gate, whole-tree watchdog, loss-aware slot ledger."""
import resource,time,pathlib,sys,json
from common import ROOT,read,save,sha,utc,inventory
from gates import main_ready
from tree_runtime import run_command
from process_groups import cleanup_registered

def seal(base,dest,schedule,fields,digest,outer):
 dest.mkdir(exist_ok=True);rows=[];bad=[]
 if (dest/'results.jsonl').exists():
  for i,line in enumerate((dest/'results.jsonl').read_text().splitlines()):
   try:rows.append(json.loads(line))
   except Exception:bad.append(i)
 by={r['schedule']['call_id']:r for r in rows};allslots=[]
 for s in schedule:
  cid=s['call_id'];exists=(dest/'calls'/(cid+'.stdout')).exists()
  allslots.append(by.get(cid,dict(schedule=s,status='UNKNOWN_AFTER_SUPERVISOR_FAILURE'if exists else'NOT_STARTED_SUPERVISOR_FAILURE',process_spawned='UNKNOWN'if exists else False)))
 fs=[]
 for field in fields:
  p=dest/'fields'/field['id']/'FIELD_FINISHED.json'
  fs.append(dict(instance_id=field['id'],result=read(p)if p.exists()else dict(status='UNKNOWN_OR_NOT_STARTED_AFTER_SUPERVISOR_FAILURE')))
 save(dest/'ALL_PLANNED_SLOTS.json',allslots);save(dest/'ALL_FIELD_SLOTS.json',fs);save(dest/'OUTER_FINISHED.json',dict(utc=utc(),outer=outer,status='RAW_MAIN_UNREVIEWED',all_planned_fields=len(fields),all_planned_calls=len(schedule),malformed_rows=bad,duplicate_call_ids=len(by)!=len(rows)))
 save(dest/'RAW_MAIN_CONTENT_MANIFEST.json',dict(utc=utc(),frozen_files_sha256=digest,files=inventory(base,[p for p in dest.rglob('*')if p.is_file()])))

def author_outer_limits():
 # Same soft/self versus hard/descendant separation used by the audited strong-baseline r1 supervisor.
 resource.setrlimit(resource.RLIMIT_AS,(536870912,1073741824));resource.setrlimit(resource.RLIMIT_CPU,(60,120))
 return {'cpu':list(resource.getrlimit(resource.RLIMIT_CPU)),'as':list(resource.getrlimit(resource.RLIMIT_AS))}

def main():
 assert __debug__;limits=author_outer_limits();d=main_ready();fields=read(ROOT/'input/provenance/PANEL_SOURCE_READY_PROPOSAL.json')['candidates'];schedule=read(ROOT/'freeze/SCHEDULE.json')
 save(ROOT/'provenance/MAIN_LAUNCH_STARTED.json',dict(utc=utc(),frozen_files_sha256=d,planned_fields=12,planned_main_calls=24,planned_independent_calls=24,whole_supervisor_tree_wall_seconds=4700,outer_soft_hard_limits=limits))
 outer=run_command(['/usr/bin/python3',ROOT/'source/run_author_batch.py'],ROOT/'provenance/author_supervisor',60,536870912,4700,ROOT/'provenance/author_supervisor.active.json',cpu_hard=120,as_hard=1073741824)
 cleanup=cleanup_registered(ROOT/'raw/active');save(ROOT/'provenance/WHOLE_TREE_CLEANUP.json',cleanup)
 if outer.get('process_spawned')and not(outer.get('registered_group_cleanup')or{}).get('quiescent'):raise RuntimeError('OUTER_GROUP_NOT_QUIESCENT_CANNOT_SEAL')
 if not cleanup['quiescent']:raise RuntimeError('CHILD_TREE_NOT_QUIESCENT_CANNOT_SEAL')
 seal(ROOT,ROOT/'raw',schedule,fields,d,outer);print('Raw main sealed locally. Private RAW_MAIN readback required before independent verification or outcome comparison.')
if __name__=='__main__':main()
