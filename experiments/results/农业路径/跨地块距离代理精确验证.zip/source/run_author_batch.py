"""Production supervisor; preserves 12 geometry slots and all 24 main DP slots."""
import sys,time,pathlib,json
from common import ROOT,read,save,append,sha,utc
from tree_runtime import run_command
from gates import active_main_gate

def execute(base,dest,fields,schedule,production=True,geometry_command=None,geometry_cpu=120,geometry_as=1073741824,geometry_wall=180,geometry_batch_wall=2300,main_batch_wall=2300):
 dest.mkdir(exist_ok=False);(dest/'active').mkdir();(dest/'calls').mkdir();(dest/'fields').mkdir();start=time.monotonic();deadline=start+geometry_batch_wall
 save(dest/'STARTED.json',dict(utc=utc(),planned_fields=len(fields),planned_main_calls=len(schedule),synthetic_only=not production));frows=[]
 for f in fields:
  fid=f['id'];slot=dest/'fields'/fid;slot.mkdir();remaining=deadline-time.monotonic();row=dict(instance_id=fid,utc=utc())
  if remaining<=0:row.update(status='NOT_STARTED_PREPROCESS_BATCH_BUDGET',process_spawned=False)
  else:
   cmd=geometry_command(fid,slot)if geometry_command else['/usr/bin/python3',base/'source/field_preprocess.py',fid,slot]
   append(dest/'events.jsonl',dict(event_kind='PREPROCESS_STARTED',instance_id=fid,utc=utc()))
   row.update(run_command(cmd,dest/'calls'/(fid+'_geometry'),geometry_cpu,geometry_as,min(geometry_wall,remaining),dest/'active'/(fid+'_geometry.active.json')))
   if (slot/'FIELD_FINISHED.json').exists():row['field_result']=read(slot/'FIELD_FINISHED.json')
  append(dest/'field_results.jsonl',row);frows.append(row)
 save(dest/'PREPROCESS_BATCH_FINISHED.json',dict(utc=utc(),fields=len(frows),wall_seconds=time.monotonic()-start,planned_fields=len(fields)))
 # Same schedule and missing-slot rules for synthetic fixtures and the real 24 slots.
 mainstart=time.monotonic();deadline=mainstart+main_batch_wall;rows=[]
 for s in schedule:
  cid=s['call_id'];fid=s['instance_id'];p=dest/'fields'/fid/(s['objective']+'.txt');fr=dest/'fields'/fid/'FIELD_FINISHED.json';row=dict(schedule=s,utc=utc());remaining=deadline-time.monotonic();reason=None
  if remaining<=0:reason='NOT_STARTED_MAIN_BATCH_BUDGET'
  elif not fr.exists()or read(fr).get('status')!='PASS_PREPROCESS':reason='NOT_STARTED_PREPROCESS_FAILURE'
  elif not p.exists():reason='NOT_STARTED_MISSING_DERIVED_INPUT'
  else:
   expected=[r for r in read(fr).get('inputs',[])if r['objective']==s['objective']]
   if len(expected)!=1 or expected[0]['sha256']!=sha(p):reason='NOT_STARTED_DERIVED_INPUT_HASH_FAILURE'
  if reason:row.update(status=reason,process_spawned=False,child_reaped=False)
  else:
   row['input']=str(p.relative_to(base));row['input_sha256']=sha(p);append(dest/'events.jsonl',dict(event_kind='DP_STARTED',schedule=s,utc=utc()))
   row.update(run_command([base/'source/hklex'],dest/'calls'/cid,60,536870912,min(90,remaining),dest/'active'/(cid+'.active.json'),p))
  append(dest/'results.jsonl',row);rows.append(row)
 save(dest/'FINISHED.json',dict(utc=utc(),planned_main_calls=len(schedule),recorded_slots=len(rows),spawned_calls=sum(bool(x['process_spawned'])for x in rows),preprocess_rows=len(frows),main_wall_seconds=time.monotonic()-mainstart,total_wall_seconds=time.monotonic()-start,status='RAW_UNREVIEWED'))
 return frows,rows

if __name__=='__main__':
 active_main_gate();panel=read(ROOT/'input/provenance/PANEL_SOURCE_READY_PROPOSAL.json');execute(ROOT,ROOT/'raw',panel['candidates'],read(ROOT/'freeze/SCHEDULE.json'))
