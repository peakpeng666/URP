"""Pure synthetic ancestor->supervisor->worker with the actual production soft/hard ceilings."""
from pathlib import Path
import sys,json,subprocess
from common import ROOT,save,read

def main():
 d=ROOT/'selftests'/sys.argv[1];d.mkdir(exist_ok=False);worker=d/'worker.py';worker.write_text('import resource,json\nprint(json.dumps({"cpu":list(resource.getrlimit(resource.RLIMIT_CPU)),"as":list(resource.getrlimit(resource.RLIMIT_AS))}))\n')
 prefix='import sys,resource,json,pathlib\nsys.path.insert(0,'+repr(str(ROOT/'source'))+')\nfrom tree_runtime import run_command\n'
 sup=d/'supervisor.py';sup.write_text(prefix+'limits={"cpu":list(resource.getrlimit(resource.RLIMIT_CPU)),"as":list(resource.getrlimit(resource.RLIMIT_AS))}\nr=run_command(["/usr/bin/python3",'+repr(str(worker))+'],pathlib.Path('+repr(str(d/'worker'))+'),120,1073741824,5,pathlib.Path('+repr(str(d/'worker.active.json'))+'))\nprint(json.dumps({"supervisor_limits":limits,"worker":r}))\n')
 outer=d/'outer.py';outer.write_text(prefix+'from launch_main_once import author_outer_limits\nlimits=author_outer_limits()\nr=run_command(["/usr/bin/python3",'+repr(str(sup))+'],pathlib.Path('+repr(str(d/'supervisor'))+'),60,536870912,10,pathlib.Path('+repr(str(d/'supervisor.active.json'))+'),cpu_hard=120,as_hard=1073741824)\nprint(json.dumps({"outer_limits":limits,"supervisor":r}))\n')
 p=subprocess.run(['/usr/bin/python3',outer],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=20);(d/'outer.stdout').write_text(p.stdout);(d/'outer.stderr').write_text(p.stderr);assert p.returncode==0;a=json.loads(p.stdout);b=read(d/'supervisor.stdout');c=read(d/'worker.stdout');assert a['outer_limits']=={'cpu':[60,120],'as':[536870912,1073741824]};assert b['supervisor_limits']==a['outer_limits'];assert c=={'cpu':[120,120],'as':[1073741824,1073741824]};assert a['supervisor']['status']==b['worker']['status']=='UNREVIEWED_PROCESS_SUCCESS';assert b['worker']['reaped_utc']and a['supervisor']['reaped_utc'];save(d/'REPORT.json',dict(status='PASS',synthetic_only=True,real_calls=0,actual_ancestor_chain_limits=True,outer=a,supervisor=b,worker_limits=c));print('PASS actual120CPU/1GiB child budget inheritance under smaller ancestor softlimits; no geometry or solver calls')
if __name__=='__main__':main()
