"""Shared real/synthetic bounded process registration; every descendant group is accounted for."""
import os,pathlib,subprocess,resource,signal,time,json
from common import utc,save,sha
from process_groups import child_register,cleanup_record,cleanup_registered

def run_command(command,dest,cpu,as_bytes,wall,registration,input_path=None,cpu_hard=None,as_hard=None):
 cpu_hard=cpu if cpu_hard is None else cpu_hard;as_hard=as_bytes if as_hard is None else as_hard
 assert 0<cpu<=cpu_hard and 0<as_bytes<=as_hard
 dest.parent.mkdir(parents=True,exist_ok=True);registration.parent.mkdir(parents=True,exist_ok=True);start=time.monotonic();started_utc=utc();reaped_utc=None;usage=resource.getrusage(resource.RUSAGE_CHILDREN);parent=os.getpid();proc=None;timedout=False;error=None;clean=None
 def setup():
  child_register(parent,registration);resource.setrlimit(resource.RLIMIT_CPU,(cpu,cpu_hard));resource.setrlimit(resource.RLIMIT_AS,(as_bytes,as_hard));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
 src=open(input_path,'rb')if input_path is not None else open(os.devnull,'rb')
 outpath=dest.with_suffix('.stdout');errpath=dest.with_suffix('.stderr')
 with src,outpath.open('xb')as out,errpath.open('xb')as err:
  try:
   proc=subprocess.Popen([str(x)for x in command],stdin=src,stdout=out,stderr=err,start_new_session=True,preexec_fn=setup,close_fds=True,env={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C','PROJ_NETWORK':'OFF','PYTHONDONTWRITEBYTECODE':'1'})
   try:proc.wait(timeout=wall)
   except subprocess.TimeoutExpired:timedout=True;os.killpg(proc.pid,signal.SIGKILL);proc.wait()
  except Exception as exc:error=repr(exc)
  finally:
   if proc is not None:
    try:os.killpg(proc.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    proc.wait();reaped_utc=utc()
   if registration.exists():
    clean=cleanup_record(json.loads(registration.read_text()));save(registration.with_name(registration.name.replace('.active.json','.closed.json')),clean)
    if not clean['quiescent']:error='PROCESS_GROUP_NOT_QUIESCENT'
 after=resource.getrusage(resource.RUSAGE_CHILDREN);rc=proc.returncode if proc else None
 status='UNREVIEWED_PROCESS_SUCCESS'if rc==0 and not error else'WALL_TIMEOUT'if timedout else'LIFECYCLE_FAILURE'if error else'PROCESS_FAILURE'
 return dict(status=status,started_utc=started_utc,reaped_utc=reaped_utc,finished_utc=utc(),returncode=rc,process_spawned=proc is not None,child_reaped=proc is not None and proc.poll()is not None,wall_seconds=time.monotonic()-start,cpu_seconds_children_delta=after.ru_utime+after.ru_stime-usage.ru_utime-usage.ru_stime,maxrss_children_kib_cumulative=after.ru_maxrss,configured_cpu_seconds=cpu,configured_cpu_soft_hard_seconds=[cpu,cpu_hard],configured_as_bytes=as_bytes,configured_as_soft_hard_bytes=[as_bytes,as_hard],configured_wall_seconds=wall,stdout=str(outpath),stderr=str(errpath),stdout_sha256=sha(outpath),stderr_sha256=sha(errpath),registered_group_cleanup=clean,error=error)
