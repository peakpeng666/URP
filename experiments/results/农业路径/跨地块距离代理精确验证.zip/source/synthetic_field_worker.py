"""Only hardcoded synthetic fixtures. No production field source is read."""
import sys,pathlib,json,traceback
from osgeo import ogr
from common import save,utc
from field_preprocess import execute_geometry
WKT={'convex':'POLYGON ((0 0,40 0,40 40,0 40,0 0))','hole':'POLYGON ((0 0,50 0,50 50,0 50,0 0),(20 20,20 30,30 30,30 20,20 20))','concave':'POLYGON ((0 0,40 0,40 15,15 15,15 40,0 40,0 0))','empty':'POLYGON ((0 0,1 0,1 1,0 1,0 0))','split':'POLYGON ((0 0,12 0,12 5,24 5,24 0,36 0,36 12,24 12,24 6,12 6,12 12,0 12,0 0))'}
if __name__=='__main__':
 fid=sys.argv[1];dest=pathlib.Path(sys.argv[2]);assert fid in WKT;dest.mkdir(exist_ok=True);w=WKT[fid];p=ogr.CreateGeometryFromWkt(w)
 try:r=execute_geometry(p,w,'synthetic_'+fid,991,4,dest)
 except Exception as e:r=dict(status='PREPROCESS_EXCEPTION',error=repr(e),traceback=traceback.format_exc())
 r.update(synthetic_only=True,utc=utc());save(dest/'FIELD_FINISHED.json',r);print(json.dumps(r))
 sys.exit(0 if r['status']=='PASS_PREPROCESS'else 4)
