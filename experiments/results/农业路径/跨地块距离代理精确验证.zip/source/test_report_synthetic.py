"""Saved-result arithmetic fixtures only; no DP, source projection, or graph searches."""
import pathlib,json,sys,copy
from common import ROOT,save,sha
from report import summarize,reconcile_audit

def main():
 d=ROOT/'selftests'/sys.argv[1];d.mkdir(exist_ok=False);(d/'input/provenance').mkdir(parents=True);(d/'raw/calls').mkdir(parents=True);fields=[];rows=[];coords=[[i+2.,2.]for i in range(21)];route=list(range(21))+[0];D=[[abs(i-j)*1.0 for j in range(21)]for i in range(21)];M=[[int(v*1000)for v in r]for r in D];cost=sum(M[a][b]for a,b in zip(route,route[1:]));paths=[[[i]if i==j else[i,j]for j in range(21)]for i in range(21)]
 for i in range(12):
  fid='synthetic_field_'+str(i);fields.append(dict(id=fid,stratum=['convex_no_hole','concave_no_hole','with_hole'][i//4]));p=d/'raw/fields'/fid;p.mkdir(parents=True);save(p/'graph.json',dict(nodes=coords));save(p/'preprocess.json',dict(n=20,integer_matrices={'E':M,'G':M},unrounded_matrices={'E':D,'G':D},canonical_paths=paths));(p/'projected.wkt').write_text('POLYGON ((0 0,30 0,30 10,0 10,0 0))')
  for arm in ['E_G','G_E']:
   out=d/'raw/calls'/(fid+'_'+arm+'.stdout');save(out,dict(E=cost,G=cost,route=route));rows.append(dict(schedule=dict(call_id=fid+'_'+arm,instance_id=fid,objective=arm),status='UNREVIEWED_PROCESS_SUCCESS',stdout=str(out),stdout_sha256=sha(out)))
 save(d/'input/provenance/PANEL_SOURCE_READY_PROPOSAL.json',dict(candidates=fields));save(d/'raw/ALL_PLANNED_SLOTS.json',rows);a=summarize(d,set(x['id']for x in fields));b=summarize(d,set(x['id']for x in fields[:-1]));assert a['verified_fields']==12 and a['complete_panel_mean_delta_integer_mm']==0 and all(x['verified_fields']==4 for x in a['strata'].values());assert b['verified_fields']==11 and b['complete_panel_mean_delta_integer_mm']is None and b['complete_case_mean_delta_integer_mm']==0 and b['strata']['with_hole']['complete_stratum_mean_delta_integer_mm']is None
 audit={'fields':copy.deepcopy(a['fields']),'rows':[dict(instance_id=f['instance_id'],objective=t['objective'],valid_for_exact_conclusion=True,E=t['E_integer_mm'],G=t['G_integer_mm'],route=t['route'],realized_path_length_m_decimal80=t['realized_path_length_m_decimal80'])for f in a['fields']for t in f['tours']],'verified_fields':12,'complete_panel_mean_delta_integer_mm':0,'main_counts':{'known_spawned':24,'unknown_spawned_slots':0},'independent_counts':{'known_spawned':24,'unknown_spawned_slots':0}}
 checked=reconcile_audit(copy.deepcopy(a),audit);assert checked['known_total_spawned_DP_processes']==48
 bad=copy.deepcopy(audit);bad['rows'][0]['E']+=1
 try:reconcile_audit(copy.deepcopy(a),bad)
 except AssertionError:pass
 else:raise AssertionError('Mismatching independent cost accepted')
 bad=copy.deepcopy(audit);bad['fields'][0]['delta_integer_mm']=1
 try:reconcile_audit(copy.deepcopy(a),bad)
 except AssertionError:pass
 else:raise AssertionError('Mismatching independent delta accepted')
 save(d/'REPORT.json',dict(status='PASS',synthetic_only=True,real_calls=0,DP_calls=0,all12complete=a,onefieldunverified=b));print('PASS saved arithmetic/all12 denominator/missing stratum; no DP calls')
if __name__=='__main__':main()
