"""Shared production/synthetic subprocess lifecycle. No optimization in this module."""
import json, os, resource, signal, subprocess, time
from process_groups import child_register, identity, cleanup_record
LIMIT_AS=512*1024*1024
LIMIT_CPU=60
LIMIT_WALL=90

def limits():
    resource.setrlimit(resource.RLIMIT_CPU,(LIMIT_CPU,LIMIT_CPU))
    resource.setrlimit(resource.RLIMIT_AS,(LIMIT_AS,LIMIT_AS))
    resource.setrlimit(resource.RLIMIT_CORE,(0,0))

def run(binary,input_path,stdout_path,stderr_path,wall_limit=LIMIT_WALL,registration_path=None):
    assert 0 < wall_limit <= LIMIT_WALL
    start=time.monotonic(); before=resource.getrusage(resource.RUSAGE_CHILDREN)
    proc=None; timeout=False; error=None; group_cleanup=None; parent_pid=os.getpid()
    def setup():
        child_register(parent_pid,registration_path)
        limits()
    with open(input_path,'rb')as src,open(stdout_path,'xb')as out,open(stderr_path,'xb')as err:
        try:
            proc=subprocess.Popen([str(binary)],stdin=src,stdout=out,stderr=err,preexec_fn=setup,start_new_session=True,close_fds=True,env={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C'})
            try:proc.wait(timeout=wall_limit)
            except subprocess.TimeoutExpired:
                timeout=True;os.killpg(proc.pid,signal.SIGKILL);proc.wait()
        except Exception as exc:
            error=repr(exc)
        finally:
            if proc is not None:
                try:os.killpg(proc.pid,signal.SIGKILL)
                except ProcessLookupError:pass
                proc.wait()
                if registration_path is not None and registration_path.exists():
                    group_cleanup=cleanup_record(json.loads(registration_path.read_text()))
                    closed=registration_path.with_name(registration_path.name.replace('.active.json','.closed.json'))
                    with closed.open('x')as f:json.dump(group_cleanup,f)
                    if not group_cleanup['quiescent']:error='PROCESS_GROUP_NOT_QUIESCENT'
    after=resource.getrusage(resource.RUSAGE_CHILDREN)
    rc=proc.returncode if proc is not None else None
    status='UNREVIEWED_PROCESS_SUCCESS' if rc==0 and not error else ('WALL_TIMEOUT' if timeout else ('SPAWN_OR_LIFECYCLE_FAILURE' if error else 'PROCESS_FAILURE'))
    return {'status':status,'returncode':rc,'process_spawned':proc is not None,'pid':proc.pid if proc else None,'child_reaped':proc is not None and proc.poll()is not None,'external_wall_seconds':time.monotonic()-start,'cpu_seconds_children_delta':after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime,'children_maxrss_kib_cumulative':after.ru_maxrss,'configured_cpu_seconds':LIMIT_CPU,'configured_as_bytes':LIMIT_AS,'configured_wall_seconds':wall_limit,'error':error,'registered_group_cleanup':group_cleanup,'maxrss_scope':'RUSAGE_CHILDREN cumulative high-water, not necessarily this child; child self maxrss separately in success stdout'}
