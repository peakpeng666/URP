"""Lightweight synthetic geometry->saved graph->paired exact DP->all-slot seal tests."""
import sys,pathlib,json,time,subprocess,itertools,math,os
from osgeo import ogr
from common import ROOT,read,save,sha
from field_preprocess import project,serialize,construct,sample,point,execute_geometry,quantize
from author_geometry import segment_check,rings_from_wkt
from run_author_batch import execute
from launch_main_once import seal
from process_groups import cleanup_registered
from synthetic_field_worker import WKT
from test_synthetic import oracle,costs

def main():
 dest=ROOT/'selftests'/sys.argv[1];dest.mkdir(exist_ok=False);fixtures=dest/'workspace';(fixtures/'source').mkdir(parents=True);os.symlink(ROOT/'source/hklex',fixtures/'source/hklex');fields=[dict(id=x)for x in ['convex','concave','hole','empty','split']];schedule=[]
 for f in fields:
  for a in ['E_G','G_E']:schedule.append(dict(call_id=f['id']+'_'+a,instance_id=f['id'],n=4,objective=a))
 frows,rows=execute(fixtures,fixtures/'raw',fields,schedule,production=False,geometry_command=lambda fid,slot:['/usr/bin/python3',ROOT/'source/synthetic_field_worker.py',fid,slot],geometry_cpu=20,geometry_as=536870912,geometry_wall=30,geometry_batch_wall=120,main_batch_wall=60)
 clean=cleanup_registered(fixtures/'raw/active');assert clean['quiescent'];seal(fixtures,fixtures/'raw',schedule,fields,'synthetic-only-not-authorization',dict(synthetic_only=True));checks={}
 checks['all_slots_retained']=len(read(fixtures/'raw/ALL_PLANNED_SLOTS.json'))==10
 checks['all_field_slots_retained']=len(read(fixtures/'raw/ALL_FIELD_SLOTS.json'))==5
 checks['all_groups_quiescent']=clean['quiescent']
 for fid in ['convex','concave','hole']:
  p=fixtures/'raw/fields'/fid;d=read(p/'preprocess.json');g=read(p/'graph.json');M=d['integer_matrices'];pairs={}
  for a in ['E_G','G_E']:
   row=next(r for r in rows if r['schedule']['call_id']==fid+'_'+a);assert row['status']=='UNREVIEWED_PROCESS_SUCCESS';out=read(row['stdout']);expect=oracle(M['E'],M['G'],a);route=out['route'];e,gg=costs(M['E'],M['G'],route);pairs[a]=out
   checks[fid+'_'+a+'_oracle']=tuple([out['primary'],out['secondary']])==expect and (out['E'],out['G'])==(e,gg)and sorted(route[1:-1])==list(range(1,5))
  checks[fid+'_lex_delta_nonnegative']=pairs['E_G']['G']-pairs['G_E']['G']>=0
  checks[fid+'_shared_same_coordinates']=d['coordinates']==read(p/'services.json')['coordinates']==g['nodes'][g['base_count']:]
  checks[fid+'_all_saved_segments_exact_safe']=all(x['exact_safe']for x in d['unique_path_segments'])and all(x['exact_safe']for x in d['endpoint_checks'])
  checks[fid+'_terminal_service_paths']=all(all(v<g['base_count']for v in path[1:-1])for row in d['canonical_paths']for path in row)
 checks['empty_center_failure_retained']=read(fixtures/'raw/fields/empty/FIELD_FINISHED.json')['status']=='EMPTY_CONSERVATIVE_CENTER'
 checks['empty_dp_not_started']=all(r['status']=='NOT_STARTED_PREPROCESS_FAILURE'for r in rows if r['schedule']['instance_id']=='empty')
 checks['split_components_retained']=read(fixtures/'raw/fields/split/FIELD_FINISHED.json')['status']=='DISCONNECTED_CONSERVATIVE_COMPONENTS'
 checks['split_dp_not_started']=all(r['status']=='NOT_STARTED_PREPROCESS_FAILURE'for r in rows if r['schedule']['instance_id']=='split')
 p=ogr.CreateGeometryFromWkt(WKT['hole']);c,_,_=construct(p);a=[];b=[];s1=sample(p,c,123,4,1000,a.append);s2=sample(p,c,123,4,1000,b.append);checks['sampling_replay']=a==b and s1==s2 and s1['complete'];short=sample(p,c,123,4,1,lambda _:None);checks['sampling_cap_failure']=not short['complete'];checks['no_duplicates']=len(set(tuple(x['coordinate'])for x in s1['accepted']))==5
 rs=rings_from_wkt(WKT['convex']);checks['exact_threshold_primary']=segment_check([1.1,5],[1.1,6],rs)['exact_safe']and not segment_check([1.099,5],[1.099,6],rs)['exact_safe'];checks['half_up']=quantize('1.2345')==1235 and quantize('0.0005')==1
 # Synthetic geographic square only; never load or transform one of the twelve real WKT files.
 prj='GEOGCS["WGS 84",DATUM["WGS_1984",SPHEROID["WGS 84",6378137,298.257223563]],PRIMEM["Greenwich",0],UNIT["degree",0.0174532925199433]]'
 pp,pw,meta=project('POLYGON ((3 45,3.001 45,3.001 45.001,3 45.001,3 45))',prj,32631);checks['synthetic_projection_axis_and_roundtrip']=meta['always_xy']and meta['maximum_roundtrip_absolute_degrees']<1e-8 and serialize(pp)==pw and 499999<pp.GetEnvelope()[0]<500001
 # Real launch must fail closed without receipts, and must not create any formal guard/raw data.
 q=subprocess.run(['/usr/bin/python3',ROOT/'source/launch_main_once.py'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=10);(dest/'missing_gate.stdout').write_text(q.stdout);(dest/'missing_gate.stderr').write_text(q.stderr);checks['real_launch_without_gate_blocked']=q.returncode!=0 and not(ROOT/'provenance/MAIN_LAUNCH_STARTED.json').exists()and not(ROOT/'raw').exists()
 report=dict(status='PASS'if all(checks.values())else'FAIL',synthetic_only=True,real_projection_calls=0,real_sampling_calls=0,real_graph_calls=0,real_optimizer_calls=0,synthetic_preprocess_slots=5,synthetic_planned_dp_slots=10,synthetic_spawned_dp_calls=sum(r['process_spawned']for r in rows),checks=checks)
 save(dest/'REPORT.json',report);print(json.dumps(report,indent=2));assert report['status']=='PASS'
if __name__=='__main__':main()
