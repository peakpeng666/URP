"""Saved-result report only. No sampling, geometry generation, graph search, or DP calls."""
import json,pathlib,math,resource,statistics
from decimal import Decimal,localcontext
from common import ROOT,read,save,sha,utc
from gates import frozen,receipt
from author_geometry import distance80,segment_check,rings_from_wkt

def summarize(base,eligible):
 panel=read(base/'input/provenance/PANEL_SOURCE_READY_PROPOSAL.json')['candidates'];slots=read(base/'raw/ALL_PLANNED_SLOTS.json');by={r['schedule']['call_id']:r for r in slots};fields=[]
 for f in panel:
  fid=f['id'];row=dict(instance_id=fid,stratum=f['stratum'],status='UNVERIFIED_OR_FAILED',eligible_for_primary=False);items=[]
  if fid in eligible:
   p=base/'raw/fields'/fid;d=read(p/'preprocess.json');g=read(p/'graph.json');rings=rings_from_wkt((p/'projected.wkt').read_text());n=d['n'];assert n==20
   for arm in ['E_G','G_E']:
    s=by[fid+'_'+arm];assert s['status']=='UNREVIEWED_PROCESS_SUCCESS';output_path=base/'raw/calls'/(fid+'_'+arm+'.stdout');assert sha(output_path)==s['stdout_sha256'];o=read(output_path);route=o['route'];assert route[0]==route[-1]==0 and sorted(route[1:-1])==list(range(1,n+1));E,G=(sum(d['integer_matrices'][a][u][v]for u,v in zip(route,route[1:]))for a in ['E','G']);assert(o['E'],o['G'])==(E,G);segments=[]
    for a,b in zip(route,route[1:]):
     path=d['canonical_paths'][a][b]
     segments.extend((g['nodes'][u],g['nodes'][v])for u,v in zip(path,path[1:]))
    with localcontext()as ctx:
     ctx.prec=80;L=sum((distance80(a,b)for a,b in segments),Decimal(0));stored=sum((Decimal(str(d['unrounded_matrices']['G'][a][b]))for a,b in zip(route,route[1:])),Decimal(0));assert abs(L-stored)<=Decimal(n+1)*Decimal('1e-8')
    # Exact segment safety has already been independently checked on all saved candidate paths;
    # route reconstruction and independent audit binding are both retained below.
    items.append(dict(objective=arm,E_integer_mm=E,G_integer_mm=G,route=route,realized_path_length_m_decimal80=str(L),realized_minus_saved_G_m_decimal80=str(L-stored),stdout_sha256=sha(output_path)))
   a,b=items;delta=a['G_integer_mm']-b['G_integer_mm'];assert delta>=0
   with localcontext()as ctx:
    ctx.prec=80;length_difference=Decimal(a['realized_path_length_m_decimal80'])-Decimal(b['realized_path_length_m_decimal80'])
   row.update(status='VERIFIED_INTEGER_PROXY_DIAGNOSTIC',eligible_for_primary=True,delta_integer_mm=delta,relative_integer_percent=(100*delta/b['G_integer_mm'])if b['G_integer_mm']else None,realized_length_difference_m_decimal80=str(length_difference),tours=items)
  else:
   row['planned_call_statuses']={arm:by.get(fid+'_'+arm,{}).get('status','MISSING_SLOT')for arm in ['E_G','G_E']}
  fields.append(row)
 good=[r for r in fields if r['eligible_for_primary']];whole=len(good)==12
 result=dict(status='COMPLETE_12_FIELD_RESULT'if whole else'INCOMPLETE_PRIMARY_PANEL',planned_fields=12,verified_fields=len(good),planned_main_calls=24,planned_independent_calls=24,complete_panel_mean_delta_integer_mm=statistics.mean(r['delta_integer_mm']for r in good)if whole else None,complete_case_mean_delta_integer_mm=statistics.mean(r['delta_integer_mm']for r in good)if good else None,integer_conflict_fields=sum(r['delta_integer_mm']>0 for r in good),fields=fields,interpretation='Exact only for 1mm integer E/G proxy models on each frozen finite candidate graph and synthetic tasks. No field-trial, actual machinery, continuous-plane optimum or statistical population generalization.')
 result['strata']={}
 for name in ['convex_no_hole','concave_no_hole','with_hole']:
  sub=[r for r in good if r['stratum']==name];result['strata'][name]={'planned_fields':4,'verified_fields':len(sub),'complete_stratum_mean_delta_integer_mm':statistics.mean(r['delta_integer_mm']for r in sub)if len(sub)==4 else None,'complete_case_mean_delta_integer_mm':statistics.mean(r['delta_integer_mm']for r in sub)if sub else None}
 return result

def reconcile_audit(result,audit):
 fields={f['instance_id']:f for f in audit['fields']};rows={(r['instance_id'],r['objective']):r for r in audit['rows']}
 assert result['verified_fields']==audit['verified_fields'] and result['complete_panel_mean_delta_integer_mm']==audit['complete_panel_mean_delta_integer_mm']
 for f in result['fields']:
  af=fields[f['instance_id']];assert f['eligible_for_primary']==af['eligible_for_primary']
  if f['eligible_for_primary']:
   assert f['delta_integer_mm']==af['delta_integer_mm']
   with localcontext()as ctx:
    ctx.prec=80;assert abs(Decimal(f['realized_length_difference_m_decimal80'])-Decimal(af['realized_length_difference_m_decimal80']))<=Decimal('1e-60')
   for t in f['tours']:
    r=rows[f['instance_id'],t['objective']];assert r['valid_for_exact_conclusion'] and (t['E_integer_mm'],t['G_integer_mm'],t['route'])==(r['E'],r['G'],r['route'])
    with localcontext()as ctx:
     ctx.prec=80;assert abs(Decimal(t['realized_path_length_m_decimal80'])-Decimal(r['realized_path_length_m_decimal80']))<=Decimal('1e-60')
  else:
   f['independent_input_audit_status']=af.get('input_audit_status','NOT_VERIFIED');f['independent_slot_errors']={a:rows.get((f['instance_id'],a),{}).get('errors',['MISSING_AUDIT_ROW'])for a in ['E_G','G_E']}
 result['main_counts']=audit['main_counts'];result['independent_counts']=audit['independent_counts'];result['report_vs_audit_decimal80_tolerance_m']='1e-60 (arithmetic grouping only; does not relax any safety or primary integer check)'
 for counts in [result['main_counts'],result['independent_counts']]:
  assert all(type(counts[k])is int and 0<=counts[k]<=24 for k in ['known_spawned','unknown_spawned_slots'])and counts['known_spawned']+counts['unknown_spawned_slots']<=24
 result['known_total_spawned_DP_processes']=result['main_counts']['known_spawned']+result['independent_counts']['known_spawned'];result['unknown_total_spawned_slots']=result['main_counts']['unknown_spawned_slots']+result['independent_counts']['unknown_spawned_slots']
 return result

def main():
 resource.setrlimit(resource.RLIMIT_CPU,(60,60));resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912));d=frozen();rm=receipt(ROOT/'provenance/RAW_MAIN_DRIVE_RECEIPT.json','RAW_MAIN',d);rv=receipt(ROOT/'provenance/RAW_VERIFICATION_DRIVE_RECEIPT.json','RAW_VERIFICATION',d);a=read(ROOT/'independent_supervision/FINAL_AUDIT.json');assert a['status']in('PASS','AUDIT_COMPLETE_WITH_UNVERIFIED_SLOTS');assert a['frozen_files_sha256']==d and a['raw_main_archive_sha256']==rm['sha256']and a['raw_verification_archive_sha256']==rv['sha256'];eligible=set(a['eligible_instance_ids']);assert len(eligible)==len(a['eligible_instance_ids'])and eligible<=set(read(ROOT/'freeze/PROTOCOL.json')['conditions']);result=reconcile_audit(summarize(ROOT,eligible),a);result['independent_audit_sha256']=sha(ROOT/'independent_supervision/FINAL_AUDIT.json');result['utc']=utc();save(ROOT/'reports/SUMMARY.json',result)
 text='跨地块整数距离代理精确诊断\n'+f"计划12个真实公开边界、每边界20个合成任务；通过复核{result['verified_fields']}/12。主24次和独立24次DP均保留计划槽。\n"+f"完整12字段主均值Δ(mm)：{result['complete_panel_mean_delta_integer_mm']}。有效字段描述均值Δ(mm)：{result['complete_case_mean_delta_integer_mm']}，分母{result['verified_fields']}。\n"+'Δ=min{G(T):E(T)=E_star}-G_star，只针对冻结1毫米整数代理；所有失败保留，无字段/seed替换。真实边界与合成任务，不是真实作业/实车实验，不推广到其它田块或统计总体。\n'
 text+=f"已知启动DP进程：主{result['main_counts']['known_spawned']}，独立{result['independent_counts']['known_spawned']}，合计{result['known_total_spawned_DP_processes']}；启动状态未知槽：主{result['main_counts']['unknown_spawned_slots']}，独立{result['independent_counts']['unknown_spawned_slots']}。未知不按零次计算。\n"
 for f in result['fields']:text+=f"{f['instance_id']} [{f['stratum']}]: "+(f"Δ={f['delta_integer_mm']} mm; 同图实现路长差={f['realized_length_difference_m_decimal80']} m"if f['eligible_for_primary']else f['status'])+'\n'
 (ROOT/'reports/REPORT_ZH.txt').write_text(text)
if __name__=='__main__':main()
