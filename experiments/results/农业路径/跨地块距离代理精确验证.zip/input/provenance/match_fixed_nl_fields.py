#!/usr/bin/python3
"""Source-correspondence audit only; no projection, sampling, graph, or route search."""
import pathlib,json,struct,hashlib,re,decimal,collections,time
from fractions import Fraction
from osgeo import ogr,osr
D=pathlib.Path(__file__).resolve().parents[1]
P=D/'sources/NL_2020_EC21.shp';start=time.time()
receipt=json.loads((D/'sources/NL_SHP_RECOVERY_RECEIPT.json').read_text());assert receipt['status']=='VERIFIED_MEMBER_COMPLETE'
panel=json.loads((D/'design/PROPOSED_12_FIELD_PANEL.json').read_text());targets=panel['candidates']
RULES={'purpose':'Prove fixed Fields2Benchmark WKT geometries correspond to official NL_2020 source SHP without reading DBF','target_ids':[r['id'] for r in targets],'required':'One unique source record per fixed candidate; original valid polygon; same part/vertex counts; all source vertices rounded nearest 1e-8 degree half-up exactly equal target WKT, invariant to ring start/direction/order; no simplification, projection, fitting or optimization','bbox_filter_absolute_native_tolerance':'0.0000001','vertex_rounding_grid':'0.00000001','rounding':'ROUND_HALF_UP on exact stored source binary64 value; target original decimal value','quantized_duplicates':'Retain all repeated vertices except one closing vertex; no repair','failure':'No replacement; save all unmatched/ambiguous candidates; do not assume CRS for unmatched','comparison_timestamp_utc':__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat()}
(D/'inventory/SOURCE_MATCH_RULES.json').write_text(json.dumps(RULES,indent=2))
def canon_ring(r):
 assert r[0]==r[-1], 'ring not closed';r=r[:-1]
 best=[]
 for q in [r,list(reversed(r))]:
  lo=min(q)
  for i,x in enumerate(q):
   if x==lo:best.append(tuple(q[i:]+q[:i]))
 return min(best)
def canon(rs):return tuple(sorted(canon_ring(r) for r in rs))
def qdec(d):return int((d*decimal.Decimal(100000000)).to_integral_value(rounding=decimal.ROUND_HALF_UP))
def fq(f):return qdec(decimal.Decimal.from_float(f))
import zipfile
z=zipfile.ZipFile(D/'sources/fields2benchmark_wkt.zip');keys={};tar={}
for t in targets:
 s=z.read(t['source_member']).decode();rings=[[tuple(qdec(decimal.Decimal(x)) for x in p.split()) for p in r.split(',')] for r in re.findall(r'\(([^()]+)\)',s)];key=canon(rings);assert key not in keys;keys[key]=t['id'];tar[t['id']]=t
matches=collections.defaultdict(list);near=[];record_count=0;shape_types=collections.Counter();warnings=[]
outdir=D/'inventory/source_matched_records';outdir.mkdir(exist_ok=True)
with P.open('rb') as f:
 header=f.read(100);assert struct.unpack('>I',header[:4])[0]==9994;assert struct.unpack('>I',header[24:28])[0]*2==P.stat().st_size;assert struct.unpack('<I',header[28:32])[0]==1000
 while True:
  rec_offset=f.tell();h=f.read(8)
  if not h:break
  assert len(h)==8
  recno,nwords=struct.unpack('>2I',h);raw=f.read(nwords*2);assert len(raw)==nwords*2;record_count+=1
  typ=struct.unpack('<I',raw[:4])[0];shape_types[typ]+=1
  if typ==0:continue
  assert typ in (5,15,25),typ
  xmin,ymin,xmax,ymax=struct.unpack('<4d',raw[4:36]);bbox=(xmin,xmax,ymin,ymax)
  possible=[t['id'] for t in targets if max(abs(a-b) for a,b in zip(t['envelope_native'],bbox))<=1e-7]
  if not possible:continue
  nparts,npoints=struct.unpack('<2I',raw[36:44]);parts=list(struct.unpack('<%dI'%nparts,raw[44:44+4*nparts]));points=[struct.unpack('<2d',raw[44+4*nparts+16*i:44+4*nparts+16*(i+1)]) for i in range(npoints)];ends=parts[1:]+[npoints];rings=[points[a:b] for a,b in zip(parts,ends)]
  q=[[tuple(fq(x) for x in p) for p in r] for r in rings]
  try:key=canon(q)
  except AssertionError as e:warnings.append({'source_record':recno,'warning':str(e)});continue
  target=keys.get(key)
  if not target:
   near.append({'source_record':recno,'bbox_candidates':possible,'source_parts':nparts,'source_points':npoints,'source_record_sha256':hashlib.sha256(raw).hexdigest()});continue
  assert target in possible
  mx=max(abs(decimal.Decimal.from_float(v)-decimal.Decimal(fq(v))/decimal.Decimal(100000000)) for p in points for v in p)
  wkt='POLYGON ('+', '.join('('+', '.join(' '.join(repr(x) for x in p) for p in r)+')' for r in rings)+')'
  g=ogr.CreateGeometryFromWkt(wkt);valid=bool(g.IsValid())
  path=outdir/(target+'_source_record.bin');path.write_bytes(h+raw)
  (outdir/(target+'_source_binary64.wkt')).write_text(wkt+'\n')
  match=dict(candidate_id=target,source_record_number=recno,source_record_header_file_offset=rec_offset,source_record_bytes=len(raw)+8,source_record_blob_sha256=hashlib.sha256(h+raw).hexdigest(),source_content_sha256=hashlib.sha256(raw).hexdigest(),source_shp_sha256=receipt['uncompressed_sha256'],source_parts=nparts,source_points_with_closure=npoints,source_polygon_valid=valid,source_crs_prj_sha256=hashlib.sha256((D/'sources/NL_2020_source.prj').read_bytes()).hexdigest(),target_wkt_sha256=tar[target]['source_sha256'],rounded_source_equals_original_target_all_vertices=True,maximum_rounding_abs_degrees=str(mx),only_vertex_rounding_no_simplification=True,canonical_hash=hashlib.sha256(repr(key).encode()).hexdigest())
  matches[target].append(match)
crs=osr.SpatialReference();assert crs.ImportFromESRI([(D/'sources/NL_2020_source.prj').read_text()])==0;crs.AutoIdentifyEPSG();authority=crs.GetAuthorityCode(None)
report=dict(status='ALL_FIXED_FIELDS_UNIQUE_SOURCE_MATCH' if all(len(matches[t['id']])==1 and matches[t['id']][0]['source_polygon_valid'] for t in targets) else 'SOURCE_CORRESPONDENCE_BLOCKED',source_shp_header={'file_code':9994,'version':1000,'shape_type':struct.unpack('<I',header[32:36])[0]},source_record_count=record_count,shape_type_counts=dict(shape_types),source_prj_authority_identified=authority,source_prj_wkt=crs.ExportToWkt(),source_prj_angular_units=crs.GetAngularUnitsName(),matched_candidates=len(matches),matches={t['id']:matches[t['id']] for t in targets},bbox_candidates_without_exact_rounding_match=near,warnings=warnings,elapsed_seconds=time.time()-start,limits=['Source-record match is coordinate-level provenance evidence for these twelve WKT geometries only, not all 350 fields or all NL/EE/LT.', 'No claim about survey accuracy, current field access, crop task reality or field management.'])
(D/'inventory/FIXED_12_SOURCE_CORRESPONDENCE.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
