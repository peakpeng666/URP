"""Metadata classification and declared CRS semantics only. No real-field metric derivation."""
from pathlib import Path
from fractions import Fraction
import json,zipfile,re,datetime
from osgeo import ogr,gdal,osr
from pyproj import CRS,Transformer,__version__
R=Path(__file__).resolve().parents[1];rows=[];groups={};invalid=[]
with zipfile.ZipFile(R/'sources/fields2benchmark_wkt.zip')as z:
 for name in z.namelist():
  if not name.endswith('.wkt'):continue
  text=z.read(name).decode();geom=ogr.CreateGeometryFromWkt(text);ident=Path(name).stem
  rings=[[tuple(Fraction(v)for v in p.split())for p in ring.split(',')]for ring in re.findall(r'\(([^()]+)\)',text)];assert all(r[0]==r[-1]for r in rings)
  n=sum(len(r)-1 for r in rings);holes=len(rings)-1;poly=rings[0][:-1];turn=[]
  for i,p in enumerate(poly):
   a,c=poly[(i-1)%len(poly)],poly[(i+1)%len(poly)];d=(p[0]-a[0])*(c[1]-p[1])-(p[1]-a[1])*(c[0]-p[0]);turn.append((d>0)-(d<0))
  convex=all(v>=0 for v in turn)or all(v<=0 for v in turn);valid=bool(geom.IsValid());stratum='with_hole'if holes else'convex_no_hole'if convex else'concave_no_hole'
  if not valid:invalid.append(ident)
  if ident.startswith('nl_')and valid and not geom.IsEmpty()and geom.GetGeometryName()=='POLYGON'and geom.GetCoordinateDimension()==2 and n<=300:groups.setdefault(stratum,[]).append(ident)
  rows.append({'id':ident,'valid':valid,'vertices':n,'holes':holes,'native_convex':convex,'embedded_CRS':geom.GetSpatialReference()is not None})
selected={k:sorted(v,key=lambda p:int(p.rsplit('_',1)[1]))[:4]for k,v in groups.items()}
assert selected=={'convex_no_hole':['nl_field_40','nl_field_44','nl_field_63','nl_field_187'],'concave_no_hole':['nl_field_1','nl_field_2','nl_field_7','nl_field_8'],'with_hole':['nl_field_17','nl_field_67','nl_field_89','nl_field_143']}
assert len(rows)==350 and all(not r['embedded_CRS']for r in rows)and sorted(invalid)==['nl_field_22','nl_field_32']
prj=(R/'sources/NL_2020_source.prj').read_text();source=CRS.from_wkt(prj);epsg=CRS.from_epsg(4326);assert source.to_epsg()==4326 and source.equals(epsg,ignore_axis_order=True)
assert [a.direction for a in source.axis_info]==['east','north']
# Synthetic CRS plumbing check: no coordinates from any real-field polygon are transformed.
target=CRS.from_epsg(32631);a=Transformer.from_crs(source,target,always_xy=True);b=Transformer.from_crs(epsg,target,always_xy=True);probes=[]
for pt in[(6.0,52.0),(4.0,51.0)]:
 x,y=a.transform(*pt);u,v=b.transform(*pt);assert x==u and y==v;probes.append({'synthetic_lon_lat':pt,'same_always_xy_result':True})
stricta=osr.SpatialReference();stricta.ImportFromWkt(prj);strictb=osr.SpatialReference();strictb.ImportFromEPSG(4326);stricta.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER);strictb.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
out={'status':'PASS_METADATA_AND_DECLARED_SOURCE_CRS','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'independent_inventory_records':350,'selected_panel_reproduced':selected,'invalid_originals_retained':invalid,'source_PRJ_recognized_EPSG':4326,'source_axis_order':['longitude','latitude'],'pyproj_equals_EPSG4326_ignoring_axis_order':True,'pyproj_version':__version__,'GDAL_version':gdal.VersionInfo(),'synthetic_axis_pipeline_probes':probes,'strict_GDAL_IsSame_observed':bool(stricta.IsSame(strictb)),'strict_equality_note':'GDAL strict IsSame is false for these CRS object representations; it is not used as proof of identical axis order. Original PRJ is longitude/latitude; EPSG registry geographic axes are latitude/longitude. Use original PRJ and explicit always_xy/traditional-GIS convention, not an implicit axis assumption.','real_field_projection_performed':False,'buffer_sampling_graph_or_solver_performed':False,'selection_note':'Native convexity is a frozen stratification label only, not a guarantee of projected/C convexity or E=G.'}
(R/'independent_supervision/METADATA_SELECTION_CRS_REVIEW.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out,ensure_ascii=False))
