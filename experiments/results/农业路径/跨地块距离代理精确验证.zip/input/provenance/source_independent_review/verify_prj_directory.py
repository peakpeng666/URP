"""Independent bounded same-ZIP PRJ proof. Requests EOCD, directory and PRJ only; no DBF ranges."""
from pathlib import Path
import urllib.request,struct,zlib,json,hashlib,datetime
R=Path(__file__).resolve().parents[1];O=Path(__file__).parent
url='https://zenodo.org/api/records/8229128/files/NL_2020.zip/content';size=283022062;parts=[]
def get(start,end,name):
 assert 0<=start<=end<size and end-start+1<=4096
 request=urllib.request.Request(url,headers={'Range':f'bytes={start}-{end}'})
 with urllib.request.urlopen(request,timeout=20)as response:
  assert response.status==206 and response.headers.get('Content-Range')==f'bytes {start}-{end}/{size}'
  data=response.read(end-start+2);assert len(data)==end-start+1
  (O/name).write_bytes(data);parts.append({'start':start,'end':end,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'local_file':name,'content_range':response.headers.get('Content-Range')});return data
end=get(size-22,size-1,'NL_ZIP_EOCD.bin');e=struct.unpack('<4s4H2IH',end);assert e[0]==b'PK\x05\x06'and e[-1]==0 and e[1]==e[2]==0;directory_size,directory_offset=e[5],e[6];assert directory_size<=4096
raw=get(directory_offset,directory_offset+directory_size-1,'NL_ZIP_CENTRAL_DIRECTORY.bin');members=[];pos=0
while pos<len(raw):
 row=struct.unpack('<4s6H3I5H2I',raw[pos:pos+46]);assert row[0]==b'PK\x01\x02';nl,extra,comment=row[10:13];name=raw[pos+46:pos+46+nl].decode();members.append({'name':name,'method':row[4],'crc32':row[7],'compressed_size':row[8],'uncompressed_size':row[9],'local_offset':row[16]});pos+=46+nl+extra+comment
assert len(members)==e[4]and pos==len(raw)
prj=next(m for m in members if m['name']=='NL_2020_EC21.prj');shp=next(m for m in members if m['name']=='NL_2020_EC21.shp');off=prj['local_offset'];header=get(off,off+29,'NL_PRJ_LOCAL_HEADER.bin');a=struct.unpack('<4s5H3I2H',header);assert a[0]==b'PK\x03\x04';n,x=a[-2:];compressed=get(off+30,off+30+n+x+prj['compressed_size']-1,'NL_PRJ_NAME_EXTRA_COMPRESSED.bin');assert compressed[:n].decode()==prj['name'];data=zlib.decompress(compressed[n+x:],-15);assert len(data)==prj['uncompressed_size']and zlib.crc32(data)==prj['crc32'];assert data==(R/'sources/NL_2020_source.prj').read_bytes()
receipt=json.loads((R/'sources/NL_SHP_RECOVERY_RECEIPT.json').read_text());assert shp==receipt['member']and receipt['url']==url
crc=0
with(R/'sources/NL_2020_EC21.shp').open('rb')as f:
 for b in iter(lambda:f.read(1024*1024),b''):crc=zlib.crc32(b,crc)
assert crc==shp['crc32']
out={'status':'PASS_SAME_OFFICIAL_ZIP_SHP_AND_PRJ','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'url':url,'archive_bytes':size,'whole_archive_downloaded':False,'whole_archive_md5_verified':False,'independent_ranges':parts,'all_ranges_exclude_DBF_payload':True,'shp_member':shp,'shp_full_local_crc32_verified':crc,'prj_member':prj,'prj_sha256':hashlib.sha256(data).hexdigest(),'prj_text':data.decode(),'source_PRJ_bytes_match_author_copy':True,'metadata_only_no_projection_or_optimizer':True}
(O/'SAME_ZIP_PRJ_REVIEW.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k not in['independent_ranges','prj_text']}))
