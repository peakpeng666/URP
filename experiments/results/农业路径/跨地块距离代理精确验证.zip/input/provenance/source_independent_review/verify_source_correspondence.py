"""Read-only independent SHP/WKT correspondence. No projection, buffering, sampling, graphs, or optimization."""
from pathlib import Path
import hashlib,json,re,struct,zipfile,math,datetime,resource,signal
R=Path(__file__).resolve().parents[1]
def load(p):return json.loads(Path(p).read_text())
def digest(path):
 h=hashlib.sha256()
 with Path(path).open('rb')as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def canonical(r):
 assert r[0]==r[-1];r=r[:-1];options=[]
 for sequence in[r,list(reversed(r))]:
  m=min(sequence)
  for i,p in enumerate(sequence):
   if p==m:options.append(tuple(sequence[i:]+sequence[:i]))
 return min(options)
def normalize(rings):return tuple(sorted(canonical(r)for r in rings))
def parse_wkt(s):
 assert s.strip().upper().startswith('POLYGON')
 rings=[]
 for ring in re.findall(r'\(([^()]+)\)',s):
  points=[tuple(map(float,p.split()))for p in ring.split(',')];assert all(len(p)==2 and all(math.isfinite(x)for x in p)for p in points);rings.append(points)
 return rings
def binary_signature(norm):return b''.join(struct.pack('<I',len(r))+b''.join(struct.pack('<2d',*p)for p in r)for r in norm)
def main():
 resource.setrlimit(resource.RLIMIT_CPU,(60,60));resource.setrlimit(resource.RLIMIT_AS,(256*1024**2,256*1024**2));signal.alarm(120)
 proposal=load(R/'design/PROPOSED_12_FIELD_PANEL.json');shp=R/'sources/NL_2020_EC21.shp';receipt=load(R/'sources/NL_SHP_RECOVERY_RECEIPT.json');assert receipt['status']=='VERIFIED_MEMBER_COMPLETE'
 assert digest(shp)==receipt['uncompressed_sha256']=='1e870b283bbae7ebeec6cf1335d61aee6eb233318eda67495a6c055844a55adf'
 zpath=R/'sources/fields2benchmark_wkt.zip';assert digest(zpath)==proposal['source_zip_sha256'];targets={};bbox_index={}
 with zipfile.ZipFile(zpath)as z:
  for q in proposal['candidates']:
   raw=z.read(q['source_member']);assert hashlib.sha256(raw).hexdigest()==q['source_sha256'];rings=parse_wkt(raw.decode());norm=normalize(rings);pts=[p for ring in rings for p in ring];box=(min(p[0]for p in pts),min(p[1]for p in pts),max(p[0]for p in pts),max(p[1]for p in pts));targets[q['id']]={'source_wkt_sha256':q['source_sha256'],'signature':binary_signature(norm),'rings':rings,'bbox':box,'matches':[]};bbox_index.setdefault(box,[]).append(q['id'])
 count=0;nulls=0;types={}
 with shp.open('rb')as f:
  header=f.read(100);assert struct.unpack('>i',header[:4])[0]==9994;assert struct.unpack('>i',header[24:28])[0]*2==shp.stat().st_size;assert struct.unpack('<2i',header[28:36])==(1000,5)
  while True:
   offset=f.tell();head=f.read(8)
   if not head:break
   assert len(head)==8;number,words=struct.unpack('>2i',head);length=2*words;count+=1;assert number==count and length>=4
   kind=struct.unpack('<i',f.read(4))[0];types[kind]=types.get(kind,0)+1
   if kind==0:nulls+=1;f.seek(length-4,1);continue
   assert kind==5 and length>=44
   bounds=struct.unpack('<4d',f.read(32))
   if bounds not in bbox_index:f.seek(length-36,1);continue
   tail=f.read(length-36);assert len(tail)==length-36;parts,points=struct.unpack('<2i',tail[:8]);starts=list(struct.unpack('<'+str(parts)+'i',tail[8:8+4*parts]));assert starts[0]==0 and starts==sorted(set(starts))and starts[-1]<points
   data=tail[8+4*parts:];assert len(data)==16*points;xy=list(struct.iter_unpack('<2d',data));rings=[xy[starts[i]:starts[i+1]if i+1<parts else points]for i in range(parts)];norm=normalize(rings);sig=binary_signature(norm)
   for ident in bbox_index[bounds]:
    if sig==targets[ident]['signature']:
     full=head+struct.pack('<i4d',kind,*bounds)+tail;local=R/'inventory/source_matched_records'/f'{ident}_source_record.bin';assert full==local.read_bytes()
     targets[ident]['matches'].append({'record_number_1_based':number,'record_header_offset_bytes':offset,'record_bytes':len(full),'record_sha256':hashlib.sha256(full).hexdigest(),'ring_count':parts,'points_including_closure':points,'coordinate_binary64_bitwise_equal_after_ring_canonicalization':True})
  assert f.tell()==shp.stat().st_size
 assert count==767034
 rows=[]
 for ident,q in targets.items():
  assert len(q['matches'])==1;assert q['matches'][0]['record_number_1_based']==int(ident.rsplit('_',1)[1]);rows.append({'id':ident,'original_wkt_sha256':q['source_wkt_sha256'],**q['matches'][0]})
 out={'status':'PASS_EXACT_SELECTED_SOURCE_CORRESPONDENCE','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_shp_sha256':receipt['uncompressed_sha256'],'source_official_zip_record':receipt['source_record'],'whole_zip_was_not_downloaded_or_digest_verified':True,'records_independently_scanned':count,'shape_types':types,'null_records':nulls,'selected_targets':12,'unique_exact_binary64_matches':12,'rows':rows,'method':'Independent stdlib SHP binary parser and original WKT parser; full source-record scan with exact raw bbox prefilter and binary64 coordinate bit equality after ring-start/direction/ring-order canonicalization. No tolerance or author match functions used. Record fragments compared byte-for-byte.','projection_performed':False,'optimizer_calls':0,'limitations':['Only12fixedNLfiles matched; no inference to untested benchmark countries/files','SHP member was recovered over official HTTPS Range and its recorded ZIP CRC; full-countryZIP MD5 not verified by this review','Separate same-archive PRJ provenance and CRS semantics must be reviewed before metric work']}
 with(R/'independent_supervision/EXACT_SOURCE_CORRESPONDENCE_REVIEW.json').open('x')as f:json.dump(out,f,ensure_ascii=False,indent=2);f.write('\n')
 print(json.dumps({k:v for k,v in out.items()if k!='rows'},ensure_ascii=False))
if __name__=='__main__':main()
