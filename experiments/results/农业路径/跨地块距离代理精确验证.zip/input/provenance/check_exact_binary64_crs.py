#!/usr/bin/python3
"""Strong source-correspondence check. No tolerance is used for binary64 equality."""
from pathlib import Path
import json,struct,re,zipfile,hashlib
from fractions import Fraction
from pyproj import CRS,__version__
D=Path(__file__).resolve().parents[1]
rep=json.loads((D/'inventory/FIXED_12_SOURCE_CORRESPONDENCE.json').read_text());z=zipfile.ZipFile(D/'sources/fields2benchmark_wkt.zip')
def canon_ring(r):
 assert r[0]==r[-1];r=r[:-1];out=[]
 for v in [r,list(reversed(r))]:
  for i,x in enumerate(v):
   if x==min(v):out.append(tuple(v[i:]+v[:i]))
 return min(out)
def canon(rs):return tuple(sorted(canon_ring(r) for r in rs))
proofs=[]
for fid,entries in rep['matches'].items():
 assert len(entries)==1
 raw=(D/'inventory/source_matched_records'/f'{fid}_source_record.bin').read_bytes()[8:]
 np,nv=struct.unpack('<2I',raw[36:44]);starts=list(struct.unpack('<%dI'%np,raw[44:44+4*np]));pts=[struct.unpack('<2d',raw[44+4*np+16*i:44+4*np+16*(i+1)]) for i in range(nv)];rs=[pts[a:b] for a,b in zip(starts,starts[1:]+[nv])]
 s=z.read('wkt/'+fid+'.wkt').decode();tr=[[tuple(float(v) for v in p.split()) for p in r.split(',')] for r in re.findall(r'\(([^()]+)\)',s)]
 targetrat=[[tuple(Fraction(v) for v in p.split()) for p in r.split(',')] for r in re.findall(r'\(([^()]+)\)',s)]
 err=max(abs(Fraction.from_float(float(v))-v) for r in targetrat for pt in r for v in pt)
 proofs.append(dict(id=fid,source_record=entries[0]['source_record_number'],source_binary64_equals_target_decimal_parsed_to_binary64=canon(rs)==canon(tr),source_all_ring_vertex_counts_match=sorted(len(r) for r in rs)==sorted(len(r) for r in tr),exact_max_decimal_to_binary64_error_fraction=str(err),error_float_degrees=float(err),no_coordinate_transform_or_geometry_simplification=True))
c=CRS.from_wkt((D/'sources/NL_2020_source.prj').read_text());proof=dict(status='PASS' if all(r['source_binary64_equals_target_decimal_parsed_to_binary64'] and r['source_all_ring_vertex_counts_match'] for r in proofs) else 'FAIL',crs=dict(source_prj_sha256=hashlib.sha256((D/'sources/NL_2020_source.prj').read_bytes()).hexdigest(),pyproj_version=__version__,to_epsg=c.to_epsg(),equals_epsg4326_ignoring_axis_order=c.equals(CRS.from_epsg(4326),ignore_axis_order=True),source_crs_json=c.to_json_dict(),source_axis_info=[str(a) for a in c.axis_info]),fields=proofs)
(D/'inventory/EXACT_BINARY64_CRS_CORRESPONDENCE.json').write_text(json.dumps(proof,indent=2));print(proof['status'],len(proofs),'fixed fields; no projection or route computations')
