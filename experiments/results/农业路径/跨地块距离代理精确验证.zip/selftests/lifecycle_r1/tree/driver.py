import sys,pathlib
sys.path.insert(0,'/workspace/shared/cross_field_distance_proxy_exact_20261009/source')
from tree_runtime import run_command
run_command(["/usr/bin/python3",'/workspace/shared/cross_field_distance_proxy_exact_20261009/selftests/lifecycle_r1/tree/fork.py'],pathlib.Path('/workspace/shared/cross_field_distance_proxy_exact_20261009/selftests/lifecycle_r1/tree/worker'),5,134217728,300,pathlib.Path('/workspace/shared/cross_field_distance_proxy_exact_20261009/selftests/lifecycle_r1/tree/active/worker.active.json'))
