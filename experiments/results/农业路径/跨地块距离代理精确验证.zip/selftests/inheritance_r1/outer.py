import sys,resource,json,pathlib
sys.path.insert(0,'/workspace/shared/cross_field_distance_proxy_exact_20261009/source')
from tree_runtime import run_command
from launch_main_once import author_outer_limits
limits=author_outer_limits()
r=run_command(["/usr/bin/python3",'/workspace/shared/cross_field_distance_proxy_exact_20261009/selftests/inheritance_r1/supervisor.py'],pathlib.Path('/workspace/shared/cross_field_distance_proxy_exact_20261009/selftests/inheritance_r1/supervisor'),60,536870912,10,pathlib.Path('/workspace/shared/cross_field_distance_proxy_exact_20261009/selftests/inheritance_r1/supervisor.active.json'),cpu_hard=120,as_hard=1073741824)
print(json.dumps({"outer_limits":limits,"supervisor":r}))
