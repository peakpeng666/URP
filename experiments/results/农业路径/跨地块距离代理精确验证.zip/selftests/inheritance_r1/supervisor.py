import sys,resource,json,pathlib
sys.path.insert(0,'/workspace/shared/cross_field_distance_proxy_exact_20261009/source')
from tree_runtime import run_command
limits={"cpu":list(resource.getrlimit(resource.RLIMIT_CPU)),"as":list(resource.getrlimit(resource.RLIMIT_AS))}
r=run_command(["/usr/bin/python3",'/workspace/shared/cross_field_distance_proxy_exact_20261009/selftests/inheritance_r1/worker.py'],pathlib.Path('/workspace/shared/cross_field_distance_proxy_exact_20261009/selftests/inheritance_r1/worker'),120,1073741824,5,pathlib.Path('/workspace/shared/cross_field_distance_proxy_exact_20261009/selftests/inheritance_r1/worker.active.json'))
print(json.dumps({"supervisor_limits":limits,"worker":r}))
