import resource,json
print(json.dumps({"cpu":list(resource.getrlimit(resource.RLIMIT_CPU)),"as":list(resource.getrlimit(resource.RLIMIT_AS))}))
