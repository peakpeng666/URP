#!/usr/bin/env python3
"""Exhaustive fixed-fleet CVRP on exact-covered polygon visibility distances.
The complete canonical plan space is enumerated: no pruning by route objectives.
"""
import csv, datetime, gzip, hashlib, itertools, json, math, os, platform, resource, signal, sys, time, traceback
from pathlib import Path
sys.dont_write_bytecode=True
from geometry import covered_point, covered_segment
from independent_geometry import point_in_union, segment_in_union
from original_geometry_experiment import check_decomposition, dijkstra, distance
from matrix_oracle import solve as dp_solve
ROOT=Path(__file__).resolve().parents[1]
TOL=1e-9

def dump(p,x):
    with p.open('x') as f: json.dump(x,f,ensure_ascii=False,indent=2,allow_nan=False); f.write('\n')
def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def verify_freeze():
    z=json.loads((ROOT/'freeze/PRE_RUN_FREEZE.json').read_text())
    for path,h in z['sha256'].items(): assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==h,path

def geometry(inst):
    services=inst['coordinates']; poly=inst['polygon']; rects=inst['rectangle_decomposition']
    validation=check_decomposition(inst)
    nodes=[]
    for p in poly+services:
        if p not in nodes: nodes.append(p)
    sn=[nodes.index(p) for p in services]
    assert all(covered_point(p,poly) and point_in_union(p,rects) for p in nodes)
    adj=[[] for _ in nodes]; edges=[]; pairs=[]
    for i,a in enumerate(nodes):
        for j in range(i+1,len(nodes)):
            b=nodes[j]; ok=covered_segment(a,b,poly); other=segment_in_union(a,b,rects)
            assert ok==other
            pairs.append({'nodes':[i,j],'covered':ok,'independent_covered':other})
            if ok:
                d=distance(a,b); adj[i].append((j,d)); adj[j].append((i,d)); edges.append({'nodes':[i,j],'distance':d})
    E=[[distance(a,b) for b in services] for a in services]
    G=[[0.]*len(services) for _ in services]; paths=[[None]*len(services) for _ in services]
    direct=[[covered_segment(a,b,poly) for b in services] for a in services]
    dijk=[]
    for source in sn: dijk.append(dijkstra(nodes,adj,source))
    # One path per unordered pair; reverse exactly. Visible straight legs are already shortest.
    # This removes direction-dependent floating accumulation without any geometric relaxation.
    for i in range(len(services)):
        for j in range(i,len(services)):
            ns=[sn[i]] if i==j else ([sn[i],sn[j]] if direct[i][j] else list(dijk[i][1][sn[j]]))
            pts=[nodes[t] for t in ns]; value=math.fsum(distance(a,b) for a,b in zip(pts,pts[1:]))
            assert abs(value-dijk[i][0][sn[j]])<=TOL
            assert abs(value-dijk[j][0][sn[i]])<=TOL
            assert all(covered_segment(a,b,poly) and segment_in_union(a,b,rects) for a,b in zip(pts,pts[1:]))
            G[i][j]=G[j][i]=value
            paths[i][j]={'node_ids':ns,'points':pts,'cost':value}
            paths[j][i]={'node_ids':list(reversed(ns)),'points':list(reversed(pts)),'cost':value}
    fw=[[math.inf]*len(nodes) for _ in nodes]
    for i in range(len(nodes)):
        fw[i][i]=0.
        for j in range(i+1,len(nodes)):
            if segment_in_union(nodes[i],nodes[j],rects): fw[i][j]=fw[j][i]=distance(nodes[i],nodes[j])
    for k in range(len(nodes)):
        for i in range(len(nodes)):
            for j in range(len(nodes)): fw[i][j]=min(fw[i][j],fw[i][k]+fw[k][j])
    ferr=max(abs(G[i][j]-fw[sn[i]][sn[j]]) for i in range(10) for j in range(10))
    assert ferr<=TOL
    assert all(G[i][j]>=E[i][j]-TOL for i in range(10) for j in range(10))
    if inst['family']=='rect': assert E==G and all(all(r) for r in direct)
    validation.update({'visibility_pairs':len(pairs),'floyd_max_abs_error':ferr,'geometric_tolerance':0,
        'all_pair_actual_path_checks':100,'distance_symmetrization':'lower-service-index path and its exact reverse; visible direct edge retained'})
    return {'services':services,'nodes':nodes,'service_node_ids':sn,'euclidean_matrix':E,'legal_matrix':G,
        'legal_leg_paths':paths,'direct_covered_matrix':direct,'visibility_edges':edges,'visibility_checks':pairs,'validation':validation}

def route_space(demand,Q):
    n=len(demand)-1; loads=[0]*(1<<n); routes={}
    for mask in range(1,1<<n):
        bit=mask&-mask; loads[mask]=loads[mask^bit]+demand[bit.bit_length()]
        if loads[mask]<=Q:
            nodes=[i+1 for i in range(n) if mask>>i&1]
            routes[mask]=[p for p in itertools.permutations(nodes) if p<=p[::-1]]
    return loads,routes

def partitions(mask,k,loads,Q,routes):
    if mask==0:
        if k==0: yield ()
        return
    if k==0 or mask.bit_count()<k or loads[mask]>k*Q: return
    anchor=mask&-mask; sub=mask
    while sub:
        if sub&anchor and sub in routes:
            for rest in partitions(mask^sub,k-1,loads,Q,routes): yield (sub,)+rest
        sub=(sub-1)&mask

def canonical(plan): return tuple(sorted(min(p,p[::-1]) for p in plan))
def route_key(plan): return '|'.join('-'.join(map(str,r)) for r in plan)
def all_costs(plan,D): return math.fsum(D[a][b] for r in plan for a,b in zip((0,)+r,r+(0,)))

def enumerate_all(inst,geom,out):
    E,G=geom['euclidean_matrix'],geom['legal_matrix']; demand=inst['demands']; Q=inst['capacity']; K=inst['max_vehicles']
    loads,routes=route_space(demand,Q); n=len(demand)-1; records=[]; part_count=0
    path=out/'all_canonical_plans.csv.gz'
    with gzip.open(path,'wt',newline='') as f:
        w=csv.writer(f); w.writerow(['index','canonical_routes','euclidean_cost','legal_cost'])
        for parts in partitions((1<<n)-1,K,loads,Q,routes):
            part_count+=1
            for combination in itertools.product(*(routes[s] for s in parts)):
                plan=canonical(combination); e=all_costs(plan,E); g=all_costs(plan,G)
                records.append((e,g,plan)); w.writerow([len(records)-1,route_key(plan),repr(e),repr(g)])
    assert records
    # No tolerance in the primary selection. Secondary exact-float tie key is canonical plan.
    eopt=min(records,key=lambda x:(x[0],x[2])); gopt=min(records,key=lambda x:(x[1],x[2]))
    def band(index,minimum,width):
        matches=[r for r in records if (r[index]==minimum if width==0 else r[index]<=minimum+width)]
        lo=min(matches,key=lambda r:(r[1],r[2])); hi=max(matches,key=lambda r:(r[1],r[2]))
        return {'count':len(matches),'width_absolute':width,'minimum_legal_cost':lo[1],'maximum_legal_cost':hi[1],
            'minimum_legal_plan':lo[2],'maximum_legal_plan':hi[2],
            'minimum_relative_regret':(lo[1]-gopt[1])/gopt[1],'maximum_relative_regret':(hi[1]-gopt[1])/gopt[1]}
    ties={'euclidean_exact_float_optima':band(0,eopt[0],0.),'euclidean_within_1e_9':band(0,eopt[0],TOL),
        'legal_exact_float_optima_count':sum(r[1]==gopt[1] for r in records),
        'interpretation':'Complete canonical plan enumeration. 1e-9 is an objective-only sensitivity band, never geometric tolerance. No formal algebraic tie certificate.'}
    def next_gap(index,v): return min((r[index]-v for r in records if r[index]>v),default=None)
    # Independently ordered audited Held-Karp/partition DP adapted only to take a matrix.
    dp={}
    for name,D,opt in [('euclidean',E,eopt[0]),('legal',G,gopt[1])]:
        z=dp_solve(inst,D); assert z['by_k']['1'] is None and z['by_k']['2'] is None
        d=z['by_k']['3']; assert d and d['nonempty_routes']==3 and abs(d['cost']-opt)<=TOL
        dp[name]={'solution':d,'absolute_difference_from_full_enumeration':abs(d['cost']-opt),
            'held_karp_states':z['held_karp_states'],'held_karp_transitions':z['held_karp_transitions'],
            'partition_states':z['partition_states'],'partition_transitions':z['partition_transitions'],
            'K1_infeasible':True,'K2_infeasible':True}
    return eopt,gopt,{'canonical_feasible_plan_count':len(records),'feasible_unlabelled_customer_partitions':part_count,
        'capacity_feasible_subsets':len(routes),'canonical_feasible_single_routes':sum(map(len,routes.values())),
        'euclidean_next_distinct_float_gap':next_gap(0,eopt[0]),'legal_next_distinct_float_gap':next_gap(1,gopt[1]),
        'tie_sensitivity':ties,'audited_dp_crosscheck':dp}

def solution_record(inst,geom,plan):
    E,G=geom['euclidean_matrix'],geom['legal_matrix']; services=inst['coordinates']; poly=inst['polygon']; rects=inst['rectangle_decomposition']
    assert len(plan)==3 and canonical(plan)==plan
    customers=[t for r in plan for t in r]; assert sorted(customers)==list(range(1,10))
    route_out=[]; illegal=[]; path_checks=0
    for rid,r in enumerate(plan):
        load=sum(inst['demands'][t] for t in r); assert load<=9
        stops=(0,)+r+(0,); legs=[]; polyline=[services[0]]
        for a,b in zip(stops,stops[1:]):
            ok=covered_segment(services[a],services[b],poly)
            assert ok==segment_in_union(services[a],services[b],rects)==geom['direct_covered_matrix'][a][b]
            if not ok: illegal.append({'vehicle':rid,'from':a,'to':b})
            p=geom['legal_leg_paths'][a][b]['points']; polyline.extend(p[1:])
            assert p[0]==services[a] and p[-1]==services[b]
            for u,v in zip(p,p[1:]):
                assert covered_segment(u,v,poly) and segment_in_union(u,v,rects); path_checks+=1
            lc=math.fsum(distance(u,v) for u,v in zip(p,p[1:])); assert abs(lc-G[a][b])<=TOL
            legs.append({'from':a,'to':b,'direct_covered':ok,'euclidean_cost':E[a][b],'legal_path':p,'legal_cost':lc})
        recost=math.fsum(distance(a,b) for a,b in zip(polyline,polyline[1:]))
        assert abs(recost-all_costs((r,),G))<=TOL
        route_out.append({'vehicle':rid,'customers':r,'stops':stops,'load':load,'legal_polyline':polyline,
            'legal_polyline_cost':recost,'euclidean_cost':all_costs((r,),E),'legal_cost':all_costs((r,),G),'legs':legs})
    e,g=all_costs(plan,E),all_costs(plan,G)
    assert abs(math.fsum(r['legal_polyline_cost'] for r in route_out)-g)<=TOL
    return {'canonical_plan':plan,'vehicle_count':3,'customer_count':9,'coverage_exactly_once':True,'capacity_valid':True,
        'euclidean_cost':e,'legal_cost':g,'routes':route_out,'direct_illegal_legs':illegal,
        'direct_illegal_leg_count':len(illegal),'total_service_legs':12,'path_segments_rechecked':path_checks}

def run_instance(inst):
    t0=time.perf_counter(); out=ROOT/'raw'/inst['instance_id']; out.mkdir()
    geom=geometry(inst); dump(out/'matrices_and_paths.json',geom)
    e,g,enumeration=enumerate_all(inst,geom,out)
    es,gs=solution_record(inst,geom,e[2]),solution_record(inst,geom,g[2])
    assert e[1]>=g[1]-TOL and e[1]>=e[0]-TOL
    regret=e[1]-g[1]; bias=e[1]-e[0]
    if inst['family']=='rect': assert bias==0 and regret==0 and es['direct_illegal_leg_count']==0 and es['canonical_plan']==gs['canonical_plan']
    # Assignment change is descriptive, never selected after observing the result.
    assignment=lambda p: sorted(sorted(r) for r in p)
    result={'instance_id':inst['instance_id'],'base_field_id':inst['base_field_id'],'family':inst['family'],'status':'PASS',
        'euclidean_optimal_cost':e[0],'euclidean_plan_legal_cost':e[1],'legal_optimal_cost':g[1],
        'euclidean_direct_illegal_legs':es['direct_illegal_leg_count'],'total_service_legs':12,
        'legal_repair_estimation_bias_absolute':bias,'legal_repair_estimation_bias_relative_to_euclidean':bias/e[0],
        'reoptimization_saved_absolute':regret,'reoptimization_relative_regret_to_legal_optimum':regret/g[1],
        'reoptimization_savings_fraction_of_repaired_euclidean':regret/e[1],
        'task_assignment_changed':assignment(e[2])!=assignment(g[2]),'canonical_plan_changed':e[2]!=g[2],
        'euclidean_solution':es,'legal_solution':gs,'enumeration':enumeration,'wall_seconds':time.perf_counter()-t0}
    dump(out/'result.json',result); return result

def main():
    resource.setrlimit(resource.RLIMIT_CPU,(90,90)); signal.alarm(150)
    t0,c0=time.perf_counter(),time.process_time(); verify_freeze()
    dump(ROOT/'evidence/STARTED.json',{'utc':utc(),'pid':os.getpid(),'main_run_number':1})
    insts=json.loads((ROOT/'input/instances.json').read_text()); results=[]; failures=[]
    for inst in insts:
        try:
            result=run_instance(inst); results.append(result)
            print(json.dumps({k:result[k] for k in ['instance_id','status','euclidean_optimal_cost','euclidean_plan_legal_cost','legal_optimal_cost','reoptimization_relative_regret_to_legal_optimum']},ensure_ascii=False),flush=True)
        except Exception as e:
            failure={'instance_id':inst['instance_id'],'error':str(e),'traceback':traceback.format_exc()}
            failures.append(failure); print(json.dumps(failure),flush=True)
    dump(ROOT/'raw/failures.json',failures)
    status={'status':'PASS' if len(results)==12 and not failures else 'FAIL','utc':utc(),'main_run_number':1,
        'planned_fields':12,'attempted_fields':len(insts),'completed_fields':len(results),'failed_fields':len(failures),
        'cpu_seconds':time.process_time()-c0,'wall_seconds':time.perf_counter()-t0,'cpu_limit_seconds':90,'wall_limit_seconds':150,
        'max_rss_kb':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'python':sys.version,'platform':platform.platform(),
        'model_api_calls':0,'new_installs':0,'purchases':0,'uploads':0,'new_paid_external_cost':0,'currency':'USD',
        'compute_monetary_cost':'Unmetered local cloud CPU; no monetary rate or billed CPU charge is exposed.',
        'geometric_tolerance':0,'objective_validation_and_sensitivity_band':TOL}
    dump(ROOT/'evidence/RUN_STATUS.json',status); print(json.dumps(status),flush=True)
    return 0 if status['status']=='PASS' else 1
if __name__=='__main__': sys.exit(main())
