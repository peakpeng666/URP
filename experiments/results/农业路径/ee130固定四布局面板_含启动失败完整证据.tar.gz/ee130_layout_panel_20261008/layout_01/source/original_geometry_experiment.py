#!/usr/bin/env python3
"""One frozen bounded computation; no model, network, installation or external writes."""
import csv,hashlib,heapq,itertools,json,math,platform,resource,signal,sys,time,traceback
from fractions import Fraction as F
from pathlib import Path
from geometry import covered_point,covered_segment,validate_polygon
from independent_geometry import point_in_union,segment_in_union
ROOT=Path(__file__).resolve().parents[1]
TOL=1e-9

def dump(p,x): p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def distance(a,b): return math.hypot(a[0]-b[0],a[1]-b[1])
def check_decomposition(inst):
    poly=inst['polygon']; rects=inst['rectangle_decomposition']
    area=validate_polygon(poly)
    # All polygon/rectangle supporting coordinates induce cells on which membership is constant.
    xs=sorted({p[0] for p in poly}|{r[k] for r in rects for k in [0,2]})
    ys=sorted({p[1] for p in poly}|{r[k] for r in rects for k in [1,3]})
    xx=sorted(set(xs)|{F(a+b,2) for a,b in zip(xs,xs[1:])})
    yy=sorted(set(ys)|{F(a+b,2) for a,b in zip(ys,ys[1:])})
    checks=0
    for x in xx:
        for y in yy:
            assert covered_point((x,y),poly)==point_in_union((x,y),rects),'Decomposition mismatch'
            checks+=1
    assert sum((x1-x0)*(y1-y0) for x0,y0,x1,y1 in rects)==area
    return {'polygon_area':area,'cell_arrangement_point_checks':checks}

def dijkstra(nodes,adj,source):
    dist=[math.inf]*len(nodes); paths=[None]*len(nodes)
    dist[source]=0.; paths[source]=(source,)
    queue=[(0.,(source,),source)]
    while queue:
        d,path,u=heapq.heappop(queue)
        if (d,path)!=(dist[u],paths[u]): continue
        for v,w in adj[u]:
            cand=(d+w,path+(v,))
            if cand[0]<dist[v] or (cand[0]==dist[v] and (paths[v] is None or cand[1]<paths[v])):
                dist[v],paths[v]=cand; heapq.heappush(queue,(cand[0],cand[1],v))
    assert all(math.isfinite(d) for d in dist),'Disconnected visibility graph'
    return dist,paths

def run_instance(inst):
    start=time.perf_counter(); poly=inst['polygon']; rects=inst['rectangle_decomposition']
    validation=check_decomposition(inst)
    services=[inst['depot']]+inst['tasks']
    assert len(services)==8 and len({tuple(p) for p in services})==8
    nodes=[]
    for p in poly+services:
        if p not in nodes: nodes.append(p)
    for p in nodes: assert covered_point(p,poly) and point_in_union(p,rects)
    service_nodes=[nodes.index(p) for p in services]
    graph=[]; edge_checks=[]; adj=[[] for _ in nodes]
    for i,a in enumerate(nodes):
        for j in range(i+1,len(nodes)):
            b=nodes[j]; covered=covered_segment(a,b,poly)
            independent=segment_in_union(a,b,rects)
            assert covered==independent,('Coverage mismatch',i,j)
            edge_checks.append({'i':i,'j':j,'covered':covered,'independent_covered':independent})
            if covered:
                w=distance(a,b); graph.append({'i':i,'j':j,'length':w})
                adj[i].append((j,w)); adj[j].append((i,w))
    euclidean=[[distance(a,b) for b in services] for a in services]
    geo=[]; leg_paths=[]; path_segments_checked=0
    for si,source in enumerate(service_nodes):
        ds,paths=dijkstra(nodes,adj,source); geo.append([ds[t] for t in service_nodes])
        row=[]
        for sj,target in enumerate(service_nodes):
            path=paths[target]; pts=[nodes[n] for n in path]
            length=math.fsum(distance(a,b) for a,b in zip(pts,pts[1:]))
            assert abs(length-ds[target])<=TOL
            assert pts[0]==services[si] and pts[-1]==services[sj]
            for a,b in zip(pts,pts[1:]):
                assert covered_segment(a,b,poly) and segment_in_union(a,b,rects)
                path_segments_checked+=1
            row.append({'node_ids':path,'points':pts,'length_recomputed':length})
        leg_paths.append(row)
    for i in range(8):
        for j in range(8):
            assert abs(geo[i][j]-geo[j][i])<=TOL
            assert geo[i][j]>=euclidean[i][j]-TOL
    # Independent all-pairs Floyd-Warshall on independently covered edges and recomputed lengths.
    fw=[[math.inf]*len(nodes) for _ in nodes]
    for i in range(len(nodes)): fw[i][i]=0.
    for i in range(len(nodes)):
        for j in range(i+1,len(nodes)):
            if segment_in_union(nodes[i],nodes[j],rects): fw[i][j]=fw[j][i]=distance(nodes[i],nodes[j])
    for k in range(len(nodes)):
        for i in range(len(nodes)):
            for j in range(len(nodes)):
                fw[i][j]=min(fw[i][j],fw[i][k]+fw[k][j])
    fw_error=max(abs(geo[i][j]-fw[u][v]) for i,u in enumerate(service_nodes) for j,v in enumerate(service_nodes))
    assert fw_error<=TOL
    # Both directions for all 5040 permutations are retained, not silently deduplicated.
    enumeration=[]
    for order in itertools.permutations(range(1,8)):
        route=(0,)+order+(0,)
        ce=math.fsum(euclidean[a][b] for a,b in zip(route,route[1:]))
        cg=math.fsum(geo[a][b] for a,b in zip(route,route[1:]))
        enumeration.append((ce,cg,order))
    eopt=min(enumeration,key=lambda z:(z[0],z[2])); gopt=min(enumeration,key=lambda z:(z[1],z[2]))
    with (ROOT/'raw'/f"{inst['instance_id']}_all_orders.csv").open('w') as f:
        w=csv.writer(f); w.writerow(['permutation_index','task_service_ids','euclidean_cost','geodesic_cost'])
        for idx,(ce,cg,order) in enumerate(enumeration): w.writerow([idx,' '.join(map(str,order)),repr(ce),repr(cg)])
    def route_record(order):
        stops=(0,)+order+(0,); illegal=[]; polyline=[services[0]]; legs=[]
        for a,b in zip(stops,stops[1:]):
            ok=covered_segment(services[a],services[b],poly)
            assert ok==segment_in_union(services[a],services[b],rects)
            if not ok: illegal.append([a,b])
            path=leg_paths[a][b]['points']; polyline.extend(path[1:])
            legs.append({'from_service':a,'to_service':b,'direct_covered':ok,'legal_path':path,'legal_cost':geo[a][b]})
        length=math.fsum(distance(a,b) for a,b in zip(polyline,polyline[1:]))
        assert abs(length-math.fsum(geo[a][b] for a,b in zip(stops,stops[1:])))<=TOL
        return {'order':list(order),'stops':stops,'direct_illegal_legs':illegal,'direct_illegal_leg_count':len(illegal),
                'direct_illegal_leg_fraction':len(illegal)/8,'legal_polyline':polyline,'legal_length_recomputed':length,'legs':legs}
    er=route_record(eopt[2]); gr=route_record(gopt[2])
    penalty=eopt[1]-gopt[1]
    assert penalty>=-TOL
    matrix_error=max(abs(geo[i][j]-euclidean[i][j]) for i in range(8) for j in range(8))
    if inst['family']=='rectangle':
        assert matrix_error<=TOL and er['direct_illegal_leg_count']==0 and abs(penalty)<=TOL
    validation.update({'visibility_pair_checks':len(edge_checks),'independent_path_segment_checks':path_segments_checked,
        'floyd_service_pair_checks':64,'floyd_max_abs_error':fw_error,'enumerated_orders':len(enumeration),
        'euclidean_exact_float_ties':sum(z[0]==eopt[0] for z in enumeration),
        'geodesic_exact_float_ties':sum(z[1]==gopt[1] for z in enumeration),
        'euclidean_near_ties_1e9':sum(abs(z[0]-eopt[0])<=TOL for z in enumeration),
        'geodesic_near_ties_1e9':sum(abs(z[1]-gopt[1])<=TOL for z in enumeration)})
    out={'instance_id':inst['instance_id'],'family':inst['family'],'base_field_id':inst['base_field_id'],'seed':inst['seed'],
        'status':'PASS','nodes':nodes,'service_nodes':service_nodes,'services':services,'visibility_graph_edges':graph,
        'visibility_pair_checks':edge_checks,'euclidean_matrix':euclidean,'geodesic_matrix':geo,'legal_leg_paths':leg_paths,
        'euclidean_order_solution':er,'geodesic_order_solution':gr,'validation':validation,
        'euclidean_objective':eopt[0],'repaired_euclidean_order_cost':eopt[1],'geodesic_optimal_cost':gopt[1],
        'absolute_cost_penalty':penalty,'relative_cost_penalty':penalty/gopt[1],
        'same_order_up_to_reversal':eopt[2] in (gopt[2],tuple(reversed(gopt[2]))),
        'max_pair_distance_increase':matrix_error,'wall_seconds':time.perf_counter()-start}
    dump(ROOT/'raw'/f"{inst['instance_id']}.json",out)
    return out

def main():
    resource.setrlimit(resource.RLIMIT_CPU,(60,60)); signal.alarm(120)
    t0,c0=time.perf_counter(),time.process_time()
    for line in (ROOT/'evidence'/'pre_run.sha256').read_text().splitlines():
        digest,name=line.split('  ',1)
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,'Frozen source/input changed: '+name
    assert json.loads((ROOT/'evidence'/'precheck.json').read_text())['status']=='PASS'
    instances=json.loads((ROOT/'instances.json').read_text()); results=[]; failures=[]
    for inst in instances:
        try:
            row=run_instance(inst); results.append(row)
            print(json.dumps({k:row[k] for k in ['instance_id','status','euclidean_objective','repaired_euclidean_order_cost','geodesic_optimal_cost','relative_cost_penalty']},ensure_ascii=False),flush=True)
        except Exception as e:
            err={'instance_id':inst['instance_id'],'error_type':type(e).__name__,'error':str(e),'traceback':traceback.format_exc()}
            failures.append(err); dump(ROOT/'raw'/f"{inst['instance_id']}_failure.json",err)
            print(json.dumps(err),flush=True)
    dump(ROOT/'raw'/'failures.json',failures)
    fields=['instance_id','family','base_field_id','seed','status','euclidean_objective','repaired_euclidean_order_cost','geodesic_optimal_cost','absolute_cost_penalty','relative_cost_penalty','same_order_up_to_reversal','direct_illegal_legs','total_legs','direct_illegal_leg_fraction','wall_seconds']
    with (ROOT/'raw'/'results.csv').open('w') as f:
        w=csv.DictWriter(f,fields); w.writeheader()
        for row in results:
            compact={k:row[k] for k in fields if k in row}; er=row['euclidean_order_solution']
            compact.update(direct_illegal_legs=er['direct_illegal_leg_count'],total_legs=8,direct_illegal_leg_fraction=er['direct_illegal_leg_fraction']); w.writerow(compact)
    status={'status':'PASS' if len(results)==16 and not failures else 'FAIL','attempted_fields':len(instances),'successful_fields':len(results),'failed_fields':len(failures),'cpu_seconds':time.process_time()-c0,'wall_seconds':time.perf_counter()-t0,'cpu_limit':60,'wall_limit':120,'python':sys.version,'platform':platform.platform(),'model_api_calls':0,'third_party_writes':0,'new_installs':0,'geometric_tolerance':0,'comparison_tolerance':TOL}
    dump(ROOT/'evidence'/'run_status.json',status); print(json.dumps(status),flush=True)
    return 0 if status['status']=='PASS' else 1
if __name__=='__main__': sys.exit(main())
