"""One authorized run; GDAL/GEOS floating visibility graph, exhaustive finite plans."""
import json,math,hashlib,sys,time,resource,signal,datetime,traceback
from pathlib import Path
from fractions import Fraction as F
from osgeo import ogr,gdal
from geometry import covered_point,on_segment,intersection_parameters
from original_geometry_experiment import dijkstra,distance
from reference_cvrp_run import route_space,partitions,canonical,route_key,all_costs
from matrix_oracle import solve as dp_solve
import itertools,gzip,csv
R=Path(__file__).resolve().parents[1]; TOL=1e-9

def save(p,x):
 with (R/p).open('x') as f: json.dump(x,f,ensure_ascii=False,indent=2,allow_nan=False); f.write('\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def main():
 resource.setrlimit(resource.RLIMIT_CPU,(120,120)); signal.alarm(180)
 t,c=time.perf_counter(),time.process_time()
 freeze=json.loads((R/'freeze/PRE_RUN_FREEZE.json').read_text())
 for p,h in freeze['sha256'].items():assert sha(R/p)==h,p
 assert (R/'evidence/ROOT_APPROVAL.json').exists(),'Root approval required'
 save('evidence/STARTED.json',{'utc':utc(),'run':1})
 ins=json.loads((R/'input/instance.json').read_text()); S=ins['integer_units_per_metre']; rings=[[tuple(p) for p in r] for r in ins['rings_integer_exact']]
 field=ogr.CreateGeometryFromWkt((R/'input/projected_epsg32634.wkt').read_text()); assert field.IsValid()
 services=[tuple(p) for p in ins['coordinates']]; nodes=[(x/S,y/S) for r in rings for x,y in r]+services
 exact_nodes=[p for r in rings for p in r]+[tuple(v*S for v in p) for p in services]
 assert len(set(nodes))==len(nodes); sn=list(range(len(nodes)-10,len(nodes)))
 def geos(a,b):
  if a==b:return True
  line=ogr.Geometry(ogr.wkbLineString); line.AddPoint_2D(*a);line.AddPoint_2D(*b)
  diff=line.Difference(field)
  assert diff is not None,'GEOS Difference failure'
  return diff.IsEmpty()
 # Independent extension of existing rational splitter only audits saved path segments.
 def exact_point(p):
  if any(on_segment(p,a,b) for r in rings for a,b in zip(r,r[1:]+r[:1])):return True
  return covered_point(p,rings[0]) and not any(covered_point(p,r) for r in rings[1:])
 def exact_segment(a,b):
  if not exact_point(a) or not exact_point(b):return False
  cuts={F(0),F(1)}
  for r in rings:
   for u,v in zip(r,r[1:]+r[:1]):cuts.update(intersection_parameters(a,b,u,v))
  cs=sorted(cuts)
  return all(exact_point(tuple(F(a[k])+(l+h)/2*(b[k]-a[k]) for k in (0,1))) for l,h in zip(cs,cs[1:]))
 adj=[[] for _ in nodes]; checks=[]; edges=[]
 for i,a in enumerate(nodes):
  for j in range(i+1,len(nodes)):
   ok=geos(a,nodes[j]);checks.append([i,j,ok])
   if ok:
    w=distance(a,nodes[j]);adj[i].append((j,w));adj[j].append((i,w));edges.append([i,j,w])
 E=[[distance(a,b) for b in services] for a in services]; G=[[0.]*10 for _ in range(10)]; paths=[[None]*10 for _ in range(10)]
 ds=[dijkstra(nodes,adj,s) for s in sn]; direct=[[geos(a,b) for b in services] for a in services]
 audited={};bad=[]
 for i in range(10):
  for j in range(i,10):
   path=[sn[i]] if i==j else ([sn[i],sn[j]] if direct[i][j] else list(ds[i][1][sn[j]]))
   val=math.fsum(distance(nodes[a],nodes[b]) for a,b in zip(path,path[1:]));assert abs(val-ds[i][0][sn[j]])<=TOL
   G[i][j]=G[j][i]=val;paths[i][j]=path;paths[j][i]=path[::-1]
   for a,b in zip(path,path[1:]):
    key=tuple(sorted((a,b)))
    if key not in audited:audited[key]=exact_segment(exact_nodes[a],exact_nodes[b])
    if not audited[key]:bad.append([i,j,a,b])
 fw=[[math.inf]*len(nodes) for _ in nodes]
 for i in range(len(nodes)):fw[i][i]=0.
 for i,j,w in edges:fw[i][j]=fw[j][i]=math.hypot(nodes[i][0]-nodes[j][0],nodes[i][1]-nodes[j][1])
 for k in range(len(nodes)):
  for i in range(len(nodes)):
   for j in range(len(nodes)):fw[i][j]=min(fw[i][j],fw[i][k]+fw[k][j])
 ferr=max(abs(G[i][j]-fw[sn[i]][sn[j]]) for i in range(10) for j in range(10));assert ferr<=TOL
 save('raw/matrices_and_paths.json',{'nodes':nodes,'services':services,'service_node_ids':sn,'euclidean_matrix':E,'legal_matrix':G,'legal_leg_node_paths':paths,'direct_covered_matrix':direct,'visibility_edges':edges,'visibility_checks':checks,'audit':{'independent_rational_audited_segment_count':len(audited),'rational_disagreements':bad,'floyd_max_abs_error':ferr,'Floyd_scope':'Same frozen GEOS graph; independent shortest path algorithm, not independent continuous graph certification'}})
 assert not bad,'Saved shortest paths failed independent exact-decimal coverage audit'
 def sol(plan):
  illegal=[];routes=[]
  for route in plan:
   stops=(0,)+route+(0,);poly=[]
   for a,b in zip(stops,stops[1:]):
    if not direct[a][b]:illegal.append([a,b])
    ns=paths[a][b];poly.extend(ns if not poly else ns[1:])
   load=sum(ins['demands'][a] for a in route)
   routes.append({'tasks':route,'load':load,'polyline':[nodes[a] for a in poly],'polyline_node_ids':poly,'cost':math.fsum(distance(nodes[a],nodes[b]) for a,b in zip(poly,poly[1:]))})
  return {'plan':plan,'euclidean_cost':all_costs(plan,E),'mapped_feasible_cost':all_costs(plan,G),'uncovered_direct_legs':illegal,'direct_leg_count':9+len(plan),'mapped_path_violations':0,'routes':routes}
 results=[]
 for K,Q in [(1,24),(3,9)]:
  inst=dict(ins,capacity=Q,max_vehicles=K);loads,routes=route_space(ins['demands'],Q);records=[];part_count=0
  with gzip.open(R/f'raw/K{K}_all_canonical_plans.csv.gz','wt',newline='') as f:
   w=csv.writer(f);w.writerow(['index','canonical_routes','euclidean_cost','legal_cost'])
   for parts in partitions(511,K,loads,Q,routes):
    part_count+=1
    for combination in itertools.product(*(routes[s] for s in parts)):
     plan=canonical(combination);e=all_costs(plan,E);g=all_costs(plan,G);records.append((e,g,plan));w.writerow([len(records)-1,route_key(plan),repr(e),repr(g)])
  eo=min(records,key=lambda x:(x[0],x[2]));go=min(records,key=lambda x:(x[1],x[2]));dp={}
  for name,D,opt in [('E',E,eo[0]),('G',G,go[1])]:
   d=dp_solve(inst,D)['by_k'][str(K)];assert d['nonempty_routes']==K and abs(d['cost']-opt)<=TOL;dp[name]=d
  ties={}
  for width in [0.,TOL]:
   rs=[r for r in records if r[0]==eo[0]] if width==0 else [r for r in records if r[0]<=eo[0]+width]
   ties[str(width)]={'count':len(rs),'min_mapped_cost':min(r[1] for r in rs),'max_mapped_cost':max(r[1] for r in rs)}
  es,gs=sol(eo[2]),sol(go[2]);assert all(r['load']<=Q for s in [es,gs] for r in s['routes'])
  result={'K':K,'Q':Q,'euclidean_solution':es,'obstacle_solution':gs,'repair_bias_m':eo[1]-eo[0],'repair_bias_fraction':(eo[1]-eo[0])/eo[0],'reordering_saved_m':eo[1]-go[1],'reordering_regret_fraction':(eo[1]-go[1])/go[1],'reordering_saved_fraction':(eo[1]-go[1])/eo[1],'canonical_plan_count':len(records),'partition_count':part_count,'E_ties':ties,'DP_crosscheck':dp}
  save(f'raw/K{K}_result.json',result);results.append(result);print(json.dumps({'K':K,'E_E':eo[0],'G_E':eo[1],'G_G':go[1],'plans':len(records)}),flush=True)
 save('reports/results.json',results)
 save('evidence/RUN_STATUS.json',{'status':'PASS','utc':utc(),'runs':1,'cpu_seconds':time.process_time()-c,'wall_seconds':time.perf_counter()-t,'cpu_cap':120,'wall_cap':180,'GDAL':gdal.VersionInfo(),'new_installs':0,'model_calls':0,'new_paid_external_cost':0,'monetary_compute_cost':'Not exposed','claim':'Finite GEOS visibility graph combinatorial optimum, binary64 costs; independently rational-audited mapped paths; not continuous geometry exact certification.'})
if __name__=='__main__':
 try:main()
 except Exception as e:
  save('evidence/FAILURE.json',{'utc':utc(),'error':str(e),'traceback':traceback.format_exc()});raise
