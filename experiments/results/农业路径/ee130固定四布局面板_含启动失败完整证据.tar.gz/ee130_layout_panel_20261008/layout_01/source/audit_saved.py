"""Read saved artifacts only. No candidate generation, graph construction, or optimizer."""
import json,csv,gzip,math,hashlib,datetime
from pathlib import Path
from osgeo import ogr
R=Path(__file__).resolve().parents[1];tol=1e-9
ins=json.loads((R/'input/instance.json').read_text()); geom=json.loads((R/'raw/matrices_and_paths.json').read_text());res=json.loads((R/'reports/results.json').read_text())
poly=ogr.CreateGeometryFromWkt((R/'input/projected_epsg32634.wkt').read_text());assert poly.IsValid() and poly.GetGeometryCount()==4
frozen=json.loads((R/'freeze/PRE_RUN_FREEZE.json').read_text())
for p,h in frozen['sha256'].items():assert hashlib.sha256((R/p).read_bytes()).hexdigest()==h
checks=[]
for out in res:
 K,Q=out['K'],out['Q'];minE=None;minG=None;n=0;maxerr=0
 with gzip.open(R/f'raw/K{K}_all_canonical_plans.csv.gz','rt') as f:
  for row in csv.DictReader(f):
   plan=tuple(tuple(map(int,r.split('-'))) for r in row['canonical_routes'].split('|'))
   assert len(plan)==K and sorted(t for r in plan for t in r)==list(range(1,10))
   assert all(sum(ins['demands'][t] for t in r)<=Q for r in plan)
   ev=[]
   for key,stored in [('euclidean_matrix','euclidean_cost'),('legal_matrix','legal_cost')]:
    d=geom[key];v=math.fsum(d[a][b] for r in plan for a,b in zip((0,)+r,r+(0,)))
    error=abs(v-float(row[stored]));maxerr=max(maxerr,error);assert error<=tol;ev.append(v)
   a=(ev[0],plan);b=(ev[1],plan);minE=a if minE is None or a<minE else minE;minG=b if minG is None or b<minG else minG;n+=1
 assert n==out['canonical_plan_count']
 segments=0;maxpath=0
 for key,minimum,matrix in [('euclidean_solution',minE,'euclidean_matrix'),('obstacle_solution',minG,'legal_matrix')]:
  sol=out[key];assert tuple(map(tuple,sol['plan']))==minimum[1]
  assert abs(sol['euclidean_cost' if key=='euclidean_solution' else 'mapped_feasible_cost']-minimum[0])<=tol
  assert sorted(t for r in sol['routes'] for t in r['tasks'])==list(range(1,10))
  total=[]
  for r in sol['routes']:
   assert sum(ins['demands'][t] for t in r['tasks'])==r['load']<=Q
   pts=r['polyline'];assert pts[0]==pts[-1]==ins['coordinates'][0]
   # All designated service stops occur in stored polyline, in order.
   offset=0
   for task in r['tasks']:
    offset=pts.index(ins['coordinates'][task],offset)+1
   lengths=[]
   for a,b in zip(pts,pts[1:]):
    line=ogr.Geometry(ogr.wkbLineString);line.AddPoint_2D(*a);line.AddPoint_2D(*b)
    intersection=line.Intersection(poly);assert intersection is not None and intersection.Equals(line)
    lengths.append(math.hypot(b[0]-a[0],b[1]-a[1]));segments+=1
   length=math.fsum(lengths);maxpath=max(maxpath,abs(length-r['cost']));assert abs(length-r['cost'])<=tol;total.append(length)
  assert abs(math.fsum(total)-sol['mapped_feasible_cost'])<=tol
 for name,mi in [('E',minE),('G',minG)]:assert abs(out['DP_crosscheck'][name]['cost']-mi[0])<=tol
 checks.append({'K':K,'Q':Q,'saved_plans_scanned':n,'all_task_coverage_and_capacity_valid':True,'all_saved_row_cost_max_abs_error':maxerr,'selected_paths_segments_intersection_equals_checked':segments,'selected_path_cost_max_abs_error':maxpath,'stored_dp_matches_saved_enumeration_minima':True})
a={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS','scope':'Independent read-only scan of saved enumeration and selected polylines; no reoptimization. GEOS Intersection.Equals(line) checks independently of main Difference emptiness; same GEOS library, not independent numerical engine. Main additionally exact-decimal rational-audits all shortest leg path segments.','frozen_hashes_unchanged':True,'checks':checks}
with (R/'evidence/INDEPENDENT_SAVED_AUDIT.json').open('x') as f:json.dump(a,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps(a))
