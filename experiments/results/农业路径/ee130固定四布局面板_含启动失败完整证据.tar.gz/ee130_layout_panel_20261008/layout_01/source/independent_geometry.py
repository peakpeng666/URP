#!/usr/bin/env python3
"""Independent exact rectangle-union segment clipping. Imports no primary predicate.
Only valid for the supplied axis-aligned rectangle decomposition, checked separately.
"""
from fractions import Fraction

def point_in_union(p,rectangles):
    return any(x0<=p[0]<=x1 and y0<=p[1]<=y1 for x0,y0,x1,y1 in rectangles)

def segment_in_union(a,b,rectangles):
    intervals=[]
    for x0,y0,x1,y1 in rectangles:
        lo,hi=Fraction(0),Fraction(1)
        for k,vmin,vmax in ((0,x0,x1),(1,y0,y1)):
            velocity=b[k]-a[k]
            if velocity==0:
                if not vmin<=a[k]<=vmax: lo,hi=Fraction(1),Fraction(0); break
            else:
                r0=Fraction(vmin-a[k],velocity); r1=Fraction(vmax-a[k],velocity)
                lo=max(lo,min(r0,r1)); hi=min(hi,max(r0,r1))
        if lo<=hi: intervals.append((lo,hi))
    right=Fraction(0)
    for left,end in sorted(intervals):
        if left>right: return False
        right=max(right,end)
        if right>=1: return True
    return False
