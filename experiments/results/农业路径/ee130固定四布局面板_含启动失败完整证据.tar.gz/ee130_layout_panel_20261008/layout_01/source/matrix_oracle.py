"""Held-Karp subset tours plus exact combinatorial at-most-K partition DP.
Adaptation: objective distance matrix injected; the other logic is unchanged.
Uses IEEE double supplied costs: no interval arithmetic or formal proof claim.
An empty fleet state has zero cost; emitted routes are nonempty depot tours.
"""
import math
from functools import lru_cache

def solve(raw, matrix):
    xy=raw['coordinates']; demand=raw['demands']; n=len(demand)-1; Q=raw['capacity']
    size=1<<n; d=matrix
    loads=[0]*size; tours={0:(0.,())}; states={}; transitions=0
    for mask in range(1,size):
        bit=mask&-mask; loads[mask]=loads[mask^bit]+demand[bit.bit_length()]
        if loads[mask]>Q: continue
        nodes=[j for j in range(n) if mask>>j&1]
        for j in nodes:
            prior=mask^(1<<j)
            if prior==0: states[(mask,j)]=(d[0][j+1],(j+1,))
            else:
                options=[]
                for i in nodes:
                    if i==j: continue
                    val,path=states[(prior,i)]; transitions+=1
                    options.append((val+d[i+1][j+1],path+(j+1,)))
                states[(mask,j)]=min(options)
        tours[mask]=min((states[(mask,j)][0]+d[j+1][0],states[(mask,j)][1]) for j in nodes)
    partition_transitions=0
    @lru_cache(None)
    def part(mask,k):
        nonlocal partition_transitions
        if mask==0: return (0.,())
        if k==0 or loads[mask]>k*Q: return None
        anchor=mask&-mask; sub=mask; best=None
        while sub:
            if sub&anchor and sub in tours:
                partition_transitions+=1
                rest=part(mask^sub,k-1)
                if rest is not None:
                    c,r=tours[sub]; cand=(c+rest[0],tuple(sorted((r,)+rest[1])))
                    if best is None or cand<best: best=cand
            sub=(sub-1)&mask
        return best
    by_k={}
    for k in range(1,n+1):
        value=part(size-1,k)
        by_k[str(k)]=None if value is None else {'cost':value[0], 'routes':[[0,*r,0] for r in value[1]],'nonempty_routes':len(value[1])}
    return {'n':n,'capacity':Q,'by_k':by_k,'tours':{str(m):{'cost':v[0],'route':[0,*v[1],0],'load':loads[m]} for m,v in tours.items() if m}, 'held_karp_states':len(states),'held_karp_transitions':transitions,'partition_states':part.cache_info().currsize,'partition_transitions':partition_transitions,'arithmetic':'IEEE754 double; exact combinatorial enumeration, numerically validated, not certified interval proof'}
