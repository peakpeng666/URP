"""Preparation only: freeze seeds, then sample four layouts without any route evaluation."""
import json,hashlib,random,datetime,shutil,time,resource,signal,sys
from pathlib import Path
from osgeo import ogr
OLD=Path('/workspace/shared/documented_ee130_routing_20261008')
R=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(OLD/'source'))
from geometry import covered_point,on_segment
resource.setrlimit(resource.RLIMIT_CPU,(10,10));signal.alarm(20)
t=time.perf_counter();c=time.process_time()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
 with p.open('x') as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
for d in ['freeze','evidence','reports']: (R/d).mkdir(exist_ok=True)
old=json.loads((OLD/'input/instance.json').read_text());oldseed=json.loads((OLD/'freeze/PROTOCOL.json').read_text())['sampling_seed']
seeds=random.Random(202610080632).sample(range(100000000000,1000000000000),4)
assert len(set(seeds))==4 and oldseed not in seeds
assert sha(OLD/'source/execute.py')=='0aaea0af7d654d31f1adfc758e68dda7d4f6c60924487cdd1c3648ea19209f3a'
source_names=['execute.py','geometry.py','independent_geometry.py','matrix_oracle.py','original_geometry_experiment.py','reference_cvrp_run.py','audit_saved.py']
source_hashes={n:sha(OLD/'source'/n) for n in source_names}
protocol={'utc':utc(),'study':'ee130_fixed_geometry_synthetic_layout_sensitivity_four_v1','old_study':'documented_ee130_routing_20261008; excluded from panel and never rerun','old_sampling_seed':oldseed,'seed_generation':'One random.Random(202610080632).sample(range(100000000000,1000000000000),4), before any point generation or objectives','sampling_seeds':seeds,'layouts':4,'points_per_layout':10,'demands':[0,1,4,2,1,3,4,2,3,4],'sampling':'Same original integer-bbox rejection sampler: independent uniform integer easting/northing; first 10 unique strictly interior points, first depot and next 9 tasks; retain all accepted/rejected draws; no objective filtering or reselection','geometry_sha256':sha(OLD/'input/projected_epsg32634.wkt'),'geometry':'Unchanged original projected EPSG32634 polygon and all three holes; no buffer, snap, simplification, repairs or tolerances','cases':[{'K':1,'Q':24},{'K':3,'Q':9}],'objectives':['E','G'],'objective_selections':16,'algorithm':'Byte-identical trusted execute.py and imports: GEOS visibility with all vertices/service nodes; Dijkstra, same-graph Floyd, rational saved-path audit, full canonical enumeration and independent Held-Karp/partition DP; binary64 primary objective with canonical tie-break; existing 1e-9 audit and tie-sensitivity only','source_sha256':source_hashes,'budgets':{'preparation_cpu_s':10,'preparation_wall_s':20,'main_per_layout_cpu_s':120,'main_per_layout_wall_s':180,'main_total_cpu_s':480,'main_total_wall_s':720,'independent_audit_and_packaging_cpu_s':60,'independent_audit_and_packaging_wall_s':60,'overall_cpu_s':550,'overall_active_wall_s':800},'claims':'Only sensitivity to four synthetic task layouts on the same documented geometry; not four fields, real agricultural tasks or generalization. Finite floating GEOS visibility graph combinatorial optimum, not continuous-geometry exact certification.','stopping':'Preparation only until root approval. One attempt per frozen layout, no retries or replacement, no adding layouts. Retain FAIL/cap evidence.','new_installs':0,'model_calls':0,'external_API_calls':0}
save(R/'freeze/PROTOCOL.json',protocol)
save(R/'freeze/PRE_GENERATION_FREEZE.json',{'utc':utc(),'objective_evaluations':0,'distance_matrix_evaluations':0,'sha256':{'source/prepare_panel.py':sha(R/'source/prepare_panel.py'),'freeze/PROTOCOL.json':sha(R/'freeze/PROTOCOL.json')}})
rings=[[tuple(p) for p in ring] for ring in old['rings_integer_exact']];S=old['integer_units_per_metre'];bounds=old['sampling_integer_bounds'];g=ogr.CreateGeometryFromWkt((OLD/'input/projected_epsg32634.wkt').read_text());assert g.IsValid() and g.GetGeometryCount()==4
assert bounds==[661870,662093,6526079,6526292]
def strict(p):
 if any(on_segment(p,a,b) for r in rings for a,b in zip(r,r[1:]+r[:1])):return False
 return covered_point(p,rings[0]) and not any(covered_point(p,r) for r in rings[1:])
summary=[]
for index,seed in enumerate(seeds,1):
 L=R/f'layout_{index:02d}'
 for d in ['source','input','freeze','evidence','raw','reports']:(L/d).mkdir(parents=True,exist_ok=False)
 for n in source_names:shutil.copyfile(OLD/'source'/n,L/'source'/n);assert sha(L/'source'/n)==source_hashes[n]
 shutil.copyfile(OLD/'input/projected_epsg32634.wkt',L/'input/projected_epsg32634.wkt')
 r=random.Random(seed);points=[];draws=[]
 while len(points)<10:
  p=(r.randint(bounds[0],bounds[1]),r.randint(bounds[2],bounds[3]));ok=strict(tuple(v*S for v in p)) and p not in points
  q=ogr.Geometry(ogr.wkbPoint);q.AddPoint_2D(*p);assert ok==(g.Contains(q) and p not in points)
  draws.append({'point':p,'accepted':ok})
  if ok:points.append(p)
 inst=dict(old,instance_id=f'ee130_layout_panel_{index:02d}',coordinates=points,sampling_draws=draws,sampling_seed=seed)
 assert inst['demands']==protocol['demands']
 save(L/'input/instance.json',inst)
 save(L/'freeze/CLAIM.json',{'layout':index,'sampling_seed':seed,'claims':protocol['claims'],'panel_protocol_sha256':sha(R/'freeze/PROTOCOL.json'),'one_formal_attempt':True})
 save(L/'evidence/GENERATION.json',{'utc':utc(),'objective_evaluations':0,'distance_matrix_evaluations':0,'planning_candidates':0,'seed':seed,'draw_count':len(draws),'all_points_unique_strictly_inside':True,'independent_GDAL_contains_agrees':True,'instance_sha256':sha(L/'input/instance.json')})
 files=sorted(list((L/'source').glob('*.py'))+list((L/'input').glob('*'))+[L/'freeze/CLAIM.json',L/'evidence/GENERATION.json'])
 save(L/'freeze/PRE_RUN_FREEZE.json',{'utc':utc(),'objective_evaluations':0,'distance_matrix_evaluations':0,'sha256':{str(p.relative_to(L)):sha(p) for p in files}})
 summary.append({'layout':index,'seed':seed,'draws':len(draws),'instance_sha256':sha(L/'input/instance.json'),'pre_run_freeze_sha256':sha(L/'freeze/PRE_RUN_FREEZE.json')})
save(R/'freeze/PANEL_PRE_RUN_FREEZE.json',{'utc':utc(),'objective_evaluations':0,'distance_matrix_evaluations':0,'layouts':summary,'sha256':{str(p.relative_to(R)):sha(p) for p in sorted(R.rglob('*')) if p.is_file()}})
save(R/'evidence/PREPARATION_STATUS.json',{'utc':utc(),'status':'FROZEN_AWAITING_ROOT_APPROVAL','cpu_seconds':time.process_time()-c,'wall_seconds':time.perf_counter()-t,'layouts':summary,'protocol_sha256':sha(R/'freeze/PROTOCOL.json'),'panel_freeze_sha256':sha(R/'freeze/PANEL_PRE_RUN_FREEZE.json')})
print((R/'evidence/PREPARATION_STATUS.json').read_text())
