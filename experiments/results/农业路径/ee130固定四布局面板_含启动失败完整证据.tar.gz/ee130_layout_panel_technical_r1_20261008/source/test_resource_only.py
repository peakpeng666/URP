import resource,subprocess,json,sys,os,time
resource.setrlimit(resource.RLIMIT_CPU,(10,120))
code="import resource,json,os,sys; before=resource.getrlimit(resource.RLIMIT_CPU); resource.setrlimit(resource.RLIMIT_CPU,(120,120)); print(json.dumps({'pid':os.getpid(),'ppid':os.getppid(),'executable':sys.executable,'before':before,'after':resource.getrlimit(resource.RLIMIT_CPU),'planning_calls':0}))"
t=time.perf_counter();p=subprocess.run(['/usr/bin/python3','-c',code],capture_output=True,text=True,timeout=5)
print(json.dumps({'parent_pid':os.getpid(),'parent_limit':resource.getrlimit(resource.RLIMIT_CPU),'child_exit_code':p.returncode,'child':json.loads(p.stdout) if p.returncode==0 else None,'stderr':p.stderr,'wall_seconds':time.perf_counter()-t,'parent_cpu_seconds':time.process_time(),'child_usage':list(resource.getrusage(resource.RUSAGE_CHILDREN)[:2]),'planning_calls':0}));assert p.returncode==0
