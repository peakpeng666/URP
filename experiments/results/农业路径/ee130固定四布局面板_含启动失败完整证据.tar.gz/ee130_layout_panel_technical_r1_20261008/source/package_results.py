"""Saved-result reporting and packaging only; no graph or optimizer calls."""
import json,hashlib,csv,time,resource,signal,tarfile
from pathlib import Path
R=Path(__file__).resolve().parents[1];OLD=Path('/workspace/shared/ee130_layout_panel_20261008')
resource.setrlimit(resource.RLIMIT_CPU,(50,50));signal.alarm(50)
t=time.perf_counter();c=time.process_time()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
x=json.loads((R/'reports/PANEL_RESULTS.json').read_text());assert x['status']=='PASS'
f=json.loads((R/'freeze/PANEL_PRE_RUN_FREEZE.json').read_text());assert all(sha(R/p)==h for p,h in f['sha256'].items())
for i in range(1,5):assert json.loads((R/f'layout_{i:02d}/evidence/INDEPENDENT_SAVED_AUDIT.json').read_text())['status']=='PASS'
rows=x['results'];fields=['layout','seed','K','Q','E_E','G_E','G_G','repair_bias_m','reordering_saved_m','reordering_saved_fraction','same_primary_plan','uncovered_direct_legs_E','mapped_violations','canonical_plan_count']
with (R/'reports/results_summary.csv').open('x') as f:
 w=csv.DictWriter(f,fields,extrasaction='ignore');w.writeheader();w.writerows(rows)
lines=['# ee130 同一几何四任务布局敏感性面板','', '## 结论与范围','', '预先一次冻结的4个新合成任务布局，在K=1/Q=24及K=3/Q=9两场景下，8/8场景欧氏与障碍目标选出的主计划完全相同，绕障后重新排序收益均为0米。16次目标选择和4份独立保存结果审计全部通过。','', '这是一个已文档化ee130地块上4个合成任务布局的小面板；不是4个地块，不是真实农业任务，不构成总体泛化。旧单例始终单独保留，未合并成预先固定5样本。不能据此断言任何布局都会相同或障碍建模没有价值。','', '5/8场景的欧氏直线最优计划含穿越不可行区域的边，替换成合法最短路径会增加距离；这项修复成本不能被写成重新优化的收益。','', '## 固定方法','', '同原始EPSG:32634投影多边形、3洞、完整顶点、9任务+1仓库，需求[0,1,4,2,1,3,4,2,3,4]。四seed一次生成且不同于旧seed202610080731：259771257096、971357684854、186193928409、828655156178。每seed独立使用原整数bbox均匀拒绝采样，保留首10个唯一严格内部点；保留全部抽取记录，没有按效果换点。','', '每布局execute.py逐字节复制原可信代码，SHA256 0aaea0af7d654d31f1adfc758e68dda7d4f6c60924487cdd1c3648ea19209f3a。复用全顶点GEOS可见图、Dijkstra、同图Floyd、保存路径的精确十进制有理几何核验、全canonical枚举及独立Held–Karp/partition DP。主目标使用binary64和原canonical tie-break，1e-9仅用于原核验与tie敏感性，不影响主选择。仅声称固定浮点GEOS图上的组合最优，不声称连续几何精确认证。','', '## 全部结果','', '|布局|K/Q|E(E*) m|G(E*) m|G(G*) m|修复增量 m|重排收益 m|欧氏不合法直连数|','|---|---|---:|---:|---:|---:|---:|---:|']
for r in rows:lines.append(f"|{r['layout']}|{r['K']}/{r['Q']}|{r['E_E']:.9f}|{r['G_E']:.9f}|{r['G_G']:.9f}|{r['repair_bias_m']:.9f}|{r['reordering_saved_m']:.9f}|{r['uncovered_direct_legs_E']}|")
lines+=['','每个K1场景保存181440个canonical计划，K3保存9918个，共765432个保存方案。全部主计划一致，全部映射路径违规为0；每场景欧氏精确最优及+1e-9候选均仅1个，不受该tie敏感性窗口影响。完整路线、路径节点、矩阵、每个方案成本和DP证据保存在各布局raw及reports目录。','', '## 技术失败历史（不得删除）','', '原panel启动调度器错误地将父进程CPU硬限设为10秒，子进程继承后无法设置原主程序120秒硬限，4个启动均在STARTED/建图前失败；原调度器异常分类过宽，错误继续后3个启动。该次完成目标数0/16，没有科学结果，不得称零收益。原目录完整保留。','', '另经root授权创建technical-r1：保持所有科学输入与求解代码不变，仅父CPU限制改10秒soft/120秒hard，并将任何非零子进程结果全停。纯资源dummy验证后，再次独立授权此轮真实运行。technical-r1四布局各仅计算一次，未换点或重跑。','', '## 预算与实耗','', '旧失败预约独立550 CPU秒/800活动wall秒，保持单列、不退款、不冲抵新预约；旧主启动实耗0.439682 CPU秒/0.508704 wall秒、旧准备0.024604 CPU秒、旧runner0.027691 CPU秒。','', 'technical-r1新独立预约550 CPU秒/800活动wall秒：准备10/20，四主跑各120/180合480/720，独审及打包60/60。实际主跑含进程启动15.538444 CPU秒/15.651952 wall秒；保存结果审计6.437072 CPU秒/6.537332 wall秒；runner自身0.070524 CPU秒。纯资源dummy子进程0.016785 CPU秒，父进程0.018785 CPU秒。打包开销另记evidence/PACKAGING_STATUS.json。模型/外部API/新安装次数均为0；货币计算费用没有接口披露，不能据此宣称货币成本为0。','', '## 文件与验证','', 'reports/PANEL_RESULTS.json及results_summary.csv为全部结果；layout_*/raw含压缩全枚举数据和路径矩阵；layout_*/evidence/INDEPENDENT_SAVED_AUDIT.json为只读独审。source/technical_r1.diff及evidence/DUMMY_RESOURCE_TEST.json保留最小恢复证据。freeze/PANEL_PRE_RUN_FREEZE.json绑定新授权，原失败包一并交付。SHA256SUMS.txt覆盖最终文件（不含Python字节缓存）。']
(R/'README_zh.md').write_text('\n'.join(lines)+'\n')
with (R/'evidence/FINAL_FREEZE_CHECK.json').open('x') as f:json.dump({'all_frozen_hashes_unchanged':True,'all_four_independent_audits':'PASS','completed_objective_selections':16,'successful_scientific_attempts_per_layout':1,'appended_layouts':0,'old_singleton_merged':False},f,indent=2)
# Save bookkeeping before manifest; archive time is reported outside the archive as well.
with (R/'evidence/PACKAGING_STATUS.json').open('x') as f:json.dump({'stage':'reports_and_manifest_pre_archive','cpu_seconds':time.process_time()-c,'wall_seconds':time.perf_counter()-t,'audit_plus_packaging_cap_cpu_s':60,'audit_plus_packaging_cap_wall_s':60,'packaging_subprocess_cap_cpu_s':50,'packaging_subprocess_cap_wall_s':50},f,indent=2)
files=sorted(p for p in R.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='SHA256SUMS.txt');(R/'SHA256SUMS.txt').write_text(''.join(sha(p)+'  '+str(p.relative_to(R))+'\n' for p in files))
archive=R.parent/'ee130_four_layout_panel_with_failed_history_20261008.tar.gz'
with tarfile.open(archive,'x:gz') as tar:
 for base in [OLD,R]:
  for p in sorted(base.rglob('*')):
   if p.is_file() and '__pycache__' not in p.parts:tar.add(p,arcname=str(p.relative_to(R.parent)))
print(json.dumps({'archive':str(archive),'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'manifest_sha256':sha(R/'SHA256SUMS.txt'),'packaging_cpu_seconds':time.process_time()-c,'packaging_wall_seconds':time.perf_counter()-t},indent=2))
