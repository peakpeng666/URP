"""Single authorized execution of four frozen layouts and saved-artifact audit."""
import json,hashlib,datetime,time,subprocess,resource,math,os
from pathlib import Path
R=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
 with (R/p).open('x') as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def childcpu():
 r=resource.getrusage(resource.RUSAGE_CHILDREN);return r.ru_utime+r.ru_stime
resource.setrlimit(resource.RLIMIT_CPU,(10,120))
approval=json.loads((R/'evidence/ROOT_APPROVAL.json').read_text())
assert approval['authorization_status']=='APPROVED_TECHNICAL_R1'
assert sha(R/'freeze/PANEL_PRE_RUN_FREEZE.json')==approval['approved_freeze_sha256']
frozen=json.loads((R/'freeze/PANEL_PRE_RUN_FREEZE.json').read_text())
for p,h in frozen['sha256'].items():assert sha(R/p)==h,p
t=time.perf_counter();maincpu=childcpu();states=[]
for i in range(1,5):
 L=R/f'layout_{i:02d}';save(f'layout_{i:02d}/evidence/ROOT_APPROVAL.json',approval)
 assert sha(L/'source/execute.py')=='0aaea0af7d654d31f1adfc758e68dda7d4f6c60924487cdd1c3648ea19209f3a'
 st=time.perf_counter();sc=childcpu()
 with (L/'evidence/STDOUT.log').open('x') as out,(L/'evidence/STDERR.log').open('x') as err:
  try:code=subprocess.run(['/usr/bin/python3',str(L/'source/execute.py')],stdout=out,stderr=err,timeout=min(180,720-(time.perf_counter()-t))).returncode
  except subprocess.TimeoutExpired:code='TIMEOUT'
 status={'layout':i,'exit_code':code,'wall_seconds':time.perf_counter()-st,'process_cpu_seconds_including_startup':childcpu()-sc}
 save(f'layout_{i:02d}/evidence/PROCESS_STATUS.json',status);states.append(status);print(json.dumps(status),flush=True)
 if code!=0:
  # Any nonzero exit stops the panel. In particular, no infrastructure failure can continue.
  save('evidence/PANEL_STOPPED.json',{'reason':'Nonzero execution result; all subsequent layouts and audits stopped','states':states});raise SystemExit(1)
mainwall=time.perf_counter()-t;maincost=childcpu()-maincpu
at=time.perf_counter();ac=childcpu();audits=[]
for s in states:
 i=s['layout'];L=R/f'layout_{i:02d}'
 if s['exit_code']!=0:audits.append({'layout':i,'status':'MAIN_FAILED_NO_AUDIT'});continue
 remainingcpu=60-(childcpu()-ac);remainingwall=60-(time.perf_counter()-at)
 if remainingcpu<1 or remainingwall<1:raise RuntimeError('Audit resource pool exhausted')
 def cap():resource.setrlimit(resource.RLIMIT_CPU,(math.floor(remainingcpu),math.floor(remainingcpu)))
 st=time.perf_counter();sc=childcpu()
 with (L/'evidence/AUDIT_STDOUT.log').open('x') as out,(L/'evidence/AUDIT_STDERR.log').open('x') as err:
  try:code=subprocess.run(['/usr/bin/python3',str(L/'source/audit_saved.py')],stdout=out,stderr=err,timeout=remainingwall,preexec_fn=cap).returncode
  except subprocess.TimeoutExpired:code='TIMEOUT'
 row={'layout':i,'exit_code':code,'cpu_seconds':childcpu()-sc,'wall_seconds':time.perf_counter()-st};audits.append(row);save(f'layout_{i:02d}/evidence/AUDIT_PROCESS_STATUS.json',row);print(json.dumps({'audit':row}),flush=True)
 if code!=0:break
rows=[]
for s in states:
 i=s['layout'];L=R/f'layout_{i:02d}'
 if s['exit_code']!=0:rows.append({'layout':i,'status':'FAIL','failure':json.loads((L/'evidence/FAILURE.json').read_text())});continue
 for r in json.loads((L/'reports/results.json').read_text()):
  E=r['euclidean_solution'];G=r['obstacle_solution']
  rows.append({'layout':i,'seed':json.loads((L/'input/instance.json').read_text())['sampling_seed'],'K':r['K'],'Q':r['Q'],'E_E':E['euclidean_cost'],'G_E':E['mapped_feasible_cost'],'G_G':G['mapped_feasible_cost'],'repair_bias_m':r['repair_bias_m'],'reordering_saved_m':r['reordering_saved_m'],'reordering_saved_fraction':r['reordering_saved_fraction'],'same_primary_plan':E['plan']==G['plan'],'euclidean_plan':E['plan'],'obstacle_plan':G['plan'],'uncovered_direct_legs_E':len(E['uncovered_direct_legs']),'mapped_violations':E['mapped_path_violations']+G['mapped_path_violations'],'canonical_plan_count':r['canonical_plan_count'],'E_ties':r['E_ties']})
summary={'utc':utc(),'scope':'Four prespecified synthetic task layouts on one unchanged documented ee130 geometry. Original singleton excluded. No real-task, multi-field or population generalization.','status':'PASS' if len(audits)==4 and all(a.get('exit_code')==0 for a in audits) else 'INCOMPLETE_OR_FAILED','main_cpu_seconds_with_startup':maincost,'main_wall_seconds':mainwall,'audit_cpu_seconds':childcpu()-ac,'audit_wall_seconds':time.perf_counter()-at,'runner_cpu_seconds':time.process_time(),'states':states,'audits':audits,'results':rows}
save('reports/PANEL_RESULTS.json',summary)
print(json.dumps(summary,ensure_ascii=False),flush=True)
