import os, resource, time
os.environ.update(MPLCONFIGDIR='/workspace/shared/nl124_proxy_gap_visual_review_20261009/.mplcache', OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1')
resource.setrlimit(resource.RLIMIT_CPU,(60,60)); resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
start=time.monotonic()
import json, hashlib, math, zipfile, re, collections
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Polygon
from matplotlib.lines import Line2D
ROOT=Path('/workspace/shared'); OUT=ROOT/'nl124_proxy_gap_visual_review_20261009'; EXACT=ROOT/'nl124_capacitated_exact_reference_20261009'; INPUT=ROOT/'unseen_nl_field_preparation_20261009'; B=INPUT/'raw/fields/nl_field_42'
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(p.read_text())
truth=load(EXACT/'truth/EXACT_REFERENCE.json'); summary=load(EXACT/'reports/SUMMARY.json'); f=next(x for x in truth['fields'] if x['instance_id']=='nl_field_42'); sf=next(x for x in summary['fields'] if x['instance_id']=='nl_field_42')
p=load(B/'preprocess.json'); g=load(B/'graph.json'); services=load(B/'services.json'); proj=load(B/'projection.json')
assert truth['status']=='EXACT_REFERENCE_AUDITED' and all(f['objectives'][o]['verified'] for o in ['E_G','G_E'])
assert sha((B/'preprocess.json').read_bytes())==f['input_preprocess_sha256']
assert len(p['coordinates'])==13 and p['n']==12 and p['capacity']==5 and p['K']==3
zpath=EXACT/'input/PARENT_FINAL.zip'; assert sha(zpath.read_bytes())==truth['input_final_archive_sha256']
sources=[]
with zipfile.ZipFile(zpath) as z:
 for n in ['preprocess.json','graph.json','services.json','projection.json','projected.wkt','center.wkt','center_metadata.json']:
  file=B/n; raw=file.read_bytes(); member=f'raw/fields/nl_field_42/{n}'; assert raw==z.read(member)
  sources.append({'path':str(file),'sha256':sha(raw),'archive_member':member,'matches_audited_parent_archive':True})
for file in [EXACT/'truth/EXACT_REFERENCE.json',EXACT/'reports/SUMMARY.json',EXACT/'PROTOCOL_ZH.txt',zpath]:sources.append({'path':str(file),'sha256':sha(file.read_bytes())})
for rel,h in sf['input_identity']['members'].items():
 if rel.startswith('raw/fields/nl_field_42/'):assert sha((INPUT/rel).read_bytes())==h
nodes=g['nodes']; edge_weights={tuple(sorted((a,b))):w for a,b,w in g['edges']}; checked={tuple(sorted(x['node_ids'])):x for x in p['unique_path_segments']}
route_evidence={}; counts={}
for obj in ['E_G','G_E']:
 objf=f['objectives'][obj]; evidence=[]; counts[obj]=collections.Counter(); all_clients=[]
 for k,route in enumerate(objf['canonical_routes']):
  assert route[0]==route[-1]==0 and 1<=len(route)-2<=5
  all_clients+=route[1:-1]; legs=[]
  for a,b in zip(route,route[1:]):
   ns=p['canonical_paths'][a][b]; assert ns[0]==g['service_node_ids'][a] and ns[-1]==g['service_node_ids'][b]
   assert not set(ns[1:-1]).intersection(g['service_node_ids'])
   es=[tuple(sorted(e)) for e in zip(ns,ns[1:])]; length=math.fsum(math.dist(nodes[u],nodes[v]) for u,v in zip(ns,ns[1:])); counts[obj].update(es)
   assert all(e in edge_weights and checked[e]['exact_safe'] and checked[e]['closed_containment'] for e in es)
   assert abs(length-p['unrounded_matrices']['G'][a][b])<=1e-8
   assert abs(length-p['integer_matrices']['G'][a][b]/1000)<=0.0005+1e-8
   legs.append({'from':a,'to':b,'node_path':ns,'G_integer_mm':p['integer_matrices']['G'][a][b],'E_integer_mm':p['integer_matrices']['E'][a][b],'saved_polyline_length_m':length})
  evidence.append({'route_number':k+1,'service_route':route,'load':len(route)-2,'legs':legs,'G_integer_mm':sum(l['G_integer_mm'] for l in legs),'saved_polyline_length_m':math.fsum(l['saved_polyline_length_m'] for l in legs)})
 assert sorted(all_clients)==list(range(1,13)); assert len(evidence)==3
 assert sum(r['G_integer_mm'] for r in evidence)==objf['G']
 assert sum(l['E_integer_mm'] for r in evidence for l in r['legs'])==objf['E']
 assert abs(math.fsum(r['saved_polyline_length_m'] for r in evidence)-float(sf['actual_path_lengths_m'][['E_G','G_E'].index(obj)]))<1e-8
 route_evidence[obj]=evidence
assert sf['order_loss_integer_mm']+sf['partition_loss_integer_mm']==f['delta_integer_mm']
total_delta=sum(x['delta_integer_mm'] for x in truth['fields']); share=f['delta_integer_mm']/total_delta*100
assert sum(x['delta_integer_mm']>0 for x in truth['fields'])==13
cross_edge=(110,111); cross_counts={o:counts[o][cross_edge] for o in counts}
font='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'; font_manager.fontManager.addfont(font)
plt.rcParams.update({'font.family':font_manager.FontProperties(fname=font).get_name(),'axes.unicode_minus':False,'font.size':11,'svg.fonttype':'path','axes.titleweight':'bold'})
C=['#187CA5','#DF8046','#8056A8']; INK='#18323E'; MUTED='#556A73'; BG='#FAFCFB'
def polygon(name):
 text=(B/name).read_text().strip(); assert text.startswith('POLYGON ((') and text.endswith('))')
 return [[float(x) for x in pair.split()] for pair in text[len('POLYGON (('):-2].split(',')]
poly=polygon('projected.wkt'); center=polygon('center.wkt'); origin=(314200,5848850)
xy=lambda coords: [(x-origin[0],y-origin[1]) for x,y in coords]
local=xy(services['coordinates']); polylocal=xy(poly); centerlocal=xy(center)
lims=(-12,400,-18,460)
def mapbase(ax):
 ax.set_facecolor(BG); ax.add_patch(Polygon(polylocal,facecolor='#E7EFE4',edgecolor='#758773',lw=1.1,zorder=1)); ax.plot(*zip(*centerlocal),color='#B0BCAE',lw=.65,zorder=2)
 ax.set_xlim(lims[0:2]);ax.set_ylim(lims[2:4]);ax.set_aspect('equal');ax.set_xticks([0,100,200,300,400]);ax.set_yticks([0,100,200,300,400]);ax.tick_params(labelsize=9,colors=MUTED,length=3);ax.grid(color='#DCE5E6',lw=.45,zorder=0);ax.set_axisbelow(True)
 for sp in ax.spines.values():sp.set_color('#C4CFD2')
 ax.set_xlabel('相对东向距离 / m',fontsize=10,color=MUTED);ax.set_ylabel('相对北向距离 / m',fontsize=10,color=MUTED)
def drawroute(ax,obj,k,alpha=1,lw=2.1,style='-'):
 for leg in route_evidence[obj][k]['legs']:
  pts=xy([nodes[n] for n in leg['node_path']]); ax.plot(*zip(*pts),color=C[k],lw=lw,alpha=alpha,ls=style,zorder=3+k,solid_capstyle='round')
def points(ax,obj,only=None):
 groups={c:k for k,r in enumerate(route_evidence[obj]) for c in r['service_route'][1:-1]}
 for i,(x,y) in enumerate(local):
  if i==0:
   ax.scatter(x,y,s=145,marker='*',facecolor=INK,edgecolor='white',lw=.9,zorder=15);ax.annotate('D',(x,y),xytext=(7,2),textcoords='offset points',fontsize=10,fontweight='bold',color=INK,zorder=16)
  else:
   selected=only is None or groups[i]==only
   ax.scatter(x,y,s=47 if selected else 22,facecolor=C[groups[i]] if selected else '#C2CDCB',edgecolor='white',lw=.7,zorder=12)
   ax.annotate(str(i),(x,y),xytext=(5,4),textcoords='offset points',fontsize=9.5,color=INK if selected else '#84938D',fontweight='bold' if selected else 'normal',zorder=16)
def route_label(obj,k):
 r=route_evidence[obj][k];return '路线'+str(k+1)+'  '+'→'.join('D' if c==0 else str(c) for c in r['service_route'])+f"   |   {r['G_integer_mm']/1000:,.3f} m"
fig=plt.figure(figsize=(16,12),facecolor='white')
fig.text(.045,.958,'地块 42：最大精确代理差，主要体现在客户分组',fontsize=23,fontweight='bold',color=INK)
fig.text(.045,.925,'真实地块边界 · 固定 12 个合成客户 + 仓库 D · 单位需求 · 容量 Q=5 · 至多 3 车（因此恰 3 条闭合路线）',fontsize=12.5,color=MUTED)
fig.text(.045,.889,f'最大精确代理差 638.238 m   |   占 124 块地总差值的 {share:.2f}%   |   13 块正差，111 块零差',fontsize=15,fontweight='bold',color=INK)
axes=[]
for j,obj in enumerate(['E_G','G_E']):
 ax=fig.add_axes([.065+.485*j,.43,.39,.374]);mapbase(ax)
 for k in range(3):drawroute(ax,obj,k,lw=3.0-.6*k,style=['-','--',':'][k])
 points(ax,obj);axes.append(ax)
 if j==0: ax.annotate('凹口末端\n保存路线在此绕行',xy=(310,76),xytext=(328,254),fontsize=9,color=MUTED,ha='center',arrowprops={'arrowstyle':'->','color':MUTED,'lw':.85},zorder=18)
 title='A  E 优先精确解（E 最小时再最小化 G）' if j==0 else 'B  G 优先精确解（G 最小时再最小化 E）'
 fig.text(.06+.485*j,.848,title,fontsize=14.5,fontweight='bold',color=INK)
 fig.text(.06+.485*j,.822, f"G = {f['objectives'][obj]['G']/1000:,.3f} m     E = {f['objectives'][obj]['E']/1000:,.3f} m",fontsize=12,color=MUTED)
 for k in range(3):fig.text(.055+.485*j,.371-k*.023,route_label(obj,k),fontsize=11.2,color=C[k])
fig.text(.055,.295,'所有彩色线均逐边复用已保存的 G 图路径；重合线可相互遮挡，逐车拆分见配套图。D 为仓库，1–12 为同一组客户。',fontsize=10.5,color=MUTED)
ax=fig.add_axes([.345,.136,.56,.122]);vals=[3244.853,3148.9,2606.615]; labels=['A：E 优先方案','固定 A 分组，组内 G 最优','B：G 最优方案']; colors=['#607D89','#DF8046','#187CA5']
ax.barh([2,1,0],vals,height=.53,color=colors); ax.set_yticks([2,1,0],labels,fontsize=11); ax.set_xlim(0,3600);ax.set_xticks([0,1000,2000,3000]);ax.grid(axis='x',color='#E1E8EA',lw=.6);ax.set_axisbelow(True);ax.set_xlabel('G 整数毫米代理换算为米（m）',fontsize=10.5,color=MUTED);ax.tick_params(length=0)
for y,v in zip([2,1,0],vals):ax.text(v+35,y,f'{v:,.3f}',va='center',fontsize=11,color=INK,fontweight='bold')
for sp in ax.spines.values():sp.set_visible(False)
fig.text(.055,.263,'差值分解',fontsize=14,fontweight='bold',color=INK)
fig.text(.055,.238,'排序：95.953 m',fontsize=11,color=MUTED)
fig.text(.055,.215,'分组：542.285 m',fontsize=11,color=MUTED)
fig.text(.055,.192,'分组占差值 85.0%',fontsize=11,color=INK,fontweight='bold')
fig.text(.045,.075,'口径：精确性仅针对已审计有限图及整数毫米矩阵。E 是欧氏距离代理；G 是该图上的已保存路径距离代理。',fontsize=10.5,color=MUTED)
fig.text(.045,.053,'分解只描述所选规范 E 优先解；不是所有 E 最优分组或因果效应。边界真实，客户任务为合成；不含车际避碰或同时调度。',fontsize=10.5,color=MUTED)
fig.text(.045,.031,'来源：已审计 124 田精确参照及冻结输入；此次新增求解 / 模型调用均为 0。局部坐标源 EPSG:32632，原点 (314200, 5848850) m。',fontsize=9.7,color=MUTED)
fig.savefig(OUT/'field42_proxy_gap_comparison_zh.png',dpi=170);fig.savefig(OUT/'field42_proxy_gap_comparison_zh.svg');plt.close(fig)
fig=plt.figure(figsize=(16,13),facecolor='white');fig.text(.055,.966,'地块 42：逐车查看保存的 G 路径',fontsize=23,fontweight='bold',color=INK);fig.text(.055,.935,'每幅图采用相同坐标范围与比例。仅拆开显示同一已保存方案；没有重新求解、改变客户分组或移动路线。',fontsize=12,color=MUTED)
for row,obj in enumerate(['E_G','G_E']):
 ybase=.555 if row==0 else .135
 fig.text(.055,ybase+.325,('A  E 优先方案：G = 3,244.853 m' if row==0 else 'B  G 最优方案：G = 2,606.615 m'),fontsize=16,fontweight='bold',color=INK)
 for k in range(3):
  ax=fig.add_axes([.07+k*.31,ybase,.255,.30]);mapbase(ax);drawroute(ax,obj,k,lw=2.4);points(ax,obj,only=k)
  r=route_evidence[obj][k]; fig.text(.06+k*.31,ybase-.045,f"路线 {k+1}  |  {r['load']} 个客户  |  G = {r['G_integer_mm']/1000:,.3f} m",fontsize=11.5,color=C[k],fontweight='bold')
  fig.text(.06+k*.31,ybase-.067,'→'.join('D' if c==0 else str(c) for c in r['service_route']),fontsize=11,color=INK)
fig.text(.055,.03,'彩线为原图实际保存边路径；浅绿为真实地块内部，灰绿细线为既定中心区域边界。成本为有限图整数毫米代理；不代表实车轨迹。',fontsize=10.5,color=MUTED)
fig.savefig(OUT/'field42_saved_G_routes_by_vehicle_zh.png',dpi=160);fig.savefig(OUT/'field42_saved_G_routes_by_vehicle_zh.svg');plt.close(fig)
evidence={'instance_id':'nl_field_42','status':'READ_ONLY_SAVED_ROUTE_VISUALIZATION_CHECKED','new_optimization_calls':0,'new_model_calls':0,'sources':sources,'source_archive_sha256':truth['input_final_archive_sha256'],'route_evidence':route_evidence,'summary':{'E_G_G_integer_mm':f['objectives']['E_G']['G'],'G_E_G_integer_mm':f['objectives']['G_E']['G'],'delta_integer_mm':f['delta_integer_mm'],'fixed_partition_G_integer_mm':sf['fixed_partition_G'],'order_loss_integer_mm':sf['order_loss_integer_mm'],'partition_loss_integer_mm':sf['partition_loss_integer_mm'],'panel_total_delta_integer_mm':total_delta,'field_share_of_panel_delta_pct':share,'positive_fields':13,'zero_fields':111,'panel_fields':124,'verified_objectives':248,'path_length_difference_m':sf['actual_path_length_difference_m'],'quantization_difference_bound_plus_saved_tolerance_m':sf['two_plan_rounding_plus_saved_path_tolerance_m']},'display':{'projection':proj['target_epsg'],'origin_m':origin,'same_limits_all_maps':lims,'path_geometry':'exact saved node coordinates, no offsets, smoothing, or connecting terminal shortcuts','customer_labels_original_ids':True},'selected_saved_edge_traversal_counts':{'edge_node_ids':cross_edge,'counts':cross_counts,'scope':'Descriptive tally only; not a new optimality or bottleneck certificate.'},'validation':{'saved_parent_bytes_identical':True,'input_identity_hashes_match':True,'all_shown_edges_present_in_saved_graph':True,'all_shown_edges_have_existing_exact_safe_audit':True,'all_route_costs_match_truth':True,'all_shown_leg_lengths_match_saved_unrounded_G_within_1e_8_m':True,'all_client_coverage_and_capacity_checks_pass':True,'no_new_route_search':True},'resources':{'wall_seconds':time.monotonic()-start,'cpu_seconds':time.process_time(),'maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'rlimit_cpu_seconds':60,'rlimit_as_bytes':512*1024**2}}
(OUT/'VISUAL_EVIDENCE.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2)+'\n')
(OUT/'README_ZH.txt').write_text('地块 nl_field_42 只读解释图\n\n主图：field42_proxy_gap_comparison_zh.png（配同名 SVG）\n逐车图：field42_saved_G_routes_by_vehicle_zh.png（配同名 SVG）\n\n结论：固定同一 depot+12 合成客户、单位需求、Q5、最多3车。E优先精确解在G上的代价3244.853米，G优先精确解2606.615米，精确整数代理差638.238米。保持规范E优先分组的G最优代价3148.900米，因此排序损失95.953米，分组损失542.285米（占差值约85.0%）。该田占124田总代理差70.79%；124田中13正、111零。\n\n主图两方案和逐车图均逐腿读取 preprocess.json 中 canonical_paths，并连接 graph.json 里对应的原始图节点。没有重建图、运行最短路、枚举或调用优化器。检查每条显示边在保存图中存在且已有exact_safe/closed_containment审计；端点为对应服务点，其他服务点不作中转；重算保存路径长度与原G浮点长度在1e-8米内相符，整数代价与真值完全相符。所有服务点覆盖一次、容量与3条路线均已检查。\n\n所有使用的几何、图和输入文件均与精确阶段持有的已审输入FINAL包逐字节一致。完整源路径、SHA-256、原包成员名、逐路线/逐腿图节点及成本记录在 VISUAL_EVIDENCE.json。render_review.py 为生成脚本。没有读取native质量输出，没有改动已有文件，没有上传或新增求解/模型调用。\n\n限制：G精确性属于已审计有限图与整数毫米代理；不称连续几何最优或实车轨迹。真实边界不等于真实任务。各路线可在地图上重合，线宽/虚线只服务显示，中心线坐标未偏移；逐车图可消除不同车辆相互遮挡。分解仅描述规范代表，不是所有E最优分组或因果效应。实际保存折线路径差为638.2375427976346米，整数代理差为638.238米；两方案差的取整及保存路径容差界0.01500030米，不涵盖测绘、投影、车辆执行误差。\n')
print(json.dumps({'out':str(OUT),'summary':evidence['summary'],'resources':evidence['resources'],'cross_counts':cross_counts},ensure_ascii=False,indent=2))
