# ee130 原路由净空审计交付索引

入口：reports/REPORT_zh.md。原始96条件表：raw/conditions.csv。逐路由逐段证据：raw/*_route.json；服务点：raw/services.json；最小值摘要：raw/routes_index.json。

冻结协议与文件哈希：freeze/。来源与原文件哈希：input/MANIFEST.json。单次执行与私有备份回读：evidence/。独立复核：evidence/INDEPENDENT_REVIEW.json；对应源码与完整证据在independent_review/。

本目录为独立新审计，不修改原规划器/原结果，不重规划或采样；r是预设假设，不代表实际农机尺寸。原raw未审状态按归档原样保留；请结合后续独立审计结论阅读。
