#!/usr/bin/python3
"""Static/input and synthetic-only audit. Never evaluates real-data geometry."""
import ast, datetime, hashlib, importlib.util, json, pathlib, sys, zipfile
from fractions import Fraction
sys.dont_write_bytecode=True
ROOT=pathlib.Path('/workspace/shared/ee130_route_clearance_audit_20261008')
ORIG=pathlib.Path('/workspace/shared/ee130_routing_scale_quality_20261008')
OUT=pathlib.Path('/workspace/shared/ee130_route_clearance_independent_review_20261008')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
report={'review_started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Frozen source/protocol/input identity and synthetic fixtures only. No real clearance evaluated.','real_data_clearance_computed':False,'checks':{},'findings':[]}
freeze=read(ROOT/'freeze/PREEXECUTION_FREEZE.json')
report['checks']['frozen_hashes']={'count':len(freeze['files']),'mismatches':[p for p,h in freeze['files'].items() if sha(ROOT/p)!=h]}
assert not report['checks']['frozen_hashes']['mismatches']
m=read(ROOT/'input/MANIFEST.json')
archive=pathlib.Path(m['original_archive']); assert sha(archive)==m['archive_sha256']
with zipfile.ZipFile(archive) as z:
    names=z.namelist(); checks=[]
    for s in m['sources']:
        p=pathlib.Path(s['original_path']); assert sha(p)==s['sha256']; assert p.stat().st_size==s['bytes']
        if 'copy_path' in s:assert (ROOT/s['copy_path']).read_bytes()==p.read_bytes()
        rel=p.relative_to(ORIG).as_posix(); candidates=[n for n in names if n==ORIG.name+'/'+rel]
        assert len(candidates)==1,(rel,candidates)
        assert z.read(candidates[0])==p.read_bytes()
        checks.append({'original_relative_path':rel,'archive_member':candidates[0],'byte_identical':True,'sha256':s['sha256']})
report['checks']['original_source_integrity']={'archive_sha256':sha(archive),'source_count':len(checks),'sources':checks}
route_checks=[]
for inst in m['instances']:
    iid=inst['instance_id']; inp=read(ROOT/inst['input_copy']); res=read(ROOT/inst['result_copy']); legs=read(ROOT/inst['used_legs_copy'])
    geom=read(ORIG/f'technical_r1/raw/{iid}_geometry.json')
    for method in ['nearest_neighbor','nn_2opt_budget']:
        row=res['methods'][method]; rebuilt=[]; rebuild_ids=[]
        for j,leg in enumerate(legs[method]):
            a,b=row['route'][j:j+2]; ids=geom['legal_leg_node_paths'][a][b]
            coords=[geom['nodes'][i] for i in ids]
            assert leg=={'service_leg':[a,b],'node_ids':ids,'coordinates':coords}
            assert coords[0]==inp['coordinates'][a] and coords[-1]==inp['coordinates'][b]
            rebuilt.extend(coords if j==0 else coords[1:]);rebuild_ids.extend(ids if j==0 else ids[1:])
        assert rebuilt==row['mapped_polyline_coordinates']
        assert rebuild_ids==row['mapped_polyline_node_ids']
        assert rebuilt[0]==rebuilt[-1]==inp['coordinates'][0]
        assert row['route'][0]==row['route'][-1]==0
        assert sorted(row['route'][1:-1])==list(range(1,inp['n']+1))
        route_checks.append({'instance_id':iid,'method':method,'polyline_vertices':len(rebuilt),'exact_saved_coordinate_reconstruction':True,'exact_saved_node_reconstruction':True,'valid_service_permutation':True})
assert len(route_checks)==24
report['checks']['route_identity']={'routes':route_checks,'count':len(route_checks),'clearance_not_evaluated':True}
# Import has no call to main; disable bytecode writes to frozen source.
spec=importlib.util.spec_from_file_location('frozen_clearance',ROOT/'source/audit_clearance.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
report['checks']['frozen_synthetic_tests']=mod.toy_tests()
# Separately specified synthetic whole-segment containment fixtures.
from osgeo import ogr
synthetic=[]
poly=ogr.CreateGeometryFromWkt('POLYGON ((0 0,10 0,10 10,0 10,0 0),(4 4,6 4,6 6,4 6,4 4))')
fixtures=[('outside_point',[[11,5]],False,1),('hole_interior_point',[[5,5]],False,1),('hole_boundary_point',[[4,5]],True,0),('hole_vertex',[[4,4]],True,0),('collinear_hole_crossing',[[3,5],[7,5]],False,0),('hole_vertex_tangent',[[3,5],[5,3]],True,0),('hole_boundary_overlap',[[3,4],[7,4]],True,0),('beyond_outer_collinear',[[0,-1],[0,1]],False,0),('outside_disjoint_segment',[[11,3],[11,7]],False,1),('identical_point_vertex',[[0,0],[0,0]],True,0),('interior_equality_1m',[[1,1],[3,1]],True,1),('reverse_interior_equality_1m',[[3,1],[1,1]],True,1)]
for name,coords,covered,d in fixtures:
    v=mod.evaluate_geometry(coords,poly,poly.Boundary(),mod.boundary_edges(poly))
    assert v['closed_field_covered']==covered,(name,v)
    assert abs(v['minimum_clearance_m']-d)<1e-12
    synthetic.append({'name':name,'coordinates':coords,'expected_covered':covered,'expected_distance_m':d,'observed_covered':v['closed_field_covered'],'observed_distance_m':v['minimum_clearance_m']})
concave=ogr.CreateGeometryFromWkt('POLYGON ((0 0,6 0,6 6,4 6,4 2,2 2,2 6,0 6,0 0))')
v=mod.evaluate_geometry([[1,5],[5,5]],concave,concave.Boundary(),mod.boundary_edges(concave))
assert not v['closed_field_covered'] and v['minimum_clearance_m']==0
synthetic.append({'name':'concave_outer_crossing_both_endpoints_inside','coordinates':[[1,5],[5,5]],'expected_covered':False,'expected_distance_m':0,'observed_covered':v['closed_field_covered'],'observed_distance_m':v['minimum_clearance_m']})
report['checks']['independent_synthetic_fixtures']={'count':len(synthetic),'cases':synthetic}
# Exact Fraction squared distance oracle independent of frozen Decimal algorithm.
def vec(a,b):return (b[0]-a[0],b[1]-a[1])
def dot(a,b):return a[0]*b[0]+a[1]*b[1]
def cross(a,b):return a[0]*b[1]-a[1]*b[0]
def orient(a,b,c):return cross(vec(a,b),vec(a,c))
def on(a,b,p):return orient(a,b,p)==0 and all(min(a[i],b[i])<=p[i]<=max(a[i],b[i]) for i in (0,1))
def pd2(p,a,b):
    v=vec(a,b); w=vec(a,p); q=dot(v,v)
    t=max(Fraction(0),min(Fraction(1),dot(w,v)/q)) if q else Fraction(0)
    return sum((p[i]-a[i]-t*v[i])**2 for i in (0,1))
def exact_d2(a,b,c,d):
    a,b,c,d=[tuple(Fraction(str(x)) for x in p) for p in (a,b,c,d)]
    os=[orient(a,b,c),orient(a,b,d),orient(c,d,a),orient(c,d,b)]
    if (os[0]*os[1]<0 and os[2]*os[3]<0) or any([on(a,b,c),on(a,b,d),on(c,d,a),on(c,d,b)]):return Fraction(0)
    return min(pd2(a,c,d),pd2(b,c,d),pd2(c,a,b),pd2(d,a,b))
pairs=[([[0,0],[10,0],[4,0],[6,0]],0),([[0,0],[1,0],[2,0],[3,0]],1),([[0,0],[1,1],[0,1],[1,0]],0),([[0,0],[0,0],[1,1],[3,1]],2),([[0,0],[2,0],[1,1],[1,1]],1),([[0,0],[2,0],[1,1],[3,1]],1),([[0,0],[2,1],[0,2],[1,2]],Fraction(9,5)),([[660000,6520000],[660010,6520000],[660004,6520000.5],[660006,6520000.5]],Fraction(1,4))]
pair_checks=[]
for coords,expected2 in pairs:
    ref=exact_d2(*coords); assert ref==expected2,(coords,ref,expected2)
    val=mod.independent_segseg(*coords)['distance_m'];geos=mod.geom_line(coords[:2]).Distance(mod.geom_line(coords[2:]))
    target=float(ref)**0.5; assert abs(val-target)<=mod.TOL and abs(geos-target)<=mod.TOL
    pair_checks.append({'coordinates':coords,'exact_reference_squared_distance':str(ref),'decimal_distance_m':val,'geos_distance_m':geos})
report['checks']['separate_fraction_oracle_synthetic_cases']={'count':len(pair_checks),'cases':pair_checks}
class_checks=[]
for r in [0.5,1.0,2.0]:
    for delta,expected in [(-2e-8,'FAIL_CLEARANCE'),(-5e-9,'BORDERLINE_WITHIN_TOLERANCE'),(0,'BORDERLINE_WITHIN_TOLERANCE'),(5e-9,'BORDERLINE_WITHIN_TOLERANCE'),(2e-8,'PASS')]:
        observed=mod.classify(r+delta,True,r); assert observed==expected
        class_checks.append({'radius_m':r,'delta_m':delta,'expected':expected,'actual':observed})
    assert mod.classify(r+10,False,r)=='FAIL_OUTSIDE_FIELD'
assert mod.classify(0,True,0)=='PASS' and mod.classify(0,False,0)=='FAIL_OUTSIDE_FIELD'
report['checks']['classification_thresholds']={'count':len(class_checks),'cases':class_checks}
report['findings']=[{'severity':'REPORTING_PRECISION','blocking':False,'detail':'Every boundary edge is evaluated independently with Decimal, but frozen code asserts agreement only for selected witness and global minimum. Do not claim each individual edge-pair distance was compared with GEOS to tolerance. Actual reported maximum errors are global-minimum and witness errors.'},{'severity':'LIMITATION','blocking':False,'detail':'Closed containment uses GEOS Difference and is checked for full lines and each segment. The independent Decimal routine verifies distance, not full containment. This is disclosed by the protocol.'},{'severity':'LIMITATION','blocking':False,'detail':'A Euclidean translating disk is a hypothetical footprint model. These checks do not establish steering/dynamics/implement clearance or empirical real-machine executability.'}]
report['real_raw_directory_present_at_review_end']=(ROOT/'raw/results.json').exists()
report['status']='PASS_STATIC_AND_SYNTHETIC_ONLY_PENDING_RAW_REVIEW'
report['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
(OUT/'PREEXECUTION_INDEPENDENT_REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['status','real_data_clearance_computed','real_raw_directory_present_at_review_end']}))
print('frozen_files',len(freeze['files']),'source_files',len(checks),'routes',len(route_checks),'synthetic_geometry_cases',7+len(synthetic),'fraction_cases',len(pair_checks),'classification_cases',len(class_checks))
