#!/usr/bin/python3
"""Independent saved-result review; rational geometry only, no optimizer or sampling."""
import csv, datetime, hashlib, json, math, pathlib, resource, sys, time, zipfile
from fractions import Fraction as Q
from osgeo import ogr, gdal
ogr.UseExceptions()
ROOT=pathlib.Path('/workspace/shared/ee130_route_clearance_audit_20261008')
OUT=pathlib.Path('/workspace/shared/ee130_route_clearance_independent_review_20261008')
TOL=1e-8
START=time.perf_counter(); CPU=time.process_time()
errors=[]; check_count=0

def require(v,label,detail=None):
    global check_count
    check_count+=1
    if not v:errors.append({'check':label,'detail':detail})

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def pointq(p):return tuple(Q(float(x)) for x in p)
def sub(a,b):return a[0]-b[0],a[1]-b[1]
def dot(a,b):return a[0]*b[0]+a[1]*b[1]
def cross(a,b):return a[0]*b[1]-a[1]*b[0]
def orientation(a,b,c):return cross(sub(b,a),sub(c,a))
def onseg(p,a,b):return orientation(a,b,p)==0 and all(min(a[i],b[i])<=p[i]<=max(a[i],b[i]) for i in (0,1))
def point_segment_squared(p,a,b):
    v=sub(b,a);w=sub(p,a);den=dot(v,v)
    if not den:return dot(w,w)
    t=dot(w,v)/den
    if t<=0:return dot(w,w)
    if t>=1:return dot(sub(p,b),sub(p,b))
    # Cross-product formula avoids rounding and explicitly minimizes over segment.
    return cross(v,w)**2/den

def segment_squared(a,b,c,d):
    o1,o2=orientation(a,b,c),orientation(a,b,d)
    o3,o4=orientation(c,d,a),orientation(c,d,b)
    if (o1*o2<0 and o3*o4<0) or onseg(c,a,b) or onseg(d,a,b) or onseg(a,c,d) or onseg(b,c,d):return Q(0)
    return min(point_segment_squared(a,c,d),point_segment_squared(b,c,d),point_segment_squared(c,a,b),point_segment_squared(d,a,b))

def gline(coords):
    if len(coords)==1 or coords[0]==coords[-1] and all(p==coords[0] for p in coords):
        g=ogr.Geometry(ogr.wkbPoint);g.AddPoint_2D(*coords[0]);return g
    g=ogr.Geometry(ogr.wkbLineString)
    for p in coords:g.AddPoint_2D(*p)
    return g

def classify(d,covered,r):
    if not covered:return 'FAIL_OUTSIDE_FIELD'
    if r==0:return 'PASS'
    if d<r-TOL:return 'FAIL_CLEARANCE'
    if d>r+TOL:return 'PASS'
    return 'BORDERLINE_WITHIN_TOLERANCE'

def merge(ss):
    if any(x.startswith('FAIL') for x in ss):return 'FAIL'
    if any(x.startswith('BORDERLINE') for x in ss):return 'BORDERLINE'
    return 'PASS'

receipt=read(ROOT.parent/(ROOT.name+'_RAW_DRIVE_RECEIPT.json'))
require(receipt['status']=='RAW_COMPLETE_UNAUDITED_ARCHIVE_VERIFIED' and receipt['verified'],'raw_gate_receipt')
require(receipt['sha256']=='2e30cfc5652cd1f0c61df5146cc2faad40011477c2c7d2ae16c8c9dc957b0ffe','raw_gate_known_hash')
archive=pathlib.Path(receipt['source']);require(sha(archive)==receipt['sha256'],'raw_archive_hash')
raw_before={p.relative_to(ROOT).as_posix():sha(p) for p in (ROOT/'raw').iterdir() if p.is_file()}
with zipfile.ZipFile(archive) as z:
    for rel,h in raw_before.items():require(hashlib.sha256(z.read(ROOT.name+'/'+rel)).hexdigest()==h,'raw_archive_member_identity',rel)
freeze=read(ROOT/'freeze/PREEXECUTION_FREEZE.json')
for p,h in freeze['files'].items():require(sha(ROOT/p)==h,'frozen_input_source_unchanged',p)

poly=ogr.CreateGeometryFromWkt((ROOT/'input/projected_epsg32634.wkt').read_text()); boundary=poly.Boundary()
require(poly.IsValid() and poly.GetGeometryName()=='POLYGON' and poly.GetGeometryCount()==4,'field_valid_polygon_3_holes')
edges=[];edge_by_id={}
for ri in range(poly.GetGeometryCount()):
    ring=poly.GetGeometryRef(ri)
    cs=[list(ring.GetPoint(i)[:2]) for i in range(ring.GetPointCount())]
    require(cs[0]==cs[-1],'ring_closed',ri)
    for ei,(a,b) in enumerate(zip(cs,cs[1:])):
        e={'ring_index':ri,'ring_type':'outer' if ri==0 else 'hole','hole_index':None if ri==0 else ri,'edge_index':ei,'a':a,'b':b}
        edges.append(e);edge_by_id[ri,ei]=len(edges)-1
require(edges==read(ROOT/'raw/boundary_edges.json'),'boundary_edges_match_field')
eq=[(pointq(e['a']),pointq(e['b'])) for e in edges]
eg=[gline([e['a'],e['b']]) for e in edges]
primitive_cache={}; max_pair_diff=0.; pair_count=0
primitive_evidence=[];max_min_diff=0.;max_witness_dist_error=0.

def primitive(coords):
    global max_pair_diff,pair_count
    key=tuple(sorted(tuple(p) for p in coords))
    if key not in primitive_cache:
        a,b=pointq(coords[0]),pointq(coords[-1]);g=gline(coords)
        # Rational values represent the exact binary64 coordinates passed to GEOS.
        d2=[segment_squared(a,b,c,d) for c,d in eq]
        ed=[g.Distance(e) for e in eg]
        diffs=[abs(float(q)**.5-d) for q,d in zip(d2,ed)]
        pair_count+=len(edges);max_pair_diff=max(max_pair_diff,max(diffs))
        require(max(diffs)<=TOL,'all_rational_edge_distances_agree_with_geos',{'coords':coords,'maximum_abs_difference_m':max(diffs)})
        mid=min(range(len(edges)),key=lambda i:(d2[i],i));mn=float(d2[mid])**.5
        gd=g.Distance(boundary);outside=g.Difference(poly)
        require(abs(gd-mn)<=TOL,'rational_global_minimum_vs_geos',{'coords':coords,'diff':abs(gd-mn)})
        primitive_cache[key]={'rational_distance_m':mn,'minimum_squared_distance_fraction':str(d2[mid]),'rational_minimum_edge_index':mid,'geos_distance_m':gd,'geos_edge_distances':ed,'closed_covered':bool(outside.IsEmpty()),'outside_geometry_wkt':outside.ExportToWkt()}
    return primitive_cache[key]

def check_record(rec,coords,label):
    global max_min_diff,max_witness_dist_error
    val=primitive(coords)
    require(sorted(rec['evaluation_coordinates'])==sorted(coords),'cached_orientation_valid',label)
    require(abs(rec['minimum_clearance_m']-val['rational_distance_m'])<=TOL,'saved_minimum_vs_rational',label)
    max_min_diff=max(max_min_diff,abs(rec['minimum_clearance_m']-val['rational_distance_m']))
    require(rec['minimum_clearance_m']==val['geos_distance_m'],'saved_minimum_exact_geos_repeat',label)
    require(rec['closed_field_covered']==val['closed_covered'],'saved_containment_repeat',label)
    require(rec['outside_geometry_wkt']==val['outside_geometry_wkt'],'saved_outside_geometry',label)
    require(rec['geos_exact_zero_distance']==(val['geos_distance_m']==0),'zero_flag',label)
    require(rec['within_contact_tolerance']==(val['geos_distance_m']<=TOL),'near_contact_flag',label)
    e=rec['witness'];wi=edge_by_id[e['ring_index'],e['edge_index']]
    require(e==edges[wi],'witness_boundary_identity',label)
    exact_geos_i=min(range(len(edges)),key=lambda i:(val['geos_edge_distances'][i],i))
    require(wi==exact_geos_i,'deterministic_witness_edge',label)
    require(rec['witness_edge_distance_m']==val['geos_edge_distances'][wi],'witness_edge_distance',label)
    expected_ties=[{'ring_index':e['ring_index'],'edge_index':e['edge_index']} for e,d in zip(edges,val['geos_edge_distances']) if abs(d-val['geos_edge_distances'][wi])<=TOL]
    require(rec['tied_edge_ids_within_tolerance']==expected_ties,'witness_ties',label)
    dw=rec['independent_decimal_witness'];rp=[float(x) for x in dw['route_point']];bp=[float(x) for x in dw['boundary_point']]
    rerr=gline([rp]).Distance(gline(coords));berr=gline([bp]).Distance(eg[wi]);derr=abs(math.dist(rp,bp)-float(dw['distance_decimal']))
    max_witness_dist_error=max(max_witness_dist_error,rerr,berr,derr)
    require(max(rerr,berr,derr)<=TOL,'decimal_witness_points_on_primitives_and_distance',{'label':label,'route_membership_error':rerr,'boundary_membership_error':berr,'distance_error':derr})
    for k in ['parameter_route','parameter_boundary','projection_parameter']:
        if k in dw:require(0<=float(dw[k])<=1,'witness_parameter_range',label)
    require(abs(float(dw['distance_decimal'])-dw['distance_m'])<=TOL,'decimal_distance_serialization',label)
    require(abs(dw['distance_m']-rec['witness_edge_distance_m'])==rec['independent_witness_abs_difference_m'],'reported_witness_delta',label)
    require(abs(rec['independent_global_minimum_m']-rec['minimum_clearance_m'])==rec['independent_global_abs_difference_m'],'reported_global_delta',label)
    require(rec['independent_global_abs_difference_m']<=TOL and rec['independent_witness_abs_difference_m']<=TOL,'reported_deltas_within_tau',label)
    gie=rec['independent_global_witness'];gii=edge_by_id[gie['ring_index'],gie['edge_index']]
    require(gie==edges[gii] and abs(val['geos_edge_distances'][gii]-val['rational_distance_m'])<=TOL,'independent_global_witness',label)
    for r in [0.,.5,1.,2.]:require(rec['radius_conditions'][str(r)]==classify(val['rational_distance_m'],val['closed_covered'],r),'primitive_radius_classification',{'label':label,'radius':r})
    return val

manifest=read(ROOT/'input/MANIFEST.json');raw=read(ROOT/'raw/results.json');services=read(ROOT/'raw/services.json')
require(len(services)==12 and len(raw['conditions'])==96,'expected_service_instance_and_condition_count')
serv_by_id={s['instance_id']:s for s in services};conditions={(c['instance_id'],c['method'],c['radius_m']):c for c in raw['conditions']}
require(len(conditions)==96,'unique_condition_keys')
route_evidence=[];calc_conditions=[];segment_uses=0;used_segment_keys=set();used_point_keys=set();saved_records=[]
for inst in manifest['instances']:
    iid=inst['instance_id'];inp=read(ROOT/inst['input_copy']);saved=read(ROOT/inst['result_copy']);sv=serv_by_id[iid]
    require(sv['n']==inp['n'] and sv['seed']==inp['seed'],'service_instance_identity',iid)
    require(len(sv['services'])==inp['n']+1,'service_count',iid)
    service_values=[]
    for i,(p,rec) in enumerate(zip(inp['coordinates'],sv['services'])):
        require(rec['coordinate']==p and rec['service_id']==i and rec['role']==('depot' if i==0 else 'task'),'service_id_role_coordinate',{'instance':iid,'service_id':i})
        service_values.append(check_record(rec,[p],{'instance_id':iid,'service_id':i}));saved_records.append(rec);used_point_keys.add(tuple(p))
    for method in ['nearest_neighbor','nn_2opt_budget']:
        rr=read(ROOT/f'raw/{iid}_{method}_route.json');src=saved['methods'][method];cs=src['mapped_polyline_coordinates'];ns=src['mapped_polyline_node_ids'];order=src['route']
        require(rr['instance_id']==iid and rr['method']==method and rr['n']==inp['n'] and rr['seed']==inp['seed'],'route_identity',iid+method)
        require(len(rr['segments'])==len(cs)-1,'segment_count',iid+method)
        legsrc=read(ROOT/inst['used_legs_copy'])[method];pos=0;segment_to_leg=[]
        for li,leg in enumerate(legsrc):
            segment_to_leg.extend([li]*(len(leg['coordinates'])-1))
        segvals=[]
        for i,(a,b,rec) in enumerate(zip(cs,cs[1:],rr['segments'])):
            li=segment_to_leg[i]
            require(rec['a']==a and rec['b']==b and rec['node_ids']==ns[i:i+2] and rec['segment_index']==i,'segment_original_identity',{'instance':iid,'method':method,'segment':i})
            require(rec['service_leg_index']==li and rec['service_leg']==order[li:li+2],'service_leg_assignment',{'instance':iid,'method':method,'segment':i})
            segvals.append(check_record(rec,[a,b],{'instance_id':iid,'method':method,'segment':i}));saved_records.append(rec)
            segment_uses+=1;used_segment_keys.add(tuple(sorted((tuple(a),tuple(b)))))
        full=gline(cs);fullc=full.Difference(poly).IsEmpty();fulld=full.Distance(boundary)
        minidx=min(range(len(segvals)),key=lambda i:(segvals[i]['geos_distance_m'],i))
        require(rr['closed_field_covered']==fullc==all(v['closed_covered'] for v in segvals),'whole_line_containment_and_all_segments',iid+method)
        require(rr['minimum_clearance_m']==fulld and abs(fulld-min(v['rational_distance_m'] for v in segvals))<=TOL,'whole_line_minimum',iid+method)
        require(rr['minimum_segment_index']==minidx and rr['minimum_witness']==rr['segments'][minidx]['witness'] and rr['minimum_independent_witness']==rr['segments'][minidx]['independent_decimal_witness'],'route_minimum_witness_location',iid+method)
        length=math.fsum(math.dist(a,b) for a,b in zip(cs,cs[1:]))
        require(abs(rr['saved_mapped_length_m']-length)<=TOL and rr['recomputed_mapped_length_m']==length and rr['saved_mapped_length_m']==src['mapped_polyline_length_m'],'saved_route_length_preserved',iid+method)
        require(rr['geos_exact_zero_distance']==(fulld==0) and rr['within_contact_tolerance']==(fulld<=TOL),'full_route_contact_flags',iid+method)
        route_evidence.append({'instance_id':iid,'method':method,'minimum_geos_clearance_m':fulld,'minimum_rational_clearance_m':min(v['rational_distance_m'] for v in segvals),'closed_field_covered':fullc,'minimum_segment_index':minidx,'minimum_witness_ring':rr['minimum_witness']['ring_index'],'minimum_witness_edge':rr['minimum_witness']['edge_index'],'segment_count':len(segvals),'service_count':len(service_values),'unchanged_route_length_m':length})
        for r in [0.,.5,1.,2.]:
            ss=[classify(v['rational_distance_m'],v['closed_covered'],r) for v in service_values]
            sg=[classify(v['rational_distance_m'],v['closed_covered'],r) for v in segvals]
            fs=[i for i,x in enumerate(ss) if x.startswith('FAIL')];bs=[i for i,x in enumerate(ss) if x.startswith('BORDERLINE')]
            fc=[i for i,x in enumerate(sg) if x.startswith('FAIL')];bc=[i for i,x in enumerate(sg) if x.startswith('BORDERLINE')]
            faillegs=sorted({segment_to_leg[i] for i in fc if all(ss[k]=='PASS' for k in order[segment_to_leg[i]:segment_to_leg[i]+2])})
            c={'instance_id':iid,'n':inp['n'],'seed':inp['seed'],'method':method,'radius_m':r,'status':merge(ss+sg),'full_centerline_covered':fullc,'minimum_route_clearance_m':fulld,'minimum_service_clearance_m':min(v['geos_distance_m'] for v in service_values),'depot_status':ss[0],'failing_task_ids':[i for i in fs if i>0],'borderline_task_ids':[i for i in bs if i>0],'service_points_status':merge(ss),'connecting_segments_status':merge(sg),'failing_segment_indices':fc,'borderline_segment_indices':bc,'connector_only_failure_all_service_points_pass':bool(fc) and all(s=='PASS' for s in ss),'failing_leg_indices_with_passing_service_endpoints':faillegs}
            require(c==conditions[iid,method,r],'complete_condition_reconstruction',{'instance_id':iid,'method':method,'radius':r})
            calc_conditions.append(c)

summary=raw['summary'];by_radius=[]
for r in [0.,.5,1.,2.]:
    cc=[c for c in calc_conditions if c['radius_m']==r]
    row={'radius_m':r,'PASS':sum(c['status']=='PASS' for c in cc),'FAIL':sum(c['status']=='FAIL' for c in cc),'BORDERLINE':sum(c['status']=='BORDERLINE' for c in cc),'service_point_failing_routes':sum(c['service_points_status']=='FAIL' for c in cc),'depot_failing_routes':sum(c['depot_status'].startswith('FAIL') for c in cc),'task_failing_routes':sum(bool(c['failing_task_ids']) for c in cc),'connecting_segment_failing_routes':sum(c['connecting_segments_status']=='FAIL' for c in cc),'connector_only_failing_routes':sum(c['connector_only_failure_all_service_points_pass'] for c in cc)}
    by_radius.append(row)
require(by_radius==summary['by_radius'],'summary_radius_counts')
expected={'route_count':len(route_evidence),'condition_count':len(calc_conditions),'all_routes_centerline_covered':all(v['closed_field_covered'] for v in route_evidence),'exact_boundary_contact_routes':sum(v['minimum_geos_clearance_m']==0 for v in route_evidence),'near_contact_routes':sum(v['minimum_geos_clearance_m']<=TOL for v in route_evidence),'segment_uses':segment_uses,'unique_segments':len(used_segment_keys),'unique_service_points':len(used_point_keys),'boundary_edges':len(edges),'ring_count':4,'maximum_independent_global_abs_difference_m':max(r['independent_global_abs_difference_m'] for r in saved_records),'maximum_independent_witness_abs_difference_m':max(r['independent_witness_abs_difference_m'] for r in saved_records)}
for k,v in expected.items():require(summary[k]==v,'summary_'+k,{'expected':v,'saved':summary[k]})
idx=read(ROOT/'raw/routes_index.json')
require(len(idx)==24,'route_index_count')
for row in idx:
    rr=read(ROOT/f'raw/{row["instance_id"]}_{row["method"]}_route.json');require(row=={k:v for k,v in rr.items() if k!='segments'},'route_index_matches_raw',row['instance_id']+row['method'])
with (ROOT/'raw/conditions.csv').open() as f:
    rows=list(csv.DictReader(f))
require(len(rows)==96,'csv_row_count')
for c,row in zip(raw['conditions'],rows):
    expectedcsv={k:json.dumps(v) if isinstance(v,list) else str(v) for k,v in c.items()}
    require(row==expectedcsv,'csv_matches_json',c['instance_id']+c['method']+str(c['radius_m']))
for rel,h in raw_before.items():require(sha(ROOT/rel)==h,'raw_results_remain_unmodified',rel)
for p,h in freeze['files'].items():require(sha(ROOT/p)==h,'frozen_source_input_remain_unmodified',p)

for key,v in primitive_cache.items():
    primitive_evidence.append({'coordinates':[list(p) for p in key],'minimum_rational_distance_m':v['rational_distance_m'],'minimum_squared_distance_fraction':v['minimum_squared_distance_fraction'],'rational_minimum_witness':edges[v['rational_minimum_edge_index']],'geos_distance_m':v['geos_distance_m'],'closed_covered_geos':v['closed_covered']})
resources={'wall_seconds':time.perf_counter()-START,'cpu_seconds':time.process_time()-CPU,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'python':sys.version,'gdal_version':gdal.VersionInfo('--version'),'geos_version':[ogr.GetGEOSVersionMajor(),ogr.GetGEOSVersionMinor(),ogr.GetGEOSVersionMicro()],'network_calls':0,'package_installs':0,'optimizer_calls':0,'sampling_calls':0,'raw_results_modified':False}
report={'status':'PASS_INDEPENDENT_SAVED_RESULT_AUDIT' if not errors else 'FAIL_INDEPENDENT_SAVED_RESULT_AUDIT','completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'raw_gate_sha256':receipt['sha256'],'checks_executed':check_count,'failures':errors,'frozen_file_count':len(freeze['files']),'raw_file_hashes':raw_before,'summary':expected,'by_radius':by_radius,'rational_review':{'coordinate_basis':'Exact Fraction conversion of original binary64 values passed to GDAL; all primitive-edge squared distances minimized algebraically. Square roots only converted for comparison/reporting. No path samples, no optimizer, no replanning.','unique_primitives':len(primitive_cache),'primitive_edge_pairs':pair_count,'maximum_all_pair_rational_vs_geos_abs_difference_m':max_pair_diff,'maximum_saved_minimum_vs_rational_abs_difference_m':max_min_diff,'maximum_witness_location_or_distance_error_m':max_witness_dist_error,'all_pair_tolerance_m':TOL},'routes':route_evidence,'conditions':calc_conditions,'unique_primitive_evidence':primitive_evidence,'limitations':['Containment is independently rerun with the same GDAL/GEOS kernel, not a separate formal full-containment proof.','Rational checks use represented binary64 geometry, not survey truth.','Hypothetical translating disk only; no machine dimensions, turning/heading/dynamics/implement/coverage conclusions.','Twelve instances are nested prefixes on one field, not twelve independent fields.'],'resources':resources,'review_source_sha256':sha(pathlib.Path(__file__))}
write(OUT/'INDEPENDENT_SAVED_RESULT_AUDIT.json',report);write(OUT/'RESOURCES.json',resources)
print(json.dumps({'status':report['status'],'checks_executed':check_count,'failure_count':len(errors),'by_radius':by_radius,'rational_review':report['rational_review'],'resources':resources},ensure_ascii=False,indent=2))
if errors:print(json.dumps(errors[:10],ensure_ascii=False,indent=2));sys.exit(1)
