#!/usr/bin/python3
import datetime,hashlib,json,os,pathlib,resource,subprocess,sys,time
ROOT=pathlib.Path(__file__).resolve().parents[1]
def dump(path,obj):path.write_text(json.dumps(obj,indent=2)+'\n')
def limit():
 resource.setrlimit(resource.RLIMIT_CPU,(120,120))
 resource.setrlimit(resource.RLIMIT_AS,(1073741824,1073741824))
def main():
 started=ROOT/'evidence/STARTED.json'
 with started.open('x') as f:json.dump({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'attempt':1,'cpu_limit_s':120,'wall_limit_s':240,'memory_limit_bytes':1073741824},f,indent=2)
 before=resource.getrusage(resource.RUSAGE_CHILDREN);wall=time.perf_counter()
 try:
  with (ROOT/'evidence/STDOUT.log').open('w') as out,(ROOT/'evidence/STDERR.log').open('w') as err:
   result=subprocess.run(['/usr/bin/python3',str(ROOT/'source/audit_clearance.py')],stdout=out,stderr=err,timeout=240,preexec_fn=limit,env={**os.environ,'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1'})
  code=result.returncode;status='COMPLETE_UNAUDITED' if code==0 else 'FAILED'
 except subprocess.TimeoutExpired:code=None;status='WALL_TIMEOUT'
 after=resource.getrusage(resource.RUSAGE_CHILDREN)
 dump(ROOT/'evidence/RUN_STATUS.json',{'status':status,'exit_code':code,'wall_seconds':time.perf_counter()-wall,'children_cpu_seconds':after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime,'children_peak_rss_kib':after.ru_maxrss,'one_formal_execution':True})
 print(status)
 if status!='COMPLETE_UNAUDITED':sys.exit(1)
if __name__=='__main__':main()
