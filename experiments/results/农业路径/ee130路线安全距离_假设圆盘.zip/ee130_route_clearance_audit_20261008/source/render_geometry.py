#!/usr/bin/python3
"""Post-run illustration only; reads original geometry and saved audit output."""
import json, pathlib, os
os.environ['MPLCONFIGDIR']='/tmp/ee130_clearance_mpl'
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Circle
from osgeo import ogr
R=pathlib.Path(__file__).resolve().parents[1]
poly=ogr.CreateGeometryFromWkt((R/'input/projected_epsg32634.wkt').read_text())
iid='n12_s202610081001';off=(661850,6526070)
def local(p):return p[0]-off[0],p[1]-off[1]
fig,axes=plt.subplots(1,2,figsize=(12,7),sharex=True,sharey=True)
fig.subplots_adjust(left=0.07,right=0.99,top=0.84,bottom=0.15,wspace=0.12)
for ax,method,label in zip(axes,['nearest_neighbor','nn_2opt_budget'],['Original nearest neighbor','Original NN + 2-opt']):
 for ri in range(poly.GetGeometryCount()):
  ring=poly.GetGeometryRef(ri);c=[local(ring.GetPoint(i)) for i in range(ring.GetPointCount())]
  ax.fill([p[0] for p in c],[p[1] for p in c],facecolor='#f0f2f3' if ri==0 else 'white',edgecolor='#333333',linewidth=1.2,zorder=1)
 rec=json.loads((R/f'raw/{iid}_{method}_route.json').read_text())
 for seg in rec['segments']:
  a,b=local(seg['a']),local(seg['b']);color='#d55e00' if seg['radius_conditions']['1.0'].startswith('FAIL') else '#007f86'
  ax.plot([a[0],b[0]],[a[1],b[1]],color=color,lw=1.7,zorder=2,alpha=0.9)
 pts=json.loads((R/f'input/{iid}_input.json').read_text())['coordinates'];v=[local(p) for p in pts]
 ax.scatter([p[0] for p in v[1:]],[p[1] for p in v[1:]],s=16,c='#555555',zorder=3)
 ax.scatter(*v[0],s=100,c='black',marker='*',zorder=4)
 w=rec['minimum_independent_witness'];rp=local([float(x) for x in w['route_point']]);bp=local([float(x) for x in w['boundary_point']])
 ax.scatter(*rp,color='#91288c',s=36,zorder=5);ax.plot([rp[0],bp[0]],[rp[1],bp[1]],color='#91288c',lw=3,zorder=5)
 ax.add_patch(Circle(rp,2,fill=False,color='#91288c',lw=1.5,zorder=4))
 ax.annotate('Minimum witness\n2 m disk outline',xy=rp,xytext=(175,100),fontsize=8,ha='left',arrowprops={'arrowstyle':'->','color':'#91288c'},color='#91288c')
 ax.set_title(f'{label}\nMinimum clearance = {rec["minimum_clearance_m"]:.6f} m',fontsize=11)
 ax.set_aspect('equal');ax.set_xlabel('Easting minus 661850 (m)');ax.grid(alpha=0.12)
axes[0].set_ylabel('Northing minus 6526070 (m)')
fig.suptitle('ee130: fixed 12-task layout, seed 202610081001',fontsize=14,y=0.985)
handles=[Line2D([0],[0],color='#007f86',lw=2,label='Segment passes r = 1 m'),Line2D([0],[0],color='#d55e00',lw=2,label='Segment fails r = 1 m'),Line2D([0],[0],marker='*',color='k',ls='',markersize=9,label='Depot')]
fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(0.5,0.02),ncol=3,frameon=False,fontsize=9)
fig.savefig(R/'reports/geometry_example.png',dpi=180)
(R/'evidence/FIGURE_DESCRIPTION.json').write_text(json.dumps({'instance_id':iid,'selection':'Post-result explanatory same-instance contrast; not representative sampling or new numerical evidence.','coordinates':'Original EPSG32634 coordinates translated by (661850,6526070) for axis readability; metric scale unchanged.','geometry':'Original outer ring plus all three holes; no buffering; circles are visual hypothetical r=2m disks only.','colors':'Based solely on saved segment condition for r=1m.','minimum_witness':'Saved numerical witness; not survey ground truth.'},indent=2)+'\n')
