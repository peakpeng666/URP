import datetime,hashlib,json,pathlib,shutil,zipfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
ORIG=pathlib.Path('/workspace/shared/ee130_routing_scale_quality_20261008')
ARCHIVE=pathlib.Path('/workspace/shared/recovery_parallel_experiments_20261008/ee130路径规模质量_完整证据_20261008.zip')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
assert sha(ARCHIVE)=='8a1a6016d9caccb4f39a5e9c044beb6a4a285ffe73e1d00f7d751ec89722ed01'
assert not (ROOT/'evidence/STARTED.json').exists()
sources=[]
def register(src,dst=None):
 item={'original_path':str(src),'sha256':sha(src),'bytes':src.stat().st_size}
 if dst:
  shutil.copyfile(src,ROOT/dst);item['copy_path']=dst
 sources.append(item)
register(ORIG/'input/projected_epsg32634.wkt','input/projected_epsg32634.wkt')
register(ORIG/'input/crs_provenance.json','input/crs_provenance.json')
register(ORIG/'freeze/PROTOCOL.json','input/original_PROTOCOL.json')
register(ORIG/'technical_r1/freeze/PROTOCOL.json','input/original_technical_r1_PROTOCOL.json')
insts=[]
for n in [8,12,20,40]:
 for seed in [202610081001,202610081002,202610081003]:
  iid=f'n{n:02d}_s{seed}'
  a=f'input/{iid}_input.json';b=f'input/{iid}_result.json';c=f'input/{iid}_used_legs.json'
  register(ORIG/f'technical_r1/input/{iid}.json',a)
  register(ORIG/f'technical_r1/raw/{iid}_result.json',b)
  gp=ORIG/f'technical_r1/raw/{iid}_geometry.json';register(gp)
  g=json.loads(gp.read_text());result=json.loads((ROOT/b).read_text());legs={}
  for method in ['nearest_neighbor','nn_2opt_budget']:
   legs[method]=[];order=result['methods'][method]['route']
   for i,j in zip(order,order[1:]):
    ids=g['legal_leg_node_paths'][i][j]
    legs[method].append({'service_leg':[i,j],'node_ids':ids,'coordinates':[g['nodes'][k] for k in ids]})
  write(ROOT/c,legs)
  insts.append({'instance_id':iid,'n':n,'seed':seed,'input_copy':a,'result_copy':b,'used_legs_copy':c})
write(ROOT/'input/MANIFEST.json',{'original_archive':str(ARCHIVE),'archive_sha256':sha(ARCHIVE),'original_drive_id':'1AHMhdSpqysCxIRAmW_4_Q5zf_UiEicOq','geometry_crs':'EPSG:32634','instances':insts,'sources':sources,'selected_legs_note':'Only recorded used leg paths selected from original geometry JSON; no graph rebuild or solving. Full original geometry file hashes retained above; verified archive preserves all originals.'})
protocol={
 'study':'ee130_frozen_route_clearance_audit_v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'question':'Which of the 24 previously mapped NN/2opt routes remain feasible for a hypothetical translating disk center at r=0,0.5,1,2 metres?',
 'fixed_instances':{'sizes':[8,12,20,40],'seeds':[202610081001,202610081002,202610081003],'methods':['nearest_neighbor','nn_2opt_budget'],'routes':24,'route_radius_conditions':96},
 'radius_m':[0,0.5,1,2],
 'hypothesis':'r is a prespecified illustrative radius, not measured agricultural machine size. Static translating circular footprint only. Orientation, turning radius, dynamics, implement articulation, ground uncertainty and coverage not modeled.',
 'geometry':'Unchanged previously projected EPSG:32634 ee130 WKT, original outer ring and three holes. Raw saved binary64 route coordinates retained. No projection, repair, buffer, snapping, simplification, obstacle widening, replanning, sampling or objective optimization.',
 'closed_containment':'Entire original line and each full segment must satisfy GDAL/GEOS Difference(original_field).IsEmpty(). Boundary is included, hole interiors and exterior excluded. No geometric tolerance buffer. Save resulting outside WKT if nonempty. Points tested by same closed-field predicate.',
 'distance':'Minimum Euclidean distance to Boundary(original_field), all outer/hole ring edges. Per route, segment, task and depot. Every segment edge enumerated; locate minimum by zero-based route segment, ring, edge and coordinates. Minimum ties within tau listed, exact minimum uses deterministic first edge order. Keep analytic witness evaluation orientation in evaluation_coordinates when an undirected segment cache is reused.',
 'numerics':{'distance_tolerance_m':1e-8,'floating_arithmetic':'GEOS binary64, independent Decimal precision60 projection/intersection checks using original serialized decimal coordinate values; both numerical evidence, not survey truth or formally certified continuous proof.',
 'r_zero':'PASS iff entire centerline closed-field covered. Exact GEOS d==0 and 0<=d<=tau reported separately; contact permitted only under this r=0 idealization.',
 'r_positive':'FAIL if uncovered or d<r-tau. PASS only if covered and d>r+tau. abs(d-r)<=tau is BORDERLINE, not rounded into PASS. Nominal mathematical d>=r permits disk touching field boundary, but finite-precision equality is held out. Route status combines all services and segments; any fail -> FAIL, else any borderline -> BORDERLINE, else PASS.'},
 'attribution':'Separately retain failing/borderline task IDs, depot status and all failing/borderline segment IDs. Connector-only failure means all service points PASS but a segment FAIL. Also list failed service legs whose two service endpoints PASS. Segment failures overlap with service failures; counts must not be added as disjoint categories.',
 'independent_checks':'Synthetic known distances/containment, including hole crossing with endpoints inside; independent Decimal point-to-segment projections and intersection calculation for every evaluated primitive against every boundary edge, plus nearest witness projection parameters. Check all to tau; no reoptimization or independent full containment proof.',
 'resources':{'cpu_seconds':120,'wall_seconds':240,'address_space_bytes':1073741824,'single_process_worker':True,'formal_attempts':1},
 'execution_gate':'Frozen protocol/source/input hashes and pre-execution synthetic-only toy checks privately archived and read back before single formal execution. Raw outputs privately archived and read back as UNAUDITED before interpretation/report.',
 'no_network_or_install_in_experiment':True,
 'scope':'Twelve instances are four nested prefixes of three seed layouts on one field; no inference to independent fields, no significance claim or real-machine executability claim. Any later clearance replanning must be a separate freeze retaining original findings.'}
write(ROOT/'freeze/PROTOCOL.json',protocol)
files={str(p.relative_to(ROOT)):sha(p) for directory in ['input','source','freeze'] for p in sorted((ROOT/directory).rglob('*')) if p.is_file() and p.name!='PREEXECUTION_FREEZE.json'}
files['evidence/PREEXECUTION_TOY_TESTS.json']=sha(ROOT/'evidence/PREEXECUTION_TOY_TESTS.json')
files['evidence/PREEXECUTION_RESOURCE_SMOKE.json']=sha(ROOT/'evidence/PREEXECUTION_RESOURCE_SMOKE.json')
write(ROOT/'freeze/PREEXECUTION_FREEZE.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'FROZEN_BEFORE_REAL_DATA_CLEARANCE_EVALUATION','files':files})
out=ROOT.parent/(ROOT.name+'_PREEXECUTION_SNAPSHOT.zip')
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(ROOT.rglob('*')):
  if p.is_file():z.write(p,str(p.relative_to(ROOT.parent)))
print(json.dumps({'path':str(out),'bytes':out.stat().st_size,'sha256':sha(out),'files_frozen':len(files)}))
