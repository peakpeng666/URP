#!/usr/bin/python3
"""Recompute saved route geometry only. No author imports or route search.
Frozen before RAW release; exact original WKT/JSON decimal tokens are primary.
"""
import collections,datetime,decimal,hashlib,json,math,pathlib,resource,sys,time,zipfile
from decimal import Decimal
from fractions import Fraction
from integer_geometry import *
from osgeo import ogr
R=pathlib.Path(__file__).resolve().parents[1]
A=R.parent
OLD=pathlib.Path('/workspace/shared/ee130_clearance_aware_routing_20261008')
METHODS=['nearest_neighbor','nn_2opt_budget']
decimal.getcontext().prec=100

def read(p):return json.loads(p.read_text(),parse_float=Decimal)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def emit(p,x):
    with p.open('x') as f:json.dump(x,f,indent=2,ensure_ascii=False,default=str);f.write('\n')
def dec(q):return Decimal(q.numerator)/Decimal(q.denominator)
def evrow(ev):
    lo,hi=enclosing(ev['q']); ml,mh=enclosing(ev['q'],Fraction('1.1'))
    return {'squared_distance_numerator':str(ev['q'].numerator),'squared_distance_denominator':str(ev['q'].denominator),'covered':ev['covered'],'clearance_interval_m':[str(dec(lo)),str(dec(hi))],'excess_over_1_10_interval_m':[str(dec(ml)),str(dec(mh))],'clearance_decimal_m':str(dec(ev['q']).sqrt()),'status':labels(ev['q'],ev['covered'],'0.10')[1],'witness_ring_edge':[ev['ring'],ev['edge']],'route_witness':[str(x) for x in ev['route_witness']],'boundary_witness':[str(x) for x in ev['boundary_witness']]}

def check_saved_operations(iid,data,graph):
    matrix=graph['distance_matrix'];n=len(matrix)-1
    methods=data['methods'];nnroute=methods['nearest_neighbor']['route'];remaining=set(range(1,n+1))
    for previous,chosen in zip(nnroute,nnroute[1:-1]):
        assert chosen==min(remaining,key=lambda q:(matrix[previous][q],q)),(iid,'saved NN decision')
        remaining.remove(chosen)
    assert not remaining and methods['nearest_neighbor']['operations']['distance_candidates']==n*(n+1)//2
    route=methods['nn_2opt_budget'];stats=route['operations'];tries=stats['candidate_reversals'];moves=stats['moves']
    assert stats['candidate_budget']==10000 and 0<=tries<=10000 and stats['accepted_moves']==len(moves)
    work=list(nnroute);last=0
    cost=lambda seq:sum(matrix[x][y] for x,y in zip(seq,seq[1:]))
    scan=[(i,j) for i in range(1,n) for j in range(i+1,n+1) if not(i==1 and j==n)]
    for m in moves:
        i,j=m['i'],m['j'];assert (i,j) in scan and m['candidate']==last+scan.index((i,j))+1 and m['candidate']<=tries
        before=cost(work);a,b,c,d=work[i-1],work[i],work[j],work[j+1]
        delta=matrix[a][c]+matrix[b][d]-matrix[a][b]-matrix[c][d]
        work[i:j+1]=reversed(work[i:j+1]);after=cost(work)
        assert delta<Decimal('-1e-9') and after<before
        assert max(abs(before-m['before_m']),abs(after-m['after_m']),abs(delta-m['delta_estimate_m']))<=Decimal('1e-8')
        last=m['candidate']
    assert work==route['route'] and cost(work)<=cost(nnroute)+Decimal('1e-8')
    assert ((stats['termination']=='BUDGET_EXHAUSTED' and tries==10000) or (stats['termination']=='NO_IMPROVING_FULL_SWEEP' and tries-last==len(scan) and tries<10000))
    return {'saved_NN_decisions_verified':True,'saved_2opt_moves_verified':len(moves),'saved_2opt_candidate_reversals':tries,'rejected_candidates_not_researched':True}

def main():
    assert len(sys.argv)==3 and sys.argv[1]=='--released-raw-receipt'
    archive_checks=[]
    for receiptpath,manifestpath in [(A/'evidence/PREEXECUTION_DRIVE_RECEIPT.json',A/'freeze/PREEXECUTION_FREEZE.json'),(pathlib.Path(sys.argv[2]),A/'evidence/RAW_COMPLETE_UNAUDITED_MANIFEST.json')]:
        gate=read(receiptpath);assert gate.get('verified') is True and gate.get('download_byte_identical') is True
        assert gate.get('permissions')=='owner_only' and gate.get('shared') is False
        original=pathlib.Path(gate['source']);download=pathlib.Path(gate['download_path'])
        assert gate['sha256']==gate['download_sha256']==sha(original)==sha(download)
        assert original.read_bytes()==download.read_bytes() and original.stat().st_size==gate['bytes']
        manifest=read(manifestpath)
        with zipfile.ZipFile(download) as z:
            assert len(z.namelist())==len(set(z.namelist()))
            for rel,digest in manifest['files'].items():
                assert hashlib.sha256(z.read(A.name+'/'+rel)).hexdigest()==digest==sha(A/rel),rel
        archive_checks.append({'receipt':str(receiptpath),'archive_sha256':sha(download),'bytes':download.stat().st_size,'confirmed_utc':gate['confirmed_at_utc'],'manifest_members_verified':len(manifest['files'])})
    resource.setrlimit(resource.RLIMIT_CPU,(60,60));resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912))
    t=time.perf_counter();cpu=time.process_time()
    freeze=read(A/'freeze/PREEXECUTION_FREEZE.json')
    for rel,digest in freeze['files'].items():assert sha(A/rel)==digest,rel
    for rel,entry in read(A/'freeze/INPUT_IDENTITY.json').items():assert sha(A/rel)==entry['sha256']==sha(pathlib.Path(entry['source_path']))
    for path,digest in read(A/'freeze/UPSTREAM_IMMUTABILITY.json').items():assert sha(pathlib.Path(path))==digest
    run=read(A/'evidence/RUN_STATUS.json');started=read(A/'evidence/STARTED.json')
    assert started['attempt']==1 and run['one_formal_execution'] is True
    stamp=lambda v:datetime.datetime.fromisoformat(v.replace('Z','+00:00'))
    assert stamp(archive_checks[0]['confirmed_utc'])<stamp(started['started_utc'])<stamp(run['finished_utc'])<stamp(archive_checks[1]['confirmed_utc'])
    assert started['preexec_zip_sha256']==archive_checks[0]['archive_sha256']
    assert started['cpu_limit_s']==60 and started['wall_limit_s']==120 and started['memory_limit_bytes']==536870912
    assert run['children_cpu_seconds']<=60 and run['wall_seconds']<121 and run['children_peak_rss_kib']*1024<536870912
    before={str(p.relative_to(A)):sha(p) for p in sorted((A/'raw').rglob('*')) if p.is_file()}
    inp={read(p)['instance_id']:read(p) for p in sorted((A/'input').rglob('n*_input.json'))}
    assert len(inp)==12 and {(d['n'],d['seed']) for d in inp.values()}=={(n,s) for n in (8,12,20,40) for s in (202610081001,202610081002,202610081003)}
    for iid,data in inp.items():assert data==read(OLD/'input'/f'{iid}_input.json')
    for seed in (202610081001,202610081002,202610081003):
        layouts=sorted([d for d in inp.values() if d['seed']==seed],key=lambda x:x['n'])
        for short,long in zip(layouts,layouts[1:]):assert short['coordinates']==long['coordinates'][:len(short['coordinates'])]
    wkt=(A/'input/projected_epsg32634.wkt').read_text();assert wkt==(OLD/'input/projected_epsg32634.wkt').read_text()
    tokens=read_wkt_rings(wkt)
    newroutes={p.name:read(p) for p in sorted((A/'raw').glob('*_solver_output.json'))}
    oldroutes={p.name:read(p) for p in sorted((A/'input/routes').glob('*_solver_output.json'))};assert len(oldroutes)==8
    allpoints=[p for r in tokens for p in r]+[p for d in inp.values() for p in d['coordinates']]+[p for d in list(newroutes.values())+list(oldroutes.values()) for p in d['mapped_polyline_coordinates']]
    scale=10**max(decimal_places(v) for p in allpoints for v in p)
    rings=[grid_points(r,scale) for r in tokens];border=edges(rings);assert len(rings)==4 and validate_rings(rings)
    field=ogr.CreateGeometryFromWkt(wkt);assert field.IsValid();boundary=field.Boundary()
    cache={};maxdiff=Decimal(0)
    def evaluate(a,b):
        nonlocal maxdiff
        key=tuple(sorted((a,b)))
        if key not in cache:
            ev=clearance(a,b,rings,scale,border)
            g=ogr.Geometry(ogr.wkbPoint if a==b else ogr.wkbLineString)
            for p in ([a] if a==b else [a,b]):g.AddPoint_2D(float(Fraction(p[0],scale)),float(Fraction(p[1],scale)))
            assert bool(g.Difference(field).IsEmpty())==ev['covered']
            diff=abs(Decimal(str(g.Distance(boundary)))-dec(ev['q']).sqrt());assert diff<=Decimal('1e-8');maxdiff=max(maxdiff,diff)
            cache[key]=ev
        return cache[key]
    summary=read(A/'raw/results.json');results={x['instance_id']:x for x in summary['instances']};assert len(results)==12 and set(results)==set(inp)
    endpoint_rows=[];ecount=0
    for iid,data in inp.items():
        assert len(data['coordinates'])==data['n']+1
        values=[evaluate(p,p) for p in grid_points(data['coordinates'],scale)]
        statuses=[labels(v['q'],v['covered'],'0.10')[1] for v in values]
        bad=[i for i,s in enumerate(statuses) if s=='FAIL'];unc=[i for i,s in enumerate(statuses) if s=='UNCERTAIN_THRESHOLD']
        saved=results[iid]
        assert saved['failing_service_ids']==bad and saved['uncertain_service_ids']==unc
        assert len(saved['services'])==len(values)
        for sid,(ev,author,p) in enumerate(zip(values,saved['services'],data['coordinates'])):
            assert author['service_id']==sid and author['coordinate']==p
            expected={'PASS':'PASS','FAIL':'FAIL','UNCERTAIN_THRESHOLD':'UNCERTAIN_BOUNDARY'}[statuses[sid]]
            assert author['clearance_status']==expected
            assert abs(dec(ev['q']).sqrt()-author['minimum_clearance_m'])<=Decimal('1e-8')
            ecount+=1
        if bad:assert saved['status']=='TASK_INFEASIBLE' and not saved['methods']
        if unc and not bad:assert saved['status']=='UNCERTAIN_ENDPOINT_NUMERICS' and not saved['methods']
        if bad or unc:assert not any(name.startswith(iid+'_') for name in newroutes)
        endpoint_rows.append({'instance_id':iid,'n':data['n'],'seed':data['seed'],'failing_service_ids':bad,'uncertain_service_ids':unc,'endpoint_status':'FAIL' if bad else 'UNCERTAIN' if unc else 'PASS_NECESSARY_ONLY','reported_planning_status':saved['status'],'minimum':evrow(min(values,key=lambda x:x['q'])),'services':[{'service_id':i,**evrow(e)} for i,e in enumerate(values)]})
    sharedpath=A/'raw/shared_preprocessing.json';shared=read(sharedpath) if sharedpath.exists() else None
    center_summary=None
    if (A/'raw/center_region.wkt').exists():
        center=ogr.CreateGeometryFromWkt((A/'raw/center_region.wkt').read_text())
        valid=bool(center.IsValid()) and not center.IsEmpty();covered=bool(center.Difference(field).IsEmpty());distance=Decimal(str(center.Distance(boundary)))
        holes=[]
        for ri in range(1,4):
            hole=ogr.Geometry(ogr.wkbPolygon);hole.AddGeometry(field.GetGeometryRef(ri));holes.append(bool(center.Intersection(hole).IsEmpty()))
        center_summary={'valid_nonempty':valid,'whole_filled_region_covered':covered,'minimum_full_region_clearance_m':str(distance),'original_holes_disjoint':holes}
        if shared and shared['geometry']['status']=='POSTERIOR_NUMERIC_REGION_PASS':assert valid and covered and distance>Decimal('1.10000001') and all(holes)
    if shared and shared['geometry']['status']=='POSTERIOR_NUMERIC_REGION_PASS':
        b=len(shared['nodes']);assert shared['candidate_edge_checks']==b*(b-1)//2
        assert shared['geometry']['quadrant_segments']==16 and shared['geometry']['numerical_margin_m']==Decimal('0.00001')
        assert abs(float(shared['geometry']['buffer_distance_m'])-1.10001/math.cos(math.pi/32))<1e-14
    graph_cache={};operation_checks={}
    def route_audit(name,route,new):
        method=next(m for m in METHODS if name.endswith('_'+m+'_solver_output.json'));iid=name[:-len('_'+method+'_solver_output.json')];data=inp[iid]
        coords=grid_points(route['mapped_polyline_coordinates'],scale);ids=route['mapped_polyline_node_ids'];order=route['route'];tasks=grid_points(data['coordinates'],scale)
        assert len(order)==data['n']+2 and order[0]==order[-1]==0 and collections.Counter(order[1:-1])==collections.Counter(range(1,data['n']+1))
        assert coords[0]==coords[-1]==tasks[0] and len(ids)==len(coords) and len(route['legs'])==len(order)-1
        rebuilt=[];offset=0
        for k,leg in enumerate(route['legs']):
            assert leg['service_leg']==order[k:k+2];p=leg['node_ids'];assert len(p)>=2
            assert coords[offset]==tasks[order[k]];offset+=len(p)-1;assert coords[offset]==tasks[order[k+1]]
            if k:assert rebuilt[-1]==p[0]
            rebuilt.extend(p if not k else p[1:])
        assert rebuilt==ids and offset==len(coords)-1
        values=[evaluate(a,b) for a,b in zip(coords,coords[1:])]
        q=min(v['q'] for v in values);covered=all(v['covered'] for v in values);state=labels(q,covered,'0.10')[1]
        length=sum(dec(Fraction((b[0]-a[0])**2+(b[1]-a[1])**2,scale*scale)).sqrt() for a,b in zip(coords,coords[1:]));assert abs(length-route['length_m'])<=Decimal('1e-8')
        row={'instance_id':iid,'method':method,'source':'new_1.10m_replanned' if new else 'old_1.00m_route','status_at_1_10m':state,'length_decimal_m':str(length),'segment_count':len(values),'minimum':evrow(min(values,key=lambda v:v['q'])),'bottleneck_segment_indices':[i for i,v in enumerate(values) if v['q']==q],'covered':covered,'scheduled_visit_once':True,'depot_closed':True,'segments':[{'segment_index':i,'a':route['mapped_polyline_coordinates'][i],'b':route['mapped_polyline_coordinates'][i+1],**evrow(v)} for i,v in enumerate(values)]}
        if new:
            saved=results[iid]['methods'][method];assert all(saved[k]==v for k,v in route.items())
            audit=read(A/'raw'/f'{iid}_{method}_route_audit.json');assert len(audit['segments'])==len(values)
            for j,(v,aa) in enumerate(zip(values,audit['segments'])):
                assert aa['a']==route['mapped_polyline_coordinates'][j] and aa['b']==route['mapped_polyline_coordinates'][j+1]
                assert aa['closed_field_covered']==v['covered'] and aa['exact_serialized_decimal_containment']==v['covered']
                assert abs(dec(v['q']).sqrt()-aa['minimum_clearance_m'])<=Decimal('1e-8')
                assert aa['clearance_status']=={'PASS':'PASS','FAIL':'FAIL','UNCERTAIN_THRESHOLD':'UNCERTAIN_BOUNDARY'}[labels(v['q'],v['covered'],'0.10')[1]]
            assert audit['complete_polyline_covered']==covered and abs(dec(q).sqrt()-audit['complete_polyline_minimum_clearance_m'])<=Decimal('1e-8')
            assert audit['each_scheduled_task_once'] and audit['depot_closed'] and abs(length-audit['mapped_length_m'])<=Decimal('1e-8')
            if audit['status']=='VALID_SAFE_ROUTE':assert state=='PASS' and len(audit['original_hole_checks'])==3 and all(h['intersection_empty'] for h in audit['original_hole_checks'])
            if iid not in graph_cache:
                graph=read(A/'raw'/f'{iid}_graph.json');graph_cache[iid]=graph
                b=len(shared['nodes']);assert graph['nodes'][:b]==shared['nodes'] and graph['nodes'][b:]==data['coordinates']
                assert graph['service_node_ids']==list(range(b,len(graph['nodes'])))
                assert graph['new_visibility_checks']==sum(range(b,len(graph['nodes'])))
                operation_checks[iid]=check_saved_operations(iid,results[iid],graph)
            graph=graph_cache[iid];nodes=graph['nodes'];b=len(shared['nodes']);matrix=graph['distance_matrix'];sn=graph['service_node_ids']
            assert [nodes[x] for x in ids]==route['mapped_polyline_coordinates']
            weights={(min(x,y),max(x,y)):w for x,y,w in shared['edges']+graph['added_visibility_edges']}
            assert len(weights)==graph['graph_edges']
            for leg in route['legs']:
                x,y=leg['service_leg'];p=leg['node_ids'];assert p==graph['paths'][x][y] and p[0]==sn[x] and p[-1]==sn[y] and all(z<b for z in p[1:-1])
                assert all((min(u,v),max(u,v)) in weights for u,v in zip(p,p[1:]))
                d=sum(weights[min(u,v),max(u,v)] for u,v in zip(p,p[1:]));assert abs(d-matrix[x][y])<=Decimal('1e-8')
                for u,v in zip(p,p[1:]):assert abs(Decimal(str(math.dist(list(map(float,nodes[u])),list(map(float,nodes[v])))))-weights[min(u,v),max(u,v)])<=Decimal('1e-8')
        return row
    oldrows=[route_audit(n,d,False) for n,d in oldroutes.items()];assert collections.Counter(r['status_at_1_10m'] for r in oldrows)=={'PASS':3,'FAIL':5}
    newrows=[route_audit(n,d,True) for n,d in newroutes.items()]
    oldmap={(r['instance_id'],r['method']):r for r in oldrows};comparisons=[]
    prior=read(A/'input/prior/clearance_aware_results.json');priorrows={x['instance_id']:x for x in prior['instances']}
    priorconditions=read(A/'input/prior/margin_sensitivity_results.json')['existing_route_conditions']
    newmap={(r['instance_id'],r['method']):r for r in newrows}
    for iid,saved in results.items():
        for method in METHODS:
            old=oldmap.get((iid,method));new=newmap.get((iid,method));record=saved['old_route_comparison'][method]
            assert record['old_instance_status']==priorrows[iid]['status'] and record['old_route_exists']==(old is not None)
            expected=next((c for c in priorconditions if c['instance_id']==iid and c['method']==method and c['extra_margin_m']=='0.10'),None)
            assert record['old_1_10m_condition']==expected
            if old:
                assert abs(Decimal(old['length_decimal_m'])-record['old_length_m'])<=Decimal('1e-8') and expected['conservative_status']==old['status_at_1_10m']
            else:assert record['old_length_m'] is None and record['old_minimum_clearance_m'] is None
            comparisons.append({'instance_id':iid,'method':method,'old_route_exists':old is not None,'old_status_at_1_10m':None if old is None else old['status_at_1_10m'],'new_route_exists':new is not None,'new_status_at_1_10m':None if new is None else new['status_at_1_10m'],'old_length_m':None if old is None else old['length_decimal_m'],'new_length_m':None if new is None else new['length_decimal_m'],'delta_length_m':None if old is None or new is None else str(Decimal(new['length_decimal_m'])-Decimal(old['length_decimal_m'])),'planning_status':saved['status']})
    assert len(comparisons)==24
    assert len(newrows)==summary['routes_produced']
    assert collections.Counter(x['status'] for x in results.values())==summary['status_counts']
    for iid,saved in results.items():
        if saved['status']=='VALID_SAFE_ROUTES':assert len(saved['methods'])==2 and all(r['status_at_1_10m']=='PASS' for r in newrows if r['instance_id']==iid)
    after={str(p.relative_to(A)):sha(p) for p in sorted((A/'raw').rglob('*')) if p.is_file()};assert before==after
    result={'status':'PASS_INDEPENDENT_SAVED_RECOMPUTATION','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'author_imports':False,'solver_calls':0,'route_search_calls':0,'original_ring_edge_counts':[len(r) for r in rings],'exact_integer_scale':str(scale),'instance_denominator':12,'method_condition_denominator':24,'endpoint_status_counts':dict(collections.Counter(r['endpoint_status'] for r in endpoint_rows)),'planning_status_counts':dict(collections.Counter(r['reported_planning_status'] for r in endpoint_rows)),'endpoint_uses':ecount,'old_route_denominator':8,'old_route_status_counts':dict(collections.Counter(r['status_at_1_10m'] for r in oldrows)),'new_route_count':len(newrows),'new_route_status_counts':dict(collections.Counter(r['status_at_1_10m'] for r in newrows)),'full_new_segment_uses':sum(r['segment_count'] for r in newrows),'full_old_segment_uses':sum(r['segment_count'] for r in oldrows),'exact_unique_geometries':len(cache),'maximum_geos_distance_difference_m':str(maxdiff),'center_region':center_summary,'endpoint_instances':endpoint_rows,'new_routes':newrows,'old_routes':oldrows,'all_24_old_new_comparisons':comparisons,'formal_execution_resources':run,'archive_checks':archive_checks,'saved_operation_checks':operation_checks,'raw_sha256':before,'resources':{'wall_seconds':time.perf_counter()-t,'cpu_seconds':time.process_time()-cpu,'rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},'reviewer_source_sha256':sha(pathlib.Path(__file__))}
    emit(R/'results/INDEPENDENT_SAVED_RECOMPUTATION.json',result)
    print(json.dumps({k:v for k,v in result.items() if k not in ('endpoint_instances','new_routes','old_routes','raw_sha256')},default=str))
if __name__=='__main__':main()
