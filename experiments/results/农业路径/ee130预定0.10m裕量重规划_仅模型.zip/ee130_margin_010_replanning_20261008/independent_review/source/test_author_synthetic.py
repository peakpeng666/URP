#!/usr/bin/python3
"""Author functions on synthetic data only. Actual inputs and formal main forbidden."""
import importlib.util,pathlib,sys,json,time,signal,datetime,hashlib,resource
R=pathlib.Path(__file__).resolve().parents[1];A=R.parent
resource.setrlimit(resource.RLIMIT_CPU,(30,30));resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912))
sys.path.insert(0,str(A/'source'))
spec=importlib.util.spec_from_file_location('tested_synthetic_author',A/'source/clearance_routing.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
answer=m.toy_tests();assert answer['status']=='PASS'
# Endpoints are safe and inside while the full connector crosses a hole.
f=m.ogr.CreateGeometryFromWkt('POLYGON ((0 0,20 0,20 20,0 20,0 0),(8 8,12 8,12 12,8 12,8 8))')
c,ns,meta=m.construct(f)
assert m.state(m.geom([[2,10]]).Distance(f.Boundary()),True)=='PASS'
assert m.state(m.geom([[18,10]]).Distance(f.Boundary()),True)=='PASS'
assert not m.safe_edge([2,10],[18,10],c,f,f.Boundary())
# Entire inset arc chords are accepted only if globally >1.10+tau from original.
for p in m.components(c):
 for i in range(p.GetGeometryCount()):
  ring=p.GetGeometryRef(i)
  for j in range(ring.GetPointCount()-1):
   a=list(ring.GetPoint(j)[:2]);b=list(ring.GetPoint(j+1)[:2]);assert m.geom([a,b]).Distance(f.Boundary())>1.10000001
# A disconnected three-node synthetic graph remains explicitly disconnected.
assert m.math.isinf(m.dijkstra([[(1,1)],[(0,1)],[]],0,3)[0][2])
# Timer restoration never resets the instance's remaining allowance.
signal.signal(signal.SIGALRM,m.timeout);signal.setitimer(signal.ITIMER_REAL,0.4)
before=signal.getitimer(signal.ITIMER_REAL)[0]
def slow(_):time.sleep(0.04);return 'ok'
assert m.bounded_solver(slow,[])=='ok';after=signal.getitimer(signal.ITIMER_REAL)[0];assert 0<after<before-0.025
signal.setitimer(signal.ITIMER_REAL,0.03)
try:m.bounded_solver(lambda _:time.sleep(0.2),[])
except TimeoutError:expired=True
else:expired=False
finally:signal.setitimer(signal.ITIMER_REAL,0)
assert expired
result={'status':'PASS','synthetic_only':True,'actual_geometry_loaded':False,'actual_solver_calls':0,'author_toy_status':answer['status'],'full_edge_hole_crossing_rejected':True,'all_toy_inset_edges_clear':True,'timer_restoration_reduces_remaining_budget':True,'solver_clamped_to_instance_expiry':True,'code_sha256':hashlib.sha256((A/'source/clearance_routing.py').read_bytes()).hexdigest(),'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
with (R/'evidence/SYNTHETIC_AUTHOR_RECHECK.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result))
