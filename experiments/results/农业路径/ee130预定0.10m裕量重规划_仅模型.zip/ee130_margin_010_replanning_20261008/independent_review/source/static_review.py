#!/usr/bin/python3
"""Final source/hash review, never invokes real geometry or the planner."""
import ast,datetime,hashlib,json,pathlib
R=pathlib.Path(__file__).resolve().parents[1];A=R.parent;U=pathlib.Path('/workspace/shared/ee130_clearance_aware_routing_20261008')
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def funcs(p):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(p.read_text()).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
checks=[]
def check(v,k):assert v,k;checks.append(k)
check(not list((A/'raw').iterdir()),'No formal output exists')
check(not (A/'evidence/STARTED.json').exists(),'No formal start marker exists')
identity=read(A/'freeze/INPUT_IDENTITY.json')
for rel,v in identity.items():check(sha(A/rel)==v['sha256']==sha(pathlib.Path(v['source_path'])),'Byte-identical '+rel)
immutable=read(A/'freeze/UPSTREAM_IMMUTABILITY.json')
for p,h in immutable.items():check(sha(pathlib.Path(p))==h,'Upstream unchanged '+p)
inputs=[read(p) for p in (A/'input').glob('n*_input.json')]
check(len(inputs)==12 and {(p['n'],p['seed']) for p in inputs}=={(n,s) for n in (8,12,20,40) for s in (202610081001,202610081002,202610081003)},'All 12 original size/seed pairs')
check((A/'source/route_algorithms.py').read_bytes()==(U/'source/route_algorithms.py').read_bytes(),'Byte-identical NN and 10000-candidate 2opt module')
f=funcs(A/'source/clearance_routing.py');old=funcs(U/'source/clearance_routing.py')
for name in ['components','rational_rings','rational_coords','build_base','dijkstra','evaluate','service_audit','build_instance']:
 check(f[name]==old[name],'Unchanged '+name+' implementation')
for name in ['construct','safe_edge','state']:
 check(f[name]==old[name].replace("id='RADIUS'","id='REQUIRED_CLEARANCE'"),'Only threshold name changes in '+name)
s=(A/'source/clearance_routing.py').read_text();runner=(A/'source/run_once.py').read_text();protocol=read(A/'freeze/PROTOCOL.json')
check(s.index('endpoint_records.append(rec)')<s.index('try:center,bnodes,bedges,meta=build_base(field)'),'All endpoint audits precede actual inset and shared graph')
check("signal.alarm(40)" in s and "signal.alarm(15)" in s,'Shared 40s and instance/endpoint 15s guards')
check('min(5.0,remaining)' in s and 'remaining-(time.monotonic()-t)' in s,'Solver deadline nests in remaining instance wall time')
check('resource.setrlimit(resource.RLIMIT_CPU,(60,60))' in runner and 'resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912))' in runner and 'timeout=120' in runner,'Wrapper total 60CPU/120wall/512MiB')
check("'x'" in runner and "PREEXECUTION_DRIVE_RECEIPT.json" in runner and "download_byte_identical" in runner and "owner_only" in runner,'Exclusive STARTED creation and verified private PREEXEC receipt')
check('os.getppid()' in s and 'resource.getrlimit(resource.RLIMIT_CPU)' in s and 'resource.getrlimit(resource.RLIMIT_AS)' in s,'Direct formal entry bound to runner and actual inherited resource ceilings')
check(protocol['radius_m']==1 and protocol['extra_geometric_margin_m']==.1 and protocol['required_clearance_m']==1.1,'Prespecified 1m disk plus sensitivity 0.10m')
check(protocol['fixed_instances']['twoopt_candidate_budget']==10000,'No 2opt budget tuning')
check(protocol['buffer']['quadrant_segments']==16 and protocol['buffer']['numerical_margin_m']==1e-5,'No buffer approximation tuning')
check(protocol['resources']['total_cpu_seconds']==60 and protocol['resources']['total_wall_seconds']==120 and protocol['resources']['address_space_bytes']==536870912,'Frozen total resource budgets')
check(read(A/'evidence/PREEXECUTION_TOY_TESTS.json')['status']=='PASS','Author synthetic test passes')
check(read(R/'evidence/SYNTHETIC_INDEPENDENT.json')['status']=='PASS','Independent integer geometry synthetic tests pass')
check(read(R/'evidence/SYNTHETIC_AUTHOR_RECHECK.json')['status']=='PASS','Author full-edge and nested timer synthetic recheck passes')
check((A/'source/render_saved_results.py').is_file(),'Saved-only renderer present before final hashes')
for p in (A/'source').rglob('*.py'):ast.parse(p.read_text())
for p in (R/'source').glob('*.py'):ast.parse(p.read_text())
result={'status':'PASS_STATIC_PREEXEC_REVIEW','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual_planner_calls':0,'actual_geometry_recomputation':False,'input_identity_count':len(identity),'upstream_immutable_count':len(immutable),'checks':checks,'author_files_sha256':{str(p.relative_to(A)):sha(p) for sub in ['source','input','freeze'] for p in sorted((A/sub).rglob('*')) if p.is_file()},'reviewer_sources_sha256':{str(p.relative_to(R)):sha(p) for p in sorted((R/'source').glob('*.py'))},'caveats':['PASS means source and synthetic precheck only; no new real routes have been generated or accepted.','A total resource kill or endpoint phase exception may leave incomplete raw records. Final analysis must retain the complete input roster and 24 method conditions, including not-reached outcomes.','Unsigned local archive receipts do not constitute independent network ACL verification; reviewer will directly hash downloaded archive bytes and check chronology after RAW release.','Author undirected segment cache may retain first evaluation orientation; actual a/b define saved direction. Independent distance and containment checks are orientation invariant.','Endpoint admissibility is necessary only. Conservative approximation failure and finite graph disconnection do not establish continuous-space infeasibility.']}
with (R/'evidence/STATIC_PREEXEC_REVIEW.json').open('x') as o:json.dump(result,o,indent=2);o.write('\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('author_files_sha256','reviewer_sources_sha256','checks')}))
