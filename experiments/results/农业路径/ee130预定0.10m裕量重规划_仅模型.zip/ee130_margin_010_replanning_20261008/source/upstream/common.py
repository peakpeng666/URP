import datetime,hashlib,json,math,re,time
from decimal import Decimal
from fractions import Fraction as F
from pathlib import Path
from osgeo import ogr
from geometry import covered_point,on_segment,intersection_parameters
R=Path(__file__).resolve().parents[1]
def save(p,x):
 p=R/p
 with p.open('x') as f: json.dump(x,f,ensure_ascii=False,indent=2,allow_nan=False); f.write('\n')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def clock(): return time.perf_counter(),time.process_time()
def elapsed(t): return {'wall_seconds':time.perf_counter()-t[0],'cpu_seconds':time.process_time()-t[1]}
def geometry():
 w=(R/'input/projected_epsg32634.wkt').read_text(); S=10**9; rings=[]
 for txt in re.findall(r'\(([^()]+)\)',w):
  ring=[]
  for pair in txt.split(','):
   p=tuple(Decimal(x)*S for x in pair.split()); assert all(x==x.to_integral_value() for x in p)
   ring.append(tuple(map(int,p)))
  assert ring[0]==ring[-1]; rings.append(ring[:-1])
 f=ogr.CreateGeometryFromWkt(w); assert f.IsValid() and len(rings)==4
 return f,rings,S

def point_covered(p,rings):
 if any(on_segment(p,a,b) for r in rings for a,b in zip(r,r[1:]+r[:1])): return True
 return covered_point(p,rings[0]) and not any(covered_point(p,r) for r in rings[1:])
def point_strict(p,rings):
 if any(on_segment(p,a,b) for r in rings for a,b in zip(r,r[1:]+r[:1])): return False
 return covered_point(p,rings[0]) and not any(covered_point(p,r) for r in rings[1:])
def exact_segment(a,b,rings):
 if not point_covered(a,rings) or not point_covered(b,rings): return False
 cuts={F(0),F(1)}
 for r in rings:
  for u,v in zip(r,r[1:]+r[:1]): cuts.update(intersection_parameters(a,b,u,v))
 cs=sorted(cuts)
 return all(point_covered(tuple(F(a[k])+(l+h)/2*(b[k]-a[k]) for k in (0,1)),rings) for l,h in zip(cs,cs[1:]))
def geos_segment(a,b,field):
 if a==b: return True
 line=ogr.Geometry(ogr.wkbLineString); line.AddPoint_2D(*a); line.AddPoint_2D(*b)
 diff=line.Difference(field); assert diff is not None
 return diff.IsEmpty()
def distance(a,b): return math.hypot(a[0]-b[0],a[1]-b[1])
def cost(route,D): return math.fsum(D[a][b] for a,b in zip(route,route[1:]))
