#!/usr/bin/python3
"""Read-only audit of frozen mapped polylines. No optimizer or sampling code."""
import csv, hashlib, json, math, os, pathlib, resource, sys, time
from decimal import Decimal, getcontext
from osgeo import ogr, gdal
getcontext().prec = 60
ogr.UseExceptions()
ROOT = pathlib.Path(__file__).resolve().parents[1]
TOL = 1e-8
RADII = [0.0, 0.5, 1.0, 2.0]
METHODS = ['nearest_neighbor', 'nn_2opt_budget']
def write(p, obj):
    p=pathlib.Path(p); p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def geom_line(coords):
    if len(coords)==1 or all(c==coords[0] for c in coords):
        p=ogr.Geometry(ogr.wkbPoint);p.AddPoint_2D(*coords[0]);return p
    g=ogr.Geometry(ogr.wkbLineString)
    for c in coords:g.AddPoint_2D(*c)
    return g
def point(p): return geom_line([p])
def closed_covered(g, poly): return bool(g.Difference(poly).IsEmpty())
def classify(d, covered, r):
    if not covered:return 'FAIL_OUTSIDE_FIELD'
    if r==0:return 'PASS'
    if d < r-TOL:return 'FAIL_CLEARANCE'
    if d > r+TOL:return 'PASS'
    return 'BORDERLINE_WITHIN_TOLERANCE'
def merge_status(statuses):
    if any(s.startswith('FAIL') for s in statuses):return 'FAIL'
    if any(s.startswith('BORDERLINE') for s in statuses):return 'BORDERLINE'
    return 'PASS'
def decpoint(p):return tuple(Decimal(str(x)) for x in p)
def sub(a,b):return (a[0]-b[0],a[1]-b[1])
def cross(a,b):return a[0]*b[1]-a[1]*b[0]
def dec_ptseg(p,a,b):
    v=sub(b,a);w=sub(p,a);den=v[0]*v[0]+v[1]*v[1]
    t=Decimal(0) if den==0 else max(Decimal(0),min(Decimal(1),(w[0]*v[0]+w[1]*v[1])/den))
    q=(a[0]+t*v[0],a[1]+t*v[1]);delta=sub(p,q)
    return (delta[0]*delta[0]+delta[1]*delta[1]).sqrt(),p,q,t

def independent_segseg(a,b,c,d):
    """Decimal point-segment projections plus segment intersection; GEOS-free."""
    a,b,c,d=map(decpoint,(a,b,c,d));r=sub(b,a);s=sub(d,c);ca=sub(c,a);den=cross(r,s)
    if den:
        t,u=cross(ca,s)/den,cross(ca,r)/den
        if 0<=t<=1 and 0<=u<=1:
            p=(a[0]+t*r[0],a[1]+t*r[1])
            return {'distance_m':0.0,'distance_decimal':'0','route_point':[str(x) for x in p],'boundary_point':[str(x) for x in p],'case':'intersection','parameter_route':str(t),'parameter_boundary':str(u)}
    vals=[]
    for name,p,x,y,rev in [('route_start',a,c,d,False),('route_end',b,c,d,False),('edge_start',c,a,b,True),('edge_end',d,a,b,True)]:
        dist,p,q,t=dec_ptseg(p,x,y)
        rp,bp=(q,p) if rev else (p,q)
        vals.append((dist,name,rp,bp,t))
    dist,name,rp,bp,t=min(vals,key=lambda q:(q[0],q[1]))
    return {'distance_m':float(dist),'distance_decimal':str(dist),'route_point':[str(x) for x in rp],'boundary_point':[str(x) for x in bp],'case':name,'projection_parameter':str(t)}

def boundary_edges(poly):
    out=[]
    for ri in range(poly.GetGeometryCount()):
        ring=poly.GetGeometryRef(ri);coords=[list(ring.GetPoint(i)[:2]) for i in range(ring.GetPointCount())]
        assert coords[0]==coords[-1]
        for ei,(a,b) in enumerate(zip(coords,coords[1:])):
            out.append({'ring_index':ri,'ring_type':'outer' if ri==0 else 'hole','hole_index':None if ri==0 else ri,'edge_index':ei,'a':a,'b':b,'geom':geom_line([a,b])})
    return out

def evaluate_geometry(coords,poly,boundary,edges):
    g=geom_line(coords);dist=g.Distance(boundary);assert dist>=0
    ed=[(g.Distance(e['geom']),i) for i,e in enumerate(edges)]
    d,ei=min(ed);e=edges[ei]
    independent=independent_segseg(coords[0],coords[-1],e['a'],e['b'])
    discrepancy=abs(independent['distance_m']-d)
    assert abs(d-dist)<=TOL,(d,dist)
    assert discrepancy<=TOL,(coords,e,independent,d)
    # Decimal independent check of every edge establishes the same global minimum;
    # this remains a finite-precision numerical crosscheck, not a certified proof.
    alt=[(independent_segseg(coords[0],coords[-1],x['a'],x['b'])['distance_m'],i) for i,x in enumerate(edges)]
    altmin,altei=min(alt)
    assert abs(altmin-dist)<=TOL,(altmin,dist)
    return {'evaluation_coordinates':coords,'minimum_clearance_m':dist,'closed_field_covered':closed_covered(g,poly),'outside_geometry_wkt':g.Difference(poly).ExportToWkt(),
        'geos_exact_zero_distance':dist==0.0,'within_contact_tolerance':dist<=TOL,
        'witness':{k:v for k,v in e.items() if k!='geom'},'witness_edge_distance_m':d,
        'tied_edge_ids_within_tolerance':[{'ring_index':edges[i]['ring_index'],'edge_index':edges[i]['edge_index']} for di,i in ed if abs(di-d)<=TOL],
        'independent_decimal_witness':independent,'independent_witness_abs_difference_m':discrepancy,
        'independent_global_minimum_m':altmin,'independent_global_witness':{k:v for k,v in edges[altei].items() if k!='geom'},
        'independent_global_abs_difference_m':abs(altmin-dist)}

def toy_tests():
    poly=ogr.CreateGeometryFromWkt('POLYGON ((0 0,10 0,10 10,0 10,0 0),(4 4,6 4,6 6,4 6,4 4))')
    cases=[('boundary_contact',[[0,0],[0,10]],True,0.0),('hole_crossing',[[1,5],[9,5]],False,0.0),('exterior_crossing',[[-1,1],[2,1]],False,0.0),('interior',[[1,1],[3,3]],True,1.0),('half_metre',[[1,0.5],[9,0.5]],True,0.5),('hole_edge_contact',[[4,4],[6,4]],True,0.0),('degenerate',[[2,2],[2,2]],True,2.0)]
    rows=[]
    for name,coords,covered,d in cases:
        v=evaluate_geometry(coords,poly,poly.Boundary(),boundary_edges(poly))
        assert v['closed_field_covered']==covered
        assert abs(v['minimum_clearance_m']-d)<=TOL
        rows.append({'name':name,'expected_covered':covered,'expected_distance_m':d,'actual':v})
    assert classify(1.0,True,1.0)=='BORDERLINE_WITHIN_TOLERANCE'
    assert classify(1.0-2*TOL,True,1.0)=='FAIL_CLEARANCE'
    assert classify(1.0+2*TOL,True,1.0)=='PASS'
    assert classify(0.0,True,0.0)=='PASS'
    assert classify(0.0,False,0.0)=='FAIL_OUTSIDE_FIELD'
    return {'status':'PASS','synthetic_only':True,'case_count':len(rows),'cases':rows}

def main():
    t0=time.perf_counter();c0=time.process_time()
    freeze=json.loads((ROOT/'freeze/PREEXECUTION_FREEZE.json').read_text())
    for rel,d in freeze['files'].items():assert sha(ROOT/rel)==d,rel
    if (ROOT/'raw/results.json').exists():raise RuntimeError('Refuse rerun over existing output')
    manifest=json.loads((ROOT/'input/MANIFEST.json').read_text())
    poly=ogr.CreateGeometryFromWkt((ROOT/'input/projected_epsg32634.wkt').read_text())
    assert poly.IsValid() and poly.GetGeometryName()=='POLYGON' and poly.GetGeometryCount()==4
    boundary=poly.Boundary();edges=boundary_edges(poly)
    write(ROOT/'raw/boundary_edges.json',[{k:v for k,v in e.items() if k!='geom'} for e in edges])
    write(ROOT/'raw/toy_tests.json',toy_tests())
    cache={};point_cache={};routes=[];conditions=[];service_instances=[];segment_uses=0
    def cached(coords,pc=False):
        target=point_cache if pc else cache
        key=tuple(sorted(tuple(c) for c in coords))
        if key not in target:target[key]=evaluate_geometry(coords,poly,boundary,edges)
        return target[key]
    for inst in manifest['instances']:
        inp=json.loads((ROOT/inst['input_copy']).read_text());saved=json.loads((ROOT/inst['result_copy']).read_text())
        assert saved['status']=='PASS' and inp['instance_id']==saved['instance_id']
        services=[]
        for i,p in enumerate(inp['coordinates']):
            v=cached([p],True)
            services.append({'service_id':i,'role':'depot' if i==0 else 'task','coordinate':p,**v,
                'radius_conditions':{str(r):classify(v['minimum_clearance_m'],v['closed_field_covered'],r) for r in RADII}})
        service_instances.append({'instance_id':inp['instance_id'],'n':inp['n'],'seed':inp['seed'],'services':services})
        for method in METHODS:
            saved_route=saved['methods'][method];coords=saved_route['mapped_polyline_coordinates'];nodeids=saved_route['mapped_polyline_node_ids'];order=saved_route['route']
            assert len(coords)==len(nodeids) and coords[0]==coords[-1]==inp['coordinates'][0]
            assert order[0]==order[-1]==0 and sorted(order[1:-1])==list(range(1,inp['n']+1))
            leg_source=json.loads((ROOT/inst['used_legs_copy']).read_text())[method]
            service_positions=[0];rebuilt=[]
            for j,leg in enumerate(leg_source):
                assert leg['service_leg']==order[j:j+2]
                assert leg['coordinates'][0]==inp['coordinates'][order[j]]
                assert leg['coordinates'][-1]==inp['coordinates'][order[j+1]]
                rebuilt.extend(leg['node_ids'] if j==0 else leg['node_ids'][1:])
                service_positions.append(service_positions[-1]+len(leg['node_ids'])-1)
            assert rebuilt==nodeids
            assert service_positions[-1]==len(coords)-1
            segments=[];legid=0
            for si,(a,b) in enumerate(zip(coords,coords[1:])):
                while legid+1<len(service_positions)-1 and si>=service_positions[legid+1]:legid+=1
                v=cached([a,b]);segment_uses+=1
                # Cached witness may be oriented oppositely; coordinates below identify actual route use.
                segments.append({'segment_index':si,'node_ids':[nodeids[si],nodeids[si+1]],'a':a,'b':b,'service_leg_index':legid,'service_leg':[order[legid],order[legid+1]],**v,
                    'radius_conditions':{str(r):classify(v['minimum_clearance_m'],v['closed_field_covered'],r) for r in RADII}})
            full=geom_line(coords);dist=full.Distance(boundary);covered=closed_covered(full,poly)
            minimum=min(segments,key=lambda x:(x['minimum_clearance_m'],x['segment_index']))
            assert abs(dist-minimum['minimum_clearance_m'])<=TOL
            assert covered==all(s['closed_field_covered'] for s in segments)
            length=math.fsum(math.dist(a,b) for a,b in zip(coords,coords[1:]))
            assert abs(length-saved_route['mapped_polyline_length_m'])<=TOL
            rec={'instance_id':inp['instance_id'],'n':inp['n'],'seed':inp['seed'],'method':method,'saved_mapped_length_m':saved_route['mapped_polyline_length_m'],
                'recomputed_mapped_length_m':length,'minimum_clearance_m':dist,'closed_field_covered':covered,'minimum_segment_index':minimum['segment_index'],
                'minimum_witness':minimum['witness'],'minimum_independent_witness':minimum['independent_decimal_witness'],
                'geos_exact_zero_distance':dist==0,'within_contact_tolerance':dist<=TOL,'segments':segments}
            routes.append(rec)
            for r in RADII:
                ss=[s['radius_conditions'][str(r)] for s in services];cs=[s['radius_conditions'][str(r)] for s in segments]
                fs=[i for i,s in enumerate(ss) if s.startswith('FAIL')];bs=[i for i,s in enumerate(ss) if s.startswith('BORDERLINE')]
                fc=[i for i,s in enumerate(cs) if s.startswith('FAIL')];bc=[i for i,s in enumerate(cs) if s.startswith('BORDERLINE')]
                status=merge_status(cs+ss)
                endpoint_feasible_bad_legs=sorted({segments[i]['service_leg_index'] for i in fc if all(ss[k]=='PASS' for k in segments[i]['service_leg'])})
                conditions.append({'instance_id':inp['instance_id'],'n':inp['n'],'seed':inp['seed'],'method':method,'radius_m':r,'status':status,
                    'full_centerline_covered':covered,'minimum_route_clearance_m':dist,'minimum_service_clearance_m':min(s['minimum_clearance_m'] for s in services),
                    'depot_status':ss[0],'failing_task_ids':[i for i in fs if i>0],'borderline_task_ids':[i for i in bs if i>0],
                    'service_points_status':merge_status(ss),'connecting_segments_status':merge_status(cs),'failing_segment_indices':fc,'borderline_segment_indices':bc,
                    'connector_only_failure_all_service_points_pass':bool(fc) and all(s=='PASS' for s in ss),
                    'failing_leg_indices_with_passing_service_endpoints':endpoint_feasible_bad_legs})
            write(ROOT/f'raw/{inp["instance_id"]}_{method}_route.json',rec)
        write(ROOT/'raw/PARTIAL_STATUS.json',{'completed_instances':len(service_instances),'completed_routes':len(routes),'completed_conditions':len(conditions)})
    assert len(routes)==24 and len(conditions)==96
    allgeom=list(cache.values())+list(point_cache.values())
    summary={'status':'COMPLETE_UNAUDITED','radii_m':RADII,'route_count':len(routes),'condition_count':len(conditions),
        'all_routes_centerline_covered':all(x['closed_field_covered'] for x in routes),'exact_boundary_contact_routes':sum(x['geos_exact_zero_distance'] for x in routes),
        'near_contact_routes':sum(x['within_contact_tolerance'] for x in routes),'segment_uses':segment_uses,'unique_segments':len(cache),'unique_service_points':len(point_cache),
        'boundary_edges':len(edges),'ring_count':poly.GetGeometryCount(),
        'maximum_independent_global_abs_difference_m':max(x['independent_global_abs_difference_m'] for x in allgeom),
        'maximum_independent_witness_abs_difference_m':max(x['independent_witness_abs_difference_m'] for x in allgeom),
        'by_radius':[]}
    for r in RADII:
        cr=[c for c in conditions if c['radius_m']==r]
        summary['by_radius'].append({'radius_m':r,'PASS':sum(c['status']=='PASS' for c in cr),'FAIL':sum(c['status']=='FAIL' for c in cr),'BORDERLINE':sum(c['status']=='BORDERLINE' for c in cr),
            'service_point_failing_routes':sum(c['service_points_status']=='FAIL' for c in cr),'depot_failing_routes':sum(c['depot_status'].startswith('FAIL') for c in cr),
            'task_failing_routes':sum(bool(c['failing_task_ids']) for c in cr),'connecting_segment_failing_routes':sum(c['connecting_segments_status']=='FAIL' for c in cr),
            'connector_only_failing_routes':sum(c['connector_only_failure_all_service_points_pass'] for c in cr)})
    write(ROOT/'raw/services.json',service_instances)
    write(ROOT/'raw/results.json',{'summary':summary,'conditions':conditions})
    write(ROOT/'raw/routes_index.json',[{k:v for k,v in r.items() if k!='segments'} for r in routes])
    fields=list(conditions[0])
    with (ROOT/'raw/conditions.csv').open('w') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
        for c in conditions:w.writerow({k:json.dumps(v) if isinstance(v,list) else v for k,v in c.items()})
    write(ROOT/'evidence/EXECUTION_RESOURCES.json',{'internal_wall_seconds':time.perf_counter()-t0,'internal_cpu_seconds':time.process_time()-c0,
        'maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'gdal_version':gdal.VersionInfo('--version'),
        'geos_version':[ogr.GetGEOSVersionMajor(),ogr.GetGEOSVersionMinor(),ogr.GetGEOSVersionMicro()],
        'python':sys.version,'network_calls':0,'installs':0,'optimizer_calls':0,'resampling_calls':0,'formal_attempts':1})
    print(json.dumps(summary,ensure_ascii=False))
if __name__=='__main__':
    if '--toy-only' in sys.argv: print(json.dumps(toy_tests()))
    else:main()
