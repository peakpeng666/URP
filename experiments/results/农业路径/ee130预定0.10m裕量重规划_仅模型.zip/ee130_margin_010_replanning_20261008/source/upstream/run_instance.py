import heapq,itertools,resource,signal,sys,traceback
from common import *
from matrix_oracle import solve as oracle_solve
from osgeo import gdal
TOL=1e-8

def dijkstra(adj,s):
 ds=[math.inf]*len(adj); paths=[None]*len(adj); ds[s]=0.; paths[s]=(s,); q=[(0.,(s,),s)]
 pops=relax=0
 while q:
  d,p,u=heapq.heappop(q); pops+=1
  if (d,p)!=(ds[u],paths[u]): continue
  for v,w in adj[u]:
   relax+=1; cand=(d+w,p+(v,))
   if cand[0]<ds[v] or (cand[0]==ds[v] and (paths[v] is None or cand[1]<paths[v])):
    ds[v],paths[v]=cand; heapq.heappush(q,(cand[0],cand[1],v))
 assert all(math.isfinite(x) for x in ds),'Disconnected graph'
 return ds,paths,pops,relax

def nn(D):
 todo=set(range(1,len(D))); route=[0]; candidates=0
 while todo:
  candidates+=len(todo); j=min(todo,key=lambda j:(D[route[-1]][j],j)); route.append(j); todo.remove(j)
 return route+[0],{'distance_candidates':candidates}

def twoopt(D,budget=10000):
 route,init=nn(D); candidates=0; moves=[]; n=len(D)-1; current=cost(route,D); reason=None
 while candidates<budget:
  improved=False
  for i in range(1,n):
   for j in range(i+1,n+1):
    if i==1 and j==n: continue
    if candidates>=budget: break
    candidates+=1; a,b=route[i-1],route[i]; c,d=route[j],route[j+1]
    delta=math.fsum([D[a][c],D[b][d],-D[a][b],-D[c][d]])
    if delta < -1e-9:
     proposed=route[:i]+route[i:j+1][::-1]+route[j+1:]; after=cost(proposed,D)
     if after<current:
      moves.append({'candidate':candidates,'i':i,'j':j,'before_m':current,'after_m':after,'delta_estimate_m':delta})
      route,current=proposed,after; improved=True; break
   if improved or candidates>=budget: break
  if not improved:
   reason='BUDGET_EXHAUSTED' if candidates>=budget else 'NO_IMPROVING_FULL_SWEEP'; break
 if reason is None: reason='BUDGET_EXHAUSTED'
 return route,{'nn_initialization':init,'candidate_reversals':candidates,'candidate_budget':budget,'accepted_moves':len(moves),'moves':moves,'termination':reason}

def build_base():
 t=clock(); field,rings,S=geometry(); nodes=[(x/S,y/S) for r in rings for x,y in r]; edges=[]; checks=[]
 for i,a in enumerate(nodes):
  for j in range(i+1,len(nodes)):
   ok=geos_segment(a,nodes[j],field); checks.append([i,j,ok])
   if ok: edges.append([i,j,distance(a,nodes[j])])
 save('raw/boundary_graph.json',{'utc':utc(),'geometry_sha256':sha(R/'input/projected_epsg32634.wkt'),'nodes':nodes,'edges':edges,'checks':checks,'graph_nodes':len(nodes),'graph_edges':len(edges),'resources':elapsed(t),'GDAL':gdal.VersionInfo()})
 print(json.dumps({'shared_base':elapsed(t),'nodes':len(nodes),'edges':len(edges)}),flush=True)

def run(id):
 start=clock(); inst=json.loads((R/f'input/{id}.json').read_text()); n=inst['n']; k=n+1
 t=clock(); field,rings,S=geometry(); base=json.loads((R/'raw/boundary_graph.json').read_text()); boundary=base['nodes']; b=len(boundary); services=inst['coordinates']; nodes=boundary+services; exact=[p for r in rings for p in r]+[tuple(v*S for v in p) for p in services]
 assert len(set(tuple(p) for p in nodes))==len(nodes)
 edges=list(base['edges']); checks=[]
 for j in range(b,len(nodes)):
  for i in range(j):
   ok=geos_segment(nodes[i],nodes[j],field); checks.append([i,j,ok])
   if ok: edges.append([i,j,distance(nodes[i],nodes[j])])
 adj=[[] for _ in nodes]
 for i,j,w in edges: adj[i].append((j,w)); adj[j].append((i,w))
 sn=list(range(b,b+k)); ds=[dijkstra(adj,s) for s in sn]; D=[[0.]*k for _ in range(k)]; paths=[[None]*k for _ in range(k)]; asymmetry=max(abs(ds[i][0][sn[j]]-ds[j][0][sn[i]]) for i in range(k) for j in range(k))
 assert asymmetry<=TOL
 for i in range(k):
  for j in range(i,k):
   p=list(ds[i][1][sn[j]]); d=math.fsum(distance(nodes[a],nodes[c]) for a,c in zip(p,p[1:])); assert abs(d-ds[i][0][sn[j]])<=TOL
   D[i][j]=D[j][i]=d; paths[i][j]=p; paths[j][i]=p[::-1]
 precompute=elapsed(t)
 artifact={'nodes':nodes,'service_node_ids':sn,'coordinates':services,'legal_distance_matrix':D,'legal_leg_node_paths':paths,'visibility_edges':edges,'new_visibility_checks':checks,'boundary_cache_sha256':sha(R/'raw/boundary_graph.json'),'preprocessing':precompute,'graph_nodes':len(nodes),'graph_edges':len(edges),'new_visibility_checks_count':len(checks),'dijkstra_heap_pops':sum(x[2] for x in ds),'dijkstra_relaxations':sum(x[3] for x in ds),'dijkstra_max_asymmetry_m':asymmetry}
 save(f'raw/{id}_geometry.json',artifact)
 methods={}
 for label,fn in [('nearest_neighbor',nn),('nn_2opt_budget',twoopt)]:
  t=clock(); route,stats=fn(D); timing=elapsed(t); methods[label]={'route':route,'length_m':cost(route,D),'solve_resources':timing,'operations':stats}
 assert methods['nn_2opt_budget']['length_m']<=methods['nearest_neighbor']['length_m']
 if n<=12:
  t=clock(); raw={'coordinates':services,'demands':[0]+[1]*n,'capacity':n}; dp=oracle_solve(raw,D); optimum=dp['by_k']['1']; timing=elapsed(t)
  assert optimum['nonempty_routes']==1
  route=optimum['routes'][0]
  methods['oracle']={'route':route,'length_m':cost(route,D),'reported_dp_cost_m':optimum['cost'],'solve_resources':timing,'operations':{s:dp[s] for s in ['held_karp_states','held_karp_transitions','partition_states','partition_transitions']},'arithmetic':dp['arithmetic'],'implementation_note':'Unchanged general CVRP oracle calculates all k; timing includes unused partition overhead'}
  assert abs(cost(route,D)-optimum['cost'])<=TOL
  save(f'raw/{id}_oracle_full.json',dp)
 # Save solver output before validation so invalid paths remain visible.
 save(f'raw/{id}_solver_outputs.json',methods)
 t=clock(); fw=[[math.inf]*len(nodes) for _ in nodes]
 for i in range(len(nodes)): fw[i][i]=0.
 for i,j,w in edges: fw[i][j]=fw[j][i]=w
 for h in range(len(nodes)):
  hh=fw[h]
  for i in range(len(nodes)):
   row=fw[i]; dh=row[h]
   if not math.isfinite(dh): continue
   for j in range(len(nodes)):
    v=dh+hh[j]
    if v<row[j]: row[j]=v
 ferr=max(abs(D[i][j]-fw[sn[i]][sn[j]]) for i in range(k) for j in range(k)); assert ferr<=TOL
 floyd_t=elapsed(t); t=clock(); checked={}; segment_uses=0
 for label,m in methods.items():
  route=m['route']; assert route[0]==route[-1]==0 and sorted(route[1:-1])==list(range(1,k)) and len(route)==n+2
  poly=[]
  for a,c in zip(route,route[1:]):
   p=paths[a][c]; assert p[0]==sn[a] and p[-1]==sn[c]; poly.extend(p if not poly else p[1:])
  assert poly[0]==poly[-1]==sn[0]
  violations=[]
  for a,c in zip(poly,poly[1:]):
   segment_uses+=1; key=tuple(sorted((a,c)))
   if key not in checked: checked[key]={'rational':exact_segment(exact[a],exact[c],rings),'GEOS':geos_segment(nodes[a],nodes[c],field)}
   if not all(checked[key].values()): violations.append([a,c,checked[key]])
  length=math.fsum(distance(nodes[a],nodes[c]) for a,c in zip(poly,poly[1:])); assert abs(length-m['length_m'])<=TOL
  m.update({'mapped_polyline_node_ids':poly,'mapped_polyline_coordinates':[nodes[a] for a in poly],'mapped_polyline_length_m':length,'audit':{'every_task_once':True,'depot_closed':True,'mapped_path_violations':violations,'all_outer_and_three_hole_rings_audited':True}})
  assert not violations,'Mapped path independent coverage failure'
 route_audit=elapsed(t); brute=None
 if n==8:
  t=clock(); best=None; count=0
  for perm in itertools.permutations(range(1,k)):
   if perm[0]>perm[-1]: continue
   count+=1; route=(0,)+perm+(0,); c=cost(route,D)
   if best is None or (c,route)<best: best=(c,route)
  brute={'length_m':best[0],'route':best[1],'canonical_plans':count,'resources':elapsed(t),'absolute_error_vs_dp_m':abs(best[0]-methods['oracle']['length_m'])}; assert brute['absolute_error_vs_dp_m']<=TOL
 oracle=methods.get('oracle'); nn_len=methods['nearest_neighbor']['length_m']; two_len=methods['nn_2opt_budget']['length_m']
 for label in ['nearest_neighbor','nn_2opt_budget']:
  m=methods[label]; m['gap_to_finite_graph_oracle_pct']=None if oracle is None else 100*(m['length_m']/oracle['length_m']-1.)
  if oracle: assert m['length_m']>=oracle['length_m']-TOL
 result={'status':'PASS','utc':utc(),'instance_id':id,'n':n,'seed':inst['seed'],'methods':methods,'relative_improvement_nn_to_2opt_pct':100*(nn_len-two_len)/nn_len,'preprocessing':precompute,'shared_base_preprocessing_excluded_and_reported_separately':True,'graph_nodes':len(nodes),'graph_edges':len(edges),'audit':{'Floyd_max_abs_error_m':ferr,'Floyd_resources':floyd_t,'Floyd_scope':'Independent shortest-path algorithm on same GEOS graph, not continuous geometry certification','path_resources':route_audit,'unique_segments':len(checked),'segment_uses':segment_uses,'segment_cache_hits':segment_uses-len(checked),'segments':[{'node_ids':list(key),**val} for key,val in sorted(checked.items())],'brute_force_n8':brute},'instance_internal_resources':elapsed(start),'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
 save(f'raw/{id}_result.json',result)
 print(json.dumps({'instance_id':id,'status':'PASS','NN_m':nn_len,'twoopt_m':two_len,'improvement_pct':result['relative_improvement_nn_to_2opt_pct'],'oracle_m':None if oracle is None else oracle['length_m'],'resources':result['instance_internal_resources']}),flush=True)

if __name__=='__main__':
 id=sys.argv[1]
 try:
  frozen=json.loads((R/'freeze/PRE_RUN_FREEZE.json').read_text())
  for p,h in frozen['hashes'].items(): assert sha(R/p)==h,p
  if id=='base': build_base()
  else: run(id)
 except Exception as e:
  save(f'evidence/{id}_FAILURE.json',{'utc':utc(),'error':str(e),'traceback':traceback.format_exc()}); raise
