"""Unchanged NN and 2opt functions extracted from frozen prior run_instance.py."""
import math
def cost(route,D): return math.fsum(D[a][b] for a,b in zip(route,route[1:]))

def nn(D):
 todo=set(range(1,len(D))); route=[0]; candidates=0
 while todo:
  candidates+=len(todo); j=min(todo,key=lambda j:(D[route[-1]][j],j)); route.append(j); todo.remove(j)
 return route+[0],{'distance_candidates':candidates}

def twoopt(D,budget=10000):
 route,init=nn(D); candidates=0; moves=[]; n=len(D)-1; current=cost(route,D); reason=None
 while candidates<budget:
  improved=False
  for i in range(1,n):
   for j in range(i+1,n+1):
    if i==1 and j==n: continue
    if candidates>=budget: break
    candidates+=1; a,b=route[i-1],route[i]; c,d=route[j],route[j+1]
    delta=math.fsum([D[a][c],D[b][d],-D[a][b],-D[c][d]])
    if delta < -1e-9:
     proposed=route[:i]+route[i:j+1][::-1]+route[j+1:]; after=cost(proposed,D)
     if after<current:
      moves.append({'candidate':candidates,'i':i,'j':j,'before_m':current,'after_m':after,'delta_estimate_m':delta})
      route,current=proposed,after; improved=True; break
   if improved or candidates>=budget: break
  if not improved:
   reason='BUDGET_EXHAUSTED' if candidates>=budget else 'NO_IMPROVING_FULL_SWEEP'; break
 if reason is None: reason='BUDGET_EXHAUSTED'
 return route,{'nn_initialization':init,'candidate_reversals':candidates,'candidate_budget':budget,'accepted_moves':len(moves),'moves':moves,'termination':reason}
