#!/usr/bin/python3
"""Frozen 1m disk plus prespecified 0.10m geometric-margin planning. No network, model, input resampling or tuning."""
import os, collections, datetime, hashlib, heapq, json, math, pathlib, re, resource, signal, sys, time, traceback
from fractions import Fraction
from decimal import Decimal
from osgeo import ogr, gdal
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'source/upstream'))
import audit_clearance as independent
from common import exact_segment, point_covered, geos_segment, distance
from route_algorithms import nn, twoopt, cost
ogr.UseExceptions()
BASE_DISK_RADIUS=1.0
EXTRA_MARGIN=0.10
REQUIRED_CLEARANCE=BASE_DISK_RADIUS+EXTRA_MARGIN
TOL=1e-8
QUADRANT_SEGMENTS=16
NUMERICAL_MARGIN=1e-5
BUFFER_DISTANCE=(REQUIRED_CLEARANCE+NUMERICAL_MARGIN)/math.cos(math.pi/(2*QUADRANT_SEGMENTS))
METHODS=[('nearest_neighbor',nn),('nn_2opt_budget',twoopt)]
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def save(rel,x):
 p=ROOT/rel;p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x') as f:json.dump(x,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')
def timing():return time.perf_counter(),time.process_time()
def elapsed(t):return {'wall_seconds':time.perf_counter()-t[0],'cpu_seconds':time.process_time()-t[1]}
def geom(coords):return independent.geom_line(coords)
def covered(g,p):return independent.closed_covered(g,p)
def state(d,ok):
 if not ok or d<REQUIRED_CLEARANCE-TOL:return 'FAIL'
 if d>REQUIRED_CLEARANCE+TOL:return 'PASS'
 return 'UNCERTAIN_BOUNDARY'
def components(g):
 if g.IsEmpty():return []
 if g.GetGeometryName()=='POLYGON':return [g]
 if g.GetGeometryName()=='MULTIPOLYGON':return [g.GetGeometryRef(i) for i in range(g.GetGeometryCount())]
 raise ValueError('Unsupported center-region geometry '+g.GetGeometryName())
def rational_rings(wkt):
 return [[tuple(Fraction(v) for v in point.split()) for point in txt.split(',')][:-1] for txt in re.findall(r'\(([^()]+)\)',wkt)]
def rational_coords(p):return tuple(Fraction(str(x)) for x in p)
def timeout(_a,_b):raise TimeoutError('Frozen per-stage deadline exceeded')
def construct(field):
 center=field.Buffer(-BUFFER_DISTANCE,QUADRANT_SEGMENTS)
 comps=components(center)
 h=[p.GetGeometryCount()-1 for p in comps]
 ok=bool(comps) and bool(center.IsValid()) and covered(center,field)
 d=None if not comps else center.Distance(field.Boundary())
 # Region-as-filled-set distance checks every part, not just ring vertices.
 approved=ok and d>REQUIRED_CLEARANCE+TOL
 nodes=[];rings=[]
 for ci,p in enumerate(comps):
  for ri in range(p.GetGeometryCount()):
   ring=p.GetGeometryRef(ri);coords=[list(ring.GetPoint(i)[:2]) for i in range(ring.GetPointCount()-1)]
   ids=list(range(len(nodes),len(nodes)+len(coords)));nodes.extend(coords);rings.append({'component':ci,'ring':ri,'nodes':ids})
 assert len(set(tuple(v) for v in nodes))==len(nodes)
 holes=[]
 for hi in range(1,field.GetGeometryCount()):
  hole=ogr.Geometry(ogr.wkbPolygon);hole.AddGeometry(field.GetGeometryRef(hi))
  overlap=center.Intersection(hole)
  holes.append({'original_hole_index':hi,'intersection_empty':bool(overlap.IsEmpty()),'intersection_area_m2':overlap.GetArea()})
 approved=approved and all(h['intersection_empty'] for h in holes)
 return center,nodes,{'status':'POSTERIOR_NUMERIC_REGION_PASS' if approved else 'CONSERVATIVE_APPROXIMATION_UNAVAILABLE','buffer_distance_m':BUFFER_DISTANCE,'quadrant_segments':QUADRANT_SEGMENTS,'numerical_margin_m':NUMERICAL_MARGIN,'valid':bool(center.IsValid()),'center_within_original_field':ok,'minimum_region_distance_to_original_boundary_m':d,'component_count':len(comps),'component_hole_counts':h,'all_original_holes_excluded':holes,'rings':rings,'nodes':len(nodes),'center_area_m2':center.GetArea()}
def safe_edge(a,b,center,field,boundary):
 if a==b:return False
 line=geom([a,b])
 if not geos_segment(a,b,center):return False
 return geos_segment(a,b,field) and line.Distance(boundary)>REQUIRED_CLEARANCE+TOL

def build_base(field):
 start=timing();center,nodes,meta=construct(field);construction=elapsed(start)
 (ROOT/'raw/center_region.wkt').write_text(center.ExportToIsoWkt()+'\n')
 if meta['status']!='POSTERIOR_NUMERIC_REGION_PASS':
  save('raw/shared_preprocessing.json',{'construction':construction,'geometry':meta,'edges':[],'nodes':nodes,'visibility_resources':None});return center,nodes,[],meta
 t=timing();edges=[];checks=0;boundary=field.Boundary()
 for i,a in enumerate(nodes):
  for j in range(i+1,len(nodes)):
   checks+=1
   if safe_edge(a,nodes[j],center,field,boundary):edges.append([i,j,distance(a,nodes[j])])
 data={'construction':construction,'visibility_resources':elapsed(t),'total_shared_resources':elapsed(start),'geometry':meta,'nodes':nodes,'edges':edges,'candidate_edge_checks':checks,'accepted_safe_edges':len(edges)}
 save('raw/shared_preprocessing.json',data)
 print(json.dumps({'shared_preprocessing':data['total_shared_resources'],'nodes':len(nodes),'edges':len(edges),'region':meta['status']}),flush=True)
 return center,nodes,edges,meta

def dijkstra(adj,s,service_start):
 """Prior heap/lexicographic Dijkstra; destination services cannot be interior transit nodes."""
 ds=[math.inf]*len(adj);paths=[None]*len(adj);ds[s]=0.;paths[s]=(s,);q=[(0.,(s,),s)];pops=relax=0
 while q:
  d,p,u=heapq.heappop(q);pops+=1
  if (d,p)!=(ds[u],paths[u]):continue
  if u>=service_start and u!=s:continue
  for v,w in adj[u]:
   relax+=1;cand=(d+w,p+(v,))
   if cand[0]<ds[v] or (cand[0]==ds[v] and (paths[v] is None or cand[1]<paths[v])):
    ds[v],paths[v]=cand;heapq.heappush(q,(cand[0],cand[1],v))
 return ds,paths,pops,relax

def evaluate(a,b,field,boundary,edges,rings):
 coords=[a] if a==b else [a,b]
 out=independent.evaluate_geometry(coords,field,boundary,edges)
 exact=exact_segment(rational_coords(a),rational_coords(b),rings)
 assert out['closed_field_covered']==exact,'GEOS versus exact serialized-decimal containment disagreement'
 out['exact_serialized_decimal_containment']=exact
 out['clearance_status']=state(out['minimum_clearance_m'],out['closed_field_covered'])
 return out

def service_audit(inst,field,boundary,edges,rings,cache):
 out=[]
 for sid,p in enumerate(inst['coordinates']):
  k=tuple(p)
  if k not in cache:cache[k]=evaluate(p,p,field,boundary,edges,rings)
  out.append({'service_id':sid,'role':'depot' if sid==0 else 'task','coordinate':p,**cache[k]})
 return out

def build_instance(inst,center,field,boundary,bnodes,bedges):
 t=timing();b=len(bnodes);services=inst['coordinates'];nodes=bnodes+services;edges=list(bedges);checks=0;added=[]
 for j in range(b,len(nodes)):
  for i in range(j):
   checks+=1
   if safe_edge(nodes[i],nodes[j],center,field,boundary):
    e=[i,j,distance(nodes[i],nodes[j])];edges.append(e);added.append(e)
 adj=[[] for _ in nodes]
 for i,j,w in edges:adj[i].append((j,w));adj[j].append((i,w))
 sn=list(range(b,len(nodes)));ds=[dijkstra(adj,s,b) for s in sn];k=len(sn)
 unreachable=[[i,j] for i in range(k) for j in range(i+1,k) if not math.isfinite(ds[i][0][sn[j]])]
 D=[[0.]*k for _ in range(k)];paths=[[None]*k for _ in range(k)];asym=0.
 if not unreachable:
  for i in range(k):
   for j in range(i,k):
    asym=max(asym,abs(ds[i][0][sn[j]]-ds[j][0][sn[i]]));p=list(ds[i][1][sn[j]]);v=math.fsum(distance(nodes[a],nodes[c]) for a,c in zip(p,p[1:]));assert abs(v-ds[i][0][sn[j]])<=TOL
    D[i][j]=D[j][i]=v;paths[i][j]=p;paths[j][i]=p[::-1]
  assert asym<=TOL
 artifact={'nodes':nodes,'service_node_ids':sn,'added_visibility_edges':added,'shared_graph_file':'shared_preprocessing.json','new_visibility_checks':checks,'graph_nodes':len(nodes),'graph_edges':len(edges),'unreachable_service_pairs':unreachable,'distance_matrix':None if unreachable else D,'paths':None if unreachable else paths,'dijkstra_heap_pops':sum(x[2] for x in ds),'dijkstra_relaxations':sum(x[3] for x in ds),'distance_max_asymmetry_m':asym,'preprocessing_resources':elapsed(t)}
 return artifact,D,paths

def run_instance(inst,center,field,boundary,edges,rings,bnodes,bedges,meta,pcache,scache):
 start=timing();name=inst['instance_id'];prior=next(x for x in json.loads((ROOT/'input/prior/clearance_aware_results.json').read_text())['instances'] if x['instance_id']==name);marginprior=json.loads((ROOT/'input/prior/margin_sensitivity_results.json').read_text())
 def finish(result):
  result.update({'instance_id':name,'n':inst['n'],'seed':inst['seed'],'input_sha256':sha(ROOT/f'input/{name}_input.json'),'instance_resources':elapsed(start),'old_route_comparison':{m:old_comparison(name,m,prior,marginprior) for m,_ in METHODS},'comparison_scope':'Changed required clearance 1.00m to 1.10m; route cost differences are constraint-specific, not pure algorithm gains or regressions.'})
  save(f'raw/{name}_result.json',result);print(json.dumps({'instance_id':name,'status':result['status'],'resources':result['instance_resources']}),flush=True);return result
 t=timing();services=service_audit(inst,field,boundary,edges,rings,pcache);service_time=elapsed(t)
 rec={'services':services,'service_validation_resources':service_time,'methods':{},'failing_service_ids':[s['service_id'] for s in services if s['clearance_status']=='FAIL'],'uncertain_service_ids':[s['service_id'] for s in services if s['clearance_status']=='UNCERTAIN_BOUNDARY']}
 if rec['failing_service_ids']:return finish({'status':'TASK_INFEASIBLE',**rec})
 if rec['uncertain_service_ids']:return finish({'status':'UNCERTAIN_ENDPOINT_NUMERICS',**rec})
 if meta['status']!='POSTERIOR_NUMERIC_REGION_PASS':return finish({'status':meta['status'] if meta['status'] in ['RESOURCE_TIMEOUT','TECHNICAL_FAILURE'] else 'CONSERVATIVE_APPROXIMATION_UNAVAILABLE','shared_preprocessing_status':meta['status'],**rec})
 excluded=[s['service_id'] for s in services if not covered(geom([s['coordinate']]),center)]
 if excluded:return finish({'status':'CONSERVATIVE_APPROXIMATION_UNAVAILABLE','safe_endpoints_excluded_by_approximation':excluded,**rec})
 artifact,D,paths=build_instance(inst,center,field,boundary,bnodes,bedges);save(f'raw/{name}_graph.json',artifact)
 rec['preprocessing_resources']=artifact['preprocessing_resources']
 if artifact['unreachable_service_pairs']:return finish({'status':'NO_CONNECTION_IN_FROZEN_GRAPH','no_connection_is_not_a_continuous_infeasibility_proof':True,'unreachable_service_pairs':artifact['unreachable_service_pairs'],**rec})
 nodes=artifact['nodes'];sn=artifact['service_node_ids'];n=inst['n']
 for label,fn in METHODS:
  t=timing();order,stats=bounded_solver(fn,D);rt=elapsed(t);polyids=[];legs=[]
  for a,b in zip(order,order[1:]):
   p=paths[a][b];assert p[0]==sn[a] and p[-1]==sn[b];assert all(x<len(bnodes) for x in p[1:-1]);legs.append({'service_leg':[a,b],'node_ids':p});polyids.extend(p if not polyids else p[1:])
  coordinates=[nodes[x] for x in polyids]
  route={'route':order,'length_m':cost(order,D),'operations':stats,'solve_resources':rt,'mapped_polyline_node_ids':polyids,'mapped_polyline_coordinates':coordinates,'legs':legs}
  save(f'raw/{name}_{label}_solver_output.json',route)
  t=timing();segments=[]
  for si,(a,b) in enumerate(zip(coordinates,coordinates[1:])):
   key=tuple(sorted((tuple(a),tuple(b))))
   if key not in scache:scache[key]=evaluate(a,b,field,boundary,edges,rings)
   segments.append({'segment_index':si,'a':a,'b':b,**scache[key]})
  full=geom(coordinates);d=full.Distance(boundary);inside=covered(full,field);segmin=min(v['minimum_clearance_m'] for v in segments);assert abs(d-segmin)<=TOL
  length=math.fsum(distance(a,b) for a,b in zip(coordinates,coordinates[1:]));assert abs(length-route['length_m'])<=TOL
  visits=collections.Counter(order[1:-1]);once=len(order)==n+2 and visits==collections.Counter(range(1,n+1));closed=order[0]==order[-1]==0 and coordinates[0]==coordinates[-1]==inst['coordinates'][0]
  assert once and closed
  hole_checks=[]
  for hi in range(1,field.GetGeometryCount()):
   hole=ogr.Geometry(ogr.wkbPolygon);hole.AddGeometry(field.GetGeometryRef(hi));inter=full.Intersection(hole);hole_checks.append({'original_hole_index':hi,'intersection_empty':bool(inter.IsEmpty()),'distance_m':full.Distance(hole)})
  exact_ok=all(s['exact_serialized_decimal_containment'] for s in segments)
  status='VALID_SAFE_ROUTE' if inside and d>REQUIRED_CLEARANCE+TOL and exact_ok and all(s['clearance_status']=='PASS' for s in segments) and all(h['intersection_empty'] for h in hole_checks) else 'UNCERTAIN_OR_INVALID_POSTERIOR_ROUTE'
  audit={'status':status,'service_visit_counts':dict(visits),'each_scheduled_task_once':once,'depot_closed':closed,'complete_polyline_covered':inside,'complete_polyline_minimum_clearance_m':d,'segment_minimum_clearance_m':segmin,'all_segments_exact_decimal_contained':exact_ok,'all_outer_and_three_hole_rings_checked':True,'original_hole_checks':hole_checks,'mapped_length_m':length,'segments':segments,'validation_resources':elapsed(t),'visit_semantics':'Scheduled service visits exactly once. Passing a coordinate without a service event is not an additional scheduled visit.'}
  save(f'raw/{name}_{label}_route_audit.json',audit);rec['methods'][label]={**route,'audit_file':f'{name}_{label}_route_audit.json','clearance_status':status,'minimum_clearance_m':d,'validation_resources':audit['validation_resources']}
 assert rec['methods']['nn_2opt_budget']['length_m']<=rec['methods']['nearest_neighbor']['length_m']+TOL
 allsafe=all(x['clearance_status']=='VALID_SAFE_ROUTE' for x in rec['methods'].values())
 return finish({'status':'VALID_SAFE_ROUTES' if allsafe else 'UNCERTAIN_OR_INVALID_POSTERIOR_ROUTE',**rec})

def toy_tests():
 """Synthetic-only preexecution test; never reads actual field/task inputs."""
 old=independent.toy_tests();field=ogr.CreateGeometryFromWkt('POLYGON ((0 0,20 0,20 20,0 20,0 0),(8 8,12 8,12 12,8 12,8 8))')
 c,ns,m=construct(field);assert m['status']=='POSTERIOR_NUMERIC_REGION_PASS';assert m['minimum_region_distance_to_original_boundary_m']>REQUIRED_CLEARANCE+TOL
 assert not safe_edge([2,10],[18,10],c,field,field.Boundary());assert safe_edge([2,2],[18,2],c,field,field.Boundary())
 assert state(REQUIRED_CLEARANCE,True)=='UNCERTAIN_BOUNDARY';assert state(1.05,True)=='FAIL';assert state(1.15,True)=='PASS';assert state(REQUIRED_CLEARANCE-2*TOL,True)=='FAIL';assert state(REQUIRED_CLEARANCE+2*TOL,True)=='PASS'
 ds=dijkstra([[(1,1)],[(0,1)],[]],0,3);assert math.isinf(ds[0][2])
 D=[[0.,2.,3.],[2.,0.,1.],[3.,1.,0.]];a,_=nn(D);b,st=twoopt(D);assert a[0]==a[-1]==0 and sorted(a[1:-1])==[1,2] and cost(b,D)<=cost(a,D)
 return {'status':'PASS','synthetic_only':True,'upstream_tests':old,'buffer_region_test':m,'disconnected_graph_handled':True,'nn_twoopt_tests_pass':True}

def old_comparison(name,method,prior,marginprior):
 old=prior.get('methods',{}).get(method)
 cond=next((c for c in marginprior['existing_route_conditions'] if c['instance_id']==name and c['method']==method and c['extra_margin_m']=='0.10'),None)
 return {'old_instance_status':prior['status'],'old_route_exists':old is not None,'old_length_m':None if old is None else old['length_m'],'old_minimum_clearance_m':None if old is None else old['minimum_clearance_m'],'old_1m_clearance_status':None if old is None else old['clearance_status'],'old_1_10m_condition':cond}

def bounded_solver(fn,D):
 # The 5s solver deadline nests inside the remaining 15s instance timer.
 remaining=signal.getitimer(signal.ITIMER_REAL)[0];t=time.monotonic()
 signal.setitimer(signal.ITIMER_REAL,min(5.0,remaining) if remaining else 5.0)
 try:return fn(D)
 finally:
  if remaining:signal.setitimer(signal.ITIMER_REAL,max(1e-6,remaining-(time.monotonic()-t)))
  else:signal.setitimer(signal.ITIMER_REAL,0)

def main():
 assert len(sys.argv)==2 and sys.argv[1]=='--formal','Use the frozen gated run_once.py wrapper.'
 assert (ROOT/'evidence/STARTED.json').is_file()
 started=json.loads((ROOT/'evidence/STARTED.json').read_text());assert started['runner_pid']==os.getppid()
 receipt=json.loads((ROOT/'evidence/PREEXECUTION_DRIVE_RECEIPT.json').read_text());archive=ROOT.parent/(ROOT.name+'_PREEXECUTION_SNAPSHOT.zip')
 assert receipt['verified'] is True and receipt['download_byte_identical'] is True and receipt['permissions']=='owner_only' and receipt['shared'] is False
 assert receipt['sha256']==receipt['download_sha256']==started['preexec_zip_sha256']==sha(archive)
 assert resource.getrlimit(resource.RLIMIT_CPU)==(60,60) and resource.getrlimit(resource.RLIMIT_AS)==(536870912,536870912)
 freeze=json.loads((ROOT/'freeze/PREEXECUTION_FREEZE.json').read_text())
 for p,h in freeze['files'].items():assert sha(ROOT/p)==h,p
 save('evidence/FORMAL_CHILD_ENTERED.json',{'utc':utc(),'attempt':1,'parent_pid':os.getppid(),'inherited_limits_verified':True})
 prior=json.loads((ROOT/'input/prior/clearance_aware_audit.json').read_text());assert prior['status']=='PASS_INDEPENDENT_SAVED_RESULT_AUDIT'
 start=timing();w=(ROOT/'input/projected_epsg32634.wkt').read_text();field=ogr.CreateGeometryFromWkt(w);assert field.IsValid() and field.GetGeometryCount()==4
 rings=rational_rings(w);assert len(rings)==4;boundary=field.Boundary();edges=independent.boundary_edges(field)
 save('raw/original_boundary_edges.json',[{k:v for k,v in e.items() if k!='geom'} for e in edges]);signal.signal(signal.SIGALRM,timeout)
 results=[];pcache={};scache={};endpoint_records=[]
 files=sorted((ROOT/'input').glob('n*_input.json'));assert len(files)==12
 # All 12 endpoint classifications are saved before any inset or graph planning.
 et=timing();signal.alarm(15)
 for p in files:
  inst=json.loads(p.read_text());services=service_audit(inst,field,boundary,edges,rings,pcache)
  failed=[s['service_id'] for s in services if s['clearance_status']=='FAIL'];uncertain=[s['service_id'] for s in services if s['clearance_status']=='UNCERTAIN_BOUNDARY']
  rec={'instance_id':inst['instance_id'],'input_sha256':sha(p),'services':services,'failing_service_ids':failed,'uncertain_service_ids':uncertain,'endpoint_status':'TASK_INFEASIBLE' if failed else 'UNCERTAIN_ENDPOINT_NUMERICS' if uncertain else 'ENDPOINTS_CLEAR_NECESSARY_ONLY'}
  save(f"raw/{inst['instance_id']}_endpoints.json",rec);endpoint_records.append(rec)
 signal.alarm(0);save('raw/endpoint_phase.json',{'finished_utc':utc(),'resources':elapsed(et),'instances':endpoint_records,'endpoint_pass_is_not_path_existence':True})
 signal.alarm(40)
 try:center,bnodes,bedges,meta=build_base(field)
 except Exception as exc:
  center=None;bnodes=[];bedges=[];meta={'status':'RESOURCE_TIMEOUT' if isinstance(exc,TimeoutError) else 'TECHNICAL_FAILURE','error':str(exc),'traceback':traceback.format_exc()};save('raw/shared_preprocessing_failure.json',meta)
 finally:signal.alarm(0)
 for p in files:
  inst=json.loads(p.read_text());signal.alarm(15)
  try:result=run_instance(inst,center,field,boundary,edges,rings,bnodes,bedges,meta,pcache,scache)
  except Exception as exc:
   ep=next(x for x in endpoint_records if x['instance_id']==inst['instance_id']);old=next(x for x in json.loads((ROOT/'input/prior/clearance_aware_results.json').read_text())['instances'] if x['instance_id']==inst['instance_id']);mp=json.loads((ROOT/'input/prior/margin_sensitivity_results.json').read_text())
   result={'services':ep['services'],'failing_service_ids':ep['failing_service_ids'],'uncertain_service_ids':ep['uncertain_service_ids'],'methods':{},'old_route_comparison':{m:old_comparison(inst['instance_id'],m,old,mp) for m,_ in METHODS},'instance_id':inst['instance_id'],'n':inst['n'],'seed':inst['seed'],'status':'RESOURCE_TIMEOUT' if isinstance(exc,TimeoutError) else 'TECHNICAL_FAILURE','error':str(exc),'traceback':traceback.format_exc()};save(f"raw/{inst['instance_id']}_failure.json",result)
  finally:signal.alarm(0)
  results.append(result)
 save('raw/results.json',{'status':'COMPLETE_UNAUDITED','instances':results,'status_counts':dict(collections.Counter(x['status'] for x in results)),'routes_produced':sum(len(x.get('methods',{})) for x in results),'base_disk_radius_m':BASE_DISK_RADIUS,'extra_margin_m':EXTRA_MARGIN,'required_clearance_m':REQUIRED_CLEARANCE,'resources':elapsed(start),'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'unique_evaluated_services':len(pcache),'unique_evaluated_route_segments':len(scache),'GDAL':gdal.VersionInfo(),'GEOS':[ogr.GetGEOSVersionMajor(),ogr.GetGEOSVersionMinor(),ogr.GetGEOSVersionMicro()]})
if __name__=='__main__':
 if len(sys.argv)>1 and sys.argv[1]=='toy':save('evidence/PREEXECUTION_TOY_TESTS.json',toy_tests())
 else:main()
