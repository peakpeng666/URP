#!/usr/bin/python3
import pathlib,json,hashlib,datetime,zipfile,sys
R=pathlib.Path(__file__).resolve().parents[1]
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,x):
 with (R/n).open('x') as f:json.dump(x,f,indent=2,ensure_ascii=False);f.write('\n')
stage=sys.argv[1]
if stage=='PREEXECUTION':
 assert not list((R/'raw').iterdir()) and not (R/'evidence/STARTED.json').exists()
 review=json.loads((R/'independent_review/evidence/STATIC_PREEXEC_REVIEW.json').read_text());assert review['status']=='PASS_STATIC_PREEXEC_REVIEW'
 for p,v in json.loads((R/'freeze/INPUT_IDENTITY.json').read_text()).items():assert h(R/p)==v['sha256'] and (R/p).read_bytes()==pathlib.Path(v['source_path']).read_bytes()
 save('freeze/PREEXECUTION_FREEZE.json',{'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'formal_data_not_executed':True,'files':{str(p.relative_to(R)):h(p) for p in sorted(R.rglob('*')) if p.is_file() and '__pycache__' not in str(p)}})
 suffix='PREEXECUTION_SNAPSHOT'
elif stage=='RAW':
 assert (R/'evidence/RUN_STATUS.json').is_file()
 save('evidence/RAW_COMPLETE_UNAUDITED_MANIFEST.json',{'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'RAW_UNAUDITED','files':{str(p.relative_to(R)):h(p) for p in sorted(R.rglob('*')) if p.is_file() and '__pycache__' not in str(p)}})
 suffix='RAW_COMPLETE_UNAUDITED'
else:raise ValueError(stage)
p=R.parent/(R.name+'_'+suffix+'.zip')
with zipfile.ZipFile(p,'x',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(R.rglob('*')):
  if f.is_file() and '__pycache__' not in str(f):z.write(f,f.relative_to(R.parent))
print(json.dumps({'path':str(p),'sha256':h(p),'bytes':p.stat().st_size}))
