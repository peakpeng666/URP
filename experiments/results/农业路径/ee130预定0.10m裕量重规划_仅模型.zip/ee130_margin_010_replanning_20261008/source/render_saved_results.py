#!/usr/bin/python3
"""Report saved evidence only after RAW readback. No graph, buffer or solver calls."""
import csv,json,math,os,pathlib,hashlib,collections
os.environ['MPLCONFIGDIR']='/tmp/ee130_margin010_mpl'
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from osgeo import ogr
R=pathlib.Path(__file__).resolve().parents[1]
def get(n):return json.loads((R/n).read_text())
def put(n,x):
 with (R/n).open('x') as f:json.dump(x,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')
receipt=get('evidence/RAW_DRIVE_RECEIPT.json');assert receipt['verified'] and receipt['download_byte_identical'] and receipt['permissions']=='owner_only' and receipt['shared'] is False
assert receipt['sha256']==receipt['download_sha256']==hashlib.sha256((R.parent/(R.name+'_RAW_COMPLETE_UNAUDITED.zip')).read_bytes()).hexdigest()
try:results=get('raw/results.json');assert len(results['instances'])==12
except Exception:results=get('raw/INCOMPLETE_EXECUTION_INDEX.json')
instances=results['instances'];endpoints={}
for ip in sorted((R/'input').glob('n*_input.json')):
 inst=json.loads(ip.read_text());name=inst['instance_id']
 try:ep=get(f'raw/{name}_endpoints.json')
 except Exception:ep={'instance_id':name,'endpoint_status':'ENDPOINT_AUDIT_NOT_COMPLETED','failing_service_ids':[],'uncertain_service_ids':[],'services':[{'service_id':j,'coordinate':p} for j,p in enumerate(inst['coordinates'])]}
 endpoints[name]=ep
prior=get('input/prior/clearance_aware_results.json');old_by={x['instance_id']:x for x in prior['instances']};margin=get('input/prior/margin_sensitivity_results.json')
methods=['nearest_neighbor','nn_2opt_budget'];rows=[]
for i in instances:
 name=i['instance_id'];ep=endpoints[name]
 for label in methods:
  m=i.get('methods',{}).get(label);old=old_by[name].get('methods',{}).get(label);condition=next((x for x in margin['existing_route_conditions'] if x['instance_id']==name and x['method']==label and x['extra_margin_m']=='0.10'),None)
  delta=m['length_m']-old['length_m'] if m and old else None
  rows.append({'instance_id':name,'n':i['n'],'seed':i['seed'],'method':label,'endpoint_status':ep['endpoint_status'],'failing_service_ids':ep['failing_service_ids'],'uncertain_service_ids':ep['uncertain_service_ids'],'new_instance_status':i['status'],'new_route_status':None if not m else m['clearance_status'],'old_route_exists':old is not None,'old_1_10m_status':'NO_SAVED_ROUTE' if condition is None else condition['conservative_status'],'old_length_m':None if not old else old['length_m'],'new_length_m':None if not m else m['length_m'],'new_minus_old_length_m':delta,'new_minus_old_percent':None if delta is None else 100*delta/old['length_m'],'old_minimum_clearance_m':None if not old else old['minimum_clearance_m'],'new_minimum_clearance_m':None if not m else m['minimum_clearance_m'],'new_extra_clearance_above_1_10_m':None if not m else m['minimum_clearance_m']-1.10,'graph_wall_seconds':i.get('preprocessing_resources',{}).get('wall_seconds'),'solve_wall_seconds':None if not m else m['solve_resources']['wall_seconds'],'candidate_reversals':None if not m else m['operations'].get('candidate_reversals'),'changed_constraint_not_algorithm_regression':True})
assert len(rows)==24
put('reports/all_24_method_conditions.json',rows)
with (R/'reports/all_24_method_conditions.csv').open('x') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows({k:json.dumps(v) if isinstance(v,list) else v for k,v in r.items()} for r in rows)
valid=[r for r in rows if r['new_route_status']=='VALID_SAFE_ROUTE'];produced=[r for r in rows if r['new_length_m'] is not None];oldrows=[r for r in rows if r['old_route_exists']]
summary={'all_instances':len(instances),'all_method_conditions':len(rows),'endpoint_clear_instances':sum(x['endpoint_status']=='ENDPOINTS_CLEAR_NECESSARY_ONLY' for x in endpoints.values()),'endpoint_infeasible_instances':sum(x['endpoint_status']=='TASK_INFEASIBLE' for x in endpoints.values()),'new_instance_status_counts':dict(collections.Counter(i['status'] for i in instances)),'old_saved_route_count':len(oldrows),'old_saved_routes_pass_1_10':sum(r['old_1_10m_status']=='PASS' for r in oldrows),'new_routes_produced':len(produced),'new_routes_pass_1_10':len(valid),'old_failed_new_pass':sum(r['old_1_10m_status']=='FAIL' for r in valid),'old_pass_new_pass':sum(r['old_1_10m_status']=='PASS' for r in valid),'new_minimum_clearance_m':min((r['new_minimum_clearance_m'] for r in produced),default=None),'new_length_delta_range_m':[min((r['new_minus_old_length_m'] for r in produced if r['new_minus_old_length_m'] is not None),default=None),max((r['new_minus_old_length_m'] for r in produced if r['new_minus_old_length_m'] is not None),default=None)],'formal_execution_resources':get('evidence/RUN_STATUS.json'),'rows':rows,'status':'AUTHOR_SAVED_REPORT_FOR_INDEPENDENT_TEXT_REVIEW'}
put('reports/summary.json',summary)
field=ogr.CreateGeometryFromWkt((R/'input/projected_epsg32634.wkt').read_text());off=(661850,6526070)
def local(p):return p[0]-off[0],p[1]-off[1]
def draw_field(ax):
 for ri in range(field.GetGeometryCount()):
  ring=field.GetGeometryRef(ri);pts=[local(ring.GetPoint(j)) for j in range(ring.GetPointCount())];ax.fill(*zip(*pts),facecolor='#eef2ee' if ri==0 else 'white',edgecolor='#334039',linewidth=.8)
 ax.set_aspect('equal');ax.grid(alpha=.15);ax.tick_params(labelsize=7)
def draw_points(ax,name):
 ep=endpoints[name]
 for s in ep['services']:
  sid=s['service_id'];bad=sid in ep['failing_service_ids'];ax.scatter(*local(s['coordinate']),c='#bd3a29' if bad else '#293945',marker='*' if sid==0 else ('x' if bad else 'o'),s=65 if sid==0 else (30 if bad else 12),zorder=4)
fig,axs=plt.subplots(3,4,figsize=(15,11),sharex=True,sharey=True)
for ax,i in zip(axs.flat,instances):
 name=i['instance_id'];draw_field(ax);draw_points(ax,name);m=i.get('methods',{}).get('nn_2opt_budget')
 if m:ax.plot(*zip(*[local(p) for p in m['mapped_polyline_coordinates']]),color='#087e70',lw=1.4,zorder=3)
 subtitle=i['status'] if not endpoints[name]['failing_service_ids'] else 'Endpoint fail: '+','.join(map(str,endpoints[name]['failing_service_ids']))
 ax.set_title(name+'\n'+subtitle,fontsize=8)
for ax in axs[-1]:ax.set_xlabel('Easting - 661850 (m)',fontsize=8)
for ax in axs[:,0]:ax.set_ylabel('Northing - 6526070 (m)',fontsize=8)
fig.suptitle('All 12 fixed instances: 1 m disk + prespecified 0.10 m geometric margin',fontsize=14)
fig.legend(handles=[Line2D([0],[0],color='#087e70',lw=2,label='New saved 2-opt route'),Line2D([0],[0],marker='x',color='#bd3a29',ls='',label='Original endpoint fails 1.10 m'),Line2D([0],[0],marker='*',color='#293945',ls='',label='Original depot')],loc='lower center',ncol=3,frameon=False,fontsize=10)
fig.tight_layout(rect=(0,.045,1,.96));fig.savefig(R/'reports/all_12_instances.png',dpi=160);plt.close(fig)
routed=[i for i in instances if i.get('methods')]
if routed:
 fig,axs=plt.subplots(len(routed),2,figsize=(11,max(4,3.8*len(routed))),sharex=True,sharey=True,squeeze=False)
 for axisrow,i in zip(axs,routed):
  name=i['instance_id']
  for ax,label in zip(axisrow,methods):
   draw_field(ax);draw_points(ax,name);row=next(r for r in rows if r['instance_id']==name and r['method']==label);old=old_by[name].get('methods',{}).get(label);m=i.get('methods',{}).get(label)
   if old:ax.plot(*zip(*[local(p) for p in old['mapped_polyline_coordinates']]),color='#cf7f29',lw=2.5,alpha=.6,zorder=2)
   if m:ax.plot(*zip(*[local(p) for p in m['mapped_polyline_coordinates']]),color='#087e70',lw=1.3,zorder=3)
   ax.set_title(f'{name} | {label}\nOld @1.10: {row["old_1_10m_status"]}; new: {row["new_route_status"]}\nDelta L={row["new_minus_old_length_m"]:.6f} m; d={row["new_minimum_clearance_m"]:.9f} m',fontsize=9)
 for ax in axs[-1]:ax.set_xlabel('Easting - 661850 (m)')
 for ax in axs[:,0]:ax.set_ylabel('Northing - 6526070 (m)')
 fig.suptitle('Every newly produced route, overlaid with its prior 1.00 m plan\nStricter constraint cost changes are not algorithm regression',fontsize=13)
 fig.legend(handles=[Line2D([0],[0],color='#087e70',lw=2,label='New 1.10 m planning'),Line2D([0],[0],color='#cf7f29',lw=3,alpha=.6,label='Prior 1.00 m planning')],loc='lower center',ncol=2,frameon=False)
 fig.tight_layout(rect=(0,.035,1,.95));fig.savefig(R/'reports/all_new_routes.png',dpi=160);plt.close(fig)
put('evidence/FIGURE_DESCRIPTION.json',{'all_12_instances.png':'All12 original instances retained; all failing endpoint IDs shown;2opt complete geometry shown where produced.','all_new_routes.png':'All produced methods overlaid on prior1.00m plans; slight geometric differences may be invisible at field scale; tabular exact checks govern.','scope':'EPSG32634 metre coordinates translated by fixed origin only, original outer ring and3 holes intact. No resampling, selection, rebuffering or replanning during rendering.'})
pre=get('evidence/PREEXECUTION_DRIVE_RECEIPT.json');run=summary['formal_execution_resources']
lines=['# 固定任务：半径1米圆盘加额外10厘米几何裕量重规划','', '日期：2026-10-08。唯一正式执行；输入保持原地块、depot及全部12个任务实例不变。额外0.10米是事先固定的敏感性设计值，不代表实际定位、边界测量或控制误差。','', '## 主要结果','',f'原来保存的{len(oldrows)}条路线中，{summary["old_saved_routes_pass_1_10"]}条已经满足1.10米净空；本轮生成{len(produced)}条完整路线，其中{len(valid)}条通过作者整段几何检查。此前不满足的新通过路线为{summary["old_failed_new_pass"]}条。独立复核以 independent_review/ 中的最终状态及逐段证据为准。', '',f'全部12个实例中，{summary["endpoint_infeasible_instances"]}个由原服务点不足净空而不可行，{summary["endpoint_clear_instances"]}个端点满足必要条件。新规划的完整实例状态：{json.dumps(summary["new_instance_status_counts"],ensure_ascii=False)}。端点合格不被当作路径存在证明。','', '## 逐路线对照','', '| 实例 | 方法 | 旧路线1.10米审计 | 旧长度 米 | 新长度 米 | 增量 米 | 增量 % | 新最小净空 米 |','|---|---|---|---:|---:|---:|---:|---:|']
for r in produced:lines.append(f'| {r["instance_id"]} | {"NN" if r["method"]=="nearest_neighbor" else "2-opt"} | {r["old_1_10m_status"]} | {r["old_length_m"]:.6f} | {r["new_length_m"]:.6f} | {r["new_minus_old_length_m"]:+.6f} | {r["new_minus_old_percent"]:+.6f} | {r["new_minimum_clearance_m"]:.12f} |')
lines+=['','长度改变是在1.00米与1.10米两种约束及其有限图上比较。同算法在更强约束下长度增加不能称为算法退步；启发式或图变化也可能使长度减少。真正同约束的方法对比仅为本轮同一图中的NN与2-opt。没有证明精确连续最短路径或全局最优。','', '## 全部12个实例，失败完整保留','', '| 实例 | 端点状态 | 不合格服务点ID | 新规划状态 |','|---|---|---|---|']
for i in instances:
 ep=endpoints[i['instance_id']];lines.append(f'| {i["instance_id"]} | {ep["endpoint_status"]} | {", ".join(map(str,ep["failing_service_ids"])) or "无"} | {i["status"]} |')
lines+=['', '未保存路线的实例×方法组合仍保留在24行完整结果表中，未作为零成本或成功路线混入分母。图不连通仅表示冻结有限图不可解；保守近似排除不能证明原连续任务不可行。只有端点几何失败能直接否定该固定任务。','', '## 冻结算法与几何审计','', '- 物理圆盘半径固定1米，额外几何裕量固定0.10米，required clearance为1.10米。NN、第一改进2-opt与10000候选预算源码逐字节沿用；全部点、seed与任务前缀不变。','- 全12个任务先独立保存端点筛查，随后才构造内缩域与图。缓冲使用16段/象限、距离(1.10+10⁻⁵)/cos(π/32)=1.1053324779996665米，补偿弧段离散近似的潜在欠净空。保守构造后仍核验整个填充域距原边界和三孔洞关系，不以弧公式代替验算。','- 对完整可视边、完整已保存路线每一线段以及整条折线审计，绝非只查顶点。主算GEOS与Decimal60投影/相交交叉核对；独审以原始WKT/JSON十进制坐标做整数/有理完整段包含与距离平方验证。无向缓存中evaluation_coordinates为首次求值方向，段a/b始终为该路线实际方向；方向不改变距离或包含结论。','- PASS要求完整包含且净空严格大于1.10+10⁻⁸米；出界或低于1.10−10⁻⁸判失败，其余保留数值不确定，不跨阈值四舍五入。逐服务点、完整路线、depot闭合、恰一次调度服务、原三孔洞均需检查。','', '## 资源与执行顺序','',f'预先限额：总60秒CPU、120秒wall、512MiB地址空间。端点阶段15秒、共享构图40秒、每实例15秒、每次solver5秒均嵌套于总限额，不能相加扩大总预算。实际正式执行CPU {run["children_cpu_seconds"]:.6f}秒、wall {run["wall_seconds"]:.6f}秒、峰值RSS {run["children_peak_rss_kib"]}KiB。验证/报告/独审另计，不宣称单次计时具有统计稳定性。','', '顺序：合成预测及独立静态预审→代码输入协议冻结→PREEXEC私有归档逐字节回读→唯一正式运行→RAW立即私有归档逐字节回读→独立保存结果重算→报告。没有参数重调、模型调用、依赖安装、旧源文件修改或受阻旧索引操作。','',f'- [PREEXEC快照]({pre["url"]})，SHA256 {pre["sha256"]}',f'- [RAW原始未审快照]({receipt["url"]})，SHA256 {receipt["sha256"]}','', 'RAW的COMPLETE_UNAUDITED标签保留为该时点状态，不覆盖旧证据。最终独审及交付见本包后续evidence和independent_review。','', '## 解释边界与证据入口','', '这是一个地块、三个布局种子的四档嵌套前缀；12实例和8方法路线不是独立地块样本。10厘米虽在本轮求解前固定，但选择是在旧净空结果已知后，因此不是盲测。EPSG:32634只沿用已有米制解释，不新增测绘真值证明。圆盘不含车辆方向、转弯半径、非圆农具、速度、动力学和控制；本轮不构成实车安全保证。','', 'freeze/为方案与输入身份，source/为完整源码，raw/保存完整坐标、图、服务顺序、逐段证据及失败，reports/all_24_method_conditions.json与csv保留全部组合；两张图分别保留全部12实例和所有产生路线，independent_review/保存不调用求解器的独审。']
with (R/'reports/REPORT_zh.md').open('x') as f:f.write('\n'.join(lines)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='rows'},ensure_ascii=False))
