#!/usr/bin/python3
"""Copy allowed immutable research inputs; this script never plans a route."""
import pathlib,hashlib,json,shutil,datetime
R=pathlib.Path(__file__).resolve().parents[1]
A=pathlib.Path('/workspace/shared/ee130_clearance_aware_routing_20261008')
B=pathlib.Path('/workspace/shared/ee130_route_margin_sensitivity_20261008')
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(rel,data):
 with (R/rel).open('x') as f:json.dump(data,f,indent=2);f.write('\n')
identity={}
def cp(src,rel):
 dst=R/rel;assert not dst.exists();shutil.copyfile(src,dst);assert dst.read_bytes()==src.read_bytes();identity[rel]={'source_path':str(src),'sha256':h(src),'byte_identical':True}
for p in sorted((A/'input').glob('n*_input.json')):cp(p,'input/'+p.name)
for n in ['projected_epsg32634.wkt','crs_provenance.json']:cp(A/'input'/n,'input/'+n)
for n in ['audit_clearance.py','common.py','geometry.py','run_instance.py']:cp(A/'source/upstream'/n,'source/upstream/'+n)
cp(A/'source/route_algorithms.py','source/route_algorithms.py')
cp(A/'source/clearance_routing.py','source/upstream/original_clearance_routing.py')
cp(A/'freeze/PROTOCOL.json','input/prior/clearance_aware_PROTOCOL.json')
cp(A/'raw/results.json','input/prior/clearance_aware_results.json')
cp(A/'independent_review/INDEPENDENT_SAVED_RESULT_AUDIT.json','input/prior/clearance_aware_audit.json')
cp(A/'independent_review/INDEPENDENT_REVIEW_REPORT.md','input/prior/clearance_aware_report.md')
cp(B/'raw/results.json','input/prior/margin_sensitivity_results.json')
cp(B/'reports/REPORT_zh.md','input/prior/margin_sensitivity_report.md')
cp(B/'independent_review/results/FINAL_REVIEW_STATUS.json','input/prior/margin_sensitivity_audit.json')
cp(B/'independent_review/results/INDEPENDENT_REVIEW_REPORT.md','input/prior/margin_sensitivity_independent_report.md')
for p in sorted((A/'raw').glob('*_solver_output.json')):cp(p,'input/routes/'+p.name)
assert len(list((R/'input').glob('n*_input.json')))==12
assert len(list((R/'input/routes').glob('*.json')))==8
save('freeze/INPUT_IDENTITY.json',identity)
save('freeze/UPSTREAM_IMMUTABILITY.json',{str(p):h(p) for base in [A,B] for p in sorted(base.rglob('*')) if p.is_file()})
save('evidence/ENVIRONMENT.json',{'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'copied_files':len(identity),'python_executable':'/usr/bin/python3','no_formal_execution':True})
