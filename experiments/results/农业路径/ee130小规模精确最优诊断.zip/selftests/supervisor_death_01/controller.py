import pathlib,sys
sys.path.insert(0,'/workspace/shared/ee130_exact_small_field_20261009/source')
from batch import execute
from common import ROOT,read
execute(read(pathlib.Path('/workspace/shared/ee130_exact_small_field_20261009/selftests/supervisor_death_01/SCHEDULE.json')),ROOT,pathlib.Path('/workspace/shared/ee130_exact_small_field_20261009/selftests/supervisor_death_01/raw'),pathlib.Path('/workspace/shared/ee130_exact_small_field_20261009/selftests/supervisor_death_01/fork_sleep.py'))
