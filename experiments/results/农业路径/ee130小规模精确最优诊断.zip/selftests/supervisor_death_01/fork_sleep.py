#!/usr/bin/python3
import os,time
pid=os.fork()
if pid==0:
 open('/workspace/shared/ee130_exact_small_field_20261009/selftests/supervisor_death_01/descendant.pid',"w").write(str(os.getpid()))
 time.sleep(60)
else:
 time.sleep(60)
