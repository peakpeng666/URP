"""No solver calls: invented route/value/ledger error fixtures for the final saved-output checker."""
from pathlib import Path
import json,copy,datetime
from audit_exact_outputs import validate_values,ledger
from validation_runtime import sha
R=Path(__file__).resolve().parents[2];T=R/'independent_supervision/synthetic';checks=[]
E=[[0,2,3],[2,0,4],[3,4,0]];G=[[0,5,6],[5,0,7],[6,7,0]];entry={'n':2,'objective':'E_G'}
v=json.loads((T/'chain/raw/calls/invented0.stdout').read_text())
m={'status':'EXACT_ALGORITHM_COMPLETED_UNREVIEWED','n':2,'objective':'E_G','primary':9,'secondary':18,'E':9,'G':18,'route':[0,1,2,0],'valid_states':4,'internal_transitions':2,'states_by_cardinality':[0,2,2],'transitions_by_cardinality':[0,0,2],'rlimit_cpu':[60,60],'rlimit_as':[512*1024**2]*2}
assert validate_values(entry,m,v,E,G)['integer_optimum_values_independently_match'];checks.append('matched_integer_values_and_route')
def reject(name,main,ind):
 try:validate_values(entry,main,ind,E,G)
 except (ValueError,KeyError):checks.append(name);return
 raise AssertionError('Failure not rejected '+name)
b=copy.deepcopy(m);b['route']=[0,1,1,0];reject('invalid_coverage',b,v)
b=copy.deepcopy(m);b['E']+=1;reject('incorrect_author_route_cost',b,v)
b=copy.deepcopy(v);b['primary']+=1;reject('independent_mismatch',m,b)
b=copy.deepcopy(v);b['encoding_base']-=1;reject('wrong_encoding_base',m,b)
b=copy.deepcopy(v);b['encoded_objective']+=1;reject('wrong_encoded_value',m,b)
b=copy.deepcopy(v);b['states']-=1;reject('wrong_state_count',m,b)
b=copy.deepcopy(v);b['rlimit_cpu']=[30,30];reject('wrong_resource_cap',m,b)
sched=json.loads((T/'chain/schedule.json').read_text());events,metadata=ledger(T/'chain/raw',sched);assert len(events)==16 and metadata['observed_event_rows']==32 and not metadata['schema_errors'];checks.append('actual16slot_nested_ledger')
out={'status':'PASS','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'solver_calls':0,'checks':checks,'checker_sha256':sha(Path(__file__).with_name('audit_exact_outputs.py'))}
(T/'SAVED_AUDIT_FIXTURES.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
