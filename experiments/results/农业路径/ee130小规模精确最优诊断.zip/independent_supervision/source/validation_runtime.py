"""Independent bounded process lifecycle shared by invented tests and sixteen formal validation solves."""
import os,resource,signal,subprocess,time,hashlib
from pathlib import Path

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def child_limits():
 resource.setrlimit(resource.RLIMIT_CPU,(60,60));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
def run_one(binary,input_path,outpath,errpath,wall=90,own_process_group=True):
 if not 0<wall<=90:raise ValueError('wall cap')
 start=time.monotonic();before=resource.getrusage(resource.RUSAGE_CHILDREN);p=None;timeout=False;error=None
 with Path(input_path).open('rb')as src,Path(outpath).open('xb')as out,Path(errpath).open('xb')as err:
  try:
   p=subprocess.Popen([str(binary)],stdin=src,stdout=out,stderr=err,preexec_fn=child_limits,start_new_session=own_process_group,close_fds=True,env={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C'})
   try:p.wait(timeout=wall)
   except subprocess.TimeoutExpired:timeout=True
  except Exception as ex:error=repr(ex)
  finally:
   if p is not None:
    try:
     if own_process_group:os.killpg(p.pid,signal.SIGKILL)
     elif p.poll()is None:p.kill()
    except ProcessLookupError:pass
    p.wait()
 after=resource.getrusage(resource.RUSAGE_CHILDREN)
 return {'status':'PROCESS_SUCCESS_UNREVIEWED'if p is not None and p.returncode==0 and not timeout and error is None else'PROCESS_FAILED','returncode':p.returncode if p else None,'process_spawned':p is not None,'timeout':timeout,'error':error,'process_group_cleanup_attempted':p is not None,'child_reaped':p is not None and p.poll()is not None,'cpu_seconds':after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime,'wall_seconds':time.monotonic()-start,'stdout_sha256':sha(outpath),'stderr_sha256':sha(errpath),'resource_caps':{'cpu_seconds':60,'wall_seconds':wall,'AS_bytes':512*1024**2},'input_sha256':sha(input_path),'binary_sha256':sha(binary)}

def run_group(command,outpath,errpath,wall=1500):
 """A supervisor and all non-detached production children share one dedicated outer-owned group."""
 start=time.monotonic();p=None;timeout=False;error=None
 with Path(outpath).open('xb')as out,Path(errpath).open('xb')as err:
  try:
   p=subprocess.Popen(command,stdout=out,stderr=err,start_new_session=True,env={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C','PYTHONDONTWRITEBYTECODE':'1'})
   try:p.wait(timeout=wall)
   except subprocess.TimeoutExpired:timeout=True
  except Exception as ex:error=repr(ex)
  finally:
   if p is not None:
    try:os.killpg(p.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    p.wait()
 return {'returncode':p.returncode if p else None,'timeout':timeout,'error':error,'wall_seconds':time.monotonic()-start,'process_group_cleanup_attempted_before_seal':True}
