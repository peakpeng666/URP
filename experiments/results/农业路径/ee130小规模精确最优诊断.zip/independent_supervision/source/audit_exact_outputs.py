"""Saved exact-output comparison and route audit after both private RAW readbacks; no optimization."""
if not __debug__:raise RuntimeError('Python assertions must remain enabled')
from pathlib import Path
from collections import Counter
import datetime,json,math,resource,signal,zipfile,hashlib
from validation_runtime import sha
from run_validation_once import receipt
R=Path(__file__).resolve().parents[2]
def read(p):return json.loads(Path(p).read_text())
def need(b,msg):
 if not b:raise ValueError(msg)
def inputs(path):
 words=Path(path).read_text().split();need(words[0]=='HKLEX_V1','input magic');n=int(words[1]);mode=words[2];N=n+1;values=list(map(int,words[3:]));need(len(values)==2*N*N,'input cell count')
 mats=[ [values[a*N*N+i*N:a*N*N+(i+1)*N]for i in range(N)]for a in range(2)]
 return n,mode,*mats
def validate_values(entry,main,verification,E,G):
 n=entry['n'];N=n+1;mode=entry['objective'];need(main['status']=='EXACT_ALGORITHM_COMPLETED_UNREVIEWED','author status');need(verification['status']=='INDEPENDENT_EXACT_VALUE_UNREVIEWED','independent status')
 need(main['n']==verification['n_customers']==n and main['objective']==verification['objective']==mode,'solver target identity')
 need(all(type(o[k])is int for o in[main,verification]for k in['primary','secondary','E','G']),'integer output types')
 route=main['route'];need(isinstance(route,list)and len(route)==n+2 and route[0]==route[-1]==0 and all(type(v)is int for v in route)and Counter(route[1:-1])==Counter(range(1,N)),'Hamilton route')
 e=sum(E[a][b]for a,b in zip(route,route[1:]));g=sum(G[a][b]for a,b in zip(route,route[1:]));need((e,g)==(main['E'],main['G'])==(verification['E'],verification['G']),'route and independently optimal values')
 expected=(e,g)if mode=='E_G'else(g,e);need((main['primary'],main['secondary'])==(verification['primary'],verification['secondary'])==expected,'lex objective')
 P,S=(E,G)if mode=='E_G'else(G,E);pmax=max(map(max,P));smax=max(map(max,S));B=N*smax+1;INF=(2**63-1)//4
 need(verification['encoding_base']==B and verification['tour_edges']==N and verification['sentinel']==INF,'independent encoding definition')
 need(N*(pmax*B+smax)<INF and verification['safe_tour_bound']==N*(pmax*B+smax),'independent overflow bound')
 need(verification['encoded_objective']==expected[0]*B+expected[1] and 0<=expected[1]<B,'encoding decode')
 states=n*2**(n-1);transitions=n*(n-1)*2**(n-2)if n>1 else 0
 need(main['valid_states']==verification['states']==states and main['internal_transitions']==verification['extension_transitions']==transitions,'DP counts')
 need(main['states_by_cardinality']==verification['states_by_cardinality']==[0]+[math.comb(n,k)*k for k in range(1,N)],'DP layers')
 need(main['transitions_by_cardinality']==[0]+[math.comb(n,k)*k*(k-1)for k in range(1,N)],'backward transition layers')
 need(verification['outgoing_transitions_by_cardinality']==[0]+[math.comb(n,k)*k*(n-k)for k in range(1,N)],'forward transition layers')
 for o in[main,verification]:need(o['rlimit_cpu']==[60,60]and o['rlimit_as']==[512*1024**2]*2,'effective solver limits')
 return {'E':e,'G':g,'primary':expected[0],'secondary':expected[1],'route':route,'integer_optimum_values_independently_match':True,'main_primary':main['primary'],'main_secondary':main['secondary'],'independent_primary':verification['primary'],'independent_secondary':verification['secondary']}
def ledger(directory,schedule):
 entries=[];malformed=[]
 path=directory/'events.jsonl'
 if path.exists():
  for i,line in enumerate(path.read_text().splitlines(),1):
   try:entries.append(json.loads(line))
   except Exception:malformed.append(i)
 expected={e['call_id']:e for e in schedule};by={c:[]for c in expected};errors=[]
 for event in entries:
  try:
   cid=event['schedule']['call_id'];need(event['schedule']==expected[cid],'nested schedule identity');by[cid].append(event)
  except Exception as ex:errors.append(repr(ex))
 prior=None
 for event in entries:
  if 'utc'in event:
   t=datetime.datetime.fromisoformat(event['utc']);need(prior is None or t>=prior,'event UTC chronological order');prior=t
 return by,{'malformed_event_lines':malformed,'schema_errors':errors,'observed_event_rows':len(entries)}
def archive_local_identity(r,prefix):
 with zipfile.ZipFile(r['download_path'])as z:
  selected=[n for n in z.namelist()if n.startswith(prefix+'/')and not n.endswith('/')]
  for name in selected:need(hashlib.sha256(z.read(name)).hexdigest()==sha(R/name),'raw archived member identity '+name)
  actual={str(p.relative_to(R))for p in(R/prefix).rglob('*')if p.is_file()and '__pycache__'not in p.parts}
  need(set(selected)==actual,'exact raw archive member set '+prefix)
 return len(selected)
def main():
 resource.setrlimit(resource.RLIMIT_CPU,(60,60));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2));signal.alarm(120)
 freeze=sha(R/'freeze/FROZEN_FILES.json');rm=receipt('RAW_MAIN',freeze);rv=receipt('RAW_VERIFICATION',freeze)
 checked={'main':archive_local_identity(rm,'raw'),'verification':archive_local_identity(rv,'independent_supervision/raw')}
 for rel,m in read(R/'freeze/FROZEN_FILES.json')['files'].items():need((R/rel).stat().st_size==m['bytes']and sha(R/rel)==m['sha256'],'frozen '+rel)
 schedule=read(R/'freeze/SCHEDULE.json');need(len(schedule)==16 and len({e['call_id']for e in schedule})==16,'fixed16 schedule')
 mrows=read(R/'raw/ALL_PLANNED_SLOTS.json');vrows=read(R/'independent_supervision/raw/OUTER_ALL_PLANNED_SLOTS.json');need(len(mrows)==len(vrows)==16,'both16 denominators')
 mby={r['schedule']['call_id']:r for r in mrows};vby={r['schedule']['call_id']:r for r in vrows};need(len(mby)==len(vby)==16,'unique slots')
 mlog,ml=ledger(R/'raw',schedule);vlog,vl=ledger(R/'independent_supervision/raw',schedule);audits=[]
 for entry in schedule:
  cid=entry['call_id'];out={'call_id':cid,'instance_id':entry['instance_id'],'objective':entry['objective'],'valid_for_exact_conclusion':False,'errors':[],'main_primary':None,'main_secondary':None,'independent_primary':None,'independent_secondary':None}
  try:
   need(not any([ml['malformed_event_lines'],ml['schema_errors'],vl['malformed_event_lines'],vl['schema_errors']]),'global ledger error')
   m,v=mby[cid],vby[cid];need(m['schedule']==v['schedule']==entry,'result schedule identity')
   for row,events,status in[(m,mlog[cid],'UNREVIEWED_PROCESS_SUCCESS'),(v,vlog[cid],'PROCESS_SUCCESS_UNREVIEWED')]:
    need(row['status']==status and row['process_spawned']is True and row['returncode']==0 and row['child_reaped']is True,'process failed or incomplete')
    need([e['event_kind']for e in events]==['STARTED','FINISHED']and events[1]['result']==row,'start finish exact result correspondence')
    for key in['stdout','stderr']:need(sha(R/row[key])==row[key+'_sha256'],'saved output identity')
   need(sha(R/entry['input'])==entry['input_sha256'],'input hash');n,mode,E,G=inputs(R/entry['input']);need(n==entry['n']and mode==entry['objective'],'input header')
   old=read(R/f"input/old/raw/preprocess/{entry['instance_id']}.json");need(E==old['integer_matrices']['E']and G==old['integer_matrices']['G'],'unchanged original integer matrices')
   value=validate_values(entry,read(R/m['stdout']),read(R/v['stdout']),E,G);out.update(valid_for_exact_conclusion=True,**value)
  except Exception as ex:out['errors'].append(str(ex))
  audits.append(out)
 by={(a['instance_id'],a['objective']):a for a in audits};conditions=[];oldchecks=[]
 for ident in read(R/'freeze/PROTOCOL.json')['conditions']:
  eg,ge=by[ident,'E_G'],by[ident,'G_E'];complete=eg['valid_for_exact_conclusion']and ge['valid_for_exact_conclusion'];c={'instance_id':ident,'valid_for_exact_conclusion':complete}
  if complete:
   e0,gE,g0,eG=eg['E'],eg['G'],ge['G'],ge['E'];need(gE>=g0 and eG>=e0 and((gE==g0)==(eG==e0)),'cross-objective exact consistency');c.update(E_star=e0,G_at_E_star_min=gE,G_star=g0,E_at_G_star_min=eG,integer_proxy_gap=gE-g0)
  d=read(R/f'input/old/raw/preprocess/{ident}.json');E,G=d['integer_matrices']['E'],d['integer_matrices']['G'];n=d['n']
  for seed in range(3):
   for arm in['E','G']:
    cid=f'{ident}_seed{seed}_{arm}';o=read(R/f'input/old/raw/calls/{cid}.stdout');need(len(o['routes'])==1,'old route count');t=o['routes'][0];need(t[0]==t[-1]==0 and Counter(t[1:-1])==Counter(range(1,n+1)),'old visit coverage');e=sum(E[a][b]for a,b in zip(t,t[1:]));g=sum(G[a][b]for a,b in zip(t,t[1:]));need((e if arm=='E'else g)==o['reported_cost'],'old route original cost')
    row={'call_id':cid,'E':e,'G':g,'exact_diagnosis_available':complete}
    if complete:
     gap=(e-e0)if arm=='E'else(g-g0);secondary=(g-gE)if arm=='E'else(e-eG);need(gap>=0 and(gap>0 or secondary>=0),'old route beats exact value');row.update(primary_gap=gap,conditional_secondary_tie_gap=secondary if gap==0 else None,signed_secondary_difference=secondary)
    oldchecks.append(row)
  conditions.append(c)
 count=sum(a['valid_for_exact_conclusion']for a in audits)
 out={'status':'PASS'if count==16 else'AUDIT_COMPLETE_WITH_UNVERIFIED_SLOTS','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'frozen_files_sha256':freeze,'raw_main_archive_sha256':rm['sha256'],'raw_verification_archive_sha256':rv['sha256'],'planned_main_calls':16,'planned_independent_verification_calls':16,'total_planned_real_exact_computations':32,'main_known_spawned':sum(r.get('process_spawned')is True for r in mrows),'verification_known_spawned':sum(r.get('process_spawned')is True for r in vrows),'verified_slots':count,'planned_slots':16,'verified_conditions':sum(c['valid_for_exact_conclusion']for c in conditions),'planned_conditions':8,'rows':audits,'conditions':conditions,'old48_routes':oldchecks,'archive_member_counts':checked,'ledger_review':{'main':ml,'verification':vl},'new_optimization_calls_in_this_postprocessing_script':0,'independent_real_validation_calls_separately_counted':16,'claim':'Independent exact integer-value recomputation agreement and route validation; no formal certificate or continuous-geometry optimality proof.'}
 with(R/'independent_supervision/FINAL_AUDIT.json').open('x')as f:json.dump(out,f,indent=2);f.write('\n')
 print(json.dumps({k:v for k,v in out.items()if k not in['rows','conditions','old48_routes']}))
if __name__=='__main__':main()
