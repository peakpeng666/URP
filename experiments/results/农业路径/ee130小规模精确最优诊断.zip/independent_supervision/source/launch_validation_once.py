"""Outer owner of validation process group. Always reaps/kills it before raw sealing."""
if not __debug__:raise RuntimeError('Python assertions must remain enabled')
from pathlib import Path
import json,os,signal,subprocess,sys,time
from run_validation_once import R,OUT,stamp,read,save,receipt
from validation_runtime import sha,run_group

def prepare_empty_raw(path):
 path=Path(path)
 if path.exists()and any(p.is_file()for p in path.rglob('*')):raise RuntimeError('Validation raw is not empty; do not resume or overwrite')
 path.mkdir(parents=True,exist_ok=True)

def main():
 frozen=sha(R/'freeze/FROZEN_FILES.json');receipt('PREEXEC',frozen);mainraw=receipt('RAW_MAIN',frozen)
 gate=read(R/'provenance/PARENT_VERIFICATION_APPROVAL.json');assert gate['approved']is True and gate['verification_calls']==16 and gate['frozen_files_sha256']==frozen and gate['raw_main_archive_sha256']==mainraw['sha256']
 save(R/'independent_supervision/VALIDATION_LAUNCH_STARTED.json',{'utc':stamp(),'frozen_files_sha256':frozen,'real_validation_solves_planned':16,'total_real_solves_planned':32,'own_process_group':True,'child_solver_does_not_fork_or_spawn':True,'outer_wall_limit':1500})
 prepare_empty_raw(OUT)
 outcome=run_group([sys.executable,'-B',str(Path(__file__).with_name('run_validation_once.py'))],OUT/'supervisor.stdout',OUT/'supervisor.stderr',wall=1500)
 schedule=read(R/'freeze/SCHEDULE.json');records=[];malformed=[]
 if(OUT/'results.jsonl').exists():
  for i,line in enumerate((OUT/'results.jsonl').read_text().splitlines(),1):
   try:records.append(json.loads(line))
   except Exception:malformed.append(i)
 by={r['schedule']['call_id']:r for r in records};slots=[]
 for e in schedule:
  if e['call_id']in by:slots.append(by[e['call_id']])
  else:
   observed=(OUT/'calls'/f"{e['call_id']}.stdout").exists();slots.append({'schedule':e,'status':'UNKNOWN_AFTER_BATCH_FAILURE'if observed else'NOT_STARTED_AFTER_BATCH_FAILURE','process_spawned':'UNKNOWN'if observed else False})
 save(OUT/'OUTER_ALL_PLANNED_SLOTS.json',slots)
 save(OUT/'OUTER_FINISHED.json',{'utc':stamp(),'status':'RAW_VERIFICATION_UNREVIEWED',**outcome,'all_planned_slots':16,'recorded_slots':len(records),'duplicate_call_ids':len(by)!=len(records),'malformed_result_lines':malformed,'no_endpoint_comparison':True})
 save(OUT/'RAW_VERIFICATION_MANIFEST.json',{'utc':stamp(),'stage':'RAW_VERIFICATION','frozen_files_sha256':frozen,'files':{str(q.relative_to(R)):{'bytes':q.stat().st_size,'sha256':sha(q)}for q in sorted(OUT.rglob('*'))if q.is_file()}})
 print(json.dumps({'status':'RAW_VERIFICATION_LOCALLY_SEALED','next':'Unique source/package.py RAW_VERIFICATION, then actual private byte readback before any comparisons','planned_real_validation_solves':16}))
if __name__=='__main__':main()
