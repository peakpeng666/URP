"""Invented sixteen-slot actual batch and outer-process-death checks; no real inputs."""
from pathlib import Path
import sys,json,time,hashlib,datetime
from validation_runtime import run_group,run_one,sha
R=Path(__file__).resolve().parents[2];S=R/'independent_supervision/source';T=R/'independent_supervision/synthetic/chain';T.mkdir(exist_ok=False);(T/'raw').mkdir()
schedule=[]
for i in range(16):
 p=T/f'i{i}.txt';p.write_text('HKLEX_V1 2 '+('E_G'if i%2==0 else'G_E')+'\n0 2 3\n2 0 4\n3 4 0\n0 5 6\n5 0 7\n6 7 0\n')
 schedule.append({'call_id':f'invented{i}','input':p.name,'input_sha256':sha(p),'phase':i%2+1,'event_kind':'intentionally_colliding_schedule_key'})
(T/'schedule.json').write_text(json.dumps(schedule))
script=T/'batch_fixture.py';script.write_text("import sys,json,resource\nfrom pathlib import Path\nsys.path.insert(0,"+repr(str(S))+")\nfrom run_validation_once import run_batch\nresource.setrlimit(resource.RLIMIT_CPU,(20,60));resource.setrlimit(resource.RLIMIT_AS,(256*1024**2,512*1024**2))\nR=Path("+repr(str(T))+")\nrun_batch(json.loads((R/'schedule.json').read_text()),R,R/'raw',Path("+repr(str(S/'scalar_verify'))+"))\n")
outer=run_group([sys.executable,'-B',str(script)],T/'outer.stdout',T/'outer.stderr');assert outer['returncode']==0
rows=[json.loads(x)for x in(T/'raw/results.jsonl').read_text().splitlines()];events=[json.loads(x)for x in(T/'raw/events.jsonl').read_text().splitlines()];assert len(rows)==16 and len(events)==32
for i,(e,r)in enumerate(zip(schedule,rows)):
 assert r['schedule']==e and r['status']=='PROCESS_SUCCESS_UNREVIEWED'
 a,b=events[2*i:2*i+2];assert a['event_kind']=='STARTED'and b['event_kind']=='FINISHED'and a['schedule']==b['schedule']==e and b['result']==r
 ans=json.loads((R/r['stdout']).read_text())if str(R)in r['stdout']else json.loads((T/r['stdout']).read_text())
 assert(ans['E'],ans['G'])==(9,18) and ans['rlimit_cpu']==[60,60] and ans['rlimit_as']==[512*1024**2]*2
faults=[]
for kind in['leader_hard_death','leader_early_exit','outer_timeout']:
 folder=T/kind;folder.mkdir();worker=folder/'leader.py';child=folder/'child.py';child.write_text("import time\nfrom pathlib import Path\ntime.sleep(.8)\nPath("+repr(str(folder/'late.txt'))+").write_text('late')\n")
 tail="os.kill(os.getpid(),signal.SIGKILL)"if kind=='leader_hard_death'else'time.sleep(30)'if kind=='outer_timeout'else'pass'
 worker.write_text("import subprocess,sys,os,signal,time\nfrom pathlib import Path\np=subprocess.Popen([sys.executable,"+repr(str(child))+"],start_new_session=False)\nPath("+repr(str(folder/'child.pid'))+").write_text(str(p.pid))\n"+tail+'\n')
 result=run_group([sys.executable,str(worker)],folder/'outer.stdout',folder/'outer.stderr',wall=.2 if kind=='outer_timeout'else 3)
 time.sleep(.9);pid=int((folder/'child.pid').read_text());proc=Path(f'/proc/{pid}/stat');state=proc.read_text().split()[2]if proc.exists()else'ABSENT';assert state in['ABSENT','Z']and not(folder/'late.txt').exists();faults.append({'kind':kind,'result':result,'child_state':state,'late_write_absent':True})
# Positive large-integer values exercise scalar encoding safely near the sentinel scale.
boundary=[]
for mode in['E_G','G_E']:
 p=T/f'large_{mode}.txt';p.write_text(f'HKLEX_V1 1 {mode}\n0 500000000\n500000000 0\n0 500000000\n500000000 0\n');out=T/f'large_{mode}.stdout';err=T/f'large_{mode}.stderr';rec=run_one(S/'scalar_verify',p,out,err);a=json.loads(out.read_text());assert(a['primary'],a['secondary'])==(1000000000,1000000000);boundary.append(rec)
out={'status':'PASS','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'real_input_solves':0,'invented_chain_solves':16,'invented_large_integer_solves':2,'outer_fault_tests':faults,'event_kind_collision_regression':True,'actual_production_batch_function':'run_validation_once.run_batch','actual_outer_function':'validation_runtime.run_group','same_frozen_binary':sha(S/'scalar_verify'),'source_sha256':{p.name:sha(p)for p in S.glob('*.py')},'chain_outer':outer,'boundary_runs':boundary}
(T/'CHAIN_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k not in['outer_fault_tests','source_sha256','boundary_runs']}))
