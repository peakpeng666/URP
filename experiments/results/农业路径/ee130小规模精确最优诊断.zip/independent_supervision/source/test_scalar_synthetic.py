"""Original invented fixtures only; independent brute-force cross-check and exact resource path."""
from pathlib import Path
import itertools,json,random,datetime,math
from validation_runtime import run_one,sha
R=Path(__file__).resolve().parents[2];O=R/'independent_supervision/synthetic';B=R/'independent_supervision/source/scalar_verify'
def encode(E,G,mode):return '\n'.join([f'HKLEX_V1 {len(E)-1} {mode}']+[' '.join(map(str,r))for M in[E,G]for r in M])+'\n'
def brute(E,G,mode):
 vals=[]
 for p in itertools.permutations(range(1,len(E))):
  t=(0,)+p+(0,);e=sum(E[a][b]for a,b in zip(t,t[1:]));g=sum(G[a][b]for a,b in zip(t,t[1:]));vals.append((e,g)if mode=='E_G'else(g,e))
 return min(vals)
def run(name,text):
 file=O/(name+'.txt');file.write_text(text);out=O/(name+'.stdout');err=O/(name+'.stderr');rec=run_one(B,file,out,err);rec['name']=name
 ans=json.loads(out.read_text())if rec['returncode']==0 else None
 return rec,ans
fixtures=[];rng=random.Random(713982)
for n in[1,2,3,4,5,6,7]:
 for flavor in['zero','ones','random']:
  matrices=[]
  for arm in range(2):
   M=[[0]*(n+1)for _ in range(n+1)]
   for i in range(n+1):
    for j in range(i+1,n+1):M[i][j]=M[j][i]=0 if flavor=='zero'else 1 if flavor=='ones'else rng.randrange(0,23)
   matrices.append(M)
  fixtures.append((f'n{n}_{flavor}',*matrices))
# Primary ties with nonconstant secondary; nonmetric and many zero edges intentionally permitted.
E=[[0 if i==j else 1 for j in range(6)]for i in range(6)];G=[[0]*6 for _ in range(6)]
for i in range(6):
 for j in range(i+1,6):G[i][j]=G[j][i]=(7*i+11*j)%17
fixtures.append(('primary_ties',E,G))
# Largest sparse test: eight customers with deterministic differing matrices.
E=[[0]*9 for _ in range(9)];G=[[0]*9 for _ in range(9)]
for i in range(9):
 for j in range(i+1,9):E[i][j]=E[j][i]=(13*i+5*j)%29;G[i][j]=G[j][i]=(3*i+17*j)%31
fixtures.append(('n8_nonmetric',E,G))
records=[]
for name,E,G in fixtures:
 for mode in['E_G','G_E']:
  rec,a=run(name+'_'+mode,encode(E,G,mode));expect=brute(E,G,mode);assert a and(a['primary'],a['secondary'])==expect
  n=len(E)-1;assert a['states']==n*2**(n-1) and a['extension_transitions']==(n*(n-1)*2**(n-2)if n>1 else 0)
  assert a['encoding_base']==len(E)*max(max(r)for r in(G if mode=='E_G'else E))+1
  assert a['encoded_objective']==a['primary']*a['encoding_base']+a['secondary']and a['secondary']<a['encoding_base']
  rec.update(status='PASS_BRUTEFORCE',expected_pair=list(expect),actual=a);records.append(rec)
# Full production dimensions use invented uniform weights with an algebraically known optimum.
E=[[0 if i==j else 2 for j in range(21)]for i in range(21)];G=[[0 if i==j else 3 for j in range(21)]for i in range(21)]
for mode in['E_G','G_E']:
 rec,a=run('n20_uniform_'+mode,encode(E,G,mode));assert a and(a['E'],a['G'])==(42,63)and a['array_bytes']==20*2**20*8;rec.update(status='PASS_UNIFORM_RESOURCE',actual=a);records.append(rec)
invalid=[('zero_clients','HKLEX_V1 0 E_G\n'),('too_many','HKLEX_V1 21 E_G\n'),('wrong_magic','X 1 E_G\n'),('truncated','HKLEX_V1 1 E_G\n0 1\n1 0\n'),('negative',encode([[0,-1],[-1,0]],[[0,1],[1,0]],'E_G')),('asymmetric',encode([[0,1],[2,0]],[[0,1],[1,0]],'E_G')),('nonzero_diagonal',encode([[1,1],[1,0]],[[0,1],[1,0]],'E_G')),('encoding_overflow',encode([[0,10**18],[10**18,0]],[[0,10**18],[10**18,0]],'E_G')),('extra_input',encode([[0,1],[1,0]],[[0,1],[1,0]],'E_G')+'extra\n')]
for name,text in invalid:
 rec,a=run('invalid_'+name,text);assert rec['returncode']==2 and a is None;rec['status']='PASS_REJECTION';records.append(rec)
out={'status':'PASS','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'real_input_solver_calls':0,'invented_valid_solver_calls':2*len(fixtures)+2,'invalid_input_rejections':len(invalid),'source_sha256':sha(Path(__file__).with_name('scalar_verify.cpp')),'binary_sha256':sha(B),'runtime_source_sha256':sha(Path(__file__).with_name('validation_runtime.py')),'records':records}
with(O/'SYNTHETIC_RESULTS.json').open('x')as f:json.dump(out,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in out.items()if k!='records'}))
if __name__!='__main__':raise RuntimeError('Do not import this test script')
