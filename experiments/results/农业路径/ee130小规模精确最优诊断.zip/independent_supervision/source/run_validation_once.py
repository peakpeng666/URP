"""Sixteen explicitly budgeted real validation DP solves, after main RAW readback; no endpoint comparison here."""
if not __debug__:raise RuntimeError('Python assertions must remain enabled')
from pathlib import Path
import datetime,json,os,resource,signal,sys,time,zipfile
from validation_runtime import run_one,sha
R=Path(__file__).resolve().parents[2];OUT=R/'independent_supervision/raw'
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def read(p):return json.loads(Path(p).read_text())
def save(p,x):
 with Path(p).open('x')as f:json.dump(x,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
def append(p,x):
 with Path(p).open('a')as f:f.write(json.dumps(x,separators=(',',':'))+'\n');f.flush();os.fsync(f.fileno())
def receipt(stage,freeze):
 r=read(R/f'provenance/{stage}_DRIVE_RECEIPT.json')
 assert r['stage']==stage and not r.get('synthetic_only')
 assert all(r[k]is True for k in ['verified','owner_only','remote_readback_sha256_verified','download_byte_identical'])and r['shared']is False
 assert r['frozen_files_sha256']==freeze and sha(r['source'])==sha(r['download_path'])==r['sha256']==r['download_sha256']
 return r

def run_batch(schedule,root,outdir,binary,batch_wall=1500):
 (outdir/'calls').mkdir(exist_ok=False);started=time.monotonic();rows=[]
 for entry in schedule:
  left=batch_wall-(time.monotonic()-started);cid=entry['call_id']
  if left<=0:row={'schedule':entry,'status':'NOT_STARTED_BATCH_WALL_BUDGET','process_spawned':False};rows.append(row);append(outdir/'results.jsonl',row);continue
  input_path=root/entry['input'];assert sha(input_path)==entry['input_sha256']
  append(outdir/'events.jsonl',{'event_kind':'STARTED','utc':stamp(),'schedule':entry})
  outpath=outdir/'calls'/f'{cid}.stdout';errpath=outdir/'calls'/f'{cid}.stderr'
  try:result=run_one(binary,input_path,outpath,errpath,wall=min(90,left),own_process_group=False)
  except Exception as ex:result={'status':'LIFECYCLE_EXCEPTION','process_spawned':'UNKNOWN','error':repr(ex)}
  row={'schedule':entry,**result,'stdout':str(outpath.relative_to(root)),'stderr':str(errpath.relative_to(root))};rows.append(row)
  append(outdir/'results.jsonl',row);append(outdir/'events.jsonl',{'event_kind':'FINISHED','utc':stamp(),'schedule':entry,'result':row})
 save(outdir/'ALL_PLANNED_SLOTS.json',rows)
 save(outdir/'FINISHED.json',{'utc':stamp(),'wall_seconds':time.monotonic()-started,'planned_calls':16,'retained_slots':len(rows),'known_spawned_calls':sum(r.get('process_spawned')is True for r in rows),'unknown_spawned_slots':sum(r.get('process_spawned')=='UNKNOWN'for r in rows),'status':'RAW_VERIFICATION_UNREVIEWED','no_endpoint_comparison':True})
 return rows

def main():
 resource.setrlimit(resource.RLIMIT_CPU,(20,60));resource.setrlimit(resource.RLIMIT_AS,(256*1024**2,512*1024**2))
 frozen=sha(R/'freeze/FROZEN_FILES.json')
 for rel,m in read(R/'freeze/FROZEN_FILES.json')['files'].items():assert (R/rel).stat().st_size==m['bytes']and sha(R/rel)==m['sha256']
 pre=receipt('PREEXEC',frozen);mainraw=receipt('RAW_MAIN',frozen)
 approval=read(R/'provenance/PARENT_VERIFICATION_APPROVAL.json')
 assert approval['approved']is True and approval['frozen_files_sha256']==frozen and approval['raw_main_archive_sha256']==mainraw['sha256']and approval['verification_calls']==16
 schedule=read(R/'freeze/SCHEDULE.json');assert len(schedule)==16 and len({e['call_id']for e in schedule})==16
 assert read(R/'freeze/INDEPENDENT_PRECHECK.json')['status']=='PASS'
 binary=R/'independent_supervision/source/scalar_verify'
 save(OUT/'STARTED.json',{'utc':stamp(),'frozen_files_sha256':frozen,'planned_independent_real_validation_solves':16,'planned_author_real_solves':16,'planned_total_real_solves':32,'raw_main_archive_sha256':mainraw['sha256'],'preexec_archive_sha256':pre['sha256'],'approval_sha256':sha(R/'provenance/PARENT_VERIFICATION_APPROVAL.json'),'max_concurrent_children':1,'no_retries':True,'parent_limits':{'cpu_soft':20,'cpu_hard':60,'AS_soft':256*1024**2,'AS_hard':512*1024**2}})
 rows=run_batch(schedule,R,OUT,binary)
 print(json.dumps({'status':'VALIDATION_BATCH_STOPPED','retained_slots':len(rows),'planned_calls':16,'no_endpoint_comparison':True}))
if __name__=='__main__':main()
