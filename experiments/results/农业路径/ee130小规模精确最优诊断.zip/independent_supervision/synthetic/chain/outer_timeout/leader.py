import subprocess,sys,os,signal,time
from pathlib import Path
p=subprocess.Popen([sys.executable,'/workspace/shared/ee130_exact_small_field_20261009/independent_supervision/synthetic/chain/outer_timeout/child.py'],start_new_session=False)
Path('/workspace/shared/ee130_exact_small_field_20261009/independent_supervision/synthetic/chain/outer_timeout/child.pid').write_text(str(p.pid))
time.sleep(30)
