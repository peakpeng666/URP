import time
from pathlib import Path
time.sleep(.8)
Path('/workspace/shared/ee130_exact_small_field_20261009/independent_supervision/synthetic/chain/outer_timeout/late.txt').write_text('late')
