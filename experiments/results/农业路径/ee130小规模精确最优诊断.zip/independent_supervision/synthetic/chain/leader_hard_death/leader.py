import subprocess,sys,os,signal,time
from pathlib import Path
p=subprocess.Popen([sys.executable,'/workspace/shared/ee130_exact_small_field_20261009/independent_supervision/synthetic/chain/leader_hard_death/child.py'],start_new_session=False)
Path('/workspace/shared/ee130_exact_small_field_20261009/independent_supervision/synthetic/chain/leader_hard_death/child.pid').write_text(str(p.pid))
os.kill(os.getpid(),signal.SIGKILL)
