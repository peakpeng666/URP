import sys,json,resource
from pathlib import Path
sys.path.insert(0,'/workspace/shared/ee130_exact_small_field_20261009/independent_supervision/source')
from run_validation_once import run_batch
resource.setrlimit(resource.RLIMIT_CPU,(20,60));resource.setrlimit(resource.RLIMIT_AS,(256*1024**2,512*1024**2))
R=Path('/workspace/shared/ee130_exact_small_field_20261009/independent_supervision/synthetic/chain')
run_batch(json.loads((R/'schedule.json').read_text()),R,R/'raw',Path('/workspace/shared/ee130_exact_small_field_20261009/independent_supervision/source/scalar_verify'))
