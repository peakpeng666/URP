"""Bounded postprocessing, no optimizers. Writes remain failure-preserving, no overwrite."""
import os,signal,subprocess,sys,time
from common import ROOT,save,utc
from gates import report_ready

def main():
    digest=report_ready();save(ROOT/'provenance/AUTHOR_REPORT_STARTED.json',{'utc':utc(),'frozen_files_sha256':digest,'cpu_seconds':60,'as_bytes':536870912,'wall_seconds':120,'optimization_calls':0})
    start=time.monotonic();p=None;timedout=False;error=None
    with(ROOT/'provenance/author_report.stdout').open('xb')as out,(ROOT/'provenance/author_report.stderr').open('xb')as err:
        try:
            p=subprocess.Popen([sys.executable,str(ROOT/'source/report.py')],stdout=out,stderr=err,start_new_session=True,env={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C'})
            try:p.wait(timeout=120)
            except subprocess.TimeoutExpired:timedout=True
        except Exception as exc:error=repr(exc)
        finally:
            if p is not None:
                try:os.killpg(p.pid,signal.SIGKILL)
                except ProcessLookupError:pass
                p.wait()
    result={'utc':utc(),'status':'PASS'if p is not None and p.returncode==0 and not timedout and error is None else'FAIL_OR_UNKNOWN','returncode':p.returncode if p else None,'timed_out':timedout,'error':error,'wall_seconds':time.monotonic()-start,'optimization_calls':0}
    save(ROOT/'provenance/AUTHOR_REPORT_FINISHED.json',result);print(result)
if __name__=='__main__':main()
