"""Tests that author success cannot silently become independent agreement."""
import copy
from report import audit_rows,verified_slot
from common import ROOT,save

def main():
    schedule=[{'call_id':str(i)}for i in range(16)]
    rows=[{'call_id':str(i),'valid_for_exact_conclusion':True,'main_primary':10,'main_secondary':20,'independent_primary':10,'independent_secondary':20,'primary':10,'secondary':20,'E':10,'G':20,'route':[0,1,0]}for i in range(16)]
    audit={'status':'PASS','frozen_files_sha256':'synthetic_hash','rows':rows}
    by=audit_rows(audit,schedule,'synthetic_hash');assert all(verified_slot(r,{'main_primary':10,'main_secondary':20,'independent_primary':10,'independent_secondary':20,'primary':10,'secondary':20,'E':10,'G':20,'route':[0,1,0]})for r in by.values())
    partial=copy.deepcopy(audit);partial['status']='AUDIT_COMPLETE_WITH_UNVERIFIED_SLOTS';partial['rows'][4]['valid_for_exact_conclusion']=False
    by=audit_rows(partial,schedule,'synthetic_hash');assert sum(verified_slot(r,{'main_primary':10,'main_secondary':20,'independent_primary':10,'independent_secondary':20,'primary':10,'secondary':20,'E':10,'G':20,'route':[0,1,0]})for r in by.values())==15
    failures=[]
    for case in('wrong_freeze','duplicate','missing','pass_missing','wrong_independent_value'):
        a=copy.deepcopy(audit)
        if case=='wrong_freeze':a['frozen_files_sha256']='different'
        if case=='duplicate':a['rows'][0]['call_id']='1'
        if case=='missing':a['rows'].pop()
        if case=='pass_missing':a['rows'][0]['valid_for_exact_conclusion']=False
        if case=='wrong_independent_value':a['rows'][0]['primary']=11
        try:
            b=audit_rows(a,schedule,'synthetic_hash')
            for r in b.values():verified_slot(r,{'main_primary':10,'main_secondary':20,'independent_primary':10,'independent_secondary':20,'primary':10,'secondary':20,'E':10,'G':20,'route':[0,1,0]})
            raise AssertionError('Bad audit admitted')
        except RuntimeError as e:failures.append({'case':case,'blocked':str(e)})
    save(ROOT/'selftests/AUDIT_BINDING_SCHEMA_FINAL.json',{'status':'PASS','synthetic_optimizer_calls':0,'real_optimizer_calls':0,'valid_and_partial_cases':2,'failures_blocked':failures})
    print('PASS author/independent per-slot evidence binding')
if __name__=='__main__':main()
