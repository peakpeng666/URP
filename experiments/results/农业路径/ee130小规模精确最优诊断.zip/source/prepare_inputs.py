"""One-time read-only extraction; never optimizes real inputs or writes old evidence."""
import json,pathlib,platform,shutil,subprocess,sys
from decimal import Decimal,ROUND_HALF_UP
from common import ROOT,OLD,read,save,sha,utc,inventory,verify_map
from test_synthetic import write

def main():
    if any((ROOT/'input').iterdir()):raise RuntimeError('Input extraction already attempted')
    final=read(OLD/'provenance/FINAL_REVIEWED_DRIVE_RECEIPT.json')
    assert final['verified'] and final['owner_only'] and final['download_byte_identical'] and final['remote_readback_sha256_verified']
    verify_map(OLD,read(OLD/'provenance/FINAL_CONTENT_MANIFEST.json')['files'])
    oldfiles=[p for p in OLD.rglob('*')if p.is_file()]
    save(ROOT/'freeze/OLD_FILES_BEFORE.json',inventory(OLD,oldfiles))
    dest=ROOT/'input/old';dest.mkdir()
    copied=[]
    def copy(rel):
        src=OLD/rel;out=dest/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,out);assert sha(src)==sha(out);copied.append({'old_path':str(src),'copied_path':str(out.relative_to(ROOT)),'sha256':sha(src),'bytes':src.stat().st_size})
    conditions=[f'C_n{n:02d}_s20261008{s}'for n in(8,20)for s in(2301,2302,2303,2304)]
    items=[];schedule=[]
    for ix,ident in enumerate(conditions):
        for rel in (f'input/{ident}_input.json',f'input/{ident}_graph.json',f'raw/preprocess/{ident}.json'):copy(rel)
        d=read(dest/f'raw/preprocess/{ident}.json');g=read(dest/f'input/{ident}_graph.json');n=d['n'];N=n+1
        assert d['instance_id']==ident and d['status']=='PASS_PREPROCESS'and d['K']==1 and d['capacity']==n and d['demands']==[0]+[1]*n
        assert d['interior_service_graph_nodes']==0 and all(c['exact_safe']for c in d['unique_path_segments'])and all(c['exact_safe']for c in d['endpoint_checks'])
        base=min(g['service_node_ids']);assert g['service_node_ids']==list(range(base,base+N))
        assert d['coordinates']==g['nodes'][base:]
        for arm in('E','G'):
            M=d['integer_matrices'][arm];U=d['unrounded_matrices'][arm]
            assert len(M)==N and all(len(r)==N for r in M)
            for i in range(N):
                for j in range(N):
                    assert type(M[i][j])is int and M[i][j]>=0 and M[i][j]==M[j][i]
                    assert M[i][j]==int((Decimal(str(U[i][j]))*1000).to_integral_value(rounding=ROUND_HALF_UP))
                    if i==j:assert M[i][j]==0
        for i in range(N):
            for j in range(N):
                p=d['canonical_paths'][i][j];assert p[0]==base+i and p[-1]==base+j
                assert all(0<=u<base for u in p[1:-1])
                if i<j:assert p==g['paths'][i][j]and d['unrounded_matrices']['G'][i][j]==g['distance_matrix'][i][j]
                if i>j:assert p==d['canonical_paths'][j][i][::-1]
        E,G=(d['integer_matrices'][a]for a in('E','G'))
        for arm in('E_G','G_E'):
            cid=ident+'_'+arm;rel='input/'+cid+'.txt';write(ROOT/rel,n,E,G,arm)
            schedule.append({'call_id':cid,'instance_id':ident,'n':n,'objective':arm,'input':rel,'input_sha256':sha(ROOT/rel),'ordinal':len(schedule),'phase':'EXACT_MAIN'})
        for seed in(0,1,2):
            for arm in('E','G'):
                rel=f'raw/calls/{ident}_seed{seed}_{arm}.stdout';copy(rel)
                old=read(dest/rel);assert old['model_distance_matrix']==d['integer_matrices'][arm]
                assert old['model_parameters']['coordinates']==d['coordinates']
        items.append({'instance_id':ident,'n':n,'max_edge':max(max(row)for M in(E,G)for row in M),'main_calls':2})
    for rel in('freeze/PROTOCOL.json','freeze/SCHEDULE.json','provenance/FINAL_REVIEWED_DRIVE_RECEIPT.json','provenance/FINAL_CONTENT_MANIFEST.json','raw/results.jsonl'):copy(rel)
    save(ROOT/'freeze/INPUT_IDENTITY.json',{'utc':utc(),'status':'PASS_READONLY_INPUT_EXTRACTION','items':items,'copied':copied,'matrix_changes':0,'production_optimizer_calls':0,'old_saved_routes':48})
    save(ROOT/'freeze/SCHEDULE.json',schedule)
    command=['/usr/bin/g++','-O2','-std=c++17','-Wall','-Wextra','-Werror','-pedantic',str(ROOT/'source/hklex.cpp'),'-o',str(ROOT/'source/hklex')]
    compiler=pathlib.Path('/usr/bin/g++').resolve()
    save(ROOT/'environment/BUILD.json',{'utc':utc(),'command':command,'compiler_path':str(compiler),'compiler_sha256':sha(compiler),'compiler_version':subprocess.check_output(['/usr/bin/g++','--version'],text=True),'compiler_target':subprocess.check_output(['/usr/bin/g++','-dumpmachine'],text=True).strip(),'binary_sha256':sha(ROOT/'source/hklex'),'source_sha256':sha(ROOT/'source/hklex.cpp'),'binary_dependencies':subprocess.check_output(['ldd',str(ROOT/'source/hklex')],text=True),'python':sys.version,'platform':platform.platform(),'new_installs':False,'foreign_source_dependencies':False})
    print(json.dumps({'conditions':len(items),'main_calls':len(schedule),'copied_files':len(copied),'old_snapshot_files':len(oldfiles)}))
if __name__=='__main__':main()
