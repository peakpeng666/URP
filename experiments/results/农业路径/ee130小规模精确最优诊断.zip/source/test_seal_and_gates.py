import json,pathlib,stat,sys
from common import ROOT,read,save,sha,verify_map
from batch import execute
from seal_raw import seal
from gates import receipt,execution_ready,report_ready

def main():
    suffix=sys.argv[1]if len(sys.argv)>1 else'01'
    dest=ROOT/('selftests/seal_gates_'+suffix);dest.mkdir(exist_ok=False)
    # Replay and seal the actual positive synthetic schedule using production code.
    previous=ROOT/('selftests/pipeline_'+suffix);schedule=read(previous/'SCHEDULE.json')
    slots=seal(ROOT,previous/'raw',schedule,'SYNTHETIC_NOT_A_REAL_FREEZE',{'test_only':True})
    verify_map(ROOT,read(previous/'raw/RAW_MAIN_MANIFEST.json')['files']);assert len(slots)==16
    # The first child times out; all remaining slots must be explicitly retained.
    worker=dest/'sleep_worker.py';worker.write_text('#!/usr/bin/python3\nimport time\ntime.sleep(60)\n');worker.chmod(worker.stat().st_mode|stat.S_IXUSR)
    rows=execute(schedule,ROOT,dest/'raw_timeout',worker,budget_seconds=.05)
    assert rows[0]['status']=='WALL_TIMEOUT'and rows[0]['child_reaped']
    assert len(rows)==16 and all(r['status']=='NOT_STARTED_BATCH_BUDGET'for r in rows[1:])
    fail_slots=seal(ROOT,dest/'raw_timeout',schedule,'SYNTHETIC_NOT_A_REAL_FREEZE',{'test_only':True,'timed_out':True})
    verify_map(ROOT,read(dest/'raw_timeout/RAW_MAIN_MANIFEST.json')['files']);assert len(fail_slots)==16
    # Simulate interrupted log write without dropping any scheduled slot.
    broken=dest/'raw_interrupted';broken.mkdir();(broken/'calls').mkdir();(broken/'calls'/f"{schedule[0]['call_id']}.stdout").write_text('{partial')
    (broken/'results.jsonl').write_text('{truncated')
    unknown=seal(ROOT,broken,schedule,'SYNTHETIC_NOT_A_REAL_FREEZE',{'test_only':True})
    assert len(unknown)==16 and unknown[0]['status']=='UNKNOWN_AFTER_SUPERVISOR_FAILURE'and all(r['status']=='NOT_STARTED_SUPERVISOR_FAILURE'for r in unknown[1:])
    gates=[]
    for name,fn in [('execution_without_receipts',execution_ready),('report_without_receipts',report_ready)]:
        try:fn();raise AssertionError('Gate unexpectedly open')
        except (FileNotFoundError,RuntimeError)as exc:gates.append({'case':name,'blocked':True,'exception':str(exc)})
    fixture=dest/'synthetic_not_a_receipt.json';save(fixture,{'synthetic_only':True,'stage':'PREEXEC'})
    try:receipt(fixture,'PREEXEC');raise AssertionError('Synthetic receipt accepted')
    except RuntimeError as exc:assert str(exc)=='SYNTHETIC_RECEIPT_NOT_AUTHORIZATION'
    save(dest/'REPORT.json',{'status':'PASS','production_optimizations':0,'new_synthetic_optimizer_calls':0,'synthetic_timeout_worker_calls':1,'complete_denominator':16,'positive_chain_raw_seal':'PASS','timedout_chain_raw_seal':'PASS','interrupted_chain_raw_seal':'PASS','gates':gates,'synthetic_receipt_rejected':True})
    print('PASS seal/gates; real 0')
if __name__=='__main__':main()
