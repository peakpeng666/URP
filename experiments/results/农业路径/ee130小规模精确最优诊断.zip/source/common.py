import datetime,hashlib,json,pathlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
OLD=pathlib.Path('/workspace/shared/ee130_distance_proxy_comparison_20261009')
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):
    h=hashlib.sha256()
    with open(p,'rb')as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()
def read(p):return json.loads(pathlib.Path(p).read_text())
def save(p,value):
    p=pathlib.Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x')as f:json.dump(value,f,indent=2,ensure_ascii=False);f.write('\n')
def append(p,value):
    import os
    with pathlib.Path(p).open('a')as f:json.dump(value,f,ensure_ascii=False);f.write('\n');f.flush();os.fsync(f.fileno())
def verify_map(base,manifest):
    for rel,row in manifest.items():
        p=base/rel
        if not p.is_file()or p.stat().st_size!=row['bytes']or sha(p)!=row['sha256']:raise RuntimeError('HASH_IDENTITY_FAILURE:'+str(p))
def inventory(base,files):return {str(p.relative_to(base)):{'bytes':p.stat().st_size,'sha256':sha(p)}for p in sorted(files)}
