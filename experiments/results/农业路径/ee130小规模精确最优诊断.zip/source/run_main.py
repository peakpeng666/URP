"""Only called by launch_once after external gates. No retry or alternate algorithm."""
if not __debug__:raise RuntimeError('Python assertions must remain enabled')
import resource
from common import ROOT,read
from batch import execute
if __name__=='__main__':
    resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912))
    resource.setrlimit(resource.RLIMIT_CPU,(60,60))
    execute(read(ROOT/'freeze/SCHEDULE.json'),ROOT,ROOT/'raw',ROOT/'source/hklex')
