"""Post-RAW-readback descriptive diagnostics; no optimization and no DP replay."""
if not __debug__:raise RuntimeError('Python assertions must remain enabled')
import csv,json,resource,time
from decimal import Decimal,localcontext
from common import ROOT,read,save,sha,utc
from gates import report_ready

def pair_cost(d,r):
    n=d['n'];assert r[0]==r[-1]==0 and sorted(r[1:-1])==list(range(1,n+1))
    return {a:sum(d['integer_matrices'][a][u][v]for u,v in zip(r,r[1:]))for a in('E','G')}

def geometry(d,g,r):
    with localcontext()as c:
        c.prec=80;actual=Decimal(0);unrounded=Decimal(0);nodes=[]
        base=min(g['service_node_ids'])
        for u,v in zip(r,r[1:]):
            p=d['canonical_paths'][u][v];assert p[0]==base+u and p[-1]==base+v and all(x<base for x in p[1:-1])
            nodes.extend(p if not nodes else p[1:]);unrounded+=Decimal(str(d['unrounded_matrices']['G'][u][v]))
            for a,b in zip(p,p[1:]):
                aa,bb=g['nodes'][a],g['nodes'][b];dx=Decimal(str(aa[0]))-Decimal(str(bb[0]));dy=Decimal(str(aa[1]))-Decimal(str(bb[1]));actual+=(dx*dx+dy*dy).sqrt()
        residual=actual-unrounded;assert abs(residual)<=Decimal(d['n']+1)*Decimal('1e-8')
        q=pair_cost(d,r)['G'];qerr=Decimal(q)/1000-unrounded
        assert abs(qerr)<=Decimal(d['n']+1)*Decimal('0.0005')
        return {'mapped_polyline_length_m_decimal80':str(actual),'saved_unrounded_G_sum_m_decimal80':str(unrounded),'actual_minus_saved_m_decimal80':str(residual),'integer_G_over1000_minus_saved_m_decimal80':str(qerr),'route_quantization_bound_m':str(Decimal(d['n']+1)*Decimal('0.0005')),'polyline_nodes':nodes,'terminal_semantics_verified':True,'edge_safety_evidence':'Inherited unchanged frozen per-pair paths and exact serialized-coordinate segment checks; route concatenation changes no segment.'}

def diagnose(cost,arm,e0,gE,g0,eG):
    main_gap=cost[arm]-(e0 if arm=='E'else g0)
    if main_gap<0:raise RuntimeError('OLD_ROUTE_BEATS_REPORTED_EXACT_VALUE')
    secondary_difference=cost['G']-gE if arm=='E'else cost['E']-eG
    if main_gap==0 and secondary_difference<0:raise RuntimeError('OLD_ROUTE_BEATS_REPORTED_LEX_VALUE')
    return {'exact_diagnosis':'PRIMARY_INTEGER_OPTIMAL'if main_gap==0 else'PRIMARY_SEARCH_DID_NOT_REACH_INTEGER_OPTIMUM','primary_gap_mm':main_gap,'conditional_secondary_tie_gap_mm':secondary_difference if main_gap==0 else None,'conditional_secondary_difference_mm':secondary_difference,'integer_G_gap_from_G_star_mm':cost['G']-g0}


def audit_rows(audit,schedule,digest):
    if audit.get('frozen_files_sha256')!=digest:raise RuntimeError('AUDIT_FREEZE_MISMATCH')
    rows=audit['rows'];by={r['call_id']:r for r in rows}
    if len(rows)!=16 or len(by)!=16 or set(by)!={s['call_id']for s in schedule}:raise RuntimeError('AUDIT_SLOT_SET_MISMATCH')
    if audit['status']=='PASS'and not all(r.get('valid_for_exact_conclusion')is True for r in rows):raise RuntimeError('AUDIT_PASS_INCOMPLETE')
    return by

def verified_slot(row,output):
    if row.get('valid_for_exact_conclusion')is not True:return False
    expected=(output['primary'],output['secondary'])
    if(row.get('main_primary'),row.get('main_secondary'))!=expected or(row.get('independent_primary'),row.get('independent_secondary'))!=expected:raise RuntimeError('AUDIT_MAIN_INDEPENDENT_VALUE_BINDING_MISMATCH')
    if(row.get('primary'),row.get('secondary'))!=expected or(row.get('E'),row.get('G'),row.get('route'))!=(output['E'],output['G'],output['route']):raise RuntimeError('AUDIT_VALUE_OR_ROUTE_BINDING_MISMATCH')
    return True


def main():
    resource.setrlimit(resource.RLIMIT_CPU,(60,60));resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912))
    report_wall_start=time.monotonic();report_cpu_start=time.process_time()
    digest=report_ready();schedule=read(ROOT/'freeze/SCHEDULE.json');slots=read(ROOT/'raw/ALL_PLANNED_SLOTS.json');by={x['schedule']['call_id']:x for x in slots};conditions=read(ROOT/'freeze/PROTOCOL.json')['conditions'];rows=[];oldrows=[];outputs=[]
    audit=read(ROOT/'independent_supervision/FINAL_AUDIT.json');audited=audit_rows(audit,schedule,digest)
    for ident in conditions:
        d=read(ROOT/f'input/old/raw/preprocess/{ident}.json');g=read(ROOT/f'input/old/input/{ident}_graph.json');r={'instance_id':ident,'n':d['n'],'status':'UNKNOWN_INCOMPLETE_EXACT_RESULTS'};sol={}
        for arm in('E_G','G_E'):
            cid=ident+'_'+arm;s=by[cid]
            if s['status']=='UNREVIEWED_PROCESS_SUCCESS'and audited[cid].get('valid_for_exact_conclusion')is True:
                p=ROOT/s['stdout'];assert sha(p)==s['stdout_sha256'];o=read(p);assert verified_slot(audited[cid],o);cost=pair_cost(d,o['route']);assert cost=={'E':o['E'],'G':o['G']};assert(o['primary'],o['secondary'])==((o['E'],o['G'])if arm=='E_G'else(o['G'],o['E']))
                assert o['status']=='EXACT_ALGORITHM_COMPLETED_UNREVIEWED';sol[arm]=o
                outputs.append({'call_id':cid,**o,'geometry':geometry(d,g,o['route'])})
        if len(sol)==2:
            eg,ge=sol['E_G'],sol['G_E'];e0,gE,g0,eG=eg['E'],eg['G'],ge['G'],ge['E'];assert gE>=g0 and eG>=e0
            assert (gE==g0)==(eG==e0)
            r.update(status='COMPLETE_INDEPENDENT_VALUE_MATCH',E_star=e0,G_among_E_star_min=gE,G_star=g0,E_among_G_star_min=eG,integer_proxy_gap_mm=gE-g0,reverse_integer_gap_mm=eG-e0,common_integer_optimum_exists=gE==g0)
            with localcontext()as c:
                c.prec=80
                lE=geometry(d,g,eg['route']);lG=geometry(d,g,ge['route']);r['two_lex_routes_actual_length_difference_m_decimal80']=str(Decimal(lE['mapped_polyline_length_m_decimal80'])-Decimal(lG['mapped_polyline_length_m_decimal80']))
                r['difference_quantization_plus_numeric_bound_m']=str(Decimal(d['n']+1)*(Decimal('.001')+Decimal('.00000002')))
        for seed in(0,1,2):
            for arm in('E','G'):
                cid=f'{ident}_seed{seed}_{arm}';old=read(ROOT/f'input/old/raw/calls/{cid}.stdout');assert len(old['routes'])==1;route=old['routes'][0];cost=pair_cost(d,route);assert cost[arm]==old['reported_cost'];x={'call_id':cid,'instance_id':ident,'seed':seed,'arm':arm,'route':route,'E':cost['E'],'G':cost['G'],'exact_diagnosis':'UNKNOWN_EXACT_SLOT_FAILURE'}
                if len(sol)==2:
                    x.update(diagnose(cost,arm,e0,gE,g0,eG))
                oldrows.append(x)
        rows.append(r)
    completed=[r for r in rows if r['status']=='COMPLETE_INDEPENDENT_VALUE_MATCH'];validold=[r for r in oldrows if 'primary_gap_mm'in r]
    summary={'utc':utc(),'resource_limits':{'cpu_seconds':60,'as_bytes':536870912,'external_wall_seconds':120},'report_cpu_seconds_before_serialization':time.process_time()-report_cpu_start,'report_wall_seconds_before_serialization':time.monotonic()-report_wall_start,'report_maxrss_kib_before_serialization':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'frozen_files_sha256':digest,'independent_audit_status':audit['status'],'main_known_spawned_calls':sum(x.get('process_spawned')is True for x in slots),'main_unknown_spawned_slots':sum(x.get('process_spawned')=='UNKNOWN'for x in slots),'independently_verified_main_slots':sum(x.get('valid_for_exact_conclusion')is True for x in audited.values()),'planned_conditions':8,'complete_conditions':len(completed),'planned_real_main_calls':16,'planned_real_independent_verification_calls':16,'total_planned_real_exact_computations':32,'old_saved_routes':48,'old_routes_diagnosed':len(validold),'old_primary_suboptimal_count':sum(r['primary_gap_mm']>0 for r in validold),'old_primary_optimal_secondary_tie_worse_count':sum(r['conditional_secondary_tie_gap_mm']is not None and r['conditional_secondary_tie_gap_mm']>0 for r in validold),'conditions_with_strict_integer_proxy_gap':sum(r['integer_proxy_gap_mm']>0 for r in completed),'all_eight_summary_valid':len(completed)==8,'scope':'Frozen 1mm integer matrices only; n40 excluded; not continuous geometry or vehicle optimality; no formal DP certificate retained.','conditions':rows}
    save(ROOT/'reports/SUMMARY.json',summary);save(ROOT/'reports/ALL_EXACT_ROUTES.json',outputs);save(ROOT/'reports/OLD_48_ROUTE_COMPARISON.json',oldrows)
    with(ROOT/'reports/CONDITIONS.csv').open('x',newline='')as f:
        fields=sorted(set(k for row in rows for k in row));w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
    lines=['小实例精确诊断（仅冻结整数模型）','',f'计划8条件，完整核验{len(completed)}/8；作者16次＋独立16次验证求优，合计计划32次真实DP。',f'旧48路线中可诊断{len(validold)}条；主目标未达整数最优{summary["old_primary_suboptimal_count"]}条；主目标已最优但副目标并列选择更差{summary["old_primary_optimal_secondary_tie_worse_count"]}条。','']
    for r in rows:
        if r['status']=='COMPLETE_INDEPENDENT_VALUE_MATCH':lines.append(f'{r["instance_id"]}: E*={r["E_star"]}, min G|E*={r["G_among_E_star_min"]}, G*={r["G_star"]}; Δ={r["integer_proxy_gap_mm"]}毫米整数成本。')
        else:lines.append(r['instance_id']+': UNKNOWN，精确槽缺失或失败。')
    lines+=['','Δ=min{G:E=E*}−G*；正值意味着即使选取G最有利的E整数最优路线，仍存在G整数代价。零值意味着存在共同整数最优路线，不意味着全部E最优路线都G最优。旧E非最优时，副目标差不称并列差或纯代理差。','最优性范围仅原单车Hamilton回路及冻结1毫米矩阵；原限制图terminal语义和任务点未改变。独立求优值一致、路线复算及源码/合成穷举核验支持计算结果，但未保留完整DP表，不提供形式化最优性证书。','n40全部排除，不外推；8条件来自单田块四条相关流的嵌套前缀，不能当8个独立田块作显著性结论。物理折线路长另以80位Decimal重算，仅为两个词典序代表路线的长度；不是连续几何最优。','每路线量化界(n+1)*0.0005m，保存G路径距离残差界(n+1)*1e-8m；两路线差分应合并两项界，不把毫米整数差直接写作连续代理损失。']
    (ROOT/'reports/REPORT_ZH.txt').write_text('\n'.join(lines)+'\n');print(json.dumps({k:v for k,v in summary.items()if k!='conditions'},ensure_ascii=False))
if __name__=='__main__':main()
