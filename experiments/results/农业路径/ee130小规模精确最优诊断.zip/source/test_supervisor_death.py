"""Hard-kill supervisor while isolated worker and forked descendant are live."""
import json,os,pathlib,signal,stat,subprocess,sys,time
from common import ROOT,save,sha,read,verify_map
from process_groups import cleanup_registered,identity,members
from seal_raw import seal

def main():
    dest=ROOT/'selftests/supervisor_death_01';dest.mkdir(exist_ok=False)
    worker=dest/'fork_sleep.py';pidfile=dest/'descendant.pid'
    worker.write_text('#!/usr/bin/python3\nimport os,time\npid=os.fork()\nif pid==0:\n open('+repr(str(pidfile))+',"w").write(str(os.getpid()))\n time.sleep(60)\nelse:\n time.sleep(60)\n');worker.chmod(worker.stat().st_mode|stat.S_IXUSR)
    src=ROOT/'selftests/attempt_01/n4_uniform_E_G.txt'
    schedule=[{'call_id':f'synthetic_death_{i:02d}','instance_id':'synthetic_death','objective':'E_G','n':4,'phase':'EXACT_MAIN','input':str(src.relative_to(ROOT)),'input_sha256':sha(src),'ordinal':i}for i in range(16)]
    save(dest/'SCHEDULE.json',schedule)
    controller=dest/'controller.py';controller.write_text('import pathlib,sys\nsys.path.insert(0,'+repr(str(ROOT/'source'))+')\nfrom batch import execute\nfrom common import ROOT,read\nexecute(read(pathlib.Path('+repr(str(dest/'SCHEDULE.json'))+')),ROOT,pathlib.Path('+repr(str(dest/'raw'))+'),pathlib.Path('+repr(str(worker))+'))\n')
    with(dest/'controller.stdout').open('x')as out,(dest/'controller.stderr').open('x')as err:
        p=subprocess.Popen([sys.executable,str(controller)],stdout=out,stderr=err,start_new_session=True)
        for _ in range(500):
            if pidfile.exists():break
            if p.poll()is not None:raise RuntimeError('Controller ended before descendant registration')
            time.sleep(.01)
        assert pidfile.exists();child=int(pidfile.read_text());active=list((dest/'raw/active').glob('*.active.json'));assert len(active)==1
        record=read(active[0]);assert identity(record['pid'])and identity(child)
        os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
    cleanup=cleanup_registered(dest/'raw/active');assert cleanup['quiescent']and not members(record['pgrp'])
    rows=seal(ROOT,dest/'raw',schedule,'SYNTHETIC_NOT_A_REAL_FREEZE',{'controller_killed':True,'controller_returncode':p.returncode,'cleanup':cleanup})
    assert len(rows)==16 and rows[0]['status']=='UNKNOWN_AFTER_SUPERVISOR_FAILURE'and all(r['status']=='NOT_STARTED_SUPERVISOR_FAILURE'for r in rows[1:])
    verify_map(ROOT,read(dest/'raw/RAW_MAIN_MANIFEST.json')['files'])
    save(dest/'REPORT.json',{'status':'PASS','real_optimizer_calls':0,'synthetic_optimizer_calls':0,'fault_worker_calls':1,'supervisor_returncode':p.returncode,'parent_death_signal_leader_and_registered_group_cleanup':cleanup,'all16_slots_retained':True,'raw_sealed_only_after_quiescence':True})
    print('PASS supervisor hard death, worker/descendant group quiescent, all16 slots retained')
if __name__=='__main__':main()
