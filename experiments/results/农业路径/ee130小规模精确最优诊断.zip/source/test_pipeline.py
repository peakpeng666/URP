"""Same production scheduling, exact schema collision regression, and group cleanup."""
import json,pathlib,stat,time,sys
from batch import execute
from bounded import run
from process_groups import identity
from common import ROOT,save,sha

def main():
    dest=ROOT/('selftests/pipeline_'+(sys.argv[1]if len(sys.argv)>1 else'01'));dest.mkdir(exist_ok=False)
    schedule=[]
    for ix in range(16):
        arm=('E_G','G_E')[ix%2];n=20 if ix>=14 else 4
        src=ROOT/f'selftests/attempt_01/n{n}_{"resource_uniform"if n==20 else"uniform"}_{arm}.txt'
        schedule.append({'call_id':f'synthetic_{ix:02d}','instance_id':f'synthetic_n{n}','n':n,'objective':arm,'input':str(src.relative_to(ROOT)),'input_sha256':sha(src),'ordinal':ix,'phase':'EXACT_MAIN','event_kind':'SCHEDULE_FIELD_MUST_NOT_SHADOW'})
    save(dest/'SCHEDULE.json',schedule)
    rows=execute(schedule,ROOT,dest/'raw',ROOT/'source/hklex')
    events=[json.loads(x)for x in(dest/'raw/events.jsonl').read_text().splitlines()]
    assert len(events)==32
    for i,slot in enumerate(schedule):
        assert events[2*i]['event_kind']=='STARTED' and events[2*i+1]['event_kind']=='FINISHED'
        assert events[2*i]['schedule']==events[2*i+1]['schedule']==slot
        assert rows[i]['status']=='UNREVIEWED_PROCESS_SUCCESS'and rows[i]['child_reaped']
        o=json.loads((ROOT/rows[i]['stdout']).read_text());n=slot['n'];assert(o['E'],o['G'])==((n+1)*7,(n+1)*11)
        assert o['rlimit_cpu']==[60,60]and o['rlimit_as']==[536870912]*2
    # Leader exits leaving a sleeping descendant. Finalizer must kill its group.
    worker=dest/'orphan_worker.py';pidfile=dest/'descendant.pid'
    worker.write_text('#!/usr/bin/python3\nimport os,time\npid=os.fork()\nif pid==0:\n open('+repr(str(pidfile))+',"w").write(str(os.getpid()))\n time.sleep(60)\nelse:\n time.sleep(0.2)\n os._exit(0)\n');worker.chmod(worker.stat().st_mode|stat.S_IXUSR)
    inp=dest/'dummy.txt';inp.write_text('')
    r=run(worker,inp,dest/'orphan.stdout',dest/'orphan.stderr');pid=int(pidfile.read_text())
    for _ in range(50):
        current=identity(pid)
        if current is None or current['state']=='Z':break
        time.sleep(.02)
    current=identity(pid);dead=current is None or current['state']=='Z'
    assert dead and r['child_reaped']
    save(dest/'REPORT.json',{'status':'PASS','synthetic_optimization_calls':16,'synthetic_n20_resource_calls':2,'real_optimizer_calls':0,'event_rows':len(events),'schema_collision_regression':'PASS','orphan_cleanup':{'descendant_pid':pid,'descendant_not_running':dead,'leader':r},'all_limits_inherited':True})
    print('PASS pipeline_01; synthetic 16; real 0')
if __name__=='__main__':main()
