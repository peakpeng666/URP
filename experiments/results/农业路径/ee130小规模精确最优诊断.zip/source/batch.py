"""Shared 16-slot production and synthetic scheduling; nested event schema."""
import json,pathlib,time
from bounded import run
from common import append,save,sha,utc

def execute(schedule,base,dest,binary,budget_seconds=1495):
    dest.mkdir(exist_ok=False);(dest/'calls').mkdir();(dest/'active').mkdir()
    start=time.monotonic();deadline=start+budget_seconds
    save(dest/'STARTED.json',{'utc':utc(),'planned_calls':len(schedule),'batch_internal_wall_seconds':budget_seconds,'binary_sha256':sha(binary),'event_schema':'event_kind independent of nested schedule fields'})
    rows=[]
    for slot in schedule:
        cid=slot['call_id'];remaining=deadline-time.monotonic()
        row={'schedule':slot,'utc':utc()}
        if remaining<=0:
            row.update(status='NOT_STARTED_BATCH_BUDGET',process_spawned=False,child_reaped=False)
            append(dest/'events.jsonl',{'event_kind':'NOT_STARTED','utc':utc(),'schedule':slot,'status':row['status']})
        else:
            input_path=base/slot['input'];out=dest/'calls'/f'{cid}.stdout';err=dest/'calls'/f'{cid}.stderr'
            if sha(input_path)!=slot['input_sha256']:
                row.update(status='INPUT_IDENTITY_FAILURE_NOT_STARTED',process_spawned=False,child_reaped=False)
                append(dest/'events.jsonl',{'event_kind':'NOT_STARTED','utc':utc(),'schedule':slot,'status':row['status']})
            else:
                append(dest/'events.jsonl',{'event_kind':'STARTED','utc':utc(),'schedule':slot})
                row.update(run(binary,input_path,out,err,min(90,remaining),dest/'active'/f'{cid}.active.json'))
                row.update(stdout=str(out.relative_to(base)),stderr=str(err.relative_to(base)),stdout_sha256=sha(out),stderr_sha256=sha(err))
                append(dest/'events.jsonl',{'event_kind':'FINISHED','utc':utc(),'schedule':slot,'result':row})
        append(dest/'results.jsonl',row);rows.append(row)
    save(dest/'FINISHED.json',{'utc':utc(),'planned_calls':len(schedule),'spawned_calls':sum(r['process_spawned']for r in rows),'completed_slots':len(rows),'unreviewed_successes':sum(r['status']=='UNREVIEWED_PROCESS_SUCCESS'for r in rows),'external_wall_seconds':time.monotonic()-start,'status':'ALL_SLOTS_RECORDED','real_vs_synthetic':'Set by invoking gate, not inferred from schedule metadata'})
    return rows
