"""Pure synthetic diagnostic logic tests; no real matrices and no optimizer calls."""
from common import ROOT,save
from report import diagnose

def main():
    tests=[('E_primary_and_secondary_optimal',{'E':100,'G':130},'E',0,0),('E_primary_optimal_bad_tie',{'E':100,'G':135},'E',0,5),('E_primary_suboptimal_lower_G',{'E':105,'G':120},'E',5,None),('E_primary_suboptimal_higher_G',{'E':105,'G':140},'E',5,None),('G_primary_optimal_bad_tie',{'E':106,'G':120},'G',0,1),('G_primary_suboptimal_lower_E',{'E':100,'G':130},'G',10,None)]
    rows=[]
    for name,cost,arm,gap,tie in tests:
        o=diagnose(cost,arm,100,130,120,105);assert o['primary_gap_mm']==gap and o['conditional_secondary_tie_gap_mm']==tie;rows.append({'test':name,'output':o})
    failures=[]
    for cost,arm in [({'E':99,'G':140},'E'),({'E':100,'G':129},'E'),({'E':105,'G':119},'G'),({'E':104,'G':120},'G')]:
        try:diagnose(cost,arm,100,130,120,105);raise AssertionError('Inconsistency was accepted')
        except RuntimeError as exc:failures.append(str(exc))
    save(ROOT/'selftests/DIAGNOSTICS.json',{'status':'PASS','pure_logic_tests':len(rows)+len(failures),'real_optimizer_calls':0,'synthetic_optimizer_calls':0,'rows':rows,'rejected_inconsistencies':failures})
    print('PASS diagnostics')
if __name__=='__main__':main()
