"""Unique local archives only. Private upload/readback is owned by the archive worker."""
import pathlib,sys,zipfile
from common import ROOT,save,sha,utc,inventory

def selected_files():
    return [p for p in ROOT.rglob('*')if p.is_file()and '__pycache__'not in p.parts]

def freeze():
    files=[p for p in selected_files()if not str(p.relative_to(ROOT)).startswith('provenance/')and p.name!='FROZEN_FILES.json']
    save(ROOT/'freeze/FROZEN_FILES.json',{'utc':utc(),'files':inventory(ROOT,files)})
    print('FROZEN_SHA256',sha(ROOT/'freeze/FROZEN_FILES.json'))

def archive(stage):
    assert stage in('PREEXEC','RAW_MAIN','RAW_VERIFICATION','FINAL_REVIEWED')
    if stage=='PREEXEC':
        assert not(ROOT/'raw').exists()
        assert not any(p.is_file()for p in(ROOT/'independent_supervision/raw').rglob('*'))
        assert not(ROOT/'independent_supervision/VALIDATION_LAUNCH_STARTED.json').exists()
    out=ROOT.parent/(ROOT.name+'_'+stage+'.zip');assert not out.exists()
    manifest=ROOT/'provenance'/f'{stage}_CONTENT_MANIFEST.json';save(manifest,{'utc':utc(),'stage':stage,'frozen_files_sha256':sha(ROOT/'freeze/FROZEN_FILES.json'),'files':inventory(ROOT,selected_files())})
    files=selected_files()
    with zipfile.ZipFile(out,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
        for p in sorted(files):
            info=zipfile.ZipInfo(str(p.relative_to(ROOT)),date_time=(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=(p.stat().st_mode&0xffff)<<16;z.writestr(info,p.read_bytes())
    print({'stage':stage,'source':str(out),'bytes':out.stat().st_size,'sha256':sha(out),'frozen_files_sha256':sha(ROOT/'freeze/FROZEN_FILES.json'),'members':len(files)})
if __name__=='__main__':
    if sys.argv[1]=='freeze':freeze()
    else:archive(sys.argv[1])
