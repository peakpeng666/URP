"""Loss-aware snapshot of every scheduled slot; shared by formal and synthetic pipeline."""
import json
from common import inventory,save,utc

def seal(base,raw,schedule,digest,outer):
    raw.mkdir(exist_ok=True);rows=[];malformed=[];p=raw/'results.jsonl'
    if p.exists():
        for ix,line in enumerate(p.read_text().splitlines()):
            try:rows.append(json.loads(line))
            except Exception:malformed.append(ix)
    by={x['schedule']['call_id']:x for x in rows}
    duplicate_ids=len(by)!=len(rows);allslots=[]
    for slot in schedule:
        cid=slot['call_id']
        if cid in by:allslots.append(by[cid])
        else:
            exists=(raw/'calls'/f'{cid}.stdout').exists()
            allslots.append({'schedule':slot,'status':'UNKNOWN_AFTER_SUPERVISOR_FAILURE'if exists else'NOT_STARTED_SUPERVISOR_FAILURE','process_spawned':'UNKNOWN'if exists else False,'child_reaped':'UNKNOWN'if exists else False})
    save(raw/'ALL_PLANNED_SLOTS.json',allslots)
    save(raw/'OUTER_FINISHED.json',{'utc':utc(),**outer,'status':'RAW_UNREVIEWED','all_planned_slots':len(allslots),'malformed_result_line_indices':malformed,'duplicate_result_call_ids':duplicate_ids})
    save(raw/'RAW_MAIN_MANIFEST.json',{'utc':utc(),'frozen_files_sha256':digest,'files':inventory(base,[p for p in raw.rglob('*')if p.is_file()])})
    return allslots
