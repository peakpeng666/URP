"""Local checks of externally created archive/parent receipts. Never fabricates approval."""
import hashlib,pathlib,zipfile
from common import ROOT,OLD,read,sha,verify_map

def receipt(path,stage,expected_frozen=None):
    r=read(path)
    if r.get('synthetic_only'):raise RuntimeError('SYNTHETIC_RECEIPT_NOT_AUTHORIZATION')
    if r.get('stage')!=stage:raise RuntimeError('WRONG_RECEIPT_STAGE')
    required=('verified','owner_only','remote_readback_sha256_verified','download_byte_identical')
    if not all(r.get(k)is True for k in required):raise RuntimeError('UNVERIFIED_ARCHIVE_RECEIPT')
    if r.get('shared')is not False:raise RuntimeError('ARCHIVE_PRIVACY_UNVERIFIED')
    if r.get('sha256')!=r.get('download_sha256')or not isinstance(r.get('sha256'),str)or len(r['sha256'])!=64:raise RuntimeError('ARCHIVE_BYTE_HASH_MISMATCH')
    if expected_frozen is not None and r.get('frozen_files_sha256')!=expected_frozen:raise RuntimeError('ARCHIVE_FREEZE_BINDING_MISMATCH')
    for key in ('source','download_path'):
        p=pathlib.Path(r[key])
        if not p.is_file()or sha(p)!=r['sha256']:raise RuntimeError('ARCHIVE_ACTUAL_BYTES_MISMATCH:'+key)
    if expected_frozen is not None:
        with zipfile.ZipFile(r['source'])as z:
            if hashlib.sha256(z.read('freeze/FROZEN_FILES.json')).hexdigest()!=expected_frozen:raise RuntimeError('ARCHIVE_EMBEDDED_FREEZE_MISMATCH')
            for rel,item in read(ROOT/'freeze/FROZEN_FILES.json')['files'].items():
                data=z.read(rel)
                if len(data)!=item['bytes']or hashlib.sha256(data).hexdigest()!=item['sha256']:raise RuntimeError('ARCHIVE_FROZEN_MEMBER_MISMATCH:'+rel)
    return r

def frozen():
    p=ROOT/'freeze/FROZEN_FILES.json';f=read(p);verify_map(ROOT,f['files']);old=read(ROOT/'freeze/OLD_FILES_BEFORE.json');verify_map(OLD,old)
    if set(old)!={str(x.relative_to(OLD))for x in OLD.rglob('*')if x.is_file()}:raise RuntimeError('OLD_FILE_SET_CHANGED')
    return sha(p)

def execution_ready():
    digest=frozen();r=receipt(ROOT/'provenance/PREEXEC_DRIVE_RECEIPT.json','PREEXEC',digest)
    approval=read(ROOT/'provenance/PARENT_EXECUTION_APPROVAL.json')
    if approval.get('approved')is not True or approval.get('frozen_files_sha256')!=digest or approval.get('main_calls')!=16 or approval.get('verification_calls')!=16 or approval.get('preexec_archive_sha256')!=r['sha256']:raise RuntimeError('PARENT_APPROVAL_MISSING_OR_MISMATCH')
    if read(ROOT/'freeze/INDEPENDENT_PRECHECK.json').get('status')!='PASS':raise RuntimeError('INDEPENDENT_PRECHECK_MISSING_OR_FAILED')
    return digest

def report_ready():
    digest=frozen();receipt(ROOT/'provenance/RAW_MAIN_DRIVE_RECEIPT.json','RAW_MAIN',digest)
    receipt(ROOT/'provenance/RAW_VERIFICATION_DRIVE_RECEIPT.json','RAW_VERIFICATION',digest)
    if read(ROOT/'independent_supervision/FINAL_AUDIT.json').get('status')not in('PASS','AUDIT_COMPLETE_WITH_UNVERIFIED_SLOTS'):raise RuntimeError('INDEPENDENT_FINAL_AUDIT_REQUIRED')
    return digest
