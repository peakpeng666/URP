"""Unique author launch, outer hard wall watchdog, unconditional process-group cleanup, immediate local RAW seal."""
if not __debug__:raise RuntimeError('Python assertions must remain enabled')
import os,pathlib,signal,subprocess,sys,time
from common import ROOT,read,save,sha,utc,inventory,append
from gates import execution_ready
from seal_raw import seal
from process_groups import cleanup_registered

def main():
    digest=execution_ready()
    guard=ROOT/'provenance/MAIN_LAUNCH_STARTED.json'
    save(guard,{'utc':utc(),'frozen_files_sha256':digest,'planned_real_main_calls':16,'planned_real_independent_verification_calls':16,'main_process_wall_limit_seconds':1500})
    start=time.monotonic();proc=None;timedout=False;error=None
    with(ROOT/'provenance/main_supervisor.stdout').open('xb')as out,(ROOT/'provenance/main_supervisor.stderr').open('xb')as err:
        try:
            proc=subprocess.Popen([sys.executable,str(ROOT/'source/run_main.py')],stdout=out,stderr=err,start_new_session=True,env={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C'})
            try:proc.wait(timeout=1500)
            except subprocess.TimeoutExpired:timedout=True;os.killpg(proc.pid,signal.SIGKILL);proc.wait()
        except Exception as exc:error=repr(exc)
        finally:
            if proc is not None:
                try:os.killpg(proc.pid,signal.SIGKILL)
                except ProcessLookupError:pass
                proc.wait()
    cleanup=cleanup_registered(ROOT/'raw/active')
    save(ROOT/'provenance/OUTER_GROUP_CLEANUP.json',cleanup)
    if not cleanup['quiescent']:raise RuntimeError('ACTIVE_CHILD_GROUP_REMAINS_RAW_NOT_SEALED')
    seal(ROOT,ROOT/'raw',read(ROOT/'freeze/SCHEDULE.json'),digest,{'timed_out':timedout,'returncode':proc.returncode if proc else None,'error':error,'wall_seconds':time.monotonic()-start,'direct_child_reaped':proc is not None and proc.poll()is not None})
    print('Main batch stopped; raw sealed locally. Private RAW_MAIN readback required before any comparison.')
if __name__=='__main__':main()
