import csv, datetime, hashlib, json, statistics
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def read(p): return json.loads(p.read_text())
def dump(p,x): p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def pct(x): return f'{x*100:.4f}%'
status=read(ROOT/'evidence/RUN_STATUS.json'); insts=read(ROOT/'input/instances.json')
results=[read(ROOT/'raw'/i['instance_id']/'result.json') for i in insts if (ROOT/'raw'/i['instance_id']/'result.json').exists()]
metrics=['legal_repair_estimation_bias_relative_to_euclidean','reoptimization_relative_regret_to_legal_optimum','reoptimization_savings_fraction_of_repaired_euclidean']
def summary(rows):
    out={'base_fields':len(rows),'fields_with_direct_illegal_legs':sum(r['euclidean_direct_illegal_legs']>0 for r in rows),
         'direct_illegal_legs_descriptive_only':sum(r['euclidean_direct_illegal_legs'] for r in rows),
         'total_legs_descriptive_only':sum(r['total_service_legs'] for r in rows),
         'fields_with_reoptimization_gain_above_1e_9':sum(r['reoptimization_saved_absolute']>1e-9 for r in rows),
         'fields_with_changed_task_assignment':sum(r['task_assignment_changed'] for r in rows),
         'exact_float_euclidean_tie_fields':sum(r['enumeration']['tie_sensitivity']['euclidean_exact_float_optima']['count']>1 for r in rows),
         'near_tie_band_fields':sum(r['enumeration']['tie_sensitivity']['euclidean_within_1e_9']['count']>1 for r in rows)}
    for m in metrics:
        vals=[r[m] for r in rows]
        out[m]={'mean':statistics.mean(vals),'median':statistics.median(vals),'min':min(vals),'max':max(vals)}
    return out
stats={'status':status['status'],'statistical_unit':'12 independently seeded base fields; no vehicle/leg/route pseudo-replication',
       'all_12':summary(results),'concave_9':summary([r for r in results if r['family']!='rect']),
       'by_family':{f:summary([r for r in results if r['family']==f]) for f in ['rect','L','U','H']},
       'main_run':status,'inference':'Descriptive synthetic comparison only, no population or field-machine generalization.'}
dump(ROOT/'reports/SUMMARY.json',stats)
fields=['instance_id','family','euclidean_optimal_cost','euclidean_plan_legal_cost','legal_optimal_cost',
        'euclidean_direct_illegal_legs','total_service_legs','legal_repair_estimation_bias_absolute',
        'legal_repair_estimation_bias_relative_to_euclidean','reoptimization_saved_absolute',
        'reoptimization_relative_regret_to_legal_optimum','reoptimization_savings_fraction_of_repaired_euclidean',
        'task_assignment_changed','canonical_feasible_plan_count','exact_E_optima','near_E_optima_1e_9',
        'near_E_min_legal_regret','near_E_max_legal_regret']
with (ROOT/'reports/RESULTS.csv').open('w') as f:
    w=csv.DictWriter(f,fields); w.writeheader()
    for r in results:
        row={k:r[k] for k in fields if k in r}; e=r['enumeration']; t=e['tie_sensitivity']; b=t['euclidean_within_1e_9']
        row.update(canonical_feasible_plan_count=e['canonical_feasible_plan_count'],exact_E_optima=t['euclidean_exact_float_optima']['count'],
                   near_E_optima_1e_9=b['count'],near_E_min_legal_regret=b['minimum_relative_regret'],near_E_max_legal_regret=b['maximum_relative_regret'])
        w.writerow(row)
s=stats['all_12']; c=stats['concave_9']; reg='reoptimization_relative_regret_to_legal_optimum'; bias='legal_repair_estimation_bias_relative_to_euclidean'
lines=['田块内合法路径 × 固定车队精确 CVRP：12块新合成田块',
       '结论：'+status['status']+'；全部预定数据保留。比较对象为同一Q=9、K≤3、9客户的两种距离目标；总需求24使可行方案恰好用3车。',
       '', '三个指标分开：',
       f"1. 原欧氏最优路线的直线腿越界：{s['fields_with_direct_illegal_legs']}/12田块，共{s['direct_illegal_legs_descriptive_only']}/{s['total_legs_descriptive_only']}腿。腿数仅作描述，不当独立样本。",
       f"2. 保持分配与顺序、换成合法最短腿后的估价偏差 (G(E*)−E(E*))/E(E*)：全12均值{pct(s[bias]['mean'])}，中位数{pct(s[bias]['median'])}；9凹形均值{pct(c[bias]['mean'])}，范围{pct(c[bias]['min'])}–{pct(c[bias]['max'])}。",
       f"3. 再按合法距离优化分配与顺序后的欧氏方案相对遗憾 (G(E*)−G(G*))/G(G*)：全12均值{pct(s[reg]['mean'])}，中位数{pct(s[reg]['median'])}；9凹形均值{pct(c[reg]['mean'])}，范围{pct(c[reg]['min'])}–{pct(c[reg]['max'])}。",
       f"实际节省占修复后欧氏方案成本的比例，9凹形均值{pct(c['reoptimization_savings_fraction_of_repaired_euclidean']['mean'])}。不要与以上遗憾分母混用。",
       f"{s['fields_with_reoptimization_gain_above_1e_9']}/12出现大于1e-9的重优化收益；{s['fields_with_changed_task_assignment']}/12主方案的客户分车发生变化。变化描述不单独归因分车/排序贡献。",
       '', '逐田块（直线越界腿 / 12；修复估价偏差；再优化相对遗憾；E最优/1e-9近最优方案数）：']
for r in results:
    t=r['enumeration']['tie_sensitivity']; b=t['euclidean_within_1e_9']
    lines.append(f"{r['instance_id']}: {r['euclidean_direct_illegal_legs']}/12；{pct(r[bias])}；{pct(r[reg])}；{t['euclidean_exact_float_optima']['count']}/{b['count']}。近最优合法遗憾界[{pct(b['minimum_relative_regret'])}, {pct(b['maximum_relative_regret'])}]。")
lines+=['', '精确性与tie：',
 '已完整枚举容量可行、恰好3车的全部方案。每条路线正反视为等价取字典序小者，车辆标签去除后排序；主要解先取未经容差处理的IEEE754 math.fsum目标最小值，再取规范方案字典序最小。规则在生成数据前冻结。',
 '另完整报告精确浮点同最优与目标差≤1e-9全部方案的合法成本上下界，不按合法成本改选主要欧氏解。不同浮点数不等于严格数学上不等；这是全局组合穷尽下的数值最优，不是无理数代数或区间认证。若同最优合法成本不同，主要解损失不能称为全部欧氏最优不可避免。',
 '独立顺序的已审Held–Karp/容量分区DP以注入距离矩阵的最小改动复核两目标；K1/K2不可行，K3成本一致至1e-9。',
 '几何使用原Fraction闭域覆盖和独立矩形并区间剪裁，所有可视边和真实路径逐段双检；Floyd–Warshall复核最短距离。无buffer、无几何容差。距离回算/算法比较的1e-9只用于浮点核验。',
 '3个rect负对照矩阵完全相等，越界、修复偏差、重优化差均精确零；没有丢弃或替换异常。',
 '12基础田块是统计单位。这里没有真实地块、农机宽度、曲率/转弯、作业覆盖、地形或障碍物动力学；采用点机器人和允许贴边的闭域。距离是合成坐标单位，不是已标定米。',
 '', f"主跑CPU {status['cpu_seconds']:.3f}s / 90s；wall {status['wall_seconds']:.3f}s / 150s。模型API、安装、购买、上传均0；新增外部付费USD 0。云CPU未提供计价，不将其声称总成本为零。",
 '复现：Python标准库；目录保持不变时检查freeze哈希，再在空白副本中运行source/run.py。原raw和evidence中的STARTED/RUN_STATUS不能覆盖；详细命令见README。',
 '本包只包含内部程序核验；独立外审由父任务另行进行。']
(ROOT/'reports/REPORT_ZH.txt').write_text('\n'.join(lines)+'\n')
print('\n'.join(lines[:12]))
