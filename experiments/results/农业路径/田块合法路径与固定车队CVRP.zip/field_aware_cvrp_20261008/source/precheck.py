import itertools, json, math, datetime
from pathlib import Path
from geometry import covered_segment
from independent_geometry import segment_in_union
from run import route_space, partitions, canonical, all_costs
from matrix_oracle import solve
ROOT=Path(__file__).resolve().parents[1]
# Independent permutation/cut enumeration of a five-client toy with two vehicles.
d=[0,1,2,2,3,1]; Q=5; K=2; xy=[[0,0],[1,1],[3,1],[4,3],[1,4],[2,6]]
D=[[math.hypot(a[0]-b[0],a[1]-b[1]) for b in xy] for a in xy]
loads,rs=route_space(d,Q)
a={canonical(p) for ps in partitions(31,K,loads,Q,rs) for p in itertools.product(*(rs[s] for s in ps))}
b=set()
for perm in itertools.permutations(range(1,6)):
    for cut in range(1,5):
        p=(perm[:cut],perm[cut:])
        if all(sum(d[t] for t in r)<=Q for r in p): b.add(canonical(p))
assert a==b and len(a)>0
best=min((all_costs(p,D),p) for p in a)
z=solve({'coordinates':xy,'demands':d,'capacity':Q},D)['by_k']['2']
assert abs(best[0]-z['cost'])<=1e-9
poly=[[0,0],[10,0],[10,3],[3,3],[3,10],[0,10]]; rects=[[0,0,10,3],[0,3,3,10]]
cases=[([1,8],[8,1],False),([1,1],[9,1],True),([3,3],[3,10],True),([3,3],[10,3],True),([1,9],[3,3],True),([4,4],[1,1],False)]
for p,q,want in cases: assert covered_segment(p,q,poly)==segment_in_union(p,q,rects)==want
result={'status':'PASS','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'toy_unique_feasible_plans':len(a),'toy_cost':best[0],'independent_permutation_cut_space_equals_partition_space':True,
 'audited_dp_matches':True,'exact_geometry_cases':len(cases),'main_data_objective_evaluations':0}
(ROOT/'evidence/PRECHECK.json').write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps(result))
