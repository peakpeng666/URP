#!/usr/bin/env python3
"""Generate a preregistered, unrejected set of 12 fresh fields without solving."""
import hashlib, json, random, datetime
from pathlib import Path
from geometry import covered_point, validate_polygon
ROOT=Path(__file__).resolve().parents[1]
def dump(p,x): p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def construct(family,seed,index):
    r=random.Random(seed)
    w=r.randint(72,116); h=r.randint(72,116)
    left=r.randint(w//5,w//3); right=w-r.randint(w//5,w//3)
    bottom=r.randint(h//5,h//3); top=h-r.randint(h//5,h//3)
    if family=='rect':
        poly=[(0,0),(w,0),(w,h),(0,h)]; rects=[(0,0,w,h)]
    elif family=='L':
        poly=[(0,0),(w,0),(w,bottom),(left,bottom),(left,h),(0,h)]
        rects=[(0,0,w,bottom),(0,bottom,left,h)]
    elif family=='U':
        poly=[(0,0),(w,0),(w,h),(right,h),(right,bottom),(left,bottom),(left,h),(0,h)]
        rects=[(0,0,w,bottom),(0,bottom,left,h),(right,bottom,w,h)]
    elif family=='H':
        poly=[(0,0),(left,0),(left,bottom),(right,bottom),(right,0),(w,0),(w,h),(right,h),(right,top),(left,top),(left,h),(0,h)]
        rects=[(0,0,left,h),(right,0,w,h),(left,bottom,right,top)]
    points=[]; draws=[]
    while len(points)<10:
        p=(r.randint(1,w-1),r.randint(1,h-1))
        ok=covered_point(p,poly) and p not in points
        draws.append({'point':p,'accepted':ok})
        if ok: points.append(p)
    demand=[1,1,2,2,3,3,4,4,4]
    # Demand randomness independent of rejection-sampling count.
    demand_seed=seed+1000000; random.Random(demand_seed).shuffle(demand)
    return {'instance_id':f'FAC_{family}_{index+1:02d}','base_field_id':f'FAC_{family}_{index+1:02d}',
        'family':family,'geometry_seed':seed,'demand_seed':demand_seed,'polygon':poly,
        'rectangle_decomposition':rects,'coordinates':points,'demands':[0]+demand,'capacity':9,'max_vehicles':3,
        'dimensions':{'width':w,'height':h,'left':left,'right':right,'bottom':bottom,'top':top},'sampling_draws':draws}
if __name__=='__main__':
    cfg=json.loads((ROOT/'freeze/PROTOCOL.json').read_text())
    frozen=json.loads((ROOT/'freeze/PRE_GENERATION_FREEZE.json').read_text())
    assert all(sha(ROOT/p)==v for p,v in frozen['sha256'].items())
    assert not (ROOT/'input/instances.json').exists()
    instances=[construct(f,cfg['master_seed']+100*j+i,i) for j,f in enumerate(cfg['families']) for i in range(3)]
    old=json.loads(Path('/workspace/shared/field_geometry_route_test_20261008/instances.json').read_text())
    fingerprints=[]
    for a in instances:
        validate_polygon(a['polygon'])
        assert len(a['coordinates'])==10 and len(set(map(tuple,a['coordinates'])))==10
        assert sum(a['demands'])==24 and sorted(a['demands'][1:])==[1,1,2,2,3,3,4,4,4]
        key=json.dumps(a['polygon']); assert key not in fingerprints; fingerprints.append(key)
        assert all(a['polygon']!=[tuple(p) for p in b['polygon']] for b in old)
    dump(ROOT/'input/instances.json',instances)
    dump(ROOT/'evidence/GENERATION.json',{'utc':utc(),'count':len(instances),'all_fields_kept':True,
         'objective_evaluations':0,'fresh_polygon_fingerprints_verified_against_prior_16':True,
         'generation_witnesses_provided_to_optimizer':False,'sha256':sha(ROOT/'input/instances.json')})
    print('Generated all 12 preregistered fields; no objective evaluation or outcome selection.')
