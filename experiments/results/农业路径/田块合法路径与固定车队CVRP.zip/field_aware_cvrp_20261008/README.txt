Field-aware fixed-fleet CVRP (12 synthetic fields)

All required runtime code is Python standard library. No network/API needed.
Primary evidence: freeze/PROTOCOL.json; freeze/PRE_GENERATION_FREEZE.json;
freeze/PRE_RUN_FREEZE.json; input/instances.json; evidence/RUN_STATUS.json.
Per-field raw/*/matrices_and_paths.json holds all matrices, legal legs, visibility
checks. raw/*/all_canonical_plans.csv.gz contains every capacity-feasible canonical
3-vehicle solution and both costs. raw/*/result.json contains both selected plans,
loads, full legal polylines, costs, complete tie sensitivity and audited DP crosscheck.
reports/RESULTS.csv and REPORT_ZH.txt summarize every preregistered field.

Main run is unique and write-once. Reproduction without modifying this package:
1. Copy the full directory to a NEW empty directory.
2. In that copy only, remove raw/, evidence/STARTED.json, evidence/RUN_STATUS.json
   and any MAIN_* receipts; recreate an empty raw/ directory.
3. PYTHONDONTWRITEBYTECODE=1 python source/run.py
4. python source/summarize.py
Input/source/freeze hashes are verified by run.py before solving.
To regenerate data separately, prepare.py additionally needs the read-only original
field_geometry_route_test_20261008/instances.json for the freshness check. Frozen
input/instances.json is sufficient to reproduce all main results without that old input.
No old package was modified. Source copies have provenance and sha256 evidence.
Main exactness means complete finite-plan enumeration using binary64 costs;
this is not formal interval/arithmetic certification of irrational objective ordering.
Geometry uses rational exact predicates without buffer or tolerance.
