#!/usr/bin/python3
import datetime,hashlib,json,math,pathlib,zipfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,obj):
 with p.open('x') as f:json.dump(obj,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')
protocol={
 'study':'ee130_fixed_tasks_clearance_aware_routing_v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'scope':'Independent new stage. All 12 original instances, depot, original projected field outer ring and 3 holes remain byte-identical. No resampling, task movement, radius selection, geometric simplification, model calls, networking or installs.',
 'fixed_instances':{'sizes':[8,12,20,40],'seeds':[202610081001,202610081002,202610081003],'methods':['nearest_neighbor','nn_2opt_budget'],'twoopt_candidate_budget':10000},
 'radius_m':1.0,'footprint':'Hypothetical translating closed disk; orientation, steering, turning radius, dynamics and physical agricultural executability are not modeled.',
 'geometry_source':'Original EPSG:32634 WKT reused as given, without claiming source CRS usage is surveying ground truth.',
 'buffer':{'algorithm':'GDAL/GEOS negative round buffer','quadrant_segments':16,'buffer_distance_formula':'(1.0 + 0.00001)/cos(pi/(2*16))','buffer_distance_m':(1.0+1e-5)/math.cos(math.pi/32),'numerical_margin_m':1e-5,'reason':'Prespecified radius inflation accommodates polygonal arc-chord underclearance. It is deliberately conservative; no exact GEOS approximation theorem is claimed. Numeric posterior checks are authoritative.',
 'center_region_acceptance':'Nonempty valid Polygon/MultiPolygon, whole filled region covered by original field, distance of whole filled region to original field boundary >1+1e-8 m, intersection with every original hole empty. This is finite-precision posterior evidence for a conservative region, not a formal continuum certificate.',
 'topology':'Retain all output components and all rings, do not filter components or close narrow corridors. All 3 original holes checked individually even if buffer topology changes.'},
 'classification_order':['TASK_INFEASIBLE: original endpoint outside field or clearance < 1-1e-8; preserve failed task IDs and compute no route','UNCERTAIN_ENDPOINT_NUMERICS: original endpoint within 1e-8 of radius','CONSERVATIVE_APPROXIMATION_UNAVAILABLE: center-region posterior check fails, or safe original endpoints excluded by approximation; not original-task infeasibility','NO_CONNECTION_IN_FROZEN_GRAPH: endpoint-valid instance lacks a finite graph connection; no claim of no continuous safe path','VALID_SAFE_ROUTES: both saved NN/2opt full polylines pass independent posterior geometry, visit and closure checks','UNCERTAIN_OR_INVALID_POSTERIOR_ROUTE / RESOURCE_TIMEOUT / TECHNICAL_FAILURE: retain raw artifacts and do not call valid'],
 'visibility':'Use unchanged prior distance and closed-polygon GEOS visibility function on center region, with each accepted full edge also checked against original field and original boundary distance >1+1e-8. All center polygon vertices plus immutable service nodes; pair checks exhaustive. No simplification. Undirected Euclidean edges.',
 'shortest_path':'Prior Dijkstra structure adapted to tolerate disconnection and disallow other service nodes as interior transit vertices. Distance matrix symmetrized from one orientation after <=1e-8 asymmetry check. Finite graph paths only, not exact continuous shortest paths.',
 'solver':'NN and first-improvement fixed 10000-candidate 2opt functions copied verbatim from original stage. No oracle claims or parameter tuning. Preprocessing cost separate from solve cost.',
 'posterior_audit':'Every full segment independently compared against original outer/hole edges using GEOS distance and Decimal precision60 projection/intersection minima. Containment independently checked using original rational predicate with exact original WKT decimal strings and serialized candidate coordinates as Fractions. Entire polyline also GEOS covered with distance >1+1e-8, length consistency, one scheduled visit per task, depot closure, each original hole disjoint. Route physical passage does not imply additional service event.',
 'numerics':{'tau_m':1e-8,'PASS':'covered and d>1+tau','FAIL':'outside or d<1-tau','UNCERTAIN':'abs(d-1)<=tau','limitations':'Binary64 GEOS and Decimal numerical evidence; exact rational containment refers to serialized decimal coordinates, not true surveying geometry. No safety result rounded across threshold.'},
 'comparison':'Always retain old lengths and old radius=1 audit statuses for all 12 instances. Old 0m optimization versus new 1m constraints cannot be presented as pure algorithm gain. Only within-new-instance NN versus 2opt compares same graph and constraint.',
 'resources':{'total_cpu_seconds':300,'total_wall_seconds':600,'address_space_bytes':1073741824,'shared_preprocessing_deadline_seconds':240,'per_instance_deadline_seconds':60,'formal_attempts':1,'single_process':True,'timing':'Shared region/visibility cost, per-instance graph construction, solver and validation separated; point and route validation caches are reported and make per-instance validation timings order-dependent.'},
 'execution_gate':'Frozen source/input/toy hashes; original audit formal independent PASS; private PREEXEC snapshot upload and readback receipt before single formal run. Immediately archive raw as UNAUDITED before scientific interpretation.',
 'prior_audit_sha256':sha(ROOT/'input/PRIOR_INDEPENDENT_AUDIT.json'),
 'limitations':'Four nested prefixes of each of three seed layouts on one field, not twelve independent environments. Finite-graph disconnection and conservative exclusions cannot prove exact continuous infeasibility. Only endpoint geometric failure establishes fixed-task infeasibility under the assumed circle.',
 'stopping_rule':'No parameter retuning or rerun after formal execution. Technical or resource failures remain visible. New follow-on stages require their own protocol and label.'}
save(ROOT/'freeze/PROTOCOL.json',protocol)
source=pathlib.Path('/workspace/shared/ee130_route_clearance_audit_20261008/input')
originals={}
for p in sorted((ROOT/'input').glob('*')):
 if (source/p.name).is_file():
  assert p.read_bytes()==(source/p.name).read_bytes();originals[p.name]={'source_path':str(source/p.name),'sha256':sha(p),'byte_identical':True}
save(ROOT/'freeze/INPUT_IDENTITY.json',originals)
files={str(p.relative_to(ROOT)):sha(p) for sub in ['input','source','freeze','evidence'] for p in sorted((ROOT/sub).rglob('*')) if p.is_file() and '__pycache__' not in str(p)}
save(ROOT/'freeze/PREEXECUTION_FREEZE.json',{'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':files,'formal_data_not_executed':True})
zip_path=ROOT.parent/(ROOT.name+'_PREEXECUTION_SNAPSHOT.zip')
with zipfile.ZipFile(zip_path,'x',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(ROOT.rglob('*')):
  if p.is_file() and '__pycache__' not in str(p):z.write(p,p.relative_to(ROOT.parent))
print(json.dumps({'path':str(zip_path),'sha256':sha(zip_path),'bytes':zip_path.stat().st_size,'files_frozen':len(files)}))
