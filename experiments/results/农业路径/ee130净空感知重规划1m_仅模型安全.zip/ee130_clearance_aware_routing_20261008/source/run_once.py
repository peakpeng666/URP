#!/usr/bin/python3
import datetime,hashlib,json,os,pathlib,resource,subprocess,sys,time
ROOT=pathlib.Path(__file__).resolve().parents[1]
def dump(path,obj):
 with path.open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
def limit():
 resource.setrlimit(resource.RLIMIT_CPU,(300,300));resource.setrlimit(resource.RLIMIT_AS,(1073741824,1073741824))
def main():
 receipt=ROOT/'evidence/PREEXECUTION_DRIVE_RECEIPT.json'
 assert receipt.is_file(),'Private preexecution readback receipt required'
 gate=json.loads((ROOT/'input/PRIOR_INDEPENDENT_AUDIT.json').read_text());assert gate['status']=='PASS_INDEPENDENT_SAVED_RESULT_AUDIT'
 with (ROOT/'evidence/STARTED.json').open('x') as f:json.dump({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'attempt':1,'cpu_limit_s':300,'wall_limit_s':600,'memory_limit_bytes':1073741824,'preexec_receipt_sha256':hashlib.sha256(receipt.read_bytes()).hexdigest(),'prior_audit_sha256':hashlib.sha256((ROOT/'input/PRIOR_INDEPENDENT_AUDIT.json').read_bytes()).hexdigest()},f,indent=2)
 before=resource.getrusage(resource.RUSAGE_CHILDREN);wall=time.perf_counter()
 try:
  with (ROOT/'evidence/STDOUT.log').open('x') as out,(ROOT/'evidence/STDERR.log').open('x') as err:
   p=subprocess.run(['/usr/bin/python3',str(ROOT/'source/clearance_routing.py')],stdout=out,stderr=err,timeout=600,preexec_fn=limit,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1'})
  code=p.returncode;status='COMPLETE_UNAUDITED' if code==0 else 'FAILED'
 except subprocess.TimeoutExpired:code=None;status='WALL_TIMEOUT'
 after=resource.getrusage(resource.RUSAGE_CHILDREN)
 dump(ROOT/'evidence/RUN_STATUS.json',{'status':status,'exit_code':code,'wall_seconds':time.perf_counter()-wall,'children_cpu_seconds':after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime,'children_peak_rss_kib':after.ru_maxrss,'one_formal_execution':True});print(status)
 if status!='COMPLETE_UNAUDITED':sys.exit(1)
if __name__=='__main__':main()
