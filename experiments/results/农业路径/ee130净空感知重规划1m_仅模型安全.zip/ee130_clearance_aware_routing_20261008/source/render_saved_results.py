#!/usr/bin/python3
"""Post-result reporting only. Does not replan, buffer, or change raw evidence."""
import csv, json, math, os, pathlib
os.environ['MPLCONFIGDIR']='/tmp/ee130_clearance_aware_mpl'
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from osgeo import ogr
R=pathlib.Path(__file__).resolve().parents[1]
results=json.loads((R/'raw/results.json').read_text());instances=results['instances'];base=json.loads((R/'raw/shared_preprocessing.json').read_text());field=ogr.CreateGeometryFromWkt((R/'input/projected_epsg32634.wkt').read_text());center=ogr.CreateGeometryFromWkt((R/'raw/center_region.wkt').read_text());off=(661850,6526070)
def local(p):return p[0]-off[0],p[1]-off[1]
def draw_field(ax):
 for ri in range(field.GetGeometryCount()):
  ring=field.GetGeometryRef(ri);pts=[local(ring.GetPoint(i)) for i in range(ring.GetPointCount())]
  ax.fill(*zip(*pts),facecolor='#eef2ee' if ri==0 else 'white',edgecolor='#334039',linewidth=.8)
 ax.set_aspect('equal');ax.grid(alpha=.15);ax.tick_params(labelsize=7)
def draw_points(ax,i):
 ps=[local(s['coordinate']) for s in i['services']];bad=set(i.get('failing_service_ids',[]))
 for j,p in enumerate(ps):
  ax.scatter(*p,c='#bd3a29' if j in bad else '#293945',marker='*' if j==0 else ('x' if j in bad else 'o'),s=65 if j==0 else (30 if j in bad else 12),zorder=4)
 # All failing task IDs are printed in the subplot title, avoiding crowded map labels.
fig,axs=plt.subplots(3,4,figsize=(15,11),sharex=True,sharey=True)
for ax,i in zip(axs.flat,instances):
 draw_field(ax);draw_points(ax,i)
 if i['methods']:
  p=[local(c) for c in i['methods']['nn_2opt_budget']['mapped_polyline_coordinates']];ax.plot(*zip(*p),color='#087e70',lw=1.4,zorder=3)
  subtitle='2 safe routes; 2-opt shown'
 else:subtitle='TASK_INFEASIBLE: '+','.join(map(str,i['failing_service_ids']))
 ax.set_title(i['instance_id']+'\n'+subtitle,fontsize=9)
for ax in axs[-1]:ax.set_xlabel('Easting - 661850 (m)',fontsize=8)
for ax in axs[:,0]:ax.set_ylabel('Northing - 6526070 (m)',fontsize=8)
fig.suptitle('Fixed ee130 tasks, 1 m disk: all 12 instances retained',fontsize=15)
fig.legend(handles=[Line2D([0],[0],color='#087e70',lw=2,label='New safe 2-opt route'),Line2D([0],[0],marker='x',color='#bd3a29',ls='',label='Original task fails 1 m clearance'),Line2D([0],[0],marker='*',color='#293945',ls='',label='Original depot')],loc='lower center',ncol=3,frameon=False,fontsize=10)
fig.tight_layout(rect=(0,0.045,1,.96));fig.savefig(R/'reports/all_12_instances.png',dpi=160);plt.close(fig)
valid=[i for i in instances if i['methods']];fig,axs=plt.subplots(len(valid),2,figsize=(11,15),sharex=True,sharey=True)
for row,i in zip(axs,valid):
 for ax,label in zip(row,['nearest_neighbor','nn_2opt_budget']):
  draw_field(ax);draw_points(ax,i);old=json.loads((R/f'input/{i["instance_id"]}_result.json').read_text())['methods'][label];oldps=[local(p) for p in old['mapped_polyline_coordinates']];ax.plot(*zip(*oldps),color='#cf7f29',lw=2.5,alpha=.6,zorder=2)
  m=i['methods'][label];p=[local(c) for c in m['mapped_polyline_coordinates']];ax.plot(*zip(*p),color='#087e70',lw=1.3,zorder=3)
  ax.set_title(f'{i["instance_id"]} | {label}\nL={m["length_m"]:.3f} m; min clearance={m["minimum_clearance_m"]:.6f} m',fontsize=10)
for ax in axs[-1]:ax.set_xlabel('Easting - 661850 (m)')
for ax in axs[:,0]:ax.set_ylabel('Northing - 6526070 (m)')
fig.suptitle('All 8 new safe routes on the 4 endpoint-feasible instances\nOld paths use a different (zero-clearance) constraint',fontsize=14)
fig.legend(handles=[Line2D([0],[0],color='#087e70',lw=2,label='New 1 m constraint'),Line2D([0],[0],color='#cf7f29',lw=3,alpha=.6,label='Old 0 m constraint')],loc='lower center',ncol=2,frameon=False)
fig.tight_layout(rect=(0,.035,1,.95));fig.savefig(R/'reports/all_8_safe_routes.png',dpi=160);plt.close(fig)
rows=[]
for i in instances:
 for label in ['nearest_neighbor','nn_2opt_budget']:
  m=i['methods'].get(label,{});old=i['old_route_comparison'][label]
  rows.append({'instance_id':i['instance_id'],'n':i['n'],'seed':i['seed'],'instance_status':i['status'],'method':label,'new_route_status':m.get('clearance_status','NOT_SOLVED_ENDPOINT_INFEASIBLE'),'failing_service_ids':json.dumps(i['failing_service_ids']),'minimum_service_clearance_m':min(x['minimum_clearance_m'] for x in i['services']),'old_length_m':old['old_length_m'],'old_1m_clearance_status':old['old_1m_clearance_status'],'new_length_m':m.get('length_m'),'new_minimum_clearance_m':m.get('minimum_clearance_m'),'new_minus_old_length_m':None if not m else m['length_m']-old['old_length_m'],'instance_graph_wall_seconds':i.get('preprocessing_resources',{}).get('wall_seconds'),'solve_wall_seconds':m.get('solve_resources',{}).get('wall_seconds'),'twoopt_candidate_reversals':m.get('operations',{}).get('candidate_reversals'),'constraint_change_not_pure_algorithm_gain':True})
with (R/'reports/all_24_method_conditions.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
summary={'status':'AUTHOR_POSTERIOR_RESULT_PENDING_INDEPENDENT_AUDIT','all_instance_count':len(instances),'status_counts':results['status_counts'],'valid_routes':results['routes_produced'],'new_route_minimum_clearance_m':min(m['minimum_clearance_m'] for i in valid for m in i['methods'].values()),'newly_routed_old_unsafe_route_count':sum(old['old_1m_clearance_status']=='FAIL' for i in valid for old in i['old_route_comparison'].values()),'already_safe_old_route_count':sum(old['old_1m_clearance_status']=='PASS' for i in valid for old in i['old_route_comparison'].values()),'complete_original_holes_retained':True,'shared_preprocessing':base['total_shared_resources'],'total_experiment':json.loads((R/'evidence/RUN_STATUS.json').read_text()),'rows':rows}
(R/'reports/summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
(R/'evidence/FIGURE_DESCRIPTION.json').write_text(json.dumps({'source':'Saved results only; no replanning or rebuffering','all_12_instances.png':'All original 12 task layouts and original 3 holes. Mark all infeasible original task IDs. Show new 2opt for all 4 feasible instances.','all_8_safe_routes.png':'Every newly produced NN/2opt route, compared visually with old unconstrained path. Constraints differ; overlap can hide the old line.','coordinates':'Original projected coordinates translated by (661850,6526070), metric scale unchanged.','colors':'Green=new numerically clearance-validated route; orange=old zero-clearance path; red cross=original infeasible service point.','selection':'Complete panels, no positive-only subset presented as entire experiment.'},indent=2)+'\n')
