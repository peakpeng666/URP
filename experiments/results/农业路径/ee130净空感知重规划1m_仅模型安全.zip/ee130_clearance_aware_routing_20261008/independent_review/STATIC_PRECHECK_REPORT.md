# Independent static precheck

Scope: read-only review of the frozen stage. No optimization, buffering, clearance computation, or route generation was run on the actual field/task data. The only executable author functions invoked were synthetic toy tests; imports used PYTHONDONTWRITEBYTECODE=1. The reviewed stage was not changed.

Verdict: PASS_STATIC_PRECHECK_WITH_REPORTING_CAVEATS. This is not a scientific acceptance of results, nor proof that a future run will complete.

- All 54 manifest-frozen files match their SHA-256 values.
- All 41 input identity references match their original source bytes. The exact 12 size/seed pairs and the original per-instance coordinates/depot are retained. Depots differ across seeds as in the originals; no single-depot assumption is introduced.
- NN and 2opt definitions are byte-for-byte equal to the original function source (also AST checked). The 2opt default and called budget is 10000 candidate reversals, allowing early termination after a full sweep with no accepted move.
- Radius=1 m, q=16, and distance=(1+1e-5)/cos(pi/32) are fixed. The protocol does not claim an exact GEOS approximation theorem. Full filled buffered region containment and boundary distance, original holes, and every accepted full edge are checked.
- All original endpoints are audited before any per-instance route construction. Failed endpoint IDs remain in TASK_INFEASIBLE results; safe endpoints excluded by conservative approximation receive a distinct label. There is no resampling, movement, endpoint dropping, or retry tuning path.
- Graph vertices retain all buffered components/rings plus immutable service nodes. Service nodes are excluded from interior Dijkstra transit. Exhaustive base/service pair candidates are checked. Symmetrization requires a <=1e-8 discrepancy. Finite-graph disconnection is expressly not a continuous-infeasibility proof.
- Saved route audits examine every full segment against all original outer/hole edges, and exact serialized-decimal containment; check full polyline containment, all three original holes, depot closure, lengths and exactly-once scheduled service events. Physical passage has separately stated semantics.
- Wrapper enforces CPU 300 s, wall 600 s, address space 1 GiB and single formal launch using exclusive STARTED creation. Shared/per-instance alarms are 240/60 s. New output is classified UNAUDITED pending independent review.
- Protocol retains the distinction between changed old 0 m/new 1 m constraints and within-new-instance NN/2opt comparisons, and the 12 observations are acknowledged to be nested prefixes of only three seed layouts.
- The synthetic preexecution tests pass when re-invoked read-only. Raw directory was empty at verification.

Reporting caveats requiring attention after execution:

1. The wrapper checks that PREEXECUTION_DRIVE_RECEIPT.json exists and saves its hash; it does not itself validate the private remote object or downloaded archive bytes. The parent must verify receipt contents and original archive hash externally before launching.
2. Shared-stage failure or a total CPU/wall/address-space stop can end execution before all instances receive result records. Per-instance exceptions also omit the normal result's old-route comparison block. For such a run, use the immutable input roster to list every instance explicitly as completed, failed, or not reached; do not silently remove these instances or present COMPLETE_UNAUDITED as all-valid. Old comparison inputs remain available and must still be retained in the final report.
3. The author Decimal crosscheck consumes original boundary coordinates after binary64 OGR conversion. Exact containment consumes original WKT decimals. The independent saved-result review will additionally calculate squared segment/boundary distances with exact integer/rational arithmetic directly from original WKT and saved JSON decimal tokens; this will not rely on the author's assertions or old claims.

Evidence: STATIC_PRECHECK.json and SYNTHETIC_TOY_RECHECK.json in this independent-review directory.
