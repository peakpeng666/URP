#!/usr/bin/python3
"""Independent read-only saved-result review. No author code imports or optimizer invocation.
Geometry uses original WKT decimal tokens and saved JSON decimal tokens as exact
integers on a 10^-20 grid; all squared distances and threshold comparisons are rational.
Only --toy runs without explicit --saved-results flag after parent archival clearance.
"""
import argparse, collections, datetime, decimal, hashlib, heapq, json, math, pathlib, re, resource, time
from decimal import Decimal as D
from fractions import Fraction as F
ROOT=pathlib.Path('/workspace/shared/ee130_clearance_aware_routing_20261008')
OUT=pathlib.Path(__file__).resolve().parent
S=10**20
TLO=F('0.99999999')**2
THI=F('1.00000001')**2
decimal.getcontext().prec=90

def read(p):return json.loads(p.read_text(),parse_float=D)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def point(p):
 q=[F(str(x))*S for x in p]
 assert all(x.denominator==1 for x in q),'Grid is too coarse for exact input tokens'
 return tuple(int(x) for x in q)
def sub(a,b):return a[0]-b[0],a[1]-b[1]
def dot(a,b):return a[0]*b[0]+a[1]*b[1]
def cross(a,b):return a[0]*b[1]-a[1]*b[0]
def orient(a,b,c):return cross(sub(b,a),sub(c,a))
def on(a,b,p):return orient(a,b,p)==0 and min(a[0],b[0])<=p[0]<=max(a[0],b[0]) and min(a[1],b[1])<=p[1]<=max(a[1],b[1])
def intersects(a,b,c,d):
 x,y,u,v=orient(a,b,c),orient(a,b,d),orient(c,d,a),orient(c,d,b)
 if (x<0<y or y<0<x) and (u<0<v or v<0<u):return True
 return (x==0 and on(a,b,c)) or (y==0 and on(a,b,d)) or (u==0 and on(c,d,a)) or (v==0 and on(c,d,b))
def point_seg_sq(p,a,b):
 ab,ap=sub(b,a),sub(p,a);length=dot(ab,ab);projection=dot(ap,ab)
 if length==0 or projection<=0:return dot(ap,ap),1
 if projection>=length:
  bp=sub(p,b);return dot(bp,bp),1
 return cross(ab,ap)**2,length

def seg_sq(a,b,c,d):
 if intersects(a,b,c,d):return 0,1
 best=None
 for n,v in (point_seg_sq(a,c,d),point_seg_sq(b,c,d),point_seg_sq(c,a,b),point_seg_sq(d,a,b)):
  if best is None or n*best[1]<best[0]*v:best=n,v
 return best

def ring_location(p,r):
 """1 strictly inside, 0 on boundary, -1 outside: exact integer winding."""
 winding=0
 for a,b in zip(r,r[1:]+r[:1]):
  if on(a,b,p):return 0
  k=orient(a,b,p)
  if a[1]<=p[1]<b[1] and k>0:winding+=1
  elif b[1]<=p[1]<a[1] and k<0:winding-=1
 return 1 if winding else -1

def field_location(p,rings):
 outer=ring_location(p,rings[0]);holes=[ring_location(p,r) for r in rings[1:]]
 return outer>=0 and not any(x==1 for x in holes)
def cmp_fraction(n,d,x):
 k=n*x.denominator-x.numerator*d*S*S
 return (k>0)-(k<0)
def metres(n,d):return (D(n)/D(d)/D(S*S)).sqrt()

def evaluate(a,b,rings,edges):
 best=None;wi=None;hole_best={}
 for ri,ei,c,d in edges:
  n,v=seg_sq(a,b,c,d)
  if best is None or n*best[1]<best[0]*v:best=n,v;wi=(ri,ei)
  if ri and (ri not in hole_best or n*hole_best[ri][1]<hole_best[ri][0]*v):hole_best[ri]=(n,v)
 n,v=best;ain=field_location(a,rings);bin=field_location(b,rings)
 # A continuous segment with strictly positive distance to the full polygon boundary
 # cannot leave its start's connected interior. Exact endpoint test + exact d>0 gives
 # containment for every point of the segment, without sampling.
 contained=bool(ain and bin and n>0)
 state='FAIL' if not (ain and bin) or cmp_fraction(n,v,TLO)<0 else 'PASS' if cmp_fraction(n,v,THI)>0 else 'UNCERTAIN_BOUNDARY'
 ratio=F(n,v*S*S)
 return {'clearance_status':state,'full_segment_contained_proof':contained,'start_covered':ain,'end_covered':bin,'distance_m_decimal':str(metres(n,v)), 'distance_squared_exact_numerator':str(ratio.numerator),'distance_squared_exact_denominator':str(ratio.denominator),'witness_ring_edge':list(wi),'three_hole_distances_m_decimal':{str(k):str(metres(*val)) for k,val in hole_best.items()},'all_three_holes_strictly_disjoint':all(val[0]>0 for val in hole_best.values()) and all(ring_location(a,rings[k])==-1 for k in hole_best)}

def toy():
 p=lambda x:point(x)
 outer=list(map(p,[[0,0],[20,0],[20,20],[0,20]]));hole=list(map(p,[[8,8],[12,8],[12,12],[8,12]]));rings=[outer,hole]
 edges=[(i,j,a,b) for i,r in enumerate(rings) for j,(a,b) in enumerate(zip(r,r[1:]+r[:1]))]
 cases=[('safe',[[2,2],[18,2]],'PASS',D(2)),('contact',[[0,2],[0,18]],'FAIL',D(0)),('hole_crossing',[[2,10],[18,10]],'FAIL',D(0)),('outside',[[21,2],[22,3]],'FAIL',D(1)),('exact_one',[[1,2],[1,18]],'UNCERTAIN_BOUNDARY',D(1)),('below',[[D('.5'),2],[D('.5'),18]],'FAIL',D('.5')),('point',[[2,2],[2,2]],'PASS',D(2))]
 rows=[]
 for name,coords,state,dist in cases:
  z=evaluate(*map(p,coords),rings,edges);assert z['clearance_status']==state,(name,z);assert D(z['distance_m_decimal'])==dist,(name,z);rows.append({'name':name,'result':z})
 # Independent hand-known diagonal point/projection and crossing checks.
 assert F(*point_seg_sq(p([1,0]),p([0,0]),p([2,2])))/(S*S)==F(1,2)
 assert seg_sq(p([0,0]),p([2,2]),p([0,2]),p([2,0]))==(0,1)
 assert seg_sq(p([0,0]),p([4,0]),p([2,0]),p([5,0]))==(0,1)
 assert ring_location(p([10,10]),hole)==1 and ring_location(p([8,10]),hole)==0
 return {'status':'PASS','synthetic_only':True,'independent_integer_geometry':True,'cases':rows}

def shortest(adj,start,firstservice):
 d=[math.inf]*len(adj);d[start]=0.;q=[(0.,start)]
 while q:
  v,u=heapq.heappop(q)
  if v!=d[u]:continue
  if u>=firstservice and u!=start:continue
  for nxt,w in adj[u]:
   cand=v+w
   if cand<d[nxt]:d[nxt]=cand;heapq.heappush(q,(cand,nxt))
 return d

def audit():
 t=time.perf_counter();cpu=time.process_time();checks=[]
 def require(ok,label,details=None):
  checks.append({'pass':bool(ok),'check':label,**({'details':details} if details is not None else {})})
  if not ok:raise AssertionError(label+': '+str(details))
 manifest=read(ROOT/'freeze/PREEXECUTION_FREEZE.json')
 for rel,h in manifest['files'].items():require(sha(ROOT/rel)==h,'frozen hash '+rel)
 identity=read(ROOT/'freeze/INPUT_IDENTITY.json')
 for rel,rec in identity.items():require((ROOT/'input'/rel).read_bytes()==pathlib.Path(rec['source_path']).read_bytes(),'unchanged original '+rel)
 rawhash={str(p.relative_to(ROOT)):sha(p) for p in sorted((ROOT/'raw').rglob('*')) if p.is_file()}
 wh=(ROOT/'input/projected_epsg32634.wkt').read_text()
 rings=[]
 for text in re.findall(r'\(([^()]+)\)',wh):
  coords=[point(pair.split()) for pair in text.split(',')];require(coords[0]==coords[-1],'original ring closed');rings.append(coords[:-1])
 require(len(rings)==4,'one outer plus three original holes')
 edges=[(i,j,a,b) for i,r in enumerate(rings) for j,(a,b) in enumerate(zip(r,r[1:]+r[:1]))]
 summary=read(ROOT/'raw/results.json');run=read(ROOT/'evidence/RUN_STATUS.json');started=read(ROOT/'evidence/STARTED.json')
 require(run['status']=='COMPLETE_UNAUDITED' and run['exit_code']==0,'formal execution completed unaudited')
 require(started['attempt']==1 and run['one_formal_execution'],'one recorded formal execution')
 require(float(run['children_cpu_seconds'])<=300 and float(run['wall_seconds'])<=600,'actual CPU and wall cap')
 require(int(run['children_peak_rss_kib'])*1024<=1073741824,'observed peak RSS below memory cap')
 require(started['cpu_limit_s']==300 and started['wall_limit_s']==600 and started['memory_limit_bytes']==1073741824,'declared fixed resource limits')
 inputs={p.stem[:-6]:read(p) for p in sorted((ROOT/'input').glob('n*_input.json'))}
 expected={(n,s) for n in [8,12,20,40] for s in [202610081001,202610081002,202610081003]}
 require(len(inputs)==12 and {(x['n'],x['seed']) for x in inputs.values()}==expected,'12 fixed input size seed pairs')
 results={x['instance_id']:x for x in summary['instances']}
 require(len(summary['instances'])==len(results)==12 and set(results)==set(inputs),'all 12 instance statuses retained')
 shared=read(ROOT/'raw/shared_preprocessing.json');bnodes=shared['nodes'];base=shared['edges']; b=len(bnodes)
 require(shared['candidate_edge_checks']==b*(b-1)//2,'exhaustive shared edge candidate count')
 require(shared['geometry']['quadrant_segments']==16 and shared['geometry']['numerical_margin_m']==D('0.00001'),'fixed q16 and margin')
 require(abs(float(shared['geometry']['buffer_distance_m'])-(1.00001/math.cos(math.pi/32)))<1e-14,'fixed inflated buffer distance')
 require(len(shared['geometry']['all_original_holes_excluded'])==3 and all(x['intersection_empty'] for x in shared['geometry']['all_original_holes_excluded']),'buffer retains hole exclusion evidence')
 # GEOS is used only as an additional independent engine, never author imports.
 from osgeo import ogr
 original=ogr.CreateGeometryFromWkt(wh);center=ogr.CreateGeometryFromWkt((ROOT/'raw/center_region.wkt').read_text())
 require(bool(center.IsValid()) and not center.IsEmpty(),'saved center valid and nonempty')
 require(center.Difference(original).IsEmpty() and center.Distance(original.Boundary())>1.00000001,'saved full center inside original and clear')
 for i in range(1,4):
  hole=ogr.Geometry(ogr.wkbPolygon);hole.AddGeometry(original.GetGeometryRef(i));require(center.Intersection(hole).IsEmpty(),'saved center excludes original hole '+str(i))
 cache={};servicecache={};instances=[];route_rows=[];segment_uses=0;max_delta=D(0)
 oldconditions=read(ROOT/'input/PRIOR_CLEARANCE_RESULTS.json')['conditions']
 for iid,inst in inputs.items():
  saved=results[iid];require(saved==read(ROOT/f'raw/{iid}_result.json'),'summary equals per-instance record '+iid)
  services=[]
  require(len(inst['coordinates'])==inst['n']+1,'input tasks/depot count '+iid)
  for j,c in enumerate(inst['coordinates']):
   key=point(c)
   if key not in servicecache:servicecache[key]=evaluate(key,key,rings,edges)
   ev=servicecache[key];services.append({'service_id':j,'coordinate':c,**ev});author=saved['services'][j]
   require(author['service_id']==j and author['coordinate']==c,'unaltered service '+iid+' '+str(j))
   require(author['clearance_status']==ev['clearance_status'],'exact service classification '+iid+' '+str(j))
   discrepancy=abs(D(ev['distance_m_decimal'])-D(author['minimum_clearance_m']));max_delta=max(max_delta,discrepancy)
   require(discrepancy<=D('0.00000001'),'service distance numerical agreement '+iid+' '+str(j))
  bad=[j for j,z in enumerate(services) if z['clearance_status']=='FAIL'];unc=[j for j,z in enumerate(services) if z['clearance_status']=='UNCERTAIN_BOUNDARY']
  require(saved['failing_service_ids']==bad and saved['uncertain_service_ids']==unc,'failed and uncertain endpoint ids preserved '+iid)
  prior=read(ROOT/f'input/{iid}_result.json')
  for method in ['nearest_neighbor','nn_2opt_budget']:
   old=saved['old_route_comparison'][method]
   status=next(x['status'] for x in oldconditions if x['instance_id']==iid and x['method']==method and x['radius_m']==1)
   require(old['old_length_m']==prior['methods'][method]['mapped_polyline_length_m'] and old['old_1m_clearance_status']==status,'old comparison copied accurately '+iid+' '+method)
  row={'instance_id':iid,'status':saved['status'],'services':services,'failing_service_ids':bad,'uncertain_service_ids':unc,'methods':[]}
  if bad:
   require(saved['status']=='TASK_INFEASIBLE' and saved['methods']=={},'infeasible tasks produce no routes '+iid)
   require(not list((ROOT/'raw').glob(iid+'_*_solver_output.json')),'no hidden solver outputs for infeasible '+iid)
   instances.append(row);continue
  if unc:
   require(saved['status']=='UNCERTAIN_ENDPOINT_NUMERICS' and saved['methods']=={},'uncertain tasks produce no routes '+iid);instances.append(row);continue
  require(saved['status']=='VALID_SAFE_ROUTES','endpoint-feasible instance valid status '+iid)
  graph=read(ROOT/f'raw/{iid}_graph.json');nodes=graph['nodes']; sn=graph['service_node_ids'];matrix=[[float(x) for x in r] for r in graph['distance_matrix']]
  require(nodes[:b]==bnodes and nodes[b:]==inst['coordinates'] and sn==list(range(b,len(nodes))),'graph vertices exactly original services '+iid)
  require(graph['new_visibility_checks']==sum(range(b,len(nodes))),'exhaustive added edge candidate count '+iid)
  adjacency=[[] for _ in nodes];edgeweights={}
  for a,c,w0 in base+graph['added_visibility_edges']:
   w=float(w0);require(abs(w-math.dist(list(map(float,nodes[a])),list(map(float,nodes[c]))))<=1e-8,'edge Euclidean weight '+iid+' '+str(a)+' '+str(c))
   adjacency[a].append((c,w));adjacency[c].append((a,w));edgeweights[min(a,c),max(a,c)]=w
  require(len(edgeweights)==graph['graph_edges'] and len(nodes)==graph['graph_nodes'],'graph counts '+iid)
  maxshort=0.
  for j,node in enumerate(sn):
   ds=shortest(adjacency,node,b)
   for k,target in enumerate(sn):
    require(math.isfinite(ds[target]),'independent finite graph connectivity '+iid)
    maxshort=max(maxshort,abs(ds[target]-matrix[j][k]));require(abs(matrix[j][k]-matrix[k][j])<=1e-8,'matrix symmetry '+iid)
  require(maxshort<=1e-8,'independent Dijkstra matrix agreement '+iid, maxshort)
  nntour=saved['methods']['nearest_neighbor']['route']
  remaining=set(range(1,inst['n']+1))
  for previous,chosen in zip(nntour,nntour[1:-1]):
   require(chosen==min(remaining,key=lambda q:(matrix[previous][q],q)),'NN saved decision minimum '+iid)
   remaining.remove(chosen)
  for method in ['nearest_neighbor','nn_2opt_budget']:
   route=saved['methods'][method];solver=read(ROOT/f'raw/{iid}_{method}_solver_output.json');audit=read(ROOT/f'raw/{iid}_{method}_route_audit.json')
   require(all(route[k]==v for k,v in solver.items()),'saved route equals frozen solver artifact '+iid+' '+method)
   tour=route['route']
   require(len(tour)==inst['n']+2 and tour[0]==tour[-1]==0 and collections.Counter(tour[1:-1])==collections.Counter(range(1,inst['n']+1)),'exact once service schedule '+iid+' '+method)
   if method=='nearest_neighbor':require(route['operations']['distance_candidates']==inst['n']*(inst['n']+1)//2,'NN candidate count '+iid)
   else:
    stats=route['operations'];tries=stats['candidate_reversals'];moves=stats['moves'];n=inst['n']
    require(stats['candidate_budget']==10000 and 0<=tries<=10000 and stats['accepted_moves']==len(moves),'2opt frozen budget and move counts '+iid)
    work=list(nntour);last_candidate=0
    for move in moves:
     lo,hi=move['i'],move['j']
     require(1<=lo<hi<=n and not (lo==1 and hi==n),'2opt legal recorded reversal '+iid)
     scan=[(i,j) for i in range(1,n) for j in range(i+1,n+1) if not (i==1 and j==n)]
     offset=scan.index((lo,hi))+1
     require(move['candidate']==last_candidate+offset and move['candidate']<=tries,'2opt recorded candidate positions '+iid)
     before=math.fsum(matrix[x][y] for x,y in zip(work,work[1:]))
     a,c,d,e=work[lo-1],work[lo],work[hi],work[hi+1]
     delta=math.fsum([matrix[a][d],matrix[c][e],-matrix[a][c],-matrix[d][e]])
     work[lo:hi+1]=list(reversed(work[lo:hi+1]))
     after=math.fsum(matrix[x][y] for x,y in zip(work,work[1:]))
     require(delta < -1e-9 and after<before,'2opt each saved move truly improving '+iid)
     require(abs(before-float(move['before_m']))<=1e-8 and abs(after-float(move['after_m']))<=1e-8 and abs(delta-float(move['delta_estimate_m']))<=1e-8,'2opt saved move length evidence '+iid)
     last_candidate=move['candidate']
    require(work==tour,'2opt saved moves reconstruct submitted tour '+iid)
    fullscan=n*(n-1)//2-1
    require((stats['termination']=='BUDGET_EXHAUSTED' and tries==10000) or (stats['termination']=='NO_IMPROVING_FULL_SWEEP' and tries-last_candidate==fullscan and tries<10000),'2opt termination count consistent with frozen scan '+iid)
   ids=route['mapped_polyline_node_ids'];coords=route['mapped_polyline_coordinates']
   require([nodes[k] for k in ids]==coords,'saved coordinate-node correspondence '+iid+' '+method)
   rebuilt=[]
   require(len(route['legs'])==len(tour)-1,'one saved leg per service transition '+iid+' '+method)
   for k,leg in enumerate(route['legs']):
    a,c=tour[k:k+2];p=leg['node_ids'];require(leg['service_leg']==[a,c] and p[0]==sn[a] and p[-1]==sn[c],'leg services and endpoints '+iid+' '+method)
    require(all(x<b for x in p[1:-1]),'no service-node interior transit '+iid+' '+method)
    require(p==graph['paths'][a][c],'saved leg equals matrix path '+iid+' '+method)
    require(all((min(x,y),max(x,y)) in edgeweights for x,y in zip(p,p[1:])),'saved path uses graph edges '+iid+' '+method)
    actual=math.fsum(edgeweights[min(x,y),max(x,y)] for x,y in zip(p,p[1:]));require(abs(actual-matrix[a][c])<=1e-8,'saved graph path length '+iid+' '+method)
    rebuilt.extend(p if k==0 else p[1:])
   require(ids==rebuilt and coords[0]==coords[-1]==inst['coordinates'][0],'complete polyline and depot closure '+iid+' '+method)
   pieces=[]
   for k,(a,c) in enumerate(zip(coords,coords[1:])):
    key=tuple(sorted((point(a),point(c))))
    if key not in cache:cache[key]=evaluate(*key,rings,edges)
    ev=cache[key];segment_uses+=1
    require(ev['clearance_status']=='PASS' and ev['full_segment_contained_proof'] and ev['all_three_holes_strictly_disjoint'],'exact entire segment 1m safe and three holes excluded '+iid+' '+method+' '+str(k))
    author=audit['segments'][k];require(author['a']==a and author['b']==c,'route audit coordinate identity '+iid+' '+method+' '+str(k))
    diff=abs(D(ev['distance_m_decimal'])-D(author['minimum_clearance_m']));max_delta=max(max_delta,diff);require(diff<=D('0.00000001'),'exact route distance agreement '+iid+' '+method+' '+str(k))
    pieces.append({'segment_index':k,'a':a,'b':c,**ev})
   length=math.fsum(math.dist(list(map(float,a)),list(map(float,c))) for a,c in zip(coords,coords[1:]));minimum=min(D(x['distance_m_decimal']) for x in pieces)
   require(abs(length-float(route['length_m']))<=1e-8 and abs(length-float(audit['mapped_length_m']))<=1e-8,'independent polyline lengths '+iid+' '+method)
   require(abs(minimum-D(route['minimum_clearance_m']))<=D('0.00000001'),'complete route minimum '+iid+' '+method)
   require(audit['status']=='VALID_SAFE_ROUTE' and route['clearance_status']=='VALID_SAFE_ROUTE' and len(audit['original_hole_checks'])==3 and all(x['intersection_empty'] for x in audit['original_hole_checks']),'saved route and holes labels '+iid+' '+method)
   rr={'instance_id':iid,'method':method,'status':'PASS_EXACT_SERIALIZED_GEOMETRY','service_schedule':tour,'length_m':length,'minimum_clearance_m_decimal':str(minimum),'segments':pieces,'independent_shortest_path_max_difference_m':maxshort}
   route_rows.append(rr);row['methods'].append({k:v for k,v in rr.items() if k!='segments'})
  require(saved['methods']['nn_2opt_budget']['length_m']<=saved['methods']['nearest_neighbor']['length_m']+D('0.00000001'),'within-new-constraint 2opt nonworse '+iid)
  instances.append(row)
 require(dict(collections.Counter(x['status'] for x in instances))==summary['status_counts'],'summary status totals')
 require(len(route_rows)==summary['routes_produced'],'summary route count')
 require(rawhash=={str(p.relative_to(ROOT)):sha(p) for p in sorted((ROOT/'raw').rglob('*')) if p.is_file()},'raw files unchanged throughout independent review')
 final={'status':'PASS_INDEPENDENT_SAVED_RESULT_AUDIT','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'method':'No author imports. Original WKT and saved JSON decimal tokens converted exactly to scaled integers. Exact segment intersections, winding containment, rational squared distances over every original edge, exact radius-band comparisons, independent graph shortest-path distances, saved NN decision checks, and 2opt saved move/scan-count verification. No alternative route is searched or generated.','scope_limitations':'Certifies saved decimal geometry only, not real surveying accuracy, physical vehicle dynamics or globally shortest continuous paths. 12 nested-prefix cases from 3 layouts, one field. No claim of pure algorithm improvement across changed old/new clearance constraints.','original_boundary_ring_edge_counts':[len(x) for x in rings],'instance_count':len(instances),'route_count':len(route_rows),'status_counts':dict(collections.Counter(x['status'] for x in instances)),'all_checks_pass':all(x['pass'] for x in checks),'check_count':len(checks),'exact_service_count':len(servicecache),'segment_uses':segment_uses,'exact_unique_segment_count':len(cache),'maximum_exact_vs_author_distance_difference_m_decimal':str(max_delta),'formal_execution_resources':run,'independent_review_resources':{'wall_seconds':time.perf_counter()-t,'cpu_seconds':time.process_time()-cpu,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},'instances':instances,'raw_file_hashes':rawhash,'reviewer_source_sha256':sha(pathlib.Path(__file__))}
 def dump(name,obj):(OUT/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False,default=lambda x:str(x) if isinstance(x,D) else x)+'\n')
 dump('INDEPENDENT_SAVED_RESULT_AUDIT.json',final);dump('INDEPENDENT_ROUTES_EXACT.json',route_rows);dump('INDEPENDENT_CHECKS.json',checks)
 print(json.dumps({k:v for k,v in final.items() if k not in ['instances','raw_file_hashes','method','scope_limitations']},indent=2,default=str))

if __name__=='__main__':
 parser=argparse.ArgumentParser();g=parser.add_mutually_exclusive_group(required=True);g.add_argument('--toy',action='store_true');g.add_argument('--saved-results',action='store_true');args=parser.parse_args()
 if args.toy:
  obj=toy();(OUT/'INDEPENDENT_GEOMETRY_TOY.json').write_text(json.dumps(obj,indent=2,default=str)+'\n');print('PASS independent synthetic exact-geometry tests')
 else:audit()
