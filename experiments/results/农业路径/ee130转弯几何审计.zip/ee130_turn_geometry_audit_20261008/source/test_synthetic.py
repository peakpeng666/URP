#!/usr/bin/python3
"""Synthetic inputs only. No real field, route or instance reads."""
import json, math, pathlib
from osgeo import ogr
import turn_audit as a
R=pathlib.Path(__file__).resolve().parents[1]
checks=[]
def check(name,condition):
    assert condition,name;checks.append(name)
def field(w):
    f=ogr.CreateGeometryFromWkt(w);hs=[]
    for i in range(1,f.GetGeometryCount()):
        p=ogr.Geometry(ogr.wkbPolygon);p.AddGeometry(f.GetGeometryRef(i));hs.append(p.Boundary())
    return f,f.Boundary(),hs
safe=field('POLYGON ((-20 -20,20 -20,20 20,-20 20,-20 -20))')
x,y,z=(-10,0),(0,0),(0,10)
t=a.turn(x,y,z);check('right_angle',abs(t['angle_rad']-math.pi/2)<1e-14 and abs(t['cutback_per_radius']-1)<1e-14)
check('collinear',a.turn((-1,0),(0,0),(1,0))['status']=='EXACT_FORWARD_COLLINEAR')
check('reversal',a.turn((-1,0),(0,0),(-1,0))['status']=='EXACT_REVERSAL_180')
check('near_collinear',a.turn((-1,0),(0,0),(1,1e-8))['status']=='NUMERICALLY_NEAR_COLLINEAR_NONZERO')
check('near_reversal',a.turn((-1,0),(0,0),(-1,1e-8))['status']=='NEAR_REVERSAL_ILL_CONDITIONED')
check('zero_length',a.turn((0,0),(0,0),(1,0))['status']=='DEGENERATE_ADJACENT_SEGMENT')
arc=a.arc_geometry(x,y,z,1,t);check('arc_sagitta',0<arc['sagitta_bound_m']<=1e-5)
check('tangent_points',math.dist(arc['start_tangent_point'],(-1,0))<1e-14 and math.dist(arc['end_tangent_point'],(0,1))<1e-14)
check('service_point_miss',abs(arc['vertex_to_arc_minimum_distance_formula_m']-(math.sqrt(2)-1))<1e-14)
check('safe_arc',a.arc_screen(arc,*safe)['status']=='LOCAL_ARC_CLEARANCE_PASS_NUMERIC_ENCLOSURE')
for xmax,expected in [(1.15,'LOCAL_ARC_CLEARANCE_PASS_NUMERIC_ENCLOSURE'),(1.1,'LOCAL_ARC_CLEARANCE_UNKNOWN'),(1.05,'LOCAL_ARC_CLEARANCE_FAIL_NUMERIC_ENCLOSURE')]:
    f=field(f'POLYGON ((-20 -20,{xmax} -20,{xmax} 20,-20 20,-20 -20))')
    check(f'threshold_{xmax}',a.arc_screen(arc,*f)['status']==expected)
holed=field('POLYGON ((-20 -20,20 -20,20 20,-20 20,-20 -20),(-0.4 0.2,-0.2 0.2,-0.2 0.4,-0.4 0.4,-0.4 0.2))')
check('arc_crosses_hole',a.arc_screen(arc,*holed)['status']=='LOCAL_ARC_CLEARANCE_FAIL_NUMERIC_ENCLOSURE')
in_hole=field('POLYGON ((-20 -20,20 -20,20 20,-20 20,-20 -20),(-5 -5,5 -5,5 5,-5 5,-5 -5))')
check('whole_arc_inside_hole_rejected',a.arc_screen(arc,*in_hole)['status']=='LOCAL_ARC_OUTSIDE_FIELD')
short=a.corner_record([(-0.5,0),(0,0),(0,0.5)],1,'scheduled_service',[1],*safe)
check('short_segments_fail',short['radius_screens'][1]['status']=='LOCAL_CUTBACK_EXCEEDS_ADJACENT_SEGMENT')
check('service_not_preserved',short['radius_screens'][1]['scheduled_point_visit_preserved_by_local_arc'] is False)
pts=[[-5,0],[0,0],[0,1],[5,1],[-5,0]]
inst={'instance_id':'synthetic','n':3,'coordinates':pts[:-1]}
route={'route':[0,1,2,3,0],'mapped_polyline_coordinates':pts,'mapped_polyline_node_ids':[0,1,2,3,0],
       'legs':[{'service_leg':[i,j],'node_ids':[i,j]} for i,j in zip([0,1,2,3],[1,2,3,0])]}
old={'segments':[{'segment_index':i,'a':p,'b':q,'minimum_clearance_m':a.line([p,q]).Distance(safe[1])} for i,(p,q) in enumerate(zip(pts,pts[1:]))],
     'complete_polyline_minimum_clearance_m':a.line(pts).Distance(safe[1])}
out=a.route_audit(inst,'synthetic',route,old,*safe)
check('shared_cutback_overlap',out['radius_summaries'][1]['shared_segments'][1]['status']=='SHARED_SEGMENT_OVERLAP')
check('all_services_remain_in_inventory',sum(len(v) for v in out['service_event_mapping'].values())==5)
check('terminal_duplicate_preserved',out['closed_terminal_duplicate_preserved'] and out['original_vertex_count_with_closure_duplicate']==5)
check('no_route_feasibility_claim',all(v['full_route_feasible_claim'] is False for v in out['radius_summaries']))
result={'status':'PASS','synthetic_only':True,'checks':checks,'check_count':len(checks)}
print(json.dumps(result,indent=2))
