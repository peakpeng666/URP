#!/usr/bin/python3
"""Read-only frozen-route geometric diagnostics. Never a route solver."""
import collections, datetime, hashlib, json, math, pathlib, resource, sys, time
from fractions import Fraction
from decimal import Decimal
from osgeo import ogr
ROOT = pathlib.Path(__file__).resolve().parents[1]
RADII = (0.5, 1.0, 2.0, 5.0)
ANGLE_TAU = 1e-6
LENGTH_TAU = 1e-8
CLEARANCE = 1.1
NUMERIC_TAU = 1e-8
SAGITTA_MAX = 1e-5
MAX_CHORDS = 4096
METHODS = ('nearest_neighbor', 'nn_2opt_budget')

def load(p):
    text=pathlib.Path(p).read_text()
    obj=json.loads(text)
    lexical=json.loads(text,parse_float=Decimal)
    # Assert that binary parsing followed by shortest-decimal serialization has
    # not changed any JSON decimal lexeme's exact rational value. Never silently
    # call float-derived coordinates exact if this roundtrip is lossy.
    def same(a,b):
        if isinstance(b,Decimal):assert Fraction(str(a))==Fraction(b), 'Decimal lexeme lost in JSON float roundtrip'
        elif isinstance(b,dict):
            for key,value in b.items():same(a[key],value)
        elif isinstance(b,list):
            for x,y in zip(a,b):same(x,y)
    same(obj,lexical)
    return obj
def save(p, obj):
    with pathlib.Path(p).open('x') as f:
        json.dump(obj, f, indent=2, ensure_ascii=False, allow_nan=False); f.write('\n')
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def exact(p): return tuple(Fraction(str(c)) for c in p)
def sub(a,b): return (a[0]-b[0],a[1]-b[1])
def norm(v): return math.hypot(*v)
def line(points):
    g = ogr.Geometry(ogr.wkbLineString)
    for p in points:g.AddPoint_2D(*p)
    return g

def turn(a,b,c):
    u,v = sub(b,a),sub(c,b)
    l1,l2 = norm(u),norm(v)
    out={'incoming_length_m':l1,'outgoing_length_m':l2}
    if l1<=LENGTH_TAU or l2<=LENGTH_TAU:
        return dict(out, status='DEGENERATE_ADJACENT_SEGMENT', angle_rad=None, angle_deg=None, cutback_per_radius=None,
                    exact_zero_incoming=(exact(a)==exact(b)),exact_zero_outgoing=(exact(b)==exact(c)))
    ea,eb,ec = exact(a),exact(b),exact(c)
    eu,ev=sub(eb,ea),sub(ec,eb)
    cross=eu[0]*ev[1]-eu[1]*ev[0];dot=eu[0]*ev[0]+eu[1]*ev[1]
    theta=math.atan2(float(cross),float(dot)); ab=abs(theta)
    out.update(angle_rad=theta,angle_deg=math.degrees(theta),exact_cross_zero=cross==0,exact_dot_sign=(dot>0)-(dot<0),cutback_per_radius=None)
    if cross==0 and dot>0:return dict(out,status='EXACT_FORWARD_COLLINEAR',cutback_per_radius=0.0)
    if cross==0 and dot<0:return dict(out,status='EXACT_REVERSAL_180',required_local_cutback='UNBOUNDED_FOR_POSITIVE_RADIUS')
    if ab<=ANGLE_TAU:return dict(out,status='NUMERICALLY_NEAR_COLLINEAR_NONZERO')
    if math.pi-ab<=ANGLE_TAU:return dict(out,status='NEAR_REVERSAL_ILL_CONDITIONED')
    k=math.tan(ab/2)
    return dict(out,status='ROBUST_NONZERO_CORNER',cutback_per_radius=k,local_radius_ceiling_by_lengths_m=min(l1,l2)/k)

def arc_geometry(a,b,c,R,info):
    """Only use for robust corner with cutback fitting both segments."""
    theta=info['angle_rad'];angle=abs(theta);t=R*info['cutback_per_radius'];sign=1 if theta>0 else -1
    u0=sub(b,a);v0=sub(c,b);u=tuple(x/info['incoming_length_m'] for x in u0);v=tuple(x/info['outgoing_length_m'] for x in v0)
    # Work relative to the original vertex to limit large-coordinate cancellation.
    start_rel=(-t*u[0],-t*u[1]);end_rel=(t*v[0],t*v[1])
    center_rel=(start_rel[0]-sign*R*u[1],start_rel[1]+sign*R*u[0])
    start_angle=math.atan2(start_rel[1]-center_rel[1],start_rel[0]-center_rel[0])
    delta_max=2*math.acos(1-SAGITTA_MAX/R)
    n=max(1,math.ceil(angle/delta_max))
    if n>MAX_CHORDS:return {'status':'UNKNOWN_CHORD_BUDGET','required_chords':n}
    points=[]
    for j in range(n+1):
        alpha=start_angle+theta*j/n
        points.append([b[0]+center_rel[0]+R*math.cos(alpha), b[1]+center_rel[1]+R*math.sin(alpha)])
    # Endpoint values from tangency formulas; deviation is included in residual guard.
    points[0]=[b[0]+start_rel[0],b[1]+start_rel[1]]
    points[-1]=[b[0]+end_rel[0],b[1]+end_rel[1]]
    center=[b[0]+center_rel[0],b[1]+center_rel[1]]
    radius_error=max(abs(math.dist(p,center)-R) for p in points)
    tangent_error=abs(norm(sub(points[-1],center))-R)
    sagitta=R*(1-math.cos(angle/(2*n)))
    return {'status':'ARC_CHORD_CHAIN_CREATED','radius_m':R,'cutback_m':t,'turn_rad':theta,'center':center,
            'start_tangent_point':points[0],'end_tangent_point':points[-1], 'chord_count':n,
            'sagitta_bound_m':sagitta,'radius_residual_max_m':radius_error,'end_radius_residual_m':tangent_error,
            'vertex_to_arc_minimum_distance_formula_m':R*(1/math.cos(angle/2)-1),
            'chord_coordinates':points}

def arc_screen(arc,field,boundary,hole_boundaries):
    if arc['status']!='ARC_CHORD_CHAIN_CREATED':return arc
    if arc['radius_residual_max_m']>NUMERIC_TAU or arc['sagitta_bound_m']>SAGITTA_MAX*(1+1e-8):
        return dict(arc,status='UNKNOWN_CONSTRUCTION_NUMERICS')
    g=line(arc['chord_coordinates']);d=g.Distance(boundary);diff=g.Difference(field)
    inside=diff is not None and diff.IsEmpty()
    eps=arc['sagitta_bound_m']+NUMERIC_TAU
    low=max(0.0,d-eps);high=d+eps
    # The entire chord chain, not only its vertices, is queried. Boundary distance
    # is 1-Lipschitz; the tube argument guarantees containment if the whole chord
    # chain is inside and farther from all boundaries than its error radius.
    if inside and low>CLEARANCE:status='LOCAL_ARC_CLEARANCE_PASS_NUMERIC_ENCLOSURE'
    elif high<CLEARANCE:status='LOCAL_ARC_CLEARANCE_FAIL_NUMERIC_ENCLOSURE'
    elif not inside and d>eps:status='LOCAL_ARC_OUTSIDE_FIELD'
    else:status='LOCAL_ARC_CLEARANCE_UNKNOWN'
    return dict(arc,status=status,chord_chain_inside_closed_field=inside,chord_chain_minimum_clearance_m=d,
                arc_clearance_lower_bound_m=low,arc_clearance_upper_bound_m=high,
                enclosure_total_error_m=eps,
                original_hole_boundary_clearance_m=[g.Distance(h) for h in hole_boundaries],
                geometry_interpretation='Floating-point numerical enclosure with analytic arc-chord error, not formal interval arithmetic or survey truth.')

def corner_record(points,index,role,service_ids,field,boundary,holes,seam=False):
    a=points[-2] if seam else points[index-1];b=points[index];c=points[index+1]
    info=turn(a,b,c)
    row={'vertex_index':index,'coordinate':b,'role':role,'service_ids':service_ids,'cyclic_seam_only':seam,**info,'radius_screens':[]}
    for R in RADII:
        rec={'radius_m':R,'assumption':'Sensitivity value, not actual vehicle parameter'}
        if info['status']=='EXACT_FORWARD_COLLINEAR':rec.update(status='NO_TURN_NEEDED',cutback_m=0.0)
        elif info['status']!='ROBUST_NONZERO_CORNER':rec.update(status='NOT_EVALUATED_'+info['status'])
        else:
            t=R*info['cutback_per_radius'];slack=min(info['incoming_length_m'],info['outgoing_length_m'])-t
            rec.update(cutback_m=t,minimum_side_slack_m=slack,
                       removes_original_vertex=True,
                       scheduled_point_visit_preserved_by_local_arc=False if service_ids else None,
                       local_vertex_miss_m=R*(1/math.cos(abs(info['angle_rad'])/2)-1))
            if slack < -LENGTH_TAU:rec.update(status='LOCAL_CUTBACK_EXCEEDS_ADJACENT_SEGMENT')
            elif slack <= LENGTH_TAU:rec.update(status='UNKNOWN_CUTBACK_NUMERIC_THRESHOLD')
            else:rec.update(arc_screen(arc_geometry(a,b,c,R,info),field,boundary,holes))
        row['radius_screens'].append(rec)
    return row

def route_audit(instance,method,route,old,field,boundary,holes):
    pts=route['mapped_polyline_coordinates'];ids=route['mapped_polyline_node_ids'];order=route['route'];legs=route['legs']
    assert len(ids)==len(pts) and pts[0]==pts[-1] and order[0]==order[-1]==0
    assert sorted(order[1:-1])==list(range(1,instance['n']+1))
    assert len(legs)==len(order)-1
    service_by_vertex=collections.defaultdict(list);offset=0;rebuilt=[]
    for leg,(s,t) in zip(legs,zip(order,order[1:])):
        assert leg['service_leg']==[s,t]
        nodes=leg['node_ids'];assert nodes[0]==ids[offset]
        assert exact(pts[offset])==exact(instance['coordinates'][s])
        service_by_vertex[offset].append(s)
        rebuilt.extend(nodes if not rebuilt else nodes[1:]);offset+=len(nodes)-1
        assert exact(pts[offset])==exact(instance['coordinates'][t])
    service_by_vertex[offset].append(0);assert rebuilt==ids and offset==len(pts)-1
    assert len(old['segments'])==len(pts)-1
    segs=[]
    for i,(a,b) in enumerate(zip(pts,pts[1:])):
        prior=old['segments'][i];assert prior['segment_index']==i and prior['a']==a and prior['b']==b
        segs.append({'segment_index':i,'length_m':math.dist(a,b),'exact_zero_length':exact(a)==exact(b),
                     'prior_whole_segment_clearance_m':prior['minimum_clearance_m'],
                     'prior_whole_segment_excess_above_1_1m':prior['minimum_clearance_m']-CLEARANCE})
    vertices=[]
    for i in range(1,len(pts)-1):
        svc=service_by_vertex.get(i,[]);role='scheduled_service' if svc else 'transit_vertex'
        row=corner_record(pts,i,role,svc,field,boundary,holes)
        row['incoming_prior_segment_clearance_m']=segs[i-1]['prior_whole_segment_clearance_m']
        row['outgoing_prior_segment_clearance_m']=segs[i]['prior_whole_segment_clearance_m']
        vertices.append(row)
    seam=corner_record(pts,0,'depot_closed_seam_optional',[0],field,boundary,holes,seam=True)
    byindex={r['vertex_index']:r for r in vertices}
    screens=[]
    for ri,R in enumerate(RADII):
        shared=[]
        for i,s in enumerate(segs):
            rec={'segment_index':i,'length_m':s['length_m']}
            # A one-shot traversal has zero endpoint cutbacks. The optional cyclic
            # seam is explicitly reported but not imposed as a boundary condition.
            left=0.0 if i==0 else byindex[i]['radius_screens'][ri].get('cutback_m')
            right=0.0 if i+1==len(pts)-1 else byindex[i+1]['radius_screens'][ri].get('cutback_m')
            if left is None or right is None:rec.update(status='UNKNOWN_DUE_TO_DEGENERATE_OR_NEAR_COLLINEAR_VERTEX')
            else:
                slack=s['length_m']-left-right
                rec.update(incoming_corner_cutback_m=left,outgoing_corner_cutback_m=right,remaining_segment_m=slack,
                           status='SHARED_SEGMENT_FITS' if slack>LENGTH_TAU else ('SHARED_SEGMENT_OVERLAP' if slack < -LENGTH_TAU else 'SHARED_SEGMENT_THRESHOLD_UNKNOWN'))
            shared.append(rec)
        screens.append({'radius_m':R,'local_corner_status_counts':dict(collections.Counter(v['radius_screens'][ri]['status'] for v in vertices)),
                        'shared_segments':shared,'shared_segment_status_counts':dict(collections.Counter(s['status'] for s in shared)),
                        'scheduled_service_corners_cut_off':sum(v['role']=='scheduled_service' and v['status']=='ROBUST_NONZERO_CORNER' for v in vertices),
                        'full_route_feasible_claim':False})
    g=line(pts);d=g.Distance(boundary);diff=g.Difference(field)
    assert abs(d-old['complete_polyline_minimum_clearance_m'])<=NUMERIC_TAU
    return {'instance_id':instance['instance_id'],'method':method,'original_route':route,
            'original_vertex_count_with_closure_duplicate':len(pts),'original_segment_count':len(pts)-1,
            'closed_terminal_duplicate_preserved':True,'zero_length_segments':[s['segment_index'] for s in segs if s['exact_zero_length']],
            'service_event_mapping':dict(service_by_vertex),'segments':segs,'interior_vertices':vertices,'optional_cyclic_depot_seam':seam,
            'one_shot_start_end_orientations_unspecified':True,
            'interior_turn_status_counts':dict(collections.Counter(v['status'] for v in vertices)),
            'robust_nonzero_service_corners':sum(v['role']=='scheduled_service' and v['status']=='ROBUST_NONZERO_CORNER' for v in vertices),
            'original_whole_polyline_clearance_m':d,'original_whole_polyline_inside_closed_field':diff is not None and diff.IsEmpty(),
            'exact_polyline_positive_speed_bounded_curvature_status':'NOT_TRACKABLE_AS_SAVED' if any(v['status'] in ('ROBUST_NONZERO_CORNER','EXACT_REVERSAL_180') for v in vertices) else 'NOT_ESTABLISHED',
            'radius_summaries':screens,'actual_vehicle_executability':'UNKNOWN_NO_VEHICLE_MODEL_OR_PHYSICAL_VALIDATION'}

def formal():
    start=time.perf_counter();cpu=time.process_time()
    field=ogr.CreateGeometryFromWkt((ROOT/'input/projected_epsg32634.wkt').read_text());assert field.IsValid() and field.GetGeometryCount()==4
    boundary=field.Boundary();holes=[]
    for i in range(1,4):
        p=ogr.Geometry(ogr.wkbPolygon);p.AddGeometry(field.GetGeometryRef(i));holes.append(p.Boundary())
    prior=load(ROOT/'input/prior/results.json');known={r['instance_id']:r for r in prior['instances']};rows=[];routes=[]
    for ip in sorted((ROOT/'input/instances').glob('*_input.json')):
        inst=load(ip);name=inst['instance_id'];previous=known[name]
        for method in METHODS:
            if time.perf_counter()-start>55:raise TimeoutError('Nested formal deadline exceeded')
            rp=ROOT/f'input/routes/{name}_{method}_solver_output.json'
            base={'instance_id':name,'n':inst['n'],'seed':inst['seed'],'method':method,'prior_task_status':previous['status']}
            if not rp.exists():
                assert previous['status']=='TASK_INFEASIBLE'
                rows.append(dict(base,status='NO_ROUTE_PRIOR_ENDPOINT_INFEASIBILITY',failing_service_ids=previous['failing_service_ids']));continue
            route=load(rp);old=load(ROOT/f'input/route_audits/{name}_{method}_route_audit.json')
            out=route_audit(inst,method,route,old,field,boundary,holes)
            filename=f'{name}_{method}_turn_audit.json';save(ROOT/'raw'/filename,out);routes.append(out)
            rows.append(dict(base,status='SAVED_POLYLINE_AUDITED',raw_file=filename,
                             exact_polyline_status=out['exact_polyline_positive_speed_bounded_curvature_status'],
                             corner_counts=out['interior_turn_status_counts'],service_corner_count=out['robust_nonzero_service_corners']))
    assert len(rows)==24 and len(routes)==8
    result={'status':'COMPLETE_UNAUDITED','all_instance_count':12,'all_instance_method_count':24,'routes_audited':len(routes),
            'prior_endpoint_infeasible_instances':len({r['instance_id'] for r in rows if r['status']=='NO_ROUTE_PRIOR_ENDPOINT_INFEASIBILITY'}),
            'rows':rows,'interior_corner_totals':dict(sum((collections.Counter(r['interior_turn_status_counts']) for r in routes),collections.Counter())),
            'exact_saved_polyline_not_trackable_count':sum(r['exact_polyline_positive_speed_bounded_curvature_status']=='NOT_TRACKABLE_AS_SAVED' for r in routes),
            'formal_wall_seconds':time.perf_counter()-start,'formal_cpu_seconds':time.process_time()-cpu,
            'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            'parameters':{'radii_m':RADII,'angle_tau_rad':ANGLE_TAU,'length_tau_m':LENGTH_TAU,'clearance_m':CLEARANCE,'numeric_tau_m':NUMERIC_TAU,'sagitta_max_m':SAGITTA_MAX},
            'limitations':['Sensitivity radii are not actual vehicle dimensions.','A local arc PASS is not a full route feasibility result.','Exact service point constraints are not replaced by neighborhood visits.','No replacement solution, dynamics, steering-rate limits or real-vehicle test.','Closed depot seam separately reported; no periodic heading assumption imposed.']}
    save(ROOT/'raw/results.json',result)

if __name__=='__main__':
    if sys.argv[1:]!=['--formal']:raise SystemExit('Only --formal supported; run via guarded run_once.py')
    formal()
