#!/usr/bin/python3
"""Seal append-only PREEXEC, raw or final archive; never evaluate routes."""
import datetime,hashlib,json,pathlib,sys,zipfile
R=pathlib.Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):
    with p.open('x') as f:json.dump(x,f,indent=2,ensure_ascii=False);f.write('\n')
stage=sys.argv[1]
if stage=='PREEXECUTION':
    assert not list((R/'raw').iterdir())
    assert json.loads((R/'independent_review/evidence/STATIC_PREEXEC_REVIEW.json').read_text())['status']=='PASS_STATIC_PREEXEC_REVIEW'
    frozen={str(p.relative_to(R)):sha(p) for p in sorted(R.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
    write(R/'freeze/PREEXECUTION_FREEZE.json',{'stage':'PREEXECUTION','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':frozen})
elif stage=='RAW_COMPLETE_UNAUDITED':
    assert (R/'evidence/RUN_STATUS.json').exists()
    write(R/'evidence/RAW_COMPLETE_UNAUDITED_MANIFEST.json',{'stage':stage,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':{str(p.relative_to(R)):sha(p) for p in sorted((R/'raw').rglob('*')) if p.is_file()}})
elif stage=='FINAL':
    write(R/'evidence/FINAL_CONTENT_MANIFEST.json',{'stage':stage,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':{str(p.relative_to(R)):sha(p) for p in sorted(R.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}})
else:raise SystemExit('Unknown stage')
z=R.parent/(R.name+'_'+stage+'_SNAPSHOT.zip')
with zipfile.ZipFile(z,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as out:
    for p in sorted(R.rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts:out.write(p,R.name+'/'+str(p.relative_to(R)))
print(json.dumps({'path':str(z),'sha256':sha(z),'bytes':z.stat().st_size,'stage':stage,'freeze_sha256':sha(R/'freeze/PREEXECUTION_FREEZE.json')}))
