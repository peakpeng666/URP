#!/usr/bin/python3
"""Describe saved and independently audited evidence, without running a planner."""
import collections,hashlib,json,pathlib,statistics
R=pathlib.Path(__file__).resolve().parents[1]
def read(p):return json.loads((R/p).read_text())
def write(p,x):
    with (R/p).open('x') as f:f.write(x)
def h(p):return hashlib.sha256((R/p).read_bytes()).hexdigest()
raw=read('raw/results.json');review=read('independent_review/evidence/INDEPENDENT_SAVED_RECOMPUTATION.json')
assert review['status']=='PASS_INDEPENDENT_SAVED_RECOMPUTATION',review['status']
pre=read('evidence/PREEXECUTION_DRIVE_RECEIPT.json');receipt=read('evidence/RAW_DRIVE_RECEIPT.json')
assert receipt['verified'] and receipt['download_byte_identical']
routes=[read('raw/'+r['raw_file']) for r in raw['rows'] if r['status']=='SAVED_POLYLINE_AUDITED']
route_rows=[];radius_rows=[];all_vertices=[]
for r in routes:
    vs=r['interior_vertices'];all_vertices.extend(vs);angles=[abs(v['angle_deg']) for v in vs if v['angle_deg'] is not None]
    route_rows.append({'instance_id':r['instance_id'],'method':r['method'],'original_segments':r['original_segment_count'],
                       'robust_internal_corners':r['interior_turn_status_counts'].get('ROBUST_NONZERO_CORNER',0),
                       'scheduled_service_corner_occurrences':r['robust_nonzero_service_corners'],
                       'min_abs_turn_deg':min(angles),'max_abs_turn_deg':max(angles),
                       'original_full_polyline_clearance_m':r['original_whole_polyline_clearance_m'],
                       'saved_polyline_positive_speed_bounded_curvature':r['exact_polyline_positive_speed_bounded_curvature_status']})
for ri,Rm in enumerate(raw['parameters']['radii_m']):
    local=collections.Counter();shared=collections.Counter();low=[]
    for r in routes:
        local.update(r['radius_summaries'][ri]['local_corner_status_counts']);shared.update(r['radius_summaries'][ri]['shared_segment_status_counts'])
        for v in r['interior_vertices']:
            rec=v['radius_screens'][ri]
            if 'arc_clearance_lower_bound_m' in rec:low.append(rec['arc_clearance_lower_bound_m'])
    radius_rows.append({'assumed_radius_m':Rm,'internal_corner_occurrences':156,'local_arc_clearance_pass':local.get('LOCAL_ARC_CLEARANCE_PASS_NUMERIC_ENCLOSURE',0),
                        'local_cutback_length_fail':local.get('LOCAL_CUTBACK_EXCEEDS_ADJACENT_SEGMENT',0),
                        'local_clearance_fail':local.get('LOCAL_ARC_CLEARANCE_FAIL_NUMERIC_ENCLOSURE',0),
                        'shared_segment_occurrences':164,'shared_segment_overlap':shared.get('SHARED_SEGMENT_OVERLAP',0),
                        'minimum_constructed_arc_clearance_lower_bound_m':min(low),
                        'service_vertex_occurrences_that_would_be_removed_by_nonzero_fillet':96,'full_path_feasibility_established':False})
summary={'status':'COMPLETE_WITH_INDEPENDENT_AUDIT','all_instances':12,'all_instance_method_combinations':24,'saved_routes':8,'endpoint_infeasible_instances':8,
         'counting_unit':'Occurrences across8 saved routes; not deduplicated physical vertices/services and not independent samples.',
         'route_rows':route_rows,'radius_rows':radius_rows,'all_24_conditions':raw['rows'],
         'source_raw_sha256':h('raw/results.json'),'independent_review_sha256':h('independent_review/evidence/INDEPENDENT_SAVED_RECOMPUTATION.json'),
         'not_a_new_route':True,'not_real_vehicle_validation':True}
write('reports/summary.json',json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
write('reports/all_24_conditions.json',json.dumps(raw['rows'],ensure_ascii=False,indent=2)+'\n')
lines=['# 现有折线路线的转弯几何审计','',
'日期：2026-10-08。审计上轮1.10米净空下保存的8条路线，不生成替代路线。',
'', '## 结论', '',
'8条保存折线都有稳健非零内部转角，因此在正速度、有限曲率的前向车辆模型下，不能按原折线精确跟踪。这不证明固定任务不存在另一条满足曲率约束的路径，也不适用于把停车和原地转动作为合法动作的全部平台。实际车辆模型与参数尚未知，本轮没有实车验证。',
'',
'共记录156次内部转角，其中96次发生在调度服务点。这里是8条路线上的出现次数，并未对重复路线节点、嵌套任务或方法间共同服务点去重；不是156个独立样本，也不是96个不同物理服务点。所有12实例、24个实例×方法组合完整保留：4实例有这8条路线，另8实例仍因先前服务端点净空不够而没有路线。',
'',
'固定假设转弯半径0.5、1、2、5米均只是敏感性参数。能放入各自相邻线段且实际构造出的局部圆弧都通过1.10米净空筛查，本轮没有发现这些局部圆弧碰撞。观察到的限制是相邻倒角争用同一线段，以及倒角不经过原精确服务点。不能为了强调转弯问题而把没有发生的碰撞当作结果。',
'', '## 逐条原路线', '',
'内部角不包含另行保存的depot闭环接缝；一次出发并返回的任务并未给出必须连续循环的朝向约束。', '',
'| 实例 | 方法 | 内部转角出现次数 | 其中服务点 | 最小转角 ° | 最大转角 ° | 原折线最小净空 m |',
'|---|---|---:|---:|---:|---:|---:|']
for r in route_rows:
    method='NN' if r['method']=='nearest_neighbor' else '2-opt'
    lines.append(f"| {r['instance_id']} | {method} | {r['robust_internal_corners']} | {r['scheduled_service_corner_occurrences']} | {r['min_abs_turn_deg']:.6f} | {r['max_abs_turn_deg']:.6f} | {r['original_full_polyline_clearance_m']:.9f} |")
lines+=['','全部156个内部顶点均属于稳健非零角。精确前向共线、精确180度反向、近共线、近反向和相邻零长退化点本数据中均为0；这些类别已在协议及合成测试中保留。8个首尾坐标重合的闭合终点记号保留，没有静默去重。8个可选depot接缝另存，不纳入156的分母。',
'', '## 预先固定半径的局部筛查', '',
'每一行的角分母都是156次内部角，段分母都是164次原线段出现。不同半径重复评估相同几何，不能合并成独立试验样本。局部净空通过与共享段重叠不是互斥分类。', '',
'| 假设半径 m | 局部圆弧净空通过 / 156角 | 单角退让超长 / 156角 | 共享段倒角重叠 / 164段 | 已构造弧最小净空下界 m |',
'|---:|---:|---:|---:|---:|']
for r in radius_rows:
    lines.append(f"| {r['assumed_radius_m']:g} | {r['local_arc_clearance_pass']} | {r['local_cutback_length_fail']} | {r['shared_segment_overlap']} | {r['minimum_constructed_arc_clearance_lower_bound_m']:.9f} |")
lines+=['',
'各半径的局部净空失败数均为0。半径2米有1个角、5米有49个角因单角退让超过相邻线段而没有构造圆弧，其净空未测；不能把未构造者算作净空通过。0.5米的156个局部弧及164条共享段都通过各自筛查，仍不等于生成了一条合格路线。',
'',
'一个能说明“逐角通过不等于同时可用”的例子：n20_s202610081001 的NN路线第33号线段长13.416407865米。在R=1米时，两端角分别需要0.165547897米与13.260854395米退让，合计超过该段约0.009994427米。两个局部弧各自都能放入各自两侧线段，且各自净空通过，但同时倒角会争用约1厘米同一段。该路线第34号内部顶点为171.374984度转角，两侧段长13.416408米与61.499234米，仅从相邻段长度得到的单角半径上限约1.011730米。',
'',
'服务点约束是另一独立问题。现有科研模型要求按调度访问精确原坐标，非零角的相切圆弧不会经过原顶点，其最近缺口为R(sec(|θ|/2)−1)>0。因此96次服务点转角若直接倒角，原调度位置就不再保留；附近通过不能替代精确访问。这并未假定实际作业必须停车，也未替用户指定一个实际服务半径。即便其他路径部分偶然再次经过同坐标，本轮也没有把它当作原调度事件得到满足。',
'', '## 数学与数值边界', '',
'先以保存JSON十进制值的精确有理叉积和点积区分共线、反向；读取时核验十进制lexeme经float再序列化没有改变其有理值。非零转角再与1e−6弧度阈值比较，近共线留为未知而不默删；靠近180度的点不套用病态倒角公式。精确反向的正半径局部相切倒角退让无界。',
'',
'普通角的退让为t=R tan(|θ|/2)。除了检t与两侧长度，还逐原共享段检两端t之和。长度比较的数值带为1e−8米，跨阈值保留未知。假设半径表示相切圆弧的半径，不代表已知实车尺寸。圆弧和直线相切也仍会在连接处产生曲率跳变；本轮不检转向速率和动态跟踪。',
'',
'圆弧按固定最大弓高1e−5米生成弦串，实际弓高e=R[1−cos(|θ|/(2n))]。查询的是完整弦串对原外边界及三个孔洞边界的最小距离D，不只查询采样点。由距离函数的1-Lipschitz性质，整弧净空用[max(0,D−e−1e−8),D+e+1e−8]作数值包围。通过还要求完整弦串在原闭地块内且下界严格超过1.10米，以边界距离管状邻域约束整弧包含性；孔内或地块外不会因距边界很远而通过。这是解析几何误差加浮点容差，不是机器认证区间算术，也不是测绘真值。',
'', '## 独立验证与资源', '',
'执行前：作者21项合成测试、独立主逻辑39项与解析几何原语106项合成测试通过。静态复核核对输入逐字节身份与上游不变性；源代码、输入、协议先冻结，PREEXEC私有Drive逐字节回读通过才进行一次正式计算。原始结果产生后先立即封为COMPLETE_UNAUDITED并私有备份回读，随后才解读与独审。',
'',
f"独立保存结果复算通过，未导入或重跑作者实验。共10252项检查，重算156次内部顶点、605个已构造局部圆弧（574个内部角圆弧，31个单列depot接缝圆弧）。独审以圆弧端点、边段端点、交点及公共法线极值解析复算对全部边界段的距离；所有解析净空都落在作者保存的弦串误差区间内，最大越界为0。独审只用GDAL解析WKT，不重用作者的弦串距离算法。",
'',
f"预先正式预算30秒CPU、60秒wall、512MiB，一次执行。主诊断实际CPU {raw['formal_cpu_seconds']:.6f}秒、wall {raw['formal_wall_seconds']:.6f}秒、峰值RSS {raw['peak_rss_kib']}KiB；独审另计约0.656秒。没有参数重调、实际实验重跑、模型调用、新依赖安装或旧证据修改。单次计时不是性能统计推断。",
'', '## 证据入口', '',
'- [执行前冻结包](https://drive.google.com/file/d/1EeSC1nOflaq576gL-9OE7ibrR-juWzb0/view?usp=drivesdk)',
'- [原始未审时点包](https://drive.google.com/file/d/12t2t6CQylG03iOJWE4i9k3QXd_bkW2hF/view?usp=drivesdk)',
'- freeze/ 保存预定协议、输入身份与冻结清单；source/ 保存源码；raw/ 保存全部原路线、顶点、共享段与完整弦串坐标；reports/all_24_conditions.json 保留全部失败组合；independent_review/ 保存独立审查源码与证据。',
'', '## 运动学参考', '',
'- [LaValle 13.1.2.1 简单车模型](https://msl.cs.illinois.edu/~lavalle/planning/node658.html)：朝向属于配置，转弯半径受转向约束。',
'- [LaValle 13.1.2.2 差动驱动](https://msl.cs.illinois.edu/~lavalle/planning/node659.html)：某些平台允许停车原地转动；这不等同于实际硬件保证。',
'- [LaValle 14.6.2 规划后变换](https://msl.cs.uiuc.edu/planning/node788.html)：尖角与Dubins车约束冲突，局部变换还须匹配朝向并独立检碰撞。',
'- [LaValle 15.3.1 Dubins曲线](https://msl.cs.illinois.edu/~lavalle/planning/node821.html)：正向固定速度、有界曲率模型背景。本轮没有实现Dubins求解器。',
'',
'下一步若要建立实际车辆结论，应先给出车辆参考点与外形、最小转弯半径/轴距转角、可否倒车或原地转、起终朝向及服务点访问定义，再针对那些明确约束规划和验证。本轮不自行假定这些参数，不以局部倒角诊断取代下一阶段。','']
write('reports/REPORT_zh.md','\n'.join(lines))
write('README_zh.md','# 现有折线路线转弯几何审计\n\n先读 reports/REPORT_zh.md 与 reports/summary.json。8条路线均有非零内部尖角，不能按原折线作正速度有限曲率跟踪；这不证明原任务无曲率可行路径。固定半径局部诊断没有产生替代路线，没有实车验证。\n\n本包保留12实例、24方法组合、一次正式执行、执行前冻结与RAW归档回读、独立解析保存结果复核。服务点保持现模型精确坐标语义；不替实际车辆作参数假定。\n')
write('evidence/REPORT_BINDINGS.json',json.dumps({'status':'SAVED_RESULTS_REPORT_CREATED','raw_results_sha256':h('raw/results.json'),'independent_review_sha256':h('independent_review/evidence/INDEPENDENT_SAVED_RECOMPUTATION.json'),'report_sha256':h('reports/REPORT_zh.md'),'summary_sha256':h('reports/summary.json')},indent=2)+'\n')
print('Report saved')
