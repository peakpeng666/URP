#!/usr/bin/python3
"""Unique formal audit guarded by immutable freeze and private Drive readback."""
import datetime, hashlib, json, os, pathlib, resource, subprocess, time, zipfile
R=pathlib.Path(__file__).resolve().parents[1]
def save(p,x):
    with (R/p).open('x') as f:json.dump(x,f,indent=2,ensure_ascii=False);f.write('\n')
def load(p):return json.loads((R/p).read_text())
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
freeze=load('freeze/PREEXECUTION_FREEZE.json')
for p,h in freeze['files'].items():assert sha(R/p)==h,p
receipt=load('evidence/PREEXECUTION_DRIVE_RECEIPT.json')
assert receipt['verified'] and receipt['download_byte_identical'] and receipt['permissions']=='owner_only' and receipt['shared'] is False
archive=R.parent/(R.name+'_PREEXECUTION_SNAPSHOT.zip')
assert receipt['sha256']==receipt['download_sha256']==sha(archive)
assert int(receipt['bytes'])==archive.stat().st_size
with zipfile.ZipFile(archive) as package:
    assert package.read(R.name+'/freeze/PREEXECUTION_FREEZE.json')==(R/'freeze/PREEXECUTION_FREEZE.json').read_bytes(), 'Uploaded freeze differs from local freeze'
assert load('evidence/SYNTHETIC_TESTS.json')['status']=='PASS'
assert load('independent_review/evidence/STATIC_PREEXEC_REVIEW.json')['status']=='PASS_STATIC_PREEXEC_REVIEW'
assert not list((R/'raw').iterdir())
save('evidence/STARTED.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'attempt':1,'pid':os.getpid(),'preexec_sha256':sha(archive),'receipt_sha256':sha(R/'evidence/PREEXECUTION_DRIVE_RECEIPT.json')})
def limits():
    resource.setrlimit(resource.RLIMIT_CPU,(30,30));resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912))
start=time.perf_counter();before=resource.getrusage(resource.RUSAGE_CHILDREN);rc=None
try:
    with (R/'evidence/STDOUT.log').open('x') as out,(R/'evidence/STDERR.log').open('x') as err:
        proc=subprocess.run(['/usr/bin/python3',str(R/'source/turn_audit.py'),'--formal'],stdout=out,stderr=err,timeout=60,preexec_fn=limits,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1'})
    rc=proc.returncode;status='COMPLETE_UNAUDITED' if rc==0 and (R/'raw/results.json').exists() else 'TECHNICAL_FAILURE'
except subprocess.TimeoutExpired:status='RESOURCE_TIMEOUT'
except Exception as e:status='TECHNICAL_FAILURE';save('evidence/EXCEPTION.json',{'error':str(e)})
if status!='COMPLETE_UNAUDITED':
    inputs=sorted((R/'input/instances').glob('*_input.json'))
    save('raw/INCOMPLETE_EXECUTION_INDEX.json',{'status':status,'combinations':[{'instance_id':json.loads(p.read_text())['instance_id'],'method':m,'status':'NOT_ESTABLISHED_AFTER_ABORT'} for p in inputs for m in ('nearest_neighbor','nn_2opt_budget')],'no_rerun':True})
r=resource.getrusage(resource.RUSAGE_CHILDREN)
save('evidence/RUN_STATUS.json',{'status':status,'exit_code':rc,'unique_formal_execution':True,'wall_seconds':time.perf_counter()-start,'child_cpu_seconds':r.ru_utime+r.ru_stime-before.ru_utime-before.ru_stime,'peak_rss_kib':r.ru_maxrss})
print(status)
raise SystemExit(0 if status=='COMPLETE_UNAUDITED' else 1)
