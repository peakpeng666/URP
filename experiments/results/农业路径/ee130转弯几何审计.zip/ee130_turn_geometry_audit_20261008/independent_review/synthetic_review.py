#!/usr/bin/python3
"""Independent synthetic-only tests. Does not load experiment instances."""
import hashlib, importlib.util, json, math, pathlib, resource, sys, time
sys.dont_write_bytecode=True
resource.setrlimit(resource.RLIMIT_CPU,(30,30))
resource.setrlimit(resource.RLIMIT_AS,(512*1024*1024,512*1024*1024))
ROOT=pathlib.Path(__file__).resolve().parents[1]
SOURCE=ROOT/'source/turn_audit.py'
spec=importlib.util.spec_from_file_location('reviewed_turn',SOURCE)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
checks=[]
def check(name,condition,detail=None):
    checks.append({'name':name,'pass':bool(condition),'detail':detail})
    assert condition,name
def close(a,b,tol=1e-9):return abs(a-b)<=tol
def makearc(a,b,c,r=1.):return m.arc_geometry(a,b,c,r,m.turn(a,b,c))
start=time.monotonic();cpu=time.process_time()
check('forward exact decimal collinear',m.turn([0,0],[1,1],[2,2])['status']=='EXACT_FORWARD_COLLINEAR')
check('opposite exact decimal collinear',m.turn([0,0],[1,1],[0,0])['status']=='EXACT_REVERSAL_180')
check('duplicate incoming',m.turn([0,0],[0,0],[1,0])['exact_zero_incoming'])
check('tiny nonzero segment separately degenerate',m.turn([0,0],[1e-9,0],[1,0])['status']=='DEGENERATE_ADJACENT_SEGMENT')
check('near forward remains nonzero',m.turn([0,0],[1,0],[2,1e-7])['status']=='NUMERICALLY_NEAR_COLLINEAR_NONZERO')
check('near reverse safely skipped',m.turn([0,0],[1,0],[0,1e-7])['status']=='NEAR_REVERSAL_ILL_CONDITIONED')
for sign in [-1,1]:
    a,b,c=[-10,0],[0,0],[0,10*sign]
    info=m.turn(a,b,c);arc=makearc(a,b,c)
    check(f'{sign} right-angle signed heading',close(info['angle_rad'],sign*math.pi/2))
    check(f'{sign} tangent setback',close(arc['cutback_m'],1))
    check(f'{sign} tangent points',math.dist(arc['start_tangent_point'],[-1,0])<1e-9 and math.dist(arc['end_tangent_point'],[0,sign])<1e-9)
    check(f'{sign} center',math.dist(arc['center'],[-1,sign])<1e-9)
    check(f'{sign} service miss analytical',close(arc['vertex_to_arc_minimum_distance_formula_m'],math.sqrt(2)-1))
    check(f'{sign} sagitta within bound',0<arc['sagitta_bound_m']<=1e-5)
    # Verify midpoint deviation for every chord using an independent radial norm.
    deviations=[]
    for p,q in zip(arc['chord_coordinates'],arc['chord_coordinates'][1:]):
        middle=[(p[k]+q[k])/2 for k in range(2)]
        deviations.append(1-math.dist(middle,arc['center']))
    check(f'{sign} all chord-midpoint errors',max(abs(d-arc['sagitta_bound_m']) for d in deviations)<1e-12)

big=makearc([499990,5000000],[500000,5000000],[500000,5000010],5)
check('UTM-size residual guard',big['radius_residual_max_m']<1e-8,big['radius_residual_max_m'])
field=m.ogr.CreateGeometryFromWkt('POLYGON ((-20 -20,20 -20,20 20,-20 20,-20 -20), (5 5,5 10,10 10,10 5,5 5))')
boundary=field.Boundary()
arc=makearc([-10,0],[0,0],[0,10])
screen=m.arc_screen(arc,field,boundary,[])
check('whole arc interior clearance pass',screen['status']=='LOCAL_ARC_CLEARANCE_PASS_NUMERIC_ENCLOSURE')
insidehole=makearc([6,6],[9,6],[9,9],.5)
check('hole interior not pass',m.arc_screen(insidehole,field,boundary,[])['status']!='LOCAL_ARC_CLEARANCE_PASS_NUMERIC_ENCLOSURE')
outside=makearc([25,25],[30,25],[30,30])
check('distant exterior labeled outside',m.arc_screen(outside,field,boundary,[])['status']=='LOCAL_ARC_OUTSIDE_FIELD')
crossing=makearc([2,6],[8,6],[8,12],3)
check('boundary crossing not pass',m.arc_screen(crossing,field,boundary,[])['status']!='LOCAL_ARC_CLEARANCE_PASS_NUMERIC_ENCLOSURE')
thresholdfield=m.ogr.CreateGeometryFromWkt('POLYGON ((-20 -1.1,20 -1.1,20 20,-20 20,-20 -1.1))')
check('clearance exactly threshold unresolved',m.arc_screen(arc,thresholdfield,thresholdfield.Boundary(),[])['status']=='LOCAL_ARC_CLEARANCE_UNKNOWN')
service=m.corner_record([[-10,0],[0,0],[0,10]],1,'scheduled_service',[1],field,boundary,[])
check('service vertex never claimed preserved',all(x['scheduled_point_visit_preserved_by_local_arc'] is False for x in service['radius_screens']))
short=m.corner_record([[-.25,0],[0,0],[0,.25]],1,'transit_vertex',[],field,boundary,[])
check('all radii fail on short right angle',all(x['status']=='LOCAL_CUTBACK_EXCEEDS_ADJACENT_SEGMENT' for x in short['radius_screens']))
equal=m.corner_record([[-.5,0],[0,0],[0,.5]],1,'transit_vertex',[],field,boundary,[])
check('exactly fitted cutback classified unknown',equal['radius_screens'][0]['status']=='UNKNOWN_CUTBACK_NUMERIC_THRESHOLD')

# One-shot closed triangle: both turns fit their adjacent 1.5m segment at R=.5,
# but their two setbacks overlap that segment. All coordinates are invented.
pts=[[0.,0.],[10.,0.],[10.,1.5],[0.,0.]]
inst={'instance_id':'SYNTHETIC','n':2,'coordinates':pts[:3]}
route={'mapped_polyline_coordinates':pts,'mapped_polyline_node_ids':[0,1,2,0],
       'route':[0,1,2,0], 'legs':[{'service_leg':[s,t],'node_ids':[s,t]} for s,t in [(0,1),(1,2),(2,0)]]}
old={'segments':[{'segment_index':i,'a':a,'b':b,'minimum_clearance_m':m.line([a,b]).Distance(boundary)} for i,(a,b) in enumerate(zip(pts,pts[1:]))],
     'complete_polyline_minimum_clearance_m':m.line(pts).Distance(boundary)}
out=m.route_audit(inst,'SYNTHETIC',route,old,field,boundary,[])
check('shared segment inspected',len(out['radius_summaries'][0]['shared_segments'])==3)
check('one-shot departure setback zero',out['radius_summaries'][0]['shared_segments'][0]['incoming_corner_cutback_m']==0.)
check('one-shot arrival setback zero',out['radius_summaries'][0]['shared_segments'][-1]['outgoing_corner_cutback_m']==0.)
check('large-radius shared overlap detected',out['radius_summaries'][1]['shared_segments'][1]['status']=='SHARED_SEGMENT_OVERLAP')
check('shared check forbids aggregate feasibility claim',not any(r['full_route_feasible_claim'] for r in out['radius_summaries']))
check('sharp exact path labeled untrackable at positive speed',out['exact_polyline_positive_speed_bounded_curvature_status']=='NOT_TRACKABLE_AS_SAVED')
for lexeme,should_accept in [('0.1',True),('1.00000000',True),('1e-7',True),('0.123456789012345678901',False)]:
    fixture=ROOT/'independent_review/decimal_guard_synthetic_fixture.json'
    fixture.write_text('{"coordinate":'+lexeme+'}')
    try:m.load(fixture);accepted=True
    except (AssertionError,ValueError):accepted=False
    check('decimal lexeme guard '+lexeme,accepted==should_accept)
result={'status':'SYNTHETIC_ONLY_PASS','source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        'loaded_real_instance_files':False,'checks':checks,'check_count':len(checks),
        'cpu_seconds':time.process_time()-cpu,'wall_seconds':time.monotonic()-start,
        'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
destination=ROOT/'independent_review/SYNTHETIC_REVIEW_FINAL.json'
destination.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='checks'}))
