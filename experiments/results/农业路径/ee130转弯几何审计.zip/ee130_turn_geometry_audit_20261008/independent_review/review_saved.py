#!/usr/bin/python3
"""One-shot read-only independent saved-result recomputation after RAW receipt.

Does not import or invoke the experiment program. Its central geometry check
uses analytic primitive extrema, not the experiment's chord-distance method.
"""
import collections, datetime, hashlib, json, math, pathlib, resource, sys, time, traceback
sys.dont_write_bytecode=True
resource.setrlimit(resource.RLIMIT_CPU,(30,30))
resource.setrlimit(resource.RLIMIT_AS,(512*1024*1024,512*1024*1024))
from fractions import Fraction
from osgeo import ogr
from analytic_geometry import arc_segment_distance, inside_field, ptseg, sub
ROOT=pathlib.Path(__file__).resolve().parents[1]
RADII=(.5,1.,2.,5.)
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(path,obj):
    with path.open('x') as f:json.dump(obj,f,indent=2,allow_nan=False);f.write('\n')
def close(a,b,tol=1e-8):return abs(a-b)<=tol
def cross(a,b):return a[0]*b[1]-a[1]*b[0]
def dot(a,b):return a[0]*b[0]+a[1]*b[1]
def segment_distance(a,b,c,d):
    u,v=sub(b,a),sub(d,c)
    if cross(u,sub(c,a))*cross(u,sub(d,a))<0 and cross(v,sub(a,c))*cross(v,sub(b,c))<0:return 0.
    return min(ptseg(a,c,d),ptseg(b,c,d),ptseg(c,a,b),ptseg(d,a,b))
def independent_turn(a,b,c):
    exact=lambda p:tuple(Fraction(str(x)) for x in p)
    a,b,c=exact(a),exact(b),exact(c);u,v=sub(b,a),sub(c,b)
    l1,l2=math.hypot(*map(float,u)),math.hypot(*map(float,v))
    # Experiment lengths use binary coordinate subtraction. Use that same input
    # precision for its explicit band only; exact cross/dot are rational.
    if l1<=1e-8 or l2<=1e-8:return 'DEGENERATE_ADJACENT_SEGMENT',None,None
    determinant,product=cross(u,v),dot(u,v)
    theta=math.atan2(float(determinant),float(product));ab=abs(theta)
    if determinant==0:return ('EXACT_FORWARD_COLLINEAR',theta,0.) if product>0 else ('EXACT_REVERSAL_180',theta,None)
    if ab<=1e-6:return 'NUMERICALLY_NEAR_COLLINEAR_NONZERO',theta,None
    if math.pi-ab<=1e-6:return 'NEAR_REVERSAL_ILL_CONDITIONED',theta,None
    return 'ROBUST_NONZERO_CORNER',theta,math.tan(ab/2)

def audit():
    started=time.monotonic();cpu=time.process_time()
    evidence=ROOT/'independent_review/evidence';evidence.mkdir(exist_ok=True)
    assert sys.argv[1:]==['--audit'],'Only the explicit post-RAW audit entry is allowed'
    receipt=load(ROOT/'evidence/RAW_DRIVE_RECEIPT.json')
    assert receipt['verified'] and receipt['download_byte_identical'] and receipt['permissions']=='owner_only' and receipt['shared'] is False
    save(evidence/'SAVED_REVIEW_STARTED.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'attempt':1,'script_sha256':sha(pathlib.Path(__file__)),'primitive_sha256':sha(pathlib.Path(__file__).with_name('analytic_geometry.py')),'raw_receipt_sha256':sha(ROOT/'evidence/RAW_DRIVE_RECEIPT.json')})
    counts=collections.Counter();arc_evidence=[];failures=[];maximums=collections.defaultdict(float)
    def check(ok,what):
        counts['checks']+=1
        if not ok:failures.append(what)
    try:
        freeze=load(ROOT/'freeze/PREEXECUTION_FREEZE.json')
        for path,digest in freeze['files'].items():check(sha(ROOT/path)==digest,'frozen file changed: '+path)
        raw_manifest=load(ROOT/'evidence/RAW_COMPLETE_UNAUDITED_MANIFEST.json')
        for path,digest in raw_manifest['files'].items():check(sha(ROOT/path)==digest,'RAW file changed: '+path)
        upstream=load(ROOT/'freeze/UPSTREAM_IMMUTABILITY.json')
        for path,digest in upstream['files'].items():check(sha(pathlib.Path(upstream['root'])/path)==digest,'upstream changed: '+path)
        field=ogr.CreateGeometryFromWkt((ROOT/'input/projected_epsg32634.wkt').read_text())
        rings=[[tuple(r.GetPoint(i)[:2]) for i in range(r.GetPointCount())] for r in [field.GetGeometryRef(i) for i in range(field.GetGeometryCount())]]
        edges=[(a,b) for ring in rings for a,b in zip(ring,ring[1:])]
        results=load(ROOT/'raw/results.json');aggregate=collections.Counter();audited=0;missing=set()
        instances={p.stem[:-6]:load(p) for p in (ROOT/'input/instances').glob('*_input.json')}
        previous={x['instance_id']:x for x in load(ROOT/'input/prior/results.json')['instances']}
        check(len(instances)==12 and len(results['rows'])==24,'12/24 denominator')
        expected_keys={(name,method) for name in instances for method in ('nearest_neighbor','nn_2opt_budget')}
        check({(x['instance_id'],x['method']) for x in results['rows']}==expected_keys,'complete unique method grid')
        for row in results['rows']:
            if time.monotonic()-started>55:raise TimeoutError('Independent review wall budget reached')
            name,method=row['instance_id'],row['method'];tag=name+'/'+method
            input_route=ROOT/f'input/routes/{name}_{method}_solver_output.json'
            if not input_route.exists():
                missing.add(name);check(row['status']=='NO_ROUTE_PRIOR_ENDPOINT_INFEASIBILITY' and previous[name]['status']=='TASK_INFEASIBLE',tag+' missing-route reason');continue
            audited+=1;out=load(ROOT/'raw'/row['raw_file']);original=load(input_route)
            check(out['original_route']==original,tag+' original route identity')
            points=original['mapped_polyline_coordinates'];ids=original['mapped_polyline_node_ids'];inst=instances[name]
            services=collections.defaultdict(list);offset=0
            for leg,(s,t) in zip(original['legs'],zip(original['route'],original['route'][1:])):
                check(leg['service_leg']==[s,t],tag+' service leg identity')
                check(points[offset]==inst['coordinates'][s],tag+' service start coordinate')
                services[str(offset)].append(s);offset+=len(leg['node_ids'])-1
                check(points[offset]==inst['coordinates'][t],tag+' service target coordinate')
            services[str(offset)].append(0)
            check(dict(services)==out['service_event_mapping'],tag+' exact service event map')
            check(points[0]==points[-1] and out['closed_terminal_duplicate_preserved'],tag+' closure retained')
            check(out['zero_length_segments']==[i for i,(a,b) in enumerate(zip(points,points[1:])) if a==b],tag+' exact duplicates')
            allclear=[]
            for i,(a,b) in enumerate(zip(points,points[1:])):
                clearance=min(segment_distance(a,b,c,d) for c,d in edges);allclear.append(clearance)
                saved=out['segments'][i]
                check(close(saved['length_m'],math.dist(a,b)),tag+' segment length '+str(i))
                check(close(saved['prior_whole_segment_clearance_m'],clearance,2e-8),tag+' independent saved segment clearance '+str(i))
            check(close(min(allclear),out['original_whole_polyline_clearance_m'],2e-8),tag+' full original polyline clearance')
            interior=out['interior_vertices'];check(len(interior)==len(points)-2,tag+' all interior vertices')
            independent_counts=collections.Counter();cutbacks={};service_corners=0
            for vertex in interior+[out['optional_cyclic_depot_seam']]:
                i=vertex['vertex_index'];seam=vertex['cyclic_seam_only'];vtag=tag+'/vertex'+str(i)+('/seam' if seam else '')
                a=points[-2] if seam else points[i-1];b=points[i];c=points[i+1]
                status,theta,k=independent_turn(a,b,c)
                check(vertex['status']==status,vtag+' exact turn status')
                if theta is not None:check(close(theta,vertex['angle_rad'],1e-12),vtag+' signed theta')
                if not seam:
                    independent_counts[status]+=1;cutbacks[i]=[None if k is None else R*k for R in RADII]
                    if services.get(str(i)) and status=='ROBUST_NONZERO_CORNER':service_corners+=1
                    check(vertex['service_ids']==services.get(str(i),[]),vtag+' service IDs')
                check(len(vertex['radius_screens'])==4,vtag+' all prespecified radii')
                for R,screen in zip(RADII,vertex['radius_screens']):
                    stag=vtag+'/R'+str(R);check(screen['radius_m']==R,stag+' fixed radius')
                    if k is None:check(screen['status']=='NOT_EVALUATED_'+status,stag+' singular corner not evaluated');continue
                    if k==0:check(screen['status']=='NO_TURN_NEEDED',stag+' forward collinear');continue
                    t=R*k;check(close(screen['cutback_m'],t),stag+' cutback')
                    if vertex['service_ids']:check(screen['scheduled_point_visit_preserved_by_local_arc'] is False,stag+' exact service not preserved')
                    slack=min(math.dist(a,b),math.dist(b,c))-t
                    if slack < -1e-8:check(screen['status']=='LOCAL_CUTBACK_EXCEEDS_ADJACENT_SEGMENT',stag+' side length fails');continue
                    if slack <= 1e-8:check(screen['status']=='UNKNOWN_CUTBACK_NUMERIC_THRESHOLD',stag+' side threshold unknown');continue
                    check('center' in screen,stag+' arc materialized')
                    if 'center' not in screen:continue
                    u=tuple(x/math.dist(a,b) for x in sub(b,a));v=tuple(x/math.dist(b,c) for x in sub(c,b));sgn=1 if theta>0 else -1
                    center=(b[0]-t*u[0]-sgn*R*u[1],b[1]-t*u[1]+sgn*R*u[0])
                    start=math.atan2(-sgn*u[0],sgn*u[1]);n=max(1,math.ceil(abs(theta)/(2*math.acos(1-1e-5/R))))
                    check(math.dist(center,screen['center'])<=2e-8,stag+' independent circle center')
                    sagitta=R*(1-math.cos(abs(theta)/(2*n)))
                    check(n==screen['chord_count'] and len(screen['chord_coordinates'])==n+1,stag+' chord budget')
                    check(close(sagitta,screen['sagitta_bound_m'],1e-14) and sagitta<=1e-5,stag+' sagitta bound')
                    expected_start=(b[0]-t*u[0],b[1]-t*u[1]);expected_end=(b[0]+t*v[0],b[1]+t*v[1])
                    check(math.dist(expected_start,screen['chord_coordinates'][0])<=2e-8 and math.dist(expected_end,screen['chord_coordinates'][-1])<=2e-8,stag+' tangent endpoints')
                    chord_error=0.
                    for j,p in enumerate(screen['chord_coordinates'][1:-1],1):
                        q=(center[0]+R*math.cos(start+theta*j/n),center[1]+R*math.sin(start+theta*j/n))
                        chord_error=max(chord_error,math.dist(p,q))
                    check(chord_error<=2e-8,stag+' reconstructed all chord vertices')
                    distances=[min(arc_segment_distance(center,R,start,theta,a,b) for a,b in zip(ring,ring[1:])) for ring in rings]
                    exact_clearance=min(distances);inside=inside_field(expected_start,rings)
                    lower=screen.get('arc_clearance_lower_bound_m');upper=screen.get('arc_clearance_upper_bound_m')
                    if lower is not None:
                        check(lower-2e-8<=exact_clearance<=upper+2e-8,stag+' analytic distance inside claimed numerical bracket')
                        bound_error=max(lower-exact_clearance,exact_clearance-upper,0.)
                        maximums['analytic_distance_outside_bracket_m']=max(maximums['analytic_distance_outside_bracket_m'],bound_error)
                        expected_low=max(0.,screen['chord_chain_minimum_clearance_m']-sagitta-1e-8)
                        expected_high=screen['chord_chain_minimum_clearance_m']+sagitta+1e-8
                        check(close(lower,expected_low,1e-14) and close(upper,expected_high,1e-14),stag+' enclosure arithmetic')
                    if screen['status']=='LOCAL_ARC_CLEARANCE_PASS_NUMERIC_ENCLOSURE':check(inside and exact_clearance>1.1,stag+' exact analytic pass supported')
                    elif screen['status']=='LOCAL_ARC_CLEARANCE_FAIL_NUMERIC_ENCLOSURE':check(exact_clearance<1.1,stag+' exact analytic fail supported')
                    elif screen['status']=='LOCAL_ARC_OUTSIDE_FIELD':check(not inside and exact_clearance>1e-8,stag+' outside component supported')
                    counts['arcs_analytically_checked']+=1
                    maximums['reconstructed_chord_coordinate_error_m']=max(maximums['reconstructed_chord_coordinate_error_m'],chord_error)
                    arc_evidence.append({'instance_id':name,'method':method,'vertex_index':i,'seam':seam,'radius_m':R,'status':screen['status'],'analytic_arc_boundary_distance_m':exact_clearance,'per_ring_analytic_distance_m':distances,'arc_start_inside_field':inside,'claimed_lower_m':lower,'claimed_upper_m':upper})
            aggregate.update(independent_counts);counts['interior_vertices']+=len(interior)
            check(dict(independent_counts)==out['interior_turn_status_counts'],tag+' corner aggregate')
            check(service_corners==out['robust_nonzero_service_corners'],tag+' service corner aggregate')
            for ri,(R,summary) in enumerate(zip(RADII,out['radius_summaries'])):
                shared_counts=collections.Counter()
                for i,(a,b) in enumerate(zip(points,points[1:])):
                    left=0. if i==0 else cutbacks[i][ri];right=0. if i+1==len(points)-1 else cutbacks[i+1][ri]
                    if left is None or right is None:expected='UNKNOWN_DUE_TO_DEGENERATE_OR_NEAR_COLLINEAR_VERTEX'
                    else:
                        remaining=math.dist(a,b)-left-right
                        expected='SHARED_SEGMENT_FITS' if remaining>1e-8 else ('SHARED_SEGMENT_OVERLAP' if remaining < -1e-8 else 'SHARED_SEGMENT_THRESHOLD_UNKNOWN')
                        check(close(remaining,summary['shared_segments'][i]['remaining_segment_m']),tag+' shared slack')
                    shared_counts[expected]+=1;check(summary['shared_segments'][i]['status']==expected,tag+' shared status')
                check(dict(shared_counts)==summary['shared_segment_status_counts'],tag+' shared aggregate')
                check(summary['scheduled_service_corners_cut_off']==service_corners,tag+' removed-service count')
                check(summary['local_corner_status_counts']==dict(collections.Counter(v['radius_screens'][ri]['status'] for v in interior)),tag+' local status aggregate')
                check(summary['full_route_feasible_claim'] is False,tag+' no route feasibility promotion')
            untrackable=any(independent_counts[s]>0 for s in ('ROBUST_NONZERO_CORNER','EXACT_REVERSAL_180'))
            check(out['exact_polyline_positive_speed_bounded_curvature_status']==('NOT_TRACKABLE_AS_SAVED' if untrackable else 'NOT_ESTABLISHED'),tag+' exact polyline interpretation')
            check(out['actual_vehicle_executability']=='UNKNOWN_NO_VEHICLE_MODEL_OR_PHYSICAL_VALIDATION',tag+' physical claims withheld')
        check(audited==8 and len(missing)==8,'route and infeasible-instance denominator')
        check(dict(aggregate)==results['interior_corner_totals'],'global corner totals')
        check(results['all_instance_count']==12 and results['all_instance_method_count']==24 and results['routes_audited']==8,'saved denominators')
        status='PASS_INDEPENDENT_SAVED_RECOMPUTATION' if not failures else 'FAIL_INDEPENDENT_SAVED_RECOMPUTATION'
    except Exception as exc:
        status='INCOMPLETE_INDEPENDENT_SAVED_RECOMPUTATION';failures.append(type(exc).__name__+': '+str(exc));traceback.print_exc()
    result={'status':status,'attempt':1,'imported_experiment_code':False,'reran_formal_experiment':False,'method':'Exact-decimal rational turn classification; analytic arc-to-boundary-segment extrema, endpoint and intersection enumeration; independent segment distances and service/shared-segment reconstruction. GDAL used only for WKT parsing.','counts':dict(counts),'maximum_discrepancies':dict(maximums),'failures':failures,'arc_evidence':arc_evidence,'cpu_seconds':time.process_time()-cpu,'wall_seconds':time.monotonic()-started,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'limitations':['Floating-point geometry with explicit comparison tolerance, not certified intervals.','Original physical-model and full-route-executability limits remain unchanged.']}
    save(evidence/'INDEPENDENT_SAVED_RECOMPUTATION.json',result)
    print(json.dumps({k:v for k,v in result.items() if k!='arc_evidence'}))
    raise SystemExit(0 if status=='PASS_INDEPENDENT_SAVED_RECOMPUTATION' else 1)
if __name__=='__main__':audit()
