"""Independent arc-to-segment minimum, without chord sampling or GEOS distance.

At a minimum of two smooth primitive interiors, their connecting segment is
normal to both tangents. For a circle and a line this is a line-normal radial
point. All remaining minima occur at primitive endpoints or intersections.
The finite candidate enumeration below is therefore complete for minor arcs.
Floating-point arithmetic is used; it is not certified interval arithmetic.
"""
import math
TAU=2*math.pi
def sub(p,q):return (p[0]-q[0],p[1]-q[1])
def dot(p,q):return p[0]*q[0]+p[1]*q[1]
def ptseg(p,a,b):
    d=sub(b,a);den=dot(d,d)
    if den==0:return math.dist(p,a)
    lam=max(0.,min(1.,dot(sub(p,a),d)/den))
    return math.hypot(p[0]-a[0]-lam*d[0],p[1]-a[1]-lam*d[1])
def onarc(vector,start,sweep):
    angle=math.atan2(vector[1],vector[0]);sign=1 if sweep>=0 else -1
    delta=(sign*(angle-start))%TAU
    return delta<=abs(sweep)+1e-12 or TAU-delta<=1e-12
def arcpoint(center,radius,angle):
    return (center[0]+radius*math.cos(angle),center[1]+radius*math.sin(angle))
def point_arc_distance(p,c,r,start,sweep):
    v=sub(p,c);d=math.hypot(*v)
    values=[math.dist(p,arcpoint(c,r,start)),math.dist(p,arcpoint(c,r,start+sweep))]
    if d==0:values.append(r)
    elif onarc(v,start,sweep):values.append(abs(d-r))
    return min(values)
def arc_segment_distance(c,r,start,sweep,a,b):
    # Work relative to the center; only the original subtraction uses large
    # global coordinate values.
    a,b=sub(a,c),sub(b,c);zero=(0.,0.)
    ends=[arcpoint(zero,r,start),arcpoint(zero,r,start+sweep)]
    values=[ptseg(p,a,b) for p in ends]
    values.extend(point_arc_distance(p,zero,r,start,sweep) for p in (a,b))
    d=sub(b,a);den=dot(d,d)
    if den==0:return min(values)
    length=math.sqrt(den);normal=(-d[1]/length,d[0]/length)
    for sign in [-1,1]:
        p=(sign*r*normal[0],sign*r*normal[1])
        projection=dot(sub(p,a),d)/den
        if 0<=projection<=1 and onarc(p,start,sweep):values.append(ptseg(p,a,b))
    # Circle-segment intersections, restricted to the arc angular interval.
    linear=2*dot(a,d);constant=dot(a,a)-r*r
    discriminant=linear*linear-4*den*constant
    if discriminant>=0:
        root=math.sqrt(discriminant)
        for lam in [(-linear-root)/(2*den),(-linear+root)/(2*den)]:
            if 0<=lam<=1:
                p=(a[0]+lam*d[0],a[1]+lam*d[1])
                if onarc(p,start,sweep):values.append(0.)
    return min(values)
def inside_ring(p,ring):
    inside=False
    for a,b in zip(ring,ring[1:]):
        if (a[1]>p[1])!=(b[1]>p[1]):
            crossing=a[0]+(p[1]-a[1])*(b[0]-a[0])/(b[1]-a[1])
            if p[0]<crossing:inside=not inside
    return inside
def inside_field(p,rings):return inside_ring(p,rings[0]) and not any(inside_ring(p,r) for r in rings[1:])
if __name__=='__main__':
    import json,pathlib,random,time
    began=time.monotonic();checks=[]
    def check(name,yes):
        assert yes,name
        checks.append(name)
    cases=[(((0,0),1,0,math.pi/2,(-2,2),(2,2)),1),
           (((0,0),1,0,math.pi/2,(2,-2),(2,2)),1),
           (((0,0),1,0,math.pi/2,(0,0),(.5,0)),.5),
           (((0,0),1,0,math.pi/2,(.5,0),(.5,2)),0),
           (((0,0),1,0,math.pi/2,(-2,-2),(-2,-1)),math.sqrt(8)),
           (((0,0),1,0,-math.pi/2,(-2,-2),(2,-2)),1)]
    for i,(args,expected) in enumerate(cases):check('analytic known case '+str(i),abs(arc_segment_distance(*args)-expected)<1e-12)
    random.seed(41026)
    for i in range(100):
        start=random.uniform(-math.pi,math.pi);sweep=random.choice([-1,1])*random.uniform(.01,math.pi-.01)
        r=random.uniform(.5,5);a=tuple(random.uniform(-6,6) for _ in range(2));b=tuple(random.uniform(-6,6) for _ in range(2))
        exact=arc_segment_distance((0,0),r,start,sweep,a,b)
        sampled=min(ptseg(arcpoint((0,0),r,start+sweep*j/2000),a,b) for j in range(2001))
        # Every point is within half a step of a sample. Distance is 1-Lipschitz.
        check('independent dense upper/lower sandwich '+str(i),exact<=sampled+1e-10 and sampled-exact<=r*abs(sweep)/4000+1e-10)
    out={'status':'PASS_ANALYTIC_PRIMITIVE_SYNTHETIC','check_count':len(checks),'checks':checks,'real_instance_loaded':False,'wall_seconds':time.monotonic()-began}
    pathlib.Path(__file__).with_name('ANALYTIC_PRIMITIVE_SYNTHETIC.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k!='checks'}))
