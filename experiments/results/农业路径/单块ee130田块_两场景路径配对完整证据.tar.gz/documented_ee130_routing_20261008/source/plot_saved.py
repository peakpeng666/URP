import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
from matplotlib.lines import Line2D
R=Path(__file__).resolve().parents[1]
a=json.loads((R/'input/instance.json').read_text());rr=json.loads((R/'reports/results.json').read_text());origin=(661870,6526079)
def local(p):return p[0]-origin[0],p[1]-origin[1]
rings=[[[x/a['integer_units_per_metre'],y/a['integer_units_per_metre']] for x,y in r] for r in a['rings_integer_exact']]
fig,axs=plt.subplots(1,2,figsize=(13,7))
colors=['#1774b5','#b75420','#667d29']
for ax,z in zip(axs,rr):
 for i,r in enumerate(rings):ax.add_patch(Polygon([local(p) for p in r],facecolor='#e1edd5' if i==0 else 'white',edgecolor='#394632',linewidth=1,zorder=1))
 s=z['euclidean_solution']
 for idx,r in enumerate(s['routes']):
  p=[local(p) for p in r['polyline']];ax.plot(*zip(*p),color=colors[idx],lw=2,zorder=3)
 for u,v in s['uncovered_direct_legs']:
  p=[local(a['coordinates'][x]) for x in [u,v]];ax.plot(*zip(*p),color='#dc2355',ls='--',lw=2.5,zorder=5)
 for i,p in enumerate(a['coordinates']):
  x,y=local(p);ax.scatter(x,y,s=85 if i==0 else 30,marker='*' if i==0 else 'o',color='black',zorder=6);ax.annotate('D' if i==0 else str(i),(x,y),xytext=(5,5),textcoords='offset points',fontsize=10,zorder=7)
 ax.set_aspect('equal');ax.autoscale_view();ax.margins(.07);ax.set_xlabel('Local easting (m)');ax.set_ylabel('Local northing (m)');ax.grid(alpha=.15)
 ax.set_title(f"K={z['K']}, Q={z['Q']} | E and G choose the same plan\nStraight {s['euclidean_cost']:.3f} m → feasible {s['mapped_feasible_cost']:.3f} m",fontsize=11)
fig.suptitle('ee_field_130: documented real geometry, synthetic depot and 9 tasks',fontsize=15,y=.98)
fig.legend(handles=[Line2D([0],[0],color='#1774b5',lw=2,label='Mapped feasible point-robot route(s)'),Line2D([0],[0],color='#dc2355',ls='--',lw=2,label='Original uncovered straight leg')],loc='lower center',ncol=2,bbox_to_anchor=(.5,.028))
fig.text(.5,.005,'All 3 holes retained. Boundary contact allowed. No vehicle footprint, turning radius, dynamics or headland model.',ha='center',fontsize=9)
fig.tight_layout(rect=(0,.14,1,.93));fig.savefig(R/'reports/ee130_two_scenarios.png',dpi=170)
