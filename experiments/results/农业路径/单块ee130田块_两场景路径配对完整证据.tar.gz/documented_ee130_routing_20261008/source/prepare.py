import json,hashlib,random,datetime,re,sys
from pathlib import Path
from decimal import Decimal
from osgeo import ogr,gdal
from geometry import covered_point,on_segment
R=Path(__file__).resolve().parents[1]
def save(p,x):
 with (R/p).open('x') as f: json.dump(x,f,ensure_ascii=False,indent=2); f.write('\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
protocol={'study':'documented_ee130_single_field_point_robot_multitask_v1','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'planning_authorized':False,'source_crs':'EPSG:4326 documented by official fixed-commit test','projected_crs':'EPSG:32634','projected_wkt_sha256':'9c63c15979ce1915673e072621e4c88b70d3e17f97b353cb3e88d8ddf1b1e86a','geometry':'Unchanged projected WKT; all outer and three hole rings retained. Exact decimal coordinate representation for predicates. Closed domain allows boundary contact, never hole interior. No buffer, snap, repair, simplification, geometry tolerance or hole deletion.','sampling':'Adapt old uniform integer rejection rule: random.Random(202610080731), independently draw integer easting uniformly from ceil(Emin) to floor(Emax), northing uniformly from ceil(Nmin) to floor(Nmax). Accept unique points strictly in field interior; first accepted is depot, next nine are tasks. No preceding synthetic-dimension RNG calls. Preserve every draw; no outcome selection.','sampling_seed':202610080731,'demand_seed':202611080731,'demand_rule':'Independent random.Random(seed+1000000).shuffle([1,1,2,2,3,3,4,4,4]); depot demand 0.','cases':[{'K':1,'Q':24},{'K':3,'Q':9}],'objective':'Minimize total round-trip length for exactly K nonempty depot tours, each synthetic task served exactly once, sum demand each tour <= Q. No fleet comparison at equal capacity claimed.','distance':'Euclidean E vs full outer+hole vertex visibility graph G, exact rational segment coverage and Dijkstra. Service nodes included. Zero-footprint point robot. Touching any boundary permitted.','verification':'Independent installed GDAL/GEOS line Difference(field).IsEmpty coverage checks, independent Floyd-Warshall graph distances, Held-Karp/partition DP crosscheck against full canonical enumeration; all disagreements retained and block PASS until resolved without geometry relaxation.','enumeration':'Full capacity-feasible canonical plans; quotient route reversal and vehicle labels; primary min(binary64 math.fsum flattened edge costs, canonical plan), objective tolerance never used in primary selection; complete exact-float and +1e-9 E-optimal tie sensitivity.','report':'E(E*), G(E*), G(G*), E and G primary plans, direct uncovered legs, all mapped path violations, full path vertices, capacities, repair bias and reordering savings separately for each K. No agricultural operational saving or general-population claim.','numeric_check_tolerance_m':1e-9,'runs':1,'cpu_limit_seconds':180,'wall_limit_seconds':300,'new_installs':0,'model_calls':0,'external_calls':0,'stopping':'One formal attempt after root approval only; failure or cap hit retained, no silent retry or point reselection.','limitations':'One real documented geometry; all task and depot positions and demands synthetic. No turn radius, footprint, heading, dynamics, headland, coverage operations, or interaction/collision of vehicles. Incidental passing through a service location does not require service.'}
save('freeze/PROTOCOL.json',protocol)
save('freeze/PRE_GENERATION_FREEZE.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'objective_evaluations':0,'sha256':{str(p.relative_to(R)):sha(p) for p in sorted((R/'source').glob('*.py'))}|{'freeze/PROTOCOL.json':sha(R/'freeze/PROTOCOL.json'),'input/projected_epsg32634.wkt':sha(R/'input/projected_epsg32634.wkt')}})
w=(R/'input/projected_epsg32634.wkt').read_text(); assert sha(R/'input/projected_epsg32634.wkt')==protocol['projected_wkt_sha256']
# Decimal lexical values are retained exactly, not snapped; 1e9 is a representation unit.
scale=10**9
rings=[]
for txt in re.findall(r'\(([^()]+)\)',w):
 ring=[]
 for pair in txt.split(','):
  v=tuple(Decimal(s)*scale for s in pair.split()); assert all(x==x.to_integral_value() for x in v)
  ring.append(tuple(map(int,v)))
 assert ring[0]==ring[-1]; rings.append(ring[:-1])
assert len(rings)==4 and sum(len(r)+1 for r in rings)==145
g=ogr.CreateGeometryFromWkt(w); assert g.IsValid() and not g.IsEmpty()
def strict(p):
 if any(on_segment(p,a,b) for r in rings for a,b in zip(r,r[1:]+r[:1])):return False
 return covered_point(p,rings[0]) and not any(covered_point(p,r) for r in rings[1:])
from math import ceil,floor
xs=[x for x,y in rings[0]]; ys=[y for x,y in rings[0]]
bounds=[ceil(min(xs)/scale),floor(max(xs)/scale),ceil(min(ys)/scale),floor(max(ys)/scale)]
r=random.Random(protocol['sampling_seed']); points=[]; draws=[]
while len(points)<10:
 p=(r.randint(bounds[0],bounds[1]),r.randint(bounds[2],bounds[3])); ok=strict(tuple(v*scale for v in p)) and p not in points
 q=ogr.Geometry(ogr.wkbPoint); q.AddPoint_2D(*p); other=g.Contains(q) and p not in points
 assert ok==other
 draws.append({'point':p,'accepted':ok})
 if ok: points.append(p)
d=[1,1,2,2,3,3,4,4,4]; random.Random(protocol['demand_seed']).shuffle(d)
inst={'instance_id':'documented_ee130_synthetic_tasks','coordinate_units':'metres, absolute EPSG:32634','coordinates':points,'demands':[0]+d,'rings_integer_exact':rings,'integer_units_per_metre':scale,'sampling_draws':draws,'sampling_integer_bounds':bounds}
save('input/instance.json',inst)
save('evidence/GENERATION.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'objective_evaluations':0,'distance_matrix_evaluations':0,'planning_candidates':0,'points':points,'demands':[0]+d,'draws':len(draws),'all_points_strictly_in_original_domain':True,'independent_GDAL_contains_agrees':True,'GDAL':gdal.VersionInfo(),'area_projected_wkt_m2':g.Area(),'ring_counts_including_close':[len(x)+1 for x in rings],'instance_sha256':sha(R/'input/instance.json')})
print(json.dumps({'points':points,'demands':[0]+d,'draws':len(draws),'bounds':bounds,'instance_sha256':sha(R/'input/instance.json')},indent=2))
