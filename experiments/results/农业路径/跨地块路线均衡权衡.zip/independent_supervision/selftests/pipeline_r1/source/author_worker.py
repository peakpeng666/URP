"""A single gated real endpoint selection. Gate precedes all source reads."""
import json
import resource
import sys
import time
from gates import active_main_gate
from inputs import load_input
from author_solver import solve


def main():
    assert __debug__
    digest = active_main_gate()
    field, objective = sys.argv[1:]
    if objective not in ('SUM_MAX', 'MAX_SUM'):
        raise ValueError('UNSCHEDULED_OBJECTIVE')
    started, cpu = time.monotonic(), time.process_time()
    table, identity = load_input(field)
    row = solve(table, 12, 5, objective)
    row.update(instance_id=field, frozen_files_sha256=digest, input_identity=identity,
               status='PROCESS_SUCCESS_UNREVIEWED', resources={
                   'wall_seconds': time.monotonic() - started, 'cpu_seconds': time.process_time() - cpu,
                   'maxrss_kib': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                   'cpu_limits': list(resource.getrlimit(resource.RLIMIT_CPU)),
                   'as_limits': list(resource.getrlimit(resource.RLIMIT_AS))})
    print(json.dumps(row, allow_nan=False))


if __name__ == '__main__':
    main()
