"""Production batch control flow against synthetic emitters, never real inputs."""
import json, sys
from common import ROOT, save, read
import run_author_batch


def main():
    base = ROOT / 'selftests/batch_fixture'
    (base / 'source').mkdir(parents=True, exist_ok=False)
    (base / 'freeze').mkdir()
    schedule = [{'call_id': 'SYNTH_%02d_%s' % (i, arm), 'instance_id': 'SYNTH_%02d' % i, 'objective': arm}
                for i in range(12) for arm in ('SUM_MAX', 'MAX_SUM')]
    save(base / 'freeze/SCHEDULE.json', schedule)
    (base / 'source/author_worker.py').write_text('import sys,json,resource\nprint(json.dumps({"synthetic_only":True,"real_objective_calls":0,"field":sys.argv[1],"objective":sys.argv[2],"cpu_limits":list(resource.getrlimit(resource.RLIMIT_CPU)),"as_limits":list(resource.getrlimit(resource.RLIMIT_AS))}))\nsys.exit(7 if sys.argv[1:]==["SYNTH_05","MAX_SUM"] else 0)\n')
    # Only this synthetic test process replaces module locals. No production files or approval receipts are changed.
    run_author_batch.ROOT = base
    run_author_batch.active_main_gate = lambda: 'synthetic-no-authority'
    run_author_batch.main()
    rows = [json.loads(line) for line in (base / 'raw/results.jsonl').read_text().splitlines()]
    assert len(rows) == 24 and all(row['process_spawned'] and row['child_reaped'] for row in rows)
    assert sum(row['status'] == 'PROCESS_FAILURE' for row in rows) == 1
    assert sum(row['status'] == 'UNREVIEWED_PROCESS_SUCCESS' for row in rows) == 23
    assert all(row['registered_group_cleanup']['quiescent'] for row in rows)
    for slot in schedule:
        out = read(base / 'raw/calls' / (slot['call_id'] + '.stdout'))
        assert out['synthetic_only'] and out['real_objective_calls'] == 0
        assert out['cpu_limits'] == [15, 15] and out['as_limits'] == [268435456, 268435456]
    save(base / 'REPORT.json', {'status': 'PASS', 'synthetic_only': True, 'real_objective_calls': 0,
         'emitter_processes': 24, 'successful_emitters': 23, 'intentional_failure_retained': 1,
         'all_groups_quiescent': True, 'production_batch_control_flow': True})
    print('PASS production24-slot batch with23 synthetic emitters and1 retained intentional failure; no optimizer or real input calls.')


if __name__ == '__main__':
    main()
