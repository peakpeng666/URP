"""Loss-aware slot preservation with synthetic evidence only; no solver/process start."""
import json
from common import ROOT, save, read
from launch_main_once import seal


def main():
    dest = ROOT / 'selftests/ledger_failure'
    (dest / 'calls').mkdir(parents=True, exist_ok=False)
    schedule = read(ROOT / 'freeze/SCHEDULE.json')
    first, second = schedule[:2]
    (dest / 'results.jsonl').write_text(json.dumps({'schedule': first, 'status': 'PROCESS_FAILURE', 'process_spawned': True}) + '\n{\n')
    (dest / 'calls' / (second['call_id'] + '.stdout')).write_text('')
    seal(dest, schedule, 'synthetic-no-authority', {'status': 'SYNTHETIC_SUPERVISOR_FAILURE'})
    slots = read(dest / 'ALL_PLANNED_SLOTS.json')
    assert len(slots) == 24 and slots[0]['status'] == 'PROCESS_FAILURE'
    assert slots[1]['status'] == 'UNKNOWN_AFTER_SUPERVISOR_FAILURE' and slots[1]['process_spawned'] == 'UNKNOWN'
    assert all(row['status'] == 'NOT_STARTED_SUPERVISOR_FAILURE' for row in slots[2:])
    assert read(dest / 'OUTER_FINISHED.json')['malformed_rows'] == [1]
    save(dest / 'REPORT.json', {'status': 'PASS', 'synthetic_only': True, 'real_objective_calls': 0,
         'planned_slots_retained': 24, 'known_started_failure': 1, 'unknown_start': 1, 'not_started': 22})
    print('PASS synthetic24-slot loss ledger; unknown starts never counted as zero.')


if __name__ == '__main__':
    main()
