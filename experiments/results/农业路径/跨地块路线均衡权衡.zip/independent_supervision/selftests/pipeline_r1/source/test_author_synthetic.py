"""Synthetic fixtures only: this module never imports the formal input reader."""
import copy
import itertools
import json
from author_solver import solve


def catalog(n, Q, cost):
    return [{'mask': sum(1 << (x - 1) for x in group), 'customers': list(group),
             'route': [0] + list(group) + [0], 'E': cost(group), 'G': cost(group)}
            for size in range(max(1, n - 2 * Q), Q + 1)
            for group in itertools.combinations(range(1, n + 1), size)]


def tied_witness_catalog():
    n, Q = 7, 3
    G = [[int(i != j) for j in range(n + 1)] for i in range(n + 1)]
    E = [[9 * int(i != j) for j in range(n + 1)] for i in range(n + 1)]
    for a, b in ((0, 2), (2, 4), (4, 3), (3, 0)):
        E[a][b] = E[b][a] = 1
    out = []
    for base in catalog(n, Q, lambda group: len(group) + 1):
        candidates = []
        for order in itertools.permutations(base['customers']):
            if order > tuple(reversed(order)):
                continue
            route = (0,) + order + (0,)
            gv = sum(G[a][b] for a, b in zip(route, route[1:]))
            ev = sum(E[a][b] for a, b in zip(route, route[1:]))
            candidates.append((gv, ev, order))
        gv, ev, order = min(candidates)
        base.update(G=gv, E=ev, route=[0] + list(order) + [0])
        out.append(base)
    return out


def main():
    cases = []
    table = catalog(12, 5, lambda group: 1)
    for objective in ('SUM_MAX', 'MAX_SUM'):
        result = solve(table, 12, 5, objective)
        assert (result['sum_G_mm'], result['max_route_G_mm']) == (3, 1)
        assert result['partition'] == [[1, 2], [3, 4, 5, 6, 7], [8, 9, 10, 11, 12]]
        assert result['counters']['unlabeled_partition_evaluations'] == 41811
        assert result['counters']['partition_size_counts'] == {'2,5,5': 8316, '3,4,5': 27720, '4,4,4': 5775}
        cases.append({'case': 'all_equal_full_structure', 'result': result})
    low = {(1, 2): 10, (3, 4): 1, (5, 6): 1, (1, 3): 5, (2, 5): 5, (4, 6): 5}
    table = catalog(6, 2, lambda group: low.get(group, 100))
    for objective, expected in (('SUM_MAX', (12, 10)), ('MAX_SUM', (15, 5))):
        result = solve(table, 6, 2, objective)
        assert (result['sum_G_mm'], result['max_route_G_mm']) == expected
        cases.append({'case': 'strict_endpoint_tradeoff', 'result': result})
    table = tied_witness_catalog()
    for objective in ('SUM_MAX', 'MAX_SUM'):
        result = solve(table, 7, 3, objective)
        assert result['partition'] == [[1], [2, 3, 4], [5, 6, 7]]
        assert result['routes'][1] == [0, 2, 4, 3, 0]
        assert (result['sum_G_mm'], result['max_route_G_mm']) == (10, 4)
        cases.append({'case': 'inherited_E_tie_witness', 'result': result})
    invalid = []
    variants = []
    bad = copy.deepcopy(table); bad[0]['customers'] = [1, 1]; variants.append(('duplicate_service', bad))
    bad = copy.deepcopy(table); bad[0]['route'] = [0, 1, 1, 0]; variants.append(('duplicate_route_visit', bad))
    bad = copy.deepcopy(table); bad.append({'mask': 15, 'customers': [1, 2, 3, 4], 'route': [0, 1, 2, 3, 4, 0], 'E': 1, 'G': 1}); variants.append(('over_capacity', bad))
    bad = copy.deepcopy(table); bad.pop(); variants.append(('missing_subset', bad))
    bad = copy.deepcopy(table); bad[0]['G'] = 1.0; variants.append(('noninteger_cost', bad))
    bad = copy.deepcopy(table); bad.append(copy.deepcopy(bad[0])); variants.append(('duplicate_mask', bad))
    for name, bad in variants:
        try:
            solve(bad, 7, 3, 'SUM_MAX')
        except ValueError as exc:
            invalid.append({'case': name, 'rejected': str(exc)})
        else:
            raise AssertionError('INVALID_INPUT_ACCEPTED:' + name)
    print(json.dumps({'status': 'PASS', 'synthetic_only': True, 'real_objective_evaluations': 0,
                      'synthetic_valid_objective_calls': len(cases), 'synthetic_invalid_input_rejections': len(invalid),
                      'cases': cases, 'invalid': invalid}, allow_nan=False))


if __name__ == '__main__':
    main()
