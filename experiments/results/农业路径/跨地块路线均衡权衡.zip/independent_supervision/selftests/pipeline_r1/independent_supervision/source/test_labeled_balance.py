"""Invented catalog checks, never reads real field local-route tables."""
import pathlib,itertools,json,time,resource
from labeled_balance import solve
ROOT=pathlib.Path(__file__).resolve().parents[2]

def catalog(n,Q,cost):
    low=max(1,n-2*Q);rows=[]
    for mask in range(1,1<<n):
        group=[i for i in range(1,n+1) if mask>>(i-1)&1]
        if low<=len(group)<=Q:rows.append({'mask':mask,'customers':group,'route':[0]+group+[0],'E':0,'G':cost(tuple(group))})
    return rows

def brute(rows,n,Q,obj):
    # Independently enumerate a vehicle label for each individual customer.
    costs={tuple(r['customers']):r['G'] for r in rows};best=None
    for labels in itertools.product(range(3),repeat=n):
        groups=tuple(sorted(tuple(i+1 for i,t in enumerate(labels) if t==k) for k in range(3)))
        if not all(0<len(g)<=Q for g in groups):continue
        vals=[costs[g] for g in groups];s,m=sum(vals),max(vals)
        key=(s,m,groups) if obj=='SUM_MAX' else(m,s,groups)
        if best is None or key<best:best=key
    return best

def main():
    start=time.monotonic();cases=[];calls=0
    special={(1,):1,(2,3):1,(4,5,6):9,(1,2):4,(3,4):4,(5,6):4}
    for name,rows in [('tradeoff',catalog(6,3,lambda g:special.get(g,100))),('ties',catalog(6,3,lambda g:1)),('irregular',catalog(6,3,lambda g:(sum(i*i for i in g)*7+len(g)*13)%29))]:
        results={}
        for obj in ('SUM_MAX','MAX_SUM'):
            a=solve(rows,6,3,obj);calls+=1;p=tuple(map(tuple,a['partition']));key=(a['sum_G_mm'],a['max_route_G_mm'],p) if obj=='SUM_MAX' else(a['max_route_G_mm'],a['sum_G_mm'],p)
            assert key==brute(rows,6,3,obj)
            results[obj]=a
        if name=='tradeoff':assert (results['SUM_MAX']['sum_G_mm'],results['SUM_MAX']['max_route_G_mm'],results['MAX_SUM']['sum_G_mm'],results['MAX_SUM']['max_route_G_mm'])==(11,9,12,4)
        cases.append({'fixture':name,'status':'PASS_CUSTOMER_LABEL_BRUTE_FORCE'})
    rows=catalog(12,5,lambda g:len(g)+1)
    for obj in ('SUM_MAX','MAX_SUM'):
        a=solve(rows,12,5,obj);calls+=1;c=a['counters']
        assert c['B_nonempty_submasks_checked']==406747 and c['labeled_feasible_partitions']==250866 and c['unique_canonical_partitions']==41811 and c['canonical_partition_multiplicities']=={'6':41811}
        assert c['labeled_size_pattern_counts']=={'2,5,5':49896,'3,4,5':166320,'4,4,4':34650}
        assert a['sum_G_mm']==15 and a['max_route_G_mm']==5 and a['partition']==[[1,2,3,4],[5,6,7,8],[9,10,11,12]]
        cases.append({'fixture':'n12_equal_edge_length','objective':obj,'status':'PASS_COUNTS_COVERAGE_AND_CANONICAL_TIE'})
    u=resource.getrusage(resource.RUSAGE_SELF)
    out={'status':'PASS','synthetic_only':True,'synthetic_target_calls':calls,'real_target_calls':0,'new_local_TSP_calls':0,'cases':cases,'wall_seconds':time.monotonic()-start,'cpu_seconds':u.ru_utime+u.ru_stime,'peak_rss_kib':u.ru_maxrss}
    p=ROOT/'independent_supervision/selftests/ALGORITHM_R1.json'
    with p.open('x') as f:json.dump(out,f,indent=2)
    print(json.dumps(out))
if __name__=='__main__':main()
