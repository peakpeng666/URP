"""Independent labelled A/B/C enumeration on frozen local optimum costs.
No main solver, dynamic programming, penalty scalarization, or local TSP calls.
"""
from collections import Counter
import hashlib,json

def solve(local_rows,n,Q,objective):
    assert objective in ('SUM_MAX','MAX_SUM') and 3<=n<=12 and 1<=Q<=5 and n<=3*Q
    low=max(1,n-2*Q);full=(1<<n)-1
    local={}
    for r in local_rows:
        mask=r['mask'];assert type(mask) is int and mask not in local and 0<mask<=full and low<=mask.bit_count()<=Q
        group=tuple(i for i in range(1,n+1) if mask>>(i-1)&1)
        assert r['customers']==list(group) and type(r['G']) is int and r['G']>=0
        assert r['route'][0]==r['route'][-1]==0 and sorted(r['route'][1:-1])==list(group)
        local[mask]=(group,r)
    expected={m for m in range(1,full+1) if low<=m.bit_count()<=Q};assert set(local)==expected
    best=None;checked=0;feasible=0;coverage=Counter();modes=Counter()
    for A in sorted(local):
        rest=full^A;B=rest
        while B:
            checked+=1;C=rest^B
            if B in local and C in local:
                feasible+=1
                ordered=sorted((local[A],local[B],local[C]),key=lambda x:x[0])
                partition=tuple(g for g,r in ordered);rows=[r for g,r in ordered]
                values=[r['G'] for r in rows];total=sum(values);maximum=max(values)
                key=(total,maximum,partition) if objective=='SUM_MAX' else (maximum,total,partition)
                coverage[partition]+=1;modes[','.join(map(str,sorted(len(g) for g in partition)))]+=1
                if best is None or key<best[0]:best=(key,total,maximum,partition,rows,values)
            B=(B-1)&rest
    assert best is not None and all(v==6 for v in coverage.values())
    packed=json.dumps([list(map(list,p)) for p in sorted(coverage)],separators=(',',':')).encode()
    return {'objective':objective,'n':n,'Q':Q,'K':3,'sum_G_mm':best[1],'max_route_G_mm':best[2],
            'partition':[list(g) for g in best[3]],'routes':[r['route'] for r in best[4]],'route_G_mm':best[5],
            'counters':{'available_local_subsets':len(local),'B_nonempty_submasks_checked':checked,'labeled_feasible_partitions':feasible,
                        'unique_canonical_partitions':len(coverage),'canonical_partition_multiplicities':dict(Counter(map(str,coverage.values()))),
                        'labeled_size_pattern_counts':dict(modes),'canonical_partition_coverage_sha256':hashlib.sha256(packed).hexdigest(),
                        'additional_local_TSP_calls':0}}
