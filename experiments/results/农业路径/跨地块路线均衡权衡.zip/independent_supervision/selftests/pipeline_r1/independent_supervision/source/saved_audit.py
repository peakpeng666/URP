"""Saved two-endpoint evidence audit; no new partition or local-route optimization."""
import pathlib,sys,json,hashlib,zipfile,resource,signal,time
ROOT=pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'source'))
from common import read,save,sha,utc,verify_map
from gates import frozen,receipt
from read_catalog import load_input

def raw_check(base,name,archived,digest):
    m=read(base/name);assert m['frozen_files_sha256']==digest;verify_map(ROOT,m['files'])
    with zipfile.ZipFile(archived['download_path']) as z:
        for rel,v in m['files'].items():
            b=z.read(rel);assert b==(ROOT/rel).read_bytes() and len(b)==v['bytes'] and hashlib.sha256(b).hexdigest()==v['sha256']
        assert z.read(str((base/name).relative_to(ROOT)))==(base/name).read_bytes()
    return len(m['files'])

def ledger(base,schedule):
    rows=read(base/'ALL_PLANNED_SLOTS.json');assert len(rows)==24 and [r['schedule'] for r in rows]==schedule
    o=read(base/'OUTER_FINISHED.json');errors=[]
    if o['duplicate_call_ids'] or o['malformed_rows']:errors.append('DUPLICATE_OR_MALFORMED_LEDGER')
    return rows,{'planned':24,'known_spawned':sum(r.get('process_spawned') is True for r in rows),
      'unknown_spawned_slots':sum(r.get('process_spawned') not in (True,False) for r in rows),'retained':24},errors

def check_output(a,slot,digest,catalog,identity,member,member_hash,lane):
    assert a['status']=='PROCESS_SUCCESS_UNREVIEWED' and a['instance_id']==slot['instance_id'] and a['objective']==slot['objective']
    assert a['frozen_files_sha256']==digest and a['n']==12 and a['Q']==5 and a['K']==3
    ident=a['input_identity'];assert ident['parent_member']==member and ident['parent_member_sha256']==member_hash
    for k in ('parent_archive_sha256','parent_audit_sha256','local_table_canonical_json_sha256'):assert ident[k]==identity[k]
    p=a['partition'];assert len(p)==len(a['routes'])==len(a['route_G_mm'])==3 and p==sorted(p)
    assert all(g==sorted(g) and 2<=len(g)<=5 for g in p) and sorted(x for g in p for x in g)==list(range(1,13))
    by={r['mask']:r for r in catalog};values=[]
    for g,route,v in zip(p,a['routes'],a['route_G_mm']):
        row=by[sum(1<<(x-1) for x in g)];assert route==row['route'] and type(v) is int and v==row['G'];values.append(v)
    assert type(a['sum_G_mm']) is int and type(a['max_route_G_mm']) is int and a['sum_G_mm']==sum(values) and a['max_route_G_mm']==max(values)
    c=a['counters'];assert c['unique_canonical_partitions']==41811
    if lane=='main':
        assert c['local_subsets']==1573 and c['new_local_tsp_evaluations']==0 and c['unlabeled_partition_evaluations']==41811
        assert c['partition_size_counts']=={'2,5,5':8316,'3,4,5':27720,'4,4,4':5775}
    else:
        assert c['available_local_subsets']==1573 and c['additional_local_TSP_calls']==0
        assert c['B_nonempty_submasks_checked']==406747 and c['labeled_feasible_partitions']==250866
        assert c['canonical_partition_multiplicities']=={'6':41811} and c['labeled_size_pattern_counts']=={'2,5,5':49896,'3,4,5':166320,'4,4,4':34650}
    expected=read(ROOT/'independent_supervision/selftests/COVERAGE_EXPECTED.json')['canonical_partition_coverage_sha256']
    assert c['canonical_partition_coverage_sha256']==expected

def endpoints(a,b):
    ds=b['sum_G_mm']-a['sum_G_mm'];dm=a['max_route_G_mm']-b['max_route_G_mm']
    assert ds>=0 and dm>=0 and (ds==0)==(dm==0)
    if ds==0:assert a['partition']==b['partition'] and a['routes']==b['routes']
    return {'delta_sum_G_mm':ds,'reduction_max_route_G_mm':dm,'sum_max_endpoint':{k:a[k] for k in ('sum_G_mm','max_route_G_mm','partition','routes','route_G_mm')},
            'max_sum_endpoint':{k:b[k] for k in ('sum_G_mm','max_route_G_mm','partition','routes','route_G_mm')},'strict_tradeoff':ds>0}

def audit():
    digest=frozen();rm=receipt(ROOT/'provenance/RAW_MAIN_DRIVE_RECEIPT.json','RAW_MAIN',digest);rv=receipt(ROOT/'provenance/RAW_VERIFICATION_DRIVE_RECEIPT.json','RAW_VERIFICATION',digest)
    checked=[raw_check(ROOT/'raw','RAW_MAIN_CONTENT_MANIFEST.json',rm,digest),raw_check(ROOT/'independent_supervision/raw','RAW_VERIFICATION_CONTENT_MANIFEST.json',rv,digest)]
    schedule=read(ROOT/'freeze/SCHEDULE.json');assert len(schedule)==24 and len({s['call_id'] for s in schedule})==24
    ml,mc,errs=ledger(ROOT/'raw',schedule);il,ic,ie=ledger(ROOT/'independent_supervision/raw',schedule);errs+=ie
    cache={};payloads={};rows=[]
    with zipfile.ZipFile(ROOT/'input/CAPACITY_FINAL.zip') as z:
        for slot,mrec,irec in zip(schedule,ml,il):
            cid,f=slot['call_id'],slot['instance_id'];row={'call_id':cid,'instance_id':f,'objective':slot['objective'],'valid_for_exact_conclusion':False,'failure':None}
            try:
                assert not errs
                for r in (mrec,irec):assert r.get('status')=='UNREVIEWED_PROCESS_SUCCESS' and not r.get('error') and r.get('process_spawned') is True and r.get('returncode')==0 and r.get('child_reaped') is True and (r.get('registered_group_cleanup') or {}).get('quiescent') is True
                if f not in cache:
                    table,ident=load_input(f);main_member=f'raw/calls/{f}_G_E.stdout';main_raw=z.read(main_member);source=json.loads(main_raw)
                    assert source['local_routes']==table
                    cache[f]=(table,ident,main_member,hashlib.sha256(main_raw).hexdigest())
                table,ident,main_member,main_hash=cache[f]
                a=read(ROOT/'raw/calls'/(cid+'.stdout'));b=read(ROOT/'independent_supervision/raw/calls'/(cid+'.stdout'))
                check_output(a,slot,digest,table,ident,main_member,main_hash,'main')
                check_output(b,slot,digest,table,ident,ident['parent_member'],ident['parent_member_sha256'],'independent')
                for k in ('sum_G_mm','max_route_G_mm','partition','routes','route_G_mm'):assert a[k]==b[k]
                row.update(valid_for_exact_conclusion=True,sum_G_mm=a['sum_G_mm'],max_route_G_mm=a['max_route_G_mm'],partition=a['partition'],routes=a['routes'],route_G_mm=a['route_G_mm'])
                payloads[f,slot['objective']]=a
            except (AssertionError,KeyError,ValueError,TypeError,OSError,IndexError) as e:row['failure']=type(e).__name__+':'+str(e)
            rows.append(row)
    fields=[];eligible=[]
    for f in read(ROOT/'freeze/PROTOCOL.json')['fields']:
        row={'instance_id':f,'valid_for_exact_conclusion':False,'delta_sum_G_mm':None,'reduction_max_route_G_mm':None,'strict_tradeoff':None}
        if all((f,o) in payloads for o in ('SUM_MAX','MAX_SUM')):
            try:row.update(endpoints(payloads[f,'SUM_MAX'],payloads[f,'MAX_SUM']),valid_for_exact_conclusion=True);eligible.append(f)
            except AssertionError:row['failure']='INCONSISTENT_LEX_ENDPOINTS'
        fields.append(row)
    valid=[f for f in fields if f['valid_for_exact_conclusion']]
    return {'status':'PASS' if len(valid)==12 else 'AUDIT_COMPLETE_WITH_UNVERIFIED_SLOTS','frozen_files_sha256':digest,'raw_main_archive_sha256':rm['sha256'],'raw_verification_archive_sha256':rv['sha256'],
        'planned_fields':12,'planned_main_calls':24,'planned_independent_calls':24,'planned_total_objective_slots':48,'main_counts':mc,'independent_counts':ic,'ledger_errors':errs,
        'rows':rows,'fields':fields,'eligible_instance_ids':eligible,'verified_fields':len(valid),'strict_tradeoff_fields':sum(f['strict_tradeoff'] for f in valid),
        'complete_panel_mean_delta_sum_G_mm':sum(f['delta_sum_G_mm'] for f in valid)/12 if len(valid)==12 else None,
        'complete_panel_mean_reduction_max_route_G_mm':sum(f['reduction_max_route_G_mm'] for f in valid)/12 if len(valid)==12 else None,
        'raw_members_checked':checked,'new_objective_or_local_TSP_calls_in_saved_audit':0}

def main():
    assert __debug__;resource.setrlimit(resource.RLIMIT_CPU,(15,15));resource.setrlimit(resource.RLIMIT_AS,(268435456,268435456));signal.alarm(30)
    start=time.monotonic();save(ROOT/'independent_supervision/SAVED_AUDIT_STARTED.json',{'utc':utc(),'new_objective_calls':0})
    out=audit();u=resource.getrusage(resource.RUSAGE_SELF);out.update(utc=utc(),cpu_seconds=u.ru_utime+u.ru_stime,wall_seconds=time.monotonic()-start,peak_rss_kib=u.ru_maxrss)
    save(ROOT/'independent_supervision/FINAL_AUDIT.json',out);print(json.dumps({'status':out['status'],'verified_fields':out['verified_fields'],'strict_tradeoff_fields':out['strict_tradeoff_fields']}))
if __name__=='__main__':main()
