"""One declared 24-objective batch, using the already-reviewed process runtime."""
import pathlib, sys, time
ROOT=pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'source'))
from common import read,save,append,utc
from gates import verification_ready
from tree_runtime import run_command

def main():
    digest=verification_ready()
    launch=read(ROOT/'provenance/VALIDATION_LAUNCH_STARTED.json')
    assert launch['frozen_files_sha256']==digest
    dest=ROOT/'independent_supervision/raw';dest.mkdir(exist_ok=False)
    (dest/'calls').mkdir();(dest/'active').mkdir()
    schedule=read(ROOT/'freeze/SCHEDULE.json');started=time.monotonic();deadline=started+780
    save(dest/'STARTED.json',{'utc':utc(),'frozen_files_sha256':digest,'planned_independent_calls':24})
    rows=[]
    for slot in schedule:
        remaining=deadline-time.monotonic();row={'schedule':slot,'utc':utc()}
        if remaining<=0:row.update(status='NOT_STARTED_BATCH_BUDGET',process_spawned=False,child_reaped=False)
        else:
            cid=slot['call_id']
            append(dest/'events.jsonl',{'event_kind':'OBJECTIVE_START_REQUESTED','schedule':slot,'utc':utc()})
            row.update(run_command(['/usr/bin/python3',ROOT/'independent_supervision/source/independent_worker.py',slot['instance_id'],slot['objective']],dest/'calls'/cid,15,268435456,min(30,remaining),dest/'active'/(cid+'.active.json')))
        append(dest/'results.jsonl',row);rows.append(row)
    save(dest/'FINISHED.json',{'utc':utc(),'planned_independent_calls':24,'recorded_slots':len(rows),
         'known_started_processes':sum(r.get('process_spawned') is True for r in rows),
         'wall_seconds':time.monotonic()-started,'status':'RAW_VERIFICATION_UNREVIEWED'})
if __name__=='__main__':main()
