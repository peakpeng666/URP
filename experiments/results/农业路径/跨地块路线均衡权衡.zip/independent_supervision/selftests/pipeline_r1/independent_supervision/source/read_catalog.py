"""Independent catalog reader, deriving no new local or global optimum."""
import pathlib,json,hashlib,zipfile
ROOT=pathlib.Path(__file__).resolve().parents[2]
def h(b):return hashlib.sha256(b).hexdigest()

def load_input(field):
    p=json.loads((ROOT/'freeze/PROTOCOL.json').read_text());assert field in p['fields']
    archive=ROOT/'input/CAPACITY_FINAL.zip';archive_hash=h(archive.read_bytes());assert archive_hash==p['source']['archive_sha256']
    identities=json.loads((ROOT/'input/PARENT_MEMBER_IDENTITIES.json').read_text())['selected_members']
    member=f'independent_supervision/raw/calls/{field}_G_E.stdout';audit_member='independent_supervision/FINAL_AUDIT.json'
    with zipfile.ZipFile(archive) as z:
        b=z.read(member);a=z.read(audit_member)
    for name,raw in [(member,b),(audit_member,a)]:assert len(raw)==identities[name]['bytes'] and h(raw)==identities[name]['sha256']
    source=json.loads(b);audit=json.loads(a)
    assert audit['status']=='PASS' and field in audit['eligible_instance_ids']
    assert source['status']=='PROCESS_SUCCESS_UNREVIEWED' and source['instance_id']==field and source['objective']=='G_E'
    assert source['n']==12 and source['Q']==5 and source['K']==3 and source['frozen_files_sha256']==p['source']['source_frozen_files_sha256']
    matrices=source['input_matrices']
    for key in ('E','G'):
        M=matrices[key];assert len(M)==13 and all(len(row)==13 for row in M)
        assert all(type(M[i][j]) is int and 0<=M[i][j]<=394480 and M[i][j]==M[j][i] and (i!=j or M[i][j]==0) for i in range(13) for j in range(13))
    rows=source['local_routes'];assert len(rows)==1573
    masks=set()
    for row in rows:
        mask=row['mask'];assert type(mask) is int and 0<mask<4096 and 2<=mask.bit_count()<=5 and mask not in masks;masks.add(mask)
        group=[i for i in range(1,13) if mask>>(i-1)&1];route=row['route']
        assert group==row['customers'] and route[0]==route[-1]==0 and sorted(route[1:-1])==group
        assert tuple(route[1:-1])<=tuple(reversed(route[1:-1]))
        for key in ('E','G'):assert type(row[key]) is int and row[key]==sum(matrices[key][a][b] for a,b in zip(route,route[1:]))
    assert masks=={m for m in range(1,4096) if 2<=m.bit_count()<=5}
    identity={'parent_archive_sha256':archive_hash,'parent_member':member,'parent_member_sha256':h(b),
              'parent_audit_sha256':h(a),'local_table_canonical_json_sha256':h(json.dumps(rows,sort_keys=True,separators=(',',':')).encode()),
              'derivation':'Inherited independently computed G minima with frozen (G,E,Rcode) witnesses; independent integer route-cost verification; no new local TSP'}
    return rows,identity
