import pathlib,sys,json,resource,time
ROOT=pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'source'))
from gates import verification_ready
from common import read
from read_catalog import load_input
from labeled_balance import solve

def main():
    assert __debug__
    started=time.monotonic();digest=verification_ready();launch=read(ROOT/'provenance/VALIDATION_LAUNCH_STARTED.json')
    assert launch['frozen_files_sha256']==digest and launch['planned_independent_calls']==24
    field,objective=sys.argv[1:];table,identity=load_input(field)
    result=solve(table,12,5,objective);u=resource.getrusage(resource.RUSAGE_SELF)
    result.update(instance_id=field,frozen_files_sha256=digest,input_identity=identity,status='PROCESS_SUCCESS_UNREVIEWED',
                  witness_rule='Inherited local (G,E,Rcode); global key excludes E',
                  resources={'wall_seconds':time.monotonic()-started,'cpu_seconds':u.ru_utime+u.ru_stime,'peak_rss_kib':u.ru_maxrss,
                    'cpu_limits':list(resource.getrlimit(resource.RLIMIT_CPU)),'as_limits':list(resource.getrlimit(resource.RLIMIT_AS))})
    print(json.dumps(result,allow_nan=False))
if __name__=='__main__':main()
