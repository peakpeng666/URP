"""Report from saved, independently audited endpoints. No optimization imports."""
from common import ROOT, read, save, sha, utc, verify_map
from gates import frozen, receipt


ENDPOINT_KEYS = ('sum_G_mm', 'max_route_G_mm', 'partition', 'routes', 'route_G_mm')


def diagnostic(sum_first, max_first):
    if sum_first['objective'] != 'SUM_MAX' or max_first['objective'] != 'MAX_SUM':
        raise ValueError('ENDPOINT_OBJECTIVE_IDENTITY')
    for row in (sum_first, max_first):
        values = row['route_G_mm']
        if (len(values) != 3 or any(type(x) is not int or x < 0 for x in values) or
                type(row['sum_G_mm']) is not int or type(row['max_route_G_mm']) is not int or
                row['sum_G_mm'] != sum(values) or row['max_route_G_mm'] != max(values)):
            raise ValueError('SAVED_ENDPOINT_COST_IDENTITY')
    extra = max_first['sum_G_mm'] - sum_first['sum_G_mm']
    reduction = sum_first['max_route_G_mm'] - max_first['max_route_G_mm']
    if extra < 0 or reduction < 0 or ((extra == 0) != (reduction == 0)):
        raise ValueError('LEX_ENDPOINT_STRONG_IDENTITY')
    if extra == 0 and any(sum_first[k] != max_first[k] for k in ENDPOINT_KEYS):
        raise ValueError('COMMON_ENDPOINT_CANONICAL_IDENTITY')
    return {'delta_sum_G_mm': extra, 'reduction_max_route_G_mm': reduction,
            'extra_total_percent': 100 * extra / sum_first['sum_G_mm'] if sum_first['sum_G_mm'] else None,
            'longest_reduction_percent': 100 * reduction / sum_first['max_route_G_mm'] if sum_first['max_route_G_mm'] else None,
            'strict_tradeoff': extra > 0,
            'sum_max_endpoint': {key: sum_first[key] for key in ENDPOINT_KEYS},
            'max_sum_endpoint': {key: max_first[key] for key in ENDPOINT_KEYS}}


def aggregate(rows, fields):
    ids = [row['instance_id'] for row in rows]
    if len(ids) != len(set(ids)) or len(fields) != len(set(fields)) or set(ids) != set(fields):
        raise ValueError('REPORT_FIELD_DENOMINATOR_IDENTITY')
    eligible = [row for row in rows if row.get('eligible_for_primary') is True]
    complete = len(eligible) == len(fields)
    out = {'status': 'COMPLETE_PANEL' if complete else 'INCOMPLETE_PANEL_WITH_EXPLICIT_FAILURE_DENOMINATORS',
           'planned_fields': len(fields), 'verified_fields': len(eligible),
           'planned_main_calls': 2 * len(fields), 'planned_independent_calls': 2 * len(fields),
           'planned_total_objective_slots': 4 * len(fields), 'fields': rows,
           'complete_case_strict_tradeoff_fields': sum(row['strict_tradeoff'] for row in eligible),
           'complete_case_common_endpoint_fields': sum(not row['strict_tradeoff'] for row in eligible)}
    for key in ('delta_sum_G_mm', 'reduction_max_route_G_mm'):
        values = sorted(row[key] for row in eligible)
        mean = sum(values) / len(values) if values else None
        median = (values[len(values) // 2] if len(values) % 2 else
                  (values[len(values) // 2 - 1] + values[len(values) // 2]) / 2) if values else None
        out['complete_panel_mean_' + key] = mean if complete else None
        out['complete_panel_median_' + key] = median if complete else None
        out['complete_case_mean_' + key] = mean
        out['complete_case_median_' + key] = median
        out['complete_case_sum_' + key] = sum(values) if values else None
    return out


def main():
    digest = frozen()
    rm = receipt(ROOT / 'provenance/RAW_MAIN_DRIVE_RECEIPT.json', 'RAW_MAIN', digest)
    rv = receipt(ROOT / 'provenance/RAW_VERIFICATION_DRIVE_RECEIPT.json', 'RAW_VERIFICATION', digest)
    for base, name in ((ROOT / 'raw', 'RAW_MAIN_CONTENT_MANIFEST.json'),
                       (ROOT / 'independent_supervision/raw', 'RAW_VERIFICATION_CONTENT_MANIFEST.json')):
        verify_map(ROOT, read(base / name)['files'])
    audit = read(ROOT / 'independent_supervision/FINAL_AUDIT.json')
    if (audit.get('status') not in ('PASS', 'AUDIT_COMPLETE_WITH_UNVERIFIED_SLOTS') or
            audit.get('frozen_files_sha256') != digest or
            audit.get('raw_main_archive_sha256') != rm['sha256'] or
            audit.get('raw_verification_archive_sha256') != rv['sha256']):
        raise ValueError('INDEPENDENT_SAVED_AUDIT_BINDING_REQUIRED')
    protocol = read(ROOT / 'freeze/PROTOCOL.json')
    eligible = set(audit['eligible_instance_ids'])
    rows = []
    for field in protocol['fields']:
        row = {'instance_id': field, 'eligible_for_primary': False, 'status': 'UNVERIFIED_INDEPENDENT_AUDIT'}
        if field in eligible:
            try:
                arms = [read(ROOT / 'raw/calls' / (field + '_' + objective + '.stdout'))
                        for objective in ('SUM_MAX', 'MAX_SUM')]
                if any(arm['instance_id'] != field or arm['frozen_files_sha256'] != digest for arm in arms):
                    raise ValueError('RAW_ENDPOINT_IDENTITY')
                value = diagnostic(*arms)
                independent = next(item for item in audit['fields'] if item['instance_id'] == field)
                if independent.get('valid_for_exact_conclusion') is not True:
                    raise ValueError('INDEPENDENT_FIELD_NOT_VALID')
                for key in ('delta_sum_G_mm', 'reduction_max_route_G_mm', 'strict_tradeoff', 'sum_max_endpoint', 'max_sum_endpoint'):
                    if value[key] != independent[key]:
                        raise ValueError('SAVED_REPORT_AUDIT_MISMATCH:' + key)
                row.update(value, eligible_for_primary=True, status='VERIFIED_INTEGER_PROXY_ENDPOINTS')
            except Exception as exc:
                row.update(status='REPORT_EVIDENCE_FAILURE', error=repr(exc))
        rows.append(row)
    summary = aggregate(rows, protocol['fields'])
    summary.update(frozen_files_sha256=digest, raw_main_archive_sha256=rm['sha256'],
                   raw_verification_archive_sha256=rv['sha256'],
                   independent_audit_sha256=sha(ROOT / 'independent_supervision/FINAL_AUDIT.json'),
                   utc=utc(), new_optimization_calls=0)
    for name, path in (('main', ROOT / 'raw/ALL_PLANNED_SLOTS.json'),
                       ('independent', ROOT / 'independent_supervision/raw/ALL_PLANNED_SLOTS.json')):
        slots = read(path)
        summary[name + '_known_started_processes'] = sum(slot.get('process_spawned') is True for slot in slots)
        summary[name + '_unknown_start_slots'] = sum(slot.get('process_spawned') == 'UNKNOWN' for slot in slots)
    save(ROOT / 'reports/SUMMARY.json', summary)
    lines = ['总路程与最长路线：固定Q5三车模型的精确双目标端点',
             '固定全部12个已观察NL边界，原depot和原客户1..12；单位需求Q5、至多3车强制恰3条路线。',
             '完整核验%s/12；计划主24加独立24目标槽全部保留，新增局部TSP为0。' % summary['verified_fields'],
             '完整12田均值：额外总路程%s mm；最长路线减少%s mm。' % (summary['complete_panel_mean_delta_sum_G_mm'], summary['complete_panel_mean_reduction_max_route_G_mm']),
             '完整案例描述分母%s；严格权衡%s田、共同端点%s田。缺失不是零。' % (summary['verified_fields'], summary['complete_case_strict_tradeoff_fields'], summary['complete_case_common_endpoint_fields']),
             '全局目标分别(sumG,maxG,Pcode)和(maxG,sumG,Pcode)；各组继承父局部(G,E,Rcode)路线，E不进入新全局成本目标。']
    for row in rows:
        lines.append('%s：额外总路程%s mm，最长路线减少%s mm，状态%s' %
                     (row['instance_id'], row.get('delta_sum_G_mm'), row.get('reduction_max_route_G_mm'), row['status']))
    lines.extend(['两个差值必须同零或同正；这是两种字典序目标的有效端点，不是完整Pareto前沿。',
                  '最长路线是距离负担指标，不是完工时间，也不代表需求载荷均等、极差或变异系数最小。无速度、服务时长或车际碰撞模型。',
                  '总路程两方案差的取整加保存路径容差界0.01500030米；最长路线差界0.00600012米。不是测绘或连续几何最优误差界。',
                  '真实边界配合合成任务和容量，旧字段已经观察，仅属探索性受控机制证据。无未见泛化、总体推断、实车节省或车辆数因果主张。',
                  '失败全分母，不补跑、不替换。路线、候选分组和车辆标签不是独立科学样本。'])
    with (ROOT / 'reports/REPORT_ZH.txt').open('x') as handle:
        handle.write('\n'.join(lines) + '\n')
    print('Saved-only report written; independent report review and FINAL byte readback are still required.')


if __name__ == '__main__':
    main()
