"""Saved-value report contracts only; no solver imports or real input reads."""
import copy
import json
from report import diagnostic, aggregate


def endpoint(objective, values, partition=None):
    partition = partition or [[1, 2], [3, 4], [5, 6]]
    return {'objective': objective, 'sum_G_mm': sum(values), 'max_route_G_mm': max(values),
            'route_G_mm': values, 'partition': partition, 'routes': [[0] + group + [0] for group in partition]}


def main():
    a = endpoint('SUM_MAX', [10, 1, 1])
    b = endpoint('MAX_SUM', [5, 5, 5], [[1, 3], [2, 5], [4, 6]])
    tradeoff = diagnostic(a, b)
    assert tradeoff['delta_sum_G_mm'] == 3 and tradeoff['reduction_max_route_G_mm'] == 5
    zero = diagnostic(endpoint('SUM_MAX', [0, 0, 0]), endpoint('MAX_SUM', [0, 0, 0]))
    assert zero['extra_total_percent'] is None and zero['longest_reduction_percent'] is None
    bad_pairs = [(endpoint('SUM_MAX', [6, 3, 3]), endpoint('MAX_SUM', [4, 4, 4])),
                 (endpoint('SUM_MAX', [5, 1, 1]), endpoint('MAX_SUM', [5, 2, 2])),
                 (endpoint('SUM_MAX', [1, 1, 1]), endpoint('MAX_SUM', [1, 1, 1], [[1, 3], [2, 5], [4, 6]]))]
    rejected = 0
    for first, second in bad_pairs:
        try:
            diagnostic(first, second)
        except ValueError:
            rejected += 1
        else:
            raise AssertionError('BAD_ENDPOINT_IDENTITY_ACCEPTED')
    rows = [dict(instance_id='SYNTH_A', eligible_for_primary=True, **tradeoff),
            dict(instance_id='SYNTH_B', eligible_for_primary=True, **zero)]
    complete = aggregate(rows, ['SYNTH_A', 'SYNTH_B'])
    assert complete['complete_panel_mean_delta_sum_G_mm'] == 1.5
    missing = copy.deepcopy(rows); missing[1] = {'instance_id': 'SYNTH_B', 'eligible_for_primary': False}
    incomplete = aggregate(missing, ['SYNTH_A', 'SYNTH_B'])
    assert incomplete['complete_panel_mean_delta_sum_G_mm'] is None
    assert incomplete['complete_case_mean_delta_sum_G_mm'] == 3 and incomplete['verified_fields'] == 1
    print(json.dumps({'status': 'PASS', 'synthetic_only': True, 'new_optimization_calls': 0,
                      'real_objective_calls': 0, 'invalid_endpoint_identities_rejected': rejected,
                      'zero_denominators_null': True, 'missing_field_full_panel_null': True}))


if __name__ == '__main__':
    main()
