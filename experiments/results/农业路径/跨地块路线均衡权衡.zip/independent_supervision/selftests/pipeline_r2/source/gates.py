from common import ROOT,read
def frozen():
 assert "selftests/pipeline_r2" in str(ROOT);return "SYNTHETIC"
def active_main_gate():return frozen()
def verification_ready():return frozen()
def receipt(path,stage,digest):return read(path)
