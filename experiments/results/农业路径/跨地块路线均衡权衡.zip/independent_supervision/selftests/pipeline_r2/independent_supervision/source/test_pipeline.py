"""Four invented worker endpoint calls and saved-only full-panel replay."""
import pathlib,sys,json,hashlib,zipfile,shutil
ROOT=pathlib.Path(__file__).resolve().parents[2];TEST=ROOT/'independent_supervision/selftests/pipeline_r2'
TEST.mkdir(exist_ok=False)
for folder in ('source','independent_supervision/source','independent_supervision/selftests','freeze','input','provenance'):(TEST/folder).mkdir(parents=True,exist_ok=True)
for folder in ('source','independent_supervision/source'):
    for p in (ROOT/folder).glob('*.py'):shutil.copyfile(p,TEST/folder/p.name)
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2))
def h(b):return hashlib.sha256(b).hexdigest()
def meta(p):return {'bytes':p.stat().st_size,'sha256':h(p.read_bytes())}
(TEST/'source/gates.py').write_text('from common import ROOT,read\ndef frozen():\n assert "selftests/pipeline_r2" in str(ROOT);return "SYNTHETIC"\ndef active_main_gate():return frozen()\ndef verification_ready():return frozen()\ndef receipt(path,stage,digest):return read(path)\n')
fields=['synthetic_'+str(i) for i in range(12)]
local=[]
for mask in range(1,4096):
    group=[i for i in range(1,13) if mask>>(i-1)&1]
    if 2<=len(group)<=5:local.append({'mask':mask,'customers':group,'route':[0]+group+[0],'E':len(group)+1,'G':len(group)+1})
M=[[int(i!=j) for j in range(13)] for i in range(13)];identities={}
with zipfile.ZipFile(TEST/'input/CAPACITY_FINAL.zip','w',zipfile.ZIP_DEFLATED) as z:
    for field in fields:
        source={'status':'PROCESS_SUCCESS_UNREVIEWED','instance_id':field,'objective':'G_E','n':12,'Q':5,'K':3,'frozen_files_sha256':'PARENT_SYNTHETIC','input_matrices':{'E':M,'G':M},'local_routes':local}
        for prefix in ('raw/calls/','independent_supervision/raw/calls/'):
            rel=prefix+field+'_G_E.stdout';b=json.dumps(source).encode();z.writestr(rel,b);identities[rel]={'bytes':len(b),'sha256':h(b)}
    rel='independent_supervision/FINAL_AUDIT.json';b=json.dumps({'status':'PASS','eligible_instance_ids':fields,'frozen_files_sha256':'PARENT_SYNTHETIC'}).encode();z.writestr(rel,b);identities[rel]={'bytes':len(b),'sha256':h(b)}
archive_hash=h((TEST/'input/CAPACITY_FINAL.zip').read_bytes())
save(TEST/'input/PARENT_MEMBER_IDENTITIES.json',{'selected_members':identities})
save(TEST/'freeze/PROTOCOL.json',{'fields':fields,'source':{'archive':'input/CAPACITY_FINAL.zip','archive_sha256':archive_hash,'source_frozen_files_sha256':'PARENT_SYNTHETIC'}})
schedule=[{'call_id':f+'_'+o,'instance_id':f,'objective':o} for f in fields for o in ('SUM_MAX','MAX_SUM')];save(TEST/'freeze/SCHEDULE.json',schedule)
save(TEST/'provenance/VALIDATION_LAUNCH_STARTED.json',{'frozen_files_sha256':'SYNTHETIC','planned_independent_calls':24})
sys.path.insert(0,str(TEST/'source'));from tree_runtime import run_command
answers={};runs=[]
for lane in ('main','independent'):
    for obj in ('SUM_MAX','MAX_SUM'):
        script=TEST/('source/author_worker.py' if lane=='main' else 'independent_supervision/source/independent_worker.py');dest=TEST/'worker_evidence'/(lane+'_'+obj)
        result=run_command(['/usr/bin/python3',script,fields[0],obj],dest,15,268435456,30,TEST/'worker_evidence'/(lane+'_'+obj+'.active.json'))
        assert result['status']=='UNREVIEWED_PROCESS_SUCCESS',result
        answer=json.loads(dest.with_suffix('.stdout').read_text());assert answer['resources']['cpu_limits']==[15,15] and answer['resources']['as_limits']==[268435456,268435456]
        answers[lane,obj]=answer;runs.append(result)
coverage=answers['independent','SUM_MAX']['counters']['canonical_partition_coverage_sha256']
assert all(a['counters']['canonical_partition_coverage_sha256']==coverage for a in answers.values())
cov={'canonical_partition_coverage_sha256':coverage,'unique_partitions':41811,'method':'Both algorithms independently enumerate synthetic n12 full feasible partition space; coverage independent of costs','new_local_TSP_calls':0}
save(ROOT/'independent_supervision/selftests/COVERAGE_EXPECTED.json',cov);save(TEST/'independent_supervision/selftests/COVERAGE_EXPECTED.json',cov)
for lane,base in [('main',TEST/'raw'),('independent',TEST/'independent_supervision/raw')]:
    records=[]
    for slot in schedule:
        a=json.loads(json.dumps(answers[lane,slot['objective']]));field=slot['instance_id'];a['instance_id']=field
        member=('raw/calls/' if lane=='main' else 'independent_supervision/raw/calls/')+field+'_G_E.stdout'
        a['input_identity']['parent_member']=member;a['input_identity']['parent_member_sha256']=identities[member]['sha256']
        save(base/'calls'/(slot['call_id']+'.stdout'),a)
        records.append({'schedule':slot,'status':'UNREVIEWED_PROCESS_SUCCESS','process_spawned':True,'returncode':0,'child_reaped':True,'error':None,'registered_group_cleanup':{'quiescent':True}})
    save(base/'ALL_PLANNED_SLOTS.json',records);save(base/'OUTER_FINISHED.json',{'duplicate_call_ids':False,'malformed_rows':[]})
    manifest='RAW_MAIN_CONTENT_MANIFEST.json' if lane=='main' else 'RAW_VERIFICATION_CONTENT_MANIFEST.json'
    save(base/manifest,{'frozen_files_sha256':'SYNTHETIC','files':{str(p.relative_to(TEST)):meta(p) for p in base.rglob('*') if p.is_file()}})
    archive=TEST/(lane+'_raw.zip')
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for p in base.rglob('*'):
            if p.is_file():z.write(p,str(p.relative_to(TEST)))
    save(TEST/'provenance'/('RAW_MAIN_DRIVE_RECEIPT.json' if lane=='main' else 'RAW_VERIFICATION_DRIVE_RECEIPT.json'),{'sha256':h(archive.read_bytes()),'download_path':str(archive),'synthetic_only':True})
sys.path.insert(0,str(TEST/'independent_supervision/source'));from saved_audit import audit,check_output,endpoints
out=audit();assert out['status']=='PASS' and out['verified_fields']==12 and out['strict_tradeoff_fields']==0
base=TEST/'independent_supervision/raw';p=base/'ALL_PLANNED_SLOTS.json';records=json.loads(p.read_text());records[0]['status']='WALL_TIMEOUT';save(p,records)
try:audit()
except (AssertionError,RuntimeError):pass
else:raise AssertionError('RAW_TAMPER_ACCEPTED')
manifest=base/'RAW_VERIFICATION_CONTENT_MANIFEST.json';m=json.loads(manifest.read_text());m['files'][str(p.relative_to(TEST))]=meta(p);save(manifest,m)
archive=TEST/'independent_failed_raw.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for q in base.rglob('*'):
        if q.is_file():z.write(q,str(q.relative_to(TEST)))
save(TEST/'provenance/RAW_VERIFICATION_DRIVE_RECEIPT.json',{'sha256':h(archive.read_bytes()),'download_path':str(archive),'synthetic_only':True})
failed=audit();assert failed['verified_fields']==11 and failed['complete_panel_mean_delta_sum_G_mm'] is None and len(failed['rows'])==24
# Explicit mathematical endpoint checks do not select any additional partition.
a=answers['main','SUM_MAX'];b=json.loads(json.dumps(a));b['sum_G_mm']+=1
try:endpoints(a,b)
except AssertionError:pass
else:raise AssertionError('ONE_ZERO_ONE_POSITIVE_ACCEPTED')
out={'status':'PASS','synthetic_only':True,'new_synthetic_target_calls':4,'real_target_calls':0,'new_local_TSP_calls':0,'actual_worker_runs':runs,'checks':['worker_limits_and_independent_input_contract','full12_saved_replay24_plus24','every_partition_coverage_hash_equal','modified_RAW_rejected','wall_failure_retains24_slots_and_full12_null','lex_deltas_same_zero_or_positive'],'gate_note':'Isolated synthetic-only gate stub; no real execution permission/receipt manufactured.'}
save(TEST/'REPORT.json',out);print(json.dumps({'status':'PASS','new_synthetic_target_calls':4,'saved_replay_fields':12}))
