"""Invented costs and independent small customer-label oracle only."""
import csv
import hashlib
import itertools
import json
import resource
import time
from pathlib import Path
from collections import Counter
from author_solver import solve, skyline, budget_queries, BASE_HEADER, CATALOG_HEADER, BUDGET_PERCENTAGES

ROOT = Path(__file__).resolve().parents[1]


def catalog(n, Q, cost):
    low = max(1, n - 2 * Q)
    return [{'mask': sum(1 << (i - 1) for i in g), 'customers': list(g), 'route': [0, *g, 0], 'G': cost(g), 'E': 10000 - sum(g)}
            for k in range(low, Q + 1) for g in itertools.combinations(range(1, n + 1), k)]


def oracle(rows, n, Q):
    cost = {tuple(r['customers']): r['G'] for r in rows}
    candidates = {}
    for labels in itertools.product(range(3), repeat=n):
        p = tuple(sorted(tuple(i + 1 for i in range(n) if labels[i] == v) for v in range(3)))
        if not all(0 < len(g) <= Q for g in p):
            continue
        values = [cost[g] for g in p]
        candidates[p] = (sum(values), max(values))
    points = set(candidates.values())
    front = sorted(q for q in points if not any(t[0] <= q[0] and t[1] <= q[1] and t != q for t in points))
    return candidates, front


def check(rows, n, Q, result, lines, brute=True):
    front = result['frontier']
    assert front and all(a['sum_G_mm'] < b['sum_G_mm'] and a['max_route_G_mm'] > b['max_route_G_mm'] for a, b in zip(front, front[1:]))
    lookup = {r['mask']: r for r in rows}
    seen, counts, prefix = [], Counter(), [BASE_HEADER]
    for r in csv.DictReader([CATALOG_HEADER, *lines]):
        masks = tuple(int(r['mask' + str(i)]) for i in (1, 2, 3))
        p = tuple(tuple(lookup[m]['customers']) for m in masks)
        assert tuple(sorted(p)) == p and len(set(sum(p, ()))) == n
        s, m = int(r['sum_G_mm']), int(r['max_route_G_mm'])
        values = [lookup[k]['G'] for k in masks]
        assert (s, m) == (sum(values), max(values))
        f = front[int(r['front_index'])]
        assert f['sum_G_mm'] <= s and f['max_route_G_mm'] <= m
        equal = (s, m) == (f['sum_G_mm'], f['max_route_G_mm'])
        assert r['relation'] == ('E' if equal else 'D')
        if equal:
            counts[int(r['front_index'])] += 1
            assert tuple(map(tuple, f['partition'])) <= p
        seen.append(p)
        prefix.append(','.join(map(str, (*masks, s, m))) + '\n')
    assert seen == sorted(set(seen))
    assert hashlib.sha256(''.join(prefix).encode()).hexdigest() == result['catalog']['normalized_objective_catalog_sha256']
    assert hashlib.sha256((CATALOG_HEADER + ''.join(lines)).encode()).hexdigest() == result['catalog']['sha256']
    assert all(counts[i] == f['assignment_multiplicity_unlabeled'] for i, f in enumerate(front))
    if brute:
        candidates, exact = oracle(rows, n, Q)
        assert [(f['sum_G_mm'], f['max_route_G_mm']) for f in front] == exact
        for f in front:
            matching = sorted(p for p, q in candidates.items() if q == (f['sum_G_mm'], f['max_route_G_mm']))
            assert f['partition'] == list(map(list, matching[0])) and f['assignment_multiplicity_unlabeled'] == len(matching)
        for q in result['queries']:
            bound = (100 + q['p']) * exact[0][0]
            best = min((m, s, p) for p, (s, m) in candidates.items() if 100 * s <= bound)
            assert best == (q['max_route_G_mm'], q['sum_G_mm'], tuple(map(tuple, q['partition'])))
    assert [q['p'] for q in result['queries']] == list(BUDGET_PERCENTAGES)
    for q in result['queries']:
        assert q['budget_total_G_mm'] == result['frontier'][0]['sum_G_mm'] * (100 + q['p']) // 100
        assert q['sum_G_mm'] <= q['budget_total_G_mm']
    assert result['queries'][0]['front_index'] == 0


def main():
    started = time.monotonic(); calls = 0; cases = []
    special = {(1,): 1, (2,3): 9, (4,5,6): 90, (2,): 10, (4,5): 20, (1,3,6): 71, (1,2): 34, (3,4): 34, (5,6): 34}
    fixtures = [('strict_nonconvex_three_points', lambda g: special.get(g, 1000)), ('ties', lambda g: 1), ('zero', lambda g: 0),
                ('irregular', lambda g: (7 * sum(i * i for i in g) + 13 * len(g)) % 29),
                ('overlap_nonmetric', lambda g: (sum(1 << i for i in g) * 37) % 113)]
    for name, fn in fixtures:
        rows = catalog(6, 3, fn)
        result, lines = solve(rows, 6, 3); calls += 1
        check(rows, 6, 3, result, lines)
        if name == 'strict_nonconvex_three_points':
            assert [(f['sum_G_mm'], f['max_route_G_mm']) for f in result['frontier']] == [(100,90),(101,71),(102,34)]
            assert [q['front_index'] for q in result['queries']] == [0,1,2,2,2,2]
        cases.append({'case': name, 'status': 'PASS_FULL_CUSTOMER_LABEL_ORACLE', 'frontier_points': result['frontier_size']})
    # Unsupported middle efficient point: (15,8) lies above the endpoint chord.
    pairs = {(12, 9): None, (15, 8): None, (18, 6): None, (15, 9): None, (18, 8): None}
    assert skyline(pairs) == [(12, 9), (15, 8), (18, 6)]
    assert skyline({(1, 4): None, (1, 3): None, (2, 3): None, (3, 2): None}) == [(1, 3), (3, 2)]
    big = {(100000 + i, 100000 - i): None for i in range(41811)}
    assert len(skyline(big)) == 41811
    cases.append({'case': 'unsupported_equal_coordinate_and_maximal_antichain', 'status': 'PASS'})
    mock = [{'index': i, 'sum_G_mm': s, 'max_route_G_mm': m, 'partition': [[1], [2], [3]], 'routes': [], 'route_G_mm': [], 'group_masks': [1, 2, 4]} for i, (s, m) in enumerate([(101, 70), (102, 69), (103, 50)])]
    assert budget_queries(mock, (0, 1, 2))[1]['sum_G_mm'] == 102
    cases.append({'case': 'fractional_percentage_integer_floor_boundary', 'status': 'PASS'})
    for name, cost in [('n12_uniform_edges', lambda g: len(g) + 1), ('n12_all_zero', lambda g: 0)]:
        rows = catalog(12, 5, cost)
        result, lines = solve(rows, 12, 5); calls += 1
        check(rows, 12, 5, result, lines, False)
        c = result['counters']
        assert c['local_subsets'] == 1573 and c['unlabeled_partition_evaluations'] == 41811
        assert c['partition_size_counts'] == {'2,5,5': 8316, '3,4,5': 27720, '4,4,4': 5775}
        assert c['canonical_partition_coverage_sha256'] == '116b468381296d0ed29066b7293164087fc03edc32b8105cd328b9f396e2c9d3'
        assert result['frontier_size'] == 1
        if name == 'n12_uniform_edges':
            assert result['frontier'][0]['partition'] == [[1,2,3,4],[5,6,7,8],[9,10,11,12]]
            assert result['frontier'][0]['assignment_multiplicity_unlabeled'] == 5775
            assert result['catalog']['relation_counts'] == {'D': 36036, 'E': 5775}
        else:
            assert result['frontier'][0]['assignment_multiplicity_unlabeled'] == 41811
            assert result['catalog']['relation_counts'] == {'E': 41811}
        cases.append({'case': name, 'status': 'PASS_FULL_SIZE_COUNTS_CERTIFICATES'})
    out = {'status': 'PASS', 'synthetic_only': True, 'real_target_calls': 0, 'synthetic_frontier_calls': calls,
           'new_local_TSP_calls': 0, 'cases': cases, 'cpu_seconds': time.process_time(),
           'wall_seconds': time.monotonic() - started, 'peak_rss_kib': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
    path = ROOT / 'selftests/AUTHOR_SYNTHETIC_EXECUTION_R2.json'
    with path.open('x') as f: json.dump(out, f, indent=2)
    print(json.dumps(out))


if __name__ == '__main__': main()
