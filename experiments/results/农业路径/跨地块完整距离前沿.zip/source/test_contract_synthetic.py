"""Synthetic endpoint binding and report failure denominators; no source archive reads."""
import copy
import hashlib
import json
from common import ROOT, save
from author_worker import verify_endpoint_match
from report import field_summary, failed_field, aggregate, PERCENTAGES


def stub(zero=False):
    core = {'sum_G_mm': 0 if zero else 101, 'max_route_G_mm': 0 if zero else 70,
            'partition': [[1,2],[3,4],[5,6]], 'group_masks': [3,12,48],
            'routes': [[0,1,2,0],[0,3,4,0],[0,5,6,0]], 'route_G_mm': [0,0,0] if zero else [10,21,70]}
    f = dict(core, index=0, assignment_multiplicity_unlabeled=1)
    queries = [dict(core, p=p, budget_total_G_mm=core['sum_G_mm']*(100+p)//100, front_index=0) for p in PERCENTAGES]
    return {'frontier':[f], 'queries':queries,'unique_objective_pairs':1,'catalog':{'synthetic_only':True}}


def main():
    value=stub();f=value['frontier'][0];verify_endpoint_match([f],[f,f]);caught=[]
    for key in ['sum_G_mm','max_route_G_mm','partition','routes','route_G_mm']:
        wrong=copy.deepcopy(f)
        wrong[key]=wrong[key]+1 if type(wrong[key]) is int else []
        try:verify_endpoint_match([f],[f,wrong])
        except ValueError:caught.append(key)
        else:raise AssertionError('WRONG_OLD_ENDPOINT_ACCEPTED')
    assert len(caught)==5
    fields=['SYNTH_%02d'%i for i in range(12)]
    rows=[field_summary(field,stub()) for field in fields]
    complete=aggregate(rows,fields)
    assert complete['verified_derived_decision_rows']==72 and complete['planned_total_frontier_calls']==24
    assert all(b['verified_fields']==12 and b['complete_panel_mean_delta_sum_G_mm']==0 for b in complete['by_budget'])
    rows[5]=failed_field(fields[5],'SYNTHETIC_UNKNOWN_START')
    incomplete=aggregate(rows,fields)
    assert incomplete['verified_derived_decision_rows']==66 and len(rows[5]['queries'])==6
    assert all(b['planned_fields']==12 and b['verified_fields']==11 and b['unverified_fields']==1 and b['complete_panel_mean_delta_sum_G_mm'] is None for b in incomplete['by_budget'])
    zero=aggregate([field_summary(field,stub(True)) for field in fields],fields)
    assert zero['verified_fields']==12 and all(b['defined_denominator_longest_reduction_percent']==0 and b['complete_panel_mean_longest_reduction_percent'] is None for b in zero['by_budget'])
    wrong=stub();wrong['queries'][1]['budget_total_G_mm']+=1
    try:field_summary('BAD_BUDGET',wrong)
    except ValueError:pass
    else:raise AssertionError('ROUNDED_THRESHOLD_MISMATCH_ACCEPTED')
    wrong=stub();wrong['queries']=wrong['queries'][:-1]
    try:field_summary('MISSING_BUDGET',wrong)
    except ValueError:pass
    else:raise AssertionError('MISSING_BUDGET_ROW_ACCEPTED')
    save(ROOT/'selftests/CONTRACT_SYNTHETIC_EXECUTION.json',{'status':'PASS','synthetic_only':True,'real_target_calls':0,'new_optimization_calls':0,'checks':['old_endpoint_all5_core_keys_fail_closed','72rows_12per_budget','failure_retains_six_missing_rows_and_fixed12denominator','zero_cost_percentage_null_not_optimization_failure','integer_threshold_and_missing_query_fail_closed']})
    print('PASS endpoint identity, exact integer budgets and per-budget fixed12 failure denominator.')


if __name__=='__main__':main()
