"""Saved-only field/budget report. No solver imports or candidate search."""
from common import ROOT, read, save, sha, utc, verify_map
from gates import frozen, receipt

PERCENTAGES = (0, 1, 2, 5, 10, 20)
CORE = ('sum_G_mm', 'max_route_G_mm', 'partition', 'routes', 'route_G_mm')


def field_summary(field, value):
    frontier, queries = value['frontier'], value['queries']
    if not frontier or [q['p'] for q in queries] != list(PERCENTAGES):
        raise ValueError('MISSING_PREDEFINED_QUERY')
    first, last = frontier[0], frontier[-1]
    previous_s, previous_m = first['sum_G_mm'], first['max_route_G_mm']
    records = []
    for q in queries:
        p = q['p']; bound = first['sum_G_mm'] * (100 + p) // 100
        selected = frontier[q['front_index']]
        if (q['budget_total_G_mm'] != bound or q['sum_G_mm'] > bound or
                any(q[k] != selected[k] for k in CORE) or
                q['sum_G_mm'] < previous_s or q['max_route_G_mm'] > previous_m or
                (p == 0 and q['front_index'] != 0) or
                (bound >= last['sum_G_mm'] and q['front_index'] != len(frontier) - 1)):
            raise ValueError('SAVED_QUERY_IDENTITY_OR_BUDGET')
        extra = q['sum_G_mm'] - first['sum_G_mm']
        reduction = first['max_route_G_mm'] - q['max_route_G_mm']
        if extra < 0 or reduction < 0 or 100 * extra > p * first['sum_G_mm']:
            raise ValueError('SAVED_QUERY_METRIC_IDENTITY')
        records.append(dict(q, instance_id=field, status='VERIFIED',
                            delta_sum_G_mm=extra, reduction_max_route_G_mm=reduction,
                            extra_total_percent=100 * extra / first['sum_G_mm'] if first['sum_G_mm'] else None,
                            longest_reduction_percent=100 * reduction / first['max_route_G_mm'] if first['max_route_G_mm'] else None))
        previous_s, previous_m = q['sum_G_mm'], q['max_route_G_mm']
    return {'instance_id': field, 'eligible_for_primary': True, 'status': 'VERIFIED_COMPLETE_FRONTIER',
            'frontier_size': len(frontier), 'unique_objective_pairs': value['unique_objective_pairs'],
            'catalog': value['catalog'], 'queries': records}


def failed_field(field, status, error=None):
    return {'instance_id': field, 'eligible_for_primary': False, 'status': status, 'error': error,
            'frontier_size': None, 'queries': [{'instance_id': field, 'p': p, 'status': 'UNVERIFIED',
                'budget_total_G_mm': None, 'delta_sum_G_mm': None, 'reduction_max_route_G_mm': None,
                'extra_total_percent': None, 'longest_reduction_percent': None} for p in PERCENTAGES]}


def aggregate(rows, fields):
    ids = [r['instance_id'] for r in rows]
    if len(ids) != len(set(ids)) or len(fields) != len(set(fields)) or set(ids) != set(fields):
        raise ValueError('REPORT_FIELD_DENOMINATOR_IDENTITY')
    n = sum(r['eligible_for_primary'] for r in rows)
    out = {'status': 'COMPLETE_PANEL' if n == len(fields) else 'INCOMPLETE_PANEL_WITH_EXPLICIT_FAILURE_DENOMINATORS',
           'planned_fields': len(fields), 'verified_fields': n, 'unverified_fields': len(fields) - n,
           'planned_main_calls': len(fields), 'planned_independent_calls': len(fields),
           'planned_total_frontier_calls': 2 * len(fields), 'planned_derived_decision_rows': 6 * len(fields),
           'verified_derived_decision_rows': 6 * n, 'fields': rows, 'by_budget': []}
    for p in PERCENTAGES:
        selected = [next(q for q in r['queries'] if q['p'] == p) for r in rows if r['eligible_for_primary']]
        summary = {'p': p, 'planned_fields': len(fields), 'verified_fields': len(selected),
                   'unverified_fields': len(fields) - len(selected), 'full_panel_available': len(selected) == len(fields)}
        for metric in ('delta_sum_G_mm', 'reduction_max_route_G_mm', 'extra_total_percent', 'longest_reduction_percent'):
            vals = sorted(q[metric] for q in selected if q[metric] is not None)
            mean = sum(vals) / len(vals) if vals else None
            mid = len(vals) // 2
            median = (vals[mid] if len(vals) % 2 else (vals[mid - 1] + vals[mid]) / 2) if vals else None
            summary['defined_denominator_' + metric] = len(vals)
            summary['complete_panel_mean_' + metric] = mean if len(vals) == len(fields) else None
            summary['complete_panel_median_' + metric] = median if len(vals) == len(fields) else None
            summary['complete_case_mean_' + metric] = mean
            summary['complete_case_median_' + metric] = median
        out['by_budget'].append(summary)
    return out


def main():
    digest = frozen()
    rm = receipt(ROOT / 'provenance/RAW_MAIN_DRIVE_RECEIPT.json', 'RAW_MAIN', digest)
    rv = receipt(ROOT / 'provenance/RAW_VERIFICATION_DRIVE_RECEIPT.json', 'RAW_VERIFICATION', digest)
    for base, name in ((ROOT / 'raw', 'RAW_MAIN_CONTENT_MANIFEST.json'),
                       (ROOT / 'independent_supervision/raw', 'RAW_VERIFICATION_CONTENT_MANIFEST.json')):
        verify_map(ROOT, read(base / name)['files'])
    audit = read(ROOT / 'independent_supervision/FINAL_AUDIT.json')
    if (audit.get('status') not in ('PASS', 'AUDIT_COMPLETE_WITH_UNVERIFIED_SLOTS') or
            audit.get('frozen_files_sha256') != digest or audit.get('raw_main_archive_sha256') != rm['sha256'] or
            audit.get('raw_verification_archive_sha256') != rv['sha256']):
        raise ValueError('SAVED_INDEPENDENT_AUDIT_BINDING')
    fields = read(ROOT / 'freeze/PROTOCOL.json')['fields']
    eligible = set(audit['eligible_instance_ids']); rows = []
    for field in fields:
        row = failed_field(field, 'UNVERIFIED_INDEPENDENT_AUDIT')
        if field in eligible:
            try:
                path = ROOT / 'raw/calls' / (field + '_FRONTIER.stdout')
                value = read(path)
                checked = next(x for x in audit['fields'] if x['instance_id'] == field)
                if (checked.get('valid_for_exact_conclusion') is not True or checked.get('main_stdout_sha256') != sha(path) or
                        checked.get('catalog_sha256') != value['catalog']['sha256'] or value['instance_id'] != field or
                        value['frozen_files_sha256'] != digest):
                    raise ValueError('AUDITED_FIELD_BYTE_BINDING')
                row = field_summary(field, value)
            except Exception as exc:
                row = failed_field(field, 'REPORT_EVIDENCE_FAILURE', repr(exc))
        rows.append(row)
    summary = aggregate(rows, fields)
    summary.update(frozen_files_sha256=digest, raw_main_archive_sha256=rm['sha256'], raw_verification_archive_sha256=rv['sha256'],
                   independent_audit_sha256=sha(ROOT / 'independent_supervision/FINAL_AUDIT.json'), utc=utc(), new_optimization_calls=0)
    for label, path in (('main', ROOT / 'raw/ALL_PLANNED_SLOTS.json'), ('independent', ROOT / 'independent_supervision/raw/ALL_PLANNED_SLOTS.json')):
        slots = read(path)
        summary[label + '_known_started_processes'] = sum(s.get('process_spawned') is True for s in slots)
        summary[label + '_unknown_start_slots'] = sum(s.get('process_spawned') == 'UNKNOWN' for s in slots)
    save(ROOT / 'reports/SUMMARY.json', summary)
    lines = ['固定Q5三车：完整总距离/最长路线非支配目标值前沿',
             '固定全部12个已观察NL边界、原depot与客户1..12，单位需求Q5，至多3车强制恰3条闭合路线。',
             '完整核验%s/12；主12加独12正式完整前沿槽全部保留。72个预定义预算决策是派生查询，不是独立实验。新增局部TSP和新图/矩阵均为0。' % summary['verified_fields'],
             '前沿保留每个非支配(sumG,maxG)目标值对，只显示最小Pcode和继承局部(G,E,Rcode)路线；保留并列无标签分组重数。E不是全局目标。不声称枚举了所有并列路线顺序或车辆标签。',
             '每个预算p按精确整数T=Smin*(100+p)//100，选(M,S,Pcode)最小值。预算不会强迫用满；不同预算选择同一点是正常结果。',
             '预算决策表，长度单位为冻结G整数毫米代理换算的米：']
    for row in rows:
        lines.append('%s：前沿点数%s，状态%s。' % (row['instance_id'], row['frontier_size'], row['status']))
        for q in row['queries']:
            if q['status'] != 'VERIFIED':
                lines.append('  额外总距预算%s%%：未核验，保留在分母中。' % q['p'])
            else:
                lines.append('  预算%s%%：总距%.3f米，最长%.3f米；实际额外总距%.3f米，最长减少%.3f米；前沿索引%s。' %
                             (q['p'], q['sum_G_mm']/1000, q['max_route_G_mm']/1000, q['delta_sum_G_mm']/1000, q['reduction_max_route_G_mm']/1000, q['front_index']))
    lines.append('逐预算完整12田描述统计，未全核验则完整面板统计为空；缺失不是零：')
    for b in summary['by_budget']:
        means = [b['complete_panel_mean_' + k] for k in ('delta_sum_G_mm', 'reduction_max_route_G_mm')]
        values = ['未形成完整面板' if x is None else '%.6f米' % (x / 1000) for x in means]
        lines.append('预算%s%%：核验%s/12，平均额外总距%s，平均最长减少%s。' % (b['p'], b['verified_fields'], *values))
    lines.extend(['完整前沿及各点见证见原始FRONTIER输出，全部41811规范分组及相等/支配证书见紧凑CSV目录；米显示仅为单位换算。',
                  '最长路线是距离负担，不能解释为工期、完工时间、速度、能耗、需求载荷均等、极差或变异系数；无车际同步或碰撞模型。',
                  '取整加保存路径容差：两方案总距差界0.01500030米、最长路线差界0.00600012米，仅对固定路径与整数代理；不保证物理路径下的前沿成员关系或排序，也不是测绘/连续几何误差界。',
                  '真实边界配合合成任务与容量；全部字段早已观察，仅作探索性受控机制证据，无未见泛化、总体推断、实车节省、车辆数因果主张。',
                  '各预算固定分母12；失败田6行均保留，无补跑、替换或预算增加。前沿点、候选分组、标签及6预算不是独立科学样本。'])
    with (ROOT / 'reports/REPORT_ZH.txt').open('x') as f: f.write('\n'.join(lines) + '\n')
    print('Saved-only frontier/budget report written; independent report review and FINAL private byte readback required.')


if __name__ == '__main__': main()
