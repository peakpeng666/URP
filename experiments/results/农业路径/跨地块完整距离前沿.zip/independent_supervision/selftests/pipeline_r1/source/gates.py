# Explicit invented-fixture-only gates; copied worker code points only to this isolated tree.
def active_main_gate():return 'INVENTED_ONLY'
def verification_ready():return 'INVENTED_ONLY'
