"""Complete objective-value Pareto frontier, never file I/O or local TSP.
Inherited (G,E,Rcode) rows witness local G minima. E is not an objective.
"""
import bisect
import hashlib
import itertools
import json
from collections import Counter

BUDGET_PERCENTAGES = (0, 1, 2, 5, 10, 20)
BASE_HEADER = 'mask1,mask2,mask3,sum_G_mm,max_route_G_mm\n'
CATALOG_HEADER = BASE_HEADER.rstrip('\n') + ',front_index,relation\n'
CORE = ('sum_G_mm', 'max_route_G_mm', 'partition', 'routes', 'route_G_mm')


def validate(local_rows, n, Q):
    if type(n) is not int or type(Q) is not int or not (3 <= n <= 12 and 1 <= Q <= 5 and n <= 3 * Q):
        raise ValueError('UNSUPPORTED_THREE_ROUTE_MODEL')
    minimum = max(1, n - 2 * Q)
    expected = {sum(1 << (x - 1) for x in group): group
                for size in range(minimum, min(Q, n) + 1)
                for group in itertools.combinations(range(1, n + 1), size)}
    local = {}
    for row in local_rows:
        mask = row['mask']
        if type(mask) is not int or mask not in expected or mask in local:
            raise ValueError('INVALID_OR_DUPLICATE_LOCAL_MASK')
        group = expected[mask]
        if row['customers'] != list(group) or any(type(x) is not int for x in row['customers']):
            raise ValueError('LOCAL_CUSTOMER_IDENTITY')
        route = row['route']
        if (not isinstance(route, list) or len(route) != len(group) + 2 or
                any(type(x) is not int for x in route) or route[0] != 0 or route[-1] != 0 or
                sorted(route[1:-1]) != list(group) or tuple(route[1:-1]) > tuple(reversed(route[1:-1]))):
            raise ValueError('INVALID_INHERITED_ROUTE')
        if any(type(row[k]) is not int or row[k] < 0 for k in ('E', 'G')):
            raise ValueError('INVALID_LOCAL_INTEGER_COST')
        local[mask] = row
    if set(local) != set(expected):
        raise ValueError('INCOMPLETE_LOCAL_TABLE')
    return local, minimum


def skyline(pair_representatives):
    """One representative per exact pair. Equal objective pairs never dominate."""
    output, best_max = [], None
    for pair in sorted(pair_representatives):
        total, maximum = pair
        if best_max is None or maximum < best_max:
            output.append(pair)
            best_max = maximum
    return output


def budget_queries(frontier, percentages=BUDGET_PERCENTAGES):
    if not frontier:
        raise ValueError('EMPTY_FRONTIER')
    smin = frontier[0]['sum_G_mm']
    queries = []
    for p in percentages:
        if type(p) is not int or p < 0:
            raise ValueError('NONINTEGER_OR_NEGATIVE_BUDGET')
        threshold = smin * (100 + p) // 100
        choices = [f for f in frontier if f['sum_G_mm'] <= threshold]
        chosen = min(choices, key=lambda f: (f['max_route_G_mm'], f['sum_G_mm'], f['partition']))
        queries.append({'p': p, 'budget_total_G_mm': threshold, 'front_index': chosen['index'],
                        **{k: chosen[k] for k in CORE}, 'group_masks': chosen['group_masks']})
    return queries


def solve(local_rows, n, Q):
    local, minimum = validate(local_rows, n, Q)

    def partitions(remaining, groups):
        if groups == 1:
            if minimum <= len(remaining) <= Q:
                yield (remaining,)
            return
        anchor, tail = remaining[0], remaining[1:]
        low = max(minimum, len(remaining) - (groups - 1) * Q)
        high = min(Q, len(remaining) - (groups - 1) * minimum)
        for size in range(low, high + 1):
            for other in itertools.combinations(tail, size - 1):
                group = (anchor,) + other
                members = set(group)
                rest = tuple(x for x in remaining if x not in members)
                for suffix in partitions(rest, groups - 1):
                    yield (group,) + suffix

    catalog, pairs, size_counts = {}, {}, Counter()
    for partition in partitions(tuple(range(1, n + 1)), 3):
        if partition in catalog:
            raise AssertionError('DUPLICATE_UNLABELED_PARTITION')
        masks = tuple(sum(1 << (x - 1) for x in g) for g in partition)
        values = [local[m]['G'] for m in masks]
        total, maximum = sum(values), max(values)
        catalog[partition] = (masks, total, maximum)
        pair = total, maximum
        if pair not in pairs:
            pairs[pair] = [partition, 1]
        else:
            pairs[pair][0] = min(pairs[pair][0], partition)
            pairs[pair][1] += 1
        size_counts[','.join(map(str, sorted(map(len, partition))))] += 1
    if not catalog:
        raise ValueError('NO_FEASIBLE_PARTITION')
    front_pairs = skyline(pairs)
    frontier = []
    for index, (total, maximum) in enumerate(front_pairs):
        partition, multiplicity = pairs[total, maximum]
        masks = catalog[partition][0]
        rows = [local[m] for m in masks]
        frontier.append({'index': index, 'sum_G_mm': total, 'max_route_G_mm': maximum,
                         'partition': [list(g) for g in partition], 'group_masks': list(masks),
                         'routes': [r['route'] for r in rows], 'route_G_mm': [r['G'] for r in rows],
                         'assignment_multiplicity_unlabeled': multiplicity})
    sums = [p[0] for p in front_pairs]
    full_hash = hashlib.sha256(CATALOG_HEADER.encode('ascii'))
    base_hash = hashlib.sha256(BASE_HEADER.encode('ascii'))
    compact_rows, relations = [], Counter()
    for partition in sorted(catalog):
        masks, total, maximum = catalog[partition]
        idx = bisect.bisect_right(sums, total) - 1
        fs, fm = front_pairs[idx]
        if not (fs <= total and fm <= maximum):
            raise AssertionError('FRONTIER_COVERAGE_CERTIFICATE')
        relation = 'E' if (fs, fm) == (total, maximum) else 'D'
        relations[relation] += 1
        prefix = ','.join(map(str, (*masks, total, maximum)))
        base_hash.update((prefix + '\n').encode('ascii'))
        line = prefix + ',' + str(idx) + ',' + relation + '\n'
        full_hash.update(line.encode('ascii'))
        compact_rows.append(line)
    coverage = json.dumps(sorted(catalog), separators=(',', ':')).encode()
    return {'objective': 'FRONTIER', 'n': n, 'Q': Q, 'K': 3,
            'frontier': frontier, 'queries': budget_queries(frontier),
            'frontier_size': len(frontier), 'unique_objective_pairs': len(pairs),
            'catalog': {'schema': 'CANONICAL_PARTITION_FRONTIER_CERTIFICATE_V1',
                        'header': CATALOG_HEADER.rstrip('\n'), 'rows': len(compact_rows),
                        'sha256': full_hash.hexdigest(), 'normalized_objective_catalog_sha256': base_hash.hexdigest(),
                        'relation_counts': dict(relations)},
            'counters': {'local_subsets': len(local), 'new_local_tsp_evaluations': 0,
                         'unlabeled_partition_evaluations': len(catalog),
                         'unique_canonical_partitions': len(catalog), 'partition_size_counts': dict(size_counts),
                         'canonical_partition_coverage_sha256': hashlib.sha256(coverage).hexdigest()},
            'witness_rule': 'Inherited local (G,E,Rcode); E absent from both global costs'}, compact_rows


def write_catalog(path, row, lines):
    with path.open('x', encoding='ascii', newline='') as f:
        f.write(CATALOG_HEADER)
        f.writelines(lines)
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != row['catalog']['sha256']:
        raise AssertionError('WRITTEN_CATALOG_IDENTITY')
    row['catalog']['bytes'] = len(raw)
