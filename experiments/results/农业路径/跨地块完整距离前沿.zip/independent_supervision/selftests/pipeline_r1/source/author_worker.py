"""One formally gated complete frontier call and its six derived budget queries."""
import json
import resource
import sys
import time
from gates import active_main_gate
from common import ROOT
from inputs import load_input, load_endpoints
from author_solver import solve, write_catalog, CORE


def verify_endpoint_match(frontier, endpoints):
    if not frontier or len(endpoints) != 2:
        raise ValueError('MISSING_ENDPOINT_REFERENCE')
    for current, saved in zip((frontier[0], frontier[-1]), endpoints):
        if any(current[k] != saved[k] for k in CORE):
            raise ValueError('OLD_ENDPOINT_MISMATCH_DO_NOT_REPAIR_FRONTIER')


def main():
    assert __debug__
    digest = active_main_gate()
    field, objective = sys.argv[1:]
    if objective != 'FRONTIER':
        raise ValueError('UNSCHEDULED_OBJECTIVE')
    started, cpu = time.monotonic(), time.process_time()
    table, identity = load_input(field)
    row, lines = solve(table, 12, 5)
    endpoints, endpoint_identity = load_endpoints(field)
    verify_endpoint_match(row['frontier'], endpoints)
    path = ROOT / 'raw/catalogs' / (field + '_FRONTIER.csv')
    write_catalog(path, row, lines)
    row['catalog']['path'] = str(path.relative_to(ROOT))
    row.update(instance_id=field, frozen_files_sha256=digest, input_identity=identity,
               endpoint_identity=endpoint_identity, endpoints_match_frozen_prior=True,
               status='PROCESS_SUCCESS_UNREVIEWED', resources={
                   'wall_seconds': time.monotonic() - started, 'cpu_seconds': time.process_time() - cpu,
                   'maxrss_kib': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                   'cpu_limits': list(resource.getrlimit(resource.RLIMIT_CPU)),
                   'as_limits': list(resource.getrlimit(resource.RLIMIT_AS))})
    print(json.dumps(row, allow_nan=False))


if __name__ == '__main__':
    main()
