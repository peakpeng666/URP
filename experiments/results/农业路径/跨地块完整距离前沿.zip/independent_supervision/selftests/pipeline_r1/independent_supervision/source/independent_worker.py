"""One declared independent frontier and six labelled-catalog budget checks."""
import pathlib,sys,json,hashlib,time,resource
ROOT=pathlib.Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'source'))
from gates import verification_ready
from read_catalog import load_input,load_endpoints
from reverse_frontier import solve,HEADER
CORE=('sum_G_mm','max_route_G_mm','partition','routes','route_G_mm')
def main():
    assert __debug__;digest=verification_ready();launch=json.loads((ROOT/'provenance/VALIDATION_LAUNCH_STARTED.json').read_text());assert launch['frozen_files_sha256']==digest
    field,objective=sys.argv[1:];assert objective=='FRONTIER';wall=time.monotonic();cpu=time.process_time();table,identity=load_input(field);result,csv=solve(table,12,5);ends,endident=load_endpoints(field)
    for current,old in zip((result['frontier'][0],result['frontier'][-1]),ends):
        for k in CORE:assert current[k]==old[k],('old endpoint mismatch',k)
    dest=ROOT/'independent_supervision/raw/catalogs';dest.mkdir(exist_ok=True);path=dest/(field+'_FRONTIER.csv')
    with path.open('xb')as f:f.write(csv)
    lines=csv.splitlines()[1:];E=sum(r.endswith(b',E')for r in lines)
    result['catalog']={'schema':'CANONICAL_PARTITION_FRONTIER_CERTIFICATE_V1','header':HEADER.rstrip('\n'),'rows':len(lines),'sha256':hashlib.sha256(csv).hexdigest(),'normalized_objective_catalog_sha256':result.pop('normalized_catalog_sha256'),'relation_counts':{'E':E,'D':len(lines)-E},'bytes':len(csv),'path':str(path.relative_to(ROOT))}
    result.update(objective=objective,instance_id=field,frozen_files_sha256=digest,frontier_size=len(result['frontier']),unique_objective_pairs=len({tuple(map(int,r.split(b',')[3:5]))for r in lines}),input_identity=identity,endpoint_identity=endident,endpoints_match_frozen_prior=True,status='PROCESS_SUCCESS_UNREVIEWED',resources={'wall_seconds':time.monotonic()-wall,'cpu_seconds':time.process_time()-cpu,'maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'cpu_limits':list(resource.getrlimit(resource.RLIMIT_CPU)),'as_limits':list(resource.getrlimit(resource.RLIMIT_AS))})
    print(json.dumps(result,allow_nan=False))
if __name__=='__main__':main()
