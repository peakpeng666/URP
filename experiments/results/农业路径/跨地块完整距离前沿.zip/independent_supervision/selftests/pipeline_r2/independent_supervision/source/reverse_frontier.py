"""Independent labelled enumeration and reverse epsilon envelope. No author optimizer or real data access."""
from collections import Counter
from array import array
from bisect import bisect_right
import hashlib,json
BUDGETS=(0,1,2,5,10,20)
HEADER='mask1,mask2,mask3,sum_G_mm,max_route_G_mm,front_index,relation\n'
NORMAL_HEADER='mask1,mask2,mask3,sum_G_mm,max_route_G_mm\n'

def solve(local_rows,n,Q):
    assert 3<=n<=12 and 1<=Q<=5 and n<=3*Q
    full=(1<<n)-1;low=max(1,n-2*Q);local={}
    for row in local_rows:
        mask=row['mask'];assert type(mask)is int and mask not in local and 0<mask<=full and low<=mask.bit_count()<=Q
        group=tuple(i for i in range(1,n+1)if mask>>(i-1)&1)
        assert row['customers']==list(group)and row['route'][0]==row['route'][-1]==0 and sorted(row['route'][1:-1])==list(group)
        assert type(row['G'])is int and 0<=row['G']<2**32
        local[mask]=(group,row)
    assert set(local)=={m for m in range(1,full+1)if low<=m.bit_count()<=Q}
    labels=array('I');catalog={};multiplicity=Counter();modes=Counter();checks=0
    for A in sorted(local):
        rest=full^A;B=rest
        while B:
            checks+=1;C=rest^B
            if B in local and C in local:
                masks=tuple(sorted((A,B,C),key=lambda m:local[m][0]));P=tuple(local[m][0]for m in masks)
                costs=[local[m][1]['G']for m in masks];S=sum(costs);M=max(costs);assert S<2**32
                labels.extend((A,B,C,S,M))
                if P in catalog:assert catalog[P]==(masks,S,M),'label permutation consistency'
                catalog[P]=(masks,S,M);multiplicity[P]+=1;modes[','.join(map(str,sorted(map(len,P))))]+=1
            B=(B-1)&rest
    assert catalog and all(v==6 for v in multiplicity.values())
    # M ascending: within equal M retain minimal S; accept a bucket iff S strictly improves the previous minimum.
    buckets={};pair_counts=Counter()
    for P,(masks,S,M)in catalog.items():
        pair_counts[(S,M)]+=1
        candidate=(S,P)
        if M not in buckets or candidate<buckets[M]:buckets[M]=candidate
    reverse=[];bestS=None
    for M in sorted(buckets):
        S,P=buckets[M]
        if bestS is None or S<bestS:reverse.append((S,M,P));bestS=S
    values=list(reversed(reverse));assert all(a[0]<b[0]and a[1]>b[1]for a,b in zip(values,values[1:]))
    front=[]
    for index,(S,M,P)in enumerate(values):
        masks=catalog[P][0];front.append({'index':index,'sum_G_mm':S,'max_route_G_mm':M,'partition':[list(g)for g in P],'group_masks':list(masks),'routes':[local[m][1]['route']for m in masks],'route_G_mm':[local[m][1]['G']for m in masks],'assignment_multiplicity_unlabeled':pair_counts[(S,M)]})
    firstS=front[0]['sum_G_mm'];query_keys=[None]*len(BUDGETS)
    # Direct scan of every labelled assignment for each declared integer budget; no selection from front is used here.
    for pos in range(0,len(labels),5):
        A,B,C,S,M=labels[pos:pos+5];P=tuple(sorted((local[A][0],local[B][0],local[C][0])));key=(M,S,P)
        for j,p in enumerate(BUDGETS):
            if 100*S<=(100+p)*firstS and(query_keys[j]is None or key<query_keys[j]):query_keys[j]=key
    by_pair={(r['sum_G_mm'],r['max_route_G_mm']):r for r in front};queries=[]
    for p,key in zip(BUDGETS,query_keys):
        M,S,P=key;r=by_pair[(S,M)];assert r['partition']==[list(g)for g in P]
        queries.append({'p':p,'budget_total_G_mm':((100+p)*firstS)//100,'front_index':r['index'],**{k:v for k,v in r.items()if k!='index'}})
    frontS=[r['sum_G_mm']for r in front];csv=[HEADER];normal=[NORMAL_HEADER]
    for P,(masks,S,M)in sorted(catalog.items()):
        index=bisect_right(frontS,S)-1;f=front[index];assert f['sum_G_mm']<=S and f['max_route_G_mm']<=M
        relation='E'if(f['sum_G_mm'],f['max_route_G_mm'])==(S,M)else'D'
        prefix=','.join(map(str,(*masks,S,M)));normal.append(prefix+'\n');csv.append(prefix+f',{index},{relation}\n')
    normalized=''.join(normal).encode();csvbytes=''.join(csv).encode();coverage=json.dumps([list(map(list,P))for P in sorted(catalog)],separators=(',',':')).encode()
    result={'n':n,'Q':Q,'K':3,'frontier':front,'queries':queries,'counters':{'available_local_subsets':len(local),'B_nonempty_submasks_checked':checks,'labeled_feasible_partitions':len(labels)//5,'unique_canonical_partitions':len(catalog),'canonical_partition_multiplicities':dict(Counter(map(str,multiplicity.values()))),'labeled_size_pattern_counts':dict(modes),'canonical_partition_coverage_sha256':hashlib.sha256(coverage).hexdigest(),'repeated_partition_consistency_checks':len(labels)//5-len(catalog),'budget_labeled_assignment_checks':(len(labels)//5)*len(BUDGETS),'additional_local_TSP_calls':0},'normalized_catalog_sha256':hashlib.sha256(normalized).hexdigest()}
    return result,csvbytes
