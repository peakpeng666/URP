"""Small invented multi-frontier cases and saved certificate rejection tests, no real data."""
from test_reverse import make,brute
from reverse_frontier import solve,HEADER
from saved_audit import check_catalog
import hashlib,copy,json,pathlib,time,resource,signal

def decorated(result,csv):
    x=copy.deepcopy(result);ls=csv.splitlines()[1:];E=sum(l.endswith(b',E')for l in ls)
    x['frontier_size']=len(x['frontier']);x['unique_objective_pairs']=len({tuple(map(int,l.split(b',')[3:5]))for l in ls});x['catalog']={'schema':'CANONICAL_PARTITION_FRONTIER_CERTIFICATE_V1','header':HEADER.rstrip('\n'),'rows':len(ls),'sha256':hashlib.sha256(csv).hexdigest(),'normalized_objective_catalog_sha256':x['normalized_catalog_sha256'],'relation_counts':{'E':E,'D':len(ls)-E},'bytes':len(csv)}
    return x

def reject(fn):
    try:fn()
    except (AssertionError,ValueError,KeyError,IndexError):return
    raise AssertionError('bad saved certificate accepted')

def main():
    resource.setrlimit(resource.RLIMIT_CPU,(15,15));resource.setrlimit(resource.RLIMIT_AS,(268435456,268435456));signal.alarm(30);cpu=time.process_time();w=time.monotonic();cases=[]
    for tiedsum in(False,True):
        rows=make(6,2,0);weights={(1,2):10,(3,4):3 if tiedsum else1,(5,6):2 if tiedsum else1,(1,3):5,(2,5):5,(4,6):5}
        for r in rows:r['G']=weights.get(tuple(r['customers']),100)
        x,csv=solve(rows,6,2);catalog,expected=brute(rows,6,2);assert[(r['sum_G_mm'],r['max_route_G_mm'])for r in x['frontier']]==expected
        assert expected==([(15,5)]if tiedsum else[(12,10),(15,5)])
        a=decorated(x,csv);local={r['mask']:r for r in rows};check_catalog(a,csv,local,6,2)
        for change in [lambda y:y['frontier'][0].__setitem__('assignment_multiplicity_unlabeled',999),lambda y:y['queries'][0].__setitem__('budget_total_G_mm',999),lambda y:y['frontier'][0]['routes'][0].__setitem__(1,6)]:
            b=copy.deepcopy(a);change(b);reject(lambda:check_catalog(b,csv,local,6,2))
        if not tiedsum:
            b=copy.deepcopy(a);b['frontier'].pop();b['frontier_size']=1;reject(lambda:check_catalog(b,csv,local,6,2))
        cases.append({'tie_total':tiedsum,'frontier':expected,'catalog_rows':len(catalog)})
    out={'status':'PASS','invented_frontier_calls':2,'real_frontier_calls':0,'new_local_TSP_calls':0,'cases':cases,'checks':['full dominated-record coverage and antichain','equalS smallerM eliminates weakly worse pair','minPcode and pair multiplicity','exact integer query bounds','missingfront wrongmultiplicity wrongroute wrongbudget rejected'],'resources':{'cpu':time.process_time()-cpu,'wall':time.monotonic()-w}}
    p=pathlib.Path(__file__).resolve().parents[1]/'selftests/MULTI_CERTIFICATE_R1.json';p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
