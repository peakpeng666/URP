import itertools,json,hashlib,resource,signal,time,pathlib
from reverse_frontier import solve,BUDGETS

def make(n,Q,mode):
    low=max(1,n-2*Q);rows=[]
    for m in range(1,1<<n):
        c=[i+1 for i in range(n)if m>>i&1]
        if low<=len(c)<=Q:
            G=1 if mode==0 else(1+(m*19+mode*13)%31 if mode==1 else(m%7)**2)
            rows.append({'mask':m,'customers':c,'route':[0,*c,0],'G':G,'E':100+G})
    return rows

def brute(rows,n,Q):
    costs={r['mask']:r['G']for r in rows};catalog={}
    for labels in itertools.product(range(3),repeat=n):
        groups=tuple(sorted(tuple(i+1 for i,v in enumerate(labels)if v==k)for k in range(3)))
        if any(not g or len(g)>Q for g in groups):continue
        masks=[sum(1<<(i-1)for i in g)for g in groups]
        if not all(m in costs for m in masks):continue
        lengths=[costs[m]for m in masks];catalog[groups]=(sum(lengths),max(lengths))
    pairs=set(catalog.values());good={v for v in pairs if not any(w!=v and w[0]<=v[0]and w[1]<=v[1]for w in pairs)}
    return catalog,sorted(good)

def main():
    resource.setrlimit(resource.RLIMIT_CPU,(15,15));resource.setrlimit(resource.RLIMIT_AS,(256*1024**2,256*1024**2));signal.alarm(30);cpu=time.process_time();wall=time.monotonic();checks=[]
    for mode in range(3):
        rows=make(6,2,mode);out,csv=solve(rows,6,2);cat,front=brute(rows,6,2)
        assert [(r['sum_G_mm'],r['max_route_G_mm'])for r in out['frontier']]==front
        for r in out['frontier']:
            pair=(r['sum_G_mm'],r['max_route_G_mm']);assert r['partition']==list(map(list,min(P for P,v in cat.items()if v==pair)));assert r['assignment_multiplicity_unlabeled']==sum(v==pair for v in cat.values())
        Smin=front[0][0]
        for q in out['queries']:
            expected=min((M,S,P)for P,(S,M)in cat.items()if 100*S<=(100+q['p'])*Smin)
            assert(q['max_route_G_mm'],q['sum_G_mm'],tuple(map(tuple,q['partition'])))==expected
        assert len(csv.splitlines())==len(cat)+1;checks.append({'n':6,'mode':mode,'frontier_count':len(front),'canonical_partitions':len(cat)})
    out,csv=solve(make(12,5,0),12,5);c=out['counters'];assert c['labeled_feasible_partitions']==250866 and c['B_nonempty_submasks_checked']==406747 and c['unique_canonical_partitions']==41811 and c['canonical_partition_multiplicities']=={'6':41811}
    assert c['canonical_partition_coverage_sha256']=='116b468381296d0ed29066b7293164087fc03edc32b8105cd328b9f396e2c9d3'
    assert c['budget_labeled_assignment_checks']==1505196 and len(out['frontier'])==1 and out['frontier'][0]['assignment_multiplicity_unlabeled']==41811
    normal=b'mask1,mask2,mask3,sum_G_mm,max_route_G_mm\n'+b''.join(b','.join(line.split(b',')[:5])+b'\n'for line in csv.splitlines()[1:]);assert hashlib.sha256(normal).hexdigest()==out['normalized_catalog_sha256']
    record={'status':'PASS','invented_frontier_calls':4,'new_real_frontier_calls':0,'new_local_TSP_calls':0,'checks':checks,'n12_counters':c,'resources':{'cpu_seconds':time.process_time()-cpu,'wall_seconds':time.monotonic()-wall,'peak_rss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}}
    dest=pathlib.Path(__file__).resolve().parents[1]/'selftests';(dest/'CORE_SYNTHETIC_R1.json').write_text(json.dumps(record,indent=2)+'\n');(dest/'N12_TIE_CATALOG.csv').write_bytes(csv);print(json.dumps(record))
if __name__=='__main__':main()
