"""Cross-check saved-only report reducers using already generated invented evidence."""
import pathlib,sys,json,copy,hashlib
ROOT=pathlib.Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'source'))
import report as author
import review_final as independent

def main():
    sample=json.loads((ROOT/'independent_supervision/selftests/pipeline_r2/raw/calls/INVENTED_FIELD_FRONTIER.stdout').read_text());fields=['INVENTED_FIELD_'+str(i)for i in range(12)]
    audit={'verified_fields':12,'fields':[],'main_counts':{'known_spawned':12,'unknown_spawned_slots':0},'independent_counts':{'known_spawned':12,'unknown_spawned_slots':0}}
    rows=[]
    for f in fields:
        value=copy.deepcopy(sample);value['instance_id']=f;rows.append(author.field_summary(f,value));audit['fields'].append({'instance_id':f,'valid_for_exact_conclusion':True,'frontier':value['frontier'],'queries':value['queries'],'frontier_size':value['frontier_size'],'catalog_sha256':value['catalog']['sha256']})
    independent.read=lambda p:{'fields':fields}
    def reduce(rr):
        s=author.aggregate(rr,fields)
        for label in('main','independent'):s[label+'_known_started_processes']=12;s[label+'_unknown_start_slots']=0
        return s
    full=reduce(rows);assert independent.check(audit,full)
    broken=copy.deepcopy(full);broken['by_budget'][0]['complete_panel_mean_delta_sum_G_mm']=1
    try:independent.check(audit,broken)
    except AssertionError:pass
    else:raise AssertionError('changed aggregate accepted')
    partial=copy.deepcopy(rows);partial[3]=author.failed_field(fields[3],'INVENTED_FAILURE');a=copy.deepcopy(audit);a['fields'][3]['valid_for_exact_conclusion']=False;a['verified_fields']=11;s=reduce(partial);assert independent.check(a,s)and s['verified_derived_decision_rows']==66 and s['planned_derived_decision_rows']==72 and all(b['complete_panel_mean_delta_sum_G_mm']is None for b in s['by_budget'])
    out={'status':'PASS','invented_fields':12,'derived_rows':72,'partial_valid_fields':11,'partial_valid_rows':66,'new_frontier_calls':0,'new_local_TSP_calls':0,'checks':['author/independent72 derivedrows and6budget aggregates','all12 denominator and66/72 partial retention','wrong aggregate rejected']}
    (ROOT/'independent_supervision/selftests/REPORT_REPLAY_R1.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
