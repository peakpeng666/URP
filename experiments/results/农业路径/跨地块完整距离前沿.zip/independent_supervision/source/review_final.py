"""Independent saved report reduction; no new frontier or partition optimization."""
from saved_audit import *
import math

def close(a,b):
    if a is None or b is None:return a is b
    return type(a)in(int,float)and type(b)in(int,float)and math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-12)

def check(a,s):
    fields=read(ROOT/'freeze/PROTOCOL.json')['fields'];assert [r['instance_id']for r in s['fields']]==fields
    eligible={f['instance_id']:f for f in a['fields']if f['valid_for_exact_conclusion']};assert s['verified_fields']==len(eligible)and s['planned_fields']==12 and s['planned_derived_decision_rows']==72 and s['verified_derived_decision_rows']==len(eligible)*6
    values={p:[]for p in(0,1,2,5,10,20)}
    for field in s['fields']:
        f=field['instance_id'];assert field['eligible_for_primary']==(f in eligible)and [q['p']for q in field['queries']]==list(values)
        if f not in eligible:
            assert all(q['status']=='UNVERIFIED'and q['delta_sum_G_mm']is None and q['reduction_max_route_G_mm']is None for q in field['queries']);continue
        source=eligible[f];assert field['frontier_size']==source['frontier_size']and field['catalog']['sha256']==source['catalog_sha256'];first=source['frontier'][0]
        for q,saved in zip(field['queries'],source['queries']):
            assert all(q[k]==saved[k]for k in QUERY_KEYS)
            delta=q['sum_G_mm']-first['sum_G_mm'];reduction=first['max_route_G_mm']-q['max_route_G_mm'];metrics={'delta_sum_G_mm':delta,'reduction_max_route_G_mm':reduction,'extra_total_percent':100*delta/first['sum_G_mm']if first['sum_G_mm']else None,'longest_reduction_percent':100*reduction/first['max_route_G_mm']if first['max_route_G_mm']else None}
            assert all(close(q[k],v)for k,v in metrics.items());values[q['p']].append(metrics)
    assert [b['p']for b in s['by_budget']]==list(values)
    for b in s['by_budget']:
        rr=values[b['p']];assert b['planned_fields']==12 and b['verified_fields']==len(rr)and b['unverified_fields']==12-len(rr)
        for k in('delta_sum_G_mm','reduction_max_route_G_mm','extra_total_percent','longest_reduction_percent'):
            v=sorted(r[k]for r in rr if r[k]is not None);n=len(v);mean=sum(v)/n if n else None;median=(v[n//2]if n%2 else(v[n//2-1]+v[n//2])/2)if n else None
            assert b['defined_denominator_'+k]==n
            for stat,expected in(('mean',mean),('median',median)):
                assert close(b['complete_case_'+stat+'_'+k],expected)and close(b['complete_panel_'+stat+'_'+k],expected if n==12 else None)
    for name in('main','independent'):assert s[name+'_known_started_processes']==a[name+'_counts']['known_spawned']and s[name+'_unknown_start_slots']==a[name+'_counts']['unknown_spawned_slots']
    return True

def main():
    resource.setrlimit(resource.RLIMIT_CPU,(15,15));resource.setrlimit(resource.RLIMIT_AS,(268435456,268435456));signal.alarm(30);c=time.process_time();w=time.monotonic();h=frozen();rm=receipt(ROOT/'provenance/RAW_MAIN_DRIVE_RECEIPT.json','RAW_MAIN',h);rv=receipt(ROOT/'provenance/RAW_VERIFICATION_DRIVE_RECEIPT.json','RAW_VERIFICATION',h)
    a=read(ROOT/'independent_supervision/FINAL_AUDIT.json');s=read(ROOT/'reports/SUMMARY.json');assert a['status']in('PASS','AUDIT_COMPLETE_WITH_UNVERIFIED_SLOTS')
    for obj in(a,s):assert obj['frozen_files_sha256']==h and obj['raw_main_archive_sha256']==rm['sha256']and obj['raw_verification_archive_sha256']==rv['sha256']
    assert s['independent_audit_sha256']==sha(ROOT/'independent_supervision/FINAL_AUDIT.json');check(a,s)
    text=(ROOT/'reports/REPORT_ZH.txt').read_text()
    for phrase in('非支配','12','72','Pcode','0.01500030','0.00600012','工期','未见泛化'):assert phrase in text
    result={'status':'PASS','utc':utc(),'frozen_files_sha256':h,'raw_main_archive_sha256':rm['sha256'],'raw_verification_archive_sha256':rv['sha256'],'report_sha256':sha(ROOT/'reports/REPORT_ZH.txt'),'summary_sha256':sha(ROOT/'reports/SUMMARY.json'),'independent_audit_sha256':sha(ROOT/'independent_supervision/FINAL_AUDIT.json'),'verified_fields':a['verified_fields'],'planned_budget_rows':72,'new_frontier_or_local_TSP_calls':0,'resources':{'cpu_seconds':time.process_time()-c,'wall_seconds':time.monotonic()-w}}
    save(ROOT/'independent_supervision/FINAL_REPORT_REVIEW.json',result);print(json.dumps(result))
if __name__=='__main__':main()
