"""Invented complete worker paths and24 saved-certificate checks. Isolated fixture gates never touch formal data."""
import pathlib,json,hashlib,zipfile,shutil,sys,time,resource,signal,copy
ROOT=pathlib.Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'source'))
from tree_runtime import run_command
from saved_audit import check_catalog
from reverse_frontier import solve
from test_reverse import make,brute
from test_certificates import decorated,reject

def h(b):return hashlib.sha256(b).hexdigest()
def write(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')
def makezip(path,objects):
    path.parent.mkdir(parents=True,exist_ok=True);meta={}
    with zipfile.ZipFile(path,'x',zipfile.ZIP_DEFLATED)as z:
        for name,value in objects.items():
            data=json.dumps(value).encode();z.writestr(name,data);meta[name]={'bytes':len(data),'sha256':h(data)}
    return meta

def main():
    resource.setrlimit(resource.RLIMIT_CPU,(15,60));resource.setrlimit(resource.RLIMIT_AS,(268435456,268435456));signal.alarm(30);start=time.monotonic();cpu=time.process_time();D=ROOT/'independent_supervision/selftests/pipeline_r2';D.mkdir(exist_ok=False);field='INVENTED_FIELD';digest='INVENTED_ONLY'
    rows=make(12,5,0)
    for r in rows:r['E']=r['G']=len(r['customers'])+1
    M=[[0 if i==j else 1 for j in range(13)]for i in range(13)]
    parent={'status':'PROCESS_SUCCESS_UNREVIEWED','instance_id':field,'objective':'G_E','n':12,'Q':5,'K':3,'frozen_files_sha256':digest,'local_routes':rows,'input_matrices':{'E':M,'G':M}}
    aud={'status':'PASS','frozen_files_sha256':digest,'eligible_instance_ids':[field]}
    members={'raw/calls/'+field+'_G_E.stdout':parent,'independent_supervision/raw/calls/'+field+'_G_E.stdout':parent,'independent_supervision/FINAL_AUDIT.json':aud}
    ids=makezip(D/'input/CAPACITY_FINAL.zip',members)
    partition=[list(range(1,5)),list(range(5,9)),list(range(9,13))];routes=[[0,*g,0]for g in partition]
    objs={'independent_supervision/FINAL_AUDIT.json':aud}
    for o in('SUM_MAX','MAX_SUM'):
        v={'instance_id':field,'objective':o,'frozen_files_sha256':digest,'sum_G_mm':15,'max_route_G_mm':5,'partition':partition,'routes':routes,'route_G_mm':[5,5,5]}
        objs[f'raw/calls/{field}_{o}.stdout']=v;objs[f'independent_supervision/raw/calls/{field}_{o}.stdout']=v
    ends=makezip(D/'input/BALANCE_FINAL.zip',objs)
    protocol={'fields':[field],'source':{'archive':'input/CAPACITY_FINAL.zip','archive_sha256':h((D/'input/CAPACITY_FINAL.zip').read_bytes()),'source_frozen_files_sha256':digest},'endpoint_source':{'archive':'input/BALANCE_FINAL.zip','archive_sha256':h((D/'input/BALANCE_FINAL.zip').read_bytes()),'source_frozen_files_sha256':digest}}
    write(D/'freeze/PROTOCOL.json',protocol);write(D/'input/PARENT_MEMBER_IDENTITIES.json',{'selected_members':ids});write(D/'input/ENDPOINT_MEMBER_IDENTITIES.json',{'selected_members':ends});write(D/'provenance/VALIDATION_LAUNCH_STARTED.json',{'frozen_files_sha256':digest})
    for directory,names in [('source',['author_solver.py','author_worker.py','inputs.py','common.py']),('independent_supervision/source',['reverse_frontier.py','read_catalog.py','independent_worker.py'])]:
        (D/directory).mkdir(parents=True,exist_ok=True)
        for name in names:shutil.copyfile(ROOT/directory/name,D/directory/name)
    (D/'source/gates.py').write_text("# Explicit invented-fixture-only gates; copied worker code points only to this isolated tree.\ndef active_main_gate():return 'INVENTED_ONLY'\ndef verification_ready():return 'INVENTED_ONLY'\n")
    for prefix in('raw','independent_supervision/raw'):
        for leaf in('calls','catalogs','active'):(D/prefix/leaf).mkdir(parents=True,exist_ok=True)
    executions=[]
    for label,script,prefix in [('main','source/author_worker.py','raw'),('independent','independent_supervision/source/independent_worker.py','independent_supervision/raw')]:
        out=D/prefix/'calls'/f'{field}_FRONTIER';r=run_command(['/usr/bin/python3','-B',D/script,field,'FRONTIER'],out,15,268435456,30,D/prefix/'active'/f'{label}.active.json');write(D/f'{label}_RUN.json',r);assert r['returncode']==0 and r['status']=='UNREVIEWED_PROCESS_SUCCESS'and r['registered_group_cleanup']['quiescent'];executions.append(r)
    mainout=json.loads((D/f'raw/calls/{field}_FRONTIER.stdout').read_text());indout=json.loads((D/f'independent_supervision/raw/calls/{field}_FRONTIER.stdout').read_text());local={r['mask']:r for r in rows}
    assert mainout['frontier']==indout['frontier']and mainout['catalog']['normalized_objective_catalog_sha256']==indout['catalog']['normalized_objective_catalog_sha256']
    for p,q in zip(mainout['queries'],indout['queries']):assert all(p[k]==q[k]for k in p)
    c0=time.process_time()
    for _ in range(12):
        for x in(mainout,indout):check_catalog(x,(D/x['catalog']['path']).read_bytes(),local)
    certificate_cpu=time.process_time()-c0
    corrupt=(D/mainout['catalog']['path']).read_bytes().replace(b',E\n',b',D\n',1);bad=copy.deepcopy(mainout);bad['catalog']['sha256']=h(corrupt);reject(lambda:check_catalog(bad,corrupt,local))
    # Complete non-convex three-point value front, independent exhaustive ternary assignment oracle.
    hand=make(6,3,0);weights={(1,):1,(2,3):9,(4,5,6):90,(2,):10,(4,5):20,(1,3,6):71,(1,2):34,(3,4):34,(5,6):34}
    for r in hand:r['G']=weights.get(tuple(r['customers']),1000)
    val,data=solve(hand,6,3);_,expected=brute(hand,6,3);assert expected==[(100,90),(101,71),(102,34)];assert [(x['sum_G_mm'],x['max_route_G_mm'])for x in val['frontier']]==expected;assert [q['front_index']for q in val['queries']]==[0,1,2,2,2,2];check_catalog(decorated(val,data),data,{r['mask']:r for r in hand},6,3)
    record={'status':'PASS','invented_worker_frontier_calls':2,'invented_additional_hand_frontier_calls':1,'formal_frontier_calls':0,'local_TSP_calls':0,'saved_catalog_checks':24,'saved_catalog_check_CPU_seconds':certificate_cpu,'scope':['actual worker CLI and isolated synthetic input reader','strict15CPU256MiB limits and process-group quiescence','main anchored vs independent reverse frontier and direct6budget agreement','all41811 canonical rows coverage and certificate antichain','false dominance certificate rejected','non-convex3-point frontier and integer0,1,2percent queries'],'resources':{'parent_cpu_seconds':time.process_time()-cpu,'wall_seconds':time.monotonic()-start,'peak_parent_rss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}}
    write(ROOT/'independent_supervision/selftests/PIPELINE_R2.json',record);print(json.dumps(record))
if __name__=='__main__':main()
