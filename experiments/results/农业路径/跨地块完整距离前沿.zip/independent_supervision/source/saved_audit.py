"""Verify saved catalogs, antichain and domination certificates; never enumerate/optimize new assignments."""
import pathlib,sys,json,hashlib,zipfile,resource,signal,time,collections
ROOT=pathlib.Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'source'))
from common import read,save,sha,utc,verify_map
from gates import frozen,receipt
from read_catalog import load_input,load_endpoints
CORE=('sum_G_mm','max_route_G_mm','partition','routes','route_G_mm')
FRONT_KEYS=('index',*CORE,'group_masks','assignment_multiplicity_unlabeled')
QUERY_KEYS=('p','budget_total_G_mm','front_index',*CORE,'group_masks')
HEADER=b'mask1,mask2,mask3,sum_G_mm,max_route_G_mm,front_index,relation\n'
NORMAL_HEADER=b'mask1,mask2,mask3,sum_G_mm,max_route_G_mm\n'
COVERAGE='116b468381296d0ed29066b7293164087fc03edc32b8105cd328b9f396e2c9d3'
def raw_check(base,name,r,h):
    m=read(base/name);assert m['frozen_files_sha256']==h;verify_map(ROOT,m['files'])
    with zipfile.ZipFile(r['download_path'])as z:
        for rel,v in m['files'].items():
            b=z.read(rel);assert b==(ROOT/rel).read_bytes()and len(b)==v['bytes']and hashlib.sha256(b).hexdigest()==v['sha256']
        assert z.read(str((base/name).relative_to(ROOT)))==(base/name).read_bytes()
    return len(m['files'])
def ledger(base,schedule):
    rows=read(base/'ALL_PLANNED_SLOTS.json');assert len(rows)==12 and [r['schedule']for r in rows]==schedule
    o=read(base/'OUTER_FINISHED.json');assert not o['duplicate_call_ids']and not o['malformed_rows']
    return rows,{'planned':12,'known_spawned':sum(r.get('process_spawned')is True for r in rows),'unknown_spawned_slots':sum(r.get('process_spawned')not in(True,False)for r in rows),'retained':12}
def check_catalog(a,raw,local,n=12,Q=5):
    assert raw.startswith(HEADER)and raw.endswith(b'\n')and b'\r'not in raw
    meta=a['catalog'];assert meta['schema']=='CANONICAL_PARTITION_FRONTIER_CERTIFICATE_V1'and meta['header']==HEADER.decode().rstrip('\n')and meta['bytes']==len(raw)and meta['sha256']==hashlib.sha256(raw).hexdigest()
    front=a['frontier'];assert front and a['frontier_size']==len(front)
    for j,f in enumerate(front):
        assert f['index']==j and len(f['partition'])==len(f['routes'])==len(f['route_G_mm'])==len(f['group_masks'])==3
        P=tuple(map(tuple,f['partition']));assert P==tuple(sorted(P))and all(list(g)==sorted(g)and max(1,n-2*Q)<=len(g)<=Q for g in P)and sorted(x for g in P for x in g)==list(range(1,n+1))
        masks=[sum(1<<(x-1)for x in g)for g in P];assert f['group_masks']==masks
        assert f['routes']==[local[m]['route']for m in masks]and f['route_G_mm']==[local[m]['G']for m in masks]
        assert f['sum_G_mm']==sum(f['route_G_mm'])and f['max_route_G_mm']==max(f['route_G_mm'])
        if j:assert front[j-1]['sum_G_mm']<f['sum_G_mm']and front[j-1]['max_route_G_mm']>f['max_route_G_mm']
    prev=None;parts=[];counts=collections.Counter();representatives={};relations=collections.Counter();normal=hashlib.sha256(NORMAL_HEADER);modes=collections.Counter()
    for line in raw.splitlines()[1:]:
        v=line.split(b',');assert len(v)==7;A,B,C,S,M,idx=map(int,v[:6]);masks=[A,B,C]
        assert all(m in local for m in masks)and not(A&B or A&C or B&C)and(A|B|C)==(1<<n)-1
        P=tuple(tuple(local[m]['customers'])for m in masks);assert P==tuple(sorted(P))and(prev is None or prev<P);prev=P;parts.append(P)
        values=[local[m]['G']for m in masks];assert S==sum(values)and M==max(values)
        pair=(S,M);counts[pair]+=1;representatives.setdefault(pair,P);modes[','.join(map(str,sorted(map(len,P))))]+=1
        assert 0<=idx<len(front);f=front[idx];assert f['sum_G_mm']<=S and f['max_route_G_mm']<=M
        expected=b'E'if(f['sum_G_mm'],f['max_route_G_mm'])==pair else b'D';assert v[6]==expected;relations[expected.decode()]+=1
        normal.update(b','.join(v[:5])+b'\n')
    assert len(parts)==meta['rows']==a['counters']['unique_canonical_partitions']
    if n==12:assert len(parts)==41811 and hashlib.sha256(json.dumps(parts,separators=(',',':')).encode()).hexdigest()==COVERAGE
    assert normal.hexdigest()==meta['normalized_objective_catalog_sha256']and len(counts)==a['unique_objective_pairs']
    assert all(meta['relation_counts'].get(k,0)==relations[k]for k in('E','D'))
    for f in front:
        pair=(f['sum_G_mm'],f['max_route_G_mm']);assert pair in counts and f['assignment_multiplicity_unlabeled']==counts[pair]and tuple(map(tuple,f['partition']))==representatives[pair]
    assert [q['p']for q in a['queries']]==[0,1,2,5,10,20]
    for q in a['queries']:
        assert q['budget_total_G_mm']==front[0]['sum_G_mm']*(100+q['p'])//100
        f=front[q['front_index']];assert all(q[k]==f[k]for k in CORE+('group_masks',))and 100*q['sum_G_mm']<=(100+q['p'])*front[0]['sum_G_mm']
        key=(q['max_route_G_mm'],q['sum_G_mm'],q['partition'])
        for candidate in front:
            if candidate['sum_G_mm']<=q['budget_total_G_mm']:assert(candidate['max_route_G_mm'],candidate['sum_G_mm'],candidate['partition'])>=key
    return {'rows':len(parts),'unique_pairs':len(counts),'frontier_size':len(front),'relation_counts':dict(relations),'normal_sha256':normal.hexdigest(),'size_counts':dict(modes)}
def output(a,slot,h,table,identity,endpoints,lane):
    assert a['instance_id']==slot['instance_id']and a['objective']==slot['objective']=='FRONTIER'and a['status']=='PROCESS_SUCCESS_UNREVIEWED'and a['frozen_files_sha256']==h
    assert a['n']==12 and a['Q']==5 and a['K']==3 and a['endpoints_match_frozen_prior']is True
    for key in('parent_archive_sha256','parent_audit_sha256','local_table_canonical_json_sha256'):assert a['input_identity'][key]==identity[key]
    prefix='raw'if lane=='main'else'independent_supervision/raw';expected=f'{prefix}/catalogs/{slot["call_id"]}.csv';assert a['catalog']['path']==expected
    cert=check_catalog(a,(ROOT/expected).read_bytes(),{r['mask']:r for r in table})
    for current,old in zip((a['frontier'][0],a['frontier'][-1]),endpoints):assert all(current[k]==old[k]for k in CORE)
    c=a['counters'];assert c['canonical_partition_coverage_sha256']==COVERAGE
    if lane=='main':assert c['local_subsets']==1573 and c['new_local_tsp_evaluations']==0 and c['unlabeled_partition_evaluations']==41811 and c['partition_size_counts']=={'2,5,5':8316,'3,4,5':27720,'4,4,4':5775}
    else:assert c['available_local_subsets']==1573 and c['additional_local_TSP_calls']==0 and c['labeled_feasible_partitions']==250866 and c['B_nonempty_submasks_checked']==406747 and c['canonical_partition_multiplicities']=={'6':41811}and c['repeated_partition_consistency_checks']==209055 and c['budget_labeled_assignment_checks']==1505196 and c['labeled_size_pattern_counts']=={'2,5,5':49896,'3,4,5':166320,'4,4,4':34650}
    assert a['resources']['cpu_limits']==[15,15]and a['resources']['as_limits']==[268435456,268435456]
    return cert

def audit():
    h=frozen();rm=receipt(ROOT/'provenance/RAW_MAIN_DRIVE_RECEIPT.json','RAW_MAIN',h);rv=receipt(ROOT/'provenance/RAW_VERIFICATION_DRIVE_RECEIPT.json','RAW_VERIFICATION',h)
    manifests=[raw_check(ROOT/'raw','RAW_MAIN_CONTENT_MANIFEST.json',rm,h),raw_check(ROOT/'independent_supervision/raw','RAW_VERIFICATION_CONTENT_MANIFEST.json',rv,h)]
    schedule=read(ROOT/'freeze/SCHEDULE.json');assert len(schedule)==12 and len({s['call_id']for s in schedule})==12
    main,mc=ledger(ROOT/'raw',schedule);ind,ic=ledger(ROOT/'independent_supervision/raw',schedule);fields=[]
    with zipfile.ZipFile(ROOT/'input/CAPACITY_FINAL.zip')as z,zipfile.ZipFile(ROOT/'input/BALANCE_FINAL.zip')as b:
        for slot,mrec,irec in zip(schedule,main,ind):
            cid,f=slot['call_id'],slot['instance_id'];row={'instance_id':f,'call_id':cid,'valid_for_exact_conclusion':False,'failure':None}
            try:
                for r in(mrec,irec):assert r.get('status')=='UNREVIEWED_PROCESS_SUCCESS'and not r.get('error')and r.get('process_spawned')is True and r.get('returncode')==0 and r.get('child_reaped')is True and(r.get('registered_group_cleanup')or{}).get('quiescent')is True
                table,identity=load_input(f);old,endident=load_endpoints(f);member=f'raw/calls/{f}_G_E.stdout';mainraw=z.read(member);assert json.loads(mainraw)['local_routes']==table
                aa=read(ROOT/f'raw/calls/{cid}.stdout');bb=read(ROOT/f'independent_supervision/raw/calls/{cid}.stdout')
                assert aa['input_identity']['parent_member']==member and aa['input_identity']['parent_member_sha256']==hashlib.sha256(mainraw).hexdigest()
                assert bb['input_identity']['parent_member']==identity['parent_member']and bb['input_identity']['parent_member_sha256']==identity['parent_member_sha256']
                assert bb['endpoint_identity']==endident
                for obj,oldrow in zip(('SUM_MAX','MAX_SUM'),old):
                    name=f'raw/calls/{f}_{obj}.stdout';data=b.read(name);assert all(json.loads(data)[k]==oldrow[k]for k in CORE);assert aa['endpoint_identity']['members'][name]['sha256']==hashlib.sha256(data).hexdigest()
                certA=output(aa,slot,h,table,identity,old,'main');certB=output(bb,slot,h,table,identity,old,'independent');assert certA['normal_sha256']==certB['normal_sha256']
                assert len(aa['frontier'])==len(bb['frontier'])
                for p,q in zip(aa['frontier'],bb['frontier']):assert all(p[k]==q[k]for k in FRONT_KEYS)
                for p,q in zip(aa['queries'],bb['queries']):assert all(p[k]==q[k]for k in QUERY_KEYS)
                row.update(valid_for_exact_conclusion=True,main_stdout_sha256=sha(ROOT/f'raw/calls/{cid}.stdout'),catalog_sha256=aa['catalog']['sha256'],normalized_objective_catalog_sha256=certA['normal_sha256'],frontier_size=aa['frontier_size'],unique_objective_pairs=aa['unique_objective_pairs'],frontier=aa['frontier'],queries=aa['queries'],certificate=certA)
            except (AssertionError,KeyError,ValueError,TypeError,OSError,IndexError)as e:row['failure']=type(e).__name__+':'+str(e)
            fields.append(row)
    eligible=[r['instance_id']for r in fields if r['valid_for_exact_conclusion']]
    return {'status':'PASS'if len(eligible)==12 else'AUDIT_COMPLETE_WITH_UNVERIFIED_SLOTS','frozen_files_sha256':h,'raw_main_archive_sha256':rm['sha256'],'raw_verification_archive_sha256':rv['sha256'],'eligible_instance_ids':eligible,'verified_fields':len(eligible),'planned_fields':12,'planned_main_calls':12,'planned_independent_calls':12,'planned_total_frontier_slots':24,'planned_derived_budget_rows':72,'main_counts':mc,'independent_counts':ic,'fields':fields,'raw_manifest_members_checked':manifests,'new_objective_or_local_TSP_calls_in_saved_audit':0}
def main():
    assert __debug__;resource.setrlimit(resource.RLIMIT_CPU,(15,15));resource.setrlimit(resource.RLIMIT_AS,(268435456,268435456));signal.alarm(30)
    c=time.process_time();w=time.monotonic();save(ROOT/'independent_supervision/SAVED_AUDIT_STARTED.json',{'utc':utc(),'new_frontier_calls':0,'new_local_TSP_calls':0});x=audit();x.update(utc=utc(),resources={'cpu_seconds':time.process_time()-c,'wall_seconds':time.monotonic()-w,'maxrss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss});save(ROOT/'independent_supervision/FINAL_AUDIT.json',x);print(json.dumps({'status':x['status'],'verified_fields':x['verified_fields']}))
if __name__=='__main__':main()
