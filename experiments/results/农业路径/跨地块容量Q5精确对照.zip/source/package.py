"""Local deterministic package only. Does not upload, generate receipts or authorize execution."""
import sys,pathlib,zipfile,json,hashlib
from common import ROOT,sha,read,save,inventory,utc,verify_map
from gates import receipt

def stage_gate(stage,digest):
 if stage=='PREEXEC':
  q=read(ROOT/'freeze/INDEPENDENT_PRECHECK.json')
  if q.get('status')!='PASS'or not q.get('reviewed_files'):raise RuntimeError('CURRENT_BOUND_PRECHECK_REQUIRED')
  verify_map(ROOT,q['reviewed_files'])
  for rel in ['raw','provenance/MAIN_LAUNCH_STARTED.json','provenance/VALIDATION_LAUNCH_STARTED.json','independent_supervision/raw','independent_supervision/results','independent_supervision/VALIDATION_LAUNCH_STARTED.json']:
   if(ROOT/rel).exists():raise RuntimeError('PREEXEC_REQUIRES_NO_FORMAL_START_OR_RAW:'+rel)
 elif stage=='RAW_MAIN':
  m=read(ROOT/'raw/RAW_MAIN_CONTENT_MANIFEST.json')
  if m['frozen_files_sha256']!=digest:raise RuntimeError('RAW_MAIN_FREEZE_MISMATCH')
  verify_map(ROOT,m['files'])
 elif stage=='RAW_VERIFICATION':
  receipt(ROOT/'provenance/RAW_MAIN_DRIVE_RECEIPT.json','RAW_MAIN',digest)
  m=read(ROOT/'independent_supervision/raw/RAW_VERIFICATION_CONTENT_MANIFEST.json')
  if m['frozen_files_sha256']!=digest:raise RuntimeError('RAW_VERIFICATION_FREEZE_MISMATCH')
  verify_map(ROOT,m['files'])
 elif stage=='FINAL':
  rm=receipt(ROOT/'provenance/RAW_MAIN_DRIVE_RECEIPT.json','RAW_MAIN',digest);rv=receipt(ROOT/'provenance/RAW_VERIFICATION_DRIVE_RECEIPT.json','RAW_VERIFICATION',digest)
  a=read(ROOT/'independent_supervision/FINAL_AUDIT.json');v=read(ROOT/'independent_supervision/FINAL_REPORT_REVIEW.json')
  if a.get('status')not in('PASS','AUDIT_COMPLETE_WITH_UNVERIFIED_SLOTS')or v.get('status')!='PASS':raise RuntimeError('FINAL_SAVED_AND_REPORT_REVIEW_REQUIRED')
  for q in(a,v):
   if q.get('frozen_files_sha256')!=digest or q.get('raw_main_archive_sha256')!=rm['sha256']or q.get('raw_verification_archive_sha256')!=rv['sha256']:raise RuntimeError('FINAL_REVIEW_INPUT_BINDING_MISMATCH')
  if v.get('report_sha256')!=sha(ROOT/'reports/REPORT_ZH.txt')or v.get('summary_sha256')!=sha(ROOT/'reports/SUMMARY.json')or v.get('independent_audit_sha256')!=sha(ROOT/'independent_supervision/FINAL_AUDIT.json'):raise RuntimeError('FINAL_REPORT_BYTE_BINDING_MISMATCH')

def main():
 stage=sys.argv[1];assert stage in('PREEXEC','RAW_MAIN','RAW_VERIFICATION','FINAL');digest=sha(ROOT/'freeze/FROZEN_FILES.json');verify_map(ROOT,read(ROOT/'freeze/FROZEN_FILES.json')['files']);stage_gate(stage,digest);out=ROOT.parent/(ROOT.name+'_'+stage+'.zip');assert not out.exists()
 # Include all frozen inputs/code plus prepared tests and relevant saved-stage outputs; never national SHP cache.
 chosen=[]
 for p in ROOT.rglob('*'):
  if not p.is_file()or '__pycache__'in p.parts:continue
  rel=p.relative_to(ROOT);top=rel.parts[0]
  if p.suffix in('.deflate','.shp'):continue
  if p.suffix=='.zip'and rel!=pathlib.Path('input/PARENT_FINAL.zip')and 'selftests'not in rel.parts:continue
  if stage=='PREEXEC'and top in('raw','reports'):continue
  if stage=='PREEXEC'and rel.parts[:2]in(('independent_supervision','raw'),('independent_supervision','results')):continue
  chosen.append(p)
 # Include the immutable parent ZIP and all recorded synthetic ZIP fixtures exactly once.
 assert len(chosen)==len(set(chosen))
 manifest=inventory(ROOT,chosen)
 if not set(read(ROOT/'freeze/FROZEN_FILES.json')['files']).issubset(manifest):raise RuntimeError('FROZEN_MEMBER_EXCLUDED_FROM_PACKAGE')
 with zipfile.ZipFile(out,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
  for p in sorted(chosen):z.write(p,str(p.relative_to(ROOT)))
  z.writestr('PACKAGE_CONTENT_MANIFEST.json',json.dumps(dict(stage=stage,frozen_files_sha256=digest,files=manifest),indent=2))
 with zipfile.ZipFile(out)as z:
  for rel,row in manifest.items():
   b=z.read(rel);assert len(b)==row['bytes']and hashlib.sha256(b).hexdigest()==row['sha256']
 save(ROOT/'provenance'/(stage+'_LOCAL_PACKAGE.json'),dict(stage=stage,utc=utc(),path=str(out),bytes=out.stat().st_size,sha256=sha(out),frozen_files_sha256=digest,member_count=len(manifest),local_byte_verification=True,remote_uploaded=False))
 print(str(out),sha(out))
if __name__=='__main__':main()
