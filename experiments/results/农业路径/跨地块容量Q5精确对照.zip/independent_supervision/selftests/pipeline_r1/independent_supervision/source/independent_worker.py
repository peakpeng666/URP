import pathlib, sys, resource, time, json
ROOT = pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'source'))
from gates import verification_ready
from common import read
from read_input import load_input
from subset_dp import solve

def main():
    assert __debug__
    started = time.monotonic(); digest = verification_ready()
    launch = read(ROOT/'provenance/VALIDATION_LAUNCH_STARTED.json')
    assert launch['frozen_files_sha256'] == digest and launch['planned_independent_calls'] == 24
    field, objective = sys.argv[1:]
    matrices, identity = load_input(field)
    result = solve(matrices['E'],matrices['G'],5,3,objective,394480)
    usage = resource.getrusage(resource.RUSAGE_SELF)
    result.update(status='PROCESS_SUCCESS_UNREVIEWED', instance_id=field, frozen_files_sha256=digest,
                  input_matrices=matrices,input_identity=identity,
                  resources={'cpu_seconds':usage.ru_utime+usage.ru_stime,'wall_seconds':time.monotonic()-started,
                    'peak_rss_kib':usage.ru_maxrss,'cpu_limits':list(resource.getrlimit(resource.RLIMIT_CPU)),
                    'as_limits':list(resource.getrlimit(resource.RLIMIT_AS))})
    print(json.dumps(result,allow_nan=False))
if __name__ == '__main__': main()
