"""Four invented objective calls; saved replay tests all fixed slots. No real data."""
import pathlib,sys,json,hashlib,zipfile,shutil,subprocess,importlib.util,os
ROOT=pathlib.Path(__file__).resolve().parents[2]
TEST=ROOT/'independent_supervision/selftests/pipeline_r1'
TEST.mkdir(exist_ok=False)
for folder in ('source','independent_supervision/source','freeze','input','provenance'):(TEST/folder).mkdir(parents=True,exist_ok=True)
for p in (ROOT/'source').glob('*.py'):shutil.copyfile(p,TEST/'source'/p.name)
for p in (ROOT/'independent_supervision/source').glob('*.py'):shutil.copyfile(p,TEST/'independent_supervision/source'/p.name)
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2))
def h(b):return hashlib.sha256(b).hexdigest()
def identity(p):return {'bytes':p.stat().st_size,'sha256':h(p.read_bytes())}
(TEST/'source/gates.py').write_text('from common import ROOT,read\ndef frozen():\n assert "selftests/pipeline_r1" in str(ROOT);return "SYNTHETIC"\ndef active_main_gate():return frozen()\ndef verification_ready():return frozen()\ndef receipt(path,stage,digest):return read(path)\n')
fields=['synthetic_'+str(i) for i in range(12)];ids={}
E=[[0 if i==j else 1 for j in range(21)] for i in range(21)];G=[[2*v for v in r] for r in E]
coords=[[i,0] for i in range(21)]
pre={'status':'PASS_PREPROCESS','n':20,'coordinates':coords,'integer_matrices':{'E':E,'G':G},
     'canonical_paths':[[[i] if i==j else [i,j] for j in range(21)] for i in range(21)],
     'pair_checks':[{'pair':[i,j],'decimal80_path_length_m':'0.002'} for i in range(21) for j in range(i+1,21)]}
with zipfile.ZipFile(TEST/'input/PARENT_FINAL.zip','w') as z:
    for field in fields:
        for name,value in [('preprocess.json',pre),('services.json',{'n':20,'coordinates':coords}),('graph.json',{'service_node_ids':list(range(21)),'base_count':0})]:
            b=json.dumps(value).encode();rel=f'raw/fields/{field}/{name}';z.writestr(rel,b);ids[rel]={'bytes':len(b),'sha256':h(b)}
    z.writestr('independent_supervision/FINAL_AUDIT.json',json.dumps({'status':'PASS','eligible_instance_ids':fields}))
save(TEST/'input/PARENT_MEMBER_IDENTITIES.json',{'selected_members':ids})
save(TEST/'freeze/PROTOCOL.json',{'fields':fields,'costs':{'source_archive':'input/PARENT_FINAL.zip','source_archive_sha256':h((TEST/'input/PARENT_FINAL.zip').read_bytes())}})
schedule=[{'call_id':f+'_'+o,'instance_id':f,'objective':o,'n':12} for f in fields for o in ('E_G','G_E')]
save(TEST/'freeze/SCHEDULE.json',schedule)
save(TEST/'provenance/VALIDATION_LAUNCH_STARTED.json',{'frozen_files_sha256':'SYNTHETIC','planned_independent_calls':24})
sys.path.insert(0,str(TEST/'source'))
from tree_runtime import run_command
runs=[];answers={}
for lane in ('main','independent'):
    for obj in ('E_G','G_E'):
        script=TEST/('source/author_worker.py' if lane=='main' else 'independent_supervision/source/independent_worker.py')
        dest=TEST/'worker_evidence'/(lane+'_'+obj)
        result=run_command(['/usr/bin/python3',script,fields[0],obj],dest,15,268435456,30,TEST/'worker_evidence'/(lane+'_'+obj+'.active.json'))
        assert result['status']=='UNREVIEWED_PROCESS_SUCCESS',result
        a=json.loads(dest.with_suffix('.stdout').read_text());assert a['resources']['cpu_limits']==[15,15] and a['resources']['as_limits']==[268435456,268435456]
        answers[(lane,obj)]=a;runs.append(result)
# Replay the four saved solver outputs across invented field slots. This is
# explicitly synthetic evidence construction, not 48 additional solver calls.
for lane,base in [('main',TEST/'raw'),('independent',TEST/'independent_supervision/raw')]:
    records=[]
    for slot in schedule:
        a=json.loads(json.dumps(answers[(lane,slot['objective'])]));a['instance_id']=slot['instance_id']
        a['input_identity']['members']={k.replace(fields[0],slot['instance_id']):v for k,v in a['input_identity']['members'].items()}
        save(base/'calls'/(slot['call_id']+'.stdout'),a)
        records.append({'schedule':slot,'process_spawned':True,'returncode':0,'child_reaped':True,'registered_group_cleanup':{'quiescent':True},'status':'UNREVIEWED_PROCESS_SUCCESS'})
    save(base/'ALL_PLANNED_SLOTS.json',records)
    save(base/'OUTER_FINISHED.json',{'duplicate_call_ids':False,'malformed_rows':[]})
    manifest='RAW_MAIN_CONTENT_MANIFEST.json' if lane=='main' else 'RAW_VERIFICATION_CONTENT_MANIFEST.json'
    save(base/manifest,{'frozen_files_sha256':'SYNTHETIC','files':{str(p.relative_to(TEST)):identity(p) for p in base.rglob('*') if p.is_file()}})
    archive=TEST/(lane+'_raw.zip')
    with zipfile.ZipFile(archive,'w') as z:
        for p in base.rglob('*'):
            if p.is_file():z.write(p,str(p.relative_to(TEST)))
    save(TEST/'provenance'/('RAW_MAIN_DRIVE_RECEIPT.json' if lane=='main' else 'RAW_VERIFICATION_DRIVE_RECEIPT.json'),{'sha256':h(archive.read_bytes()),'download_path':str(archive),'synthetic_only':True})
sys.path.insert(0,str(TEST/'independent_supervision/source'))
from saved_audit import audit,check_payload
out=audit();assert out['status']=='PASS' and out['verified_fields']==12 and out['complete_panel_mean_delta_integer_mm']==0,out
# Necessary saved-output contracts only: missing outcome, wrong route or cost.
a=answers[('independent','E_G')];from read_input import load_input
matrices,ident=load_input(fields[0]);slot=schedule[0]
negative=[]
for label in ('duplicate_customer','cost','wrong_input_hash'):
    bad=json.loads(json.dumps(a))
    if label=='duplicate_customer':bad['routes'][0][1]=bad['routes'][0][2]
    elif label=='cost':bad['G']+=1
    else:bad['input_identity']['selected_matrix_canonical_json_sha256']='wrong'
    try:check_payload(bad,matrices,ident,slot,'SYNTHETIC')
    except AssertionError:negative.append(label)
    else:raise AssertionError('NEGATIVE_ACCEPTED:'+label)
records=json.loads((TEST/'independent_supervision/raw/ALL_PLANNED_SLOTS.json').read_text());records[0]['process_spawned']=False
save(TEST/'independent_supervision/raw/ALL_PLANNED_SLOTS.json',records)
# Missing/invalid lanes are tested by exact payload validator above; a tampered
# RAW is required to fail integrity before any scientific status is assessed.
try:audit()
except AssertionError:negative.append('changed_raw_rejected')
else:raise AssertionError('RAW_TAMPER_ACCEPTED')
save(TEST/'REPORT.json',{'status':'PASS','invented_only':True,'new_synthetic_objective_calls':4,'real_objective_calls':0,
 'actual_worker_chain_runs':runs,'saved_replay_fields':12,'saved_replay_target_slots':48,'negative_tests':negative,
 'gate_note':'Explicit synthetic-only gate stub in isolated fixture; not an approval or production receipt'})
print(json.dumps({'status':'PASS','new_synthetic_objective_calls':4,'saved_replay_fields':12}))
