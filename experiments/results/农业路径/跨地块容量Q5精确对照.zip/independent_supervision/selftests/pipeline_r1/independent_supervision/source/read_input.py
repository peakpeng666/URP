"""Independent byte-bound extraction; no author input/optimizer import."""
import hashlib, json, pathlib, zipfile
ROOT = pathlib.Path(__file__).resolve().parents[2]
def digest(b): return hashlib.sha256(b).hexdigest()
def load_input(field):
    protocol = json.loads((ROOT/'freeze/PROTOCOL.json').read_text())
    assert field in protocol['fields']
    raw_zip = (ROOT/'input/PARENT_FINAL.zip').read_bytes()
    archive_hash = digest(raw_zip)
    assert archive_hash == protocol['costs']['source_archive_sha256']
    identities = json.loads((ROOT/'input/PARENT_MEMBER_IDENTITIES.json').read_text())['selected_members']
    decoded, hashes = {}, {}
    with zipfile.ZipFile(ROOT/'input/PARENT_FINAL.zip') as z:
        for name in ('preprocess.json','services.json','graph.json'):
            rel = f'raw/fields/{field}/{name}'
            b = z.read(rel); h = digest(b)
            assert identities[rel] == {'bytes':len(b),'sha256':h}
            decoded[name] = json.loads(b); hashes[rel] = h
    pre, services, graph = [decoded[x] for x in ('preprocess.json','services.json','graph.json')]
    assert pre['status'] == 'PASS_PREPROCESS' and pre['n'] == services['n'] == 20
    assert pre['coordinates'] == services['coordinates'] and len(pre['coordinates']) == 21
    original = pre['integer_matrices']
    for name in ('E','G'):
        a = original[name]
        assert len(a) == 21 and all(len(row) == 21 for row in a)
        assert all(type(a[i][j]) is int and 0 <= a[i][j] <= 394480 and a[i][j] == a[j][i]
                   and (i != j or a[i][j] == 0) for i in range(21) for j in range(21))
    for i in range(13):
        for j in range(13):
            path = pre['canonical_paths'][i][j]
            assert path[0] == graph['service_node_ids'][i] and path[-1] == graph['service_node_ids'][j]
            assert all(node < graph['base_count'] for node in path[1:-1])
    selected = {name:[[original[name][i][j] for j in range(13)] for i in range(13)] for name in ('E','G')}
    identity = {'parent_archive_sha256':archive_hash, 'members':hashes, 'selected_original_ids':list(range(13)),
                'selected_matrix_canonical_json_sha256':digest(json.dumps(selected,sort_keys=True,separators=(',',':')).encode())}
    return selected, identity
