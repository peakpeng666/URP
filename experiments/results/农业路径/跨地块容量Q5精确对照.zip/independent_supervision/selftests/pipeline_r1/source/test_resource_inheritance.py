"""Synthetic smoke test of actual three-level soft/hard resource inheritance."""
from pathlib import Path
import sys, json, subprocess
from common import ROOT, save, read


def main():
    dest = ROOT / 'selftests/resource_inheritance'
    dest.mkdir(exist_ok=False)
    worker = dest / 'worker.py'
    worker.write_text('import resource,json\nprint(json.dumps({"cpu":list(resource.getrlimit(resource.RLIMIT_CPU)),"as":list(resource.getrlimit(resource.RLIMIT_AS))}))\n')
    prefix = 'import sys,resource,json,pathlib\nsys.path.insert(0,' + repr(str(ROOT / 'source')) + ')\nfrom tree_runtime import run_command\n'
    supervisor = dest / 'supervisor.py'
    supervisor.write_text(prefix + 'limits={"cpu":list(resource.getrlimit(resource.RLIMIT_CPU)),"as":list(resource.getrlimit(resource.RLIMIT_AS))}\nr=run_command(["/usr/bin/python3",' + repr(str(worker)) + '],pathlib.Path(' + repr(str(dest / 'worker')) + '),15,268435456,5,pathlib.Path(' + repr(str(dest / 'worker.active.json')) + '))\nprint(json.dumps({"supervisor_limits":limits,"worker":r}))\n')
    outer = dest / 'outer.py'
    outer.write_text(prefix + 'from launch_main_once import author_outer_limits\nlimits=author_outer_limits()\nr=run_command(["/usr/bin/python3",' + repr(str(supervisor)) + '],pathlib.Path(' + repr(str(dest / 'supervisor')) + '),15,134217728,10,pathlib.Path(' + repr(str(dest / 'supervisor.active.json')) + '),cpu_hard=60,as_hard=268435456)\nprint(json.dumps({"outer_limits":limits,"supervisor":r}))\n')
    proc = subprocess.run(['/usr/bin/python3', str(outer)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=20)
    (dest / 'outer.stdout').write_text(proc.stdout); (dest / 'outer.stderr').write_text(proc.stderr)
    assert proc.returncode == 0
    a, b, c = json.loads(proc.stdout), read(dest / 'supervisor.stdout'), read(dest / 'worker.stdout')
    assert a['outer_limits'] == {'cpu': [20, 60], 'as': [134217728, 268435456]}
    assert b['supervisor_limits'] == {'cpu': [15, 60], 'as': [134217728, 268435456]}
    assert c == {'cpu': [15, 15], 'as': [268435456, 268435456]}
    assert a['supervisor']['status'] == b['worker']['status'] == 'UNREVIEWED_PROCESS_SUCCESS'
    assert a['supervisor']['registered_group_cleanup']['quiescent'] and b['worker']['registered_group_cleanup']['quiescent']
    save(dest / 'REPORT.json', {'status': 'PASS', 'synthetic_only': True, 'real_objective_calls': 0, 'outer': a, 'supervisor': b, 'worker_limits': c})
    print('PASS: actual ancestor hard ceilings permit formal worker15CPU/256MiB under smaller supervisor soft memory.')


if __name__ == '__main__':
    main()
