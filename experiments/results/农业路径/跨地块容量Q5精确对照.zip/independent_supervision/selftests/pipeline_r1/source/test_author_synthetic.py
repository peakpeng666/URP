"""Literal/generated synthetic matrices only. Never reads parent or formal inputs."""
import itertools, json, random, resource, time
from author_solver import solve, objective_key


def brute(E, G, Q, K, objective):
    n = len(E) - 1
    best = None
    for sizes in itertools.product(range(1, Q + 1), repeat=K):
        if sum(sizes) != n:
            continue
        for perm in itertools.permutations(range(1, n + 1)):
            offset, groups = 0, []
            for size in sizes:
                order = perm[offset:offset + size]
                offset += size
                order = min(order, order[::-1])
                groups.append((tuple(sorted(order)), order))
            groups.sort()
            routes = [(0,) + order + (0,) for _, order in groups]
            ev = sum(E[a][b] for route in routes for a, b in zip(route, route[1:]))
            gv = sum(G[a][b] for route in routes for a, b in zip(route, route[1:]))
            key = objective_key(ev, gv, objective) + (tuple(group for group, _ in groups), tuple(order for _, order in groups))
            if best is None or key < best:
                best = key
    return best


def matrix(n, seed):
    rng = random.Random(seed)
    x = [[0] * (n + 1) for _ in range(n + 1)]
    for i in range(n + 1):
        for j in range(i + 1, n + 1):
            x[i][j] = x[j][i] = rng.randrange(1, 30)
    return x


def main():
    started, cpu = time.monotonic(), time.process_time()
    records = []
    cases = [('random6', matrix(6, 1), matrix(6, 2), 4, 2),
             ('equal6', matrix(6, 3), matrix(6, 3), 3, 2),
             ('all_ties6', [[int(i != j) for j in range(7)] for i in range(7)], [[int(i != j) for j in range(7)] for i in range(7)], 4, 2)]
    for name, E, G, Q, K in cases:
        results = {}
        for objective in ('E_G', 'G_E'):
            row = solve(E, G, Q, K, objective)
            observed = objective_key(row['E'], row['G'], objective) + (tuple(map(tuple, row['partition'])), tuple(tuple(r[1:-1]) for r in row['routes']))
            assert observed == brute(E, G, Q, K, objective)
            results[objective] = row
        eg, ge = results['E_G'], results['G_E']
        lookup = {r['mask']: r for r in ge['local_routes']}
        fixed_g = sum(lookup[sum(1 << (x - 1) for x in group)]['G'] for group in eg['partition'])
        order_loss, partition_loss = eg['G'] - fixed_g, fixed_g - ge['G']
        assert order_loss >= 0 and partition_loss >= 0 and order_loss + partition_loss == eg['G'] - ge['G']
        records.append({'fixture': name, 'brute_exact_key_match': True, 'order_loss': order_loss, 'partition_loss': partition_loss})
    uniform = [[int(i != j) for j in range(13)] for i in range(13)]
    row = solve(uniform, uniform, 5, 3, 'E_G')
    assert row['E'] == row['G'] == 15
    assert row['partition'] == [[1, 2], [3, 4, 5, 6, 7], [8, 9, 10, 11, 12]]
    assert row['counters'] == {'local_subsets': 1573, 'local_route_evaluations': 54186, 'unlabeled_partition_evaluations': 41811, 'partition_size_counts': {'2,5,5': 8316, '3,4,5': 27720, '4,4,4': 5775}}
    bad = matrix(3, 1); bad[0][1] = -1
    try:
        solve(bad, bad, 2, 2, 'E_G')
        raise AssertionError('Invalid matrix accepted')
    except ValueError:
        pass
    print(json.dumps({'status': 'PASS', 'synthetic_only': True, 'real_source_matrix_reads': 0, 'real_objective_calls': 0,
                      'fixtures': records, 'full_size_uniform_counts': row['counters'], 'canonical_full_size_partition': row['partition'],
                      'wall_seconds': time.monotonic() - started, 'cpu_seconds': time.process_time() - cpu,
                      'limits': {'cpu': list(resource.getrlimit(resource.RLIMIT_CPU)), 'as': list(resource.getrlimit(resource.RLIMIT_AS))}}))


if __name__ == '__main__':
    main()
