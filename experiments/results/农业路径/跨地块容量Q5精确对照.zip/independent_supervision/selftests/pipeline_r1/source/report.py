"""Saved-evidence report only. No optimization, geometry, or source-cost recomputation."""
import json, zipfile
from decimal import Decimal, localcontext
from common import ROOT, read, save, sha, utc
from gates import frozen, receipt


def diagnostic(eg, ge, pair_lengths=None):
    if eg['objective'] != 'E_G' or ge['objective'] != 'G_E':
        raise ValueError('REPORT_OBJECTIVE_IDENTITY')
    delta = eg['G'] - ge['G']
    local = {row['mask']: row for row in ge['local_routes']}
    masks = [sum(1 << (x - 1) for x in group) for group in eg['partition']]
    fixed = sum(local[mask]['G'] for mask in masks)
    order_loss, partition_loss = eg['G'] - fixed, fixed - ge['G']
    if delta < 0 or order_loss < 0 or partition_loss < 0 or delta != order_loss + partition_loss:
        raise ValueError('DECOMPOSITION_IDENTITY_FAILURE')
    result = {'delta_integer_mm': delta, 'fixed_selected_partition_G_integer_mm': fixed,
              'order_loss_integer_mm': order_loss, 'partition_loss_integer_mm': partition_loss,
              'relative_integer_percent': 100 * delta / ge['G'] if ge['G'] else None,
              'same_selected_partition': eg['partition'] == ge['partition'],
              'E_G': {k: eg[k] for k in ('E', 'G', 'partition', 'routes')},
              'G_E': {k: ge[k] for k in ('E', 'G', 'partition', 'routes')}}
    if pair_lengths is not None:
        with localcontext() as context:
            context.prec = 80
            lengths = [sum((Decimal(pair_lengths[tuple(sorted((a, b)))]) for route in row['routes'] for a, b in zip(route, route[1:])), Decimal(0)) for row in (eg, ge)]
            result['representative_realized_G_lengths_m_decimal80'] = [str(value) for value in lengths]
            result['representative_realized_difference_m_decimal80'] = str(lengths[0] - lengths[1])
    return result


def aggregate(rows, planned_fields):
    eligible = [row for row in rows if row.get('eligible_for_primary') is True]
    values = [row['delta_integer_mm'] for row in eligible]
    complete = len(rows) == len(planned_fields) == len(eligible) and {row['instance_id'] for row in rows} == set(planned_fields)
    sorted_values = sorted(values)
    median = None if not values else sorted_values[len(values)//2] if len(values) % 2 else (sorted_values[len(values)//2-1] + sorted_values[len(values)//2]) / 2
    return {'status': 'COMPLETE_12_FIELD_RESULT' if complete else 'INCOMPLETE_PANEL_WITH_EXPLICIT_FAILURE_DENOMINATORS',
            'planned_fields': len(planned_fields), 'verified_fields': len(eligible), 'planned_main_calls': 24,
            'planned_independent_calls': 24, 'planned_total_objective_slots': 48,
            'complete_panel_mean_delta_integer_mm': sum(values)/len(values) if complete else None,
            'complete_case_mean_delta_integer_mm': sum(values)/len(values) if values else None,
            'complete_case_median_delta_integer_mm': median,
            'complete_case_positive_delta_fields': sum(value > 0 for value in values),
            'complete_case_zero_delta_fields': sum(value == 0 for value in values), 'fields': rows}


def main():
    digest = frozen()
    rm = receipt(ROOT / 'provenance/RAW_MAIN_DRIVE_RECEIPT.json', 'RAW_MAIN', digest)
    rv = receipt(ROOT / 'provenance/RAW_VERIFICATION_DRIVE_RECEIPT.json', 'RAW_VERIFICATION', digest)
    audit = read(ROOT / 'independent_supervision/FINAL_AUDIT.json')
    if audit.get('status') not in ('PASS', 'AUDIT_COMPLETE_WITH_UNVERIFIED_SLOTS') or audit.get('frozen_files_sha256') != digest or audit.get('raw_main_archive_sha256') != rm['sha256'] or audit.get('raw_verification_archive_sha256') != rv['sha256']:
        raise ValueError('INDEPENDENT_SAVED_AUDIT_BINDING_REQUIRED')
    protocol = read(ROOT / 'freeze/PROTOCOL.json')
    eligible = set(audit['eligible_instance_ids'])
    rows = []
    with zipfile.ZipFile(ROOT / 'input/PARENT_FINAL.zip') as parent:
        for field in protocol['fields']:
            row = {'instance_id': field, 'eligible_for_primary': False, 'status': 'UNVERIFIED_INDEPENDENT_AUDIT'}
            if field in eligible:
                try:
                    eg = read(ROOT / 'raw/calls' / (field + '_E_G.stdout'))
                    ge = read(ROOT / 'raw/calls' / (field + '_G_E.stdout'))
                    source = json.loads(parent.read('raw/fields/' + field + '/preprocess.json'))
                    lengths = {tuple(x['pair']): x['decimal80_path_length_m'] for x in source['pair_checks']}
                    value = diagnostic(eg, ge, lengths)
                    independent = next(item for item in audit['fields'] if item['instance_id'] == field)
                    if independent.get('valid_for_exact_conclusion') is not True:
                        raise ValueError('INDEPENDENT_FIELD_NOT_VALID')
                    for key in ('delta_integer_mm', 'order_loss_integer_mm', 'partition_loss_integer_mm'):
                        if value[key] != independent[key]:
                            raise ValueError('INDEPENDENT_REPORT_VALUE_MISMATCH:' + key)
                    if value['fixed_selected_partition_G_integer_mm'] != independent['fixed_partition_G'] or value['representative_realized_difference_m_decimal80'] != independent['actual_path_length_difference_m']:
                        raise ValueError('INDEPENDENT_REPORT_DERIVED_VALUE_MISMATCH')
                    row.update(value, eligible_for_primary=True, status='VERIFIED_INTEGER_PROXY_DIAGNOSTIC')
                except Exception as exc:
                    row.update(status='REPORT_EVIDENCE_FAILURE', error=repr(exc))
            rows.append(row)
    summary = aggregate(rows, protocol['fields'])
    summary.update(frozen_files_sha256=digest, raw_main_archive_sha256=rm['sha256'], raw_verification_archive_sha256=rv['sha256'],
                   independent_audit_sha256=sha(ROOT / 'independent_supervision/FINAL_AUDIT.json'), utc=utc(),
                   scope='Previously observed twelve NL boundaries, synthetic first12 tasks and unit capacity; Q5 forces3 routes. No unseen generalization or single-factor comparison with old20-task single vehicle.')
    for name, path in [('main', ROOT / 'raw/ALL_PLANNED_SLOTS.json'), ('independent', ROOT / 'independent_supervision/raw/ALL_PLANNED_SLOTS.json')]:
        slots = read(path)
        summary[name + '_known_started_processes'] = sum(row.get('process_spawned') is True for row in slots)
        summary[name + '_unknown_start_slots'] = sum(row.get('process_spawned') == 'UNKNOWN' for row in slots)
    save(ROOT / 'reports/SUMMARY.json', summary)
    lines = ['容量约束多车辆距离代理精确诊断',
             '固定12个已观察NL边界；每田原depot及前12个合成任务；单位需求Q5、最多3车强制恰3条路线。',
             '通过完整核验：%s/12。主24+独24计划目标槽保留；候选回路/分区/DP转移不是目标调用次数。' % summary['verified_fields'],
             '完整12田均值Delta(mm)：%s。完整案例描述均值：%s；分母%s。' % (summary['complete_panel_mean_delta_integer_mm'], summary['complete_case_mean_delta_integer_mm'], summary['verified_fields']),
             'Delta是E最优集合内最小G成本减全局G最优成本。两非负分量仅描述规范选定E最优代表：固定该分组后的组内排序损失，以及该分组相对全局G最优的损失。']
    for row in rows:
        lines.append('%s: Delta=%s mm，排序=%s mm，分组=%s mm，状态=%s' % (row['instance_id'], row.get('delta_integer_mm'), row.get('order_loss_integer_mm'), row.get('partition_loss_integer_mm'), row['status']))
    lines.extend(['所有实现均复用原G合法有限图路径；未选8服务点仍terminal-only，不重新构图或取整。没有车际碰撞/时间调度模型。',
                  '15腿两代表方案差的取整界0.015米；计入旧每腿1e-8米保存路径核验容差后为0.01500030米。不是连续几何最优或测绘误差界。',
                  '真实边界、合成任务与容量；旧结果已观察。这是探索性机制实验，不称未见泛化、实车验证或自动算法优越性。',
                  '不能将旧20任务单车与新12任务三车总长度或Delta变化归因于车辆数；不作总体或有孔结构因果推断。'])
    path = ROOT / 'reports/REPORT_ZH.txt'
    with path.open('x') as handle:
        handle.write('\n'.join(lines) + '\n')
    print('Saved-evidence-only report generated; independent report review and FINAL archive still required.')


if __name__ == '__main__':
    main()
