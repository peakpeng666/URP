"""Declared reporting identities and missing-field denominator only; no optimizer."""
import json
from report import diagnostic, aggregate


def main():
    common = {'E': 10, 'G': 20, 'partition': [[1, 2], [3, 4]], 'routes': [[0, 1, 2, 0], [0, 3, 4, 0]]}
    eg = dict(common, objective='E_G')
    ge = dict(common, objective='G_E', E=15, G=10, local_routes=[{'mask': 3, 'G': 5}, {'mask': 12, 'G': 9}])
    value = diagnostic(eg, ge)
    assert value['delta_integer_mm'] == 10 and value['order_loss_integer_mm'] == 6 and value['partition_loss_integer_mm'] == 4
    ids = ['SYNTH_%02d' % i for i in range(12)]
    rows = [dict(instance_id=f, eligible_for_primary=True, **value) for f in ids]
    complete = aggregate(rows, ids)
    assert complete['complete_panel_mean_delta_integer_mm'] == 10 and complete['verified_fields'] == 12
    rows[2] = {'instance_id': ids[2], 'eligible_for_primary': False, 'status': 'SYNTHETIC_UNVERIFIED'}
    incomplete = aggregate(rows, ids)
    assert incomplete['complete_panel_mean_delta_integer_mm'] is None and incomplete['complete_case_mean_delta_integer_mm'] == 10 and incomplete['verified_fields'] == 11
    print(json.dumps({'status': 'PASS', 'synthetic_only': True, 'real_objective_calls': 0, 'optimizer_calls': 0,
                      'decomposition_identity': True, 'full_panel_null_on_missing_field': True, 'explicit_complete_case_denominator': 11}))


if __name__ == '__main__':
    main()
