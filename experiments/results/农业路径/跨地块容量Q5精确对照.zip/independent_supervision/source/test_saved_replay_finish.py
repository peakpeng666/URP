"""Zero-solver completion after expected raw rejection used RuntimeError, not AssertionError."""
import pathlib,sys,shutil,json,zipfile,hashlib
ROOT=pathlib.Path(__file__).resolve().parents[2];OLD=ROOT/'independent_supervision/selftests/pipeline_r1';NEW=ROOT/'independent_supervision/selftests/saved_replay_r2'
shutil.copytree(OLD,NEW)
gate=NEW/'source/gates.py';gate.write_text(gate.read_text().replace('selftests/pipeline_r1','selftests/saved_replay_r2'))
# Restore original synthetic raw bytes from the already-saved synthetic ZIP.
for lane in ('main','independent'):
    with zipfile.ZipFile(NEW/(lane+'_raw.zip')) as z:
        for rel in z.namelist():
            p=NEW/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(rel))
    receipt=NEW/'provenance'/('RAW_MAIN_DRIVE_RECEIPT.json' if lane=='main' else 'RAW_VERIFICATION_DRIVE_RECEIPT.json')
    r=json.loads(receipt.read_text());r['download_path']=str(NEW/(lane+'_raw.zip'));receipt.write_text(json.dumps(r))
sys.path.insert(0,str(NEW/'source'));sys.path.insert(0,str(NEW/'independent_supervision/source'))
from saved_audit import audit,check_payload
from read_input import load_input
out=audit();assert out['status']=='PASS' and out['verified_fields']==12
schedule=json.loads((NEW/'freeze/SCHEDULE.json').read_text());slot=schedule[0]
a=json.loads((NEW/'independent_supervision/raw/calls'/(slot['call_id']+'.stdout')).read_text());matrices,ident=load_input(slot['instance_id'])
passed=[]
for label in ('duplicate_customer','cost','wrong_input_hash'):
    bad=json.loads(json.dumps(a))
    if label=='duplicate_customer':bad['routes'][0][1]=bad['routes'][0][2]
    elif label=='cost':bad['G']+=1
    else:bad['input_identity']['selected_matrix_canonical_json_sha256']='wrong'
    try:check_payload(bad,matrices,ident,slot,'SYNTHETIC')
    except AssertionError:passed.append(label)
    else:raise AssertionError(label)
base=NEW/'independent_supervision/raw';p=base/'ALL_PLANNED_SLOTS.json';records=json.loads(p.read_text());records[0]['process_spawned']=False;p.write_text(json.dumps(records))
try:audit()
except (AssertionError,RuntimeError):passed.append('changed_raw_rejected')
else:raise AssertionError('RAW_TAMPER_ACCEPTED')
# Repackage changed invented evidence as a different synthetic failed-slot batch.
manifest=base/'RAW_VERIFICATION_CONTENT_MANIFEST.json';m=json.loads(manifest.read_text());rel=str(p.relative_to(NEW));b=p.read_bytes();m['files'][rel]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()};manifest.write_text(json.dumps(m))
archive=NEW/'independent_missing_raw.zip'
with zipfile.ZipFile(archive,'w') as z:
    for q in base.rglob('*'):
        if q.is_file():z.write(q,str(q.relative_to(NEW)))
receipt=NEW/'provenance/RAW_VERIFICATION_DRIVE_RECEIPT.json';r=json.loads(receipt.read_text());r['download_path']=str(archive);r['sha256']=hashlib.sha256(archive.read_bytes()).hexdigest();receipt.write_text(json.dumps(r))
out=audit();assert out['verified_fields']==11 and out['complete_panel_mean_delta_integer_mm'] is None and len(out['rows'])==24
passed.append('one_failed_slot_full_panel_null_24_slots_retained')
report={'status':'PASS','new_synthetic_objective_calls':0,'real_objective_calls':0,'saved_replay_fields':12,'checks':passed,
 'prior_attempt':'pipeline_r1 retained its 4 actual synthetic objective outputs and harness traceback; expected raw integrity rejection was RuntimeError, missing from the negative-test except clause. No production code change or solver rerun.'}
(NEW/'REPORT.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
