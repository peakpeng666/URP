"""Zero-solver replay against final saved auditor and 24-slot driver."""
import pathlib,sys,importlib.util,json,ast,hashlib
ROOT=pathlib.Path(__file__).resolve().parents[2]
FIX=ROOT/'independent_supervision/selftests/saved_replay_r2'
sys.path.insert(0,str(FIX/'source'));import common,gates
sys.path.insert(0,str(ROOT/'independent_supervision/source'))
import saved_audit,read_input
saved_audit.ROOT=FIX;read_input.ROOT=FIX
out=saved_audit.audit();assert out['verified_fields']==11 and out['complete_panel_mean_delta_integer_mm'] is None and len(out['rows'])==24
for p in list((ROOT/'source').glob('*.py'))+list((ROOT/'independent_supervision/source').glob('*.py')):ast.parse(p.read_text())
# Replay independent production batch loop using bounded-result emitters, no
# child optimization. Real worker limits were checked in pipeline_r1.
import run_validation_batch as batch
DEST=ROOT/'independent_supervision/selftests/driver_replay';DEST.mkdir(exist_ok=False)
(DEST/'freeze').mkdir();(DEST/'provenance').mkdir();(DEST/'independent_supervision').mkdir()
schedule=json.loads((FIX/'freeze/SCHEDULE.json').read_text())
(DEST/'freeze/SCHEDULE.json').write_text(json.dumps(schedule))
(DEST/'provenance/VALIDATION_LAUNCH_STARTED.json').write_text(json.dumps({'frozen_files_sha256':'SYNTHETIC'}))
batch.ROOT=DEST;batch.verification_ready=lambda:'SYNTHETIC';counter=[0]
def emitter(command,dest,cpu,as_bytes,wall,registration):
    counter[0]+=1
    assert cpu==15 and as_bytes==268435456 and 0<wall<=30
    return {'status':'PROCESS_FAILURE' if counter[0]==1 else 'UNREVIEWED_PROCESS_SUCCESS','process_spawned':True,'child_reaped':True,'returncode':7 if counter[0]==1 else 0,'error':None,'registered_group_cleanup':{'quiescent':True}}
batch.run_command=emitter;batch.main()
rows=[json.loads(l) for l in (DEST/'independent_supervision/raw/results.jsonl').read_text().splitlines()]
assert len(rows)==24 and [r['schedule'] for r in rows]==schedule and rows[0]['returncode']==7
files={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'independent_supervision/source').glob('*.py')}
report={'status':'PASS','new_optimization_calls':0,'checks':['final_saved_audit_missing_slot_retains24_fullmean_null','production_independent_batch24_schema_with_failure','all_current_python_AST'], 'reviewed_source_hashes':files}
(ROOT/'independent_supervision/selftests/FINAL_CONTRACT.json').write_text(json.dumps(report,indent=2));print(json.dumps({'status':'PASS','new_optimization_calls':0}))
