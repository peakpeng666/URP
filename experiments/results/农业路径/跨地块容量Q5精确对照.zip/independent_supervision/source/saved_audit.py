"""Audit saved declared solves, with zero optimization or solver imports."""
import pathlib,sys,json,hashlib,itertools,zipfile,decimal,time,resource,signal
ROOT=pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'source'))
from common import read,save,sha,utc,verify_map
from gates import frozen,receipt
from read_input import load_input
D=decimal.Decimal

def check_payload(row,matrices,identity,slot,digest):
    assert isinstance(row,dict) and row['status']=='PROCESS_SUCCESS_UNREVIEWED'
    assert row['instance_id']==slot['instance_id'] and row['objective']==slot['objective']
    assert row['frozen_files_sha256']==digest and row['n']==12 and row['Q']==5 and row['K']==3
    assert row['input_matrices']==matrices
    assert all(row['input_identity'][k]==v for k,v in identity.items())
    def check_route(route,customers):
        assert route[0]==route[-1]==0 and len(route)==len(customers)+2
        assert all(type(x) is int for x in route) and sorted(route[1:-1])==customers
        assert tuple(route[1:-1])<=tuple(reversed(route[1:-1]))
        return tuple(sum(matrices[k][a][b] for a,b in zip(route,route[1:])) for k in ('E','G'))
    expected={sum(1<<(x-1) for x in group) for size in range(2,6) for group in itertools.combinations(range(1,13),size)}
    local={}
    assert len(row['local_routes'])==1573
    for r in row['local_routes']:
        mask=r['mask'];assert type(mask) is int and mask in expected and mask not in local
        customers=[i for i in range(1,13) if mask>>(i-1)&1]
        assert r['customers']==customers and 2<=len(customers)<=5
        assert all(type(r[k]) is int for k in ('E','G'))
        assert check_route(r['route'],customers)==(r['E'],r['G'])
        local[mask]=r
    assert set(local)==expected
    partition=row['partition'];assert len(partition)==len(row['routes'])==3
    assert partition==sorted(partition) and all(g==sorted(g) and 2<=len(g)<=5 for g in partition)
    assert sorted(x for group in partition for x in group)==list(range(1,13))
    totals=[0,0]
    for group,route in zip(partition,row['routes']):
        mask=sum(1<<(x-1) for x in group)
        assert local[mask]['route']==route
        ev,gv=check_route(route,group);totals[0]+=ev;totals[1]+=gv
    assert totals==[row['E'],row['G']] and all(type(row[k]) is int for k in ('E','G'))
    return local

def raw_check(base,manifest_name,archived,digest):
    manifest=read(base/manifest_name);assert manifest['frozen_files_sha256']==digest
    verify_map(ROOT,manifest['files'])
    with zipfile.ZipFile(archived['download_path']) as z:
        for rel,r in manifest['files'].items():
            b=z.read(rel);assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256']
        rel=str((base/manifest_name).relative_to(ROOT));assert z.read(rel)==(base/manifest_name).read_bytes()
    return len(manifest['files'])

def check_ledger(base,schedule):
    rows=read(base/'ALL_PLANNED_SLOTS.json');assert len(rows)==24
    assert [r['schedule'] for r in rows]==schedule
    outer=read(base/'OUTER_FINISHED.json')
    errors=[]
    if outer['duplicate_call_ids'] or outer['malformed_rows']:errors.append('LEDGER_DUPLICATE_OR_MALFORMED')
    known=sum(r.get('process_spawned') is True for r in rows)
    unknown=sum(r.get('process_spawned') not in (True,False) for r in rows)
    return rows,{'planned':24,'known_spawned':known,'unknown_spawned_slots':unknown,'retained':len(rows)},errors

def audit():
    digest=frozen();main_receipt=receipt(ROOT/'provenance/RAW_MAIN_DRIVE_RECEIPT.json','RAW_MAIN',digest)
    verify_receipt=receipt(ROOT/'provenance/RAW_VERIFICATION_DRIVE_RECEIPT.json','RAW_VERIFICATION',digest)
    counts=[raw_check(ROOT/'raw','RAW_MAIN_CONTENT_MANIFEST.json',main_receipt,digest),
            raw_check(ROOT/'independent_supervision/raw','RAW_VERIFICATION_CONTENT_MANIFEST.json',verify_receipt,digest)]
    schedule=read(ROOT/'freeze/SCHEDULE.json');assert len(schedule)==24 and len({s['call_id'] for s in schedule})==24
    main_ledger,main_counts,errors=check_ledger(ROOT/'raw',schedule)
    ind_ledger,ind_counts,ind_errors=check_ledger(ROOT/'independent_supervision/raw',schedule);errors+=ind_errors
    parent=ROOT/'input/PARENT_FINAL.zip'
    with zipfile.ZipFile(parent) as z:
        parent_audit=json.loads(z.read('independent_supervision/FINAL_AUDIT.json'))
    assert parent_audit['status']=='PASS'
    rows=[];payloads={};inputs={}
    for slot,main_record,ind_record in zip(schedule,main_ledger,ind_ledger):
        cid=slot['call_id'];field=slot['instance_id']
        result={'call_id':cid,'instance_id':field,'objective':slot['objective'],'valid_for_exact_conclusion':False,
                'main_E':None,'main_G':None,'independent_E':None,'independent_G':None,'failure':None}
        try:
            assert not errors and field in parent_audit['eligible_instance_ids']
            for record in (main_record,ind_record):
                assert record.get('status')=='UNREVIEWED_PROCESS_SUCCESS' and not record.get('error')
                assert record.get('process_spawned') is True and record.get('returncode')==0 and record.get('child_reaped') is True
                assert not record.get('wall_timeout') and (record.get('registered_group_cleanup') or {}).get('quiescent') is True
            if field not in inputs:inputs[field]=load_input(field)
            matrices,identity=inputs[field]
            a=read(ROOT/'raw/calls'/(cid+'.stdout'));b=read(ROOT/'independent_supervision/raw/calls'/(cid+'.stdout'))
            al=check_payload(a,matrices,identity,slot,digest);bl=check_payload(b,matrices,identity,slot,digest)
            for k in ('E','G','partition','routes'):assert a[k]==b[k]
            assert al==bl
            assert a['counters']['local_route_evaluations']==54186 and a['counters']['unlabeled_partition_evaluations']==41811
            assert b['counters']['HK_states']==6744 and b['counters']['HK_internal_transitions']==23232
            assert b['counters']['assignment_candidate_transitions']==252439
            assert b['scalarization']['M']==5917201 and b['scalarization']['scalar_upper_bound']==35013267674400
            result.update(valid_for_exact_conclusion=True,main_E=a['E'],main_G=a['G'],independent_E=b['E'],independent_G=b['G'])
            payloads[(field,slot['objective'])]=a
        except (AssertionError,KeyError,TypeError,ValueError,OSError,IndexError) as e:
            result['failure']=type(e).__name__+':'+str(e)
        rows.append(result)
    fields=[];eligible=[]
    with decimal.localcontext() as ctx, zipfile.ZipFile(parent) as z:
        ctx.prec=80
        for field in read(ROOT/'freeze/PROTOCOL.json')['fields']:
            data={'instance_id':field,'valid_for_exact_conclusion':False,'delta_integer_mm':None,'order_loss_integer_mm':None,'partition_loss_integer_mm':None}
            if all((field,arm) in payloads for arm in ('E_G','G_E')):
                a,b=[payloads[(field,arm)] for arm in ('E_G','G_E')]
                g_local={r['mask']:r['G'] for r in b['local_routes']}
                gfix=sum(g_local[sum(1<<(x-1) for x in group)] for group in a['partition'])
                delta=a['G']-b['G'];order=a['G']-gfix;partition=gfix-b['G']
                assert min(delta,order,partition)>=0 and delta==order+partition
                pre=json.loads(z.read(f'raw/fields/{field}/preprocess.json'))
                pair_lengths={tuple(sorted(r['pair'])):D(r['decimal80_path_length_m']) for r in pre['pair_checks']}
                lengths=[]
                for plan in (a,b):
                    total=D(0)
                    for route in plan['routes']:
                        for i,j in zip(route,route[1:]):
                            length=pair_lengths[tuple(sorted((i,j)))];total+=length
                            assert abs(length-D(pre['integer_matrices']['G'][i][j])/1000)<=D('0.00050001')
                    lengths.append(total)
                difference=lengths[0]-lengths[1]
                assert abs(difference-D(delta)/1000)<=D('0.01500030')
                data.update(valid_for_exact_conclusion=True,delta_integer_mm=delta,order_loss_integer_mm=order,
                    partition_loss_integer_mm=partition,fixed_partition_G=gfix,E_star=a['E'],G_at_E_optimum=a['G'],G_star=b['G'],
                    E_at_G_optimum=b['E'],E_G_partition=a['partition'],G_E_partition=b['partition'],
                    actual_path_length_difference_m=str(difference),two_plan_rounding_plus_saved_path_tolerance_m='0.01500030')
                eligible.append(field)
            fields.append(data)
    deltas=[r['delta_integer_mm'] for r in fields if r['valid_for_exact_conclusion']]
    return {'status':'PASS' if len(eligible)==12 else 'AUDIT_COMPLETE_WITH_UNVERIFIED_SLOTS',
        'frozen_files_sha256':digest,'raw_main_archive_sha256':main_receipt['sha256'],'raw_verification_archive_sha256':verify_receipt['sha256'],
        'planned_fields':12,'planned_main_calls':24,'planned_independent_calls':24,'planned_total_objective_slots':48,
        'main_counts':main_counts,'independent_counts':ind_counts,'ledger_errors':errors,'rows':rows,'fields':fields,
        'eligible_instance_ids':eligible,'verified_fields':len(eligible),'raw_members_checked':counts,
        'complete_panel_mean_delta_integer_mm':sum(deltas)/12 if len(deltas)==12 else None,
        'complete_case_mean_delta_integer_mm':sum(deltas)/len(deltas) if deltas else None,'new_optimization_calls_in_saved_audit':0}

def main():
    assert __debug__
    resource.setrlimit(resource.RLIMIT_CPU,(15,15));resource.setrlimit(resource.RLIMIT_AS,(268435456,268435456));signal.alarm(30)
    started=time.monotonic();save(ROOT/'independent_supervision/SAVED_AUDIT_STARTED.json',{'utc':utc(),'new_optimization_calls':0})
    out=audit();u=resource.getrusage(resource.RUSAGE_SELF)
    out.update(utc=utc(),cpu_seconds=u.ru_utime+u.ru_stime,wall_seconds=time.monotonic()-started,peak_rss_kib=u.ru_maxrss)
    save(ROOT/'independent_supervision/FINAL_AUDIT.json',out);print(json.dumps({'status':out['status'],'verified_fields':out['verified_fields']}))
if __name__=='__main__':main()
