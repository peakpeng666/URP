import sys,resource,json,pathlib
sys.path.insert(0,'/workspace/shared/capacitated_field_comparison_20261009/source')
from tree_runtime import run_command
from launch_main_once import author_outer_limits
limits=author_outer_limits()
r=run_command(["/usr/bin/python3",'/workspace/shared/capacitated_field_comparison_20261009/selftests/resource_inheritance/supervisor.py'],pathlib.Path('/workspace/shared/capacitated_field_comparison_20261009/selftests/resource_inheritance/supervisor'),15,134217728,10,pathlib.Path('/workspace/shared/capacitated_field_comparison_20261009/selftests/resource_inheritance/supervisor.active.json'),cpu_hard=60,as_hard=268435456)
print(json.dumps({"outer_limits":limits,"supervisor":r}))
