import sys,resource,json,pathlib
sys.path.insert(0,'/workspace/shared/capacitated_field_comparison_20261009/source')
from tree_runtime import run_command
limits={"cpu":list(resource.getrlimit(resource.RLIMIT_CPU)),"as":list(resource.getrlimit(resource.RLIMIT_AS))}
r=run_command(["/usr/bin/python3",'/workspace/shared/capacitated_field_comparison_20261009/selftests/resource_inheritance/worker.py'],pathlib.Path('/workspace/shared/capacitated_field_comparison_20261009/selftests/resource_inheritance/worker'),15,268435456,5,pathlib.Path('/workspace/shared/capacitated_field_comparison_20261009/selftests/resource_inheritance/worker.active.json'))
print(json.dumps({"supervisor_limits":limits,"worker":r}))
