import sys,json,resource
print(json.dumps({"synthetic_only":True,"real_objective_calls":0,"field":sys.argv[1],"objective":sys.argv[2],"cpu_limits":list(resource.getrlimit(resource.RLIMIT_CPU)),"as_limits":list(resource.getrlimit(resource.RLIMIT_AS))}))
sys.exit(7 if sys.argv[1:]==["SYNTH_05","G_E"] else 0)
