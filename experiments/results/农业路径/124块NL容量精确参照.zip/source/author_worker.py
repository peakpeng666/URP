"""One formal objective. Gate before any real input derivation or optimizer call."""
import json, resource, sys, time
from gates import active_main_gate
from inputs import load_input
from author_solver import solve


def main():
    assert __debug__
    digest = active_main_gate()
    field, objective = sys.argv[1:]
    if objective not in ('E_G', 'G_E'):
        raise ValueError('UNSCHEDULED_OBJECTIVE')
    started, cpu = time.monotonic(), time.process_time()
    matrices, identity = load_input(field)
    row = solve(matrices['E'], matrices['G'], 5, 3, objective)
    row.update(instance_id=field, frozen_files_sha256=digest, input_identity=identity, input_matrices=matrices,
               status='PROCESS_SUCCESS_UNREVIEWED', resources={'wall_seconds': time.monotonic() - started,
               'cpu_seconds': time.process_time() - cpu, 'maxrss_kib': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
               'cpu_limits': list(resource.getrlimit(resource.RLIMIT_CPU)), 'as_limits': list(resource.getrlimit(resource.RLIMIT_AS))})
    print(json.dumps(row, allow_nan=False))


if __name__ == '__main__':
    main()
