"""Read-only externally issued approvals. No function creates authority or receipts."""
import hashlib, pathlib, zipfile
from common import ROOT, read, sha, verify_map


def frozen():
    path = ROOT / 'freeze/FROZEN_FILES.json'
    verify_map(ROOT, read(path)['files'])
    return sha(path)


def receipt(path, stage, digest):
    row = read(path)
    if row.get('synthetic_only') or row.get('stage') != stage:
        raise RuntimeError('WRONG_OR_SYNTHETIC_RECEIPT')
    if not all(row.get(k) is True for k in ('verified', 'owner_only', 'remote_readback_sha256_verified', 'download_byte_identical')) or row.get('shared') is not False:
        raise RuntimeError('PRIVATE_ACTUAL_BYTE_READBACK_REQUIRED')
    if row.get('sha256') != row.get('download_sha256') or row.get('frozen_files_sha256') != digest:
        raise RuntimeError('RECEIPT_HASH_BINDING')
    for key in ('source', 'download_path'):
        if not pathlib.Path(row[key]).is_file() or sha(row[key]) != row['sha256']:
            raise RuntimeError('ACTUAL_ARCHIVE_BYTES_MISMATCH')
    with zipfile.ZipFile(row['download_path']) as archive:
        if hashlib.sha256(archive.read('freeze/FROZEN_FILES.json')).hexdigest() != digest:
            raise RuntimeError('ARCHIVE_FREEZE_BINDING')
        for rel, value in read(ROOT / 'freeze/FROZEN_FILES.json')['files'].items():
            raw = archive.read(rel)
            if len(raw) != value['bytes'] or hashlib.sha256(raw).hexdigest() != value['sha256']:
                raise RuntimeError('ARCHIVE_FROZEN_MEMBER_IDENTITY:' + rel)
    return row


def parent_ready():
    protocol=read(ROOT/'freeze/PROTOCOL.json');row=read(ROOT/'input/PARENT_FINAL_DRIVE_RECEIPT.json')
    if row.get('stage')!='FINAL' or row.get('sha256')!=protocol['costs']['source_archive_sha256'] or row.get('frozen_files_sha256')!=protocol['costs']['input_final_frozen_files_sha256']:
        raise RuntimeError('PARENT_FINAL_BINDING')
    if not all(row.get(k)is True for k in ('verified','owner_only','remote_readback_sha256_verified','download_byte_identical')) or row.get('shared')is not False:
        raise RuntimeError('PARENT_PRIVATE_ACTUAL_READBACK_REQUIRED')
    archive=ROOT/protocol['costs']['source_archive']
    if sha(archive)!=row['sha256'] or row['sha256']!=row['download_sha256'] or sha(row['download_path'])!=row['sha256']:
        raise RuntimeError('PARENT_ACTUAL_BYTES_REQUIRED')
    identities=read(ROOT/'input/PARENT_MEMBER_IDENTITIES.json')
    if identities['parent_archive_sha256']!=row['sha256']:raise RuntimeError('PARENT_SELECTED_MANIFEST_IDENTITY')
    with zipfile.ZipFile(archive) as z:
        if hashlib.sha256(z.read('freeze/FROZEN_FILES.json')).hexdigest()!=row['frozen_files_sha256']:raise RuntimeError('PARENT_FREEZE_MEMBER')
        for rel,value in identities['selected_members'].items():
            b=z.read(rel)
            if len(b)!=value['bytes']or hashlib.sha256(b).hexdigest()!=value['sha256']:raise RuntimeError('PARENT_SELECTED_MEMBER_IDENTITY:'+rel)
    return row


def main_ready():
    digest = frozen()
    parent_ready()
    archived = receipt(ROOT / 'provenance/PREEXEC_DRIVE_RECEIPT.json', 'PREEXEC', digest)
    approval = read(ROOT / 'provenance/PARENT_MAIN_APPROVAL.json')
    if approval.get('approved') is not True or approval.get('frozen_files_sha256') != digest or approval.get('preexec_archive_sha256') != archived['sha256'] or approval.get('main_calls') != 248 or approval.get('verification_calls') != 248 or approval.get('fields') != 124:
        raise RuntimeError('ROOT_HASH_BOUND_MAIN_APPROVAL_REQUIRED')
    check = read(ROOT / 'freeze/INDEPENDENT_PRECHECK.json')
    if check.get('status') != 'PASS' or not check.get('reviewed_files'):
        raise RuntimeError('INDEPENDENT_PRECHECK_REQUIRED')
    verify_map(ROOT, check['reviewed_files'])
    return digest


def active_main_gate():
    digest = main_ready()
    launch = read(ROOT / 'provenance/MAIN_LAUNCH_STARTED.json')
    if launch.get('frozen_files_sha256') != digest or launch.get('planned_main_calls') != 248 or launch.get('planned_fields') != 124:
        raise RuntimeError('UNIQUE_ACTIVE_MAIN_LAUNCH_REQUIRED')
    return digest


def verification_ready():
    digest = frozen()
    parent_ready()
    archived = receipt(ROOT / 'provenance/RAW_MAIN_DRIVE_RECEIPT.json', 'RAW_MAIN', digest)
    approval = read(ROOT / 'provenance/PARENT_VERIFICATION_APPROVAL.json')
    if approval.get('approved') is not True or approval.get('frozen_files_sha256') != digest or approval.get('raw_main_archive_sha256') != archived['sha256'] or approval.get('verification_calls') != 248 or approval.get('fields') != 124:
        raise RuntimeError('ROOT_HASH_BOUND_INDEPENDENT_APPROVAL_REQUIRED')
    return digest
