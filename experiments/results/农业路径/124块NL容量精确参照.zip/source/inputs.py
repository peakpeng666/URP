"""Direct frozen13 input; no projection, route objective evaluation or optimization."""
import hashlib,json,zipfile
from common import ROOT,read,sha

def load_input(field):
 protocol=read(ROOT/'freeze/PROTOCOL.json')
 if field not in protocol['fields']:raise ValueError('UNSCHEDULED_FIELD')
 archive=ROOT/protocol['costs']['source_archive'];archive_sha=sha(archive)
 if archive_sha!=protocol['costs']['source_archive_sha256']:raise ValueError('PARENT_ARCHIVE_IDENTITY')
 identities=read(ROOT/'input/PARENT_MEMBER_IDENTITIES.json')['selected_members'];loaded={};file_hashes={}
 names=['independent_supervision/FINAL_INPUT_AUDIT.json','raw/ALL_FIELD_SLOTS.json']+['raw/fields/'+field+'/'+n for n in ('preprocess.json','services.json','graph.json')]
 with zipfile.ZipFile(archive) as z:
  for member in names:
   raw=z.read(member);digest=hashlib.sha256(raw).hexdigest()
   if digest!=identities[member]['sha256'] or len(raw)!=identities[member]['bytes']:raise ValueError('PARENT_MEMBER_IDENTITY')
   loaded[member]=json.loads(raw);file_hashes[member]=digest
 audit=loaded[names[0]]
 if audit['status']!='INPUT_EVIDENCE_AUDITED' or audit['planned_fields']!=124 or [r['instance_id']for r in audit['fields']]!=protocol['fields']:raise ValueError('UPSTREAM_AUDIT_IDENTITY')
 rows=[r for r in audit['fields']if r['instance_id']==field];slots=[r for r in loaded[names[1]]if r['instance_id']==field]
 if len(rows)!=1 or len(slots)!=1:raise ValueError('UPSTREAM_FIELD_IDENTITY')
 reviewed,slot=rows[0],slots[0]
 if reviewed['input_ready'] is not True or reviewed['numeric_flags']['exact_signed64_safe'] is not True:raise ValueError('INPUT_NOT_EXACT_READY')
 if slot['author_pass_unreviewed'] is not True or reviewed['preprocess_sha256']!=file_hashes[names[2]] or slot['preprocess']['sha256']!=file_hashes[names[2]]:raise ValueError('UPSTREAM_PREPROCESS_BINDING')
 data,services,graph=[loaded[n]for n in names[2:]]
 if data['status']!='PASS_PREPROCESS' or data['instance_id']!=field or data['n']!=12 or data['K']!=3 or data['capacity']!=5 or data['demands']!=[0]+[1]*12:raise ValueError('SOURCE_Q5_MODEL')
 if data['graph_construction_identity']!=protocol['costs']['graph_construction_identity']:raise ValueError('SOURCE_GRAPH_IDENTITY')
 if services['n']!=12 or data['coordinates']!=services['coordinates'] or len(data['coordinates'])!=13:raise ValueError('SOURCE_COORDINATE_IDENTITY')
 matrices=data['integer_matrices']
 for key in ('E','G'):
  matrix=matrices[key]
  if len(matrix)!=13 or any(len(row)!=13 for row in matrix):raise ValueError('SOURCE_MATRIX_DIMENSION')
  for i in range(13):
   for j in range(13):
    v=matrix[i][j]
    if type(v)is not int or v<0 or v!=matrix[j][i] or (i==j and v):raise ValueError('SOURCE_MATRIX_VALUE')
 for primary,secondary in [('E','G'),('G','E')]:
  a=max(map(max,matrices[primary]));b=max(map(max,matrices[secondary]));M=15*b+1
  if not 15*a*M+15*b<2**63-1:raise ValueError('PRELOCKED_EXACT_INTEGER_GUARD')
 for i in range(13):
  for j in range(13):
   path=data['canonical_paths'][i][j]
   if path[0]!=graph['service_node_ids'][i] or path[-1]!=graph['service_node_ids'][j]:raise ValueError('SOURCE_PATH_ENDPOINT')
   if any(v>=graph['base_count']for v in path[1:-1]):raise ValueError('SOURCE_PATH_TERMINAL_ONLY')
 selected={k:matrices[k]for k in ('E','G')}
 fingerprint=hashlib.sha256(json.dumps(selected,sort_keys=True,separators=(',',':')).encode()).hexdigest()
 identity={'parent_archive_sha256':archive_sha,'members':file_hashes,'selected_original_ids':list(range(13)),'selected_matrix_canonical_json_sha256':fingerprint,'preprocess_sha256':file_hashes[names[2]],'upstream_final_input_audit_sha256':file_hashes[names[0]]}
 return selected,identity
