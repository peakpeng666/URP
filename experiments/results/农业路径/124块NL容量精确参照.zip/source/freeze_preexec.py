"""Freeze after current bound independent PRECHECK; this is not execution authority."""
from common import ROOT,read,save,sha,inventory,verify_map,utc

def main():
 check=read(ROOT/'freeze/INDEPENDENT_PRECHECK.json');assert check['status']=='PASS' and check['reviewed_files'];verify_map(ROOT,check['reviewed_files'])
 for rel in ['raw','independent_supervision/raw','provenance/MAIN_LAUNCH_STARTED.json','provenance/VALIDATION_LAUNCH_STARTED.json']:assert not(ROOT/rel).exists()
 files=[p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p!=ROOT/'freeze/FROZEN_FILES.json']
 save(ROOT/'freeze/FROZEN_FILES.json',dict(utc=utc(),status='PREEXEC_IDENTITY_ONLY_NOT_EXECUTION_APPROVAL',files=inventory(ROOT,files),approved_real_exact_calls=0,approved_native_calls=0))
 print(sha(ROOT/'freeze/FROZEN_FILES.json'))
if __name__=='__main__':main()
