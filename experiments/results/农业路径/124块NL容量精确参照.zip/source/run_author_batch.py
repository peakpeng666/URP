"""One sequential main batch with all 248 planned objective slots retained."""
import time
from common import ROOT, read, save, append, utc
from gates import active_main_gate
from tree_runtime import run_command


def main():
    digest = active_main_gate()
    dest = ROOT / 'raw'
    dest.mkdir(exist_ok=False)
    (dest / 'calls').mkdir(); (dest / 'active').mkdir()
    schedule = read(ROOT / 'freeze/SCHEDULE.json')
    started = time.monotonic(); deadline = started + 7700
    save(dest / 'STARTED.json', {'utc': utc(), 'frozen_files_sha256': digest, 'planned_main_calls': 248, 'planned_fields': 124})
    rows = []; stopped = False
    for slot in schedule:
        remaining = deadline - time.monotonic()
        row = {'schedule': slot, 'utc': utc()}
        if stopped:
            row.update(status='NOT_STARTED_LIFECYCLE_FAILURE', process_spawned=False, child_reaped=False)
        elif remaining <= 0:
            row.update(status='NOT_STARTED_BATCH_BUDGET', process_spawned=False, child_reaped=False)
        else:
            cid = slot['call_id']
            append(dest / 'events.jsonl', {'event_kind': 'OBJECTIVE_START_REQUESTED', 'schedule': slot, 'utc': utc()})
            row.update(run_command(['/usr/bin/python3', ROOT / 'source/author_worker.py', slot['instance_id'], slot['objective']],
                                   dest / 'calls' / cid, 15, 268435456, min(30, remaining), dest / 'active' / (cid + '.active.json')))
        append(dest / 'results.jsonl', row); rows.append(row)
        if row.get('status') == 'LIFECYCLE_FAILURE': stopped = True
    save(dest / 'FINISHED.json', {'utc': utc(), 'planned_main_calls': 248, 'recorded_slots': len(rows),
         'known_started_processes': sum(row.get('process_spawned') is True for row in rows), 'wall_seconds': time.monotonic() - started,
         'status': 'RAW_MAIN_UNREVIEWED', 'note': 'Objective slots and candidate enumeration counters are distinct.'})


if __name__ == '__main__':
    main()
