"""Saved-evidence report and postprocessing truth only; no optimizer imports."""
import json,zipfile
from decimal import Decimal,localcontext
from common import ROOT,read,save,sha,utc
from gates import frozen,receipt,parent_ready

def diagnostic(eg, ge, pair_lengths=None):
    if eg['objective'] != 'E_G' or ge['objective'] != 'G_E':
        raise ValueError('REPORT_OBJECTIVE_IDENTITY')
    delta = eg['G'] - ge['G']
    local = {row['mask']: row for row in ge['local_routes']}
    masks = [sum(1 << (x - 1) for x in group) for group in eg['partition']]
    fixed = sum(local[mask]['G'] for mask in masks)
    order_loss, partition_loss = eg['G'] - fixed, fixed - ge['G']
    if delta < 0 or order_loss < 0 or partition_loss < 0 or delta != order_loss + partition_loss:
        raise ValueError('DECOMPOSITION_IDENTITY_FAILURE')
    result = {'delta_integer_mm': delta, 'fixed_selected_partition_G_integer_mm': fixed,
              'order_loss_integer_mm': order_loss, 'partition_loss_integer_mm': partition_loss,
              'relative_integer_percent': 100 * delta / ge['G'] if ge['G'] else None,
              'same_selected_partition': eg['partition'] == ge['partition'],
              'E_G': {k: eg[k] for k in ('E', 'G', 'partition', 'routes')},
              'G_E': {k: ge[k] for k in ('E', 'G', 'partition', 'routes')}}
    if pair_lengths is not None:
        with localcontext() as context:
            context.prec = 80
            lengths = [sum((Decimal(pair_lengths[tuple(sorted((a, b)))]) for route in row['routes'] for a, b in zip(route, route[1:])), Decimal(0)) for row in (eg, ge)]
            result['representative_realized_G_lengths_m_decimal80'] = [str(value) for value in lengths]
            result['representative_realized_difference_m_decimal80'] = str(lengths[0] - lengths[1])
    return result



AUDIT_KEYS=('frozen_files_sha256','raw_main_archive_sha256','raw_verification_archive_sha256',
 'input_final_archive_sha256','input_final_frozen_files_sha256','input_final_actual_readback',
 'raw_main_actual_readback','raw_verification_actual_readback','planned_fields','planned_main_calls',
 'planned_independent_calls','planned_total_objective_slots','main_counts','independent_counts','fields',
 'eligible_instance_ids','verified_fields','verified_objective_slots','complete_panel_mean_delta_integer_mm',
 'complete_case_mean_delta_integer_mm','ledger_errors','rows')

def make_reference(audit,audit_sha):
 fields=[]
 for row in audit['fields']:
  objectives={}
  for objective in ('E_G','G_E'):
   o=row['objectives'][objective]
   if type(o['verified'])is not bool:raise ValueError('TARGET_VERIFIED_NOT_BOOLEAN')
   if o['verified']:
    if o['failure']is not None or type(o['E'])is not int or type(o['G'])is not int:raise ValueError('TARGET_VALUE_CONTRACT')
   elif any(o[k]is not None for k in ('E','G','partition','canonical_routes')):raise ValueError('UNVERIFIED_TARGET_HAS_VALUE')
   objectives[objective]=dict(o)
  eg,ge=objectives['E_G'],objectives['G_E'];both=eg['verified']and ge['verified']
  estar=eg['E']if eg['verified']else None;gstar=ge['G']if ge['verified']else None
  delta=eg['G']-ge['G']if both else None
  if (row['E_star'],row['G_star'],row['delta_integer_mm'],row['valid_for_exact_conclusion'])!=(estar,gstar,delta,both):raise ValueError('PARTIAL_TARGET_DERIVATION')
  fields.append({'instance_id':row['instance_id'],'input_preprocess_sha256':row['preprocess_sha256'],'objectives':objectives,'E_star':estar,'G_star':gstar,'delta_integer_mm':delta,'valid_for_exact_conclusion':both})
 result={'status':'EXACT_REFERENCE_AUDITED','independent_audit_sha256':audit_sha,'fields':fields,
 'objective_slots':audit['rows'],'new_optimization_calls_in_derivation':0,
 'scope':'Saved independently matched exact references. Partial objective validity is explicit; input for analysis only, never native worker.'}
 for key in ('frozen_files_sha256','raw_main_archive_sha256','raw_verification_archive_sha256','input_final_archive_sha256','input_final_frozen_files_sha256','input_final_actual_readback','raw_main_actual_readback','raw_verification_actual_readback','planned_fields','planned_main_calls','planned_independent_calls','planned_total_objective_slots','main_counts','independent_counts','eligible_instance_ids','verified_fields','verified_objective_slots'):
  result[key]=audit[key]
 return result

def display(value):
 return '不可估计' if value is None else value

def main():
 digest=frozen();parent_receipt=parent_ready()
 rm=receipt(ROOT/'provenance/RAW_MAIN_DRIVE_RECEIPT.json','RAW_MAIN',digest)
 rv=receipt(ROOT/'provenance/RAW_VERIFICATION_DRIVE_RECEIPT.json','RAW_VERIFICATION',digest)
 path=ROOT/'independent_supervision/FINAL_AUDIT.json';audit=read(path);audit_sha=sha(path)
 if audit['status']not in ('PASS','AUDIT_COMPLETE_WITH_UNVERIFIED_SLOTS'):raise ValueError('INDEPENDENT_SAVED_AUDIT_REQUIRED')
 bindings={'frozen_files_sha256':digest,'raw_main_archive_sha256':rm['sha256'],'raw_verification_archive_sha256':rv['sha256'],'input_final_archive_sha256':parent_receipt['sha256'],'input_final_frozen_files_sha256':parent_receipt['frozen_files_sha256']}
 if any(audit[k]!=v for k,v in bindings.items()):raise ValueError('AUDIT_BINDING_MISMATCH')
 if any(audit[k]is not True for k in ('input_final_actual_readback','raw_main_actual_readback','raw_verification_actual_readback')):raise ValueError('AUDIT_ACTUAL_READBACK_REQUIRED')
 protocol=read(ROOT/'freeze/PROTOCOL.json');identities=read(ROOT/'input/PARENT_MEMBER_IDENTITIES.json')['selected_members']
 if [r['instance_id']for r in audit['fields']]!=protocol['fields']or len(audit['fields'])!=124:raise ValueError('ALL124_FIELDS_REQUIRED')
 diagnostics=[]
 with zipfile.ZipFile(ROOT/'input/PARENT_FINAL.zip')as parent:
  for field in audit['fields']:
   fid=field['instance_id'];witnesses={};member='raw/fields/'+fid+'/preprocess.json'
   if field['preprocess_sha256']!=identities[member]['sha256']:raise ValueError('REPORT_PREPROCESS_IDENTITY')
   for objective in ('E_G','G_E'):
    target=field['objectives'][objective]
    if target['verified']:
     paths=[ROOT/'raw/calls'/(fid+'_'+objective+'.stdout'),ROOT/'independent_supervision/raw/calls'/(fid+'_'+objective+'.stdout')]
     for p,key in zip(paths,('main_stdout_sha256','independent_stdout_sha256')):
      if sha(p)!=target[key]:raise ValueError('REPORT_STDOUT_HASH')
      row=read(p)
      if row['instance_id']!=fid or row['objective']!=objective or row['frozen_files_sha256']!=digest or row['input_identity']['preprocess_sha256']!=field['preprocess_sha256']:raise ValueError('REPORT_STDOUT_IDENTITY')
      if (row['E'],row['G'],row['partition'],row['routes'])!=(target['E'],target['G'],target['partition'],target['canonical_routes']):raise ValueError('REPORT_WITNESS_MISMATCH')
     witnesses[objective]=read(paths[0])
   item={'instance_id':fid,'eligible_for_primary':field['valid_for_exact_conclusion']}
   if field['valid_for_exact_conclusion']:
    pre=json.loads(parent.read(member));lengths={tuple(x['pair']):x['decimal80_path_length_m']for x in pre['pair_checks']}
    value=diagnostic(witnesses['E_G'],witnesses['G_E'],lengths)
    for key in ('delta_integer_mm','order_loss_integer_mm','partition_loss_integer_mm'):
     if value[key]!=field[key]:raise ValueError('AUTHOR_INDEPENDENT_DIAGNOSTIC_MISMATCH:'+key)
    if value['fixed_selected_partition_G_integer_mm']!=field['fixed_partition_G']or value['representative_realized_difference_m_decimal80']!=field['actual_path_length_difference_m']:raise ValueError('AUTHOR_INDEPENDENT_PATH_SUM_MISMATCH')
    item.update(value)
   diagnostics.append(item)
 truth=make_reference(audit,audit_sha);save(ROOT/'truth/EXACT_REFERENCE.json',truth)
 summary={k:audit[k]for k in AUDIT_KEYS};summary.update(status='SAVED_EXACT_REFERENCE_REPORT',independent_audit_sha256=audit_sha,truth_sha256=sha(ROOT/'truth/EXACT_REFERENCE.json'),author_diagnostics=diagnostics,utc=utc(),scope=protocol['scope'],new_optimization_calls=0)
 save(ROOT/'reports/SUMMARY.json',summary)
 lines=['124块NL扩展验证：容量约束双目标精确参照',
 '输入阶段已审124块全部保留。每田depot+12合成单位需求客户，Q5/最多3车强制恰3条路线。',
 '两目标均已核：%s/124；已核单目标：%s/248（每目标作者与独立各一个预定槽）。'%(audit['verified_fields'],audit['verified_objective_slots']),
 '作者248+独立248共496目标槽全部保留；局部回路、分区和DP转移不是独立样本或目标调用。',
 '主已知/未知/未启动：%s；独：%s。'%(audit['main_counts'],audit['independent_counts']),
 '完整124田均值Delta(mm)：%s。完整案例均值：%s；分母%s。'%(display(audit['complete_panel_mean_delta_integer_mm']),display(audit['complete_case_mean_delta_integer_mm']),audit['verified_fields']),
 'Delta=E最优集合内的最小G成本−全局G最优成本。排序损失与分区损失均非负、和为Delta；分解只描述规范代表，不是所有E最优分区或因果效应。']
 for r in audit['fields']:
  lines.append('%s：E_G核验=%s，G_E核验=%s，E_star=%s，G_star=%s，Delta=%s mm，排序=%s mm，分区=%s mm，失败=%s'%(r['instance_id'],r['objectives']['E_G']['verified'],r['objectives']['G_E']['verified'],display(r['E_star']),display(r['G_star']),display(r['delta_integer_mm']),display(r['order_loss_integer_mm']),display(r['partition_loss_integer_mm']),{k:r['objectives'][k]['failure']for k in ('E_G','G_E')}))
 lines+=['原冻结13×13E/G整数矩阵直接使用，无新任务/图/路径/取整。G只针对已核合法有限候选图，不称连续平面最优；没有车际避碰和同时调度模型。',
 '15腿每方案取整界0.0075米，两方案差0.015米；计入每腿既定保存路径容差为0.01500030米，不是测绘、投影或实车误差界。',
 '历史已定位面板之外的124块NL扩展验证；元数据与原几何字节曾见，不承诺全历史未见，不作全国总体、实车泛化或新旧田地单因素结论。',
 'truth/EXACT_REFERENCE.json只供native结果保存后处理。每目标verified独立决定own gap/hit是否可用；双目标参考指标要求两侧已核，失败保留null。精确真值不进入nativeworker。',
 'P可行性为条件不变式迁移/接线检查；250有限预算质量和精确命中另报。E搜索A/P配对G差、自身gap、精确代理Delta、有符号参考偏移分别定义。',
 '父输入FINAL、双RAW私有实际字节回读、独保存审计均已核。此报告只处理保存证据；终稿审阅与FINAL归档仍为后续交付步骤。']
 with (ROOT/'reports/REPORT_ZH.txt').open('x')as f:f.write('\n'.join(lines)+'\n')
 print('Saved reference/report written; final review and archive required.')

if __name__=='__main__':main()
