"""Read byte-bound, independently certified input; never import author reader/solver."""
import hashlib
import json
import pathlib
import zipfile

ROOT = pathlib.Path(__file__).resolve().parents[2]


def digest(data):
    return hashlib.sha256(data).hexdigest()


def load_input(field):
    protocol = json.loads((ROOT / 'freeze/PROTOCOL.json').read_text())
    assert field in protocol['fields']
    archive = ROOT / 'input/PARENT_FINAL.zip'
    archive_hash = digest(archive.read_bytes())
    assert archive_hash == protocol['costs']['source_archive_sha256']
    identities = json.loads((ROOT / 'input/PARENT_MEMBER_IDENTITIES.json').read_text())['selected_members']
    audit_name = 'independent_supervision/FINAL_INPUT_AUDIT.json'
    ledger_name = 'raw/ALL_FIELD_SLOTS.json'
    names = [audit_name, ledger_name] + [f'raw/fields/{field}/{name}' for name in ('preprocess.json', 'services.json', 'graph.json')]
    decoded, hashes, sizes = {}, {}, {}
    with zipfile.ZipFile(archive) as z:
        for name in names:
            data = z.read(name)
            hashes[name], sizes[name] = digest(data), len(data)
            assert identities[name] == {'bytes': len(data), 'sha256': hashes[name]}
            decoded[name] = json.loads(data)
    audit = decoded[audit_name]
    assert audit['status'] == 'INPUT_EVIDENCE_AUDITED' and audit['planned_fields'] == 124
    assert audit['frozen_files_sha256'] == '43a3a05519bbfa4689a071e1dc71e44c86585c2f215ead4319a8318f708e05ef'
    audited = [row for row in audit['fields'] if row['instance_id'] == field]
    author = [row for row in decoded[ledger_name] if row['instance_id'] == field]
    assert len(audited) == len(author) == 1
    audited, author = audited[0], author[0]
    assert audited['input_ready'] is True and audited['numeric_flags']['exact_signed64_safe'] is True
    assert author['author_pass_unreviewed'] is True
    rel = f'raw/fields/{field}/preprocess.json'
    assert audited['preprocess_path'] == rel and audited['preprocess_sha256'] == hashes[rel]
    assert audited['preprocess_bytes'] == sizes[rel]
    assert author['preprocess']['exists'] is True and author['preprocess']['sha256'] == hashes[rel]
    assert author['preprocess']['bytes'] == sizes[rel]
    pre, services, graph = [decoded[f'raw/fields/{field}/{name}'] for name in ('preprocess.json', 'services.json', 'graph.json')]
    assert pre['status'] == 'PASS_PREPROCESS' and pre['instance_id'] == services['instance_id'] == field
    assert pre['n'] == services['n'] == 12 and pre['K'] == 3 and pre['capacity'] == 5
    assert pre['demands'] == [0] + [1] * 12
    assert pre['coordinates'] == services['coordinates'] and len(pre['coordinates']) == 13
    assert pre['graph_construction_identity'] == 'DIRECT_13_TERMINAL_SERVICES_NOT_OLD_21_THEN_SUBMATRIX'
    matrices = pre['integer_matrices']
    assert set(matrices) == {'E', 'G'}
    for matrix in matrices.values():
        assert len(matrix) == 13 and all(len(row) == 13 for row in matrix)
        assert all(type(matrix[i][j]) is int and 0 <= matrix[i][j] == matrix[j][i]
                   and (i != j or matrix[i][j] == 0) for i in range(13) for j in range(13))
    # Recheck the input-only signed-integer proof without evaluating a route.
    for objective, primary, secondary in [('E_G', 'E', 'G'), ('G_E', 'G', 'E')]:
        pmax = max(map(max, matrices[primary])); smax = max(map(max, matrices[secondary]))
        multiplier = 15 * smax + 1
        upper = 15 * pmax * multiplier + 15 * smax
        bound = pre['numeric_bounds']['exact_scalarization'][objective]
        assert upper < 2**63 - 1 and bound['signed64_safe'] is True
        assert bound['multiplier'] == multiplier and bound['scalar_complete_solution_upper'] == upper
    assert audited['numeric_bounds'] == pre['numeric_bounds']
    for i in range(13):
        for j in range(13):
            path = pre['canonical_paths'][i][j]
            assert path[0] == graph['service_node_ids'][i] and path[-1] == graph['service_node_ids'][j]
            assert all(node < graph['base_count'] for node in path[1:-1])
    identity = {'parent_archive_sha256': archive_hash, 'members': hashes,
                'selected_original_ids': list(range(13)),
                'selected_matrix_canonical_json_sha256': digest(json.dumps(matrices, sort_keys=True, separators=(',', ':')).encode()),
                'preprocess_sha256': hashes[rel], 'upstream_final_input_audit_sha256': hashes[audit_name]}
    return matrices, identity
