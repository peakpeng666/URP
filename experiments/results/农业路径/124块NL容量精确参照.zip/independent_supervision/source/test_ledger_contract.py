"""Zero-process replay of the expanded248-slot loss-aware seal."""
import pathlib,sys,json,importlib.util
ROOT=pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'source'))


def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);out=importlib.util.module_from_spec(spec);spec.loader.exec_module(out);return out


def main():
    schedule=[{'call_id':'INVENTED_'+str(i),'instance_id':'INVENTED_FIELD_'+str(i//2),'objective':('E_G','G_E')[i%2]}for i in range(248)]
    results=[]
    for side,path in [('author',ROOT/'source/launch_main_once.py'),('independent',ROOT/'independent_supervision/source/launch_validation_once.py')]:
        m=module('fixture_'+side,path)
        base=ROOT/'independent_supervision/preparation/ledger_contract'/side;base.mkdir(parents=True,exist_ok=False)
        m.ROOT=base;dest=base/'raw';(dest/'calls').mkdir(parents=True)
        first={'schedule':schedule[0],'status':'PROCESS_FAILURE','process_spawned':True,'returncode':1,'child_reaped':True}
        (dest/'results.jsonl').write_text(json.dumps(first)+'\n'+ '{"schedule":')
        (dest/'calls'/(schedule[1]['call_id']+'.stdout')).write_text('partial output')
        m.seal(dest,schedule,'synthetic-freeze',{'process_spawned':False,'synthetic_only':True})
        rows=json.loads((dest/'ALL_PLANNED_SLOTS.json').read_text());outer=json.loads((dest/'OUTER_FINISHED.json').read_text())
        assert len(rows)==248 and rows[0]==first and rows[1]['process_spawned']=='UNKNOWN'
        assert all(r['process_spawned']is False for r in rows[2:])
        assert outer['malformed_rows']==[1] and outer['planned_fields']==124 and outer['planned_objective_slots']==248
        results.append({'side':side,'known_failed':1,'unknown':1,'not_started':246,'retained':248})
    out={'status':'PASS','fixture_scope':'INVENTED_LEDGER_NO_CHILD_PROCESS','results':results,
         'new_optimizer_calls':0,'new_native_calls':0,'new_synthetic_objective_calls':0,'new_worker_processes':0}
    with (ROOT/'independent_supervision/preparation/LEDGER_CONTRACT.json').open('x')as f:json.dump(out,f,indent=2)
    print(json.dumps(out))


if __name__=='__main__':main()
