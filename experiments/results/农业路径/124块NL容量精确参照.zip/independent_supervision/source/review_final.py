"""Final structured reference/report audit; reader prose is reviewed directly."""
import pathlib,sys,json,time,resource,signal
ROOT=pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'source'))
from common import read,save,sha,utc
from gates import frozen,receipt,parent_ready
from saved_audit import reference_from_audit

KEYS=('frozen_files_sha256','raw_main_archive_sha256','raw_verification_archive_sha256',
      'input_final_archive_sha256','input_final_frozen_files_sha256','input_final_actual_readback',
      'raw_main_actual_readback','raw_verification_actual_readback','planned_fields','planned_main_calls',
      'planned_independent_calls','planned_total_objective_slots','main_counts','independent_counts','fields',
      'eligible_instance_ids','verified_fields','verified_objective_slots','complete_panel_mean_delta_integer_mm',
      'complete_case_mean_delta_integer_mm','ledger_errors','rows')


def compare(audit,summary,truth,audit_sha):
    assert audit['status'] in ('PASS','AUDIT_COMPLETE_WITH_UNVERIFIED_SLOTS')
    assert audit['planned_fields']==len(audit['fields'])==124
    assert audit['planned_main_calls']==audit['planned_independent_calls']==len(audit['rows'])==248
    assert audit['planned_total_objective_slots']==496
    assert len({r['instance_id']for r in audit['fields']})==124
    assert len({r['call_id']for r in audit['rows']})==248
    assert audit['verified_objective_slots']==sum(r['valid_for_exact_conclusion']for r in audit['rows'])
    assert audit['verified_fields']==sum(r['valid_for_exact_conclusion']for r in audit['fields'])
    assert audit['eligible_instance_ids']==[r['instance_id']for r in audit['fields']if r['valid_for_exact_conclusion']]
    for side in ('main_counts','independent_counts'):
        counts=audit[side]
        assert counts['planned']==counts['retained']==248
        assert counts['known_spawned']+counts['unknown_spawned_slots']+counts['not_started']==248
    for key in KEYS:assert summary[key]==audit[key],key
    assert summary['independent_audit_sha256']==audit_sha
    assert truth==reference_from_audit(audit,audit_sha)
    assert summary['new_optimization_calls']==audit['new_optimization_calls_in_saved_audit']==0
    assert len(summary['author_diagnostics'])==124
    for row,item in zip(audit['fields'],summary['author_diagnostics']):
        assert item['instance_id']==row['instance_id'] and item['eligible_for_primary']==row['valid_for_exact_conclusion']
        objectives=row['objectives'];eg,ge=objectives['E_G'],objectives['G_E']
        assert row['valid_for_exact_conclusion']==(eg['verified']and ge['verified'])
        assert row['E_star']==(eg['E']if eg['verified']else None)
        assert row['G_star']==(ge['G']if ge['verified']else None)
        for target in (eg,ge):
            if target['verified']:
                assert target['failure']is None and type(target['E'])is int and type(target['G'])is int
            else:
                assert all(target[k]is None for k in ('E','G','partition','canonical_routes'))
        if not row['valid_for_exact_conclusion']:
            assert row['delta_integer_mm']is None
            assert set(item)=={'instance_id','eligible_for_primary'}
            continue
        assert row['delta_integer_mm']==eg['G']-ge['G']>=0
        assert item['delta_integer_mm']==row['delta_integer_mm']
        assert item['order_loss_integer_mm']==row['order_loss_integer_mm']>=0
        assert item['partition_loss_integer_mm']==row['partition_loss_integer_mm']>=0
        assert row['delta_integer_mm']==row['order_loss_integer_mm']+row['partition_loss_integer_mm']
        assert item['fixed_selected_partition_G_integer_mm']==row['fixed_partition_G']
        assert item['relative_integer_percent']==(100*row['delta_integer_mm']/row['G_star']if row['G_star']else None)
        assert item['same_selected_partition']==(eg['partition']==ge['partition'])
        for key,target in [('E_G',eg),('G_E',ge)]:
            assert item[key]=={'E':target['E'],'G':target['G'],'partition':target['partition'],'routes':target['canonical_routes']}
        assert item['representative_realized_G_lengths_m_decimal80']==row['actual_path_lengths_m']
        assert item['representative_realized_difference_m_decimal80']==row['actual_path_length_difference_m']
    values=[r['delta_integer_mm']for r in audit['fields']if r['valid_for_exact_conclusion']]
    assert audit['complete_panel_mean_delta_integer_mm']==(sum(values)/124 if len(values)==124 else None)
    assert audit['complete_case_mean_delta_integer_mm']==(sum(values)/len(values)if values else None)
    return True


def main():
    assert __debug__
    resource.setrlimit(resource.RLIMIT_CPU,(15,15));resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912));signal.alarm(60)
    started=time.monotonic();cpu=time.process_time();digest=frozen();parent=parent_ready()
    main_raw=receipt(ROOT/'provenance/RAW_MAIN_DRIVE_RECEIPT.json','RAW_MAIN',digest)
    ind_raw=receipt(ROOT/'provenance/RAW_VERIFICATION_DRIVE_RECEIPT.json','RAW_VERIFICATION',digest)
    path=ROOT/'independent_supervision/FINAL_AUDIT.json';audit=read(path);audit_sha=sha(path)
    summary=read(ROOT/'reports/SUMMARY.json');truth=read(ROOT/'truth/EXACT_REFERENCE.json')
    assert audit['frozen_files_sha256']==digest and audit['input_final_archive_sha256']==parent['sha256']
    assert audit['raw_main_archive_sha256']==main_raw['sha256'] and audit['raw_verification_archive_sha256']==ind_raw['sha256']
    assert [r['instance_id']for r in audit['fields']]==read(ROOT/'freeze/PROTOCOL.json')['fields']
    compare(audit,summary,truth,audit_sha)
    assert summary['truth_sha256']==sha(ROOT/'truth/EXACT_REFERENCE.json')
    result={'status':'PASS','utc':utc(),'frozen_files_sha256':digest,
        'input_final_archive_sha256':parent['sha256'],'raw_main_archive_sha256':main_raw['sha256'],
        'raw_verification_archive_sha256':ind_raw['sha256'],'report_sha256':sha(ROOT/'reports/REPORT_ZH.txt'),
        'summary_sha256':sha(ROOT/'reports/SUMMARY.json'),'truth_sha256':sha(ROOT/'truth/EXACT_REFERENCE.json'),
        'independent_audit_sha256':audit_sha,'planned_fields':124,'verified_fields':audit['verified_fields'],
        'verified_objective_slots':audit['verified_objective_slots'],'main_counts':audit['main_counts'],
        'independent_counts':audit['independent_counts'],'new_optimization_calls':0,
        'reader_review_method':'Direct semantic reading of actual report separately; no keyword gate.',
        'resources':{'cpu_seconds':time.process_time()-cpu,'wall_seconds':time.monotonic()-started}}
    save(ROOT/'independent_supervision/FINAL_REPORT_REVIEW.json',result);print(json.dumps(result))


if __name__=='__main__':main()
