"""Preparation-only reader identity check, no solve imports or objective evaluation."""
import pathlib,sys,resource,signal,json,time,hashlib,datetime
ROOT=pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'source'))
from inputs import load_input as author_input
from read_input import load_input as independent_input


def main():
    resource.setrlimit(resource.RLIMIT_CPU,(60,60));resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912));signal.alarm(120)
    start=time.monotonic();cpu=time.process_time()
    assert not (ROOT/'provenance/MAIN_LAUNCH_STARTED.json').exists()
    assert not (ROOT/'provenance/VALIDATION_LAUNCH_STARTED.json').exists()
    fields=json.loads((ROOT/'freeze/PROTOCOL.json').read_text())['fields'];assert len(fields)==124
    rows=[]
    for field in fields:
        a,ai=author_input(field);b,bi=independent_input(field)
        assert a==b and ai==bi
        rows.append({'instance_id':field,'preprocess_sha256':ai['preprocess_sha256'],
                     'matrix_canonical_json_sha256':ai['selected_matrix_canonical_json_sha256']})
    out={'status':'PASS','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fields_checked':124,
         'rows':rows,'new_optimization_calls':0,'new_native_calls':0,'new_synthetic_objective_calls':0,
         'scope':'Byte/model/numerical-admission identity only; no route objective computed or searched.',
         'author_reader_sha256':hashlib.sha256((ROOT/'source/inputs.py').read_bytes()).hexdigest(),
         'independent_reader_sha256':hashlib.sha256((ROOT/'independent_supervision/source/read_input.py').read_bytes()).hexdigest(),
         'cpu_seconds':time.process_time()-cpu,'wall_seconds':time.monotonic()-start}
    target=ROOT/'independent_supervision/preparation/INPUT_READER_IDENTITY.json'
    with target.open('x')as f:json.dump(out,f,ensure_ascii=False,indent=2)
    print(json.dumps({k:v for k,v in out.items()if k!='rows'}))


if __name__=='__main__':main()
