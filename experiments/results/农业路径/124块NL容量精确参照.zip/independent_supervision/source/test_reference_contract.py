"""Invented JSON contract replay only; no matrix, route search, or solve import."""
import pathlib,sys,copy,json,resource,signal
ROOT=pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'source'))
from report import make_reference
from saved_audit import reference_from_audit
from review_final import compare,KEYS


def fixture(mode):
    fields=[];rows=[];diagnostics=[]
    for i in range(124):
        fid='INVENTED_FIELD_'+str(i);objectives={}
        for arm in ('E_G','G_E'):
            verified=(mode=='partial'and i==0 and arm=='E_G')or(mode=='both'and i==0)
            e,g=(10,20)if arm=='E_G'else(12,15)
            partition=[[1,2,3,4],[5,6,7,8],[9,10,11,12]]
            routes=[[0]+x+[0]for x in partition]
            objectives[arm]={'verified':verified,'failure':None if verified else 'INVENTED_NOT_STARTED',
                'E':e if verified else None,'G':g if verified else None,'partition':partition if verified else None,
                'canonical_routes':routes if verified else None,
                'main_stdout_sha256':'a'*64 if verified else None,'independent_stdout_sha256':'b'*64 if verified else None}
            rows.append({'call_id':fid+'_'+arm,'instance_id':fid,'objective':arm,'valid_for_exact_conclusion':verified})
        eg,ge=objectives['E_G'],objectives['G_E'];both=eg['verified']and ge['verified']
        f={'instance_id':fid,'preprocess_sha256':'c'*64,'objectives':objectives,'E_star':eg['E']if eg['verified']else None,
            'G_star':ge['G']if ge['verified']else None,'valid_for_exact_conclusion':both,
            'delta_integer_mm':5 if both else None,'order_loss_integer_mm':2 if both else None,'partition_loss_integer_mm':3 if both else None}
        diag={'instance_id':fid,'eligible_for_primary':both}
        if both:
            f.update(fixed_partition_G=18,actual_path_lengths_m=['0.020','0.015'],actual_path_length_difference_m='0.005')
            diag.update(delta_integer_mm=5,order_loss_integer_mm=2,partition_loss_integer_mm=3,
                fixed_selected_partition_G_integer_mm=18,relative_integer_percent=100*5/15,same_selected_partition=True,
                E_G={'E':eg['E'],'G':eg['G'],'partition':eg['partition'],'routes':eg['canonical_routes']},
                G_E={'E':ge['E'],'G':ge['G'],'partition':ge['partition'],'routes':ge['canonical_routes']},
                representative_realized_G_lengths_m_decimal80=['0.020','0.015'],representative_realized_difference_m_decimal80='0.005')
        fields.append(f);diagnostics.append(diag)
    valid=sum(f['valid_for_exact_conclusion']for f in fields)
    a={k:'d'*64 for k in ('frozen_files_sha256','raw_main_archive_sha256','raw_verification_archive_sha256','input_final_archive_sha256','input_final_frozen_files_sha256')}
    a.update(status='AUDIT_COMPLETE_WITH_UNVERIFIED_SLOTS',input_final_actual_readback=True,raw_main_actual_readback=True,
        raw_verification_actual_readback=True,planned_fields=124,planned_main_calls=248,planned_independent_calls=248,
        planned_total_objective_slots=496,fields=fields,rows=rows,eligible_instance_ids=[f['instance_id']for f in fields if f['valid_for_exact_conclusion']],
        verified_fields=valid,verified_objective_slots=sum(r['valid_for_exact_conclusion']for r in rows),ledger_errors=[],
        complete_panel_mean_delta_integer_mm=None,complete_case_mean_delta_integer_mm=5.0 if valid else None,new_optimization_calls_in_saved_audit=0)
    for side in ('main_counts','independent_counts'):
        a[side]={'planned':248,'retained':248,'known_spawned':0,'unknown_spawned_slots':0,'not_started':248}
    s={k:copy.deepcopy(a[k])for k in KEYS};s.update(independent_audit_sha256='e'*64,new_optimization_calls=0,author_diagnostics=diagnostics)
    return a,s


def main():
    resource.setrlimit(resource.RLIMIT_CPU,(15,15));resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912));signal.alarm(60)
    results=[]
    for mode in ('none','partial','both'):
        a,s=fixture(mode);truth=make_reference(a,'e'*64)
        assert truth==reference_from_audit(a,'e'*64) and compare(a,s,truth,'e'*64)
        assert len(truth['fields'])==124 and len(truth['objective_slots'])==248
        results.append({'case':mode,'status':'PASS'})
    a,s=fixture('partial')
    assert a['fields'][0]['E_star']==10 and a['fields'][0]['G_star']is None and a['fields'][0]['delta_integer_mm']is None
    bad=copy.deepcopy(a);bad['fields'][0]['objectives']['G_E']['E']=1
    try:make_reference(bad,'e'*64)
    except ValueError:results.append({'case':'unverified_value_rejected','status':'PASS'})
    else:raise AssertionError('Unverified target gained a value')
    truth=make_reference(a,'e'*64);truth['fields'][0]['E_star']=11
    try:compare(a,s,truth,'e'*64)
    except AssertionError:results.append({'case':'truth_mismatch_rejected','status':'PASS'})
    else:raise AssertionError('Changed reference passed')
    s['complete_panel_mean_delta_integer_mm']=0
    try:compare(a,s,make_reference(a,'e'*64),'e'*64)
    except AssertionError:results.append({'case':'partial_full_panel_mean_rejected','status':'PASS'})
    else:raise AssertionError('Missing fields treated as zero')
    result={'status':'PASS','fixture_scope':'INVENTED_JSON_SCHEMA_ONLY_NOT_PROCESS_OR_SOLVER_RESULTS','tests':results,
        'new_optimization_calls':0,'new_native_calls':0,'new_synthetic_objective_calls':0}
    with (ROOT/'independent_supervision/preparation/REFERENCE_CONTRACT.json').open('x')as f:json.dump(result,f,indent=2)
    print(json.dumps(result))


if __name__=='__main__':main()
