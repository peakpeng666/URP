"""Saved248+248 exact evidence audit; no optimizer imports or new route selection."""
import pathlib,sys,json,hashlib,itertools,zipfile,decimal,time,resource,signal
ROOT=pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'source'))
from common import read,save,sha,utc,verify_map
from gates import frozen,receipt,parent_ready
from read_input import load_input
D=decimal.Decimal

def check_payload(row,matrices,identity,slot,digest):
    assert isinstance(row,dict) and row['status']=='PROCESS_SUCCESS_UNREVIEWED'
    assert row['instance_id']==slot['instance_id'] and row['objective']==slot['objective']
    assert row['frozen_files_sha256']==digest and row['n']==12 and row['Q']==5 and row['K']==3
    assert row['input_matrices']==matrices
    assert all(row['input_identity'][k]==v for k,v in identity.items())
    def check_route(route,customers):
        assert route[0]==route[-1]==0 and len(route)==len(customers)+2
        assert all(type(x) is int for x in route) and sorted(route[1:-1])==customers
        assert tuple(route[1:-1])<=tuple(reversed(route[1:-1]))
        return tuple(sum(matrices[k][a][b] for a,b in zip(route,route[1:])) for k in ('E','G'))
    expected={sum(1<<(x-1) for x in group) for size in range(2,6) for group in itertools.combinations(range(1,13),size)}
    local={}
    assert len(row['local_routes'])==1573
    for r in row['local_routes']:
        mask=r['mask'];assert type(mask) is int and mask in expected and mask not in local
        customers=[i for i in range(1,13) if mask>>(i-1)&1]
        assert r['customers']==customers and 2<=len(customers)<=5
        assert all(type(r[k]) is int for k in ('E','G'))
        assert check_route(r['route'],customers)==(r['E'],r['G'])
        local[mask]=r
    assert set(local)==expected
    partition=row['partition'];assert len(partition)==len(row['routes'])==3
    assert partition==sorted(partition) and all(g==sorted(g) and 2<=len(g)<=5 for g in partition)
    assert sorted(x for group in partition for x in group)==list(range(1,13))
    totals=[0,0]
    for group,route in zip(partition,row['routes']):
        mask=sum(1<<(x-1) for x in group)
        assert local[mask]['route']==route
        ev,gv=check_route(route,group);totals[0]+=ev;totals[1]+=gv
    assert totals==[row['E'],row['G']] and all(type(row[k]) is int for k in ('E','G'))
    return local

def raw_check(base,manifest_name,archived,digest):
    manifest=read(base/manifest_name);assert manifest['frozen_files_sha256']==digest
    verify_map(ROOT,manifest['files'])
    with zipfile.ZipFile(archived['download_path']) as z:
        for rel,r in manifest['files'].items():
            b=z.read(rel);assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256']
        rel=str((base/manifest_name).relative_to(ROOT));assert z.read(rel)==(base/manifest_name).read_bytes()
    return len(manifest['files'])


def check_ledger(base, schedule):
    rows = read(base/'ALL_PLANNED_SLOTS.json')
    assert len(rows) == len(schedule) == 248 and [r['schedule'] for r in rows] == schedule
    outer = read(base/'OUTER_FINISHED.json')
    errors = []
    if outer['duplicate_call_ids'] or outer['malformed_rows']:
        errors.append('LEDGER_DUPLICATE_OR_MALFORMED')
    outer_process = outer['outer']
    if outer_process.get('process_spawned') and not (outer_process.get('registered_group_cleanup') or {}).get('quiescent'):
        errors.append('OUTER_NOT_QUIESCENT')
    return rows, {'planned': 248, 'known_spawned': sum(r.get('process_spawned') is True for r in rows),
                  'unknown_spawned_slots': sum(r.get('process_spawned') not in (True, False) for r in rows),
                  'not_started': sum(r.get('process_spawned') is False for r in rows), 'retained': len(rows)}, errors


def check_process(record):
    assert record.get('status') == 'UNREVIEWED_PROCESS_SUCCESS' and not record.get('error')
    assert record.get('process_spawned') is True and record.get('returncode') == 0 and record.get('child_reaped') is True
    assert not record.get('wall_timeout') and (record.get('registered_group_cleanup') or {}).get('quiescent') is True
    assert record['configured_cpu_seconds'] == 15 and record['configured_as_bytes'] == 268435456
    assert 0 < record['configured_wall_seconds'] <= 30
    assert record['started_utc'] <= record['reaped_utc'] <= record['finished_utc']
    for stream in ('stdout', 'stderr'):
        assert sha(record[stream]) == record[stream+'_sha256']


def compact(row):
    return {key: row[key] for key in ('E', 'G', 'partition', 'routes')}


def audit():
    digest = frozen()
    input_receipt = parent_ready()
    main_receipt = receipt(ROOT/'provenance/RAW_MAIN_DRIVE_RECEIPT.json', 'RAW_MAIN', digest)
    verify_receipt = receipt(ROOT/'provenance/RAW_VERIFICATION_DRIVE_RECEIPT.json', 'RAW_VERIFICATION', digest)
    counts = [raw_check(ROOT/'raw', 'RAW_MAIN_CONTENT_MANIFEST.json', main_receipt, digest),
              raw_check(ROOT/'independent_supervision/raw', 'RAW_VERIFICATION_CONTENT_MANIFEST.json', verify_receipt, digest)]
    schedule = read(ROOT/'freeze/SCHEDULE.json')
    fields_order = read(ROOT/'freeze/PROTOCOL.json')['fields']
    selected_members = read(ROOT/'input/PARENT_MEMBER_IDENTITIES.json')['selected_members']
    assert len(fields_order) == len(set(fields_order)) == 124
    assert len(schedule) == len({s['call_id'] for s in schedule}) == 248
    assert [(s['instance_id'], s['objective']) for s in schedule] == [(f, arm) for f in fields_order for arm in ('E_G', 'G_E')]
    main_ledger, main_counts, errors = check_ledger(ROOT/'raw', schedule)
    ind_ledger, ind_counts, more_errors = check_ledger(ROOT/'independent_supervision/raw', schedule)
    errors += more_errors
    rows, fields, eligible = [], [], []
    # Only the current field's local tables are live. Retain compact witnesses,
    # so the124-field expansion does not scale memory with248 local route tables.
    with decimal.localcontext() as ctx, zipfile.ZipFile(ROOT/'input/PARENT_FINAL.zip') as parent:
        ctx.prec = 80
        for field_index, field in enumerate(fields_order):
            payloads, field_rows = {}, []
            matrices = identity = None
            input_error = None
            try:
                matrices, identity = load_input(field)
            except (AssertionError, KeyError, TypeError, ValueError, OSError, IndexError) as exc:
                input_error = type(exc).__name__+':'+str(exc)
            fixed_partition_G = None
            for offset, objective in enumerate(('E_G', 'G_E')):
                index = 2*field_index+offset
                slot = schedule[index]; cid = slot['call_id']
                result = {'call_id': cid, 'instance_id': field, 'objective': objective,
                          'valid_for_exact_conclusion': False, 'main_E': None, 'main_G': None,
                          'independent_E': None, 'independent_G': None, 'failure': None,
                          'main_stdout_sha256': None, 'independent_stdout_sha256': None}
                try:
                    assert not errors, errors
                    assert input_error is None, input_error
                    for record in (main_ledger[index], ind_ledger[index]):
                        check_process(record)
                    apath = ROOT/'raw/calls'/(cid+'.stdout')
                    bpath = ROOT/'independent_supervision/raw/calls'/(cid+'.stdout')
                    a, b = read(apath), read(bpath)
                    al = check_payload(a, matrices, identity, slot, digest)
                    bl = check_payload(b, matrices, identity, slot, digest)
                    assert compact(a) == compact(b) and al == bl
                    assert a['counters']['local_route_evaluations'] == 54186
                    assert a['counters']['unlabeled_partition_evaluations'] == 41811
                    assert b['counters']['HK_states'] == 6744 and b['counters']['HK_internal_transitions'] == 23232
                    assert b['counters']['assignment_candidate_transitions'] == 252439
                    primary, secondary = ('E', 'G') if objective == 'E_G' else ('G', 'E')
                    pmax, smax = max(map(max, matrices[primary])), max(map(max, matrices[secondary]))
                    multiplier = 15*smax+1; upper = 15*pmax*multiplier+15*smax
                    scalar = b['scalarization']
                    assert scalar['M'] == multiplier and scalar['secondary_total_upper_bound'] == multiplier-1
                    assert scalar['primary_max_edge'] == pmax and scalar['secondary_max_edge'] == smax
                    assert scalar['scalar_upper_bound'] == upper < 2**63-1 and scalar['complete_route_legs'] == 15
                    payloads[objective] = compact(a)
                    if objective == 'G_E' and 'E_G' in payloads:
                        fixed_partition_G = sum(al[sum(1 << (x-1) for x in group)]['G'] for group in payloads['E_G']['partition'])
                    result.update(valid_for_exact_conclusion=True, main_E=a['E'], main_G=a['G'],
                                  independent_E=b['E'], independent_G=b['G'],
                                  main_stdout_sha256=sha(apath), independent_stdout_sha256=sha(bpath))
                    del a, b, al, bl
                except (AssertionError, KeyError, TypeError, ValueError, OSError, IndexError) as exc:
                    payloads.pop(objective, None)
                    result['failure'] = type(exc).__name__+':'+str(exc)
                rows.append(result); field_rows.append(result)
            data = {'instance_id': field, 'valid_for_exact_conclusion': False,
                    'preprocess_sha256': selected_members[f'raw/fields/{field}/preprocess.json']['sha256'],
                    'input_identity': identity, 'objectives': {},
                    'E_star': payloads.get('E_G', {}).get('E'), 'G_star': payloads.get('G_E', {}).get('G'),
                    'delta_integer_mm': None, 'order_loss_integer_mm': None, 'partition_loss_integer_mm': None,
                    'failure': input_error}
            for objective, result in zip(('E_G', 'G_E'), field_rows):
                witness = payloads.get(objective)
                data['objectives'][objective] = {'verified': result['valid_for_exact_conclusion'],
                    'failure': result['failure'], 'E': witness['E'] if witness else None,
                    'G': witness['G'] if witness else None, 'partition': witness['partition'] if witness else None,
                    'canonical_routes': witness['routes'] if witness else None,
                    'main_stdout_sha256': result['main_stdout_sha256'], 'independent_stdout_sha256': result['independent_stdout_sha256']}
            if all(arm in payloads for arm in ('E_G', 'G_E')):
                a, b = payloads['E_G'], payloads['G_E']
                delta = a['G']-b['G']; order = a['G']-fixed_partition_G; partition = fixed_partition_G-b['G']
                assert min(delta, order, partition) >= 0 and delta == order+partition
                pre = json.loads(parent.read(f'raw/fields/{field}/preprocess.json'))
                pair_lengths = {tuple(sorted(r['pair'])): D(r['decimal80_path_length_m']) for r in pre['pair_checks']}
                lengths = []
                for plan in (a, b):
                    total = D(0)
                    for route in plan['routes']:
                        for i, j in zip(route, route[1:]):
                            length = pair_lengths[tuple(sorted((i, j)))]; total += length
                            assert abs(length-D(matrices['G'][i][j])/1000) <= D('0.00050001')
                    lengths.append(total)
                difference = lengths[0]-lengths[1]
                assert abs(difference-D(delta)/1000) <= D('0.01500030')
                data.update(valid_for_exact_conclusion=True, delta_integer_mm=delta,
                    order_loss_integer_mm=order, partition_loss_integer_mm=partition, fixed_partition_G=fixed_partition_G,
                    G_at_E_optimum=a['G'], E_at_G_optimum=b['E'], E_G_partition=a['partition'], G_E_partition=b['partition'],
                    actual_path_lengths_m=[str(value) for value in lengths], actual_path_length_difference_m=str(difference),
                    two_plan_rounding_plus_saved_path_tolerance_m='0.01500030')
                eligible.append(field)
            elif data['failure'] is None:
                data['failure'] = 'ONE_OR_MORE_OBJECTIVES_UNVERIFIED'
            fields.append(data)
    deltas = [r['delta_integer_mm'] for r in fields if r['valid_for_exact_conclusion']]
    return {'status': 'PASS' if len(eligible) == 124 else 'AUDIT_COMPLETE_WITH_UNVERIFIED_SLOTS',
        'frozen_files_sha256': digest, 'raw_main_archive_sha256': main_receipt['sha256'],
        'raw_verification_archive_sha256': verify_receipt['sha256'],
        'input_final_archive_sha256': read(ROOT/'freeze/PROTOCOL.json')['costs']['source_archive_sha256'],
        'input_final_frozen_files_sha256': input_receipt['frozen_files_sha256'],
        'input_final_actual_readback': True, 'raw_main_actual_readback': True, 'raw_verification_actual_readback': True,
        'planned_fields': 124, 'planned_main_calls': 248, 'planned_independent_calls': 248,
        'planned_total_objective_slots': 496, 'main_counts': main_counts, 'independent_counts': ind_counts,
        'ledger_errors': errors, 'rows': rows, 'fields': fields, 'eligible_instance_ids': eligible,
        'verified_fields': len(eligible), 'verified_objective_slots': sum(r['valid_for_exact_conclusion'] for r in rows),
        'raw_members_checked': counts, 'complete_panel_mean_delta_integer_mm': sum(deltas)/124 if len(deltas) == 124 else None,
        'complete_case_mean_delta_integer_mm': sum(deltas)/len(deltas) if deltas else None,
        'new_optimization_calls_in_saved_audit': 0}


def reference_from_audit(audit_result, audit_sha):
    fields = [{'instance_id': row['instance_id'], 'input_preprocess_sha256': row['preprocess_sha256'],
               'objectives': row['objectives'], 'E_star': row['E_star'], 'G_star': row['G_star'],
               'delta_integer_mm': row['delta_integer_mm'],
               'valid_for_exact_conclusion': row['valid_for_exact_conclusion']} for row in audit_result['fields']]
    return {'status': 'EXACT_REFERENCE_AUDITED', 'independent_audit_sha256': audit_sha,
        'frozen_files_sha256': audit_result['frozen_files_sha256'],
        'raw_main_archive_sha256': audit_result['raw_main_archive_sha256'],
        'raw_verification_archive_sha256': audit_result['raw_verification_archive_sha256'],
        'input_final_archive_sha256': audit_result['input_final_archive_sha256'],
        'input_final_frozen_files_sha256': audit_result['input_final_frozen_files_sha256'],
        'input_final_actual_readback': audit_result['input_final_actual_readback'],
        'raw_main_actual_readback': audit_result['raw_main_actual_readback'],
        'raw_verification_actual_readback': audit_result['raw_verification_actual_readback'],
        'planned_fields': 124, 'planned_main_calls': 248, 'planned_independent_calls': 248,
        'planned_total_objective_slots': 496, 'main_counts': audit_result['main_counts'],
        'independent_counts': audit_result['independent_counts'], 'fields': fields,
        'objective_slots': audit_result['rows'], 'eligible_instance_ids': audit_result['eligible_instance_ids'],
        'verified_fields': audit_result['verified_fields'], 'verified_objective_slots': audit_result['verified_objective_slots'],
        'new_optimization_calls_in_derivation': 0,
        'scope': 'Saved independently matched exact references. Partial objective validity is explicit; input for analysis only, never native worker.'}


def main():
    assert __debug__
    resource.setrlimit(resource.RLIMIT_CPU, (60, 60))
    resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912)); signal.alarm(120)
    started = time.monotonic()
    save(ROOT/'independent_supervision/SAVED_AUDIT_STARTED.json', {'utc': utc(), 'new_optimization_calls': 0})
    out = audit(); usage = resource.getrusage(resource.RUSAGE_SELF)
    out.update(utc=utc(), cpu_seconds=usage.ru_utime+usage.ru_stime,
               wall_seconds=time.monotonic()-started, peak_rss_kib=usage.ru_maxrss)
    target = ROOT/'independent_supervision/FINAL_AUDIT.json'; save(target, out)
    print(json.dumps({'status': out['status'], 'verified_fields': out['verified_fields'],
                      'verified_objective_slots': out['verified_objective_slots']}))


if __name__ == '__main__':
    main()

