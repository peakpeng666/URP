import itertools, random, time, json, pathlib, resource
from subset_dp import solve
ROOT=pathlib.Path(__file__).resolve().parents[2]

def brute(E,G,Q,K,obj):
    n=len(E)-1; best=None
    for sizes in itertools.product(range(1,Q+1),repeat=K):
        if sum(sizes)!=n: continue
        for order in itertools.permutations(range(1,n+1)):
            groups=[]; offset=0
            for size in sizes:
                r=order[offset:offset+size];offset+=size
                r=min(r,r[::-1]);groups.append((tuple(sorted(r)),r))
            groups.sort();p=tuple(x[0] for x in groups);routes=tuple(x[1] for x in groups)
            ev=gv=0
            for r in routes:
                closed=(0,)+r+(0,)
                ev+=sum(E[a][b] for a,b in zip(closed,closed[1:]))
                gv+=sum(G[a][b] for a,b in zip(closed,closed[1:]))
            key=((ev,gv) if obj=='E_G' else (gv,ev))+(p,routes)
            if best is None or key<best[0]:best=key,ev,gv,p,routes
    return best

def main():
    started=time.monotonic();tests=[];calls=0
    for case,(n,Q,K) in enumerate(((3,2,2),(6,3,3),(6,3,2),(4,4,1))):
        rng=random.Random(702+case);matrices=[]
        for arm in range(2):
            a=[[0]*(n+1) for _ in range(n+1)]
            for i in range(n+1):
                for j in range(i):a[i][j]=a[j][i]=rng.randrange(0,8)
            matrices.append(a)
        for obj in ('E_G','G_E'):
            result=solve(*matrices,Q,K,obj);calls+=1
            oracle=brute(*matrices,Q,K,obj)
            assert (result['E'],result['G'],tuple(map(tuple,result['partition'])),tuple(tuple(r[1:-1]) for r in result['routes']))==oracle[1:]
            tests.append({'case':case,'objective':obj,'status':'PASS_BRUTE_FORCE_GLOBAL_VALUE_AND_CANONICAL_WITNESS'})
    n=12;a=[[0 if i==j else 1 for j in range(13)] for i in range(13)]
    for obj in ('E_G','G_E'):
        result=solve(a,a,5,3,obj,394480);calls+=1
        assert result['E']==result['G']==15
        assert result['partition']==[[1,2],[3,4,5,6,7],[8,9,10,11,12]]
        assert result['counters']=={'HK_states':6744,'HK_masks':1585,'HK_internal_transitions':23232,'local_subsets':1573,'assignment_candidate_transitions':252439,'assignment_candidates_by_stage':{'2':250866,'3':1573}}
        assert result['scalarization']['M']==5917201 and result['scalarization']['scalar_upper_bound']==35013267674400
        for r in result['local_routes']:
            assert r['route']==[0]+r['customers']+[0]
        tests.append({'case':'n12_complete_tie','objective':obj,'status':'PASS_COUNTS_AND_CANONICAL_WITNESSES'})
    usage=resource.getrusage(resource.RUSAGE_SELF)
    out={'status':'PASS','invented_only':True,'new_synthetic_objective_calls':calls,'real_objective_calls':0,'tests':tests,'wall_seconds':time.monotonic()-started,'cpu_seconds':usage.ru_utime+usage.ru_stime,'peak_rss_kib':usage.ru_maxrss}
    print(json.dumps(out,indent=2))
if __name__=='__main__':main()
