"""Independent forward truncated HK and labelled vehicle assignment DP.

No author solver, enumeration, or input-reader imports. Both values and canonical
witnesses are retained during this declared optimization call.
"""

def solve(E, G, Q, K, objective, edge_ceiling=None):
    n = len(E) - 1
    assert 1 <= n <= 12 and 1 <= Q <= 5 and 1 <= K <= 3 and K <= n <= K * Q
    assert objective in ('E_G', 'G_E')
    for a in (E, G):
        assert len(a) == n + 1 and all(len(r) == n + 1 for r in a)
        assert all(type(a[i][j]) is int and a[i][j] >= 0 and a[i][j] == a[j][i]
                   and (i != j or a[i][j] == 0) for i in range(n + 1) for j in range(n + 1))
    p, s = (E, G) if objective == 'E_G' else (G, E)
    ceiling = max(max(r) for a in (E, G) for r in a) if edge_ceiling is None else edge_ceiling
    assert type(ceiling) is int and ceiling >= 0 and all(v <= ceiling for a in (E, G) for r in a for v in r)
    legs = n + K
    M = legs * ceiling + 1
    bound = legs * ceiling * (M + 1)
    assert bound < 2**63 - 1
    cost = [[p[i][j] * M + s[i][j] for j in range(n + 1)] for i in range(n + 1)]
    # A state is (visited mask,last); the base-16 code breaks equal-cost
    # prefix ties lexicographically. Compared prefixes have equal length.
    full = (1 << n) - 1
    states = {1 << (j - 1): {j: (cost[0][j], j)} for j in range(1, n + 1)}
    transitions = 0
    for size in range(1, min(Q, n)):
        for mask in [m for m in states if m.bit_count() == size]:
            available = full ^ mask
            for last, (value, code) in list(states[mask].items()):
                todo = available
                while todo:
                    bit = todo & -todo; todo -= bit
                    nxt = bit.bit_length()
                    target = states.setdefault(mask | bit, {})
                    candidate = (value + cost[last][nxt], code * 16 + nxt)
                    transitions += 1
                    if nxt not in target or candidate < target[nxt]:
                        target[nxt] = candidate
    minimum = max(1, n - (K - 1) * Q)
    local = {}
    for mask, endpoint_states in states.items():
        if mask.bit_count() < minimum:
            continue
        value, code = min((v + cost[last][0], c) for last, (v, c) in endpoint_states.items())
        order = []
        for _ in range(mask.bit_count()):
            order.append(code % 16); code //= 16
        order.reverse()
        assert tuple(order) <= tuple(reversed(order))
        route = [0] + order + [0]
        ev = sum(E[a][b] for a,b in zip(route, route[1:]))
        gv = sum(G[a][b] for a,b in zip(route, route[1:]))
        assert value == (ev * M + gv if objective == 'E_G' else gv * M + ev)
        local[mask] = {'mask': mask, 'customers': [j for j in range(1,n+1) if mask >> (j-1) & 1],
                       'route': route, 'E': ev, 'G': gv, 'scalar': value}
    # Vehicle labels distinguish the recurrence transitions. The stored witness
    # is sorted solely to implement the predeclared unlabeled partition tie.
    previous = {m: (r['scalar'], (tuple(r['customers']),)) for m,r in local.items()}
    assignment_by_stage = {}
    for used in range(2, K + 1):
        current = {}; count = 0
        for mask in range(1, full + 1):
            size = mask.bit_count(); remaining = n - size
            if not (used * minimum <= size <= used * Q and (K-used)*minimum <= remaining <= (K-used)*Q):
                continue
            sub = mask
            while sub:
                rest = mask ^ sub
                if sub in local and rest in previous:
                    count += 1
                    old = previous[rest]
                    groups = tuple(sorted(old[1] + (tuple(local[sub]['customers']),)))
                    candidate = old[0] + local[sub]['scalar'], groups
                    if mask not in current or candidate < current[mask]:
                        current[mask] = candidate
                sub = (sub - 1) & mask
        assignment_by_stage[str(used)] = count
        previous = current
    value, partition = previous[full]
    rows = [local[sum(1 << (x-1) for x in group)] for group in partition]
    ev, gv = sum(r['E'] for r in rows), sum(r['G'] for r in rows)
    assert value == (ev*M+gv if objective == 'E_G' else gv*M+ev)
    return {'objective': objective, 'n': n, 'Q': Q, 'K': K, 'E': ev, 'G': gv,
            'partition': [list(g) for g in partition], 'routes': [r['route'] for r in rows],
            'local_routes': [{k:v for k,v in local[m].items() if k != 'scalar'} for m in sorted(local)],
            'counters': {'HK_states': sum(map(len,states.values())), 'HK_masks': len(states),
                         'HK_internal_transitions': transitions, 'local_subsets': len(local),
                         'assignment_candidate_transitions': sum(assignment_by_stage.values()),
                         'assignment_candidates_by_stage': assignment_by_stage},
            'scalarization': {'M': M, 'max_edge': ceiling, 'complete_route_legs': legs,
                              'secondary_total_upper_bound': M-1, 'scalar_upper_bound': bound,
                              'arithmetic': 'Python exact integers; independently checked signed-int64 bound; no INF sentinel'}}
