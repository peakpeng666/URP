#!/usr/bin/python3
import pathlib,json,hashlib,datetime,zipfile,sys
R=pathlib.Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,x):
    with (R/n).open('x') as f:json.dump(x,f,indent=2,ensure_ascii=False);f.write('\n')
stage=sys.argv[1]
if stage=='PREEXECUTION':
    assert not list((R/'raw').iterdir()) and not (R/'evidence/STARTED.json').exists()
    review=json.loads((R/'independent_review/STATIC_PREEXEC_REVIEW.json').read_text())
    assert review['status']=='PASS_STATIC_PREEXEC_REVIEW'
    required={str(f.relative_to(R)) for sub in ['source','input','freeze'] for f in (R/sub).rglob('*') if f.is_file() and '__pycache__' not in str(f) and f.name!='PREEXECUTION_FREEZE.json'}
    assert required<=set(review['reviewed_files']), 'Pre-review lacks source/input/protocol binding'
    for name,h in review['reviewed_files'].items():assert sha(R/name)==h, 'Post-review change: '+name
    for name,v in json.loads((R/'freeze/INPUT_IDENTITY.json').read_text()).items():assert sha(R/name)==v['sha256'] and (R/name).read_bytes()==pathlib.Path(v['source_path']).read_bytes()
    save('freeze/PREEXECUTION_FREEZE.json',{'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'formal_candidates_not_generated':True,'files':{str(p.relative_to(R)):sha(p) for p in sorted(R.rglob('*')) if p.is_file() and '__pycache__' not in str(p)}})
    suffix='PREEXECUTION_SNAPSHOT'
elif stage=='RAW':
    assert (R/'evidence/RUN_STATUS.json').is_file()
    save('evidence/RAW_COMPLETE_UNAUDITED_MANIFEST.json',{'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'RAW_UNAUDITED','files':{str(p.relative_to(R)):sha(p) for p in sorted(R.rglob('*')) if p.is_file() and '__pycache__' not in str(p)}})
    suffix='RAW_COMPLETE_UNAUDITED'
else:raise ValueError(stage)
z=R.parent/(R.name+'_'+suffix+'.zip')
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED) as f:
    for p in sorted(R.rglob('*')):
        if p.is_file() and '__pycache__' not in str(p):f.write(p,p.relative_to(R.parent))
print(json.dumps({'path':str(z),'sha256':sha(z),'bytes':z.stat().st_size,'freeze_sha256':sha(R/'freeze/PREEXECUTION_FREEZE.json')}))
