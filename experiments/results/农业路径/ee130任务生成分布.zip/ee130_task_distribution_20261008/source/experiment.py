#!/usr/bin/python3
"""Unique frozen experiment; no network, model, installations or selection after results."""
from fractions import Fraction
import collections,datetime,hashlib,json,math,os,pathlib,resource,signal,sys,time,traceback
from osgeo import ogr,gdal
import geometry_backend as g
from sampling import paired_sample,prefix,point
R=pathlib.Path(__file__).resolve().parents[1]

def save(path,obj):
    with (R/path).open('x') as f:json.dump(obj,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def component_ids(p,center):return [i for i,c in enumerate(g.components(center)) if g.covered(point(p),c)]
def exact_point_clearance(p,rings):
    p=tuple(Fraction(str(v)) for v in p);values=[]
    for ring in rings:
        for a,b in zip(ring,ring[1:]+ring[:1]):
            v=tuple(b[k]-a[k] for k in (0,1));w=tuple(p[k]-a[k] for k in (0,1));den=sum(x*x for x in v)
            t=Fraction(0) if den==0 else max(Fraction(0),min(Fraction(1),sum(w[k]*v[k] for k in (0,1))/den))
            values.append(sum((p[k]-a[k]-t*v[k])**2 for k in (0,1)))
    q=min(values);inside=g.point_covered(p,rings)
    return {'minimum_squared_clearance_fraction':[str(q.numerator),str(q.denominator)],'exact_1_10m_endpoint_pass':inside and q>=Fraction(11,10)**2}

def audit_endpoints(inst,field,center,boundary,edges,rings,cache):
    start=g.timing();services=g.service_audit(inst,field,boundary,edges,rings,cache)
    for row in services:
        row.update(exact_point_clearance(row['coordinate'],rings))
        row['center_component_ids']=component_ids(row['coordinate'],center)
        row['member_of_conservative_C']=bool(row['center_component_ids'])
    failed=[r['service_id'] for r in services if r['clearance_status']=='FAIL']
    uncertain=[r['service_id'] for r in services if r['clearance_status']=='UNCERTAIN_BOUNDARY']
    excluded=[r['service_id'] for r in services if not r['member_of_conservative_C']]
    common=set(services[0]['center_component_ids'])
    for row in services[1:]:common.intersection_update(row['center_component_ids'])
    return {'services':services,'failing_service_ids':failed,'uncertain_service_ids':uncertain,'safe_but_excluded_from_C_ids':[r['service_id'] for r in services if r['clearance_status']=='PASS' and not r['member_of_conservative_C']],
            'not_in_C_ids':excluded,'all_services_share_C_component':bool(common),'shared_C_component_ids':sorted(common),
            'all_endpoints_exact_1_10m_pass':(all(r['exact_1_10m_endpoint_pass'] for r in services) if inst['sampling']['complete'] else None),'covers_complete_requested_task_set':inst['sampling']['complete'],
            'endpoint_status':'TASK_INFEASIBLE' if failed else 'UNCERTAIN_ENDPOINT_NUMERICS' if uncertain else 'ENDPOINTS_CLEAR_NECESSARY_ONLY','resources':g.elapsed(start)}

def plan_instance(inst,ep,center,field,boundary,edges,rings,bnodes,bedges,meta,cache):
    if not inst['sampling']['complete']:return {'status':'SAMPLING_INSUFFICIENT','solver_calls':0}
    if ep['endpoint_status']!='ENDPOINTS_CLEAR_NECESSARY_ONLY':return {'status':ep['endpoint_status'],'solver_calls':0}
    if meta['status']!='POSTERIOR_NUMERIC_REGION_PASS':return {'status':(meta['status'] if meta['status'] in ['RESOURCE_TIMEOUT','TECHNICAL_FAILURE'] else 'CONSERVATIVE_APPROXIMATION_UNAVAILABLE'),'solver_calls':0,'shared_preprocessing_status':meta['status']}
    if ep['not_in_C_ids']:return {'status':'SAFE_ENDPOINTS_EXCLUDED_BY_CONSERVATIVE_C','solver_calls':0,'not_a_proof_of_continuous_infeasibility':True}
    if not ep['all_services_share_C_component']:return {'status':'DISCONNECTED_CONSERVATIVE_C_COMPONENTS','solver_calls':0,'not_a_proof_of_exact_1_10m_infeasibility':True}
    artifact,D,paths=g.build_instance(inst,center,field,boundary,bnodes,bedges)
    save('raw/'+inst['instance_id']+'_graph.json',artifact)
    if artifact['unreachable_service_pairs']:return {'status':'NO_CONNECTION_IN_FROZEN_GRAPH','solver_calls':0,'unreachable_service_pairs':artifact['unreachable_service_pairs'],'not_a_proof_of_continuous_infeasibility':True}
    save('raw/'+inst['instance_id']+'_nn_call_started.json',{'utc':utc(),'method':'nearest_neighbor','attempt':1})
    t=g.timing();order,stats=g.nn(D);solve_time=g.elapsed(t)
    nodes=artifact['nodes'];sn=artifact['service_node_ids'];polyids=[];legs=[]
    for a,b in zip(order,order[1:]):
        p=paths[a][b];assert p[0]==sn[a] and p[-1]==sn[b];assert all(i<len(bnodes) for i in p[1:-1]);polyids.extend(p if not polyids else p[1:]);legs.append({'service_leg':[a,b],'node_ids':p})
    coords=[nodes[i] for i in polyids]
    route={'route':order,'length_m':g.cost(order,D),'operations':stats,'solve_resources':solve_time,'mapped_polyline_node_ids':polyids,'mapped_polyline_coordinates':coords,'legs':legs}
    save('raw/'+inst['instance_id']+'_nn_solver_output.json',route)
    t=g.timing();segments=[]
    for i,(a,b) in enumerate(zip(coords,coords[1:])):
        key=tuple(sorted((tuple(a),tuple(b))))
        if key not in cache:cache[key]=g.evaluate(a,b,field,boundary,edges,rings)
        segments.append({'segment_index':i,'a':a,'b':b,**cache[key]})
    full=g.geom(coords);inside=g.covered(full,field);clearance=full.Distance(boundary)
    assert abs(clearance-min(s['minimum_clearance_m'] for s in segments))<=g.TOL
    length=math.fsum(g.distance(a,b) for a,b in zip(coords,coords[1:]));assert abs(length-route['length_m'])<=g.TOL
    once=len(order)==inst['n']+2 and sorted(order[1:-1])==list(range(1,inst['n']+1))
    closed=order[0]==order[-1]==0 and coords[0]==coords[-1]==inst['coordinates'][0]
    hole_checks=[]
    for hi in range(1,field.GetGeometryCount()):
        hole=ogr.Geometry(ogr.wkbPolygon);hole.AddGeometry(field.GetGeometryRef(hi));hole_checks.append({'original_hole_index':hi,'intersection_empty':bool(full.Intersection(hole).IsEmpty())})
    valid=once and closed and inside and clearance>1.1+g.TOL and all(s['clearance_status']=='PASS' and s['exact_serialized_decimal_containment'] for s in segments) and all(h['intersection_empty'] for h in hole_checks)
    status='VALID_SAFE_ROUTE' if valid else 'UNCERTAIN_OR_INVALID_POSTERIOR_ROUTE'
    audit={'status':status,'each_scheduled_task_once':once,'depot_closed':closed,'complete_polyline_covered':inside,'minimum_clearance_m':clearance,'mapped_length_m':length,'original_hole_checks':hole_checks,'segments':segments,'validation_resources':g.elapsed(t)}
    save('raw/'+inst['instance_id']+'_route_audit.json',audit)
    return {'status':status,'solver_calls':1,'length_m':length,'minimum_clearance_m':clearance,'solve_resources':solve_time,'preprocessing_resources':artifact['preprocessing_resources'],'validation_resources':audit['validation_resources']}

def main():
    assert sys.argv[1:]==['--formal'];p=json.loads((R/'freeze/PROTOCOL.json').read_text());start=g.timing()
    started=json.loads((R/'evidence/STARTED.json').read_text());assert started['runner_pid']==os.getppid()
    assert resource.getrlimit(resource.RLIMIT_CPU)==(180,180);assert resource.getrlimit(resource.RLIMIT_AS)==(1073741824,1073741824)
    for f,h in json.loads((R/'freeze/PREEXECUTION_FREEZE.json').read_text())['files'].items():assert sha(R/f)==h,f
    signal.signal(signal.SIGALRM,g.timeout)
    save('evidence/FORMAL_CHILD_ENTERED.json',{'utc':utc(),'parent_pid':os.getppid(),'limits_verified':True,'attempt':1})
    field=ogr.CreateGeometryFromWkt((R/'input/projected_epsg32634.wkt').read_text());center=ogr.CreateGeometryFromWkt((R/'input/prior/center_region.wkt').read_text())
    assert field.IsValid() and field.GetGeometryCount()==4 and center.IsValid()
    boundary=field.Boundary();rings=g.rational_rings((R/'input/projected_epsg32634.wkt').read_text());edges=g.independent.boundary_edges(field)
    save('raw/domain_summary.json',{'P_area_m2':field.GetArea(),'C_area_m2':center.GetArea(),'C_to_P_area_ratio':center.GetArea()/field.GetArea(),'P_to_bbox_acceptance_area_ratio':field.GetArea()/((field.GetEnvelope()[1]-field.GetEnvelope()[0])*(field.GetEnvelope()[3]-field.GetEnvelope()[2])),'C_to_bbox_acceptance_area_ratio':center.GetArea()/((field.GetEnvelope()[1]-field.GetEnvelope()[0])*(field.GetEnvelope()[3]-field.GetEnvelope()[2])),'bbox_area_m2':(field.GetEnvelope()[1]-field.GetEnvelope()[0])*(field.GetEnvelope()[3]-field.GetEnvelope()[2]),'C_component_count':len(g.components(center)),'C_component_areas_m2':[c.GetArea() for c in g.components(center)],'minimum_C_clearance_m':center.Distance(boundary),'fixed_depot':p['depot'],'C_is_conservative_not_exact_erosion':True})
    insts=[];signal.alarm(30);sampling_start=g.timing()
    for seed in p['seeds']:
        with (R/f'raw/s{seed}_candidate_rows.jsonl').open('x') as trace:
            def emit(row):trace.write(json.dumps(row,allow_nan=False)+'\n');trace.flush()
            stream=paired_sample(field,center,p['depot'],seed,p['max_n'],p['candidate_cap_per_seed'],candidate_sink=emit)
        save(f'raw/s{seed}_candidate_stream.json',stream)
        if stream.get('interrupted'):
            save('raw/sampling_interrupted.json',{'seed':seed,'status':'RESOURCE_TIMEOUT' if stream['error_type']=='TimeoutError' else 'TECHNICAL_FAILURE','error':stream['error'],'completed_candidate_rows_retained':stream['candidate_count']})
            raise RuntimeError('Sampling interrupted; partial candidate stream retained')
        for n in p['sizes']:
            for arm in p['arms']:
                sample=prefix(stream,arm,n);name=f'{arm}_n{n:02d}_s{seed}'
                inst={'instance_id':name,'n':n,'seed':seed,'arm':arm,'sampling':sample,'coordinates':[p['depot']]+sample['coordinates']}
                save(f'raw/{name}_input.json',inst);insts.append(inst)
    signal.alarm(0);save('raw/sampling_phase.json',{'resources':g.elapsed(sampling_start),'instances':len(insts),'frozen_seed_streams':p['seeds']})
    pcache={};ep_records={};signal.alarm(60);ep_start=g.timing()
    for inst in insts:
        ep=audit_endpoints(inst,field,center,boundary,edges,rings,pcache);ep_records[inst['instance_id']]=ep;save('raw/'+inst['instance_id']+'_endpoints.json',ep)
    signal.alarm(0);save('raw/endpoint_phase.json',{'resources':g.elapsed(ep_start),'all_24_classified_before_any_graph':True})
    signal.alarm(40)
    try:
        newcenter,bnodes,bedges,meta=g.build_base(field)
        assert newcenter.ExportToIsoWkt()==center.ExportToIsoWkt(),'Fresh construction differs from frozen prior C'
    except Exception as exc:
        bnodes=[];bedges=[];meta={'status':'RESOURCE_TIMEOUT' if isinstance(exc,TimeoutError) else 'TECHNICAL_FAILURE','error':str(exc),'traceback':traceback.format_exc()};save('raw/shared_preprocessing_failure.json',meta)
    finally:signal.alarm(0)
    results=[];scache={};solver_calls=0
    for inst in insts:
        t=g.timing();signal.alarm(15)
        try:r=plan_instance(inst,ep_records[inst['instance_id']],center,field,boundary,edges,rings,bnodes,bedges,meta,scache)
        except Exception as exc:r={'status':'RESOURCE_TIMEOUT' if isinstance(exc,TimeoutError) else 'TECHNICAL_FAILURE','error':str(exc),'traceback':traceback.format_exc(),'solver_calls':int((R/('raw/'+inst['instance_id']+'_nn_call_started.json')).exists())}
        finally:signal.alarm(0)
        ep=ep_records[inst['instance_id']]
        r.update({'instance_id':inst['instance_id'],'n':inst['n'],'seed':inst['seed'],'arm':inst['arm'],'input_sha256':sha(R/('raw/'+inst['instance_id']+'_input.json')),'endpoint_status':ep['endpoint_status'],'all_endpoints_exact_1_10m_pass':ep['all_endpoints_exact_1_10m_pass'],'failing_service_ids':ep['failing_service_ids'],'uncertain_service_ids':ep['uncertain_service_ids'],'safe_but_excluded_from_C_ids':ep['safe_but_excluded_from_C_ids'],'all_services_share_C_component':ep['all_services_share_C_component'],'sampling_complete':inst['sampling']['complete'],'candidate_draws_to_prefix':inst['sampling']['candidate_draws_to_prefix'],'rejected_draws':inst['sampling']['rejected_draws'],'instance_resources':g.elapsed(t)})
        solver_calls+=r['solver_calls'];results.append(r);save('raw/'+inst['instance_id']+'_result.json',r)
        print(json.dumps({'instance_id':r['instance_id'],'status':r['status']}),flush=True)
    assert len(results)==24 and solver_calls<=24
    save('raw/results.json',{'status':'COMPLETE_UNAUDITED','instances':results,'solver_calls':solver_calls,'formal_attempts':1,'resources':g.elapsed(start),'gdal_version':gdal.VersionInfo(),'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'network_calls':0,'model_calls':0,'installs':0})
if __name__=='__main__':main()
