#!/usr/bin/python3
import json,pathlib,sys
from osgeo import ogr
import sampling as s
import geometry_backend as g
import experiment as e

def main():
    result=s.synthetic_tests()
    field=ogr.CreateGeometryFromWkt('POLYGON ((0 0,20 0,20 20,0 20,0 0),(8 8,12 8,12 12,8 12,8 8))')
    c,nodes,meta=g.construct(field);assert meta['status']=='POSTERIOR_NUMERIC_REGION_PASS'
    assert not g.safe_edge([2.,10.],[18.,10.],c,field,field.Boundary())
    assert g.safe_edge([2.,2.],[18.,2.],c,field,field.Boundary())
    rings=g.rational_rings('POLYGON ((0 0,20 0,20 20,0 20,0 0))')
    assert not e.exact_point_clearance([1.05,5.],rings)['exact_1_10m_endpoint_pass']
    assert e.exact_point_clearance([1.10,5.],rings)['exact_1_10m_endpoint_pass']
    assert e.exact_point_clearance([1.15,5.],rings)['exact_1_10m_endpoint_pass']
    assert g.state(1.1,True)=='UNCERTAIN_BOUNDARY'
    split=ogr.CreateGeometryFromWkt('MULTIPOLYGON (((0 0,4 0,4 4,0 4,0 0)),((10 0,14 0,14 4,10 4,10 0)))')
    assert e.component_ids([2.,2.],split)==[0] and e.component_ids([12.,2.],split)==[1]
    ins={'sampling':{'complete':True}};ep={'endpoint_status':'ENDPOINTS_CLEAR_NECESSARY_ONLY','not_in_C_ids':[],'all_services_share_C_component':False}
    r=e.plan_instance(ins,ep,None,None,None,None,None,None,None,{'status':'POSTERIOR_NUMERIC_REGION_PASS'},{})
    assert r['status']=='DISCONNECTED_CONSERVATIVE_C_COMPONENTS' and r['solver_calls']==0
    ep['not_in_C_ids']=[1]
    r=e.plan_instance(ins,ep,None,None,None,None,None,None,None,{'status':'POSTERIOR_NUMERIC_REGION_PASS'},{})
    assert r['status']=='SAFE_ENDPOINTS_EXCLUDED_BY_CONSERVATIVE_C'
    D=[[0.,2.,3.],[2.,0.,1.],[3.,1.,0.]];route,stats=g.nn(D);assert route==[0,1,2,0]
    result.update({'hole_crossing_rejected':True,'connected_point_does_not_imply_straight_line':True,'disconnected_C_retained':True,'safe_endpoint_conservative_exclusion_retained':True,'exact_threshold_tests':True,'nn_deterministic_matrix_test':True})
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
