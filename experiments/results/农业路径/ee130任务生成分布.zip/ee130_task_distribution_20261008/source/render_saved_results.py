#!/usr/bin/python3
"""Saved-artifact-only reporting. Never samples, builds graph, or calls a solver."""
import csv,datetime,hashlib,json,math,pathlib
from xml.sax.saxutils import escape
from osgeo import ogr
R=pathlib.Path(__file__).resolve().parents[1]
def load(p):return json.loads((R/p).read_text())
def save(p,x):
    with (R/p).open('x') as f:json.dump(x,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
receipt=load('evidence/RAW_DRIVE_RECEIPT.json');rawzip=R.parent/(R.name+'_RAW_COMPLETE_UNAUDITED.zip')
assert receipt['verified'] and receipt['download_byte_identical'] and receipt['sha256']==receipt['download_sha256']==sha(rawzip)
assert receipt['permissions']=='owner_only' and receipt['shared'] is False
if not (R/'raw/results.json').exists():
    inc=load('raw/INCOMPLETE_EXECUTION_INDEX.json')
    save('reports/all_24_conditions.json',inc['instances'])
    save('reports/summary.json',{'status':'INCOMPLETE_FORMAL_RUN_RETAINED','inventory':inc,'resources':load('evidence/RUN_STATUS.json'),'no_rerun':True})
    (R/'reports/REPORT_zh.md').write_text('# EE130任务分布实验：未完整执行\n\n唯一正式执行未能完成。已保留全部部分raw及24个预定条件索引并完成私有RAW归档；不重跑、不重新选seed、不删除失败。缺失条件不计为可行，旧任务未改动。具体运行状态和错误见evidence/RUN_STATUS.json、STDERR.log及raw/INCOMPLETE_EXECUTION_INDEX.json。\n')
    raise SystemExit(0)
raw=load('raw/results.json');protocol=load('freeze/PROTOCOL.json');domain=load('raw/domain_summary.json')
rows=[];pairs=[]
for result in raw['instances']:
    name=result['instance_id'];ins=load('raw/'+name+'_input.json');ep=load('raw/'+name+'_endpoints.json');sample=ins['sampling']
    rows.append({'instance_id':name,'arm':ins['arm'],'n':ins['n'],'seed':ins['seed'],'status':result['status'],'sample_complete':sample['complete'],'sampled_tasks':sample['accepted_n'],'all_endpoints_exact_1_10m_pass':ep['all_endpoints_exact_1_10m_pass'],'endpoint_tolerance_status':ep['endpoint_status'],'exact_failing_task_count':sum(not s['exact_1_10m_endpoint_pass'] for s in ep['services'][1:]),'numeric_failing_service_ids':ep['failing_service_ids'],'safe_but_excluded_from_C_ids':ep['safe_but_excluded_from_C_ids'],'all_services_share_C_component':ep['all_services_share_C_component'],'candidate_draws':sample['candidate_draws_to_prefix'],'rejections':sample['rejected_draws'],'length_m':(result.get('length_m') if result['status']=='VALID_SAFE_ROUTE' else None),'minimum_clearance_m':result.get('minimum_clearance_m'),'solver_calls':result['solver_calls']})
for seed in protocol['seeds']:
    for n in protocol['sizes']:
        pp=load(f'raw/P_n{n:02d}_s{seed}_input.json')['sampling'];cc=load(f'raw/C_n{n:02d}_s{seed}_input.json')['sampling']
        overlap=len(set(pp['accepted_candidate_indices'])&set(cc['accepted_candidate_indices']))
        pairs.append({'seed':seed,'n':n,'shared_task_candidate_count':overlap,'shared_fraction_of_requested_n':overlap/n,'P_candidate_draws':pp['candidate_draws_to_prefix'],'C_candidate_draws':cc['candidate_draws_to_prefix'],'C_minus_P_draws':cc['candidate_draws_to_prefix']-pp['candidate_draws_to_prefix']})
agg=[]
for arm in protocol['arms']:
    for n in protocol['sizes']:
        rr=[r for r in rows if r['arm']==arm and r['n']==n]
        agg.append({'arm':arm,'n':n,'denominator':4,'sampling_complete':sum(r['sample_complete'] for r in rr),'exact_endpoint_pass':sum(r['all_endpoints_exact_1_10m_pass'] is True for r in rr),'safe_routes':sum(r['status']=='VALID_SAFE_ROUTE' for r in rr),'status_counts':{s:sum(r['status']==s for r in rr) for s in sorted(set(r['status'] for r in rr))},'candidate_draws_total':sum(r['candidate_draws'] for r in rr),'rejections_total':sum(r['rejections'] for r in rr)})
summary={'status':'AUTHOR_REPORT_PENDING_INDEPENDENT_REVIEW','geometry':domain,'total_instances':24,'seed_streams':4,'nested_pairs':12,'nn_calls':raw['solver_calls'],'by_arm_size':agg,'paired_sampling':pairs,'counts_by_arm':{arm:{'denominator':12,'exact_endpoint_pass':sum(r['all_endpoints_exact_1_10m_pass'] is True for r in rows if r['arm']==arm),'safe_routes':sum(r['status']=='VALID_SAFE_ROUTE' for r in rows if r['arm']==arm)} for arm in protocol['arms']},'raw_sha256':sha(R/'raw/results.json'),'resources':load('evidence/RUN_STATUS.json')}
save('reports/summary.json',summary);save('reports/all_24_conditions.json',rows);save('reports/paired_sampling.json',pairs)
with (R/'reports/all_24_conditions.csv').open('x') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader()
    for row in rows:w.writerow({k:json.dumps(v) if isinstance(v,list) else v for k,v in row.items()})
with (R/'reports/paired_sampling.csv').open('x') as f:w=csv.DictWriter(f,fieldnames=list(pairs[0]));w.writeheader();w.writerows(pairs)
lines=['# EE130：任务生成分布与可规划性','', '状态：作者结果，待独立审查。','',
'## 结论边界','这是同一个 EE130 地块上的新合成任务研究。P组在原地块内作连续面积均匀近似；C组在已冻结的1.1米保守中心区内作连续面积均匀近似。固定depot沿用旧seed1001的[661922,6526122]。历史生成器使用整数米网格且随机depot，因此新P组也不是历史任务生成的原样复刻。',
'筛选改变了任务分布。C组端点通过是生成定义直接带来的结果，不能称为算法救回原任务，不能用新任务替换旧8个失败实例。原12任务及历史文件未修改。','',
'## 冻结设计',
'四个候选流seed：'+', '.join(map(str,protocol['seeds']))+'；每流的n=8/20/40是嵌套前缀。两组使用相同候选序列，共12配对/24条件；四流不是12个独立布局，更不是24个独立地块。单个真实地块外推有限，不做显著性或总体优越性推断。',
'从原P包围盒分别均匀生成x/y，以严格多边形内部测试拒绝洞和外部位置。每流最多100000候选；保留全部随机数、坐标、接受原因、候选序号、采纳序号，采样不足保留失败。没有按结果选择seed。',
'C是已验证的保守多边形近似，不是精确1.1米腐蚀集。精确序列化坐标的d>=1.1端点布尔、±1e-8数值标签和C成员关系分别报告。端点通过不等于能连通；C排除/断连也不能证明精确中心可行域中无路。','',
'## 面积与连通性',f"原P面积：{domain['P_area_m2']:.9f} m²；保守C面积：{domain['C_area_m2']:.9f} m²；C/P={domain['C_to_P_area_ratio']:.9%}。此比例是保守允许区域比例，非精确1.1米区域面积比例。",f"C组件数：{domain['C_component_count']}；最小整区边界净空数值：{domain['minimum_C_clearance_m']:.12f} m。所有原3孔保留核验，组件不筛掉。",'',
'## 全部条件结果','| 分布 | n | 精确端点全通过/4 | 有效NN路线/4 | 采样候选合计 | 拒绝合计 |','|---|---:|---:|---:|---:|---:|']
for a in agg:lines.append(f"| {a['arm']} | {a['n']} | {a['exact_endpoint_pass']} | {a['safe_routes']} | {a['candidate_draws_total']} | {a['rejections_total']} |")
lines.extend(['','上表各n共享前缀，候选数与拒绝数按条件报告，不能跨n相加后当作独立抽样成本。逐条件完整状态、失败ID、保守排除、候选index、共同任务比例、路长与净空见CSV/JSON和raw。不同组的路线服务不同任务，长度差不能归因于算法提升。','',
'## 规划与预算',f"只使用固定可见图+Dijkstra+NN，最多24次NN，实际调用{raw['solver_calls']}次。没有2opt竞赛、最优性oracle或模型调用。共享图预处理、逐实例预处理、求解、检查分开记录。",'正式上限：180秒CPU、300秒墙钟、1GiB；每实例15秒嵌套于总上限。单次执行，没有重采样、重跑或阈值调优。RAW已私有归档并逐字节回读后才生成本报告。',
'圆盘半径1m+0.1m是研究设定；没有真实车辆朝向、转向半径、动力学、定位误差或测绘精度模型，结果不是农业机械可执行证书。','',
'## 独立验证要求','另一个审查实现从已保存输入核验候选流、采纳前缀、洞/组件、精确端点/完整路线几何、服务一次、闭合、长度与归档身份；不重跑公共新任务规划。独立最终结论附于independent_review。'])
(R/'reports/REPORT_zh.md').write_text('\n'.join(lines)+'\n')
# Compact deterministic SVG. Four streams x two arms at n40, no raster editing.
field=ogr.CreateGeometryFromWkt((R/'input/projected_epsg32634.wkt').read_text());center=ogr.CreateGeometryFromWkt((R/'input/prior/center_region.wkt').read_text());xmin,xmax,ymin,ymax=field.GetEnvelope()
W,H=1140,1480;cw,ch=560,342;scl=min(480/(xmax-xmin),270/(ymax-ymin))
svg=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">','<rect width="100%" height="100%" fill="#f8fafc"/>','<style>text{font-family:Arial,sans-serif;fill:#0f172a}.small{font-size:13px}</style>','<text x="28" y="28" font-size="22">EE130: paired task-generation distributions (n=40)</text>','<text x="28" y="50" class="small">Same candidate stream by row; fixed depot black; exact clearance failure red; other tasks blue. P differs from C.</text>']
for ri,seed in enumerate(protocol['seeds']):
    for ci,arm in enumerate(['P','C']):
        ox=28+ci*cw;oy=84+ri*ch
        def xy(p):return ox+40+(p[0]-xmin)*scl,oy+34+(ymax-p[1])*scl
        def path(poly):
            ss=[]
            for j in range(poly.GetGeometryCount()):
                r=poly.GetGeometryRef(j);pts=[xy(r.GetPoint(k)[:2]) for k in range(r.GetPointCount())];ss.append('M '+' L '.join(f'{x:.3f},{y:.3f}' for x,y in pts)+' Z')
            return ' '.join(ss)
        svg.append(f'<rect x="{ox}" y="{oy-16}" width="548" height="332" rx="9" fill="white" stroke="#cbd5e1"/>')
        result=next(r for r in rows if r['arm']==arm and r['seed']==seed and r['n']==40)
        svg.append(f'<text x="{ox+12}" y="{oy+5}" font-size="15">{arm}, seed {seed}: {escape(result["status"])}</text>')
        svg.append(f'<path d="{path(field)}" fill="#e2e8f0" fill-rule="evenodd" stroke="#334155" stroke-width="1"/>')
        comps=[center] if center.GetGeometryName()=='POLYGON' else [center.GetGeometryRef(i) for i in range(center.GetGeometryCount())]
        for c in comps:svg.append(f'<path d="{path(c)}" fill="#dcfce7" fill-rule="evenodd" stroke="#16a34a" stroke-width="0.6"/>')
        eps=load(f'raw/{arm}_n40_s{seed}_endpoints.json')['services']
        for ep in eps[1:]:
            x,y=xy(ep['coordinate']);color='#2563eb' if ep['exact_1_10m_endpoint_pass'] else '#dc2626';svg.append(f'<circle cx="{x:.3f}" cy="{y:.3f}" r="2.7" fill="{color}"/>')
        x,y=xy(eps[0]['coordinate']);svg.append(f'<rect x="{x-4:.3f}" y="{y-4:.3f}" width="8" height="8" fill="#111827"/>')
svg.extend(['<text x="28" y="1470" class="small">Synthetic disk model; C is conservative. Four nested streams on one field, not independent environments or an algorithm rescue.</text>','</svg>'])
(R/'reports/n40_paired_distribution.svg').write_text('\n'.join(svg))
print(json.dumps(summary,ensure_ascii=False))
