"""Paired bounded rejection sampling on synthetic task distributions, never real work demand."""
import random
from osgeo import ogr

def point(p):
    g=ogr.Geometry(ogr.wkbPoint);g.AddPoint_2D(*p);return g

def paired_sample(field,center,depot,seed,target=40,max_draws=100000,candidate_sink=None):
    rng=random.Random(seed);xmin,xmax,ymin,ymax=field.GetEnvelope()
    accepted={'P':[],'C':[]};seen={'P':set(),'C':set()};draws=[]
    try:
        for index in range(1,max_draws+1):
            ux,uy=rng.random(),rng.random()
            p=[xmin+(xmax-xmin)*ux,ymin+(ymax-ymin)*uy];q=point(p);key=tuple(p)
            in_p=bool(field.Contains(q));in_c=bool(center.Contains(q))
            row={'candidate_index':index,'unit_random':[ux,uy],'coordinate':p,'strict_in_P':in_p,'strict_in_C':in_c}
            assert not in_c or in_p,'Frozen center region must be inside field'
            for arm,inside in [('P',in_p),('C',in_c)]:
                reason=('OUTSIDE_DOMAIN' if not inside else 'EQUALS_FIXED_DEPOT' if p==depot else 'DUPLICATE' if key in seen[arm] else 'ACCEPT')
                row[arm+'_reason']=reason
                if reason=='ACCEPT':
                    seen[arm].add(key)
                    accepted[arm].append({'candidate_index':index,'coordinate':p})
                row[arm+'_accepted_rank']=len(accepted[arm]) if reason=='ACCEPT' else None
            draws.append(row)
            if candidate_sink is not None:candidate_sink(row)
            if all(len(v)>=target for v in accepted.values()):break
    except Exception as exc:
        return {'seed':seed,'candidate_cap':max_draws,'target_per_arm':target,'candidate_count':len(draws),'complete':False,'draws':draws,'accepted':accepted,'interrupted':True,'error':str(exc),'error_type':type(exc).__name__,'partial_trace_note':'All completed candidate rows retained; an interrupted in-flight draw may be incomplete.'}
    return {'seed':seed,'candidate_cap':max_draws,'target_per_arm':target,'candidate_count':len(draws),'complete':all(len(v)>=target for v in accepted.values()),'draws':draws,'accepted':accepted}

def prefix(stream,arm,n):
    points=stream['accepted'][arm][:n];complete=len(points)==n
    cutoff=points[-1]['candidate_index'] if complete else stream['candidate_count']
    reasons={}
    for row in stream['draws'][:cutoff]:
        k=row[arm+'_reason'];reasons[k]=reasons.get(k,0)+1
    return {'complete':complete,'requested_n':n,'accepted_n':len(points),'candidate_draws_to_prefix':cutoff,'rejected_draws':cutoff-len(points),'reason_counts':reasons,'accepted_candidate_indices':[v['candidate_index'] for v in points],'coordinates':[v['coordinate'] for v in points]}

def synthetic_tests():
    field=ogr.CreateGeometryFromWkt('POLYGON ((0 0,20 0,20 20,0 20,0 0),(8 8,12 8,12 12,8 12,8 8))')
    center=field.Buffer(-1.2,16);depot=[2.,2.]
    s=paired_sample(field,center,depot,991,target=40,max_draws=10000)
    assert s['complete'] and s==paired_sample(field,center,depot,991,target=40,max_draws=10000)
    assert len(s['accepted']['P'])>=40 and len(s['accepted']['C'])==40
    for arm in ['P','C']:
        p8=prefix(s,arm,8);p20=prefix(s,arm,20);p40=prefix(s,arm,40)
        assert p8['coordinates']==p20['coordinates'][:8]==p40['coordinates'][:8]
        assert all((field if arm=='P' else center).Contains(point(p)) for p in p40['coordinates'])
        assert p40['rejected_draws']+40==p40['candidate_draws_to_prefix']
        assert p40['reason_counts'].get('ACCEPT')==40
    short=paired_sample(field,center,depot,992,target=40,max_draws=1)
    assert not short['complete'] and not prefix(short,'C',40)['complete']
    split=ogr.CreateGeometryFromWkt('MULTIPOLYGON (((0 0,4 0,4 4,0 4,0 0)),((10 0,14 0,14 4,10 4,10 0)))')
    multi=paired_sample(split,split,[1.,1.],993,target=20,max_draws=1000)
    assert multi['complete'];assert any(v['coordinate'][0]<4 for v in multi['accepted']['C']);assert any(v['coordinate'][0]>10 for v in multi['accepted']['C'])
    return {'status':'PASS','synthetic_only':True,'replay_and_prefix_tests':True,'holes_excluded':True,'multicomponent_not_filtered':True,'sampling_cap_failure_retained':True,'synthetic_seeds':[991,992,993]}
