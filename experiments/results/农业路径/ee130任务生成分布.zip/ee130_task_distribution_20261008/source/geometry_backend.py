#!/usr/bin/python3
"""Copied geometry primitives from previously audited 1.10m-margin planner; used by a separately frozen task-generation study."""
import os, collections, datetime, hashlib, heapq, json, math, pathlib, re, resource, signal, sys, time, traceback
from fractions import Fraction
from decimal import Decimal
from osgeo import ogr, gdal
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'source/upstream'))
import audit_clearance as independent
from common import exact_segment, point_covered, geos_segment, distance
from route_algorithms import nn, twoopt, cost
ogr.UseExceptions()
BASE_DISK_RADIUS=1.0
EXTRA_MARGIN=0.10
REQUIRED_CLEARANCE=BASE_DISK_RADIUS+EXTRA_MARGIN
TOL=1e-8
QUADRANT_SEGMENTS=16
NUMERICAL_MARGIN=1e-5
BUFFER_DISTANCE=(REQUIRED_CLEARANCE+NUMERICAL_MARGIN)/math.cos(math.pi/(2*QUADRANT_SEGMENTS))
METHODS=[('nearest_neighbor',nn),('nn_2opt_budget',twoopt)]
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def save(rel,x):
 p=ROOT/rel;p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x') as f:json.dump(x,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')
def timing():return time.perf_counter(),time.process_time()
def elapsed(t):return {'wall_seconds':time.perf_counter()-t[0],'cpu_seconds':time.process_time()-t[1]}
def geom(coords):return independent.geom_line(coords)
def covered(g,p):return independent.closed_covered(g,p)
def state(d,ok):
 if not ok or d<REQUIRED_CLEARANCE-TOL:return 'FAIL'
 if d>REQUIRED_CLEARANCE+TOL:return 'PASS'
 return 'UNCERTAIN_BOUNDARY'
def components(g):
 if g.IsEmpty():return []
 if g.GetGeometryName()=='POLYGON':return [g]
 if g.GetGeometryName()=='MULTIPOLYGON':return [g.GetGeometryRef(i) for i in range(g.GetGeometryCount())]
 raise ValueError('Unsupported center-region geometry '+g.GetGeometryName())
def rational_rings(wkt):
 return [[tuple(Fraction(v) for v in point.split()) for point in txt.split(',')][:-1] for txt in re.findall(r'\(([^()]+)\)',wkt)]
def rational_coords(p):return tuple(Fraction(str(x)) for x in p)
def timeout(_a,_b):raise TimeoutError('Frozen per-stage deadline exceeded')
def construct(field):
 center=field.Buffer(-BUFFER_DISTANCE,QUADRANT_SEGMENTS)
 comps=components(center)
 h=[p.GetGeometryCount()-1 for p in comps]
 ok=bool(comps) and bool(center.IsValid()) and covered(center,field)
 d=None if not comps else center.Distance(field.Boundary())
 # Region-as-filled-set distance checks every part, not just ring vertices.
 approved=ok and d>REQUIRED_CLEARANCE+TOL
 nodes=[];rings=[]
 for ci,p in enumerate(comps):
  for ri in range(p.GetGeometryCount()):
   ring=p.GetGeometryRef(ri);coords=[list(ring.GetPoint(i)[:2]) for i in range(ring.GetPointCount()-1)]
   ids=list(range(len(nodes),len(nodes)+len(coords)));nodes.extend(coords);rings.append({'component':ci,'ring':ri,'nodes':ids})
 assert len(set(tuple(v) for v in nodes))==len(nodes)
 holes=[]
 for hi in range(1,field.GetGeometryCount()):
  hole=ogr.Geometry(ogr.wkbPolygon);hole.AddGeometry(field.GetGeometryRef(hi))
  overlap=center.Intersection(hole)
  holes.append({'original_hole_index':hi,'intersection_empty':bool(overlap.IsEmpty()),'intersection_area_m2':overlap.GetArea()})
 approved=approved and all(h['intersection_empty'] for h in holes)
 return center,nodes,{'status':'POSTERIOR_NUMERIC_REGION_PASS' if approved else 'CONSERVATIVE_APPROXIMATION_UNAVAILABLE','buffer_distance_m':BUFFER_DISTANCE,'quadrant_segments':QUADRANT_SEGMENTS,'numerical_margin_m':NUMERICAL_MARGIN,'valid':bool(center.IsValid()),'center_within_original_field':ok,'minimum_region_distance_to_original_boundary_m':d,'component_count':len(comps),'component_hole_counts':h,'all_original_holes_excluded':holes,'rings':rings,'nodes':len(nodes),'center_area_m2':center.GetArea()}
def safe_edge(a,b,center,field,boundary):
 if a==b:return False
 line=geom([a,b])
 if not geos_segment(a,b,center):return False
 return geos_segment(a,b,field) and line.Distance(boundary)>REQUIRED_CLEARANCE+TOL

def build_base(field):
 start=timing();center,nodes,meta=construct(field);construction=elapsed(start)
 (ROOT/'raw/center_region.wkt').write_text(center.ExportToIsoWkt()+'\n')
 if meta['status']!='POSTERIOR_NUMERIC_REGION_PASS':
  save('raw/shared_preprocessing.json',{'construction':construction,'geometry':meta,'edges':[],'nodes':nodes,'visibility_resources':None});return center,nodes,[],meta
 t=timing();edges=[];checks=0;boundary=field.Boundary()
 for i,a in enumerate(nodes):
  for j in range(i+1,len(nodes)):
   checks+=1
   if safe_edge(a,nodes[j],center,field,boundary):edges.append([i,j,distance(a,nodes[j])])
 data={'construction':construction,'visibility_resources':elapsed(t),'total_shared_resources':elapsed(start),'geometry':meta,'nodes':nodes,'edges':edges,'candidate_edge_checks':checks,'accepted_safe_edges':len(edges)}
 save('raw/shared_preprocessing.json',data)
 print(json.dumps({'shared_preprocessing':data['total_shared_resources'],'nodes':len(nodes),'edges':len(edges),'region':meta['status']}),flush=True)
 return center,nodes,edges,meta

def dijkstra(adj,s,service_start):
 """Prior heap/lexicographic Dijkstra; destination services cannot be interior transit nodes."""
 ds=[math.inf]*len(adj);paths=[None]*len(adj);ds[s]=0.;paths[s]=(s,);q=[(0.,(s,),s)];pops=relax=0
 while q:
  d,p,u=heapq.heappop(q);pops+=1
  if (d,p)!=(ds[u],paths[u]):continue
  if u>=service_start and u!=s:continue
  for v,w in adj[u]:
   relax+=1;cand=(d+w,p+(v,))
   if cand[0]<ds[v] or (cand[0]==ds[v] and (paths[v] is None or cand[1]<paths[v])):
    ds[v],paths[v]=cand;heapq.heappush(q,(cand[0],cand[1],v))
 return ds,paths,pops,relax

def evaluate(a,b,field,boundary,edges,rings):
 coords=[a] if a==b else [a,b]
 out=independent.evaluate_geometry(coords,field,boundary,edges)
 exact=exact_segment(rational_coords(a),rational_coords(b),rings)
 assert out['closed_field_covered']==exact,'GEOS versus exact serialized-decimal containment disagreement'
 out['exact_serialized_decimal_containment']=exact
 out['clearance_status']=state(out['minimum_clearance_m'],out['closed_field_covered'])
 return out

def service_audit(inst,field,boundary,edges,rings,cache):
 out=[]
 for sid,p in enumerate(inst['coordinates']):
  k=tuple(p)
  if k not in cache:cache[k]=evaluate(p,p,field,boundary,edges,rings)
  out.append({'service_id':sid,'role':'depot' if sid==0 else 'task','coordinate':p,**cache[k]})
 return out

def build_instance(inst,center,field,boundary,bnodes,bedges):
 t=timing();b=len(bnodes);services=inst['coordinates'];nodes=bnodes+services;edges=list(bedges);checks=0;added=[]
 for j in range(b,len(nodes)):
  for i in range(j):
   checks+=1
   if safe_edge(nodes[i],nodes[j],center,field,boundary):
    e=[i,j,distance(nodes[i],nodes[j])];edges.append(e);added.append(e)
 adj=[[] for _ in nodes]
 for i,j,w in edges:adj[i].append((j,w));adj[j].append((i,w))
 sn=list(range(b,len(nodes)));ds=[dijkstra(adj,s,b) for s in sn];k=len(sn)
 unreachable=[[i,j] for i in range(k) for j in range(i+1,k) if not math.isfinite(ds[i][0][sn[j]])]
 D=[[0.]*k for _ in range(k)];paths=[[None]*k for _ in range(k)];asym=0.
 if not unreachable:
  for i in range(k):
   for j in range(i,k):
    asym=max(asym,abs(ds[i][0][sn[j]]-ds[j][0][sn[i]]));p=list(ds[i][1][sn[j]]);v=math.fsum(distance(nodes[a],nodes[c]) for a,c in zip(p,p[1:]));assert abs(v-ds[i][0][sn[j]])<=TOL
    D[i][j]=D[j][i]=v;paths[i][j]=p;paths[j][i]=p[::-1]
  assert asym<=TOL
 artifact={'nodes':nodes,'service_node_ids':sn,'added_visibility_edges':added,'shared_graph_file':'shared_preprocessing.json','new_visibility_checks':checks,'graph_nodes':len(nodes),'graph_edges':len(edges),'unreachable_service_pairs':unreachable,'distance_matrix':None if unreachable else D,'paths':None if unreachable else paths,'dijkstra_heap_pops':sum(x[2] for x in ds),'dijkstra_relaxations':sum(x[3] for x in ds),'distance_max_asymmetry_m':asym,'preprocessing_resources':elapsed(t)}
 return artifact,D,paths
