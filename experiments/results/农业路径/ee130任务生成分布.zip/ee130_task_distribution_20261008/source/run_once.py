#!/usr/bin/python3
"""Exclusive formal attempt, new private PREEXEC receipt, global hard resource bounds."""
import datetime,hashlib,json,os,pathlib,resource,signal,subprocess,time
R=pathlib.Path(__file__).resolve().parents[1]
def save(n,x):
    with (R/n).open('x') as f:json.dump(x,f,indent=2,ensure_ascii=False);f.write('\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
freeze=json.loads((R/'freeze/PREEXECUTION_FREEZE.json').read_text())
for name,h in freeze['files'].items():assert sha(R/name)==h,name
receipt=json.loads((R/'evidence/PREEXECUTION_DRIVE_RECEIPT.json').read_text())
z=R.parent/(R.name+'_PREEXECUTION_SNAPSHOT.zip')
assert receipt['verified'] is True and receipt['download_byte_identical'] is True and receipt['permissions']=='owner_only' and receipt['shared'] is False
assert receipt['sha256']==receipt['download_sha256']==sha(z) and receipt['bytes']==z.stat().st_size
assert json.loads((R/'evidence/PREEXECUTION_TOY_TESTS.json').read_text())['status']=='PASS'
review=json.loads((R/'independent_review/STATIC_PREEXEC_REVIEW.json').read_text())
assert review['status']=='PASS_STATIC_PREEXEC_REVIEW'
required={str(f.relative_to(R)) for sub in ['source','input','freeze'] for f in (R/sub).rglob('*') if f.is_file() and '__pycache__' not in str(f) and f.name!='PREEXECUTION_FREEZE.json'}
assert required<=set(review['reviewed_files']), 'Pre-review lacks source/input/protocol binding'
for name,h in review['reviewed_files'].items():assert sha(R/name)==h, 'Post-review change: '+name
assert not list((R/'raw').iterdir())
p=json.loads((R/'freeze/PROTOCOL.json').read_text())
save('evidence/STARTED.json',{'started_utc':utc(),'attempt':1,'runner_pid':os.getpid(),'preexec_zip_sha256':sha(z),'receipt_sha256':sha(R/'evidence/PREEXECUTION_DRIVE_RECEIPT.json'),'cpu_limit_s':180,'wall_limit_s':300,'memory_limit_bytes':1073741824,'solver_call_cap':24})
def limits():resource.setrlimit(resource.RLIMIT_CPU,(180,180));resource.setrlimit(resource.RLIMIT_AS,(1073741824,1073741824))
start=time.perf_counter();before=resource.getrusage(resource.RUSAGE_CHILDREN);status='TECHNICAL_FAILURE';rc=None
try:
    with (R/'evidence/STDOUT.log').open('x') as out,(R/'evidence/STDERR.log').open('x') as err:
        result=subprocess.run(['/usr/bin/python3',str(R/'source/experiment.py'),'--formal'],stdout=out,stderr=err,timeout=300,preexec_fn=limits,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1'})
    rc=result.returncode;status='COMPLETE_UNAUDITED' if rc==0 and (R/'raw/results.json').exists() else 'RESOURCE_TIMEOUT' if rc==-signal.SIGXCPU else 'RESOURCE_OR_EXTERNAL_TERMINATION' if rc==-signal.SIGKILL else 'TECHNICAL_FAILURE'
except subprocess.TimeoutExpired:status='RESOURCE_TIMEOUT'
except Exception as exc:save('evidence/EXCEPTION.json',{'error':str(exc)})
if (R/'raw/sampling_interrupted.json').exists():status=json.loads((R/'raw/sampling_interrupted.json').read_text())['status']
if status!='COMPLETE_UNAUDITED':
    inventory=[]
    for seed in p['seeds']:
        for n in p['sizes']:
            for arm in p['arms']:
                name=f'{arm}_n{n:02d}_s{seed}';rp=R/f'raw/{name}_result.json'
                inventory.append(json.loads(rp.read_text()) if rp.exists() else {'instance_id':name,'n':n,'seed':seed,'arm':arm,'status':'NOT_COMPLETED_DUE_TO_FORMAL_ABORT'})
    save('raw/INCOMPLETE_EXECUTION_INDEX.json',{'status':status,'instances':inventory,'one_attempt_only':True})
r=resource.getrusage(resource.RUSAGE_CHILDREN)
save('evidence/RUN_STATUS.json',{'status':status,'exit_code':rc,'one_formal_execution':True,'finished_utc':utc(),'wall_seconds':time.perf_counter()-start,'children_cpu_seconds':r.ru_utime+r.ru_stime-before.ru_utime-before.ru_stime,'children_peak_rss_kib':r.ru_maxrss,'termination_note':('SIGKILL is consistent with hard CPU/memory/resource enforcement but cause is not definitively known' if rc==-signal.SIGKILL else None),'nn_invocation_markers':len(list((R/'raw').glob('*_nn_call_started.json')))})
print(status)
raise SystemExit(0 if status=='COMPLETE_UNAUDITED' else 1)
