#!/usr/bin/python3
"""Only invented geometries and synthetic seeds; no study input or real seed use."""
import sys,pathlib,json,time,hashlib
from fractions import Fraction as F
from unittest.mock import patch
from osgeo import ogr
from geometry_exact import *
from replay_exact import validate_stream,verify_prefix
R=pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0,str(R/'source'))
import sampling

def main():
    start=time.perf_counter();checks=[]
    hole='POLYGON ((0 0,20 0,20 20,0 20,0 0),(8 8,12 8,12 12,8 12,8 8))'
    split='MULTIPOLYGON (((0 0,4 0,4 4,0 4,0 0)),((10 0,14 0,14 4,10 4,10 0)))'
    rect='POLYGON ((0 0,20 0,20 20,0 20,0 0))'
    hp=grid_geometry(parse_wkt(hole),1);sp=grid_geometry(parse_wkt(split),1)
    assert area(hp)==384 and area(sp)==32
    assert memberships((2,2),sp)==[0] and memberships((12,2),sp)==[1] and memberships((7,2),sp)==[]
    assert memberships((10,10),hp)==[] and memberships((8,10),hp)==[0] and not memberships((8,10),hp,True)
    checks+=['exact shoelace hole and multipolygon areas','all components and hole interior/boundary membership']
    rings=hp[0]
    assert not contained_segment((2,10),(18,10),rings)
    assert contained_segment((2,8),(18,8),rings)
    assert contained_segment((2,2),(18,2),rings)
    assert not audit_segment((2,10),(18,10),rings)['covered']
    assert audit_segment((2,2),(18,2),rings)['q']==4
    assert audit_segment((2,8),(18,8),rings)['q']==0
    assert audit_segment((2,2),(2,2),rings)['q']==4
    assert segment_sq((0,0),(4,0),(2,-1),(2,1))==0
    assert segment_sq((0,0),(4,0),(1,0),(3,0))==0
    assert point_sq((2,2),(0,0),(4,0))==4
    checks+=['whole-segment hole crossing and tangency','zero-length, crossing and collinear distances']
    rr=grid_geometry(parse_wkt(rect),10**10)[0]
    for x,ex,label in [('1.05',False,'FAIL'),('1.1',True,'UNCERTAIN_BOUNDARY'),('1.15',True,'PASS'),('1.100000005',True,'UNCERTAIN_BOUNDARY'),('1.099999995',False,'UNCERTAIN_BOUNDARY')]:
        p=grid_point([x,5],10**10);a=audit_segment(p,p,rr,10**10);assert (a['exact'],a['label'])==(ex,label)
    assert audit_segment(grid_point([-1,5],10**10),grid_point([-1,5],10**10),rr,10**10)['label']=='FAIL'
    checks+=['exact 1.10m distinguished from tolerance band']
    # This exact-safe point is excluded by deliberately stricter toy C.
    toy_c=grid_geometry(parse_wkt('POLYGON ((1.2 1.2,18.8 1.2,18.8 18.8,1.2 18.8,1.2 1.2))'),100)
    assert audit_segment((115,500),(115,500),grid_geometry(parse_wkt(rect),100)[0],100)['exact']
    assert not memberships((115,500),toy_c)
    checks+=['exact safe does not imply conservative C membership']
    stream_count=0
    for seed,wkt,cwkt,target,cap in [(44001,hole,None,40,10000),(44002,split,split,40,10000),(44003,hole,None,40,1)]:
        field=ogr.CreateGeometryFromWkt(wkt);center=ogr.CreateGeometryFromWkt(cwkt) if cwkt else field.Buffer(-1.2,16)
        stream=sampling.paired_sample(field,center,[2.,2.],seed,target,cap)
        pp,cc=parse_wkt(wkt),parse_wkt(center.ExportToIsoWkt())
        vals=[v for ps in [pp,cc] for rs in ps for ring in rs for p in ring for v in p]+[v for r in stream['draws'] for v in r['coordinate']]
        scale=scale_for(vals)
        validate_stream(stream,grid_geometry(pp,scale),grid_geometry(cc,scale),[2.,2.],field.GetEnvelope(),scale)
        for arm in ['P','C']:
            for n in [8,20,40]:verify_prefix(stream,arm,n,sampling.prefix(stream,arm,n))
        if seed==44002:
            assert any(p['coordinate'][0]<4 for p in stream['accepted']['C']) and any(p['coordinate'][0]>10 for p in stream['accepted']['C'])
        if seed==44003:assert not stream['complete']
        stream_count+=1
    checks+=['independent RNG replay, reason/rank/counter verification','8/20/40 prefix validation','cap exhaustion retained','disconnected components retained']
    class Fixed:
        def __init__(self,*args):self.r=iter([0.1,0.1,0.2,0.2,0.2,0.2,0.3,0.3])
        def random(self):return next(self.r)
    field=ogr.CreateGeometryFromWkt('POLYGON ((0 0,10 0,10 10,0 10,0 0))')
    with patch.object(sampling.random,'Random',Fixed):stream=sampling.paired_sample(field,field,[1.,1.],999999,target=2,max_draws=4)
    assert [r['P_reason'] for r in stream['draws']]==['EQUALS_FIXED_DEPOT','ACCEPT','DUPLICATE','ACCEPT']
    assert stream['candidate_count']==4 and len(stream['accepted']['P'])==2
    checks+=['fixed-depot exclusion and duplicate rejection']
    journal=[]
    def interrupted_sink(row):
        journal.append(row)
        if len(journal)==3:raise TimeoutError('synthetic interrupt')
    interrupted=sampling.paired_sample(field,field,[1.,1.],44004,target=40,max_draws=10000,candidate_sink=interrupted_sink)
    assert interrupted['interrupted'] and interrupted['error_type']=='TimeoutError' and interrupted['draws']==journal and interrupted['candidate_count']==3
    checks+=['interrupted sampler retains completed rows and explicit failure']
    output={'status':'PASS_INDEPENDENT_SYNTHETIC','real_candidates_generated':False,'real_planning_executed':False,'author_planner_imported':False,'synthetic_seeds':[44001,44002,44003],'replayed_synthetic_streams':stream_count,'checks':checks,'wall_seconds':time.perf_counter()-start}
    print(json.dumps(output,indent=2))
if __name__=='__main__':main()
