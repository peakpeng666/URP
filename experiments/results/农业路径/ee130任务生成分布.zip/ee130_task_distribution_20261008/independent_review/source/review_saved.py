#!/usr/bin/python3
"""Saved-artifact independent review. No author planner imports or planner execution.
All exact geometry uses the separately frozen geometry_exact implementation.
"""
import collections,csv,datetime,hashlib,json,math,pathlib,resource,time,zipfile
import xml.etree.ElementTree as ET
from fractions import Fraction as F
from geometry_exact import *
from replay_exact import validate_stream,verify_prefix
R=pathlib.Path(__file__).resolve().parents[2]
OUT=R/'independent_review/results'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads((R/p).read_text())
def save(name,x):(OUT/name).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def instant(s):return datetime.datetime.fromisoformat(s.replace('Z','+00:00'))
def close(a,b,tol=1e-8):assert abs(a-b)<=tol,(a,b,abs(a-b),tol)
def qstr(q):return [str(q.numerator),str(q.denominator)]
def area_close(a,b):close(float(a),b,1e-6)
def main():
    started=utc();clock=time.perf_counter();cpu=time.process_time()
    assert 0 < resource.getrlimit(resource.RLIMIT_CPU)[0] <= 180
    assert resource.getrlimit(resource.RLIMIT_AS)==(1073741824,1073741824)
    protocol=load('freeze/PROTOCOL.json');freeze=load('freeze/PREEXECUTION_FREEZE.json');rawmanifest=load('evidence/RAW_COMPLETE_UNAUDITED_MANIFEST.json')
    receipts={};archive_info={}
    for phase,suffix,manifest in [('PREEXECUTION','PREEXECUTION_SNAPSHOT',freeze),('RAW','RAW_COMPLETE_UNAUDITED',rawmanifest)]:
        receipt=load(f'evidence/{phase}_DRIVE_RECEIPT.json');archive=R.parent/(R.name+'_'+suffix+'.zip');download=pathlib.Path(receipt['download_path'])
        assert receipt['verified'] is True and receipt['download_byte_identical'] is True and receipt['permissions']=='owner_only' and receipt['shared'] is False
        assert sha(archive)==sha(download)==receipt['sha256']==receipt['download_sha256'] and archive.stat().st_size==receipt['bytes']
        with zipfile.ZipFile(archive) as z:
            names=z.namelist();assert len(names)==len(set(names)) and all(n.startswith(R.name+'/') and '..' not in pathlib.PurePosixPath(n).parts for n in names)
            for name,h in manifest['files'].items():
                assert sha(R/name)==h,name
                assert hashlib.sha256(z.read(R.name+'/'+name)).hexdigest()==h,name
            if phase=='PREEXECUTION':assert not any(n.startswith(R.name+'/raw/') for n in names)
            else:assert all(R.name+'/'+str(p.relative_to(R)) in names for p in (R/'raw').rglob('*') if p.is_file())
        receipts[phase]=receipt;archive_info[phase]={'sha256':sha(archive),'bytes':archive.stat().st_size,'checked_members':len(manifest['files']),'private_receipt_and_download_identity_verified':True}
    start=load('evidence/STARTED.json');run=load('evidence/RUN_STATUS.json');entry=load('evidence/FORMAL_CHILD_ENTERED.json')
    assert instant(freeze['created_utc'])<instant(receipts['PREEXECUTION']['confirmed_at_utc'])<instant(start['started_utc'])<=instant(entry['utc'])<instant(run['finished_utc'])<instant(rawmanifest['created_utc'])<instant(receipts['RAW']['confirmed_at_utc'])<instant(started)
    assert start['preexec_zip_sha256']==receipts['PREEXECUTION']['sha256'] and start['receipt_sha256']==sha(R/'evidence/PREEXECUTION_DRIVE_RECEIPT.json')
    assert entry['parent_pid']==start['runner_pid'] and entry['limits_verified'] and entry['attempt']==start['attempt']==1
    assert run['status']=='COMPLETE_UNAUDITED' and run['exit_code']==0 and run['one_formal_execution']
    assert run['children_cpu_seconds']<180 and run['wall_seconds']<300 and run['children_peak_rss_kib']*1024<1073741824
    for name,h in load('freeze/UPSTREAM_IMMUTABILITY.json').items():assert sha(pathlib.Path(name))==h,name
    for name,v in load('freeze/INPUT_IDENTITY.json').items():assert sha(R/name)==v['sha256'] and (R/name).read_bytes()==pathlib.Path(v['source_path']).read_bytes()
    pre=load('independent_review/STATIC_PREEXEC_REVIEW.json')
    for name,h in pre['reviewed_files'].items():assert sha(R/name)==h,name
    for name,h in pre['independent_code_sha256'].items():assert sha(R/name)==h,name
    print(json.dumps({'phase':'archive_identity','status':'PASS','raw_sha256':archive_info['RAW']['sha256']}),flush=True)
    raw=load('raw/results.json');expected=[f'{arm}_n{n:02d}_s{seed}' for seed in protocol['seeds'] for n in protocol['sizes'] for arm in protocol['arms']]
    assert [r['instance_id'] for r in raw['instances']]==expected and len(expected)==24
    assert raw['formal_attempts']==1 and raw['network_calls']==raw['model_calls']==raw['installs']==0
    streams={seed:load(f'raw/s{seed}_candidate_stream.json') for seed in protocol['seeds']}
    pg_text=parse_wkt((R/'input/projected_epsg32634.wkt').read_text());cg_text=parse_wkt((R/'input/prior/center_region.wkt').read_text())
    assert (R/'raw/center_region.wkt').read_bytes()==(R/'input/prior/center_region.wkt').read_bytes()
    base=load('raw/shared_preprocessing.json')
    coords=[v for ps in [pg_text,cg_text] for rs in ps for ring in rs for p in ring for v in p]+[v for stream in streams.values() for row in stream['draws'] for v in row['coordinate']]+[v for p in base['nodes'] for v in p]
    scale=scale_for(coords);pg,cg=grid_geometry(pg_text,scale),grid_geometry(cg_text,scale);rings=pg[0]
    assert len(pg)==1 and len(rings)==4 and len(cg)==1
    floats=[[float(v) for v in p] for p in pg_text[0][0]]
    bounds=(min(p[0] for p in floats),max(p[0] for p in floats),min(p[1] for p in floats),max(p[1] for p in floats))
    bbox=(bounds[1]-bounds[0])*(bounds[3]-bounds[2]);pa,ca=area(pg,scale),area(cg,scale);domain=load('raw/domain_summary.json')
    area_close(pa,domain['P_area_m2']);area_close(ca,domain['C_area_m2']);close(float(ca/pa),domain['C_to_P_area_ratio'])
    close(float(pa)/bbox,domain['P_to_bbox_acceptance_area_ratio']);close(float(ca)/bbox,domain['C_to_bbox_acceptance_area_ratio']);close(bbox,domain['bbox_area_m2'])
    assert domain['C_component_count']==len(cg) and domain['fixed_depot']==protocol['depot']
    for actual,saved in zip([area([c],scale) for c in cg],domain['C_component_areas_m2']):area_close(actual,saved)
    cchecks=[audit_segment(a,b,rings,scale) for poly in cg for a,b in edges(poly)]
    assert all(a['covered'] and a['label']=='PASS' for a in cchecks)
    assert all(not memberships(hole[0],cg) for hole in rings[1:])
    cq=min(a['q'] for a in cchecks);close(math.sqrt(float(cq)),domain['minimum_C_clearance_m'])
    base=load('raw/shared_preprocessing.json');expected_nodes=[[float(v) for v in p] for poly in cg_text for ring in poly for p in ring]
    assert len(base['nodes'])==len(expected_nodes) and base['geometry']['status']=='POSTERIOR_NUMERIC_REGION_PASS'
    assert all([float(format(v,'.15g')) for v in actual]==expected for actual,expected in zip(base['nodes'],expected_nodes))
    node_delta=max(abs(a[k]-e[k]) for a,e in zip(base['nodes'],expected_nodes) for k in (0,1))
    b=len(expected_nodes);assert base['candidate_edge_checks']==b*(b-1)//2 and base['accepted_safe_edges']==len(base['edges'])
    edgebase={}
    for u,v,w in base['edges']:
        assert 0<=u<v<b and (u,v) not in edgebase;close(w,math.dist(base['nodes'][u],base['nodes'][v]));edgebase[(u,v)]=w
    sample_result=[]
    for seed,stream in streams.items():
        assert stream['seed']==seed and stream['target_per_arm']==40 and stream['candidate_cap']==100000 and stream['complete']
        assert [json.loads(line) for line in (R/f'raw/s{seed}_candidate_rows.jsonl').read_text().splitlines()]==stream['draws']
        validate_stream(stream,pg,cg,protocol['depot'],bounds,scale)
        sample_result.append({'seed':seed,'candidate_count':stream['candidate_count'],'accepted_P':len(stream['accepted']['P']),'accepted_C':len(stream['accepted']['C']),'replayed_all_rows':True})
    print(json.dumps({'phase':'candidate_replay_and_C_geometry','status':'PASS','candidate_rows':sum(s['candidate_count'] for s in streams.values())}),flush=True)
    endpoint_cache={};segment_cache={};instance_results=[];route_min=[];all_endpoint_rows=0;full_segments=0;matrix_pairs=0;weight_checks=len(edgebase)
    def endpoint(p):
        key=tuple(p)
        if key not in endpoint_cache:
            q=grid_point(p,scale);a=audit_segment(q,q,rings,scale);a['components']=memberships(q,cg);endpoint_cache[key]=a
        return endpoint_cache[key]
    def segment(a,b):
        key=tuple(sorted((tuple(a),tuple(b))))
        if key not in segment_cache:segment_cache[key]=audit_segment(grid_point(a,scale),grid_point(b,scale),rings,scale)
        return segment_cache[key]
    for result in raw['instances']:
        name=result['instance_id'];ins=load(f'raw/{name}_input.json');ep=load(f'raw/{name}_endpoints.json');n,seed,arm=ins['n'],ins['seed'],ins['arm']
        assert result==load(f'raw/{name}_result.json') and result['input_sha256']==sha(R/f'raw/{name}_input.json')
        verify_prefix(streams[seed],arm,n,ins['sampling']);assert ins['coordinates']==[protocol['depot']]+ins['sampling']['coordinates']
        assert len(ep['services'])==n+1 and ep['covers_complete_requested_task_set']
        checks=[]
        for sid,(p,row) in enumerate(zip(ins['coordinates'],ep['services'])):
            all_endpoint_rows+=1;a=endpoint(p);checks.append(a)
            assert row['service_id']==sid and row['coordinate']==p and row['role']==('depot' if sid==0 else 'task')
            assert row['minimum_squared_clearance_fraction']==qstr(a['q']) and row['exact_1_10m_endpoint_pass']==a['exact']
            assert row['clearance_status']==a['label'] and row['closed_field_covered']==row['exact_serialized_decimal_containment']==a['covered']
            assert row['center_component_ids']==a['components'] and row['member_of_conservative_C']==bool(a['components'])
            close(math.sqrt(float(a['q'])),row['minimum_clearance_m']);close(math.sqrt(float(a['q'])),row['independent_global_minimum_m'])
        fail=[i for i,a in enumerate(checks) if a['label']=='FAIL'];unc=[i for i,a in enumerate(checks) if a['label']=='UNCERTAIN_BOUNDARY'];exc=[i for i,a in enumerate(checks) if not a['components']]
        safe_exc=[i for i,a in enumerate(checks) if a['label']=='PASS' and not a['components']];common=set(checks[0]['components'])
        for a in checks[1:]:common&=set(a['components'])
        endpoint_status='TASK_INFEASIBLE' if fail else 'UNCERTAIN_ENDPOINT_NUMERICS' if unc else 'ENDPOINTS_CLEAR_NECESSARY_ONLY'
        assert ep['failing_service_ids']==fail and ep['uncertain_service_ids']==unc and ep['not_in_C_ids']==exc and ep['safe_but_excluded_from_C_ids']==safe_exc
        assert ep['all_services_share_C_component']==bool(common) and ep['shared_C_component_ids']==sorted(common) and ep['endpoint_status']==endpoint_status
        exact=all(a['exact'] for a in checks);assert exact==ep['all_endpoints_exact_1_10m_pass']==result['all_endpoints_exact_1_10m_pass']
        for k in ['failing_service_ids','uncertain_service_ids','safe_but_excluded_from_C_ids','all_services_share_C_component','endpoint_status']:assert result[k]==ep[k]
        assert result['sampling_complete'] and result['candidate_draws_to_prefix']==ins['sampling']['candidate_draws_to_prefix'] and result['rejected_draws']==ins['sampling']['rejected_draws']
        expected_status=endpoint_status if endpoint_status!='ENDPOINTS_CLEAR_NECESSARY_ONLY' else 'SAFE_ENDPOINTS_EXCLUDED_BY_CONSERVATIVE_C' if exc else 'DISCONNECTED_CONSERVATIVE_C_COMPONENTS' if not common else 'VALID_SAFE_ROUTE'
        assert result['status']==expected_status
        out={'instance_id':name,'n':n,'seed':seed,'arm':arm,'exact_endpoint_pass':exact,'failing_ids':fail,'uncertain_ids':unc,'safe_C_exclusions':safe_exc,'status':expected_status,'solver_calls':result['solver_calls']}
        if result['status']!='VALID_SAFE_ROUTE':
            assert result['solver_calls']==0 and not (R/f'raw/{name}_nn_call_started.json').exists() and not (R/f'raw/{name}_graph.json').exists()
            instance_results.append(out);continue
        assert result['solver_calls']==1
        mark=load(f'raw/{name}_nn_call_started.json');assert mark['attempt']==1 and mark['method']=='nearest_neighbor'
        graph=load(f'raw/{name}_graph.json');route=load(f'raw/{name}_nn_solver_output.json');audit=load(f'raw/{name}_route_audit.json')
        nodes=graph['nodes'];sn=graph['service_node_ids'];D=graph['distance_matrix'];paths=graph['paths']
        assert nodes==base['nodes']+ins['coordinates'] and sn==list(range(b,b+n+1)) and graph['unreachable_service_pairs']==[]
        assert graph['graph_nodes']==len(nodes) and graph['shared_graph_file']=='shared_preprocessing.json'
        em=dict(edgebase)
        for u,v,w in graph['added_visibility_edges']:
            assert 0<=u<v<len(nodes) and v>=b and (u,v) not in em
            close(w,math.dist(nodes[u],nodes[v]));em[(u,v)]=w;weight_checks+=1
        assert graph['graph_edges']==len(em) and graph['new_visibility_checks']==sum(range(b,len(nodes)))
        assert len(D)==len(paths)==n+1
        for i in range(n+1):
            assert len(D[i])==len(paths[i])==n+1
            for j in range(n+1):
                pa=paths[i][j];assert pa[0]==sn[i] and pa[-1]==sn[j] and all(v<b for v in pa[1:-1])
                assert paths[j][i]==pa[::-1] and D[i][j]==D[j][i] and (D[i][j]>0 if i!=j else D[i][j]==0)
                weights=[em[tuple(sorted((u,v)))] for u,v in zip(pa,pa[1:])];close(math.fsum(weights),D[i][j])
                close(math.fsum(math.dist(nodes[u],nodes[v]) for u,v in zip(pa,pa[1:])),D[i][j]);matrix_pairs+=1
        order=route['route'];assert order[0]==order[-1]==0 and len(order)==n+2 and sorted(order[1:-1])==list(range(1,n+1))
        # Check each saved NN choice against all still-unvisited distances; do not call a solver.
        pending=set(range(1,n+1))
        for a,j in zip(order[:-2],order[1:-1]):
            assert j in pending and all((D[a][j],j)<=(D[a][k],k) for k in pending);pending.remove(j)
        assert not pending and route['operations']['distance_candidates']==n*(n+1)//2
        mapped=[];expected_legs=[]
        for a,j in zip(order,order[1:]):
            pa=paths[a][j];mapped.extend(pa if not mapped else pa[1:]);expected_legs.append({'service_leg':[a,j],'node_ids':pa})
        assert route['legs']==expected_legs and route['mapped_polyline_node_ids']==mapped
        points=[nodes[i] for i in mapped];assert route['mapped_polyline_coordinates']==points and points[0]==points[-1]==protocol['depot']
        assert len(audit['segments'])==len(points)-1
        qq=[]
        for k,(a,z,row) in enumerate(zip(points,points[1:],audit['segments'])):
            full_segments+=1;v=segment(a,z);qq.append(v['q'])
            assert v['covered'] and v['exact'] and v['label']=='PASS'
            assert row['segment_index']==k and row['a']==a and row['b']==z and row['clearance_status']=='PASS' and row['exact_serialized_decimal_containment']
            close(math.sqrt(float(v['q'])),row['minimum_clearance_m'])
        q=min(qq);route_min.append(q);length=math.fsum(math.dist(a,z) for a,z in zip(points,points[1:]))
        for value in [route['length_m'],audit['mapped_length_m'],result['length_m'],math.fsum(D[a][z] for a,z in zip(order,order[1:]))]:close(length,value)
        for value in [audit['minimum_clearance_m'],result['minimum_clearance_m']]:close(math.sqrt(float(q)),value)
        assert audit['status']=='VALID_SAFE_ROUTE' and audit['each_scheduled_task_once'] and audit['depot_closed'] and audit['complete_polyline_covered']
        assert len(audit['original_hole_checks'])==3 and all(h['intersection_empty'] for h in audit['original_hole_checks'])
        out.update({'length_m':length,'minimum_clearance_interval_m':sqrt_interval(q),'segments_checked':len(qq),'saved_NN_choices_verified':True,'saved_matrix_paths_verified':True});instance_results.append(out)
    assert sum(r['solver_calls'] for r in instance_results)==raw['solver_calls']==run['nn_invocation_markers']==len(list((R/'raw').glob('*_nn_call_started.json')))==18
    print(json.dumps({'phase':'all_endpoints_and_full_routes','status':'PASS','conditions':24,'routes':18,'unique_segments':len(segment_cache),'cpu_seconds':time.process_time()-cpu}),flush=True)
    result={'status':'PASS_INDEPENDENT_SAVED_RECOMPUTATION','started_utc':started,'finished_utc':utc(),'formal_planner_rerun':False,'new_real_candidates_generated':False,'author_planner_imported':False,'archives':archive_info,'old_immutable_files_checked':len(load('freeze/UPSTREAM_IMMUTABILITY.json')),'input_copies_checked':len(load('freeze/INPUT_IDENTITY.json')),'all_frozen_files_unchanged':True,'all_raw_files_unchanged':True,'candidate_streams':sample_result,'candidate_rows_replayed':sum(s['candidate_count'] for s in streams.values()),'decimal_grid_scale':str(scale),'exact_area':{'P_fraction':qstr(area(pg,scale)),'C_fraction':qstr(ca),'P_m2':float(area(pg,scale)),'C_m2':float(ca),'C_to_P':float(ca/area(pg,scale))},'C_graph_serialization_note':{'graph_node_decimal_precision':'Saved full binary64 JSON repr','C_wkt_decimal_precision':'15 significant digits','max_coordinate_difference_m':node_delta,'vertices_correspond_after_15_digit_serialization':True,'different_exact_decimal_sets':True},'C_components':len(cg),'C_boundary_segments_checked':len(cchecks),'C_minimum_clearance_interval_m':sqrt_interval(cq),'P_holes':3,'all_24_conditions':instance_results,'condition_count':24,'endpoint_rows_checked':all_endpoint_rows,'unique_endpoint_positions_checked':len(endpoint_cache),'route_count':len(route_min),'route_segments_checked':full_segments,'unique_route_segments_checked':len(segment_cache),'saved_matrix_path_entries_checked':matrix_pairs,'graph_edge_weights_checked':weight_checks,'global_route_minimum_clearance_interval_m':sqrt_interval(min(route_min)),'counts_by_arm':{arm:{'denominator':12,'exact_endpoint_pass':sum(r['exact_endpoint_pass'] for r in instance_results if r['arm']==arm),'valid_safe_routes':sum(r['status']=='VALID_SAFE_ROUTE' for r in instance_results if r['arm']==arm)} for arm in ['P','C']},'resources':{'wall_seconds':time.perf_counter()-clock,'cpu_seconds':time.process_time()-cpu,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},'limits':{'cpu_seconds':180,'wall_seconds':300,'address_space_bytes':1073741824},'matrix_scope':'Verified every stored service path edge, symmetry and length plus each NN decision; no shortest-path algorithm or optimizer was re-executed.'}
    save('INDEPENDENT_SAVED_RECOMPUTATION.json',result)
    print(json.dumps({'status':result['status'],'cpu_seconds':result['resources']['cpu_seconds'],'routes':18,'conditions':24}),flush=True)
if __name__=='__main__':main()
