#!/usr/bin/python3
"""Pre-execution review evidence. Reads real geometry/depot but never samples/plans."""
import ast,datetime,hashlib,json,pathlib,time
from geometry_exact import *
R=pathlib.Path(__file__).resolve().parents[2]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads((R/p).read_text())
def main():
    start=time.perf_counter();checks={}
    assert not list((R/'raw').iterdir())
    assert not (R/'evidence/STARTED.json').exists() and not (R/'freeze/PREEXECUTION_FREEZE.json').exists()
    checks['no_formal_candidates_or_execution_artifacts']=True
    p=load('freeze/PROTOCOL.json')
    assert p['seeds']==[202610082301,202610082302,202610082303,202610082304]
    assert p['sizes']==[8,20,40] and p['arms']==['P','C']
    assert p['total_instances']==24 and p['maximum_nn_solver_calls']==24 and p['total_seed_streams']==4
    assert p['max_n']==40 and p['candidate_cap_per_seed']==100000 and p['resources']['formal_attempts']==1
    assert p['resources']['total_cpu_seconds']==180 and p['resources']['total_wall_seconds']==300 and p['resources']['address_space_bytes']==1073741824
    checks['fixed_design_and_nested_hard_limits']=True
    ident=load('freeze/INPUT_IDENTITY.json')
    for name,v in ident.items():assert sha(R/name)==v['sha256'] and (R/name).read_bytes()==pathlib.Path(v['source_path']).read_bytes(),name
    upstream=load('freeze/UPSTREAM_IMMUTABILITY.json')
    for name,h in upstream.items():assert sha(pathlib.Path(name))==h,name
    checks['input_identity_count']=len(ident);checks['old_immutable_files_count']=len(upstream)
    pp=parse_wkt((R/'input/projected_epsg32634.wkt').read_text());cc=parse_wkt((R/'input/prior/center_region.wkt').read_text())
    scale=scale_for(v for ps in [pp,cc] for rings in ps for ring in rings for point in ring for v in point)
    pg,cg=grid_geometry(pp,scale),grid_geometry(cc,scale)
    assert len(pg)==1 and len(pg[0])==4
    old=load('input/prior/original_depot_instance.json');old_ep=load('input/prior/depot_endpoint_evidence.json')
    assert p['depot']==old['coordinates'][0]==old_ep['services'][0]['coordinate']==[661922,6526122]
    depot=grid_point(p['depot'],scale);d=audit_segment(depot,depot,pg[0],scale)
    assert d['exact'] and d['label']=='PASS' and memberships(depot,cg)==[0]
    assert load('input/prior/margin_independent_FINAL_STATUS.json')['status']=='PASS_FINAL_INDEPENDENT_REVIEW'
    checks['fixed_depot_and_prior_conservative_C_provenance']=True
    checks['independent_depot_clearance_interval_m']=sqrt_interval(d['q'])
    checks['P_holes']=len(pg[0])-1;checks['C_components']=len(cg)
    checks['independent_P_area_m2']=str(area(pg,scale));checks['independent_C_area_m2']=str(area(cg,scale))
    src={str(f.relative_to(R)):f.read_text() for f in (R/'source').rglob('*.py')}
    for s in src.values():ast.parse(s)
    exp=src['source/experiment.py'];tree=ast.parse(exp)
    calls=[n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='nn']
    assert len(calls)==1 and not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in ['twoopt','oracle'] for n in ast.walk(tree))
    assert exp.index("save('raw/endpoint_phase.json'")<exp.index('newcenter,bnodes,bedges,meta=g.build_base(field)')
    assert "signal.alarm(30)" in exp and "signal.alarm(60)" in exp and "signal.alarm(40)" in exp and "signal.alarm(15)" in exp
    assert "'_nn_call_started.json'" in exp and 'assert len(results)==24 and solver_calls<=24' in exp
    checks['all_endpoints_precede_graph_and_only_one_NN_call_site']=True
    for name in ['source/run_once.py','source/seal_snapshot.py']:
        s=src[name]
        assert "required<=set(review['reviewed_files'])" in s and "for name,h in review['reviewed_files'].items():assert sha(R/name)==h" in s
    runner=src['source/run_once.py'];seal=src['source/seal_snapshot.py'];render=src['source/render_saved_results.py']
    assert "'evidence/STARTED.json'" in runner and "open('x')" in runner and 'timeout=300' in runner
    assert "resource.RLIMIT_CPU,(180,180)" in runner and "resource.RLIMIT_AS,(1073741824,1073741824)" in runner
    assert "receipt['permissions']=='owner_only'" in runner and "receipt['shared'] is False" in runner
    assert "receipt['sha256']==receipt['download_sha256']==sha(z)" in runner
    assert 'INCOMPLETE_EXECUTION_INDEX.json' in runner and '-signal.SIGXCPU' in runner and '-signal.SIGKILL' in runner
    assert "receipt=load('evidence/RAW_DRIVE_RECEIPT.json')" in render and "receipt['download_byte_identical']" in render
    assert "if result['status']=='VALID_SAFE_ROUTE' else None" in render
    assert "candidate_sink=emit" in exp and 'trace.flush()' in exp and 'sampling_interrupted.json' in exp
    checks['review_hash_binding_exclusive_execution_private_receipts_raw_gate']=True
    checks['all_six_pre_review_findings_resolved']=True
    assert load('independent_review/evidence/SYNTHETIC_INDEPENDENT.json')['status']=='PASS_INDEPENDENT_SYNTHETIC'
    assert load('independent_review/evidence/SYNTHETIC_AUTHOR_RECHECK.json')['status']=='PASS'
    checks['independent_and_author_synthetic_suites']=True
    reviewed={str(f.relative_to(R)):sha(f) for sub in ['source','input','freeze'] for f in sorted((R/sub).rglob('*')) if f.is_file() and '__pycache__' not in str(f) and f.name!='PREEXECUTION_FREEZE.json'}
    own={str(f.relative_to(R)):sha(f) for f in sorted((R/'independent_review/source').glob('*.py'))}
    resolved=[
      'Bind independent review to current source/input/protocol hashes in seal and runner.',
      'Preserve shared graph RESOURCE_TIMEOUT or TECHNICAL_FAILURE instead of mislabelling approximation.',
      'Publish route length only for VALID_SAFE_ROUTE; raw invalid output remains available for audit.',
      'SIGXCPU classified as resource timeout; SIGKILL cause honestly uncertain.',
      'Flush completed candidate rows to JSONL and save caught-interruption partial stream.',
      'Report conservative and original domain area relative to common sampling bounding box.'
    ]
    report='''# Independent static and synthetic pre-execution review

Status: PASS_STATIC_PREEXEC_REVIEW

This pass authorizes only the next freeze/archive gate. It is not a result, route-safety certificate, or confirmation that a PREEXEC or RAW upload has occurred.

## Research design

The experiment changes synthetic task generation. P and conservative C are sampled from the same bounding-box candidate sequence, with all three holes excluded and all C components eligible. Four prescribed streams have nested 8/20/40 prefixes: 24 conditions and at most 24 NN invocations. Accepted P rows beyond 40 are retained when C needs more draws. Cap exhaustion remains a failure without reseeding. Binary64 pseudorandom sampling is explicitly an approximation to continuous area uniformity. Historical integer-grid tasks and their random depots are not claimed as replicated or rescued.

The fixed depot is byte-identical to the previously saved seed-1001 depot. Its independently recomputed exact serialized-coordinate clearance lies in [4.401724777438, 4.401724777439] m and it is in C. Seven input copies and 262 historical artifact hashes match. P has three holes; saved C has one component. No real candidate stream was generated and no real graph or route was computed during this review.

## Exact and conservative geometry

Independent review code uses its own WKT topology parsing, decimal-grid integers, ray-parity containment, rational projections, segment intersections and shoelace areas. It does not import the author planner. Synthetic checks distinguish exact d >= 1.10 m from the numeric tolerance band, preserve safe-but-C-excluded endpoints, handle holes, multipolygon components, complete-segment crossings, tangencies, and degenerate segments. Candidate replay independently validates saved synthetic RNG draws, membership, reasons, ranks, counters and all prefixes. Fault injection checks duplicate/depot rejection and partial trace retention.

C remains the prior byte-identical conservative polygon, not the analytic erosion set. Endpoint feasibility is necessary only; C exclusion/disconnection is not proof of infeasibility in the exact center domain. All 24 endpoints are scheduled before fresh shared graph construction. Dijkstra paths cannot use other service vertices internally. Only the single NN call site is reached by eligible instances; legacy 2-opt code is present but has no formal call.

## Execution controls

The six identified pre-review issues are fixed: stale review hashes, graph-failure classification, invalid-route public lengths, signal termination labels, partial sampling journal, and bounding-box area ratios. Exclusive-created STARTED plus parent-process identity and frozen hash checks support one attempt. Nested phase timers and the 180 CPU-second / 300 wall-second / 1 GiB subprocess bounds are explicit. Private PREEXEC receipt and byte-identical readback are required before execution; saved reporting requires private RAW receipt. Failed or aborted conditions receive a retained 24-condition inventory. Hard kill may leave one in-flight row or partial artifact incomplete; no result-dependent retry is permitted.

## Remaining gates and limits

The parent must now freeze exactly the reviewed files, upload/read back private PREEXEC, perform at most one formal attempt, and seal/upload/read back RAW before saved-result review or interpretation. These future actions were not performed by this reviewer. Later independent review must verify archive member hashes and chronology, every saved candidate/prefix/endpoint/classification, all used route segments, NN order against the saved matrix, lengths, task visits and depot closure. It must not re-run the planner. Route/region correctness is limited to exact serialized geometry and the hypothetical disk model; no dynamics, localization or survey-accuracy certificate is provided.
'''
    rp=R/'independent_review/STATIC_PREEXEC_REVIEW.md';rp.write_text(report)
    result={'status':'PASS_STATIC_PREEXEC_REVIEW','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Static and synthetic only; no real candidate sampling or planner execution.','formal_raw_empty':True,'real_candidates_generated':False,'real_planning_executed':False,'reviewed_files':reviewed,'independent_code_sha256':own,'checks':checks,'resolved_findings':resolved,'blocking_findings':[],'pending_gates':['Freeze matching reviewed files','Private PREEXEC upload and byte-identical readback','At most one resource-bounded formal execution','Private RAW archive and byte-identical readback','Saved-result-only independent review'],'report_sha256':sha(rp),'synthetic_evidence_sha256':{f:sha(R/f) for f in ['independent_review/evidence/SYNTHETIC_INDEPENDENT.json','independent_review/evidence/SYNTHETIC_AUTHOR_RECHECK.json']},'wall_seconds':time.perf_counter()-start}
    (R/'independent_review/STATIC_PREEXEC_REVIEW.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'reviewed_files':len(reviewed),'independent_code_files':len(own),'report_sha256':result['report_sha256'],'raw_empty':not list((R/'raw').iterdir())}))
if __name__=='__main__':main()
