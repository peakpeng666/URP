#!/usr/bin/python3
"""Bounded saved-data review supervisor; no author execution."""
import datetime,json,os,pathlib,resource,subprocess,time
R=pathlib.Path(__file__).resolve().parents[2]
E=R/'independent_review/evidence'
def limits():
    resource.setrlimit(resource.RLIMIT_CPU,(179,179));resource.setrlimit(resource.RLIMIT_AS,(1073741824,1073741824))
start=time.perf_counter();before=resource.getrusage(resource.RUSAGE_CHILDREN);started=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (E/'SAVED_REVIEW_STDOUT_02.log').open('x') as out,(E/'SAVED_REVIEW_STDERR_02.log').open('x') as err:
    p=subprocess.run(['/usr/bin/python3',str(R/'independent_review/source/review_saved.py')],stdout=out,stderr=err,preexec_fn=limits,timeout=299,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
u=resource.getrusage(resource.RUSAGE_CHILDREN)
(E/'SAVED_REVIEW_RUN_02.json').write_text(json.dumps({'status':'PASS' if p.returncode==0 else 'FAILED_REVIEW','started_utc':started,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'returncode':p.returncode,'wall_seconds':time.perf_counter()-start,'children_cpu_seconds':u.ru_utime+u.ru_stime-before.ru_utime-before.ru_stime,'peak_rss_kib':u.ru_maxrss,'hard_cpu_s':179,'hard_wall_s':299,'hard_address_space_bytes':1073741824,'real_planner_called':False},indent=2)+'\n')
raise SystemExit(p.returncode)
