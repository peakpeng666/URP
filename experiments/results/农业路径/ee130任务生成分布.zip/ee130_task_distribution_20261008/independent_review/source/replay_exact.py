"""Independent replay and prefix validation, never generates new selected real tasks.
Caller supplies a saved stream. RNG is advanced only for existing saved rows.
"""
import random
from geometry_exact import memberships,grid_point

def validate_stream(stream,polys_p,polys_c,depot,bounds,scale):
    rng=random.Random(stream['seed']);accepted={'P':[],'C':[]};seen={'P':set(),'C':set()}
    xmin,xmax,ymin,ymax=bounds
    assert len(stream['draws'])==stream['candidate_count']<=stream['candidate_cap']
    for index,row in enumerate(stream['draws'],1):
        assert not all(len(v)>=stream['target_per_arm'] for v in accepted.values()),'rows after stopping condition'
        ux,uy=rng.random(),rng.random();p=[xmin+(xmax-xmin)*ux,ymin+(ymax-ymin)*uy]
        assert row['candidate_index']==index and row['unit_random']==[ux,uy] and row['coordinate']==p
        for arm,polys in [('P',polys_p),('C',polys_c)]:
            inside=bool(memberships(grid_point(p,scale),polys,strict=True));assert row['strict_in_'+arm]==inside
            key=tuple(p)
            reason='OUTSIDE_DOMAIN' if not inside else 'EQUALS_FIXED_DEPOT' if p==depot else 'DUPLICATE' if key in seen[arm] else 'ACCEPT'
            assert row[arm+'_reason']==reason
            if reason=='ACCEPT':seen[arm].add(key);accepted[arm].append({'candidate_index':index,'coordinate':p})
            assert row[arm+'_accepted_rank']==(len(accepted[arm]) if reason=='ACCEPT' else None)
    assert accepted==stream['accepted']
    complete=all(len(v)>=stream['target_per_arm'] for v in accepted.values())
    assert stream['complete']==complete
    if not stream.get('interrupted',False):assert complete or len(stream['draws'])==stream['candidate_cap']
    return accepted

def verify_prefix(stream,arm,n,saved):
    chosen=stream['accepted'][arm][:n];complete=len(chosen)==n
    cutoff=chosen[-1]['candidate_index'] if complete else stream['candidate_count'];counts={}
    for row in stream['draws'][:cutoff]:counts[row[arm+'_reason']]=counts.get(row[arm+'_reason'],0)+1
    expected={'complete':complete,'requested_n':n,'accepted_n':len(chosen),'candidate_draws_to_prefix':cutoff,'rejected_draws':cutoff-len(chosen),'reason_counts':counts,'accepted_candidate_indices':[p['candidate_index'] for p in chosen],'coordinates':[p['coordinate'] for p in chosen]}
    assert saved==expected
    return expected
