#!/usr/bin/python3
"""Close review against unchanged saved inputs/raw and final author report hashes."""
import datetime,hashlib,json,pathlib
R=pathlib.Path(__file__).resolve().parents[2]
def load(p):return json.loads((R/p).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):(R/p).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
core=load('independent_review/results/INDEPENDENT_SAVED_RECOMPUTATION.json');review=load('independent_review/evidence/FINAL_REPORT_CHECKS.json');summary=load('reports/summary.json')
assert core['status']=='PASS_INDEPENDENT_SAVED_RECOMPUTATION' and review['status']=='PASS_SAVED_REPORT_DATA_AND_FIGURE_CHECKS'
assert summary['status']=='VERIFIED_SAVED_RESULTS'
for manifest in ['freeze/PREEXECUTION_FREEZE.json','evidence/RAW_COMPLETE_UNAUDITED_MANIFEST.json']:
    for name,h in load(manifest)['files'].items():assert sha(R/name)==h,name
for name,h in load('freeze/UPSTREAM_IMMUTABILITY.json').items():assert sha(pathlib.Path(name))==h,name
for name,h in review['reviewed_report_files'].items():assert sha(R/name)==h,name
report=(R/'reports/REPORT_zh.md').read_text()
for token in ['452','820','0.000000005','1.102915312325','1.102915312326','1.102491143225','1.102491143226','406','568','716','369','11618']:
    assert token in report,token
qa=load('evidence/VISUAL_QA.json');assert qa['sha256']==sha(R/'reports/n40_paired_distribution.png')
runs=[load(f'independent_review/evidence/SAVED_REVIEW_RUN_{i:02d}.json') for i in (1,2)]
body='''# EE130 新任务生成分布实验：独立最终审查

结论：PASS_FINAL_INDEPENDENT_REVIEW。

## 复核结果

- 预定的4个共享候选流、8/20/40嵌套前缀、P/C两组共24个条件全部保留。
- 4流共406条候选（93、116、99、98）逐行核验随机数、坐标、P/C严格成员关系、接受/拒绝原因、顺序、计数、停止点以及全部嵌套前缀；JSONL与结构化候选流一致。
- 全部568条端点记录（168个唯一位置）按保存十进制坐标，以独立整数/有理数实现核对原外环及3孔洞、精确1.10米阈值、数值容差标签、C成员及组件。
- P组12条件中6个通过并获得有效路线，另6个端点不可行；C组12条件全部通过并获得有效路线。按n=8/20/40，P为3/4、2/4、1/4，C均为4/4。不存在被隐藏的缺失条件。
- 18次NN调用标记与18份路线一一对应。每一步已存NN选择都对未访问任务的已存距离核验，包含低任务ID平局规则；每个服务恰好一次，回到固定depot，映射路径与长度一致。
- 核验11618个已存服务矩阵路径条目的边存在性、长度及对称性，检查78118次保存边权。没有重新执行Dijkstra、NN或其他公共任务规划；没有独立宣称所有已存矩阵距离为全图最短路或连续最优路线。
- 完整路线共716次段使用、369条唯一线段均通过独立精确几何审核。全部18条路线最小净空落在[1.102915312325, 1.102915312326]米。
- 保守C的455条序列化边界段通过原地块几何审核，原3孔洞被排除。C为一个组件，其序列化边界最小净空落在[1.102491143225, 1.102491143226]米。

## 面积与生成解释

独立精确鞋带公式给出P面积19625.993447153185平方米、C面积18679.371558060884平方米，C/P约0.9517669313585951。作者GDAL面积与此有极小浮点舍入差，所有报告数值在声明的数值误差范围内一致。C/P是保守允许区域比例，不是精确1.1米腐蚀域比例。

事后补充的理想连续独立抽样解析值p^n经复算一致：n=8/20/40时约67.3356%、37.2059%、13.8428%。报告正确标为事后解释，并说明它只对应全部任务属于保守C，不是53位有限生成器的精确概率、精确1.1米可行率或NN成功率。固定depot另行核验。

P前40任务的首次失败记录亦匹配独立端点结果：seed2301任务33/候选75；seed2302任务15/候选27；seed2303无失败；seed2304任务1/候选1。

## 序列化精度说明

采样域为冻结的15有效位C WKT；fresh图节点的JSON保存更多小数。455个节点中452个、910个坐标中820个不逐坐标相等。两者在15有效位序列化下对应一致；按各自保存的十进制数，最大坐标差精确为1/200000000米，即5×10^-9米。binary64相减显示的最大差约4.6566128730773926×10^-9米。

本审查直接对每条路线保存的十进制坐标与原地块边界作精确运算，未把这两套节点强行视为同一精确坐标。该表示差未改变18条已存路线的通过结论。第一次审核程序使用了过强的逐浮点节点相等断言，因而停止；该记录与当时审核源码完整保留。修正的是审核中的序列化身份判据，实验源码、输入、RAW与正式执行均未改变，也未重新执行实验。

## 身份、归档与资源

PREEXEC与RAW均核对本地包、既有私有归档回读文件的SHA-256和字节数、owner-only/nonshared回执声明及全部清单成员。确认顺序为PREEXEC回读、唯一正式执行、RAW封存、RAW回读、保存结果审查。预执行33项清单成员与RAW198项清单成员均匹配；7项输入副本及262项历史文件保持哈希一致。旧12实例及其中8个旧端点失败没有被更改或替换。

正式运行耗时36.071墙钟秒、36.024 CPU秒，18次NN，低于180 CPU秒/300墙钟秒/1 GiB预算。审核没有导入作者planner；重放只针对既有406条候选。两次核心审核进程共约2.673 CPU秒（包括初次序列化断言停止），未超过单独审核资源上限。原始失败审核日志保留，并与最终通过日志区分。

## 最终报告与图

最终作者报告、summary、全部24条件JSON/CSV、12对采样JSON/CSV、事后解析参考和首次失败点均已核对。SVG全部320个任务点坐标、颜色、8个depot和16个带3孔的区域结构与保存数据匹配。PNG已完整视觉检查：8面板清楚，P失败点数1/3/0/3，C全为0，孔洞、固定depot、图例均可辨识；SVG仅作结构数据审核，不声称另行完成其栅格化视觉审核。所有最终作者报告文件哈希绑定在FINAL_REPORT_CHECKS.json及FINAL_STATUS.json。

## 结论范围

这是一处EE130几何上的新合成分布研究，四个候选流及嵌套尺寸存在依赖。C组改变了任务集合，不能称作救回原P任务、修复历史失败或提高算法能力。不同任务路线长度不能作算法因果比较。端点通过是必要条件，C排除/断连也不是精确连续中心可行域无路的证明。结果只约束保存几何和假设平移圆盘，不是车辆动力学、定位误差、真实测绘精度或现场安全证书。
'''
path='independent_review/results/INDEPENDENT_REVIEW_REPORT.md';(R/path).write_text(body)
status={'status':'PASS_FINAL_INDEPENDENT_REVIEW','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Saved-data candidate replay, exact serialized-coordinate endpoint and full-route geometry, fixed NN decisions, archive identity, all24 reports and figures.','saved_result_status':core['status'],'report_review_status':review['status'],'conditions':24,'independent_seed_streams':4,'nested_sizes':[8,20,40],'candidate_rows_replayed':406,'endpoint_rows_verified':568,'valid_routes':18,'P_valid_routes':6,'P_denominator':12,'C_valid_routes':12,'C_denominator':12,'endpoint_infeasible_conditions':6,'route_segment_uses_verified':716,'unique_route_segments_verified':369,'saved_matrix_path_entries_verified':11618,'minimum_route_clearance_interval_m':core['global_route_minimum_clearance_interval_m'],'minimum_C_boundary_clearance_interval_m':core['C_minimum_clearance_interval_m'],'serialization_precision':review['serialization_precision'],'old_files_unchanged':262,'input_copies_unchanged':7,'frozen_files_unchanged':True,'raw_files_unchanged':True,'actual_planner_rerun':False,'author_planner_imported':False,'new_real_candidates_generated':False,'raw_archive_sha256':core['archives']['RAW']['sha256'],'preexec_archive_sha256':core['archives']['PREEXECUTION']['sha256'],'independent_result_sha256':sha(R/'independent_review/results/INDEPENDENT_SAVED_RECOMPUTATION.json'),'independent_report_sha256':sha(R/path),'final_author_report_sha256':sha(R/'reports/REPORT_zh.md'),'final_report_checks_sha256':sha(R/'independent_review/evidence/FINAL_REPORT_CHECKS.json'),'author_report_files_sha256':review['reviewed_report_files'],'review_code_sha256':{str(p.relative_to(R)):sha(p) for p in sorted((R/'independent_review/source').glob('*.py'))},'core_review_processes':{'count':2,'first_stopped_on_overstrict_serialization_identity_assertion':True,'second_passed':True,'experiment_not_rerun':True,'total_cpu_seconds':sum(r['children_cpu_seconds'] for r in runs),'total_wall_seconds':sum(r['wall_seconds'] for r in runs),'peak_rss_kib':max(r['peak_rss_kib'] for r in runs)},'limitations':['No independent shortest-path re-solve or continuous optimality claim.','Four dependent nested streams in one field; descriptive comparison only.','Hypothetical disk geometry, not a machinery or survey-accuracy certificate.']}
save('independent_review/results/FINAL_STATUS.json',status)
print(json.dumps({'status':status['status'],'report_sha256':status['independent_report_sha256'],'final_status_sha256':sha(R/'independent_review/results/FINAL_STATUS.json'),'raw_unchanged':True}))
