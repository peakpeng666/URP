#!/usr/bin/python3
"""Final saved-report/figure audit; no generation, planner or author imports."""
import csv,datetime,hashlib,json,math,pathlib,struct,time,xml.etree.ElementTree as ET
from fractions import Fraction as F
from geometry_exact import parse_wkt
R=pathlib.Path(__file__).resolve().parents[2]
def load(p):return json.loads((R/p).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def close(a,b,tol=1e-8):assert abs(a-b)<=tol,(a,b)
def main():
    start=time.perf_counter();core=load('independent_review/results/INDEPENDENT_SAVED_RECOMPUTATION.json');protocol=load('freeze/PROTOCOL.json');summary=load('reports/summary.json')
    independent={r['instance_id']:r for r in core['all_24_conditions']};rows=load('reports/all_24_conditions.json')
    assert len(rows)==len(independent)==24 and [r['instance_id'] for r in rows]==list(independent)
    for row in rows:
        r=independent[row['instance_id']];ins=load('raw/'+row['instance_id']+'_input.json');ep=load('raw/'+row['instance_id']+'_endpoints.json')
        assert row['arm']==r['arm'] and row['n']==r['n'] and row['seed']==r['seed'] and row['status']==r['status']
        assert row['sample_complete'] and row['sampled_tasks']==r['n'] and row['all_endpoints_exact_1_10m_pass']==r['exact_endpoint_pass']
        assert row['exact_failing_task_count']==sum(not s['exact_1_10m_endpoint_pass'] for s in ep['services'][1:])
        assert row['numeric_failing_service_ids']==r['failing_ids'] and row['safe_but_excluded_from_C_ids']==r['safe_C_exclusions']
        assert row['solver_calls']==r['solver_calls'] and row['candidate_draws']==ins['sampling']['candidate_draws_to_prefix'] and row['rejections']==ins['sampling']['rejected_draws']
        if r['status']=='VALID_SAFE_ROUTE':close(row['length_m'],r['length_m'])
        else:assert row['length_m'] is None
    csvrows=list(csv.DictReader((R/'reports/all_24_conditions.csv').open()))
    for actual,expected in zip(csvrows,rows):
        assert actual=={k:json.dumps(v) if isinstance(v,list) else '' if v is None else str(v) for k,v in expected.items()}
    assert len(csvrows)==24
    agg=[]
    for arm in protocol['arms']:
        for n in protocol['sizes']:
            rr=[r for r in rows if r['arm']==arm and r['n']==n]
            agg.append({'arm':arm,'n':n,'denominator':4,'sampling_complete':4,'exact_endpoint_pass':sum(r['all_endpoints_exact_1_10m_pass'] for r in rr),'safe_routes':sum(r['status']=='VALID_SAFE_ROUTE' for r in rr),'status_counts':{s:sum(r['status']==s for r in rr) for s in sorted(set(r['status'] for r in rr))},'candidate_draws_total':sum(r['candidate_draws'] for r in rr),'rejections_total':sum(r['rejections'] for r in rr)})
    assert summary['by_arm_size']==agg and summary['total_instances']==24 and summary['seed_streams']==4 and summary['nested_pairs']==12 and summary['nn_calls']==18
    for arm in ['P','C']:
        assert summary['counts_by_arm'][arm]['exact_endpoint_pass']==core['counts_by_arm'][arm]['exact_endpoint_pass']
        assert summary['counts_by_arm'][arm]['safe_routes']==core['counts_by_arm'][arm]['valid_safe_routes']
    assert summary['raw_sha256']==sha(R/'raw/results.json')
    paired=[]
    for seed in protocol['seeds']:
        for n in protocol['sizes']:
            p=load(f'raw/P_n{n:02d}_s{seed}_input.json')['sampling'];c=load(f'raw/C_n{n:02d}_s{seed}_input.json')['sampling'];overlap=len(set(p['accepted_candidate_indices'])&set(c['accepted_candidate_indices']))
            paired.append({'seed':seed,'n':n,'shared_task_candidate_count':overlap,'shared_fraction_of_requested_n':overlap/n,'P_candidate_draws':p['candidate_draws_to_prefix'],'C_candidate_draws':c['candidate_draws_to_prefix'],'C_minus_P_draws':c['candidate_draws_to_prefix']-p['candidate_draws_to_prefix']})
    assert paired==load('reports/paired_sampling.json')==summary['paired_sampling']
    assert list(csv.DictReader((R/'reports/paired_sampling.csv').open()))==[{k:str(v) for k,v in row.items()} for row in paired]
    post=load('reports/posthoc_area_reference.json');ratio=core['exact_area']['C_to_P'];close(post['area_C_over_P'],ratio)
    assert post['label']=='POST_HOC_EXPLANATORY_REFERENCE_NOT_PREREGISTERED_OUTCOME' and post['no_additional_sampling_or_solver_calls'] and post['no_significance_test']
    assert [r['n'] for r in post['rows']]==[8,20,40]
    for row in post['rows']:close(row['probability_all_n_in_C_ideal_model'],ratio**row['n'])
    first=load('reports/first_failure_points.json');assert [r['seed'] for r in first]==protocol['seeds']
    for row in first:
        name=f"P_n40_s{row['seed']}";ind=independent[name];ins=load('raw/'+name+'_input.json');ep=load('raw/'+name+'_endpoints.json');failed=[i for i in ind['failing_ids'] if i>0]
        task=failed[0] if failed else None;assert row['first_exact_1_10m_failing_P_task_id']==task
        if task is None:assert row['candidate_index'] is None and row['coordinate'] is None and row['observed_minimum_clearance_m'] is None
        else:
            assert row['coordinate']==ins['coordinates'][task] and row['candidate_index']==ins['sampling']['accepted_candidate_indices'][task-1]
            close(row['observed_minimum_clearance_m'],ep['services'][task]['minimum_clearance_m'])
    # SVG: inspect all coordinates, exact-failure colors, unchanged depot positions and panel labels.
    root=ET.fromstring((R/'reports/n40_paired_distribution.svg').read_text());ns={'s':'http://www.w3.org/2000/svg'}
    circles=root.findall('s:circle',ns);paths=root.findall('s:path',ns);texts=[e.text for e in root.findall('s:text',ns)]
    assert len(circles)==320 and len(paths)==16 and all(p.attrib['fill-rule']=='evenodd' for p in paths)
    assert all(p.attrib['d'].count('M ')==4 for p in paths)
    pg=parse_wkt((R/'input/projected_epsg32634.wkt').read_text());points=[[float(v) for v in p] for p in pg[0][0]];xmin,xmax=min(p[0] for p in points),max(p[0] for p in points);ymin,ymax=min(p[1] for p in points),max(p[1] for p in points);scale=min(480/(xmax-xmin),270/(ymax-ymin));pos=0;panel_failure_counts=[]
    for ri,seed in enumerate(protocol['seeds']):
        for ci,arm in enumerate(['P','C']):
            name=f'{arm}_n40_s{seed}';ep=load('raw/'+name+'_endpoints.json');assert f'{arm}, seed {seed}: '+independent[name]['status'] in texts
            for s in ep['services'][1:]:
                elem=circles[pos];pos+=1;x,y=s['coordinate'];xx=28+ci*560+40+(x-xmin)*scale;yy=84+ri*342+34+(ymax-y)*scale
                assert elem.attrib['cx']==f'{xx:.3f}' and elem.attrib['cy']==f'{yy:.3f}' and elem.attrib['fill']==('#2563eb' if s['exact_1_10m_endpoint_pass'] else '#dc2626')
            panel_failure_counts.append({'instance_id':name,'exact_failing_tasks':sum(not s['exact_1_10m_endpoint_pass'] for s in ep['services'][1:])})
    depots=[r for r in root.findall('s:rect',ns) if r.attrib.get('fill')=='#111827'];assert len(depots)==8
    for idx,rect in enumerate(depots):
        ri,ci=divmod(idx,2);x,y=protocol['depot'];xx=28+ci*560+40+(x-xmin)*scale;yy=84+ri*342+34+(ymax-y)*scale
        assert rect.attrib['x']==f'{xx-4:.3f}' and rect.attrib['y']==f'{yy-4:.3f}'
    png=(R/'reports/n40_paired_distribution.png').read_bytes();assert png[:8]==b'\x89PNG\r\n\x1a\n';width,height=struct.unpack('>II',png[16:24]);assert width>1000 and height>1500
    wktnodes=[q for poly in parse_wkt((R/'raw/center_region.wkt').read_text()) for ring in poly for q in ring];graphnodes=load('raw/shared_preprocessing.json')['nodes'];differences=[[abs(F(str(a[k]))-F(b[k])) for k in (0,1)] for a,b in zip(graphnodes,wktnodes)]
    precision={'differing_nodes':sum(any(p) for p in differences),'total_nodes':len(differences),'differing_coordinates':sum(v!=0 for p in differences for v in p),'total_coordinates':2*len(differences),'maximum_exact_decimal_difference_fraction':str(max(v for p in differences for v in p)),'maximum_exact_decimal_difference_m':float(max(v for p in differences for v in p)),'maximum_binary64_subtraction_difference_m':max(abs(a[k]-float(b[k])) for a,b in zip(graphnodes,wktnodes) for k in (0,1)),'effect_on_saved_route_clearance_conclusion':'None: all18 full saved-coordinate routes independently pass original-boundary/hole checks.'}
    assert precision['differing_nodes']==452 and precision['differing_coordinates']==820 and precision['maximum_exact_decimal_difference_fraction']=='1/200000000'
    report=(R/'reports/REPORT_zh.md').read_text()
    for s in ['不是历史任务生成的原样复刻','不能称为算法救回原任务','不做显著性','事后解释','不是预注册检验','不是实际有限离散生成器的精确概率','不等于精确1.1米可行率或NN成功率','历史12实例也未被更改']:assert s in report,s
    for a in agg:assert f"| {a['arm']} | {a['n']} | {a['exact_endpoint_pass']} | {a['safe_routes']} | {a['candidate_draws_total']} | {a['rejections_total']} |" in report
    result={'status':'PASS_SAVED_REPORT_DATA_AND_FIGURE_CHECKS','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'author_summary_status':summary['status'],'verified_24_json_and_csv_rows':True,'verified_12_paired_json_and_csv_rows':True,'verified_6_aggregate_rows':True,'posthoc_ideal_model_reference_verified':True,'posthoc_not_preregistered_or_generator_exact_probability':True,'first_failure_points_verified':True,'panel_failure_counts':panel_failure_counts,'SVG_all_320_point_coordinates_and_colors_verified':True,'SVG_all_8_depots_verified':True,'SVG_all_16_regions_keep_three_holes':True,'PNG_dimensions':[width,height],'PNG_visual_inspection':'Parent-independent reviewer inspected complete PNG: all 8 panels legible, P failures 1/3/0/3 and C 0/0/0/0, matching saved data; holes and fixed depots visible; no clipping observed.','serialization_precision':precision,'reviewed_report_files':{str(p.relative_to(R)):sha(p) for p in sorted((R/'reports').iterdir()) if p.is_file()},'wall_seconds':time.perf_counter()-start}
    (R/'independent_review/evidence/FINAL_REPORT_CHECKS.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps({'status':result['status'],'author_status':summary['status'],'serialization_precision':precision}))
if __name__=='__main__':main()
