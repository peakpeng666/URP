# Independent static and synthetic pre-execution review

Status: PASS_STATIC_PREEXEC_REVIEW

This pass authorizes only the next freeze/archive gate. It is not a result, route-safety certificate, or confirmation that a PREEXEC or RAW upload has occurred.

## Research design

The experiment changes synthetic task generation. P and conservative C are sampled from the same bounding-box candidate sequence, with all three holes excluded and all C components eligible. Four prescribed streams have nested 8/20/40 prefixes: 24 conditions and at most 24 NN invocations. Accepted P rows beyond 40 are retained when C needs more draws. Cap exhaustion remains a failure without reseeding. Binary64 pseudorandom sampling is explicitly an approximation to continuous area uniformity. Historical integer-grid tasks and their random depots are not claimed as replicated or rescued.

The fixed depot is byte-identical to the previously saved seed-1001 depot. Its independently recomputed exact serialized-coordinate clearance lies in [4.401724777438, 4.401724777439] m and it is in C. Seven input copies and 262 historical artifact hashes match. P has three holes; saved C has one component. No real candidate stream was generated and no real graph or route was computed during this review.

## Exact and conservative geometry

Independent review code uses its own WKT topology parsing, decimal-grid integers, ray-parity containment, rational projections, segment intersections and shoelace areas. It does not import the author planner. Synthetic checks distinguish exact d >= 1.10 m from the numeric tolerance band, preserve safe-but-C-excluded endpoints, handle holes, multipolygon components, complete-segment crossings, tangencies, and degenerate segments. Candidate replay independently validates saved synthetic RNG draws, membership, reasons, ranks, counters and all prefixes. Fault injection checks duplicate/depot rejection and partial trace retention.

C remains the prior byte-identical conservative polygon, not the analytic erosion set. Endpoint feasibility is necessary only; C exclusion/disconnection is not proof of infeasibility in the exact center domain. All 24 endpoints are scheduled before fresh shared graph construction. Dijkstra paths cannot use other service vertices internally. Only the single NN call site is reached by eligible instances; legacy 2-opt code is present but has no formal call.

## Execution controls

The six identified pre-review issues are fixed: stale review hashes, graph-failure classification, invalid-route public lengths, signal termination labels, partial sampling journal, and bounding-box area ratios. Exclusive-created STARTED plus parent-process identity and frozen hash checks support one attempt. Nested phase timers and the 180 CPU-second / 300 wall-second / 1 GiB subprocess bounds are explicit. Private PREEXEC receipt and byte-identical readback are required before execution; saved reporting requires private RAW receipt. Failed or aborted conditions receive a retained 24-condition inventory. Hard kill may leave one in-flight row or partial artifact incomplete; no result-dependent retry is permitted.

## Remaining gates and limits

The parent must now freeze exactly the reviewed files, upload/read back private PREEXEC, perform at most one formal attempt, and seal/upload/read back RAW before saved-result review or interpretation. These future actions were not performed by this reviewer. Later independent review must verify archive member hashes and chronology, every saved candidate/prefix/endpoint/classification, all used route segments, NN order against the saved matrix, lengths, task visits and depot closure. It must not re-run the planner. Route/region correctness is limited to exact serialized geometry and the hypothetical disk model; no dynamics, localization or survey-accuracy certificate is provided.
