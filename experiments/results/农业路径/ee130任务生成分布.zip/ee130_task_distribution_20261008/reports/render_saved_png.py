"""Post-run visualization only, from archived saved inputs; no sampling or planning."""
from pathlib import Path
import json
from osgeo import ogr
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
from matplotlib.lines import Line2D
R=Path(__file__).resolve().parents[1]
protocol=json.loads((R/'freeze/PROTOCOL.json').read_text())
field=ogr.CreateGeometryFromWkt((R/'input/projected_epsg32634.wkt').read_text())
center=ogr.CreateGeometryFromWkt((R/'input/prior/center_region.wkt').read_text())
def coords(ring):return [ring.GetPoint(i)[:2] for i in range(ring.GetPointCount())]
fig,axes=plt.subplots(4,2,figsize=(12,16),constrained_layout=True)
for si,seed in enumerate(protocol['seeds']):
  for ai,arm in enumerate(['P','C']):
    ax=axes[si,ai];ax.add_patch(Polygon(coords(field.GetGeometryRef(0)),facecolor='#e2e8f0',edgecolor='#334155',lw=.8))
    cc=[center] if center.GetGeometryName()=='POLYGON' else [center.GetGeometryRef(i) for i in range(center.GetGeometryCount())]
    for c in cc:
      ax.add_patch(Polygon(coords(c.GetGeometryRef(0)),facecolor='#dcfce7',edgecolor='#16a34a',lw=.7))
      for ri in range(1,c.GetGeometryCount()):ax.add_patch(Polygon(coords(c.GetGeometryRef(ri)),facecolor='#e2e8f0',edgecolor='#16a34a',lw=.7))
    for ri in range(1,field.GetGeometryCount()):ax.add_patch(Polygon(coords(field.GetGeometryRef(ri)),facecolor='white',edgecolor='#334155',lw=.8))
    ep=json.loads((R/f'raw/{arm}_n40_s{seed}_endpoints.json').read_text())
    result=json.loads((R/f'raw/{arm}_n40_s{seed}_result.json').read_text())
    for s in ep['services'][1:]:
      x,y=s['coordinate'];ax.scatter([x],[y],s=20,color='#2563eb' if s['exact_1_10m_endpoint_pass'] else '#dc2626',zorder=4)
    x,y=ep['services'][0]['coordinate'];ax.scatter([x],[y],s=40,color='#111827',marker='s',zorder=5)
    fails=sum(not s['exact_1_10m_endpoint_pass'] for s in ep['services'][1:])
    label='valid NN route' if result['status']=='VALID_SAFE_ROUTE' else 'endpoint infeasible' if result['status']=='TASK_INFEASIBLE' else result['status']
    ax.set_title(f'{arm}, seed {seed}\n{label}; exact endpoint failures {fails}/40',fontsize=10)
    ax.autoscale_view();ax.set_aspect('equal');ax.set_xticks([]);ax.set_yticks([])
    for spine in ax.spines.values():spine.set_visible(False)
fig.suptitle('EE130: paired task-generation distributions (n=40)\nFour shared candidate streams on one field; C is a conservative 1.1 m center region',fontsize=14)
handles=[Line2D([0],[0],marker='o',linestyle='',color='#2563eb',label='Exact endpoint clearance >=1.1 m'),Line2D([0],[0],marker='o',linestyle='',color='#dc2626',label='Exact endpoint clearance <1.1 m'),Line2D([0],[0],marker='s',linestyle='',color='#111827',label='Unchanged fixed depot')]
fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(0.5,-0.02),ncol=3,fontsize=9)
fig.savefig(R/'reports/n40_paired_distribution.png',dpi=140,bbox_inches='tight',facecolor='white')
