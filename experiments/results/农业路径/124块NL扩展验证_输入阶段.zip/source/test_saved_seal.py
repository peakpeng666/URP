"""Saved-only replay of the approved five synthetic fields; no geometry or optimizer."""
from pathlib import Path
import sys,shutil
from launch_main_once import seal
from common import ROOT,read,save

def main():
 dest=ROOT/'selftests'/sys.argv[1];dest.mkdir();(dest/'raw').mkdir()
 source=ROOT/'selftests/input_stage_r1/workspace/raw'
 for directory in ['fields','calls','active']:shutil.copytree(source/directory,dest/'raw'/directory)
 shutil.copy2(source/'field_results.jsonl',dest/'raw/field_results.jsonl')
 fields=[dict(id=f)for f in ['convex','concave','hole','empty','split']]
 seal(dest,dest/'raw',[],fields,'SYNTHETIC_NOT_AUTHORIZATION',dict(synthetic_only=True))
 rows=read(dest/'raw/ALL_FIELD_SLOTS.json');assert len(rows)==5 and sum(r['author_pass_unreviewed']for r in rows)==3
 for r in rows:
  if r['instance_id']in['convex','concave','hole']:assert r['preprocess']['exists']and r['preprocess']['bytes']>0
  else:assert not r['preprocess']['exists']and r['execution']['process_spawned']is True and not r['author_pass_unreviewed']
 outer=read(dest/'raw/OUTER_FINISHED.json');assert outer['known_spawned_geometry_workers']==5 and outer['unknown_spawned_geometry_workers']==0 and outer['not_started_geometry_slots']==0
 save(dest/'REPORT.json',dict(status='PASS',synthetic_only=True,source='selftests/input_stage_r1',new_geometry_calls=0,optimizer_calls=0,native_calls=0,retained=5,author_pass_unreviewed=3,known_spawned=5,preprocess_hash_interface_verified=True))
 print('PASS saved-only seal interface')
if __name__=='__main__':main()
