"""Only formal author entry point; unique gate, whole-tree watchdog, loss-aware slot ledger."""
import resource,time,pathlib,sys,json
from common import ROOT,read,save,sha,utc,inventory
from gates import main_ready
from tree_runtime import run_command
from process_groups import cleanup_registered

def seal(base,dest,schedule,fields,digest,outer):
 dest.mkdir(exist_ok=True);rows=[];bad=[]
 if (dest/'results.jsonl').exists():
  for i,line in enumerate((dest/'results.jsonl').read_text().splitlines()):
   try:rows.append(json.loads(line))
   except Exception:bad.append(i)
 by={r['schedule']['call_id']:r for r in rows};allslots=[]
 for s in schedule:
  cid=s['call_id'];exists=(dest/'calls'/(cid+'.stdout')).exists()
  allslots.append(by.get(cid,dict(schedule=s,status='UNKNOWN_AFTER_SUPERVISOR_FAILURE'if exists else'NOT_STARTED_SUPERVISOR_FAILURE',process_spawned='UNKNOWN'if exists else False)))
 # Data-only stage: the actual124 launches are in field_results, not results.
 # Preserve the same loss-aware known/unknown/not-started contract for those slots.
 frows=[];fbad=[];fmap={};duplicates=[]
 if (dest/'field_results.jsonl').exists():
  for i,line in enumerate((dest/'field_results.jsonl').read_text().splitlines(),1):
   try:
    row=json.loads(line)
    if not isinstance(row,dict)or not isinstance(row.get('instance_id'),str):raise ValueError('FIELD_ROW_SCHEMA')
    frows.append(row);fid=row['instance_id']
    if fid in fmap:duplicates.append(fid)
    fmap[fid]=row
   except Exception:fbad.append(i)
 fs=[]
 for field in fields:
  fid=field['id'];p=dest/'fields'/fid/'FIELD_FINISHED.json'
  evidence={name:path.exists() for name,path in {
   'stdout':dest/'calls'/(fid+'_geometry.stdout'),
   'active_registration':dest/'active'/(fid+'_geometry.active.json'),
   'worker_started':dest/'fields'/fid/'FIELD_STARTED.json'}.items()}
  execution=fmap.get(fid)
  if execution is None or fid in duplicates:
   possible=any(evidence.values())
   execution=dict(instance_id=fid,status='UNKNOWN_AFTER_SUPERVISOR_FAILURE'if possible else'NOT_STARTED_SUPERVISOR_FAILURE',process_spawned='UNKNOWN'if possible else False)
  try:
   result=read(p)if p.exists()else dict(status='UNKNOWN_OR_NOT_STARTED_AFTER_SUPERVISOR_FAILURE')
   if not isinstance(result,dict):raise ValueError('FIELD_FINISHED_SCHEMA')
  except (ValueError,OSError)as exc:result=dict(status='UNKNOWN_TRUNCATED_FIELD_FINISHED',error=type(exc).__name__)
  matrix_path=dest/'fields'/fid/'preprocess.json'
  matrix_record=dict(exists=matrix_path.is_file(),path=str(matrix_path.relative_to(base)))
  if matrix_record['exists']:matrix_record.update(bytes=matrix_path.stat().st_size,sha256=sha(matrix_path))
  expected=result.get('inputs',[]) if isinstance(result,dict)else[]
  matrix_identity_ok=matrix_record['exists']and isinstance(expected,list)and len(expected)==1 and isinstance(expected[0],dict)and expected[0].get('kind')=='FROZEN_Q5_MATRICES'and expected[0].get('filename')=='preprocess.json'and expected[0].get('sha256')==matrix_record.get('sha256')
  author_pass=execution.get('status')=='UNREVIEWED_PROCESS_SUCCESS'and execution.get('child_reaped')is True and result.get('status')=='PASS_PREPROCESS'and matrix_identity_ok
  fs.append(dict(instance_id=fid,execution=execution,execution_evidence=evidence,result=result,preprocess=matrix_record,author_pass_unreviewed=author_pass,readiness_note='Requires independent input PASS and actual private archive byte readback; file presence alone never authorizes solving.'))
 save(dest/'ALL_PLANNED_SLOTS.json',allslots);save(dest/'ALL_FIELD_SLOTS.json',fs);save(dest/'OUTER_FINISHED.json',dict(utc=utc(),outer=outer,status='RAW_MAIN_UNREVIEWED_INPUT_DATA_ONLY',all_planned_fields=len(fields),all_planned_calls=len(schedule),malformed_rows=bad,duplicate_call_ids=len(by)!=len(rows),malformed_field_rows=fbad,duplicate_field_ids=duplicates,known_spawned_geometry_workers=sum(r['execution'].get('process_spawned')is True for r in fs),unknown_spawned_geometry_workers=sum(r['execution'].get('process_spawned')=='UNKNOWN'for r in fs),not_started_geometry_slots=sum(r['execution'].get('process_spawned')is False for r in fs),optimizer_calls=0,native_model_instances=0))
 save(dest/'RAW_MAIN_CONTENT_MANIFEST.json',dict(utc=utc(),frozen_files_sha256=digest,files=inventory(base,[p for p in dest.rglob('*')if p.is_file()])))

def author_outer_limits():
 # Same soft/self versus hard/descendant separation used by the audited strong-baseline r1 supervisor.
 resource.setrlimit(resource.RLIMIT_AS,(536870912,1073741824));resource.setrlimit(resource.RLIMIT_CPU,(60,120))
 return {'cpu':list(resource.getrlimit(resource.RLIMIT_CPU)),'as':list(resource.getrlimit(resource.RLIMIT_AS))}

def main():
 assert __debug__;limits=author_outer_limits();d=main_ready();fields=read(ROOT/'input/provenance/PANEL_SOURCE_READY_PROPOSAL.json')['candidates'];schedule=read(ROOT/'freeze/SCHEDULE.json')
 save(ROOT/'provenance/MAIN_LAUNCH_STARTED.json',dict(utc=utc(),frozen_files_sha256=d,planned_fields=124,planned_main_calls=0,planned_independent_calls=0,whole_supervisor_tree_wall_seconds=22860,outer_soft_hard_limits=limits))
 outer=run_command(['/usr/bin/python3',ROOT/'source/run_author_batch.py'],ROOT/'provenance/author_supervisor',60,536870912,22860,ROOT/'provenance/author_supervisor.active.json',cpu_hard=120,as_hard=1073741824)
 cleanup=cleanup_registered(ROOT/'raw/active');save(ROOT/'provenance/WHOLE_TREE_CLEANUP.json',cleanup)
 if outer.get('process_spawned')and not(outer.get('registered_group_cleanup')or{}).get('quiescent'):raise RuntimeError('OUTER_GROUP_NOT_QUIESCENT_CANNOT_SEAL')
 if not cleanup['quiescent']:raise RuntimeError('CHILD_TREE_NOT_QUIESCENT_CANNOT_SEAL')
 seal(ROOT,ROOT/'raw',schedule,fields,d,outer);print('Raw input data sealed locally. Private RAW_MAIN readback and separate root approval required before independent inputs; no optimizers were scheduled.')
if __name__=='__main__':main()
