"""Frozen geometry-input generation. This module never selects a service visit order."""
import json,math,time,random,heapq,resource,pathlib,sys,traceback
from decimal import Decimal,ROUND_HALF_UP,localcontext
from fractions import Fraction
from osgeo import ogr,gdal
from pyproj import CRS,Transformer,network,__version__ as pyproj_version,proj_version_str
from common import ROOT,read,save,sha,append,utc
from input_numeric_bounds import derive_bounds
from author_geometry import rings_from_wkt,segment_check,distance80,interior
ogr.UseExceptions()
TOL=1e-8;RADIUS=1.1;BUFFER=(1.1+1e-5)/math.cos(math.pi/32)

def polygon_coords(g):return [[[float(g.GetGeometryRef(i).GetX(j)),float(g.GetGeometryRef(i).GetY(j))]for j in range(g.GetGeometryRef(i).GetPointCount())]for i in range(g.GetGeometryCount())]
def serialize(g):
 name=g.GetGeometryName()
 if name=='POLYGON':return 'POLYGON ('+', '.join('('+', '.join(' '.join(repr(x)for x in p)for p in r)+')'for r in polygon_coords(g))+')'
 if name=='MULTIPOLYGON':return 'MULTIPOLYGON ('+', '.join(serialize(g.GetGeometryRef(i))[8:]for i in range(g.GetGeometryCount()))+')'
 raise ValueError('UNSUPPORTED_GEOMETRY:'+name)
def point(p):
 q=ogr.Geometry(ogr.wkbPoint);q.AddPoint_2D(*p);return q
def line(a,b):
 if a==b:return point(a)
 g=ogr.Geometry(ogr.wkbLineString);g.AddPoint_2D(*a);g.AddPoint_2D(*b);return g
def components(g):
 if g.IsEmpty():return []
 if g.GetGeometryName()=='POLYGON':return [g]
 if g.GetGeometryName()=='MULTIPOLYGON':return [g.GetGeometryRef(i).Clone()for i in range(g.GetGeometryCount())]
 raise ValueError('UNSUPPORTED_CENTER_GEOMETRY')
def convex_native(wkt):
 rs=rings_from_wkt(wkt)
 if len(rs)!=1:return False
 r=rs[0];signs=set()
 for i,b in enumerate(r):
  a,c=r[i-1],r[(i+1)%len(r)];v=(b[0]-a[0])*(c[1]-b[1])-(b[1]-a[1])*(c[0]-b[0])
  if v:signs.add(1 if v>0 else -1)
 return len(signs)==1

def project(wkt,source_prj,target_epsg):
 network.set_network_enabled(False);t=Transformer.from_crs(CRS.from_wkt(source_prj),CRS.from_epsg(target_epsg),always_xy=True)
 raw=ogr.CreateGeometryFromWkt(wkt);assert raw.IsValid()and raw.GetGeometryName()=='POLYGON'
 coords=polygon_coords(raw);out=[];residual=0.
 for ring in coords:
  rr=[]
  for a,b in ring:
   x,y=t.transform(a,b,errcheck=True);assert math.isfinite(x)and math.isfinite(y);rr.append([x,y]);lon,lat=t.transform(x,y,direction='INVERSE',errcheck=True);residual=max(residual,abs(lon-a),abs(lat-b))
  out.append(rr)
 projected='POLYGON ('+', '.join('('+', '.join(' '.join(repr(x)for x in p)for p in r)+')'for r in out)+')'
 p=ogr.CreateGeometryFromWkt(projected);assert p.IsValid()and not p.IsEmpty()and polygon_coords(p)==out and residual<=1e-8
 return p,projected,dict(source_crs_wkt=source_prj,target_epsg=target_epsg,always_xy=True,pipeline=t.definition,description=t.description,pyproj_version=pyproj_version,proj_version=proj_version_str,gdal_version=gdal.VersionInfo(),network_enabled=network.is_network_enabled(),maximum_roundtrip_absolute_degrees=residual,serialization='repr binary64 round-trip coordinates; no simplification',original_vertex_counts=list(map(len,coords)),projected_vertex_counts=list(map(len,out)),projected_convex_no_hole=convex_native(projected))

def construct(p):
 c=p.Buffer(-BUFFER,16);cs=components(c)
 if not cs:return c,[],dict(status='EMPTY_CONSERVATIVE_CENTER',components=0)
 if not c.IsValid()or not c.Difference(p).IsEmpty():return c,[],dict(status='INVALID_OR_OUTSIDE_CONSERVATIVE_CENTER')
 clearance=c.Distance(p.Boundary())
 if not clearance>RADIUS+TOL:return c,[],dict(status='CENTER_NUMERIC_CLEARANCE_FAILURE',minimum_numeric_clearance_m=clearance)
 nodes=[];rings=[]
 for ci,part in enumerate(cs):
  for ri,ring in enumerate(polygon_coords(part)):
   ids=list(range(len(nodes),len(nodes)+len(ring)-1));nodes.extend(ring[:-1]);rings.append(dict(component=ci,ring=ri,nodes=ids))
 if len(nodes)>800:return c,nodes,dict(status='CENTER_VERTEX_RESOURCE_LIMIT',vertices=len(nodes),cap=800)
 if len(set(map(tuple,nodes)))!=len(nodes):return c,nodes,dict(status='DUPLICATE_CENTER_VERTICES')
 cw=serialize(c);assert serialize(ogr.CreateGeometryFromWkt(cw))==cw
 return c,nodes,dict(status='CENTER_NUMERIC_PASS',components=len(cs),component_areas_m2=[x.GetArea()for x in cs],component_holes=[x.GetGeometryCount()-1 for x in cs],vertices=len(nodes),rings=rings,buffer_distance_m=BUFFER,quadrant_segments=16,center_area_m2=c.GetArea(),original_area_m2=p.GetArea(),minimum_numeric_clearance_m=clearance,center_convex_no_hole=len(cs)==1 and convex_native(serialize(cs[0])),center_vertex_order='component, ring, stored coordinate order',center_serialization_roundtrip=True)

def sample(p,c,seed,n,cap,sink):
 rng=random.Random(seed);xmin,xmax,ymin,ymax=p.GetEnvelope();accepted=[];seen=set();draws=0
 for draws in range(1,cap+1):
  ux,uy=rng.random(),rng.random();xy=[xmin+(xmax-xmin)*ux,ymin+(ymax-ymin)*uy];g=point(xy);inside=bool(c.Contains(g));key=tuple(xy)
  reason='OUTSIDE_C'if not inside else'DUPLICATE'if key in seen else'ACCEPT'
  if reason=='ACCEPT':
   assert p.Contains(g);seen.add(key);accepted.append(dict(candidate_index=draws,coordinate=xy))
  sink(dict(candidate_index=draws,unit_random=[ux,uy],coordinate=xy,strict_in_C=inside,reason=reason,accepted_rank=len(accepted)if reason=='ACCEPT'else None))
  if len(accepted)==n+1:break
 return dict(seed=seed,n=n,target_points_including_depot=n+1,cap=cap,draws=draws,accepted=accepted,complete=len(accepted)==n+1,selection='first accepted is depot; next n accepted are tasks; no component conditioning')

def safe_edge(a,b,c,p,boundary):
 if a==b:return False
 g=line(a,b)
 return bool(g.Difference(c).IsEmpty()and g.Difference(p).IsEmpty()and g.Distance(boundary)>RADIUS+TOL)
def dijkstra(adj,s,base):
 ds=[math.inf]*len(adj);paths=[None]*len(adj);ds[s]=0.;paths[s]=(s,);q=[(0.,(s,),s)]
 while q:
  d,path,u=heapq.heappop(q)
  if (d,path)!=(ds[u],paths[u]):continue
  if u>=base and u!=s:continue
  for v,w in adj[u]:
   cand=(d+w,path+(v,))
   if cand[0]<ds[v]or(cand[0]==ds[v]and(paths[v]is None or cand[1]<paths[v])):ds[v],paths[v]=cand;heapq.heappush(q,(cand[0],cand[1],v))
 return ds,paths

def build_graph(p,c,base_nodes,coords):
 nodes=base_nodes+coords;base=len(base_nodes);boundary=p.Boundary();edges=[];adj=[[]for _ in nodes];checks=0
 assert len(nodes)<=813
 for i,a in enumerate(nodes):
  for j in range(i+1,len(nodes)):
   checks+=1
   if safe_edge(a,nodes[j],c,p,boundary):
    w=math.hypot(a[0]-nodes[j][0],a[1]-nodes[j][1]);assert w>0
    edges.append([i,j,w]);adj[i].append((j,w));adj[j].append((i,w))
 ds=[dijkstra(adj,base+i,base)for i in range(len(coords))];bad=[[i,j]for i in range(len(coords))for j in range(i+1,len(coords))if not math.isfinite(ds[i][0][base+j])]
 graph=dict(nodes=nodes,service_node_ids=list(range(base,len(nodes))),base_count=base,edges=edges,edge_count=len(edges),candidate_edge_checks=checks,unreachable_service_pairs=bad,edge_geometry_method='GEOS closed inclusion in C/P and numeric clearance >1.10+1e-8; exact rational audit all service-pair saved path segments below',shortest_path_rule='Dijkstra finite numerical graph, other service vertices terminal only; i<j path and reverse reuse')
 if bad:return graph,None,None
 N=len(coords);G=[[0.]*N for _ in coords];paths=[[None]*N for _ in coords];asym=0.
 for i in range(N):
  paths[i][i]=[base+i]
  for j in range(i+1,N):
   path=list(ds[i][1][base+j]);value=math.fsum(math.hypot(nodes[a][0]-nodes[b][0],nodes[a][1]-nodes[b][1])for a,b in zip(path,path[1:]));asym=max(asym,abs(ds[i][0][base+j]-ds[j][0][base+i]));assert abs(value-ds[i][0][base+j])<=TOL
   assert all(v<base for v in path[1:-1])and len(set(path))==len(path)
   G[i][j]=G[j][i]=value;paths[i][j]=path;paths[j][i]=path[::-1]
 assert asym<=TOL;graph['distance_max_asymmetry_m']=asym
 return graph,G,paths

def quantize(v):
 d=Decimal(str(v));assert d.is_finite()and d>=0;q=int((d*1000).to_integral_value(rounding=ROUND_HALF_UP));assert abs(Decimal(q)/1000-d)<=Decimal('0.0005');return q

def finalize(ident,n,coords,graph,G,paths,rings):
 nodes=graph['nodes'];N=n+1;checks={};pairchecks=[];passages=[];E=[[0.]*N for _ in coords]
 endpoints=[dict(service_id=i,**segment_check(p,p,rings))for i,p in enumerate(coords)]
 if not all(r['exact_safe']for r in endpoints):raise RuntimeError('EXACT_ENDPOINT_CLEARANCE_OR_CONTAINMENT_FAILURE')
 for i in range(N):
  for j in range(i+1,N):
   E[i][j]=E[j][i]=math.hypot(coords[i][0]-coords[j][0],coords[i][1]-coords[j][1]);path=paths[i][j]
   with localcontext()as ctx:
    ctx.prec=80;precise=sum((distance80(nodes[a],nodes[b])for a,b in zip(path,path[1:])),Decimal(0));residual=precise-Decimal(str(G[i][j]));assert abs(residual)<=Decimal('1e-8')
   pairchecks.append(dict(pair=[i,j],decimal80_path_length_m=str(precise),saved_distance_m=G[i][j],residual_m=str(residual)))
   for k,(a,b)in enumerate(zip(path,path[1:])):
    key=(min(a,b),max(a,b))
    if key not in checks:checks[key]=dict(node_ids=list(key),**segment_check(nodes[a],nodes[b],rings))
    assert checks[key]['exact_safe'],'EXACT_FULL_PATH_SEGMENT_FAILURE'
    for t,xy in enumerate(coords):
     if t not in(i,j)and interior(nodes[a],nodes[b],xy):passages.append(dict(service_leg=[i,j],segment_index=k,other_service=t,event='GEOMETRIC_PASSAGE_NOT_A_SERVICE_EVENT'))
 ints={a:[[quantize(v)for v in row]for row in M]for a,M in [('E',E),('G',G)]}
 return dict(instance_id=ident,status='PASS_PREPROCESS',n=n,coordinates=coords,K=3,capacity=5,demands=[0]+[1]*n,unrounded_matrices={'E':E,'G':G},integer_matrices=ints,canonical_paths=paths,endpoint_checks=endpoints,unique_path_segments=list(checks.values()),pair_checks=pairchecks,geometric_passages=passages,interior_service_graph_nodes=0,length_quantization_bound_m=(n+3)*.0005,numeric_bounds=derive_bounds(ints,n=12,K=3),graph_construction_identity='DIRECT_13_TERMINAL_SERVICES_NOT_OLD_21_THEN_SUBMATRIX',data_independence='124 boundaries outside located historical panels, one synthetic point stream each; prior metadata exposure; not a random field sample or field trial.')

def execute_geometry(p,projected_wkt,ident,seed,n,dest,cap=100000):
 assert n==12, 'Only the frozen12-customer data contract is allowed'
 c,bnodes,cm=construct(p);save(dest/'center_metadata.json',cm)
 if not c.IsEmpty():(dest/'center.wkt').write_text(serialize(c)+'\n')
 if cm['status']!='CENTER_NUMERIC_PASS':return dict(status=cm['status'])
 stream=sample(p,c,seed,n,cap,lambda row:append(dest/'candidate_trace.jsonl',row));save(dest/'sampling.json',stream)
 if not stream['complete']:return dict(status='SAMPLING_INSUFFICIENT')
 coords=[r['coordinate']for r in stream['accepted']];cs=components(c);membership=[[i for i,part in enumerate(cs)if part.Contains(point(xy))]for xy in coords]
 save(dest/'services.json',dict(instance_id=ident,n=n,coordinates=coords,component_membership=membership,depot_rule='first accepted',field_seed=seed))
 if len({tuple(x)for x in membership})!=1:return dict(status='DISCONNECTED_CONSERVATIVE_COMPONENTS')
 graph,G,paths=build_graph(p,c,bnodes,coords);save(dest/'graph.json',graph)
 if graph['unreachable_service_pairs']:return dict(status='NO_CONNECTION_IN_FROZEN_GRAPH')
 data=finalize(ident,n,coords,graph,G,paths,rings_from_wkt(projected_wkt));save(dest/'preprocess.json',data)
 inputs=[dict(kind='FROZEN_Q5_MATRICES',filename='preprocess.json',sha256=sha(dest/'preprocess.json'))]
 return dict(status='PASS_PREPROCESS',inputs=inputs,n=n)

def main():
 assert __debug__;field_id=sys.argv[1];dest=pathlib.Path(sys.argv[2]);assert dest.resolve()==(ROOT/'raw/fields'/field_id).resolve();dest.mkdir(exist_ok=True);save(dest/'FIELD_STARTED.json',dict(instance_id=field_id,utc=utc(),stage='UNIQUE_FORMAL_PREPROCESS'));start=time.monotonic();cpu=time.process_time();result={}
 try:
  panel=read(ROOT/'input/provenance/PANEL_SOURCE_READY_PROPOSAL.json');row=next(x for x in panel['candidates']if x['id']==field_id);path=ROOT/'input/wkt'/f'{field_id}.wkt';assert sha(path)==row['source_sha256'];w=path.read_text()
  p,pw,pm=project(w,(ROOT/'input/provenance/NL_2020_source.prj').read_text(),row['proposed_utm_epsg']);save(dest/'projection.json',pm);(dest/'projected.wkt').write_text(pw+'\n')
  result=execute_geometry(p,pw,field_id,row['fixed_task_seed'],12,dest)
 except Exception as e:result=dict(status='PREPROCESS_EXCEPTION',error=repr(e),traceback=traceback.format_exc())
 finally:
  result.update(instance_id=field_id,utc=utc(),wall_seconds=time.monotonic()-start,cpu_seconds=time.process_time()-cpu,maxrss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,rlimit_cpu=list(resource.getrlimit(resource.RLIMIT_CPU)),rlimit_as=list(resource.getrlimit(resource.RLIMIT_AS)));save(dest/'FIELD_FINISHED.json',result);print(json.dumps(result))
 if result['status']!='PASS_PREPROCESS':sys.exit(4)
if __name__=='__main__':
 from gates import active_main_gate
 active_main_gate();main()
