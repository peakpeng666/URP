"""Freeze prepared files only after current independent PRECHECK; no execution authority."""
from common import ROOT,read,save,sha,inventory,verify_map,utc

def main():
 check=read(ROOT/'freeze/INDEPENDENT_PRECHECK.json');assert check['status']=='PASS'and check['reviewed_files'];verify_map(ROOT,check['reviewed_files'])
 for rel in ['raw','independent_supervision/raw','provenance/MAIN_LAUNCH_STARTED.json','provenance/VALIDATION_LAUNCH_STARTED.json']:assert not(ROOT/rel).exists()
 folders=['source','input','freeze','environment','evidence','original_source_extracts','history_evidence','future_algorithm_policy','future_exact_policy','selftests','independent_supervision']
 files=[]
 for name in folders:
  for p in(ROOT/name).rglob('*'):
   if p.is_file()and '__pycache__'not in p.parts and p.name!='FROZEN_FILES.json':files.append(p)
 files.extend([ROOT/'PROTOCOL_PROPOSAL_ZH.txt',ROOT/'CANDIDATE_IDS_124.txt',ROOT/'audit_sources.py',ROOT/'READ_FIRST_ZH.txt'])
 files.extend(p for p in(ROOT/'provenance').rglob('*')if p.is_file())
 assert len(files)==len(set(files))
 save(ROOT/'freeze/FROZEN_FILES.json',dict(utc=utc(),status='PREEXEC_IDENTITY_ONLY_NOT_EXECUTION_APPROVAL',files=inventory(ROOT,files),approved_real_geometry=0,approved_exact_calls=0,approved_native_calls=0))
 print(sha(ROOT/'freeze/FROZEN_FILES.json'))
if __name__=='__main__':main()
