"""Bounded saved-input report only. No geometry, routing, or native imports."""
import resource,signal,copy
from common import ROOT,read,save,sha,utc
from gates import frozen,receipt

KEYS=['status','planned_fields','fields','eligible_instance_ids','input_ready_count','native_policy_ready_count','exact_integer_ready_count','main_counts','independent_counts','frozen_files_sha256','raw_main_archive_sha256','raw_verification_archive_sha256','field_denominator_unchanged','optimizer_calls','native_model_instances']

def summarize(audit):
 assert audit['status']=='INPUT_EVIDENCE_AUDITED'
 fields=audit['fields'];assert audit['planned_fields']==audit['field_denominator_unchanged']==len(fields)
 assert len({r['instance_id']for r in fields})==len(fields)
 assert audit['input_ready_count']==sum(r['input_ready']for r in fields)
 assert audit['eligible_instance_ids']==[r['instance_id']for r in fields if r['input_ready']]
 assert audit['native_policy_ready_count']==sum(r['input_ready']and r['numeric_flags']['native_policy_admissible']for r in fields)
 assert audit['exact_integer_ready_count']==sum(r['input_ready']and r['numeric_flags']['exact_signed64_safe']for r in fields)
 assert audit['optimizer_calls']==audit['native_model_instances']==0
 return {key:copy.deepcopy(audit[key])for key in KEYS}

def render(summary):
 N=summary['planned_fields']
 lines=['历史已定位面板之外的124块NL输入构造结果',
  f"固定{N}个原始边界；{summary['input_ready_count']}/{N}获得完整的独立几何与矩阵证据。",
  f"其中{summary['native_policy_ready_count']}/{N}满足已冻结native数值准入，{summary['exact_integer_ready_count']}/{N}满足精确标量化整数界。",
  '这是输入阶段结果。本阶段0精确求解、0native模型/求解；数据就绪不等于真实农业可行、算法质量或后续运行批准。',
  '任务为每田13点合成流，12单位需求客户、Q5、至多3车。124分母固定，失败/未知/未启动均保留，不换地/改seed。',
  '技术准入被阻断不代表数学无解。G是有限冻结候选图保存路径，不是连续平面最短路径；没有真实车辆部署或总体推断。',
  '历史只穷尽已定位面板，未穷尽全部历史压缩包；全部原WKT已有元数据接触。',
  '',f"作者调用账本：{summary['main_counts']}",f"独立输入账本：{summary['independent_counts']}",'',
  '逐田结果']
 for row in summary['fields']:
  flags=row['numeric_flags'];lines.append(f"{row['instance_id']}: input_ready={row['input_ready']}; native_numeric={flags['native_policy_admissible']}; exact_integer={flags['exact_signed64_safe']}; failure={row['failure']}")
 lines+=['','源码/输入冻结SHA256 '+summary['frozen_files_sha256'],'RAW_MAIN SHA256 '+summary['raw_main_archive_sha256'],'RAW_VERIFICATION SHA256 '+summary['raw_verification_archive_sha256']]
 return '\n'.join(lines)+'\n'

def main():
 resource.setrlimit(resource.RLIMIT_CPU,(30,30));resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912));signal.alarm(120)
 digest=frozen();a=receipt(ROOT/'provenance/RAW_MAIN_DRIVE_RECEIPT.json','RAW_MAIN',digest);b=receipt(ROOT/'provenance/RAW_VERIFICATION_DRIVE_RECEIPT.json','RAW_VERIFICATION',digest)
 source=ROOT/'independent_supervision/FINAL_INPUT_AUDIT.json';audit=read(source)
 assert audit['frozen_files_sha256']==digest and audit['raw_main_archive_sha256']==a['sha256']and audit['raw_verification_archive_sha256']==b['sha256']
 assert audit['planned_fields']==124
 # Re-read saved stream identities; do not re-run any field or geometry.
 mainrows=read(ROOT/'raw/ALL_FIELD_SLOTS.json');indrows=read(ROOT/'independent_supervision/raw/ALL_PLANNED_SLOTS.json')
 for row in [x['execution']for x in mainrows]+indrows:
  for stream in ('stdout','stderr'):
   if stream in row:assert sha(row[stream])==row[stream+'_sha256']
 summary=summarize(audit);summary['independent_audit_sha256']=sha(source);summary['utc']=utc()
 out=ROOT/'reports';out.mkdir(exist_ok=True);save(out/'SUMMARY.json',summary)
 with (out/'REPORT_ZH.txt').open('x')as f:f.write(render(summary))
 print('Input-only report saved; independent final review and privateFINAL byte readback remain required.')
if __name__=='__main__':main()
