"""Input-only supervisor; preserves124 geometry slots and starts zero optimizer/native calls."""
import sys,time,pathlib,json
from common import ROOT,read,save,append,sha,utc
from tree_runtime import run_command
from gates import active_main_gate

def execute(base,dest,fields,schedule,production=True,geometry_command=None,geometry_cpu=120,geometry_as=1073741824,geometry_wall=180,geometry_batch_wall=22700,main_batch_wall=0):
 assert schedule==[], 'Input stage cannot schedule optimizers'
 dest.mkdir(exist_ok=False);(dest/'active').mkdir();(dest/'calls').mkdir();(dest/'fields').mkdir();start=time.monotonic();deadline=start+geometry_batch_wall
 save(dest/'STARTED.json',dict(utc=utc(),planned_fields=len(fields),planned_main_calls=len(schedule),synthetic_only=not production));frows=[];abort_reason=None
 for f in fields:
  fid=f['id'];slot=dest/'fields'/fid;slot.mkdir();remaining=deadline-time.monotonic();row=dict(instance_id=fid,utc=utc())
  if abort_reason:row.update(status='NOT_STARTED_ABORTED_CONTRACT_FAILURE',process_spawned=False,abort_reason=abort_reason)
  elif remaining<=0:row.update(status='NOT_STARTED_PREPROCESS_BATCH_BUDGET',process_spawned=False)
  else:
   cmd=geometry_command(fid,slot)if geometry_command else['/usr/bin/python3',base/'source/field_preprocess.py',fid,slot]
   append(dest/'events.jsonl',dict(event_kind='PREPROCESS_STARTED',instance_id=fid,utc=utc()))
   row.update(run_command(cmd,dest/'calls'/(fid+'_geometry'),geometry_cpu,geometry_as,min(geometry_wall,remaining),dest/'active'/(fid+'_geometry.active.json')))
   if (slot/'FIELD_FINISHED.json').exists():row['field_result']=read(slot/'FIELD_FINISHED.json')
  if row.get('status')=='LIFECYCLE_FAILURE' or row.get('field_result',{}).get('status')=='PREPROCESS_EXCEPTION' or (row.get('status')=='PROCESS_FAILURE'and not row.get('field_result')):abort_reason='TECHNICAL_OR_SOURCE_CONTRACT_FAILURE:'+fid
  append(dest/'field_results.jsonl',row);frows.append(row)
 save(dest/'PREPROCESS_BATCH_FINISHED.json',dict(utc=utc(),fields=len(frows),wall_seconds=time.monotonic()-start,planned_fields=len(fields)))

 save(dest/'FINISHED.json',dict(utc=utc(),planned_fields=len(fields),recorded_fields=len(frows),known_spawned_geometry_workers=sum(r.get('process_spawned')is True for r in frows),optimizer_calls=0,native_model_instances=0,abort_reason=abort_reason,total_wall_seconds=time.monotonic()-start,status='RAW_MAIN_UNREVIEWED'))
 return frows,[]

if __name__=='__main__':
 active_main_gate();panel=read(ROOT/'input/provenance/PANEL_SOURCE_READY_PROPOSAL.json');execute(ROOT,ROOT/'raw',panel['candidates'],read(ROOT/'freeze/SCHEDULE.json'))
