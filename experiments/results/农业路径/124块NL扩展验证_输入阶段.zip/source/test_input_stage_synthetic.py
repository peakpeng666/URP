"""Five approved hardcoded synthetic geometry fixtures; no optimizer or native solver."""
import json,pathlib,sys,subprocess
from common import ROOT,read,save
from run_author_batch import execute
from launch_main_once import seal
from process_groups import cleanup_registered

def main():
 dest=ROOT/'selftests'/sys.argv[1];dest.mkdir(exist_ok=False)
 base=dest/'workspace';base.mkdir();fields=[dict(id=f)for f in ['convex','concave','hole','empty','split']]
 rows,_=execute(base,base/'raw',fields,[],production=False,geometry_command=lambda fid,slot:['/usr/bin/python3','-B',ROOT/'source/synthetic_field_worker.py',fid,slot],geometry_cpu=20,geometry_as=536870912,geometry_wall=30,geometry_batch_wall=160,main_batch_wall=0)
 cleanup=cleanup_registered(base/'raw/active');assert cleanup['quiescent'];seal(base,base/'raw',[],fields,'SYNTHETIC_NOT_AUTHORIZATION',dict(synthetic_only=True))
 checks=dict(all5_field_slots=len(read(base/'raw/ALL_FIELD_SLOTS.json'))==5,zero_solver_slots=read(base/'raw/ALL_PLANNED_SLOTS.json')==[],groups_quiescent=cleanup['quiescent'])
 for fid in ['convex','concave','hole']:
  p=base/'raw/fields'/fid;f=read(p/'FIELD_FINISHED.json');d=read(p/'preprocess.json');g=read(p/'graph.json')
  checks[fid+'_input_pass']=f['status']=='PASS_PREPROCESS'
  checks[fid+'_13points_Q5']=d['n']==12 and len(d['coordinates'])==13 and d['K']==3 and d['capacity']==5 and d['demands']==[0]+[1]*12
  checks[fid+'_matrices13']=all(len(d['integer_matrices'][k])==13 and all(len(r)==13 for r in d['integer_matrices'][k])for k in ['E','G'])
  checks[fid+'_terminal_only']=all(all(node<g['base_count']for node in path[1:-1])for row in d['canonical_paths']for path in row)
  checks[fid+'_full_exact_safety']=all(r['exact_safe']for r in d['endpoint_checks']+d['unique_path_segments'])
  checks[fid+'_correct_quantization']=d['length_quantization_bound_m']==0.0075
  checks[fid+'_no_TSP_inputs']=not list(p.glob('*.txt')) and len(f['inputs'])==1 and f['inputs'][0]['kind']=='FROZEN_Q5_MATRICES'
  checks[fid+'_bounds']=all(d['numeric_bounds']['per_proxy'][k]['P']==15*max(max(row)for row in d['integer_matrices'][k])+1 for k in ['E','G'])
 checks['empty_retained']=read(base/'raw/fields/empty/FIELD_FINISHED.json')['status']=='EMPTY_CONSERVATIVE_CENTER'
 checks['split_retained']=read(base/'raw/fields/split/FIELD_FINISHED.json')['status']=='DISCONNECTED_CONSERVATIVE_COMPONENTS'
 # A damaged FIELD_FINISHED or partial field_results line must not destroy the seal.
 p=dest/'partial';(p/'raw/fields/f').mkdir(parents=True);(p/'raw/calls').mkdir();(p/'raw/active').mkdir()
 (p/'raw/fields/f/FIELD_FINISHED.json').write_text('{unfinished')
 (p/'raw/calls/f_geometry.stdout').write_text('{partial')
 (p/'raw/field_results.jsonl').write_text('{unfinished\n')
 seal(p,p/'raw',[],[dict(id='f'),dict(id='never')],'SYNTHETIC_NOT_AUTHORIZATION',dict(synthetic_only=True))
 fr=read(p/'raw/ALL_FIELD_SLOTS.json')
 checks['truncated_field_retained']=len(fr)==2 and fr[0]['result']['status']=='UNKNOWN_TRUNCATED_FIELD_FINISHED' and fr[0]['execution']['process_spawned']=='UNKNOWN' and fr[1]['execution']['process_spawned'] is False
 checks['corrupt_line_recorded']=read(p/'raw/OUTER_FINISHED.json')['malformed_field_rows']==[1]
 # No production gate, receipt, or raw data may be created by a missing-gate attempt.
 q=subprocess.run(['/usr/bin/python3','-B',ROOT/'source/launch_main_once.py'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=10)
 (dest/'missing_gate.stdout').write_text(q.stdout);(dest/'missing_gate.stderr').write_text(q.stderr)
 checks['real_launch_missing_gate_rejected']=q.returncode!=0 and not (ROOT/'provenance/MAIN_LAUNCH_STARTED.json').exists() and not (ROOT/'raw').exists()
 report=dict(status='PASS'if all(checks.values())else'FAIL',synthetic_only=True,approved_geometry_fixtures=5,synthetic_task_streams=5,real_projection_calls=0,real_sampling_calls=0,real_graph_calls=0,optimizer_calls=0,native_model_instances=0,checks=checks)
 save(dest/'REPORT.json',report);print(json.dumps(report,indent=2));assert report['status']=='PASS'
if __name__=='__main__':main()
