"""Pure frozen-input arithmetic. No optimizer/native imports or objective evaluation.

An out-of-admission matrix remains a data result and a retained field. This module
never clips distances, replaces a field, changes the policy, or calls a solver.
"""

def derive_bounds(matrices, n=12, K=3):
    assert (n, K) == (12, 3)
    assert set(matrices) == {'E', 'G'}
    N, legs = n + 1, n + K
    maximum = {}
    per_proxy = {}
    for name in ('E', 'G'):
        matrix = matrices[name]
        assert len(matrix) == N and all(len(row) == N for row in matrix)
        for i, row in enumerate(matrix):
            for j, value in enumerate(row):
                assert type(value) is int and value >= 0
                assert value == matrix[j][i]
                assert i != j or value == 0
        M = max(value for row in matrix for value in row)
        U, P = legs * M, legs * M + 1
        checks = {
            'existing_adapter_max_edge_le_3944800': M <= 3944800,
            'probe1000P_lt_2pow53': 1000 * P < 2**53,
            'four_times_U_plus_nP_lt_2pow53': 4 * (U + n * P) < 2**53,
            'penalty_exact_binary64_integer': P <= 2**53 and int(float(P)) == P,
            'cost_bound_lt_signed64_max': 4 * (U + n * P) < 2**63 - 1,
        }
        per_proxy[name] = {
            'n': n, 'K': K, 'legs': legs, 'max_edge': M, 'U': U, 'P': P,
            'formula': '(n+K)*max_edge+1', 'checks': checks,
            'native_policy_admissible': all(checks.values()),
            'blockers': [key for key, value in checks.items() if not value],
        }
        maximum[name] = M
    exact = {}
    for primary, secondary in [('E', 'G'), ('G', 'E')]:
        multiplier = legs * maximum[secondary] + 1
        bound = legs * maximum[primary] * multiplier + legs * maximum[secondary]
        exact[primary + '_' + secondary] = {
            'secondary_complete_solution_upper': legs * maximum[secondary],
            'multiplier': multiplier,
            'scalar_complete_solution_upper': bound,
            'signed64_safe': bound < 2**63 - 1,
            'formula': 'primary*M+secondary; M=15*max_secondary_edge+1',
        }
    return {
        'kind': 'INPUT_DERIVED_ONLY_NOT_OBJECTIVE_VALUES_OR_SOLVER_RESULTS',
        'per_proxy': per_proxy, 'exact_scalarization': exact,
        'all_native_policies_admissible': all(r['native_policy_admissible'] for r in per_proxy.values()),
        'all_exact_signed64_safe': all(r['signed64_safe'] for r in exact.values()),
        'no_automatic_relaxation': True,
    }
