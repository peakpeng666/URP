#!/usr/bin/python3
"""Read-only source geometry audit. No projection, buffering, sampling or optimization.

The only writes are this task's metadata/evidence reports. All source files are read only.
"""
from pathlib import Path
from fractions import Fraction
from collections import Counter, defaultdict
import hashlib, json, re, struct, time, zipfile, zlib, datetime
from osgeo import ogr, osr, gdal
from pyproj import CRS, __version__ as pyproj_version

ROOT = Path(__file__).resolve().parent
SRC = Path('/workspace/shared/cross_field_validation_preparation_20261009')
OUT = ROOT / 'evidence'
OUT.mkdir(exist_ok=True)
OLD = {f'nl_field_{i}' for i in [40,44,63,187,1,2,7,8,17,67,89,143]}
EXPECTED_ZIP = 'd00d0c9574212e29f7f18be775975f6b1ffd38a7dcd3501d7c05d2f63b7b26f7'
EXPECTED_SHP = '1e870b283bbae7ebeec6cf1335d61aee6eb233318eda67495a6c055844a55adf'
EXPECTED_PRJ = 'a02a27b1d1982c8516d83398e85a3c8b1aef1713c13ef4d84d7bde17430c07c4'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def file_digest(p):
    h = hashlib.sha256()
    crc = 0
    with p.open('rb') as f:
        for b in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(b)
            crc = zlib.crc32(b, crc)
    return h.hexdigest(), crc

def save(name, obj):
    (OUT / name).write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n')

def rings(text, conversion):
    return [[tuple(conversion(v) for v in point.split())
             for point in ring.split(',')]
            for ring in re.findall(r'\(([^()]+)\)', text)]

def ring_key(points):
    assert points and points[0] == points[-1]
    q = points[:-1]
    best = []
    for seq in (q, list(reversed(q))):
        low = min(seq)
        for i, pt in enumerate(seq):
            if pt == low:
                best.append(tuple(seq[i:] + seq[:i]))
    return min(best)

def all_rings_key(rs):
    return tuple(sorted(ring_key(r) for r in rs))

def polygon_key(rs):
    return ring_key(rs[0]), tuple(sorted(ring_key(r) for r in rs[1:]))

def bits(value):
    return struct.pack('<d', value)

started = datetime.datetime.now(datetime.timezone.utc).isoformat()
t0 = time.monotonic()
zip_path = SRC / 'sources/fields2benchmark_wkt.zip'
shp_path = SRC / 'sources/NL_2020_EC21.shp'
prj_path = SRC / 'sources/NL_2020_source.prj'
zip_sha, zip_crc = file_digest(zip_path)
shp_sha, shp_crc = file_digest(shp_path)
prj_sha = sha(prj_path.read_bytes())
assert (zip_sha, shp_sha, prj_sha) == (EXPECTED_ZIP, EXPECTED_SHP, EXPECTED_PRJ)
receipt = json.loads((SRC / 'sources/NL_SHP_RECOVERY_RECEIPT.json').read_text())
assert shp_path.stat().st_size == receipt['uncompressed_bytes'] == 399868452
assert shp_crc == receipt['crc32'] == 3644379390

# Reconstruct PRJ from independently saved same-ZIP local header/data range.
sup = SRC / 'independent_supervision'
lh = (sup / 'NL_PRJ_LOCAL_HEADER.bin').read_bytes()
tail = (sup / 'NL_PRJ_NAME_EXTRA_COMPRESSED.bin').read_bytes()
assert lh[:4] == b'PK\x03\x04'
name_len, extra_len = struct.unpack('<HH', lh[26:30])
assert tail[:name_len].decode() == 'NL_2020_EC21.prj'
prj_recovered = zlib.decompress(tail[name_len+extra_len:], -15)
assert prj_recovered == prj_path.read_bytes()
assert zlib.crc32(prj_recovered) == struct.unpack('<I', lh[14:18])[0]
crs = osr.SpatialReference()
assert crs.ImportFromESRI([prj_path.read_text()]) == 0
crs.AutoIdentifyEPSG()
crs_pyproj = CRS.from_wkt(prj_path.read_text())
assert crs_pyproj.to_epsg() == 4326
assert crs_pyproj.equals(CRS.from_epsg(4326), ignore_axis_order=True)

z = zipfile.ZipFile(zip_path)
old_metadata = {x['id']:x for x in json.loads((SRC/'inventory/ALL_350_GEOMETRY_METADATA.json').read_text())}
rows, geoms, decimal_keys, bit_keys = [], {}, {}, {}
for member in sorted(n for n in z.namelist() if n.endswith('.wkt')):
    raw = z.read(member)
    text = raw.decode().strip()
    fid = Path(member).stem
    g = ogr.CreateGeometryFromWkt(text)
    assert g is not None
    rs = rings(text, Fraction)
    frs = rings(text, float)
    brs = [[tuple(bits(v) for v in pt) for pt in r] for r in frs]
    dec_key = polygon_key(rs)
    bit_key = all_rings_key(brs)
    vertices = sum(len(r)-1 for r in rs)
    valid = bool(g.IsValid())
    reasons = []
    if fid[:2] != 'nl': reasons.append('COUNTRY_OUTSIDE_FIXED_NL_SCOPE')
    if fid in OLD: reasons.append('PREVIOUSLY_USED_NL12_BASE_GEOMETRY')
    if not valid: reasons.append('ORIGINAL_INVALID_NO_REPAIR')
    if g.IsEmpty(): reasons.append('ORIGINAL_EMPTY')
    if g.GetGeometryName() != 'POLYGON': reasons.append('NOT_ORIGINAL_POLYGON')
    if g.GetCoordinateDimension() != 2: reasons.append('NOT_TWO_DIMENSIONAL')
    if vertices > 300: reasons.append('ORIGINAL_VERTICES_OVER_300')
    row = dict(id=fid,country=fid[:2],source_member=member,source_sha256=sha(raw),
               exact_decimal_polygon_sha256=sha(repr(dec_key).encode()),
               valid_original=valid,empty=bool(g.IsEmpty()),geometry_type=g.GetGeometryName(),
               coordinate_dimension=g.GetCoordinateDimension(),holes=len(rs)-1,
               vertices_excluding_closure=vertices,vertices_including_closure=sum(map(len,rs)),
               envelope_native=list(g.GetEnvelope()),exclusion_reasons=reasons,
               eligible_source_candidate=not reasons)
    om = old_metadata[fid]
    for k in ['source_sha256','valid_original','empty','geometry_type','coordinate_dimension',
              'holes','vertices_excluding_closure','vertices_including_closure','envelope_native']:
        assert row[k] == om[k], (fid,k)
    rows.append(row)
    geoms[fid] = g
    decimal_keys[fid] = dec_key
    bit_keys[fid] = bit_key

candidates = sorted([r for r in rows if r['eligible_source_candidate']],key=lambda r:int(r['id'].split('_')[-1]))
nl = [r for r in rows if r['country']=='nl']
ids = {r['id'] for r in candidates}
assert len(rows)==350 and len(nl)==140

# Full 767,034-record scan with a lossless first-stored-coordinate bit filter.
# Any coordinate-identical polygon necessarily starts at one of the target coordinates.
# Therefore uniqueness does NOT depend on trusting each SHP record's bbox metadata.
# Unmatched candidates are retained in the report and are never assigned a CRS.
first_coordinate_index = defaultdict(set)
for r in nl:
    target_text=z.read(r['source_member']).decode()
    for ring in rings(target_text,float):
        for pt in ring:
            first_coordinate_index[struct.pack('<2d',*pt)].add(r['id'])
matches = defaultdict(list)
bbox_only = []
count, types = 0, Counter()
with shp_path.open('rb') as f:
    header = f.read(100)
    assert struct.unpack('>I',header[:4])[0]==9994
    assert struct.unpack('>I',header[24:28])[0]*2==shp_path.stat().st_size
    assert struct.unpack('<I',header[28:32])[0]==1000
    while True:
        offset=f.tell()
        rh=f.read(8)
        if not rh: break
        assert len(rh)==8
        recno,words=struct.unpack('>II',rh)
        raw=f.read(words*2)
        assert len(raw)==words*2
        count+=1
        assert recno==count
        typ=struct.unpack('<I',raw[:4])[0]
        types[typ]+=1
        assert typ==5
        np,nv=struct.unpack('<II',raw[36:44])
        possible=first_coordinate_index.get(raw[44+4*np:60+4*np],set())
        if not possible: continue
        starts=list(struct.unpack('<%dI'%np,raw[44:44+4*np]))
        points=[struct.unpack('<2d',raw[44+4*np+16*i:44+4*np+16*(i+1)]) for i in range(nv)]
        source_rings=[points[a:b] for a,b in zip(starts,starts[1:]+[nv])]
        assert all(r[0]==r[-1] for r in source_rings)
        key=all_rings_key([[tuple(bits(v) for v in pt) for pt in r] for r in source_rings])
        found=False
        for fid in possible:
            if key!=bit_keys[fid]: continue
            found=True
            wkt='POLYGON ('+', '.join('('+', '.join(' '.join(repr(v) for v in pt) for pt in r)+')' for r in source_rings)+')'
            sg=ogr.CreateGeometryFromWkt(wkt)
            source_valid=bool(sg.IsValid())
            exact_topology=bool(sg.SymDifference(geoms[fid]).IsEmpty()) if source_valid and geoms[fid].IsValid() else None
            matches[fid].append(dict(record_number_1_based=recno,record_header_offset=offset,
                record_bytes=len(rh+raw),record_sha256=sha(rh+raw),ring_count=np,
                vertices_including_closure=nv,source_polygon_valid=source_valid,
                binary64_coordinate_bits_equal_ring_order_direction_start_invariant=True,
                source_target_topological_symdifference_empty=exact_topology))
        if not found: bbox_only.append(dict(record=recno,possible=sorted(possible)))
assert count==767034

# Original geometry duplicate checks across all 350 fields, preserving rational decimals;
# GEOS topological checks additionally compare intersecting valid raw originals.
exact_duplicates=[]
topological_duplicates=[]
near_duplicates=[]
bykey=defaultdict(list)
for fid,k in decimal_keys.items(): bykey[k].append(fid)
exact_duplicates=[v for v in bykey.values() if len(v)>1]
for i,a in enumerate(rows):
    if not a['valid_original']:continue
    A=geoms[a['id']]; x0,x1,y0,y1=A.GetEnvelope()
    for b in rows[i+1:]:
        if not b['valid_original']:continue
        B=geoms[b['id']];u0,u1,v0,v1=B.GetEnvelope()
        if x1<u0 or u1<x0 or y1<v0 or v1<y0:continue
        if A.SymDifference(B).IsEmpty():
            topological_duplicates.append([a['id'],b['id']]);continue
        inter=A.Intersection(B).GetArea()
        if inter and min(inter/A.GetArea(),inter/B.GetArea())>=0.99:
            near_duplicates.append(dict(a=a['id'],b=b['id'],min_coverage=min(inter/A.GetArea(),inter/B.GetArea())))

# Inspect every currently materialized historical WKT; compare original-coordinate
# equivalence, and label transformed/synthetic files as contextual, not a no-leakage proof.
historical_wkt=[]
for base in [Path('/workspace/shared'),Path('/workspace/scratch/27470b7a9f17')]:
    for p in sorted(base.rglob('*.wkt')):
        if ROOT in p.parents:continue
        raw=p.read_bytes()
        try:
            gg=ogr.CreateGeometryFromWkt(raw.decode().strip())
            rr=rings(raw.decode().strip(),Fraction)
            key=polygon_key(rr) if gg is not None and gg.GetGeometryName()=='POLYGON' else None
            equal=[fid for fid,k in decimal_keys.items() if k==key]
        except Exception:
            equal=[]
        historical_wkt.append(dict(path=str(p),sha256=sha(raw),matched_original_ids=equal,
            matching_new_candidate_ids=sorted(ids.intersection(equal))))

unready=[]
for r in candidates:
    mm=matches[r['id']]
    ready=len(mm)==1 and mm[0]['source_polygon_valid'] and mm[0]['source_target_topological_symdifference_empty']
    r['source_matches']=mm
    r['crs_ready']=ready
    r['source_crs']='EPSG:4326; geographic WGS84; source SHP x=longitude y=latitude' if ready else None
    r['future_axis_rule']='always_xy=True; not yet projected' if ready else None
    if not ready:unready.append(r['id'])

source_evidence=dict(status='SOURCE_AUDIT_PASS' if not unready else 'UNRESOLVED_CANDIDATES_RETAINED',
    audit_started_utc=started,audit_finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    source_zip=dict(path=str(zip_path),sha256=zip_sha,bytes=zip_path.stat().st_size,official_record='https://zenodo.org/records/14524735'),
    source_shp=dict(path=str(shp_path),sha256=shp_sha,bytes=shp_path.stat().st_size,zip_member_crc32=shp_crc,
        official_record='https://zenodo.org/records/8229128',official_zip='NL_2020.zip',member='NL_2020_EC21.shp',
        full_record_count=count,shape_types=dict(types),full_zip_downloaded=False,full_zip_md5_verified=False),
    source_prj=dict(path=str(prj_path),sha256=prj_sha,reconstructed_from_same_zip_cached_range=True,
        osr_authority=crs.GetAuthorityCode(None),pyproj_version=pyproj_version,
        pyproj_to_epsg=crs_pyproj.to_epsg(),epsg4326_equivalent_ignoring_axis_order=True,
        source_axis_info=[str(a) for a in crs_pyproj.axis_info],text=prj_path.read_text()),
    candidate_count=len(candidates),crs_ready_count=sum(r['crs_ready'] for r in candidates),
    unresolved_candidates=unready,first_vertex_candidates_without_bitwise_match=bbox_only,
    lossless_prefilter='First stored coordinate bits must occur in target; no reliance on SHP record bbox for uniqueness.',
    all_140_nl_unique_bitwise_match_count=sum(len(matches[r['id']])==1 for r in nl),
    gdAL_version=gdal.VersionInfo(),elapsed_seconds=time.monotonic()-t0,
    source_inputs_mutated=False,projection_calls=0,buffer_calls=0,random_draws=0,graph_builds=0,
    matrix_builds=0,optimizer_calls=0,native_vrp_calls=0,LLM_calls=0,
    limits=['Cached official source bytes and saved HTTPS Range receipts reused; no new network download.',
            'Member CRC/hash and same-ZIP PRJ verified; complete NL ZIP digest was not verified.',
            'CRS correspondence proves only matched source geometries, not survey accuracy/current access/task realism.'])
save('SOURCE_CORRESPONDENCE.json',source_evidence)
save('CANDIDATE_126_SOURCE_READY.json',dict(status='DRAFT_NOT_FORMAL_FREEZE',selection_rule='All remaining original valid nonempty 2D Polygon NL fields, <=300 original vertices excluding closure, excluding prior NL12 and duplicate base geometry',candidates=candidates))
save('ALL_350_RECHECKED.json',rows)
save('NL140_EXCLUSIONS.json',dict(nl_count=140,candidate_count=len(candidates),excluded=[r for r in nl if r['exclusion_reasons']]))
save('SOURCE_MATCHES_ALL_NL140.json',dict(matches={r['id']:matches[r['id']] for r in nl}))
save('DUPLICATE_GEOMETRY_CHECK.json',dict(exact_original_duplicate_clusters=exact_duplicates,
    topological_original_duplicate_pairs=topological_duplicates,near_duplicate_overlap_99pct_pairs=near_duplicates,
    historical_materialized_wkt_files=historical_wkt,
    candidate_match_to_historical_wkt=[r for r in historical_wkt if r['matching_new_candidate_ids']],
    limitation='Materialized WKT scan alone does not establish all prior experimentation history. Authoritative archived source usage and supervisor history confirmation must also be recorded. Transformed/synthetic WKT is not reprojected.'))
summary=dict(candidate_count=len(candidates),crs_ready=len(candidates)-len(unready),unready=unready,
    excluded_nl=[dict(id=r['id'],reasons=r['exclusion_reasons']) for r in nl if r['exclusion_reasons']],
    candidate_hole_counts=dict(Counter(r['holes'] for r in candidates)),
    candidate_vertex_range=[min(r['vertices_excluding_closure'] for r in candidates),max(r['vertices_excluding_closure'] for r in candidates)],
    exact_duplicates=exact_duplicates,topological_duplicates=topological_duplicates,near_duplicates=near_duplicates,
    historical_wkt_count=len(historical_wkt),historical_candidate_matches=sum(bool(r['matching_new_candidate_ids']) for r in historical_wkt),
    source_audit_status=source_evidence['status'])
save('SUMMARY.json',summary)
print(json.dumps(summary,ensure_ascii=False,indent=2))
