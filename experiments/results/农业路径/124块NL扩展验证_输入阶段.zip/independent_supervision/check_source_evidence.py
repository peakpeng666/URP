"""Read original geometry bytes only: no projection, sampling, or optimisation."""
import collections, datetime, hashlib, json, pathlib, re, resource, signal, struct, time, zipfile, zlib
from osgeo import ogr
from pyproj import CRS

ROOT = pathlib.Path(__file__).resolve().parents[1]
OUT = pathlib.Path(__file__).resolve().parent
resource.setrlimit(resource.RLIMIT_CPU, (30, 30))
resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
signal.alarm(60)
t = time.monotonic()
c = time.process_time()
load = lambda p: json.loads(pathlib.Path(p).read_text())
digest = lambda b: hashlib.sha256(b).hexdigest()
panel = load(ROOT / 'evidence/PROPOSED_124_PANEL.json')
candidate = load(ROOT / 'evidence/CANDIDATE_126_SOURCE_READY.json')['candidates']
source = load(ROOT / 'evidence/SOURCE_CORRESPONDENCE.json')
history = load(ROOT / 'evidence/HISTORICAL_PANEL_EXPOSURE.json')
old = {f'nl_field_{i}' for i in (1, 2, 7, 8, 10, 11, 17, 40, 44, 63, 67, 89, 143, 187)}
assert len(candidate) == 126 and len(panel['candidates']) == 124
assert {r['id'] for r in panel['candidates']} == {r['id'] for r in candidate} - {'nl_field_10', 'nl_field_11'}
assert not old.intersection(r['id'] for r in panel['candidates'])

def canonical_ring(points):
    assert len(points) >= 4 and points[0] == points[-1]
    cycle = tuple(points[:-1])
    reverse = cycle[::-1]
    # All cyclic rotations, preserving every repeated vertex and both directions.
    return min(seq[i:] + seq[:i] for seq in (cycle, reverse) for i in range(len(seq)))

def normalise(rings):
    return tuple(sorted(canonical_ring(r) for r in rings))

def wkt_rings(raw):
    return [[struct.pack('<2d', *(float(v) for v in p.split())) for p in ring.split(',')]
            for ring in re.findall(r'\(([^()]+)\)', raw.decode())]

def shp_rings(raw):
    assert struct.unpack_from('<I', raw)[0] == 5
    parts, points = struct.unpack_from('<II', raw, 36)
    starts = list(struct.unpack_from('<' + 'I' * parts, raw, 44)) + [points]
    assert starts[0] == 0 and all(a < b for a, b in zip(starts, starts[1:]))
    base = 44 + 4 * parts
    assert base + points * 16 == len(raw)
    return [[raw[base + 16*i:base + 16*(i+1)] for i in range(a, b)]
            for a, b in zip(starts, starts[1:])]

archive = pathlib.Path(source['source_zip']['path'])
assert digest(archive.read_bytes()) == source['source_zip']['sha256']
records = []
with zipfile.ZipFile(archive) as z, pathlib.Path(source['source_shp']['path']).open('rb') as shp:
    nl_names = [n for n in z.namelist() if n.startswith('wkt/nl_field_') and n.endswith('.wkt')]
    assert len(nl_names) == 140
    expected = set()
    invalid = set()
    for name in nl_names:
        raw = z.read(name); fid = pathlib.Path(name).stem
        g = ogr.CreateGeometryFromWkt(raw.decode())
        if not g.IsValid(): invalid.add(fid); continue
        assert g.GetGeometryName() == 'POLYGON' and not g.IsEmpty() and g.GetCoordinateDimension() == 2
        assert sum(len(r)-1 for r in wkt_rings(raw)) <= 300
        if fid not in old: expected.add(fid)
    assert invalid == {'nl_field_22', 'nl_field_32'}
    assert expected == {r['id'] for r in panel['candidates']}
    for r in candidate:
        fid = r['id']; raw = z.read(r['source_member'])
        assert digest(raw) == r['source_sha256']
        assert raw == (ROOT / 'original_source_extracts' / (fid + '.wkt')).read_bytes()
        match, = r['source_matches']
        shp.seek(match['record_header_offset']); record = shp.read(match['record_bytes'])
        assert record == (ROOT / 'original_source_extracts' / (fid + '_source_record.bin')).read_bytes()
        assert digest(record) == match['record_sha256']
        number, words = struct.unpack('>II', record[:8])
        assert number == match['record_number_1_based'] and words * 2 == len(record)-8
        assert normalise(wkt_rings(raw)) == normalise(shp_rings(record[8:]))
        records.append({'id': fid, 'source_record': number, 'original_wkt_sha256': digest(raw), 'original_record_sha256': digest(record), 'binary64_ring_match': True})
    for kind, member_key in [('nl6', 'archive_member'), ('formal_nl12', 'member')]:
        h = history[kind]; p = pathlib.Path(h['archive_path']); assert digest(p.read_bytes()) == h['archive_sha256']
        with zipfile.ZipFile(p) as old_zip:
            for item in h['fields']:
                data = old_zip.read(item[member_key]); assert data == z.read('wkt/' + item['id'] + '.wkt') and digest(data) == item['sha256']

prj = pathlib.Path(source['source_prj']['path']).read_bytes()
assert digest(prj) == source['source_prj']['sha256']
assert CRS.from_wkt(prj.decode()).equals(CRS.from_epsg(4326), ignore_axis_order=True)
cached = pathlib.Path('/workspace/shared/cross_field_validation_preparation_20261009/independent_supervision')
header = (cached / 'NL_PRJ_LOCAL_HEADER.bin').read_bytes()
tail = (cached / 'NL_PRJ_NAME_EXTRA_COMPRESSED.bin').read_bytes()
nl, el = struct.unpack_from('<HH', header, 26)
assert tail[:nl] == b'NL_2020_EC21.prj'
assert zlib.decompress(tail[nl+el:], -15) == prj
assert zlib.crc32(prj) == struct.unpack_from('<I', header, 14)[0]
result = {'status': 'PASS_SOURCE_EXCERPTS_AND_PANEL_RULE', 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'source_candidates_checked': 126, 'proposed_panel': 124, 'historical_union_excluded': 14,
          'original_invalid_excluded': 2, 'records': records, 'same_zip_prj_checked': True,
          'uniqueness_scope': 'Full 767034-record uniqueness scan reviewed in author source and saved evidence; this independent run checks all 126 exact original excerpts, not a second national scan.',
          'history_scope': 'Located NL6 and NL12 byte identities checked; not exhaustive absence across all historical ZIPs.',
          'proposal_sha256': digest((ROOT / 'evidence/PROPOSED_124_PANEL.json').read_bytes()),
          'source_audit_sha256': digest((ROOT / 'evidence/SOURCE_CORRESPONDENCE.json').read_bytes()),
          'algorithm_calls': 0, 'projection_calls': 0, 'sampling_calls': 0, 'matrix_calls': 0,
          'resources': {'cpu_seconds': time.process_time()-c, 'wall_seconds': time.monotonic()-t, 'maxrss_KiB': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}}
with (OUT / 'SOURCE_EXCERPT_REVIEW.json').open('x') as f: json.dump(result, f, indent=2, ensure_ascii=False)
print(json.dumps({k: v for k, v in result.items() if k != 'records'}, ensure_ascii=False))
