"""Saved124-field evidence aggregation; no geometry kernel, native model, or optimizer."""
import pathlib,sys,json,resource,signal,time,datetime,hashlib,zipfile
ROOT=pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'source'))
from common import read,save,sha
from gates import frozen,receipt

def require(value,message):
    if not value: raise ValueError(message)

def rows(path):
    found=[];bad=[]
    if path.exists():
        for i,line in enumerate(path.read_text().splitlines(),1):
            try:
                row=json.loads(line)
                if not isinstance(row,dict):raise ValueError('row')
                found.append(row)
            except (ValueError,TypeError):bad.append(i)
    return found,bad

def good_process(row):
    return (row.get('status')=='UNREVIEWED_PROCESS_SUCCESS' and row.get('process_spawned') is True
      and row.get('child_reaped') is True and row.get('returncode')==0 and not row.get('error')
      and bool(row.get('started_utc')) and bool(row.get('reaped_utc'))
      and (row.get('registered_group_cleanup') or {}).get('quiescent') is True)

def counts(records):
    return {'planned':len(records),'known_spawned':sum(x.get('process_spawned') is True for x in records),
      'unknown_spawned_slots':sum(x.get('process_spawned')=='UNKNOWN' for x in records),
      'not_started':sum(x.get('process_spawned') is False for x in records),'retained':len(records)}

def collect(base,panel,main_slots,ind_slots,binding):
    expected=[f['id'] for f in panel]
    require(len(expected)==len(set(expected)) and [r['instance_id']for r in main_slots]==expected,'ordered full author field ledger')
    require([r['schedule']['instance_id']for r in ind_slots]==expected,'ordered full independent field ledger')
    main_rows,main_bad=rows(base/'raw/field_results.jsonl');ind_rows,ind_bad=rows(base/'independent_supervision/raw/results.jsonl')
    main_by={r['instance_id']:r for r in main_rows};ind_by={r['schedule']['instance_id']:r for r in ind_rows}
    duplicate_main=len(main_by)!=len(main_rows);duplicate_ind=len(ind_by)!=len(ind_rows)
    fields=[]
    for source,a,b in zip(panel,main_slots,ind_slots):
        fid=source['id'];folder=base/'raw/fields'/fid;output=base/'independent_supervision/raw/fields'/fid/'INPUT_AUDIT.json'
        row={'instance_id':fid,'input_ready':False,'failure':None,'author_status':a['result'].get('status'),
          'author_execution_status':a['execution'].get('status'),'independent_execution_status':b.get('status'),
          'preprocess_path':f'raw/fields/{fid}/preprocess.json','preprocess_sha256':None,'preprocess_bytes':None,
          'independent_input_audit_sha256':sha(output) if output.exists() else None,
          'numeric_flags':{'native_policy_admissible':False,'exact_signed64_safe':False},'numeric_bounds':None}
        try:
            require(not duplicate_main and not duplicate_ind,'duplicate process ledger identities')
            if fid in main_by:require(a['execution']==main_by[fid],'author original process row identity')
            if fid in ind_by:require(b==ind_by[fid],'independent original process row identity')
            require(good_process(a['execution']) and a['result'].get('status')=='PASS_PREPROCESS','AUTHOR_NOT_COMPLETED_PASS:'+str(a['result'].get('status')))
            require(good_process(b),'INDEPENDENT_NOT_COMPLETED_PASS:'+str(b.get('status')))
            require(a['author_pass_unreviewed'] is True and b.get('audit_status')=='PASS_INPUT_AUDIT','final PASS identities')
            for process in (a['execution'],b):
                for stream in ('stdout','stderr'):require(sha(process[stream])==process[stream+'_sha256'],'saved process stream bytes')
                require(process['configured_cpu_seconds']==120 and process['configured_as_bytes']==1073741824 and 0<process['configured_wall_seconds']<=180,'field process limits')
                require(process['started_utc']<=process['reaped_utc']<=process['finished_utc'],'field process UTC order')
            finish=read(folder/'FIELD_FINISHED.json');require(finish==a['result'],'author original finish identity')
            data=read(folder/'preprocess.json');dh=sha(folder/'preprocess.json')
            require(finish['inputs']==[{'kind':'FROZEN_Q5_MATRICES','filename':'preprocess.json','sha256':dh}],'frozen sole matrix artifact')
            require(data['instance_id']==fid and data['n']==12 and data['K']==3 and data['capacity']==5 and data['demands']==[0]+[1]*12,'final model identity')
            independent=read(output);require(independent['status']=='PASS_INPUT_AUDIT' and independent['synthetic_only'] is False and independent['field_id']==fid and independent['n']==12,'independent field identity')
            require(sha(output)==b['audit_sha256'] and b['audit_path']==str(output.relative_to(base)),'independent artifact ledger binding')
            for key,value in binding.items():require(independent['gate_binding'][key]==value,'independent authority binding '+key)
            require(independent['source_sha256']==sha(base/'independent_supervision/source/check_field.py') and independent['geometry_kernel_sha256']==sha(base/'independent_supervision/source/geometry_exact.py'),'independent frozen code binding')
            verified=independent['verified_matrix_input'];require(verified['path']==str(folder/'preprocess.json') and verified['sha256']==dh and verified['bytes']==(folder/'preprocess.json').stat().st_size,'independent matrix identity')
            require(independent['numeric_bounds']==data['numeric_bounds'],'independent numerical admission evidence')
            require(independent['graph']['all_used_full_segments_and_endpoints_exact_safe'] is True,'independent exact geometry conclusion')
            row.update(input_ready=True,preprocess_sha256=dh,preprocess_bytes=verified['bytes'],numeric_bounds=data['numeric_bounds'],
              numeric_flags={'native_policy_admissible':data['numeric_bounds']['all_native_policies_admissible'],'exact_signed64_safe':data['numeric_bounds']['all_exact_signed64_safe']},
              independent_minimum_clearance_m_decimal80=independent['minimum_clearance_m_decimal80'])
        except (ValueError,KeyError,TypeError,OSError) as exc:row['failure']=str(exc)
        fields.append(row)
    main_counts=counts([r['execution']for r in main_slots]);ind_counts=counts(ind_slots)
    return {'status':'INPUT_EVIDENCE_AUDITED','planned_fields':len(panel),'fields':fields,
      'input_ready_count':sum(r['input_ready']for r in fields),'eligible_instance_ids':[r['instance_id']for r in fields if r['input_ready']],
      'native_policy_ready_count':sum(r['input_ready']and r['numeric_flags']['native_policy_admissible']for r in fields),
      'exact_integer_ready_count':sum(r['input_ready']and r['numeric_flags']['exact_signed64_safe']for r in fields),
      'main_counts':main_counts,'independent_counts':ind_counts,
      'malformed_author_row_numbers':main_bad,'malformed_independent_row_numbers':ind_bad,
      'duplicate_author_ids':duplicate_main,'duplicate_independent_ids':duplicate_ind,
      'field_denominator_unchanged':len(panel),'optimizer_calls':0,'native_model_instances':0,
      'scope':'Saved input identity and verification evidence only; readiness is not route optimality, real agricultural feasibility, or approval of later496 native/496 exact slots.'}

def check_archive(stage,digest,prefix):
    r=receipt(ROOT/f'provenance/{stage}_DRIVE_RECEIPT.json',stage,digest)
    manifest_path=ROOT/prefix/(stage+'_CONTENT_MANIFEST.json');manifest=read(manifest_path)
    require(manifest['frozen_files_sha256']==digest,'raw manifest freeze')
    with zipfile.ZipFile(r['download_path'])as z:
        require(z.read(str(manifest_path.relative_to(ROOT)))==manifest_path.read_bytes(),'actual archive raw manifest')
        for name,item in manifest['files'].items():
            b=(ROOT/name).read_bytes();require(len(b)==item['bytes']and hashlib.sha256(b).hexdigest()==item['sha256']and z.read(name)==b,'raw artifact bytes '+name)
    return r

def main():
    resource.setrlimit(resource.RLIMIT_CPU,(60,60));resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912));signal.alarm(120)
    cpu=time.process_time();wall=time.monotonic();digest=frozen()
    main_receipt=check_archive('RAW_MAIN',digest,'raw');ind_receipt=check_archive('RAW_VERIFICATION',digest,'independent_supervision/raw')
    dest=ROOT/'independent_supervision/results';dest.mkdir(exist_ok=True)
    save(dest/'SAVED_INPUT_AUDIT_STARTED.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'optimizer_calls':0,'native_model_instances':0})
    panel=read(ROOT/'input/provenance/PANEL_SOURCE_READY_PROPOSAL.json')['candidates'];require(len(panel)==124 and read(ROOT/'freeze/SCHEDULE.json')==[],'fixed124 data only')
    binding={'frozen_files_sha256':digest,'raw_main_archive_sha256':main_receipt['sha256'],
      'raw_main_receipt_sha256':sha(ROOT/'provenance/RAW_MAIN_DRIVE_RECEIPT.json'),
      'verification_approval_sha256':sha(ROOT/'provenance/PARENT_VERIFICATION_APPROVAL.json'),
      'validation_launch_sha256':sha(ROOT/'provenance/VALIDATION_LAUNCH_STARTED.json'),
      'raw_manifest_sha256':sha(ROOT/'raw/RAW_MAIN_CONTENT_MANIFEST.json')}
    result=collect(ROOT,panel,read(ROOT/'raw/ALL_FIELD_SLOTS.json'),read(ROOT/'independent_supervision/raw/ALL_PLANNED_SLOTS.json'),binding)
    result.update(frozen_files_sha256=digest,raw_main_archive_sha256=main_receipt['sha256'],raw_verification_archive_sha256=ind_receipt['sha256'],
      utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),resources={'cpu_seconds':time.process_time()-cpu,'wall_seconds':time.monotonic()-wall,'maxrss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss})
    save(ROOT/'independent_supervision/FINAL_INPUT_AUDIT.json',result)
    print(json.dumps({k:result[k]for k in ('status','planned_fields','input_ready_count','native_policy_ready_count','exact_integer_ready_count','main_counts','independent_counts')}))
if __name__=='__main__':main()
