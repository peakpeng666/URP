"""Only saved-input audits: 124 field slots, zero native models or optimizers."""
import pathlib, sys, time
ROOT = pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'source'))
from common import read, save, append, sha, utc
from gates import verification_ready
from tree_runtime import run_command

def schedule(fields):
    return [{'call_id':f['id']+'_INPUT_AUDIT','instance_id':f['id'],'objective':'INPUT_AUDIT'} for f in fields]

def execute(base, dest, fields, binding, batch_wall=22840, command=None):
    dest.mkdir(exist_ok=False)
    for name in ('calls','active','fields'): (dest/name).mkdir()
    began=time.monotonic(); deadline=began+batch_wall; rows=[]; abort=None
    author_slots=read(base/'raw/ALL_FIELD_SLOTS.json')
    assert [row['instance_id'] for row in author_slots]==[f['id'] for f in fields]
    author_by={row['instance_id']:row for row in author_slots}
    save(dest/'STARTED.json',{'utc':utc(),'frozen_files_sha256':binding,'planned_fields':len(fields),'optimizer_calls':0})
    for slot in schedule(fields):
        fid=slot['instance_id']; cid=slot['call_id']; folder=dest/'fields'/fid; folder.mkdir()
        output=folder/'INPUT_AUDIT.json'; row={'schedule':slot,'utc':utc()}; remaining=deadline-time.monotonic()
        main_finish=base/'raw/fields'/fid/'FIELD_FINISHED.json'
        try: owner=read(main_finish) if main_finish.exists() else {'status':'MISSING_OWNER_RESULT'}
        except (ValueError,TypeError): owner={'status':'MALFORMED_OWNER_RESULT'}
        row['owner_status']=owner.get('status') if isinstance(owner,dict) else 'MALFORMED_OWNER_RESULT'
        if abort: row.update(status='NOT_STARTED_ABORTED_INPUT_CONTRACT',process_spawned=False,abort_reason=abort)
        elif remaining<=0: row.update(status='NOT_STARTED_INPUT_STAGE_BUDGET',process_spawned=False)
        elif row['owner_status']!='PASS_PREPROCESS' or author_by[fid].get('author_pass_unreviewed') is not True:
            row.update(status='NOT_STARTED_MAIN_PREPROCESS_NONPASS',process_spawned=False)
        else:
            append(dest/'events.jsonl',{'event_kind':'INPUT_AUDIT_START_REQUESTED','schedule':slot,'utc':utc()})
            argv=command(fid,output) if command else ['/usr/bin/python3','-B',base/'independent_supervision/source/check_field.py',fid,output]
            row.update(run_command(argv,dest/'calls'/cid,120,1073741824,min(180,remaining),dest/'active'/(cid+'.active.json')))
            if output.exists():
                row['audit_path']=str(output.relative_to(base)); row['audit_sha256']=sha(output)
                try: result=read(output); row['audit_status']=result.get('status','MALFORMED_AUDIT')
                except (ValueError,TypeError,AttributeError): row['audit_status']='MALFORMED_AUDIT'
            if row.get('audit_status') in ('NOT_VERIFIED','MALFORMED_AUDIT') or row.get('status')=='LIFECYCLE_FAILURE':
                abort='INDEPENDENT_INPUT_OR_LIFECYCLE_CONTRACT_FAILURE:'+fid
            append(dest/'events.jsonl',{'event_kind':'INPUT_AUDIT_FINISHED','schedule':slot,'utc':utc(),'result':row})
        append(dest/'results.jsonl',row); rows.append(row)
    save(dest/'FINISHED.json',{'utc':utc(),'planned_fields':len(fields),'recorded_slots':len(rows),
         'known_spawned_input_audits':sum(r.get('process_spawned') is True for r in rows),
         'wall_seconds':time.monotonic()-began,'abort_reason':abort,'optimizer_calls':0,'native_model_instances':0,
         'status':'RAW_VERIFICATION_UNREVIEWED'})
    return rows

def main():
    digest=verification_ready(); launch=read(ROOT/'provenance/VALIDATION_LAUNCH_STARTED.json')
    assert launch['frozen_files_sha256']==digest and launch['planned_input_audit_calls']==124
    fields=read(ROOT/'input/provenance/PANEL_SOURCE_READY_PROPOSAL.json')['candidates']
    assert len(fields)==124 and read(ROOT/'freeze/SCHEDULE.json')==[]
    execute(ROOT,ROOT/'independent_supervision/raw',fields,digest)
if __name__=='__main__': main()
