"""Saved synthetic inputs only. Does not import author code or execute any solver."""
import copy,json,pathlib,shutil,sys,hashlib
from decimal import Decimal
import check_field as ck

ROOT=ck.ROOT

def save(p,value):p.write_text(json.dumps(value,indent=2)+'\n')
def main():
    dest=ROOT/'independent_supervision/selftests'/sys.argv[1];dest.mkdir(exist_ok=False)
    checks={};reports={}
    source=ROOT/'selftests/input_stage_r1/workspace/raw/fields'
    for fid in ck.SYNTHETIC_WKT:
        result=ck.audit_synthetic(source/fid,fid);reports[fid]=result
        expected='NOT_VERIFIED' if fid in ('empty','split') else 'PASS_SYNTHETIC_INPUT_AUDIT'
        checks[fid+'_saved_result']=result['status']==expected and not result['errors']
        if fid in ('empty','split'):checks[fid+'_failure_retained']='NO_OWNER_PASS_PREPROCESS' in result['reason']
    # Split's saved C must match every recomputed component, even though it is
    # deliberately not eligible for an input-audit PASS or a DP invocation.
    split=source/'split';out={}
    ck.verify_center(ck.SYNTHETIC_WKT['split'],ck.inspect_wkt((split/'center.wkt').read_text()),ck.read(split/'center_metadata.json'),out)
    checks['split_all_components_preserved']=out['center']['components']==2
    def negative(name,filename,mutate,needle):
        p=dest/name/'hole';shutil.copytree(source/'hole',p)
        d=ck.read(p/filename);mutate(d);save(p/filename,d)
        r=ck.audit_synthetic(p,'hole');reports[name]=r
        checks[name]=r['status']=='NOT_VERIFIED' and any(needle in e for e in r['errors'])
    def edge(d):d['edges'][0][2]+=0.01
    negative('wrong_edge','graph.json',edge,'EDGE_WEIGHT_NOT_FROZEN_HYPOT')
    def path(d):
        d['canonical_paths'][0][1]=[72,74,73];d['canonical_paths'][1][0]=[73,74,72]
    negative('service_transit_path','preprocess.json',path,'PATH_REPETITION_OR_SERVICE_TRANSIT')
    def missing(d):d['canonical_paths'][0][1]=[72,999,73]
    negative('out_of_range_path','preprocess.json',missing,'BAD_PATH_NODE_IDS')
    def quant(d):d['integer_matrices']['E'][0][1]+=1;d['integer_matrices']['E'][1][0]+=1
    negative('bad_quantization','preprocess.json',quant,'MATRIX_HALF_UP_MISMATCH')
    def endpoint(d):d['endpoint_checks'][0]['clearance_squared_fraction']=['1','1']
    negative('bad_saved_clearance','preprocess.json',endpoint,'SERVICE_ENDPOINT:0:clearance_squared_fraction')
    def points(d):d['coordinates'].pop()
    negative('missing_service_point','services.json',points,'SERVICES_DIFFER_FROM_FIRST_ACCEPTED_POINTS')
    def samp(d):d['accepted'][0],d['accepted'][1]=d['accepted'][1],d['accepted'][0]
    negative('reordered_sample','sampling.json',samp,'FIRST_ACCEPTED_SEQUENCE_MISMATCH')
    def component(d):d['components']=2
    negative('bad_component_metadata','center_metadata.json',component,'CENTER_COMPONENT_METADATA_MISMATCH')
    # Geometry safety is independently exercised on full segments and holes,
    # with the exact threshold deliberately separated from tolerance labels.
    pg=ck.gx.grid_geometry(ck.inspect_wkt(ck.SYNTHETIC_WKT['hole']),1000000000)
    def check(a,b):return ck.gx.audit_segment(ck.gx.grid_point(a,1000000000),ck.gx.grid_point(b,1000000000),pg[0],1000000000)
    checks['full_segment_crossing_hole_rejected']=not check([10,25],[40,25])['exact']
    checks['subthreshold_endpoint_rejected']=not check([1.099,10],[1.099,10])['exact']
    checks['threshold_exact_safe_tolerance_uncertain']=check([1.1,10],[1.1,11])['exact'] and check([1.1,10],[1.1,11])['label']=='UNCERTAIN_BOUNDARY'
    checks['slightly_subthreshold_uncertain_still_unsafe']=not check([1.099999999,10],[1.099999999,11])['exact'] and check([1.099999999,10],[1.099999999,11])['label']=='UNCERTAIN_BOUNDARY'
    checks['round_half_up']=ck.rounded(1.2345)==1235 and ck.rounded(0.0005)==1
    # Independently constructed geographic square: exercises projection binding
    # without reading, transforming or buffering any real field input.
    from pyproj import CRS,Transformer,network,__version__ as pyproj_version,proj_version_str
    from osgeo import gdal
    synthetic_root=dest/'projection_fixture';pd=synthetic_root/'saved';pd.mkdir(parents=True)
    (synthetic_root/'input/wkt').mkdir(parents=True);(synthetic_root/'input/provenance').mkdir(parents=True)
    sw='POLYGON ((3 45,3.001 45,3.001 45.001,3 45.001,3 45))'
    prj='GEOGCS["WGS 84",DATUM["WGS_1984",SPHEROID["WGS 84",6378137,298.257223563]],PRIMEM["Greenwich",0],UNIT["degree",0.0174532925199433]]'
    source_file=synthetic_root/'input/wkt/synthetic_projection.wkt';source_file.write_text(sw)
    prj_file=synthetic_root/'input/provenance/NL_2020_source.prj';prj_file.write_text(prj)
    network.set_network_enabled(False);trans=Transformer.from_crs(CRS.from_wkt(prj),CRS.from_epsg(32631),always_xy=True)
    original=ck.coords(ck.inspect_wkt(sw));proj=[];backmax=0.0
    for ring in original[0]:
        rr=[]
        for a,b in ring:
            x,y=trans.transform(a,b,errcheck=True);lon,lat=trans.transform(x,y,direction='INVERSE',errcheck=True)
            backmax=max(backmax,abs(lon-a),abs(lat-b));rr.append([x,y])
        proj.append(rr)
    projected_text=ck.serialized([proj])+'\n';(pd/'projected.wkt').write_text(projected_text)
    projected=ck.inspect_wkt(projected_text)
    pm={'source_crs_wkt':prj,'target_epsg':32631,'always_xy':True,'network_enabled':False,
        'pipeline':trans.definition,'description':trans.description,'pyproj_version':pyproj_version,
        'proj_version':proj_version_str,'gdal_version':gdal.VersionInfo(),
        'serialization':'repr binary64 round-trip coordinates; no simplification',
        'original_vertex_counts':[5],'projected_vertex_counts':[5],
        'maximum_roundtrip_absolute_degrees':backmax,'projected_convex_no_hole':ck.convex(projected)}
    save(pd/'projection.json',pm)
    row={'id':'synthetic_projection','source_sha256':ck.digest(source_file),'proposed_utm_epsg':32631,
         'crs_provenance':{'source_crs_prj_sha256':ck.digest(prj_file)}}
    previous_root=ck.ROOT
    try:
        ck.ROOT=synthetic_root;report={};ck.verify_projection(pd,row,projected,report)
        checks['synthetic_projection_identity_and_axis']=report['projection']['status']=='PASS' and 499999<proj[0][0][0]<500001 and 4980000<proj[0][0][1]<4990000
        pm['always_xy']=False;save(pd/'projection.json',pm)
        try:ck.verify_projection(pd,row,projected,{})
        except ck.AuditError as e:checks['synthetic_projection_wrong_axis_rejected']='AXIS_OR_NETWORK_MISMATCH' in str(e)
        else:checks['synthetic_projection_wrong_axis_rejected']=False
    finally:ck.ROOT=previous_root
    try:ck.audit_synthetic(ROOT/'raw/fields/nl_field_40','nl_field_40')
    except ck.AuditError:checks['real_id_cannot_use_synthetic_api']=True
    else:checks['real_id_cannot_use_synthetic_api']=False
    report={'status':'PASS' if all(checks.values()) else 'FAIL','synthetic_only':True,
      'real_projection_calls':0,'real_buffer_calls':0,'real_sampling_calls':0,'real_graph_calls':0,'TSP_calls':0,
      'checks':checks,'source_sha256':ck.digest(pathlib.Path(ck.__file__)),'kernel_sha256':ck.digest(pathlib.Path(ck.__file__).with_name('geometry_exact.py'))}
    save(dest/'REPORT.json',report);save(dest/'DETAIL.json',reports)
    print(json.dumps(report,indent=2));return 0 if report['status']=='PASS' else 1

if __name__=='__main__':sys.exit(main())
