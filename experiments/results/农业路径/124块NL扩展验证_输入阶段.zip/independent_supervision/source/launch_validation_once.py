"""Reuse registered process groups; seal all124 slots after confirmed quiescence."""
import pathlib, sys, resource, json
ROOT=pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'source'))
from common import read,save,sha,utc,inventory
from gates import verification_ready
from tree_runtime import run_command
from process_groups import cleanup_registered
from run_validation_batch import schedule

def seal(base,dest,slots,digest,outer):
    dest.mkdir(exist_ok=True); rows=[]; malformed=[]
    if (dest/'results.jsonl').exists():
        for i,line in enumerate((dest/'results.jsonl').read_text().splitlines(),1):
            try:
                row=json.loads(line)
                if not isinstance(row,dict) or not isinstance(row.get('schedule'),dict) or not isinstance(row['schedule'].get('call_id'),str): raise ValueError('result schema')
                rows.append(row)
            except (ValueError,TypeError): malformed.append(i)
    by={r['schedule']['call_id']:r for r in rows}; retained=[]
    for slot in slots:
        cid=slot['call_id']; evidence=(dest/'calls'/(cid+'.stdout')).exists() or (dest/'active'/(cid+'.active.json')).exists()
        retained.append(by.get(cid,{'schedule':slot,'status':'UNKNOWN_AFTER_SUPERVISOR_FAILURE' if evidence else 'NOT_STARTED_SUPERVISOR_FAILURE','process_spawned':'UNKNOWN' if evidence else False}))
    save(dest/'ALL_PLANNED_SLOTS.json',retained)
    save(dest/'OUTER_FINISHED.json',{'utc':utc(),'frozen_files_sha256':digest,'outer':outer,'planned_fields':len(slots),
         'known_spawned_input_audits':sum(r.get('process_spawned') is True for r in retained),
         'unknown_spawned_slots':sum(r.get('process_spawned')=='UNKNOWN' for r in retained),
         'duplicate_call_ids':len(by)!=len(rows),'malformed_rows':malformed,'optimizer_calls':0,'native_model_instances':0,
         'status':'RAW_VERIFICATION_UNREVIEWED'})
    save(dest/'RAW_VERIFICATION_CONTENT_MANIFEST.json',{'utc':utc(),'frozen_files_sha256':digest,
         'files':inventory(base,[p for p in dest.rglob('*') if p.is_file()])})

def main():
    assert __debug__
    resource.setrlimit(resource.RLIMIT_CPU,(60,120)); resource.setrlimit(resource.RLIMIT_AS,(536870912,1073741824))
    digest=verification_ready(); dest=ROOT/'independent_supervision/raw'; assert not dest.exists()
    receipt=read(ROOT/'provenance/RAW_MAIN_DRIVE_RECEIPT.json')
    manifest=read(ROOT/'raw/RAW_MAIN_CONTENT_MANIFEST.json')
    assert manifest['frozen_files_sha256']==digest
    for rel,meta in manifest['files'].items(): assert (ROOT/rel).stat().st_size==meta['bytes'] and sha(ROOT/rel)==meta['sha256']
    # Actual downloaded archive members must match before any independent worker.
    import zipfile
    with zipfile.ZipFile(receipt['download_path']) as z:
        assert z.read('raw/RAW_MAIN_CONTENT_MANIFEST.json')==(ROOT/'raw/RAW_MAIN_CONTENT_MANIFEST.json').read_bytes()
        for rel in manifest['files']: assert z.read(rel)==(ROOT/rel).read_bytes()
    save(ROOT/'provenance/VALIDATION_LAUNCH_STARTED.json',{'utc':utc(),'frozen_files_sha256':digest,
         'raw_main_archive_sha256':receipt['sha256'],'raw_main_receipt_sha256':sha(ROOT/'provenance/RAW_MAIN_DRIVE_RECEIPT.json'),
         'verification_approval_sha256':sha(ROOT/'provenance/PARENT_VERIFICATION_APPROVAL.json'),
         'planned_fields':124,'planned_input_audit_calls':124,'planned_verification_calls':0,'raw_members_verified':True,
         'whole_supervisor_tree_wall_seconds':22860,'optimizer_calls':0,'native_model_instances':0,
         'outer_limits':{'cpu':list(resource.getrlimit(resource.RLIMIT_CPU)),'as':list(resource.getrlimit(resource.RLIMIT_AS))}})
    outer=run_command(['/usr/bin/python3','-B',ROOT/'independent_supervision/source/run_validation_batch.py'],ROOT/'provenance/verification_supervisor',60,536870912,22860,ROOT/'provenance/verification_supervisor.active.json',cpu_hard=120,as_hard=1073741824)
    cleanup=cleanup_registered(dest/'active');save(ROOT/'provenance/VALIDATION_WHOLE_TREE_CLEANUP.json',cleanup)
    if not cleanup['quiescent'] or (outer.get('process_spawned') and not (outer.get('registered_group_cleanup') or {}).get('quiescent')): raise RuntimeError('WHOLE_TREE_NOT_QUIESCENT')
    fields=read(ROOT/'input/provenance/PANEL_SOURCE_READY_PROPOSAL.json')['candidates'];assert len(fields)==124
    seal(ROOT,dest,schedule(fields),digest,outer)
    print('Independent124 saved-input slots sealed; private RAW_VERIFICATION readback required before final audit. Zero optimizer/native calls.')
if __name__=='__main__':main()
