"""Invented saved schema replay; deliberately retains residual files on failed slots."""
import pathlib,json,copy,shutil
import saved_input_audit as audit
from common import save,sha

def main():
    root=audit.ROOT;dest=root/'independent_supervision/selftests/saved_input_r2';dest.mkdir(exist_ok=False)
    for sub in ('raw','independent_supervision/raw','independent_supervision/source'):(dest/sub).mkdir(parents=True,exist_ok=True)
    for name in ('check_field.py','geometry_exact.py'):shutil.copy2(root/'independent_supervision/source'/name,dest/'independent_supervision/source'/name)
    original=json.loads((root/'selftests/input_stage_r1/workspace/raw/fields/convex/preprocess.json').read_text())
    proof=json.loads((root/'independent_supervision/selftests/field_check_r1/DETAIL.json').read_text())['convex']
    ids=['invented_pass','invented_main_failed_with_file','invented_independent_failed'];pan=[{'id':x}for x in ids]
    mains=[];inds=[];mainrows=[];indrows=[];binding={'frozen_files_sha256':'SYNTHETIC_NOT_AUTHORITY'}
    def process(prefix,ok):
        prefix.parent.mkdir(parents=True,exist_ok=True);out=prefix.with_suffix('.stdout');err=prefix.with_suffix('.stderr');out.write_text('INVENTED_SCHEMA_ONLY\n');err.write_text('')
        return {'status':'UNREVIEWED_PROCESS_SUCCESS'if ok else'PROCESS_FAILURE','process_spawned':True,'child_reaped':True,'returncode':0 if ok else 4,'error':None,
          'started_utc':'2026-01-01T00:00:00+00:00','reaped_utc':'2026-01-01T00:00:01+00:00','finished_utc':'2026-01-01T00:00:01+00:00',
          'registered_group_cleanup':{'quiescent':True},'stdout':str(out),'stderr':str(err),'stdout_sha256':sha(out),'stderr_sha256':sha(err),
          'configured_cpu_seconds':120,'configured_as_bytes':1073741824,'configured_wall_seconds':180}
    for fid in ids:
        folder=dest/'raw/fields'/fid;folder.mkdir(parents=True);data=copy.deepcopy(original);data['instance_id']=fid;save(folder/'preprocess.json',data);dh=sha(folder/'preprocess.json')
        ok=fid!='invented_main_failed_with_file';finish={'status':'PASS_PREPROCESS'if ok else'PREPROCESS_EXCEPTION','instance_id':fid,'n':12,'inputs':[{'kind':'FROZEN_Q5_MATRICES','filename':'preprocess.json','sha256':dh}]};save(folder/'FIELD_FINISHED.json',finish)
        ex=process(dest/'raw/calls'/fid,ok);ex['instance_id']=fid;mainrows.append(ex)
        mains.append({'instance_id':fid,'execution':ex,'result':finish,'author_pass_unreviewed':ok})
        independent=copy.deepcopy(proof);independent.update(status='PASS_INPUT_AUDIT',synthetic_only=False,field_id=fid,gate_binding=binding,
          source_sha256=sha(dest/'independent_supervision/source/check_field.py'),geometry_kernel_sha256=sha(dest/'independent_supervision/source/geometry_exact.py'))
        independent['verified_matrix_input'].update(path=str(folder/'preprocess.json'),sha256=dh,bytes=(folder/'preprocess.json').stat().st_size)
        p=dest/'independent_supervision/raw/fields'/fid/'INPUT_AUDIT.json';save(p,independent)
        row={'schedule':{'instance_id':fid,'call_id':fid+'_INPUT_AUDIT','objective':'INPUT_AUDIT'},**process(dest/'independent_supervision/raw/calls'/fid,fid!='invented_independent_failed'),
          'audit_status':'PASS_INPUT_AUDIT','audit_sha256':sha(p),'audit_path':str(p.relative_to(dest))};inds.append(row);indrows.append(row)
    (dest/'raw/field_results.jsonl').write_text(''.join(json.dumps(x)+'\n'for x in mainrows))
    (dest/'independent_supervision/raw/results.jsonl').write_text(''.join(json.dumps(x)+'\n'for x in indrows))
    result=audit.collect(dest,pan,mains,inds,binding)
    assert result['input_ready_count']==1 and result['eligible_instance_ids']==['invented_pass']
    assert result['planned_fields']==3 and len(result['fields'])==3 and all((dest/x['preprocess_path']).exists()for x in result['fields'])
    assert not result['fields'][1]['input_ready']and not result['fields'][2]['input_ready']
    assert result['main_counts']['known_spawned']==result['independent_counts']['known_spawned']==3
    save(dest/'COLLECTED.json',result);save(dest/'REPORT.json',{'status':'PASS','synthetic_only':True,'retained_slots':3,'ready':1,'failed_process_residual_json_not_promoted':True,'new_geometry_or_native_or_optimizer_calls':0})
    print('PASS saved-only three-slot schema, full failure denominator, residual artifacts cannot create readiness')
if __name__=='__main__':main()
