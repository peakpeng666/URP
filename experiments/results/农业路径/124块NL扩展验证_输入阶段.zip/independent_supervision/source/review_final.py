"""Final structured input-report check. Reader prose is reviewed semantically, not by keywords."""
import pathlib,sys,resource,signal,time,json,datetime
ROOT=pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'source'))
from common import read,save,sha
from gates import frozen,receipt

KEYS=('planned_fields','fields','input_ready_count','eligible_instance_ids','native_policy_ready_count',
      'exact_integer_ready_count','main_counts','independent_counts','field_denominator_unchanged',
      'frozen_files_sha256','raw_main_archive_sha256','raw_verification_archive_sha256')

def compare(audit,summary):
    assert audit['status']=='INPUT_EVIDENCE_AUDITED' and audit['planned_fields']==124
    assert len(audit['fields'])==124 and len({x['instance_id']for x in audit['fields']})==124
    for key in KEYS: assert summary[key]==audit[key],key
    assert audit['input_ready_count']==sum(x['input_ready']for x in audit['fields'])
    assert audit['eligible_instance_ids']==[x['instance_id']for x in audit['fields']if x['input_ready']]
    for name in ('main_counts','independent_counts'):
        x=audit[name]; assert x['planned']==x['retained']==124
        assert x['known_spawned']+x['unknown_spawned_slots']+x['not_started']==124
    assert audit['optimizer_calls']==audit['native_model_instances']==0
    return True

def main():
    resource.setrlimit(resource.RLIMIT_CPU,(15,15));resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912));signal.alarm(60)
    t=time.monotonic();c=time.process_time();digest=frozen()
    main_raw=receipt(ROOT/'provenance/RAW_MAIN_DRIVE_RECEIPT.json','RAW_MAIN',digest)
    ind_raw=receipt(ROOT/'provenance/RAW_VERIFICATION_DRIVE_RECEIPT.json','RAW_VERIFICATION',digest)
    audit=read(ROOT/'independent_supervision/FINAL_INPUT_AUDIT.json');summary=read(ROOT/'reports/SUMMARY.json')
    assert audit['frozen_files_sha256']==digest and audit['raw_main_archive_sha256']==main_raw['sha256'] and audit['raw_verification_archive_sha256']==ind_raw['sha256']
    compare(audit,summary)
    assert summary['independent_audit_sha256']==sha(ROOT/'independent_supervision/FINAL_INPUT_AUDIT.json')
    result={'status':'PASS','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'frozen_files_sha256':digest,
      'raw_main_archive_sha256':main_raw['sha256'],'raw_verification_archive_sha256':ind_raw['sha256'],
      'report_sha256':sha(ROOT/'reports/REPORT_ZH.txt'),'summary_sha256':sha(ROOT/'reports/SUMMARY.json'),
      'independent_audit_sha256':sha(ROOT/'independent_supervision/FINAL_INPUT_AUDIT.json'),
      'planned_fields':124,'input_ready_count':audit['input_ready_count'],'main_counts':audit['main_counts'],'independent_counts':audit['independent_counts'],
      'new_geometry_calls':0,'optimizer_calls':0,'native_model_instances':0,
      'reader_review_method':'Separate direct semantic review of actual final prose; no keyword whitelist gate.',
      'resources':{'cpu_seconds':time.process_time()-c,'wall_seconds':time.monotonic()-t}}
    save(ROOT/'independent_supervision/FINAL_REPORT_REVIEW.json',result);print(json.dumps(result))
if __name__=='__main__':main()
