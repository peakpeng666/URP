"""Small invented process emitters and saved124-slot loss ledger, no geometry/native."""
import pathlib, json, sys
import run_validation_batch as batch
import launch_validation_once as launch
from common import save,read
from process_groups import cleanup_registered

def main():
    dest=batch.ROOT/'independent_supervision/selftests/validation_pipeline_r2';dest.mkdir(exist_ok=False)
    base=dest/'invented';base.mkdir();fields=[{'id':x} for x in ('owner_failed','pass','bad','after_bad')]
    for field in fields:
        p=base/'raw/fields'/field['id'];p.mkdir(parents=True)
        save(p/'FIELD_FINISHED.json',{'status':'PASS_PREPROCESS','synthetic_only':True})
    save(base/'raw/ALL_FIELD_SLOTS.json',[{'instance_id':f['id'],'author_pass_unreviewed':f['id']!='owner_failed'}for f in fields])
    emitter=dest/'emitter.py'
    emitter.write_text("import json,sys,pathlib\np=pathlib.Path(sys.argv[2]);p.write_text(json.dumps({'status':'NOT_VERIFIED' if sys.argv[1]=='bad' else 'PASS_INPUT_AUDIT','synthetic_only':True}))\nsys.exit(4 if sys.argv[1]=='bad' else 0)\n")
    output=base/'independent_supervision/raw';output.parent.mkdir()
    rows=batch.execute(base,output,fields,'SYNTHETIC_NO_AUTHORITY',batch_wall=30,command=lambda fid,p:['/usr/bin/python3',emitter,fid,p])
    cleanup=cleanup_registered(output/'active');assert cleanup['quiescent']
    assert rows[0]['status']=='NOT_STARTED_MAIN_PREPROCESS_NONPASS' and rows[0]['process_spawned'] is False
    assert rows[1]['status']=='UNREVIEWED_PROCESS_SUCCESS' and rows[1]['audit_status']=='PASS_INPUT_AUDIT'
    assert rows[2]['audit_status']=='NOT_VERIFIED' and rows[3]['status']=='NOT_STARTED_ABORTED_INPUT_CONTRACT'
    launch.seal(base,output,batch.schedule(fields),'SYNTHETIC_NO_AUTHORITY',{'synthetic_only':True,'quiescent':True})
    assert len(read(output/'ALL_PLANNED_SLOTS.json'))==4
    partial=dest/'partial';(partial/'raw/calls').mkdir(parents=True);(partial/'raw/active').mkdir()
    invented=[{'id':'invented_'+str(i)}for i in range(124)];slots=batch.schedule(invented)
    (partial/'raw/results.jsonl').write_text('{unfinished\n')
    (partial/'raw/calls'/('invented_0_INPUT_AUDIT.stdout')).write_text('{unfinished')
    launch.seal(partial,partial/'raw',slots,'SYNTHETIC_NO_AUTHORITY',{'synthetic_only':True})
    retained=read(partial/'raw/ALL_PLANNED_SLOTS.json');outer=read(partial/'raw/OUTER_FINISHED.json')
    assert len(retained)==124 and retained[0]['process_spawned']=='UNKNOWN'
    assert sum(r['process_spawned'] is False for r in retained)==123
    assert outer['unknown_spawned_slots']==1 and outer['known_spawned_input_audits']==0 and outer['malformed_rows']==[1]
    assert not(batch.ROOT/'provenance/VALIDATION_LAUNCH_STARTED.json').exists()
    report={'status':'PASS','synthetic_only':True,'actual_invented_process_emitters':2,'saved_loss_ledger_slots':124,
      'all_group_quiescent':True,'owner_nonpass_retained':True,'independent_contract_failure_stops_next_slot':True,
      'truncated_result_unknown_not_zero':True,'new_real_geometry_calls':0,'native_calls':0,'optimizer_calls':0}
    save(dest/'REPORT.json',report);print(json.dumps(report))
if __name__=='__main__':main()
