import json,sys,pathlib
p=pathlib.Path(sys.argv[2]);p.write_text(json.dumps({'status':'NOT_VERIFIED' if sys.argv[1]=='bad' else 'PASS_INPUT_AUDIT','synthetic_only':True}))
sys.exit(4 if sys.argv[1]=='bad' else 0)
