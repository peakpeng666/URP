"""Supplementary supervisor summary recomputation, not a substitute or duplicate claim of geometric peer review."""
from pathlib import Path
from decimal import Decimal,localcontext,ROUND_HALF_UP
from collections import Counter
import json,hashlib,math,datetime
R=Path('/workspace/shared/ee130_distance_proxy_comparison_20261009');O=Path(__file__).parent
j=lambda p:json.loads(Path(p).read_text());h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
r=j(R/'provenance/RAW_UNREVIEWED_DRIVE_RECEIPT.json')
assert h(r['source'])==h(r['download_path'])==r['sha256']==r['download_sha256']
assert r['owner_only'] and r['shared']is False and r['download_byte_identical']
peer=j(R/'independent_review/results/INDEPENDENT_SAVED_REVIEW.json');assert peer['status']=='PASS_COMPLETE_INDEPENDENT_REVIEW'
assert r['confirmed_at_utc']<peer['started_utc']
schedule=j(R/'freeze/SCHEDULE.json');records={a['call_id']:a for a in map(json.loads,(R/'raw/results.jsonl').read_text().splitlines())};cache={};rows=[]
with localcontext()as ctx:
 ctx.prec=80
 for e in schedule:
  rec=records[e['call_id']];assert rec['status']=='UNREVIEWED_PROCESS_SUCCESS'and rec['returncode']==0 and rec['child_reaped']
  assert h(R/rec['stdout'])==rec['stdout_sha256'];ans=j(R/rec['stdout']);ident=e['instance_id']
  if ident not in cache:cache[ident]=(j(R/'input'/f'{ident}_input.json'),j(R/'input'/f'{ident}_graph.json'))
  data,g=cache[ident];n=data['n'];routes=ans['routes'];assert len(routes)==1;route=routes[0]
  assert route[0]==route[-1]==0 and Counter(route[1:-1])==Counter(range(1,n+1))
  length=Decimal(0);integer=0
  for a,b in zip(route,route[1:]):
   lo,hi=sorted((a,b));path=g['paths'][lo][hi];path=path if a==lo else list(reversed(path))
   assert path[0]==g['service_node_ids'][a]and path[-1]==g['service_node_ids'][b]
   for u,v in zip(path,path[1:]):
    x,y=map(lambda z:Decimal(str(z)),g['nodes'][u]);xx,yy=map(lambda z:Decimal(str(z)),g['nodes'][v]);length+=((x-xx)**2+(y-yy)**2).sqrt()
   if e['arm']=='G':cost=g['distance_matrix'][lo][hi]
   else:cost=math.hypot(data['coordinates'][a][0]-data['coordinates'][b][0],data['coordinates'][a][1]-data['coordinates'][b][1])
   integer+=int((Decimal(str(cost))*1000).to_integral_value(rounding=ROUND_HALF_UP))
  assert integer==ans['reported_cost']==ans['reported_distance']==ans['internal_route_cost']
  rows.append({**e,'cost':str(length),'integer_cost':integer,'route':route})
 by={(r['instance_id'],r['seed'],r['arm']):r for r in rows};condition=[];delta=[]
 for ident in j(R/'freeze/PROTOCOL.json')['conditions']:
  E=[Decimal(by[ident,s,'E']['cost'])for s in range(3)];G=[Decimal(by[ident,s,'G']['cost'])for s in range(3)];me=sum(E)/3;mg=sum(G)/3
  condition.append({'instance_id':ident,'meanE':str(me),'meanG':str(mg),'delta':str(me-mg),'percent':str(100*(me-mg)/mg)})
  delta.extend(a-b for a,b in zip(E,G))
 md=sum(Decimal(c['delta'])for c in condition)/12;mp=sum(Decimal(c['percent'])for c in condition)/12
 ratio=100*(sum(Decimal(c['meanE'])for c in condition)-sum(Decimal(c['meanG'])for c in condition))/sum(Decimal(c['meanG'])for c in condition)
 assert abs(md-Decimal(peer['aggregate']['all12_mean_delta_m']))<Decimal('1e-50')
 assert abs(mp-Decimal(peer['aggregate']['all12_mean_condition_percent']))<Decimal('1e-50')
 out={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_SAVED_SUMMARY_RECOMPUTATION','raw_byte_identity_checked':True,'raw_archive_sha256':r['sha256'],'calls':72,'pairs':36,'conditions':12,'mean_condition_delta_m':str(md),'mean_condition_percent':str(mp),'ratio_of_condition_means_percent':str(ratio),'pair_sign_counts':dict(Counter('E_longer'if d>Decimal('1e-8')else'G_longer'if d<Decimal('-1e-8')else'tie'for d in delta)),'per_condition':condition,'method':'Independently expanded saved output service orders using original upper-triangle graph paths and reverse traversal, Decimal80 full polyline sums, independently rounded E/G integer proxy costs; no author modules or optimizer. Geometry and shortest-path validity are covered by the distinct existing peer audit, not repeated here.','new_optimizer_calls':0}
 (O/'EE130_SAVED_SUMMARY_RECOMPUTATION.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k!='per_condition'}))
