"""Only invented fixture data. Never reads or recomputes any actual project geometry."""
from decimal import Decimal
from audit_core import (quantize_saved, make_adjacency, shortest_distances,
                        GeometryAudit, interior_customers, distance, close, audit_input_instance, audit_route)
from geometry_exact import audit_segment
import datetime,json,pathlib

def run():
    checks=[]
    assert quantize_saved(Decimal('0'))==0
    assert quantize_saved(Decimal('0.000499999999999999'))==0
    assert quantize_saved(Decimal('0.0005'))==1
    assert quantize_saved(Decimal('1.2345'))==1235
    assert quantize_saved(Decimal('1.234499999999999'))==1234
    try:quantize_saved(Decimal('-1'))
    except AssertionError:pass
    else:raise AssertionError('Negative distance accepted')
    checks.append('Exact saved-decimal half-up including both sides of half boundary')
    nodes=[None]*6
    adj,em=make_adjacency(nodes,[[0,1,2],[1,2,2],[0,3,1],[2,4,1],[0,5,'0.1'],[4,5,'0.1']])
    d=shortest_distances(adj,3,{3,4,5})
    assert d[4]==6 and d[5]==Decimal('1.1')
    assert shortest_distances(adj,4,{3,4,5})[3]==6
    adj2,_=make_adjacency([None]*3,[[0,1,1]])
    assert shortest_distances(adj2,0,{0,2})[2].is_infinite()
    checks.append('Saved-weight shortest paths prohibit other service-node transit; disconnected graph stays disconnected')
    wkt='POLYGON ((0 0,30 0,30 30,0 30,0 0),(8 8,12 8,12 12,8 12,8 8),(18 18,20 18,20 20,18 20,18 18),(22 22,24 22,24 24,22 24,22 22))'
    g=GeometryAudit(wkt)
    safe=g.segment([2,3],[28,3]);assert safe['covered'] and safe['exact'] and safe['label']=='PASS'
    crossed=g.segment([2,10],[16,10]);assert not crossed['covered'] and not crossed['exact']
    below=g.segment([2,'1.099999999'],[28,'1.099999999']);assert not below['exact'] and below['label']=='UNCERTAIN_BOUNDARY'
    equal=g.segment([2,'1.1'],[28,'1.1']);assert equal['exact'] and equal['label']=='UNCERTAIN_BOUNDARY'
    above=g.segment([2,'1.10000002'],[28,'1.10000002']);assert above['exact'] and above['label']=='PASS'
    outside=g.segment([-2,3],[-2,20]);assert not outside['covered'] and not outside['exact']
    corner=g.segment([7,7],[7,13]);assert not corner['exact']
    checks.append('Whole segments through holes, outside field, and exact 1.10 m boundary semantics')
    coords=[[0,0],[1,1],[2,2],[3,3],[2,'2.00000000001']]
    assert interior_customers([0,0],[3,3],coords,exclude=(3,))==[1,2]
    assert interior_customers([0,0],[0,0],coords)==[]
    assert interior_customers([3,3],[0,0],coords,exclude=(3,))==[1,2]
    checks.append('Exact segment-interior customer incidence independent of service events and direction')
    assert distance([0,0],[3,4])==5
    close('5.000000009','5',Decimal('1e-8'))
    try:close('5.000000011','5',Decimal('1e-8'))
    except AssertionError:pass
    else:raise AssertionError('Residual over tolerance accepted')
    checks.append('Independent Decimal length and explicit residual tolerance')
    ins={'instance_id':'synthetic_collinear_only','n':2,'coordinates':[[2,3],[10,3],[25,3]]}
    base={'nodes':[],'edges':[]}
    gr={'nodes':ins['coordinates'],'service_node_ids':[0,1,2],
        'unreachable_service_pairs':[],'graph_nodes':3,'graph_edges':3,
        'added_visibility_edges':[[0,1,8],[0,2,23],[1,2,15]],
        'distance_matrix':[[0,8,23],[8,0,15],[23,15,0]],
        'paths':[[[0],[0,1],[0,2]],[[1,0],[1],[1,2]],[[2,0],[2,1],[2]]]}
    summ,dd,pp,ll=audit_input_instance(ins,base,gr,g)
    assert summ['canonical_service_leg_interior_customer_events']==[{'service_leg':[0,2],'segment_index':0,'node_ids':[0,2],'interior_customer_ids':[1]}]
    rr=audit_route([0,1,2,0],ins,gr,dd,pp,ll,g)
    assert Decimal(rr['actual_length_m'])==46 and rr['service_event_count']==2
    assert rr['interior_customer_events'][0]['interior_customer_ids']==[1]
    try:audit_route([0,1,1,0],ins,gr,dd,pp,ll,g)
    except AssertionError:pass
    else:raise AssertionError('Duplicate service visit accepted')
    checks.append('Complete invented input and route, exact interior pass-through preserved without duplicate service')
    return {'status':'PASS_SYNTHETIC_ONLY','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'checks':checks,'actual_project_inputs_read':False,'real_geometry_or_distance_recomputed':False,
            'optimizer_called':False}

if __name__=='__main__':
    result=run()
    p=pathlib.Path(__file__).resolve().parents[1]/'evidence/SYNTHETIC_REVIEW_02.json'
    with p.open('x') as f:json.dump(result,f,indent=2,ensure_ascii=False);f.write('\n')
    print(json.dumps(result,ensure_ascii=False))
