"""Independent saved-data audit primitives; no solver, author, GDAL or network imports.

This module is inert on import. Real geometry/distance calls are allowed only by
our post-RAW gated entrypoint. PREEXEC may use synthetic objects only.
"""
from decimal import Decimal, localcontext, ROUND_HALF_UP, getcontext
from fractions import Fraction
from heapq import heappush, heappop
import json
from geometry_exact import (parse_wkt, scale_for, grid_geometry, grid_point,
                            audit_segment, sqrt_interval, on)

TOL = Decimal('1e-8')
PRECISION = 60
getcontext().prec = PRECISION

def load_decimal(path):
    with open(path) as f:
        return json.load(f, parse_float=Decimal)

def dec(x):
    return x if isinstance(x, Decimal) else Decimal(str(x))

def distance(a, b):
    with localcontext() as ctx:
        ctx.prec = PRECISION
        return sum((dec(x)-dec(y))**2 for x,y in zip(a,b)).sqrt()

def total(values):
    with localcontext() as ctx:
        ctx.prec = PRECISION
        return sum((dec(x) for x in values), Decimal(0))

def quantize_saved(value):
    with localcontext() as ctx:
        ctx.prec = PRECISION
        x = dec(value)
        assert x.is_finite() and x >= 0
        q = int((x*1000).to_integral_value(rounding=ROUND_HALF_UP))
        assert abs(Decimal(q)/1000-x) <= Decimal('0.0005')
        return q

def close(a,b,tol=TOL):
    delta=abs(dec(a)-dec(b))
    assert delta <= tol, f'Distance residual {delta} exceeds {tol}: {a} versus {b}'
    return delta

def make_adjacency(nodes, edges):
    adj=[[] for _ in nodes]
    edge_map={}
    for a,b,w in edges:
        assert type(a) is int and type(b) is int and 0 <= a < b < len(nodes)
        assert (a,b) not in edge_map
        w=dec(w)
        assert w.is_finite() and w>0
        edge_map[a,b]=w
        adj[a].append((b,w));adj[b].append((a,w))
    for row in adj:
        row.sort()
    return adj,edge_map

def shortest_distances(adj, source, service_ids):
    """Exact arithmetic on the finite saved-decimal edge weights, not geometric reweighting.

    Services may be endpoints but no service except source can be an interior
    transit node. No path optimization or replacement of saved paths occurs.
    """
    with localcontext() as ctx:
        ctx.prec=PRECISION
        ds=[Decimal('Infinity')]*len(adj)
        ds[source]=Decimal(0)
        heap=[(Decimal(0),source)]
        while heap:
            value,u=heappop(heap)
            if value != ds[u]:
                continue
            if u in service_ids and u != source:
                continue
            for v,w in adj[u]:
                candidate=value+w
                if candidate<ds[v]:
                    ds[v]=candidate
                    heappush(heap,(candidate,v))
        return ds

class GeometryAudit:
    """Exact rational clearance/containment on every saved-decimal segment."""
    def __init__(self, wkt):
        self.polys=parse_wkt(wkt)
        assert len(self.polys)==1 and len(self.polys[0])==4
        self.cache={}
        self.point_cache={}
    def segment(self,a,b):
        key=tuple(sorted((tuple(map(str,a)),tuple(map(str,b)))))
        if key not in self.cache:
            values=[x for r in self.polys[0] for p in r for x in p]
            values+=list(a)+list(b)
            scale=scale_for(values)
            rings=grid_geometry(self.polys,scale)[0]
            value=audit_segment(grid_point(a,scale),grid_point(b,scale),rings,scale)
            self.cache[key]=value
        return self.cache[key]
    def point(self,p):
        return self.segment(p,p)

def interior_customers(a,b,coordinates,exclude=()):
    """Exact coordinate incidence, not an extra service event."""
    aa=tuple(Fraction(str(v)) for v in a)
    bb=tuple(Fraction(str(v)) for v in b)
    found=[]
    if aa==bb:
        return found
    for customer,p in enumerate(coordinates):
        if customer==0 or customer in exclude:
            continue
        pp=tuple(Fraction(str(v)) for v in p)
        if pp!=aa and pp!=bb and on(pp,aa,bb):
            found.append(customer)
    return found

def audit_input_instance(instance, base, graph, geometry):
    """Full real-data audit; call after verified RAW, never during PREEXEC."""
    n=instance['n'];coordinates=instance['coordinates'];nodes=graph['nodes']
    b=len(base['nodes']);count=n+1
    assert len(coordinates)==count and nodes==base['nodes']+coordinates
    service=list(range(b,b+count));service_set=set(service)
    assert graph['service_node_ids']==service
    assert graph['unreachable_service_pairs']==[]
    assert graph['graph_nodes']==len(nodes)
    assert all(v>=b for u,v,w in graph['added_visibility_edges'])
    edges=base['edges']+graph['added_visibility_edges']
    adj,em=make_adjacency(nodes,edges)
    assert graph['graph_edges']==len(em)
    max_edge=Decimal(0)
    for (u,v),w in em.items():
        max_edge=max(max_edge,close(w,distance(nodes[u],nodes[v])))
    D=graph['distance_matrix'];paths=graph['paths']
    assert len(D)==len(paths)==count
    assert all(len(r)==count for r in D+paths)
    max_sym=Decimal(0);max_path=Decimal(0);max_weights=Decimal(0)
    canonical_paths=[[None]*count for _ in range(count)]
    canonical_D=[[Decimal(0)]*count for _ in range(count)]
    actual_lengths=[[Decimal(0)]*count for _ in range(count)]
    used_edges=set();canonical_interior_events=[]
    for i in range(count):
        for j in range(count):
            p=paths[i][j]
            assert p and p[0]==service[i] and p[-1]==service[j]
            assert all(type(k) is int and 0<=k<len(nodes) for k in p)
            assert all(k not in service_set for k in p[1:-1])
            assert len(p)==len(set(p)), 'Frozen positive-weight shortest path cannot contain a cycle'
            assert (p==[service[i]] and dec(D[i][j])==0) if i==j else dec(D[i][j])>0
            edge_ids=[tuple(sorted((u,v))) for u,v in zip(p,p[1:])]
            assert all(k in em for k in edge_ids)
            weighted=total(em[k] for k in edge_ids)
            actual=total(distance(nodes[u],nodes[v]) for u,v in zip(p,p[1:]))
            max_path=max(max_path,close(actual,D[i][j]))
            max_weights=max(max_weights,close(weighted,D[i][j]))
            max_sym=max(max_sym,close(D[i][j],D[j][i]))
            if i<=j:
                canonical_D[i][j]=canonical_D[j][i]=dec(D[i][j])
                canonical_paths[i][j]=list(p);canonical_paths[j][i]=list(reversed(p))
                actual_lengths[i][j]=actual_lengths[j][i]=actual
                used_edges.update(edge_ids)
                for seg,(u,v) in enumerate(zip(p,p[1:])):
                    hits=interior_customers(nodes[u],nodes[v],coordinates,exclude=(i,j))
                    if hits:
                        canonical_interior_events.append({'service_leg':[i,j],'segment_index':seg,'node_ids':[u,v],'interior_customer_ids':hits})
    max_shortest=Decimal(0)
    for i,s in enumerate(service):
        ds=shortest_distances(adj,s,service_set)
        for j,t in enumerate(service):
            assert ds[t].is_finite(), 'Finite saved graph is disconnected under service-transit restriction'
            max_shortest=max(max_shortest,close(ds[t],D[i][j]))
    labels={'PASS':0,'UNCERTAIN_BOUNDARY':0,'FAIL':0};minimum=None
    for u,v in sorted(used_edges):
        result=geometry.segment(nodes[u],nodes[v])
        assert result['covered'] and result['exact'], f'Unsafe saved segment {(u,v)}'
        labels[result['label']]+=1
        minimum=result['q'] if minimum is None else min(minimum,result['q'])
    for p in coordinates:
        check=geometry.point(p)
        assert check['covered'] and check['exact'], 'Unsafe service endpoint'
    summary={'instance_id':instance['instance_id'],'n':n,'service_pair_entries':count*count,
             'graph_edges_checked':len(em),'unique_selected_path_segments':len(used_edges),
             'geometry_labels':labels,'minimum_clearance_interval_m':sqrt_interval(minimum),
             'maximum_edge_representation_residual_m':str(max_edge),
             'maximum_directional_matrix_residual_m':str(max_sym),
             'maximum_saved_path_length_residual_m':str(max_path),
             'maximum_saved_edge_sum_residual_m':str(max_weights),
             'maximum_independent_shortest_distance_residual_m':str(max_shortest),
             'canonical_service_leg_interior_customer_events':canonical_interior_events,
             'shortest_scope':'Frozen finite graph, saved decimal weights, no intermediate service nodes; no continuous-space optimality claim.'}
    return summary,canonical_D,canonical_paths,actual_lengths

def audit_route(route, instance, graph, canonical_D, canonical_paths, actual_lengths, geometry):
    n=instance['n'];nodes=graph['nodes'];coordinates=instance['coordinates']
    assert type(route) is list and len(route)==n+2 and route[0]==route[-1]==0
    assert all(type(i) is int for i in route)
    assert sorted(route[1:-1])==list(range(1,n+1))
    mapped=[];interior_events=[];segment_uses=[]
    for leg,(a,b) in enumerate(zip(route,route[1:])):
        p=canonical_paths[a][b]
        mapped.extend(p if not mapped else p[1:])
        for segment,(u,v) in enumerate(zip(p,p[1:])):
            check=geometry.segment(nodes[u],nodes[v])
            assert check['covered'] and check['exact']
            segment_uses.append(check)
            hits=interior_customers(nodes[u],nodes[v],coordinates,exclude=(a,b))
            if hits:
                interior_events.append({'service_leg_index':leg,'service_leg':[a,b],
                    'segment_index':segment,'node_ids':[u,v],'interior_customer_ids':hits})
    assert nodes[mapped[0]]==nodes[mapped[-1]]==coordinates[0]
    actual=total(distance(nodes[a],nodes[b]) for a,b in zip(mapped,mapped[1:]))
    saved_sum=total(canonical_D[a][b] for a,b in zip(route,route[1:]))
    residual=close(actual,saved_sum,TOL*(n+1))
    close(actual,total(actual_lengths[a][b] for a,b in zip(route,route[1:])),Decimal('1e-50'))
    return {'actual_length_m':str(actual),'saved_matrix_sum_m':str(saved_sum),
            'matrix_to_polyline_residual_m':str(residual),'matrix_to_polyline_tolerance_m':str(TOL*(n+1)),
            'mapped_polyline_node_ids':mapped,'segment_uses':len(segment_uses),
            'minimum_clearance_interval_m':sqrt_interval(min(x['q'] for x in segment_uses)),
            'exact_geometry_pass':True,'conservative_boundary_label':('PASS' if all(x['label']=='PASS' for x in segment_uses) else 'UNCERTAIN_BOUNDARY'),
            'interior_customer_events':interior_events,'service_event_count':n}


def check_native_activities(route, activities, n):
    """Validate the 0.14 client-index/location distinction without importing PyVRP."""
    assert len(activities)==len(route)==n+2
    for k,a in enumerate(activities):
        assert type(a['idx']) is int and type(a['location']) is int and type(a['node']) is int
        if k in (0,len(route)-1):
            assert a['type']=='DEPOT' and a['idx']==a['location']==a['node']==route[k]==0
        else:
            assert a['type']=='CLIENT' and 0<=a['idx']<n
            assert a['idx']+1==a['location']==a['node']==route[k]
    assert sorted(route[1:-1])==list(range(1,n+1))
    return True
