"""Invented missingness/denominator statistics only; no actual inputs loaded."""
from review_saved import summarize
from pathlib import Path
import datetime,json
conditions=[f'SYNTHETIC_{x}' for x in range(12)]
rows=[{'instance_id':ident,'seed':seed,'arm':a,'status':'PASS_INDEPENDENT_ROUTE','actual_length_m':str(100+(a=='E')*10)} for ident in conditions for seed in [0,1,2] for a in ['E','G']]
p,c,g=summarize(rows,conditions)
assert len(p)==36 and len(c)==12 and g['all12_mean_delta_m']=='10' and g['all12_mean_condition_percent']=='10'
assert all(x['passes']==36 and x['planned_denominator']==36 for x in g['pass_rates'].values())
rows[0]['status']='NOT_STARTED_OR_NO_RESULT'
p,c,g=summarize(rows,conditions)
assert not p[0]['complete_valid_pair'] and c[0]['mean_delta_m'] is None
assert g['all12_mean_delta_m'] is None and g['all12_mean_condition_percent'] is None and g['complete_conditions']==11
assert g['pass_rates']['E']['passes']==35 and g['pass_rates']['E']['planned_denominator']==36
for x in rows:x['status']='NOT_STARTED_OR_NO_RESULT'
p,c,g=summarize(rows,conditions)
assert g['complete_conditions']==0 and g['complete_condition_descriptive_mean_delta_m'] is None
assert all(x['passes']==0 and x['planned_denominator']==36 for x in g['pass_rates'].values())
r={'status':'PASS_SYNTHETIC_STATISTICS','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'planned_rows':72,'planned_pairs':36,'planned_conditions':12,'main_missingness_enforced':True,'fixed_denominators_enforced':True,'real_inputs_read':False}
out=Path(__file__).resolve().parents[1]/'evidence/SYNTHETIC_STATISTICS.json'
with out.open('x') as f:json.dump(r,f,indent=2);f.write('\n')
print(json.dumps(r))
