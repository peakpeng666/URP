"""Invented native Activity corruption tests; no solver or real-data imports."""
from audit_core import check_native_activities
from pathlib import Path
import copy,datetime,json
route=[0,2,1,0]
activities=[{'type':'DEPOT','idx':0,'location':0,'node':0},{'type':'CLIENT','idx':1,'location':2,'node':2},{'type':'CLIENT','idx':0,'location':1,'node':1},{'type':'DEPOT','idx':0,'location':0,'node':0}]
assert check_native_activities(route,activities,2)
checks=['Correct zero-based client index maps to one-based service location']
for label,index,key,value in [('wrong_client_index',1,'idx',2),('wrong_depot_index',0,'idx',7),('fake_client_at_depot',0,'type','CLIENT'),('wrong_location',2,'location',2)]:
    bad=copy.deepcopy(activities);bad[index][key]=value
    try:check_native_activities(route,bad,2)
    except AssertionError:checks.append(label)
    else:raise AssertionError(label+' was accepted')
r={'status':'PASS_SYNTHETIC_ACTIVITY_MAPPING','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':checks,'real_data_used':False,'optimizer_called':False}
p=Path(__file__).resolve().parents[1]/'evidence/SYNTHETIC_ACTIVITY_MAPPING.json'
with p.open('x')as f:json.dump(r,f,indent=2);f.write('\n')
print(json.dumps(r))
