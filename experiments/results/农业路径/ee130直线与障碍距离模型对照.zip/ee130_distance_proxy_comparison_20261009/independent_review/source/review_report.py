"""Final comparison of authored report with already audited saved results.
No optimizer, shortest paths, or geometry computations are executed here.
"""
from pathlib import Path
from decimal import Decimal,localcontext
import datetime,json,hashlib
R=Path(__file__).resolve().parents[2]
def load(p):return json.loads((R/p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def close(a,b):
    if a is None or b is None:
        assert a is None and b is None
    else:
        with localcontext()as c:
            c.prec=80
            assert abs(Decimal(a)-Decimal(b))<=Decimal('1e-45'),(a,b)
def main():
    review=load('independent_review/results/INDEPENDENT_SAVED_REVIEW.json')
    summary=load('reports/SUMMARY.json')
    if review['status']!='PASS_COMPLETE_INDEPENDENT_REVIEW':
        assert summary['status']=='UNVERIFIED_NO_VALID_PRIMARY_CONCLUSION' and summary['primary'] is None
        retained=summary['all_scheduled_slots_and_call_evidence']
        assert len(retained)==72 and [r['call_id']for r in retained]==[r['call_id']for r in review['rows']]
        assert summary['recorded_calls']==review['recorded_results'] and summary['spawned_calls']==review['processes_spawned']
        result={'status':'PASS_UNVERIFIED_REPORT_FIDELITY','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
                'independent_review_status':review['status'],'all72_planned_slots_retained':True,'valid_primary_conclusion':False,
                'independent_result_sha256':sha(R/'independent_review/results/INDEPENDENT_SAVED_REVIEW.json'),
                'authored_report_sha256':{str(p.relative_to(R)):sha(p)for p in sorted((R/'reports').glob('*'))if p.is_file()}}
        with(R/'independent_review/results/FINAL_REPORT_REVIEW.json').open('x')as f:json.dump(result,f,indent=2);f.write('\n')
        print(json.dumps(result));return
    authored=load('reports/SAVED_ROUTE_AUDIT.json')['rows']
    assert len(authored)==len(review['rows'])==72 and len(summary['pairs'])==36 and len(summary['conditions'])==12
    by={r['call_id']:r for r in authored}
    for r in review['rows']:
        a=by[r['call_id']]
        assert a['instance_id']==r['instance_id']and a['seed']==r['seed']and a['arm']==r['arm']
        assert (a['status']=='VALID_EXACT_SAFE_ROUTE')==(r['status']=='PASS_INDEPENDENT_ROUTE')
        if r['status']=='PASS_INDEPENDENT_ROUTE':
            assert a['route']==r['route'] and a['mapped_polyline_node_ids']==r['mapped_polyline_node_ids']
            assert a['all_segments_exact_safe'] and a['service_events_each_once'] and a['integer_search_cost']==r['integer_proxy_cost']
            close(a['actual_length_m_decimal80'],r['actual_length_m'])
            close(a['unrounded_search_proxy_m_decimal80'],r['unrounded_proxy_cost_m'])
            close(a['saved_graph_leg_sum_m_decimal80'],r['saved_matrix_sum_m'])
            assert len(a['segments'])==r['segment_uses']
            authored_hits=sorted((x['segment_index'],x['service_id']) for x in a['incidental_geometric_passages'] if x['service_id']!=0)
            prefix=0;independent_hits=[]
            for leg_idx,leg in enumerate(a['legs']):
                for x in r['interior_customer_events']:
                    if x['service_leg_index']==leg_idx:
                        for cid in x['interior_customer_ids']:independent_hits.append((prefix+x['segment_index'],cid))
                prefix+=len(leg['node_ids'])-1
            assert authored_hits==sorted(independent_hits)
    for a,r in zip(summary['pairs'],review['pairs']):
        assert (a['instance_id'],a['seed'],a['valid'])==(r['instance_id'],r['seed'],r['complete_valid_pair'])
        close(a['delta_m_decimal80'],r['delta_m'])
    for a,r in zip(summary['conditions'],review['conditions']):
        assert a['instance_id']==r['instance_id'] and a['complete_three_seed_pairs']==r['complete_three_seed_condition']
        close(a['mean_delta_m_decimal80'],r['mean_delta_m']);close(a['percent_of_mean_G_decimal80'],r['percent'])
    close(summary['primary']['mean_condition_delta_m_decimal80'],review['aggregate']['all12_mean_delta_m'])
    close(summary['primary']['mean_condition_percent_decimal80'],review['aggregate']['all12_mean_condition_percent'])
    for arm in ['E','G']:
        assert summary['per_arm'][arm]['valid']==review['aggregate']['pass_rates'][arm]['passes']
        assert summary['per_arm'][arm]['planned']==36
    text=(R/'reports/REPORT_ZH.txt').read_text()
    for token in ['72','PyVRP0.14.0','1.10','半径','最优','嵌套','连续平面全局最优','失败','无warm start']:
        assert token in text,token
    result={'status':'PASS_FINAL_REPORT_COMPARISON','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'routes_compared':72,'pairs_compared':36,'conditions_compared':12,'raw_numeric_recomputed':False,
            'independent_result_sha256':sha(R/'independent_review/results/INDEPENDENT_SAVED_REVIEW.json'),
            'authored_report_sha256':{str(p.relative_to(R)):sha(p)for p in sorted((R/'reports').glob('*'))if p.is_file()},
            'limitation':'Mechanical value/semantics comparison is supplemented by reviewer reading the final narrative.'}
    with (R/'independent_review/results/FINAL_REPORT_REVIEW.json').open('x')as f:json.dump(result,f,ensure_ascii=False,indent=2);f.write('\n')
    print(json.dumps(result))
if __name__=='__main__':main()
