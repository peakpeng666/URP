"""Post-run requested reader-report verification from already audited saved values.
This reviewer is a disclosed post-run reporting addition. No experimental source
is changed, and no geometry, shortest-path computation, or optimizer is run.
"""
from pathlib import Path
from decimal import Decimal,localcontext
from collections import Counter
import datetime,hashlib,json
from review_saved import verify_frozen,verify_old,verify_gates
R=Path(__file__).resolve().parents[2]
def load(p):return json.loads((R/p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def sign(v):
    v=Decimal(v);t=Decimal('1e-8')
    return 'E_longer_G_better'if v>t else'G_longer_E_better'if v<-t else'numeric_tie_within1e-8m'
def close(a,b):
    with localcontext()as c:
        c.prec=80
        assert abs(Decimal(str(a))-Decimal(str(b)))<=Decimal('1e-45'),(a,b)
def normalize(c):return {k:c.get(k,0)for k in ['E_longer_G_better','G_longer_E_better','numeric_tie_within1e-8m']}
def main():
    gate=verify_gates();i=load('independent_review/results/INDEPENDENT_SAVED_REVIEW.json')
    d=load('reports/DETAIL_SUMMARY.json');a=load('reports/SUMMARY.json');text=(R/'reports/FINAL_REPORT_ZH.txt').read_text()
    assert i['status']=='PASS_COMPLETE_INDEPENDENT_REVIEW' and len(i['rows'])==72
    pc=Counter(sign(x['delta_m'])for x in i['pairs']);cc=Counter(sign(x['mean_delta_m'])for x in i['conditions'])
    assert normalize(d['pair_counts'])==normalize(pc) and normalize(d['condition_counts'])==normalize(cc)
    assert d['numeric_tie_threshold_m']=='1e-8'
    assert d['negative_pairs_beyond_tolerance']==[] and d['negative_conditions_beyond_tolerance']==[]
    maxd=max(Decimal(x['delta_m'])for x in i['pairs'])
    ties=[x for x in i['pairs']if abs(Decimal(x['delta_m'])-maxd)<=Decimal('1e-8')]
    assert len(ties)==3 and {x['instance_id']for x in ties}=={'C_n40_s202610082302'} and {x['seed']for x in ties}=={0,1,2}
    close(d['maximum_positive_pair_raw_argmax_audit_only']['delta_m_decimal80'],maxd)
    listed=d['maximum_positive_pairs_within_tolerance']
    assert len(listed)==3 and {x['seed']for x in listed}=={0,1,2} and all(x['instance_id']=='C_n40_s202610082302'for x in listed)
    assert d['maximum_positive_condition']['instance_id']=='C_n40_s202610082302'
    close(d['maximum_positive_condition']['mean_delta_m_decimal80'],max(Decimal(x['mean_delta_m'])for x in i['conditions']))
    close(d['primary']['mean_condition_delta_m_decimal80'],i['aggregate']['all12_mean_delta_m'])
    close(d['primary']['mean_condition_percent_decimal80'],i['aggregate']['all12_mean_condition_percent'])
    with localcontext()as ctx:
        ctx.prec=80
        ee=sum(Decimal(x['mean_E_m'])for x in i['conditions'])/12
        gg=sum(Decimal(x['mean_G_m'])for x in i['conditions'])/12
        close(d['primary']['ratio_of_condition_means_percent_decimal80'],100*(ee-gg)/gg)
        for n in [8,20,40]:
            cond=[x for x in i['conditions']if x['instance_id'].startswith(f'C_n{n:02d}')]
            pairs=[x for x in i['pairs']if x['instance_id'].startswith(f'C_n{n:02d}')]
            row=d['by_n'][str(n)];assert row['condition_count']==4 and row['pair_count']==12 and row['complete_conditions']==4
            close(row['mean_delta_m'],sum(Decimal(x['mean_delta_m'])for x in cond)/4)
            close(row['mean_condition_percent'],sum(Decimal(x['percent'])for x in cond)/4)
            assert normalize(row['condition_counts'])==normalize(Counter(sign(x['mean_delta_m'])for x in cond))
            assert normalize(row['pair_counts'])==normalize(Counter(sign(x['delta_m'])for x in pairs))
    assert d['incidental_customer_passage_count']==0==sum(len(x['interior_customer_events'])for x in i['rows'])
    for rel,digest in d['source_identity'].items():assert sha(R/rel)==digest
    wrapper=load('independent_review/evidence/SAVED_REVIEW_RUN.json')
    resources=d['resources']
    assert resources['independent_review_cpu_seconds']==wrapper['cpu_seconds'] and resources['independent_review_wall_seconds']==wrapper['wall_seconds']
    assert resources['independent_review_core_cpu_seconds']==i['cpu_seconds'] and resources['independent_review_core_wall_seconds']==i['wall_seconds']
    # The final wording must distinguish full-process accounting from core timing.
    assert any(f'{wrapper[k]:.3f}'in text for k in ['cpu_seconds'])
    assert f"{wrapper['wall_seconds']:.3f}" in text
    for token in ['0.179160','0.233573','1.455615','13.967023','1.676049','并列','1e-8','n=8','n=20','n=40','12条件不是12','不报告gap','不能称实车可执行','其他service顶点仅作终点','原D/paths保留不改','没有把几何通行设为不可行']:
        assert token in text,token
    result={'status':'PASS_FINAL_READER_REPORT','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'scope':'Post-run reporting only: independent saved statistics, counts, maxima/ties, strata, percentage definitions, resource attribution and limitations.',
            'pair_counts':normalize(pc),'condition_counts':normalize(cc),'maximum_positive_pair_tie_count':len(ties),
            'all_saved_raw_identity_verified':gate,'real_geometry_or_shortest_paths_recomputed':False,'optimizer_called':False,
            'final_files_sha256':{rel:sha(R/rel)for rel in ['reports/FINAL_REPORT_ZH.txt','reports/DETAIL_SUMMARY.json','source/present_saved_summary.py','independent_review/source/review_presentation.py']},
            'frozen_files_sha256':verify_frozen(),'old_files_unchanged':verify_old(),
            'manual_narrative_review':'Reviewer read the complete final text and confirmed its frozen-terminal-graph, physical-pass-through, finite-budget, sample-dependence, quantization, and hypothetical-disk limitations.'}
    with(R/'independent_review/results/FINAL_READER_REPORT_REVIEW.json').open('x')as f:json.dump(result,f,indent=2,ensure_ascii=False);f.write('\n')
    print(json.dumps(result,ensure_ascii=False))
if __name__=='__main__':main()
