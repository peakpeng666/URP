"""Once-only bounded post-RAW reviewer. Does not import author or solver modules."""
from pathlib import Path
import datetime,json,os,resource,signal,subprocess,sys,time
R=Path(__file__).resolve().parents[2]
E=R/'independent_review/evidence'
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def limits():
    resource.setrlimit(resource.RLIMIT_CPU,(179,179))
    resource.setrlimit(resource.RLIMIT_AS,(1073741824,1073741824))
def main():
    # This explicit gate check prevents even launching the real review early.
    gate=json.loads((R/'provenance/PARENT_AUDIT_APPROVAL.json').read_text())
    assert gate['approved'] is True
    assert (R/'provenance/RAW_UNREVIEWED_DRIVE_RECEIPT.json').is_file()
    with (E/'SAVED_REVIEW_STARTED.json').open('x') as f:
        json.dump({'utc':stamp(),'once_only':True,'no_optimizer':True},f)
    started=stamp();wall=time.perf_counter();before=resource.getrusage(resource.RUSAGE_CHILDREN)
    p=None;timeout=False;error=None
    with (E/'SAVED_REVIEW_STDOUT.log').open('x') as out,(E/'SAVED_REVIEW_STDERR.log').open('x') as err:
        try:
            p=subprocess.Popen([sys.executable,'-B',str(R/'independent_review/source/review_saved.py')],
                stdout=out,stderr=err,preexec_fn=limits,start_new_session=True,
                env={'PATH':'/usr/bin:/bin','HOME':'/tmp','LANG':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1'},cwd=R)
            try:p.wait(timeout=299)
            except subprocess.TimeoutExpired:timeout=True
        except Exception as ex:error=repr(ex)
        finally:
            if p is not None:
                try:os.killpg(p.pid,signal.SIGKILL)
                except ProcessLookupError:pass
                p.wait()
    used=resource.getrusage(resource.RUSAGE_CHILDREN)
    result={'status':'PASS_PROCESS' if p is not None and p.returncode==0 else 'FAILED_REVIEW_PROCESS',
            'started_utc':started,'finished_utc':stamp(),'returncode':p.returncode if p else None,
            'timeout':timeout,'error':error,'wall_seconds':time.perf_counter()-wall,
            'cpu_seconds':used.ru_utime+used.ru_stime-before.ru_utime-before.ru_stime,
            'peak_rss_kib':used.ru_maxrss,'child_cpu_limit_s':179,'external_wall_limit_s':299,
            'address_space_limit_bytes':1073741824,'optimizer_called':False,'process_group_reaped':True}
    with (E/'SAVED_REVIEW_RUN.json').open('x') as f:json.dump(result,f,ensure_ascii=False,indent=2);f.write('\n')
    print(json.dumps(result))
    return 0 if result['status']=='PASS_PROCESS' else 1
if __name__=='__main__':raise SystemExit(main())
