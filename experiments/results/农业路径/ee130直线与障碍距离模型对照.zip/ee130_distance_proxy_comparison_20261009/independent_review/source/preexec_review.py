"""Independent PREEXEC: identity, structure, frozen schedule and saved synthetic evidence.

Does not import author code, PyVRP, geometry evaluators, or shortest-path code.
Does not derive distances, geometry predicates, route costs, or real inputs.
"""
from pathlib import Path
import ast,datetime,hashlib,json
R=Path(__file__).resolve().parents[2]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads((R/p).read_text())
def main():
    assert not (R/'raw/EXECUTOR_STARTED.json').exists() and not (R/'raw/STARTED.json').exists()
    conditions=[f'C_n{n:02d}_s{s}'for n in [8,20,40]for s in range(202610082301,202610082305)]
    protocol=load('freeze/PROTOCOL.json');assert protocol['conditions']==conditions and protocol['calls']==72
    assert protocol['solver_seeds']==[0,1,2] and protocol['arms']==['E','G'] and protocol['scale']==1000
    schedule=load('freeze/SCHEDULE.json');expected=[]
    pair=0
    for ident in conditions:
        for seed in [0,1,2]:
            for arm in (['E','G']if pair%2==0 else['G','E']):
                expected.append({'call_id':f'{ident}_seed{seed}_{arm}','instance_id':ident,'seed':seed,'arm':arm,'pair_index':pair,'max_runtime_seconds':1.0})
            pair+=1
    assert schedule==expected
    identities=load('freeze/INPUT_IDENTITY.json')
    assert len(identities)==27
    for rel,m in identities.items():
        p=R/rel;s=Path(m['source'])
        assert p.read_bytes()==s.read_bytes() and p.stat().st_size==m['bytes'] and sha(p)==m['sha256']
    old_count=0
    for root in load('freeze/OLD_FILES_BEFORE.json')['roots']:
        p=Path(root['root']);assert {str(f.relative_to(p))for f in p.rglob('*')if f.is_file()}==set(root['files'])
        for rel,m in root['files'].items():
            assert (p/rel).stat().st_size==m['bytes']and sha(p/rel)==m['sha256'];old_count+=1
    base=load('input/shared_preprocessing.json');b=len(base['nodes']);assert b==455
    shapes=[];by_stream={}
    for ident in conditions:
        ins=load(f'input/{ident}_input.json');g=load(f'input/{ident}_graph.json');n=ins['n'];N=n+1
        assert ins['instance_id']==ident and ins['arm']=='C' and len(ins['coordinates'])==N
        assert ins['coordinates'][0]==[661922,6526122] and len({tuple(v)for v in ins['coordinates']})==N
        assert all(len(p)==2 for p in ins['coordinates'])
        assert g['nodes']==base['nodes']+ins['coordinates'] and g['service_node_ids']==list(range(b,b+N))
        assert len(g['nodes'])==g['graph_nodes'] and g['unreachable_service_pairs']==[]
        assert len(g['distance_matrix'])==len(g['paths'])==N
        assert all(len(r)==N for r in g['distance_matrix']+g['paths'])
        edgeids={(u,v)for u,v,w in base['edges']+g['added_visibility_edges']}
        assert len(edgeids)==g['graph_edges'] and all(type(u)is int and type(v)is int and 0<=u<v<len(g['nodes'])for u,v in edgeids)
        for i in range(N):
            assert g['distance_matrix'][i][i]==0 and g['paths'][i][i]==[b+i]
            for j in range(N):
                p=g['paths'][i][j]
                assert p[0]==b+i and p[-1]==b+j and all(type(k)is int and 0<=k<len(g['nodes'])for k in p)
                assert all(k<b for k in p[1:-1]) and all(tuple(sorted((u,v)))in edgeids for u,v in zip(p,p[1:]))
                assert g['paths'][j][i]==p[::-1] and g['distance_matrix'][j][i]==g['distance_matrix'][i][j]
        if ins['seed']in by_stream:assert ins['coordinates'][:len(by_stream[ins['seed']])]==by_stream[ins['seed']]
        by_stream[ins['seed']]=ins['coordinates']
        shapes.append({'instance_id':ident,'n':n,'graph_nodes':len(g['nodes']),'graph_edges':len(edgeids),'distance_or_geometry_recomputed':False})
    env=load('environment/RUNTIME.json');assert env['pyvrp_version']=='0.14.0'
    assert sha(Path(env['python_executable']).resolve())==env['python_binary_sha256']
    for m in env['installed_distribution_files']:
        p=Path(m['path']);assert p.stat().st_size==m['bytes']and sha(p)==m['sha256']
    syntax=[]
    for p in sorted(list((R/'source').rglob('*.py'))+list((R/'independent_review/source').glob('*.py'))):
        ast.parse(p.read_text());syntax.append(str(p.relative_to(R)))
    prep=load('selftests/PREPROCESS_SYNTHETIC.json');assert prep['status']=='PASS' and prep['synthetic_only'] and prep['actual_field_numeric_calculations']==0
    integ=load('selftests/SUPERVISOR_INTEGRATION.json');assert integ['status']=='PASS'and integ['synthetic_only']and integ['public_or_EE130_optimizer_calls']==0 and integ['synthetic_optimizer_calls']==2
    report_tests=[json.loads(p.read_text()) for p in sorted((R/'selftests').glob('REPORT_SYNTHETIC*.json'))]
    report_tests=[x for x in report_tests if x['status']=='PASS' and x['actual_numeric_data_used'] is False and x['source_sha256'].get('report.py')==sha(R/'source/report.py')]
    assert report_tests, 'No synthetic report evidence bound to current report source'
    for evidence in [prep,integ,report_tests[-1]]:
        for name,digest in evidence['source_sha256'].items():assert sha(R/'source'/name)==digest
    for record in integ['records']:
        for stream in ['stdout','stderr']:assert sha(R/record[stream])==record[stream+'_sha256']
    assert [r['status']for r in integ['records']]==['UNREVIEWED_PROCESS_SUCCESS','UNREVIEWED_PROCESS_SUCCESS','WALL_TIMEOUT','PROCESS_FAILURE_OR_CPU_LIMIT','PROCESS_FAILURE_OR_CPU_LIMIT','CALL_ERROR_UNDETERMINED']
    assert all(r['child_reaped']for r in integ['records'])and not integ['records'][-1]['process_spawned']
    cleanup=load('selftests/PROCESS_CLEANUP.json');assert cleanup['status']=='PASS'and len(cleanup['fixtures'])==3 and all(x['pass']and x['late_file_absent']for x in cleanup['fixtures'])
    independent=load('independent_review/evidence/SYNTHETIC_REVIEW_02.json');assert independent['status']=='PASS_SYNTHETIC_ONLY'and independent['actual_project_inputs_read']is False and independent['optimizer_called']is False
    stats=load('independent_review/evidence/SYNTHETIC_STATISTICS.json');assert stats['status']=='PASS_SYNTHETIC_STATISTICS'and stats['real_inputs_read']is False
    activities=load('independent_review/evidence/SYNTHETIC_ACTIVITY_MAPPING.json');assert activities['status']=='PASS_SYNTHETIC_ACTIVITY_MAPPING' and activities['real_data_used'] is False
    final=load('independent_review/evidence/INDEPENDENT_FIXTURES_FINAL.json');assert final['status']=='PASS_SYNTHETIC_ONLY'
    for rel,digest in final['source_sha256'].items():assert sha(R/rel)==digest
    result={'status':'PASS','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Independent source/manual design review plus identities, graph structure, fixed schedule, native-model synthetic outputs and failure fixtures only.',
            'conditions':shapes,'planned_calls':72,'pairs':36,'arms_first_counts':{'E':18,'G':18},'input_copies_verified':len(identities),'old_files_unchanged':old_count,
            'real_distance_recomputed':False,'real_shortest_path_recomputed':False,'real_geometry_recomputed':False,'actual_optimizer_called':False,
            'python_sources_parse_checked':syntax,'source_sha256':{str(p.relative_to(R)):sha(p)for p in sorted(list((R/'source').rglob('*.py'))+list((R/'independent_review/source').glob('*.py')))},
            'pending_execution_gates':['PREEXEC private upload and byte-identical readback','Parent permission for exact frozen hash and permitted timing window'],
            'post_raw_requirements':['RAW private readback before real independent recomputation','All-path full-segment exact geometry','Finite-graph saved-weight shortest distances with service-transit restriction','Actual route length, native model, fixed denominator and aggregate audit'],
            'limitations':['The PREEXEC pass does not certify real shortest paths or real geometric safety.','Other service nodes are non-transit terminals only by the historical frozen graph encoding; this is not a physical safety restriction. Coordinate passages do not add or remove service events.','One field, four nested streams; descriptive results only.']}
    for rel in ['freeze/INDEPENDENT_PRECHECK.json','independent_review/results/PREEXEC_REVIEW.json']:
        with (R/rel).open('x')as f:json.dump(result,f,indent=2,ensure_ascii=False);f.write('\n')
    print(json.dumps({'status':'PASS','copies':len(identities),'old_files':old_count,'formal_calls':0}))
if __name__=='__main__':main()
