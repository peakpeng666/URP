"""Independent post-RAW audit. No optimizer calls or author-module imports.

Requires the exact private RAW archive, verified byte-readback receipt, and an
explicit parent audit gate. PREEXEC must not execute this entrypoint.
"""
from pathlib import Path
from decimal import Decimal,localcontext
from fractions import Fraction
from collections import Counter
import datetime,hashlib,json,os,time,traceback,zipfile
from audit_core import (load_decimal,dec,total,distance,close,quantize_saved,
                        GeometryAudit,audit_input_instance,audit_route,check_native_activities,TOL)
R=Path(__file__).resolve().parents[2]

def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads((R/p).read_text())
def save(p,data):
    with (R/p).open('x') as f:
        json.dump(data,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
def verify_frozen():
    m=load('freeze/FROZEN_FILES.json')
    for rel,v in m['files'].items():
        p=R/rel
        assert p.stat().st_size==v['bytes'] and sha(p)==v['sha256'], f'Frozen mismatch {rel}'
    return sha(R/'freeze/FROZEN_FILES.json')
def verify_old():
    count=0
    for m in load('freeze/OLD_FILES_BEFORE.json')['roots']:
        p=Path(m['root']);assert {str(x.relative_to(p)) for x in p.rglob('*') if x.is_file()}==set(m['files'])
        for rel,v in m['files'].items():
            assert (p/rel).stat().st_size==v['bytes'] and sha(p/rel)==v['sha256'],str(p/rel)
            count+=1
    return count

def verify_gates():
    frozen=verify_frozen()
    receipt=load('provenance/RAW_UNREVIEWED_DRIVE_RECEIPT.json')
    assert receipt['owner_only'] is True and receipt['shared'] is False
    assert receipt['remote_readback_sha256_verified'] is True and receipt['download_byte_identical'] is True
    assert receipt['frozen_files_sha256']==frozen
    archive=R.parent/(R.name+'_RAW_UNREVIEWED.zip')
    assert receipt['sha256']==receipt['download_sha256']==sha(archive)==sha(receipt['download_path'])
    approval=load('provenance/PARENT_AUDIT_APPROVAL.json')
    assert approval['approved'] is True
    assert approval['raw_archive_sha256']==receipt['sha256'] and approval['frozen_files_sha256']==frozen
    with zipfile.ZipFile(archive) as z:
        for rel in ['freeze/FROZEN_FILES.json','raw/RAW_UNREVIEWED_MANIFEST.json']:
            assert z.read(R.name+'/'+rel)==(R/rel).read_bytes(), f'Archived identity mismatch {rel}'
    manifest=load('raw/RAW_UNREVIEWED_MANIFEST.json')
    paths={str(p.relative_to(R)) for p in (R/'raw').rglob('*') if p.is_file() and '__pycache__' not in p.parts}
    assert paths==set(manifest['files'])|{'raw/RAW_UNREVIEWED_MANIFEST.json'}
    for rel,v in manifest['files'].items():
        assert (R/rel).stat().st_size==v['bytes'] and sha(R/rel)==v['sha256'], f'Raw mismatch {rel}'
    return {'frozen_files_sha256':frozen,'raw_archive_sha256':receipt['sha256'],
            'raw_readback_verified':True,'raw_files_checked':len(paths),'old_files_checked':verify_old()}

def check_preprocess(instance,graph,independent_D,paths,lengths,geometry):
    ident=instance['instance_id'];p=R/f'raw/preprocess/{ident}.json'
    actual=load_decimal(p)
    assert actual['status']=='PASS_PREPROCESS' and actual['instance_id']==ident
    assert actual['coordinates']==instance['coordinates'] and actual['n']==instance['n']
    n=instance['n'];N=n+1
    assert actual['capacity']==n and actual['K']==1 and actual['demands']==[0]+[1]*n
    assert actual['canonical_paths']==paths
    matrix=actual['unrounded_matrices'];integer=actual['integer_matrices']
    assert matrix['G']==independent_D
    max_e=Decimal(0);max_q=Decimal(0)
    for arm in ['E','G']:
        assert len(matrix[arm])==len(integer[arm])==N
        for i in range(N):
            assert len(matrix[arm][i])==len(integer[arm][i])==N
            for j in range(N):
                value=dec(matrix[arm][i][j]);q=integer[arm][i][j]
                assert value==dec(matrix[arm][j][i]) and (i!=j or value==0)
                assert type(q) is int and q==quantize_saved(value)
                max_q=max(max_q,abs(Decimal(q)/1000-value))
                if arm=='E':max_e=max(max_e,close(value,distance(instance['coordinates'][i],instance['coordinates'][j])))
    for row in actual['endpoint_checks']:
        g=geometry.point(instance['coordinates'][row['service_id']])
        assert row['exact_safe']==g['exact'] and row['closed_containment']==g['covered'] and row['tolerance_label']==g['label']
        assert Fraction(*map(int,row['clearance_squared_fraction']))==g['q']
    for row in actual['unique_path_segments']:
        u,v=row['node_ids'];g=geometry.segment(graph['nodes'][u],graph['nodes'][v])
        assert row['exact_safe']==g['exact'] and row['closed_containment']==g['covered'] and row['tolerance_label']==g['label']
        assert Fraction(*map(int,row['clearance_squared_fraction']))==g['q']
    return actual,{'maximum_E_representation_residual_m':str(max_e),'maximum_quantization_residual_m':str(max_q)}

def load_lines(p):
    path=R/p
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()] if path.exists() else []

def mean(values):
    with localcontext() as c:
        c.prec=60
        return total(values)/len(values)

def summarize(rows,conditions):
    index={(x['instance_id'],x['seed'],x['arm']):x for x in rows}
    pairs=[];condition_results=[]
    for ident in conditions:
        pp=[]
        for seed in [0,1,2]:
            e,g=[index[ident,seed,a] for a in ['E','G']]
            ok=e['status']==g['status']=='PASS_INDEPENDENT_ROUTE'
            pair={'instance_id':ident,'seed':seed,'complete_valid_pair':ok,'delta_m':None}
            if ok:pair.update(delta_m=str(dec(e['actual_length_m'])-dec(g['actual_length_m'])),E_length_m=e['actual_length_m'],G_length_m=g['actual_length_m'])
            pairs.append(pair);pp.append(pair)
        valid=all(p['complete_valid_pair'] for p in pp)
        out={'instance_id':ident,'complete_three_seed_condition':valid,'mean_delta_m':None,'percent':None}
        if valid:
            e=mean([p['E_length_m'] for p in pp]);g=mean([p['G_length_m'] for p in pp])
            delta=mean([p['delta_m'] for p in pp])
            with localcontext() as c:
                c.prec=60
                out.update(mean_E_m=str(e),mean_G_m=str(g),mean_delta_m=str(delta),percent=str(100*(e-g)/g))
        condition_results.append(out)
    complete=[r for r in condition_results if r['complete_three_seed_condition']]
    group={'complete_conditions':len(complete),'planned_conditions':12,'all12_mean_delta_m':None,'all12_mean_condition_percent':None,
           'complete_condition_descriptive_mean_delta_m':None,'complete_condition_descriptive_mean_percent':None}
    if complete:
        group['complete_condition_descriptive_mean_delta_m']=str(mean([x['mean_delta_m'] for x in complete]))
        group['complete_condition_descriptive_mean_percent']=str(mean([x['percent'] for x in complete]))
        if len(complete)==12:
            group['all12_mean_delta_m']=group['complete_condition_descriptive_mean_delta_m']
            group['all12_mean_condition_percent']=group['complete_condition_descriptive_mean_percent']
    group['pass_rates']={a:{'passes':sum(x['status']=='PASS_INDEPENDENT_ROUTE' for x in rows if x['arm']==a),'planned_denominator':36,
                              'failure_status_counts':dict(Counter(x['status'] for x in rows if x['arm']==a and x['status']!='PASS_INDEPENDENT_ROUTE'))}for a in ['E','G']}
    return pairs,condition_results,group

def main():
    started=utc();clock=time.perf_counter();cpu=time.process_time();gate=verify_gates()
    protocol=load('freeze/PROTOCOL.json');conditions=protocol['conditions'];schedule=load('freeze/SCHEDULE.json')
    assert len(conditions)==12 and len(schedule)==72 and len({x['call_id'] for x in schedule})==72
    geometry=GeometryAudit((R/'input/projected_epsg32634.wkt').read_text())
    base=load_decimal(R/'input/shared_preprocessing.json')
    instances={};checks=[];input_failures={}
    for ident in conditions:
        try:
            inst=load_decimal(R/f'input/{ident}_input.json');graph=load_decimal(R/f'input/{ident}_graph.json')
            summary,D,paths,lengths=audit_input_instance(inst,base,graph,geometry)
            pre,pre_summary=check_preprocess(inst,graph,D,paths,lengths,geometry)
            summary.update(pre_summary)
            expected_passages=sorted((x['service_leg'][0],x['service_leg'][1],x['segment_index'],c) for x in summary['canonical_service_leg_interior_customer_events'] for c in x['interior_customer_ids'])
            recorded_passages=sorted((x['service_leg'][0],x['service_leg'][1],x['path_segment_index'],x['other_service_id']) for x in pre['geometric_passages'] if x['other_service_id']!=0)
            assert expected_passages==recorded_passages
            instances[ident]=(inst,graph,D,paths,lengths,pre)
            summary['status']='PASS_INDEPENDENT_INPUT';checks.append(summary)
        except Exception as ex:
            fail={'instance_id':ident,'status':'INDEPENDENT_INPUT_FAILURE','error':repr(ex),'traceback':traceback.format_exc()}
            input_failures[ident]=fail;checks.append(fail)
        print(json.dumps({'phase':'INPUT_REVIEW','instance_id':ident,'status':checks[-1]['status']}),flush=True)
    records=load_lines('raw/results.jsonl');record_by={x['call_id']:x for x in records}
    assert len(record_by)==len(records) and set(record_by)<={x['call_id'] for x in schedule}
    attempts=load_lines('raw/attempts.jsonl');starts=[x for x in attempts if x['phase']=='STARTED']
    assert len(starts)<=72 and len({x['call_id'] for x in starts})==len(starts)
    assert [x['call_id'] for x in starts]==[x['call_id'] for x in schedule[:len(starts)]]
    assert {x['call_id'] for x in records}<={x['call_id'] for x in starts}
    rows=[];default_params=load('selftests/integration_r1/INVENTED_E.stdout')['model_parameters']['default_solve_params']
    for entry in schedule:
        out=dict(entry);ident=entry['instance_id'];rec=record_by.get(entry['call_id'])
        if ident in input_failures:
            out.update(status='INPUT_INVALID',error=input_failures[ident]['error']);rows.append(out);continue
        if rec is None:
            out['status']='NOT_STARTED_OR_NO_RESULT';rows.append(out);continue
        try:
            assert rec['child_reaped'] is True
            for k in ['call_id','instance_id','seed','arm','pair_index','max_runtime_seconds']:assert rec[k]==entry[k]
            if rec['status']!='UNREVIEWED_PROCESS_SUCCESS':
                out['status']=rec['status'];rows.append(out);continue
            assert rec['returncode']==0 and rec['process_spawned'] is True
            assert sha(R/rec['stdout'])==rec['stdout_sha256'] and sha(R/rec['stderr'])==rec['stderr_sha256']
            saved=json.loads((R/rec['stdout']).read_text());inst,graph,D,paths,lengths,pre=instances[ident]
            assert saved['solver']=='PyVRP' and saved['version']=='0.14.0' and saved['algorithm']=='ILS'
            assert saved['seed']==entry['seed'] and saved['max_runtime_seconds']==1.0
            assert saved['denied_io_events']==saved['reference_or_history_payload_fields']==[]
            assert saved['solver_is_feasible'] and saved['solver_is_complete']
            assert saved['reported_num_routes']==1 and len(saved['routes'])==1
            assert len(saved['native_routes'])==1
            matrix=pre['integer_matrices'][entry['arm']]
            assert saved['model_distance_matrix']==matrix
            assert saved['model_matrix_sha256']==hashlib.sha256(json.dumps(matrix,separators=(',',':')).encode()).hexdigest()
            params=saved['model_parameters'];assert params['K']==1 and params['capacity']==inst['n'] and params['demands']==[0]+[1]*inst['n']
            assert [[dec(v) for v in p] for p in params['coordinates']]==inst['coordinates']
            if default_params is None:default_params=params['default_solve_params']
            assert params['default_solve_params']==default_params
            native_model=saved['native_model_parameters'];vehicle=native_model['vehicle'];clients=native_model['clients'];depot=native_model['depot'];ub=2**63-1
            assert native_model['num_locations']==inst['n']+1 and native_model['num_clients']==inst['n']
            assert native_model['num_depots']==native_model['num_vehicles']==1 and native_model['num_shipments']==0 and native_model['duration_matrix_all_zero'] is True
            assert vehicle['capacity']==[inst['n']] and vehicle['num_available']==1 and vehicle['initial_load']==[0]
            assert vehicle['unit_distance_cost']==vehicle['max_trips']==1 and vehicle['reload_depots']==[]
            assert all(vehicle[k]==0 for k in ['start_depot','end_depot','fixed_cost','unit_duration_cost','unit_overtime_cost','max_reloads','max_overtime','tw_early','profile'])
            assert all(vehicle[k]==ub for k in ['max_distance','max_duration','shift_duration','start_late','tw_late'])
            assert len(clients)==inst['n']
            for i,c in enumerate(clients):
                assert c['location']==i+1 and c['delivery']==[1] and c['pickup']==[0] and c['required'] is True and c['group'] is None
                assert c['service_duration']==c['prize']==c['release_time']==c['tw_early']==0 and c['tw_late']==ub
            assert depot=={'location':0,'service_duration':0,'tw_early':0,'tw_late':ub}
            assert saved['resource_limits']['effective']['CPU_seconds']==[5,5] and saved['resource_limits']['effective']['AS_bytes']==[1073741824,1073741824]
            route=saved['routes'][0];native=saved['native_routes'][0]
            assert native['start_depot']==native['end_depot']==0 and native['vehicle_type']==0 and native['num_trips']==1 and native['is_feasible']
            check_native_activities(route,native['activities'],inst['n'])
            assert native['delivery']==[inst['n']]
            cost=sum(matrix[a][b] for a,b in zip(route,route[1:]))
            assert cost==saved['reported_cost']==saved['reported_distance']==saved['internal_route_cost']==native['distance']
            assert saved['reported_fixed_vehicle_cost']==saved['reported_duration_cost']==0
            audit=audit_route(route,inst,graph,D,paths,lengths,geometry)
            proxy=total(pre['unrounded_matrices'][entry['arm']][a][b] for a,b in zip(route,route[1:]))
            quant_residual=abs(Decimal(cost)/1000-proxy)
            assert quant_residual<=Decimal(inst['n']+1)*Decimal('0.0005')
            out.update(audit,status='PASS_INDEPENDENT_ROUTE',route=route,integer_proxy_cost=cost,
                       unrounded_proxy_cost_m=str(proxy),quantization_residual_m=str(quant_residual),num_iterations=saved['num_iterations'])
        except Exception as ex:
            out.update(status='INDEPENDENT_OUTPUT_FAILURE',error=repr(ex),traceback=traceback.format_exc())
        rows.append(out)
    pairs,condition_results,aggregate=summarize(rows,conditions)
    result={'status':'PASS_COMPLETE_INDEPENDENT_REVIEW' if all(x['status']=='PASS_INDEPENDENT_ROUTE' for x in rows) else 'COMPLETE_WITH_EXPLICIT_FAILURES',
            'started_utc':started,'finished_utc':utc(),'gate':gate,'input_reviews':checks,'rows':rows,'pairs':pairs,'conditions':condition_results,'aggregate':aggregate,
            'planned_calls':72,'recorded_results':len(records),'processes_spawned':sum(bool(x['process_spawned'])for x in records),'attempt_starts':len(starts),
            'unique_geometry_segments_recomputed':len(geometry.cache),'optimizer_called':False,'author_modules_imported':False,
            'wall_seconds':time.perf_counter()-clock,'cpu_seconds':time.process_time()-cpu,'frozen_identity_after':verify_frozen(),'old_files_after':verify_old()}
    save('independent_review/results/INDEPENDENT_SAVED_REVIEW.json',result)
    print(json.dumps({'status':result['status'],'aggregate':aggregate}),flush=True)
    return result
if __name__=='__main__':main()
