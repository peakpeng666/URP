"""Saved-result report only; requires RAW private readback, never optimizes."""
import json,sys,math,csv,collections,resource,time,signal
from decimal import Decimal,getcontext
from common import ROOT,now,read,save,sha,receipt,verify_frozen,verify_old
from author_geometry import rings_from_wkt,segment_check,distance80,interior
getcontext().prec=80

def validate(entry,answer,data,graph,rings,cache):
    n=data['n'];N=n+1;arm=entry['arm'];matrix=data['integer_matrices'][arm]
    assert answer['version']=='0.14.0' and answer['solver_is_feasible']and answer['solver_is_complete']
    assert answer['seed']==entry['seed']and answer['max_runtime_seconds']==1.0 and answer['model_distance_matrix']==matrix
    assert answer['reported_num_routes']==1 and answer['reported_duration_cost']==answer['reported_fixed_vehicle_cost']==0
    routes=answer['routes'];assert len(routes)==1;r=routes[0]
    assert len(r)==n+2 and r[0]==r[-1]==0 and collections.Counter(r[1:-1])==collections.Counter(range(1,N))
    integer=sum(matrix[a][b]for a,b in zip(r,r[1:]));assert integer==answer['reported_cost']==answer['reported_distance']==answer['internal_route_cost']
    nr=answer['native_routes'];assert len(nr)==1 and nr[0]['is_feasible']and nr[0]['num_trips']==1 and nr[0]['vehicle_type']==nr[0]['start_depot']==nr[0]['end_depot']==0
    assert [x['node']for x in nr[0]['activities']]==r
    for k,x in enumerate(nr[0]['activities']):
        assert x['location']==r[k]
        if k in(0,len(r)-1):assert x['type']=='DEPOT'and x['idx']==0
        else:assert x['type']=='CLIENT'and x['idx']==r[k]-1
    nodes=graph['nodes'];sn=graph['service_node_ids'];poly=[];legs=[];passages=[]
    for a,b in zip(r,r[1:]):
        p=data['canonical_paths'][a][b];assert p[0]==sn[a]and p[-1]==sn[b]and all(x<sn[0]for x in p[1:-1])
        legs.append({'service_leg':[a,b],'node_ids':p});poly.extend(p if not poly else p[1:])
    coords=[nodes[x]for x in poly];assert coords[0]==coords[-1]==data['coordinates'][0]
    actual=Decimal(0);segments=[]
    for ix,(a,b)in enumerate(zip(coords,coords[1:])):
        key=tuple(sorted((tuple(a),tuple(b))))
        if key not in cache:cache[key]=segment_check(a,b,rings)
        chk=cache[key];segments.append({'segment_index':ix,'a':a,'b':b,**chk});assert chk['exact_safe']
        actual+=distance80(a,b)
        for cid,p in enumerate(data['coordinates']):
            if interior(a,b,p):passages.append({'segment_index':ix,'service_id':cid,'kind':'INTERIOR_COORDINATE_PASSAGE_NOT_SERVICE'})
    saved=sum((Decimal(str(data['unrounded_matrices']['G'][a][b]))for a,b in zip(r,r[1:])),Decimal(0))
    proxy=sum((Decimal(str(data['unrounded_matrices'][arm][a][b]))for a,b in zip(r,r[1:])),Decimal(0))
    assert abs(actual-saved)<=Decimal(n+1)*Decimal('1e-8')
    assert abs(Decimal(integer)/1000-proxy)<=Decimal(n+1)*Decimal('.0005')
    signature=min(tuple(r),tuple(r[::-1]));minimum=min(Decimal(x['minimum_clearance_m_decimal80'])for x in segments)
    return {**entry,'status':'VALID_EXACT_SAFE_ROUTE','n':n,'route':r,'reversal_canonical_signature':list(signature),'integer_search_cost':integer,'unrounded_search_proxy_m_decimal80':str(proxy),'actual_length_m_decimal80':str(actual),'saved_graph_leg_sum_m_decimal80':str(saved),'actual_minus_saved_sum_m_decimal80':str(actual-saved),'quantization_error_m_decimal80':str(Decimal(integer)/1000-proxy),'quantization_bound_m':(n+1)*.0005,'minimum_clearance_m_decimal80':str(minimum),'all_segments_exact_safe':True,'conservative_labels':dict(collections.Counter(x['tolerance_label']for x in segments)),'service_events_each_once':True,'incidental_geometric_passages':passages,'interior_service_graph_nodes':0,'mapped_polyline_node_ids':poly,'mapped_polyline_coordinates':coords,'legs':legs,'segments':segments,'stats':{'iterations':answer['num_iterations'],'solver_loop_runtime':answer['solver_loop_runtime'],'solve_cpu':answer['solve_cpu_seconds_audit_only'],'solve_wall':answer['solve_wall_seconds_audit_only']}}

def aggregate(rows,conditions):
    by={(x['instance_id'],x['seed'],x['arm']):x for x in rows};pairs=[];per=[]
    for ident in conditions:
        delta=[];E=[];G=[]
        for seed in range(3):
            e,g=by[ident,seed,'E'],by[ident,seed,'G'];ok=e['status']==g['status']=='VALID_EXACT_SAFE_ROUTE'
            pair={'instance_id':ident,'seed':seed,'valid':ok,'E_status':e['status'],'G_status':g['status'],'delta_m_decimal80':None,'percent_of_G_decimal80':None}
            if ok:
                le,lg=Decimal(e['actual_length_m_decimal80']),Decimal(g['actual_length_m_decimal80']);d=le-lg;delta.append(d);E.append(le);G.append(lg)
                pair.update(delta_m_decimal80=str(d),percent_of_G_decimal80=str(100*d/lg),same_route_up_to_reversal=e['reversal_canonical_signature']==g['reversal_canonical_signature'])
            pairs.append(pair)
        item={'instance_id':ident,'n':int(ident.split('_n')[1].split('_')[0]),'stream_seed':int(ident.split('_s')[1]),'complete_three_seed_pairs':len(delta)==3,'valid_pairs':len(delta),'mean_delta_m_decimal80':None,'mean_E_m_decimal80':None,'mean_G_m_decimal80':None,'percent_of_mean_G_decimal80':None}
        if len(delta)==3:
            me,mg=sum(E)/3,sum(G)/3;item.update(mean_delta_m_decimal80=str(sum(delta)/3),mean_E_m_decimal80=str(me),mean_G_m_decimal80=str(mg),percent_of_mean_G_decimal80=str(100*(me-mg)/mg))
        per.append(item)
    complete=[x for x in per if x['complete_three_seed_pairs']]
    def mean(items,key):return str(sum(Decimal(x[key])for x in items)/len(items))if items else None
    primary={'complete_conditions':len(complete),'planned_conditions':12,'mean_condition_delta_m_decimal80':mean(per,'mean_delta_m_decimal80')if len(complete)==12 else None,'mean_condition_percent_decimal80':mean(per,'percent_of_mean_G_decimal80')if len(complete)==12 else None,'ratio_of_condition_means_percent_decimal80':None}
    if len(complete)==12:primary['ratio_of_condition_means_percent_decimal80']=str(100*(Decimal(mean(per,'mean_E_m_decimal80'))-Decimal(mean(per,'mean_G_m_decimal80')))/Decimal(mean(per,'mean_G_m_decimal80')))
    return {'pairs':pairs,'conditions':per,'primary':primary,'available_complete_conditions_descriptive_mean_delta_m':mean(complete,'mean_delta_m_decimal80'),'available_complete_conditions_denominator':len(complete),'per_arm':{arm:{'valid':sum(x['status']=='VALID_EXACT_SAFE_ROUTE'for x in rows if x['arm']==arm),'planned':36,'statuses':dict(collections.Counter(x['status']for x in rows if x['arm']==arm))}for arm in['E','G']},'by_n':{str(n):{'complete_conditions':len([x for x in complete if x['n']==n]),'mean_delta_m':mean([x for x in complete if x['n']==n],'mean_delta_m_decimal80'),'mean_condition_percent':mean([x for x in complete if x['n']==n],'percent_of_mean_G_decimal80')}for n in[8,20,40]},'pair_sign_counts':dict(collections.Counter('E_longer'if Decimal(p['delta_m_decimal80'])>Decimal('1e-8')else'G_longer'if Decimal(p['delta_m_decimal80'])<Decimal('-1e-8')else'numeric_tie_within1e-8m'for p in pairs if p['valid']))}

def main():
    resource.setrlimit(resource.RLIMIT_CPU,(180,180));resource.setrlimit(resource.RLIMIT_AS,(1073741824,1073741824));signal.alarm(300);start=time.monotonic();verify_frozen();verify_old();receipt('RAW_UNREVIEWED')
    schedule=read('freeze/SCHEDULE.json');results={}
    file=ROOT/'raw/results.jsonl'
    if file.exists():results={x['call_id']:x for x in map(json.loads,file.read_text().splitlines())}
    review_file=ROOT/'independent_review/results/INDEPENDENT_SAVED_REVIEW.json'
    review=json.loads(review_file.read_text())if review_file.exists()else{'status':'INDEPENDENT_REVIEW_NOT_AVAILABLE'}
    if review['status']!='PASS_COMPLETE_INDEPENDENT_REVIEW':
        retained=[{**e,'observed_process_record':results.get(e['call_id']),'independent_status':next((x['status']for x in review.get('rows',[])if x['call_id']==e['call_id']),None)}for e in schedule]
        save(ROOT/'reports/SUMMARY.json',{'status':'UNVERIFIED_NO_VALID_PRIMARY_CONCLUSION','independent_status':review['status'],'planned_calls':72,'recorded_calls':len(results),'spawned_calls':sum(bool(x['process_spawned'])for x in results.values()),'primary':None,'all_scheduled_slots_and_call_evidence':retained})
        (ROOT/'reports/REPORT_ZH.txt').write_text('EE130距离代理实验：独立审计未全部通过，主结论未验证。\n全部72个计划槽位和已发生调用均保留。没有重复优化或删去失败；请见SUMMARY.json与RAW/独审证据。\n')
        print('UNVERIFIED_NO_VALID_PRIMARY_CONCLUSION');return
    rings=rings_from_wkt((ROOT/'input/projected_epsg32634.wkt').read_text());cache={};rows=[]
    for entry in schedule:
        cid=entry['call_id'];rec=results.get(cid);row={**entry,'status':'NOT_STARTED','error':None}
        if rec:
            row['status']=rec['status']
            if rec['status']=='UNREVIEWED_PROCESS_SUCCESS':
                try:row=validate(entry,json.loads((ROOT/rec['stdout']).read_text()),read(f"raw/preprocess/{entry['instance_id']}.json"),read(f"input/{entry['instance_id']}_graph.json"),rings,cache)
                except Exception as exc:row.update(status='INVALID_SAVED_RESULT',error=repr(exc))
            row['process_resources']={k:rec[k]for k in ['cpu_seconds_audit_only','wall_seconds_audit_only','returncode','child_reaped']}
        rows.append(row)
    summary=aggregate(rows,read('freeze/PROTOCOL.json')['conditions']);summary.update(created_utc=now(),status='AUTHOR_REPORT_PENDING_INDEPENDENT_NARRATIVE_REVIEW',all72_retained=len(rows)==72,wall_seconds=time.monotonic()-start,unique_segment_checks=len(cache),old_files_unchanged=verify_old())
    save(ROOT/'reports/SAVED_ROUTE_AUDIT.json',{'rows':rows});save(ROOT/'reports/SUMMARY.json',summary)
    fields=['call_id','instance_id','seed','arm','status','actual_length_m_decimal80','integer_search_cost','minimum_clearance_m_decimal80','quantization_error_m_decimal80']
    with(ROOT/'reports/PER_SEED.csv').open('x')as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(rows)
    with(ROOT/'reports/PAIRED_CONDITIONS.csv').open('x')as f:
        w=csv.DictWriter(f,fieldnames=list(summary['conditions'][0]));w.writeheader();w.writerows(summary['conditions'])
    lines=['EE130：直线距离与障碍可行图距离选择访问顺序','',f"全部72个计划调用保留；E/G有效几何路线分别{summary['per_arm']['E']['valid']}/36、{summary['per_arm']['G']['valid']}/36。",f"12条件等权平均配对实际路长差 L_E−L_G：{summary['primary']['mean_condition_delta_m_decimal80']} 米。",f"条件百分比等权平均：{summary['primary']['mean_condition_percent_decimal80']}%；这是不同条件归一化后的平均。",f"全条件均值之比：{summary['primary']['ratio_of_condition_means_percent_decimal80']}%，与上一百分比定义不同。",f"36配对符号分布（1e-8m内列数值并列）：{summary['pair_sign_counts']}。",'', '同一冻结C组12条件，两种访问顺序均按完全相同冻结可行图路径实现。单车、每客户一次服务事件、单位需求和capacity=n仅为TSP编码，没有实测车队或载重参数。', '两臂均使用PyVRP0.14.0默认ILS，种子0/1/2，每调用fresh进程，MaxRuntime(1.0)只限制主循环，不等于端到端1秒；原顺序相邻交替。', '搜索矩阵每米1000、half-up，单leg量化界0.5毫米；实际结论按未取整全折线路长独立重算，不将整数代理差当作真实几何收益。', '必访一次指服务事件；折线偶然经过其他服务点另列，不自动增减服务。每段按序列化原边界及三孔做完整精确净空>=1.10m验证，保守数值边界标签另列。', '四流共享同一地块；n8/20/40为嵌套前缀，12条件并非12独立地块或实测布局。不作显著性、普遍优越性或最优gap声明。', 'G的最短路仅是冻结有限可见图中其他service顶点仅作终点、不扩展中转这一既定编码规则及数值精度下的距离，不是无限制全图或连续平面全局最优。实际成本差同时受距离代理和本次有限预算启发式求解实现影响，不能推定G每次必然更好。', '1.10m保守圆盘中心区只是几何代理，无车体朝向、转弯半径、控制/定位/地形/测绘误差约束，不能称真实农业车辆可执行。', '全部失败/未启动保留；缺任一seed时该条件主值不可用，缺任一条件时全12主聚合为空。没有reference，无warm start、结果选seed、重复正式调用、新安装、模型调用、付费或凭据读取。', '本报告仍须最终独立叙述审查与私有归档回读。']
    (ROOT/'reports/REPORT_ZH.txt').write_text('\n'.join(lines)+'\n')
    print(json.dumps({'status':summary['status'],'primary':summary['primary'],'per_arm':summary['per_arm']}))
if __name__=='__main__':main()
