"""No real data: confirm paired denominators, negative deltas and NULL policy."""
from common import ROOT,save,now,sha
from report import aggregate

def main():
    ids=[f'C_n{n:02d}_s{s}'for n in[8,20,40]for s in[101,102,103,104]]
    rows=[{'instance_id':i,'seed':s,'arm':a,'status':'VALID_EXACT_SAFE_ROUTE','actual_length_m_decimal80':'10'if a=='E'else'11','reversal_canonical_signature':[0,1,2,0]}for i in ids for s in range(3)for a in['E','G']]
    summary=aggregate(rows,ids);assert summary['primary']['mean_condition_delta_m_decimal80']=='-1'and summary['primary']['complete_conditions']==12
    assert summary['pair_sign_counts']=={'G_longer':36}and all(summary['per_arm'][a]['valid']==36 for a in['E','G'])
    rows[0]['status']='WALL_TIMEOUT';summary=aggregate(rows,ids)
    assert summary['primary']['mean_condition_delta_m_decimal80']is None and summary['primary']['mean_condition_percent_decimal80']is None and summary['primary']['complete_conditions']==11
    assert summary['per_arm']['E']['planned']==36 and summary['per_arm']['E']['valid']==35 and summary['available_complete_conditions_denominator']==11
    assert len(summary['pairs'])==36 and len(summary['conditions'])==12
    save(ROOT/'selftests/REPORT_SYNTHETIC.json',{'utc':now(),'status':'PASS','actual_numeric_data_used':False,'checks':['Negative delta retained','36planned per arm','All36pairs/all12conditions retained','One seed missing invalidates condition three-seed primary','Any condition missing makes all12primary NULL','available-complete denominator explicit'],'source_sha256':{'report.py':sha(ROOT/'source/report.py'),'test_report_synthetic.py':sha(ROOT/'source/test_report_synthetic.py')}})
    print('PASS synthetic paired report semantics')
if __name__=='__main__':main()
