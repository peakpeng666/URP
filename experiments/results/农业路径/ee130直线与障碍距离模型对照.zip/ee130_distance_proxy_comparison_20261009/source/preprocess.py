"""Gated numerical preprocessing only. Never selects a service visit order."""
import sys,json,math,time,resource,traceback
from decimal import Decimal,ROUND_HALF_UP,localcontext
from common import ROOT,now,read,save,sha,verify_frozen,verify_old,receipt
from author_geometry import rings_from_wkt,segment_check,distance80,interior
TOL=1e-8

def quantize(d):
    x=Decimal(str(d));assert x.is_finite() and x>=0
    value=int((x*1000).to_integral_value(rounding=ROUND_HALF_UP))
    assert abs(Decimal(value)/1000-x)<=Decimal('0.0005')
    return value

def derive(inst,g,base,rings,cache):
    coords=inst['coordinates'];n=inst['n'];N=n+1;b=len(base['nodes']);nodes=g['nodes'];sn=g['service_node_ids']
    assert len(coords)==N and nodes[:b]==base['nodes'] and nodes[b:]==coords and sn==list(range(b,b+N))
    assert not g['unreachable_service_pairs'] and len(nodes)==g['graph_nodes']
    original=g['distance_matrix'];oldpaths=g['paths'];assert len(original)==len(oldpaths)==N
    edges={}
    for u,v,w in base['edges']+g['added_visibility_edges']:
        assert type(u)is int and type(v)is int and 0<=u<v<len(nodes) and (u,v)not in edges and math.isfinite(w) and w>0
        assert abs(math.hypot(nodes[u][0]-nodes[v][0],nodes[u][1]-nodes[v][1])-w)<=TOL
        edges[u,v]=w
    assert len(edges)==g['graph_edges']
    D=[[0.0]*N for _ in coords];E=[[0.0]*N for _ in coords];paths=[[None]*N for _ in coords];pair_checks=[];checks={};passages=[]
    for i in range(N):
        assert len(original[i])==len(oldpaths[i])==N and original[i][i]==0 and oldpaths[i][i]==[sn[i]]
        paths[i][i]=[sn[i]]
        for j in range(i+1,N):
            dij,dji=original[i][j],original[j][i];assert math.isfinite(dij) and dij>0 and abs(dij-dji)<=TOL
            lengths=[]
            for a,c in [(i,j),(j,i)]:
                p=oldpaths[a][c];assert p[0]==sn[a] and p[-1]==sn[c] and all(0<=v<b for v in p[1:-1])
                assert len(set(p))==len(p)
                for u,v in zip(p,p[1:]):assert tuple(sorted((u,v)))in edges
                length=math.fsum(math.hypot(nodes[u][0]-nodes[v][0],nodes[u][1]-nodes[v][1]) for u,v in zip(p,p[1:]));assert abs(length-original[a][c])<=TOL
                lengths.append(length)
            assert abs(lengths[0]-lengths[1])<=TOL
            p=oldpaths[i][j];D[i][j]=D[j][i]=dij;paths[i][j]=p;paths[j][i]=p[::-1]
            E[i][j]=E[j][i]=math.hypot(coords[i][0]-coords[j][0],coords[i][1]-coords[j][1])
            with localcontext()as ctx:
                ctx.prec=80;precise=sum((distance80(nodes[u],nodes[v]) for u,v in zip(p,p[1:])),Decimal(0));residual=precise-Decimal(str(dij))
            assert abs(residual)<=Decimal('1e-8')
            pair_checks.append({'pair':[i,j],'original_forward':dij,'original_backward':dji,'original_value_asymmetry_m':dij-dji,'reverse_path_identity':oldpaths[j][i]==p[::-1],'original_direction_lengths_m':lengths,'canonical_path_decimal80_m':str(precise),'continuous_minus_saved_distance_m_decimal80':str(residual)})
            for ix,(u,v)in enumerate(zip(p,p[1:])):
                key=tuple(sorted((tuple(nodes[u]),tuple(nodes[v]))))
                if key not in cache:cache[key]=segment_check(nodes[u],nodes[v],rings)
                value=cache[key];checks[f'{min(u,v)}_{max(u,v)}']={'node_ids':sorted([u,v]),**value};assert value['exact_safe']
                for k,point in enumerate(coords):
                    if k not in (i,j)and interior(nodes[u],nodes[v],point):passages.append({'service_leg':[i,j],'path_segment_index':ix,'other_service_id':k,'event':'INTERIOR_GEOMETRIC_PASSAGE_NOT_SERVICE'})
    endpoints=[{'service_id':i,**segment_check(p,p,rings)} for i,p in enumerate(coords)];assert all(v['exact_safe']for v in endpoints)
    ints={arm:[[quantize(v)for v in row]for row in mat]for arm,mat in [('E',E),('G',D)]}
    return {'instance_id':inst['instance_id'],'status':'PASS_PREPROCESS','n':n,'coordinates':coords,'demands':[0]+[1]*n,'capacity':n,'K':1,'unrounded_matrices':{'E':E,'G':D},'integer_matrices':ints,'canonical_paths':paths,'canonical_rule':'Original i<j path and D; reverse reuse; originals unchanged in frozen input','pair_checks':pair_checks,'endpoint_checks':endpoints,'unique_path_segments':list(checks.values()),'geometric_passages':passages,'interior_service_graph_nodes':0,'length_quantization_bound_m':(n+1)*0.0005,'data_independence':'One field, four streams, nested sizes; not12 independent layouts.'}

def main():
    resource.setrlimit(resource.RLIMIT_CPU,(180,180));resource.setrlimit(resource.RLIMIT_AS,(1073741824,1073741824))
    assert (ROOT/'raw/EXECUTOR_STARTED.json').exists();verify_frozen();verify_old();receipt('PREEXEC')
    started=time.monotonic();cpu=time.process_time();dest=ROOT/'raw/preprocess';dest.mkdir(exist_ok=False)
    base=read('input/shared_preprocessing.json');rings=rings_from_wkt((ROOT/'input/projected_epsg32634.wkt').read_text());assert len(rings)==4
    cache={};items=[];failure=None
    for ident in read('freeze/PROTOCOL.json')['conditions']:
        try:
            data=derive(read(f'input/{ident}_input.json'),read(f'input/{ident}_graph.json'),base,rings,cache)
            save(dest/f'{ident}.json',data);items.append({'instance_id':ident,'status':'PASS_PREPROCESS','path':f'raw/preprocess/{ident}.json','sha256':sha(dest/f'{ident}.json')})
        except Exception as exc:
            failure={'instance_id':ident,'status':'INPUT_NUMERIC_OR_GEOMETRY_FAILURE','error':repr(exc),'traceback':traceback.format_exc()};items.append(failure);break
    save(ROOT/'raw/PREPROCESS_FINISHED.json',{'utc':now(),'status':'PASS'if failure is None else'FAIL','items':items,'failure':failure,'unique_segment_cache_size':len(cache),'wall_seconds':time.monotonic()-started,'cpu_seconds':time.process_time()-cpu,'maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'resource_limits':{'cpu':list(resource.getrlimit(resource.RLIMIT_CPU)),'as':list(resource.getrlimit(resource.RLIMIT_AS))}})
    if failure:raise RuntimeError('Input preflight failed; no optimizer may run')
if __name__=='__main__':main()
