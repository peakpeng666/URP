"""Invented-only preprocess/quantization/geometry fixtures."""
import copy,math,json,resource,sys
from common import ROOT,save,now,sha
from preprocess import derive,quantize
from author_geometry import rings_from_wkt,segment_check,interior

def main():
    resource.setrlimit(resource.RLIMIT_CPU,(180,180));resource.setrlimit(resource.RLIMIT_AS,(1073741824,1073741824))
    checks=[]
    for x,q in [('0',0),('1.000499999',1000),('1.0005',1001),('1.000500001',1001),('0.0005',1)]:assert quantize(x)==q;checks.append('quantize_'+x)
    rings=rings_from_wkt('POLYGON ((0 0,30 0,30 30,0 30,0 0),(13 13,17 13,17 17,13 17,13 13))')
    assert not segment_check([5,15],[25,15],rings)['exact_safe'];assert segment_check([5,5],[25,5],rings)['exact_safe'];checks+=['whole_segment_hole_crossing','safe_whole_segment']
    edge=segment_check([2,1.1],[8,1.1],rings);assert edge['exact_safe']and edge['tolerance_label']=='UNCERTAIN_BOUNDARY';checks+=['exact_safety_separate_tolerance']
    assert interior([2,2],[8,2],[5,2])and not interior([2,2],[8,2],[2,2]);checks+=['incidental_passage_not_endpoint']
    coords=[[2,2],[8,2],[8,8]];nodes=[[2,8]]+coords
    edges=[[a,b,math.dist(nodes[a],nodes[b])]for a in range(4)for b in range(a+1,4)]
    D=[[math.dist(a,b)for b in coords]for a in coords];paths=[[[i+1]if i==j else[i+1,j+1]for j in range(3)]for i in range(3)]
    inst={'instance_id':'INVENTED','n':2,'coordinates':coords};base={'nodes':nodes[:1],'edges':[]}
    g={'nodes':nodes,'service_node_ids':[1,2,3],'unreachable_service_pairs':[],'distance_matrix':D,'paths':paths,'added_visibility_edges':edges,'graph_nodes':4,'graph_edges':6}
    good=derive(inst,g,base,rings,{})
    assert good['status']=='PASS_PREPROCESS'and good['K']==1 and good['capacity']==2;checks+=['full_preprocess_fixture']
    for label,mutate in [('asymmetry_rejection',lambda z:z['distance_matrix'][1].__setitem__(0,D[1][0]+1e-6)),('service_transit_rejection',lambda z:z['paths'][0].__setitem__(2,[1,2,3])),('disconnected_rejection',lambda z:z.__setitem__('unreachable_service_pairs',[[0,1]])),('missing_edge_rejection',lambda z:z['added_visibility_edges'].pop())]:
        bad=copy.deepcopy(g);mutate(bad)
        try:derive(inst,bad,base,rings,{})
        except AssertionError:checks.append(label)
        else:raise AssertionError(label)
    save(ROOT/'selftests/PREPROCESS_SYNTHETIC.json',{'utc':now(),'status':'PASS','synthetic_only':True,'checks':checks,'actual_field_numeric_calculations':0,'resource_limits':{'CPU':list(resource.getrlimit(resource.RLIMIT_CPU)),'AS':list(resource.getrlimit(resource.RLIMIT_AS))},'source_sha256':{f:sha(ROOT/'source'/f)for f in ['preprocess.py','author_geometry.py','test_synthetic.py']}})
    print('PASS invented preprocessing fixtures')
if __name__=='__main__':main()
