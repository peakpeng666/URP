"""Exclusive two-stage outer executor; process groups reaped before RAW seal."""
import subprocess,sys,os,signal,time,json
from common import ROOT,now,sha,read,save,verify_frozen,verify_old,receipt
from run_once import child_environment
from package import package

def stop_process_group(p):
    if p is not None:
        try:os.killpg(p.pid,signal.SIGKILL)
        except ProcessLookupError:pass
        p.wait()
def stage(name,script,timeout):
    p=None;timed_out=False;error=None;start=time.monotonic()
    try:
        with(ROOT/'raw'/f'{name}.stdout').open('xb')as fo,(ROOT/'raw'/f'{name}.stderr').open('xb')as fe:
            p=subprocess.Popen([sys.executable,'-B',str(ROOT/'source'/script)],stdout=fo,stderr=fe,env=child_environment(),cwd=ROOT/'raw',start_new_session=True)
            try:p.wait(timeout=timeout)
            except subprocess.TimeoutExpired:timed_out=True
    except Exception as exc:error=repr(exc)
    finally:stop_process_group(p)
    return {'name':name,'returncode':p.returncode if p else None,'timeout':timed_out,'error':error,'wall_seconds':time.monotonic()-start,'group_cleanup_completed':True}
def main():
    if not __debug__:raise RuntimeError('Assertions must be enabled')
    freeze=verify_frozen();verify_old();r=receipt('PREEXEC')
    approval=read('provenance/PARENT_EXECUTION_APPROVAL.json')
    assert approval['approved']and approval['frozen_files_sha256']==freeze and approval['preexec_archive_sha256']==r['sha256']
    assert approval['scope']=='one frozen EE130 preprocessing and72 calls; no retry'
    assert read('freeze/INDEPENDENT_PRECHECK.json')['status']=='PASS'
    save(ROOT/'raw/EXECUTOR_STARTED.json',{'utc':now(),'no_retries':True,'preexec_sha256':r['sha256'],'frozen_files_sha256':freeze,'pid':os.getpid(),'approval_sha256':sha(ROOT/'provenance/PARENT_EXECUTION_APPROVAL.json')})
    rows=[stage('preprocess','preprocess.py',300)]
    if rows[0]['returncode']==0 and read('raw/PREPROCESS_FINISHED.json')['status']=='PASS':rows.append(stage('supervisor','run_once.py',900))
    else:save(ROOT/'raw/OPTIMIZATION_NOT_STARTED.json',{'utc':now(),'reason':'PREPROCESS_FAILURE_ALL72_SLOTS_RETAINED_UNAVAILABLE','schedule':read('freeze/SCHEDULE.json')})
    save(ROOT/'raw/EXECUTOR_FINISHED.json',{'utc':now(),'stages':rows,'status':'RAW_UNREVIEWED','wall_seconds':sum(x['wall_seconds']for x in rows),'no_reruns':True})
    print(json.dumps(package('RAW_UNREVIEWED')))
if __name__=='__main__':main()
