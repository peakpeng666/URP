"""Synthetic-only integration through identical limited supervisor and worker."""
import sys,json,resource,signal
from common import ROOT,now,read,save,sha
from run_once import execute_call

def run_in_limited_supervisor(limits):
    assert limits=={'AS_bytes':[536870912,1073741824],'CPU_seconds':[20,20]}
    signal.alarm(80);dest=ROOT/'selftests/integration_r1';dest.mkdir(exist_ok=False)
    python=read('environment/RUNTIME.json')['python_executable'];records=[]
    coords=[[0,0],[1,0],[2,0],[1,1]]
    for arm,matrix in [('E',[[0,1000,2000,1414],[1000,0,1000,1000],[2000,1000,0,1414],[1414,1000,1414,0]]),('G',[[0,3000,2000,1414],[3000,0,3000,2000],[2000,3000,0,1414],[1414,2000,1414,0]])]:
        entry={'call_id':'INVENTED_'+arm,'seed':0,'max_runtime_seconds':1.0,'arm':arm}
        payload={'coordinates':coords,'demands':[0,1,1,1],'capacity':3,'K':1,'seed':0,'max_runtime_seconds':1.0,'distance_matrix':matrix}
        item=execute_call(entry,payload,python,dest);assert item['status']=='UNREVIEWED_PROCESS_SUCCESS'and item['child_reaped'],item
        answer=json.loads((ROOT/item['stdout']).read_text());routes=answer['routes'];assert len(routes)==1 and sorted(routes[0][1:-1])==[1,2,3]and routes[0][0]==routes[0][-1]==0
        assert answer['model_distance_matrix']==matrix and answer['reported_cost']==sum(matrix[a][b]for a,b in zip(routes[0],routes[0][1:]))
        assert answer['resource_limits']=={'inherited':limits,'effective':{'AS_bytes':[1073741824,1073741824],'CPU_seconds':[5,5]}}
        records.append(item)
    for kind,expected in [('wall_timeout','WALL_TIMEOUT'),('cpu_limit','PROCESS_FAILURE_OR_CPU_LIMIT')]:
        entry={'call_id':'FAULT_'+kind,'seed':0,'max_runtime_seconds':1.0}
        item=execute_call(entry,{'synthetic_fault':kind},python,dest,ROOT/'source/synthetic_fault_worker.py');assert item['status']==expected and item['returncode']<0 and item['child_reaped'];records.append(item)
    entry={'call_id':'FAULT_bad_matrix','seed':0,'max_runtime_seconds':1.0}
    payload['distance_matrix']=[[0]]
    item=execute_call(entry,payload,python,dest);assert item['returncode']==1 and item['child_reaped'];records.append(item)
    again=execute_call(entry,payload,python,dest);assert not again['process_spawned']and again['status']=='CALL_ERROR_UNDETERMINED';records.append(again)
    signal.alarm(0)
    save(ROOT/'selftests/SUPERVISOR_INTEGRATION.json',{'utc':now(),'status':'PASS','synthetic_only':True,'public_or_EE130_optimizer_calls':0,'synthetic_optimizer_calls':2,'formal_runtime1s_used':True,'records':records,'source_sha256':{p:sha(ROOT/'source'/p)for p in ['worker.py','run_once.py','synthetic_integration.py','synthetic_fault_worker.py']}})
    print('PASS same production supervisor/worker:2 invented full1s calls,CPU/wall/malformed faults,exclusive guard')
