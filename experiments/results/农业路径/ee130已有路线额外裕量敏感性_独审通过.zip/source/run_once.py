#!/usr/bin/python3
import datetime,hashlib,json,os,pathlib,resource,subprocess,sys,time,traceback
R=pathlib.Path(__file__).resolve().parents[1]
def save(n,d):
 with (R/n).open('x') as f:json.dump(d,f,indent=2);f.write('\n')
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
freeze=json.loads((R/'freeze/PREEXECUTION_FREEZE.json').read_text())
for n,s in freeze['files'].items():assert h(R/n)==s,n
receipt=json.loads((R/'evidence/PREEXECUTION_DRIVE_RECEIPT.json').read_text())
assert receipt.get('verified') is True and receipt.get('download_byte_identical') is True
assert receipt.get('permissions')=='owner_only' and receipt.get('shared') is False
zipfile=R.parent/(R.name+'_PREEXECUTION_SNAPSHOT.zip')
assert receipt['sha256']==receipt['download_sha256']==h(zipfile)
assert int(receipt['bytes'])==zipfile.stat().st_size
save('evidence/STARTED.json',{'started_utc':utc(),'attempt':1,'runner_pid':os.getpid(),'cpu_limit_s':120,'wall_limit_s':180,'memory_limit_bytes':536870912,'preexec_zip_sha256':h(zipfile),'receipt_sha256':h(R/'evidence/PREEXECUTION_DRIVE_RECEIPT.json')})
assert not list((R/'raw').iterdir())
def limits():
 resource.setrlimit(resource.RLIMIT_CPU,(120,120));resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912));os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
t=time.perf_counter();status='TECHNICAL_FAILURE';rc=None
try:
 with (R/'evidence/STDOUT.log').open('x') as out,(R/'evidence/STDERR.log').open('x') as err:
  p=subprocess.run(['/usr/bin/python3',str(R/'source/audit_margin.py'),'--formal'],stdout=out,stderr=err,timeout=180,preexec_fn=limits,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1'})
 rc=p.returncode;status='COMPLETE_UNAUDITED' if rc==0 and (R/'raw/results.json').exists() else 'TECHNICAL_FAILURE'
except subprocess.TimeoutExpired:status='RESOURCE_TIMEOUT'
except Exception as e:save('evidence/EXCEPTION.json',{'error':str(e),'traceback':traceback.format_exc()})
r=resource.getrusage(resource.RUSAGE_CHILDREN)
save('evidence/RUN_STATUS.json',{'status':status,'exit_code':rc,'one_formal_execution':True,'finished_utc':utc(),'wall_seconds':time.perf_counter()-t,'children_cpu_seconds':r.ru_utime+r.ru_stime,'children_peak_rss_kib':r.ru_maxrss})
print(status)
raise SystemExit(0 if status=='COMPLETE_UNAUDITED' else 1)
