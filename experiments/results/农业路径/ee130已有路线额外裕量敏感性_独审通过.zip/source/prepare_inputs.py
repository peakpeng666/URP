import pathlib,hashlib,json,shutil,datetime
R=pathlib.Path(__file__).resolve().parents[1]
A=pathlib.Path('/workspace/shared/ee130_clearance_aware_routing_20261008')
B=pathlib.Path('/workspace/shared/ee130_route_clearance_audit_20261008')
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
ident=[]
def cp(p,d):
 out=R/'input'/d;assert not out.exists();shutil.copyfile(p,out);ident.append({'source_path':str(p),'copied_path':str(out.relative_to(R)),'bytes':out.stat().st_size,'sha256':h(out)});assert h(p)==h(out)
for p in sorted((A/'input').glob('n*_input.json')):cp(p,pathlib.Path('tasks')/p.name)
for p in sorted((A/'raw').glob('*_solver_output.json')):cp(p,pathlib.Path('routes')/p.name)
for n in ['projected_epsg32634.wkt','crs_provenance.json']:cp(A/'input'/n,n)
for p,d in [(A/'raw/results.json','prior/clearance_aware_results.json'),(A/'freeze/PROTOCOL.json','prior/clearance_aware_PROTOCOL.json'),(A/'independent_review/INDEPENDENT_ROUTES_EXACT.json','prior/clearance_aware_exact_routes.json'),(A/'independent_review/INDEPENDENT_REVIEW_REPORT.md','prior/clearance_aware_independent_report.md'),(B/'raw/results.json','prior/original_clearance_results.json'),(B/'freeze/PROTOCOL.json','prior/original_clearance_PROTOCOL.json')]:cp(p,d)
(R/'freeze/INPUT_IDENTITY.json').write_text(json.dumps(ident,indent=2)+'\n')
old={str(p):h(p) for root in [A,B] for p in sorted(root.rglob('*')) if p.is_file()}
(R/'freeze/UPSTREAM_IMMUTABILITY.json').write_text(json.dumps(old,indent=2)+'\n')
print({'copied_files':len(ident),'upstream_files':len(old),'tasks':len(list((R/'input/tasks').glob('*.json'))),'routes':len(list((R/'input/routes').glob('*.json')))})
