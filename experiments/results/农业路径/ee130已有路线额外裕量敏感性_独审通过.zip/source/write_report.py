#!/usr/bin/python3
"""Post-RAW-archive reporting only; reads saved outputs, no geometry or solver calls."""
import json,pathlib,hashlib,datetime
R=pathlib.Path(__file__).resolve().parents[1]
def read(p):return json.loads(pathlib.Path(p).read_text())
def save(p,x):
 with (R/p).open('x') as f:json.dump(x,f,ensure_ascii=False,indent=2);f.write('\n')
raw=read(R/'raw/results.json');receipt=read(R/'evidence/RAW_DRIVE_RECEIPT.json');assert receipt['verified'] and receipt['download_byte_identical']
review=read('/workspace/shared/ee130_route_margin_independent_20261008/results/INDEPENDENT_SAVED_RECOMPUTATION.json');assert review['status']=='PASS_INDEPENDENT_SAVED_RESULT_RECOMPUTATION'
assert raw['summary']==review['summary']
tasks=[read(p) for p in sorted((R/'raw').glob('*_endpoints.json'))];routes=[read(p) for p in sorted((R/'raw').glob('*_margins.json'))];assert len(tasks)==12 and len(routes)==8
run=read(R/'evidence/RUN_STATUS.json');pre=read(R/'evidence/PREEXECUTION_DRIVE_RECEIPT.json')
def interval(x):return '['+x['lower_m']+', '+x['upper_m']+']'
def short(i):return i[:3]+' / '+i[-4:]
def method(m):return 'NN' if m=='nearest_neighbor' else '2-opt'
def ids(a):return ', '.join(map(str,a)) if a else '无'
lines=['# ee130 已有路线额外几何裕量敏感性审计','',
'日期：2026-10-08。固定半径 1 米圆盘，额外裕量为 0、0.01、0.05、0.10、0.25、0.50 米。沿用原地块、全部 12 个任务实例和原有 8 条完整路线，没有移动任务、删除失败实例或重新求解。','',
'## 主要结果','',
'额外加入 1 厘米几何裕量后，原有 8 条路线仅 3 条通过，5 条不满足净空。额外 5 厘米和 10 厘米时仍为 3/8；25 厘米和 50 厘米时为 2/8。最紧两条固定路线的额外几何裕量极限位于 [0.002651194998, 0.002651194999] 米，即约 2.65 毫米。','',
'任务层面另有不同结论：12 个原实例中，8 个在额外裕量为零时就有服务点不足 1 米净空；额外 50 厘米时增至 9 个。端点不足使固定任务在该圆盘模型下不可行；已有路线净空不足，只能否定这条路线，不能据此否定替代路径。','',
'这是保存坐标上的后验几何敏感性审计，不是车辆验证。没有给定或估计实际定位、测量或控制误差，也没有把这些档位解释为硬件误差分布、可靠性概率或部署安全保证。','',
'## 六档完整结果','',
'表中“端点满足”包括全部服务点和 depot，仅代表路径存在的必要条件。两列分母分别为 12 个任务实例和 8 条保存路线。','',
'| 额外裕量 米 | 端点满足 / 12 | 端点使任务不可行 / 12 | 保存路线通过 / 8 | 保存路线不通过 / 8 | 端点满足但保存路线不足的条数 |',
'|---:|---:|---:|---:|---:|---:|']
for s in raw['summary']:
 t=s['task_status_counts'];rr=s['saved_route_status_counts'];c=s['instance_method_combined_status_counts'];lines.append(f"| {s['extra_margin_m']} | {t.get('ENDPOINTS_CLEAR',0)} | {t.get('TASK_ENDPOINT_INFEASIBLE',0)} | {rr.get('PASS',0)} | {rr.get('FAIL',0)} | {c.get('EXISTING_ROUTE_MARGIN_INSUFFICIENT',0)} |")
lines += ['', '六档均没有阈值不确定项。额外 50 厘米时，n20 / 1001 的服务点 15 使任务新增不可行；该点距原边界约 1.381114 米。原有 8 个不可行实例完整保留。原先没有生成路线的 16 个“实例 × 方法”组合仍标为无保存路线，没有补生成或作为零失败样本混入路线分母。', '',
'## 全部 12 个任务的端点上界','',
'种子后缀 1001、1002、1003 分别对应 202610081001、202610081002、202610081003；0 是 depot。下表是最小端点净空减去 1 米的精确包围区间，单位为米。它只是任务额外裕量的必要上界，不是任务全局可行性的精确极限。负数表示连额外零裕量都不可行。','',
'| 实例 | 最紧服务点 ID | 端点必要上界区间 米 | 零额外裕量不通过服务点 | 50厘米不通过服务点 |',
'|---|---:|---|---|---|']
for t in tasks:lines.append(f"| {short(t['instance_id'])} | {ids(t['endpoint_minimum_service_ids'])} | {interval(t['endpoint_necessary_signed_margin_upper_bound'])} | {ids(t['conditions'][0]['failing_service_ids'])} | {ids(t['conditions'][-1]['failing_service_ids'])} |")
lines += ['', '所有 depot 在六档中均通过。全 72 个任务条件、每个失败/不确定服务点 ID 和逐点证据，分别保存在 all_72_task_conditions.json 及 raw/*_endpoints.json。', '',
'## 全部 8 条固定路线的几何极限','',
'下表是这些保存折线在闭圆盘模型下的最大额外几何裕量区间。全部区间宽度至多 10⁻¹² 米，用整数平方根和有理不等式包围，不依赖小数四舍五入跨阈值。如此精细的数学区间不表示测绘具有相应精度。边界环 0 为外环，1 至 3 为孔洞；边和线段索引均从 0 开始。','',
'| 实例 | 方法 | 固定路线最大额外裕量区间 米 | 瓶颈线段 | 原边界环 / 边 | 六档保守状态 |',
'|---|---|---|---|---|---|']
for r in routes:
 w=r['fixed_route_minimum']['witness'];states='/'.join('通过' if c['conservative_status']=='PASS' else '失败' if c['conservative_status']=='FAIL' else '临界' for c in r['conditions'])
 lines.append(f"| {short(r['instance_id'])} | {method(r['method'])} | {interval(r['fixed_route_exact_maximum_additional_margin_interval'])} | {ids(r['bottleneck_segment_indices'])} | {w['ring_index']} / {w['edge_index']} | {states} |")
lines += ['', '六档顺序为 0、0.01、0.05、0.10、0.25、0.50 米。几何上的闭圆盘极限允许相切；若要求本实验的保守 PASS，则额外裕量必须严格小于该极限再减去 10⁻⁸ 米。表中的极限也不是实际车辆的误差承受能力。', '',
'## 几何和数值口径','',
'- 主算把原 WKT 与保存 JSON 的十进制文本直接转换为精确有理数。计算全部原外环与三个孔洞的 141 条边，不对中心线抽样；使用整段相交和端点到线段投影求最小距离平方。精确包含谓词用所有相交参数分段后检查开区间内部及端点。',
'- 闭圆盘数学可行条件为完整中心几何被地块覆盖，且距离大于或等于 1 加额外裕量。保守 PASS 需距离严格大于阈值加 10⁻⁸ 米；出界或距离严格小于阈值减 10⁻⁸ 米判 FAIL；其余保留 UNCERTAIN。',
'- 同一坐标另转 binary64 用 GEOS 重算，只作对照，不悄悄替换主算口径。原边界顶点的最大文本到 binary64 转换位移位于 '+interval(raw['boundary_binary64_conversion_error'])+' 米；全部点段距离的最大 GEOS 与精确十进制差约 '+format(float(raw['geos_decimal_max_distance_discrepancy_m']),'.9g')+' 米，小于冻结 10⁻⁸ 米核对容差。',
'- 逐任务、逐路线也记录各自坐标转换位移。线段插值的转换位移不超过其端点最大位移，两几何间距离的转换偏移不超过两侧位移界之和；GEOS 运算舍入另计。保留文本精度、算术精确性都不能替代测绘精度验证。',
'- 沿用前序 EPSG:32634 的米制解释，没有重新证明投影或原测绘是真值。圆盘没有转向半径、姿态、非圆农具、速度或控制执行模型。','',
'## 独立复核与执行证据','',
'独立保存结果重算 PASS。审阅器不导入作者代码，不调用路线求解器；以独立整数网格、绕数和有理距离实现核对全部 252 次服务点使用、161 次路线线段使用，覆盖 123 个独特服务点和 92 条独特线段。全部 72/48/144 条件、证点、包围区间、阈值、任务恰一次服务、depot 闭合及原十进制多边形有效性一致。28 份复制输入与原文件逐字节一致，230 份上游文件未改。','',
f"预先限定 120 秒 CPU、180 秒 wall、512 MiB 地址空间，仅执行一次。主执行器实际计得 CPU {run['children_cpu_seconds']:.6f} 秒、wall {run['wall_seconds']:.6f} 秒、子进程峰值 RSS {run['children_peak_rss_kib']} KiB。独立复核另用 CPU {review['resources']['cpu_seconds']:.6f} 秒、wall {review['resources']['wall_seconds']:.6f} 秒，未计入主执行。这些单次耗时不是稳定速度比较。",'',
'顺序为：冻结输入、协议、代码和独立合成预审 → PREEXEC 私有上传并逐字节回读 → 唯一正式重算 → RAW 未审包立即私有上传并回读 → 独立重算 → 本报告。没有模型调用、依赖安装、调参重跑、旧证据覆盖或旧索引变更。','',
'- [PREEXEC 冻结快照]('+pre['url']+')，SHA256 '+pre['sha256'],
'- [RAW 原始未审阶段快照]('+receipt['url']+')，SHA256 '+receipt['sha256'], '',
'RAW 中 COMPLETE_UNAUDITED 标签作为执行阶段证据保留；当前审阅结论见 independent_review。','',
'## 解释边界与下一步','',
'这是一个地块，三个随机布局各自取 8、12、20、40 个任务的嵌套前缀，不能当作 12 个独立环境；8 条路线来自 4 个实例的两种方法，也不是 8 个独立地块。档位虽在本阶段重算前冻结，但此前最小净空已知，因此属于后验敏感性，不是盲测或统计验证。','',
'要讨论真实车辆，应先独立给出车辆/农具足迹、定位与地块边界误差界、跟踪控制误差及适用条件，再判断如何形成组合裕量。本阶段不替用户假定这些误差。若以后在更大裕量下重规划，应作为新冻结实验；端点已经不可行的原任务不能靠只改连接线修复。','',
'完整数据索引：all_72_task_conditions.json、all_48_saved_route_conditions.json、all_144_instance_method_conditions.json；逐点逐段证据和原始状态在 raw/；协议及坐标身份在 freeze/；完整独审代码、结果与报告在 independent_review/。','']
report='\n'.join(lines)
with (R/'reports/REPORT_zh.md').open('x') as f:f.write(report)
for name,key in [('all_72_task_conditions.json','task_conditions'),('all_48_saved_route_conditions.json','existing_route_conditions'),('all_144_instance_method_conditions.json','all_instance_method_conditions')]:save('reports/'+name,raw[key])
assert all(s['conditions'][mi]['conservative_status']=='PASS' for t in tasks for s in t['all_services'] if s['service_id']==0 for mi in range(6))
save('evidence/REPORT_CONTENT_RECHECK.json',{'status':'PASS','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'report_sha256':hashlib.sha256(report.encode()).hexdigest(),'task_rows':len(tasks),'route_rows':len(routes),'task_conditions':len(raw['task_conditions']),'route_conditions':len(raw['existing_route_conditions']),'all_method_conditions':len(raw['all_instance_method_conditions']),'all_depots_pass_six_margins':True,'summary_matches_independent_review':True,'no_geometry_recomputed':True,'report_is_markdown_technical_artifact_matching_prior_project_format':True})
print('Saved Chinese report and complete JSON condition tables.')
