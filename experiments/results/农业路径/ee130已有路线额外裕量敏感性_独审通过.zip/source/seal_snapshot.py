#!/usr/bin/python3
import datetime,hashlib,json,pathlib,zipfile,sys
R=pathlib.Path(__file__).resolve().parents[1]
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
kind=sys.argv[1]
if kind=='PREEXECUTION':
 assert not list((R/'raw').iterdir())
 paths=[p for p in sorted(R.rglob('*')) if p.is_file() and p.suffix!='.pyc']
 manifest={'stage':'PREEXECUTION_FROZEN','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':{str(p.relative_to(R)):h(p) for p in paths},'formal_run_not_started':True}
 m=R/'freeze/PREEXECUTION_FREEZE.json'
elif kind=='RAW_COMPLETE_UNAUDITED':
 assert (R/'evidence/RUN_STATUS.json').exists()
 paths=[p for p in sorted(R.rglob('*')) if p.is_file() and p.suffix!='.pyc']
 manifest={'stage':kind,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':{str(p.relative_to(R)):h(p) for p in paths},'no_interpretive_report_yet':True}
 assert not list((R/'reports').iterdir());m=R/'evidence/RAW_COMPLETE_UNAUDITED_MANIFEST.json'
else:raise SystemExit('Only PREEXECUTION or RAW_COMPLETE_UNAUDITED')
with m.open('x') as f:json.dump(manifest,f,indent=2);f.write('\n')
zipname=R.parent/(R.name+('_PREEXECUTION_SNAPSHOT.zip' if kind=='PREEXECUTION' else '_RAW_COMPLETE_UNAUDITED.zip'))
with zipfile.ZipFile(zipname,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(R.rglob('*')):
  if p.is_file() and p.suffix!='.pyc':z.write(p,str(p.relative_to(R)))
print(json.dumps({'path':str(zipname),'bytes':zipname.stat().st_size,'sha256':h(zipname),'stage':kind}))
