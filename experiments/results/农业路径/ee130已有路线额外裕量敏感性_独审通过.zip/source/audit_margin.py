#!/usr/bin/python3
"""Single frozen read-only geometry sensitivity run; no solver, networking, or imports of prior code."""
import collections,datetime,decimal,hashlib,json,math,os,pathlib,re,resource,sys,time
from fractions import Fraction as F
from decimal import Decimal as D
ROOT=pathlib.Path(__file__).resolve().parents[1]
decimal.getcontext().prec=80
MARGINS=['0','0.01','0.05','0.10','0.25','0.50']; TAU=F('0.00000001'); SCALE=10**12
METHODS=['nearest_neighbor','nn_2opt_budget']
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def read(p):return json.loads(pathlib.Path(p).read_text(),parse_float=D)
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def save(rel,x):
 p=ROOT/rel;p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x') as f:json.dump(x,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')
def pt(a):return tuple(F(str(x)) for x in a)
def txt(a):return [str(D(x.numerator)/D(x.denominator)) for x in a]
def sub(a,b):return a[0]-b[0],a[1]-b[1]
def dot(a,b):return a[0]*b[0]+a[1]*b[1]
def cross(a,b):return a[0]*b[1]-a[1]*b[0]
def lerp(a,b,t):return a[0]+t*(b[0]-a[0]),a[1]+t*(b[1]-a[1])
def on(p,a,b):return cross(sub(p,a),sub(b,a))==0 and min(a[0],b[0])<=p[0]<=max(a[0],b[0]) and min(a[1],b[1])<=p[1]<=max(a[1],b[1])
def intersect_parameters(a,b,c,d):
 v,w=sub(b,a),sub(d,c);den=cross(v,w);r=sub(c,a)
 if den:
  t,u=cross(r,w)/den,cross(r,v)/den
  return [t] if 0<=t<=1 and 0<=u<=1 else []
 if cross(r,v):return []
 if a==b:return [F(0)] if on(a,c,d) else []
 k=0 if v[0] else 1
 lo,hi=sorted([(c[k]-a[k])/v[k],(d[k]-a[k])/v[k]])
 lo,hi=max(lo,F(0)),min(hi,F(1))
 return [lo,hi] if lo<=hi else []
def point_segment(p,a,b):
 v=sub(b,a);den=dot(v,v);t=max(F(0),min(F(1),dot(sub(p,a),v)/den)) if den else F(0)
 q=lerp(a,b,t);return dot(sub(p,q),sub(p,q)),q,t
def segment_distance(a,b,c,d):
 hits=intersect_parameters(a,b,c,d)
 if hits:
  q=lerp(a,b,hits[0]);return F(0),q,q,'intersection'
 vals=[]
 for p,n in [(a,'route_endpoint'),(b,'route_endpoint')]:
  q,r,t=point_segment(p,c,d);vals.append((q,p,r,n))
 for p,n in [(c,'boundary_a'),(d,'boundary_b')]:
  q,r,t=point_segment(p,a,b);vals.append((q,r,p,n))
 return min(vals,key=lambda x:x[0])
def ring_location(p,r):
 inside=False
 for a,b in zip(r,r[1:]+r[:1]):
  if on(p,a,b):return 0
  if (a[1]>p[1])!=(b[1]>p[1]):
   x=a[0]+(p[1]-a[1])*(b[0]-a[0])/(b[1]-a[1])
   if x>p[0]:inside=not inside
 return 1 if inside else -1
def covered_point(p,rings):return ring_location(p,rings[0])>=0 and all(ring_location(p,r)!=1 for r in rings[1:])
def covered_segment(a,b,rings,edges):
 if not covered_point(a,rings) or not covered_point(b,rings):return False
 cuts={F(0),F(1)}
 for ri,ei,c,d in edges:cuts.update(intersect_parameters(a,b,c,d))
 ordered=sorted(cuts)
 return all(covered_point(lerp(a,b,(u+v)/2),rings) for u,v in zip(ordered,ordered[1:]))
def bounds(q,offset=F(0)):
 # Exact floor of sqrt(q)*10^12, computed only with integer arithmetic.
 k=math.isqrt((q.numerator*SCALE*SCALE)//q.denominator)
 lower=F(k,SCALE);upper=lower if lower*lower==q else F(k+1,SCALE)
 assert lower*lower<=q<=upper*upper
 def dec(x):return format(D(x.numerator)/D(x.denominator),'.12f')
 return {'lower_m':dec(lower-offset),'upper_m':dec(upper-offset),'interval_width_m':dec(upper-lower),'lower_inclusive':True,'upper_inclusive':True}
def classify(q,covered,margin):
 threshold=1+F(margin)
 return {'extra_margin_m':margin,'required_radius_m':str(D(threshold.numerator)/D(threshold.denominator)),
 'closed_disk_exact_feasible':bool(covered and q>=threshold*threshold),
 'conservative_status':'FAIL' if not covered or q<(threshold-TAU)**2 else 'PASS' if q>(threshold+TAU)**2 else 'UNCERTAIN_THRESHOLD',
 'definition':'Closed disk fits iff whole center geometry covered and d >= 1 + margin; conservative PASS requires d > 1 + margin + 1e-8 m.'}
def evaluate(a,b,rings,edges):
 best=None;witness=None
 for ri,ei,c,d in edges:
  q,rp,bp,case=segment_distance(a,b,c,d)
  if best is None or q<best:
   best=q;witness={'ring_index':ri,'ring_type':'outer' if ri==0 else 'hole','edge_index':ei,'boundary_a':txt(c),'boundary_b':txt(d),'route_point':txt(rp),'boundary_point':txt(bp),'case':case}
 covered=covered_segment(a,b,rings,edges)
 return {'covered':covered,'distance_squared':{'numerator':str(best.numerator),'denominator':str(best.denominator)},'clearance_interval':bounds(best),'clearance_decimal_80':str((D(best.numerator)/D(best.denominator)).sqrt()),'signed_additional_clearance_interval':bounds(best,F(1)),'nonnegative_margin_exists':bool(covered and best>=1),'witness':witness,'conditions':[classify(best,covered,m) for m in MARGINS]}
def ratio(ev):return F(int(ev['distance_squared']['numerator']),int(ev['distance_squared']['denominator']))
def binary_error(coords):
 q=max((dot(sub(tuple(F.from_float(float(v)) for v in p),p),sub(tuple(F.from_float(float(v)) for v in p),p)) for p in coords),default=F(0));return bounds(q)
def geometry(wkt):
 rings=[]
 for group in re.findall(r'\(([^()]+)\)',wkt):
  r=[pt(x.split()) for x in group.split(',')];assert r[0]==r[-1];rings.append(r[:-1])
 assert rings
 return rings,[(ri,ei,a,b) for ri,r in enumerate(rings) for ei,(a,b) in enumerate(zip(r,r[1:]+r[:1]))]
def toy():
 w='POLYGON ((0 0,20 0,20 20,0 20,0 0),(8 8,12 8,12 12,8 12,8 8))';r,e=geometry(w)
 cases=[('inside',[[2,2],[18,2]],F(4),True),('hole_cross',[[2,10],[18,10]],F(0),False),('outside',[[21,2],[22,2]],F(1),False),('boundary',[[0,2],[0,18]],F(0),True),('tangent_1',[[1,2],[1,18]],F(1),True),('point',[[2,2],[2,2]],F(4),True),('inside_hole',[[9,9],[11,9]],F(1),False),('degenerate_boundary',[[0,2],[0,2]],F(0),True)]
 out=[]
 for name,coords,q,covered in cases:
  z=evaluate(*map(pt,coords),r,e);assert ratio(z)==q and z['covered']==covered,(name,z);out.append({'name':name,'pass':True})
 for v in ['1','1.000000005','1.00000001','1.000000011','.99999999','.999999989','1.01']:
  q=F(v)**2;s=classify(q,True,'0');expected='FAIL' if F(v)<1-TAU else 'PASS' if F(v)>1+TAU else 'UNCERTAIN_THRESHOLD';assert s['conservative_status']==expected;assert s['closed_disk_exact_feasible']==(F(v)>=1)
 assert classify(F('1.01')**2,True,'.01')['closed_disk_exact_feasible']
 assert classify(F('1.01')**2,True,'.01')['conservative_status']=='UNCERTAIN_THRESHOLD'
 assert point_segment(pt([1,0]),pt([0,0]),pt([2,2]))[0]==F(1,2)
 assert segment_distance(pt([0,0]),pt([4,0]),pt([2,0]),pt([5,0]))[0]==0
 for q in [F(0),F(1),F(1,2),F(1000000000000000000001,1000000000000000000000)]:bounds(q)
 cr,ce=geometry('POLYGON ((0 0,5 0,5 5,3 5,3 2,2 2,2 5,0 5,0 0))')
 assert not covered_segment(pt([1,4]),pt([4,4]),cr,ce)
 return {'status':'PASS','synthetic_only':True,'cases':out,'threshold_cases':7,'exact_tangency_closed_disk':True,'threshold_band_conservative':True,'collinear_degenerate_crossing_projection_concavity_interval_tests':True}
def verify_execution_gate():
 started=read(ROOT/'evidence/STARTED.json');receipt=read(ROOT/'evidence/PREEXECUTION_DRIVE_RECEIPT.json')
 archive=ROOT.parent/(ROOT.name+'_PREEXECUTION_SNAPSHOT.zip')
 assert started['attempt']==1 and started['runner_pid']==os.getppid(),'Formal execution must be the child of the one recorded runner'
 assert started['cpu_limit_s']==120 and started['wall_limit_s']==180 and started['memory_limit_bytes']==536870912
 assert resource.getrlimit(resource.RLIMIT_CPU)==(120,120) and resource.getrlimit(resource.RLIMIT_AS)==(536870912,536870912)
 assert receipt.get('verified') is True and receipt.get('download_byte_identical') is True and receipt.get('permissions')=='owner_only' and receipt.get('shared') is False
 assert receipt['sha256']==receipt['download_sha256']==started['preexec_zip_sha256']==sha(archive)
 assert receipt['bytes']==archive.stat().st_size and started['receipt_sha256']==sha(ROOT/'evidence/PREEXECUTION_DRIVE_RECEIPT.json')
 assert not list((ROOT/'raw').iterdir()),'No reruns or partial-result overwrite'
 save('evidence/FORMAL_CHILD_ENTERED.json',{'entered_utc':utc(),'pid':os.getpid(),'runner_pid':os.getppid(),'attempt':1,'preexec_zip_sha256':sha(archive)})
def main():
 verify_execution_gate()
 start=time.perf_counter();cpu=time.process_time();freeze=read(ROOT/'freeze/PREEXECUTION_FREEZE.json')
 for rel,h in freeze['files'].items():assert sha(ROOT/rel)==h,rel
 wkt=(ROOT/'input/projected_epsg32634.wkt').read_text();rings,edges=geometry(wkt);assert len(rings)==4
 from osgeo import ogr,gdal
 ogr.UseExceptions();field=ogr.CreateGeometryFromWkt(wkt);assert field.IsValid();boundary=field.Boundary()
 def geos(points):
  kind=ogr.wkbPoint if len(points)==1 or all(p==points[0] for p in points) else ogr.wkbLineString
  g=ogr.Geometry(kind)
  for p in (points[:1] if kind==ogr.wkbPoint else points):g.AddPoint_2D(float(p[0]),float(p[1]))
  return bool(g.Difference(field).IsEmpty()),g.Distance(boundary)
 comparisons=[];maxdelta=D(0)
 def crosscheck(ev,points,label):
  nonlocal maxdelta
  cov,d=geos(points);delta=abs(D(str(d))-D(ev['clearance_decimal_80']));maxdelta=max(maxdelta,delta)
  comparisons.append({'label':label,'geos_covered':cov,'exact_covered':ev['covered'],'geos_distance_m':d,'exact_decimal_distance_m':ev['clearance_decimal_80'],'absolute_difference_m':str(delta)})
  assert cov==ev['covered'] and delta<=D('1e-8'),label
 tasks={};services={};routes=[];pcache={};scache={};taskconditions=[];routeconditions=[];methodconditions=[]
 for p in sorted((ROOT/'input/tasks').glob('*.json')):
  inst=read(p);iid=inst['instance_id'];assert len(inst['coordinates'])==inst['n']+1;rows=[]
  for sid,c in enumerate(inst['coordinates']):
   a=pt(c)
   if a not in pcache:pcache[a]=evaluate(a,a,rings,edges);crosscheck(pcache[a],[a],iid+':'+str(sid))
   rows.append({'service_id':sid,'role':'depot' if sid==0 else 'task','coordinate':txt(a),**pcache[a]})
  minimum=min(rows,key=ratio);q=ratio(minimum);allinside=all(x['covered'] for x in rows)
  rec={'instance_id':iid,'n':inst['n'],'seed':inst['seed'],'service_count_including_depot':len(rows),'all_services':rows,'endpoint_minimum_service_ids':[x['service_id'] for x in rows if ratio(x)==q],'endpoint_minimum':minimum,'endpoint_necessary_signed_margin_upper_bound':bounds(q,F(1)),'nonnegative_endpoint_admissible_margin_exists':bool(allinside and q>=1),'meaning':'This is a necessary endpoint upper bound only, not an existence or connectivity guarantee for any route.','binary64_coordinate_error':binary_error([pt(c) for c in inst['coordinates']]),'conditions':[]}
  for mi,m in enumerate(MARGINS):
   failing=[s['service_id'] for s in rows if s['conditions'][mi]['conservative_status']=='FAIL'];uncertain=[s['service_id'] for s in rows if s['conditions'][mi]['conservative_status']=='UNCERTAIN_THRESHOLD']
   status='TASK_ENDPOINT_INFEASIBLE' if failing else 'ENDPOINT_THRESHOLD_UNCERTAIN' if uncertain else 'ENDPOINTS_CLEAR'
   row={'instance_id':iid,'extra_margin_m':m,'status':status,'failing_service_ids':failing,'uncertain_service_ids':uncertain,'closed_disk_all_endpoints_feasible':all(s['conditions'][mi]['closed_disk_exact_feasible'] for s in rows)};rec['conditions'].append(row);taskconditions.append(row)
  tasks[iid]=rec;services[iid]=inst
  save('raw/'+iid+'_endpoints.json',rec)
 expected={(n,s) for n in [8,12,20,40] for s in [202610081001,202610081002,202610081003]};assert len(tasks)==12 and {(x['n'],x['seed']) for x in tasks.values()}==expected
 for p in sorted((ROOT/'input/routes').glob('*_solver_output.json')):
  data=read(p);method=next(m for m in METHODS if p.name.endswith('_'+m+'_solver_output.json'));iid=p.name[:-len('_'+method+'_solver_output.json')];inst=services[iid];coords=[pt(c) for c in data['mapped_polyline_coordinates']];order=data['route']
  assert order[0]==order[-1]==0 and collections.Counter(order[1:-1])==collections.Counter(range(1,inst['n']+1))
  assert coords[0]==coords[-1]==pt(inst['coordinates'][0]);assert len(coords)>=2
  # Saved leg breakpoints bind the service schedule to actual polyline nodes.
  rebuilt=[];ids=data['mapped_polyline_node_ids']
  assert len(data['legs'])==len(order)-1
  for i,leg in enumerate(data['legs']):
   assert leg['service_leg']==order[i:i+2];ns=leg['node_ids'];rebuilt.extend(ns if i==0 else ns[1:])
   offset=sum(len(x['node_ids'])-1 for x in data['legs'][:i]);assert coords[offset]==pt(inst['coordinates'][order[i]]) and coords[offset+len(ns)-1]==pt(inst['coordinates'][order[i+1]])
  assert rebuilt==ids and len(ids)==len(coords)
  pieces=[]
  for si,(a,b) in enumerate(zip(coords,coords[1:])):
   key=tuple(sorted([a,b]))
   if key not in scache:scache[key]=evaluate(a,b,rings,edges);crosscheck(scache[key],[a,b],p.stem+':'+str(si))
   pieces.append({'segment_index':si,'a':txt(a),'b':txt(b),**scache[key]})
  best=min(pieces,key=ratio);q=ratio(best);contained=all(x['covered'] for x in pieces);ev={k:v for k,v in best.items() if k not in ['segment_index','a','b']};ev['covered']=contained;crosscheck(ev,coords,p.stem+':full')
  length=sum((D(dot(sub(b,a),sub(b,a)).numerator)/D(dot(sub(b,a),sub(b,a)).denominator)).sqrt() for a,b in zip(coords,coords[1:]));assert abs(length-D(data['length_m']))<=D('1e-8')
  rec={'instance_id':iid,'method':method,'source_file':str(p.relative_to(ROOT)),'source_sha256':sha(p),'service_order':order,'scheduled_visit_once':True,'depot_closed':True,'polyline_leg_services_verified':True,'length_decimal_80_m':str(length),'saved_length_m':str(data['length_m']),'segment_count':len(pieces),'segments':pieces,'fixed_route_minimum':ev,'bottleneck_segment_indices':[s['segment_index'] for s in pieces if ratio(s)==q],'fixed_route_exact_maximum_additional_margin_interval':bounds(q,F(1)),'nonnegative_fixed_route_margin_exists':bool(contained and q>=1),'maximum_is_attained_for_closed_disk':bool(contained and q>=1),'meaning':'Maximum geometric margin for this saved full polyline in the decimal-coordinate disk model only.','binary64_coordinate_error':binary_error(coords),'conditions':[]}
  for mi,m in enumerate(MARGINS):
   z=classify(q,contained,m);z.update({'instance_id':iid,'method':method});rec['conditions'].append(z);routeconditions.append(z)
  routes.append(rec);save('raw/'+iid+'_'+method+'_margins.json',rec)
 assert len(routes)==8 and len({r['instance_id'] for r in routes})==4
 rmap={(r['instance_id'],r['method']):r for r in routes}
 for iid,t in tasks.items():
  for method in METHODS:
   for mi,m in enumerate(MARGINS):
    tc=t['conditions'][mi];r=rmap.get((iid,method));rc=None if r is None else r['conditions'][mi]
    status=tc['status'] if tc['status']!='ENDPOINTS_CLEAR' else 'NO_EXISTING_ROUTE_TO_AUDIT' if rc is None else 'EXISTING_ROUTE_PASS' if rc['conservative_status']=='PASS' else 'EXISTING_ROUTE_MARGIN_INSUFFICIENT' if rc['conservative_status']=='FAIL' else 'EXISTING_ROUTE_THRESHOLD_UNCERTAIN'
    methodconditions.append({'instance_id':iid,'method':method,'extra_margin_m':m,'task_status':tc['status'],'existing_route_available':r is not None,'fixed_route_status':None if rc is None else rc['conservative_status'],'combined_status':status,'absence_does_not_mean_no_feasible_route':True})
 summary=[]
 for m in MARGINS:
  tr=[x for x in taskconditions if x['extra_margin_m']==m];rr=[x for x in routeconditions if x['extra_margin_m']==m];mr=[x for x in methodconditions if x['extra_margin_m']==m]
  summary.append({'extra_margin_m':m,'task_denominator':12,'task_status_counts':dict(collections.Counter(x['status'] for x in tr)),'saved_route_denominator':8,'saved_route_status_counts':dict(collections.Counter(x['conservative_status'] for x in rr)),'instance_method_denominator':24,'instance_method_combined_status_counts':dict(collections.Counter(x['combined_status'] for x in mr))})
 out={'status':'COMPLETE_UNAUDITED','created_utc':utc(),'study':'ee130_saved_route_geometric_margin_sensitivity_v1','base_disk_radius_m':'1','margins_m':MARGINS,'numeric_conservative_tau_m':'0.00000001','task_conditions':taskconditions,'existing_route_conditions':routeconditions,'all_instance_method_conditions':methodconditions,'summary':summary,'tasks_count':12,'saved_routes_count':8,'unique_service_points':len(pcache),'service_uses':sum(x['service_count_including_depot'] for x in tasks.values()),'unique_route_segments':len(scache),'route_segment_uses':sum(r['segment_count'] for r in routes),'original_ring_count':len(rings),'original_edge_count':len(edges),'boundary_binary64_conversion_error':binary_error([p for r in rings for p in r]),'geos_decimal_max_distance_discrepancy_m':str(maxdelta),'geos_version':[ogr.GetGEOSVersionMajor(),ogr.GetGEOSVersionMinor(),ogr.GetGEOSVersionMicro()],'gdal':gdal.VersionInfo(),'resources':{'cpu_seconds':time.process_time()-cpu,'wall_seconds':time.perf_counter()-start,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},'limitations':['Post-hoc geometric sensitivity on one field; not vehicle validation.','12 instances are nested prefixes of 3 layouts; 8 saved routes are 2 methods on 4 endpoint-feasible instances, not independent fields.','No measured hardware error distribution or probability/safety claim.','Exact arithmetic treats saved decimal coordinates as exact model data, not surveying truth.','Endpoint limits are necessary bounds, not route existence certificates.','No route regeneration or alternative optimization.']}
 save('raw/binary64_crosschecks.json',{'status':'PASS','agreement_tolerance_m':'0.00000001','checks':comparisons,'max_difference_m':str(maxdelta)})
 save('raw/results.json',out);print(json.dumps({'status':out['status'],'summary':summary,'resources':out['resources']},ensure_ascii=False),flush=True)
if __name__=='__main__':
 if sys.argv[1:] == ['--toy']:save('evidence/PREEXECUTION_TOY_TESTS.json',toy())
 elif sys.argv[1:] == ['--formal']:main()
 else:raise SystemExit('Use --toy or gated run_once.py; no implicit execution.')
