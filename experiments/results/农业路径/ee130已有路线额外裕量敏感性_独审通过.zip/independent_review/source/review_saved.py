#!/usr/bin/python3
"""Independent saved-result audit. Invoked only after author's raw archival release.
No author code imported, no optimization, no mutation of author or upstream evidence.
"""
import collections,datetime,decimal,hashlib,json,pathlib,resource,sys,time,zipfile
from decimal import Decimal
from fractions import Fraction
from integer_geometry import *
from osgeo import ogr,gdal
R=pathlib.Path(__file__).resolve().parents[1]
A=pathlib.Path('/workspace/shared/ee130_route_margin_sensitivity_20261008')
MARGINS=['0','0.01','0.05','0.10','0.25','0.50']
METHODS=['nearest_neighbor','nn_2opt_budget']
decimal.getcontext().prec=100

def read(path):return json.loads(path.read_text(),parse_float=Decimal)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def emit(path,data):
    with path.open('x') as out:json.dump(data,out,indent=2,ensure_ascii=False);out.write('\n')
def rat(ev):return Fraction(int(ev['distance_squared']['numerator']),int(ev['distance_squared']['denominator']))
def decimal_of(q):return Decimal(q.numerator)/Decimal(q.denominator)
def interval_check(rec,q,shift=Fraction(0)):
    lo,hi=enclosing(q,shift)
    assert Fraction(rec['lower_m'])==lo and Fraction(rec['upper_m'])==hi
    assert Fraction(rec['interval_width_m'])==hi-lo
    assert rec['lower_inclusive'] is True and rec['upper_inclusive'] is True

def binary_bound(points,rec):
    q=max((sum((Fraction.from_float(float(v))-Fraction(str(v)))**2 for v in p) for p in points),default=Fraction(0))
    interval_check(rec,q)
    return q

def check_conditions(rows,q,covered):
    assert len(rows)==6
    for m,row in zip(MARGINS,rows):
        exact,status=labels(q,covered,m)
        assert row['extra_margin_m']==m and row['closed_disk_exact_feasible']==exact
        assert row['conservative_status']==status
        assert Fraction(row['required_radius_m'])==1+Fraction(m)

def archive_matches(path,manifest_path):
    manifest=read(manifest_path)
    with zipfile.ZipFile(path) as z:
        names=z.namelist();assert len(names)==len(set(names))
        for name,digest in manifest['files'].items():
            assert hashlib.sha256(z.read(name)).hexdigest()==digest,(name,'archive')
            assert sha(A/name)==digest,(name,'local')
        assert z.read(str(manifest_path.relative_to(A)))==manifest_path.read_bytes()
    return len(manifest['files'])

def receipt_check(path,archive):
    receipt=read(path)
    assert receipt.get('verified') is True and receipt.get('download_byte_identical') is True
    assert receipt.get('permissions')=='owner_only' and receipt.get('shared') is False
    assert receipt['sha256']==receipt['download_sha256']==sha(archive)
    assert int(receipt['bytes'])==archive.stat().st_size
    return {'path':str(path),'sha256':sha(path),'archive_sha256':sha(archive),'bytes':archive.stat().st_size}

def main():
    assert len(sys.argv)==3 and sys.argv[1]=='--released-raw-receipt', 'A verified raw archival receipt is required.'
    resource.setrlimit(resource.RLIMIT_CPU,(120,120));resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912))
    t=time.perf_counter();cpu=time.process_time()
    raw_receipt=pathlib.Path(sys.argv[2])
    prearchive=A.parent/(A.name+'_PREEXECUTION_SNAPSHOT.zip')
    rawarchive=A.parent/(A.name+'_RAW_COMPLETE_UNAUDITED.zip')
    pre_gate=receipt_check(A/'evidence/PREEXECUTION_DRIVE_RECEIPT.json',prearchive)
    raw_gate=receipt_check(raw_receipt,rawarchive)
    frozen_count=archive_matches(prearchive,A/'freeze/PREEXECUTION_FREEZE.json')
    raw_frozen_count=archive_matches(rawarchive,A/'evidence/RAW_COMPLETE_UNAUDITED_MANIFEST.json')
    static=read(R/'evidence/STATIC_PREEXEC_REVIEW.json')
    for rel,h in static['author_files_sha256'].items():assert sha(A/rel)==h,(rel,'pre-reviewed bytes changed')
    immutable=read(A/'freeze/UPSTREAM_IMMUTABILITY.json')
    for name,h in immutable.items():assert sha(pathlib.Path(name))==h,(name,'upstream changed')
    identity=read(A/'freeze/INPUT_IDENTITY.json')
    for row in identity:
        assert sha(pathlib.Path(row['source_path']))==row['sha256']==sha(A/row['copied_path'])
        assert (A/row['copied_path']).stat().st_size==row['bytes']
    run=read(A/'evidence/RUN_STATUS.json');started=read(A/'evidence/STARTED.json');entered=read(A/'evidence/FORMAL_CHILD_ENTERED.json')
    assert run['status']=='COMPLETE_UNAUDITED' and run['exit_code']==0 and run['one_formal_execution'] is True
    assert run['wall_seconds']<180 and run['children_cpu_seconds']<=120
    assert run['children_peak_rss_kib']*1024<536870912
    assert started['attempt']==entered['attempt']==1 and started['runner_pid']==entered['runner_pid']
    assert started['preexec_zip_sha256']==entered['preexec_zip_sha256']==pre_gate['archive_sha256']
    assert started['receipt_sha256']==pre_gate['sha256']
    wkt=(A/'input/projected_epsg32634.wkt').read_text();token_rings=read_wkt_rings(wkt)
    task_data={p.name:read(p) for p in sorted((A/'input/tasks').glob('*.json'))}
    route_data={p.name:read(p) for p in sorted((A/'input/routes').glob('*_solver_output.json'))}
    assert len(task_data)==12 and len(route_data)==8
    all_points=[p for r in token_rings for p in r]
    all_points += [p for data in task_data.values() for p in data['coordinates']]
    all_points += [p for data in route_data.values() for p in data['mapped_polyline_coordinates']]
    places=max(decimal_places(v) for p in all_points for v in p);scale=10**places
    rings=[grid_points(r,scale) for r in token_rings];border=edges(rings)
    assert len(rings)==4 and validate_rings(rings)
    polygon=ogr.CreateGeometryFromWkt(wkt);assert polygon.IsValid();boundary=polygon.Boundary()
    records=[];cache={};checks=0;geos_max=Decimal(0)
    def evaluate(a,b,label):
        nonlocal geos_max
        key=tuple(sorted((a,b)))
        if key not in cache:
            ev=clearance(a,b,rings,scale,border)
            g=ogr.Geometry(ogr.wkbPoint if a==b else ogr.wkbLineString)
            for p in ([a] if a==b else [a,b]):g.AddPoint_2D(float(Fraction(p[0],scale)),float(Fraction(p[1],scale)))
            assert bool(g.Difference(polygon).IsEmpty())==ev['covered']
            delta=abs(Decimal(str(g.Distance(boundary)))-decimal_of(ev['q']).sqrt())
            assert delta<=Decimal('1e-8');geos_max=max(geos_max,delta)
            cache[key]=ev
        return cache[key]
    def check_ev(stored,ev,a,b,label):
        nonlocal checks
        assert rat(stored)==ev['q'] and stored['covered']==ev['covered'],(label,'distance or containment')
        interval_check(stored['clearance_interval'],ev['q'])
        interval_check(stored['signed_additional_clearance_interval'],ev['q'],Fraction(1))
        assert abs(Decimal(stored['clearance_decimal_80'])-decimal_of(ev['q']).sqrt())<Decimal('1e-70')
        assert stored['nonnegative_margin_exists']==(ev['covered'] and ev['q']>=1)
        check_conditions(stored['conditions'],ev['q'],ev['covered'])
        witness=stored['witness'];ri=witness['ring_index'];ei=witness['edge_index']
        assert (ri,ei)==(ev['ring'],ev['edge'])
        c=rings[ri][ei];d=rings[ri][(ei+1)%len(rings[ri])]
        assert tuple(Fraction(str(x))*scale for x in witness['boundary_a'])==c
        assert tuple(Fraction(str(x))*scale for x in witness['boundary_b'])==d
        assert witness['ring_type']==('outer' if ri==0 else 'hole')
        rp=tuple(Fraction(x)*scale for x in witness['route_point']);bp=tuple(Fraction(x)*scale for x in witness['boundary_point'])
        tol=Fraction(1,10**60)
        assert nearest_point(rp,a,b)[0]/scale**2<tol*tol
        assert nearest_point(bp,c,d)[0]/scale**2<tol*tol
        assert abs(sum((x-y)**2 for x,y in zip(rp,bp))/scale**2-ev['q'])<tol
        checks+=1
    tasks={};all_task_conditions=[];task_minima=[];service_count=0
    for name,data in task_data.items():
        iid=data['instance_id'];coords=grid_points(data['coordinates'],scale)
        stored=read(A/'raw'/f'{iid}_endpoints.json')
        assert len(coords)==data['n']+1==stored['service_count_including_depot']
        assert stored['instance_id']==iid and stored['n']==data['n'] and stored['seed']==data['seed']
        assert len(stored['all_services'])==len(coords)
        values=[]
        for sid,(p,rec) in enumerate(zip(coords,stored['all_services'])):
            ev=evaluate(p,p,f'{iid}:{sid}');values.append(ev)
            assert rec['service_id']==sid and rec['role']==('depot' if sid==0 else 'task')
            assert grid_points([rec['coordinate']],scale)[0]==p
            check_ev(rec,ev,p,p,f'{iid}:{sid}');service_count+=1
        q=min(x['q'] for x in values);covered=all(x['covered'] for x in values)
        ids=[i for i,x in enumerate(values) if x['q']==q]
        assert stored['endpoint_minimum_service_ids']==ids
        assert rat(stored['endpoint_minimum'])==q and stored['endpoint_minimum']['service_id']==ids[0]
        interval_check(stored['endpoint_necessary_signed_margin_upper_bound'],q,Fraction(1))
        assert stored['nonnegative_endpoint_admissible_margin_exists']==(covered and q>=1)
        binary_bound(data['coordinates'],stored['binary64_coordinate_error'])
        rows=[]
        for m in MARGINS:
            statuses=[labels(x['q'],x['covered'],m) for x in values]
            bad=[i for i,x in enumerate(statuses) if x[1]=='FAIL'];uncertain=[i for i,x in enumerate(statuses) if x[1]=='UNCERTAIN_THRESHOLD']
            row={'instance_id':iid,'extra_margin_m':m,'status':'TASK_ENDPOINT_INFEASIBLE' if bad else 'ENDPOINT_THRESHOLD_UNCERTAIN' if uncertain else 'ENDPOINTS_CLEAR','failing_service_ids':bad,'uncertain_service_ids':uncertain,'closed_disk_all_endpoints_feasible':all(x[0] for x in statuses)}
            rows.append(row)
        assert rows==stored['conditions'];all_task_conditions.extend(rows)
        tasks[iid]={'data':data,'coordinates':coords,'conditions':rows}
        task_minima.append({'instance_id':iid,'minimum_distance_squared_numerator':str(q.numerator),'minimum_distance_squared_denominator':str(q.denominator),'bottleneck_service_ids':ids,'margin_interval':stored['endpoint_necessary_signed_margin_upper_bound'],'covered':covered})
    assert {(v['data']['n'],v['data']['seed']) for v in tasks.values()}=={(n,s) for n in (8,12,20,40) for s in (202610081001,202610081002,202610081003)}
    # Independently establish the advertised nested-prefix relation.
    for seed in (202610081001,202610081002,202610081003):
        layouts=sorted((v for v in tasks.values() if v['data']['seed']==seed),key=lambda v:v['data']['n'])
        for shorter,longer in zip(layouts,layouts[1:]):assert longer['coordinates'][:len(shorter['coordinates'])]==shorter['coordinates']
    routes={};all_route_conditions=[];segment_count=0
    for name,data in route_data.items():
        method=next(m for m in METHODS if name.endswith('_'+m+'_solver_output.json'))
        iid=name[:-len('_'+method+'_solver_output.json')];task=tasks[iid];coords=grid_points(data['mapped_polyline_coordinates'],scale)
        stored=read(A/'raw'/f'{iid}_{method}_margins.json');order=data['route'];ids=data['mapped_polyline_node_ids']
        assert stored['source_sha256']==sha(A/'input/routes'/name)
        assert stored['instance_id']==iid and stored['method']==method and stored['service_order']==order
        assert order[0]==order[-1]==0 and collections.Counter(order[1:-1])==collections.Counter(range(1,task['data']['n']+1))
        assert coords[0]==coords[-1]==task['coordinates'][0] and len(ids)==len(coords)
        assert len(data['legs'])==len(order)-1
        rebuilt=[];offset=0
        for i,leg in enumerate(data['legs']):
            assert leg['service_leg']==order[i:i+2]
            nodes=leg['node_ids'];assert len(nodes)>=1
            if i:assert rebuilt[-1]==nodes[0]
            rebuilt+=nodes if not i else nodes[1:]
            assert coords[offset]==task['coordinates'][order[i]]
            offset+=len(nodes)-1
            assert coords[offset]==task['coordinates'][order[i+1]]
        assert rebuilt==ids and offset==len(coords)-1
        assert all(stored[x] is True for x in ('scheduled_visit_once','depot_closed','polyline_leg_services_verified'))
        assert stored['segment_count']==len(coords)-1==len(stored['segments'])
        values=[]
        for i,(a,b,rec) in enumerate(zip(coords,coords[1:],stored['segments'])):
            ev=evaluate(a,b,f'{iid}:{method}:{i}');values.append(ev)
            assert rec['segment_index']==i and grid_points([rec['a'],rec['b']],scale)==[a,b]
            check_ev(rec,ev,a,b,f'{iid}:{method}:{i}');segment_count+=1
        q=min(x['q'] for x in values);covered=all(x['covered'] for x in values)
        assert rat(stored['fixed_route_minimum'])==q and stored['fixed_route_minimum']['covered']==covered
        bottlenecks=[i for i,x in enumerate(values) if x['q']==q]
        assert stored['bottleneck_segment_indices']==bottlenecks
        interval_check(stored['fixed_route_exact_maximum_additional_margin_interval'],q,Fraction(1))
        assert stored['nonnegative_fixed_route_margin_exists']==(covered and q>=1)
        assert covered and stored['maximum_is_attained_for_closed_disk'] is True
        check_conditions(stored['conditions'],q,covered)
        binary_bound(data['mapped_polyline_coordinates'],stored['binary64_coordinate_error'])
        length=sum(decimal_of(Fraction((b[0]-a[0])**2+(b[1]-a[1])**2,scale*scale)).sqrt() for a,b in zip(coords,coords[1:]))
        assert abs(length-Decimal(stored['length_decimal_80_m']))<Decimal('1e-70')
        assert abs(length-Decimal(data['length_m']))<=Decimal('1e-8')
        route_summary={'instance_id':iid,'method':method,'minimum_distance_squared_numerator':str(q.numerator),'minimum_distance_squared_denominator':str(q.denominator),'bottleneck_segment_indices':bottlenecks,'margin_interval':stored['fixed_route_exact_maximum_additional_margin_interval'],'covered':covered,'segment_count':len(values),'length_m':str(length),'margin_statuses':{m:labels(q,covered,m)[1] for m in MARGINS}}
        records.append(route_summary);routes[iid,method]=stored
        all_route_conditions.extend(stored['conditions'])
    assert len(routes)==8 and len({k[0] for k in routes})==4
    combined=[]
    for iid,tdata in tasks.items():
        for method in METHODS:
            for mi,m in enumerate(MARGINS):
                tc=tdata['conditions'][mi];rr=routes.get((iid,method));rc=None if rr is None else rr['conditions'][mi]
                status=(tc['status'] if tc['status']!='ENDPOINTS_CLEAR' else 'NO_EXISTING_ROUTE_TO_AUDIT' if rc is None else 'EXISTING_ROUTE_PASS' if rc['conservative_status']=='PASS' else 'EXISTING_ROUTE_MARGIN_INSUFFICIENT' if rc['conservative_status']=='FAIL' else 'EXISTING_ROUTE_THRESHOLD_UNCERTAIN')
                combined.append({'instance_id':iid,'method':method,'extra_margin_m':m,'task_status':tc['status'],'existing_route_available':rr is not None,'fixed_route_status':None if rc is None else rc['conservative_status'],'combined_status':status,'absence_does_not_mean_no_feasible_route':True})
    summary=[]
    for m in MARGINS:
        tc=[r for r in all_task_conditions if r['extra_margin_m']==m];rc=[r for r in all_route_conditions if r['extra_margin_m']==m];mc=[r for r in combined if r['extra_margin_m']==m]
        summary.append({'extra_margin_m':m,'task_denominator':12,'task_status_counts':dict(collections.Counter(r['status'] for r in tc)),'saved_route_denominator':8,'saved_route_status_counts':dict(collections.Counter(r['conservative_status'] for r in rc)),'instance_method_denominator':24,'instance_method_combined_status_counts':dict(collections.Counter(r['combined_status'] for r in mc))})
    saved=read(A/'raw/results.json')
    assert saved['summary']==summary and saved['task_conditions']==all_task_conditions
    assert saved['existing_route_conditions']==all_route_conditions and saved['all_instance_method_conditions']==combined
    assert len(all_task_conditions)==72 and len(all_route_conditions)==48 and len(combined)==144
    assert saved['tasks_count']==12 and saved['saved_routes_count']==8
    assert saved['service_uses']==service_count and saved['route_segment_uses']==segment_count
    assert saved['original_ring_count']==len(rings) and saved['original_edge_count']==len(border)
    assert saved['unique_service_points']==len({p for v in tasks.values() for p in v['coordinates']})
    assert saved['unique_route_segments']==len({tuple(sorted((a,b))) for data in route_data.values() for a,b in zip(grid_points(data['mapped_polyline_coordinates'],scale),grid_points(data['mapped_polyline_coordinates'],scale)[1:])})
    binary_bound([p for ring in token_rings for p in ring],saved['boundary_binary64_conversion_error'])
    binary_checks=read(A/'raw/binary64_crosschecks.json')
    assert binary_checks['status']=='PASS' and Decimal(binary_checks['max_difference_m'])<=Decimal('1e-8')
    for c in binary_checks['checks']:
        assert c['geos_covered']==c['exact_covered']
        with decimal.localcontext() as ctx:
            ctx.prec=80
            assert abs(Decimal(str(c['geos_distance_m']))-Decimal(c['exact_decimal_distance_m']))==Decimal(c['absolute_difference_m'])
    report={'status':'PASS_INDEPENDENT_SAVED_RESULT_RECOMPUTATION','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'method':'Independent common-integer-decimal-grid orientation/winding and cross-product projection arithmetic; no author module imports or route solver calls.','coordinate_decimal_places':places,'grid_scale':str(scale),'exact_original_polygon_valid':True,'preexecution_gate':pre_gate,'raw_gate':raw_gate,'frozen_file_count':frozen_count,'raw_manifest_file_count':raw_frozen_count,'unchanged_upstream_files':len(immutable),'byte_identical_inputs':len(identity),'checked_point_segment_uses':checks,'checked_service_uses':service_count,'checked_segment_uses':segment_count,'independent_geos_unique_geometry_checks':len(cache),'independent_geos_max_abs_difference_m':str(geos_max),'tasks':task_minima,'routes':records,'summary':summary,'denominators':{'tasks':12,'saved_routes':8,'task_margin_conditions':72,'route_margin_conditions':48,'instance_method_margin_conditions':144},'resources':{'cpu_seconds':time.process_time()-cpu,'wall_seconds':time.perf_counter()-t,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},'source_sha256':{str(p.relative_to(R)):sha(p) for p in (R/'source').glob('*.py')},'limits':['Mathematical certificate applies only to saved decimal geometry and translating closed disk.','Endpoint upper bound does not establish path existence or connectivity.','Only the eight existing polylines were audited; failing a route does not prove the task impossible.','One field and nested prefixes of three layouts do not establish independent-field performance, statistical significance or hardware safety.']}
    emit(R/'results/INDEPENDENT_SAVED_RECOMPUTATION.json',report)
    print(json.dumps({'status':report['status'],'summary':summary,'resources':report['resources']}))
if __name__=='__main__':main()
