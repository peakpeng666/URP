#!/usr/bin/python3
"""Synthetic-only independent tests. Does not open author files or genuine inputs."""
from integer_geometry import *
from osgeo import ogr
import datetime,json,pathlib,random,resource,time,hashlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
start=time.perf_counter()
resource.setrlimit(resource.RLIMIT_CPU,(30,30))
resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912))
polygons=[
 'POLYGON ((0 0,20 0,20 20,0 20,0 0),(8 8,12 8,12 12,8 12,8 8))',
 'POLYGON ((0 0,10 0,10 10,7 10,7 3,3 3,3 10,0 10,0 0))',
 'POLYGON ((0 0,11 2,15 14,3 18,-2 10,0 0),(3 5,6 5,7 8,2 9,3 5))'
]
count=0
rng=random.Random(900551)
for wkt in polygons:
    token_rings=read_wkt_rings(wkt)
    rings=[grid_points(ring,1) for ring in token_rings]
    assert validate_rings(rings)
    polygon=ogr.CreateGeometryFromWkt(wkt);assert polygon.IsValid()
    boundary=polygon.Boundary()
    points=[(rng.randint(-30,50),rng.randint(-30,50)) for i in range(600)]
    points += [p for r in rings for p in r]
    for a,b in list(zip(points,points[1:]))+[(p,p) for r in rings for p in r]:
        g=ogr.Geometry(ogr.wkbPoint if a==b else ogr.wkbLineString)
        for p in ([a] if a==b else [a,b]):g.AddPoint_2D(*p)
        ev=clearance(a,b,rings,1)
        assert ev['covered']==bool(g.Difference(polygon).IsEmpty()),(a,b,ev)
        assert abs(float(ev['q'])**0.5-g.Distance(boundary))<=1e-12,(a,b,ev)
        assert ev['route_witness']==ev['boundary_witness'] or sum((x-y)**2 for x,y in zip(ev['route_witness'],ev['boundary_witness']))==ev['q']
        assert between(ev['route_witness'],a,b)
        edge=rings[ev['ring']];c=edge[ev['edge']];d=edge[(ev['edge']+1)%len(edge)]
        assert between(ev['boundary_witness'],c,d)
        count+=1
qcases=[Fraction(0),Fraction(1),Fraction(2),Fraction(1,2),Fraction(1,10**40),Fraction(99999999999999999999999999999999999,10**15)]
for i in range(500):qcases.append(Fraction(rng.randint(0,10**40),rng.randint(1,10**35)))
for q in qcases:
    lo,hi=enclosing(q)
    assert lo*lo<=q<=hi*hi and hi-lo<=Fraction(1,10**12)
threshold_count=0
for m in ['0','.01','.05','.10','.25','.50']:
    t=1+Fraction(m)
    for gap in ['-.000000011','-.00000001','-.000000005','0','.000000005','.00000001','.000000011']:
        d=t+Fraction(gap)
        exact,conservative=labels(d*d,True,m)
        assert exact==(d>=t)
        expected='FAIL' if Fraction(gap)<-Fraction(1,10**8) else 'PASS' if Fraction(gap)>Fraction(1,10**8) else 'UNCERTAIN_THRESHOLD'
        assert conservative==expected
        assert labels(d*d,False,m)==(False,'FAIL')
        threshold_count+=1
# A decimal coordinate and its IEEE-754 representation are distinct exact numbers.
for token in ['0.1','481234.123456789123456789','5199999.999999999999']:
    decimal_exact=Fraction(token);binary_exact=Fraction.from_float(float(token))
    assert decimal_exact!=binary_exact
    lo,hi=enclosing((decimal_exact-binary_exact)**2)
    assert lo<=abs(decimal_exact-binary_exact)<=hi
result={'status':'PASS','synthetic_only':True,'no_author_module_import':True,'real_dataset_reads':False,'segment_point_geos_crosschecks':count,'square_root_interval_tests':len(qcases),'margin_boundary_tests':threshold_count,'exact_polygon_validity_examples':3,'coordinate_convention_examples':3,'random_seed':900551,'cpu_limit_seconds':30,'memory_limit_bytes':536870912,'wall_seconds':time.perf_counter()-start,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'code_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in pathlib.Path(__file__).parent.glob('*.py')}}
output=ROOT/'evidence/SYNTHETIC_INDEPENDENT.json'
with output.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result))
