#!/usr/bin/python3
"""Read-only report cross-check against independently verified saved results."""
import hashlib,json,pathlib,datetime,re
R=pathlib.Path(__file__).resolve().parents[1]
A=pathlib.Path('/workspace/shared/ee130_route_margin_sensitivity_20261008')
report=A/'reports/REPORT_zh.md';text=report.read_text()
ind=json.loads((R/'results/INDEPENDENT_SAVED_RECOMPUTATION.json').read_text())
saved=json.loads((A/'raw/results.json').read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def table(section,next_section):
    segment=text.split('## '+section+'\n',1)[1].split('## '+next_section+'\n',1)[0]
    lines=[l for l in segment.splitlines() if l.startswith('|')]
    return [[part.strip() for part in line.split('|')[1:-1]] for line in lines[2:]]
def label(iid):
    return iid.split('_s')[0]+' / '+iid[-4:]
summary_rows=table('六档完整结果','全部 12 个任务的端点上界')
assert len(summary_rows)==6
for row,s in zip(summary_rows,ind['summary']):
    tasks=s['task_status_counts'];routes=s['saved_route_status_counts'];combined=s['instance_method_combined_status_counts']
    expected=[s['extra_margin_m'],str(tasks.get('ENDPOINTS_CLEAR',0)),str(tasks.get('TASK_ENDPOINT_INFEASIBLE',0)),str(routes.get('PASS',0)),str(routes.get('FAIL',0)),str(combined.get('EXISTING_ROUTE_MARGIN_INSUFFICIENT',0))]
    assert row==expected,(row,expected)
task_rows=table('全部 12 个任务的端点上界','全部 8 条固定路线的几何极限')
assert len(task_rows)==12
for row,data in zip(task_rows,ind['tasks']):
    raw=json.loads((A/'raw'/f"{data['instance_id']}_endpoints.json").read_text())
    fmt=lambda values:', '.join(map(str,values)) if values else '无'
    interval=data['margin_interval']
    expected=[label(data['instance_id']),fmt(data['bottleneck_service_ids']),f"[{interval['lower_m']}, {interval['upper_m']}]",fmt(raw['conditions'][0]['failing_service_ids']),fmt(raw['conditions'][-1]['failing_service_ids'])]
    assert row==expected,(row,expected)
    assert all(raw['all_services'][0]['conditions'][i]['conservative_status']=='PASS' for i in range(6))
route_rows=table('全部 8 条固定路线的几何极限','几何和数值口径')
assert len(route_rows)==8
for row,data in zip(route_rows,ind['routes']):
    raw=json.loads((A/'raw'/f"{data['instance_id']}_{data['method']}_margins.json").read_text())
    w=raw['fixed_route_minimum']['witness'];interval=data['margin_interval']
    expected=[label(data['instance_id']),'NN' if data['method']=='nearest_neighbor' else '2-opt',f"[{interval['lower_m']}, {interval['upper_m']}]",', '.join(map(str,data['bottleneck_segment_indices'])),f"{w['ring_index']} / {w['edge_index']}",'/'.join('通过' if c['conservative_status']=='PASS' else '失败' if c['conservative_status']=='FAIL' else '不确定' for c in raw['conditions'])]
    assert row==expected,(row,expected)
for filename,key,count in [('all_72_task_conditions.json','task_conditions',72),('all_48_saved_route_conditions.json','existing_route_conditions',48),('all_144_instance_method_conditions.json','all_instance_method_conditions',144)]:
    data=json.loads((A/'reports'/filename).read_text())
    assert data==saved[key] and len(data)==count
special=json.loads((A/'raw/n20_s202610081001_endpoints.json').read_text())
assert special['conditions'][-1]['failing_service_ids']==[15] and special['conditions'][0]['failing_service_ids']==[]
assert saved['boundary_binary64_conversion_error']['lower_m']=='0.000000000466'
assert saved['boundary_binary64_conversion_error']['upper_m']=='0.000000000467'
assert saved['original_edge_count']==141 and saved['unique_service_points']==123 and saved['unique_route_segments']==92
for required in ['仅代表路径存在的必要条件','不是任务全局可行性的精确极限','不能据此否定替代路径','不是车辆验证','不能当作 12 个独立环境','属于后验敏感性，不是盲测或统计验证','没有给定或估计实际定位、测量或控制误差']:
    assert required in text,required
resources=json.loads((A/'evidence/RUN_STATUS.json').read_text())
for value in [f"{resources['children_cpu_seconds']:.6f}",f"{resources['wall_seconds']:.6f}",str(resources['children_peak_rss_kib']),f"{ind['resources']['cpu_seconds']:.6f}",f"{ind['resources']['wall_seconds']:.6f}"]:
    assert value in text
assert '6.50143456e-10' in text
result={'status':'PASS_AUTHOR_REPORT_READ_ONLY_REVIEW','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'report_path':str(report),'report_sha256':sha(report),'report_bytes':report.stat().st_size,'report_jsons_sha256':{p.name:sha(p) for p in (A/'reports').glob('*.json')},'summary_rows_verified':6,'endpoint_interval_bottleneck_and_failing_id_rows_verified':12,'fixed_route_interval_bottleneck_edge_and_status_rows_verified':8,'condition_counts_verified':[72,48,144],'all_depots_pass_all_six_margins':True,'new_half_meter_endpoint_failure_verified':'n20_s202610081001 service 15 only','coordinate_binary64_boundary_and_discrepancy_checked':True,'resources_and_main_vs_review_separation_checked':True,'inference_limits_checked':True,'no_author_file_changed':True,'review_source_sha256':sha(pathlib.Path(__file__)),'remaining_findings':[]}
with (R/'evidence/AUTHOR_REPORT_TEXT_REVIEW.json').open('x') as f:json.dump(result,f,indent=2,ensure_ascii=False);f.write('\n')
print(json.dumps(result,ensure_ascii=False))
