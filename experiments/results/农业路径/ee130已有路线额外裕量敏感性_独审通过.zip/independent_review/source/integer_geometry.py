"""Independent decimal-grid implementation. No author-module imports or route generation.
Integer orientation, winding number and cross-product projection distances are primary;
Fractions are used for exact quotients and intersection witnesses only.
"""
from decimal import Decimal
from fractions import Fraction
from math import isqrt
import re

def decimal_places(value):
    return max(0, -Decimal(str(value)).as_tuple().exponent)

def grid_points(points, scale):
    output = []
    for p in points:
        q = tuple(Fraction(str(v)) * scale for v in p)
        assert all(v.denominator == 1 for v in q)
        output.append(tuple(v.numerator for v in q))
    return output

def read_wkt_rings(text):
    assert text.strip().upper().startswith('POLYGON')
    result = []
    for contents in re.findall(r'\(([^()]+)\)', text):
        ring = [tuple(pair.split()) for pair in contents.split(',')]
        assert all(len(p) == 2 for p in ring) and ring[0] == ring[-1]
        result.append(ring[:-1])
    assert result
    return result

def orient(a, b, c):
    return (b[0]-a[0])*(c[1]-a[1]) - (b[1]-a[1])*(c[0]-a[0])

def between(p, a, b):
    return orient(a,b,p) == 0 and all(min(a[k],b[k]) <= p[k] <= max(a[k],b[k]) for k in (0,1))

def ring_position(p, ring):
    winding = 0
    for i, a in enumerate(ring):
        b = ring[(i+1) % len(ring)]
        turn = orient(a,b,p)
        if turn == 0 and between(p,a,b):
            return 0
        if a[1] <= p[1] < b[1] and turn > 0:
            winding += 1
        elif b[1] <= p[1] < a[1] and turn < 0:
            winding -= 1
    return 1 if winding else -1

def field_position(p, rings):
    return ring_position(p,rings[0]) >= 0 and all(ring_position(p,r) <= 0 for r in rings[1:])

def line_hits(a,b,c,d):
    """Return exact parameter(s) on first closed segment for its intersection."""
    ux,uy = b[0]-a[0],b[1]-a[1]
    vx,vy = d[0]-c[0],d[1]-c[1]
    denominator = ux*vy - uy*vx
    if denominator:
        t = Fraction((c[0]-a[0])*vy - (c[1]-a[1])*vx, denominator)
        s = Fraction((c[0]-a[0])*uy - (c[1]-a[1])*ux, denominator)
        return [t] if 0 <= t <= 1 and 0 <= s <= 1 else []
    if a == b:
        return [Fraction(0)] if between(a,c,d) else []
    if orient(a,b,c) != 0:
        return []
    k = 0 if ux != 0 else 1
    w = b[k]-a[k]
    p,q = sorted((Fraction(c[k]-a[k], w),Fraction(d[k]-a[k], w)))
    left,right = max(p,0),min(q,1)
    return [left,right] if left <= right else []

def interpolation(a,b,t):
    return tuple(a[k] + t*(b[k]-a[k]) for k in (0,1))

def nearest_point(point,a,b):
    ux,uy = b[0]-a[0],b[1]-a[1]
    wx,wy = point[0]-a[0],point[1]-a[1]
    norm2 = ux*ux + uy*uy
    projection = ux*wx + uy*wy
    if projection <= 0 or norm2 == 0:
        return Fraction(wx*wx+wy*wy),a
    if projection >= norm2:
        dx,dy = point[0]-b[0],point[1]-b[1]
        return Fraction(dx*dx+dy*dy),b
    area = ux*wy-uy*wx
    return Fraction(area*area,norm2),interpolation(a,b,Fraction(projection,norm2))

def segment_squared(a,b,c,d):
    hits = line_hits(a,b,c,d)
    if hits:
        p = interpolation(a,b,hits[0])
        return Fraction(0),p,p
    alternatives = []
    for p in (a,b):
        q,r = nearest_point(p,c,d)
        alternatives.append((q,p,r))
    for p in (c,d):
        q,r = nearest_point(p,a,b)
        alternatives.append((q,r,p))
    return min(alternatives,key=lambda item:item[0])

def edges(rings):
    return [(ri,i,p,ring[(i+1)%len(ring)]) for ri,ring in enumerate(rings) for i,p in enumerate(ring)]

def contained(a,b,rings,boundary=None):
    if not field_position(a,rings) or not field_position(b,rings):
        return False
    cuts = {Fraction(0),Fraction(1)}
    for ri,ei,c,d in boundary if boundary is not None else edges(rings):
        cuts.update(line_hits(a,b,c,d))
    ordered = sorted(cuts)
    return all(field_position(interpolation(a,b,(l+r)/2),rings) for l,r in zip(ordered,ordered[1:]))

def clearance(a,b,rings,scale,boundary=None):
    border = boundary if boundary is not None else edges(rings)
    candidates = []
    for ri,ei,c,d in border:
        q,rp,bp = segment_squared(a,b,c,d)
        candidates.append((q,ri,ei,rp,bp))
    best = min(candidates,key=lambda item:item[0])
    return {'q':best[0]/(scale*scale),'covered':contained(a,b,rings,border),
            'ring':best[1],'edge':best[2],
            'route_witness':tuple(Fraction(x,scale) for x in best[3]),
            'boundary_witness':tuple(Fraction(x,scale) for x in best[4])}

def enclosing(q,shift=Fraction(0),precision=12):
    m=10**precision
    k=isqrt(q.numerator*m*m//q.denominator)
    lo=Fraction(k,m)
    hi=lo if lo*lo == q else Fraction(k+1,m)
    assert lo*lo <= q <= hi*hi
    return lo-shift,hi-shift

def labels(q,covered,margin):
    radius=1+Fraction(margin)
    tau=Fraction(1,10**8)
    exact=covered and q >= radius*radius
    conservative=('FAIL' if not covered or q < (radius-tau)**2 else
                  'PASS' if q > (radius+tau)**2 else 'UNCERTAIN_THRESHOLD')
    return exact,conservative

def validate_rings(rings):
    """Exact basic polygon validity for simple, non-touching holes."""
    boundary=edges(rings)
    for ring in rings:
        assert len(ring)>=3 and len(set(ring))==len(ring)
        assert sum(a[0]*ring[(i+1)%len(ring)][1]-a[1]*ring[(i+1)%len(ring)][0] for i,a in enumerate(ring)) != 0
    for j,(ri,ei,a,b) in enumerate(boundary):
        for rj,ej,c,d in boundary[j+1:]:
            adjacent=(ri==rj and ((ei-ej)%len(rings[ri]) in (1,len(rings[ri])-1)))
            hits=line_hits(a,b,c,d)
            if adjacent:
                assert a==d or b==c or a==c or b==d
                assert not (len(hits)>1 and hits[0]!=hits[-1]), 'overlapping adjacent edges'
            else:
                assert not hits, 'nonadjacent intersecting edges'
    for i,hole in enumerate(rings[1:],1):
        assert ring_position(hole[0],rings[0])==1
        assert all(ring_position(hole[0],other)==-1 for j,other in enumerate(rings[1:],1) if j!=i)
    return True
