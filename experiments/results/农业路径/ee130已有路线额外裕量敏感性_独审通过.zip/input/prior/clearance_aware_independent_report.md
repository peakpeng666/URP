# Independent review: fixed-task 1 m clearance-aware routes

Verdict: **PASS_INDEPENDENT_SAVED_RESULT_AUDIT**. This accepts the integrity and stated geometry of the saved experiment, including eight correctly retained endpoint-infeasible instances. It does not mean all twelve task sets were feasible.

## Full denominator and outcomes

All 12 original instance files, each original depot, and the original field with three holes were preserved byte-for-byte. There are four route-feasible instances (eight saved routes) and eight task-infeasible instances (no routes). None was resampled, relocated, dropped, or replaced.

| Instance | Independently verified status | Failing original task IDs |
|---|---|---|
| n08_s202610081001 | VALID_SAFE_ROUTES | None |
| n08_s202610081002 | VALID_SAFE_ROUTES | None |
| n08_s202610081003 | TASK_INFEASIBLE | 5, 8 |
| n12_s202610081001 | VALID_SAFE_ROUTES | None |
| n12_s202610081002 | TASK_INFEASIBLE | 10 |
| n12_s202610081003 | TASK_INFEASIBLE | 5, 8, 9 |
| n20_s202610081001 | VALID_SAFE_ROUTES | None |
| n20_s202610081002 | TASK_INFEASIBLE | 10 |
| n20_s202610081003 | TASK_INFEASIBLE | 5, 8, 9 |
| n40_s202610081001 | TASK_INFEASIBLE | 27 |
| n40_s202610081002 | TASK_INFEASIBLE | 10 |
| n40_s202610081003 | TASK_INFEASIBLE | 5, 8, 9, 32 |

## Saved safe routes

The displayed values below are rounded for readability only. Acceptance used exact rational squared-distance comparisons before rounding, against (1 + 1e-8 m)².

| Instance | Method | Length (m) | Minimum original-field boundary clearance (m) |
|---|---|---:|---:|
| n08_s202610081001 | nearest_neighbor | 326.634108639 | 3.356188299534 |
| n08_s202610081001 | nn_2opt_budget | 290.614110966 | 3.356188299534 |
| n08_s202610081002 | nearest_neighbor | 379.830998579 | 1.003614401517 |
| n08_s202610081002 | nn_2opt_budget | 377.300400894 | 1.003614401496 |
| n12_s202610081001 | nearest_neighbor | 504.116133055 | 1.002651194998 |
| n12_s202610081001 | nn_2opt_budget | 438.136067416 | 1.221047943239 |
| n20_s202610081001 | nearest_neighbor | 743.493917882 | 1.002651194998 |
| n20_s202610081001 | nn_2opt_budget | 589.030025185 | 1.003716429256 |

The lowest verified route clearance is approximately 1.002651194998 m. The safety excess over the assumed 1 m disk radius can therefore be only about 2.65 mm; this is a statement about the serialized model, not real-world localization, surveying, tracking, or safety margins.

## Independent method

No author modules were imported and no alternate route or actual experiment was generated. The reviewer read original WKT decimal tokens and saved JSON decimal tokens exactly as integer coordinates on a 10^-20 m grid (with an integrality check). It used:

- Exact integer segment intersections and winding containment tests
- Exact rational squared minimum distance for every original outer/hole edge, using the four endpoint/segment projections after intersection rejection
- Exact comparisons to both radius tolerance-band boundaries
- A full-segment containment argument: an interior start and strictly positive distance to every boundary edge prevent the connected segment from exiting the field or entering a hole
- Saved graph edge/path/coordinate checks, separately implemented Dijkstra distances on the saved graph, NN decision verification and reconstruction of the submitted 2opt route solely from its saved accepted moves and candidate-position evidence
- Full route reconstruction from all service legs, one scheduled service per original task, depot closure and independently recalculated lengths
- Whole saved center-region checks using a fresh OGR load, in addition to exact independent certification of the actual routes

The exact checks cover 123 unique service points, 161 complete segment uses and 92 unique segments against all 141 original edges (84 outer; holes 21, 30 and 6). All eight routes are wholly contained, all three holes are excluded, every task is scheduled exactly once, and every route closes at its own original depot. The maximum difference between exact-token distances and the author binary64 results is about 6.502e-10 m, below the frozen 1e-8 m tolerance.

The saved 2opt evidence remains within 10000 candidate reversals; accepted move costs and scan positions match, and within each new graph its submitted route is no longer than NN. This review does not claim global optimality. Rejected 2opt candidates were not re-optimized during review; frozen source equivalence and the saved trace are the implementation evidence.

## Integrity, resources, and archive

All 54 frozen entries match, all 41 original identity references match, and all raw files remained unchanged during the review. The only recorded formal run exited 0 in 13.802504493 wall seconds and 13.789128 CPU seconds, with 63696 KiB peak RSS. The wrapper sets the frozen 300 s CPU, 600 s wall and 1 GiB address-space limits. The independent saved-result check took about 1.49 s; its resource cost is separate.

The raw archive and its downloaded copy were independently re-hashed and byte-compared: both are 911922 bytes with SHA-256 fd8c3d35da50d9fa8c3df88abf2bd426c22b797e4a6c10c70c2acdc387878d4d. All 97 archived file members match current files; all 36 raw files are included. Remote owner-only permission is supported by the received private-upload receipt, not a fresh network check by this reviewer.

## Interpretation limits

- The old optimization used a 0 m centerline constraint; the new stage uses a fixed 1 m disk assumption. Old/new route-length changes are not pure algorithm improvements. Old lengths and old 1 m audit outcomes were preserved and checked for every one of the twelve instances.
- Within-new-instance NN versus 2opt uses the same saved graph and geometric constraint.
- The twelve task sets are nested prefixes of three random layouts on one field, not twelve independent environments.
- Endpoint failures establish infeasibility of those fixed task requirements under the assumed disk and given geometry. Conservative exclusion or finite-graph disconnection would not prove absence of a continuous feasible path; neither label occurred in this run.
- No exact theorem is claimed for GEOS q16 buffering. The buffer inflation was prespecified, and final safety evidence comes from saved-geometry posterior verification.
- No physical tractor geometry, turning, dynamics, orientation, survey accuracy, terrain or field execution is established.

## Evidence files

- INDEPENDENT_SAVED_RESULT_AUDIT.json: full 12-instance outcome, exact service evidence, resources and raw hashes
- INDEPENDENT_ROUTES_EXACT.json: exact rational distance witnesses for all 161 saved segment uses
- INDEPENDENT_CHECKS.json: 125709 recorded checks
- INDEPENDENT_ARCHIVE_IDENTITY.json: independently recomputed archive/member identity
- review_saved_results.py and INDEPENDENT_GEOMETRY_TOY.json: independent reviewer implementation and synthetic tests
- STATIC_PRECHECK_REPORT.md, STATIC_PRECHECK.json and SYNTHETIC_TOY_RECHECK.json: pre-execution read-only/source checks
