# Independent pre-execution review

Status: PASS_PREEXEC_STATIC_AND_SYNTHETIC

Static protocol/source precheck and independent synthetic-only tests; no real geometry distances or sensitivity outcomes recomputed. Frozen/raw remote receipts remain later gate requirements.

## Checks
- literal_decimal_coordinates_without_binary64_roundtrip: PASS: JSON parse_float=Decimal, WKT tokens to Fraction; prior EPSG interpretation inherited and survey truth disclaimed.
- binary64_secondary_comparison: PASS: exact conversion displacement bound, GEOS distance/containment check with frozen 1e-8 m tolerance; binary64 and stored decimals explicitly distinct.
- exact_segment_distance: PASS: exact intersections and endpoint projections cover every polygon edge; no sampling.
- exact_containment: PASS: exact ray parity and complete intersection-parameter partition; concavity, holes, collinearity and zero-length cases handled.
- closed_disk_threshold: PASS: contained AND q >= (1+margin)^2; mathematical tangency allowed.
- conservative_threshold_band: PASS: strict PASS above radius+1e-8, strict FAIL below radius-1e-8, closed uncertainty band including both boundaries.
- certified_interval: PASS: isqrt(floor(q*10^24)) brackets the root with rational squared checks and width <=1e-12 m; decimal display does not select labels.
- inference_limits: PASS: endpoint upper bound is necessary only, absent/failed saved route does not imply no alternative route, no vehicle/error-distribution/safety claim.
- denominators: PASS: 12 tasks x6=72 endpoint rows, 8 fixed routes x6=48 route rows, 12x2x6=144 method rows; nested 3-layout design disclosed.
- schedule_and_closure: PASS: ordered depot closure, service multiplicity, leg IDs/coordinates and saved length are asserted.
- gate_and_no_rerun: PASS STATIC: runner validates PREEXEC receipt and archive; child revalidates parent PID, archive/receipt, hard resource limits, empty raw directory and exclusive FORMAL_CHILD_ENTERED marker. Actual remote gate evidence is not yet available and must be checked later.
- resource_limits: PASS STATIC: child RLIMIT_CPU=120s, RLIMIT_AS=512MiB, parent wall timeout=180s, BLAS/OMP threads=1, one exclusive start.
- witness_direction: PASS: author corrected route_a/route_b to orientation-independent route_endpoint for undirected segment cache.
- dependencies_and_external_actions: PASS STATIC: no solver, model, installation or network call in formal calculation; imports use standard library plus preinstalled GDAL/GEOS.
- frozen_decimal_polygon_validity: FOLLOW-UP: formal author checks GEOS IsValid; independent post-run audit will additionally verify original rational rings are simple, mutually disjoint and holes inside outer ring.

## Synthetic evidence
Independent integer-grid/winding implementation: 1847 GEOS point/segment checks, 506 certified-root interval checks, 42 margin-band boundary checks, three exact-validity synthetic polygons, three decimal/binary64 distinction examples. All passed. No author module imported; no real geometric inputs opened by tests.

## Pending before independent result audit
- Author must seal PREEXEC, obtain verified private byte-identical readback, perform one formal run, then archive raw terminal evidence before releasing results for independent recomputation.
- Actual archive membership/hashes, remote readback/permissions, runtime limits/status, original decimal polygon validity and all saved outcomes remain to be verified after that release.
