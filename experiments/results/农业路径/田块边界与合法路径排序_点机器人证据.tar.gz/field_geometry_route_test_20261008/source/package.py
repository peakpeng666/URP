#!/usr/bin/env python3
"""Build and verify deterministic, content-addressed archive without altering frozen inputs."""
import gzip,hashlib,io,json,tarfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
files=sorted(p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='SHA256SUMS.txt')
manifest=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(ROOT))+'\n' for p in files)
(ROOT/'SHA256SUMS.txt').write_text(manifest)
files.append(ROOT/'SHA256SUMS.txt'); files.sort()
raw=io.BytesIO()
with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0,compresslevel=6) as gz:
    with tarfile.open(fileobj=gz,mode='w') as tar:
        for p in files:
            data=p.read_bytes(); info=tarfile.TarInfo(str(Path(ROOT.name)/p.relative_to(ROOT)))
            info.size=len(data); info.mtime=0; info.mode=0o644; info.uid=info.gid=0;info.uname=info.gname=''
            tar.addfile(info,io.BytesIO(data))
blob=raw.getvalue(); digest=hashlib.sha256(blob).hexdigest(); target=ROOT.parent/f'{ROOT.name}_{digest[:12]}.tar.gz'
if target.exists(): assert target.read_bytes()==blob
else: target.write_bytes(blob)
expected={str(Path(ROOT.name)/p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with tarfile.open(target,'r:gz') as tar:
    actual={m.name:hashlib.sha256(tar.extractfile(m).read()).hexdigest() for m in tar.getmembers()}
assert actual==expected
receipt={'archive_name':target.name,'archive_path':str(target),'sha256':digest,'bytes':len(blob),'members':len(files),'payload_hash_verification':'PASS','pre_run_hashes_verified':8,'archive_creation':'deterministic tar+gzip, timestamps normalized; content-addressed name; no claim of OS immutability'}
receipt_path=ROOT.parent/(target.name+'.receipt.json');receipt_path.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(receipt,ensure_ascii=False,indent=2))
