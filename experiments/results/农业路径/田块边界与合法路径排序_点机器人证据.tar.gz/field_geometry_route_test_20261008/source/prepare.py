#!/usr/bin/env python3
"""Construct all frozen synthetic integer orthogonal field inputs before solving."""
import hashlib, json, random
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def dump(p,x):
    p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')

def construct(family,seed,index):
    r=random.Random(seed)
    w=r.randint(60,100); h=r.randint(60,100)
    left=r.randint(w//5,w//3); right=w-r.randint(w//5,w//3)
    bottom=r.randint(h//5,h//3); top=h-r.randint(h//5,h//3)
    if family=='rectangle':
        vertices=[(0,0),(w,0),(w,h),(0,h)]
        rects=[(0,0,w,h)]
    elif family=='L':
        vertices=[(0,0),(w,0),(w,bottom),(left,bottom),(left,h),(0,h)]
        rects=[(0,0,w,bottom),(0,bottom,left,h)]
    elif family=='U':
        vertices=[(0,0),(w,0),(w,h),(right,h),(right,bottom),(left,bottom),(left,h),(0,h)]
        rects=[(0,0,w,bottom),(0,bottom,left,h),(right,bottom,w,h)]
    elif family=='H':
        vertices=[(0,0),(left,0),(left,bottom),(right,bottom),(right,0),(w,0),(w,h),(right,h),(right,top),(left,top),(left,h),(0,h)]
        rects=[(0,0,left,h),(right,0,w,h),(left,bottom,right,top)]
    else: raise ValueError(family)
    depot=(1,1); tasks=[]; draws=[]
    while len(tasks)<7:
        p=(r.randint(1,w-1),r.randint(1,h-1))
        accepted=any(x0<=p[0]<=x1 and y0<=p[1]<=y1 for x0,y0,x1,y1 in rects) and p!=depot and p not in tasks
        draws.append({'point':p,'accepted':accepted})
        if accepted: tasks.append(p)
    return {'instance_id':f'{family}_{index:02d}','family':family,'base_field_id':f'{family}_{index:02d}',
            'seed':seed,'dimensions':{'width':w,'height':h,'left':left,'right':right,'bottom':bottom,'top':top},
            'polygon':vertices,'rectangle_decomposition':rects,'depot':depot,'tasks':tasks,'sampling_draws':draws}

if __name__=='__main__':
    cfg=json.loads((ROOT/'freeze.json').read_text())
    instances=[construct(f,cfg['master_seed']+100*fi+i,i) for fi,f in enumerate(cfg['families']) for i in range(4)]
    dump(ROOT/'instances.json',instances)
    print('Prepared all 16 inputs; no path graph or route objectives evaluated.')
