#!/usr/bin/env python3
"""Create frozen-sample descriptive summaries and Chinese figures from saved outputs."""
import csv,json,os,statistics,time
from pathlib import Path
os.environ.setdefault('MPLCONFIGDIR','/tmp/field_geometry_mpl')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
from matplotlib.patches import Polygon as PatchPolygon
ROOT=Path(__file__).resolve().parents[1]
FONT=FontProperties(fname='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
plt.rcParams.update({'font.family':FONT.get_name(),'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'savefig.facecolor':'white'})
# Explicit font registration guarantees this file is available independent of font cache.
from matplotlib import font_manager
font_manager.fontManager.addfont(FONT.get_file()); plt.rcParams['font.family']=FONT.get_name()
insts=json.loads((ROOT/'instances.json').read_text()); results=[json.loads((ROOT/'raw'/f"{i['instance_id']}.json").read_text()) for i in insts]
by_id={x['instance_id']:x for x in results}
colors={'rectangle':'#8296A8','L':'#467EA5','U':'#DB9C36','H':'#AB6C93'}
labels={'rectangle':'矩形负对照','L':'L形','U':'U形','H':'H形','concave':'凹形合计','all':'全部田块'}
summary=[]
for family in ['rectangle','L','U','H','concave','all']:
    rows=[x for x in results if family=='all' or x['family']==family or (family=='concave' and x['family']!='rectangle')]
    s={'group':family,'n_base_fields':len(rows),'n_failures':0,'fields_with_illegal_direct_legs':sum(x['euclidean_order_solution']['direct_illegal_leg_count']>0 for x in rows),
       'illegal_direct_legs':sum(x['euclidean_order_solution']['direct_illegal_leg_count'] for x in rows),'total_direct_legs':8*len(rows),
       'fields_with_positive_order_penalty':sum(x['absolute_cost_penalty']>1e-9 for x in rows),
       'mean_order_penalty_pct':statistics.mean(100*x['relative_cost_penalty'] for x in rows),
       'median_order_penalty_pct':statistics.median(100*x['relative_cost_penalty'] for x in rows),
       'max_order_penalty_pct':max(100*x['relative_cost_penalty'] for x in rows),
       'mean_legal_repair_increase_pct':statistics.mean(100*(x['repaired_euclidean_order_cost']/x['euclidean_objective']-1) for x in rows)}
    summary.append(s)
(ROOT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
with (ROOT/'summary.csv').open('w') as f:
    w=csv.DictWriter(f,summary[0].keys());w.writeheader();w.writerows(summary)

# Figure 1 keeps each independent field visible; no selected-only or family-only plot.
fig,axes=plt.subplots(1,2,figsize=(13,8.2),gridspec_kw={'width_ratios':[1,1.2]})
y=list(range(16)); row_colors=[colors[r['family']] for r in results]
axes[0].barh(y,[100*r['euclidean_order_solution']['direct_illegal_leg_fraction'] for r in results],color=row_colors,height=.65)
axes[1].barh(y,[100*r['relative_cost_penalty'] for r in results],color=row_colors,height=.65)
for ax in axes:
    ax.set_yticks(y,[r['instance_id'] for r in results]);ax.invert_yaxis();ax.set_axisbelow(True);ax.grid(axis='x',alpha=.2)
    for line in [3.5,7.5,11.5]: ax.axhline(line,color='#DDE1E5',lw=.8)
axes[0].set_xlim(0,43);axes[0].set_xlabel('越界直线腿占比（每条路线共8腿，%）');axes[0].set_title('问题一：直线成本可能低估合法路程',pad=15)
axes[1].set_xlim(0,4.6);axes[1].set_xlabel('修复欧氏顺序 / 合法距离最优 − 1（%）');axes[1].set_title('问题二：补成合法腿后，访问顺序仍可能次优',pad=15)
for k,r in enumerate(results):
    v=100*r['euclidean_order_solution']['direct_illegal_leg_fraction'];axes[0].text(v+.6,k,f"{r['euclidean_order_solution']['direct_illegal_leg_count']}/8",va='center',fontsize=10)
    v=100*r['relative_cost_penalty'];axes[1].text(v+.07,k,f'{v:.3f}%',va='center',fontsize=10)
fig.suptitle('田块内路径距离影响路线可行性，也可能改变多任务访问顺序',fontsize=17,fontweight='bold',y=.97)
fig.text(.5,.91,'12块凹形：17/96条直线腿越界；修复后的顺序损失均值0.825%，最大3.803%；4块矩形均为0',ha='center',fontsize=11)
fig.text(.5,.025,'全部为新建合成田块｜K=1点机器人、7个任务、闭合巡回｜边界可接触、无buffer｜每块全枚举5040顺序｜非真实农机效果',ha='center',fontsize=10,color='#555555')
fig.subplots_adjust(left=.11,right=.96,bottom=.13,top=.83,wspace=.36)
fig.savefig(ROOT/'summary_zh.png',dpi=160);plt.close(fig)

def base(ax,i):
    ax.add_patch(PatchPolygon(i['polygon'],closed=True,facecolor='#EDF3E7',edgecolor='#526547',lw=1.3))
    pts=[i['depot']]+i['tasks'];ax.scatter(*zip(*pts[1:]),c='#223344',s=24,zorder=5)
    ax.scatter(*pts[0],c='#102D4D',marker='s',s=45,zorder=6)
    for j,(x,y) in enumerate(pts): ax.annotate('D' if j==0 else str(j),(x,y),xytext=(4,4),textcoords='offset points',fontsize=8,zorder=6)
    ax.set_aspect('equal');ax.set_xlim(-6,i['dimensions']['width']+6);ax.set_ylim(-6,i['dimensions']['height']+6)
    ax.set_xticks([]);ax.set_yticks([])
    for s in ax.spines.values(): s.set_visible(False)

def draw_polyline(ax,pts,color,lw=2):
    ax.plot(*zip(*pts),color=color,lw=lw,zorder=3)

fig,axes=plt.subplots(4,4,figsize=(12,12))
for ax,i,r in zip(axes.flat,insts,results):
    base(ax,i); draw_polyline(ax,r['geodesic_order_solution']['legal_polyline'],'#247B6A',1.8)
    ax.set_title(f"{i['instance_id']}  |  顺序损失 {100*r['relative_cost_penalty']:.3f}%",fontsize=10)
fig.suptitle('全部16个独立基础田块与合法距离最优路线',fontsize=17,y=.985,fontweight='bold')
fig.text(.5,.02,'固定seed、完整保留零效果样本；D为仓点，1–7为指定服务点。图示是点机器人路径，允许贴边转向。',ha='center',fontsize=10)
fig.subplots_adjust(left=.02,right=.98,bottom=.06,top=.94,hspace=.2,wspace=.1)
fig.savefig(ROOT/'all_fields_zh.png',dpi=160);plt.close(fig)

# Preregistered example U_00, irrespective of which instance has the largest effect.
i=next(i for i in insts if i['instance_id']=='U_00');r=by_id['U_00'];fig,axes=plt.subplots(1,3,figsize=(14,5.7))
for ax in axes: base(ax,i)
stops=r['euclidean_order_solution']['stops'];sp=r['services'];illegal=r['euclidean_order_solution']['direct_illegal_legs']
for a,b in zip(stops,stops[1:]):
    bad=[a,b] in illegal;axes[0].plot(*zip(sp[a],sp[b]),color='#C84343' if bad else '#467EA5',ls='--' if bad else '-',lw=2,zorder=3)
draw_polyline(axes[1],r['euclidean_order_solution']['legal_polyline'],'#CF9034')
draw_polyline(axes[2],r['geodesic_order_solution']['legal_polyline'],'#247B6A')
titles=[f"欧氏最优顺序，直接连线\n{r['euclidean_objective']:.3f}（含越界，不能执行）",f"保持同一顺序，逐腿修复\n{r['repaired_euclidean_order_cost']:.3f}（合法）",f"按合法距离重排\n{r['geodesic_optimal_cost']:.3f}（合法最优）"]
for ax,title in zip(axes,titles): ax.set_title(title,fontsize=12,pad=12)
fig.suptitle('固定展示 U_00：几何修复与顺序优化是两个不同步骤',fontsize=17,y=.99,fontweight='bold')
fig.text(.5,.04,f"固定例，非挑选最大效果：补成合法腿 +{100*(r['repaired_euclidean_order_cost']/r['euclidean_objective']-1):.2f}%；欧氏顺序相对合法最优仍多 {100*r['relative_cost_penalty']:.3f}%。\n合成任意长度单位；不含农机车宽、最小转弯半径、地头与作物限制。",ha='center',fontsize=10)
fig.subplots_adjust(left=.03,right=.97,bottom=.18,top=.81,wspace=.11)
fig.savefig(ROOT/'route_example_U00_zh.png',dpi=160);plt.close(fig)
(ROOT/'evidence/illustration_selection.json').write_text(json.dumps({'overview':'All 16 fields in frozen order','detail':'U_00','selection_rule':'Specified before any route results; not maximum or selected on significance'},ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))
