#!/usr/bin/env python3
import datetime,json,resource,subprocess,sys,time
from pathlib import Path
r=Path(__file__).resolve().parents[1]; start=time.perf_counter(); utc=datetime.datetime.now(datetime.timezone.utc).isoformat()
try:
    with (r/'evidence/run.log').open('w') as f:
        p=subprocess.run([sys.executable,str(r/'source/experiment.py')],cwd=r,stdout=f,stderr=subprocess.STDOUT,timeout=120)
    code=p.returncode; expired=False
except subprocess.TimeoutExpired:
    code=-9; expired=True
usage=resource.getrusage(resource.RUSAGE_CHILDREN)
out={'start_utc':utc,'exit_code':code,'external_wall_seconds':time.perf_counter()-start,'child_user_cpu_seconds':usage.ru_utime,'child_system_cpu_seconds':usage.ru_stime,'child_total_cpu_seconds':usage.ru_utime+usage.ru_stime,'max_rss_kib':usage.ru_maxrss,'wall_timeout_seconds':120,'timeout':expired}
(r/'evidence/launch_status.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n'); (r/'evidence/exit_code.txt').write_text(str(code)+'\n')
print(json.dumps(out)); sys.exit(0 if code==0 else 1)
