#!/usr/bin/env python3
import json
from fractions import Fraction as F
from pathlib import Path
from geometry import covered_point,covered_segment,validate_polygon
from independent_geometry import point_in_union,segment_in_union
ROOT=Path(__file__).resolve().parents[1]
R=[(0,0),(6,0),(6,6),(0,6)]; RR=[(0,0,6,6)]
L=[(0,0),(6,0),(6,2),(2,2),(2,6),(0,6)]; LR=[(0,0,6,2),(0,2,2,6)]
U=[(0,0),(6,0),(6,6),(4,6),(4,2),(2,2),(2,6),(0,6)]; UR=[(0,0,6,2),(0,2,2,6),(4,2,6,6)]
tests=[('rectangle diagonal',R,RR,(0,0),(6,6),True),
('rectangle boundary',R,RR,(0,0),(6,0),True),
('rectangle exterior',R,RR,(-1,0),(6,0),False),
('zero on boundary',R,RR,(0,0),(0,0),True),
('zero outside',R,RR,(-1,0),(-1,0),False),
('L notch crossing',L,LR,(1,5),(5,1),False),
('L reflex contact',L,LR,(0,4),(4,0),True),
('L boundary collinear',L,LR,(2,2),(2,6),True),
('L extension outside',L,LR,(2,2),(5,5),False),
('L narrow exact outside',L,LR,(0,4),(4,F(1,1000000)),False),
('L outside endpoint exact',L,LR,(0,4),(4,F(-1,1000000)),False),
('L narrow exact inside',L,LR,(0,F(3999999,1000000)),(4,0),True),
('U arm crossing',U,UR,(1,5),(5,5),False),
('U bottom notch boundary',U,UR,(1,2),(5,2),True),
('U exterior notch one epsilon',U,UR,(1,F(2000001,1000000)),(5,F(2000001,1000000)),False),
('U interior epsilon',U,UR,(1,F(1999999,1000000)),(5,F(1999999,1000000)),True),
('U full opposite vertex crossing',U,UR,(0,6),(6,6),False),
('U reverse boundary',U,UR,(4,2),(2,2),True)]
results=[]
for name,p,r,a,b,expected in tests:
    x=covered_segment(a,b,p); y=segment_in_union(a,b,r)
    assert x==y==expected,(name,x,y,expected)
    assert covered_segment(b,a,p)==expected
    results.append({'name':name,'expected':expected,'primary':x,'independent':y,'pass':True})
# Dense exact test lattice includes integer, half-integer and boundary pairs.
counts={}; total=0
for name,p,r in [('rectangle',R,RR),('L',L,LR),('U',U,UR)]:
    validate_polygon(p)
    points=[(F(i,2),F(j,2)) for i in range(-1,14) for j in range(-1,14)]
    for q in points: assert covered_point(q,p)==point_in_union(q,r)
    # Fixed 30-by-30 deterministic subset, not sampled after findings.
    selected=points[::8]
    n=0
    for a in selected:
        for b in selected:
            assert covered_segment(a,b,p)==segment_in_union(a,b,r),(name,a,b)
            n+=1
    counts[name]={'point_checks':len(points),'segment_checks':n}; total+=n
out={'status':'PASS','targeted_segment_tests':results,'dense_lattice_checks':counts,'dense_segment_checks_total':total,'feasibility_tolerance':0,'buffer_used':False}
(ROOT/'evidence'/'precheck.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(out,ensure_ascii=False))
