"""Explicitly invented JSON-only denominator test; no native or saved new results."""
from pathlib import Path
import json,sys,copy,resource,signal
from seed_summary import summarize
from original_primitives import ROOT
from evidence_primitives import equal
sys.path.insert(0,str(ROOT/'source'))
from report_core import build_summary


def main():
    resource.setrlimit(resource.RLIMIT_CPU,(15,15));resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912));signal.alarm(60)
    fields=json.loads((ROOT/'design/SEED_REPLICATION_PRECOMMIT.json').read_text())['fields'];rows=[]
    for f in fields:
        for p in ('E','G'):
            for s in range(3):
                for a in ('A','P'):
                    row={k:None for k in ('routing_violation','base_E','base_G','normalized_own_cost','own_gap_mm','own_gap_percent','exact_hit','G_realized_excess_mm','E_offset_from_lex_reference_mm','E_optimal_tie_difference_mm','exact_proxy_reference_delta_mm','observations','input_readiness_status')}
                    row.update(call_id=f'{f}_{p}_s{s}_{a}_i250',instance_id=f,proxy=p,seed=s,arm=a,scale=1,max_iterations=250,
                        valid=False,record_verified=False,own_reference_verified=False,process_spawned=False,
                        raw_status='NOT_STARTED_SUPERVISOR_FAILURE',failure_class='NOT_STARTED_SUPERVISOR_FAILURE')
                    rows.append(row)
    equal(summarize(rows,fields),build_summary(rows,fields),'all1488 unknown or missing')
    ix={(r['instance_id'],r['proxy'],r['seed'],r['arm']):r for r in rows}
    for field,seed,a_cost,p_cost in [(fields[0],0,100,90),(fields[0],1,100,110),(fields[1],0,200,210)]:
        for arm,cost in [('A',a_cost),('P',p_cost)]:
            row=ix[field,'E',seed,arm]
            row.update(valid=True,record_verified=True,routing_violation=False,process_spawned=True,
                base_E=cost,base_G=cost,normalized_own_cost=cost,raw_status='UNREVIEWED_PROCESS_SUCCESS',failure_class='VALID_FEASIBLE',
                observations={'initial_solution_feasible':True,'source_prediction_current_feasible_all250_observed':True})
    row=ix[fields[0],'G',2,'A'];row.update(record_verified=True,routing_violation=True,process_spawned=True,raw_status='UNREVIEWED_INFEASIBLE',failure_class='VERIFIED_NATIVE_INFEASIBLE')
    row=ix[fields[0],'E',0,'P'];row.update(own_reference_verified=True,own_gap_mm=0,own_gap_percent=0.,exact_hit=True)
    row=ix[fields[0],'E',1,'P'];row.update(own_reference_verified=True,own_gap_mm=10,own_gap_percent=10.,exact_hit=False)
    out=summarize(rows,fields);equal(out,build_summary(rows,fields),'invented mixed3seed field data')
    cross=out['secondary_cross_G_on_E_pairs'];assert (cross['positive'],cross['zero'],cross['negative'])==(2,0,1)
    assert cross['equal_field_weight']['conditional_equal_field_mean_mm']==5
    assert cross['summary']['conditional_mean']==10/3 and cross['equal_field_weight']['complete_panel_equal_field_mean_mm'] is None
    assert out['field_level_summary']['E']['P']['count_distributions']['confirmed_exact_hits']['1']==1
    assert out['field_level_summary']['G']['A']['count_distributions']['verified_native_infeasible']['1']==1
    assert not any(x=='pyvrp' or x.startswith('pyvrp.') for x in sys.modules)
    record={'status':'PASS','fixtures':'Invented JSON only; actual field IDs for fixed124 denominator, no matrices/output/route search',
        'tests':['all1488 missing retained','native infeasible distinct from technical missing','exact hit/nonhit/unscored separate','field equal weighting differs from pooled pair weighting','all372 required for complete E mean','positive/zero/negative pair signs'],
        'new_native_calls':0,'new_solver_calls':0,'new_exact_computations':0}
    path=ROOT/'independent_supervision/preparation/SEED_SUMMARY_CONTRACT.json';assert not path.exists();path.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))


if __name__=='__main__':main()
