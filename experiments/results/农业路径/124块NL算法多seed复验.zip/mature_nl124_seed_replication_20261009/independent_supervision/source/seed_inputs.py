"""Independent frozen input/reference binding, with no native or search imports."""
from unseen_contract import *
INPUT_SHA='163618b1280131105a1de43dfe4825886baaa716810e970a16c9dde58140c987'
INPUT_FREEZE='43a3a05519bbfa4689a071e1dc71e44c86585c2f215ead4319a8318f708e05ef'
SCIENCE_SHA='4dbd4f75d3acf8a5354104bec7b611073f3aff3a5d1a3f611f40ec309d3f8e94'
PRECOMMIT_SHA='b4aac52014276b42870332fb4bab6f7abe15a740e280059c7c0480aa8db8db4b'


def source_inputs():
    require(sha(ROOT/'freeze/PRECOMMIT_LOCK.json')==PRECOMMIT_SHA,'original repeated-seed precommit')
    for rel,meta in load(ROOT/'freeze/PRECOMMIT_LOCK.json')['files'].items():
        require((ROOT/rel).stat().st_size==meta['bytes'] and sha(ROOT/rel)==meta['sha256'],'precommit unchanged')
    protocol=load(ROOT/'freeze/PROTOCOL.json');fields=protocol['fields'];require(len(fields)==len(set(fields))==124,'registered124 fields')
    require(sha(ROOT/'freeze/SCIENTIFIC_POLICY_LOCK.json')==SCIENCE_SHA,'pre-input original method and repeated-seed implementation lock')
    for rel,meta in load(ROOT/'freeze/SCIENTIFIC_POLICY_LOCK.json')['files'].items():
        path=ROOT/rel;require(path.stat().st_size==meta['bytes']and sha(path)==meta['sha256'],'scientific member')
    binding=load(ROOT/'upstream_identity/FINAL_INPUT_PACKAGE_IDENTITY.json')
    require(binding['upstream_final_archive_sha256']==INPUT_SHA and binding['upstream_frozen_files_sha256']==INPUT_FREEZE,'same input FINAL')
    require(binding['scientific_policy_lock_sha256']==SCIENCE_SHA,'source extraction science identity')
    for rel,meta in binding['extracted_members'].items():
        path=ROOT/rel;require(path.stat().st_size==meta['bytes']and sha(path)==meta['sha256'],'frozen extracted input')
    audit=load(ROOT/'upstream_evidence/FINAL_INPUT_AUDIT.json');ledger=load(ROOT/'upstream_evidence/ALL_FIELD_SLOTS.json')
    require(audit['status']=='INPUT_EVIDENCE_AUDITED'and audit['frozen_files_sha256']==INPUT_FREEZE,'audited inputs')
    require([r['instance_id']for r in audit['fields']]==[r['instance_id']for r in ledger]==fields,'complete input124')
    identities=load(ROOT/'input/IDENTITIES.json');require(identities['field_order']==fields and set(identities['fields'])==set(fields),'local identity denominator')
    require(identities['upstream_final_input_audit_sha256']==sha(ROOT/'upstream_evidence/FINAL_INPUT_AUDIT.json'),'input audit bytes')
    problems={};readiness={}
    for field,certified,original in zip(fields,audit['fields'],ledger):
        ident=identities['fields'][field];flags=certified['numeric_flags']
        ready=certified['input_ready']is True and flags['native_policy_admissible']is True and original['author_pass_unreviewed']is True
        require(ident['input_ready']==certified['input_ready']and ident['numeric_flags']==flags,'eligibility derived from audit')
        require(ident['native_ready']is ready,'native readiness flag')
        require(ident['preprocess_sha256']==certified['preprocess_sha256'],'original input SHA')
        readiness[field]=ready
        if not ready:continue
        path=ROOT/ident['local_input_path'];require(sha(path)==certified['preprocess_sha256']and path.stat().st_size==certified['preprocess_bytes']==ident['bytes'],'matrix source bytes')
        require(original['preprocess']['sha256']==certified['preprocess_sha256']and original['preprocess']['bytes']==ident['bytes'],'author input identity')
        data=load(path);require(data['instance_id']==field and data['status']=='PASS_PREPROCESS'and data['n']==12,'field model')
        require(data['K']==3 and data['capacity']==5 and data['demands']==[0]+[1]*12 and len(data['coordinates'])==13,'fixed Q5 model')
        require(data['graph_construction_identity']=='DIRECT_13_TERMINAL_SERVICES_NOT_OLD_21_THEN_SUBMATRIX','terminal model identity')
        for proxy in ('E','G'):
            M=data['integer_matrices'][proxy];derive(M,12,3)
            require(all(M[i][j]==M[j][i]and(i!=j or M[i][j]==0)for i in range(13)for j in range(13)),'symmetric integer matrix')
        problem={k:data[k]for k in('coordinates','demands','capacity','K')};problem['matrices']=data['integer_matrices'];problems[field]=problem
    return fields,problems,readiness,identities


def payload(problem,entry):
    # Exact serialized order used by the frozen projection; only one matrix.
    out={k:problem[k]for k in('coordinates','demands','capacity','K')}
    out.update(distance_matrix=problem['matrices'][entry['proxy']],seed=entry['seed'],max_iterations=entry['max_iterations'],
               arm=entry['arm'],scale=entry['scale'],observe_penalties=entry['observe_penalties'])
    return out


def check_reference_routes(reference,problem):
    for objective,target in reference['objectives'].items():
        if not target['verified']:continue
        groups=target['partition'];routes=target['canonical_routes']
        require(len(groups)==len(routes)==3 and groups==sorted(groups),'canonical reference partition')
        seen=[]
        for group,route in zip(groups,routes):
            require(group==sorted(group) and 2<=len(group)<=5,'reference capacity')
            require(route[0]==route[-1]==0 and sorted(route[1:-1])==group and tuple(route[1:-1])<=tuple(reversed(route[1:-1])),'canonical reference route')
            seen.extend(group)
        require(sorted(seen)==list(range(1,13)),'reference full coverage')
        for proxy in ('E','G'):require(matrix_cost(problem['matrices'][proxy],routes)==target[proxy],'reference original-matrix cost')


def source_references(raw_sha,fields,identities,problems):
    binding=load(ROOT/'postprocess_reference/REFERENCE_BINDING.json')
    require(binding['status']=='EXACT_FINAL_ORIGINAL_BYTES_BOUND_AFTER_ALGORITHM_RAW'and binding['algorithm_raw_archive_sha256']==raw_sha,'post-RAW reference binding')
    for rel,meta in binding['files'].items():
        path=ROOT/rel;require(path.stat().st_size==meta['bytes']and sha(path)==meta['sha256'],'reference original extracted bytes')
    truth=load(ROOT/'postprocess_reference/EXACT_REFERENCE.json');exact_audit=load(ROOT/'postprocess_reference/FINAL_AUDIT.json')
    review=load(ROOT/'postprocess_reference/FINAL_REPORT_REVIEW.json');final=load(ROOT/'postprocess_reference/FINAL_DRIVE_RECEIPT.json')
    require(final['verified']is True and final['owner_only']is True and final['shared']is False and final['download_byte_identical']is True,'private exact FINAL')
    require(final['sha256']==binding['reference_final_archive_sha256']==final['download_sha256'],'reference FINAL identity')
    # The binder already verified actual source/download bytes; independently
    # verify the archived members when auditing this original execution.
    require(sha(final['download_path'])==final['sha256'],'actual exact FINAL downloaded bytes')
    with zipfile.ZipFile(final['download_path'])as archive:
        for rel,meta in binding['files'].items():
            if meta['archive_member']is not None:require(archive.read(meta['archive_member'])==(ROOT/rel).read_bytes(),'actual exact FINAL member')
    require(truth['status']=='EXACT_REFERENCE_AUDITED'and truth['planned_fields']==124,'reference status')
    require(truth['input_final_archive_sha256']==INPUT_SHA and truth['input_final_frozen_files_sha256']==INPUT_FREEZE,'same input ancestor')
    require(all(truth[k]is True for k in('input_final_actual_readback','raw_main_actual_readback','raw_verification_actual_readback')),'reference archived before audit')
    require(review['status']=='PASS'and review['truth_sha256']==sha(ROOT/'postprocess_reference/EXACT_REFERENCE.json'),'reviewed exact truth')
    require(truth['independent_audit_sha256']==review['independent_audit_sha256']==sha(ROOT/'postprocess_reference/FINAL_AUDIT.json'),'exact saved audit hash')
    for key in('frozen_files_sha256','raw_main_archive_sha256','raw_verification_archive_sha256'):
        require(truth[key]==review[key]==exact_audit[key]==binding[key],'exact archive/audit bindings')
    require([r['instance_id']for r in truth['fields']]==fields,'all124 references retained')
    answer={}
    for row in truth['fields']:
        field=row['instance_id'];require(row['input_preprocess_sha256']==identities['fields'][field]['preprocess_sha256'],'reference matrix identity')
        require(set(row['objectives'])=={'E_G','G_E'},'both reference slots')
        for obj in row['objectives'].values():
            require(type(obj['verified'])is bool,'verified boolean')
            if obj['verified']:require(obj['failure']is None and all(type(obj[k])is int and obj[k]>=0 for k in('E','G')),'verified costs')
            else:require(obj['failure']is not None and all(obj[k]is None for k in('E','G','partition','canonical_routes')),'unverified reference nulls')
        eg,ge=row['objectives']['E_G'],row['objectives']['G_E'];both=eg['verified']and ge['verified']
        require(row['valid_for_exact_conclusion']is both and row['E_star']==(eg['E']if eg['verified']else None)and row['G_star']==(ge['G']if ge['verified']else None),'partial reference eligibility')
        require(row['delta_integer_mm']==(eg['G']-ge['G']if both else None),'reference Delta')
        if field in problems:check_reference_routes(row,problems[field])
        answer[field]=row
    return answer,binding


SEED0_FINAL_SHA='79af111bc684d999bffa36b5557330db40694007d50e9a54b4c8b66f7223072e'
SEED0_SUMMARY_SHA='31b277ec94df43ff9802029abe6ee4b59c235e557301bf81b959a69b33622815'
SEED0_AUDIT_SHA='545b92d7e5a292ec9d38fd609cea194cad468afed5544adffe4bcbde7e6e10ea'


def source_seed0(raw_sha,truth_sha,fields):
    from base_summary import ROW_KEYS,SECTIONS
    base=ROOT/'postprocess_reference/seed0'
    binding=load(base/'ORIGINAL_FINAL_BINDING.json')
    require(binding['status']=='SEED0_FINAL_ORIGINAL_BYTES_BOUND_AFTER_ALGORITHM_RAW' and binding['algorithm_raw_archive_sha256']==raw_sha,'seed0 bound only after new RAW')
    require(binding['seed0_final_archive_sha256']==SEED0_FINAL_SHA and binding['seed0_summary_sha256']==SEED0_SUMMARY_SHA,'fixed full seed0 source')
    final=load(base/'FINAL_REVIEWED_DRIVE_RECEIPT.json')
    require(final['verified'] is True and final['owner_only'] is True and final['shared'] is False and final['download_byte_identical'] is True,'private seed0 FINAL')
    require(final['sha256']==final['download_sha256']==SEED0_FINAL_SHA and sha(final['download_path'])==SEED0_FINAL_SHA,'actual original seed0 FINAL download')
    with zipfile.ZipFile(final['download_path']) as archive:
        for rel,meta in binding['files'].items():
            path=ROOT/rel;require(path.resolve().is_relative_to(base.resolve()),'seed0 bounded extraction path')
            require(path.stat().st_size==meta['bytes'] and sha(path)==meta['sha256'],'seed0 copied bytes')
            if meta['archive_member'] is not None:require(archive.read(meta['archive_member'])==path.read_bytes(),'seed0 archived member identity')
    require(sha(base/'SUMMARY.json')==SEED0_SUMMARY_SHA and sha(base/'SAVED_UNSEEN_AUDIT.json')==SEED0_AUDIT_SHA,'originally reviewed summary and independent rows')
    summary=load(base/'SUMMARY.json');audit=load(base/'SAVED_UNSEEN_AUDIT.json');review=load(base/'FINAL_REPORT_REVIEW.json')
    require(review['status']=='PASS' and audit['status']=='SAVED_UNSEEN_AUDITED','seed0 scientific and final review complete')
    require(review['summary_sha256']==SEED0_SUMMARY_SHA and review['independent_audit_sha256']==SEED0_AUDIT_SHA,'seed0 final review bindings')
    require(summary['independent_saved_audit_sha256']==SEED0_AUDIT_SHA,'seed0 summary independent binding')
    require(audit['input_final_archive_sha256']==summary['input_final_archive_sha256']==INPUT_SHA,'same input124')
    require(audit['reference_truth_sha256']==summary['reference_truth_sha256']==truth_sha,'same exact reference bytes')
    for key in ('raw_archive_sha256','frozen_files_sha256'):
        require(audit[key]==summary[key]==review[key],'seed0 raw and freeze')
    require(audit['planned_slots']==summary['planned_slots']==496 and len(audit['rows'])==len(summary['rows'])==496,'all original496 without selection')
    indexed={r['call_id']:r for r in audit['rows']}
    require(len(indexed)==496 and {(r['instance_id'],r['proxy'],r['seed'],r['arm']) for r in audit['rows']}=={(f,p,0,a) for f in fields for p in ('E','G') for a in ('A','P')},'seed0 full same-panel cells')
    for row in summary['rows']:
        for key in ROW_KEYS:equal(indexed[row['call_id']][key],row[key],'seed0 '+row['call_id']+'.'+key)
    for key in SECTIONS:equal(audit[key],summary[key],'seed0 '+key)
    return audit['rows'],binding
