"""Check the saved 992-new plus496-reused report without rerunning any solver."""
from audit_seed_replication import *

HASH_KEYS=('raw_archive_sha256','frozen_files_sha256','reference_truth_sha256','input_final_archive_sha256',
           'precommit_lock_sha256','seed0_final_archive_sha256','seed0_summary_sha256','seed0_original_binding_sha256','reference_final_archive_sha256')
DENOMINATORS={'planned_slots':1488,'new_planned_slots':992,'reused_seed0_planned_slots':496,
              'field_denominator':124,'planned_per_arm_proxy':372,'seeds_per_field':3}
COUNTS=('formal_known_spawned','formal_unknown_spawned_slots','confirmed_model_and_solver_calls',
        'unconfirmed_possible_model_or_solver_calls','reused_seed0_verified_slots','pooled_record_verified_slots',
        'pooled_unconfirmed_possible_call_slots','pooled_known_process_spawned','pooled_unknown_process_spawned','pooled_known_not_spawned')


def compare(audit,summary):
    require(audit['status']=='SAVED_SEED_REPLICATION_AUDITED','independent audit complete')
    for k in HASH_KEYS:require(audit[k]==summary[k],'report identity '+k)
    for k,v in DENOMINATORS.items():require(audit[k]==summary[k]==v,'fixed denominator '+k)
    require(len(audit['rows'])==len(summary['rows'])==1488,'all old and new slots retained')
    by={r['call_id']:r for r in audit['rows']};require(len(by)==1488 and set(by)=={r['call_id'] for r in summary['rows']},'complete call IDs')
    for row in summary['rows']:
        for k in ROW_KEYS:equal(by[row['call_id']][k],row[k],row['call_id']+'.'+k)
    for k in SECTIONS+COUNTS:equal(audit[k],summary[k],k)
    require(summary['new_solver_calls_in_report']==summary['new_native_constructions_in_report']==summary['new_exact_computations_in_report']==0,'saved-only final analysis')
    require(summary['historical_development_cells_in_statistics']==0,'old12 development panel excluded')


def main():
    resource.setrlimit(resource.RLIMIT_CPU,(15,15));resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912));signal.alarm(60)
    t=time.monotonic();cpu=time.process_time();rec=gate()
    path=ROOT/'independent_supervision/results/SAVED_SEED_REPLICATION_AUDIT.json';a=load(path);s=load(ROOT/'reports/SUMMARY.json')
    require(a['raw_archive_sha256']==rec['sha256'] and a['frozen_files_sha256']==rec['frozen_files_sha256'],'new RAW/audit identity')
    require(s['independent_saved_audit_sha256']==sha(path),'report bound independent audit')
    require(a['reference_truth_sha256']==sha(ROOT/'postprocess_reference/EXACT_REFERENCE.json'),'reference unchanged')
    require(a['seed0_original_binding_sha256']==sha(ROOT/'postprocess_reference/seed0/ORIGINAL_FINAL_BINDING.json'),'old seed0 binding unchanged')
    compare(a,s)
    out={'status':'PASS','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        **{k:a[k] for k in HASH_KEYS},**DENOMINATORS,
        'report_sha256':sha(ROOT/'reports/REPORT_ZH.txt'),'summary_sha256':sha(ROOT/'reports/SUMMARY.json'),
        'independent_audit_sha256':sha(path),**{k:a[k] for k in COUNTS},
        'new_solver_calls':0,'new_native_calls':0,'new_exact_calls':0,
        'reader_review_method':'Actual report read separately; numerical and byte contracts only here, no prose keyword gate.',
        'resources':{'cpu_seconds':time.process_time()-cpu,'wall_seconds':time.monotonic()-t}}
    save_exclusive(ROOT/'independent_supervision/results/FINAL_REPORT_REVIEW.json',out);print(json.dumps(out))


if __name__=='__main__':main()
