"""Independent saved native contract; reused validators, fresh A/P arms."""
import copy
from base_saved import *

def derive(M,n,K):
    require((n,K)in((4,2),(12,3)), 'fixed problem sizes')
    require(len(M)==n+1 and all(len(r)==n+1 for r in M), 'matrix shape')
    require(all(type(v)is int and 0<=v<=3944800 for r in M for v in r), 'nonnegative bounded matrix')
    maximum=max(map(max,M));U=(n+K)*maximum;P=U+1
    require(P*1000<2**53 and 4*(U+n*P)<2**53<2**63-1, 'native integer arithmetic safety')
    return dict(formula='(n_customers+K)*max_edge+1',n_customers=n,K=K,max_edge=maximum,U=U,P=P)

def observation(a,e,p):
    o=a['penalty_observation']
    if not e['observe_penalties']:
        require(o is None,'unobserved callback');return {'observed':False,'initial_solution_feasible':None,'first_best_feasible_iteration':None,'pm_updates_observed':None}
    require(o['schema']=='public_scale_penalty_observer_v1'and o['probe_values']==[1,2,7,1000],'observer schema/probes')
    midpoint=e['min_penalty']+(e['max_penalty']-e['min_penalty'])/2;expected=[[midpoint],midpoint,midpoint];require(o['initial_penalties']==expected,'initial public midpoint')
    rr=o['initial_solution_routes'];n=len(p['coordinates'])-1;seen=[];loads=[]
    require(isinstance(rr,list)and 1<=len(rr)<=p['K'],'initial route count')
    for r in rr:
        require(isinstance(r,list)and len(r)>=3 and r[0]==r[-1]==0 and all(type(v)is int and 1<=v<=n for v in r[1:-1]),'initial route schema')
        seen.extend(r[1:-1]);loads.append(sum(p['demands'][v]for v in r[1:-1]))
    require(Counter(seen)==Counter(range(1,n+1)),'initial coverage');initial=all(v<=p['capacity']for v in loads);require(o['initial_solution_feasible']is initial,'initial feasibility')
    first=0 if initial else None;found=initial;retained=True;require(len(o['rows'])==250==len(a['stats']),'250observations')
    probes=[{'violation':v,'load':int(v*midpoint),'duration':int(v*midpoint),'distance':int(v*midpoint)}for v in(1,2,7,1000)]
    for i,(row,stat)in enumerate(zip(o['rows'],a['stats']),1):
        require(type(row['iteration'])is int and row['iteration']==i,'observer iteration')
        require(row['expected_search_penalties_source_derived']==row['observed_post_registration_penalties']==expected,'500registration no250update contract')
        require(row['observed_search_evaluator_integer_probes']==probes,'delivered integer evaluator probes')
        state=row['best_is_feasible'];require(type(state)is bool and state==stat['best_feas'],'publicbest versus stats')
        # Monotone best feasibility is a source prediction under test, not an
        # eligibility filter that may discard a readable counterexample.
        if found and not state:retained=False
        if state and first is None:first=i
        found=found or state
    require(o['first_best_feasible_iteration']==first and o['rows'][-1]['best_is_feasible']==a['solver_is_feasible'],'first observed feasible/final saved state')
    return {'observed':True,'initial_solution_feasible':initial,'initial_solution_routes':rr,'initial_solution_loads':loads,'first_best_feasible_iteration':first,'pm_updates_observed':0,'diagnostic_best_feasible_retention_observed':retained}


def check_answer(problem, entry, answer, default_params):
    require(entry['arm'] in ('A','P') and entry['scale']==1 and entry['max_iterations']==250,'fresh registered arms')
    require(answer['arm']==entry['arm'] and answer['scale']==1 and answer['observe_penalties']==entry['observe_penalties'],'fresh output identity')
    bound=derive(problem['matrices'][entry['proxy']],len(problem['coordinates'])-1,problem['K']) if entry['arm']=='P' else None
    settings={'min_penalty':float(bound['P']),'max_penalty':float(bound['P'])} if bound else {'min_penalty':.1,'max_penalty':100000.0}
    require(answer['derived_penalty']==bound and answer['public_penalty_bounds']==settings,'input-only public penalty contract')
    params=copy.deepcopy(default_params);params['values']['penalty']['values'].update(settings)
    if entry['observe_penalties']:
        params['values']['ils']['values']['callbacks']={'type':'observer.ReadonlyPenaltyObserver','values':{}}
    require(answer['solver_is_complete'] is True and 1<=len(answer['routes'])<=problem['K'],'full required coverage and vehicle count')
    checked=validate_answer(problem,entry,answer,params,expected_cpu=120)
    observed=observation(answer,{**entry,**settings},problem)
    if observed['observed']:
        observed.update(source_prediction_initial_feasible_observed=observed['initial_solution_feasible'],
                        source_prediction_current_feasible_all250_observed=all(s['current_feas']for s in answer['stats']))
    return {'valid':checked['valid_feasible'],'routing_violation':not checked['valid_feasible'],
            'base_E':checked['E'],'base_G':checked['G'],
            'normalized_own_cost':checked[entry['proxy']] if checked['valid_feasible'] else None,
            'routes':checked['routes'],'loads':checked['loads'],'observations':observed,'derived_penalty':bound}
