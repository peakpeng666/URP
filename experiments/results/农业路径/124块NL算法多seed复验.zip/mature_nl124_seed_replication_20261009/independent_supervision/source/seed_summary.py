"""Independent three-seed summaries; prior registered endpoints remain unchanged."""
from base_summary import ROW_KEYS, endpoint, values, observations, pair_group, arm_group as original_arm_group

SECTIONS=('by_proxy','overall','per_field','field_level_summary','paired_rows','secondary_cross_G_on_E_pairs','P_invariant_transfer')


def arm_group(rows):
    out=original_arm_group(rows)
    out['exact_unscored_valid']=out['valid_feasible']-out['exact_scored_valid']
    out['own_exact_non_hits_scored_valid']=out['exact_scored_valid']-out['confirmed_exact_hits']
    return out


def cross_group(pairs):
    nums=[x['delta_G_P_minus_A_mm'] for x in pairs if x['common_success']]
    return {'definition':'G(P route from E search) - G(A route from E search), integer mm',
        'planned_E_pairs':len(pairs),'common_success':len(nums),'excluded_or_missing':len(pairs)-len(nums),
        'positive':sum(x>0 for x in nums),'zero':sum(x==0 for x in nums),'negative':sum(x<0 for x in nums),
        'summary':values(nums,len(pairs)),
        'interpretation':'Treatment-pair G realization; distinct from own E gap, exact proxy Delta, or signed offset from the E_G reference.'}


def frequencies(nums):
    assert all(type(x) is int and 0<=x<=3 for x in nums)
    return {str(i):sum(x==i for x in nums) for i in range(4)}


def summarize(rows,fields):
    assert len(fields)==len(set(fields))==124 and len(rows)==1488
    ix={(r['instance_id'],r['proxy'],r['seed'],r['arm']):r for r in rows}
    expected={(f,p,s,a) for f in fields for p in ('E','G') for s in range(3) for a in ('A','P')}
    assert set(ix)==expected and len({r['call_id'] for r in rows})==1488
    for (f,p,s,a),r in ix.items():
        assert r['call_id']==f'{f}_{p}_s{s}_{a}_i250' and r['scale']==1 and r['max_iterations']==250
    paired={'E':[],'G':[]};by_field=[]
    for field in fields:
        local={p:[] for p in paired}
        for proxy in paired:
            for seed in range(3):
                a,p=ix[field,proxy,seed,'A'],ix[field,proxy,seed,'P'];both=a['valid'] and p['valid']
                item={'instance_id':field,'proxy':proxy,'seed':seed,'A_valid':a['valid'],'P_valid':p['valid'],
                    'A_record_verified':a['record_verified'],'P_record_verified':p['record_verified'],'common_success':both}
                for target,key in [('delta_own_cost_P_minus_A_mm','normalized_own_cost'),('delta_E_P_minus_A_mm','base_E'),('delta_G_P_minus_A_mm','base_G'),('delta_own_gap_P_minus_A_mm','own_gap_mm')]:
                    item[target]=p[key]-a[key] if both and a[key] is not None and p[key] is not None else None
                local[proxy].append(item);paired[proxy].append(item)
        selected=[ix[field,p,s,a] for p in ('E','G') for s in range(3) for a in ('A','P')]
        by_field.append({'instance_id':field,'seeds':[0,1,2],'slots':12,'valid_feasible':sum(r['valid'] for r in selected),
            'by_proxy':{p:{'arms':{a:arm_group([ix[field,p,s,a] for s in range(3)]) for a in ('A','P')},'pairs':pair_group(local[p])} for p in ('E','G')},
            'E_search_A_to_P_G':cross_group(local['E'])})
    field_summary={p:{} for p in ('E','G')}
    count_keys=('valid_feasible','verified_native_infeasible','technical_or_unverified_or_not_run','confirmed_exact_hits','own_exact_non_hits_scored_valid','exact_unscored_valid')
    for proxy in field_summary:
        for arm in ('A','P'):
            counts=[f['by_proxy'][proxy]['arms'][arm] for f in by_field]
            field_summary[proxy][arm]={'fields':124,'planned_seeds_per_field':3,'planned_repeated_slots':372,
                'count_distributions':{key:frequencies([x[key] for x in counts]) for key in count_keys},
                'equal_field_weight_mean_feasible_fraction':sum(x['valid_feasible']/3 for x in counts)/124,
                'equal_field_weight_mean_confirmed_own_exact_fraction':sum(x['confirmed_exact_hits']/3 for x in counts)/124,
                'interpretation':'Fractions use three planned seeds per field; confirmed exact yield is not a claim that unscored or unknown slots missed the optimum.'}
    cross=cross_group(paired['E']);available=[f['E_search_A_to_P_G']['summary']['conditional_mean'] for f in by_field if f['E_search_A_to_P_G']['common_success']]
    n_per_field=[f['E_search_A_to_P_G']['common_success'] for f in by_field]
    cross.update(statistical_unit='124 fields; 372 seed pairs are within-field repeated measurements',
        equal_field_weight={'planned_fields':124,'planned_pairs_per_field':3,'fields_with_available_pairs':len(available),
            'fields_without_available_pairs':124-len(available),'available_pair_count_distribution':frequencies(n_per_field),
            'conditional_equal_field_mean_mm':sum(available)/len(available) if available else None,
            'complete_panel_equal_field_mean_mm':sum(available)/124 if all(n==3 for n in n_per_field) else None,
            'definition':'Average each field over its available common-success seed pairs, then weight eligible fields equally; complete-panel mean requires every one of 372 planned pairs.'})
    return {'by_proxy':{p:{'arms':{a:arm_group([r for r in rows if r['proxy']==p and r['arm']==a]) for a in ('A','P')},'pairs':pair_group(paired[p])} for p in ('E','G')},
        'overall':{'arms':{a:arm_group([r for r in rows if r['arm']==a]) for a in ('A','P')},'mixed_proxy_costs_are_descriptive_only':True},
        'per_field':by_field,'field_level_summary':field_summary,'paired_rows':paired,'secondary_cross_G_on_E_pairs':cross,
        'P_invariant_transfer':{p:observations([r for r in rows if r['proxy']==p and r['arm']=='P']) for p in ('E','G')},
        'pooled_record_verified_slots':sum(r['record_verified'] for r in rows),
        'pooled_unconfirmed_possible_call_slots':sum(r['process_spawned'] is not False and not r['record_verified'] for r in rows),
        'pooled_known_process_spawned':sum(r['process_spawned'] is True for r in rows),
        'pooled_unknown_process_spawned':sum(r['process_spawned'] is None for r in rows),
        'pooled_known_not_spawned':sum(r['process_spawned'] is False for r in rows)}
