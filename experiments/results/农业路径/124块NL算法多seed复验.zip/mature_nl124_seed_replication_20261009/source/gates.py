"""One-use 992-slot gates. Pure data checks; never load exact references."""
from pathlib import Path
import re
from common import ROOT,read,sha,verify_frozen,verify_old,receipt
from input_projection import project_payload,planned_input_status

FORMAL_SCOPE='one frozen992-slot PyVRP default-versus-input-derived-P replication batch,124fields,seeds1and2,E/G,250ILS,no retry'
SCIENCE_SHA='4dbd4f75d3acf8a5354104bec7b611073f3aff3a5d1a3f611f40ec309d3f8e94'


def verify_scientific_lock():
    assert sha(ROOT/'freeze/SCIENTIFIC_POLICY_LOCK.json')==SCIENCE_SHA
    lock=read('freeze/SCIENTIFIC_POLICY_LOCK.json')
    assert len(lock['files'])==12
    for rel,meta in lock['files'].items():
        path=ROOT/rel
        assert path.stat().st_size==meta['bytes'] and sha(path)==meta['sha256'], 'SCIENTIFIC_LOCK_CHANGED:'+rel
    for name in ('worker.py','matrix_adapter.py'):
        assert (ROOT/'source'/name).read_bytes()==(ROOT/'source'/(name+'.proposed')).read_bytes(), 'WORKER_PROMOTION_DRIFT:'+name
    assert sha(ROOT/'freeze/PRECOMMIT_LOCK.json')=='b4aac52014276b42870332fb4bab6f7abe15a740e280059c7c0480aa8db8db4b'
    for rel,meta in read('freeze/PRECOMMIT_LOCK.json')['files'].items():
        assert (ROOT/rel).stat().st_size==meta['bytes'] and sha(ROOT/rel)==meta['sha256']
    for name,meta in read('parent_identity/SEED0_FINAL_IDENTITY.json')['unchanged_worker_files'].items():
        assert (ROOT/'source'/name).stat().st_size==meta['bytes'] and sha(ROOT/'source'/name)==meta['sha256']
    return SCIENCE_SHA


def check_environment():
    env=read('environment/RUNTIME.json');python=Path(env['python_executable'])
    assert python.is_file() and sha(python.resolve())==env['python_binary_sha256']
    for item in env['installed_distribution_files']:
        path=Path(item['path'])
        assert path.stat().st_size==item['bytes'] and sha(path)==item['sha256'], str(path)
    assert env['pyvrp_version']=='0.14.0'
    return str(python)


def get_schedule(mode):
    assert mode=='formal'
    schedule=read('freeze/PROPOSED_SCHEDULE.json')['entries']
    fields=read('upstream_identity/PANEL_SOURCE_IDENTITY.json')['field_ids_in_source_order']
    assert len(fields)==len(set(fields))==124 and all(re.fullmatch(r'nl_field_[0-9]+',f) for f in fields)
    expected=[]
    for i,field in enumerate(fields):
        for seed in (1,2):
            for j,proxy in enumerate(('E','G')):
                order=['A','P'] if (i+j+seed)%2==0 else ['P','A']
                for position,arm in enumerate(order,1):
                    expected.append({'schedule_index':len(expected)+1,'call_id':f'{field}_{proxy}_s{seed}_{arm}_i250',
                        'instance_id':field,'proxy':proxy,'seed':seed,'arm':arm,'max_iterations':250,
                        'scale':1,'observe_penalties':True,'arm_position':position,'arm_order':order})
    assert schedule==expected and len(schedule)==992
    return schedule


def verify_input_binding():
    binding=read('upstream_identity/FINAL_INPUT_PACKAGE_IDENTITY.json')
    assert binding['status']=='VERIFIED_FINAL_INPUT_ARCHIVE_MEMBER_EXTRACTION'
    assert binding['scientific_policy_lock_sha256']==verify_scientific_lock()
    assert binding['upstream_frozen_files_sha256']=='43a3a05519bbfa4689a071e1dc71e44c86585c2f215ead4319a8318f708e05ef'
    for relative,meta in binding['extracted_members'].items():
        path=(ROOT/relative).resolve()
        assert path.is_relative_to(ROOT.resolve()) and path.stat().st_size==meta['bytes'] and sha(path)==meta['sha256'], 'UPSTREAM_EXTRACTED_MEMBER_CHANGED:'+relative
        assert isinstance(meta['archive_member'],str)
    for relative,meta in binding['external_receipts'].items():
        path=ROOT/relative
        assert path.stat().st_size==meta['bytes'] and sha(path)==meta['sha256']
    final=read('upstream_evidence/FINAL_DRIVE_RECEIPT.json')
    assert final['stage']=='FINAL' and final['sha256']==final['download_sha256']==binding['upstream_final_archive_sha256']
    assert final['owner_only'] is True and final['shared'] is False
    assert final['remote_readback_sha256_verified'] is True and final['download_byte_identical'] is True
    audit=read('upstream_evidence/FINAL_INPUT_AUDIT.json')
    assert audit['status']=='INPUT_EVIDENCE_AUDITED' and audit['planned_fields']==124
    assert audit['frozen_files_sha256']==binding['upstream_frozen_files_sha256']
    assert audit['optimizer_calls']==audit['native_model_instances']==0
    for stage,key in [('RAW_MAIN','raw_main_archive_sha256'),('RAW_VERIFICATION','raw_verification_archive_sha256')]:
        rec=read('upstream_evidence/'+stage+'_DRIVE_RECEIPT.json')
        assert rec['stage']==stage and rec['sha256']==rec['download_sha256']==audit[key]
        assert rec['owner_only'] is True and rec['shared'] is False
        assert rec['remote_readback_sha256_verified'] is True and rec['download_byte_identical'] is True
    author=read('upstream_evidence/ALL_FIELD_SLOTS.json')
    assert isinstance(author,list) and len(author)==124
    assert len(audit['fields'])==124
    author_rows={row['instance_id']:row for row in author}
    independent_rows={row['instance_id']:row for row in audit['fields']}
    assert len(author_rows)==len(independent_rows)==124
    identities=read('input/IDENTITIES.json')
    fields=read('upstream_identity/PANEL_SOURCE_IDENTITY.json')['field_ids_in_source_order']
    assert identities['field_order']==fields and set(identities['fields'])==set(fields)
    assert set(author_rows)==set(independent_rows)==set(fields)
    assert identities['upstream_final_archive_sha256']==binding['upstream_final_archive_sha256']
    assert identities['upstream_final_input_audit_sha256']==sha(ROOT/'upstream_evidence/FINAL_INPUT_AUDIT.json')
    for field in fields:
        row=identities['fields'][field]
        assert row['instance_id']==field and type(row['native_ready']) is bool
        original=independent_rows[field]
        recomputed=planned_input_status(field,author_rows[field],original)
        assert row['readiness_evidence']==recomputed, 'READINESS_DERIVATION_MISMATCH:'+field
        assert row['status']==recomputed['status']
        assert row['native_ready']==(recomputed['status']=='INPUT_AUDIT_READY_FOR_BYTE_AND_NUMERIC_CHECK')
        assert row['input_ready'] is original['input_ready'] and row['numeric_flags']==original['numeric_flags']
        assert row['preprocess_sha256']==original['preprocess_sha256']
        assert row['bytes']==original['preprocess_bytes']
        assert row['upstream_preprocess_path']==original['preprocess_path']
        if row['native_ready']:
            relative=f'input/{field}.json'; path=ROOT/relative
            assert row['local_input_path']==relative and path.stat().st_size==row['bytes'] and sha(path)==row['preprocess_sha256']
            data=read(relative)
            assert data['instance_id']==field
            # Preflight both proxies before ANY one of this field's eight slots.
            for proxy in ('E','G'):
                for arm in ('A','P'):project_payload(data,proxy,arm,1)
    return binding['upstream_final_archive_sha256']


def check_gate(mode):
    assert mode=='formal'
    verify_old();digest=verify_frozen();science=verify_scientific_lock()
    upstream=verify_input_binding();get_schedule(mode)
    rec=receipt('PREEXEC');review=read('freeze/INDEPENDENT_PRECHECK.json')
    assert review['status']=='PASS'
    approval=read('provenance/PARENT_EXECUTION_APPROVAL.json')
    assert approval['approved'] is True and approval['scope']==FORMAL_SCOPE
    assert approval['frozen_files_sha256']==digest and approval['preexec_archive_sha256']==rec['sha256']
    assert approval['independent_precheck_sha256']==sha(ROOT/'freeze/INDEPENDENT_PRECHECK.json')
    assert approval['scientific_policy_lock_sha256']==science and approval['upstream_final_archive_sha256']==upstream
    assert approval['planned_slots']==992 and approval['additional_native_toys']==0
    return {'mode':mode,'freeze_sha256':digest,'python':check_environment(),
            'scientific_policy_lock_sha256':science,'upstream_final_archive_sha256':upstream,
            'approval_sha256':sha(ROOT/'provenance/PARENT_EXECUTION_APPROVAL.json'),
            'preexec_receipt_sha256':sha(ROOT/'provenance/PREEXEC_DRIVE_RECEIPT.json')}


def load_payload(entry,mode):
    assert mode=='formal'
    identity=read('input/IDENTITIES.json')['fields'][entry['instance_id']]
    if identity['native_ready'] is not True:return None
    path=ROOT/identity['local_input_path']
    assert path.stat().st_size==identity['bytes'] and sha(path)==identity['preprocess_sha256'], 'RUNTIME_INPUT_IDENTITY_DRIFT'
    data=read(identity['local_input_path'])
    assert data['instance_id']==entry['instance_id']
    # Field-wide guard is repeated to fail closed on any runtime identity drift.
    for proxy in ('E','G'):
        for arm in ('A','P'):project_payload(data,proxy,arm,1)
    payload=project_payload(data,entry['proxy'],entry['arm'],entry['seed'])
    for key in ('seed','max_iterations','arm','scale','observe_penalties'):
        assert payload[key]==entry[key]
    return payload
