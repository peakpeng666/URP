"""Prospective pure-data contract. No native import, construction, or launch."""
import math
from penalty_bound import derive_penalty

FIELDS = {'coordinates', 'demands', 'capacity', 'K', 'distance_matrix', 'seed',
          'max_iterations', 'arm', 'scale', 'observe_penalties'}


def validate_payload(payload):
    assert isinstance(payload, dict) and set(payload) == FIELDS
    assert payload['demands'] == [0] + [1] * 12
    assert all(type(v) is int for v in payload['demands'])
    assert type(payload['capacity']) is int and payload['capacity'] == 5
    assert type(payload['K']) is int and payload['K'] == 3
    assert type(payload['seed']) is int and payload['seed'] in (1, 2)
    assert type(payload['max_iterations']) is int and payload['max_iterations'] == 250
    assert payload['arm'] in ('A', 'P')
    assert type(payload['scale']) is int and payload['scale'] == 1
    assert payload['observe_penalties'] is True
    coords = payload['coordinates']
    assert isinstance(coords, list) and len(coords) == 13
    assert all(isinstance(p, list) and len(p) == 2 and all(type(v) in (int, float) and math.isfinite(v) for v in p) for p in coords)
    matrix = payload['distance_matrix']
    assert isinstance(matrix, list) and len(matrix) == 13
    assert all(isinstance(row, list) and len(row) == 13 for row in matrix)
    for i, row in enumerate(matrix):
        for j, value in enumerate(row):
            assert type(value) is int and 0 <= value <= 3944800, 'INPUT_GUARD_BLOCKED'
            assert value == matrix[j][i] and (i != j or value == 0)
    derive_penalty(matrix, 12, 3)


def public_penalty_settings(payload):
    validate_payload(payload)
    bound = derive_penalty(payload['distance_matrix'], 12, 3)
    if payload['arm'] == 'P':
        penalty = float(bound['P'])
        return {'min_penalty': penalty, 'max_penalty': penalty}
    # Baseline remains exactly the frozen official defaults.
    assert 1000 * 100000 < 2**53
    assert 4 * (bound['U'] + 12 * 100000) < 2**53
    return {'min_penalty': 0.1, 'max_penalty': 100000.0}
