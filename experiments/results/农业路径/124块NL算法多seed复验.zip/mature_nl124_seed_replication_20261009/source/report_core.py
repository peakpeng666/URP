"""Pure 1488-slot, 124-field repeated-seed endpoints; no native import or solver.

Seeds are within-field repeated measurements. No 372-independent-field inference.
"""
from collections import Counter

ARMS=('A','P')
PROXIES=('E','G')
SEEDS=(0,1,2)
COST_METRICS=('base_E','base_G','normalized_own_cost')
EXACT_METRICS=('own_gap_mm','own_gap_percent','G_realized_excess_mm',
               'E_offset_from_lex_reference_mm','E_optimal_tie_difference_mm')
ROW_AUDIT_KEYS=('call_id','instance_id','proxy','seed','arm','scale','max_iterations',
    'valid','record_verified','routing_violation','base_E','base_G','normalized_own_cost',
    'own_reference_verified','own_gap_mm','own_gap_percent','exact_hit',
    'G_realized_excess_mm','E_offset_from_lex_reference_mm','E_optimal_tie_difference_mm',
    'exact_proxy_reference_delta_mm','observations','process_spawned','raw_status','failure_class','input_readiness_status')


def blank_row(entry,slot):
    row=dict(entry)
    status=slot['status'];readiness=slot.get('input_readiness') or {}
    input_status=readiness.get('status')
    if status=='NOT_STARTED_INPUT_OR_TECHNICAL_BLOCKED':
        category='TECHNICAL_GUARD_BLOCKED' if input_status and ('NATIVE_POLICY' in input_status or 'GUARD' in input_status) else 'INPUT_FAILURE_OR_UNVERIFIED'
    elif status=='UNKNOWN_AFTER_SUPERVISOR_FAILURE':category='UNKNOWN_PROCESS_OR_OUTPUT'
    elif status=='NOT_STARTED_SUPERVISOR_FAILURE':category='NOT_STARTED_SUPERVISOR_FAILURE'
    elif status=='NOT_STARTED_INPUT_FAILURE':category='RUNTIME_INPUT_IDENTITY_OR_CONTRACT_FAILURE'
    elif status in ('WALL_TIMEOUT','PROCESS_FAILURE_OR_CPU_LIMIT'):category='PROCESS_FAILURE_OR_LIMIT'
    else:category='UNVERIFIED_OUTPUT_OR_CALL_ERROR'
    row.update(raw_status=slot['status'],process_spawned=slot.get('process_spawned'),
        valid=False,record_verified=False,routing_violation=None,failure=None,failure_class=category,input_readiness_status=input_status,
        base_E=None,base_G=None,normalized_own_cost=None,diagnostic_base_E=None,diagnostic_base_G=None,
        own_reference_verified=False,own_gap_mm=None,own_gap_percent=None,exact_hit=None,
        G_realized_excess_mm=None,E_offset_from_lex_reference_mm=None,E_optimal_tie_difference_mm=None,
        exact_proxy_reference_delta_mm=None,observations=None,routes=None,loads=None,
        offset_is_search_error=False)
    return row


def apply_checked(row,checked,answer):
    assert type(checked['valid']) is bool and type(checked['routing_violation']) is bool
    row.update(record_verified=True,routing_violation=checked['routing_violation'],
        diagnostic_base_E=checked['base_E'],diagnostic_base_G=checked['base_G'],
        observations=checked['observations'],routes=checked['routes'],loads=checked['loads'])
    if not checked['valid']:
        row['failure']='NO_FEASIBLE_INCUMBENT'
        row['failure_class']='VERIFIED_NATIVE_INFEASIBLE'
        return row
    assert row['scale']==1 and answer['reported_cost']==checked['normalized_own_cost']
    row.update(valid=True,failure_class='VALID_FEASIBLE',base_E=checked['base_E'],base_G=checked['base_G'],
        normalized_own_cost=checked['normalized_own_cost'])
    return row


def apply_reference(row,reference):
    """References may be partially unavailable. Do not invent missing endpoints."""
    if not row['valid'] or reference is None:return row
    targets={key:reference.get('objectives',{}).get(key) for key in ('E_G','G_E')}
    verified={key:isinstance(targets[key],dict) and targets[key].get('verified') is True for key in targets}
    for key in targets:
        if verified[key]:
            assert all(type(targets[key][proxy]) is int and targets[key][proxy]>=0 for proxy in PROXIES)
    own_key='E_G' if row['proxy']=='E' else 'G_E'
    if verified[own_key]:
        optimum=targets[own_key][row['proxy']]
        assert reference[row['proxy']+'_star']==optimum
        gap=row['normalized_own_cost']-optimum
        assert type(gap) is int and gap>=0,'NEGATIVE_OWN_GAP'
        row.update(own_reference_verified=True,own_gap_mm=gap,
            own_gap_percent=100*gap/optimum if optimum>0 else None,exact_hit=gap==0)
    if verified['G_E']:
        excess=row['base_G']-targets['G_E']['G']
        assert excess>=0,'NEGATIVE_G_EXCESS'
        row['G_realized_excess_mm']=excess
    if row['proxy']=='E' and verified['E_G']:
        offset=row['base_G']-targets['E_G']['G']
        row['E_offset_from_lex_reference_mm']=offset
        if row['exact_hit'] is True:
            assert offset>=0,'NEGATIVE_E_OPTIMAL_TIE_DIFFERENCE'
            row['E_optimal_tie_difference_mm']=offset
    if all(verified.values()):
        delta=targets['E_G']['G']-targets['G_E']['G']
        assert delta==reference['delta_integer_mm'] and delta>=0
        row['exact_proxy_reference_delta_mm']=delta
        if row['proxy']=='E':
            assert row['G_realized_excess_mm']==row['E_offset_from_lex_reference_mm']+delta
    return row


def values_summary(values,planned):
    assert all(type(v) in (int,float) for v in values)
    n=len(values)
    return {'available':n,'planned':planned,'missing':planned-n,
        'conditional_mean':sum(values)/n if n else None,
        'min':min(values) if n else None,'max':max(values) if n else None,
        'complete_panel_mean':sum(values)/n if n and n==planned else None}


def summarize_observations(rows):
    keys=('initial_solution_feasible','source_prediction_current_feasible_all250_observed')
    result={'planned':len(rows),'scope':'Saved public endpoint observations. Only the P arm tests the registered conditional source-invariant transfer; no general search-quality theorem.'}
    for key in keys:
        counts={'true':0,'false':0,'unknown_or_not_run':0}
        for row in rows:
            value=row['observations'].get(key) if isinstance(row['observations'],dict) else None
            counts['true' if value is True else 'false' if value is False else 'unknown_or_not_run']+=1
        result[key]=counts
    result['returned_best_feasible']={'true':sum(r['record_verified'] and r['valid'] for r in rows),
        'false':sum(r['record_verified'] and not r['valid'] for r in rows),
        'unknown_or_not_run':sum(not r['record_verified'] for r in rows)}
    return result


def summarize_arm(rows):
    n=len(rows);valid=[r for r in rows if r['valid']]
    exact=[r for r in valid if r['own_reference_verified']]
    hits=sum(r['exact_hit'] is True for r in exact)
    return {'planned':n,'valid_feasible':len(valid),'valid_feasible_rate_all_planned':len(valid)/n if n else None,
        'verified_native_infeasible':sum(r['record_verified'] and not r['valid'] for r in rows),
        'technical_or_unverified_or_not_run':sum(not r['record_verified'] for r in rows),
        'raw_status_counts':dict(Counter(r['raw_status'] for r in rows)),
        'failure_class_counts':dict(Counter(r['failure_class'] for r in rows)),
        'exact_scored_valid':len(exact),'confirmed_exact_hits':hits,
        'confirmed_hit_yield_all_planned':hits/n if n else None,
        'exact_hit_rate_scored_valid_only':hits/len(exact) if exact else None,
        'exact_score_missing_or_invalid':n-len(exact),
        'exact_unscored_valid':len(valid)-len(exact),
        'own_exact_non_hits_scored_valid':len(exact)-hits,
        'metrics':{key:values_summary([r[key] for r in valid if r[key] is not None],n) for key in COST_METRICS+EXACT_METRICS},
        'observations':summarize_observations(rows)}



def pair_rows(rows,fields,proxy):
    lookup={(r['instance_id'],r['proxy'],r['seed'],r['arm']):r for r in rows}
    output=[]
    for field in fields:
        for seed in SEEDS:
            a,p=lookup[field,proxy,seed,'A'],lookup[field,proxy,seed,'P']
            both=a['valid'] and p['valid']
            output.append({'instance_id':field,'proxy':proxy,'seed':seed,'A_valid':a['valid'],'P_valid':p['valid'],
                'A_record_verified':a['record_verified'],'P_record_verified':p['record_verified'],
                'common_success':both,
                'delta_own_cost_P_minus_A_mm':p['normalized_own_cost']-a['normalized_own_cost'] if both else None,
                'delta_E_P_minus_A_mm':p['base_E']-a['base_E'] if both else None,
                'delta_G_P_minus_A_mm':p['base_G']-a['base_G'] if both else None,
                'delta_own_gap_P_minus_A_mm':p['own_gap_mm']-a['own_gap_mm'] if both and a['own_gap_mm'] is not None and p['own_gap_mm'] is not None else None})
    return output


def summarize_pairs(pairs):
    common=[p for p in pairs if p['common_success']];n=len(pairs)
    transitions=Counter(('valid' if p['A_valid'] else 'not_valid')+'->'+('valid' if p['P_valid'] else 'not_valid') for p in pairs)
    keys=('delta_own_cost_P_minus_A_mm','delta_E_P_minus_A_mm','delta_G_P_minus_A_mm','delta_own_gap_P_minus_A_mm')
    return {'planned_pairs':n,'common_success':len(common),'excluded_or_missing':n-len(common),
        'validity_transitions':dict(transitions),'transition_limit':'not_valid includes technical/input/unknown slots; it does not mean observed native infeasibility.',
        'deltas':{key:values_summary([p[key] for p in common if p[key] is not None],n) for key in keys}}


def cross_G_signs(E_pairs):
    values=[p['delta_G_P_minus_A_mm'] for p in E_pairs if p['common_success']]
    assert all(type(v) is int for v in values)
    return {'definition':'G(P route from E search) - G(A route from E search), integer mm',
        'planned_E_pairs':len(E_pairs),'common_success':len(values),'excluded_or_missing':len(E_pairs)-len(values),
        'positive':sum(v>0 for v in values),'zero':sum(v==0 for v in values),'negative':sum(v<0 for v in values),
        'summary':values_summary(values,len(E_pairs)),
        'interpretation':'Treatment-pair G realization; distinct from own E gap, exact proxy Delta, or signed offset from the E_G reference.'}


def count_distribution(values):
    assert all(type(v) is int and 0<=v<=3 for v in values)
    return {str(i):values.count(i) for i in range(4)}


def field_level_arm(field_arms):
    """Equal-field-weight yields keep unknown/unscored separate from observed failure."""
    assert len(field_arms)==124 and all(a['planned']==3 for a in field_arms)
    keys=('valid_feasible','verified_native_infeasible','technical_or_unverified_or_not_run',
          'confirmed_exact_hits','own_exact_non_hits_scored_valid','exact_unscored_valid')
    result={'fields':124,'planned_seeds_per_field':3,'planned_repeated_slots':372,
        'count_distributions':{key:count_distribution([a[key] for a in field_arms]) for key in keys},
        'equal_field_weight_mean_feasible_fraction':sum(a['valid_feasible']/3 for a in field_arms)/124,
        'equal_field_weight_mean_confirmed_own_exact_fraction':sum(a['confirmed_exact_hits']/3 for a in field_arms)/124,
        'interpretation':'Fractions use three planned seeds per field; confirmed exact yield is not a claim that unscored or unknown slots missed the optimum.'}
    return result


def equal_field_cross_G(per_field_cross):
    assert len(per_field_cross)==124 and all(v['planned_E_pairs']==3 for v in per_field_cross)
    available=[v['summary']['conditional_mean'] for v in per_field_cross if v['common_success']]
    complete=all(v['common_success']==3 for v in per_field_cross)
    return {'planned_fields':124,'planned_pairs_per_field':3,'fields_with_available_pairs':len(available),
        'fields_without_available_pairs':124-len(available),
        'available_pair_count_distribution':count_distribution([v['common_success'] for v in per_field_cross]),
        'conditional_equal_field_mean_mm':sum(available)/len(available) if available else None,
        'complete_panel_equal_field_mean_mm':sum(available)/124 if complete else None,
        'definition':'Average each field over its available common-success seed pairs, then weight eligible fields equally; complete-panel mean requires every one of 372 planned pairs.'}


def validate_panel_rows(rows,fields):
    assert len(fields)==len(set(fields))==124 and len(rows)==1488
    assert len({r['call_id'] for r in rows})==1488
    expected={(f,p,s,a) for f in fields for p in PROXIES for s in SEEDS for a in ARMS}
    assert {(r['instance_id'],r['proxy'],r['seed'],r['arm']) for r in rows}==expected
    for row in rows:
        assert type(row['seed']) is int and row['seed'] in SEEDS
        assert row['call_id']==f"{row['instance_id']}_{row['proxy']}_s{row['seed']}_{row['arm']}_i250"
        assert type(row['scale']) is int and row['scale']==1
        assert type(row['max_iterations']) is int and row['max_iterations']==250
        assert all(type(row[k]) is bool for k in ('valid','record_verified','own_reference_verified'))
        assert row['process_spawned'] is None or type(row['process_spawned']) is bool
        assert not row['valid'] or (row['record_verified'] and row['routing_violation'] is False)
        if row['record_verified']:
            assert type(row['routing_violation']) is bool and row['routing_violation'] is not row['valid']
        if not row['valid']:
            assert all(row[k] is None for k in COST_METRICS+EXACT_METRICS+('exact_hit','exact_proxy_reference_delta_mm'))
            assert row['own_reference_verified'] is False
        else:
            assert all(type(row[k]) is int and row[k]>=0 for k in COST_METRICS)
            assert row['normalized_own_cost']==row['base_'+row['proxy']]
        if row['own_reference_verified']:
            assert row['valid'] and type(row['own_gap_mm']) is int and row['own_gap_mm']>=0
            assert row['exact_hit'] is (row['own_gap_mm']==0)
        else:
            assert row['own_gap_mm'] is row['own_gap_percent'] is row['exact_hit'] is None


def build_summary(rows,fields):
    validate_panel_rows(rows,fields)
    pairs={proxy:pair_rows(rows,fields,proxy) for proxy in PROXIES}
    per_field=[]
    for field in fields:
        selected=[r for r in rows if r['instance_id']==field]
        local_pairs={p:[r for r in pairs[p] if r['instance_id']==field] for p in PROXIES}
        per_field.append({'instance_id':field,'seeds':list(SEEDS),'slots':12,
            'valid_feasible':sum(r['valid'] for r in selected),
            'by_proxy':{p:{'arms':{a:summarize_arm([r for r in selected if r['proxy']==p and r['arm']==a]) for a in ARMS},
                           'pairs':summarize_pairs(local_pairs[p])} for p in PROXIES},
            'E_search_A_to_P_G':cross_G_signs(local_pairs['E'])})
    cross=cross_G_signs(pairs['E'])
    cross['statistical_unit']='124 fields; 372 seed pairs are within-field repeated measurements'
    cross['equal_field_weight']=equal_field_cross_G([f['E_search_A_to_P_G'] for f in per_field])
    return {'by_proxy':{proxy:{'arms':{arm:summarize_arm([r for r in rows if r['proxy']==proxy and r['arm']==arm]) for arm in ARMS},
                             'pairs':summarize_pairs(pairs[proxy])} for proxy in PROXIES},
        'overall':{'arms':{arm:summarize_arm([r for r in rows if r['arm']==arm]) for arm in ARMS},
                   'mixed_proxy_costs_are_descriptive_only':True},
        'per_field':per_field,
        'field_level_summary':{p:{a:field_level_arm([f['by_proxy'][p]['arms'][a] for f in per_field]) for a in ARMS} for p in PROXIES},
        'paired_rows':pairs,'secondary_cross_G_on_E_pairs':cross,
        'P_invariant_transfer':{proxy:summarize_observations([r for r in rows if r['proxy']==proxy and r['arm']=='P']) for proxy in PROXIES},
        'pooled_record_verified_slots':sum(r['record_verified'] for r in rows),
        'pooled_unconfirmed_possible_call_slots':sum(r['process_spawned'] is not False and not r['record_verified'] for r in rows),
        'pooled_known_process_spawned':sum(r['process_spawned'] is True for r in rows),
        'pooled_unknown_process_spawned':sum(r['process_spawned'] is None for r in rows),
        'pooled_known_not_spawned':sum(r['process_spawned'] is False for r in rows)}
