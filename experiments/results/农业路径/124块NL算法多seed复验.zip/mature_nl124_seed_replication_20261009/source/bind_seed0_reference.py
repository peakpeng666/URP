"""Post-new-RAW binding of original audited seed0 rows; never re-run seed0."""
from pathlib import Path
import json,hashlib,zipfile,resource,signal
from common import ROOT,read,save,sha,now,receipt,verify_frozen
from bind_reference import private_readback
SOURCE=Path('/workspace/shared/mature_unseen_nl_field_execution_20261009')
PREFIX='mature_unseen_nl_field_execution_20261009/'


def digest(data):return hashlib.sha256(data).hexdigest()


def main():
    resource.setrlimit(resource.RLIMIT_CPU,(120,120));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,1536*1024**2));signal.alarm(480)
    verify_frozen();raw=receipt('RAW_UNREVIEWED')
    parent=read('parent_identity/SEED0_FINAL_IDENTITY.json')
    source_receipt=(SOURCE/'provenance/FINAL_REVIEWED_DRIVE_RECEIPT.json').read_bytes();final=json.loads(source_receipt)
    private_readback(final,'FINAL_REVIEWED')
    assert final['sha256']==parent['final_archive_sha256']=='79af111bc684d999bffa36b5557330db40694007d50e9a54b4c8b66f7223072e'
    files={};base='postprocess_reference/seed0/'
    with zipfile.ZipFile(final['download_path']) as archive:
        assert len(archive.namelist())==len(set(archive.namelist()))
        def member(name):return archive.read(PREFIX+name)
        frozen_bytes=member('freeze/FROZEN_FILES.json');assert digest(frozen_bytes)==parent['final_frozen_files_sha256']
        for name,meta in json.loads(frozen_bytes)['files'].items():
            data=member(name);assert len(data)==meta['bytes'] and digest(data)==meta['sha256']
        raw_manifest=json.loads(member('raw/RAW_UNREVIEWED_MANIFEST.json'))
        for name,meta in raw_manifest['files'].items():
            data=member(name);assert len(data)==meta['bytes'] and digest(data)==meta['sha256']
        summary_bytes=member('reports/SUMMARY.json');audit_bytes=member('independent_supervision/results/SAVED_UNSEEN_AUDIT.json')
        assert digest(summary_bytes)==parent['summary_sha256']=='31b277ec94df43ff9802029abe6ee4b59c235e557301bf81b959a69b33622815'
        assert digest(audit_bytes)==parent['saved_audit_sha256']
        summary=json.loads(summary_bytes);audit=json.loads(audit_bytes)
        review=json.loads(member('independent_supervision/results/FINAL_REPORT_REVIEW.json'))
        assert review['status']=='PASS' and audit['status']=='SAVED_UNSEEN_AUDITED'
        assert review['summary_sha256']==digest(summary_bytes) and review['independent_audit_sha256']==digest(audit_bytes)
        assert review['report_sha256']==digest(member('reports/REPORT_ZH.txt'))
        assert review['frozen_files_sha256']==parent['final_frozen_files_sha256']
        assert review['raw_archive_sha256']==summary['raw_archive_sha256']==audit['raw_archive_sha256']
        assert summary['planned_slots']==496 and len(summary['rows'])==len(audit['rows'])==496
        assert all(row['seed']==0 for row in summary['rows'])
        assert summary['input_final_archive_sha256']==read('upstream_identity/FINAL_INPUT_PACKAGE_IDENTITY.json')['upstream_final_archive_sha256']
        assert summary['reference_truth_sha256']==sha(ROOT/'postprocess_reference/EXACT_REFERENCE.json')
        mapping={'reports/SUMMARY.json':base+'SUMMARY.json',
            'independent_supervision/results/SAVED_UNSEEN_AUDIT.json':base+'SAVED_UNSEEN_AUDIT.json',
            'independent_supervision/results/FINAL_REPORT_REVIEW.json':base+'FINAL_REPORT_REVIEW.json',
            'freeze/FROZEN_FILES.json':base+'FROZEN_FILES.json',
            'raw/RAW_UNREVIEWED_MANIFEST.json':base+'RAW_UNREVIEWED_MANIFEST.json',
            'provenance/RAW_UNREVIEWED_DRIVE_RECEIPT.json':base+'RAW_UNREVIEWED_DRIVE_RECEIPT.json'}
        (ROOT/base).mkdir(exist_ok=False)
        for original,relative in mapping.items():
            data=member(original)
            with (ROOT/relative).open('xb') as handle:handle.write(data)
            files[relative]={'bytes':len(data),'sha256':digest(data),'archive_member':PREFIX+original}
    relative=base+'FINAL_REVIEWED_DRIVE_RECEIPT.json'
    with (ROOT/relative).open('xb') as handle:handle.write(source_receipt)
    files[relative]={'bytes':len(source_receipt),'sha256':digest(source_receipt),'archive_member':None}
    binding={'utc':now(),'status':'SEED0_FINAL_ORIGINAL_BYTES_BOUND_AFTER_ALGORITHM_RAW',
        'algorithm_raw_archive_sha256':raw['sha256'],'seed0_final_archive_sha256':final['sha256'],
        'seed0_summary_sha256':digest(summary_bytes),'files':files,'new_native_calls':0,'new_solver_calls':0,'new_exact_computations':0,
        'seed0_rerun':False,'scope':'Original audited496 rows reused only for within-field3seed saved analysis; no historical row selection'}
    save(ROOT/base/'ORIGINAL_FINAL_BINDING.json',binding)
    from report import checked_seed0
    fields=read('design/SEED_REPLICATION_PRECOMMIT.json')['fields']
    checked_seed0(raw['sha256'],summary['input_final_archive_sha256'],summary['reference_truth_sha256'],fields)
    signal.alarm(0)
    print(json.dumps({'seed0_final_sha256':final['sha256'],'reused_seed0_rows':496,'new_native_calls':0}))

if __name__=='__main__':main()
