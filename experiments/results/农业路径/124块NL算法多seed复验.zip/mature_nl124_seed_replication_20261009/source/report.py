"""Saved-only 1488-row repeated-seed report, gated by this batch RAW readback.

No solver, native construction, exact optimization, geometry or shortest paths.
"""
import json,math,hashlib,resource,signal
from pathlib import Path
from common import ROOT,read,save,sha,now,verify_frozen,receipt
from report_core import blank_row,apply_checked,apply_reference,build_summary,ROW_AUDIT_KEYS,PROXIES,ARMS,SEEDS
from input_projection import project_payload


def checked_truth(raw_sha):
    binding=read('postprocess_reference/REFERENCE_BINDING.json')
    assert binding['status']=='EXACT_FINAL_ORIGINAL_BYTES_BOUND_AFTER_ALGORITHM_RAW'
    assert binding['algorithm_raw_archive_sha256']==raw_sha
    for relative,meta in binding['files'].items():
        path=ROOT/relative
        assert path.stat().st_size==meta['bytes'] and sha(path)==meta['sha256']
    truth=read('postprocess_reference/EXACT_REFERENCE.json')
    assert truth['status']=='EXACT_REFERENCE_AUDITED' and truth['planned_fields']==124
    assert all(truth[key] is True for key in ('input_final_actual_readback','raw_main_actual_readback','raw_verification_actual_readback'))
    input_binding=read('upstream_identity/FINAL_INPUT_PACKAGE_IDENTITY.json')
    assert truth['input_final_archive_sha256']==input_binding['upstream_final_archive_sha256']
    assert truth['input_final_frozen_files_sha256']==input_binding['upstream_frozen_files_sha256']
    for key in ('frozen_files_sha256','raw_main_archive_sha256','raw_verification_archive_sha256','independent_audit_sha256'):
        assert truth[key]==binding[key]
    assert len(truth['fields'])==124
    fields=read('upstream_identity/PANEL_SOURCE_IDENTITY.json')['field_ids_in_source_order']
    assert [r['instance_id'] for r in truth['fields']]==fields
    identities=read('input/IDENTITIES.json')['fields']
    for record in truth['fields']:
        field=record['instance_id'];assert record['input_preprocess_sha256']==identities[field]['preprocess_sha256']
        objectives=record['objectives'];assert set(objectives)=={'E_G','G_E'}
        for key in ('E_G','G_E'):
            target=objectives[key];assert type(target['verified']) is bool
            if target['verified']:
                assert target['failure'] is None
                assert all(type(target[p]) is int and target[p]>=0 for p in ('E','G'))
            else:
                assert target['failure'] is not None
                assert all(target[k] is None for k in ('E','G','canonical_routes','partition'))
        both=all(target['verified'] for target in objectives.values())
        assert record['valid_for_exact_conclusion'] is both
        assert record['E_star']==(objectives['E_G']['E'] if objectives['E_G']['verified'] else None)
        assert record['G_star']==(objectives['G_E']['G'] if objectives['G_E']['verified'] else None)
        assert record['delta_integer_mm']==(objectives['E_G']['G']-objectives['G_E']['G'] if both else None)
    return {r['instance_id']:r for r in truth['fields']},binding


def checked_reference_routes(reference,problem):
    from endpoint_core import route_cost
    for target in reference['objectives'].values():
        if not target['verified']:continue
        routes=target['canonical_routes'];assert isinstance(routes,list) and len(routes)==3
        seen=[];groups=[]
        for route in routes:
            assert isinstance(route,list) and 3<=len(route)<=7 and route[0]==route[-1]==0
            assert all(type(v) is int and 1<=v<=12 for v in route[1:-1])
            seen.extend(route[1:-1]);groups.append(sorted(route[1:-1]))
        assert sorted(seen)==list(range(1,13))
        # Partition encoding is retained unchanged; closed-route coverage/costs suffice here.
        for proxy in ('E','G'):
            assert route_cost(problem['matrices'][proxy],routes)==target[proxy]


PRECOMMIT_SHA='b4aac52014276b42870332fb4bab6f7abe15a740e280059c7c0480aa8db8db4b'
SEED0_FINAL_SHA='79af111bc684d999bffa36b5557330db40694007d50e9a54b4c8b66f7223072e'
SEED0_SUMMARY_SHA='31b277ec94df43ff9802029abe6ee4b59c235e557301bf81b959a69b33622815'
SEED0_SECTIONS=('by_proxy','overall','per_field','paired_rows','secondary_cross_G_on_E_pairs','P_invariant_transfer')
SECTIONS=('by_proxy','overall','per_field','field_level_summary','paired_rows','secondary_cross_G_on_E_pairs','P_invariant_transfer')


def exact_match(expected,actual,path='root'):
    if isinstance(expected,dict):
        assert isinstance(actual,dict) and set(expected)==set(actual),path+'.keys'
        for key,value in expected.items():
            assert key in actual,path+'.'+key;exact_match(value,actual[key],path+'.'+key)
    elif isinstance(expected,list):
        assert isinstance(actual,list) and len(expected)==len(actual),path
        for i,(left,right) in enumerate(zip(expected,actual)):exact_match(left,right,path+'['+str(i)+']')
    elif isinstance(expected,float):
        assert type(actual) in (float,int) and math.isclose(expected,actual,rel_tol=1e-12,abs_tol=1e-12),path
    else:assert type(expected) is type(actual) and expected==actual,path


def checked_seed0(raw_sha,input_sha,truth_sha,fields):
    """Verify bound, already-audited seed0 rows; never reopen its native output."""
    base='postprocess_reference/seed0/'
    binding=read(base+'ORIGINAL_FINAL_BINDING.json')
    assert binding['status']=='SEED0_FINAL_ORIGINAL_BYTES_BOUND_AFTER_ALGORITHM_RAW'
    assert binding['algorithm_raw_archive_sha256']==raw_sha
    assert binding['seed0_final_archive_sha256']==SEED0_FINAL_SHA
    assert binding['seed0_summary_sha256']==SEED0_SUMMARY_SHA
    assert {base+'SUMMARY.json',base+'SAVED_UNSEEN_AUDIT.json'}<=set(binding['files'])
    for relative,meta in binding['files'].items():
        path=(ROOT/relative).resolve()
        assert path.is_relative_to((ROOT/base).resolve())
        assert path.stat().st_size==meta['bytes'] and sha(path)==meta['sha256']
    assert sha(ROOT/base/'SUMMARY.json')==SEED0_SUMMARY_SHA
    data=read(base+'SUMMARY.json');audit=read(base+'SAVED_UNSEEN_AUDIT.json')
    assert data['status']=='INDEPENDENT_SAVED_VERIFIED_PENDING_REPORT_REVIEW'
    assert data['independent_saved_audit_sha256']==sha(ROOT/base/'SAVED_UNSEEN_AUDIT.json')
    assert audit['status']=='SAVED_UNSEEN_AUDITED'
    assert data['input_final_archive_sha256']==input_sha and data['reference_truth_sha256']==truth_sha
    for key in ('raw_archive_sha256','frozen_files_sha256','reference_truth_sha256','input_final_archive_sha256'):
        assert audit[key]==data[key]
    assert data['planned_slots']==496 and data['field_denominator']==124
    assert data['planned_per_arm_proxy']==124 and data['seeds_per_field']==1
    assert len(data['rows'])==len(audit['rows'])==496
    expected={(field,proxy,arm) for field in fields for proxy in PROXIES for arm in ARMS}
    assert {(r['instance_id'],r['proxy'],r['arm']) for r in data['rows']}==expected
    indexed={r['call_id']:r for r in audit['rows']};assert len(indexed)==496
    assert set(indexed)=={r['call_id'] for r in data['rows']}
    for row in data['rows']:
        assert type(row['seed']) is int and row['seed']==0
        assert row['call_id']==f"{row['instance_id']}_{row['proxy']}_s0_{row['arm']}_i250"
        for key in ROW_AUDIT_KEYS:exact_match(indexed[row['call_id']][key],row[key],row['call_id']+'.'+key)
    for key in SEED0_SECTIONS:exact_match(audit[key],data[key],key)
    return data['rows'],binding


def collect_saved_evidence():
    from endpoint_core import validate_saved
    from gates import get_schedule,verify_input_binding
    from ledger import reconcile
    digest=verify_frozen();input_sha=verify_input_binding();raw=receipt('RAW_UNREVIEWED')
    assert sha(ROOT/'freeze/PRECOMMIT_LOCK.json')==PRECOMMIT_SHA
    precommit=read('design/SEED_REPLICATION_PRECOMMIT.json');fields=precommit['fields']
    preseal=read('raw/PRESEAL_IDENTITY_VERIFICATION.json')
    assert preseal['frozen_files_sha256']==digest
    assert preseal['old_manifest_sha256']==sha(ROOT/'freeze/OLD_FILES_BEFORE.json')
    assert preseal['old_files_verified_unchanged']==len(read('freeze/OLD_FILES_BEFORE.json')['files'])
    schedule=get_schedule('formal')
    slots=read('raw/ALL_PLANNED_SLOTS.json');outer=read('raw/EXECUTOR_FINISHED.json')
    assert len(schedule)==len(slots)==992 and [r['schedule'] for r in slots]==schedule
    assert outer['cleanup']['quiescent'] is True
    results=(ROOT/'raw/results.jsonl').read_text() if (ROOT/'raw/results.jsonl').exists() else ''
    attempts=(ROOT/'raw/attempts.jsonl').read_text() if (ROOT/'raw/attempts.jsonl').exists() else ''
    recovered,errors=reconcile(schedule,results,attempts)
    assert slots==recovered and errors==outer['ledger_errors']
    references,reference_binding=checked_truth(raw['sha256'])
    identities=read('input/IDENTITIES.json')['fields'];problems={};new_rows=[]
    assert set(identities)==set(fields)
    for field,identity in identities.items():
        if not identity['native_ready']:continue
        preprocess=read(identity['local_input_path'])
        problem={key:preprocess[key] for key in ('coordinates','demands','capacity','K')}
        problem['matrices']=preprocess['integer_matrices'];problem['preprocess']=preprocess
        checked_reference_routes(references[field],problem);problems[field]=problem
    for entry,slot in zip(schedule,slots):
        assert type(entry['seed']) is int and entry['seed'] in (1,2)
        row=blank_row(entry,slot)
        try:
            assert slot['status'] in ('UNREVIEWED_PROCESS_SUCCESS','UNREVIEWED_INFEASIBLE'),'NON_SUCCESS_PROCESS_STATUS'
            assert slot['returncode']==0 and slot['process_spawned'] is True and slot['child_reaped'] is True
            assert not errors,'LEDGER_INTEGRITY_FAILURE'
            stdout=(ROOT/slot['stdout']).resolve();stderr=(ROOT/slot['stderr']).resolve()
            assert all(p.is_relative_to((ROOT/'raw/calls').resolve()) for p in (stdout,stderr))
            assert sha(stdout)==slot['stdout_sha256'] and sha(stderr)==slot['stderr_sha256'],'RAW_OUTPUT_HASH_MISMATCH'
            problem=problems[entry['instance_id']]
            payload=project_payload(problem['preprocess'],entry['proxy'],entry['arm'],entry['seed'])
            encoded=json.dumps(payload,separators=(',',':')).encode()
            assert hashlib.sha256(encoded).hexdigest()==slot['payload_sha256'],'WORKER_PAYLOAD_IDENTITY_MISMATCH'
            answer=json.loads(stdout.read_text());checked=validate_saved(problem,entry,answer)
            assert checked['valid']==(slot['status']=='UNREVIEWED_PROCESS_SUCCESS')
            apply_checked(row,checked,answer)
        except (AssertionError,KeyError,TypeError,ValueError,OSError,IndexError,OverflowError) as exc:
            row=blank_row(entry,slot);row['failure']=type(exc).__name__+':'+str(exc)
        apply_reference(row,references[entry['instance_id']]);new_rows.append(row)
    # Deliberately after this batch's RAW gate and new saved-output pass.
    truth_sha=sha(ROOT/'postprocess_reference/EXACT_REFERENCE.json')
    seed0_rows,seed0_binding=checked_seed0(raw['sha256'],input_sha,truth_sha,fields)
    rows=seed0_rows+new_rows;summary=build_summary(rows,fields)
    return {'utc':now(),'status':'AUTHOR_SAVED_REPORT_COMPLETE_PENDING_INDEPENDENT_REVIEW',
        'frozen_files_sha256':digest,'precommit_lock_sha256':PRECOMMIT_SHA,
        'raw_archive_sha256':raw['sha256'],'input_final_archive_sha256':input_sha,
        'reference_final_archive_sha256':reference_binding['reference_final_archive_sha256'],
        'reference_truth_sha256':truth_sha,
        'seed0_final_archive_sha256':seed0_binding['seed0_final_archive_sha256'],
        'seed0_summary_sha256':SEED0_SUMMARY_SHA,
        'seed0_original_binding_sha256':sha(ROOT/'postprocess_reference/seed0/ORIGINAL_FINAL_BINDING.json'),
        'planned_slots':1488,'new_planned_slots':992,'reused_seed0_planned_slots':496,
        'field_denominator':124,'planned_per_arm_proxy':372,'seeds_per_field':3,'seeds':list(SEEDS),
        'formal_known_spawned':outer['known_spawned'],'formal_unknown_spawned_slots':outer['unknown_spawned_slots'],
        'confirmed_model_and_solver_calls':sum(r['record_verified'] for r in new_rows),
        'unconfirmed_possible_model_or_solver_calls':sum(r['process_spawned'] is not False and not r['record_verified'] for r in new_rows),
        'reused_seed0_verified_slots':sum(r['record_verified'] for r in seed0_rows),
        'call_count_scope':'formal/confirmed call counts refer only to the additional 992 slots; seed0 has 496 reused saved rows and no rerun.',
        'ledger_errors':errors,'new_solver_calls_in_report':0,'new_native_constructions_in_report':0,
        'new_exact_computations_in_report':0,'historical_development_cells_in_statistics':0,
        'rows':rows,**summary,'analysis_commitments':precommit['analysis'],
        'complete_panel_policy':'Any missing required endpoint yields null complete-panel mean. Conditional subset denominator is shown.',
        'primary_statistical_unit':'124 fixed fields; seeds0,1,2 are within-field repeated measurements, not372 independent fields.',
        'scope':'Same124-field seed replication; not a new unseen-field test set; descriptive only, without significance, speed or IID claims.'}


def check_independent(data,audit):
    assert audit['status']=='SAVED_SEED_REPLICATION_AUDITED'
    for key in ('raw_archive_sha256','frozen_files_sha256','reference_truth_sha256','input_final_archive_sha256',
                'precommit_lock_sha256','seed0_final_archive_sha256','seed0_summary_sha256','seed0_original_binding_sha256'):
        assert audit[key]==data[key]
    for key in ('planned_slots','new_planned_slots','reused_seed0_planned_slots','field_denominator','planned_per_arm_proxy','seeds_per_field'):
        assert audit[key]==data[key]
    assert len(audit['rows'])==len(data['rows'])==1488
    indexed={r['call_id']:r for r in audit['rows']};assert len(indexed)==1488
    assert set(indexed)=={r['call_id'] for r in data['rows']}
    for row in data['rows']:
        for key in ROW_AUDIT_KEYS:exact_match(indexed[row['call_id']][key],row[key],row['call_id']+'.'+key)
    for key in SECTIONS:exact_match(audit[key],data[key],key)
    for key in ('formal_known_spawned','formal_unknown_spawned_slots',
                'confirmed_model_and_solver_calls','unconfirmed_possible_model_or_solver_calls',
                'reused_seed0_verified_slots','pooled_record_verified_slots',
                'pooled_unconfirmed_possible_call_slots','pooled_known_process_spawned',
                'pooled_unknown_process_spawned','pooled_known_not_spawned'):
        exact_match(audit[key],data[key],key)
    return ['1488rows=496fixed_seed0+992new',*SECTIONS]


def readable(value,unit=''):
    return '不可估计' if value is None else f'{value}{unit}'


def report_text(data):
    lines=['同124块NL田重复种子验证：seed0固定复用，追加seed1、2',
        '这是相同124田的随机性重复验证，不是新未见集。独立田分母始终124；每arm/proxy的372次为田内3seed重复测量。',
        'E/G×默认A/固定P、250次ILS均不变。P=15×当前单矩阵最大边+1；公开min=max固定。',
        'n12、单位需求、Q5、最多3车、完整覆盖、单趟、非负整数距离。',
        f"本轮计划992槽，已知启动{data['formal_known_spawned']}，启动未知{data['formal_unknown_spawned_slots']}；本轮完整记录确认model/solver各{data['confirmed_model_and_solver_calls']}，另有{data['unconfirmed_possible_model_or_solver_calls']}槽可能调用但未确认。",
        '原seed0的496个已审槽仅复用，不重新调用。三seed分析保留全部1488槽。','']
    for proxy in PROXIES:
        for arm in ARMS:
            pooled=data['by_proxy'][proxy]['arms'][arm];field=data['field_level_summary'][proxy][arm]
            counts=field['count_distributions']
            lines.append(f"{proxy}/{arm}：已核可行{pooled['valid_feasible']}/372，已核原生不可行{pooled['verified_native_infeasible']}，技术/未知/未运行{pooled['technical_or_unverified_or_not_run']}；自身精确确认命中{pooled['confirmed_exact_hits']}/372，可行但真值未评分{pooled['exact_unscored_valid']}。")
            lines.append(f"  124田的可行seed数0/1/2/3分布：{counts['valid_feasible']}；自身精确确认命中seed数0/1/2/3分布：{counts['confirmed_exact_hits']}。")
            lines.append(f"  等田权平均已核可行分数{field['equal_field_weight_mean_feasible_fraction']}，平均自身精确确认命中yield{field['equal_field_weight_mean_confirmed_own_exact_fraction']}。分母每田3个计划seed；未评分/未知不称为已观测未命中。")
        lines.append('')
    cross=data['secondary_cross_G_on_E_pairs'];equal=cross['equal_field_weight']
    lines += [f"E搜索A→P的G实现差=P路线G成本−A路线G成本：共同成功{cross['common_success']}/372，排除/缺失{cross['excluded_or_missing']}；正{cross['positive']}、零{cross['zero']}、负{cross['negative']}。",
        f"等田权条件均值{readable(equal['conditional_equal_field_mean_mm'],'mm')}，有至少1个共同成功pair的田{equal['fields_with_available_pairs']}/124；每田有效pair数0/1/2/3分布{equal['available_pair_count_distribution']}。",
        f"完整124田×3pair等田权均值{readable(equal['complete_panel_equal_field_mean_mm'],'mm')}。逐田逐seed配对见paired_rows；逐田正零负、共同成功和排除分母见per_field。",'',
        '解释与限制：',
        '- 可行性、原生不可行、技术/未知与真值未评分分开；失败成本为null，所有计划槽保留，不替换、不修复、不重试。',
        '- 自身目标gap/命中、精确代理参考Delta、相对E_G的有符号跨目标偏移、处理配对DeltaG保持分开。真值缺失仅使依赖该目标的指标为null，不降低已核路线可行性。',
        '- P的初始化/current/best条件可行不变式迁移，与有限250ILS预算的解质量和精确命中分别报告。内部扰动候选不受完整性定理保证。',
        '- 条件均值明确有效分母；任何所需观测缺失都使相应完整面板均值为null。372次不是372块独立田，不作IID、显著性、速度或新未见集结论。',
        '- G为冻结有限候选图路径代理，不是连续平面全局最短路；P(sD)=sU+1不是sP，不宣称完整算法轨迹单位不变。',
        '- 精确参照和原seed0已审行仅在本轮RAW实际私有原字节回读后绑定；worker只接收本次当前单矩阵。后处理新增solver/native/精确求解均0。',
        '- 1488行和7组科学汇总均须与独立保存证据审计逐项一致。']
    return '\n'.join(lines)+'\n'


def main():
    resource.setrlimit(resource.RLIMIT_CPU,(120,120));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,1536*1024**2));signal.alarm(480)
    data=collect_saved_evidence();audit_path='independent_supervision/results/SAVED_SEED_REPLICATION_AUDIT.json'
    compared=check_independent(data,read(audit_path))
    data['status']='INDEPENDENT_SAVED_VERIFIED_PENDING_REPORT_REVIEW'
    data['independent_saved_audit_sha256']=sha(ROOT/audit_path);data['independently_compared_sections']=compared
    save(ROOT/'reports/STARTED.json',{'utc':now(),'solver_calls':0,'native_constructions':0,'exact_computations':0,'independent_comparison_before_write':True})
    save(ROOT/'reports/SUMMARY.json',data)
    with (ROOT/'reports/REPORT_ZH.txt').open('x') as handle:handle.write(report_text(data))
    print(json.dumps({'report':'reports/REPORT_ZH.txt','planned_slots':1488,'new_planned_slots':992,'independently_compared_sections':compared}))

if __name__=='__main__':main()
