"""Post-RAW-only original-byte binding of independently audited exact references.

Never imported by the native execution gate, supervisor, or worker.
"""
from pathlib import Path
import json,hashlib,zipfile,resource,signal
from common import ROOT,read,save,sha,now,receipt,verify_frozen

SOURCE=Path('/workspace/shared/nl124_capacitated_exact_reference_20261009')


def digest(data):return hashlib.sha256(data).hexdigest()


def private_readback(rec,stage):
    assert rec['stage']==stage and rec['status']=='ARCHIVE_VERIFIED'
    assert rec['owner_only'] is True and rec['shared'] is False
    assert rec['remote_readback_sha256_verified'] is True and rec['download_byte_identical'] is True
    assert rec['sha256']==rec['download_sha256']==sha(Path(rec['download_path']))==sha(Path(rec['source']))
    assert Path(rec['download_path']).stat().st_size==rec['bytes']


def main():
    resource.setrlimit(resource.RLIMIT_CPU,(120,120));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,1536*1024**2));signal.alarm(480)
    # This gate is deliberately first: never read reference artifacts pre-RAW.
    verify_frozen();algorithm_raw=receipt('RAW_UNREVIEWED')
    source_receipt=(SOURCE/'provenance/FINAL_DRIVE_RECEIPT.json').read_bytes();final=json.loads(source_receipt)
    private_readback(final,'FINAL')
    files={}
    with zipfile.ZipFile(final['download_path']) as archive:
        assert len(archive.namelist())==len(set(archive.namelist()))
        frozen_bytes=archive.read('freeze/FROZEN_FILES.json')
        assert digest(frozen_bytes)==final['frozen_files_sha256']
        for name,meta in json.loads(frozen_bytes)['files'].items():
            data=archive.read(name);assert len(data)==meta['bytes'] and digest(data)==meta['sha256']
        truth_bytes=archive.read('truth/EXACT_REFERENCE.json');truth=json.loads(truth_bytes)
        assert truth['status']=='EXACT_REFERENCE_AUDITED' and truth['planned_fields']==124
        assert all(truth[key] is True for key in ('input_final_actual_readback','raw_main_actual_readback','raw_verification_actual_readback'))
        assert truth['frozen_files_sha256']==final['frozen_files_sha256']
        input_identity=read('upstream_identity/FINAL_INPUT_PACKAGE_IDENTITY.json')
        assert truth['input_final_archive_sha256']==input_identity['upstream_final_archive_sha256']
        assert truth['input_final_frozen_files_sha256']==input_identity['upstream_frozen_files_sha256']
        audit_bytes=archive.read('independent_supervision/FINAL_AUDIT.json');audit=json.loads(audit_bytes)
        assert audit['status'] in ('PASS','AUDIT_COMPLETE_WITH_UNVERIFIED_SLOTS')
        assert digest(audit_bytes)==truth['independent_audit_sha256']
        review_bytes=archive.read('independent_supervision/FINAL_REPORT_REVIEW.json');review=json.loads(review_bytes)
        assert review['status']=='PASS'
        assert review['truth_sha256']==digest(truth_bytes)
        assert review['independent_audit_sha256']==digest(audit_bytes)
        assert review['report_sha256']==digest(archive.read('reports/REPORT_ZH.txt'))
        assert review['summary_sha256']==digest(archive.read('reports/SUMMARY.json'))
        for key in ('frozen_files_sha256','raw_main_archive_sha256','raw_verification_archive_sha256'):
            assert review[key]==truth[key]
        for stage,key in [('RAW_MAIN','raw_main_archive_sha256'),('RAW_VERIFICATION','raw_verification_archive_sha256')]:
            rec=json.loads(archive.read('provenance/'+stage+'_DRIVE_RECEIPT.json'));private_readback(rec,stage)
            assert rec['sha256']==truth[key] and rec['frozen_files_sha256']==truth['frozen_files_sha256']
        field_ids=read('upstream_identity/PANEL_SOURCE_IDENTITY.json')['field_ids_in_source_order']
        assert [r['instance_id'] for r in truth['fields']]==field_ids
        for record in truth['fields']:
            expected=read('input/IDENTITIES.json')['fields'][record['instance_id']]
            assert record['input_preprocess_sha256']==expected['preprocess_sha256']
        mapping={'truth/EXACT_REFERENCE.json':'postprocess_reference/EXACT_REFERENCE.json',
            'freeze/FROZEN_FILES.json':'postprocess_reference/FROZEN_FILES.json',
            'independent_supervision/FINAL_AUDIT.json':'postprocess_reference/FINAL_AUDIT.json',
            'independent_supervision/FINAL_REPORT_REVIEW.json':'postprocess_reference/FINAL_REPORT_REVIEW.json',
            'provenance/RAW_MAIN_DRIVE_RECEIPT.json':'postprocess_reference/RAW_MAIN_DRIVE_RECEIPT.json',
            'provenance/RAW_VERIFICATION_DRIVE_RECEIPT.json':'postprocess_reference/RAW_VERIFICATION_DRIVE_RECEIPT.json'}
        (ROOT/'postprocess_reference').mkdir(exist_ok=False)
        for member,relative in mapping.items():
            data=archive.read(member)
            with (ROOT/relative).open('xb') as handle:handle.write(data)
            files[relative]={'bytes':len(data),'sha256':digest(data),'archive_member':member}
    relative='postprocess_reference/FINAL_DRIVE_RECEIPT.json'
    with (ROOT/relative).open('xb') as handle:handle.write(source_receipt)
    files[relative]={'bytes':len(source_receipt),'sha256':digest(source_receipt),'archive_member':None}
    binding={'utc':now(),'status':'EXACT_FINAL_ORIGINAL_BYTES_BOUND_AFTER_ALGORITHM_RAW',
        'algorithm_raw_archive_sha256':algorithm_raw['sha256'],'reference_final_archive_sha256':final['sha256'],
        'reference_final_drive_id':final['drive_id'],'files':files,'new_native_calls':0,'new_solver_calls':0,'new_exact_computations':0}
    for key in ('frozen_files_sha256','raw_main_archive_sha256','raw_verification_archive_sha256','independent_audit_sha256'):binding[key]=truth[key]
    save(ROOT/'postprocess_reference/REFERENCE_BINDING.json',binding)
    from report import checked_truth
    checked_truth(algorithm_raw['sha256'])
    signal.alarm(0)
    print(json.dumps({'reference_final_archive_sha256':final['sha256'],'fields':124,'new_native_calls':0}))

if __name__=='__main__':main()
