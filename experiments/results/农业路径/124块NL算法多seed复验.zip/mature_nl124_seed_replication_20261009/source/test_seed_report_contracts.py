"""Fictional scalar/JSON report-contract tests only; no native or scientific data reads."""
import copy,json,sys,unittest
from report_core import (ARMS,PROXIES,SEEDS,blank_row,apply_checked,apply_reference,
                         build_summary,ROW_AUDIT_KEYS,validate_panel_rows)
from report import check_independent,SECTIONS


def fictional_rows():
    fields=[f'nl_field_{i}' for i in range(124)]
    rows=[]
    for field in fields:
        for proxy in PROXIES:
            for seed in SEEDS:
                for arm in ARMS:
                    entry={'call_id':f'{field}_{proxy}_s{seed}_{arm}_i250','instance_id':field,
                           'proxy':proxy,'seed':seed,'arm':arm,'scale':1,'max_iterations':250}
                    rows.append(blank_row(entry,{'status':'NOT_STARTED_SUPERVISOR_FAILURE','process_spawned':False}))
    return fields,rows


def make_feasible(row,E=10,G=30):
    checked={'valid':True,'routing_violation':False,'base_E':E,'base_G':G,
             'normalized_own_cost':E if row['proxy']=='E' else G,
             'observations':{},'routes':[],'loads':[]}
    row.update(raw_status='UNREVIEWED_PROCESS_SUCCESS',process_spawned=True)
    apply_checked(row,checked,{'reported_cost':checked['normalized_own_cost']})
    return row


class ReportContracts(unittest.TestCase):
    def test_all1488_missing_retained(self):
        fields,rows=fictional_rows();data=build_summary(rows,fields)
        self.assertEqual(data['pooled_known_not_spawned'],1488)
        self.assertEqual(data['pooled_record_verified_slots'],0)
        for p in PROXIES:
            for a in ARMS:
                arm=data['by_proxy'][p]['arms'][a]
                self.assertEqual((arm['planned'],arm['valid_feasible'],arm['verified_native_infeasible'],arm['technical_or_unverified_or_not_run']),(372,0,0,372))
                self.assertIsNone(arm['metrics']['normalized_own_cost']['complete_panel_mean'])
                field=data['field_level_summary'][p][a]
                self.assertEqual(field['count_distributions']['technical_or_unverified_or_not_run'],{'0':0,'1':0,'2':0,'3':124})
                self.assertEqual(field['count_distributions']['confirmed_exact_hits'],{'0':124,'1':0,'2':0,'3':0})
        cross=data['secondary_cross_G_on_E_pairs']
        self.assertEqual((cross['planned_E_pairs'],cross['common_success'],cross['excluded_or_missing']),(372,0,372))
        self.assertIsNone(cross['equal_field_weight']['conditional_equal_field_mean_mm'])

    def test_missing_truth_does_not_reduce_feasibility(self):
        fields,rows=fictional_rows()
        for row in rows:make_feasible(row)
        data=build_summary(rows,fields)
        for p in PROXIES:
            for a in ARMS:
                arm=data['by_proxy'][p]['arms'][a]
                self.assertEqual((arm['valid_feasible'],arm['exact_scored_valid'],arm['exact_unscored_valid']),(372,0,372))
                self.assertIsNone(arm['metrics']['own_gap_mm']['complete_panel_mean'])
                self.assertEqual(data['field_level_summary'][p][a]['equal_field_weight_mean_feasible_fraction'],1)
        self.assertEqual(data['secondary_cross_G_on_E_pairs']['equal_field_weight']['complete_panel_equal_field_mean_mm'],0)

    def test_conditional_equal_field_weight_is_not_pooled_pairs(self):
        fields,rows=fictional_rows()
        for row in rows:
            if row['proxy']!='E':continue
            if row['instance_id']==fields[0]:
                make_feasible(row,G=30+(3 if row['arm']=='P' else 0))
            elif row['instance_id']==fields[1] and row['seed']==0:
                make_feasible(row,G=30+(9 if row['arm']=='P' else 0))
        data=build_summary(rows,fields);cross=data['secondary_cross_G_on_E_pairs'];equal=cross['equal_field_weight']
        self.assertEqual((cross['common_success'],cross['excluded_or_missing'],cross['positive'],cross['zero'],cross['negative']),(4,368,4,0,0))
        self.assertEqual(cross['summary']['conditional_mean'],4.5)
        self.assertEqual(equal['conditional_equal_field_mean_mm'],6)
        self.assertEqual(equal['fields_with_available_pairs'],2)
        self.assertEqual(equal['available_pair_count_distribution'],{'0':122,'1':1,'2':0,'3':1})
        self.assertIsNone(equal['complete_panel_equal_field_mean_mm'])
        self.assertEqual(data['per_field'][0]['E_search_A_to_P_G']['summary']['conditional_mean'],3)
        self.assertEqual(data['per_field'][1]['E_search_A_to_P_G']['common_success'],1)

    def test_signed_G_pairs_are_per_field_seed(self):
        fields,rows=fictional_rows()
        for row in rows:
            if row['instance_id']==fields[0] and row['proxy']=='E':
                make_feasible(row,G=30+((row['seed']-1)*5 if row['arm']=='P' else 0))
        data=build_summary(rows,fields);cross=data['secondary_cross_G_on_E_pairs']
        self.assertEqual((cross['positive'],cross['zero'],cross['negative']),(1,1,1))
        self.assertEqual([p['seed'] for p in data['paired_rows']['E'][:3]],[0,1,2])
        self.assertEqual([p['delta_G_P_minus_A_mm'] for p in data['paired_rows']['E'][:3]],[-5,0,5])

    def test_observed_infeasible_distinct_from_unknown(self):
        fields,rows=fictional_rows();row=rows[0]
        row.update(process_spawned=True,raw_status='UNREVIEWED_INFEASIBLE')
        checked={'valid':False,'routing_violation':True,'base_E':12,'base_G':30,'observations':{},'routes':[],'loads':[]}
        apply_checked(row,checked,{})
        data=build_summary(rows,fields);arm=data['per_field'][0]['by_proxy']['E']['arms']['A']
        self.assertEqual((arm['verified_native_infeasible'],arm['technical_or_unverified_or_not_run']),(1,2))
        self.assertIsNone(row['base_E']);self.assertEqual(row['diagnostic_base_E'],12)
        bad=copy.deepcopy(rows);bad[0]['base_E']=0
        with self.assertRaises(AssertionError):build_summary(bad,fields)

    def test_single_reference_dependencies(self):
        fields,rows=fictional_rows();E=make_feasible(rows[0],E=10,G=35)
        ref={'objectives':{'E_G':{'verified':True,'E':10,'G':30},'G_E':{'verified':False}},'E_star':10,'G_star':None,'delta_integer_mm':None}
        apply_reference(E,ref)
        self.assertTrue(E['valid']);self.assertTrue(E['exact_hit'])
        self.assertEqual(E['E_optimal_tie_difference_mm'],5)
        self.assertIsNone(E['G_realized_excess_mm']);self.assertIsNone(E['exact_proxy_reference_delta_mm'])
        G=make_feasible(next(r for r in rows if r['proxy']=='G'),E=10,G=35);apply_reference(G,ref)
        self.assertTrue(G['valid']);self.assertFalse(G['own_reference_verified'])
        self.assertIsNone(G['own_gap_mm']);self.assertIsNone(G['G_realized_excess_mm'])
        fresh=make_feasible(rows[1],E=11,G=35)
        ref={'objectives':{'E_G':{'verified':False},'G_E':{'verified':True,'E':12,'G':20}},'E_star':None,'G_star':20,'delta_integer_mm':None}
        apply_reference(fresh,ref)
        self.assertTrue(fresh['valid']);self.assertIsNone(fresh['exact_hit'])
        self.assertEqual(fresh['G_realized_excess_mm'],15)
        self.assertIsNone(fresh['E_offset_from_lex_reference_mm'])
        validate_panel_rows(rows,fields)

    def test_zero_optimum_has_null_percent_not_invalid(self):
        fields,rows=fictional_rows();row=make_feasible(rows[0],E=0,G=0)
        ref={'objectives':{'E_G':{'verified':True,'E':0,'G':0},'G_E':{'verified':False}},'E_star':0,'G_star':None,'delta_integer_mm':None}
        apply_reference(row,ref);self.assertTrue(row['exact_hit']);self.assertIsNone(row['own_gap_percent'])
        validate_panel_rows(rows,fields)

    def test_panel_rejects_duplicate_seed_and_fake_cost(self):
        fields,rows=fictional_rows();rows[1]['seed']=1
        with self.assertRaises(AssertionError):build_summary(rows,fields)
        fields,rows=fictional_rows();rows[0]['base_G']=0
        with self.assertRaises(AssertionError):build_summary(rows,fields)

    def test_audit_JSON_roundtrip_and_mismatch(self):
        fields,rows=fictional_rows();data={'rows':rows,**build_summary(rows,fields)}
        hashes=('raw_archive_sha256','frozen_files_sha256','reference_truth_sha256','input_final_archive_sha256',
                'precommit_lock_sha256','seed0_final_archive_sha256','seed0_summary_sha256','seed0_original_binding_sha256')
        data.update({key:'fictional_scalar_contract_'+key for key in hashes})
        data.update(planned_slots=1488,new_planned_slots=992,reused_seed0_planned_slots=496,
                    field_denominator=124,planned_per_arm_proxy=372,seeds_per_field=3,
                    formal_known_spawned=0,formal_unknown_spawned_slots=0,
                    confirmed_model_and_solver_calls=0,unconfirmed_possible_model_or_solver_calls=0,
                    reused_seed0_verified_slots=0)
        audit=json.loads(json.dumps(data,allow_nan=False));audit['status']='SAVED_SEED_REPLICATION_AUDITED'
        self.assertEqual(check_independent(data,audit),['1488rows=496fixed_seed0+992new',*SECTIONS])
        audit['rows'][0]['valid']=True
        with self.assertRaises(AssertionError):check_independent(data,audit)
        audit=json.loads(json.dumps(data));audit['status']='SAVED_SEED_REPLICATION_AUDITED'
        audit['field_level_summary']['E']['A']['count_distributions']['valid_feasible']['0']=123
        with self.assertRaises(AssertionError):check_independent(data,audit)
        audit=json.loads(json.dumps(data));audit['status']='SAVED_SEED_REPLICATION_AUDITED'
        del audit['secondary_cross_G_on_E_pairs']['equal_field_weight']['complete_panel_equal_field_mean_mm']
        with self.assertRaises(AssertionError):check_independent(data,audit)
        audit=json.loads(json.dumps(data));audit['status']='SAVED_SEED_REPLICATION_AUDITED'
        audit['confirmed_model_and_solver_calls']=1
        with self.assertRaises(AssertionError):check_independent(data,audit)

    def test_no_native_import(self):
        self.assertFalse(any(name=='pyvrp' or name.startswith('pyvrp.') for name in sys.modules))


if __name__=='__main__':
    unittest.main()
