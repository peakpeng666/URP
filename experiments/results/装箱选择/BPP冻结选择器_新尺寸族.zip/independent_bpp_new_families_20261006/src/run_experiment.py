"""One bounded fresh external synthetic panel. Never fit or retune anything."""
import pathlib, hashlib, json, time, sys, os, signal, resource, traceback, csv, platform
import numpy as np
from runner_copied import execute, load_controls
from checker_copied import rankings, replay
from selector import BRANCHES, FEATURE_NAMES
H=pathlib.Path(__file__).resolve().parents[1]
OLD=H.parent/'independent_bpp_prefix_selection_20261006'
N=5000; CAP=100; ORDERS=['random','ascending','descending']
FAMILIES=['two_point_5_95_skew95','three_point_10_50_90','two_point_49_51_equal','triangular_1_20_100']
METHODS=['BF','BF_then_EoH','published_EoH','SELECTOR']; SBS='BF_then_EoH'
canon=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
sha=lambda x:hashlib.sha256(x).hexdigest()
def put(p,x):
    with p.open('x') as f:f.write(canon(x)+'\n');f.flush()
def now():return time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
def fail_signal(signum,frame):raise RuntimeError(f'Frozen budget interrupt signal {signum}; no reruns permitted')
def read_source_map():
    mapping={'MODEL.json':'MODEL.json','src/run.py':'src/runner_copied.py','src/selector.py':'src/selector.py','src/check_cached.py':'src/checker_copied.py','src/prepare.py':'evidence/original_prepare.py.txt','sources/BF.py.txt':'sources/BF.py.txt','sources/published_EoH.py.txt':'sources/published_EoH.py.txt','LICENSE.source':'LICENSE.source'}
    records=[]
    for old,new in mapping.items():
        a=(OLD/old).read_bytes();b=(H/new).read_bytes();assert a==b,(old,new)
        records.append({'source_path':str(OLD/old),'local_path':new,'sha256':sha(a),'bytes':len(a)})
    return records

def verify_sources(records):
    for r in records:
        assert sha(pathlib.Path(r['source_path']).read_bytes())==r['sha256']
        assert sha((H/r['local_path']).read_bytes())==r['sha256']

def make_values(family,seed):
    rng=np.random.Generator(np.random.PCG64(seed))
    if family==FAMILIES[0]:a=rng.choice([5,95],N,p=[.95,.05])
    elif family==FAMILIES[1]:a=rng.choice([10,50,90],N,p=[.2,.6,.2])
    elif family==FAMILIES[2]:a=rng.choice([49,51],N,p=[.5,.5])
    else:a=rng.triangular(1.,20.,100.,N)
    return np.rint(np.clip(a,1,100)).astype(np.int64).tolist()

def freeze_inputs(source_map):
    protocol={'schema':'frozen-selector-new-family-panel-v1','created_utc':now(),'capacity':CAP,'items_per_stream':N,'prefix_length':500,'scope':'Post-hoc defined, fresh finite synthetic external distribution panel; no training or tuning. New families mean generating definitions absent from original training generator, not disjoint item support. Not agriculture field data or arbitrary out-of-distribution guarantee.','families':[{'id':FAMILIES[0],'distribution':'choice [5,95], p [0.95,0.05]'},{'id':FAMILIES[1],'distribution':'choice [10,50,90], p [0.2,0.6,0.2]'},{'id':FAMILIES[2],'distribution':'choice [49,51], p [0.5,0.5]'},{'id':FAMILIES[3],'distribution':'continuous triangular(left=1, mode=20, right=100), clip to [1,100], numpy rint ties-to-even'}],'family_order':FAMILIES,'orders':ORDERS,'seed_rule':'base 202610068801 + replicate_index(0..3) + 100*family_index(0..3); independent permutation PCG64(value_seed+1000000)','rng':'numpy Generator(PCG64(integer_seed)); choice or triangular exactly as frozen source; permutation(5000) from separate RNG','grouping':'16 independent generated multisets. The 3 orders share values/source positions within each group. 48 streams are not 48 independent generated samples.','expected_counts':{'groups':16,'streams':48,'full_runs':192,'policy_steps':960000},'policies':METHODS,'execution_order':'family, replicate, then random/ascending/descending; policy list rotated left by stream_index modulo4','selector':'Byte-identical frozen original MODEL and selector; no call to fit; first500 BF items and residual state only, before item501 fetched','training_sbs':SBS,'model_sha256':sha((H/'MODEL.json').read_bytes()),'branch_oracle':'min(final_bins_BF, final_bins_BF_then_EoH), sharing actual first500 BF state','fixed_full_baseline':'published_EoH from item1; never substituted into branch oracle','primary_metric':'mean(SELECTOR final bins - BF_then_EoH final bins); negative means improvement','secondary':['same-prefix branch oracle regret; mean and worst','SBS headroom and recovered fraction if nonzero','all policies mean bins','selector-vs-SBS win/tie/loss; worst loss; selection frequency','all 12 family x order cells and all 48 streams, no filtering'],'statistics':'Descriptive only. No bootstrap, confidence interval, significance test, reweighting, family selection, or test-driven configuration.','checks':'Every full trajectory replayed by copied independently coded scalar-score heap verifier; conservation, integer state, bins and tie behavior; all BF500 states agree; selector complete trajectory equals its chosen actual branch; neighbor/features recomputed without selector call','budget':{'all_official_numerics_and_verification_process_cpu_seconds':180,'soft_cpu_seconds':175,'wall_hard_seconds':600,'single_process_single_thread':True,'no_reruns':True,'failure':'Keep all completed and partial raw files, report incomplete; no new result-producing process after failure','models_or_api_calls':0,'new_dependencies':0},'source_isolation':'Only original MODEL, source code and LICENSE read and copied; no old input or raw result file opened. Original package remains unchanged. Source hashes checked before and after. Copies contain unused original main functions and are never invoked.','environment':{'python':sys.version,'numpy':np.__version__,'platform':platform.platform()},'source_map':source_map,'features':list(FEATURE_NAMES)}
    # Freeze all experiment code, protocol and seeds BEFORE generating any input or result.
    put(H/'PROTOCOL.json',protocol)
    codefiles={str(p.relative_to(H)):sha(p.read_bytes()) for d in ['src','sources','evidence'] for p in sorted((H/d).rglob('*')) if p.is_file() and '__pycache__' not in str(p)}
    codefiles['MODEL.json']=sha((H/'MODEL.json').read_bytes());codefiles['PROTOCOL.json']=sha((H/'PROTOCOL.json').read_bytes())
    put(H/'CODE_SEED_FREEZE.json',{'created_utc':now(),'before_any_input_generation':True,'before_any_policy_execution':True,'files':codefiles})
    metas=[]
    for fi,family in enumerate(FAMILIES):
        for rep in range(4):
            value_seed=202610068801+rep+100*fi;permutation_seed=value_seed+1000000
            values=make_values(family,value_seed);perm=np.random.Generator(np.random.PCG64(permutation_seed)).permutation(N).tolist()
            group=f'new_{family}_r{rep}';multiset_sha=sha(canon(sorted(values)).encode())
            for order in ORDERS:
                idx=perm if order=='random' else sorted(range(N),key=lambda j:values[j],reverse=order=='descending')
                meta={'instance_id':f'{group}__{order}','group_id':group,'family':family,'replicate':rep,'order':order,'value_seed':value_seed,'permutation_seed':permutation_seed,'multiset_sha256':multiset_sha}
                put(H/'inputs'/f"{meta['instance_id']}.json",{**meta,'capacity':CAP,'n':N,'items':[values[j] for j in idx],'source_position':idx});metas.append(meta)
    put(H/'INPUT_INDEX.json',{'instances':metas})
    frozen={**codefiles,'CODE_SEED_FREEZE.json':sha((H/'CODE_SEED_FREEZE.json').read_bytes()),'INPUT_INDEX.json':sha((H/'INPUT_INDEX.json').read_bytes())}
    frozen.update({str(p.relative_to(H)):sha(p.read_bytes()) for p in sorted((H/'inputs').glob('*.json'))})
    put(H/'FREEZE.json',{'created_utc':now(),'before_any_policy_execution':True,'streams':48,'groups':16,'files':frozen})
    print(canon({'stage':'frozen','freeze_sha256':sha((H/'FREEZE.json').read_bytes()),'model_sha256':protocol['model_sha256'],'streams':len(metas)}),flush=True)
    return metas

def validate_all(metas,rows):
    ranks=rankings();checked=0;decisions=0;groups={};model=json.loads((H/'MODEL.json').read_bytes())
    bykey={(r['instance_id'],r['policy']):r for r in rows}
    for meta in metas:
        data=json.loads((H/'inputs'/f"{meta['instance_id']}.json").read_bytes());items=data['items'];pos=data['source_position']
        assert len(items)==N and all(type(x)==int and 1<=x<=100 for x in items)
        assert sorted(pos)==list(range(N)) and sha(canon(sorted(items)).encode())==meta['multiset_sha256']
        values=make_values(meta['family'],meta['value_seed']);assert items==[values[j] for j in pos]
        if meta['order']=='random':assert pos==np.random.Generator(np.random.PCG64(meta['permutation_seed'])).permutation(N).tolist()
        else:assert pos==sorted(range(N),key=lambda j:values[j],reverse=meta['order']=='descending')
        groups.setdefault(meta['group_id'],[]).append(meta['multiset_sha256'])
        states={};assignments={};features={};rs={}
        for p in METHODS:
            r=bykey[(meta['instance_id'],p)];rs[p]=r
            states[p],assignments[p],features[p]=replay(data,r,ranks);checked+=1
        assert states['BF']==states['BF_then_EoH']==states['SELECTOR']
        assert assignments['BF'][:500]==assignments['BF_then_EoH'][:500]==assignments['SELECTOR'][:500]
        sel=rs['SELECTOR'];branch=sel['branch'];assert branch in BRANCHES
        assert assignments['SELECTOR']==assignments[branch] and sel['used_bins']==rs[branch]['used_bins'] and sel['selector_consumed_count']==500
        f=features['SELECTOR'];z=(np.array(f)-np.array(model['mean']))/np.array(model['scale'])
        distances=np.sum((np.array(model['x'])-z)**2,axis=1).tolist();nn=sorted(range(144),key=lambda i:(distances[i],i))[:5]
        costs=[sum(model['y'][i][j] for i in nn)/5 for j in range(2)]
        ix=model['sbs_index'] if costs[0]==costs[1] else int(costs[1]<costs[0])
        assert nn==sel['decision']['neighbors'] and costs==sel['decision']['predicted_final_bins'] and ix==sel['decision']['selected_index']
        assert branch==BRANCHES[ix];decisions+=1
        print(canon({'stage':'validated','runs':checked,'instance':meta['instance_id']}),flush=True)
    assert len(groups)==16 and all(len(v)==3 and len(set(v))==1 for v in groups.values())
    assert checked==192 and decisions==48
    result={'passed':True,'complete_runs_checked':checked,'integer_and_decision_steps':checked*N,'selector_decisions_independently_recomputed':decisions,'chosen_full_trace_matches_actual_branch':True,'shared_BF500_states_verified':48,'regenerated_inputs_and_orders':48,'multiset_groups':16,'source_of_validator':'Byte-identical copied check_cached replay and independent features; panel wrapper independently recomputes selector neighbors','limitations':'Independent mathematical implementation, but same process. Separate external audit is distinct. No robustness guarantee outside these inputs.'}
    put(H/'CHECK.json',result);return result

def analyze(metas,rows):
    bykey={(r['instance_id'],r['policy']):r for r in rows};out=[]
    for m in metas:
        rs={p:bykey[(m['instance_id'],p)] for p in METHODS};b={p:rs[p]['used_bins'] for p in METHODS};oracle=min(b['BF'],b['BF_then_EoH'])
        out.append({**m,**b,'selected_branch':rs['SELECTOR']['branch'],'branch_oracle':oracle,'selector_minus_sbs':b['SELECTOR']-b[SBS],'selector_regret':b['SELECTOR']-oracle,'sbs_regret':b[SBS]-oracle})
    def summarize(rr):
        delta=[r['selector_minus_sbs'] for r in rr];reg=[r['selector_regret'] for r in rr];head=[r['sbs_regret'] for r in rr]
        total_head=sum(head);recovered=-sum(delta)
        return {'streams':len(rr),'groups':len(set(r['group_id'] for r in rr)),'mean_bins':{p:float(np.mean([r[p] for r in rr])) for p in METHODS},'mean_branch_oracle_bins':float(np.mean([r['branch_oracle'] for r in rr])),'mean_selector_minus_sbs':float(np.mean(delta)),'total_selector_minus_sbs':sum(delta),'wins_ties_losses':[sum(d<0 for d in delta),sum(d==0 for d in delta),sum(d>0 for d in delta)],'worst_selector_minus_sbs':max(delta),'mean_selector_regret':float(np.mean(reg)),'worst_selector_regret':max(reg),'mean_sbs_regret':float(np.mean(head)),'headroom_recovered_fraction':recovered/total_head if total_head else None,'selected_branch_counts':{p:sum(r['selected_branch']==p for r in rr) for p in BRANCHES}}
    cells=[{'family':f,'order':o,**summarize([r for r in out if r['family']==f and r['order']==o])} for f in FAMILIES for o in ORDERS]
    families=[{'family':f,**summarize([r for r in out if r['family']==f])} for f in FAMILIES]
    result={'schema':'new-family-panel-summary-v1','status':'complete','training_sbs_fixed':SBS,'all_streams_included':True,'overall':summarize(out),'per_family':families,'per_family_order':cells,'worst_regret_instances':[r['instance_id'] for r in out if r['selector_regret']==max(x['selector_regret'] for x in out)],'inference':'Descriptive fixed panel only; no bootstrap or significance claim.'}
    put(H/'analysis'/'SUMMARY.json',result);put(H/'analysis'/'PER_STREAM.json',out)
    with (H/'analysis'/'per_stream.csv').open('x',newline='') as f:w=csv.DictWriter(f,fieldnames=list(out[0]));w.writeheader();w.writerows(out)
    flat=[]
    for c in cells:
        r={k:v for k,v in c.items() if k not in ['mean_bins','selected_branch_counts','wins_ties_losses']};r.update({'mean_'+p:v for p,v in c['mean_bins'].items()});r.update({'selected_'+p:v for p,v in c['selected_branch_counts'].items()});r.update(dict(zip(['wins','ties','losses'],c['wins_ties_losses'])));flat.append(r)
    with (H/'analysis'/'family_order_summary.csv').open('x',newline='') as f:w=csv.DictWriter(f,fieldnames=list(flat[0]));w.writeheader();w.writerows(flat)
    print(canon({'stage':'summary','overall':result['overall']}),flush=True)
    return result

def verify_freeze():
    for p,h in json.loads((H/'FREEZE.json').read_bytes())['files'].items():assert sha((H/p).read_bytes())==h,p

def main():
    start=time.monotonic();cpu=time.process_time();rows=[];metas=[]
    signal.signal(signal.SIGXCPU,fail_signal);signal.signal(signal.SIGALRM,fail_signal);signal.alarm(599)
    resource.setrlimit(resource.RLIMIT_CPU,(175,180))
    put(H/'RUN_STARTED.json',{'started_utc':now(),'cpu_limit':180,'wall_limit':600,'all_numeric_work_in_this_process':True,'thread_environment':{k:os.environ.get(k) for k in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS']}})
    try:
        source_map=read_source_map();put(H/'evidence'/'SOURCE_SNAPSHOT.json',{'created_utc':now(),'files':source_map})
        metas=freeze_inputs(source_map);verify_freeze();controls=load_controls();model=json.loads((H/'MODEL.json').read_bytes());assert model['sbs_index']==1 and model['k']==5
        for i,m in enumerate(metas):
            data=json.loads((H/'inputs'/f"{m['instance_id']}.json").read_bytes());names=METHODS[i%4:]+METHODS[:i%4]
            runs=[execute(data,p,controls,model) for p in names];rows.extend(runs)
            print(canon({'stage':'run','completed_runs':len(rows),'instance':m['instance_id'],'bins':{r['policy']:r['used_bins'] for r in runs},'branch':next(r['branch'] for r in runs if r['policy']=='SELECTOR')}),flush=True)
        assert len(rows)==192
        validate_all(metas,rows);summary=analyze(metas,rows);verify_freeze();verify_sources(source_map)
        put(H/'SOURCE_ISOLATION_CHECK.json',{'passed':True,'source_files':len(source_map),'before_after_bytes_match':True,'old_inputs_or_results_opened':False,'old_source_files_modified':False,'fit_called':False})
        done={'status':'complete','started_utc':json.loads((H/'RUN_STARTED.json').read_bytes())['started_utc'],'finished_utc':now(),'full_runs':len(rows),'policy_steps':len(rows)*N,'validated_steps':len(rows)*N,'process_cpu_seconds_before_final_write':time.process_time(),'experiment_cpu_seconds':time.process_time()-cpu,'experiment_wall_seconds':time.monotonic()-start,'models_or_api_calls':0,'no_retries':True,'source_unchanged':True}
        put(H/'RUN_COMPLETE.json',done);print(canon(done),flush=True)
    except BaseException as e:
        try:put(H/'RUN_FAILURE.json',{'status':'partial_or_failure','finished_utc':now(),'error':type(e).__name__+': '+str(e),'fully_committed_rows_in_memory':len(rows),'raw_json_files_preserved':len(list((H/'raw').glob('*.json'))),'cpu_seconds':time.process_time(),'wall_seconds':time.monotonic()-start,'traceback':traceback.format_exc(),'rerun_permitted':False})
        except BaseException:pass
        raise
if __name__=='__main__':main()
