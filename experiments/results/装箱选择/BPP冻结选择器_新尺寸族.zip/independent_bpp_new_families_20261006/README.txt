BPP 冻结前缀选择器 新尺寸族独立合成面板

这是独立追加实验，不替换、不改写原768次历史包，也不扩展已交付本地面板提示词的数据范围。

先读 REPORT_ZH.txt 或 BPP冻结选择器新尺寸族短实验.docx。
正式结果：analysis/SUMMARY.json（总体、每族、全部12族×顺序单元）、analysis/per_stream.csv（全48流）和 analysis/family_order_summary.csv。
主比较始终为SELECTOR减原训练SBS BF_then_EoH，负数表示节省。没有在本面板重选SBS。oracle只取同BF500状态的两分支；published EoH全程基线不进入oracle。

规模：16个新生成多重集，48条输入流，四策略各自完整真实执行，192次runs，共960000策略步。4族和固定种子写入PROTOCOL.json。
全数据保留：inputs/48个JSON；raw/192个JSON及192个NPZ。NPZ记录每步assignment、pre_remaining、post_remaining、feasible_counts、used_bins_after及5000槽终态remaining。remaining不是每一步的全状态矩阵。
SELECTOR记录的decision保存真实特征、邻居索引、距离、预测值与一次选择。原MODEL内已有训练表征与标签是冻结模型的一部分，没有重新读取旧训练输入或旧raw成绩。

冻结顺序：CODE_SEED_FREEZE.json（代码/协议/种子，早于新输入生成）→FREEZE.json（全部输入，早于任何策略执行）→RUN_STARTED/RUN_COMPLETE及日志。RUN_STARTED是整个受限进程开始时刻，因此先于CODE_SEED_FREEZE；具体策略执行始于日志frozen记录之后。
源隔离：evidence/SOURCE_SNAPSHOT.json记录原MODEL、源码、原生成器与许可证的8项映射；SOURCE_ISOLATION_CHECK.json核对前后字节。src/runner_copied.py、src/checker_copied.py、src/selector.py与两个控制源保持原字节。copied文件保留旧main函数，但本次只import允许的执行/独立验证函数，不调用其旧main。
预算：resources/PROCESS_RESOURCE.json由只运行一次的外层进程计量。正式输入生成、全部策略、独立轨迹验证及汇总均在同一子进程内，CPU硬限制180秒/wall600秒。实测CPU47.239409秒/wall47.260420秒。报告排版、ZIP校验和另行独立审计不属于该数值进程，没有借这些步骤运行额外策略、换配置或新增正式统计。
检查：CHECK.json是同进程独立标量评分及整数回放；audit_external/（如存在）为另一审计任务用独立bitset实现的全量复验原件副本，计量独立，不与主进程重复扣同一计数。

统计边界：描述性、无bootstrap和显著性结论。三顺序共享多重集，不可把48流当作48个独立生成样本。新族仅相对于原6族训练生成器，不表示整个项目首次见到这些取值/结构；旧压力试验已有49/51类构造，非支持集互斥。这是看过既有研究后新增并预先冻结的合成面板，采用新seed和新真实运行，不是未经选择的现实外部盲测，非农业实测数据，不保证任意分布外表现。全部负结果已保留。

复现材料：全部输入、原模型、控制源、生成/执行/验证/汇总代码和精确版本已随包。src/run_experiment.py为这次实际一次性入口，src/launch_budget.py为该进程预算与日志入口。文件使用排他创建，不允许在交付目录里直接重跑覆盖。完整源隔离检查引用原 sibling independent_bpp_prefix_selection_20261006，并保留当时绝对路径证据；在另一机器重建运行时，须另建全新工作目录并显式重建只读原源快照的路径映射，不能暗改已冻结包。此次任务不进行额外复现运行。

MANIFEST.json列出交付文件大小和SHA256；manifest自身不自列。ZIP成员以本实验目录为顶层目录。报告渲染PNG为排版QA中间件，不随交付包分发；DOCUMENT_QA.json记录检查范围。没有新增依赖、网络模型调用或API费用。
