"""Verify saved traces via residual-class bitsets, never call the packing policies."""
import pathlib,json,hashlib,math,statistics,itertools,collections,datetime,time,signal,traceback,csv
import numpy as np
H=pathlib.Path(__file__).resolve().parent;R=H.parent/'independent_bpp_new_families_20261006'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
canon=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
digest=lambda x:hashlib.sha256(canon(x).encode()).hexdigest()
progress={'runs_checked':0,'decisions_checked':0,'integer_steps':0,'selector_decisions':0}
def fail_signal(signum,frame):raise RuntimeError('Audit soft CPU cap reached; preserve partial scope')
signal.signal(signal.SIGXCPU,fail_signal)
def main():
    P=read(R/'PROTOCOL.json');freeze=read(R/'FREEZE.json');sources={}
    assert sha(R/'FREEZE.json')=='520ee8c45772616721463f00557dc1a18c5c22f673913265aa43e99315b60445'
    for name,expected in freeze['files'].items():assert sha(R/name)==expected;sources[name]=expected
    for entry in P['source_map']:
        assert sha(pathlib.Path(entry['source_path']))==entry['sha256']==sha(R/entry['local_path'])
    assert P['model_sha256']=='98991f0908867ff7de995b1e252d503c0180a5e74c67ac03d9444765fdede7ab'
    model=read(R/'MODEL.json');assert model['k']==5 and model['sbs_index']==1 and len(model['x'])==len(model['y'])==144
    assert all(len(x)==31 for x in model['x']) and len(model['mean'])==len(model['scale'])==31 and all(x>0 for x in model['scale'])
    metas=read(R/'INPUT_INDEX.json')['instances'];assert len(metas)==48 and len({m['instance_id'] for m in metas})==48
    assert len({m['group_id'] for m in metas})==16
    for path in [R/'FREEZE.json',R/'RUN_COMPLETE.json',R/'CHECK.json',R/'SOURCE_ISOLATION_CHECK.json',R/'resources/PROCESS_RESOURCE.json',R/'analysis/SUMMARY.json',R/'analysis/PER_STREAM.json']:
        sources[str(path.relative_to(R))]=sha(path)
    finished=read(R/'RUN_COMPLETE.json');assert finished['status']=='complete' and finished['full_runs']==192 and finished['policy_steps']==finished['validated_steps']==960000
    # Precompute scalar score order once. This is score arithmetic, not policy execution.
    ranking={}
    for item in range(1,101):
        tied={}
        for remaining in range(item,101):
            gap=remaining-item;exp=math.exp(gap)
            score=remaining/((exp+0.7)*exp)+(1-gap/remaining)*math.sqrt(gap)+(0.8 if gap>3*item else 0.3)
            tied.setdefault(score,[]).append(remaining)
        ranking[item]=[(sum(1<<r for r in group),group) for score,group in sorted(tied.items(),reverse=True)]
    generated={}
    for fi,family in enumerate(P['family_order']):
        for rep in range(4):
            seed=202610068801+rep+100*fi;rng=np.random.Generator(np.random.PCG64(seed))
            if fi==0:v=rng.choice([5,95],5000,p=[.95,.05])
            elif fi==1:v=rng.choice([10,50,90],5000,p=[.2,.6,.2])
            elif fi==2:v=rng.choice([49,51],5000,p=[.5,.5])
            else:v=rng.triangular(1.,20.,100.,5000)
            generated[family,rep]=(np.rint(np.clip(v,1,100)).astype(np.int64).tolist(),seed)
    def features(items,state):
        p=items[:500];used=[v for v in state if v<100];ordered=sorted(p)
        def quant(q):
            t=499*q;i=int(t);frac=t-i
            return (ordered[i]*(1-frac)+ordered[min(i+1,499)]*frac)/100
        return [sum((x-1)//10==k for x in p)/500 for k in range(10)]+[statistics.mean(p)/100,statistics.pstdev(p)/100]+[quant(q) for q in [.1,.5,.9]]+[sum(b>a for a,b in zip(p,p[1:]))/499,sum(b<a for a,b in zip(p,p[1:]))/499,(statistics.mean(p[-100:])-statistics.mean(p[:100]))/100,len(used)/500]+[sum(x//10==k for x in used)/len(used) for k in range(10)]+[statistics.mean(used)/100,statistics.pstdev(used)/100]
    metrics=[];max_feature_error=0.;max_distance_error=0.;negative_cells=[]
    methods=['BF','BF_then_EoH','published_EoH','SELECTOR']
    for meta in metas:
        data=read(R/'inputs'/f"{meta['instance_id']}.json");items=data['items'];positions=data['source_position'];v,seed=generated[meta['family'],meta['replicate']]
        assert len(items)==5000 and all(type(x)==int and 1<=x<=100 for x in items) and sorted(positions)==list(range(5000))
        assert meta['value_seed']==seed and meta['permutation_seed']==seed+1000000 and items==[v[i] for i in positions]
        expected=(np.random.Generator(np.random.PCG64(seed+1000000)).permutation(5000).tolist() if meta['order']=='random' else sorted(range(5000),key=lambda i:v[i],reverse=meta['order']=='descending'))
        assert positions==expected and digest(sorted(items))==meta['multiset_sha256']
        states={};traces={};rows={};feats={}
        for policy in methods:
            name=f"raw/{meta['instance_id']}__{policy}.json";row=read(R/name);sources[name]=sha(R/name);rows[policy]=row
            assert row['instance_id']==meta['instance_id'] and row['policy']==policy and row['status']=='complete' and row['error'] is None and row['steps']==5000
            assert row['items_sha256']==digest(items) and row['selector_consumed_count']==500
            npz=R/row['trajectory_file'];assert sha(npz)==row['trajectory_sha256'];sources[row['trajectory_file']]=row['trajectory_sha256']
            arrays={k:a.tolist() for k,a in dict(np.load(npz,allow_pickle=False)).items()};traces[policy]=arrays
            for key in ['assignment','pre_remaining','post_remaining','feasible_counts','used_bins_after','remaining']:assert len(arrays[key])==5000
            remaining=[100]*5000;bins=[0]*101;bins[100]=(1<<5000)-1;count=[0]*101;count[100]=5000;present=1<<100;used=0;prefix=None
            for step,item in enumerate(items):
                target=arrays['assignment'][step];assert type(target)==int and 0<=target<5000
                is_eoh=policy=='published_EoH' or (step>=500 and row['branch']=='BF_then_EoH')
                if is_eoh:
                    # Capacity-class masks locate the best score; bitsets provide first bin index.
                    eligible=None
                    for mask,residuals in ranking[item]:
                        active=present&mask
                        if active:eligible=residuals;break
                    assert eligible is not None
                    candidate=min((bins[r]&-bins[r]).bit_length()-1 for r in eligible if bins[r])
                else:
                    feasible=present>>item;assert feasible
                    r=item+(feasible&-feasible).bit_length()-1
                    candidate=(bins[r]&-bins[r]).bit_length()-1
                assert target==candidate,(meta['instance_id'],policy,step,target,candidate)
                before=remaining[target];after=before-item
                assert before>=item and 0<=after<100
                assert arrays['pre_remaining'][step]==before and arrays['post_remaining'][step]==after and arrays['feasible_counts'][step]==sum(count[item:])
                used+=int(before==100);assert arrays['used_bins_after'][step]==used
                bit=1<<target;bins[before]^=bit;bins[after]|=bit;count[before]-=1;count[after]+=1
                if not count[before]:present&=~(1<<before)
                present|=1<<after;remaining[target]=after
                if step==499:prefix=remaining.copy()
            assert remaining==arrays['remaining'] and used==row['used_bins']==sum(r<100 for r in remaining)
            assert sum(100-r for r in remaining)==sum(items) and used>=(sum(items)+99)//100
            assert digest(prefix)==row['prefix_remaining_sha256']
            f=features(items,prefix);assert np.allclose(f,row['prefix_features'],rtol=1e-12,atol=1e-13)
            max_feature_error=max(max_feature_error,max(abs(a-b) for a,b in zip(f,row['prefix_features'])))
            states[policy]=prefix;feats[policy]=f;progress['runs_checked']+=1;progress['integer_steps']+=5000;progress['decisions_checked']+=5000
        assert states['BF']==states['BF_then_EoH']==states['SELECTOR']
        for field in ['assignment','pre_remaining','post_remaining','feasible_counts','used_bins_after']:
            assert traces['BF'][field][:500]==traces['BF_then_EoH'][field][:500]==traces['SELECTOR'][field][:500]
        sel=rows['SELECTOR'];branch=sel['branch'];assert branch in ['BF','BF_then_EoH'] and traces['SELECTOR']==traces[branch]
        assert sel['used_bins']==rows[branch]['used_bins']
        z=[(x-mu)/scale for x,mu,scale in zip(feats['SELECTOR'],model['mean'],model['scale'])]
        d=[math.fsum((a-b)**2 for a,b in zip(x,z)) for x in model['x']];neighbors=sorted(range(144),key=lambda i:(d[i],i))[:5]
        scores=[sum(model['y'][i][j] for i in neighbors)/5 for j in [0,1]];choice=1 if scores[0]==scores[1] else int(scores[1]<scores[0])
        decision=sel['decision'];assert neighbors==decision['neighbors'] and scores==decision['predicted_final_bins'] and choice==decision['selected_index'] and ['BF','BF_then_EoH'][choice]==branch
        assert np.allclose(feats['SELECTOR'],decision['features'],rtol=1e-12,atol=1e-13)
        error=max(abs(d[i]-observed) for i,observed in zip(neighbors,decision['squared_distances']));assert error<1e-9;max_distance_error=max(max_distance_error,error)
        progress['selector_decisions']+=1
        b={p:rows[p]['used_bins'] for p in methods};oracle=min(b['BF'],b['BF_then_EoH'])
        metrics.append({**meta,**b,'selected_branch':branch,'branch_oracle':oracle,'selector_minus_sbs':b['SELECTOR']-b['BF_then_EoH'],'selector_regret':b['SELECTOR']-oracle,'sbs_regret':b['BF_then_EoH']-oracle})
        print(json.dumps({'validated_instance':meta['instance_id'],**progress}),flush=True)
    assert len(list((R/'raw').glob('*.json')))==len(list((R/'raw').glob('*.npz')))==192
    assert progress=={'runs_checked':192,'decisions_checked':960000,'integer_steps':960000,'selector_decisions':48}
    assert metrics==read(R/'analysis/PER_STREAM.json')
    def summary(rows):
        delta=[r['selector_minus_sbs'] for r in rows];regret=[r['selector_regret'] for r in rows];head=[r['sbs_regret'] for r in rows];den=sum(head)
        return {'streams':len(rows),'groups':len({r['group_id'] for r in rows}),'mean_bins':{p:statistics.mean(r[p] for r in rows) for p in methods},'mean_branch_oracle_bins':statistics.mean(r['branch_oracle'] for r in rows),'mean_selector_minus_sbs':statistics.mean(delta),'total_selector_minus_sbs':sum(delta),'wins_ties_losses':[sum(v<0 for v in delta),sum(v==0 for v in delta),sum(v>0 for v in delta)],'worst_selector_minus_sbs':max(delta),'mean_selector_regret':statistics.mean(regret),'worst_selector_regret':max(regret),'mean_sbs_regret':statistics.mean(head),'headroom_recovered_fraction':-sum(delta)/den if den else None,'selected_branch_counts':{p:sum(r['selected_branch']==p for r in rows) for p in ['BF','BF_then_EoH']}}
    overall=summary(metrics);families=[{'family':f,**summary([r for r in metrics if r['family']==f])} for f in P['family_order']]
    cells=[{'family':f,'order':o,**summary([r for r in metrics if r['family']==f and r['order']==o])} for f in P['family_order'] for o in P['orders']]
    reported=read(R/'analysis/SUMMARY.json');assert overall==reported['overall'] and families==reported['per_family'] and cells==reported['per_family_order']
    assert len(cells)==12 and all(c['streams']==4 and c['groups']==4 for c in cells)
    assert all(f['streams']==12 and f['groups']==4 for f in families)
    worst=[r['instance_id'] for r in metrics if r['selector_regret']==max(x['selector_regret'] for x in metrics)];assert worst==reported['worst_regret_instances']
    for name,expected in sources.items():assert sha(R/name)==expected,name
    for entry in P['source_map']:assert sha(pathlib.Path(entry['source_path']))==entry['sha256']
    negative=[r for r in metrics if r['selector_minus_sbs']>0]
    report={'status':'passed','completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'Separate reviewer, new residual-class bitset verifier, no producer helper imports and no policy reruns.','checks':progress,'inputs_reconstructed_from_frozen_seed':48,'groups':16,'source_files_verified_unchanged':len(sources),'original_source_files_verified_unchanged':8,'model_byte_identical':True,'prefix_BF500_common_states_verified':48,'selector_trace_equal_chosen_actual_branch':48,'all12_cells_and_negative_results_preserved':True,'maximum_feature_absolute_error':max_feature_error,'maximum_neighbor_distance_absolute_error':max_distance_error,'overall':overall,'per_family':families,'per_family_order':cells,'negative_streams':negative,'worst_regret_instances':worst,'limits':['Post-hoc four-family synthetic panel. New generator definitions do not mean disjoint size support, arbitrary distribution robustness or field validation.','There are16 generated multiset groups;48 ordered streams are correlated triplets, not48 independent samples.','Code and hash/source isolation checked; no operating-system filesystem syscall audit or security-isolation claim.','Selector computational input boundary is checked from code and saved consumed_count/prefix states; no adversarial future-invariance intervention was run on these new inputs.','Policy tie ranking uses a newly written scalar objective verifier over finite integer capacities; this audits saved decisions, not an independent new policy execution.']}
    (H/'AUDIT_RESULT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');(H/'SOURCE_MANIFEST.json').write_text(json.dumps({'root':R.name,'files':sources},indent=2)+'\n')
    print(json.dumps(report,ensure_ascii=False,indent=2),flush=True)
try:main()
except BaseException as e:
    (H/'AUDIT_FAILURE.json').write_text(json.dumps({'status':'failed_or_incomplete','error':type(e).__name__+': '+str(e),'completed_checks':progress,'traceback':traceback.format_exc()},ensure_ascii=False,indent=2)+'\n')
    raise
