import os,sys,time,resource,signal,json,pathlib,datetime
H=pathlib.Path(__file__).resolve().parent;start=time.monotonic();cpu=time.process_time();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();started=now()
pid=os.fork()
if pid==0:
    resource.setrlimit(resource.RLIMIT_CPU,(27,29));f=os.open(H/'AUDIT.log',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o644);os.dup2(f,1);os.dup2(f,2)
    for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
    os.execv(sys.executable,[sys.executable,str(H/'audit_new_families.py')])
resource.setrlimit(resource.RLIMIT_CPU,(1,1));timeout=False
while True:
    got,status,usage=os.wait4(pid,os.WNOHANG)
    if got:break
    if time.monotonic()-start>120:timeout=True;os.kill(pid,signal.SIGKILL);got,status,usage=os.wait4(pid,0);break
    time.sleep(.1)
r={'started_utc':started,'finished_utc':now(),'exit_code':os.waitstatus_to_exitcode(status),'wall_timeout':timeout,'child_user_cpu_seconds':usage.ru_utime,'child_system_cpu_seconds':usage.ru_stime,'child_cpu_seconds':usage.ru_utime+usage.ru_stime,'wall_seconds':time.monotonic()-start,'launcher_partial_cpu_seconds':time.process_time()-cpu,'child_cpu_hard_limit_seconds':29,'launcher_cpu_hard_limit_seconds':1,'wall_limit_seconds':120,'scope':'Entire verification child via wait4; launcher measured through wait, final write/exit tail bounded but not exactly metered. No exact all-in claim.'}
with (H/'PROCESS_RESOURCE.json').open('x') as f:json.dump(r,f,indent=2)
print(json.dumps(r));sys.exit(r['exit_code'] if r['exit_code']>=0 else 128-r['exit_code'])
