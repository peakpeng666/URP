import resource
resource.setrlimit(resource.RLIMIT_CPU,(1,1))
import pathlib,json,csv,hashlib,datetime
H=pathlib.Path(__file__).resolve().parent;R=H.parent/'independent_bpp_new_families_20261006';read=lambda p:json.loads(p.read_text())
P=read(R/'PROTOCOL.json');meta=read(R/'INPUT_INDEX.json')['instances'];seen=set()
for m in meta:
    seen.add((m['family'],m['replicate'],m['order']))
    for p in P['policies']:
        r=read(R/'raw'/f"{m['instance_id']}__{p}.json")
        assert r['branch'] in ['BF','BF_then_EoH'] if p=='SELECTOR' else r['branch']==p
assert seen=={(f,r,o) for f in P['family_order'] for r in range(4) for o in P['orders']}
rows=read(R/'analysis/PER_STREAM.json');csvrows=list(csv.DictReader((R/'analysis/per_stream.csv').open()));assert len(csvrows)==48
for expected,actual in zip(rows,csvrows):
    assert set(expected)==set(actual)
    for k,v in expected.items():assert str(v)==actual[k],(k,v,actual[k])
cells=read(R/'analysis/SUMMARY.json')['per_family_order'];csvcells=list(csv.DictReader((R/'analysis/family_order_summary.csv').open()));assert len(csvcells)==12
for c,a in zip(cells,csvcells):
    expected={k:v for k,v in c.items() if k not in ['mean_bins','selected_branch_counts','wins_ties_losses']}
    expected.update({'mean_'+p:v for p,v in c['mean_bins'].items()});expected.update({'selected_'+p:v for p,v in c['selected_branch_counts'].items()});expected.update(dict(zip(['wins','ties','losses'],c['wins_ties_losses'])))
    assert set(a)==set(expected)
    for k,v in expected.items():assert ('' if v is None else str(v))==a[k],(k,v,a[k])
r={'status':'passed','checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'policy_branch_labels':192,'complete_family_replicate_order_grid':48,'per_stream_csv_rows':48,'family_order_csv_rows':12,'source_csv_sha256':{name:hashlib.sha256((R/'analysis'/name).read_bytes()).hexdigest() for name in ['per_stream.csv','family_order_summary.csv']}}
(H/'FINAL_METADATA_CHECK.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
