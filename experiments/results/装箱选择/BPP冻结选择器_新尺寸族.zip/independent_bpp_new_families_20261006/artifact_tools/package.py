"""Package fixed artifacts only; no numerical experiment or statistic is rerun."""
import pathlib,json,hashlib,zipfile,time
H=pathlib.Path(__file__).resolve().parents[1]
assert (H/'audit_external').is_dir(), 'Final external audit must be copied first'
assert (H/'RUN_COMPLETE.json').is_file() and (H/'CHECK.json').is_file()
assert not (H/'MANIFEST.json').exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
files=[p for p in sorted(H.rglob('*')) if p.is_file() and not any(x.startswith('render_qa') or x=='__pycache__' for x in p.relative_to(H).parts)]
records=[{'path':str(p.relative_to(H)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in files]
manifest={'schema':'full-artifact-manifest-v1','created_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'directory':H.name,'file_count_excluding_manifest':len(records),'files':records,'excluded':'Report render QA PNG directories only; no raw input or trajectory excluded','self_hash':'MANIFEST does not include itself; ZIP SHA256 supplied outside ZIP'}
(H/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');files.append(H/'MANIFEST.json')
out=H.parent/(H.name+'_FULL_PACKAGE.zip');assert not out.exists()
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in files:z.write(p,str(pathlib.Path(H.name)/p.relative_to(H)))
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None
    assert len(z.namelist())==len(files)
    for r in records:
        data=z.read(str(pathlib.Path(H.name)/r['path']));assert len(data)==r['bytes'] and sha(data)==r['sha256']
    assert z.read(str(pathlib.Path(H.name)/'MANIFEST.json'))==(H/'MANIFEST.json').read_bytes()
result={'zip_path':str(out),'zip_bytes':out.stat().st_size,'zip_sha256':sha(out.read_bytes()),'zip_members':len(files),'manifest_entries':len(records),'manifest_sha256':sha((H/'MANIFEST.json').read_bytes()),'verified':'All zip CRCs and every member against manifest; manifest readback exact. No strategy execution.','raw_npz_count':len(list((H/'raw').glob('*.npz'))),'raw_json_count':len(list((H/'raw').glob('*.json'))),'input_json_count':len(list((H/'inputs').glob('*.json'))),'audit_included':True,'created_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
(H.parent/(H.name+'_DELIVERY.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2))
