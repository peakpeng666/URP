"""Format completed, frozen scientific results. No experiment reruns or new statistics."""
import pathlib,json
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_CELL_VERTICAL_ALIGNMENT
H=pathlib.Path(__file__).resolve().parents[1]
s=json.loads((H/'analysis/SUMMARY.json').read_text());o=s['overall'];p=json.loads((H/'PROTOCOL.json').read_text());r=json.loads((H/'resources/PROCESS_RESOURCE.json').read_text());check=json.loads((H/'CHECK.json').read_text())
names={f['id']:f'F{i+1}' for i,f in enumerate(p['families'])};orders={'random':'随机','ascending':'升序','descending':'降序'}
d=Document();sec=d.sections[0];sec.page_width=Inches(8.5);sec.page_height=Inches(11);sec.top_margin=sec.bottom_margin=Inches(.62);sec.left_margin=sec.right_margin=Inches(.62)
for name in ['Normal','Title','Heading 1','Heading 2']:
    st=d.styles[name];st.font.name='Noto Sans CJK SC';st.element.rPr.rFonts.set(qn('w:eastAsia'),'Noto Sans CJK SC');st.font.color.rgb=RGBColor(0,0,0)
d.styles['Normal'].font.size=Pt(10);d.styles['Normal'].paragraph_format.space_after=Pt(5);d.styles['Normal'].paragraph_format.line_spacing=1.12
d.styles['Title'].font.size=Pt(21);d.styles['Title'].paragraph_format.space_after=Pt(8)
d.styles['Heading 1'].font.size=Pt(13);d.styles['Heading 1'].paragraph_format.space_before=Pt(9);d.styles['Heading 1'].paragraph_format.space_after=Pt(5)
text=[]
def para(t,style=None):
    p0=d.add_paragraph(t,style);p0.paragraph_format.space_before=Pt(3);text.append(t)
def heading(t):para(t,'Heading 1')
def table(headers,rows,widths):
    t=d.add_table(rows=1,cols=len(headers));t.alignment=WD_TABLE_ALIGNMENT.CENTER;t.autofit=False
    for i,(h,w) in enumerate(zip(headers,widths)):t.columns[i].width=Inches(w);t.rows[0].cells[i].width=Inches(w);t.rows[0].cells[i].text=h
    repeat=OxmlElement('w:tblHeader');t.rows[0]._tr.get_or_add_trPr().append(repeat)
    for row in rows:
        cells=t.add_row().cells
        for i,v in enumerate(row):cells[i].text=str(v);cells[i].width=Inches(widths[i])
    for ri,row in enumerate(t.rows):
        for c in row.cells:
            c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            tcpr=c._tc.get_or_add_tcPr();b=OxmlElement('w:tcBorders')
            for edge in ['top','left','bottom','right']:
                e=OxmlElement('w:'+edge);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'4');e.set(qn('w:color'),'D9D9D9');b.append(e)
            tcpr.append(b);mar=OxmlElement('w:tcMar')
            for edge in ['top','left','bottom','right']:
                e=OxmlElement('w:'+edge);e.set(qn('w:w'),'65');e.set(qn('w:type'),'dxa');mar.append(e)
            tcpr.append(mar)
            if ri==0:
                sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'E7EDF3');tcpr.append(sh)
            for par in c.paragraphs:
                par.alignment=WD_ALIGN_PARAGRAPH.CENTER;par.paragraph_format.space_after=Pt(0);par.paragraph_format.line_spacing=1.02
                for run in par.runs:run.font.size=Pt(9);run.bold=ri==0
    text.append(' | '.join(headers));text.extend(' | '.join(map(str,x)) for x in rows)
para('BPP 冻结选择器新尺寸族短实验','Title')
para('2026年10月6日  48条新流  192次真实运行  描述性外部分布面板')
heading('主要结果')
para(f'冻结选择器相对原训练集选定的固定基线 BF_then_EoH，平均少用 {abs(o["mean_selector_minus_sbs"]):.2f} 箱；{o["wins_ties_losses"][0]} 胜、{o["wins_ties_losses"][1]} 平、{o["wins_ties_losses"][2]} 负。最坏单流比基线多 {o["worst_selector_minus_sbs"]} 箱，相对同 BF500 前缀的两分支事后 oracle 最坏后悔 {o["worst_selector_regret"]} 箱。')
para('该实验补充了旧留族分析复用已有数据的局限：它生成并真实执行了新定义的尺寸分布，但仍只支持本次有限合成面板的描述，不能推出任意新分布上的收益保证。')
heading('先冻结再执行')
para('模型、31维前缀特征、k=5、控制函数和训练SBS均保持不变；没有训练、调参、模型API调用或策略补跑。每条流5000项，容量100；SELECTOR先用BF处理500项，在第501项到达前仅决定一次后续分支。四种策略各自完整执行，不能由已有分支记录复制冒充SELECTOR运行。')
para('4个尺寸族，每族4个固定新seed，每组同一多重集生成随机、升序和降序三种到达顺序，共16组48流。族按F1至F4排列，seed = 202610068801 + 重复索引0..3 + 100×族索引0..3；随机排列使用独立PCG64(seed+1000000)。')
para('F1：5/95，概率0.95/0.05；F2：10/50/90，概率0.2/0.6/0.2；F3：49/51，概率0.5/0.5；F4：连续三角分布Triangular(1,20,100)，裁剪1..100后按ties-to-even取整数。代码与种子先冻结，随后全部输入冻结，最后才开始策略执行。')
heading('总体平均箱数')
table(['策略或对照','平均箱数'],[['全程BF',f'{o["mean_bins"]["BF"]:.3f}'],['BF500后续EoH  固定训练SBS',f'{o["mean_bins"]["BF_then_EoH"]:.3f}'],['全程published EoH',f'{o["mean_bins"]["published_EoH"]:.3f}'],['冻结SELECTOR',f'{o["mean_bins"]["SELECTOR"]:.3f}'],['同BF500两分支事后oracle',f'{o["mean_branch_oracle_bins"]:.3f}']],[5.2,2.0])
para(f'选择BF {o["selected_branch_counts"]["BF"]}次，续EoH {o["selected_branch_counts"]["BF_then_EoH"]}次。平均oracle后悔 {o["mean_selector_regret"]:.3f}箱；固定SBS平均可改善余地 {o["mean_sbs_regret"]:.3f}箱，收回比例 {o["headroom_recovered_fraction"]:.2%}。该比例不是整体装箱提效。')
para('published EoH从第1项开始使用EoH，不共享第500项的BF状态，因此只作固定全程baseline，未纳入分支oracle或重新挑选新SBS。')
d.add_page_break();heading('全部尺寸族与到达顺序')
para('差值为 SELECTOR − 固定训练SBS，负值表示节省；每格4条流。选择列为BF/续EoH次数。最大后悔相对同BF500两分支oracle。全部12格和全部48流均保留，未过滤不利结果。')
rows=[]
for c in s['per_family_order']:
    rows.append([names[c['family']]+' '+orders[c['order']],f'{c["mean_selector_minus_sbs"]:.2f}','/'.join(map(str,c['wins_ties_losses'])),str(c['worst_selector_minus_sbs']),str(c['worst_selector_regret']),f'{c["selected_branch_counts"]["BF"]}/{c["selected_branch_counts"]["BF_then_EoH"]}'])
table(['族与顺序','平均差值','胜/平/负','最大差值','最大后悔','选择次数'],rows,[1.38,1.05,1.1,1.1,1.1,1.47])
para('四策略各格平均箱数、每族总体和全部逐流结果见 analysis/SUMMARY.json、family_order_summary.csv 与 per_stream.csv。最大差值可为负，表示该格每条流均优于基线。')
heading('负结果与外推边界')
para('F1随机与升序、F2升序，SELECTOR始终选续EoH并与SBS打平，却错过BF更优的分支；其中最坏oracle后悔为53箱。F3随机单元平均多用1.50箱，出现唯一负例；不能把总体平均收益理解为每族、每顺序或每条流都受益。')
para('“新族”仅相对于原6族训练生成器，不表示整个项目首次见到这些取值或结构；旧压力试验已有49/51类构造，支持集不要求互斥。这是看过既有研究后新增、预先冻结的合成面板，使用新seed和新真实运行，不是未经选择的现实外部盲测，也不是农业实测数据或原研究确认集。三顺序共享多重集，独立生成单位只有16组；本次不做bootstrap、置信区间或显著性检验，不能保证任意OOD表现。')
d.add_page_break();heading('四策略完整单元均值')
full=[]
for c in s['per_family_order']:
    full.append([names[c['family']]+' '+orders[c['order']]]+[f'{c["mean_bins"][p0]:.2f}' for p0 in ['BF','BF_then_EoH','published_EoH','SELECTOR']])
table(['族与顺序','全BF','固定SBS','全EoH','SELECTOR'],full,[1.6,1.4,1.4,1.4,1.4])
heading('验证与资源')
para(f'192次实际运行共960000步全部完成。独立标量评分与整数状态回放逐步核对可行性、首索引破同分、箱残量、累计箱数和体积守恒；48次前缀状态及选择器邻居预测均核验，SELECTOR完整轨迹逐条等于其合法所选真实分支。该验证使用独立实现，在同一受限进程内运行。')
para(f'包含输入生成、全部策略、全轨迹验证和正式统计的子进程CPU {r["cpu_total_seconds"]:.6f}秒，wall {r["wall_seconds"]:.6f}秒；预设CPU硬上限180秒、wall硬上限600秒。无失败重跑。报告排版及独立外部审计不属于这次正式数值子进程；其范围另有文件说明。')
para('模型、runner、selector、checker、原生成器代码、两个控制源及许可证均逐字节复制，原8项源文件在执行前后哈希一致；未读取原132、原heldout或旧输入/原始成绩。数值和复验边界见CHECK.json、SOURCE_ISOLATION_CHECK.json及外部审计文件。')
para('原MODEL SHA256：'+p['model_sha256'])
para('输入及代码冻结清单：FREEZE.json。原768次历史实验、已交付包及本地科研面板数据范围保持不变，本结果独立封装。')
d.core_properties.title='BPP 冻结选择器新尺寸族短实验';d.core_properties.subject='48条新合成流的冻结模型有限外分布评估';d.core_properties.author=''
for root in [d.styles.element,d.element]:
    for b in list(root.iter(qn('w:pBdr'))):b.getparent().remove(b)
d.save(H/'BPP冻结选择器新尺寸族短实验.docx');(H/'REPORT_ZH.txt').write_text('\n\n'.join(text)+'\n')
print('Created DOCX and plain-text report from frozen official results.')
