"""Freeze all experimental choices using historical metadata only, before fitting."""
import pathlib,json,hashlib,random,time,shutil
H=pathlib.Path(__file__).resolve().parent
canon=lambda v:json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(p,v):
    with pathlib.Path(p).open('x') as f:f.write(canon(v)+'\n')
def main():
    src=H/'original';p=json.loads((src/'PROTOCOL.json').read_text());families=p['families']
    metas=[r for r in p['instances'] if r['split'] in ['train','confirmation']]
    seeds=list(range(2026100701,2026100721));sizes=[1,2,4,8]
    plan=[]
    for track in ['family_holdout','within_family']:
        folds=families if track=='family_holdout' else ['all_six']
        for fold in folds:
            train=[r for r in metas if r['split']=='train' and (track=='within_family' or r['family']!=fold)]
            test=[r for r in metas if r['split']=='confirmation' and (track=='within_family' or r['family']==fold)]
            tf=[f for f in families if track=='within_family' or f!=fold]
            for seed in seeds:
                orders={}
                for f in tf:
                    g=sorted(set(r['group_id'] for r in train if r['family']==f))
                    rng=random.Random(int(sha(f'{seed}|{f}'.encode())[:16],16));rng.shuffle(g);orders[f]=g
                for size in sizes:
                    chosen={g for f in tf for g in orders[f][:size]}
                    trs=[r for r in train if r['group_id'] in chosen]
                    assert not ({r['group_id'] for r in trs}&{r['group_id'] for r in test})
                    assert not ({r['multiset_sha256'] for r in trs}&{r['multiset_sha256'] for r in test})
                    if track=='family_holdout':assert not ({r['family'] for r in trs}&{r['family'] for r in test})
                    plan.append({'track':track,'fold':fold,'seed':seed,'groups_per_training_family':size,'train_groups':len(chosen),'train_streams':len(trs),'train_ids':[r['instance_id'] for r in trs],'test_ids':[r['instance_id'] for r in test],'pool_ids':[r['instance_id'] for r in train]})
    protocol={'schema':'bpp-selector-training-size-offline-ablation-v1','created_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'question':'How does the number of independently drawn training multisets affect a fixed prefix-only kNN selector?','provenance':{'original_source_zip_sha256':sha((H/'original_source.zip').read_bytes()),'source_container':'/tmp/review_uploaded_research_panel/delivery.zip','original_historical_streams':264,'original_historical_policy_runs':768,'source_scope':'Use 252 train/confirmation streams and 504 existing BF/BF_then_EoH policy outcomes. Exclude 12 risk streams and all drift outcomes.'},'primary':'family_holdout: six fixed leave-one-family-out folds, test only historical confirmation samples of held-out family, no test-family training data. Aggregate all 108 fixed test streams at each size and seed.','secondary':'within_family: all six families train and test, but independently drawn multisets and all their orderings strictly separated. Fixed 108 confirmation streams.','sample_sizes':{'groups_per_training_family':sizes,'family_holdout_groups':[5,10,20,40],'family_holdout_streams':[15,30,60,120],'within_family_groups':[6,12,24,48],'within_family_streams':[18,36,72,144]},'seeds':seeds,'nesting':'Hash-seeded stdlib Random shuffles within each training family; 1/2/4/8 group prefixes nested; same seed-family order across folds. All three arrival-order variants of each multiset stay together. Training row order retains original protocol order.','selector':{'method':'original 5NN mean-cost regression with only fit shape assertion generalized','k':5,'features':'Original 31 BF500 prefix/state features unchanged; features only from arrived first500 items and their BF state. No family/order labels exposed to predictor.','standardization':'Mean and population standard deviation fitted on each selected training subset only; zero std becomes1.','distance':'Squared Euclidean; stable row-order tie break.','prediction_tie':'Matched subset SBS; BF wins SBS ties.','labels':['BF','BF_then_EoH'],'knn_refit':True,'hyperparameter_search':False},'comparators':['subset_training_SBS','full_training_pool_SBS (diagnostic reference)','same-prefix two-branch hindsight oracle min(BF,BF_then_EoH)'],'metrics':['Mean bins','Mean selector minus subset SBS bins (negative favorable)','Mean selector regret to two-branch oracle','SBS oracle gap','Fraction of SBS gap recovered (null when gap0)','Paired W/T/L versus subset SBS','Worst harm','Descriptive mean/min/max across20 subset seeds','All family/order cells'], 'inference':'Fixed historically observed finite synthetic panel; test data were available in earlier research. This protocol is frozen before new ablation results, not a newly blinded confirmation. Seeds vary training subsets only and are not independent test replications. No significance or population CI claim.','execution_scope':{'new_streams':0,'new_policy_runs':0,'model_api_calls':0,'llm_calls':0,'paid_api_charge':0,'new_offline_models':560,'new_offline_test_decisions':17280,'expected_unique_test_streams':108},'budgets':{'process_tree_cpu_seconds':180,'single_process_soft_cpu_seconds':175,'wall_seconds':1200,'threads':1},'no_adaptive_changes':'All methods, sizes, seeds, partitions, row orders and reporting are frozen before fitting; no outcome-driven tuning, row dropping, reruns, sample-size changes or early success stop.'}
    put(H/'PROTOCOL.json',protocol);put(H/'SPLITS.json',plan)
    files={n:sha((H/n).read_bytes()) for n in ['prepare.py','run.py','audit.py','pipeline.py','PROTOCOL.json','SPLITS.json','original_source.zip']}
    put(H/'FREEZE.json',{'created_utc':protocol['created_utc'],'before_new_fitting':True,'files':files})
    print(canon({'stage':'frozen','sha256':sha((H/'FREEZE.json').read_bytes()),'models':len(plan)}),flush=True)
