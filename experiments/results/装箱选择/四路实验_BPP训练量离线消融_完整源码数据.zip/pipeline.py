"""One process, no children; CPU hard cap180s applies to the complete experiment tree."""
import os,time,resource,signal,sys,json,traceback,pathlib
for k in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[k]='1'
resource.setrlimit(resource.RLIMIT_CPU,(175,180));signal.alarm(1200)
H=pathlib.Path(__file__).resolve().parent
start=time.monotonic();cpu=time.process_time();stages=[]
def stop(sig,frame):raise RuntimeError(f'Budget stop signal {sig}')
signal.signal(signal.SIGXCPU,stop);signal.signal(signal.SIGALRM,stop)
try:
    for name in ['prepare','run','audit']:
        s=time.monotonic();c=time.process_time();mod=__import__(name);mod.main();stages.append({'stage':name,'cpu_seconds':time.process_time()-c,'wall_seconds':time.monotonic()-s})
    from prepare import put
    put(H/'COST.json',{'status':'complete','numerical_pipeline_cpu_seconds':time.process_time()-cpu,'numerical_pipeline_wall_seconds':time.monotonic()-start,'stages':stages,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'execution_processes':1,'child_processes':0,'cpu_hard_limit_seconds':180,'cpu_soft_limit_seconds':175,'wall_limit_seconds':1200,'threads':1,'monetary_charge':0,'currency':'USD','api_calls':0,'llm_calls':0,'new_streams':0,'new_policy_runs':0,'new_experimental_selector_fits':560,'original_full_model_reconstruction_for_integrity_check':1,'offline_test_decisions':17280,'historical_raw_label_runs_verified':504,'training_size_seed_evaluations':160,'unique_test_streams':108,'distinct_evaluations_note':'560 model fits include 480 family-held-out fold fits and80 within-family fits. The largest subset is identical across seeds by design. Seed repeats are not additional independent test data.','cost_scope':'Measured single-process preparation, source checking, fitting, prediction, serialization and checker. Excludes connector download latency and pre-run script authoring/archive extraction.'})
except BaseException as e:
    p=H/'FAILURE.json';p.write_text(json.dumps({'error':str(e),'traceback':traceback.format_exc(),'cpu_seconds':time.process_time()-cpu,'wall_seconds':time.monotonic()-start,'completed_stages':stages},ensure_ascii=False,indent=2));raise
finally:signal.alarm(0)
