"""Separate checker implementation: recompute every saved prediction and audit grouping."""
import json,pathlib,time,collections
import numpy as np
from prepare import H,put,sha

def main():
    freeze=json.loads((H/'FREEZE.json').read_text());assert all(sha((H/n).read_bytes())==s for n,s in freeze['files'].items())
    plans=json.loads((H/'SPLITS.json').read_text());data={r['instance_id']:r for r in json.loads((H/'DATA.json').read_text())};fits=json.loads((H/'FITS.json').read_text());rows=[json.loads(s) for s in (H/'RAW_PREDICTIONS.jsonl').read_text().splitlines()]
    byrun=collections.defaultdict(list)
    for r in rows:byrun[r['run_id']].append(r)
    groups=collections.defaultdict(list)
    for run_id,p in enumerate(plans):
        a=[data[x] for x in p['train_ids']];b=[data[x] for x in p['test_ids']];assert len(set(p['train_ids']))==len(a)
        assert all(n==3 for n in collections.Counter(r['group_id'] for r in a).values())
        for key in ['group_id','multiset_sha256']:
            assert not ({r[key] for r in a}&{r[key] for r in b})
        if p['track']=='family_holdout':assert not ({r['family'] for r in a}&{r['family'] for r in b})
        groups[p['track'],p['fold'],p['seed']].append(p)
        x=np.array([r['features'] for r in a]);y=np.array([r['costs'] for r in a]);mu=x.sum(axis=0)/len(x);sd=np.sqrt(((x-mu)**2).sum(axis=0)/len(x));sd[sd==0]=1;zx=(x-mu)/sd;sbs=0 if y[:,0].sum()<=y[:,1].sum() else 1
        model=json.loads((H/'models'/f'{run_id:04d}.json').read_text());assert np.allclose(mu,model['mean'],atol=1e-14,rtol=0) and np.allclose(sd,model['scale'],atol=1e-14,rtol=0);assert model['sbs']==sbs
        assert sha((H/'models'/f'{run_id:04d}.json').read_bytes())==fits[run_id]['model_sha256']
        assert len(byrun[run_id])==len(b)
        for r in byrun[run_id]:
            item=data[r['instance_id']];z=(np.array(item['features'])-mu)/sd;ds=np.sum((zx-z)**2,axis=1);order=sorted(range(len(a)),key=lambda i:(ds[i],i))[:5];sum0=int(y[order,0].sum());sum1=int(y[order,1].sum());choice=sbs if sum0==sum1 else int(sum1<sum0)
            assert r['neighbors']==[a[i]['instance_id'] for i in order]
            assert choice==r['selected_index'] and r['selected_bins']==item['costs'][choice]
            assert r['subset_sbs_bins']==item['costs'][sbs] and r['oracle_bins']==min(item['costs'])
            assert r['selected_bins']>=r['oracle_bins']
    for ps in groups.values():
        ps.sort(key=lambda p:p['groups_per_training_family']);assert [p['groups_per_training_family'] for p in ps]==[1,2,4,8]
        assert all(set(a['train_ids'])<set(b['train_ids']) and a['test_ids']==b['test_ids'] for a,b in zip(ps,ps[1:]))
    for sm in json.loads((H/'SEED_METRICS.json').read_text()):
        rr=[r for r in rows if (r['track'],r['groups_per_training_family'],r['seed'])==(sm['track'],sm['groups_per_training_family'],sm['seed'])];assert len(rr)==108
        deltas=[r['selected_bins']-r['subset_sbs_bins'] for r in rr]
        assert abs(sum(deltas)/108-sm['delta_vs_subset_sbs'])<1e-12
        assert sum(d<0 for d in deltas)==sm['wins'] and sum(d>0 for d in deltas)==sm['losses']
        assert abs(sum(r['selected_bins']-r['oracle_bins'] for r in rr)/108-sm['regret'])<1e-12
    exact_full=[]
    for r in rows:
        if r['track']=='within_family' and r['groups_per_training_family']==8:
            src=json.loads((H/'original'/'raw'/f"{r['instance_id']}__SELECTOR.json").read_text())
            assert src['used_bins']==r['selected_bins'] and src['branch']==r['selected_branch'];exact_full.append(r)
    assert len(plans)==560 and len(rows)==17280 and len(data)==252
    put(H/'AUDIT.json',{'passed':True,'checker':'Separate numerical implementation, same author; not an independent human or agent review.','source_freeze_verified':True,'all_predictions_recomputed':len(rows),'grouped_split_checks':len(plans),'nested_subset_chains':len(groups),'family_holdout_models':480,'within_family_models':80,'full_training_original_selector_predictions_matched':len(exact_full),'label_and_regret_checks':True,'failure_count':0,'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())})
    print('AUDIT passed: all 17280 offline decisions, 560 split/model records, and full-size original parity.',flush=True)
