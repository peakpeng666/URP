"""Pure post-hoc descriptive decomposition; never fits, tunes, or alters predictions."""
import json,pathlib
H=pathlib.Path(__file__).resolve().parent
plans=json.loads((H/'SPLITS.json').read_text());raw=[json.loads(l) for l in (H/'RAW_PREDICTIONS.jsonl').read_text().splitlines()];cells=json.loads((H/'CELL_METRICS.json').read_text());rows=[]
for fam in json.loads((H/'original/PROTOCOL.json').read_text())['families']:
    for order in ['random','ascending','descending']:
        rr=[]
        for size in [1,2,4,8]:
            a=[r for r in cells if r['track']=='family_holdout' and r['groups_per_training_family']==size and r['family']==fam and r['order']==order]
            rr.append({'groups_per_training_family':size,'mean_delta':sum(r['delta_vs_subset_sbs'] for r in a)/20,'mean_regret':sum(r['regret'] for r in a)/20})
        rows.append({'family':fam,'order':order,'values':rr,'contribution_to_20_to_40_group_delta_change':(rr[-1]['mean_delta']-rr[-2]['mean_delta'])/18})
normal=[r for r in raw if r['track']=='family_holdout' and r['groups_per_training_family']==8 and r['seed']==2026100701 and r['family']=='normal_50_15' and r['order']=='ascending']
d={'classification':'post-hoc descriptive decomposition only; no models, splits, parameters, or results changed','all_family_order_cells':rows,'normal_ascending_full_model':{'n':len(normal),'all_five_neighbors_bimodal_ascending':all(all('bimodal_20_30_70_80' in i and i.endswith('__ascending') for i in r['neighbors']) for r in normal),'mean_harm':sum(r['selected_bins']-r['subset_sbs_bins'] for r in normal)/len(normal),'worst_harm':max(r['selected_bins']-r['subset_sbs_bins'] for r in normal),'raw_examples':normal},'distinct_training_subsets':len({tuple(p['train_ids']) for p in plans})}
# Existing results can be verified without overwriting them.
out=H/'POSTHOC_DIAGNOSIS.json'
if out.exists():assert json.loads(out.read_text())==d
else:out.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
