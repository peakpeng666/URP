"""Package only the frozen ablation, its history, and complete results."""
import pathlib,hashlib,json,zipfile,time,resource
H=pathlib.Path(__file__).resolve().parent;t=time.monotonic();c=time.process_time()
exclude={'source.zip','selector_sizes_20261007.zip','MANIFEST.json','SHA256SUMS.txt','PACKAGE_RECEIPT.json'}
files=[p for p in H.iterdir() if p.is_file() and p.name not in exclude]+list((H/'models').glob('*.json'))
files=sorted(files,key=lambda p:str(p.relative_to(H)));manifest=[]
for p in files:manifest.append({'file':str(p.relative_to(H)),'size_bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(H/'MANIFEST.json').write_text(json.dumps({'artifact':'BPP selector training-sample-size offline ablation','files':manifest,'note':'Core experiment code and protocol pinned before fitting in FREEZE.json; report/posthoc/package source created after results, no tuning.'},ensure_ascii=False,indent=2)+'\n')
(H/'SHA256SUMS.txt').write_text(''.join(f"{x['sha256']}  {x['file']}\n" for x in manifest))
files += [H/'MANIFEST.json',H/'SHA256SUMS.txt']
out=H/'selector_sizes_20261007.zip'
with zipfile.ZipFile(out,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in files:
        z.write(p,arcname=p.relative_to(H),compress_type=zipfile.ZIP_STORED if p.name=='original_source.zip' else zipfile.ZIP_DEFLATED)
with zipfile.ZipFile(out) as z:assert z.testzip() is None
r={'file':out.name,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'size_bytes':out.stat().st_size,'packaging_cpu_seconds':time.process_time()-c,'packaging_wall_seconds':time.monotonic()-t,'members':len(files),'tested_crc':True,'external_uploads':0}
(H/'PACKAGE_RECEIPT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
