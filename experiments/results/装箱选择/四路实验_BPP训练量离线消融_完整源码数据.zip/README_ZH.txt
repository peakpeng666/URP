BPP 选择器训练样本量消融

先读 REPORT_ZH.txt，再按需要检查 SUMMARY.json、SEED_METRICS.json、CELL_METRICS.json。
本包新增560次离线拟合（427个不同训练子集）和17280次离线决策；不含任何新增策略运行、流生成或LLM调用。

关键文件：
- PROTOCOL.json：冻结的实验方法、指标、种子、样本量与预算。
- SPLITS.json：560次拟合的完整train/test/pool实例名单。
- FREEZE.json：新拟合前的协议、名单、核心源码与历史原包哈希。
- prepare.py/run.py/audit.py/pipeline.py：完整主流程源码。
- original_source.zip：完整历史包，恢复后见original/；SHA在FREEZE内。
- DATA.json：252条历史流的31维前缀特征和两分支真实箱数。
- SOURCE_CHECKS.json：504条历史标签、输入与轨迹对应哈希及检查。
- models/：560次实际拟合参数和训练行ID。
- FITS.json：每次fit的元数据、SBS及CPU记录。
- RAW_PREDICTIONS.jsonl：17280条新离线选择、近邻、距离、预测及实际标签。
- SEED_METRICS.json/seed_metrics.csv：160种track×size×seed结果。
- CELL_METRICS.json/family_order_cells.csv：全部家族×顺序结果。
- POSTHOC_DIAGNOSIS.json：结果后分解，未影响模型或选参。
- build_report.py/REPORT_ZH.txt：仅基于已固定结果的中文报告。
- RUN_STARTED.json/RUN_COMPLETE.json/PIPELINE.log：原始执行记录。
- AUDIT.json：单独实现的全量代码交叉核验；并非独立审稿。
- COST.json：时间、资源、次数、失败边界与0新增API收费口径。
- RECOVERY.json：数据恢复来源及完整性证据。
- MANIFEST.json/SHA256SUMS.txt：本交付的最终文件校验。

复现须在新目录执行，避免覆盖本次冻结与原始结果（程序使用独占创建模式）：
1. 创建一个空目录，例如reproduce。
2. 将prepare.py、run.py、audit.py、pipeline.py以及original_source.zip复制到其中。
3. 在新目录运行：unzip -q original_source.zip -d original
4. 运行：OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 OMP_NUM_THREADS=1 python pipeline.py
5. 比较新旧RAW_PREDICTIONS.jsonl、DATA.json、SUMMARY.json。时间和成本记录会变化；冻结创建时间也会变化；模型、划分、决策和指标应完全一致。
依赖为Python3和NumPy；本次Python/NumPy来自既有环境，无安装。

结果不支持跨家族性能随样本量单调提升；应同时查看完整负结果及最坏单流+622箱。
