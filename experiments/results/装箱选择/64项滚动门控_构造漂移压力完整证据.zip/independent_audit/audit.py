"""Read-only independent evidence audit. Never imports or executes experiment code."""
import json, pathlib, hashlib, hmac, ast
from fractions import Fraction
R=pathlib.Path('/workspace/shared/bpp_rolling_gate_20261008'); O=R.parent/'bpp_prefix_gate_drift_20261008'; A=R.parent/'audit_bpp_rolling_gate_20261008'
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda p:json.loads(p.read_text())
canon=lambda x:json.dumps(x,sort_keys=True,separators=(',',':')).encode()
initial={str(p.relative_to(R)):sha(p.read_bytes()) for p in R.rglob('*') if p.is_file()}
f=read(R/'SOURCE_FREEZE.json');seal=read(R/'DATA_SEAL.json');p=read(R/'policy.json');ex=read(R/'exclusions.json');release=read(R/'ROOT_RELEASE.json')
for n,h in f['files'].items():assert sha((R/n).read_bytes())==h,n
for n in ['engine.py','patch.py']:assert (R/n).read_bytes()==(O/n).read_bytes(),n
assert f['upstream_generator_sha256']==sha((O/'generate.py').read_bytes())
assert seal['source_freeze_sha256']==sha((R/'SOURCE_FREEZE.json').read_bytes())
assert release['approved'] is True
for n in ['SOURCE_FREEZE.json','DATA_SEAL.json']:assert sha((R/n).read_bytes()) in release['exact_parent_message']
assert f['unix']<release['unix']<read(R/'LAUNCH_CLAIM.json')['start']<read(R/'RUN_CLAIM.json')['unix']
assert p['window']==64 and p['threshold']==2880 and p['capacity']==100 and p['horizon']==1000
expected_plan=[{'sequence':i,'arm':a} for i in range(8) for a in (['B','G','R'][i%3:]+['B','G','R'][:i%3])]
assert p['actions']==seal['plan']==expected_plan
assert len(seal['instances'])==8 and len(set((a['sequence'],a['arm']) for a in seal['plan']))==24
prior=set(read(O/'exclusions.json')['hashes'])|{x['items_sha256'] for x in read(O/'DATA_SEAL.json')['instances']}
assert set(ex['hashes'])==prior and len(ex['hashes'])==len(prior)==seal['known_array_exclusions']==79
oldseeds=[]
for name,domain,n in [('bpp_online_prefix_gate_20261008',b'online-prefix-gate-v1|',12),('bpp_prefix_gate_drift_20261008',b'prefix-drift-v1|',16)]:
 d=R.parent/name;entropy=(d/'entropy.bin').read_bytes();ph=sha((d/'policy.json').read_bytes()).encode()
 oldseeds.extend(int.from_bytes(hmac.new(entropy,domain+ph+b'|'+str(i).encode(),hashlib.sha256).digest()[:16],'big') for i in range(n))
assert oldseeds==ex['known_seed_values'] and len(set(oldseeds))==seal['known_seed_exclusions']==28
assert len((R/'entropy.bin').read_bytes())==32
rows=[];flat=[];newhash=set();newseed=set();bf=0;patch=0
assert len(list((R/'trajectories').glob('*.json')))==24
for i,e in enumerate(seal['instances']):
 assert e['sequence']==i and {k:e[k] for k in p['sequences'][i]}==p['sequences'][i]
 raw=(R/e['path']).read_bytes();inp=json.loads(raw);items=inp['items'];assert inp['capacity']==100 and len(items)==1000 and all(type(x) is int and 1<=x<=100 for x in items)
 assert sha(raw)==e['file_sha256'] and sha(canon(items))==e['items_sha256']
 assert e['items_sha256'] not in prior|newhash;newhash.add(e['items_sha256'])
 seed=int.from_bytes(hmac.new((R/'entropy.bin').read_bytes(),b'rolling-gate-v1|'+sha((R/'policy.json').read_bytes()).encode()+b'|'+str(i).encode(),hashlib.sha256).digest()[:16],'big')
 assert seed==e['seed'] and seed not in set(oldseeds)|newseed;newseed.add(seed)
 row={'sequence':i,'family':e['family'],'prefix64_sum':sum(items[:64]),'bins':{},'F_exact':{},'diagnostics':{}}
 traces={}
 for arm in ['B','G','R']:
  t=read(R/f'trajectories/{i:02d}_{arm}.json');assert t['arm']==arm and t['sequence']==i and t['family']==e['family'];assert len(t['events'])==len(t['assignment'])==1000
  if arm=='R':assert len(t['decisions'])==1000
  remaining=[100]*1000;methods=[];prefix=sum(items[:64])
  for k,x in enumerate(items):
   past=sum(items[max(0,k-64):k]) if k>=64 else None
   m='P' if k>=64 and ((arm=='G' and prefix<2880) or (arm=='R' and past<2880)) else 'B';methods.append(m)
   feasible=[j for j,r in enumerate(remaining) if r>=x]
   j=t['assignment'][k];assert type(j) is int and j in feasible
   if m=='B':assert j==min(feasible,key=lambda j:remaining[j]);bf+=1
   else:patch+=1
   before=remaining[j];remaining[j]-=x
   assert t['events'][k]=={'step':k+1,'item':x,'bin':j,'remaining_before':before,'remaining_after':remaining[j],'method':m,'feasible_count':len(feasible)}
   if arm=='R':assert t['decisions'][k]=={'step':k+1,'previous64_sum':past,'method':m}
  assert sum(100-r for r in remaining)==sum(items) and remaining==t['remaining'] and all(0<=r<=100 for r in remaining)
  bins=sum(r<100 for r in remaining);F=str(Fraction((sum(items)+99)//100,bins));assert t['used_bins']==bins and t['F_exact']==F
  if arm=='G':assert t['gate']=={'decision_after_item':64,'first_postdecision_item':65,'observed_prefix_sum':prefix,'threshold':2880,'switch':prefix<2880,'rule':'strict_less'}
  if arm=='B':assert t['gate'] is None
  changes=[k+1 for k in range(1,1000) if methods[k]!=methods[k-1]];cp=e['change_after_item']
  row['bins'][arm]=bins;row['F_exact'][arm]=F;row['diagnostics'][arm]={'patch_prefix_steps':methods[:cp].count('P'),'patch_suffix_steps':methods[cp:].count('P'),'switch_count':len(changes),'switch_steps':changes,'first_post_cp_method_change':next((x for x in changes if x>cp),None)}
  flat.append({key:t[key] for key in ['sequence','family','arm','used_bins','F_exact','measured_CPU_seconds','measured_wall_seconds']});traces[arm]=t
 assert traces['B']['events'][:64]==traces['G']['events'][:64]==traces['R']['events'][:64]
 if prefix>=2880:assert traces['G']['events']==traces['B']['events']
 for arm in ['B','G']:
  row['R-'+arm]=row['bins']['R']-row['bins'][arm];row['R-'+arm+'_F_exact']=str(Fraction(row['F_exact']['R'])-Fraction(row['F_exact'][arm]))
 rows.append(row)
assert rows==read(R/'PAIRED_RESULTS.json')
flatmap={(x['sequence'],x['arm']):x for x in flat};assert read(R/'RESULTS.json')==[flatmap[(x['sequence'],x['arm'])] for x in expected_plan]
groups=[]
for fam in dict.fromkeys(x['family'] for x in rows):
 for arm in ['B','G']:
  ds=[x['R-'+arm] for x in rows if x['family']==fam];groups.append({'family':fam,'contrast':'R-'+arm,'paired_bin_deltas':ds,'mean_delta':sum(ds)/2,'wins_ties_losses':[sum(d<0 for d in ds),sum(d==0 for d in ds),sum(d>0 for d in ds)]})
assert groups==read(R/'GROUP_SUMMARY.json')
receipt=read(R/'EXIT_RECEIPT.json');assert receipt['exit_code']==receipt['raw_wait_status']==0 and receipt['status']=='PASS' and receipt['reaped'] is True and receipt['retry'] is False
assert receipt['CPU_total']==receipt['CPU_user']+receipt['CPU_system'] and 0<receipt['CPU_total']<60 and 0<receipt['wall_seconds']<90
assert receipt['CPU_limit_seconds']==60 and receipt['wall_limit_seconds']==90
assert read(R/'RUN_CLAIM.json')['pid']==receipt['pid'] and read(R/'RUN_CLAIM.json')['attempt']==read(R/'LAUNCH_CLAIM.json')['attempt']==1
assert read(R/'GENERATION_CLAIM.json')=={'attempt':1,'candidate_calls':0,'entropy_draws':1} and seal['generation_attempts']==1 and seal['candidate_calls_before_seal']==0
assert (R/'stderr.txt').read_bytes()==b'' and json.loads((R/'stdout.txt').read_text())==read(R/'RESULTS.json')
assert {str(q.relative_to(R)):sha(q.read_bytes()) for q in R.rglob('*') if q.is_file()}==initial
out={'status':'PASS','trajectories':24,'placements':bf+patch,'BF_placements_verified':bf,'patch_placements_feasibility_verified':patch,'patch_scores_recomputed':False,'original_files_unchanged':True,'source_freeze_sha256':sha((R/'SOURCE_FREEZE.json').read_bytes()),'data_seal_sha256':sha((R/'DATA_SEAL.json').read_bytes()),'historical_array_hashes':79,'historical_known_seeds':28,'new_unique_streams':8,'resource_receipt':receipt,'paired_rows':rows,'group_summary':groups,'limitations':['No strategy, scorer or generator executed; no patch score ranking recomputation.','Historical dedup limited to 79 supplied array hashes and 28 prefix/drift seeds; no universal unseen-history assertion.','One-run receipts and exclusive-create guards support recorded once-only execution, not proof against activity outside this directory.','Binding to actual root authorization additionally requires parent message provenance confirmation.']}
provenance=A/'AUTHORIZATION_PROVENANCE.json'
if provenance.exists():
 proof=read(provenance);assert proof['matches_ROOT_RELEASE'] is True and proof['exact_root_message']==release['exact_parent_message']
 out['root_authorization_provenance_confirmed']=True
 out['limitations']=[v for v in out['limitations'] if 'additionally requires' not in v]
(A/'AUDIT.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');(A/'EVIDENCE_MANIFEST.json').write_text(json.dumps(initial,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['paired_rows','group_summary']},ensure_ascii=False,indent=2))
