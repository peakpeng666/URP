# Rolling gate 独立只读审计：PASS

## 已完成复核
- SOURCE_FREEZE 所列9份文件逐字节SHA-256一致；DATA_SEAL正确绑定freeze；授权原文绑定freeze和seal，且父任务通过消息确认其为实际收到的root原文。原engine.py和patch.py与上一漂移实验逐字节一致。
- 人工源码检查：rolling.py在每次放置前从已有deque/window_sum决策，前64步BF；第65步起仅使用此前64项之和，严格小于2880才启用patch。当前项放置后才进入窗口，未读取family/变点/未来数值，无重置。当前item当然参与装箱可行性与scorer，但不参与该步gate。
- 8份1000项整数输入的文件与数组哈希均匹配seal，互不重复，均不在79历史数组哈希内。28个prefix/drift历史seed独立由原熵/域/策略哈希重导出，8个新seed绑定当前熵与策略哈希且互不冲突。未重采样或重运行生成器。
- 独立整数复核24条轨迹全部24,000次放置；容量、可行性、守恒、事件字段、最终余量、箱数、F全部正确。15,439次BF以独立最小可行剩余空间和索引tie-break校验；8,561次patch放置仅检查可行性与记录一致，不重算patch分值/argmax。
- 全部G/R门控方法及R逐步过去64项和均核对正确；前64步三臂一致；完整配对数据、switch和变点前后patch数量、GROUP_SUMMARY与RESULTS逐项完全一致。
- 一次性generation/launch/run收据均为attempt=1；排他创建保护和CPU/wall硬限在源码中存在。退出0，reaped=true，retry=false，stderr空，stdout与RESULTS一致。

## 结果与资源
- 总箱数：B=3785，G=3821，R=3749。
- R−B依序为[+2, −2, −5, −5, −8, −10, −5, −3]；R−G依序为[−9, −14, −16, −11, −8, −10, −5, +1]。明确存在负面结果：序列0比BF多2箱，序列7比静态G多1箱。
- 收据CPU=2.107602秒，wall=2.109930286秒，maxrss=23872 KiB；限制60 CPU秒/90 wall秒。

## 边界
- 仅8条构造漂移流，每族2条；不能据此声称普遍优越或显著性。F是ceil(总尺寸/100)/箱数，不是已知真实最优解比。
- 去重仅覆盖给定79历史数组hash和28已知seed，不声称全部历史或未见分布保证。
- 收据和排他写支持目录中记录的一次执行，无法凭文件证明目录外不存在其他执行。
- 未导入/运行策略、scorer或生成器，未重算patch分值，未读取GLM pilot/C1，未修改原实验文件。原文件审计前后哈希完全一致。

## 审计产物
- audit.py：独立整数复核脚本
- AUDIT.json：完整结构化结果、全部配对及组汇总
- EVIDENCE_MANIFEST.json：被审原文件SHA-256清单
- AUTHORIZATION_PROVENANCE.json：父任务确认的root原文及匹配结果

审计清单绑定当时已存在的科学证据（源码冻结、输入、轨迹、结果与运行收据）；父任务后续更新的叙述性REPORT_ZH.md不在本次初始快照中，由最终交付manifest另行绑定。
