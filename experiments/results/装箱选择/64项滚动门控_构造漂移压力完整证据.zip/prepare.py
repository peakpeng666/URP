import json,pathlib,hashlib,hmac,os,time,numpy as np,importlib.util
R=pathlib.Path(__file__).resolve().parent;S=R.parent
canon=lambda x:json.dumps(x,sort_keys=True,separators=(',',':')).encode()
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(n,x):
 with (R/n).open('xb') as f:f.write(canon(x)+b'\n')
old=S/'bpp_prefix_gate_drift_20261008'
spec=importlib.util.spec_from_file_location('old_generator',old/'generate.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
seq=[]
for direction in ['W_to_U','U_to_W']:
 for cp in [64,500]:
  for rep in range(2):seq.append({'sequence':len(seq),'direction':direction,'change_after_item':cp,'within_family':rep,'family':f'{direction}_cp{cp}'})
policy={'arms':['B','G','R'],'R':'First64 BF. Before assigning t>=65 use patch iff sum(items[t-64..t-1])<2880, else BF; 1-based indexing. Current item excluded. Update after placing. No family input. No resets.','G':'Original unchanged engine.py static prefix64 strict sum<2880','capacity':100,'horizon':1000,'window':64,'threshold':2880,'sequences':seq,'actions':[{'sequence':i,'arm':a} for i in range(8) for a in (['B','G','R'][i%3:]+['B','G','R'][:i%3])],'metrics':['total_bins','F_exact','paired_R_minus_B','paired_R_minus_G','patch_steps_before_after_cp','switch_count','first_post_cp_method_change'],'scope':'Constructed mechanism stress only. No model/API calls, tuning, repeat, replacement or expansion. Independent of GLM pilot and C1; those data not read.','limits':{'CPU_seconds':60,'wall_seconds':90},'generation':'Original drift generate.py draw/generate functions; one 32-byte entropy draw, HMAC independent seeds, known-array and known-seed exact dedup; stop on collision'}
put('policy.json',policy)
prior=set(json.loads((old/'exclusions.json').read_text())['hashes']);prior.update(e['items_sha256'] for e in json.loads((old/'DATA_SEAL.json').read_text())['instances'])
seeds=[]
for name,domain,count in [('bpp_online_prefix_gate_20261008',b'online-prefix-gate-v1|',12),('bpp_prefix_gate_drift_20261008',b'prefix-drift-v1|',16)]:
 d=S/name;entropy=(d/'entropy.bin').read_bytes();ph=sha((d/'policy.json').read_bytes()).encode()
 seeds.extend(int.from_bytes(hmac.new(entropy,domain+ph+b'|'+str(i).encode(),hashlib.sha256).digest()[:16],'big') for i in range(count))
put('exclusions.json',{'hashes':sorted(prior),'known_seed_values':seeds,'seed_scope':'28 prefix/drift seeds derived from original entropy and original domain. Older arrays covered by 79 exact hashes; no unseen-history guarantee. Protected pilot/C1 not inspected.'})
put('SOURCE_FREEZE.json',{'unix':time.time(),'files':{p.name:sha(p.read_bytes()) for p in R.iterdir() if p.suffix in ['.py','.json']},'upstream_generator_sha256':sha((old/'generate.py').read_bytes())})
put('GENERATION_CLAIM.json',{'attempt':1,'entropy_draws':1,'candidate_calls':0})
master=os.getrandom(32)
with (R/'entropy.bin').open('xb') as f:f.write(master)
(R/'inputs').mkdir();entries=[];seen=set();seen_seed=set(seeds)
for e in seq:
 seed=int.from_bytes(hmac.new(master,b'rolling-gate-v1|'+sha((R/'policy.json').read_bytes()).encode()+b'|'+str(e['sequence']).encode(),hashlib.sha256).digest()[:16],'big')
 assert seed not in seen_seed;seen_seed.add(seed)
 items=g.generate(np.random.Generator(np.random.PCG64(seed)),e['direction'],e['change_after_item'])
 h=sha(canon(items));assert h not in prior and h not in seen;seen.add(h)
 path=f"inputs/{e['sequence']:02d}.json";put(path,{'capacity':100,'items':items})
 entries.append(dict(e,path=path,seed=seed,items_sha256=h,file_sha256=sha((R/path).read_bytes())))
put('DATA_SEAL.json',{'instances':entries,'source_freeze_sha256':sha((R/'SOURCE_FREEZE.json').read_bytes()),'generation_attempts':1,'candidate_calls_before_seal':0,'known_array_exclusions':len(prior),'known_seed_exclusions':len(seeds),'plan':policy['actions']})
print(json.dumps({p.name:sha(p.read_bytes()) for p in R.iterdir() if p.is_file()},indent=2))
