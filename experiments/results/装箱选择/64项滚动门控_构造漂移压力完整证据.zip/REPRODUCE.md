# 最小复核与复现说明

此包包含8条原始输入、24条完整逐步真实轨迹、原BF/静态门控源码、原patch、新滚动规则、固定策略/动作顺序/指标、冻结SHA和独审证据。

## 安全复核（不执行策略）
Python 3标准库足够。把本目录复制到新的临时目录，在该副本中删除派生输出 `PAIRED_RESULTS.json`、`GROUP_SUMMARY.json`、`VALIDATION.json`，执行 `python -B verify.py`。该脚本只读取输入与轨迹，重建24,000步真实容量/守恒、BF决策、门控和精确F，并重新生成这三个输出；它不导入numpy、engine、rolling或patch。不要在原封存目录删除或改动文件。

## 数值策略复现
原科学运行使用Python 3.12、NumPy 2.3.5。输入全部保留，复现无需重新采样。engine.py提供pack(items,'B'/'G')；rolling.py提供pack_rolling(items)。在独立副本/另一次标明为“复现”的运行中可调用它们，预计assignment、events、remaining、used_bins完全一致；CPU/wall字段不应一致。

本交付没有为复现再执行策略。原launch_once.py/run_once.py通过排他claim防止再次运行，不应删除原claim来重跑原科学任务。不要执行prepare.py来代替复用封存数据；其绝对来源路径记录原准备环境，不是可移植生成入口。upstream_generator.py提供原生成器字节证据，entropy.bin仅为实验随机性，非密钥/凭证。原数据种子和hash见DATA_SEAL.json。

所有新复现都应另建目录并另记时间与执行收据，不能覆盖或混淆此次唯一主跑证据。结论只覆盖本批8条构造压力流，不能解释为模型进步、自然分布泛化或无损保证。
