"""One fixed rolling rule. Gate sees only previously packed observations."""
from collections import deque
from engine import choose
import numpy as np

def pack_rolling(items):
 remaining=[100]*len(items);events=[];window=deque();window_sum=0;decisions=[]
 for step,item in enumerate(items,1):
  observed_sum=window_sum if len(window)==64 else None
  method='P' if observed_sum is not None and observed_sum<2880 else 'B'
  decisions.append({'step':step,'previous64_sum':observed_sum,'method':method})
  feasible=[j for j,r in enumerate(remaining) if r>=item]
  values=np.array([remaining[j] for j in feasible],dtype=np.float64);values.flags.writeable=False
  j=feasible[choose(item,values,method)];before=remaining[j];remaining[j]-=item
  events.append({'step':step,'item':item,'bin':j,'remaining_before':before,'remaining_after':remaining[j],'method':method,'feasible_count':len(feasible)})
  if len(window)==64:window_sum-=window.popleft()
  window.append(item);window_sum+=item
 return {'arm':'R','assignment':[e['bin'] for e in events],'events':events,'remaining':remaining,'used_bins':sum(r<100 for r in remaining),'decisions':decisions}
