import json,pathlib,time,hashlib,os
from fractions import Fraction
from engine import pack
from rolling import pack_rolling
R=pathlib.Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(n,x):
 with (R/n).open('x') as f:json.dump(x,f,separators=(',',':'))
put('RUN_CLAIM.json',{'attempt':1,'unix':time.time(),'pid':os.getpid()})
assert json.loads((R/'ROOT_RELEASE.json').read_text())['approved'] is True
for n,h in json.loads((R/'SOURCE_FREEZE.json').read_text())['files'].items():assert sha((R/n).read_bytes())==h,n
seal=json.loads((R/'DATA_SEAL.json').read_text());assert sha((R/'SOURCE_FREEZE.json').read_bytes())==seal['source_freeze_sha256']
(R/'trajectories').mkdir();rows=[]
for a in seal['plan']:
 e=seal['instances'][a['sequence']];raw=(R/e['path']).read_bytes();assert sha(raw)==e['file_sha256'];items=json.loads(raw)['items'];t=time.process_time();w=time.monotonic()
 r=pack_rolling(iterable:=items) if a['arm']=='R' else pack(items,a['arm'])
 r['measured_CPU_seconds']=time.process_time()-t;r['measured_wall_seconds']=time.monotonic()-w
 r.update({'sequence':e['sequence'],'family':e['family'],'F_exact':str(Fraction((sum(items)+99)//100,r['used_bins']))})
 put(f"trajectories/{e['sequence']:02d}_{a['arm']}.json",r);rows.append({k:r[k] for k in ['sequence','family','arm','used_bins','F_exact','measured_CPU_seconds','measured_wall_seconds']})
put('RESULTS.json',rows);print(json.dumps(rows))
