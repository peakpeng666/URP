"""Independent integer-only placement/selector/metric reconstruction; no scorer import."""
import json,pathlib,hashlib
from fractions import Fraction
R=pathlib.Path(__file__).resolve().parent
read=lambda n:json.loads((R/n).read_text())
rows=[];checks=[]
for e in read('DATA_SEAL.json')['instances']:
 items=read(e['path'])['items'];results={};cp=e['change_after_item']
 assert len(items)==1000 and all(type(x) is int and 1<=x<=100 for x in items)
 for arm in ['B','G','R']:
  r=read(f"trajectories/{e['sequence']:02d}_{arm}.json");loads=[];methods=[]
  assert len(r['assignment'])==len(r['events'])==1000
  for t,(item,j,event) in enumerate(zip(items,r['assignment'],r['events'])):
   previous=sum(items[t-64:t]) if t>=64 else None
   method='P' if t>=64 and ((arm=='G' and sum(items[:64])<2880) or (arm=='R' and previous<2880)) else 'B'
   methods.append(method)
   assert type(j) is int and 0<=j<=len(loads)
   count=sum(v+item<=100 for v in loads)+(1000-len(loads))
   if method=='B':
    feasible=[b for b,v in enumerate(loads) if v+item<=100]
    assert j==(min(feasible,key=lambda b:(100-loads[b],b)) if feasible else len(loads))
   if j==len(loads):loads.append(0)
   before=100-loads[j];loads[j]+=item;assert 0<loads[j]<=100
   assert event=={'step':t+1,'item':item,'bin':j,'remaining_before':before,'remaining_after':100-loads[j],'method':method,'feasible_count':count}
   if arm=='R':assert r['decisions'][t]=={'step':t+1,'previous64_sum':previous,'method':method}
  assert sum(loads)==sum(items) and len(loads)==r['used_bins']
  assert r['remaining']==[100-v for v in loads]+[100]*(1000-len(loads))
  assert r['F_exact']==str(Fraction((sum(items)+99)//100,len(loads)))
  if arm=='G':assert r['gate']['observed_prefix_sum']==sum(items[:64]) and r['gate']['switch']==(sum(items[:64])<2880)
  changes=[t+1 for t in range(1,1000) if methods[t]!=methods[t-1]]
  r['diagnostics']={'patch_prefix_steps':methods[:cp].count('P'),'patch_suffix_steps':methods[cp:].count('P'),'switch_count':len(changes),'switch_steps':changes,'first_post_cp_method_change':next((x for x in changes if x>cp),None)}
  results[arm]=r;checks.append({'sequence':e['sequence'],'arm':arm,'placements':1000})
 assert results['R']['events'][:64]==results['B']['events'][:64]==results['G']['events'][:64]
 if sum(items[:64])>=2880:assert results['G']['events']==results['B']['events']
 row={'sequence':e['sequence'],'family':e['family'],'prefix64_sum':sum(items[:64]),'bins':{a:r['used_bins'] for a,r in results.items()},'F_exact':{a:r['F_exact'] for a,r in results.items()},'diagnostics':{a:r['diagnostics'] for a,r in results.items()}}
 for b in ['B','G']:
  row['R-'+b]=results['R']['used_bins']-results[b]['used_bins']
  row['R-'+b+'_F_exact']=str(Fraction(results['R']['F_exact'])-Fraction(results[b]['F_exact']))
 rows.append(row)
summary=[]
for family in dict.fromkeys(r['family'] for r in rows):
 group=[r for r in rows if r['family']==family]
 for b in ['B','G']:
  ds=[r['R-'+b] for r in group];summary.append({'family':family,'contrast':'R-'+b,'paired_bin_deltas':ds,'mean_delta':sum(ds)/2,'wins_ties_losses':[sum(x<0 for x in ds),sum(x==0 for x in ds),sum(x>0 for x in ds)]})
for name,obj in [('PAIRED_RESULTS.json',rows),('GROUP_SUMMARY.json',summary),('VALIDATION.json',{'status':'PASS','trajectories':len(checks),'placements':sum(x['placements'] for x in checks),'independent_integer_reconstruction':True,'BF_and_gate_decisions_verified':True,'patch_scores_recomputed':False,'checks':checks})]:
 with (R/name).open('x') as f:json.dump(obj,f,indent=2)
print(json.dumps(summary,indent=2))
