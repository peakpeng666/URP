import datetime,json,os,pathlib,resource,subprocess,sys,time
h=pathlib.Path(__file__).resolve().parent;kind=sys.argv[1];target=h/kind;start=time.perf_counter();cpu=time.process_time()
def limit():resource.setrlimit(resource.RLIMIT_CPU,(85,90));os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
with (target/'AUDIT.log').open('x') as out:
 p=subprocess.Popen([sys.executable,str(target/'check_independent.py')],stdout=out,stderr=subprocess.STDOUT,preexec_fn=limit);pid,status,usage=os.wait4(p.pid,0);code=os.waitstatus_to_exitcode(status)
record={'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':code,'wall_seconds':time.perf_counter()-start,'child_user_cpu_seconds':usage.ru_utime,'child_system_cpu_seconds':usage.ru_stime,'child_total_cpu_seconds':usage.ru_utime+usage.ru_stime,'launcher_cpu_seconds_before_final_write':time.process_time()-cpu,'child_cpu_soft_cap':85,'child_cpu_hard_cap':90,'planning_metadata_documentation_cpu_conservative_allowance':20,'combined_budget_cpu_seconds':120}
(target/'PROCESS_RESOURCE.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record));sys.exit(code)
