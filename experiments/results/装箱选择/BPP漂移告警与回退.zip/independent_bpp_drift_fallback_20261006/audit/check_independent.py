"""All saved trajectories/argmax/scores checked without producer imports.
Capacity-class bitsets and prefix features reuse prior independent audit helper;
KS, monitoring, adaptive control, protocol/grid, calibration and summaries new.
"""
import ast,collections,csv,datetime,hashlib,json,math,pathlib,statistics,time,traceback
import numpy as np
from prior_independent_helper import ranks,features,decision,canon,digest,sha,read
H=pathlib.Path(__file__).resolve().parent;R=H.parents[1]/'independent_bpp_drift_fallback_20261006';POL=['BF','BF_then_EoH','published_EoH','SELECTOR','DRIFT_FALLBACK'];TIMES=list(range(1000,5001,500));PINS={};EXT={};progress=collections.Counter();start=time.process_time();score_error=0.;nn_error=0.
def load(name):PINS[name]=sha(R/name);return read(R/name)
def eq(a,b,label=''):
    if isinstance(a,dict):assert a.keys()==b.keys(),(label,a.keys(),b.keys());[eq(a[k],b[k],label+'/'+k) for k in a]
    elif isinstance(a,list):assert len(a)==len(b),(label,len(a),len(b));[eq(x,y,label+'/'+str(i)) for i,(x,y) in enumerate(zip(a,b))]
    elif isinstance(a,(int,float)) and not isinstance(a,bool):assert math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-12),(label,a,b)
    else:assert a==b,(label,a,b)
def ks(left,right):
    assert len(left)==len(right)==500;freq=collections.Counter(left);freq.subtract(right);v=maximum=0
    for i in range(1,101):v+=freq[i];maximum=max(maximum,abs(v))
    return maximum
def events(items,threshold):
    out=[];alarmed=False
    for t in TIMES:
        num=ks(items[:500],items[t-500:t]);exceed=num>threshold;first=exceed and not alarmed;alarmed|=first
        out.append({'observed_count':t,'reference_start_1based':1,'reference_end_1based':500,'recent_start_1based':t-499,'recent_end_1based':t,'ks_count':num,'ks_D':num/500,'threshold_count':threshold,'threshold_D':threshold/500,'strict_exceedance':exceed,'first_alarm':first,'latched_alarm':alarmed,'earliest_action_item_1based':t+1 if first else None,'history_only_arguments':True})
    return out

def make(family,seed):
    rng=np.random.Generator(np.random.PCG64(seed));n=5000
    if family=='small_beta_2_5':x=100*rng.beta(2,5,n)
    elif family=='large_beta_5_2':x=100*rng.beta(5,2,n)
    elif family=='normal_50_15':x=rng.normal(50,15,n)
    elif family=='bimodal_20_30_70_80':
        label=rng.integers(0,2,n);small=rng.integers(20,31,n);large=rng.integers(70,81,n);x=np.where(label==0,small,large)
    elif family=='weibull_3_45':x=45*rng.weibull(3,n)
    elif family=='uniform_1_100':x=rng.integers(1,101,n)
    else:raise AssertionError(family)
    clips={'raw_below_1':int(sum(x<1)),'raw_above_100':int(sum(x>100))};v=np.rint(np.clip(x,1,100)).astype(np.int64).tolist();order=np.random.Generator(np.random.PCG64(seed+1000000)).permutation(n).tolist()
    return [v[i] for i in order],order,clips

def replay(d,row,ranking,threshold):
    global score_error
    p=row['policy'];items=d['items'];n=len(items);assert n==5000 and row['steps']==n and row['status']=='complete' and row['error'] is None
    path=R/row['trajectory_file'];assert sha(path)==row['trajectory_sha256'];PINS[row['trajectory_file']]=sha(path)
    fields=['assignment','pre_remaining','post_remaining','feasible_counts','used_bins_after','algorithm_eoh','remaining','chosen_score']
    with np.load(path,allow_pickle=False) as z:
        assert sorted(z.files)==sorted(fields) and all(z[k].shape==(n,) for k in fields)
        assert all(np.issubdtype(z[k].dtype,np.integer) for k in fields if k!='chosen_score');assert np.issubdtype(z['chosen_score'].dtype,np.floating) and np.isfinite(z['chosen_score']).all();tr={k:z[k].tolist() for k in fields}
    ev=events(items,threshold) if p=='DRIFT_FALLBACK' else [];assert row['drift_events']==ev
    first=next((e['observed_count'] for e in ev if e['first_alarm']),None);assert first==row['first_alarm_observed_count'];actual=first+1 if first is not None and first<5000 and row['branch']=='BF' else None;assert row['actual_switch_item_1based']==actual
    rem=[100]*n;bins=[0]*101;bins[100]=(1<<n)-1;count=[0]*101;count[100]=n;present=1<<100;used=0;prefix=None
    for t,item in enumerate(items):
        eoh=p=='published_EoH' or (t>=500 and (row['branch']=='BF_then_EoH' or (p=='DRIFT_FALLBACK' and first is not None and t>=first)))
        assert tr['algorithm_eoh'][t]==int(eoh),(d['instance_id'],p,t,'algorithm')
        if eoh:
            for mask,residuals in ranking[item]:
                if present&mask:eligible=residuals;break
            target=min((bins[r]&-bins[r]).bit_length()-1 for r in eligible if bins[r])
        else:
            possible=present>>item;assert possible;r=item+(possible&-possible).bit_length()-1;target=(bins[r]&-bins[r]).bit_length()-1
        assert tr['assignment'][t]==target,(d['instance_id'],p,t,'argmax');before=rem[target];after=before-item;assert 0<=after<100
        assert tr['pre_remaining'][t]==before and tr['post_remaining'][t]==after and tr['feasible_counts'][t]==sum(count[item:]);used+=before==100;assert tr['used_bins_after'][t]==used
        if eoh:
            g=before-item;ex=math.exp(g);sc=before/((ex+.7)*ex)+(1-g/before)*math.sqrt(g)+(.8 if g>3*item else .3)
        else:sc=-(before-item)
        err=abs(sc-tr['chosen_score'][t]);score_error=max(score_error,err);assert math.isclose(sc,tr['chosen_score'][t],rel_tol=1e-12,abs_tol=1e-13),(p,t,sc,tr['chosen_score'][t])
        bit=1<<target;bins[before]^=bit;bins[after]|=bit;count[before]-=1;count[after]+=1
        if count[before]==0:present&=~(1<<before)
        present|=1<<after;rem[target]=after
        if t==499:prefix=rem.copy()
    assert rem==tr['remaining'] and used==row['used_bins']==sum(v<100 for v in rem);assert sum(100-v for v in rem)==sum(items);assert used>=(sum(items)+99)//100
    assert digest(items)==row['items_sha256'] and digest(prefix)==row['prefix_remaining_sha256'] and row['selector_consumed_count']==500
    f=features(items,prefix);eq(f,row['prefix_features']);progress['packing_argmax_chosen_score_steps']+=n;progress['policy_runs']+=1;progress['monitor_events']+=len(ev)
    return prefix,tr,f

def aggregate(rr):
    out={'streams':len(rr),'paired_blocks':len({r['block_id'] for r in rr}),'mean_bins':{p:statistics.mean(r[p] for r in rr) for p in POL}}
    for key,a,b in [('fallback_minus_selector','DRIFT_FALLBACK','SELECTOR'),('fallback_minus_sbs','DRIFT_FALLBACK','BF_then_EoH'),('selector_minus_sbs','SELECTOR','BF_then_EoH')]:
        delta=[r[a]-r[b] for r in rr];out[key]={'mean':statistics.mean(delta),'total':sum(delta),'wins_ties_losses':[sum(d<0 for d in delta),sum(d==0 for d in delta),sum(d>0 for d in delta)],'worst_harm':max(delta),'best_improvement':min(delta)}
    out.update({'alarms':sum(r['first_alarm']is not None for r in rr),'actual_switches':sum(r['actual_switch_item']is not None for r in rr),'prechange_false_alarms':sum(r['prechange_false_alarm'] for r in rr),'stationary_false_alarms':sum(r['stationary_false_alarm'] for r in rr),'missed_first_alarm_after_change':sum(r['kind']=='shift' and (r['first_alarm']is None or r['first_alarm']<=r['change_point']) for r in rr),'first_alarm_postchange_delays':[r['first_alarm_delay_items'] for r in rr if r['first_alarm_delay_items']is not None],'fallback_mean_signed_gap_to_fixed_branch_oracle':statistics.mean(r['fallback_minus_fixed_branch_oracle'] for r in rr)})
    return out

def csvcheck(name,expected):
    PINS[name]=sha(R/name)
    with (R/name).open() as f:rows=list(csv.DictReader(f))
    assert len(rows)==len(expected)
    for got,exp in zip(rows,expected):
        assert got.keys()==exp.keys()
        for k,v in exp.items():
            if v is None:assert got[k]==''
            elif isinstance(v,str):assert got[k]==v
            else:eq(ast.literal_eval(got[k]),v,name+'/'+k)
    progress['csv_rows_checked']+=len(rows)

def main():
    global nn_error
    p=load('PROTOCOL.json');freeze=load('FREEZE.json');cal=load('CALIBRATION.json')
    for name,h in [('FREEZE.json','b81c4ee040a50a210893b91e2c440872c13d9b0694a6c1c1f20c93b514f39282'),('PROTOCOL.json','50201c34fdcd88caad4e5ebb427e65e1b1e9c540812d825d37e0c5e21059bc06'),('CALIBRATION.json','ae6927604c11c572bd076ff988614209eee93b3559e2a33c1fa7ca5fd3e7f047')]:assert sha(R/name)==h==sha(H/'pre_run'/name)
    for name,h in freeze['files'].items():assert sha(R/name)==h,name;PINS[name]=h
    design=load('DESIGN_FREEZE.json');code=load('CODE_SEED_FREEZE.json');begin=load('POLICIES_STARTED.json');done=load('RUN_COMPLETE.json');resources=load('resources/PROCESS_RESOURCE.json')
    assert design['before_calibration_computation'] and design['before_test_input_generation'];assert design['created_utc']<=cal['created_utc']<=p['created_utc']<=code['created_utc']<=freeze['created_utc']<=begin['started_utc']<=done['finished_utc']
    for name,h in design['files'].items():assert sha(R/name)==h
    assert begin['freeze_sha256']==sha(R/'FREEZE.json');assert begin['release_sha256']==sha(R/'EXECUTION_RELEASE.json')
    for rec in load('evidence/SOURCE_SNAPSHOT.json')['files']:
        assert sha(rec['source'])==rec['sha256']==sha(R/rec['local']);EXT[rec['source']]=rec['sha256']
    model=load('MODEL.json');assert sha(R/'MODEL.json')=='98991f0908867ff7de995b1e252d503c0180a5e74c67ac03d9444765fdede7ab';assert model['k']==5 and model['sbs_index']==1 and len(model['x'])==144
    assert p['policies']==POL and p['guard_rule']==cal['rule']==load('CALIBRATION_RULE.json') and p['replicate_seed_roots']==[2026100612401,2026100612402,2026100612403]
    # Validate all eligibility decisions first, then all eligible windows and quantile.
    eligible=[];excluded=[]
    for path in sorted((R/'calibration_inputs').glob('train*.json')):
        d=load(str(path.relative_to(R)));assert d['split']=='train' and len(d['items'])==5000
        if d['order']=='random':
            vals=[{'observed_count':t,'ks_count':ks(d['items'][:500],d['items'][t-500:t])} for t in TIMES]
            eligible.append({'instance_id':d['instance_id'],'group_id':d['group_id'],'family':d['family'],'input_file':str(path.relative_to(R)),'input_sha256':sha(path),'events':vals,'max_ks_count':max(v['ks_count'] for v in vals)})
        else:assert d['order']in['ascending','descending'];excluded.append({'instance_id':d['instance_id'],'order':d['order'],'reason':'excluded_by_predeclared_order_metadata'})
    assert eligible==cal['rows'] and excluded==cal['excluded'];assert len(eligible)==cal['eligible_count']==48 and len(excluded)==cal['excluded_count']==96 and len({r['group_id'] for r in eligible})==48
    threshold=sorted(r['max_ks_count'] for r in eligible)[math.ceil(47*.95)];assert threshold==48==cal['threshold_count']==p['threshold_count'];assert threshold/500==cal['threshold_D']==p['threshold_D'];assert sum(r['max_ks_count']>threshold for r in eligible)==cal['calibration_streams_strictly_exceeding']==2
    progress.update(training_metadata_eligibility_checked=144,training_calibration_streams=48,calibration_events=432)
    index=load('INPUT_INDEX.json');metas=index['instances'];assert len(metas)==54 and len(index['base_draws'])==18;bm=[];expected=[];bases={};seeds=set()
    for pi,pair in enumerate(p['pairs']):
        for ri,root in enumerate(p['replicate_seed_roots']):
            block=f"{pair['id']}_r{ri}"
            for ei,end in enumerate(['A','B']):
                seed=root+1000*pi+100*ei;family=pair['a' if end=='A' else 'b'];items,order,clips=make(family,seed);bid=block+'_'+end;meta={'base_id':bid,'block_id':block,'endpoint':end,'family':family,'replicate':ri,'value_seed':seed,'permutation_seed':seed+1000000,**clips};saved=load('inputs/base__'+bid+'.json');assert saved=={**meta,'items':items,'source_position':order};assert sorted(order)==list(range(5000));bases[bid]=items;bm.append(meta);seeds.update([seed,seed+1000000]);progress['base_draws_reconstructed']+=1
            for src,dst,t,kind in [('A','A',None,'stationary'),('B','B',None,'stationary'),('A','B',500,'shift'),('A','B',2500,'shift'),('B','A',500,'shift'),('B','A',2500,'shift')]:
                left=bases[block+'_'+src];right=bases[block+'_'+dst];items=left if t is None else left[:t]+right[t:];label='stationary_'+src if kind=='stationary' else f'{src}_to_{dst}_t{t}'
                m={'instance_id':block+'__'+label,'block_id':block,'pair_id':pair['id'],'replicate':ri,'kind':kind,'direction':src+'_to_'+dst,'change_point':t,'origin_endpoint':src,'destination_endpoint':dst,'origin_family':pair['a' if src=='A' else 'b'],'destination_family':pair['a' if dst=='A' else 'b'],'prefix_group':block+'_'+src,'items_sha256':digest(items),'prefix_sha256':digest(items[:500]),'total_volume':sum(items)}
                assert load('inputs/'+m['instance_id']+'.json')=={**m,'n':5000,'capacity':100,'items':items};expected.append(m);progress['inputs_reconstructed']+=1
    assert bm==index['base_draws'] and expected==metas and len(seeds)==36
    old=load('evidence/prior_shift_input_index.json');assert not seeds & {r[k] for r in old['base_draws'] for k in ['value_seed','permutation_seed']};assert not {m['items_sha256'] for m in metas}&{m['items_sha256'] for m in old['instances']}
    ranking=ranks();group=collections.defaultdict(list);out=[];allrows=[];evout=[]
    for m in metas:
        d=read(R/'inputs'/f"{m['instance_id']}.json");rows={};states={};traces={};fs={}
        for policy in POL:
            row=load('raw/'+m['instance_id']+'__'+policy+'.json');assert row['instance_id']==m['instance_id'] and row['policy']==policy
            states[policy],traces[policy],fs[policy]=replay(d,row,ranking,threshold);rows[policy]=row;allrows.append(row)
            if policy in ['SELECTOR','DRIFT_FALLBACK']:nn_error=max(nn_error,decision(model,fs[policy],row));progress['selector_decisions']+=1
            else:assert row['branch']==policy and row['decision'] is None
        assert states['BF']==states['BF_then_EoH']==states['SELECTOR']==states['DRIFT_FALLBACK']
        assert traces['SELECTOR']==traces[rows['SELECTOR']['branch']];assert rows['SELECTOR']['decision']==rows['DRIFT_FALLBACK']['decision']
        f=rows['DRIFT_FALLBACK'];limit=(f['actual_switch_item_1based']-1) if f['actual_switch_item_1based'] else 5000
        for field in traces['SELECTOR']:
            if field!='remaining':assert traces['SELECTOR'][field][:limit]==traces['DRIFT_FALLBACK'][field][:limit]
        group[m['prefix_group']].append({'prefix':d['items'][:500],'state':states['BF'],'decision':rows['SELECTOR']['decision']})
        b={pol:rows[pol]['used_bins'] for pol in POL};oracle=min(b['BF'],b['BF_then_EoH']);alarm=f['first_alarm_observed_count'];cp=m['change_point'];post=[e['observed_count'] for e in f['drift_events'] if cp is not None and e['observed_count']>cp and e['strict_exceedance']]
        out.append({**m,**b,'selected_branch':f['branch'],'fixed_branch_oracle':oracle,'selector_regret_fixed_branch':b['SELECTOR']-oracle,'fallback_minus_fixed_branch_oracle':b['DRIFT_FALLBACK']-oracle,'fallback_minus_selector':b['DRIFT_FALLBACK']-b['SELECTOR'],'fallback_minus_sbs':b['DRIFT_FALLBACK']-b['BF_then_EoH'],'selector_minus_sbs':b['SELECTOR']-b['BF_then_EoH'],'first_alarm':alarm,'actual_switch_item':f['actual_switch_item_1based'],'prechange_false_alarm':bool(cp is not None and alarm is not None and alarm<=cp),'stationary_false_alarm':bool(cp is None and alarm is not None),'first_alarm_delay_items':alarm-cp if cp is not None and alarm is not None and alarm>cp else None,'first_postchange_exceedance':min(post) if post else None,'first_postchange_exceedance_delay':min(post)-cp if post else None,'alarm_but_no_policy_change':alarm is not None and f['actual_switch_item_1based'] is None,'monitor_cpu_seconds':f['cpu_monitor_seconds']})
        evout += [{'instance_id':m['instance_id'],**e} for e in f['drift_events']]
        progress['streams_checked']+=1;print(json.dumps({'instance':m['instance_id'],'coverage':dict(progress)}),flush=True)
    assert len(group)==18 and all(len(v)==3 and v[0]==v[1]==v[2] for v in group.values());progress['same_prefix_groups_verified']=18
    assert len(list((R/'raw').glob('*.json')))==len(list((R/'raw').glob('*.npz')))==270
    eq(out,load('analysis/PER_STREAM.json'));eq(evout,load('analysis/ALL_GUARD_EVENTS.json'));summary=load('analysis/SUMMARY.json');shift=[r for r in out if r['kind']=='shift'];stat=[r for r in out if r['kind']=='stationary'];scells=[];ccells=[]
    for pair in p['pairs']:
        for direction in ['A_to_B','B_to_A']:
            for cp in [500,2500]:scells.append({'pair_id':pair['id'],'direction':direction,'change_point':cp,**aggregate([r for r in shift if r['pair_id']==pair['id'] and r['direction']==direction and r['change_point']==cp])})
        for end in ['A','B']:ccells.append({'pair_id':pair['id'],'endpoint':end,**aggregate([r for r in stat if r['pair_id']==pair['id'] and r['origin_endpoint']==end])})
    for key,val in [('shift_only',aggregate(shift)),('stationary_only',aggregate(stat)),('shift_cells',scells),('stationary_cells',ccells)]:eq(summary[key],val,key)
    for name,val in [('per_stream.csv',out),('guard_events.csv',evout),('shift_cells.csv',scells),('stationary_cells.csv',ccells)]:csvcheck('analysis/'+name,val)
    assert summary['all_streams_included'] and summary['status']=='complete';assert done['status']=='complete' and done['full_runs']==270 and done['policy_steps']==done['validated_steps']==1350000 and done['guard_events']==486 and done['calibration_events']==432;assert done['api_calls']==done['external_paid_tools']==done['installations']==done['retries']==0;assert done['cpu_seconds']<=180 and resources['exit_code']==0
    check=load('CHECK.json');assert check['passed'];isolation=load('SOURCE_ISOLATION_CHECK.json');assert isolation['passed'] and not isolation['model_fit_called'] and not isolation['prior_shift_losses_opened'];assert not (R/'RUN_FAILURE.json').exists()
    for name,h in PINS.items():assert sha(R/name)==h,name
    for path,h in EXT.items():assert sha(path)==h,path
    result={'status':'PASS_FULL_NUMERICAL_EVIDENCE','completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'coverage':dict(progress),'threshold_count':threshold,'threshold_D':threshold/500,'calibration_domain':'48 random-arrival training streams selected by metadata from144;96 sorted streams excluded prospectively','threshold_strictly_exceeding_training_streams':2,'max_chosen_score_abs_error':score_error,'max_selector_distance_abs_error':nn_error,'new_executions':270,'historical_runs_counted_as_new':0,'model_byte_identical':True,'first_alarm_action_next_item':True,'static_history_only_guard_review':True,'fixed_branch_oracle_not_adaptive_oracle':True,'paired_blocks':9,'summary':summary,'cpu_seconds':time.process_time()-start,'author_resource':resources,'limits':['Finite correlated54-stream synthetic diagnostic,9 paired source blocks; no general false-alarm guarantee, blind-test, significance or general OOD robustness claim.','Static code and complete saved-evidence validation, not OS syscall/security attestation.','Prospective rule excludes sorted training order; calibration applicability must be disclosed.','Adaptive signed comparison to two fixed branches is not adaptive regret.','Author final report/manifest require later metadata review.']}
    (H/'CHECKS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');(H/'SOURCE_PINS.json').write_text(json.dumps({'files':PINS,'external':EXT,'prior_independent_helper_sha256':sha(H/'prior_independent_helper.py')},indent=2)+'\n');(H/'INDEPENDENT_PER_STREAM.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False))
try:main()
except BaseException as ex:
    (H/'FAILURE.json').write_text(json.dumps({'error':repr(ex),'traceback':traceback.format_exc(),'partial_coverage':dict(progress),'cpu_seconds':time.process_time()-start},indent=2)+'\n');raise
