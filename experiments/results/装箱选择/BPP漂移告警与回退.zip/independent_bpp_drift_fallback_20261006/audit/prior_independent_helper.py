"""Saved-trajectory auditor; no producer imports and no new policy experiment.
Score-ranking, capacity-class bitset replay, and feature arithmetic adapted from:
../new_family_independent_audit_20261006/audit_new_families.py
SHA256 7b2e9d279e83b1737596e6b53ec1eb1389cc6c4e4763f7f8380d6debca749fd6.
The new wrapper adds strict trajectory schema checks and dependency accounting.
"""
import pathlib,json,hashlib,math,statistics
import numpy as np
canon=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
digest=lambda x:hashlib.sha256(canon(x).encode()).hexdigest()
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(pathlib.Path(p).read_text())
FIELDS=['assignment','pre_remaining','post_remaining','feasible_counts','used_bins_after','remaining']
POLICIES=['BF','BF_then_EoH','published_EoH','SELECTOR']

def ranks():
    result={}
    for item in range(1,101):
        scores={}
        for remaining in range(item,101):
            gap=remaining-item;exp=math.exp(gap)
            score=remaining/((exp+0.7)*exp)+(1-gap/remaining)*math.sqrt(gap)+(0.8 if gap>3*item else 0.3)
            scores.setdefault(score,[]).append(remaining)
        result[item]=[(sum(1<<r for r in group),group) for score,group in sorted(scores.items(),reverse=True)]
    return result

def features(items,state):
    p=items[:500];used=[v for v in state if v<100];ordered=sorted(p)
    def quant(q):
        t=499*q;i=int(t);frac=t-i
        return (ordered[i]*(1-frac)+ordered[min(i+1,499)]*frac)/100
    return [sum((x-1)//10==k for x in p)/500 for k in range(10)]+[statistics.mean(p)/100,statistics.pstdev(p)/100]+[quant(q) for q in [.1,.5,.9]]+[sum(b>a for a,b in zip(p,p[1:]))/499,sum(b<a for a,b in zip(p,p[1:]))/499,(statistics.mean(p[-100:])-statistics.mean(p[:100]))/100,len(used)/500]+[sum(x//10==k for x in used)/len(used) for k in range(10)]+[statistics.mean(used)/100,statistics.pstdev(used)/100]

def replay(root,data,row,ranking):
    policy=row['policy'];items=data['items'];n=len(items);assert n==5000
    path=root/row['trajectory_file'];assert sha(path)==row['trajectory_sha256']
    with np.load(path,allow_pickle=False) as z:
        assert sorted(z.files)==sorted(FIELDS)
        assert all(z[key].shape==(n,) and np.issubdtype(z[key].dtype,np.integer) for key in FIELDS)
        arrays={k:z[k].tolist() for k in FIELDS}
    assert row['status']=='complete' and row['error'] is None and row['steps']==n
    assert row['instance_id']==data['instance_id'] and policy in POLICIES
    assert row['items_sha256']==digest(items) and row['selector_consumed_count']==500
    expected_branch={'BF':'BF','BF_then_EoH':'BF_then_EoH','published_EoH':'published_EoH'}
    if policy!='SELECTOR':assert row['branch']==expected_branch[policy] and row['decision'] is None
    else:assert row['branch'] in ('BF','BF_then_EoH')
    remaining=[100]*n;bins=[0]*101;bins[100]=(1<<n)-1;count=[0]*101;count[100]=n;present=1<<100;used=0;prefix=None
    for step,item in enumerate(items):
        target=arrays['assignment'][step];assert type(target)==int and 0<=target<n
        is_eoh=policy=='published_EoH' or (step>=500 and row['branch']=='BF_then_EoH')
        if is_eoh:
            eligible=None
            for mask,residuals in ranking[item]:
                if present&mask:eligible=residuals;break
            assert eligible is not None
            candidate=min((bins[r]&-bins[r]).bit_length()-1 for r in eligible if bins[r])
        else:
            feasible=present>>item;assert feasible
            r=item+(feasible&-feasible).bit_length()-1
            candidate=(bins[r]&-bins[r]).bit_length()-1
        assert target==candidate,(data['instance_id'],policy,step,target,candidate)
        before=remaining[target];after=before-item;assert before>=item and 0<=after<100
        assert arrays['pre_remaining'][step]==before and arrays['post_remaining'][step]==after
        assert arrays['feasible_counts'][step]==sum(count[item:])
        used+=int(before==100);assert arrays['used_bins_after'][step]==used
        bit=1<<target;bins[before]^=bit;bins[after]|=bit;count[before]-=1;count[after]+=1
        if not count[before]:present&=~(1<<before)
        present|=1<<after;remaining[target]=after
        if step==499:prefix=remaining.copy()
    assert remaining==arrays['remaining'] and used==row['used_bins']==sum(r<100 for r in remaining)
    assert sum(100-r for r in remaining)==sum(items) and used>=(sum(items)+99)//100
    assert digest(prefix)==row['prefix_remaining_sha256']
    f=features(items,prefix);assert np.allclose(f,row['prefix_features'],rtol=1e-12,atol=1e-13)
    return prefix,arrays,f

def decision(model,f,row):
    z=[(x-mu)/scale for x,mu,scale in zip(f,model['mean'],model['scale'])]
    d=[math.fsum((a-b)**2 for a,b in zip(x,z)) for x in model['x']]
    neighbors=sorted(range(144),key=lambda i:(d[i],i))[:5]
    costs=[sum(model['y'][i][j] for i in neighbors)/5 for j in [0,1]]
    choice=model['sbs_index'] if costs[0]==costs[1] else int(costs[1]<costs[0])
    dec=row['decision'];assert neighbors==dec['neighbors'] and costs==dec['predicted_final_bins']
    assert choice==dec['selected_index'] and ['BF','BF_then_EoH'][choice]==row['branch']
    assert np.allclose(f,dec['features'],rtol=1e-12,atol=1e-13)
    error=max(abs(d[i]-observed) for i,observed in zip(neighbors,dec['squared_distances']))
    assert error<1e-9
    return error

def summarize(rows):
    delta=[r['selector_minus_sbs'] for r in rows];regret=[r['selector_regret'] for r in rows];head=[r['sbs_regret'] for r in rows];den=sum(head)
    return {'streams':len(rows),'mean_bins':{p:statistics.mean(r[p] for r in rows) for p in POLICIES},'mean_branch_oracle_bins':statistics.mean(r['branch_oracle'] for r in rows),'mean_selector_minus_sbs':statistics.mean(delta),'total_selector_minus_sbs':sum(delta),'wins_ties_losses':[sum(v<0 for v in delta),sum(v==0 for v in delta),sum(v>0 for v in delta)],'worst_selector_minus_sbs':max(delta),'mean_selector_regret':statistics.mean(regret),'worst_selector_regret':max(regret),'mean_sbs_regret':statistics.mean(head),'headroom_recovered_fraction':-sum(delta)/den if den else None,'selected_branch_counts':{p:sum(r['selected_branch']==p for r in rows) for p in ['BF','BF_then_EoH']}}
