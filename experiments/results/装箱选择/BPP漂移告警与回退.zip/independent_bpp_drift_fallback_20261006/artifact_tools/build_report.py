import pathlib,json,time,collections,csv
H=pathlib.Path(__file__).resolve().parents[1]
a=json.loads((H/'analysis/SUMMARY.json').read_text());rows=json.loads((H/'analysis/PER_STREAM.json').read_text());cal=json.loads((H/'CALIBRATION.json').read_text());proc=json.loads((H/'resources/PROCESS_RESOURCE.json').read_text());done=json.loads((H/'RUN_COMPLETE.json').read_text());p=json.loads((H/'PROTOCOL.json').read_text())
shift=a['shift_only'];station=a['stationary_only'];lines=[]
def add(s=''):lines.append(s)
add('BPP冻结前缀选择器的漂移告警与永久回退验证')
add('2026年10月6日  新种子合成诊断  完整结果与局限')
add()
add('结论')
add('简单KS告警加EoH永久回退，在这组新转换流上减少了原前缀选择器的平均损失，但收益集中在uniform→Weibull方向，不能据此替换固定SBS或声称普遍鲁棒。36条转换流上，回退比原selector平均少6.3889箱；相对固定SBS仍平均多1.1667箱。最坏相对SBS损失在同一新种子面板内从69箱降至12箱。与此同时，8/36条转换流比原selector更差，最坏多8箱。')
add('uniform→Weibull的6流合计少264箱；normal↔bimodal的12流合计多34箱；另外18流不变。全部结论保留负结果，未重跑、改阈值或删除单元。独立外部审计状态见交付时的审计附件；本报告中的作者独立实现复算不替代外部独审。')
add()
add('实验来源与冻结')
add('本实验针对先前已发现的后续分布转换风险提出，因此属于事后提出的新防护设计，不是真实外部盲测。原BF、published EoH得分函数、31维前缀特征、k=5选择器和MODEL逐字节保留；未调用fit或重新训练。统一执行器仅新增监测策略与逐步日志，四个原策略的行为定义不变。')
add('原模型SHA256为'+p['model_sha256']+'。设计、校准规则和源代码先冻结；然后只从原训练输入校准阈值；再冻结阈值和新种子；最后生成54条验证流并冻结输入后执行。PROTOCOL.json、DESIGN_FREEZE.json、CODE_SEED_FREEZE.json、FREEZE.json及POLICIES_STARTED.json记录顺序和文件哈希。')
add('原训练集144流包括48随机、48升序、48降序。按事前order元数据只取48随机流，避免把人为排序趋势当平稳噪声。每流比较首500与t=1000,1500,…,5000最近500件的经验KS距离，取该流9次距离的最大值，再取48个最大值的95% higher经验分位数。得到阈值48/500=0.096；严格大于阈值才告警，内部用整数计数比较。校准集2/48流越阈，仅是训练内描述值，并非5%假警保证。')
add('只用原训练输入校准；未读取原确认/风险输入或loss，也未用之前54流或本次验证loss调参。原144训练输入被复制用于可审计性，但实际校准仅48随机流，不能称为144全体校准。原模型自身保留既有训练标签用于原选择器决策，与新增KS校准相互区分。')
add()
add('在线防护定义')
add('每流容量100、5000件。前500件严格BF装箱，随后原冻结选择器只选择一次。新增DRIFT_FALLBACK保留该初始决定；每装完500件检查一次，首个有效比较在已装完第1000件后。KS只接收首500与最近500已到达尺寸，不接收家族、种子、转换点、未来数据或任何策略最终箱数。')
add('首次告警在已处理第t件后锁存，从第t+1件开始永久使用原EoH得分函数，在当前已有箱状态继续装箱，不回滚已处理物品。初始已选EoH时告警不改变动作。t=5000仍记录监测，但没有下一件可切换。记录全部486个验证监测点，包括判定值、阈值、历史读取范围和锁存状态。')
add('两样本KS D是对整数x=1..100取|F首500(x)-F最近500(x)|最大值；两样本同为500件。监测开销包括所有逐件observe更新与KS调用；未运行EoH/BF影子装箱、未看未来loss后再决定是否回退。检测到分布不同，并不能证明EoH在新的分布上更优。')
add()
add('配对面板与计数')
add('沿用三个配对：small Beta(2,5)↔large Beta(5,2)，normal(50,15)↔双峰20–30/70–80，Weibull(3,45)↔uniform1–100。前述名称与参数严格按原生成器。整数化使用numpy ties-to-even rint，截断至1–100，并以独立的固定种子排列到达顺序。')
add('新种子根为'+', '.join(map(str,p['replicate_seed_roots']))+'；每配对每重复生成A/B两个基础序列。转换流为A[:t]+B[t:]及逆向，t取500或2500；另外保留两个完整平稳对照。共9配对来源块、18基础抽样、36转换流、18平稳流。每流5策略，270完整实跑、1350000装箱步；没有把同一轨迹缓存复用成另一策略的实跑。')
add('相同来源前缀的平稳流和两个转换流共享首500状态，18组同前缀不变性均通过。54条流在各配对块内相关，不能当54个独立观测；以下均为描述性有限面板均值，不提供显著性、置信区间或外推保证。新18基础种子与旧面板不重合，新54完整流哈希与旧54不重合。')
add()
add('主要结果')
for label,s in [('转换36流',shift),('平稳18流',station)]:
 add(label)
 add('  平均箱数：'+ '；'.join(f'{k} {v:.4f}' for k,v in s['mean_bins'].items()))
 for key,title in [('fallback_minus_selector','回退减selector'),('fallback_minus_sbs','回退减固定SBS'),('selector_minus_sbs','selector减固定SBS')]:
  r=s[key];add(f"  {title}：均值{r['mean']:+.4f}，合计{r['total']:+d}，胜/平/负{r['wins_ties_losses']}，最大差值{r['worst_harm']:+d}。负值表示前者更省箱。")
add()
add('所有转换单元')
add('每单元3流；顺序为 配对 方向 转换点 回退减selector均值 回退减SBS均值 胜平负相对selector')
for r in a['shift_cells']:add(f"  {r['pair_id']} {r['direction']} t={r['change_point']} {r['fallback_minus_selector']['mean']:+.4f} {r['fallback_minus_sbs']['mean']:+.4f} {r['fallback_minus_selector']['wins_ties_losses']}")
add('A/B对应：P1 A小Beta/B大Beta；P2 A normal/B bimodal；P3 A Weibull/B uniform。')
add()
add('局部改善与完整负例')
add('uniform→Weibull早变t=500：三流平均改善59箱，回退仍比SBS多4箱。晚变t=2500：平均改善29箱，仍比SBS多11箱。晚变前已经发生的BF状态偏离不能被回退消除；这是结果支持的局限，不能把回退视为从第501件就采用SBS。')
for r in rows:
 if r['fallback_minus_selector']>0:add(f"  负例 {r['instance_id']}：回退较selector多{r['fallback_minus_selector']}箱，较SBS差{r['fallback_minus_sbs']:+d}箱；初始BF，告警后才转EoH。")
add('上述8个负例全部来自normal↔bimodal。该配对12流合计增加34箱，1胜3平8负。KS能发现尺寸分布变化，但回退方向并非由新分布的算法优劣决定。这个固定回退规则只能缓解特定风险，不能解决所有方向的算法选择问题。')
add()
add('告警 迟报与假警')
add('36/36转换流均在转换后500件首次告警，无转换前告警。对应t=500在已装完第1000件后告警，t=2500在已装完第3000件后告警；首次可能改变的物品分别是1001与3001。检测延迟500件，不能倒算为转换发生即刻切换。')
add('转换流实际BF→EoH切换16次，其他20流初始已选EoH，虽告警但不改变动作。平稳18流中2流告警，即本次面板11.11%；并未出现0假警。两次都发生在3500件后，且初始已是EoH，因此没有额外切换，最终箱数与原selector一致。')
for r in rows:
 if r['stationary_false_alarm']:add('  平稳假警 '+r['instance_id']+'；已观测'+str(r['first_alarm'])+'件，初始'+r['selected_branch']+'。')
add('平稳对照没有出现初始BF后的误切，不能据此证明误报在其他流上不会导致装箱损失。阈值只按随机流校准，对排序或其他相关到达过程不作假警控制承诺。')
add()
add('固定分支oracle的边界')
add('sameBF500固定分支oracle仅为min(全程BF箱数, BF500后EoH箱数)，两者共享首500 BF状态。它只能在500后一次选定固定分支，不包含告警时间上的额外自适应切换，不是自适应oracle。')
add('原selector减该固定oracle可称固定分支regret；新增回退减该oracle仅是有正有负的signed gap，不据此计算自适应regret或声称恢复了全部可用headroom。published_EoH从第一件开始使用EoH，起始轨迹不同，也不进入sameBF500分支oracle。')
add()
add('核验与资源')
add('作者另外编写的标量EoH得分排序与整数堆重放器已全量复算135万步：容量、体积守恒、残量、可行箱数量、箱数、最优得分/首索引并列规则、逐步算法标志和chosen_score全部通过。108次selector决定与31维特征重算；486个监测点与432个校准窗口用另一种经验CDF实现重算；阈值顺序统计量也独立计算。')
add('每个raw/*.npz保存逐步assignment、pre_remaining、post_remaining、feasible_counts、used_bins_after、algorithm_eoh、chosen_score和最终remaining；结合输入可完整重建每一步的全箱状态。对应JSON保存初始分支、决策邻居、全部告警、实际切换位置及分项CPU。')
add(f"数值进程外层实测CPU {proc['cpu_total_seconds']:.6f}秒，墙时{proc['wall_seconds']:.6f}秒，最大RSS {proc['max_rss_kb']} KB；硬上限180 CPU秒。墙时包含等待冻结通知与放行，不能与纯策略运行耗时混用。")
add(f"该进程内部准备/校准{done['preparation_calibration_cpu_seconds']:.6f} CPU秒，全量核验{done['validation_cpu_seconds']:.6f}秒，分析{done['analysis_cpu_seconds']:.6f}秒；54条监测策略合计监测CPU {a['cost']['total_cpu_monitor_seconds']:.6f}秒（包含逐件更新，单流均值{a['cost']['total_cpu_monitor_seconds']/54:.6f}秒）。分项计时存在仪器开销，不能作为稳定部署性能估计。")
add('0模型/API调用，0付费外部工具，0依赖安装，0策略重试。作者代码编写、源文件字节复制、报告/manifest整理与外部审计不包含在这条数值进程CPU内；成本表明确区分范围。原153个源/训练/索引文件前后哈希均一致，未改旧目录或主线。')
add()
add('后续判断')
add('可以把本次结果视为“固定KS守卫能削减特定后续变化造成的严重损失”的有限支持。当前固定EoH回退并未总体胜过原SBS，对normal↔bimodal还会造成反向损失，因此不建议凭本结果替换原默认策略。任何新的回退条件或策略重选都应另开设计、训练内校准、新种子验证，不能沿用本面板调参后仍称验证。')
add()
add('文件导览')
add('PROTOCOL.json与CALIBRATION_RULE.json：结果前冻结的精确规则。CALIBRATION.json：48随机训练流全部432个KS值与96个元数据排除记录。inputs/与INPUT_INDEX.json：全部基础抽样及54测试流。raw/：270完整轨迹及JSON。analysis/：逐流、12转换单元、6平稳单元和全部告警表。CHECK.json：作者核验。COST_LEDGER.json与resources/：资源。MANIFEST.json：最终文件哈希。')
(H/'REPORT_ZH.txt').write_text('\n'.join(lines)+'\n')
protocol_text='''BPP漂移回退验证协议摘要

本文件辅助阅读，精確机器规则以结果前冻结的PROTOCOL.json为准。

一、固定部件
原MODEL、k=5选择器和31维特征不变；原BF、BF500后EoH、从首件EoH、原SELECTOR均保留。新增DRIFT_FALLBACK前500件BF，原选择器只决定一次；此后不重拟合。

二、仅训练内校准
144训练流中按order=random选择48流，排除48升序和48降序，不读取loss选样。对各流首500与t=1000,1500,...,5000最近500做KS，共432窗口；每流取最大KS，再取48个最大值的95% higher分位数。整数阈值48，对应D=0.096。新校准属于守卫设计，不冒充原选择器训练。

三、合法在线动作
每到一件先用当前策略装箱，再把该尺寸交给guard。每500件比较一次，首次t=1000；KS整数计数严格>48告警。首次告警永久锁存，t+1起使用原EoH得分，在已有箱状态继续；无回滚、无未来信息、无影子策略loss。5000时告警只能记录，无后续动作。原本EoH的流告警后不改动作。

四、新验证
三个原配对双向，转换在500和2500，加各端平稳对照。新根种子2026100612401、2026100612402、2026100612403，每配对/端点固定偏移；每块6流，共9块54流，5策略270run、135万步。先冻结阈值，再生成/冻结新输入，之后执行。54流有共享来源相关性。

五、指标
主要为转换36流回退减原selector与回退减固定训练SBS；18平稳流另列。全12转换单元、全6平稳单元、54逐流结果、486监测事件保留。正差值更差，负差值更好。记录迟报、假警、实际切换。sameBF500两固定分支oracle不可当自适应oracle；回退对它仅报signed gap。

六、预算与核验
一条单线程数值进程175秒软/180秒硬CPU、900秒墙时上限；0新依赖、0API、0付费外部工具、0策略重试。包括训练校准、输入生成、270实跑、完整作者标量重放及分析。外部独审另计。原目录只读，改动仅新目录。不能称普遍鲁棒、统计显著或真实盲测。
'''
(H/'PROTOCOL_ZH.txt').write_text(protocol_text)
ledger={'created_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'numeric_process':proc,'numeric_stages':done,'run_component_sums':a['cost'],'counts':{'actual_policy_runs':270,'policy_steps':1350000,'guard_observations':54*5000,'guard_ks_checks':486,'calibration_streams':48,'calibration_ks_checks':432},'freezes':{'design':'DESIGN_FREEZE.json','calibration':'CALIBRATION.json','test_input_and_code':'FREEZE.json'},'monetary':{'model_api_calls':0,'paid_external_tool_calls':0,'external_purchase_or_api_charges':0,'currency':'USD','local_compute_money_not_estimated':True},'source_copy_and_authoring':'Not included in numerical CPU; byte-copy/setup and code authoring not separately instrumented. No numeric result work outside bounded child except independent report summaries.','external_audit':'Measured separately by auditor; not included or double-counted in author numeric budget.','report_and_package':'Separate measured resources files are added when completed; not part of numeric CPU hard limit.'}
(H/'COST_LEDGER.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n')
(H/'README.txt').write_text('BPP漂移告警与永久回退验证\n\n先读REPORT_ZH.txt。机器协议、原始输入、270条完整轨迹、校准432窗口和验证486监测点均在此目录。\n原目录只读；本目录数值过程已完成，无策略重跑。\n完整实验不能在此目录重新启动：所有输出用独占创建，避免覆盖。若获授权复现，应复制代码/原始基线与训练输入到新目录，重新记录协议与资源；不得覆盖本次冻结证据。\n外部审计附件由独审员另行提供。报告中不把自适应结果与固定分支oracle的差称为自适应regret。\n')
print(json.dumps({'report_characters':len('\n'.join(lines)),'files':['REPORT_ZH.txt','PROTOCOL_ZH.txt','COST_LEDGER.json','README.txt']}))
