"""Freeze final bundle and create local ZIP, without upload or numerical rerun."""
import pathlib,json,hashlib,time,zipfile,resource
H=pathlib.Path(__file__).resolve().parents[1]
start=time.monotonic();cpu=time.process_time();sha=lambda b:hashlib.sha256(b).hexdigest();now=lambda:time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
for p,v in json.loads((H/'FREEZE.json').read_text())['files'].items():assert sha((H/p).read_bytes())==v,p
assert json.loads((H/'CHECK.json').read_text())['passed']
assert json.loads((H/'audit/CHECKS.json').read_text())['status']=='PASS_FULL_NUMERICAL_EVIDENCE'
manifest={'created_utc':now(),'scope':'All final files under experiment root except MANIFEST.json itself. Local delivery ZIP and hash/resource receipt are siblings, not included.','files':[]}
for p in sorted(H.rglob('*')):
 if p.is_file() and p.name!='MANIFEST.json':manifest['files'].append({'path':str(p.relative_to(H)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())})
manifest['file_count']=len(manifest['files']);manifest['total_bytes']=sum(x['bytes'] for x in manifest['files'])
with (H/'MANIFEST.json').open('x') as f:json.dump(manifest,f,ensure_ascii=False,indent=2);f.write('\n')
path=H.parent/(H.name+'_FULL_PACKAGE.zip')
with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(H.rglob('*')):
  if p.is_file():z.write(p,str(pathlib.Path(H.name)/p.relative_to(H)))
with zipfile.ZipFile(path) as z:
 assert z.testzip() is None
 assert len(z.namelist())==manifest['file_count']+1
 for r in manifest['files']:assert sha(z.read(H.name+'/'+r['path']))==r['sha256']
receipt={'created_utc':now(),'status':'local_package_complete_no_upload','experiment_dir':str(H),'zip_path':str(path),'zip_sha256':sha(path.read_bytes()),'zip_bytes':path.stat().st_size,'manifest_sha256':sha((H/'MANIFEST.json').read_bytes()),'manifest_files_excluding_self':manifest['file_count'],'zip_entries':manifest['file_count']+1,'zip_crc_and_all_file_hashes_verified':True,'package_cpu_seconds':time.process_time()-cpu,'package_wall_seconds':time.monotonic()-start,'package_max_rss_kb':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'numeric_policy_reruns':0,'upload_calls':0,'external_final_manifest_gate':'Auditor may write final gate receipt in external audit directory after this manifest is available; no archive file edits.'}
receiptpath=H.parent/(H.name+'_DELIVERY.json')
with receiptpath.open('x') as f:json.dump(receipt,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps(receipt,ensure_ascii=False))
