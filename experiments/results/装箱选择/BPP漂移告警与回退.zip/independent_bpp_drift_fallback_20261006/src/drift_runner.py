"""Online execution; selector and drift guard receive only observed items/state.
Every policy uses the exact original BF and EoH score functions. No fit is called.
"""
import pathlib, hashlib, json, time
import numpy as np
from selector import features, choose
from original_runner import load_controls, ArrivalStream
H=pathlib.Path(__file__).resolve().parents[1]
canon=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
sha=lambda x:hashlib.sha256(x).hexdigest()
def put(p,x):
    with p.open('x') as f:f.write(canon(x)+'\n');f.flush()

def ks_count_distance(first,recent):
    """Exactly 500 observations per sample; return integer numerator of KS D."""
    assert len(first)==len(recent)==500
    a=np.bincount(first,minlength=101);b=np.bincount(recent,minlength=101)
    return int(np.max(np.abs(np.cumsum(a)-np.cumsum(b))))

class DriftGuard:
    """No filesystem, labels, seed, full stream, packing costs or future access."""
    def __init__(self,threshold_count):
        self.threshold_count=int(threshold_count);self.first=[];self.recent=[];self.consumed=0;self.alarmed=False;self.events=[];self.first_alarm=None
    def observe(self,item):
        self.consumed+=1
        if self.consumed<=500:self.first.append(int(item))
        self.recent.append(int(item))
        if len(self.recent)>500:del self.recent[0]
        if self.consumed>=1000 and self.consumed%500==0:
            num=ks_count_distance(tuple(self.first),tuple(self.recent));exceed=num>self.threshold_count
            first=exceed and not self.alarmed
            if first:self.first_alarm=self.consumed;self.alarmed=True
            self.events.append({'observed_count':self.consumed,'reference_start_1based':1,'reference_end_1based':500,'recent_start_1based':self.consumed-499,'recent_end_1based':self.consumed,'ks_count':num,'ks_D':num/500,'threshold_count':self.threshold_count,'threshold_D':self.threshold_count/500,'strict_exceedance':exceed,'first_alarm':first,'latched_alarm':self.alarmed,'earliest_action_item_1based':self.consumed+1 if first else None,'history_only_arguments':True})

def execute(data,policy,controls,model,threshold_count):
    cpu=time.process_time();wall=time.monotonic();n=5000
    rem=np.full(n,100,dtype=np.int64);used=0;arrived=[];stream=ArrivalStream(data['items'])
    fields=('assignment','pre_remaining','post_remaining','feasible_counts','used_bins_after','algorithm_eoh')
    tr={k:np.empty(n,dtype=np.int32) for k in fields};tr['chosen_score']=np.empty(n,dtype=np.float64)
    steps=0;choice='BF' if policy=='BF' else ('BF_then_EoH' if policy=='BF_then_EoH' else 'published_EoH')
    decision=None;feature_cpu=0.;selection_cpu=0.;monitor_cpu=0.;prefix_hash=None;prefix_features=None;reads=None
    guard=DriftGuard(threshold_count) if policy=='DRIFT_FALLBACK' else None
    status='complete';error=None;actual_switch_item=None
    try:
        with np.errstate(all='raise'):
            for item in stream:
                # The guard has consumed exactly the previous `steps` items at this point.
                assert guard is None or guard.consumed==steps
                eoh=policy=='published_EoH' or (steps>=500 and (choice=='BF_then_EoH' or bool(guard and guard.alarmed)))
                algorithm='published_EoH' if eoh else 'BF'
                if guard and guard.alarmed and choice=='BF' and actual_switch_item is None:actual_switch_item=steps+1
                feasible=np.flatnonzero(rem>=item);bins=np.array(rem[feasible],dtype=np.int64,copy=True);bins.setflags(write=False)
                scores=controls[algorithm](np.int64(item),bins)
                assert isinstance(scores,np.ndarray) and scores.shape==bins.shape and np.all(np.isfinite(scores))
                arg=int(np.argmax(scores));target=int(feasible[arg]);before=int(rem[target]);rem[target]-=item
                used+=int(before==100);assert rem[target]>=0
                for key,value in zip(fields,(target,before,int(rem[target]),len(feasible),used,int(eoh))):tr[key][steps]=value
                tr['chosen_score'][steps]=float(scores[arg]);steps+=1
                if steps<=500:arrived.append(item)
                if steps==500:
                    prefix_hash=sha(canon(rem.tolist()).encode());reads=stream.consumed
                    if policy in ('SELECTOR','DRIFT_FALLBACK'):
                        t=time.process_time();choice,decision=choose(tuple(arrived),tuple(map(int,rem)),model);selection_cpu=time.process_time()-t;prefix_features=decision['features'];assert reads==500
                    else:
                        t=time.process_time();prefix_features=features(tuple(arrived),tuple(map(int,rem))).tolist();feature_cpu=time.process_time()-t
                if guard:
                    t=time.process_time();guard.observe(int(item));monitor_cpu+=time.process_time()-t
            assert steps==n
    except BaseException as e:status='failure';error=type(e).__name__+': '+str(e)
    loop_cpu=time.process_time()-cpu;loop_wall=time.monotonic()-wall;stem=f"{data['instance_id']}__{policy}";path=H/'raw'/f'{stem}.npz'
    with path.open('xb') as f:np.savez_compressed(f,**{k:v[:steps] for k,v in tr.items()},remaining=rem)
    row={'instance_id':data['instance_id'],'policy':policy,'status':status,'error':error,'steps':steps,'used_bins':used,'items_sha256':sha(canon(data['items']).encode()),'trajectory_file':str(path.relative_to(H)),'trajectory_sha256':sha(path.read_bytes()),'prefix_remaining_sha256':prefix_hash,'prefix_features':prefix_features,'selector_consumed_count':reads,'branch':choice,'decision':decision,'first_alarm_observed_count':guard.first_alarm if guard else None,'actual_switch_item_1based':actual_switch_item,'drift_events':guard.events if guard else [],'cpu_loop_seconds':loop_cpu,'cpu_policy_seconds':loop_cpu-selection_cpu-feature_cpu-monitor_cpu,'cpu_selector_seconds':selection_cpu,'cpu_monitor_seconds':monitor_cpu,'cpu_instrument_feature_seconds':feature_cpu,'wall_loop_seconds':loop_wall,'cpu_total_including_serialization_seconds':time.process_time()-cpu}
    put(H/'raw'/f'{stem}.json',row)
    if error:raise RuntimeError(error)
    return row
