"""Training-only drift calibration, then frozen new validation: no retries/tuning."""
import pathlib,json,time,sys,os,signal,resource,traceback,csv,hashlib,platform
import numpy as np
import prior_shift_utils as u
from drift_runner import execute,load_controls,ks_count_distance
from checker import replay,rankings,independent_ks_count
from selector import BRANCHES,FEATURE_NAMES
H=pathlib.Path(__file__).resolve().parents[1]
METHODS=['BF','BF_then_EoH','published_EoH','SELECTOR','DRIFT_FALLBACK'];SBS='BF_then_EoH';N=5000
SEEDS=[2026100612401,2026100612402,2026100612403];u.SEEDS=SEEDS
canon=u.canon;sha=u.sha;put=u.put;now=u.now
RULE={'reference_items':500,'window_items':500,'monitor_every_items':500,'monitor_times':list(range(1000,5001,500)),'distance':'max over integer x=1..100 of abs(F_first500(x)-F_recent500(x)); numerator is exact integer count difference /500','comparator':'strict >; integer numerator compared to integer threshold to avoid floating boundary ambiguity','calibration_eligibility':'Original training split AND order metadata == random; exactly48 of144 streams; excludes96 sorted streams using metadata only before distances or outcomes','calibration_unit':'One max across nine monitor times for each eligible random stream; equal weight48 streams/48 original multisets','threshold':'numpy quantile of48 stream maxima at0.95, method=higher; no subsequent adjustment','fallback':'Permanent published_EoH score on current packing state after first alarm; no rollback; first eligible action is alarm observed_count +1','calibration_scope':'New guard calibrated on random-arrival streams within original training set, not all144 streams; not original selector calibration, no false-positive guarantee','terminal_monitor':'Monitor at5000 retained for false-alarm accounting but cannot change any packing action','no_access':'No confirmation/risk inputs or losses, no prior shift outcomes or new test losses in threshold calibration'}

def verify_sources():
    records=json.loads((H/'evidence/SOURCE_SNAPSHOT.json').read_text())['files']
    for r in records:assert sha(pathlib.Path(r['source']).read_bytes())==r['sha256'] and sha((H/r['local']).read_bytes())==r['sha256'],r['local']
    return len(records)

def calibration():
    allfiles=sorted((H/'calibration_inputs').glob('train*.json'));assert len(allfiles)==144;rows=[];excluded=[]
    for p in allfiles:
        d=json.loads(p.read_bytes());assert d['split']=='train' and len(d['items'])==5000
        if d['order']!='random':excluded.append({'instance_id':d['instance_id'],'order':d['order'],'reason':'excluded_by_predeclared_order_metadata'});continue
        vals=[{'observed_count':t,'ks_count':ks_count_distance(d['items'][:500],d['items'][t-500:t])} for t in RULE['monitor_times']]
        rows.append({'instance_id':d['instance_id'],'group_id':d['group_id'],'family':d['family'],'input_file':str(p.relative_to(H)),'input_sha256':sha(p.read_bytes()),'events':vals,'max_ks_count':max(v['ks_count'] for v in vals)})
    assert len(rows)==48 and len(excluded)==96 and len(set(r['group_id'] for r in rows))==48
    maxima=[r['max_ks_count'] for r in rows];threshold=int(np.quantile(maxima,.95,method='higher'))
    result={'created_utc':now(),'rule':RULE,'eligible_count':48,'excluded_count':96,'threshold_count':threshold,'threshold_D':threshold/500,'rows':rows,'excluded':excluded,'calibration_streams_strictly_exceeding':sum(v>threshold for v in maxima),'test_inputs_not_yet_generated':True,'test_policy_runs_not_started':True}
    put(H/'CALIBRATION.json',result)
    return threshold

def prepare():
    verify_sources();put(H/'CALIBRATION_RULE.json',RULE)
    codefiles={str(p.relative_to(H)):sha(p.read_bytes()) for d in ['src','sources','evidence','calibration_inputs'] for p in sorted((H/d).rglob('*')) if p.is_file() and '__pycache__' not in str(p)}
    codefiles.update({f:sha((H/f).read_bytes()) for f in ['MODEL.json','CALIBRATION_RULE.json','LICENSE.source']})
    put(H/'DESIGN_FREEZE.json',{'created_utc':now(),'before_calibration_computation':True,'before_test_input_generation':True,'files':codefiles})
    threshold=calibration()
    protocol={'schema':'frozen-selector-drift-fallback-v1','created_utc':now(),'question':'Can a simple historical-item KS alarm followed by permanent EoH fallback mitigate frozen prefix selector harm under later distribution shifts?', 'scope':'Post-hoc proposed synthetic diagnostic after prior shift harm; new independent seeds, not a real externally blinded test or universal robustness/significance claim.', 'capacity':100,'items_per_stream':5000,'prefix_length':500,'pairs':u.PAIRS,'replicate_seed_roots':SEEDS,'value_seed_rule':'root +1000*pair_index +100*endpoint','permutation_seed_rule':'value seed+1000000','generator':'Original make function AST only, original parameters, rint ties to even, clipped1..100, independent seeded permutation; unmodified copied evidence.','stream_construction':'For each pair/replicate, draw A,B once; two stationary controls, A[:t]+B[t:], B[:t]+A[t:] for t500,2500. Six correlated streams per block.','change_points':[500,2500],'policies':METHODS,'training_sbs':SBS,'model_sha256':sha((H/'MODEL.json').read_bytes()),'features':list(FEATURE_NAMES),'selector':'Original model and selector byte-identical; BF first500, choose once using first500 and exact BF state; no fit call.','guard_rule':RULE,'threshold_count':threshold,'threshold_D':threshold/500,'threshold_frozen_before_new_inputs':True,'expected_counts':{'base_draws':18,'paired_blocks':9,'shift_streams':36,'stationary_streams':18,'all_streams':54,'full_policy_runs':270,'policy_steps':1350000,'guard_events':486,'calibration_streams':48,'calibration_events':432},'primary':['Mean DRIFT_FALLBACK minus SELECTOR on36 shifts','Mean DRIFT_FALLBACK minus fixed training SBS on36 shifts; stationary18 separately'],'secondary':['All five policy bins, paired W/T/L, worst harm, all12 shift cells and6 control cells, every stream','First alarms, prechange false alarms, stationary alarms, postchange exceedance and trigger delay, actual policy switches, alarms with no action','Guard CPU includes every observe update and KS computation; separate selector, policy, feature, serialization and calibration timing'],'oracle':'min(BF,BF_then_EoH) final bins is sameBF500 fixed-branch hindsight comparator only, never an adaptive oracle. Adaptive signed gap may be negative and is not called regret.','statistics':'Descriptive finite panel;54 streams are correlated within9 source/replicate blocks; no independence claim, confidence intervals, significance, result-driven weights or reruns.','execution_order':'pair, replicate, stationaryA,B,AtoB500,2500,BtoA500,2500; rotate5 policies by stream index mod5','budget':{'numeric_cpu_soft_seconds':175,'numeric_cpu_hard_seconds':180,'numeric_wall_hard_seconds':900,'whole_task_target_wall_seconds':1200,'single_thread':True,'model_or_api_calls':0,'paid_external_tools':0,'installations':0,'reruns':False},'source_isolation':'153 original source/model/license/training-input/prior-input-index files copied and hashed; old directories remain unchanged. Prior shift outcomes not read by this experiment.','environment':{'python':sys.version,'numpy':np.__version__,'platform':platform.platform()}}
    assert protocol['model_sha256']=='98991f0908867ff7de995b1e252d503c0180a5e74c67ac03d9444765fdede7ab'
    put(H/'PROTOCOL.json',protocol)
    codefiles.update({f:sha((H/f).read_bytes()) for f in ['CALIBRATION.json','PROTOCOL.json','DESIGN_FREEZE.json']})
    put(H/'CODE_SEED_FREEZE.json',{'created_utc':now(),'before_any_test_input_generation':True,'before_any_policy_execution':True,'files':codefiles})
    make=u.load_generator();metas=u.freeze_inputs(codefiles,make)
    # Compare only provenance metadata, never prior performance outcomes.
    prior=json.loads((H/'evidence/prior_shift_input_index.json').read_bytes());new=json.loads((H/'INPUT_INDEX.json').read_bytes())
    assert not {r['value_seed'] for r in prior['base_draws']}&{r['value_seed'] for r in new['base_draws']}
    assert not {r['permutation_seed'] for r in prior['base_draws']}&{r['permutation_seed'] for r in new['base_draws']}
    assert not {r['items_sha256'] for r in prior['instances']}&{r['items_sha256'] for r in new['instances']}
    put(H/'FRESHNESS_CHECK.json',{'passed':True,'prior_streams':54,'new_streams':54,'new_seed_roots':SEEDS,'base_value_seeds_disjoint':True,'base_permutation_seeds_disjoint':True,'complete_stream_hashes_disjoint':True,'no_claim_of_statistical_independence_between_paired_streams':True})
    print(canon({'stage':'FREEZE_READY','threshold_count':threshold,'threshold_D':threshold/500,'calibration_random_training_streams':48,'streams':54,'runs':270,'freeze_sha256':sha((H/'FREEZE.json').read_bytes())}),flush=True)
    return metas,threshold,make

def validate(metas,rows,threshold,make):
    ranks=rankings();model=json.loads((H/'MODEL.json').read_bytes());by={(r['instance_id'],r['policy']):r for r in rows};groups={}
    cal=json.loads((H/'CALIBRATION.json').read_bytes());maxima=[]
    for r in cal['rows']:
        d=json.loads((H/r['input_file']).read_bytes());vals=[independent_ks_count(d['items'][:500],d['items'][t-500:t]) for t in RULE['monitor_times']]
        assert vals==[x['ks_count'] for x in r['events']];maxima.append(max(vals))
    # Independent higher quantile: order statistic ceil((n-1)*.95).
    import math
    assert sorted(maxima)[math.ceil((len(maxima)-1)*.95)]==threshold
    for b in json.loads((H/'INPUT_INDEX.json').read_bytes())['base_draws']:
        seq,clips,perm=u.make_base(make,b['family'],b['value_seed']);d=json.loads((H/'inputs'/f"base__{b['base_id']}.json").read_bytes());assert seq==d['items'] and perm==d['source_position']
    for m in metas:
        d=json.loads((H/'inputs'/f"{m['instance_id']}.json").read_bytes());states={};assign={};fs={}
        for p in METHODS:states[p],assign[p],fs[p]=replay(d,by[m['instance_id'],p],ranks,threshold)
        assert states['BF']==states[SBS]==states['SELECTOR']==states['DRIFT_FALLBACK']
        for p in ['SELECTOR','DRIFT_FALLBACK']:
            r=by[m['instance_id'],p];z=(np.asarray(fs[p])-model['mean'])/model['scale'];dist=np.sum((np.asarray(model['x'])-z)**2,axis=1).tolist();nn=sorted(range(144),key=lambda i:(dist[i],i))[:5];costs=[sum(model['y'][i][j] for i in nn)/5 for j in range(2)];ix=model['sbs_index'] if costs[0]==costs[1] else int(costs[1]<costs[0]);assert r['selector_consumed_count']==500 and r['decision']['neighbors']==nn and r['decision']['predicted_final_bins']==costs and r['branch']==BRANCHES[ix]
        s=by[m['instance_id'],'SELECTOR'];f=by[m['instance_id'],'DRIFT_FALLBACK'];assert s['decision']==f['decision'];assert assign['SELECTOR']==assign[s['branch']]
        stop=f['actual_switch_item_1based'];limit=5000 if stop is None else stop-1;assert assign['DRIFT_FALLBACK'][:limit]==assign['SELECTOR'][:limit]
        groups.setdefault(m['prefix_group'],[]).append({'prefix':d['items'][:500],'state':states['BF'],'decision':s['decision']})
    assert len(groups)==18 and all(len(g)==3 and g[0]==g[1]==g[2] for g in groups.values())
    put(H/'CHECK.json',{'passed':True,'full_runs_checked':270,'packing_and_argmax_score_steps':1350000,'guard_events_independently_recomputed':486,'calibration_events_independently_recomputed':432,'selector_decisions_independently_recomputed':108,'same_prefix_groups':18,'base_draws_regenerated':18,'fallback_equals_selector_until_actual_switch':True,'no_rollback_or_future_input_to_guard':True,'scope':'Author-supplied independent algorithm implementation; external audit remains separate.'})

def aggregate(rr):
    pairs={}
    for name,a,b in [('fallback_minus_selector','DRIFT_FALLBACK','SELECTOR'),('fallback_minus_sbs','DRIFT_FALLBACK',SBS),('selector_minus_sbs','SELECTOR',SBS)]:
        ds=[r[a]-r[b] for r in rr];pairs[name]={'mean':float(np.mean(ds)),'total':sum(ds),'wins_ties_losses':[sum(d<0 for d in ds),sum(d==0 for d in ds),sum(d>0 for d in ds)],'worst_harm':max(ds),'best_improvement':min(ds)}
    return {'streams':len(rr),'paired_blocks':len(set(r['block_id'] for r in rr)),'mean_bins':{p:float(np.mean([r[p] for r in rr])) for p in METHODS},**pairs,'alarms':sum(r['first_alarm'] is not None for r in rr),'actual_switches':sum(r['actual_switch_item'] is not None for r in rr),'prechange_false_alarms':sum(r['prechange_false_alarm'] for r in rr),'stationary_false_alarms':sum(r['stationary_false_alarm'] for r in rr),'missed_first_alarm_after_change':sum(r['kind']=='shift' and (r['first_alarm'] is None or r['first_alarm']<=r['change_point']) for r in rr),'first_alarm_postchange_delays':[r['first_alarm_delay_items'] for r in rr if r['first_alarm_delay_items'] is not None],'fallback_mean_signed_gap_to_fixed_branch_oracle':float(np.mean([r['fallback_minus_fixed_branch_oracle'] for r in rr]))}

def analyze(metas,rows):
    by={(r['instance_id'],r['policy']):r for r in rows};out=[]
    for m in metas:
        rs={p:by[m['instance_id'],p] for p in METHODS};b={p:rs[p]['used_bins'] for p in METHODS};f=rs['DRIFT_FALLBACK'];alarm=f['first_alarm_observed_count'];cp=m['change_point'];post=[e['observed_count'] for e in f['drift_events'] if cp is not None and e['observed_count']>cp and e['strict_exceedance']];oracle=min(b['BF'],b[SBS])
        out.append({**m,**b,'selected_branch':f['branch'],'fixed_branch_oracle':oracle,'selector_regret_fixed_branch':b['SELECTOR']-oracle,'fallback_minus_fixed_branch_oracle':b['DRIFT_FALLBACK']-oracle,'fallback_minus_selector':b['DRIFT_FALLBACK']-b['SELECTOR'],'fallback_minus_sbs':b['DRIFT_FALLBACK']-b[SBS],'selector_minus_sbs':b['SELECTOR']-b[SBS],'first_alarm':alarm,'actual_switch_item':f['actual_switch_item_1based'],'prechange_false_alarm':bool(cp is not None and alarm is not None and alarm<=cp),'stationary_false_alarm':bool(cp is None and alarm is not None),'first_alarm_delay_items':alarm-cp if cp is not None and alarm is not None and alarm>cp else None,'first_postchange_exceedance':min(post) if post else None,'first_postchange_exceedance_delay':min(post)-cp if post else None,'alarm_but_no_policy_change':alarm is not None and f['actual_switch_item_1based'] is None,'monitor_cpu_seconds':f['cpu_monitor_seconds']})
    shifts=[r for r in out if r['kind']=='shift'];stat=[r for r in out if r['kind']=='stationary'];cells=[]
    for pair in u.PAIRS:
        for direction in ['A_to_B','B_to_A']:
            for cp in [500,2500]:cells.append({'pair_id':pair['id'],'direction':direction,'change_point':cp,**aggregate([r for r in shifts if r['pair_id']==pair['id'] and r['direction']==direction and r['change_point']==cp])})
    controlcells=[{'pair_id':pair['id'],'endpoint':end,**aggregate([r for r in stat if r['pair_id']==pair['id'] and r['origin_endpoint']==end])} for pair in u.PAIRS for end in ['A','B']]
    summary={'status':'complete','shift_only':aggregate(shifts),'stationary_only':aggregate(stat),'shift_cells':cells,'stationary_cells':controlcells,'cost':{'total_cpu_monitor_seconds':sum(r['cpu_monitor_seconds'] for r in rows),'total_cpu_selector_seconds':sum(r['cpu_selector_seconds'] for r in rows),'total_cpu_policy_seconds':sum(r['cpu_policy_seconds'] for r in rows),'sum_run_cpu_including_serialization_seconds':sum(r['cpu_total_including_serialization_seconds'] for r in rows)},'all_streams_included':True,'oracle_note':'Fixed sameBF500 branch comparator only. Adaptive signed gap is not regret to an adaptive oracle.','inference':'Descriptive correlated finite synthetic diagnostic, not universal robustness, significance or real blind test.'}
    put(H/'analysis/SUMMARY.json',summary);put(H/'analysis/PER_STREAM.json',out)
    events=[{'instance_id':m['instance_id'],**e} for m in metas for e in by[m['instance_id'],'DRIFT_FALLBACK']['drift_events']]
    put(H/'analysis/ALL_GUARD_EVENTS.json',events)
    for file,data in [('per_stream.csv',out),('shift_cells.csv',cells),('stationary_cells.csv',controlcells),('guard_events.csv',events)]:
        with (H/'analysis'/file).open('x',newline='') as f:w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
    print(canon({'stage':'SUMMARY','shift_only':summary['shift_only'],'stationary_only':summary['stationary_only']}),flush=True)

def main():
    start=time.monotonic();cpu=time.process_time();rows=[]
    def stop(signum,frame):raise RuntimeError(f'Frozen budget interrupt{signum}; no policy reruns')
    signal.signal(signal.SIGXCPU,stop);signal.signal(signal.SIGALRM,stop);signal.alarm(899);resource.setrlimit(resource.RLIMIT_CPU,(175,180))
    put(H/'RUN_STARTED.json',{'started_utc':now(),'cpu_soft':175,'cpu_hard':180,'wall_hard':900,'single_thread_env':{k:os.environ.get(k) for k in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS']}})
    try:
        prep_cpu=time.process_time();metas,threshold,make=prepare();prep_elapsed=time.process_time()-prep_cpu
        while not (H/'EXECUTION_RELEASE.json').exists():time.sleep(.2)
        u.verify_freeze();controls=load_controls();model=json.loads((H/'MODEL.json').read_bytes());assert model['sbs_index']==1 and model['k']==5
        put(H/'POLICIES_STARTED.json',{'started_utc':now(),'freeze_sha256':sha((H/'FREEZE.json').read_bytes()),'release_sha256':sha((H/'EXECUTION_RELEASE.json').read_bytes()),'preparation_calibration_cpu_seconds':prep_elapsed})
        for i,m in enumerate(metas):
            d=json.loads((H/'inputs'/f"{m['instance_id']}.json").read_bytes());names=METHODS[i%5:]+METHODS[:i%5];rs=[execute(d,p,controls,model,threshold) for p in names];rows.extend(rs)
            print(canon({'stage':'run','completed_runs':len(rows),'instance':m['instance_id'],'bins':{r['policy']:r['used_bins'] for r in rs}}),flush=True)
        assert len(rows)==270
        t=time.process_time();validate(metas,rows,threshold,make);check_cpu=time.process_time()-t
        t=time.process_time();analyze(metas,rows);analysis_cpu=time.process_time()-t
        u.verify_freeze();count=verify_sources();put(H/'SOURCE_ISOLATION_CHECK.json',{'passed':True,'original_files_checked':count,'before_after_bytes_match':True,'old_source_or_data_modified':False,'old_confirmation_risk_inputs_opened':False,'prior_shift_losses_opened':False,'model_fit_called':False})
        done={'status':'complete','finished_utc':now(),'full_runs':270,'policy_steps':1350000,'validated_steps':1350000,'guard_events':486,'calibration_events':432,'cpu_seconds':time.process_time()-cpu,'wall_seconds':time.monotonic()-start,'preparation_calibration_cpu_seconds':prep_elapsed,'validation_cpu_seconds':check_cpu,'analysis_cpu_seconds':analysis_cpu,'api_calls':0,'external_paid_tools':0,'installations':0,'retries':0}
        put(H/'RUN_COMPLETE.json',done);print(canon(done),flush=True)
    except BaseException as e:
        try:put(H/'RUN_FAILURE.json',{'status':'partial_or_failure','finished_utc':now(),'error':type(e).__name__+': '+str(e),'complete_rows_in_memory':len(rows),'raw_json_files':len(list((H/'raw').glob('*.json'))),'cpu_seconds':time.process_time()-cpu,'wall_seconds':time.monotonic()-start,'traceback':traceback.format_exc(),'rerun_permitted':False})
        except BaseException:pass
        raise
if __name__=='__main__':main()
