"""Independent scalar-score/integer replay; does not import the numerical runner or guard."""
import pathlib,json,hashlib,heapq,math
import numpy as np
from original_checker import rankings, independent_features, scalar_score
H=pathlib.Path(__file__).resolve().parents[1]
canon=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
sha=lambda x:hashlib.sha256(x).hexdigest()

def independent_ks_count(a,b):
    assert len(a)==len(b)==500
    # Independent empirical CDF enumeration, not histogram+cumsum implementation.
    sa=sorted(a);sb=sorted(b);ia=ib=0;best=0
    for v in range(1,101):
        while ia<500 and sa[ia]<=v:ia+=1
        while ib<500 and sb[ib]<=v:ib+=1
        best=max(best,abs(ia-ib))
    return best

def replay(data,row,ranks,threshold):
    archive=H/row['trajectory_file'];assert sha(archive.read_bytes())==row['trajectory_sha256']
    with np.load(archive) as loaded:z={k:loaded[k] for k in loaded.files}
    rem=[100]*5000;counts=[0]*101;counts[100]=5000;heaps=[[] for _ in range(101)];heaps[100]=list(range(5000));present=1<<100;used=0;prefix=None;events=[];first_alarm=None;actual_switch=None
    assert row['status']=='complete' and row['steps']==5000
    assert row['items_sha256']==sha(canon(data['items']).encode())
    history=[]
    for step,(item,target) in enumerate(zip(data['items'],z['assignment'].tolist())):
        eoh=row['policy']=='published_EoH' or (step>=500 and (row['branch']=='BF_then_EoH' or (row['policy']=='DRIFT_FALLBACK' and first_alarm is not None)))
        assert bool(z['algorithm_eoh'][step])==eoh
        if row['policy']=='DRIFT_FALLBACK' and first_alarm is not None and row['branch']=='BF' and actual_switch is None:actual_switch=step+1
        if eoh:
            possible=None
            for mask,rs in ranks[item]:
                if mask&present:possible=[r for r in rs if counts[r]];break
            assert possible is not None
        else:
            m=present>>item;assert m;possible=[item+(m&-m).bit_length()-1]
        candidates=[]
        for r in possible:
            while heaps[r] and rem[heaps[r][0]]!=r:heapq.heappop(heaps[r])
            assert heaps[r];candidates.append(heaps[r][0])
        expected=min(candidates);assert target==expected,(data['instance_id'],row['policy'],step,target,expected)
        before=rem[target];after=before-item;score=scalar_score(item,before) if eoh else float(-(before-item))
        assert math.isclose(float(z['chosen_score'][step]),score,rel_tol=1e-12,abs_tol=1e-12)
        assert 0<=after<100 and before>=item
        assert int(z['pre_remaining'][step])==before and int(z['post_remaining'][step])==after
        assert int(z['feasible_counts'][step])==sum(counts[item:])
        used+=int(before==100);assert int(z['used_bins_after'][step])==used
        rem[target]=after;counts[before]-=1;counts[after]+=1
        if counts[before]==0:present&=~(1<<before)
        present|=1<<after;heapq.heappush(heaps[after],target)
        history.append(item)
        if step==499:prefix=rem.copy()
        t=step+1
        if row['policy']=='DRIFT_FALLBACK' and t>=1000 and t%500==0:
            k=independent_ks_count(history[:500],history[-500:]);exceed=k>threshold;first=exceed and first_alarm is None
            if first:first_alarm=t
            events.append({'observed_count':t,'reference_start_1based':1,'reference_end_1based':500,'recent_start_1based':t-499,'recent_end_1based':t,'ks_count':k,'ks_D':k/500,'threshold_count':threshold,'threshold_D':threshold/500,'strict_exceedance':exceed,'first_alarm':first,'latched_alarm':first_alarm is not None,'earliest_action_item_1based':t+1 if first else None,'history_only_arguments':True})
    assert row['drift_events']==events
    assert first_alarm==row['first_alarm_observed_count'] and actual_switch==row['actual_switch_item_1based']
    assert rem==z['remaining'].tolist() and used==row['used_bins']==sum(r<100 for r in rem)
    assert sum(100-r for r in rem)==sum(data['items']) and used>=(sum(data['items'])+99)//100
    assert row['prefix_remaining_sha256']==sha(canon(prefix).encode())
    f=independent_features(data['items'][:500],prefix);assert np.allclose(f,row['prefix_features'],rtol=1e-13,atol=1e-14)
    return prefix,z['assignment'].tolist(),f
