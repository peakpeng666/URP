"""Freeze a single label-free distance gate before new policy recomputation."""
import pathlib,json,hashlib,time,math
H=pathlib.Path(__file__).resolve().parent
SOURCE=H.parent/'selector_sizes_20261007'
canon=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(name,obj):
    with (H/name).open('x') as f:f.write(canon(obj)+'\n')
def main():
    old=json.loads((SOURCE/'SPLITS.json').read_text())
    selected=[dict(p,source_run_id=i) for i,p in enumerate(old) if p['groups_per_training_family']==8 and p['seed']==2026100701]
    assert len(selected)==7
    put('SPLITS.json',selected)
    (H/'DATA.json').write_bytes((SOURCE/'DATA.json').read_bytes())
    (H/'SOURCE_RUN_REFERENCE.py').write_bytes((SOURCE/'run.py').read_bytes())
    ids={p['source_run_id'] for p in selected}
    baseline=[json.loads(s) for s in (SOURCE/'RAW_PREDICTIONS.jsonl').read_text().splitlines() if json.loads(s)['run_id'] in ids]
    assert len(baseline)==216
    with (H/'SOURCE_BASELINE.jsonl').open('x') as f:
        for r in baseline:f.write(canon(r)+'\n')
    protocol={
      'schema':'bpp-distance-reject-offline-v1','created_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
      'question':'Does a generic training-only distance rejection gate reduce fixed 5NN risk on the already-observed historical panel?',
      'prior_knowledge':'Prior LOFO full-data failure on normal ascending, worst +622 bins, was known before design. This is a new offline policy recomputation, not a blinded test, new online run, or evidence of deployment safety.',
      'scope':'All six full-data LOFO folds (40 groups / 120 streams each), plus full within-family control (48 groups / 144 streams). Each track evaluates the same 108 historical confirmation streams. Use seed2026100701 as canonical since every size8 seed has identical train/test IDs; no seed replication or pooled 216-stream inference.',
      'base_selector':'Exact original 31-feature, train-only population-standardized 5NN mean-cost regression, stable source row-order distance tie-break; cost prediction tie uses training SBS; SBS cost tie favors BF.',
      'rules':[{'name':'distance_q95','score':'Squared Euclidean distance to the 5th nearest training stream; no family/order feature or label input.','calibration':'For each training multiset group, remove all3 order variants; refit scaling on remaining training groups; calculate its3 held-group 5th-NN squared distances. Pool all group-held-out scores.','threshold':'Nearest-rank empirical 95th percentile: sorted scores[ceil(0.95*n)-1]. The 0.95 level is fixed in advance, no test labels, CV loss minimization or outcome-based threshold search.','decision':'If final full-training-model 5th-NN squared distance > training calibration threshold, select full-training SBS; otherwise original5NN. Equality is accepted. Gate may fire without changing branch.','alternatives':0}],
      'grouping':'Multiset groups remain intact across calibration and test; no confirmation row or its outcomes used in fit or threshold. All orders retained.',
      'reporting':['Paired mean bins, regret, gap recovered and W/T/L versus matched trainingSBS','Gated-minus-original5NN mean bins and W/T/L','Worst harm vsSBS','Every family/order cell','Gate trigger, changed decisions, harmful-case detection and misses, beneficial decisions wrongly rejected, neutral triggers','Raw calibration distances, thresholds, source neighbor predictions and costs'],
      'interpretation':'Finite descriptive paired panel only. No confidence intervals or population claims. Calibration distance distribution mixes families/orders and uses slightly different fitted scales; the95% quantile is heuristic and gives no OOD/error/coverage guarantee.',
      'resource_scope':{'cpu_hard_limit_seconds':120,'processes':1,'threads':1,'llm_calls':0,'api_calls':0,'new_streams':0,'new_online_policy_runs':0,'paid_charge_usd':0},
      'no_adaptation':'No alternative rule, q tuning, family/order carve-out, changed tests, or outcome-driven rerun. Preserve ineffective gates and regression cases.',
      'source_sha256':{n:sha((SOURCE/n).read_bytes()) for n in ['DATA.json','SPLITS.json','RAW_PREDICTIONS.jsonl','FREEZE.json','AUDIT.json','SOURCE_CHECKS.json']},
      'source_reuse':'Reuse previously checked prefix features and two historical branch costs. No full trajectory replay or repeated historical audit.'}
    put('PROTOCOL.json',protocol)
    names=['prepare.py','run.py','verify.py','pipeline.py','DATA.json','SPLITS.json','SOURCE_BASELINE.jsonl','SOURCE_RUN_REFERENCE.py','PROTOCOL.json']
    put('FREEZE.json',{'created_utc':protocol['created_utc'],'before_new_gate_calibration':True,'historical_test_outcomes_already_known':True,'files':{n:sha((H/n).read_bytes()) for n in names}})
