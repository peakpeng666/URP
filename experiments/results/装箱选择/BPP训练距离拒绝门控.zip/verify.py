"""Independent scalar distance and aggregate recomputation, not a history replay."""
import json,math,statistics
from prepare import H,put,sha

def main():
    d={r['instance_id']:r for r in json.loads((H/'DATA.json').read_text())}
    raw=list(map(json.loads,(H/'RAW_PREDICTIONS.jsonl').read_text().splitlines()))
    calibration={(r['model_id'],r['instance_id']):r for r in map(json.loads,(H/'RAW_CALIBRATION.jsonl').read_text().splitlines())}
    fits=json.loads((H/'FITS.json').read_text());checked_cal=checked_test=0;maxerr=0.
    def independently_fit(ids):
        xs=[d[i]['features'] for i in ids];n=len(xs);mu=[sum(z)/n for z in zip(*xs)]
        sd=[math.sqrt(sum((a[j]-mu[j])**2 for a in xs)/n) or 1. for j in range(31)]
        return mu,sd
    def neighbors(ids,mu,sd,query):
        ds=[sum(((query[j]-mu[j])/sd[j]-(d[i]['features'][j]-mu[j])/sd[j])**2 for j in range(31)) for i in ids]
        ix=sorted(range(len(ids)),key=lambda k:(ds[k],k))[:5]
        return ix,[ds[k] for k in ix]
    for m in fits:
        ids=m['train_ids'];scores=[]
        for g in sorted({d[i]['group_id'] for i in ids}):
            keep=[i for i in ids if d[i]['group_id']!=g];hold=[i for i in ids if d[i]['group_id']==g];mu,sd=independently_fit(keep)
            for i in hold:
                ix,ds=neighbors(keep,mu,sd,d[i]['features']);saved=calibration[m['model_id'],i]
                assert math.isclose(ds[-1],saved['d5_squared'],rel_tol=1e-11,abs_tol=1e-11)
                assert [keep[k] for k in ix]==saved['neighbor_ids']
                maxerr=max(maxerr,abs(ds[-1]-saved['d5_squared']));scores.append(ds[-1]);checked_cal+=1
        threshold=sorted(scores)[math.ceil(len(scores)*0.95)-1]
        assert math.isclose(threshold,m['threshold'],rel_tol=1e-11,abs_tol=1e-11)
        mu,sd=independently_fit(ids);sbs=min(range(2),key=lambda k:(sum(d[i]['costs'][k] for i in ids),k))
        for r in [r for r in raw if r['model_id']==m['model_id']]:
            ix,ds=neighbors(ids,mu,sd,d[r['instance_id']]['features'])
            means=[sum(d[ids[k]]['costs'][b] for k in ix)/5 for b in range(2)]
            knn=sbs if means[0]==means[1] else min(range(2),key=lambda k:means[k]);fire=ds[-1]>threshold;gated=sbs if fire else knn
            assert [ids[k] for k in ix]==r['neighbors'] and knn==r['knn_index'] and fire==r['trigger'] and gated==r['gated_index'] and sbs==r['sbs_index']
            for method,k in [('knn',knn),('gated',gated),('sbs',sbs)]:assert r[method+'_bins']==d[r['instance_id']]['costs'][k]
            assert r['oracle_bins']==min(d[r['instance_id']]['costs']);checked_test+=1
    all_metrics=json.loads((H/'CELL_METRICS.json').read_text())
    for summary in json.loads((H/'SUMMARY.json').read_text()):
        for mm in summary['metrics']:all_metrics.append(dict(mm,track=summary['track']))
    for m in all_metrics:
        rr=[r for r in raw if r['track']==m['track'] and ('family' not in m or (r['family']==m['family'] and r['order']==m['order']))]
        vals=[r[m['method']+'_bins'] for r in rr];diff=[a-r['sbs_bins'] for a,r in zip(vals,rr)]
        assert m['n']==len(rr) and math.isclose(m['mean_bins'],sum(vals)/len(vals),abs_tol=1e-12)
        assert math.isclose(m['delta_vs_sbs'],sum(diff)/len(diff),abs_tol=1e-12)
        assert m['wins_vs_sbs']==sum(a<0 for a in diff) and m['ties_vs_sbs']==sum(a==0 for a in diff) and m['losses_vs_sbs']==sum(a>0 for a in diff)
        assert m['worst_harm_vs_sbs']==max(0,max(diff))
    for name,h in json.loads((H/'FREEZE.json').read_text())['files'].items():assert sha((H/name).read_bytes())==h,name
    put('CHECK.json',{'status':'passed','independent_scalar_training_calibration_scores':checked_cal,'independent_scalar_test_decisions':checked_test,'aggregate_rows_recomputed':len(all_metrics),'max_calibration_distance_absolute_error':maxerr,'freeze_unchanged':True,'repeated_full_history_audit':False})
