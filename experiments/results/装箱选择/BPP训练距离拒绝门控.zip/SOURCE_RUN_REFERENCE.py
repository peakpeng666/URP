"""New offline fitting/prediction only. Historical policy outcomes are never called new runs."""
import pathlib,json,hashlib,time,sys,csv,collections
import numpy as np
from prepare import H,canon,sha,put
BRANCHES=['BF','BF_then_EoH']
def metrics(rows):
    y=np.array([r['selected_bins'] for r in rows]);s=np.array([r['subset_sbs_bins'] for r in rows]);o=np.array([r['oracle_bins'] for r in rows]);d=y-s
    gap=float(np.mean(s-o));reg=float(np.mean(y-o))
    return {'n':len(rows),'mean_bins':float(y.mean()),'subset_sbs_mean_bins':float(s.mean()),'pool_sbs_mean_bins':float(np.mean([r['pool_sbs_bins'] for r in rows])),'oracle_mean_bins':float(o.mean()),'delta_vs_subset_sbs':float(d.mean()),'regret':reg,'sbs_regret':gap,'gap_recovered':None if gap==0 else float(1-reg/gap),'wins':int(sum(d<0)),'ties':int(sum(d==0)),'losses':int(sum(d>0)),'worst_harm':int(max(d)),'eoh_selected':int(sum(r['selected_index']==1 for r in rows))}
def fit(x,y):
    mu=x.mean(0);sd=x.std(0);sd=np.where(sd==0,1.,sd);sbs=int(np.argmin(y.mean(0)))
    return {'mean':mu,'scale':sd,'x':(x-mu)/sd,'y':y,'sbs':sbs}
def main():
    for n,h in json.loads((H/'FREEZE.json').read_text())['files'].items():assert sha((H/n).read_bytes())==h,n
    put(H/'RUN_STARTED.json',{'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'freeze_sha256':sha((H/'FREEZE.json').read_bytes())})
    src=H/'original';protocol=json.loads((src/'PROTOCOL.json').read_text());source_model=json.loads((src/'MODEL.json').read_text());model_freeze=json.loads((src/'MODEL_FREEZE.json').read_text())
    sys.path.insert(0,str(src/'src'));from selector import features
    data=[];source_checks=[]
    for meta in protocol['instances']:
        if meta['split'] not in ['train','confirmation']:continue
        iid=meta['instance_id'];inputpath=src/'inputs'/f'{iid}.json';inp=json.loads(inputpath.read_text());rows=[]
        for b in BRANCHES:
            rp=src/'raw'/f'{iid}__{b}.json';r=json.loads(rp.read_text());tp=src/r['trajectory_file'];a=np.load(tp,allow_pickle=False)
            assert r['status']=='complete' and r['steps']==5000 and r['error'] is None
            assert r['trajectory_sha256']==sha(tp.read_bytes())
            assert r['items_sha256']==sha(canon(inp['items']).encode())
            assert len(a['assignment'])==5000 and int(a['used_bins_after'][-1])==r['used_bins']
            assert int(sum(a['remaining']<100))==r['used_bins'] and np.all(a['remaining']>=0)
            assert int(sum(100-a['remaining']))==sum(inp['items'])
            rows.append(r)
            source_checks.append({'instance_id':iid,'branch':b,'raw_file':str(rp.relative_to(src)),'raw_sha256':sha(rp.read_bytes()),'trajectory_sha256':sha(tp.read_bytes()),'input_sha256':sha(inputpath.read_bytes())})
            if b=='BF':
                rem=np.full(5000,100,dtype=np.int64)
                for t,j in enumerate(a['assignment'][:500]):rem[int(j)]-=inp['items'][t]
                f=features(inp['items'][:500],rem)
                assert np.allclose(f,r['prefix_features'],rtol=0,atol=1e-15)
        assert rows[0]['prefix_features']==rows[1]['prefix_features'] and rows[0]['prefix_remaining_sha256']==rows[1]['prefix_remaining_sha256']
        data.append({**meta,'features':rows[0]['prefix_features'],'costs':[r['used_bins'] for r in rows]})
    put(H/'DATA.json',data);put(H/'SOURCE_CHECKS.json',{'historical_label_runs_verified':len(source_checks),'prefix_feature_reconstructions':len(data),'records':source_checks})
    idx={r['instance_id']:i for i,r in enumerate(data)};xx=np.array([r['features'] for r in data]);yy=np.array([r['costs'] for r in data]);tr=[idx[i] for i in model_freeze['training_rows']]
    oldfit=fit(xx[tr],yy[tr]);assert np.allclose(oldfit['mean'],source_model['mean'],rtol=0,atol=1e-15) and np.allclose(oldfit['scale'],source_model['scale'],rtol=0,atol=1e-15)
    assert np.array_equal(yy[tr],source_model['y']) and np.allclose(oldfit['x'],source_model['x'],rtol=0,atol=1e-13)
    plans=json.loads((H/'SPLITS.json').read_text());out=[];fitmeta=[]
    rawfile=(H/'RAW_PREDICTIONS.jsonl').open('x');(H/'models').mkdir()
    for run_id,p in enumerate(plans):
        ti=np.array([idx[x] for x in p['train_ids']]);te=np.array([idx[x] for x in p['test_ids']]);pool=np.array([idx[x] for x in p['pool_ids']]);t=time.process_time();m=fit(xx[ti],yy[ti]);fitcpu=time.process_time()-t
        model_dict={k:(v.tolist() if isinstance(v,np.ndarray) else v) for k,v in m.items()};model_dict['train_ids']=p['train_ids'];mp=H/'models'/f'{run_id:04d}.json';put(mp,model_dict)
        pool_sbs=int(np.argmin(yy[pool].mean(0)));t=time.process_time();z=(xx[te]-m['mean'])/m['scale'];dist=np.sum((z[:,None,:]-m['x'][None,:,:])**2,axis=2);neighbors=np.argsort(dist,axis=1,kind='stable')[:,:5];predicted=m['y'][neighbors].mean(1);choices=np.argmin(predicted,axis=1);ties=predicted[:,0]==predicted[:,1];choices[ties]=m['sbs'];predcpu=time.process_time()-t
        fitmeta.append({k:p[k] for k in ['track','fold','seed','groups_per_training_family','train_groups','train_streams']}|{'run_id':run_id,'fit_cpu_seconds':fitcpu,'prediction_cpu_seconds':predcpu,'test_streams':len(te),'subset_sbs_index':m['sbs'],'pool_sbs_index':pool_sbs,'model_sha256':sha(mp.read_bytes())})
        for j,i in enumerate(te):
            r={k:p[k] for k in ['track','fold','seed','groups_per_training_family','train_groups','train_streams']}|{k:data[i][k] for k in ['instance_id','family','group_id','order','multiset_sha256']}|{'run_id':run_id,'selected_index':int(choices[j]),'selected_branch':BRANCHES[choices[j]],'selected_bins':int(yy[i,choices[j]]),'subset_sbs_index':m['sbs'],'subset_sbs_bins':int(yy[i,m['sbs']]),'pool_sbs_index':pool_sbs,'pool_sbs_bins':int(yy[i,pool_sbs]),'oracle_bins':int(min(yy[i])),'costs':yy[i].tolist(),'neighbors':[p['train_ids'][k] for k in neighbors[j]],'squared_distances':dist[j,neighbors[j]].tolist(),'predicted_costs':predicted[j].tolist()}
            rawfile.write(canon(r)+'\n');out.append(r)
    rawfile.close();put(H/'FITS.json',fitmeta)
    seed_metrics=[];cell_metrics=[]
    for track in ['family_holdout','within_family']:
        for size in [1,2,4,8]:
            for seed in range(2026100701,2026100721):
                rows=[r for r in out if r['track']==track and r['groups_per_training_family']==size and r['seed']==seed]
                assert len(rows)==108 and len({r['instance_id'] for r in rows})==108
                seed_metrics.append({'track':track,'groups_per_training_family':size,'seed':seed,**metrics(rows)})
                for family in protocol['families']:
                    for order in protocol['orders']:
                        cell=[r for r in rows if r['family']==family and r['order']==order];cell_metrics.append({'track':track,'groups_per_training_family':size,'seed':seed,'family':family,'order':order,**metrics(cell)})
    summary=[]
    for track in ['family_holdout','within_family']:
        for size in [1,2,4,8]:
            sms=[r for r in seed_metrics if r['track']==track and r['groups_per_training_family']==size]
            d={'track':track,'groups_per_training_family':size,'train_groups':size*(5 if track=='family_holdout' else 6),'train_streams':size*(15 if track=='family_holdout' else 18),'seeds':20,'test_streams_fixed':108}
            for k in ['mean_bins','subset_sbs_mean_bins','pool_sbs_mean_bins','oracle_mean_bins','delta_vs_subset_sbs','regret','sbs_regret','gap_recovered','wins','ties','losses','worst_harm','eoh_selected']:
                v=[r[k] for r in sms if r[k] is not None];d[k]={'mean':float(np.mean(v)),'min':float(min(v)),'max':float(max(v))} if v else None
            summary.append(d)
    put(H/'SEED_METRICS.json',seed_metrics);put(H/'CELL_METRICS.json',cell_metrics);put(H/'SUMMARY.json',summary)
    for name,rows in [('seed_metrics.csv',seed_metrics),('family_order_cells.csv',cell_metrics)]:
        with (H/name).open('x',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    put(H/'RUN_COMPLETE.json',{'new_offline_fits':len(fitmeta),'new_offline_test_predictions':len(out),'fit_cpu_seconds':sum(r['fit_cpu_seconds'] for r in fitmeta),'prediction_cpu_seconds':sum(r['prediction_cpu_seconds'] for r in fitmeta),'new_policy_runs':0,'new_streams':0,'llm_calls':0,'api_calls':0,'original_model_recovered_exactly':True,'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())})
    print(canon({'stage':'complete','models':len(fitmeta),'predictions':len(out)}),flush=True)
