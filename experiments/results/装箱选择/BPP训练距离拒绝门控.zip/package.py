import pathlib,json,hashlib,zipfile,time
h=pathlib.Path(__file__).resolve().parent;s=time.process_time()
files=sorted(p for p in h.iterdir() if p.is_file() and p.name not in ['MANIFEST.json','SHA256SUMS.txt','selector_reject_20261007.zip','PACKAGE_RECEIPT.json'])
manifest={p.name:{'size_bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files}
(h/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
(h/'SHA256SUMS.txt').write_text(''.join(f'{v["sha256"]}  {k}\n' for k,v in manifest.items()))
z=h/'selector_reject_20261007.zip'
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED) as f:
    for p in files+[h/'MANIFEST.json',h/'SHA256SUMS.txt']:f.write(p,p.name)
with zipfile.ZipFile(z) as f:
    assert f.testzip() is None
    for name,r in manifest.items():assert hashlib.sha256(f.read(name)).hexdigest()==r['sha256']
(h/'PACKAGE_RECEIPT.json').write_text(json.dumps({'archive':z.name,'sha256':hashlib.sha256(z.read_bytes()).hexdigest(),'bytes':z.stat().st_size,'files':len(files)+2,'package_cpu_seconds':time.process_time()-s,'crc_and_manifest_checked':True},indent=2)+'\n')
print((h/'PACKAGE_RECEIPT.json').read_text())
