"""A single pre-frozen, training-only q95 5NN-distance fallback."""
import pathlib,json,math,time,csv,collections
import numpy as np
from prepare import H,put,sha,canon
BRANCHES=['BF','BF_then_EoH']
def fit(x,y):
    # Unchanged from historical source run.py.
    mu=x.mean(0);sd=x.std(0);sd=np.where(sd==0,1.,sd);sbs=int(np.argmin(y.mean(0)))
    return {'mean':mu,'scale':sd,'x':(x-mu)/sd,'y':y,'sbs':sbs}
def predict(m,x):
    z=(x-m['mean'])/m['scale'];dist=np.sum((z[:,None,:]-m['x'][None,:,:])**2,axis=2)
    neighbors=np.argsort(dist,axis=1,kind='stable')[:,:5];predicted=m['y'][neighbors].mean(1)
    choice=np.argmin(predicted,axis=1);choice[predicted[:,0]==predicted[:,1]]=m['sbs']
    return choice,neighbors,dist,predicted
def metric(rows,method):
    y=np.array([r[method+'_bins'] for r in rows]);s=np.array([r['sbs_bins'] for r in rows]);o=np.array([r['oracle_bins'] for r in rows]);b=np.array([r['knn_bins'] for r in rows])
    d=y-s;e=y-b;gap=float(np.mean(s-o));reg=float(np.mean(y-o))
    return {'method':method,'n':len(rows),'mean_bins':float(y.mean()),'regret':reg,'delta_vs_sbs':float(d.mean()),'gap_recovered':None if gap==0 else float(1-reg/gap),'wins_vs_sbs':int(sum(d<0)),'ties_vs_sbs':int(sum(d==0)),'losses_vs_sbs':int(sum(d>0)),'worst_harm_vs_sbs':int(max(0,max(d))),'delta_vs_knn':float(e.mean()),'wins_vs_knn':int(sum(e<0)),'ties_vs_knn':int(sum(e==0)),'losses_vs_knn':int(sum(e>0))}
def detection(rows):
    n=lambda pred:sum(bool(pred(r)) for r in rows)
    return {'n':len(rows),'triggers':n(lambda r:r['trigger']),'changed_decisions':n(lambda r:r['trigger'] and r['gated_index']!=r['knn_index']),
      'harmful_detected':n(lambda r:r['trigger'] and r['knn_bins']>r['sbs_bins']),
      'harmful_missed':n(lambda r:not r['trigger'] and r['knn_bins']>r['sbs_bins']),
      'beneficial_rejected':n(lambda r:r['trigger'] and r['knn_bins']<r['sbs_bins']),
      'neutral_triggers':n(lambda r:r['trigger'] and r['knn_bins']==r['sbs_bins']),
      'bins_rescued':sum(max(0,r['knn_bins']-r['gated_bins']) for r in rows),
      'bins_sacrificed':sum(max(0,r['gated_bins']-r['knn_bins']) for r in rows)}
def main():
    freeze=json.loads((H/'FREEZE.json').read_text())
    for n,h in freeze['files'].items():assert sha((H/n).read_bytes())==h,n
    put('RUN_STARTED.json',{'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'freeze_sha256':sha((H/'FREEZE.json').read_bytes())})
    data=json.loads((H/'DATA.json').read_text());idx={r['instance_id']:i for i,r in enumerate(data)}
    x=np.array([r['features'] for r in data]);y=np.array([r['costs'] for r in data]);plans=json.loads((H/'SPLITS.json').read_text())
    baseline={(r['run_id'],r['instance_id']):r for r in map(json.loads,(H/'SOURCE_BASELINE.jsonl').read_text().splitlines())}
    raw=[];cal=[];fits=[];inner_fits=0
    for model_id,p in enumerate(plans):
        tr=[idx[i] for i in p['train_ids']];te=[idx[i] for i in p['test_ids']]
        assert all(data[i]['split']=='train' for i in tr) and all(data[i]['split']=='confirmation' for i in te)
        groups=sorted({data[i]['group_id'] for i in tr});assert not set(groups)&{data[i]['group_id'] for i in te}
        scores=[]
        for group in groups:
            keep=[i for i in tr if data[i]['group_id']!=group];hold=[i for i in tr if data[i]['group_id']==group]
            assert len(hold)==3
            inner=fit(x[keep],y[keep]);choice,nei,dist,pred=predict(inner,x[hold]);inner_fits+=1
            for j,i in enumerate(hold):
                score=float(dist[j,nei[j,-1]]);scores.append(score)
                cal.append({'model_id':model_id,'group_id':group,'instance_id':data[i]['instance_id'],'d5_squared':score,'neighbor_ids':[data[keep[k]]['instance_id'] for k in nei[j]]})
        threshold=sorted(scores)[math.ceil(0.95*len(scores))-1]
        model=fit(x[tr],y[tr]);choice,nei,dist,pred=predict(model,x[te]);sbs=model['sbs']
        fits.append({'model_id':model_id,'source_run_id':p['source_run_id'],'track':p['track'],'fold':p['fold'],'train_ids':p['train_ids'],'training_groups':len(groups),'calibration_n':len(scores),'threshold':threshold,'quantile':0.95,'sbs_index':sbs,'mean':model['mean'].tolist(),'scale':model['scale'].tolist()})
        for j,i in enumerate(te):
            b=baseline[p['source_run_id'],data[i]['instance_id']]
            assert int(choice[j])==b['selected_index'] and sbs==b['subset_sbs_index']
            assert np.allclose(pred[j],b['predicted_costs'],rtol=0,atol=1e-12)
            assert [p['train_ids'][k] for k in nei[j]]==b['neighbors']
            score=float(dist[j,nei[j,-1]]);trigger=score>threshold;g=sbs if trigger else int(choice[j])
            raw.append({k:data[i][k] for k in ['instance_id','family','order','group_id','multiset_sha256']}|{'model_id':model_id,'source_run_id':p['source_run_id'],'track':p['track'],'fold':p['fold'],'knn_index':int(choice[j]),'gated_index':g,'sbs_index':sbs,'knn_bins':int(y[i,choice[j]]),'gated_bins':int(y[i,g]),'sbs_bins':int(y[i,sbs]),'oracle_bins':int(y[i].min()),'costs':y[i].tolist(),'trigger':trigger,'d5_squared':score,'threshold':threshold,'distance_ratio':score/threshold if threshold else None,'neighbors':[p['train_ids'][k] for k in nei[j]],'squared_distances':dist[j,nei[j]].tolist(),'predicted_costs':pred[j].tolist()})
    for name,rows in [('RAW_PREDICTIONS.jsonl',raw),('RAW_CALIBRATION.jsonl',cal)]:
        with (H/name).open('x') as f:
            for r in rows:f.write(canon(r)+'\n')
    put('FITS.json',fits)
    summary=[];cells=[]
    for track in ['family_holdout','within_family']:
        rr=[r for r in raw if r['track']==track]
        assert len(rr)==108 and len({r['instance_id'] for r in rr})==108
        summary.append({'track':track,'metrics':[metric(rr,m) for m in ['knn','gated','sbs','oracle']],'gate_detection':detection(rr)})
        for family,order in sorted({(r['family'],r['order']) for r in rr}):
            cc=[r for r in rr if (r['family'],r['order'])==(family,order)]
            for m in ['knn','gated','sbs','oracle']:cells.append({'track':track,'family':family,'order':order,**metric(cc,m),**{'gate_'+k:v for k,v in detection(cc).items()}})
    put('SUMMARY.json',summary);put('CELL_METRICS.json',cells)
    with (H/'family_order_cells.csv').open('x',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(cells[0]));w.writeheader();w.writerows(cells)
    put('RUN_COMPLETE.json',{'outer_model_fits':len(fits),'inner_group_heldout_fits':inner_fits,'training_calibration_scores':len(cal),'offline_test_gate_decisions':len(raw),'unique_historical_test_streams':108,'new_online_policy_runs':0,'new_streams':0,'api_calls':0,'llm_calls':0,'baseline_reproduction_rows':len(raw)})
    print(canon({'summary':summary}),flush=True)
