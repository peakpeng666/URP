#!/usr/bin/env bash
set -euo pipefail
source_dir="$(cd "$(dirname "$0")" && pwd)"
out="${1:?Usage: bash REPLAY.sh /new/output/directory}"
[ ! -e "$out" ] || { printf '%s\n' 'Output directory must not already exist.' >&2; exit 1; }
mkdir -p "$out"
for f in prepare.py run.py verify.py pipeline.py DATA.json SPLITS.json SOURCE_BASELINE.jsonl SOURCE_RUN_REFERENCE.py PROTOCOL.json FREEZE.json; do cp "$source_dir/$f" "$out/"; done
cd "$out"
OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 OMP_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 python - <<'PY'
import resource,time
resource.setrlimit(resource.RLIMIT_CPU,(115,120))
s=time.process_time()
import run,verify
run.main();verify.main()
from prepare import put
put('REPLAY_COST.json',{'cpu_seconds':time.process_time()-s,'cpu_hard_limit_seconds':120,'api_calls':0,'llm_calls':0,'new_policy_runs':0})
PY
