选择器距离拒绝与训练SBS回退离线有限试验

先读REPORT_ZH.txt。主结果为负：LOFO门控比原5NN平均多9.815箱，最坏+622未改变；20个有害选择全部漏过，11个有益选择被错误回退。within-family不变。

关键文件：
- PROTOCOL.json / FREEZE.json：新校准前冻结的唯一规则及输入/源码哈希
- DATA.json / SPLITS.json：复用数据、7个满数据量固定分组计划
- SOURCE_BASELINE.jsonl / SOURCE_RUN_REFERENCE.py：旧5NN原始输出子集和参考实现
- RAW_CALIBRATION.jsonl / FITS.json：864条训练留组距离、7个阈值及外层模型参数
- RAW_PREDICTIONS.jsonl：216条配对测试决策、门控、原始分支箱数、距离及邻居
- SUMMARY.json / CELL_METRICS.json / family_order_cells.csv：总体与全部family/order分解
- CHECK.json / POSTCHECK.json / COST.json：独立复算、补充检查、资源实测
- prepare.py / run.py / verify.py / pipeline.py：完整本次数值源码

无新online策略运行、无LLM/API调用、无外部上传。旧测试已看过，不是新盲测。两个track共享108条唯一测试流，不代表216个独立样本。

原始准备与冻结：在同级保留selector_sizes_20261007源项目，在一个新的selector_reject目录中只放4个主要.py文件，运行python pipeline.py。已有输出采用只创建不覆盖，防止静默覆写。

只复算本包而不读取旧项目：运行 bash REPLAY.sh /一个全新的输出目录。
REPLAY.sh复制原冻结输入与源码，重算run与verify；不会覆盖现有结果。需要Python3与numpy。重算只检验已有冻结规则，不新增试验。

本目录留给父任务统一私有URP归档；本任务未自行上传或变更权限。
