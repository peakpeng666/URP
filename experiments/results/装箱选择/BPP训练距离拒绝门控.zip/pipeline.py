import os,resource,time,signal,json,pathlib,traceback
for k in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[k]='1'
resource.setrlimit(resource.RLIMIT_CPU,(115,120));signal.alarm(600)
start=time.monotonic();cpu=time.process_time();stages=[]
try:
    for name in ['prepare','run','verify']:
        s=time.monotonic();c=time.process_time();mod=__import__(name);mod.main();stages.append({'stage':name,'cpu_seconds':time.process_time()-c,'wall_seconds':time.monotonic()-s})
    from prepare import put
    put('COST.json',{'status':'complete','cpu_seconds':time.process_time()-cpu,'wall_seconds':time.monotonic()-start,'stages':stages,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'cpu_hard_limit_seconds':120,'processes':1,'child_processes':0,'threads':1,'api_calls':0,'llm_calls':0,'paid_charge_usd':0,'scope':'Single numerical process including input subset creation, freezing, calibration, predictions, raw outputs, independent scalar verification. Excludes initial source inspection, code authoring and final report/hash creation.'})
except BaseException as e:
    pathlib.Path(__file__).with_name('FAILURE.json').write_text(json.dumps({'error':str(e),'traceback':traceback.format_exc(),'cpu_seconds':time.process_time()-cpu,'stages':stages},indent=2));raise
finally:signal.alarm(0)
