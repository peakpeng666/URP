import json,pathlib,time,hashlib,os
from fractions import Fraction
from engine import pack
R=pathlib.Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(n,x):
 with (R/n).open('x') as f:json.dump(x,f,ensure_ascii=False,separators=(',',':'))
class RecordedStream:
 # No distribution, change point, group or suffix statistic is exposed to engine.
 # Iterator observes every item boundary equally; the scorer still gets item and feasible bins only.
 def __init__(self,items):self.items=items;self.boundaries=[]
 def __len__(self):return len(self.items)
 def __iter__(self):
  for item in self.items:
   self.boundaries.append([time.process_time_ns(),time.monotonic_ns()]);yield item
  self.boundaries.append([time.process_time_ns(),time.monotonic_ns()])
def main():
 put('RUN_CLAIM.json',{'pid':os.getpid(),'start_unix':time.time(),'attempt':1})
 for n,h in json.loads((R/'SOURCE_FREEZE.json').read_text())['files'].items():assert sha((R/n).read_bytes())==h,n
 approval=json.loads((R/'UPSTREAM_PASS.json').read_text());assert approval['status']=='PASS' and approval['root_released'] is True
 s=json.loads((R/'DATA_SEAL.json').read_text());assert sha((R/'SOURCE_FREEZE.json').read_bytes())==s['source_freeze_sha256']
 (R/'trajectories').mkdir();rows=[]
 for a in s['plan']:
  e=s['instances'][a['sequence']];raw=(R/e['path']).read_bytes();assert sha(raw)==e['file_sha256'];items=json.loads(raw)['items']
  stream=RecordedStream(items);r=pack(stream,a['arm'])
  cp=e['change_after_item'];b=stream.boundaries;assert len(b)==1001
  prefix_set=set(r['assignment'][:cp]);suffix_set=set(r['assignment'][cp:])
  r['segment_diagnostics']={'change_after_item':cp,'prefix_used_bins':len(prefix_set),'suffix_touched_bins':len(suffix_set),'suffix_new_bins':len(suffix_set-prefix_set),'cross_boundary_bins':len(prefix_set&suffix_set),'total_used_bins':r['used_bins'],'prefix_CPU_ns':b[cp][0]-b[0][0],'suffix_CPU_ns':b[-1][0]-b[cp][0],'prefix_wall_ns':b[cp][1]-b[0][1],'suffix_wall_ns':b[-1][1]-b[cp][1],'note':'One continuous packing state. Prefix bins plus suffix touched bins is NOT a total or independent segment cost. Suffix new bins is an accounting increment, not a fresh suffix packing. Timings include observer overhead and exclude engine setup/final summary.'}
  r['boundary_clocks_ns']=b
  running=0;r['observed_running_sums']=[]
  for item in items:running+=item;r['observed_running_sums'].append(running)
  l1=(sum(items)+99)//100;f=Fraction(l1,r['used_bins'])
  r.update({'sequence':e['sequence'],'family':e['family'],'within_family':e['within_family'],'direction':e['direction'],'change_after_item':cp,'prefix64_sum':sum(items[:64]),'items_sha256':e['items_sha256'],'L1':l1,'F_exact':str(f),'F':float(f),'status':'ok'})
  put(f"trajectories/{e['sequence']:02d}_{a['arm']}.json",r)
  rows.append({k:r[k] for k in ['sequence','family','within_family','arm','used_bins','L1','F_exact','F','status','gate','resources','segment_diagnostics']})
 put('RESULTS.json',rows);print(json.dumps({'status':'completed','trajectories':len(rows),'item_placements':64000}))
if __name__=='__main__':main()
