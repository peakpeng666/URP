"""Transparent deterministic policy wrapper; original patch bytes unchanged."""
import time, numpy as np
from patch import score as patch_score
# patch source deliberately contains no import, as in the original recorded code.
patch_score.__globals__['np']=np

def choose(item,bins,method):
 if method=='B':return int(np.argmin(bins))
 scores=patch_score(item,bins)
 assert scores.shape==bins.shape and np.isfinite(scores).all()
 return int(np.argmax(scores))

def pack(items,arm):
 remaining=[100]*len(items);events=[];prefix_sum=0;switched=False;gate=None
 t0=time.process_time_ns();w0=time.monotonic_ns();stats_ns=0;decision_ns=0;prefix_done=None
 for step,item in enumerate(items,1):
  # Streaming item access only: gate has no reference to family or suffix.
  method='P' if arm=='P' or (step>64 and switched) else 'B'
  feasible=[j for j,r in enumerate(remaining) if r>=item]
  values=np.array([remaining[j] for j in feasible],dtype=np.float64);values.flags.writeable=False
  j=feasible[choose(item,values,method)];before=remaining[j];remaining[j]-=item
  events.append({'step':step,'item':item,'bin':j,'remaining_before':before,'remaining_after':remaining[j],'method':method,'feasible_count':len(feasible)})
  if arm in ('D','G') and step<=64:
   t=time.process_time_ns();prefix_sum+=item;stats_ns+=time.process_time_ns()-t
   if step==64:
    t=time.process_time_ns();switched=arm=='D' or prefix_sum<2880
    gate={'decision_after_item':64,'first_postdecision_item':65,'observed_prefix_sum':prefix_sum,'threshold':2880,'switch':switched,'rule':'unconditional' if arm=='D' else 'strict_less'}
    decision_ns=time.process_time_ns()-t
  if step==64:prefix_done={'CPU_ns':time.process_time_ns()-t0,'wall_ns':time.monotonic_ns()-w0,'used_bins':sum(r<100 for r in remaining)}
 return {'arm':arm,'assignment':[e['bin'] for e in events],'events':events,'remaining':remaining,'used_bins':sum(r<100 for r in remaining),'gate':gate,'resources':{'CPU_ns':time.process_time_ns()-t0,'wall_ns':time.monotonic_ns()-w0,'prefix64':prefix_done,'prefix_sum_update_CPU_ns':stats_ns,'decision_dispatch_CPU_ns':decision_ns,'switch_state_copy_count':0,'cost_note':'decision_ns includes branch and receipt creation; dispatch included in full trajectory; no state copy/reset'}}
