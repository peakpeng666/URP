def score(item, bins):
    lo = (bins - item - 0.5) / 45.0
    hi = (bins - item + 0.5) / 45.0
    s = np.exp(0.0 - lo * lo * lo) - np.exp(0.0 - hi * hi * hi)
    return np.where(bins == item, s + 1.0, np.where(bins - item == 1, s + 0.5, s))
