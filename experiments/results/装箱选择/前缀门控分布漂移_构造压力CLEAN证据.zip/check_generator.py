import json,pathlib,hashlib,numpy as np
from generate import draw,generate
R=pathlib.Path(__file__).resolve().parent;S=R.parent/'bpp_online_prefix_gate_20261008'
class BoundaryRNG:
 def __init__(self):self.calls=[]
 def weibull(self,shape,size):assert shape==3;self.calls.append(['W',size]);return np.full(size,11/45)
 def integers(self,low,high,size,dtype):assert (low,high)==(1,101);self.calls.append(['U',size]);return np.full(size,77,dtype=dtype)
checks=[]
for direction in ['W_to_U','U_to_W']:
 for cp in [64,500]:
  r=BoundaryRNG();x=generate(r,direction,cp);a,b=direction.split('_to_');v={'W':11,'U':77}
  assert x==[v[a]]*cp+[v[b]]*(1000-cp) and r.calls==[[a,cp],[b,1000-cp]]
  checks.append({'direction':direction,'change_after_item':cp,'first_suffix_item':cp+1,'counts_ok':True})
class ClipRNG:
 def weibull(self,shape,size):assert shape==3 and size==6;return np.array([0,1,1.5,2.5,100,101])/45
assert draw(ClipRNG(),'W',6)==[1,1,2,2,100,100]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source={n:sha(R/n) for n in ['engine.py','patch.py']}
assert all((R/n).read_bytes()==(S/n).read_bytes() for n in source)
assert source['engine.py']=='c61fd5ab38da3edae5f2a48eec9589b40ae6774835a4473d2b483f387ad2f658'
assert source['patch.py']=='6bff5a3b26ab13b6ae688cdccca88d647168dd9297d0184b605a5ae3bba39546'
assert json.loads((R/'evidence/upstream_TOYS.json').read_text())['status']=='PASS'
with (R/'PRECHECK.json').open('x') as f:json.dump({'status':'PASS','checks':checks,'clip_round_check':True,'candidate_calls':0,'scientific_rng_draws':0,'source_byte_identity':source,'upstream_toys_reused_not_rerun':True},f,indent=2)
print('PASS source byte identity and generator boundary checks; no candidate evaluation')
