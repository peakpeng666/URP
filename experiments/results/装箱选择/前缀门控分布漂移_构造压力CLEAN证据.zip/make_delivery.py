import json,pathlib,csv,hashlib,zipfile,time
from fractions import Fraction
R=pathlib.Path(__file__).resolve().parent
read=lambda n:json.loads((R/n).read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
rows=read('RESULTS.json');paired=read('PAIRED_RESULTS.json');contrasts=read('FAMILY_CONTRASTS.json');receipt=read('EXIT_RECEIPT.json')
segments=[]
for row in rows:segments.append(dict(sequence=row['sequence'],family=row['family'],arm=row['arm'],**row['segment_diagnostics']))
with (R/'segment_diagnostics.csv').open('x',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(segments[0]));w.writeheader();w.writerows(segments)
lines=['# prefix64 固定门控：分布漂移压力试验','',
'## 结果先行',
'64/64 条轨迹成功，16/16 条流齐全，无缺项、无重跑。W→U 的两组中，G 全部开启补丁且每条均比 BF 多用箱；U→W 的两组中，G 全部保持 BF，均比无条件延迟补丁 D 多用箱。该构造压力样本说明：只看开头 64 项的一次性决定，可能在后续分布改变时误开或错失收益。它不估计真实漂移发生率，也不构成统计泛化或校准。',
'', '## 固定设计与边界',
'- 容量100，每流1000项；两方向 W→U、U→W × 变点64或500 × 各4重复，共16条新流。变点k指前k项来自第一族、第k+1项起来自第二族。',
'- W = NumPy round(clip(45 × Weibull(shape=3),1,100))；U = 整数均匀1..100。沿用D1公式，分段顺序独立取样。',
'- B：始终BF；P：始终原补丁；D：前64 BF，第65项起原补丁；G：前64 BF，当且仅当前64和 <2880 时第65项起原补丁。严格小于，等于不切换。64/2880不调参。',
'- engine.py与patch.py逐字节沿用原实现。补丁哈希6bff5a3b26ab13b6ae688cdccca88d647168dd9297d0184b605a5ae3bba39546。原玩具PASS复用，新检查仅生成器边界/clip-round和源码字节，不增加候选试跑。',
'- 固定16分组、64执行次序、生成规则、指标及验证器先冻结。仅一次os.getrandom(32)，按序号HMAC派生PCG64种子；排除已知63个旧数组hash及本批重复，仅按精确重复检查，无质量筛选、替换或挑样。',
'- 先核验原48轨迹最终独审PASS_WITH_SCOPE_LIMITS和CLEAN包绑定，满足root条件放行后才生成并唯一主跑。UPSTREAM_PASS.json记录核验。',
'- 每臂每流均独立从空箱状态实跑；G与D/B结果相同不复用轨迹。整个流内箱状态持续，变点及门控均无重置或复制。',
'- scorer只收到当前item与按原索引排序的可行剩余容量。engine读取流和已知长度1000；不接收方向、变点、族标签或未来统计。逐项时钟记录器不含分组/变点，离线才切段；时间包含记录开销。',
'', '## 分组配对主结果',
'主指标：总箱数越低越好；精确F = ceil(sum(items)/100) / 总箱数，越高越好。下表Δ箱数=G−对照，正值为G受损；胜/平/负按箱数定义。每组固定4对，没有合并平均。',
'', '|分组|对比|4条配对Δ箱数|平均Δ箱数|胜/平/负|平均ΔF（精确分数）|缺项|','|---|---|---|---:|---|---|---:|']
for c in contrasts:
 if c['contrast'].startswith('G-'):lines.append(f"|{c['family']}|{c['contrast']}|{c['paired_bins']}|{c['mean_delta_bins']}|{c['wins_ties_losses']}|{c['mean_delta_F_exact']}|{c['missing_pairs']}|")
lines+=['','## 每流总箱数、精确F及门控','|序号|分组|前64和|切换|B 箱/F|P 箱/F|D 箱/F|G 箱/F|','|---|---|---:|---|---|---|---|---|']
for p in paired:lines.append('|'+ '|'.join([str(p['sequence']),p['family'],str(p['prefix64_sum']),'是' if p['gate_switch'] else '否']+[f"{p[a+'_bins']} / {p[a+'_F']}" for a in 'BPDG'])+'|')
lines+=['','## 变点前后成本：只作连续状态诊断',
'每条轨迹的segment_diagnostics记录：前段已用箱、后段触及箱、后段新增箱、跨变点共用箱，以及变点前后CPU/wall时间。segment_diagnostics.csv包含全部64行。',
'前段已用箱 + 后段新增箱 = 全流总箱数只是记账恒等式；“后段新增箱”受前段余量影响，不是把后段单独从空箱运行的成本。禁止把“前段已用箱 + 后段触及箱”当作总箱数，因为会重复计算跨界共用箱。未计算两段独立F、未用分段箱数相加替代主指标。',
'每步assignment/events及1001个边界时钟原样保留。observed_running_sums是运行完成后的顺序累加审计字段，不作为候选输入；实际G决策所读前64和保存在gate.observed_prefix_sum。时钟微小开销/计时分辨率不支持零开销结论。',
'', '## 复核与资源',
'- check_and_report.py只用整数重建逐步容量、BF选择、剩余箱、总箱数和精确F，核验全部前64 BF一致、G开门全轨迹等于D/关门等于B，并核验分段记账与时钟边界。验证不重新调用补丁或求解器。',
'- VALIDATION.json：PASS；64000项放置全部合法。未独立重算补丁评分，需将合法性/源码完整性与评分正确性审计区分。',
f"- 唯一主跑：CPU {receipt['CPU_total']:.6f}s；wall {receipt['wall_seconds']:.6f}s；退出码{receipt['exit_code']}，进程已reap。RLIMIT_CPU=60s，alarm=90s。生成/只读验证/打包不是额外科学主跑。",
'- 源码冻结和执行时序由本地记录支持，不是第三方可信执行证明或外部预注册。旧hash排重只覆盖已提供的历史集合。',
'', '## 解释和限制',
'W→U：开头W令G开启，后续U下G相对B的损失在两种变点均逐条出现；cp64平均多8.75箱，cp500平均多2.75箱。它仍可能比始终补丁P好，故不可把G对P的改善误称相对BF无损。',
'U→W：开头U令G关闭，G与BF完全一致，但后续W带来的补丁机会未被重新评估；相对D，cp64平均多9.75箱，cp500平均多6.5箱。这里是对D/P的机会损失，不是对BF的直接伤害。',
'原固定族试验的混合族已有G−B单条+2箱（组平均+0.5箱）；本批不重跑、不覆盖、更不抹去该伤害。本批也不支持“一次门控能保证不伤BF”的主张。',
'本试验刻意选定相反族切换；四个小组各4流仅提供构造压力证据。方向/变点之间不是同一底层随机流的反事实配对；仅同一流内四臂配对。无显著性/发生率/广泛收益宣称，无阈值调整或额外采样。',
'', '## 文件索引',
'- policy.json / SOURCE_FREEZE.json / PRECHECK.json：事前固定方案、源码hash及边界检查',
'- DATA_SEAL.json / inputs / entropy.bin：输入封存、16流与实验随机性（非凭证）',
'- trajectories：64个逐步原始结果；RESULTS、SEQUENCE_RESULTS、PAIRED_RESULTS、FAMILY_CONTRASTS及CSV：总量与配对结果',
'- EXIT_RECEIPT.json：真实退出和资源receipt；UPSTREAM_PASS.json及evidence：原48独审放行证据',
'- DELIVERY_MANIFEST.json：交包成员SHA256；外置DELIVERY_RECEIPT：最终zip hash及完整性检查',
'']
with (R/'REPORT_ZH.md').open('x') as f:f.write('\n'.join(lines))
# No archive exists under R; explicit immutable member list avoids self-inclusion.
files=[p for p in sorted(R.rglob('*')) if p.is_file() and '__pycache__' not in p.parts]
manifest={'files':{str(p.relative_to(R)):sha(p.read_bytes()) for p in files},'scope':'all delivery files before this manifest; archive and external receipt excluded','complete_trajectories':64,'missing_trajectories':0}
with (R/'DELIVERY_MANIFEST.json').open('x') as f:json.dump(manifest,f,indent=2)
files.append(R/'DELIVERY_MANIFEST.json');z=R.parent/'bpp_prefix_gate_drift_20261008_CLEAN.zip'
with zipfile.ZipFile(z,'x',compression=zipfile.ZIP_DEFLATED) as out:
 for p in files:out.write(p,p.relative_to(R))
with zipfile.ZipFile(z) as f:
 assert f.testzip() is None and len(f.namelist())==len(files)
 for n,h in manifest['files'].items():assert sha(f.read(n))==h
receipt={'status':'PASS','package':str(z),'sha256':sha(z.read_bytes()),'bytes':z.stat().st_size,'members':len(files),'manifest_sha256':sha((R/'DELIVERY_MANIFEST.json').read_bytes()),'all_manifest_members_verified':True,'scientific_runs':1,'trajectories':64,'new_candidate_runs_after_main':0,'created_unix':time.time()}
q=R.parent/'bpp_prefix_gate_drift_20261008_DELIVERY_RECEIPT.json'
with q.open('x') as f:json.dump(receipt,f,indent=2)
print(json.dumps(receipt))
