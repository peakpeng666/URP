import os,json,time,hashlib,hmac,pathlib,numpy as np
R=pathlib.Path(__file__).resolve().parent
canon=lambda x:json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(n,x):
 with (R/n).open('xb') as f:f.write(canon(x)+b'\n')
def draw(rng,family,n):
 if family=='W':return np.round(np.clip(45*rng.weibull(3,size=n),1,100)).astype(np.int64).tolist()
 assert family=='U';return rng.integers(1,101,size=n,dtype=np.int64).tolist()
def generate(rng,direction,cp):
 first,last=direction.split('_to_');return draw(rng,first,cp)+draw(rng,last,1000-cp)
def main():
 for n,h in json.loads((R/'SOURCE_FREEZE.json').read_text())['files'].items():assert sha((R/n).read_bytes())==h
 put('GENERATION_CLAIM.json',{'start':time.time(),'draws':1,'attempts':1})
 master=os.getrandom(32)
 with (R/'entropy.bin').open('xb') as f:f.write(master)
 p=json.loads((R/'policy.json').read_text());prior=set(json.loads((R/'exclusions.json').read_text())['hashes']);seen=set();entries=[]
 (R/'inputs').mkdir()
 for spec in p['sequences']:
  i=spec['sequence'];seed=int.from_bytes(hmac.new(master,b'prefix-drift-v1|'+sha((R/'policy.json').read_bytes()).encode()+b'|'+str(i).encode(),hashlib.sha256).digest()[:16],'big')
  items=generate(np.random.Generator(np.random.PCG64(seed)),spec['direction'],spec['change_after_item'])
  assert len(items)==1000 and all(type(x) is int and 1<=x<=100 for x in items)
  h=sha(canon(items));assert h not in prior and h not in seen,'Exact duplicate: STOP without replacement';seen.add(h)
  name=f'inputs/{i:02d}.json';put(name,{'items':items,'capacity':100});entries.append(dict(spec,path=name,items_sha256=h,file_sha256=sha((R/name).read_bytes())))
 put('DATA_SEAL.json',{'instances':entries,'source_freeze_sha256':sha((R/'SOURCE_FREEZE.json').read_bytes()),'entropy_sha256':sha(master),'no_performance_filter':True,'candidate_calls_before_seal':0,'generation_attempts':1,'plan':p['actions']})
 print('SEALED 16 fresh sequences; no scientific candidate evaluations')
if __name__=='__main__':main()
