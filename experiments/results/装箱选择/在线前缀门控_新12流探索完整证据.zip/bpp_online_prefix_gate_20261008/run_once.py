import json,pathlib,time,hashlib,resource,signal,os
from fractions import Fraction
from engine import pack
R=pathlib.Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(n,x):
 with (R/n).open('x') as f:json.dump(x,f,ensure_ascii=False,separators=(',',':'))
def main():
 put('RUN_CLAIM.json',{'pid':os.getpid(),'start_unix':time.time(),'attempt':1})
 for n,h in json.loads((R/'SOURCE_FREEZE.json').read_text())['files'].items():assert sha((R/n).read_bytes())==h,n
 s=json.loads((R/'DATA_SEAL.json').read_text());assert sha((R/'SOURCE_FREEZE.json').read_bytes())==s['source_freeze_sha256']
 (R/'trajectories').mkdir();rows=[]
 for a in s['plan']:
  e=s['instances'][a['sequence']];raw=(R/e['path']).read_bytes();assert sha(raw)==e['file_sha256'];items=json.loads(raw)['items']
  r=pack(items,a['arm']) # Every arm executes independently from an empty state.
  l1=(sum(items)+99)//100;f=Fraction(l1,r['used_bins'])
  r.update({'sequence':e['sequence'],'family':e['family'],'within_family':e['within_family'],'items_sha256':e['items_sha256'],'L1':l1,'F_exact':str(f),'F':float(f),'status':'ok'})
  put(f"trajectories/{e['sequence']:02d}_{a['arm']}.json",r)
  rows.append({k:r[k] for k in ['sequence','family','within_family','arm','used_bins','L1','F_exact','F','status','gate','resources']})
 put('RESULTS.json',rows);print(json.dumps({'status':'completed','trajectories':len(rows),'item_placements':48000}))
if __name__=='__main__':main()
