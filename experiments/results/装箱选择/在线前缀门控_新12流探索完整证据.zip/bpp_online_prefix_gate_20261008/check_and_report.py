"""Independent integer-only reconstruction, with no candidate import or execution."""
import pathlib,json,csv,hashlib
from fractions import Fraction
R=pathlib.Path(__file__).resolve().parent
read=lambda n:json.loads((R/n).read_text())
checks=[];rows=[];paired=[];summaries=[]
seal=read('DATA_SEAL.json')
for e in seal['instances']:
 items=read(e['path'])['items'];rr={}
 for arm in ['B','P','D','G']:
  p=R/f"trajectories/{e['sequence']:02d}_{arm}.json"
  if not p.exists():rr[arm]=None;continue
  r=json.loads(p.read_text());loads=[]
  assert len(r['events'])==len(items)==len(r['assignment'])==1000
  for k,(item,j,event) in enumerate(zip(items,r['assignment'],r['events']),1):
   assert type(j) is int and 0<=j<=len(loads)
   feasible_count=sum(x+item<=100 for x in loads)+(1000-len(loads))
   expected_method='P' if arm=='P' or (arm=='D' and k>64) or (arm=='G' and k>64 and sum(items[:64])<2880) else 'B'
   if expected_method=='B':
    feasible=[x for x,v in enumerate(loads) if v+item<=100]
    expected=min(feasible,key=lambda x:(100-loads[x],x)) if feasible else len(loads)
    assert j==expected
   if j==len(loads):loads.append(0)
   before=100-loads[j];loads[j]+=item;assert loads[j]<=100
   assert event=={'step':k,'item':item,'bin':j,'remaining_before':before,'remaining_after':100-loads[j],'method':expected_method,'feasible_count':feasible_count}
  assert len(loads)==r['used_bins'] and sum(loads)==sum(items)
  assert [100-x for x in loads]+[100]*(1000-len(loads))==r['remaining']
  f=Fraction((sum(items)+99)//100,len(loads));assert str(f)==r['F_exact'] and float(f)==r['F']
  if arm in ('D','G'):assert r['gate']['observed_prefix_sum']==sum(items[:64]) and r['gate']['switch']==(arm=='D' or sum(items[:64])<2880)
  rr[arm]=r;rows.append({k:r[k] for k in ['sequence','family','arm','used_bins','L1','F_exact','F']});checks.append({'sequence':e['sequence'],'arm':arm,'legal_steps':1000,'metric_verified':True})
 if all(rr.values()):
  for arm in ['D','G']:assert rr[arm]['events'][:64]==rr['B']['events'][:64]
  assert rr['G']['events']==rr['D' if sum(items[:64])<2880 else 'B']['events']
 p={'sequence':e['sequence'],'family':e['family'],'prefix64_sum':sum(items[:64]),'gate_switch':sum(items[:64])<2880}
 for arm in rr:
  p[arm+'_bins']=None if rr[arm] is None else rr[arm]['used_bins'];p[arm+'_F']=None if rr[arm] is None else rr[arm]['F_exact']
 for a,b in [('G','B'),('G','P'),('G','D'),('D','P')]:
  valid=rr[a] is not None and rr[b] is not None
  p[a+'-'+b+'_bins']=rr[a]['used_bins']-rr[b]['used_bins'] if valid else None
  p[a+'-'+b+'_F']=str(Fraction(rr[a]['F_exact'])-Fraction(rr[b]['F_exact'])) if valid else None
 paired.append(p)
for fam in read('policy.json')['families']:
 pp=[p for p in paired if p['family']==fam]
 for a,b in [('G','B'),('G','P'),('G','D'),('D','P')]:
  ds=[p[a+'-'+b+'_bins'] for p in pp];fs=[p[a+'-'+b+'_F'] for p in pp];valid=all(x is not None for x in ds)
  summaries.append({'family':fam,'contrast':a+'-'+b,'paired_bins':ds,'paired_F_exact':fs,'complete_pairs':sum(x is not None for x in ds),'missing_pairs':sum(x is None for x in ds),'mean_delta_bins':sum(ds)/4 if valid else None,'mean_delta_F_exact':str(sum(map(Fraction,fs),Fraction())/4) if valid else None,'wins_ties_losses': [sum(x<0 for x in ds),sum(x==0 for x in ds),sum(x>0 for x in ds)] if valid else None})
for name,data in [('SEQUENCE_RESULTS.json',rows),('PAIRED_RESULTS.json',paired),('FAMILY_CONTRASTS.json',summaries),('VALIDATION.json',{'status':'PASS','checks':checks,'independent_integer_reconstruction':True,'patch_scores_rerun':False,'complete_trajectories':len(checks),'identity_checks':'all BF prefixes equal; gate closed equals complete BF trace; gate open equals complete delayed trace'})]:
 with (R/name).open('x') as f:json.dump(data,f,indent=2,ensure_ascii=False)
for name,data in [('sequence_results.csv',rows),('paired_results.csv',paired),('family_contrasts.csv',summaries)]:
 with (R/name).open('x',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
print(json.dumps(summaries,ensure_ascii=False,indent=2))
