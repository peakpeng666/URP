import json,numpy as np
from engine import pack,choose
from pathlib import Path
R=Path(__file__).resolve().parent
out=[]
for s in [2879,2880,2881]:
 items=[45]*63+[s-45*63]+[55,45,100,1,99]
 r={a:pack(items,a) for a in ['B','P','D','G']}
 assert r['G']['gate']['switch']==(s<2880)
 assert r['G']['assignment']==r['D' if s<2880 else 'B']['assignment']
 assert r['G']['events']==r['D' if s<2880 else 'B']['events']
 for a in ['D','G']:assert r[a]['events'][:64]==r['B']['events'][:64]
 assert r['D']['events'][63]['method']=='B' and r['D']['events'][64]['method']=='P'
 assert r['G']['events'][64]['method']==('P' if s<2880 else 'B')
 out.append({'case':'sum'+str(s),'input':items,'trajectories':r,'passed':True})
for name,items,expected in [('capacity',[100,100,1],[0,1,2]),('exact_fit',[60,40],[0,0]),('tie',[60,60,40],[0,1,0]),('empty_mapping',[100,100,60,40],[0,1,2,2])]:
 r={a:pack(items,a) for a in ['B','P','D','G']}
 for a in r:assert r[a]['assignment']==expected
 out.append({'case':name,'input':items,'expected':expected,'trajectories':r,'passed':True})
assert choose(20,np.array([60.,30.,30.,100.]),'B')==1
assert choose(40,np.array([40.,40.,100.]),'P')==0
# Full original pool gives same first max as one representative empty for this elementwise patch.
assert choose(20,np.array([100.,100.,100.]),'P')==0
(R/'TOYS.json').write_text(json.dumps({'status':'PASS','cases':out,'extra_checks':['BF minimum feasible remainder tie lowest','patch exact-fit tie lowest','empty pool stable mapping']},indent=2))
print('PASS toys: three threshold boundaries,64/65,full-trace identities,capacity/exactfit/tie/empty mapping')
