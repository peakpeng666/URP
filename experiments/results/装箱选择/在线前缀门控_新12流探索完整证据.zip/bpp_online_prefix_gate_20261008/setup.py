import json, pathlib, hashlib, sys, numpy as np, shutil, time
R=pathlib.Path(__file__).resolve().parent
old=pathlib.Path('/workspace/shared/bpp_nearfit_distribution_20261008')
for name,path in {'d1_generate.py':old/'generate.py','d1_policy.json':old/'policy.json','d1_manifest.json':old/'data_manifest.json','d1_exclusions.json':old/'exclusions.json','classic_run.py':pathlib.Path('/workspace/shared/bpp_distribution_classic_baselines_20261008/run_once.py'),'original_runner.py':old/'frozen_runtime/runner.py'}.items():
 (R/'evidence').mkdir(exist_ok=True);shutil.copyfile(path,R/'evidence'/name)
m=json.loads((old/'methods.json').read_text())['methods']['EOH_nearfit_one']
assert hashlib.sha256(m['code'].encode()).hexdigest()==m['code_sha256']
(R/'patch.py').write_bytes(m['code'].encode())
ex=json.loads((old/'exclusions.json').read_text())['prior_1000_prefix_sha256']
ex+= [e['items_sha256'] for e in json.loads((old/'data_manifest.json').read_text())['instances']]
(R/'exclusions.json').write_text(json.dumps({'hashes':sorted(set(ex)),'scope':'39 known public/C1/A1/A2 prefixes plus 12 D1 arrays; exact canonical item-array equality only; no guarantee against unavailable historical data'},indent=2))
policy={'arms':['B','P','D','G'],'definition':{'B':'BF throughout','P':'unchanged r1+0.5 patch throughout','D':'BF first64 then patch from item65','G':'BF first64; switch to patch iff observed prefix sum <2880; equality stays BF'},'candidate_inputs':['item','feasible remaining bins in original index order'],'horizon':1000,'capacity':100,'prefix':64,'threshold':2880,'threshold_origin':'64/45 inspired by already observed D1; fixed exploratory rule, not calibration or independent confirmation of entire adaptive study','families':['weibull3_scale45','uniform_1_100','mixture_1_20_80_99'],'sequences_per_family':4,'actions':[{'sequence':i,'arm':a} for i in range(12) for a in ['B','P','D','G'][i%4:]+['B','P','D','G'][:i%4]],'metric':'F=ceil(sum(items)/100)/used_bins; exact Fraction; higher is better','contrasts':['G-B','G-P','G-D','D-P'],'missing':'Keep all4 slots per family; any missing yields null full4 contrast summary; stop on failure, no retries','scope':'No pooled analysis, tuning, classifier, CRC or general improvement claims','entropy':'one os.getrandom(32); HMAC-SHA256 per sequence; no replacement if exact duplicate','limits':{'CPU_seconds':180,'wall_seconds':240},'dependency':{'python':sys.version,'executable':sys.executable,'numpy':np.__version__},'patch_sha256':m['code_sha256']}
(R/'policy.json').write_text(json.dumps(policy,indent=2))
print('Setup complete; no candidate executed, no scientific input generated.')
