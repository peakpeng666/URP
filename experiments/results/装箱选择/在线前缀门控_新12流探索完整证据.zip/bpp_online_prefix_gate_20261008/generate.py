import os,json,time,hashlib,hmac,pathlib,numpy as np
R=pathlib.Path(__file__).resolve().parent
canon=lambda x:json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(n,x):
 with (R/n).open('xb') as f:f.write(canon(x)+b'\n')
f=json.loads((R/'SOURCE_FREEZE.json').read_text())
for n,h in f['files'].items():assert sha((R/n).read_bytes())==h
assert json.loads((R/'TOYS.json').read_text())['status']=='PASS'
put('GENERATION_CLAIM.json',{'start':time.time(),'draws':1,'attempts':1})
master=os.getrandom(32);(R/'entropy.bin').write_bytes(master)
p=json.loads((R/'policy.json').read_text());prior=set(json.loads((R/'exclusions.json').read_text())['hashes']);seen=set();entries=[]
(R/'inputs').mkdir()
for i in range(12):
 seed=int.from_bytes(hmac.new(master,b'online-prefix-gate-v1|'+sha((R/'policy.json').read_bytes()).encode()+b'|'+str(i).encode(),hashlib.sha256).digest()[:16],'big')
 rng=np.random.Generator(np.random.PCG64(seed));fam=p['families'][i//4]
 if i<4:items=np.round(np.clip(45*rng.weibull(3,size=1000),1,100)).astype(np.int64).tolist()
 elif i<8:items=rng.integers(1,101,size=1000,dtype=np.int64).tolist()
 else:
  component=rng.integers(0,2,size=1000,dtype=np.int64);offset=rng.integers(0,20,size=1000,dtype=np.int64);items=(offset+np.where(component==0,1,80)).tolist()
 h=sha(canon(items));assert h not in prior and h not in seen,'Exact duplicate: STOP without replacement';seen.add(h)
 name=f'inputs/{i:02d}.json';put(name,{'items':items,'capacity':100});entries.append({'sequence':i,'family':fam,'within_family':i%4,'path':name,'items_sha256':h,'file_sha256':sha((R/name).read_bytes())})
put('DATA_SEAL.json',{'instances':entries,'source_freeze_sha256':sha((R/'SOURCE_FREEZE.json').read_bytes()),'entropy_sha256':sha(master),'no_performance_filter':True,'candidate_calls_before_seal':0,'generation_attempts':1,'plan':p['actions']})
print('SEALED 12 fresh sequences; no scientific candidate evaluations')
