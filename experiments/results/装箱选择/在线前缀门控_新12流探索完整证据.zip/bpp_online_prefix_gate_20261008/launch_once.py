import os,pathlib,json,time,resource,signal,sys
R=pathlib.Path(__file__).resolve().parent
with (R/'LAUNCH_CLAIM.json').open('x') as f:json.dump({'start':time.time(),'attempt':1,'CPU_limit':180,'wall_limit':240},f)
t=time.monotonic();pid=os.fork()
if pid==0:
 resource.setrlimit(resource.RLIMIT_CPU,(180,180));signal.alarm(240)
 out=os.open(R/'stdout.txt',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600);err=os.open(R/'stderr.txt',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 os.dup2(out,1);os.dup2(err,2)
 os.execve(sys.executable,[sys.executable,'-B',str(R/'run_once.py')],dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1'))
_,status,u=os.wait4(pid,0)
receipt={'pid':pid,'raw_wait_status':status,'exit_code':os.waitstatus_to_exitcode(status),'CPU_user':u.ru_utime,'CPU_system':u.ru_stime,'CPU_total':u.ru_utime+u.ru_stime,'wall_seconds':time.monotonic()-t,'maxrss_KiB':u.ru_maxrss,'CPU_limit_seconds':180,'wall_limit_seconds':240,'reaped':True,'retry':False,'status':'PASS' if status==0 else 'FAILED_STOP'}
with (R/'EXIT_RECEIPT.json').open('x') as f:json.dump(receipt,f,indent=2)
print(json.dumps(receipt));sys.exit(0 if status==0 else 1)
