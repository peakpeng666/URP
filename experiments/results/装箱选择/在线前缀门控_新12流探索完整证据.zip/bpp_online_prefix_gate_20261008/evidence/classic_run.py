"""Standard-library deterministic FF/BF supplement; one invocation, no old heuristic calls."""
import csv, hashlib, json, os, time
from pathlib import Path
from fractions import Fraction
ROOT=Path(__file__).resolve().parent
OLD=('EOH_original','EOH_nearfit_one','published_EoH')
def sha(b): return hashlib.sha256(b).hexdigest()
def canon(x): return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def put(n,x):
 p=ROOT/n;p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f: f.write(canon(x)+b'\n');f.flush();os.fsync(f.fileno())
def read(n): return json.loads((ROOT/n).read_text())
def pack(items,method,cap=100):
 loads=[];assignment=[];events=[]
 for step,item in enumerate(items):
  assert type(item) is int and 1<=item<=cap
  chosen=None
  for j,load in enumerate(loads):
   if load+item<=cap and (chosen is None or (method=='BF' and load>loads[chosen])):
    chosen=j
    if method=='FF':break
  if chosen is None: chosen=len(loads);loads.append(0)
  before=loads[chosen];loads[chosen]+=item;assignment.append(chosen)
  events.append({'step':step,'item':item,'bin':chosen,'load_before':before,'load_after':loads[chosen]})
 return {'assignment':assignment,'final_integer_loads':loads,'events':events,'used_bins':len(loads)}
def validate(items,a,claimed,events=None):
 assert len(a)==len(items)
 loads=[]
 for i,(item,j) in enumerate(zip(items,a)):
  assert type(j) is int and 0<=j<=len(loads)
  if j==len(loads):loads.append(0)
  before=loads[j];loads[j]+=item
  assert loads[j]<=100
  if events is not None:assert events[i]=={'step':i,'item':item,'bin':j,'load_before':before,'load_after':loads[j]}
 assert len(loads)==claimed and all(0<x<=100 for x in loads) and sum(loads)==sum(items)
 return loads
def writecsv(name,rows):
 with (ROOT/name).open('x',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def main():
 put('RUN_CLAIM.json',{'pid':os.getpid(),'started_unix':time.time(),'max_new_trajectories':24,'no_retries':True})
 freeze=read('PREEXECUTION_FREEZE.json')
 for n,h in freeze['files'].items():assert sha((ROOT/n).read_bytes())==h,n
 toy=[]
 cases=[('exact_fit',[60,40],[0,0],[0,0]),('forced_new_bin',[60,50],[0,1],[0,1]),('tie_lowest',[60,60,40],[0,1,0],[0,1,0]),('capacity100',[100,100,1],[0,1,2],[0,1,2]),('ff_bf_divergence',[40,70,20],[0,1,0],[0,1,1])]
 for name,items,ff,bf in cases:
  for m,expected in [('FF',ff),('BF',bf)]:
   r=pack(items,m);assert r['assignment']==expected;validate(items,r['assignment'],r['used_bins'],r['events']);toy.append({'case':name,'method':m,'input':items,'expected':expected,'observed':r['assignment'],'passed':True})
 put('TOY_CHECKS.json',toy)
 manifest=read('evidence/data_manifest.json');rows=[];checks=[]
 existing=list(csv.DictReader((ROOT/'evidence/sequence_method_results.csv').open()))
 for e in manifest['instances']:
  idx=e['sequence_index'];data=read(f'inputs/{idx:02d}.json');items=data['items'];assert data['capacity']==100 and len(items)==1000
  assert sha((ROOT/f'inputs/{idx:02d}.json').read_bytes())==e['file_sha256'];assert sha(canon(data))==e['input_sha256'];assert sha(canon(items))==e['items_sha256']
  l1=(sum(items)+99)//100
  for m in ('FF','BF'):
   r=pack(items,m);loads=validate(items,r['assignment'],r['used_bins'],r['events']);assert loads==r['final_integer_loads'];f=Fraction(l1,r['used_bins'])
   r.update({'method':m,'sequence_index':idx,'family':e['family'],'family_sequence_index':e['family_sequence_index'],'n':1000,'capacity':100,'L1':l1,'F_numerator':f.numerator,'F_denominator':f.denominator,'input_sha256':e['input_sha256'],'input_file_sha256':e['file_sha256'],'implementation_sha256':freeze['files']['run_once.py'],'c1_source_code_sha256':read('evidence/C1_baseline_definitions.json')[m]['code_sha256']})
   put(f'trajectories/{idx:02d}_{m}.json',r)
   rows.append({k:r[k] for k in ('family','family_sequence_index','sequence_index','method','L1','used_bins','F_numerator','F_denominator')})
  for m in OLD:
   p=read(f'evidence/old_payloads/{idx:02d}_{m}.json');raw=p['original_pack_report']['result'];assert p['input_sha256']==e['input_sha256'] and p['outcome']=='ok' and p['checker']['checker_status']=='passed'
   loads=validate(items,raw['assignment'],raw['used_bins']);assert [100-x for x in loads]+[100]*(1000-len(loads))==raw['remaining']
   f=Fraction(l1,len(loads));er=next(x for x in existing if int(x['global_sequence_index'])==idx and x['method']==m)
   assert int(er['used_bins'])==len(loads) and Fraction(int(er['F_numerator']),int(er['F_denominator']))==f and int(er['L1'])==l1
   rows.append({'family':e['family'],'family_sequence_index':e['family_sequence_index'],'sequence_index':idx,'method':m,'L1':l1,'used_bins':len(loads),'F_numerator':f.numerator,'F_denominator':f.denominator})
   checks.append({'sequence_index':idx,'method':m,'status':'existing assignment reconstructed; no heuristic execution','used_bins':len(loads)})
 writecsv('all60_sequence_results.csv',rows)
 families=[];contrasts=[]
 for family in dict.fromkeys(r['family'] for r in rows):
  rr=[r for r in rows if r['family']==family]
  for m in ('FF','BF')+OLD:
   mm=[r for r in rr if r['method']==m];f=sum((Fraction(r['F_numerator'],r['F_denominator']) for r in mm),Fraction())/4
   families.append({'family':family,'method':m,'n_sequences':4,'bins_in_order':','.join(str(r['used_bins']) for r in mm),'mean_bins':sum(r['used_bins'] for r in mm)/4,'mean_F_exact':str(f),'mean_F_decimal':float(f)})
  for b in ('FF','BF'):
   bm=[r for r in rr if r['method']==b]
   for m in OLD:
    om=[r for r in rr if r['method']==m];ds=[o['used_bins']-b0['used_bins'] for o,b0 in zip(om,bm)]
    df=sum((Fraction(o['F_numerator'],o['F_denominator'])-Fraction(b0['F_numerator'],b0['F_denominator']) for o,b0 in zip(om,bm)),Fraction())/4
    contrasts.append({'family':family,'method':m,'baseline':b,'delta_bins_method_minus_baseline':','.join(map(str,ds)),'wins_ties_losses_by_bins':f'{sum(d<0 for d in ds)}/{sum(d==0 for d in ds)}/{sum(d>0 for d in ds)}','mean_delta_bins':sum(ds)/4,'mean_delta_F_exact':str(df),'mean_delta_F_decimal':float(df)})
 writecsv('family_summary.csv',families);writecsv('family_contrasts.csv',contrasts)
 unchanged={}
 for path,h in read('ORIGINAL_INPUT_HASHES.json').items():unchanged[path]=sha(Path(path).read_bytes())==h
 assert all(unchanged.values())
 put('VALIDATION.json',{'new_trajectories':24,'old_trajectories_rerun':0,'new_legality_checks_passed':24,'old_reconstructions':checks,'original_inputs_unchanged':unchanged,'exact_metric':'F=ceil(sum(items)/100)/used_bins; arithmetic Fraction','status':'passed'})
 put('COMPLETION.json',{'status':'completed','new_trajectories':24,'retries':0,'old_heuristic_executions':0,'interpretation':'post-D1 supplemental classic baseline comparison, not new independent confirmation'})
 print(json.dumps({'family_summary':families,'family_contrasts':contrasts},ensure_ascii=False))
if __name__=='__main__':main()
