"""Frozen LOFO analysis from legal archived outcomes; no policy/selector module execution."""
import json,pathlib,hashlib,time,datetime,collections
import numpy as np
H=pathlib.Path(__file__).resolve().parents[1]; S=H.parent/'independent_bpp_prefix_selection_20261006'
read=lambda p:json.loads(p.read_bytes()); canon=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
P=read(H/'PROTOCOL.json'); OP=read(S/'PROTOCOL.json'); OLD=read(S/'FREEZE.json'); B=['BF','BF_then_EoH']; evidence={}; phases=[]
def put(name,value):
    with (H/name).open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
def mark(name,func):
    c=time.process_time();w=time.monotonic();out=func();phases.append({'phase':name,'cpu_seconds':time.process_time()-c,'wall_seconds':time.monotonic()-w});return out
def hashrecord(rel,expected=None):
    v=sha(S/rel)
    if expected is not None:assert v==expected,(rel,'source hash mismatch')
    evidence[rel]=v;return v

def feature(items,state):
    p=np.array(items,dtype=np.int64);r=np.array(state,dtype=np.int64);used=r[r<100];d=np.diff(p)
    return np.r_[np.bincount((p-1)//10,minlength=10)/500,[p.mean()/100,p.std(ddof=0)/100],np.quantile(p,[.1,.5,.9],method='linear')/100,[np.mean(d>0),np.mean(d<0),(p[-100:].mean()-p[:100].mean())/100,len(used)/500],np.bincount(used//10,minlength=10)/len(used),[used.mean()/100,used.std(ddof=0)/100]]

def gate():
    for rel,dig in P['immutable_source_files'].items():hashrecord(rel,dig)
    audit=read(S/'independent_audit/RESULT_EVIDENCE_MANIFEST.json')['files']
    assert sha(S/'FREEZE.json')=='883780fb58189db4159a0e2c99b4c2db43b4b98a36ade8387b795973b5dc153a'
    rows=[];steps=0
    for meta in OP['instances']:
        if meta['split'] not in ['train','confirmation']:continue
        ident=meta['instance_id'];inp=f'inputs/{ident}.json';hashrecord(inp,OLD['files'][inp]);data=read(S/inp);items=data['items']
        assert len(items)==5000 and all(type(i)==int and 1<=i<=100 for i in items)
        rr=[];pp=[];ff=[]
        for method in B:
            rel=f'raw/{ident}__{method}.json';hashrecord(rel,audit[rel]);r=read(S/rel)
            assert r['instance_id']==ident and r['policy']==method and r['branch']==method and r['status']=='complete' and r['error'] is None and r['steps']==5000 and r['selector_consumed_count']==500
            assert r['items_sha256']==hashlib.sha256(canon(items).encode()).hexdigest()
            path=f'raw/{ident}__{method}.npz';assert r['trajectory_file']==path;hashrecord(path,r['trajectory_sha256']);assert evidence[path]==audit[path]
            with np.load(S/path,allow_pickle=False) as z:a={k:z[k].tolist() for k in z.files}
            assert set(a)=={'assignment','pre_remaining','post_remaining','feasible_counts','used_bins_after','remaining'} and all(len(v)==5000 for v in a.values())
            state=[100]*5000;counts=[0]*101;counts[100]=5000;used=0;prefix=None
            for j,(item,t,bef,aft,fc,uc) in enumerate(zip(items,a['assignment'],a['pre_remaining'],a['post_remaining'],a['feasible_counts'],a['used_bins_after'])):
                assert type(t)==int and 0<=t<5000 and state[t]==bef and bef>=item and aft==bef-item and aft>=0
                assert fc==sum(counts[item:]);used+=bef==100;assert uc==used
                state[t]=aft;counts[bef]-=1;counts[aft]+=1
                if j==499:prefix=state.copy()
            assert state==a['remaining'] and used==r['used_bins']==sum(v<100 for v in state) and sum(100-v for v in state)==sum(items)
            assert hashlib.sha256(canon(prefix).encode()).hexdigest()==r['prefix_remaining_sha256']
            f=feature(items[:500],prefix);assert f.shape==(31,) and np.all(np.isfinite(f)) and np.allclose(f,r['prefix_features'],rtol=0,atol=1e-12)
            rr.append(r);ff.append(f);pp.append({k:a[k][:500] for k in a if k!='remaining'}|{'state':prefix});steps+=5000
        assert pp[0]==pp[1] and np.array_equal(ff[0],ff[1]) and rr[0]['prefix_remaining_sha256']==rr[1]['prefix_remaining_sha256']
        rows.append({**{k:meta[k] for k in ['instance_id','group_id','split','family','replicate','order']},'features':ff[0].tolist(),'costs':[r['used_bins'] for r in rr],'prefix_state_sha256':rr[0]['prefix_remaining_sha256']})
    assert len(rows)==252 and steps==2520000
    assert len({r['instance_id'] for r in rows})==252
    put('audit/COUNTERFACTUAL_SUFFICIENCY.json',{'passed':True,'streams':252,'complete_legal_branches':504,'integer_replayed_steps':steps,'common_first500_arrays_and_state':True,'prefix_only_features_recomputed':252,'scores_reexecuted':False,'policy_reruns':0,'basis':'Original audited deterministic branch runs, identical BF500 state and same full input, with all outcome/trajectory hashes pinned to original audit; branch costs exactly support potential-outcome lookup for this one-switch policy class.','limitation':'This is archived counterfactual outcome lookup, not a newly executed deployed selector; original score first-argmax checks are inherited from original audit rather than rerun.'})
    put('analysis/SOURCE_PANEL.json',rows)
    return rows
rows=mark('source_hashes_integer_replay_and_features',gate)

def aggregate(rr):
    n=len(rr);avg=lambda k:sum(r[k] for r in rr)/n;ds=[r['selector_minus_SBS'] for r in rr];reg=[r['selector_regret'] for r in rr]
    head=avg('SBS_regret')
    return {'n':n,'mean_bins':{'selector':avg('selector_bins'),'SBS':avg('SBS_bins'),'branch_oracle':avg('oracle_bins'),'BF':sum(r['costs'][0] for r in rr)/n,'BF_then_EoH':sum(r['costs'][1] for r in rr)/n},'selector_minus_SBS_mean':sum(ds)/n,'selector_oracle_regret_mean':sum(reg)/n,'selector_oracle_regret_max':max(reg),'SBS_oracle_headroom_mean':head,'headroom_recovered_fraction':None if head==0 else (head-sum(reg)/n)/head,'worst_harm_vs_SBS':max(ds),'best_gain_vs_SBS':-min(ds),'W_T_L_vs_SBS':[sum(d<0 for d in ds),sum(d==0 for d in ds),sum(d>0 for d in ds)],'switch_to_EoH_count':sum(r['selected_index']==1 for r in rr),'switch_to_EoH_frequency':sum(r['selected_index']==1 for r in rr)/n,'different_from_SBS_count':sum(r['selected_index']!=r['sbs_index'] for r in rr),'different_from_SBS_frequency':sum(r['selected_index']!=r['sbs_index'] for r in rr)/n,'worst_regret_instances':[r['instance_id'] for r in rr if r['selector_regret']==max(reg)],'worst_harm_instances':[r['instance_id'] for r in rr if r['selector_minus_SBS']==max(ds)]}

def analyze():
    models=[];preds=[]
    for fam in P['families']:
        train=[r for r in rows if r['split']=='train' and r['family']!=fam];test=[r for r in rows if r['split']=='confirmation' and r['family']==fam]
        assert len(train)==120 and len(test)==18 and len({r['family'] for r in train})==5 and all(r['family']!=fam for r in train)
        assert not ({r['group_id'] for r in train}&{r['group_id'] for r in test})
        x=np.array([r['features'] for r in train]);y=np.array([r['costs'] for r in train]);mu=x.mean(0);scale=x.std(0,ddof=0);scale=np.where(scale==0,1.,scale);z=(x-mu)/scale;sbs=int(np.argmin(y.mean(0)))
        model={'heldout_family':fam,'train_ids':[r['instance_id'] for r in train],'train_families':sorted({r['family'] for r in train}),'mean':mu.tolist(),'scale':scale.tolist(),'x':z.tolist(),'y':y.tolist(),'training_mean_costs':y.mean(0).tolist(),'sbs_index':sbs,'sbs_branch':B[sbs],'k':5};models.append(model)
        for r in test:
            f=np.array(r['features']);zz=(f-mu)/scale;d=np.sum((z-zz)**2,axis=1);nn=np.argsort(d,kind='stable')[:5];pc=y[nn].mean(0);ix=sbs if pc[0]==pc[1] else int(np.argmin(pc));cost=r['costs'];oracle=min(cost)
            preds.append({**{k:r[k] for k in ['instance_id','group_id','family','replicate','order','features','costs']},'heldout_family':fam,'neighbor_indices':nn.tolist(),'neighbor_ids':[train[i]['instance_id'] for i in nn],'squared_distances':d[nn].tolist(),'predicted_costs':pc.tolist(),'prediction_tie':bool(pc[0]==pc[1]),'selected_index':ix,'selected_branch':B[ix],'sbs_index':sbs,'sbs_branch':B[sbs],'selector_bins':cost[ix],'SBS_bins':cost[sbs],'oracle_bins':oracle,'selector_minus_SBS':cost[ix]-cost[sbs],'selector_regret':cost[ix]-oracle,'SBS_regret':cost[sbs]-oracle})
    assert len(preds)==108 and len({r['instance_id'] for r in preds})==108
    result={'schema':'lofo-bpp-replay-results-v1','interpretation':P['status'],'primary_definition':P['primary'],'models':models,'predictions':preds,'pooled':aggregate(preds),'per_family':[{ 'family':f,**aggregate([r for r in preds if r['family']==f])} for f in P['families']],'per_family_order':[{'family':f,'order':o,**aggregate([r for r in preds if r['family']==f and r['order']==o])} for f in P['families'] for o in P['orders']],'new_policy_runs':0,'new_generated_inputs':0,'new_model_API_calls':0}
    put('analysis/RESULTS.json',result);return result
result=mark('six_models_and_108_predictions_and_aggregation',analyze)
for rel,dig in evidence.items():assert sha(S/rel)==dig,rel
put('evidence/SOURCE_MANIFEST.json',{'source_directory':S.name,'files':evidence,'post_analysis_unchanged':True})
put('analysis/PHASE_TIMING.json',phases)
print(json.dumps({'pooled':result['pooled'],'per_family':result['per_family'],'phase_timing':phases},ensure_ascii=False,indent=2))
