import pathlib,json,datetime
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
H=pathlib.Path(__file__).resolve().parents[1];R=json.loads((H/'analysis/RESULTS.json').read_text());p=R['pooled'];ledger=json.loads((H/'resources/LEDGER.json').read_text())
labels={'weibull_3_45':'Weibull','uniform_1_100':'均匀整数','small_beta_2_5':'偏小 Beta','large_beta_5_2':'偏大 Beta','normal_50_15':'裁剪正态','bimodal_20_30_70_80':'双峰'}
parts=[('title','BPP前缀选择器留一分布族外推'),('meta','2026年10月6日  既有分支结果的离线反事实重放'),('h','结论'),('p','原同族平均收益未能延续到这次留族外推面板。六折合并结果比训练单一最佳分支更差，主要损失集中在裁剪正态与Weibull留出折。'),('p',f"六折合并108条流，选择器相对各折训练SBS的平均箱数差为{p['selector_minus_SBS_mean']:+.3f}箱，负值表示节省。选择器平均{p['mean_bins']['selector']:.3f}箱，SBS平均{p['mean_bins']['SBS']:.3f}箱。逐流胜／平／负为{'／'.join(map(str,p['W_T_L_vs_SBS']))}。"),('p',f"相对同一BF500前缀后的两条合法分支事后oracle，选择器平均后悔{p['selector_oracle_regret_mean']:.3f}箱、最坏{p['selector_oracle_regret_max']}箱；相对SBS最坏多{p['worst_harm_vs_SBS']}箱。BF后切换到EoH的频率为{p['switch_to_EoH_count']}/108（{p['switch_to_EoH_frequency']:.1%}），与该折SBS不同的选择为{p['different_from_SBS_count']}/108。"),('p','这是追加的探索性分析。我们已知原研究总体结果；本轮没有产生新流、执行新策略或获取盲测新资料，也不属于原研究预注册。结果只描述这六个已观察合成分布族之间的留族迁移，不能据此保证任意新分布表现。'),('h','冻结设计'),('p','每折剔除一个分布族，只用其余五族既有train中的120条流训练，并只在被剔除族的18条既有confirmation流评估。该族24条train流完全排除。六折覆盖原108条confirmation各一次；每个多重集的三种顺序保持在同一组。'),('p','保持31个合法前缀／BF状态特征、训练均值与总体标准差、零标准差置1、k=5、平方欧氏距离、等权代价回归。邻居并列按原训练行序，预测并列退回该折训练SBS；SBS并列选BF。未搜索超参数，也未按结果改方法。'),('table',''),('p','每族均为18条流。表中“后悔”为相对合法分支oracle的平均值；“最坏后悔”按单条流计。“切换”指BF前500项之后改用EoH，不是跨流切换。各折SBS及18个族×顺序单元完整记录在JSON中。'),('h','反事实结果为何可重放'),('p','只使用既有BF与BF后EoH两条完整5000步分支。已核对252条train／confirmation流的504条轨迹、2,520,000步整数状态、完整性和原审计哈希；每对分支前500步数组及残量状态完全一致，31维特征只来自这500项及状态。确定性分支在相同输入与相同切换状态下的归档最终箱数，足以支持本次一次切换选择的确切结果查表。'),('p','本轮不重新评分、不再运行策略；策略first-argmax正确性承接旧独立审计。我们验证归档和合法状态对应关系，不能把“重放所得选择结果”写成“本轮真实部署执行”。oracle仅取这两合法分支的最小值，未使用全程EoH充当oracle。'),('h','独立复核与资源边界'),('p','另一份不导入主分析的实现从原始记录重建前缀特征，独立重算六组标准化、训练标签、SBS、全部108条邻居、代价预测、分支选择及聚合，并检查留出族和确认资料不进入训练。详见独立审计JSON与源码。'),('p',f"预设前瞻总限为120 CPU秒，全部本轮数值、验证、报告制作与本地打包步骤通过同一计量入口，单线程，逐步记录CPU／墙时；每步计量器尾部另保守记0.05秒。报告生成前账面累计{ledger['accounted_cpu_seconds']:.3f} CPU秒；最终账本随交付归档。前期文件列举和文本阅读未计时，不被冒称为零或整体历史成本。旧研究900秒历史总预算无法认证的限制保持不变。"),('h','解释与后续使用'),('p','留一族使训练缺少该族，但确认流仍来自同一批已观察资料，且六折训练集高度重叠。三种顺序不是独立样本；合并平均是这张均衡合成面板的描述量，不附显著性或总体推广声明。应同时查看逐族差异、最坏风险与切换频率。'),('p','原同族选择器的平均差−21.454箱、平均oracle后悔2.880箱仅作背景，未用于选择LOFO方案。模型训练样本从144减到120且同时剔除一族，因此两者差异不能单独归因为“分布外”因素。两项分析均不得反馈到原132研究。')]
doc=Document();sec=doc.sections[0];sec.page_width=Inches(8.5);sec.page_height=Inches(11);sec.top_margin=Inches(.68);sec.bottom_margin=Inches(.65);sec.left_margin=sec.right_margin=Inches(.75)
for nm in ['Normal','Title','Subtitle','Heading 1','Heading 2']:
    s=doc.styles[nm];s.font.name='Noto Sans CJK SC';s._element.rPr.rFonts.set(qn('w:eastAsia'),'Noto Sans CJK SC');s.font.color.rgb=RGBColor(0,0,0)
    s.paragraph_format.space_after=Pt(6)
doc.styles['Normal'].font.size=Pt(10);doc.styles['Normal'].paragraph_format.line_spacing=1.15;doc.styles['Title'].font.size=Pt(21);doc.styles['Heading 1'].font.size=Pt(13)
for style in doc.styles:
    for border in list(style.element.iter(qn('w:pBdr'))):
        border.getparent().remove(border)
md=[]
for kind,text in parts:
    if kind=='title':doc.add_paragraph(text,'Title');md+=['# '+text,'']
    elif kind=='meta':doc.add_paragraph(text,'Subtitle');md += [text,'']
    elif kind=='h':doc.add_heading(text,1);md += ['## '+text,'']
    elif kind=='p':doc.add_paragraph(text);md += [text,'']
    else:
        head=['留出分布族','选择器−SBS','后悔','最坏后悔','切换／18'];tab=doc.add_table(rows=1,cols=5);tab.autofit=False; widths=[1.5,1.5,1.15,1.1,1.0]
        for i,h in enumerate(head):tab.rows[0].cells[i].text=h;tab.columns[i].width=Inches(widths[i])
        for x in R['per_family']:
            vals=[labels[x['family']],f"{x['selector_minus_SBS_mean']:+.3f}",f"{x['selector_oracle_regret_mean']:.3f}",str(x['selector_oracle_regret_max']),str(x['switch_to_EoH_count'])+'/18']
            for c,t in zip(tab.add_row().cells,vals):c.text=t
        for rowi,row in enumerate(tab.rows):
            for c in row.cells:
                pr=c._tc.get_or_add_tcPr();borders=OxmlElement('w:tcBorders')
                for edge in ['top','left','bottom','right']:
                    e=OxmlElement('w:'+edge);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'4');e.set(qn('w:color'),'D9D9D9');borders.append(e)
                pr.append(borders)
                if rowi==0:
                    fill=OxmlElement('w:shd');fill.set(qn('w:fill'),'DCEAF5');pr.append(fill)
                for pp in c.paragraphs:
                    pp.paragraph_format.space_after=Pt(5);pp.paragraph_format.space_before=Pt(5)
                    for run in pp.runs:run.font.size=Pt(9);run.bold=rowi==0
        md+=[' | '.join(head),' | '.join(['---']*5)]
        for x in R['per_family']:md+=[' | '.join([labels[x['family']],f"{x['selector_minus_SBS_mean']:+.3f}",f"{x['selector_oracle_regret_mean']:.3f}",str(x['selector_oracle_regret_max']),str(x['switch_to_EoH_count'])+'/18'])]
        md+=['']
(H/'REPORT_ZH.md').write_text('\n'.join(md));doc.save(H/'BPP前缀选择器留族外推分析.docx');print('Report DOCX and Markdown created')
