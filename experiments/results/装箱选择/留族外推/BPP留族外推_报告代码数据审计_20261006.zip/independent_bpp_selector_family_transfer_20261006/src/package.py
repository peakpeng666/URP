import pathlib,json,hashlib,zipfile,datetime
H=pathlib.Path(__file__).resolve().parents[1];S=H.parent/'independent_bpp_prefix_selection_20261006';D=H.parent/(H.name+'_delivery');D.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest(); files={}; payload={}
for p in sorted(H.rglob('*')):
    if p.is_file() and not any(part.startswith('rendered') for part in p.parts) and p.name not in ['MANIFEST.json','POOL.lock'] and '__pycache__' not in p.parts:
        data=p.read_bytes();k=str(p.relative_to(H.parent));files[k]={'bytes':len(data),'sha256':sha(data)};payload[k]=data
src=json.loads((H/'evidence/SOURCE_MANIFEST.json').read_text())['files']
for rel,dig in src.items():
    p=S/rel;data=p.read_bytes();assert sha(data)==dig;key=str(p.relative_to(H.parent));files[key]={'bytes':len(data),'sha256':dig};payload[key]=data
manifest={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'New offline analysis plus required immutable original scientific subset, no policy execution.','files':files,'ledger_boundary':'The packaged LEDGER predates this packaging step and the final delivery readback. Final outer resource receipt accompanies delivery separately.'}
raw=json.dumps(manifest,ensure_ascii=False,indent=2).encode()+b'\n';(H/'MANIFEST.json').write_bytes(raw);payload[H.name+'/MANIFEST.json']=raw
out=D/'BPP留族外推_报告代码数据审计_20261006.zip'
with zipfile.ZipFile(out,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for k,b in payload.items():z.writestr(k,b)
with zipfile.ZipFile(out) as z:
    assert set(z.namelist())==set(payload)
    for k,v in files.items():assert sha(z.read(k))==v['sha256']
r={'file':str(out),'bytes':out.stat().st_size,'sha256':sha(out.read_bytes()),'manifest_entries':len(files),'archive_members':len(payload),'all_zip_members_readback_hash_verified':True}
(D/'PACKAGE_VERIFICATION.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
