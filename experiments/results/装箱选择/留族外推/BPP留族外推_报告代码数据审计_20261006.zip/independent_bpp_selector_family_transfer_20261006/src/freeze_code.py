import pathlib,json,hashlib,datetime
H=pathlib.Path(__file__).resolve().parents[1]; files=['PROTOCOL.json','PREEXEC_FREEZE.json','src/meter.py','src/analyze.py','audit/verify_independent.py']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
record={'before_analysis':True,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':{p:sha(H/p) for p in files}}
with (H/'ANALYSIS_CODE_FREEZE.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps(record,indent=2))
