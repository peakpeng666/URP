"""Prospective shared 120 CPU-second pool; all numerical/validation child stages use this."""
import sys, os, time, json, resource, subprocess, pathlib, math, fcntl, datetime
H=pathlib.Path(__file__).resolve().parents[1]
lock=(H/'resources/POOL.lock').open('a'); fcntl.flock(lock,fcntl.LOCK_EX)
ledger_path=H/'resources/LEDGER.json'
ledger=json.loads(ledger_path.read_text()) if ledger_path.exists() else {'limit_cpu_seconds':120.,'stages':[],'scope':'All new numerical, validation, artifact production and local packaging stages plus their metering processes. Prior text reading/tool orchestration is not measured and is not represented as zero.'}
prior=sum(s['accounted_cpu_seconds'] for s in ledger['stages']); remaining=120-prior
stage=sys.argv[1]; command=sys.argv[2:]; reserve=2.; cap=math.floor(remaining-reserve)
if cap<1:raise SystemExit('No remaining prospective CPU pool')
start=time.monotonic(); stamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
def preexec():
    os.setsid(); resource.setrlimit(resource.RLIMIT_CPU,(cap,cap))
proc=subprocess.Popen(command,env=env,preexec_fn=preexec,stdout=(H/'resources'/f'{stage}.log').open('wb'),stderr=subprocess.STDOUT)
# Guard the single child and any descendants; all stages must remain in its process group.
def group_cpu():
    total=0.; ticks=os.sysconf('SC_CLK_TCK')
    for p in pathlib.Path('/proc').iterdir():
        if p.name.isdigit():
            try:
                s=(p/'stat').read_text().rsplit(')',1)[1].split()
                if int(s[2])==proc.pid:total+=(int(s[11])+int(s[12]))/ticks
            except (FileNotFoundError,ProcessLookupError,PermissionError,ValueError):pass
    return total
killed=False
while proc.poll() is None:
    used=resource.getrusage(resource.RUSAGE_SELF); selfcpu=used.ru_utime+used.ru_stime
    if group_cpu()+selfcpu>=remaining-0.5:
        os.killpg(proc.pid,9); killed=True; break
    time.sleep(.02)
rc=proc.wait(); child=resource.getrusage(resource.RUSAGE_CHILDREN); own=resource.getrusage(resource.RUSAGE_SELF)
cpu_child=child.ru_utime+child.ru_stime; cpu_self=own.ru_utime+own.ru_stime
row={'stage':stage,'started_utc':stamp,'command':command,'exit_code':rc,'wall_seconds':time.monotonic()-start,'child_cpu_seconds':cpu_child,'meter_cpu_seconds':cpu_self,'accounted_cpu_seconds':cpu_child+cpu_self,'previous_pool_spend_seconds':prior,'child_RLIMIT_CPU_seconds':cap,'pool_limit_cpu_seconds':120,'killed_by_guard':killed,'single_thread':True,'accounting_tail_reserve_seconds':0.05}
# Charge a prospective conservative reserve for the final JSON write and process shutdown.
row['accounted_cpu_seconds']+=.05
ledger['stages'].append(row); ledger['accounted_cpu_seconds']=sum(x['accounted_cpu_seconds'] for x in ledger['stages']); ledger['remaining_cpu_seconds']=120-ledger['accounted_cpu_seconds']
ledger_path.write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n'); print(json.dumps(row,ensure_ascii=False)); print((H/'resources'/f'{stage}.log').read_text()[-15000:])
assert ledger['accounted_cpu_seconds']<=120
sys.exit(rc if rc>=0 else 128-rc)
