import json,pathlib,hashlib,zipfile,xml.etree.ElementTree as ET
H=pathlib.Path(__file__).resolve().parents[1];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();r=json.loads((H/'analysis/RESULTS.json').read_text());a=json.loads((H/'audit/INDEPENDENT_AUDIT.json').read_text())
assert a['passed'] and a['all_six_models_recomputed'] and a['all_108_predictions_recomputed']
freeze=json.loads((H/'ANALYSIS_CODE_FREEZE.json').read_text())
for rel,d in freeze['files'].items():assert sha(H/rel)==d
with zipfile.ZipFile(H/'BPP前缀选择器留族外推分析.docx') as z:
    root=ET.fromstring(z.read('word/document.xml'));ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'};text=''.join(root.itertext())
    assert all(x in text for x in ['+30.519','54.852','622','35／53／20','46/108','62/108','120 CPU秒','2,520,000','非'] if x!='非')
    table=root.find('.//w:tbl',ns);trs=table.findall('w:tr',ns);assert len(trs)==7
    for tr,f in zip(trs[1:],r['per_family']):
        texts=[''.join(t.itertext()) for t in tr.findall('w:tc',ns)]
        for value in [f"{f['selector_minus_SBS_mean']:+.3f}",f"{f['selector_oracle_regret_mean']:.3f}",str(f['selector_oracle_regret_max']),str(f['switch_to_EoH_count'])+'/18']:assert any(value==s for s in texts),(value,texts)
    assert not root.findall('.//w:ins',ns) and not root.findall('.//w:del',ns)
    styles=ET.fromstring(z.read('word/styles.xml'));assert not styles.findall('.//w:pBdr',ns)
assert len(list((H/'rendered_final').glob('page-*.png')))==2
final={'passed':True,'report_docx_sha256':sha(H/'BPP前缀选择器留族外推分析.docx'),'report_markdown_sha256':sha(H/'REPORT_ZH.md'),'science_code_freeze_unchanged':True,'independent_scientific_audit_passed':True,'six_family_numeric_table_checked':True,'all_headline_numbers_checked':True,'no_tracked_changes':True,'title_border_absent':True,'pages':2,'visual_review':'Author inspected both final PNG pages: CJK glyphs render; no clipping or overlap; six-row family table intact; body limits and historical-accounting disclosure legible.','report_only_render_revision':'Removed inherited Word title border; no changes to models, predictions, scientific protocol or frozen analysis code.','cpu_scope':'All local numerical/verification and document/package stages through meter; connector backend execution and image viewing are not locally metered. No claim of total LLM/tool infrastructure cost.'}
(H/'audit/DELIVERY_AUDIT.json').write_text(json.dumps(final,ensure_ascii=False,indent=2)+'\n');print(json.dumps(final,ensure_ascii=False,indent=2))
