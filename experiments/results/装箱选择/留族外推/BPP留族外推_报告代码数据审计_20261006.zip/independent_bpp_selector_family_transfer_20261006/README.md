# BPP 前缀选择器留一分布族外推

这是对既有 BF 与 BF_then_EoH 归档结果的追加离线反事实分析，非新真实策略执行、非原研究预注册、非盲新资料。

## 文件

- PROTOCOL.json 与 PREEXEC_FREEZE.json：先于本轮数值分析固定的设计。
- ANALYSIS_CODE_FREEZE.json：主分析及独立复核代码的执行前哈希。
- analysis/RESULTS.json：六个模型、108条预测、主指标、六族及18个族×顺序单元。
- analysis/SOURCE_PANEL.json：252条合法前缀特征与两分支代价标签。
- audit/COUNTERFACTUAL_SUFFICIENCY.json：504分支归档与完整状态重放结果。
- audit/verify_independent.py：不导入主实现的独立实现。
- resources/LEDGER.json：本次全部数值、验证、文档制作和本地打包阶段前瞻CPU账。每阶段0.05秒为尾部保守记账量，不是实测成本。
- evidence/SOURCE_MANIFEST.json：所读取旧科学文件的SHA256，旧目录未修改。

## 可复算范围

归档中同时包含原研究仅为本分析所需的源文件子集，保留原目录名 independent_bpp_prefix_selection_20261006；原研究完整归档另在同一Drive实验项目。解压可直接检查JSON、代码和哈希。

若要从零复算，请在新的工作区建立与本目录同名的新空分析目录，仅复制本轮src、audit/verify_independent.py、PROTOCOL.json、PREEXEC_FREEZE.json、ANALYSIS_CODE_FREEZE.json，并将原源子集放在同级原目录名下。不复制旧分析输出或旧resources账。

顺序执行（全部经计量器；不调用原prepare/run/selector）：

1. python src/meter.py analyze python src/analyze.py
2. python src/meter.py independent_verify python audit/verify_independent.py

每次复算独立拥有新前瞻120 CPU秒额度；这不是修改本次实测记录的许可。程序拒绝覆盖已有结果。无需联网、API、收费服务或生成任何新输入。Python主实现需要numpy；独立复核仅标准库。

六折只以原train的其余五族120行拟合。前缀特征和预测函数无分布族输入；族标签只用于离线划分折。留出族24条train行不会进入该折的标准化、模型、SBS或平局处理。全程EoH不参与本轮合法oracle。
