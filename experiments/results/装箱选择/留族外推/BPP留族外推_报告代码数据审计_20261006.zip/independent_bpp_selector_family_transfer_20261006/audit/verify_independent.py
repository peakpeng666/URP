"""Independent stdlib-only LOFO audit; execute only through src/meter.py.

No analysis implementation, policy module, NumPy, or model API is imported.
Source archive assignments are replayed as recorded, never recomputed by a policy.
Training models are completely constructed before any confirmation source is read.
Confirmation branch costs are used only after the prefix-only decision is fixed.
"""
import ast
import datetime
import hashlib
import io
import json
import math
import os
from pathlib import Path
import resource
import struct
import time
import zipfile

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT.parent / 'independent_bpp_prefix_selection_20261006'
BRANCHES = ['BF', 'BF_then_EoH']
TRACE_FIELDS = ['assignment', 'pre_remaining', 'post_remaining',
                'feasible_counts', 'used_bins_after', 'remaining']
CHECK_COUNTS = {'archives': 0, 'state_transition_steps': 0,
                'common_prefix_streams': 0, 'feature_vectors': 0,
                'compared_numeric_values': 0}
READ_EVIDENCE = {}
MAX_NUMERIC_ABS_ERROR = 0.0


def require(value, message):
    if not value:
        raise AssertionError(message)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False).encode()


def digest(blob):
    return hashlib.sha256(blob).hexdigest()


def read_bytes(path):
    resolved = path.resolve()
    allowed_local = resolved.is_relative_to(ROOT)
    allowed_source = (resolved == SOURCE / 'PROTOCOL.json' or
                      resolved.is_relative_to(SOURCE / 'raw') or
                      resolved.is_relative_to(SOURCE / 'inputs'))
    require(allowed_local or allowed_source, 'Read outside audit allowlist: ' + str(path))
    blob = resolved.read_bytes()
    READ_EVIDENCE[str(resolved.relative_to(ROOT.parent))] = digest(blob)
    return blob


def read_json(path):
    return json.loads(read_bytes(path))


def compare(expected, actual, context=''):
    global MAX_NUMERIC_ABS_ERROR
    if isinstance(expected, dict):
        require(isinstance(actual, dict) and set(expected) == set(actual),
                ('Dictionary keys', context, set(expected), set(actual)))
        for key, value in expected.items():
            compare(value, actual[key], context + '/' + key)
    elif isinstance(expected, list):
        require(isinstance(actual, list) and len(expected) == len(actual),
                ('List dimensions', context))
        for index, (a, b) in enumerate(zip(expected, actual)):
            compare(a, b, context + '/' + str(index))
    elif type(expected) is int:
        require(type(actual) in (int, float) and expected == actual,
                ('Integer mismatch', context, expected, actual))
    elif type(expected) is float:
        require(type(actual) in (int, float) and math.isfinite(actual),
                ('Non-finite or nonnumeric result', context, actual))
        error = abs(expected - actual)
        MAX_NUMERIC_ABS_ERROR = max(MAX_NUMERIC_ABS_ERROR, error)
        CHECK_COUNTS['compared_numeric_values'] += 1
        require(math.isclose(expected, actual, rel_tol=2e-11, abs_tol=2e-10),
                ('Numerical mismatch', context, expected, actual, error))
    else:
        require(expected == actual, ('Value mismatch', context, expected, actual))


def read_npy(blob):
    """Minimal safe NPY decoder for one-dimensional integer archive arrays."""
    require(blob[:6] == b'\x93NUMPY', 'NPY magic')
    major, minor = blob[6:8]
    require((major, minor) in ((1, 0), (2, 0), (3, 0)), 'NPY version')
    nbytes = 2 if major == 1 else 4
    header_size = int.from_bytes(blob[8:8+nbytes], 'little')
    offset = 8 + nbytes + header_size
    header = ast.literal_eval(blob[8+nbytes:offset].decode('latin1'))
    require(header['shape'] == (5000,) and header['fortran_order'] is False,
            ('NPY shape/order', header))
    dtype = header['descr']
    require(dtype in ('<i4', '<i8', '>i4', '>i8', '=i4', '=i8'), ('NPY dtype', dtype))
    endian = '<' if dtype[0] in '<=' else '>'
    code = 'i' if dtype[-1] == '4' else 'q'
    require(len(blob) - offset == 5000 * int(dtype[-1]), 'NPY payload length')
    return list(struct.unpack_from(endian + '5000' + code, blob, offset))


def read_archive(path, claimed_hash):
    blob = read_bytes(path)
    require(digest(blob) == claimed_hash, ('Archive hash', path.name))
    with zipfile.ZipFile(io.BytesIO(blob)) as archive:
        require(set(archive.namelist()) == {k + '.npy' for k in TRACE_FIELDS},
                ('NPZ members', path.name))
        data = {k: read_npy(archive.read(k + '.npy')) for k in TRACE_FIELDS}
    CHECK_COUNTS['archives'] += 1
    return data


def prefix_input(meta):
    """Only first 500 input values leave this function; suffix is never a feature."""
    data = read_json(SOURCE / 'inputs' / (meta['instance_id'] + '.json'))
    require(data['instance_id'] == meta['instance_id'], 'Input identity')
    require(len(data['items']) == 5000, 'Input complete length')
    prefix = data['items'][:500]
    require(all(type(v) is int and 1 <= v <= 100 for v in prefix), 'Prefix item range')
    return prefix


def replay_archive(meta, branch):
    ident = meta['instance_id']
    row = read_json(SOURCE / 'raw' / (ident + '__' + branch + '.json'))
    require(row['instance_id'] == ident and row['policy'] == branch and
            row['branch'] == branch and row['status'] == 'complete' and
            row['error'] is None and row['steps'] == 5000, ('Archived run status', ident, branch))
    require(row['selector_consumed_count'] == 500, ('Archived prefix boundary', ident, branch))
    relative = 'raw/' + ident + '__' + branch + '.npz'
    require(row['trajectory_file'] == relative, 'Archive path')
    trace = read_archive(SOURCE / relative, row['trajectory_sha256'])
    state = [100] * 5000
    used = 0
    prefix_state = None
    prefix = []
    for index in range(5000):
        target = trace['assignment'][index]
        before = trace['pre_remaining'][index]
        after = trace['post_remaining'][index]
        item = before - after
        require(0 <= target < 5000 and state[target] == before and
                0 <= after < before <= 100 and 1 <= item <= 100,
                ('State transition', ident, branch, index))
        used += int(before == 100)
        require(trace['used_bins_after'][index] == used,
                ('Used-bin trajectory', ident, branch, index))
        require(1 <= trace['feasible_counts'][index] <= 5000,
                ('Feasible count range', ident, branch, index))
        state[target] = after
        if index < 500:
            prefix.append(item)
        if index == 499:
            prefix_state = state.copy()
    require(state == trace['remaining'], ('Final residual state', ident, branch))
    require(used == row['used_bins'] == sum(v < 100 for v in state), 'Final bin label')
    require(digest(canonical(prefix_state)) == row['prefix_remaining_sha256'], 'Prefix state hash')
    CHECK_COUNTS['state_transition_steps'] += 5000
    return row, trace, prefix, prefix_state


def avg(values):
    return math.fsum(values) / len(values)


def pop_sd(values, center=None):
    if center is None:
        center = avg(values)
    return math.sqrt(math.fsum((value - center) ** 2 for value in values) / len(values))


def make_features(prefix, residuals):
    require(len(prefix) == 500 and len(residuals) == 5000, 'Feature input shape')
    ordered = sorted(prefix)
    used = [value for value in residuals if value < 100]
    require(len(used) > 0, 'Empty prefix bins')
    item_hist = [0] * 10
    for value in prefix:
        item_hist[(value - 1) // 10] += 1
    res_hist = [0] * 10
    for value in used:
        res_hist[value // 10] += 1
    def quantile(probability):
        location = 499 * probability
        low = math.floor(location)
        high = min(low + 1, 499)
        return (ordered[low] + (ordered[high] - ordered[low]) * (location - low)) / 100
    x = ([count / 500 for count in item_hist] +
         [avg(prefix) / 100, pop_sd(prefix) / 100] +
         [quantile(probability) for probability in (0.1, 0.5, 0.9)] +
         [sum(b > a for a, b in zip(prefix, prefix[1:])) / 499,
          sum(b < a for a, b in zip(prefix, prefix[1:])) / 499,
          (avg(prefix[-100:]) - avg(prefix[:100])) / 100,
          len(used) / 500] +
         [count / len(used) for count in res_hist] +
         [avg(used) / 100, pop_sd(used) / 100])
    require(len(x) == 31 and all(math.isfinite(v) for v in x), 'Feature output shape/range')
    CHECK_COUNTS['feature_vectors'] += 1
    return x


def load_stream(meta):
    require(meta['split'] in ('train', 'confirmation'), 'Forbidden source split')
    prefix = prefix_input(meta)
    rows, traces, prefixes, states = [], [], [], []
    for branch in BRANCHES:
        row, trace, rebuilt_prefix, state = replay_archive(meta, branch)
        require(rebuilt_prefix == prefix, ('Prefix input link', meta['instance_id'], branch))
        rows.append(row)
        traces.append(trace)
        prefixes.append(rebuilt_prefix)
        states.append(state)
    require(states[0] == states[1] and prefixes[0] == prefixes[1], 'Common BF500 state')
    require(rows[0]['items_sha256'] == rows[1]['items_sha256'], 'Legal branch input identity')
    for name in TRACE_FIELDS[:-1]:
        require(traces[0][name][:500] == traces[1][name][:500], ('Common prefix arrays', name))
    features = make_features(prefix, states[0])
    for row in rows:
        compare(features, row['prefix_features'], meta['instance_id'] + '/archived_features')
    CHECK_COUNTS['common_prefix_streams'] += 1
    return {'meta': meta, 'features': features,
            'labels': [row['used_bins'] for row in rows]}


def fit_fold(heldout, train_data):
    rows = [row for row in train_data if row['meta']['family'] != heldout]
    require(len(rows) == 120, ('Fold training row count', heldout))
    require(all(row['meta']['split'] == 'train' and row['meta']['family'] != heldout
                for row in rows), 'Heldout/confirmation training leakage')
    ids = [row['meta']['instance_id'] for row in rows]
    x = [row['features'] for row in rows]
    y = [row['labels'] for row in rows]
    mean = [avg([row[col] for row in x]) for col in range(31)]
    scale = [pop_sd([row[col] for row in x], mean[col]) or 1.0 for col in range(31)]
    z = [[(row[col] - mean[col]) / scale[col] for col in range(31)] for row in x]
    cost_mean = [avg([row[col] for row in y]) for col in range(2)]
    sbs = int(cost_mean[1] < cost_mean[0])
    return {'mean': mean, 'scale': scale, 'x': z, 'y': y,
            'sbs_index': sbs, 'k': 5, 'training_ids': ids,
            'training_mean_bins': cost_mean}


def prefix_decision(features, model):
    """This function cannot access source metadata, heldout labels, or future items."""
    normalized = [(value - mean) / scale for value, mean, scale in
                  zip(features, model['mean'], model['scale'])]
    distances = [math.fsum((a - b) ** 2 for a, b in zip(row, normalized))
                 for row in model['x']]
    neighbors = sorted(range(120), key=lambda index: (distances[index], index))[:5]
    prediction = [sum(model['y'][index][col] for index in neighbors) / 5 for col in range(2)]
    choice = (model['sbs_index'] if prediction[0] == prediction[1]
              else int(prediction[1] < prediction[0]))
    return {'features': features, 'neighbors': neighbors,
            'neighbor_ids': [model['training_ids'][index] for index in neighbors],
            'squared_distances': [distances[index] for index in neighbors],
            'predicted_final_bins': prediction, 'selected_index': choice,
            'selected_branch': BRANCHES[choice]}


def summarize(rows):
    delta = [row['selector_minus_SBS'] for row in rows]
    regret = [row['selector_regret'] for row in rows]
    sbs_regret = [row['SBS_regret'] for row in rows]
    n = len(rows)
    result = {
        'n': n,
        'mean_bins': {name: avg([row[name] for row in rows])
                      for name in ['BF', 'BF_then_EoH', 'SELECTOR', 'SBS', 'branch_oracle']},
        'selector_minus_SBS_mean': avg(delta),
        'selector_oracle_regret': avg(regret),
        'worst_selector_oracle_regret': max(regret),
        'SBS_oracle_headroom': avg(sbs_regret),
        'worst_harm_vs_SBS': max(delta),
        'best_gain_vs_SBS': -min(delta),
        'W_T_L_vs_SBS': [sum(v < 0 for v in delta), sum(v == 0 for v in delta), sum(v > 0 for v in delta)],
        'choices': {branch: sum(row['selected_branch'] == branch for row in rows) for branch in BRANCHES},
        'switch_frequency': sum(row['selected_branch'] == BRANCHES[1] for row in rows) / n,
        'differs_from_SBS_frequency': sum(row['selected_branch'] != row['sbs_branch'] for row in rows) / n,
        'best_case_ids': [row['instance_id'] for row in rows if row['selector_minus_SBS'] == min(delta)],
        'worst_case_ids': [row['instance_id'] for row in rows if row['selector_minus_SBS'] == max(delta)],
    }
    return result


# The main result schema adapter is appended before the pre-analysis code freeze.

def model_schema(heldout, model, training_meta):
    return {
        'heldout_family': heldout,
        'train_ids': model['training_ids'],
        'train_families': sorted({row['family'] for row in training_meta if row['family'] != heldout}),
        'mean': model['mean'], 'scale': model['scale'], 'x': model['x'], 'y': model['y'],
        'training_mean_costs': model['training_mean_bins'],
        'sbs_index': model['sbs_index'], 'sbs_branch': BRANCHES[model['sbs_index']], 'k': 5,
    }


def prediction_schema(stream, model, decision):
    meta = stream['meta']
    # The decision has already been finalized from the prefix alone. Labels are
    # now accessed to score the chosen archived branch and its legal comparators.
    costs = stream['labels']
    selected = decision['selected_index']
    sbs = model['sbs_index']
    oracle = min(costs)
    return {
        **{key: meta[key] for key in ['instance_id', 'group_id', 'family', 'replicate', 'order']},
        'features': decision['features'], 'costs': costs,
        'heldout_family': meta['family'],
        'neighbor_indices': decision['neighbors'], 'neighbor_ids': decision['neighbor_ids'],
        'squared_distances': decision['squared_distances'],
        'predicted_costs': decision['predicted_final_bins'],
        'prediction_tie': decision['predicted_final_bins'][0] == decision['predicted_final_bins'][1],
        'selected_index': selected, 'selected_branch': BRANCHES[selected],
        'sbs_index': sbs, 'sbs_branch': BRANCHES[sbs],
        'selector_bins': costs[selected], 'SBS_bins': costs[sbs], 'oracle_bins': oracle,
        'selector_minus_SBS': costs[selected] - costs[sbs],
        'selector_regret': costs[selected] - oracle, 'SBS_regret': costs[sbs] - oracle,
    }


def aggregate_schema(rows):
    # The internal aggregation uses a different row layout and explicit branch
    # names; this adapter maps the independently recomputed quantities to the
    # producer's externally specified JSON field names.
    converted = []
    for row in rows:
        converted.append({
            **row, 'BF': row['costs'][0], 'BF_then_EoH': row['costs'][1],
            'SELECTOR': row['selector_bins'], 'SBS': row['SBS_bins'],
            'branch_oracle': row['oracle_bins'],
        })
    summary = summarize(converted)
    switch_count = summary['choices']['BF_then_EoH']
    differs_count = sum(row['selected_branch'] != row['sbs_branch'] for row in rows)
    headroom = summary['SBS_oracle_headroom']
    regret = summary['selector_oracle_regret']
    means = summary['mean_bins']
    return {
        'n': summary['n'],
        'mean_bins': {'selector': means['SELECTOR'], 'SBS': means['SBS'],
                      'branch_oracle': means['branch_oracle'],
                      'BF': means['BF'], 'BF_then_EoH': means['BF_then_EoH']},
        'selector_minus_SBS_mean': summary['selector_minus_SBS_mean'],
        'selector_oracle_regret_mean': regret,
        'selector_oracle_regret_max': summary['worst_selector_oracle_regret'],
        'SBS_oracle_headroom_mean': headroom,
        'headroom_recovered_fraction': None if headroom == 0 else (headroom - regret) / headroom,
        'worst_harm_vs_SBS': summary['worst_harm_vs_SBS'],
        'best_gain_vs_SBS': summary['best_gain_vs_SBS'],
        'W_T_L_vs_SBS': summary['W_T_L_vs_SBS'],
        'switch_to_EoH_count': switch_count,
        'switch_to_EoH_frequency': summary['switch_frequency'],
        'different_from_SBS_count': differs_count,
        'different_from_SBS_frequency': summary['differs_from_SBS_frequency'],
        'worst_regret_instances': [row['instance_id'] for row in rows
                                   if row['selector_regret'] == summary['worst_selector_oracle_regret']],
        'worst_harm_instances': summary['worst_case_ids'],
    }


def assert_metered():
    # Independent numerical work is forbidden unless the exclusive shared pool
    # meter is the immediate parent. The parent applies the CPU limit and lock.
    parent_command = Path('/proc') / str(os.getppid()) / 'cmdline'
    arguments = parent_command.read_bytes().split(b'\0')
    meter = str(ROOT / 'src' / 'meter.py')
    require(any(arg and str(Path(os.fsdecode(arg)).resolve()) == meter for arg in arguments[1:]),
            'Run this verifier only via this task src/meter.py')
    require(all(os.environ.get(key) == '1' for key in
                ['OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'OMP_NUM_THREADS', 'NUMEXPR_NUM_THREADS']),
            'Expected single-thread environment')
    soft, hard = resource.getrlimit(resource.RLIMIT_CPU)
    require(0 < soft <= hard <= 120, 'Shared-pool CPU limit is missing')


def check_freeze():
    freeze_paths = [ROOT / 'PREEXEC_FREEZE.json', ROOT / 'ANALYSIS_CODE_FREEZE.json']
    for freeze_path in freeze_paths:
        frozen = read_json(freeze_path)
        for relative, expected_hash in frozen['files'].items():
            require(digest(read_bytes(ROOT / relative)) == expected_hash,
                    ('Frozen code/protocol hash', relative))
    require('audit/verify_independent.py' in read_json(freeze_paths[1])['files'],
            'Independent verifier was not frozen before analysis')


def main():
    assert_metered()
    started = time.process_time()
    check_freeze()
    protocol = read_json(ROOT / 'PROTOCOL.json')
    source_protocol = read_json(SOURCE / 'PROTOCOL.json')
    require(protocol['legal_branches'] == BRANCHES and protocol['folds'] == 6 and
            protocol['selector']['k'] == 5 and protocol['features']['count'] == 31,
            'Protocol selector specification')
    require(protocol['families'] == source_protocol['families'] and
            protocol['orders'] == source_protocol['orders'], 'Protocol family/order identity')
    require(protocol['prefix_items'] == source_protocol['switch_after'] == 500,
            'Prefix boundary protocol')
    families = protocol['families']
    orders = protocol['orders']
    train_meta = [row for row in source_protocol['instances'] if row['split'] == 'train']
    test_meta = [row for row in source_protocol['instances'] if row['split'] == 'confirmation']
    require(len(train_meta) == 144 and len(test_meta) == 108, 'Panel dimensions')
    train_ids = {row['instance_id'] for row in train_meta}
    test_ids = {row['instance_id'] for row in test_meta}
    require(len(train_ids) == 144 and len(test_ids) == 108 and not train_ids & test_ids,
            'Train/confirmation identity disjointness')
    require(not {row['group_id'] for row in train_meta} & {row['group_id'] for row in test_meta},
            'Grouped train/confirmation disjointness')
    for split_rows, expected_family_count in [(train_meta, 24), (test_meta, 18)]:
        for family in families:
            subset = [row for row in split_rows if row['family'] == family]
            require(len(subset) == expected_family_count, 'Family panel balance')
            groups = {}
            for row in subset:
                groups.setdefault(row['group_id'], []).append(row['order'])
            require(all(group_orders == orders for group_orders in groups.values()),
                    'Original within-group ordering or grouped split changed')

    # Every training archive is read first; no confirmation source has been read.
    training = [load_stream(meta) for meta in train_meta]
    require(all('confirmation_' not in path for path in READ_EVIDENCE),
            'Confirmation source was opened before fitting')
    independently_fitted = {family: fit_fold(family, training) for family in families}
    models = [model_schema(family, independently_fitted[family], train_meta) for family in families]
    before_confirmation_fingerprint = digest(canonical(models))
    leakage = []
    for family, model in zip(families, models):
        expected = [row['instance_id'] for row in train_meta if row['family'] != family]
        require(model['train_ids'] == expected, 'Stable fold training row order')
        require(len(model['x']) == len(model['y']) == len(model['train_ids']) == 120,
                'Model training dimensions')
        require(all(len(row) == 31 for row in model['x']) and all(len(row) == 2 for row in model['y']),
                'Model feature/label dimensions')
        heldout_ids = {row['instance_id'] for row in train_meta if row['family'] == family}
        require(not set(model['train_ids']) & (heldout_ids | test_ids), 'Fit leakage')
        require(set(model['train_families']) == set(families) - {family}, 'Fit family leakage')
        leakage.append({'heldout_family': family, 'training_rows': 120,
                        'heldout_train_rows_used': 0, 'confirmation_rows_used': 0,
                        'training_ids_match_original_order': True,
                        'scaling_labels_SBS_and_neighbors_train_only': True})

    predictions = []
    for family in families:
        model = independently_fitted[family]
        for meta in [row for row in test_meta if row['family'] == family]:
            stream = load_stream(meta)
            decision = prefix_decision(stream['features'], model)
            require(set(decision['neighbor_ids']) <= set(model['training_ids']), 'Neighbor leakage')
            predictions.append(prediction_schema(stream, model, decision))
    require(len(predictions) == 108 and {row['instance_id'] for row in predictions} == test_ids,
            'Confirmation predictions complete and unique')
    require(digest(canonical(models)) == before_confirmation_fingerprint,
            'Model changed after opening confirmation sources')
    independent = {
        'models': models,
        'predictions': predictions,
        'pooled': aggregate_schema(predictions),
        'per_family': [dict(family=family, **aggregate_schema(
            [row for row in predictions if row['family'] == family])) for family in families],
        'per_family_order': [dict(family=family, order=order, **aggregate_schema(
            [row for row in predictions if row['family'] == family and row['order'] == order]))
            for family in families for order in orders],
    }
    # The first read of producer results occurs only after all independent models,
    # decisions, realized outcomes, and aggregates are complete and fixed.
    result = read_json(ROOT / 'analysis' / 'RESULTS.json')
    for key, value in independent.items():
        compare(value, result[key], key)
    require(result['new_policy_runs'] == result['new_generated_inputs'] ==
            result['new_model_API_calls'] == 0, 'Unexpected new execution claims')
    require(CHECK_COUNTS['archives'] == 504 and
            CHECK_COUNTS['state_transition_steps'] == 2520000 and
            CHECK_COUNTS['common_prefix_streams'] == 252 and
            CHECK_COUNTS['feature_vectors'] == 252, 'Independent source coverage')
    check_freeze()
    # Verify every source read remains byte-identical at the end; all hashing is
    # inside the same metered subprocess and no source file is ever written.
    source_checks = 0
    for relative, expected_hash in list(READ_EVIDENCE.items()):
        path = ROOT.parent / relative
        if path.is_relative_to(SOURCE):
            require(digest(path.read_bytes()) == expected_hash, ('Source changed', relative))
            source_checks += 1
    report = {
        'schema': 'independent-stdlib-lofo-selector-audit-v1',
        'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'passed': True, 'stdlib_only': True, 'analysis_module_imported': False,
        'policy_executions': 0, 'input_generation': 0, 'model_API_calls': 0,
        'source_files_read_and_unchanged': source_checks,
        'all_six_models_recomputed': True, 'all_108_predictions_recomputed': True,
        'all_pooled_family_and_family_order_aggregates_recomputed': True,
        'training_models_fixed_before_confirmation_source_reads': True,
        'confirmation_prefixes_only_in_prediction': True,
        'future_item_statistics_used': False,
        'producer_results_read_after_independent_recomputation': True,
        'numerical_comparison_relative_tolerance': 2e-11,
        'numerical_comparison_absolute_tolerance': 2e-10,
        'maximum_numeric_absolute_difference': MAX_NUMERIC_ABS_ERROR,
        'model_fingerprint_before_confirmation': before_confirmation_fingerprint,
        'leakage_checks': leakage, 'checks': CHECK_COUNTS,
        'pooled': independent['pooled'], 'per_family': independent['per_family'],
        'independent_recomputation_sha256': digest(canonical(independent)),
        'verifier_sha256': digest(Path(__file__).read_bytes()),
        'internal_cpu_seconds_before_serialization': time.process_time() - started,
        'cpu_accounting': 'This full subprocess and its meter are charged to resources/LEDGER.json; internal CPU is not the total charge.',
    }
    for filename, value in [('INDEPENDENT_RECOMPUTATION.json', independent),
                            ('INDEPENDENT_AUDIT.json', report),
                            ('INDEPENDENT_SOURCE_MANIFEST.json', READ_EVIDENCE)]:
        with (ROOT / 'audit' / filename).open('x') as handle:
            json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
            handle.write('\n')
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
