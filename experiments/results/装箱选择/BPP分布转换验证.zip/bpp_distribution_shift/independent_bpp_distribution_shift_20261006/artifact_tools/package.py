"""Seal report and evidence after completed experiment. Never executes policies."""
from pathlib import Path
import json,hashlib,time
H=Path(__file__).resolve().parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
def put(name,value):
    with (H/name).open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
assert json.loads((H/'RUN_COMPLETE.json').read_text())['full_runs']==216
assert json.loads((H/'CHECK.json').read_text())['passed']
assert not (H/'RUN_FAILURE.json').exists()
for path,digest in json.loads((H/'FREEZE.json').read_text())['files'].items():assert sha(H/path)==digest
pages=list(sorted((H/'render_final').glob('page-*.png')));assert len(pages)==4
assert all(sha(p)==sha(H/'render'/p.name) for p in pages)
put('DOCUMENT_QA.json',{'passed':True,'completed_utc':now(),'pages':4,'docx_sha256':sha(H/'BPP冻结前缀选择器分布转换验证.docx'),'final_render_directory':'render_final','all_page_images_visually_inspected':True,'final4_page_images_byte_identical_to_inspected_pages':True,'no_clipping_overlap_missing_glyphs':True,'page_sha256':{p.name:sha(p) for p in pages},'prior_render_note':'render contains earlier five-page QA including a short final pointer-only page. That pointer moved to plain-text report/README; final artifact renders to four pages. Earlier QA preserved, not a final deliverable.'})
rows=[json.loads(p.read_text()) for p in sorted((H/'raw').glob('*.json'))]
cost={}
for policy in ['BF','BF_then_EoH','published_EoH','SELECTOR']:
    rr=[r for r in rows if r['policy']==policy]
    cost[policy]={'actual_full_runs':len(rr),'completed_steps':sum(r['steps'] for r in rr),'sum_cpu_loop_seconds':sum(r['cpu_loop_seconds'] for r in rr),'sum_cpu_policy_seconds':sum(r['cpu_policy_seconds'] for r in rr),'sum_cpu_selector_seconds':sum(r['cpu_selector_seconds'] for r in rr),'sum_cpu_instrument_feature_seconds':sum(r['cpu_instrument_feature_seconds'] for r in rr),'sum_cpu_total_including_serialization_seconds':sum(r['cpu_total_including_serialization_seconds'] for r in rr)}
put('resources/COST_BREAKDOWN.json',{'created_utc':now(),'per_policy':cost,'official_process':json.loads((H/'resources/PROCESS_RESOURCE.json').read_text()),'api_calls':0,'payments':0,'cost_scope':'Policy timers are nested, not additive to process total. Official process total also includes input generation, source hashing, verification and summary. Report rendering and external audit are separate. External audit reports its own measured resources.','failure_accounting':{'complete_runs':216,'failed_runs':0,'retries':0,'RUN_FAILURE_exists':False}})
(H/'README.txt').write_text('''BPP 冻结前缀选择器分布转换验证

结论：36条转换流平均比固定训练SBS多7.805556箱，7胜20平9负，最坏多69箱；18平稳对照平均省3.888889箱。它说明本次合成面板中，前500件的一次推荐会因未来分布变化失准。不得推广为所有转换都失效、统计显著、现实外部盲测或任意分布保证。

交付入口
- BPP冻结前缀选择器分布转换验证.docx：四页中文报告，已逐页视觉核验。
- REPORT_ZH.txt：同内容可检索纯文本及核查文件指引。
- PROTOCOL.json、CODE_SEED_FREEZE.json、FREEZE.json：看新策略结果前的协议、代码/seed和全部输入冻结。
- MODEL.json：原模型逐字节复制，SHA256 98991f0908867ff7de995b1e252d503c0180a5e74c67ac03d9444765fdede7ab。
- inputs：18个源抽样与54条真实输入。9配对/seed依赖块，36转换与18平稳分开；同前缀、时间点、双向流存在共享，不能视作54独立样本。
- raw：216次真实运行，每次一个JSON与NPZ，保留每步装箱轨迹及SELECTOR全部决策。
- analysis：全部54逐流成绩、36配对对照、12转换单元及6平稳单元；同BF500的branch oracle与全程EoH严格分开。
- CHECK.json：同进程独立标量score/整数状态的108万步全量核查与54决策核查。
- resources：一次正式子进程日志、CPU/wall/RSS及按策略成本。正式CPU57.950386秒；零付款/API调用/失败/重跑。
- evidence、sources、src：原模型/生成器/控制器/许可证出处与副本、原精确runner和selector、冻结新实验入口。
- MANIFEST.json：作者目录完整SHA256/字节清单；不包含清单自身，无递归自签。请在转存后重算校验。
- DOCUMENT_QA.json、render_final：最终四页QA证据。render为旧排版中间态，保留但不要作为最终报告发布。

外部独审
另目录 audit_bpp_distribution_shift_20261006 已再次完整验证216实跑、108万步、54决策、18同前缀组、输入和统计，CPU3.179856秒。数值独审PASS；最终交付完整性终审见该目录后续文件，不回写或改变作者数值冻结。

复核边界
本实验是在既有负例出现后新增并预冻结的合成时间分布变化面板，未重训练。复制源码保留原未调用的main/fit函数，实际入口只调用execute与choose，绝不调用fit。原作者入口设置一次运行保护，不可原地重跑；如另做复现实验，应建立新目录并另记预算、来源与输出。旧目录、旧768次实验和原研究成绩保持不变。当前交付为本地文件，未上传或共享外部。
''')
put('AUTHOR_COMPLETION.json',{'status':'complete','sealed_utc':now(),'numerical_complete':True,'document_qa_complete':True,'independent_numerical_audit':'passed; see sibling audit_bpp_distribution_shift_20261006/AUDIT_RESULT.json','delivery_audit':'separate sibling audit; not included in this author seal','full_runs':216,'model_unchanged':True,'frozen_files_verified':True,'api_calls':0,'payments':0,'failed_runs':0,'reruns':0,'uploaded_by_author':False})
files={str(p.relative_to(H)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(H.rglob('*')) if p.is_file() and p.name!='MANIFEST.json' and '__pycache__' not in p.parts}
put('MANIFEST.json',{'schema':'bpp-shift-author-delivery-manifest-v1','created_utc':now(),'file_count':len(files),'total_bytes':sum(v['bytes'] for v in files.values()),'excluded':['MANIFEST.json (self-reference)','__pycache__ (not generated)'],'scope':'All author directory files, including retained intermediate and final render QA. No independent audit directory copied here.','files':files})
print(json.dumps({'manifest_sha256':sha(H/'MANIFEST.json'),'file_count':len(files),'report_txt_sha256':sha(H/'REPORT_ZH.txt'),'report_docx_sha256':sha(H/'BPP冻结前缀选择器分布转换验证.docx')},ensure_ascii=False))
