"""Format completed, frozen scientific results. No experiment reruns or new statistics."""
import pathlib,json
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_CELL_VERTICAL_ALIGNMENT
H=pathlib.Path(__file__).resolve().parents[1]
s=json.loads((H/'analysis/SUMMARY.json').read_text());o=s['shift_only'];c=s['stationary_only'];p=json.loads((H/'PROTOCOL.json').read_text());r=json.loads((H/'resources/PROCESS_RESOURCE.json').read_text());check=json.loads((H/'CHECK.json').read_text())
names={pair['id']:f'P{i+1}' for i,pair in enumerate(p['pairs'])}
d=Document();sec=d.sections[0];sec.page_width=Inches(8.5);sec.page_height=Inches(11);sec.top_margin=sec.bottom_margin=Inches(.62);sec.left_margin=sec.right_margin=Inches(.62)
for name in ['Normal','Title','Heading 1','Heading 2']:
    st=d.styles[name];st.font.name='Noto Sans CJK SC';st.element.rPr.rFonts.set(qn('w:eastAsia'),'Noto Sans CJK SC');st.font.color.rgb=RGBColor(0,0,0)
d.styles['Normal'].font.size=Pt(10);d.styles['Normal'].paragraph_format.space_after=Pt(5);d.styles['Normal'].paragraph_format.line_spacing=1.12
d.styles['Title'].font.size=Pt(21);d.styles['Title'].paragraph_format.space_after=Pt(8)
d.styles['Heading 1'].font.size=Pt(13);d.styles['Heading 1'].paragraph_format.space_before=Pt(9);d.styles['Heading 1'].paragraph_format.space_after=Pt(5)
text=[]
def para(t,style=None):
    p0=d.add_paragraph(t,style);p0.paragraph_format.space_before=Pt(3);text.append(t)
def heading(t):para(t,'Heading 1')
def table(headers,rows,widths):
    t=d.add_table(rows=1,cols=len(headers));t.alignment=WD_TABLE_ALIGNMENT.CENTER;t.autofit=False
    for i,(h,w) in enumerate(zip(headers,widths)):t.columns[i].width=Inches(w);t.rows[0].cells[i].width=Inches(w);t.rows[0].cells[i].text=h
    repeat=OxmlElement('w:tblHeader');t.rows[0]._tr.get_or_add_trPr().append(repeat)
    for row in rows:
        cells=t.add_row().cells
        for i,v in enumerate(row):cells[i].text=str(v);cells[i].width=Inches(widths[i])
    for ri,row in enumerate(t.rows):
        for c in row.cells:
            c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            tcpr=c._tc.get_or_add_tcPr();b=OxmlElement('w:tcBorders')
            for edge in ['top','left','bottom','right']:
                e=OxmlElement('w:'+edge);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'4');e.set(qn('w:color'),'D9D9D9');b.append(e)
            tcpr.append(b);mar=OxmlElement('w:tcMar')
            for edge in ['top','left','bottom','right']:
                e=OxmlElement('w:'+edge);e.set(qn('w:w'),'65');e.set(qn('w:type'),'dxa');mar.append(e)
            tcpr.append(mar)
            if ri==0:
                sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'E7EDF3');tcpr.append(sh)
            for par in c.paragraphs:
                par.alignment=WD_ALIGN_PARAGRAPH.CENTER;par.paragraph_format.space_after=Pt(0);par.paragraph_format.line_spacing=1.02
                for run in par.runs:run.font.size=Pt(9);run.bold=ri==0
    text.append(' | '.join(headers));text.extend(' | '.join(map(str,x)) for x in rows)
para('BPP 冻结前缀选择器分布转换验证','Title')
para('2026年10月6日  36条转换流  18条平稳对照  216次真实运行')
heading('结论与适用边界')
para(f'看前500件后只选一次策略，不能保证后续分布改变时仍选对。在本次36条转换流中，SELECTOR比固定训练基线平均多用{o["mean_selector_minus_sbs"]:.2f}箱，7胜、20平、9负；最坏多69箱。对应18条平稳流平均省3.89箱，7胜、10平、1负，最坏多1箱。')
para('这是一项在已观察旧负例后提出、再冻结定义与新seed的合成时间分布变化验证。它复用原6种边际生成器，测试新的时序组合，不是新边际族发现或现实外部盲测。转换与平稳样本相关，不能据此宣称显著性。')
heading('对照口径')
para('每流5000件、容量100，原模型、31维特征、k=5及四种策略口径完全冻结，无训练、调参或补跑。SELECTOR先用BF装入500件，在第501件到达前选定BF或BF_then_EoH，之后不再更新。SBS为原训练集选定的BF_then_EoH。')
table(['策略或参照','转换流均值','平稳流均值'],[[label,f'{o["mean_bins"][key]:.3f}',f'{c["mean_bins"][key]:.3f}'] for key,label in [('BF','全程BF'),('BF_then_EoH','BF500后续EoH  固定SBS'),('published_EoH','全程published EoH'),('SELECTOR','冻结SELECTOR')]]+[['同BF500两分支事后oracle',f'{o["mean_branch_oracle_bins"]:.3f}',f'{c["mean_branch_oracle_bins"]:.3f}']],[4.0,1.6,1.6])
para('两类流含不同项目总量，不应比较其平均绝对箱数来估计转换损失。核心比较均在同一条流的策略之间完成。oracle仅取BF和BF_then_EoH的较小最终箱数，保持同BF500初态；全程EoH从第1件起不同，严格另列。')
para(f'转换流平均oracle后悔{o["mean_selector_regret"]:.3f}箱，平稳对照为{c["mean_selector_regret"]:.3f}箱。转换流中固定SBS本有平均{o["mean_sbs_regret"]:.3f}箱改善余地，选择器却反向增加7.806箱，因此headroom收回比为{o["headroom_recovered_fraction"]:.2%}；该比例不是装箱提效。')
d.add_page_break();heading('预先冻结的机制与流构造')
para('P1 小件与大件占比反转：A为100×Beta(2,5)，B为100×Beta(5,2)。P2 模态和离散程度改变：A为Normal(50,15)，B等概率取20至30或70至80的整数。P3 宽度和右侧质量改变：A为45×Weibull(shape=3)，B为Uniform整数1至100。P3同时改变均值、宽度与右侧质量，不是纯重尾或单变量因果对照。')
para('各生成器直接提取并执行原make函数，保持参数、裁剪到1至100及ties-to-even取整。每组/seed生成两条5000件源序列A、B，并按独立置换seed随机排列。转换A→B在t件后使用A[:t]+B[t:]，反向同理；t固定为500或2500。平稳对照是完整A和完整B。')
para('新seed根为202610069401、202610069402、202610069403。value_seed = 根 + 1000×配对索引0至2 + 100×端点索引0或1；permutation_seed = value_seed + 1000000。先冻结代码和seed，再冻结全部输入，通知独审后才执行。')
heading('全部转换单元')
para('每格3条流。差值为SELECTOR减固定SBS；负值表示省箱。最大后悔相对同BF500分支oracle。选择次数按BF/续EoH排列。')
rows=[]
for cell in s['shift_cells']:
    rows.append([names[cell['pair_id']]+' '+cell['direction'].replace('_to_','→'),cell['change_point'],f'{cell["mean_selector_minus_sbs"]:.2f}','/'.join(map(str,cell['wins_ties_losses'])),cell['worst_selector_regret'],f'{cell["selected_branch_counts"]["BF"]}/{cell["selected_branch_counts"]["BF_then_EoH"]}'])
table(['机制与方向','转换点','平均差值','胜/平/负','最大后悔','选择次数'],rows,[1.5,.9,1.2,1.1,1.2,1.3])
para('全部12格和54条流均保留。9个配对/seed块中每块6流，共用两条源序列与部分后缀；共有18个独立设seed的源抽样。不能把36转换流、18平稳流或54总流当作相互独立的样本；本次不做bootstrap、置信区间或显著性检验。')
d.add_page_break();heading('为何同一前缀会推荐失准')
para('18个原始端点各产生平稳、t500转换和t2500转换三条流，前500件完全一致。18组三元组的BF状态、特征、5个近邻、预测和选择全部一致；但36个转换相对其原分布平稳对照，15个严格oracle偏好发生翻转。后悔值增加17次、持平18次、降低1次；平均增加11.972箱，最大增加69箱。')
para('最坏例为P3第3个seed，先均匀后Weibull：同一前缀始终选BF。平稳均匀流BF为2577箱、SBS为2585箱，选择器省8箱；500件后转换时BF为2159箱、SBS为2090箱，选择器多69箱；2500件后转换时多46箱。这里比较的是每条流内部的策略差值，不是不同体积流之间的绝对箱数。')
para('上述三流完全相同的近邻索引为39、45、30、33、24，预测BF/续EoH最终箱数为2574.8/2587.0。这些预测仅来自旧训练近邻，不会得知后续转换。原前缀判断在平稳流正确，在这两条转换流失去适用性。')
heading('全部平稳单元')
stat=[]
for cell in s['stationary_cells']:
    stat.append([names[cell['pair_id']]+' '+cell['endpoint'],f'{cell["mean_selector_minus_sbs"]:.2f}','/'.join(map(str,cell['wins_ties_losses'])),cell['worst_selector_regret'],f'{cell["selected_branch_counts"]["BF"]}/{cell["selected_branch_counts"]["BF_then_EoH"]}'])
table(['机制与端点','平均差值','胜/平/负','最大后悔','选择次数'],stat,[1.7,1.4,1.4,1.4,1.3])
heading('结论不能超出的范围')
para('转换并非一概有害。P2正态→双峰在2500件后转换的3条流全部优于SBS，平均省9.33箱；P1多个方向与时间格仍达分支oracle。另一方面，与SBS打平也不代表选对：P1大→小、t2500时平均错过17.33箱。总体负值或正值都不能替代逐机制与分支后悔检查。')
para('适用建议是把“未来与前缀近似同分布”标为该冻结一次推荐的使用条件，并公开分布变化风险。本次没有实现或验证变化检测、再选择或在线更新，也不能宣称这些改造一定有效。t2500结果的oracle仍是第500件后固定分支选择，不是到2500件才允许重选的oracle。')
d.add_page_break();heading('四种策略在所有转换单元的均值')
full=[]
for cell in s['shift_cells']:
    full.append([names[cell['pair_id']]+' '+cell['direction'].replace('_to_','→')+' '+str(cell['change_point'])]+[f'{cell["mean_bins"][k]:.2f}' for k in ['BF','BF_then_EoH','published_EoH','SELECTOR']])
table(['机制 方向 转换点','全BF','固定SBS','全EoH','SELECTOR'],full,[2.0,1.3,1.3,1.3,1.3])
heading('验证与资源')
para('216次完整实跑共1080000步全部完成，没有策略失败、丢弃单元或重跑。每步记录assignment、装入前后残量、可行箱数量、累计箱数及最终完整残量；SELECTOR记录31维特征、近邻、距离、预测和分支。')
para('同一受限进程中的独立标量评分与整数堆回放逐步验证capacity、score、首索引破同分、策略分支、总箱数与体积守恒；独立重算54次前缀特征和近邻，重新生成18源抽样与54流，确认所选完整轨迹等于合法分支。外部独审随后再次全量验证216次运行和108万步、54决策、18等前缀组、全部统计及4份CSV，结果通过，独审CPU为3.179856秒。')
para(f'正式单线程数值子进程CPU {r["cpu_total_seconds"]:.6f}秒，wall {r["wall_seconds"]:.6f}秒（包含等待冻结通知）。其范围包含源快照、输入生成和冻结、216实跑、全部独立回放及正式统计；预设CPU硬上限180秒、wall硬上限600秒。报告渲染及独立外审另计，不计入正式数值子进程。零模型API调用、零付款。')
para('原8项模型/源码/许可证字节复制且前后哈希不变。已阅读前次新尺寸族报告以提出此协议；本次程序未读旧输入或原始成绩，不修改任何旧目录。所有失败文件若存在均保留，本次RUN_FAILURE不存在。完整输入、轨迹、逐流结果、配对差值、成本和哈希清单均随本地目录保留。')
para('模型SHA256：'+p['model_sha256'])
text.append('核查入口：PROTOCOL.json、CODE_SEED_FREEZE.json、FREEZE.json、CHECK.json、analysis/SUMMARY.json、analysis/per_stream.csv、analysis/paired_contrasts.csv及resources/PROCESS_RESOURCE.json。MANIFEST.json覆盖交付文件，独审结果另见独审目录。')
d.core_properties.title='BPP 冻结前缀选择器分布转换验证';d.core_properties.subject='同前缀平稳与时间分布转换配对面板';d.core_properties.author=''
for root in [d.styles.element,d.element]:
    for border in list(root.iter(qn('w:pBdr'))):border.getparent().remove(border)
d.save(H/'BPP冻结前缀选择器分布转换验证.docx');(H/'REPORT_ZH.txt').write_text('\n\n'.join(text)+'\n')
print('Created local DOCX and text report from frozen official results.')
