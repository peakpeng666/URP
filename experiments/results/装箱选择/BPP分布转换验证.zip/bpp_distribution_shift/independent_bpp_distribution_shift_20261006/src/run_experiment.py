"""Frozen selector, fresh paired change-point streams; no fitting or tuning."""
import pathlib, hashlib, json, time, sys, os, signal, resource, traceback, csv, platform, ast
import numpy as np
from runner_copied import execute, load_controls
from checker_copied import rankings, replay
from selector import BRANCHES, FEATURE_NAMES
H=pathlib.Path(__file__).resolve().parents[1]
OLD=H.parent/'independent_bpp_prefix_selection_20261006'
N=5000; CAP=100; METHODS=['BF','BF_then_EoH','published_EoH','SELECTOR']; SBS='BF_then_EoH'
SEEDS=[202610069401,202610069402,202610069403]
PAIRS=[
 {'id':'P1_mean_reversal','a':'small_beta_2_5','b':'large_beta_5_2','mechanism':'Small-dominant versus large-dominant mirrored Beta; changes mean and complement availability.'},
 {'id':'P2_modality_dispersion','a':'normal_50_15','b':'bimodal_20_30_70_80','mechanism':'Similar central mean, unimodal clipped normal versus separated bimodal integer ranges; also changes variance and shape.'},
 {'id':'P3_breadth_upper_mass','a':'weibull_3_45','b':'uniform_1_100','mechanism':'Concentrated Weibull versus broad bounded uniform; compound changes in mean, breadth and upper-tail mass, not isolated or asymptotically heavy-tail.'},
]
SOURCE_MAP={'MODEL.json':'MODEL.json','src/run.py':'src/runner_copied.py','src/selector.py':'src/selector.py','src/check_cached.py':'src/checker_copied.py','src/prepare.py':'evidence/original_prepare.py.txt','sources/BF.py.txt':'sources/BF.py.txt','sources/published_EoH.py.txt':'sources/published_EoH.py.txt','LICENSE.source':'LICENSE.source'}
canon=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
sha=lambda x:hashlib.sha256(x).hexdigest()
def put(p,x):
    with p.open('x') as f:f.write(canon(x)+'\n');f.flush()
def now():return time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
def fail_signal(signum,frame):raise RuntimeError(f'Frozen budget interrupt signal {signum}; no reruns permitted')
def source_records():
    out=[]
    for old,new in SOURCE_MAP.items():
        a=(OLD/old).read_bytes();b=(H/new).read_bytes();assert a==b
        out.append({'source_path':str(OLD/old),'local_path':new,'sha256':sha(a),'bytes':len(a)})
    return out
def verify_sources(records):
    for r in records:
        assert sha(pathlib.Path(r['source_path']).read_bytes())==r['sha256']
        assert sha((H/r['local_path']).read_bytes())==r['sha256']
def load_generator():
    # Execute only the exact original make function, never original top-level preparation.
    tree=ast.parse((H/'evidence/original_prepare.py.txt').read_text())
    fun=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='make')
    scope={'np':np,'__builtins__':{'int':int}}
    exec(compile(ast.Module(body=[fun],type_ignores=[]),'<original-make-only>','exec'),scope)
    return scope['make']
def seed_for(pair_index,rep_index,endpoint):
    # Three replicate roots are new; pair and endpoint offsets produce 18 disjoint value seeds.
    return SEEDS[rep_index]+1000*pair_index+100*endpoint
def make_base(make,family,seed):
    values,clips=make(family,N,np.random.Generator(np.random.PCG64(seed)))
    perm=np.random.Generator(np.random.PCG64(seed+1000000)).permutation(N).tolist()
    return [values[j] for j in perm],clips,perm
def freeze_protocol(records):
    protocol={'schema':'frozen-selector-distribution-shift-v1','created_utc':now(),'question':'Does a once-only first500 recommendation remain useful when later item distributions change?',
      'scope':'Synthetic temporal-shift validation proposed after observing prior negative cases. No retraining, tuning, model/API calls, realistic external-blind or universal OOD claim.',
      'capacity':CAP,'items_per_stream':N,'prefix_length':500,'pairs':PAIRS,'replicate_seed_roots':SEEDS,
      'value_seed_rule':'replicate_seed_roots[r] + 1000*pair_index(0..2) + 100*endpoint(0=A,1=B)',
      'permutation_seed_rule':'value_seed + 1000000; separate numpy Generator(PCG64)',
      'generator':'Exact original make(family,n,rng) AST function copied without invoking its top-level script; original parameters, clipping1..100, ties-to-even numpy rint. Each complete 5000 base draw gets independent deterministic permutation.',
      'stream_construction':'For each pair and replicate generate A and B once. Stationary controls are full A and full B. Shift A_to_B at t is A[:t]+B[t:]; reverse B_to_A is B[:t]+A[t:]. No resampling by time. All inputs freeze before policies.',
      'change_points':[500,2500],'directions':['A_to_B','B_to_A'],
      'same_prefix_groups':'Each of 18 source endpoint prefixes is shared by its stationary control and its two outgoing shifts. Exact first500 state, features, neighbors and decisions must match all3.',
      'dependence':'9 paired source/replicate blocks; 18 independently seeded base draws. Six streams per block share source values and suffixes. The 54 streams, 36 shifts, 18 controls and paired times/directions are not independent observations; no pooled inferential sample-size claim.',
      'expected_counts':{'blocks':9,'base_draws':18,'shift_streams':36,'stationary_streams':18,'all_streams':54,'full_runs':216,'policy_steps':1080000},
      'policies':METHODS,'execution_order':'pair, replicate, then stationary_A, stationary_B, A_to_B_t500,t2500, B_to_A_t500,t2500; rotate policy order left by stream_index modulo4',
      'selector':'Original frozen MODEL and selector bytes. No fit call. Select exactly once after first500 BF placements, before arrival501 is consumed.',
      'features':list(FEATURE_NAMES),'model_sha256':'98991f0908867ff7de995b1e252d503c0180a5e74c67ac03d9444765fdede7ab','training_sbs':SBS,
      'branch_oracle':'min(BF final bins, BF_then_EoH final bins), sharing same first500 BF state. This is a hindsight branch choice at500, not a second oracle switch at2500.',
      'fixed_full_baseline':'published_EoH starts at item1 and is reported separately, never substituted into sameBF500 branch oracle.',
      'primary':'Mean SELECTOR minus fixed training SBS on all36 shift streams, reported separately from18 stationary controls.',
      'secondary':['All four policies and branch oracle means; wins/ties/losses; worst harm and regret; chosen branch counts.','All12 mechanism-direction-time cells, 6 stationary endpoint cells, all54 individual streams.','Paired shift-minus-origin-stationary selector regret and selector-minus-SBS delta changes (descriptive, changing item totals).','Same-prefix control-to-shift changes of strict oracle preference; increased/decreased regret and negative cases retained.'],
      'statistics':'Descriptive finite panel only; no bootstrap, confidence intervals, p-values, independence claim, result-driven weighting, dropped cells or reruns.',
      'checks':'Independent scalar score/integer heap replay of every policy step; feasible count, first index tie, residual, total bins and capacity/volume. Independent first500 features and neighbor regression; SELECTOR full trace equals legal chosen branch. Regenerate all input streams; identical-prefix invariance for18 groups.',
      'budget':{'numeric_process_cpu_hard_seconds':180,'numeric_process_cpu_soft_seconds':175,'numeric_process_wall_hard_seconds':600,'single_thread':True,'reruns':False,'new_dependencies':0,'api_calls':0,'failure':'Preserve completed files and partial trace if caught; hard kill may lose current in-memory trace. Do not relaunch result-producing process.'},
      'source_isolation':'Original8 source/model/license files byte-copied and checked before/after; prior new-family report read and copied as context. No old input/raw outcome files opened by new experiment. Old directories remain read-only.',
      'source_map':records,'environment':{'python':sys.version,'numpy':np.__version__,'platform':platform.platform()}}
    assert sha((H/'MODEL.json').read_bytes())==protocol['model_sha256']
    put(H/'PROTOCOL.json',protocol)
    files={str(p.relative_to(H)):sha(p.read_bytes()) for d in ['src','sources','evidence'] for p in sorted((H/d).rglob('*')) if p.is_file() and '__pycache__' not in str(p)}
    files.update({f:sha((H/f).read_bytes()) for f in ['MODEL.json','PROTOCOL.json','LICENSE.source']})
    put(H/'CODE_SEED_FREEZE.json',{'created_utc':now(),'before_any_input_generation':True,'before_any_policy_execution':True,'files':files})
    return files
def freeze_inputs(codefiles,make):
    metas=[];bases=[]
    for pi,pair in enumerate(PAIRS):
        for ri in range(3):
            block=f"{pair['id']}_r{ri}";items={}
            for ei,endpoint in enumerate(['A','B']):
                family=pair['a' if endpoint=='A' else 'b'];s=seed_for(pi,ri,ei)
                items[endpoint],clips,perm=make_base(make,family,s)
                base={'base_id':block+'_'+endpoint,'block_id':block,'endpoint':endpoint,'family':family,'replicate':ri,'value_seed':s,'permutation_seed':s+1000000,'items':items[endpoint],'source_position':perm,**clips}
                put(H/'inputs'/f"base__{base['base_id']}.json",base);bases.append({k:v for k,v in base.items() if k not in ['items','source_position']})
            for src,dst,t,kind in [('A','A',None,'stationary'),('B','B',None,'stationary'),('A','B',500,'shift'),('A','B',2500,'shift'),('B','A',500,'shift'),('B','A',2500,'shift')]:
                stream=items[src] if kind=='stationary' else items[src][:t]+items[dst][t:]
                label=f'stationary_{src}' if kind=='stationary' else f'{src}_to_{dst}_t{t}'
                meta={'instance_id':block+'__'+label,'block_id':block,'pair_id':pair['id'],'replicate':ri,'kind':kind,'direction':f'{src}_to_{dst}','change_point':t,'origin_endpoint':src,'destination_endpoint':dst,'origin_family':pair['a' if src=='A' else 'b'],'destination_family':pair['a' if dst=='A' else 'b'],'prefix_group':block+'_'+src,'items_sha256':sha(canon(stream).encode()),'prefix_sha256':sha(canon(stream[:500]).encode()),'total_volume':sum(stream)}
                put(H/'inputs'/f"{meta['instance_id']}.json",{**meta,'n':N,'capacity':CAP,'items':stream});metas.append(meta)
    put(H/'INPUT_INDEX.json',{'instances':metas,'base_draws':bases})
    files={**codefiles,'CODE_SEED_FREEZE.json':sha((H/'CODE_SEED_FREEZE.json').read_bytes()),'INPUT_INDEX.json':sha((H/'INPUT_INDEX.json').read_bytes())}
    files.update({str(p.relative_to(H)):sha(p.read_bytes()) for p in sorted((H/'inputs').glob('*.json'))})
    put(H/'FREEZE.json',{'created_utc':now(),'before_any_policy_execution':True,'streams':54,'blocks':9,'files':files})
    print(canon({'stage':'frozen_waiting_release','freeze_sha256':sha((H/'FREEZE.json').read_bytes()),'protocol_sha256':sha((H/'PROTOCOL.json').read_bytes()),'streams':54}),flush=True)
    return metas
def verify_freeze():
    for p,h in json.loads((H/'FREEZE.json').read_bytes())['files'].items():assert sha((H/p).read_bytes())==h,p
def validate_all(metas,rows,make):
    ranks=rankings();model=json.loads((H/'MODEL.json').read_bytes());bykey={(r['instance_id'],r['policy']):r for r in rows};groups={};base_cache={}
    for pi,pair in enumerate(PAIRS):
        for ri in range(3):
            for ei,end in enumerate(['A','B']):
                family=pair['a' if end=='A' else 'b'];seq,clips,perm=make_base(make,family,seed_for(pi,ri,ei))
                bid=f"{pair['id']}_r{ri}_{end}";saved=json.loads((H/'inputs'/f'base__{bid}.json').read_bytes())
                assert seq==saved['items'] and perm==saved['source_position'];base_cache[bid]=seq
    for m in metas:
        data=json.loads((H/'inputs'/f"{m['instance_id']}.json").read_bytes());a=base_cache[m['block_id']+'_'+m['origin_endpoint']];b=base_cache[m['block_id']+'_'+m['destination_endpoint']];t=m['change_point']
        assert data['items']==(a if t is None else a[:t]+b[t:]);assert data['items_sha256']==sha(canon(data['items']).encode())
        assert len(data['items'])==N and all(type(x)==int and 1<=x<=100 for x in data['items'])
        states={};assignments={};fs={};rs={}
        for p in METHODS:
            r=bykey[(m['instance_id'],p)];rs[p]=r;states[p],assignments[p],fs[p]=replay(data,r,ranks)
        assert states['BF']==states['BF_then_EoH']==states['SELECTOR']
        assert assignments['BF'][:500]==assignments['BF_then_EoH'][:500]==assignments['SELECTOR'][:500]
        sel=rs['SELECTOR'];branch=sel['branch'];assert branch in BRANCHES and sel['selector_consumed_count']==500
        assert assignments['SELECTOR']==assignments[branch] and sel['used_bins']==rs[branch]['used_bins']
        z=(np.asarray(fs['SELECTOR'])-np.asarray(model['mean']))/np.asarray(model['scale']);d=np.sum((np.asarray(model['x'])-z)**2,axis=1).tolist()
        nn=sorted(range(144),key=lambda i:(d[i],i))[:5];costs=[sum(model['y'][i][j] for i in nn)/5 for j in range(2)];ix=model['sbs_index'] if costs[0]==costs[1] else int(costs[1]<costs[0])
        assert nn==sel['decision']['neighbors'] and costs==sel['decision']['predicted_final_bins'] and ix==sel['decision']['selected_index']
        assert np.allclose([d[i] for i in nn],sel['decision']['squared_distances'],rtol=1e-12,atol=1e-12) and branch==BRANCHES[ix]
        groups.setdefault(m['prefix_group'],[]).append({'prefix':data['items'][:500],'state':states['BF'],'decision':sel['decision'],'branch':branch})
    assert len(groups)==18 and all(len(g)==3 and g[0]==g[1]==g[2] for g in groups.values())
    result={'passed':True,'full_runs_checked':216,'integer_and_policy_decision_steps':1080000,'selector_decisions_independently_recomputed':54,'regenerated_base_draws':18,'regenerated_streams':54,'identical_prefix_invariance_groups':18,'chosen_full_trace_equals_actual_branch':True,'all_BF500_states_match':True,'scope':'Independent scalar score/integer replay implementation and independent features, in same bounded numeric process; external audit separate.'}
    put(H/'CHECK.json',result);return result
def summarize(rr):
    delta=[r['selector_minus_sbs'] for r in rr];reg=[r['selector_regret'] for r in rr];head=[r['sbs_regret'] for r in rr]
    return {'streams':len(rr),'shared_source_blocks':len(set(r['block_id'] for r in rr)),'mean_bins':{p:float(np.mean([r[p] for r in rr])) for p in METHODS},'mean_branch_oracle_bins':float(np.mean([r['branch_oracle'] for r in rr])),'mean_selector_minus_sbs':float(np.mean(delta)),'total_selector_minus_sbs':sum(delta),'wins_ties_losses':[sum(d<0 for d in delta),sum(d==0 for d in delta),sum(d>0 for d in delta)],'worst_selector_minus_sbs':max(delta),'mean_selector_regret':float(np.mean(reg)),'worst_selector_regret':max(reg),'mean_sbs_regret':float(np.mean(head)),'headroom_recovered_fraction':-sum(delta)/sum(head) if sum(head) else None,'selected_branch_counts':{p:sum(r['selected_branch']==p for r in rr) for p in BRANCHES}}
def analyze(metas,rows):
    bykey={(r['instance_id'],r['policy']):r for r in rows};out=[]
    for m in metas:
        rs={p:bykey[(m['instance_id'],p)] for p in METHODS};b={p:rs[p]['used_bins'] for p in METHODS};oracle=min(b['BF'],b[SBS]);preferred='tie' if b['BF']==b[SBS] else ('BF' if b['BF']<b[SBS] else SBS)
        out.append({**m,**b,'selected_branch':rs['SELECTOR']['branch'],'branch_oracle':oracle,'oracle_preferred_branch':preferred,'selector_minus_sbs':b['SELECTOR']-b[SBS],'selector_regret':b['SELECTOR']-oracle,'sbs_regret':b[SBS]-oracle})
    controls={r['prefix_group']:r for r in out if r['kind']=='stationary'};contrasts=[]
    for r in out:
        if r['kind']!='shift':continue
        c=controls[r['prefix_group']];contrasts.append({'instance_id':r['instance_id'],'origin_control_id':c['instance_id'],'block_id':r['block_id'],'pair_id':r['pair_id'],'direction':r['direction'],'change_point':r['change_point'],'selected_branch':r['selected_branch'],'origin_control_regret':c['selector_regret'],'shift_regret':r['selector_regret'],'regret_change':r['selector_regret']-c['selector_regret'],'selector_minus_sbs_change':r['selector_minus_sbs']-c['selector_minus_sbs'],'origin_oracle_preferred':c['oracle_preferred_branch'],'shift_oracle_preferred':r['oracle_preferred_branch'],'strict_oracle_preference_flip':c['oracle_preferred_branch']!='tie' and r['oracle_preferred_branch']!='tie' and c['oracle_preferred_branch']!=r['oracle_preferred_branch'],'control_total_volume':c['total_volume'],'shift_total_volume':r['total_volume']})
    shifts=[r for r in out if r['kind']=='shift'];stat=[r for r in out if r['kind']=='stationary']
    cells=[{'pair_id':p['id'],'direction':d,'change_point':t,**summarize([r for r in shifts if r['pair_id']==p['id'] and r['direction']==d and r['change_point']==t])} for p in PAIRS for d in ['A_to_B','B_to_A'] for t in [500,2500]]
    stationary_cells=[{'pair_id':p['id'],'endpoint':end,**summarize([r for r in stat if r['pair_id']==p['id'] and r['origin_endpoint']==end])} for p in PAIRS for end in ['A','B']]
    result={'schema':'distribution-shift-summary-v1','status':'complete','training_sbs_fixed':SBS,'shift_only':summarize(shifts),'stationary_only':summarize(stat),'shift_cells':cells,'stationary_cells':stationary_cells,'same_prefix_contrasts':{'count':36,'strict_oracle_preference_flips':sum(r['strict_oracle_preference_flip'] for r in contrasts),'mean_regret_change':float(np.mean([r['regret_change'] for r in contrasts])),'regret_increased_unchanged_decreased':[sum(r['regret_change']>0 for r in contrasts),sum(r['regret_change']==0 for r in contrasts),sum(r['regret_change']<0 for r in contrasts)],'worst_regret_increase':max(r['regret_change'] for r in contrasts)},'all_streams_included':True,'inference':'Descriptive, correlated finite synthetic panel. Stationary and shift summaries separate; no statistical significance or external blind-test claim.'}
    put(H/'analysis/SUMMARY.json',result);put(H/'analysis/PER_STREAM.json',out);put(H/'analysis/PAIRED_CONTRASTS.json',contrasts)
    for filename,data in [('per_stream.csv',out),('paired_contrasts.csv',contrasts),('shift_cells.csv',cells),('stationary_cells.csv',stationary_cells)]:
        with (H/'analysis'/filename).open('x',newline='') as f:w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
    print(canon({'stage':'summary','shift_only':result['shift_only'],'stationary_only':result['stationary_only'],'same_prefix_contrasts':result['same_prefix_contrasts']}),flush=True)
    return result
def main():
    start=time.monotonic();cpu=time.process_time();rows=[]
    signal.signal(signal.SIGXCPU,fail_signal);signal.signal(signal.SIGALRM,fail_signal);signal.alarm(599);resource.setrlimit(resource.RLIMIT_CPU,(175,180))
    put(H/'RUN_STARTED.json',{'started_utc':now(),'cpu_hard_limit':180,'wall_hard_limit':600,'all_official_numeric_work_in_this_process':True,'single_thread_env':{k:os.environ.get(k) for k in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS']}})
    try:
        records=source_records();put(H/'evidence/SOURCE_SNAPSHOT.json',{'created_utc':now(),'files':records});codefiles=freeze_protocol(records);make=load_generator();metas=freeze_inputs(codefiles,make)
        while not (H/'EXECUTION_RELEASE.json').exists():time.sleep(.25)
        verify_freeze();controls=load_controls();model=json.loads((H/'MODEL.json').read_bytes());assert model['sbs_index']==1 and model['k']==5
        put(H/'POLICIES_STARTED.json',{'started_utc':now(),'freeze_sha256':sha((H/'FREEZE.json').read_bytes()),'release_sha256':sha((H/'EXECUTION_RELEASE.json').read_bytes()),'cpu_before_policies':time.process_time()})
        for i,m in enumerate(metas):
            data=json.loads((H/'inputs'/f"{m['instance_id']}.json").read_bytes());names=METHODS[i%4:]+METHODS[:i%4];runs=[execute(data,p,controls,model) for p in names];rows.extend(runs)
            print(canon({'stage':'run','completed_runs':len(rows),'instance':m['instance_id'],'bins':{r['policy']:r['used_bins'] for r in runs},'branch':next(r['branch'] for r in runs if r['policy']=='SELECTOR')}),flush=True)
        assert len(rows)==216
        validate_all(metas,rows,make);analyze(metas,rows);verify_freeze();verify_sources(records)
        put(H/'SOURCE_ISOLATION_CHECK.json',{'passed':True,'original_source_files':len(records),'before_after_bytes_match':True,'old_input_or_raw_files_opened_by_experiment':False,'prior_new_family_report_read':True,'old_source_files_modified':False,'fit_called':False})
        done={'status':'complete','finished_utc':now(),'full_runs':216,'policy_steps':1080000,'validated_steps':1080000,'process_cpu_seconds_before_final_write':time.process_time(),'experiment_cpu_seconds':time.process_time()-cpu,'experiment_wall_seconds':time.monotonic()-start,'api_calls':0,'api_charges':0,'retries':0,'source_unchanged':True}
        put(H/'RUN_COMPLETE.json',done);print(canon(done),flush=True)
    except BaseException as e:
        try:put(H/'RUN_FAILURE.json',{'status':'partial_or_failure','finished_utc':now(),'error':type(e).__name__+': '+str(e),'fully_committed_rows_in_memory':len(rows),'raw_json_files_preserved':len(list((H/'raw').glob('*.json'))),'cpu_seconds':time.process_time(),'wall_seconds':time.monotonic()-start,'traceback':traceback.format_exc(),'rerun_permitted':False})
        except BaseException:pass
        raise
if __name__=='__main__':main()
