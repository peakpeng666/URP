"""One bounded numerical child; all input generation, runs and validation included."""
import pathlib,os,sys,time,json,resource,subprocess,signal
H=pathlib.Path(__file__).resolve().parents[1]
assert not (H/'RUN_STARTED.json').exists()
env=dict(os.environ,OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',OMP_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
def limits():resource.setrlimit(resource.RLIMIT_CPU,(175,180));os.setsid()
start=time.monotonic();r0=resource.getrusage(resource.RUSAGE_CHILDREN);status='finished'
with (H/'resources/experiment.log').open('x') as log:
    p=subprocess.Popen([sys.executable,str(H/'src/run_experiment.py')],stdout=log,stderr=subprocess.STDOUT,env=env,preexec_fn=limits)
    try:rc=p.wait(timeout=600)
    except subprocess.TimeoutExpired:status='wall_limit_killed';os.killpg(p.pid,signal.SIGKILL);rc=p.wait()
r1=resource.getrusage(resource.RUSAGE_CHILDREN)
result={'status':status,'exit_code':rc,'wall_seconds':time.monotonic()-start,'cpu_user_seconds':r1.ru_utime-r0.ru_utime,'cpu_system_seconds':r1.ru_stime-r0.ru_stime,'cpu_total_seconds':r1.ru_utime+r1.ru_stime-r0.ru_utime-r0.ru_stime,'max_rss_kb':r1.ru_maxrss,'cpu_hard_limit':180,'cpu_soft_limit':175,'wall_hard_limit':600,'includes':'One child: source snapshot, protocol freeze, input generation and freeze, all216 actual runs, independent full replay and official analysis. Waiting for freeze notification release adds wall only. Launcher records child resource usage. No retry.'}
with (H/'resources/PROCESS_RESOURCE.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result),flush=True);raise SystemExit(rc)
