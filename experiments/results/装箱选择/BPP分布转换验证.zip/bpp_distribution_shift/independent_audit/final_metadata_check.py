"""Read-only publication metadata and DOCX table/text verification. No policy execution."""
import pathlib,json,hashlib,zipfile,xml.etree.ElementTree as ET,datetime,time,resource,traceback
H=pathlib.Path(__file__).resolve().parent;R=H.parent/'independent_bpp_distribution_shift_20261006'
resource.setrlimit(resource.RLIMIT_CPU,(3,3));cpu=time.process_time();start=time.monotonic()
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(name,x):
    with (H/name).open('x') as f:json.dump(x,f,ensure_ascii=False,indent=2);f.write('\n')
try:
    audit=read(H/'AUDIT_RESULT.json');assert audit['status']=='passed_numerical_evidence'
    pins=read(H/'SOURCE_PINS.json')
    for n,h in pins['files'].items():assert sha(R/n)==h,n
    for n,h in pins['external_files'].items():assert sha(pathlib.Path(n))==h,n
    origin=pins['independent_checker_origin'];assert sha(pathlib.Path(origin['path']))==origin['sha256']
    mf=read(R/'MANIFEST.json');seen=set()
    for name,record in mf['files'].items():
        rec={'path':name,**record}
        p=R/rec['path'];assert rec['path'] not in seen and p.is_file();seen.add(rec['path'])
        assert p.stat().st_size==rec['bytes'] and sha(p)==rec['sha256'],rec['path']
    assert len(mf['files'])==mf['file_count']
    actual={str(p.relative_to(R)) for p in R.rglob('*') if p.is_file()}
    omitted=actual-seen-{'MANIFEST.json'}
    allowed=lambda n:n.startswith('render/') or n.startswith('render_final/') or n.startswith('render_release/') or '__pycache__' in n
    assert all(allowed(n) for n in omitted),sorted(omitted)
    assert not seen-actual
    assert sum((R/n).stat().st_size for n in seen)==mf['total_bytes']
    assert sha(R/'MANIFEST.json')=='2ca341141082ce6405598039dc0b00497bce198714ab186e2bd2b550f76c29ef'
    assert all(n in seen for n in pins['files'])
    assert all(n in seen for n in ['REPORT_ZH.txt','DOCUMENT_QA.json','README.txt','BPP冻结前缀选择器分布转换验证.docx'])
    doc=R/'BPP冻结前缀选择器分布转换验证.docx';doc_hash=sha(doc)
    qa=read(R/'DOCUMENT_QA.json');assert qa['passed'] and qa['docx_sha256']==doc_hash
    visual=read(H/'VISUAL_QA.json');assert visual['passed'] and visual['document_sha256']==doc_hash
    for n,h in visual['page_sha256'].items():assert sha(R/n)==h,n
    ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
    with zipfile.ZipFile(doc) as z:tree=ET.fromstring(z.read('word/document.xml'))
    body=tree.find('w:body',ns);txt=lambda element:''.join(element.itertext()) # replaced below by w:t only
    def text(e):return ''.join(t.text or '' for t in e.findall('.//w:t',ns))
    lines=[];tables=[]
    for e in body:
        if e.tag.endswith('}p'):
            t=text(e)
            if t:lines.append(t)
        elif e.tag.endswith('}tbl'):
            rows=[[text(cell) for cell in row.findall('w:tc',ns)] for row in e.findall('w:tr',ns)]
            tables.append(rows);lines.extend(' | '.join(row) for row in rows)
    report=(R/'REPORT_ZH.txt').read_text();report_lines=[x for x in report.split('\n\n') if x.strip()]
    assert len(report_lines)==len(lines)+1 and report_lines[-1].startswith('核查入口：')
    assert [x.strip() for x in report_lines[:-1]]==lines
    assert len(tables)==4
    summary=audit['summary'];o=summary['shift_only'];c=summary['stationary_only']
    expected0=[[label,f'{o["mean_bins"][key]:.3f}',f'{c["mean_bins"][key]:.3f}'] for key,label in [('BF','全程BF'),('BF_then_EoH','BF500后续EoH  固定SBS'),('published_EoH','全程published EoH'),('SELECTOR','冻结SELECTOR')]]+[['同BF500两分支事后oracle',f'{o["mean_branch_oracle_bins"]:.3f}',f'{c["mean_branch_oracle_bins"]:.3f}']]
    assert tables[0][1:]==expected0
    e1=[];e2=[];e3=[]
    for cell in summary['shift_cells']:
        label=cell['pair_id'].split('_')[0]+' '+cell['direction'].replace('_to_','→')
        e1.append([label,str(cell['change_point']),f'{cell["mean_selector_minus_sbs"]:.2f}','/'.join(map(str,cell['wins_ties_losses'])),str(cell['worst_selector_regret']),f'{cell["selected_branch_counts"]["BF"]}/{cell["selected_branch_counts"]["BF_then_EoH"]}'])
        e3.append([label+' '+str(cell['change_point'])]+[f'{cell["mean_bins"][p]:.2f}' for p in ['BF','BF_then_EoH','published_EoH','SELECTOR']])
    for cell in summary['stationary_cells']:
        e2.append([cell['pair_id'].split('_')[0]+' '+cell['endpoint'],f'{cell["mean_selector_minus_sbs"]:.2f}','/'.join(map(str,cell['wins_ties_losses'])),str(cell['worst_selector_regret']),f'{cell["selected_branch_counts"]["BF"]}/{cell["selected_branch_counts"]["BF_then_EoH"]}'])
    assert tables[1][1:]==e1 and tables[2][1:]==e2 and tables[3][1:]==e3
    assert ['216','1080000','7.81','69','3.89','3.179856','57.950386','92.039370','-184.87%'] == [v for v in ['216','1080000','7.81','69','3.89','3.179856','57.950386','92.039370','-184.87%'] if v in report]
    cost=read(R/'resources/COST_BREAKDOWN.json')
    all_raw=[read(p) for p in (R/'raw').glob('*.json')]
    assert cost['official_process']==audit['author_resource'] and cost['api_calls']==cost['payments']==0
    for policy,costrow in cost['per_policy'].items():
        rr=[r for r in all_raw if r['policy']==policy]
        assert costrow['actual_full_runs']==len(rr)==54 and costrow['completed_steps']==sum(r['steps'] for r in rr)==270000
        for key,value in costrow.items():
            if key.startswith('sum_'):assert abs(value-sum(r[key[4:]] for r in rr))<1e-10,(policy,key)
    assert cost['failure_accounting']=={'complete_runs':216,'failed_runs':0,'retries':0,'RUN_FAILURE_exists':False}
    worst=read(R/'raw/P3_breadth_upper_mass_r2__B_to_A_t500__SELECTOR.json')
    assert worst['decision']['neighbors']==[39,45,30,33,24] and worst['decision']['predicted_final_bins']==[2574.8,2587.0]
    rows=read(H/'INDEPENDENT_PER_STREAM.json');byid={r['instance_id']:r for r in rows}
    x=byid['P3_breadth_upper_mass_r2__stationary_B'];assert x['BF']==2577 and x['BF_then_EoH']==2585
    x=byid['P3_breadth_upper_mass_r2__B_to_A_t500'];assert x['BF']==2159 and x['BF_then_EoH']==2090
    assert byid['P3_breadth_upper_mass_r2__B_to_A_t2500']['selector_minus_sbs']==46
    keys=['9个配对/seed块','不能把36转换流','不是新边际族发现或现实外部盲测','不是纯重尾或单变量因果对照','不是到2500件才允许重选的oracle','核心比较均在同一条流的策略之间完成','不能宣称这些改造一定有效']
    assert all(k in report for k in keys)
    assert not tree.findall('.//w:ins',ns) and not tree.findall('.//w:del',ns)
    result={'status':'passed','completed_utc':now(),'release_verdict':'可在限定有限合成时间分布变化面板的负结果范围内发布。不得宣称普遍失效/鲁棒性成功、现实盲测、独立54样本、显著性或孤立因果效应。','manifest_sha256':sha(R/'MANIFEST.json'),'manifest_files_verified':len(seen),'omitted_QA_or_cache_files':sorted(omitted),'document_sha256':doc_hash,'render_pages_visually_reviewed':len(visual['page_sha256']),'report_text_and_all4_tables_verified':True,'numeric_source_pins_rechecked':len(pins['files']),'model_and_original_sources_unchanged':True,'failures_seen':[],'no_numerical_rerun':True,'cost_breakdown_recomputed_from_all216_raw_rows':True,'script_cpu_seconds_before_final_write':time.process_time()-cpu,'wall_seconds_before_final_write':time.monotonic()-start,'script_cpu_hard_limit_seconds':3,'limits':['Final byte verification does not substitute for external publication recipient/access review.','Stationarity is a modeling assumption, not a sufficient safety/performance guarantee.']}
    save('FINAL_METADATA_CHECK.json',result);print(json.dumps(result,ensure_ascii=False,indent=2))
except BaseException as exc:
    save('FINAL_METADATA_FAILURE.json',{'status':'failed_or_incomplete','error':repr(exc),'traceback':traceback.format_exc(),'completed_utc':now()});raise
