"""Independent full-grid distribution-shift audit. See frozen audit plan and provenance."""
import pathlib,json,hashlib,statistics,datetime,time,signal,traceback,collections,csv,ast
import numpy as np
from checker_independent import read,sha,canon,digest,ranks,replay,decision,summarize,POLICIES
H=pathlib.Path(__file__).resolve().parent;R=H.parent/'independent_bpp_distribution_shift_20261006'
PROTOCOL='9208238b9fb9534692a90abd200874d355d5a5783a296aee39baff602c4f535a'
FREEZE='2aeef17a851e85a04f14a6a8cd8d539da4b4c98673618eee6cc74f6dd456c286'
MODEL='98991f0908867ff7de995b1e252d503c0180a5e74c67ac03d9444765fdede7ab'
progress={'base_draws':0,'streams':0,'runs':0,'integer_and_policy_decision_steps':0,'selector_decisions':0,'same_prefix_groups':0}
sources={};external={}
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def put(name,x):
    with (H/name).open('x') as f:json.dump(x,f,ensure_ascii=False,indent=2);f.write('\n')
def pin(path):
    sources[str(path.relative_to(R))]=sha(path)
    return read(path)
def fail_signal(sig,frame):raise RuntimeError('Audit CPU soft cap reached; partial evidence retained')
signal.signal(signal.SIGXCPU,fail_signal)

def make(family,seed):
    rng=np.random.Generator(np.random.PCG64(seed));n=5000
    if family=='small_beta_2_5':x=100*rng.beta(2,5,n)
    elif family=='large_beta_5_2':x=100*rng.beta(5,2,n)
    elif family=='normal_50_15':x=rng.normal(50,15,n)
    elif family=='bimodal_20_30_70_80':
        label=rng.integers(0,2,n);small=rng.integers(20,31,n);large=rng.integers(70,81,n);x=np.where(label==0,small,large)
    elif family=='weibull_3_45':x=45*rng.weibull(3,n)
    elif family=='uniform_1_100':x=rng.integers(1,101,n)
    else:raise AssertionError(family)
    clips={'raw_below_1':int(sum(x<1)),'raw_above_100':int(sum(x>100))}
    values=np.rint(np.clip(x,1,100)).astype(np.int64).tolist()
    order=np.random.Generator(np.random.PCG64(seed+1000000)).permutation(n).tolist()
    return [values[k] for k in order],order,clips

def summary(rows):
    v=summarize(rows);v['shared_source_blocks']=len({r['block_id'] for r in rows});return v

def main():
    assert sha(R/'PROTOCOL.json')==PROTOCOL and sha(R/'FREEZE.json')==FREEZE
    P=pin(R/'PROTOCOL.json');F=pin(R/'FREEZE.json');pin(R/'CODE_SEED_FREEZE.json')
    assert P==read(H/'pre_run/PROTOCOL.json') and F==read(H/'pre_run/FREEZE.json')
    for name,expected in F['files'].items():assert sha(R/name)==expected,name;sources[name]=expected
    for rec in P['source_map']:
        assert sha(pathlib.Path(rec['source_path']))==rec['sha256']==sha(R/rec['local_path'])
        external[rec['source_path']]=rec['sha256']
    model=pin(R/'MODEL.json');assert sha(R/'MODEL.json')==MODEL
    assert model['k']==5 and model['sbs_index']==1 and len(model['x'])==len(model['y'])==144
    assert all(len(x)==31 for x in model['x']) and len(model['mean'])==len(model['scale'])==31 and all(s>0 for s in model['scale'])
    done=pin(R/'RUN_COMPLETE.json');started=pin(R/'RUN_STARTED.json');began=pin(R/'POLICIES_STARTED.json');release=pin(R/'EXECUTION_RELEASE.json')
    assert done['status']=='complete' and done['full_runs']==216 and done['policy_steps']==done['validated_steps']==1080000
    assert done['api_calls']==done['api_charges']==done['retries']==0
    assert began['freeze_sha256']==FREEZE and began['release_sha256']==sha(R/'EXECUTION_RELEASE.json')
    assert F['before_any_policy_execution'] and F['created_utc']<=began['started_utc']<=done['finished_utc']
    assert P['policies']==POLICIES and P['training_sbs']=='BF_then_EoH' and P['change_points']==[500,2500]
    assert started['single_thread_env']=={'OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1','OMP_NUM_THREADS':'1'}
    resource=pin(R/'resources/PROCESS_RESOURCE.json');assert resource['exit_code']==0 and resource['status']=='finished' and resource['cpu_total_seconds']<180
    assert resource['cpu_hard_limit']==180 and resource['cpu_soft_limit']==175 and resource['wall_seconds']<600
    check=pin(R/'CHECK.json');assert check['passed'] and check['full_runs_checked']==216
    isolation=pin(R/'SOURCE_ISOLATION_CHECK.json');assert isolation['passed'] and isolation['fit_called'] is False
    assert not (R/'RUN_FAILURE.json').exists()
    index=pin(R/'INPUT_INDEX.json');metas=index['instances'];assert len(metas)==54 and len(index['base_draws'])==18
    pairs=[('P1_mean_reversal','small_beta_2_5','large_beta_5_2'),('P2_modality_dispersion','normal_50_15','bimodal_20_30_70_80'),('P3_breadth_upper_mass','weibull_3_45','uniform_1_100')]
    assert [(p['id'],p['a'],p['b']) for p in P['pairs']]==pairs
    assert P['replicate_seed_roots']==[202610069401,202610069402,202610069403]
    bases={};new_seeds=set();base_metas=[];expected_metas=[]
    for pi,(pair,a,b) in enumerate(pairs):
        for rep in range(3):
            block=f'{pair}_r{rep}'
            for endpoint,family,offset in [('A',a,0),('B',b,100)]:
                seed=202610069401+rep+1000*pi+offset;bid=block+'_'+endpoint
                items,order,clips=make(family,seed)
                saved=pin(R/'inputs'/f'base__{bid}.json')
                bm={'base_id':bid,'block_id':block,'endpoint':endpoint,'family':family,'replicate':rep,'value_seed':seed,'permutation_seed':seed+1000000,**clips}
                assert saved=={**bm,'items':items,'source_position':order},bid
                assert sorted(order)==list(range(5000));assert all(type(x)==int and 1<=x<=100 for x in items)
                bases[bid]=items;base_metas.append(bm);new_seeds.update([seed,seed+1000000]);progress['base_draws']+=1
            for src,dst,t,kind in [('A','A',None,'stationary'),('B','B',None,'stationary'),('A','B',500,'shift'),('A','B',2500,'shift'),('B','A',500,'shift'),('B','A',2500,'shift')]:
                left=bases[block+'_'+src];right=bases[block+'_'+dst];items=left if t is None else left[:t]+right[t:]
                label='stationary_'+src if kind=='stationary' else f'{src}_to_{dst}_t{t}'
                meta={'instance_id':block+'__'+label,'block_id':block,'pair_id':pair,'replicate':rep,'kind':kind,'direction':src+'_to_'+dst,'change_point':t,'origin_endpoint':src,'destination_endpoint':dst,'origin_family':a if src=='A' else b,'destination_family':a if dst=='A' else b,'prefix_group':block+'_'+src,'items_sha256':digest(items),'prefix_sha256':digest(items[:500]),'total_volume':sum(items)}
                data=pin(R/'inputs'/f"{meta['instance_id']}.json");assert data=={**meta,'n':5000,'capacity':100,'items':items}
                expected_metas.append(meta)
    assert base_metas==index['base_draws'] and expected_metas==metas
    assert len(new_seeds)==36 and len({digest(x) for x in bases.values()})==18 and len({m['items_sha256'] for m in metas})==54
    assert len(list((R/'inputs').glob('*.json')))==72
    # Compare new seeds with metadata from all named previous independent BPP panels.
    old_seeds=set();old_meta_files=[]
    def harvest(obj):
        if isinstance(obj,dict):
            for key,value in obj.items():
                if 'seed' in key and isinstance(value,int):old_seeds.add(value)
                harvest(value)
        elif isinstance(obj,list):
            for v in obj:harvest(v)
    for dirname in ['independent_bpp_prefix_selection_20261006','independent_bpp_new_families_20261006','independent_bpp_distribution_20261006','independent_bpp_matched_size_20261006','independent_bpp_selector_family_transfer_20261006']:
        for name in ['PROTOCOL.json','INPUT_INDEX.json']:
            path=H.parent/dirname/name
            if path.exists():
                harvest(read(path));external[str(path)]=sha(path);old_meta_files.append(str(path))
    assert not new_seeds&old_seeds
    ranking=ranks();metrics=[];groups=collections.defaultdict(list);feature_error=0.;distance_error=0.
    for meta in metas:
        data=read(R/'inputs'/f"{meta['instance_id']}.json");rows={};traces={};states={};fs={}
        for policy in POLICIES:
            path=R/'raw'/f"{meta['instance_id']}__{policy}.json";row=pin(path);assert row['policy']==policy
            prefix,arrays,f=replay(R,data,row,ranking);rows[policy]=row;states[policy]=prefix;traces[policy]=arrays;fs[policy]=f
            sources[row['trajectory_file']]=row['trajectory_sha256']
            feature_error=max(feature_error,max(abs(x-y) for x,y in zip(f,row['prefix_features'])))
            progress['runs']+=1;progress['integer_and_policy_decision_steps']+=5000
        assert states['BF']==states['BF_then_EoH']==states['SELECTOR']
        for field in ['assignment','pre_remaining','post_remaining','feasible_counts','used_bins_after']:
            assert traces['BF'][field][:500]==traces['BF_then_EoH'][field][:500]==traces['SELECTOR'][field][:500]
        sel=rows['SELECTOR'];branch=sel['branch'];assert traces['SELECTOR']==traces[branch] and sel['used_bins']==rows[branch]['used_bins']
        distance_error=max(distance_error,decision(model,fs['SELECTOR'],sel));progress['selector_decisions']+=1
        groups[meta['prefix_group']].append({'prefix':data['items'][:500],'state':states['BF'],'features':fs['SELECTOR'],'decision':sel['decision'],'branch':branch})
        bins={p:rows[p]['used_bins'] for p in POLICIES};oracle=min(bins['BF'],bins['BF_then_EoH'])
        pref='tie' if bins['BF']==bins['BF_then_EoH'] else ('BF' if bins['BF']<bins['BF_then_EoH'] else 'BF_then_EoH')
        metrics.append({**meta,**bins,'selected_branch':branch,'branch_oracle':oracle,'oracle_preferred_branch':pref,'selector_minus_sbs':bins['SELECTOR']-bins['BF_then_EoH'],'selector_regret':bins['SELECTOR']-oracle,'sbs_regret':bins['BF_then_EoH']-oracle})
        progress['streams']+=1;print(canon({'verified':meta['instance_id'],**progress}),flush=True)
    assert len(groups)==18
    for group,records in groups.items():assert len(records)==3 and records[0]==records[1]==records[2],group;progress['same_prefix_groups']+=1
    assert len(list((R/'raw').glob('*.json')))==len(list((R/'raw').glob('*.npz')))==216
    expected_raw={f"{m['instance_id']}__{p}{ext}" for m in metas for p in POLICIES for ext in ['.json','.npz']}
    assert {p.name for p in (R/'raw').iterdir() if p.is_file()}==expected_raw
    reported=pin(R/'analysis/PER_STREAM.json');assert metrics==reported
    controls={r['prefix_group']:r for r in metrics if r['kind']=='stationary'};contrasts=[]
    shifts=[r for r in metrics if r['kind']=='shift'];stationary=[r for r in metrics if r['kind']=='stationary']
    for r in shifts:
        c=controls[r['prefix_group']]
        contrasts.append({'instance_id':r['instance_id'],'origin_control_id':c['instance_id'],'block_id':r['block_id'],'pair_id':r['pair_id'],'direction':r['direction'],'change_point':r['change_point'],'selected_branch':r['selected_branch'],'origin_control_regret':c['selector_regret'],'shift_regret':r['selector_regret'],'regret_change':r['selector_regret']-c['selector_regret'],'selector_minus_sbs_change':r['selector_minus_sbs']-c['selector_minus_sbs'],'origin_oracle_preferred':c['oracle_preferred_branch'],'shift_oracle_preferred':r['oracle_preferred_branch'],'strict_oracle_preference_flip':c['oracle_preferred_branch']!='tie' and r['oracle_preferred_branch']!='tie' and c['oracle_preferred_branch']!=r['oracle_preferred_branch'],'control_total_volume':c['total_volume'],'shift_total_volume':r['total_volume']})
    assert contrasts==pin(R/'analysis/PAIRED_CONTRASTS.json')
    shift_cells=[{'pair_id':pair,'direction':d,'change_point':t,**summary([r for r in shifts if r['pair_id']==pair and r['direction']==d and r['change_point']==t])} for pair,_,_ in pairs for d in ['A_to_B','B_to_A'] for t in [500,2500]]
    stat_cells=[{'pair_id':pair,'endpoint':end,**summary([r for r in stationary if r['pair_id']==pair and r['origin_endpoint']==end])} for pair,_,_ in pairs for end in ['A','B']]
    paired_summary={'count':36,'strict_oracle_preference_flips':sum(r['strict_oracle_preference_flip'] for r in contrasts),'mean_regret_change':statistics.mean(r['regret_change'] for r in contrasts),'regret_increased_unchanged_decreased':[sum(r['regret_change']>0 for r in contrasts),sum(r['regret_change']==0 for r in contrasts),sum(r['regret_change']<0 for r in contrasts)],'worst_regret_increase':max(r['regret_change'] for r in contrasts)}
    report=pin(R/'analysis/SUMMARY.json')
    for key,value in [('shift_only',summary(shifts)),('stationary_only',summary(stationary)),('shift_cells',shift_cells),('stationary_cells',stat_cells),('same_prefix_contrasts',paired_summary)]:assert value==report[key],key
    assert report['all_streams_included'] and report['training_sbs_fixed']=='BF_then_EoH'
    assert all(c['streams']==3 and c['shared_source_blocks']==3 for c in shift_cells+stat_cells)
    csv_checks=[]
    for name,expected in [('per_stream.csv',metrics),('paired_contrasts.csv',contrasts),('shift_cells.csv',shift_cells),('stationary_cells.csv',stat_cells)]:
        path=R/'analysis'/name;sources[str(path.relative_to(R))]=sha(path)
        with path.open(newline='') as f:got=list(csv.DictReader(f))
        assert len(got)==len(expected)
        for observed,exp in zip(got,expected):
            assert observed.keys()==exp.keys()
            for k,v in exp.items():
                x=observed[k]
                if v is None:assert x==''
                elif isinstance(v,str):assert x==v
                else:assert ast.literal_eval(x)==v,(name,k,x,v)
        csv_checks.append({'file':name,'rows':len(got)})
    # Execution order and exact accounting are verified from author log.
    log=R/'resources/experiment.log';sources[str(log.relative_to(R))]=sha(log)
    logs=[json.loads(line) for line in log.read_text().splitlines() if line.startswith('{')]
    runlogs=[r for r in logs if r.get('stage')=='run'];assert len(runlogs)==54
    for i,(entry,meta) in enumerate(zip(runlogs,metas)):
        assert entry['instance']==meta['instance_id'] and entry['completed_runs']==4*(i+1)
        rotated=POLICIES[i%4:]+POLICIES[:i%4]
        # Saved JSON log serializes keys canonically; policy rotation is established by frozen code.
        assert entry['bins']=={p:metrics[i][p] for p in POLICIES} and entry['branch']==metrics[i]['selected_branch']
    for name,h in sources.items():assert sha(R/name)==h,name
    for name,h in external.items():assert sha(pathlib.Path(name))==h,name
    result={'status':'passed_numerical_evidence','completed_utc':now(),'checks':progress,'all_steps_independently_scored':True,'frozen_model_byte_identical':True,'new_executions':216,'historical_execution_records_reused':0,'new_value_and_permutation_seeds':36,'prior_metadata_unique_seeds_checked':len(old_seeds),'prior_seed_metadata_files':old_meta_files,'base_draws':18,'dependent_blocks':9,'same_prefix_groups_of_three':18,'max_feature_absolute_error':feature_error,'max_neighbor_distance_absolute_error':distance_error,'csv_checks':csv_checks,'summary':report,'all_negative_streams':[r for r in metrics if r['selector_minus_sbs']>0],'strict_flip_contrasts':[r for r in contrasts if r['strict_oracle_preference_flip']],'worst_shift_regret_instances':[r['instance_id'] for r in shifts if r['selector_regret']==max(x['selector_regret'] for x in shifts)],'source_files_checked':len(sources),'external_source_and_metadata_files_checked':len(external),'author_resource':resource,'limits':['Descriptive, post-hoc synthetic temporal composition using original6 marginal generator definitions. No general OOD or field claim.','54 streams/36 shifts/18 controls are dependent;9 paired source blocks,18 seeded base draws.','Same-prefix oracle is a hindsight decision at500 only, not a new action at2500; full-run published_EoH excluded.','Seeds are checked disjoint against named prior protocol/index metadata, not all possible historical random seeds.','Code and hash evidence, not OS syscall logging. No claim of physical isolation or fully exact all-in cost.','Final report/document/complete release manifest require separate metadata check.']}
    put('AUDIT_RESULT.json',result);put('SOURCE_PINS.json',{'root':str(R),'files':sources,'external_files':external,'independent_checker_origin':{'path':str(H.parent/'new_family_independent_audit_20261006/audit_new_families.py'),'sha256':'7b2e9d279e83b1737596e6b53ec1eb1389cc6c4e4763f7f8380d6debca749fd6'}})
    put('INDEPENDENT_PER_STREAM.json',metrics);put('INDEPENDENT_PAIRED_CONTRASTS.json',contrasts)
    print(canon({'status':result['status'],'checks':progress,'shift_only':report['shift_only'],'stationary_only':report['stationary_only'],'paired':paired_summary}),flush=True)
try:main()
except BaseException as exc:
    put('AUDIT_FAILURE.json',{'status':'failed_or_incomplete','error':type(exc).__name__+': '+str(exc),'completed_checks':progress,'traceback':traceback.format_exc(),'completed_utc':now()});raise
