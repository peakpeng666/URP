"""Small standard-library PFSP implementations with pre-debited work budgets."""
from collections import Counter
import random,time,signal

class BudgetStop(Exception): pass
class Evaluator:
    def __init__(self,processing,max_evaluations=5000,max_cells=500000,cpu_seconds=3.0,wall_seconds=8.0):
        self.p=tuple(tuple(row) for row in processing); self.n=len(self.p); self.m=len(self.p[0])
        self.limit_eval=max_evaluations; self.limit_cells=max_cells; self.limit_cpu=cpu_seconds; self.limit_wall=wall_seconds
        self.evaluations=0; self.cells=0; self.completed_evaluations=0; self.completed_cells=0
        self.by_phase=Counter(); self.cells_by_phase=Counter(); self.by_length=Counter()
        self.best_perm=None; self.best=None; self.trace=[]; self.phase='NEH'; self.denied=None
        self.start_cpu=time.process_time(); self.start_wall=time.perf_counter()
    def elapsed(self): return time.process_time()-self.start_cpu,time.perf_counter()-self.start_wall
    def evaluate(self,perm):
        cost=len(perm)*self.m; cpu,wall=self.elapsed()
        reason= ('candidate_budget' if self.evaluations+1>self.limit_eval else
                'dp_cell_budget' if self.cells+cost>self.limit_cells else
                'cpu_budget' if cpu>=self.limit_cpu else 'wall_budget' if wall>=self.limit_wall else None)
        if reason:
            self.denied={'reason':reason,'requested_cells':cost,'requested_phase':self.phase,'cpu_seconds':cpu,'wall_seconds':wall}
            raise BudgetStop(reason)
        # Debit the entire candidate before computing any cell.
        self.evaluations+=1; self.cells+=cost; self.by_phase[self.phase]+=1; self.cells_by_phase[self.phase]+=cost; self.by_length[len(perm)]+=1
        end=[0]*self.m
        for job in perm:
            previous=0
            for machine,duration in enumerate(self.p[job]):
                previous=max(end[machine],previous)+duration; end[machine]=previous
        value=end[-1]; self.completed_evaluations+=1; self.completed_cells+=cost
        if len(perm)==self.n and (self.best is None or value<self.best):
            self.best=value; self.best_perm=tuple(perm)
            self.trace.append({'evaluations':self.evaluations,'dp_cells':self.cells,'makespan':value,'phase':self.phase})
        return value

def neh(e):
    order=sorted(range(e.n),key=lambda j:(-sum(e.p[j]),j)); perm=[]; value=None
    for job in order:
        selected=None; selected_val=None
        for pos in range(len(perm)+1):
            candidate=perm[:pos]+[job]+perm[pos:]; objective=e.evaluate(candidate)
            # Earliest insertion index wins ties, then retain this exact partial permutation.
            if selected_val is None or objective<selected_val: selected=candidate; selected_val=objective
        perm=selected; value=selected_val
    return perm,value

def neighbors(perm,kind):
    n=len(perm)
    if kind=='swap':
        for i in range(n-1):
            for j in range(i+1,n):
                q=perm.copy(); q[i],q[j]=q[j],q[i]; yield q
    elif kind=='relocate':
        for i in range(n):
            for j in range(n):
                if i!=j:
                    q=perm.copy(); job=q.pop(i); q.insert(j,job); yield q
    else: raise ValueError('unknown neighborhood')

def vnd(e,perm,value,stats):
    while True:
        improved=False
        for kind in ('swap','relocate'):
            e.phase='VND_'+kind
            for q in neighbors(perm,kind):
                candidate=e.evaluate(q)
                if candidate<value:
                    perm,value=q,candidate; stats['accepted_'+kind]+=1; improved=True; break
            if improved: break
        if not improved:
            stats['local_optima_completed']+=1
            return perm,value

def perturb(perm,rng):
    positions=rng.sample(range(len(perm)),4); a,b,c,d=positions
    q=perm.copy(); q[a],q[b]=q[b],q[a]; q[c],q[d]=q[d],q[c]
    return q,positions

def solve(processing,algorithm,seed,limits=None):
    e=Evaluator(processing,**(limits or {})); rng=random.Random(seed); stats=Counter(); perturbations=[]
    status='completed'; stop='algorithm_complete'
    def alarm_handler(signum,frame):
        raise BudgetStop('hard_wall_alarm')
    prior=signal.signal(signal.SIGALRM,alarm_handler); signal.setitimer(signal.ITIMER_REAL,e.limit_wall)
    try:
        p,value=neh(e)
        if algorithm!='NEH':
            p,value=vnd(e,p,value,stats)
            if algorithm=='MS_VND':
                while True:
                    q=list(range(e.n)); rng.shuffle(q); e.phase='restart'; qval=e.evaluate(q); stats['restarts_started']+=1
                    vnd(e,q,qval,stats)
            elif algorithm=='ILS':
                while True:
                    q,positions=perturb(p,rng); e.phase='perturb'; qval=e.evaluate(q)
                    stats['perturbations_started']+=1
                    perturbations.append({'iteration':stats['perturbations_started'],'positions':positions,'base_makespan':value,'perturbed_makespan':qval})
                    q,qval=vnd(e,q,qval,stats)
                    if qval<=value:
                        stats['ils_accepted_equal' if qval==value else 'ils_accepted_better']+=1; p,value=q,qval
                    else: stats['ils_rejected_worse']+=1
            elif algorithm!='VND': raise ValueError('unknown algorithm')
    except BudgetStop as ex:
        status='budget_truncated'; stop=str(ex)
    except Exception as ex:
        status='failed'; stop=f'{type(ex).__name__}: {ex}'
    finally:
        signal.setitimer(signal.ITIMER_REAL,0); signal.signal(signal.SIGALRM,prior)
    cpu,wall=e.elapsed()
    return {'algorithm':algorithm,'seed':seed,'status':status,'stop_reason':stop,'makespan':e.best,
      'best_permutation':list(e.best_perm) if e.best_perm is not None else None,
      'evaluations':e.evaluations,'dp_cells':e.cells,'completed_evaluations':e.completed_evaluations,'completed_dp_cells':e.completed_cells,
      'evaluations_by_phase':dict(e.by_phase),'dp_cells_by_phase':dict(e.cells_by_phase),'evaluations_by_length':dict(e.by_length),
      'cpu_seconds':cpu,'wall_seconds':wall,'denied_evaluation':e.denied,'stats':dict(stats),'improvement_trace':e.trace,'perturbations':perturbations}
