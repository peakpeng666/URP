"""Parse saved official bytes; never execute downloaded content."""
import hashlib, json, pathlib, re
ROOT = pathlib.Path(__file__).resolve().parents[1]
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def parse_instances(text):
    lines = text.splitlines(); instances = []; i = 0
    while i < len(lines):
        if not lines[i].strip(): i += 1; continue
        if not lines[i].startswith('number of jobs, number of machines, initial seed, upper bound and lower bound'):
            raise ValueError(f'unexpected header at line {i+1}')
        n,m,seed,ub,lb = map(int, lines[i+1].split())
        if (n,m)!=(20,5): raise ValueError('unexpected dimensions')
        if lines[i+2].strip() != 'processing times :': raise ValueError('missing matrix marker')
        machine_rows = [list(map(int,lines[i+3+k].split())) for k in range(m)]
        if any(len(row)!=n or any(not 1<=v<=99 for v in row) for row in machine_rows):
            raise ValueError('invalid processing matrix')
        processing = [[machine_rows[k][j] for k in range(m)] for j in range(n)]
        instances.append(dict(id=f'ta{len(instances)+1:03d}', jobs=n,machines=m,generator_seed=seed,
            original_header_upper=ub,original_header_lower=lb,processing=processing,
            raw_header_line_1based=i+1,raw_machine_rows=machine_rows))
        i += 3+m
    if len(instances)!=10: raise ValueError('expected exactly 10 instances')
    return instances

def parse_reference(text):
    values=[]
    for label in ('ta001-005','ta006-010'):
        line=next(l for l in text.splitlines() if l.startswith(label))
        row=[int(x.strip()) for x in line[len(label):].split('|')]
        if len(row)!=5: raise ValueError('invalid reference row')
        values.extend(row)
    if values != [1278,1359,1081,1293,1235,1195,1234,1206,1230,1108]:
        raise ValueError('reference differs from frozen source verification; stop')
    return values

if __name__=='__main__':
    data=ROOT/'data'; instances=parse_instances((data/'tai20_5.txt').read_text())
    refs=parse_reference((data/'best_lb_up.txt').read_text())
    for inst,ref in zip(instances,refs): inst['source_reference']=ref
    (data/'instances.json').write_text(json.dumps(instances,indent=2)+'\n')
    evidence={'input_sha256':digest(data/'tai20_5.txt'),'reference_sha256':digest(data/'best_lb_up.txt'),
      'instance_count':len(instances),'dimensions':[20,5],'raw_layout':'machine x job',
      'solver_layout':'job x machine','transpose_rule':'processing[job][machine] = raw_machine_rows[machine][job]',
      'verified_reference_values':refs,'reference_header':(data/'best_lb_up.txt').read_text().splitlines()[0],
      'first_job_first_instance':instances[0]['processing'][0],
      'last_job_first_instance':instances[0]['processing'][-1],
      'total_processing_values':sum(len(row) for inst in instances for row in inst['processing']),
      'minimum':min(v for inst in instances for row in inst['processing'] for v in row),
      'maximum':max(v for inst in instances for row in inst['processing'] for v in row),
      'header_vs_reference_differences':[{'id':x['id'],'header_upper':x['original_header_upper'],'reference':x['source_reference']} for x in instances if x['original_header_upper']!=x['source_reference']]}
    (data/'parse_evidence.json').write_text(json.dumps(evidence,indent=2)+'\n'); print(json.dumps(evidence))
