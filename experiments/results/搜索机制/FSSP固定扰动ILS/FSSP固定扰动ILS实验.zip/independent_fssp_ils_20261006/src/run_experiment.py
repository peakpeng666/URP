import datetime,hashlib,json,os,pathlib,platform,sys,time
from solver import solve
ROOT=pathlib.Path(__file__).resolve().parents[1]
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
    freeze=json.loads((ROOT/'FREEZE.json').read_text())
    for relative,expected in freeze['sha256'].items():
        if sha(ROOT/relative)!=expected:raise RuntimeError('frozen input mismatch '+relative)
    cfg=json.loads((ROOT/'config.json').read_text()); instances=json.loads((ROOT/'data/instances.json').read_text())
    assert json.loads((ROOT/'tests/preflight.json').read_text())['passed']
    output=ROOT/'results/runs.jsonl'; old=[json.loads(x) for x in output.read_text().splitlines()] if output.exists() else []
    done={x['run_id'] for x in old}; assert len(done)==len(old),'duplicates in ledger'
    launch={'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'python':sys.version,'platform':platform.platform(),'pid':os.getpid(),'prior_runs':len(done),'freeze_sha256':sha(ROOT/'FREEZE.json')}
    with (ROOT/'results/launches.jsonl').open('a') as f:f.write(json.dumps(launch)+'\n')
    for inst in instances:
        specs=[('NEH',cfg['reference_seed']),('VND',cfg['reference_seed'])]+[(a,s) for s in cfg['main_search_seeds'] for a in ('MS_VND','ILS')]
        batch=[]
        for algorithm,seed in specs:
            rid=f"{inst['id']}__{algorithm}__{seed}"
            if rid in done:continue
            # Check immutable input bytes before every planned run.
            for name in ('data/tai20_5.txt','data/instances.json'):
                assert sha(ROOT/name)==freeze['sha256'][name]
            started=datetime.datetime.now(datetime.timezone.utc).isoformat()
            result=solve(inst['processing'],algorithm,seed,cfg['limits'])
            result.update(run_id=rid,instance=inst['id'],source_reference=inst['source_reference'],started_utc=started,
              gap_percent=None if result['makespan'] is None else 100*(result['makespan']/inst['source_reference']-1),
              frozen_config_sha256=freeze['sha256']['config.json'])
            with output.open('a') as f:f.write(json.dumps(result,separators=(',',':'))+'\n');f.flush();os.fsync(f.fileno())
            done.add(rid);batch.append({'algorithm':algorithm,'seed':seed,'makespan':result['makespan'],'stop':result['stop_reason'],'evaluations':result['evaluations']})
        if batch:print(json.dumps({'instance':inst['id'],'results':batch,'completed_total':len(done)}),flush=True)
    assert len(done)==cfg['nominal_runs']
if __name__=='__main__':main()
