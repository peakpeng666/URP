"""Post-run analysis, never imported by optimizer; unit = instance, not seed."""
import csv,itertools,json,pathlib,random,statistics,time
from collections import Counter
ROOT=pathlib.Path(__file__).resolve().parents[1]
def quantile(xs,p):
    x=sorted(xs); pos=(len(x)-1)*p; i=int(pos); f=pos-i
    return x[i]*(1-f)+x[min(i+1,len(x)-1)]*f

def main():
    t=time.process_time();cfg=json.loads((ROOT/'config.json').read_text()); rows=[json.loads(x) for x in (ROOT/'results/runs.jsonl').read_text().splitlines()]
    assert len(rows)==80 and len({x['run_id'] for x in rows})==80
    assert not [x for x in rows if x['status']=='failed']
    instances=sorted({x['instance'] for x in rows});summary=[]
    for inst in instances:
        r=[x for x in rows if x['instance']==inst]; obj={'instance':inst,'source_reference':r[0]['source_reference']}
        for alg in cfg['algorithms']:
            a=[x for x in r if x['algorithm']==alg]; assert len(a)==(3 if alg in ('MS_VND','ILS') else 1)
            for key in ('makespan','gap_percent','evaluations','dp_cells','cpu_seconds','wall_seconds'):
                obj[f'{alg}_{key}']=statistics.mean(x[key] for x in a)
            obj[f'{alg}_seed_makespans']=[x['makespan'] for x in a]
        obj['ILS_minus_MS_gap_pp']=obj['ILS_gap_percent']-obj['MS_VND_gap_percent']
        obj['ILS_minus_MS_makespan']=obj['ILS_makespan']-obj['MS_VND_makespan']
        summary.append(obj)
    diff=[x['ILS_minus_MS_gap_pp'] for x in summary]; effect=statistics.mean(diff)
    null=[statistics.mean(s*d for s,d in zip(signs,diff)) for signs in itertools.product((-1,1),repeat=10)]
    pvalue=sum(abs(t)>=abs(effect)-1e-12 for t in null)/len(null)
    rng=random.Random(cfg['statistical_bootstrap_seed']); bootstrap=[statistics.mean(rng.choices(diff,k=len(diff))) for _ in range(cfg['bootstrap_replicates'])]
    method={}
    for alg in cfg['algorithms']:
        r=[x for x in rows if x['algorithm']==alg]
        method[alg]={'runs':len(r),'mean_instance_gap_percent':statistics.mean(x[f'{alg}_gap_percent'] for x in summary),'mean_makespan':statistics.mean(x[f'{alg}_makespan'] for x in summary),
          'total_evaluations':sum(x['evaluations'] for x in r),'total_dp_cells':sum(x['dp_cells'] for x in r),
          'total_cpu_seconds':sum(x['cpu_seconds'] for x in r),'total_wall_seconds':sum(x['wall_seconds'] for x in r),
          'mean_evaluations':statistics.mean(x['evaluations'] for x in r),'mean_dp_cells':statistics.mean(x['dp_cells'] for x in r),
          'mean_cpu_seconds':statistics.mean(x['cpu_seconds'] for x in r),'mean_wall_seconds':statistics.mean(x['wall_seconds'] for x in r),
          'max_cpu_seconds':max(x['cpu_seconds'] for x in r),'max_wall_seconds':max(x['wall_seconds'] for x in r),
          'source_reference_hits':sum(x['makespan']==x['source_reference'] for x in r),'stop_reasons':dict(Counter(x['stop_reason'] for x in r)),
          'mean_stats':{k:statistics.mean(x['stats'].get(k,0) for x in r) for k in sorted({k for x in r for k in x['stats']})}}
    report={'statistical_unit':'10 independent dataset instances; three search seeds averaged within each instance','nominal_runs':80,'recorded_runs':len(rows),
      'method_summary':method,'main_comparison':{'effect_name':'ILS minus MS_VND gap, percentage points','mean_gap_difference_pp':effect,'median_gap_difference_pp':statistics.median(diff),
         'mean_makespan_difference':statistics.mean(x['ILS_minus_MS_makespan'] for x in summary),
         'instance_win_tie_loss':{'win':sum(x<-1e-12 for x in diff),'tie':sum(abs(x)<=1e-12 for x in diff),'loss':sum(x>1e-12 for x in diff)},
         'exact_paired_sign_flip_two_sided_p':pvalue,'sign_assignments':1024,'bootstrap_95_percentile_ci_pp':[quantile(bootstrap,.025),quantile(bootstrap,.975)],
         'bootstrap_seed':cfg['statistical_bootstrap_seed'],'bootstrap_resamples':cfg['bootstrap_replicates'],'interpretation':'exploratory small fixed benchmark; no universal superiority claim'},
      'resource_totals':{'evaluations':sum(x['evaluations'] for x in rows),'dp_cells':sum(x['dp_cells'] for x in rows),'cpu_seconds':sum(x['cpu_seconds'] for x in rows),'wall_seconds':sum(x['wall_seconds'] for x in rows),
        'max_cpu_per_run':max(x['cpu_seconds'] for x in rows),'max_wall_per_run':max(x['wall_seconds'] for x in rows),'status_counts':dict(Counter(x['status'] for x in rows)),
        'budget_predebit_reconstruction_pass':all(x['evaluations']==sum(x['evaluations_by_length'].values()) and x['dp_cells']==sum(int(k)*5*v for k,v in x['evaluations_by_length'].items()) for x in rows)},
      'analysis_cpu_seconds':time.process_time()-t}
    (ROOT/'results/summary.json').write_text(json.dumps(report,indent=2)+'\n')
    (ROOT/'results/per_instance.json').write_text(json.dumps(summary,indent=2)+'\n')
    with (ROOT/'results/per_instance.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(summary[0]));w.writeheader();w.writerows(summary)
    columns=['run_id','instance','algorithm','seed','status','stop_reason','makespan','source_reference','gap_percent','evaluations','dp_cells','cpu_seconds','wall_seconds','best_permutation']
    with (ROOT/'results/runs.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=columns);w.writeheader();w.writerows({k:x[k] for k in columns} for x in rows)
    print(json.dumps(report,indent=2))
if __name__=='__main__':main()
