"""Independent checker: no solver imports, constructs operation start/end records."""
import json,pathlib,time,hashlib

def checked_matrix(processing):
    if not processing or not processing[0]: raise ValueError('empty matrix')
    n=len(processing); m=len(processing[0])
    if any(len(row)!=m for row in processing): raise ValueError('ragged matrix')
    if any(type(v) is not int or v<=0 for row in processing for v in row): raise ValueError('invalid duration')
    return n,m

def schedule(processing,permutation):
    n,m=checked_matrix(processing)
    if len(permutation)!=n or any(type(j) is not int for j in permutation) or set(permutation)!=set(range(n)):
        raise ValueError('not a permutation')
    machine_available=[0]*m; job_available=[0]*n; operations=[]
    for position,job in enumerate(permutation):
        for machine in range(m):
            start=max(machine_available[machine],job_available[job]); end=start+processing[job][machine]
            operations.append({'position':position,'job':job,'machine':machine,'start':start,'end':end})
            machine_available[machine]=end; job_available[job]=end
    return max(job_available),operations

def verify(processing,permutation,claimed,operations=None):
    n,m=checked_matrix(processing)
    expected,canonical=schedule(processing,permutation)
    if type(claimed) is not int or claimed!=expected: raise ValueError('makespan mismatch')
    records=canonical if operations is None else operations
    if len(records)!=n*m: raise ValueError('wrong operation count')
    lookup={}
    for op in records:
        job=op['job']; machine=op['machine']; key=(job,machine)
        if key in lookup or not 0<=job<n or not 0<=machine<m: raise ValueError('invalid operation identity')
        if op['position']!=permutation.index(job): raise ValueError('wrong permutation position')
        if type(op['start']) is not int or type(op['end']) is not int: raise ValueError('noninteger time')
        if op['start']<0 or op['end']-op['start']!=processing[job][machine]: raise ValueError('duration error')
        lookup[key]=op
    for job in range(n):
        for machine in range(1,m):
            if lookup[job,machine]['start']<lookup[job,machine-1]['end']: raise ValueError('job precedence')
    for machine in range(m):
        previous=0
        for job in permutation:
            op=lookup[job,machine]
            if op['start']<previous: raise ValueError('machine overlap')
            previous=op['end']
    if max(op['end'] for op in records)!=claimed: raise ValueError('schedule makespan error')
    if records!=canonical: raise ValueError('not canonical earliest-start schedule')
    return {'valid':True,'makespan':expected,'operations':canonical,'operations_checked':n*m}

if __name__=='__main__':
    root=pathlib.Path(__file__).resolve().parents[1]; t=time.perf_counter(); cpu=time.process_time()
    instances={x['id']:x for x in json.loads((root/'data/instances.json').read_text())}
    results=[json.loads(line) for line in (root/'results/runs.jsonl').read_text().splitlines()]
    accepted=[]; failed=[]; schedules=[]
    for row in results:
        if row.get('best_permutation') is None: failed.append({'run_id':row['run_id'],'error':'missing result'}); continue
        try:
            result=verify(instances[row['instance']]['processing'],row['best_permutation'],row['makespan'])
            schedules.append({'run_id':row['run_id'],**result}); accepted.append(row['run_id'])
        except (ValueError,KeyError) as e: failed.append({'run_id':row['run_id'],'error':str(e)})
    (root/'results/verified_schedules.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in schedules))
    audit={'nominal_runs':80,'recorded_runs':len(results),'unique_run_ids':len({x['run_id'] for x in results}),
       'accepted':len(accepted),'failed':failed,'operations_checked':sum(x['operations_checked'] for x in schedules),
       'checker_cpu_seconds':time.process_time()-cpu,'checker_wall_seconds':time.perf_counter()-t,
       'runs_sha256':hashlib.sha256((root/'results/runs.jsonl').read_bytes()).hexdigest()}
    (root/'results/checker_audit.json').write_text(json.dumps(audit,indent=2)+'\n'); print(json.dumps(audit))
    if failed or len(results)!=80 or len(accepted)!=80 or audit['unique_run_ids']!=80: raise SystemExit(1)
