"""Native SVG scientific figures from saved results; standard library only."""
import html,json,pathlib
R=pathlib.Path(__file__).resolve().parents[1]
S=json.loads((R/'results/summary.json').read_text()); P=json.loads((R/'results/per_instance.json').read_text()); runs=[json.loads(x) for x in (R/'results/runs.jsonl').read_text().splitlines()]
colors={'NEH':'#8c98a5','VND':'#d99628','MS_VND':'#3d6dad','ILS':'#147d64'}
class SVG:
    def __init__(self,w,h,title,desc):
        self.out=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}" role="img"><title>{html.escape(title)}</title><desc>{html.escape(desc)}</desc><rect width="100%" height="100%" fill="white"/>', '<style>text{font-family:Arial,DejaVu Sans,sans-serif;fill:#263445} .small{font-size:13px}.axis{font-size:14px}.label{font-size:16px}.title{font-size:25px;font-weight:700}.sub{font-size:17px;font-weight:600}</style>']
    def text(self,x,y,s,cl='axis',anchor='start',fill=None): self.out.append(f'<text x="{x}" y="{y}" class="{cl}" text-anchor="{anchor}"'+(f' style="fill:{fill}"' if fill else '')+'>'+html.escape(str(s))+'</text>')
    def line(self,x1,y1,x2,y2,stroke='#dce3e8',width=1):self.out.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{stroke}" stroke-width="{width}"/>')
    def circle(self,x,y,r,c,opacity=1):self.out.append(f'<circle cx="{x}" cy="{y}" r="{r}" fill="{c}" opacity="{opacity}"/>')
    def rect(self,x,y,w,h,c):self.out.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{c}"/>')
    def poly(self,pts,c,w=2):self.out.append('<polyline points="'+' '.join(f'{x},{y}' for x,y in pts)+f'" fill="none" stroke="{c}" stroke-width="{w}"/>')
    def save(self,path):path.write_text('\n'.join(self.out)+"</svg>\n")

f=SVG(1200,870,'Fixed-budget permutation flow-shop comparison','Taillard ta001-ta010, 20 jobs x 5 machines; all planned 80 runs; seed means within each instance. Lower makespan is better.')
f.text(45,45,'Fixed-budget flow-shop comparison','title');f.text(45,75,'Taillard 20 x 5 | 10 instances | 3 frozen search seeds per main arm','label')
f.text(75,117,'A  Gap to source reference by instance (%)','sub')
x0=90;x1=1115;y0=410;y1=155
for t in range(0,9,2):
    y=y0-(y0-y1)*t/8;f.line(x0,y,x1,y);f.text(x0-15,y+5,str(t),'axis','end')
for i,p in enumerate(P):f.text(x0+(x1-x0)*i/9,y0+26,p['instance'],'axis','middle')
for alg in colors:
    pts=[(x0+(x1-x0)*i/9,y0-(y0-y1)*p[alg+'_gap_percent']/8) for i,p in enumerate(P)];f.poly(pts,colors[alg]);
    for x,y in pts:f.circle(x,y,4,colors[alg])
for i,alg in enumerate(colors):
    x=140+i*245;f.line(x,475,x+25,475,colors[alg],3);f.text(x+34,480,f'{alg}: {S["method_summary"][alg]["mean_instance_gap_percent"]:.3f}%','axis')
f.text(75,531,'B  ILS minus MS_VND gap (percentage points)','sub');f.text(75,555,'Below zero favors ILS; instance means, not best seeds','small')
x0=95;x1=655;y0=590;y1=750
for d in [0,-.5,-1,-1.5]:
    y=y0+(-d)/1.5*(y1-y0);f.line(x0,y,x1,y);f.text(x0-10,y+4,f'{d:.1f}','small','end')
for i,p in enumerate(P):
    x=x0+25+i*54; d=p['ILS_minus_MS_gap_pp']; h=-d/1.5*(y1-y0)
    if h:f.rect(x-12,y0,24,h,colors['ILS'])
    else:f.circle(x,y0,3,colors['MS_VND'])
    f.text(x,779,p['instance'][-2:],'small','middle')
f.text(735,531,'C  Actual DP cells per run','sub');f.text(735,555,'Partial NEH evaluations charged by length','small')
for i,alg in enumerate(colors):
    y=580+i*48;v=S['method_summary'][alg]['mean_dp_cells'];f.text(735,y+15,alg,'axis');f.rect(815,y,230*v/500000,20,colors[alg]);f.text(1055,y+15,f'{v:,.0f}','axis')
f.text(45,830,'Main arms: 5,000 evaluations / 493,350 DP cells each | 80/80 schedules verified | 0 failed runs','axis')
f.text(45,853,'Exploratory: 5 wins / 5 ties / 0 losses; exact paired sign-flip p = 0.0625. Source reference is not an implementation oracle.','small')
f.save(R/'figures/main_results.svg')

f=SVG(1200,710,'All frozen seed results','Every main-arm run is shown, with three small points and one larger within-instance mean. No best-seed selection.')
f.text(45,45,'All frozen seed results','title');f.text(45,74,'Gap to source reference (%) | small points: all 3 seeds | large dot: mean','label')
x0=100;x1=1100;y0=565;y1=130
for tick in range(5):
    y=y0-(y0-y1)*tick/4;f.line(x0,y,x1,y);f.text(x0-15,y+5,str(tick),'axis','end')
for i,p in enumerate(P):
    cx=x0+35+i*(x1-x0-70)/9;f.text(cx,y0+30,p['instance'],'axis','middle')
    for alg,dx in [('MS_VND',-15),('ILS',15)]:
        vals=[r['gap_percent'] for r in runs if r['instance']==p['instance'] and r['algorithm']==alg]
        for j,v in enumerate(vals):f.circle(cx+dx+(j-1)*6,y0-(y0-y1)*v/4,3.4,colors[alg],.55)
        mean=p[alg+'_gap_percent'];f.circle(cx+dx,y0-(y0-y1)*mean/4,5.4,colors[alg])
for i,a in enumerate(('MS_VND','ILS')):
    x=330+i*300;f.circle(x,632,6,colors[a]);f.text(x+14,638,a,'label')
f.text(45,682,'Search seeds: 610064101, 610064102, 610064103. Statistical unit: 10 instances after averaging seeds.','axis')
f.save(R/'figures/seed_detail.svg')

rid='ta001__ILS__610064101'; sch=next(json.loads(x) for x in (R/'results/verified_schedules.jsonl').read_text().splitlines() if json.loads(x)['run_id']==rid)
f=SVG(1300,615,'Verified permutation flow-shop schedule','First instance, first frozen ILS seed; all 100 operations reconstructed from original processing matrix and independently checked.')
f.text(45,45,'Verified schedule example','title');f.text(45,75,'ta001 | ILS | first frozen seed 610064101 | makespan 1278','label')
x0=100;scale=1120/1278;y0=130
for t in range(0,1300,200):
    x=x0+t*scale;f.line(x,115,x,475);f.text(x,505,t,'axis','middle')
for machine in range(5):
    y=y0+machine*68;f.text(78,y+30,f'M{machine+1}','label','end')
    for op in sch['operations']:
        if op['machine']!=machine:continue
        col=f'hsl({(op["job"]*137.508)%360:.1f},48%,70%)';xx=x0+op['start']*scale;ww=(op['end']-op['start'])*scale;f.rect(xx,y,ww,45,col)
        if ww>24:f.text(xx+ww/2,y+28,op['job']+1,'small','middle')
f.text(660,539,'Processing time units','label','middle')
f.text(45,576,'Same job order on every machine. Labels are one-based job IDs; audit data use zero-based IDs.','axis')
f.text(45,598,'First-instance illustration only; does not replace the full 80-run checker ledger.','small')
f.save(R/'figures/schedule_example.svg')
print('Wrote 3 native SVG figures')
