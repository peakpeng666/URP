import copy,itertools,json,pathlib,random,sys,time
sys.path.insert(0,str(pathlib.Path(__file__).parent))
from solver import Evaluator,BudgetStop,neh,neighbors,vnd,perturb,solve
from checker import schedule,verify
from collections import Counter
ROOT=pathlib.Path(__file__).resolve().parents[1]

def expect_error(fn):
    try: fn()
    except (ValueError,BudgetStop): return True
    raise AssertionError('negative case incorrectly accepted')

def main():
    cpu=time.process_time(); wall=time.perf_counter(); cfg=json.loads((ROOT/'config.json').read_text()); cases=[]; tests=[]
    for seed in cfg['small_case_seeds']:
        rng=random.Random(seed); p=[[rng.randint(1,20) for _ in range(3)] for _ in range(6)]; original=copy.deepcopy(p)
        ev=Evaluator(p,max_evaluations=10000,max_cells=1000000); values=[]; best=None
        for perm in itertools.permutations(range(6)):
            v,ops=schedule(p,perm); assert ev.evaluate(perm)==v; assert verify(p,list(perm),v,ops)['valid']; values.append(v)
            if best is None or v<best[0]: best=(v,list(perm))
        assert len(values)==720
        for alg in cfg['algorithms']:
            out=solve(p,alg,610064777)
            assert out['makespan']>=best[0]; assert verify(p,out['best_permutation'],out['makespan'])['valid']
        assert p==original
        cases.append({'seed':seed,'processing':p,'permutations_checked':720,'exact_makespan':best[0],'exact_permutation':best[1],'max_makespan':max(values)})
    tests.append('4 x 720 complete permutations: DP equals independently scheduled makespan')
    # Explicit hand-computed 3-job example: C=[2,5]; [6,7]; [9,11].
    e=Evaluator([[2,3],[4,1],[3,2]]); assert e.evaluate([0,1,2])==11
    tests.append('hand computed 3x2 makespan = 11')
    full=json.loads((ROOT/'data/instances.json').read_text())[0]['processing']; e=Evaluator(full); perm,val=neh(e)
    assert (e.evaluations,e.cells)==(210,14350); verify(full,perm,val)
    tests.append('NEH partial schedules count = 210, DP cells = 14350')
    for e in (Evaluator([[1,2],[3,4]],max_evaluations=0),Evaluator([[1,2],[3,4]],max_cells=3)):
        expect_error(lambda:e.evaluate([0,1])); assert e.evaluations==e.cells==0
    e=Evaluator([[1,2],[3,4]],max_evaluations=1,max_cells=4); assert e.evaluate([0,1])==8
    expect_error(lambda:e.evaluate([0,1])); assert (e.evaluations,e.cells)==(1,4)
    for expected,clock in [('cpu_budget',(4,0)),('wall_budget',(0,9))]:
        e=Evaluator([[1,2]]); e.elapsed=lambda:clock
        try:e.evaluate([0])
        except BudgetStop as ex: assert str(ex)==expected
        else:raise AssertionError('time budget failure')
        assert e.evaluations==e.cells==0
    tests.append('candidate, DP, CPU, wall pre-debit denial boundaries')
    q=list(range(6)); assert len(list(neighbors(q,'swap')))==15; assert len(list(neighbors(q,'relocate')))==30
    for kind in ('swap','relocate'):
        assert all(set(r)==set(q) and r!=q for r in neighbors(q,kind))
    e=Evaluator(cases[0]['processing'],max_evaluations=20000,max_cells=1000000); p,val=neh(e); p,val=vnd(e,p,val,Counter())
    for kind in ('swap','relocate'): assert all(e.evaluate(r)>=val for r in neighbors(p,kind))
    tests.append('neighborhood enumeration and completed VND local optimality')
    rng=random.Random(610064999)
    for _ in range(1000):
        r,pos=perturb(q,rng); assert len(set(pos))==4; assert set(r)==set(q); assert sum(a!=b for a,b in zip(q,r))==4
    tests.append('1000 disjoint double swaps change exactly four positions')
    p=[[2,3],[4,1],[3,2]]; perm=[0,1,2]; value,ops=schedule(p,perm)
    bads=[lambda:verify(p,[0,0,2],value),lambda:verify(p,[0,1],value),lambda:verify(p,[0,1,9],value),lambda:verify(p,perm,value+1),lambda:verify([[1],[1,2]],perm,value)]
    # Duration corruption, job precedence, machine overlap, missing operation, duplicate identity, wrong position.
    corrupted=[]
    a=copy.deepcopy(ops);a[0]['end']+=1;corrupted.append(a)
    a=copy.deepcopy(ops);a[1]['start']=0;a[1]['end']=3;corrupted.append(a)
    a=copy.deepcopy(ops);a[2]['start']=0;a[2]['end']=4;corrupted.append(a)
    corrupted.append(ops[:-1]); corrupted.append(ops[:-1]+[ops[0]])
    a=copy.deepcopy(ops);a[0]['position']=1;corrupted.append(a)
    for fn in bads:expect_error(fn)
    for a in corrupted:expect_error(lambda:verify(p,perm,value,a))
    tests.append('11 malformed permutation/matrix/makespan/timing cases rejected')
    report={'passed':True,'tests':tests,'small_cases':cases,'exact_permutation_comparisons':2880,'negative_cases':11,'preflight_cpu_seconds':time.process_time()-cpu,'preflight_wall_seconds':time.perf_counter()-wall}
    (ROOT/'tests/preflight.json').write_text(json.dumps(report,indent=2)+'\n'); print(json.dumps(report))
if __name__=='__main__': main()
