# FSSP固定算法机制对照 预先冻结方案

## 问题与边界
在dot当前云端、独立目录和无第三方包venv，比较10个Taillard 20工件×5机器排列流水车间实例。原始加工时间不可变，目标为最后工件在最后机器的完成时间（makespan，越小越好）。所有机器使用同一工件排列。零LLM调用，不运行作者下载程序，不访问旧holdout或bin-packing实验，不更改全局依赖。

本实验依据EoH附录FSSP宿主和经典NEH构造方法，验证固定算法机制；自定ILS不是作者ILS1/ILS2的精确复现，也不是完整EoH搜索或P5全部完成。

## 数据与来源
- 作者实例：https://mistic.iict-heig-vd.ch/taillard/problemes.dir/ordonnancement.dir/flowshop.dir/tai20_5.txt
- 作者参考界：https://mistic.iict-heig-vd.ch/taillard/problemes.dir/ordonnancement.dir/flowshop.dir/best_lb_up.txt
- 作者索引：https://mistic.iict-heig-vd.ch/taillard/problemes.dir/ordonnancement.dir/ordonnancement.html
- NEH原论文：Nawaz, Enscore, Ham (1983), A heuristic algorithm for the m-machine, n-job flow-shop sequencing problem, DOI https://doi.org/10.1016/0305-0483(83)90088-9
- EoH：Liu et al. (2024), Evolution of Heuristics, PMLR 235，附录PDF21–23页D.2/D.3、Fig10、Table12；https://proceedings.mlr.press/v235/liu24bs.html

保存官方原始字节、抓取时间、SHA256、原始machine×job和显式转置job×machine。10组各100个整数均须在1..99。来源参考值仅供事后gap对照，不向优化器传入，不作停止、调参或筛选依据。使用参考文件标注Update : 03.06.2026的前10个值，仅称“来源参考值”，不以其替代实现正确性证明。实例原header历史UB另存（ta005 1236、ta007 1239）且不冒充更新参考（1235、1234）。

## 冻结方法
NEH：按每工件加工总时长降序，同总时长以原0-based工件ID升序。由空排列逐个插入；每次完整枚举插入位置0..k，makespan最小优先，同值保留最早插入位置。长度1也评价，20工件共210次候选、14350 DP单元更新。

VND：从该次重新计费构造的NEH出发。顺序swap再relocate。swap按(i,j)字典序且i<j；relocate按(i,j)字典序且i!=j，在pop(i)后insert(j)。相邻移动可能与swap重复，明确不去重，仍每次计费。采用first strict improvement，改善后从swap重新开始；两邻域均无严格改善才认定局部最优。同makespan邻居不接受。

MS_VND主臂：完成NEH+VND第一起点后，用该run独有Random(seed)均匀shuffle所有工件作为新起点，评价后VND；重复到预算。每个重启独立，保留全程最好完整排列。

ILS主臂：同样完成NEH+VND第一起点。每次rng.sample(range(20),4)得到四个不同位置(a,b,c,d)，分别swap(a,b)及swap(c,d)，排除两次交换互相撤销。评价扰动后做同一VND；局部最优makespan<=当前时接受（等值允许漂移），更差则拒绝并回到旧当前解；不另加随机重启。保留全程原矩阵评价的最好完整排列。记录每次扰动位置与分值。

所有算法的全局best只在严格改善时更新，同值保留首次发现的排列；中途截断时也保留所有已完成完整候选中的最好结果。

## 样本与公平预算
config.json预先固定三个新搜索seed，每个seed同时用于MS_VND及ILS；两臂随机消耗流自然不同，seed是重复索引，不能解读为相同随机轨迹。4个新6工件小例seed只用于预检。参考NEH和单次VND各10run；两主臂各10×3run，合计80。

每个run从开始计时，含NEH成本；最多5000个候选、500000个DP单元、3秒CPU、8秒wall。每次评价前扣候选与len(permutation)×machines单元预算；部分排列与完整排列分别按真实单元计费。不缓存相同排列。CPU/wall每次评价前检查，wall另由单进程SIGALRM硬中断；报告实际CPU/wall以及扣费与完成数，若中断发生在评价内两者可能不同。NEH/VND允许算法自然结束；两主臂运行到预算，不补齐其他方法不用的预算。主比较只在两主臂进行，参考臂不能据较少花费作等预算归因。

正式总上限：80run，400000候选、40000000 DP单元、240 CPU秒、640 wall秒（不含I/O/预检/checker/统计/作图）。单实验只有一个计算进程。无并发run。达到逐run预算即保存截断原因和best，任何失败保留，不更换seed或补样。脚本只能补执行未写记录的预定run，已有失败run不重试。数据/代码/config冻结哈希不一致则中止。

## 实现正确性门槛
正式运行前，4个新6×3整数小例，各720排列，用独立checker构造start/end，和求解器makespan逐排列对照；穷举min给出独立精确自检，不使用官方参考值作为真值。验证邻域覆盖与排列合法、局部最优、NEH计费、预算pre-debit边界、扰动四位置、重复/丢失工件、错误makespan、工序违例、机器重叠、非法时序等负向案例。

正式80run落盘后，独立checker重新读取原矩阵、完整排列和claimed makespan，重建每工件每机器最早start/end；验证排列唯一、加工时长、工序优先、机器不重叠、同排列与makespan。输出80套可复查时序、总验收和checker独立CPU/wall。预检成本单列。

## 统计和输出
每seed报告makespan及100×(makespan/reference−1)。先在实例内平均3seed，再以10实例为统计单位；报告四方法实例平均、ILS相对MS_VND逐实例胜平负、配对差均值/中位数。预先固定两侧精确配对符号翻转均值检验（2^10符号），以及10000次配对实例bootstrap百分位95%区间，均属小样本探索性说明，不视为跨问题普遍结论。图展示全部10实例和3seed，不选择最好seed代替均值。CPU仅作实际开销描述，不在小规模短run上推断稳定速度排名。

交付：原始官方文本、解析证据、config、冻结哈希、源码、测试、80run账本、80套时序、统计CSV/JSON、研究图、中文报告与压缩包。仅本地，由主线程审阅后统一上传。
