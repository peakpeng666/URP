"""Independent, single-process, stdlib audit. Never calls solve or modifies frozen/results files."""
import collections, datetime, hashlib, itertools, json, math, pathlib, random, statistics, sys, time
from fractions import Fraction
ROOT=pathlib.Path(__file__).resolve().parent
sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT/'src'))
from solver import Evaluator,BudgetStop,neh,neighbors,perturb
from checker import verify
started_cpu=time.process_time(); started_wall=time.perf_counter()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads((ROOT/p).read_text())
def lines(p):return [json.loads(s) for s in (ROOT/p).read_text().splitlines()]
def close(a,b):assert math.isclose(a,b,rel_tol=1e-11,abs_tol=1e-10),(a,b)
def independent_schedule(p,perm):
    # Full 2D operation grid, not solver rolling array or checker per-job availability.
    n=len(perm);m=len(p[0]);finish=[[0]*(m+1) for _ in range(n+1)];ops=[]
    for row,j in enumerate(perm,1):
        for col in range(1,m+1):
            start=max(finish[row-1][col],finish[row][col-1]);end=start+p[j][col-1]
            finish[row][col]=end
            ops.append(dict(position=row-1,job=j,machine=col-1,start=start,end=end))
    return finish[n][m],ops
freeze=read('FREEZE.json');cfg=read('config.json');rows=lines('results/runs.jsonl');audit=read('results/checker_audit.json');preflight=read('tests/preflight.json')
protected={rel:sha(ROOT/rel) for rel in freeze['sha256']}
assert protected==freeze['sha256']
protected.update({str(p.relative_to(ROOT)):sha(p) for p in (ROOT/'results').iterdir() if p.is_file()})
protected['FREEZE.json']=sha(ROOT/'FREEZE.json')
assert sha(ROOT/'results/runs.jsonl')==audit['runs_sha256']
launches=lines('results/launches.jsonl');assert len(launches)==1 and launches[0]['prior_runs']==0
assert launches[0]['freeze_sha256']==sha(ROOT/'FREEZE.json')
assert datetime.datetime.fromisoformat(freeze['frozen_utc'])<datetime.datetime.fromisoformat(launches[0]['started_utc'])
# Reparse authoritative local raw bytes without calling prepare_data.
raw=(ROOT/'data/tai20_5.txt').read_text().splitlines();headers=[i for i,l in enumerate(raw) if l.startswith('number of jobs')]
assert len(headers)==10
stored=read('data/instances.json');matrices={};refs=[];header_diffs=[]
for i,l in enumerate((ROOT/'data/best_lb_up.txt').read_text().splitlines()):
    if l.startswith(('ta001-005','ta006-010')): refs.extend(map(int,l[9:].replace('|',' ').split()))
assert refs==[1278,1359,1081,1293,1235,1195,1234,1206,1230,1108]
for idx,start in enumerate(headers):
    n,m,seed,ub,lb=map(int,raw[start+1].split());assert(n,m)==(20,5)
    source_machine=[list(map(int,raw[start+3+k].split())) for k in range(m)]
    assert len(source_machine)==5 and all(len(v)==20 for v in source_machine)
    assert all(1<=v<=99 for r in source_machine for v in r)
    p=[list(t) for t in zip(*source_machine)];x=stored[idx];name=f'ta{idx+1:03d}'
    assert x['id']==name and x['processing']==p and x['raw_machine_rows']==source_machine
    assert(x['jobs'],x['machines'],x['generator_seed'],x['original_header_upper'],x['original_header_lower'])==(n,m,seed,ub,lb)
    assert x['source_reference']==refs[idx] and x['raw_header_line_1based']==start+1
    matrices[name]=p
    if ub!=refs[idx]:header_diffs.append(dict(instance=name,header_upper=ub,source_reference=refs[idx]))
assert len(stored)==10
for entry in read('data/provenance.json')['official_downloads']:
    assert sha(ROOT/entry['file'])==entry['sha256'] and (ROOT/entry['file']).stat().st_size==entry['bytes']
expected=[]
for name in matrices:
    expected.extend(f'{name}__{alg}__{seed}' for alg,seed in [('NEH',0),('VND',0)]+[(a,s) for s in cfg['main_search_seeds'] for a in ('MS_VND','ILS')])
assert [r['run_id'] for r in rows]==expected and len(set(expected))==80
assert audit['accepted']==audit['recorded_runs']==audit['unique_run_ids']==80 and audit['failed']==[] and audit['operations_checked']==8000
saved_schedules=lines('results/verified_schedules.jsonl');assert len(saved_schedules)==80
schedules={r['run_id']:r for r in saved_schedules};assert set(schedules)==set(expected)
record_counts=collections.Counter();hit_continued=[];perturb_checks=0;local_neighbor_checks=0
for r in rows:
    record_counts[r['algorithm']]+=1;p=matrices[r['instance']];q=r['best_permutation'];ref=refs[int(r['instance'][2:])-1]
    assert len(q)==20 and all(type(j) is int for j in q) and sorted(q)==list(range(20))
    value,ops=independent_schedule(p,q);assert value==r['makespan']
    saved=schedules[r['run_id']];assert saved['operations']==ops and saved['makespan']==value and saved['valid'] and saved['operations_checked']==100
    assert r['source_reference']==ref;close(r['gap_percent'],100*(value/ref-1))
    assert r['frozen_config_sha256']==freeze['sha256']['config.json']
    assert r['evaluations']==sum(r['evaluations_by_length'].values())==sum(r['evaluations_by_phase'].values())==r['completed_evaluations']
    assert r['dp_cells']==sum(int(k)*5*v for k,v in r['evaluations_by_length'].items())==sum(r['dp_cells_by_phase'].values())==r['completed_dp_cells']
    assert r['evaluations']<=5000 and r['dp_cells']<=500000 and 0<=r['cpu_seconds']<3 and 0<=r['wall_seconds']<8
    assert r['evaluations_by_phase']['NEH']==210 and r['dp_cells_by_phase']['NEH']==14350
    assert all(r['evaluations_by_length'][str(k)]==k for k in range(1,20))
    assert r['dp_cells']==14350+100*(r['evaluations']-210)
    for phase,count in r['evaluations_by_phase'].items():
        if phase!='NEH':assert r['dp_cells_by_phase'][phase]==100*count
    trace=r['improvement_trace'];assert trace[-1]['makespan']==value
    for t in trace:
        assert 191<=t['evaluations']<=r['evaluations'] and t['dp_cells']==100*t['evaluations']-6650
    assert all(a['evaluations']<b['evaluations'] and a['makespan']>b['makespan'] for a,b in zip(trace,trace[1:]))
    if r['algorithm'] in ('MS_VND','ILS'):
        assert r['status']=='budget_truncated' and r['stop_reason']=='candidate_budget'
        assert r['evaluations']==5000 and r['dp_cells']==493350
        assert r['denied_evaluation']['reason']=='candidate_budget' and r['denied_evaluation']['requested_cells']==100
        hits=[t for t in trace if t['makespan']==ref]
        if hits and hits[0]['evaluations']<5000:hit_continued.append(dict(run_id=r['run_id'],hit_at=hits[0]['evaluations'],finished_at=5000))
    else:assert r['status']=='completed' and r['stop_reason']=='algorithm_complete' and r['denied_evaluation'] is None
    if r['algorithm']=='NEH':assert r['evaluations']==210 and r['dp_cells']==14350
    if r['algorithm']=='MS_VND':
        assert r['perturbations']==[] and r['stats']['restarts_started']==r['evaluations_by_phase']['restart']
        assert r['stats']['local_optima_completed'] in (r['stats']['restarts_started'],r['stats']['restarts_started']+1)
    if r['algorithm']=='ILS':
        rr=random.Random(r['seed']);assert len(r['perturbations'])==r['stats']['perturbations_started']==r['evaluations_by_phase']['perturb']
        for j,t in enumerate(r['perturbations'],1):
            assert t['positions']==rr.sample(range(20),4) and len(set(t['positions']))==4 and t['iteration']==j
            perturb_checks+=1
        accepted=sum(r['stats'].get(k,0) for k in ('ils_accepted_equal','ils_accepted_better','ils_rejected_worse'))
        assert accepted==r['stats']['local_optima_completed']-1 and accepted in (len(r['perturbations']),len(r['perturbations'])-1)
    if r['algorithm']=='VND':
        # Independent final-neighborhood construction; not executing local search.
        candidates=[]
        for i in range(20):
            for j in range(i+1,20):
                z=q[:];z[i],z[j]=z[j],z[i];candidates.append(z)
            for j in range(20):
                if i!=j:
                    z=q[:];v=z.pop(i);z=z[:j]+[v]+z[j:];candidates.append(z)
        assert len(candidates)==570
        assert all(independent_schedule(p,z)[0]>=value for z in candidates);local_neighbor_checks+=len(candidates)
assert record_counts=={'NEH':10,'VND':10,'MS_VND':30,'ILS':30}
# Dynamic unit-level budget and tie checks, with synthetic input only; never call solve.
e=Evaluator([[1]*5 for _ in range(20)]);seq,v=neh(e)
assert(e.evaluations,e.cells)==(210,14350) and seq==list(reversed(range(20)))
assert e.by_length==collections.Counter({k:k for k in range(1,21)})
checks=[]
def denied(e,p,reason):
    before=(e.evaluations,e.cells,e.completed_evaluations,e.completed_cells)
    try:e.evaluate(p)
    except BudgetStop as ex:assert str(ex)==reason
    else:raise AssertionError('candidate wrongly accepted')
    assert before==(e.evaluations,e.cells,e.completed_evaluations,e.completed_cells);checks.append(reason)
denied(Evaluator([[1,2],[3,4]],max_evaluations=0),[0,1],'candidate_budget')
denied(Evaluator([[1,2],[3,4]],max_cells=3),[0,1],'dp_cell_budget')
e=Evaluator([[1,2],[3,4]],max_evaluations=1,max_cells=4);assert e.evaluate([0,1])==8;denied(e,[0,1],'candidate_budget')
e=Evaluator([[1,2],[3,4]],max_evaluations=3,max_cells=4);assert e.evaluate([0,1])==8;denied(e,[0,1],'dp_cell_budget')
for reason,clock in [('cpu_budget',(3,0)),('wall_budget',(0,8))]:
    e=Evaluator([[1,1]]);e.elapsed=lambda:clock;denied(e,[0],reason)
class DeliberateInterrupt(Exception):pass
class InterruptedRows:
    def __getitem__(self,k):raise DeliberateInterrupt()
e=Evaluator([[1,2],[3,4]]);e.p=InterruptedRows()
try:e.evaluate([0,1])
except DeliberateInterrupt:pass
else:raise AssertionError('injected interruption missing')
assert(e.evaluations,e.cells,e.completed_evaluations,e.completed_cells)==(1,4,0,0)
# Differential independent exhaustive audit of four existing synthetic cases, no search rerun.
small=[]
for c in preflight['small_cases']:
    rr=random.Random(c['seed']);p=[[rr.randint(1,20) for _ in range(3)] for _ in range(6)];assert p==c['processing']
    vals=[independent_schedule(p,q)[0] for q in itertools.permutations(range(6))]
    assert len(vals)==720 and min(vals)==c['exact_makespan'] and max(vals)==c['max_makespan']
    assert independent_schedule(p,c['exact_permutation'])[0]==min(vals)
    small.append(dict(seed=c['seed'],permutations=720,minimum=min(vals),maximum=max(vals)))
# Verify enumeration order and all allowed positions independently.
q=list(range(6));expected_swap=[];expected_reloc=[]
for i in range(6):
    for j in range(i+1,6):
        z=q[:];z[i],z[j]=z[j],z[i];expected_swap.append(z)
    for j in range(6):
        if i!=j:
            z=q[:i]+q[i+1:];z=z[:j]+[q[i]]+z[j:];expected_reloc.append(z)
assert list(neighbors(q,'swap'))==expected_swap and list(neighbors(q,'relocate'))==expected_reloc
assert len(expected_swap)==15 and len(expected_reloc)==30
r1=random.Random(610064999);r2=random.Random(610064999)
for _ in range(1000):
    z,pos=perturb(q,r1);assert pos==r2.sample(range(6),4);w=q[:];a,b,c,d=pos;w[a],w[b]=w[b],w[a];w[c],w[d]=w[d],w[c]
    assert w==z and sorted(z)==q and sum(a!=b for a,b in zip(z,q))==4
# Recompute inference from integer outcomes with exact fractions, not published gap values.
method_gaps={a:[] for a in cfg['algorithms']};diff=[];instance_differences=[]
for name in matrices:
    by={a:[r for r in rows if r['instance']==name and r['algorithm']==a] for a in cfg['algorithms']};ref=by['ILS'][0]['source_reference']
    means={a:sum(Fraction(r['makespan']) for r in by[a])/len(by[a]) for a in by}
    for a in by:method_gaps[a].append(100*(means[a]/ref-1))
    d=100*(means['ILS']-means['MS_VND'])/ref;diff.append(d);instance_differences.append(dict(instance=name,difference_pp=float(d)))
exact_mean=sum(diff)/10;null_sums=[sum(s*d for s,d in zip(signs,diff)) for signs in itertools.product([-1,1],repeat=10)]
pvalue=sum(abs(x)>=abs(sum(diff)) for x in null_sums)/1024
rr=random.Random(cfg['statistical_bootstrap_seed']);bootstrap=sorted(float(sum(rr.choices(diff,k=10))/10) for _ in range(cfg['bootstrap_replicates']))
def quantile(p):
    rank=p*(len(bootstrap)-1);lo=math.floor(rank);return bootstrap[lo]+(rank-lo)*(bootstrap[math.ceil(rank)]-bootstrap[lo])
ci=[quantile(.025),quantile(.975)];summary=read('results/summary.json');mc=summary['main_comparison']
close(float(exact_mean),mc['mean_gap_difference_pp']);close(float(statistics.median(diff)),mc['median_gap_difference_pp']);close(pvalue,mc['exact_paired_sign_flip_two_sided_p'])
for a in method_gaps:close(float(sum(method_gaps[a])/10),summary['method_summary'][a]['mean_instance_gap_percent'])
for a,b in zip(ci,mc['bootstrap_95_percentile_ci_pp']):close(a,b)
wtl={'win':sum(d<0 for d in diff),'tie':sum(d==0 for d in diff),'loss':sum(d>0 for d in diff)};assert wtl==mc['instance_win_tie_loss']
assert all(sha(ROOT/p)==h for p,h in protected.items()),'protected content changed during audit'
result={
  'audit_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
  'verdict':'PASS_WITH_SCOPE_LIMITATIONS','material_result_changing_bug_found':False,
  'execution_scope':'Single stdlib process; no solve calls, no formal run replay, no network, no frozen/source/config/data/results edits',
  'frozen_files_hash_verified':len(freeze['sha256']),'protected_files_unchanged':len(protected),
  'freeze_sha256':sha(ROOT/'FREEZE.json'),'runs_sha256':sha(ROOT/'results/runs.jsonl'),
  'raw_data':{'instances':10,'jobs':20,'machines':5,'processing_values_verified':1000,'machine_to_job_transpose_verified':True,'source_references':refs,'header_reference_differences':header_diffs},
  'runs':{'total':80,'counts':dict(record_counts),'exact_frozen_order_and_seeds':True,'complete_permutations':80,'independent_makespan_recomputations':80,'independent_operation_recomputations':8000,'final_vnd_neighbors_checked':local_neighbor_checks,'saved_perturbation_rng_records_checked':perturb_checks,'reference_hit_without_early_stop_runs':hit_continued},
  'budget':{'synthetic_neh_evaluations':210,'synthetic_neh_dp_cells':14350,'synthetic_neh_tie_policy_verified':True,'denial_tests':checks,'injected_mid_evaluation_debit':[1,4,0,0],'main_runs_evaluations_each':5000,'main_runs_dp_cells_each':493350,'all_logged_counters_consistent':True,'all_80_within_logged_time_limits':True,'resource_totals':summary['resource_totals']},
  'small_cases_independent_enumeration':small,'neighborhood_order_checked':True,'disjoint_double_swap_trials':1000,
  'statistics':{'mean_gap_percent':{a:float(sum(v)/10) for a,v in method_gaps.items()},'difference_pp':float(exact_mean),'win_tie_loss':wtl,'sign_flip_p':pvalue,'bootstrap_95_ci_pp':ci,'instance_differences':instance_differences,'nonzero_instance_differences':sum(d!=0 for d in diff),'summary_matches':True},
  'limitations':[
    'Local downloaded bytes and recorded provenance were audited; official servers and paper provenance were not fetched again.',
    'No formal run replay: source and selective trace/counters support algorithm behavior, but full candidate history is not saved and cannot independently establish the best among every evaluated candidate.',
    'No forced asynchronous SIGALRM test: injected evaluation interruption checks debit ordering only. General hard-alarm timing races and CPU overshoot beyond pre-evaluation checks remain unproven; no actual formal run hit time limits.',
    'Freeze hashes and ordering establish internal consistency, not externally authenticated preregistration or proof that no unrecorded earlier exploratory trials occurred.',
    'Recorded timing and no-model-call claims are consistent with source; external runtime process/system provenance was not independently instrumented.',
    'Ten fixed 20x5 Taillard instances and three seeds per main arm do not establish general performance, 20-job optimality, a larger-budget effect, cross-problem superiority, full EoH reproduction, or paper ILS1/ILS2 equivalence.',
    'Five of ten instance differences are exactly zero. Two-sided sign flip p=0.0625 and percentile bootstrap interval excluding zero are different exploratory summaries; they do not justify a universal or conventional 5-percent-significance claim.',
    'Reference arms naturally terminate at smaller budgets; only MS_VND versus ILS is an equal-evaluation/equal-DP-cell mechanism comparison. CPU ordering is not a stable speed claim.'
  ],
  'audit_cpu_seconds':time.process_time()-started_cpu,'audit_wall_seconds':time.perf_counter()-started_wall
}
(ROOT/'AUDIT_INDEPENDENT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('verdict','material_result_changing_bug_found','frozen_files_hash_verified','protected_files_unchanged','runs','statistics','audit_cpu_seconds','audit_wall_seconds')},ensure_ascii=False,indent=2))
