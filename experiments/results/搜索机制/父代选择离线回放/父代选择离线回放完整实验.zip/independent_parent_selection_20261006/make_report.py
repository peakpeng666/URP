#!/usr/bin/env python3
"""Create the Chinese research note from completed, independently reviewed results."""
import json,pathlib,html
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT,TA_CENTER
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,PageBreak,Image,Table,TableStyle
from PIL import Image as PILImage
ROOT=pathlib.Path(__file__).resolve().parent
D=json.loads((ROOT/'results/RESULTS.json').read_text());F=json.loads((ROOT/'FREEZE.json').read_text());R={(x['population'],x['method']):x for x in D['results']}
assert json.loads((ROOT/'validation/INDEPENDENT_REVIEW.json').read_text())['result']=='PASS'
pdfmetrics.registerFont(UnicodeCIDFont('STSong-Light'))
styles={
 'title':ParagraphStyle('title',fontName='STSong-Light',fontSize=21,leading=28,spaceAfter=12,textColor=colors.black),
 'h':ParagraphStyle('h',fontName='STSong-Light',fontSize=13,leading=19,spaceBefore=12,spaceAfter=7,textColor=colors.black),
 'p':ParagraphStyle('p',fontName='STSong-Light',fontSize=10.3,leading=16,spaceAfter=7,wordWrap='CJK'),
 'small':ParagraphStyle('small',fontName='STSong-Light',fontSize=8.6,leading=12.5,spaceAfter=6,wordWrap='CJK',textColor=colors.HexColor('#444444')),
 'cell':ParagraphStyle('cell',fontName='STSong-Light',fontSize=9,leading=12,wordWrap='CJK'),
 'ch':ParagraphStyle('ch',fontName='STSong-Light',fontSize=9,leading=12,textColor=colors.white,wordWrap='CJK')}
story=[];md=[]
def p(t,style='p'):
 story.append(Paragraph(t,styles[style]));md.append(t.replace('<b>','**').replace('</b>','**')+'\n')
def h(t):p(t,'h')
def img(name,width=505):
 f=ROOT/'figures'/name
 im=PILImage.open(f);story.append(Image(str(f),width=width,height=width*im.height/im.width));md.append(f'![{name}](figures/{name})\n')
def table(data,widths):
 rows=[[Paragraph(html.escape(str(v)),styles['ch' if i==0 else 'cell']) for v in row] for i,row in enumerate(data)]
 t=Table(rows,colWidths=widths,repeatRows=1,hAlign='LEFT');t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#27465E')),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#F1F5F7')]),('GRID',(0,0),(-1,-1),.5,colors.HexColor('#D9D9D9')),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7),('VALIGN',(0,0),(-1,-1),'MIDDLE')]))
 story.append(t);story.append(Spacer(1,8))
 md.extend([' | '.join(map(str,row))+'\n' for row in data])
def newpage():story.append(PageBreak());md.append('\n---\n')

p('固定候选档案的分簇与选父回放','title')
p('论文机制组件实验  /  2026年10月6日  /  零新增模型调用与候选执行','small')
p('结论：这批档案里的源码多样性明显高估了行为多样性。分簇抽样能保留更多行为，但也会选入当前质量更差的父代；本实验没有生成后代，不能据此宣称搜索效果提升。')
p('本次把 FunSearch 的“按多输入分数签名分簇、优先较好簇、簇内偏向短程序”落实为独立可重跑组件。只读取两批已终态候选及45份既有评分，不改动正在运行的60槽生成协议，也不读取留出集。')
h('一 档案究竟有多少种行为')
table([['批次','有效槽 / 原生成槽','不同源码','用箱签名','完整轨迹签名'],['phase0','4 / 12','3','1','1'],['followon','5 / 6','5','3','3'],['事后合并','9 / 18','8','3','3']],[100,112,84,84,125])
p('phase0 的4份有效提交中有两份源码完全相同；其余不同源码在5个设计输入上的完整分配轨迹也都与 Best Fit（BF）一致。followon 的5份源码包含3份BF等价候选和2份更差候选。这里的等价只指这5个输入，轨迹通过已归档的逐输入 assignment SHA-256 对齐。','small')
img('01_archive_diversity.png',505)
p('图1  行为用两个层级核对：5维用箱数元组，以及5条完整分配轨迹的哈希元组。事后合并仅用于工程压力测试；phase0 内两个原始生成臂也只在本组件回放中汇总，不做原始臂间效果比较。','small')

newpage()
h('二 followon 的父代分布发生了什么变化')
p('每行描述固定分布下连续独立、有放回抽取5次父代。源码 top-k 和标量去重 top-k 保留后均匀抽样，是本实验对照，不是原版 EoH 的选父复现。簇方法使用整个源码去重档案，k=3/6 不作用于它们。')
rows=[['选父方法','BF概率','5次不同源码期望','5次不同轨迹期望','5次至少1个更差父代']]
for name,label in [('code_topk_3','源码 top-3'),('code_topk_6','源码 top-6'),('scalar_topk_3','标量去重 top-3/6'),('rank_length','簇排名 + 长度'),('softmax_length_tau0.1','簇 softmax + 长度')]:
 r=R['followon',name];rows.append([label,f"{100*r['p_bf']:.2f}%",f"{r['expected_distinct_source_5']:.3f}",f"{r['expected_distinct_trace_signature_5']:.3f}",f"{100*r['p_at_least_one_worse_5']:.2f}%"])
table(rows,[140,70,98,98,99])
p('top-6 在followon中只有5份源码可保留。标量去重只有3个不同精确适应度，所以k=3和k=6相同；本档案中标量适应度类与用箱签名类一一对应，无法用它证明多维签名优于标量去重。','small')
img('02_followon_tradeoff.png',505)
p('图2  更差指平均适应度 mean(L1 / 用箱数) 低于BF；这两个更差候选也在全部5个输入上用了更多箱子。softmax主设置 τ=0.1：单次抽到更差父代15.99%，5次至少抽到一次为58.16%；选中父代的平均相对多用箱数为5.16%。这些是选父分布描述，不是后代性能。','small')
h('三 phase0 与合并面板的边界')
p('phase0 无论使用哪种已测选父方法，5次抽取的不同轨迹期望都为1；任何抽样法都不能凭空创造档案没有的行为。源码top-3的不同源码期望为2.605，加入长度偏置后为2.503。')
p('合并工程面板中，源码top-3与top-6都只保留BF行为，尽管top-6可保留6份不同源码。全档案分簇的行为概率与followon相同，簇内源码分布有所改变。详细42组结果与每个父代概率均在附带CSV中。')

newpage()
h('四 怎样将论文机制变成可核查实验')
p('来源是 FunSearch 论文 Methods 的 Evolutionary method and program selection，以及官方提交 cc53f274237d7ab05c19df939edbc1f9616a7c19 的 programs_database.py 和 config.py。论文支持先按多输入签名聚类，再按质量选簇、偏向短程序。官方代码的簇内长度公式为 exp(-(L-min L)/(max L+10^-6))，温度为1。')
p('本实验明确采用适配：质量用URP的5输入精确 mean(L1 / bins)，不使用官方代码的“最后一个测试分数”；先做精确源码去重，以输入ID和哈希绑定签名；簇温度固定，不运行岛屿、重置或生成。官方初温0.1和周期30000只是来源依据；这里的τ=0.1并不构成原版超参数复现。5次抽取是诊断窗口，原版默认每个提示2个程序。')
p('主簇对照分别使用“质量排名的倒数”与 softmax(quality / τ) 作为簇权重。前者是新增秩权变体，后者是 FunSearch 式适配；两者簇内都采用短程序偏置。另测均匀簇、均匀簇内、保留重复槽和5个固定温度。')
img('03_temperature_sensitivity.png',505)
p('图3  温度敏感性使用事前冻结的0.01、0.03、0.1、0.3、1.0。τ=0.03时单次更差概率约0.086%，τ=1时为61.23%。不能在看完结果后把最有利温度冒充预先确定的胜出参数。','small')
h('五 复核与可重跑性')
p('方案、13份输入副本的清单以及执行代码在04:14:22 UTC冻结。由于历史结果在冻结前已被检查，这是事后机制回放的运行前冻结，不是原始生成试验的前瞻性预注册。源码哈希、共同输入哈希、原始绑定和45份评分分母均经核对。')
p('42个分布/批次组合共穷举401269个五次抽取的有序结果；与占有期望公式的最大绝对误差为2.23×10^-15。原始档案独立复算的6个followon主方法最大误差1.12×10^-16；另一次独立数学复核为1.34×10^-15。二次完整回放输出逐字节相同。')
p('验证范围是已有证据、概率和多样性计算。没有重新执行45份候选评分，没有重新检验原隔离沙箱，也没有独立重算完整原始轨迹字节。小档案的精确计算不带来总体显著性或泛化结论。')

newpage()
h('六 可以推进的下一步')
p('适合进入后续正式方案的是三层记录：源码身份、多输入成绩签名、完整轨迹签名。选父时同时报告行为占有期望和质量损失，避免用更多代码版本代替更多搜索方向。')
p('还不能决定的是：保留这两个较差行为是否会成为有用的后代“踏脚石”。只有在另行冻结的后代生成实验中，用配对预算、固定选父法与评估协议比较后代改善率，才能回答。此次不启动该实验，也不修改正在运行的生成协议。')
h('复现入口')
p('解压完整实验包，在目录内运行 python replay.py --output rerun。数值回放只依赖Python标准库；输出RESULTS.json、selection_metrics.csv、parent_probabilities.csv和穷举校验记录。运行 make_figures.py 可重建科研图；需要Matplotlib与Noto CJK字体。运行 make_report.py 可重建本报告；需要ReportLab与Pillow。')
p('原始输入位于raw；INPUT_MANIFEST.json记录来源路径与SHA-256；FREEZE.json固定运行前方案与执行代码。validation/INDEPENDENT_REVIEW.json和parent_review/math_review.json给出两份独立复核。完整结果保留top-k边界同分选择的全部组合，避免隐藏随机破同分的影响。')
h('关键概念的口径')
table([['名称','本实验定义'],['源码身份','原始UTF-8代码字节的SHA-256；AST身份只作辅助描述'],['用箱签名','同一组5个输入按instance_index排序的用箱数元组'],['完整轨迹签名','同一顺序的5个assignment_sha256元组；依赖已归档评分证据'],['BF类','5个输入的完整分配轨迹哈希逐一等于独立BF控制'],['更差父代','精确平均L1/用箱数小于BF；此档案两例也均在每个输入更差'],['不同父代期望','对每类概率q计算sum[1-(1-q)^5]；按源码与轨迹分别汇总'],['有效多样性','1 / sum(q^2)；逐类概率平方和的倒数，详见CSV']],[113,392])
h('参考来源')
p('<link href="https://doi.org/10.1038/s41586-023-06924-6" color="#28609A">Romera-Paredes等，Mathematical discoveries from program search with large language models，Nature 625，468-475，2024。论文 DOI。</link>','small')
p('<link href="https://github.com/google-deepmind/funsearch/blob/cc53f274237d7ab05c19df939edbc1f9616a7c19/implementation/programs_database.py" color="#28609A">Google DeepMind FunSearch 官方 programs_database.py，固定提交 cc53f274。</link>','small')
p('<link href="https://github.com/google-deepmind/funsearch/blob/cc53f274237d7ab05c19df939edbc1f9616a7c19/implementation/config.py" color="#28609A">Google DeepMind FunSearch 官方 config.py，同一固定提交。</link>','small')
p('原始实验数据：phase0终态数值档案、glm53_fixed_design_followon终态档案、frozen_design_controls的BF设计集控制；精确文件和哈希见实验包清单。','small')

def footer(canvas,doc):
 canvas.setFont('STSong-Light',8);canvas.setFillColor(colors.HexColor('#666666'))
 canvas.drawString(45,25,'固定候选档案的分簇与选父回放 | 2026-10-06')
 canvas.drawRightString(A4[0]-45,25,str(doc.page))
path=ROOT/'选父回放中文报告.pdf'
doc=SimpleDocTemplate(str(path),pagesize=A4,rightMargin=45,leftMargin=45,topMargin=38,bottomMargin=42,title='固定候选档案的分簇与选父回放',author='研究实验报告')
doc.build(story,onFirstPage=footer,onLaterPages=footer)
(ROOT/'中文报告.md').write_text('\n'.join(md))
print(path)
