#!/usr/bin/env python3
"""Render descriptive scientific figures only; reads completed replay results."""
import json,pathlib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
ROOT=pathlib.Path(__file__).resolve().parent
font_manager.fontManager.addfont('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
plt.rcParams.update({'font.family':'Noto Sans CJK JP','font.size':10,'axes.unicode_minus':False,'axes.spines.top':False,'axes.spines.right':False,'figure.dpi':150,'savefig.dpi':220})
D=json.loads((ROOT/'results/RESULTS.json').read_text());R={(r['population'],r['method']):r for r in D['results']}
colors={'source':'#28609A','behavior':'#197D70','worse':'#C55D3D'}

def save(fig,name):
 fig.savefig(ROOT/'figures'/f'{name}.png',bbox_inches='tight',facecolor='white')
 fig.savefig(ROOT/'figures'/f'{name}.svg',bbox_inches='tight',facecolor='white');plt.close(fig)

fig,ax=plt.subplots(figsize=(8.8,3.7))
xs=[0,1,2];width=.18
for j,(key,label,color) in enumerate([('slots','有效候选槽','#9BA5AE'),('source','不同源码',colors['source']),('bin_signature','用箱签名',colors['behavior']),('trace_signature','完整分配轨迹签名','#674C8E')]):
 vals=[D['populations'][p][key] for p in ['phase0','followon','pooled_posthoc']]
 pos=[x+(j-1.5)*width for x in xs]; bars=ax.bar(pos,vals,width,label=label,color=color)
 ax.bar_label(bars,padding=3)
ax.set_xticks(xs,['phase0\n独立批次','followon\n独立批次','事后合并\n仅工程压力面板']);ax.set_ylabel('计数');ax.set_ylim(0,10.5);ax.legend(ncol=4,loc='upper left',frameon=False);ax.set_title('不同源码未必带来不同的装箱行为',loc='left',fontweight='bold',pad=16)
ax.grid(axis='y',alpha=.16);ax.set_axisbelow(True);fig.tight_layout();save(fig,'01_archive_diversity')

methods=['code_topk_3','code_topk_6','scalar_topk_3','rank_length','softmax_length_tau0.1']
labels=['源码 top-3','源码 top-6*','标量去重 top-3','簇排名 + 长度','簇 softmax + 长度\nτ = 0.1']
fig,(ax,bx)=plt.subplots(1,2,figsize=(11,4.3),gridspec_kw={'wspace':.42})
y=list(range(len(methods)))
for off,key,label,color in [(-.16,'expected_distinct_source_5','不同源码',colors['source']),(.16,'expected_distinct_trace_signature_5','不同完整轨迹',colors['behavior'])]:
 vals=[R['followon',m][key] for m in methods]; bars=ax.barh([i+off for i in y],vals,height=.3,label=label,color=color);ax.bar_label(bars,fmt='%.2f',padding=3,fontsize=9)
ax.set_yticks(y,labels);ax.invert_yaxis();ax.set_xlim(0,4);ax.set_xlabel('连续独立抽5次的不同父代期望');ax.set_title('A  身份与行为分开计数',loc='left',fontweight='bold');ax.set_ylim(5.1,-.6);ax.legend(loc='lower left',frameon=False,fontsize=9,ncol=2)
vals=[100*R['followon',m]['p_worse'] for m in methods];bars=bx.barh(y,vals,color=colors['worse'],height=.55);bx.bar_label(bars,fmt='%.2f%%',padding=4);bx.set_yticks(y,labels);bx.invert_yaxis();bx.set_xlim(0,82);bx.set_ylim(5.1,-.6);bx.set_xlabel('每次抽到低于BF适应度的概率 (%)');bx.set_title('B  多样性的质量代价',loc='left',fontweight='bold')
for a in [ax,bx]:a.grid(axis='x',alpha=.16);a.set_axisbelow(True)
fig.suptitle('followon 批次  |  5候选、3行为类、25份既有评分',x=.04,ha='left',y=1.025,fontsize=13,fontweight='bold')
fig.text(.04,-.04,'* top-6 因档案只有5份源码而保留全部5份。簇方法使用全部去重档案，没有 top-k 截断。',fontsize=9,color='#444444')
save(fig,'02_followon_tradeoff')

fig,(ax,bx)=plt.subplots(1,2,figsize=(9,3.6),gridspec_kw={'wspace':.4})
ts=[.01,.03,.1,.3,1.];ms=['softmax_length_tau0.01','softmax_length_tau0.03','softmax_length_tau0.1','softmax_length_tau0.3','softmax_length_tau1.0']
vals=[100*R['followon',m]['p_worse'] for m in ms];ax.plot(ts,vals,'o-',color=colors['worse'],lw=2);ax.set_ylabel('每次更差父代概率 (%)');ax.set_ylim(-2,70)
vals2=[R['followon',m]['expected_distinct_trace_signature_5'] for m in ms];bx.plot(ts,vals2,'o-',color=colors['behavior'],lw=2);bx.set_ylabel('5次抽取的不同完整轨迹期望');bx.set_ylim(.9,3)
for a in [ax,bx]:a.set_xscale('log');a.set_xticks(ts,[str(t) for t in ts]);a.set_xlabel('固定温度 τ');a.axvline(.1,color='#999999',lw=1,ls='--');a.grid(alpha=.16)
ax.annotate('15.99%',(.1,vals[2]),xytext=(.047,25),arrowprops={'arrowstyle':'-','color':'#666666'})
bx.annotate('1.679',(.1,vals2[2]),xytext=(.045,2.02),arrowprops={'arrowstyle':'-','color':'#666666'})
fig.suptitle('温度决定质量与行为多样性的权衡',x=.025,ha='left',fontweight='bold',fontsize=13,y=1.04)
save(fig,'03_temperature_sensitivity')
print('Rendered 3 PNG and SVG figures')
