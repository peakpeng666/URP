# 固定候选档案的分簇与选父回放

独立、只读的论文机制组件实验。零新增模型调用，零新增候选程序执行。

## 先看什么

- 选父回放中文报告.pdf：4页中文结论、方法、3张科研图、复核与限制
- 中文报告.md：同内容可编辑文本
- figures/02_followon_tradeoff.png：主结果图
- results/selection_metrics.csv：42个批次/方法组合的完整指标
- results/parent_probabilities.csv：每个父代的抽样概率
- results/RESULTS.json：完整数据、来源绑定、精确适应度、签名、同分敏感性

## 数值重跑

需要Python 3.10或更新版本，仅使用标准库。图表和PDF不是数值重跑依赖。

    python replay.py --output rerun
    python test_replay.py

程序首先验证FREEZE.json和INPUT_MANIFEST.json。输入变更会立即报错。
候选源码只作为字符串哈希和语法树解析的对象，不导入、不执行，不编译为可执行字节码。
不需要原始目录、网络、凭证、LLM、容器沙箱或原评分器。

## 图和报告重建

    python make_figures.py
    python make_report.py

图需要Matplotlib和Noto CJK字体，当前构建脚本字体位置为
/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc。
报告需要ReportLab和Pillow，使用STSong-Light内置CID字体。
如果系统字体位置不同，仅调整图形构建脚本；这不改变冻结数值方法。

## 原始证据与冻结

raw/包含13份已终态档案证据，INPUT_MANIFEST.json记录逐文件SHA-256及原路径。
prepare_inputs.py是制作该副本的来源记录脚本；复现计算不必运行它，也不要求原始工作目录仍存在。
FREEZE.json在2026-10-06T04:14:22Z、第一次回放计算前生成，固定PLAN.json、manifest、replay.py等。
历史结果在冻结前已知。这是事后档案回放，不是原始生成试验的前瞻性预注册。

## 独立验证

- results/EXHAUSTIVE_VALIDATION.json：42个分布，401269个有序五抽取结果，解析式与穷举最大误差2.23e-15
- validation/INDEPENDENT_REVIEW.json：另一实现直接从原始档案读取并复算6个followon主方法，误差1.12e-16以内
- parent_review/math_review.json：独立数学与代码复核全部42组，误差1.34e-15以内
- validation/UNIT_TESTS.txt：8项机制测试通过，包括标量碰撞、Fraction不舍入、重复源码、短程序偏置、顺序不变性
- COMPLETION_RECEIPT.json：原输入未变、重跑一致、最终可见成品的哈希

验证没有重新执行45份候选评分，没有重新认证原沙箱，也没有重新计算原始完整轨迹字节。

## 关键限制

phase0有4个有效槽但只有3个源码身份和1个行为类；followon有5个源码身份和3个行为类。
行为等价仅在共同5个已暴露设计输入上成立，以逐输入assignment_sha256比较。
事后合并的9槽档案只用于工程压力测试。k=3/6仅作用于均匀选父top-k对照，簇方法使用完整去重档案。
本档案标量适应度类与多维签名类一一对应，不能证明多维分簇优于标量去重。
没有生成后代，不能从父代多样性推断搜索提升，也不能判断较差行为是否具有后代踏脚石价值。

参考：FunSearch，Nature，DOI 10.1038/s41586-023-06924-6；官方代码固定提交cc53f274237d7ab05c19df939edbc1f9616a7c19。
