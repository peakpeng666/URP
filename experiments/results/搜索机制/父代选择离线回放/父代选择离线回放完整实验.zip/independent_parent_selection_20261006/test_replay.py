#!/usr/bin/env python3
"""Unit checks on selection mechanics; synthetic records, no candidate execution."""
import copy, unittest
from fractions import Fraction
import replay

class Mechanics(unittest.TestCase):
    def setUp(self):
        self.cs,_=replay.load_archive()
        self.f=[c for c in self.cs if c['batch']=='followon']
    def test_all_input_bindings(self):
        self.assertEqual(len(self.cs),9)
        self.assertEqual(sum(len(c['archived_rows']) for c in self.cs),45)
    def test_permutation_invariance(self):
        self.assertEqual(replay.distributions(self.f)[0],replay.distributions(list(reversed(self.f)))[0])
    def test_identity_duplicate_has_one_representative(self):
        p=[c for c in self.cs if c['batch']=='phase0']
        self.assertEqual(len(replay.dedup(p,'code_sha256')),3)
        self.assertEqual(len(replay.dedup(p,'fitness')),1)
    def test_scalar_collision_is_not_signature_equality(self):
        a,b=copy.deepcopy(self.f[:2]);b['fitness']=a['fitness']
        self.assertNotEqual(a['bins'],b['bins'])
        self.assertEqual(len(replay.dedup([a,b],'fitness')),1)
        p=replay.cluster_distribution([a,b],'softmax','length',.1)
        self.assertEqual(set(p),{a['id'],b['id']})
        self.assertAlmostEqual(p[a['id']],.5)
    def test_fraction_dedup_does_not_round(self):
        a,b=copy.deepcopy(self.f[:2]);a['fitness']=Fraction(1);b['fitness']=Fraction(10**30+1,10**30)
        self.assertEqual(float(a['fitness']),float(b['fitness']))
        self.assertEqual(len(replay.dedup([a,b],'fitness')),2)
    def test_length_bias_shorter_has_more_mass(self):
        bf=[c for c in self.f if c['bf_class']]
        p=replay.cluster_distribution(bf,'softmax','length',.1)
        order=sorted(bf,key=lambda c:c['source_characters'])
        self.assertGreater(p[order[0]['id']],p[order[-1]['id']])
    def test_duplicate_slots_do_not_increase_cluster_mass(self):
        d=copy.deepcopy(next(c for c in self.f if c['bf_class']));d['id']='synthetic_duplicate_only'
        for pool in [self.f,self.f+[d]]:
            p=replay.cluster_distribution(pool,'softmax','length',.1)
            mass=sum(p[c['id']] for c in pool if c['bf_class'])
            self.assertAlmostEqual(mass,0.8400878002240457)
    def test_softmax_requires_positive_temperature(self):
        with self.assertRaises(AssertionError):replay.softmax([1,2],0)

if __name__=='__main__': unittest.main(verbosity=2)
