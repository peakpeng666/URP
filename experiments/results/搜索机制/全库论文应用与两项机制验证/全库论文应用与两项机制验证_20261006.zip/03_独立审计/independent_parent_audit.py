"""Parent-side audit; imports no experiment implementation. Writes only audit directory.
Turn exactness uses independent Floyd-Warshall arc closure and exhaustive service-order
and set-partition enumeration, not either production solver. CVRP is recomputed from
coordinates/routes and the frozen protocol. Python standard library only.
"""
from pathlib import Path
import json, hashlib, itertools, collections, math, csv, datetime, functools, time, copy
HERE=Path(__file__).resolve().parent
BASE=HERE.parent

def read(p): return json.loads(Path(p).read_text())
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def canon(x): return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def mean(a): a=list(a); return math.fsum(a)/len(a)
def std(a): a=list(a); m=mean(a); return math.sqrt(mean((x-m)**2 for x in a))
def close(a,b):
    assert math.isclose(a,b,rel_tol=1e-10,abs_tol=1e-10),(a,b)
def write(p,x): Path(p).write_text(json.dumps(x,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
def snapshot(root): return {str(p.relative_to(root)):sha(p) for p in root.rglob('*') if p.is_file()}
def clean_timings(x):
    if isinstance(x,dict):return {k:clean_timings(v) for k,v in x.items() if not any(t in k for t in ['wall_s','cpu_s','inference_time'])}
    if isinstance(x,list):return [clean_timings(v) for v in x]
    return x

def road_closure(inst):
    edges=inst['arcs']; states=[(u,v) for u,v,_ in edges]; index={s:i for i,s in enumerate(states)}
    assert len(index)==len(states)
    N=len(states);d=[[math.inf]*N for _ in range(N)]
    forb=set(map(tuple,inst['forbidden_turns']));pen={tuple(t[:3]):t[3] for t in inst['turn_penalties']}
    for i,(u,v) in enumerate(states):
        d[i][i]=0
        for j,(vv,w,c) in enumerate(edges):
            if vv==v and (u,v,w) not in forb:d[i][j]=min(d[i][j],c+pen.get((u,v,w),0))
    # All-pairs closure directly over raw arcs.
    for k in range(N):
        for i in range(N):
            if math.isinf(d[i][k]):continue
            via=d[i][k]
            for j in range(N):
                new=via+d[k][j]
                if new<d[i][j]:d[i][j]=new
    modes={v:[i for i,e in enumerate(states) if e[1]==v] for v in {e[1] for e in states}}
    def start(node,target):
        return min((c+d[i][target] for i,(u,v,c) in enumerate(edges) if u==node),default=math.inf)
    return d,modes,start

def independent_road_optimum(inst):
    D,modes,start=road_closure(inst);dep=inst['depot'];tasks=inst['customers'];n=len(tasks)
    def ordered(order):
        costs={j:start(dep,j) for j in modes.get(tasks[order[0]]['node'],[])}
        for t in order[1:]:
            costs={j:min((v+D[k][j] for k,v in costs.items()),default=math.inf) for j in modes.get(tasks[t]['node'],[])}
        return min((v+D[k][j] for k,v in costs.items() for j in modes.get(dep,[])),default=math.inf)
    nodes=[dep]+[t['node'] for t in tasks]
    reset={(a,b):min((start(a,j) for j in modes.get(b,[])),default=math.inf) for a in nodes for b in nodes if a!=b}
    def reset_order(order):
        route=[dep]+[tasks[t]['node'] for t in order]+[dep]
        return sum(reset[a,b] for a,b in zip(route,route[1:]))
    routecost={};resetcost={};permutations=0
    for size in range(1,n+1):
        for subset in itertools.combinations(range(n),size):
            if sum(tasks[t]['demand'] for t in subset)>inst['capacity']:continue
            mask=sum(1<<t for t in subset)
            a=b=math.inf
            for order in itertools.permutations(subset):
                permutations+=1;a=min(a,ordered(order));b=min(b,reset_order(order))
            routecost[mask]=a;resetcost[mask]=b
    # Generate every set partition by assigning the smallest remaining customer to
    # each admissible route; no production subset-DP state or table is reused.
    def partition(costs):
        @functools.lru_cache(None)
        def go(remaining):
            if not remaining:return 0
            first=remaining&-remaining
            return min((cost+go(remaining^mask) for mask,cost in costs.items() if mask&first and mask&remaining==mask),default=math.inf)
        return go((1<<n)-1)
    a,b=partition(routecost),partition(resetcost)
    return {'cost':None if math.isinf(a) else a,'reset_cost':None if math.isinf(b) else b,
            'permutations_enumerated':permutations,'route_subsets':len(routecost),
            'fixed_sequence_cost':(lambda v:None if math.isinf(v) else v)(ordered(tuple(range(min(4,n)))))}

def independent_witness(inst,sol):
    if sol['status']=='infeasible':return {'witness_present':False,'valid':False,'routes':0,'forbidden':0,'cost_only':False}
    edges={(a,b):c for a,b,c in inst['arcs']}; forbidden=set(map(tuple,inst['forbidden_turns']));turns={tuple(x[:3]):x[3] for x in inst['turn_penalties']}
    customers={x['id']:x for x in inst['customers']};seen=[];fail=[];total=0;nf=0;nlegs=0;badlegs=0
    for route in sol['routes']:
        path=route['nodes'];svc=route['services']
        assert path[0]==path[-1]==inst['depot'] and len(path)>1
        assert all((u,v) in edges for u,v in zip(path,path[1:]))
        c=sum(edges[u,v] for u,v in zip(path,path[1:]))
        for triple in zip(path,path[1:],path[2:]):
            if triple in forbidden:fail.append('forbidden');nf+=1
            c+=turns.get(triple,0)
        load=0;last=-1
        for s in svc:
            assert s['customer'] in customers and type(s['position']) is int
            assert 0<=s['position']<len(path) and s['position']>=last
            assert path[s['position']]==customers[s['customer']]['node']
            last=s['position'];seen.append(s['customer']);load+=customers[s['customer']]['demand']
        assert load<=inst['capacity'] and len(svc)>0
        if c!=route['cost']:fail.append('cost')
        total+=c
        cuts=[0]+[s['position'] for s in svc]+[len(path)-1]
        for i,j in zip(cuts,cuts[1:]):
            leg=path[i:j+1];nlegs+=1
            badlegs+=sum(t in forbidden for t in zip(leg,leg[1:],leg[2:]))
    assert sorted(seen)==sorted(customers)
    if total!=sol['cost']:fail.append('cost')
    return {'witness_present':True,'valid':not fail,'routes':len(sol['routes']),'forbidden':nf,'cost_only':bool(fail) and set(fail)=={'cost'},'computed_cost':total,'legs':nlegs,'badlegs':badlegs}

def turn_audit():
    root=BASE/'independent_turn_modes_20261006';out=HERE/'turn_modes';before=snapshot(root);t=time.perf_counter()
    frozen=read(root/'PRE_RUN_SHA256SUMS.json');assert len(frozen)==54
    for p,h in frozen.items():assert sha(root/p)==h,p
    receipt=read(root/'FREEZE_RECEIPT.json');assert receipt['pre_run_manifest_sha256']==sha(root/'PRE_RUN_SHA256SUMS.json')
    source=read(root/'sources/source_identity.json');assert source['author_pdf_sha256']==sha(root/'sources/P343_author_manuscript.pdf')
    inputs=[read(p) for p in sorted((root/'data/formal').glob('*.json'))];assert len(inputs)==36
    assert len({canon(x) for x in inputs})==36
    assert collections.Counter((tuple(x['shape']),x['seed']) for x in inputs)=={(s,seed):3 for s in [(3,3),(3,4),(4,4)] for seed in range(10000,10004)}
    for shape,seed in itertools.product([(3,3),(3,4),(4,4)],range(10000,10004)):
        group=[x for x in inputs if tuple(x['shape'])==shape and x['seed']==seed]
        assert {x['rule'] for x in group}=={'uturn','left_cost','left_ban'}
        for k in ['arcs','customers','capacity']:assert all(x[k]==group[0][k] for x in group)
    smoke=[read(p) for p in (root/'data/smoke').glob('*.json')]
    assert not {x['seed'] for x in inputs}&{x['seed'] for x in smoke}
    totals=collections.Counter();recomputed=[]
    for inst in inputs:
        r=read(root/'results/formal'/f"{inst['id']}.json");replay=read(out/'replay'/f"{inst['id']}.json")
        assert r['terminal']=='completed' and clean_timings(r)==clean_timings(replay)
        assert r['data_sha256']==sha(root/'data/formal'/f"{inst['id']}.json")
        assert len({x['id'] for x in inst['customers']})==len(inst['customers'])
        assert len({x['node'] for x in inst['customers']})==len(inst['customers'])
        assert all(c>0 for u,v,c in inst['arcs']) and all(t[3]>=0 for t in inst['turn_penalties'])
        v=independent_road_optimum(inst)
        assert v['cost']==r['mode']['cost']==r['oracle']['cost'],(inst['id'],v)
        assert v['reset_cost']==r['reset']['cost'] and v['reset_cost']<=v['cost']
        assert v['fixed_sequence_cost']==r['fixed_sequence_check']['layered_cost']==r['fixed_sequence_check']['brute_cost']
        for m in ['mode','oracle','reset']:
            ck=independent_witness(inst,r[m]);assert ck['valid']==r['checks'][m]['valid']
            if m!='reset':assert ck['valid'];totals[m+'_routes']+=ck['routes']
            else:
                totals['reset_valid']+=ck['valid'];totals['reset_forbidden_cases']+=ck['forbidden']>0
                totals['reset_cost_only_cases']+=ck['cost_only'];totals['reset_isolated_legs']+=ck['legs'];totals['reset_illegal_isolated_legs']+=ck['badlegs']
                if ck['valid']:assert r[m]['cost']==v['cost']
        totals['exact_matches']+=1;totals['permutations_enumerated']+=v['permutations_enumerated']
        recomputed.append({'id':inst['id'],**v})
    fixture=[]
    for p in sorted((root/'data/fixtures').glob('*.json')):
        inst=read(p);v=independent_road_optimum(inst);r=read(root/'results/fixtures'/p.name)
        assert v['cost']==r['mode']['cost']==r['oracle']['cost'] and v['reset_cost']==r['reset']['cost']
        fixture.append({'id':inst['id'],**v})
    # Independently check published aggregate raw timing sums, without drawing speed rankings.
    budgets=read(root/'results/BUDGET_TOTALS.json')
    for m in ['reset','mode','oracle']:
        records=[read(root/'results/formal'/f"{x['id']}.json")[m] for x in inputs]
        for k,v in budgets[m].items():close(v,sum(r.get(k,0) for r in records))
    assert snapshot(root)==before,'source tree modified during independent audit'
    write(out/'independent_costs.json',recomputed)
    result={'passed':True,'verdict':'PASS_WITH_SCOPE_LIMITATIONS','experiment':root.name,'audit_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'auditor_implementation':str(Path(__file__).relative_to(BASE)),
      'source_imports':False,'frozen_files_verified':54,'freeze_manifest_sha256':sha(root/'PRE_RUN_SHA256SUMS.json'),
      'freeze_receipt_verified':True,'source_pdf_sha256_verified':True,'whole_source_tree_unchanged':True,
      'formal_instances':36,'distinct_base_graphs':12,'paired_rule_versions_per_base':3,'data_duplicates':0,
      'method':'Independent Floyd-Warshall closure on raw incoming-arc states; exhaustive capacity-feasible service-order enumeration and exact set partitions; separate raw witness recomputation.',
      'main_results':dict(totals),'fixtures':fixture,'formal_replay_identical_excluding_timing':36,
      'tests':{'original_unit_tests_passed':6,'separate_log':'unit_tests.txt','third_method_all_formal_global_costs_match':True,'fixed_sequence_costs_match':36,'source_vs_result_data_hashes_match':36,'cpu_wall_ledger_sums_match':True},
      'paper_fit':{'P343':'Incoming-arc node service modes and legal arc-state transitions correspond to author-manuscript sections 4.1-4.3 and 4.6.2; exact global enumeration is audit scaffolding, not full UHGS.',
                   'source_url':source['author_pdf_url'],'not_run':['official HGS-CARP','1528-instance results','amortized neighborhood benchmark','LLM candidate improvement','agricultural vehicle execution']},
      'limitations':['The 36 synthetic, turn-sensitive instances form 12 correlated base graphs under 3 contracts, not 36 independent population draws.','30 forbidden-turn and 2 cost-only failures are diagnostic counts, not a real-world failure rate.','Pairwise-reset solves a deliberately relaxed problem: its lower objective cannot establish a competing algorithm speed/quality advantage.','Matched exact solvers and an independently recomputed third method are strong empirical validation, not a formal program proof.','Local self-recorded freeze timestamps and matching hashes establish current integrity; they do not independently authenticate chronology or serve as externally registered preregistration.','Fixed-schema trusted-input research adapter only; no production hostile-JSON security or physical agricultural path guarantee.'],
      'blocking_findings':[],'audit_wall_seconds':time.perf_counter()-t}
    write(out/'AUDIT_PARENT_INDEPENDENT.json',result);return result

def cv_features(x):
    pts=x['coordinates'][1:];d=x['coordinates'][0];dem=x['demands'][1:]
    rad=[math.hypot(p[0]-d[0],p[1]-d[1]) for p in pts]
    near=[min(math.hypot(p[0]-q[0],p[1]-q[1]) for j,q in enumerate(pts) if i!=j) for i,p in enumerate(pts)]
    spans=[max(p[k] for p in pts)-min(p[k] for p in pts) for k in [0,1]]
    return [math.log(len(pts)),mean(dem)/x['capacity'],std(dem)/x['capacity'],std(rad)/mean(rad),mean(near)/mean(rad),min(spans)/max(spans)],2*math.fsum(rad)

def cvrp_audit():
    root=BASE/'independent_cvrp_selection_crc_20261006';out=HERE/'cvrp_selection_crc';before=snapshot(root);t=time.perf_counter()
    frozen=read(root/'PRE_RUN_FREEZE.json')['sha256'];assert len(frozen)==31
    for p,h in frozen.items():assert sha(root/p)==h,p
    final=read(root/'FINAL_MANIFEST.json')['files']
    for e in final:assert sha(root/e['path'])==e['sha256'],e['path']
    sources=read(root/'SOURCE_MANIFEST.json');source_n=0
    for e in sources:
        assert sha(root/e['copy'])==e['sha256']
        p=BASE/e['source'];assert p.exists(),p
        assert sha(p)==e['sha256'];source_n+=1
    plan=read(root/'PLAN.json');meta=read(root/'data/instance_manifest.json')['instances'];ids=sorted(m['instance_id'] for m in meta)
    assert len(ids)==len(set(ids))==24
    instances={i:read(root/'data/instances'/f'{i}.json') for i in ids}
    content={i:canon({k:v for k,v in x.items() if k in ['coordinates','demands','capacity','depot','fleet','objective']}) for i,x in instances.items()}
    assert len(set(content.values()))==24,'duplicate physical instance under different ID'
    for m in meta:assert canon(instances[m['instance_id']])==m['sha256']
    algos=sorted(plan['algorithms']);profiles=plan['profiles'];seeds=plan['solver_seeds']
    raw=[json.loads(s) for s in (root/'data/raw.jsonl').read_text().splitlines()]
    expected=set(itertools.product(ids,algos,profiles,seeds));keys=[(r['instance_id'],r['algorithm'],r['profile'],r['solver_seed']) for r in raw]
    assert len(raw)==len(set(keys))==432 and set(keys)==expected
    costs0=collections.defaultdict(list);rows0=collections.defaultdict(list);maxdelta=0
    for r in raw:
        x=instances[r['instance_id']];points=x['coordinates'];seen=[];terms=[]
        assert r['status']=='returned' and all(r[k] is True for k in ['accepted','budget_conformant','scoreable'])
        assert r['child_exit_code']==0 and not r['checker_errors']
        assert r['routes']==r['output']['routes'] and r['instance_sha256']==canon(x)
        assert r['solver_cpu_seconds']<=r['cpu_budget_seconds'] and r['process_wall_seconds']<=r['wall_budget_seconds']
        for route in r['routes']:
            assert route[0]==route[-1]==0 and 0 not in route[1:-1] and len(route)>=3
            assert all(type(v) is int and 0<=v<len(points) for v in route)
            assert sum(x['demands'][v] for v in route[1:-1])<=x['capacity']
            seen.extend(route[1:-1])
            terms.extend(math.hypot(points[a][0]-points[b][0],points[a][1]-points[b][1]) for a,b in zip(route,route[1:]))
        assert sorted(seen)==list(range(1,len(points)))
        value=math.fsum(terms);close(value,r['recomputed_cost']);close(value,r['output']['reported_cost'])
        maxdelta=max(maxdelta,abs(value-r['recomputed_cost']));key=r['profile'],r['instance_id'],r['algorithm']
        costs0[key].append(value);rows0[key].append(r)
    assert all(len(v)==3 for v in costs0.values());costs={k:mean(v) for k,v in costs0.items()}
    fs={i:cv_features(x) for i,x in instances.items()};savedfeatures=read(root/'results/features.json')['features']
    for i,(f,s) in fs.items():
        for a,b in zip(f,savedfeatures[i]['values']):close(a,b)
        close(s,savedfeatures[i]['star_upper_bound'])
    def fit_predict(train,cal,test,p,cm):
        mus=[mean(fs[i][0][d] for i in train) for d in range(6)]
        sds=[std(fs[i][0][d] for i in train) or 1 for d in range(6)]
        normalized={i:{a:cm[p,i,a]/fs[i][1] for a in algos} for i in train}
        sbs=min(algos,key=lambda a:(mean(normalized[i][a] for i in train),a));preds={}
        for i in cal+test:
            dist={j:sum(((fs[i][0][d]-fs[j][0][d])/sds[d])**2 for d in range(6)) for j in train}
            nn=sorted(train,key=lambda j:(dist[j],j))[:3]
            values={a:mean(normalized[j][a] for j in nn) for a in algos}
            choice=min(algos,key=lambda a:(values[a],a));score=(values[sbs]-values[choice])/values[sbs]
            preds[i]={'choice':choice,'score':score,'neighbors':nn,'values':values}
        gates={}
        for alpha in [.1,.2]:
            thresholds=sorted({0.0}|{preds[i]['score'] for i in cal if preds[i]['score']>=0})
            eligible=[v for v in thresholds if (1+sum(preds[i]['choice']!=sbs and preds[i]['score']>v and cm[p,i,preds[i]['choice']]>1.01*cm[p,i,sbs] for i in cal))/(len(cal)+1)<=alpha]
            gates[alpha]=eligible[0] if eligible else None
        return mus,sds,sbs,preds,gates
    savedfolds=read(root/'results/folds.json');oof=list(csv.DictReader((root/'results/out_of_fold.csv').open()));assert len(oof)==240
    assert len({(r['profile'],r['instance_id'],r['strategy']) for r in oof})==240
    recomputed=[];foldlog=[];mutationchecks=[]
    for p in profiles:
        for fold in range(4):
            test=sorted(m['instance_id'] for m in meta if m['replicate']==fold)
            cal=sorted(m['instance_id'] for m in meta if m['replicate']==(fold+1)%4)
            train=sorted(set(ids)-set(test)-set(cal));assert [len(train),len(cal),len(test)]==[12,6,6]
            assert not (set(train)&set(cal) or set(train)&set(test) or set(cal)&set(test))
            mus,sds,sbs,preds,gates=fit_predict(train,cal,test,p,costs)
            f=next(f for f in savedfolds if f['profile']==p and f['fold']==fold)
            assert (train,cal,test)==(f['train_ids'],f['calibration_ids'],f['test_ids']) and sbs==f['model']['sbs']
            for a,b in zip(mus+sds,f['model']['mu']+f['model']['sd']):close(a,b)
            for i in cal+test:
                export=next(v for v in f['calibration_predictions']+f['test_predictions'] if v['instance_id']==i)
                assert export['chosen']==preds[i]['choice'] and export['neighbor_ids']==preds[i]['neighbors']
                close(export['score'],preds[i]['score'])
                for a in algos:close(export['predicted_costs'][a],preds[i]['values'][a])
            for alpha in [.1,.2]:
                g=f['gates'][str(alpha)];assert g['safe_endpoint']==(gates[alpha] is None)
                if gates[alpha] is not None:close(gates[alpha],g['threshold'])
                close(g['finite_sample_floor'],1/7)
            # Audit-side perturbation rebuild: held-out labels cannot affect decisions.
            changed=dict(costs)
            for j,i in enumerate(test):
                for k,a in enumerate(algos):changed[p,i,a]=(j+1)*(k+1)*10**9
            other=fit_predict(train,cal,test,p,changed)
            assert (mus,sds,sbs,preds,gates)==other
            # Calibration labels cannot alter fitted predictor, though they may alter gates.
            for j,i in enumerate(cal):
                for k,a in enumerate(algos):changed[p,i,a]=(j+1)*(k+1)*10**9
            other2=fit_predict(train,cal,test,p,changed)
            assert (mus,sds,sbs,preds)==other2[:4]
            mutationchecks.append({'profile':p,'fold':fold,'test_label_decision_invariance':True,'calibration_label_model_invariance':True})
            foldlog.append({'profile':p,'fold':fold,'train_n':12,'cal_n':6,'test_n':6,'sbs':sbs,'primary_safe_endpoint':gates[.1] is None,'sensitivity_threshold':gates[.2]})
            for i in test:
                pred=preds[i];oracle=min(algos,key=lambda a:(costs[p,i,a],a))
                actions={'train_sbs':sbs,'knn':pred['choice'],'estimated_mean_oracle':oracle}
                for alpha,name in [(.1,'crc_alpha_0.10'),(.2,'crc_alpha_0.20_sensitivity')]:
                    actions[name]=pred['choice'] if gates[alpha] is not None and pred['score']>gates[alpha] else sbs
                for name,a in actions.items():
                    r=next(r for r in oof if (r['profile'],r['instance_id'],r['strategy'])==(p,i,name))
                    assert r['selected_algorithm']==a and r['sbs_algorithm']==sbs and r['oracle_algorithm']==oracle
                    value=costs[p,i,a];base=costs[p,i,sbs];best=costs[p,i,oracle]
                    z={'profile':p,'instance_id':i,'strategy':name,'selected_algorithm':a,'route_length':value,'normalized_cost':value/fs[i][1],
                       'improvement_over_sbs_pct':100*(base-value)/base,'regret_vs_mean_oracle_pct':100*(value/best-1),'accepted_alternative':a!=sbs,'harm_gt_1pct':value>1.01*base}
                    for k in ['route_length','normalized_cost','improvement_over_sbs_pct','regret_vs_mean_oracle_pct']:close(z[k],float(r[k]))
                    for k in ['accepted_alternative','harm_gt_1pct']:assert z[k]==(r[k]=='True')
                    recomputed.append(z)
    summary=read(root/'results/summary.json');aggregates=[]
    for s in summary['strategies']:
        rr=[r for r in recomputed if (r['profile'],r['strategy'])==(s['profile'],s['strategy'])];assert len(rr)==24
        for k in ['route_length','normalized_cost','improvement_over_sbs_pct','regret_vs_mean_oracle_pct']:close(s['mean_'+k],mean(r[k] for r in rr))
        accepted=[r for r in rr if r['accepted_alternative']]
        assert len(accepted)==s['alternative_count']
        assert sum(r['harm_gt_1pct'] for r in rr)==s['harmful_instance_count']
        if not accepted:assert s['conditional_accepted_harm_frequency'] is None
        else:close(s['conditional_accepted_harm_frequency'],mean(r['harm_gt_1pct'] for r in accepted))
        aggregates.append({k:s[k] for k in ['profile','strategy','mean_improvement_over_sbs_pct','mean_regret_vs_mean_oracle_pct','mean_route_length','alternative_count','harmful_instance_count','conditional_accepted_harm_frequency']})
    assert summary['historical_real_solver_runs']==432 and summary['new_solver_runs']==summary['new_api_calls']==0
    for sourcefield,target in [('solver_cpu_seconds','historical_source_solver_cpu_seconds'),('child_total_cpu_seconds','historical_source_child_cpu_seconds'),('supervisor_cpu_seconds','historical_source_supervisor_cpu_seconds'),('total_wall_seconds','historical_source_total_call_wall_seconds')]:close(sum(r[sourcefield] for r in raw),summary['cost_ledger'][target])
    for oracle in summary['oracle_audit']:
        p=oracle['profile'];close(oracle['estimated_mean_oracle_length'],mean(min(costs[p,i,a] for a in algos) for i in ids))
        close(oracle['seed_hindsight_oracle_length'],mean(min(r['recomputed_cost'] for r in raw if r['profile']==p and r['instance_id']==i) for i in ids))
    assert read(root/'results/decision_fingerprint.json')==read(out/'replay/decision_fingerprint.json')
    assert snapshot(root)==before,'source tree modified during independent audit'
    write(out/'independent_oof_rows.json',recomputed);write(out/'independent_fold_and_leakage_checks.json',{'folds':foldlog,'mutations':mutationchecks})
    result={'passed':True,'verdict':'PASS_WITH_SCOPE_LIMITATIONS','experiment':root.name,'audit_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
      'auditor_implementation':str(Path(__file__).relative_to(BASE)),'source_imports':False,'frozen_files_verified':len(frozen),'final_manifest_entries_verified':len(final),
      'freeze_receipt_sha256':sha(root/'PRE_RUN_FREEZE.json'),'source_copies_and_originals_verified':source_n,'whole_source_tree_unchanged':True,
      'historical_solver_rows_revalidated':432,'new_solver_runs':0,'new_API_calls':0,'independent_statistical_units':24,'physical_input_duplicates':0,'factorial_log_duplicates':0,
      'main_results':aggregates,'folds':foldlog,'tests':{'original_unit_tests_passed':8,'separate_log':'unit_tests.txt','six_features_recomputed_for_instances':24,'all_seed_costs_and_capacity_service_constraints_pass':432,'out_of_fold_rows_recomputed':240,'independent_held_out_label_mutations_pass':8,'independent_calibration_label_model_isolation_pass':8,'max_route_cost_absolute_difference':maxdelta,'same_decision_fingerprint_on_parent_replay':True,'ledger_and_oracles_recomputed':True},
      'CRC':{'n_calibration_each_fold':6,'primary_alpha':.1,'minimum_corrected_calibration_value':1/7,'primary_gates_fallback':8,
             'interpretation':'No threshold satisfies the corrected calibration inequality at alpha=.1. Zero relative-switch harm is structural because all decisions use training SBS. This does not mean the inequality reached .1 and is not empirical deployment certification.','controlled_loss_scope':'Unconditional frequency of accepted alternative with historical 3-seed mean length >1.01 times train-SBS; not accepted-subgroup conditional risk or individual-run safety.','finite_endpoint_equivalent':1},
      'paper_fit':{'P069':'Train-only SBS, feature scaling, and kNN performance aggregation are mechanism transfer; no SMAC or full AutoFolio system reproduction.','P116':'Equation (4), monotone right-continuous bounded binary losses and empty-set safe endpoint are correctly implemented; exchangeability to a deployment distribution is unestablished.','P093':'Seed-mean versus lucky-seed oracle accounting only; no original SAT experiment.', 'sources':['https://arxiv.org/html/2208.02814v4#S1.SS1','https://ml.informatik.uni-freiburg.de/wp-content/uploads/papers/15-JAIR-Autofolio.pdf']},
      'limitations':['24 previously observed synthetic development instances, not 432 independent samples or new solver experiments.','All seeds and both budgets for one base instance stay grouped within a fold; reused cross-fold training data and seeds do not add independent sample size.','Whole-panel prior headroom was observed before freezing the selector, so this is explicitly post-hoc exploration, not an untouched confirmatory test.','Three-seed mean oracle has finite-sample selection optimism and is not mathematical optimum or known expected performance.','0.25-second kNN improvement is 0.014412% from one selected alternative; no stable gain, significance, generalization, or economic utility claim is established.','1-second no selection headroom applies to this library and historical panel only.','Historical CPU and new feature/inference CPU were measured in potentially different conditions; adding them is not a measured end-to-end runtime.','Local self-recorded freeze timestamps and hashes do not independently authenticate preregistration chronology.'],
      'blocking_findings':[],'audit_wall_seconds':time.perf_counter()-t}
    write(out/'AUDIT_PARENT_INDEPENDENT.json',result);return result

if __name__=='__main__':
    a=turn_audit();print('TURN',a['verdict'],a['main_results'],flush=True)
    b=cvrp_audit();print('CVRP',b['verdict'],b['historical_solver_rows_revalidated'],b['tests'],flush=True)
