# 两项机制实验的父端独立复核

结论：两项均 PASS_WITH_SCOPE_LIMITATIONS。无阻碍性缺陷；没有修改原实验文件。

- turn_modes/AUDIT_PARENT_INDEPENDENT.json：36正式路网用第三套Floyd–Warshall弧状态闭包、穷举8868个容量合法服务排列和分区重算；与原mode-DP及raw-state oracle全部一致。
- cvrp_selection_crc/AUDIT_PARENT_INDEPENDENT.json：432条既有路线重新从坐标核验，24基础实例、240策略行独立重算；不导入实验实现。
- 每项子目录保留本次原单元测试日志、独立输出目录重跑及重算结果。
- PACKAGE_INTEGRITY.json核对两份源ZIP及审计报告SHA256。

关键边界：转弯36例是12个基础图各3规则版本；30禁转+2漏费并非现实失败率或算法性能排名。CVRP是432条历史日志回放，不是新432次求解；统计单位为24个实例。主CRC α=.10因每折仅6校准点而全回退；零相对改选伤害来自直接使用固定基线，不代表修正式达到.10，也不提供部署保证。

独立脚本 independent_parent_audit.py 在父工作区执行。它需要两项实验的完整目录、turn_modes/replay和cvrp_selection_crc/replay，以及来源清单所列原URP文件和作者PDF，才能复核原文件身份。用户保存包可能不包含受版权保护的作者全文或全部原URP来源；这些来源核验步骤需要原工作区。实验自身的独立重跑可按各实验README完成。父端独立结果及来源哈希已完整保存。

重跑父端审计：从该工作区运行 PYTHONDONTWRITEBYTECODE=1 python audit_new_paper_experiments_20261006/independent_parent_audit.py。脚本只写本审计目录；原实验源树在审计前后逐文件哈希保持不变。
