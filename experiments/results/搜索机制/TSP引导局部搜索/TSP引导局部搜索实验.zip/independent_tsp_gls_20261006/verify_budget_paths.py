"""Post-run non-formal safety probes; never overwrite or alter formal runs."""
import json
from pathlib import Path
import signal
import subprocess
import sys
import time
import experiment as ex

def main():
    coords=[(.1,.1),(.8,.9),(.1,.9),(.9,.1),(.5,.8)]
    probes=[]
    for kind,kwargs in [('cpu',{'cpu':.002,'wall':10}),('wall',{'cpu':10,'wall':.002})]:
        result=ex.solve(coords,'fixed_gls',770192,work=100000000,**kwargs)
        expected='cpu_limit' if kind=='cpu' else 'wall_limit_cooperative'
        assert result['termination']==expected, result['termination']
        probes.append({'probe':kind,'termination':result['termination'],
            'deltas':result['delta_evaluations'],'cpu':result['solver_cpu_seconds'],'wall':result['solver_wall_seconds']})
    def handler(signum,frame): raise ex.StopBudget('cpu_limit_signal')
    signal.signal(signal.SIGPROF,handler); signal.setitimer(signal.ITIMER_PROF,.01)
    result=ex.solve(coords,'fixed_gls',770192,work=100000000,cpu=10,wall=10)
    signal.setitimer(signal.ITIMER_PROF,0)
    assert result['termination']=='cpu_limit_signal'
    probes.append({'probe':'CPU signal interrupt','termination':result['termination'],'cpu':result['solver_cpu_seconds']})
    start=time.perf_counter()
    p=subprocess.Popen([sys.executable,'-c','import time; time.sleep(1)'])
    try:
        p.communicate(timeout=.03)
        raise AssertionError('Expected supervisor timeout')
    except subprocess.TimeoutExpired:
        p.kill(); p.communicate()
        assert p.returncode<0
    probes.append({'probe':'supervisor hard kill code path with sleeping dummy process',
        'configured_wall_seconds':.03,'elapsed_seconds':time.perf_counter()-start,'returncode':p.returncode})
    out={'all_passed':True,'scope':'post-formal synthetic safety probes only; formal parameters untouched',
        'clock_information':{key:vars(time.get_clock_info(key)) for key in ('process_time','perf_counter')},'probes':probes}
    (ex.ROOT/'results/budget_safety_probes.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))

if __name__=='__main__': main()
