"""Optional PNG rendering only, using preinstalled matplotlib outside solver venv.
No package installation or global environment modifications.
"""
import collections
import csv
import json
from pathlib import Path
import statistics
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parent
summary=json.loads((ROOT/'results/summary.json').read_text())
pairs=list(csv.DictReader((ROOT/'results/paired.csv').open()))
instances=list(csv.DictReader((ROOT/'results/per_instance.csv').open()))
rows=list(csv.DictReader((ROOT/'results/per_run.csv').open()))
arms=['single_two_opt','multistart_two_opt','fixed_gls']
labels=['Single 2-opt','Restart 2-opt','Fixed GLS']
colors=['#8b949e','#d55e00','#0072b2']
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,
    'axes.spines.right':False,'axes.labelcolor':'#17212b','text.color':'#17212b'})
fig=plt.figure(figsize=(12.4,10.2),facecolor='white')
gs=fig.add_gridspec(2,2,height_ratios=[1.5,1],hspace=.70,wspace=.45,
    left=.11,right=.96,top=.84,bottom=.22)
ax=fig.add_subplot(gs[0,:])
ii=[i for i in instances if int(i['n'])==50]
for k,item in enumerate(ii):
    vals=[float(p['gls_improvement_percent']) for p in pairs if p['instance_id']==item['instance_id']]
    col='#0072b2' if item['family']=='uniform' else '#009e73'
    ax.scatter(vals,[k-.11,k,k+.11],s=38,color=col,zorder=3)
    ax.scatter([float(item['mean_gls_improvement_percent'])],[k],marker='D',color='#17212b',s=45,zorder=4)
ax.axvline(0,color='#506070',lw=1)
ax.set_xlim(-.12,6.3); ax.set_ylim(5.55,-.55)
ax.set_yticks(range(6),[('Uniform' if i['family']=='uniform' else '3-cluster')+' '+i['instance_id'][-1] for i in ii])
ax.set_xticks(range(7)); ax.set_xticklabels([f'{i}%' for i in range(7)])
ax.grid(axis='x',color='#dfe5eb'); ax.set_axisbelow(True)
ax.set_xlabel('Reduction in original Euclidean tour length; positive favors GLS')
ax.set_title('A   n = 50: paired seed results and instance means',loc='left',fontweight='bold',pad=12)
ax.text(0,-.28,'Circles: paired seeds   Diamonds: instance means   13 wins / 5 ties / 0 losses',transform=ax.transAxes,fontsize=10)
bx=fig.add_subplot(gs[1,0])
hits=[summary['n12_optimal_hits'][a] for a in arms]
bx.barh(range(3),hits,color=colors,height=.58)
bx.set_yticks(range(3),labels); bx.invert_yaxis(); bx.set_xlim(0,20)
bx.set_xticks([0,6,12,18]); bx.set_xlabel('Optimal hits out of 18 runs (tolerance 1e-9)')
for k,h in enumerate(hits): bx.text(h+.3,k,f'{h}/18',va='center',fontsize=11)
bx.set_title('B   n = 12: exhaustive DP reference',loc='left',fontweight='bold',pad=12)
cx=fig.add_subplot(gs[1,1])
means=[1000*statistics.mean(float(r['solver_cpu_seconds']) for r in rows if r['arm']==a) for a in arms]
cx.barh(range(3),means,color=colors,height=.58)
cx.set_yticks(range(3),labels); cx.invert_yaxis(); cx.set_xlim(0,75)
for k,v in enumerate(means): cx.text(v+1,k,f'{v:.2f}',va='center')
cx.set_xlabel('Mean solver CPU per run (ms); all 36 runs/arm')
cx.set_title('C   Actual solver CPU',loc='left',fontweight='bold',pad=12)
fig.suptitle('Fixed GLS vs matched-budget restart 2-opt',x=.06,y=.96,ha='left',fontsize=21,fontweight='bold')
fig.text(.06,.913,'12 new synthetic instances · 3 search seeds each · 100,000 actual deltas per main run',fontsize=12)
fig.text(.06,.13,'n=50: mean reduction 1.1714%; six instances, not 18 independent data sets. No n=50 optimum claimed.',fontsize=10)
fig.text(.06,.105,'Equal delta caps do not imply equal CPU: GLS/restart aggregate CPU = 1.062×. Short CPU readings are noisy.',fontsize=10)
fig.text(.06,.08,'Single-start is an early-stop reference. This tests a host mechanism, not the EoH/LLM pipeline or TSPLIB.',fontsize=10)
fig.savefig(ROOT/'figures/tsp_gls_results.png',dpi=180)
print(json.dumps({'rendered':'figures/tsp_gls_results.png','matplotlib':matplotlib.__version__,'scope':'presentation only'}))
