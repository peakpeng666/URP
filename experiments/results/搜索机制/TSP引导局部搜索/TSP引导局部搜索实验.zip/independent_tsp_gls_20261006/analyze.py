"""Stdlib descriptive analysis and reproducible vector scientific figures."""
import collections
import csv
import html
import json
import math
from pathlib import Path
import statistics

ROOT=Path(__file__).resolve().parent
ARMS=('single_two_opt','multistart_two_opt','fixed_gls')
COLORS={'single_two_opt':'#8b949e','multistart_two_opt':'#d55e00','fixed_gls':'#0072b2'}
LABELS={'single_two_opt':'Single 2-opt','multistart_two_opt':'Restart 2-opt','fixed_gls':'Fixed GLS'}

def savecsv(path,rows):
    with Path(path).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)

def analyze():
    rows=[json.loads(s) for s in (ROOT/'results/runs.jsonl').read_text().splitlines()]
    dp=json.loads((ROOT/'results/held_karp.json').read_text())
    pairgroups=collections.defaultdict(dict)
    records=[]
    for r in rows:
        record={k:r.get(k) for k in ('instance_id','family','n','search_seed','arm','status','raw_length',
            'delta_evaluations','solver_cpu_seconds','solver_wall_seconds','process_wall_seconds',
            'solver_preprocessing_cpu_seconds','solver_preprocessing_wall_seconds','termination',
            'restarts','completed_starts','accepted_moves','local_optima','penalty_updates',
            'penalty_edge_increments','raw_full_objective_evaluations','augmented_full_objective_evaluations',
            'edge_utility_evaluations','distance_evaluations','lambda')}
        record['gap_to_DP_percent']=(max(0.0,100*(r['raw_length']/dp[r['instance_id']]['optimal_length_dp']-1))
               if r['n']==12 and r['status']=='completed' else '')
        record['optimal_hit_within_1e-9']=(abs(r['raw_length']-dp[r['instance_id']]['optimal_length_dp'])<=1e-9
               if r['n']==12 and r['status']=='completed' else '')
        records.append(record)
        pairgroups[r['instance_id'],r['search_seed']][r['arm']]=r
    savecsv(ROOT/'results/per_run.csv',records)
    paired=[]
    for (iid,seed),p in pairgroups.items():
        a,b=p['multistart_two_opt'],p['fixed_gls']
        diff=a['raw_length']-b['raw_length']
        paired.append({'instance_id':iid,'family':a['family'],'n':a['n'],'search_seed':seed,
            'multistart_length':a['raw_length'],'gls_length':b['raw_length'],
            'gls_improvement_percent':100*diff/a['raw_length'],
            'GLS_outcome':'win' if diff>1e-9 else 'loss' if diff<-1e-9 else 'tie',
            'multistart_cpu_seconds':a['solver_cpu_seconds'],'gls_cpu_seconds':b['solver_cpu_seconds'],
            'multistart_deltas':a['delta_evaluations'],'gls_deltas':b['delta_evaluations']})
    savecsv(ROOT/'results/paired.csv',paired)
    inst=[]
    for iid in dict.fromkeys(r['instance_id'] for r in paired):
        rr=[r for r in paired if r['instance_id']==iid]
        inst.append({'instance_id':iid,'family':rr[0]['family'],'n':rr[0]['n'],
            'mean_gls_improvement_percent':statistics.mean(r['gls_improvement_percent'] for r in rr),
            'min_seed_improvement_percent':min(r['gls_improvement_percent'] for r in rr),
            'max_seed_improvement_percent':max(r['gls_improvement_percent'] for r in rr),
            'seed_wins':sum(r['GLS_outcome']=='win' for r in rr),
            'seed_ties':sum(r['GLS_outcome']=='tie' for r in rr),
            'seed_losses':sum(r['GLS_outcome']=='loss' for r in rr)})
    savecsv(ROOT/'results/per_instance.csv',inst)
    strata=[]
    for family in ('uniform','three_cluster'):
        for n in (12,50):
            ii=[i for i in inst if i['family']==family and i['n']==n]
            pp=[i for i in paired if i['family']==family and i['n']==n]
            strata.append({'family':family,'n':n,'instances':len(ii),'paired_seeds':len(pp),
                'mean_gls_improvement_percent':statistics.mean(i['mean_gls_improvement_percent'] for i in ii),
                'min_instance_mean':min(i['mean_gls_improvement_percent'] for i in ii),
                'max_instance_mean':max(i['mean_gls_improvement_percent'] for i in ii),
                'wins':sum(p['GLS_outcome']=='win' for p in pp),'ties':sum(p['GLS_outcome']=='tie' for p in pp),
                'losses':sum(p['GLS_outcome']=='loss' for p in pp)})
    savecsv(ROOT/'results/strata.csv',strata)
    resources=[]
    for n in (12,50):
        for arm in ARMS:
            rr=[r for r in rows if r['n']==n and r['arm']==arm]
            resources.append({'n':n,'arm':arm,'runs':len(rr),
                'mean_delta_evaluations':statistics.mean(r['delta_evaluations'] for r in rr),
                'min_delta_evaluations':min(r['delta_evaluations'] for r in rr),
                'max_delta_evaluations':max(r['delta_evaluations'] for r in rr),
                'mean_solver_cpu_seconds':statistics.mean(r['solver_cpu_seconds'] for r in rr),
                'mean_solver_wall_seconds':statistics.mean(r['solver_wall_seconds'] for r in rr),
                'mean_restarts':statistics.mean(r['restarts'] for r in rr),
                'mean_penalty_updates':statistics.mean(r['penalty_updates'] for r in rr)})
    savecsv(ROOT/'results/resources.csv',resources)
    n50=[p for p in paired if p['n']==50]
    summary={'scope':'Synthetic development component study only; not EoH/LLM end-to-end reproduction',
        'runs':108,'instances':12,'strata':strata,
        'n50':{'paired_seeds':18,'instances':6,
               'mean_gls_improvement_percent':statistics.mean(p['gls_improvement_percent'] for p in n50),
               'wins':sum(p['GLS_outcome']=='win' for p in n50),'ties':sum(p['GLS_outcome']=='tie' for p in n50),
               'losses':sum(p['GLS_outcome']=='loss' for p in n50),
               'six_instance_means':[i['mean_gls_improvement_percent'] for i in inst if i['n']==50]},
        'n12_optimal_hits':{a:sum(r['optimal_hit_within_1e-9'] is True for r in records if r['arm']==a and r['n']==12) for a in ARMS},
        'n12_mean_gaps_percent':{a:statistics.mean(r['gap_to_DP_percent'] for r in records if r['arm']==a and r['n']==12) for a in ARMS},
        'timing':{'solver_cpu_sum_seconds':sum(r['solver_cpu_seconds'] for r in rows),
          'solver_wall_sum_seconds':sum(r['solver_wall_seconds'] for r in rows),
          'process_wall_sum_seconds':sum(r['process_wall_seconds'] for r in rows),
          'DP_preprocessing_cpu_sum_seconds':sum(x['cpu_seconds'] for x in dp.values()),
          'DP_preprocessing_wall_sum_seconds':sum(x['wall_seconds'] for x in dp.values()),
          'zero_CPU_readings_single_reference':sum(r['solver_cpu_seconds']==0 for r in rows),
          'GLS_to_multistart_aggregate_CPU_ratio':sum(r['solver_cpu_seconds'] for r in rows if r['arm']=='fixed_gls')/sum(r['solver_cpu_seconds'] for r in rows if r['arm']=='multistart_two_opt')},
        'resources':resources,'penalty_updates':sum(r['penalty_updates'] for r in rows),
        'main_budget_terminated_runs':sum(r['termination']=='delta_limit' for r in rows),
        'single_reference_early_local_optima':sum(r['termination']=='first_local_optimum' for r in rows)}
    (ROOT/'results/summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    figure(paired,inst,records,resources,summary)
    print(json.dumps(summary,indent=2))

def figure(paired,instances,records,resources,summary):
    parts=['<svg xmlns="http://www.w3.org/2000/svg" width="1240" height="910" viewBox="0 0 1240 910">',
      '<rect width="1240" height="910" fill="#ffffff"/>',
      '<style>text{font-family:DejaVu Sans,Arial,sans-serif;fill:#17212b} .small{font-size:13px}.label{font-size:16px}.title{font-size:22px;font-weight:bold}.grid{stroke:#dfe5eb;stroke-width:1}.axis{stroke:#506070;stroke-width:1.3}</style>']
    def text(x,y,s,cls='label',anchor='start',fill=None):
        parts.append(f'<text x="{x}" y="{y}" class="{cls}" text-anchor="{anchor}"'+(f' fill="{fill}"' if fill else '')+'>'+html.escape(str(s))+'</text>')
    def line(x1,y1,x2,y2,cls='grid'):
        parts.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" class="{cls}"/>')
    text(45,42,'Fixed GLS vs matched-budget restart 2-opt','title')
    text(45,69,'12 new synthetic instances · 3 search seeds each · 100,000 evaluated 2-opt deltas per main run','label')
    text(45,97,'A  n = 50: paired reduction in original Euclidean tour length','title')
    x0,x1=250,1160; ytop=133; rowh=52
    for v in range(7):
        x=x0+(x1-x0)*v/6
        line(x,ytop-7,x,ytop+6*rowh-15)
        text(x,ytop+6*rowh+10,f'{v}%','small','middle')
    ii=[x for x in instances if x['n']==50]
    for k,item in enumerate(ii):
        y=ytop+k*rowh+12
        label=('Uniform' if item['family']=='uniform' else '3-cluster')+f'  instance {item["instance_id"][-1]}'
        text(225,y+5,label,'label','end')
        vals=[p['gls_improvement_percent'] for p in paired if p['instance_id']==item['instance_id']]
        col='#0072b2' if item['family']=='uniform' else '#009e73'
        for j,val in enumerate(vals):
            x=x0+(x1-x0)*val/6; yy=y+(j-1)*8
            parts.append(f'<circle cx="{x}" cy="{yy}" r="5" fill="{col}" fill-opacity="0.85"/>')
        x=x0+(x1-x0)*item['mean_gls_improvement_percent']/6
        parts.append(f'<path d="M{x},{y-8} L{x+7},{y} L{x},{y+8} L{x-7},{y} Z" fill="#17212b"/>')
    text(250,485,'Circles: paired seeds   Diamonds: instance means   Positive values favor GLS','small')
    text(250,510,'13 wins / 5 ties / 0 losses; mean reduction 1.1714%. Six instances, not 18 independent data sets.','small')
    text(45,552,'B  n = 12: exhaustive DP reference','title')
    text(650,552,'C  Actual search work and CPU','title')
    for k,arm in enumerate(ARMS):
        rr=[r for r in records if r['n']==12 and r['arm']==arm]
        hits=summary['n12_optimal_hits'][arm]
        y=603+58*k
        parts.append(f'<rect x="50" y="{y-20}" width="{hits/18*340}" height="25" fill="{COLORS[arm]}"/>')
        text(405,y,f'{hits}/18 optimal hits','label')
        text(50,y+27,LABELS[arm]+' · mean gap '+f'{summary["n12_mean_gaps_percent"][arm]:.4f}%', 'small')
    for k,arm in enumerate(ARMS):
        y=600+58*k
        cpu=statistics.mean(r['solver_cpu_seconds'] for r in records if r['arm']==arm)
        work=statistics.mean(r['delta_evaluations'] for r in records if r['arm']==arm)
        text(650,y,LABELS[arm], 'label')
        text(1160,y,f'{work:,.0f} deltas / {1000*cpu:.2f} ms CPU', 'label','end')
    text(650,789,'Equal delta caps do not imply equal CPU.','small')
    text(650,811,f'GLS / restart aggregate CPU = {summary["timing"]["GLS_to_multistart_aggregate_CPU_ratio"]:.3f}×.','small')
    text(45,853,'Fresh synthetic development set; unrounded Euclidean distances; no n=50 optimum claimed.','small')
    text(45,878,'Single-start is an early-stop reference. This tests the host search mechanism, not the EoH/LLM pipeline.','small')
    parts.append('</svg>')
    (ROOT/'figures/tsp_gls_results.svg').write_text('\n'.join(parts))

if __name__=='__main__': analyze()
