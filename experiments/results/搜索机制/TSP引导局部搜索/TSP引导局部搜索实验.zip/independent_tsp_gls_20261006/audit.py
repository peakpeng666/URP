"""Independent post-hoc TSP contract, raw-coordinate and exhaustive DP audit.

Deliberately does not import experiment.py or any CVRP checker/cost function.
"""
import collections
import hashlib
import json
import math
from pathlib import Path
import time

ROOT=Path(__file__).resolve().parent
TOL=1e-9

def check_cycle(coords,cycle,reported=None):
    n=len(coords)
    if not isinstance(cycle,list) or len(cycle)!=n+1:
        raise ValueError('wrong explicit cycle length')
    if any(type(v) is not int for v in cycle):
        raise ValueError('node IDs must be integers (not booleans)')
    if cycle[0]!=0 or cycle[-1]!=0 or sorted(cycle[:-1])!=list(range(n)):
        raise ValueError('not one Hamiltonian cycle rooted at 0')
    if any(len(p)!=2 or not all(math.isfinite(x) for x in p) for p in coords):
        raise ValueError('invalid coordinates')
    lengths=[]
    for a,b in zip(cycle,cycle[1:]):
        dx=coords[a][0]-coords[b][0]; dy=coords[a][1]-coords[b][1]
        lengths.append(math.sqrt(dx*dx+dy*dy))
    total=math.fsum(lengths)
    if reported is not None and (not math.isfinite(reported) or abs(total-reported)>TOL):
        raise ValueError('reported raw length differs from coordinate recomputation')
    return total

def independently_optimize(coords):
    # Different dense-array state enumeration and sqrt metric; no path code reuse.
    n=len(coords); width=1<<(n-1)
    lengths=[[math.sqrt((p[0]-q[0])**2+(p[1]-q[1])**2) for q in coords] for p in coords]
    table=[[math.inf]*n for _ in range(width)]
    for j in range(1,n): table[1<<(j-1)][j]=lengths[0][j]
    transitions=0
    for mask in range(1,width):
        for end in range(1,n):
            bit=1<<(end-1)
            if not mask&bit: continue
            prev=mask^bit
            if not prev: continue
            for k in range(1,n):
                if prev&(1<<(k-1)):
                    table[mask][end]=min(table[mask][end],table[prev][k]+lengths[k][end])
                    transitions+=1
    return min(table[-1][j]+lengths[j][0] for j in range(1,n)),transitions

def audit():
    start=time.perf_counter(); startcpu=time.process_time()
    instances={x['id']:x for x in json.loads((ROOT/'data/instances.json').read_text())}
    rows=[json.loads(x) for x in (ROOT/'results/runs.jsonl').read_text().splitlines()]
    expected={(iid,seed,arm) for iid,item in instances.items() for seed in item['search_seeds']
              for arm in ('single_two_opt','multistart_two_opt','fixed_gls')}
    actual=[(r['instance_id'],r['search_seed'],r['arm']) for r in rows]
    assert len(actual)==108 and set(actual)==expected and len(set(actual))==108
    freeze=json.loads((ROOT/'PRE_RUN_SHA256SUMS.json').read_text())
    for rel,digest in freeze['files'].items():
        assert hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()==digest, rel
    dp=json.loads((ROOT/'results/held_karp.json').read_text()); dp_audit=[]
    for iid,out in dp.items():
        t=time.process_time(); w=time.perf_counter()
        val,trans=independently_optimize(instances[iid]['coordinates'])
        check_cycle(instances[iid]['coordinates'],out['optimal_cycle'],out['optimal_length_dp'])
        assert abs(val-out['optimal_length_dp'])<=TOL
        dp_audit.append({'instance_id':iid,'independent_optimal_length':val,
            'difference':val-out['optimal_length_dp'],'independent_transitions':trans,
            'cpu_seconds':time.process_time()-t,'wall_seconds':time.perf_counter()-w})
    by_pair=collections.defaultdict(dict); checks=[]; penalties_checked=0
    failures=[]
    for row in rows:
        if row['status']!='completed':
            failures.append({k:row.get(k) for k in ('instance_id','arm','search_seed','status','error')})
            continue
        t=time.process_time(); w=time.perf_counter()
        item=instances[row['instance_id']]; coords=item['coordinates']; n=item['n']
        raw=check_cycle(coords,row['best_cycle'],row['raw_length'])
        check_cycle(coords,row['initial_route'])
        assert 0<row['delta_evaluations']<=100000
        assert row['solver_cpu_seconds']<=3.03
        assert row['solver_wall_seconds']<8.0
        # End-to-end overhead is separate; OS scheduling at deadline may add a tiny delay.
        assert row['process_wall_seconds']<=8.2
        assert row['solver_preprocessing_cpu_seconds']<=row['solver_cpu_seconds']
        assert row['distance_evaluations']==n*n
        if n==12: assert raw>=dp[item['id']]['optimal_length_dp']-TOL
        by_pair[(item['id'],row['search_seed'])][row['arm']]=row
        if row['arm']=='fixed_gls':
            lam=row['lambda']
            if lam is not None:
                assert abs(lam-row['first_local_optimum_length']/(6*n))<1e-15
            p=collections.Counter()
            for idx,event in enumerate(row['penalty_log']):
                cycle=event['current_cycle']; value=check_cycle(coords,cycle,event['raw_length'])
                edges=[tuple(sorted((a,b))) for a,b in zip(cycle,cycle[1:])]
                distances={e:math.dist(coords[e[0]],coords[e[1]]) for e in edges}
                utilities={e:distances[e]/(1+p[e]) for e in edges}; maximum=max(utilities.values())
                selected=sorted(e for e,u in utilities.items() if u>=maximum-1e-12)
                assert selected==[tuple(e) for e in event['edges']]
                assert abs(maximum-event['max_utility'])<=TOL
                assert event['update']==idx+1 and event['delta_evaluations']<=row['delta_evaluations']
                for e in selected: p[e]+=1
                aug=math.fsum(distances[e]+lam*p[e] for e in edges)
                assert abs(aug-event['augmented_length'])<=TOL
                penalties_checked+=1
            assert len(row['penalty_log'])==row['penalty_updates']
            assert sum(p.values())==row['penalty_edge_increments']
            assert row['edge_utility_evaluations']==n*row['penalty_updates']
        checks.append({'instance_id':item['id'],'seed':row['search_seed'],'arm':row['arm'],
            'valid':True,'coordinate_raw_length':raw,'length_error':raw-row['raw_length'],
            'checker_cpu_seconds':time.process_time()-t,'checker_wall_seconds':time.perf_counter()-w})
    for group in by_pair.values():
        if len(group)==3:
            initial=[r['initial_route'] for r in group.values()]
            assert initial[0]==initial[1]==initial[2]
            gls=group['fixed_gls']; single=group['single_two_opt']
            if gls['first_local_optimum_length'] is not None:
                assert abs(gls['first_local_optimum_length']-single['raw_length'])<=TOL
    outcome={'audit_passed':True,'expected_slots':108,'observed_slots':len(rows),
        'valid_completed_routes':len(checks),'failed_or_censored':failures,
        'paired_initial_routes_verified':len(by_pair),'penalty_updates_independently_replayed':penalties_checked,
        'six_exact_DP_rechecks':dp_audit,'max_raw_length_error':max(x['length_error'] for x in checks),
        'audit_cpu_seconds':time.process_time()-startcpu,'audit_wall_seconds':time.perf_counter()-start,
        'frozen_files_unchanged':True,'tolerance':TOL}
    (ROOT/'results/audit.json').write_text(json.dumps(outcome,indent=2)+'\n')
    (ROOT/'results/checker_revalidation.jsonl').write_text(''.join(json.dumps(c)+'\n' for c in checks))
    print(json.dumps(outcome,indent=2))

if __name__=='__main__': audit()
