"""Fixed classical GLS versus matched-budget random-restart 2-opt: stdlib only.

This is an independently implemented TSP component study, not EoH reproduction.
Reference CVRP files are archived for provenance only; never imported/executed.
"""
import argparse
import datetime
import hashlib
import itertools
import json
import math
import os
from pathlib import Path
import random
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
EPS = 1e-12
ARMS = ('single_two_opt', 'multistart_two_opt', 'fixed_gls')

def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def dump(path, obj):
    Path(path).write_text(json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False) + '\n')

def matrix(coords):
    return [[math.hypot(x-u, y-v) for u,v in coords] for x,y in coords]

def cycle_cost(route, d):
    return math.fsum(d[a][b] for a,b in zip(route, route[1:]+route[:1]))

def pairs(n):
    # Node 0 is fixed; exclude full reversal (identical undirected cycle).
    return [(i,j) for i in range(1,n-1) for j in range(i+1,n)
            if not (i == 1 and j == n-1)]

def delta(route, d, i, j):
    a,b,c,e = route[i-1],route[i],route[j],route[(j+1)%len(route)]
    return d[a][c] + d[b][e] - d[a][b] - d[c][e]

def apply_move(route, i, j):
    return route[:i] + list(reversed(route[i:j+1])) + route[j+1:]

def initial(n, seed):
    rng = random.Random(seed)
    tail = list(range(1,n)); rng.shuffle(tail)
    return [0]+tail, rng

class StopBudget(Exception):
    pass

class Budget:
    def __init__(self, work=100000, cpu=3.0, wall=8.0):
        self.start_cpu = time.process_time(); self.start_wall = time.perf_counter()
        self.work_limit,self.cpu_limit,self.wall_limit = work,cpu,wall
        self.evaluations=0; self.checks=0

    def guard(self, delta_evaluation=False):
        # Called BEFORE every actual delta and other substantial search operation.
        self.checks += 1
        if delta_evaluation and self.evaluations >= self.work_limit:
            raise StopBudget('delta_limit')
        if time.process_time()-self.start_cpu >= self.cpu_limit:
            raise StopBudget('cpu_limit')
        if time.perf_counter()-self.start_wall >= self.wall_limit:
            raise StopBudget('wall_limit_cooperative')
        if delta_evaluation:
            self.evaluations += 1

    def elapsed(self):
        return time.process_time()-self.start_cpu, time.perf_counter()-self.start_wall

def penalty_edges(route, d, penalties):
    edges = [tuple(sorted((a,b))) for a,b in zip(route,route[1:]+route[:1])]
    utilities = [(d[a][b]/(1+penalties[a][b]),a,b) for a,b in edges]
    largest = max(u for u,a,b in utilities)
    # Frozen deterministic tie rule: penalize ALL present edges within 1e-12
    # of the max utility, processed in ascending undirected endpoint order.
    return sorted((a,b) for u,a,b in utilities if u >= largest-EPS), largest

def solve(coords, arm, seed, work=100000, cpu=3.0, wall=8.0):
    budget=Budget(work,cpu,wall)
    n=len(coords); route=None; best=None; best_value=None; d=None
    state={'accepted_moves':0,'local_optima':0,'completed_starts':0,
           'restarts':0,'penalty_updates':0,'penalty_edge_increments':0,
           'raw_full_objective_evaluations':0,'augmented_full_objective_evaluations':0,
           'edge_utility_evaluations':0,'distance_evaluations':0,
           'lambda':None,'first_local_optimum_length':None,
           'initial_route':None,'penalty_log':[], 'incumbent_trace':[]}
    init_cpu=time.process_time(); init_wall=time.perf_counter()
    prep_cpu=prep_wall=0.0
    def evaluate(candidate, weights):
        budget.guard()
        key='raw_full_objective_evaluations' if weights is d else 'augmented_full_objective_evaluations'
        state[key]+=1
        return cycle_cost(candidate,weights)
    def observe(candidate, cause):
        nonlocal best,best_value
        budget.guard()
        value=evaluate(candidate,d)
        # Actual raw objective determines saved best; no augmented scoring.
        if best_value is None or value < best_value-EPS:
            best,best_value=candidate[:],value
            state['incumbent_trace'].append({'delta_evaluations':budget.evaluations,
               'raw_length':value,'cause':cause})
        return value
    def descend(current, weights):
        budget.guard(); value=evaluate(current,weights)
        while True:
            move=None; best_delta=-EPS
            for i,j in moves:
                budget.guard(delta_evaluation=True)
                change=delta(current,weights,i,j)
                if change < best_delta:
                    best_delta,move=change,(i,j)
            budget.guard()
            if move is None:
                state['local_optima'] += 1
                return current
            candidate=apply_move(current,*move)
            budget.guard(); new_value=evaluate(candidate,weights)
            if not new_value < value-EPS:
                raise ArithmeticError('Delta predicted improvement but full objective disagreed')
            current,value=candidate,new_value
            state['accepted_moves'] += 1
            observe(current,'accepted_move')
    termination='uninitialized'
    try:
        budget.guard(); d=matrix(coords); state['distance_evaluations']=n*n
        budget.guard(); moves=pairs(n)
        budget.guard(); route,rng=initial(n,seed)
        state['initial_route']=route+[0]
        observe(route,'initial')
        prep_cpu=time.process_time()-init_cpu; prep_wall=time.perf_counter()-init_wall
        if arm == 'single_two_opt':
            route=descend(route,d)
            state['completed_starts']=1
            termination='first_local_optimum'
        elif arm == 'multistart_two_opt':
            while True:
                route=descend(route,d)
                state['completed_starts'] += 1
                budget.guard()
                if budget.evaluations >= budget.work_limit:
                    raise StopBudget('delta_limit')
                tail=list(range(1,n)); rng.shuffle(tail)
                route=[0]+tail; state['restarts']+=1
                observe(route,'restart')
        elif arm == 'fixed_gls':
            route=descend(route,d)
            state['completed_starts']=1
            budget.guard(); first=evaluate(route,d)
            state['first_local_optimum_length']=first
            lam=first/(6*n); state['lambda']=lam
            penalties=[[0]*n for _ in range(n)]
            weights=[row[:] for row in d]
            while True:
                budget.guard()
                if budget.evaluations >= budget.work_limit:
                    raise StopBudget('delta_limit')
                edges,utility=penalty_edges(route,d,penalties)
                state['edge_utility_evaluations']+=n
                budget.guard()
                for a,b in edges:
                    budget.guard()
                    penalties[a][b]+=1; penalties[b][a]+=1
                    weights[a][b]=weights[b][a]=d[a][b]+lam*penalties[a][b]
                state['penalty_updates']+=1
                state['penalty_edge_increments']+=len(edges)
                state['penalty_log'].append({'update':state['penalty_updates'],
                    'delta_evaluations':budget.evaluations,'max_utility':utility,
                    'edges':[list(x) for x in edges],
                    'current_cycle':route+[0], 'raw_length':evaluate(route,d),
                    'augmented_length':evaluate(route,weights)})
                route=descend(route,weights)
        else:
            raise ValueError(arm)
    except StopBudget as exc:
        termination=str(exc)
    elapsed_cpu,elapsed_wall=budget.elapsed()
    return {'status':'completed' if best is not None else 'failed_before_incumbent',
       'arm':arm,'search_seed':seed,'best_cycle':best+[0] if best else None,
       'raw_length':best_value,'termination':termination,
       'delta_evaluations':budget.evaluations,'budget_checks':budget.checks,
       'solver_cpu_seconds':elapsed_cpu,'solver_wall_seconds':elapsed_wall,
       'solver_preprocessing_cpu_seconds':prep_cpu,
       'solver_preprocessing_wall_seconds':prep_wall,
       'budgets':{'delta_limit':work,'cpu_seconds':cpu,'hard_process_wall_seconds':wall},
       **state}

def held_karp(coords):
    """Exhaustive subset DP on unrounded binary64 Euclidean edge weights."""
    start_cpu=time.process_time(); start_wall=time.perf_counter()
    d=matrix(coords); n=len(d); costs={}; predecessor={}; transitions=0
    for j in range(1,n):
        costs[(1<<(j-1),j)]=d[0][j]; predecessor[(1<<(j-1),j)]=0
    for size in range(2,n):
        for subset in itertools.combinations(range(1,n),size):
            mask=sum(1<<(v-1) for v in subset)
            for j in subset:
                rest=mask^(1<<(j-1))
                options=[(costs[(rest,k)]+d[k][j],k) for k in subset if k!=j]
                transitions+=len(options)
                value,k=min(options)
                costs[(mask,j)]=value; predecessor[(mask,j)]=k
    full=(1<<(n-1))-1
    value,last=min((costs[(full,j)]+d[j][0],j) for j in range(1,n))
    reverse=[]; mask=full; j=last
    while j:
        reverse.append(j); prev=predecessor[(mask,j)]; mask^=1<<(j-1); j=prev
    route=[0]+list(reversed(reverse))
    return {'optimal_length_dp':value,'optimal_cycle':route+[0],
       'optimal_length_recomputed':cycle_cost(route,d), 'states':len(costs),
       'transitions':transitions,'cpu_seconds':time.process_time()-start_cpu,
       'wall_seconds':time.perf_counter()-start_wall,
       'numeric_model':'unrounded Euclidean math.hypot distances; binary64 DP sums',
       'comparison_tolerance':1e-9}

def prepare():
    if (ROOT/'data/config.json').exists():
        raise RuntimeError('Frozen design already exists; refusing regeneration')
    instances=[]
    for family in ('uniform','three_cluster'):
        for n in (12,50):
            for rep in range(3):
                iid=f'{family}_n{n}_i{rep+1}'
                seed=202610060000+(0 if family=='uniform' else 1000)+n*10+rep
                rng=random.Random(seed)
                if family=='uniform':
                    coords=[[rng.random(),rng.random()] for _ in range(n)]
                else:
                    centers=((.2,.2),(.8,.2),(.5,.8))
                    coords=[[min(.999,max(.001,rng.gauss(centers[i%3][a],.07)))
                             for a in (0,1)] for i in range(n)]
                    rng.shuffle(coords)
                seeds=[202610061000000+(0 if family=='uniform' else 100000)+n*100+rep*10+k
                       for k in range(3)]
                instances.append({'id':iid,'family':family,'n':n,'replicate':rep+1,
                    'instance_seed':seed,'search_seeds':seeds,'coordinates':coords})
    config={'design_version':'independent-tsp-gls-v1','created_utc':stamp(),
       'instance_count':12,'nominal_runs':108,'replicates_per_instance':3,
       'arms':list(ARMS),'delta_limit':100000,'cpu_seconds':3.0,'hard_process_wall_seconds':8.0,
       'epsilon':EPS,'lambda_rule':'first local optimum raw length / (6*n)',
       'lambda_scope':'Fixed for whole run; 1/6 prechosen here, not claimed author optimum',
       'penalty_ties':'all current undirected edges with utility >= max utility - 1e-12, endpoint-sorted',
       'move_ties':'best strict improvement by > 1e-12; lexicographic i,j scan, first minimum retained',
       'partial_scan_rule':'discard incomplete scan; return best complete accepted raw-d incumbent',
       'generators':{'uniform':'n IID U[0,1)^2 points',
        'three_cluster':'centers (.2,.2),(.8,.2),(.5,.8); balanced round-robin allocation; independent Gaussian sigma .07 coordinates; clip [.001,.999]; shuffle nodes'},
       'data_scope':'fresh reproducible synthetic development set; not TSPLIB or holdout',
       'metric':'single Hamiltonian cycle; original unrounded Euclidean length',
       'preprocessing':'distance matrix included in each solver budget; exact DP and verification accounted separately',
       'inferential_unit':'instance; seeds nested within instance; descriptive study, no generalization claim',
       'run_order':'instance order then seed order; arm order cyclically rotated by global pair index'}
    dump(ROOT/'data/instances.json',instances); dump(ROOT/'data/config.json',config)
    print(json.dumps({'prepared':len(instances),'slots':108,'created_utc':stamp()}),flush=True)

def worker(args):
    item=next(x for x in json.loads((ROOT/'data/instances.json').read_text()) if x['id']==args.instance)
    out=ROOT/'results'/f'{args.instance}_{args.seed}_{args.arm}.json'
    def cpu_handler(signum,frame):
        raise StopBudget('cpu_limit_signal')
    signal.signal(signal.SIGPROF,cpu_handler)
    signal.setitimer(signal.ITIMER_PROF,3.0)
    try:
        result=solve(item['coordinates'],args.arm,args.seed)
        signal.setitimer(signal.ITIMER_PROF,0)
        result.update({'instance_id':item['id'],'family':item['family'],'n':item['n'],
                       'finished_utc':stamp()})
    except BaseException as exc:
        signal.setitimer(signal.ITIMER_PROF,0)
        result={'status':'failed','instance_id':item['id'],'family':item['family'],'n':item['n'],
            'arm':args.arm,'search_seed':args.seed,'error':repr(exc),'finished_utc':stamp()}
    dump(out,result)

def run():
    manifest=ROOT/'PRE_RUN_SHA256SUMS.json'
    for rel,digest in json.loads(manifest.read_text())['files'].items():
        assert hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()==digest, rel
    ledger=ROOT/'results/runs.jsonl'
    if ledger.exists():
        raise RuntimeError('Prior formal ledger exists; no overwrite or silent resume')
    instances=json.loads((ROOT/'data/instances.json').read_text())
    dp={}
    for item in instances:
        if item['n']==12:
            dp[item['id']]=held_karp(item['coordinates'])
    dump(ROOT/'results/held_karp.json',dp)
    pair_index=0; rows=[]; started=stamp(); wall_start=time.perf_counter()
    for item in instances:
        first_batch=[]
        for seed in item['search_seeds']:
            shift=pair_index%3; order=ARMS[shift:]+ARMS[:shift]
            for arm in order:
                run_start=time.perf_counter()
                outfile=ROOT/'results'/f'{item["id"]}_{seed}_{arm}.json'
                command=[sys.executable,str(ROOT/'experiment.py'),'worker','--instance',item['id'],
                         '--seed',str(seed),'--arm',arm]
                proc=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
                try:
                    stdout,stderr=proc.communicate(timeout=8.0)
                    process_wall=time.perf_counter()-run_start
                    if outfile.exists():
                        result=json.loads(outfile.read_text())
                    else:
                        result={'status':'failed_no_output','termination':'worker_exited_without_output'}
                except subprocess.TimeoutExpired:
                    proc.kill(); stdout,stderr=proc.communicate()
                    process_wall=time.perf_counter()-run_start
                    result={'status':'hard_wall_killed','termination':'hard_process_wall_limit',
                            'raw_length':None,'best_cycle':None}
                result.update({'instance_id':item['id'],'family':item['family'],'n':item['n'],
                     'arm':arm,'search_seed':seed,'process_wall_seconds':process_wall,
                     'returncode':proc.returncode,'stderr':stderr,'stdout':stdout,
                     'run_order_in_pair':order.index(arm),'pair_index':pair_index})
                rows.append(result); first_batch.append(result)
                with ledger.open('a') as f:
                    f.write(json.dumps(result,allow_nan=False)+'\n'); f.flush(); os.fsync(f.fileno())
                print(json.dumps({'slot':len(rows),'id':item['id'],'seed':seed,'arm':arm,
                    'status':result['status'],'length':result.get('raw_length'),
                    'deltas':result.get('delta_evaluations'),'termination':result.get('termination')}),flush=True)
            pair_index+=1
        if len(rows)==9:
            dump(ROOT/'results/first_instance.json',first_batch)
    dump(ROOT/'results/completion.json',{'started_utc':started,'finished_utc':stamp(),
        'slots':len(rows),'wall_seconds':time.perf_counter()-wall_start,
        'status_counts':{s:sum(r['status']==s for r in rows) for s in sorted(set(r['status'] for r in rows))},
        'max_simultaneous_compute_workers':1})

if __name__=='__main__':
    parser=argparse.ArgumentParser(); parser.add_argument('action',choices=['prepare','run','worker'])
    parser.add_argument('--instance'); parser.add_argument('--seed',type=int); parser.add_argument('--arm')
    args=parser.parse_args()
    if args.action=='prepare': prepare()
    elif args.action=='run': run()
    else: worker(args)
