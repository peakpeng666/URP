import itertools
import math
import random
import unittest
from unittest.mock import patch
import audit
import experiment as ex

class Validation(unittest.TestCase):
    def test_exhaustive_DP_vs_brute_force(self):
        for n in range(3,9):
            rng=random.Random(880000+n)
            coords=[(rng.random(),rng.random()) for _ in range(n)]
            brute=min(audit.check_cycle(coords,[0]+list(p)+[0])
                      for p in itertools.permutations(range(1,n)))
            exact=ex.held_karp(coords)
            other,_=audit.independently_optimize(coords)
            self.assertAlmostEqual(brute,exact['optimal_length_dp'],places=12)
            self.assertAlmostEqual(brute,other,places=12)
            self.assertAlmostEqual(brute,audit.check_cycle(coords,exact['optimal_cycle']),places=12)

    def test_all_2opt_deltas_raw_and_augmented(self):
        rng=random.Random(771992)
        for n in range(3,13):
            coords=[(rng.random(),rng.random()) for _ in range(n)]
            raw=ex.matrix(coords); weights=[x[:] for x in raw]
            for i in range(n):
                for j in range(i): weights[i][j]=weights[j][i]=raw[i][j]+.05*rng.randrange(7)
            self.assertEqual(len(ex.pairs(n)),n*(n-3)//2)
            for _ in range(10):
                tail=list(range(1,n)); rng.shuffle(tail); route=[0]+tail
                for i,j in ex.pairs(n):
                    candidate=ex.apply_move(route,i,j)
                    audit.check_cycle(coords,candidate+[0])
                    for d in (raw,weights):
                        self.assertAlmostEqual(ex.delta(route,d,i,j),
                            ex.cycle_cost(candidate,d)-ex.cycle_cost(route,d),places=12)

    def test_checker_rejects_invalid_cycles_and_scores(self):
        c=[(0,0),(1,0),(1,1),(0,1)]
        self.assertEqual(audit.check_cycle(c,[0,1,2,3,0]),4)
        for route in ([0,1,1,3,0],[0,1,2,3],[0,1,2,4,0],[1,2,3,0,1],
                      [0,True,2,3,0],[[0,1,0],[0,2,3,0]]):
            with self.assertRaises(ValueError): audit.check_cycle(c,route)
        with self.assertRaises(ValueError): audit.check_cycle(c,[0,1,2,3,0],3.9)

    def test_guard_before_delta_and_exact_work_count(self):
        coords=[(.1,.1),(.8,.9),(.1,.9),(.9,.1),(.5,.8)]
        for arm in ex.ARMS:
            for limit in (0,1,7,19):
                calls=[]; original=ex.delta
                def counted(*a): calls.append(1); return original(*a)
                with patch.object(ex,'delta',counted): result=ex.solve(coords,arm,7701,work=limit)
                self.assertEqual(len(calls),result['delta_evaluations'])
                self.assertLessEqual(len(calls),limit)
                audit.check_cycle(coords,result['best_cycle'],result['raw_length'])

    def test_cpu_wall_guard_before_delta(self):
        for limitname in ('cpu','wall'):
            b=ex.Budget(cpu=3,wall=8)
            if limitname=='cpu': b.start_cpu-=4
            else: b.start_wall-=9
            with self.assertRaises(ex.StopBudget): b.guard(delta_evaluation=True)
            self.assertEqual(b.evaluations,0)

    def test_penalty_ties_and_raw_best_semantics(self):
        c=[(0,0),(1,0),(1,1),(0,1)]; d=ex.matrix(c)
        edges,maximum=ex.penalty_edges([0,1,2,3],d,[[0]*4 for _ in range(4)])
        self.assertEqual(edges,[(0,1),(0,3),(1,2),(2,3)])
        self.assertEqual(maximum,1)
        result=ex.solve(c,'fixed_gls',70422,work=2000)
        self.assertEqual(result['raw_length'],4)
        self.assertGreater(result['penalty_updates'],0)
        self.assertEqual(result['lambda'],4/24)
        audit.check_cycle(c,result['best_cycle'],4)

if __name__=='__main__': unittest.main(verbosity=2)
