# Independent TSP fixed-GLS component experiment

Read `REPORT.md` first. All 108 pre-frozen formal slots completed. No model calls, no external solver, no old holdout, no parameter or seed reroll.

## Files

- `data/config.json`, `data/instances.json`: frozen design, seeds and full coordinates
- `experiment.py`: stdlib solver, exact Held–Karp reference, one-worker supervisor
- `audit.py`: independent TSP checker, independent DP, penalty-log replay, budget checks
- `test_experiment.py`: brute-force/delta/checker/budget unit tests
- `verify_budget_paths.py`: post-run safety probes, not formal experiment observations
- `analyze.py`: deterministic CSV/summary/SVG generation using only stdlib
- `render_figure.py`: optional PNG rendering with preinstalled matplotlib; not imported by solver
- `results/runs.jsonl`: complete ordered formal ledger, including paths, counts, timing and penalty logs
- `results/*_<arm>.json`: individual worker output prior to supervisor metadata enrichment
- `results/held_karp.json`: optimal reference routes and exhaustive-DP accounting for six n12 instances
- `results/checker_revalidation.jsonl`, `results/audit.json`: independent validation and cost accounting
- `results/per_run.csv`, `paired.csv`, `per_instance.csv`, `strata.csv`, `resources.csv`: analysis tables
- `figures/tsp_gls_results.svg`, `.png`: scientific result figure
- `source_reference/`: byte-for-byte copied provenance sources, never imported by solvers
- `SOURCE_MANIFEST.json`, `PRE_RUN_SHA256SUMS.json`, `SHA256SUMS.txt`: source, pre-run and final integrity manifests

## Recheck existing results without rerunning formal slots

Python 3.12 stdlib suffices for all numerical work. From this directory:

```sh
python3 -m venv --without-pip .venv
.venv/bin/python -m unittest -v test_experiment.py
.venv/bin/python audit.py
.venv/bin/python analyze.py
.venv/bin/python verify_budget_paths.py
```

Optional PNG rendering uses the host's already-installed matplotlib:

```sh
MPLCONFIGDIR="$PWD/.render-cache" XDG_CACHE_HOME="$PWD/.render-cache" python3 render_figure.py
```

These checks may rewrite their corresponding derived audit/summary files, so verify the delivered hashes before rerunning if byte-level integrity is needed.

## Rerun the frozen formal design in a NEW directory

Do not remove, overwrite or reuse the delivered raw results. Copy `experiment.py`, `audit.py`, `test_experiment.py`, `SOURCE_MANIFEST.json`, `PRE_RUN_SHA256SUMS.json`, all `data/` files and all `source_reference/` files into a new clean directory. Preserve relative paths. Create an empty `results/` directory and isolated stdlib venv, then:

```sh
.venv/bin/python experiment.py run
.venv/bin/python audit.py
```

`run` first verifies frozen code/data/source hashes and refuses to overwrite an existing formal ledger. Do not call `prepare` when replaying: it intentionally refuses to replace frozen data. The delivered design has no time-triggered runs, but timing and real cutoff behavior may differ on slower hardware. Failed/censored rows are retained; no automatic retries occur.

## Interpretation

Single-start 2-opt ends at its first local optimum and is not an equal-compute comparator. Main arms share 100,000 true delta-evaluation caps, 3-second solver CPU caps and 8-second process wall caps; equal delta counts do not imply equal CPU. DP is isolated from workers and cannot cause optimum-based early stopping. n50 has no optimality-gap claim. All statistics concern fresh synthetic development instances, not TSPLIB or EoH's full pipeline.
