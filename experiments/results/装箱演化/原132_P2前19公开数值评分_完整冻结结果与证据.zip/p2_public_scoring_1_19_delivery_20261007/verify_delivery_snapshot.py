#!/usr/bin/env python3
"""Offline read-only SHA and exact-fitness audit. Never import candidate code."""
from pathlib import Path
from fractions import Fraction
import hashlib,json
R=Path(__file__).resolve().parent
manifest=json.loads((R/'FILE_MANIFEST.json').read_text())
for rel,ref in manifest['files'].items():
 raw=(R/rel).read_bytes();assert len(raw)==ref['bytes'] and hashlib.sha256(raw).hexdigest()==ref['sha256'],rel
rows=[]
for p in (R/'project/public_execution/results').glob('*.json'):
 row=json.loads(p.read_text());rows.append(row)
 if row['fitness']:
  assert len(row['scores'])==5 and all(s['outcome']=='ok' and s['evidence']['checker_status']=='passed' for s in row['scores'])
  f=sum((Fraction(s['L1'],s['used_bins']) for s in row['scores']),Fraction())/5
  assert row['fitness']['numerator']==f.numerator and row['fitness']['denominator']==f.denominator
 else:assert row['evaluation_status']!='scored'
assert sorted(x['record']['position'] for x in rows)==list(range(1,20))
summary=json.loads((R/'SUMMARY.json').read_text());assert sum(summary['counts'].values())==19
for arm,stats in summary['arms'].items():
 xs=[x for x in rows if x['record']['arm']==arm];assert len(xs)==stats['generation_slots_in_prefix'];assert sum(x['evaluation_status']=='scored' for x in xs)==stats['fitness_complete']
print(json.dumps({'status':'PASS_readonly_snapshot_integrity_and_exact_fitness','files_verified':len(manifest['files']),'rows':len(rows),'candidate_executions':0,'heldout_reads':0}))
