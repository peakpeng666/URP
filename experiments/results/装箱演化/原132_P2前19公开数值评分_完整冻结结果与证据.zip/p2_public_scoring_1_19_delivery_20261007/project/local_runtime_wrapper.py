"""DRAFT local-R1 runtime metadata adaptation. No candidate execution here.

Does not reconstruct historical pre_run_freeze, preparation timings, approvals,
external session commits, or signatures. Frozen numeric/security code is unchanged.
"""
import copy,hashlib,json,os
from pathlib import Path

def sha(raw):return hashlib.sha256(raw).hexdigest()
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
def host_security():
    wanted={'Threads','NoNewPrivs','Seccomp','Seccomp_filters'}
    result={}
    for line in Path('/proc/self/status').read_text().splitlines():
        if ':' in line:
            k,v=line.split(':',1)
            if k in wanted:result[k]=int(v.strip())
    if 'Seccomp_filters' not in result:raise RuntimeError('host security metadata unavailable')
    return result

def derive_local_receipt_trust(runtime_hash,policy,policy_hash,manifest_hash,api_names,limits,parent_security,source_evidence_sha):
    """Current expectations from pinned code, not historical worker observations."""
    if len(api_names)!=46 or len(set(api_names))!=46:raise ValueError('frozen API count')
    if type(parent_security.get('Seccomp_filters')) is not int or parent_security['Seccomp_filters']<0:raise ValueError('host filter count')
    return {'schema':'r1-local-receipt-trust-v1','historical_receipt_trust_recovered':False,
        'external_operation_or_approval_proven':False,'runtime_freeze_sha256':runtime_hash,
        'policy':policy,'policy_sha256':policy_hash,'manifest_sha256':manifest_hash,
        'api_names':sorted(api_names),'expected_limits':limits,
        # Identical derivation to frozen runner.Session.__init__: parent + 1.
        'expected_security':{'Threads':1,'NoNewPrivs':1,'Seccomp':2,'Seccomp_filters':parent_security['Seccomp_filters']+1},
        'parent_security_observed':parent_security,'source_evidence_sha256':source_evidence_sha,
        'verification_scope':'Expected values only; every real frozen worker still has to pass its unchanged pre-source host gate and receipt verifier.'}

def derive_local_run_manifest(stage_sha,frozen_inputs_sha,runtime_hash,design_hash,profile_hash,source_evidence_sha,trust_file_sha,frozen_dependencies):
    """New sidecar preserves the exact dependency map consumed by the host gate."""
    if not isinstance(frozen_dependencies,dict) or not frozen_dependencies:raise ValueError("fixed dependency map required")
    if not all(isinstance(k,str) and isinstance(v,str) and len(v)==64 for k,v in frozen_dependencies.items()):raise ValueError("fixed dependency map format")
    return {'schema':'r1-local-scoring-run-manifest-v1','historical_pre_run_freeze_recovered':False,
        'dependencies':copy.deepcopy(frozen_dependencies),
        'historical_prep_cpu_seconds':None,'historical_prep_wall_seconds':None,
        'old_grants_accepted_or_restarted':False,'external_commits_claimed':False,
        'stage_sha256':stage_sha,'frozen_inputs_sha256':frozen_inputs_sha,
        'worker_freeze_sha256':runtime_hash,'design_file_sha256':design_hash,
        'resource_profile_sha256':profile_hash,'source_evidence_sha256':source_evidence_sha,
        'local_receipt_trust_file_sha256':trust_file_sha,'heldout':False,
        'meaning':'New local execution metadata, not the historical runtime preparation report. Authoritative scientific/safety pins remain worker_freeze.json and the exact source/contract/panel hashes.'}
