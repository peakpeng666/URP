#!/usr/bin/env python3
"""R1 public-capture to frozen original132 scoring adapter.

Default: metadata-only stage. No candidate extraction, AST admission or numeric
execution. Real scoring requires a later parent authorization AND both guards.
Never invokes generation, INIT, old grants, old accounting or heldout paths.
"""
import argparse, copy, fcntl, hashlib, importlib.util, json, os, sys, time
from fractions import Fraction
from pathlib import Path
sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
FROZEN_SHA = '52f1505c9bab0ef6a821be8a28564b8ee601a66d20bbe17e918226bb5719865f'
RUNNER_SHA = 'e642b00b208330612cc5b13d842508312420c228ff31962ac80b0b60eec73f73'
RUN = 'urp132_20261005_b01_phase2'
WAVE = RUN + '-phase2'
RUNTIME_HASH = '7903fec4a38568000f7dc8901e49cfff6f246529129aacab2c94c179b1d1aeb8'
DESIGN_HASH = '5358c41aa758e1d399d29157f8cbdc5fb422f4c8acd56b2cb95c41af3f1750ca'
STATE = HERE / 'execution_state'  # Single immutable execution identity; no reroll directory.

def need(ok, reason):
    if not ok: raise ValueError(reason)
def canonical(v): return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
def sha(b): return hashlib.sha256(b).hexdigest()
def digest(v): return sha(canonical(v).encode())
def seal(v): return dict(v,sha256=digest(v))
def verify(v):
    need(v.get('sha256') == digest({k:x for k,x in v.items() if k!='sha256'}),'seal mismatch')
    return v
def read_bytes(p,expected=None,cap=16*1024*1024):
    p=Path(p);need(p.is_file() and not p.is_symlink() and p.stat().st_size<=cap,'file bounds: '+str(p))
    raw=p.read_bytes();need(expected is None or sha(raw)==expected,'hash mismatch: '+str(p));return raw
def read(p,expected=None):return json.loads(read_bytes(p,expected))
def write_once(p,v):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb') as f:f.write((canonical(v)+'\n').encode());f.flush();os.fsync(f.fileno())
    fd=os.open(p.parent,os.O_RDONLY|os.O_DIRECTORY)
    try:os.fsync(fd)
    finally:os.close(fd)
def verify_sources():
    evidence=read(HERE/'SOURCE_EVIDENCE.json')
    for e in evidence['files']:read_bytes(HERE/e['recovered_path'],e['sha256'])
    return evidence

def claim_for(record):
    claim=seal({'schema':'wave-external-claim-v1',**{k:record[k] for k in ('run_id','slot_id','phase','claim_id','request_sha256','freeze_sha256')}})
    need(claim['sha256']==record['claim_sha256'],'original claim identity')
    return claim

def capture_disposition(result,answer):
    """Transport/emptiness only. Does not parse any candidate source."""
    need(type(result.get('answer_bytes')) is int and result['answer_bytes']==len(answer),'answer length')
    need(result.get('answer_sha256')==sha(answer),'answer hash')
    if result.get('client_state')!='exited':return 'generation_failure',result.get('client_state','unknown')
    if result.get('exit_code')!=0:return 'generation_failure','nonzero_exit'
    if result.get('capture_issues'):return 'generation_failure','capture_issues'
    finishes=result.get('finish_reasons')
    if not isinstance(finishes,list) or not finishes or any(x not in ('stop','length') for x in finishes):
        return 'generation_failure','missing_or_unsupported_finish'
    if not answer:return 'generation_failure','empty_answer_'+finishes[-1]
    return 'awaiting_format_and_admission',None

def stage(frozen_path,snapshot_roots):
    data=read(frozen_path,FROZEN_SHA);verify(data['freeze']);verify(data['roster'])
    slots=data['slots'];need(len(slots)==60 and len(data['roster']['records'])==60,'sixty slots')
    need([x['record'] for x in slots]==data['roster']['records'],'roster order')
    need([x['record']['position'] for x in slots]==list(range(1,61)),'P2 order')
    need([x['record']['order'] for x in slots]==list(range(73,133)),'original order')
    need(all(sum(x['record']['arm']==a for x in slots)==30 for a in ('EOH_TC','IID_TC')),'arm balance')
    roots=[Path(r).resolve() for r in snapshot_roots]
    for root in roots:
        read_bytes(root/'executor/frozen_inputs.json',FROZEN_SHA)
        read_bytes(root/'executor/runner.py',RUNNER_SHA)
    rows=[]
    for slot in slots:
        r,p=slot['record'],slot['pack'];verify(p);claim=claim_for(r)
        need(r['run_id']==RUN and r['phase']==2 and p['sha256']==r['request_sha256'],'slot freeze')
        row={'record':copy.deepcopy(r),'claim':claim,'status':'not_collected','reason':None,
             'candidate':None,'admission':None,'scores':[],'fitness':None,'sources':[]}
        identity=None
        for root in roots:
            folder=root/'ledger'/r['slot_id']
            if not folder.exists():continue
            need(not folder.is_symlink(),'ledger symlink')
            if not all((folder/n).is_file() for n in ('result.json','dispatch.json','answer.txt','prompt.txt')):
                row.update(status='unknown_capture',reason='incomplete_local_capture');continue
            paths={n:folder/n for n in ('result.json','dispatch.json','answer.txt','prompt.txt')}
            raws={n:read_bytes(path,cap=2*1024*1024) for n,path in paths.items()}
            result,dispatch=json.loads(raws['result.json']),json.loads(raws['dispatch.json'])
            for key in ('position','slot_id'):
                need(result[key]==r[key] and dispatch[key]==r[key],'slot identity '+key)
            need(result.get('revision')==data['revision'] and dispatch.get('revision')==data['revision'],'revision')
            need(result.get('fixture_only') is False and dispatch.get('fixture_only') is False,'fixture cannot enter production')
            for key in ('order','arm','prompt_sha256'):need(dispatch[key]==r[key],'dispatch '+key)
            need(dispatch['frozen_inputs_sha256']==FROZEN_SHA and dispatch['configuration']==p['configuration'],'dispatch freeze/config')
            need(dispatch['config_sha256']==r['config_file_sha256'],'config hash')
            need(sha(raws['prompt.txt'])==r['prompt_sha256']==sha(p['prompt'].encode()),'exact prompt bytes')
            hashes={n:sha(b) for n,b in raws.items()}
            need(identity is None or identity==hashes,'conflicting duplicate snapshot')
            identity=hashes
            status,reason=capture_disposition(result,raws['answer.txt'])
            need(row['status']!='unknown_capture','uncertain duplicate capture')
            row.update(status=status,reason=reason,local_generation_result=result)
            row['sources'].append({'snapshot_root':str(root),'files':{n:{'path':str(path),'sha256':hashes[n]} for n,path in paths.items()}})
        rows.append(row)
    counts={s:sum(r['status']==s for r in rows) for s in sorted({r['status'] for r in rows})}
    return seal({'schema':'r1-public-scoring-stage-v1','frozen_path':str(Path(frozen_path).resolve()),'frozen_inputs_sha256':FROZEN_SHA,
        'run_id':RUN,'scientific_run_id':'urp132_20261005_b01','snapshot_roots':[str(r) for r in roots],
        'generation_denominator':60,'counts':counts,'rows':rows,'source_admissions':0,'numeric_packs':0,
        'format_extractions':0,'heldout_access':False,'real_execution_enabled':False,
        'provenance':'R1 local public capture; not an authenticated external committed session store; provider outcome remains unknown'})

def parse_public_capture(raw,result,extractor):
    """Format only, called on actual answers only after explicit real activation.

    A bounded but overlong public answer is a consumed slot format failure.
    Identity/hash drift is verified outside this helper and remains a hard error.
    """
    try:
        capture={'raw':raw.decode('utf-8'),'status':'ok','capture_complete':True,'finish_reason':result['finish_reasons'][-1],'tool_calls':[]}
        candidate,raw_sha,metrics=extractor(capture)
        return {'candidate':candidate,'capture':capture,'format_metrics':metrics,'status':'awaiting_admission','reason':None}
    except (ValueError,KeyError,TypeError,UnicodeError) as exc:
        return {'candidate':None,'format_metrics':{'unique':False,'strict':False},'status':'generation_format_failure','reason':str(exc)}

def modules():
    for name in ('registry','policy','resource_profile','deployment','dependencies','runner','backend','bridge','profiles'):
        need(name not in sys.modules,'fresh interpreter required: '+name)
    sys.path[:0]=[str(HERE/'frozen_receiver'),str(HERE/'frozen_runtime')]
    import registry, deployment, backend, dependencies, bridge, policy, manifest
    return locals()

def public_panel():
    d=read(HERE/'frozen_public/design_5000.json',DESIGN_HASH)
    need(d['set']=='historical_design_5k' and d['capacity']==100,'public panel')
    need([x['id'] for x in d['cases']]==list(range(5)),'five ordered cases')
    panel=[];instances=[]
    for i,c in enumerate(d['cases']):
        items=c['items'];need(len(items)==5000 and all(type(x) is int and 1<=x<=100 for x in items),'public domain')
        v={'items':items,'capacity':100};instances.append(v)
        panel.append({'instance_index':i,'input_sha256':digest(v),'n':5000,'capacity':100,'L1':(sum(items)+99)//100})
    need([x['L1'] for x in panel]==[2012,1983,1978,1986,1980],'public lower bounds')
    expected=read(HERE/'frozen_metadata/SOURCE_INPUT_PLAN.json')['design_panel']
    need(expected=={'kind':'registered_source_study','instances':panel},'exact frozen source panel')
    return expected,instances

class Reservations:
    """Exact original phase2_numerical.py role budgets; no reset on restart."""
    def __init__(self,root,claim_ids):self.root=Path(root);self.claim_ids=set(claim_ids)
    def reserve(self,role,cpu_seconds,execution_id):
        parts=execution_id.split('/');need(parts[0] in self.claim_ids,'reservation identity')
        if role=='admission':need(parts[1:]==['admission'] and cpu_seconds==1,'admission reservation');wall=5;cap=60
        else:
            need(role in ('instance','supervisor') and len(parts)==3 and parts[1]=='instance' and parts[2] in ('0','1','2','3','4') and cpu_seconds==60,'instance reservation')
            wall=90 if role=='instance' else 0;cap=300
        rows=[read(p) for p in self.root.glob('*.json')]
        need(not any(x['role']==role and x['execution_id']==execution_id for x in rows),'reservation consumed; no retry')
        need(sum(x['role']==role for x in rows)<cap,'P2 role cap')
        if role=='supervisor':need(any(x['role']=='instance' and x['execution_id']==execution_id for x in rows),'instance reservation first')
        need(sum(x['cpu_seconds'] for x in rows)+cpu_seconds<=36060,'original P2 CPU cap')
        need(sum(x['shared_wall_seconds'] for x in rows)+wall<=27300,'original P2 wall cap')
        write_once(self.root/(digest([role,execution_id])+'.json'),{'role':role,'execution_id':execution_id,'cpu_seconds':cpu_seconds,'shared_wall_seconds':wall})
    def worker(self,*,cpu_seconds,worker_role,execution_id):self.reserve(worker_role,cpu_seconds,execution_id)
    def supervisor(self,*,cpu_seconds,execution_id):self.reserve('supervisor',cpu_seconds,execution_id)

def exact_fitness(scores,panel):
    """Incomplete, failed, or unchecked panels stay unranked, never zero-imputed."""
    if len(scores)!=len(panel):return None
    for i,(s,p) in enumerate(zip(scores,panel)):
        if s.get('outcome')!='ok' or s.get('instance_index')!=i or s.get('L1')!=p['L1']:return None
        if type(s.get('used_bins')) is not int or not p['L1']<=s['used_bins']<=p['n']:return None
        if s.get('evidence',{}).get('checker_status')!='passed':return None
    f=sum((Fraction(s['L1'],s['used_bins']) for s in scores),Fraction(0))/len(scores)
    return {'numerator':f.numerator,'denominator':f.denominator,'direction':'maximize'}

def account(bundles, reservations):
    result={'admissions':0,'instance_packs':0,'admission_cpu_seconds':0.,'child_cpu_seconds':0.,
            'supervisor_self_cpu_seconds':0.,'supervisor_inclusive_wait4_cpu_seconds':0.,
            'score_call_cpu_ns':0,'shared_instance_wall_seconds':0.}
    for b in bundles:
        result['admissions']+=1
        result['admission_cpu_seconds']+=b['admission']['worker']['cpu_seconds']
        for row in b['scores']:
            worker=row['evidence']['worker']; supervisor=row['evidence']['supervisor']
            result['instance_packs']+=1
            result['child_cpu_seconds']+=worker['cpu_seconds']
            result['supervisor_self_cpu_seconds']+=supervisor['actual_supervisor_cpu_seconds']
            result['supervisor_inclusive_wait4_cpu_seconds']+=supervisor['wait4_cpu_seconds']
            result['score_call_cpu_ns']+=worker['score_call_cpu_ns']
            result['shared_instance_wall_seconds']+=supervisor['wall_seconds']
    result['numerical_cpu_seconds_no_double_count']=result['admission_cpu_seconds']+result['child_cpu_seconds']+result['supervisor_self_cpu_seconds']
    result['score_timing_scope']='function call including facade; excludes prep/check/serialization; already inside child CPU'
    result['inclusive_wait4_not_added_again']=True
    result['reserved_cpu_seconds']=sum(x['cpu_seconds'] for x in reservations)
    result['reserved_shared_wall_seconds']=sum(x['shared_wall_seconds'] for x in reservations)
    return result


def real_score(stage_path,stage_sha,enabled=False):
    """Retired in append revision: there must be one real claim/budget root."""
    raise RuntimeError('RETIRED_BATCH_ENTRYPOINT_USE_INCREMENTAL_APPEND')


def main():
    ap=argparse.ArgumentParser();sub=ap.add_subparsers(dest='cmd',required=True)
    p=sub.add_parser('stage');p.add_argument('--frozen',required=True);p.add_argument('--snapshot',action='append',required=True);p.add_argument('--output',required=True)
    p=sub.add_parser('score');p.add_argument('--stage',required=True);p.add_argument('--stage-sha256',required=True);p.add_argument('--enable-real',action='store_true')
    sub.add_parser('verify-sources')
    a=ap.parse_args()
    if a.cmd=='stage':
        verify_sources();out=Path(a.output).resolve()
        need(not any(out.is_relative_to(Path(r).resolve()) for r in a.snapshot),'output must not be inside any input snapshot')
        v=stage(a.frozen,a.snapshot);write_once(out,v);print(canonical({'counts':v['counts'],'stage_sha256':v['sha256'],'file_sha256':sha(out.read_bytes()),'source_admissions':0,'numeric_packs':0}))
    elif a.cmd=='score':print(canonical(real_score(a.stage,a.stage_sha256,a.enable_real)))
    else:print(canonical({'source_files_verified':len(verify_sources()['files']),'real_execution_enabled':False}))
if __name__=='__main__':main()
