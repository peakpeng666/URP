# 原132 P2按槽追加评分修订，真实开关关闭

## 状态

本修订独立于上一准备包；上一包文件不改。原48份固定源码/公开数据不改。真实模型候选格式抽取、AST准入、执行、数值pack均0；本目录public_execution尚不存在，EXECUTION_SWITCH.json的enabled=false。

已完成：

- 按槽追加控制层incremental.py；只处理已收终态连续前缀，严格保留原position1–60/order73–132、两臂30/30、父票、prompt、配置与claim身份
- 已收到1–13的只读stage映射：11非空待格式/准入、1 length空、1 timeout空；真实candidate字段全部null。输入stage文件SHA f53a3fa5e175419ed4cb7b7b8bbfccf1ae73194388dc1b557f42d64db2c28f8c
- 原冻结动态sandbox smoke通过：独立fake_only_dynamic目录，原创score和8个自造item，1个fake admission、1个fake pack。checker为4箱，源前gate、profile、依赖和cleanup均通过；不是P2 admission/pack，不是原benchmark分数
- controller纯假fixture测试15项；动态smoke与控制测试成本见PREPARATION_COST_LEDGER.jsonl。独立复核见审阅记录

## 动态smoke说明

fake_dynamic_smoke.py直接调用原Session和supervised_pack，未改任何冻结worker、安全门、facade、checker或资源profile；不把原创fixture塞进真实P2 registry，也不伪称模型输出。实际profile为production-60cpu-90wall-v1，其固定worker60CPU/512MiB/NOFILE3及supervisor60CPU/512MiB/NOFILE32均按原profile观察。admission仍原1CPU/5wall。

观察Threads1、NoNewPrivs1、Seccomp2、Seccomp_filters2，admission与instance均source_after_host_gate=true。numeric child、supervisor均reaped、无cleanup_error。CPU计账区分numeric child、supervisor self和inclusive wait4，不重复相加。

含启动器dynamic smoke约0.780 CPU秒、0.784 wall秒；准确完整证据在fake_only_dynamic/RESULT.json、admission_worker.json、pack_receipt.json。父环境Python/NumPy/995依赖精确匹配复用上次只读证明，动态原worker/supervisor又按固有门自行检查；没有额外全库扫描。

这证明当前dot能使用原隔离执行路径跑这个小fixture，不证明任意模型候选通过、不证明5×5000在预算内完成。fake目录已有attempt，不能删掉或重跑掩盖失败。若以后需要不同工程smoke须另明确命名。

## 追加与永久状态

- 本修订唯一真实执行入口为incremental.py append；保留的adapter.py仅供元数据/共享辅助函数，旧score入口已无条件退役，不能另建整批执行池
- 所有真实P2追加轮共用固定public_execution目录、全局锁、scope和Reservations账本。每批不会新开资源池
- 每slot先永久claims/<slot>.json，后不可覆盖results/<slot>.json。slot身份和原始capture各文件hash固定；后来的同字节快照路径可不同，内容/父票不能漂移
- 数值pack使用原ExecutionJournal的独立*.claim.json和*.result.json；token基于原RUN、slot、execution_id，不随导入批次变化
- 任何已有slot/pack claim无终态回执，都全局停；不判断“也许没跑”而重试。基础设施异常写HALT，之后停止派发
- 完成的slot只读复核旧回执与fitness，不重新调用backend。空输出/timeout/格式失败留生成失败，scores=[]、fitness=null，不冒充评分成功，也不补模型生成
- 新批只处理未消费的已收到连续前缀；遇未收/未知capture，暂停等后续完整快照。不跳过较早position去跑晚到槽
- 单槽numeric failure后由原backend停止该候选后续case；失败不改变后续候选的题目或父代
- 固定5×5000、capacity100、精确mean(L1/used_bins)、原60 admissions/300 packs、36060CPU/27300共享wall上限不变。旧P0/P1余额仍unknown，不能将新记录解释为重置余额
- 没有生成器写入、旧claim/HALT/cost写入、winner更新、父代替换、heldout入口或外部服务调用。评估结果不得反馈未发出的本代生成请求

## 具体启动命令：仅供父审后明确授权，不在本任务执行

当前只读检查：

    cd /workspace/shared/p2_scoring_adapter_append_revision_20261007
    python -B incremental.py inspect

若父在下一条明确批准本修订真实public评分，先由获准执行者将EXECUTION_SWITCH.json的enabled改为true（保留heldout=false），再执行：

    python -B incremental.py append --stage imports_prepared/slots_1_13.json --stage-sha256 f53a3fa5e175419ed4cb7b7b8bbfccf1ae73194388dc1b557f42d64db2c28f8c --enable-real

两个条件缺一即拒绝；布尔开关本身不是授权。命令处理1–13：2个已知空终态作为生成失败，11个非空答案才进入冻结格式/AST/数值链，符合准入的每槽最多5个public case。不能预先声称11个会通过。完成后停在position14，并显示哪些只读复用/哪些新增终态。

为了便于审后按确定步骤激活，可使用以下仅修改本修订自有开关的命令；必须等明确批准：

    python -B -c "import json,pathlib; p=pathlib.Path('EXECUTION_SWITCH.json'); d=json.loads(p.read_text()); assert d.get('heldout') is False; d['enabled']=True; p.write_text(json.dumps(d,indent=2)+'\\n')"

准备阶段没有调用这条激活命令。

## 后续批次只读导入

新批必须是父核验通过的只读R1快照根目录，带同一executor/frozen_inputs.json与runner.py。每次stage命令列出已有全部快照再加新快照，以保留连续前缀；快照重叠仅容许逐字节相同capture。输出必须新建在本目录imports_prepared下，不覆盖旧stage：

    python -B incremental.py stage --frozen /workspace/shared/first_slot_r1_review/executor/frozen_inputs.json --snapshot /workspace/shared/first_slot_r1_review --snapshot /workspace/shared/p2_minimal_batch1_review/data --snapshot /workspace/shared/p2_minimal_batch2_review/data --snapshot /新的已核验快照根目录 --output imports_prepared/下一批.json

stage仅校验字节和元数据，不抽取真实候选源码、不准入、不评分，采集可继续。工具输出新的file_sha256。仍在已明确授权范围内时，使用新stage路径及该file_sha256再调用append；既有终态只读复用，新到槽使用同一账本。不要删除public_execution、HALT、claim或pack日志来“恢复”。

## 已知限制与范围记录

新pre_run/trust仍是诚实标记的新local-R1运行元数据；pre_run携带原995项dependencies供原源前mapped gate使用，不伪造历史回执、签名或旧批准。输入来源保持R1本地capture，provider outcome未知。

上一轮定位public定义时读取原protocol_draft.json曾偶然带出同文件heldout元数据；此偏差保留记录。本修订没有追加读取或复制任何该部分值，没有读取heldout实例。

已有30CPU秒准备预算下，实质动态/测试任务逐次计量，明显低于预算。工具调度和先前少量shell元数据检查不伪称为全系统硬CPU审计。原数值资源预约与本次准备实测开销分开报告。
