#!/usr/bin/env python3
"""Append-only original132 P2 public scoring. Default operation is read-only.

No generator client, old grant/INIT entrypoint, winner selection or heldout access.
Real source extraction/admission/score requires the still-disabled explicit guards.
"""
import argparse,copy,fcntl,json,os,sys,time
from pathlib import Path
import adapter as b
from local_runtime_wrapper import derive_local_receipt_trust,derive_local_run_manifest,host_security
HERE=Path(__file__).resolve().parent
STATE=HERE/'public_execution'

def input_identity(row):
    hashes=row['sources'][0]['files'] if row.get('sources') else {}
    return b.digest({'frozen_inputs_sha256':b.FROZEN_SHA,'record':row['record'],'claim':row['claim'],
        'file_hashes':{k:v['sha256'] for k,v in hashes.items()}})

class OnceOnly:
    """A permanent claim lacking its terminal result blocks every later dispatch."""
    def __init__(self,root,scope):
        self.root=Path(root);self.root.mkdir(parents=True,exist_ok=True)
        self.lock=(self.root/'lock').open('a+b');fcntl.flock(self.lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        p=self.root/'scope.json'
        if p.exists():b.need(b.read(p)==scope,'independent state scope drift')
        else:b.write_once(p,scope)
        for name in ['claims','results','slots','reservations','runtime_journal']:(self.root/name).mkdir(exist_ok=True)
        try:self.assert_no_unknown()
        except BaseException:self.lock.close();raise
    def close(self):self.lock.close()
    def assert_no_unknown(self):
        b.need(not (self.root/'HALT.json').exists(),'existing infrastructure HALT; no new dispatch')
        for p in (self.root/'claims').glob('*.json'):
            b.need((self.root/'results'/p.name).is_file(),'UNKNOWN slot claim without terminal; no retry: '+p.stem)
        for p in (self.root/'runtime_journal').glob('*.claim.json'):
            b.need(p.with_name(p.name.replace('.claim.json','.result.json')).is_file(),'UNKNOWN runtime claim; no retry')
    def completed(self,sid,identity):
        p=self.root/'results'/(sid+'.json')
        if not p.exists():return None
        c=b.read(self.root/'claims'/(sid+'.json'));v=b.verify(b.read(p))
        b.need(c['input_identity']==identity==v['input_identity'],'completed identity changed')
        return v
    def claim(self,sid,identity):
        self.assert_no_unknown()
        b.write_once(self.root/'claims'/(sid+'.json'),{'slot_id':sid,'input_identity':identity,'retries':0})
    def finish(self,sid,value):
        c=b.read(self.root/'claims'/(sid+'.json'));b.need(value['input_identity']==c['input_identity'],'terminal binding')
        b.write_once(self.root/'results'/(sid+'.json'),b.seal(value))
    def halt(self,sid,exc):
        if not (self.root/'HALT.json').exists():b.write_once(self.root/'HALT.json',{'slot_id':sid,'status':'halted_no_retry','exception':type(exc).__name__+': '+str(exc)})

def format_row(row,extractor):
    out={'slot_id':row['record']['slot_id'],'record':copy.deepcopy(row['record']),'claim':row['claim'],
         'input_identity':input_identity(row),'generation_status':row['status'],'reason':row['reason'],
         'candidate':None,'admission':None,'scores':[],'fitness':None,
         'provenance':'local-R1 public capture; provider outcome remains unknown; no external committed store claimed'}
    if row['status']=='awaiting_format_and_admission':
        ref=row['sources'][0]['files']['answer.txt'];raw=b.read_bytes(ref['path'],ref['sha256'],cap=2*1024*1024)
        parsed=b.parse_public_capture(raw,row['local_generation_result'],extractor)
        out.update(parsed);out['generation_status']=parsed['status']
    return out

def local_metadata(m,stage,freeze):
    trust=derive_local_receipt_trust(b.RUNTIME_HASH,m['policy'].POLICY,freeze['policy_sha256'],m['manifest'].manifest_sha256(),list(m['manifest'].API_SPECS),m['bridge'].LIMITS,host_security(),b.sha(b.read_bytes(HERE/'SOURCE_EVIDENCE.json')))
    wf,rh=m['dependencies'].load_worker_freeze();b.need(rh==b.RUNTIME_HASH,'runtime identity')
    # Required preflight, precise frozen list only. No new dependency inventory.
    m['dependencies'].verify_files(wf['dependencies'])
    trust_path=STATE/'local_receipt_trust.json'
    if trust_path.exists():b.need(b.read(trust_path)==trust,'host trust scope changed')
    else:b.write_once(trust_path,trust)
    manifest=derive_local_run_manifest('append-only-P2-scope',b.FROZEN_SHA,b.RUNTIME_HASH,b.DESIGN_HASH,freeze['resource_profile_sha256'],b.sha(b.read_bytes(HERE/'SOURCE_EVIDENCE.json')),b.sha(b.read_bytes(trust_path)),wf['dependencies'])
    path=HERE/'frozen_runtime/pre_run_freeze.json'
    if path.exists():b.need(b.read(path)==manifest,'local suite manifest drift')
    else:b.write_once(path,manifest)
    return trust

def make_bridge(m,reg,dep,trust):
    return m['bridge'].ReceiptBridge(reg,registry_sha256=reg['sha256'],run_id=b.RUN,phase=2,wave_id=b.WAVE,policy=trust['policy'],policy_sha256=trust['policy_sha256'],runtime_freeze_sha256=b.RUNTIME_HASH,manifest_sha256=trust['manifest_sha256'],api_names=trust['api_names'],expected_security=trust['expected_security'],expected_limits=trust['expected_limits'],handwritten_source_hashes=[],deployment_document=dep,deployment_sha256=dep['sha256'])

def score_slot(store,row,m,panel,instances,freeze,trust):
    sid=row['record']['slot_id'];identity=input_identity(row)
    completed=store.completed(sid,identity)
    if completed is not None:
        if completed.get('bundle_sha256'):
            home=store.root/'slots'/sid;reg=b.verify(b.read(home/'registry.json'));dep=b.verify(b.read(home/'deployment.json'))
            bundle=b.verify(b.read(home/'bundle.json'));b.need(bundle['sha256']==completed['bundle_sha256'],'completed bundle drift')
            capture=b.read(home/'capture.json');bridge=make_bridge(m,reg,dep,trust)
            verified=bridge.verify_receipt(bundle,capture,row['claim'],panel,freeze)
            b.need(verified['scores']==completed['scores'] and verified['admission']==completed['admission'],'completed receipt mismatch')
            b.need(b.exact_fitness(verified['scores'],panel['instances'])==completed['fitness'],'completed fitness mismatch')
        return completed,False
    store.claim(sid,identity)  # Permanent before format extraction and worker launches.
    home=store.root/'slots'/sid;home.mkdir(exist_ok=False)
    out=format_row(row,m['bridge'].extract)
    if out['candidate'] is None:
        out['evaluation_status']='generation_failure';store.finish(sid,out);return out,True
    candidate=out.pop('candidate');capture=out.pop('capture')
    b.write_once(home/'capture.json',capture)
    reg=m['registry'].freeze_wave(home/'registry.json',batch_id=b.RUN,wave_id=b.WAVE,phase=2,runtime_freeze_sha256=b.RUNTIME_HASH,slots=[(candidate,row['claim'],capture['raw'].encode())],source_origin='model_response',resource_profile_sha256=freeze['resource_profile_sha256'])
    dep=b.seal({'schema':'candidate-deployment-freeze-v2','mode':'registered_source_study','source_origin':'model_response','registry_sha256':reg['sha256'],'wave_freeze_sha256':freeze['sha256'],'batch_id':b.RUN,'wave_id':b.WAVE,'phase':2,'runtime_freeze_sha256':b.RUNTIME_HASH,**{k:freeze[k] for k in ('resource_profile_sha256','policy_sha256','isolation_profile_sha256','checker_sha256','intake_manifest_sha256')}})
    b.write_once(home/'deployment.json',dep)
    reserves=b.Reservations(store.root/'reservations',[x['claim_id'] for x in m['all_claims']])
    backend=m['backend'].RegistryBackend(m['registry'].FrozenRegistry(home/'registry.json',reg['sha256']),m['registry'].ExecutionJournal(store.root/'runtime_journal'),raw_reader=lambda cid:capture['raw'].encode() if cid==row['claim']['claim_id'] else None,instance_provider=lambda i:copy.deepcopy(instances[i]),reserve_worker=reserves.worker,reserve_supervisor=reserves.supervisor,deployment_freeze=m['deployment'].DeploymentFreeze(home/'deployment.json',dep['sha256']))
    backend.bind_capture(row['claim'],b.sha(capture['raw'].encode()))
    bundle=backend.verify(candidate,row['claim'],panel,freeze);b.write_once(home/'bundle.json',bundle)
    verified=make_bridge(m,reg,dep,trust).verify_receipt(bundle,capture,row['claim'],panel,freeze)
    out.update(admission=verified['admission'],scores=verified['scores'],bundle_sha256=bundle['sha256'])
    out['fitness']=b.exact_fitness(out['scores'],panel['instances'])
    out['evaluation_status']='scored' if out['fitness'] is not None else ('admission_rejected' if not verified['admission']['admitted'] else 'numeric_failure')
    store.finish(sid,out);return out,True

def process_prefix(rows,operation):
    """Arrival batches never reorder frozen slots or skip a missing predecessor."""
    processed=[];fresh=0;stop=None
    for row in rows:
        if row['status'] in ('not_collected','unknown_capture'):
            stop={'position':row['record']['position'],'status':row['status']};break
        result,is_new=operation(row)
        processed.append({'slot_id':row['record']['slot_id'],'position':row['record']['position'],'evaluation_status':result['evaluation_status'],'reused_read_only':not is_new})
        fresh+=is_new
    return processed,fresh,stop

def append(stage_path,file_sha,enable_real=False):
    b.need(enable_real is True and b.read(HERE/'EXECUTION_SWITCH.json').get('enabled') is True,'REAL_EXECUTION_DISABLED; explicit later parent authorization required')
    b.verify_sources();stage=b.verify(b.read(stage_path,file_sha))
    b.need(stage==b.stage(stage['frozen_path'],stage['snapshot_roots']),'stage drift')
    data=b.read(stage['frozen_path'],b.FROZEN_SHA);freeze=data['freeze']
    scope={'schema':'r1-p2-once-only-public-scope-v1','run_id':b.RUN,'frozen_inputs_sha256':b.FROZEN_SHA,'runtime_sha256':b.RUNTIME_HASH,'design_sha256':b.DESIGN_HASH,'source_evidence_sha256':b.sha(b.read_bytes(HERE/'SOURCE_EVIDENCE.json')),'max_admissions':60,'max_packs':300,'max_cpu_reservation':36060,'max_shared_wall_reservation':27300,'heldout':False,'generation_feedback':False}
    store=OnceOnly(STATE,scope);sid=None
    try:
        m=b.modules();m['all_claims']=[r['claim'] for r in stage['rows']]
        trust=local_metadata(m,stage,freeze);panel,instances=b.public_panel()
        imported=STATE/'imports'/(stage['sha256']+'.json')
        if not imported.exists():b.write_once(imported,{'stage_path':str(Path(stage_path).resolve()),'stage_file_sha256':file_sha,'stage_sha256':stage['sha256']})
        def operation(row):
            nonlocal sid
            sid=row['record']['slot_id'];return score_slot(store,row,m,panel,instances,freeze,trust)
        processed,fresh,stop=process_prefix(stage['rows'],operation)
        report={'schema':'r1-public-append-pass-v1','stage_sha256':stage['sha256'],'new_terminals':fresh,'processed_contiguous_prefix':processed,'stop_at':stop,'generation_denominator':60,'heldout':False,'historical_shared_balance':None,'new_budget_pool':False}
        report_path=STATE/'passes'/(str(time.time_ns())+'.json');b.write_once(report_path,report);return report
    except BaseException as exc:store.halt(sid,exc);raise
    finally:store.close()

def inspect():
    if not STATE.exists():return {'status':'not_started','real_execution_enabled':b.read(HERE/'EXECUTION_SWITCH.json')['enabled'],'real_admissions':0,'real_packs':0}
    claims=list((STATE/'claims').glob('*.json'));results=list((STATE/'results').glob('*.json'))
    unknown=[p.stem for p in claims if not (STATE/'results'/p.name).exists()]
    return {'status':'halted_or_unknown' if unknown or (STATE/'HALT.json').exists() else 'paused_between_append_passes','terminal_slots':len(results),'unknown_slots':unknown,'real_execution_enabled':b.read(HERE/'EXECUTION_SWITCH.json')['enabled']}

def main():
    ap=argparse.ArgumentParser();sp=ap.add_subparsers(dest='cmd',required=True);sp.add_parser('inspect')
    p=sp.add_parser('append');p.add_argument('--stage',required=True);p.add_argument('--stage-sha256',required=True);p.add_argument('--enable-real',action='store_true')
    p=sp.add_parser('stage');p.add_argument('--frozen',required=True);p.add_argument('--snapshot',action='append',required=True);p.add_argument('--output',required=True)
    a=ap.parse_args()
    if a.cmd=='inspect':v=inspect()
    elif a.cmd=='append':v=append(a.stage,a.stage_sha256,a.enable_real)
    else:
        b.verify_sources();out=Path(a.output).resolve();b.need(out.is_relative_to(HERE/'imports_prepared'),'stage output confined to independent imports_prepared')
        b.need(not any(out.is_relative_to(Path(x).resolve()) for x in a.snapshot),'cannot write input snapshot')
        v=b.stage(a.frozen,a.snapshot);b.write_once(out,v);v={'file_sha256':b.sha(b.read_bytes(out)),'stage_sha256':v['sha256'],'counts':v['counts'],'format_extractions':0,'admissions':0,'packs':0}
    print(b.canonical(v))
if __name__=='__main__':main()
