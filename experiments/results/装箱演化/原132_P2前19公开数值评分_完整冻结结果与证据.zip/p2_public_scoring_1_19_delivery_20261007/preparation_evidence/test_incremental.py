"""Synthetic controller tests. No generated answer read or benchmark execution."""
import copy,json,pathlib,tempfile,unittest
import adapter as b
import incremental as inc
ROOT=pathlib.Path(__file__).resolve().parent
class Tests(unittest.TestCase):
 def scope(self):return {'fixture_only':True,'fixed_budget':'original-P2-ceiling-not-reset'}
 def test_once_claim_and_readonly_reuse(self):
  with tempfile.TemporaryDirectory(dir=ROOT) as t:
   st=inc.OnceOnly(t,self.scope());st.claim('fixture','id');st.finish('fixture',{'input_identity':'id','evaluation_status':'generation_failure','scores':[]})
   old=(pathlib.Path(t)/'results/fixture.json').read_bytes();self.assertEqual(st.completed('fixture','id')['scores'],[])
   with self.assertRaises(FileExistsError):st.claim('fixture','id')
   self.assertEqual(old,(pathlib.Path(t)/'results/fixture.json').read_bytes());st.close()
 def test_unknown_blocks_later_and_restart(self):
  with tempfile.TemporaryDirectory(dir=ROOT) as t:
   st=inc.OnceOnly(t,self.scope());st.claim('unknown','id')
   with self.assertRaisesRegex(ValueError,'UNKNOWN'):st.claim('later','later')
   st.close()
   with self.assertRaisesRegex(ValueError,'UNKNOWN'):inc.OnceOnly(t,self.scope())
 def test_mismatched_completed_identity_blocks(self):
  with tempfile.TemporaryDirectory(dir=ROOT) as t:
   st=inc.OnceOnly(t,self.scope());st.claim('x','id');st.finish('x',{'input_identity':'id'})
   with self.assertRaises(ValueError):st.completed('x','different')
   st.close()
 def test_unknown_pack_claim_blocks(self):
  with tempfile.TemporaryDirectory(dir=ROOT) as t:
   st=inc.OnceOnly(t,self.scope());b.write_once(pathlib.Path(t)/'runtime_journal/fixture.claim.json',{'fixture_only':True})
   with self.assertRaisesRegex(ValueError,'UNKNOWN runtime'):st.claim('next','id')
   st.close()
 def test_halt_blocks_restart(self):
  with tempfile.TemporaryDirectory(dir=ROOT) as t:
   st=inc.OnceOnly(t,self.scope());st.halt('x',RuntimeError('synthetic fault'));st.close()
   with self.assertRaisesRegex(ValueError,'HALT'):inc.OnceOnly(t,self.scope())
 def test_shared_admission_budget_across_reopens(self):
  with tempfile.TemporaryDirectory(dir=ROOT) as t:
   ids=['fake'+str(i) for i in range(61)]
   for i in range(60):b.Reservations(t,ids).worker(cpu_seconds=1,worker_role='admission',execution_id=ids[i]+'/admission')
   with self.assertRaisesRegex(ValueError,'cap'):b.Reservations(t,ids).worker(cpu_seconds=1,worker_role='admission',execution_id=ids[60]+'/admission')
   self.assertEqual(len(list(pathlib.Path(t).glob('*.json'))),60)
 def test_shared_wall_once_only_and_no_pack_retry(self):
  with tempfile.TemporaryDirectory(dir=ROOT) as t:
   r=b.Reservations(t,['fake']);r.worker(cpu_seconds=60,worker_role='instance',execution_id='fake/instance/0');r.supervisor(cpu_seconds=60,execution_id='fake/instance/0')
   rows=[b.read(p) for p in pathlib.Path(t).glob('*.json')];self.assertEqual(sum(x['cpu_seconds'] for x in rows),120);self.assertEqual(sum(x['shared_wall_seconds'] for x in rows),90)
   with self.assertRaises(ValueError):b.Reservations(t,['fake']).worker(cpu_seconds=60,worker_role='instance',execution_id='fake/instance/0')
 def test_bad_resource_value_rejected(self):
  with tempfile.TemporaryDirectory(dir=ROOT) as t:
   with self.assertRaises(ValueError):b.Reservations(t,['fake']).worker(cpu_seconds=2,worker_role='admission',execution_id='fake/admission')
 def test_prefix_append_reuses_and_never_skips(self):
  with tempfile.TemporaryDirectory(dir=ROOT) as t:
   st=inc.OnceOnly(t,self.scope());rows=[{'record':{'slot_id':'fake'+str(i),'position':i},'status':'generation_failure' if i<3 else 'not_collected'} for i in range(1,5)];calls=[]
   def fake(row):
    sid=row['record']['slot_id'];v=st.completed(sid,sid)
    if v:return v,False
    st.claim(sid,sid);v={'fixture_only':True,'input_identity':sid,'evaluation_status':'generation_failure','scores':[]};st.finish(sid,v);calls.append(sid);return v,True
   done,fresh,stop=inc.process_prefix(rows,fake);self.assertEqual((fresh,stop['position']),(2,3))
   rows[2]['status']='generation_failure';done,fresh,stop=inc.process_prefix(rows,fake)
   self.assertEqual((fresh,stop['position']),(1,4));self.assertEqual(calls,['fake1','fake2','fake3']);self.assertEqual(list((pathlib.Path(t)/'reservations').iterdir()),[]);st.close()
 def test_later_ready_cannot_skip_pending(self):
  rows=[{'record':{'position':1},'status':'not_collected'},{'record':{'position':2},'status':'generation_failure'}]
  done,fresh,stop=inc.process_prefix(rows,lambda r:(_ for _ in ()).throw(AssertionError('must not execute')))
  self.assertEqual(fresh,0);self.assertEqual(stop['position'],1)
 def test_length_and_timeout_empty_are_generation_failure(self):
  result={'answer_bytes':0,'answer_sha256':b.sha(b''),'client_state':'exited','exit_code':0,'capture_issues':[],'finish_reasons':['length']}
  self.assertEqual(b.capture_disposition(result,b''),('generation_failure','empty_answer_length'))
  result['client_state']='timeout';self.assertEqual(b.capture_disposition(result,b'')[0],'generation_failure')
 def test_no_real_guard_bypass(self):
  for flag in [False,True]:
   with self.assertRaisesRegex(ValueError,'REAL_EXECUTION_DISABLED'):inc.append('DO_NOT_READ','bad',flag)
  self.assertFalse(inc.STATE.exists());self.assertFalse((ROOT/'frozen_runtime/pre_run_freeze.json').exists())
 def test_old_batch_entrypoint_permanently_retired(self):
  with self.assertRaisesRegex(RuntimeError,'RETIRED_BATCH_ENTRYPOINT'):b.real_score('DO_NOT_READ','bad',True)
  self.assertFalse(b.STATE.exists())
 def test_source_identity_ignores_snapshot_path_only(self):
  row={'record':{'parents':['frozen-parent']},'claim':{'claim_id':'fake'},'sources':[{'files':{'answer.txt':{'path':'first','sha256':'a'*64}}}]};other=copy.deepcopy(row);other['sources'][0]['files']['answer.txt']['path']='second'
  self.assertEqual(inc.input_identity(row),inc.input_identity(other));other['record']['parents']=[];self.assertNotEqual(inc.input_identity(row),inc.input_identity(other))
 def test_generation_failure_format_row_does_not_read_answer(self):
  row={'record':{'slot_id':'fake','parents':['frozen-parent']},'claim':{'claim_id':'fake'},'status':'generation_failure','reason':'timeout','sources':[{'files':{'answer.txt':{'path':'DO_NOT_READ','sha256':'a'*64}}}]}
  out=inc.format_row(row,lambda x:(_ for _ in ()).throw(AssertionError('no extract')));self.assertIsNone(out['candidate']);self.assertEqual(out['scores'],[]);self.assertEqual(out['reason'],'timeout')
if __name__=='__main__':
 result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests))
 (ROOT/'CONTROLLER_TEST_RESULT.json').write_text(json.dumps({'tests':result.testsRun,'passed':result.wasSuccessful(),'failures':len(result.failures),'errors':len(result.errors),'synthetic_only':True,'real_admissions':0,'real_packs':0},indent=2)+'\n')
 raise SystemExit(not result.wasSuccessful())
