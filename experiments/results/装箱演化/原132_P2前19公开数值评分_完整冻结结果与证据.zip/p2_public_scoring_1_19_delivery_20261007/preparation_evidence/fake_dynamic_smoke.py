#!/usr/bin/env python3
"""One-shot authored-source smoke through ORIGINAL sandbox gates, fake only."""
import copy,hashlib,importlib.util,json,os,pathlib,resource,shutil,sys,time
ROOT=pathlib.Path(__file__).resolve().parent
sys.dont_write_bytecode=True
import adapter as b
from local_runtime_wrapper import derive_local_run_manifest
FAKE=ROOT/'fake_only_dynamic'
SOURCE='def score(item, bins):\n    return -(bins - item)\n'
ITEMS=[40,60,20,80,33,67,1,99]
def write(p,v):b.write_once(p,v)
def main():
    start=time.monotonic();self0=time.process_time();FAKE.mkdir(exist_ok=False)
    write(FAKE/'attempt.json',{'fixture_only':True,'source_sha256':b.sha(SOURCE.encode()),'items':ITEMS,'real_P2_admissions':0,'real_P2_packs':0,'no_retry':True})
    runtime=FAKE/'runtime';shutil.copytree(ROOT/'frozen_runtime',runtime)
    b.need(not (runtime/'pre_run_freeze.json').exists(),'fake has no real execution metadata')
    wf=b.read(runtime/'worker_freeze.json');b.need(b.sha(b.read_bytes(runtime/'worker_freeze.json'))==b.RUNTIME_HASH,'frozen runtime')
    # Exact dependency list already read-only checked; frozen child and supervisor
    # independently recheck it again as their original startup contract demands.
    local=derive_local_run_manifest('fake-only-original8items',b.FROZEN_SHA,b.RUNTIME_HASH,'NO_BENCHMARK_USED',b.read(ROOT/'frozen_metadata/RESOURCE_SCOPE.json').get('resource_profile_sha256','not-a-source-authority'),b.sha(b.read_bytes(ROOT/'SOURCE_EVIDENCE.json')),'NO_TRUST_RECEIPT_FABRICATED',wf['dependencies'])
    local.update(schema='fake-only-local-run-metadata-v1',fixture_only=True,source_sha256=b.sha(SOURCE.encode()),original_design_used=False)
    write(runtime/'pre_run_freeze.json',local)
    sys.path.insert(0,str(runtime))
    from registry import sha,digest
    from resource_profile import PRODUCTION_PROFILE_ID,profile_sha256
    from policy import policy_sha256
    from runner import Session
    from supervised_runner import supervised_pack
    from checker import check_assignment
    candidate={'description':'Authored fake-only best-fit scoring fixture','code':SOURCE,'description_sha256':sha(b'Authored fake-only best-fit scoring fixture'),'code_sha256':sha(SOURCE.encode()),'pair_sha256':digest({'description':'Authored fake-only best-fit scoring fixture','code':SOURCE}),'description_consistency':'undetermined'}
    claim_id=digest(['fake-only-smoke','authored8'])
    binding={'batch_id':'fake-only-smoke','wave_id':'fake-only-smoke-wave','slot_id':'authored8','raw_response_sha256':sha(SOURCE.encode()),'source_sha256':sha(SOURCE.encode()),'policy_sha256':policy_sha256(),'runtime_freeze_sha256':b.RUNTIME_HASH,'claim_sha256':digest(['fake-only-local-claim',claim_id]),'claim_id':claim_id,'registry_sha256':digest(['fake-only-authored-source-registry',sha(SOURCE.encode())]),'resource_profile_sha256':profile_sha256(PRODUCTION_PROFILE_ID)}
    write(FAKE/'source_binding.json',{'candidate':candidate,'binding':binding,'fixture_only':True,'meaning':'Local authored fixture identity, not a model claim or historical approval. Direct Session/supervised_pack exercise; no production registry insertion.'})
    admission=None;report=None
    try:
        worker=Session(candidate,binding,worker_role='admission',execution_id=claim_id+'/admission')
        admitted=copy.deepcopy(worker.admission);worker.close();admission=worker.evidence()
        b.need(admitted['admitted'] and admission['source_after_host_gate'] and admission['reaped'],'fake admission gate')
        write(FAKE/'admission_worker.json',{'fixture_only':True,'admission':admitted,'worker':admission})
        report=supervised_pack(ITEMS,100,candidate,binding,execution_id=claim_id+'/instance/0',instance_index=0)
        write(FAKE/'pack_receipt.json',{'fixture_only':True,**report})
        b.need(report['outcome']=='ok','fake tiny pack outcome')
        checked=check_assignment(ITEMS,100,report['result']);b.need(checked['used_bins']==4,'fixture result')
        usage=resource.getrusage(resource.RUSAGE_CHILDREN)
        result={'status':'passed','fixture_only':True,'fixture_items':8,'original_frozen_worker_used':True,'real_model_candidates':0,'real_P2_admissions':0,'real_P2_packs':0,'benchmark_or_heldout_used':False,'candidate_fixture_admissions':1,'candidate_fixture_packs':1,'checker':checked,'admission_source_after_host_gate':admission['source_after_host_gate'],'instance_source_after_host_gate':report['worker']['source_after_host_gate'],'worker_security':report['worker']['security'],'worker_limits':report['worker']['host_observed_limits'],'supervisor_limits':report['supervisor_evidence']['host_observed_limits'],'admission_cpu_seconds':admission['cpu_seconds'],'instance_child_cpu_seconds':report['worker']['cpu_seconds'],'supervisor_self_cpu_seconds':report['supervisor_evidence']['actual_supervisor_cpu_seconds'],'supervisor_inclusive_wait4_cpu_seconds':report['supervisor_evidence']['wait4_cpu_seconds'],'all_children_cpu_seconds':usage.ru_utime+usage.ru_stime,'self_cpu_seconds':time.process_time()-self0,'total_measured_cpu_seconds':usage.ru_utime+usage.ru_stime+time.process_time()-self0,'wall_seconds':time.monotonic()-start,'clean_reaped':admission['reaped'] and report['worker']['reaped'] and report['supervisor_evidence']['reaped'],'limits':'Dynamic smoke only. No evidence of original5x5000 runtime feasibility or model candidate validity.'}
    except BaseException as exc:
        result={'status':'blocked_no_retry','fixture_only':True,'exception':type(exc).__name__+': '+str(exc),'worker_evidence':getattr(exc,'worker_evidence',None),'supervisor_evidence':getattr(exc,'supervisor_evidence',None),'admission':admission,'self_cpu_seconds':time.process_time()-self0,'wall_seconds':time.monotonic()-start,'real_P2_admissions':0,'real_P2_packs':0}
    write(FAKE/'RESULT.json',result);print(b.canonical(result));return result['status']=='passed'
if __name__=='__main__':sys.exit(not main())
