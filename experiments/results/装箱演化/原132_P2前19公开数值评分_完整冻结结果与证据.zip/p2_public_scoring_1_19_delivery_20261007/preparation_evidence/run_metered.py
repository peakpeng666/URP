#!/usr/bin/env python3
"""Meter trusted preparation subprocesses; <=20s wall for single-thread smoke.

No changes to original sandbox limits. Parent counts aggregate reaped CPU; stops
remaining preparation if measured total approaches the 30 CPU-second envelope.
"""
import json,os,pathlib,resource,signal,subprocess,sys,time
ROOT=pathlib.Path(__file__).resolve().parent
if len(sys.argv)<3:raise SystemExit('usage: run_metered.py LABEL SCRIPT [ARGS]')
label,script,*args=sys.argv[1:]
ledger=ROOT/'PREPARATION_COST_LEDGER.jsonl'
prior=[json.loads(x) for x in ledger.read_text().splitlines()]
used=sum(x.get('total_measured_cpu_seconds',x.get('self_cpu_seconds',0)) for x in prior)
if used>=10:raise SystemExit('Preparation measured CPU margin exhausted; stop before 30.')
start=time.monotonic();self0=time.process_time();children0=resource.getrusage(resource.RUSAGE_CHILDREN)
# Timeout of 8s bounds this original smoke's serial parent/supervisor/worker wait
# pipeline well below30CPU; no candidate or original profile limit is altered.
p=subprocess.Popen([sys.executable,'-B',str(ROOT/script),*args],cwd=ROOT,env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1','OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1'},stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
try:out,err=p.communicate(timeout=8)
except subprocess.TimeoutExpired:
 os.killpg(p.pid,signal.SIGKILL);out,err=p.communicate();err+=b'\nPREPARATION_WALL_WATCHDOG: descendants rely on unchanged PDEATHSIG; no retries.\n'
usage=resource.getrusage(resource.RUSAGE_CHILDREN);cpu=usage.ru_utime+usage.ru_stime-children0.ru_utime-children0.ru_stime+time.process_time()-self0
record={'task':label,'returncode':p.returncode,'total_measured_cpu_seconds':cpu,'wall_seconds':time.monotonic()-start,'prior_measured_cpu_seconds':used,'measured_running_total_cpu_seconds':used+cpu}
with ledger.open('a') as f:f.write(json.dumps(record)+'\n');f.flush();os.fsync(f.fileno())
(ROOT/(label+'.stdout.txt')).write_bytes(out);(ROOT/(label+'.stderr.txt')).write_bytes(err)
print(json.dumps(record));print(out.decode(errors='replace')[:5000]);print(err.decode(errors='replace')[:3000]);sys.exit(p.returncode)
