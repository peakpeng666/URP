import hashlib,json,os,resource,signal,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
with (ROOT/'LAUNCH_CLAIM.json').open('x') as f:json.dump({'no_retry':True,'cpu_limit_seconds':30,'wall_limit_seconds':60,'timestamp':time.time()},f)
start=time.monotonic();pid=os.fork()
if pid==0:
 os.chdir(ROOT);resource.setrlimit(resource.RLIMIT_CPU,(30,30));signal.alarm(60)
 with open('stdout.json','xb') as out,open('stderr.txt','xb') as err:
  os.dup2(out.fileno(),1);os.dup2(err.fileno(),2);os.execv(sys.executable,[sys.executable,'-B','run_once.py'])
_,status,ru=os.wait4(pid,0);exitcode=os.waitstatus_to_exitcode(status)
r={'exit_code':exitcode,'wait_status':status,'reaped':True,'cpu_user_seconds':ru.ru_utime,'cpu_system_seconds':ru.ru_stime,'cpu_total_seconds':ru.ru_utime+ru.ru_stime,'wall_seconds':time.monotonic()-start,'max_rss_kib':ru.ru_maxrss,'cpu_limit_seconds':30,'wall_limit_seconds':60,'pid':pid,'completed':exitcode==0}
with (ROOT/'EXIT_RECEIPT.json').open('x') as f:json.dump(r,f,sort_keys=True,indent=2)
print(json.dumps(r));sys.exit(0 if exitcode==0 else 1)
