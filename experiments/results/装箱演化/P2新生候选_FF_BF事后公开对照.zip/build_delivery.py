"""Make one outer delivery, retaining both inner ZIPs and receipts byte-for-byte.
No baseline execution, model call, external upload, or edits to original/audit.
"""
import datetime
import hashlib
import json
import pathlib
import shutil
import time
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent
BASE = ROOT.parent
OUTER = pathlib.Path(str(ROOT) + '.zip')
RECEIPT = pathlib.Path(str(OUTER) + '.receipt.json')
CPU0, WALL0 = time.process_time_ns(), time.monotonic_ns()
assert not OUTER.exists() and not RECEIPT.exists()
EXPECTED = {
    'public_binpacking_controls_20261007.zip': (212409, 'b8bd6393ee0ccca4df64e1972e0fe81ad2e86b1dafb9b4c6ae2d110f77825e19'),
    'public_binpacking_controls_audit_20261007.zip': (47349, 'e1e8b0472da879238b04b59604800c3c2a6a394a61ba4f7ad7640a9bcc42b542'),
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def snapshot(directory):
    return {str(p.relative_to(directory)): {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in sorted(directory.rglob('*')) if p.is_file()}


def write_once(name, value):
    with (ROOT / name).open('x') as f:
        f.write(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n')


before = {}
sources = []
for name, (size, expected) in EXPECTED.items():
    archive = BASE / name
    directory = BASE / name.removesuffix('.zip')
    assert archive.stat().st_size == size and sha(archive) == expected
    before[directory.name] = snapshot(directory)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert set(z.namelist()) == set(before[directory.name])
        for member in z.namelist():
            contents = z.read(member)
            entry = before[directory.name][member]
            assert len(contents) == entry['bytes'] and hashlib.sha256(contents).hexdigest() == entry['sha256']
    receipt_path = pathlib.Path(str(archive) + '.receipt.json')
    receipt = json.loads(receipt_path.read_text())
    assert receipt['archive_bytes'] == size and receipt['archive_sha256'] == expected
    for source in [archive, receipt_path]:
        destination = ROOT / source.name
        assert not destination.exists()
        shutil.copyfile(source, destination)
        assert source.read_bytes() == destination.read_bytes()
        sources.append({'source_path': str(source), 'delivery_path': source.name, 'bytes': source.stat().st_size, 'sha256': sha(source)})

text = '''公开手写基线诊断：最终交付说明
2026-10-07

结论与身份
这是一项在原 P2 public60 闭账后新增的、明确事后的 FF/BF 描述性对照。独立复核通过，附科研与证据边界。它不是原 P2 预注册 controls；原 P2 的 controls=0 身份、原60/132分母、缺失值、预算和入口均不改写。

同题与结果
使用完全相同的5条公开物品流，每条5000项、容量100、原顺序；设计文件SHA256为5358c41aa758e1d399d29157f8cbdc5fb422f4c8acd56b2cb95c41af3f1750ca。
FF箱数：[2098,2067,2065,2070,2059]；fitness≈0.959458274460。
BF箱数：[2094,2059,2057,2067,2058]；fitness≈0.961687165486。
fitness是五个L1/used_bins的等权算术平均，完整精确分数保存在主包。L1只是体积下界，不是已证明的最优箱数。

原EOH public所选best相对BF：五例分别少[66,62,62,73,66]箱，五个相同公开流合计少329箱；fitness增加3.162133个百分点。
原IID public所选best相对BF：五例分别少[17,13,6,22,9]箱，五个相同公开流合计少67箱；fitness增加0.627181个百分点。
这里的百分点是fitness绝对差乘100，不能直接写成相同比例的相对百分比增益。

全部43个完整候选相对BF：28高、6等、9低；EOH 22/0/2（有效分母24），IID 6/6/7（有效分母19）。相对FF：38高、0等、5低。原17个未排名槽仍保留fitness=null、used_bins=[]，包括10次生成失败和7次准入拒绝；原总体分母仍为60，两臂各30。
6个相等IID候选具有与BF相同的五例箱数和fitness，这不能证明代码相同、算法相同，也不能单凭这一点判断创新与否。

证据与局限
新FF/BF只做了预先冻结的2×5=10次pack，保存完整5000项assignment。作者逐步checker、另一实现的分桶heap重放，以及独立审核的bitset残量桶谓词均核对了50,000次放置。原43候选只对公开safe摘要、精确fitness和215个case记录做交叉核验，没有重放其完整原assignment。
实际原runner包含空箱与exact-fit可行项，按原bin顺序stable first argmax。历史静态契约中的int32提案不覆盖最终int64 runtime变体；本对照按精确整数FF/BF规则与实际可行/tie语义执行。
这是同一public设计集上的best-of-many观察，存在选择偏倚。五例不是五个独立外部泛化样本。没有heldout证据、显著性结论、全臂普遍优越结论或算法创新认证。

资源边界
基线main硬限60 CPU秒，正常退出实用11.482846秒。内部FF/BF循环与checker已包含在main内，不再重复相加。
独立审核两次只读运行CPU分别0.700941和0.696996秒，合计1.397937秒。第一次的ZIP顶层目录假设错误和修正后通过均完整留痕，没有重跑实验。
作者前期源码阅读/撰写、协议准备、失败的schema后处理及部分报告准备CPU未累计观测，保留unknown，不能填0。因此没有可信的精确全成本总额或全成本优势结论。
手写基线走可信Python直接执行，原候选走worker/supervisor/guard路径，不能用二者时间直接排名算法速度。
主包原封包CPU0.126875326秒，另有最终只读验证子进程CPU0.130601秒；独审包原封包CPU0.019113527秒。其他已测细分及范围见各完整receipt。此次外层封装另计于最终ZIP同名.receipt.json，不混入main。

文件与修正历史
1. public_binpacking_controls_20261007.zip：原主包，212409字节，SHA256 b8bd6393ee0ccca4df64e1972e0fe81ad2e86b1dafb9b4c6ae2d110f77825e19。
2. public_binpacking_controls_audit_20261007.zip：原独审包，47349字节，SHA256 e1e8b0472da879238b04b59604800c3c2a6a394a61ba4f7ad7640a9bcc42b542。
3. 两份对应的完整原外层receipt均逐字节保留。主包receipt中“等待根独审”是其较早时点记录；后续独审通过的依据在独审包，不回写历史。
4. 作者曾把失败行used_bins=[]误断言为None，仅修正纯后处理schema检查；原源码版本与纠正记录保留。独审曾修正ZIP目录假设，失败代码与日志也保留。冻结规则、原始结果和原包均未覆盖。
5. DELIVERY_MANIFEST.json给出本外层内容SHA；build_delivery.py是只做封装和完整性核验的程序，不执行实验。外层ZIP的最终SHA、资源与原件不变核验在其同名.receipt.json。

两个内层ZIP、两份原receipt、原主目录与独审目录均经过封装前后哈希核对。所有ZIP经过CRC和逐成员SHA核验。这里的SHA和时间日志用于一致性/损坏检测，不是外部不可篡改时间证明或全系统执行审计。
本次没有上传、模型调用、安装或新增pack。由根代理完成唯一归档交接。
'''
with (ROOT / '中文交付说明.txt').open('x') as f:
    f.write(text)
for source in sources:
    assert sha(pathlib.Path(source['source_path'])) == source['sha256']
for name, state in before.items():
    assert snapshot(BASE / name) == state
write_once('ORIGINALS_UNCHANGED.json', {'status': 'passed', 'source_files': sources, 'original_directory_snapshots': before, 'originals_opened_readonly': True, 'new_experimental_packs': 0, 'external_uploads': 0})
rows = [{'path': str(p.relative_to(ROOT)), 'bytes': p.stat().st_size, 'sha256': sha(p)} for p in sorted(ROOT.rglob('*')) if p.is_file()]
write_once('DELIVERY_MANIFEST.json', {'schema': 'posthoc-controls-final-outer-delivery-v1', 'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'files': rows, 'manifest_self_sha_in_external_receipt': True, 'inner_archives_byte_identical': True, 'contains_two_complete_original_external_receipts': True, 'scientific_identity': 'Post-hoc public-only diagnostic; not original P2 controls', 'directory_stopped_writing_after_manifest': True})
with zipfile.ZipFile(OUTER, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for row in rows:
        z.write(ROOT / row['path'], row['path'], compress_type=zipfile.ZIP_STORED if row['path'].endswith('.zip') else zipfile.ZIP_DEFLATED)
    z.write(ROOT / 'DELIVERY_MANIFEST.json', 'DELIVERY_MANIFEST.json')
with zipfile.ZipFile(OUTER) as z:
    assert z.testzip() is None
    assert set(z.namelist()) == {r['path'] for r in rows} | {'DELIVERY_MANIFEST.json'}
    for row in rows:
        raw = z.read(row['path'])
        assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
    assert z.read('DELIVERY_MANIFEST.json') == (ROOT / 'DELIVERY_MANIFEST.json').read_bytes()
for name, state in before.items():
    assert snapshot(BASE / name) == state
for source in sources:
    assert sha(pathlib.Path(source['source_path'])) == source['sha256']
receipt = {'schema': 'final-outer-delivery-packaging-receipt-v1', 'archive_path': str(OUTER), 'archive_bytes': OUTER.stat().st_size, 'archive_sha256': sha(OUTER), 'archive_entries': len(rows) + 1, 'manifest_sha256': sha(ROOT / 'DELIVERY_MANIFEST.json'), 'readable_explanation_path': str(ROOT / '中文交付说明.txt'), 'inner_archives_and_receipts_unchanged': True, 'original_main_and_audit_directories_unchanged': True, 'inner_and_outer_CRC_and_entry_SHA': 'passed', 'packaging_process_cpu_ns_before_receipt': time.process_time_ns() - CPU0, 'packaging_wall_ns_before_receipt': time.monotonic_ns() - WALL0, 'resource_scope': 'source snapshot and both inner ZIP CRC/entry checks, exact-copy 2 ZIP+2 receipts, readable explanation and manifest, outer ZIP build/CRC/entry checks and post-build original source checks; excludes source-code preparation/interpreter startup and this final receipt write; no experiment or statistical rerun', 'all_in_project_CPU_total': None, 'unobserved_prior_costs_not_zero': True, 'new_experimental_packs': 0, 'uploads': 0, 'wrapper_directory_stopped_writing': True, 'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
with RECEIPT.open('x') as f:
    f.write(json.dumps(receipt, sort_keys=True, ensure_ascii=False, separators=(',', ':')) + '\n')
print(json.dumps(receipt, ensure_ascii=False, indent=2))
