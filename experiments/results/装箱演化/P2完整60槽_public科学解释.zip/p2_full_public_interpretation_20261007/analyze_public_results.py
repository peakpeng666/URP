#!/usr/bin/env python3
"""Read-only descriptive analysis of the closed P2 public-design experiment.
Never imports, compiles, executes, or rescores model code. No network access.
Requires immutable delivery directories; exits unless all 60 final results exist.
"""
from pathlib import Path
from fractions import Fraction
from collections import Counter, defaultdict
import argparse, hashlib, json, statistics, time

ROOT = Path('/workspace/shared')
OUT = ROOT / 'p2_full_public_interpretation_20261007'
PREFIXES = [(1,19),(20,25),(26,31),(32,37),(38,43),(44,49),(50,55),(56,60)]
DEP = {}

def read(p):
    p = Path(p)
    assert 'protocol_draft' not in str(p).lower()
    assert not any('heldout' in s.lower() for s in p.parts)
    raw=p.read_bytes()
    DEP[str(p)]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
    return json.loads(raw)

def frac(x):
    return Fraction(x['numerator'],x['denominator'])

def fj(x):
    return {'numerator':x.numerator,'denominator':x.denominator,'decimal':float(x)}

def stats(xs):
    return {'count':len(xs),'sum':sum(xs),'mean':statistics.mean(xs) if xs else None,
            'median':statistics.median(xs) if xs else None,'min':min(xs) if xs else None,'max':max(xs) if xs else None}

def quality(rows):
    fs=[frac(r['fitness']) for r in rows]
    return {'conditional_denominator':len(rows),'mean':fj(sum(fs,Fraction())/len(fs)) if fs else None,
            'median':fj(statistics.median(fs)) if fs else None,
            'min':fj(min(fs)) if fs else None,'max':fj(max(fs)) if fs else None,
            'mean_used_bins_by_case':[float(sum(Fraction(r['used_bins'][j]) for r in rows)/len(rows)) for j in range(5)] if rows else None,
            'interpretation':'Descriptive distribution conditional on complete, compliant fitness; excluded failure fitness remains null. Not an all-slot efficacy mean.'}

def rank_average(values):
    return [1+sum(v>x for v in values)+Fraction(sum(v==x for v in values)-1,2) for x in values]

def spearman(a,b):
    a=rank_average(a);b=rank_average(b);ma=sum(a)/len(a);mb=sum(b)/len(b)
    num=sum((x-ma)*(y-mb) for x,y in zip(a,b));da=sum((x-ma)**2 for x in a);db=sum((y-mb)**2 for y in b)
    return float(num)/(float(da*db)**0.5) if da and db else None

def main():
    start=time.process_time();wall=time.monotonic()
    delivery=[];results={};summary_by_prefix=[]
    for lo,hi in PREFIXES:
        name=f'p2_public_scoring_{lo}_{hi}_'+('delivery' if lo==1 else 'delta')+'_20261007'
        d=ROOT/name;delivery.append(d)
        summary=read(d/'SUMMARY.json');summary_by_prefix.append(summary)
        state=d/('project/public_execution' if lo==1 else 'state_delta')
        paths=sorted((state/'results').glob('*.json'))
        assert len(paths)==hi-lo+1,(lo,hi,len(paths))
        for p in paths:
            r=read(p);slot=r['slot_id'];pos=r['record']['position']
            assert slot not in results and lo<=pos<=hi
            r['_result_file']=str(p);results[slot]=r
    assert len(results)==60
    assert sorted(r['record']['position'] for r in results.values())==list(range(1,61))
    assert Counter(r['record']['arm'] for r in results.values())=={'EOH_TC':30,'IID_TC':30}
    terminal={'scored','admission_rejected','generation_failure','numeric_failure','numerical_failure'}
    assert all(r['evaluation_status'] in terminal for r in results.values())
    final=delivery[-1]
    exact=read(final/'CUMULATIVE_EXACT_FITNESS_ROWS.json')
    gen=read(final/'generation_sources/slots_1_60.json')
    assert len(exact)==60 and len(gen['rows'])==60
    safe_rows=read(final/'safe_facts/PER_SLOT_SAFE_RESULTS.json')
    safe={r['slot_id']:r for r in safe_rows}
    assert len(safe)==60
    gen={r['record']['slot_id']:r for r in gen['rows']}
    rows=[];L1=None;case_input_sha=None
    for r in sorted(results.values(),key=lambda x:x['record']['position']):
        slot=r['slot_id'];a=r.get('admission') or {};aw=a.get('worker') or {};g=gen[slot]['local_generation_result'];rec=r['record']
        assert g and not g.get('fixture_only')
        assert rec==gen[slot]['record']
        scores=r['scores'];f=r['fitness'];status=r['evaluation_status']
        if status=='scored':
            assert len(scores)==5 and f is not None
            ll=[s['L1'] for s in scores];sh=[s['input_sha256'] for s in scores]
            if L1 is None:L1,case_input_sha=ll,sh
            assert ll==L1 and sh==case_input_sha
            assert all(s['outcome']=='ok' for s in scores)
            assert frac(f)==sum((Fraction(s['L1'],s['used_bins']) for s in scores),Fraction())/5
        else: assert f is None
        token=g.get('cli_reported_tokens')
        if isinstance(token,dict) and not any(v is not None for v in token.values()):token=None
        row={'position':rec['position'],'slot_id':slot,'nominal_pair':slot.replace('_EOH_TC_','_ARM_').replace('_IID_TC_','_ARM_'),
             'arm':rec['arm'],'operator':rec['operator'],'status':status,'reason':r.get('reason'),
             'admission_kind':a.get('kind'),'fitness':f,'used_bins':[s['used_bins'] for s in scores] if status=='scored' else [],
             'source_sha256':a.get('source_sha256'),'canonical_text_sha256':(aw.get('admission') or {}).get('canonical_text_sha256'),
             'bounded_child_code_identity':safe[slot].get('bounded_child_code_identity'),
             'bounded_child_joint_identity':safe[slot].get('bounded_child_joint_identity'),
             'answer_sha256':g.get('answer_sha256'),'prompt_sha256':rec['prompt_sha256'],
             'serialized_messages_sha256':rec['serialized_messages_sha256'],'request_sha256':rec['request_sha256'],
             'parent_snapshot_sha256':rec['parent_snapshot_sha256'],'parents':rec['parents'],
             'cli_payload_bytes':rec['actual_cli_payload_bytes'],'generation_wall_seconds':g['wall_seconds'],
             'generation_timeout_seconds':g['requested_timeout_seconds'],'cli_reported_tokens':token,
             'cli_client_state':g['client_state'],'cli_exit_code':g['exit_code'],'finish_reasons':g['finish_reasons'],
             'provider_cost':g.get('provider_cost'),'provider_usage':g.get('provider_usage'),'physical_http_attempts':g.get('physical_http_attempts'),
             'numeric_admission_cpu_seconds':aw.get('cpu_seconds',0),
             'numeric_inclusive_pack_cpu_seconds':sum(s['evidence']['supervisor']['wait4_cpu_seconds'] for s in scores),
             'numeric_pack_shared_wall_seconds':sum(s['evidence']['supervisor']['wall_seconds'] for s in scores),
             'numeric_child_pack_cpu_seconds':sum(s['evidence']['supervisor']['child_cpu_seconds'] for s in scores),
             'score_call_cpu_seconds':sum(s['evidence']['worker']['score_call_cpu_ns'] for s in scores)/1e9,
             'result_file':r['_result_file']}
        row['numeric_cpu_seconds_no_double_count']=row['numeric_admission_cpu_seconds']+row['numeric_inclusive_pack_cpu_seconds']
        assert row['source_sha256']==safe[slot]['source_sha256']
        assert row['fitness']==safe[slot]['fitness_exact']
        rows.append(row)
    exact={r['slot_id']:r for r in exact}
    for r in rows:
        e=exact[r['slot_id']]
        assert r['fitness']==e['fitness'] and r['used_bins']==e['used_bins'] and r['status']==e.get('status',e.get('evaluation_status'))
    armfacts={};duplicated_groups={}
    for arm in ['EOH_TC','IID_TC']:
        allr=[r for r in rows if r['arm']==arm];ok=[r for r in allr if r['status']=='scored'];nonempty=[r for r in allr if r['status']!='generation_failure']
        sr=defaultdict(list)
        for r in nonempty: sr[r['source_sha256']].append(r)
        assert None not in sr
        duplicates=[{'source_sha256':sha,'positions':[r['position'] for r in rr],'statuses':[r['status'] for r in rr]} for sha,rr in sr.items() if len(rr)>1]
        unique_ok={r['source_sha256']:r for r in ok}
        for sha in unique_ok:
            fs=[r['fitness'] for r in ok if r['source_sha256']==sha]
            assert all(f==fs[0] for f in fs)
        best=max(ok,key=lambda r:frac(r['fitness']));ranked=sorted(ok,key=lambda r:(-frac(r['fitness']),r['position']))
        tok=[r for r in allr if r['cli_reported_tokens'] is not None]
        usage={key:sum(r['cli_reported_tokens'].get(key) or 0 for r in tok) for key in ['input','output','reasoning']}
        af={'generation_denominator':30,'terminal_count':30,'nonempty_answers':len(nonempty),'generation_failures':sum(r['status']=='generation_failure' for r in allr),
            'generation_failures_by_reason':dict(Counter(r['reason'] for r in allr if r['status']=='generation_failure')),
            'actual_admissions':len(nonempty),'admission_rejections':sum(r['status']=='admission_rejected' for r in allr),
            'admission_rejections_by_kind':dict(Counter(r['admission_kind'] for r in allr if r['status']=='admission_rejected')),
            'numerical_failures':sum('numeric' in r['status'] for r in allr),'complete_fitness':len(ok),'unranked':30-len(ok),
            'complete_fitness_rate':{'numerator':len(ok),'denominator':30,'decimal':len(ok)/30},
            'full_arm_mean_fitness':None,
            'full_arm_mean_fitness_reason':'Undefined without an authorized failure utility; failure fitness remains null.',
            'generation_failure_rate_all_slots':{'numerator':sum(r['status']=='generation_failure' for r in allr),'denominator':30},
            'admission_rejection_rate_all_slots':{'numerator':sum(r['status']=='admission_rejected' for r in allr),'denominator':30},
            'admission_rejection_rate_given_nonempty':{'numerator':sum(r['status']=='admission_rejected' for r in allr),'denominator':len(nonempty)},
            'conditional_quality':quality(ok),'byte_source_deduplicated_conditional_quality':quality(list(unique_ok.values())),
            'distinct_source_hashes_nonempty':len(sr),'duplicate_source_excess_nonempty':len(nonempty)-len(sr),'duplicate_source_groups':duplicates,
            'distinct_source_hashes_complete':len(unique_ok),'distinct_five_case_used_bins_vectors_complete':len({tuple(r['used_bins']) for r in ok}),
            'best':{k:best[k] for k in ['position','slot_id','fitness','used_bins','source_sha256']},
            'ranked_complete_positions':[r['position'] for r in ranked],
            'generation_wall_seconds':stats([r['generation_wall_seconds'] for r in allr]),
            'generation_payload_bytes':stats([r['cli_payload_bytes'] for r in allr]),
            'cli_token_records_present':len(tok),'cli_token_records_missing':30-len(tok),'cli_tokens_observed_sum':usage,
            'cli_tokens_observed_per_record':{k:stats([r['cli_reported_tokens'].get(k) or 0 for r in tok]) for k in usage},
            'numeric_cpu_seconds_no_double_count':sum(r['numeric_cpu_seconds_no_double_count'] for r in allr),
            'numeric_pack_shared_wall_seconds':sum(r['numeric_pack_shared_wall_seconds'] for r in allr),
            'numeric_cpu_per_complete_candidate':stats([r['numeric_cpu_seconds_no_double_count'] for r in ok]),
            'score_call_cpu_seconds_complete':stats([r['score_call_cpu_seconds'] for r in ok]),
            'prompt_hash_distinct_count':len({r['prompt_sha256'] for r in allr}),
            'parent_snapshot_hashes':dict(Counter(r['parent_snapshot_sha256'] for r in allr)),
            'distinct_parents':sorted({p for r in allr for p in r['parents']}),
            'parent_occurrence_count':dict(Counter(p for r in allr for p in r['parents']))}
        armfacts[arm]=af
    pairs=defaultdict(dict)
    for r in rows:pairs[r['nominal_pair']][r['arm']]=r
    assert len(pairs)==30 and all(len(p)==2 for p in pairs.values())
    pairrows=[]
    for key,p in pairs.items():
        e,i=p['EOH_TC'],p['IID_TC'];both=e['status']==i['status']=='scored';diff=frac(e['fitness'])-frac(i['fitness']) if both else None
        pairrows.append({'nominal_pair':key,'EOH_position':e['position'],'IID_position':i['position'],'EOH_status':e['status'],'IID_status':i['status'],
                         'both_scored':both,'fitness_difference':fj(diff) if diff is not None else None,
                         'direction':'EOH' if diff is not None and diff>0 else 'IID' if diff is not None and diff<0 else 'tie' if both else None})
    scored=[r for r in rows if r['status']=='scored']
    best=max(scored,key=lambda r:frac(r['fitness']));be=armfacts['EOH_TC']['best'];bi=armfacts['IID_TC']['best']
    case_stability=[]
    for j in range(5):
        vals={r['position']:Fraction(L1[j],r['used_bins'][j]) for r in scored};mx=max(vals.values())
        lo={r['position']:sum((Fraction(L1[k],r['used_bins'][k]) for k in range(5) if k!=j),Fraction())/4 for r in scored};lmx=max(lo.values())
        case_stability.append({'case_index':j,'L1':L1[j],'input_sha256':case_input_sha[j],
                               'winning_positions':[p for p,v in vals.items() if v==mx],
                               'leave_one_case_out_winning_positions':[p for p,v in lo.items() if v==lmx],
                               'best_EOH_used_bins':be['used_bins'][j],'best_IID_used_bins':bi['used_bins'][j],
                               'best_EOH_bin_saving':bi['used_bins'][j]-be['used_bins'][j]})
    correlation=[{'case_a':j,'case_b':k,'spearman_complete_candidates':spearman([Fraction(L1[j],r['used_bins'][j]) for r in scored],[Fraction(L1[k],r['used_bins'][k]) for r in scored])} for j in range(5) for k in range(j+1,5)]
    ehash={r['source_sha256'] for r in rows if r['arm']=='EOH_TC' and r['source_sha256']};ihash={r['source_sha256'] for r in rows if r['arm']=='IID_TC' and r['source_sha256']}
    resource=read(delivery[0]/'project/frozen_metadata/RESOURCE_SCOPE.json')
    review_summaries=[]
    for lo,hi in PREFIXES:
        p=ROOT/f'p2_public_scoring_{lo}_{hi}_independent_review_20261007.json'
        if p.exists():review_summaries.append({'prefix_end':hi,'file':str(p),'review':read(p)})
    allnumeric=sum(r['numeric_cpu_seconds_no_double_count'] for r in rows)
    assert abs(allnumeric-summary_by_prefix[-1]['cumulative_usage']['numerical_cpu_seconds_no_double_count'])<1e-5
    facts={'schema':'p2_full_public_descriptive_interpretation_v1','scope':{'phase':'P2','generation_slots':60,'per_arm':30,'public_cases':5,'items_per_case':5000,
            'metric':'mean over five fixed public cases of exact Fraction(L1, used_bins); maximize',
            'heldout_reads_by_this_analysis':0,'heldout_evidence':False,'model_or_candidate_executions_by_this_analysis':0,
            'null_imputed_to_zero':False,'statistical_significance_tests_performed':False,
            'unit_warning':'30 generation slots per arm are not 30 independent benchmark instances. Cases and parent pool are reused.'},
           'arms':armfacts,'all_failure_counts':dict(Counter(r['status'] for r in rows)),
           'best_fitness_difference_EOH_minus_IID':fj(frac(be['fitness'])-frac(bi['fitness'])),
           'best_bin_savings_sum_over_fixed_five_cases':sum(bi['used_bins'])-sum(be['used_bins']),
           'source_identity':{'nonempty_count':sum(r['source_sha256'] is not None for r in rows),'global_distinct_byte_source_hashes':len(ehash|ihash),
                              'complete_distinct_bounded_child_code_identities':len({r['bounded_child_code_identity'] for r in scored}),
                              'complete_distinct_bounded_child_joint_identities':len({r['bounded_child_joint_identity'] for r in scored}),
                              'cross_arm_shared_source_hashes':sorted(ehash&ihash),
                              'warning':'Byte-source identity only. Distinct hashes do not establish distinct algorithms; equal public output vectors do not establish semantic equivalence.'},
           'nominal_pairs':{'count':len(pairs),'both_scored':sum(r['both_scored'] for r in pairrows),'directions_on_both_scored':dict(Counter(r['direction'] for r in pairrows if r['both_scored'])),
                            'status_cross_tab':dict(Counter(r['EOH_status']+' | '+r['IID_status'] for r in pairrows)),
                            'interpretation':'Slots are nominal matched schedule positions, not identical prompts, seeds, parent contexts, or independent experiments. Success-only pair comparison is selection-conditioned.',
                            'rows':pairrows},
           'public_ranking_stability':{'cases':case_stability,'case_rank_correlations':correlation,'warning':'Within-design descriptive sensitivity only; neither leave-one-case-out nor correlated case ranks supplies heldout evidence.'},
           'cost_scope':{'numeric_saved_receipts_cpu_seconds':allnumeric,'final_reported_cumulative_usage':summary_by_prefix[-1]['cumulative_usage'],
                         'generation_window_seconds_reserved':resource['summed_generation_window_reservation_seconds'],
                         'completion_tokens_configured_maximum':resource['configured_completion_tokens_maximum'],
                         'completion_tokens_per_invocation_configured':resource['configured_completion_tokens_maximum']//60,
                         'configured_budgets_equal_between_arms':True,
                         'P0_P1_32k_vs_P2_64k_context_source':'Parent task context; P2 configured maximum independently checked in RESOURCE_SCOPE.json. No P0/P1 causal reanalysis.',
                         'unknown':['provider billing','provider authenticated usage','physical HTTP attempt count','server outcome/cancellation after client timeout','disconnected historical process CPU/exit','historical shared remaining balance'],
                         'not_added':'Inclusive wait4 already includes child CPU; score-call CPU is a component, not additional CPU. Summed slot wall is not elapsed calendar duration.'},
           'handwritten_control_comparison':{'same_input_same_rules_measured_control_present_in_P2_deliveries':False,'frozen_P2_controls_authorized':resource['controls'],'interpretation':'No BestFit or other handwritten-control measurement identified in this public P2 delivery scope; no claim of improvement over BestFit or algorithmic novelty.'},
           'audit_dependency_review_count':len(review_summaries),'audit_reviews':[{'prefix_end':r['prefix_end'],'file':r['file']} for r in review_summaries],
           'rows':rows}
    OUT.mkdir(exist_ok=True)
    (OUT/'FACTS.json').write_text(json.dumps(facts,ensure_ascii=False,indent=2)+'\n')
    (OUT/'INPUT_DEPENDENCIES.json').write_text(json.dumps({'inputs':DEP,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'read_policy':'Only named public result/generation/summary/audit deliveries and P2 resource scope. No model code loaded or executed; no heldout files or protocol_draft opened.',
        'measurement':{'process_cpu_seconds':time.process_time()-start,'wall_seconds':time.monotonic()-wall}},ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'arms':armfacts,'pair_summary':{k:v for k,v in facts['nominal_pairs'].items() if k!='rows'},'ranking_stability':facts['public_ranking_stability'],
                      'best_gap':facts['best_fitness_difference_EOH_minus_IID'],'failure_counts':facts['all_failure_counts'],'sources':facts['source_identity'],'numeric_cpu':allnumeric},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
