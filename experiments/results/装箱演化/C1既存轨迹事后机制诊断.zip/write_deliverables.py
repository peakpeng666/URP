#!/usr/bin/env python3
"""Create readable report and unexecuted proposal from saved diagnostic JSON only."""
from pathlib import Path
import json, hashlib, statistics, time, resource
P=Path(__file__).parent; start=time.monotonic(); cpu=time.process_time()
s=json.loads((P/'SUMMARY.json').read_text()); seq=json.loads((P/'PER_SEQUENCE_DIAGNOSIS.json').read_text())
base=(P/'EOH_locked_source.txt').read_text()
old='    return np.where(bins == item, s + 1.0, s)\n'
new='    return np.where(bins == item, s + 1.0, np.where(bins - item == 1, s + 0.5, s))\n'
assert base.count(old)==1
patch=base.replace(old,new)
(P/'A1_NEARFIT_ONE_UNEXECUTED_SOURCE.txt').write_text(patch)
(P/'A1_ONE_LINE_PATCH.diff').write_text('--- EOH_locked_source.txt\n+++ A1_NEARFIT_ONE_UNEXECUTED_SOURCE.txt\n@@ -5 +5 @@\n-'+old+'+'+new)
proposal={
 'schema':'A1-single-term-ablation-draft-v1','status':'EXPLORATORY_SCREEN_DRAFT_FOR_INDEPENDENT_REVIEW_NOT_REGISTERED_NOT_EXECUTED',
 'scientific_question':'Does protecting exactly one unit of slack reduce bins relative to the frozen EOH, holding every other score and host rule fixed?',
 'hypothesis_origin':'Post-hoc C1 diagnosis: EOH has more exact fills and less voluntary opening on all20, but more medium (11..45) residual capacity on all20; public retains 743.25 r=1 bins per sequence vs EOH0.05. These observations generate, not confirm, the hypothesis.',
 'one_change':{'old_return':old.strip(),'new_return':new.strip(),'r0':'bitwise source expression unchanged s+1.0','r1':'only add 0.5 to original s','r_ge_2':'identical original s','coefficient':0.5,'tuning_allowed':False,'candidate_source_sha256':hashlib.sha256(patch.encode()).hexdigest(),'candidate_source_execution_so_far':False},
 'why_selective':'A bonus only at residual r=1, preserving probability formula, scale45, shape3, exact-fit branch, all other residual scores, feasibility, candidate input and stable original-index ties. It is not a replacement algorithm or learned policy.',
 'static_priority_argument':'For integer feasible r>=1, the interior Weibull interval mass s is below 0.027 (density bound). Thus r=0 remains first priority (score >1), r=1 becomes second priority (0.5<s<0.527), and all r>=2 rankings remain unchanged. This is an analytic argument, not a candidate score evaluation.',
 'arms':[{'name':'EOH_original','source_sha256':hashlib.sha256(base.encode()).hexdigest()},{'name':'EOH_nearfit_one','source_sha256':hashlib.sha256(patch.encode()).hexdigest()},{'name':'published_EoH','source_sha256':hashlib.sha256((P/'published_EoH_source.txt').read_bytes()).hexdigest()}],
 'new_data':{'independent_sequences':8,'items_per_sequence':1000,'capacity':100,'generator':'Same C1 specification: integer round(clip(45*Weibull(shape=3),1,100)); preserve exact declared generator and rounding implementation, do not approximate it.','new_master_entropy_draws':1,'generation_attempts':1,'seal_before_any_candidate_evaluation':True,'exclude_this_C1_panel':True,'exclude_all_prior_development_and_confirmation_panels':True,'same_order_items_across_arms':True,'no_quality_filtering_or_resampling':True,'execution_order':'For instance i, rotate the three fixed arm names by i mod3; freeze all24 action IDs before execution.','not_yet_generated':True},
 'primary':{'contrast':'EOH_nearfit_one minus EOH_original','metric':'Per-sequence F=ceil(sum(items)/100)/used_bins, then mean of8 exact rational paired differences; higher is better.','independent_unit':'sequence','report':['mean paired F difference','8 per-sequence paired bin differences','total bin savings','wins/ties/losses','all failure counts and complete-pair count'],'uncertainty':{'method':'paired sequence percentile bootstrap','resamples':20000,'fixed_analysis_seed':20261008,'confidence':0.95,'same_indices_reused_for_secondary':True},'interpretation':'Mechanism screening only: report the point estimate and descriptive sequence-bootstrap interval without a confirmatory significance or superiority claim even if the interval excludes0. Only8 sequences and the fixed1000-item horizon provide limited statistical support. A planned5000-item confirmation requires a separately frozen protocol and wholly new data. No p-value, no selective n increase, no changing horizon, no post hoc cutoff or candidate reselection.'},
 'secondary':{'contrast':'EOH_nearfit_one minus published_EoH','status':'descriptive unadjusted, no automatic superiority claim','mechanism_proxies':['r=1 placements and final r=1 bin counts','final capacity in r11..45','full-bin counts','voluntary and forced openings'],'falsification':'If the patch changes the proxy but not F/bin use, do not claim efficiency improved. If primary estimate<=0, predicted benefit is not observed; distinguish this from proof of no effect. If nearfit reward reduces exact fills but reduces bins, this contradicts exact-fill count as a valid standalone objective.'},
 'failure_policy':{'algorithm_contract_or_numeric_failure':'Record exact failure, never convert to0 or use a different candidate. Any such failure blocks the claim that the candidate passed. Full8 primary null unless all8 primary pairs are valid.','infrastructure_missing':'Keep consumed action claim unknown; no imputation, no relaunch under same claim. Any missing primary pair keeps full8 primary null.','public_only_missing':'Full8 public secondary null; primary may be reported only if its own8 pairs are complete.','recovery':'Stop dependent run and require a separately reviewed, pre-score-disclosure amendment with new claim and additional budget; no generic retry.','early_stopping':'No performance-based early stopping or sample extension. Stop on invalid contract, resource cap, unaccounted process/lifecycle break or unverifiable data/source hash.'},
 'proposed_budget':{'currency_or_paid_model_cost':0,'new_provider_calls':0,'CPU_hard_total_seconds':3500,'active_wall_hard_total_seconds':2750,'separate_from_closed_C1_and_this_diagnosis':True,'reservations':{'formal_24_packs':{'CPU':3000,'wall':2232,'per_pack_CPU':125,'per_pack_wall':93},'three_toy_admission_packs':{'CPU':375,'wall':279},'static_checks_and_data_sealing':{'CPU':20,'wall':20},'single_dispatcher':{'CPU':22,'wall':60},'locked_analysis':{'CPU':30,'wall':60},'independent_readonly_audit':{'CPU':30,'wall':30}},'reserved_total':{'CPU':3477,'wall':2681},'unallocated_margin':{'CPU':23,'wall':69},'basis':'Conservative reuse of C1 reviewed complete-tree per-pack reservation 125CPU/93wall. This is a proposed cap, not measured expense or authorization to launch. Reuse the existing reviewed original sandbox and blocking wait4 collection; no new multi-hour scheduler or probe program. Root must confirm the final reviewed execution design and source/hash freeze first. The caps are conservative upper bounds, not runtime predictions for1000-item sequences. If using a changed runtime, establish equivalence and re-register a complete budget before data performance is seen; do not claim these numbers cover arbitrary probes.','no_over_cap_recovery':True},
 'gates_before_execution':['Independent static review of one-line change, priority argument and original baseline hashes.','Freeze protocol, source, host/checker, analysis and complete resource ledger before drawing new research seed.','Verify bounded worker cleanup and complete descendant CPU accounting; no undisclosed process probes.','Generate once and seal8 new sequences before any arm sees their performance.','Execute only after root approves the frozen plan; this draft starts no candidate.'],
 'no_further_proposals':True}
(P/'A1_NEARFIT_ONE_DRAFT.json').write_text(json.dumps(proposal,ensure_ascii=False,indent=2)+'\n')
firsts=[q['first_label_invariant_histogram_difference'] for q in seq]
fullmean={k:statistics.mean(q['endpoints'][k]['residual_bands']['full']['bins']/q['endpoints'][k]['used_bins'] for q in seq) for k in ['EOH','Public']}
cost1=json.loads((P/'execution_history'/'EXECUTION_RECEIPT.json').read_text());cost2=json.loads((P/'EXECUTION_RECEIPT.json').read_text())
report=f'''C1 真实放置结果的事后机制诊断
2026年10月7日 UTC完成；目录后缀20261008是任务标识

结论
EOH在20条序列中每一条都更少主动开箱、留下更多完全装满的箱，但最终总箱数仍然4胜4平12负，合计多30箱。它几乎不留下1单位的小缝，转而把未用容量集中在少数中等余量箱。可检验的改进方向是只提高余量r=1的奖励，同时保持r=0和所有r>=2的评分不变。这个建议来自事后诊断，尚未证明机制因果，也没有启动新候选。

一 证据和原结论
只读C1封包v2的20份原始序列及40份成功终态，重建200000次已保存放置。代码只读文本和AST，没有exec、eval、import候选，没有运行评分函数、求解器或模型。实例、源码、终态均核对封包SHA256；每条assignment哈希及最终remaining数组也一致。
原EOH均值0.9914830290071946，公开式0.9922162104067185。原配对差区间[-0.0015649021094684612,0.0000743535627814167]仍跨0；本报告不重算bootstrap、不报告新显著性。IID严格18/20、技术19/20及两套全20主比较null均不动。

二 真正的行为差别
以下均先按完整序列汇总，再对20条取平均；逐item、逐箱与前缀不是独立统计样本。
EOH / 公开式：
- 最终箱数：2024.80 / 2023.30
- 全满箱数：1958.95 / 1254.35；每序列满箱率的平均：{fullmean['EOH']:.4%} / {fullmean['Public']:.4%}
- 旧箱可放时主动开新箱：1095.65 / 1420.45
- 当时没有旧箱可放而开新箱：929.15 / 602.85
- 最终余量恰为1的箱：0.05 / 743.25
- 最终余量1–10的箱：0.30 / 743.45
- 最终余量11–45的空余容量：1570.30 / 547.00
- 最终总空余容量：1777.25 / 1627.25
EOH更少主动开箱、更多满箱和更多11–45余量容量这三个方向在20/20条上都成立。它的满箱数更好，并不意味着装箱目标更好；公开式容许大量1单位小缝，却在本批次把中等残余积压压得更低。不能将其描述为“EOH过度主动开箱”或“EOH留下更多小碎片”。

严格守恒：每个前缀W=100×已开箱数−已放置物品尺寸总和均已验证。两算法处理相同前缀，所以差W=100×差箱数恒成立。最终150单位/序列差额就是1.5箱/序列，不是第二项独立胜负证据。按余量区间分解EOH−公开式容量差：1–10为−742.70，11–29为+619.65，30–45为+403.65，46–99为−130.60，合计+150。

三 从源码能说什么
记item=x、放置前剩余容量b、放置后余量r=b−x。
EOH：s(r)=exp(−((r−0.5)/45)^3)−exp(−((r+0.5)/45)^3)，r=0额外加1。除是否恰好装满外，排序只看r；形状3、尺度45的单件密度目标固定，连续密度峰约39.3。边界r=0、1受裁剪/离散化影响，不能把所有r都不加限定地称为真实PMF。
公开式：(x+r)/[(exp(r)+0.7)exp(r)] + x√r/(x+r) + 0.3 + 0.5×1[r>3x]。它依赖x和r；近零指数项、当前item相关的利用率/平方根项以及阈值分支共同作用。只看中间项，其随r的峰在r=x，但完整公式还受其他项影响，不能据此声称所有决策都瞄准r=x。
共同host将所有可容纳item的箱（包括未使用空箱）传给评分函数，按原箱序稳定取首个最大值。因此“先用旧箱，旧箱都不行再开新箱”不是本实验的host规则。EOH的描述文字不能覆盖精确源码和真实host行为。

四 首次同状态分歧与完整轨迹
所有20对在第2–15个item就出现标签无关的剩余容量直方图分歧。首次分歧前两方余量多重集合相同，此处可描述两条评分规则确实选择了不同余量；之后两条轨迹的候选状态已经不同，不能把逐item动作差当作同状态反事实。
在首次分歧事件，12对是公开式开新箱而EOH用旧箱，2对相反，6对都用旧箱但选择不同余量。完整每前缀箱数/余量轨迹、每500项完整直方图、每次放置观察和最终每箱装载分布均已导出。
平均EOH额外箱数在500项为4.6、2500项4.5、4500项0.3、5000项1.5。差距并非单调积累，也不是只在结尾突然形成；这些前缀快照不能作为独立重复来缩窄区间。

五 三个固定规则选出的事后代表
规则在计算逐序列诊断前写入计划：按最终EOH−公开箱数差升序，同分按序列ID升序，取第1、第10、第20名。C1成绩已经公开，所以整个选择仍是事后的。
- 最好02，最终−8箱。首次分歧第15项x=26，EOH从余量62放入后留36，公开式从58留32。整条轨迹曾落后14箱、领先11箱；3666/5000个前缀EOH箱数更多，却最终获胜。
- 下中位18，最终+1箱。首次分歧第9项x=6，EOH留16、公开式留10。最终小差额不代表轨迹相同。
- 最差11，最终+13箱。首次分歧第9项x=20，EOH从旧箱60留40，公开式主动开新箱留80。此时EOH少1箱，最后却多13箱；不能把这一个早期动作指定为13箱损失的因果来源。
这些例子用于检查全量统计的机制解释，不构成额外样本，也没有挑换更好看的例子。

六 唯一后续消融草案 A1
只改EOH的一行return：r=0仍返回s+1；r=1返回s+0.5；r>=2仍返回s。保持原概率项、尺度、shape、输入、可行性和tie-break全部相同；不向模型重新生成候选，不选择其他参数。
原r>=1单件质量项小于0.027，所以该修改保持精确满箱第一优先，仅把r=1提升为第二优先。它检验“容忍1单位小缝能否少开总箱”，而不是换一整套启发式。r=1选择增加、满箱数下降却总箱数改善，才符合这个效率方向；若只有代理指标变化而F未改善，就不能说改进成功。
建议三臂固定为原EOH、此补丁和原公开式，在一次生成封存的8条独立新1000项序列上配对比较。固定8条和1000项，不因结果好看改规模；这轮只作机制筛查，样本少且长度不同于C1，即使描述区间不跨0也不作正式胜出或5000项改进结论。禁止重复使用本C1的20条当新确认；后续5000规模确认须另立协议、另抽全新数据。唯一主要筛查比较是补丁−原EOH的平均F差；公开式对比及碎片指标是描述性次要结果。样本数、20000次序列配对bootstrap、固定分析种子、失败定义和资源预算都须先冻结；区间跨0保持不确定，不追加样本追显著。
复用已验证原sandbox及blocking wait4收割，不新造大型调度框架或长时间探针。按原C1完整进程树保守预约口径，24个正式槽共3000CPU秒/2232active-wall秒，3个toy槽375/279，另加封存静态20/20、dispatcher22/60、分析30/60、独审30/30，总预约3477/2681；建议硬帽3500CPU秒/2750active-wall秒。这是保守硬上界，不是1000项序列的运行时间预测，也不是已使用或已授予的预算；最终由root在边界静态审核后分配。更换运行实现需先验证等价并重新锁定完整预算。
算法或基础设施缺失不填0、不重用claim；只要主比较任一配对不完整，全8主要筛查差为null。算法契约失败必须明确报出，不可用另一个候选替换。完整可审草案见A1_NEARFIT_ONE_DRAFT.json，源码仅作为.txt保存且从未执行。

七 文件与成本
- 机制诊断总览.png：20对终点、全部前缀、余量区间和3代表轨迹
- SUMMARY.json、PER_SEQUENCE_DIAGNOSIS.json、paired_sequence_summary.csv：摘要与20对详情
- all_20_prefixes.csv.gz：20×5001条逐前缀记录
- all_200000_observed_placements.csv.gz：两策略的20万条真实放置重建
- all_final_used_bin_loads.csv.gz、CHECKPOINT_RESIDUAL_HISTOGRAMS.json：每箱装载与完整余量直方图
- INPUT_VERIFICATION.json、源码.txt、host片段：哈希与静态证据
- diagnose_saved_assignments.py、run_bounded.py：受60CPU/120wall上限保护的只读复算脚本
诊断首次运行加一次纯算术精度/派生统计修订复算，完整子进程CPU共{cost1['child_wait4_cpu_seconds']+cost2['child_wait4_cpu_seconds']:.6f}秒，外层wall共{cost1['outer_complete_wall_seconds']+cost2['outer_complete_wall_seconds']:.6f}秒，均远小于60/120上限。两次都没有策略评分执行；第一次回执完整保留。准备文本查看和报告写作另列，不冒称已精确计得所有控制面费用；不改已闭账C1预约。原始输入分析前后哈希一致。
'''
(P/'C1机制诊断_中文结论.txt').write_text(report)
(P/'README.txt').write_text('本目录是C1已存raw的事后诊断，不是新的算法运行或确认实验。\n主读：C1机制诊断_中文结论.txt、机制诊断总览.png。\n候选补丁只在A1_NEARFIT_ONE_UNEXECUTED_SOURCE.txt中作为数据保存；禁止把未审草案当执行授权。\n复算需要旧交付包evidence/experiment及其父目录PAYLOAD_MANIFEST.json：\npython diagnose_saved_assignments.py <sealed_experiment_root> <new_output_directory>\n须先将本目录DIAGNOSIS_PLAN.json复制至新的输出目录；不要覆盖旧C1源数据。脚本独立重建保存的assignment，不调用原评分器。\n所有序列ID为00..19；item_position与prefix为1起/0起(空前缀0)，stored_target_bin为原0起箱号。\nCSV中Public即published_EoH；总余量仅包括已经使用的箱。每条序列为唯一统计独立单位。\n来源RAW终态集合、精确源hash、原CI和IID空缺口径均保留。\n')
(P/'REPORT_WRITING_RECEIPT.json').write_text(json.dumps({'CPU_seconds_at_emit':time.process_time()-cpu,'wall_seconds_at_emit':time.monotonic()-start,'scope':'Derived-JSON to text report and unexecuted candidate proposal only; no reconstruction or candidate calls'},indent=2)+'\n')
print('report bytes',len(report.encode()),'candidate draft sha256',proposal['one_change']['candidate_source_sha256'])
