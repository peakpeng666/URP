#!/usr/bin/env python3
"""Package finalized, audited saved-trace diagnosis. Does not evaluate any strategy."""
from pathlib import Path
import hashlib,json,shutil,time,zipfile,resource,signal
P=Path(__file__).parent
AUDIT=Path('/workspace/shared/audit_eoh_trace_diagnosis_20261008')
w=time.monotonic(); c=time.process_time()
resource.setrlimit(resource.RLIMIT_CPU,(15,15)); signal.alarm(30)
assert json.loads((AUDIT/'AUDIT_RESULT.json').read_text())['status']=='PASS'
assert json.loads((AUDIT/'AUDIT_RECEIPT.json').read_text())['inputs_rehashed_unchanged_after_audit']
for q in AUDIT.iterdir():
 if q.is_file():
  d=P/'independent_audit'/q.name;d.parent.mkdir(exist_ok=True);shutil.copyfile(q,d)
zipname='C1机制诊断_完整证据_20261008.zip'
exclude={zipname,'封包回执.json','ARCHIVE_WHITELIST.json','DELIVERY_MANIFEST.json'}
files=[q for q in sorted(P.rglob('*')) if q.is_file() and q.name not in exclude and '.matplotlib' not in q.parts and '__pycache__' not in q.parts]
records={str(q.relative_to(P)):{'bytes':q.stat().st_size,'sha256':hashlib.sha256(q.read_bytes()).hexdigest()} for q in files}
manifest={'schema':'C1-posthoc-diagnosis-delivery-v1','original_C1_budget_unchanged':True,'candidate_solver_model_calls':0,'future_A1_unexecuted':True,'independent_trace_audit':'PASS','future_A1_effect_design_budget_excluded_from_audit':True,'source_evidence':'Exact subset of65 files read from original sealed C1 plus original manifest; no credential/master seed','files':records}
(P/'DELIVERY_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
files.append(P/'DELIVERY_MANIFEST.json')
with zipfile.ZipFile(P/zipname,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=5) as z:
 for q in files: z.write(q,q.relative_to(P))
with zipfile.ZipFile(P/zipname) as z:
 assert z.testzip() is None
 for rel,rec in records.items(): assert hashlib.sha256(z.read(rel)).hexdigest()==rec['sha256']
z=P/zipname
receipt={'schema':'C1-posthoc-diagnosis-packaging-receipt-v1','zip':{'name':zipname,'bytes':z.stat().st_size,'sha256':hashlib.sha256(z.read_bytes()).hexdigest()},'file_count':len(files),'all_entries_crc_and_sha256_verified':True,'independent_trace_audit':'PASS','scope_not_a_new_experiment':True,'A1_source_unexecuted':True,'packaging_CPU_seconds_at_emit':time.process_time()-c,'packaging_wall_seconds_at_emit':time.monotonic()-w,'not_charged_to_closed_C1_budget':True,'analysis_run1_receipt':'execution_history/EXECUTION_RECEIPT.json','analysis_run2_receipt':'EXECUTION_RECEIPT.json','audit_receipt':'independent_audit/AUDIT_RECEIPT.json','cost_note':'Source analysis full-process wait4 CPU8.091156s/wall6.438793s; independent audit2.589862CPU/2.598646wall measured before emission. Text inspection/control-plane not claimed as exact all-in metering.'}
(P/'封包回执.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
whitelist=[]
for kind,q in [('immutable_zip',z),('concise_chinese_report',P/'C1机制诊断_中文结论.txt'),('independent_audit',P/'independent_audit'/'AUDIT_RESULT.json'),('outer_receipt',P/'封包回执.json')]:
 whitelist.append({'kind':kind,'path':str(q),'bytes':q.stat().st_size,'sha256':hashlib.sha256(q.read_bytes()).hexdigest()})
(P/'ARCHIVE_WHITELIST.json').write_text(json.dumps(whitelist,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(whitelist,ensure_ascii=False,indent=2))
