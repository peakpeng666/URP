#!/usr/bin/env python3
import os,sys,time,json,resource,signal
from pathlib import Path
out=Path(__file__).parent
start=time.monotonic(); before=resource.getrusage(resource.RUSAGE_SELF)
pid=os.fork()
if pid==0:
    os.setsid()
    os.execv(sys.executable,[sys.executable,str(out/'diagnose_saved_assignments.py')])
def kill(*args):
    os.killpg(pid,signal.SIGKILL)
signal.signal(signal.SIGALRM,kill); signal.alarm(120)
_,status,ru=os.wait4(pid,0); signal.alarm(0)
after=resource.getrusage(resource.RUSAGE_SELF)
r={'child_pid':pid,'child_exit_code':os.waitstatus_to_exitcode(status),'child_wait4_cpu_seconds':ru.ru_utime+ru.ru_stime,'outer_complete_wall_seconds':time.monotonic()-start,'outer_self_cpu_seconds':after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime,'not_charged_to_C1':True,'scope':'One bounded offline trajectory reconstruction plus plotting; no child candidate/solver/model execution'}
(out/'EXECUTION_RECEIPT.json').write_text(json.dumps(r,indent=2)+'\n'); print(r)
sys.exit(r['child_exit_code'])
