#!/usr/bin/env python3
"""Independent read-only replay of saved assignments. No candidate/solver execution."""
import ast, csv, gzip, hashlib, json, resource, signal, time
from pathlib import Path
from collections import Counter
START=time.monotonic(); CPU=time.process_time()
resource.setrlimit(resource.RLIMIT_CPU,(15,15)); signal.alarm(30)
ROOT=Path('/workspace/shared/c1_prospective_confirmation_final_delivery_20261007_v2/evidence/experiment')
D=Path('/workspace/shared/eoh_public_baseline_gap_diagnosis_20261008')
OUT=Path('/workspace/shared/audit_eoh_trace_diagnosis_20261008')
INPUTS={}; checks=Counter()
def sha(b): return hashlib.sha256(b).hexdigest()
def read(p):
 b=p.read_bytes(); INPUTS[str(p)]={'sha256':sha(b),'bytes':len(b)}; return json.loads(b)
def canon(o): return json.dumps(o,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def ck(test,msg):
 if not test: raise AssertionError(msg)
 checks[msg]+=1
manifest=read(ROOT.parent/'PAYLOAD_MANIFEST.json')['files']
def source(rel):
 p=ROOT/rel; o=read(p); ck(INPUTS[str(p)]['sha256']==manifest['experiment/'+rel]['sha256'],'sealed_source_sha256'); return o
meta=source('DATA_MANIFEST.json'); methods=source('METHODS_FROZEN.json')['methods']
raw=source('RAW_TERMINAL_SET_AFTER_SECOND_HALT.json'); termhash={x['action_id']:x['terminal_sha256'] for x in raw['strict_original']}
summary=read(D/'SUMMARY.json'); detail=read(D/'PER_SEQUENCE_DIAGNOSIS.json'); checkpoints=read(D/'CHECKPOINT_RESIDUAL_HISTOGRAMS.json')
plan=read(D/'DIAGNOSIS_PLAN.json'); static=read(D/'STATIC_SOURCE_ANALYSIS.json')
for m in ['EOH_locked','published_EoH']:
 code=methods[m]['code']; ck(sha(code.encode())==methods[m]['code_sha256'],'source_hash')
 ck(static[m]['ast_dump']==ast.dump(ast.parse(code)),'static_AST_only')
 ck((D/(m+'_source.txt')).read_text()==code,'source_text_copy')
pf=gzip.open(D/'all_20_prefixes.csv.gz','rt'); prefixes=csv.reader(pf); ph=next(prefixes)
ef=gzip.open(D/'all_200000_observed_placements.csv.gz','rt'); events=csv.reader(ef); eh=next(events)
lf=gzip.open(D/'all_final_used_bin_loads.csv.gz','rt'); loads=csv.reader(lf); lh=next(loads)
for f in ['all_20_prefixes.csv.gz','all_200000_observed_placements.csv.gz','all_final_used_bin_loads.csv.gz']:
 b=(D/f).read_bytes(); INPUTS[str(D/f)]={'sha256':sha(b),'bytes':len(b)}
fixed={0,1,2,5,10,100,500,1000,1500,2000,2500,3000,3500,4000,4500,5000}
all_results=[]; labels=[]; firsts=[]; fixed_results=[]; totals={k:Counter() for k in ['EOH','Public']}
def features(h,n,total): return [n,100*n-total,h[0],sum(h[1:11]),sum(r*h[r] for r in range(1,11)),sum(h[30:46])]
for i,mi in enumerate(meta['instances']):
 ck(mi['global_instance_index']==i,'manifest_global_index'); data=source(mi['relative_file']); xs=data['items']
 ck(sha(canon(data))==mi['input_sha256'],'canonical_input_hash'); ck(data['capacity']==100 and len(xs)==5000,'input_shape')
 ar=[]; saved=[]; hs=[[0]*100 for _ in range(2)]; rem=[[100]*5000 for _ in range(2)]; counts=[[0]*5000 for _ in range(2)]; opened=[0,0]; counters=[Counter(),Counter()]
 for j,(m,k) in enumerate(zip(['EOH_locked','published_EoH'],['EOH','Public'])):
  aid=f'confirm_{i:02d}_{m}'; terminal=source('results/'+aid+'.json'); p=terminal['payload']; report=p['original_pack_report']; r=report['result']; w=r['worker']; expectedslot=f'{m}-group{i//5}'
  ck(INPUTS[str(ROOT/('results/'+aid+'.json'))]['sha256']==termhash[aid],'original_terminal_membership')
  ck(terminal['action_id']==aid and terminal['status']=='passed','terminal_action_status')
  ck(p['method']==m and p['global_instance_index']==i and p['input_sha256']==mi['input_sha256'],'payload_identity')
  ck(report['instance_index']==w['instance_index']==i%5,'original_local_index')
  ck(report['binding']['slot_id']==w['registry_binding']['slot_id']==w['source_id']==expectedslot,'original_slot_method_label')
  ck(report['binding']['source_sha256']==w['source_sha256']==p['code_sha256']==methods[m]['code_sha256'],'original_source_binding')
  ck(sha(canon(r['assignment']))==p['checker']['assignment_sha256'] and len(r['assignment'])==5000,'original_assignment_binding')
  labels.append({'global_index':i,'local_index':i%5,'method':m,'slot_id':expectedslot,'action_id':aid})
  ar.append(r['assignment']); saved.append(r)
 total=0; first_a=None; first_h=None; first_o=None; first_before=None
 ck(list(map(int,next(prefixes)))==[i,0,0]+[0]*14,'every_prefix_row')
 ck(checkpoints[i]['sequence']==i and checkpoints[i]['checkpoints'][0]=={'prefix':0,'EOH':[0]*100,'Public':[0]*100},'checkpoint_zero')
 for t,x in enumerate(xs,1):
  pre_same=rem[0]==rem[1] if first_h is None else None
  prehist=list(hs[0]) if first_h is None else None
  if first_a is None and ar[0][t-1]!=ar[1][t-1]: first_a=t
  for j,(m,k) in enumerate(zip(['EOH_locked','published_EoH'],['EOH','Public'])):
   b=ar[j][t-1]; h=hs[j]; before=rem[j][b]; new=(counts[j][b]==0); oldfeasible=sum(h[x:]); exact=h[x] if x<100 else 0; after=before-x
   ck(0<=b<5000 and before>=x,'valid_saved_placement'); ck(new==(before==100),'empty_definition')
   ck(saved[j]['feasible_counts'][t-1]==oldfeasible+5000-opened[j],'saved_feasible_counts')
   row=[str(i),m,str(t),str(x),str(b),str(before),str(after),str(int(new)),str(oldfeasible),str(exact),str(int(new and oldfeasible>0)),str(int(exact>0 and before!=x))]
   ck(next(events)==row,'every_observed_event_row')
   c=counters[j]; c['voluntary_open']+=int(new and oldfeasible>0); c['forced_open']+=int(new and oldfeasible==0); c['declined_existing_exact_fit']+=int(exact>0 and before!=x); c['exact_fit_opportunities']+=int(exact>0); c['exact_fit_placements']+=int(after==0); c['small_1_10_created']+=int(1<=after<=10); c['band_30_45_created']+=int(30<=after<=45); c['existing_bin_placements']+=int(not new); c['chosen_residual_sum']+=after
   if new:
    ck(b==opened[j],'original_bin_order'); opened[j]+=1
   else: h[before]-=1
   h[after]+=1; rem[j][b]=after; counts[j][b]+=1
  total+=x
  if first_h is None and hs[0]!=hs[1]:
   first_h=t; first_before={'sequence':i,'position':t,'item':x,'full_labeled_pre_state_equal':pre_same,'opened_pre_histogram':prehist}
   ck(pre_same,'first_divergence_full_labeled_pre_state_equal')
  if first_o is None and opened[0]!=opened[1]: first_o=t
  # Independent histogram conservation for each full state, not merely updating a residual counter.
  for j in range(2): ck(sum(r*v for r,v in enumerate(hs[j]))==100*opened[j]-total,'every_prefix_conservation')
  expected=[i,t,total]+features(hs[0],opened[0],total)+features(hs[1],opened[1],total)+[opened[0]-opened[1],100*(opened[0]-opened[1])]
  ck(list(map(int,next(prefixes)))==expected,'every_prefix_row')
  if t in fixed: fixed_results.append(dict(zip(ph,expected)))
  if t%500==0: ck(checkpoints[i]['checkpoints'][t//500]=={'prefix':t,'EOH':hs[0],'Public':hs[1]},'every_fixed_checkpoint_histogram')
 q=detail[i]; ck(q['sequence']==i,'diagnosis_sequence_label'); ck(q['first_assignment_difference']['item_position']==first_a,'first_assignment_difference')
 ck(q['first_label_invariant_histogram_difference']['item_position']==first_h,'first_histogram_difference'); ck(q['first_open_bin_count_difference']['item_position']==first_o,'first_open_count_difference')
 ck(q['first_label_invariant_histogram_difference']['common_pre_histogram_opened_bins']==first_before['opened_pre_histogram'],'first_divergence_common_histogram')
 firsts.append(first_before)
 for j,(m,k) in enumerate(zip(['EOH_locked','published_EoH'],['EOH','Public'])):
  ep=q['endpoints'][k]; ck(rem[j]==saved[j]['remaining'],'final_full_remaining_vector'); ck(opened[j]==saved[j]['used_bins']==ep['used_bins'],'final_used_bins'); ck(hs[j]==ep['final_residual_histogram'],'final_histogram'); ck(ep['total_residual']==100*opened[j]-total,'final_residual')
  for name,lo,hi in [('full',0,0),('1_10',1,10),('11_29',11,29),('30_45',30,45),('46_99',46,99)]:
   band={'bins':sum(hs[j][lo:hi+1]),'residual':sum(r*hs[j][r] for r in range(lo,hi+1))}; ck(ep['residual_bands'][name]==band,'every_residual_band')
   for metric,v in band.items(): totals[k][name+'_'+metric]+=v
  for name,v in ep['behavior_counts'].items(): ck(counters[j][name]==v,'every_behavior_count')
  for b in range(opened[j]): ck(next(loads)==list(map(str,[i,m,b,100-rem[j][b],rem[j][b],counts[j][b]])),'every_final_bin_load_row')
  totals[k].update(counters[j]); totals[k]['used_bins']+=opened[j]; totals[k]['total_residual']+=100*opened[j]-total; totals[k]['r1_bins']+=hs[j][1]
 all_results.append({'sequence':i,'extra_bins':opened[0]-opened[1],'EOH_bins':opened[0],'Public_bins':opened[1]})
for f,it in [(pf,prefixes),(ef,events),(lf,loads)]: ck(next(it,None) is None,'no_extra_csv_rows'); f.close()
ordered=sorted(all_results,key=lambda q:(q['extra_bins'],q['sequence'])); representatives={role:ordered[rank-1]['sequence'] for role,rank in [('best',1),('lower_median',10),('worst',20)]}; ck(representatives==summary['representatives'],'posthoc_representative_ranking')
for k in ['EOH','Public']:
 for metric,v in summary['behavior_mean_counts_per_sequence'][k].items(): ck(totals[k][metric]/20==v,'summary_behavior_means')
 for band,vals in summary['final_residual_band_mean_per_sequence'][k].items():
  for metric,v in vals.items(): ck(totals[k][band+'_'+metric]/20==v,'summary_residual_band_means')
 ck(totals[k]['r1_bins']/20==summary['exact_residual_one_mean_bins'][k],'summary_r1_mean')
 ck(totals[k]['forced_open']/20==summary['forced_open_mean_counts'][k],'summary_forced_open_mean')
ck(sum(q['extra_bins'] for q in all_results)==summary['total_extra_bins']==30,'sum_extra_bins')
ck(summary['wins_ties_losses']==[sum(q['extra_bins']<0 for q in all_results),sum(q['extra_bins']==0 for q in all_results),sum(q['extra_bins']>0 for q in all_results)],'paired_win_tie_loss')
ck(summary['first_state_divergence_positions']==[q['position'] for q in firsts],'summary_first_divergences')
# Commit independent evidence, not copies of the author's generated CSVs.
result={'status':'PASS','scope':'Independent integer replay of all original 20 paired sequences; diagnostic artifacts compared exhaustively. Candidate source only read and AST-parsed.','candidate_or_solver_runs':0,'model_calls':0,'source_execution':False,'checks':dict(checks),'means':{k:{a:b/20 for a,b in v.items()} for k,v in totals.items()},'representatives':representatives,'posthoc_ranked_cases':ordered,'first_same_state_divergences':firsts,'label_binding_checks':labels,'input_hashes':INPUTS,'limits':{'CPU_seconds':15,'wall_seconds':30},'cost_at_emit':{'CPU_seconds':time.process_time()-CPU,'wall_seconds':time.monotonic()-START,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},'interpretation':'Descriptive post-hoc diagnosis only. Residual gap is the bin-count identity, not independent confirmation. No ablation was run. Later trajectories are not controlled same-state counterfactuals.'}
(OUT/'AUDIT_RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
with (OUT/'INDEPENDENT_FIXED_PREFIXES.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=ph); w.writeheader(); w.writerows(fixed_results)
print(json.dumps({k:result[k] for k in ['status','checks','means','representatives','cost_at_emit']},ensure_ascii=False,indent=2))
