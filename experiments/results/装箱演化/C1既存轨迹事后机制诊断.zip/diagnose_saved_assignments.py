#!/usr/bin/env python3
"""Read only saved C1 data. Never import/compile/execute a candidate or solver.
Own arithmetic reconstructs stored placements; it makes no placement decisions.
Usage: python diagnose_saved_assignments.py [sealed-experiment-root] [output-dir]
"""
import ast, csv, gzip, hashlib, json, os, resource, signal, statistics, sys, time
from pathlib import Path
from fractions import Fraction
START=time.monotonic(); CPU0=time.process_time()
resource.setrlimit(resource.RLIMIT_CPU,(60,60))
signal.alarm(120)
ROOT=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/workspace/shared/c1_prospective_confirmation_final_delivery_20261007_v2/evidence/experiment')
OUT=Path(sys.argv[2]) if len(sys.argv)>2 else Path(__file__).parent
OUT.mkdir(parents=True,exist_ok=True)
METHODS=['EOH_locked','published_EoH']; SHORT=['EOH','Public']
INPUTS={}
def sha(b): return hashlib.sha256(b).hexdigest()
def canon(d): return json.dumps(d,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def write(name,obj): (OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
manifest=json.loads((ROOT.parent/'PAYLOAD_MANIFEST.json').read_text())['files']
def read(rel):
    b=(ROOT/rel).read_bytes(); h=sha(b)
    assert h==manifest['experiment/'+rel]['sha256'], ('sealed_manifest_mismatch',rel)
    INPUTS[rel]={'sha256':h,'bytes':len(b)}
    return json.loads(b)
def readtext(rel):
    b=(ROOT/rel).read_bytes(); h=sha(b)
    assert h==manifest['experiment/'+rel]['sha256']
    INPUTS[rel]={'sha256':h,'bytes':len(b)}
    return b.decode()
meta=read('DATA_MANIFEST.json'); methods=read('METHODS_FROZEN.json')['methods']
old=read('CONFIRMATION_ANALYSIS_FINAL_STRICT_AND_TECHNICAL.json')
raw=read('RAW_TERMINAL_SET_AFTER_SECOND_HALT.json')
termhash={x['action_id']:x['terminal_sha256'] for x in raw['strict_original']}
assert old['strict_original_100_slots']['primary_EOH_minus_IID'] is None
assert old['technical_completion_sensitivity']['primary_EOH_minus_IID'] is None
static={}
for m in METHODS:
    code=methods[m]['code']; assert sha(code.encode())==methods[m]['code_sha256']
    tree=ast.parse(code) # Static parser only. No compile/eval/exec/import of source.
    static[m]={'source_sha256':sha(code.encode()),'ast_dump':ast.dump(tree),
               'np_calls':sorted({n.func.attr for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=='np'}),
               'code':code}
    (OUT/(m+'_source.txt')).write_text(code)
runner=readtext('frozen_runtime/runner.py')
(OUT/'host_semantics_excerpt.txt').write_text('\n'.join(runner.splitlines()[563:602])+'\n')
write('STATIC_SOURCE_ANALYSIS.json',static)

prefix_file=gzip.open(OUT/'all_20_prefixes.csv.gz','wt',newline='',compresslevel=3)
pw=csv.writer(prefix_file)
pw.writerow(['sequence','prefix_items','cumulative_item_size']+[s+'_'+k for s in SHORT for k in ['open_bins','total_residual','full_bins','small_1_10_bins','small_1_10_capacity','band_30_45_bins']]+['extra_bins_EOH_minus_Public','extra_residual_EOH_minus_Public'])
event_file=gzip.open(OUT/'all_200000_observed_placements.csv.gz','wt',newline='',compresslevel=3)
ew=csv.writer(event_file); ew.writerow(['sequence','method','item_position_1based','item','stored_target_bin','selected_residual_before','selected_residual_after','new_bin','existing_feasible_count','existing_exact_fit_count','voluntary_open','declined_existing_exact_fit'])
load_file=gzip.open(OUT/'all_final_used_bin_loads.csv.gz','wt',newline='',compresslevel=3)
lw=csv.writer(load_file); lw.writerow(['sequence','method','bin_id','load','residual','item_count'])
seqs=[]; paths=[]; histograms=[]; sumgaps=[0]*5001

def features(st):
    h=st['hist']; return [st['opened'],st['residual'],h[0],sum(h[1:11]),sum(r*h[r] for r in range(1,11)),sum(h[30:46])]
def obs(st,x,b):
    h=st['hist']; before=st['rem'][b]; new=(before==100)
    existing_feasible=sum(h[x:]) if x<100 else 0
    existing_exact=h[x] if x<100 else 0
    assert before>=x
    return {'target_bin':b,'residual_before':before,'residual_after':before-x,'opens_new_bin':new,'existing_feasible_count':existing_feasible,'existing_exact_fit_count':existing_exact,'voluntary_open':bool(new and existing_feasible),'declined_existing_exact_fit':bool(existing_exact and before!=x)}
def apply(st,o,x):
    b=o['target_bin']; before=o['residual_before']; after=o['residual_after']; h=st['hist']; c=st['counts']
    if o['opens_new_bin']:
        assert b==st['opened'], 'first opened bins must be sequential under stable original-index tie break'
        st['opened']+=1; st['residual']+=100
    else: h[before]-=1
    h[after]+=1; st['rem'][b]=after; st['item_counts'][b]+=1; st['residual']-=x
    for k in ['voluntary_open','declined_existing_exact_fit']: c[k]+=int(o[k])
    c['exact_fit_opportunities']+=int(o['existing_exact_fit_count']>0)
    c['exact_fit_placements']+=int(after==0)
    c['small_1_10_created']+=int(1<=after<=10)
    c['band_30_45_created']+=int(30<=after<=45)
    c['existing_bin_placements']+=int(not o['opens_new_bin'])
    c['chosen_residual_sum']+=after

for idx in range(20):
    info=meta['instances'][idx]; assert info['global_instance_index']==idx
    inst=read(info['relative_file']); assert INPUTS[info['relative_file']]['sha256']==info['file_sha256']
    assert sha(canon(inst))==info['input_sha256']; items=inst['items']; assert len(items)==5000 and inst['capacity']==100
    assert all(type(x) is int and 1<=x<=100 for x in items)
    arrays=[]; payloads=[]; saved=[]; states=[]
    for m in METHODS:
        aid=f'confirm_{idx:02d}_{m}'; rel=f'results/{aid}.json'; terminal=read(rel)
        assert INPUTS[rel]['sha256']==termhash[aid]
        assert terminal['status']=='passed'; p=terminal['payload']; payloads.append(p)
        assert p['method']==m and p['global_instance_index']==idx and p['input_sha256']==info['input_sha256']
        assert p['code_sha256']==methods[m]['code_sha256']
        r=p['original_pack_report']['result']; saved.append(r); a=r['assignment']; arrays.append(a)
        assert len(a)==5000 and sha(canon(a))==p['checker']['assignment_sha256']
        states.append({'rem':[100]*5000,'hist':[0]*100,'item_counts':[0]*5000,'opened':0,'residual':0,'counts':{k:0 for k in ['voluntary_open','declined_existing_exact_fit','exact_fit_opportunities','exact_fit_placements','small_1_10_created','band_30_45_created','existing_bin_placements','chosen_residual_sum']}})
    first_assignment=None; first_hist=None; first_open=None; cumulative=0; gaps=[0]; checkpoints=[]
    pw.writerow([idx,0,0]+features(states[0])+features(states[1])+[0,0])
    checkpoints.append({'prefix':0,'EOH':[0]*100,'Public':[0]*100})
    for t,x in enumerate(items,1):
        before_same_hist=(states[0]['hist']==states[1]['hist'])
        os_=[obs(states[j],x,arrays[j][t-1]) for j in range(2)]
        common_before_hist=list(states[0]['hist']) if first_hist is None else None
        if first_assignment is None and arrays[0][t-1]!=arrays[1][t-1]:
            first_assignment={'item_position':t,'item':x,'EOH':os_[0],'Public':os_[1],'pre_residual_histograms_equal':before_same_hist}
        for j in range(2):
            o=os_[j]
            assert saved[j]['feasible_counts'][t-1]==o['existing_feasible_count']+5000-states[j]['opened']
            apply(states[j],o,x)
            ew.writerow([idx,METHODS[j],t,x,o['target_bin'],o['residual_before'],o['residual_after'],int(o['opens_new_bin']),o['existing_feasible_count'],o['existing_exact_fit_count'],int(o['voluntary_open']),int(o['declined_existing_exact_fit'])])
        if first_hist is None and states[0]['hist']!=states[1]['hist']:
            assert before_same_hist
            first_hist={'item_position':t,'item':x,'EOH':os_[0],'Public':os_[1],'common_pre_histogram_opened_bins':common_before_hist,'same_state_claim':'Residual multiset equal immediately before this event; candidate scores are not rerun.'}
        gap=states[0]['opened']-states[1]['opened']; gapr=states[0]['residual']-states[1]['residual']
        if first_open is None and gap!=0: first_open={'item_position':t,'extra_bins_EOH_minus_Public':gap}
        cumulative+=x
        assert gapr==100*gap
        for st in states: assert st['residual']==100*st['opened']-cumulative
        pw.writerow([idx,t,cumulative]+features(states[0])+features(states[1])+[gap,gapr])
        gaps.append(gap); sumgaps[t]+=gap
        if t%500==0: checkpoints.append({'prefix':t,'EOH':list(states[0]['hist']),'Public':list(states[1]['hist'])})
    endpoints=[]
    for j,m in enumerate(METHODS):
        st=states[j]; p=payloads[j]
        assert st['rem']==saved[j]['remaining']
        assert st['opened']==p['checker']['used_bins']==saved[j]['used_bins']
        assert st['opened']==sum(st['hist']) and st['residual']==sum(r*c for r,c in enumerate(st['hist']))
        assert sum(st['item_counts'])==5000
        l1=(sum(items)+99)//100; assert l1==p['L1']
        bands={name:{'bins':sum(st['hist'][lo:hi+1]),'residual':sum(r*st['hist'][r] for r in range(lo,hi+1))} for name,lo,hi in [('full',0,0),('1_10',1,10),('11_29',11,29),('30_45',30,45),('46_99',46,99)]}
        ep={'method':m,'used_bins':st['opened'],'L1':l1,'F':float(Fraction(l1,st['opened'])),'total_residual':st['residual'],'mean_load':100-st['residual']/st['opened'],'final_residual_histogram':st['hist'],'residual_bands':bands,'behavior_counts':st['counts']}
        endpoints.append(ep)
        for b in range(st['opened']): lw.writerow([idx,m,b,100-st['rem'][b],st['rem'][b],st['item_counts'][b]])
    seqs.append({'sequence':idx,'item_sum':sum(items),'item_min':min(items),'item_max':max(items),'extra_bins_EOH_minus_Public':gaps[-1],'F_difference':float(Fraction(endpoints[0]['L1'],endpoints[0]['used_bins'])-Fraction(endpoints[1]['L1'],endpoints[1]['used_bins'])),'endpoints':dict(zip(SHORT,endpoints)),'first_assignment_difference':first_assignment,'first_label_invariant_histogram_difference':first_hist,'first_open_bin_count_difference':first_open,'trajectory_summary':{'minimum_extra_bins':min(gaps),'maximum_extra_bins':max(gaps),'prefixes_EOH_fewer_bins':sum(g<0 for g in gaps[1:]),'prefixes_equal_bins':sum(g==0 for g in gaps[1:]),'prefixes_EOH_more_bins':sum(g>0 for g in gaps[1:]),'mean_extra_bins_over_5000_prefixes':statistics.mean(gaps[1:])}})
    paths.append(gaps); histograms.append({'sequence':idx,'checkpoints':checkpoints})
for f in [prefix_file,event_file,load_file]: f.close()
ordered=sorted(seqs,key=lambda s:(s['extra_bins_EOH_minus_Public'],s['sequence']))
reps={role:ordered[rank-1]['sequence'] for role,rank in [('best',1),('lower_median',10),('worst',20)]}
summary={'schema':'posthoc_gap_diagnosis_results_v1','independent_sequences':20,'placements_reconstructed':200000,'candidate_score_evaluations':0,'solver_runs':0,'model_calls':0,'source_execution':False,'original_primary_unchanged_null':True,'representatives':reps,'total_extra_bins':sum(s['extra_bins_EOH_minus_Public'] for s in seqs),'wins_ties_losses':[sum(s['extra_bins_EOH_minus_Public']<0 for s in seqs),sum(s['extra_bins_EOH_minus_Public']==0 for s in seqs),sum(s['extra_bins_EOH_minus_Public']>0 for s in seqs)],'original_descriptive_bootstrap_95pct':old['strict_original_100_slots']['contrasts']['published_EoH']['interval']['lower_upper'],'mean_F':{key:float(sum((Fraction(s['endpoints'][key]['L1'],s['endpoints'][key]['used_bins']) for s in seqs),Fraction(0))/20) for key in SHORT},'behavior_mean_counts_per_sequence':{key:{k:statistics.mean(s['endpoints'][key]['behavior_counts'][k] for s in seqs) for k in states[0]['counts']} for key in SHORT},'final_residual_band_mean_per_sequence':{key:{band:{measure:statistics.mean(s['endpoints'][key]['residual_bands'][band][measure] for s in seqs) for measure in ['bins','residual']} for band in ['full','1_10','11_29','30_45','46_99']} for key in SHORT},'first_state_divergence_positions':[s['first_label_invariant_histogram_difference']['item_position'] for s in seqs],'first_open_count_divergence_positions':[s['first_open_bin_count_difference']['item_position'] for s in seqs],'mean_prefix_extra_bins':{str(t):sumgaps[t]/20 for t in range(0,5001,500)},'interpretation_limits':['All diagnostics post hoc; no new inferential tests.','Items/prefixes/bin loads are dependent within a sequence.','Residual gap is exactly 100 times bin-count gap, not independent evidence.','After first state divergence, behavior differences mix decision rule and induced state.','Twenty complete EOH/Public pairs do not repair IID missingness.']}
summary['exact_residual_one_mean_bins']={key:statistics.mean(s['endpoints'][key]['final_residual_histogram'][1] for s in seqs) for key in SHORT}
summary['forced_open_mean_counts']={key:statistics.mean(s['endpoints'][key]['used_bins']-s['endpoints'][key]['behavior_counts']['voluntary_open'] for s in seqs) for key in SHORT}
summary['paired_direction_counts']={metric:{'EOH_less':sum(getter(s,'EOH')<getter(s,'Public') for s in seqs),'equal':sum(getter(s,'EOH')==getter(s,'Public') for s in seqs),'EOH_more':sum(getter(s,'EOH')>getter(s,'Public') for s in seqs)} for metric,getter in {'voluntary_open':lambda s,k:s['endpoints'][k]['behavior_counts']['voluntary_open'],'full_bins':lambda s,k:s['endpoints'][k]['residual_bands']['full']['bins'],'medium_11_45_residual':lambda s,k:s['endpoints'][k]['residual_bands']['11_29']['residual']+s['endpoints'][k]['residual_bands']['30_45']['residual']}.items()}
assert summary['total_extra_bins']==30 and summary['wins_ties_losses']==[4,4,12]
for key,m in zip(SHORT,METHODS): assert abs(summary['mean_F'][key]-old['strict_original_100_slots']['full20_means'][m]['decimal'])<1e-14
write('SUMMARY.json',summary); write('PER_SEQUENCE_DIAGNOSIS.json',seqs); write('CHECKPOINT_RESIDUAL_HISTOGRAMS.json',histograms)
with (OUT/'paired_sequence_summary.csv').open('w',newline='') as f:
    w=csv.writer(f); w.writerow(['sequence','extra_bins_EOH_minus_Public','EOH_bins','Public_bins','F_difference','first_hist_divergence','first_bin_count_divergence','EOH_voluntary_open','Public_voluntary_open','EOH_small_residual_bins','Public_small_residual_bins','EOH_full_bins','Public_full_bins'])
    for s in seqs:
        a,b=s['endpoints']['EOH'],s['endpoints']['Public']
        w.writerow([s['sequence'],s['extra_bins_EOH_minus_Public'],a['used_bins'],b['used_bins'],s['F_difference'],s['first_label_invariant_histogram_difference']['item_position'],s['first_open_bin_count_difference']['item_position'],a['behavior_counts']['voluntary_open'],b['behavior_counts']['voluntary_open'],a['residual_bands']['1_10']['bins'],b['residual_bands']['1_10']['bins'],a['residual_bands']['full']['bins'],b['residual_bands']['full']['bins']])
write('INPUT_VERIFICATION.json',{'sealed_payload_manifest_sha256':sha((ROOT.parent/'PAYLOAD_MANIFEST.json').read_bytes()),'plan_sha256':sha((OUT/'DIAGNOSIS_PLAN.json').read_bytes()),'inputs':INPUTS,'input_files_verified_again_after_analysis':all(sha((ROOT/rel).read_bytes())==rec['sha256'] for rel,rec in INPUTS.items())})
# Plot only derived measurements. No candidate source evaluation.
os.environ.setdefault('MPLCONFIGDIR',str(OUT/'.matplotlib'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
font=FontProperties(fname='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
plt.rcParams.update({'font.family':font.get_name(),'axes.unicode_minus':False,'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'white'})
# Ensure font available without external fetching.
matplotlib.font_manager.fontManager.addfont('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
fig,axs=plt.subplots(2,2,figsize=(12,8),constrained_layout=True)
ax=axs[0,0]; vals=[s['extra_bins_EOH_minus_Public'] for s in seqs]
ax.bar(range(20),vals,color=['#287c8e' if v<0 else '#bd654f' if v>0 else '#a0a0a0' for v in vals]); ax.axhline(0,c='black',lw=.6); ax.set_xticks(range(20),[f'{i:02d}' for i in range(20)],fontsize=8); ax.set_title('20对最终箱数差：EOH合计多30箱'); ax.set_ylabel('EOH − 公开启发式（箱）'); ax.set_xlabel('序列编号')
ax=axs[0,1]
for g in paths: ax.plot(range(5001),g,color='#899eab',alpha=.28,lw=.6)
ax.plot(range(5001),[x/20 for x in sumgaps],c='#153b53',lw=2,label='20序列平均'); ax.axhline(0,c='black',lw=.6); ax.set_title('箱数差沿前缀变化'); ax.set_xlabel('已放置物品数'); ax.set_ylabel('EOH − 公开启发式（箱）'); ax.legend(frameon=False)
ax=axs[1,0]; bands=['1_10','11_29','30_45','46_99']; x=list(range(4))
for key,col,off in [('EOH','#bd654f',-.18),('Public','#287c8e',.18)]:
    ax.bar([i+off for i in x],[summary['final_residual_band_mean_per_sequence'][key][b]['residual'] for b in bands],width=.36,label='EOH' if key=='EOH' else '公开启发式',color=col)
ax.set_xticks(x,['余量1–10','11–29','30–45','46–99']); ax.set_ylabel('各区间总空余容量 / 序列'); ax.set_title('最终碎片分布（先每序列汇总，再平均）'); ax.legend(frameon=False)
ax=axs[1,1]
for role,col in [('best','#287c8e'),('lower_median','#7b699e'),('worst','#bd654f')]:
    idx=reps[role]; lab={'best':'最好','lower_median':'下中位','worst':'最差'}[role]
    ax.plot(range(5001),paths[idx],lw=1,label=f'{lab} {idx:02d} / 最终{paths[idx][-1]:+d}箱',color=col)
ax.axhline(0,c='black',lw=.6); ax.set_xlabel('已放置物品数'); ax.set_ylabel('EOH − 公开启发式（箱）'); ax.set_title('固定事后规则选出的3条代表轨迹'); ax.legend(frameon=False,fontsize=9)
fig.suptitle('C1 事后机制诊断  |  仅重建已存assignment，不重跑策略',fontsize=16)
fig.savefig(OUT/'机制诊断总览.png',dpi=160); plt.close(fig)
write('ANALYSIS_RECEIPT.json',{'schema':'separate_posthoc_analysis_cost_v1','completed_at_utc':__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),'cpu_seconds_at_emit':time.process_time()-CPU0,'wall_seconds_at_emit':time.monotonic()-START,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'cpu_hard_limit_seconds':60,'wall_alarm_seconds':120,'candidate_or_solver_runs':0,'new_model_calls':0,'not_charged_to_closed_C1_budget':True,'note':'One-process diagnosis including plotting. External wait4 receipt captures exit tail. Preparatory text inspection and report writing/packaging listed separately, not claimed as metered all-in cost.'})
print(json.dumps(summary,ensure_ascii=False,indent=2))
