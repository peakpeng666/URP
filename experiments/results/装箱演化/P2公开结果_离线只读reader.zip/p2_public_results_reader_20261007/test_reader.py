#!/usr/bin/env python3
"""Small offline integration/regression check on COPIES of explicitly listed ZIPs.
Runs only our reader. Never runs code from an input archive.
"""
from __future__ import annotations
import argparse
import ast
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time
import zipfile


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rewrite(source, target, mutate):
    with zipfile.ZipFile(source) as archive:
        files = {n: archive.read(n) for n in archive.namelist()}
    mutate(files)
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, raw in files.items():
            archive.writestr(name, raw)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("zips", nargs="+", type=Path)
    parser.add_argument("--work", type=Path, required=True, help="new temporary test directory, retained for inspection")
    parser.add_argument("--expected-slots", type=int, choices=[55, 60], default=55)
    args = parser.parse_args()
    args.work.mkdir(parents=True, exist_ok=False)
    reader = Path(__file__).with_name("read_p2_public.py")
    ast.parse(reader.read_text(encoding="utf-8"), feature_version=(3, 10))
    originals = [p.resolve(strict=True) for p in args.zips]
    before = {str(p): sha(p) for p in originals}
    copies = []
    inputs = args.work / "inputs"
    inputs.mkdir()
    for source in originals:
        target = inputs / source.name
        if target.exists():
            raise ValueError("Test input basenames must be unique")
        shutil.copyfile(source, target)
        copies.append(target)
    checks = []

    def run(name, paths, expected_code, extras=()):
        out = args.work / name
        start = time.perf_counter()
        result = subprocess.run([sys.executable, "-I", "-B", str(reader), "--out", str(out),
                                 *extras, *map(str, paths)], text=True, capture_output=True, check=False)
        assert result.returncode == expected_code, (name, result.returncode, result.stderr)
        report = json.loads((out / "report.json").read_text(encoding="utf-8")) if (out / "report.json").exists() else None
        checks.append({"test": name, "result": "PASS", "exit_code": result.returncode,
                       "wall_seconds": time.perf_counter() - start,
                       "reader_cost": report["reader_cost_separate_from_science"] if report else None,
                       "available_slots": report["result_slots_available"] if report else None,
                       "detail": result.stderr.strip() if report is None else report["integrity_status"]})
        return out, report

    expected_code = 0 if args.expected_slots == 60 else 2
    out, full = run("integration", copies, expected_code)
    assert full["result_slots_available"] == args.expected_slots
    assert full["integrity_status"] == "pass"
    rows = json.loads((out / "slots_60.json").read_text(encoding="utf-8"))
    assert len(rows) == 60
    assert all(r["fitness"] is None and r["fitness_float"] is None for r in rows if r["evaluation_status"] != "scored")
    assert all(r["numerical_cpu_seconds_no_double_count"] is None for r in rows if r["evidence_status"] == "未齐")
    if args.expected_slots == 55:
        assert full["evaluations"] == {"scored": 39, "admission_rejected": 7, "generation_failure": 9}
        assert full["missing_result_positions"] == [56, 57, 58, 59, 60]
    base = next(p for p in copies if "1_19_delivery" in p.name)
    _, duplicate = run("duplicate_input", [*reversed(copies), base], expected_code)
    assert duplicate["evaluations"] == full["evaluations"]
    assert duplicate["result_slots_available"] == full["result_slots_available"]
    assert len(duplicate["duplicate_inputs_skipped"]) == 1
    gap = next(p for p in copies if "26_31_delta" in p.name)
    _, missing = run("missing_middle", [p for p in copies if p != gap], 2)
    assert missing["result_slots_available"] == args.expected_slots - 6
    assert set(range(26, 32)) <= set(missing["missing_result_positions"])
    assert missing["integrity_status"] == "incomplete_missing_packages"
    run("missing_base", [p for p in copies if p != base], 1)
    damaged = args.work / "corrupt.zip"
    def damage(files):
        name = next(n for n in files if n.endswith("/SUMMARY.json"))
        files[name] += b" "
    rewrite(base, damaged, damage)
    run("hash_corruption", [damaged], 1)
    unsafe = args.work / "unsafe.zip"
    rewrite(base, unsafe, lambda files: files.update({"../escape.json": b"{}"}))
    run("unsafe_path", [unsafe], 1)
    assert not (args.work.parent / "escape.json").exists()
    run("wrong_external_pin", [base], 1, ("--expect-sha256", str(base) + "=" + "0" * 64))
    # Repacking preserves file content, but is not byte-identical to the original ZIP.
    repacked = args.work / "repacked.zip"
    rewrite(base, repacked, lambda files: None)
    assert sha(base) != sha(repacked)
    run("conflicting_duplicate_zip", [base, repacked], 1)
    after = {str(p): sha(p) for p in originals}
    assert before == after, "Original inputs changed"
    result = {"status": "PASS", "python": sys.version.split()[0],
              "python310_syntax_parse": "PASS; not a Python3.10 runtime test",
              "expected_slots": args.expected_slots, "reader_source_sha256": sha(reader),
              "original_zip_sha256_unchanged": before, "checks": checks,
              "candidate_executions": 0, "solver_executions": 0, "LLM_calls": 0,
              "heldout_reads": 0, "note": "All reader tests used explicit ZIP copies. Test wall and reader CPU are tooling costs, separate from science."}
    (args.work / "TEST_RESULTS.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": "PASS", "checks": len(checks), "result": str(args.work / "TEST_RESULTS.json")}))


if __name__ == "__main__":
    main()
