#!/usr/bin/env python3
"""Read only explicitly supplied P2 delivery ZIPs. Python 3.10+, standard library.
No network, extraction, project imports, candidate execution, or directory discovery.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import math
from collections import Counter
from fractions import Fraction
from pathlib import Path, PurePosixPath
import platform
import stat
import sys
import time
import zipfile

VERSION = "1.0"
BASE_ROOT = "p2_public_scoring_1_19_delivery_20261007"
ARMS = ("EOH_TC", "IID_TC")
TOTAL = 60


class InvalidInput(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise InvalidInput(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def safe_name(name):
    parts = name.split("/")
    require(name and not name.startswith("/") and "\\" not in name
            and ":" not in name and all(p not in ("", ".", "..") for p in parts),
            "不安全的 ZIP/manifest 路径: " + repr(name))
    return str(PurePosixPath(name))


def pairs_unique(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "JSON 重复字段: " + key)
        result[key] = value
    return result


def read_json(raw, label):
    try:
        return json.loads(raw.decode("utf-8"), object_pairs_hook=pairs_unique,
                          parse_constant=lambda x: (_ for _ in ()).throw(InvalidInput("非有限 JSON 数字: " + x)))
    except (ValueError, UnicodeError) as exc:
        raise InvalidInput(label + ": " + str(exc)) from exc


def matches(raw, expected, label):
    require(isinstance(expected, dict) and expected.get("bytes") == len(raw)
            and expected.get("sha256") == sha(raw), "SHA/字节数不一致: " + label)


def merge_bytes(target, key, raw, label):
    if key in target:
        require(target[key] == raw, "同一身份出现不同字节: " + label + "/" + key)
        return False
    target[key] = raw
    return True


class Package:
    def __init__(self, path):
        self.path = path
        raw = path.read_bytes()  # Exactly one user-listed input; ZIP references are never opened.
        self.zip_sha256, self.zip_bytes = sha(raw), len(raw)
        self.files = {}
        with zipfile.ZipFile(io.BytesIO(raw), "r") as archive:
            roots = set()
            for info in archive.infolist():
                name = info.filename.rstrip("/") if info.is_dir() else info.filename
                safe_name(name)
                mode = info.external_attr >> 16
                require(not stat.S_ISLNK(mode), "ZIP 不接受符号链接: " + name)
                if info.is_dir():
                    continue
                require("/" in name, "文件须在单一顶层包目录中: " + name)
                root, rel = name.split("/", 1)
                roots.add(root)
                merge_bytes(self.files, rel, archive.read(info), path.name)
            require(len(roots) == 1, "ZIP 须含单一顶层包目录: " + path.name)
            self.root = roots.pop()
        require("FILE_MANIFEST.json" in self.files, "缺 FILE_MANIFEST.json: " + path.name)
        self.manifest_raw = self.files["FILE_MANIFEST.json"]
        self.manifest_sha256 = sha(self.manifest_raw)
        manifest = self.json("FILE_MANIFEST.json")
        refs = manifest["files"]
        require(set(self.files) == set(refs) | {"FILE_MANIFEST.json"},
                "manifest 文件集合不完整或含未列文件: " + self.root)
        for rel, expected in refs.items():
            safe_name(rel)
            matches(self.files[rel], expected, self.root + "/" + rel)
        self.summary = self.json("SUMMARY.json")
        self.end = self.summary.get("cumulative_generation_denominator", self.summary.get("generation_slots_prefix"))
        require(type(self.end) is int and 1 <= self.end <= TOTAL, "无法识别包范围: " + self.root)
        self.state_prefix = "project/public_execution/" if self.root == BASE_ROOT else "state_delta/"
        require(any(k.startswith(self.state_prefix + "results/") for k in self.files),
                "包没有可读的原 result 回执: " + self.root)

    def json(self, key):
        require(key in self.files, self.root_if_ready() + " 缺少 " + key)
        return read_json(self.files[key], self.root_if_ready() + "/" + key)

    def root_if_ready(self):
        return getattr(self, "root", self.path.name)

    def references(self):
        if "CHAIN_REFERENCE.json" in self.files:
            return [(r, "chain_manifests/" + str(r["end"]) + ".json")
                    for r in self.json("CHAIN_REFERENCE.json")["required_previous_packages"]]
        if "BASE_REFERENCE.json" not in self.files:
            require(self.root == BASE_ROOT, "delta 缺链引用: " + self.root)
            return []
        ref = self.json("BASE_REFERENCE.json")
        rows = [({"directory_name": ref["required_base_directory_name"],
                  "zip_sha256": ref["base_zip_sha256"], "manifest_sha256": ref["base_manifest_sha256"]},
                 "BASE_FILE_MANIFEST.json")]
        if "previous_delta_directory_name" in ref:
            rows.append(({"directory_name": ref["previous_delta_directory_name"],
                          "zip_sha256": ref["previous_delta_zip_sha256"],
                          "manifest_sha256": ref["previous_delta_manifest_sha256"]},
                         "PREVIOUS_DELTA_FILE_MANIFEST.json"))
        return rows


def finite_number(value):
    return type(value) in (int, float) and math.isfinite(value)


def measured_sum(values):
    # Null propagates. An explicitly empty set of executed packs has sum zero.
    return sum(values) if all(finite_number(v) for v in values) else None


def ratio(numerator, denominator):
    return {"numerator": numerator, "denominator": denominator,
            "float": numerator / denominator if denominator else None}


def make_row(record, result, generation, panel, origin):
    row = {"position": record["position"], "slot_id": record["slot_id"], "arm": record["arm"],
           "evidence_status": "已齐" if result is not None else "未齐",
           "generation_status_raw": None, "generation_client_state": None,
           "generation_answer_bytes": None, "generation_finish_reasons": None,
           "generation_provider_outcome": None, "generation_provider_usage": None,
           "generation_provider_cost": None, "generation_physical_http_attempts": None,
           "generation_wall_seconds": None, "evaluation_status": None,
           "AST_status": None, "admission_kind": None, "fitness": None,
           "fitness_fraction": None, "fitness_float": None, "used_bins": [None] * 5,
           "case_outcomes": [None] * 5, "score_packs_recorded": None,
           "admission_cpu_seconds": None, "pack_child_cpu_seconds": None,
           "pack_supervisor_self_cpu_seconds": None, "pack_inclusive_wait4_cpu_seconds": None,
           "numerical_cpu_seconds_no_double_count": None, "score_call_cpu_ns": None,
           "cpu_measurement_scope": "missing_result", "failure_reason": None,
           "admission_reason_raw": None, "source_sha256": None, "result_source": origin}
    if generation is not None:
        for dest, src in [("generation_client_state", "client_state"),
                          ("generation_answer_bytes", "answer_bytes"),
                          ("generation_finish_reasons", "finish_reasons"),
                          ("generation_provider_outcome", "provider_outcome"),
                          ("generation_provider_usage", "provider_usage"),
                          ("generation_provider_cost", "provider_cost"),
                          ("generation_physical_http_attempts", "physical_http_attempts"),
                          ("generation_wall_seconds", "wall_seconds")]:
            row[dest] = generation.get(src)
    if result is None:
        return row
    for key in ("position", "slot_id", "arm", "order", "phase"):
        require(result["record"].get(key) == record.get(key), "result/冻结 roster 身份不一致: " + record["slot_id"])
    require(result["slot_id"] == record["slot_id"], "result slot_id 不一致")
    row["generation_status_raw"] = result.get("generation_status")
    row["evaluation_status"] = result.get("evaluation_status")
    row["failure_reason"] = result.get("reason")
    admission = result.get("admission")
    scores = result.get("scores", [])
    require(isinstance(scores, list), "scores 不是列表: " + record["slot_id"])
    row["score_packs_recorded"] = len(scores)
    if admission is None:
        row["AST_status"] = "not_attempted" if result.get("evaluation_status") == "generation_failure" else None
        row["cpu_measurement_scope"] = "no_numeric_execution_recorded" if row["AST_status"] == "not_attempted" else "unknown"
    else:
        admitted = admission.get("admitted")
        row["admission_kind"] = admission.get("kind")
        row["AST_status"] = "admitted" if admitted is True else ("rejected_" + str(admission.get("kind", "unknown")) if admitted is False else None)
        row["admission_reason_raw"] = admission.get("reason")
        row["source_sha256"] = admission.get("source_sha256")
        row["admission_cpu_seconds"] = admission.get("worker", {}).get("cpu_seconds")
        row["cpu_measurement_scope"] = "admission_plus_recorded_packs"
    seen = set()
    for score in scores:
        index = score["instance_index"]
        require(type(index) is int and 0 <= index < 5 and index not in seen, "重复/非法 case index")
        seen.add(index)
        expected = panel[index]
        require(score.get("L1") == expected["L1"] and score.get("input_sha256") == expected["input_sha256"],
                "public case 身份/L1 不一致: " + record["slot_id"])
        require(score.get("code_sha256") == row["source_sha256"], "candidate source SHA 不一致")
        row["used_bins"][index] = score.get("used_bins")
        row["case_outcomes"][index] = score.get("outcome")
    if admission is not None:
        row["pack_child_cpu_seconds"] = measured_sum([s.get("evidence", {}).get("worker", {}).get("cpu_seconds") for s in scores])
        row["pack_supervisor_self_cpu_seconds"] = measured_sum([s.get("evidence", {}).get("supervisor", {}).get("actual_supervisor_cpu_seconds") for s in scores])
        row["pack_inclusive_wait4_cpu_seconds"] = measured_sum([s.get("evidence", {}).get("supervisor", {}).get("wait4_cpu_seconds") for s in scores])
        row["score_call_cpu_ns"] = measured_sum([s.get("evidence", {}).get("worker", {}).get("score_call_cpu_ns") for s in scores])
        row["numerical_cpu_seconds_no_double_count"] = measured_sum([
            row["admission_cpu_seconds"], row["pack_child_cpu_seconds"], row["pack_supervisor_self_cpu_seconds"]])
    fitness = result.get("fitness")
    if fitness is not None:
        require(len(scores) == 5 and seen == set(range(5)) and all(
            s.get("outcome") == "ok" and s.get("evidence", {}).get("checker_status") == "passed"
            and type(s.get("used_bins")) is int and s["used_bins"] > 0 for s in scores),
            "完整 fitness 缺少五份通过的原回执: " + record["slot_id"])
        exact = sum((Fraction(s["L1"], s["used_bins"]) for s in scores), Fraction()) / 5
        require(type(fitness.get("numerator")) is int and type(fitness.get("denominator")) is int
                and fitness["numerator"] == exact.numerator and fitness["denominator"] == exact.denominator,
                "精确 fitness 不一致: " + record["slot_id"])
        require(row["evaluation_status"] == "scored", "有 fitness 但状态不是 scored")
        row.update(fitness=fitness, fitness_fraction=str(exact), fitness_float=float(exact))
    else:
        require(row["evaluation_status"] != "scored", "scored 的 fitness 为 null")
    return row


def summarize_arm(arm, rows):
    xs = [r for r in rows if r["arm"] == arm]
    available = [r for r in xs if r["evidence_status"] == "已齐"]
    complete = sum(r["fitness"] is not None for r in available)
    admissions = sum(r["AST_status"] not in (None, "not_attempted") for r in available)
    rejects = sum(r["AST_status"] == "rejected_static" for r in available)
    gen_failures = sum(r["evaluation_status"] == "generation_failure" for r in available)
    known_cpu = [r["numerical_cpu_seconds_no_double_count"] for r in available if r["numerical_cpu_seconds_no_double_count"] is not None]
    not_run = sum(r["cpu_measurement_scope"] == "no_numeric_execution_recorded" for r in available)
    return {"arm": arm, "planned_generation_denominator": len(xs), "result_slots_available": len(available),
            "missing_result_slots": len(xs) - len(available), "generation_failures": gen_failures,
            "actual_admissions": admissions, "AST_static_rejections": rejects, "complete_fitness": complete,
            "known_noncomplete_fitness": len(available) - complete,
            "evaluation_status_counts": dict(Counter(r["evaluation_status"] for r in available)),
            "fitness_coverage_full30": ratio(complete, len(xs)),
            "fitness_coverage_available": ratio(complete, len(available)),
            "generation_failure_rate_full30": ratio(gen_failures, len(xs)),
            "AST_static_rejection_rate_full30": ratio(rejects, len(xs)),
            "AST_static_rejection_rate_admissions": ratio(rejects, admissions),
            "public_case_packs_recorded": sum(r["score_packs_recorded"] for r in available),
            "public_case_planned_denominator": len(xs) * 5,
            "numerical_cpu_known_sum_seconds": sum(known_cpu) if known_cpu else None,
            "cpu_known_measurement_slots": len(known_cpu), "cpu_no_numeric_execution_recorded_slots": not_run,
            "cpu_unknown_measurement_slots": len(available) - len(known_cpu) - not_run,
            "interpretation": "固定 public 设计集的描述性覆盖率；失败保留在30槽分母中；缺包仍未齐；不是 heldout、泛化或跨臂胜负结论。"}


def collect(paths, expected_hashes):
    packages, duplicates = {}, []
    for path in paths:
        package = Package(path)
        if str(path) in expected_hashes:
            require(package.zip_sha256 == expected_hashes[str(path)], "外部指定 ZIP SHA 不一致: " + path.name)
        if package.root in packages:
            require(package.zip_sha256 == packages[package.root].zip_sha256,
                    "重复包身份的 ZIP 字节不同: " + package.root)
            duplicates.append({"input_path": str(path), "root": package.root, "action": "byte_identical_skip"})
        else:
            packages[package.root] = package
    require(BASE_ROOT in packages, "必须显式提供1–19基础ZIP，以读取完整60槽冻结roster和public case身份。")
    ordered = sorted(packages.values(), key=lambda p: p.end)
    missing_references, checked_references = [], []
    for package in ordered:
        for ref, copy_key in package.references():
            root = ref["directory_name"]
            safe_name(root)
            require(copy_key in package.files and sha(package.files[copy_key]) == ref["manifest_sha256"],
                    "包内前序 manifest 副本不符: " + package.root + "/" + copy_key)
            prior = packages.get(root)
            if prior is None:
                missing_references.append({"from": package.root, "missing": root,
                                           "expected_zip_sha256": ref["zip_sha256"]})
                continue
            require(prior.end < package.end and prior.zip_sha256 == ref["zip_sha256"]
                    and prior.manifest_sha256 == ref["manifest_sha256"]
                    and prior.manifest_raw == package.files[copy_key], "链式引用不一致: " + root)
            checked_references.append({"from": package.root, "to": root})
    state, state_origins, ledger = {}, {}, {}
    duplicate_state = 0
    for package in ordered:
        for rel, raw in package.files.items():
            if rel.startswith(package.state_prefix):
                key = rel[len(package.state_prefix):]
                if merge_bytes(state, key, raw, package.root):
                    state_origins[key] = {"package": package.root, "member": rel, "sha256": sha(raw)}
                else:
                    duplicate_state += 1
            if rel.startswith("generation_sources/ledger/"):
                merge_bytes(ledger, rel[len("generation_sources/ledger/"):], raw, package.root)
    missing_state = []
    for package in ordered:
        if "CUMULATIVE_STATE_FILE_HASHES.json" in package.files:
            for key, expected in package.json("CUMULATIVE_STATE_FILE_HASHES.json")["files"].items():
                safe_name(key)
                if key not in state:
                    missing_state.append({"package": package.root, "member": key})
                else:
                    matches(state[key], expected, package.root + " cumulative/" + key)
    base = packages[BASE_ROOT]
    frozen = base.json("generation_sources/executor/frozen_inputs.json")
    roster = frozen["roster"]["records"]
    require(len(roster) == TOTAL and sorted(r["position"] for r in roster) == list(range(1, TOTAL + 1))
            and len({r["slot_id"] for r in roster}) == TOTAL
            and Counter(r["arm"] for r in roster) == Counter({a: 30 for a in ARMS}), "冻结roster不是60槽/每臂30")
    plan = base.json("project/frozen_metadata/SOURCE_INPUT_PLAN.json")
    panel = sorted(plan["design_panel"]["instances"], key=lambda x: x["instance_index"])
    require([p["instance_index"] for p in panel] == list(range(5)), "public设计case不是5个")
    design_key = "project/frozen_public/design_5000.json"
    require(sha(base.files[design_key]) == plan["design_file_sha256"], "public设计源hash不一致")
    raw_results = {key[8:-5]: read_json(raw, key) for key, raw in state.items()
                   if key.startswith("results/") and key.endswith(".json") and key.count("/") == 1}
    require(set(raw_results) <= {r["slot_id"] for r in roster}, "出现roster以外result")
    rows = []
    for record in sorted(roster, key=lambda x: x["position"]):
        sid = record["slot_id"]
        result = raw_results.get(sid)
        generation = None
        if sid + "/result.json" in ledger:
            generation = read_json(ledger[sid + "/result.json"], sid + " generation result")
            require(generation.get("slot_id") == sid and generation.get("position") == record["position"], "generation身份不一致")
            answer = ledger.get(sid + "/answer.txt")
            require(answer is not None and generation.get("answer_sha256") == sha(answer)
                    and generation.get("answer_bytes") == len(answer), "公开capture answer字节/SHA不符: " + sid)
        if result is not None:
            require(generation is not None, "原result缺配套generation result: " + sid)
        rows.append(make_row(record, result, generation, panel, state_origins.get("results/" + sid + ".json")))
    by_slot = {r["slot_id"]: r for r in rows}
    for package in ordered:
        exact_key = "EXACT_FITNESS_ROWS.json" if package.root == BASE_ROOT else "CUMULATIVE_EXACT_FITNESS_ROWS.json"
        exact_rows = package.json(exact_key)
        require(len(exact_rows) == package.end and sorted(r["position"] for r in exact_rows) == list(range(1, package.end + 1)), "累计fitness表范围错误")
        for exact in exact_rows:
            row = by_slot.get(exact["slot_id"])
            require(row is not None and row["position"] == exact["position"] and row["arm"] == exact["arm"], "累计表身份错误")
            if row["evidence_status"] == "未齐":
                continue  # A cumulative summary never creates a capture/result.
            result = raw_results[row["slot_id"]]
            require(exact["fitness"] == row["fitness"] and exact.get("evaluation_status", exact.get("status")) == row["evaluation_status"]
                    and exact["used_bins"] == [s.get("used_bins") for s in result.get("scores", [])], "累计fitness表与原result不一致")
    latest = ordered[-1]
    arms = [summarize_arm(a, rows) for a in ARMS]
    present = [r for r in rows if r["evidence_status"] == "已齐"]
    prefix_complete = [r["position"] for r in present] == list(range(1, latest.end + 1))
    if prefix_complete:
        claimed = latest.summary.get("cumulative_counts", latest.summary.get("counts"))
        require(dict(Counter(r["evaluation_status"] for r in present)) == claimed, "源SUMMARY计数不符")
        for arm in arms:
            original = latest.summary["arms"][arm["arm"]]
            for key, names in [("result_slots_available", ("generation_denominator_prefix", "generation_slots_in_prefix")),
                               ("complete_fitness", ("complete_fitness", "fitness_complete")),
                               ("generation_failures", ("generation_failures", "generation_failure")),
                               ("actual_admissions", ("actual_admissions",)),
                               ("AST_static_rejections", ("AST_rejections", "AST_static_failure"))]:
                require(arm[key] == next(original[n] for n in names if n in original), "源SUMMARY分臂计数不符")
        usage = latest.summary.get("cumulative_usage", latest.summary.get("usage"))
        cpu = measured_sum([r["numerical_cpu_seconds_no_double_count"] for r in present if r["AST_status"] not in (None, "not_attempted")])
        require(cpu is not None and abs(cpu - usage["numerical_cpu_seconds_no_double_count"]) < 1e-6, "源SUMMARY数值CPU不符")
    report = {
        "reader_version": VERSION, "scope": "offline_readonly_public_design_metrics",
        "integrity_status": "pass" if not missing_references and not missing_state else "incomplete_missing_packages",
        "complete60": len(present) == TOTAL and not missing_references and not missing_state,
        "planned_slots": TOTAL, "result_slots_available": len(present),
        "missing_result_positions": [r["position"] for r in rows if r["evidence_status"] == "未齐"],
        "evaluations": dict(Counter(r["evaluation_status"] for r in present)),
        "packages": [{"input_path": str(p.path), "root": p.root, "end": p.end,
                      "zip_bytes": p.zip_bytes, "zip_sha256": p.zip_sha256,
                      "manifest_sha256": p.manifest_sha256, "files_verified": len(p.files) - 1,
                      "externally_pinned": str(p.path) in expected_hashes} for p in ordered],
        "duplicate_inputs_skipped": duplicates, "byte_identical_duplicate_state_files_skipped": duplicate_state,
        "chain_references_checked": checked_references, "missing_chain_references": missing_references,
        "missing_cumulative_state_files": missing_state,
        "state_files_unique": len(state), "source_summary_prefix_crosschecked": prefix_complete,
        "source_summary_raw": latest.summary,
        "source_reported_best_public_design_raw": latest.summary.get("best_public_design_candidate", latest.summary.get("best_design_candidate")),
        "best_public_design_note": "仅原样展示源SUMMARY已有描述性字段；reader不选择候选、不排序、不宣布赢家。仅固定public设计集，无heldout。",
        "fitness_formula": "sum(Fraction(L1_i, used_bins_i) for i in range(5)) / 5",
        "formula_source": {"package": BASE_ROOT, "member": "verify_delivery_snapshot.py",
                           "sha256": sha(base.files["verify_delivery_snapshot.py"])},
        "public_design_source_sha256": plan["design_file_sha256"],
        "roster_source_sha256": sha(base.files["generation_sources/executor/frozen_inputs.json"]),
        "scientific_cpu_note": "admission.worker.cpu + sum(pack.worker.cpu + pack.supervisor.actual_supervisor_cpu)。inclusive wait4与score_call计时均不再次相加；不含未知provider成本和本reader CPU。",
        "limits": ["SHA校验是给定字节与链内引用的一致性检查，不是签名或防特权替换证明。最后包若无外部SHA pin则仅验证内部一致性。",
                   "只整理保存的回执与做精确算术；不复现provider生成或原硬件运行，不重新验证完整assignment。",
                   "仅读取命令行列出的ZIP；包内绝对路径、脚本、STATUS快照均不作执行或外部读文件入口。",
                   "缺包不从累计表补造capture/结果；unknown/null保留。没有进行候选、solver、LLM或heldout执行。"]}
    return rows, arms, report


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def cell(value):
    if value is None:
        return "null"
    if isinstance(value, (dict, list, bool)):
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
    text = str(value)
    # Spreadsheet-only escaping; authoritative JSON retains the exact string.
    return "'" + text if text.startswith(("=", "+", "-", "@", "\t", "\r")) else text


def write_csv(path, rows):
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows({k: cell(v) for k, v in row.items()} for row in rows)


def main(argv=None):
    parser = argparse.ArgumentParser(description="只读核验明确指定的P2 ZIP，输出60槽JSON/CSV；不执行任何包中代码。")
    parser.add_argument("zips", nargs="+", type=Path, help="明确列出的基础/增量ZIP路径；不自动找邻近文件")
    parser.add_argument("--out", required=True, type=Path, help="新建独立输出目录；已存在则拒绝")
    parser.add_argument("--expect-sha256", action="append", default=[], metavar="ZIP_PATH=SHA256", help="可选外部可信ZIP SHA；可重复")
    args = parser.parse_args(argv)
    started_cpu, started_wall = time.process_time(), time.perf_counter()
    try:
        require(not args.out.exists() and not args.out.is_symlink(), "输出目录已存在；请选择全新目录，防止覆盖。")
        paths = [p.resolve(strict=True) for p in args.zips]
        out = args.out.resolve()
        require(all(p != out and out not in p.parents for p in paths), "输出目录须独立于输入ZIP")
        expected = {}
        for spec in args.expect_sha256:
            path_text, sep, digest = spec.rpartition("=")
            require(sep and len(digest) == 64 and all(c in "0123456789abcdefABCDEF" for c in digest), "外部SHA格式须为ZIP_PATH=64位HEX")
            path = str(Path(path_text).resolve(strict=True))
            require(path in {str(p) for p in paths}, "外部SHA所指ZIP未在输入列表中")
            require(path not in expected or expected[path] == digest.lower(), "外部SHA声明冲突")
            expected[path] = digest.lower()
        rows, arms, report = collect(paths, expected)
        out.mkdir(parents=True, exist_ok=False)
        write_json(out / "slots_60.json", rows)
        flat = []
        for row in rows:
            item = dict(row)
            for index, bins in enumerate(row["used_bins"]):
                item["case_" + str(index) + "_used_bins"] = bins
            flat.append(item)
        write_csv(out / "slots_60.csv", flat)
        write_json(out / "arms.json", arms)
        write_csv(out / "arms.csv", arms)
        report["reader_cost_separate_from_science"] = {
            "python": platform.python_version(), "process_cpu_seconds": time.process_time() - started_cpu,
            "wall_seconds": time.perf_counter() - started_wall,
            "scope": "本reader读取、核验与前四份表写出；不含report/说明最后写出，不计入科学CPU。"}
        write_json(out / "report.json", report)
        note = ("P2公开设计集只读结果整理\n"
                + "已有原result: " + str(report["result_slots_available"]) + "/60；完整fitness: " + str(report["evaluations"].get("scored", 0)) + "。\n"
                + "未齐槽: " + json.dumps(report["missing_result_positions"]) + "。完整60槽=" + str(report["complete60"]) + "。\n"
                + "文件字节/SHA通过；链状态=" + report["integrity_status"] + "。\n"
                + "先看slots_60.csv与arms.csv；null不是0。准确原字段与分数以JSON为准。\n"
                + "公开设计集覆盖率仅描述性。源报告best-design字段原样保留在report.json；本工具不选赢家、不排名，无heldout结论。\n"
                + "数值CPU来自原回执；reader成本另列。未重跑候选、solver、LLM或硬件实验。\n")
        (out / "说明.txt").write_text(note, encoding="utf-8")
        print(note, end="")
        print("输出: " + str(out))
        return 0 if report["complete60"] else 2
    except (InvalidInput, OSError, zipfile.BadZipFile, KeyError, TypeError) as exc:
        print("核验失败: " + str(exc), file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
