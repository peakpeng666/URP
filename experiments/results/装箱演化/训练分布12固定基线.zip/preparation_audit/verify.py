from pathlib import Path
import json,hashlib,ast,math
R=Path('/workspace/shared/bpp_training_distribution_baselines_20261008');O=Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
canon=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
digest=lambda x:sha(canon(x).encode())
read=lambda n:json.loads((R/n).read_text())
checks=[]
def check(name,condition,details=None):
 checks.append({'check':name,'status':'PASS' if condition else 'FAIL','details':details})
def collect(z):
 out=set()
 if isinstance(z,dict):
  for k,v in z.items():
   if k=='items_sha256' and isinstance(v,str):out.add(v)
   elif k in ['hashes','prior_1000_prefix_sha256','prior_5000_items_sha256'] and isinstance(v,list):out.update(v)
   else:out.update(collect(v))
 elif isinstance(z,list):
  for v in z:out.update(collect(v))
 return out
seal=read('PREPARATION_SEAL.json');sealh=sha((R/'PREPARATION_SEAL.json').read_bytes());check('exact_parent_seal',sealh=='c35f83aaaf2da5d29624072c2bb442fc871475890292780859fc3ed6b88c6538',sealh)
mis=[n for n,h in seal['files'].items() if sha((R/n).read_bytes())!=h];check('all_sealed_file_hashes',not mis,{'count':len(seal['files']),'mismatches':mis})
plan=read('PLAN.json');methods=read('METHODS.json');sf=read('SOURCE_FREEZE.json');proto=read('sources/protocol_v2.json');inputs=read('INPUT_MANIFEST.json');inv=read('PRIOR_HASH_INVENTORY.json')
check('source_freeze',all(sha((R/n).read_bytes())==h for n,h in sf['files'].items()),{'count':len(sf['files'])})
known=set(inv['items_sha256']);derived=set()
for x in (R/'sources').glob('prior_*.json'):derived.update(collect(json.loads(x.read_text())))
check('known_exclusion_inventory',len(known)==112 and len(inv['items_sha256'])==112 and derived<=known,{'unique_inventory_hashes':112,'reconstructed_from_eight_metadata_sources':len(derived),'additional_precheck_item_hashes':len(known-derived),'scope':inv['scope'],'two_precheck_array_contents_not_reopened':True})
sourceproof=[]
for s in inv['sources']:
 z=Path(s['path']);h=sha(z.read_bytes());sourceproof.append({'path':s['path'],'expected_sha256':s['sha256'],'actual_sha256':h,'matches':h==s['sha256']})
check('old_source_provenance_byte_hashes',all(s['matches'] for s in sourceproof),{'count':len(sourceproof),'content_not_output_or_performance_inspected':True})
check('six_fixed_sequences',set(e['sequence'] for e in inputs['entries'])=={'W1','W2','W3','W4','U1','U2'} and len(inputs['entries'])==6)
newhashes=[]
for e in inputs['entries']:
 b=(R/'inputs'/f"{e['sequence']}.json").read_bytes();d=json.loads(b);h=digest(d['items']);newhashes.append(h)
 check('input_'+e['sequence'],sha(b)==e['file_sha256'] and digest(d)==e['input_sha256'] and h==e['items_sha256'] and len(d['items'])==1000 and d['capacity']==100 and all(type(x)is int and 1<=x<=100 for x in d['items']) and h not in known,{'items_sha256':h,'n':len(d['items']),'overlap_with_known':h in known})
check('new_inputs_unique',len(set(newhashes))==6)
gensource=(R/'prepare_data.py').read_text();tree=ast.parse(gensource)
urd=[n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=='os' and n.func.attr=='urandom']
check('once_only_entropy_and_no_filter_static',len(urd)==1 and ast.literal_eval(urd[0].args[0])==32 and gensource.index("put('ENTROPY_DRAW_CLAIM.json'")<gensource.index('master=os.urandom(32)') and "raise AssertionError('exact duplicate; halt without replacement')" in gensource and 'np.round(np.clip(45*g.weibull(3,size=1000),1,100)).astype(np.int64)' in gensource and 'g.integers(1,101,size=1000,dtype=np.int64)' in gensource,{'basis':'source inspection plus exclusive/fsynced claims; no generator rerun'})
check('pre_entropy_freeze_binding',read('ENTROPY_DRAW_CLAIM.json')['analysis_sha256']==sha((R/'analyze.py').read_bytes()) and read('ENTROPY_DRAW_CLAIM.json')['exclusion_sha256']==sha((R/'PRIOR_HASH_INVENTORY.json').read_bytes()) and read('DATA_CLAIM.json')['source_freeze_sha256']==sha((R/'SOURCE_FREEZE.json').read_bytes()))
conf=read('CONFIRMATION_SEED_COMMITMENTS.json');check('confirmation_seed_only',len(conf['entries'])==8 and len(set(x['seed_commitment'] for x in conf['entries']))==8 and conf['data_materialized'] is False and conf['raw_array_hashes'] is None and conf['performance_read'] is False and set(x.name for x in (R/'inputs').iterdir())=={f'{x}.json' for x in ['W1','W2','W3','W4','U1','U2']},{'future_raw_arrays_read_or_generated':False,'seed_custody_file_only_hashed_not_parsed':True})
for name,m in methods['methods'].items():check('fixed_source_'+name,sha(m['code'].encode())==m['code_sha256']==proto['controls'][name]['code_sha256'])
rt=Path(plan['runtime']);wf=json.loads((rt/'worker_freeze.json').read_text());rtmis=[n for n,h in wf['files'].items() if sha((rt/n).read_bytes())!=h]
check('current_runtime_source_unchanged',sha((rt/'worker_freeze.json').read_bytes())==plan['worker_freeze_sha256'] and not rtmis,{'runtime_files':len(wf['files']),'mismatches':rtmis,'995_dependency_checks':'preparation receipt, not repeated'})
check('score_ABI',proto['contract']['function']=='score(item, bins)' and all('def score(item, bins):' in m['code'] for m in methods['methods'].values()))
contract=read('STATIC_CONTRACT.json')['rows'];science=[x['id'] for x in plan['packs']]
check('twelve_independent_index_zero',len(science)==12 and len(set(science))==12 and all(x['index']==0 for x in plan['packs']) and len({x['claim_id'] for x in contract})==12 and all(x['claim_id']==digest([plan['id'],x['action_id']]) and x['execution_id']==x['claim_id']+'/instance/0' and x['instance_index']==0 for x in contract))
prep=['prepare','admission_BF','admission_published_EoH','toy_BF','toy_published_EoH'];receipts=[];interfaces=[]
for a in prep:
 c=read('claims/'+a+'.json');t=read('results/'+a+'.json');raw=(R/f'payload_{a}.json').read_bytes();p=json.loads(raw);rr=t['resources'];receipts.append(t)
 check('terminal_'+a,t['status']=='passed' and t['claim_sha256']==digest(c) and t['payload_sha256']==sha(raw) and rr['driver_exit_code']==0 and rr['driver_reaped'] is True and rr['driver_wait4_inclusive_CPU']>0 and rr['whole_tree_CPU_conservative_upper']<=c['CPU_reserve'] and rr['wall_at_emit']<=c['wall_reserve'])
 if a.startswith('admission_'):
  w=p['worker'];ok=p['admission']['admitted'] and w['source_after_host_gate'] and w['source_sent'] and w['reaped'] and w['returncode']==0 and w['cleanup_error'] is None
  check('host_gate_'+a,ok);interfaces.append({'action_id':a,'admitted':p['admission']['admitted'],'source_after_host_gate':w['source_after_host_gate'],'worker_wait4_CPU':w['cpu_seconds']})
 if a.startswith('toy_'):
  rep=p['original_pack_report'];b=rep['binding'];w=rep['worker'];su=rep['supervisor_evidence'];ok=rep['instance_index']==0 and rep['execution_id']==b['claim_id']+'/instance/0' and b['claim_id']==digest([plan['id'],a]) and p['checker']['checker_status']=='passed' and w['source_after_host_gate'] and all(e['reaped'] and e['returncode']==0 and e['cleanup_error'] is None for e in [w,su]) and rep['worker']['admission']['canonical_text']==read('payload_admission_'+p['method']+'.json')['admission']['canonical_text']
  check('toy_contract_'+a,ok);interfaces.append({'action_id':a,'checker':'passed','source_after_host_gate':w['source_after_host_gate'],'worker_wait4_CPU':w['cpu_seconds'],'supervisor_inclusive_wait4_CPU':su['wait4_cpu_seconds'],'inclusive_driver_wait4_CPU':rr['driver_wait4_inclusive_CPU'],'nested_CPU_not_added_again':True})
check('scientific_zero_model_zero',sorted(x.stem for x in (R/'claims').glob('*.json'))==sorted(prep) and all(not read('claims/'+a+'.json')['scientific'] for a in prep) and not (R/'EXECUTION_AUTHORIZATION.json').exists() and read('PREPARATION_REPORT.json')['model_API_calls']==0 and not any((R/f'payload_{a}.json').exists() for a in science))
g=(R/'guard.py').read_text();check('root_exact_release_gate',all(s in g for s in ["auth.get('scientific_execution_authorized') is True","auth['seal_sha256']==sha((R/'PREPARATION_SEAL.json').read_bytes())","auth['allowed_scientific_ids']==science","auth['source_freeze_sha256']==sha((R/'SOURCE_FREEZE.json').read_bytes())"]),{'root_authorization_file_must_be_written_only_after_external_root_approval':True,'authorization_not_created_by_auditor':True})
b=plan['budget'];cpu=sum(v['CPU'] for v in b['reservations'].values());wall=sum(v['wall'] for v in b['reservations'].values());check('all_in_budget',cpu==1840<1900 and wall==1570<1700 and b['no_unknown_refund'] is True and b['reservations']['independent_review']=={'CPU':60,'wall':60},{'CPU':cpu,'active_wall':wall,'control_plane':b['reservations']['control_plane'],'analysis_and_package':b['reservations']['analysis_and_package'],'preparation_audit_full_debit':{'CPU':30,'wall':30},'reserved_for_later_result_audit':{'CPU':30,'wall':30}})
a=(R/'analyze.py').read_text();check('future_analysis_static',all(s in a for s in ['from fractions import Fraction','q=Fraction(lower,used)',"'no_p_values':True","'public training feedback only, not independent confirmation or generated policy evidence'","assert rem==rep['result']['remaining']","assert j==min("]))
check('future_prompt_static',all(s in a for s in ["'actual_input_tokens':None","'actual_input_token_difference_M_minus_W':None","'no_padding':True","'not_transmitted':True","'candidate_calls':0", "'pair_order':[['W','M'],['M','W'],['W','M'],['M','W']]", "parent=read('METHODS.json')['methods']['published_EoH']['code']"]) and plan['arms']=={'W':['W1','W2','W3','W4'],'M':['W1','W2','U1','U2']},{'same_template_parent_and_offered_request_budget':True,'realized_token_equality_not_claimed':True,'model_not_called':True})
check('protected_tree_final_hashes',all(sha((R/n).read_bytes())==h for n,h in seal['files'].items()))
report={'status':'PASS_PREPARATION_ONLY_WAIT_ROOT_EXACT_RELEASE' if all(c['status']=='PASS' for c in checks) else 'BLOCKED','reviewer':'independent native audit worker','sealed_package':str(R),'preparation_seal_sha256':sealh,'checks':checks,'interfaces':interfaces,'old_source_byte_hash_verification':sourceproof,'scientific_executions_by_auditor':0,'baseline_reexecutions':0,'generator_reexecutions':0,'model_calls':0,'confirmation_arrays_read_or_materialized':0,'protected_package_modified':False,'budget_accounting':{'audit_preparation_CPU_debit':30,'audit_preparation_active_wall_debit':30,'later_result_audit_CPU_reserved':30,'later_result_audit_active_wall_reserved':30,'unmetered_outer_control_actual_CPU':None,'unmetered_outer_control_actual_wall':None,'complete_actual_CPU':None,'complete_actual_active_wall':None,'unknown_full_reservation_retained':True,'meter_file':'measurement.jsonl','interpretation':'Every post-bootstrap inspection/verification child is waited through os.wait4, capturing reaped descendants. Initial read, wrapper construction, tool/controller bootstrap and final-tail costs are not falsely zero; conservative full30/30 preparation-review reservation is retained. No refunds are derived from small measured costs.'},'limitations':['No baseline, scientific pack, generator or future analysis/prompt generation was rerun. Analysis and prompts were reviewed statically only.','Single entropy execution is supported by source, exclusive durable claims and sealed receipts; files alone cannot establish a global absence of undisclosed external activity.','110 exclusion item hashes were reconstructed from eight archived metadata sources. The remaining two are precheck item hashes in the frozen112 inventory; their source file byte hashes were verified without parsing historical arrays. All112 were checked against each new training item-array hash.','Root authorization is an operational trust boundary; the JSON file is not a cryptographic signature. No authorization file currently exists.','Source/byte preservation was verified for all sealed package files and ten prior provenance files. No claim is made to have hashed every unrelated historical directory.'],'manual_findings':['V2 W formula uses NumPy ties-to-even rounding after clipping; U uses inclusive1..100 through integers(1,101). New numbering W1..W4/U1..U2 is an engineering relabeling of the v2 four/two stream design.','The latest blocking collector, not the old /proc polling collector, is imported by both guards. Inclusive driver wait4 is used once; worker/supervisor receipts are evidence rather than additional debits.','Future analysis replays integer assignments and exact Fraction L1/used_bins and produces four same-format feedback rows per arm. Both share W1/W2; parent source and mutation instruction are fixed. Actual provider input tokens and difference remain null.']}
(O/'AUDIT_REPORT.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
(O/'CHECKLIST.txt').write_text('\n'.join(c['status']+' '+c['check'] for c in checks)+'\n')
print(json.dumps({'status':report['status'],'checks':len(checks),'failures':[c for c in checks if c['status']!='PASS'],'reconstructed_prior_hashes':len(derived)},ensure_ascii=False))
