import os,sys,time,json,resource
from pathlib import Path
out=Path(__file__).parent
start=time.monotonic(); ru0=resource.getrusage(resource.RUSAGE_SELF)
pid=os.fork()
if pid==0:
 os.execvp(sys.argv[1],sys.argv[1:])
_,status,ru=os.wait4(pid,0)
ru1=resource.getrusage(resource.RUSAGE_SELF)
row={'argv':sys.argv[1:],'wait4_status':status,'full_tree_user_cpu_s':ru.ru_utime,'full_tree_system_cpu_s':ru.ru_stime,'full_tree_cpu_s':ru.ru_utime+ru.ru_stime,'elapsed_active_wall_s':time.monotonic()-start,'controller_cpu_s':ru1.ru_utime+ru1.ru_stime-ru0.ru_utime-ru0.ru_stime,'controller_bootstrap_charge_cpu_s':0.05,'controller_bootstrap_charge_wall_s':0.05,'measurement_scope':'child process and waited descendants; outer function/tool overhead charged separately'}
with open(out/'measurement.jsonl','a') as f:f.write(json.dumps(row)+'\n')
sys.exit(os.waitstatus_to_exitcode(status))
