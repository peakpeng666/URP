from pathlib import Path
import os,json,time,resource,hashlib
O=Path(__file__).parent;R=Path('/workspace/shared/bpp_training_distribution_baselines_20261008');start=time.monotonic()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pid=os.fork()
if pid==0:
 report=json.loads((O/'AUDIT_REPORT.json').read_text());seal=json.loads((R/'PREPARATION_SEAL.json').read_text())
 assert report['status']=='PASS_PREPARATION_ONLY_WAIT_ROOT_EXACT_RELEASE'
 assert all(sha(R/n)==h for n,h in seal['files'].items())
 assert not (R/'EXECUTION_AUTHORIZATION.json').exists()
 (O/'FINAL_READONLY_CHECK.json').write_text(json.dumps({'sealed_files_unchanged':True,'scientific_claims':0,'authorization_present':False,'baseline_or_generator_executions':0,'source_seal_sha256':sha(R/'PREPARATION_SEAL.json')},indent=2)+'\n')
 os._exit(0)
_,status,u=os.wait4(pid,0);assert os.waitstatus_to_exitcode(status)==0
selfru=resource.getrusage(resource.RUSAGE_SELF)
row={'argv':['finalize.py child verification'],'wait4_status':status,'full_tree_user_cpu_s':u.ru_utime,'full_tree_system_cpu_s':u.ru_stime,'full_tree_cpu_s':u.ru_utime+u.ru_stime,'elapsed_active_wall_s':time.monotonic()-start,'controller_CPU_through_wait_s':selfru.ru_utime+selfru.ru_stime,'tail_and_external_controls_unmeasured':True}
with (O/'measurement.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
rows=[json.loads(x) for x in (O/'measurement.jsonl').read_text().splitlines()]
summary={'wait4_child_tree_CPU_sum_s':sum(x['full_tree_cpu_s'] for x in rows),'measured_command_active_wall_sum_s':sum(x['elapsed_active_wall_s'] for x in rows),'measured_commands':len(rows),'measurement_scope':'Child interpreter processes and reaped descendants, once per invocation. Initial inspection, wrappers/controller setup, transport and report sealing tail are not all included. No measured all-in total is claimed.','complete_actual_CPU':None,'complete_actual_active_wall':None,'preparation_audit_CPU_full_debit':30,'preparation_audit_active_wall_full_debit':30,'future_result_review_CPU_reserved':30,'future_result_review_active_wall_reserved':30,'unknown_refund':False,'combined_review_caps':{'CPU':60,'active_wall':60}}
assert summary['wait4_child_tree_CPU_sum_s']<30 and summary['measured_command_active_wall_sum_s']<30
(O/'RESOURCE_ACCOUNTING.json').write_text(json.dumps(summary,indent=2)+'\n')
files={p.name:sha(p) for p in sorted(O.iterdir()) if p.is_file() and p.name!='AUDIT_MANIFEST.json'}
manifest={'schema':'independent-read-only-preparation-audit-v1','status':'PASS_PREPARATION_ONLY_WAIT_ROOT_EXACT_RELEASE','source_preparation_seal_sha256':sha(R/'PREPARATION_SEAL.json'),'files':files,'resource_accounting':'RESOURCE_ACCOUNTING.json','scientific_or_model_execution_authorized':False,'unmetered_finalizer_tail_covered_by_full_30CPU_30wall_preparation_review_debit':True}
(O/'AUDIT_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'audit_directory':str(O),'manifest_sha256':sha(O/'AUDIT_MANIFEST.json'),'report_sha256':sha(O/'AUDIT_REPORT.json'),'resource_accounting':summary},ensure_ascii=False))
