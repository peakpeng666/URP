from pathlib import Path
import os,json,time,resource,hashlib
O=Path(__file__).parent;R=Path('/workspace/shared/bpp_training_distribution_baselines_20261008');start=time.monotonic()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pid=os.fork()
if pid==0:
 report=json.loads((O/'RESULTS_AUDIT_REPORT.json').read_text());seal=json.loads((R/'PREPARATION_SEAL.json').read_text());close=json.loads((R/'CLOSEOUT.json').read_text());cn=(R/'简短中文报告.txt').read_text();ok=all(x['status']=='PASS' for x in report['checks'])
 def ck(n,value,details=None):
  global ok
  report['checks'].append({'check':n,'status':'PASS' if value else 'FAIL','details':details});ok=ok and value
 rc=report['resources'];co=close['costs']
 ck('closeout_numbers',close['scientific_denominator']==close['scientific_successes']==12 and close['scientific_failures']==close['scientific_unknown']==0 and close['preparation_denominator']==close['preparation_actions_successes']==5 and close['analysis_successes']==1 and co['scientific_driver_wait4_inclusive_CPU']==rc['scientific_driver_tree_CPU'] and co['all18_driver_wait4_inclusive_CPU']==rc['all18_driver_tree_CPU'] and abs(co['all18_guard_wall_to_emit']-rc['all18_guard_wall_to_emit'])<1e-9 and co['exact_all_in_actual_CPU'] is None and co['exact_all_in_actual_wall'] is None and co['full_reservation']=={'CPU':1840,'wall':1570} and close['new_model_API_calls']==close['candidate_generation_requests']==close['confirmation_arrays_materialized']==0 and close['candidate_selection'] is None and close['all_scientific_claims_permanently_consumed'] and close['no_automatic_resume_or_retry'])
 ck('closeout_file_bindings',close['prompt_manifest_sha256']==sha(R/'PROMPT_MANIFEST.json') and close['training_feedback_sha256']==sha(R/'TRAINING_FEEDBACK.json'))
 expected=[]
 for c in report['independently_reconstructed_comparisons']:
  sign=f"{c['parent_minus_BF_bins']:+d}" if c['parent_minus_BF_bins']>0 else str(c['parent_minus_BF_bins'])
  expected.append(f"{c['sequence']}：L1={c['L1']}；BF {c['BF_bins']}箱，F={c['BF_F']}；published {c['parent_bins']}箱，F={c['parent_F']}；published−BF箱数={sign}")
 ck('chinese_report_numbers',all(x in cn for x in expected) and '24.764096' in cn and '27.228722' in cn and '1540/1595' in cn and '仍为null' in cn)
 ck('chinese_report_scientific_index_scope','12个科学pack的每个独立claim都使用instance_index=0及claim_id/instance/0' in cn and '每独立claim都使用instance_index=0' not in cn,{'narrowed_to_scientific_packs':'Admission execution IDs use another format; prepare/analysis have no instance index.'})
 ck('final_source_seal_unchanged',all(sha(R/n)==h for n,h in seal['files'].items()))
 report['reviewed_closeout_sha256']=sha(R/'CLOSEOUT.json');report['reviewed_chinese_report_sha256']=sha(R/'简短中文报告.txt');report['status']='PASS_ALL12_RESULTS_AND_FROZEN_FEEDBACK' if ok else 'BLOCKED'
 (O/'RESULTS_AUDIT_REPORT.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n');(O/'CHECKLIST.txt').write_text('\n'.join(x['status']+' '+x['check'] for x in report['checks'])+'\n')
 snapshot={str(p.relative_to(R)):sha(p) for p in sorted(R.rglob('*')) if p.is_file() and p.name!='LOCK' and '__pycache__' not in p.parts}
 (O/'SOURCE_RESULTS_SNAPSHOT.json').write_text(json.dumps({'source':str(R),'files':snapshot,'includes_logs':True},indent=2)+'\n')
 os._exit(0 if ok else 2)
_,status,u=os.wait4(pid,0)
selfru=resource.getrusage(resource.RUSAGE_SELF)
row={'argv':['finalize.py child verification'],'wait4_status':status,'full_tree_user_cpu_s':u.ru_utime,'full_tree_system_cpu_s':u.ru_stime,'full_tree_cpu_s':u.ru_utime+u.ru_stime,'elapsed_active_wall_s':time.monotonic()-start,'controller_CPU_through_wait_s':selfru.ru_utime+selfru.ru_stime,'tail_and_external_controls_unmeasured':True}
with (O/'measurement.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
rows=[json.loads(x) for x in (O/'measurement.jsonl').read_text().splitlines()]
summary={'wait4_child_tree_CPU_sum_s':sum(x['full_tree_cpu_s'] for x in rows),'measured_command_active_wall_sum_s':sum(x['elapsed_active_wall_s'] for x in rows),'measured_commands':len(rows),'measurement_scope':'All audit calculation/replay children and their reaped descendants are measured via blocking wait4. Initial mkdir/copy, wrapper/controller bootstrap, transport, script construction and final serialization tail are not completely metered. No all-in measured total is claimed.','complete_actual_CPU':None,'complete_actual_active_wall':None,'result_audit_CPU_full_debit':30,'result_audit_active_wall_full_debit':30,'preparation_audit_prior_CPU_debit':30,'preparation_audit_prior_active_wall_debit':30,'combined_review_CPU_full_debit':60,'combined_review_active_wall_full_debit':60,'unknown_refund':False,'combined_review_caps':{'CPU':60,'active_wall':60}}
assert summary['wait4_child_tree_CPU_sum_s']<30 and summary['measured_command_active_wall_sum_s']<30
(O/'RESOURCE_ACCOUNTING.json').write_text(json.dumps(summary,indent=2)+'\n')
report=json.loads((O/'RESULTS_AUDIT_REPORT.json').read_text());files={p.name:sha(p) for p in sorted(O.iterdir()) if p.is_file() and p.name!='AUDIT_MANIFEST.json'}
manifest={'schema':'independent-read-only-results-audit-v1','status':report['status'],'source_preparation_seal_sha256':sha(R/'PREPARATION_SEAL.json'),'files':files,'resource_accounting':'RESOURCE_ACCOUNTING.json','no_further_scientific_or_model_execution_authorized':True,'unmetered_finalizer_tail_covered_by_full_30CPU_30wall_result_review_debit':True}
(O/'AUDIT_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'status':report['status'],'checks':len(report['checks']),'failures':[x for x in report['checks'] if x['status']!='PASS'],'audit_directory':str(O),'manifest_sha256':sha(O/'AUDIT_MANIFEST.json'),'report_sha256':sha(O/'RESULTS_AUDIT_REPORT.json'),'resource_accounting':summary},ensure_ascii=False))
