"""New namespace only. No model API. Original worker and score ABI unchanged."""
import os,sys,json,hashlib,signal,time
from pathlib import Path
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parent
os.umask(0o077)
def sha(b):return hashlib.sha256(b).hexdigest()
def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
def digest(x):return sha(canon(x).encode())
def read(n):return json.loads((R/n).read_text())
def put(n,x):
 with (R/n).open('x') as f:f.write(canon(x)+'\n');f.flush();os.fsync(f.fileno())
 fd=os.open(R/n if False else (R/n).parent,os.O_RDONLY|os.O_DIRECTORY);os.fsync(fd);os.close(fd)
assert len(sys.argv)==2
A=sys.argv[1]
assert os.getppid()==int(os.environ['PRECHECK_GUARD_PID'])
signal.signal(signal.SIGXCPU,signal.SIG_DFL);signal.pthread_sigmask(signal.SIG_UNBLOCK,{signal.SIGXCPU})
assert sys.stdin.read(1)=='G'
p=read('PLAN.json'); runtime=Path(p['runtime']);sys.path.insert(0,str(runtime))
if A=='prepare':
 from prepare_data import prepare
 prepare(p,runtime,put,sha,digest)
else:
 from resource_profile import profile_sha256,DIAGNOSTIC_PROFILE_ID,PRODUCTION_PROFILE_ID
 from policy import policy_sha256
 from registry import source_bytes
 methods=read('METHODS.json')['methods']
 if A.startswith('admission_'):kind='admission';mid=A[len('admission_'):];family=None;idx=0
 elif A.startswith('toy_'):kind='toy';mid='BF' if A=='toy_BF_technical_r1' else A[len('toy_'):];family=None;idx=0
 else:
  kind='scientific';x=next(x for x in p['packs'] if x['id']==A);mid=x['method'];family=x['family'];sequence=x['sequence'];idx=x['index'];assert idx==0
  auth=read('EXECUTION_AUTHORIZATION.json');assert auth['scientific_execution_authorized'] is True
  assert auth['seal_sha256']==sha((R/'PREPARATION_SEAL.json').read_bytes())
 m=methods[mid];candidate={k:m[k] for k in ('description','code','description_sha256','code_sha256','pair_sha256','description_consistency')};source_bytes(candidate)
 profile=DIAGNOSTIC_PROFILE_ID if kind=='toy' else PRODUCTION_PROFILE_ID
 claim=read('claims/'+A+'.json')
 binding={'batch_id':p['id'],'wave_id':p['id']+'-fixed','slot_id':mid,'raw_response_sha256':digest(m),'source_sha256':candidate['code_sha256'],'policy_sha256':policy_sha256(),'runtime_freeze_sha256':p['worker_freeze_sha256'],'claim_sha256':digest(claim),'claim_id':digest([p['id'],A]),'registry_sha256':digest(read('METHODS.json')),'resource_profile_sha256':profile_sha256(profile)}
 if kind=='admission':
  from runner import Session
  w=Session(candidate,binding,worker_role='admission',execution_id=p['id']+'/'+A)
  adm=w.admission.copy();w.close();ev=w.evidence()
  assert adm['admitted'] and ev['reaped'] and not ev['cleanup_error'] and ev['source_after_host_gate']
  payload={'kind':kind,'method':mid,'admission':adm,'worker':ev}
 else:
  from supervised_runner import supervised_pack
  from checker import check_assignment
  if kind=='toy':items=p['toy']
  else:
   data=read('inputs/'+sequence+'.json');e=next(x for x in read('INPUT_MANIFEST.json')['entries'] if x['sequence']==sequence)
   assert digest(data)==e['input_sha256'];items=data['items'];assert len(items)==1000
  execution_id=binding['claim_id']+'/instance/'+str(idx)
  assert execution_id==binding['claim_id']+'/instance/'+str(idx), 'original supervisor execution identity contract'
  try:
   report=supervised_pack(items,100,candidate,binding,execution_id=execution_id,instance_index=idx)
  except BaseException as exc:
   put('failure_'+A+'.json',{'exception_type':type(exc).__name__,'message':str(exc),'supervisor_evidence':getattr(exc,'supervisor_evidence',None),'worker_evidence':getattr(exc,'worker_evidence',None),'execution_id':execution_id,'claim_id':binding['claim_id'],'instance_index':idx,'missing_evidence_is_null':True,'no_retry':True})
   raise
  assert report['worker']['reaped'] and report['supervisor_evidence']['reaped']
  assert report['worker']['cleanup_error'] is None and report['supervisor_evidence']['cleanup_error'] is None
  assert report['outcome']=='ok','fixed baseline or interface failure; no retry'
  checked=check_assignment(items,100,report['result'])
  assert checked['checker_status']=='passed'
  assert report['worker']['source_after_host_gate']
  assert report['worker']['returncode']==0 and report['supervisor_evidence']['returncode']==0
  if mid=='BF':
   rem=[100]*len(items)
   for item,j in zip(items,report['result']['assignment']):
    expected=min((i for i in range(len(rem)) if rem[i]>=item),key=lambda i:(rem[i],i));assert j==expected;rem[j]-=item
  prior=read('payload_admission_'+mid+'.json')['admission']
  assert sha(report['worker']['admission']['canonical_text'].encode())==sha(prior['canonical_text'].encode())
  payload={'kind':kind,'method':mid,'family':family,'n':len(items),'input_sha256':digest({'items':items,'capacity':100}),'code_sha256':candidate['code_sha256'],'L1':(sum(items)+99)//100,'checker':checked,'original_pack_report':report,'scientific':kind=='scientific'}
 put('payload_'+A+'.json',payload)
