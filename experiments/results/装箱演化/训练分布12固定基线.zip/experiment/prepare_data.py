"""Once-only public training generation and unmaterialized confirmation seed commitment."""
from pathlib import Path
import os,sys,json,hmac
R=Path(__file__).resolve().parent
def derive(master,plan_hash,stage,family,index):
 return int.from_bytes(hmac.new(master,('|'.join([plan_hash,stage,family,str(index)])).encode(),'sha256').digest()[:16],'big')
def generate(seed,family):
 import numpy as np
 g=np.random.Generator(np.random.PCG64(seed))
 v=np.round(np.clip(45*g.weibull(3,size=1000),1,100)).astype(np.int64) if family=='W' else g.integers(1,101,size=1000,dtype=np.int64)
 return {'items':v.tolist(),'capacity':100}
def prepare(p,runtime,put,sha,digest):
 import numpy as np
 wf=json.loads((runtime/'worker_freeze.json').read_text())
 assert all(sha(Path(n).read_bytes())==h for n,h in wf['dependencies'].items())
 assert all(sha((runtime/n).read_bytes())==h for n,h in wf['files'].items())
 assert sys.version==wf['python'] and np.__version__==wf['numpy_version']
 assert sha((runtime/'worker_freeze.json').read_bytes())==p['worker_freeze_sha256']
 put('DEPENDENCIES.json',{'status':'PASS','python':sys.version,'numpy':np.__version__,'dependencies_verified':len(wf['dependencies']),'runtime_files_verified':len(wf['files']),'worker_freeze_sha256':p['worker_freeze_sha256']})
 plan_hash=sha((R/'PLAN.json').read_bytes());gen_hash=sha(Path(__file__).read_bytes());prior=json.loads((R/'PRIOR_HASH_INVENTORY.json').read_text());old=set(prior['items_sha256'])
 # Claim file is exclusive and durable before entropy; any failure consumes the action.
 put('ENTROPY_DRAW_CLAIM.json',{'maximum_draws':1,'plan_sha256':plan_hash,'generator_sha256':gen_hash,'exclusion_sha256':sha((R/'PRIOR_HASH_INVENTORY.json').read_bytes()),'analysis_sha256':sha((R/'analyze.py').read_bytes()),'no_reroll':True})
 master=os.urandom(32)
 put('DATA_CLAIM.json',{'master_commitment':sha(b'bpp-training-baselines-v1|'+master),'entropy_draws':1,'plan_sha256':plan_hash,'source_freeze_sha256':sha((R/'SOURCE_FREEZE.json').read_bytes()),'generator_sha256':gen_hash})
 put('custody/SEED_REPRODUCIBILITY.json',{'master_hex':master.hex(),'purpose':'scientific seed, not credential; no confirmation arrays materialized','plan_sha256':plan_hash,'generator_sha256':gen_hash})
 confirm=[]
 for f in ['W','U']:
  for i in range(1,5):
   seed=derive(master,plan_hash,'confirmation',f,i)
   confirm.append({'id':f+'C'+str(i),'seed_commitment':sha(str(seed).encode()),'stage':'confirmation','family':f,'index':i})
 put('CONFIRMATION_SEED_COMMITMENTS.json',{'entries':confirm,'generator_sha256':gen_hash,'data_materialized':False,'raw_array_hashes':None,'performance_read':False,'release_rule':'Only after both candidate selections locked and separate authorization; generate once, exact overlap HALT no replacement','not_claimed':'This is seed/generator precommitment, NOT eight physically sealed data arrays'})
 entries=[];seen=set()
 for f,num in [('W',4),('U',2)]:
  for i in range(1,num+1):
   name=f+str(i);seed=derive(master,plan_hash,'training',f,i);d=generate(seed,f);h=digest(d['items'])
   assert len(d['items'])==1000 and all(type(x)is int and 1<=x<=100 for x in d['items'])
   if h in old or h in seen:
    put('DATA_COLLISION_HALT.json',{'id':name,'items_sha256':h,'no_replacement':True});raise AssertionError('exact duplicate; halt without replacement')
   seen.add(h);put('inputs/'+name+'.json',d)
   entries.append({'sequence':name,'family':f,'index':i,'seed':str(seed),'n':1000,'items_sha256':h,'input_sha256':digest(d),'file_sha256':sha((R/'inputs'/(name+'.json')).read_bytes())})
 put('INPUT_MANIFEST.json',{'entries':entries,'training_sequences':6,'generated_before_any_scientific_evaluation':True,'quality_filter':False,'prior_hash_count':len(old),'exact_duplicate_collisions':0,'confirmation_arrays_materialized':0,'generator_sha256':gen_hash,'plan_sha256':plan_hash})
 put('payload_prepare.json',{'dependency_check':'PASS','input_sequences':6,'n':1000,'new_model_calls':0,'scientific_packs':0,'confirmation_arrays_materialized':0,'runtime_code_unchanged':True})
