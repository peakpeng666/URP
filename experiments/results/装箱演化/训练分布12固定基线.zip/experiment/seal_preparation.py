from pathlib import Path
import json,hashlib,os
R=Path(__file__).resolve().parent
from driver_helpers import read,put,sha,digest
p=read('PLAN.json');sf=read('SOURCE_FREEZE.json')
assert all(sha((R/n).read_bytes())==h for n,h in sf['files'].items())
assert not (R/'HALT.json').exists() and not (R/'EXECUTION_AUTHORIZATION.json').exists()
entries=read('INPUT_MANIFEST.json')['entries'];assert len(entries)==6
assert set(x['sequence'] for x in entries)=={'W1','W2','W3','W4','U1','U2'}
for x in entries:
 data=read('inputs/'+x['sequence']+'.json');assert digest(data)==x['input_sha256'] and digest(data['items'])==x['items_sha256']
 assert sha((R/'inputs'/(x['sequence']+'.json')).read_bytes())==x['file_sha256']
assert all(x['index']==0 for x in p['packs']) and len(p['packs'])==12
assert len({digest([p['id'],x['id']]) for x in p['packs']})==12
prep=['prepare','admission_BF','admission_published_EoH','toy_BF','toy_published_EoH']
receipts=[]
for a in prep:
 c=read('claims/'+a+'.json');t=read('results/'+a+'.json');assert t['status']=='passed' and t['claim_sha256']==digest(c)
 assert sha((R/('payload_'+a+'.json')).read_bytes())==t['payload_sha256']
 assert t['resources']['driver_exit_code']==0 and t['resources']['driver_reaped']
 receipts.append(t)
for a in ['toy_BF','toy_published_EoH']:
 payload=read('payload_'+a+'.json');rep=payload['original_pack_report']
 assert rep['instance_index']==0 and rep['execution_id']==rep['binding']['claim_id']+'/instance/0'
 assert payload['checker']['checker_status']=='passed' and rep['worker']['source_after_host_gate']
 for k in ['worker','supervisor_evidence']:assert rep[k]['returncode']==0 and rep[k]['reaped'] and rep[k]['cleanup_error'] is None
assert len(read('CONFIRMATION_SEED_COMMITMENTS.json')['entries'])==8
assert read('CONFIRMATION_SEED_COMMITMENTS.json')['data_materialized'] is False
assert sum(x['CPU'] for x in p['budget']['reservations'].values())==1840
assert sum(x['wall'] for x in p['budget']['reservations'].values())==1570
put('STATIC_CONTRACT.json',{'status':'PASS','rows':[{'action_id':x['id'],'claim_id':digest([p['id'],x['id']]),'execution_id':digest([p['id'],x['id']])+'/instance/0','instance_index':0,'not_yet_claimed':not (R/'claims'/(x['id']+'.json')).exists()} for x in p['packs']],'source_after_gate_and_checker_pass_in_both_toys':True,'new_model_calls':0})
put('PREPARATION_REPORT.json',{'status':'PREPARATION_PASS_WAIT_ROOT_APPROVAL_AND_INDEPENDENT_REVIEW','training_sequences':6,'scientific_packs_started':0,'model_API_calls':0,'candidate_generations':0,'old_files_modified':False,'confirmation_arrays_materialized':0,'confirmation_seed_commitments':8,'preparation_driver_tree_CPU':sum(t['resources']['driver_wait4_inclusive_CPU'] for t in receipts),'preparation_guard_wall_to_emit_sum':sum(t['resources']['wall_at_emit'] for t in receipts),'guard_CPU_upper_total':len(receipts),'complete_all_in_actual_CPU':None,'complete_all_in_active_wall':None,'unmetered_control_plane_reserve':read('CONTROL_PLANE_CLAIM.json'),'budget':p['budget'],'measurement_caveat':'inclusive wait4 driver-tree CPU counted once; no summing nested worker/supervisor meters; bounded guard tails and unmetered file/control work retained in reservation, never claimed measured0','token_counts':'Actual model input tokens unavailable before authorized generation; future draft records null, no invented count or measurement API','old_precheck':'4 old packs are chain tests only, not formal training; old error/HALT/unknown records preserved'})
# Include all preflight evidence, no locks or logs (logs hash separately via terminal and evidence).
files={str(f.relative_to(R)):sha(f.read_bytes()) for f in sorted(R.rglob('*')) if f.is_file() and f.name!='LOCK' and '__pycache__' not in f.parts and 'logs' not in f.parts}
put('PREPARATION_SEAL.json',{'files':files,'scientific_started':False,'model_calls':0,'authorization_required':'root exact12-pack release after reading this seal','source_freeze_sha256':sha((R/'SOURCE_FREEZE.json').read_bytes()),'budget_caps':p['budget']['caps']})
print(json.dumps({'seal_sha256':sha((R/'PREPARATION_SEAL.json').read_bytes()),'frozen_files':len(files),'report':read('PREPARATION_REPORT.json')},ensure_ascii=False))
