from pathlib import Path
import json,hashlib,zipfile,sys
R=Path(__file__).resolve().parent
from driver_helpers import read,put,sha
A=Path(sys.argv[1]);P=Path('/workspace/shared/bpp_training_distribution_preparation_audit_20261008')
assert (A/'AUDIT_MANIFEST.json').is_file()
assert sha((R/'PREPARATION_SEAL.json').read_bytes())=='c35f83aaaf2da5d29624072c2bb442fc871475890292780859fc3ed6b88c6538'
assert all(sha((R/n).read_bytes())==h for n,h in read('PREPARATION_SEAL.json')['files'].items())
assert read('CLOSEOUT.json')['scientific_successes']==12
put('FINAL_VERIFICATION.json',{'status':'TWELVE_BASELINES_ANALYSIS_AND_INDEPENDENT_RESULT_AUDIT_COMPLETE','preparation_seal_sha256':sha((R/'PREPARATION_SEAL.json').read_bytes()),'preparation_audit_manifest_sha256':sha((P/'AUDIT_MANIFEST.json').read_bytes()),'result_audit_directory':str(A),'result_audit_manifest_sha256':sha((A/'AUDIT_MANIFEST.json').read_bytes()),'report_sha256':sha((R/'简短中文报告.txt').read_bytes()),'new_model_calls':0,'confirmation_arrays_materialized':0,'status_supersedes':'CLOSEOUT and report pending-audit wording is preserved as the audited pre-audit snapshot; this receipt records completed audit','archive_is_private_delivery_only':True})
files=[]
for root,prefix in [(R,'experiment'),(P,'preparation_audit'),(A,'result_audit')]:
 for p in sorted(root.rglob('*')):
  if p.is_file() and p.name!='LOCK' and '__pycache__' not in p.parts and p.suffix!='.zip':files.append((p,prefix+'/'+str(p.relative_to(root))))
runtime=Path(read('PLAN.json')['runtime']);wf=json.loads((runtime/'worker_freeze.json').read_text())
for n in list(wf['files'])+['worker_freeze.json','pre_run_freeze.json']:files.append((runtime/n,'unchanged_runtime/'+n))
license=runtime.parent/'LICENSE.published_EoH';files.append((license,'unchanged_runtime/LICENSE.published_EoH'))
# Historical errors remain a separate provenance annex; no old scores or confirmation arrays.
old=Path('/workspace/shared/bpp_zero_generation_precheck_20261008')
for n in ['HALT.json','claims/toy_BF.json','results/toy_BF.json','TOY_FAILURE_READONLY_DIAGNOSIS.json']:
 files.append((old/n,'historical_precheck_failure/'+n))
manifest={n:{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p,n in files}
assert len(manifest)==len(files)
archive=R/'训练分布12固定基线完整证据_20261008.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for p,n in files:z.write(p,n)
 z.writestr('MANIFEST.json',json.dumps(manifest,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 m=json.loads(z.read('MANIFEST.json'));assert all(sha(z.read(n))==x['sha256'] for n,x in m.items())
put('ARCHIVE_RECEIPT.json',{'archive':str(archive),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'members':len(manifest),'all_member_hashes_and_CRC':'PASS','excludes_credentials':True,'scientific_calls_in_packaging':0,'packaging_wait4_receipt':'PACKAGING_WAIT4.json outside archive because produced after archive closure'})
print((R/'ARCHIVE_RECEIPT.json').read_text())
