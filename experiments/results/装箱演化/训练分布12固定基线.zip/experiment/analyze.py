"""Independent integer replay and exact rational description, no policy execution."""
from pathlib import Path
import json,hashlib,sys,os,signal
from fractions import Fraction
R=Path(__file__).resolve().parent
sys.path.insert(0,str(R))
from driver_helpers import read,put,sha,digest
assert os.getppid()==int(os.environ['PRECHECK_GUARD_PID']) and sys.stdin.read(1)=='G'
signal.signal(signal.SIGXCPU,signal.SIG_DFL);signal.pthread_sigmask(signal.SIG_UNBLOCK,{signal.SIGXCPU})
rows=[]
for x in read('PLAN.json')['packs']:
 aid=x['id'];t=read('results/'+aid+'.json');c=read('claims/'+aid+'.json');assert t['status']=='passed' and t['claim_sha256']==digest(c)
 raw=(R/('payload_'+aid+'.json')).read_bytes();assert sha(raw)==t['payload_sha256'];p=json.loads(raw)
 d=read('inputs/'+x['sequence']+'.json');items=d['items'];assert len(items)==1000 and p['input_sha256']==digest(d)
 assert p['code_sha256']==read('METHODS.json')['methods'][x['method']]['code_sha256']
 rep=p['original_pack_report'];assign=rep['result']['assignment'];assert len(assign)==1000
 rem=[100]*1000
 for item,j in zip(items,assign):
  assert type(item)is int and 1<=item<=100 and type(j)is int and 0<=j<1000 and rem[j]>=item
  if x['method']=='BF':assert j==min((i for i,b in enumerate(rem) if b>=item),key=lambda i:(rem[i],i))
  rem[j]-=item
 assert rem==rep['result']['remaining'] and sum(items)==sum(100-z for z in rem)
 used=sum(z!=100 for z in rem);lower=(sum(items)+99)//100
 assert used==rep['result']['used_bins']==p['checker']['used_bins'] and lower==p['L1'] and used>=lower
 assert rep['execution_id']==rep['binding']['claim_id']+'/instance/'+str(x['index'])
 for role in ['worker','supervisor_evidence']:
  e=rep[role];assert e['reaped'] and e['returncode']==0 and e['cleanup_error'] is None
 q=Fraction(lower,used)
 rows.append({'action_id':aid,'sequence':x['sequence'],'family':x['family'],'method':x['method'],'n':1000,'capacity':100,'total_weight':sum(items),'L1':lower,'used_bins':used,'bins_above_L1':used-lower,'F':str(q),'F_float_display':float(q),'integer_replay_pass':True,'input_sha256':digest(d),'source_sha256':p['code_sha256']})
comparisons=[]
for sequence in ['W1','W2','W3','W4','U1','U2']:
 b=next(z for z in rows if z['sequence']==sequence and z['method']=='BF');h=next(z for z in rows if z['sequence']==sequence and z['method']=='published_EoH')
 comparisons.append({'sequence':sequence,'family':sequence[0],'L1':b['L1'],'BF_bins':b['used_bins'],'BF_F':b['F'],'parent_bins':h['used_bins'],'parent_F':h['F'],'parent_minus_BF_bins':h['used_bins']-b['used_bins'],'parent_minus_BF_F':str(Fraction(h['F'])-Fraction(b['F']))})
out={'status':'TWELVE_FIXED_TRAINING_PACKS_INTEGER_REPLAY_PASS','rows':rows,'comparisons':comparisons,'model_calls':0,'scientific_packs':12,'unique_sequences':6,'n':1000,'scope':'public training feedback only, not independent confirmation or generated policy evidence','no_p_values':True,'no_quality_reroll':True,'analysis_code_sha256':sha(Path(__file__).read_bytes())}
put('ANALYSIS.json',out)
feedback={arm:[next(r for r in comparisons if r['sequence']==s) for s in seq] for arm,seq in read('PLAN.json')['arms'].items()}
put('TRAINING_FEEDBACK.json',{'arms':feedback,'same_format':True,'shared_W1_W2':True,'model_calls':0})
parent=read('METHODS.json')['methods']['published_EoH']['code']
template='Return one new heuristic as Python source implementing score(item, bins). Mutate the fixed parent below for online bin packing (capacity100,1000 items). Only current item and feasible residual capacities in original-index order, including empty bins, are visible. Return a finite int32/int64/float64 ndarray of matching length; first original-index argmax wins. No future items, runtime family label, mutable cross-call state, imports, external calls, or tools. Source maximum16384 bytes. Improve exact mean L1/used_bins over the four assigned training streams. The same frozen parent is used for every request. No candidate feedback is available.\nTraining condition: {condition}\nFeedback columns: sequence, L1, BF bins, BF F, parent bins, parent F\n{feedback}\nFixed parent:\n{parent}'
prompts={}
for arm in ['W','M']:
 condition='four Weibull(3,scale45) rounded/clipped streams' if arm=='W' else 'two Weibull(3,scale45) rounded/clipped plus two discrete uniform1..100 streams, equal sequence weights'
 text=template.format(condition=condition,feedback='\n'.join(', '.join(str(r[k]) for k in ['sequence','L1','BF_bins','BF_F','parent_bins','parent_F']) for r in feedback[arm]),parent=parent)
 with (R/('PROMPT_'+arm+'_DRAFT.txt')).open('x') as f:f.write(text+'\n')
 prompts[arm]={'sha256':sha((text+'\n').encode()),'utf8_bytes':len((text+'\n').encode()),'actual_input_tokens':None}
put('PROMPT_MANIFEST.json',{'draft_only':True,'not_transmitted':True,'max_logical_requests':8,'pair_order':[['W','M'],['M','W'],['W','M'],['M','W']],'parent_sha256':sha(parent.encode()),'prompts':prompts,'actual_input_token_difference_M_minus_W':None,'token_status':'Exact provider input token count unavailable before authorized requests; no measurement API calls or fabricated local estimate; record returned provider usage later','no_padding':True,'candidate_calls':0})
