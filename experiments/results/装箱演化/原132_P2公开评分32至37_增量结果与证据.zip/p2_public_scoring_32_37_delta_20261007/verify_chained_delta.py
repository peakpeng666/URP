#!/usr/bin/env python3
"""Offline data-only chain verification. Never import project/candidate code."""
from pathlib import Path
from fractions import Fraction
import argparse,hashlib,json
ap=argparse.ArgumentParser();ap.add_argument('--chain-root',required=True);args=ap.parse_args();R=Path(__file__).resolve().parent;P=Path(args.chain_root)
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def check(root):
 m=load(root/'FILE_MANIFEST.json')
 for rel,v in m['files'].items():assert (root/rel).stat().st_size==v['bytes'] and sha(root/rel)==v['sha256'],str(root/rel)
 return m
check(R);sources=[]
for entry in load(R/'CHAIN_REFERENCE.json')['required_previous_packages']:
 root=P/entry['directory_name'];assert sha(root/'FILE_MANIFEST.json')==entry['manifest_sha256'];assert (root/'FILE_MANIFEST.json').read_bytes()==(R/'chain_manifests'/(str(entry['end'])+'.json')).read_bytes();check(root);sources.append(root/'project/public_execution' if entry['kind']=='base' else root/'state_delta')
sources.append(R/'state_delta');state={}
for rel,expected in load(R/'CUMULATIVE_STATE_FILE_HASHES.json')['files'].items():
 matches=[d/rel for d in sources if (d/rel).exists()];assert len(matches)==1,rel
 p=matches[0];assert p.stat().st_size==expected['bytes'] and sha(p)==expected['sha256'];state[rel]=p
rows=[load(p) for rel,p in state.items() if rel.startswith('results/')];summary=load(R/'SUMMARY.json');end=summary['cumulative_generation_denominator'];assert sorted(x['record']['position'] for x in rows)==list(range(1,end+1))
for row in rows:
 if row['fitness']:
  assert len(row['scores'])==5 and all(x['outcome']=='ok' and x['evidence']['checker_status']=='passed' for x in row['scores']);f=sum((Fraction(x['L1'],x['used_bins']) for x in row['scores']),Fraction())/5;assert row['fitness']['numerator']==f.numerator and row['fitness']['denominator']==f.denominator
 else:assert row['evaluation_status']!='scored'
reservations=[load(p) for rel,p in state.items() if rel.startswith('reservations/')];assert sum(x['cpu_seconds'] for x in reservations)==summary['cumulative_usage']['reserved_cpu_seconds'];assert sum(x['shared_wall_seconds'] for x in reservations)==summary['cumulative_usage']['reserved_shared_wall_seconds']
bundles=[load(p) for rel,p in state.items() if rel.startswith('slots/') and rel.endswith('/bundle.json')];cpu=0;packs=0
for b in bundles:
 cpu+=b['admission']['worker']['cpu_seconds']
 for s in b['scores']:packs+=1;cpu+=s['evidence']['worker']['cpu_seconds']+s['evidence']['supervisor']['actual_supervisor_cpu_seconds']
assert len(bundles)==summary['cumulative_usage']['admissions'] and packs==summary['cumulative_usage']['instance_packs'];assert abs(cpu-summary['cumulative_usage']['numerical_cpu_seconds_no_double_count'])<1e-6
for arm,x in summary['arms'].items():
 xs=[r for r in rows if r['record']['arm']==arm];assert len(xs)==x['generation_denominator_prefix'];assert sum(r['evaluation_status']=='scored' for r in xs)==x['complete_fitness'];assert sum(r['evaluation_status']=='generation_failure' for r in xs)==x['generation_failures']
print(json.dumps({'status':'PASS_readonly_chain_hashes_exact_fitness_budget','rows':end,'admissions':len(bundles),'packs':packs,'candidate_executions':0,'heldout_reads':0}))
