"""Single authorized, terminal-only, read-only audit with a complete wait4 receipt.

No candidate sandbox is launched. The child performs only file verification,
assignment replay and independent analysis of the already sealed terminal set.
"""
import ctypes
import hashlib
import json
import os
import resource
import signal
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/workspace/shared/prospective_confirmation_C1_preparation_20261007')
os.umask(0o077)


def write_once(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    descriptor = os.open(path.parent, os.O_DIRECTORY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def main():
    if sys.argv[1:] != ['--run-authorized-terminal-audit']:
        raise SystemExit('Explicit authorization flag and terminal notification are required.')
    for name in ('RAW_TERMINAL_SET_FROZEN.json', 'CONFIRMATION_ANALYSIS_STRICT_AND_TECHNICAL.json',
                 'results/analysis_recovery.json', 'RECOVERY_DISPATCH_COMPLETION.json'):
        if not (ROOT / name).is_file():
            raise SystemExit('Not launched: terminal gate missing: ' + name)
    source = HERE / 'verify_sealed_confirmation.py'
    plan = json.loads((HERE / 'FINAL_READONLY_AUDIT_PLAN.json').read_text())
    source_sha = hashlib.sha256(source.read_bytes()).hexdigest()
    if source_sha != plan['audit_source_sha256']:
        raise SystemExit('Audit source differs from the approved prepared plan.')
    started = time.monotonic()
    resource.setrlimit(resource.RLIMIT_CPU, (1, 8))
    resource.setrlimit(resource.RLIMIT_AS, (134217728, 536870912))
    signal.signal(signal.SIGXCPU, signal.SIG_DFL)
    signal.pthread_sigmask(signal.SIG_UNBLOCK, {signal.SIGXCPU, signal.SIGALRM})
    signal.signal(signal.SIGALRM, signal.SIG_DFL)
    signal.setitimer(signal.ITIMER_REAL, 8)
    claim = {'schema': 'C1-final-read-only-audit-once-claim-v1',
             'claimed_at_utc': datetime.now(timezone.utc).isoformat(),
             'source_sha256': source_sha, 'reserve_CPU_seconds': 10, 'reserve_wall_seconds': 8,
             'cumulative_CPU_reservations': 14116, 'cumulative_wall_reservations': 11999,
             'main_process_CPU_hard': 8, 'controller_CPU_hard': 1,
             'CPU_quantization_and_termination_margin': 1,
             'main_process_wall_alarm': 7, 'controller_wall_alarm': 8,
             'candidate_executions_allowed': 0, 'no_automatic_retry': True}
    write_once(HERE / 'FINAL_AUDIT_EXECUTION_CLAIM.json', claim)
    libc = ctypes.CDLL(None, use_errno=True)
    parent = os.getpid()

    def child_limits():
        if libc.prctl(1, signal.SIGKILL, 0, 0, 0) != 0 or os.getppid() != parent:
            os._exit(76)
        resource.setrlimit(resource.RLIMIT_CPU, (8, 8))
        resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
        signal.signal(signal.SIGXCPU, signal.SIG_DFL)
        signal.signal(signal.SIGALRM, signal.SIG_DFL)
        signal.pthread_sigmask(signal.SIG_UNBLOCK, {signal.SIGXCPU, signal.SIGALRM})
        signal.setitimer(signal.ITIMER_REAL, 7)

    env = {'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8', 'PYTHONDONTWRITEBYTECODE': '1',
           'OPENBLAS_NUM_THREADS': '1', 'OMP_NUM_THREADS': '1', 'MKL_NUM_THREADS': '1',
           'BLIS_NUM_THREADS': '1', 'NUMEXPR_NUM_THREADS': '1'}
    stdout = (HERE / 'FINAL_AUDIT_STDOUT.txt').open('x')
    stderr = (HERE / 'FINAL_AUDIT_STDERR.txt').open('x')
    child = subprocess.Popen([sys.executable, '-B', str(source), '--sealed-terminal-only'],
                             stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
                             cwd=HERE, env=env, preexec_fn=child_limits)
    resource.setrlimit(resource.RLIMIT_CPU, (1, 1))
    resource.setrlimit(resource.RLIMIT_AS, (134217728, 134217728))
    pid, raw_status, usage = os.wait4(child.pid, 0)
    child.returncode = os.waitstatus_to_exitcode(raw_status)
    stdout.close()
    stderr.close()
    own = resource.getrusage(resource.RUSAGE_SELF)
    report = HERE / 'FINAL_TERMINAL_ACCEPTANCE.json'
    receipt = {'schema': 'C1-final-audit-full-exit-receipt-v1',
               'status': 'COMPLETE' if child.returncode == 0 and report.is_file() else 'INCOMPLETE_REVIEW_REQUIRED',
               'pid': pid, 'child_reaped': True, 'raw_wait_status': raw_status,
               'exit_code': child.returncode, 'complete_child_CPU_seconds': usage.ru_utime + usage.ru_stime,
               'child_peak_RSS_kib': usage.ru_maxrss,
               'controller_CPU_at_emit': own.ru_utime + own.ru_stime,
               'wall_at_emit': time.monotonic() - started,
               'main_report_hash': hashlib.sha256(report.read_bytes()).hexdigest() if report.is_file() else None,
               'partial_progress_file': str(HERE / 'FINAL_AUDIT_PROGRESS.json'),
               'reserve_CPU_seconds': 10, 'reserve_wall_seconds': 8,
               'cumulative_CPU_reservations': 14116, 'cumulative_wall_reservations': 11999,
               'candidate_executions': 0,
               'measurement_scope': 'wait4 includes the full main audit process through report fsync and exit. '
                                    'Controller final receipt/exit tail is bounded by its CPU cap and uncancelled '
                                    'wall alarm and remains within the separately reserved envelope. '
                                    'Earlier preparation/control-plane costs are not represented as zero.'}
    write_once(HERE / 'FINAL_AUDIT_FULL_EXIT_RECEIPT.json', receipt)
    print(json.dumps({'status': receipt['status'], 'exit_code': child.returncode,
                      'complete_child_CPU_seconds': receipt['complete_child_CPU_seconds'],
                      'wall_at_emit': receipt['wall_at_emit']}), flush=True)
    return 0 if receipt['status'] == 'COMPLETE' else 1


if __name__ == '__main__':
    sys.exit(main())
