"""Read-only C1 integrity verification. No seeds/policies/confirmation scores read.
Instance arrays are parsed only inside this process for hash/domain/duplicate checks;
no values, sums, minima/maxima, or quality statistics are emitted.
"""
from pathlib import Path
import json,hashlib,stat,os,time
from datetime import datetime,timezone
C=Path('/workspace/shared/prospective_confirmation_C1_preparation_20261007');A=Path(__file__).resolve().parent
start=time.process_time()
canon=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda p:json.loads(p.read_text())
mp=C/'DATA_MANIFEST.json';m=read(mp);raw=mp.read_bytes();assert raw==(canon(m)+'\n').encode()
assert m['generation_attempts']==1 and m['entropy_draws']==1 and m['policy_evaluations']==0 and m['quality_or_policy_filter_used'] is False and m['old_heldout_reads']==0 and m['private_seed_in_manifest'] is False
links={'PROTOCOL_DRAFT.json':'protocol_sha256','custodian.py':'generator_source_sha256','SEED_METHOD_SPEC.json':'seed_method_spec_sha256','METHODS_FROZEN.json':'methods_file_sha256','PREPARATION_FREEZE.json':'preparation_freeze_sha256','custody/MASTER_COMMITMENT.json':'master_commitment_file_sha256','PUBLIC_EXCLUSION_MANIFEST.json':'public_exclusion_manifest_sha256'}
for file,key in links.items():assert sha((C/file).read_bytes())==m[key],key
runtime=read(C/'frozen_runtime/worker_freeze.json');assert m['python']==runtime['python'] and m['numpy_version']==runtime['numpy_version']
ex=read(C/'PUBLIC_EXCLUSION_MANIFEST.json');entries=m['instances'];assert len(entries)==20
assert [e['global_instance_index'] for e in entries]==list(range(20))
seen=set();report=[];public_compares=0
for i,e in enumerate(entries):
 assert e['relative_file']==f'custody/instances/{i:02d}.json'
 p=C/e['relative_file'];b=p.read_bytes();obj=json.loads(b)
 assert set(obj)=={'items','capacity'} and type(obj['capacity']) is int and obj['capacity']==100
 items=obj['items'];assert type(items)is list and len(items)==5000 and all(type(x)is int and 1<=x<=100 for x in items)
 assert e['n']==5000 and e['capacity']==100
 assert b==(canon(obj)+'\n').encode() and sha(b)==e['file_sha256']
 assert sha(canon(obj).encode())==e['input_sha256'];ih=sha(canon(items).encode());assert ih==e['items_sha256'] and ih not in seen;seen.add(ih)
 for prior in ex['entries']:
  assert sha(canon(items[:prior['n']]).encode())!=prior['items_sha256'];public_compares+=1
 report.append({'index':i,'file_sha256':sha(b),'input_sha256':e['input_sha256'],'domain_and_shape_valid':True,'canonical_json_valid':True,'private_mode':oct(stat.S_IMODE(p.stat().st_mode))})
 del items,obj,b
assert {p.name for p in (C/'custody/instances').iterdir()}=={f'{i:02d}.json' for i in range(20)}
claim=read(C/'claims/data.json');terminal=read(C/'results/data.json');r=terminal['resources']
assert claim['action_id']=='data' and terminal['action_id']=='data' and terminal['claim_sha256']==sha(canon(claim).encode())
assert terminal['status']=='passed' and r['driver_reaped'] is True and r['driver_exit_code']==0 and r['guard_trigger'] is None
assert terminal['payload']['data_manifest_sha256']==sha(raw)
policy=read(C/'RESUME_POLICY.json');toys=[read(C/'results'/(aid+'.json')) for aid in policy['required_successful_toys']]
assert all(t['status']=='passed' and t['completed_at_utc']<claim['claimed_at_utc'] for t in toys)
selection=read(C/'CANDIDATE_SELECTION_DECISION.json');assert selection['decision_time_utc']<claim['claimed_at_utc']
gen=read(C/'custody/GENERATION_ONCE_CLAIM.json');assert gen['entropy_draws_max']==1 and gen['instances']==20 and gen['no_reroll'] is True
master=C/'custody/master.bin';ms=master.stat();assert ms.st_size==32 and stat.S_IMODE(ms.st_mode)==0o600
ordered=(C/'custody/GENERATION_ONCE_CLAIM.json').stat().st_mtime_ns<=ms.st_mtime_ns<=(C/'custody/MASTER_COMMITMENT.json').stat().st_mtime_ns<=min((C/e['relative_file']).stat().st_mtime_ns for e in entries)
assert ordered
x={'schema':'C1-independent-data-integrity-metadata-only-v1','status':'PASS_NEW_PROSPECTIVE_DATA_INTEGRITY','reviewed_at_utc':datetime.now(timezone.utc).isoformat(),'dataset_manifest_sha256':sha(raw),'dataset_file_count':20,'items_per_instance':5000,'capacity':100,'all_file_input_items_hashes_match':True,'all_domains_and_shapes_valid':True,'all_canonical_json_valid':True,'new_full_instance_hashes_unique':True,'public_prefix_full_hash_comparisons':public_compares,'public_duplicate_matches':0,'policy_evaluations_in_data_generation':0,'prior_toys_completed_before_data_claim':True,'selected_candidate_decision_precedes_new_data':True,'generation_claim_master_stat_commitment_instances_mtime_order_valid':True,'master_stat_only':{'bytes':ms.st_size,'mode':'0600','contents_read':False},'generator_environment_matches_frozen_runtime_versions':True,'manifest_bound_files':links,'data_action_resource_receipt':{'driver_reaped':True,'driver_exit_code':0,'guard_trigger':None,'complete_driver_CPU_seconds':r['driver_wait4_inclusive_CPU_seconds'],'conservative_complete_tree_CPU_upper_seconds':r['conservative_complete_tree_CPU_upper_seconds'],'cumulative_reserved_CPU_seconds':r['cumulative_reserved_CPU_seconds'],'cumulative_reserved_wall_seconds':r['cumulative_reserved_wall_seconds']},'creation_utc_interval':{'claim':claim['claimed_at_utc'],'terminal':terminal['completed_at_utc']},'per_instance_hash_domain_evidence':report,'no_seed_values_read':True,'no_instance_values_or_quality_summaries_emitted':True,'no_candidates_admissions_toys_or_formal_packs_run_by_auditor':True,'interpretation':'New post-selection prospective validation data. Does not retroactively complete original preregistration.','audit_process_CPU_seconds_before_report_write':time.process_time()-start}
(A/'DATA_INTEGRITY_REVIEW.json').write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in x.items() if k not in ['per_instance_hash_domain_evidence','manifest_bound_files']},ensure_ascii=False,indent=2))
