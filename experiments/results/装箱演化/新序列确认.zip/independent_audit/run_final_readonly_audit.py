"""One authorized final read-only audit envelope: 10 CPU seconds, 8 active-wall seconds.

No policy process, source admission, or packing execution is launched. The single
analysis/checking child is capped before exec. The parent records its complete
wait4 usage, retains failures, and never retries a consumed audit claim.
"""
from pathlib import Path
import ctypes
import hashlib
import json
import os
import resource
import signal
import subprocess
import sys
import time
from datetime import datetime, timezone

ROOT = Path('/workspace/shared/prospective_confirmation_C1_preparation_20261007')
HERE = Path(__file__).resolve().parent
SCRIPT = HERE / 'verify_sealed_confirmation_after_second_halt.py'
EXPECTED_SCRIPT_SHA256 = 'd52a4eec434f5a2949dc5717fb08ddb2f40e901cf124fca8100165a17b0de3c1'


def put_once(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    descriptor = os.open(path.parent, os.O_DIRECTORY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def main():
    if sys.argv[1:] != ['--run-authorized-sealed-audit']:
        raise SystemExit('Explicit authorized terminal-audit argument required.')
    # Only file existence and the verifier's own source hash are inspected here.
    # In particular, this parent does not decode scientific output.
    required = ('RAW_TERMINAL_SET_AFTER_SECOND_HALT.json',
                'CONFIRMATION_ANALYSIS_FINAL_STRICT_AND_TECHNICAL.json',
                'results/analysis_remaining28.json', 'REMAINING28_DISPATCH_COMPLETION.json')
    if not all((ROOT / name).is_file() for name in required):
        raise SystemExit('Final terminal set is not complete; audit was not claimed or started.')
    script_sha = hashlib.sha256(SCRIPT.read_bytes()).hexdigest()
    if script_sha != EXPECTED_SCRIPT_SHA256:
        raise SystemExit('Prepared independent verifier source hash changed.')
    claim_path = HERE / 'FINAL_READONLY_AUDIT_CLAIM.json'
    if claim_path.exists():
        raise SystemExit('Permanent audit claim already exists; no automatic rerun.')
    os.umask(0o077)
    resource.setrlimit(resource.RLIMIT_CPU, (1, 8))
    signal.signal(signal.SIGXCPU, signal.SIG_DFL)
    signal.pthread_sigmask(signal.SIG_UNBLOCK, {signal.SIGXCPU})
    started = time.monotonic()
    deadline = started + 8
    signal.signal(signal.SIGALRM, signal.SIG_DFL)
    signal.setitimer(signal.ITIMER_REAL, 8)
    put_once(claim_path, {
        'schema': 'C1-once-only-final-readonly-audit-reservation-v1',
        'claimed_at_utc': datetime.now(timezone.utc).isoformat(),
        'verifier_source_sha256': script_sha,
        'reserve_CPU_seconds': 10, 'reserve_active_wall_seconds': 8,
        'execution_reservations_before_audit_CPU': 14128,
        'execution_reservations_before_audit_wall': 11991,
        'cumulative_reservations_including_audit_CPU': 14138,
        'cumulative_reservations_including_audit_wall': 11999,
        'total_CPU_cap': 14200, 'total_active_wall_cap': 12000,
        'candidate_or_pack_execution_allowed': False,
        'source_preparation_and_unmeasured_control_plane_are_not_fabricated_as_zero': True,
        'no_automatic_retry': True,
    })
    libc = ctypes.CDLL(None, use_errno=True)
    parent = os.getpid()

    def parent_death_guard():
        if libc.prctl(1, signal.SIGKILL, 0, 0, 0) != 0 or os.getppid() != parent:
            os._exit(76)

    environment = {'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8', 'PYTHONDONTWRITEBYTECODE': '1',
                   'OPENBLAS_NUM_THREADS': '1', 'OMP_NUM_THREADS': '1', 'MKL_NUM_THREADS': '1',
                   'BLIS_NUM_THREADS': '1', 'NUMEXPR_NUM_THREADS': '1'}
    command = ['/usr/bin/prlimit', '--cpu=8:8', '--as=536870912:536870912',
               '--nofile=64:64', '--core=0:0', '--', sys.executable, '-I', '-B',
               str(SCRIPT), '--sealed-terminal-only']
    stdout = (HERE / 'FINAL_READONLY_AUDIT.stdout.txt').open('xb')
    stderr = (HERE / 'FINAL_READONLY_AUDIT.stderr.txt').open('xb')
    child = subprocess.Popen(command, env=environment, stdin=subprocess.DEVNULL,
                             stdout=stdout, stderr=stderr, preexec_fn=parent_death_guard)
    resource.setrlimit(resource.RLIMIT_CPU, (1, 1))
    resource.setrlimit(resource.RLIMIT_AS, (134217728, 134217728))
    stopped_for_wall = False

    def stop_child_before_envelope_end(_signal, _frame):
        nonlocal stopped_for_wall
        stopped_for_wall = True
        try:
            os.kill(child.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        # Keep an unhandled kernel deadline through final reaping/receipt writes.
        signal.signal(signal.SIGALRM, signal.SIG_DFL)
        signal.setitimer(signal.ITIMER_REAL, max(.001, deadline - time.monotonic()))

    signal.signal(signal.SIGALRM, stop_child_before_envelope_end)
    signal.setitimer(signal.ITIMER_REAL, max(.001, deadline - .5 - time.monotonic()))
    pid, status, usage = os.wait4(child.pid, 0)
    child.returncode = os.waitstatus_to_exitcode(status)
    signal.signal(signal.SIGALRM, signal.SIG_DFL)
    signal.setitimer(signal.ITIMER_REAL, max(.001, deadline - time.monotonic()))
    stdout.close()
    stderr.close()
    own = resource.getrusage(resource.RUSAGE_SELF)
    child_cpu = usage.ru_utime + usage.ru_stime
    passed = child.returncode == 0 and not stopped_for_wall and child_cpu + 1 <= 10 and time.monotonic() <= deadline
    report = HERE / 'FINAL_TERMINAL_ACCEPTANCE_AFTER_SECOND_HALT.json'
    put_once(HERE / 'FINAL_READONLY_AUDIT_TERMINAL.json', {
        'schema': 'C1-final-readonly-audit-complete-exit-receipt-v1',
        'status': 'passed' if passed else 'failed_or_incomplete_no_retry',
        'completed_at_utc': datetime.now(timezone.utc).isoformat(),
        'child_pid': pid, 'child_reaped': True, 'raw_wait_status': status,
        'child_exit_code': child.returncode, 'wall_stop_triggered': stopped_for_wall,
        'complete_child_CPU_seconds': child_cpu,
        'complete_child_peak_RSS_kib': usage.ru_maxrss,
        'parent_CPU_at_emit': own.ru_utime + own.ru_stime,
        'conservative_complete_tree_CPU_upper': child_cpu + 1,
        'wall_at_emit': time.monotonic() - started,
        'reserve_CPU_seconds': 10, 'reserve_active_wall_seconds': 8,
        'alarm_active_through_receipt_and_exit': True,
        'final_report_exists': report.is_file(),
        'final_report_sha256': hashlib.sha256(report.read_bytes()).hexdigest() if report.is_file() else None,
        'partial_progress_retained': (HERE / 'FINAL_AUDIT_PROGRESS_AFTER_SECOND_HALT.jsonl').is_file(),
        'source_preparation_costs_are_separate_not_claimed_as_measured_all_in': True,
        'no_candidate_or_pack_execution': True,
    })
    print(json.dumps({'status': 'passed' if passed else 'failed_or_incomplete_no_retry',
                      'child_exit': child.returncode, 'child_complete_CPU': child_cpu,
                      'wall_at_emit': time.monotonic() - started,
                      'cumulative_reservations_CPU': 14138, 'cumulative_reservations_wall': 11999}))
    return 0 if passed else 1


if __name__ == '__main__':
    raise SystemExit(main())
