"""Select only infrastructure metadata; skip scientific payload values without decoding them."""
import json
from pathlib import Path
D=json.JSONDecoder()
def skip_value(s,p):
 while s[p].isspace():p+=1
 if s[p] in '[{':
  level=0;quoted=False;escape=False
  for i in range(p,len(s)):
   c=s[i]
   if quoted:
    if escape:escape=False
    elif c=='\\':escape=True
    elif c=='"':quoted=False
   elif c=='"':quoted=True
   elif c in '[{':level+=1
   elif c in ']}':
    level-=1
    if level==0:return i+1
  raise ValueError('unterminated container')
 if s[p]=='"':
  escape=False
  for i in range(p+1,len(s)):
   if escape:escape=False
   elif s[i]=='\\':escape=True
   elif s[i]=='"':return i+1
  raise ValueError('unterminated string')
 i=p
 while i<len(s) and s[i] not in ',}]':i+=1
 return i
def slices(s):
 p=0
 while s[p].isspace():p+=1
 assert s[p]=='{';p+=1;out={}
 while True:
  while s[p].isspace():p+=1
  if s[p]=='}':return out
  key,p=D.raw_decode(s,p)
  while s[p].isspace():p+=1
  assert s[p]==':';p+=1
  while s[p].isspace():p+=1
  end=skip_value(s,p);out[key]=(p,end);p=end
  while s[p].isspace():p+=1
  if s[p]==',':p+=1
  else:assert s[p]=='}'
def select(s,keys):
 parts=slices(s)
 return {k:json.loads(s[slice(*parts[k])]) for k in keys if k in parts}
def raw_field(s,key):return s[slice(*slices(s)[key])]
def inspect(path):
 s=Path(path).read_text();r=select(s,['action_id','status','claim_sha256','completed_at_utc','resources'])
 payload=raw_field(s,'payload');pack=raw_field(payload,'original_pack_report');worker=raw_field(pack,'worker');sup=raw_field(pack,'supervisor_evidence')
 r['worker_resource_metadata']=select(worker,['pid','reaped','returncode','source_after_host_gate','cleanup_error','cpu_seconds','host_observed_limits'])
 r['supervisor_resource_metadata']=select(sup,['pid','reaped','returncode','wait4_cpu_seconds','actual_supervisor_cpu_seconds','child_cpu_seconds','host_observed_limits','cleanup_error'])
 return r
if __name__=='__main__':
 p=Path('/workspace/shared/prospective_confirmation_C1_preparation_20261007/results/confirm_00_EOH_locked.json')
 r=inspect(p);out=Path(__file__).resolve().parent/'FIRST_FORMAL_RESOURCE_METADATA_ONLY.json';out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
