"""Independent terminal-only verification; never executes a policy or reads master.bin.

Do not run until the parent authorizes final verification after the raw terminal set,
analysis terminal, dispatcher completion and outer execution completion are available.
All experiment files are read-only. Outputs are written only beside this audit script.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import resource
import sys
import time
from collections import Counter
from datetime import datetime, timezone
from fractions import Fraction
from pathlib import Path

ROOT = Path('/workspace/shared/prospective_confirmation_C1_preparation_20261007')
OUT = Path(__file__).resolve().parent
METHODS = ('EOH_locked', 'IID_locked', 'FF', 'BF', 'published_EoH')
UNKNOWN = ('confirm_00_IID_locked', 'confirm_14_IID_locked')
EXTRA = 'technical_completion_00_IID_locked_v1'
PINNED_FREEZE = 'f5668186735505b8cff55e51e20efa8ba2b7e8e25ae7736331c6530d6ab35b54'
PINNED_SEAL = '2aacabef0437f0ba9005a631fe994fad72d1c85d54c54a5158af1a5a4b76a174'


def need(test, label):
    if not test:
        raise RuntimeError(label)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def file_hash(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(relative):
    return json.loads((ROOT / relative).read_text())


def progress(stage, **details):
    path = OUT / 'FINAL_AUDIT_PROGRESS.json'
    temporary = OUT / 'FINAL_AUDIT_PROGRESS.tmp'
    with temporary.open('w') as stream:
        json.dump({'status': 'IN_PROGRESS_NOT_A_PASS', 'stage': stage,
                   'recorded_at_utc': datetime.now(timezone.utc).isoformat(), **details}, stream)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def close(a, b, label, tolerance=1e-8):
    need(math.isclose(float(a), float(b), rel_tol=1e-12, abs_tol=tolerance), label)


def fraction_document(value):
    return {'numerator': value.numerator, 'denominator': value.denominator, 'decimal': float(value)}


def independently_analyze(rows, indices, np):
    """Recompute the committed estimands without importing either experiment analyzer."""
    table = {(row['global_instance_index'], row['method']): row for row in rows}
    need(len(rows) == len(table) == 100, 'analysis requires exactly 100 distinct cells')
    need(set(table) == {(i, method) for i in range(20) for method in METHODS}, 'paired cell grid')
    ratios, coverage, means = {}, {}, {}
    for method in METHODS:
        valid = []
        for i in range(20):
            row = table[i, method]
            if row['status'] == 'ok':
                ratios[i, method] = Fraction(row['L1'], row['used_bins'])
                valid.append(i)
            else:
                need(row['used_bins'] is None, 'failed cell cannot carry a bin count')
        coverage[method] = {'complete': len(valid), 'denominator': 20}
        means[method] = (fraction_document(sum((ratios[i, method] for i in valid), Fraction()) / 20)
                         if len(valid) == 20 else None)
    contrasts = {}
    for method in METHODS[1:]:
        if coverage['EOH_locked']['complete'] != 20 or coverage[method]['complete'] != 20:
            contrasts[method] = None
            continue
        differences = [ratios[i, 'EOH_locked'] - ratios[i, method] for i in range(20)]
        samples = np.asarray([float(x) for x in differences], dtype=np.float64)[indices].mean(axis=1)
        contrasts[method] = {
            'mean_F_difference': fraction_document(sum(differences, Fraction()) / 20),
            'total_bin_savings_comparator_minus_EOH': sum(
                table[i, method]['used_bins'] - table[i, 'EOH_locked']['used_bins'] for i in range(20)),
            'wins_ties_losses': [sum(x > 0 for x in differences), sum(x == 0 for x in differences),
                                sum(x < 0 for x in differences)],
            'paired_instances': 20,
            'interval': {
                'method': 'paired_percentile_bootstrap_approximate',
                'resamples': 20000,
                'lower_upper': np.quantile(samples, [.025, .975], method='linear').tolist(),
                'secondary_intervals_descriptive_unadjusted': method != 'IID_locked',
            },
        }
    return {'coverage': coverage, 'full20_means': means, 'primary_EOH_minus_IID': contrasts['IID_locked'],
            'contrasts': contrasts, 'no_zero_imputation': True, 'p_values': None,
            'winner_selection': None, 'n_independent_sequences': 20}


def compare_documents(expected, actual, path='analysis'):
    if isinstance(expected, dict):
        need(isinstance(actual, dict) and set(expected) == set(actual), path + ': keys')
        for key in expected:
            compare_documents(expected[key], actual[key], path + '.' + key)
    elif isinstance(expected, list):
        need(isinstance(actual, list) and len(expected) == len(actual), path + ': list length')
        for i, value in enumerate(expected):
            compare_documents(value, actual[i], path + '[' + str(i) + ']')
    elif isinstance(expected, float):
        need(type(actual) in (float, int) and math.isfinite(actual), path + ': finite numeric value')
        close(expected, actual, path, 1e-14)
    else:
        need(type(expected) is type(actual) and expected == actual, path + ': exact value')


def main():
    need(sys.argv[1:] == ['--sealed-terminal-only'], 'explicit terminal-only invocation required')
    # Check completion gates before opening any scientific result or instance file.
    for name in ('RAW_TERMINAL_SET_AFTER_SECOND_HALT.json', 'CONFIRMATION_ANALYSIS_FINAL_STRICT_AND_TECHNICAL.json',
                 'results/analysis_remaining28.json', 'REMAINING28_DISPATCH_COMPLETION.json'):
        need((ROOT / name).is_file(), 'terminal gate missing: ' + name)
    completion = read('REMAINING28_DISPATCH_COMPLETION.json')
    need(completion['status'] == '28_new_terminals_plus_two_unknown_strict_and_technical_analysis_written',
         'dispatcher completion status')
    started, cpu_started = time.monotonic(), time.process_time()
    progress_path = OUT / 'FINAL_AUDIT_PROGRESS_AFTER_SECOND_HALT.jsonl'
    def checkpoint(stage, **fields):
        with progress_path.open('a') as stream:
            stream.write(json.dumps({'stage': stage, 'CPU': time.process_time()-cpu_started,
                                     'wall': time.monotonic()-started, **fields}, sort_keys=True)+'\n')
            stream.flush()
            os.fsync(stream.fileno())
    checkpoint('terminal_gates_present')
    progress('terminal_completion_gates_passed')
    need(file_hash(ROOT / 'REMAINING28_FREEZE.json') == PINNED_FREEZE, 'pinned recovery freeze')
    need(file_hash(ROOT / 'REMAINING28_SEAL.json') == PINNED_SEAL, 'pinned recovery seal')
    freeze, policy = read('REMAINING28_FREEZE.json'), read('REMAINING28_POLICY.json')
    for name, expected in freeze['files'].items():
        need(file_hash(ROOT / name) == expected, 'frozen file drift: ' + name)
    for name, expected in policy['preserved_files'].items():
        need(file_hash(ROOT / name) == expected, 'preserved file drift: ' + name)
    runtime = read('frozen_runtime/worker_freeze.json')
    for name, expected in runtime['files'].items():
        need(file_hash(ROOT / 'frozen_runtime' / name) == expected, 'original runtime source drift: ' + name)
    need(file_hash(Path('/workspace/shared/p2_scoring_adapter_append_revision_20261007/EXECUTION_SWITCH.json')) ==
         '06633366205b921f12bdc9d17910b490e9c4eed808c71a2f950a3098f725b4a3', 'old closed P2 switch unchanged')
    progress('frozen_and_preserved_hashes_verified')
    original, recovery = read('FORMAL_PLAN.json'), read('RECOVERY_PLAN.json')
    methods, data_manifest = read('METHODS_FROZEN.json')['methods'], read('DATA_MANIFEST.json')
    need(recovery['packs'][:98] == original['packs'][2:], 'unchanged 98-slot schedule')
    need(recovery['packs'][-1]['action_id'] == EXTRA and len(recovery['packs']) == 99, 'single extra attempt')
    remaining = read('REMAINING28_RUNTIME_PLAN.json')
    need(remaining['packs'] == recovery['packs'][71:] and len(remaining['packs']) == 28, 'exact final suffix')
    claims = {p.stem: json.loads(p.read_text()) for p in (ROOT / 'claims').glob('*.json')}
    need(len(claims) == 115, 'final permanent claim count')
    need(len(list((ROOT / 'results').glob('*.json'))) == 113, 'terminal count includes retained toy failure')
    for unknown in UNKNOWN:
        need(not (ROOT / 'results' / (unknown + '.json')).exists(), 'unknown terminal must remain absent')
        need(not (ROOT / 'payloads' / (unknown + '.json')).exists(), 'unknown payload must remain absent')
    raw = read('RAW_TERMINAL_SET_AFTER_SECOND_HALT.json')
    raw_sha = file_hash(ROOT / 'RAW_TERMINAL_SET_AFTER_SECOND_HALT.json')
    need(raw['unknown_original'] == list(UNKNOWN) and raw['no_original_unknown_replacement'] is True,
         'raw-set unknown semantics')
    need([x['action_id'] for x in raw['strict_original']] == [x['action_id'] for x in original['packs']],
         'raw strict membership order')
    need(raw['technical_extra']['action_id'] == EXTRA, 'raw extra membership')
    references = {x['action_id']: x for x in raw['strict_original']}
    references[EXTRA] = raw['technical_extra']
    for aid, reference in references.items():
        need(reference['claim_sha256'] == file_hash(ROOT / 'claims' / (aid + '.json')), 'raw claim hash: ' + aid)
        if aid in UNKNOWN:
            need(reference['terminal_sha256'] is None, 'unknown must not acquire a terminal hash')
        else:
            need(reference['terminal_sha256'] == file_hash(ROOT / 'results' / (aid + '.json')),
                 'raw terminal hash: ' + aid)
    need(claims['analysis_remaining28']['raw_terminal_set_sha256'] == raw_sha, 'analysis claim raw-set binding')
    progress('raw_membership_verified', strict_scientific_cells=100, total_scientific_attempts=101)

    checkpoint('frozen_sources_claims_and_raw_membership_verified')
    cached_instance, items = None, None
    verified_rows, resources, outcomes = {}, [], Counter()
    assignment_steps = 0
    for row in original['packs'] + [recovery['packs'][-1]]:
        aid, index, method = row['action_id'], row['global_instance_index'], row['method']
        if aid in UNKNOWN:
            verified_rows[aid] = {'global_instance_index': index, 'method': method,
                                  'status': 'infrastructure_unknown_original_claim', 'used_bins': None, 'L1': None}
            continue
        if cached_instance != index:
            entry = data_manifest['instances'][index]
            instance_path = ROOT / entry['relative_file']
            need(file_hash(instance_path) == entry['file_sha256'], 'sealed instance bytes')
            instance = json.loads(instance_path.read_text())
            need(digest(instance) == entry['input_sha256'], 'sealed instance canonical hash')
            items = instance['items']
            need(instance['capacity'] == 100 and len(items) == 5000 and
                 all(type(value) is int and 1 <= value <= 100 for value in items), 'instance domain')
            cached_instance = index
        need((claims[aid]['reserve_CPU_seconds'], claims[aid]['reserve_wall_seconds']) == (125, 93),
             'exact scientific-attempt reservation')
        terminal = read('results/' + aid + '.json')
        need(terminal['status'] == 'passed' and terminal['claim_sha256'] == digest(claims[aid]),
             'infrastructure terminal/claim binding: ' + aid)
        payload = terminal['payload']
        need((payload['global_instance_index'], payload['method']) == (index, method), 'cell identity')
        need(payload['input_sha256'] == row['input_sha256'] == data_manifest['instances'][index]['input_sha256'],
             'cell input hash')
        need(payload['code_sha256'] == row['code_sha256'] == methods[method]['code_sha256'], 'method code hash')
        need(payload['description_sha256'] == methods[method]['description_sha256'], 'method description hash')
        need(payload['source_origin'] == methods[method]['origin'], 'honest method origin')
        lower = (sum(items) + 99) // 100
        need(payload['L1'] == lower and payload['n'] == 5000 and payload['capacity'] == 100, 'independent L1')
        report = payload['original_pack_report']
        worker, supervisor = report['worker'], report['supervisor_evidence']
        need(report['execution_id'] == row['runtime_execution_id'] and
             report['instance_index'] == row['local_instance_index'], 'original runtime ABI identity')
        need(report['binding']['claim_id'] == row['runtime_claim_id'] and
             report['binding']['source_sha256'] == row['code_sha256'], 'runtime source claim')
        need(worker['source_after_host_gate'] is True and worker['source_sha256'] == row['code_sha256'],
             'source execution gate')
        for evidence, fd in ((worker, 3), (supervisor, 32)):
            limits = evidence['host_observed_limits']
            need(limits['cpu_seconds'] == [60, 60] and
                 limits['address_space_bytes'] == [536870912, 536870912] and limits['open_files'] == [fd, fd],
                 'original observed hard limits')
            need(evidence['reaped'] is True and evidence['cleanup_error'] is None, 'original descendant reap')
        need(worker['security']['Threads'] == 1 and worker['security']['NoNewPrivs'] == 1 and
             worker['security']['Seccomp'] == 2, 'worker OS isolation')
        admitted = read('results/admission_' + method + '.json')['payload']['admission']
        need(worker['admission']['canonical_text'] == admitted['canonical_text'], 'original admitted AST identity')
        close(supervisor['wait4_cpu_seconds'], supervisor['actual_supervisor_cpu_seconds'] + worker['cpu_seconds'],
              'inclusive supervisor CPU without double count', .01)
        resource_record = terminal['resources']
        need(resource_record['driver_reaped'] is True and resource_record['driver_exit_code'] == 0 and
             resource_record['guard_trigger'] is None, 'guard terminal integrity')
        need(resource_record['driver_wait4_inclusive_CPU_seconds'] + .01 >= supervisor['wait4_cpu_seconds'],
             'driver inclusive CPU scope')
        need(resource_record['driver_wait4_inclusive_CPU_seconds'] + 1 <= claims[aid]['reserve_CPU_seconds'],
             'complete driver plus guard tail reservation')
        outcome = payload['outcome']
        need(outcome == report['outcome'] and outcome in ('ok', 'numeric_failure', 'resource_limit', 'timeout'),
             'scientific outcome classification')
        outcomes[method + ':' + outcome] += 1
        used = None
        if outcome == 'ok':
            result = report['result']
            assignments, counts = result['assignment'], result['feasible_counts']
            need(len(assignments) == len(counts) == 5000, 'complete assignment trajectory')
            remaining, histogram = [100] * 5000, [0] * 101
            histogram[100] = 5000
            for item, target, count in zip(items, assignments, counts):
                need(type(target) is int and 0 <= target < 5000 and remaining[target] >= item,
                     'replayed assignment feasibility')
                need(type(count) is int and count == sum(histogram[item:]), 'replayed feasible count')
                before = remaining[target]
                remaining[target] -= item
                histogram[before] -= 1
                histogram[remaining[target]] += 1
            need(remaining == result['remaining'] and sum(items) == sum(100 - v for v in remaining),
                 'replayed final residuals and conservation')
            used = sum(v != 100 for v in remaining)
            need(result['used_bins'] == payload['checker']['used_bins'] == used and
                 payload['checker']['checker_status'] == 'passed', 'independently replayed used bins')
            need(payload['checker']['assignment_sha256'] == digest(assignments), 'assignment hash')
            need(lower <= used <= 5000 and worker['steps'] == 5000 and worker['assignment_complete'] is True,
                 'complete successful worker trajectory')
            assignment_steps += 5000
        else:
            need(report['result'] is None and payload['checker'] is None, 'failed output stays null')
            if outcome == 'resource_limit':
                need(worker['terminal_reason']['kind'] == 'worker_cpu_limit', 'attributed CPU-limit failure')
            elif outcome == 'timeout':
                need(worker['terminal_reason'] is not None, 'attributed wall-limit failure')
            else:
                need(worker['numerical_failure'] is not None, 'attributed numerical failure')
        verified_rows[aid] = {'global_instance_index': index, 'method': method,
                              'status': outcome, 'used_bins': used, 'L1': lower}
        resources.append({'action_id': aid, 'driver_complete_CPU': resource_record['driver_wait4_inclusive_CPU_seconds'],
                          'guard_CPU_at_emit': resource_record['guard_self_CPU_at_emit']})
        if len(resources) % 10 == 0:
            checkpoint('trajectory_replay_progress', completed_terminals=len(resources), assignment_steps=assignment_steps)
        if len(resources) % 10 == 0:
            progress('trajectory_verification', known_terminals_verified=len(resources),
                     replayed_assignment_steps=assignment_steps)

    outer_cpu = 0.0
    for aid in [x['action_id'] for x in recovery['packs'] if x['action_id'] not in UNKNOWN] + ['analysis_remaining28']:
        observed = read('dispatcher_observations/' + aid + '.complete.json')
        launch = read('dispatcher_observations/' + aid + '.launch.json')
        events = observed['raw_wait4_events']
        need(observed['unreaped_descendants_remaining'] is False and
             observed['inner_driver_or_worker_CPU_not_readded'] is True, 'outer cleanup and accounting')
        need(len({event['pid'] for event in events}) == len(events), 'distinct outer wait4 events')
        need(events[0] == read('dispatcher_observations/' + aid + '.guard_wait4.json'), 'guard wait4 source')
        need(events[0]['pid'] == launch['guard']['pid'] and events[0]['exit_code'] == 0, 'guard identity/exit')
        total = sum(event['utime'] + event['stime'] for event in events)
        close(total, observed['inclusive_CPU_counted_once'], 'outer complete CPU sum')
        for event in events:
            need(os.waitstatus_to_exitcode(event['raw_wait_status']) == event['exit_code'], 'raw wait status decode')
        need(total <= claims[aid]['reserve_CPU_seconds'], 'outer complete tree below reservation')
        term = read('results/' + aid + '.json')
        need(term['status'] == 'passed' and term['claim_sha256'] == digest(claims[aid]), 'final action binding')
        need(total + .01 >= term['resources']['driver_wait4_inclusive_CPU_seconds'], 'outer versus inner CPU scope')
        outer_cpu += total
    progress('outer_reaping_and_resource_receipts_verified', guarded_actions_verified=100,
             replayed_assignment_steps=assignment_steps)

    checkpoint('all_trajectories_and_outer_resource_receipts_verified', completed_terminals=len(resources), assignment_steps=assignment_steps)
    # The complete raw set and every trajectory are checked before any comparison is calculated.
    import numpy as np
    need(np.__version__ == data_manifest['numpy_version'] == '2.3.5', 'frozen bootstrap NumPy')
    analysis_sha = file_hash(ROOT / 'analysis_locked.py')
    data_sha = file_hash(ROOT / 'DATA_MANIFEST.json')
    message = ('confirmation-C1-analysis-bootstrap-v1|' + data_sha + '|' + analysis_sha).encode()
    bootstrap_seed = int.from_bytes(hashlib.sha256(message).digest()[:16], 'big')
    indices = np.random.Generator(np.random.PCG64(bootstrap_seed)).integers(0, 20, size=(20000, 20))
    strict_rows = [verified_rows[x['action_id']] for x in original['packs']]
    technical_rows = [verified_rows[EXTRA] if row['action_id'] == UNKNOWN[0] else verified_rows[row['action_id']]
                      for row in original['packs']]
    strict = independently_analyze(strict_rows, indices, np)
    technical = independently_analyze(technical_rows, indices, np)
    checkpoint('independent_two_view_statistics_computed')
    actual = read('CONFIRMATION_ANALYSIS_FINAL_STRICT_AND_TECHNICAL.json')
    compare_documents(strict, actual['strict_original_100_slots'])
    compare_documents(technical, actual['technical_completion_sensitivity'])
    need(actual['original_unknowns_retained'] == [0, 14], 'both original unknowns retained')
    for key in ('technical_IID14_still_unknown', 'technical_full_primary_permanently_null',
                'strict_primary_permanently_null', 'technical_completion_is_separate_not_original_primary', 'no_generic_retry'):
        need(actual[key] is True, 'analysis distinction: ' + key)
    need(actual['all_attempts_reported_separately'] == 101 and actual['exact_extra_attempt'] == EXTRA,
         'scientific attempt count')
    need(actual['raw_terminal_set_sha256'] == raw_sha, 'analysis output raw-set identity')
    need((claims['analysis_remaining28']['reserve_CPU_seconds'], claims['analysis_remaining28']['reserve_wall_seconds']) == (303, 523),
         'exact final analysis reservation')
    analysis_terminal = read('results/analysis_remaining28.json')
    need(analysis_terminal['payload']['analysis_file_sha256'] ==
         file_hash(ROOT / 'CONFIRMATION_ANALYSIS_FINAL_STRICT_AND_TECHNICAL.json'), 'analysis terminal output hash')
    need(strict['full20_means']['IID_locked'] is None and strict['primary_EOH_minus_IID'] is None,
         'strict primary remains null')
    need(technical['full20_means']['IID_locked'] is None and technical['primary_EOH_minus_IID'] is None,
         'technical view still lacks original IID14')
    need(strict['coverage']['IID_locked']['complete'] <= 18 and technical['coverage']['IID_locked']['complete'] <= 19,
         'no missing cell disappears in either view')
    progress('independent_statistics_match', strict_primary_null=True)
    need(sum(name.startswith('confirm_') for name in claims) == 100 and EXTRA in claims, '101 scientific attempts')
    ledger = read('TECHNICAL_PREPARATION_LEDGER.json')
    for entry in ledger['claims']:
        need(file_hash(ROOT / entry['file']) == entry['file_sha256'], 'permanent probe claim identity')
    need(file_hash(ROOT / ledger['explicit_top_up']['file']) == ledger['explicit_top_up']['sha256'],
         'explicit reservation correction identity')
    extra_cpu = sum(x['reserve_CPU_seconds'] for x in ledger['claims']) + ledger['explicit_top_up']['CPU']
    extra_wall = sum(x['reserve_wall_seconds'] for x in ledger['claims'])
    need((extra_cpu, extra_wall) == (61, 400), 'all probe and correction debits retained')
    cpu_reserve = 200 + 22 + 22 + 22 + extra_cpu + sum(x['reserve_CPU_seconds'] for x in claims.values())
    wall_reserve = 600 + 60 + 60 + 60 + extra_wall + sum(x['reserve_wall_seconds'] for x in claims.values())
    need((cpu_reserve, wall_reserve) == (14128, 11991), 'complete frozen execution reservations')
    checkpoint('statistics_and_final_budget_verified')
    result = {
        'schema': 'C1-independent-terminal-assignment-statistics-and-budget-review-v1',
        'status': 'PASS_FROZEN_EXECUTION_DATA_STATISTICS_AND_LEDGER',
        'reviewed_at_utc': datetime.now(timezone.utc).isoformat(),
        'raw_terminal_set_sha256': raw_sha,
        'analysis_output_sha256': file_hash(ROOT / 'CONFIRMATION_ANALYSIS_FINAL_STRICT_AND_TECHNICAL.json'),
        'original_scientific_cells': 100, 'original_unknowns_retained': list(UNKNOWN),
        'known_scientific_terminals_including_technical': 99, 'scientific_attempts_including_unknown': 101,
        'independently_replayed_assignment_steps': assignment_steps,
        'outcome_counts_including_technical_attempt': dict(outcomes),
        'strict_original_100_slots': strict, 'technical_completion_sensitivity': technical,
        'point_estimates_exact_fraction_match': True, 'bootstrap_recomputed_resamples': 20000,
        'bootstrap_float_comparison_absolute_tolerance': 1e-14,
        'conservative_frozen_execution_CPU_reservation': cpu_reserve,
        'conservative_frozen_execution_wall_reservation': wall_reserve,
        'complete_logged_guard_trees_CPU_measured_once': outer_cpu,
        'final_dispatcher_self_CPU_at_emit': completion['self_CPU_at_emit'],
        'all_in_actual_CPU_including_old_unknown': None,
        'final_audit_cost_is_separate_and_requires_its_own_authorized_envelope': True,
        'old_unknown_CPU_reservation': 250, 'old_unknown_wall_reservation': 186,
        'old_toy_failure_and_all_probe_failures_not_refunded': True,
        'policy_executions_by_auditor': 0, 'master_seed_contents_read': False,
        'outer_execution_tool_exit_must_be_confirmed_separately': True,
        'final_stage_switch_at_audit': read('REMAINING28_SWITCH.json')['enabled'],
        'audit_CPU_before_output_write': time.process_time() - cpu_started,
        'audit_wall_before_output_write': time.monotonic() - started,
    }
    output = OUT / 'FINAL_TERMINAL_ACCEPTANCE_AFTER_SECOND_HALT.json'
    with output.open('x') as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    progress('all_checks_passed_report_written', report=str(output), report_sha256=file_hash(output))
    print(json.dumps({'status': result['status'], 'report': str(output),
                      'scientific_attempts': 101, 'strict_primary_null': True,
                      'CPU_reservations_before_audit': cpu_reserve,
                      'wall_reservations_before_audit': wall_reserve}, ensure_ascii=False))


if __name__ == '__main__':
    main()
