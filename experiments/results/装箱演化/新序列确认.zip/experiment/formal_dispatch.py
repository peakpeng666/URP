"""One permanent finite dispatcher segment. A second launch cannot reset its debit."""
import ctypes,fcntl,os,sys,resource,signal,subprocess,time
from datetime import datetime,timezone
from control import ROOT,read,put,need,sha,canon
from guard_collect import valid_new_terminal
sys.dont_write_bytecode=True;os.umask(0o077)
need(sys.argv[1:]==['--enable-formal'],'explicit activation flag required')
need(read(ROOT/'FORMAL_SWITCH.json')['enabled'] is True,'formal disabled')
resource.setrlimit(resource.RLIMIT_CPU,(20,300));resource.setrlimit(resource.RLIMIT_AS,(67108864,536870912))
signal.signal(signal.SIGXCPU,signal.SIG_DFL);signal.pthread_sigmask(signal.SIG_UNBLOCK,{signal.SIGXCPU})
lock=(ROOT/'FORMAL_DISPATCH_LOCK').open('a+b');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
need(not (ROOT/'FORMAL_DISPATCH_CLAIM.json').exists(),'permanent dispatcher segment consumed; reviewed new segment required for resume')
need(not (ROOT/'FORMAL_HALT.json').exists(),'formal HALT preserved')
freeze=read(ROOT/'FORMAL_FREEZE.json');fh=sha((ROOT/'FORMAL_FREEZE.json').read_bytes())
for n,h in freeze['files'].items():need(sha((ROOT/n).read_bytes())==h,'formal frozen file drift '+n)
policy=read(ROOT/'FORMAL_POLICY.json');seal_hash=sha((ROOT/'NEW_PROSPECTIVE_SEAL.json').read_bytes());auth=read(ROOT/'FORMAL_AUTHORIZATION.json')
audit_file=__import__('pathlib').Path(policy['independent_pass_path']);audit=read(audit_file)
need(auth.get('formal_execution_authorized') is True and auth.get('formal_freeze_sha256')==fh and auth.get('prospective_seal_sha256')==seal_hash and auth.get('independent_audit_sha256')==sha(audit_file.read_bytes()),'specific parent activation required')
need(audit.get('status')=='PASS_FORMAL_ENTRYPOINT_NOT_ACTIVATED' and audit.get('formal_freeze_sha256')==fh and audit.get('prospective_seal_sha256')==seal_hash,'formal independent audit required')
plan=read(ROOT/'FORMAL_PLAN.json');started=time.monotonic()
# All100 guarded actions+analysis+60seconds nonoverlapped overhead; alarm remains active through final exit.
segment_wall=100*93+603+60
signal.signal(signal.SIGALRM,signal.SIG_DFL);signal.setitimer(signal.ITIMER_REAL,segment_wall)
put(ROOT/'FORMAL_DISPATCH_CLAIM.json',{'schema':'C1-single-dispatcher-segment-claim-v1','pid':os.getpid(),'formal_freeze_sha256':fh,'seal_sha256':seal_hash,'reserve_CPU_seconds':22,'reserve_wall_seconds':60,'full_segment_wall_limit_seconds':segment_wall,'claimed_at_utc':datetime.now(timezone.utc).isoformat(),'no_retry':True})
libc=ctypes.CDLL(None,use_errno=True);parent=os.getpid()
def death_guard():
 if libc.prctl(1,signal.SIGKILL,0,0,0)!=0 or os.getppid()!=parent:os._exit(76)
env=dict(os.environ,C1_DISPATCH_PID=str(parent),PYTHONDONTWRITEBYTECODE='1')
for row in plan['packs']+[{'action_id':'analysis'}]:
 aid=row['action_id'];need(not (ROOT/'FORMAL_HALT.json').exists(),'formal HALT retained')
 if (ROOT/'claims'/(aid+'.json')).exists():
  need((ROOT/'results'/(aid+'.json')).exists(),'UNKNOWN permanent claim; stop,never rerun')
  need(valid_new_terminal(read(ROOT/'claims'/(aid+'.json')),read(ROOT/'results'/(aid+'.json'))),'failed or mismatched permanent claim; stop')
  continue
 result=subprocess.run([sys.executable,'-B',str(ROOT/'formal_guard.py'),'--enable-formal',aid],cwd=ROOT,env=env,check=False,preexec_fn=death_guard)
 if result.returncode!=0:raise SystemExit(result.returncode)
 # Never interpret partial policy fitness,adapt order or retry.
put(ROOT/'FORMAL_DISPATCH_COMPLETION.json',{'status':'all100_terminal_analysis_written','self_CPU_at_emit':time.process_time(),'wall_at_emit':time.monotonic()-started,'dispatcher_CPU_reservation':22,'nonoverlapped_wall_overhead_reservation':60,'full_segment_wall_limit_seconds':segment_wall,'alarm_active_through_exit':True,'overlap_not_double_counted':True,'new_generation_calls':0})
print(canon({'status':'formal_sequence_terminal','no_candidate_reselection':True}))
