"""Trusted short fixtures for the exact production blocking collector."""
from pathlib import Path
import os,sys,time,resource,signal,json,hashlib
resource.setrlimit(resource.RLIMIT_CPU,(1,3));signal.signal(signal.SIGXCPU,signal.SIG_DFL)
from guard_collect_blocking import collect_driver
root=Path(__file__).resolve().parent;mode=sys.argv[1];out=root/'engineering_tests'/('blocking_'+mode);out.mkdir(exist_ok=False)
wall=.5 if mode=='wall' else 5;start=time.monotonic();signal.signal(signal.SIGALRM,signal.SIG_DFL);signal.setitimer(signal.ITIMER_REAL,wall)
cap=1 if mode=='cpu' else 2
command=['/usr/bin/prlimit',f'--cpu={cap}:{cap}','--as=268435456:536870912','--',sys.executable,'-B',str(root/'engineering_probe_driver.py'),mode,str(out/'payload.json')]
r=collect_driver(command,dict(os.environ),4,start+wall,out/'stdout.txt',out/'stderr.txt');u=r['usage'];s=resource.getrusage(resource.RUSAGE_SELF)
record={'mode':mode,'driver_exit':r['returncode'],'driver_raw_wait_status':r['raw_wait_status'],'driver_reaped':True,'driver_full_CPU':u.ru_utime+u.ru_stime,'guard_self_CPU_at_emit':s.ru_utime+s.ru_stime,'guard_peak_RSS_kib':s.ru_maxrss,'wall_at_emit':time.monotonic()-start,'CPU_per_driver_OS_cap':cap,'driver_CPU_above_nominal_cap':max(0,u.ru_utime+u.ru_stime-cap),'collector_sha256':hashlib.sha256((root/'guard_collect_blocking.py').read_bytes()).hexdigest(),'candidate_calls':0,'data_reads':0,'proc_CPU_meter_used':False,'alarm_active_through_exit':True}
if (out/'payload.json').exists():record['payload_resource_fields']=json.loads((out/'payload.json').read_text())
with (out/'RAW_COLLECTOR.json').open('x') as f:json.dump(record,f,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
