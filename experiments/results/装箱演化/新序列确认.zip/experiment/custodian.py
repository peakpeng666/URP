"""One approved data materialization; no policy imports, scores, or seed disclosure."""
from pathlib import Path
import hashlib,hmac,json,os,sys
from control import ROOT,read,put,sha,canon,need

def generate():
 import numpy as np
 need(np.__version__=='2.3.5','exact generation NumPy')
 plan=read(ROOT/'PROTOCOL_DRAFT.json');plan_hash=sha((ROOT/'PROTOCOL_DRAFT.json').read_bytes());custody=ROOT/'custody'
 put(custody/'GENERATION_ONCE_CLAIM.json',{'schema':'C1-master-once-claim-v1','protocol_sha256':plan_hash,'entropy_draws_max':1,'instances':20,'no_reroll':True})
 master=os.getrandom(32);need(len(master)==32,'single complete CSPRNG draw required')
 with (custody/'master.bin').open('xb') as f:f.write(master);f.flush();os.fsync(f.fileno())
 commitment=sha(b'confirmation-C1-master-v1|'+master)
 put(custody/'MASTER_COMMITMENT.json',{'protocol_sha256':plan_hash,'master_commitment_sha256':commitment,'master_values_disclosed':False})
 exclusions=read(ROOT/'PUBLIC_EXCLUSION_MANIFEST.json');seen=set();entries=[]
 for i in range(20):
  message=('confirmation-C1-instance-v1|'+plan_hash+'|'+f'{i:02d}').encode()
  seed=int.from_bytes(hmac.new(master,message,hashlib.sha256).digest()[:16],'big')
  rng=np.random.Generator(np.random.PCG64(seed));items=np.round(np.clip(45*rng.weibull(3,size=5000),1,100)).astype(np.int64).tolist()
  need(len(items)==5000 and all(type(x) is int and 1<=x<=100 for x in items),'domain')
  ih=sha(canon(items).encode());need(ih not in seen,'duplicate new full instance; no replacement')
  for e in exclusions['entries']:need(sha(canon(items[:e['n']]).encode())!=e['items_sha256'],'duplicate against frozen public prefix/full; no replacement')
  seen.add(ih);obj={'items':items,'capacity':100};rel='custody/instances/'+f'{i:02d}.json';put(ROOT/rel,obj)
  entries.append({'global_instance_index':i,'relative_file':rel,'file_sha256':sha((ROOT/rel).read_bytes()),'input_sha256':sha(canon(obj).encode()),'items_sha256':ih,'n':5000,'capacity':100})
 manifest={'schema':'C1-new-prospective-data-manifest-v1','protocol_sha256':plan_hash,'generator_source_sha256':sha(Path(__file__).read_bytes()),'seed_method_spec_sha256':sha((ROOT/'SEED_METHOD_SPEC.json').read_bytes()),'methods_file_sha256':sha((ROOT/'METHODS_FROZEN.json').read_bytes()),'preparation_freeze_sha256':sha((ROOT/'PREPARATION_FREEZE.json').read_bytes()),'master_commitment_file_sha256':sha((custody/'MASTER_COMMITMENT.json').read_bytes()),'public_exclusion_manifest_sha256':sha((ROOT/'PUBLIC_EXCLUSION_MANIFEST.json').read_bytes()),'python':sys.version,'numpy_version':np.__version__,'instances':entries,'generation_attempts':1,'entropy_draws':1,'quality_or_policy_filter_used':False,'policy_evaluations':0,'old_heldout_reads':0,'private_seed_in_manifest':False}
 put(ROOT/'DATA_MANIFEST.json',manifest)
 return {'instances':20,'data_manifest_sha256':sha((ROOT/'DATA_MANIFEST.json').read_bytes()),'generator_policy_evaluations':0,'seeds_or_data_in_chat':False,'formal_confirmation_runs':0}
if __name__=='__main__':raise SystemExit('Use the guarded preparation action; no direct entrypoint.')
