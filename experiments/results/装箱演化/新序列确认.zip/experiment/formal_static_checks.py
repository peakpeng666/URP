"""Trusted metadata/synthetic analysis checks only; no instance values or policy execution."""
from pathlib import Path
import ast,copy,json,time
from fractions import Fraction
from control import ROOT,read,put,sha,digest
from analysis_locked import analyze,METHODS
start=time.process_time();checks=[]
for n in ['formal_driver.py','formal_guard.py','formal_dispatch.py']:ast.parse((ROOT/n).read_text())
checks.append('formal_sources_parse')
plan=read(ROOT/'FORMAL_PLAN.json');manifest=read(ROOT/'DATA_MANIFEST.json');methods=read(ROOT/'METHODS_FROZEN.json')['methods'];packs=plan['packs']
assert len(packs)==100 and len({p['action_id'] for p in packs})==100
assert {(p['global_instance_index'],p['method']) for p in packs}=={(i,m) for i in range(20) for m in METHODS}
assert len({p['runtime_execution_id'] for p in packs})==100
for p in packs:
 d=manifest['instances'][p['global_instance_index']]
 assert p['input_sha256']==d['input_sha256'] and p['data_file_sha256']==d['file_sha256'] and p['relative_data_file']==d['relative_file']
 assert p['runtime_execution_id']==p['runtime_claim_id']+'/instance/'+str(p['local_instance_index'])
 assert p['local_instance_index']==p['global_instance_index']%5 and p['group_index']==p['global_instance_index']//5
 assert p['code_sha256']==methods[p['method']]['code_sha256']
checks.extend(['100_unique_actions_and_runtime_ids','20_by_5_complete_fixed_pairs','manifest_hash_identity','legacy_5_slot_ABI_mapping','exact_frozen_method_code_identity'])
for mid in METHODS:
 t='toy_EOH_locked_ABI_v2' if mid=='EOH_locked' else 'toy_'+mid
 w=read(ROOT/'results'/(t+'.json'))['payload']['original_pack_report']['worker']
 pre=read(ROOT/'results'/('admission_'+mid+'.json'))['payload']['admission']
 assert sha(w['admission']['canonical_text'].encode())==sha(pre['canonical_text'].encode())
checks.append('real_preparation_receipts_canonical_text_contract_no_new_execution')
rows=[{'global_instance_index':i,'method':m,'status':'ok','checker_status':'passed','used_bins':100+i+METHODS.index(m),'L1':99} for i in range(20) for m in METHODS]
a=analyze(rows,'synthetic_dataset_hash','synthetic_analysis_hash',bootstrap=True)
f=sum((Fraction(99,100+i)-Fraction(99,101+i) for i in range(20)),Fraction())/20
assert a['primary_EOH_minus_IID']['mean_F_difference']['numerator']==f.numerator and a['primary_EOH_minus_IID']['mean_F_difference']['denominator']==f.denominator
assert a['primary_EOH_minus_IID']['paired_instances']==20 and a['primary_EOH_minus_IID']['interval']['resamples']==20000
bad=copy.deepcopy(rows);bad[0].update(status='numeric_failure',used_bins=None,checker_status='not_run')
b=analyze(bad,'synthetic_dataset_hash','synthetic_analysis_hash',bootstrap=False)
assert b['full20_means']['EOH_locked'] is None and b['primary_EOH_minus_IID'] is None and b['coverage']['EOH_locked']=={'complete':19,'denominator':20}
checks.extend(['synthetic_exact_paired_fraction','synthetic_20000_paired_bootstrap','failure_keeps_denominator20_and_full_metric_null'])
assert read(ROOT/'FORMAL_SWITCH.json')['enabled'] is False
assert not list((ROOT/'claims').glob('confirm_*.json')) and not (ROOT/'FORMAL_DISPATCH_CLAIM.json').exists()
checks.append('formal_not_started')
put(ROOT/'FORMAL_STATIC_REVIEW.json',{'status':'PASS_TRUSTED_METADATA_AND_SYNTHETIC_ONLY','checks':checks,'candidate_calls':0,'new_data_values_read':False,'new_data_seeds_read':False,'new_confirmation_scores_read':False,'CPU_seconds_before_report_write':time.process_time()-start,'cost_scope':'Included in already debited 200 CPU/600 wall trusted preparation envelope, not a new numeric claim.'})
print(json.dumps({'checks':len(checks),'status':'passed','candidate_calls':0,'new_instance_values_read':False,'CPU':time.process_time()-start}))
