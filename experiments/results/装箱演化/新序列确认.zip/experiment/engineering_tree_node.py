"""Three trusted dummy layers with parent-death guards; no experiment data/source."""
import os,sys,time,signal,resource,subprocess,ctypes,json
from pathlib import Path
role,mode,out=sys.argv[1:];out=Path(out)
if role=='driver':assert sys.stdin.read(1)=='G'
stat=Path('/proc/self/stat').read_text();fields=stat[stat.rfind(')')+2:].split()
(out/(role+'.identity.json')).write_text(json.dumps({'pid':os.getpid(),'ppid':os.getppid(),'starttime_ticks':fields[19],'pid_namespace':os.readlink('/proc/self/ns/pid')}))
parent=os.getpid();libc=ctypes.CDLL(None,use_errno=True)
def death_guard():
 if libc.prctl(1,signal.SIGKILL,0,0,0)!=0 or os.getppid()!=parent:os._exit(76)
if role!='worker':
 child=subprocess.Popen([sys.executable,'-B',__file__,'supervisor' if role=='driver' else 'worker',mode,str(out)],preexec_fn=death_guard)
 if mode=='cpu':
  while True:
   pid,status,u=os.wait4(child.pid,os.WNOHANG)
   if pid:child.returncode=os.waitstatus_to_exitcode(status);break
 else:
  pid,status,u=os.wait4(child.pid,0);child.returncode=os.waitstatus_to_exitcode(status)
 (out/(role+'.child_wait4.json')).write_text(json.dumps({'child_pid':pid,'child_exit':child.returncode,'child_CPU':u.ru_utime+u.ru_stime,'child_reaped':True}))
 if child.returncode:raise SystemExit(child.returncode)
else:
 if mode=='long_success':time.sleep(88.2)
 elif mode=='pdeath':time.sleep(30)
 else:
  while True:pass
if role=='driver':
 s=resource.getrusage(resource.RUSAGE_SELF);c=resource.getrusage(resource.RUSAGE_CHILDREN)
 (out/'payload.json').write_text(json.dumps({'self_at_payload':s.ru_utime+s.ru_stime,'child_at_payload':c.ru_utime+c.ru_stime}))
 t=time.process_time()
 while time.process_time()-t<.08:pass
