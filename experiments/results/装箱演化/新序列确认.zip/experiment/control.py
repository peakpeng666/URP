"""Small durable preparation ledger. No solver, source execution, or data access."""
from pathlib import Path
import fcntl,hashlib,json,os,resource,time
ROOT=Path(__file__).resolve().parent
METHOD_IDS=('EOH_locked','IID_locked','FF','BF','published_EoH')
def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
def sha(b):return hashlib.sha256(b).hexdigest()
def digest(x):return sha(canon(x).encode())
def read(p):return json.loads(Path(p).read_text())
def need(x,msg):
 if not x:raise RuntimeError(msg)
def put(p,x):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:f.write((canon(x)+'\n').encode());f.flush();os.fsync(f.fileno())
 fd=os.open(p.parent,os.O_RDONLY|os.O_DIRECTORY)
 try:os.fsync(fd)
 finally:os.close(fd)
def verify_package():
 m=read(ROOT/'PREPARATION_FREEZE.json')
 for n,h in m['files'].items():need(sha((ROOT/n).read_bytes())==h,'preparation source drift '+n)
 return m
def totals(claims,scope):
 cpu=scope['preparation_fixed_debit']['CPU_seconds']+sum(c['reserve_CPU_seconds'] for c in claims)
 wall=scope['preparation_fixed_debit']['active_wall_seconds']+sum(c['reserve_wall_seconds'] for c in claims)
 need(cpu<=scope['CPU_ceiling'] and wall<=scope['active_wall_ceiling'],'forward budget cap')
 for kind,cap in [('admission',5),('toy',5),('data',1),('static',1)]:need(sum(c['kind']==kind for c in claims)<=cap,'stage attempt cap '+kind)
 need(all(c['kind'] in ('admission','toy','data','static') for c in claims),'formal execution not authorized')
 return {'reserved_CPU_seconds':cpu,'reserved_active_wall_seconds':wall}
def check_open(root=ROOT):
 need(not (root/'HALT.json').exists(),'HALT retained; no automatic dispatch')
 for p in (root/'claims').glob('*.json'):need((root/'results'/p.name).is_file(),'UNKNOWN permanent claim: '+p.stem)
class Action:
 def __init__(self,kind,method=None):
  os.umask(0o077);self.kind=kind;self.method=method;self.id=kind+('_'+method if method else '')
  self.lock=(ROOT/'GLOBAL_LOCK').open('a+b');fcntl.flock(self.lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  check_open();freeze=verify_package();self.scope=read(ROOT/'BUDGET_SCOPE.json');sw=read(ROOT/'EXECUTION_SWITCH.json')
  need(sw['preparation_enabled'] and sw['formal_confirmation_enabled'] is False,'preparation guard')
  need(kind in ('admission','toy','data','static'),'formal execution disabled')
  if kind in ('admission','toy'):need(method in METHOD_IDS,'fixed method')
  else:need(method is None,'unexpected method')
  if kind=='toy':
   for mid in METHOD_IDS:need(read(ROOT/'results'/('admission_'+mid+'.json'))['status']=='passed','all admissions first')
  if kind=='data':
   for mid in METHOD_IDS:
    for stage in ('admission','toy'):need(read(ROOT/'results'/(stage+'_'+mid+'.json'))['status']=='passed','all method gates before data')
  cpu,wall={'admission':(4,7),'toy':(123,92),'data':(100,300),'static':(3,2)}[kind]
  self.claim={'schema':'C1-preparation-once-only-claim-v1','action_id':self.id,'kind':kind,'method':method,'reserve_CPU_seconds':cpu,'reserve_wall_seconds':wall,'protocol_sha256':self.scope['protocol_sha256'],'preparation_freeze_sha256':digest(freeze),'no_retry':True}
  old=[read(p) for p in (ROOT/'claims').glob('*.json')];totals(old+[self.claim],self.scope)
  put(ROOT/'claims'/(self.id+'.json'),self.claim);self.started=time.monotonic()
 def finish(self,payload,status='passed'):
  own=resource.getrusage(resource.RUSAGE_SELF);child=resource.getrusage(resource.RUSAGE_CHILDREN)
  resource_record={'coordinator_self_CPU_at_emit':own.ru_utime+own.ru_stime,'reaped_descendant_CPU_inclusive':child.ru_utime+child.ru_stime,'CPU_at_emit_no_double_count':own.ru_utime+own.ru_stime+child.ru_utime+child.ru_stime,'action_wall_at_emit':time.monotonic()-self.started,'coordinator_peak_RSS_kib':own.ru_maxrss,'cost_scope':'Full interpreter self rusage and reaped descendants at emit; final serialization/exit tail not fabricated, covered by full reservation. Unknown work charged full reservation.','limits':{'CPU':resource.getrlimit(resource.RLIMIT_CPU),'AS':resource.getrlimit(resource.RLIMIT_AS)}}
  put(ROOT/'results'/(self.id+'.json'),{'schema':'C1-preparation-terminal-v1','action_id':self.id,'claim_sha256':digest(self.claim),'status':status,'payload':payload,'resources':resource_record})
  if status!='passed' and not (ROOT/'HALT.json').exists():put(ROOT/'HALT.json',{'action_id':self.id,'status':'HALT_no_retry','claim_retained':True,'reason':payload.get('exception','failed gate')})
  self.lock.close()
  return resource_record
