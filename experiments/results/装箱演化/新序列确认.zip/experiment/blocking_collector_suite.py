"""Raw wait4 first,then check short OS CPU cap,full tail and kernel wall alarm."""
from pathlib import Path
import os,sys,time,signal,resource,subprocess,ctypes,json
root=Path(__file__).resolve().parent;start=time.monotonic();libc=ctypes.CDLL(None,use_errno=True);assert libc.prctl(36,1,0,0,0)==0
resource.setrlimit(resource.RLIMIT_CPU,(3,3));signal.signal(signal.SIGALRM,signal.SIG_DFL);signal.setitimer(signal.ITIMER_REAL,100)
parent=os.getpid()
def death_guard():
 if libc.prctl(1,signal.SIGKILL,0,0,0)!=0 or os.getppid()!=parent:os._exit(76)
observations=[]
for mode in ['success','cpu','wall']:
 out=root/'engineering_tests'/('blocking_'+mode);child=subprocess.Popen([sys.executable,'-B',str(root/'blocking_collector_probe.py'),mode],preexec_fn=death_guard);events=[]
 while True:
  try:pid,status,u=os.wait4(-1,0)
  except ChildProcessError:break
  e={'pid':pid,'raw_wait_status':status,'exit':os.waitstatus_to_exitcode(status),'utime':u.ru_utime,'stime':u.ru_stime,'maxrss':u.ru_maxrss};events.append(e)
  with (out/('WAIT4_'+str(pid)+'.json')).open('x') as f:json.dump(e,f,sort_keys=True);f.write('\n')
  if pid==child.pid:child.returncode=e['exit']
 rec={'mode':mode,'guard_pid':child.pid,'all_outer_wait4':events,'outer_full_CPU_no_readding_inner':sum(e['utime']+e['stime'] for e in events),'guard_exit':child.returncode,'candidate_calls':0,'data_reads':0}
 with (out/'OUTER_RAW.json').open('x') as f:json.dump(rec,f,sort_keys=True);f.write('\n')
 observations.append(rec)
checks={}
success=json.loads((root/'engineering_tests/blocking_success/RAW_COLLECTOR.json').read_text());p=success['payload_resource_fields'];checks['full_exit_tail_included']=success['driver_full_CPU']>=p['self_at_payload']+p['child_at_payload']+.06 and success['driver_exit']==0
cpu=json.loads((root/'engineering_tests/blocking_cpu/RAW_COLLECTOR.json').read_text());checks['OS_CPU_hard_cap']=cpu['driver_exit']==-9 and .8<=cpu['driver_full_CPU']<=1.25
wall=observations[2];checks['kernel_alarm_and_PDEATH_reaped']=wall['guard_exit']==-signal.SIGALRM and len(wall['all_outer_wait4'])==2 and sorted(e['exit'] for e in wall['all_outer_wait4'])==[-signal.SIGALRM,-signal.SIGKILL]
s=resource.getrusage(resource.RUSAGE_SELF);c=resource.getrusage(resource.RUSAGE_CHILDREN);checks['test_reserved_CPU_upper']=c.ru_utime+c.ru_stime+3<=10
record={'status':'PASS' if all(checks.values()) else 'FAIL_RETAIN_RAW','checks':checks,'outer_observations':observations,'suite_self_CPU_at_emit':s.ru_utime+s.ru_stime,'all_children_complete_inclusive_CPU':c.ru_utime+c.ru_stime,'conservative_complete_tree_CPU_upper':c.ru_utime+c.ru_stime+3,'suite_self_effective_CPU3':True,'wall_at_emit':time.monotonic()-start,'reserve_CPU':10,'reserve_wall':100,'candidate_calls':0,'data_reads':0,'alarm_active_through_exit':True}
with (root/'PREP_BLOCKING_TEST_TERMINAL.json').open('x') as f:json.dump(record,f,sort_keys=True,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps({'status':record['status'],'checks':checks,'CPU':c.ru_utime+c.ru_stime+s.ru_utime+s.ru_stime,'wall':record['wall_at_emit']}),flush=True)
