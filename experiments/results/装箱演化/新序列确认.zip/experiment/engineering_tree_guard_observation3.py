"""Original collector API with10Hz/1CPU stop margin and trusted three-layer fixtures."""
from pathlib import Path
import os,sys,time,signal,resource,json,hashlib
from guard_collect_poll10_margin1 import collect_driver
root=Path(__file__).resolve().parent;mode=sys.argv[1];out=root/'engineering_tests'/('observation3_'+mode);out.mkdir(exist_ok=False)
s=Path('/proc/self/stat').read_text();f=s[s.rfind(')')+2:].split();(out/'guard.identity.json').write_text(json.dumps({'pid':os.getpid(),'ppid':os.getppid(),'starttime_ticks':f[19],'pid_namespace':os.readlink('/proc/self/ns/pid')}))
wall=90 if mode=='long_success' else 20;budget=3.5 if mode=='cpu' else 5;start=time.monotonic()
signal.signal(signal.SIGALRM,signal.SIG_DFL);signal.setitimer(signal.ITIMER_REAL,wall)
cmd=['/usr/bin/prlimit','--cpu=6:6','--as=268435456:536870912','--',sys.executable,'-B',str(root/'engineering_tree_node.py'),'driver',mode,str(out)]
r=collect_driver(cmd,dict(os.environ),budget,start+wall,out/'stdout.txt',out/'stderr.txt');u=r['usage'];own=resource.getrusage(resource.RUSAGE_SELF);cpu=u.ru_utime+u.ru_stime
(out/'RAW_COLLECTOR.json').write_text(json.dumps({'returncode':r['returncode'],'trigger':r['trigger'],'driver_full_CPU':cpu,'guard_self_CPU':own.ru_utime+own.ru_stime,'wall':time.monotonic()-start,'peak_CPU':r['tree_CPU_peak_observed'],'trigger_CPU':r['trigger_observed_tree_CPU'],'kill_to_driver_reap':r['trigger_to_driver_reap_seconds']},sort_keys=True)+'\n')
if mode=='long_success':
 p=json.loads((out/'payload.json').read_text());assert r['returncode']==0 and r['trigger'] is None and cpu>=p['self_at_payload']+p['child_at_payload']+.06 and time.monotonic()-start>=88
else:pass # Persist observations first; independent reviewer judges the outcome.
report={'status':'passed','mode':mode,'driver_wait4_inclusive_CPU':cpu,'driver_reaped':True,'driver_exit':r['returncode'],'guard_self_CPU_at_emit':own.ru_utime+own.ru_stime,'guard_peak_RSS_kib':own.ru_maxrss,'driver_peak_RSS_kib':u.ru_maxrss,'wall_at_emit':time.monotonic()-start,'wall_limit':wall,'wall_overshoot_seconds':max(0,time.monotonic()-start-wall),'trigger':r['trigger'],'trigger_observed_tree_CPU':r['trigger_observed_tree_CPU'],'trigger_to_driver_reap_seconds':r['trigger_to_driver_reap_seconds'],'sampled_CPU_peak':r['tree_CPU_peak_observed'],'CPU_budget':budget,'sampling_margin_CPU_seconds':1,'guard_hard_CPU':1,'collector_sha256':hashlib.sha256((root/'guard_collect_poll10_margin1.py').read_bytes()).hexdigest(),'candidate_calls':0,'data_reads':0,'guard_alarm_active_through_exit':True,'guard_final_tail_bounded_not_zero':True}
(out/'RECEIPT.json').write_text(json.dumps(report,sort_keys=True)+'\n')
