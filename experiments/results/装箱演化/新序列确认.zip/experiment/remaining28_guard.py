"""Explicitly disabled-by-default formal gate,reusing the audited wait4 collector."""
from pathlib import Path
from datetime import datetime,timezone
import fcntl,os,resource,signal,sys,time
sys.dont_write_bytecode=True;os.umask(0o077)
from control import ROOT,read,put,need,sha,digest,canon
from guard_collect_blocking import collect_driver,valid_new_terminal

def main():
 resource.setrlimit(resource.RLIMIT_CPU,(1,300));signal.signal(signal.SIGXCPU,signal.SIG_DFL);signal.pthread_sigmask(signal.SIG_UNBLOCK,{signal.SIGXCPU})
 need(len(sys.argv)==3 and sys.argv[1]=='--enable-formal','explicit formal flag required');aid=sys.argv[2]
 lock=(ROOT/'GLOBAL_LOCK').open('a+b');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 need(read(ROOT/'REMAINING28_SWITCH.json')['enabled'] is True,'formal switch disabled')
 freeze=read(ROOT/'REMAINING28_FREEZE.json');fh=sha((ROOT/'REMAINING28_FREEZE.json').read_bytes())
 for n,h in freeze['files'].items():need(sha((ROOT/n).read_bytes())==h,'formal frozen file drift '+n)
 policy=read(ROOT/'REMAINING28_POLICY.json');plan=read(ROOT/'REMAINING28_RUNTIME_PLAN.json')
 seal_hash=sha((ROOT/'REMAINING28_SEAL.json').read_bytes());auth=read(ROOT/'REMAINING28_AUTHORIZATION.json')
 need(auth.get('remaining28_execution_authorized') is True and auth.get('remaining28_freeze_sha256')==fh and auth.get('remaining28_seal_sha256')==seal_hash,'specific parent activation required')
 audit=read(Path(policy['independent_pass_path']))
 need(audit.get('status')=='PASS_REMAINING28_NOT_ACTIVATED' and audit.get('remaining28_freeze_sha256')==fh and audit.get('remaining28_seal_sha256')==seal_hash,'formal independent audit required')
 need(auth.get('independent_audit_sha256')==sha(Path(policy['independent_pass_path']).read_bytes()),'parent pinned independent audit')
 need(not (ROOT/'REMAINING28_HALT.json').exists(),'formal HALT preserved; no implicit restart')
 dispatch=read(ROOT/'REMAINING28_DISPATCH_CLAIM.json')
 need(dispatch['remaining28_freeze_sha256']==fh and dispatch['seal_sha256']==seal_hash and dispatch['reserve_CPU_seconds']==22 and dispatch['reserve_wall_seconds']==60,'persistent dispatcher debit identity')
 need(os.getppid()==dispatch['pid'] and os.environ.get('C1_DISPATCH_PID')==str(dispatch['pid']),'one authorized dispatcher parent')
 for n,h in policy['preserved_files'].items():need(sha((ROOT/n).read_bytes())==h,'preparation record drift '+n)
 entries={x['action_id']:x for x in plan['packs']};need(aid in entries or aid=='analysis_remaining28','fixed100/analysis only')
 claims=[read(p) for p in (ROOT/'claims').glob('*.json')];old=set(policy['preserved_claim_ids']);new=set(entries)|{'analysis_remaining28'}
 for c in claims:
  name=c['action_id'];need(name in old|new,'unexpected claim')
  if name in policy['unknown_original_actions']:
   need(not (ROOT/'results'/(name+'.json')).exists() and not (ROOT/'payloads'/(name+'.json')).exists(),'original unknown preserved without invented terminal');continue
  need((ROOT/'results'/(name+'.json')).is_file(),'UNKNOWN claim; no dispatch')
  if name in new:need(valid_new_terminal(c,read(ROOT/'results'/(name+'.json'))),'formal terminal mismatch/failed/unreaped')
 need(not (ROOT/'claims'/(aid+'.json')).exists(),'permanent action consumed')
 completed={c['action_id'] for c in claims if c['action_id'] in entries}
 if aid=='analysis_remaining28':need(len(completed)==28,'analysis waits for100 terminal packs')
 else:
  expected=next(x['action_id'] for x in plan['packs'] if x['action_id'] not in completed);need(aid==expected,'fixed instance-major rotated schedule')
 cpu,wall=(303,523) if aid=='analysis_remaining28' else (125,93)
 # Persistent single dispatcher claim is charged once; any restart requires a new reviewed segment.
 total_cpu=200+policy['extra_test_debit_CPU']+policy['prior_dispatch_debit_CPU']+dispatch['reserve_CPU_seconds']+sum(c['reserve_CPU_seconds'] for c in claims)+cpu;total_wall=600+policy['extra_test_debit_wall']+policy['prior_dispatch_debit_wall']+dispatch['reserve_wall_seconds']+sum(c['reserve_wall_seconds'] for c in claims)+wall
 need(total_cpu<=14200 and total_wall<=12000,'same forward ceiling; stop before insufficient worst-case budget')
 started=time.monotonic();deadline=started+wall
 signal.signal(signal.SIGALRM,signal.SIG_DFL);signal.setitimer(signal.ITIMER_REAL,wall)
 claim={'schema':'C1-formal-once-only-claim-v1','action_id':aid,'kind':'analysis_remaining28' if aid=='analysis_remaining28' else 'formal','reserve_CPU_seconds':cpu,'reserve_wall_seconds':wall,'remaining28_freeze_sha256':fh,'seal_sha256':seal_hash,'claimed_at_utc':datetime.now(timezone.utc).isoformat(),'no_retry':True}
 if aid=='analysis_remaining28':
  def ref(x):
   cid=x['action_id'];tp=ROOT/'results'/(cid+'.json')
   return {'action_id':cid,'claim_sha256':sha((ROOT/'claims'/(cid+'.json')).read_bytes()),'terminal_sha256':sha(tp.read_bytes()) if tp.exists() else None}
  raw={'schema':'C1-two-analysis-raw-membership-freeze-v1','strict_original':[ref(x) for x in read(ROOT/'FORMAL_PLAN.json')['packs']],'technical_extra':ref(next(x for x in plan['packs'] if x['action_id']==policy['specific_extra_action'])),'unknown_original':policy['unknown_original_actions'],'no_original_unknown_replacement':True}
  put(ROOT/'RAW_TERMINAL_SET_AFTER_SECOND_HALT.json',raw);claim['raw_terminal_set_sha256']=sha((ROOT/'RAW_TERMINAL_SET_AFTER_SECOND_HALT.json').read_bytes())
 put(ROOT/'claims'/(aid+'.json'),claim)
 env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1','OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','BLIS_NUM_THREADS':'1','C1_GUARD_PID':str(os.getpid())}
 soft_cpu,hard_cpu,soft_as=(299,300,536870912) if aid=='analysis_remaining28' else (2,200,268435456)
 command=['/usr/bin/prlimit',f'--cpu={soft_cpu}:{hard_cpu}',f'--as={soft_as}:536870912','--nofile=64:64','--core=0:0','--',sys.executable,'-B',str(ROOT/'remaining28_driver.py'),aid]
 c=collect_driver(command,env,cpu,deadline,ROOT/'logs'/(aid+'.stdout.txt'),ROOT/'logs'/(aid+'.stderr.txt'));u=c['usage'];self_usage=resource.getrusage(resource.RUSAGE_SELF);driver_cpu=u.ru_utime+u.ru_stime
 payload_file=ROOT/'payloads'/(aid+'.json');status='passed' if c['returncode']==0 and c['trigger'] is None and payload_file.is_file() and driver_cpu+1<=cpu and time.monotonic()<=deadline else 'blocked_no_retry'
 payload=read(payload_file) if status=='passed' else {'exception':'formal guarded driver failed/missing/limit','returncode':c['returncode'],'trigger':c['trigger']}
 record={'schema':'C1-formal-guard-terminal-v1','action_id':aid,'claim_sha256':digest(claim),'status':status,'completed_at_utc':datetime.now(timezone.utc).isoformat(),'payload':payload,'resources':{'driver_pid':c['pid'],'driver_reaped':True,'driver_exit_code':c['returncode'],'driver_wait4_inclusive_CPU_seconds':driver_cpu,'guard_self_CPU_at_emit':self_usage.ru_utime+self_usage.ru_stime,'conservative_complete_tree_CPU_upper_seconds':driver_cpu+1,'driver_peak_RSS_kib':u.ru_maxrss,'wall_at_emit':time.monotonic()-started,'guard_trigger':c['trigger'],'guard_CPU_hard_limit_seconds':1,'guard_wall_alarm_active_through_exit':True,'cumulative_reserved_CPU_seconds':total_cpu,'cumulative_reserved_wall_seconds':total_wall}}
 put(ROOT/'results'/(aid+'.json'),record)
 if status!='passed':put(ROOT/'REMAINING28_HALT.json',{'action_id':aid,'status':'HALT_permanent_claim_preserved','no_retry':True})
 print(canon({'action':aid,'status':status,'driver_exit':c['returncode'],'formal_scores_not_streamed':True}));return status=='passed'
if __name__=='__main__':sys.exit(not main())
