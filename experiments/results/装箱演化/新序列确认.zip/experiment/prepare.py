"""Approved preparation only: one static check,5 admissions,5 toy packs,one data generation.
There is deliberately no formal confirmation evaluation command.
"""
import os,sys,time,resource,signal,copy
os.umask(0o077);sys.dont_write_bytecode=True
from control import ROOT,METHOD_IDS,Action,read,put,need,sha,digest,canon

def effective_limits(kind):
 # Effective soft limits bound this trusted driver, while inherited hard limits
 # permit unchanged original prlimit children to set60CPU and512MiB.
 soft_cpu=100 if kind=='data' else 3
 soft_as=512*1024**2 if kind=='data' else 256*1024**2
 resource.setrlimit(resource.RLIMIT_CPU,(soft_cpu,200))
 resource.setrlimit(resource.RLIMIT_AS,(soft_as,512*1024**2))
 resource.setrlimit(resource.RLIMIT_NOFILE,(64,64));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
 signal.signal(signal.SIGXCPU,signal.SIG_DFL)

def fixed_source(mid):
 registry=read(ROOT/'METHODS_FROZEN.json');m=registry['methods'][mid]
 candidate={k:m[k] for k in ('description','code','description_sha256','code_sha256','pair_sha256','description_consistency')}
 need(sha(candidate['code'].encode())==candidate['code_sha256'],'exact source')
 sys.path.insert(0,str(ROOT/'frozen_runtime'))
 from resource_profile import PRODUCTION_PROFILE_ID,profile_sha256
 from policy import policy_sha256
 claim=digest(['C1-preparation',mid]);binding={'batch_id':'C1-preparation-20261007','wave_id':'C1-predata-method-gates','slot_id':mid,'raw_response_sha256':digest(m),'source_sha256':candidate['code_sha256'],'policy_sha256':policy_sha256(),'runtime_freeze_sha256':'7903fec4a38568000f7dc8901e49cfff6f246529129aacab2c94c179b1d1aeb8','claim_sha256':digest(['C1-new-source-claim',claim]),'claim_id':claim,'registry_sha256':digest(registry),'resource_profile_sha256':profile_sha256(PRODUCTION_PROFILE_ID)}
 return candidate,binding,m['origin']

def do_admission(mid):
 c,b,origin=fixed_source(mid)
 from runner import Session
 w=Session(c,b,worker_role='admission',execution_id=b['claim_id']+'/admission')
 admitted=copy.deepcopy(w.admission);w.close();ev=w.evidence()
 need(ev['source_after_host_gate'] and ev['reaped'] and ev['cleanup_error'] is None,'original admission gate and cleanup')
 need(admitted['admitted'] is True,'admission rejected; no source repair or retry')
 return {'method':mid,'origin':origin,'candidate_source_sha256':c['code_sha256'],'binding':b,'admission':admitted,'worker':ev,'formal_confirmation':False}

def do_toy(mid):
 c,b,origin=fixed_source(mid);fixture=read(ROOT/'TOY_FROZEN.json');items=fixture['items'];need(len(items)<=16 and fixture['fixture_only'],'toy bound')
 from supervised_runner import supervised_pack
 from checker import check_assignment
 report=supervised_pack(items,100,c,b,execution_id=b['claim_id']+'/toy/0',instance_index=0)
 need(report['outcome']=='ok','toy numeric gate failed; no retry')
 checked=check_assignment(items,100,report['result']);w=report['worker'];sup=report['supervisor_evidence']
 need(w['source_after_host_gate'] and w['reaped'] and sup['reaped'] and w['cleanup_error'] is None and sup['cleanup_error'] is None,'original toy gate and cleanup')
 if mid in ('FF','BF'):
  remaining=[100]*len(items)
  for item,chosen in zip(items,report['result']['assignment']):
   feasible=[i for i,v in enumerate(remaining) if v>=item]
   expected=feasible[0] if mid=='FF' else min(feasible,key=lambda i:(remaining[i],i))
   need(chosen==expected,'fixed baseline assignment semantics');remaining[chosen]-=item
 return {'method':mid,'origin':origin,'fixture_only':True,'fixture_sha256':sha((ROOT/'TOY_FROZEN.json').read_bytes()),'formal_confirmation':False,'checker':checked,'original_pack_report':report}

def main():
 need(len(sys.argv) in (2,3),'usage: prepare.py static|admission METHOD|toy METHOD|data')
 kind=sys.argv[1];mid=sys.argv[2] if len(sys.argv)==3 else None
 need(kind in ('static','admission','toy','data'),'formal confirmation is not implemented or authorized')
 effective_limits(kind);action=Action(kind,mid)
 def timeout(_s,_f):raise TimeoutError('C1 action wall budget; permanent claim consumed')
 signal.signal(signal.SIGALRM,timeout);signal.alarm(action.claim['reserve_wall_seconds'])
 try:
  if kind=='static':
   from static_checks import run
   payload=run()
  elif kind=='admission':payload=do_admission(mid)
  elif kind=='toy':payload=do_toy(mid)
  else:
   from custodian import generate
   payload=generate()
  signal.alarm(0);cost=action.finish(payload)
  print(canon({'action':action.id,'status':'passed','measured_CPU_at_emit':cost['CPU_at_emit_no_double_count'],'wall_at_emit':cost['action_wall_at_emit'],'formal_confirmation_runs':0,'private_values_disclosed':False}))
 except BaseException as exc:
  signal.alarm(0)
  payload={'exception':type(exc).__name__+': '+str(exc),'worker_evidence':getattr(exc,'worker_evidence',None),'supervisor_evidence':getattr(exc,'supervisor_evidence',None),'no_retry':True}
  try:action.finish(payload,status='blocked_no_retry')
  except BaseException:pass
  print(canon({'action':action.id,'status':'blocked_no_retry','exception':payload['exception']}));raise
if __name__=='__main__':main()
