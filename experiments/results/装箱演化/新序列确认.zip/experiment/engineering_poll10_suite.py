"""Finite four no-candidate probes,one permanent extra preparation debit."""
import os,sys,time,signal,resource,subprocess,ctypes,json
from pathlib import Path
root=Path(__file__).resolve().parent
resource.setrlimit(resource.RLIMIT_CPU,(3,3));resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912))
signal.signal(signal.SIGXCPU,signal.SIG_DFL);signal.signal(signal.SIGALRM,signal.SIG_DFL);signal.setitimer(signal.ITIMER_REAL,120)
parent=os.getpid();libc=ctypes.CDLL(None,use_errno=True);started=time.monotonic()
def death_guard():
 if libc.prctl(1,signal.SIGKILL,0,0,0)!=0 or os.getppid()!=parent:os._exit(76)
for mode in ['long_success','failure','cpu','wall']:
 rc=subprocess.run([sys.executable,'-B',str(root/'engineering_poll10_guard.py'),mode],cwd=root,preexec_fn=death_guard).returncode
 if rc:raise SystemExit(rc)
s=resource.getrusage(resource.RUSAGE_SELF);c=resource.getrusage(resource.RUSAGE_CHILDREN);assert c.ru_utime+c.ru_stime+3<=20
p=root/'PREP_POLL10_TEST_TERMINAL.json'
with p.open('x') as f:json.dump({'status':'passed','all_four_probe_processes_reaped':True,'suite_self_CPU_at_emit':s.ru_utime+s.ru_stime,'suite_self_hard_CPU':3,'all_reaped_children_inclusive_full_CPU':c.ru_utime+c.ru_stime,'complete_tree_conservative_CPU_upper':c.ru_utime+c.ru_stime+3,'wall_at_emit':time.monotonic()-started,'suite_wall_alarm_active_through_exit':True,'candidate_calls':0,'data_reads':0,'reserve_CPU':20,'reserve_wall':120},f,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
