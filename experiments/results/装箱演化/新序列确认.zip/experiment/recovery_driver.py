"""One immutable formal pack,or results-only analysis,under the reviewed outer guard."""
import os,sys,signal,json
from pathlib import Path
sys.dont_write_bytecode=True;os.umask(0o077)
from control import ROOT,read,put,need,sha,digest
need(len(sys.argv)==2,'one immutable formal action');aid=sys.argv[1]
need(os.getppid()==int(os.environ['C1_GUARD_PID']),'guard parent identity')
signal.signal(signal.SIGXCPU,signal.SIG_DFL);signal.pthread_sigmask(signal.SIG_UNBLOCK,{signal.SIGXCPU})
need(sys.stdin.read(1)=='G','guard release')
plan=read(ROOT/'RECOVERY_PLAN.json')
if aid=='analysis_recovery':
 from analysis_recovery_locked import analyze_both
 frozen=read(ROOT/'RAW_TERMINAL_SET_FROZEN.json');claim=read(ROOT/'claims/analysis_recovery.json')
 need(sha((ROOT/'RAW_TERMINAL_SET_FROZEN.json').read_bytes())==claim['raw_terminal_set_sha256'],'raw set frozen before analysis')
 original=read(ROOT/'FORMAL_PLAN.json');rows=[]
 def record(x,reference):
  term_path=ROOT/'results'/(x['action_id']+'.json');need(sha(term_path.read_bytes())==reference['terminal_sha256'],'immutable raw terminal')
  term=read(term_path);need(term['status']=='passed','infrastructure-terminal gate');p=term['payload']
  need(p['global_instance_index']==x['global_instance_index'] and p['method']==x['method'] and p['input_sha256']==x['input_sha256'] and p['code_sha256']==x['code_sha256'],'analysis exact input/source identity')
  return {'global_instance_index':p['global_instance_index'],'method':p['method'],'status':p['outcome'],'checker_status':p['checker']['checker_status'] if p['checker'] else 'not_run','used_bins':p['checker']['used_bins'] if p['checker'] else None,'L1':p['L1']}
 refs={z['action_id']:z for z in frozen['strict_original']}
 for x in original['packs']:
  if x['action_id']=='confirm_00_IID_locked':
   need(refs[x['action_id']]['terminal_sha256'] is None,'unknown never rewritten as passed')
   rows.append({'global_instance_index':0,'method':'IID_locked','status':'infrastructure_unknown_original_claim','checker_status':'not_available','used_bins':None,'L1':None})
  else:rows.append(record(x,refs[x['action_id']]))
 extra=next(z for z in plan['packs'] if z['action_id']=='technical_completion_00_IID_locked_v1')
 output=analyze_both(rows,record(extra,frozen['technical_extra']),plan['data_manifest_sha256'],sha((ROOT/'analysis_locked.py').read_bytes()))
 output['raw_terminal_set_sha256']=claim['raw_terminal_set_sha256']
 put(ROOT/'CONFIRMATION_ANALYSIS_STRICT_AND_TECHNICAL.json',output)
 payload={'analysis_file_sha256':sha((ROOT/'CONFIRMATION_ANALYSIS_STRICT_AND_TECHNICAL.json').read_bytes()),'analysis_complete':True,'candidate_execution':False,'strict_primary_null':True}
else:
 x=next((x for x in plan['packs'] if x['action_id']==aid),None);need(x is not None,'fixed100 action ID')
 raw=(ROOT/x['relative_data_file']).read_bytes();need(sha(raw)==x['data_file_sha256'],'sealed data bytes')
 data=json.loads(raw);items=data['items'];need(data['capacity']==100 and len(items)==5000 and all(type(v) is int and 1<=v<=100 for v in items),'data domain')
 need(digest(data)==x['input_sha256'],'instance binding')
 from prepare_abi_v2 import fixed_source
 candidate,binding,origin=fixed_source(x['method']);need(candidate['code_sha256']==x['code_sha256'],'fixed source identity')
 binding.update(batch_id=plan['run_id'],wave_id=plan['run_id']+'-group'+str(x['group_index']),slot_id=x['method']+'-group'+str(x['group_index']),claim_id=x['runtime_claim_id'],claim_sha256=digest(['C1-formal-source-claim',x['runtime_claim_id']]),registry_sha256=plan['typed_registry_sha256'])
 from supervised_runner import supervised_pack
 from checker import check_assignment
 report=supervised_pack(items,100,candidate,binding,execution_id=x['runtime_execution_id'],instance_index=x['local_instance_index'])
 checked=check_assignment(items,100,report['result']) if report['outcome']=='ok' else None
 worker=report['worker'];sup=report['supervisor_evidence']
 need(worker['reaped'] and sup['reaped'] and worker['cleanup_error'] is None and sup['cleanup_error'] is None,'complete cleanup')
 pre=read(ROOT/'results'/('admission_'+x['method']+'.json'))['payload']['admission']
 if report['outcome']=='ok':need(sha(worker['admission']['canonical_text'].encode())==sha(pre['canonical_text'].encode()),'unchanged child AST identity')
 payload={'schema':'C1-formal-pack-result-v1','global_instance_index':x['global_instance_index'],'method':x['method'],'source_origin':origin,'code_sha256':candidate['code_sha256'],'description_sha256':candidate['description_sha256'],'input_sha256':x['input_sha256'],'n':5000,'capacity':100,'L1':(sum(items)+99)//100,'outcome':report['outcome'],'checker':checked,'original_pack_report':report,'no_zero_imputation':True,'candidate_reselection':False}
put(ROOT/'payloads'/(aid+'.json'),payload)
