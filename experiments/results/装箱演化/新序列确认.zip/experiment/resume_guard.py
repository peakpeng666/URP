"""Narrow reviewed continuation guard: durable claims,wait4 tail,CPU/tree and wall bounds."""
from pathlib import Path
from datetime import datetime,timezone
import ctypes,fcntl,hashlib,json,os,resource,signal,subprocess,sys,time
sys.dont_write_bytecode=True;os.umask(0o077)
from control import ROOT,read,put,need,sha,digest,canon,verify_package

from guard_collect import tree_cpu,collect_driver,valid_new_terminal

def main():
 need(len(sys.argv)==2,'one exact action ID');action=sys.argv[1]
 lock=(ROOT/'GLOBAL_LOCK').open('a+b');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 policy=read(ROOT/'RESUME_POLICY.json');freeze=read(ROOT/'RESUME_FREEZE.json');freeze_sha=sha((ROOT/'RESUME_FREEZE.json').read_bytes())
 for n,h in freeze['files'].items():need(sha((ROOT/n).read_bytes())==h,'resume source drift '+n)
 verify_package() # All original frozen inputs and failed-version code stay unchanged.
 for n,h in policy['preserved_original_files'].items():need(sha((ROOT/n).read_bytes())==h,'original state drift '+n)
 need(action in policy['allowed_actions'],'only five named toy actions and data permitted')
 audit=read(Path(policy['independent_pass_path']))
 need(audit.get('status')=='PASS_LIMITED_PREPARATION' and audit.get('resume_freeze_sha256')==freeze_sha and audit.get('formal_confirmation_enabled') is False,'independent PASS gate')
 need(audit.get('allowed_actions')==list(policy['allowed_actions']),'exact independently approved action set')
 need(not (ROOT/'RESUME_HALT.json').exists(),'resume HALT retained')
 claims=[read(p) for p in (ROOT/'claims').glob('*.json')]
 allowed_old=set(policy['old_claim_ids']);allowed_new=set(policy['allowed_actions'])
 for c in claims:
  aid=c['action_id'];need(aid in allowed_old|allowed_new,'unexpected action identity');need((ROOT/'results'/(aid+'.json')).is_file(),'UNKNOWN permanent claim blocks continuation')
  if aid in allowed_new:need(valid_new_terminal(c,read(ROOT/'results'/(aid+'.json'))),'new terminal failed/unreaped/hash mismatch; permanent block')
 need(not (ROOT/'claims'/(action+'.json')).exists(),'permanent action consumed; no rerun')
 if action=='data':
  for aid in policy['required_successful_toys']:need(read(ROOT/'results'/(aid+'.json'))['status']=='passed','all five valid toys required before data')
  for mid in ('EOH_locked','IID_locked','FF','BF','published_EoH'):need(read(ROOT/'results'/('admission_'+mid+'.json'))['status']=='passed','all admissions required')
 stage=policy['allowed_actions'][action];cpu,wall=stage['reserve_CPU_seconds'],stage['reserve_wall_seconds']
 total_cpu=200+sum(c['reserve_CPU_seconds'] for c in claims)+cpu;total_wall=600+sum(c['reserve_wall_seconds'] for c in claims)+wall
 need(total_cpu<=14000 and total_wall<=12000,'forward ceiling; no reset')
 need(sum(c['kind']=='toy' for c in claims)+(stage['kind']=='toy')<=6,'exact amended six-attempt cap')
 need(sum(c['kind']=='data' for c in claims)+(stage['kind']=='data')<=1,'one data attempt')
 need(read(ROOT/'EXECUTION_SWITCH.json')['formal_confirmation_enabled'] is False,'formal stays closed')
 # Verify local proc accounting is available before consuming an action.
 tree_cpu(os.getpid())
 claim={'schema':'C1-guarded-continuation-claim-v1','action_id':action,'kind':stage['kind'],'method':stage.get('method'),'reserve_CPU_seconds':cpu,'reserve_wall_seconds':wall,'resume_freeze_sha256':freeze_sha,'protocol_sha256':policy['protocol_sha256'],'old_unknown_attempt_retained':True,'no_retry':True,'claimed_at_utc':datetime.now(timezone.utc).isoformat()}
 started=time.monotonic();deadline=started+wall
 signal.signal(signal.SIGALRM,signal.SIG_DFL);signal.setitimer(signal.ITIMER_REAL,wall)
 put(ROOT/'claims'/(action+'.json'),claim)
 # Spawn before reducing this trusted guard's own hard caps; child keeps only
 # the hard inheritance room needed by unchanged original60CPU/512MiB workers.
 parent=os.getpid()
 environment={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1','OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','BLIS_NUM_THREADS':'1','C1_GUARD_PID':str(parent)}
 soft_cpu=99 if action=='data' else 2;soft_as=536870912 if action=='data' else 268435456
 command=['/usr/bin/prlimit',f'--cpu={soft_cpu}:200',f'--as={soft_as}:536870912','--nofile=64:64','--core=0:0','--',sys.executable,'-B',str(ROOT/'resume_driver.py'),action]
 collected=collect_driver(command,environment,cpu,deadline,ROOT/'logs'/(action+'.guard.stdout.txt'),ROOT/'logs'/(action+'.guard.stderr.txt'))
 own=resource.getrusage(resource.RUSAGE_SELF);usage=collected['usage'];rc=collected['returncode'];trigger=collected['trigger'];peak_observed_cpu=collected['tree_CPU_peak_observed']
 full_driver_cpu=usage.ru_utime+usage.ru_stime;observed_total=full_driver_cpu+own.ru_utime+own.ru_stime
 status='passed' if rc==0 and trigger is None else 'blocked_no_retry';payload_path=ROOT/'payloads'/(action+'.json')
 payload=read(payload_path) if status=='passed' and payload_path.is_file() else {'exception':'Guarded driver failed or missing payload','returncode':rc,'trigger':trigger}
 if status=='passed' and not payload_path.is_file():status='blocked_no_retry'
 if full_driver_cpu+1>cpu or time.monotonic()>deadline:status='blocked_no_retry'
 record={'schema':'C1-guarded-full-driver-terminal-v1','completed_at_utc':datetime.now(timezone.utc).isoformat(),'action_id':action,'claim_sha256':digest(claim),'status':status,'payload':payload,'resources':{'driver_pid':collected['pid'],'driver_reaped':True,'driver_exit_code':rc,'driver_wait4_inclusive_CPU_seconds':full_driver_cpu,'driver_peak_RSS_kib':usage.ru_maxrss,'guard_self_CPU_at_emit':own.ru_utime+own.ru_stime,'measured_CPU_at_emit_no_double_count':observed_total,'whole_action_wall_at_emit':time.monotonic()-started,'guard_CPU_hard_limit_seconds':1,'conservative_complete_tree_CPU_upper_seconds':full_driver_cpu+1,'guard_AS_hard_limit_bytes':134217728,'guard_wall_alarm_active_through_serialization_and_exit':True,'driver_limits':{'CPU_soft':soft_cpu,'CPU_hard_inheritance':200,'AS_soft':soft_as,'AS_hard_inheritance':536870912},'tree_CPU_peak_observed':peak_observed_cpu,'guard_trigger':trigger,'cumulative_reserved_CPU_seconds':total_cpu,'cumulative_reserved_wall_seconds':total_wall,'scope':'wait4 includes driver full exit plus reaped descendants once. Guard self is at-emit; hard1CPU and uncancelled kernel wall alarm bound its own final tail. Old unknown work remains fully debited.'}}
 put(ROOT/'results'/(action+'.json'),record)
 if status!='passed':put(ROOT/'RESUME_HALT.json',{'action_id':action,'status':'HALT_no_retry','claim_preserved':True})
 print(canon({'action':action,'status':status,'driver_exit_code':rc,'complete_driver_CPU':full_driver_cpu,'observed_CPU_with_guard_at_emit':observed_total,'cumulative_reserved_CPU':total_cpu,'cumulative_reserved_wall':total_wall,'formal_confirmation_runs':0,'private_values_disclosed':False}))
 # Do not cancel ITIMER_REAL: it remains live until this guard actually exits.
 return status=='passed'
if __name__=='__main__':sys.exit(not main())
