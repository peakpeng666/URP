"""One guarded preparation action; no ledger reset or formal evaluator."""
import os,sys,signal,resource
sys.dont_write_bytecode=True;os.umask(0o077)
from control import ROOT,read,put,need
need(len(sys.argv)==2,'one fixed action ID')
action=sys.argv[1];policy=read(ROOT/'RESUME_POLICY.json');need(action in policy['allowed_actions'],'unapproved action')
need(os.getppid()==int(os.environ['C1_GUARD_PID']),'guard parent identity')
signal.signal(signal.SIGXCPU,signal.SIG_DFL);signal.pthread_sigmask(signal.SIG_UNBLOCK,{signal.SIGXCPU})
need(sys.stdin.read(1)=='G','guard release')
if action=='data':
 from custodian import generate
 payload=generate()
else:
 from prepare_abi_v2 import do_toy
 payload=do_toy(policy['allowed_actions'][action]['method'])
put(ROOT/'payloads'/(action+'.json'),payload)
# The outer wait4 guard, not this driver, emits the terminal resource receipt.
