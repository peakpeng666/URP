"""Counts and resource metadata only; no science payload projection."""
from pathlib import Path
import json
r=Path(__file__).resolve().parent;ids=[x['action_id'] for x in json.loads((r/'REMAINING28_RUNTIME_PLAN.json').read_text())['packs']]
cs=[x for x in ids if (r/'claims'/(x+'.json')).exists()];ts=[x for x in ids if (r/'results'/(x+'.json')).exists()]
claims=[json.loads(p.read_text()) for p in (r/'claims').glob('*.json')];cpu=200+61+44+22+sum(x['reserve_CPU_seconds'] for x in claims);wall=600+400+120+60+sum(x['reserve_wall_seconds'] for x in claims)
latest=None
if ts:
 d=json.loads((r/'results'/(ts[-1]+'.json')).read_text());u=d['resources'];latest={'action':ts[-1],'infrastructure_status':d['status'],'driver_CPU':u['driver_wait4_inclusive_CPU_seconds'],'guard_CPU_at_emit':u['guard_self_CPU_at_emit']}
print(json.dumps({'remaining28_claims':len(cs),'remaining28_terminals':len(ts),'latest_resource':latest,'runtime_reserved_CPU':cpu,'runtime_reserved_wall':wall,'pending_final_audit_not_in_runtime':[10,8],'HALT':(r/'REMAINING28_HALT.json').exists(),'stderr_bytes':(r/'logs/remaining28_dispatch.stderr.log').stat().st_size,'raw_set_frozen':(r/'RAW_TERMINAL_SET_AFTER_SECOND_HALT.json').exists(),'analysis_exists':(r/'CONFIRMATION_ANALYSIS_FINAL_STRICT_AND_TECHNICAL.json').exists(),'dispatcher_complete':(r/'REMAINING28_DISPATCH_COMPLETION.json').exists()}))
