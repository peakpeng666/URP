"""Collect raw wait4/PID observations first; no candidate,data or expected-signal filtering."""
import os,sys,time,signal,resource,subprocess,ctypes,json
from pathlib import Path
root=Path(__file__).resolve().parent;start=time.monotonic();libc=ctypes.CDLL(None,use_errno=True)
assert libc.prctl(36,1,0,0,0)==0
resource.setrlimit(resource.RLIMIT_CPU,(3,10));signal.signal(signal.SIGALRM,signal.SIG_DFL);signal.setitimer(signal.ITIMER_REAL,40)
parent=os.getpid();events=[]
def death_guard():
 if libc.prctl(1,signal.SIGKILL,0,0,0)!=0 or os.getppid()!=parent:os._exit(76)
def save(path,data):
 with path.open('x') as f:json.dump(data,f,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
def snapshot(identities):
 result={}
 for role,row in identities.items():
  try:
   raw=Path('/proc/'+str(row['pid'])+'/stat').read_text();f=raw[raw.rfind(')')+2:].split();result[role]={'pid':row['pid'],'state':f[0],'starttime_ticks':f[19],'same_starttime':f[19]==row['starttime_ticks'],'self_CPU_ticks':int(f[11])+int(f[12]),'reaped_child_CPU_ticks':int(f[13])+int(f[14])}
  except FileNotFoundError:result[role]={'pid':row['pid'],'absent':True}
 return result
for mode in ['cpu','pdeath']:
 out=root/'engineering_tests'/('observation3_'+mode);guard=subprocess.Popen([sys.executable,'-B',str(root/'engineering_tree_guard_observation3.py'),mode],preexec_fn=death_guard);reaped=[];identities={};last_snapshot={};killed_at=None
 deadline=time.monotonic()+3
 while not all((out/(role+'.identity.json')).exists() for role in ['guard','driver','supervisor','worker']):
  if time.monotonic()>=deadline:break
  time.sleep(.01)
 for role in ['guard','driver','supervisor','worker']:
  p=out/(role+'.identity.json')
  if p.exists():identities[role]=json.loads(p.read_text())
 save(out/'ORIGINAL_TREE_IDENTITIES.json',identities)
 if mode=='pdeath':killed_at=time.monotonic();os.kill(guard.pid,signal.SIGKILL)
 deadline=time.monotonic()+22
 while True:
  try:pid,status,u=os.wait4(-1,os.WNOHANG)
  except ChildProcessError:break
  if pid:
   event={'pid':pid,'raw_wait_status':status,'exit_code':os.waitstatus_to_exitcode(status),'utime':u.ru_utime,'stime':u.ru_stime,'maxrss':u.ru_maxrss,'recorded_monotonic':time.monotonic()};reaped.append(event);save(out/('WAIT4_'+str(pid)+'.json'),event)
   if pid==guard.pid:guard.returncode=event['exit_code']
  else:
   last_snapshot=snapshot(identities)
   if time.monotonic()>=deadline:break
   time.sleep(.02)
 after=snapshot(identities);full=sum(x['utime']+x['stime'] for x in reaped)
 rec={'mode':mode,'status':'OBSERVATIONS_RECORDED_NOT_PREJUDGED','identities':identities,'individual_wait4':reaped,'last_live_snapshot':last_snapshot,'after_wait_snapshot':after,'unique_outer_wait4_CPU_sum':full,'all_recorded_PIDs_reaped':set(x['pid'] for x in identities.values())<=set(x['pid'] for x in reaped),'no_same_identity_live_computing_node':all(x.get('absent') or x.get('same_starttime') is False or x.get('state') in ['Z','X'] for x in after.values()),'PDEATH_guard_killed_at':killed_at,'kill_to_collection_complete_seconds':time.monotonic()-killed_at if killed_at else None,'CPU_budget':3.5 if mode=='cpu' else None,'candidate_calls':0,'data_reads':0,'CLK_TCK':os.sysconf('SC_CLK_TCK')}
 save(out/'OUTER_OBSERVATIONS.json',rec);events.append(rec)
s=resource.getrusage(resource.RUSAGE_SELF);c=resource.getrusage(resource.RUSAGE_CHILDREN)
record={'status':'OBSERVATIONS_COMPLETE_REVIEW_REQUIRED','modes':events,'suite_self_CPU_at_emit':s.ru_utime+s.ru_stime,'all_reaped_descendants_inclusive_CPU':c.ru_utime+c.ru_stime,'conservative_full_tree_CPU_upper':c.ru_utime+c.ru_stime+3,'reserved_CPU':10,'reserved_wall':40,'within_reserved_CPU_upper':c.ru_utime+c.ru_stime+3<=10,'wall_at_emit':time.monotonic()-start,'candidate_calls':0,'data_reads':0,'alarm_active_through_exit':True}
save(root/'PREP_OBSERVATION3_TERMINAL.json',record);print(json.dumps({'status':record['status'],'CPU':c.ru_utime+c.ru_stime+s.ru_utime+s.ru_stime,'wall':record['wall_at_emit']}),flush=True)
