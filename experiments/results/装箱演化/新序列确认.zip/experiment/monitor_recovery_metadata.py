"""Read-only counts/resources projection. Never emits or derives policy performance."""
from pathlib import Path
import json
r=Path(__file__).resolve().parent
ids=[x['action_id'] for x in json.loads((r/'RECOVERY_PLAN.json').read_text())['packs']]
claims=[x for x in ids if (r/'claims'/(x+'.json')).exists()]
terms=[x for x in ids if (r/'results'/(x+'.json')).exists()]
latest=None
if terms:
 d=json.loads((r/'results'/(terms[-1]+'.json')).read_text());q=d['resources']
 latest={'action':terms[-1],'infrastructure_status':d['status'],'driver_CPU':q['driver_wait4_inclusive_CPU_seconds'],'guard_CPU_at_emit':q['guard_self_CPU_at_emit'],'reserved_CPU':q['cumulative_reserved_CPU_seconds'],'reserved_wall':q['cumulative_reserved_wall_seconds']}
all_claims=[json.loads(p.read_text()) for p in (r/'claims').glob('*.json')]
current_CPU=200+61+22+22+sum(c['reserve_CPU_seconds'] for c in all_claims)
current_wall=600+400+60+60+sum(c['reserve_wall_seconds'] for c in all_claims)
print(json.dumps({'current_reserved_CPU':current_CPU,'current_reserved_wall':current_wall,'recovery_claims':len(claims),'recovery_terminals':len(terms),'latest_resources':latest,'HALT':(r/'RECOVERY_HALT.json').exists(),'stderr_bytes':(r/'logs/recovery_dispatch.stderr.log').stat().st_size,'raw_set_frozen':(r/'RAW_TERMINAL_SET_FROZEN.json').exists(),'analysis_exists':(r/'CONFIRMATION_ANALYSIS_STRICT_AND_TECHNICAL.json').exists(),'dispatcher_complete':(r/'RECOVERY_DISPATCH_COMPLETION.json').exists()}))
