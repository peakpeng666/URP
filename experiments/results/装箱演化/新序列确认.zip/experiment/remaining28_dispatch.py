"""One permanent finite dispatcher segment. A second launch cannot reset its debit."""
import ctypes,fcntl,os,sys,resource,signal,subprocess,time
from datetime import datetime,timezone
from control import ROOT,read,put,need,sha,canon
from guard_collect_blocking import valid_new_terminal,identity
sys.dont_write_bytecode=True;os.umask(0o077)
need(sys.argv[1:]==['--enable-formal'],'explicit activation flag required')
need(read(ROOT/'REMAINING28_SWITCH.json')['enabled'] is True,'formal disabled')
resource.setrlimit(resource.RLIMIT_CPU,(20,300));resource.setrlimit(resource.RLIMIT_AS,(67108864,536870912))
signal.signal(signal.SIGXCPU,signal.SIG_DFL);signal.pthread_sigmask(signal.SIG_UNBLOCK,{signal.SIGXCPU})
lock=(ROOT/'REMAINING28_DISPATCH_LOCK').open('a+b');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
need(not (ROOT/'REMAINING28_DISPATCH_CLAIM.json').exists(),'permanent dispatcher segment consumed; reviewed new segment required for resume')
need(not (ROOT/'REMAINING28_HALT.json').exists(),'formal HALT preserved')
freeze=read(ROOT/'REMAINING28_FREEZE.json');fh=sha((ROOT/'REMAINING28_FREEZE.json').read_bytes())
for n,h in freeze['files'].items():need(sha((ROOT/n).read_bytes())==h,'formal frozen file drift '+n)
policy=read(ROOT/'REMAINING28_POLICY.json');seal_hash=sha((ROOT/'REMAINING28_SEAL.json').read_bytes());auth=read(ROOT/'REMAINING28_AUTHORIZATION.json')
audit_file=__import__('pathlib').Path(policy['independent_pass_path']);audit=read(audit_file)
need(auth.get('remaining28_execution_authorized') is True and auth.get('remaining28_freeze_sha256')==fh and auth.get('remaining28_seal_sha256')==seal_hash and auth.get('independent_audit_sha256')==sha(audit_file.read_bytes()),'specific parent activation required')
need(audit.get('status')=='PASS_REMAINING28_NOT_ACTIVATED' and audit.get('remaining28_freeze_sha256')==fh and audit.get('remaining28_seal_sha256')==seal_hash,'formal independent audit required')
plan=read(ROOT/'REMAINING28_RUNTIME_PLAN.json');started=time.monotonic()
# All100 guarded actions+analysis+60seconds nonoverlapped overhead; alarm remains active through final exit.
segment_wall=28*93+523+60
signal.signal(signal.SIGALRM,signal.SIG_DFL);signal.setitimer(signal.ITIMER_REAL,segment_wall)
put(ROOT/'REMAINING28_DISPATCH_CLAIM.json',{'schema':'C1-single-dispatcher-segment-claim-v1','pid':os.getpid(),'remaining28_freeze_sha256':fh,'seal_sha256':seal_hash,'reserve_CPU_seconds':22,'reserve_wall_seconds':60,'full_segment_wall_limit_seconds':segment_wall,'claimed_at_utc':datetime.now(timezone.utc).isoformat(),'no_retry':True})
libc=ctypes.CDLL(None,use_errno=True);need(libc.prctl(36,1,0,0,0)==0,'dispatcher subreaper');parent=os.getpid()
def death_guard():
 if libc.prctl(1,signal.SIGKILL,0,0,0)!=0 or os.getppid()!=parent:os._exit(76)
env=dict(os.environ,C1_DISPATCH_PID=str(parent),PYTHONDONTWRITEBYTECODE='1')
for row in plan['packs']+[{'action_id':'analysis_remaining28'}]:
 aid=row['action_id'];need(not (ROOT/'REMAINING28_HALT.json').exists(),'formal HALT retained')
 if (ROOT/'claims'/(aid+'.json')).exists():
  need((ROOT/'results'/(aid+'.json')).exists(),'UNKNOWN permanent claim; stop,never rerun')
  need(valid_new_terminal(read(ROOT/'claims'/(aid+'.json')),read(ROOT/'results'/(aid+'.json'))),'failed or mismatched permanent claim; stop')
  continue
 child=subprocess.Popen([sys.executable,'-B',str(ROOT/'remaining28_guard.py'),'--enable-formal',aid],cwd=ROOT,env=env,preexec_fn=death_guard)
 try:observed_identity=identity(child.pid)
 except FileNotFoundError:observed_identity={'pid':child.pid,'starttime_unavailable_after_early_exit':True}
 put(ROOT/'dispatcher_observations'/(aid+'.launch.json'),{'guard':observed_identity,'dispatcher':identity(parent),'launched_at_utc':datetime.now(timezone.utc).isoformat()})
 pid,status,usage=os.wait4(child.pid,0);child.returncode=os.waitstatus_to_exitcode(status)
 events=[{'pid':pid,'raw_wait_status':status,'exit_code':child.returncode,'utime':usage.ru_utime,'stime':usage.ru_stime,'maxrss':usage.ru_maxrss}]
 put(ROOT/'dispatcher_observations'/(aid+'.guard_wait4.json'),events[0])
 deadline=time.monotonic()+2;unreaped=False
 while True:
  try:pid2,status2,u2=os.wait4(-1,os.WNOHANG)
  except ChildProcessError:break
  if pid2:
   event={'pid':pid2,'raw_wait_status':status2,'exit_code':os.waitstatus_to_exitcode(status2),'utime':u2.ru_utime,'stime':u2.ru_stime,'maxrss':u2.ru_maxrss};events.append(event)
   put(ROOT/'dispatcher_observations'/(aid+'.adopted_'+str(pid2)+'.json'),event)
  elif time.monotonic()>=deadline:unreaped=True;break
  else:time.sleep(.02)
 put(ROOT/'dispatcher_observations'/(aid+'.complete.json'),{'raw_wait4_events':events,'inclusive_CPU_counted_once':sum(x['utime']+x['stime'] for x in events),'inner_driver_or_worker_CPU_not_readded':True,'unreaped_descendants_remaining':unreaped})
 if child.returncode!=0 or unreaped:
  if not (ROOT/'REMAINING28_HALT.json').exists():put(ROOT/'REMAINING28_HALT.json',{'action_id':aid,'status':'HALT_permanent_claim_retained','guard_exit':child.returncode,'unreaped_descendants_remaining':unreaped,'no_retry':True})
  raise SystemExit(1)
 need(valid_new_terminal(read(ROOT/'claims'/(aid+'.json')),read(ROOT/'results'/(aid+'.json'))),'new terminal complete before next dispatch')
 # Never interpret partial policy fitness,adapt order or retry.
put(ROOT/'REMAINING28_DISPATCH_COMPLETION.json',{'status':'28_new_terminals_plus_two_unknown_strict_and_technical_analysis_written','self_CPU_at_emit':time.process_time(),'wall_at_emit':time.monotonic()-started,'dispatcher_CPU_reservation':22,'nonoverlapped_wall_overhead_reservation':60,'full_segment_wall_limit_seconds':segment_wall,'alarm_active_through_exit':True,'overlap_not_double_counted':True,'new_generation_calls':0})
print(canon({'status':'formal_sequence_terminal','no_candidate_reselection':True}))
