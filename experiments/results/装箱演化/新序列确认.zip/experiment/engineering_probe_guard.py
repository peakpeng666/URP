"""Runs the same collector with trusted dummy processes,never model sources."""
from pathlib import Path
import json,os,sys,time,signal,resource
from guard_collect import collect_driver,valid_new_terminal
root=Path(__file__).resolve().parent;mode=sys.argv[1];out=root/'engineering_tests'/('guard_'+mode);out.mkdir(exist_ok=False)
wall=1 if mode=='wall' else 5;threshold=1.4 if mode=='cpu' else 4
started=time.monotonic();signal.signal(signal.SIGALRM,signal.SIG_DFL);signal.setitimer(signal.ITIMER_REAL,wall)
command=['/usr/bin/prlimit','--cpu=2:200','--as=268435456:536870912','--',sys.executable,'-B',str(root/'engineering_probe_driver.py'),mode,str(out/'payload.json')]
r=collect_driver(command,dict(os.environ),threshold,started+wall,out/'stdout.txt',out/'stderr.txt');u=r['usage'];cpu=u.ru_utime+u.ru_stime
if mode=='success':
 p=json.loads((out/'payload.json').read_text());assert r['returncode']==0 and r['trigger'] is None and cpu>=p['self_at_payload']+p['child_at_payload']+.06
elif mode=='failure':assert r['returncode']==17 and not (out/'payload.json').exists()
elif mode=='wall':assert r['returncode']==-9 and r['trigger']=='whole_action_wall_stop'
else:assert r['returncode']==-9 and r['trigger']=='tree_CPU_reserve_stop'
claim={'action_id':'fixture','reserve_CPU_seconds':123,'reserve_wall_seconds':92}
assert not valid_new_terminal(claim,{'status':'blocked_no_retry','resources':{'driver_reaped':True,'driver_exit_code':17}})
assert not valid_new_terminal(claim,{'claim_sha256':'mismatched','status':'passed','resources':{'driver_reaped':True,'driver_exit_code':0}})
# Persist a failed terminal with no HALT; reloading it must remain invalid.
(out/'claim.json').write_text(json.dumps(claim));(out/'failed_terminal_without_halt.json').write_text(json.dumps({'status':'blocked_no_retry','resources':{'driver_reaped':True,'driver_exit_code':17}}))
assert not valid_new_terminal(json.loads((out/'claim.json').read_text()),json.loads((out/'failed_terminal_without_halt.json').read_text()))
s=resource.getrusage(resource.RUSAGE_SELF)
record={'mode':mode,'status':'passed','driver_wait4_inclusive_CPU_seconds':cpu,'driver_returncode':r['returncode'],'driver_reaped':True,'trigger':r['trigger'],'wall_at_emit':time.monotonic()-started,'guard_self_CPU_at_emit':s.ru_utime+s.ru_stime,'candidate_calls':0,'data_reads':0,'same_collector_sha256':__import__('hashlib').sha256((root/'guard_collect.py').read_bytes()).hexdigest(),'cost_scope':'Dummy enforcement probes within already debited trusted preparation envelope; guard own final tail bounded byhard1CPU,not fabricated as zero.'}
(out/'RECEIPT.json').write_text(json.dumps(record,sort_keys=True)+'\n');print(json.dumps(record))
