"""Small shared wait4/CPU/wall collector; no policy or data imports."""
from pathlib import Path
import ctypes,os,resource,signal,subprocess,time
def tree_cpu(pid):
 total=0.;pending=[pid];seen=set();hz=os.sysconf('SC_CLK_TCK')
 while pending:
  p=pending.pop()
  if p in seen:continue
  seen.add(p)
  try:
   s=Path(f'/proc/{p}/stat').read_text();f=s[s.rfind(')')+2:].split()
   total+=sum(int(f[j]) for j in (11,12,13,14))/hz
   child=Path(f'/proc/{p}/task/{p}/children').read_text().split();pending.extend(map(int,child))
  except FileNotFoundError:continue
 return total


def collect_driver(command,environment,cpu,deadline,stdout_path,stderr_path):
 libc=ctypes.CDLL(None,use_errno=True);parent=os.getpid()
 def death_guard():
  if libc.prctl(1,signal.SIGKILL,0,0,0)!=0 or os.getppid()!=parent:os._exit(76)
 stdout=Path(stdout_path).open('xb');stderr=Path(stderr_path).open('xb')
 child=subprocess.Popen(command,env=environment,stdin=subprocess.PIPE,stdout=stdout,stderr=stderr,start_new_session=True,preexec_fn=death_guard)
 resource.setrlimit(resource.RLIMIT_CPU,(1,1));resource.setrlimit(resource.RLIMIT_AS,(134217728,134217728))
 child.stdin.write(b'G');child.stdin.flush();child.stdin.close();trigger=None;peak=0.;usage=None;rc=None
 while True:
  pid,status,u=os.wait4(child.pid,os.WNOHANG)
  if pid:usage=u;rc=os.waitstatus_to_exitcode(status);child.returncode=rc;break
  own=resource.getrusage(resource.RUSAGE_SELF);current=tree_cpu(child.pid)+own.ru_utime+own.ru_stime;peak=max(peak,current)
  if trigger is None and (current>=cpu-.25 or time.monotonic()>=deadline-.5):
   trigger='tree_CPU_reserve_stop' if current>=cpu-.25 else 'whole_action_wall_stop'
   try:os.killpg(child.pid,signal.SIGKILL)
   except ProcessLookupError:pass
  time.sleep(.1)
 stdout.close();stderr.close()
 return {'pid':child.pid,'returncode':rc,'trigger':trigger,'usage':usage,'tree_CPU_peak_observed':peak}

def valid_new_terminal(claim,terminal):
 import hashlib,json
 expected=hashlib.sha256(json.dumps(claim,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
 r=terminal.get('resources',{})
 return terminal.get('claim_sha256')==expected and terminal.get('status')=='passed' and r.get('driver_reaped') is True and r.get('driver_exit_code')==0
