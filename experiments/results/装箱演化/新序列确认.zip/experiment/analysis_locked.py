"""Prospectively fixed results-only analysis. No candidate, seed, or item access."""
from fractions import Fraction
import hashlib
METHODS=('EOH_locked','IID_locked','FF','BF','published_EoH')
def value(x):return {'numerator':x.numerator,'denominator':x.denominator,'decimal':float(x)}
def analyze(records,dataset_manifest_sha256,analysis_source_sha256,bootstrap=True):
 rows={(r['global_instance_index'],r['method']):r for r in records}
 assert len(rows)==len(records)==100 and set(rows)=={(i,m) for i in range(20) for m in METHODS}
 f={};means={};coverage={}
 for m in METHODS:
  valid=[]
  for i in range(20):
   r=rows[i,m]
   if r['status']=='ok':
    assert r['checker_status']=='passed' and type(r['used_bins']) is int and r['L1']<=r['used_bins']<=5000
    f[i,m]=Fraction(r['L1'],r['used_bins']);valid.append(i)
   else:assert r.get('used_bins') is None
  coverage[m]={'complete':len(valid),'denominator':20};means[m]=value(sum((f[i,m] for i in valid),Fraction())/20) if len(valid)==20 else None
 contrasts={}
 for m in METHODS[1:]:
  if coverage['EOH_locked']['complete']==coverage[m]['complete']==20:
   diffs=[f[i,'EOH_locked']-f[i,m] for i in range(20)]
   saved={'mean_F_difference':value(sum(diffs,Fraction())/20),'total_bin_savings_comparator_minus_EOH':sum(rows[i,m]['used_bins']-rows[i,'EOH_locked']['used_bins'] for i in range(20)),'wins_ties_losses':[sum(d>0 for d in diffs),sum(d==0 for d in diffs),sum(d<0 for d in diffs)],'paired_instances':20,'interval':None}
   if bootstrap:
    import numpy as np
    msg=('confirmation-C1-analysis-bootstrap-v1|'+dataset_manifest_sha256+'|'+analysis_source_sha256).encode();seed=int.from_bytes(hashlib.sha256(msg).digest()[:16],'big')
    # Reset to the same index stream for every contrast, preserving paired rows.
    rng=np.random.Generator(np.random.PCG64(seed));indices=rng.integers(0,20,size=(20000,20));vals=np.asarray([float(d) for d in diffs],dtype=np.float64)[indices].mean(axis=1)
    saved['interval']={'method':'paired_percentile_bootstrap_approximate','resamples':20000,'lower_upper':np.quantile(vals,[.025,.975],method='linear').tolist(),'secondary_intervals_descriptive_unadjusted':m!='IID_locked'}
   contrasts[m]=saved
  else:contrasts[m]=None
 return {'coverage':coverage,'full20_means':means,'primary_EOH_minus_IID':contrasts['IID_locked'],'contrasts':contrasts,'no_zero_imputation':True,'p_values':None,'winner_selection':None,'n_independent_sequences':20}
if __name__=='__main__':raise SystemExit('Results-only function. Formal results do not exist; no automatic evaluation or CLI.')
