"""Pre-unblinding two-dataset wrapper; original exact analysis function is unchanged."""
from analysis_locked import analyze

def analyze_both(strict_records,technical_record,data_sha,original_analysis_sha):
 assert len(strict_records)==100
 missing=[r for r in strict_records if r['status']=='infrastructure_unknown_original_claim']
 assert len(missing)==1 and missing[0]['global_instance_index']==0 and missing[0]['method']=='IID_locked' and missing[0]['used_bins'] is None
 assert technical_record['global_instance_index']==0 and technical_record['method']=='IID_locked'
 strict=analyze(strict_records,data_sha,original_analysis_sha,bootstrap=True)
 assert strict['full20_means']['IID_locked'] is None and strict['primary_EOH_minus_IID'] is None
 technical=[technical_record if (r['global_instance_index'],r['method'])==(0,'IID_locked') else dict(r) for r in strict_records]
 completed=analyze(technical,data_sha,original_analysis_sha,bootstrap=True)
 return {'strict_original_100_slots':strict,'technical_completion_sensitivity':completed,'original_unknown_retained':True,'strict_primary_permanently_null':True,'technical_completion_is_separate_not_original_primary':True,'exact_extra_attempt':'technical_completion_00_IID_locked_v1','no_generic_retry':True,'all_attempts_reported_separately':101}
