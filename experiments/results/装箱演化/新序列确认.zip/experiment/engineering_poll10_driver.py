"""Trusted resource fixtures; no candidate/dataset imports."""
import sys,time,subprocess,resource,json,os,ctypes,signal
from pathlib import Path
assert sys.stdin.read(1)=='G';mode,out=sys.argv[1:];parent=os.getpid();libc=ctypes.CDLL(None,use_errno=True)
def death_guard():
 if libc.prctl(1,signal.SIGKILL,0,0,0)!=0 or os.getppid()!=parent:os._exit(76)
if mode=='failure':raise SystemExit(17)
if mode=='wall':time.sleep(10)
if mode=='cpu':
 t=time.process_time()
 while time.process_time()-t<1.8:pass
if mode=='long_success':
 # A live descendant remains present during the near90s test,not merely an idle root.
 subprocess.run([sys.executable,'-B','-c','import time;time.sleep(88.4);t=time.process_time()\nwhile time.process_time()-t<.08:pass'],check=True,preexec_fn=death_guard)
 c=resource.getrusage(resource.RUSAGE_CHILDREN);s=resource.getrusage(resource.RUSAGE_SELF)
 Path(out).write_text(json.dumps({'self_at_payload':s.ru_utime+s.ru_stime,'child_at_payload':c.ru_utime+c.ru_stime,'descendant_reaped':True}))
 t=time.process_time()
 while time.process_time()-t<.08:pass
