"""Synthetic ledger/analysis checks; no candidate parse, admission or invocation."""
from pathlib import Path
import tempfile
from control import ROOT,read,put,check_open,totals,need
from analysis_locked import analyze,METHODS

def run():
 count=0;scope=read(ROOT/'BUDGET_SCOPE.json')
 with tempfile.TemporaryDirectory(dir=ROOT/'engineering_tests') as t:
  r=Path(t);(r/'claims').mkdir();(r/'results').mkdir();put(r/'claims/x.json',{})
  try:check_open(r)
  except RuntimeError:count+=1
  else:raise AssertionError('unknown must halt')
  put(r/'results/x.json',{});check_open(r);count+=1
  try:put(r/'claims/x.json',{})
  except FileExistsError:count+=1
  else:raise AssertionError('claim overwritten')
  put(r/'HALT.json',{})
  try:check_open(r)
  except RuntimeError:count+=1
  else:raise AssertionError('HALT ignored')
 sample={'kind':'admission','reserve_CPU_seconds':4,'reserve_wall_seconds':7}
 for xs in [[sample]*6,[{'kind':'formal','reserve_CPU_seconds':1,'reserve_wall_seconds':1}],[{'kind':'toy','reserve_CPU_seconds':14000,'reserve_wall_seconds':1}]]:
  try:totals(xs,scope)
  except RuntimeError:count+=1
  else:raise AssertionError('cap/forbidden stage accepted')
 need(totals([sample]*5,scope)['reserved_CPU_seconds']==220,'persistent full reservation sum');count+=1
 rows=[{'global_instance_index':i,'method':m,'status':'ok','checker_status':'passed','used_bins':10,'L1':9} for i in range(20) for m in METHODS]
 a=analyze(rows,'fixture','fixture',bootstrap=False);need(a['primary_EOH_minus_IID']['mean_F_difference']['numerator']==0,'paired exact estimate');count+=1
 rows[0].update(status='unknown',used_bins=None);a=analyze(rows,'fixture','fixture',bootstrap=False)
 need(a['full20_means']['EOH_locked'] is None and a['primary_EOH_minus_IID'] is None and a['coverage']['EOH_locked']=={'complete':19,'denominator':20},'unknown not zero/not dropped');count+=1
 return {'tests_passed':count,'synthetic_only':True,'candidate_executions':0,'data_generated':0}
