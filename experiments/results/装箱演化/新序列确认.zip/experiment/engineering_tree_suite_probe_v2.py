"""One recorded test segment; subreaper captures intentionally orphaned dummy nodes."""
import os,sys,time,signal,resource,subprocess,ctypes,json
from pathlib import Path
root=Path(__file__).resolve().parent;start=time.monotonic();libc=ctypes.CDLL(None,use_errno=True)
assert libc.prctl(36,1,0,0,0)==0
resource.setrlimit(resource.RLIMIT_CPU,(3,10));resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912));signal.signal(signal.SIGALRM,signal.SIG_DFL);signal.setitimer(signal.ITIMER_REAL,40)
parent=os.getpid()
def death_guard():
 if libc.prctl(1,signal.SIGKILL,0,0,0)!=0 or os.getppid()!=parent:os._exit(76)
results=[]
for mode in ['cpu','pdeath']:
 out=root/'engineering_tests'/('boundary2_'+mode)
 guard=subprocess.Popen([sys.executable,'-B',str(root/'engineering_tree_guard_probe_v2.py'),mode],preexec_fn=death_guard)
 if mode=='pdeath':
  deadline=time.monotonic()+3
  while not all((out/(role+'.identity.json')).exists() for role in ['guard','driver','supervisor','worker']):
   assert time.monotonic()<deadline;time.sleep(.01)
  identities={role:json.loads((out/(role+'.identity.json')).read_text()) for role in ['guard','driver','supervisor','worker']}
  assert len({v['pid_namespace'] for v in identities.values()})==1
  killed_at=time.monotonic();os.kill(guard.pid,signal.SIGKILL);reaped={};deadline=time.monotonic()+3
  while len(reaped)<4:
   pid,status,u=os.wait4(-1,os.WNOHANG)
   if pid:reaped[pid]={'exit':os.waitstatus_to_exitcode(status),'CPU':u.ru_utime+u.ru_stime}
   else:assert time.monotonic()<deadline;time.sleep(.01)
  assert set(reaped)=={x['pid'] for x in identities.values()} and all(x['exit']==-9 for x in reaped.values());guard.returncode=-9
  record={'status':'passed','mode':mode,'identities':identities,'actual_wait4_reaped':reaped,'kill_to_all_reaped_seconds':time.monotonic()-killed_at,'candidate_calls':0,'data_reads':0,'scope':'This new trusted dummy tree only; no retrospective claim about unknown original IID process.'}
  (out/'RECEIPT.json').write_text(json.dumps(record,sort_keys=True)+'\n')
 else:
  pid,status,u=os.wait4(guard.pid,0);guard.returncode=os.waitstatus_to_exitcode(status);assert guard.returncode==0
  orphans=[];deadline=time.monotonic()+2
  while True:
   try:pid2,status2,u2=os.wait4(-1,os.WNOHANG)
   except ChildProcessError:break
   if pid2:orphans.append({'pid':pid2,'exit':os.waitstatus_to_exitcode(status2),'CPU':u2.ru_utime+u2.ru_stime})
   else:assert time.monotonic()<deadline;time.sleep(.01)
  rec=json.loads((out/'RECEIPT.json').read_text());full=u.ru_utime+u.ru_stime+sum(x['CPU'] for x in orphans)
  if mode=='cpu':assert full<=rec['CPU_budget'] and all(x['exit']==-9 for x in orphans)
  record={'mode':mode,'guard_full_wait4_CPU':u.ru_utime+u.ru_stime,'adopted_orphans_wait4':orphans,'unique_complete_tree_CPU':full,'CPU_overshoot_seconds':max(0,full-rec['CPU_budget']),'status':'passed'}
  (out/'OUTER_WAIT4.json').write_text(json.dumps(record,sort_keys=True)+'\n')
 results.append(record)
s=resource.getrusage(resource.RUSAGE_SELF);c=resource.getrusage(resource.RUSAGE_CHILDREN);assert c.ru_utime+c.ru_stime+3<=10
with (root/'PREP_BOUNDARY2_TERMINAL.json').open('x') as f:json.dump({'status':'passed','all_probes':results,'suite_self_CPU_at_emit':s.ru_utime+s.ru_stime,'suite_hard_CPU':3,'all_reaped_descendants_inclusive_CPU':c.ru_utime+c.ru_stime,'conservative_complete_CPU_upper':c.ru_utime+c.ru_stime+3,'wall_at_emit':time.monotonic()-start,'candidate_calls':0,'data_reads':0,'reserve_CPU':10,'reserve_wall':40,'active_alarm_through_exit':True},f,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps({'status':'passed','threelevel_and_pdeath':True,'CPU':c.ru_utime+c.ru_stime+s.ru_utime+s.ru_stime,'wall':time.monotonic()-start}),flush=True)
