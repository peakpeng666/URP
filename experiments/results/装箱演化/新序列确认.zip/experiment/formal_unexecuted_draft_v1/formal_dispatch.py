"""Finite100-slot dispatcher. Never enabled by preparation or by importing this file."""
import os,sys,resource,signal,subprocess,time
from control import ROOT,read,put,need,canon
need(sys.argv[1:]==['--enable-formal'],'explicit activation flag required')
need(read(ROOT/'FORMAL_SWITCH.json')['enabled'] is True,'formal disabled')
# Trusted bookkeeping only; limits retain inheritance room for the original workers.
resource.setrlimit(resource.RLIMIT_CPU,(20,300));resource.setrlimit(resource.RLIMIT_AS,(67108864,536870912))
signal.signal(signal.SIGXCPU,signal.SIG_DFL);signal.pthread_sigmask(signal.SIG_UNBLOCK,{signal.SIGXCPU})
plan=read(ROOT/'FORMAL_PLAN.json');started=time.monotonic();self0=time.process_time()
for row in plan['packs']+[{'action_id':'analysis'}]:
 aid=row['action_id']
 if (ROOT/'claims'/(aid+'.json')).exists():
  need((ROOT/'results'/(aid+'.json')).exists(),'UNKNOWN permanent claim; stop,never rerun')
  need(read(ROOT/'results'/(aid+'.json'))['status']=='passed','failed claim; stop')
  continue
 result=subprocess.run([sys.executable,'-B',str(ROOT/'formal_guard.py'),'--enable-formal',aid],cwd=ROOT,check=False)
 if result.returncode!=0:raise SystemExit(result.returncode)
 # Never interpret partial policy fitness,adapt order or retry.
put(ROOT/'FORMAL_DISPATCH_COMPLETION.json',{'status':'all100_terminal_analysis_written','self_CPU_at_emit':time.process_time()-self0,'wall_at_emit':time.monotonic()-started,'dispatcher_CPU_reservation':20,'nonoverlapped_wall_overhead_reservation':60,'overlap_not_double_counted':True,'new_generation_calls':0})
print(canon({'status':'formal_sequence_terminal','no_candidate_reselection':True}))
