"""Trusted no-candidate resource probes. Never imports a policy or dataset."""
import sys,time,subprocess,resource,json
from pathlib import Path
assert sys.stdin.read(1)=='G';mode,out=sys.argv[1:]
if mode=='failure':raise SystemExit(17)
if mode=='wall':time.sleep(10)
if mode=='cpu':
 t=time.process_time()
 while time.process_time()-t<5:pass
if mode=='success':
 p=subprocess.run([sys.executable,'-c','import time;t=time.process_time()\nwhile time.process_time()-t<.08:pass'],check=True)
 c=resource.getrusage(resource.RUSAGE_CHILDREN);s=resource.getrusage(resource.RUSAGE_SELF)
 Path(out).write_text(json.dumps({'self_at_payload':s.ru_utime+s.ru_stime,'child_at_payload':c.ru_utime+c.ru_stime}))
 t=time.process_time()
 while time.process_time()-t<.08:pass
