"""Fresh copy of resource probes using the10Hz collector; no candidate/data access."""
from pathlib import Path
import json,os,sys,time,signal,resource,hashlib
from guard_collect_poll10 import collect_driver,valid_new_terminal
root=Path(__file__).resolve().parent;mode=sys.argv[1];out=root/'engineering_tests'/('poll10_'+mode);out.mkdir(exist_ok=False)
wall=90 if mode=='long_success' else 1 if mode=='wall' else 5;threshold=1.3 if mode=='cpu' else 4
started=time.monotonic();signal.signal(signal.SIGALRM,signal.SIG_DFL);signal.setitimer(signal.ITIMER_REAL,wall)
command=['/usr/bin/prlimit','--cpu=2:2','--as=268435456:536870912','--',sys.executable,'-B',str(root/'engineering_poll10_driver.py'),mode,str(out/'payload.json')]
r=collect_driver(command,dict(os.environ),threshold,started+wall,out/'stdout.txt',out/'stderr.txt');u=r['usage'];cpu=u.ru_utime+u.ru_stime
if mode=='long_success':
 p=json.loads((out/'payload.json').read_text());assert r['returncode']==0 and r['trigger'] is None and cpu>=p['self_at_payload']+p['child_at_payload']+.06 and time.monotonic()-started>=88
elif mode=='failure':assert r['returncode']==17 and not (out/'payload.json').exists()
elif mode=='wall':assert r['returncode']==-9 and r['trigger']=='whole_action_wall_stop'
else:assert r['returncode']==-9 and r['trigger']=='tree_CPU_reserve_stop'
claim={'action_id':'dummy','reserve_CPU_seconds':125,'reserve_wall_seconds':93};bad={'status':'blocked_no_retry','resources':{'driver_reaped':True,'driver_exit_code':17}}
(out/'failed_terminal_without_halt.json').write_text(json.dumps(bad));assert not valid_new_terminal(claim,json.loads((out/'failed_terminal_without_halt.json').read_text()))
s=resource.getrusage(resource.RUSAGE_SELF);elapsed=time.monotonic()-started;total=cpu+s.ru_utime+s.ru_stime
record={'mode':mode,'status':'passed','driver_wait4_inclusive_CPU_seconds':cpu,'driver_returncode':r['returncode'],'driver_reaped':True,'driver_peak_RSS_kib':u.ru_maxrss,'trigger':r['trigger'],'wall_at_emit':elapsed,'wall_limit':wall,'wall_overshoot_seconds':max(0,elapsed-wall),'guard_self_CPU_at_emit':s.ru_utime+s.ru_stime,'guard_peak_RSS_kib':s.ru_maxrss,'guard_hard_CPU':1,'guard_hard_AS':134217728,'measured_tree_CPU_at_emit':total,'tree_CPU_threshold':threshold,'observed_CPU_overshoot_seconds':max(0,total-threshold),'full_guard_tail_upper_CPU':cpu+1,'alarm_active_through_exit':True,'candidate_calls':0,'data_reads':0,'same_collector_sha256':hashlib.sha256((root/'guard_collect_poll10.py').read_bytes()).hexdigest(),'cost_scope':'Additional test envelope20CPU/120wall; each guard hard1CPU and uncancelled wall alarm; suite retains inclusive full child wait4 usage.'}
(out/'RECEIPT.json').write_text(json.dumps(record,sort_keys=True)+'\n');print(json.dumps(record),flush=True)
