"""Synthetic analysis and metadata only; no real confirmation score/data access."""
import ast,json,time,hashlib
from pathlib import Path
from analysis_recovery_locked import analyze_both
from analysis_locked import METHODS
root=Path(__file__).resolve().parent;start=time.process_time()
for name in ['guard_collect_blocking.py','recovery_guard.py','recovery_dispatch.py','recovery_driver.py','analysis_recovery_locked.py']:ast.parse((root/name).read_text())
old=json.loads((root/'FORMAL_PLAN.json').read_text());new=json.loads((root/'RECOVERY_PLAN.json').read_text());assert len(new['packs'])==99 and new['packs'][:98]==old['packs'][2:]
extra=new['packs'][-1];original=old['packs'][1];assert extra['action_id']=='technical_completion_00_IID_locked_v1' and extra['method']==original['method']=='IID_locked' and extra['global_instance_index']==0
for key in ['relative_data_file','data_file_sha256','input_sha256','code_sha256','group_index','local_instance_index']:assert extra[key]==original[key]
assert len({x['runtime_execution_id'] for x in old['packs']+[extra]})==101
rows=[{'global_instance_index':i,'method':m,'status':'ok','checker_status':'passed','used_bins':100+i+METHODS.index(m),'L1':99} for i in range(20) for m in METHODS]
missing=next(x for x in rows if x['global_instance_index']==0 and x['method']=='IID_locked');missing.update(status='infrastructure_unknown_original_claim',used_bins=None,L1=None,checker_status='not_available')
technical={'global_instance_index':0,'method':'IID_locked','status':'ok','checker_status':'passed','used_bins':101,'L1':99}
a=analyze_both(rows,technical,'synthetic_data','synthetic_analysis');assert a['strict_original_100_slots']['primary_EOH_minus_IID'] is None and a['strict_original_100_slots']['coverage']['IID_locked']=={'complete':19,'denominator':20}
assert a['technical_completion_sensitivity']['coverage']['IID_locked']=={'complete':20,'denominator':20} and a['technical_completion_sensitivity']['primary_EOH_minus_IID'] is not None
technical.update(status='numeric_failure',used_bins=None,checker_status='not_run');b=analyze_both(rows,technical,'synthetic_data','synthetic_analysis');assert b['technical_completion_sensitivity']['primary_EOH_minus_IID'] is None
assert json.loads((root/'RECOVERY_SWITCH.json').read_text())['enabled'] is False and not (root/'RECOVERY_AUTHORIZATION.json').exists()
record={'status':'PASS_SYNTHETIC_AND_METADATA_ONLY','checks':['source_parse','98_exact_original_unclaimed_rows','one_unique_extra_runtime_executionID','same_method_and_input_for_technical_only','strict_original_primary_null_and_n19_of20','separate_technical_full20_possible','technical_failure_stays_null_no_retry','disabled_no_authorization'],'candidate_calls':0,'real_instance_values_read':False,'real_performance_values_read':False,'CPU_seconds_before_report_write':time.process_time()-start}
with (root/'RECOVERY_SYNTHETIC_CHECKS.json').open('x') as f:json.dump(record,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps({'status':record['status'],'CPU':record['CPU_seconds_before_report_write']}))
