"""Frozen paired feedback pilot. Imports are inference-safe; execution needs approval."""
import argparse,hashlib,json,os,pathlib,re,resource,sys,time
from fractions import Fraction
sys.dont_write_bytecode=True
ROOT=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'src'))
from guard import verify,bounded_json,Budget

def save(path,obj):
 path=pathlib.Path(path)
 with path.open('x') as f:json.dump(obj,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
def authorize(path,expected):
 d=bounded_json(path,10000)
 if d.get('authorized') is not True or d.get('scope')!='typed_tree_feedback_packing4_once' or d.get('freeze_sha256')!=expected or not re.fullmatch('[A-Za-z0-9_-]{1,64}',d.get('run_id','')):raise ValueError('matching one-use approval required')
 return d

def checked_pack(raw,items,obs):
 from measurement import admit
 from checker import check_assignment
 p,_=admit(raw)
 if obs.get('returncode')!=0 or obs.get('termination') is not None or obs.get('error') is not None or obs.get('reaped') is not True or obs.get('cpu_evidence_complete') is not True:raise ValueError('packing worker transport/cleanup failure')
 b=obs['result']
 if b.get('pid')!=obs.get('pid') or b.get('limits')!={'RLIMIT_AS':[2147483648,2147483648],'RLIMIT_CPU':[20,20],'RLIMIT_FSIZE':[0,0],'RLIMIT_NOFILE':[32,32]}:raise ValueError('worker identity/limits')
 if b.get('program_sha256')!=p.raw_sha256 or b.get('canonical_program_sha256')!=p.canonical_sha256 or b.get('phase')!='pack':raise ValueError('source/phase binding')
 if b['status'] in ['numeric_invalid','resource_unresolved','diagnostic_unresolved']:
  if b.get('result') is not None or not isinstance(b.get('error'),dict):raise ValueError('failed outcome envelope')
  return {'status':b['status'],'error':b['error']}
 if b['status']!='packing_returned' or b['error'] is not None or b['warnings']['complete'] is not True:raise ValueError('packing outcome')
 r=b['result'];c=check_assignment(items,100,r['assignment'],r['used_bins'],r['residuals'])
 return dict(status='feasible',used_bins=c['used_bins'],L1=c['L1'],placements=c['n'],feasibility=c)

def execute(plan,expected,approval):
 out=ROOT/'runs'/approval['run_id'];out.mkdir(parents=True,exist_ok=False)
 uses=ROOT/'.authorization_uses';uses.mkdir(exist_ok=True);save(uses/(approval['run_id']+'.json'),approval)
 resource.setrlimit(resource.RLIMIT_AS,(536870912,4294967296));resource.setrlimit(resource.RLIMIT_CPU,(1000,1000))
 budget=Budget(plan);errors=[];dispatch=[];grammar=None
 slots=bounded_json(ROOT/'transport_preparation.json')['slots'];rows=[dict(s,status='not_run',reason='not_reached') for s in slots]
 names=['FF','BF']+[s['id'] for s in slots]
 ledger=[{'method':name,'instance':i,'status':'not_run','reason':'not_reached'} for name in names for i in range(5)]
 programs={};events=(out/'events.jsonl').open('x')
 def emit(kind,value):events.write(json.dumps({'event':kind,'payload':value},allow_nan=False)+'\n');events.flush();os.fsync(events.fileno())
 def reserve(kind):
  try:budget.reserve(kind);return True
  except RuntimeError:return False
 try:
  verify(expected,full=True)
  from measurement import admit,strict_json
  from typed_tree import compile_tree
  from transport_check import decode
  from runtime import request
  sys.path.insert(0,str(ROOT/'transport'));sys.path.insert(0,str(ROOT.parent/'paper_baseline_v1/src'))
  from backend import run_once
  transport=bounded_json(ROOT/'transport_protocol.json');data=bounded_json(ROOT/'data/design_prefixes.json')['items']
  assert len(data)==5 and all(len(v)==256 for v in data)
  save(out/'initial_ledger.json',{'requests':rows,'scores':ledger,'freeze_sha256':expected})
  for i,(slot,row) in enumerate(zip(slots,rows)):
   verify(expected)
   if not reserve('model'):row['reason']='insufficient_reserved_budget';continue
   row.update(status='pre_dispatch',reason=None);entry={'kind':'model','slot_id':slot['id'],'state':'entered_backend'};dispatch.append(entry);emit('model_start',entry)
   directory=out/'generation'/slot['id'];start=time.monotonic();result=run_once(i,(ROOT/slot['request_file']).read_bytes(),directory);wall=time.monotonic()-start
   entry.update(state='returned',post_requests_sent=result.get('post_requests_sent',0));row['generation_evidence']=str(directory.relative_to(out))
   if wall>120:raise ValueError('full model lifecycle exceeded 120 seconds')
   if 'json schema conversion was incomplete' in (directory/'server_stderr.log').read_text(errors='replace').lower():raise ValueError('incomplete schema conversion')
   raw=(directory/'response_body.json').read_bytes() if (directory/'response_body.json').exists() else b'';outcome=decode(slot,raw,result,slot,transport)
   metadata=outcome.get('metadata');row['metadata']=metadata
   if metadata:
    gh=metadata['grammar_sha256']
    if grammar is not None and gh!=grammar:raise ValueError('same schema grammar changed')
    grammar=gh;(directory/'effective_grammar.gbnf').write_text(strict_json(raw)['generation_settings']['grammar'])
   save(directory/'decoded.json',{k:v for k,v in outcome.items() if k!='content'})
   if outcome['status']!='completed_valid_transport':row.update(status='generation_failed',reason=outcome['status'])
   else:
    if (directory/'content.txt').read_bytes()!=outcome['content']:raise ValueError('original content binding')
    p,obj=compile_tree(outcome['content']);content=json.dumps(obj,separators=(',',':'),allow_nan=False).encode();admit(content)
    (directory/'compiled_dag.json').write_bytes(content);programs[slot['id']]=content;row.update(status='dag_admitted',reason=None)
   emit('model_terminal',row)
  for name in ['FF','BF']:programs[name]=(ROOT.parent/'math_dag_evolution_v1/seeds'/(name.lower()+'.json')).read_bytes()
  for lr in ledger:
   name=lr['method'];items=data[lr['instance']]
   if name not in programs:lr['reason']='candidate_not_admitted';continue
   verify(expected)
   if not reserve('score'):lr['reason']='insufficient_reserved_budget';continue
   mark=budget.score_mark();lr.update(status='pre_dispatch',reason=None);raw=programs[name];payload={'mode':'pack','program_json':raw.decode(),'items':items,'capacity':100}
   sd=out/'scores'/f"{name}_{lr['instance']}";sd.mkdir(parents=True);save(sd/'request.json',payload)
   entry={'kind':'score','method':name,'instance':lr['instance'],'state':'entered_worker'};dispatch.append(entry);emit('score_start',entry)
   try:
    obs=request(payload);entry.update(state='returned',reaped=obs.get('reaped'));save(sd/'observation.json',obs);lr['observation']=str((sd/'observation.json').relative_to(out))
    result=checked_pack(raw,items,obs);save(sd/'checked.json',result);lr.update({k:v for k,v in result.items() if k!='feasibility'});emit('score_terminal',lr)
   finally:budget.score_charge(mark)
 except Exception as exc:errors.append(type(exc).__name__+': '+str(exc))
 finally:
  for row in rows+ledger:
   if row['status']=='pre_dispatch':row.update(status='infrastructure_failure',reason=errors[-1] if errors else 'unterminated')
   elif row.get('reason')=='not_reached':row['reason']='stopped_before_slot'
  events.close()
  try:verify(expected,full=True)
  except Exception as exc:errors.append('final_integrity: '+str(exc))
  groups=[]
  for name in names:
   rs=[x for x in ledger if x['method']==name and x['status']=='feasible'];g={'method':name,'completed_feasible':len(rs)}
   if len(rs)==5:
    fit=sum((Fraction(x['L1'],x['used_bins']) for x in rs),Fraction())/5;g.update(bins=[x['used_bins'] for x in rs],sum_bins=sum(x['used_bins'] for x in rs),mean_L1_over_bins=float(fit),exact_fitness=str(fit))
   groups.append(g)
  by={g['method']:g for g in groups};pairs=[]
  for i in range(2):
   c,f=by[f'control_s{i}'],by[f'feedback_s{i}'];p={'pair':i,'status':'incomplete'}
   if c['completed_feasible']==f['completed_feasible']==5:p.update(status='complete',feedback_minus_control_sum_bins=f['sum_bins']-c['sum_bins'])
   pairs.append(p)
  costs=budget.terminal()
  if not costs['within_charged_budget']:errors.append('observed budget exceeded')
  report={'state':'completed' if not errors else 'incomplete','freeze_sha256':expected,'requests':rows,'ledger':ledger,'groups':groups,'pairs':pairs,'dispatches':dispatch,'errors':errors,'costs':costs,'formal_posts_observed':sum(x.get('post_requests_sent',0) for x in dispatch),'score_dispatches':sum(x['kind']=='score' for x in dispatch),'unknown_launch_states':sum(x['state'].startswith('entered') for x in dispatch),'grammar_sha256':grammar,'scope':plan['scope'],'timing_boundary':'Through final integrity, reserve covers final report and outer wrapper.'}
  save(out/'report.json',report);print(json.dumps({'state':report['state'],'errors':errors,'groups':groups,'pairs':pairs,'costs':costs}),flush=True);return report

def main():
 p=argparse.ArgumentParser();p.add_argument('--freeze-sha256',required=True);p.add_argument('--execute-approved',action='store_true');p.add_argument('--approval');a=p.parse_args();verify(a.freeze_sha256)
 if not a.execute_approved:print(json.dumps({'state':'verified_only','model_calls':0,'score_calls':0}));return
 if not a.approval:raise ValueError('approval required')
 r=execute(bounded_json(ROOT/'protocol.json'),a.freeze_sha256,authorize(a.approval,a.freeze_sha256))
 if r['state']!='completed':raise SystemExit(1)
if __name__=='__main__':main()
