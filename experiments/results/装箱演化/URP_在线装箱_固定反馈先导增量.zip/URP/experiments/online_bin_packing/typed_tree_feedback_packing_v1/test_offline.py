"""Offline orchestration mocks only: zero inference and zero solver launches."""
import contextlib,io,json,pathlib,shutil,sys,tempfile,types,unittest
from unittest.mock import patch
sys.dont_write_bytecode=True
HERE=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(HERE));sys.path.insert(0,str(HERE/'src'));sys.path.insert(0,str(HERE.parent/'paper_baseline_v1/src'))
import run_pilot as pilot
from typed_tree import compile_tree
from measurement import admit
from guard import Budget
TREE=b'{"schema":"typed-tree-v1","score":["sub",0,"bins"]}'

def fake_backend(i,request,d):
 d.mkdir(parents=True);(d/'content.txt').write_bytes(TREE);(d/'server_stderr.log').write_text('');(d/'response_body.json').write_text('{}')
 return {'post_requests_sent':1}
def fake_decode(*a):return {'status':'completed_valid_transport','content':TREE}
def fake_pack(payload):
 p,_=admit(payload['program_json'].encode());items=payload['items'];n=len(items)
 return {'returncode':0,'termination':None,'error':None,'reaped':True,'cpu_evidence_complete':True,'pid':123,'result':{'pid':123,'limits':{'RLIMIT_AS':[2147483648]*2,'RLIMIT_CPU':[20]*2,'RLIMIT_FSIZE':[0]*2,'RLIMIT_NOFILE':[32]*2},'program_sha256':p.raw_sha256,'canonical_program_sha256':p.canonical_sha256,'phase':'pack','status':'packing_returned','error':None,'warnings':{'complete':True},'result':{'assignment':list(range(n)),'used_bins':n,'residuals':[100-x for x in items]}}}
class Tests(unittest.TestCase):
 def run_mock(self,reserve=None):
  with tempfile.TemporaryDirectory() as tmp:
   root=pathlib.Path(tmp)/'pilot';root.mkdir()
   for f in ['transport_preparation.json','transport_protocol.json','protocol.json']:shutil.copy(HERE/f,root/f)
   shutil.copytree(HERE/'requests',root/'requests');shutil.copytree(HERE/'data',root/'data');shutil.copytree(HERE.parent/'math_dag_evolution_v1/seeds',root.parent/'math_dag_evolution_v1/seeds')
   modules={'backend':types.SimpleNamespace(run_once=fake_backend),'transport_check':types.SimpleNamespace(decode=fake_decode),'runtime':types.SimpleNamespace(request=fake_pack)}
   with patch.object(pilot,'ROOT',root),patch.object(pilot,'verify',lambda *a,**k:None),patch.object(pilot.resource,'setrlimit',lambda *a:None),patch.dict(sys.modules,modules),contextlib.redirect_stdout(io.StringIO()):
    if reserve:
     with patch.object(Budget,'reserve',reserve):r=pilot.execute(json.loads((root/'protocol.json').read_text()),'offline_mock',{'run_id':'mock','authorized':True})
    else:r=pilot.execute(json.loads((root/'protocol.json').read_text()),'offline_mock',{'run_id':'mock','authorized':True})
   return r
 def test_full_offline_orchestration(self):
  r=self.run_mock();self.assertEqual(r['errors'],[]);self.assertEqual(r['formal_posts_observed'],4);self.assertEqual(r['score_dispatches'],30);self.assertEqual([g['completed_feasible'] for g in r['groups']],[5]*6);self.assertEqual([p['feedback_minus_control_sum_bins'] for p in r['pairs']],[0,0])
 def test_budget_not_run(self):
  def deny(*a):raise RuntimeError('budget unavailable')
  r=self.run_mock(deny);self.assertEqual(r['formal_posts_observed'],0);self.assertEqual(r['score_dispatches'],0);self.assertTrue(all(x['status']=='not_run' for x in r['requests']+r['ledger']))
 def test_pairing(self):
  ps=json.loads((HERE/'prompts.json').read_text());self.assertEqual([p['seed'] for p in ps],[2026100900,2026100900,2026100901,2026100901]);self.assertEqual(ps[0]['prompt'],ps[3]['prompt']);self.assertEqual(ps[1]['prompt'],ps[2]['prompt']);self.assertTrue(ps[1]['prompt'].startswith(ps[0]['prompt']))
 def test_compiler_no_generated_python(self):
  compile_tree(TREE)
  with self.assertRaises(ValueError):compile_tree(b'__import__("os").system("true")')
if __name__=='__main__':unittest.main()
