"""One separately approved and disclosed recovery attempt; no automatic retry."""
import argparse,copy,hashlib,json,os,pathlib,resource,sys,time
sys.dont_write_bytecode=True
ROOT=pathlib.Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def save(p,value):
 with p.open('x') as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
def main():
 start=time.monotonic();cpu=time.process_time();before=resource.getrusage(resource.RUSAGE_CHILDREN)
 a=argparse.ArgumentParser();a.add_argument('--freeze-sha256',required=True);a.add_argument('--approval',required=True);args=a.parse_args()
 freeze_path=ROOT/'final_freeze.json'
 if sha(freeze_path)!=args.freeze_sha256:raise ValueError('recovery freeze mismatch')
 frozen=json.loads(freeze_path.read_text())
 for p,h in frozen['files'].items():
  if sha(ROOT/p)!=h:raise ValueError('recovery file changed: '+p)
 plan=json.loads((ROOT/'protocol.json').read_text());original=ROOT.parent/plan['original_directory']
 if sys.executable!=plan['python_executable'] or sha(sys.executable)!=plan['python_executable_sha256']:raise ValueError('interpreter mismatch')
 for p,h in plan['prior_evidence_hashes'].items():
  if sha(original/p)!=h:raise ValueError('prior evidence changed')
 approval=json.loads(pathlib.Path(args.approval).read_text())
 if approval!={'authorized':True,'scope':'typed_tree_feedback_recovery_once','freeze_sha256':args.freeze_sha256,'run_id':plan['run_id']}:raise ValueError('matching recovery approval required')
 # Claim the single recovery authorization before any attempted dispatch.
 claim=ROOT/'authorization_use.json';save(claim,approval)
 mem={s.split(':')[0]:int(s.split()[1])*1024 for s in pathlib.Path('/proc/meminfo').read_text().splitlines() if len(s.split())>=3}
 if mem['MemAvailable']<5368709120:
  save(ROOT/'prelaunch_stop.json',{'reason':'MemAvailable_below_5GiB_no_launch','MemAvailable_bytes':mem['MemAvailable'],'model_posts':0,'score_dispatches':0,'no_retry':True});raise SystemExit(1)
 sys.path.insert(0,str(original));import run_pilot
 run_pilot.verify(plan['original_freeze_sha256'],full=True)
 inherited=json.loads((original/'protocol.json').read_text());modified=copy.deepcopy(inherited)
 modified['aggregate_budgets']['preparation_debit']=plan['combined_nonexecution_debit']
 report=run_pilot.execute(modified,plan['original_freeze_sha256'],{'authorized':True,'scope':'typed_tree_contract_recovery_disclosed_once','freeze_sha256':plan['original_freeze_sha256'],'run_id':plan['run_id'],'recovery_freeze_sha256':args.freeze_sha256})
 after=resource.getrusage(resource.RUSAGE_CHILDREN);owncpu=time.process_time()-cpu+after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime;wall=time.monotonic()-start
 debit=plan['combined_nonexecution_debit'];chargedcpu=owncpu+debit['cpu_seconds'];chargedwall=wall+debit['active_wall_seconds']
 saved={'recovery_freeze_sha256':args.freeze_sha256,'original_freeze_sha256':plan['original_freeze_sha256'],'run_id':plan['run_id'],'current_outer_cpu_seconds':owncpu,'current_outer_active_wall_seconds':wall,'combined_debit':debit,'combined_charged_cpu_seconds':chargedcpu,'combined_charged_active_wall_seconds':chargedwall,'within_combined_budget':chargedcpu<=1200 and chargedwall<=900,'prior_attempt':plan['prior_attempt'],'prelaunch_MemAvailable_bytes':mem['MemAvailable'],'disclosure':'Second attempt explicitly approved after zero-POST zero-score infrastructure failure. No prompt/model/backend changes. Shared 1200CPU/900activewall includes both preparation debits, prior outer runtime and five-second prior postcheck allowance. Forty-second terminal reserve covers final writes/postcheck; no further recovery permitted.','current_report':str((original/'runs'/plan['run_id']/'report.json').relative_to(ROOT.parent))}
 save(ROOT/'outer_accounting.json',saved);print(json.dumps(saved),flush=True)
 if report['state']!='completed' or not saved['within_combined_budget']:raise SystemExit(1)
if __name__=='__main__':main()
