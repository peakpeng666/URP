"""Bounded packing check of four already-recorded typed-tree outputs.

No new inference, no candidate Python execution, no old experiment mutation.
"""
import hashlib
import json
import pathlib
import resource
import sys
import time
from fractions import Fraction

sys.dont_write_bytecode = True
HERE = pathlib.Path(__file__).resolve().parent
BASE = HERE.parent
sys.path.insert(0, str(BASE / 'math_dag_v1/src'))
from runtime import request
from schema import validate_program
sys.path.insert(0, str(BASE / 'paper_baseline_v1/src'))
from checker import check_assignment


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


def sources():
    generation = BASE / 'typed_tree_contract_v1/runs/typed_tree_pilot_20261005_01/generation'
    programs = {name: generation / name / 'compiled_dag.json'
                for name in ('fixed_transcription', 'design_0', 'design_1', 'design_2')}
    programs.update({name: BASE / 'math_dag_evolution_v1/seeds' / (name.lower() + '.json')
                     for name in ('FF', 'BF')})
    data = BASE / 'paper_baseline_v1/data/historical_numeric.json'
    files = [pathlib.Path(__file__).resolve(), data, *programs.values(),
             BASE / 'paper_baseline_v1/src/checker.py']
    files += list((BASE / 'math_dag_v1/src').glob('*.py'))
    return programs, data, files


def prepare():
    programs, data_path, files = sources()
    values = json.loads(data_path.read_text())['sets']['historical_design_5k']
    assert len(values) == 5 and all(len(x) == 5000 for x in values)
    for path in programs.values():
        validate_program(path.read_bytes())
    plan = {
        'scope': 'Post-generation descriptive packing check; not evolution or full-paper reproduction',
        'reuse': 'Four previously generated outputs, no new model requests; all scored without selection',
        'data': 'First 256 items of each of five historical 5000-item design sequences. Previously exposed data, not blind or independent test.',
        'capacity': 100, 'items_per_instance': 256, 'instances': 5,
        'methods': list(programs),
        'source_hashes': {str(p.relative_to(BASE)): digest(p) for p in files},
        'fragment_hashes': [hashlib.sha256(json.dumps(x[:256], separators=(',', ':')).encode()).hexdigest() for x in values],
        'worker_limits': {'cpu_seconds': 20, 'wall_seconds': 30, 'cleanup_seconds': 1,
                          'address_space_bytes': 2147483648, 'stdout_bytes': 400000},
        'budget': {'cpu_seconds': 150, 'active_wall_seconds': 240,
                   'preparation_debit_seconds': 10, 'terminal_reserve_seconds': 5},
        'selection': 'All preallocated feasible bins, first argmax; nonfinite final scores reject without repair',
        'metrics': ['bins per instance', 'exact mean L1/bins over all five completed feasible cases'],
        'stop': 'Infrastructure, integrity or independent feasibility failure stops dispatch; numeric invalid remains an outcome',
        'retries': 0,
    }
    save(HERE / 'protocol.json', plan)
    print(digest(HERE / 'protocol.json'))


def run(expected):
    assert digest(HERE / 'protocol.json') == expected
    plan = json.loads((HERE / 'protocol.json').read_text())
    def verify():
        assert all(digest(BASE / p) == h for p, h in plan['source_hashes'].items())
    verify()
    out = HERE / 'run'
    out.mkdir(exist_ok=False)
    programs, data_path, _ = sources()
    data = [x[:256] for x in json.loads(data_path.read_text())['sets']['historical_design_5k']]
    start, own = time.monotonic(), time.process_time()
    before = resource.getrusage(resource.RUSAGE_CHILDREN)
    def costs():
        child = resource.getrusage(resource.RUSAGE_CHILDREN)
        return {'cpu_seconds': time.process_time() - own + child.ru_utime + child.ru_stime - before.ru_utime - before.ru_stime,
                'wall_seconds': time.monotonic() - start}
    rows, errors = [], []
    for name, path in programs.items():
        raw = path.read_bytes()
        program = validate_program(raw)
        for index, items in enumerate(data):
            row = {'method': name, 'instance': index, 'status': 'not_run'}
            rows.append(row)
            spent = costs()
            if errors:
                row['reason'] = 'stopped_after_error'
                continue
            if spent['cpu_seconds'] + 10 + 20 + 5 > 150 or spent['wall_seconds'] + 10 + 31 + 5 > 240:
                row['reason'] = 'insufficient_reserved_budget'
                continue
            try:
                verify()
                payload = {'mode': 'pack', 'program_json': raw.decode(), 'items': items, 'capacity': 100}
                slot = out / f'{name}_{index}'
                slot.mkdir()
                save(slot / 'request.json', payload)
                obs = request(payload)
                save(slot / 'observation.json', obs)
                assert obs['reaped'] and obs['cpu_evidence_complete']
                assert obs['returncode'] == 0 and obs['termination'] is None and obs['error'] is None
                body = obs['result']
                assert body['program_sha256'] == program.raw_sha256 and body['phase'] == 'pack'
                row.update(status=body['status'], observation=str((slot / 'observation.json').relative_to(HERE)))
                if body['status'] == 'numeric_invalid':
                    row['numeric_error'] = body['error']
                    continue
                assert body['status'] == 'packing_returned' and body['error'] is None
                assert body['warnings']['complete']
                result = body['result']
                checked = check_assignment(items, 100, result['assignment'], result['used_bins'], result['residuals'])
                save(slot / 'feasibility.json', checked)
                row.update(status='feasible', used_bins=checked['used_bins'], L1=checked['L1'],
                           placements=checked['n'], warning_count=len(body['warnings']['events']))
            except Exception as exc:
                row.update(status='error', reason=type(exc).__name__ + ': ' + str(exc))
                errors.append(row.copy())
    verify()
    groups = []
    for name in programs:
        selected = [r for r in rows if r['method'] == name and r['status'] == 'feasible']
        entry = {'method': name, 'completed_feasible': len(selected)}
        if len(selected) == 5:
            fitness = sum((Fraction(r['L1'], r['used_bins']) for r in selected), Fraction()) / 5
            entry.update(bins=[r['used_bins'] for r in selected], sum_bins=sum(r['used_bins'] for r in selected),
                         mean_L1_over_bins=float(fitness), exact_fitness=str(fitness))
        groups.append(entry)
    spent = costs()
    report = {'protocol_sha256': expected, 'rows': rows, 'groups': groups, 'errors': errors,
              'cost': spent, 'preparation_debit_seconds': 10,
              'charged_cpu_seconds': spent['cpu_seconds'] + 10,
              'charged_active_wall_seconds': spent['wall_seconds'] + 10,
              'new_model_calls': 0, 'new_solver_dispatches': sum('observation' in r or r['status'] == 'error' for r in rows),
              'verified_placements': sum(r.get('placements', 0) for r in rows),
              'boundary': 'Budget excludes final report serialization with five seconds reserved. Reuses old generated programs and exposed design prefixes; not a new independent model sample.'}
    assert spent['cpu_seconds'] + 10 < 150 and spent['wall_seconds'] + 10 < 240
    save(out / 'report.json', report)
    print(json.dumps({'groups': groups, 'errors': errors, 'cost': spent}, ensure_ascii=False))
    if errors:
        raise SystemExit(1)


if __name__ == '__main__':
    if sys.argv[1:] == ['prepare']:
        prepare()
    elif len(sys.argv) == 3 and sys.argv[1] == 'run':
        run(sys.argv[2])
    else:
        raise SystemExit('Use prepare or run FROZEN_PROTOCOL_SHA256')
