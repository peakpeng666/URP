# URP 研究状态总表

更新：2026-10-05 UTC。本表是当前研究状态的统一入口；实验目录中的冻结协议、原始记录和历史报告保持原样。当前主线为VRP／CVRP任务优化与LLM自动算法设计，在线装箱用于生成、评价与反馈机制验证；果园导航及覆盖规划保留为独立历史分支，不替代主线。

## 阅读口径

- “已运行”指已有保存的实际运行证据；本次文档整理只核对保存文件，没有重新运行实验、模型或作者代码
- 实例、随机种子、生成请求、执行形式、评分槽位、物品分配和重放是不同分母；不合并成独立样本。源文件中的历史“尚未开展”只描述当时阶段
- 静态审阅、保存结果复核、数值门槛、固定算法重评分、教学先导和完整论文复现分别判断；通过格式或可行性检查不代表算法质量提高
- 已发布包仍对应原版本。本表和根README属于下一版本文档补丁，未表示GitHub／Drive同步完成；复现入口沿用原目录，不移动冻结证据

## 当前状态与证据

以下链接均相对于本文件。每行范围独立，不能将不同批次的数字直接相加作为研究样本量。

|研究项|状态及分母|当前结论与限制|依据|
|---|---|---|---|
|P1：GA／PSO基础比较|已运行：3函数×2算法×20配对种子=120次；每次10000评价|10维开发实验与报告已具备；不是论文原规模复现或教师自动验收|[实验说明](../experiments/function_optimization/README.md)、[核验](../experiments/function_optimization/results/verification.json)|
|P1扩展：DE|已运行：3函数×20种子=60次，600000评价|沿用P1初始种群；看过GA／PSO结果后的探索扩展，非独立盲测|[说明](../experiments/function_optimization_de/README.md)、[保存结果核验](../experiments/function_optimization_de/results/postrun_audit.json)|
|DEAP教学|已运行：1函数、1种子、420评价、21条轨迹|正式框架练习；不证明算法优势、全部框架知识掌握或与P1数值等价|[说明](../experiments/deap_teaching_v1/README.md)、[核验](../experiments/deap_teaching_v1/results/postrun_audit.json)|
|CVRP基础与局部搜索|已运行：24开发实例；基础216次；修正版局部搜索360次，重放另计|v2为当前修正版；旧v1保留。客户覆盖、容量和目标独立检查不能替代农业实证|[基础说明](../experiments/vehicle_routing/README.md)、[局部搜索v2](../experiments/vehicle_routing/local_search_v2/README.md)|
|成熟求解器与规模预算|已运行：小规模504次；另24新开发实例432次主调用及432次重放|PyVRP短预算原有4例落后受初始化影响；两种距离缩放不是不同算法家族|[成熟求解器](../experiments/vehicle_routing/mature_pyvrp_v1/README.md)、[规模预算](../experiments/vehicle_routing/scale_budget_v1/README.md)|
|初始化控制、新实例及事后选择|已运行：288主调用+288重放；另20新实例600主调用+120预选重放，8次定步诊断另计|事后oracle相对固定warm的平均逐实例剩余改善仅0.02672056%／0.03016481%；不是可执行推荐器、置信上界或H1/H2结果|[初始化](../experiments/vehicle_routing/initialization_ablation_v1/README.md)、[新实例](../experiments/vehicle_routing/fresh_initialization_replication_v1/README.md)|
|OR-Tools对照|已运行：24复用开发实例×4配置×3计时标签×2预算=576次；192次预选重放另计|当前配置两预算下均落后warm PyVRP；不外推求解器排名，计时标签不是OR随机种子|[说明](../experiments/vehicle_routing/ortools_baseline_v1/README.md)|
|本地模型直接生成路线|已运行小先导：4实例、8模型调用，严格可行2/8|直接输出路线不等于生成求解算法；事后修正诊断与工作台QA不改变原先导指标|[网页快照说明](../web/README.md)、[本地桥接](../web/LOCAL_MODEL_BRIDGE.md)、[来源清单](../web/data-manifest.json)|
|CVRP工作台|已有离线任务编辑、规则需求解析和成熟求解器文件桥接|操作原型不等于在线LLM集成、地理场景验证或研究收益；有限车队等边界见说明|[工作台](../web/PLANNER.md)、[桥接](../web/BRIDGE.md)|
|果园导航历史分支|已运行：12合成底图、96查询、960主调用；192保存重放另列|四邻接图与静态足迹；不是连续动力学、覆盖规划或田间验证；嵌套查询不是独立地图样本|[保存报告](../experiments/orchard_navigation/results/reporting_v2/viewer_data.json)、[网页说明](../web/README.md)|
|P2：历史生成及评测|32原始生成形式、10既有提取形式；v2为780请求；v3为864请求|v3全部72用例协议为raw 0/32、extracted 0/10；29结构拒绝和1语言拒绝未执行。提取形式不是新独立候选|[v2](../experiments/isolated_evaluator/delivery_v2/RESULTS_ZH.md)、[v3目录](../experiments/isolated_evaluator/delivery_v3/)|
|P2：前瞻五对提示比较|已运行：10新输出；7语言拒绝，3准入形式×144用例=432测量|有效输入360/360符合；非法输入72测量中24不符合；严格A/B均0/5。不将教师未要求的异常合同倒写成“不会排序”；未证明提示优化有效|[批次说明](../experiments/isolated_evaluator/prospective_prompt_v4_compat/README.md)、[教学要求核对](code_review/teacher/六阶段代码核查.md)|
|P3：自定义装箱基线|已运行：360冻结开发序列、720次FF／BF调用|BF胜160、FF胜2、平198；基线接近不代表接近最优；不与论文历史序列合并|[说明](../experiments/online_bin_packing/README.md)|
|P3：历史测试集固定策略|已运行：15序列×2容量×2基线=60；固定已发表公式30槽位另列|固定算法重评分，非新模型发现。两容量共享序列；容量缺陷诊断不能冒充全部实例容量500的正确结果|[基线](../experiments/online_bin_packing/paper_baseline_v1/README.md)、[固定公式目录](../experiments/online_bin_packing/published_eoh_formula_v1/)、[论文机制核对](code_review/teacher/六阶段代码核查.md)|
|P3：完整历史设计集|已运行：5实例×5000物品×3固定策略=15槽位|FF／BF／固定EoH总箱数10359／10335／10007；0.993204的固定公式fitness不是产生公式的20代搜索复现。作者字节只在数值门槛执行，正式槽位用可信重实现|[结果及数值门槛](../experiments/online_bin_packing/paper_design_panel_v1/RESULTS_ZH.md)|
|P3：固定公式参数网格|已运行：27参数组×5设计实例=135槽位；赢家5测试槽位另列；0模型调用|3组并列最优，按预定规则选择原参数；未改善。不等于生成搜索或新盲测|[汇总](../experiments/online_bin_packing/eoh_parameter_control_v1/delivery/summary.json)|
|P3：受限DAG两代先导|已运行：旧22物理模型请求；紧凑接口3请求／9微例另列；新紧凑两代22请求|旧批20次上限停止、2类型拒绝；新批15拒绝、7入评分、4完整资格、3数值失败；完整候选均未胜手写种子，没有生成父代持续改进实证|[旧批结果](../experiments/online_bin_packing/math_dag_evolution_v1/delivery/RESULTS_ZH.md)、[接口](../experiments/online_bin_packing/math_dag_interface_v2_1/README.md)、[紧凑批结果](../experiments/online_bin_packing/math_dag_evolution_compact_v2/delivery/RESULTS_ZH.md)|
|P3：有类型树接口|已运行：4模型请求、12手写微型向量评分|接口准入与数值检查；该阶段没有真实序列装箱质量评价，后续评分另列|[汇总](../experiments/online_bin_packing/typed_tree_contract_v1/delivery/summary.json)|
|P3：旧树输出装箱检验|已运行：复用上述4输出；0新模型调用；6策略×5个256项前缀=30评分|旧输出中转写与设计2箱数同BF；设计0／1一物一箱。30可行、7680分配独立重算；无胜BF证据|[结果](../experiments/online_bin_packing/typed_tree_packing_check_v1/RESULTS_ZH.md)、[核验](../experiments/online_bin_packing/typed_tree_packing_check_v1/postcheck.json)|
|P3：类型树反馈对照（最新）|已运行：4新模型POST、2对种子；4候选+FF／BF共30评分，7680分配|反馈减对照总箱数[-731,0]；一份反馈重现FF，所有候选未胜BF。只用固定历史反馈，不是多代演化、显著性结论或未见泛化|[实际批次报告](../experiments/online_bin_packing/typed_tree_feedback_packing_v1/runs/feedback_pilot_20261005_02/report.json)、[恢复后独立核验](../experiments/online_bin_packing/typed_tree_feedback_recovery_v1/independent_postcheck.json)|
|P4：简单RL NAS|已运行：3配对种子×2方法×8候选=48训练，固定基线另1；选后5000图像评估|RL与随机三个种子均选相同权重，未观察到RL优势；官方测试未用，小预算不是完整论文训练|[实验说明](../experiments/architecture_search/README.md)、[教学核对](code_review/teacher/六阶段代码核查.md)|
|P5：多问题LLM+EA+评估系统|未完成|多个独立目录不等于统一系统已验收；缺多问题一致合同、成本账本与公平对照|[要求及缺口](code_review/teacher/六阶段代码核查.md)|
|P6：原创方法与论文|未完成|尚无冻结对照、消融和确认性结果支持完整原创方法验收；负先导不能单独证明领域空白|[要求及缺口](code_review/teacher/六阶段代码核查.md)|
|教师／文献代码核查|静态来源审阅已具备|固定源码调用链、来源与风险核对不等于作者代码运行或论文复现；实际运行另凭上列证据|[六阶段核查](code_review/teacher/六阶段代码核查.md)、[来源清单](code_review/teacher/upstream_manifest.json)|

## 最新反馈批次的精确解释

实际结果来自 `feedback_pilot_20261005_02`。首次 `_01` 在发起模型和评分之前因可用内存门槛停止，为0 POST、0评分；其准备与失败成本仍保留，不算新增样本。恢复后独立核验只复查保存结果，新增模型与求解器调用均为0，不再次累加到4／30。

|方法|5个256项前缀总箱数|与基线的关系|
|---|---:|---|
|FF|549|固定基线|
|BF|546|本批最少箱数|
|control_s0|1280|一物一箱|
|feedback_s0|549|五条保存分配轨迹均与FF相同，未胜BF|
|control_s1|1280|一物一箱|
|feedback_s1|1280|一物一箱|

差值按每对种子的五个前缀总箱数计算，负数表示反馈臂更少；它不是每实例百分比或独立五次改进。只有2对种子、数据已暴露、提示长度不同、候选空间受限，不能据[-731,0]宣布可靠反馈收益。均值 `mean(L1_i/bins_i)` 与论文表格用的聚合超额比不是同一指标，不互相替代。资源上限、实测值、准备扣账与最终预留按批次账本分别解释，不把费用未知写成0。

完整EoH仍缺目标论文设置下的双表示与算子搜索、充分重复、匹配对照／消融及对应完整评测；既有固定策略与受限先导分别是其中的组件证据。P3最新反馈实验没有完成这些缺口，也不完成P5／P6。

## 网页快照与复现环境

[网页来源清单](../web/data-manifest.json)生成时间为2026-10-05T00:47:52.021Z；[静态验收记录](../web/tests/static-verification.json)记载460项主来源、229/229测试通过，快照32740348字节。这里引用既有记录，本次未重建或重新跑测试。页面还没有纳入最新旧树装箱30评分与反馈4 POST／30评分，不能只看网页推断本表最新状态。`web/data/`并非现存数据目录；实际数据入口为 `web/embedded-data.js` 和 `web/data-manifest.json`。

直接打开 `web/index.html` 查看研究快照；任务点操作用 `web/planner.html`。具体依赖、运行命令和实验配置见各目录README及冻结协议。真实浏览器视觉验收仍未完成，模拟DOM和静态测试不替代实际浏览器验收。当前实测Debian／Python环境不能写成已验证Ubuntu 22.04；模型权重、运行时及第三方依赖应按各批固定来源核验。

本地模型已有实际小先导记录；URP在线科研推理通路仍未验证。接口POST次数不等于付费在线服务调用。文档修订没有启动实验、发模型请求或发布新版本。
