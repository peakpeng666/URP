# 公开复核与重新实验边界

## 主包依赖

此ZIP是增量证据包，不修改主包或前端。配套主包：URP_实验项目_20261005_教学进度与固定策略对照.zip，SHA256：

ae189573bbd6495524a37ba3fd686538755b0d2f81f4e45a51167c9a677edab6

REUSED_DEPENDENCIES.json 对198个复用文件列出主包内路径、大小与SHA256，制作时已逐项与该主包验证。新增三个实验目录按URP原目录布局保留；主包中的数学DAG解释器、历史数据、旧生成树、FF/BF和其他被冻结来源继续复用。

## 无模型、无求解器的结果复核

在新目录解压此增量ZIP，运行：

    python3 verify_public.py --main-zip /path/to/URP_实验项目_20261005_教学进度与固定策略对照.zip

脚本只读主包ZIP和本包文件，验证主包hash、198个复用文件、本包公开manifest、60份已保存装箱观测的容量/箱数/残余量、配对差值与轨迹相同性。不联网、不加载模型、不启动求解器或执行候选代码。它验证已保存结果，不证明浮点评分的独立重放、在线因果性或实验一般化。

原始源代码随包保留。若要运行mock测试，可先在另一个新目录解压主包与此增量，再运行：

    PYTHONDONTWRITEBYTECODE=1 python3 URP/experiments/online_bin_packing/typed_tree_feedback_packing_v1/test_offline.py

这四个测试使用假transport/解码/评分输出，仅测试编译拒绝、配对、账本与预算not_run逻辑，不是新模型或求解器实验。

## 环境外置

EXTERNAL_ENVIRONMENT.json列出Qwen/Qwen3-4B-GGUF固定revision和GGUF文件hash、llama.cpp b11387/commit及官方发行包hash、Python3.12、NumPy2.3.5、Jinja2 3.1.6、MarkupSafe3.0.2与模板hash。模型权重、二进制库、Python环境、缓存和venv不随包分发。原始冻结与运行观测中的绝对路径属于历史机器，不能在另一环境直接照抄。

新模型实验需要使用这些外置依赖并重新验证环境、路径、模板、限额和模型来源，建立新的独立环境快照、输出目录及研究方案。保留上下文2048、2线程、4GiB单模型生命周期、5GiB可用内存启动门槛及原worker20CPU/30wall/2GiB，不放宽原解释器<=256项或执行生成Python。任何新实验均应由使用者独立明确决定；不要覆盖历史结果或重新使用历史执行记录。

## 公开证据投影，不是运行许可重放

授权记录、使用记录、审批文件、私有执行备注/协调内容均已排除。恢复协议仅把涉及私有操作协调的原因文字改为中性公开说明，数学方案、预算、原始数据与失败观测不改。PUBLIC_PROJECTION.json记录投影来源与原始hash；PUBLIC_MANIFEST.json是本交付所有文件的新公开内容清单。

保留的历史final_freeze.json可能引用被排除文件或投影前的恢复协议hash，因此它只能证明历史身份，不能直接验证本公开子集为完整原工作区，更不能授权重新执行。请用公开manifest复核此次分发；不要通过删除校验、重写旧hash或降低安全门槛使旧启动器“凑跑”。源码中的执行保护为研究实现的一部分，不包含任何真实审批记录。
