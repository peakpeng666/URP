"""Read-only public evidence verification. Standard library only; no solver/model."""
import argparse,hashlib,json,pathlib,zipfile
from fractions import Fraction
ROOT=pathlib.Path(__file__).resolve().parent
BASE=ROOT/'URP/experiments/online_bin_packing'

def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def read(path):return json.loads(path.read_text())
def check_one(obs_path):
 obs=read(obs_path);request=read(obs_path.with_name('request.json'));items=request['items'];capacity=request['capacity'];assert request['mode']=='pack' and capacity==100 and len(items)==256
 assert obs['returncode']==0 and obs['termination'] is None and obs['error'] is None and obs['reaped'] and obs['cpu_evidence_complete']
 body=obs['result'];assert body['phase']=='pack' and body['status']=='packing_returned' and body['error'] is None and body['warnings']['complete']
 assert body['program_sha256']==hashlib.sha256(request['program_json'].encode()).hexdigest()
 result=body['result'];assignment=result['assignment'];assert len(assignment)==len(items)
 loads=[0]*len(items)
 for value,bin_id in zip(items,assignment):
  assert type(value)is int and 1<=value<=capacity and type(bin_id)is int and 0<=bin_id<len(items)
  loads[bin_id]+=value;assert loads[bin_id]<=capacity
 used=sum(v>0 for v in loads);assert used==result['used_bins'] and result['residuals']==[capacity-v for v in loads]
 return used,(sum(items)+capacity-1)//capacity,assignment

def main():
 p=argparse.ArgumentParser();p.add_argument('--main-zip',required=True,type=pathlib.Path);a=p.parse_args()
 manifest=read(ROOT/'PUBLIC_MANIFEST.json')
 for row in manifest['files']:
  path=ROOT/row['path'];assert path.is_file() and path.stat().st_size==row['bytes'] and digest(path)==row['sha256'],row['path']
 dep=read(ROOT/'REUSED_DEPENDENCIES.json');assert digest(a.main_zip)==dep['main_archive_sha256'],'wrong main archive'
 with zipfile.ZipFile(a.main_zip) as z:
  for row in dep['main_files_verified']:
   data=z.read(row['path']);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],row['path']
 old=BASE/'typed_tree_packing_check_v1';new=BASE/'typed_tree_feedback_packing_v1';run=new/'runs/feedback_pilot_20261005_02';oldreport=read(old/'run/report.json');newreport=read(run/'report.json');results={};count=0
 for label,directory,report in [('old',old/'run',oldreport),('new',run/'scores',newreport)]:
  for group in report['groups']:
   name=group['method'];bins=[];lower=[]
   for i in range(5):
    b,l,trajectory=check_one(directory/f'{name}_{i}'/'observation.json');bins.append(b);lower.append(l);results[label,name,i]=trajectory;count+=1
   fit=sum((Fraction(l,b) for l,b in zip(lower,bins)),Fraction())/5
   assert bins==group['bins'] and sum(bins)==group['sum_bins'] and str(fit)==group['exact_fitness']
 assert count==60
 pairs=[];g={x['method']:x for x in newreport['groups']}
 for i in range(2):
  diff=g[f'feedback_s{i}']['sum_bins']-g[f'control_s{i}']['sum_bins'];assert diff==newreport['pairs'][i]['feedback_minus_control_sum_bins'];pairs.append(diff)
 assert pairs==[-731,0]
 assert all(results['new','feedback_s0',i]==results['new','FF',i] for i in range(5))
 assert all(results['old','design_2',i]==results['old','BF',i] for i in range(5))
 assert all(results['old','fixed_transcription',i]!=results['old','BF',i] for i in range(5))
 first=read(new/'runs/feedback_pilot_20261005_01/report.json');assert first['formal_posts_observed']==0 and first['score_dispatches']==0 and first['state']=='incomplete'
 assert newreport['formal_posts_observed']==4 and newreport['score_dispatches']==30 and newreport['unknown_launch_states']==0 and not newreport['errors']
 posts=0
 for slot in newreport['requests']:
  d=run/'generation'/slot['id'];execution=read(d/'result.json');decoded=read(d/'decoded.json');content=(d/'content.txt').read_bytes();response=read(d/'response_body.json')
  assert execution['post_requests_sent']==1 and execution['cleanup']['direct_child_reaped'] and execution['process_status']=='completed'
  assert decoded['status']=='completed_valid_transport' and decoded['metadata']['stop_type']=='eos';assert response['content'].encode()==content and hashlib.sha256(content).hexdigest()==decoded['metadata']['content_sha256'];posts+=1
 print(json.dumps({'public_files_verified':len(manifest['files']),'main_dependency_files_verified':len(dep['main_files_verified']),'saved_score_observations_verified':count,'saved_placements_verified':count*256,'saved_generation_posts_verified':posts,'first_attempt_posts':0,'paired_bin_differences':pairs,'new_model_calls':0,'new_solver_calls':0,'note':'Saved evidence only; no independent floating-score replay or generalization claim.'},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
