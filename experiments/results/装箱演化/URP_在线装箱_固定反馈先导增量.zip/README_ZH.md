# 在线装箱固定反馈先导：增量交付

先读RESULTS_ZH.md看结论，再按REPRODUCE_ZH.md做只读复核。

包含三个新增研究目录：
1. typed_tree_packing_check_v1：旧4输出+FF/BF的30次任务评分、独立可行性/轨迹复核
2. typed_tree_feedback_packing_v1：冻结源/提示/请求、首轮0调用内存失败、恢复后的4次完整生成与30评分原始观测
3. typed_tree_feedback_recovery_v1：公开恢复方案、合并计量、独立结果复核

本包需要SHA256为ae189573bbd6495524a37ba3fd686538755b0d2f81f4e45a51167c9a677edab6的现有主包。模型和环境外置。没有改动主包、前端或历史冻结。公开交付是证据投影，不是原运行授权重放。

另附URP/README.md与URP/docs/research_status.md，统一当前研究状态。将本增量与指定主包解压到同一新目录时，仅这两份说明取增量版本；历史冻结源码和原始结果不变。GitHub主工程尚未发布。
