#!/usr/bin/env python3
"""Offline read-only safe60 facts arithmetic; does not load source/AST text."""
from pathlib import Path
from fractions import Fraction
import json,hashlib,collections
R=Path(__file__).resolve().parent/'safe_facts'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
m=load(R/'FILE_MANIFEST.json')
for name,x in m['files'].items():assert (R/name).stat().st_size==x['bytes'] and sha(R/name)==x['sha256']
a=load(R/'AGGREGATE.json');rows=load(R/'PER_SLOT_SAFE_RESULTS.json');generation=load(R/'GENERATION_SAFE_COST_TABLE.json');assert len(rows)==len(generation)==60
for arm,x in a['arms'].items():
 group=[r for r in rows if r['arm']==arm];assert len(group)==30;counts=dict(collections.Counter(r['evaluation_status'] for r in group));assert counts==x['evaluation_counts']
 valid=[r for r in group if r['fitness_exact']];assert len(valid)==x['complete_fitness_coverage']['numerator'];assert x['complete_fitness_coverage']['denominator']==30
 fs=[Fraction(r['fitness_exact']['numerator'],r['fitness_exact']['denominator']) for r in valid];mean=sum(fs,Fraction())/len(fs)
 v=x['conditional_complete_only_mean'];assert v['denominator_candidates']==len(fs) and v['NOT_full_arm_mean'] is True
 assert Fraction(v['value']['numerator'],v['value']['denominator'])==mean
 best=max(fs);assert Fraction(x['best_complete_only_fitness']['numerator'],x['best_complete_only_fitness']['denominator'])==best
 assert x['best_complete_only_slot_ids']==[r['slot_id'] for r in valid if Fraction(r['fitness_exact']['numerator'],r['fitness_exact']['denominator'])==best]
 for r in valid:
  assert len(r['cases'])==5 and all(c['outcome']=='ok' and c['checker_status']=='passed' for c in r['cases']);f=sum((Fraction(c['L1'],c['used_bins']) for c in r['cases']),Fraction())/5;assert f==Fraction(r['fitness_exact']['numerator'],r['fitness_exact']['denominator'])
 assert all(r['fitness_exact'] is None for r in group if r['evaluation_status']!='scored')
 for field,s in x['CLI_reported_token_accounting'].items():
  vals=[g['CLI_reported_tokens'][field] for g in generation if g['arm']==arm];known=[v for v in vals if type(v) is int];assert s['known_sum']==sum(known) and s['unknown_slots']==30-len(known)
closure=a['claim_closure'];assert closure['slot_claim_count']==closure['slot_terminal_count']==60 and closure['unknown_slot_claims']==closure['unknown_runtime_claims']==0 and closure['runtime_claim_count']==closure['runtime_terminal_count'];assert closure['execution_switch_enabled'] is False
print(json.dumps({'status':'PASS_safe60_exact_fitness_conditional_means_denominators_tokens_closure','rows':60,'candidate_executions':0,'heldout_reads':0,'conditional_means_are_not_arm_winners':True}))
