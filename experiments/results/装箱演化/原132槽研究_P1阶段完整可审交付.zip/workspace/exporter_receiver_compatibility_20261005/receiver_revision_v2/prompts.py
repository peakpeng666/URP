"""Finite parent projection and worst-case bounds. No data paths are accepted."""
from copy import deepcopy
from bridge import MAX_DESCRIPTION, MAX_SOURCE, canonical, is_hash, require, sha

MAX_BASE_PROMPT_BYTES = 65536
MAX_PROMPT_BYTES = 1048576
MAX_PARENT_ID_BYTES = 128
ARGV_PROMPT_BYTES = 65536
PARENT_LABEL = '\n\nOrdered public parent draws (duplicates deliberately preserved):\n'
PUBLIC_RESPONSE_RULE = ('Return one public {description} of at most 2048 UTF-8 bytes and one complete '
    'Python code block of at most 16384 UTF-8 source bytes. Source is retained exactly. '
    'Surrounding prose is counted as non-strict format; no source or parent is truncated or repaired.')


class PromptBoundFailure(ValueError):
    """Infrastructure preflight failure before slot claim, never algorithm failure."""


def check_delivery(prompt_text, delivery):
    require(type(prompt_text) is str and type(delivery) is dict, 'delivery_type')
    size = len(prompt_text.encode('utf-8'))
    method = delivery.get('method')
    if method == 'argv':
        limit = ARGV_PROMPT_BYTES
    elif method in ('stdin', 'file'):
        require(delivery.get('verified_support') is True and is_hash(delivery.get('support_evidence_sha256')),
                'stdin_file_support_must_be_verified')
        limit = delivery.get('max_payload_bytes')
        require(type(limit) is int and 0 < limit <= MAX_PROMPT_BYTES, 'verified_delivery_limit')
    else:
        raise PromptBoundFailure('prompt_bound_failure:unverified_cli_delivery')
    if size > limit:
        raise PromptBoundFailure('prompt_bound_failure:actual_cli_payload_exceeds_' + method + '_limit')
    return {'method': method, 'actual_cli_payload_bytes': size, 'payload_limit_bytes': limit,
            'support_evidence_sha256': delivery.get('support_evidence_sha256'),
            'prompt_sha256': sha(prompt_text.encode('utf-8'))}


def build_prompt(base_messages, parents, *, delivery):
    require(type(base_messages) is list and len(base_messages) == 2 and type(parents) is list and len(parents) <= 5,
            'prompt_shape')
    for message in base_messages:
        require(type(message) is dict and set(message) == {'role', 'content'} and
                message['role'] in ('system', 'user') and type(message['content']) is str, 'prompt_message')
    require([message['role'] for message in base_messages] == ['system', 'user'], 'frozen_system_user_delivery_mapping')
    base = deepcopy(base_messages)
    base[-1]['content'] += '\n\n' + PUBLIC_RESPONSE_RULE
    base_size = len(canonical(base).encode('utf-8'))
    if base_size > MAX_BASE_PROMPT_BYTES:
        raise PromptBoundFailure('prompt_bound_failure:base_prompt_byte_bound')
    # Each UTF-8 input byte can expand to at most six JSON bytes. Include bounded
    # IDs, hash text, parent-object labels, separators and message-string escaping.
    # Parent JSON is then embedded in the message JSON string. Worst input-byte
    # expansion across both layers is seven (control -> \uXXXX -> \\uXXXX).
    # Quotes/backslashes expand by at most four; non-ASCII UTF-8 stays unescaped.
    worst_parent_json = 5*(7*(MAX_SOURCE + MAX_DESCRIPTION + MAX_PARENT_ID_BYTES + 64) + 2048)
    worst_prompt = base_size + worst_parent_json + 2*len(PARENT_LABEL.encode()) + 1024
    if worst_prompt > MAX_PROMPT_BYTES:
        raise PromptBoundFailure('prompt_bound_failure:worst_case_five_parent_artifact')
    projected = []
    for parent in parents:
        require(type(parent) is dict, 'parent_type')
        pid, description, code = parent.get('id'), parent.get('description'), parent.get('code')
        require(type(pid) is str and 0 < len(pid.encode()) <= MAX_PARENT_ID_BYTES, 'parent_id_bound')
        if type(description) is not str or not 0 < len(description.encode()) <= MAX_DESCRIPTION:
            raise PromptBoundFailure('prompt_bound_failure:parent_description_bound')
        if type(code) is not str or not 0 < len(code.encode()) <= MAX_SOURCE:
            raise PromptBoundFailure('prompt_bound_failure:parent_source_bound')
        pair = sha(canonical({'description': description, 'code': code}).encode())
        require(parent.get('pair_sha256') == pair, 'parent_pair_identity')
        projected.append({'id': pid, 'description': description, 'code': code, 'pair_sha256': pair})
    if projected:
        base[-1]['content'] += PARENT_LABEL + canonical(projected)
    actual = len(canonical(base).encode('utf-8'))
    if actual > MAX_PROMPT_BYTES:
        raise PromptBoundFailure('prompt_bound_failure:actual_serialized_artifact')
    # Actual user payload is separate from the serialized two-message artifact.
    # Exporter must put the exact system prompt in its separately hashed config.
    delivery_result = check_delivery(base[-1]['content'], delivery)
    return {'messages': base, 'prompt_bytes': actual, 'worst_case_five_parent_bytes': worst_prompt,
            'prompt_sha256': sha(canonical(base).encode()), 'parent_count': len(projected),
            'cli_user_prompt': base[-1]['content'], 'delivery': delivery_result,
            'required_system_prompt_sha256': sha(base[0]['content'].encode())}
