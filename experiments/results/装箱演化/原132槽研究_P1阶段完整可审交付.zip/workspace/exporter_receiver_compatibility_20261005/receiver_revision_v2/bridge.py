"""Source-only receipts bridge; no imports of backend/runtime/candidate modules.

Default API verifies existing data only. The optional callback wrapper requires
an explicit externally pinned deployment and separately granted execution.
No deployment is created here. No host AST parser exists here.
"""
from copy import deepcopy
import hashlib
import json
import math
import re

MODES = {'handwritten_registry_test': 'handwritten_fixture',
         'registered_source_study': 'model_response'}
MAX_RAW = 262144
MAX_SOURCE = 16384
MAX_DESCRIPTION = 2048
MAX_AST = 262144
MAX_RECEIPT = 1048576
BINDING_KEYS = {'batch_id', 'wave_id', 'slot_id', 'raw_response_sha256',
                'source_sha256', 'policy_sha256', 'runtime_freeze_sha256',
                'claim_sha256', 'claim_id', 'registry_sha256'}
EVENTS = ('divide', 'overflow', 'invalid', 'underflow', 'python_runtimewarning')
LIMITS = {'cpu_seconds': [1, 1], 'address_space_bytes': [536870912, 536870912],
          'open_files': [3, 3], 'file_size_bytes': [0, 0], 'core_bytes': [0, 0]}
TIMING_SCOPE = 'function call including facade; excludes prep/check/serialization'


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def digest(value):
    return sha(canonical(value).encode('utf-8'))


def is_hash(value):
    return type(value) is str and re.fullmatch('[0-9a-f]{64}', value) is not None


def bound(value, cap=MAX_RECEIPT):
    stack, seen, size, nodes = [(value, 0)], set(), 0, 0
    while stack:
        item, depth = stack.pop()
        if depth == -1:
            seen.remove(id(item)); continue
        nodes += 1
        require(depth <= 16 and nodes <= 50000, 'receipt_structure_bound')
        kind = type(item)
        if kind in (dict, list):
            require(id(item) not in seen and len(item) <= 50000, 'receipt_cycle_or_container_bound')
            seen.add(id(item)); size += 2 + 2*len(item)
            stack.append((item, -1))
            if kind is dict:
                require(all(type(key) is str for key in item), 'receipt_key_type')
                stack.extend((part, depth+1) for pair in item.items() for part in pair)
            else:
                stack.extend((part, depth+1) for part in item)
        elif kind is str:
            require(len(item) <= cap, 'receipt_string_bound')
            size += len(canonical(item).encode('utf-8'))
        elif kind is int:
            require(item.bit_length() <= 128, 'receipt_integer_bound')
            size += len(str(item))
        elif kind is float:
            require(math.isfinite(item), 'receipt_nonfinite'); size += 32
        else:
            require(item is None or kind is bool, 'receipt_value_type'); size += 5
        require(size <= cap, 'receipt_byte_bound')


def verify_seal(value):
    bound(value)
    require(type(value) is dict, 'sealed_type')
    obj = dict(value); checksum = obj.pop('sha256', None)
    require(is_hash(checksum) and digest(obj) == checksum, 'sealed_hash')
    return obj


def extract(capture):
    """Unique extraction, with separately reported strict-format metric.

    Upstream must authenticate the receiver artifact and validate terminal/config
    provenance. This layer checks the literal raw bytes and response format again.
    """
    require(type(capture) is dict and type(capture.get('raw')) is str, 'capture_type')
    raw = capture['raw']
    require(len(raw) <= MAX_RAW, 'raw_character_bound')
    encoded = raw.encode('utf-8', errors='strict')
    require(0 < len(encoded) <= MAX_RAW, 'raw_byte_bound')
    require(capture.get('status') == 'ok' and capture.get('capture_complete') is True,
            'nonterminal_or_failed_capture')
    require(capture.get('finish_reason') in ('stop', 'length') and
            type(capture.get('tool_calls')) is list and not capture['tool_calls'], 'finish_or_tool_call')
    require(raw.count('```') == 2, 'unique_code_block')
    blocks = list(re.finditer(r'```python\r?\n(.*?)```', raw, re.DOTALL))
    require(len(blocks) == 1, 'unique_complete_python_block')
    block = blocks[0]
    outside = raw[:block.start()] + raw[block.end():]
    descriptions = list(re.finditer(r'\{([^{}]+)\}', outside))
    require(len(descriptions) == 1 and outside.count('{') == outside.count('}') == 1,
            'unique_public_description')
    description, code = descriptions[0].group(1).strip(), block.group(1)
    require(0 < len(description.encode('utf-8')) <= MAX_DESCRIPTION, 'public_description_byte_bound')
    require(code.endswith('\n') and 0 < len(code.encode('utf-8')) <= MAX_SOURCE, 'exact_source_bound')
    candidate = {'description': description, 'code': code,
            'description_sha256': sha(description.encode('utf-8')),
            'code_sha256': sha(code.encode('utf-8')),
            'pair_sha256': digest({'description': description, 'code': code}),
            'description_consistency': 'undetermined'}
    strict = re.fullmatch(r'\s*\{[^{}]+\}\s*```python\r?\n.*?```\s*', raw, re.DOTALL) is not None
    return candidate, sha(encoded), {'unique': True, 'strict': strict}


class ReceiptBridge:
    """Explicit registry/policy/runtime trust roots, supplied without data reads.

    Constructor arguments are trusted reviewed artifacts, not fields copied from
    the received bundle. No path, raw instance provider or source executor exists.
    """
    def __init__(self, registry_document, *, registry_sha256, run_id, phase, wave_id,
                 policy, policy_sha256, runtime_freeze_sha256, manifest_sha256,
                 api_names, expected_security, expected_limits, handwritten_source_hashes,
                 deployment_document, deployment_sha256):
        registry = verify_seal(registry_document)
        require(registry_document['sha256'] == registry_sha256, 'trusted_registry_hash')
        profiled = 'resource_profile_sha256' in registry
        registry_fields = {'schema', 'batch_id', 'wave_id', 'phase', 'policy_sha256',
                           'runtime_freeze_sha256', 'source_origin', 'slots'}
        if profiled: registry_fields.add('resource_profile_sha256')
        require(set(registry) == registry_fields, 'registry_fields')
        require(registry['schema'] == 'frozen-candidate-wave-registry-v1', 'registry_schema')
        require(type(phase) is int and phase in (0, 1, 2), 'phase_type')
        require(registry['batch_id'] == run_id and registry['phase'] == phase and
                registry['wave_id'] == wave_id, 'explicit_batch_wave_mapping')
        require(all(is_hash(v) for v in (registry_sha256, policy_sha256, runtime_freeze_sha256, manifest_sha256)),
                'trusted_hash_format')
        bound(policy)
        require(digest(policy) == policy_sha256 == registry['policy_sha256'], 'policy_identity')
        require(registry['runtime_freeze_sha256'] == runtime_freeze_sha256, 'runtime_identity')
        require(policy.get('schema') == 'bounded-arithmetic-finite-final-v1' and
                policy.get('events') == list(EVENTS) and
                policy.get('per_placement_callback_limit') == 64 and
                policy.get('per_instance_callback_limit') == 320000 and
                policy.get('intermediate_nonfinite') == 'allowed_program_managed' and
                policy.get('repairs') is False and policy.get('applies_to') == 'both experimental arms identically',
                'arithmetic_policy_scope')
        require(type(expected_security) is dict and set(expected_security) ==
                {'Threads', 'NoNewPrivs', 'Seccomp', 'Seccomp_filters'} and
                expected_security['Threads'] == 1 and expected_security['NoNewPrivs'] == 1 and
                expected_security['Seccomp'] == 2 and type(expected_security['Seccomp_filters']) is int and
                expected_security['Seccomp_filters'] >= 1, 'explicit_security_profile')
        require(expected_limits == LIMITS, 'legacy_or_admission_observed_limits')
        require(type(api_names) is list and len(api_names) == 46 and len(set(api_names)) == 46 and
                all(type(name) is str for name in api_names), 'explicit_46_api_names')
        deployment = verify_seal(deployment_document)
        require(deployment_document['sha256'] == deployment_sha256, 'externally_pinned_deployment')
        deployment_fields = {'schema', 'mode', 'source_origin', 'registry_sha256', 'wave_freeze_sha256',
                'batch_id', 'wave_id', 'phase', 'runtime_freeze_sha256', 'policy_sha256', 'isolation_profile_sha256',
                'checker_sha256', 'intake_manifest_sha256'}
        if profiled:
            deployment_fields.add('resource_profile_sha256')
        else:
            deployment_fields.update(('worker_cpu_seconds', 'worker_as_bytes', 'max_source_bytes', 'max_steps', 'max_instances'))
        require(set(deployment) == deployment_fields, 'deployment_fields')
        require(deployment['schema'] == ('candidate-deployment-freeze-v2' if profiled else 'candidate-deployment-freeze-v1') and deployment['mode'] in MODES and
                deployment['source_origin'] == MODES[deployment['mode']], 'deployment_mode_provenance')
        for key in ('batch_id', 'wave_id', 'phase', 'runtime_freeze_sha256', 'policy_sha256', 'source_origin'):
            require(deployment[key] == registry[key], 'deployment_registry:' + key)
        require(deployment['registry_sha256'] == registry_sha256, 'deployment_registry_identity')
        self.profile = None
        if profiled:
            from profiles import resolve, PRODUCTION
            require(deployment['resource_profile_sha256'] == registry['resource_profile_sha256'], 'deployment_resource_profile')
            self.profile = resolve(registry['resource_profile_sha256'])
            if deployment['mode'] == 'registered_source_study':
                require(self.profile['profile_id'] == PRODUCTION, 'study_requires_production_profile')
        else:
            require(deployment['mode'] == 'handwritten_registry_test', 'legacy1CPU_not_a_study_profile')
            for key, expected in {'worker_cpu_seconds': 1, 'worker_as_bytes': 536870912, 'max_source_bytes': 16384,
                                  'max_steps': 5000, 'max_instances': 5}.items():
                require(type(deployment[key]) is int and deployment[key] == expected, 'deployment_limit:' + key)
        require(all(is_hash(deployment[key]) for key in ('registry_sha256', 'wave_freeze_sha256', 'runtime_freeze_sha256',
                'policy_sha256', 'isolation_profile_sha256', 'checker_sha256', 'intake_manifest_sha256')), 'deployment_hashes')
        require(type(handwritten_source_hashes) is list and
                all(is_hash(value) for value in handwritten_source_hashes), 'handwritten_allowlist_required')
        require(type(registry['slots']) is list and 0 < len(registry['slots']) <= 128, 'registry_slots')
        entries = {}
        for entry in registry['slots']:
            require(type(entry) is dict and set(entry) == {'slot_id', 'claim_id', 'claim_sha256',
                'raw_response_sha256', 'source_sha256', 'description_sha256', 'pair_sha256'}, 'registry_entry_fields')
            require(entry['slot_id'] not in entries, 'duplicate_registry_slot')
            require(all(is_hash(value) for key, value in entry.items() if key != 'slot_id'), 'registry_entry_hash')
            if deployment['source_origin'] == 'handwritten_fixture':
                require(entry['source_sha256'] in handwritten_source_hashes, 'handwritten_source_not_registered')
            entries[entry['slot_id']] = deepcopy(entry)
        require(len({entry['claim_id'] for entry in entries.values()}) == len(entries), 'duplicate_registry_claim')
        self.registry = deepcopy(registry_document); self.entries = entries
        self.policy = deepcopy(policy); self.manifest_sha256 = manifest_sha256
        self.api_names = set(api_names); self.security = deepcopy(expected_security)
        self.limits = deepcopy(expected_limits); self.used_claims = set()
        self.deployment = deepcopy(deployment_document); self.mode = deployment['mode']

    def expected_binding(self, capture, claim, freeze):
        verify_seal(claim); verify_seal(freeze)
        require(claim.get('schema') == 'wave-external-claim-v1', 'claim_schema')
        require(claim.get('run_id') == self.registry['batch_id'] and
                type(claim.get('phase')) is int and claim['phase'] == self.registry['phase'], 'claim_wave_mapping')
        require(claim.get('claim_id') == digest(['wave-claim-v1', claim['run_id'], claim['slot_id']]), 'claim_id')
        require(is_hash(claim.get('request_sha256')) and claim.get('freeze_sha256') == freeze['sha256'], 'claim_freeze')
        require(freeze['sha256'] == self.deployment['wave_freeze_sha256'], 'deployment_wave_freeze')
        if self.mode == 'registered_source_study':
            require(freeze.get('mode') == 'official_cli' and
                    freeze.get('evaluation_mode') == 'registered_source_study' and
                    self.deployment['source_origin'] == 'model_response', 'explicit_capture_evaluation_modes')
        else:
            require(freeze.get('mode') == 'handwritten_registry_test' and
                    freeze.get('evaluation_mode', 'handwritten_registry_test') == 'handwritten_registry_test' and
                    self.deployment['source_origin'] == 'handwritten_fixture', 'handwritten_mode_provenance')
        require(freeze.get('policy_sha256') == self.registry['policy_sha256'] and
                freeze.get('runtime_sha256') == self.registry['runtime_freeze_sha256'], 'freeze_policy_runtime')
        require(all(is_hash(freeze.get(key)) for key in ('intake_manifest_sha256', 'isolation_profile_sha256', 'checker_sha256')),
                'freeze_evidence_hashes')
        for key in ('policy_sha256', 'isolation_profile_sha256', 'checker_sha256', 'intake_manifest_sha256'):
            require(freeze[key] == self.deployment[key], 'deployment_wave:' + key)
        if self.profile is not None:
            require(freeze.get('resource_profile_sha256') == self.registry['resource_profile_sha256'], 'wave_resource_profile')
        candidate, raw_sha, format_metrics = extract(capture)
        entry = self.entries.get(claim['slot_id']); require(entry is not None, 'unregistered_slot')
        expected = {'slot_id': claim['slot_id'], 'claim_id': claim['claim_id'], 'claim_sha256': claim['sha256'],
                    'raw_response_sha256': raw_sha, 'source_sha256': candidate['code_sha256'],
                    'description_sha256': candidate['description_sha256'], 'pair_sha256': candidate['pair_sha256']}
        require(entry == expected, 'actual_capture_candidate_registry_binding')
        binding = {key: self.registry[key] for key in ('batch_id', 'wave_id', 'policy_sha256', 'runtime_freeze_sha256')}
        binding.update({key: entry[key] for key in ('slot_id', 'claim_id', 'claim_sha256', 'raw_response_sha256', 'source_sha256')})
        binding['registry_sha256'] = self.registry['sha256']
        if self.profile is not None:
            binding['resource_profile_sha256'] = self.registry['resource_profile_sha256']
        return candidate, binding, format_metrics

    @staticmethod
    def _binding(actual, expected):
        keys = BINDING_KEYS | ({'resource_profile_sha256'} if 'resource_profile_sha256' in expected else set())
        require(type(actual) is dict and set(actual) == keys and actual == expected, 'exact_registry_binding')

    @staticmethod
    def _counts(counts, maximum):
        require(type(counts) is dict and set(counts) == set(EVENTS), 'arithmetic_event_categories')
        require(all(type(value) is int and 0 <= value <= maximum for value in counts.values()) and
                sum(counts.values()) <= maximum, 'arithmetic_event_budget')

    def _worker(self, worker, binding, *, canonical_sha256, admitted, expected_admission, role, steps=None,
                numerical=False, cap_failure=None, instance_index=None, execution_id=None):
        require(type(worker) is dict, 'worker_evidence_required')
        self._binding(worker.get('registry_binding'), binding)
        require(worker.get('source_id') == binding['slot_id'] and worker.get('source_sha256') == binding['source_sha256'], 'worker_source')
        require(worker.get('source_sent') is True and worker.get('source_after_host_gate') is True, 'source_before_host_gate')
        require(worker.get('dependency_freeze_sha256') == binding['runtime_freeze_sha256'], 'worker_dependency_freeze')
        expected_limits = deepcopy(self.limits)
        cpu_limit = 1
        if self.profile is not None:
            from profiles import configured
            role_limits = self.profile['roles'][role]; cpu_limit = role_limits['cpu_seconds']
            expected_limits['cpu_seconds'] = [cpu_limit, cpu_limit]
            require(worker.get('resource_profile_sha256') == binding['resource_profile_sha256'] and
                    worker.get('resource_profile_id') == self.profile['profile_id'] and worker.get('worker_role') == role and
                    worker.get('configured_limits') == configured(self.profile, role), 'worker_role_profile_limits')
            if role == 'instance':
                require(worker.get('execution_id') == execution_id and worker.get('instance_index') == instance_index,
                        'worker_execution_instance_binding')
            else:
                require(worker.get('execution_id') == binding['claim_id']+'/admission' and worker.get('instance_index') is None,
                        'admission_execution_binding')
            require(worker.get('assignment_complete') is (role == 'instance' and not numerical and not cap_failure), 'assignment_completion')
            for key in ('instance_started', 'absolute_deadline', 'total_wall_deadline', 'instance_wall_seconds'):
                require(type(worker.get(key)) in (int, float) and math.isfinite(worker[key]) and worker[key] >= 0,
                        'worker_deadline_field:' + key)
            total_span = worker['total_wall_deadline'] - worker['instance_started']
            require(abs(total_span - role_limits['wall_seconds']) < 1e-6 and
                    abs(worker['total_wall_deadline'] - worker['absolute_deadline'] - self.profile['cleanup_wall_seconds']) < 1e-6,
                    'shared_wall_cleanup_reservation')
            require(worker['instance_wall_seconds'] <= role_limits['wall_seconds'], 'observed_instance_wall_budget')
        require(worker.get('security') == self.security and worker.get('host_observed_limits') == expected_limits, 'worker_security_resources')
        require(type(worker.get('pid')) is int and worker['pid'] > 1, 'worker_pid')
        pipes = worker.get('private_pipes')
        require(type(pipes) is list and len(pipes) == 3 and len(set(pipes)) == 3 and
                all(type(value) is str and re.fullmatch(r'pipe:\[\d+\]', value) for value in pipes), 'private_pipes')
        require(is_hash(worker.get('mapped_dependencies_sha256')), 'mapped_dependencies_receipt')
        require(worker.get('reaped') is True and type(worker.get('returncode')) is int and
                worker['returncode'] == (-9 if cap_failure else 0) and
                worker.get('cleanup_error') is None, 'worker_cleanup')
        require(type(worker.get('steps')) is int and 0 <= worker['steps'] <= 5000, 'worker_steps')
        if steps is not None:
            require(worker['steps'] == steps, 'worker_instance_steps')
        require(type(worker.get('score_call_cpu_ns')) is int and 0 <= worker['score_call_cpu_ns'] <= cpu_limit*1000000000 and
                worker.get('score_timing_scope') == TIMING_SCOPE, 'score_call_cpu_scope')
        for key in ('wall_seconds', 'startup_seconds', 'cleanup_seconds', 'cpu_seconds'):
            value = worker.get(key)
            require(type(value) in (int, float) and math.isfinite(value) and value >= 0, 'worker_time:' + key)
        require(worker['score_call_cpu_ns'] <= int(worker['cpu_seconds']*1000000000)+1000,
                'score_call_cpu_within_observed_child_cpu')
        require(type(worker.get('peak_rss_kib')) is int and worker['peak_rss_kib'] >= 0, 'worker_rss')
        for key in ('input_bytes', 'output_bytes', 'write_calls', 'read_calls', 'short_writes', 'stderr_bytes'):
            require(type(worker.get(key)) is int and worker[key] >= 0, 'worker_counter:' + key)
        require(worker['stderr_bytes'] == 0 and worker['input_bytes'] <= 160*1024**2 and
                worker['output_bytes'] <= 600*1024**2, 'worker_io_bounds')
        require(is_hash(worker.get('input_sha256')) and is_hash(worker.get('output_sha256')), 'worker_transcript_hashes')
        inner = worker.get('admission')
        admission_cap = bool(cap_failure and inner is None)
        if admission_cap:
            # A post-gate cap may terminate parsing before the child can emit an
            # admission frame. Do not fabricate canonical AST/admission evidence.
            require(worker['steps'] == 0 and (admitted is False if role == 'admission' else
                    admitted is True and expected_admission.get('admitted') is True), 'admission_cap_no_fabricated_child_frame')
        else:
            require(type(inner) is dict and inner.get('admitted') is admitted and
                    inner.get('binding_sha256') == digest(binding), 'worker_child_admission_binding')
            require(type(inner.get('open_denials')) is int and 0 <= inner['open_denials'] <= 1024, 'worker_open_denials')
        if admitted and not admission_cap:
            fields = {'admitted', 'source_sha256', 'manifest_sha256', 'node_count', 'ast_depth', 'apis',
                      'canonical_text_sha256', 'binding_sha256', 'open_denials'}
            if self.profile is not None: fields.update(('resource_profile_sha256', 'worker_role'))
            require(set(inner) == fields, 'inner_admission_fields')
            require(inner.get('canonical_text_sha256') == canonical_sha256 and
                    inner.get('source_sha256') == binding['source_sha256'] and
                    inner.get('manifest_sha256') == self.manifest_sha256, 'worker_canonical_identity')
            require(type(inner.get('node_count')) is int and 1 <= inner['node_count'] <= 4096 and
                    type(inner.get('ast_depth')) is int and 1 <= inner['ast_depth'] <= 64, 'inner_admission_bounds')
            inner_apis = inner.get('apis')
            require(type(inner_apis) is list and len(inner_apis) <= 46 and
                    all(type(name) is str and name in self.api_names for name in inner_apis) and
                    len(set(inner_apis)) == len(inner_apis), 'inner_admission_apis')
        elif not admission_cap:
            fields = {'admitted', 'kind', 'binding_sha256', 'open_denials'}
            if self.profile is not None: fields.update(('resource_profile_sha256', 'worker_role'))
            require(set(inner) == fields and
                    inner['kind'] in ('source_protocol', 'static', 'compile'), 'inner_rejection_fields')
        if self.profile is not None and not admission_cap:
            require(inner.get('resource_profile_sha256') == binding['resource_profile_sha256'] and
                    inner.get('worker_role') == role, 'child_admission_role_profile')
        for key, value in (inner or {}).items():
            if key not in ('canonical_text_sha256', 'worker_role'):
                require(expected_admission.get(key) == value, 'inner_outer_admission:' + key)
        self._counts(worker.get('arithmetic_events'), 320001 if numerical else 320000)
        require(type(worker.get('max_placement_event_count')) is int and
                0 <= worker['max_placement_event_count'] <= (65 if numerical else 64), 'max_placement_event_count')
        require(type(worker.get('arithmetic_steps_checked')) is int and
                worker['arithmetic_steps_checked'] == worker['steps'] + int(numerical), 'arithmetic_steps_checked')
        require(sum(worker['arithmetic_events'].values()) <= 64*worker['steps'] + (65 if numerical else 0), 'events_per_checked_step')
        if worker['steps'] == 0 and not numerical:
            require(worker['score_call_cpu_ns'] == 0 and worker['max_placement_event_count'] == 0, 'admission_no_score_calls')
        failure = worker.get('numerical_failure')
        if numerical:
            fields = {'v', 'step', 'failure', 'arithmetic_events', 'binding_sha256', 'exception_kind', 'score_call_cpu_ns'}
            if self.profile is not None: fields.update(('resource_profile_sha256', 'worker_role'))
            require(type(failure) is dict and set(failure) == fields, 'numeric_failure_fields')
            if self.profile is not None:
                require(failure.get('resource_profile_sha256') == binding['resource_profile_sha256'] and
                        failure.get('worker_role') == role, 'numeric_failure_role_profile')
            require(type(failure.get('v')) is int and failure['v'] == 3 and failure.get('failure') == 'numerical_policy' and
                    failure.get('binding_sha256') == digest(binding) and type(failure.get('step')) is int and
                    failure['step'] == worker['steps'], 'numeric_failure_binding')
            require(failure.get('exception_kind') in ('ArithmeticBudgetExceeded', 'ArithmeticError', 'FloatingPointError',
                    'OverflowError', 'ZeroDivisionError', 'ValueError', 'TypeError', 'IndexError', 'NumericContractError'),
                    'numeric_failure_exception_kind')
            events = failure.get('arithmetic_events')
            require(type(events) is dict and set(events) == {'placement', 'instance', 'budget_exceeded'} and
                    type(events['budget_exceeded']) is bool, 'failure_event_fields')
            self._counts(events['placement'], 65); self._counts(events['instance'], 320001)
            require(events['instance'] == worker['arithmetic_events'] and
                    all(events['placement'][key] <= events['instance'][key] for key in EVENTS), 'failure_event_totals')
            exceeded = sum(events['placement'].values()) > 64 or sum(events['instance'].values()) > 320000
            require(events['budget_exceeded'] == exceeded, 'failure_budget_flag')
            require((failure['exception_kind'] == 'ArithmeticBudgetExceeded') == events['budget_exceeded'], 'failure_exception_budget_consistency')
            require(type(failure.get('score_call_cpu_ns')) is int and 0 <= failure['score_call_cpu_ns'] <= worker['score_call_cpu_ns'], 'failure_score_cpu')
        else:
            require(failure is None, 'unexpected_numeric_failure')
        if self.profile is not None:
            require(worker['cleanup_seconds'] <= self.profile['cleanup_wall_seconds'] and
                    worker['wall_seconds'] <= worker['instance_wall_seconds'] and
                    worker['startup_seconds'] <= worker['wall_seconds'], 'worker_elapsed_consistency')
            # The producer's published cap-attribution rule permits up to one
            # second of reported rusage overshoot; this does not raise RLIMIT_CPU.
            require(worker['cpu_seconds'] <= cpu_limit+1 and worker['cpu_seconds'] <= worker['wall_seconds']+.05,
                    'worker_cpu_usage_consistency')
            active = worker.get('active_completed_at')
            if role == 'instance' and not numerical and not cap_failure:
                require(type(active) in (int, float) and math.isfinite(active) and
                        worker['instance_started'] <= active < worker['absolute_deadline'] and
                        active-worker['instance_started']+worker['cleanup_seconds'] <= worker['instance_wall_seconds']+1e-6,
                        'successful_active_completion_deadline')
            else:
                require(active is None, 'failed_or_admission_no_active_completion')
            if cap_failure:
                require(role in ('admission', 'instance') and not numerical and worker['assignment_complete'] is False,
                        'cap_failure_role_assignment')
                terminal = worker.get('terminal_reason')
                require(type(terminal) is dict and set(terminal) == {'kind', 'scope', 'limit_seconds',
                        'observed_seconds', 'trigger', 'stage', 'signal', 'returncode'} and
                        terminal == worker.get('resource_limit'), 'structured_cap_reason')
                require(terminal['stage'] in ('startup', 'admission', 'score', 'cleanup') and
                        terminal['returncode'] == worker['returncode'] and terminal['signal'] == 9 and
                        type(terminal['limit_seconds']) in (int, float) and terminal['limit_seconds'] > 0 and
                        type(terminal['observed_seconds']) in (int, float) and math.isfinite(terminal['observed_seconds']),
                        'cap_terminal_fields')
                require(terminal['observed_seconds'] <= worker['instance_wall_seconds'], 'cap_observed_elapsed_consistency')
                if cap_failure == 'resource_limit':
                    require(terminal['kind'] == 'worker_cpu_limit' and terminal['scope'] == 'worker_cpu' and
                            terminal['trigger'] == 'wait4_sigkill_cpu_near_cap' and terminal['limit_seconds'] == cpu_limit,
                            'cpu_cap_rule')
                    require(worker.get('parent_kill_attempted') is False and worker.get('parent_kill_sent') is False and
                            worker.get('cpu_cap_evidence') == {'typed_eof': True, 'natural_wait4_reap': True,
                                'near_cap_tolerance_seconds': {'below': 0.05, 'above': 1.0}, 'os_confirmed_cause': False},
                            'qualified_cpu_cap_evidence')
                    require(cpu_limit-0.05 <= terminal['observed_seconds'] <= cpu_limit+1 and
                            abs(terminal['observed_seconds'] - worker['cpu_seconds']) < 1e-9, 'cpu_cap_rusage')
                else:
                    require(cap_failure == 'timeout' and terminal['scope'] in ('instance_wall', 'request_wall') and
                            terminal['kind'] == terminal['scope'] + '_limit' and terminal['trigger'] == 'parent_monotonic_deadline',
                            'wall_cap_rule')
                    require(worker.get('parent_kill_attempted') is True and worker.get('parent_kill_sent') is True,
                            'wall_cap_parent_kill')
                    expected_limit = (worker['absolute_deadline'] - worker['instance_started'] if terminal['scope'] == 'instance_wall'
                                      else role_limits['startup_wall_seconds'] if terminal['stage'] == 'startup'
                                      else role_limits['request_wall_seconds'])
                    require(abs(terminal['limit_seconds'] - expected_limit) < 1e-6 and
                            terminal['observed_seconds'] >= terminal['limit_seconds'], 'wall_cap_deadline')
            else:
                require(worker.get('terminal_reason') is None and worker.get('resource_limit') is None,
                        'unexpected_cap_reason')

    def _supervisor(self, value, worker, binding, *, execution_id, instance_index):
        require(self.profile is not None and type(value) is dict, 'supervisor_receipt_required')
        require(value.get('role') == 'instance_supervisor' and value.get('resource_profile_sha256') == binding['resource_profile_sha256'] and
                value.get('runtime_freeze_sha256') == binding['runtime_freeze_sha256'] and
                value.get('execution_id') == execution_id and type(value.get('instance_index')) is int and
                value['instance_index'] == instance_index, 'supervisor_identity_profile')
        limits = deepcopy(LIMITS)
        limits['cpu_seconds'] = [self.profile['supervisor_cpu_seconds']]*2
        limits['open_files'] = [32, 32]
        require(value.get('host_observed_limits') == limits and value.get('configured_wall_seconds') == self.profile['roles']['instance']['wall_seconds'] and
                value.get('cleanup_within_wall') is True, 'supervisor_resource_bounds')
        require(type(value.get('pid')) is int and value['pid'] > 1 and value['pid'] != worker['pid'] and
                value.get('reaped') is True and type(value.get('returncode')) is int and value['returncode'] == 0 and
                value.get('cleanup_error') is None, 'supervisor_cleanup')
        require(value.get('shared_instance_started') == worker['instance_started'] and
                value.get('shared_absolute_deadline') == worker['total_wall_deadline'], 'shared_supervisor_child_deadline')
        require(value.get('cpu_accounting_scope') == 'Linux wait4 inclusive descendants; self_at_emit excludes final serialization tail',
                'supervisor_cpu_accounting_scope')
        for key in ('wait4_cpu_seconds', 'self_cpu_at_emit', 'actual_supervisor_cpu_seconds', 'child_cpu_seconds', 'wall_seconds'):
            require(type(value.get(key)) in (int, float) and math.isfinite(value[key]) and value[key] >= 0,
                    'supervisor_usage:' + key)
        require(value['wall_seconds'] <= self.profile['roles']['instance']['wall_seconds'], 'observed_supervisor_shared_wall_budget')
        require(worker['instance_wall_seconds'] <= value['wall_seconds'] and
                value['actual_supervisor_cpu_seconds'] <= self.profile['supervisor_cpu_seconds']+1 and
                value['self_cpu_at_emit'] <= value['actual_supervisor_cpu_seconds']+.01 and
                value['actual_supervisor_cpu_seconds'] <= value['wall_seconds']+.05,
                'supervisor_elapsed_cpu_consistency')
        require(value['child_cpu_seconds'] == worker['cpu_seconds'] and
                value['wait4_cpu_seconds'] + .01 >= value['self_cpu_at_emit'] + value['child_cpu_seconds'] and
                abs(value['actual_supervisor_cpu_seconds'] - max(0.0, value['wait4_cpu_seconds']-value['child_cpu_seconds'])) < 1e-9,
                'no_double_counted_supervisor_cpu')
        for key in ('peak_rss_kib', 'input_bytes', 'output_bytes', 'stderr_bytes'):
            require(type(value.get(key)) is int and value[key] >= 0, 'supervisor_counter:' + key)
        require(value['input_bytes'] <= 327680 and value['output_bytes'] <= 1048576 and value['stderr_bytes'] == 0,
                'supervisor_transport_bounds')

    def validate_panel(self, panel):
        require(type(panel) is dict and panel.get('kind') == self.mode and type(panel.get('instances')) is list and
                1 <= len(panel['instances']) <= 5, 'deployment_panel')
        if self.mode == 'registered_source_study':
            require(len(panel['instances']) == 5, 'study_requires_exact_five_instance_panel')
        for index, item in enumerate(panel['instances']):
            require(type(item) is dict and type(item.get('instance_index')) is int and item['instance_index'] == index and
                    type(item.get('n')) is int and 1 <= item['n'] <= 5000 and type(item.get('L1')) is int and
                    1 <= item['L1'] <= item['n'] and type(item.get('capacity')) is int and item['capacity'] in (100, 500) and
                    is_hash(item.get('input_sha256')), 'panel_metadata')

    def verify_receipt(self, bundle, capture, claim, panel, freeze):
        """Read-only verification of a completed receipt; never invokes backend."""
        verify_seal(bundle)
        candidate, binding, format_metrics = self.expected_binding(capture, claim, freeze)
        self.validate_panel(panel)
        require(bundle.get('schema') == 'wave-bounded-verification-v1' and bundle.get('mode') == self.mode, 'bundle_schema_mode')
        for part in (bundle, bundle.get('admission')):
            require(type(part) is dict and part.get('deployment_sha256') == self.deployment['sha256'] and
                    part.get('source_origin') == self.deployment['source_origin'], 'deployment_receipt_provenance')
            if self.profile is not None:
                require(part.get('resource_profile_sha256') == binding['resource_profile_sha256'], 'receipt_resource_profile')
        for key, expected in {'claim_id': claim['claim_id'], 'slot_id': claim['slot_id'], 'source_sha256': candidate['code_sha256'],
                'description_sha256': candidate['description_sha256'], 'freeze_sha256': freeze['sha256'],
                'intake_manifest_sha256': freeze['intake_manifest_sha256'], 'policy_sha256': binding['policy_sha256']}.items():
            require(bundle.get(key) == expected, 'bundle_binding:' + key)
        self._binding(bundle.get('registry_binding'), binding)
        require(bundle.get('arithmetic_policy') == self.policy, 'full_arithmetic_policy')
        if self.profile is not None:
            require(bundle.get('resource_profile') == self.profile, 'full_resource_profile')
        admission, identity, scores = bundle.get('admission'), bundle.get('identity'), bundle.get('scores')
        require(type(admission) is dict and type(admission.get('admitted')) is bool and type(scores) is list, 'admission_score_schema')
        if self.profile is not None:
            require(admission.get('worker_role') == 'admission', 'outer_admission_worker_role')
        self._binding(admission.get('registry_binding'), binding)
        admission_cap = self.profile is not None and not admission['admitted'] and admission.get('kind') in ('resource_limit', 'timeout')
        require(admission.get('policy_sha256') == binding['policy_sha256'] and
                admission.get('source_sha256') == candidate['code_sha256'] and
                (admission_cap or admission.get('binding_sha256') == digest(binding)) and admission.get('bounded_child_verified') is True and
                admission.get('runtime_sha256') == freeze['runtime_sha256'] and
                admission.get('isolation_profile_sha256') == freeze['isolation_profile_sha256'] and
                admission.get('cleanup_status') == 'passed', 'admission_evidence')
        if not admission['admitted']:
            require((admission_cap or admission.get('kind') in ('source_protocol', 'static', 'compile')) and identity is None and scores == [], 'rejection_only')
            self._worker(admission.get('worker'), binding, canonical_sha256=None, admitted=False, expected_admission=admission, role='admission',
                steps=0, cap_failure=admission['kind'] if admission_cap else None)
            return {'candidate': None, 'scores': [], 'admission': deepcopy(admission), 'registry_binding': binding,
                    'eligible_for_scheduler': False, 'mode': self.mode, 'format_metrics': format_metrics}
        require(type(identity) is dict and identity.get('method') == 'bounded-child-ast-dump-v1', 'child_identity_method')
        canonical_text = identity.get('canonical_text')
        require(type(canonical_text) is str and 0 < len(canonical_text) <= MAX_AST and
                len(canonical_text.encode('utf-8')) <= MAX_AST, 'canonical_text_bound')
        code_identity = sha(canonical_text.encode('utf-8'))
        require(identity.get('code_identity') == code_identity and identity.get('joint_identity') ==
                digest([candidate['description'].strip(), canonical_text]), 'canonical_identity_hash')
        require(admission.get('manifest_sha256') == self.manifest_sha256 and type(admission.get('node_count')) is int and
                1 <= admission['node_count'] <= 4096 and type(admission.get('ast_depth')) is int and
                1 <= admission['ast_depth'] <= 64, 'admission_manifest_bounds')
        apis = admission.get('apis')
        require(type(apis) is list and len(apis) <= 46 and all(type(name) is str and name in self.api_names for name in apis)
                and len(set(apis)) == len(apis), 'admission_apis')
        self._worker(admission.get('worker'), binding, canonical_sha256=code_identity, admitted=True, expected_admission=admission, role='admission', steps=0)
        require(1 <= len(scores) <= len(panel['instances']), 'score_count')
        failed = False
        for index, record in enumerate(scores):
            require(type(record) is dict and type(record.get('instance_index')) is int and record['instance_index'] == index and
                    record.get('kind') == self.mode and record.get('code_sha256') == candidate['code_sha256'], 'ordered_uncached_score')
            expected = panel['instances'][index]
            require(record.get('input_sha256') == expected['input_sha256'] and type(record.get('L1')) is int and
                    record['L1'] == expected['L1'], 'score_panel_binding')
            evidence = record.get('evidence'); require(type(evidence) is dict, 'score_evidence')
            require(evidence.get('deployment_sha256') == self.deployment['sha256'] and
                    evidence.get('source_origin') == self.deployment['source_origin'], 'score_deployment_provenance')
            if self.profile is not None:
                require(evidence.get('resource_profile_sha256') == binding['resource_profile_sha256'], 'score_resource_profile')
                require(evidence.get('worker_role') == 'instance' and evidence.get('instance_index') == index and
                        type(evidence.get('instance_index')) is int, 'score_worker_role_instance')
            self._binding(evidence.get('registry_binding'), binding)
            for key, value in {'slot_id': claim['slot_id'], 'claim_id': claim['claim_id'],
                    'execution_id': claim['claim_id'] + '/instance/' + str(index),
                    'intake_manifest_sha256': freeze['intake_manifest_sha256'], 'runtime_sha256': freeze['runtime_sha256'],
                    'isolation_profile_sha256': freeze['isolation_profile_sha256'], 'checker_sha256': freeze['checker_sha256'],
                    'policy_sha256': binding['policy_sha256']}.items():
                require(evidence.get(key) == value, 'score_evidence_binding:' + key)
            require(evidence.get('no_cross_slot_cache') is True and evidence.get('cleanup_status') == 'passed', 'score_cleanup_cache')
            outcome = record.get('outcome')
            supported = ('ok', 'numeric_failure', 'resource_limit', 'timeout') if self.profile is not None else ('ok', 'numeric_failure')
            require(outcome in supported and not failed, 'backend_outcome_order')
            if outcome == 'ok':
                require(type(record.get('used_bins')) is int and expected['L1'] <= record['used_bins'] <= expected['n'] and
                        evidence.get('checker_status') == 'passed' and is_hash(evidence.get('assignment_sha256')), 'verified_bin_count')
                self._worker(evidence.get('worker'), binding, canonical_sha256=code_identity, admitted=True, expected_admission=admission,
                    role='instance', steps=expected['n'], instance_index=index, execution_id=evidence['execution_id'])
            else:
                failed = True
                require(record.get('used_bins') is None and evidence.get('checker_status') == 'not_run' and
                        evidence.get('assignment_sha256') is None and index == len(scores)-1, 'numeric_failure_no_repair')
                self._worker(evidence.get('worker'), binding, canonical_sha256=code_identity, admitted=True, expected_admission=admission,
                    role='instance', numerical=outcome == 'numeric_failure', cap_failure=outcome if outcome != 'numeric_failure' else None,
                    instance_index=index, execution_id=evidence['execution_id'])
                require(evidence['worker']['steps'] < expected['n'] if outcome == 'numeric_failure' else
                        evidence['worker']['steps'] <= expected['n'], 'failure_placement_count')
            if self.profile is not None:
                require(evidence.get('assignment_complete') is (outcome == 'ok'), 'score_assignment_completion')
                self._supervisor(evidence.get('supervisor'), evidence['worker'], binding,
                    execution_id=evidence['execution_id'], instance_index=index)
        require(failed or len(scores) == len(panel['instances']), 'missing_successful_instance')
        candidate.update(code_identity=code_identity, joint_identity=identity['joint_identity'])
        return {'candidate': candidate, 'scores': deepcopy(scores), 'admission': deepcopy(admission),
                'registry_binding': binding, 'eligible_for_scheduler': self.mode == 'registered_source_study' and not failed,
                'mode': self.mode, 'format_metrics': format_metrics, 'all_instances_passed': not failed}

    def call_backend(self, backend, capture, claim, panel, freeze, *, explicit_execution_grant=False):
        """Optional orchestration; default blocked until independently authorized.

        Caller must already hold specific external execution authority and durable
        raw/slot reservations. The boolean documents that precondition; it is not
        an authorization mechanism. Any exception permanently consumes this local
        call identity; external journal remains authoritative across restarts.
        """
        require(explicit_execution_grant is True, 'execution_not_granted_default_block')
        candidate, binding, _ = self.expected_binding(capture, claim, freeze)
        self.validate_panel(panel)
        require(claim['claim_id'] not in self.used_claims, 'no_repeated_backend_attempt')
        self.used_claims.add(claim['claim_id'])
        backend.bind_capture(deepcopy(claim), binding['raw_response_sha256'])
        bundle = backend.verify(deepcopy(candidate), deepcopy(claim), deepcopy(panel), deepcopy(freeze))
        return self.verify_receipt(bundle, capture, claim, panel, freeze)

    def scheduler_observation(self, bundle, capture, claim, panel, freeze):
        """Explicit reviewed study-receipt projection for the unchanged pure scheduler.

        Test receipts cannot enter the study scheduler. Original provenance remains
        in every evidence object; this method does not enable a transport or launch.
        """
        result = self.verify_receipt(bundle, capture, claim, panel, freeze)
        require(self.mode == 'registered_source_study' and self.deployment['source_origin'] == 'model_response',
                'test_receipts_cannot_be_relabelled_for_scheduler')
        scheduler_panel = deepcopy(panel); scheduler_panel['kind'] = 'externally_verified'
        scores = deepcopy(result['scores'])
        for record in scores:
            record['registry_mode'] = record['kind']; record['kind'] = 'externally_verified'
        return {'panel': scheduler_panel, 'candidate': result['candidate'], 'scores': scores,
                'admission': result['admission'], 'format_metrics': result['format_metrics'],
                'registry_binding': result['registry_binding'], 'deployment_sha256': self.deployment['sha256']}
