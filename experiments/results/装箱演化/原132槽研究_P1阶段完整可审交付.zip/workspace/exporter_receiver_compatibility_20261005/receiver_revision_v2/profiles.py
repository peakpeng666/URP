"""Pure, closed profile identities mirrored from the reviewed producer schema.

Resolving a profile does not authorize execution or create a deployment.
"""
from copy import deepcopy
from bridge import digest, require

PRODUCTION = 'production-60cpu-90wall-v1'
DIAGNOSTIC = 'diagnostic-1cpu-5wall-v1'


def document(profile_id):
    require(profile_id in (PRODUCTION, DIAGNOSTIC), 'unknown_closed_resource_profile')
    production = profile_id == PRODUCTION
    return {'schema': 'registered-numpy-resource-profile-v1', 'profile_id': profile_id,
        'roles': {'admission': {'cpu_seconds': 1, 'wall_seconds': 5,
                              'request_wall_seconds': 5 if production else 2, 'startup_wall_seconds': 5},
                  'instance': {'cpu_seconds': 60 if production else 1, 'wall_seconds': 90 if production else 5,
                               'request_wall_seconds': 90 if production else 2, 'startup_wall_seconds': 5}},
        'worker_as_bytes': 536870912, 'max_open_files': 3, 'max_file_size_bytes': 0,
        'max_core_bytes': 0, 'max_steps': 5000, 'max_source_bytes': 16384, 'max_instances': 5,
        'supervisor_cpu_seconds': 60 if production else 10, 'both_arms_identical': True,
        'cleanup_wall_seconds': 2, 'cleanup_within_wall': True}


def resolve(expected_sha256):
    for name in (PRODUCTION, DIAGNOSTIC):
        value = document(name)
        if digest(value) == expected_sha256:
            return value
    raise ValueError('unapproved_resource_profile_hash')


def configured(profile, role):
    require(role in ('admission', 'instance'), 'worker_role')
    value = deepcopy(profile['roles'][role])
    value.update({key: profile[key] for key in ('worker_as_bytes', 'max_open_files', 'max_file_size_bytes',
        'max_core_bytes', 'max_steps', 'max_source_bytes', 'max_instances', 'supervisor_cpu_seconds', 'cleanup_wall_seconds',
        'cleanup_within_wall')})
    return value
