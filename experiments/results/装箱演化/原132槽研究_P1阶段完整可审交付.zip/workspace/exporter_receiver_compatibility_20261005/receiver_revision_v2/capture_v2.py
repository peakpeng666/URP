"""Bounded receiver schema v2; no model client or session creation exists here.

Session IDs are observed SDK IDs, never derived from/relabelled to claim IDs.
The independent invocation receipt and session-claim store are trust boundaries.
"""
import base64
import json
from bridge import MAX_RAW, bound, digest, is_hash, require, sha, verify_seal

MAX_EXPORT = 524288
CONFIG_EVIDENCE = 'configured_settings_not_observed_wire_parameters'
TERMINALS = {'ok', 'timeout', 'transport_failure', 'cli_failure', 'cancelled'}


def strict_json(raw):
    require(type(raw) is bytes and 0 < len(raw) <= MAX_EXPORT, 'export_byte_bound')
    text = raw.decode('utf-8', errors='strict')
    depth, quoted, escaped = 0, False, False
    for char in text:
        if quoted:
            if escaped: escaped = False
            elif char == '\\': escaped = True
            elif char == '"': quoted = False
        elif char == '"': quoted = True
        elif char in '[{':
            depth += 1; require(depth <= 16, 'export_depth')
        elif char in ']}':
            depth -= 1; require(depth >= 0, 'export_balance')
    require(depth == 0 and not quoted, 'export_incomplete')
    def pairs(entries):
        result = {}
        for key, value in entries:
            require(key not in result, 'duplicate_json_key'); result[key] = value
        return result
    def integer(token):
        require(len(token) <= 20, 'integer_token_bound'); return int(token)
    def constant(_): raise ValueError('nonfinite_json')
    value = json.loads(text, object_pairs_hook=pairs, parse_int=integer, parse_constant=constant)
    bound(value, MAX_EXPORT)
    return value


class CaptureImporter:
    """session_store.claim must durably CAS actual session IDs across all slots.

    The caller also retains every exact terminal artifact externally BEFORE this
    receiver runs. Malformed/oversized artifacts are quarantined there, not repaired.
    An unknown session CAS result stops; the caller must reconcile and not retry.
    """
    def __init__(self, session_store):
        self.session_store = session_store

    def import_capture(self, artifact, receiver_sha256, claim, freeze, invocation_receipt):
        verify_seal(claim); verify_seal(freeze); verify_seal(invocation_receipt)
        require(claim.get('freeze_sha256') == freeze['sha256'], 'claim_freeze_binding')
        if freeze.get('mode') not in ('mock_only', 'handwritten_registry_test'):
            require(getattr(self.session_store, 'durable_external', False) is True, 'production_requires_durable_session_store')
        require(type(artifact) is bytes and len(artifact) <= MAX_EXPORT, 'export_byte_bound')
        require(is_hash(receiver_sha256) and sha(artifact) == receiver_sha256, 'independent_receiver_hash')
        require(invocation_receipt.get('schema') == 'external-model-invocation-v2' and
                invocation_receipt.get('claim_id') == claim['claim_id'] and
                invocation_receipt.get('claim_sha256') == claim['sha256'] and
                invocation_receipt.get('request_sha256') == claim['request_sha256'], 'invocation_claim_binding')
        invocation_id = invocation_receipt.get('invocation_id')
        require(type(invocation_id) is str and 0 < len(invocation_id.encode()) <= 128, 'invocation_id')
        value = strict_json(artifact)
        require(type(value) is dict and set(value) == {'schema', 'claim_id', 'slot_id', 'invocation_id',
                'request_sha256', 'configured_settings_sha256', 'config_file_sha256', 'cli', 'terminal',
                'raw_b64', 'raw_sha256'}, 'export_v2_fields')
        require(value['schema'] == 'bounded-official-cli-export-v2' and value['claim_id'] == claim['claim_id'] and
                value['slot_id'] == claim['slot_id'] and value['invocation_id'] == invocation_id and
                value['request_sha256'] == claim['request_sha256'], 'export_claim_invocation')
        require(value['configured_settings_sha256'] == digest(freeze['configured_settings']) and
                value['config_file_sha256'] == freeze['config_file_sha256'] == invocation_receipt.get('config_file_sha256'),
                'configured_settings_file_binding')
        cli = value['cli']
        require(type(cli) is dict and set(cli) == {'binary_sha256', 'exporter_source_sha256', 'version', 'mode',
                'configured_settings', 'settings_evidence', 'wire_parameters', 'actual_session_id',
                'observed_session_ids', 'new_session_observed', 'resume_requested', 'session_evidence_sha256'}, 'cli_v2_fields')
        require(cli['binary_sha256'] == freeze['cli_binary_sha256'] and
                cli['exporter_source_sha256'] == freeze['cli_exporter_source_sha256'] and
                cli['version'] == freeze['cli_version'] and cli['mode'] == freeze['mode'], 'cli_source_version_mode')
        require(cli['configured_settings'] == freeze['configured_settings'] and
                cli['settings_evidence'] == CONFIG_EVIDENCE and cli['wire_parameters'] is None,
                'configuration_evidence_not_wire_claim')
        require(cli['resume_requested'] is False and type(cli['new_session_observed']) is bool, 'no_resume')
        require(is_hash(cli['session_evidence_sha256']) and
                cli['session_evidence_sha256'] == invocation_receipt.get('session_evidence_sha256'), 'session_evidence_binding')
        sessions = cli['observed_session_ids']
        require(type(sessions) is list and len(sessions) <= 1 and
                all(type(value) is str and 0 < len(value.encode()) <= 256 for value in sessions), 'one_observed_session')
        require(cli['actual_session_id'] == (sessions[0] if sessions else None), 'actual_sdk_session_id')
        require(invocation_receipt.get('actual_session_id') == cli['actual_session_id'] and
                invocation_receipt.get('observed_session_ids') == sessions and
                invocation_receipt.get('new_session_observed') is cli['new_session_observed'] and
                invocation_receipt.get('resume_requested') is False, 'independent_session_observation_binding')
        terminal = value['terminal']
        require(type(terminal) is dict and set(terminal) == {'status', 'capture_complete', 'finish_reason', 'tool_calls',
                'usage', 'physical_http_attempts', 'exit_code', 'process_terminal'}, 'terminal_fields')
        require(terminal['status'] in TERMINALS and terminal['process_terminal'] is True and
                type(terminal['capture_complete']) is bool and type(terminal['tool_calls']) is list, 'terminal_status')
        require(terminal['exit_code'] is None or type(terminal['exit_code']) is int, 'exit_code_type')
        if terminal['status'] == 'ok':
            require(terminal['exit_code'] == 0 and len(sessions) == 1 and cli['new_session_observed'] is True,
                    'success_requires_one_new_session')
        if sessions:
            require(cli['new_session_observed'] is True, 'observed_session_must_be_new')
        attempts = terminal['physical_http_attempts']
        require(attempts is None or type(attempts) is int and attempts >= 1, 'attempt_count')
        usage = terminal['usage']
        require(type(usage) is dict and set(usage) == {'input_tokens', 'output_tokens', 'reasoning_tokens', 'wall_seconds'}, 'usage_fields')
        for key, item in usage.items():
            require(item is None or type(item) in (int, float) and item >= 0, 'usage_value')
            if key != 'wall_seconds': require(item is None or type(item) is int, 'usage_token_type')
        encoded = value['raw_b64']
        require(type(encoded) is str and encoded.isascii() and len(encoded) <= 4*((MAX_RAW+2)//3), 'raw_encoded_bound')
        raw = base64.b64decode(encoded, validate=True)
        require(len(raw) <= MAX_RAW and base64.b64encode(raw).decode('ascii') == encoded and sha(raw) == value['raw_sha256'], 'raw_identity')
        raw_text = raw.decode('utf-8', errors='strict')
        if sessions:
            # Does not convert/relabel the session ID. Unique invocation IDs alone
            # cannot establish fresh SDK sessions; the external store claims both.
            receipt = self.session_store.claim(sessions[0], claim['claim_id'], invocation_id)
            require(receipt == {'session_id': sessions[0], 'claim_id': claim['claim_id'], 'invocation_id': invocation_id},
                    'session_claim_readback')
        return dict(terminal, raw=raw_text, raw_sha256=sha(raw), receiver_artifact_sha256=receiver_sha256,
                    claim_id=claim['claim_id'], invocation_id=invocation_id, actual_session_id=cli['actual_session_id'],
                    configured_settings=cli['configured_settings'], settings_evidence=CONFIG_EVIDENCE,
                    config_file_sha256=value['config_file_sha256'], wire_parameters=None,
                    cli_provenance=cli)


class MockSessionStore:
    """Handwritten test provider only; not durable, never a production store."""
    durable_external = False
    def __init__(self): self.sessions = {}; self.invocations = set()
    def claim(self, session_id, claim_id, invocation_id):
        require(session_id not in self.sessions and invocation_id not in self.invocations, 'reused_session_or_invocation')
        value = {'session_id': session_id, 'claim_id': claim_id, 'invocation_id': invocation_id}
        self.sessions[session_id] = value; self.invocations.add(invocation_id)
        return dict(value)
