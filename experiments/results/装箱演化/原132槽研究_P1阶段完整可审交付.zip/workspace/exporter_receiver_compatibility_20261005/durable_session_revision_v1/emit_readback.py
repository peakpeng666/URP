"""Canonicalize an assistant-staged genuine readback and return its trusted pin."""
import hashlib
import json
from pathlib import Path
import sys
path = Path(sys.argv[1])
value = json.loads(path.read_bytes())
raw = json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode()
path.write_bytes(raw)
print(json.dumps({'readback_path': str(path), 'trusted_readback_sha256': hashlib.sha256(raw).hexdigest()}))
