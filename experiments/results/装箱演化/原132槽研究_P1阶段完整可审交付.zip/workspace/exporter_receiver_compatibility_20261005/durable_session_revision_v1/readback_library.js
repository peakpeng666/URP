/* Run as assistant code-mode with authenticated tools. No external writes.
 * Fetch the current Library skill's library_file_transfer.py once beforehand.
 * The returned digest is a parent-held trust root, never read from an untrusted
 * adjacent manifest. Root must separately pin actual producer fence stdout.
 */
async function readbackLibrary({indexLibraryFileId, destination, helperPath, adapterRoot}) {
  const q = x => "'" + String(x).replaceAll("'", "'\\''") + "'";
  const need = (ok, why) => { if (!ok) throw new Error(why); };
  function structured(r) {
    need(!r.isError, 'authenticated_tool_failed');
    if (r.structuredContent) return r.structuredContent;
    for (const c of r.content ?? []) if (c.type === 'text') {
      try { const s = JSON.parse(c.text); if (s) return s; } catch {}
    }
    throw new Error('missing_structured_tool_result');
  }
  async function read() {
    return structured(await tools.mcp__codex_apps__library_read({read:[{
      ref_id:indexLibraryFileId, mode:'full', max_lines:2
    }]}));
  }
  const before = await read();
  const row = before.results?.[0];
  need(before.results?.length === 1 && row.has_more === false && /^\d+$/.test(row.version_id)
       && Number(row.version_id) > 0 && row.library_file_id === indexLibraryFileId, 'incomplete_index_read');
  const index = JSON.parse(row.content.join('\n'));
  need(index.schema === 'eoh-cli-index-ledger-v2'
       && index.rows.every(r => r.state === 'terminal'), 'unresolved_or_unknown_index');
  const items = [{library_file_id:indexLibraryFileId, file_id:row.file_id, file_name:row.name}];
  for (const ack of Object.values(index.archives)) {
    need(ack.write_result_confirmed === true && Number.isInteger(ack.current_version_number)
         && ack.current_version_number > 0, 'unconfirmed_archive');
    items.push({library_file_id:ack.library_file_id, file_id:ack.file_id, file_name:ack.file_name});
  }
  const response = structured(await tools.mcp__codex_apps__library_prepare_materialize({items, destination:{directory:destination}}));
  const prepared = response.result ?? response;
  need(!(prepared.unavailable_items?.length) && prepared.transfers?.length === items.length, 'materialization_incomplete');
  const materialized = [];
  for (const tr of prepared.transfers) {
    need(items.some(i => i.library_file_id === tr.library_file_id && i.file_id === tr.file_id), 'unexpected_transfer');
    let local = tr.workspace_path;
    let command;
    if (local) command = 'python3 ' + q(helperPath) + ' apply-xattrs ' + q(local) + ' ' + q(tr.library_file_id)
         + " <<'LIBRARY_XATTRS_JSON'\n" + JSON.stringify(tr.xattrs ?? []) + '\nLIBRARY_XATTRS_JSON';
    else {
      need(tr.file_name && !/[\\/]/.test(tr.file_name), 'unsafe_transfer_basename');
      local = destination + '/' + tr.file_name;
      command = 'python3 ' + q(helperPath) + ' materialize ' + q(local)
         + " <<'LIBRARY_TRANSFER_JSON'\n" + JSON.stringify(tr) + '\nLIBRARY_TRANSFER_JSON';
    }
    const copied = await tools.exec_command({cmd:command,login:false,max_output_tokens:100});
    need(copied.exit_code === 0, 'local_materialization_failed');
    materialized.push({library_file_id:tr.library_file_id, file_id:tr.file_id,
      current_version_number:tr.current_version_number, size_bytes:tr.size_bytes, local_path:local});
  }
  const after = await read();
  const proof = {schema:'authenticated-library-readback-v1', evidence_kind:'actual_authenticated_tool_results',
                 read_before:before, read_after:after, materialized};
  const path = destination + '/readback.receipt.json';
  const staged = await tools.apply_patch('*** Begin Patch\n*** Add File: ' + path + '\n+' + JSON.stringify(proof) + '\n*** End Patch');
  need(!staged?.isError, 'readback_staging_failed');
  const pin = await tools.exec_command({cmd:'python3 -I ' + q(adapterRoot + '/emit_readback.py') + ' ' + q(path),login:false,max_output_tokens:300});
  need(pin.exit_code === 0, 'readback_pinning_failed');
  return JSON.parse(pin.output);
}
