"""Read-only adapter for the producer's existing external terminal CAS.

Trust roots are exact digests supplied by the authenticated parent, not digests
loaded from the evidence directory. A seal is integrity, never authentication.
No model client, CLI, worker, source parser or external write exists here.
"""
import base64
import copy
import hashlib
import importlib.util
import io
import json
from pathlib import Path, PurePosixPath
import zipfile

PROTOCOL_SHA256 = 'ef5efa2f8517ba78603fdf4e6a619590345d55ef4dd5e417ebfa1283e0bb2665'
MAX_ZIP = 48 * 1024 * 1024
MAX_EXPANDED = 64 * 1024 * 1024
MEMBERS = {'raw.txt', 'export.json', 'metadata.json', 'session-evidence.json',
           'invocation-receipt.json', 'config.raw.json'}


def need(ok, reason):
    if not ok:
        raise ValueError(reason)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def bounded_file(path, cap):
    path = Path(path)
    need(path.is_file() and not path.is_symlink() and 0 < path.stat().st_size <= cap,
         'missing_symlink_or_oversized_evidence')
    with path.open('rb') as stream:
        value = stream.read(cap + 1)
    need(len(value) <= cap, 'evidence_changed_or_oversized')
    return value


def load_protocol(path):
    need(sha(bounded_file(path, 65536)) == PROTOCOL_SHA256, 'unaccepted_protocol_source')
    spec = importlib.util.spec_from_file_location('_durable_session_pinned_protocol', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def read_wave(path, expected_hash, protocol):
    data = bounded_file(path, MAX_ZIP)
    need(sha(data) == expected_hash, 'archive_byte_identity')
    files = {}
    with zipfile.ZipFile(io.BytesIO(data)) as reader:
        entries = reader.infolist()
        need(len(entries) <= 512 and sum(e.file_size for e in entries) <= MAX_EXPANDED,
             'archive_expanded_bound')
        for entry in entries:
            name, p = entry.filename, PurePosixPath(entry.filename)
            need(not p.is_absolute() and '..' not in p.parts and '\\' not in name
                 and ':' not in name and name not in files, 'unsafe_duplicate_archive_path')
            need(not entry.is_dir() and not entry.flag_bits & 1
                 and (entry.external_attr >> 16) & 0o170000 != 0o120000,
                 'archive_special_or_encrypted')
            files[name] = reader.read(entry)
        need(reader.testzip() is None, 'archive_crc')
    need('file-hashes.json' in files and 'wave-manifest.json' in files, 'archive_manifest_missing')
    hashes = protocol.read_json(files['file-hashes.json'])
    need(set(hashes) == set(files) - {'file-hashes.json'}, 'archive_hash_roster')
    for name, expected in hashes.items():
        need(expected == {'bytes': len(files[name]), 'sha256': sha(files[name])},
             'archive_member_identity')
    manifest = protocol.read_json(files['wave-manifest.json'])
    need(set(manifest) == {'schema', 'phase', 'slots', 'retention', 'remote_byte_verification'}
         and manifest['schema'] == 'eoh-raw-wave-archive-v2', 'archive_schema')
    need(type(manifest['phase']) is int and manifest['phase'] in (0, 1, 2), 'archive_phase')
    slots = manifest['slots']
    need(type(slots) is list and slots == sorted(set(slots))
         and len(slots) <= (12, 60, 60)[manifest['phase']], 'archive_slot_roster')
    expected_names = {'wave-manifest.json', 'file-hashes.json'}
    for slot in slots:
        need(protocol.identifier(slot), 'archive_slot_identifier')
        expected_names.update('slots/' + slot + '/' + name for name in MEMBERS)
    need(set(files) == expected_names, 'archive_extra_or_missing_members')
    return manifest, files


class CommittedSessionStore:
    """claim() asserts an already committed mapping, and is idempotent.

    This is NOT a new claim, dispatch, evaluation admission or durable import-ack.
    Restore by repeating from_readback with a parent-pinned genuine readback.
    Fixture proofs never set durable_external; production requires official rows.
    """
    @property
    def durable_external(self):
        return self._durable_external

    @property
    def external_backing_verified(self):
        return self._external_backing_verified

    @classmethod
    def from_readback(cls, *, readback_path, trusted_readback_sha256,
                      fence_path, trusted_fence_sha256, freeze_path,
                      expected_run_id, expected_freeze_sha256, protocol_path):
        """The parent supplies both trusted hashes out of band from tool results.

        readback_path is emitted by readback_library.js. fence_path is the exact
        stdout of producer_fence_status.py run in the authorized producer, not
        in a copied package. A current matching Library read surrounds download.
        """
        p = load_protocol(protocol_path)
        raw = bounded_file(readback_path, 2 * 1024 * 1024)
        need(p.is_hash(trusted_readback_sha256) and sha(raw) == trusted_readback_sha256,
             'untrusted_readback_receipt')
        proof = p.read_json(raw, 2 * 1024 * 1024)
        need(proof.get('schema') == 'authenticated-library-readback-v1', 'readback_schema')
        need(proof.get('evidence_kind') == 'actual_authenticated_tool_results' or
             cls is OfflineFixtureSessionStore and
             proof.get('evidence_kind') == 'offline_fixture_tool_shapes', 'not_external_tool_evidence')
        # This label alone grants nothing: authenticated caller supplies its hash.
        before = cls._read_result(proof['read_before'])
        after = cls._read_result(proof['read_after'])
        identity = lambda r: (r['library_file_id'], r['file_id'], r['version_id'], r['content'])
        need(identity(before) == identity(after), 'index_changed_during_readback')
        index_bytes = '\n'.join(before['content']).encode('utf-8')
        index = p.read_json(index_bytes, p.MAX_INDEX)
        p.verify_index(index)
        need(set(index) == {'schema', 'mode', 'run_id', 'freeze_sha256', 'arms', 'caps',
                            'rows', 'archives', 'predecessor', 'sha256'}
             and type(index['arms']) is list and len(index['arms']) == 2
             and len(set(index['arms'])) == 2 and all(p.identifier(a) for a in index['arms']),
             'index_namespace_schema')
        need(p.canon(index) == index_bytes, 'index_noncanonical_readback')
        materialized = proof['materialized']
        need(type(materialized) is list and len(materialized) in (2, 3, 4), 'materialized_count')
        by_library = {x['library_file_id']: x for x in materialized}
        need(len(by_library) == len(materialized), 'duplicate_materialized_identity')
        idx = by_library.get(before['library_file_id'])
        need(idx is not None and idx['file_id'] == before['file_id']
             and type(idx['current_version_number']) is int
             and idx['current_version_number'] == int(before['version_id']), 'index_materialization_identity')
        need(bounded_file(idx['local_path'], p.MAX_INDEX) == index_bytes
             and idx['size_bytes'] == len(index_bytes), 'index_materialized_readback_bytes')
        freeze = p.read_json(bounded_file(freeze_path, p.MAX_EXPORT))
        p.verify_seal(freeze)
        need(freeze['sha256'] == expected_freeze_sha256 == index['freeze_sha256']
             and index['run_id'] == expected_run_id, 'wrong_run_or_freeze')
        need(index['mode'] == freeze['mode'], 'index_freeze_mode')
        need(freeze.get('run_id', expected_run_id) == expected_run_id, 'freeze_run_binding')
        need(not any(r['state'] != 'terminal' for r in index['rows']), 'unresolved_claim_reconcile_no_retry')
        need(index['rows'], 'no_committed_terminals')
        fence_raw = bounded_file(fence_path, p.MAX_INDEX)
        need(p.is_hash(trusted_fence_sha256) and sha(fence_raw) == trusted_fence_sha256,
             'untrusted_producer_fence_receipt')
        fence = p.read_json(fence_raw, p.MAX_INDEX)
        need(fence.get('schema') == 'producer-fence-status-v1'
             and fence.get('external_write_pending') is False
             and fence.get('unresolved_dispatch_fences') == 0, 'unknown_or_pending_write_fence')
        observation_kind = fence.get('observation_kind')
        need(observation_kind in ('actual_producer_status_tool_stdout', 'parent_accepted_producer_attestation')
             or cls is OfflineFixtureSessionStore and observation_kind == 'offline_fixture_tool_shapes',
             'unknown_fence_evidence_kind')
        if observation_kind == 'parent_accepted_producer_attestation':
            source = fence['source']
            transcript_raw = bounded_file(source['transcript_path'], p.MAX_EXPORT)
            need(sha(transcript_raw) == source['transcript_sha256'], 'fence_transcript_identity')
            transcript = p.read_json(transcript_raw)['structuredContent']
            need(transcript['threadId'] == source['thread_id']
                 and transcript['latestTurn']['id'] == source['turn_id']
                 and transcript['latestTurn']['status'] == 'completed'
                 and any(item.get('turnId') == source['turn_id'] and item.get('role') == 'assistant'
                         and item.get('truncated') is False for item in transcript['items']),
                 'fence_attestation_producer_turn')
        for key, expected in [('library_file_id', before['library_file_id']), ('file_id', before['file_id']),
                              ('current_version_number', int(before['version_id'])),
                              ('index_blob_sha256', sha(index_bytes)), ('run_id', expected_run_id),
                              ('freeze_sha256', expected_freeze_sha256)]:
            need(fence.get(key) == expected, 'producer_fence_head_mismatch')
        commit = fence.get('commit_receipt')
        need(type(commit) is dict and commit.get('write_result_confirmed') is True
             and commit.get('index_readback_confirmed') is True
             and commit.get('local_blob_sha256') == sha(index_bytes)
             and commit.get('library_file_id') == before['library_file_id']
             and commit.get('file_id') == before['file_id']
             and commit.get('current_version_number') == int(before['version_id']),
             'producer_commit_ack_mismatch')
        waves = {}
        for phase, ack in index['archives'].items():
            need(phase in ('0', '1', '2') and ack.get('write_result_confirmed') is True,
                 'archive_ack')
            material = by_library.get(ack['library_file_id'])
            need(material is not None and material['file_id'] == ack['file_id']
                 and type(ack['current_version_number']) is int and ack['current_version_number'] > 0
                 and type(material['current_version_number']) is int
                 and material['current_version_number'] == ack['current_version_number']
                 and material['size_bytes'] == ack['local_blob_bytes'], 'archive_version_identity')
            manifest, files = read_wave(material['local_path'], ack['local_blob_sha256'], p)
            need(manifest['phase'] == int(phase), 'archive_wrong_phase')
            need(manifest['slots'] == sorted(r['claim']['slot_id'] for r in index['rows'] if r['phase'] == int(phase)),
                 'archive_index_slot_roster')
            waves[int(phase)] = files
        need(set(by_library) == {before['library_file_id']} | {a['library_file_id'] for a in index['archives'].values()},
             'unrelated_materialized_identity')
        self = object.__new__(cls)
        self._durable_external = False
        self._external_backing_verified = proof['evidence_kind'] == 'actual_authenticated_tool_results'
        self._records = {}
        self._freeze = freeze
        self._proof_sha256 = trusted_readback_sha256
        self._fence_sha256 = trusted_fence_sha256
        for row in index['rows']:
            self._validate_row(row, waves, index, freeze, p)
        # External fixtures prove storage mechanics, not official production observations.
        self._durable_external = self._external_backing_verified and freeze['mode'] == 'official_cli'
        self.index_identity = {'library_file_id': before['library_file_id'], 'file_id': before['file_id'],
                               'version': int(before['version_id']), 'sha256': sha(index_bytes)}
        return self

    @staticmethod
    def _read_result(response):
        need(type(response) is dict and response.get('api_tool_source') == 'files/read'
             and len(response.get('results', [])) == 1, 'library_read_response')
        r = response['results'][0]
        version = r.get('version_id')
        need(type(version) is str and version.isdecimal() and int(version) > 0,
             'unknown_index_version')
        need(r.get('has_more') is False and r.get('file_provider') == 'native'
             and type(r.get('content')) is list and all(type(x) is str for x in r['content']),
             'incomplete_or_untrusted_readback')
        return r

    def _validate_row(self, row, waves, index, freeze, p):
        need(set(row) == {'claim', 'reservation', 'phase', 'arm', 'state', 'terminal'}, 'index_row_fields')
        claim, reservation, ref = row['claim'], row['reservation'], row['terminal']
        need(claim['schema'] == 'wave-external-claim-v1'
             and reservation['schema'] == 'external-model-invocation-reservation-v2', 'claim_reservation_schema')
        need(p.identifier(claim['slot_id']) and p.is_hash(claim['claim_id'])
             and p.is_hash(claim['request_sha256']) and p.identifier(reservation['invocation_id']), 'claim_identity_type')
        if freeze['mode'] == 'official_cli':
            need(claim['claim_id'] == p.digest(['wave-claim-v1', claim['run_id'], claim['slot_id']]),
                 'production_claim_identity')
            need(freeze.get('configuration') == freeze.get('configured_settings')
                 and freeze.get('exporter_source_sha256') == freeze.get('cli_exporter_source_sha256'),
                 'production_freeze_aliases')
        need(reservation['invocation_id'] == p.digest(['invocation-v2', claim['run_id'], claim['claim_id']])
             and reservation['config_file_sha256'] == freeze['config_file_sha256'], 'reservation_identity_config')
        need(set(ref) == {'artifact_sha256', 'session_evidence_sha256', 'invocation_receipt_sha256',
             'config_file_sha256', 'actual_session_id', 'status', 'capture_complete',
             'archive_file_id', 'archive_version'}, 'terminal_ref_fields')
        ack = index['archives'].get(str(row['phase']))
        need(ack is not None and type(ref['archive_version']) is int
             and 0 < ref['archive_version'] <= ack['current_version_number'], 'terminal_archive_version')
        if ref['archive_version'] == ack['current_version_number']:
            need(ref['archive_file_id'] == ack['file_id'], 'terminal_archive_identity')
        # Older terminal refs remain untouched. Current same-identity phase archive
        # independently proves every exact retained member, including old slots.
        files = waves[row['phase']]
        retained = {name: files['slots/' + claim['slot_id'] + '/' + name] for name in MEMBERS}
        for key, name in [('artifact_sha256', 'export.json'), ('session_evidence_sha256', 'session-evidence.json'),
                          ('invocation_receipt_sha256', 'invocation-receipt.json'), ('config_file_sha256', 'config.raw.json')]:
            need(ref[key] == sha(retained[name]), 'terminal_member_binding')
        invocation = p.make_invocation_receipt(claim, reservation, retained['config.raw.json'], retained['session-evidence.json'])
        need(p.read_json(retained['invocation-receipt.json']) == invocation, 'independent_receipt_mismatch')
        export = p.verify_export(retained['export.json'], ref['artifact_sha256'], claim, reservation, freeze,
                                 invocation, retained['config.raw.json'], retained['session-evidence.json'])
        need(base64.b64decode(export['raw_b64'], validate=True) == retained['raw.txt'], 'raw_archive_binding')
        need(ref['actual_session_id'] == invocation['actual_session_id']
             and ref['status'] == export['terminal']['status']
             and ref['capture_complete'] is export['terminal']['capture_complete'], 'terminal_semantic_binding')
        sessions = invocation['observed_session_ids']
        need(not sessions or invocation['new_session_observed'] is True, 'unproven_new_session_quarantine')
        if freeze['mode'] == 'official_cli' and sessions:
            need(p.read_json(retained['session-evidence.json'])['creation']['source'] == 'official_local_session_row',
                 'fixture_session_cannot_become_production')
        need(freeze['mode'] in ('official_cli', 'fixture_only', 'handwritten_registry_test', 'mock_only'), 'unsupported_mode')
        self._records[claim['claim_id']] = {'claim': copy.deepcopy(claim), 'invocation': invocation,
                                          'export': retained['export.json'], 'raw': retained['raw.txt']}

    def claim(self, session_id, claim_id, invocation_id):
        record = self._records.get(claim_id)
        need(record is not None, 'claim_not_committed')
        receipt = record['invocation']
        need(session_id is not None and receipt['actual_session_id'] == session_id
             and receipt['invocation_id'] == invocation_id, 'committed_session_claim_invocation_conflict')
        return {'session_id': session_id, 'claim_id': claim_id, 'invocation_id': invocation_id}

    def import_capture(self, claim_id, importer_class):
        """Import only retained bytes; no caller-supplied substitute artifact."""
        record = self._records.get(claim_id)
        need(record is not None, 'claim_not_committed')
        return importer_class(self).import_capture(record['export'], sha(record['export']),
            copy.deepcopy(record['claim']), copy.deepcopy(self._freeze), copy.deepcopy(record['invocation']))

    def raw(self, claim_id):
        need(claim_id in self._records, 'claim_not_committed')
        return bytes(self._records[claim_id]['raw'])


class OfflineFixtureSessionStore(CommittedSessionStore):
    """Offline unit tests only; fabricated tool shapes never prove durability."""
    @property
    def durable_external(self):
        return False
