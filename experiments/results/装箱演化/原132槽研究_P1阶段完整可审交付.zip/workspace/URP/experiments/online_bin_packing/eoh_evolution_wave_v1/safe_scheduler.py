"""Pinned pure scheduler with safe text extraction injected, NEVER host AST parsing."""
from copy import deepcopy
import json
from common import digest, require
from contracts import RESTRICTIONS
from dependencies import BASE, core, legacy


def public_contract():
    manifest = json.loads((BASE / 'numpy_candidate_contract_v1/api_manifest.json').read_text())
    keys = ('positional_min', 'positional_max', 'keywords', 'arguments', 'returns', 'max_output_elements')
    apis = {name: {key: entry[key] for key in keys} for name, entry in manifest['apis'].items()}
    return RESTRICTIONS + '\nPublic finite API contract:\n' + core.canonical({
        'limits': manifest['limits'], 'dtypes': manifest['dtypes'], 'apis': apis})


class SafeRunner(legacy.Runner):
    def __init__(self, panel, **kwargs):
        super().__init__(panel, **kwargs)
        self.public_contract = public_contract()

    def next_request(self):
        request = super().next_request()
        if request is None:
            return None
        slot = self._slot(request['id'])
        slot['prompt'][-1]['content'] += '\n\n' + self.public_contract
        slot['prompt_sha256'] = digest(slot['prompt'])
        # super already emitted the dispatch event; replace that unexported event
        # with the actual prompt before any claim or request leaves this method.
        event = self._events.pop()
        require(event['kind'] == 'dispatch' and event['payload']['id'] == request['id'], 'dispatch_event')
        payload = event['payload']
        payload.update(prompt=deepcopy(slot['prompt']), prompt_sha256=slot['prompt_sha256'])
        self._event('dispatch', payload)
        return deepcopy(slot)

    def observe(self, *args, **kwargs):
        raise RuntimeError('unsafe legacy observe disabled; use observe_verified')

    def observe_verified(self, slot_id, capture, extraction, scores, admission, integrity_error=None):
        """Called only after receiver and bounded-admission receipts are verified.

        Admission rejection receives candidate=None. Even malformed/failed source
        never reaches core.parse_capture or core.identity. No candidate AST is
        parsed here, including successful sources.
        """
        slot = self._slot(slot_id)
        require(slot['state'] == 'dispatched', 'observation_requires_unique_dispatch')
        capture, extraction, scores = deepcopy(capture), deepcopy(extraction), deepcopy(scores)
        self._event('observe', {'id': slot_id, 'capture': capture, 'extraction': extraction,
                               'verified_scores': scores, 'admission': admission,
                               'integrity_error': integrity_error})
        slot['capture'] = capture
        slot['observed'] = capture.get('usage')
        slot['physical_http_attempts'] = capture.get('physical_http_attempts')
        slot['extraction'] = {k: v for k, v in extraction.items() if k != 'candidate'}
        slot['admission'] = deepcopy(admission)
        if integrity_error:
            slot.update(state='integrity_failed', reason=integrity_error)
            for row in self._score_rows(slot_id):
                row['reason'] = 'integrity_failure'
            self._halt('integrity_error:' + integrity_error)
            return
        if not extraction['unique']:
            require(not scores, 'scores_for_unadmitted_response')
            slot.update(state='generation_failed', reason=extraction['reason'])
            for row in self._score_rows(slot_id):
                row['reason'] = 'generation_' + str(extraction['reason'])
            self._advance()
            return
        candidate = extraction['candidate']
        candidate.update(id=slot_id, arm=slot['arm'], phase=slot['phase'], order=slot['order'],
            tie_priority=slot['tie_priority'], eligible=False, fitness=None, report_gap=None,
            parents=list(slot['parents']), joint_duplicate_of=None, code_duplicate_of=None,
            initial_lineages=([slot_id] if slot['phase'] == 0 or slot['arm'] == 'IID_TC' else
                sorted({x for p in slot['parents'] for x in self._archive[p]['initial_lineages']})))
        self._archive[slot_id] = candidate
        try:
            self._ingest_scores(candidate, scores)
        except (ValueError, TypeError, KeyError) as exc:
            slot.update(state='integrity_failed', reason=str(exc))
            for row in self._score_rows(slot_id):
                if row['state'] == 'not_run' and row['evidence'] is None:
                    row['reason'] = 'integrity_failure'
            self._halt('integrity_error:' + str(exc))
            return
        rows = self._score_rows(slot_id)
        if all(row['state'] == 'verified' for row in rows):
            candidate['fitness'], candidate['report_gap'] = core.metrics(rows)
            candidate['eligible'] = True
            slot.update(state='eligible', reason=None)
        else:
            slot.update(state='evaluation_failed', reason='incomplete_or_failed_design_panel')
        self._refresh_duplicates()
        self._advance()

    def export(self):
        result = super().export()
        result.pop('sha256')
        result.update(schema='safe-wave-scheduler-ledger-v1',
                      safe_extraction='no host AST; bounded callback supplies canonical text',
                      public_contract_sha256=digest(self.public_contract))
        result['sha256'] = digest(result)
        return result
