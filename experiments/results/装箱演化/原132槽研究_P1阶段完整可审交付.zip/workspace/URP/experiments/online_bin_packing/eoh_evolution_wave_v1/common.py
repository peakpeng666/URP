"""Bounded data helpers. No candidate parsing, compilation or execution."""
import base64
import hashlib
import json
import math

MAX_SOURCE = 16384
MAX_RAW = 262144
MAX_EXPORT = 524288
MAX_AST_TEXT = 262144
MAX_RECEIPT = 1048576


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def digest(value):
    return sha(canonical(value).encode('utf-8'))


def is_hash(value):
    return type(value) is str and len(value) == 64 and set(value) <= set('0123456789abcdef')


def require(test, reason):
    if not test:
        raise ValueError(reason)


def strict_json(raw, cap=MAX_EXPORT):
    require(type(raw) is bytes and 0 < len(raw) <= cap, 'export_byte_bound')
    text = raw.decode('utf-8', errors='strict')
    depth, quoted, escaped = 0, False, False
    for char in text:
        if quoted:
            if escaped:
                escaped = False
            elif char == '\\':
                escaped = True
            elif char == '"':
                quoted = False
        elif char == '"':
            quoted = True
        elif char in '[{':
            depth += 1
            require(depth <= 16, 'export_json_depth')
        elif char in ']}':
            depth -= 1
            require(depth >= 0, 'export_json_balance')
    require(depth == 0 and not quoted, 'export_json_incomplete')

    def pairs(entries):
        out = {}
        for key, value in entries:
            require(key not in out, 'duplicate_json_key')
            out[key] = value
        return out

    def integer(value):
        require(len(value) <= 20, 'json_integer_bound')
        return int(value)

    def constant(_):
        raise ValueError('nonfinite_json')

    obj = json.loads(text, object_pairs_hook=pairs, parse_int=integer, parse_constant=constant)
    # Also rejects overflowed floats such as 1e999.
    canonical(obj)
    return obj


def decode_bytes(value, cap):
    require(type(value) is str and value.isascii() and len(value) <= 4*((cap+2)//3), 'base64_bound')
    raw = base64.b64decode(value, validate=True)
    require(len(raw) <= cap and base64.b64encode(raw).decode() == value, 'base64_canonical')
    return raw


def seal(value):
    value = dict(value)
    value['sha256'] = digest(value)
    return value


def verify_seal(value):
    require(type(value) is dict, 'sealed_record_type')
    obj = dict(value)
    expected = obj.pop('sha256', None)
    require(is_hash(expected) and digest(obj) == expected, 'sealed_record_hash')
    return obj


def bound_value(value, cap=MAX_RECEIPT):
    """Reject pathological callback data BEFORE canonicalization/deep copying."""
    stack, size, nodes = [(value, 0)], 0, 0
    seen = set()
    while stack:
        item, depth = stack.pop()
        nodes += 1
        require(nodes <= 50000 and depth <= 16, 'receipt_structure_bound')
        kind = type(item)
        if kind in (dict, list):
            require(id(item) not in seen, 'receipt_cycle_or_shared_container')
            seen.add(id(item))
            require(len(item) <= 50000, 'receipt_container_bound')
            if kind is dict:
                require(all(type(key) is str for key in item), 'receipt_key_type')
                stack.extend((part, depth+1) for pair in item.items() for part in pair)
            else:
                stack.extend((part, depth+1) for part in item)
            size += 2 + 2*len(item)
        elif kind is str:
            require(len(item) <= cap, 'receipt_text_bound')
            # Count JSON escaping, including up to six bytes per control char.
            size += len(canonical(item).encode('utf-8'))
        elif kind is int:
            require(item.bit_length() <= 128, 'receipt_integer_bound')
            size += len(str(item))
        elif kind is float:
            require(math.isfinite(item), 'receipt_nonfinite')
            size += 32
        else:
            require(item is None or kind is bool, 'receipt_value_type')
            size += 5
        require(size <= cap, 'receipt_byte_bound')
