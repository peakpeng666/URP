"""Auditable generation/selection state machine. No transport or execution adapter.

The caller supplies terminal provider captures and already verified score records.
This module only parses Python as data, computes rational numbers, and writes JSON.
"""
from copy import deepcopy
from pathlib import Path
import json
from core import (ARMS, assemble_prompt, digest, draw_parents, metrics,
                  parse_capture, select, tie_priority)

ROOT = Path(__file__).resolve().parent
TERMINAL = {'eligible', 'generation_failed', 'evaluation_failed', 'integrity_failed', 'not_run'}


class Runner:
    def __init__(self, panel, *, logical_budget=132, completion_budget=4224000,
                 generation_wall_budget=119400, finalization_wall_reserve=600):
        self._spec = json.loads((ROOT / 'scheduler_spec.json').read_text())
        self._slots = json.loads((ROOT / 'generation_slots.json').read_text())['records']
        self._scores = json.loads((ROOT / 'score_slots.json').read_text())['records']
        if len(self._slots) != 132 or len(self._scores) != 780:
            raise ValueError('fixed ledger shape changed')
        if panel.get('kind') not in ('mock', 'externally_verified') or len(panel.get('instances', [])) != 5:
            raise ValueError('a trusted five-instance mock or externally_verified panel is required')
        for i, instance in enumerate(panel['instances']):
            if (instance.get('instance_index') != i or type(instance.get('L1')) is not int
                    or not 0 < instance['L1'] <= instance.get('n', 0)
                    or type(instance.get('capacity')) is not int or instance['capacity'] <= 0
                    or not self._is_hash(instance.get('input_sha256'))):
                raise ValueError('invalid ordered panel instance')
        values = (logical_budget, completion_budget, generation_wall_budget, finalization_wall_reserve)
        if any(type(x) is not int or x < 0 for x in values) or logical_budget > 132:
            raise ValueError('budget must be nonnegative integers, at most 132 logical requests')
        self._panel = deepcopy(panel)
        self._budget = dict(zip(('logical_requests', 'completion_tokens', 'generation_wall_seconds',
                                 'finalization_wall_reserve'), values))
        self._reserved = {'logical_requests': 0, 'completion_tokens': 0, 'generation_wall_seconds': 0}
        self._archive, self._snapshots, self._events = {}, [], []
        self._phase, self._halt_reason = 0, None
        for s in self._slots:
            s.update(state='planned', reason=None, tie_priority=tie_priority(self._spec['seeds']['ties'], s['id']),
                     capture=None, extraction=None, parent_draw=None, parent_snapshot_sha256=None,
                     parent_provenance=[], prompt=None, configured=None, observed=None,
                     physical_http_attempts=None)
        for row in self._scores:
            row.update(state='not_run', reason='awaiting_candidate' if row['policy'] == 'candidate'
                       else 'out_of_scope_no_execution_adapter', used_bins=None, L1=None,
                       evidence=None, no_cross_slot_cache=True)
        self._event('init', {'panel': self._panel, 'budget': self._budget,
                            'spec_sha256': digest(self._spec),
                            'generation_plan_sha256': digest(self._slots),
                            'score_plan_sha256': digest(self._scores)})

    @staticmethod
    def _is_hash(value):
        return isinstance(value, str) and len(value) == 64 and all(c in '0123456789abcdef' for c in value)

    def _event(self, kind, payload):
        event = {'index': len(self._events), 'kind': kind, 'payload': deepcopy(payload),
                 'previous_sha256': self._events[-1]['sha256'] if self._events else None}
        event['sha256'] = digest(event)
        self._events.append(event)

    def _slot(self, slot_id):
        return next(s for s in self._slots if s['id'] == slot_id)

    def _score_rows(self, slot_id):
        return [r for r in self._scores if r['source_generation_slot'] == slot_id]

    def _population(self, phase, arm='EOH_TC'):
        snap = next(s for s in self._snapshots if s['phase'] == phase and s['arm'] == arm)
        return [self._archive[i] for i in snap['survivor_ids']], snap

    def _advance(self):
        while self._phase <= 2:
            stage = [s for s in self._slots if s['phase'] == self._phase]
            if any(s['state'] not in TERMINAL for s in stage):
                return
            for arm in ARMS:
                stage_slots = [s for s in stage if s['arm'] == arm]
                offspring = [self._archive[s['id']] for s in stage_slots if s['state'] == 'eligible']
                if arm == 'EOH_TC':
                    old = self._population(self._phase - 1)[0] if self._phase else []
                    pool = old + offspring
                    capacity = 6
                else:
                    pool = [c for c in self._archive.values() if c['arm'] == arm and c['eligible']]
                    capacity = 1
                survivors, decisions = select(pool, capacity)
                snap = {'name': f'P{self._phase}', 'arm': arm, 'phase': self._phase,
                        'survivor_ids': [c['id'] for c in survivors],
                        'members': [{k: deepcopy(c[k]) for k in ('id', 'pair_sha256', 'code_identity',
                                     'joint_identity', 'fitness', 'report_gap', 'tie_priority',
                                     'initial_lineages')} for c in survivors],
                        'decisions': decisions,
                        'failed_offspring': [{'id': s['id'], 'state': s['state'], 'reason': s['reason']}
                                             for s in stage_slots if s['state'] != 'eligible'],
                        'population_size': len(survivors),
                        'underfilled': len(survivors) < capacity,
                        'distinct_code_count': len({c['code_identity'] for c in survivors}),
                        'behavior_diversity': 'unknown_without_assignment_evidence',
                        'active_initial_lineages': sorted({x for c in survivors for x in c['initial_lineages']})}
                snap['sha256'] = digest(snap)
                self._snapshots.append(snap)
            self._phase += 1

    def _not_run(self, slot, reason):
        slot.update(state='not_run', reason=reason)
        for row in self._score_rows(slot['id']):
            row.update(reason=reason)

    def _halt(self, reason):
        if self._halt_reason is None:
            self._halt_reason = reason
            self._event('halt', {'reason': reason})
        for s in self._slots:
            if s['state'] == 'planned':
                self._not_run(s, reason)
        self._advance()

    def next_request(self):
        """Reserve and return the next planned request; never contacts a provider.

        Returns None when waiting for in-flight records or all slots are terminal.
        A returned request consumes one logical observation slot even on failure.
        Repeated calls advance to different planned slots; there is no retry method.
        """
        self._advance()
        if self._halt_reason or self._phase > 2:
            return None
        while True:
            slot = next((s for s in self._slots if s['phase'] == self._phase and s['state'] == 'planned'), None)
            if slot is None:
                return None
            parents, snap, draws = [], None, None
            if slot['parent_draws']:
                pop, snap = self._population(self._phase - 1)
                if not pop:
                    self._not_run(slot, 'parent_unavailable')
                    self._event('skip', {'id': slot['id'], 'reason': 'parent_unavailable'})
                    self._advance()
                    if self._phase > 2:
                        return None
                    continue
                draws = draw_parents(pop, slot['parent_draws'], self._spec['seeds']['parents'], slot['id'])
                parents = [self._archive[i] for i in draws['ids']]
            caps = self._spec['generation_config_proposal']
            needed = {'logical_requests': 1, 'completion_tokens': caps['max_completion_tokens'],
                      'generation_wall_seconds': caps['wall_seconds']}
            if any(self._reserved[k] + v + (self._budget['finalization_wall_reserve']
                   if k == 'generation_wall_seconds' else 0) > self._budget[k] for k, v in needed.items()):
                self._halt('budget_exhausted_before_full_request_reservation')
                return None
            for k, v in needed.items():
                self._reserved[k] += v
            prompt = assemble_prompt(slot['operator'], parents)
            slot.update(state='dispatched', logical_requests_observed=1, prompt=prompt,
                        prompt_sha256=digest(prompt), parent_draw=draws,
                        parents=[p['id'] for p in parents],
                        parent_snapshot_sha256=snap['sha256'] if snap else None,
                        parent_provenance=[{k: deepcopy(p[k]) for k in
                                           ('id', 'pair_sha256', 'description_sha256', 'code_sha256', 'fitness')}
                                           for p in parents],
                        configured=deepcopy(caps))
            self._event('dispatch', {k: deepcopy(slot[k]) for k in ('id', 'prompt', 'prompt_sha256',
                        'parent_draw', 'parents', 'parent_snapshot_sha256', 'parent_provenance', 'configured')})
            return deepcopy(slot)

    def observe(self, slot_id, capture, verified_scores=()):
        """Record one terminal capture and five independently verified observations.

        score rows are data from an external trusted verifier, NOT proof created here.
        Receipt kind must match the caller-supplied panel kind; authenticity is
        not established here. No source is evaluated by this function.
        Infrastructure-integrity failures terminate dispatch, while ordinary candidate
        and numerical failures consume their slot and permit the planned continuation.
        """
        slot = self._slot(slot_id)
        if slot['state'] != 'dispatched':
            raise ValueError('only one observation per dispatched slot; no implicit retries')
        if not isinstance(verified_scores, (list, tuple)):
            raise ValueError('verified_scores must be a list or tuple; no observation committed')
        capture, scores = deepcopy(capture), deepcopy(list(verified_scores))
        if not isinstance(capture, dict):
            capture = {'status': 'invalid_capture_record', 'raw': '', 'supplied_payload': capture}
        self._event('observe', {'id': slot_id, 'capture': capture, 'verified_scores': scores})
        slot['capture'] = capture
        slot['observed'] = deepcopy(capture.get('usage', {'input_tokens': None, 'output_tokens': None,
                                                       'reasoning_tokens': None, 'wall_seconds': None}))
        slot['physical_http_attempts'] = capture.get('physical_http_attempts')
        extraction = parse_capture(capture)
        slot['extraction'] = {k: v for k, v in extraction.items() if k != 'candidate'}
        if not extraction['unique']:
            slot.update(state='generation_failed', reason=extraction['reason'])
            for row in self._score_rows(slot_id):
                row['reason'] = 'generation_' + str(extraction['reason'])
            if scores:
                slot.update(state='integrity_failed', reason='scores_for_unadmitted_response')
                self._halt('integrity_error:scores_for_unadmitted_response')
            self._advance()
            return
        candidate = extraction['candidate']
        candidate.update(id=slot_id, arm=slot['arm'], phase=slot['phase'], order=slot['order'],
                         tie_priority=slot['tie_priority'], eligible=False, fitness=None, report_gap=None,
                         parents=list(slot['parents']), joint_duplicate_of=None, code_duplicate_of=None,
                         initial_lineages=([slot_id] if slot['phase'] == 0 or slot['arm'] == 'IID_TC' else
                            sorted({x for p in slot['parents'] for x in self._archive[p]['initial_lineages']})))
        self._archive[slot_id] = candidate
        try:
            self._ingest_scores(candidate, scores)
        except (ValueError, TypeError, KeyError) as exc:
            slot.update(state='integrity_failed', reason=str(exc))
            for row in self._score_rows(slot_id):
                if row['state'] == 'not_run' and row['evidence'] is None:
                    row['reason'] = 'integrity_failure'
            self._halt('integrity_error:' + str(exc))
            return
        rows = self._score_rows(slot_id)
        if all(r['state'] == 'verified' for r in rows):
            candidate['fitness'], candidate['report_gap'] = metrics(rows)
            candidate['eligible'] = True
            slot.update(state='eligible', reason=None)
        else:
            slot.update(state='evaluation_failed', reason='incomplete_or_failed_design_panel')
        self._refresh_duplicates()
        self._advance()

    def _ingest_scores(self, candidate, observations):
        if any(not isinstance(r, dict) for r in observations):
            raise ValueError('invalid_score_record')
        ids = [r.get('instance_index') for r in observations]
        if any(type(i) is not int or not 0 <= i < 5 for i in ids) or len(ids) != len(set(ids)):
            raise ValueError('duplicate_or_invalid_instance_index')
        for obs in observations:
            i = obs['instance_index']
            manifest = self._panel['instances'][i]
            if obs.get('kind') != self._panel['kind']:
                raise ValueError('score_provenance_kind_mismatch')
            if obs.get('code_sha256') != candidate['code_sha256']:
                raise ValueError('candidate_code_hash_mismatch')
            if (obs.get('input_sha256') != manifest['input_sha256']
                    or type(obs.get('L1')) is not int or obs.get('L1') != manifest['L1']):
                raise ValueError('panel_hash_or_lower_bound_mismatch')
            evidence = obs.get('evidence', {})
            if not isinstance(evidence, dict):
                raise ValueError('invalid_score_evidence')
            for key in ('runtime_sha256', 'isolation_profile_sha256', 'checker_sha256'):
                if not self._is_hash(evidence.get(key)):
                    raise ValueError('missing_' + key)
            if evidence.get('cleanup_status') != 'passed':
                raise ValueError('cleanup_integrity_failure')
            if obs.get('outcome') == 'ok':
                if (evidence.get('checker_status') != 'passed'
                        or not self._is_hash(evidence.get('assignment_sha256'))):
                    raise ValueError('checker_integrity_failure')
                bins = obs.get('used_bins')
                if type(bins) is not int or not manifest['L1'] <= bins <= manifest['n']:
                    raise ValueError('invalid_verified_bin_count')
            elif obs.get('outcome') in ('numeric_failure', 'infeasible', 'timeout', 'resource_limit',
                                       'exception', 'prohibited_capability', 'not_run'):
                if obs.get('used_bins') is not None:
                    raise ValueError('invented_bins_for_failed_observation')
            else:
                raise ValueError('unknown_score_outcome')
            row = self._score_rows(candidate['id'])[i]
            row.update(state='verified' if obs['outcome'] == 'ok' else 'not_run' if obs['outcome'] == 'not_run' else 'failed',
                       reason=None if obs['outcome'] == 'ok' else obs['outcome'],
                       used_bins=obs.get('used_bins'), L1=obs['L1'], code_hash=candidate['code_sha256'],
                       runtime_hash=evidence['runtime_sha256'], evidence=deepcopy(obs))
        for row in self._score_rows(candidate['id']):
            if row['state'] == 'not_run' and row['evidence'] is None:
                row['reason'] = 'missing_verified_observation'

    def _refresh_duplicates(self):
        seen_joint, seen_code = {}, {}
        for c in sorted(self._archive.values(), key=lambda c: c['order']):
            joint, code = (c['arm'], c['joint_identity']), (c['arm'], c['code_identity'])
            c['joint_duplicate_of'] = seen_joint.get(joint)
            c['code_duplicate_of'] = seen_code.get(code)
            seen_joint.setdefault(joint, c['id'])
            seen_code.setdefault(code, c['id'])

    @property
    def done(self):
        return all(s['state'] in TERMINAL for s in self._slots)

    def export(self):
        """Independent copies prevent consumer mutations changing sealed snapshots."""
        self._refresh_duplicates()
        summary = {'planned_generation_slots': 132, 'planned_scoring_rows': 780,
                   'actual_provider_calls': 0, 'candidate_executions': 0,
                   'scheduler_request_records': sum(s['logical_requests_observed'] for s in self._slots),
                   'generation_counts_by_arm': {a: sum(s['logical_requests_observed'] for s in self._slots
                                                      if s['arm'] == a) for a in ARMS},
                   'not_run_generation_slots': sum(s['state'] == 'not_run' for s in self._slots),
                   'verified_score_records': sum(r['state'] == 'verified' for r in self._scores),
                   'remaining_generation_slots': [s['id'] for s in self._slots if s['state'] not in TERMINAL],
                   'terminal': self.done, 'halt_reason': self._halt_reason,
                   'equal_full_66_request_records': all(sum(s['logical_requests_observed'] for s in self._slots
                                           if s['arm'] == a) == 66 for a in ARMS),
                   'actual_tokens_equal': 'not_claimed', 'physical_http_attempts': None,
                   'actual_g1_to_g2_parent_ids': sorted({p for s in self._slots if s['arm'] == 'EOH_TC'
                            and s['phase'] == 2 for p in s['parents'] if self._archive[p]['phase'] == 1}),
                   'winners': {a: next((s['survivor_ids'][0] if s['survivor_ids'] else None
                                   for s in self._snapshots if s['phase'] == 2 and s['arm'] == a), None)
                               for a in ARMS}}
        result = {'schema': 'eoh-scheduler-ledger-v1',
                  'mode': 'mock_only' if self._panel['kind'] == 'mock' else 'external_records_only',
                  'native_execution_ready': False, 'spec': self._spec, 'panel': self._panel,
                  'budget': self._budget, 'reserved': self._reserved,
                  'generation': self._slots, 'scores': self._scores,
                  'archive': sorted(self._archive.values(), key=lambda c: c['order']),
                  'snapshots': self._snapshots, 'events': self._events, 'summary': summary}
        result = deepcopy(result)
        result['sha256'] = digest(result)
        return result

    def save(self, path):
        Path(path).write_text(json.dumps(self.export(), ensure_ascii=False, indent=2, allow_nan=False) + '\n')
