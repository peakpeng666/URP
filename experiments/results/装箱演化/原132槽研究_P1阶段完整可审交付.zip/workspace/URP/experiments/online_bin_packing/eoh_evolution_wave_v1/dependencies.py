"""Load only explicit, hash-pinned pure scheduler modules; never inspect data."""
import importlib.util
import json
from pathlib import Path
import sys
from common import require, sha

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent


def verify_dependencies():
    lock = json.loads((ROOT / 'dependency_lock.json').read_text())
    for name, expected in lock.items():
        require(name.count('/') == 1 and '..' not in name, 'dependency_path')
        require(sha((BASE / name).read_bytes()) == expected, 'dependency_hash:' + name)
    return lock


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


verify_dependencies()
core = load('_wave_pinned_core', BASE / 'eoh_evolution_runner_v1/core.py')
old_core = sys.modules.get('core')
try:
    sys.modules['core'] = core
    legacy = load('_wave_pinned_runner', BASE / 'eoh_evolution_runner_v1/runner.py')
finally:
    if old_core is None:
        sys.modules.pop('core', None)
    else:
        sys.modules['core'] = old_core
