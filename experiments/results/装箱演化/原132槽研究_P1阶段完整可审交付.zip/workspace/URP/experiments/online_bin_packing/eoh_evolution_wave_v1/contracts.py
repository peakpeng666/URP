"""Same public restrictions for both arms. Seal metadata never enters prompts."""
from common import digest, seal

CONFIRMATION_SEAL = {
    'data_sha256': 'ebe12cd8274ccb4db39d553b68c69efea75038bd7edea936972b2c26e351a992',
    'bytes': 302509, 'instances': 20, 'items_per_instance': 5000, 'capacity': 100,
    'provenance': 'literal parent-supplied hash-only replacement seal; data never read here',
}

RESTRICTIONS = '''Restricted numerical Python/NumPy two-generation mechanism pilot.
Use the same restricted language in every request. Implement exactly one undecorated,
unannotated def score(item, bins), with no imports or top-level statements.
The host provides np as an immutable finite numerical facade, not a Python module.
item is np.int64 and bins is a copied read-only np.int64 one-dimensional array.
Source must be UTF-8 and at most 16384 bytes. Local scalar/name assignment, bounded
numeric expressions, if/else, read-only indexing, bounded loops and numerical
vectors are allowed under the frozen contract. No array/attribute writes, object
methods, dynamic calls, introspection, imports, I/O, recursion or comprehensions.
Return a finite exact one-dimensional ndarray of int32, int64 or float64 scores.
No hidden reasoning, tools, tests, extra explanations or repairs will be requested.
Return exactly {one public algorithm description} followed by one complete
```python code block. The block's exact bytes are the submitted source.'''

# All 46 API entries are declared by the unchanged finite-contract manifest.
# Builder includes their exact public names/signatures via an explicit safe projection.


def generation_config():
    return {'model': 'glm-5.3', 'effort': 'high', 'temperature': 0.7, 'top_p': 0.9,
            'max_completion_tokens': 32000, 'wall_seconds': 900, 'steps': 2,
            'tools': False, 'outer_retries': 0, 'paid_provider_fallback': False}


def mock_freeze():
    return seal({'schema': 'wave-freeze-v1', 'mode': 'mock_only',
                 'target': 'restricted numerical Python/NumPy two-generation mechanism pilot',
                 'runtime_sha256': digest('MOCK_RUNTIME_NOT_EXECUTED'),
                 'isolation_profile_sha256': digest('MOCK_ISOLATION_NOT_CERTIFIED'),
                 'checker_sha256': digest('MOCK_CHECKER_NOT_EXECUTED'),
                 'intake_manifest_sha256': digest('MOCK_INTAKE_NOT_AUTHORIZED'),
                 'cli_binary_sha256': digest('MOCK_CLI_NOT_RUN'),
                 'cli_source_sha256': digest('MOCK_EXPORTER_NOT_IMPLEMENTED'),
                 'cli_version': 'mock-no-official-cli-invocation',
                 'configuration': generation_config(),
                 'confirmation_seal': CONFIRMATION_SEAL,
                 'live_launch_ready': False})
