"""Synthetic entrypoint failure/repeat test. Never dispatches any command."""
import hashlib
import importlib.util
import json
from pathlib import Path
import signal
import sys
import tempfile

METER = Path(__file__).resolve().parent.parent / "original132_phase1_coordination_20261006/meter.py"
spec = importlib.util.spec_from_file_location("meter_entrypoint_test", METER)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
calls = 0
def source_check_failure(grant):
    global calls
    calls += 1
    raise RuntimeError("trusted synthetic source verification failure")
m.fixed_commands = source_check_failure
with tempfile.TemporaryDirectory(prefix="phase1-entrypoint-audit-") as td:
    root = Path(td)
    m.LOG = root / "synthetic_logs"
    grant = root / "synthetic_test_grant.json"
    grant.write_text(json.dumps({"schema":"phase1-forward-coordination-grant-v1", "enabled":True, "parent_review_accepted":True, "meter_sha256":hashlib.sha256(METER.read_bytes()).hexdigest(), "action":"prepare", "inclusive_wall_seconds":120, "trusted_cpu_allowance_seconds":120, "test_only":True}))
    sys.argv = [str(METER), "--grant", str(grant), "--grant-sha256", hashlib.sha256(grant.read_bytes()).hexdigest()]
    try:
        m.main()
        raise AssertionError("source failure ignored")
    except RuntimeError as exc:
        assert str(exc) == "trusted synthetic source verification failure"
    assert (m.LOG / "prepare.attempt.json").is_file()
    assert not (m.LOG / "prepare.receipt.json").exists()
    try:
        m.main()
        raise AssertionError("retry accepted")
    except FileExistsError:
        pass
    assert calls == 1
    signal.setitimer(signal.ITIMER_REAL, 0)
    result = {"status":"passed", "test":"valid synthetic grant writes permanent attempt before source validation; second invocation rejected before validation", "fixed_command_verification_calls":calls, "meter_sha256":hashlib.sha256(METER.read_bytes()).hexdigest(), "dispatched_processes":0, "candidate_executions":0}
    Path(__file__).with_name("ENTRYPOINT_TEST.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))
