"""Trusted synthetic process-tree fixtures; never imports study or candidates."""
import ctypes
import json
import os
import resource
import signal
import sys
import time


def burn(seconds):
    until = time.process_time() + seconds
    while time.process_time() < until:
        pass


def guard(parent):
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.prctl(1, signal.SIGKILL, 0, 0, 0) != 0 or os.getppid() != parent:
        raise RuntimeError("parent guard")


mode = sys.argv[1]
if mode == "success":
    pid = os.fork()
    if pid == 0:
        burn(0.06)
        os._exit(0)
    os.waitpid(pid, 0)
    burn(0.04)
    print(json.dumps({"kind": "trusted_dummy", "ok": True}), flush=True)
elif mode == "orphan":
    pid = os.fork()
    if pid == 0:
        os.setsid()
        burn(0.08)
        os._exit(0)
    print(json.dumps({"kind": "trusted_dummy", "orphan_pid": pid}), flush=True)
    os._exit(0)
elif mode == "detached_wait":
    parent = os.getpid()
    pid = os.fork()
    if pid == 0:
        os.setsid()
        guard(parent)
        child_parent = os.getpid()
        child = os.fork()
        if child == 0:
            os.setsid()
            guard(child_parent)
            time.sleep(60)
            os._exit(0)
        print(json.dumps({"kind": "trusted_dummy", "pid": os.getpid(), "child": child}), flush=True)
        time.sleep(60)
        os._exit(0)
    time.sleep(60)
elif mode == "limits":
    print(json.dumps({"kind": "trusted_dummy", "limits": resource.getrlimit(resource.RLIMIT_CPU)}), flush=True)
elif mode == "cpu":
    burn(10)
elif mode == "failure":
    raise SystemExit(17)
else:
    raise SystemExit("unknown fixture")
