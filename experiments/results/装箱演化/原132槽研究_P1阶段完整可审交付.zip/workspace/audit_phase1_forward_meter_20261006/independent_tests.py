"""Independent trusted dummy checks only. No study/candidate imports or launch."""
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parent.parent
METER = ROOT / "original132_phase1_coordination_20261006/meter.py"
DUMMY = Path(__file__).resolve().parent / "trusted_dummy.py"
spec = importlib.util.spec_from_file_location("forward_meter_audit", METER)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
results = {}
sha_before = m.sha(METER.read_bytes())
with tempfile.TemporaryDirectory(prefix="phase1-meter-audit-", dir="/tmp") as td:
    logs = Path(td)
    for mode in ("success", "orphan", "detached_wait", "limits", "cpu", "failure"):
        command = ["/usr/bin/prlimit", "--cpu=1:1", "--", sys.executable, "-I", "-B", str(DUMMY), mode]
        s = m.supervise(command, logs, mode, m.clock() + (5 if mode == "cpu" else 3))
        s["stdout"] = Path(s["stdout_path"]).read_text()
        assert s["all_meter_children_reaped"], (mode, s)
        assert not m.child_pids(os.getpid()), (mode, s)
        assert s["direct_child_reaped"], (mode, s)
        if mode in ("success", "limits"):
            assert s["returncode"] == 0 and not s["forced_shutdown"] and not s["timed_out"], (mode, s)
        if mode == "success":
            assert 0.10 <= s["wait4_inclusive_cpu_seconds"] < 0.8, s
            assert len(s["reap_records"]) == 1, s
        if mode == "orphan":
            assert s["adopted_descendants_reaped"] == 1, s
        if mode == "detached_wait":
            assert s["timed_out"] and s["forced_shutdown"] and s["adopted_descendants_reaped"] == 2, s
            assert s["within_absolute_deadline"], s
        if mode == "limits":
            assert json.loads(s["stdout"])["limits"] == [1, 1], s
        if mode == "cpu":
            assert s["returncode"] == -9 and not s["timed_out"], s
            assert 0.9 < s["wait4_inclusive_cpu_seconds"] < 1.2, s
        if mode == "failure":
            assert s["returncode"] == 17, s
        results[mode] = s
    existing = logs / "already.claim.json"
    m.exclusive(existing, b"first")
    try:
        m.exclusive(existing, b"second")
        raise AssertionError("duplicate claim accepted")
    except FileExistsError:
        pass
    link = logs / "symlink.json"
    link.symlink_to(existing)
    try:
        m.read(link)
        raise AssertionError("symlink accepted")
    except ValueError:
        pass
    assert existing.read_bytes() == b"first"
    results["exclusive_and_symlink"] = "passed"
    original_wait4 = m.os.wait4
    faulted = False
    def fail_once(*args):
        global faulted
        if not faulted:
            faulted = True
            raise OSError("trusted injected wait failure")
        return original_wait4(*args)
    try:
        m.os.wait4 = fail_once
        s = m.supervise([sys.executable, "-I", "-B", str(DUMMY), "detached_wait"], logs, "wait_failure", m.clock() + 3)
    finally:
        m.os.wait4 = original_wait4
    assert faulted and s["forced_shutdown"] and s["all_meter_children_reaped"], s
    assert s["direct_child_reaped"] and s["error"], s
    assert not m.child_pids(os.getpid()), s
    results["injected_wait_failure_cleanup"] = s
sha_after = m.sha(METER.read_bytes())
result = {"status": "passed", "meter_sha256_before": sha_before, "meter_sha256_after": sha_after, "source_stable": sha_before == sha_after, "test_results": results, "candidate_executions": 0, "model_calls": 0}
Path(__file__).with_name("INDEPENDENT_TESTS.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({k:v for k,v in result.items() if k != "test_results"}))
