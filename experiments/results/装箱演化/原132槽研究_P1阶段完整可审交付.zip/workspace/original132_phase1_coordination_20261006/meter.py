"""Fixed-command forward accounting. Never changes the frozen scientific harness.

One exclusive claim for prepare (preflight + prepare), one for numeric run.
Abnormal/inconclusive execution is UNKNOWN and cannot be retried here.
"""
import argparse,ctypes,hashlib,json,math,os,pathlib,resource,signal,subprocess,sys,time
ROOT=pathlib.Path(__file__).resolve().parent.parent
HERE=pathlib.Path(__file__).resolve().parent
LOG=ROOT/'original132_phase1_forward_accounting_20261006'
STATE=ROOT/'urp132_20261005_b01_phase1_numerical_state'
HARNESS=ROOT/'original132_phase1_preparation_20261005/phase1_numerical.py'
PREFLIGHT=ROOT/'original132_phase1_evaluation_ready_20261006/preflight_handoff.py'
SCHEDULER=ROOT/'original132_phase1_preparation_20261005/scheduler_continuation.py'
HANDOFF=ROOT/'original132_phase1_authenticated_readback_20261006/phase1-authenticated-handoff.json'
APPROVAL=STATE/'parent_execution_approval.json'
PINS={str(HARNESS):'5a5e5974ab81fb7452ca50294b2ab07fcf9c1feda3134dcb79b2da209b2f2c14',str(PREFLIGHT):'c344f1e5de6d907a8409227decc3428409be5d57bcab48109a6331262e39cefc',str(SCHEDULER):'6c83ebb992d036b5be9a0df46b02ae4730b6b742387d86b01e376b166efb2ba8'}
HANDOFF_SHA='597571b0047adc9cfcc6e13f22e157b5fdd3ca362fe0b7e87d47479ceaca1a3c'
FREEZE=ROOT/'exporter_receiver_compatibility_20261005/runtime_revision_v3/worker_freeze.json'
FREEZE_SHA='7903fec4a38568000f7dc8901e49cfff6f246529129aacab2c94c179b1d1aeb8'

def need(ok,why):
    if not ok:raise ValueError(why)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def checked_path(p):
    p=pathlib.Path(p);need(p.is_absolute() and p.resolve()==p and not p.is_symlink(),'noncanonical/symlink path');return p
def read(p,expected=None):
    p=checked_path(p);need(p.is_file() and p.stat().st_size<=64*1024*1024,'bounded file required');raw=p.read_bytes();need(expected is None or sha(raw)==expected,'file pin mismatch');return json.loads(raw)
def fsync_dir(p):
    fd=os.open(str(p),os.O_RDONLY|os.O_DIRECTORY);os.fsync(fd);os.close(fd)
def exclusive(p,data):
    checked_path(p.parent);fd=os.open(str(p),os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    with os.fdopen(fd,'wb') as f:f.write(data);f.flush();os.fsync(f.fileno())
    fsync_dir(p.parent)
def clock():return time.clock_gettime(time.CLOCK_BOOTTIME)
def cpu_self():
    r=resource.getrusage(resource.RUSAGE_SELF);return r.ru_utime+r.ru_stime
def identity(pid):
    try:
        fields=pathlib.Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split();return int(fields[19])
    except (FileNotFoundError,ProcessLookupError):return None
def child_pids(pid):
    # This cloud runtime exposes /proc/<pid>/stat, not task/<pid>/children.
    result=[]
    for path in pathlib.Path('/proc').iterdir():
        if not path.name.isdigit():continue
        try:fields=(path/'stat').read_text().rsplit(')',1)[1].split()
        except (FileNotFoundError,ProcessLookupError):continue
        if int(fields[1])==pid:result.append(int(path.name))
    return result

def descendants(pid):
    found={};todo=[pid]
    while todo:
        for child in child_pids(todo.pop()):
            birth=identity(child)
            if birth is not None and child not in found:found[child]=birth;todo.append(child)
    return found

def supervise(command,logroot,label,deadline):
    """Subreaper wait4(root + disjoint adopted descendants); failures UNKNOWN."""
    start=clock();seen={};reaped=[];root_reaped=False;no_children=False;timed_out=False;shutdown=False;error=None;proc=None
    libc=ctypes.CDLL(None,use_errno=True)
    need(libc.prctl(36,1,0,0,0)==0,'subreaper unavailable')
    observed=ctypes.c_int();need(libc.prctl(37,ctypes.byref(observed),0,0,0)==0 and observed.value==1,'subreaper verification')
    need(not child_pids(os.getpid()),'meter already has child; refusing mixed accounting')
    parent=os.getpid()
    def parent_guard():
        if libc.prctl(1,signal.SIGKILL,0,0,0)!=0 or os.getppid()!=parent:os._exit(71)
        armed=ctypes.c_int()
        if libc.prctl(2,ctypes.byref(armed),0,0,0)!=0 or armed.value!=signal.SIGKILL:os._exit(72)
    def drain():
        nonlocal root_reaped,no_children,shutdown
        no_children=False
        while True:
            try:pid,status,usage=os.wait4(-1,os.WNOHANG)
            except ChildProcessError:no_children=True;break
            if not pid:break
            rc=os.waitstatus_to_exitcode(status)
            reaped.append({'pid':pid,'role':'root' if pid==proc.pid else 'adopted','returncode':rc,'user_cpu_seconds':usage.ru_utime,'system_cpu_seconds':usage.ru_stime,'inclusive_cpu_seconds':usage.ru_utime+usage.ru_stime})
            if pid==proc.pid:root_reaped=True;proc.returncode=rc
            else:shutdown=True
    def terminate():
        # Unreaped root PID cannot have been reused; groups include only this launch.
        if not root_reaped:
            try:os.killpg(proc.pid,signal.SIGKILL)
            except ProcessLookupError:pass
        try:seen.update(descendants(os.getpid()))
        except OSError:pass  # Still kill known births; cleanup completeness uses wait4 ECHILD.
        for child,original_birth in seen.items():
            try:
                if identity(child)==original_birth:os.kill(child,signal.SIGKILL)
            except (ProcessLookupError,FileNotFoundError):pass
    out=logroot/(label+'.stdout.log');err=logroot/(label+'.stderr.log');fds=[]
    try:
        for path in (out,err):fds.append(os.open(str(path),os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600))
        proc=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=fds[0],stderr=fds[1],cwd=str(ROOT),env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1'},close_fds=True,start_new_session=True,preexec_fn=parent_guard)
        while True:
            seen.update(descendants(os.getpid()));drain()
            if root_reaped and no_children:break
            now=clock()
            if now>=deadline-2 or root_reaped or shutdown:
                timed_out=timed_out or now>=deadline-2;shutdown=True;terminate()
            if now>=deadline:break
            time.sleep(min(.02,max(0.,deadline-now)))
    except BaseException as exc:
        error=type(exc).__name__+': '+str(exc);shutdown=True
    finally:
        if proc is not None and not (root_reaped and no_children):
            shutdown=True
            cleanup_end=min(deadline,clock()+2)
            while True:
                try:terminate();drain()
                except BaseException as exc:error=(error or '')+'; cleanup '+type(exc).__name__+': '+str(exc);break
                if root_reaped and no_children or clock()>=cleanup_end:break
                time.sleep(.01)
        for fd in fds:
            try:os.fsync(fd)
            except OSError as exc:error=(error or '')+'; log fsync '+str(exc);shutdown=True
            finally:os.close(fd)
        try:fsync_dir(logroot)
        except OSError as exc:error=(error or '')+'; directory fsync '+str(exc);shutdown=True
    end=clock();root=next((r for r in reaped if r['role']=='root'),None)
    return {'command':command,'pid':None if proc is None else proc.pid,'wall_seconds':end-start,'returncode':None if root is None else root['returncode'],'direct_child_reaped':root_reaped,'all_meter_children_reaped':no_children,'adopted_descendants_reaped':sum(r['role']=='adopted' for r in reaped),'reap_records':reaped,'timed_out':timed_out,'forced_shutdown':shutdown,'error':error,'within_absolute_deadline':end<=deadline,'wait4_user_cpu_seconds':sum(r['user_cpu_seconds'] for r in reaped),'wait4_system_cpu_seconds':sum(r['system_cpu_seconds'] for r in reaped),'wait4_inclusive_cpu_seconds':sum(r['inclusive_cpu_seconds'] for r in reaped),'observed_descendants':len(seen),'stdout_path':str(out),'stderr_path':str(err),'stdout_sha256':sha(out.read_bytes()) if out.exists() else None,'stderr_sha256':sha(err.read_bytes()) if err.exists() else None,'accounting_scope':'sum of disjoint wait4(root plus adopted orphans); complete only on ECHILD after root reap','parent_death_guard':True,'subreaper':True}

def fixed_commands(grant):
    action=grant['action'];python=str(pathlib.Path(sys.executable).resolve());prefix=['/usr/bin/prlimit']
    for path,expected in PINS.items():need(sha(checked_path(path).read_bytes())==expected,'fixed command source drift')
    runtime=read(FREEZE,FREEZE_SHA)
    for path in (python,'/usr/bin/prlimit'):
        real=str(pathlib.Path(path).resolve());need(real in runtime['dependencies'] and sha(pathlib.Path(real).read_bytes())==runtime['dependencies'][real],'interpreter/limiter drift')
    if action=='prepare':
        need(not STATE.exists() and not STATE.is_symlink(),'phase1 state already exists; no reset/retry')
        read(HANDOFF,HANDOFF_SHA);need(grant['handoff_file_sha256']==HANDOFF_SHA,'handoff scope')
        return 40,120,[('prepare.preflight',prefix+['--cpu=40:40','--',python,'-I','-B',str(PREFLIGHT),'--handoff',str(HANDOFF),'--handoff-sha256',HANDOFF_SHA]),('prepare.prepare',prefix+['--cpu=40:40','--',python,'-I','-B',str(HARNESS),'prepare','--handoff',str(HANDOFF),'--handoff-sha256',HANDOFF_SHA])]
    need(action=='run','unknown action')
    prep=read(LOG/'prepare.receipt.json');need(prep['status']=='completed' and prep['plan_file_sha256']==grant['plan_file_sha256'],'prepare receipt binding')
    plan=read(STATE/'plan.json',grant['plan_file_sha256']);read(APPROVAL,grant['approval_file_sha256'])
    need(plan['run_id']=='urp132_20261005_b01_phase1' and plan['denominator']==60 and 0<=plan['max_admissions']<=60 and plan['max_candidate_packs']==5*plan['max_admissions'],'plan bounds')
    wall=plan['max_admissions']*5+plan['max_candidate_packs']*90+900
    need(grant['inclusive_wall_seconds']==wall,'exact forward inclusive wall grant')
    return 300,wall,[('run',prefix+['--cpu=300:300','--',python,'-I','-B',str(HARNESS),'run','--plan-file-sha256',grant['plan_file_sha256'],'--approval',str(APPROVAL),'--approval-sha256',grant['approval_file_sha256']])]

def main():
    started=identity(os.getpid())/os.sysconf('SC_CLK_TCK');p=argparse.ArgumentParser();p.add_argument('--grant',required=True);p.add_argument('--grant-sha256',required=True);args=p.parse_args()
    grant=read(pathlib.Path(args.grant).absolute(),args.grant_sha256)
    need(grant['schema']=='phase1-forward-coordination-grant-v1' and grant['enabled'] is True and grant['parent_review_accepted'] is True,'explicit reviewed forward grant required')
    need(grant['meter_sha256']==sha(pathlib.Path(__file__).read_bytes()),'meter pin')
    action=grant['action'];need(action in ('prepare','run'),'action allowlist')
    # Installed before source verification/launch; cumulative CPU since startup.
    meter_cap=40 if action=='prepare' else 300;resource.setrlimit(resource.RLIMIT_CPU,(meter_cap,meter_cap))
    declared_wall=grant['inclusive_wall_seconds']
    need(type(declared_wall) is int and (declared_wall==120 if action=='prepare' else 900<=declared_wall<=28200),'bounded forward wall grant')
    # Kernel-default SIGALRM covers verification, subprocess waits, fsync and exit.
    # Poll cleanup starts two seconds sooner. If the meter blocks or misses cleanup,
    # this fatal alarm still kills it; PDEATHSIG kills the guarded harness chain.
    signal.signal(signal.SIGALRM,signal.SIG_DFL)
    signal.setitimer(signal.ITIMER_REAL,max(.001,started+declared_wall-clock()))
    checked_path(LOG)
    if not LOG.exists():LOG.mkdir(mode=0o700);fsync_dir(LOG.parent)
    need(LOG.is_dir() and not LOG.is_symlink(),'accounting directory')
    exclusive(LOG/(action+'.attempt.json'),canonical({'schema':'phase1-forward-once-only-attempt-v1','action':action,'grant_file_sha256':args.grant_sha256,'meter_sha256':grant['meter_sha256'],'retry_authorized':False})+b'\n')
    meter_limit,wall,commands=fixed_commands(grant);need(meter_limit==meter_cap,'meter cap agreement')
    need(grant['trusted_cpu_allowance_seconds']==(120 if action=='prepare' else 900) and grant['inclusive_wall_seconds']==wall,'forward allowance agreement')
    checked_path(LOG)
    if not LOG.exists():LOG.mkdir(mode=0o700);fsync_dir(LOG.parent)
    need(LOG.is_dir() and not LOG.is_symlink(),'accounting directory')
    claim={'schema':'phase1-forward-exclusive-claim-v1','action':action,'grant_file_sha256':args.grant_sha256,'meter_sha256':grant['meter_sha256'],'commands':commands,'trusted_cpu_allowance_seconds':grant['trusted_cpu_allowance_seconds'],'inclusive_wall_seconds':wall,'historical_shared_balance':None,'retry_authorized':False}
    exclusive(LOG/(action+'.claim.json'),canonical(claim)+b'\n')
    deadline=started+wall;steps=[];result={**claim,'schema':'phase1-forward-accounting-receipt-v1','steps':steps,'status':'unknown','numeric_execution_authorized_by_this_receipt':False}
    try:
        for label,command in commands:
            need(clock()<deadline-2,'insufficient remaining inclusive wall')
            step=supervise(command,LOG,label,deadline);steps.append(step)
            exclusive(LOG/(label+'.step.json'),canonical(step)+b'\n')
            need(step['direct_child_reaped'] and step['returncode']==0 and not step['timed_out'] and not step['forced_shutdown'] and step['all_meter_children_reaped'] and step['within_absolute_deadline'],'nonclean/unknown child; no retry')
        if action=='prepare':
            result['plan_file_sha256']=sha((STATE/'plan.json').read_bytes());result['plan_sha256']=read(STATE/'plan.json')['sha256']
            result['trusted_child_cpu_seconds']=sum(s['wait4_inclusive_cpu_seconds'] for s in steps)
            result['trusted_cpu_scope']='preflight plus prepare, both source-pinned and childless'
        else:
            raw=pathlib.Path(steps[-1]['stdout_path']).read_bytes();need(len(raw)<=2*1024*1024,'bounded harness report log')
            report=json.loads(raw.splitlines()[-1]);need(report['status']=='phase1_complete' and report['halt_reason'] is None,'harness did not complete')
            persisted=read(STATE/('report-'+report['sha256']+'.json'));need(report==persisted,'persisted report agreement')
            numerical=report['usage']['numerical_cpu_seconds_no_double_count'];inclusive=steps[0]['wait4_inclusive_cpu_seconds']
            need(math.isfinite(numerical) and numerical>=0 and inclusive+0.02>=numerical,'numeric inclusive accounting')
            remainder=max(0.,inclusive-numerical)
            result.update(report_sha256=report['sha256'],numeric_cpu_from_complete_receipts=numerical,trusted_child_cpu_seconds=remainder,harness_self_cpu_at_report=report['orchestrator_self_cpu_seconds_this_process'],trusted_cpu_scope='inclusive harness subtree minus complete numeric worker/supervisor receipts; combines harness, scheduler, launch and finalization overhead',scheduler_cpu_separately_observed=False,trusted_child_cpu_rounding_tolerance_seconds=.02)
        result['status']='completed'
    except BaseException as exc:result['error']=type(exc).__name__+': '+str(exc)
    result.update(wall_seconds_at_receipt=clock()-started,meter_self_cpu_at_receipt=cpu_self(),meter_cpu_hard_limit=meter_cap,meter_final_receipt_tail_unmeasured=True,static_trusted_cpu_upper_bound_seconds=120 if action=='prepare' else 900,aggregate_kernel_cpu_cap_installed=False,kernel_fatal_wall_alarm_installed=True,wall_alarm_not_disarmed_before_exit=True,static_bound_basis='prepare: meter40 + childless preflight40 + childless prepare40. run: meter300 + main harness300 + at most one inherited-limit scheduler300; numeric descendants separately retain original caps',historical_shared_balance=None,historical_original_shared_cap_compliance='not authenticated; not claimed',unknown_cleanup_policy='Any abnormal exit/deadline or absent receipt permanently blocks automatic replay; orphan accounting may be incomplete')
    if result['wall_seconds_at_receipt']>wall:result['status']='unknown';result['error']='inclusive wall exceeded'
    exclusive(LOG/(action+'.receipt.json'),canonical(result)+b'\n')
    # Observe the receipt fsync too. The immutable receipt remains an at-checkpoint
    # observation; this post-fsync terminal stdout is required for a successful launch.
    after_fsync=clock()-started
    terminal_status=result['status'] if after_fsync<=wall else 'unknown'
    print(json.dumps({'status':terminal_status,'receipt_path':str(LOG/(action+'.receipt.json')),'receipt_sha256':sha((LOG/(action+'.receipt.json')).read_bytes()),'wall_seconds_after_receipt_fsync':after_fsync,'within_inclusive_wall_after_receipt_fsync':after_fsync<=wall,'final_stdout_exit_tail_unmeasured':True}),flush=True)
    return 0 if terminal_status=='completed' else 2
if __name__=='__main__':sys.exit(main())
