"""Trusted dummy processes only. No production grant, state or candidate access."""
import ctypes,importlib.util,json,os,pathlib,resource,signal,subprocess,sys,tempfile,time,unittest
HERE=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('meter_under_test',HERE/'meter.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
PYTHON=str(pathlib.Path(sys.executable).resolve())

class MeterTests(unittest.TestCase):
    def setUp(self):self.tmp=tempfile.TemporaryDirectory(prefix='phase1-meter-trusted-dummy-');self.root=pathlib.Path(self.tmp.name)
    def tearDown(self):self.tmp.cleanup()
    def dummy(self,name,code):p=self.root/(name+'.py');p.write_text(code);return p
    def test_exact_production_allowlist_rejects_unknown(self):
        with self.assertRaises((ValueError,KeyError)):m.fixed_commands({'action':'SHELL'})
    def test_exclusive_and_symlink_rejection(self):
        path=self.root/'one.json';m.exclusive(path,b'{}')
        with self.assertRaises(FileExistsError):m.exclusive(path,b'new')
        alias=self.root/'alias';alias.symlink_to(path)
        with self.assertRaises(ValueError):m.read(alias)
    def test_true_sequential_40_40_40_cpu_inheritance(self):
        child=self.dummy('child','import json,resource; print(json.dumps({"cpu":resource.getrlimit(resource.RLIMIT_CPU)}))')
        launcher=self.dummy('launcher',f'''import importlib.util,pathlib,resource,json
s=importlib.util.spec_from_file_location('m',{str(HERE/'meter.py')!r});m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
resource.setrlimit(resource.RLIMIT_CPU,(40,40))
root=pathlib.Path({str(self.root)!r});rows=[]
for label in ['first','second']:
 rows.append(m.supervise(['/usr/bin/prlimit','--cpu=40:40','--',{PYTHON!r},'-I','-B',{str(child)!r}],root,label,m.clock()+10))
print(json.dumps(rows))
''')
        r=subprocess.run([PYTHON,'-I','-B',str(launcher)],capture_output=True,text=True,timeout=20);self.assertEqual(r.returncode,0,r.stderr)
        rows=json.loads(r.stdout);self.assertEqual(len(rows),2)
        for row in rows:
            self.assertEqual(row['returncode'],0);self.assertTrue(row['all_meter_children_reaped']);self.assertEqual(json.loads(pathlib.Path(row['stdout_path']).read_text())['cpu'],[40,40])
    def test_wait4_includes_reaped_grandchild_cpu(self):
        child=self.dummy('cpu','''import subprocess,sys,time
s=time.process_time()
while time.process_time()-s<.1: pass
subprocess.run([sys.executable,'-I','-B','-c','import time;s=time.process_time()\\nwhile time.process_time()-s<.15: pass'],check=True)
''')
        row=m.supervise([PYTHON,'-I','-B',str(child)],self.root,'cpu',m.clock()+10)
        self.assertEqual(row['returncode'],0);self.assertGreaterEqual(row['wait4_inclusive_cpu_seconds'],.24);self.assertEqual(len(row['reap_records']),1);self.assertTrue(row['all_meter_children_reaped'])
    def test_wall_cleanup_reaps_new_session_orphan(self):
        child=self.dummy('orphan','''import subprocess,sys,time
subprocess.Popen([sys.executable,'-I','-B','-c','import time;time.sleep(30)'],start_new_session=True)
time.sleep(30)
''')
        row=m.supervise([PYTHON,'-I','-B',str(child)],self.root,'orphan',m.clock()+2.4)
        self.assertTrue(row['timed_out']);self.assertTrue(row['forced_shutdown']);self.assertTrue(row['direct_child_reaped']);self.assertTrue(row['all_meter_children_reaped']);self.assertGreaterEqual(row['adopted_descendants_reaped'],1);self.assertLess(row['wall_seconds'],2.4)
    def test_fatal_wall_alarm(self):
        start=time.monotonic()
        r=subprocess.run([PYTHON,'-I','-B','-c','import signal,time;signal.signal(signal.SIGALRM,signal.SIG_DFL);signal.setitimer(signal.ITIMER_REAL,.2);time.sleep(10)'])
        self.assertEqual(r.returncode,-signal.SIGALRM);self.assertLess(time.monotonic()-start,1)
    def test_early_attempt_survives_source_validation_failure(self):
        # Separate trusted process; fixed_commands is replaced with a rejecting
        # test double, so no production command can be launched.
        launcher=self.dummy('rejecting_launch',f'''import importlib.util,pathlib,json,sys,hashlib
s=importlib.util.spec_from_file_location('m',{str(HERE/'meter.py')!r});m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
m.LOG=pathlib.Path({str(self.root/'mock_log')!r});calls=[]
def denied(g):calls.append(1);raise ValueError('TRUSTED_SOURCE_FAILURE_TEST')
m.fixed_commands=denied
p=pathlib.Path({str(self.root/'mock_grant.json')!r});p.write_text(json.dumps({{'schema':'phase1-forward-coordination-grant-v1','action':'prepare','enabled':True,'parent_review_accepted':True,'meter_sha256':hashlib.sha256(pathlib.Path(m.__file__).read_bytes()).hexdigest(),'inclusive_wall_seconds':120}}))
sys.argv=['meter','--grant',str(p),'--grant-sha256',hashlib.sha256(p.read_bytes()).hexdigest()]
try:m.main()
except ValueError:pass
assert (m.LOG/'prepare.attempt.json').is_file()
try:m.main()
except FileExistsError:pass
else:raise AssertionError('replay accepted')
assert len(calls)==1
print('passed')
''')
        r=subprocess.run([PYTHON,'-I','-B',str(launcher)],capture_output=True,text=True,timeout=5);self.assertEqual(r.returncode,0,r.stderr)
    def test_abrupt_meter_death_kills_guarded_root(self):
        libc=ctypes.CDLL(None);self.assertEqual(libc.prctl(36,1,0,0,0),0)
        pidfile=self.root/'guarded_pid'
        child=self.dummy('guarded',f'import os,pathlib,time;pathlib.Path({str(pidfile)!r}).write_text(str(os.getpid()));time.sleep(30)')
        launcher=self.dummy('dying_meter',f'''import importlib.util,pathlib
s=importlib.util.spec_from_file_location('m',{str(HERE/'meter.py')!r});m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
m.supervise([{PYTHON!r},'-I','-B',{str(child)!r}],pathlib.Path({str(self.root)!r}),'guard',m.clock()+30)
''')
        p=subprocess.Popen([PYTHON,'-I','-B',str(launcher)])
        end=time.monotonic()+5
        while not pidfile.exists() and time.monotonic()<end:time.sleep(.01)
        self.assertTrue(pidfile.exists());pid=int(pidfile.read_text());p.kill();p.wait(timeout=5)
        reaped=False;end=time.monotonic()+5
        while time.monotonic()<end:
            got,status,_=os.wait4(pid,os.WNOHANG)
            if got:self.assertEqual(os.waitstatus_to_exitcode(status),-signal.SIGKILL);reaped=True;break
            time.sleep(.01)
        self.assertTrue(reaped)

if __name__=='__main__':unittest.main(verbosity=2)
