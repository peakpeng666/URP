# Phase-0 terminal audit

Result: PASS. The exact completed report and its retained evidence reconcile; no numerical rerun was performed.

## Outcome

- Report seal: `df2812a963cdd1053991b98aae52d5d5ecff8c8b141d05f360737d11d056e325`
- Plan seal: `228d4a9f75fc47804fddfe8bd8982a8867c6ed360b273c663de7d620b67165e7`
- Ledger seal: `4d5fa3ee080ae931a8a52e36769c04781af525a48002b4a4ec42f77398c2ef56`
- All 12 authenticated phase-0 terminals were independently restored and matched against the pinned prepared rows, claims, capture bytes, registry, deployment, and receipt trust
- Four admissions succeeded and all 20 design-instance scores completed: EOH 1/6 eligible, IID 3/6 eligible. Eight empty length terminals remain generation failures; the denominator is 12
- Every candidate has bins `[2094, 2059, 2057, 2067, 2058]` and exact maximized fitness `5039117513623279 / 5239871856954735`, approximately `0.961687165485736`

## Best-Fit comparison

All 20 receipt-bound full-assignment SHA-256 values equal the canonical hashes of the corresponding retained Best-Fit reference assignments. Each reference contains all 5,000 placement indices, and input hashes also match. This is stronger than a bin-count match: the evidence identifies the same full assignment trajectory for every tested candidate/input pair.

The candidate bundles retain assignment hashes, not the full candidate assignment vectors. This audit therefore compared their verified full-sequence hashes with the retained BF vectors. No source execution, algorithm simulation, or reconstructed candidate trajectory was used. The finding is limited to these five frozen design instances and does not establish general algorithm equivalence or heldout performance.

## Receipt and recovery reconciliation

- Re-ran the accepted read-only ReceiptBridge validation on all four complete bundles, then matched projected observations exactly to all twelve saved outer results and the ledger
- All 24 child-worker receipts (4 admissions + 20 instance workers) and all 20 supervisor receipts show clean reaping, return code 0, and no cleanup error
- All 24 runtime claims have exact matching terminal results: 4 verification bundles + 20 per-instance receipts. All 12 outer attempts have matching results. There are no unknown claims or halt records
- Every numerical receipt preserves exact capture/source/claim/input identities, accepted security and resource profiles, completed 5,000-step assignment, passed checker, and no-cross-slot-cache evidence
- Full ledger remains 132 generation rows and 780 score rows: 4 eligible, 8 generation failures, 120 planned; 20 verified scores and 760 not run
- EOH P0 contains its one valid candidate and is explicitly underfilled. IID selects `b01_IID_TC_g0_i1_01` by the accepted tie priority among three equal-fitness candidates

## Accounting

- Admission CPU: 0.716827 seconds
- Numerical-child CPU: 245.301670 seconds
- Supervisor self CPU: 391.570308 seconds
- Numerical total without double counting: 637.588805 seconds
- Inclusive supervisor wait4 CPU: 636.871978 seconds, retained as evidence and not added again
- Score-call CPU: 1,508,172,129 ns, already included in numerical-child CPU
- Sum of shared instance wall times: 638.532749 seconds
- Current-process elapsed wall: 639.934496 seconds; orchestrator self CPU: 1.931312 seconds
- Durable reservations: 4 admissions, 20 numerical children, 20 supervisors; 2,404 CPU seconds and 1,820 shared wall seconds. The 90-second instance wall allowance is charged once per pack
- No controls, heldout confirmations, retained-parent rescoring, or extra generation were performed by this harness

## Audit scope

All 109 frozen source/input hashes still match. Frozen-state file hashes before and after the audit are identical. The audit used read-only evidence validation and exact integer/rational/hash comparisons only. It accessed no heldout data or superseded protocol seed metadata and performed no candidate parsing/execution, numerical workers, model calls, or external writes.

Artifacts: `RESULT.json` contains the per-candidate and all-20 comparison records; `STATE_FILE_HASHES.json` records the audited frozen-state bytes; `audit_terminal.py` and `AUDIT_LOG.txt` retain the reproducible read-only checks.
