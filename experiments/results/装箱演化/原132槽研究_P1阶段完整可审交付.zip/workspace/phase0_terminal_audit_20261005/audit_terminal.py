"""Read-only terminal evidence audit. No numerical or candidate execution."""
from collections import Counter
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import sys
from unittest.mock import patch

ROOT=Path(__file__).resolve().parent.parent
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'phase0_numerical_harness_20261005'))
import phase0 as h
STATE=h.STATE
REPORT='df2812a963cdd1053991b98aae52d5d5ecff8c8b141d05f360737d11d056e325'
def snapshot():
    return {str(p.relative_to(STATE)):h.sha(p.read_bytes()) for p in sorted(STATE.rglob('*')) if p.is_file()}
before=snapshot()
with patch('ast.parse',side_effect=AssertionError('candidate AST forbidden')),patch('subprocess.Popen',side_effect=AssertionError('process launch forbidden')):
    sources=h.verify_sources()
    report=h.verify(h.read(STATE/('report-'+REPORT+'.json')));assert report['sha256']==REPORT
    plan=h.verify(h.read(STATE/'plan.json','0e76e9d825eb97f4560f259423c8a2f39411036649d8796e6047c100e24fe277'))
    assert plan['sha256']==report['plan_sha256']=='228d4a9f75fc47804fddfe8bd8982a8867c6ed360b273c663de7d620b67165e7'
    assert plan['source_input_plan_sha256']==sources['sha256']=='69bde2227b25f0da2d670010a24eb30e0c3194018436161f04cb63410fd76cba'
    approval=h.read(STATE/'parent_execution_approval.json')
    assert approval['explicit_execution_grant'] is True
    for k in ('plan_sha256','registry_sha256','deployment_sha256','max_admissions','max_candidate_packs'):
        assert approval[k]==(plan['sha256'] if k=='plan_sha256' else plan[k])
    assert approval['controls']==approval['heldout']==0
    assert plan['max_admissions']==4 and plan['max_candidate_packs']==20
    trust=h.read(approval['receipt_trust_path'],approval['receipt_trust_file_sha256'])
    assert approval['receipt_trust_file_sha256']=='a16084586b4ae388cf0b59b266423d3ee7b68717f69f5e74f1391387265bf388'
    handoff=h.read(STATE/'handoff.json',plan['handoff_file_sha256'])
    m=h.modules();store,rows=h.imported_rows(handoff,m)
    assert rows==h.read(STATE/'rows.json',plan['rows_file_sha256'])
    panel,_=h.design_panel();assert panel==h.read(STATE/'panel.json',plan['panel_file_sha256'])
    freeze=h.verify(h.read(h.INPUTS/'freeze.json'));bridge=h.receipt_bridge(plan,trust,m)
    ledger=h.verify(h.read(report['scheduler_ledger_path']))
    assert ledger['sha256']==report['scheduler_ledger_sha256']
    assert len(ledger['generation'])==132 and len(ledger['scores'])==780
    assert len(rows)==report['generation_denominator']==report['authenticated_generation_terminals']==12
    assert sum(x['logical_requests_observed'] for x in ledger['generation'])==12
    assert report['status']=='phase0_complete' and report['halt_reason'] is None
    assert report['control_packs']==report['heldout_packs']==report['parent_rescores']==0
    reference=[]
    for i in range(5):
        path=ROOT/f'frozen_design_controls_20261005/references/BF_{i}.json'
        ref=h.read(path); checked=h.read(ROOT/f'frozen_design_controls_20261005/results/control_BF_design_{i:02}.checked.json')
        assignment_hash=h.digest(ref['assignment'])
        assert len(ref['assignment'])==5000 and ref['input_sha256']==panel['instances'][i]['input_sha256']
        assert assignment_hash==checked['assignment_sha256'] and ref['used_bins']==checked['used_bins']
        reference.append({'instance_index':i,'input_sha256':ref['input_sha256'],'L1':ref['L1'],'used_bins':ref['used_bins'],'assignment_sha256':assignment_hash,'reference_file_sha256':h.sha(path.read_bytes())})
    bundles=[];comparisons=[];candidates=[];workers=[];supervisors=[]
    expected_runtime_tokens=set()
    for row in rows:
        cid=row['claim']['claim_id']
        attempt=h.verify(h.read(STATE/'attempts'/(cid+'.json')))
        saved=h.verify(h.read(STATE/'results'/(cid+'.json')))
        assert attempt['plan_sha256']==saved['plan_sha256']==plan['sha256']
        assert attempt['claim_sha256']==saved['claim_sha256']==row['claim']['sha256']
        bundle=h.verify(h.read(STATE/'bundles'/(cid+'.json'))) if row['candidate'] else None
        projected=h.project(row,bundle,bridge,panel,freeze)
        assert projected==saved['observation']
        assert saved['bundle_sha256']==(bundle['sha256'] if bundle else None)
        slot=next(x for x in ledger['generation'] if x['id']==row['slot_id'])
        assert slot['capture']==row['capture'] and slot['extraction']=={k:v for k,v in projected['extraction'].items() if k!='candidate'}
        if bundle is None:
            assert slot['state']=='generation_failed' and row['capture']['raw']=='' and row['capture']['finish_reason']=='length'
            continue
        assert slot['state']=='eligible' and bundle['admission']['admitted'] is True
        bundles.append(bundle);workers.append(bundle['admission']['worker'])
        assert len(bundle['scores'])==5
        token=h.digest(['registry-execution-v1',h.RUN,row['slot_id'],'verify']);expected_runtime_tokens.add(token)
        assert h.verify(h.read(STATE/'runtime_journal'/(token+'.result.json')))['receipt']==bundle
        claim=h.verify(h.read(STATE/'runtime_journal'/(token+'.claim.json')))
        assert claim['binding']==bundle['registry_binding'] and claim['execution_id']=='verify'
        bins=[]
        for score in bundle['scores']:
            i=score['instance_index'];ev=score['evidence'];worker=ev['worker'];supervisor=ev['supervisor'];bins.append(score['used_bins'])
            workers.append(worker);supervisors.append(supervisor)
            assert score['outcome']=='ok' and ev['checker_status']=='passed' and ev['assignment_complete'] is True and ev['no_cross_slot_cache'] is True
            assert worker['steps']==5000 and worker['assignment_complete'] is True
            eid=cid+'/instance/'+str(i); token=h.digest(['registry-execution-v1',h.RUN,row['slot_id'],eid]);expected_runtime_tokens.add(token)
            journal_claim=h.verify(h.read(STATE/'runtime_journal'/(token+'.claim.json')))
            assert journal_claim['binding']==bundle['registry_binding'] and journal_claim['execution_id']==eid
            assert h.verify(h.read(STATE/'runtime_journal'/(token+'.result.json')))['receipt']==score
            ledger_score=next(x for x in ledger['scores'] if x.get('source_generation_slot')==row['slot_id'] and x['instance_index']==i)
            assert ledger_score['state']=='verified' and ledger_score['used_bins']==score['used_bins'] and ledger_score['evidence']==projected['scores'][i]
            ref=reference[i]
            comparisons.append({'slot_id':row['slot_id'],'instance_index':i,'input_match':score['input_sha256']==ref['input_sha256'],'bin_count_match':score['used_bins']==ref['used_bins'],'full_assignment_hash_match':ev['assignment_sha256']==ref['assignment_sha256'],'assignment_sha256':ev['assignment_sha256']})
        fitness=sum((Fraction(x['L1'],x['used_bins']) for x in bundle['scores']),Fraction())/5
        archive=next(x for x in ledger['archive'] if x['id']==row['slot_id'])
        assert archive['fitness']=={'numerator':fitness.numerator,'denominator':fitness.denominator}
        candidates.append({'slot_id':row['slot_id'],'arm':row['arm'],'source_sha256':row['candidate']['code_sha256'],'bundle_sha256':bundle['sha256'],'result_sha256':saved['sha256'],'used_bins':bins,'fitness':archive['fitness'],'fitness_decimal':float(fitness),'tie_priority':archive['tie_priority']})
    assert {p.name.removesuffix('.claim.json') for p in (STATE/'runtime_journal').glob('*.claim.json')}==expected_runtime_tokens
    assert {p.name.removesuffix('.result.json') for p in (STATE/'runtime_journal').glob('*.result.json')}==expected_runtime_tokens
    assert len(list((STATE/'attempts').glob('*.json')))==len(list((STATE/'results').glob('*.json')))==12
    assert len(bundles)==4 and len(comparisons)==20 and len(workers)==24 and len(supervisors)==20
    assert not list(STATE.glob('halt-*.json'))
    assert all(x['reaped'] is True and x['returncode']==0 and x['cleanup_error'] is None for x in workers+supervisors)
    assert all(x['source_sent'] is True and x['source_after_host_gate'] is True for x in workers)
    assert all(x['security']==trust['expected_security'] for x in workers)
    assert all(x['input_match'] and x['bin_count_match'] and x['full_assignment_hash_match'] for x in comparisons)
    reservations=[h.verify(h.read(p)) for p in sorted((STATE/'reservations').glob('*.json'))]
    assert Counter(x['role'] for x in reservations)==Counter({'admission':4,'instance':20,'supervisor':20})
    assert len({(x['role'],x['execution_id']) for x in reservations})==44
    usage=h.account(bundles,reservations);assert usage==report['usage']
    assert usage['reserved_cpu_seconds']==2404 and usage['reserved_shared_wall_seconds']==1820
    independently_counted_cpu=sum(x['cpu_seconds'] for x in workers)+sum(x['actual_supervisor_cpu_seconds'] for x in supervisors)
    assert abs(independently_counted_cpu-usage['numerical_cpu_seconds_no_double_count'])<1e-8
    assert usage['score_call_cpu_ns']==sum(x['score_call_cpu_ns'] for x in workers)
    assert report['snapshots']==ledger['snapshots']
    snapshots={x['arm']:x for x in ledger['snapshots']}
    assert len(snapshots)==2 and all(x['phase']==0 for x in snapshots.values())
    assert snapshots['EOH_TC']['survivor_ids']==['b01_EOH_TC_g0_i1_05'] and snapshots['EOH_TC']['underfilled'] is True
    iid=sorted((x for x in candidates if x['arm']=='IID_TC'),key=lambda x:(-Fraction(x['fitness']['numerator'],x['fitness']['denominator']),x['tie_priority'],x['slot_id']))
    assert snapshots['IID_TC']['survivor_ids']==[iid[0]['slot_id']]
    assert snapshots['IID_TC']['decisions']['ranked_ids']==[x['slot_id'] for x in iid]
    result={'schema':'phase0-terminal-independent-audit-v1','status':'passed','report_sha256':REPORT,'plan_sha256':plan['sha256'],'ledger_sha256':ledger['sha256'],'authenticated_index_identity':store.index_identity,'source_files_verified':len(sources['source_and_input_files']),'generation_denominator':12,'generation_observed_per_arm':dict(Counter(x['arm'] for x in rows)),'eligible_per_arm':dict(Counter(x['arm'] for x in candidates)),'empty_length_failures':8,'admissions':4,'completed_scores':20,'verified_child_worker_receipts':24,'verified_supervisor_receipts':20,'all_reaped_cleanly':True,'distinct_observed_pids':len({x['pid'] for x in workers+supervisors}),'runtime_claim_result_pairs':24,'outer_attempt_result_pairs':12,'unknown_claims':0,'numerical_usage':usage,'orchestrator_self_cpu_seconds':report['orchestrator_self_cpu_seconds_this_process'],'wall_seconds_this_process':report['wall_seconds_this_process'],'full_generation_rows':132,'full_score_rows':780,'ledger_generation_states':dict(Counter(x['state'] for x in ledger['generation'])),'ledger_score_states':dict(Counter(x['state'] for x in ledger['scores'])),'candidates':candidates,'bf_reference':reference,'bf_comparisons':comparisons,'bf_assignment_hash_matches':20,'trajectory_comparison_scope':'Verified candidate full-assignment SHA-256 equals canonical hash of retained BF 5000-placement assignment, on each identical input. Candidate assignment vectors are not persisted in these bundles. This establishes hash-evidence trajectory identity for these five designs, not general algorithm equivalence.','controls_executed_here':0,'heldout_executed_here':0,'parent_rescores':0,'candidate_or_numeric_execution_during_audit':0,'model_calls_during_audit':0,'external_writes_during_audit':0}
after=snapshot();assert before==after
result['frozen_state_unchanged']=True
result['frozen_state_files_hashed']=len(before)
(OUT/'RESULT.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
(OUT/'STATE_FILE_HASHES.json').write_text(json.dumps(before,sort_keys=True,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('status','report_sha256','admissions','completed_scores','generation_denominator','all_reaped_cleanly','unknown_claims','bf_assignment_hash_matches','frozen_state_unchanged','ledger_generation_states','ledger_score_states','numerical_usage')},sort_keys=True))
