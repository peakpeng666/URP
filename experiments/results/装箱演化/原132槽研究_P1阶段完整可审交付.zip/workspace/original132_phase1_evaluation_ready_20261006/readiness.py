"""Read-only readiness; no candidate parsing, admission, scoring, or network."""
import hashlib, importlib.util, json, pathlib, sys
ROOT=pathlib.Path(__file__).resolve().parent.parent

def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

def main():
    h=load(ROOT/'original132_phase1_preparation_20261005/phase1_numerical.py','phase1_readiness')
    source=h.verify_sources();package=h.verify(h.read(h.HERE/'PACKAGE_MANIFEST.json')); panel,values=h.design_panel()
    dep=load(h.RUNTIME/'dependencies.py','phase1_readiness_dependencies');freeze,runtime=dep.load_worker_freeze();dep.verify_files(freeze['dependencies'])
    trust_path=ROOT/'phase0_numerical_harness_20261005/RECEIPT_TRUST_REVIEW_CANDIDATE.json';trust_sha=h.sha(trust_path.read_bytes())
    assert trust_sha=='a16084586b4ae388cf0b59b266423d3ee7b68717f69f5e74f1391387265bf388'
    assert runtime==h.RUNTIME_HASH
    result={'schema':'phase1-local-readiness-v1','status':'sources_inputs_dependencies_verified', 'source_files':len(source['source_and_input_files']), 'package_files':len(package['files']), 'dependency_files':len(freeze['dependencies']), 'source_plan_sha256':source['sha256'],'package_manifest_sha256':package['sha256'],'runtime_sha256':runtime, 'design_file_sha256':h.DESIGN_HASH,'design_panel':panel, 'receipt_trust_path':str(trust_path),'receipt_trust_file_sha256':trust_sha, 'production_state_exists':h.STATE.exists(),'production_state_path':str(h.STATE), 'execution_granted':False, 'model_calls':0,'candidate_AST_or_compile_calls':0,'admissions':0,'score_calls':0, 'verification_scope':'Read-only hashes and exact input domain checks; no new sandbox or numerical probe.'}
    print(json.dumps(result,sort_keys=True,indent=2))
if __name__=='__main__':main()
