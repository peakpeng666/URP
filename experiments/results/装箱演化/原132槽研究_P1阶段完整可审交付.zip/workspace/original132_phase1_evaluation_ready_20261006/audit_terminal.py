"""Read-only phase-one evidence audit; no candidate AST, execution, or API calls.

The accepted runtime already checks every assignment with its independent exact
integer checker. Its persisted receipts contain assignment hashes, not vectors.
This auditor revalidates those receipts and independently recomputes rational
fitness, gap, deduplication, selection, counts and accounting from retained data.
"""
import argparse
from collections import Counter
from fractions import Fraction
import hashlib,importlib.util,json,pathlib,sys
from unittest.mock import patch
ROOT=pathlib.Path(__file__).resolve().parent.parent

def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

def require(ok,reason):
    if not ok:raise ValueError(reason)

def frac(v):return Fraction(v['numerator'],v['denominator'])
def rational(v):return {'numerator':v.numerator,'denominator':v.denominator}
def snapshot(h):return {str(p.relative_to(h.STATE)):h.sha(p.read_bytes()) for p in sorted(h.STATE.rglob('*')) if p.is_file()}

def independent_selection(ledger,phase):
    archive={x['id']:x for x in ledger['archive']};generations={x['id']:x for x in ledger['generation']};out=[]
    for snap in ledger['snapshots']:
        require(snap['phase']<=phase,'unexpected later selection')
        arm=snap['arm'];stage=snap['phase']
        offspring=[x for x in archive.values() if x['arm']==arm and x['phase']==stage and x['eligible']]
        if arm=='EOH_TC':
            prev=next((s for s in ledger['snapshots'] if s['phase']==stage-1 and s['arm']==arm),None)
            pool=([archive[i] for i in prev['survivor_ids']] if prev else [])+offspring;capacity=6
        else:
            pool=[x for x in archive.values() if x['arm']==arm and x['phase']<=stage and x['eligible']];capacity=1
        unique={};duplicates={}
        for candidate in sorted(pool,key=lambda x:x['order']):
            identity=candidate['joint_identity']
            if identity in unique:duplicates[candidate['id']]=unique[identity]['id']
            else:unique[identity]=candidate
        ranked=sorted(unique.values(),key=lambda x:(-frac(x['fitness']),x['tie_priority'],x['id']))
        survivors=[x['id'] for x in ranked[:capacity]]
        decisions={'eligible_ids':[x['id'] for x in sorted(pool,key=lambda x:x['order'])], 'ranked_ids':[x['id'] for x in ranked],'duplicates':duplicates,'reasons':{x['id']:('exact_joint_duplicate' if x['id'] in duplicates else 'retained' if x['id'] in survivors else 'outside_capacity') for x in pool}}
        require(snap['decisions']==decisions and snap['survivor_ids']==survivors,'independent dedup/ranking mismatch')
        require(snap['population_size']==len(survivors) and snap['underfilled']==(len(survivors)<capacity),'selection capacity mismatch')
        expected_failed=[{'id':x['id'],'state':x['state'],'reason':x['reason']} for x in ledger['generation'] if x['arm']==arm and x['phase']==stage and x['state']!='eligible']
        require(snap['failed_offspring']==expected_failed,'failed denominator changed')
        for member in snap['members']:
            require(member=={k:archive[member['id']][k] for k in member},'snapshot member mismatch')
        out.append({'phase':stage,'arm':arm,'survivor_ids':survivors,'ranked_ids':decisions['ranked_ids'],'joint_duplicates':duplicates,'capacity':capacity})
    return out

def audit(h,phase,report_path,report_sha,approval_path,approval_sha):
    before=snapshot(h)
    with patch('ast.parse',side_effect=AssertionError('candidate AST forbidden')),patch('subprocess.Popen',side_effect=AssertionError('process launch forbidden')):
        sources=h.verify_sources();report=h.verify(h.read(report_path,report_sha));plan=h.verify(h.read(h.STATE/'plan.json'))
        require(report['status']==f'phase{phase}_complete' and report['halt_reason'] is None,'not a clean terminal report')
        require(report['plan_sha256']==plan['sha256'] and plan['source_input_plan_sha256']==sources['sha256'],'plan/report/source binding')
        approval=h.read(approval_path,approval_sha)
        require(approval['schema']==f'phase{phase}-execution-approval-v1' and approval['explicit_execution_grant'] is True,'approval identity')
        if phase==1:
            package=h.verify(h.read(h.HERE/'PACKAGE_MANIFEST.json'))
            require(approval['enabled'] is True and approval['parent_review_accepted'] is True and approval['package_manifest_sha256']==package['sha256'],'phase-one parent grant')
        for k in ('plan_sha256','registry_sha256','deployment_sha256','max_admissions','max_candidate_packs'):
            require(approval[k]==(plan['sha256'] if k=='plan_sha256' else plan[k]),'approval binding '+k)
        require(approval['run_id']==h.RUN and approval['controls']==approval['heldout']==0,'approval scope')
        trust=h.read(approval['receipt_trust_path'],approval['receipt_trust_file_sha256'])
        require(approval['receipt_trust_file_sha256']=='a16084586b4ae388cf0b59b266423d3ee7b68717f69f5e74f1391387265bf388','unchanged receipt trust')
        handoff=h.read(h.STATE/'handoff.json',plan['handoff_file_sha256']);m=h.modules();store,rows=h.imported_rows(handoff,m)
        require(rows==h.read(h.STATE/'rows.json',plan['rows_file_sha256']),'capture reimport mismatch')
        panel,instances=h.design_panel();require(panel==h.read(h.STATE/'panel.json',plan['panel_file_sha256']),'design mismatch')
        freeze=h.verify(h.read(h.INPUTS/'freeze.json'));bridge=h.receipt_bridge(plan,trust,m) if plan['candidate_source_count'] else None
        ledger=h.verify(h.read(report['scheduler_ledger_path']));require(ledger['sha256']==report['scheduler_ledger_sha256'],'ledger binding')
        denominator=60 if phase else 12
        require(len(rows)==report['generation_denominator']==report['authenticated_generation_terminals']==denominator,'denominator')
        require(len(ledger['generation'])==132 and len(ledger['scores'])==780,'scientific full scope')
        require(sum(x['logical_requests_observed'] for x in ledger['generation'])==(72 if phase else 12),'logical request scope')
        require(all(x['state']=='planned' and x['logical_requests_observed']==0 for x in ledger['generation'] if x['phase']>phase),'later phase touched')
        require(report['control_packs']==report['heldout_packs']==report['parent_rescores']==0,'unauthorized evaluation')
        if phase:
            original=h.verify(h.read(h.HERE/'history/scheduler-ledger.json'))
            require(ledger['snapshots'][:2]==original['snapshots'],'P0 changed')
            old_gen={x['id']:x for x in original['generation'] if x['phase']==0}
            require(all(x==old_gen[x['id']] for x in ledger['generation'] if x['phase']==0),'phase-zero generation history changed')
            old_scores={x['id']:x for x in original['scores'] if x.get('source_generation_slot') in old_gen}
            require(all(x==old_scores[x['id']] for x in ledger['scores'] if x.get('source_generation_slot') in old_gen),'phase-zero score history changed')
        require(len(ledger['snapshots'])==(4 if phase else 2),'selection boundary')
        bundles=[];workers=[];supervisors=[];expected_tokens=set();expected_reservations=set();candidates=[];observations=[]
        generation={x['id']:x for x in ledger['generation']};archive={x['id']:x for x in ledger['archive']}
        for row in rows:
            cid=row['claim']['claim_id'];attempt=h.verify(h.read(h.STATE/'attempts'/(cid+'.json')));saved=h.verify(h.read(h.STATE/'results'/(cid+'.json')))
            require(attempt['plan_sha256']==saved['plan_sha256']==plan['sha256'],'attempt plan')
            require(attempt['claim_sha256']==saved['claim_sha256']==row['claim']['sha256'],'attempt claim')
            bundle=h.verify(h.read(h.STATE/'bundles'/(cid+'.json'))) if row['candidate'] else None
            projected=h.project(row,bundle,bridge,panel,freeze);observations.append(projected)
            require(projected==saved['observation'] and saved['bundle_sha256']==(bundle['sha256'] if bundle else None),'verified projection')
            slot=generation[row['slot_id']]
            require(slot['capture']==row['capture'] and slot['extraction']=={k:v for k,v in projected['extraction'].items() if k!='candidate'},'scheduler capture/extraction')
            if bundle is None:
                require(slot['state']=='generation_failed','format failure state');continue
            bundles.append(bundle);workers.append(bundle['admission']['worker']);expected_reservations.add(('admission',cid+'/admission'))
            token=h.digest(['registry-execution-v1',h.RUN,row['slot_id'],'verify']);expected_tokens.add(token)
            require(h.verify(h.read(h.STATE/'runtime_journal'/(token+'.result.json')))['receipt']==bundle,'bundle journal')
            journal=h.verify(h.read(h.STATE/'runtime_journal'/(token+'.claim.json')))
            require(journal['binding']==bundle['registry_binding'] and journal['execution_id']=='verify','bundle journal claim')
            for score,projected_score in zip(bundle['scores'],projected['scores']):
                i=score['instance_index'];ev=score['evidence'];worker=ev['worker'];supervisor=ev['supervisor'];workers.append(worker);supervisors.append(supervisor)
                eid=cid+'/instance/'+str(i);expected_reservations.update({('instance',eid),('supervisor',eid)})
                token=h.digest(['registry-execution-v1',h.RUN,row['slot_id'],eid]);expected_tokens.add(token)
                require(h.verify(h.read(h.STATE/'runtime_journal'/(token+'.result.json')))['receipt']==score,'score journal')
                journal=h.verify(h.read(h.STATE/'runtime_journal'/(token+'.claim.json')))
                require(journal['binding']==bundle['registry_binding'] and journal['execution_id']==eid,'score journal claim')
                require(score['input_sha256']==panel['instances'][i]['input_sha256'] and score['L1']==panel['instances'][i]['L1'],'exact score input')
                ledger_score=next(x for x in ledger['scores'] if x.get('source_generation_slot')==row['slot_id'] and x['instance_index']==i)
                require(ledger_score['evidence']==projected_score,'scheduler score evidence')
                if score['outcome']=='ok':
                    require(ledger_score['state']=='verified' and ledger_score['used_bins']==score['used_bins'],'score bin/state')
                    require(ev['checker_status']=='passed' and ev['assignment_complete'] is True and ev['no_cross_slot_cache'] is True,'assignment evidence')
                    require(worker['steps']==5000 and worker['assignment_complete'] is True,'full 5000 assignments')
                else:require(score['used_bins'] is None and ev['assignment_complete'] is False,'no invented failed fitness')
            if slot['state']=='eligible':
                require(len(bundle['scores'])==5 and all(s['outcome']=='ok' for s in bundle['scores']),'eligible incomplete panel')
                fitness=sum((Fraction(s['L1'],s['used_bins']) for s in bundle['scores']),Fraction())/5
                gap=100*Fraction(sum(s['used_bins']-s['L1'] for s in bundle['scores']),sum(s['L1'] for s in bundle['scores']))
                candidate=archive[row['slot_id']]
                require(candidate['fitness']==rational(fitness) and candidate['report_gap']==rational(gap),'independent exact fitness/gap')
                require(candidate['tie_priority']==slot['tie_priority'],'frozen tie priority')
                candidates.append({'slot_id':row['slot_id'],'arm':row['arm'],'source_sha256':row['candidate']['code_sha256'],'used_bins':[s['used_bins'] for s in bundle['scores']],'fitness':rational(fitness),'fitness_decimal':float(fitness),'assignment_hashes':[s['evidence']['assignment_sha256'] for s in bundle['scores']]})
            elif row['slot_id'] in archive:require(archive[row['slot_id']]['fitness'] is None and archive[row['slot_id']]['eligible'] is False,'failed candidate fitness')
        require({p.stem for p in (h.STATE/'attempts').glob('*.json')}=={x['claim']['claim_id'] for x in rows},'attempt roster')
        require({p.stem for p in (h.STATE/'results').glob('*.json')}=={x['claim']['claim_id'] for x in rows},'result roster')
        for suffix in ('.claim.json','.result.json'):require({p.name.removesuffix(suffix) for p in (h.STATE/'runtime_journal').glob('*'+suffix)}==expected_tokens,'unknown runtime journal')
        require(not list(h.STATE.glob('halt-*.json')),'retained infrastructure halt')
        require(all(x['reaped'] is True and x['cleanup_error'] is None for x in workers+supervisors),'worker/supervisor cleanup')
        require(all(x['source_sent'] is True and x['source_after_host_gate'] is True and x['security']==trust['expected_security'] for x in workers),'sandbox evidence')
        reservations=[h.verify(h.read(p)) for p in sorted((h.STATE/'reservations').glob('*.json'))]
        require(len(reservations)==len(expected_reservations) and {(x['role'],x['execution_id']) for x in reservations}==expected_reservations,'reservation exactness')
        usage=h.account(bundles,reservations);require(usage==report['usage'],'usage report')
        cpu=sum(x['cpu_seconds'] for x in workers)+sum(x['actual_supervisor_cpu_seconds'] for x in supervisors)
        require(abs(cpu-usage['numerical_cpu_seconds_no_double_count'])<1e-8,'independent CPU accounting')
        require(usage['score_call_cpu_ns']==sum(x['score_call_cpu_ns'] for x in workers),'score timing')
        require(usage['reserved_cpu_seconds']<= (36060 if phase else 7212) and usage['reserved_shared_wall_seconds']<=(27300 if phase else 5460),'phase resources')
        require(len(bundles)<=plan['max_admissions'] and usage['instance_packs']<=plan['max_candidate_packs'],'phase execution counts')
        require(report['snapshots']==ledger['snapshots'],'report snapshots')
        selections=independent_selection(ledger,phase)
    require(snapshot(h)==before,'audit changed frozen state')
    return {'schema':'phase1-independent-terminal-audit-v1' if phase else 'phase0-reference-audit-test-v1','status':'passed','phase':phase,'report_file_sha256':report_sha,'report_sha256':report['sha256'],'plan_sha256':plan['sha256'],'ledger_sha256':ledger['sha256'],'authenticated_index_identity':store.index_identity,'generation_denominator':denominator,'generation_per_arm':dict(Counter(x['arm'] for x in rows)),'generation_states':dict(Counter(generation[x['slot_id']]['state'] for x in rows)),'eligible_per_arm':dict(Counter(x['arm'] for x in candidates)),'admissions':len(bundles),'design_packs':usage['instance_packs'],'source_files_verified':len(sources['source_and_input_files']),'worker_receipts':len(workers),'supervisor_receipts':len(supervisors),'runtime_claim_result_pairs':len(expected_tokens),'unknown_claims':0,'all_reaped_cleanly':True,'usage':usage,'candidates':candidates,'selection_recomputation':selections,'controls':0,'heldout':0,'parent_rescores':0,'candidate_execution_during_audit':0,'source_AST_calls_during_audit':0,'model_calls_during_audit':0,'frozen_state_unchanged':True,'state_files_hashed':len(before),'assignment_verification_scope':'The frozen runtime independently checks every full assignment using exact integers before emitting receipts. This audit checks accepted checker receipts, assignment hashes, exact rational fitness and selection. Candidate vectors are not persisted; no claimed second offline vector replay.'}

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--phase0-reference',action='store_true');parser.add_argument('--report',required=True);parser.add_argument('--report-file-sha256',required=True);parser.add_argument('--approval',required=True);parser.add_argument('--approval-file-sha256',required=True);parser.add_argument('--output',required=True);args=parser.parse_args()
    phase=0 if args.phase0_reference else 1
    harness=ROOT/('phase0_numerical_harness_20261005/phase0.py' if phase==0 else 'original132_phase1_preparation_20261005/phase1_numerical.py')
    h=load(harness,'audited_numerical_harness');result=audit(h,phase,args.report,args.report_file_sha256,args.approval,args.approval_file_sha256)
    with pathlib.Path(args.output).open('x') as stream:json.dump(result,stream,sort_keys=True,indent=2);stream.write('\n')
    print(json.dumps({k:result[k] for k in ('status','phase','generation_denominator','admissions','design_packs','unknown_claims','all_reaped_cleanly','frozen_state_unchanged')},sort_keys=True))
if __name__=='__main__':main()
