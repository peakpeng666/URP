"""Trusted metadata-only mutations, no production state or candidate execution."""
import copy,importlib.util,json,pathlib,unittest
HERE=pathlib.Path(__file__).resolve().parent;ROOT=HERE.parent
s=importlib.util.spec_from_file_location('strong',HERE/'audit_source_binding.py');a=importlib.util.module_from_spec(s);s.loader.exec_module(a)
class Tests(unittest.TestCase):
 def setUp(self):
  prep=ROOT/'original132_phase1_preparation_20261005';self.old=json.loads((prep/'history/scheduler-ledger.json').read_bytes());self.rows=[];self.obs=[]
  for i,r in enumerate(json.loads((prep/'inputs/roster.json').read_bytes())['records']):
   pack=json.loads((prep/'inputs/packs'/(r['slot_id']+'.json')).read_bytes());self.rows.append({'slot_id':r['slot_id'],'pack':pack});candidate=None;scores=[]
   if i==1:
    code='TRUSTED OPAQUE MOCK; NEVER PARSED OR EXECUTED';description='Metadata fixture';candidate={'code':code,'description':description,'code_sha256':a.textsha(code),'description_sha256':a.textsha(description),'pair_sha256':a.digest({'description':description,'code':code}),'code_identity':a.digest('TEST_CODE_ID'),'joint_identity':a.digest('TEST_JOINT_ID'),'description_consistency':'undetermined'};scores=[{'instance_index':j,'L1':100,'used_bins':100,'outcome':'ok','evidence':{'runtime_sha256':'TRUSTED_TEST_RUNTIME'}} for j in range(5)]
   self.obs.append({'slot_id':r['slot_id'],'capture':{'status':'TRUSTED_MOCK','raw':''},'extraction':{'candidate':candidate,'unique':candidate is not None,'strict':candidate is not None,'reason':None if candidate else 'TRUSTED_MOCK_FAILURE'},'scores':scores})
  self.ledger=copy.deepcopy(self.old);archive,snaps,states=a.derive(self.old,self.rows,self.obs);self.ledger['archive']=archive;self.ledger['snapshots']=snaps;self.ledger['scores']=a.derive_scores(self.old,self.obs)
  for slot,row,obs in zip([x for x in self.ledger['generation'] if x['phase']==1],self.rows,self.obs):slot.update(logical_requests_observed=1,parents=row['pack']['parents'],state=states[slot['id']][0],reason=states[slot['id']][1],capture=obs['capture'],extraction={k:v for k,v in obs['extraction'].items() if k!='candidate'})
 def check(self):return a.verify_binding(self.old,self.ledger,self.rows,self.obs)
 def test_metadata_baseline(self):self.assertEqual(self.check()['status'],'passed')
 def test_wrong_current_code(self):
  self.ledger['archive'][-1]['code']='TAMPER'
  with self.assertRaisesRegex(ValueError,'archive'):self.check()
 def test_wrong_historical_code(self):
  self.ledger['archive'][0]['code']='TAMPER'
  with self.assertRaisesRegex(ValueError,'archive'):self.check()
 def test_forged_current_joint_identity(self):
  self.ledger['archive'][-1]['joint_identity']=self.ledger['archive'][0]['joint_identity']
  with self.assertRaisesRegex(ValueError,'archive'):self.check()
 def test_duplicate_generation_same_length(self):
  self.ledger['generation'][0]=copy.deepcopy(self.ledger['generation'][1])
  with self.assertRaisesRegex(ValueError,'ID sequence'):self.check()
 def test_duplicate_score_same_length(self):
  self.ledger['scores'][0]=copy.deepcopy(self.ledger['scores'][1])
  with self.assertRaisesRegex(ValueError,'ID sequence'):self.check()
 def test_altered_failed_score_routing(self):
  target=next(s for s in self.ledger['scores'] if s['phase']==1 and s['state']=='not_run');target['source_generation_slot']='TAMPER'
  with self.assertRaisesRegex(ValueError,'score ledger'):self.check()
 def test_two_zero_logical_counts_keep_total(self):
  slots=[s for s in self.ledger['generation'] if s['phase']==1];slots[0]['logical_requests_observed']=2;slots[1]['logical_requests_observed']=0
  with self.assertRaisesRegex(ValueError,'exactly one'):self.check()
 def test_snapshot_ancillary_field(self):
  self.ledger['snapshots'][-1]['behavior_diversity']='TAMPER'
  with self.assertRaisesRegex(ValueError,'snapshot'):self.check()
 def test_spurious_phase2_winner(self):
  self.ledger['summary']['winners']['EOH_TC']='TAMPER'
  with self.assertRaisesRegex(ValueError,'winner'):self.check()
if __name__=='__main__':unittest.main(verbosity=2)
