"""Temporary trusted test doubles only; never production evidence or execution."""
import ast, copy, importlib.util, json, pathlib, sys, tempfile, unittest
from types import SimpleNamespace
from unittest.mock import patch
ROOT=pathlib.Path(__file__).resolve().parent.parent
spec=importlib.util.spec_from_file_location('h_phase1',ROOT/'original132_phase1_preparation_20261005/phase1_numerical.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
h.modules()

class HandoffTests(unittest.TestCase):
    def setUp(self):self.temp=tempfile.TemporaryDirectory(prefix='phase1-test-double-');self.root=pathlib.Path(self.temp.name)
    def tearDown(self):self.temp.cleanup()
    def test_exact_pins_and_five_design_inputs(self):
        self.assertEqual(len(h.verify_sources()['source_and_input_files']),280)
        panel,values=h.design_panel();self.assertEqual([x['L1'] for x in panel['instances']],[2012,1983,1978,1986,1980])
        self.assertEqual([h.digest(v) for v in values],[x['input_sha256'] for x in panel['instances']])
    def test_sixty_opaque_sources_prepare_without_host_parse_or_workers(self):
        rows=[];raws={}
        for r in h.read(h.INPUTS/'roster.json')['records']:
            claim=h.read(h.INPUTS/'uncommitted-claims'/(r['slot_id']+'.json'));pack=h.read(h.INPUTS/'packs'/(r['slot_id']+'.json'))
            raw='{Trusted temporary mock '+str(r['order'])+'}\n```python\nNOT PARSABLE SENTINEL\n```'
            capture={'raw':raw,'status':'ok','capture_complete':True,'finish_reason':'stop','tool_calls':[]}
            candidate,observed,fmt=h.modules()['extract'](capture);raws[claim['claim_id']]=raw.encode()
            rows.append({'slot_id':r['slot_id'],'arm':r['arm'],'order':r['order'],'claim':claim,'pack':pack,'capture':capture,'candidate':candidate,'raw_response_sha256':observed,'format_metrics':fmt,'reason':None})
        store=SimpleNamespace(raw=lambda cid:raws[cid],index_identity={'notice':'TEST DOUBLE; NEVER EXTERNAL EVIDENCE'})
        path=self.root/'mock.json';h.write_once(path,{'notice':'TRUSTED TEMPORARY TEST DOUBLE'})
        with patch.object(h,'STATE',self.root/'state'),patch.object(h,'imported_rows',return_value=(store,rows)),patch('ast.parse',side_effect=AssertionError('host AST')),patch('subprocess.Popen',side_effect=AssertionError('process launch')):
            result=h.prepare(path,h.sha(path.read_bytes()))
        plan=h.verify(h.read(self.root/'state/plan.json'))
        self.assertEqual(result['denominator'],60);self.assertEqual(result['textually_extractable'],60)
        self.assertEqual(plan['max_admissions'],60);self.assertEqual(plan['max_candidate_packs'],300)
        self.assertEqual(len(h.read(self.root/'state/registry.json')['slots']),60)
        self.assertEqual(h.read(self.root/'state/deployment.json')['phase'],1)
        self.assertFalse(plan['execution_enabled']);self.assertEqual(list((self.root/'state/runtime_journal').iterdir()),[])
    def test_zero_source_prepare_has_no_registry(self):
        rows=[]
        for r in h.read(h.INPUTS/'roster.json')['records']:
            claim=h.read(h.INPUTS/'uncommitted-claims'/(r['slot_id']+'.json'))
            rows.append({'slot_id':r['slot_id'],'claim':claim,'candidate':None,'raw_response_sha256':h.sha(b''),'reason':'TEST_ONLY_FORMAT_FAILURE'})
        store=SimpleNamespace(raw=lambda _:b'',index_identity={'notice':'TEST DOUBLE'})
        path=self.root/'mock.json';h.write_once(path,{'notice':'TEST DOUBLE'})
        with patch.object(h,'STATE',self.root/'state'),patch.object(h,'imported_rows',return_value=(store,rows)),patch('subprocess.Popen',side_effect=AssertionError('process launch')):
            result=h.prepare(path,h.sha(path.read_bytes()))
        plan=h.read(self.root/'state/plan.json');self.assertEqual(plan['max_candidate_packs'],0);self.assertIsNone(plan['registry_sha256']);self.assertFalse((self.root/'state/registry.json').exists())
    def test_sixty_reservation_cap_and_no_replay(self):
        ids=['TEST'+str(i) for i in range(61)];r=h.Reservations(self.root,ids,60,300)
        for cid in ids[:60]:
            r.worker(cpu_seconds=1,worker_role='admission',execution_id=cid+'/admission')
            for j in range(5):
                r.worker(cpu_seconds=60,worker_role='instance',execution_id=cid+'/instance/'+str(j));r.supervisor(cpu_seconds=60,execution_id=cid+'/instance/'+str(j))
        self.assertEqual(sum(x['cpu_seconds'] for x in r.entries()),36060);self.assertEqual(sum(x['shared_wall_seconds'] for x in r.entries()),27300)
        with self.assertRaisesRegex(ValueError,'cap'):r.worker(cpu_seconds=1,worker_role='admission',execution_id=ids[60]+'/admission')
        with self.assertRaisesRegex(ValueError,'consumed'):r.worker(cpu_seconds=1,worker_role='admission',execution_id=ids[0]+'/admission')
    def test_unknown_attempt_never_calls_backend(self):
        for name in ('attempts','results','bundles','runtime_journal'):(self.root/name).mkdir()
        row={'slot_id':'TEST','claim':{'claim_id':'TEST','sha256':'TEST'},'candidate':{'opaque':'TEST'}};plan={'sha256':'TEST'}
        h.write_once(self.root/'attempts/TEST.json',h.seal({'plan_sha256':'TEST'}))
        class Forbidden:
            def __getattr__(self,*args):raise AssertionError('backend called')
        with patch.object(h,'STATE',self.root),self.assertRaisesRegex(ValueError,'UNKNOWN'):h.get_or_execute(row,plan,Forbidden(),None,None,None,None)
    def test_empty_approval_fails_before_modules(self):
        with patch.object(h,'verify_sources',return_value={'sha256':'TEST'}),patch.object(h,'read',side_effect=[h.seal({'source_input_plan_sha256':'TEST'}),{},h.seal({})]),patch.object(h,'modules',side_effect=AssertionError('runtime called')):
            with self.assertRaisesRegex(ValueError,'activation'):h.run('TEST','TEST','TEST')
    def test_completed_format_failure_replay_needs_no_backend(self):
        for name in ('attempts','results','bundles','runtime_journal'):(self.root/name).mkdir()
        row={'slot_id':'TEST','claim':{'claim_id':'TEST','sha256':'TEST'},'candidate':None,'capture':{'raw':'','status':'TEST_FAILURE'},'format_metrics':{'unique':False,'strict':False},'raw_response_sha256':h.sha(b''),'reason':'TEST'}
        with patch.object(h,'STATE',self.root),patch('subprocess.Popen',side_effect=AssertionError('process launch')):
            one,_=h.get_or_execute(row,{'sha256':'TEST'},None,None,None,None,None);two,_=h.get_or_execute(row,{'sha256':'TEST'},None,None,None,None,None)
        self.assertEqual(one,two)
    def test_partial_terminal_prefix_rejected_before_extract(self):
        roster=h.read(h.INPUTS/'roster.json')['records']
        store=SimpleNamespace(_records={r['claim_id']:{} for r in roster[:23]})
        with patch.object(h,'open_store',return_value=store),self.assertRaisesRegex(ValueError,'all sixty committed'):
            h.imported_rows({}, {})
    def test_fixture_store_cannot_be_production(self):
        from session_store import OfflineFixtureSessionStore
        self.assertFalse(object.__new__(OfflineFixtureSessionStore).durable_external)
    def test_source_safe_phase1_scheduler_metadata_replay(self):
        # Fresh isolated interpreter avoids mixing scheduler and runtime bare imports.
        import subprocess
        code='''import sys,json;from pathlib import Path
sys.path.insert(0,sys.argv[1]);import scheduler_continuation as s
packet=json.loads((s.HERE/'history/scheduler-input.json').read_bytes());original=json.loads((s.HERE/'history/scheduler-ledger.json').read_bytes())
r=s.restore_phase0(packet,original);freeze=json.loads((s.HERE/'inputs/freeze.json').read_bytes());req=s.phase1_requests(r,freeze['input_route_evidence_sha256']);assert len(req)==60
for request,_ in req:r.observe_verified(request['id'],{'status':'TEST_ONLY_TIMEOUT','raw':'','usage':None},{'unique':False,'strict':False,'reason':'TEST_ONLY','candidate':None},[],None)
ledger=r.export();assert ledger['snapshots'][:2]==original['snapshots'];assert len(ledger['generation'])==132 and len(ledger['scores'])==780;assert len(ledger['snapshots'])==4;assert all(x['state']=='planned' for x in ledger['generation'] if x['phase']==2);print('passed')'''
        result=subprocess.run([sys.executable,'-I','-B','-c',code,str(h.HERE)],capture_output=True,text=True,timeout=30)
        self.assertEqual(result.returncode,0,result.stderr)

if __name__=='__main__':unittest.main(verbosity=2)
