# Original 132-slot study, phase-one numerical reception readiness

This directory contains auxiliary read-only checks, a terminal evidence auditor,
and temporary trusted-double tests. It does not alter the frozen study package,
model requests, candidates, evaluator, resource profiles, or scientific protocol.
It does not authorize admission, scoring, or phase-two generation.

## Verified locally on 2026-10-06 UTC

- All 280 source/input byte pins and all 172 package byte pins match.
- All 995 runtime dependency files are present with exact frozen hashes.
- Five original design inputs are present, each 5,000 items, capacity 100.
  Their lower bounds are `[2012,1983,1978,1986,1980]`.
- Frozen runtime hash: `7903fec4a38568000f7dc8901e49cfff6f246529129aacab2c94c179b1d1aeb8`.
- No phase-one production state was created by these checks.
- No candidate AST parsing, admission, score calls, or model calls occurred.
- Ten temporary-double tests cover the 60-source/zero-source preparation paths,
  the 60-admission/300-pack cap, no retry after unknown execution, no launch
  without approval, rejection of a partial terminal prefix, and exact P0/P1
  scheduler boundaries. Temporary doubles are never production evidence.
- The new read-only terminal auditor passed against the existing accepted P0
  evidence (12 terminals, 4 admissions, 20 design packs), without any state edits.

## Exact pending evidence, which must come from the actual producer/Library

These are requirements, not permission to manufacture missing evidence.

1. A final full terminal index for phase one: exactly the 60 roster claims in
   orders 13 through 72, no claimed/in-flight rows. Stable Library identity:
   `libfile_9afab4077ef48191ba90b2adbe95093f`.
2. Its exact externally acknowledged archive, all 60 slots and all six retained
   members per slot, plus `wave-manifest.json` and `file-hashes.json`. Stable
   Library identity: `libfile_221f3504a0d081918fd9aab558c12577`. Final backing
   file IDs, version, byte length and hash must come from the final index.
3. A fresh `authenticated-library-readback-v1` receipt from genuine before /
   materialize / after authenticated calls, showing unchanged exact index identity
   and byte content. It must reference index/archive paths actually readable in
   this dot cloud workspace. Use the current Library transfer helper and keep
   the genuine complete tool results. The frozen `adapter/readback_library.js`
   supplies the accepted orchestration contract; its tool names match the current
   available Library read/materialize tools.
4. Fresh `producer-fence-status-v1` exact stdout from the actual authorized
   producer thread `01a10a11-33a8-7316-9259-215287be30aa`, for that exact final
   index head, showing no pending write or unresolved dispatch fences and the
   confirmed commit receipt. Do not run fence inspection on a copied package.
5. A parent-pinned handoff file with schema `phase1-authenticated-handoff-v1`:
   - `run_id=urp132_20261005_b01_phase1`
   - `freeze_sha256=1e3e0bf30681e13c80747bdc406a05b34190623bab43467b91be6a0aea7ac45e`
   - `scientific_run_id=urp132_20261005_b01`
   - `lineage_sha256=ad18683fa4afe67c8b1722be6058c94a1bd4bb5fecf83490a03851b6452b1c76`
   - Actual `readback_path`, `trusted_readback_sha256`, `fence_path`,
     `trusted_fence_sha256`. Parent retains both genuine evidence digests out of
     band; an adjacent self-hash manifest is not authentication.
6. After preparation, separate parent approval binding the exact resulting
   plan, registry and deployment. No additional user confirmation is implied by
   this internal review gate.

The retained partial snapshots are recovery evidence only. They cannot supply a
full handoff or authorize parent selection. No missing model response is retried.

## Commands, from /workspace/scratch/27470b7a9f17

Read-only readiness at any time:

`python -I -B original132_phase1_evaluation_ready_20261006/readiness.py`

After the parent supplies actual authenticated final evidence and trusted hashes,
optional read-only final intake verification:

`python -I -B original132_phase1_evaluation_ready_20261006/preflight_handoff.py --handoff HANDOFF --handoff-sha256 PARENT_PINNED_HANDOFF_FILE_SHA`

One-time preparation, using the unchanged frozen harness:

`python -I -B original132_phase1_preparation_20261005/phase1_numerical.py prepare --handoff HANDOFF --handoff-sha256 PARENT_PINNED_HANDOFF_FILE_SHA`

Preparation textually extracts responses and creates the one fixed root
`urp132_20261005_b01_phase1_numerical_state`, including `plan.json`, `rows.json`,
`panel.json`, `handoff.json`, `registry.json`, `deployment.json`, and permanent
journal/reservation directories. Registry/deployment are absent only for a
zero-source wave. It never parses or executes candidate code.

If preparation leaves partial state or a run becomes unknown, stop and reconcile.
Do not delete the state, select another root, or repeat an execution blindly.

Parent review must supply a JSON approval with:

- `schema=phase1-execution-approval-v1`, `enabled=true`,
  `parent_review_accepted=true`, `explicit_execution_grant=true`
- `package_manifest_sha256=cbcbadeb1af618098e28c6b2c86c64716b8f7ae8129f987dc7f4987bc7722e8f`
- `run_id=urp132_20261005_b01_phase1`
- Exact prepared `plan_sha256`, `registry_sha256`, `deployment_sha256`,
  `max_admissions`, `max_candidate_packs`
- `controls=0`, `heldout=0`
- `receipt_trust_path` pointing to the existing
  `phase0_numerical_harness_20261005/RECEIPT_TRUST_REVIEW_CANDIDATE.json`
- `receipt_trust_file_sha256=a16084586b4ae388cf0b59b266423d3ee7b68717f69f5e74f1391387265bf388`

Only after that exact approval:

`python -I -B original132_phase1_preparation_20261005/phase1_numerical.py run --plan-file-sha256 PREPARED_PLAN_FILE_SHA --approval PARENT_APPROVAL --approval-sha256 PARENT_PINNED_APPROVAL_FILE_SHA`

The parent must carry forward remaining shared preparation and orchestration
budgets, not reset the original totals of 120 preparation CPU/wall seconds and
600 orchestration CPU / 900 active-bookkeeping wall seconds. Numerical waiting
is separately reserved by instance packs. Original phase-zero actual orchestrator
self CPU was 1.931311679 s, not its 639.9345 s inclusive waiting elapsed time.
A hard inherited CPU ceiling below 60 s prevents the accepted numeric supervisor
from launching. Do not apply a naive short whole-run timeout to 300 packs.
No new outer wrapper, resource amendment, or budget reset is introduced here.

Numerical phase-one ceilings: 60 admissions, 300 five-design-instance packs,
36,060 reserved admission/child/supervisor CPU seconds, 27,300 shared summed wall
seconds. Previous P0 reservations remain 4 admissions/20 packs/2,404 CPU/1,820
shared wall seconds. This phase does not rerun P0, controls, or held-out instances.

After a clean terminal report, run the new auxiliary auditor with the actual
returned report and independently retained exact file hashes:

`python -I -B original132_phase1_evaluation_ready_20261006/audit_terminal.py --report REPORT --report-file-sha256 REPORT_FILE_SHA --approval PARENT_APPROVAL --approval-file-sha256 APPROVAL_FILE_SHA --output NEW_AUDIT_RESULT`

The output path must be new. The auditor refuses a halted/incomplete report and
has no execution capability. Have a separate reviewer check its results before
using the P1 selection for a later generation. No phase-two activation is included.

## Numerical isolation and independent verification

The unchanged runtime admits source only in a bounded subprocess. Each numeric
child is gated by actual PID/executable, one thread, NoNewPrivs, seccomp and frozen
mapped dependency hashes before source delivery. Its numerical child and trusted
packing supervisor each have a 60-CPU-second hard cap and share a 90-second wall
bound; admission is 1 CPU / 5 wall. Existing residual shared-kernel limitations
remain unchanged.

The accepted parent `checker.py` independently walks all 5,000 assignments with
exact integers, checks capacity, remaining state, conservation and used bins.
The bundle retains checker status and assignment SHA, not assignment vectors.
The auxiliary terminal auditor revalidates receipts and journals and independently
recomputes exact Fraction mean(L1 / used_bins), reporting gap, original joint
identity deduplication, frozen tie ordering and P1 survival. It does not claim a
second offline replay of unpersisted assignment vectors.

EOH P1 pools retained EOH P0 plus eligible phase-one offspring, capacity six.
IID keeps the best record from all eligible IID draws through this phase,
capacity one. First order wins duplicate joint identity; remaining distinct
records rank by descending exact fitness, then frozen tie priority, then slot ID.
Incomplete design panels receive no fitness. Full ledgers remain 132 generation
rows and 780 score rows; phase two stays planned and unissued.
