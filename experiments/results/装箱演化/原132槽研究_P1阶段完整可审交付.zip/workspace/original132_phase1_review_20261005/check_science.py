"""Read-only metadata/scientific replay review. No model, parser or numerical execution."""
import collections,hashlib,json,pathlib,sys
ROOT=pathlib.Path(__file__).resolve().parent.parent
P=ROOT/'original132_phase1_preparation_20261005'
sys.path.insert(0,str(P))
from scheduler_continuation import restore_phase0,phase1_requests
from prompts import PUBLIC_RESPONSE_RULE
C=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
H=lambda b:hashlib.sha256(b).hexdigest()
L=lambda n:json.loads((P/n).read_bytes())
def sealed(x):assert x['sha256']==H(C({k:v for k,v in x.items() if k!='sha256'}))
lineage=L('LINEAGE.json');ledger=L('history/scheduler-ledger.json');packet=L('history/scheduler-input.json')
for name,h in lineage['history_file_sha256'].items():assert H((P/'history'/name).read_bytes())==h
for x in (lineage,ledger,L('PLAN.json'),L('RESOURCE_SCOPE.json'),L('inputs/freeze.json'),L('inputs/roster.json')):sealed(x)
assert ledger['sha256']==lineage['original_ledger_sha256']=='4d5fa3ee080ae931a8a52e36769c04781af525a48002b4a4ec42f77398c2ef56'
assert len(ledger['generation'])==132 and len(ledger['scores'])==780
assert sum(x['logical_requests_observed'] for x in ledger['generation'])==12
assert sum(x['state']=='verified' for x in ledger['scores'])==20
assert ledger['snapshots'][0]['survivor_ids']==['b01_EOH_TC_g0_i1_05']
assert ledger['snapshots'][1]['population_size']==1
assert len(ledger['snapshots'][1]['decisions']['eligible_ids'])==3
assert (P/'inputs/config.raw.json').read_bytes()==(ROOT/'urp132_final_phase0_launch_20261005/inputs/config.raw.json').read_bytes()
runner=restore_phase0(packet,ledger)
requests=phase1_requests(runner,L('inputs/freeze.json')['input_route_evidence_sha256'])
roster=L('inputs/roster.json');prov=L('INTERNAL_PARENT_PROVENANCE.json')
assert len(requests)==len(roster['records'])==len(prov['records'])==60
assert [r['order'] for r in roster['records']]==list(range(13,73))
assert collections.Counter(r['arm'] for r in roster['records'])=={'EOH_TC':30,'IID_TC':30}
seen=[];parentcounts=collections.Counter()
for (req,prompt),row,provenance in zip(requests,roster['records'],prov['records']):
 pack=L('inputs/packs/'+row['slot_id']+'.json');claim=L('inputs/uncommitted-claims/'+row['slot_id']+'.json')
 sealed(pack);sealed(claim)
 assert req['id']==row['slot_id']==pack['slot_id']==claim['slot_id']
 assert req['order']==row['order']==pack['order']
 assert req['parents']==row['parents']==pack['parents']==provenance['parents']
 assert req['operator']==row['operator']==pack['operator']
 assert pack['prompt']==prompt['cli_user_prompt']
 assert H(pack['prompt'].encode())==pack['prompt_sha256']==row['prompt_sha256']
 assert H(C(prompt['messages']))==pack['serialized_messages_sha256']==row['serialized_messages_sha256']
 assert H(C(prompt))==pack['source_prompt_artifact_sha256']
 assert pack['prompt'].count(PUBLIC_RESPONSE_RULE)==1
 assert pack['sha256']==row['request_sha256']==claim['request_sha256']
 assert claim['sha256']==row['claim_sha256']
 assert row['actual_cli_payload_bytes']==len(pack['prompt'].encode())
 assert pack['configuration']==L('history/freeze.json')['configuration']
 n=len(req['parents']);parentcounts[(req['arm'],req['operator'],n)]+=1
 marker='\n\nOrdered parent draws (duplicates deliberately preserved):\n'
 assert pack['prompt'].count(marker)==(1 if n else 0)
 if n:
  public=json.loads(pack['prompt'].split(marker)[1].split('\n\n'+runner.public_contract)[0])
  assert len(public)==n and all(set(x)=={'id','description','code','pair_sha256'} for x in public)
  assert all(x['id']=='b01_EOH_TC_g0_i1_05' for x in public)
 else:assert pack['prompt']==json.loads((P/'history/base-artifact.json').read_bytes())[1]['content']
 seen.append(pack['sha256'])
assert L('inputs/EXECUTION_SWITCH.json')['authorized_request_sha256']==seen
assert L('inputs/EXECUTION_SWITCH.json')['enabled'] is False and L('NUMERICAL_SWITCH.json')['enabled'] is False
result={'status':'PASS_SCIENTIFIC_METADATA','original_scientific_freeze':lineage['original_scientific_freeze_sha256'],'operational_freeze':L('inputs/freeze.json')['sha256'],'roster':roster['sha256'],'request_count':60,'orders':[13,72],'parent_counts':[{ 'arm':a,'operator':o,'actual_parent_count':n,'requests':c}for(a,o,n),c in sorted(parentcounts.items())],'public_parent_whitelist_exact':True,'public_response_rule_once':True,'P0_unchanged':True,'phase0_exact_replay':True,'model_calls':0,'candidate_admission_compile_score_calls':0,'heldout_reads':0,'external_writes':0}
print(json.dumps(result,sort_keys=True,indent=2))
