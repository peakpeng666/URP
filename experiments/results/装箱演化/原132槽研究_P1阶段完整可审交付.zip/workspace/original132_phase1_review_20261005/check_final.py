"""Final hash and gate checks only. Synthetic gate is never dispatched or committed."""
import hashlib,json,pathlib,sys
ROOT=pathlib.Path(__file__).resolve().parent.parent
P=ROOT/'original132_phase1_preparation_20261005'
sys.path.insert(0,str(P));import producer_bridge as b
L=lambda n:json.loads((P/n).read_bytes())
H=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
manifest=b.verify_local_package();pins=L('PINS.json');source=L('SOURCE_INPUT_PLAN.json');b.verify(source)
assert pins['package_manifest_sha256']==manifest['sha256']=='cbcbadeb1af618098e28c6b2c86c64716b8f7ae8129f987dc7f4987bc7722e8f'
assert H(P/'PACKAGE_MANIFEST.json')==pins['package_manifest_file_sha256']
assert pins['source_input_plan_sha256']==source['sha256']
for rel,h in source['source_and_input_files'].items():assert H(ROOT/rel)==h,rel
for field,name in [('producer_bridge_file_sha256','producer_bridge.py'),('numerical_bridge_file_sha256','phase1_numerical.py'),('scheduler_continuation_file_sha256','scheduler_continuation.py')]:assert H(P/name)==pins[field]
for kind in ['producer','receiver','adapter']:
 pin=L('source-pins/'+kind+'.json')
 base=P/('exporter' if kind=='producer' else kind)
 for rel,h in pin['files'].items():assert H(base/rel)==h
for name,src in [('retain_library_replies.js','retain_library_replies.js'),('retain_tool_result.py','retain_tool_result.py')]:assert H(P/'retention'/name)==L('retention/INDEPENDENT_AUDIT.json')['reviewed_sha256'][src]
for name in ['scheduler-input','scheduler-ledger']:
 original=next((ROOT/'urp132_20261005_b01_numerical_state').glob(name+'-*.json'))
 assert original.read_bytes()==(P/'history'/(name+'.json')).read_bytes()
plan=L('PLAN.json');roster=L('inputs/roster.json');gate=L('inputs/EXECUTION_SWITCH.json')
assert gate['enabled'] is False and L('NUMERICAL_SWITCH.json')['enabled'] is False
failures=[]
def reject(g,**kw):
 try:b.check_gate(g,plan,roster,**kw)
 except (ValueError,TypeError):return
 raise AssertionError('unsafe gate accepted')
reject(gate);failures.append('disabled gate')
workspace=str(ROOT/'original132_phase1_review_20261005'/'SYNTHETIC_NOT_CREATED')
g=dict(gate,enabled=True,parent_review_accepted=True,package_manifest_sha256=manifest['sha256'],original_head_current_confirmed=True,original_index_blob_sha256=plan['predecessor']['index_blob_sha256'],producer_workspace=workspace,bridge_journal_root=workspace+'/phase1-bridge-journal',storage={'index_library_file_id':'libfile_SYNTHETIC_INDEX_NOT_USED','archive_library_file_id':'libfile_SYNTHETIC_ARCHIVE_NOT_USED'})
b.check_gate(g,plan,roster,root=g['bridge_journal_root'],workspace=workspace,storage=g['storage'])
reject(g,root=workspace+'/another-journal');failures.append('alternate journal')
reject(g,workspace=workspace+'-another');failures.append('alternate workspace')
reject(g,storage={'index_library_file_id':'libfile_SYNTHETIC_OTHER_NOT_USED','archive_library_file_id':'libfile_SYNTHETIC_ARCHIVE_NOT_USED'});failures.append('alternate storage')
reject(dict(g,bridge_journal_root=workspace+'/elsewhere'));failures.append('non-fixed journal basename')
reject(dict(g,producer_workspace=workspace+'/../SYNTHETIC_NOT_CREATED'));failures.append('path alias')
reject(dict(g,authorized_request_sha256=list(reversed(g['authorized_request_sha256']))));failures.append('changed request order')
reject(dict(g,original_head_current_confirmed=False));failures.append('unconfirmed original head')
reject(dict(g,package_manifest_sha256='0'*64));failures.append('changed package pin')
result={'status':'PASS_FINAL_DISABLED_PACKAGE','pins':pins,'manifest_file_count':len(manifest['files']),'source_input_file_count':len(source['source_and_input_files']),'independent_negative_gate_checks':failures,'synthetic_gate_used_only_in_nonexecuting_check_gate':True,'production_authority_or_authentication_claimed':False,'generation_reservations_created':0,'model_calls':0,'candidate_admission_compile_score_calls':0,'heldout_reads':0,'external_writes':0}
print(json.dumps(result,sort_keys=True,indent=2))
