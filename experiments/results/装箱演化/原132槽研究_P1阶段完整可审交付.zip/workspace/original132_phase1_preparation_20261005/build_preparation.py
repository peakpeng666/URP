"""Build disabled phase-one inputs using original scientific state; no live work."""
import copy
import hashlib
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
WORK=HERE.parent
ORIGINAL=WORK/'urp132_final_phase0_launch_20261005/inputs'
STATE=WORK/'urp132_20261005_b01_numerical_state'
COMPAT=WORK/'exporter_receiver_compatibility_20261005'
EXPORTER=WORK/'exporter_v2_received/verified'
RUN='urp132_20261005_b01_phase1'
SCIENTIFIC_RUN='urp132_20261005_b01'
ORIGINAL_FREEZE='3fa177d35b7e9f3989248611f881372f819b264194f2edda0284af1459d332e7'

def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def sha(x):return hashlib.sha256(x).hexdigest()
def seal(x):return dict(x,sha256=sha(canon(x)))
def load(p):return json.loads(Path(p).read_bytes())
def put(name,x):
    p=HERE/name;p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb') as f:f.write(x if isinstance(x,bytes) else canon(x))
def checked_copy(src,dst,expected=None):
    raw=Path(src).read_bytes();assert expected is None or sha(raw)==expected
    put(dst,raw);return sha(raw)


def main():
    assert not (HERE/'PLAN.json').exists(), 'Never rebuild an existing preparation in place'
    original=load(ORIGINAL/'freeze.json');assert original['sha256']==ORIGINAL_FREEZE
    input_packet=next(STATE.glob('scheduler-input-*.json'))
    ledger_path=next(STATE.glob('scheduler-ledger-*.json'))
    ledger=load(ledger_path)
    assert ledger['sha256']=='4d5fa3ee080ae931a8a52e36769c04781af525a48002b4a4ec42f77398c2ef56'
    checked_copy(input_packet,'history/scheduler-input.json')
    checked_copy(ledger_path,'history/scheduler-ledger.json')
    for name in ('base-artifact.json','freeze.json','resource-amendment.json','launch-bindings.json'):
        checked_copy(ORIGINAL/name,'history/'+name)
    checked_copy(STATE/'plan.json','history/numerical-plan.json')
    checked_copy(WORK/'phase0_authenticated_readback_20261005/producer_final/producer-fence-status.stdout.json','history/producer-fence-status.json')
    history_pins={p.name:sha(p.read_bytes()) for p in sorted((HERE/'history').iterdir())}
    producer_pin=load(ORIGINAL/'source-pins/producer.json')
    for name,expected in producer_pin['files'].items():checked_copy(EXPORTER/name,'exporter/'+name,expected)
    for kind,subdir in [('receiver','receiver_revision_v2'),('adapter','durable_session_revision_v1')]:
        pin=load(ORIGINAL/'source-pins'/(kind+'.json'))
        for name,expected in pin['files'].items():checked_copy(COMPAT/subdir/name,kind+'/'+name,expected)
    for name in ('producer.json','receiver.json','adapter.json','runtime-metadata-revision.json'):
        checked_copy(ORIGINAL/'source-pins'/name,'source-pins/'+name)
    for name in ('config.raw.json','base-artifact.json','input-route.json'):
        checked_copy(ORIGINAL/name,'inputs/'+name)
    checked_copy(ORIGINAL/'resource-amendment.json','inputs/resource-amendment.json')
    original_head=load(HERE/'history/producer-fence-status.json')
    lineage=seal({'schema':'original132-phase1-lineage-v1', 'scientific_run_id':SCIENTIFIC_RUN,
        'operational_run_id':RUN, 'original_scientific_freeze_sha256':ORIGINAL_FREEZE,
        'original_ledger_sha256':ledger['sha256'], 'history_file_sha256':history_pins,
        'original_index':{k:original_head[k] for k in ('library_file_id','file_id','current_version_number','index_blob_sha256')},
        'original_phase0_archive':{'library_file_id':'libfile_911c5755e8b081918c4901ff766ee71f','current_version_number':15},
        'namespace_reason':'Accepted V2 index binds all claims to one operational freeze. Preserve original phase0-only freeze/index; create a new phase1 namespace linked to this exact original history.',
        'scientific_scope':'Original orders13..72, original slot IDs and science. Not a new experiment, new randomization, or extra budget.',
        'phase0_generation_denominator':12,'phase0_admitted_candidates':4,'phase0_verified_scores':20,
        'original_index_or_archive_mutation_allowed':False})
    put('LINEAGE.json',lineage)
    resource=seal({'schema':'original132-phase1-resource-scope-v1','scientific_run_id':SCIENTIFIC_RUN,
        'operational_run_id':RUN,'original_resource_amendment_sha256':original['resource_amendment_sha256'],
        'generation_requests':60,'generation_per_arm':30,'configured_completion_tokens_each':32000,
        'configured_completion_tokens_maximum':1920000,'generation_active_window_seconds_each':900,
        'summed_generation_window_reservation_seconds':54000,'maximum_admissions':60,'maximum_design_packs':300,
        'admission_cpu_seconds_each':1,'admission_wall_seconds_each':5,
        'child_cpu_seconds_per_pack':60,'supervisor_cpu_seconds_per_pack':60,'shared_wall_seconds_per_pack':90,
        'maximum_numerical_reserved_cpu_seconds':36060,'maximum_numerical_reserved_shared_wall_seconds':27300,
        'numerical_cpu_includes_child_plus_supervisor_self_not_inclusive_wait4_twice':True,
        'maximum_logical_requests_after_phase1':72,'maximum_candidate_design_packs_after_phase1':320,
        'original_overall_generation_maximum':132,'original_overall_score_maximum':780,
        'original_overall_covered_cpu_reservation':95100,'original_overall_summed_wall_reservation':194220,
        'within_original_run_not_additional_budget':True,'native_CLI_CPU_hard_limit':None,
        'physical_http_attempts':None,'wire_parameters':None,'outer_retries':0,'replacements':0,
        'retained_parent_rescores':0,'controls':0,'holdout':0,'phase2_requests':0,
        'existing_overall_trusted_preparation_and_orchestration_envelopes_shared_not_reset':True,
        'wall_sum_is_not_elapsed_time_forecast':True,'execution_authorized_by_this_file':False})
    put('RESOURCE_SCOPE.json',resource)
    fields={k:copy.deepcopy(original[k]) for k in (
        'cli_binary_sha256','cli_version','cli_exporter_source_sha256','exporter_source_sha256',
        'base_artifact_sha256','input_route_evidence_sha256','session_creation_profile','session_creation_profile_approved',
        'required_system_prompt_sha256','receiver_source_sha256','receiver_source_files','policy_sha256','runtime_sha256',
        'resource_profile_sha256','intake_manifest_sha256','isolation_profile_sha256','checker_sha256',
        'durable_session_adapter','configuration','configured_settings','config_file_sha256','resource_amendment_sha256')}
    fields.update(schema='original132-phase1-operational-freeze-v1',run_id=RUN,scientific_run_id=SCIENTIFIC_RUN,
        phase=1,mode='official_cli',evaluation_mode='registered_source_study',
        status='PREPARED_DISABLED_REQUIRES_PARENT_REVIEW',live_launch_ready=True,
        live_launch_ready_meaning='Unchanged accepted producer route representable; disabled switch still mandatory',
        original_scientific_freeze_sha256=ORIGINAL_FREEZE,lineage_sha256=lineage['sha256'],
        phase1_resource_scope_sha256=resource['sha256'],parent_ledger_sha256=ledger['sha256'],
        parent_snapshot_sha256=ledger['snapshots'][0]['sha256'],
        authorization_scope='Original phase1 orders13..72 only after explicit activation. No phase2 or holdout.',
        final_generation_phase_scope=1,final_generation_dispatch_count=60)
    freeze=seal(fields);put('inputs/freeze.json',freeze)
    # No candidate AST or numerical backend is called by this pure replay.
    from scheduler_continuation import restore_phase0, phase1_requests
    runner=restore_phase0(load(HERE/'history/scheduler-input.json'),ledger)
    requests=phase1_requests(runner,original['input_route_evidence_sha256'])
    sys.path.insert(0,str(HERE/'exporter/src'))
    import protocol_v2 as protocol
    import capture_v2 as capture
    original_i1=load(ORIGINAL/'packs/b01_EOH_TC_g0_i1_01.json')
    base=(HERE/'inputs/base-artifact.json').read_bytes();config=(HERE/'inputs/config.raw.json').read_bytes();route=(HERE/'inputs/input-route.json').read_bytes()
    records=[];parent_records=[]
    for request,prompt in requests:
        slot=request['id']
        pack=seal({'schema':'wave-prompt-pack-v1','run_id':RUN,'slot_id':slot,'phase':1,
            'arm':request['arm'],'operator':request['operator'],'order':request['order'],
            'parents':request['parents'],'parent_snapshot_sha256':request['parent_snapshot_sha256'],
            'parent_pair_hashes':[p['pair_sha256'] for p in request['parent_provenance']],
            'prompt':prompt['cli_user_prompt'],'prompt_sha256':sha(prompt['cli_user_prompt'].encode()),
            'serialized_messages_sha256':prompt['prompt_sha256'],'source_prompt_artifact_sha256':sha(canon(prompt)),
            'configuration':freeze['configuration'],'configuration_sha256':sha(canon(freeze['configuration'])),
            'freeze_sha256':freeze['sha256'],'contains_data_bytes':False,'mode':'official_cli'})
        claim=seal({'schema':'wave-external-claim-v1','run_id':RUN,'slot_id':slot,'phase':1,
            'claim_id':sha(canon(['wave-claim-v1',RUN,slot])),'request_sha256':pack['sha256'],'freeze_sha256':freeze['sha256']})
        checked=capture.check_input(pack,claim,freeze,config,base,route)
        assert prompt['messages'][0]['content']==json.loads(base)[0]['content']
        if request['arm']=='IID_TC':assert pack['prompt']==original_i1['prompt'] and pack['parents']==[]
        put('inputs/packs/'+slot+'.json',pack);put('inputs/uncommitted-claims/'+slot+'.json',claim)
        records.append({'position':len(records)+1,'order':request['order'],'slot_id':slot,'run_id':RUN,
            'arm':request['arm'],'phase':1,'operator':request['operator'],'parents':request['parents'],
            'parent_snapshot_sha256':request['parent_snapshot_sha256'],'claim_id':claim['claim_id'],
            'claim_sha256':claim['sha256'],'request_sha256':pack['sha256'],'freeze_sha256':freeze['sha256'],
            'config_file_sha256':freeze['config_file_sha256'],'prompt_sha256':pack['prompt_sha256'],
            'actual_cli_payload_bytes':len(checked['prompt']),'serialized_messages_sha256':pack['serialized_messages_sha256']})
        parent_records.append({k:copy.deepcopy(request[k]) for k in ('id','order','arm','operator','parents','parent_draw','parent_snapshot_sha256','parent_provenance','tie_priority')})
    roster=seal({'schema':'original132-phase1-fixed-roster-v1','run_id':RUN,'scientific_run_id':SCIENTIFIC_RUN,
        'phase':1,'count':60,'freeze_sha256':freeze['sha256'],'records':records})
    put('inputs/roster.json',roster)
    put('INTERNAL_PARENT_PROVENANCE.json',{'not_model_input':True,'original_ledger_sha256':ledger['sha256'],
        'P0':ledger['snapshots'],'records':parent_records})
    predecessor={'scientific_run_id':SCIENTIFIC_RUN,'freeze_sha256':ORIGINAL_FREEZE,
        'ledger_sha256':ledger['sha256'],'lineage_sha256':lineage['sha256'],**lineage['original_index']}
    put('inputs/index.initial.json',protocol.initial_index(RUN,freeze['sha256'],['EOH_TC','IID_TC'],'official_cli',predecessor))
    plan=seal({'schema':'original132-phase1-continuation-plan-v1','run_id':RUN,'scientific_run_id':SCIENTIFIC_RUN,
        'status':'PREPARED_DISABLED','target_existing_thread_id':'01a10a11-33a8-7316-9259-215287be30aa',
        'freeze_sha256':freeze['sha256'],'roster_sha256':roster['sha256'],'lineage_sha256':lineage['sha256'],
        'resource_scope_sha256':resource['sha256'],'predecessor':predecessor,
        'storage':{'index_library_file_id':None,'archive_library_file_id':None},
        'forbidden_storage_ids':['libfile_c904cc20ec4c81918b438f206e1b60ad','libfile_911c5755e8b081918c4901ff766ee71f'],
        'new_operational_namespace_not_new_scientific_sample':True,
        'generation_calls':0,'admissions':0,'scores':0,'holdout_reads':0,'external_writes':0,
        'generation_switch_enabled':False,'numerical_switch_enabled':False,
        'required_gates':['Independent parent review of continuation bridge and exact input pins',
            'Parent activation bound to final package/source manifest, freeze, roster and sixty requests',
            'Two fresh confirmed storage identities; durable creation acknowledgment retained before optional readback',
            'Producer verifies official CLI binary hash and all accepted source pins in existing executor',
            'Authenticated terminal readback plus producer fence before separate numerical preparation',
            'Parent numeric approval binds exact registry/deployment/plan and bounded runtime receipts'],
        'stop_conditions':['Sixty assigned phase1 positions terminal; select P1 then stop',
            'Unknown write, claim, dispatch, session or runtime outcome: halt and reconcile without replay',
            'Integrity/security/source/identity drift or resource exhaustion: halt; preserve unrun rows',
            'Ordinary candidate/transport/numeric failure consumes its position; no replacements'],
        'quality_based_early_stop':False,'phase2_activation':False,'holdout_activation':False})
    put('PLAN.json',plan)
    put('inputs/EXECUTION_SWITCH.json',{'enabled':False,'freeze_sha256':freeze['sha256'],
        'resource_amendment_sha256':freeze['resource_amendment_sha256'],'authorized_phase':1,
        'authorized_request_sha256':[r['request_sha256'] for r in records],
        'authorized_slot_order':[r['slot_id'] for r in records],'roster_sha256':roster['sha256'],
        'plan_sha256':plan['sha256'],'reason':'Disabled preparation. Parent review and exact activation required.'})
    put('NUMERICAL_SWITCH.json',{'enabled':False,'run_id':RUN,'max_admissions':60,'max_design_packs':300,
        'controls':0,'holdout':0,'reason':'Await authenticated captures, exact registry/deployment and parent approval'})
    put('OFFLINE_BUILD_RESULT.json',{'exact_phase0_ledger_replayed':True,'phase1_inputs_checked':60,
        'order_start':13,'order_end':72,'EOH_count':30,'IID_count':30,'IID_prompt_byte_identical':True,
        'phase0_snapshots_unchanged':True,'phase2_requests':0,'CLI_or_model_calls':0,
        'candidate_AST_calls':0,'admission_workers':0,'score_workers':0,'external_writes':0,
        'generation_switch_enabled':False,'freeze_sha256':freeze['sha256'],'roster_sha256':roster['sha256'],
        'plan_sha256':plan['sha256']})
    print(json.dumps({'freeze_sha256':freeze['sha256'],'roster_sha256':roster['sha256'],'plan_sha256':plan['sha256']}))

if __name__=='__main__':main()
