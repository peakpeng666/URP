"""Local hash manifest construction only; no runtime, candidates or network."""
import difflib,hashlib,json
from pathlib import Path
HERE=Path(__file__).resolve().parent;WORK=HERE.parent

def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def sha(v):return hashlib.sha256(v).hexdigest()
def seal(v):return dict(v,sha256=sha(canon(v)))
def load(p):return json.loads(p.read_bytes())
def put(p,v):p.write_bytes(canon(v))

old=WORK/'phase0_numerical_harness_20261005/phase0.py';new=HERE/'phase1_numerical.py'
(HERE/'NUMERICAL_ADAPTATION.diff').write_text(''.join(difflib.unified_diff(old.read_text().splitlines(True),new.read_text().splitlines(True),fromfile='accepted_phase0.py',tofile='phase1_numerical.py')))
original=load(WORK/'phase0_numerical_harness_20261005/SOURCE_INPUT_PLAN.json')
files=dict(original['source_and_input_files'])
# Keep inherited accepted sources exact. This is byte hashing, never candidate parsing.
for rel,expected in files.items():assert sha((WORK/rel).read_bytes())==expected,rel
for p in sorted(HERE.rglob('*')):
 if p.is_file() and '__pycache__' not in p.parts and p.name not in ('PACKAGE_MANIFEST.json','SOURCE_INPUT_PLAN.json','OFFLINE_TEST_RESULT.json','PINS.json'):
  files[p.relative_to(WORK).as_posix()]=sha(p.read_bytes())
source=seal({'schema':'phase1-source-input-plan-v1','run_id':'urp132_20261005_b01_phase1',
 'scientific_run_id':'urp132_20261005_b01','original_source_input_plan_sha256':original['sha256'],
 'generation_freeze_sha256':load(HERE/'inputs/freeze.json')['sha256'],'runtime_sha256':original['runtime_sha256'],
 'source_and_input_files':files,'design_panel':original['design_panel'],'design_file_sha256':original['design_file_sha256'],
 'phase1_limits':load(HERE/'RESOURCE_SCOPE.json'),'execution_authorized':False,'holdout_access':False})
put(HERE/'SOURCE_INPUT_PLAN.json',source)
packagefiles={p.relative_to(HERE).as_posix():sha(p.read_bytes()) for p in sorted(HERE.rglob('*'))
 if p.is_file() and '__pycache__' not in p.parts and p.name not in ('PACKAGE_MANIFEST.json','OFFLINE_TEST_RESULT.json','PINS.json')}
manifest=seal({'schema':'original132-phase1-package-manifest-v1','status':'PREPARED_DISABLED_PENDING_INDEPENDENT_REVIEW',
 'files':packagefiles,'source_input_plan_sha256':source['sha256'],'model_calls':0,'admissions':0,'score_calls':0,
 'candidate_AST_calls':0,'external_writes':0,'holdout_reads':0})
put(HERE/'PACKAGE_MANIFEST.json',manifest)
put(HERE/'PINS.json',{'freeze_sha256':load(HERE/'inputs/freeze.json')['sha256'],'roster_sha256':load(HERE/'inputs/roster.json')['sha256'],
 'plan_sha256':load(HERE/'PLAN.json')['sha256'],'package_manifest_sha256':manifest['sha256'],
 'package_manifest_file_sha256':sha((HERE/'PACKAGE_MANIFEST.json').read_bytes()),
 'source_input_plan_sha256':source['sha256'],'producer_bridge_file_sha256':sha((HERE/'producer_bridge.py').read_bytes()),
 'numerical_bridge_file_sha256':sha(new.read_bytes()),'scheduler_continuation_file_sha256':sha((HERE/'scheduler_continuation.py').read_bytes())})
print(json.dumps(load(HERE/'PINS.json')))
