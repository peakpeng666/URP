"""Pure phase-one replay over the accepted scheduler; no candidate AST or execution.

The original twelve historical observations are replayed exactly, then the sixty
phase-one requests are reserved in memory. This operation does not issue calls.
"""
import ast
import copy
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
WAVE = WORK / 'URP/experiments/online_bin_packing/eoh_evolution_wave_v1'
RECEIVER = WORK / 'exporter_receiver_compatibility_20261005/receiver_revision_v2'
sys.path[:0] = [str(WAVE), str(RECEIVER)]
from safe_scheduler import SafeRunner
from common import digest, require
from prompts import build_prompt


def forbidden(*args, **kwargs):
    raise RuntimeError('host candidate AST/eval forbidden')


def restore_phase0(packet, expected_ledger):
    ast.parse = forbidden
    import dependencies
    dependencies.core.parse_capture = forbidden
    dependencies.core.identity = forbidden
    require(packet['schema'] == 'phase0-scheduler-packet-v1' and
            packet['mode'] == 'production_verified_receipts', 'production phase-zero history')
    rows, observations = packet['rows'], packet['observations']
    require(len(rows) == len(observations) == 12, 'original twelve denominator')
    panel = copy.deepcopy(packet['panel']); panel['kind'] = 'externally_verified'
    runner = SafeRunner(panel)
    original_messages = json.loads((HERE / 'history/base-artifact.json').read_bytes())
    for expected in rows:
        request = runner.next_request(); pack = expected['pack']
        require(request is not None and request['id'] == expected['slot_id'] == pack['slot_id']
                and request['arm'] == pack['arm'] and request['phase'] == pack['phase'] == 0
                and request['order'] == pack['order'] and pack['parents'] == [], 'frozen historical slot')
        require(hashlib.sha256(pack['prompt'].encode()).hexdigest() == pack['prompt_sha256']
                and original_messages[1]['content'] == pack['prompt']
                and digest(original_messages) == pack['serialized_messages_sha256'], 'historical prompt')
        slot = runner._slot(request['id'])
        slot.update(prompt=copy.deepcopy(original_messages), prompt_sha256=digest(original_messages),
                    configured=copy.deepcopy(pack['configuration']),
                    cli_user_prompt_sha256=pack['prompt_sha256'], actual_pack_sha256=pack['sha256'])
        event = runner._events.pop()
        require(event['kind'] == 'dispatch' and event['payload']['id'] == request['id'], 'dispatch event')
        payload = event['payload']; payload.update(prompt=slot['prompt'],
            prompt_sha256=slot['prompt_sha256'], configured=slot['configured'])
        runner._event('dispatch', payload)
    for expected, obs in zip(rows, observations):
        require(obs['slot_id'] == expected['slot_id'], 'historical observation order')
        runner.observe_verified(obs['slot_id'], obs['capture'], obs['extraction'],
                                obs['scores'], obs['admission'], obs['integrity_error'])
    require(runner.export() == expected_ledger, 'exact original ledger replay')
    require(runner._phase == 1 and runner._halt_reason is None, 'original ready for phase one')
    return runner


def phase1_requests(runner, route_sha256):
    """Keep accepted operator prompt + public parents once; append unchanged rule.

    SafeRunner already embeds whitelisted public parent description/code/identity.
    Passing [] to the receiver builder deliberately avoids inserting them twice.
    No fitness or numerical observations enter any public prompt.
    """
    result = []
    frozen_snapshots = copy.deepcopy(runner._snapshots)
    for order in range(13, 73):
        request = runner.next_request()
        require(request is not None and request['phase'] == 1 and request['order'] == order,
                'exact phase-one schedule')
        parents = [runner._archive[p] for p in request['parents']]
        expected = 0 if request['arm'] == 'IID_TC' else 5 if request['operator'] in ('e1', 'e2') else 1
        require(len(parents) == expected, 'original parent multiplicity')
        if parents:
            require(all(p['id'] == 'b01_EOH_TC_g0_i1_05' for p in parents)
                    and request['parent_draw']['replacement'] is True, 'frozen P0 with replacement')
        marker = '\n\nOrdered parent draws (duplicates deliberately preserved):\n'
        content = request['prompt'][-1]['content']
        require(content.count(marker) == (1 if parents else 0), 'one public parent block only')
        if parents:
            public_json = content.split(marker, 1)[1].split('\n\n' + runner.public_contract, 1)[0]
            public = json.loads(public_json)
            require(public == [{k:p[k] for k in ('id','description','code','pair_sha256')} for p in parents],
                    'exact whitelist projection no scores or diagnostics')
        projected = build_prompt(request['prompt'], [], delivery={'method':'stdin',
            'verified_support':True, 'support_evidence_sha256':route_sha256,
            'max_payload_bytes':1048576})
        result.append((request, projected))
    require(runner._phase == 1 and runner._snapshots == frozen_snapshots,
            'P0 frozen throughout phase one')
    require(runner.next_request() is None, 'wait for all phase-one observations')
    require(all(s['state'] == 'planned' and s['logical_requests_observed'] == 0
                for s in runner._slots if s['phase'] == 2), 'phase two untouched')
    return result


def bind_phase1_dispatch(runner, rows):
    for expected in rows:
        request = runner.next_request(); pack = expected['pack']
        require(request is not None and request['phase'] == 1 and request['id'] == pack['slot_id']
                and request['order'] == pack['order'] and request['parents'] == pack['parents']
                and request['parent_snapshot_sha256'] == pack['parent_snapshot_sha256'], 'phase-one dispatch binding')
        prompt = copy.deepcopy(request['prompt'])
        prompt[-1]['content'] += '\n\n' + __import__('prompts').PUBLIC_RESPONSE_RULE
        require(prompt[-1]['content'] == pack['prompt'] and digest(prompt) == pack['serialized_messages_sha256'],
                'exact regenerated phase-one prompt')
        slot = runner._slot(request['id'])
        slot.update(prompt=prompt, prompt_sha256=digest(prompt), configured=copy.deepcopy(pack['configuration']),
            cli_user_prompt_sha256=pack['prompt_sha256'], actual_pack_sha256=pack['sha256'],
            operational_run_id=pack['run_id'], operational_freeze_sha256=pack['freeze_sha256'])
        event = runner._events.pop(); require(event['kind'] == 'dispatch', 'phase-one dispatch event')
        payload = event['payload']; payload.update(prompt=prompt, prompt_sha256=digest(prompt), configured=slot['configured'])
        runner._event('dispatch', payload)


def reconstruct(packet):
    require(packet['schema'] == 'phase1-scheduler-packet-v1' and
            packet['mode'] == 'production_verified_receipts', 'phase-one packet')
    original = json.loads((HERE / 'history/scheduler-input.json').read_bytes())
    ledger0 = json.loads((HERE / 'history/scheduler-ledger.json').read_bytes())
    runner = restore_phase0(original, ledger0)
    rows, observations = packet['rows'], packet['observations']
    require(len(rows) == len(observations) == 60, 'sixty assigned phase-one observations')
    bind_phase1_dispatch(runner, rows)
    for row, obs in zip(rows, observations):
        require(row['slot_id'] == obs['slot_id'], 'phase-one observation order')
        runner.observe_verified(obs['slot_id'], obs['capture'], obs['extraction'], obs['scores'],
                                obs['admission'], obs['integrity_error'])
    ledger = runner.export()
    require(len(ledger['generation']) == 132 and len(ledger['scores']) == 780, 'original full denominator')
    require(sum(s['logical_requests_observed'] for s in ledger['generation']) == 72, 'no phase-two requests')
    require(ledger['snapshots'][:2] == ledger0['snapshots'], 'P0 immutable')
    if runner._halt_reason is None:
        require(runner._phase == 2 and len(ledger['snapshots']) == 4, 'select P1 only after full phase one')
        require(all(s['state'] == 'planned' for s in ledger['generation'] if s['phase'] == 2), 'phase two remains planned')
    return ledger


def main():
    source = Path(sys.argv[1]); raw = source.read_bytes()
    require(hashlib.sha256(raw).hexdigest() == sys.argv[2] and len(raw) <= 64*1024*1024, 'pinned packet')
    ledger = reconstruct(json.loads(raw))
    with Path(sys.argv[3]).open('x') as stream:
        json.dump(ledger, stream, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'ledger_sha256':ledger['sha256'], 'snapshots':len(ledger['snapshots'])}))

if __name__ == '__main__': main()
