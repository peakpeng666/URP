"""Pure local metadata and synthetic-journal tests. No model or candidate execution."""
import copy,json,sys,tempfile
from pathlib import Path
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import producer_bridge as b
sys.path.insert(0,str(HERE/'exporter/src'))
import protocol_v2 as p
import capture_v2 as c
from scheduler_continuation import restore_phase0, phase1_requests, bind_phase1_dispatch

def reject(fn,label):
    try:fn()
    except (ValueError,RuntimeError):return label
    raise AssertionError('expected rejection: '+label)


def main():
    tests=[];manifest=b.verify_local_package();plan=b.load(HERE/'PLAN.json');roster=b.load(HERE/'inputs/roster.json')
    freeze=b.load(HERE/'inputs/freeze.json');gate=b.load(HERE/'inputs/EXECUTION_SWITCH.json')
    tests.append(reject(lambda:b.check_gate(gate,plan,roster),'disabled generation gate rejects'))
    ledger0=b.load(HERE/'history/scheduler-ledger.json');packet=b.load(HERE/'history/scheduler-input.json')
    runner=restore_phase0(packet,ledger0);requests=phase1_requests(runner,freeze['input_route_evidence_sha256'])
    assert len(requests)==60
    config=(HERE/'inputs/config.raw.json').read_bytes();base=(HERE/'inputs/base-artifact.json').read_bytes();route=(HERE/'inputs/input-route.json').read_bytes()
    rows=[]
    for r,(req,prompt) in zip(roster['records'],requests):
        pack=b.load(HERE/'inputs/packs'/(r['slot_id']+'.json'));claim=b.load(HERE/'inputs/uncommitted-claims'/(r['slot_id']+'.json'))
        c.check_input(pack,claim,freeze,config,base,route)
        assert pack['prompt']==prompt['cli_user_prompt'] and req['parents']==r['parents']
        assert set(r['parents'])<= {'b01_EOH_TC_g0_i1_05'}
        assert req['parent_snapshot_sha256']==r['parent_snapshot_sha256']
        if r['arm']=='IID_TC':assert pack['prompt']==json.loads(base)[1]['content'] and len(r['parents'])==0
        rows.append({'slot_id':r['slot_id'],'pack':pack})
    tests+=['exact original ledger replay','all sixty original orders and prompts reproduced','IID byte identity and EOH whitelisted multiplicities','phase2 remains unreserved']
    # Pure source-safe selection fixture only; these are not experiment captures.
    runner=restore_phase0(packet,ledger0);bind_phase1_dispatch(runner,rows)
    for r in rows:
        runner.observe_verified(r['slot_id'],{'status':'synthetic_offline_timeout','raw':'','usage':None},
            {'unique':False,'strict':False,'reason':'synthetic_offline_fixture','candidate':None},[],None)
    ledger=runner.export()
    assert len(ledger['generation'])==132 and len(ledger['scores'])==780
    assert ledger['snapshots'][:2]==ledger0['snapshots'] and len(ledger['snapshots'])==4
    assert ledger['reserved']['logical_requests']==72 and all(r['state']=='planned' for r in ledger['generation'] if r['phase']==2)
    tests.append('synthetic all-failure wave preserves denominators and P0 then selects P1 without phase2')
    # Synthetic accepted-protocol shapes only, in a temporary fixture directory.
    index=b.load(HERE/'inputs/index.initial.json');storage={'index_library_file_id':'libfile_OFFLINE_INDEX','archive_library_file_id':'libfile_OFFLINE_ARCHIVE'}
    version=1
    def head():
        receipt={'write_result_confirmed':True,'index_readback_confirmed':True,'library_file_id':storage['index_library_file_id'],
            'file_id':'file_OFFLINE_INDEX','current_version_number':version,'local_blob_sha256':b.sha(b.canon(index))}
        status={'schema':'producer-fence-status-v1','observation_kind':'actual_producer_status_tool_stdout',
            'external_write_pending':False,'unresolved_dispatch_fences':0,'library_file_id':receipt['library_file_id'],
            'file_id':receipt['file_id'],'current_version_number':version,'index_blob_sha256':receipt['local_blob_sha256'],
            'run_id':plan['run_id'],'freeze_sha256':plan['freeze_sha256'],'commit_receipt':receipt}
        return receipt,status
    enabled=dict(gate,enabled=True,parent_review_accepted=True,package_manifest_sha256=manifest['sha256'],
        original_head_current_confirmed=True,original_index_blob_sha256=plan['predecessor']['index_blob_sha256'])
    with tempfile.TemporaryDirectory(prefix='phase1-metadata-fixture-') as workspace:
        tmp=str(Path(workspace)/'phase1-bridge-journal')
        enabled.update(producer_workspace=workspace,bridge_journal_root=tmp,storage=storage)
        receipt,status=head()
        tests.append(reject(lambda:b.reserve_next(str(Path(workspace)/'alternate-journal'),plan,roster,index,receipt,storage,p,status,enabled), 'alternate journal root rejected before reservation'))
        bad_storage=dict(storage,index_library_file_id='libfile_OFFLINE_ALTERNATE')
        tests.append(reject(lambda:b.reserve_next(tmp,plan,roster,index,receipt,bad_storage,p,status,enabled), 'alternate storage identities rejected'))
        tests.append(reject(lambda:b.check_gate(enabled,plan,roster,root=tmp,workspace=str(Path(workspace)/'alternate-workspace')), 'alternate producer workspace rejected'))
        for rec in roster['records']:
            receipt,status=head()
            reservation=b.reserve_next(tmp,plan,roster,index,receipt,storage,p,status,enabled)
            assert reservation['record']==rec
            if rec['position']==1:
                tests.append(reject(lambda:b.reserve_next(tmp,plan,roster,index,receipt,storage,p,status,enabled),
                                    'unfinished reservation never replayed'))
            pack=b.load(HERE/'inputs/packs'/(rec['slot_id']+'.json'));claim=b.load(HERE/'inputs/uncommitted-claims'/(rec['slot_id']+'.json'))
            b.verify_reserved(tmp,reservation,plan,pack,claim,freeze,config)
            index,inv=p.claim_index(index,claim,rec['arm'],rec['config_file_sha256']);version+=1
            archive={'write_result_confirmed':True,'remote_bytes_verified':False,'library_file_id':storage['archive_library_file_id'],
                'file_id':'file_OFFLINE_ARCHIVE','current_version_number':rec['position']+1}
            ref={'archive_file_id':archive['file_id'],'archive_version':archive['current_version_number'],
                 'actual_session_id':None,'status':'synthetic_offline_fixture'}
            index=p.terminal_index(index,claim['claim_id'],ref,archive);version+=1
            receipt,status=head();b.finish_position(tmp,reservation,plan,roster,index,receipt,storage,p,status)
        assert b.reserve_next(tmp,plan,roster,index,*head()[:1],storage,p,head()[1],enabled) is None
        assert len(list(Path(tmp).glob('*.reserved.json')))==60
        snapshot=b.status_snapshot(plan,roster,index,receipt,storage,p,status)
        assert snapshot['assigned_denominator']==60 and snapshot['phase1_terminal_requests']==60
    tests+=['sixty once-only synthetic journal positions, no sixty-first','immutable slot order/pack/claim/parent binding','fixed sixty-row status denominator']
    bad=copy.deepcopy(index);bad['predecessor']['ledger_sha256']='0'*64;bad=p.sealed(p.verify_seal(index)|{'predecessor':bad['predecessor']})
    receipt,status=head()
    tests.append(reject(lambda:b.inspect_head(plan,roster,bad,receipt,storage,p,status),'changed scientific predecessor rejected'))
    result={'schema':'original132-phase1-offline-test-result-v1','passed':len(tests),'tests':tests,
        'production_calls':0,'model_calls':0,'candidate_AST_calls':0,'candidate_compile_calls':0,'admissions':0,
        'score_calls':0,'external_writes':0,'holdout_reads':0,'synthetic_receipts_are_not_production_evidence':True,
        'generation_switch_enabled':False,'numerical_switch_enabled':False,'tested_package_manifest_sha256':manifest['sha256']}
    (HERE/'OFFLINE_TEST_RESULT.json').write_bytes(b.canon(result));print(json.dumps(result))

if __name__=='__main__':main()
