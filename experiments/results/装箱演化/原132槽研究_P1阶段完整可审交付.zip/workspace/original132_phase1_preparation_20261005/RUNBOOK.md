# Original 132-slot study: disabled phase-one continuation

This is an operational continuation supplement, not a new scientific trial. Nothing in this package authorizes live work. Original phase-zero files, scientific freeze, index and archive remain immutable. All model, admission and numerical switches are disabled.

## Scope and identities

- Scientific study: `urp132_20261005_b01`
- New operational namespace: `urp132_20261005_b01_phase1`
- Original slots/orders: all 60 phase-one positions, orders 13–72, 30 EOH and 30 IID
- Original scientific freeze: `3fa177d35b7e9f3989248611f881372f819b264194f2edda0284af1459d332e7`
- Original completed scheduler ledger: `4d5fa3ee080ae931a8a52e36769c04781af525a48002b4a4ec42f77398c2ef56`
- Original index is `libfile_c904cc20ec4c81918b438f206e1b60ad` (retained historical version 35); phase-zero archive is `libfile_911c5755e8b081918c4901ff766ee71f` (retained version 15)

The accepted exporter requires one operational freeze per index. The new index explicitly links its predecessor to the original immutable head, scientific freeze and ledger. A historical head is not proof of current clean state. Root must freshly verify the original head and actual producer fence before activation. If the original head has changed, stop for reconciliation rather than silently rebasing.

## Frozen science

Unchanged model/configuration: GLM-5.3 high; temperature 0.7; top_p 0.9; configured completion ceiling 32,000; active generation window 900 seconds; tools disabled; steps 2; no outer retries or fallback. Configuration bytes equal the original high configuration. Configured values are not independently observed wire/server values; physical HTTP counts remain unknown.

The original source-safe scheduler reconstructs phase zero exactly before requesting phase one. EOH P0 contains one member, `b01_EOH_TC_g0_i1_05`, and remains frozen throughout the full wave. e1/e2 draw that parent five times with replacement; m1/m2/m3 draw it once. IID keeps operator i1, zero parents and exact original prompt bytes. Its three eligible archived initial candidates do not imply population capacity three: the retained best record has capacity one.

SafeRunner inserts the public parent block once. The unchanged receiver prompt helper receives an empty additional-parent projection, appending only its unchanged response-size rule. Its helper-local `parent_count=0` does not describe the scheduler's actual parent count; the roster and parent provenance record actual IDs/multiplicity. The exact rendered block is validated against only `id`, `description`, `code`, and `pair_sha256`. Internal fitness/provenance never becomes model input. No diagnostics, follow-on candidates or published EoH code are inserted.

## Generation producer contract

Use only existing authorized producer thread `01a10a11-33a8-7316-9259-215287be30aa`. Materialize the final reviewed package through the current supported Library flow; verify its archive and package-manifest hashes locally. Never read or copy secret values. Verify the accepted CLI binary/version and source pins in that executor.

Root creates a separate activation document from `inputs/EXECUTION_SWITCH.json`, enabling it only after review and adding `parent_review_accepted=true`, the exact `package_manifest_sha256`, `original_head_current_confirmed=true`, and the freshly verified original `original_index_blob_sha256`. The final activation must also pin the exact confirmed `storage` index/archive IDs, canonical absolute `producer_workspace`, and its one `bridge_journal_root=<producer_workspace>/phase1-bridge-journal`. Alternate roots, workspaces, storage identities and symlink aliases are rejected before reservation or dispatch. Finalize activation only after these fresh identities and consumer-local paths are known. The package copy of the disabled switch stays unchanged. Authorization covers only the exact sixty request hashes/order, not arbitrary requests in the new namespace.

Create exactly two fresh confirmed storage identities: phase-one index and phase-one archive. They must differ from both original identities. The initial index bytes are in `inputs/index.initial.json`; an empty phase-one archive may be built with accepted `driver_v2.build_wave_archive(..., phase=1)` before the first claim. Keep confirmed IDs in a separate storage binding. Preserve scientific and operational identities distinctly.

Use unchanged accepted `commitV2` with the exact audited `retainLibraryReplies` wrapper bound as its `tools` argument. Give every commit a unique operation ID. Its `retain_tool_result.py` fsyncs the complete returned tool object BEFORE success checks, xattrs, metadata refresh or index readback. Use this for initial creates and every replacement. Missing, contradictory or uncertain acknowledgments leave the pending fence intact and stop all work; never invent an old receipt or repeat an uncertain create/write. Accepted `external_commit_fence_v2.py` remains unchanged.

Create separate empty producer `state`, `dispatch-fences`, `retained`, audit and bridge-journal directories. For each next position, in original order:

1. Obtain the current confirmed index receipt and actual producer-fence status. `producer_bridge.reserve_next` checks the final package, activation, exact predecessor, roster prefix and permanent journal, then fsyncs a once-only reservation. It reserves one logical request, 32,000 configured completion tokens and 900 generation-window seconds
2. Call `prepare_reserved` around accepted `driver_v2.prepare`. Commit the returned claimed index through the retention-wrapped accepted commit path. No model call precedes the confirmed external claim
3. In the same uninterrupted flow, call `collect_reserved` once around accepted `driver_v2.collect_slot`; retained export/session/config/raw evidence is unchanged. Existing local dispatch fences also forbid replay
4. Build the phase-one archive with the accepted driver, preserving every prior slot and every failed public response. Commit archive, then terminal index, retaining every write acknowledgment before readback
5. Obtain fresh actual producer-fence status and call `finish_position`. Only then may the next reservation be created

An incomplete local reservation, claimed index, unconfirmed write, reused session, unknown process outcome, source/identity mismatch or integrity failure is a global stop, never retry permission. Ordinary authenticated timeout/transport/format/numerical failures consume their planned slots. Do not stop on disappointing or favorable quality. Keep the fixed sixty-row roster and mark all later rows unrun after a global halt. Do not fabricate captures or receipts for unissued positions. On an early generation halt, return exact partial index plus the sixty-row status; numerical preparation below deliberately requires all sixty terminal exports and must not be forced through.

## Numerical continuation after authenticated generation

`phase1_numerical.py` is a narrow phase-specific adaptation of accepted `phase0.py`; `NUMERICAL_ADAPTATION.diff` records all changes. It keeps the same registry, deployment, runtime, source admission, full-assignment checker, journals, receipt bridge and reservation semantics. `scheduler_continuation.py` replaces only the historical twelve-row projection boundary.

After all 60 terminals are durably committed, use the accepted readback/session adapter with fresh authenticated Library results and actual producer fence. Root supplies their exact digests out of band. The handoff schema is `phase1-authenticated-handoff-v1`; supply operational `run_id`, `freeze_sha256`, `readback_path`, `trusted_readback_sha256`, `fence_path`, `trusted_fence_sha256`, plus `scientific_run_id=urp132_20261005_b01` and the exact `lineage_sha256`.

Preparation, without candidate execution:

`python -I -B original132_phase1_preparation_20261005/phase1_numerical.py prepare --handoff <authenticated-handoff.json> --handoff-sha256 <exact file hash>`

This verifies all captures and textually extracts source without AST parsing, freezes a new phase-one registry/deployment and numerical plan, and creates the one fixed numerical journal directory. It does not call admission or score. Root reviews those post-capture bindings before a separate numerical approval.

Numeric approval must have schema `phase1-execution-approval-v1`, `enabled=true`, `parent_review_accepted=true`, exact package manifest semantic hash, `explicit_execution_grant=true`, operational run ID, exact plan semantic hash, registry/deployment hashes, exact max admissions and packs, `controls=0`, `heldout=0`, and the accepted unchanged receipt-trust path/file hash. The accepted receipt trust remains schema `phase0-receipt-trust-v1`; it is a runtime trust contract, not permission to execute phase zero.

Run command, only after that approval:

`python -I -B original132_phase1_preparation_20261005/phase1_numerical.py run --plan-file-sha256 <exact numerical plan file hash> --approval <parent approval.json> --approval-sha256 <exact file hash>`

Root must apply the remaining shared trusted orchestration/preparation envelopes from the original overall run. They are not reset by this operational namespace. Per-worker accepted hard limits and durable phase-one reservations remain enforced. The numerical run allows at most 60 admissions and 300 five-design-instance packs; it does not rescore retained parents, controls or holdout. On restoration, only exact completed journal receipts may be reused; unknown executions halt before new work.

After all phase-one observations, the accepted selection code computes P1 from original exact rational fitness, original joint-identity deduplication and tie priorities. The resulting scientific ledger retains 132 generation rows and 780 score rows, the original P0, all historical failures and the exact 60 new positions. It stops at P1. No phase-two dispatch is implemented by this supplement.

## Resources and interpretation

Maximum phase-one reservations: 60 logical calls, 1,920,000 configured completion tokens, 54,000 generation-window seconds, 60 admissions and 300 numerical packs. Numerical/admission maximum: 36,060 CPU seconds and 27,300 shared wall seconds. Actual consumption is separate, supervisor inclusive wait4 CPU is not added twice, and summed wall reservations are not an elapsed-time forecast. Native model CLI CPU is not covered by numerical CPU caps.

These are within the original 132-generation / 780-score, 95,100 covered-CPU / 194,220 summed-wall envelope. Diagnostic and fixed-candidate follow-on results remain separate evidence. No effort winner or quality improvement is assumed. Report lineage, failures and assigned denominators before interpreting design-set fitness.
