"""Fresh-interpreter projection into the accepted source-safe pure scheduler.

No runtime/backend import; no model client; no candidate AST parsing. Frozen
packs replace only the scheduler's historical prompt/config record, never its
ranking, tie priority, identities, failure policy or arithmetic.
"""
import ast
import copy
import hashlib
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
WAVE=ROOT/'URP/experiments/online_bin_packing/eoh_evolution_wave_v1'
sys.path.insert(0,str(WAVE))
from safe_scheduler import SafeRunner
from common import digest,require


def forbidden(*args,**kwargs):
    raise RuntimeError('host candidate AST/eval forbidden')


def reconstruct(packet):
    ast.parse=forbidden
    # legacy parsing functions are fail-closed, even if future routing changes.
    import dependencies
    dependencies.core.parse_capture=forbidden
    dependencies.core.identity=forbidden
    require(packet['schema']=='phase0-scheduler-packet-v1','packet schema')
    require(packet['mode'] in ('production_verified_receipts','trusted_mock_only'),'packet provenance')
    rows=packet['rows']; observations=packet['observations']
    require(len(rows)==len(observations)==12,'all twelve denominator')
    panel=copy.deepcopy(packet['panel']);panel['kind']='externally_verified' if packet['mode']=='production_verified_receipts' else 'mock'
    runner=SafeRunner(panel)
    # Replay all already-issued phase0 records first, then observations. No request13.
    for expected in rows:
        request=runner.next_request(); pack=expected['pack']
        require(request is not None and request['id']==expected['slot_id']==pack['slot_id'] and
                request['arm']==pack['arm'] and request['phase']==pack['phase']==0 and
                request['order']==pack['order'] and pack['parents']==[], 'frozen scheduler slot')
        require(type(pack['prompt']) is str and hashlib.sha256(pack['prompt'].encode()).hexdigest()==pack['prompt_sha256'],'frozen actual CLI prompt hash')
        actual_messages=json.loads((ROOT/'urp132_final_phase0_launch_20261005/inputs/base-artifact.json').read_bytes())
        require(actual_messages[1]['content']==pack['prompt'] and digest(actual_messages)==pack['serialized_messages_sha256'],'actual system/user mapping')
        slot=runner._slot(request['id'])
        slot.update(prompt=copy.deepcopy(actual_messages),prompt_sha256=digest(actual_messages),configured=copy.deepcopy(pack['configuration']),
                    cli_user_prompt_sha256=pack['prompt_sha256'],actual_pack_sha256=pack['sha256'])
        event=runner._events.pop(); require(event['kind']=='dispatch' and event['payload']['id']==request['id'],'dispatch event')
        payload=event['payload'];payload.update(prompt=slot['prompt'],prompt_sha256=slot['prompt_sha256'],configured=slot['configured'])
        runner._event('dispatch',payload)
    for expected,obs in zip(rows,observations):
        require(obs['slot_id']==expected['slot_id'],'observation order')
        runner.observe_verified(obs['slot_id'],obs['capture'],obs['extraction'],obs['scores'],obs['admission'],obs['integrity_error'])
    ledger=runner.export()
    require(len(ledger['generation'])==132 and len(ledger['scores'])==780,'full finite plan preserved')
    require(sum(x['logical_requests_observed'] for x in ledger['generation'])==12,'no later generation prepared')
    require(all(x['state']!='dispatched' for x in ledger['generation'] if x['phase']==0),'all phase0 terminal')
    return ledger


def main():
    source=Path(sys.argv[1]);raw=source.read_bytes()
    require(hashlib.sha256(raw).hexdigest()==sys.argv[2] and len(raw)<=64*1024*1024,'pinned packet')
    ledger=reconstruct(json.loads(raw))
    with Path(sys.argv[3]).open('x') as stream:
        json.dump(ledger,stream,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False);stream.write('\n')
    print(json.dumps({'ledger_sha256':ledger['sha256'],'snapshots':len(ledger['snapshots'])}))
if __name__=='__main__': main()
