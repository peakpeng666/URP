"""Trusted orchestration mocks only. No real numeric workers or model calls."""
import ast
import copy
from fractions import Fraction
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parent))
import phase0 as h
h.modules()


def load_fixture():
    spec=importlib.util.spec_from_file_location('_accepted_receipt_mocks',h.RECEIVER/'test_bridge.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


class BoundedHarnessTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
    def tearDown(self):self.temp.cleanup()
    def test_exact_five_design_hashes_without_worker(self):
        panel,values=h.design_panel()
        self.assertEqual([x['L1'] for x in panel['instances']],[2012,1983,1978,1986,1980])
        self.assertEqual([x['n'] for x in panel['instances']],[5000]*5)
        self.assertEqual([h.digest(x) for x in values],[x['input_sha256'] for x in panel['instances']])
    def test_exact_sources_and_no_execution_grant(self):
        manifest=h.verify_sources()
        self.assertFalse(manifest['execution_authorized'])
        self.assertEqual(manifest['phase0_limits']['max_instance_packs'],60)
    def test_prepare_seals_exact_registry_with_trusted_import_mock_only(self):
        # Test double replaces the unavailable authenticated input boundary only.
        # Its fake index identity is explicit and never escapes the temp directory.
        from types import SimpleNamespace
        rows=[];raws={}
        for r in h.read(h.INPUTS/'roster.json')['records']:
            claim=h.read(h.INPUTS/'uncommitted-claims'/(r['slot_id']+'.json'))
            pack=h.read(h.INPUTS/'packs'/(r['slot_id']+'.json'))
            raw='{Opaque trusted orchestration mock '+str(r['order'])+'}\n```python\nNOT PARSABLE SENTINEL\n```'
            capture={'raw':raw,'status':'ok','capture_complete':True,'finish_reason':'stop','tool_calls':[]}
            candidate,rawhash,fmt=h.modules()['extract'](capture)
            raws[claim['claim_id']]=raw.encode()
            rows.append({'slot_id':r['slot_id'],'arm':r['arm'],'order':r['order'],'claim':claim,'pack':pack,
                         'capture':capture,'candidate':candidate,'raw_response_sha256':rawhash,'format_metrics':fmt,'reason':None})
        store=SimpleNamespace(raw=lambda cid:raws[cid],index_identity={'notice':'TRUSTED MOCK ONLY, NOT EXTERNAL EVIDENCE'})
        handoff=self.root/'mock_handoff.json';h.write_once(handoff,{'notice':'TRUSTED IMPORT TEST DOUBLE ONLY'})
        state=self.root/'state'
        with patch.object(h,'STATE',state),patch.object(h,'imported_rows',return_value=(store,rows)),patch('ast.parse',side_effect=AssertionError('host parse')),patch('subprocess.Popen',side_effect=AssertionError('worker launch')):
            result=h.prepare(handoff,h.sha(handoff.read_bytes()))
        plan=h.verify(h.read(state/'plan.json'))
        self.assertEqual(result['textually_extractable'],12);self.assertEqual(plan['max_candidate_packs'],60)
        self.assertEqual(len(h.read(state/'registry.json')['slots']),12)
        self.assertEqual(h.read(state/'deployment.json')['wave_freeze_sha256'],h.FREEZE)
        self.assertEqual(list((state/'runtime_journal').iterdir()),[])
        self.assertFalse(plan['execution_enabled'])
    def test_durable_reservations_and_shared_wall(self):
        r=h.Reservations(self.root,['a'],1,5)
        r.worker(cpu_seconds=1,worker_role='admission',execution_id='a/admission')
        for i in range(5):
            r.worker(cpu_seconds=60,worker_role='instance',execution_id='a/instance/'+str(i))
            r.supervisor(cpu_seconds=60,execution_id='a/instance/'+str(i))
        self.assertEqual(sum(x['cpu_seconds'] for x in r.entries()),601)
        self.assertEqual(sum(x['shared_wall_seconds'] for x in r.entries()),455)
        restarted=h.Reservations(self.root,['a'],1,5)
        with self.assertRaisesRegex(ValueError,'consumed'):
            restarted.worker(cpu_seconds=1,worker_role='admission',execution_id='a/admission')
    def test_reservation_rejects_unknown_and_sixth_case(self):
        r=h.Reservations(self.root,['a'],1,5)
        for role,cpu,eid in [('instance',60,'b/instance/0'),('instance',60,'a/instance/5'),('admission',60,'a/admission')]:
            with self.assertRaises(ValueError):r.reserve(role,cpu,eid)
        with self.assertRaisesRegex(ValueError,'before supervisor'):
            r.supervisor(cpu_seconds=60,execution_id='a/instance/0')
        self.assertEqual(r.entries(),[])
    def test_full_phase0_reservation_ceiling(self):
        ids=['x'+str(i) for i in range(13)];r=h.Reservations(self.root,ids,12,60)
        for cid in ids[:12]:
            r.worker(cpu_seconds=1,worker_role='admission',execution_id=cid+'/admission')
            for j in range(5):
                r.worker(cpu_seconds=60,worker_role='instance',execution_id=cid+'/instance/'+str(j))
                r.supervisor(cpu_seconds=60,execution_id=cid+'/instance/'+str(j))
        self.assertEqual(sum(x['cpu_seconds'] for x in r.entries()),7212)
        self.assertEqual(sum(x['shared_wall_seconds'] for x in r.entries()),5460)
        with self.assertRaisesRegex(ValueError,'cap'):
            r.worker(cpu_seconds=1,worker_role='admission',execution_id=ids[12]+'/admission')
    def fixture_row(self):
        f=load_fixture();data=f.fake('registered_source_study')
        return f,data
    def test_bridge_projection_and_accounting_use_only_fabricated_receipts(self):
        f,d=self.fixture_row();bridge,bundle,capture,claim,panel,freeze=d
        candidate,raw,fmt=h.modules()['extract'](capture)
        row={'slot_id':claim['slot_id'],'claim':claim,'capture':capture,'candidate':candidate,'raw_response_sha256':raw,'format_metrics':fmt,'reason':None}
        with patch('ast.parse',side_effect=AssertionError('host parse')):
            projected=h.project(row,bundle,bridge,panel,freeze)
        self.assertEqual(len(projected['scores']),5)
        self.assertTrue(projected['extraction']['unique'])
        accounting=h.account([bundle],[])
        self.assertAlmostEqual(accounting['numerical_cpu_seconds_no_double_count'],
            accounting['admission_cpu_seconds']+accounting['child_cpu_seconds']+accounting['supervisor_self_cpu_seconds'])
        self.assertEqual(accounting['instance_packs'],5)
        self.assertEqual(accounting['score_call_cpu_ns'],5000)
    def test_completed_result_replays_without_backend(self):
        f,d=self.fixture_row();bridge,bundle,capture,claim,panel,freeze=d
        candidate,raw,fmt=h.modules()['extract'](capture)
        row={'slot_id':claim['slot_id'],'claim':claim,'capture':capture,'candidate':candidate,'raw_response_sha256':raw,'format_metrics':fmt,'reason':None}
        for name in ('attempts','results','bundles','runtime_journal'):(self.root/name).mkdir()
        class Mock:
            calls=0
            def bind_capture(self,*a):pass
            def verify(self,*a):self.calls+=1;return bundle
        backend=Mock();plan={'sha256':h.digest('TEST_PLAN')}
        with patch.object(h,'STATE',self.root):
            a,_=h.get_or_execute(row,plan,backend,bridge,panel,freeze,None)
            b,_=h.get_or_execute(row,plan,backend,bridge,panel,freeze,None)
        self.assertEqual(a,b);self.assertEqual(backend.calls,1)
    def test_unknown_attempt_never_retries(self):
        for name in ('attempts','results','bundles','runtime_journal'):(self.root/name).mkdir()
        row={'slot_id':'slot','claim':{'claim_id':'cid','sha256':'claim'},'candidate':{'opaque':'not executable'}}
        plan={'sha256':'plan'}
        h.write_once(self.root/'attempts/cid.json',h.seal({'plan_sha256':'plan'}))
        class Forbidden:
            def __getattr__(self,*a):raise AssertionError('backend access after UNKNOWN')
        with patch.object(h,'STATE',self.root),self.assertRaisesRegex(ValueError,'UNKNOWN'):
            h.get_or_execute(row,plan,Forbidden(),None,None,None,None)
    def test_completed_runtime_receipt_recovers_without_backend(self):
        f,d=self.fixture_row();bridge,bundle,capture,claim,panel,freeze=d
        candidate,raw,fmt=h.modules()['extract'](capture)
        row={'slot_id':claim['slot_id'],'claim':claim,'capture':capture,'candidate':candidate,'raw_response_sha256':raw,'format_metrics':fmt,'reason':None}
        for name in ('attempts','results','bundles','runtime_journal'):(self.root/name).mkdir()
        plan={'sha256':h.digest('TEST_PLAN')};cid=claim['claim_id']
        h.write_once(self.root/'attempts'/(cid+'.json'),h.seal({'plan_sha256':plan['sha256']}))
        token=h.digest(['registry-execution-v1',h.RUN,row['slot_id'],'verify'])
        h.write_once(self.root/'runtime_journal'/(token+'.result.json'),h.seal({'receipt':bundle}))
        class Forbidden:
            def __getattr__(self,*a):raise AssertionError('backend access on completed recovery')
        with patch.object(h,'STATE',self.root):
            saved,recovered=h.get_or_execute(row,plan,Forbidden(),bridge,panel,freeze,None)
        self.assertEqual(recovered,bundle);self.assertEqual(saved['bundle_sha256'],bundle['sha256'])
    def test_parent_approval_required_before_any_runtime_import(self):
        # A forged empty grant fails before the backend or dataset is reachable.
        with patch.object(h,'verify_sources',return_value={'sha256':'sources'}),patch.object(h,'read',side_effect=[
                h.seal({'source_input_plan_sha256':'sources'}),{'schema':'wrong'}]),patch.object(h,'modules',side_effect=AssertionError('premature runtime')):
            with self.assertRaises((ValueError,KeyError)):
                h.run('irrelevant','irrelevant','irrelevant')
    def test_outer_attempt_survives_backend_crash(self):
        for name in ('attempts','results','bundles','runtime_journal'):(self.root/name).mkdir()
        row={'slot_id':'slot','claim':{'claim_id':'cid','sha256':'claim'},'candidate':{'opaque':'not executable'},'raw_response_sha256':'raw'}
        class Broken:
            calls=0
            def bind_capture(self,*a):pass
            def verify(self,*a):self.calls+=1;raise RuntimeError('simulated interruption')
        backend=Broken()
        with patch.object(h,'STATE',self.root):
            with self.assertRaisesRegex(RuntimeError,'interruption'):
                h.get_or_execute(row,{'sha256':'plan'},backend,None,None,None,None)
            with self.assertRaisesRegex(ValueError,'UNKNOWN'):
                h.get_or_execute(row,{'sha256':'plan'},backend,None,None,None,None)
        self.assertEqual(backend.calls,1)
    def test_tampered_receipt_is_not_repaired(self):
        f,d=self.fixture_row();bridge,bundle,capture,claim,panel,freeze=d
        bundle['scores'][0]['used_bins']+=1;bundle=f.sealed(bundle)
        bundle['scores'][0]['evidence']['checker_status']='not_run';bundle=f.sealed(bundle)
        with self.assertRaises(ValueError):bridge.scheduler_observation(bundle,capture,claim,panel,freeze)
    def test_fixture_store_cannot_claim_production(self):
        from session_store import OfflineFixtureSessionStore
        self.assertFalse(object.__new__(OfflineFixtureSessionStore).durable_external)
    def test_zero_source_generation_failure_requires_no_backend(self):
        row={'slot_id':'failed','capture':{'raw':'broken','status':'timeout'},'candidate':None,
             'format_metrics':{'unique':False,'strict':False},'raw_response_sha256':h.sha(b'broken'),'reason':'generation_timeout'}
        result=h.project(row,None,None,None,None)
        self.assertFalse(result['extraction']['unique']);self.assertEqual(result['scores'],[])
    def test_scheduler_fraction_denominator_failure_and_full_plan(self):
        panel={'kind':'mock','instances':[{'instance_index':i,'input_sha256':h.digest(['mock',i]),'n':5000,'capacity':100,'L1':100+i} for i in range(5)]}
        roster=h.read(h.INPUTS/'roster.json')['records'];rows=[];observations=[]
        for ix,r in enumerate(roster):
            pack=h.read(h.INPUTS/'packs'/(r['slot_id']+'.json'))
            rows.append({'slot_id':r['slot_id'],'pack':pack})
            text='OPAQUE MOCK SOURCE NOT PYTHON '+str(ix)
            candidate={'description':'Mock '+str(ix),'code':text,'description_sha256':h.digest('d'+str(ix)),
                'code_sha256':h.sha(text.encode()),'pair_sha256':h.digest(['pair',ix]),
                'code_identity':h.digest(['code',ix]),'joint_identity':h.digest(['joint',ix]),'description_consistency':'undetermined'}
            scores=[]
            if ix!=2:
                for i,inst in enumerate(panel['instances']):
                    failed=ix==3 and i==1
                    scores.append({'kind':'mock','instance_index':i,'input_sha256':inst['input_sha256'],'L1':inst['L1'],
                        'code_sha256':candidate['code_sha256'],'used_bins':None if failed else inst['L1']+10+ix,'outcome':'numeric_failure' if failed else 'ok',
                        'evidence':{'runtime_sha256':h.digest('MOCK_RUNTIME'),'isolation_profile_sha256':h.digest('MOCK_ISOLATION'),
                            'checker_sha256':h.digest('MOCK_CHECKER'),'cleanup_status':'passed','checker_status':'not_run' if failed else 'passed',
                            'assignment_sha256':None if failed else h.digest(['MOCK_ASSIGNMENT',ix,i])}})
                    if failed:break
            observations.append({'slot_id':r['slot_id'],'capture':{'raw':text,'status':'ok','usage':None},
                'extraction':{'unique':ix!=2,'strict':True,'reason':'format_failure' if ix==2 else None,'candidate':None if ix==2 else candidate},
                'scores':scores,'admission':None,'integrity_error':None})
        packet={'schema':'phase0-scheduler-packet-v1','mode':'trusted_mock_only','panel':panel,'rows':rows,'observations':observations}
        path=self.root/'mock_packet.json';h.write_once(path,packet);out=self.root/'mock_ledger.json'
        result=subprocess.run([sys.executable,'-I','-B',str(h.HERE/'scheduler_projection.py'),str(path),h.sha(path.read_bytes()),str(out)],capture_output=True,text=True,timeout=15)
        self.assertEqual(result.returncode,0,result.stderr)
        ledger=h.read(out);self.assertEqual(len(ledger['generation']),132);self.assertEqual(len(ledger['scores']),780)
        self.assertEqual(sum(x['logical_requests_observed'] for x in ledger['generation']),12)
        states=[x['state'] for x in ledger['generation'][:12]]
        self.assertEqual(states.count('generation_failed'),1);self.assertEqual(states.count('evaluation_failed'),1);self.assertEqual(states.count('eligible'),10)
        candidate=next(c for c in ledger['archive'] if c['id']==rows[0]['slot_id'])
        exact=sum((Fraction(100+i,110+i) for i in range(5)),Fraction())/5
        self.assertEqual(candidate['fitness'],{'numerator':exact.numerator,'denominator':exact.denominator})
        self.assertEqual(len(ledger['snapshots']),2)
        self.assertTrue(all(s['phase']==0 for s in ledger['snapshots']))

if __name__=='__main__':unittest.main(verbosity=2)
