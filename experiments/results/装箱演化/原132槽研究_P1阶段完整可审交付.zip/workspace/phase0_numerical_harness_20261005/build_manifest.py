"""Freeze orchestration inputs. Hash-only protocol access; no evaluation."""
import importlib.util
import json
from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import phase0 as h


def main():
    files={}
    def pin(path):
        path=Path(path);files[str(path.relative_to(h.ROOT))]=h.sha(path.read_bytes())
    revision=h.read(h.RUNTIME/'METADATA_REVISION.json')
    for name,expected in revision['source_files'].items():
        p=h.RUNTIME/name;assert h.sha(p.read_bytes())==expected;pin(p)
    pin(h.RUNTIME/'worker_freeze.json');pin(h.RUNTIME/'METADATA_REVISION.json')
    assert h.sha((h.RUNTIME/'worker_freeze.json').read_bytes())==h.RUNTIME_HASH
    for name,expected in h.read(h.INPUTS/'freeze.json')['receiver_source_files'].items():
        p=h.RECEIVER/name;assert h.sha(p.read_bytes())==expected;pin(p)
    for name,expected in h.read(h.ADAPTER/'SOURCE_MANIFEST.json')['files'].items():
        p=h.ADAPTER/name;assert h.sha(p.read_bytes())==expected;pin(p)
    pin(h.ADAPTER/'SOURCE_MANIFEST.json');pin(h.PROTOCOL)
    assert h.sha(h.PROTOCOL.read_bytes())=='ef5efa2f8517ba78603fdf4e6a619590345d55ef4dd5e417ebfa1283e0bb2665'
    wave=h.BASE/'eoh_evolution_wave_v1'
    for name in ('safe_scheduler.py','common.py','contracts.py','dependencies.py','dependency_lock.json'):
        pin(wave/name)
    for name,expected in h.read(wave/'dependency_lock.json').items():
        p=h.BASE/name;assert h.sha(p.read_bytes())==expected;pin(p) # no JSON parse of old protocol
    for p in h.INPUTS.rglob('*'):
        if p.is_file():pin(p)
    pin(h.DESIGN)
    assert h.sha(h.DESIGN.read_bytes())==h.DESIGN_HASH
    for name in ('phase0.py','scheduler_projection.py','test_phase0.py','build_manifest.py'):
        pin(HERE/name)
    panel,_=h.design_panel()
    value=h.seal({'schema':'phase0-source-input-plan-v1','run_id':h.RUN,
        'generation_freeze_sha256':h.FREEZE,'final_generation_zip_sha256':h.FINAL_ZIP_HASH,
        'runtime_sha256':h.RUNTIME_HASH,'source_and_input_files':files,
        'design_panel':panel,'design_path':str(h.DESIGN),'design_file_sha256':h.DESIGN_HASH,
        'phase0_limits':{'denominator':12,'max_admission_workers':12,'max_instance_packs':60,
            'child_cpu_seconds_per_pack':60,'supervisor_cpu_seconds_per_pack':60,'shared_wall_seconds_per_pack':90,
            'admission_cpu_seconds':1,'admission_wall_seconds':5,'max_phase0_reserved_cpu_seconds':7212,
            'max_phase0_reserved_wall_seconds':5460,'controls':0,'confirmation':0,'retained_parent_rescores':0},
        'whole_study_envelope':{'generation':132,'candidate_design':660,'controls':20,'confirmation':100,
            'total_packs':780,'trusted_numerical_cpu_reservation':95100,'summed_wall_reservation':194220,
            'resource_amendment_sha256':'e04c5ae99f72d8b09c5edeaba5a9da732a9cd21c85c6c06d97356813bcd98c70'},
        'historical_fixed5000_evidence_archive_sha256':'df50efdb0c3be20d31d56d500bb50222e19b9013320db59f9876ae5b9f86ded1',
        'source_provenance':'model_response only in actual execution; trusted mocks separate',
        'holdout_access':'No current holdout data or seed access; old protocol hashed only by executable path',
        'execution_authorized':False})
    (HERE/'SOURCE_INPUT_PLAN.json').write_text(h.canonical(value)+'\n')
    print(h.canonical({'source_input_plan_sha256':value['sha256'],'file_count':len(files)}))

if __name__=='__main__':main()
