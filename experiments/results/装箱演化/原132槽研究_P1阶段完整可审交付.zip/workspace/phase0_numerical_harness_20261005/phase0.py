"""Bounded phase-0 orchestration. No model client or host candidate parser.

prepare: authenticated import + byte extraction + registry/deployment proposal.
run: parent-pinned, explicitly authorized accepted-runtime execution only.
replay: the same run path reuses completed journal receipts, never unknown work.
"""
import argparse
import copy
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
BASE = ROOT / 'URP/experiments/online_bin_packing'
RUNTIME = ROOT / 'exporter_receiver_compatibility_20261005/runtime_revision_v3'
RECEIVER = ROOT / 'exporter_receiver_compatibility_20261005/receiver_revision_v2'
ADAPTER = ROOT / 'exporter_receiver_compatibility_20261005/durable_session_revision_v1'
PROTOCOL = ROOT / 'exporter_v2_received/verified/src/protocol_v2.py'
INPUTS = ROOT / 'urp132_final_phase0_launch_20261005/inputs'
DESIGN = BASE / 'paper_scale_dag_evaluator_v1/data/design_5000.json'
RUN = 'urp132_20261005_b01'
WAVE = RUN + '-phase0'
FREEZE = '3fa177d35b7e9f3989248611f881372f819b264194f2edda0284af1459d332e7'
RUNTIME_HASH = '7903fec4a38568000f7dc8901e49cfff6f246529129aacab2c94c179b1d1aeb8'
DESIGN_HASH = '5358c41aa758e1d399d29157f8cbdc5fb422f4c8acd56b2cb95c41af3f1750ca'
FINAL_ZIP_HASH = '350d2a7c7f9817522502315cf05cab2c8000a110b4b759d775b0182a2c5c9495'
# A single fixed journal location for this run, never caller-selectable.
STATE = ROOT / 'urp132_20261005_b01_numerical_state'


def need(ok, reason):
    if not ok:
        raise ValueError(reason)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def digest(value):
    return sha(canonical(value).encode())


def seal(value):
    need(type(value) is dict and 'sha256' not in value, 'seal fields')
    return dict(value, sha256=digest(value))


def verify(value):
    obj = dict(value)
    expected = obj.pop('sha256', None)
    need(digest(obj) == expected, 'seal mismatch')
    return value


def read(path, expected=None, cap=64*1024*1024):
    path = Path(path)
    need(path.is_file() and not path.is_symlink() and path.stat().st_size <= cap, 'input file bounds')
    raw = path.read_bytes()
    need(len(raw) <= cap and (expected is None or sha(raw) == expected), 'input file hash')
    return json.loads(raw)


def write_once(path, value):
    path = Path(path)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write((canonical(value)+'\n').encode()); stream.flush(); os.fsync(stream.fileno())
    fd = os.open(str(path.parent), os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def same_or_write(path, value):
    if Path(path).exists():
        need(read(path) == value, 'existing artifact differs; no overwrite')
    else:
        write_once(path, value)


def verify_sources():
    manifest = verify(read(HERE / 'SOURCE_INPUT_PLAN.json'))
    for rel, expected in manifest['source_and_input_files'].items():
        p = ROOT / rel
        need(p.is_file() and sha(p.read_bytes()) == expected, 'frozen source/input: '+rel)
    need(sha((ROOT/'urp132_FINAL_PHASE0_GENERATION_20261005T1339Z.zip').read_bytes()) == FINAL_ZIP_HASH, 'generation ZIP')
    need(sha((RUNTIME/'worker_freeze.json').read_bytes()) == RUNTIME_HASH, 'runtime identity')
    return manifest


def modules():
    # Fresh interpreter; never mix the scheduler's bare dependencies/runner modules.
    for name in ('registry', 'policy', 'resource_profile', 'deployment', 'dependencies', 'runner', 'backend'):
        previous = sys.modules.get(name)
        need(previous is None or Path(previous.__file__).parent == RUNTIME, 'mixed runtime module '+name)
    sys.path[:0] = [str(RECEIVER), str(ADAPTER), str(RUNTIME)]
    from registry import freeze_wave, FrozenRegistry, ExecutionJournal
    from deployment import DeploymentFreeze
    from bridge import extract, ReceiptBridge
    from capture_v2 import CaptureImporter
    from session_store import CommittedSessionStore
    return locals()


def design_panel():
    data = read(DESIGN, DESIGN_HASH)
    need(data['set'] == 'historical_design_5k' and data['capacity'] == 100 and
         data['source_sha256'] == '97b77d4d5f98a32b46240e18a85c99d39f5fd5cfea4df83782abe330a7b21fd5', 'exact teacher design')
    cases = data['cases']
    need(len(cases) == 5 and [x['id'] for x in cases] == list(range(5)), 'ordered five cases')
    instances, values = [], []
    for i, case in enumerate(cases):
        items = case['items']
        need(len(items) == 5000 and all(type(x) is int and 1 <= x <= 100 for x in items), 'design domain')
        value = {'items': items, 'capacity': 100}
        values.append(value)
        instances.append({'instance_index': i, 'input_sha256': digest(value), 'n': 5000,
                          'capacity': 100, 'L1': (sum(items)+99)//100})
    need([x['L1'] for x in instances] == [2012,1983,1978,1986,1980], 'design lower bounds')
    return {'kind': 'registered_source_study', 'instances': instances}, values


def open_store(handoff, m):
    need(handoff['schema'] == 'phase0-authenticated-handoff-v1' and handoff['run_id'] == RUN
         and handoff['freeze_sha256'] == FREEZE, 'handoff scope')
    store = m['CommittedSessionStore'].from_readback(
        readback_path=handoff['readback_path'], trusted_readback_sha256=handoff['trusted_readback_sha256'],
        fence_path=handoff['fence_path'], trusted_fence_sha256=handoff['trusted_fence_sha256'],
        freeze_path=INPUTS/'freeze.json', expected_run_id=RUN,
        expected_freeze_sha256=FREEZE, protocol_path=PROTOCOL)
    need(type(store) is m['CommittedSessionStore'] and store.durable_external is True
         and store.external_backing_verified is True, 'actual official external store required')
    return store


def imported_rows(handoff, m):
    store = open_store(handoff, m)
    roster = read(INPUTS/'roster.json')['records']
    need(len(roster) == 12 and sorted(x['order'] for x in roster) == list(range(1,13)), 'exact phase0 roster')
    need(set(store._records) == {x['claim_id'] for x in roster}, 'all twelve committed; no extra slots')
    rows = []
    for r in sorted(roster, key=lambda x: x['order']):
        claim = verify(read(INPUTS/'uncommitted-claims'/ (r['slot_id']+'.json')))
        pack = verify(read(INPUTS/'packs'/(r['slot_id']+'.json')))
        need(store._records[r['claim_id']]['claim'] == claim, 'independent committed claim')
        need(claim['sha256'] == r['claim_sha256'] and claim['request_sha256'] == pack['sha256'] == r['request_sha256'], 'frozen request')
        capture = store.import_capture(r['claim_id'], m['CaptureImporter'])
        raw = store.raw(r['claim_id'])
        need(raw == capture['raw'].encode('utf-8'), 'exact raw imported bytes')
        row = {'slot_id': r['slot_id'], 'arm': r['arm'], 'order': r['order'], 'claim': claim,
               'pack': pack, 'capture': capture, 'raw_response_sha256': sha(raw), 'candidate': None,
               'format_metrics': {'unique': False, 'strict': False}, 'reason': None}
        try:
            candidate, observed_raw, metrics = m['extract'](capture)
            need(observed_raw == sha(raw), 'extract raw hash')
            row.update(candidate=candidate, format_metrics=metrics)
        except (ValueError, KeyError, TypeError, UnicodeError) as exc:
            # Authenticated generation/format failure consumes the denominator; no repair.
            row['reason'] = 'generation_format:' + str(exc)
        rows.append(row)
    return store, rows


def prepare(handoff_path, handoff_sha):
    source_plan = verify_sources()
    handoff = read(handoff_path, handoff_sha)
    m = modules(); store, rows = imported_rows(handoff, m)
    freeze = verify(read(INPUTS/'freeze.json')); need(freeze['sha256'] == FREEZE, 'common generation freeze')
    panel, _ = design_panel()
    STATE.mkdir(mode=0o700, exist_ok=False)
    for name in ('runtime_journal', 'attempts', 'reservations', 'bundles', 'results'):
        (STATE/name).mkdir(mode=0o700)
    write_once(STATE/'handoff.json', handoff)
    write_once(STATE/'rows.json', rows)
    write_once(STATE/'panel.json', panel)
    source_slots = [(r['candidate'], r['claim'], store.raw(r['claim']['claim_id'])) for r in rows if r['candidate'] is not None]
    registry = deployment = None
    if source_slots:
        registry = m['freeze_wave'](STATE/'registry.json', batch_id=RUN, wave_id=WAVE, phase=0,
            runtime_freeze_sha256=RUNTIME_HASH, slots=source_slots, source_origin='model_response',
            resource_profile_sha256=freeze['resource_profile_sha256'])
        deployment = seal({'schema':'candidate-deployment-freeze-v2', 'mode':'registered_source_study',
            'source_origin':'model_response', 'registry_sha256':registry['sha256'], 'wave_freeze_sha256':FREEZE,
            'batch_id':RUN, 'wave_id':WAVE, 'phase':0, 'runtime_freeze_sha256':RUNTIME_HASH,
            **{k:freeze[k] for k in ('policy_sha256','resource_profile_sha256','isolation_profile_sha256','checker_sha256','intake_manifest_sha256')}})
        write_once(STATE/'deployment.json', deployment)
        m['DeploymentFreeze'](STATE/'deployment.json', deployment['sha256']).validate(
            m['FrozenRegistry'](STATE/'registry.json', registry['sha256']), freeze)
    plan = seal({'schema':'phase0-numerical-plan-v1', 'run_id':RUN, 'wave_id':WAVE, 'phase':0,
        'generation_freeze_sha256':FREEZE, 'source_input_plan_sha256':source_plan['sha256'],
        'handoff_file_sha256':sha((STATE/'handoff.json').read_bytes()),
        'rows_file_sha256':sha((STATE/'rows.json').read_bytes()), 'panel_file_sha256':sha((STATE/'panel.json').read_bytes()),
        'registry_sha256':registry['sha256'] if registry else None,
        'deployment_sha256':deployment['sha256'] if deployment else None,
        'runtime_sha256':RUNTIME_HASH, 'journal_root':str(STATE/'runtime_journal'),
        'index_identity':store.index_identity, 'denominator':12, 'candidate_source_count':len(source_slots),
        'max_admissions':len(source_slots), 'max_candidate_packs':5*len(source_slots),
        'controls_this_run':0, 'heldout_this_run':0, 'retained_parent_rescores':0,
        'source_manifest':[{'slot_id':r['slot_id'], 'claim_sha256':r['claim']['sha256'],
             'raw_response_sha256':r['raw_response_sha256'],
             'source_sha256':r['candidate']['code_sha256'] if r['candidate'] else None,
             'description_sha256':r['candidate']['description_sha256'] if r['candidate'] else None,
             'extraction_failure':r['reason']} for r in rows],
        'execution_enabled':False})
    write_once(STATE/'plan.json', plan)
    return {'status':'prepared_not_executed', 'plan_path':str(STATE/'plan.json'),
            'plan_file_sha256':sha((STATE/'plan.json').read_bytes()), 'plan_seal':plan['sha256'],
            'registry_seal':plan['registry_sha256'], 'deployment_seal':plan['deployment_sha256'],
            'textually_extractable':len(source_slots), 'denominator':12}


class Reservations:
    """One durable role reservation before each accepted runtime launch.

    Shared wall is charged once to instance, never twice to child+supervisor.
    Caller holds the run lock. Exclusive claim files survive process death.
    """
    def __init__(self, root, claim_ids, max_admissions, max_packs):
        self.root = Path(root); self.claim_ids = set(claim_ids)
        self.max_admissions, self.max_packs = max_admissions, max_packs
    def entries(self):
        return [verify(read(p)) for p in sorted(self.root.glob('*.json'))]
    def reserve(self, role, cpu_seconds, execution_id):
        parts = execution_id.split('/')
        need(parts[0] in self.claim_ids, 'reservation candidate')
        if role == 'admission':
            need(parts[1:] == ['admission'] and cpu_seconds == 1, 'admission reservation')
            wall = 5
        else:
            need(role in ('instance','supervisor') and len(parts) == 3 and parts[1] == 'instance'
                 and parts[2] in ('0','1','2','3','4') and cpu_seconds == 60, 'instance reservation')
            wall = 90 if role == 'instance' else 0
        rows = self.entries()
        need(not any(x['role']==role and x['execution_id']==execution_id for x in rows), 'reservation consumed; no retry')
        limit = self.max_admissions if role=='admission' else self.max_packs
        need(sum(x['role']==role for x in rows) < limit, 'phase0 reservation cap')
        if role == 'supervisor':
            need(any(x['role']=='instance' and x['execution_id']==execution_id for x in rows), 'shared instance before supervisor')
        # 12 + 60*(60+60) CPU, 12*5 + 60*90 wall; part of global envelope.
        need(sum(x['cpu_seconds'] for x in rows)+cpu_seconds <= 7212, 'phase0 CPU cap')
        need(sum(x['shared_wall_seconds'] for x in rows)+wall <= 5460, 'phase0 wall cap')
        value = seal({'schema':'phase0-resource-reservation-v1','role':role,'execution_id':execution_id,
                      'cpu_seconds':cpu_seconds,'shared_wall_seconds':wall})
        write_once(self.root/(digest([role,execution_id])+'.json'), value)
    def worker(self, *, cpu_seconds, worker_role, execution_id):
        self.reserve(worker_role, cpu_seconds, execution_id)
    def supervisor(self, *, cpu_seconds, execution_id):
        self.reserve('supervisor', cpu_seconds, execution_id)


def receipt_bridge(plan, trust, m):
    need(trust['schema']=='phase0-receipt-trust-v1' and trust['runtime_freeze_sha256']==RUNTIME_HASH, 'receipt trust identity')
    return m['ReceiptBridge'](verify(read(STATE/'registry.json')), registry_sha256=plan['registry_sha256'],
        run_id=RUN, phase=0, wave_id=WAVE, policy=trust['policy'], policy_sha256=trust['policy_sha256'],
        runtime_freeze_sha256=trust['runtime_freeze_sha256'], manifest_sha256=trust['manifest_sha256'],
        api_names=trust['api_names'], expected_security=trust['expected_security'],
        expected_limits=trust['expected_limits'], handwritten_source_hashes=[],
        deployment_document=verify(read(STATE/'deployment.json')), deployment_sha256=plan['deployment_sha256'])


def project(row, bundle, bridge, panel, freeze):
    if row['candidate'] is None:
        return {'slot_id':row['slot_id'], 'capture':row['capture'],
            'extraction':dict(row['format_metrics'],raw_sha256=row['raw_response_sha256'],reason=row['reason'],candidate=None),
            'scores':[], 'admission':None, 'integrity_error':None}
    observation = bridge.scheduler_observation(bundle, row['capture'], row['claim'], panel, freeze)
    candidate = observation['candidate']
    return {'slot_id':row['slot_id'], 'capture':row['capture'],
        'extraction':dict(observation['format_metrics'], raw_sha256=row['raw_response_sha256'],
            unique=candidate is not None, reason=None if candidate else 'admission_'+observation['admission']['kind'], candidate=candidate),
        'scores':observation['scores'], 'admission':observation['admission'], 'integrity_error':None}


def get_or_execute(row, plan, backend, bridge, panel, freeze, journal_class):
    cid = row['claim']['claim_id']; attempt = STATE/'attempts'/(cid+'.json')
    result = STATE/'results'/(cid+'.json'); bundle_path = STATE/'bundles'/(cid+'.json')
    if result.exists():
        saved = verify(read(result))
        need(saved['plan_sha256']==plan['sha256'] and saved['claim_sha256']==row['claim']['sha256'], 'saved result identity')
        bundle = verify(read(bundle_path)) if row['candidate'] else None
        need(saved['bundle_sha256']==(bundle['sha256'] if bundle else None), 'saved exact bundle identity')
        projected = project(row,bundle,bridge,panel,freeze)
        need(saved['observation']==projected, 'saved result re-verification')
        return saved, bundle
    if attempt.exists():
        # An exact completed accepted-runtime journal may be recovered read-only.
        prior = verify(read(attempt)); need(prior['plan_sha256']==plan['sha256'], 'attempt plan')
        token = digest(['registry-execution-v1',RUN,row['slot_id'],'verify'])
        receipt_path = STATE/'runtime_journal'/(token+'.result.json')
        need(row['candidate'] is not None and receipt_path.exists(), 'UNKNOWN verification; resolve without rerun')
        receipt = verify(read(receipt_path))['receipt']
        need('terminal_failure' not in receipt, 'terminal runtime integrity failure; no retry')
        bundle = verify(receipt)
    else:
        write_once(attempt,seal({'schema':'phase0-verification-attempt-v1','run_id':RUN,'claim_id':cid,
                                'claim_sha256':row['claim']['sha256'],'plan_sha256':plan['sha256']}))
        if row['candidate'] is None:
            bundle = None
        else:
            # Accepted runtime reserves its own permanent verification claim before admission.
            backend.bind_capture(row['claim'], row['raw_response_sha256'])
            bundle = backend.verify(copy.deepcopy(row['candidate']), copy.deepcopy(row['claim']),copy.deepcopy(panel),copy.deepcopy(freeze))
    if bundle is not None:
        same_or_write(bundle_path,bundle)
    observation = project(row,bundle,bridge,panel,freeze)
    value = seal({'schema':'phase0-verified-observation-v1','plan_sha256':plan['sha256'],
                  'claim_sha256':row['claim']['sha256'],'bundle_sha256':bundle['sha256'] if bundle else None,'observation':observation})
    write_once(result,value)
    return value,bundle


def account(bundles, reservations):
    result={'admissions':0,'instance_packs':0,'admission_cpu_seconds':0.,'child_cpu_seconds':0.,
            'supervisor_self_cpu_seconds':0.,'supervisor_inclusive_wait4_cpu_seconds':0.,
            'score_call_cpu_ns':0,'shared_instance_wall_seconds':0.}
    for b in bundles:
        result['admissions']+=1
        result['admission_cpu_seconds']+=b['admission']['worker']['cpu_seconds']
        for row in b['scores']:
            worker=row['evidence']['worker']; supervisor=row['evidence']['supervisor']
            result['instance_packs']+=1
            result['child_cpu_seconds']+=worker['cpu_seconds']
            result['supervisor_self_cpu_seconds']+=supervisor['actual_supervisor_cpu_seconds']
            result['supervisor_inclusive_wait4_cpu_seconds']+=supervisor['wait4_cpu_seconds']
            result['score_call_cpu_ns']+=worker['score_call_cpu_ns']
            result['shared_instance_wall_seconds']+=supervisor['wall_seconds']
    result['numerical_cpu_seconds_no_double_count']=result['admission_cpu_seconds']+result['child_cpu_seconds']+result['supervisor_self_cpu_seconds']
    result['score_timing_scope']='function call including facade; excludes prep/check/serialization; already inside child CPU'
    result['inclusive_wait4_not_added_again']=True
    result['reserved_cpu_seconds']=sum(x['cpu_seconds'] for x in reservations)
    result['reserved_shared_wall_seconds']=sum(x['shared_wall_seconds'] for x in reservations)
    return result


def run(plan_sha, approval_path, approval_sha):
    start=time.monotonic(); cpu0=time.process_time(); sources=verify_sources()
    plan=verify(read(STATE/'plan.json',plan_sha)); need(plan['source_input_plan_sha256']==sources['sha256'], 'source-plan agreement')
    approval=read(approval_path,approval_sha)
    need(approval['schema']=='phase0-execution-approval-v1' and approval['explicit_execution_grant'] is True
         and approval['plan_sha256']==plan['sha256'] and approval['run_id']==RUN
         and approval['registry_sha256']==plan['registry_sha256'] and approval['deployment_sha256']==plan['deployment_sha256']
         and approval['max_admissions']==plan['max_admissions'] and approval['max_candidate_packs']==plan['max_candidate_packs']
         and approval['controls']==0 and approval['heldout']==0, 'exact parent execution grant required')
    need(plan['journal_root']==str(STATE/'runtime_journal') and plan['denominator']==12
         and 0<=plan['max_admissions']<=12 and 0<=plan['max_candidate_packs']<=60, 'fixed execution scope')
    trust=read(approval['receipt_trust_path'],approval['receipt_trust_file_sha256'])
    m=modules(); handoff=read(STATE/'handoff.json',plan['handoff_file_sha256'])
    store, rows=imported_rows(handoff,m); need(rows==read(STATE/'rows.json',plan['rows_file_sha256']), 'import restoration agreement')
    panel,instances=design_panel(); need(panel==read(STATE/'panel.json',plan['panel_file_sha256']), 'exact frozen panel')
    freeze=verify(read(INPUTS/'freeze.json'))
    need(freeze['sha256']==FREEZE, 'exact common freeze')
    lock=(STATE/'run.lock').open('a+b'); fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    # Unknown state blocks the entire resumed wave before any new candidate is launched.
    for p in (STATE/'attempts').glob('*.json'):
        cid=p.stem
        if not (STATE/'results'/(cid+'.json')).exists():
            row=next((r for r in rows if r['claim']['claim_id']==cid),None)
            need(row is not None, 'unknown attempt identity')
            token=digest(['registry-execution-v1',RUN,row['slot_id'],'verify'])
            need((STATE/'runtime_journal'/(token+'.result.json')).exists(), 'UNKNOWN verification; no new dispatch')
    reservations=Reservations(STATE/'reservations',[r['claim']['claim_id'] for r in rows if r['candidate']],plan['max_admissions'],plan['max_candidate_packs'])
    bridge=backend=None
    if plan['candidate_source_count']:
        bridge=receipt_bridge(plan,trust,m)
        from dependencies import load_worker_freeze, verify_files
        worker_freeze,runtime=load_worker_freeze(); need(runtime==RUNTIME_HASH, 'current runtime freeze')
        verify_files(worker_freeze['dependencies'])  # read-only host readiness; no numeric probe
        from backend import RegistryBackend
        backend=RegistryBackend(m['FrozenRegistry'](STATE/'registry.json',plan['registry_sha256']),m['ExecutionJournal'](STATE/'runtime_journal'),
            raw_reader=store.raw,instance_provider=lambda i:copy.deepcopy(instances[i]),
            reserve_worker=reservations.worker,reserve_supervisor=reservations.supervisor,
            deployment_freeze=m['DeploymentFreeze'](STATE/'deployment.json',plan['deployment_sha256']))
    observations=[]; bundles=[]; halted=None
    for row in rows:
        if halted is not None:
            observations.append({'slot_id':row['slot_id'],'capture':row['capture'],
                'extraction':dict(row['format_metrics'],raw_sha256=row['raw_response_sha256'],candidate=None,unique=False,reason='infrastructure_halt'),
                'scores':[],'admission':None,'integrity_error':'infrastructure_halt:'+halted})
            continue
        try:
            saved,bundle=get_or_execute(row,plan,backend,bridge,panel,freeze,m['ExecutionJournal'])
            observations.append(saved['observation'])
            if bundle is not None: bundles.append(bundle)
            print(canonical({'slot_id':row['slot_id'],'verified_result':saved['sha256'],
                             'completed':len(observations),'denominator':12}),flush=True)
        except BaseException as exc:
            halted=type(exc).__name__+': '+str(exc)
            failure=seal({'schema':'phase0-infrastructure-halt-v1','plan_sha256':plan['sha256'],'slot_id':row['slot_id'],'reason':halted})
            same_or_write(STATE/('halt-'+digest(halted)+'.json'),failure)
            observations.append({'slot_id':row['slot_id'],'capture':row['capture'],
                'extraction':dict(row['format_metrics'],raw_sha256=row['raw_response_sha256'],candidate=None,unique=False,reason='infrastructure_halt'),
                'scores':[],'admission':None,'integrity_error':halted})
    packet={'schema':'phase0-scheduler-packet-v1','mode':'production_verified_receipts','panel':panel,
            'rows':rows,'observations':observations,'plan_sha256':plan['sha256']}
    packet_path=STATE/('scheduler-input-'+digest(packet)+'.json'); same_or_write(packet_path,packet)
    ledger_path=STATE/('scheduler-ledger-'+digest(packet)+'.json')
    if not ledger_path.exists():
        proc=subprocess.run([sys.executable,'-I','-B',str(HERE/'scheduler_projection.py'),str(packet_path),sha(packet_path.read_bytes()),str(ledger_path)],
            stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30,check=False,
            env={'PATH':'/usr/bin:/bin','PYTHONDONTWRITEBYTECODE':'1','LANG':'C.UTF-8'},close_fds=True)
        need(proc.returncode==0, 'scheduler projection failed; receipts retained, no rerun: '+proc.stderr.decode(errors='replace')[:2000])
    ledger=verify(read(ledger_path)); usage=account(bundles,reservations.entries())
    report=seal({'schema':'phase0-numerical-report-v1','plan_sha256':plan['sha256'],'status':'halted' if halted else 'phase0_complete',
        'halt_reason':halted,'generation_denominator':12,'authenticated_generation_terminals':12,
        'verified_observations':len(bundles),'usage':usage,'orchestrator_self_cpu_seconds_this_process':time.process_time()-cpu0,
        'wall_seconds_this_process':time.monotonic()-start,'scheduler_ledger_path':str(ledger_path),'scheduler_ledger_sha256':ledger['sha256'],
        'full_plan_generation_rows':len(ledger['generation']),'full_plan_score_rows':len(ledger['scores']),
        'scheduler_summary_counts_are_scheduler_only':True,'parent_rescores':0,'control_packs':0,'heldout_packs':0,
        'fitness':'exact Fraction mean(L1_i / used_bins_i), maximize; incomplete panels unranked',
        'snapshots':ledger['snapshots']})
    write_once(STATE/('report-'+report['sha256']+'.json'),report)
    return report


def main():
    parser=argparse.ArgumentParser(); commands=parser.add_subparsers(dest='command',required=True)
    p=commands.add_parser('prepare');p.add_argument('--handoff',required=True);p.add_argument('--handoff-sha256',required=True)
    p=commands.add_parser('run');p.add_argument('--plan-file-sha256',required=True);p.add_argument('--approval',required=True);p.add_argument('--approval-sha256',required=True)
    commands.add_parser('inspect')
    args=parser.parse_args()
    if args.command=='prepare': result=prepare(args.handoff,args.handoff_sha256)
    elif args.command=='run': result=run(args.plan_file_sha256,args.approval,args.approval_sha256)
    else:
        result={'source_input_plan':verify_sources()['sha256'],'design_panel':design_panel()[0],
                'real_numerical_workers':0,'model_calls':0,'execution_enabled':False}
    print(canonical(result),flush=True)

if __name__=='__main__': main()
