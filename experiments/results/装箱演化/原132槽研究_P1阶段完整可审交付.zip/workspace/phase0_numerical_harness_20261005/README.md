# Phase-0 numerical harness, ready for parent review

This is a bounded orchestration artifact for `urp132_20261005_b01`, not an executed study. The generation freeze remains `3fa177d35b7e9f3989248611f881372f819b264194f2edda0284af1459d332e7`. No model calls, actual generated-source admission, numeric workers, current holdout data/seeds, or new calibration runs were used to build or test it.

## What is implemented

- `phase0.py prepare` reconstructs the accepted `CommittedSessionStore` from separately parent-pinned authenticated Library readback and producer fence evidence. It imports the exact twelve terminal captures with the accepted receiver, checks each original pack/claim, and uses the accepted purely textual extractor. A fixture store cannot satisfy production construction.
- It seals an exact registry with `source_origin=model_response`, a distinct study deployment bound to that registry and the unchanged generation freeze, a five-instance design metadata panel, and an exact source/provenance manifest for all twelve denominator slots. Source syntax is not parsed by the host. An all-format-failure wave has no registry and schedules no worker.
- `phase0.py run` requires a separately pinned explicit approval of that exact plan, registry, deployment, counts, and receipt trust document. It invokes the accepted metadata-revised runtime unchanged, verifies every returned receipt with `ReceiptBridge`, and projects only verified observations into `SafeRunner.observe_verified` in a fresh interpreter.
- Scheduler projection preserves the accepted ranking, seeded ties, joint identity deduplication, failure treatment, and exact `Fraction` arithmetic. It reconstructs the actual frozen two-message system/user prompt from the original base artifact, while retaining the exact CLI user-prompt hash and pack identity. It never calls legacy host AST parsing or prepares request 13.
- All 132 generation rows and 780 potential score rows remain in the scheduler ledger. First-phase denominator is twelve, even when generation, admission, or numeric evaluation fails. All five successful design instances are required for fitness. Incomplete panels receive no invented bins or fitness. EOH P0 and IID best-of-first-six snapshots result from the existing scheduler.
- Retained parents are not rescored. Control and confirmation rows remain in the full ledger, with zero control/confirmation execution in this first12 harness. No additional control or calibration is implied by a resource reservation.

## Accepted components and fixed inputs

`SOURCE_INPUT_PLAN.json` pins 109 source/input files, including the accepted runtime's 36-file source map, the exact `worker_freeze.json`, receiver revision v2, committed-session adapter revision v1, accepted producer protocol, source-safe scheduler and original plans, final phase0 packs/claims, and the exact design input.

Runtime: `7903fec4a38568000f7dc8901e49cfff6f246529129aacab2c94c179b1d1aeb8`

Design: `paper_scale_dag_evaluator_v1/data/design_5000.json`, file SHA-256 `5358c41aa758e1d399d29157f8cbdc5fb422f4c8acd56b2cb95c41af3f1750ca`, set `historical_design_5k`, capacity 100, five cases of 5000 items, L1 `[2012, 1983, 1978, 1986, 1980]`. Per-case canonical input hashes are in the source/input plan and `INSPECT_RESULT.json`.

The previous single fixed5000 calibration evidence is retained as historical accepted evidence. It is not rerun and is not a claim that arbitrary generated algorithms will pass. Runtime dependency revalidation is a read-only hash check performed before an authorized real launch; no new numerical readiness claim is made by these smoke tests.

## Durable execution and recovery

The sole production state root is fixed to `/workspace/scratch/27470b7a9f17/urp132_20261005_b01_numerical_state`. The persistent accepted execution journal is its `runtime_journal` child. The CLI cannot select a new journal. Do not delete, replace, move to an empty journal, or reconstruct this state from only a plan. Losing it blocks safe resumption.

A whole-run lock excludes concurrent launches. A durable outer verification attempt precedes the accepted runtime's own durable verification and per-instance claims. Every role reservation uses exclusive creation and file/directory fsync. Unknown or partial attempts stop the entire resumed wave before new admission. Completed outer results are reverified read-only. If only the complete accepted-runtime receipt was committed before a crash, it may be recovered and bridge-verified without calling the backend again. A terminal infrastructure failure or an uncompleted receipt never authorizes a retry.

A later metadata/receipt review failure preserves the emitted bundle and stops subsequent numeric work. Authenticated capture-import integrity failures stop preparation before numerical state is activated; all terminal bytes remain in the producer's external index/ZIP. They must be reconciled without a generation retry.

## Resource accounting

Per admitted source: one admission worker (1 CPU second / 5 wall seconds), then up to five fixed5000 instance packs. Each pack reserves numeric child 60 CPU seconds plus supervisor 60 CPU seconds, sharing one 90-second wall bound including cleanup.

First12 caps are 12 admissions, 60 packs, 7212 reserved child/supervisor/admission CPU seconds, and 5460 summed shared wall reservations. These are a subset of the already approved whole-study envelope: 132 generation slots; 660 candidate design + 20 controls + 100 confirmation = 780 packs; 95100 trusted numerical CPU seconds and 194220 total wall reservations. This harness does not authorize extra work under the unused envelope.

Actual report fields separate admission CPU, numeric-child CPU, supervisor self CPU, supervisor inclusive wait4 CPU, score-call CPU nanoseconds, shared instance wall, and current-process orchestrator CPU/wall. Inclusive wait4 and score-call CPU are not added again to numerical CPU. Scheduler-only legacy summary counters remain explicitly identified as scheduler-only; actual evidence-backed accounting is in the enclosing numerical report. Unknown/infrastructure failure consumption is not asserted to be fully reconciled.

## Remaining handoff and exact commands

No production state directory exists yet. The parent must first receive all twelve actual externally committed terminals and independently retain fresh evidence hashes.

1. Supply a JSON handoff containing:

   - `schema`: `phase0-authenticated-handoff-v1`
   - `run_id`: `urp132_20261005_b01`
   - `freeze_sha256`: the unchanged generation seal above
   - `readback_path` and `trusted_readback_sha256`: exact receipt from authenticated read/materialize/read
   - `fence_path` and `trusted_fence_sha256`: fresh actual producer fence evidence

   The referenced readback must point to existing independently materialized exact index and phase ZIP bytes. The accepted producer protocol is already pinned at `exporter_v2_received/verified/src/protocol_v2.py`.

2. From the existing workspace, run preparation only:

   `python -I -B phase0_numerical_harness_20261005/phase0.py prepare --handoff HANDOFF_JSON --handoff-sha256 EXACT_HANDOFF_FILE_SHA`

   This does not start an admission worker. Review the returned plan file SHA, plan seal, registry seal, deployment seal, twelve-source manifest, and bounds.

3. Independently review and pin a receipt trust document. `RECEIPT_TRUST_REVIEW_CANDIDATE.json` derives policy, finite API names, API manifest hash and admission limits from accepted source metadata. Its expected security profile is `{Threads:1, NoNewPrivs:1, Seccomp:2, Seccomp_filters:2}`. This file is a review candidate, not an authenticated worker observation or execution grant. Confirm its exact profile independently; never learn receipt trust roots from the returned numerical bundle.

4. Parent approval JSON must contain:

   - `schema`: `phase0-execution-approval-v1`
   - `explicit_execution_grant`: true
   - `run_id`: exact run ID
   - `plan_sha256`: exact prepared plan's semantic seal
   - `registry_sha256`, `deployment_sha256`: exact prepared seals (null only for a zero-source wave)
   - `max_admissions`, `max_candidate_packs`: exactly the prepared plan's counts
   - `controls`: 0; `heldout`: 0
   - `receipt_trust_path`, `receipt_trust_file_sha256`: independently approved exact trust bytes

   The approval file's exact SHA is retained out-of-band by the parent. A self-declared grant or adjacent hash file is not permission.

5. Only after parent authorization:

   `python -I -B phase0_numerical_harness_20261005/phase0.py run --plan-file-sha256 PREPARED_PLAN_FILE_SHA --approval APPROVAL_JSON --approval-sha256 EXACT_APPROVAL_FILE_SHA`

   The command emits one compact verified-slot progress line at a time, then a numerical report. Reusing the same command after a clean completion re-verifies existing receipts without scoring. Unknown work blocks and requires reconciliation. Do not point a copied harness at a new state root.

`python -I -B phase0_numerical_harness_20261005/phase0.py inspect` verifies pinned files and design metadata, with no numeric workers or model access.

## Smoke evidence and exposure disclosure

`SMOKE_LOG.txt`: 16/16 focused trusted-mock tests passed. Coverage includes exact design identity, source pins, no approval/no activation, opaque non-Python source extraction and registry/deployment preparation, exact Fraction ranking, all12 denominator and all132/780 rows, generation/numeric failures, completed replay, complete-receipt recovery, unknown/crashed-attempt rejection, fixture production denial, receipt tampering, and full 12/60 reservation ceilings. Mock evidence remains inside temporary directories; no fake external fixture is accepted by the production path.

During initial inspection, the superseded original protocol draft's old holdout seed section was inadvertently displayed. The parent verified that this was the superseded seed range, not the current replacement confirmation seeds. No old holdout data were read or used; no current confirmation data/seeds were exposed; no replacement was required. Subsequent protocol access is hash-only. None of those seed values are included in this artifact or any generation prompt.

Generation is separately blocked awaiting the user's specific alternative-transfer approval as reported by the parent. This harness does not attempt alternate transfer, generation, or numeric execution.
