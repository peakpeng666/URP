"""Read-only exact historical replay; never AST parse or execute candidate source."""
import hashlib,json,pathlib,sys
from unittest.mock import patch
ROOT=pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'original132_phase2_continuation_draft_20261006'))
import phase2_scheduler as scheduler
path=ROOT/'original132_phase1_coordination_20261006/TERMINAL_DELIVERY.json'
assert hashlib.sha256(path.read_bytes()).hexdigest()=='915180c59454ad330e4cd96e78eeb381fdb7c20fa66fbd5ddf1927aaed7a1c3d'
d=json.loads(path.read_bytes());objects={}
for name in ('scheduler_packet','ledger'):
 p=pathlib.Path(d['files'][name]['path']);raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()==d['files'][name]['file_sha256'];objects[name]=json.loads(raw)
with patch('ast.parse',side_effect=AssertionError('candidate AST forbidden')),patch('subprocess.Popen',side_effect=AssertionError('process launch forbidden')),patch('socket.socket',side_effect=AssertionError('network forbidden')):
 runner=scheduler.replay_phase1(objects['scheduler_packet'],objects['ledger'])
 assert runner.export()==objects['ledger']
print(json.dumps({'status':'passed','exact_ledger_equality':True,'ledger_sha256':objects['ledger']['sha256'],'phase':runner._phase,'snapshots':len(runner._snapshots),'prior_logical_requests':sum(s['logical_requests_observed'] for s in runner._slots),'phase2_requests_created':0,'candidate_AST_calls':0,'candidate_execution':0,'model_calls':0},sort_keys=True))
