# 原132 P1终态：独立接受报告

2026-10-06 07:55 UTC。

结论：接受这份精确、已完整终态的P1证据。接受范围仅为P1完成及其最终选择；P2仍未绑定、未生成、未执行，资源核算及执行门禁不由本接受文件授予。

## 独立验证

1. 按外部钉住的report/approval字节SHA重新运行已独立审查的source-binding补验。原base receipt/journal终审与strong补验均通过，独立输出与原strong审计逐字段完全一致。
2. 用原冻结SafeRunner与P1 continuation进行纯数据精确replay，整个最终ledger与真实ledger完全相等；未构造任何P2 request，未解析候选AST或执行候选。
3. report、packet、plan、ledger、base、strong同头一致；原packet、report、ledger、audit四SHA由独立reviewer acceptance精确绑定，并另绑strong审计文件及其已审代码SHA。
4. base、readback前后、producer fence及父独立index pin一致：Library index最终版本120，完整60终态；无未决外部写入或dispatch fence。
5. 原meter源码、grant、approval、once-only attempt/claim、step、receipt、harness stdout/stderr哈希与终态report一致；清理完整、无超时或强制关停。
6. 保留的真实tools.write_stdin(session51454)最终对象确认exit_code=0及meter terminal stdout completed。post-fsync wall为5107.886133109001秒，低于批准14095秒；其receipt SHA与磁盘一致。最终stdout/exit尾段仍按原声明未精确回溯计量，未把这一限制抹去。
7. P2全部位置仍planned/0请求，controls/heldout/parent-rescores均未执行；原历史shared余额仍未知、不声称原全局shared cap已被证明。

## 已接受范围

- P1：60生成位置；29 admissions；145 design packs；31生成/格式未形成可执行候选的位置仍消费固定分母。
- P0＋P1：72生成位置；33 admissions；165 design packs。
- unknown claims：0；worker/supervisor/outer-meter清理全部通过。
- 数值CPU（不重复计wait4）：5089.824491000002秒。
- forward trusted child CPU checkpoint：14.946955999997954秒；meter自身checkpoint CPU：216.35621600000002秒。新前瞻静态CPU上界900秒，旧余额未重置。
- 选择仅来自5个design实例集合，不是heldout表现，也不是已完成132位置的全实验。

P1 EOH首名：b01_EOH_TC_g1_m1_03。
P1 IID首名：b01_IID_TC_g1_m2_04。
完整6个EOH survivor及IID survivor见接受JSON与strong审计，不强制改父或补抽。

## 关键身份

- report seal：6eab5ab8c5879c88a4348bd2e70acfa8ddde932352af43796cc302413e2ba357
- report文件SHA：021b823f06b966de761714d7470d169b6947b65914c0b1dc3fe193aea4abbfe7
- ledger seal：16423d0c433762de7640c6731c83f58dc8975a22822eab51a2bda078214cda4b
- ledger文件SHA：fe1b8365506f0ae0403d3411655066f6325588ed7137746a0a3e52389942a22f
- plan seal：69f7c2563cc341c1240da49bf790419da3fe785e7956a2700919b2c02f8caae1
- strong audit文件SHA：8549ebbbd773d1c83146dc5a789bc181e4f462f31b19d65152681020c96f9689
- strong代码SHA：c26eb06b65376c0ec8b45869c6f569ad3659a6bd376452cde166ea9137729699
- base audit文件SHA：5bd03441f306580f198e89c361d52966b0449306492450bea7e3c312a2f5bf33
- meter receipt SHA：3eec01f09d2bd3abc16b671f5a59ea2bd60a76761563a46ccd36fea81be5ce32
- meter实际终态tool对象SHA：348c399688513331a8675aae1a08a804430125c88905e07314b8e3e4f5c3771b
- index blob SHA：c8a8f6ecabd3ee5f58d61e61f1a4c9ff04ee4dbcb534479e068d69fb05188717

## 后续接线文件

- P1_INDEPENDENT_REVIEWER_ACCEPTANCE.json，字节SHA db37f0c5f5a6bddd08ea033983554e6610db170e0bdfa6a7737c41b7d56bddff。
- FINAL_P1_BOUNDARY_EVIDENCE.json，字节SHA cb85e56d61f90dbf74e1e10df87f74b22275982921849a9c294f8d1e07718a40。

这份boundary已通过phase2_binding.validate_final_p1的只读结构及同头校验。没有调用builder，未把其内容写进P2包。P2 disabled builder仍须单独满足输入准备/协调资源核算，后续生成与数值执行仍需各自批准。

## 审计边界

只在收到P1已真实终态的新授权后读取最终report/ledger/receipts。此前未读取运行中分数。本次没有模型调用、候选执行或源AST解析，没有改冻结P1源码、数值state、meter证据或P2包。审计仅写本目录的新输出。
