"""Read-only terminal evidence cross-check. Produces audit files outside the run state."""
import hashlib,json,math,pathlib,sys
ROOT=pathlib.Path(__file__).resolve().parent.parent;OUT=pathlib.Path(__file__).resolve().parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
canon=lambda v:json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def read(path,pin=None):
 p=pathlib.Path(path);assert p.is_file() and not p.is_symlink() and p.stat().st_size<64*1024*1024
 raw=p.read_bytes();assert pin is None or sha(raw)==pin
 return json.loads(raw)
def sealcheck(v):assert v['sha256']==sha(canon({k:x for k,x in v.items() if k!='sha256'}))
def ref(path):
 p=pathlib.Path(path).resolve();return {'path':str(p),'file_sha256':sha(p.read_bytes())}
def write(name,v):
 with (OUT/name).open('x') as f:json.dump(v,f,sort_keys=True,indent=2);f.write('\n')
d=read(ROOT/'original132_phase1_coordination_20261006/TERMINAL_DELIVERY.json','915180c59454ad330e4cd96e78eeb381fdb7c20fa66fbd5ddf1927aaed7a1c3d')
f={k:read(r['path'],r['file_sha256']) for k,r in d['files'].items()}
for n in ('report','plan','registry','deployment','ledger'):sealcheck(f[n])
report=f['report'];plan=f['plan'];ledger=f['ledger'];base=f['base_audit'];strong=f['strong_audit'];receipt=f['meter_receipt'];step=f['meter_step']
rerun=read(OUT/'STRONG_AUDIT_RERUN.json');assert rerun==strong and strong['base_receipt_audit']==base
assert report['status']=='phase1_complete' and report['halt_reason'] is None
assert all(x['status']=='passed' for x in (base,strong,strong['source_selection_binding']))
assert all(x['report_sha256']==report['sha256'] and x['plan_sha256']==plan['sha256'] and x['ledger_sha256']==ledger['sha256'] for x in (base,strong))
assert strong['report_file_sha256']==base['report_file_sha256']==d['files']['report']['file_sha256']
assert f['scheduler_packet']['plan_sha256']==report['plan_sha256']==plan['sha256']
assert report['scheduler_ledger_sha256']==ledger['sha256'] and report['snapshots']==ledger['snapshots']
assert base['controls']==base['heldout']==base['parent_rescores']==0 and base['unknown_claims']==0 and base['all_reaped_cleanly'] is True
assert base['admissions']==29 and base['design_packs']==145
assert all(s['state']=='planned' and s['logical_requests_observed']==0 for s in ledger['generation'] if s['phase']==2)
approval_path=ROOT/'urp132_20261005_b01_phase1_numerical_state/parent_execution_approval.json'
approval=read(approval_path,'575099c18f096dc75752fcfaee50d6336402ea6b815742d66c271072c0e34df1')
grant_path=ROOT/'parent_phase1_review_20261006/PARENT_RUN_GRANT.json';grant=read(grant_path,'ac358a0cc104707315710146d7e193969c295d0b185910b270b7b1a67cc8b458')
addendum_path=ROOT/'parent_phase1_review_20261006/FORWARD_ACCOUNTING_ADDENDUM_APPROVED.json';addendum=read(addendum_path,grant['accounting_addendum_file_sha256'])
assert sha((ROOT/'original132_phase1_coordination_20261006/meter.py').read_bytes())==grant['meter_sha256']==receipt['meter_sha256']==addendum['meter_file_sha256']
assert grant['enabled'] is True and grant['parent_review_accepted'] is True and grant['action']=='run'
assert grant['plan_file_sha256']==d['files']['plan']['file_sha256'] and grant['approval_file_sha256']==ref(approval_path)['file_sha256']
assert approval['plan_sha256']==plan['sha256'] and approval['max_admissions']==plan['max_admissions']==29 and approval['max_candidate_packs']==plan['max_candidate_packs']==145
assert grant['inclusive_wall_seconds']==receipt['inclusive_wall_seconds']==29*5+145*90+900==14095
assert grant['trusted_cpu_allowance_seconds']==receipt['trusted_cpu_allowance_seconds']==receipt['static_trusted_cpu_upper_bound_seconds']==900
attempt=read(ROOT/'original132_phase1_forward_accounting_20261006/run.attempt.json','706fa1b235e109496736e6704a3528f8ad046bd18a67cdbf41a4fb444b6aa79e')
claim=read(ROOT/'original132_phase1_forward_accounting_20261006/run.claim.json','2fbf85613d122be88143803e881f77065262c69e2d8c727cda6dee31252abf33')
assert attempt['grant_file_sha256']==claim['grant_file_sha256']==receipt['grant_file_sha256']==ref(grant_path)['file_sha256']
assert attempt['meter_sha256']==claim['meter_sha256']==receipt['meter_sha256'] and attempt['retry_authorized'] is claim['retry_authorized'] is receipt['retry_authorized'] is False
assert receipt['commands']==claim['commands'] and len(receipt['steps'])==1 and receipt['steps'][0]==step
assert step['command']==claim['commands'][0][1] and step['returncode']==0 and step['direct_child_reaped'] is True and step['all_meter_children_reaped'] is True
assert step['error'] is None and step['timed_out'] is False and step['forced_shutdown'] is False and step['within_absolute_deadline'] is True
assert step['subreaper'] is True and step['parent_death_guard'] is True
for kind in ('stdout','stderr'):assert sha(pathlib.Path(step[kind+'_path']).read_bytes())==step[kind+'_sha256']
assert json.loads(pathlib.Path(step['stdout_path']).read_bytes().splitlines()[-1])==report
assert receipt['status']=='completed' and receipt['report_sha256']==report['sha256']
assert receipt['numeric_cpu_from_complete_receipts']==report['usage']['numerical_cpu_seconds_no_double_count']==base['usage']['numerical_cpu_seconds_no_double_count']
assert math.isclose(receipt['trusted_child_cpu_seconds'],max(0,step['wait4_inclusive_cpu_seconds']-receipt['numeric_cpu_from_complete_receipts']),abs_tol=1e-8)
assert receipt['meter_self_cpu_at_receipt']<=receipt['meter_cpu_hard_limit']==300
assert receipt['wall_seconds_at_receipt']<=receipt['inclusive_wall_seconds']
tool_path=ROOT/'original132_phase1_coordination_20261006/RUN_TERMINAL_TOOL_RESULT.json';tool=read(tool_path,'348c399688513331a8675aae1a08a804430125c88905e07314b8e3e4f5c3771b')
prov_path=ROOT/'original132_phase1_coordination_20261006/RUN_TERMINAL_TOOL_RESULT_PROVENANCE.json';prov=read(prov_path,'a2ffb8d72f4d76f3f3eb126a57e433229d8ab0b2b715f53749ef4aa9a77300f7')
assert tool['exit_code']==0 and tool['chunk_id']==prov['observed_tool_result_chunk_id'] and prov['exec_session_id']==prov['arguments']['session_id']==51454
assert prov['file_sha256']==ref(tool_path)['file_sha256']
terminal=json.loads(tool['output']);assert terminal['status']=='completed' and terminal['within_inclusive_wall_after_receipt_fsync'] is True
assert terminal['receipt_sha256']==d['files']['meter_receipt']['file_sha256'] and terminal['receipt_path']==d['files']['meter_receipt']['path']
assert receipt['wall_seconds_at_receipt']<=terminal['wall_seconds_after_receipt_fsync']<=grant['inclusive_wall_seconds']
assert terminal['final_stdout_exit_tail_unmeasured'] is True and receipt['wall_alarm_not_disarmed_before_exit'] is True
handoff=read(ROOT/'original132_phase1_authenticated_readback_20261006/phase1-authenticated-handoff.json')
proof=read(handoff['readback_path'],'6b9dfaa0f8b5123d14979dd1006170d66a3657412baabd44981955c83072ab31')
fence=read(handoff['fence_path'],'b4e89d5c0a118b76ff45550c95886f469ae9484bb8e31e1af16c2a842c6238bc')
identity=base['authenticated_index_identity']
assert identity=={'library_file_id':fence['library_file_id'],'file_id':fence['file_id'],'version':fence['current_version_number'],'sha256':fence['index_blob_sha256']}
assert fence['external_write_pending'] is False and fence['unresolved_dispatch_fences']==0 and fence['run_id']=='urp132_20261005_b01_phase1'
assert proof['evidence_kind']=='actual_authenticated_tool_results' and fence['observation_kind']=='actual_producer_status_tool_stdout'
parent_index=read(ROOT/'parent_phase1_review_20261006/index_identity_pin.json')
assert identity['library_file_id']==parent_index['library_file_id'] and identity['file_id']==parent_index['file_id'] and identity['version']==int(parent_index['version']) and identity['sha256']==parent_index['index_raw_sha256']
summary={'schema':'phase1-independent-terminal-evidence-verification-v1','status':'passed','exact_report_plan_ledger_base_strong_binding':True,'independent_strong_rerun_identical':True,'independent_scheduler_replay':read(OUT/'SCHEDULER_REPLAY.json'),'authenticated_index_identity':identity,'base_and_strong_status':'passed','meter_actual_tool_exit_code':tool['exit_code'],'meter_tool_evidence':ref(tool_path),'meter_tool_provenance':ref(prov_path),'meter_receipt':d['files']['meter_receipt'],'meter_terminal_stdout':terminal,'meter_grant':ref(grant_path),'accounting_addendum':ref(addendum_path),'meter_cleanup_complete':True,'meter_same_report_and_plan':True,'harness_terminal_stdout_report_equal':True,'numeric_CPU_no_double_count':receipt['numeric_cpu_from_complete_receipts'],'trusted_child_CPU_at_checkpoint':receipt['trusted_child_cpu_seconds'],'meter_self_CPU_at_checkpoint':receipt['meter_self_cpu_at_receipt'],'final_tail_measurement_limit_preserved':True,'historical_shared_balance':None,'historical_original_shared_cap_compliance':'not authenticated; not claimed','generation':60,'admissions':29,'design_packs':145,'controls':0,'heldout':0,'parent_rescores':0,'phase2_remains_untouched':True,'model_calls_during_review':0,'candidate_execution_during_review':0}
write('TERMINAL_EVIDENCE_VERIFICATION.json',summary)
print(json.dumps({'status':'passed','report_sha256':report['sha256'],'ledger_sha256':ledger['sha256'],'index_version':identity['version'],'meter_exit_code':tool['exit_code'],'within_wall':True,'phase2_untouched':True},sort_keys=True))
