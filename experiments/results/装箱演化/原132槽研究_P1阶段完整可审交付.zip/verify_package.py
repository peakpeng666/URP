"""Verify this extracted evidence package; never executes candidate code."""
import hashlib,json,pathlib
root=pathlib.Path(__file__).resolve().parent
manifest=json.loads((root/'FILE_MANIFEST.json').read_bytes())
for name,expected in manifest['files'].items():
    p=root/name
    assert p.resolve().is_relative_to(root) and p.is_file() and not p.is_symlink(),name
    raw=p.read_bytes();assert len(raw)==expected['bytes'] and hashlib.sha256(raw).hexdigest()==expected['sha256'],name
print(json.dumps({'status':'passed','verified_files':len(manifest['files']),'candidate_execution':0,'model_calls':0,'scope':'byte-integrity only; original authenticated evidence and independent acceptance are retained separately'},indent=2))
