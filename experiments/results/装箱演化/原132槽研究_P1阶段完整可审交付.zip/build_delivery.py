"""Allowlisted evidence packaging only; no candidate parse, execution, or API."""
import argparse,hashlib,json,pathlib,zipfile
ROOT=pathlib.Path(__file__).resolve().parent.parent
OUT=pathlib.Path(__file__).resolve().parent
H=lambda b:hashlib.sha256(b).hexdigest()

def sources():
    files=set()
    def add(p):
        p=pathlib.Path(p);assert p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(ROOT)
        if '__pycache__' not in p.parts and p.suffix not in ('.pyc','.tmp'):files.add(p)
    def tree(name):
        path=ROOT/name;assert path.is_dir(),name
        for p in path.rglob('*'):
            if p.is_file():add(p)
    plan=json.loads((ROOT/'original132_phase1_preparation_20261005/SOURCE_INPUT_PLAN.json').read_bytes())
    for rel,expected in plan['source_and_input_files'].items():
        p=ROOT/rel;assert H(p.read_bytes())==expected,rel;add(p)
    for name in ['original132_phase1_preparation_20261005','original132_phase1_review_20261005','original132_phase1_authenticated_readback_20261006','urp132_20261005_b01_phase1_numerical_state','urp132_20261005_b01_numerical_state','phase0_numerical_harness_20261005','phase0_authenticated_readback_20261005','phase0_terminal_audit_20261005','original132_phase1_forward_accounting_20261006','original132_phase1_coordination_20261006','original132_phase1_evaluation_ready_20261006','parent_phase1_review_20261006','audit_phase1_forward_meter_20261006','audit_original132_phase1_terminal_independent_20261006']:
        tree(name)
    for name in ['urp132_FINAL_PHASE0_GENERATION_20261005T1339Z.zip','original132_phase1_PREPARATION_REVIEWED_20261005.zip','original132_shared_budget_recovery_20261006/AUDIT.json']:
        add(ROOT/name)
    # Only P1 independent acceptance/review, never the separate future P2 draft.
    audit=ROOT/'audit_original132_phase2_adapters_20261006'
    for p in audit.glob('PHASE1*'):
        if p.is_file():add(p)
    report=ROOT/'original132_phase1_report_20261006'
    if report.exists():
        for name in ('P1_REPORT_ZH.docx','P1_REPORT_ZH.pdf','REPORT_ZH.md','P1_CANDIDATES.csv','DERIVED_STATISTICS.json','SOURCE_MANIFEST.json','REPORT_QA.json','DELIVERY_MANIFEST.json'):
            p=report/name
            if p.is_file():add(p)
    return sorted(files)

def main():
    p=argparse.ArgumentParser();p.add_argument('--build',action='store_true');p.add_argument('--acceptance',help='Exact independently accepted P1 record, required to finalize');p.add_argument('--acceptance-sha256');a=p.parse_args();files=sources()
    if not a.build:
        print(json.dumps({'allowlisted_files':len(files),'uncompressed_bytes':sum(p.stat().st_size for p in files),'finalization_requires_independent_acceptance_and_report':True}));return
    assert a.acceptance and a.acceptance_sha256
    acceptance=pathlib.Path(a.acceptance);assert H(acceptance.read_bytes())==a.acceptance_sha256
    if acceptance not in files:files.append(acceptance)
    report=ROOT/'original132_phase1_report_20261006';assert list(report.glob('*.docx')) and list(report.glob('*.pdf')) and (report/'REPORT_ZH.md').is_file()
    members={'workspace/'+str(p.relative_to(ROOT)):p.read_bytes() for p in sorted(files)}
    for name in ('README_ZH.md','verify_package.py','build_delivery.py'):members[name]=(OUT/name).read_bytes()
    manifest={'schema':'original132-phase1-auditable-delivery-v1','scope':'Original study P0 plus completed P1 evidence; P2 not executed by this package','independent_acceptance':{'path':'workspace/'+str(acceptance.relative_to(ROOT)),'file_sha256':a.acceptance_sha256},'files':{name:{'sha256':H(raw),'bytes':len(raw)} for name,raw in sorted(members.items())},'runtime_dependency_note':'The exact 995 system dependency hashes are retained in frozen worker metadata. System binaries/credentials are not copied; this is not a portable permission to rerun.'}
    members['FILE_MANIFEST.json']=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
    dest=OUT/'原132槽研究_P1阶段完整可审交付_20261006.zip';assert not dest.exists()
    with zipfile.ZipFile(dest,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,raw in sorted(members.items()):z.writestr(name,raw)
    with zipfile.ZipFile(dest) as z:
        assert z.testzip() is None and set(z.namelist())==set(members)
        for name,raw in members.items():assert z.read(name)==raw
    receipt={'schema':'phase1-delivery-zip-receipt-v1','path':str(dest),'bytes':dest.stat().st_size,'sha256':H(dest.read_bytes()),'members':len(members),'uncompressed_bytes':sum(len(x) for x in members.values()),'crc_all_members_verified':True,'all_member_hashes_verified':True,'acceptance_file_sha256':a.acceptance_sha256,'public_upload_done':False}
    (OUT/'ZIP_RECEIPT.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n');print(json.dumps(receipt,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
