# 原132槽研究：P1阶段可审交付

## 先读什么

1. `workspace/original132_phase1_report_20261006/REPORT_ZH.md`，以及同目录可编辑Word和PDF：中文阶段报告。
2. `workspace/original132_phase1_coordination_20261006/TERMINAL_DELIVERY.json`：结果索引、各证据文件的精确SHA-256。
3. `workspace/original132_phase1_evaluation_ready_20261006/STRONG_TERMINAL_AUDIT.json`：收据审计与额外源码/完整档案/完整评分账/父代选择绑定验证。
4. `FILE_MANIFEST.json`所指的独立P1 acceptance：最终独立接受记录。

## 已完成与边界

第一代固定60个位置：31次公共输出为空且结束原因为length，29份可提取候选通过准入，完成145次设计实例评测。每个候选固定评测5个5000项设计实例。加上P0，累计72次生成、33次准入、165次设计实例评测。完整科学账仍保留132个生成位置及780个评分位置。

这是一份P1设计集阶段交付；未把空输出移出分母，未重抽候选，未重评已保留父代，未新增控制或heldout评测。P2不由此交付自动启动。设计集成绩不能当作heldout泛化结果，也不代表完整132槽研究已结束。

## 包内结构

- `workspace/urp132_20261005_b01_phase1_numerical_state/`：全部真实P1结果、准入/评分bundle、执行journal、资源reservation、plan/registry/deployment、完整scheduler输入与账本。
- `workspace/urp132_20261005_b01_numerical_state/`：已接受P0状态，便于完整追溯。
- `workspace/original132_phase1_authenticated_readback_20261006/`：60个原始公共输出的正式归档、最终索引、认证读回、实际生产端fence与生成终态证据。
- `workspace/original132_phase1_preparation_20261005/`、`workspace/URP/…`及其他被冻结依赖目录：原请求、协议、评测器和选择器的原始字节及哈希，不混入后续独立实验。
- `workspace/original132_phase1_forward_accounting_20261006/`：一次性执行标记、日志和前向计量收据。
- `workspace/parent_phase1_review_20261006/`：精确绑定本次运行的已接受前向开销补充及批准记录。
- `workspace/original132_phase1_coordination_20261006/`：外置计量源码、可信dummy测试、真实终态工具输出及恢复说明。

## 不改写历史资源口径

原历史准备/协调预算的完整消耗无法认证，余额保持unknown，不声称旧共享总上限已获全程证明。P1使用另外明确接受的前向可信协调开销补充。数值子进程的原准入/数值/监督上限与科学槽位预算没有改变。详见中文报告和计量收据。

## 如何核对与恢复

解压后可运行 `python verify_package.py`，只验证包内字节SHA与大小，不解析或执行候选。

全部原始数据、收据、代码和清单可用于重建结果与追溯；冻结运行时同时保留995个系统依赖文件的精确哈希，没有复制系统二进制或凭证。本包不是任意机器上可直接重新发请求或重新评测的快捷入口。原已执行state、journal、once-only attempt必须保留，不能删掉后重跑；旧包中的历史RUNBOOK/disabled草稿是审计材料，不能覆盖本次实际已接受的前向计量流程。

认证读回中的原始本地绝对路径为当时执行证据，移动文件不等于重新认证外部服务。严格复验需要保留原目录关系、认证信任根和对应环境；单纯本地SHA通过只证明字节一致，不等于新的运行授权或新的外部认证。

候选完整分配在原运行中经过独立精确整数checker逐项检查；持久bundle保存分配SHA而非全部分配向量，因此不宣称此包能第二次离线逐项重放未保存的分配。补强审计从已验证候选独立重建完整archive、评分账与P1快照，封住原审计对代码/identity/选择绑定的覆盖缺口；这不表示实际结果曾遭篡改。
