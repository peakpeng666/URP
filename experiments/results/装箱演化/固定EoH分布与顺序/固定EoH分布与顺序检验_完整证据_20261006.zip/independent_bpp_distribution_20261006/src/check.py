"""Independent exact integer replay and scalar-decision oracle; no NumPy or policy imports."""
import collections,hashlib,heapq,json,math,pathlib,sys,time
H=pathlib.Path(__file__).resolve().parents[1]
canon=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
sha=lambda x:hashlib.sha256(x).hexdigest()
def score(item,space,policy):
 if policy=='BF':return -(space-item)
 diff=space-item;e=math.exp(diff);return space/((e+0.7)*e)+(1-diff/space)*math.sqrt(diff)+(0.8 if diff>3*item else 0.3)
TABLE={p:{i:{s:score(i,s,p) for s in range(i,101)} for i in range(1,101)} for p in ['BF','published_EoH']}
def check(data,result):
 items=data['items'];tr=result['trajectory'];assert len(items)==5000 and all(type(i)is int and 1<=i<=100 for i in items)
 assert result['status']=='complete' and result['steps']==5000
 assert result['items_sha256']==sha(canon(items).encode())
 assert all(len(a)==5000 for a in tr.values())
 rem=[100]*5000; hist=[0]*101;hist[100]=5000;heaps=[[] for _ in range(101)];heaps[100]=list(range(5000));used=0
 for step,(item,index) in enumerate(zip(items,tr['assignment'])):
  assert type(index)is int and 0<=index<5000
  before=rem[index]; assert before>=item
  assert tr['feasible_counts'][step]==sum(hist[item:])
  choices=[]
  for space in range(item,101):
   if hist[space]:
    heap=heaps[space]
    while heap and rem[heap[0]]!=space:heapq.heappop(heap)
    assert heap
    choices.append((TABLE[result['policy']][item][space],-heap[0]))
  _,minus_index=max(choices);assert index==-minus_index,(result['instance_id'],result['policy'],step,'scalar decision mismatch',index,-minus_index)
  selected=TABLE[result['policy']][item][before];assert math.isclose(tr['score_selected'][step],selected,rel_tol=2e-14,abs_tol=2e-14)
  rem[index]-=item;hist[before]-=1;hist[rem[index]]+=1;heapq.heappush(heaps[rem[index]],index);used+=int(before==100)
  assert tr['pre_remaining'][step]==before and tr['post_remaining'][step]==rem[index] and tr['used_bins_after'][step]==used
 assert rem==result['remaining'];assert sum(items)==sum(100-r for r in rem);assert used==result['used_bins']==sum(r!=100 for r in rem)
 return used

def main():
 start=time.process_time();freeze=json.loads((H/'FREEZE.json').read_bytes())
 for n,h in freeze['files'].items():assert sha((H/n).read_bytes())==h,n
 rows=[]; groups=collections.defaultdict(dict)
 for p in sorted((H/'raw').glob('*.json')):
  x=json.loads(p.read_bytes());data=json.loads((H/'inputs'/f"{x['instance_id']}.json").read_bytes());b=check(data,x);rows.append({'file':p.name,'sha256':sha(p.read_bytes()),'used_bins':b,'integer_and_decision_replay':True})
  if not x['instance_id'].startswith('calibration'):groups[data['base_id']][data['order']]=data
 assert len(rows)==172
 for base,orders in groups.items():
  assert set(orders)=={'random','ascending','descending'}
  counts=[collections.Counter(d['items']) for d in orders.values()];assert counts[0]==counts[1]==counts[2]
  for d in orders.values():
   assert sorted(d['source_position'])==list(range(5000));assert d['volume_lb']==(sum(d['items'])+99)//100
   if d['kind']=='constructed':
    sizes=sorted(set(d['items']));assert len(sizes)==2 and sum(sizes)==100 and all(d['items'].count(s)==2500 for s in sizes) and d['known_optimum']==d['volume_lb']==2500
 result={'passed':True,'checked_runs':len(rows),'checked_placements':5000*len(rows),'scalar_decisions_replayed':5000*len(rows),'family_multisets_checked':len(groups),'checker_imports_policy_or_numpy':False,'checks':['all assignments integer and in range','every placement capacity feasible','exact conservation','complete 5000-item trajectory','all residuals and used-bin prefixes','feasible candidate counts','scalar EoH/BF first-argmax decision equivalence','same multiset across three arrival orders','construction 2500-bin witnesses attain volume LB'],'cpu_seconds':time.process_time()-start,'rows':rows}
 (H/'CHECK.json').write_text(canon(result)+'\n');print(canon({k:v for k,v in result.items() if k!='rows'}))
if __name__=='__main__':main()
