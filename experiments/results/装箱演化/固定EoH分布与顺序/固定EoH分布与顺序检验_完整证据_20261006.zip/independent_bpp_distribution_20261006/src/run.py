"""ONLY two SHA256-allowlisted trusted controls. Not a generated-program sandbox."""
import hashlib,json,pathlib,time,resource,sys,signal
import numpy as np
H=pathlib.Path(__file__).resolve().parents[1]
ALLOW={'BF':'f1b3010016ca5c3c95a5f583ddc071cd1a30cfaf40e270b865c95f4817387d4b','published_EoH':'de06105a3b630fc5ab6f2d823e45d5326315071208cbac8379ffe8d3a29bed7a'}
canon=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(p,x):
 with p.open('x') as f:f.write(canon(x)+'\n');f.flush()
def verify():
 for n,h in json.loads((H/'FREEZE.json').read_bytes())['files'].items():assert sha((H/n).read_bytes())==h,n

def run(items,policy,instance_id):
 source=(H/'sources'/f'{policy}.py.txt').read_bytes(); assert sha(source)==ALLOW[policy]
 scope={'np':np,'__builtins__':{}};exec(compile(source,f'<trusted-control-{policy}>','exec'),scope);f=scope['score']
 rem=np.full(len(items),100,dtype=np.int64);trajectory={'assignment':[],'pre_remaining':[],'post_remaining':[],'feasible_counts':[],'score_selected':[],'used_bins_after':[]};used=0
 start=time.monotonic();cpu=time.process_time();status='complete';error=None
 try:
  with np.errstate(all='raise'):
   for item in items:
    feasible=np.flatnonzero(rem>=item);bins=np.array(rem[feasible],dtype=np.int64,copy=True);bins.setflags(write=False);scores=f(np.int64(item),bins)
    assert isinstance(scores,np.ndarray) and scores.shape==bins.shape and np.all(np.isfinite(scores))
    pos=int(np.argmax(scores));target=int(feasible[pos]);before=int(rem[target]);rem[target]-=item
    assert int(rem[target])>=0
    used+=int(before==100)
    trajectory['assignment'].append(target);trajectory['pre_remaining'].append(before);trajectory['post_remaining'].append(int(rem[target]));trajectory['feasible_counts'].append(len(feasible));trajectory['score_selected'].append(float(scores[pos]));trajectory['used_bins_after'].append(used)
 except BaseException as exc:
  status='failure';error=type(exc).__name__+': '+str(exc)
 result={'instance_id':instance_id,'policy':policy,'status':status,'error':error,'source_sha256':ALLOW[policy],'items_sha256':sha(canon(items).encode()),'steps':len(trajectory['assignment']),'remaining':rem.tolist(),'used_bins':used,'trajectory':trajectory,'wall_seconds':time.monotonic()-start,'cpu_seconds':time.process_time()-cpu}
 put(H/'raw'/f'{instance_id}__{policy}.json',result)
 if error:raise RuntimeError(error)
 return result

def main():
 assert resource.getrlimit(resource.RLIMIT_CPU)==(1200,1200)
 verify();put(H/'RUN_STARTED.json',{'freeze_sha256':sha((H/'FREEZE.json').read_bytes()),'start_unix':time.time(),'cpu_limit':1200,'policies':ALLOW})
 start=time.monotonic();cpu=time.process_time();rows=[]
 try:
  for i in range(5):
   data=json.loads((H/'inputs'/f'calibration_{i}.json').read_bytes())
   for p in ALLOW:
    x=run(data['items'],p,f'calibration_{i}');ref=json.loads((H/'evidence'/f'calibration_{p}_{i}.json').read_bytes())
    assert x['trajectory']['assignment']==ref['assignment'] and x['remaining']==ref['remaining'] and x['trajectory']['feasible_counts']==ref['feasible_counts'] and x['used_bins']==ref['used_bins'],'historical calibration mismatch'
  put(H/'CALIBRATION.json',{'passed':True,'runs':10,'checks':['complete assignment','all 5000 residuals','all 5000 feasible counts','bin counts'],'note':'Trusted vectorized host; no equivalence claim for generated candidate isolation or runtime cost'})
  protocol=json.loads((H/'PROTOCOL.json').read_bytes())
  for meta in protocol['instances']:
   data=json.loads((H/'inputs'/f"{meta['instance_id']}.json").read_bytes())
   # Alternate policy execution order to reduce simple timing confounding.
   names=list(ALLOW) if len(rows)%4==0 else list(reversed(ALLOW))
   for p in names:
    x=run(data['items'],p,data['instance_id']);rows.append({k:v for k,v in x.items() if k not in ['remaining','trajectory']});print(canon({'completed':len(rows),'id':data['instance_id'],'policy':p,'bins':x['used_bins'],'cpu':x['cpu_seconds']}),flush=True)
  verify();put(H/'RUN_COMPLETE.json',{'status':'complete','new_runs':len(rows),'calibration_runs':10,'total_cpu_seconds':time.process_time()-cpu,'total_wall_seconds':time.monotonic()-start,'model_calls':0,'rows':rows})
 except BaseException as e:
  put(H/'RUN_FAILURE.json',{'status':'failed','error':type(e).__name__+': '+str(e),'completed_rows':rows,'cpu_seconds':time.process_time()-cpu,'wall_seconds':time.monotonic()-start});raise
if __name__=='__main__':main()
