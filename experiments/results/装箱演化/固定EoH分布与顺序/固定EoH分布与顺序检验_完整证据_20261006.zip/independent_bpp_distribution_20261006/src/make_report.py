"""Build editable Chinese report from all verified results."""
import json,pathlib,statistics,csv
from docx import Document
from docx.shared import Pt,Inches,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
H=pathlib.Path(__file__).resolve().parents[1]
D=json.loads((H/'analysis/SUMMARY.json').read_bytes());R=json.loads((H/'RUN_COMPLETE.json').read_bytes());C=json.loads((H/'CHECK.json').read_bytes());assert C['passed']
labels={'weibull_3_45':'Weibull 3/45','uniform_1_100':'均匀整数','small_beta_2_5':'偏小Beta','large_beta_5_2':'偏大Beta','normal_50_15':'裁剪正态','bimodal_20_30_70_80':'双峰','constructed_25_75':'25+75','constructed_40_60':'40+60','constructed_49_51':'49+51'}
orders={'random':'随机','ascending':'升序','descending':'降序'}
sums=D['summary'];rows=D['rows'];random=[r for r in rows if r['kind']=='random' and r['order']=='random']
sections=[]
def sec(title,text):sections.append((title,text))
sec('结论与用途','最直接的新结果是同一批5000件Weibull物品的排名反转：随机到达时EoH平均比Best Fit少66.75箱；降序到达时反而多96箱，四个独立seed都发生反转。长度和容量完全不变，因此不能用“256前缀不等于5000长流”解释本轮现象。\n六族共24个降序流中，EoH为0胜、3平、21负；随机到达的均匀和正态族，EoH均值也略差。正面结果同样保留：40+60与49+51互补构造的升序流，EoH以2500箱达到有证最优，Best Fit使用3750箱。\n固定发表EoH的优势取决于物品分布和输入顺序。本轮服务老师P3：把平均胜出写成具体适用范围。全部数据为5000物品、容量100；这是独立探索测试，不是原132研究的确认集。')
# Computed findings, no predetermined preferred result.
facts=[]
for s in sums:
 if s['kind']=='random' and s['order']=='random':facts.append(f"{labels[s['family']]}随机流：EoH−Best Fit平均{s['delta_mean']:+.2f}箱，四seed范围[{s['delta_min']:+d}, {s['delta_max']:+d}]，胜/平/负={s['EoH_wins']}/{s['ties']}/{s['EoH_losses']}。")
sec('随机到达的六族结果','\n'.join(facts)+'\n负差值表示EoH箱数更少；每族仅四个独立多重集，不报告显著性或总体胜率。各族同时改变均值、尾部和结构，未做等均值匹配，不能将差异单归因于分布形状。')
sec('论文机制如何落实','EoH原文第5页§4.1用5个Weibull、每例5000物品、容量100设计，Figure 6给出固定评分函数。该函数把当前物品和可行箱残量组合成指数、平方根和分段评分。本轮逐字节复用已审控制，未进行演化或新模型生成。\nM07的RAISE原文§2.4把受限基分布搜索接入评价循环，提醒固定设计分布可能掩盖弱点。本轮仅据此提出有限分布检验，不实现RAISE的对抗搜索、投影、重评分和LLM外环；其重新训练基线也不与本轮固定发表函数混为一物。')
sec('冻结设计与公平比较','六随机族各四个全新确定seed：Weibull形状3/尺度45；整数均匀1至100；100×Beta(2,5)；100×Beta(5,2)；Normal(50,15)；20至30与70至80的等概率整数双峰。连续数值先裁剪到[1,100]，再ties-to-even取整。尺寸不再按实例归一化。\n每一多重集生成随机、升序、降序三个输入流。算法仍逐物品到达、不可逆放置，不看未来、不能排序。升降序是结构化压力流，不是让online算法取得离线重排权限；这三流互相配对，并非三份独立抽样。\n随机部分24多重集、72流、144策略运行；构造部分3多重集、9流、18运行。另10次旧公开设计校准，总172次。全部预先冻结，不按结果加seed、换分布或筛胜例。')
sec('宿主与独立检查','两个策略在同一宿主上接收np.int64物品和只读int64残量向量。宿主维护5000个候选空箱，按箱索引升序过滤可行箱，first argmax打破平分；EoH可以在仍有可行已用箱时选择新箱。没有偷偷换成“只有无可行箱才开箱”的宿主。\n执行前用五个公开旧设计实例逐策略校准：完整5000步assignment、残量、可行箱数和箱数与历史一致。校准只验证这十条轨迹，不证明所有输入域等价。之后的独立checker不导入NumPy或运行控制源，以整数验容量、守恒、箱数和全部前缀，同时用math标量公式重放每一步first argmax。分数用明确容差比较，不能声称浮点位级相同。\n另一个独立审阅程序采用残量索引bitset和原公式括号顺序，860000步决策也完全一致。本机分数数值相等，但观察到不同残量候选间最小胜出间隔仅4.44×10⁻¹⁶。如此接近的浮点并列意味着跨平台或改写公式后的位级与轨迹等价没有得到证明；源dtype、括号与first argmax应保留。')
sec('构造最优与随机下界','构造包含2500件小物品和2500件互补大物品，尺寸对为25+75、40+60、49+51。每对放一箱给出2500箱可行见证，总体积250000/容量100又给2500下界，因此这些构造OPT=2500。\n随机实例只使用ceil(总体积/100)作为volume下界。随机excess=(使用箱数−下界)/下界，不是相对已知最优值的gap；接近零不能推导算法在一般输入上最优。三个构造和随机均值分开展示，不估计现实部署分布占比。')
sec('运行账本与失败','全部172次运行完成，失败0，未重试；独立检查覆盖860000次放置和860000次标量决策。数值执行CPU %.3f秒，墙钟 %.3f秒；独立检查CPU %.3f秒。新模型/API调用0。性能计时只属于本向量化可信控制宿主，不能与原候选隔离执行器、论文硬件或总生成成本作速度比较。'%(R['total_cpu_seconds'],R['total_wall_seconds'],C['cpu_seconds']))
sec('适用范围与可报告表述','可报告：在已冻结的六个尺寸分布族与三类输入顺序上，固定发表EoH相对Best Fit表现出具体且可复查的差异；相同长度不保证相同排名，须保留强基线并报告负例。\n不可报告：实现了RAISE；新seed是原132研究此前未触碰的确认集；六族代表所有BPP；排序压力流代表真实到达概率；结论可直接转为农业田间有效性；本轮结果证明所有EoH生成算法都有效或无效。\n本轮没有训练选择器，不能用完整输入流的事后分布或顺序标签推荐online算法。若选择器只能观察合法前缀，其净收益仍需另立信息隔离实验。\n本轮没有读取原132 heldout或进行中P1结果，没有改原研究提示、选择、数据或freeze；新数据和反馈不得进入原132第二代。')
sec('复查入口与引用','PROTOCOL.json包含所有生成参数、seed与预设统计；inputs/保存完整流和排列；raw/保存每步分配、残量、可行箱数、已用箱前缀与评分；analysis/保存全部逐实例及聚合CSV。FREEZE.json与ANALYSIS_FREEZE.json记录执行前版本，CHECK.json记录独立验算。详见README的重放与复跑命令。\nEoH：Liu等，ICML 2024，Figure 6、§4.1。https://proceedings.mlr.press/v235/liu24bs.html\nRAISE：Liu等，arXiv:2606.31801v1，§2.2至2.4。https://arxiv.org/html/2606.31801v1')
md=['# 固定 EoH 与 Best Fit 的分布和到达顺序检验','日期 2026年10月6日\n']
for t,txt in sections:md+=['## '+t,txt,'']
md+=['## 全部分布顺序单元','|类别|族|顺序|BF均值|EoH均值|差值均值|差值范围|EoH胜平负|','|---|---|---|---:|---:|---:|---|---|']
for s in sums:md.append(f"|{s['kind']}|{labels[s['family']]}|{orders[s['order']]}|{s['BF_mean_bins']:.2f}|{s['EoH_mean_bins']:.2f}|{s['delta_mean']:+.2f}|[{s['delta_min']:+d},{s['delta_max']:+d}]|{s['EoH_wins']}/{s['ties']}/{s['EoH_losses']}|")
(H/'REPORT_ZH.md').write_text('\n\n'.join(md)+'\n')
doc=Document();section=doc.sections[0];section.top_margin=Inches(.7);section.bottom_margin=Inches(.7);section.left_margin=Inches(.75);section.right_margin=Inches(.75)
for name in ['Normal','Title','Heading 1','Heading 2']:
 st=doc.styles[name];st.font.name='Noto Sans CJK SC';st.font.color.rgb=RGBColor(0,0,0);st._element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'),'Noto Sans CJK SC')
doc.styles['Normal'].font.size=Pt(10);doc.styles['Normal'].paragraph_format.space_after=Pt(6);doc.styles['Normal'].paragraph_format.line_spacing=1.12;doc.styles['Title'].font.size=Pt(21);doc.styles['Heading 1'].font.size=Pt(14)
doc.add_paragraph('固定 EoH 与 Best Fit 的分布和到达顺序检验','Title');doc.add_paragraph('老师P3独立控制实验  2026年10月6日')
for idx,(title,txt) in enumerate(sections):
 doc.add_heading(title,level=1)
 for para in txt.split('\n'):doc.add_paragraph(para)
 if idx==1:
  doc.add_picture(str(H/'figures/random_family_order.png'),width=Inches(6.75));doc.add_paragraph('图1 全部六随机族。每个圆点对应一个独立多重集；相同多重集的三种顺序互相配对。')
 if title=='构造最优与随机下界':
  doc.add_picture(str(H/'figures/constructed_bounds.png'),width=Inches(6.75));doc.add_paragraph('图2 三类互补构造。虚线2500箱有可行装法和体积下界双重证明。')
doc.add_heading('全部单元的箱数差值',level=1);doc.add_paragraph('差值为EoH箱数减Best Fit箱数；负值有利于EoH。四随机重复报均值与范围，构造单元只有一个多重集。')
t=doc.add_table(rows=1, cols=5);t.style='Table Grid'
for c,txt in zip(t.rows[0].cells,['族','到达流','BF / EoH均值','差值及范围','胜 / 平 / 负']):c.text=txt
for s in sums:
 rr=t.add_row().cells
 vals=[labels[s['family']],orders[s['order']],f"{s['BF_mean_bins']:.2f} / {s['EoH_mean_bins']:.2f}",f"{s['delta_mean']:+.2f} [{s['delta_min']:+d},{s['delta_max']:+d}]",f"{s['EoH_wins']} / {s['ties']} / {s['EoH_losses']}"]
 for cell,txt in zip(rr,vals):cell.text=txt
for row in t.rows:
 for cell in row.cells:
  tcPr=cell._tc.get_or_add_tcPr();m=OxmlElement('w:tcMar')
  for side in ['top','left','bottom','right']:
   el=OxmlElement('w:'+side);el.set(qn('w:w'),'90');el.set(qn('w:type'),'dxa');m.append(el)
  tcPr.append(m)
  for p in cell.paragraphs:
   for r in p.runs:r.font.size=Pt(8.5)
head=t.rows[0]._tr.get_or_add_trPr();head.append(OxmlElement('w:tblHeader'))
for c in t.rows[0].cells:
 sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'E8EEF3');c._tc.get_or_add_tcPr().append(sh)
# Remove inherited decorative title borders and prevent split table rows.
for st in doc.styles:
 for el in list(st._element.iter(qn('w:pBdr'))):el.getparent().remove(el)
for row in t.rows:
 row._tr.get_or_add_trPr().append(OxmlElement('w:cantSplit'))
for col,width in zip(t.columns,[1.2,.75,1.65,1.95,1.2]):col.width=Inches(width)
for row in t.rows:
 for cell,width in zip(row.cells,[1.2,.75,1.65,1.95,1.2]):cell.width=Inches(width)
pr=t._tbl.tblPr;b=OxmlElement('w:tblBorders')
for side in ['top','left','bottom','right','insideH','insideV']:
 el=OxmlElement('w:'+side);el.set(qn('w:val'),'single');el.set(qn('w:sz'),'4');el.set(qn('w:color'),'D9D9D9');b.append(el)
pr.append(b)
doc.save(H/'固定EoH分布与顺序检验.docx')
print('report built')
