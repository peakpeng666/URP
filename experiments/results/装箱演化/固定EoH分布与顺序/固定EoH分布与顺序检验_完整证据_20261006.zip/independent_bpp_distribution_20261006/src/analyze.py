"""Fixed all-cell descriptive summary. No selection, fitting, or reruns."""
import collections,csv,json,pathlib,statistics,os
os.environ.setdefault('MPLCONFIGDIR','/tmp/bpp_distribution_matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
H=pathlib.Path(__file__).resolve().parents[1];P=json.loads((H/'PROTOCOL.json').read_bytes());CHECK=json.loads((H/'CHECK.json').read_bytes());assert CHECK['passed']
cn=FontProperties(fname='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
labels={'weibull_3_45':'Weibull 形状3 尺度45','uniform_1_100':'整数均匀 1–100','small_beta_2_5':'偏小 Beta(2,5)','large_beta_5_2':'偏大 Beta(5,2)','normal_50_15':'裁剪正态 50±15','bimodal_20_30_70_80':'双峰 20–30 与70–80','constructed_25_75':'构造 25+75','constructed_40_60':'构造 40+60','constructed_49_51':'构造 49+51'}
orders=['random','ascending','descending']; order_labels={'random':'随机到达','ascending':'升序流','descending':'降序流'}
rows=[];groups=collections.defaultdict(list)
for meta in P['instances']:
 id=meta['instance_id'];b=json.loads((H/'raw'/f'{id}__BF.json').read_bytes());e=json.loads((H/'raw'/f'{id}__published_EoH.json').read_bytes());data=json.loads((H/'inputs'/f'{id}.json').read_bytes());lb=meta['volume_lb']
 divergence=next((i+1 for i,(x,y) in enumerate(zip(b['trajectory']['assignment'],e['trajectory']['assignment'])) if x!=y),None)
 row={'instance_id':id,'base_id':meta['base_id'],'kind':meta['kind'],'family':meta['family'],'replicate':meta['replicate'],'order':meta['order'],'volume_lb':lb,'item_mean':statistics.mean(data['items']),'item_sd':statistics.pstdev(data['items']),'item_fraction_gt50':sum(x>50 for x in data['items'])/5000,'BF_bins':b['used_bins'],'EoH_bins':e['used_bins'],'delta_bins':e['used_bins']-b['used_bins'],'BF_excess_lb_pct':100*(b['used_bins']-lb)/lb,'EoH_excess_lb_pct':100*(e['used_bins']-lb)/lb,'first_decision_divergence_step':divergence,'BF_cpu_s':b['cpu_seconds'],'EoH_cpu_s':e['cpu_seconds']}
 rows.append(row);groups[(meta['kind'],meta['family'],meta['order'])].append(row)
with (H/'analysis/per_instance.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
summary=[]
for (kind,fam,order),rr in groups.items():
 ds=[r['delta_bins'] for r in rr];summary.append({'kind':kind,'family':fam,'order':order,'n_multisets':len(rr),'BF_mean_bins':statistics.mean(r['BF_bins'] for r in rr),'EoH_mean_bins':statistics.mean(r['EoH_bins'] for r in rr),'delta_mean':statistics.mean(ds),'delta_min':min(ds),'delta_max':max(ds),'EoH_wins':sum(x<0 for x in ds),'ties':sum(x==0 for x in ds),'EoH_losses':sum(x>0 for x in ds),'BF_mean_excess_lb_pct':statistics.mean(r['BF_excess_lb_pct'] for r in rr),'EoH_mean_excess_lb_pct':statistics.mean(r['EoH_excess_lb_pct'] for r in rr)})
with (H/'analysis/family_order_summary.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(summary[0]));w.writeheader();w.writerows(summary)
order_deltas=[]
for base in sorted({r['base_id'] for r in rows}):
 rr={r['order']:r for r in rows if r['base_id']==base}
 for order in orders[1:]:
  order_deltas.append({'base_id':base,'family':rr[order]['family'],'kind':rr[order]['kind'],'order':order,'BF_change_vs_random':rr[order]['BF_bins']-rr['random']['BF_bins'],'EoH_change_vs_random':rr[order]['EoH_bins']-rr['random']['EoH_bins'],'rank_delta_change':rr[order]['delta_bins']-rr['random']['delta_bins']})
with (H/'analysis/paired_order_deltas.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(order_deltas[0]));w.writeheader();w.writerows(order_deltas)
(H/'analysis/SUMMARY.json').write_text(json.dumps({'summary':summary,'rows':rows,'order_deltas':order_deltas},ensure_ascii=False,indent=2)+'\n')
fig,axs=plt.subplots(1,3,figsize=(13,5),sharey=True,layout='constrained');families=list(P['families'])
for ax,order in zip(axs,orders):
 for i,fam in enumerate(families):
  rr=[r for r in rows if r['family']==fam and r['order']==order];ds=[r['delta_bins'] for r in rr];mean=statistics.mean(ds)
  ax.scatter(ds,[i]*4,s=32,alpha=.7,color='#4C76A6');ax.plot([min(ds),max(ds)],[i,i],color='#4C76A6');ax.scatter([mean],[i],marker='D',s=38,color='#B04632')
 ax.axvline(0,color='black',lw=.8);ax.set_title(order_labels[order],fontproperties=cn,fontsize=13);ax.set_xlabel('EoH 箱数 − Best Fit 箱数',fontproperties=cn,fontsize=10);ax.set_yticks(range(6));ax.set_yticklabels([labels[f] for f in families],fontproperties=cn,fontsize=10);ax.grid(axis='x',alpha=.2)
axs[0].invert_yaxis();fig.suptitle('固定5000物品  六分布族与三种到达流\n圆点为4个独立多重集  菱形为均值  负值有利于EoH',fontproperties=cn,fontsize=14)
fig.savefig(H/'figures/random_family_order.png',dpi=180);plt.close(fig)
fig,axs=plt.subplots(1,3,figsize=(12,4),sharey=True,layout='constrained')
for ax,fam in zip(axs,[f'constructed_{x}_{100-x}' for x in [25,40,49]]):
 rr={r['order']:r for r in rows if r['family']==fam};xx=list(range(3));ax.bar([x-.17 for x in xx],[rr[o]['BF_bins'] for o in orders],width=.34,label='Best Fit',color='#4C76A6');ax.bar([x+.17 for x in xx],[rr[o]['EoH_bins'] for o in orders],width=.34,label='EoH',color='#B04632');ax.axhline(2500,color='black',ls='--',label='OPT=2500');ax.set_xticks(xx);ax.set_xticklabels([order_labels[o] for o in orders],fontproperties=cn);ax.set_title(labels[fam],fontproperties=cn);ax.grid(axis='y',alpha=.15)
axs[0].set_ylabel('箱数',fontproperties=cn);axs[2].legend(fontsize=9);fig.suptitle('精确互补构造独立呈现  2500对互补物品给出最优见证',fontproperties=cn,fontsize=13);fig.savefig(H/'figures/constructed_bounds.png',dpi=180);plt.close(fig)
print(json.dumps({'summary':summary},ensure_ascii=False,indent=2))
