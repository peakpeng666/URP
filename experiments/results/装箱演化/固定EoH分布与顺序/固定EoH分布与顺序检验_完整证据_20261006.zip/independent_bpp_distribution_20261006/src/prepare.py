"""Prepare new finite panel without executing either policy. Only fixed public controls are read."""
import hashlib,json,pathlib,shutil,sys,platform
import numpy as np
H=pathlib.Path(__file__).resolve().parents[1]; W=H.parent
POLICIES={'BF':'f1b3010016ca5c3c95a5f583ddc071cd1a30cfaf40e270b865c95f4817387d4b','published_EoH':'de06105a3b630fc5ab6f2d823e45d5326315071208cbac8379ffe8d3a29bed7a'}
N=5000; C=100; NS='bpp_distribution_scope_20261006_v1'
def sha(x):return hashlib.sha256(x).hexdigest()
def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
def put(p,x):
 with p.open('x') as f:f.write(canon(x)+'\n')
def seed(*parts):return int.from_bytes(hashlib.sha256((NS+'|'+ '|'.join(map(str,parts))).encode()).digest()[:16],'big')
families={
 'weibull_3_45':'X=45*Weibull(shape=3)',
 'uniform_1_100':'discrete uniform integers inclusive [1,100]',
 'small_beta_2_5':'X=100*Beta(2,5)',
 'large_beta_5_2':'X=100*Beta(5,2)',
 'normal_50_15':'X=Normal(mean=50,sd=15); clipping, not rejection/truncation sampling',
 'bimodal_20_30_70_80':'independent fair Bernoulli: Uniform integers [20,30] or [70,80]'
}
records=[]; base_rows=[]
for fam in families:
 for rep in range(4):
  rng=np.random.Generator(np.random.PCG64(seed(fam,rep,'values')))
  if fam=='weibull_3_45':a=rng.weibull(3,N)*45
  elif fam=='uniform_1_100':a=rng.integers(1,101,N)
  elif fam=='small_beta_2_5':a=rng.beta(2,5,N)*100
  elif fam=='large_beta_5_2':a=rng.beta(5,2,N)*100
  elif fam=='normal_50_15':a=rng.normal(50,15,N)
  else:
   coin=rng.integers(0,2,N);lo=rng.integers(20,31,N);hi=rng.integers(70,81,N);a=np.where(coin==0,lo,hi)
  items=np.rint(np.clip(a,1,100)).astype(np.int64).tolist()
  base_rows.append({'base_id':f'{fam}_r{rep}','family':fam,'replicate':rep,'kind':'random','items':items,'value_seed':seed(fam,rep,'values'),'raw_below_1':int(np.sum(a<1)),'raw_above_100':int(np.sum(a>100))})
for x in [25,40,49]:
 fam=f'constructed_{x}_{100-x}';base_rows.append({'base_id':fam,'family':fam,'replicate':0,'kind':'constructed','items':[x]*2500+[100-x]*2500,'value_seed':None,'known_optimum':2500,'witness':'2500 bins, each containing one of each complementary size; total volume 250000 gives LB=2500'})
for base in base_rows:
 items=base.pop('items'); s=seed(base['base_id'],'random_order'); r=np.random.Generator(np.random.PCG64(s));perm=r.permutation(N).tolist()
 for order in ['random','ascending','descending']:
  idx=perm if order=='random' else sorted(range(N),key=lambda j:items[j],reverse=order=='descending')
  stream=[items[j] for j in idx];id=base['base_id']+'__'+order
  data={**base,'instance_id':id,'order':order,'n':N,'capacity':C,'items':stream,'source_position':idx,'random_order_seed':s,'volume_lb':(sum(stream)+99)//100}
  put(H/'inputs'/f'{id}.json',data)
  records.append({k:v for k,v in data.items() if k not in ('items','source_position')})
# Calibration is old public design data only, never any withheld or P1 data.
old=W/'frozen_design_controls_20261005'; data=json.loads((old/'inputs/design_5000.json').read_bytes())
for i,case in enumerate(data['cases']):
 put(H/'inputs'/f'calibration_{i}.json',{'items':case['items'],'capacity':100,'instance_id':f'calibration_{i}'})
 for policy in POLICIES:shutil.copyfile(old/'references'/f'{policy}_{i}.json',H/'evidence'/f'calibration_{policy}_{i}.json')
for p,h in POLICIES.items():assert sha((H/'sources'/f'{p}.py.txt').read_bytes())==h
protocol={'schema':'independent-bpp-distribution-v1','namespace':NS,'prepared_utc':'2026-10-06','question':'Fixed published EoH versus Best Fit at n=5000 C=100 under new size distributions and paired arrival orders','families':families,'rounding':'continuous X clipped to [1,100], np.rint ties-to-even, int; discrete families unchanged','input_normalization':'NONE. Scores receive np.int64 item and read-only np.int64 residual vector; no instance-wise rescaling or retuning.','rng':'numpy Generator PCG64; SHA256(namespace|labels) first 16 bytes big-endian seed','random_repeats_per_family':4,'orders':['random','ascending','descending'],'orders_are_streams':'Generator creates different streams of same multiset; solver does not see future or reorder. Sorted streams are structured stress tests, not i.i.d. deployment evidence.','construction_pairs':[25,40,49],'policy_hashes':POLICIES,'policy_source':'byte-identical audited frozen_design_controls_20261005/sources','host':'n empty slots, feasible ascending bin indices, first argmax. No open-bin-only shortcut. Both policies same host.','calibration':'10 executions, compare all assignment/residual/feasible-count arrays with five public old design instances for both policies before novel panel','counts':{'new_random_multisets':24,'new_random_streams':72,'constructed_multisets':3,'constructed_streams':9,'new_policy_instance_runs':162,'calibration_runs':10,'total_policy_instance_runs':172},'budget':{'numerical_cpu_hard_seconds':1200,'numerical_wall_hard_seconds':1800,'no_retries':True,'no_api':True},'outcomes':{'primary':'paired delta_bins = EoH bins - BF bins per stream; negative favors EoH','secondary':['each-policy bin counts','excess_vs_volume_LB_percent','order delta relative to random same multiset','full trajectory first divergence','CPU/wall measured in this host only'],'aggregation':'per family x order mean/range across 4 independent multisets; W/T/L; all cells included; constructions separate; no pooled deployment-population estimate','inference':'exploratory finite-panel evidence, no statistical significance or universal guarantee; paired orders not independent replicates; only constructed optimality proved by witnesses'},'information_firewall':['no original132 heldout reads','no current P1 results read','no new generated candidate','no changes to old prompts/selection/freezes/data','new seeds are not the original study untouched confirmation set'],'environment':{'python':sys.version,'numpy':np.__version__,'platform':platform.platform()},'instances':records}
put(H/'PROTOCOL.json',protocol)
files={str(p.relative_to(H)):sha(p.read_bytes()) for d in ['src','sources','inputs','evidence'] for p in sorted((H/d).rglob('*')) if p.is_file()};files['PROTOCOL.json']=sha((H/'PROTOCOL.json').read_bytes())
put(H/'FREEZE.json',{'schema':'file-freeze-v1','files':files,'generated_before_policy_execution':True})
print(canon({'freeze_sha256':sha((H/'FREEZE.json').read_bytes()),'instances':len(records),'files':len(files)}))
