# 固定 EoH 与 Best Fit 的分布和到达顺序检验

本实验固定容量100、每流5000件、整数尺寸1至100。它是老师P3的独立适用范围检验，不是RAISE复现、算法搜索、模型生成或原132研究的确认测试。

## 文件

- PROTOCOL.json 和 FREEZE.json：执行前合同、seed派生、输入和源码哈希
- sources：仅两个已审可信控制；与旧控制逐字节相同
- src/prepare.py：六随机分布族与三互补构造的确定性准备程序
- src/run.py：只接纳两个固定哈希的向量化在线宿主；不是新候选安全沙箱
- src/check.py：无NumPy/策略导入的整数重放与独立标量决策验算
- src/analyze.py：所有单元完整汇总，不筛选获胜单元
- inputs：所有完整5000件流、生成seed与原位置排列
- raw：每次执行的5000步分配、残量前后、可行箱数、分数与已用箱前缀
- analysis：逐实例结果、分布族与顺序聚合、配对顺序差异
- figures：中文结果图

## 在当前证据包上复查

先检查 FREEZE.json 各文件SHA256，再运行 python -B src/check.py 和 python -B src/analyze.py。check.py重放全部整数轨迹及独立评分决策，不重新执行两个控制。

## 从完整冻结输入重新执行

在全新副本中保留冻结输入/源文件，不使用任何旧输出。将原 raw、RUN_STARTED.json、RUN_COMPLETE.json、CALIBRATION.json 等结果移至单独历史副本；不要就地覆盖本归档。空 raw 目录准备后运行：

OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 timeout --signal=TERM --kill-after=5 1800 prlimit --cpu=1200:1200 -- python -B src/run.py

之后运行 src/check.py 和 src/analyze.py。run.py以独占创建防重复，已有RUN_STARTED时拒绝；失败时不自动重试。

## 重新生成输入

prepare.py在空目录中创建输入，源控制与旧公开校准输入通过固定路径复制。归档已包含全部冻结输入，常规复跑不需要依赖外部旧研究目录。跨NumPy版本重新抽样不宣称位级复现；完整输入JSON是权威合同。四重复只是有限探索，三种顺序共享同一多重集，不能当三份独立样本。

## 来源

EoH固定函数对应ICML 2024论文Figure 6。来源与代码许可见LICENSE.source。

https://proceedings.mlr.press/v235/liu24bs.html

RAISE只为本轮分布测试提供问题背景，未实现其对抗搜索、投影、重评或演化：

https://arxiv.org/html/2606.31801v1
