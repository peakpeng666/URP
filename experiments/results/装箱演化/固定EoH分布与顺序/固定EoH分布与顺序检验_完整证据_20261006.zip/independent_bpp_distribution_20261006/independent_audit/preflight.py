from pathlib import Path
import json,hashlib,collections,datetime,ast
import numpy as np
A=Path(__file__).resolve().parent
H=A.parent if (A.parent/'PROTOCOL.json').is_file() and (A.parent/'FREEZE.json').is_file() else A.parent/'independent_bpp_distribution_20261006'
O=H.parent/'frozen_design_controls_20261005'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
F='c8bf449095b24dc5b9fdfd9463cf4ae4624a560a4b37fb1c5c2e18700d75d63b';assert sha(H/'FREEZE.json')==F
f=json.loads((H/'FREEZE.json').read_text());assert all(sha(H/n)==h for n,h in f['files'].items())
assert sha(H/'src/run.py')=='b667927fd92d5f78fec491c0c340610d1bbfd7b7c659279662e9f68435d6d961'
af=json.loads((H/'ANALYSIS_FREEZE.json').read_text());assert af['created_before_policy_execution'] and sha(H/'src/analyze.py')==af['source_sha256']
assert not (H/'RUN_STARTED.json').exists() and not list((H/'raw').glob('*'))
P=json.loads((H/'PROTOCOL.json').read_text()); assert len(P['instances'])==81 and np.__version__==P['environment']['numpy']
NS=P['namespace'];seed=lambda *s:int.from_bytes(hashlib.sha256((NS+'|'+'|'.join(map(str,s))).encode()).digest()[:16],'big')
base={}
for m in P['instances']:
 d=json.loads((H/'inputs'/f"{m['instance_id']}.json").read_text());assert all(d[k]==v for k,v in m.items());assert d['n']==5000 and d['capacity']==100
 xs=d['items'];pos=d['source_position'];assert len(xs)==5000 and all(type(i)is int and 1<=i<=100 for i in xs);assert sorted(pos)==list(range(5000));assert d['volume_lb']==(sum(xs)+99)//100
 if d['base_id'] not in base:
  restored=[None]*5000
  for i,j in enumerate(pos):restored[j]=xs[i]
  fam=d['family'];rep=d['replicate']
  if d['kind']=='random':
   s=seed(fam,rep,'values');assert s==d['value_seed'];r=np.random.Generator(np.random.PCG64(s))
   if fam=='weibull_3_45':v=45*r.weibull(3,5000)
   elif fam=='uniform_1_100':v=r.integers(1,101,5000)
   elif fam=='small_beta_2_5':v=100*r.beta(2,5,5000)
   elif fam=='large_beta_5_2':v=100*r.beta(5,2,5000)
   elif fam=='normal_50_15':v=r.normal(50,15,5000)
   elif fam=='bimodal_20_30_70_80':
    c=r.integers(0,2,5000);l=r.integers(20,31,5000);u=r.integers(70,81,5000);v=np.where(c==0,l,u)
   else:raise AssertionError(fam)
   expected=np.rint(np.clip(v,1,100)).astype(np.int64).tolist();assert int(sum(v<1))==d['raw_below_1'] and int(sum(v>100))==d['raw_above_100']
  else:
   a,b=map(int,fam.split('_')[1:]);assert a+b==100;expected=[a]*2500+[b]*2500;assert d['known_optimum']==2500 and d['volume_lb']==2500
  assert restored==expected;base[d['base_id']]=restored
 source=base[d['base_id']];assert xs==[source[i] for i in pos]
 assert d['random_order_seed']==seed(d['base_id'],'random_order')
 if d['order']=='random':expected_pos=np.random.Generator(np.random.PCG64(d['random_order_seed'])).permutation(5000).tolist()
 else:expected_pos=sorted(range(5000),key=source.__getitem__,reverse=d['order']=='descending')
 assert pos==expected_pos
assert len(base)==27
old=json.loads((H/'evidence/PREEXEC_FREEZE_v0.json').read_text());assert all(old['files'][n]==v for n,v in f['files'].items() if n.startswith(('inputs/','sources/')))
wf=json.loads((O/'accepted_worker_freeze.json').read_text());assert sha(O/'runtime/facade.py')==wf['files']['facade.py'];assert sha(O/'runtime/runner.py')==wf['files']['runner.py']
for name,h in P['policy_hashes'].items():assert sha(H/'sources'/f'{name}.py.txt')==h==sha(O/'sources'/f'{name}.py.txt')
legacy=json.loads((O/'inputs/design_5000.json').read_text())
for i in range(5):
 assert json.loads((H/'inputs'/f'calibration_{i}.json').read_text())['items']==legacy['cases'][i]['items']
 for name in P['policy_hashes']:assert sha(H/'evidence'/f'calibration_{name}_{i}.json')==sha(O/'references'/f'{name}_{i}.json')
out={'status':'PASS_PREEXECUTION_ADMISSION','time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'freeze_sha256':F,'runner_sha256':sha(H/'src/run.py'),'checked_frozen_files':len(f['files']),'analysis_sha256':af['source_sha256'],'new_input_streams_regenerated_and_validated':81,'independent_multisets':27,'calibration_inputs_and_reference_sources_validated':10,'source_review':'Both full source files read; fixed SHA allowlist checked; no arbitrary candidate entrypoint. Only trusted controls admitted.','facade_reference_sha256':wf['files']['facade.py'],'contract':'np.int64 item and read-only np.int64 feasible residual vector; 5000 empty capacity-100 bins; ascending feasible indices and exact first argmax; no lookahead or solver sorting.','limits':'Launch with timeout 1800 plus kill-after 5, prlimit CPU=1200:1200, single-thread BLAS. Capture shell exit and log externally for hard-kill evidence. No retries.','numerical_caveat':'Scalar math checker uses score tolerance, so it verifies exact selected actions and integer trajectories, not bitwise score equivalence. Hard budget termination may lack current partial raw file; preserve outer log and exit status.','scope':'144 random + 18 constructed + 10 historical calibration; fixed-policy finite-panel stress test; no RAISE implementation, no new model generation, no original132 heldout or current P1 access.'}
(A/'PREFLIGHT.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out,ensure_ascii=False))
