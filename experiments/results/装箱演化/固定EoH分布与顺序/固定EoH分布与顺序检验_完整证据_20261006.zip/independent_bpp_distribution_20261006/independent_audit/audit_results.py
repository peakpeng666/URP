"""Independent audit: integer bitset state and separately parenthesized math oracle.
Reads only this experiment and the audit's preflight. Does not import/execute policies.
"""
import pathlib,json,hashlib,math,collections,statistics,csv,time,datetime
A=pathlib.Path(__file__).resolve().parent
H=A.parent if (A.parent/'PROTOCOL.json').is_file() and (A.parent/'FREEZE.json').is_file() else A.parent/'independent_bpp_distribution_20261006'
canon=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda p:json.loads(p.read_bytes())
def scalar(item,space,p):
 if p=='BF':return -(space-item)
 difference=space-item;exponential=math.exp(difference);root=math.sqrt(difference)
 fullness=1-difference/space;combination=fullness*root
 adjustment=combination+(0.8 if difference>item*3 else 0.3)
 denominator=(exponential+0.7)*exponential
 return space/denominator+adjustment
T={p:{i:{s:scalar(i,s,p) for s in range(i,101)} for i in range(1,101)} for p in ('BF','published_EoH')}
# Examine the complete 5050 point (item,residual) domain for cross-residual ties.
gaps=[];domain_ties=[]
for i in range(1,101):
 ranked=sorted((v,s) for s,v in T['published_EoH'][i].items())
 for (v,s),(w,t) in zip(ranked,ranked[1:]):
  if v==w:domain_ties.append([i,s,t,v])
  else:gaps.append([w-v,i,s,t])
P=read(H/'PROTOCOL.json');F=read(H/'FREEZE.json');start=time.process_time()
assert sha((H/'FREEZE.json').read_bytes())==read(A/'PREFLIGHT.json')['freeze_sha256']
assert all(sha((H/n).read_bytes())==h for n,h in F['files'].items())
assert read(H/'RUN_COMPLETE.json')['status']=='complete' and not (H/'RUN_FAILURE.json').exists()
expected={(f'calibration_{i}',p) for i in range(5) for p in T}
expected.update((m['instance_id'],p) for m in P['instances'] for p in T)
expected_names={f'{i}__{p}.json' for i,p in expected}
assert {p.name for p in (H/'raw').glob('*.json')}==expected_names
checks=[];runs={};score_exact=0;score_within_tol=0;max_score_error=0;min_selected_gap=math.inf;cross_residual_top_ties=0
for instance,policy in sorted(expected):
 path=H/'raw'/f'{instance}__{policy}.json';r=read(path);d=read(H/'inputs'/f'{instance}.json');xs=d['items'];tr=r['trajectory']
 assert (r['instance_id'],r['policy'])==(instance,policy);assert r['source_sha256']==P['policy_hashes'][policy]
 assert r['status']=='complete' and r['error'] is None and r['steps']==5000
 assert len(xs)==5000 and all(type(x)is int and 1<=x<=100 for x in xs)
 assert sha(canon(xs).encode())==r['items_sha256']
 assert set(tr)=={'assignment','pre_remaining','post_remaining','feasible_counts','score_selected','used_bins_after'} and all(len(x)==5000 for x in tr.values())
 slots=[100]*5000;buckets=[0]*101;buckets[100]=(1<<5000)-1;populations=[0]*101;populations[100]=5000;used=0;volume=0
 for k,item in enumerate(xs):
  candidates=[]
  for space in range(item,101):
   mask=buckets[space]
   if mask:
    minimum_index=(mask&-mask).bit_length()-1
    candidates.append((T[policy][item][space],-minimum_index,space))
  ordered=sorted(candidates,reverse=True);value,neg_index,space=ordered[0];index=-neg_index
  if policy=='published_EoH' and len(ordered)>1:
   if ordered[1][0]==value:cross_residual_top_ties+=1
   else:min_selected_gap=min(min_selected_gap,value-ordered[1][0])
  assert type(tr['assignment'][k])is int and tr['assignment'][k]==index,(instance,policy,k,'first argmax mismatch',tr['assignment'][k],index)
  assert sum(populations[item:])==tr['feasible_counts'][k]
  assert slots[index]==space and space>=item and tr['pre_remaining'][k]==space
  actual=tr['score_selected'][k];error=abs(actual-value);max_score_error=max(error,max_score_error)
  assert type(actual)in (int,float) and math.isfinite(actual) and math.isclose(actual,value,rel_tol=2e-14,abs_tol=2e-14),(instance,policy,k,'score',actual,value)
  score_exact+=int(actual==value);score_within_tol+=int(actual!=value)
  post=space-item;bit=1<<index;buckets[space]^=bit;buckets[post]|=bit;populations[space]-=1;populations[post]+=1;slots[index]=post
  used+=int(space==100);volume+=item
  assert tr['post_remaining'][k]==post and tr['used_bins_after'][k]==used
 assert slots==r['remaining'];assert all(type(x)is int and 0<=x<=100 for x in slots)
 assert used==r['used_bins']==5000-populations[100]==sum(x!=100 for x in slots)
 assert volume==sum(100-x for x in slots)==sum(xs)
 if instance.startswith('calibration_'):
  old=read(H/'evidence'/f"calibration_{policy}_{instance.split('_')[-1]}.json")
  assert all((tr['assignment'] if k=='assignment' else tr['feasible_counts'] if k=='feasible_counts' else r[k])==old[k] for k in ['assignment','feasible_counts','remaining','used_bins'])
 runs[instance,policy]=r
 checks.append({'instance_id':instance,'policy':policy,'raw_sha256':sha(path.read_bytes()),'bins':used,'placements':5000})
rows=[];groups=collections.defaultdict(list);opt_witness=[]
for m in P['instances']:
 i=m['instance_id'];d=read(H/'inputs'/f'{i}.json');b=runs[i,'BF'];e=runs[i,'published_EoH'];lb=(sum(d['items'])+99)//100
 assert lb==d['volume_lb']==m['volume_lb']
 if m['kind']=='constructed':
  counts=collections.Counter(d['items']);assert len(counts)==2 and sum(counts)==100 and list(counts.values())==[2500,2500]
  assert lb==2500==m['known_optimum'];opt_witness.append({'instance_id':i,'optimal_bins':2500,'BF_gap_bins':b['used_bins']-2500,'EoH_gap_bins':e['used_bins']-2500})
 divergence=next((k+1 for k,(x,y) in enumerate(zip(b['trajectory']['assignment'],e['trajectory']['assignment'])) if x!=y),None)
 row={'instance_id':i,'base_id':m['base_id'],'kind':m['kind'],'family':m['family'],'replicate':m['replicate'],'order':m['order'],'volume_lb':lb,'item_mean':statistics.mean(d['items']),'item_sd':statistics.pstdev(d['items']),'item_fraction_gt50':sum(x>50 for x in d['items'])/5000,'BF_bins':b['used_bins'],'EoH_bins':e['used_bins'],'delta_bins':e['used_bins']-b['used_bins'],'BF_excess_lb_pct':100*(b['used_bins']-lb)/lb,'EoH_excess_lb_pct':100*(e['used_bins']-lb)/lb,'first_decision_divergence_step':divergence,'BF_cpu_s':b['cpu_seconds'],'EoH_cpu_s':e['cpu_seconds']}
 rows.append(row);groups[m['kind'],m['family'],m['order']].append(row)
summary=[]
for (kind,fam,order),rs in groups.items():
 ds=[r['delta_bins'] for r in rs]
 summary.append({'kind':kind,'family':fam,'order':order,'n_multisets':len(rs),'BF_mean_bins':statistics.mean(r['BF_bins'] for r in rs),'EoH_mean_bins':statistics.mean(r['EoH_bins'] for r in rs),'delta_mean':statistics.mean(ds),'delta_min':min(ds),'delta_max':max(ds),'EoH_wins':sum(x<0 for x in ds),'ties':sum(x==0 for x in ds),'EoH_losses':sum(x>0 for x in ds),'BF_mean_excess_lb_pct':statistics.mean(r['BF_excess_lb_pct'] for r in rs),'EoH_mean_excess_lb_pct':statistics.mean(r['EoH_excess_lb_pct'] for r in rs)})
order_deltas=[]
for base in sorted({r['base_id'] for r in rows}):
 rs={r['order']:r for r in rows if r['base_id']==base}
 for order in ['ascending','descending']:
  order_deltas.append({'base_id':base,'family':rs[order]['family'],'kind':rs[order]['kind'],'order':order,'BF_change_vs_random':rs[order]['BF_bins']-rs['random']['BF_bins'],'EoH_change_vs_random':rs[order]['EoH_bins']-rs['random']['EoH_bins'],'rank_delta_change':rs[order]['delta_bins']-rs['random']['delta_bins']})
analysis=read(H/'analysis/SUMMARY.json');assert analysis=={'summary':summary,'rows':rows,'order_deltas':order_deltas}
assert read(H/'CHECK.json')['checked_runs']==172 and read(H/'CHECK.json')['passed']
rc=read(H/'RUN_COMPLETE.json');assert rc['new_runs']==162 and rc['calibration_runs']==10 and rc['model_calls']==0
assert len(rc['rows'])==162 and {(r['instance_id'],r['policy']) for r in rc['rows']}=={(m['instance_id'],p) for m in P['instances'] for p in T}
for r in rc['rows']:assert all(v==runs[r['instance_id'],r['policy']][k] for k,v in r.items())
assert rc['total_cpu_seconds']>=sum(r['cpu_seconds'] for r in runs.values()) and rc['total_cpu_seconds']<1200 and rc['total_wall_seconds']<1800
out={'status':'PASS_INDEPENDENT_RESULT_AUDIT','checked_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checked_runs':172,'integer_placements_and_exact_selected_decisions':860000,'score_values_exact_numeric_equal':score_exact,'score_values_only_within_tolerance':score_within_tol,'max_score_absolute_difference':max_score_error,'score_tolerance':{'rel':2e-14,'abs':2e-14},'min_observed_EoH_top_gap_across_different_residuals':min_selected_gap,'observed_EoH_top_ties_across_different_residuals':cross_residual_top_ties,'complete_integer_domain_EoH_min_distinct_score_gap':min(gaps),'complete_integer_domain_EoH_cross_residual_equal_scores':domain_ties,'independent_algorithm':'Residual-index bitsets; first set bit gives smallest bin index; scalar math score with original source grouping; no NumPy or policy imports/execution','analysis_agreement':'All 81 per-stream rows, 27 family/order cells, 54 paired-order rows exactly match recomputation','calibration_agreement':'All 10 full assignment/residual/feasible-count/bin-count arrays match public historical references','construction_witnesses':opt_witness,'producer_cpu_seconds':rc['total_cpu_seconds'],'producer_wall_seconds':rc['total_wall_seconds'],'independent_audit_cpu_seconds':time.process_time()-start,'limitations':['Exact selected-decision agreement for this finite panel is not bitwise numerical equality or a proof for other domains.','Four fresh independent multisets per random family; paired sorted streams are dependent structured stress tests.','Volume lower bound is not generally the true optimum; only the three complementary constructions have a proved 2500-bin optimum.','Fixed trusted-policy stress test, not RAISE implementation, LLM generation or field/deployment generalization.'],'checks':checks,'summary':summary}
(A/'RESULT_AUDIT.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
for name,values in [('independent_per_instance.csv',rows),('independent_family_order_summary.csv',summary),('independent_order_deltas.csv',order_deltas)]:
 with (A/name).open('w') as f:w=csv.DictWriter(f,fieldnames=list(values[0]));w.writeheader();w.writerows(values)
print(json.dumps({k:v for k,v in out.items() if k not in ('checks','summary','construction_witnesses')},ensure_ascii=False,indent=2))
print('ALL CELL SUMMARY');print(json.dumps(summary,ensure_ascii=False,indent=2))
