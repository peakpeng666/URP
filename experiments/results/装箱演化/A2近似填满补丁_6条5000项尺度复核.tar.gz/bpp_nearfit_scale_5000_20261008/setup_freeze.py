"""Static A2 preparation: no candidate compilation/execution, no random draw."""
import ast,os,sys,time,resource,signal,difflib
from pathlib import Path
from common import ROOT,METHODS,read,put,need,sha
sys.dont_write_bytecode=True;os.umask(0o077)
resource.setrlimit(resource.RLIMIT_CPU,(5,5));signal.alarm(8);started=time.monotonic()
A1=Path('/workspace/shared/bpp_nearfit_ablation_20261008')
C1=Path('/workspace/shared/prospective_confirmation_C1_preparation_20261007')
need(not (ROOT/'source_freeze.json').exists(),'freeze once')
review=Path('/workspace/shared/audit_bpp_nearfit_setup_20261008/A1_RESULT_REVIEW.json')
need(sha(review.read_bytes())=='dcfc084e3a2d24e65fd5a0706ffa0e0a56c4b96037a634161f2f73f7b0f14401','prior A1 audit identity')
oldfreeze=read(A1/'source_freeze.json')
for n,h in oldfreeze['files'].items():need(sha((A1/n).read_bytes())==h,'readonly A1 frozen identity '+n)
for n in ['methods.json','toy.json','guard_collect.py','guard_collect_blocking.py']:
 need((ROOT/n).read_bytes()==(A1/n).read_bytes(),'byte-identical A1 '+n)
methods=read(ROOT/'methods.json')['methods']
need(set(methods)==set(METHODS),'three fixed methods')
need(methods['EOH_nearfit_one']['code_sha256']=='6bff5a3b26ab13b6ae688cdccca88d647168dd9297d0184b605a5ae3bba39546','fixed unique patch')
for m,v in methods.items():need(sha(v['code'].encode())==v['code_sha256'],'source hash');ast.parse(v['code'])
original_runtime=read(ROOT/'frozen_runtime/worker_freeze.json')
for p in (A1/'frozen_runtime').rglob('*'):
 if p.is_file():need(p.read_bytes()==(ROOT/'frozen_runtime'/p.relative_to(A1/'frozen_runtime')).read_bytes(),'runtime byte-identical A1')
for n,h in original_runtime['files'].items():need(sha((ROOT/'frozen_runtime'/n).read_bytes())==h,'original36 runtime bytes '+n)
manifest_sources={'A1_DATA_MANIFEST.json':A1/'data_manifest.json','A1_EXCLUSIONS.json':A1/'exclusions.json','C1_DATA_MANIFEST.json':C1/'DATA_MANIFEST.json','PUBLIC_EXCLUSION_MANIFEST.json':C1/'PUBLIC_EXCLUSION_MANIFEST.json'}
for n,p in manifest_sources.items():need((ROOT/'source_evidence'/n).read_bytes()==p.read_bytes(),'exact exclusion metadata copy')
a1data=read(ROOT/'source_evidence/A1_DATA_MANIFEST.json');oldex=read(ROOT/'source_evidence/A1_EXCLUSIONS.json');c1data=read(ROOT/'source_evidence/C1_DATA_MANIFEST.json');public=read(ROOT/'source_evidence/PUBLIC_EXCLUSION_MANIFEST.json')
h1000=sorted(set(oldex['prior_1000_prefix_sha256']+[x['items_sha256'] for x in a1data['instances']]))
h5000=sorted(set([x['items_sha256'] for x in public['entries'] if x['n']==5000]+[x['items_sha256'] for x in c1data['instances']]))
need(len(h1000)==33 and len(h5000)==25,'known exact exclusion scope')
put(ROOT/'exclusions.json',{'prior_1000_prefix_sha256':h1000,'prior_5000_items_sha256':h5000,'source_manifest_sha256':{n:sha((ROOT/'source_evidence'/n).read_bytes()) for n in manifest_sources},'known_coverage':'33 known public/C1/A1 prefixes and25 public/C1 full5000 hashes. No old arrays, seeds, scores or difficulty read for generation; no unavailable historical heldout equality claim.','quality_selection':False,'exact_equality_only':True})
policy=read(ROOT/'original_draft.json');need(policy['new_data']['independent_sequences']==6 and policy['new_data']['items_per_sequence']==5000,'fixed scale');put(ROOT/'policy.json',policy)
for p in ROOT.glob('*.py'):ast.parse(p.read_text())
need("+'/instance/0'" in (ROOT/'driver.py').read_text() and "['canonical_text']" in (ROOT/'driver.py').read_text() and "['checker_status']=='passed'" in (ROOT/'guard.py').read_text(),'ABI static checks')
changes={n:''.join(difflib.unified_diff((A1/n).read_text().splitlines(True),(ROOT/n).read_text().splitlines(True),fromfile='A1/'+n,tofile='A2/'+n)) for n in ['common.py','driver.py','guard.py','dispatch.py','generate.py','analysis.py']}
put(ROOT/'source_delta.json',{'baseline_source_freeze_sha256':sha((A1/'source_freeze.json').read_bytes()),'baseline_result_audit_sha256':sha(review.read_bytes()),'exact_A1_method_registry_bytes':True,'exact_A1_runtime_bytes':True,'blocking_collectors_byte_identical':True,'diffs':changes})
names=sorted([p.name for p in ROOT.glob('*.py')]+['original_draft.json','MINIMAL_CHANGES.md','source_delta.json','methods.json','toy.json','exclusions.json','policy.json']+[str(p.relative_to(ROOT)) for folder in ('frozen_runtime','source_evidence') for p in (ROOT/folder).rglob('*') if p.is_file()])
put(ROOT/'source_freeze.json',{'schema':'A2-source-method-analysis-policy-freeze-v1','files':{n:sha((ROOT/n).read_bytes()) for n in names},'candidate_evaluations':0,'research_entropy_draws':0,'original_runtime_files_verified':len(original_runtime['files']),'science_enabled':False})
put(ROOT/'setup_completion.json',{'status':'frozen_static_PASS','source_freeze_sha256':sha((ROOT/'source_freeze.json').read_bytes()),'self_CPU_at_emit':time.process_time(),'wall_at_emit':time.monotonic()-started,'candidate_execution':False,'source_compile':False,'ast_parse_only':True,'OS_CPU_limit':5,'OS_wall_alarm':8})
print('Static PASS; all A2 source, unchanged methods, analysis and policy frozen; zero candidate calls/entropy draws.')
