"""Locked A2 results-only descriptive analysis; no candidate evaluation."""
from fractions import Fraction
from common import ROOT,METHODS,read,need,sha,digest
def value(f):return {'numerator':f.numerator,'denominator':f.denominator,'decimal':float(f)}
def proxies(items,result):
 remaining=[100]*len(items);hist=[0]*101;opened=0;r1=0;voluntary=0;forced=0
 for item,b in zip(items,result['assignment']):
  before=remaining[b];need(before>=item,'replay feasibility');new=before==100
  if new:
   need(b==opened,'stable original-index opening');opened+=1
   if sum(hist[item:100]):voluntary+=1
   else:forced+=1
  else:hist[before]-=1
  after=before-item;hist[after]+=1;remaining[b]=after;r1+=int(after==1)
 need(remaining==result['remaining'] and opened==result['used_bins'],'exact saved replay')
 return {'r1_placements':r1,'final_r1_bins':hist[1],'final_capacity_r11_45':sum(r*hist[r] for r in range(11,46)),'full_bins':hist[0],'voluntary_openings':voluntary,'forced_openings':forced}
def analyze():
 seal=read(ROOT/'data_seal.json');refs=read(ROOT/'raw_terminal_freeze.json');records=[];scores={};rows={};coverage={}
 for x in seal['packs']:
  aid=x['action_id'];i=x['sequence_index'];mid=x['method'];p=ROOT/'results'/(aid+'.json')
  row={'sequence_index':i,'method':mid,'status':'missing','used_bins':None,'F':None,'mechanism':None}
  if p.exists():
   need(refs[p.name]==sha(p.read_bytes()),'raw terminal sealed');t=read(p);claim=read(ROOT/'claims'/(aid+'.json'))
   need(t['claim_sha256']==digest(claim),'terminal claim')
   if t['status']=='passed':
    y=t['payload'];need(y['input_sha256']==x['input_sha256'] and y['code_sha256']==x['code_sha256'] and y['method']==mid and y['sequence_index']==i,'exact source/input/action')
    need(y['outcome']=='ok' and y['checker']['checker_status']=='passed','checked result')
    raw=(ROOT/x['relative_file']).read_bytes();need(sha(raw)==x['file_sha256'],'sealed item bytes');items=__import__('json').loads(raw)['items'];lb=(sum(items)+99)//100;bins=y['checker']['used_bins']
    need(y['L1']==lb and lb<=bins<=5000,'valid integer counts');scores[i,mid]=Fraction(lb,bins)
    row.update(status='ok',used_bins=bins,F=value(scores[i,mid]),L1=lb,mechanism=proxies(items,y['original_pack_report']['result']))
   else:row['status']=t['status']
  records.append(row);rows[i,mid]=row
 need(len(records)==18 and len(rows)==18,'all fixed slots retained')
 for mid in METHODS:coverage[mid]={'complete':sum((i,mid) in scores for i in range(6)),'denominator':6,'failures':[rows[i,mid]['status'] for i in range(6) if rows[i,mid]['status']!='ok']}
 import numpy as np
 indices=np.random.Generator(np.random.PCG64(20261008)).integers(0,6,size=(20000,6));contrasts={}
 for other in ('EOH_original','published_EoH'):
  valid=[i for i in range(6) if (i,'EOH_nearfit_one') in scores and (i,other) in scores]
  item={'complete_pairs':len(valid),'denominator':6,'full6_result':None}
  if len(valid)==6:
   diffs=[scores[i,'EOH_nearfit_one']-scores[i,other] for i in range(6)];bins=[rows[i,'EOH_nearfit_one']['used_bins']-rows[i,other]['used_bins'] for i in range(6)];vals=np.asarray([float(d) for d in diffs])[indices].mean(axis=1)
   item['full6_result']={'mean_paired_F_difference':value(sum(diffs,Fraction())/6),'paired_F_differences':[value(d) for d in diffs],'paired_bins_patch_minus_comparator':bins,'total_bin_savings':-sum(bins),'wins_ties_losses':[sum(d>0 for d in diffs),sum(d==0 for d in diffs),sum(d<0 for d in diffs)],'descriptive_95_percentile_bootstrap':np.quantile(vals,[.025,.975],method='linear').tolist(),'resamples':20000,'analysis_seed':20261008,'bootstrap_only_descriptive':True}
  contrasts['EOH_nearfit_one_minus_'+other]=item
 return {'schema':'A2-mechanism-screen-v1','independent_sequences':6,'items_per_sequence':5000,'records':records,'coverage':coverage,'contrasts':contrasts,'primary':'EOH_nearfit_one_minus_EOH_original','primary_full6_null_unless_all6_complete':True,'p_value':None,'confirmatory_superiority_claim':False,'generalization_guarantee':False,'5000_item_scale_check':True,'small_sample_descriptive_only':True,'missing_imputation':None,'data_seal_sha256':sha((ROOT/'data_seal.json').read_bytes()),'analysis_source_sha256':sha(__import__('pathlib').Path(__file__).read_bytes())}
