"""Small A2-only durable records and immutable input/source bindings."""
from pathlib import Path
import hashlib,json,os,sys
ROOT=Path(__file__).resolve().parent
METHODS=('EOH_original','EOH_nearfit_one','published_EoH')
def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
def sha(b):return hashlib.sha256(b).hexdigest()
def digest(x):return sha(canon(x).encode())
def read(p):return json.loads(Path(p).read_text())
def need(x,msg):
 if not x:raise RuntimeError(msg)
def put(p,x):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:f.write((canon(x)+'\n').encode());f.flush();os.fsync(f.fileno())
 fd=os.open(p.parent,os.O_RDONLY|os.O_DIRECTORY)
 try:os.fsync(fd)
 finally:os.close(fd)
def verify_source():
 f=read(ROOT/'source_freeze.json')
 for n,h in f['files'].items():need(sha((ROOT/n).read_bytes())==h,'source drift: '+n)
 return sha((ROOT/'source_freeze.json').read_bytes())
def source(mid,aid):
 reg=read(ROOT/'methods.json');m=reg['methods'][mid]
 c={k:m[k] for k in ('description','code','description_sha256','code_sha256','pair_sha256','description_consistency')}
 need(sha(c['code'].encode())==c['code_sha256'],'source SHA')
 sys.path.insert(0,str(ROOT/'frozen_runtime'))
 from resource_profile import PRODUCTION_PROFILE_ID,profile_sha256
 from policy import policy_sha256
 claim=digest(['A2-source-claim',aid]);b={'batch_id':'A2-nearfit-20261008','wave_id':aid,'slot_id':mid,'raw_response_sha256':digest(m),'source_sha256':c['code_sha256'],'policy_sha256':policy_sha256(),'runtime_freeze_sha256':sha((ROOT/'frozen_runtime/worker_freeze.json').read_bytes()),'claim_sha256':digest(['A2-typed-source-claim',claim]),'claim_id':claim,'registry_sha256':digest(reg),'resource_profile_sha256':profile_sha256(PRODUCTION_PROFILE_ID)}
 return c,b,m['origin']
