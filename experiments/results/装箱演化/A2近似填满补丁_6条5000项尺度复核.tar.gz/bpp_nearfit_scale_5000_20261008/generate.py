"""One fresh A2 entropy draw after source/analysis freeze and all3 toy gates."""
import os,sys,resource,signal,time,hmac,hashlib
sys.dont_write_bytecode=True;os.umask(0o077)
from common import ROOT,METHODS,read,put,need,sha,digest,verify_source
resource.setrlimit(resource.RLIMIT_CPU,(5,5));resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912));signal.signal(signal.SIGALRM,signal.SIG_DFL);signal.alarm(8)
started=time.monotonic();fh=verify_source();need(not (ROOT/'HALT.json').exists(),'HALT')
for m in METHODS:need(read(ROOT/'results'/('toy_'+m+'.json'))['status']=='passed','all toy/admission gates')
put(ROOT/'custody/generation_claim.json',{'source_freeze_sha256':fh,'entropy_draws_max':1,'instances':6,'no_retry':True})
import numpy as np
need(np.__version__=='2.3.5','exact generator version')
master=os.getrandom(32);need(len(master)==32,'one full entropy draw')
with (ROOT/'custody/master.bin').open('xb') as f:f.write(master);f.flush();os.fsync(f.fileno())
put(ROOT/'custody/master_commitment.json',{'sha256':sha(b'A2-nearfit-master-v1|'+master),'private_entropy_not_disclosed':True})
entries=[];seen=set();exclusion=read(ROOT/'exclusions.json');ph=sha((ROOT/'policy.json').read_bytes());methods=read(ROOT/'methods.json')['methods']
for i in range(6):
 msg=('A2-nearfit-instance-v1|'+ph+'|'+f'{i:02d}').encode();seed=int.from_bytes(hmac.new(master,msg,hashlib.sha256).digest()[:16],'big')
 rng=np.random.Generator(np.random.PCG64(seed));items=np.round(np.clip(45*rng.weibull(3,size=5000),1,100)).astype(np.int64).tolist()
 ih=digest(items);need(ih not in seen and ih not in exclusion['prior_5000_items_sha256'] and digest(items[:1000]) not in exclusion['prior_1000_prefix_sha256'],'duplicate input or prefix; stop without replacement');seen.add(ih)
 data={'items':items,'capacity':100};rel=f'custody/instances/{i:02d}.json';put(ROOT/rel,data)
 entries.append({'sequence_index':i,'relative_file':rel,'file_sha256':sha((ROOT/rel).read_bytes()),'input_sha256':digest(data),'items_sha256':ih,'n':5000,'capacity':100})
manifest={'source_freeze_sha256':fh,'generator_source_sha256':sha(__import__('pathlib').Path(__file__).read_bytes()),'policy_sha256':ph,'numpy':np.__version__,'entropy_draws':1,'generation_attempts':1,'quality_filtering':False,'candidate_evaluations_before_seal':0,'instances':entries,'exclusion_manifest_sha256':sha((ROOT/'exclusions.json').read_bytes())};put(ROOT/'data_manifest.json',manifest)
packs=[]
for i,e in enumerate(entries):
 order=METHODS[i%3:]+METHODS[:i%3]
 for m in order:packs.append(dict(e,action_id=f'A2_{i:02d}_{m}',method=m,code_sha256=methods[m]['code_sha256']))
put(ROOT/'data_seal.json',{'schema':'A2-all18-input-source-binding-v1','source_freeze_sha256':fh,'data_manifest_sha256':sha((ROOT/'data_manifest.json').read_bytes()),'packs':packs,'science_enabled':False,'seal_before_any_scientific_pack':True})
put(ROOT/'generation_completion.json',{'status':'sealed','instances':6,'packs':18,'wall_at_emit':time.monotonic()-started,'self_CPU_at_emit':time.process_time(),'private_entropy_disclosed':False,'CPU_OS_limit':5,'wall_OS_alarm':8,'cost_within_static_data_reservation':True})
print('Sealed6 new sequences,18 immutable packs; scientific execution disabled.',flush=True)
