"""Only the audited terminal validator; obsolete tree-CPU polling is omitted."""
def valid_new_terminal(claim, terminal):
    import hashlib, json
    expected = hashlib.sha256(json.dumps(claim, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode()).hexdigest()
    r = terminal.get('resources', {})
    return terminal.get('claim_sha256') == expected and terminal.get('status') == 'passed' and r.get('driver_reaped') is True and r.get('driver_exit_code') == 0
