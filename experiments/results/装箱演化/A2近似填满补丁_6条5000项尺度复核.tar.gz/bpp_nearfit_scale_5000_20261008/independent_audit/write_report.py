"""Write review report from already checked read-only evidence; no study source import."""
import hashlib,json,re,resource,signal
from pathlib import Path
from datetime import datetime,timezone
resource.setrlimit(resource.RLIMIT_CPU,(3,3));signal.alarm(3)
a=Path('/workspace/shared/audit_bpp_nearfit_scale_20261008');r=Path('/workspace/shared/bpp_nearfit_scale_5000_20261008');other=Path('/workspace/shared/audit_bpp_nearfit_scale_5000_20261008')
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def receipt(p):return {k:float(v) for k,v in re.findall(r'([A-Za-z_]+)=([0-9.]+)',p.read_text())}
e=read(a/'FROZEN_EVIDENCE_CHECK.json');p=read(r/'policy.json')
report={
 'schema':'A2-independent-preactivation-review-v1',
 'status':'PASS_A2_NOT_ACTIVATED',
 'reviewed_at_utc':datetime.now(timezone.utc).isoformat(),
 **{k:e[k] for k in ('source_freeze_sha256','data_seal_sha256','data_manifest_sha256','policy_sha256','analysis_source_sha256','methods_sha256','ordered_scientific_actions_sha256')},
 'evidence_check_sha256':h(a/'FROZEN_EVIDENCE_CHECK.json'),
 'evidence_check_source_sha256':h(a/'check_frozen_evidence.py'),
 'baseline_A1_preflight_audit_sha256':h(Path('/workspace/shared/bpp_nearfit_ablation_20261008/independent_audit/A1_INDEPENDENT_PASS.json')),
 'baseline_A1_result_audit_sha256':h(Path('/workspace/shared/bpp_nearfit_ablation_20261008/independent_audit/A1_RESULT_REVIEW.json')),
 'review_state':{'scientific_packs_started':0,'scientific_authorization_present':False,'new_root_activation_required':True,'candidate_execution_by_auditor':False,'solver_execution_by_auditor':False,'analysis_execution_by_auditor':False,'study_frozen_files_modified_by_auditor':False,'old_A1_C1_files_modified':False,'new_provider_calls':0},
 'scope':{'study':'six-sequence small-sample scale check after A1 mechanism screen','independent_sequences':6,'items_per_sequence':5000,'capacity':100,'methods':['EOH_original','EOH_nearfit_one','published_EoH'],'scientific_packs':18,'toy_packs':3,'analysis_actions':1,'standalone_admission_probes':0,'candidate_patch_sha256':'6bff5a3b26ab13b6ae688cdccca88d647168dd9297d0184b605a5ae3bba39546','coefficient':0.5,'tuning_allowed':False,'primary':'EOH_nearfit_one_minus_EOH_original','published_comparator':'secondary descriptive only'},
 'passed_checks':e['checks']+[
 'Manual six-file code diff review: only A2 namespaces,5000 input length, six-sequence/eighteen-pack scope and corresponding analysis/output labels change. No candidate, sandbox, host checker or blocking collector change.',
 'Static preparation seals method registry, generator, analysis, policy, exclusion metadata and runtime before fresh data generation. Fresh once-only32byte entropy uses A2 HMAC domain; the generator contains no difficulty/performance read, retry, filtering or replacement path. Known prior sources used only as hash metadata.',
 'Auditor reproduced only the six data arrays in memory using the sealed rule. This did not execute any heuristic, solver, study generator, candidate admission, toy or scientific analysis. Seed bytes and item values were not emitted into the report or tool output.',
 'Inherited guard topology and kernel limits: guard hard1CPU, driver effective soft2CPU with inherited hard200 to allow original supervisor/worker hard60; per-pack93wall. Original reviewed125CPU reservation remains. Outer raw wait4 subtree accounting counts child CPU once and does not add nested receipts again.',
 'Scientific dispatch is fixed18 actions then one analysis; exact audit PASS, freeze SHA, data seal SHA and parent authorization hash all gate activation. One-shot exclusive claims, permanent stage claims and HALT/unknown/failed claim gates prevent silent retry or scope expansion.',
 'Guard creates immutable raw_terminal_freeze before starting analysis; analysis checks each saved result against the raw seal and claim plus source/input/method/sequence identities. Missing records remain null, with six fixed denominator slots per method and full6 contrast null unless all six pairs complete.',
 'Analysis uses F=ceil(sum(items)/100)/used_bins, exact Fraction per-sequence differences and exact Fraction mean over six. Frozen PCG64(20261008) paired bootstrap uses20000 six-sequence samples, identical indices for primary and secondary, linear95% percentile intervals and descriptive-only labeling.',
 'All six paired bin differences, total bin savings, wins/ties/losses, completion/failure states and prespecified saved-assignment mechanism proxies are reported. These proxies alone cannot establish efficiency benefit.',
 'No p-value, confirmatory superiority, generalization guarantee, SOTA claim, adaptive sample extension or coefficient tuning is permitted. PASS authorizes no execution by itself.'
 ],
 'toy_receipts':e['toy_receipts'],
 'budget':{
  'caps':p['resource_accounting']['caps'],
  'reservations':p['resource_accounting']['reservations'],
  'reserved_total':p['resource_accounting']['reserved_total'],
  'margin':p['resource_accounting']['unallocated_margin'],
  'old_A1_C1_budget_used':False,
  'auditor_shared_reservation':e['audit_shared_reservation'],
  'main_auditor_complete_check_shell_receipt':receipt(a/'check_time_receipt.txt'),
  'stopped_parallel_auditor_receipts':{n:receipt(other/n) for n in ('prior_read_time_receipt.txt','prior_setup_read_time_receipt.txt','priority_read_time_receipt.txt')},
  'author_preparation_complete_shell_receipts':{n:receipt(r/n) for n in ('setup_time_receipt.txt','prepare_time_receipt.txt','generation_time_receipt.txt')},
  'actual_toy_outer_wait4_CPU_seconds':sum(t['outer_wait4_CPU_seconds'] for t in e['toy_receipts']),
  'cost_semantics':'Reservations are conservative bounds, not measured all-in runtime. Both independent auditors share one30CPU/30active-wall A2 reservation. Initial short read/report tool commands and four stopped-auditor reads were not individually fully CPU-metered and are not asserted zero. Main bounded check and three stopped-auditor reads have complete shell receipts. Reasoning/idle review time is not active process wall. Author prepare shell CPU already includes toys; do not add nested toy CPU again.'
 },
 'limitations':[
  'Six new5000-item sequences are a small-sample descriptive scale check. They cannot establish general superiority or full SOTA; public formula is secondary.',
  'Known exact equality exclusion covers25 public/C1 full5000 hashes and33 public/C1/A1 thousand-item prefixes. Unavailable historical datasets are not exhaustively excluded; no deliberate old-data reuse is supported by the fixed new-entropy protocol.',
  'Toy PASS verifies the unchanged entrypoint, admission, checker contract and cleanup; it does not demonstrate scientific benefit or guarantee every5000-item pack finishes within resource caps.',
  'Analysis control flow and null handling were reviewed statically, not executed by auditor. Any later frozen-source or data-seal change invalidates this review.',
  'A failed or unknown scientific pack may halt before automatic analysis. Preserve its failure state and missing/null denominator semantics; do not substitute a zero or silently rerun. Any recovery requires separately reviewed authority and budget.'
 ],
 'activation_contract':{
  'destination':str(r/'independent_review.json'),'copy_this_report_byte_for_byte':True,
  'authorization_file':str(r/'authorization.json'),
  'required_fields':{'enabled':True,'source_freeze_sha256':e['source_freeze_sha256'],'data_seal_sha256':e['data_seal_sha256'],'independent_review_sha256':'SHA256 of this exact report, supplied by root only after approving it'},
  'science_entrypoint':'python -B dispatch.py science','root_enable_still_required':True
 }
}
assert h(r/'source_freeze.json')==e['source_freeze_sha256'] and h(r/'data_seal.json')==e['data_seal_sha256']
assert not (r/'authorization.json').exists() and not (r/'science_dispatch_claim.json').exists()
out=a/'A2_INDEPENDENT_PASS.json'
with out.open('x') as f:json.dump(report,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({'status':report['status'],'report':str(out),'report_sha256':h(out),**{k:e[k] for k in ('source_freeze_sha256','data_manifest_sha256','data_seal_sha256')}},ensure_ascii=False))
