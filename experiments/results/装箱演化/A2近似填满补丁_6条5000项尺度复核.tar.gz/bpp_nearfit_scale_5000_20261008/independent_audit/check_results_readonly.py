"""Independent saved-output audit. No import of candidate/runner/analysis code."""
import hashlib,json,resource,signal,time,re
from fractions import Fraction
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CPU,(10,10));signal.alarm(10)
start=time.monotonic();r=Path('/workspace/shared/bpp_nearfit_scale_5000_20261008');a=Path('/workspace/shared/audit_bpp_nearfit_scale_20261008')
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
def dig(v):return hashlib.sha256(canon(v).encode()).hexdigest()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def need(x,t):
 if not x:raise RuntimeError(t)
def exact(x):return {'numerator':x.numerator,'denominator':x.denominator,'decimal':float(x)}
pre=read(a/'A2_INDEPENDENT_PASS.json');fh=sha(r/'source_freeze.json');ds=read(r/'data_seal.json');sealhash=sha(r/'data_seal.json');out=read(r/'analysis_result.json');policy=read(r/'policy.json');auth=read(r/'authorization.json')
need(fh==pre['source_freeze_sha256']==auth['source_freeze_sha256'],'same frozen source')
need(sealhash==pre['data_seal_sha256']==auth['data_seal_sha256']==out['data_seal_sha256'],'same sealed data')
need(auth['enabled'] is True and auth['independent_review_sha256']==sha(a/'A2_INDEPENDENT_PASS.json')==sha(r/'independent_review.json'),'root activation binding')
for n,h in read(r/'source_freeze.json')['files'].items():need(sha(r/n)==h,'source changed '+n)
need(sha(r/'analysis.py')==pre['analysis_source_sha256']==out['analysis_source_sha256'],'analysis unchanged')
ids=policy['scientific_actions'];toyids=policy['toy_actions'];all_ids=toyids+ids+['analysis'];raw=read(r/'raw_terminal_freeze.json')
need(set(raw)=={x+'.json' for x in toyids+ids},'raw exact21 before analysis')
for n,h in raw.items():need(sha(r/'results'/n)==h,'raw terminal changed '+n)
for folder in ('claims','results','observations'):need({p.stem for p in (r/folder).glob('*.json')}==set(all_ids),'exact22 '+folder)
need(not (r/'HALT.json').exists(),'no HALT')
need([x['action_id'] for x in ds['packs']]==ids and len(ds['packs'])==18,'scope')
methods=('EOH_original','EOH_nearfit_one','published_EoH');m=read(r/'methods.json')['methods'];rows={(v['sequence_index'],v['method']):v for v in out['records']}
need(len(rows)==18,'analysis record uniqueness')
instance_data={};resource_rows=[];verified=[];F={};Bins={};proxy_totals={x:{k:0 for k in ['r1_placements','final_r1_bins','final_capacity_r11_45','full_bins','voluntary_openings','forced_openings']} for x in methods};seen_execution=set();new_data_hashes=set()
for x in ds['packs']:
 aid=x['action_id'];i=x['sequence_index'];method=x['method'];c=read(r/'claims'/(aid+'.json'));t=read(r/'results'/(aid+'.json'));o=read(r/'observations'/(aid+'.json'));y=t['payload'];report=y['original_pack_report'];w=report['worker'];s=report['supervisor_evidence']
 need(c['action_id']==aid and c['stage']=='science' and c['source_freeze_sha256']==fh and c['data_seal_sha256']==sealhash and c['no_retry'] is True,'claim')
 need(c['reserve_CPU_seconds']==125 and c['reserve_wall_seconds']==93,'pack reservation')
 need(t['action_id']==aid and t['claim_sha256']==dig(c) and t['status']=='passed','terminal')
 need(y['method']==method and y['sequence_index']==i and y['code_sha256']==x['code_sha256']==m[method]['code_sha256'] and y['input_sha256']==x['input_sha256'],'exact identity')
 need(y['n']==5000 and y['capacity']==100 and y['fixture_only'] is False and y['outcome']=='ok' and y['checker']['checker_status']=='passed','5000-item success')
 rawinput=(r/x['relative_file']).read_bytes();data=json.loads(rawinput);items=data['items']
 need(sha(r/x['relative_file'])==x['file_sha256'] and dig(data)==x['input_sha256'] and dig(items)==x['items_sha256'],'input hash')
 need(len(items)==5000 and data['capacity']==100 and all(type(v) is int and 1<=v<=100 for v in items),'input domain')
 if i in instance_data:need(instance_data[i]==items,'same sequence across arms')
 else:instance_data[i]=items;new_data_hashes.add(x['items_sha256'])
 bind=report['binding'];eid=dig(['A2-source-claim',aid])+'/instance/0'
 need(bind['source_sha256']==x['code_sha256'] and bind['claim_id']==dig(['A2-source-claim',aid]),'runtime binding')
 need(report['execution_id']==w['execution_id']==s['execution_id']==eid and report['instance_index']==w['instance_index']==s['instance_index']==0,'execution ABI')
 need(eid not in seen_execution,'unique worker claim');seen_execution.add(eid)
 need(w['steps']==5000 and w['assignment_complete'] is True and w['source_sent'] is True and w['source_after_host_gate'] is True,'full worker scope')
 need(w['admission']['admitted'] is True and w['admission']['source_sha256']==x['code_sha256'],'exact admitted source')
 toy=read(r/'results'/('toy_'+method+'.json'))['payload']['original_pack_report']['worker']['admission']
 need(w['admission']['canonical_text']==toy['canonical_text'],'same toy AST')
 need(w['reaped'] is True and s['reaped'] is True and w['cleanup_error'] is None and s['cleanup_error'] is None,'worker supervisor reaped')
 need(w['returncode']==0 and s['returncode']==0 and w['host_observed_limits']['cpu_seconds']==[60,60],'successful capped workers')
 need(t['resources']['driver_reaped'] is True and t['resources']['driver_exit_code']==0 and t['resources']['conservative_complete_tree_CPU_upper_seconds']<=125,'driver receipt')
 need(o['unreaped_descendants_remaining'] is False and all(e['exit_code']==0 for e in o['raw_wait4_events']),'complete outer tree')
 cpu=sum(e['utime']+e['stime'] for e in o['raw_wait4_events']);need(abs(cpu-o['inclusive_CPU_counted_once'])<1e-9 and cpu>=t['resources']['driver_wait4_inclusive_CPU_seconds'],'once-count inclusive')
 result=report['result'];assignment=result['assignment'];need(len(assignment)==5000,'assignment length');remaining=[100]*5000;opened=set();r1=0;forced=0;voluntary=0;residual_hist=[0]*101
 for item,b in zip(items,assignment):
  need(type(b) is int and 0<=b<5000 and remaining[b]>=item,'assignment feasibility')
  if b not in opened:
   need(b==len(opened),'stable original-index new bin')
   if sum(residual_hist[item:100]):voluntary+=1
   else:forced+=1
   opened.add(b)
  if remaining[b]!=100:residual_hist[remaining[b]]-=1
  remaining[b]-=item;residual_hist[remaining[b]]+=1;r1+=int(remaining[b]==1)
 bins=len(opened);lb=(sum(items)+99)//100
 need(remaining==result['remaining'] and sum(100-v for v in remaining)==sum(items),'conservation and remainders')
 need(bins==result['used_bins']==y['checker']['used_bins'] and dig(assignment)==y['checker']['assignment_sha256'] and lb==y['L1'],'independent count and assignment hash')
 f=Fraction(lb,bins);F[i,method]=f;Bins[i,method]=bins
 proxies={'r1_placements':r1,'final_r1_bins':sum(remaining[j]==1 for j in opened),'final_capacity_r11_45':sum(remaining[j] for j in opened if 11<=remaining[j]<=45),'full_bins':sum(remaining[j]==0 for j in opened),'voluntary_openings':voluntary,'forced_openings':forced}
 row=rows[i,method];need(row['status']=='ok' and row['F']==exact(f) and row['L1']==lb and row['used_bins']==bins and row['mechanism']==proxies,'independent analysis row/proxy')
 for k,v in proxies.items():proxy_totals[method][k]+=v
 resource_rows.append({'action_id':aid,'outer_wait4_CPU_seconds':cpu,'guard_wall_at_emit':t['resources']['wall_at_emit'],'claim_sha256':dig(c),'terminal_sha256':sha(r/'results'/(aid+'.json'))})
 verified.append({'sequence_index':i,'method':method,'used_bins':bins,'L1':lb,'F':exact(f),'mechanism':proxies})
need(len(instance_data)==len(new_data_hashes)==6,'six independent sequences')
need(not new_data_hashes & set(read(r/'exclusions.json')['prior_5000_items_sha256']),'no old data mix')
import numpy as np
idx=np.random.Generator(np.random.PCG64(20261008)).integers(0,6,size=(20000,6));contrasts={}
for other in ('EOH_original','published_EoH'):
 diffs=[F[i,'EOH_nearfit_one']-F[i,other] for i in range(6)];bins=[Bins[i,'EOH_nearfit_one']-Bins[i,other] for i in range(6)]
 # Independent column accumulation avoids importing the production analysis.
 d=np.array([float(x) for x in diffs],dtype=np.float64);samples=d[idx].mean(axis=1);interval=np.percentile(samples,[2.5,97.5],method='linear').tolist()
 expect={'mean_paired_F_difference':exact(sum(diffs,Fraction())/6),'paired_F_differences':[exact(x) for x in diffs],'paired_bins_patch_minus_comparator':bins,'total_bin_savings':-sum(bins),'wins_ties_losses':[sum(x>0 for x in diffs),sum(x==0 for x in diffs),sum(x<0 for x in diffs)],'descriptive_95_percentile_bootstrap':interval,'resamples':20000,'analysis_seed':20261008,'bootstrap_only_descriptive':True}
 actual=out['contrasts']['EOH_nearfit_one_minus_'+other]
 need(actual['complete_pairs']==actual['denominator']==6 and actual['full6_result']==expect,'contrast exact reproduction '+other)
 contrasts['EOH_nearfit_one_minus_'+other]=expect
need(out['primary_full6_null_unless_all6_complete'] is True and out['missing_imputation'] is None and out['p_value'] is None and out['confirmatory_superiority_claim'] is False and out['5000_item_scale_check'] is True and out['small_sample_descriptive_only'] is True and out['generalization_guarantee'] is False,'claim limits')
for method in methods:need(out['coverage'][method]=={'complete':6,'denominator':6,'failures':[]},'coverage')
ac=read(r/'claims/analysis.json');at=read(r/'results/analysis.json');ao=read(r/'observations/analysis.json');dc=read(r/'science_dispatch_completion.json')
need(ac['raw_terminal_freeze_sha256']==sha(r/'raw_terminal_freeze.json') and ac['source_freeze_sha256']==fh and ac['data_seal_sha256']==sealhash,'raw before analysis claim binding')
need(at['claim_sha256']==dig(ac) and at['status']=='passed' and at['payload']['analysis_sha256']==sha(r/'analysis_result.json') and at['payload']['candidate_execution'] is False,'analysis terminal')
need(at['resources']['driver_reaped'] is True and at['resources']['driver_exit_code']==0 and ao['unreaped_descendants_remaining'] is False and all(e['exit_code']==0 for e in ao['raw_wait4_events']),'analysis full cleanup')
need(dc['status']=='complete' and dc['actions']==ids+['analysis'] and dc['no_retries'] is True,'science completed exact scope')
science_cpu=sum(x['outer_wait4_CPU_seconds'] for x in resource_rows)+ao['inclusive_CPU_counted_once'];need(abs(science_cpu-dc['inclusive_children_CPU_once'])<1e-8,'science CPU once')
receipts={name:{k:float(v) for k,v in re.findall(r'([A-Za-z_]+)=([0-9.]+)',(r/name).read_text())} for name in ('setup_time_receipt.txt','prepare_time_receipt.txt','generation_time_receipt.txt','science_time_receipt.txt')}
need(receipts['science_time_receipt.txt']['wall_seconds']>=dc['wall_at_emit'] and receipts['science_time_receipt.txt']['user_CPU_seconds']+receipts['science_time_receipt.txt']['system_CPU_seconds']>=science_cpu,'full exit receipt')
for folder in ('claims','results','observations'):need(len(list((r/folder).glob('*.json')))==22,'no extra/retry claims')
reserved_pack_CPU=sum(read(p)['reserve_CPU_seconds'] for p in (r/'claims').glob('*.json'));reserved_pack_wall=sum(read(p)['reserve_wall_seconds'] for p in (r/'claims').glob('*.json'))
need(reserved_pack_CPU+20+4+18+30==2727 and reserved_pack_wall+20+10+50+30==2123,'cumulative permanent budget')
summary={'schema':'A2-independent-result-check-v1','status':'PASS_A2_RESULTS','source_freeze_sha256':fh,'data_seal_sha256':sealhash,'analysis_result_sha256':sha(r/'analysis_result.json'),'raw_terminal_freeze_sha256':sha(r/'raw_terminal_freeze.json'),'science_completion_sha256':sha(r/'science_dispatch_completion.json'),'source_unchanged':True,'scientific_packs':18,'sequences':6,'assignments_replayed':90000,'claims_including_toy_and_analysis':22,'unknown':0,'failures':0,'retries':0,'candidate_execution':False,'solver_execution':False,'study_analysis_source_executed':False,'all_saved_results_and_metrics_independently_reproduced':True,'host_load_disclosure':auth.get('host_load_disclosure'),'no_exclusive_host_or_runtime_performance_claim':True,'raw_sealed_before_analysis_claim':True,'method_totals':{m:{'bins':sum(Bins[i,m] for i in range(6)),'mean_F':exact(sum((F[i,m] for i in range(6)),Fraction())/6),'mechanism_totals':proxy_totals[m]} for m in methods},'contrasts':contrasts,'verified_records':verified,'resource_rows':resource_rows,'full_exit_receipts':receipts,'science_guard_tree_CPU_once':science_cpu,'measured_execution_receipts_CPU':sum(v['user_CPU_seconds']+v['system_CPU_seconds'] for v in receipts.values()),'measured_execution_receipts_wall':sum(v['wall_seconds'] for v in receipts.values()),'cost_limit_note':'Measured core execution totals exclude individually unmetered short author/auditor control-plane commands; those retain conservative named reservations, not zero. All reservations remain2727CPU/2123activewall within2800/2200. Audit uses original30/30 only.','audit_validation_CPU_at_emit':time.process_time(),'audit_validation_wall_at_emit':time.monotonic()-start,'OS_CPU_limit':10,'OS_wall_alarm':10}
(a/'RESULT_EVIDENCE_CHECK.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:summary[k] for k in ['status','analysis_result_sha256','assignments_replayed','unknown','failures','retries','method_totals','measured_execution_receipts_CPU','measured_execution_receipts_wall','audit_validation_CPU_at_emit','audit_validation_wall_at_emit']},ensure_ascii=False))
