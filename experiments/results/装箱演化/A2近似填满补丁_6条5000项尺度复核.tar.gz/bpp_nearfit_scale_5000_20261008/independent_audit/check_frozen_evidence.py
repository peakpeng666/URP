"""Minimal read-only A2 evidence check; imports no study module and executes no candidate."""
import hashlib,hmac,json,resource,signal,time,difflib
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CPU,(10,10));signal.alarm(10)
r=Path('/workspace/shared/bpp_nearfit_scale_5000_20261008')
a=Path('/workspace/shared/audit_bpp_nearfit_scale_20261008')
a1=Path('/workspace/shared/bpp_nearfit_ablation_20261008')
c1=Path('/workspace/shared/prospective_confirmation_C1_preparation_20261007')
t0=time.monotonic()
def sha(b):return hashlib.sha256(b).hexdigest()
def h(p):return sha(p.read_bytes())
def canon(d):return json.dumps(d,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
def dig(d):return sha(canon(d).encode())
def read(p):return json.loads(p.read_text())
def need(x,msg):
 if not x:raise RuntimeError(msg)
checks=[]
f=read(r/'source_freeze.json');fh=h(r/'source_freeze.json')
for n,x in f['files'].items():need(h(r/n)==x,'source drift '+n)
for n in ('methods.json','toy.json','guard_collect.py','guard_collect_blocking.py'):
 need((r/n).read_bytes()==(a1/n).read_bytes(),'A1 byte inheritance '+n)
rt=[n for n in f['files'] if n.startswith('frozen_runtime/')]
for n in rt:need((r/n).read_bytes()==(a1/n).read_bytes(),'A1 runtime bytes '+n)
wf=read(r/'frozen_runtime/worker_freeze.json')
for n,x in wf['files'].items():need(h(r/'frozen_runtime'/n)==x,'worker freeze '+n)
delta=read(r/'source_delta.json')
for n,d in delta['diffs'].items():
 need(d==''.join(difflib.unified_diff((a1/n).read_text().splitlines(True),(r/n).read_text().splitlines(True),fromfile='A1/'+n,tofile='A2/'+n)),'recorded delta '+n)
need(delta['baseline_source_freeze_sha256']==h(a1/'source_freeze.json'),'A1 freeze provenance')
checks.append(f'{len(f["files"])} A2 frozen files verified; all {len(rt)} runtime files, three method registry, toy fixture and both collectors byte-identical to A1. Recorded six-file delta matches.')
methods=('EOH_original','EOH_nearfit_one','published_EoH');m=read(r/'methods.json')['methods']
for name in methods:
 v=m[name];need(sha(v['code'].encode())==v['code_sha256'] and sha(v['description'].encode())==v['description_sha256'],'method source/description');need(dig({'description':v['description'],'code':v['code']})==v['pair_sha256'],'method pair')
old_return='return np.where(bins == item, s + 1.0, s)'
new_return='return np.where(bins == item, s + 1.0, np.where(bins - item == 1, s + 0.5, s))'
need(m['EOH_nearfit_one']['code']==m['EOH_original']['code'].replace(old_return,new_return),'exact r1-only patch')
need(m['EOH_nearfit_one']['code_sha256']=='6bff5a3b26ab13b6ae688cdccca88d647168dd9297d0184b605a5ae3bba39546','fixed patch')
p=read(r/'policy.json');b=p['resource_accounting'];res=b['reservations']
need(b['caps']=={'CPU':2800,'active_wall':2200},'budget cap')
need(sum(v['CPU'] for v in res.values())==2727 and sum(v['wall'] for v in res.values())==2123,'budget sum')
need(res['independent_audit']=={'CPU':30,'wall':30} and res['science18']=={'CPU':2250,'wall':1674},'science and shared audit reserve')
need(p['fixed_patch']['coefficient']==0.5 and p['fixed_patch']['tuning_allowed'] is False,'fixed coefficient')
expected=[f'A2_{i:02d}_{name}' for i in range(6) for name in methods[i%3:]+methods[:i%3]]
need(p['scientific_actions']==expected and len(set(expected))==18,'finite action scope')
need(p['toy_actions']==['toy_'+n for n in methods] and p['primary']['denominator']==6,'toy/denominator')
checks.append('Unchanged r1-only coefficient0.5, six independent5000-item cap100 sequences,18 unique rotated actions, each method first/second/third twice; budget2727CPU/2123wall below2800/2200 with shared audit30/30.')
toy_receipts=[];toy_data=read(r/'toy.json')
for name in methods:
 aid='toy_'+name;c=read(r/'claims'/(aid+'.json'));t=read(r/'results'/(aid+'.json'));y=t['payload'];rep=y['original_pack_report'];w=rep['worker'];s=rep['supervisor_evidence'];o=read(r/'observations'/(aid+'.json'))
 need(c['source_freeze_sha256']==fh and c['reserve_CPU_seconds']==125 and c['reserve_wall_seconds']==93,'toy claim')
 need(t['status']=='passed' and t['claim_sha256']==dig(c),'toy claim terminal')
 need(y['method']==name and y['code_sha256']==m[name]['code_sha256'] and y['input_sha256']==dig(toy_data),'toy exact bindings')
 need(y['outcome']=='ok' and y['checker']['checker_status']=='passed','real checker contract')
 need(w['source_sent'] is True and w['source_after_host_gate'] is True,'host gate precedes source')
 need(w['admission']['admitted'] is True and type(w['admission']['canonical_text']) is str and w['admission']['source_sha256']==m[name]['code_sha256'],'real admitted canonical_text')
 bind=rep['binding'];cid=dig(['A2-source-claim',aid]);need(bind['claim_id']==cid and bind['claim_sha256']==dig(['A2-typed-source-claim',cid]) and bind['batch_id']=='A2-nearfit-20261008' and bind['wave_id']==aid and bind['slot_id']==name,'A2 typed binding')
 need(bind['registry_sha256']==dig(read(r/'methods.json')) and bind['source_sha256']==m[name]['code_sha256'],'registry/source binding')
 need(w['execution_id']==cid+'/instance/0' and w['instance_index']==0,'execution ABI')
 need(w['reaped'] and s['reaped'] and w['cleanup_error'] is None and s['cleanup_error'] is None,'nested cleanup')
 need(w['host_observed_limits']['cpu_seconds']==[60,60] and w['host_observed_limits']['address_space_bytes']==[536870912,536870912],'worker OS limits')
 need(t['resources']['driver_reaped'] and t['resources']['driver_exit_code']==0,'driver reaped')
 need(o['unreaped_descendants_remaining'] is False and all(e['exit_code']==0 for e in o['raw_wait4_events']),'complete outer reap')
 need(abs(o['inclusive_CPU_counted_once']-sum(e['utime']+e['stime'] for e in o['raw_wait4_events']))<1e-8 and o['inclusive_CPU_counted_once']>=t['resources']['driver_wait4_inclusive_CPU_seconds'],'single inclusive wait4 meter')
 toy_receipts.append({'action_id':aid,'canonical_sha256':sha(w['admission']['canonical_text'].encode()),'terminal_sha256':h(r/'results'/(aid+'.json')),'observation_sha256':h(r/'observations'/(aid+'.json')),'outer_wait4_CPU_seconds':o['inclusive_CPU_counted_once']})
need(read(r/'prepare_dispatch_completion.json')['actions']==p['toy_actions'],'prepare complete')
need(set(x.stem for x in (r/'claims').glob('*.json'))==set(p['toy_actions']),'exactly3 toy claims, no science')
checks.append('Three actual A2 toys use the scientific driver/supervised_pack path; admitted canonical_text, checker_status=passed, exact A2 claim/instance/0 ABI, source-after-host-gate and full nested/outer reaping verified. No new probe or candidate execution by auditor.')
ex=read(r/'exclusions.json')
origins={'A1_DATA_MANIFEST.json':a1/'data_manifest.json','A1_EXCLUSIONS.json':a1/'exclusions.json','C1_DATA_MANIFEST.json':c1/'DATA_MANIFEST.json','PUBLIC_EXCLUSION_MANIFEST.json':c1/'PUBLIC_EXCLUSION_MANIFEST.json'}
for n,orig in origins.items():need(h(r/'source_evidence'/n)==h(orig)==ex['source_manifest_sha256'][n],'exclusion metadata provenance')
oldex=read(r/'source_evidence/A1_EXCLUSIONS.json');a1dm=read(r/'source_evidence/A1_DATA_MANIFEST.json');c1dm=read(r/'source_evidence/C1_DATA_MANIFEST.json');public=read(r/'source_evidence/PUBLIC_EXCLUSION_MANIFEST.json')
prefixes=set(oldex['prior_1000_prefix_sha256'])|{e['items_sha256'] for e in a1dm['instances']}
fulls={e['items_sha256'] for e in public['entries'] if e['n']==5000}|{e['items_sha256'] for e in c1dm['instances']}
need(len(prefixes)==33 and prefixes==set(ex['prior_1000_prefix_sha256']) and len(fulls)==25 and fulls==set(ex['prior_5000_items_sha256']),'known equality exclusion coverage')
dm=read(r/'data_manifest.json');ds=read(r/'data_seal.json');ph=h(r/'policy.json')
need(dm['source_freeze_sha256']==ds['source_freeze_sha256']==fh,'data source freeze')
need(dm['policy_sha256']==ph and dm['generator_source_sha256']==h(r/'generate.py') and dm['exclusion_manifest_sha256']==h(r/'exclusions.json'),'generation inputs fixed')
need(dm['entropy_draws']==dm['generation_attempts']==1 and dm['quality_filtering'] is False and dm['candidate_evaluations_before_seal']==0,'once-only no quality filter')
need(len(dm['instances'])==6 and len(ds['packs'])==18 and ds['science_enabled'] is False and ds['data_manifest_sha256']==h(r/'data_manifest.json'),'sealed scope')
import numpy as np
need(np.__version__==dm['numpy']=='2.3.5','numpy generator identity')
master=(r/'custody/master.bin').read_bytes();need(len(master)==32 and read(r/'custody/master_commitment.json')['sha256']==sha(b'A2-nearfit-master-v1|'+master),'private entropy commitment')
seen=set()
for i,e in enumerate(dm['instances']):
 raw=(r/e['relative_file']).read_bytes();v=json.loads(raw)
 need(e['sequence_index']==i and e['n']==5000 and e['capacity']==100 and set(v)=={'items','capacity'},'sequence schema')
 need(v['capacity']==100 and len(v['items'])==5000 and all(type(j) is int and 1<=j<=100 for j in v['items']),'sequence domain')
 need(raw==(canon(v)+'\n').encode() and sha(raw)==e['file_sha256'] and dig(v)==e['input_sha256'] and dig(v['items'])==e['items_sha256'],'canonical input hashes')
 need(e['items_sha256'] not in seen|fulls and dig(v['items'][:1000]) not in prefixes,'new disjoint sequence')
 seen.add(e['items_sha256'])
 msg=('A2-nearfit-instance-v1|'+ph+'|'+f'{i:02d}').encode();seed=int.from_bytes(hmac.new(master,msg,hashlib.sha256).digest()[:16],'big')
 rng=np.random.Generator(np.random.PCG64(seed));reproduced=np.round(np.clip(45*rng.weibull(3,size=5000),1,100)).astype(np.int64).tolist()
 need(reproduced==v['items'],'fixed HMAC/PCG64 source reproduction')
for j,row in enumerate(ds['packs']):
 i=j//3;name=(methods[i%3:]+methods[:i%3])[j%3]
 need(row==dict(dm['instances'][i],action_id=expected[j],method=name,code_sha256=m[name]['code_sha256']),'exact input/source/action pack')
need(read(r/'custody/generation_claim.json')['source_freeze_sha256']==fh and read(r/'generation_completion.json')['status']=='sealed','generation bound complete')
need(not (r/'authorization.json').exists() and not (r/'science_dispatch_claim.json').exists() and not (r/'HALT.json').exists(),'unactivated and no HALT')
checks.append('Six complete inputs independently reproduced in memory from fixed HMAC/PCG64 rule; all file/input/items hashes and18 exact rotated bindings verified. Full5000 and1000-prefix equality exclusions match25/33 known hashes. No old arrays/scores or new quality statistics read/exported; private entropy never exported.')
summary={'schema':'A2-minimal-readonly-evidence-check-v1','status':'PASS_EVIDENCE_NOT_ACTIVATED','source_freeze_sha256':fh,'data_seal_sha256':h(r/'data_seal.json'),'data_manifest_sha256':h(r/'data_manifest.json'),'policy_sha256':ph,'analysis_source_sha256':h(r/'analysis.py'),'methods_sha256':h(r/'methods.json'),'ordered_scientific_actions_sha256':dig(expected),'checks':checks,'toy_receipts':toy_receipts,'local_frozen_file_count':len(f['files']),'original_runtime_frozen_file_count':len(wf['files']),'all_runtime_file_count':len(rt),'candidate_execution':False,'solver_execution':False,'analysis_source_execution':False,'real_research_scores_read':False,'private_entropy_read_locally_for_reproduction':True,'private_entropy_exported':False,'old_research_arrays_or_scores_read':False,'script_CPU_at_emit':time.process_time(),'script_wall_at_emit':time.monotonic()-t0,'script_OS_CPU_limit':10,'script_OS_wall_alarm':10,'audit_shared_reservation':{'CPU':30,'active_wall':30,'debit':'new A2 only','includes':'This read-only review and stopped parallel auditor; initial short shell reads not individually CPU-metered and not asserted zero.'}}
(a/'FROZEN_EVIDENCE_CHECK.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:summary[k] for k in ('status','source_freeze_sha256','data_seal_sha256','data_manifest_sha256','local_frozen_file_count','script_CPU_at_emit','script_wall_at_emit')}))
