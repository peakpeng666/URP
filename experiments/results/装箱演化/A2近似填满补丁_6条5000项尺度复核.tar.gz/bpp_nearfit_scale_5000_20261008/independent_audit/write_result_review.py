"""Complete result review from independently replayed saved outputs."""
import hashlib,json,resource,signal,re
from pathlib import Path
from datetime import datetime,timezone
resource.setrlimit(resource.RLIMIT_CPU,(3,3));signal.alarm(3)
a=Path('/workspace/shared/audit_bpp_nearfit_scale_20261008');r=Path('/workspace/shared/bpp_nearfit_scale_5000_20261008')
def read(p):return json.loads(p.read_text())
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rec(p):return {k:float(v) for k,v in re.findall(r'([A-Za-z_]+)=([0-9.]+)',p.read_text())}
e=read(a/'RESULT_EVIDENCE_CHECK.json');pre=read(a/'A2_INDEPENDENT_PASS.json');seal=read(r/'data_seal.json');auth=read(r/'authorization.json')
assert h(r/'data_manifest.json')==seal['data_manifest_sha256']==pre['data_manifest_sha256']==auth['data_manifest_sha256']
assert e['analysis_result_sha256']==h(r/'analysis_result.json') and e['raw_terminal_freeze_sha256']==h(r/'raw_terminal_freeze.json')
assert all(x['guard_wall_at_emit']<93 and x['outer_wait4_CPU_seconds']<125 for x in e['resource_rows'])
analysis_obs=read(r/'observations/analysis.json');events=analysis_obs['raw_wait4_events']
assert abs(analysis_obs['inclusive_CPU_counted_once']-sum(x['utime']+x['stime'] for x in events))<1e-9
assert read(r/'results/analysis.json')['resources']['wall_at_emit']<60
report={
 'schema':'A2-independent-result-review-v1','status':'PASS_A2_RESULTS','reviewed_at_utc':datetime.now(timezone.utc).isoformat(),
 **{k:e[k] for k in ('source_freeze_sha256','data_seal_sha256','analysis_result_sha256','raw_terminal_freeze_sha256','science_completion_sha256')},
 'data_manifest_sha256':h(r/'data_manifest.json'),'authorization_sha256':h(r/'authorization.json'),
 'preactivation_audit_sha256':h(a/'A2_INDEPENDENT_PASS.json'),'result_evidence_sha256':h(a/'RESULT_EVIDENCE_CHECK.json'),'result_checker_source_sha256':h(a/'check_results_readonly.py'),
 'scientific_packs':18,'independent_sequences':6,'items_per_sequence':5000,'capacity':100,'assignment_steps_independently_replayed':90000,'claims_with_three_toys_and_analysis':22,'raw_preanalysis_terminals':21,'failures':0,'unknown':0,'retries':0,
 'passed_checks':[
  'All67 frozen study/runtime/source-evidence files remain exact. Data manifest/seal, authorizing root activation, exact prior PASS hash and analysis source/result bindings remain intact.',
  'Exactly18 fixed scientific actions and one analysis completed after three preflight toys;22 claims/results/outer observations,21 raw sealed terminals before analysis. No unexpected action, retry, HALT, unknown, or missing result.',
  'Every saved5000-item assignment independently replayed as exact integers: all indices valid, online placements feasible, capacity respected, final remaining arrays equal, item mass conserved, used-bin counts and assignment hashes match original checker_status=passed. No candidate or solver ran during this audit.',
  'All18 exact source/input/method/sequence identities and A2 claim_id/instance/0 execution IDs agree across report, worker and supervisor. Admitted canonical_text equals each method toy, source sent after host gate,5000 worker steps complete, all workers/supervisors/drivers and outer descendants reaped.',
  'Per-sequence lower bounds, F fractions, each exact paired difference and six-sequence mean, bin differences, total savings, wins/ties/losses, coverage and all saved mechanism proxies independently reproduce exactly.',
  'Frozen PCG64(20261008) paired sequence bootstrap,20000 resamples, shared primary/secondary indices and linear95% percentile intervals independently reproduce exactly. Intervals remain descriptive, not a confirmatory significance or SOTA claim.',
  'Raw immutable terminal hashes were bound into the analysis claim before analysis. Full6 null-unless-all-six semantics and no-imputation were reviewed statically; all six primary and secondary pairs actually completed.',
  'Every scientific pack is within125CPU/93wall reservation; analysis within its60wall reservation. Complete outer wait4 CPU is summed once, nested CPU not re-added; dispatcher child sum reconciles with outer records and full shell exit receipt.',
  'Permanent consumed claims plus named static/dispatcher/shared-audit allowances reconcile to2727CPU/2123active-wall reserved under2800/2200. No A1/C1 budget used and no provider calls introduced.'
 ],
 'method_totals':e['method_totals'],'contrasts':e['contrasts'],
 'concise_result':{
  'bins_original':12202,'bins_patch':12180,'bins_published':12176,
  'primary_patch_minus_original_bins':[-2,-3,-2,-5,-3,-7],
  'primary_total_bins_saved':22,'primary_wins_ties_losses':[6,0,0],
  'primary_mean_F_gain':0.001790555084385612,
  'primary_descriptive_95_percent_interval':[0.0011380058307391572,0.0025285604407218705],
  'secondary_patch_minus_published_bins':[2,-1,4,0,-1,0],
  'secondary_extra_patch_bins':4,'secondary_wins_ties_losses':[2,2,2],
  'secondary_mean_F_difference':-0.00032366509194271744,
  'secondary_descriptive_95_percent_interval':[-0.0010563211011126682,0.00032645960962094923],
  'interpretation':'The fixed0.5 near-fit patch used fewer bins than original EOH on all six new5000-item sequences. It did not beat the public reference in aggregate. This supports a narrow small-sample length-scale replication of the original-comparator benefit; no general superiority, confirmatory significance or SOTA conclusion.'
 },
 'mechanism_interpretation':'Patch r1 placements4241 versus original0; final capacity at residual11..45 falls11160 to4710; full bins fall11743 to7732 while total used bins fall22. Thus full-bin count alone is not a valid optimization objective here. These saved-assignment proxies are descriptive; they do not separately establish causal mediation.',
 'resource_accounting':{
  'new_A2_cap':{'CPU':2800,'active_wall':2200},'fixed_total_reservation':{'CPU':2727,'active_wall':2123},'reservation_margin':{'CPU':73,'active_wall':77},
  'core_execution_full_shell_receipts':e['full_exit_receipts'],'measured_core_execution_CPU_seconds':e['measured_execution_receipts_CPU'],'measured_core_execution_wall_seconds':e['measured_execution_receipts_wall'],'science_guard_trees_CPU_counted_once':e['science_guard_tree_CPU_once'],
  'result_check_complete_shell_receipt':rec(a/'result_check_time_receipt.txt'),
  'shared_preflight_plus_result_audit_reservation':{'CPU':30,'active_wall':30,'includes_stopped_parallel_auditor':True},
  'cost_limit_note':e['cost_limit_note'],
  'timing_caveat':'Concurrent host video synthesis was disclosed in root authorization. Report time as task resource consumption only; no exclusive-host or algorithm runtime-speed comparison is made.'
 },
 'limits':['Six independent sequences at one prespecified distribution and horizon; results do not establish broad generalization or full SOTA.','Public-formula contrast is secondary; patch uses four more bins overall and its descriptive interval spans zero.','Missing-result semantics were inspected statically because there were no missing scientific outputs.','All replay was on saved assignments and metrics; no original candidate, solver or study analysis source was executed by auditor.','This review covers frozen experiment and analysis artifacts. Delivery packaging produced afterward is not automatically covered by this result review.'],
 'reviewer_actions':{'candidate_execution':False,'solver_execution':False,'study_analysis_source_execution':False,'study_directory_modified':False,'old_A1_C1_files_modified':False,'external_API_calls':0}
}
out=a/'A2_RESULT_REVIEW.json'
with out.open('x') as f:json.dump(report,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({'status':report['status'],'report':str(out),'sha256':h(out),'raw_terminal_freeze_sha256':e['raw_terminal_freeze_sha256'],'analysis_result_sha256':e['analysis_result_sha256']},ensure_ascii=False))
