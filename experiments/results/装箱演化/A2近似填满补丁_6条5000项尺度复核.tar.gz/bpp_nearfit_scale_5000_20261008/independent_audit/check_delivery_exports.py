"""Read-only check that deliverable exports preserve already audited raw evidence."""
import csv,hashlib,json,re,resource,signal,time
from pathlib import Path
from datetime import datetime,timezone
resource.setrlimit(resource.RLIMIT_CPU,(3,3));signal.alarm(3)
a=Path('/workspace/shared/audit_bpp_nearfit_scale_20261008');r=Path('/workspace/shared/bpp_nearfit_scale_5000_20261008');start=time.monotonic()
def read(p):return json.loads(p.read_text())
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def need(x,msg):
 if not x:raise RuntimeError(msg)
e=read(a/'RESULT_EVIDENCE_CHECK.json');rep=read(a/'A2_RESULT_REVIEW.json');seal=read(r/'data_seal.json');methods=read(r/'methods.json')['methods'];out=read(r/'analysis_result.json');summary=read(r/'result_summary.json');close=read(r/'closeout.json');reviewhash=h(a/'A2_RESULT_REVIEW.json')
files=['result_summary.json','closeout.json','SUMMARY_ZH.txt','paired_sequence_results.csv','mechanism_results.csv']
for name,m in methods.items():
 file=r/'deliverables/source'/(name+'.py');need(file.read_text()==m['code'] and h(file)==m['code_sha256'],'exact exported source '+name);files.append(str(file.relative_to(r)))
for x in seal['packs']:
 aid=x['action_id'];file=r/'deliverables/assignments'/(aid+'.json');v=read(file);rawfile=r/'results'/(aid+'.json');y=read(rawfile)['payload']
 expect={'action_id':aid,'assignment_and_remaining':y['original_pack_report']['result'],'capacity':y['capacity'],'checker':y['checker'],'input_sha256':y['input_sha256'],'method':y['method'],'n':y['n'],'original_terminal_sha256':h(rawfile),'sequence_index':y['sequence_index'],'source_sha256':y['code_sha256']}
 need(v==expect,'exact assignment export '+aid);files.append(str(file.relative_to(r)))
rows={(v['sequence_index'],v['method']):v for v in e['verified_records']};paired=list(csv.DictReader((r/'paired_sequence_results.csv').open(newline='')));mechanism=list(csv.DictReader((r/'mechanism_results.csv').open(newline='')))
need(len(paired)==6 and len(mechanism)==18,'complete CSV rows')
expected_summary_rows=[]
for i,pair in enumerate(paired):
 bins={n:rows[i,n]['used_bins'] for n in methods};lb=rows[i,'EOH_original']['L1']
 expect={'sequence_index':i,'n':5000,'L1':lb,**bins,'patch_minus_original_bins':bins['EOH_nearfit_one']-bins['EOH_original'],'patch_minus_published_bins':bins['EOH_nearfit_one']-bins['published_EoH']}
 need({k:int(v) for k,v in pair.items()}==expect,'paired CSV exact row')
 expected_summary_rows.append({'sequence_index':i,'L1':lb,**bins})
seen=set()
for row in mechanism:
 i=int(row['sequence_index']);name=row['method'];key=(i,name);need(key not in seen,'unique mechanism CSV');seen.add(key)
 want={'sequence_index':i,'method':name,'used_bins':rows[key]['used_bins'],**rows[key]['mechanism']}
 need({k:(v if k=='method' else int(v)) for k,v in row.items()}==want,'mechanism CSV exact')
need(summary['per_sequence_bins']==expected_summary_rows and summary['contrasts']==out['contrasts'],'summary exact results')
need(summary['analysis_result_sha256']==h(r/'analysis_result.json') and summary['data_seal_sha256']==h(r/'data_seal.json') and summary['source_freeze_sha256']==h(r/'source_freeze.json'),'summary evidence binding')
need('PENDING' not in summary['status'] and reviewhash in (r/'closeout.json').read_text(),'final reviewed summary status and audit binding')
need(close['scientific_packs_complete']==18 and close['total_claims']==22 and close['failure_count']==close['unknown_count']==close['retries']==0,'closeout count')
cs=close['measured_complete_shell_stages']
for n,receipt in cs.items():need(receipt=={k:float(v) for k,v in re.findall(r'([A-Za-z_]+)=([0-9.]+)',(r/n).read_text())},'shell receipt copy '+n)
need(abs(sum(x['user_CPU_seconds']+x['system_CPU_seconds'] for x in cs.values())-close['measured_complete_shell_CPU_total'])<1e-8,'closeout CPU sum')
need(abs(sum(x['wall_seconds'] for x in cs.values())-close['measured_complete_shell_wall_total'])<1e-8,'closeout wall sum')
need(abs(sum(x['outer_wait4_CPU_seconds'] for x in e['resource_rows'])-close['science_outer_wait4_CPU_counted_once'])<1e-8,'science18 outer CPU sum')
text=(r/'SUMMARY_ZH.txt').read_text();need('独审正在进行' not in text and '多4箱' in text and '少22箱' in text and '小样本' in text and '不能据此宣称' in text,'Chinese result limits and current review state')
report={'schema':'A2-independent-delivery-export-check-v1','status':'PASS_A2_DELIVERY_EXPORTS','checked_at_utc':datetime.now(timezone.utc).isoformat(),'result_review_sha256':reviewhash,'analysis_result_sha256':h(r/'analysis_result.json'),'checked_files_sha256':{n:h(r/n) for n in files},'checks':['Three exported method sources match exact registry code and pinned SHA.','Eighteen complete exported assignment/remaining/checker records equal audited raw results and source/input/terminal bindings.','Both CSVs parse with six/eighteen complete rows and equal audited individual bins, differences and mechanism metrics.','JSON summary equals all six per-sequence results and exact raw primary/secondary contrasts.','Chinese summary reports22 fewer bins against original and4 more against public, descriptive intervals and six-sequence limits; correctly avoids strict cross-batch length causal comparison.','Closeout five-receipt totals reconcile; author .038CPU/.038wall explains difference from four-stage core total. Scientific18 outer CPU is correctly distinct from scientific dispatcher including analysis.','Final status records independent result PASS; no claim of fully metered all-in cost or exclusive-host speed benchmark.'],'scientific_source_modified':False,'candidate_execution':False,'solver_execution':False,'scope_note':'Checks named exports only. Later tar, Drive upload or index changes require their own integrity/delivery verification.','audit_budget':'Same shared A2 independent30CPU/30active-wall reservation; no additional budget.','check_CPU_at_emit':time.process_time(),'check_wall_at_emit':time.monotonic()-start}
file=a/'A2_DELIVERY_EXPORT_REVIEW.json'
with file.open('x') as f:json.dump(report,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({'status':report['status'],'checked_files':len(files),'report':str(file),'sha256':h(file)}))
