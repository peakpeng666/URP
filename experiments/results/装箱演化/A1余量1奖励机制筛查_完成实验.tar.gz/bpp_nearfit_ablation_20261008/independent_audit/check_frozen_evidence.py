"""Read-only A1 verification. Never imports study source or executes candidates."""
import hashlib,json,resource,signal,time
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CPU,(10,10)); signal.alarm(10)
r=Path('/workspace/shared/bpp_nearfit_ablation_20261008')
a=Path('/workspace/shared/audit_bpp_nearfit_setup_20261008')
old=Path('/workspace/shared/prospective_confirmation_C1_preparation_20261007')
t0=time.monotonic();checks=[]
def sha(b): return hashlib.sha256(b).hexdigest()
def h(p): return sha(p.read_bytes())
def canon(d): return json.dumps(d,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
def dig(d): return sha(canon(d).encode())
def read(p): return json.loads(p.read_text())
def need(ok,msg):
 if not ok: raise RuntimeError(msg)
checks.append('Auditor executes no candidate, solver, admission, toy or analysis source.')
f=read(r/'source_freeze.json');fh=h(r/'source_freeze.json')
for n,x in f['files'].items(): need(h(r/n)==x,'freeze drift '+n)
wf=read(r/'frozen_runtime/worker_freeze.json')
for n,x in wf['files'].items():
 need(h(r/'frozen_runtime'/n)==x,'runtime local drift '+n)
 need((r/'frozen_runtime'/n).read_bytes()==(old/'frozen_runtime'/n).read_bytes(),'old runtime mismatch '+n)
need(h(r/'guard_collect_blocking.py')=='e507678f7ea00ff6cade255d84e038db44f7d8a5fa7fdd6e902ce1552ee30d97','collector identity')
checks.append(f"All {len(f['files'])} frozen study files and {len(wf['files'])} runtime files match; collector byte-identical to reviewed C1. System dependency enumeration not rerun by auditor.")
methods=('EOH_original','EOH_nearfit_one','published_EoH');m=read(r/'methods.json')['methods'];prior_m=read(old/'METHODS_FROZEN.json')['methods']
need(m[methods[0]]==prior_m['EOH_locked'] and m[methods[2]]==prior_m['published_EoH'],'baseline origins')
for name in methods:
 v=m[name];need(sha(v['code'].encode())==v['code_sha256'],'method source hash');need(sha(v['description'].encode())==v['description_sha256'],'description hash');need(dig({'description':v['description'],'code':v['code']})==v['pair_sha256'],'pair hash')
old_return='return np.where(bins == item, s + 1.0, s)'
new_return='return np.where(bins == item, s + 1.0, np.where(bins - item == 1, s + 0.5, s))'
need(m[methods[0]]['code'].count(old_return)==1 and m[methods[1]]['code']==m[methods[0]]['code'].replace(old_return,new_return),'exact only-line change')
need(m[methods[1]]['code_sha256']=='6bff5a3b26ab13b6ae688cdccca88d647168dd9297d0184b605a5ae3bba39546','pinned patch')
checks.append('Both baseline records match prior frozen records exactly. Patch is only r=1 bonus0.5; r=0 and r>=2 source expressions unchanged. No score evaluated by auditor.')
p=read(r/'policy.json');res=p['resource_accounting']['reservations']
need(sum(v['CPU'] for v in res.values())==3477 and sum(v['wall'] for v in res.values())==2681,'budget sum')
need(p['resource_accounting']['caps']=={'CPU':3500,'active_wall':2750},'budget caps')
need(res['independent_audit']=={'CPU':30,'wall':30},'independent audit debit')
expected=[f'A1_{i:02d}_{name}' for i in range(8) for name in methods[i%3:]+methods[:i%3]]
need(p['scientific_actions']==expected and len(set(expected))==24,'exact rotating scope')
need(p['toy_actions']==['toy_'+x for x in methods],'exact toy scope')
need(p['one_change']['tuning_allowed'] is False and p['one_change']['coefficient']==0.5,'no tuning')
checks.append('Finite global reservation closes at3477CPU/2681active-wall under3500/2750 including30/30 independent audit. One-shot claims and exact3+24+analysis scope prohibit retry/reset; remaining margin23/69.')
toy_ids=p['toy_actions'];toy_data=read(r/'toy.json');toy_receipts=[]
for aid,name in zip(toy_ids,methods):
 c=read(r/'claims'/(aid+'.json'));t=read(r/'results'/(aid+'.json'));y=t['payload'];report=y['original_pack_report'];w=report['worker'];s=report['supervisor_evidence'];o=read(r/'observations'/(aid+'.json'))
 need(c['source_freeze_sha256']==fh and c['reserve_CPU_seconds']==125 and c['reserve_wall_seconds']==93,'toy claim')
 need(t['claim_sha256']==dig(c) and t['status']=='passed','toy terminal')
 need(y['input_sha256']==dig(toy_data) and y['code_sha256']==m[name]['code_sha256'] and y['method']==name,'toy input/source')
 need(y['outcome']=='ok' and y['checker']['checker_status']=='passed','toy checked')
 need(w['source_sent'] is True and w['source_after_host_gate'] is True and w['reaped'] is True and s['reaped'] is True,'source and reap')
 need(w['cleanup_error'] is None and s['cleanup_error'] is None,'cleanup')
 need(w['admission']['admitted'] is True and type(w['admission']['canonical_text']) is str,'real canonical AST receipt')
 need(w['admission']['source_sha256']==m[name]['code_sha256'],'admitted exact source')
 need(w['execution_id']==report['binding']['claim_id']+'/instance/0' and w['instance_index']==0,'ABI')
 need(w['host_observed_limits']['cpu_seconds']==[60,60] and w['host_observed_limits']['address_space_bytes']==[536870912,536870912],'worker OS caps')
 need(t['resources']['driver_reaped'] is True and t['resources']['driver_exit_code']==0,'driver reap')
 need(o['unreaped_descendants_remaining'] is False and all(e['exit_code']==0 for e in o['raw_wait4_events']),'outer all reaped')
 need(abs(o['inclusive_CPU_counted_once']-sum(e['utime']+e['stime'] for e in o['raw_wait4_events']))<1e-8,'single counted CPU')
 need(o['inclusive_CPU_counted_once']>=t['resources']['driver_wait4_inclusive_CPU_seconds'],'outer inclusive bound')
 toy_receipts.append({'action_id':aid,'canonical_sha256':sha(w['admission']['canonical_text'].encode()),'terminal_sha256':h(r/'results'/(aid+'.json')),'observation_sha256':h(r/'observations'/(aid+'.json')),'outer_wait4_CPU_seconds':o['inclusive_CPU_counted_once']})
completion=read(r/'prepare_dispatch_completion.json')
need(completion['status']=='complete' and completion['actions']==toy_ids,'prepare complete')
need(set(x.stem for x in (r/'claims').glob('*.json'))==set(toy_ids),'no scientific claims yet')
checks.append('Exactly3 true toy/admission passes with canonical_text, exact source-after-host-gate, ABI /instance/0, both nested reaps, driver reap and outer rawwait4 complete subtree receipts. No research pack started.')
ex=read(r/'exclusions.json');old_manifest=read(old/'DATA_MANIFEST.json');old_public=read(old/'PUBLIC_EXCLUSION_MANIFEST.json')
need(h(old/'PUBLIC_EXCLUSION_MANIFEST.json')==ex['old_public_manifest_sha256'],'old public exclusions')
prior_hashes={e['items_sha256'] for e in old_public['entries'] if e['n']==1000}
for e,x in zip(old_manifest['instances'],ex['C1_readonly_prefix_evidence']):
 raw=(old/e['relative_file']).read_bytes();need(sha(raw)==e['file_sha256']==x['source_file_sha256'],'C1 bytes');prefix=dig(json.loads(raw)['items'][:1000]);need(prefix==x['prefix1000_sha256'],'C1 prefix');prior_hashes.add(prefix)
need(len(prior_hashes)==25 and prior_hashes==set(ex['prior_1000_prefix_sha256']),'known25 coverage')
dm=read(r/'data_manifest.json');ds=read(r/'data_seal.json')
need(dm['source_freeze_sha256']==ds['source_freeze_sha256']==fh,'data source bind')
need(dm['entropy_draws']==dm['generation_attempts']==1 and dm['quality_filtering'] is False and dm['candidate_evaluations_before_seal']==0,'prospective generation')
need(dm['policy_sha256']==h(r/'policy.json') and dm['generator_source_sha256']==h(r/'generate.py') and dm['exclusion_manifest_sha256']==h(r/'exclusions.json'),'generator binds')
need(ds['data_manifest_sha256']==h(r/'data_manifest.json') and ds['science_enabled'] is False,'data seal')
need(len(dm['instances'])==8 and len(ds['packs'])==24,'data scope')
seen=set()
for i,e in enumerate(dm['instances']):
 raw=(r/e['relative_file']).read_bytes();v=json.loads(raw)
 need(e['sequence_index']==i and e['n']==1000 and e['capacity']==100 and set(v)=={'items','capacity'},'data schema')
 need(len(v['items'])==1000 and v['capacity']==100 and all(type(j) is int and 1<=j<=100 for j in v['items']),'data domain')
 need(raw==(canon(v)+'\n').encode() and sha(raw)==e['file_sha256'] and dig(v)==e['input_sha256'] and dig(v['items'])==e['items_sha256'],'all input hashes')
 need(e['items_sha256'] not in seen and e['items_sha256'] not in prior_hashes,'duplicate data');seen.add(e['items_sha256'])
for j,x in enumerate(ds['packs']):
 i=j//3;name=(methods[i%3:]+methods[:i%3])[j%3]
 expected_row=dict(dm['instances'][i],action_id=expected[j],method=name,code_sha256=m[name]['code_sha256'])
 need(x==expected_row,'exact paired pack binding')
need(read(r/'custody/generation_claim.json')['source_freeze_sha256']==fh and (r/'custody/master.bin').stat().st_size==32,'once seed custody')
need(read(r/'generation_completion.json')['status']=='sealed','generation completion')
need(not (r/'authorization.json').exists() and not (r/'science_dispatch_claim.json').exists() and not (r/'HALT.json').exists(),'not activated and no HALT')
checks.append('All8 canonical1000-item integer inputs verified by file/input/items SHA, unique and disjoint from known25 prefixes; all24 complete paired source/input/action bindings match frozen rotated order. Seed bytes, item values and quality summaries not exported.')
summary={'schema':'A1-readonly-evidence-check-v1','status':'PASS_EVIDENCE_NOT_ACTIVATED','source_freeze_sha256':fh,'data_seal_sha256':h(r/'data_seal.json'),'data_manifest_sha256':h(r/'data_manifest.json'),'policy_sha256':h(r/'policy.json'),'analysis_source_sha256':h(r/'analysis.py'),'methods_sha256':h(r/'methods.json'),'ordered_scientific_actions_sha256':dig(expected),'checks':checks,'toy_receipts':toy_receipts,'local_frozen_file_count':len(f['files']),'original_runtime_file_count':len(wf['files']),'independent_cost_reservation':{'CPU':30,'active_wall':30,'from':'new A1 budget only','includes':'read-only audit tools, report authoring and this bounded validation','initial_short_read_commands':'not individually CPU-timed; conservatively covered, not asserted zero'},'script_CPU_at_emit':time.process_time(),'script_wall_at_emit':time.monotonic()-t0,'script_OS_CPU_limit':10,'script_OS_wall_alarm':10,'candidate_execution':False,'candidate_compilation':False,'real_research_scores_read':False,'private_entropy_read':False,'limitations':['Fresh independent entropy and A1 domain establish no deliberate old-data reuse; exact equality exclusion covers available25 prefixes, not unavailable historic heldout.','No scientific run or5000-item confirmatory validation has occurred.','Control-flow/analysis null semantics reviewed statically; auditor did not execute analysis or candidate source.']}
(a/'FROZEN_EVIDENCE_CHECK.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:summary[k] for k in ('status','source_freeze_sha256','data_seal_sha256','data_manifest_sha256','local_frozen_file_count','script_CPU_at_emit','script_wall_at_emit')}))
