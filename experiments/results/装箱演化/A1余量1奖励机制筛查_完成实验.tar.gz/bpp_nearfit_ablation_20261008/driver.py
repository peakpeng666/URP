"""Exactly one frozen pack; candidate code runs only inside original sandbox."""
import os,sys,signal
sys.dont_write_bytecode=True;os.umask(0o077)
from common import ROOT,read,put,need,sha,digest,source
need(len(sys.argv)==2,'one action');aid=sys.argv[1]
need(os.getppid()==int(os.environ['A1_GUARD_PID']),'guard identity')
signal.signal(signal.SIGXCPU,signal.SIG_DFL);signal.pthread_sigmask(signal.SIG_UNBLOCK,{signal.SIGXCPU})
need(sys.stdin.read(1)=='G','guard release')
if aid=='analysis':
 from analysis import analyze
 result=analyze();put(ROOT/'analysis_result.json',result)
 payload={'analysis_sha256':sha((ROOT/'analysis_result.json').read_bytes()),'candidate_execution':False}
else:
 toy=aid.startswith('toy_')
 if toy:
  mid=aid[4:];data=read(ROOT/'toy.json');items=data['items'];need(data['fixture_only'] and len(items)<=16,'toy only')
 else:
  plan=read(ROOT/'data_seal.json');row=next(x for x in plan['packs'] if x['action_id']==aid);mid=row['method']
  raw=(ROOT/row['relative_file']).read_bytes();need(sha(raw)==row['file_sha256'],'data file SHA');data=__import__('json').loads(raw);items=data['items']
  need(digest(data)==row['input_sha256'] and len(items)==1000 and data['capacity']==100 and all(type(v) is int and 1<=v<=100 for v in items),'sealed input')
 c,b,origin=source(mid,aid)
 if not toy:need(c['code_sha256']==row['code_sha256'],'bound method')
 from supervised_runner import supervised_pack
 from checker import check_assignment
 report=supervised_pack(items,100,c,b,execution_id=b['claim_id']+'/instance/0',instance_index=0)
 checked=check_assignment(items,100,report['result']) if report['outcome']=='ok' else None
 w=report['worker'];sup=report['supervisor_evidence']
 need(w['source_after_host_gate'] and w['reaped'] and sup['reaped'] and w['cleanup_error'] is None and sup['cleanup_error'] is None,'complete cleanup')
 need(w['admission']['admitted'] is True and type(w['admission']['canonical_text']) is str,'sandbox AST admission')
 if not toy:
  pre=read(ROOT/'payloads'/('toy_'+mid+'.json'))['original_pack_report']['worker']['admission']
  need(w['admission']['canonical_text']==pre['canonical_text'],'fixed admitted AST')
 payload={'method':mid,'source_origin':origin,'code_sha256':c['code_sha256'],'input_sha256':digest(data),'sequence_index':None if toy else row['sequence_index'],'n':len(items),'capacity':100,'L1':(sum(items)+99)//100,'outcome':report['outcome'],'checker':checked,'original_pack_report':report,'fixture_only':toy,'missing_is_null':True}
put(ROOT/'payloads'/(aid+'.json'),payload)
