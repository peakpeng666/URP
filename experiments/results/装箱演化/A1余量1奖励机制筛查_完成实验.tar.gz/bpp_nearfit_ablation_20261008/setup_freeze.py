"""Static preparation: no candidate compilation/execution, no random draw."""
import ast,copy,os,sys,time,resource,signal
from pathlib import Path
from common import ROOT,METHODS,read,put,need,sha,digest
sys.dont_write_bytecode=True;os.umask(0o077)
resource.setrlimit(resource.RLIMIT_CPU,(5,5));signal.alarm(8);started=time.monotonic()
OLD=Path('/workspace/shared/prospective_confirmation_C1_preparation_20261007')
need(not (ROOT/'source_freeze.json').exists(),'freeze once')
old=read(OLD/'METHODS_FROZEN.json')['methods'];methods={METHODS[0]:copy.deepcopy(old['EOH_locked']),METHODS[2]:copy.deepcopy(old['published_EoH'])}
code=(ROOT/'source_evidence/A1_NEARFIT_ONE_UNEXECUTED_SOURCE.txt').read_text();need(sha(code.encode())=='6bff5a3b26ab13b6ae688cdccca88d647168dd9297d0184b605a5ae3bba39546','fixed unique patch')
desc='Single-term A1 ablation: original EOH score with a fixed 0.5 bonus only for exactly one unit of post-placement slack; no tuning.'
methods[METHODS[1]]={'description':desc,'code':code,'description_sha256':sha(desc.encode()),'code_sha256':sha(code.encode()),'pair_sha256':digest({'description':desc,'code':code}),'description_consistency':'undetermined','origin':'posthoc_single_term_ablation_no_model_call'}
need(code==methods[METHODS[0]]['code'].replace('return np.where(bins == item, s + 1.0, s)','return np.where(bins == item, s + 1.0, np.where(bins - item == 1, s + 0.5, s))'),'exact only-line patch')
for m,v in methods.items():
 need(sha(v['code'].encode())==v['code_sha256'] and digest({'description':v['description'],'code':v['code']})==v['pair_sha256'],'method identities')
 ast.parse(v['code'])
put(ROOT/'methods.json',{'methods':methods,'no_new_provider_calls':True,'description_is_not_provider_output':True})
put(ROOT/'toy.json',read(OLD/'TOY_FROZEN.json'))
prior=read(OLD/'PUBLIC_EXCLUSION_MANIFEST.json');hashes=[e['items_sha256'] for e in prior['entries'] if e['n']==1000];evidence=[]
manifest=read(OLD/'DATA_MANIFEST.json')
for e in manifest['instances']:
 p=OLD/e['relative_file'];raw=p.read_bytes();need(sha(raw)==e['file_sha256'],'C1 readonly source hash');items=__import__('json').loads(raw)['items']
 h=digest(items[:1000]);hashes.append(h);evidence.append({'C1_sequence_index':e['global_instance_index'],'source_file_sha256':e['file_sha256'],'prefix1000_sha256':h})
put(ROOT/'exclusions.json',{'prior_1000_prefix_sha256':sorted(set(hashes)),'known_coverage':'5 public development prefixes and20 C1 prefixes; no old heldout read. Fresh256bit entropy and new A1 HMAC domain, never reuse/select old seeds or arrays. This is not an exhaustive equality audit of unavailable historical data.','C1_readonly_prefix_evidence':evidence,'old_public_manifest_sha256':sha((OLD/'PUBLIC_EXCLUSION_MANIFEST.json').read_bytes())})
draft=read(ROOT/'original_draft.json');policy=copy.deepcopy(draft);policy.update(schema='A1-frozen-screen-policy-v1',status='PREPARATION_AUTHORIZED_SCIENCE_REQUIRES_NEW_PARENT_ENABLE',toy_actions=['toy_'+m for m in METHODS],scientific_actions=[f'A1_{i:02d}_{m}' for i in range(8) for m in METHODS[i%3:]+METHODS[:i%3]],admission='Each of the3 toy packs uses original sandbox Session source-after-host-gate AST admission; no extra standalone admission child. canonical_text identity retained.',seed_method={'master':'One os.getrandom(32), no reroll; HMAC-SHA256 keyed by master; first16bytes unsigned big-endian.','message':'A1-nearfit-instance-v1|<sha256 policy.json bytes>|<two-digit sequence index>','numpy':'2.3.5','generator':'Generator(PCG64(seed)); np.round(np.clip(45*rng.weibull(3,size=1000),1,100)).astype(np.int64).tolist()','analysis':'PCG64(20261008); integers(0,8,size=(20000,8)); same indices for both contrasts; quantile(method=linear)'},resource_accounting={'caps':{'CPU':3500,'active_wall':2750},'reservations':{'science24':{'CPU':3000,'wall':2232},'toy3_with_admission':{'CPU':375,'wall':279},'static_admin_data':{'CPU':20,'wall':20},'prepare_dispatch':{'CPU':4,'wall':10},'science_dispatch':{'CPU':18,'wall':50},'analysis':{'CPU':30,'wall':60},'independent_audit':{'CPU':30,'wall':30}},'reserved_total':{'CPU':3477,'wall':2681},'fixed_topology_pack':'guard hard1; driver soft2/default SIGXCPU with inherited hard200 so original supervisor/worker each hard60 remain possible; whole guarded pack93wall. Original C1 reviewed125CPU reservation reused. All descendant CPU from outermost wait4 once. No proc aggregate polling.','no_retry':'Every stage and pack consumes an exclusive durable claim. Any unknown stops, never silently rerun.','accounting_scope':'Actual tools/setup reads and writes are covered conservatively by static_admin_data20/20. Static setup5CPU/8wall and data5CPU/8wall OS bounds leave10CPU/4wall for initial short read/copy checks. Source authoring/review reasoning idle time is not active process wall.'})
policy['new_data']['not_yet_generated']=True
policy['new_data']['exclusion_scope']='No reuse of any old arrays or seeds. Exact collision checks against frozen known25 1000-prefix hashes; no old heldout data read.'
policy['proposed_budget']['reservations']['single_dispatcher']['basis']='Split into finite prepare4CPU/10wall plus science18CPU/50wall stages to avoid charging review waiting as active runtime; total unchanged22/60.'
put(ROOT/'policy.json',policy)
original_runtime=read(ROOT/'frozen_runtime/worker_freeze.json')
for n,h in original_runtime['files'].items():need(sha((ROOT/'frozen_runtime'/n).read_bytes())==h,'original36 runtime bytes '+n)
need((ROOT/'guard_collect_blocking.py').read_bytes()==(OLD/'guard_collect_blocking.py').read_bytes(),'byte-identical reviewed collector')
for p in ROOT.glob('*.py'):ast.parse(p.read_text())
need("+'/instance/0'" in (ROOT/'driver.py').read_text() and "['canonical_text']" in (ROOT/'driver.py').read_text(),'ABI static checks')
names=sorted([p.name for p in ROOT.glob('*.py')]+['original_draft.json','methods.json','toy.json','exclusions.json','policy.json']+[str(p.relative_to(ROOT)) for folder in ('frozen_runtime','source_evidence') for p in (ROOT/folder).rglob('*') if p.is_file()])
put(ROOT/'source_freeze.json',{'schema':'A1-source-method-analysis-policy-freeze-v1','files':{n:sha((ROOT/n).read_bytes()) for n in names},'candidate_evaluations':0,'research_entropy_draws':0,'original_runtime_files_verified':len(original_runtime['files']),'science_enabled':False})
put(ROOT/'setup_completion.json',{'status':'frozen_static_PASS','source_freeze_sha256':sha((ROOT/'source_freeze.json').read_bytes()),'self_CPU_at_emit':time.process_time(),'wall_at_emit':time.monotonic()-started,'candidate_execution':False,'source_compile':False,'ast_parse_only':True,'OS_CPU_limit':5,'OS_wall_alarm':8})
print('Static PASS; all source,method,analysis and policy frozen; zero candidate calls/entropy draws.')
