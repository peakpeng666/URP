"""Once-only A1 guard, fixed OS topology and reused blocking wait4 collector."""
import os,sys,signal,resource,time,fcntl
from datetime import datetime,timezone
sys.dont_write_bytecode=True;os.umask(0o077)
from common import ROOT,read,put,need,sha,digest,verify_source
from guard_collect_blocking import collect_driver,valid_new_terminal
need(len(sys.argv)==3,'stage and action');stage,aid=sys.argv[1:]
resource.setrlimit(resource.RLIMIT_CPU,(1,300));signal.signal(signal.SIGXCPU,signal.SIG_DFL);signal.pthread_sigmask(signal.SIG_UNBLOCK,{signal.SIGXCPU})
lock=(ROOT/'guard.lock').open('a+b');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
fh=verify_source();policy=read(ROOT/'policy.json');dispatch=read(ROOT/(stage+'_dispatch_claim.json'))
need(os.getppid()==dispatch['pid'] and os.environ.get('A1_DISPATCH_PID')==str(dispatch['pid']),'authorized dispatcher parent')
need(dispatch['source_freeze_sha256']==fh and not (ROOT/'HALT.json').exists(),'source and halt gate')
if stage=='prepare':need(aid in policy['toy_actions'],'only fixed toy actions')
else:
 need(stage=='science','fixed stage');sealhash=sha((ROOT/'data_seal.json').read_bytes());auth=read(ROOT/'authorization.json');audit=read(ROOT/'independent_review.json')
 need(auth['enabled'] is True and auth['source_freeze_sha256']==fh and auth['data_seal_sha256']==sealhash and auth['independent_review_sha256']==sha((ROOT/'independent_review.json').read_bytes()),'specific parent enable')
 need(audit['status']=='PASS_A1_NOT_ACTIVATED' and audit['source_freeze_sha256']==fh and audit['data_seal_sha256']==sealhash,'specific independent PASS')
 need(aid in [x['action_id'] for x in read(ROOT/'data_seal.json')['packs']]+['analysis'],'fixed actions')
need(not (ROOT/'claims'/(aid+'.json')).exists(),'consumed claim; no retry')
for p in (ROOT/'claims').glob('*.json'):
 need((ROOT/'results'/p.name).exists() and valid_new_terminal(read(p),read(ROOT/'results'/p.name)),'unknown or failed prior claim')
cpu,wall=(30,60) if aid=='analysis' else (125,93)
started=time.monotonic();deadline=started+wall;signal.signal(signal.SIGALRM,signal.SIG_DFL);signal.setitimer(signal.ITIMER_REAL,wall)
claim={'action_id':aid,'stage':stage,'source_freeze_sha256':fh,'data_seal_sha256':None if stage=='prepare' else sealhash,'reserve_CPU_seconds':cpu,'reserve_wall_seconds':wall,'claimed_at_utc':datetime.now(timezone.utc).isoformat(),'no_retry':True}
if aid=='analysis':
 refs={p.name:sha(p.read_bytes()) for p in sorted((ROOT/'results').glob('*.json'))};put(ROOT/'raw_terminal_freeze.json',refs);claim['raw_terminal_freeze_sha256']=sha((ROOT/'raw_terminal_freeze.json').read_bytes())
put(ROOT/'claims'/(aid+'.json'),claim)
env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1','OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','BLIS_NUM_THREADS':'1','A1_GUARD_PID':str(os.getpid())}
soft=28 if aid=='analysis' else 2
command=['/usr/bin/prlimit',f'--cpu={soft}:200','--as=268435456:536870912','--nofile=64:64','--core=0:0','--',sys.executable,'-B',str(ROOT/'driver.py'),aid]
c=collect_driver(command,env,cpu,deadline,ROOT/'logs'/(aid+'.stdout'),ROOT/'logs'/(aid+'.stderr'));u=c['usage'];used=u.ru_utime+u.ru_stime
pf=ROOT/'payloads'/(aid+'.json');ok=c['returncode']==0 and pf.exists() and used+1<=cpu and time.monotonic()<=deadline
payload=read(pf) if ok else {'exception':'driver failure or missing/late terminal','returncode':c['returncode']}
if aid!='analysis' and ok:ok=payload['outcome']=='ok' and payload['checker']['checker_status']=='passed'
status='passed' if ok else 'blocked_no_retry'
put(ROOT/'results'/(aid+'.json'),{'action_id':aid,'claim_sha256':digest(claim),'status':status,'payload':payload,'resources':{'driver_reaped':True,'driver_exit_code':c['returncode'],'driver_wait4_inclusive_CPU_seconds':used,'guard_CPU_hard_limit_seconds':1,'conservative_complete_tree_CPU_upper_seconds':used+1,'wall_at_emit':time.monotonic()-started,'guard_alarm_active_through_exit':True}})
if not ok:put(ROOT/'HALT.json',{'action_id':aid,'reason':'failed gate or infrastructure','unknown_not_retried':True})
print(aid,status,flush=True);sys.exit(0 if ok else 1)
