#!/usr/bin/env python3
"""Read-only P1 public-evidence recovery. No candidate/archived script execution."""
from pathlib import Path
from fractions import Fraction
import json, hashlib, zipfile, time
ROOT=Path('/workspace/shared'); OUT=ROOT/'p2_parent_evidence_recovery_20261007'
BASE=ROOT/'p2_public_scoring_1_19_delivery_20261007'
FINAL=ROOT/'p2_public_scoring_56_60_delta_20261007'
ARCH=Path('/workspace/scratch/27470b7a9f17/attachments/e9d892e6-aa5e-4250-a100-b8e4a0fe3f52/原132槽研究_P1阶段完整可审交付_20261006.zip')
EXPECTED_ZIP='aa14a4a33993850df91c2195b247ae5d29b9cb9d9d1ac845f913ce3b33b6178c'
PRE='workspace/urp132_20261005_b01_phase1_numerical_state/'
DEPS={}
def hashb(b):return hashlib.sha256(b).hexdigest()
def rf(p,raw=False):
 b=p.read_bytes();DEPS[str(p)]={'sha256':hashb(b),'bytes':len(b)};return b if raw else json.loads(b)
def fj(f):return {'numerator':f.numerator,'denominator':f.denominator,'decimal':float(f)}
def fr(f):return Fraction(f['numerator'],f['denominator'])
def main():
 t=time.process_time(); assert hashb(ARCH.read_bytes())==EXPECTED_ZIP
 rf(OUT/'SELECTION_RULE_EXCERPTS.txt',True)
 oldsealed={n:hashb((ROOT/n).read_bytes()) for n in ['p2_full_public_interpretation_20261007.zip','p2_parent_comparison_appendix_20261007.zip']}
 z=zipfile.ZipFile(ARCH);opened=[]
 def rz(n,raw=False):
  assert not any(w in n.lower() for w in ['protocol_draft','heldout','holdout','seed'])
  b=z.read(n);opened.append(n);DEPS['P1ZIP::'+n]={'sha256':hashb(b),'bytes':len(b)};return b if raw else json.loads(b)
 prior=rf(ROOT/'p2_parent_comparison_appendix_20261007/PARENT_COMPARISON_FACTS.json')
 targets={p['id']:p for p in prior['parent_records']};iid='b01_IID_TC_g1_m2_04';ids=set(targets)|{iid}
 snapshots=rf(ROOT/'audit64k/baseline/PARENT_SNAPSHOTS.FROZEN.json')
 snap_e=next(s for s in snapshots['snapshots'] if s['arm']=='EOH_TC');snap_i=next(s for s in snapshots['snapshots'] if s['arm']=='IID_TC')
 assert snap_e['sha256']==prior['frozen_parent_snapshot_sha256']
 assert hashb(json.dumps({k:v for k,v in snap_e.items() if k!='sha256'},sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())==snap_e['sha256']
 snap_members={p['id']:p for s in snapshots['snapshots'] for p in s['members']};assert set(snap_members)==ids
 scope=rf(BASE/'project/frozen_metadata/SOURCE_INPUT_PLAN.json')
 frozen=rf(BASE/'generation_sources/executor/frozen_inputs.json')
 runtime=rf(BASE/'project/frozen_runtime/worker_freeze.json')
 runtime_file_hash=DEPS[str(BASE/'project/frozen_runtime/worker_freeze.json')]['sha256']
 assert runtime_file_hash==scope['runtime_sha256']
 runtime_runner=rf(BASE/'project/frozen_runtime/runner.py',True)
 assert hashb(runtime_runner)==runtime['files']['runner.py']
 assert 'argmax = max(range(len(values)), key=values.__getitem__)' in runtime_runner.decode()
 design_name='workspace/URP/experiments/online_bin_packing/paper_scale_dag_evaluator_v1/data/design_5000.json'
 design_bytes=rz(design_name,True)
 assert hashb(design_bytes)==scope['design_file_sha256']==hashb(rf(BASE/'project/frozen_public/design_5000.json',True))
 panel=rz(PRE+'panel.json');plan=rz(PRE+'plan.json')
 assert panel==scope['design_panel']; assert plan['phase']==1 and plan['heldout_this_run']==0 and plan['controls_this_run']==0
 assert plan['runtime_sha256']==runtime_file_hash
 rows=rz(PRE+'rows.json');select={r['slot_id']:r for r in rows if r['slot_id'] in ids};assert set(select)==ids
 results=[];(OUT/'evidence_public_receipts').mkdir(exist_ok=True)
 for slot,row in sorted(select.items()):
  claim=row['claim']['claim_id'];member=PRE+'results/'+claim+'.json';raw=rz(member,True);res=json.loads(raw);obs=res['observation'];cand=obs['extraction']['candidate'];ad=obs['admission'];scores=obs['scores'];snap=snap_members[slot]
  assert obs['slot_id']==slot and obs['integrity_error'] is None and ad['admitted'] and len(scores)==5
  assert res['claim_sha256']==row['claim']['sha256'];assert res['plan_sha256']==plan['sha256']
  source=hashb(cand['code'].encode());assert source==cand['code_sha256']==row['candidate']['code_sha256']==ad['source_sha256']
  assert cand['code_identity']==snap['code_identity'] and cand['joint_identity']==snap['joint_identity'] and cand['pair_sha256']==snap['pair_sha256']
  if slot in targets:assert source==targets[slot]['source_sha256'] and cand['pair_sha256']==targets[slot]['pair_sha256']
  assert ad['runtime_sha256']==runtime_file_hash
  projected=[]
  for j,s in enumerate(scores):
   ev=s['evidence'];expect=panel['instances'][j]
   assert s['instance_index']==j and s['input_sha256']==expect['input_sha256'] and s['L1']==expect['L1']
   assert s['code_sha256']==source and ev['registry_binding']['source_sha256']==source
   assert s['kind']=='externally_verified' and s['registry_mode']==panel['kind']=='registered_source_study' and s['outcome']=='ok'
   assert ev['checker_status']=='passed' and ev['assignment_complete']
   assert ev['runtime_sha256']==runtime_file_hash and ev['checker_sha256']==runtime['files']['checker.py']==frozen['freeze']['checker_sha256']
   assert ev['intake_manifest_sha256']==runtime['files']['INTAKE.json']==frozen['freeze']['intake_manifest_sha256']
   projected.append({'instance_index':j,'input_sha256':s['input_sha256'],'n':expect['n'],'capacity':expect['capacity'],'L1':s['L1'],'used_bins':s['used_bins'],'checker_status':ev['checker_status'],'checker_sha256':ev['checker_sha256'],'runtime_sha256':ev['runtime_sha256'],'assignment_sha256':ev['assignment_sha256']})
  fitness=sum((Fraction(s['L1'],s['used_bins']) for s in scores),Fraction())/5;assert fitness==fr(snap['fitness'])
  results.append({'slot_id':slot,'claim_id':claim,'source_sha256':source,'pair_sha256':cand['pair_sha256'],'code_identity':cand['code_identity'],'joint_identity':cand['joint_identity'],'fitness':fj(fitness),'used_bins':[s['used_bins'] for s in scores],'total_used_bins':sum(s['used_bins'] for s in scores),'cases':projected,'P1_zip_member':member,'P1_result_sha256':hashb(raw),'source_and_input_runtime_bindings_matched':True})
  (OUT/'evidence_public_receipts'/f'{slot}.json').write_bytes(raw)
 p2=rf(FINAL/'safe_facts/PER_SLOT_SAFE_RESULTS.json');b2=max((r for r in p2 if r['arm']=='EOH_TC' and r['fitness_exact']),key=lambda r:fr(r['fitness_exact']));i2=max((r for r in p2 if r['arm']=='IID_TC' and r['fitness_exact']),key=lambda r:fr(r['fitness_exact']))
 eold=max((r for r in results if '_EOH_' in r['slot_id']),key=lambda r:fr(r['fitness']));iold=next(r for r in results if r['slot_id']==iid);direct=next(r for r in results if r['slot_id']==b2['parents_as_frozen'][0])
 bins=[c['used_bins'] for c in b2['cases']];delta=fr(b2['fitness_exact'])-fr(eold['fitness'])
 facts={'schema':'P2-existing-P1-public-evidence-recovery-v1','status':'SEVEN_EXISTING_PUBLIC_RESULTS_FOUND_AND_MATCHED','P1_archive':{'drive_id':'1SYo9awdPdO9uVQBY6I18Llp0v4B7LFSO','url':'https://drive.google.com/file/d/1SYo9awdPdO9uVQBY6I18Llp0v4B7LFSO/view','sha256':EXPECTED_ZIP,'bytes':ARCH.stat().st_size,'whole_archive_extracted':False},
 'comparability':{'same_public_design_file_sha256':scope['design_file_sha256'],'same_public_panel':panel,'same_runtime_freeze_sha256':runtime_file_hash,'same_checker_sha256':runtime['files']['checker.py'],'same_intake_sha256':runtime['files']['INTAKE.json'],'same_host_runner_sha256':runtime['files']['runner.py'],'schema_field_mapping':{'P1_kind':'externally_verified','P1_registry_mode':'registered_source_study','P2_kind':'registered_source_study','interpretation':'Receipt wrapper labels differ; actual registry mode, input, source, runtime and checker bindings match.'},'bin_choice_tie_rule':'Stable first argmax among feasible bins; frozen runtime runner.py lines441-444,575-601','fitness_definition':'Exact mean of five Fraction(L1,used_bins), maximize; reconstructed from saved bins and equals each frozen parent fitness.','new_evaluations':0},
 'P1_target_results':results,'P2_best':{'slot_id':b2['slot_id'],'fitness':fj(fr(b2['fitness_exact'])),'used_bins':bins,'total_used_bins':sum(bins),'direct_parent_id':direct['slot_id']},
 'comparison_against_best_of_six_EOH_parents':{'parent_slot_id':eold['slot_id'],'parent_fitness':eold['fitness'],'parent_used_bins':eold['used_bins'],'parent_total_used_bins':eold['total_used_bins'],'fitness_delta_offspring_minus_parent':fj(delta),'per_case_bins_offspring_minus_parent':[a-b for a,b in zip(bins,eold['used_bins'])],'total_bins_offspring_minus_parent':sum(bins)-eold['total_used_bins'],'offspring_less_equal_more_bins_case_counts':{'less':sum(a<b for a,b in zip(bins,eold['used_bins'])),'equal':sum(a==b for a,b in zip(bins,eold['used_bins'])),'more':sum(a>b for a,b in zip(bins,eold['used_bins']))}},
 'comparison_against_direct_parent':{'parent_slot_id':direct['slot_id'],'parent_fitness':direct['fitness'],'parent_used_bins':direct['used_bins'],'parent_total_used_bins':direct['total_used_bins'],'fitness_delta_offspring_minus_parent':fj(fr(b2['fitness_exact'])-fr(direct['fitness'])),'total_bins_offspring_minus_parent':sum(bins)-direct['total_used_bins']},
 'historical_IID_retained_candidate':{'slot_id':iold['slot_id'],'fitness':iold['fitness'],'used_bins':iold['used_bins'],'total_used_bins':iold['total_used_bins'],'snapshot_sha256':snap_i['sha256'],'is_above_P2_newborn_IID_best':fr(iold['fitness'])>fr(i2['fitness_exact']),'P2_newborn_best_id':i2['slot_id'],'P2_newborn_best_fitness':fj(fr(i2['fitness_exact']))},
 'comparison_P2_EOH_best_to_historical_IID_retained':{'fitness_delta':fj(fr(b2['fitness_exact'])-fr(iold['fitness'])),'total_bins_EOH_minus_IID':sum(bins)-iold['total_used_bins']},
 'selection_rule_evidence':{'runner_sha256':'a2b2b419f58033f5540abe9465489b2a0200cc0082da1b4bd7f4f18346d07961','runner_lines':[[71,73],[80,90],[305,307]],'core_sha256':'6aff2378ba51203da41c07eb85051568c384024634629400cefe6ba8f4bb4465','core_lines':[[182,194]],'excerpt_file':'SELECTION_RULE_EXCERPTS.txt','EOH_pool':'previous survivors plus current eligible offspring','EOH_capacity':6,'IID_pool':'all eligible candidates in that arm archive','IID_capacity':1,'rank':'exact Fraction descending, original tie_priority, id','deduplication':'joint_identity; retain earliest order','final_rule':'first phase2 survivor per arm; this analysis does not create or commit that selection'},
 'joint_identity_checks':{'P2_best_EOH_different_from_all_six_old_EOH':all(b2['bounded_child_joint_identity']!=r['joint_identity'] for r in results if '_EOH_' in r['slot_id']),'historical_IID_joint_not_repeated_among_P2_IID':not any(r['arm']=='IID_TC' and r['bounded_child_joint_identity']==iold['joint_identity'] for r in p2)},
 'selection_warning':'P2-only newborn best is not automatically the original frozen final survivor. EOH retains prior survivors in its pool; IID ranks eligible archive. No final selection transaction is executed by this recovery.',
 'boundaries':{'heldout_instance_or_score_reads':0,'protocol_draft_member_reads':0,'new_model_calls':0,'parent_or_candidate_executions':0,'archived_scripts_executed':0,'old_reports_modified':False,'original_model_feedback':False,'source_search':'Targeted known local P2 parent metadata, frozen audit64k snapshot, known P1 archive from existing handoff index. No unbounded search.'},
 'pre_whitelist_non_target_result_member':'workspace/urp132_20261005_b01_phase1_numerical_state/results/0327d563176c8323503becb6f066ed9c33a1d90c1818dbb9f7294d76c1855930.json',
 'scope_log':'Before the final seven-target whitelist was clarified, P1 public panel/plan/rows and one non-target P1 result were read for structure. The plan identifies phase1 and heldout_this_run=0; no heldout data was opened. After clarification, only seven target result members were opened.',
 'old_sealed_zip_hashes':oldsealed,'opened_P1_member_names':list(dict.fromkeys(opened))}
 for n,h in oldsealed.items():assert hashb((ROOT/n).read_bytes())==h
 (OUT/'RECOVERED_PUBLIC_FACTS.json').write_text(json.dumps(facts,ensure_ascii=False,indent=2)+'\n')
 (OUT/'INPUT_DEPENDENCIES.json').write_text(json.dumps({'inputs':DEPS,'source_script_sha256':hashb(Path(__file__).read_bytes()),'analysis_CPU_seconds':time.process_time()-t},ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({k:facts[k] for k in ['status','comparison_against_best_of_six_EOH_parents','comparison_against_direct_parent','historical_IID_retained_candidate','comparison_P2_EOH_best_to_historical_IID_retained']},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
