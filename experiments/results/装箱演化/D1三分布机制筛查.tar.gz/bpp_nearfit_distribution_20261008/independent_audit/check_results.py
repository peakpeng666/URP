import ast,hashlib,json,pathlib,sys,time,resource,signal
from fractions import Fraction
start=time.monotonic();cstart=time.process_time();resource.setrlimit(resource.RLIMIT_CPU,(10,10));signal.alarm(12)
r=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(r));sys.dont_write_bytecode=True
H=lambda b:hashlib.sha256(b).hexdigest();J=lambda p:json.loads(p.read_text());D=lambda x:H(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode())
checks=[]
def ck(n,v):
 assert v,n
 checks.append(n)
def val(x):return {'numerator':x.numerator,'denominator':x.denominator,'decimal':float(x)}
review=J(r/'independent_review.json');auth=J(r/'authorization.json');ck('review exact',H((r/'independent_review.json').read_bytes())=='817b513b483509f939d9c940e050b5f83ba084aa8232870d475d1859031645b7')
for file,key in [('source_freeze.json','source_freeze_sha256'),('data_manifest.json','data_manifest_sha256'),('data_seal.json','data_seal_sha256'),('independent_review.json','independent_review_sha256')]:ck('authorization '+file,auth[key]==H((r/file).read_bytes()) and (key not in review or review[key]==auth[key]))
ck('enabled',auth['enabled'] is True)
for n,h in J(r/'source_freeze.json')['files'].items():ck('frozen '+n,H((r/n).read_bytes())==h)
seal=J(r/'data_seal.json');policy=J(r/'policy.json');analysis=J(r/'analysis_result.json');refs=J(r/'raw_terminal_freeze.json');methods=J(r/'methods.json')['methods'];names=['EOH_original','EOH_nearfit_one','published_EoH'];done=J(r/'science_dispatch_completion.json')
ck('single complete finite stage',done['status']=='complete' and done['actions']==policy['scientific_actions']+['analysis'] and done['no_retries'] and not (r/'HALT.json').exists())
ck('40 claims/results/observations',all(set(p.stem for p in (r/d).glob('*.json'))==set(policy['scientific_actions']+policy['toy_actions']+['analysis']) for d in ['claims','results','observations']))
ck('raw terminals freeze',len(refs)==39 and all(H((r/'results'/n).read_bytes())==h for n,h in refs.items()))
score={};used={};toy_cpu=0.;science_cpu=0.;rows={(x['sequence_index'],x['method']):x for x in analysis['records']};details=[]
for aid in policy['toy_actions']+done['actions']:
 t=J(r/'results'/(aid+'.json'));claim=J(r/'claims'/(aid+'.json'));o=J(r/'observations'/(aid+'.json'))
 ck('terminal and claim '+aid,t['claim_sha256']==D(claim) and t['status']=='passed' and t['resources']['driver_reaped'] and t['resources']['driver_exit_code']==0 and claim['source_freeze_sha256']==auth['source_freeze_sha256'])
 ck('outer wait4 '+aid,not o['unreaped_descendants_remaining'] and o['inner_CPU_not_readded'] and all(x['exit_code']==0 for x in o['raw_wait4_events']) and abs(o['inclusive_CPU_counted_once']-sum(x['utime']+x['stime'] for x in o['raw_wait4_events']))<1e-12)
 ck('pack reservations '+aid,t['resources']['conservative_complete_tree_CPU_upper_seconds']<=claim['reserve_CPU_seconds'] and t['resources']['wall_at_emit']<=claim['reserve_wall_seconds'])
 if aid.startswith('toy_'):toy_cpu+=o['inclusive_CPU_counted_once']
 else:science_cpu+=o['inclusive_CPU_counted_once'];ck('seal claim '+aid,claim['data_seal_sha256']==auth['data_seal_sha256'])
 if aid=='analysis':
  ck('analysis output binding',t['payload']['analysis_sha256']==H((r/'analysis_result.json').read_bytes()) and claim['raw_terminal_freeze_sha256']==H((r/'raw_terminal_freeze.json').read_bytes()))
for e in seal['packs']:
 aid=e['action_id'];i=e['sequence_index'];m=e['method'];y=J(r/'results'/(aid+'.json'))['payload'];q=y['original_pack_report'];w=q['worker'];s=q['supervisor_evidence'];raw=(r/e['relative_file']).read_bytes();data=json.loads(raw);items=data['items'];a=q['result']['assignment']
 ck('payload input source '+aid,y==J(r/'payloads'/(aid+'.json')) and H(raw)==e['file_sha256'] and D(data)==e['input_sha256']==y['input_sha256'] and y['code_sha256']==e['code_sha256']==methods[m]['code_sha256'] and y['sequence_index']==i and y['method']==m and y['outcome']=='ok' and y['checker']['checker_status']=='passed')
 ck('worker supervisor ABI '+aid,q['execution_id']==q['binding']['claim_id']+'/instance/0' and q['instance_index']==0 and w['reaped'] and s['reaped'] and w['cleanup_error'] is None and s['cleanup_error'] is None and w['source_after_host_gate'] and w['source_sent'] and w['returncode']==s['returncode']==0 and w['steps']==1000 and w['assignment_complete'])
 toy=J(r/'payloads'/('toy_'+m+'.json'))['original_pack_report']['worker']['admission']
 ck('canonical AST '+aid,w['admission']['admitted'] and w['admission']['canonical_text']==toy['canonical_text']==ast.dump(ast.parse(methods[m]['code']),annotate_fields=True,include_attributes=False))
 rem=[100]*1000;opened=0;r1=0;vol=0;forced=0
 ck('assignment length '+aid,len(a)==1000)
 for item,b in zip(items,a):
  assert type(b) is int and 0<=b<1000 and rem[b]>=item
  if rem[b]==100:
   assert b==opened
   if any(item<=v<100 for v in rem[:opened]):vol+=1
   else:forced+=1
   opened+=1
  rem[b]-=item;r1+=int(rem[b]==1)
 ck('integer assignment replay '+aid,rem==q['result']['remaining'] and sum(100-v for v in rem)==sum(items) and opened==q['result']['used_bins']==y['checker']['used_bins'] and y['checker']['assignment_sha256']==D(a))
 lb=(sum(items)+99)//100;F=Fraction(lb,opened);score[i,m]=F;used[i,m]=opened;row=rows[i,m]
 mech={'r1_placements':r1,'final_r1_bins':rem.count(1),'final_capacity_r11_45':sum(v for v in rem if 11<=v<=45),'full_bins':rem.count(0),'voluntary_openings':vol,'forced_openings':forced}
 ck('exact F and mechanisms '+aid,y['L1']==lb and row['F']==val(F) and row['used_bins']==opened and row['mechanism']==mech and row['status']=='ok')
 details.append({'action_id':aid,'used_bins':opened,'F':val(F),'terminal_sha256':H((r/'results'/(aid+'.json')).read_bytes())})
import numpy as np
idx=np.random.Generator(np.random.PCG64(20261008)).integers(0,4,size=(20000,4));summaries={}
for fi,f in enumerate(policy['families']):
 ids=list(range(4*fi,4*fi+4));fam=analysis['families'][f['id']];summaries[f['id']]={}
 ck('family denominator '+f['id'],fam['denominator']==4 and fam['sequence_indices']==ids and all(c['complete']==4 and c['denominator']==4 and c['failures']==[] for c in fam['coverage'].values()))
 for lhs,rhs in [(names[1],names[0]),(names[1],names[2]),(names[0],names[2])]:
  name=lhs+'_minus_'+rhs;c=fam['contrasts'][name];full=c['full4_result'];diff=[score[i,lhs]-score[i,rhs] for i in ids];bd=[used[i,lhs]-used[i,rhs] for i in ids];boot=np.quantile(np.array([float(x) for x in diff])[idx].mean(axis=1),[.025,.975],method='linear').tolist();wtl=[sum(v>0 for v in diff),sum(v==0 for v in diff),sum(v<0 for v in diff)]
  ck('exact family contrast '+f['id']+'/'+name,c['complete_pairs']==c['denominator']==4 and full['mean_paired_F_difference']==val(sum(diff,Fraction())/4) and full['paired_F_differences']==[val(v) for v in diff] and full['paired_bins_lhs_minus_comparator']==bd and full['total_bin_savings']==-sum(bd) and full['mean_paired_bin_difference']==val(Fraction(sum(bd),4)) and full['wins_ties_losses']==wtl and full['descriptive_95_percentile_bootstrap']==boot)
  summaries[f['id']][name]={'bins_lhs_minus_comparator':bd,'wins_ties_losses':wtl,'mean_paired_F_difference':val(sum(diff,Fraction())/4),'descriptive_95_percentile_bootstrap':boot}
ck('no pooling general superiority',analysis['pooled_mean'] is None and analysis['pooling_for_claims_prohibited'] and not analysis['general_robustness_claim'] and not analysis['SOTA_claim'])
import analysis as locked
ck('saved analysis recomputation',locked.analyze()==analysis)
orig=pathlib.Path.exists;missing_path=r/'results'/'D1_04_EOH_nearfit_one.json'
pathlib.Path.exists=lambda self:False if self==missing_path else orig(self)
try:missing=locked.analyze()
finally:pathlib.Path.exists=orig
mf=missing['families']['uniform_1_100'];ck('single missing preserves full4 null',len(missing['records'])==36 and mf['contrasts']['EOH_nearfit_one_minus_EOH_original']['full4_result'] is None and mf['contrasts']['EOH_nearfit_one_minus_EOH_original']['complete_pairs']==3 and mf['contrasts']['EOH_nearfit_one_minus_EOH_original']['denominator']==4 and mf['contrasts']['EOH_nearfit_one_minus_published_EoH']['full4_result'] is None and missing['families']['weibull3_scale45']==analysis['families']['weibull3_scale45'])
ck('fullwait4 sum',abs(science_cpu-done['inclusive_children_CPU_once'])<1e-10)
receipt=(r/'science_time_receipt.txt').read_text()
record={'status':'PASS_D1_RESULTS','source_freeze_sha256':auth['source_freeze_sha256'],'data_manifest_sha256':auth['data_manifest_sha256'],'data_seal_sha256':auth['data_seal_sha256'],'preparation_review_sha256':auth['independent_review_sha256'],'authorization_sha256':H((r/'authorization.json').read_bytes()),'analysis_result_sha256':H((r/'analysis_result.json').read_bytes()),'checks':checks,'independent_sequence_results':details,'family_contrasts':summaries,'science_packs_passed':36,'unknown_or_failed_claims':0,'candidate_calls_by_auditor':0,'resource_evidence':{'science_dispatch_shell_exit_receipt':receipt,'science_guard_descendants_complete_wait4_CPU_once':science_cpu,'toy_guard_descendants_complete_wait4_CPU_once':toy_cpu,'dispatch_self_CPU_at_emit_not_final':done['self_CPU_at_emit'],'dispatch_wall_at_emit_not_final':done['wall_at_emit'],'resource_reservations_CPU':4977,'resource_reservations_wall':3797,'caps_CPU':5100,'caps_wall':3900,'audits_shared_reservation_CPU':30,'audits_shared_reservation_wall':30,'result_verification_CPU_at_emit':time.process_time()-cstart,'result_verification_wall_at_emit':time.monotonic()-start,'audit_previous_reads_and_preparation_conservative_CPU':3,'audit_previous_reads_and_preparation_conservative_wall':4,'actuals_do_not_replace_reservations':True},'conclusion':'Patch beats original EOH on all4 streams in each family. Relative to published EoH: Weibull3 3W0T1L; uniform0W1T3L with paired bin differences[10,0,6,6]; mixture4W0T0L. No pooled positive average or general superiority claim. Four streams per family and descriptive bootstrap only.'}
raw=(json.dumps(record,sort_keys=True,separators=(',',':'),ensure_ascii=False)+'\n').encode();out=r/'independent_audit'/'D1_RESULT_REVIEW.json'
with out.open('xb') as f:f.write(raw)
(r/'independent_audit'/'D1_RESULT_REVIEW.sha256').write_text(H(raw)+'  D1_RESULT_REVIEW.json\n')
print(json.dumps({'status':record['status'],'sha256':H(raw),'checks':len(checks),'CPU':time.process_time()-cstart,'wall':time.monotonic()-start,'science_guard_CPU':science_cpu}))
