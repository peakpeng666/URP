import ast,hashlib,json,pathlib,sys,time,resource,signal,hmac
start=time.monotonic(); cstart=time.process_time(); resource.setrlimit(resource.RLIMIT_CPU,(8,8));signal.alarm(10)
r=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(r));sys.dont_write_bytecode=True
H=lambda b:hashlib.sha256(b).hexdigest()
J=lambda p:json.loads(p.read_text())
D=lambda x:H(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode())
checks=[]
def ck(name,x):
 assert x,name
 checks.append(name)
expected={'source_freeze.json':'374c3479528d24940dbcc963ec4bca354816cbf03224df9be78a59b8b6f13ce4','data_manifest.json':'22595ca0947fab318f1265e545d02f07cd0463acb83bd0aa7765fcd4a2408514','data_seal.json':'b37ed20b4d8592b6b22a4fb2ec0bdc018487ef4cdb55b38152c5b37add8ba0af'}
for n,h in expected.items():ck('exact '+n,H((r/n).read_bytes())==h)
f=J(r/'source_freeze.json');ck('68 frozen files',len(f['files'])==68)
for n,h in f['files'].items():ck('frozen '+n,H((r/n).read_bytes())==h)
a1=r.parent/'bpp_nearfit_ablation_20261008';a2=r.parent/'bpp_nearfit_scale_5000_20261008'
for base in (a1,a2):
 for n in ('methods.json','toy.json','guard_collect.py','guard_collect_blocking.py'):ck('identical '+base.name+'/'+n,(r/n).read_bytes()==(base/n).read_bytes())
for p in (a1/'frozen_runtime').iterdir():
 if p.is_file():ck('identical A1 runtime '+p.name,p.read_bytes()==(r/'frozen_runtime'/p.name).read_bytes())
methods=J(r/'methods.json')['methods'];names=['EOH_original','EOH_nearfit_one','published_EoH'];ck('three locked methods',set(methods)==set(names))
for m in names:ck('method code '+m,H(methods[m]['code'].encode())==methods[m]['code_sha256'])
ck('only r1 bonus0.5',methods[names[1]]['code']==methods[names[0]]['code'].replace('return np.where(bins == item, s + 1.0, s)','return np.where(bins == item, s + 1.0, np.where(bins - item == 1, s + 0.5, s))'))
p=J(r/'policy.json');manifest=J(r/'data_manifest.json');seal=J(r/'data_seal.json');ex=J(r/'exclusions.json');res=p['resource_accounting']['reservations']
ck('reservation caps',sum(x['CPU'] for x in res.values())==4977<=5100 and sum(x['wall'] for x in res.values())==3797<=3900)
ck('audit reservation includes results',res['independent_audit']=={'CPU':30,'wall':30})
ck('12 sequences and36 packs',len(manifest['instances'])==12 and len(seal['packs'])==36)
ck('manifest seal link',seal['data_manifest_sha256']==expected['data_manifest.json'])
ck('single draw generation',manifest['entropy_draws']==manifest['generation_attempts']==1 and not manifest['quality_filtering'])
import numpy as np
ck('numpy2.3.5',np.__version__=='2.3.5');master=(r/'custody/master.bin').read_bytes();seen=set();familyids=['weibull3_scale45','uniform_1_100','mixture_1_20_80_99']
for i,e in enumerate(manifest['instances']):
 raw=(r/e['relative_file']).read_bytes();data=json.loads(raw);items=data['items'];ck('instance binding '+str(i),e['sequence_index']==i and e['family_sequence_index']==i%4 and e['family']==familyids[i//4] and H(raw)==e['file_sha256'] and D(data)==e['input_sha256'] and D(items)==e['items_sha256'] and len(items)==1000 and data['capacity']==100 and all(type(v) is int and 1<=v<=100 for v in items))
 ck('fresh exact exclusion '+str(i),D(items) not in seen and D(items) not in ex['prior_1000_prefix_sha256']);seen.add(D(items))
 msg=('D1-distribution-instance-v1|'+H((r/'policy.json').read_bytes())+'|'+f'{i:02d}').encode();seed=int.from_bytes(hmac.new(master,msg,hashlib.sha256).digest()[:16],'big');rng=np.random.Generator(np.random.PCG64(seed))
 if i<4: replay=np.round(np.clip(45*rng.weibull(3,size=1000),1,100)).astype(np.int64).tolist()
 elif i<8:replay=rng.integers(1,101,size=1000,dtype=np.int64).tolist()
 else:
  component=rng.integers(0,2,size=1000,dtype=np.int64);offset=rng.integers(0,20,size=1000,dtype=np.int64);replay=(offset+np.where(component==0,1,80)).tolist()
 ck('deterministic family replay '+str(i),replay==items)
 for j,m in enumerate(names[i%3:]+names[:i%3]):ck('rotation binding '+str(i)+' '+m,seal['packs'][3*i+j]==dict(e,action_id=f'D1_{i:02d}_{m}',method=m,code_sha256=methods[m]['code_sha256']))
ck('exact frozen action order',[x['action_id'] for x in seal['packs']]==p['scientific_actions'])
ck('known39 exclusions',len(set(ex['prior_1000_prefix_sha256']))==39)
toys=[]
for m in names:
 aid='toy_'+m;t=J(r/'results'/(aid+'.json'));claim=J(r/'claims'/(aid+'.json'));obs=J(r/'observations'/(aid+'.json'));y=t['payload'];q=y['original_pack_report'];w=q['worker'];s=q['supervisor_evidence']
 ck('real passed terminal '+m,t['status']=='passed' and t['claim_sha256']==D(claim) and y==J(r/'payloads'/(aid+'.json')) and y['outcome']=='ok' and y['checker']['checker_status']=='passed')
 ck('canonical identity '+m,w['admission']['admitted'] is True and w['admission']['canonical_text']==ast.dump(ast.parse(methods[m]['code']),annotate_fields=True,include_attributes=False) and w['admission']['source_sha256']==methods[m]['code_sha256'])
 ck('ABI cleanup gates '+m,q['execution_id']==q['binding']['claim_id']+'/instance/0' and q['instance_index']==0 and w['source_after_host_gate'] and w['reaped'] and s['reaped'] and w['cleanup_error'] is None and s['cleanup_error'] is None)
 ck('fullwait4 '+m,t['resources']['driver_reaped'] and t['resources']['driver_exit_code']==0 and not obs['unreaped_descendants_remaining'] and obs['inner_CPU_not_readded'] and abs(obs['inclusive_CPU_counted_once']-sum(x['utime']+x['stime'] for x in obs['raw_wait4_events']))<1e-12 and all(x['exit_code']==0 for x in obs['raw_wait4_events']))
 items=J(r/'toy.json')['items'];rem=[100]*len(items)
 for item,b in zip(items,q['result']['assignment']):assert rem[b]>=item;rem[b]-=item
 ck('saved assignment replay '+m,len(q['result']['assignment'])==len(items) and rem==q['result']['remaining'] and sum(x!=100 for x in rem)==y['checker']['used_bins'])
 toys.append({'method':m,'terminal_sha256':H((r/'results'/(aid+'.json')).read_bytes()),'observation_sha256':H((r/'observations'/(aid+'.json')).read_bytes()),'inclusive_CPU_once':obs['inclusive_CPU_counted_once']})
ck('science not activated',not (r/'authorization.json').exists() and not (r/'science_dispatch_claim.json').exists() and not (r/'HALT.json').exists() and set(x.stem for x in (r/'claims').glob('*.json'))==set(p['toy_actions']))
import analysis
oldread=analysis.read
analysis.read=lambda path: {} if pathlib.Path(path).name=='raw_terminal_freeze.json' else oldread(path)
missing=analysis.analyze()
ck('all36 missing slots retained',len(missing['records'])==36 and all(x['F'] is None and x['used_bins'] is None for x in missing['records']))
ck('all per-family missing means null',all(fam['denominator']==4 and all(c['full4_result'] is None and c['denominator']==4 and c['complete_pairs']==0 and len(c['paired_sequence_differences'])==4 for c in fam['contrasts'].values()) for fam in missing['families'].values()))
ck('no pooled masking',missing['pooled_mean'] is None and missing['pooling_for_claims_prohibited'])
record={'status':'PASS_D1_NOT_ACTIVATED','source_freeze_sha256':expected['source_freeze.json'],'data_manifest_sha256':expected['data_manifest.json'],'data_seal_sha256':expected['data_seal.json'],'review_scope':'Independent read-only preparation review; own audit artifacts only. No candidate execution, no toy rerun, no science launch, no new entropy. Deterministic regeneration from existing entropy solely verifies sealed data. Missing-data analysis tested in memory without output writes.','checks':checks,'toy_evidence':toys,'scientific_packs_started':0,'authorization_written':False,'resource_reservations':{'CPU':4977,'active_wall':3797,'cap_CPU':5100,'cap_wall':3900},'audit_resource_accounting':{'this_verification_CPU_at_emit':time.process_time()-cstart,'this_verification_wall_at_emit':time.monotonic()-start,'earlier_read_tool_calls_conservative_CPU_seconds':2,'earlier_read_tool_calls_conservative_wall_seconds':3,'total_audit_reservation_CPU_seconds':30,'total_audit_reservation_wall_seconds':30,'remaining_reservation_covers_result_review':True},'limitations':['Only four independent streams per prespecified family. Bootstrap is descriptive; no robustness/SOTA claim.','Original-domain gains and OOD losses must be reported separately; no pooling.','PASS does not activate science. Root must supply exact-hash-bound authorization.']}
raw=(json.dumps(record,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n').encode();out=r/'independent_review.json'
with out.open('xb') as f:f.write(raw)
(r/'independent_audit'/'PREPARATION_REVIEW.sha256').write_text(H(raw)+'  independent_review.json\n')
print(json.dumps({'status':record['status'],'review_sha256':H(raw),'checks':len(checks),'CPU':time.process_time()-cstart,'wall':time.monotonic()-start}))
