"""Two finite D1 stages; shared22CPU/60wall overhead reservation, no retries."""
import ctypes,fcntl,os,sys,resource,signal,subprocess,time
from common import ROOT,read,put,need,sha,verify_source
from guard_collect_blocking import identity,valid_new_terminal
sys.dont_write_bytecode=True;os.umask(0o077)
need(len(sys.argv)==2 and sys.argv[1] in ('prepare','science'),'fixed stage');stage=sys.argv[1]
lock=(ROOT/'dispatch.lock').open('a+b');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
need(not (ROOT/(stage+'_dispatch_claim.json')).exists() and not (ROOT/'HALT.json').exists(),'consumed stage or HALT; no relaunch')
fh=verify_source();policy=read(ROOT/'policy.json');toy=stage=='prepare';cpu=3 if toy else 17;overhead_wall=10 if toy else 50
resource.setrlimit(resource.RLIMIT_CPU,(cpu,300));resource.setrlimit(resource.RLIMIT_AS,(67108864,536870912));signal.signal(signal.SIGXCPU,signal.SIG_DFL);signal.pthread_sigmask(signal.SIG_UNBLOCK,{signal.SIGXCPU})
if toy:actions=policy['toy_actions']
else:
 auth=read(ROOT/'authorization.json');audit=read(ROOT/'independent_review.json');sealhash=sha((ROOT/'data_seal.json').read_bytes())
 need(auth['enabled'] is True and auth['source_freeze_sha256']==fh and auth['data_seal_sha256']==sealhash and auth['independent_review_sha256']==sha((ROOT/'independent_review.json').read_bytes()),'parent enable required')
 need(audit['status']=='PASS_D1_NOT_ACTIVATED' and audit['source_freeze_sha256']==fh and audit['data_seal_sha256']==sealhash,'audit PASS required')
 actions=[x['action_id'] for x in read(ROOT/'data_seal.json')['packs']]+['analysis']
started=time.monotonic();wall=len(actions)*93+overhead_wall if toy else 36*93+60+overhead_wall
signal.signal(signal.SIGALRM,signal.SIG_DFL);signal.setitimer(signal.ITIMER_REAL,wall)
put(ROOT/(stage+'_dispatch_claim.json'),{'stage':stage,'pid':os.getpid(),'source_freeze_sha256':fh,'reserve_CPU_seconds':cpu+1,'nonoverlapped_wall_reservation_seconds':overhead_wall,'stage_wall_limit':wall,'no_retry':True})
libc=ctypes.CDLL(None,use_errno=True);need(libc.prctl(36,1,0,0,0)==0,'subreaper');parent=os.getpid()
def death_guard():
 if libc.prctl(1,signal.SIGKILL,0,0,0)!=0 or os.getppid()!=parent:os._exit(76)
env=dict(os.environ,D1_DISPATCH_PID=str(parent),PYTHONDONTWRITEBYTECODE='1');observations=[]
for aid in actions:
 need(not (ROOT/'HALT.json').exists() and not (ROOT/'claims'/(aid+'.json')).exists(),'HALT or permanent consumed claim')
 child=subprocess.Popen([sys.executable,'-B',str(ROOT/'guard.py'),stage,aid],env=env,cwd=ROOT,preexec_fn=death_guard)
 pid,status,u=os.wait4(child.pid,0);child.returncode=os.waitstatus_to_exitcode(status)
 events=[{'pid':pid,'raw_wait_status':status,'exit_code':child.returncode,'utime':u.ru_utime,'stime':u.ru_stime,'maxrss':u.ru_maxrss}]
 deadline=time.monotonic()+2;unreaped=False
 while True:
  try:p,s,r=os.wait4(-1,os.WNOHANG)
  except ChildProcessError:break
  if p:events.append({'pid':p,'raw_wait_status':s,'exit_code':os.waitstatus_to_exitcode(s),'utime':r.ru_utime,'stime':r.ru_stime,'maxrss':r.ru_maxrss})
  elif time.monotonic()>=deadline:unreaped=True;break
  else:time.sleep(.02)
 obs={'action_id':aid,'raw_wait4_events':events,'inclusive_CPU_counted_once':sum(x['utime']+x['stime'] for x in events),'inner_CPU_not_readded':True,'unreaped_descendants_remaining':unreaped};put(ROOT/'observations'/(aid+'.json'),obs);observations.append(obs)
 if child.returncode!=0 or unreaped:
  if not (ROOT/'HALT.json').exists():put(ROOT/'HALT.json',{'action_id':aid,'guard_exit':child.returncode,'unreaped':unreaped,'no_retry':True})
  raise SystemExit(1)
 need(valid_new_terminal(read(ROOT/'claims'/(aid+'.json')),read(ROOT/'results'/(aid+'.json'))),'complete terminal')
put(ROOT/(stage+'_dispatch_completion.json'),{'status':'complete','actions':actions,'self_CPU_at_emit':time.process_time(),'inclusive_children_CPU_once':sum(x['inclusive_CPU_counted_once'] for x in observations),'wall_at_emit':time.monotonic()-started,'alarm_active_through_exit':True,'no_retries':True})
