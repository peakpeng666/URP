"""Post-run export only: read frozen analysis and receipts; no candidate execution."""
import csv,hashlib,json,re,os
from pathlib import Path
R=Path(__file__).resolve().parent

def read(p):return json.loads(p.read_text())
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(n,v):
 with (R/n).open('x') as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
def csvfile(n,rows):
 with (R/n).open('x',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows);f.flush();os.fsync(f.fileno())
a=read(R/'analysis_result.json');p=read(R/'policy.json');methods=('EOH_original','EOH_nearfit_one','published_EoH')
rows=[]
for x in sorted(a['records'],key=lambda x:(x['sequence_index'],methods.index(x['method']))):
 rows.append({'family':x['family'],'family_sequence_index':x['family_sequence_index'],'global_sequence_index':x['sequence_index'],'method':x['method'],'status':x['status'],'n':1000,'capacity':100,'L1':x.get('L1'),'used_bins':x['used_bins'],'F_numerator':x['F']['numerator'] if x['F'] else None,'F_denominator':x['F']['denominator'] if x['F'] else None,'F_decimal':x['F']['decimal'] if x['F'] else None,**(x['mechanism'] or {})})
csvfile('sequence_method_results.csv',rows)
paired=[];families=[]
for spec in p['families']:
 fid=spec['id'];v=a['families'][fid]
 for contrast,c in v['contrasts'].items():
  for z in c['paired_sequence_differences']:
   q=z['F_lhs_minus_comparator'];paired.append({'family':fid,'contrast':contrast,'global_sequence_index':z['sequence_index'],'family_sequence_index':z['family_sequence_index'],'bins_lhs_minus_comparator':z['bins_lhs_minus_comparator'],'F_difference_numerator':q['numerator'] if q else None,'F_difference_denominator':q['denominator'] if q else None,'F_difference_decimal':q['decimal'] if q else None})
  z=c['full4_result'];q=z['mean_paired_F_difference'] if z else None
  families.append({'family':fid,'contrast':contrast,'complete_pairs':c['complete_pairs'],'denominator':4,'F_mean_difference_numerator':q['numerator'] if q else None,'F_mean_difference_denominator':q['denominator'] if q else None,'F_mean_difference_decimal':q['decimal'] if q else None,'total_bin_savings':z['total_bin_savings'] if z else None,'mean_bin_difference':z['mean_paired_bin_difference']['decimal'] if z else None,'wins':z['wins_ties_losses'][0] if z else None,'ties':z['wins_ties_losses'][1] if z else None,'losses':z['wins_ties_losses'][2] if z else None,'descriptive95_bootstrap_lower':z['descriptive_95_percentile_bootstrap'][0] if z else None,'descriptive95_bootstrap_upper':z['descriptive_95_percentile_bootstrap'][1] if z else None})
csvfile('paired_sequence_results.csv',paired);csvfile('family_contrasts.csv',families)

def seconds(s):
 m=re.fullmatch(r'(\d+)m([\d.]+)s',s);return int(m[1])*60+float(m[2])
stages={}
for name in ['author_time_receipt.txt','setup_time_receipt.txt','prepare_time_receipt.txt','generation_time_receipt.txt','handoff_check_time_receipt.txt','activation_time_receipt.txt','science_time_receipt.txt']:
 fields=dict(line.split() for line in (R/name).read_text().splitlines() if line.strip());stages[name]={'wall_seconds':seconds(fields['real']),'user_CPU_seconds':seconds(fields['user']),'system_CPU_seconds':seconds(fields['sys'])}
terminals=[read(x) for x in (R/'results').glob('*.json')]
assert len(terminals)==40 and all(x['status']=='passed' for x in terminals) and not (R/'HALT.json').exists()
put('closeout.json',{'status':'COMPLETE_ALL36_PLUS_LOCKED_ANALYSIS','source_freeze_sha256':h(R/'source_freeze.json'),'data_seal_sha256':h(R/'data_seal.json'),'analysis_result_sha256':h(R/'analysis_result.json'),'raw_terminal_freeze_sha256':h(R/'raw_terminal_freeze.json'),'scientific_packs_complete':36,'toy_packs_complete':3,'analysis_complete':1,'total_claims':40,'failure_count':0,'unknown_count':0,'retries':0,'provider_calls':0,'currency_cost':0,'new_CPU_cap':5100,'new_active_wall_cap':3900,'conservative_CPU_reservation':4977,'conservative_active_wall_reservation':3797,'old_C1_A1_A2_debit':0,'measured_complete_shell_stages':stages,'measured_complete_shell_CPU_total':sum(x['user_CPU_seconds']+x['system_CPU_seconds'] for x in stages.values()),'measured_complete_shell_wall_total':sum(x['wall_seconds'] for x in stages.values()),'science_plus_analysis_complete_shell_CPU':stages['science_time_receipt.txt']['user_CPU_seconds']+stages['science_time_receipt.txt']['system_CPU_seconds'],'science_plus_analysis_complete_shell_wall':stages['science_time_receipt.txt']['wall_seconds'],'cost_scope':'Complete shell stages shown, not measured all-in. Excludes initial/final short reads, export/package commands and independent audit. These remain in fixed static/admin20/20 and audit30/30 reservations. Do not add inner wait4 CPU again.','experimental_master':'master.bin is experiment reproducibility entropy, not account credential. Private delivery only; no external upload performed here.','independent_result_review':'Separate independent review required; results report is not self-certification.','conclusion_limits':a['families'].keys() if False else ['Only these three prespecified distributions at n1000/cap100, four independent sequences per family.','No mixed family average, no general robustness/SOTA claim, no confirmatory significance claim.','Original EOH is tailored to Weibull3 scale45; OOD results do not erase original-domain conclusion.']})
lines=['D1 三种预定分布稳健性筛查：固定 r=1 加0.5 补丁','', '完成：12条全新独立序列，每族4条、每条1000项、容量100；三方法同序列配对轮转。36/36科学pack、3/3 toy及固定分析全部passed，失败、缺项和unknown均为0。正式结果独立审核见D1_RESULT_REVIEW.json。','', '核心结论：补丁在这三个预定分布的各4条序列中，都比原EOH少用箱。但均匀分布上仍不及公开EoH，不能称一般领先或SOTA。原EOH为Weibull任务定制；OOD负结果不抹掉原域结论。','']
labels={'weibull3_scale45':'原域正对照：Weibull形状3、尺度45，clip1..100后round','uniform_1_100':'OOD：均匀整数1..100','mixture_1_20_80_99':'OOD：逐项等概率混合均匀整数1..20与80..99'}
for spec in p['families']:
 fid=spec['id'];f=a['families'][fid];lines += [labels[fid]+'（独立分母4）']
 for lhs,other in [('EOH_nearfit_one','EOH_original'),('EOH_nearfit_one','published_EoH'),('EOH_original','published_EoH')]:
  z=f['contrasts'][lhs+'_minus_'+other]['full4_result'];q=z['mean_paired_F_difference'];ci=z['descriptive_95_percentile_bootstrap'];lines += [f"- {lhs} − {other}：箱数差{z['paired_bins_lhs_minus_comparator']}；总节省{z['total_bin_savings']}箱；胜/平/负{z['wins_ties_losses']}；平均F差={q['numerator']}/{q['denominator']} ≈ {q['decimal']:.12f}；描述性95%区间[{ci[0]:.12f}, {ci[1]:.12f}]。"]
 lines += ['']
lines += ['指标与边界','- F=ceil(sum(items)/100)/used_bins，越大越好。差值与均值由精确Fraction计算；逐序列F及三对比较保留在CSV和analysis_result.json。','- 箱数差为左方法−右方法，负数表示左方法更省箱；胜负按F差。','- 每族仅4条；20000次固定seed配对bootstrap仅作描述，不能据区间排除0声称确认性显著。没有跨族混合平均。','- 缺失预设为null、分母保持4，本次无缺失。','- 0.5未调参；不换候选、不挑难度、无补样/重试。12条数据一次生成，39个已知旧前缀精确hash去重通过。','', '实际成本与交付','- 科学36+冻结分析：完整退出CPU87.010秒、活动墙钟87.628秒。内层wait4不重复加总。','- 预约4977 CPU秒/3797活动墙钟秒，批准上限5100/3900；预算含准备、toy、数据封存、分析和独审。更多分阶段实测见closeout.json及各time_receipt。未把短管理命令声称为零成本。','- 零模型API、安装、购买或上传；旧包与冻结源未修改。完整输入、方法源码、原始assignment/remaining、checker、claim、进程资源证据及独审纳入私有交付包。','- master.bin仅实验复现熵，不是账号凭证；交付包须保持私有。']
with (R/'SUMMARY_ZH.txt').open('x') as f:f.write('\n'.join(lines)+'\n');f.flush();os.fsync(f.fileno())
print('Read-only exports written: 36 method rows,36 paired differences,9 family contrasts, closeout and Chinese summary.')
