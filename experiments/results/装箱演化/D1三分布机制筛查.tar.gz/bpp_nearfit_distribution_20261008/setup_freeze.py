"""Static D1 preparation, exact A1 reuse, old-input hash exclusions only."""
import ast,os,sys,time,resource,signal,difflib
from pathlib import Path
from common import ROOT,METHODS,read,put,need,sha,digest
sys.dont_write_bytecode=True;os.umask(0o077)
resource.setrlimit(resource.RLIMIT_CPU,(5,5));signal.alarm(8);started=time.monotonic()
A1=Path('/workspace/shared/bpp_nearfit_ablation_20261008');A2=Path('/workspace/shared/bpp_nearfit_scale_5000_20261008')
need(not (ROOT/'source_freeze.json').exists(),'freeze once')
prior={}
for label,base in [('A1',A1),('A2',A2)]:
 oldfreeze=read(base/'source_freeze.json')
 for n,h in oldfreeze['files'].items():need(sha((base/n).read_bytes())==h,'readonly prior source '+label+'/'+n)
 review=base/'independent_audit'/(label+'_RESULT_REVIEW.json');need(read(review)['status']=='PASS_'+label+'_RESULTS','prior independently passed')
 prior[label]={'source_freeze_sha256':sha((base/'source_freeze.json').read_bytes()),'result_audit_sha256':sha(review.read_bytes())}
 for n in ['data_manifest.json','exclusions.json']:need((ROOT/'source_evidence'/(label+'_'+n.upper())).read_bytes()==(base/n).read_bytes(),'exact exclusion metadata copy')
for n in ['methods.json','toy.json','guard_collect.py','guard_collect_blocking.py']:
 need((ROOT/n).read_bytes()==(A1/n).read_bytes()==(A2/n).read_bytes(),'byte-identical A1/A2 '+n)
methods=read(ROOT/'methods.json')['methods'];need(set(methods)==set(METHODS),'three fixed methods')
for m,v in methods.items():need(sha(v['code'].encode())==v['code_sha256'],'source hash');ast.parse(v['code'])
need(methods['EOH_nearfit_one']['code_sha256']=='6bff5a3b26ab13b6ae688cdccca88d647168dd9297d0184b605a5ae3bba39546','fixed patch')
need(methods['EOH_nearfit_one']['code']==methods['EOH_original']['code'].replace('return np.where(bins == item, s + 1.0, s)','return np.where(bins == item, s + 1.0, np.where(bins - item == 1, s + 0.5, s))'),'sole0.5 term')
original_runtime=read(ROOT/'frozen_runtime/worker_freeze.json')
for p in (A1/'frozen_runtime').rglob('*'):
 if p.is_file():need(p.read_bytes()==(ROOT/'frozen_runtime'/p.relative_to(A1/'frozen_runtime')).read_bytes(),'runtime byte-identical A1')
for n,h in original_runtime['files'].items():need(sha((ROOT/'frozen_runtime'/n).read_bytes())==h,'original runtime hash '+n)
a1data=read(ROOT/'source_evidence/A1_DATA_MANIFEST.JSON');oldex=read(ROOT/'source_evidence/A1_EXCLUSIONS.JSON');a2data=read(ROOT/'source_evidence/A2_DATA_MANIFEST.JSON')
h1000=set(oldex['prior_1000_prefix_sha256']+[x['items_sha256'] for x in a1data['instances']]);a2evidence=[]
need(len(h1000)==33,'C1/public/A1 exact exclusions')
for e in a2data['instances']:
 raw=(A2/e['relative_file']).read_bytes();need(sha(raw)==e['file_sha256'],'A2 readonly source bytes');items=__import__('json').loads(raw)['items'];prefix=digest(items[:1000]);h1000.add(prefix)
 a2evidence.append({'sequence_index':e['sequence_index'],'source_file_sha256':e['file_sha256'],'prefix1000_sha256':prefix})
need(len(h1000)==39,'known39 exact exclusion scope')
put(ROOT/'exclusions.json',{'prior_1000_prefix_sha256':sorted(h1000),'A2_readonly_prefix_evidence':a2evidence,'source_manifest_sha256':{n:sha((ROOT/'source_evidence'/n).read_bytes()) for n in ['A1_DATA_MANIFEST.JSON','A1_EXCLUSIONS.JSON','A2_DATA_MANIFEST.JSON','A2_EXCLUSIONS.JSON']},'known_coverage':'39 known public/C1/A1/A2 1000-item prefixes. Prior A2 arrays read only to compute exact prefix hashes; no scores or difficulty summaries read for generation. Fresh entropy and new domain. No unavailable historical heldout equality guarantee.','quality_selection':False,'exact_equality_only':True})
policy=read(ROOT/'original_draft.json');need(policy['new_data']['independent_sequences']==12 and policy['new_data']['items_per_sequence']==1000,'fixed horizon');need([x['independent_sequences'] for x in policy['families']]==[4,4,4],'fixed family denominators')
res=policy['resource_accounting']['reservations'];need(sum(x['CPU'] for x in res.values())==4977 and sum(x['wall'] for x in res.values())==3797,'closed reservation')
put(ROOT/'policy.json',policy)
for p in ROOT.glob('*.py'):ast.parse(p.read_text())
need("+'/instance/0'" in (ROOT/'driver.py').read_text() and "['canonical_text']" in (ROOT/'driver.py').read_text() and "['checker_status']=='passed'" in (ROOT/'guard.py').read_text(),'ABI static checks')
changes={n:''.join(difflib.unified_diff((A1/n).read_text().splitlines(True),(ROOT/n).read_text().splitlines(True),fromfile='A1/'+n,tofile='D1/'+n)) for n in ['common.py','driver.py','guard.py','dispatch.py','generate.py','analysis.py']}
put(ROOT/'source_delta.json',{'baselines':prior,'exact_A1_A2_method_registry_bytes':True,'exact_A1_runtime_bytes':True,'blocking_collectors_byte_identical':True,'diffs':changes})
put(ROOT/'administrative_preexecution_note.json',{'first_author_wrapper':'/usr/bin/time executable absent; shell exit127 before author source executed. No preparation/science claim, entropy draw or candidate execution consumed.','known_outcome':'Author script then invoked once using bash time keyword and completed; no unknown action or experiment retry.','extra_install':False,'tool_reads':'Initial short read/copy operations not individually CPU-metered; conservatively covered by static_admin_data20/20, not asserted zero.'})
names=sorted([p.name for p in ROOT.glob('*.py')]+['original_draft.json','MINIMAL_CHANGES.md','source_delta.json','methods.json','toy.json','exclusions.json','policy.json','administrative_preexecution_note.json']+[str(p.relative_to(ROOT)) for folder in ('frozen_runtime','source_evidence') for p in (ROOT/folder).rglob('*') if p.is_file()])
put(ROOT/'source_freeze.json',{'schema':'D1-source-method-analysis-policy-freeze-v1','files':{n:sha((ROOT/n).read_bytes()) for n in names},'candidate_evaluations':0,'research_entropy_draws':0,'original_runtime_files_verified':len(original_runtime['files']),'science_enabled':False})
put(ROOT/'setup_completion.json',{'status':'frozen_static_PASS','source_freeze_sha256':sha((ROOT/'source_freeze.json').read_bytes()),'self_CPU_at_emit':time.process_time(),'wall_at_emit':time.monotonic()-started,'candidate_execution':False,'source_compile':False,'ast_parse_only':True,'OS_CPU_limit':5,'OS_wall_alarm':8})
print('D1 static PASS; source/methods/family analysis/policy frozen; zero candidate calls or entropy draws.')
