"""Locked D1 results-only descriptive analysis; no candidate evaluation."""
from fractions import Fraction
from common import ROOT,METHODS,read,need,sha,digest
def value(f):return {'numerator':f.numerator,'denominator':f.denominator,'decimal':float(f)}
def proxies(items,result):
 remaining=[100]*len(items);hist=[0]*101;opened=0;r1=0;voluntary=0;forced=0
 for item,b in zip(items,result['assignment']):
  before=remaining[b];need(before>=item,'replay feasibility');new=before==100
  if new:
   need(b==opened,'stable original-index opening');opened+=1
   if sum(hist[item:100]):voluntary+=1
   else:forced+=1
  else:hist[before]-=1
  after=before-item;hist[after]+=1;remaining[b]=after;r1+=int(after==1)
 need(remaining==result['remaining'] and opened==result['used_bins'],'exact saved replay')
 return {'r1_placements':r1,'final_r1_bins':hist[1],'final_capacity_r11_45':sum(r*hist[r] for r in range(11,46)),'full_bins':hist[0],'voluntary_openings':voluntary,'forced_openings':forced}
def analyze():
 seal=read(ROOT/'data_seal.json');refs=read(ROOT/'raw_terminal_freeze.json');policy=read(ROOT/'policy.json');records=[];scores={};rows={};families={}
 for x in seal['packs']:
  aid=x['action_id'];i=x['sequence_index'];mid=x['method'];p=ROOT/'results'/(aid+'.json')
  row={'sequence_index':i,'family':x['family'],'family_sequence_index':x['family_sequence_index'],'method':mid,'status':'missing','used_bins':None,'F':None,'mechanism':None}
  if p.exists():
   need(refs[p.name]==sha(p.read_bytes()),'raw terminal sealed');t=read(p);claim=read(ROOT/'claims'/(aid+'.json'))
   need(t['claim_sha256']==digest(claim),'terminal claim')
   if t['status']=='passed':
    y=t['payload'];need(y['input_sha256']==x['input_sha256'] and y['code_sha256']==x['code_sha256'] and y['method']==mid and y['sequence_index']==i,'exact source/input/action')
    need(y['outcome']=='ok' and y['checker']['checker_status']=='passed','checked result')
    raw=(ROOT/x['relative_file']).read_bytes();need(sha(raw)==x['file_sha256'],'sealed item bytes');items=__import__('json').loads(raw)['items'];lb=(sum(items)+99)//100;bins=y['checker']['used_bins']
    need(y['L1']==lb and lb<=bins<=1000,'valid integer counts');scores[i,mid]=Fraction(lb,bins)
    row.update(status='ok',used_bins=bins,F=value(scores[i,mid]),L1=lb,mechanism=proxies(items,y['original_pack_report']['result']))
   else:row['status']=t['status']
  records.append(row);rows[i,mid]=row
 need(len(records)==36 and len(rows)==36,'all fixed slots retained')
 import numpy as np
 indices=np.random.Generator(np.random.PCG64(20261008)).integers(0,4,size=(20000,4))
 for fi,family in enumerate(policy['families']):
  ids=list(range(fi*4,fi*4+4));coverage={};contrasts={}
  for mid in METHODS:coverage[mid]={'complete':sum((i,mid) in scores for i in ids),'denominator':4,'failures':[rows[i,mid]['status'] for i in ids if rows[i,mid]['status']!='ok']}
  for lhs,other in [('EOH_nearfit_one','EOH_original'),('EOH_nearfit_one','published_EoH'),('EOH_original','published_EoH')]:
   valid=[i for i in ids if (i,lhs) in scores and (i,other) in scores]
   paired=[{'sequence_index':i,'family_sequence_index':i%4,'bins_lhs_minus_comparator':rows[i,lhs]['used_bins']-rows[i,other]['used_bins'] if i in valid else None,'F_lhs_minus_comparator':value(scores[i,lhs]-scores[i,other]) if i in valid else None} for i in ids]
   item={'complete_pairs':len(valid),'denominator':4,'paired_sequence_differences':paired,'full4_result':None}
   if len(valid)==4:
    diffs=[scores[i,lhs]-scores[i,other] for i in ids];bins=[rows[i,lhs]['used_bins']-rows[i,other]['used_bins'] for i in ids];vals=np.asarray([float(d) for d in diffs])[indices].mean(axis=1)
    item['full4_result']={'mean_paired_F_difference':value(sum(diffs,Fraction())/4),'paired_F_differences':[value(d) for d in diffs],'paired_bins_lhs_minus_comparator':bins,'mean_paired_bin_difference':value(Fraction(sum(bins),4)),'total_bin_savings':-sum(bins),'wins_ties_losses':[sum(d>0 for d in diffs),sum(d==0 for d in diffs),sum(d<0 for d in diffs)],'descriptive_95_percentile_bootstrap':np.quantile(vals,[.025,.975],method='linear').tolist(),'resamples':20000,'analysis_seed':20261008,'bootstrap_only_descriptive':True}
   contrasts[lhs+'_minus_'+other]=item
  families[family['id']]={'domain_status':family['domain_status'],'sequence_indices':ids,'independent_sequences':4,'denominator':4,'coverage':coverage,'contrasts':contrasts}
 return {'schema':'D1-predisclosed-three-distribution-screen-v1','independent_sequences':12,'items_per_sequence':1000,'records':records,'families':families,'primary_in_each_family':'EOH_nearfit_one_minus_EOH_original','each_family_full4_null_unless_all4_complete':True,'pooled_mean':None,'pooling_for_claims_prohibited':True,'p_value':None,'confirmatory_superiority_claim':False,'general_robustness_claim':False,'SOTA_claim':False,'original_EOH_domain':'shape3/scale45 Weibull clip-round','OOD_negative_does_not_erase_original_domain_conclusion':True,'missing_imputation':None,'data_seal_sha256':sha((ROOT/'data_seal.json').read_bytes()),'analysis_source_sha256':sha(__import__('pathlib').Path(__file__).read_bytes())}
