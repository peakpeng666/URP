#!/usr/bin/env python3
"""Read-only base+delta integrity and exact math; no project imports/execution."""
from pathlib import Path
from fractions import Fraction
import argparse,hashlib,json
ap=argparse.ArgumentParser();ap.add_argument('--base',required=True);args=ap.parse_args();R=Path(__file__).resolve().parent;BASE=Path(args.base)
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for rel,ref in load(R/'FILE_MANIFEST.json')['files'].items():assert (R/rel).stat().st_size==ref['bytes'] and sha(R/rel)==ref['sha256'],rel
ref=load(R/'BASE_REFERENCE.json');assert sha(BASE/'FILE_MANIFEST.json')==ref['base_manifest_sha256'];assert (BASE/'FILE_MANIFEST.json').read_bytes()==(R/'BASE_FILE_MANIFEST.json').read_bytes()
for rel,expected in load(BASE/'FILE_MANIFEST.json')['files'].items():assert (BASE/rel).stat().st_size==expected['bytes'] and sha(BASE/rel)==expected['sha256'],rel
state={}
for rel,expected in load(R/'CUMULATIVE_STATE_FILE_HASHES.json')['files'].items():
 p=R/'state_delta'/rel
 if not p.exists():p=BASE/'project/public_execution'/rel
 assert p.stat().st_size==expected['bytes'] and sha(p)==expected['sha256'],rel
 state[rel]=p
rows=[load(p) for rel,p in state.items() if rel.startswith('results/')];assert sorted(x['record']['position'] for x in rows)==list(range(1,26))
for row in rows:
 if row['fitness']:
  assert len(row['scores'])==5 and all(x['outcome']=='ok' and x['evidence']['checker_status']=='passed' for x in row['scores'])
  f=sum((Fraction(x['L1'],x['used_bins']) for x in row['scores']),Fraction())/5
  assert row['fitness']['numerator']==f.numerator and row['fitness']['denominator']==f.denominator
 else:assert row['evaluation_status']!='scored'
summary=load(R/'SUMMARY.json');reservations=[load(p) for rel,p in state.items() if rel.startswith('reservations/')]
assert sum(x['cpu_seconds'] for x in reservations)==summary['cumulative_usage']['reserved_cpu_seconds'];assert sum(x['shared_wall_seconds'] for x in reservations)==summary['cumulative_usage']['reserved_shared_wall_seconds']
bundles=[load(p) for rel,p in state.items() if rel.startswith('slots/') and rel.endswith('/bundle.json')];cpu=0;packs=0
for b in bundles:
 cpu+=b['admission']['worker']['cpu_seconds']
 for s in b['scores']:packs+=1;cpu+=s['evidence']['worker']['cpu_seconds']+s['evidence']['supervisor']['actual_supervisor_cpu_seconds']
assert len(bundles)==summary['cumulative_usage']['admissions'] and packs==summary['cumulative_usage']['instance_packs'];assert abs(cpu-summary['cumulative_usage']['numerical_cpu_seconds_no_double_count'])<1e-6
for arm,x in summary['arms'].items():
 xs=[r for r in rows if r['record']['arm']==arm];assert len(xs)==x['generation_denominator_prefix'];assert sum(r['evaluation_status']=='scored' for r in xs)==x['complete_fitness'];assert sum(r['evaluation_status']=='generation_failure' for r in xs)==x['generation_failures']
print(json.dumps({'status':'PASS_readonly_delta_union_exact_fitness_and_budget','rows':25,'admissions':len(bundles),'packs':packs,'candidate_executions':0,'heldout_reads':0}))
