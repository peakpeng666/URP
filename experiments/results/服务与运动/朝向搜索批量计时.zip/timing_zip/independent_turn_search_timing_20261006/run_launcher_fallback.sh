#!/bin/bash
set -u
cd "$(dirname "$0")"
if ! (set -o noclobber; printf '{"launch":"first_python_launch_after_prepython_wrapper_failure"}\n' > PYTHON_LAUNCH_ATTEMPT.json) 2>/dev/null; then echo 'Python launch already attempted'; exit 73; fi
export PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0
TIMEFORMAT='wall_seconds=%R user_cpu_seconds=%U system_cpu_seconds=%S'
{ time timeout --signal=TERM --kill-after=2 800 python3 -B src/run_timing.py > raw/execution.log 2>&1; } 2>checks/launcher_resource_usage.txt
code=$?
printf '{"exit_code":%d}\n' "$code" > PYTHON_LAUNCH_EXIT.json
cat raw/execution.log
exit "$code"
