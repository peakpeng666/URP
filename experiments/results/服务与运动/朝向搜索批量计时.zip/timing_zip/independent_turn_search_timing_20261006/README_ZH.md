# 朝向搜索批量计时补证

先读 REPORT_ZH.md。

本次是全72旧问题的新真实搜索计时，不是重算旧时间表。正式1296批、227196次搜索，另216次热身、3456次校准；全部230868次逐路径校验通过。wall及进程CPU正式零值均为0。总体wall约少25.50%，但λ=0约慢9.44%；不可据此宣称普适加速。

初始外围启动器在Python前因缺/usr/bin/time失败；外围改用bash内置time后，唯一数值进程exit0。原冻结代码/输入、旧实验全目录均未改。

完整证据：PROTOCOL.md、两份FREEZE、raw/、checks/、src/、inputs/及provenance/。MANIFEST.json列出文件哈希。独立审计另交。

保留一次性启动标记，不在此交付目录重跑。若日后明确复现，应创建新空目录、保留来源哈希，复制代码/协议/输入，并让原实验只读目录位于其同级的 independent_turn_aware_search_20261006（可从provenance/original_experiment原样恢复）。当前runner冻结路径以此同级来源为准。重现不是本次已做工作。
