#!/usr/bin/env python3
import resource
resource.setrlimit(resource.RLIMIT_CPU, (110, 110))
resource.setrlimit(resource.RLIMIT_AS, (1024**3, 1024**3))
import signal
signal.alarm(780)
import time, json, hashlib, datetime, sys, os, platform, itertools, math, statistics, csv, traceback, gc
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
OLD = ROOT.parent / 'independent_turn_aware_search_20261006'
sys.path.insert(0, str(ROOT/'src'))
from search_core import search, ALGORITHMS
from reference import reverse_dijkstra, encode_state, verify_path
T0 = time.perf_counter()
START = datetime.datetime.now(datetime.timezone.utc).isoformat()
COUNTS = dict(oracles=0, warmup_searches=0, calibration_searches=0, formal_searches=0, path_checks=0, batch_checks=0)
PERMS = list(itertools.permutations(ALGORITHMS))

def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def canonical(obj): return json.dumps(obj, sort_keys=True, separators=(',',':'), ensure_ascii=False, allow_nan=False)
def objsha(obj): return hashlib.sha256(canonical(obj).encode()).hexdigest()
def dump(name, obj): (ROOT/name).write_text(json.dumps(obj, indent=2, ensure_ascii=False, allow_nan=False)+'\n')
def load(name): return json.loads((ROOT/name).read_text())
def tree(root): return {str(p.relative_to(root)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(root.rglob('*')) if p.is_file()}
def check_freeze(freeze):
    for name, h in freeze['files'].items(): assert sha(ROOT/name)==h['sha256'], name

def safety():
    if time.process_time() >=100 or time.perf_counter()-T0>=750: raise RuntimeError('PREDECLARED_SAFETY_STOP')

def measure(m,c,algorithm,n):
    results=[None]*n
    rows,start,goal,weight=m['rows'],m['start'],m['goal'],c['weight']
    w0=time.perf_counter_ns(); p0=time.process_time_ns(); t0=time.thread_time_ns()
    for j in range(n): results[j]=search(rows,start,goal,weight,algorithm)
    t1=time.thread_time_ns(); p1=time.process_time_ns(); w1=time.perf_counter_ns()
    return results,dict(wall_ns=w1-w0,cpu_ns=p1-p0,thread_cpu_ns=t1-t0)

def check_results(m,c,algorithm,results,exact,baseline,phase):
    for result in results:
        verify_path(m['rows'],m['start'],m['goal'],c['weight'],result,exact)
        assert result==baseline, (c['case_id'],algorithm,'nondeterminism')
        assert result['reexpansions']==0
        COUNTS['path_checks']+=1
    COUNTS[phase+'_searches']+=len(results)
    COUNTS['batch_checks']+=1

def write_line(f,obj): f.write(canonical(obj)+'\n'); f.flush()
def csvwrite(name,rows):
    with (ROOT/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def summary(formal,baselines,cases,maps):
    keys=['wall_ns','cpu_ns','thread_cpu_ns']
    pairs=[]; allmed={}
    for c in cases:
        cid=c['case_id']; m=maps[c['map_id']]
        rec=dict(**c,n=m['n'],obstacle_probability=m['obstacle_probability'],reachable=baselines[(cid,'dijkstra')]['reachable'])
        for a in ALGORITHMS:
            rr=[r for r in formal if r['case_id']==cid and r['algorithm']==a]
            assert rr
            for k in keys:
                vals=[r[k]/r['repetitions'] for r in rr]
                rec[a+'_'+k+'_median']=statistics.median(vals)
                rec[a+'_'+k+'_min']=min(vals);rec[a+'_'+k+'_max']=max(vals)
            rec[a+'_expansions']=baselines[(cid,a)]['expansions']
            rec[a+'_heap_pushes']=baselines[(cid,a)]['heap_pushes']
        rec['turn_wall_ratio_to_manhattan']=rec['astar_turn_wall_ns_median']/rec['astar_manhattan_wall_ns_median']
        rec['turn_cpu_ratio_to_manhattan']=(rec['astar_turn_cpu_ns_median']/rec['astar_manhattan_cpu_ns_median'] if rec['astar_manhattan_cpu_ns_median']>0 and rec['astar_turn_cpu_ns_median']>0 else None)
        rec['fewer_expansions_but_wall_slower']=rec['astar_turn_expansions']<rec['astar_manhattan_expansions'] and rec['turn_wall_ratio_to_manhattan']>1
        pairs.append(rec)
    groups=[]
    criteria=[('all','all',lambda p:True)] + [('weight',v,lambda p,v=v:p['weight']==v) for v in [0,2,8]] + [('n',v,lambda p,v=v:p['n']==v) for v in [16,32,48]] + [('obstacle_probability',v,lambda p,v=v:p['obstacle_probability']==v) for v in [0.1,0.25]]
    for key,value,pred in criteria:
        pp=[p for p in pairs if pred(p)];totals={}
        for a in ALGORITHMS:
            totals[a]={k:sum(p[a+'_'+k+'_median'] for p in pp) for k in keys}
            totals[a].update(expansions=sum(p[a+'_expansions'] for p in pp),heap_pushes=sum(p[a+'_heap_pushes'] for p in pp))
        reduction={k:1-totals['astar_turn'][k]/totals['astar_manhattan'][k] if totals['astar_manhattan'][k]>0 else None for k in keys+['expansions','heap_pushes']}
        groups.append(dict(group_by=key,value=value,cases=len(pp),totals=totals,turn_reduction_vs_manhattan=reduction,median_case_wall_ratio=statistics.median(p['turn_wall_ratio_to_manhattan'] for p in pp),wall_win_tie_loss=[sum(p['turn_wall_ratio_to_manhattan']<1 for p in pp),sum(p['turn_wall_ratio_to_manhattan']==1 for p in pp),sum(p['turn_wall_ratio_to_manhattan']>1 for p in pp)],fewer_expansions_but_wall_slower=sum(p['fewer_expansions_but_wall_slower'] for p in pp)))
    result=dict(created_utc=utc(),cases=72,maps=24,formal_batches=len(formal),formal_searches=sum(r['repetitions'] for r in formal),formal_rounds=len(formal)//216,zero_time_batches={k:sum(r[k]==0 for r in formal) for k in keys},batch_ranges_ns={k:[min(r[k] for r in formal),max(r[k] for r in formal)] for k in keys},groups=groups,counts=COUNTS,all_paths_verified=True,unreachable_cases=sum(not p['reachable'] for p in pairs),fewer_expansions_but_wall_slower_cases=[p['case_id'] for p in pairs if p['fewer_expansions_but_wall_slower']],interpretation='Descriptive one-session shared-cloud measurement. No significance or universal speed claim.')
    dump('raw/summary.json',result);dump('raw/paired_cases.json',pairs);csvwrite('raw/paired_cases.csv',pairs);csvwrite('raw/formal_batches.csv',formal)
    return result

def run():
    freeze=load('PRE_RUN_FREEZE.json');check_freeze(freeze)
    original=load('checks/original_tree_snapshot.json');assert tree(OLD)==original['files']
    maps_list=load('inputs/maps.json');maps={m['map_id']:m for m in maps_list};cases=load('inputs/cases.json');assert len(cases)==72 and len(maps)==24
    old_oracles={c['case_id']:c for c in json.loads((OLD/'outputs/main_oracles.json').read_text())}
    oldruns=[json.loads(s) for s in (OLD/'outputs/main_runs.jsonl').read_text().splitlines()]
    oldbase={(r['case_id'],r['algorithm']):r for r in oldruns if r['repeat']==0}
    dump('checks/environment.json',dict(python=sys.version,platform=platform.platform(),pid=os.getpid(),start_utc=START,clock_info={k:vars(time.get_clock_info(k)) for k in ['perf_counter','process_time','thread_time']},rlimit_cpu=resource.getrlimit(resource.RLIMIT_CPU),rlimit_as=resource.getrlimit(resource.RLIMIT_AS),gc_enabled=gc.isenabled(),gc_threshold=gc.get_threshold(),cpu_affinity=sorted(os.sched_getaffinity(0)),pythonhashseed=os.environ.get('PYTHONHASHSEED'),numerical_processes=1,model_calls=0,network_calls=0))
    baselines={};oracle_values={};oraclerows=[];calibration=[];warmup=[];reps={};estimates={};canonical_rows=[]
    with (ROOT/'raw/oracles.jsonl').open('w') as of, (ROOT/'raw/warmup.jsonl').open('w') as wf, (ROOT/'raw/calibration.jsonl').open('w') as cf:
        for i,c in enumerate(cases):
            safety();m=maps[c['map_id']];cid=c['case_id']
            p0=time.process_time_ns();w0=time.perf_counter_ns()
            distances,edges,info=reverse_dijkstra(m['rows'],m['goal'],c['weight'])
            exact=distances.get(encode_state(m['start']));assert exact==old_oracles[cid]['exact_cost'];COUNTS['oracles']+=1;oracle_values[cid]=exact
            oracle_row=dict(**c,exact_cost=exact,**info,cpu_ns=time.process_time_ns()-p0,wall_ns=time.perf_counter_ns()-w0)
            write_line(of,oracle_row);oraclerows.append(oracle_row);del distances,edges
            for pos,a in enumerate(PERMS[i%6]):
                results,times=measure(m,c,a,1);baseline=results[0]
                # Verify every deterministic output field equals the existing experiment.
                for k,v in baseline.items(): assert json.loads(canonical(v))==oldbase[(cid,a)][k],(cid,a,k)
                baselines[(cid,a)]=baseline;check_results(m,c,a,results,exact,baseline,'warmup')
                row=dict(**c,algorithm=a,phase='warmup',repetitions=1,order=pos,**times,path_checks=1,result_sha256=objsha(baseline));write_line(wf,row);warmup.append(row)
                canonical_rows.append(dict(**c,algorithm=a,result_sha256=objsha(baseline),result=baseline));del results
            for cr in range(2):
                for pos,a in enumerate(PERMS[(i+cr)%6]):
                    safety();results,times=measure(m,c,a,8);check_results(m,c,a,results,exact,baselines[(cid,a)],'calibration')
                    row=dict(**c,algorithm=a,phase='calibration',calibration_round=cr,repetitions=8,order=pos,**times,path_checks=8,result_sha256=objsha(baselines[(cid,a)]));write_line(cf,row);calibration.append(row);del results
            for a in ALGORITHMS:
                tt=min(r['wall_ns']/8 for r in calibration if r['case_id']==cid and r['algorithm']==a)
                assert tt>0
                n=min(20000,max(4,math.ceil(40_000_000/tt)))
                reps[(cid,a)]=n;estimates[(cid,a)]=tt
            if (i+1)%12==0:print('CALIBRATION',i+1,'cpu',time.process_time(),flush=True)
    dump('raw/canonical_results.json',canonical_rows)
    predicted_round_seconds=sum(reps[k]*estimates[k] for k in reps)/1e9
    current_cpu=time.process_time()
    rounds=6 if current_cpu+1.5*6*predicted_round_seconds+5<=100 else (3 if current_cpu+1.5*3*predicted_round_seconds+5<=100 else 0)
    plan=[dict(case_id=k[0],algorithm=k[1],repetitions=reps[k],calibration_ns_per_search=estimates[k]) for k in reps]
    calfreeze=dict(frozen_utc=utc(),pre_run_freeze_sha256=sha(ROOT/'PRE_RUN_FREEZE.json'),calibration_sha256=sha(ROOT/'raw/calibration.jsonl'),canonical_results_sha256=sha(ROOT/'raw/canonical_results.json'),selected_rounds=rounds,estimated_round_seconds=predicted_round_seconds,cpu_seconds_at_freeze=current_cpu,plan=plan)
    dump('CALIBRATION_FREEZE.json',calfreeze);calhash=sha(ROOT/'CALIBRATION_FREEZE.json');check_freeze(freeze)
    print('CALIBRATION_FROZEN',rounds,'estimated_round_seconds',predicted_round_seconds,'cpu',current_cpu,flush=True)
    assert rounds>0,'Budget forecast prohibits complete 3-round block'
    formal=[];deviation=[]
    with (ROOT/'raw/formal_batches.jsonl').open('w') as ff:
        for r in range(rounds):
            if r==3 and time.process_time()+1.5*3*predicted_round_seconds+5>100:
                deviation.append('Second 3-round block omitted by frozen budget forecast.');break
            indexes=list(range(72));shift=(12*r)%72;indexes=indexes[shift:]+indexes[:shift]
            if r%2: indexes.reverse()
            for position,i in enumerate(indexes):
                c=cases[i];cid=c['case_id'];m=maps[c['map_id']]
                for apos,a in enumerate(PERMS[(i+r)%6]):
                    safety();n=reps[(cid,a)];results,times=measure(m,c,a,n)
                    check_results(m,c,a,results,oracle_values[cid],baselines[(cid,a)],'formal')
                    row=dict(batch_id=len(formal),round=r,case_index=i,case_position=position,algorithm_position=apos,**c,n=m['n'],obstacle_probability=m['obstacle_probability'],algorithm=a,repetitions=n,**times,exact_cost=oracle_values[cid],path_checks=n,all_results_identical=True,result_sha256=objsha(baselines[(cid,a)]),expansions_per_search=baselines[(cid,a)]['expansions'],heap_pushes_per_search=baselines[(cid,a)]['heap_pushes'])
                    write_line(ff,row);formal.append(row);del results
            print('FORMAL_ROUND_COMPLETE',r+1,'batches',len(formal),'searches',COUNTS['formal_searches'],'cpu',time.process_time(),flush=True)
    assert len(formal) in (648,1296)
    assert COUNTS['path_checks']==COUNTS['warmup_searches']+COUNTS['calibration_searches']+COUNTS['formal_searches']
    check_freeze(freeze);assert sha(ROOT/'CALIBRATION_FREEZE.json')==calhash;assert tree(OLD)==original['files']
    result=summary(formal,baselines,cases,maps)
    dump('checks/post_run_checks.json',dict(completed_utc=utc(),passed=True,counts=COUNTS,all_costs_match_recomputed_independent_oracle=True,all_paths_verified_individually=True,all_deterministic_results_match_old_experiment=True,all_repeated_results_identical=True,original_directory_unchanged=True,pre_run_freeze_unchanged=True,calibration_freeze_unchanged=True,planned_rounds=rounds,completed_rounds=len(formal)//216,deviations=deviation))
    usage=resource.getrusage(resource.RUSAGE_SELF)
    dump('checks/resource_usage.json',dict(status='completed',measured_at_utc=utc(),user_cpu_seconds=usage.ru_utime,system_cpu_seconds=usage.ru_stime,process_cpu_seconds=usage.ru_utime+usage.ru_stime,process_time_seconds=time.process_time(),wall_seconds=time.perf_counter()-T0,max_rss_kib=usage.ru_maxrss,cpu_hard_limit_seconds=110,task_author_cpu_budget_seconds=120,wall_alarm_seconds=780,counts=COUNTS,note='Measured after numerical work, individual validation, summary and checks; before this resource-file write. Launcher supplies terminal usage.'))
    print('COMPLETE',canonical(result['groups'][:4]),flush=True)

if __name__=='__main__':
    try:run()
    except BaseException as exc:
        dump('checks/FAILURE.json',dict(at_utc=utc(),error_type=type(exc).__name__,error=str(exc),traceback=traceback.format_exc(),counts=COUNTS,process_cpu_seconds=time.process_time(),wall_seconds=time.perf_counter()-T0))
        traceback.print_exc();raise
