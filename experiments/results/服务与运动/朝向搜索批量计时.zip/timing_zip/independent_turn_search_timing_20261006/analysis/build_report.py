import json,statistics,datetime,hashlib,sys
from pathlib import Path
R=Path(__file__).resolve().parents[1]
s=json.loads((R/'raw/summary.json').read_text());p=json.loads((R/'raw/paired_cases.json').read_text());b=[json.loads(x) for x in (R/'raw/formal_batches.jsonl').read_text().splitlines()];cf=json.loads((R/'CALIBRATION_FREEZE.json').read_text());res=json.loads((R/'checks/resource_usage.json').read_text())
clock_ratios={k:[x[k]/x['wall_ns'] for x in b] for k in ['cpu_ns','thread_cpu_ns']}
clock_diag={k:dict(median=statistics.median(v),minimum=min(v),maximum=max(v)) for k,v in clock_ratios.items()}
(R/'raw/clock_comparison_diagnostic.json').write_text(json.dumps(clock_diag,indent=2)+'\n')
round_groups=[]
for w in ['all',0,2,8]:
 for rnd in range(6):
  row=dict(weight=w,round=rnd)
  for k in ['wall_ns','cpu_ns','thread_cpu_ns']:
   tt={a:sum(x[k]/x['repetitions'] for x in b if x['round']==rnd and x['algorithm']==a and (w=='all' or x['weight']==w)) for a in ['dijkstra','astar_manhattan','astar_turn']}
   row[k+'_sum_per_search']=tt;row[k+'_turn_manhattan_ratio']=tt['astar_turn']/tt['astar_manhattan']
  round_groups.append(row)
(R/'raw/round_group_sensitivity.json').write_text(json.dumps(round_groups,ensure_ascii=False,indent=2)+'\n')
reversals=[x for x in p if x['fewer_expansions_but_wall_slower']]
G=s['groups'];allg=G[0];k='wall_ns';r=allg['turn_reduction_vs_manhattan']
lines=['# 朝向搜索批量计时补证：全72问题的新实跑','',
'## 结论先读','',
f"在本次共享云环境、固定Python实现和预注册批量协议下，A* Turn相对A* Manhattan的“各问题每次搜索批均值中位数之和”wall少{100*r['wall_ns']:.2f}%，进程CPU少{100*r['cpu_ns']:.2f}%。wall是主要性能证据；25.74%仅为本协议整个进程计时指标，不是独立校准的搜索内核净CPU。正式1296批无CPU或wall零值，补上了旧实验短搜索CPU大量为0的缺口。",'',
'这不是普适加速结论。λ=0时扩展完全相同，A* Turn的wall反而多9.44%，24/24问题的中位批均值都更慢。λ=2有1个问题扩展从7降至6，但中位wall多2.70%；其六批范围重叠，不能据此断言稳定退化。计数减少并不自动变成运行加速。','',
'## 新实跑与旧证据的区分','',
'- 原72问题/24地图、三算法内核和独立参考代码原样复用，不是新地图或新算法泛化实验。尺寸16/32/48、障碍率0.10/0.25、λ=0/2/8、四固定种子全覆盖；3个不可达问题保留。',
'- 新实算72次独立反向图Dijkstra参考；成本逐项等于旧参考。每次路径逐步检查通行、相邻、朝向和独立重算成本。',
f"- 新搜索共{s['counts']['path_checks']:,}次：216次热身、3456次校准、{s['formal_searches']:,}次正式搜索。全部230,868次结果逐次校验，并与该案例算法的完整代表路径及确定性计数相同；与旧实验对应结果也相同。", 
'- 1296条正式原始批记录含批次数、顺序、三种时钟、该批逐次校验数量和代表输出SHA256；216个完整代表输出含路径。重复路径相同，采用代表路径+逐次完整相等检查保存，不重复存230,868份相同路径。',
'- 原报告的693次搜索中483次CPU差值为0，原求解后的汇总代码exit1及只读恢复记录均保留在 provenance/original_experiment/；本次没有覆盖原证据。','',
'## 冻结、热身和计时边界','',
'- PRE_RUN_FREEZE.json在任何新搜索前冻结协议、代码、输入和旧目录快照；完成后复核哈希及旧目录全树未变。原输入/内核复制件同时与旧冻结清单一致。',
'- 每问题算法先热身1次，再做2批×8次校准。取两批wall/8的较小值t，N=ceil(40ms/t)，夹到[4,20000]。选N仅为获得可测批时长，不能用于挑胜负；实际N为4至1672。',
f"- CALIBRATION_FREEZE.json在正式阶段前固定全部N和6轮计划。校准时测得约{cf['estimated_round_seconds']:.3f}秒/轮；正式全部6轮完成，无预算退阶或补跑。", 
'- 案例顺序逐轮左移12个、奇数轮逆序；每案例遍历三算法全部6种排列，各算法在每个位置出现2次。批内N次只运行同一算法，所有轮N不变。',
'- perf_counter_ns记录wall，process_time_ns记录进程CPU，thread_time_ns为诊断。结果列表预分配在计时外，区间包含循环调用、完整search、返回路径重建和结果槽位赋值；参考计算、逐路径检查、序列化和结果释放在计时外。默认GC启用、未绑核、未减空循环。保留整批结果也会影响分配/缓存行为，结论仅适用于此协议。',
'- 每问题算法取6个“原始批时长/N”的中位数；组内再相加，相当于各问题各求解一次的汇总口径。不同算法N不同，不能把未归一化批时长直接相加比较。此汇总也不是某个真实生产请求的端到端延迟。','',
'## 核心结果','',
'下表wall和CPU单位为毫秒，均是各问题每次搜索的中位批均值之和。扩展为确定性每问题一次的合计。','',
'| λ | 算法 | 合计扩展 | wall ms | 进程CPU ms |',
'|---|---|---:|---:|---:|']
for g in G[:4]:
 for a in ['dijkstra','astar_manhattan','astar_turn']:
  t=g['totals'][a];lines.append(f"| {g['value']} | {a} | {t['expansions']} | {t['wall_ns']/1e6:.3f} | {t['cpu_ns']/1e6:.3f} |")
lines+=['','A* Turn相对Manhattan：','',
'| λ | wall节时率 | CPU节时率 | 扩展减少率 | wall较快/相同/较慢 |',
'|---|---:|---:|---:|---|']
for g in G[:4]:
 t=g['turn_reduction_vs_manhattan'];v=g['wall_win_tie_loss'];lines.append(f"| {g['value']} | {100*t['wall_ns']:.2f}% | {100*t['cpu_ns']:.2f}% | {100*t['expansions']:.2f}% | {v[0]}/{v[1]}/{v[2]} |")
lines+=['','正数表示节时，负数表示更慢。胜负只按观测中位数大小，无显著性阈值，不代表统计可靠性。尺寸和障碍率分组全部见 raw/summary.json。','',
'## 精度与例外','',
f"- 正式批wall范围{s['batch_ranges_ns']['wall_ns'][0]/1e6:.3f}–{s['batch_ranges_ns']['wall_ns'][1]/1e6:.3f}ms，进程CPU范围{s['batch_ranges_ns']['cpu_ns'][0]/1e6:.3f}–{s['batch_ranges_ns']['cpu_ns'][1]/1e6:.3f}ms。1296/1296批的三种时钟均大于0，无0值插补、删除或选择性复跑。时钟API标称1ns不意味着有效精度确为1ns。", 
'- 按每轮分别聚合归一化批时长，总体Turn/Manhattan wall比值为0.731–0.753，CPU比值为0.729–0.750；6轮方向一致。因此总体约25%的差异并非依赖一个零值或单一批次，但仍只是同一会话的描述性证据。',
'- 按轮λ=0 wall比值为1.007–1.103，CPU为1.000–1.099；该组首轮差异很小。正式主表用每案例六批中位数再汇总，与每轮先汇总后求比不同，不能混用口径。',
f"- 正式批进程CPU/wall比中位{clock_diag['cpu_ns']['median']:.5f}、最大{clock_diag['cpu_ns']['maximum']:.5f}；主线程CPU/wall比中位{clock_diag['thread_cpu_ns']['median']:.5f}。因此25.74%只能解释为整个进程时钟的协议指标，不能称为搜索内核净CPU或纳秒可靠性；CPU不为0并不证明时钟已独立校准。wall的多轮一致差异是更稳健的主要证据。",
'- 所有逐案例、逐算法六批min/median/max保存在 raw/paired_cases.csv。微小配对差异和重叠区间不能证明稳定速度胜负；CPU和线程CPU的差异也提醒计时器/调度开销不可忽略。',
'','扩展下降但中位wall变慢的唯一案例：','',
'| 案例 | Manhattan扩展→Turn扩展 | Manhattan中位wall μs | Turn中位wall μs | Manhattan六批范围 μs | Turn六批范围 μs |',
'|---|---:|---:|---:|---|---|']
for x in reversals:
 lines.append(f"| {x['case_id']} | {x['astar_manhattan_expansions']}→{x['astar_turn_expansions']} | {x['astar_manhattan_wall_ns_median']/1e3:.3f} | {x['astar_turn_wall_ns_median']/1e3:.3f} | {x['astar_manhattan_wall_ns_min']/1e3:.3f}–{x['astar_manhattan_wall_ns_max']/1e3:.3f} | {x['astar_turn_wall_ns_min']/1e3:.3f}–{x['astar_turn_wall_ns_max']/1e3:.3f} |")
lines+=['','该例只从7次扩展省到6次，额外启发函数计算/分配可能抵消收益；这是基于实现的解释而非独立剖析实验。两组范围重叠，应称“观测中位数更慢”而不是“已证明稳定更慢”。','',
'## 执行、偏差和成本','',
'- 初始外层启动器因云端不存在/usr/bin/time而在调用Python前exit127，零次求解。保留LAUNCH_ATTEMPT.json、LAUNCH_EXIT.json、LAUNCHER_AMENDMENT.json；改用bash内置time外围记账，未改冻结求解代码/输入/协议、未扩限，首次且唯一Python求解exit0。不能写成外层启动一遍无故障。',
f"- 数值进程开始于{json.loads((R/'checks/environment.json').read_text())['start_utc']}，资源快照于{res['measured_at_utc']}。终端实测wall 64.419秒、user CPU64.310秒、system CPU0.097秒，总CPU64.407秒；内存高水位{res['max_rss_kib']}KiB。内部资源快照CPU{res['process_cpu_seconds']:.6f}秒与终端末尾计量边界不同。", 
'- 进程硬限110秒CPU/780秒wall/1GiB，100秒CPU预定主动停止以保全；任务作者CPU预算120秒，留10秒给准备及交付。数值运行含独立参考、校准、全部逐路径验证及汇总；报告生成和打包另行记账；早期源文件阅读/准备命令未逐项计CPU，因此64.407秒是数值进程实测，不冒充全任务精确总CPU。没有把预算上限当实际消耗。',
'- 新模型API调用0，网络调用0、依赖安装0；实验脚本未产生模型API token请求。本次对话、云计算和订阅的实际账单金额此环境无法计量，不能声称计算完全免费。','',
'## 适用范围与后续决策','',
'结果支持：在这批含正转向惩罚的合成四邻接离散问题上，该转向下界在当前Python实现中可同时降低扩展和本次运行时间；λ=0没有信息增益时，它的计算开销反而可见。默认启用时应关注λ=0的多余计算，但本次不改代码、不引入优化变体。',
'只有24张合成地图/4个种子，同图跨λ相关；六批是技术重复，不是432个独立问题。没有跨会话、跨机器、真实田间数据或车辆动力学约束，因此不宣称统计显著、普适加速、实车实时性或新算法贡献。若后续论文需要更强性能主张，应另行预注册多会话/机器及更大地图的测试；这不是本次已完成结果。','',
'## 文件导航','',
'- PROTOCOL.md、PRE_RUN_FREEZE.json、CALIBRATION_FREEZE.json：预定规则和两阶段冻结。',
'- src/、inputs/：原样内核/参考、真实新实跑驱动与原72问题。',
'- raw/formal_batches.jsonl/csv：1296正式批；warmup.jsonl、calibration.jsonl记录额外搜索；oracles.jsonl为72个新参考。',
'- raw/canonical_results.json：216个完整路径/确定性计数；raw/summary.json、paired_cases.csv/json、round_group_sensitivity.json为派生结果；clock_comparison_diagnostic.json量化三种时钟差异。',
'- checks/：环境、旧目录全树快照、正确性、冻结复核与资源。',
'- provenance/original_experiment/：旧实验完整原样证据，包括原CPU不可用和exit1恢复事实。',
'- analysis/build_report.py：仅读取本次原始与派生数据的中文报告生成器，无求解调用。',
'- MANIFEST.json：全交付哈希；独立审计单独提供，不在作者报告中伪称已经审计通过。','']
(R/'REPORT_ZH.md').write_text('\n'.join(lines))
(R/'README_ZH.md').write_text('''# 朝向搜索批量计时补证\n\n先读 REPORT_ZH.md。\n\n本次是全72旧问题的新真实搜索计时，不是重算旧时间表。正式1296批、227196次搜索，另216次热身、3456次校准；全部230868次逐路径校验通过。wall及进程CPU正式零值均为0。总体wall约少25.50%，但λ=0约慢9.44%；不可据此宣称普适加速。\n\n初始外围启动器在Python前因缺/usr/bin/time失败；外围改用bash内置time后，唯一数值进程exit0。原冻结代码/输入、旧实验全目录均未改。\n\n完整证据：PROTOCOL.md、两份FREEZE、raw/、checks/、src/、inputs/及provenance/。MANIFEST.json列出文件哈希。独立审计另交。\n\n保留一次性启动标记，不在此交付目录重跑。若日后明确复现，应创建新空目录、保留来源哈希，复制代码/协议/输入，并让原实验只读目录位于其同级的 independent_turn_aware_search_20261006（可从provenance/original_experiment原样恢复）。当前runner冻结路径以此同级来源为准。重现不是本次已做工作。\n''')
print('REPORT_WRITTEN',len(lines),'lines')
