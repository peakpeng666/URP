# 朝向状态搜索实验交付

先读 REPORT_ZH.md，再读 PROTOCOL.md 与 outputs/summary.json。

状态：所有693次被测搜索、90次独立参考均实际执行，最优代价与路径检查通过。正式进程在最后的CPU比率汇总时失败（exit 1）；完整原始数据保留，只读后处理恢复了报告（exit 0），没有补跑实验。请勿把这一状态写成全流程无故障成功。

性能结论以确定性扩展/入堆为主；483/693个逐次CPU差值为0，弃用CPU相对速度结论。wall时长仅作为本次共享云环境描述。

主要文件：
- REPORT_ZH.md：中文短报告。
- PROTOCOL.md、PRE_RUN_FREEZE.json：冻结协议、输入/源码SHA256。
- outputs/results.json：全部搜索路径、成本、计数、原始计时及参考结果。
- outputs/main_runs.csv：648次主搜索；boundary_runs.csv：45次边界。
- checks/：预检查、逐次执行记账、正确性检查、失败日志和终端资源计量。
- recovery/：不调用求解器的只读后处理源码、偏差说明与独立资源证据。
- MANIFEST.json：除自身以外全部交付文件的大小和SHA256。

这里没有真实田间地图、车辆动力学、模型调用、原132/heldout数据或旧实验改动。外部独立复核可能作为单独附件交付，不伪称已包含在此版本。

复现说明：现有目录带一次性启动标记，run_limited.sh会拒绝重复执行，避免覆盖证据。若以后明确决定复现，应在全新空目录只复制PROTOCOL.md、run_limited.sh和src/，建立inputs/outputs/checks/空目录，再启动；旧启动标记、输入、日志和结果不得覆盖。该源码可能在同样的CPU计时读数下复现汇总失败，届时可在保留所有证据后使用recovery/postprocess_existing.py。以上只是复现说明，本次交付没有进行额外复现运行。
