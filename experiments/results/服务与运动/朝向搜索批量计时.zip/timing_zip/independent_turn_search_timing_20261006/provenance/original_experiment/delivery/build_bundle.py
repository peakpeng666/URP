"""Archive existing artifacts only. No numerical experiment execution."""
from pathlib import Path
import datetime, hashlib, json, zipfile
root=Path(__file__).resolve().parents[1]
output=root.parent/(root.name+"_SOLVER_COMPLETE_REPORT_RECOVERED.zip")
files=sorted(p for p in root.rglob("*") if p.is_file() and p.name!="MANIFEST.json")
manifest={"generated_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),
          "status":"solver_complete_report_recovered", "file_count":len(files),
          "files":{str(p.relative_to(root)):{"bytes":p.stat().st_size,
                   "sha256":hashlib.sha256(p.read_bytes()).hexdigest()} for p in files}}
(root/"MANIFEST.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+"\n")
with zipfile.ZipFile(output,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(root.rglob("*")):
        if p.is_file():
            z.write(p,arcname=str(p.relative_to(root.parent)))
with zipfile.ZipFile(output) as z:
    assert z.testzip() is None
    for relative,record in manifest["files"].items():
        data=z.read(root.name+"/"+relative)
        assert len(data)==record["bytes"]
        assert hashlib.sha256(data).hexdigest()==record["sha256"]
receipt={"archive_path":str(output),"archive_bytes":output.stat().st_size,
         "archive_sha256":hashlib.sha256(output.read_bytes()).hexdigest(),
         "manifest_sha256":hashlib.sha256((root/"MANIFEST.json").read_bytes()).hexdigest(),
         "frozen_pre_run_manifest_sha256":hashlib.sha256((root/"PRE_RUN_FREEZE.json").read_bytes()).hexdigest(),
         "zip_crc_and_all_manifest_members_verified":True,
         "contains_independent_external_audit":False,
         "formal_solver_launches":1,"formal_launch_exit":1,"main_searches":648,
         "boundary_searches":45,"independent_reference_runs":90,
         "postprocessing_runs":1,"postprocessing_exit":0,"solver_reruns":0}
receipt_path=root.parent/(root.name+"_DELIVERY_RECEIPT.json")
receipt_path.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+"\n")
print(json.dumps(receipt,ensure_ascii=False))
