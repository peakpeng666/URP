#!/usr/bin/env python3
"""Single limited process: inputs, checks, frozen run, summaries, and report."""
import resource
resource.setrlimit(resource.RLIMIT_CPU, (180, 180))
resource.setrlimit(resource.RLIMIT_AS, (1024 ** 3, 1024 ** 3))
import signal
signal.alarm(600)

import csv
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import platform
import random
import statistics
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from search_core import ALGORITHMS, heuristic, search
from reference import VECTORS, encode_state, reverse_dijkstra, verify_path

PROCESS_STARTED = time.perf_counter()
START_UTC = dt.datetime.now(dt.timezone.utc).isoformat()
SEEDS = [871211, 871229, 871247, 871283]
SIZES = [16, 32, 48]
PROBABILITIES = [0.10, 0.25]
WEIGHTS = [0, 2, 8]
REPEATS = 3
COUNTERS = dict(preflight_oracle_started=0, preflight_oracle_completed=0,
                main_oracle_started=0, main_oracle_completed=0,
                boundary_oracle_started=0, boundary_oracle_completed=0,
                main_search_started=0, main_search_completed=0,
                boundary_search_started=0, boundary_search_completed=0,
                path_checks=0, failures=0)
JOURNAL = None


def utc():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def dump(path, value):
    (ROOT / path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def snapshot(paths):
    return {str(path.relative_to(ROOT)): dict(bytes=path.stat().st_size, sha256=digest(path))
            for path in sorted(paths)}


def event(kind, **data):
    entry = dict(timestamp_utc=utc(), event=kind, **data)
    JOURNAL.write(json.dumps(entry, ensure_ascii=False, allow_nan=False) + "\n")
    JOURNAL.flush()


def make_inputs():
    maps, cases = [], []
    for n in SIZES:
        for seed in SEEDS:
            for probability in PROBABILITIES:
                key = f"turn-aware-grid-v1|n={n}|seed={seed}|p={probability:.2f}"
                rng_seed = int.from_bytes(hashlib.sha256(key.encode()).digest(), "big")
                rng = random.Random(rng_seed)
                rows = ["".join("#" if rng.random() < probability else "." for _ in range(n))
                        for _ in range(n)]
                free = [(x, y) for y in range(n) for x in range(n) if rows[y][x] == "."]
                assert len(free) >= 2, "Frozen rule: do not resample a degenerate map."
                start_cell, goal = rng.sample(free, 2)
                heading = rng.randrange(4)
                map_id = f"n{n}_s{seed}_p{int(probability * 100):02d}"
                item = dict(map_id=map_id, n=n, seed=seed, obstacle_probability=probability,
                            rng_key=key, rng_seed_hex=hex(rng_seed), rows=rows,
                            start=[*start_cell, heading], goal=list(goal),
                            obstacle_count=n*n-len(free))
                maps.append(item)
                for weight in WEIGHTS:
                    cases.append(dict(case_id=f"{map_id}_w{weight}", map_id=map_id,
                                      weight=weight))
    assert len(maps) == 24 and len(cases) == 72
    dump("inputs/maps.json", maps)
    dump("inputs/cases.json", cases)
    boundary_maps = [
        dict(map_id="same_start_goal", n=5, rows=["....."]*5, start=[2,2,3], goal=[2,2],
             expected_base_steps=0, expected_turn_units=0, expected_reachable=True),
        dict(map_id="sealed_start", n=5,
             rows=[".....", "..#..", ".#.#.", "..#..", "....."],
             start=[2,2,0], goal=[4,4], expected_reachable=False),
        dict(map_id="complete_wall", n=5, rows=["..#.."]*5,
             start=[0,2,0], goal=[4,2], expected_reachable=False),
        dict(map_id="one_step_reverse", n=3, rows=["..."]*3,
             start=[1,1,0], goal=[0,1], expected_base_steps=1, expected_turn_units=2,
             expected_reachable=True),
        dict(map_id="forced_zigzag", n=5,
             rows=["...##", "##.##", "##...", "####.", "####."],
             start=[0,0,0], goal=[4,4], expected_base_steps=8, expected_turn_units=3,
             expected_reachable=True),
    ]
    boundary_cases = [dict(case_id=f"{m['map_id']}_w{w}", map_id=m["map_id"], weight=w)
                      for m in boundary_maps for w in WEIGHTS]
    dump("inputs/boundary_maps.json", boundary_maps)
    dump("inputs/boundary_cases.json", boundary_cases)
    dump("inputs/config.json", dict(protocol="turn-aware-grid-v1", seeds=SEEDS, sizes=SIZES,
         obstacle_probabilities=PROBABILITIES, weights=WEIGHTS, repeats=REPEATS,
         expected_main_search_runs=648, expected_boundary_search_runs=45,
         expected_preflight_oracle_runs=3, expected_main_oracle_runs=72,
         expected_boundary_oracle_runs=15))
    return maps, cases, boundary_maps, boundary_cases


def oracle(rows, goal, weight, category, case_id):
    COUNTERS[f"{category}_oracle_started"] += 1
    event("oracle_start", category=category, case_id=case_id, weight=weight)
    cpu0, wall0 = time.process_time_ns(), time.perf_counter_ns()
    distances, edges, info = reverse_dijkstra(rows, goal, weight)
    info.update(cpu_ns=time.process_time_ns()-cpu0, wall_ns=time.perf_counter_ns()-wall0)
    COUNTERS[f"{category}_oracle_completed"] += 1
    event("oracle_complete", category=category, case_id=case_id, weight=weight, **info)
    return distances, edges, info


def preflight():
    rows, goal = ["." * 13] * 13, (6,6)
    checks = dict(exact_turn_heuristic_states=0, admissibility_checks=0,
                  consistency_checks=0, nonnegative_checks=0, goal_zero_checks=0)
    records = []
    for weight in WEIGHTS:
        distances, edges, info = oracle(rows, goal, weight, "preflight", f"open13_w{weight}")
        for (cell, vector), exact in distances.items():
            state = (*cell, VECTORS.index(vector))
            assert heuristic(state, goal, weight, "astar_turn") == exact
            checks["exact_turn_heuristic_states"] += 1
            for algorithm in ALGORITHMS:
                h = heuristic(state, goal, weight, algorithm)
                assert 0 <= h <= exact
                checks["nonnegative_checks"] += 1
                checks["admissibility_checks"] += 1
                if cell == goal:
                    assert h == 0
                    checks["goal_zero_checks"] += 1
        for source, target, cost in edges:
            s = (*source[0], VECTORS.index(source[1]))
            t = (*target[0], VECTORS.index(target[1]))
            for algorithm in ALGORITHMS:
                assert heuristic(s, goal, weight, algorithm) <= cost + heuristic(t, goal, weight, algorithm)
                checks["consistency_checks"] += 1
        records.append(dict(weight=weight, **info))
    result = dict(passed=True, grid_size=13, target=[6,6],
                  displacement_range_inclusive=[-6,6], algorithms=list(ALGORITHMS),
                  weights=WEIGHTS, checks=checks, oracle_runs=records, completed_utc=utc())
    dump("checks/preflight.json", result)
    event("preflight_passed", **checks)
    return result


def write_csv(path, records):
    keys = sorted({key for row in records for key in row if key != "path"})
    with (ROOT / path).open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=keys)
        writer.writeheader()
        for row in records:
            writer.writerow({key: (json.dumps(value, ensure_ascii=False)
                                   if isinstance(value, (dict,list,tuple)) else value)
                             for key, value in row.items() if key != "path"})


def run_cases(maps, cases, category, repeats):
    lookup = {m["map_id"]: m for m in maps}
    results, oracle_results = [], []
    output = (ROOT / f"outputs/{category}_runs.jsonl").open("w")
    for case_index, case in enumerate(cases):
        map_data = lookup[case["map_id"]]
        rows, start, goal = map_data["rows"], map_data["start"], map_data["goal"]
        weight, case_id = case["weight"], case["case_id"]
        distances, _, info = oracle(rows, goal, weight, category, case_id)
        exact = distances.get(encode_state(start))
        oracle_row = dict(category=category, **case, exact_cost=exact, reachable=exact is not None, **info)
        if category == "boundary":
            expected = (map_data["expected_base_steps"] + weight * map_data["expected_turn_units"]
                        if map_data["expected_reachable"] else None)
            assert exact == expected, (case_id, exact, expected)
            oracle_row["manual_expected_cost"] = expected
        oracle_results.append(oracle_row)
        baselines = {}
        for repeat in range(repeats):
            offset = (case_index + repeat) % len(ALGORITHMS)
            ordering = ALGORITHMS[offset:] + ALGORITHMS[:offset]
            for position, algorithm in enumerate(ordering):
                COUNTERS[f"{category}_search_started"] += 1
                event("search_start", category=category, case_id=case_id,
                      algorithm=algorithm, repeat=repeat)
                cpu0, wall0 = time.process_time_ns(), time.perf_counter_ns()
                result = search(rows, start, goal, weight, algorithm)
                cpu_ns, wall_ns = time.process_time_ns()-cpu0, time.perf_counter_ns()-wall0
                COUNTERS[f"{category}_search_completed"] += 1
                checked = verify_path(rows, start, goal, weight, result, exact)
                assert result["reexpansions"] == 0
                COUNTERS["path_checks"] += 1
                if repeat:
                    assert result == baselines[algorithm], (case_id, algorithm, "nondeterminism")
                else:
                    baselines[algorithm] = result
                row = dict(category=category, **case, n=map_data["n"],
                           seed=map_data.get("seed"), obstacle_probability=map_data.get("obstacle_probability"),
                           repeat=repeat, algorithm=algorithm, within_repeat_order=position,
                           cpu_ns=cpu_ns, wall_ns=wall_ns, exact_cost=exact,
                           path_valid=checked["valid"], steps=checked["steps"],
                           turn_units=checked["turn_units"], **result)
                results.append(row)
                output.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")
                output.flush()
                event("search_complete", category=category, case_id=case_id,
                      algorithm=algorithm, repeat=repeat, cost=result["cost"],
                      expansions=result["expansions"], heap_pushes=result["heap_pushes"],
                      cpu_ns=cpu_ns, wall_ns=wall_ns, validated=True)
        print(json.dumps(dict(progress=category, completed_cases=case_index+1,
                              total_cases=len(cases), case_id=case_id, exact_cost=exact)), flush=True)
    output.close()
    dump(f"outputs/{category}_oracles.json", oracle_results)
    write_csv(f"outputs/{category}_runs.csv", results)
    return results, oracle_results


def summarize(main, main_oracles, boundary, preflight_result):
    primary = [r for r in main if r["repeat"] == 0]
    paired = []
    for case_id in sorted({r["case_id"] for r in primary}):
        found = {r["algorithm"]: r for r in primary if r["case_id"] == case_id}
        a, b = found["astar_turn"], found["astar_manhattan"]
        paired.append(dict(case_id=case_id, weight=a["weight"], n=a["n"], reachable=a["reachable"],
                           manhattan_expansions=b["expansions"], turn_expansions=a["expansions"],
                           expansion_reduction_percent=100*(b["expansions"]-a["expansions"])/b["expansions"],
                           manhattan_heap_pushes=b["heap_pushes"], turn_heap_pushes=a["heap_pushes"],
                           push_reduction_percent=100*(b["heap_pushes"]-a["heap_pushes"])/b["heap_pushes"]))
    groups = []
    for weight in WEIGHTS + ["all"]:
        chosen = [r for r in primary if weight == "all" or r["weight"] == weight]
        group_pairs = [p for p in paired if weight == "all" or p["weight"] == weight]
        totals = {}
        for algorithm in ALGORITHMS:
            rows = [r for r in chosen if r["algorithm"] == algorithm]
            medians = [statistics.median([x["cpu_ns"] for x in main
                       if x["case_id"] == r["case_id"] and x["algorithm"] == algorithm]) for r in rows]
            totals[algorithm] = dict(cases=len(rows), expansions=sum(r["expansions"] for r in rows),
                 heap_pushes=sum(r["heap_pushes"] for r in rows),
                 sum_case_median_cpu_ms=sum(medians)/1e6,
                 median_case_cpu_ms=statistics.median(medians)/1e6,
                 min_run_cpu_ms=min(x["cpu_ns"] for x in main if x["algorithm"] == algorithm
                                    and (weight == "all" or x["weight"] == weight))/1e6,
                 max_run_cpu_ms=max(x["cpu_ns"] for x in main if x["algorithm"] == algorithm
                                    and (weight == "all" or x["weight"] == weight))/1e6)
        reductions = dict()
        for baseline in ("dijkstra", "astar_manhattan"):
            reductions[baseline] = {metric: 100*(1-totals["astar_turn"][metric]/totals[baseline][metric])
                                    for metric in ("expansions", "heap_pushes", "sum_case_median_cpu_ms")}
        groups.append(dict(weight=weight, cases=len(group_pairs),
                           reachable=sum(p["reachable"] for p in group_pairs), totals=totals,
                           pooled_reduction_percent_vs=reductions,
                           median_paired_expansion_reduction_percent=statistics.median(
                                p["expansion_reduction_percent"] for p in group_pairs),
                           expansion_win_tie_loss=dict(
                               win=sum(p["turn_expansions"] < p["manhattan_expansions"] for p in group_pairs),
                               tie=sum(p["turn_expansions"] == p["manhattan_expansions"] for p in group_pairs),
                               loss=sum(p["turn_expansions"] > p["manhattan_expansions"] for p in group_pairs))))
    summary = dict(protocol="turn-aware-grid-v1", completed_utc=utc(), all_checks_passed=True,
                   main_cases=72, distinct_main_maps=24, main_algorithm_executions=len(main),
                   main_independent_oracles=len(main_oracles), boundary_algorithm_executions=len(boundary),
                   main_reachable_cases=sum(o["reachable"] for o in main_oracles),
                   main_unreachable_cases=sum(not o["reachable"] for o in main_oracles),
                   boundary_cases=15, counts=dict(COUNTERS), preflight=preflight_result,
                   groups=groups, paired_cases=paired)
    dump("outputs/summary.json", summary)
    write_csv("outputs/paired_cases.csv", paired)
    dump("outputs/results.json", dict(summary=summary, main=main, main_oracles=main_oracles,
                                      boundary=boundary))
    return summary


def report(summary):
    all_group = summary["groups"][-1]
    diff = all_group["pooled_reduction_percent_vs"]["astar_manhattan"]
    lines = ["# 朝向状态 A 星搜索正确性与开销短实验", "",
        f"72个新合成问题全部通过独立最优代价与路径校验，三算法各实跑3次，共648次主搜索；另45次边界搜索通过。含转向下界的A*相对仅曼哈顿A*，合计扩展减少{diff['expansions']:.2f}%，入堆减少{diff['heap_pushes']:.2f}%。这是本次离散模型的描述性结果。", "",
        "## 范围和设计", "",
        "24张新合成地图：边长16/32/48、四固定种子871211/871229/871247/871283、障碍概率0.10/0.25；每图固定起点、终点、初始朝向，分别使用转弯权重0/2/8，形成72配对问题。不可达不换样。",
        "状态为位置加四向朝向；目标代价为步数加权90度转向单位，180度反向计两单位，终点朝向自由。三算法的动作、严格改善入堆、平局顺序与停止规则相同。详见PROTOCOL.md。",
        "三算法依次为Dijkstra（零启发）、A* Manhattan（距离）、A* Turn（距离加无障碍最少转角下界）。单步允许直接改变朝向，不包含曲率、加速度、转弯半径、作物行约束、动态障碍或实车控制。", "",
        "## 正确性", "",
        f"- 主问题可达{summary['main_reachable_cases']}/72、不可达{summary['main_unreachable_cases']}/72。三算法的全部648次主运行均与独立显式反向图Dijkstra一致。",
        "- 独立参考用不同状态编码、显式反向图及向量点积计算转角；不调用被测搜索内核、动作生成器、转向函数或启发式。每条返回路径逐步验证合法性并独立重算成本。",
        f"- 正式运行前，无障碍13×13全部2028个带权朝向状态的转向启发值等于独立精确值；三个启发式共6084个admissibility检查、22464条边consistency检查、36个目标零值检查全部通过。",
        "- 起终相同、封闭起点、完全隔墙、单步180度反向、强制折线5种边界，各3权重、3算法，共45次独立边界搜索；均符合手算期望与独立参考。边界不混入主汇总。",
        "- 三次重复的路径、代价、所有搜索计数完全一致；没有重扩展。", "",
        "转向下界的理由：单轴位移必须最终沿所需方向前进，最少转角是初始朝向到该方向的0/1/2单位；双轴位移必须使用两种相邻方向，若起始朝向已是其中一种则至少1单位，否则至少2单位。这些下界均可由无障碍单轴或两段单调路径达到。因此距离加该转角项等于无障碍精确最优代价；删除障碍的松弛问题给出admissible且consistent的启发式。有限枚举验证不是任意地图的穷尽证明。", "",
        "## 搜索开销", "",
        "下表每个问题只取重复0的确定性计数，避免把3次重复当成3个样本。扩展数不含目标出堆，入堆数含起点。", "",
        "| 转弯权重 | 算法 | 合计扩展 | 合计入堆 | 各问题三次CPU中位数之和 ms |",
        "|---|---|---:|---:|---:|"]
    for group in summary["groups"]:
        for algorithm in ALGORITHMS:
            row = group["totals"][algorithm]
            lines.append(f"| {group['weight']} | {algorithm} | {row['expansions']} | {row['heap_pushes']} | {row['sum_case_median_cpu_ms']:.3f} |")
    lines += ["", "各权重下A* Turn相对A* Manhattan的配对扩展变化：", ""]
    for group in summary["groups"][:-1]:
        wtl = group["expansion_win_tie_loss"]
        pooled = group["pooled_reduction_percent_vs"]["astar_manhattan"]
        lines.append(f"- λ={group['weight']}：合计扩展减少{pooled['expansions']:.2f}%；逐问题减少率中位数{group['median_paired_expansion_reduction_percent']:.2f}%；胜/平/负={wtl['win']}/{wtl['tie']}/{wtl['loss']}。")
    lines += ["", "λ=0时两个A*启发式相同，计数应相同；非零权重才检验转向信息的额外价值。不可达实例仍保留，队列耗尽时更强启发式不能消除所有可达状态的探索需求。", "",
        "## 计时与限制", "",
        "CPU使用process_time_ns，wall使用perf_counter_ns。每问题每算法真实重复3次，无预热，算法顺序轮换；原始每次数据都保存。搜索计时含初始化与返回路径重建，不含外部校验/写文件。独立参考、所有校验和汇总均计入总进程CPU。",
        "运行在共享云环境，CPU差值包含Python解释器、启发式计算和实验实现因素，不能据此宣称一般硬件或实车上的速度优势。四种种子、同一地图跨权重相关，本报告没有统计显著性主张、参数调优或事后剔除。",
        "这项实验支持将显式朝向状态与该模型专用的转向下界作为可验证基线；它不证明真实农业机器人规划质量或动力学可行性，也不构成新算法的普遍优越性证据。", "",
        "## 可核验文件", "",
        "- PROTOCOL.md：预定规则和全部固定种子。PRE_RUN_FREEZE.json：正式运行前源码、输入及预检查SHA256。",
        "- inputs/：24张地图、72问题、15边界及配置。src/：共同搜索、独立参考、单进程驱动源码。",
        "- outputs/results.json：完整结果与路径；main_runs.csv/main_runs.jsonl：648次记录；boundary_runs.csv/boundary_runs.jsonl：45次边界。",
        "- outputs/paired_cases.csv与summary.json：配对及分组汇总。checks/preflight.json、post_run_checks.json与execution_journal.jsonl：检查和真实执行记账。",
        "- checks/resource_usage.json：本进程实际CPU/wall计量快照和硬限；LAUNCH_ATTEMPT.json/LAUNCH_EXIT.json：一次启动及退出状态。",
        "- MANIFEST.json及完整ZIP：交付文件的哈希清单。没有读取原132/heldout、修改旧实验、调用模型、安装依赖或发布GitHub。", ""]
    (ROOT / "REPORT_ZH.md").write_text("\n".join(lines))


def run():
    global JOURNAL
    JOURNAL = (ROOT / "checks/execution_journal.jsonl").open("w")
    source_paths = [ROOT / "PROTOCOL.md", ROOT / "run_limited.sh"] + list((ROOT / "src").glob("*.py"))
    initial = snapshot(source_paths)
    dump("checks/initial_source_snapshot.json", dict(timestamp_utc=utc(), files=initial))
    dump("checks/runtime_environment.json", dict(python=sys.version, executable=sys.executable,
         platform=platform.platform(), pid=os.getpid(), started_utc=START_UTC,
         cpu_hard_limit_seconds=180, wall_alarm_seconds=600,
         address_space_hard_limit_bytes=1024**3, actual_rlimit_cpu=resource.getrlimit(resource.RLIMIT_CPU),
         actual_rlimit_as=resource.getrlimit(resource.RLIMIT_AS), stdlib_only=True,
         numerical_processes=1, model_calls=0, network_calls=0, dependencies_installed=0))
    event("process_start", cpu_limit_seconds=180, wall_limit_seconds=600)
    maps, cases, boundary_maps, boundary_cases = make_inputs()
    preflight_result = preflight()
    assert snapshot(source_paths) == initial
    freeze_paths = source_paths + list((ROOT / "inputs").glob("*.json")) + [ROOT / "checks/preflight.json"]
    frozen = snapshot(freeze_paths)
    dump("PRE_RUN_FREEZE.json", dict(timestamp_utc=utc(), phase="before_first_formal_search",
         protocol="turn-aware-grid-v1", input_problem_count=72, main_repeats=3,
         files=frozen, preflight_passed=True, code_unchanged_since_process_start=True))
    event("formal_run_frozen", manifest_sha256=digest(ROOT / "PRE_RUN_FREEZE.json"))
    print("PRE_RUN_FROZEN " + digest(ROOT / "PRE_RUN_FREEZE.json"), flush=True)
    main, main_oracles = run_cases(maps, cases, "main", REPEATS)
    boundary, boundary_oracles = run_cases(boundary_maps, boundary_cases, "boundary", 1)
    assert len(main) == 648 and len(boundary) == 45
    assert COUNTERS["main_oracle_completed"] == 72
    assert COUNTERS["boundary_oracle_completed"] == 15
    assert COUNTERS["preflight_oracle_completed"] == 3
    assert COUNTERS["path_checks"] == 693
    assert snapshot(freeze_paths) == frozen, "Frozen files changed during run."
    dump("checks/post_run_checks.json", dict(passed=True, frozen_files_unchanged=True,
         exact_execution_counts=dict(COUNTERS), all_returned_paths_checked=True,
         all_costs_match_independent_oracle=True, repeated_non_timing_results_identical=True,
         no_reexpansions=True, manual_boundary_costs_match=True, completed_utc=utc()))
    summary = summarize(main, main_oracles, boundary, preflight_result)
    report(summary)
    event("completed", exact_counts=dict(COUNTERS))
    JOURNAL.close()
    usage = resource.getrusage(resource.RUSAGE_SELF)
    dump("checks/resource_usage.json", dict(status="completed", measured_at_utc=utc(),
         user_cpu_seconds=usage.ru_utime, system_cpu_seconds=usage.ru_stime,
         process_cpu_seconds=usage.ru_utime+usage.ru_stime,
         process_time_seconds=time.process_time(),
         wall_seconds_since_driver_imports=time.perf_counter()-PROCESS_STARTED,
         max_rss_kib=usage.ru_maxrss, cpu_limit_seconds=180, wall_limit_seconds=600,
         note="Measured after all numerical work, checks, results and report; excludes subsequent resource-file write and external packaging. Terminal launcher shell also records its measured child user/system time."))
    print("COMPLETE " + json.dumps(dict(main_runs=len(main), boundary_runs=len(boundary),
         all_checks_passed=True, process_cpu_seconds=usage.ru_utime+usage.ru_stime)), flush=True)


if __name__ == "__main__":
    try:
        run()
    except BaseException as exc:
        COUNTERS["failures"] += 1
        failure = dict(timestamp_utc=utc(), error_type=type(exc).__name__, error=str(exc),
                       counts=dict(COUNTERS), traceback=traceback.format_exc())
        dump("checks/FAILURE.json", failure)
        if JOURNAL is not None and not JOURNAL.closed:
            event("failure", failure=failure)
            JOURNAL.close()
        traceback.print_exc()
        raise
