#!/usr/bin/env python3
"""Read-only analysis of completed raw records; never invokes any solver.

Explicit recovery after the frozen driver failed while forming CPU ratios.
Original protocol, code, inputs, outputs, failure, and launch evidence remain
unchanged. This process only adds derived files and its own evidence.
"""
import resource
resource.setrlimit(resource.RLIMIT_CPU, (10,10))
resource.setrlimit(resource.RLIMIT_AS, (1024**3,1024**3))
import signal
signal.alarm(30)
import csv
import datetime as dt
import hashlib
import json
from pathlib import Path
import statistics
import time

ROOT = Path(__file__).resolve().parents[1]
START_WALL = time.perf_counter()
ALGORITHMS = ("dijkstra", "astar_manhattan", "astar_turn")
WEIGHTS = (0,2,8)


def load(name):
    return json.loads((ROOT/name).read_text())


def dump(name, value):
    (ROOT/name).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+"\n")


def csv_dump(name, rows):
    columns = sorted({k for r in rows for k in r})
    with (ROOT/name).open("w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=columns)
        w.writeheader()
        for row in rows:
            w.writerow({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list,tuple)) else v
                        for k,v in row.items()})


main = [json.loads(s) for s in (ROOT/"outputs/main_runs.jsonl").read_text().splitlines()]
boundary = [json.loads(s) for s in (ROOT/"outputs/boundary_runs.jsonl").read_text().splitlines()]
main_oracles = load("outputs/main_oracles.json")
boundary_oracles = load("outputs/boundary_oracles.json")
freeze=load("PRE_RUN_FREEZE.json")
for filename,record in freeze["files"].items():
    assert hashlib.sha256((ROOT/filename).read_bytes()).hexdigest()==record["sha256"]
assert len(main)==648 and len(boundary)==45 and len(main_oracles)==72 and len(boundary_oracles)==15
assert all(r["path_valid"] and r["cost"]==r["exact_cost"] and r["reexpansions"]==0 for r in main+boundary)
keys={(r["case_id"],r["algorithm"],r["repeat"]) for r in main}
assert len(keys)==648 and len({r["case_id"] for r in main})==72
assert all(sum(r["case_id"]==case and r["algorithm"]==algorithm for r in main)==3
           for case in {r["case_id"] for r in main} for algorithm in ALGORITHMS)
raw_cpu_values=[r["cpu_ns"] for r in main+boundary]
cpu_zero_count=sum(x==0 for x in raw_cpu_values)
# An identically zero duration series is unusable, not evidence of free work.
cpu_timing_usable=all(x>0 for x in raw_cpu_values)
primary=[r for r in main if r["repeat"]==0]
paired=[]
for case in sorted({r["case_id"] for r in primary}):
    rows={r["algorithm"]:r for r in primary if r["case_id"]==case}
    a,b=rows["astar_turn"],rows["astar_manhattan"]
    paired.append(dict(case_id=case,weight=a["weight"],n=a["n"],reachable=a["reachable"],
        manhattan_expansions=b["expansions"],turn_expansions=a["expansions"],
        expansion_reduction_percent=100*(b["expansions"]-a["expansions"])/b["expansions"],
        manhattan_heap_pushes=b["heap_pushes"],turn_heap_pushes=a["heap_pushes"],
        push_reduction_percent=100*(b["heap_pushes"]-a["heap_pushes"])/b["heap_pushes"]))
groups=[]
for weight in (*WEIGHTS,"all"):
    chosen=[r for r in primary if weight=="all" or r["weight"]==weight]
    pairs=[r for r in paired if weight=="all" or r["weight"]==weight]
    totals={}
    for algorithm in ALGORITHMS:
        rows=[r for r in chosen if r["algorithm"]==algorithm]
        wall_medians=[statistics.median(r["wall_ns"] for r in main if r["case_id"]==base["case_id"]
                                       and r["algorithm"]==algorithm) for base in rows]
        totals[algorithm]=dict(cases=len(rows),expansions=sum(r["expansions"] for r in rows),
            heap_pushes=sum(r["heap_pushes"] for r in rows),
            sum_case_median_wall_ms=sum(wall_medians)/1e6,
            median_case_wall_ms=statistics.median(wall_medians)/1e6,
            cpu_comparison=None)
    reductions={baseline:{metric:100*(1-totals["astar_turn"][metric]/totals[baseline][metric])
                          for metric in ("expansions","heap_pushes")}
                for baseline in ("dijkstra","astar_manhattan")}
    groups.append(dict(weight=weight,cases=len(pairs),reachable=sum(r["reachable"] for r in pairs),
        totals=totals,pooled_reduction_percent_vs=reductions,
        median_paired_expansion_reduction_percent=statistics.median(r["expansion_reduction_percent"] for r in pairs),
        expansion_win_tie_loss=dict(win=sum(r["turn_expansions"]<r["manhattan_expansions"] for r in pairs),
                                    tie=sum(r["turn_expansions"]==r["manhattan_expansions"] for r in pairs),
                                    loss=sum(r["turn_expansions"]>r["manhattan_expansions"] for r in pairs))))
summary=dict(status="solver_and_correctness_complete_postprocessing_recovered",protocol="turn-aware-grid-v1",
    formal_solver_process_exit_code=load("LAUNCH_EXIT.json")["exit_code"],
    formal_error_stage="summary CPU ratio after all 693 search validations completed",
    recovery="Read existing raw files only; no search, oracle, map generation or experiment rerun",
    main_cases=72,distinct_main_maps=24,main_algorithm_executions=648,boundary_cases=15,
    boundary_algorithm_executions=45,total_independent_dijkstra_oracles=90,
    main_reachable_cases=sum(r["reachable"] for r in main_oracles),
    main_unreachable_cases=sum(not r["reachable"] for r in main_oracles),
    all_solver_correctness_checks_passed=True,
    frozen_files_unchanged=True,preflight=load("checks/preflight.json"),
    final_execution_counts=load("checks/FAILURE.json")["counts"],
    cpu_timing=dict(usable=cpu_timing_usable,zero_records=cpu_zero_count,total_records=len(raw_cpu_values),
                    minimum_ns=min(raw_cpu_values),maximum_ns=max(raw_cpu_values),
                    decision="No per-search CPU ratios, speedup claims or CPU timing conclusions"),
    terminal_launcher_resource_measurement=(ROOT/"checks/launcher_resource_usage.txt").read_text().strip(),
    groups=groups,paired_cases=paired,
    completed_utc=dt.datetime.now(dt.timezone.utc).isoformat())
dump("outputs/summary.json",summary)
dump("outputs/results.json",dict(summary=summary,main=main,main_oracles=main_oracles,
                                 boundary=boundary,boundary_oracles=boundary_oracles))
csv_dump("outputs/paired_cases.csv",paired)
csv_dump("outputs/group_summary.csv",[
    dict(weight=g["weight"],algorithm=a,**r) for g in groups for a,r in g["totals"].items()])

allgroup=groups[-1]
pct=allgroup["pooled_reduction_percent_vs"]["astar_manhattan"]
lines=["# 朝向状态 A 星搜索正确性与开销短实验","",
 f"72个新合成问题的全部648次主搜索，以及45次边界搜索，均通过独立最优代价和逐步路径检查。A* Turn相对A* Manhattan的合计扩展减少{pct['expansions']:.2f}%，入堆减少{pct['heap_pushes']:.2f}%。正式进程在搜索全部结束后的CPU汇总阶段失败，现已从完整原始记录恢复报告，没有补跑搜索。","",
 "## 设计和模型","",
 "24张地图：边长16/32/48、固定种子871211/871229/871247/871283、Bernoulli障碍概率0.10/0.25。每图固定一次起点、终点、初始朝向，并使用转弯权重0/2/8，得到72配对问题。输入生成、种子和平局规则在PROTOCOL.md固定，正式运行前记录全部源码和输入的SHA256。","",
 "状态为(x,y,heading)，每步走到四邻接可通行格，新朝向为移动方向。代价是步数加λ乘90度转向单位，180度反向计2单位，终点朝向自由。三算法共用同一搜索内核、动作顺序、(f,g,x,y,heading,插入序号)平局、严格改善才入堆及首次非过期目标出堆停止规则。","",
 "- Dijkstra：零启发式。",
 "- A* Manhattan：曼哈顿距离。",
 "- A* Turn：距离加无障碍最少转向代价下界。","",
 "## 正确性结果","",
 f"主问题可达{summary['main_reachable_cases']}/72、不可达{summary['main_unreachable_cases']}/72；不可达保留、不重新抽样。三算法全部648次运行的代价等于独立参考；所有返回路径逐步合法且成本重算一致。每算法3次重复的全部非计时输出相同，无重扩展。","",
 "独立参考以不同状态编码构建显式反向图，用向量点积计算转角，从终点四朝向多源Dijkstra；不调用被测搜索、动作生成器、转向函数或启发式。参考执行90次：主问题72次、边界15次、启发式预检查3次。","",
 "预检查覆盖13×13无障碍图全部4朝向、3权重。2028个转向启发值均等于精确最短路；三个启发式6084个admissibility、22464个有向边consistency及36个目标零值检查全部通过。","",
 "起终相同、封闭起点、完全隔墙、单步180度反向、强制折线共5种边界，各3权重、3算法，45次结果均符合手算值和独立参考；不混入主汇总。","",
 "下界依据：单轴位移要求使用目标方向，最少转角是当前方向到目标方向的0/1/2单位。双轴位移要求使用两种相邻方向，起始朝向属于其中之一则至少1单位，否则至少2单位；零位移为0。无障碍单轴或两段单调路径能同时达到曼哈顿长度和这个最少转角，因此该启发值等于松弛问题的精确代价，具备admissibility和consistency。有限网格枚举只是实现检查，不替代上述数学理由。","",
 "## 主要搜索开销","",
 "下表只用每问题重复0的确定性计数。扩展是非过期、非目标出堆后枚举后继的状态次数；入堆包括初始状态。3次重复不当成3个独立样本。","",
 "| λ | 算法 | 合计扩展 | 合计入堆 | 各问题三次wall中位数之和 ms |",
 "|---|---|---:|---:|---:|"]
for group in groups:
    for algorithm in ALGORITHMS:
        r=group["totals"][algorithm]
        lines.append(f"| {group['weight']} | {algorithm} | {r['expansions']} | {r['heap_pushes']} | {r['sum_case_median_wall_ms']:.3f} |")
lines += ["","A* Turn相对A* Manhattan的配对变化：",""]
for group in groups[:-1]:
    w=group["expansion_win_tie_loss"]
    r=group["pooled_reduction_percent_vs"]["astar_manhattan"]
    lines.append(f"- λ={group['weight']}：合计扩展减少{r['expansions']:.2f}%，入堆减少{r['heap_pushes']:.2f}%；逐问题扩展减少率中位数{group['median_paired_expansion_reduction_percent']:.2f}%；胜/平/负={w['win']}/{w['tie']}/{w['loss']}。")
lines += ["","λ=0时两个A*的启发式一致，计数相同；非零权重才体现转向下界的额外信息。这是固定平局规则下的本批合成结果，不保证每个一般地图都降低同样比例。","",
 "## 实际运行和已知失败","",
 "预定正式运行在一个Python进程内，CPU硬限180秒、墙钟600秒、地址空间1GiB。唯一启动见LAUNCH_ATTEMPT.json；正式代码与输入冻结后未修改。所有搜索及正确性校验在11:29:23至11:29:26 UTC之间完成。终端shell记录的实际量为："+summary["terminal_launcher_resource_measurement"]+"。","",
 f"本环境的单次process_time_ns差值在{cpu_zero_count}/{len(raw_cpu_values)}条搜索记录中为0（最小{min(raw_cpu_values)}、最大{max(raw_cpu_values)}纳秒），不能当作零成本。冻结驱动随后计算CPU相对比率，出现ZeroDivisionError，正式进程exit=1；FAILURE.json和原始日志原样保留。CPU计时部分未达到原协议预期，不提供逐次CPU速度结论。","",
 "恢复仅在另一个10秒CPU/30秒wall受限后处理进程中读取既有原始数据，生成派生汇总和本报告；没有执行搜索、参考最短路、地图生成或追加实验。故应如实区分：唯一实验求解进程完成、汇总代码失败、只读后处理恢复；不是全流程一次成功。后处理资源独立记录在recovery/，未扩大原180秒/600秒硬限。","",
 "wall计时每算法每问题3次，无预热，按预定规则轮换顺序；计时含搜索初始化和路径重建、不含独立校验与文件写入。表中wall值只是共享云同机描述，不能作CPU优势、普遍速度或实车实时性证据。","",
 "## 适用范围","",
 "这项实验给农业机器人点到点规划提供一个可核验的离散基线：若目标包含方向改变惩罚，应把朝向保留为状态；该模型的无障碍转向下界可减少这批问题的搜索开销。这里只比较三个朝向状态算法，没有无朝向算法对照，因而未实验验证忽略朝向会造成多大误差。","",
 "数据均为合成而非田间数据，没有曲率、加速度、转弯半径、作物行、车体碰撞或动态障碍。4个种子、24地图，同图跨λ相关；不宣称统计显著、一般化优势或真实车辆动力学可行性。未读取原132/heldout，未改动任何旧实验，未调用模型、联网或安装依赖。","",
 "## 文件导航","",
 "- PROTOCOL.md与PRE_RUN_FREEZE.json：预定规则、种子、正式前SHA256。",
 "- src/和inputs/：源码、24地图、72主问题、15边界问题。",
 "- outputs/results.json：完整原始运行、路径、oracle及汇总。main_runs.csv/jsonl含648次；boundary_runs.csv/jsonl含45次。",
 "- outputs/summary.json、paired_cases.csv、group_summary.csv：派生汇总。",
 "- checks/preflight.json、post_run_checks.json、execution_journal.jsonl：启发式检查、正确性和精确执行记账。",
 "- LAUNCH_EXIT.json、checks/FAILURE.json、launcher_resource_usage.txt：失败及终端资源证据。",
 "- recovery/：只读恢复源码、偏差说明与资源记录。MANIFEST.json及ZIP包含全套可审查证据。",""]
(ROOT/"REPORT_ZH.md").write_text("\n".join(lines))
dump("recovery/RECOVERY_NOTICE.json",dict(reason="ZeroDivisionError in frozen summary after complete experiments",
    original_sources_modified=False,original_inputs_modified=False,original_raw_records_modified=False,
    solver_reruns=0,oracle_reruns=0,numerical_solver_processes=1,postprocessing_processes=1,
    derived_files=["outputs/summary.json","outputs/results.json","outputs/paired_cases.csv",
                   "outputs/group_summary.csv","REPORT_ZH.md"],
    cpu_timing_usable=cpu_timing_usable,formal_failure_retained=True,
    frozen_files_reverified=True,postprocessing_cpu_limit_seconds=10,postprocessing_wall_limit_seconds=30,
    measured_process_cpu_seconds=time.process_time(),
    measured_wall_seconds=time.perf_counter()-START_WALL,
    process_clock_info=vars(time.get_clock_info("process_time")),
    wall_clock_info=vars(time.get_clock_info("perf_counter"))))
print(json.dumps(dict(main_cases=72,main_runs=648,boundary_runs=45,reachable=summary["main_reachable_cases"],
    cpu_zero_count=cpu_zero_count,overall_reduction_percent=pct,groups=groups),ensure_ascii=False))
