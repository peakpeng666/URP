#!/bin/bash
# Launch exactly once from this directory. Python enforces CPU+AS+wall limits.
set -eu
cd "$(dirname "$0")"
if [ -e LAUNCH_ATTEMPT.json ]; then
  echo 'Refusing a second launch: preserve existing execution evidence.' >&2
  exit 70
fi
printf '{"attempt":1,"launcher_utc":"%s","external_wall_limit_seconds":600,"external_kill_grace_seconds":2}\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > LAUNCH_ATTEMPT.json
set +e
TIMEFORMAT='wall_seconds=%R user_cpu_seconds=%U system_cpu_seconds=%S'
{ time timeout --signal=TERM --kill-after=2s 600s python3 -I -B src/run.py > outputs/execution.log 2>&1; } 2> checks/launcher_resource_usage.txt
status=$?
printf '{"exit_code":%s,"launcher_ended_utc":"%s"}\n' "$status" "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > LAUNCH_EXIT.json
exit "$status"
