#!/bin/bash
set -u
cd "$(dirname "$0")"
if ! (set -o noclobber; printf '{"launch":"one_shot"}\n' > LAUNCH_ATTEMPT.json) 2>/dev/null; then echo 'Already launched; refusing overwrite'; exit 73; fi
export PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0
/usr/bin/time -f 'wall_seconds=%e user_cpu_seconds=%U system_cpu_seconds=%S max_rss_kib=%M exit_code=%x' -o checks/launcher_resource_usage.txt timeout --signal=TERM --kill-after=2 800 python3 -B src/run_timing.py > raw/execution.log 2>&1
code=$?
printf '{"exit_code":%d}\n' "$code" > LAUNCH_EXIT.json
cat raw/execution.log
exit "$code"
