"""Read-only provenance, report-statistics and saved-vector checks."""
from pathlib import Path
import json,hashlib,resource,signal,time,datetime,math
import numpy as np
resource.setrlimit(resource.RLIMIT_CPU,(120,120));signal.alarm(300)
A=Path(__file__).resolve().parent;R=A.parent
start=time.monotonic();cpu=time.process_time()
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
checks=[]
def check(name,passed,detail):checks.append({'check':name,'passed':bool(passed),'detail':detail})
old=read(A/'old_sourcepins.json');bad=[p for p,x in old['files'].items() if sha(R/p)!=x['sha256'] or (R/p).stat().st_size!=x['bytes']]
check('All 336 previously pinned old source files remain unchanged',not bad,{'files':len(old['files']),'mismatch':bad})
D=R/'independent_de_multi_rotation_20261006';S=R/'independent_turn_search_timing_20261006'
rec=read(D/'STATISTICS_RECOVERY_MANIFEST.json');rc=read(D/'provenance/statistics_recovery_external_receipt.json');bad=[p for p,x in rec['files'].items() if sha(D/p)!=x['sha256'] or (D/p).stat().st_size!=x['bytes']]
check('Recovery frozen files and chronology preserved',not bad and rec['frozen_at_utc']<=rc['start_utc'],{'files':len(rec['files']),'mismatch':bad,'freeze':rec['frozen_at_utc'],'start':rc['start_utc']})
P=read(D/'protocol.json');cfgs={c['id']:c for c in P['configs']};rows=[json.loads(s) for s in (D/'results/runs.jsonl').read_text().splitlines()]+read(D/'results/reused_runs.json');bad=[]
for row in rows:
 with np.load(D/row['output_file']) as z:
  if not (np.array_equal(z['best_vector'],z['final_population'][int(np.argmin(z['final_fitness']))]) and cfgs[row['config_id']]['F']==row['F'] and cfgs[row['config_id']]['CR']==row['CR']):bad.append(row['run_id'])
check('All 640 saved best vectors and configuration metadata exact',not bad,bad)
qs=[np.load(D/q['authoritative_file']) for q in P['new_rotations']]+[np.load(D/'reused_source/inputs/Q.npy')]
check('Three new rotations and historical Q are pairwise distinct',all(not np.array_equal(qs[i],qs[j]) for i in range(4) for j in range(i+1,4)),{'matrices':4,'pairwise_comparisons':6})
formal=[json.loads(s) for s in (S/'raw/formal_batches.jsonl').read_text().splitlines()];derived=read(S/'raw/round_group_sensitivity.json');bad=[];fields=0
for r in derived:
 rr=[b for b in formal if b['round']==r['round'] and (r['weight']=='all' or b['weight']==r['weight'])]
 for clock in ['wall_ns','cpu_ns','thread_cpu_ns']:
  sums={a:sum(b[clock]/b['repetitions'] for b in rr if b['algorithm']==a) for a in ['dijkstra','astar_manhattan','astar_turn']}
  for a,v in sums.items():
   fields+=1
   if not math.isclose(v,r[clock+'_sum_per_search'][a],rel_tol=1e-12):bad.append([r['weight'],r['round'],clock,a])
  fields+=1
  if not math.isclose(sums['astar_turn']/sums['astar_manhattan'],r[clock+'_turn_manhattan_ratio'],rel_tol=1e-12):bad.append([r['weight'],r['round'],clock,'ratio'])
check('Per-round report sensitivity independently recomputed',not bad,{'groups':len(derived),'fields_compared':fields,'mismatch':bad})
result={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'all_passed':all(c['passed'] for c in checks),'checks':checks,'resource':{'cpu_seconds':time.process_time()-cpu,'wall_seconds':time.monotonic()-start},'clock_interpretation':'Positive timers and internal consistency are necessary checks, not independent hardware calibration. Process CPU includes all process activity and is not isolated search-kernel CPU. Main-thread CPU agrees closely with wall; use wall as principal performance evidence.'}
(A/'supplement_checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'all_passed':result['all_passed'],'checks':len(checks),'resource':result['resource']}))
