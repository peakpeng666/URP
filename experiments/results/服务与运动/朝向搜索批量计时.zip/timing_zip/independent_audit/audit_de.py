from pathlib import Path
import json,hashlib,math,statistics,itertools,collections
import numpy as np
from independent_kernels import objective,de_replay
ROOT=Path(__file__).resolve().parent.parent
D=ROOT/'independent_de_multi_rotation_20261006'
A=Path(__file__).resolve().parent

def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 P=read(D/'protocol.json'); freeze=read(D/'PRE_RUN_MANIFEST.json');receipt=read(D/'provenance/execution_attempt_01.json')
 checks=[]
 def check(name,passed,detail=None):
  checks.append({'check':name,'passed':bool(passed),'detail':detail})
 def near(a,b):return math.isclose(float(a),float(b),rel_tol=1e-10,abs_tol=1e-10)
 mismatch=[n for n,e in freeze['files'].items() if sha(D/n)!=e['sha256'] or (D/n).stat().st_size!=e['bytes']]
 check('Frozen file bytes unchanged',not mismatch,mismatch)
 check('Recorded freeze predates execution',freeze['frozen_at_utc']<receipt['start_utc'],{'freeze':freeze['frozen_at_utc'],'start':receipt['start_utc'],'end':receipt.get('end_utc'),'caveat':'Local self-recorded timestamps, not externally certified'})
 recovery=read(D/'provenance/statistics_recovery_external_receipt.json')
 check('Formal failure retained and read-only recovery completed within combined budget',receipt['status']=='failed' and receipt['return_code']==1 and (D/'results/first_failure.json').exists() and recovery['exit_code']==0 and receipt['child_cpu_seconds']+recovery['cpu_seconds']<120,{'formal':receipt,'recovery':recovery})
 summary=read(D/'results/summary.json');rows=[json.loads(s) for s in (D/'results/runs.jsonl').read_text().splitlines()];reuse=read(D/'results/reused_runs.json')
 ids=[c['id'] for c in P['configs']];seeds=P['search_seeds'];families=P['families'];qs=[q['id'] for q in P['new_rotations']]
 expected=set(itertools.product(families,qs,ids,seeds))
 actual=[(r['family'],r['group'],r['config_id'],r['seed']) for r in rows]
 check('Exact new Cartesian grid, unique, 384 rows',len(actual)==384 and len(set(actual))==384 and set(actual)==expected,{'expected':384,'actual':len(rows)})
 check('Old controls and historical Q accounted separately',len(reuse)==256 and collections.Counter(r['group'] for r in reuse)=={'axis':128,'old_rotation':128},dict(collections.Counter(r['group'] for r in reuse)))
 check('New optimization FE',sum(r['fe'] for r in rows)==768000 and all(r['fe']==2000 for r in rows),sum(r['fe'] for r in rows))
 check('No recorded failed or missing runs',summary['new_failed_optimization_runs']==0 and summary['new_unexecuted_runs']==0,{'failed':summary['new_failed_optimization_runs'],'unexecuted':summary['new_unexecuted_runs']})
 old=ROOT/'independent_de_rotation_sensitivity_20261006'
 tapes={s:dict(np.load(D/f'inputs/random_tape_{s}.npz')) for s in seeds}
 check('Unchanged initial populations and operator tapes',all(sha(D/f'inputs/random_tape_{s}.npz')==sha(old/f'inputs/random_tape_{s}.npz') for s in seeds),seeds)
 matrices={}
 for r in P['new_rotations']:
  q=np.load(D/r['authoritative_file']);matrices[r['id']]=q
  regen,rr=np.linalg.qr(np.random.Generator(np.random.PCG64(r['seed'])).normal(size=(10,10)));regen*=np.where(np.diag(rr)<0,-1.,1.)[None,:]
  if np.linalg.det(regen)<0:regen[:,-1]*=-1
  check('Frozen Q regeneration '+r['id'],np.array_equal(q,regen) and np.max(np.abs(q.T@q-np.eye(10)))<1e-12 and abs(np.linalg.det(q)-1)<1e-12,{'seed':r['seed'],'max_orthogonality_error':float(np.max(np.abs(q.T@q-np.eye(10))))})
 allrows=reuse+rows;logs={};rowkeys={};raw_errors=[];maxrel=0.;maxabs=0.;replayresults=[];maxlog=0.
 for row in allrows:
  p=D/row['output_file'];key=(row['family'],row['group'],row['config_id'],row['seed']); rowkeys[key]=row
  with np.load(p) as z:
   rawloss=float(min(z['final_fitness']));logs[key]=math.log10(rawloss+1e-12)
   valid=sha(p)==row['output_sha256'] and near(row['final_best_loss'],rawloss) and z['final_population'].shape==(20,10) and z['final_fitness'].shape==(20,) and z['eval_values'].shape==(100,20) and z['curve_best_loss'].shape==(100,)
   valid=valid and np.all(np.isfinite(z['eval_values'])) and np.all(z['eval_values']>=0) and np.all(np.abs(z['final_population'])<=5) and np.allclose(np.minimum.accumulate(np.min(z['eval_values'],axis=1)),z['curve_best_loss'],rtol=1e-12,atol=1e-12) and near(z['curve_best_loss'][-1],rawloss)
   valid=valid and str(z['point_batch_sha256'][0])==hashlib.sha256(tapes[row['seed']]['initial_population'].astype('<f8').tobytes()).hexdigest()
   if not valid:raw_errors.append(row['run_id'])
   if row['group'] not in qs:continue
   vals=objective(z['final_population'],row['family'],matrices[row['group']]);diff=np.abs(vals-z['final_fitness'])
   maxabs=max(maxabs,float(max(diff)));maxrel=max(maxrel,float(max(diff/np.maximum(np.abs(vals),1e-300))))
   if not np.allclose(vals,z['final_fitness'],rtol=1e-10,atol=1e-10):raw_errors.append(row['run_id']+' scalar objective')
   if row['seed']==seeds[0] and row['config_id'] in ('F0.4_CR0.1','F1.0_CR0.9'):
    rr=de_replay(tapes[row['seed']],row['F'],row['CR'],row['family'],matrices[row['group']])
    samepop=np.array_equal(rr['final_population'],z['final_population']);samehash=np.array_equal(rr['point_batch_sha256'],z['point_batch_sha256'])
    good=samepop and samehash and all(np.allclose(rr[k],z[k],rtol=1e-9,atol=1e-9) for k in ('final_fitness','curve_best_loss','eval_values'))
    replayresults.append({'run_id':row['run_id'],'passed':bool(good),'population_byte_equal':bool(samepop),'all_100_point_batch_hashes_equal':bool(samehash),'max_fitness_abs':float(np.max(np.abs(rr['final_fitness']-z['final_fitness']))),'max_eval_abs':float(np.max(np.abs(rr['eval_values']-z['eval_values'])))})
 check('All 640 raw records, curves, initial tape hashes and 384 scalar population checks',not raw_errors,{'errors':raw_errors,'new_final_vectors':7680,'max_relative_objective_difference':maxrel,'max_absolute_objective_difference':maxabs})
 check('12 independently implemented full DE replays',len(replayresults)==12 and all(r['passed'] for r in replayresults),replayresults)
 primary=read(D/'results/analysis.json');stats={};stat_errors=[];ncompare=0
 def assertnear(a,b,label):
  nonlocal ncompare
  ncompare+=1
  if not near(a,b):stat_errors.append({'field':label,'recomputed':a,'reported':b})
 for fam in families:
  groups=['axis','old_rotation']+qs;gs={};out={};pa=primary[fam]
  for g in groups:
   score={c:math.fsum(logs[fam,g,c,s] for s in seeds)/len(seeds) for c in ids};order=sorted(ids,key=lambda c:(score[c],c));rank={c:i+1 for i,c in enumerate(order)}
   gs[g]={'scores':score,'ranks':rank,'order':order}
   for c in ids:
    assertnear(score[c],pa['groups'][g]['scores'][c],f'{fam}/{g}/{c}/score');assertnear(rank[c],pa['groups'][g]['ranks'][c],f'{fam}/{g}/{c}/rank')
   assertnear(len(ids)-len(set(score.values())),pa['groups'][g]['exact_score_ties'],f'{fam}/{g}/ties')
  comps=[]
  for g,h in itertools.combinations(groups,2):
   rho=1-6*sum((gs[g]['ranks'][c]-gs[h]['ranks'][c])**2 for c in ids)/(16*(16**2-1));inv=sum((gs[g]['ranks'][a]-gs[g]['ranks'][b])*(gs[h]['ranks'][a]-gs[h]['ranks'][b])<0 for a,b in itertools.combinations(ids,2))
   reported=next(r for r in pa['rank_comparisons'] if r['a']==g and r['b']==h)
   assertnear(rho,reported['spearman'],f'{fam}/{g}:{h}/rho');assertnear(inv,reported['inversions'],f'{fam}/{g}:{h}/inversions')
   comps.append({'a':g,'b':h,'rho':rho,'inversions':inv})
  ds_bygroup={}
  for g in groups[1:]:
   ds_bygroup[g]=[]
   for c in ids:
    ds=[logs[fam,g,c,s]-logs[fam,'axis',c,s] for s in seeds];ds_bygroup[g]+=ds
    config=next(r for r in pa['config_pairs'] if r['group']==g and r['config_id']==c)
    for key,value in [('mean',statistics.mean(ds)),('median',statistics.median(ds)),('min',min(ds)),('max',max(ds)),('rank_change',gs[g]['ranks'][c]-gs['axis']['ranks'][c])]:assertnear(value,config[key],f'{fam}/{g}/{c}/{key}')
    for seed,d in zip(seeds,ds):
     reported=next(r for r in pa['paired'] if r['group']==g and r['config_id']==c and r['seed']==seed)
     assertnear(d,reported['delta'],f'{fam}/{g}/{c}/{seed}/paired')
  pooled={c:statistics.mean(gs[g]['scores'][c] for g in qs) for c in ids};pooled_order=sorted(ids,key=lambda c:(pooled[c],c));stability=[]
  for c in ids:
   ranks=[gs[g]['ranks'][c] for g in qs];axis=gs['axis']['ranks'][c];vals={'axis_rank':axis,'new_rank_mean':statistics.mean(ranks),'new_rank_min':min(ranks),'new_rank_max':max(ranks),'top1_count':ranks.count(1),'rank_worse_count':sum(r>axis for r in ranks),'rank_better_count':sum(r<axis for r in ranks),'rank_equal_count':sum(r==axis for r in ranks),'pooled_new_score':pooled[c],'pooled_new_rank':pooled_order.index(c)+1}
   reported=next(r for r in pa['stability'] if r['config_id']==c)
   for k,v in vals.items():assertnear(v,reported[k],f'{fam}/{c}/stability/{k}')
   for a,b in zip(ranks,reported['new_ranks']):assertnear(a,b,f'{fam}/{c}/new_rank')
   stability.append({'config_id':c,'new_ranks':ranks,**vals})
  ds_bygroup['new_pooled']=[d for g in qs for d in ds_bygroup[g]];pairedsummary={}
  for g,ds in ds_bygroup.items():
   vals={'n':len(ds),'mean':statistics.mean(ds),'median':statistics.median(ds),'min':min(ds),'max':max(ds),'positive':sum(d>0 for d in ds),'negative':sum(d<0 for d in ds),'zero':sum(d==0 for d in ds)};pairedsummary[g]=vals
   reported=pa['new_paired_summary'] if g=='new_pooled' else pa['paired_summary'][g]
   for k,v in vals.items():
    assertnear(v,reported[k],f'{fam}/{g}/summary/{k}')
  stats[fam]={'groups':gs,'rank_comparisons':comps,'paired_summary':pairedsummary,'stability':stability,'pooled_new_order':pooled_order}
 check('Independent complete statistical recomputation',not stat_errors,{'numeric_fields_compared':ncompare,'errors':stat_errors,'caveat':'Canonical math.log10 matches recovered analysis. Sphere positive/negative/zero counts remain rounding-sensitive and are not scientific signs.'})
 result={'checks':checks,'all_passed':all(c['passed'] for c in checks),'statistics':stats,'auditor_validation_fe':7680+24000,'replay_count':12,'author_validation_fe':summary['new_validation_fe']}
 (A/'de_checks.json').write_text(json.dumps(result,indent=2)+'\n')
 print('DE',result['all_passed'],'checks',len(checks),'statistical fields',ncompare)
 return result
if __name__=='__main__':main()
