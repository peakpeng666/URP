from pathlib import Path
import json,hashlib,datetime,resource,signal,time
resource.setrlimit(resource.RLIMIT_CPU,(120,120));signal.alarm(300)
A=Path(__file__).resolve().parent;R=A.parent
start=time.monotonic();cpu=time.process_time()
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
authors={'independent_de_multi_rotation_20261006':'592d81155938650ce64b488b244562a67290c9c6107571fbb782be88ae98d8b3','independent_turn_search_timing_20261006':'aca9fa16601c768d8f123b0a50e3187851b48d97ff647673985a90313a4116d7'}
pins={};checks=[]
for directory,expectedhash in authors.items():
 root=R/directory;m=read(root/'MANIFEST.json');bad=[]
 for name,entry in m['files'].items():
  p=root/name
  if sha(p)!=entry['sha256'] or p.stat().st_size!=entry['bytes']:bad.append(name)
 for p in sorted(root.rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts:pins[str(p.relative_to(R))]={'sha256':sha(p),'bytes':p.stat().st_size}
 checks.append({'check':'Author final manifest '+directory,'passed':not bad and sha(root/'MANIFEST.json')==expectedhash,'files_checked':len(m['files']),'mismatches':bad,'manifest_sha256':sha(root/'MANIFEST.json')})
d=read(A/'timing_checks.json')['clock_diagnostics'];report=read(R/'independent_turn_search_timing_20261006/raw/clock_comparison_diagnostic.json')
checks.append({'check':'Final report clock diagnostic agrees with independent diagnostic','passed':all(report[k][rk]==d[k][dk] for k in ['cpu_ns','thread_cpu_ns'] for rk,dk in [('median','median_ratio_to_wall'),('minimum','min_ratio_to_wall'),('maximum','max_ratio_to_wall')])})
(A/'sourcepins.json').write_text(json.dumps({'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_root':str(R),'files':pins,'old_files_separately_pinned':'old_sourcepins.json','author_final_manifests':authors},indent=2)+'\n')
allchecks=read(A/'de_checks.json')['checks']+read(A/'timing_checks.json')['checks']+read(A/'supplement_checks.json')['checks']+checks
result={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'all_passed':all(c['passed'] for c in allchecks),'check_count':len(allchecks),'checks':allchecks,'sourcepin_count':len(pins),'finalization_resource':{'cpu_seconds':time.process_time()-cpu,'wall_seconds':time.monotonic()-start},'publication_status':'Publishable only as bounded synthetic descriptive experiments, with documented DE statistics recovery and timing launcher failure, no universal/significance claim; process CPU is whole-process indicator, not isolated kernel CPU.'}
(A/'checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'all_passed':result['all_passed'],'checks':len(allchecks),'sourcepins':len(pins),'final_checks':checks,'resource':result['finalization_resource']}))
