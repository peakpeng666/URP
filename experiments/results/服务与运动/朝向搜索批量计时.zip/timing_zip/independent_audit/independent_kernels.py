"""Independently authored validation kernels. Does not import either experiment."""
from heapq import heappush, heappop
from itertools import permutations
import math
import hashlib
import numpy as np


def objective(points, family, q):
    weights=[10.0**(6.0*k/9.0) if family=='ellipsoid' else 1.0 for k in range(10)]
    ans=[]
    for point in points:
        z=[sum(float(q[i,j])*float(point[j]) for j in range(10)) for i in range(10)] if q is not None else list(point)
        ans.append(sum(weights[i]*float(z[i])*float(z[i]) for i in range(10)))
    return np.array(ans)


def de_replay(tape, scale, crossover, family, q):
    population=tape['initial_population'].tolist()
    fitness=objective(population,family,q).tolist()
    curve=[min(fitness)]; all_values=[fitness.copy()]; batch_hashes=[hashlib.sha256(np.array(population,dtype='<f8').tobytes()).hexdigest()]
    for generation in range(99):
        trials=[]
        for target in range(20):
            available=[j for j in range(20) if j!=target]
            donors=[]
            for field in ['donor_rank_a','donor_rank_b','donor_rank_c']:
                donors.append(available.pop(int(tape[field][generation,target])))
            a,b,c=donors
            proposed=[]
            for dimension in range(10):
                take=(float(tape['crossover_uniform'][generation,target,dimension]) < crossover or dimension==int(tape['forced_coordinate'][generation,target]))
                value=population[a][dimension]+scale*(population[b][dimension]-population[c][dimension]) if take else population[target][dimension]
                proposed.append(max(-5.0,min(5.0,value)))
            trials.append(proposed)
        values=objective(trials,family,q).tolist(); all_values.append(values); batch_hashes.append(hashlib.sha256(np.array(trials,dtype='<f8').tobytes()).hexdigest())
        for i in range(20):
            if values[i]<fitness[i]:
                population[i]=trials[i];fitness[i]=values[i]
        curve.append(min(fitness))
    return {'final_population':np.array(population),'final_fitness':np.array(fitness),'curve_best_loss':np.array(curve),'eval_values':np.array(all_values),'point_batch_sha256':np.array(batch_hashes),'fe':2000}


VECTORS=((1,0),(0,1),(-1,0),(0,-1))

def turn_cost(a,b):
    dot=VECTORS[a][0]*VECTORS[b][0]+VECTORS[a][1]*VECTORS[b][1]
    return 1-dot


def relaxed_h(state, goal, weight, algorithm):
    if algorithm=='dijkstra':return 0
    dx=goal[0]-state[0];dy=goal[1]-state[1]
    distance=abs(dx)+abs(dy)
    if algorithm=='astar_manhattan' or distance==0:return distance
    headings=([0 if dx>0 else 2] if dx else [])+([1 if dy>0 else 3] if dy else [])
    best=min(sum(turn_cost(u,v) for u,v in zip((state[2],)+p,p)) for p in permutations(headings))
    return distance+weight*best


def search_replay(rows,start,goal,weight,algorithm):
    start=tuple(start);goal=tuple(goal);n=len(rows)
    distances={start:0};parents={};queue=[(relaxed_h(start,goal,weight,algorithm),0,*start,0)]
    visited=set();serial=0; terminal=None
    counts={'expansions':0,'accepted_pops':0,'stale_pops':0,'heap_pushes':1,'max_heap':1,'reexpansions':0,'successor_candidates':0,'traversable_successors':0}
    while queue:
        record=heappop(queue);g=record[1];state=tuple(record[2:5])
        if distances[state]!=g:
            counts['stale_pops']+=1;continue
        counts['accepted_pops']+=1
        if state[:2]==goal:terminal=state;break
        counts['expansions']+=1;counts['reexpansions']+=int(state in visited);visited.add(state)
        for heading in range(4):
            counts['successor_candidates']+=1
            nextstate=(state[0]+VECTORS[heading][0],state[1]+VECTORS[heading][1],heading)
            x,y,_=nextstate
            if not (0<=x<n and 0<=y<n and rows[y][x]=='.'):continue
            counts['traversable_successors']+=1
            newcost=g+1+weight*turn_cost(state[2],heading)
            if nextstate not in distances or newcost<distances[nextstate]:
                distances[nextstate]=newcost;parents[nextstate]=state;serial+=1
                heappush(queue,(newcost+relaxed_h(nextstate,goal,weight,algorithm),newcost,*nextstate,serial))
                counts['heap_pushes']+=1;counts['max_heap']=max(counts['max_heap'],len(queue))
    path=[]
    if terminal is not None:
        step=terminal
        while True:
            path.append(list(step))
            if step==start:break
            step=parents[step]
        path.reverse()
    return {'reachable':terminal is not None,'cost':distances[terminal] if terminal is not None else None,'path':path,**counts}
