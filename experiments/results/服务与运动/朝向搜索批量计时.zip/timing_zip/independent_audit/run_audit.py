import resource,signal,time,json,datetime,hashlib,traceback
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CPU,(120,120));signal.alarm(300)
A=Path(__file__).resolve().parent
start=time.monotonic();u0=resource.getrusage(resource.RUSAGE_SELF)
source={p.name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in A.glob('*.py')}
(A/'AUDIT_EXECUTION_FREEZE.json').write_text(json.dumps({'created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':source,'limits':{'cpu_seconds':120,'wall_seconds':300},'no_author_imports':True},indent=2)+'\n')
try:
 import audit_de,audit_timing
 de=audit_de.main();timing=audit_timing.main()
 status='passed' if de['all_passed'] and timing['all_passed'] else 'findings'
except BaseException:
 status='audit_script_error';(A/'AUDIT_SCRIPT_ERROR.txt').write_text(traceback.format_exc());raise
finally:
 u1=resource.getrusage(resource.RUSAGE_SELF)
 (A/'audit_resource_usage.json').write_text(json.dumps({'status':status,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'wall_seconds':time.monotonic()-start,'user_cpu_seconds':u1.ru_utime-u0.ru_utime,'system_cpu_seconds':u1.ru_stime-u0.ru_stime,'total_cpu_seconds':u1.ru_utime-u0.ru_utime+u1.ru_stime-u0.ru_stime,'max_rss_kib':u1.ru_maxrss,'cpu_hard_limit_seconds':120,'wall_alarm_seconds':300,'note':'Independent audit validation; not new scientific samples; excludes script preparation/reporting.'},indent=2)+'\n')
