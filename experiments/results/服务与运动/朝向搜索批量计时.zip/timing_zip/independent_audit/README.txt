Independent audit of the DE three-rotation extension and turn-search timing extension.
Read REPORT_ZH.md first; checks.json contains all 36 passing checks.
sourcepins.json pins the final author deliverables; old_sourcepins.json pins unchanged old sources.
All computation is validation only, not extra scientific samples. No author source or data is modified.
The final conclusion is qualified publication: preserve all disclosed failures and limits, and use wall time as the principal timing evidence.
