from pathlib import Path
import json,hashlib,math,statistics,itertools,collections
from independent_kernels import search_replay, turn_cost
ROOT=Path(__file__).resolve().parent.parent
D=ROOT/'independent_turn_search_timing_20261006';A=Path(__file__).resolve().parent
ALGS=['dijkstra','astar_manhattan','astar_turn'];PERMS=list(itertools.permutations(ALGS))
def read(p):return json.loads(p.read_text())
def jl(p):return [json.loads(l) for l in p.read_text().splitlines()]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def canonsha(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
def main():
 checks=[]
 def check(name,passed,detail=None):checks.append({'check':name,'passed':bool(passed),'detail':detail})
 F=read(D/'PRE_RUN_FREEZE.json');C=read(D/'CALIBRATION_FREEZE.json');E=read(D/'checks/environment.json');usage=read(D/'checks/resource_usage.json');P=read(D/'checks/post_run_checks.json');S=read(D/'raw/summary.json')
 cases=read(D/'inputs/cases.json');mapslist=read(D/'inputs/maps.json');maps={m['map_id']:m for m in mapslist};cids=[c['case_id'] for c in cases];case_byid={c['case_id']:c for c in cases}
 warm=jl(D/'raw/warmup.jsonl');cal=jl(D/'raw/calibration.jsonl');formal=jl(D/'raw/formal_batches.jsonl');oracle=jl(D/'raw/oracles.jsonl');baselist=read(D/'raw/canonical_results.json');base={(b['case_id'],b['algorithm']):b['result'] for b in baselist}
 bad=[n for n,m in F['files'].items() if sha(D/n)!=m['sha256'] or (D/n).stat().st_size!=m['bytes']]
 check('Frozen source and inputs unmodified',not bad,bad)
 check('Recorded source freeze before Python start and calibration freeze',F['created_utc']<E['start_utc']<C['frozen_utc'],{'source_freeze':F['created_utc'],'python_start':E['start_utc'],'calibration_freeze':C['frozen_utc'],'caveat':'Local timestamps and frozen source execution order, not trusted external timestamping.'})
 check('Calibration records and baseline hashed before formal stage',C['pre_run_freeze_sha256']==sha(D/'PRE_RUN_FREEZE.json') and C['calibration_sha256']==sha(D/'raw/calibration.jsonl') and C['canonical_results_sha256']==sha(D/'raw/canonical_results.json'))
 check('Original failed wrapper retained; sole solver succeeded',read(D/'LAUNCH_EXIT.json')['exit_code']==127 and read(D/'PYTHON_LAUNCH_EXIT.json')['exit_code']==0 and not (D/'checks/FAILURE.json').exists(),{'outer_exit':127,'python_exit':read(D/'PYTHON_LAUNCH_EXIT.json')['exit_code'],'amendment':read(D/'LAUNCHER_AMENDMENT.json')})
 check('Numerical CPU below 110 second process and 120 second author budget',usage['process_cpu_seconds']<110 and E['rlimit_cpu']==[110,110],usage)
 check('Complete input set and prelude counts',len(cases)==72 and len(maps)==24 and len(base)==216 and len(warm)==216 and len(cal)==432 and len(oracle)==72,{'maps':len(maps),'cases':len(cases),'baselines':len(base),'warmup_batches':len(warm),'calibration_batches':len(cal),'oracles':len(oracle)})
 old=ROOT/'independent_turn_aware_search_20261006';oldbase={(r['case_id'],r['algorithm']):r for r in jl(old/'outputs/main_runs.jsonl') if r['repeat']==0}
 same=True;patherrors=[]
 for (cid,alg),res in base.items():
  same=same and all(res[k]==oldbase[cid,alg][k] for k in res)
  c=case_byid[cid];m=maps[c['map_id']];path=res['path']
  if res['reachable']:
   ok=bool(path) and path[0]==m['start'] and path[-1][:2]==m['goal'];cost=0
   for aa,bb in zip(path,path[1:]):
    dx=bb[0]-aa[0];dy=bb[1]-aa[1];expected=[(1,0),(0,1),(-1,0),(0,-1)][bb[2]]
    ok=ok and (dx,dy)==expected and 0<=bb[0]<m['n'] and 0<=bb[1]<m['n'] and m['rows'][bb[1]][bb[0]]=='.'
    cost+=1+c['weight']*turn_cost(aa[2],bb[2])
   ok=ok and cost==res['cost']
  else:ok=not path and res['cost'] is None
  if not ok:patherrors.append([cid,alg])
 check('All 216 representative deterministic results match old runs and paths independently legal',same and not patherrors,{'path_errors':patherrors})
 check('Three unreachable problems retained',sum(not base[cid,'dijkstra']['reachable'] for cid in cids)==3)
 scheduleerrors=[];N={};estimate={}
 for i,cid in enumerate(cids):
  for alg in ALGS:
   ww=[r for r in warm if r['case_id']==cid and r['algorithm']==alg];cc=[r for r in cal if r['case_id']==cid and r['algorithm']==alg]
   ok=len(ww)==1 and ww[0]['repetitions']==1 and ww[0]['order']==PERMS[i%6].index(alg) and len(cc)==2
   for cr in range(2):
    rr=[r for r in cc if r['calibration_round']==cr]
    ok=ok and len(rr)==1 and rr[0]['repetitions']==8 and rr[0]['order']==PERMS[(i+cr)%6].index(alg)
   if not ok:scheduleerrors.append([cid,alg,'prelude order'])
   t=min(r['wall_ns']/r['repetitions'] for r in cc);n=min(20000,max(4,math.ceil(40_000_000/t)));N[cid,alg]=n;estimate[cid,alg]=t
   plan=next(r for r in C['plan'] if r['case_id']==cid and r['algorithm']==alg)
   if n!=plan['repetitions'] or t!=plan['calibration_ns_per_search']:scheduleerrors.append([cid,alg,'N'])
 est=sum(N[k]*estimate[k] for k in N)/1e9;cpu=C['cpu_seconds_at_freeze'];planned=6 if cpu+1.5*6*est+5<=100 else (3 if cpu+1.5*3*est+5<=100 else 0)
 check('Warmup, calibration, N and round-selection follow frozen rules',not scheduleerrors and math.isclose(est,C['estimated_round_seconds'],rel_tol=1e-14) and planned==C['selected_rounds'],{'errors':scheduleerrors,'recomputed_estimated_round_seconds':est,'selected_rounds':planned})
 rounds=len(formal)//216;expected=[]
 for r in range(rounds):
  indices=list(range(72));shift=12*r%72;indices=indices[shift:]+indices[:shift]
  if r%2:indices.reverse()
  for pos,i in enumerate(indices):
   for apos,alg in enumerate(PERMS[(i+r)%6]):expected.append((r,i,pos,apos,cids[i],alg))
 badformal=[]
 for idx,(row,exp) in enumerate(zip(formal,expected)):
  actual=(row['round'],row['case_index'],row['case_position'],row['algorithm_position'],row['case_id'],row['algorithm']);key=row['case_id'],row['algorithm']
  if actual!=exp or row['batch_id']!=idx or row['repetitions']!=N[key] or row['path_checks']!=N[key] or not row['all_results_identical'] or row['result_sha256']!=canonsha(base[key]) or row['expansions_per_search']!=base[key]['expansions'] or row['heap_pushes_per_search']!=base[key]['heap_pushes']:badformal.append(idx)
 check('Complete formal grid, balanced declared order, fixed N and result identity',len(formal) in (648,1296) and len(formal)==len(expected) and not badformal,{'rounds':rounds,'formal_batches':len(formal),'bad_batches':badformal,'full_six_permutation_balance':rounds==6})
 actualcounts={'oracles':72,'warmup_searches':sum(r['repetitions'] for r in warm),'calibration_searches':sum(r['repetitions'] for r in cal),'formal_searches':sum(r['repetitions'] for r in formal),'path_checks':sum(r['repetitions'] for r in warm+cal+formal),'batch_checks':len(warm+cal+formal)}
 check('All measured calls accounted without treating repeats as new cases',actualcounts==S['counts']==P['counts']==usage['counts'],actualcounts)
 clocks=['wall_ns','cpu_ns','thread_cpu_ns'];clockstats={}
 for k in clocks:
  vals=[r[k] for r in formal];ratio=[r[k]/r['wall_ns'] for r in formal if r['wall_ns']>0]
  clockstats[k]={'zero_batches':sum(v==0 for v in vals),'negative_batches':sum(v<0 for v in vals),'min_ns':min(vals),'max_ns':max(vals),'sum_ns':sum(vals),'median_ratio_to_wall':statistics.median(ratio),'min_ratio_to_wall':min(ratio),'max_ratio_to_wall':max(ratio),'unique_values':len(set(vals))}
 reliable=all(clockstats[k]['zero_batches']==0 and clockstats[k]['negative_batches']==0 for k in clocks)
 check('All batch clocks positive, no zero interpolation',reliable,clockstats)
 pairs=[];errors=[];comparisons=0;reported_pairs={r['case_id']:r for r in read(D/'raw/paired_cases.json')}
 def eq(a,b,key):
  nonlocal comparisons
  comparisons+=1
  if isinstance(a,(float,int)) and not isinstance(a,bool):ok=b is not None and math.isclose(float(a),float(b),rel_tol=1e-12,abs_tol=1e-9)
  else:ok=a==b
  if not ok:errors.append({'field':key,'expected':a,'reported':b})
 for cid in cids:
  c=case_byid[cid];m=maps[c['map_id']];rec={**c,'n':m['n'],'obstacle_probability':m['obstacle_probability'],'reachable':base[cid,'dijkstra']['reachable']}
  for alg in ALGS:
   rr=[r for r in formal if (r['case_id'],r['algorithm'])==(cid,alg)]
   for k in clocks:
    vals=[r[k]/r['repetitions'] for r in rr]
    for name,fn in [('median',statistics.median),('min',min),('max',max)]:rec[alg+'_'+k+'_'+name]=fn(vals)
   for k in ['expansions','heap_pushes']:rec[alg+'_'+k]=base[cid,alg][k]
  rec['turn_wall_ratio_to_manhattan']=rec['astar_turn_wall_ns_median']/rec['astar_manhattan_wall_ns_median']
  rec['turn_cpu_ratio_to_manhattan']=rec['astar_turn_cpu_ns_median']/rec['astar_manhattan_cpu_ns_median'] if reliable else None
  rec['fewer_expansions_but_wall_slower']=rec['astar_turn_expansions']<rec['astar_manhattan_expansions'] and rec['turn_wall_ratio_to_manhattan']>1
  for k,v in rec.items():eq(v,reported_pairs[cid][k],cid+'/'+k)
  pairs.append(rec)
 groups=[]
 criteria=[('all','all')]+[('weight',v) for v in [0,2,8]]+[('n',v) for v in [16,32,48]]+[('obstacle_probability',v) for v in [.1,.25]]
 for key,value in criteria:
  pp=[p for p in pairs if key=='all' or p[key]==value];totals={a:{k:sum(p[a+'_'+k+'_median'] for p in pp) for k in clocks} for a in ALGS}
  for alg in ALGS:
   for k in ['expansions','heap_pushes']:totals[alg][k]=sum(p[alg+'_'+k] for p in pp)
  reductions={k:1-totals['astar_turn'][k]/totals['astar_manhattan'][k] for k in clocks+['expansions','heap_pushes']}
  r={'group_by':key,'value':value,'cases':len(pp),'totals':totals,'turn_reduction_vs_manhattan':reductions,'median_case_wall_ratio':statistics.median(p['turn_wall_ratio_to_manhattan'] for p in pp),'wall_win_tie_loss':[sum(p['turn_wall_ratio_to_manhattan']<1 for p in pp),sum(p['turn_wall_ratio_to_manhattan']==1 for p in pp),sum(p['turn_wall_ratio_to_manhattan']>1 for p in pp)],'fewer_expansions_but_wall_slower':sum(p['fewer_expansions_but_wall_slower'] for p in pp)}
  reported=next(g for g in S['groups'] if g['group_by']==key and g['value']==value)
  for alg in ALGS:
   for k,v in totals[alg].items():eq(v,reported['totals'][alg][k],str((key,value,alg,k)))
  for k,v in reductions.items():eq(v,reported['turn_reduction_vs_manhattan'][k],str((key,value,k)))
  for k in ['cases','median_case_wall_ratio','wall_win_tie_loss','fewer_expansions_but_wall_slower']:eq(r[k],reported[k],str((key,value,k)))
  groups.append(r)
 exceptions=[p['case_id'] for p in pairs if p['fewer_expansions_but_wall_slower']];eq(exceptions,S['fewer_expansions_but_wall_slower_cases'],'exceptions')
 check('Independent complete batch-normalized statistics and contrary cases',not errors,{'compared_fields':comparisons,'errors':errors,'fewer_expansions_but_wall_slower_cases':exceptions})
 selected=[]
 for n in [16,32,48]:
  ms=[m for m in mapslist if m['n']==n];selected.extend([ms[0]['map_id'],ms[-1]['map_id']])
 replays=[]
 for c in cases:
  if c['map_id'] not in selected:continue
  m=maps[c['map_id']]
  for alg in ALGS:
   got=search_replay(m['rows'],m['start'],m['goal'],c['weight'],alg);expected=base[c['case_id'],alg]
   replays.append({'case_id':c['case_id'],'algorithm':alg,'passed':got==expected,'reachable':got['reachable'],'cost':got['cost'],'expansions':got['expansions'],'all_path_and_counter_fields_exact':got==expected})
 check('54 independently implemented selected search replays',len(replays)==54 and all(r['passed'] for r in replays),replays)
 result={'checks':checks,'all_passed':all(c['passed'] for c in checks),'recomputed_groups':groups,'recomputed_counts':actualcounts,'clock_diagnostics':clockstats,'independent_replay_calls':54,'scope':'72 correlated problems from 24 maps and 4 reused map seeds. Repeated batches are not independent maps. Timing describes this session and protocol only.'}
 (A/'timing_checks.json').write_text(json.dumps(result,indent=2)+'\n');print('Timing',result['all_passed'],'checks',len(checks),'statistical fields',comparisons)
 return result
if __name__=='__main__':main()
