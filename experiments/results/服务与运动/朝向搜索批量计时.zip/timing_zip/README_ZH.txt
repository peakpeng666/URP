朝向搜索批量计时完整证据

先读 independent_turn_search_timing_20261006/REPORT_ZH.md，再读 independent_audit/REPORT_ZH.md。两项审计均保留在审计目录，36项检查通过；独立重放不计新增实验样本。
原作者目录及其MANIFEST逐字节保留。外层FILE_MANIFEST.json覆盖本ZIP全部材料（自身除外）；运行verify_files.py只做哈希核验。
本包未运行或恢复原132主线，没有模型API请求。源、协议、输入、全部raw、失败记录、验证、成本和独立审计均保留。
