#!/usr/bin/env python3
"""Independent checker: imports no experiment code and uses explicit geometry + exhaustive search."""
import csv, hashlib, itertools, json, math, time
from pathlib import Path


def load(path):
    return json.loads(path.read_text())


def alternatives(a,b):
    a,b=tuple(a),tuple(b)
    assert a!=b
    if a[0]==b[0] or a[1]==b[1]:
        return [(a,b)]
    return [(a,(b[0],a[1]),b),(a,(a[0],b[1]),b)]


def geometry(vertices):
    vectors=[]
    length=0
    for a,b in zip(vertices,vertices[1:]):
        dx,dy=b[0]-a[0],b[1]-a[1]
        assert (dx==0) != (dy==0), 'Path segment must be nonzero and axis-aligned'
        vectors.append((dx,dy))
        length+=math.hypot(dx,dy)
    changes=[]
    for (ax,ay),(bx,by) in zip(vectors,vectors[1:]):
        # Actual unsigned angle, independent of the experiment's heading labels.
        q=math.atan2(abs(ax*by-ay*bx),ax*bx+ay*by)/(math.pi/2)
        assert abs(q-round(q))<1e-10
        changes.append(round(q))
    return length,sum(changes),sum(t>0 for t in changes)


def reconstruct(instance,order,options):
    n=len(instance['tasks'])
    assert sorted(order)==list(range(n))
    assert len(options)==n+1
    stops=[instance['start']]+[instance['tasks'][i] for i in order]+[instance['goal']]
    vertices=[tuple(stops[0])]
    for a,b,op in zip(stops,stops[1:],options):
        choices=alternatives(a,b)
        assert 0<=op<len(choices)
        vertices.extend(choices[op][1:])
    return vertices


def unit_tests():
    tests=[([(0,0),(2,0),(5,0)],(5,0,0)),
           ([(0,0),(2,0),(2,3)],(5,1,1)),
           ([(0,0),(2,0),(0,0)],(4,2,1)),
           ([(0,0),(2,0),(2,2),(4,2),(4,4)],(8,3,3)),
           ([(0,0),(2,0),(2,2),(2,4),(4,4)],(8,2,2))]
    for vertices,expected in tests:
        assert geometry(vertices)==expected
    # Two identical outgoing B->C paths have different junction turn costs
    # when the incoming leg's terminal direction changes; a task-edge-only
    # turn charge cannot encode both.
    assert geometry([(0,2),(2,2),(2,4)])[1]==1
    assert geometry([(2,0),(2,2),(2,4)])[1]==0
    return 7


def exhaustive_minima(instance,lambdas):
    """Enumerate complete orders AND every Cartesian product of leg paths."""
    best={lam:math.inf for lam in lambdas}
    witness={lam:None for lam in lambdas}
    count=0
    for order in itertools.permutations(range(len(instance['tasks']))):
        stops=[instance['start']]+[instance['tasks'][i] for i in order]+[instance['goal']]
        choices=[alternatives(a,b) for a,b in zip(stops,stops[1:])]
        for indices in itertools.product(*(range(len(c)) for c in choices)):
            vertices=[tuple(stops[0])]
            for paths,index in zip(choices,indices):
                vertices.extend(paths[index][1:])
            length,turns,_=geometry(vertices)
            count+=1
            for lam in lambdas:
                score=length+lam*turns
                if score<best[lam]:
                    best[lam]=score
                    witness[lam]={'order':list(order),'leg_options':list(indices)}
    return best,witness,count


def verify_all(root):
    t0,c0=time.perf_counter(),time.process_time()
    ntests=unit_tests()
    hash_checks=[]
    for line in (root/'pre_run.sha256').read_text().splitlines():
        digest,name=line.split('  ',1)
        assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,'Frozen file changed: '+name
        hash_checks.append(name)
    cfg=load(root/'freeze.json')
    instances=load(root/'instances.json')
    by_id={i['instance_id']:i for i in instances}
    routes=[json.loads(line) for line in (root/'routes.jsonl').read_text().splitlines()]
    expected=len(instances)*len(cfg['lambdas'])*len(cfg['strategies'])
    assert len(routes)==expected
    assert len({(r['instance_id'],r['lambda'],r['strategy']) for r in routes})==expected
    raw_csv=list(csv.DictReader((root/'raw_results.csv').open()))
    assert len(raw_csv)==expected
    csv_index={(r['instance_id'],float(r['lambda']),r['strategy']):r for r in raw_csv}
    oracle={(r['instance_id'],r['lambda']):r for r in routes if r['strategy']=='joint_dp_oracle'}
    records={}
    for r in routes:
        assert r['success']
        inst=by_id[r['instance_id']]
        vertices=reconstruct(inst,r['order'],r['leg_options'])
        assert vertices==[tuple(x) for x in r['polyline']]
        length,turns,events=geometry(vertices)
        assert length==r['distance'] and turns==r['turn_quarter_units'] and events==r['turn_events']
        assert abs(r['J']-(length+r['lambda']*turns))<1e-9
        assert r['J']>=oracle[r['instance_id'],r['lambda']]['J']-1e-9
        csvrec=csv_index[r['instance_id'],r['lambda'],r['strategy']]
        assert float(csvrec['J'])==r['J']
        gap=(r['J']-oracle[r['instance_id'],r['lambda']]['J'])/oracle[r['instance_id'],r['lambda']]['J']
        assert abs(float(csvrec['relative_gap_to_oracle'])-gap)<1e-12
        records[r['instance_id'],r['lambda'],r['strategy']]=r
    # Fully independent distance-only enumeration of all 8! orders per main geometry.
    distance_permutations=0
    for inst in instances:
        tasks=inst['tasks']; n=len(tasks)
        pts=tasks+[inst['start'],inst['goal']]
        dist=[[abs(a[0]-b[0])+abs(a[1]-b[1]) for b in pts] for a in pts]
        best=math.inf
        for order in itertools.permutations(range(n)):
            nodes=(n,)+order+(n+1,)
            score=sum(dist[a][b] for a,b in zip(nodes,nodes[1:]))
            best=min(best,score)
            distance_permutations+=1
        for strategy in ['distance_order_fixed_paths','distance_order_heading_paths','turn_2opt','joint_dp_oracle']:
            assert records[inst['instance_id'],0,strategy]['J']==best
        baseline_order=records[inst['instance_id'],0,'distance_order_fixed_paths']['order']
        prev=None
        for lam in cfg['lambdas']:
            a=records[inst['instance_id'],lam,'distance_order_fixed_paths']
            b=records[inst['instance_id'],lam,'distance_order_heading_paths']
            c=records[inst['instance_id'],lam,'turn_2opt']
            o=oracle[inst['instance_id'],lam]
            assert a['order']==b['order']==baseline_order
            assert o['J']<=c['J']<=b['J']<=a['J']
            # Exact linear-penalty optimum cannot increase its selected turn count
            # as positive lambda increases; lambda 0 ties are exempt.
            if prev is not None:
                assert o['J']>=prev['J']
                if prev['lambda']>0:
                    assert o['turn_quarter_units']<=prev['turn_quarter_units']
            prev=o
    dpresults=load(root/'validation_dp_results.json')
    dpi={(r['instance_id'],r['lambda']):r for r in dpresults}
    exhaustive=[]
    candidate_count=0
    for inst in load(root/'validation_instances.json'):
        best,witness,count=exhaustive_minima(inst,cfg['lambdas'])
        candidate_count+=count
        for lam in cfg['lambdas']:
            r=dpi[inst['instance_id'],lam]
            vertices=reconstruct(inst,r['order'],r['leg_options'])
            length,turns,_=geometry(vertices)
            assert r['J']==length+lam*turns
            assert abs(r['J']-best[lam])<1e-9, (inst['instance_id'],lam,r['J'],best[lam])
            exhaustive.append({'instance_id':inst['instance_id'],'lambda':lam,'dp_J':r['J'],
                               'exhaustive_J':best[lam],'candidate_routes':count,
                               'witness':witness[lam],'status':'PASS'})
    with (root/'exhaustive_validation.json').open('w') as f:
        json.dump(exhaustive,f,ensure_ascii=False,indent=2);f.write('\n')
    return {'status':'PASS','unit_tests':ntests,'main_routes_recomputed':len(routes),
            'csv_rows_cross_checked':len(raw_csv),'independent_8task_distance_permutations':distance_permutations,
            'small_joint_optima_checked':len(exhaustive),'small_complete_routes_enumerated':candidate_count,
            'small_route_lambda_evaluations':candidate_count*len(cfg['lambdas']),
            'frozen_hash_checks':hash_checks,'cpu_s':time.process_time()-c0,'wall_s':time.perf_counter()-t0,
            'scope':'Exhaustive joint correctness on 6 five-task cases at all 5 penalties; full geometry/feasibility/objective checks on every main route. Main positive-penalty optima rely on the tested exact DP, not exhaustive 8-task path enumeration.'}

if __name__=='__main__':
    import resource,signal,sys
    resource.setrlimit(resource.RLIMIT_CPU,(170,170));signal.alarm(1150)
    result=verify_all(Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parent)
    print(json.dumps(result,ensure_ascii=False,indent=2))
