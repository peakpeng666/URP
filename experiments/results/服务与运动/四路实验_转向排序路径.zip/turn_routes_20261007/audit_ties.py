#!/usr/bin/env python3
"""Post-hoc diagnostic: eliminate arbitrary distance-order tie-breaking."""
import csv, hashlib, itertools, json, resource, signal, statistics, time
from pathlib import Path
from experiment import Problem, turn
from verify import alternatives, geometry
ROOT=Path(__file__).resolve().parent


def shortest_then_turns(p):
    states={}
    for j in range(p.n):
        for i,leg in enumerate(p.legs[p.start,j]):
            key=(1<<j,j,leg['out'])
            value=(leg['length'],leg['internal'],(j,),(i,))
            if key not in states or value<states[key]:states[key]=value
    for mask in range(1,1<<p.n):
        for j in range(p.n):
            if not mask & (1<<j):continue
            for h in range(4):
                old=states.get((mask,j,h))
                if old is None:continue
                for k in range(p.n):
                    if mask & (1<<k):continue
                    for i,leg in enumerate(p.legs[j,k]):
                        value=(old[0]+leg['length'],old[1]+leg['internal']+turn(h,leg['in']),
                               old[2]+(k,),old[3]+(i,))
                        key=(mask|(1<<k),k,leg['out'])
                        if key not in states or value<states[key]:states[key]=value
    candidates=[]
    for (mask,j,h),old in states.items():
        if mask != (1<<p.n)-1:continue
        for i,leg in enumerate(p.legs[j,p.goal]):
            candidates.append((old[0]+leg['length'],old[1]+leg['internal']+turn(h,leg['in']),
                               old[2],old[3]+(i,)))
    return min(candidates)


def brute_lex(instance):
    best=(float('inf'),float('inf'))
    n=0
    for order in itertools.permutations(range(len(instance['tasks']))):
        stops=[instance['start']]+[instance['tasks'][i] for i in order]+[instance['goal']]
        legs=[alternatives(a,b) for a,b in zip(stops,stops[1:])]
        for inds in itertools.product(*(range(len(l)) for l in legs)):
            vertices=[tuple(stops[0])]
            for choices,idx in zip(legs,inds):vertices.extend(choices[idx][1:])
            distance,turns,_=geometry(vertices)
            best=min(best,(distance,turns));n+=1
    return best,n


def main():
    resource.setrlimit(resource.RLIMIT_CPU,(30,30));signal.alarm(60)
    t,c=time.perf_counter(),time.process_time()
    for line in (ROOT/'tie_audit_pre_run.sha256').read_text().splitlines():
        digest,name=line.split('  ',1)
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest
    cfg=json.loads((ROOT/'freeze.json').read_text())
    main_records=[json.loads(s) for s in (ROOT/'routes.jsonl').read_text().splitlines()]
    oracle={(r['instance_id'],r['lambda']):r for r in main_records if r['strategy']=='joint_dp_oracle'}
    raw=[]
    for inst in json.loads((ROOT/'instances.json').read_text()):
        p=Problem(inst)
        length,turns,order,opts=shortest_then_turns(p)
        assert length==oracle[inst['instance_id'],0]['distance']
        for lam in cfg['lambdas']:
            ev=p.evaluate(order,opts,lam)
            assert ev['distance']==length and ev['turn_quarter_units']==turns
            o=oracle[inst['instance_id'],lam]
            assert ev['J']>=o['J']
            raw.append({'instance_id':inst['instance_id'],'family':inst['family'],'lambda':lam,
                        'distance':length,'turns':turns,'J':ev['J'],'oracle_J':o['J'],
                        'oracle_distance':o['distance'],'gap_pct':100*(ev['J']-o['J'])/o['J'],
                        'order':order,'leg_options':opts})
    with (ROOT/'tie_audit_raw.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(raw[0]));w.writeheader();w.writerows(raw)
    tests=[]
    for inst in json.loads((ROOT/'validation_instances.json').read_text()):
        exact=shortest_then_turns(Problem(inst))
        brute,count=brute_lex(inst)
        assert exact[:2]==brute
        tests.append({'instance_id':inst['instance_id'],'distance':exact[0],'turns':exact[1],
                      'complete_routes_enumerated':count,'status':'PASS'})
    summaries=[]
    for lam in cfg['lambdas']:
        rows=[r for r in raw if r['lambda']==lam]
        summaries.append({'lambda':lam,'n':len(rows),'mean_gap_pct':statistics.mean(r['gap_pct'] for r in rows),
                          'median_gap_pct':statistics.median(r['gap_pct'] for r in rows),
                          'max_gap_pct':max(r['gap_pct'] for r in rows),
                          'strict_gap_count':sum(r['gap_pct']>1e-9 for r in rows),
                          'joint_distance_above_shortest_count':sum(r['oracle_distance']>r['distance'] for r in rows)})
    result={'status':'PASS','post_hoc':True,'summary':summaries,'independent_checks':tests,
            'cpu_s':time.process_time()-c,'wall_s':time.perf_counter()-t}
    (ROOT/'tie_audit_summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
