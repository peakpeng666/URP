#!/usr/bin/env python3
"""Frozen synthetic service-order / rectilinear path-choice experiment. stdlib only."""
import csv, hashlib, itertools, json, math, platform, random, resource, signal
import statistics, sys, time, traceback
from pathlib import Path
ROOT = Path(__file__).resolve().parent


def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def turn(a, b):
    return min(abs(a - b), 4 - abs(a - b))


def leg_paths(a, b):
    """Candidate index 0 is x-first (or the unique straight path)."""
    a, b = tuple(a), tuple(b)
    if a == b:
        raise ValueError('Coincident service endpoints are unsupported')
    mids = [None] if a[0] == b[0] or a[1] == b[1] else [(b[0], a[1]), (a[0], b[1])]
    result = []
    for mid in mids:
        pts = (a, b) if mid is None else (a, mid, b)
        hs = []
        length = 0
        for p, q in zip(pts, pts[1:]):
            dx, dy = q[0] - p[0], q[1] - p[1]
            assert bool(dx) != bool(dy)
            hs.append(0 if dx > 0 else 2 if dx < 0 else 1 if dy > 0 else 3)
            length += abs(dx) + abs(dy)
        result.append({'points': pts, 'in': hs[0], 'out': hs[-1],
                       'length': length, 'internal': sum(turn(x, y) for x, y in zip(hs, hs[1:]))})
    return result


class Problem:
    def __init__(self, instance):
        self.data = instance
        self.n = len(instance['tasks'])
        self.start, self.goal = self.n, self.n + 1
        self.points = [tuple(p) for p in instance['tasks'] + [instance['start'], instance['goal']]]
        self.legs = {(i, j): leg_paths(a, b) for i, a in enumerate(self.points)
                     for j, b in enumerate(self.points) if i != j}

    def evaluate(self, order, options, lam):
        assert sorted(order) == list(range(self.n))
        assert len(options) == self.n + 1
        nodes = (self.start,) + tuple(order) + (self.goal,)
        vertices = [self.points[self.start]]
        for a, b, op in zip(nodes, nodes[1:], options):
            vertices.extend(self.legs[a, b][op]['points'][1:])
        headings, length = [], 0
        for a, b in zip(vertices, vertices[1:]):
            dx, dy = b[0]-a[0], b[1]-a[1]
            assert bool(dx) != bool(dy)
            length += abs(dx)+abs(dy)
            headings.append(0 if dx>0 else 2 if dx<0 else 1 if dy>0 else 3)
        changes = [turn(a,b) for a,b in zip(headings, headings[1:])]
        return {'J': length + lam*sum(changes), 'distance': length,
                'turn_quarter_units': sum(changes), 'turn_events': sum(x>0 for x in changes),
                'order': list(order), 'leg_options': list(options), 'polyline': vertices,
                'headings': headings}

    def distance_order(self):
        # A distance-only edge DP is valid for this step only.
        dp = {}
        for j in range(self.n):
            dp[1 << j, j] = (self.legs[self.start,j][0]['length'], (j,))
        for mask in range(1, 1 << self.n):
            for last in range(self.n):
                old = dp.get((mask,last))
                if old is None:
                    continue
                for nxt in range(self.n):
                    if mask & (1 << nxt):
                        continue
                    key = mask | (1 << nxt), nxt
                    cand = old[0] + self.legs[last,nxt][0]['length'], old[1] + (nxt,)
                    if key not in dp or cand < dp[key]:
                        dp[key] = cand
        full = (1 << self.n)-1
        return min((dp[full,j][0] + self.legs[j,self.goal][0]['length'], dp[full,j][1])
                   for j in range(self.n))[1]

    def best_paths(self, order, lam):
        nodes = (self.start,) + tuple(order) + (self.goal,)
        dp = {None: (0, ())}
        for a,b in zip(nodes,nodes[1:]):
            nd = {}
            for h,(cost,opts) in dp.items():
                for oi, leg in enumerate(self.legs[a,b]):
                    turns = leg['internal'] + (0 if h is None else turn(h,leg['in']))
                    cand = cost + leg['length'] + lam*turns, opts + (oi,)
                    if leg['out'] not in nd or cand < nd[leg['out']]:
                        nd[leg['out']] = cand
            dp = nd
        return min(dp.values())

    def greedy(self, lam):
        left, order, options, last, heading = set(range(self.n)), [], [], self.start, None
        while left:
            choices = []
            for nxt in sorted(left):
                for oi, leg in enumerate(self.legs[last,nxt]):
                    turns = leg['internal'] + (0 if heading is None else turn(heading,leg['in']))
                    choices.append((leg['length'] + lam*turns, nxt, oi))
            _, nxt, oi = min(choices)
            heading = self.legs[last,nxt][oi]['out']
            order.append(nxt); options.append(oi); left.remove(nxt); last = nxt
        _, oi = min((leg['length']+lam*(leg['internal']+turn(heading,leg['in'])), oi)
                    for oi,leg in enumerate(self.legs[last,self.goal]))
        return tuple(order), tuple(options + [oi])

    def local(self, order, lam):
        order = tuple(order)
        cache = {}
        def evaluate(o):
            if o not in cache:
                cache[o] = self.best_paths(o,lam)
            return cache[o]
        cost,opts = evaluate(order)
        accepted = 0
        for _ in range(50):
            best = (cost, order, opts)
            for i in range(self.n-1):
                for j in range(i+1,self.n):
                    candidate = order[:i] + order[i:j+1][::-1] + order[j+1:]
                    cc,co = evaluate(candidate)
                    if cc < cost and (cc,candidate,co) < best:
                        best = cc,candidate,co
            if best[0] >= cost:
                return order,opts,{'2opt_stop':'no_strict_improvement', 'accepted_reversals':accepted,
                                   'orders_evaluated':len(cache)}
            cost,order,opts = best
            accepted += 1
        return order,opts,{'2opt_stop':'50_reversal_cap', 'accepted_reversals':accepted,
                           'orders_evaluated':len(cache)}

    def joint(self, lam):
        # Key retains arrival heading. It is NOT a task-pair edge-weight TSP.
        dp = {}
        for j in range(self.n):
            for oi,leg in enumerate(self.legs[self.start,j]):
                key = 1 << j,j,leg['out']
                cand = leg['length']+lam*leg['internal'],(j,),(oi,)
                if key not in dp or cand < dp[key]:
                    dp[key] = cand
        for mask in range(1, 1 << self.n):
            for last in range(self.n):
                if not mask & (1 << last):
                    continue
                for h in range(4):
                    old = dp.get((mask,last,h))
                    if old is None:
                        continue
                    for nxt in range(self.n):
                        if mask & (1 << nxt):
                            continue
                        for oi,leg in enumerate(self.legs[last,nxt]):
                            key = mask | (1 << nxt),nxt,leg['out']
                            cand = (old[0]+leg['length']+lam*(leg['internal']+turn(h,leg['in'])),
                                    old[1]+(nxt,),old[2]+(oi,))
                            if key not in dp or cand < dp[key]:
                                dp[key] = cand
        full = (1 << self.n)-1
        finals = []
        for last in range(self.n):
            for h in range(4):
                old = dp.get((full,last,h))
                if old is not None:
                    for oi,leg in enumerate(self.legs[last,self.goal]):
                        finals.append((old[0]+leg['length']+lam*(leg['internal']+turn(h,leg['in'])),
                                       old[1], old[2]+(oi,)))
        best = min(finals)
        return best[1],best[2],len(dp)


def make_instance(family, seed, n, label):
    rng = random.Random(seed)
    if family == 'uniform':
        cells = [(x,y) for x in range(1,20) for y in range(1,20)]
    elif family == 'two_rows':
        cells = [(x,y) for x in range(1,20) for y in (5,15)]
    elif family == 'four_clusters':
        cells = sorted({(cx+dx,cy+dy) for cx,cy in ((5,5),(5,15),(15,5),(15,15))
                        for dx in range(-2,3) for dy in range(-2,3)})
    else:
        raise ValueError(family)
    return {'instance_id':label,'family':family,'seed':seed,'start':[0,0],
            'goal':[20,0],'tasks':[list(x) for x in rng.sample(cells,n)]}


def prepare():
    cfg = json.loads((ROOT/'freeze.json').read_text())
    main,validation = [],[]
    for fi,f in enumerate(cfg['families']):
        for rep in range(cfg['replicates_per_family']):
            main.append(make_instance(f,cfg['master_seed']+100*fi+rep,cfg['task_count'],f'{f}_{rep:02d}'))
        for rep in range(2):
            validation.append(make_instance(f,cfg['master_seed']+10000+100*fi+rep,5,f'verify_{f}_{rep:02d}'))
    dump(ROOT/'instances.json',main)
    dump(ROOT/'validation_instances.json',validation)
    sources = ['freeze.json','experiment.py','verify.py','instances.json','validation_instances.json']
    (ROOT/'pre_run.sha256').write_text(''.join(hashlib.sha256((ROOT/f).read_bytes()).hexdigest()+'  '+f+'\n' for f in sources))
    print('Prepared and hashed frozen inputs; no strategies executed.', flush=True)


def run():
    resource.setrlimit(resource.RLIMIT_CPU,(170,170))
    signal.alarm(1150)
    started_wall, started_cpu = time.perf_counter(),time.process_time()
    cfg = json.loads((ROOT/'freeze.json').read_text())
    for line in (ROOT/'pre_run.sha256').read_text().splitlines():
        digest,name = line.split('  ',1)
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest() == digest, 'Pre-run hash changed: '+name
    instances = json.loads((ROOT/'instances.json').read_text())
    records,failures = [],[]
    out = (ROOT/'routes.jsonl').open('w')
    for inst in instances:
        p = Problem(inst)
        t0,c0 = time.perf_counter(),time.process_time()
        dorder = p.distance_order()
        order_wall,order_cpu = time.perf_counter()-t0,time.process_time()-c0
        for lam in cfg['lambdas']:
            for strategy in cfg['strategies']:
                t0,c0 = time.perf_counter(),time.process_time()
                rec = {'instance_id':inst['instance_id'],'family':inst['family'],'seed':inst['seed'],
                       'lambda':lam,'strategy':strategy,'success':True,'2opt_stop':'',
                       'distance_order_cpu_s':order_cpu,'distance_order_wall_s':order_wall}
                try:
                    extra = {}
                    if strategy == 'distance_order_fixed_paths':
                        order,opts = dorder,(0,)*(p.n+1)
                    elif strategy == 'distance_order_heading_paths':
                        order = dorder; _,opts = p.best_paths(order,lam)
                    elif strategy == 'turn_greedy':
                        order,opts = p.greedy(lam)
                    elif strategy == 'turn_2opt':
                        order,opts,extra = p.local(dorder,lam)
                    elif strategy == 'joint_dp_oracle':
                        order,opts,states = p.joint(lam); extra['dp_states'] = states
                    else:
                        raise ValueError(strategy)
                    rec.update(p.evaluate(order,opts,lam)); rec.update(extra)
                except Exception:
                    rec['success'] = False
                    rec['error'] = traceback.format_exc()
                    failures.append(rec.copy())
                rec['strategy_cpu_s'] = time.process_time()-c0
                rec['strategy_wall_s'] = time.perf_counter()-t0
                records.append(rec)
                out.write(json.dumps(rec,separators=(',',':'))+'\n'); out.flush()
        print('Completed '+inst['instance_id'], flush=True)
    out.close()
    refs = {(r['instance_id'],r['lambda']):r['J'] for r in records
            if r['strategy']=='joint_dp_oracle' and r['success']}
    for r in records:
        if r['success'] and (r['instance_id'],r['lambda']) in refs:
            r['relative_gap_to_oracle'] = (r['J']-refs[r['instance_id'],r['lambda']])/refs[r['instance_id'],r['lambda']]
    fields = ['instance_id','family','seed','lambda','strategy','success','J','distance','turn_quarter_units',
              'turn_events','relative_gap_to_oracle','strategy_cpu_s','strategy_wall_s','distance_order_cpu_s',
              'distance_order_wall_s','2opt_stop','accepted_reversals','orders_evaluated','dp_states',
              'order','leg_options','error']
    with (ROOT/'raw_results.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore'); w.writeheader(); w.writerows(records)
    dump(ROOT/'failures.json',failures)
    # Store DP outputs for a wholly independent permutation/path enumerator.
    oracle_checks = []
    for inst in json.loads((ROOT/'validation_instances.json').read_text()):
        p = Problem(inst)
        for lam in cfg['lambdas']:
            order,opts,states=p.joint(lam)
            oracle_checks.append({'instance_id':inst['instance_id'],'lambda':lam,
                                  **p.evaluate(order,opts,lam),'dp_states':states})
    dump(ROOT/'validation_dp_results.json',oracle_checks)
    elapsed_main_cpu = time.process_time()-started_cpu
    elapsed_main_wall = time.perf_counter()-started_wall
    # Import only for orchestration. verify.py imports no experiment code.
    import verify
    verified = verify.verify_all(ROOT)
    dump(ROOT/'verification.json',verified)
    summary = []
    for fam in ['ALL']+cfg['families']:
        for lam in cfg['lambdas']:
            for strategy in cfg['strategies']:
                group = [r for r in records if r['success'] and r['lambda']==lam and r['strategy']==strategy
                         and (fam=='ALL' or r['family']==fam)]
                gaps=[r['relative_gap_to_oracle'] for r in group]
                summary.append({'family':fam,'lambda':lam,'strategy':strategy,'n':len(group),
                    'mean_J':statistics.mean(r['J'] for r in group),
                    'mean_distance':statistics.mean(r['distance'] for r in group),
                    'mean_turn_quarter_units':statistics.mean(r['turn_quarter_units'] for r in group),
                    'mean_gap_pct':100*statistics.mean(gaps),'median_gap_pct':100*statistics.median(gaps),
                    'max_gap_pct':100*max(gaps),'strict_suboptimal_count':sum(g>1e-9 for g in gaps)})
    with (ROOT/'summary.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(summary[0]));w.writeheader();w.writerows(summary)
    paired=[]
    contrasts=[('distance_order_fixed_paths','distance_order_heading_paths'),
               ('distance_order_heading_paths','joint_dp_oracle'),('turn_2opt','joint_dp_oracle')]
    by_key={(r['instance_id'],r['lambda'],r['strategy']):r for r in records if r['success']}
    for lam in cfg['lambdas']:
        for a,b in contrasts:
            diffs=[by_key[i['instance_id'],lam,a]['J']-by_key[i['instance_id'],lam,b]['J'] for i in instances]
            paired.append({'lambda':lam,'strategy_A':a,'strategy_B':b,'n':len(diffs),
                           'mean_A_minus_B':statistics.mean(diffs),'median_A_minus_B':statistics.median(diffs),
                           'min_A_minus_B':min(diffs),'max_A_minus_B':max(diffs),
                           'positive_count':sum(d>0 for d in diffs),'zero_count':sum(d==0 for d in diffs)})
    with (ROOT/'paired_comparisons.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(paired[0]));w.writeheader();w.writerows(paired)
    status={'status':'PASS' if verified['status']=='PASS' and not failures else 'FAIL',
            'main_route_records':len(records),'failures':len(failures),'main_cpu_s':elapsed_main_cpu,
            'main_wall_s':elapsed_main_wall,'total_cpu_s':time.process_time()-started_cpu,
            'total_wall_s':time.perf_counter()-started_wall,'python':sys.version,'platform':platform.platform(),
            'resource_policy':'Single Python compute process, RLIMIT_CPU=170 s, alarm=1150 s; no child compute processes.',
            'timing_warning':'Concurrent cloud workloads; timing is diagnostic only, not a speed ranking. Distance-order preprocessing is shared and separately reported, not included in per-strategy times.',
            'external_calls':0,'deviations':[]}
    dump(ROOT/'run_status.json',status)
    print(json.dumps(status,ensure_ascii=False),flush=True)
    signal.alarm(0)
    if status['status']!='PASS':
        raise SystemExit(1)

if __name__ == '__main__':
    if sys.argv[1:] == ['--prepare']:
        prepare()
    elif sys.argv[1:] == ['--run']:
        run()
    else:
        raise SystemExit('Use --prepare to freeze inputs; then --run to execute.')
