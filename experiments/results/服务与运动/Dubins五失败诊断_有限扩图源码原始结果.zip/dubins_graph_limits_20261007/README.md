# Dubins finite-graph limit diagnostic

Read REPORT_ZH.txt and summary.json first. This is a post-hoc bounded diagnostic of exactly five failures, not a new benchmark or overall success-rate update.

## Reproduction

Python 3.12, NumPy, Matplotlib. No network or model API. Inputs and production generator are frozen by freeze.sha256. All outcome-producing source files are frozen by source.sha256 before the first formal solve. Copy this folder to a clean location, preserve inputs/freeze/source, remove output directories and regenerate empty raw/routes/evidence/figures directories. Run PYTHONDONTWRITEBYTECODE=1 python source/supervise.py. The original source experiment folder must remain available for the read-only before/after integrity check. Do not rerun over formal outputs.

source/freeze.py records the fixed grid and copies the exact inputs; it is provenance, not an instruction to reseed/reselect. source/experiment.py constructs direct-or-one-intermediate edges. source/verify.py independently integrates every generated candidate and enumerates all tours without importing the generator. source/report.py produces the figure and report. source/archive.py creates a clean ZIP without interpreter caches, binaries, credentials or runtime caches.

## Files

- input: selected geometry, map-based grid, original direct edges, original result/graph tables for selection evidence, and OMPL source/license
- raw/legs.jsonl: all generated candidates, unavailable words, selection and failures for all 9,520 connection pairs
- raw/graphs.json: extended cost matrices and complete selected component parameters
- raw/results.json and raw/failures.json: all five outcomes, no discarded failures
- routes: independently checked CSV/JSON full tours if any are found; otherwise intentionally empty
- evidence: freeze, resource and independent-check records
- figures/diagnostic_cases.png: synthetic geometric/order component, explicitly not a full multi-vehicle system

The supervisor's final resource.json is external to the clean archive because it includes the archive process itself. The ZIP includes resource_pre_archive.json; the final cumulative resource ledger and ZIP hash accompany delivery outside the archive. SHA256SUMS.txt covers the stable archive payload, excluding itself and the evolving supervisor/archive log. Preparation and read-only inspection CPU is excluded from the formal 120-second cap and not disguised as measured execution time.

No candidate graph failure is a proof of continuous-space infeasibility. The original 72-case data remain read-only. No upload is performed.
