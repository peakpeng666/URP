#!/usr/bin/env python3
import json,csv,math,time
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
ROOT=Path(__file__).resolve().parents[1]
def dump(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
def main():
 cfg=json.loads((ROOT/'freeze.json').read_text());rows=json.loads((ROOT/'raw/results.json').read_text());v=json.loads((ROOT/'evidence/verification.json').read_text());run=json.loads((ROOT/'evidence/run_status.json').read_text());assert v['status']=='passed'
 gs={g['geometry_id']+'_R6':g for g in json.loads((ROOT/'input/instances_selected5.json').read_text())};grid=json.loads((ROOT/'input/intermediate_grid.json').read_text());success=[r for r in rows if r['feasible']]
 fields=['instance_id','original_feasible_edges','expanded_feasible_edges','new_edge_count','feasible','length','incoming_missing_nodes','outgoing_missing_nodes']
 with (ROOT/'summary.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
  for r in rows:w.writerow({**{k:r[k] for k in fields if k not in ['new_edge_count']},'new_edge_count':len(r['newly_connected_edges'])})
 summary={'post_hoc_selected_failures':5,'verified_continuous_witnesses':len(success),'expanded_finite_graph_failures':5-len(success),'newly_connected_original_node_pairs':sum(len(r['newly_connected_edges']) for r in rows),'original_72_results_unchanged':True,'claim_limit':'No population success rate, no continuous infeasibility claim, no continuous-space optimality, no full multi-vehicle system claim.'};dump(ROOT/'summary.json',summary)
 fig,axs=plt.subplots(2,3,figsize=(15,9),constrained_layout=True)
 for ax,r in zip(axs.flat,rows):
  iid=r['instance_id'];ps=gs[iid]['poses'];ax.add_patch(Rectangle((0,0),40,30,fill=False,lw=1.7));positions=sorted(set(tuple(g['pose'][:2]) for g in grid));ax.scatter(*zip(*positions),s=11,c='#b8c3d1',label='Fixed intermediate positions')
  if r['feasible']:
   w=json.loads((ROOT/'routes'/f'{iid}.json').read_text());data=list(csv.DictReader((ROOT/'routes'/f'{iid}.csv').open()))
   for ei in range(8):
    pts=[p for p in data if int(p['edge'])==ei];typ=pts[0]['edge_type'];ax.plot([float(p['x']) for p in pts],[float(p['y']) for p in pts],lw=1.5,c='#e07a16' if typ!='direct' else '#2076b5')
   subtitle=f"Verified witness: {r['length']:.2f} m"
  else:subtitle='No tour in this expanded finite graph'
  missing=set(r['incoming_missing_nodes']+r['outgoing_missing_nodes'])
  for i,(x,y,h) in enumerate(ps):
   col='#c72e35' if i in missing else ('black' if i==0 else '#18568b');ax.scatter([x],[y],s=45 if i else 65,c=col,zorder=4,marker='s' if i==0 else 'o');ax.arrow(x,y,1.8*math.cos(h),1.8*math.sin(h),width=.05,head_width=.55,color=col,zorder=5,length_includes_head=True);ax.text(x+.65,y+.7,str(i),fontsize=9,color=col)
  ax.set(xlim=(-1,41),ylim=(-1,31),aspect='equal',xlabel='x (m)',ylabel='y (m)',title=iid+'\n'+subtitle);ax.grid(alpha=.12)
 ax=axs.flat[-1];ax.axis('off');ax.text(0,1,'POST-HOC DIAGNOSTIC\n\nFive original graph failures only\nR = 6 m; fixed service poses\n15 map-based positions × 8 headings\n119 intermediate poses after duplicate removal\nAt most one intermediate pose per task pair\nOriginal direct edges retained\n\nRed: node still missing all in/out edges\nGray dots: fixed grid positions\nArrows: unchanged service headings\n\nSynthetic geometric/order component.\nNot a complete multi-vehicle system.\nNo tour here does not prove\ncontinuous-space infeasibility.',va='top',fontsize=12)
 fig.suptitle('Dubins graph-limit diagnosis | independent geometric verification',fontsize=17)
 fig.savefig(ROOT/'figures/diagnostic_cases.png',dpi=150);plt.close(fig)
 lines=['Dubins有限候选图限制：五个原失败实例的有界事后诊断','',f'结论：原5个图失败案例中，扩展有限图找到{len(success)}个完整闭合7任务路线；独立验证通过的连续可行见证为{len(success)}个。']
 if not success:lines+=['本次没有得到“原六类直接曲线限制导致假无解”的正面见证。即使扩展图仍失败，也不能据此断言这些实例在连续有界空间中无解。']
 else:lines+=['得到见证的实例已证明连续空间可行，原六类直接候选图无法表示该见证所需的至少一条连接；剩余失败只代表本次扩展有限图失败。']
 lines+=['','选择与冻结：仅按原72例中既有失败结果选择 near_boundary_01_R6、02_R6、03_R6、10_R6、11_R6。它们不是新随机样本；不重新计算或宣传总体胜率提升，不改写原72例结论。',f"设计冻结于 {cfg['frozen_utc']}，在正式求解之前保存摘要。位置只由40×30矩形和R=6决定：x=6,13,20,27,34；y=6,15,24；方向为0,π/4,…,7π/4。排除与公共depot完全重合的位姿后119个。没有看结果调网格。",'每一对原节点保留原全部合法直接候选，成本至少保留原最短合法边；仅增加“原节点→单个格点位姿→原节点”的两段连接。每段仍用原已核验六类生成器选最短矩形内曲线。没有格点间连接、没有多中间点最短路、没有网格细化。',f"冻结的连接预算全部执行：{run['counts']['leg_pairs']}个有向原节点/中间位姿对，{run['counts']['candidates']}条实际存在的Dubins候选；{run['counts']['via_pairs_evaluated']}个两段组合。所有不可生成的词型、越界候选和缺失连接均保留。",'','几何语义：起终点均为原depot (20,15,0)，7个服务点的位置及航向完全沿用，最小转弯半径6米。前进、单位速率、点车、位置航向连续、曲率跳变允许；仅矩形为碰撞边界，无内部障碍、无车身包络、无加速度/转向速率模型。','', '逐例结果：']
 for r in rows:
  lines.append(f"- {r['instance_id']}: 合法原节点对 {r['original_feasible_edges']}→{r['expanded_feasible_edges']}；新增{len(r['newly_connected_edges'])}；闭合tour {'找到' if r['feasible'] else '未找到'}；仍无入边节点{r['incoming_missing_nodes']}，仍无出边节点{r['outgoing_missing_nodes']}。")
  if r['feasible']:lines.append(f"  路线{r['tour']}，长度{r['length']:.10f}米，完整路线见routes/{r['instance_id']}.json和.csv。")
 lines+=['','独立核验：verify.py不导入生产Dubins实现。对全部新增连接候选做32点Gauss–Legendre积分，依方向导数零点重算完整弧段边界极值，用积分轨迹点重算有符号Menger曲率，并检查位置、航向、长度、曲率上界和越界分类。不是只检查离散采样点。所有原图合法边的成本不增，扩展图由原始leg结果独立重建。五个图各枚举7!=5,040个任务顺序，原图和扩展图闭合可行性/最小值与求解输出一致。若存在完整路线，另检查每个组件拼接位置与方向、逐任务服务位姿、7任务覆盖和闭合返回。',f"核验最大终点位置误差 {v['max_endpoint_m']:.3g} m，航向误差 {v['max_heading_rad']:.3g} rad，曲率误差 {v['max_curvature_error']:.3g} 1/m，包围盒误差 {v['max_bbox_m']:.3g} m。全部 {v['instances_checked']} 个图通过。",f"原目录 {v['original_file_count']} 个文件逐一SHA256比对未改动；复用的生成器字节与输入冻结中保存的原文件摘要一致。",'','预算与失败记录：预估按原实验单次连接成本线性推算求解约2.21 CPU秒、候选几何独验保守约19.41秒，不是结果后调预算。监督器按前面全部子进程累计CPU给后续进程设置剩余RLIMIT_CPU，正式求解、独验、报告/图与归档累计CPU上限120秒，留1秒监督余量。代码准备与只读输入检查不在该正式运行上限计量内。各阶段实际CPU与终止状态见evidence/resource.json；干净ZIP内保存归档前状态evidence/resource_pre_archive.json，最终含归档的资源账作为包外交接证据。',f"求解进程内部实测CPU {run['cpu_seconds']:.6f} 秒；独验内部实测CPU {v['cpu_seconds']:.6f} 秒；这两项不含进程启动，完整口径以监督器资源账为准。",'本次无Codex、模型API、付费调用、第三方上传。','', '结论边界：结果只适用于这5个按失败选出的实例及冻结的有限扩展图。候选图最优不是连续空间最优；没有见证不是连续空间不可行证明。静态图只是合成的单车几何和访问排序组件，不能作为完整多车容量/分配系统验证。']
 (ROOT/'REPORT_ZH.txt').write_text('\n'.join(lines)+'\n')
 (ROOT/'README.md').write_text('''# Dubins finite-graph limit diagnostic\n\nRead REPORT_ZH.txt and summary.json first. This is a post-hoc bounded diagnostic of exactly five failures, not a new benchmark or overall success-rate update.\n\n## Reproduction\n\nPython 3.12, NumPy, Matplotlib. No network or model API. Inputs and production generator are frozen by freeze.sha256. All outcome-producing source files are frozen by source.sha256 before the first formal solve. Copy this folder to a clean location, preserve inputs/freeze/source, remove output directories and regenerate empty raw/routes/evidence/figures directories. Run PYTHONDONTWRITEBYTECODE=1 python source/supervise.py. The original source experiment folder must remain available for the read-only before/after integrity check. Do not rerun over formal outputs.\n\nsource/freeze.py records the fixed grid and copies the exact inputs; it is provenance, not an instruction to reseed/reselect. source/experiment.py constructs direct-or-one-intermediate edges. source/verify.py independently integrates every generated candidate and enumerates all tours without importing the generator. source/report.py produces the figure and report. source/archive.py creates a clean ZIP without interpreter caches, binaries, credentials or runtime caches.\n\n## Files\n\n- input: selected geometry, map-based grid, original direct edges, original result/graph tables for selection evidence, and OMPL source/license\n- raw/legs.jsonl: all generated candidates, unavailable words, selection and failures for all 9,520 connection pairs\n- raw/graphs.json: extended cost matrices and complete selected component parameters\n- raw/results.json and raw/failures.json: all five outcomes, no discarded failures\n- routes: independently checked CSV/JSON full tours if any are found; otherwise intentionally empty\n- evidence: freeze, resource and independent-check records\n- figures/diagnostic_cases.png: synthetic geometric/order component, explicitly not a full multi-vehicle system\n\nThe supervisor's final resource.json is external to the clean archive because it includes the archive process itself. The ZIP includes resource_pre_archive.json; the final cumulative resource ledger and ZIP hash accompany delivery outside the archive. SHA256SUMS.txt covers the stable archive payload, excluding itself and the evolving supervisor/archive log. Preparation and read-only inspection CPU is excluded from the formal 120-second cap and not disguised as measured execution time.\n\nNo candidate graph failure is a proof of continuous-space infeasibility. The original 72-case data remain read-only. No upload is performed.\n''')
 print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
