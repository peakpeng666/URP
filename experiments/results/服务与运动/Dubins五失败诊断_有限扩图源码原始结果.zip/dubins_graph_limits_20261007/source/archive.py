#!/usr/bin/env python3
import json,hashlib,zipfile,shutil,time,resource
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def main():
 shutil.copyfile(ROOT/'evidence/resource.json',ROOT/'evidence/resource_pre_archive.json')
 excluded={'SHA256SUMS.txt','evidence/resource.json','evidence/archive.log','DELIVERY.json','delivery.sha256'}
 files=[p for p in sorted(ROOT.rglob('*')) if p.is_file() and str(p.relative_to(ROOT)) not in excluded and '__pycache__' not in p.parts and 'mplcache' not in p.parts]
 sums=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(ROOT))+'\n' for p in files)
 (ROOT/'SHA256SUMS.txt').write_text(sums);files.append(ROOT/'SHA256SUMS.txt')
 dest=ROOT.with_name(ROOT.name+'_delivery.zip');assert not dest.exists()
 with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p in files:z.write(p,arcname=str(Path(ROOT.name)/p.relative_to(ROOT)))
 with zipfile.ZipFile(dest) as z:
  assert z.testzip() is None
  for line in sums.splitlines():
   h,n=line.split('  ');assert hashlib.sha256(z.read(ROOT.name+'/'+n)).hexdigest()==h
 print(json.dumps({'zip':str(dest),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'bytes':dest.stat().st_size,'payload_files':len(files),'zip_integrity_and_payload_hashes':'passed','resource_ledger':'Final cumulative ledger is emitted by supervisor outside archive; archive contains pre-archive snapshot.'},indent=2))
if __name__=='__main__':main()
