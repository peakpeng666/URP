#!/usr/bin/env python3
"""Independent verifier: no import of production Dubins implementation.
Integrate unit-speed ODE by Gauss-Legendre; extrema from derivative roots;
Menger curvature from integrated points; permutation oracle for tours.
"""
import json,math,itertools,time,hashlib,csv
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1];TAU=2*math.pi
GN,GW=np.polynomial.legendre.leggauss(32)
S={'leg_pairs':0,'candidates':0,'segments':0,'curvature_checks':0,'zero_length_segments':0,'max_endpoint_m':0.,'max_heading_rad':0.,'max_curvature_error':0.,'max_bbox_m':0.,'max_length_m':0.,'minimum_selected_tour_boundary_margin_m':None,'witnesses_checked':0}
def dump(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
def integral(h,k,lengths):
 lengths=np.atleast_1d(lengths).astype(float);s=(GN[None,:]+1)*lengths[:,None]/2;hs=h+k*s
 return np.column_stack(((np.cos(hs)*GW).sum(axis=1)*lengths/2,(np.sin(hs)*GW).sum(axis=1)*lengths/2))
def error(x,y):return math.dist(x[:2],y[:2]),abs(math.remainder(x[2]-y[2],TAU))
def verify_path(q0,q1,path,R,box,tol,output=False):
 q=np.array(q0,dtype=float);boxes=[];total=0.;sampled=[]
 assert len(path['word'])==len(path['params'])==3
 for segi,(kind,u) in enumerate(zip(path['word'],path['params'],strict=True)):
  assert kind in 'LSR' and u>=0 and math.isfinite(u)
  length=R*u;k={'L':1/R,'R':-1/R,'S':0.}[kind];times=[0.,length]
  if k:
   lo,hi=sorted((q[2],q[2]+k*length))
   for n in range(math.ceil(lo/(math.pi/2)),math.floor(hi/(math.pi/2))+1):
    s=(n*math.pi/2-q[2])/k
    if 0<=s<=length:times.append(s)
  points=integral(q[2],k,times)+q[:2]
  boxes.append([float(points[:,0].min()),float(points[:,0].max()),float(points[:,1].min()),float(points[:,1].max())])
  headings=q[2]+k*(GN+1)*length/2
  speed_length=float(np.dot(np.hypot(np.cos(headings),np.sin(headings)),GW)*length/2)
  le=abs(length-speed_length);S['max_length_m']=max(S['max_length_m'],le);assert le<tol['length_m'];total+=speed_length
  if length>1e-8:
   pts=integral(q[2],k,[.3*length,.5*length,.7*length]);a=pts[1]-pts[0];b=pts[2]-pts[1];c=pts[2]-pts[0]
   den=np.linalg.norm(a)*np.linalg.norm(b)*np.linalg.norm(c);curv=float(2*(a[0]*b[1]-a[1]*b[0])/den)
   ce=abs(curv-k);assert ce<tol['curvature_abs'],(ce,kind,length)
   assert abs(curv)<=1/R+tol['curvature_abs'];S['max_curvature_error']=max(S['max_curvature_error'],ce);S['curvature_checks']+=1
  else:S['zero_length_segments']+=1
  if output:
   ss=np.linspace(0,length,max(2,math.ceil(length/.1)+1));xy=integral(q[2],k,ss)+q[:2]
   sampled.extend({'segment':segi,'kind':kind,'s_in_component_m':total-speed_length+float(s),'x':float(p[0]),'y':float(p[1]),'heading_rad':float(q[2]+k*s),'curvature':k} for s,p in zip(ss,xy))
  q[:2]+=integral(q[2],k,[length])[0];q[2]+=k*length;S['segments']+=1
 pe,he=error(q,q1);S['max_endpoint_m']=max(S['max_endpoint_m'],pe);S['max_heading_rad']=max(S['max_heading_rad'],he)
 assert pe<tol['endpoint_m'] and he<tol['heading_rad'],(pe,he,q0,q1,path)
 assert abs(total-path['length'])<tol['length_m']
 bbox=[min(b[0] for b in boxes),max(b[1] for b in boxes),min(b[2] for b in boxes),max(b[3] for b in boxes)]
 be=max(abs(x-y) for x,y in zip(bbox,path['bbox']));S['max_bbox_m']=max(S['max_bbox_m'],be);assert be<tol['bbox_m']
 margin=min(bbox[0]-box[0],box[1]-bbox[1],bbox[2]-box[2],box[3]-bbox[3]);assert (margin>=-tol['boundary_m'])==path['feasible']
 S['candidates']+=1
 return margin,sampled,list(q)
def main():
 t=time.perf_counter();cpu=time.process_time();cfg=json.loads((ROOT/'freeze.json').read_text());tol=cfg['tolerances'];R=cfg['R'];box=cfg['rectangle']
 for name in ('freeze.sha256','source.sha256'):
  for line in (ROOT/name).read_text().splitlines():
   h,p=line.split('  ');assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h,p
 grid=json.loads((ROOT/'input/intermediate_grid.json').read_text());geoms={g['geometry_id']+'_R6':g for g in json.loads((ROOT/'input/instances_selected5.json').read_text())};legs={}
 # Verify generated candidates, including rejected paths, with independent ODE.
 for line in (ROOT/'raw/legs.jsonl').open():
  e=json.loads(line);ps=geoms[e['instance_id']]['poses'];g=grid[e['grid_index']];i=e['node'];d=e['direction'];assert e['grid_id']==g['grid_id']
  expected=(ps[i],g['pose']) if d=='out' else (g['pose'],ps[i]);assert (e['q0'],e['q1'])==expected
  assert sorted([p['word'] for p in e['candidates']]+e['unavailable_words'])==sorted(['LSL','RSR','LSR','RSL','LRL','RLR'])
  for p in e['candidates']:verify_path(e['q0'],e['q1'],p,R,box,tol)
  feas=[p for p in e['candidates'] if p['feasible']];best=min(feas,key=lambda p:(p['length'],p['word'])) if feas else None
  assert e['cost']==(best['length'] if best else None) and e['selected_word']==(best['word'] if best else None)
  key=(e['instance_id'],i,e['grid_index'],d);assert key not in legs
  legs[key]=best;S['leg_pairs']+=1
 assert S['leg_pairs']==cfg['connections']['leg_generation_budget']
 graphs={g['instance_id']:g for g in json.loads((ROOT/'raw/graphs.json').read_text())};rows=json.loads((ROOT/'raw/results.json').read_text());origs={}
 for line in (ROOT/'input/original_edges_selected5.jsonl').open():
  e=json.loads(line);origs[(e['instance_id'],e['i'],e['j'])]=e
 audit=[]
 for row in rows:
  iid=row['instance_id'];graph=graphs[iid];ps=geoms[iid]['poses'];cost=graph['cost'];original=graph['original_cost']
  for i in range(8):
   for j in range(8):
    if i==j:assert cost[i][j] is None;continue
    o=origs[(iid,i,j)];assert original[i][j]==o['cost'];choices=[]
    if o['cost'] is not None:choices.append((o['cost'],0,-1))
    for gi in range(len(grid)):
     a,b=legs[(iid,i,gi,'out')],legs[(iid,j,gi,'in')]
     if a is not None and b is not None:choices.append((a['length']+b['length'],1,gi))
    val=min(choices) if choices else None
    assert cost[i][j]==(val[0] if val else None)
    if val:
     e=graph['selected_edges'][f'{i},{j}'];assert e['length']==val[0]
     assert e['type']==('direct' if val[1]==0 else 'via_one_grid_pose')
     assert e['grid_index']==(None if val[1]==0 else val[2]);assert e['original_cost']==o['cost']
     assert e['components'][0]['q0']==ps[i] and e['components'][-1]['q1']==ps[j]
     if val[1]:assert e['components'][0]['q1']==e['components'][1]['q0']==grid[val[2]]['pose']
     assert len(e['components'])==1+val[1]
     if o['cost'] is not None:assert cost[i][j]<=o['cost']
  perms=[(0,)+p+(0,) for p in itertools.permutations(range(1,8))]
  def tourvalue(c,p):return sum(math.inf if c[i][j] is None else c[i][j] for i,j in zip(p,p[1:]))
  allvals=[tourvalue(cost,p) for p in perms];oldvals=[tourvalue(original,p) for p in perms]
  assert not any(math.isfinite(x) for x in oldvals)
  v=min(allvals);assert math.isfinite(v)==row['feasible']
  item={'instance_id':iid,'orders_enumerated':len(perms),'original_feasible_orders':0,'expanded_feasible_orders':sum(math.isfinite(x) for x in allvals),'expanded_best_length':v if math.isfinite(v) else None,'passed':True}
  if row['feasible']:
   assert abs(v-row['length'])<tol['tour_m'];route=row['tour'];assert route[0]==route[-1]==0 and sorted(route[1:-1])==list(range(1,8));assert abs(tourvalue(cost,route)-v)<tol['tour_m']
   w=json.loads((ROOT/'routes'/f'{iid}.json').read_text());assert w['route']==route and w['fixed_service_poses']==ps
   previous=ps[0];total=0.;samples=[];margins=[]
   for ei,e in enumerate(w['edges']):
    assert [e['i'],e['j']]==route[ei:ei+2]
    for ci,c in enumerate(e['components']):
     pe,he=error(previous,c['q0']);assert pe<tol['endpoint_m'] and he<tol['heading_rad']
     margin,pts,end=verify_path(c['q0'],c['q1'],c['path'],R,box,tol,True);assert c['path']['feasible'];margins.append(margin)
     for p in pts:p.update(edge=ei,from_node=e['i'],to_node=e['j'],component=ci,s_global_m=total+p['s_in_component_m'],edge_type=e['type'])
     samples.extend(pts);total+=c['path']['length'];previous=end
    pe,he=error(previous,ps[e['j']]);assert pe<tol['endpoint_m'] and he<tol['heading_rad']
   assert abs(total-w['length'])<tol['tour_m'];pe,he=error(previous,ps[0]);assert pe<tol['endpoint_m'] and he<tol['heading_rad']
   assert w['original_missing_edges_on_route'],'A rescue witness must use at least one absent original edge.'
   with (ROOT/'routes'/f'{iid}.csv').open('w',newline='') as f:
    wr=csv.DictWriter(f,fieldnames=list(samples[0]));wr.writeheader();wr.writerows(samples)
   w['independent_verification']={'passed':True,'minimum_boundary_margin_m':min(margins),'csv_sample_spacing_max_m':.1,'boundary_check':'Analytic derivative-root extrema integrated independently; CSV sampling is for visualization only.'};dump(ROOT/'routes'/f'{iid}.json',w)
   S['witnesses_checked']+=1;S['minimum_selected_tour_boundary_margin_m']=min(margins) if S['minimum_selected_tour_boundary_margin_m'] is None else min(S['minimum_selected_tour_boundary_margin_m'],min(margins))
  audit.append(item)
 old=Path('/workspace/shared/curvature_routes_20261007');expected=json.loads((ROOT/'evidence/old_inventory_before.json').read_text());actual={str(p.relative_to(old)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(old.rglob('*')) if p.is_file()}
 assert actual==expected,'Original experiment changed.'
 dump(ROOT/'evidence/old_inventory_after.json',actual)
 S.update(status='passed',instances_checked=len(rows),all_order_checks=audit,original_files_unchanged=True,original_file_count=len(actual),cpu_seconds=time.process_time()-cpu,wall_seconds=time.perf_counter()-t,independence='Does not import production generator; quadrature ODE, derivative-root extrema, signed Menger curvature, graph reconstruction from raw legs, 7! full-order enumeration. Formula completeness is inherited from previously audited generator, not newly independently proved.',source_sha256=hashlib.sha256((ROOT/'source/verify.py').read_bytes()).hexdigest())
 dump(ROOT/'evidence/verification.json',S);print(json.dumps(S,indent=2))
if __name__=='__main__':main()
