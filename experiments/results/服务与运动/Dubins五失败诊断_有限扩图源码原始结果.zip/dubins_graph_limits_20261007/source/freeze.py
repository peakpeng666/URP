#!/usr/bin/env python3
import json, hashlib, shutil, datetime, math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OLD=Path('/workspace/shared/curvature_routes_20261007')
def dump(p,x): p.write_text(json.dumps(x,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
assert not (ROOT/'freeze.json').exists()
ids=json.loads((OLD/'failure_index.json').read_text())['both_failures_in_candidate_graph']
rows=[x for x in json.loads((OLD/'raw/results.json').read_text()) if x['instance_id'] in ids]
assert len(rows)==5 and all(not x['dubins_dp_feasible'] and x['R']==6 for x in rows)
geoms=[x for x in json.loads((OLD/'instances.json').read_text()) if x['geometry_id']+'_R6' in ids]
original_hashes={str(p.relative_to(OLD)):sha(p) for p in sorted(OLD.rglob('*')) if p.is_file()}
dump(ROOT/'evidence/old_inventory_before.json',original_hashes)
for src,dst in [('freeze.json','old_freeze.json'),('raw/results.json','old_results_all72.json'),('failure_index.json','old_failure_index.json'),('raw/graphs.json','old_graphs_all72.json')]: shutil.copyfile(OLD/src,ROOT/'input'/dst)
shutil.copyfile(OLD/'source/dubins.py',ROOT/'source/dubins.py')
shutil.copyfile(OLD/'reference/ompl_DubinsStateSpace_1.7.0.cpp',ROOT/'input/ompl_DubinsStateSpace_1.7.0.cpp')
dump(ROOT/'input/instances_selected5.json',geoms)
with (ROOT/'input/original_edges_selected5.jsonl').open('w') as f:
 for line in (OLD/'raw/edges.jsonl').open():
  if json.loads(line)['instance_id'] in ids: f.write(line)
# These grid locations depend only on map rectangle and R. No trial is run.
box=[0.,40.,0.,30.];R=6.
xs=[R+(box[1]-2*R)*i/4 for i in range(5)]
ys=[R+(box[3]-2*R)*i/2 for i in range(3)]
grid=[{'grid_id':f'x{ix}_y{iy}_h{ih}','pose':[x,y,ih*math.pi/4]} for ix,x in enumerate(xs) for iy,y in enumerate(ys) for ih in range(8)]
# The only excluded point is exactly the common original depot pose.
excluded=[g for g in grid if g['pose']==[20.,15.,0.]]
grid=[g for g in grid if g['pose']!=[20.,15.,0.]]
dump(ROOT/'input/intermediate_grid.json',grid)
cfg={'experiment_id':'dubins_graph_limits_20261007','frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'selection':'Post-hoc diagnostic of exactly the five original graph-DP failures. Not new random samples; not a population success-rate experiment.',
 'instance_ids':ids,'original_experiment':'curvature_routes_20261007','rectangle':box,'R':R,'obstacles':[],
 'motion_semantics':'Same forward-only unit-speed point Dubins vehicle, fixed depot and all seven task poses, |curvature|<=1/R, continuous position/heading, curvature jumps allowed. Only rectangle is collision boundary; no footprint or dynamics.',
 'grid':{'x':xs,'y':ys,'headings':[i*math.pi/4 for i in range(8)],'position_rule':'Five evenly spaced x and three evenly spaced y in rectangle inset by R; eight equally spaced headings; exclude exact common depot duplicate.', 'raw_grid_poses':120,'excluded':excluded,'retained_poses':len(grid),'priority':'instance order from original failure index; source node 0..7, grid lexicographic x/y/heading, forward original->grid then grid->original; all executed without outcome-adaptive tuning'},
 'connections':{'max_intermediate_poses_per_original_edge':1,'required_direct_edges_retained':True,'original_edges':5*56,'leg_generation_budget':5*8*len(grid)*2,'candidate_word_budget':5*8*len(grid)*2*6,'via_pair_combinations':5*56*len(grid),'each_leg':'Shortest boundary-feasible of original six standard Dubins candidates. Join two legs at identical grid pose. All original feasible candidates remain available and original selected edge cost cannot increase.','new_edge':'Minimum of original direct edge and all two-leg concatenations; exact ties prefer direct then grid order then word order.'},
 'solver':'Original Held-Karp on expanded 8-node graph; independent all-5040-order enumeration. No multi-hop closure, no grid-grid legs, no grid refinement, no changing headings or R, no repeat seeking success.',
 'validation':'Independent module that does not import dubins.py: 32-node Gauss-Legendre ODE integration, derivative-root extrema, signed Menger curvature, exact service cover, start/end/join direction, all-order oracle. Verify every generated leg candidate including rejects and every selected tour.',
 'tolerances':{'endpoint_m':2e-8,'heading_rad':2e-10,'length_m':2e-9,'bbox_m':2e-8,'curvature_abs':2e-7,'tour_m':1e-8,'boundary_m':1e-9},
 'cpu_budget_seconds':120,'budget_scope':'Sequential formal solve, independent verification, plots/report, and clean archive process CPU, including process startup and parent supervisor; 1-second cushion. Preparation/read-only inspection is excluded and separately disclosed.',
 'computation_estimate':{'source_evidence':'Original 4032 pair generations / 18294 candidate paths took 0.936690463 process CPU seconds; original all-candidate independent verifier took 6.215971 seconds.','estimated_generation_cpu_seconds_linear':0.936690463*(5*8*len(grid)*2)/4032,'estimated_candidate_check_cpu_seconds_upper_linear':6.215971*(5*8*len(grid)*2*6)/18294,'extra_budget':'Serialization, full 5! error-free input reuse, 5*7! tours, plotting and packaging expected to fit; hard sequential process budget governs.'},
 'external_model_calls':0,'paid_calls':0,'upload':False,'failure_wording':'If no complete tour is found, call it failure of this expanded finite graph. Never claim continuous infeasibility. A verified tour is a continuous feasible witness for that fixed original instance, not a continuous-space optimum.'}
# Typographical estimate phrase must be exact task count.
cfg['computation_estimate']['extra_budget']='Serialization, five selected cases, 5*7! orders, plotting and packaging expected to fit; hard sequential process budget governs.'
dump(ROOT/'freeze.json',cfg)
inputs=[ROOT/'freeze.json',*sorted((ROOT/'input').glob('*')),ROOT/'source/dubins.py']
(ROOT/'freeze.sha256').write_text(''.join(sha(p)+'  '+str(p.relative_to(ROOT))+'\n' for p in inputs))
print(json.dumps({'frozen_utc':cfg['frozen_utc'],'grid_poses':len(grid),'leg_generation_budget':cfg['connections']['leg_generation_budget'],'estimate':cfg['computation_estimate']},indent=2))
