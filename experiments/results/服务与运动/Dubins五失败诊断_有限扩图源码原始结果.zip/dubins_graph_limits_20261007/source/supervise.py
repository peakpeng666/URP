#!/usr/bin/env python3
"""Sequential cumulative CPU ledger and per-child remaining-budget limit."""
import resource,time,sys,subprocess,json,hashlib,os,datetime,math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def usage():
 r=resource.getrusage(resource.RUSAGE_SELF);c=resource.getrusage(resource.RUSAGE_CHILDREN)
 return {'self_user':r.ru_utime,'self_system':r.ru_stime,'children_user':c.ru_utime,'children_system':c.ru_stime}
def total():return sum(usage().values())
def dump(x):(ROOT/'evidence/resource.json').write_text(json.dumps(x,indent=2)+'\n')
cmds=sys.argv[1:] or ['experiment.py','verify.py','report.py','archive.py']
assert not (ROOT/'evidence/resource.json').exists(),'No automatic repeat.'
# All outcome-producing source files must be frozen before first solve.
files=[p for p in (ROOT/'source').glob('*.py')]
(ROOT/'source.sha256').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(ROOT))+'\n' for p in sorted(files)))
state={'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'budget_cpu_seconds':120,'budget_scope':'All sequential child processes + supervisor including startup/import/serialization/verification/figures/report/archive. Pre-freeze preparation and read-only input inspection excluded. No paid or model API use.','steps':[],'status':'running'}
for name in cmds:
 remaining=119-total();cap=math.floor(remaining)
 if cap<1:state['status']='budget_exhausted_before_'+name;dump(state);sys.exit(2)
 def limit():resource.setrlimit(resource.RLIMIT_CPU,(cap,cap))
 before=total();t=time.perf_counter()
 with (ROOT/'evidence'/f'{Path(name).stem}.log').open('w') as f:
  p=subprocess.run([sys.executable,str(ROOT/'source'/name)],env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MPLCONFIGDIR=str(ROOT/'evidence/mplcache')),stdout=f,stderr=subprocess.STDOUT,preexec_fn=limit)
 step={'step':name,'exit_code':p.returncode,'wall_seconds':time.perf_counter()-t,'cpu_seconds_with_supervisor_overhead':total()-before,'child_hard_cpu_limit_seconds':cap}
 state['steps'].append(step);state['cpu_usage_seconds']=usage();state['total_cpu_seconds']=total();dump(state);print(json.dumps(step),flush=True)
 if p.returncode:state['status']='failed_or_budget_terminated';dump(state);sys.exit(p.returncode)
state['status']='completed';state['ended_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();state['cpu_usage_seconds']=usage();state['total_cpu_seconds']=total();state['within_budget']=total()<120;dump(state)
print(json.dumps(state),flush=True)
