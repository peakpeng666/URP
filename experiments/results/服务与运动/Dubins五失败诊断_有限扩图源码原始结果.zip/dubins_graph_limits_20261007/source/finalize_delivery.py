#!/usr/bin/env python3
import json,math,hashlib,shutil,sys,os,subprocess,resource,time,datetime
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def usage():
 r=resource.getrusage(resource.RUSAGE_SELF);c=resource.getrusage(resource.RUSAGE_CHILDREN);return r.ru_utime+r.ru_stime+c.ru_utime+c.ru_stime
state=json.loads((ROOT/'evidence/resource.json').read_text());assert state['status']=='completed';base=state['total_cpu_seconds'];assert 'postprocessing' not in state
shutil.copyfile(ROOT/'evidence/resource.json',ROOT/'evidence/resource_initial.json');shutil.copyfile(ROOT/'evidence/archive.log',ROOT/'evidence/archive_initial.log')
files=[ROOT/'source/export_edge_witnesses.py',ROOT/'source/finalize_delivery.py'];(ROOT/'postprocessing_source.sha256').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(ROOT))+'\n' for p in files))
state['postprocessing']='Export already-selected 10 partial edge witnesses; no search or grid change. Includes second final clean archive; preserves first archive evidence.'
state['status']='postprocessing_running'
def save():
 state['total_cpu_seconds']=base+usage();state['postprocessing_cpu_seconds']=usage();(ROOT/'evidence/resource.json').write_text(json.dumps(state,indent=2)+'\n')
initial=ROOT.with_name(ROOT.name+'_delivery.zip');initial.rename(ROOT.with_name(ROOT.name+'_initial_pre_witnesses.zip'))
for script in ['export_edge_witnesses.py','archive.py']:
 cap=math.floor(119-base-usage());assert cap>0
 def limit():resource.setrlimit(resource.RLIMIT_CPU,(cap,cap))
 save();before=usage();t=time.perf_counter()
 with (ROOT/'evidence'/f'{Path(script).stem}.log').open('w') as f:
  p=subprocess.run([sys.executable,str(ROOT/'source'/script)],env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MPLCONFIGDIR=str(ROOT/'evidence/mplcache')),stdout=f,stderr=subprocess.STDOUT,preexec_fn=limit)
 state['steps'].append({'step':script,'stage':'postprocessing_without_search','exit_code':p.returncode,'wall_seconds':time.perf_counter()-t,'cpu_seconds_with_supervisor_overhead':usage()-before,'child_hard_cpu_limit_seconds':cap});save();assert p.returncode==0
state['status']='completed';state['within_budget']=base+usage()<120;state['ended_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
z=ROOT.with_name(ROOT.name+'_delivery.zip');proof={'root':str(ROOT),'zip':str(z),'zip_sha256':hashlib.sha256(z.read_bytes()).hexdigest(),'zip_bytes':z.stat().st_size,'final_resource_ledger':str(ROOT/'evidence/resource.json'),'resource_sha256':hashlib.sha256((ROOT/'evidence/resource.json').read_bytes()).hexdigest(),'formal_and_postprocessing_cpu_seconds':state['total_cpu_seconds'],'selection':'exactly five original graph failures','complete_witness_tours':0,'partial_node_pair_witnesses':10,'no_continuous_infeasibility_claim':True,'no_upload_performed':True,'final_zip_contents_checked':'archive.py verified each SHA256 and ZIP CRC'}
(ROOT/'DELIVERY.json').write_text(json.dumps(proof,indent=2)+'\n');(ROOT/'delivery.sha256').write_text(proof['zip_sha256']+'  '+z.name+'\n');print(json.dumps(proof,indent=2))
