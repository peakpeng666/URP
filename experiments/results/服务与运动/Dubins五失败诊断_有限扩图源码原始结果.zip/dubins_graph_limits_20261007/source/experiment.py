#!/usr/bin/env python3
import json,math,hashlib,time,datetime,csv,resource
from pathlib import Path
from dubins import candidates,held_karp
ROOT=Path(__file__).resolve().parents[1]
def dump(p,x): p.write_text(json.dumps(x,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
def pack(p): return {k:v for k,v in p.items() if k!='segments'}
def finite(x): return x if math.isfinite(x) else None
def main():
 t=time.perf_counter();cpu=time.process_time()
 cfg=json.loads((ROOT/'freeze.json').read_text());grid=json.loads((ROOT/'input/intermediate_grid.json').read_text())
 for l in (ROOT/'freeze.sha256').read_text().splitlines():
  h,p=l.split('  ');assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h,p
 assert not (ROOT/'raw/results.json').exists(),'Never overwrite a diagnostic run.'
 inputs={g['geometry_id']+'_R6':g for g in json.loads((ROOT/'input/instances_selected5.json').read_text())}
 originals={}
 for l in (ROOT/'input/original_edges_selected5.jsonl').read_text().splitlines():
  e=json.loads(l);originals[(e['instance_id'],e['i'],e['j'])]=e
 rows=[];graphs=[];cnt={'leg_pairs':0,'candidates':0,'valid_candidates':0,'missing_legs':0,'via_pairs_evaluated':0,'via_pairs_feasible':0};start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (ROOT/'raw/legs.jsonl').open('w') as f:
  for iid in cfg['instance_ids']:
   ps=inputs[iid]['poses'];R=cfg['R'];box=cfg['rectangle'];legs={};local=dict.fromkeys(cnt,0)
   for i,q in enumerate(ps):
    for gi,g in enumerate(grid):
     for direction in ('out','in'):
      q0,q1=(q,g['pose']) if direction=='out' else (g['pose'],q)
      paths=candidates(q0,q1,R,box);fps=[p for p in paths if p['feasible']]
      best=min(fps,key=lambda p:(p['length'],p['word'])) if fps else None
      key=(i,gi,direction);legs[key]={'q0':q0,'q1':q1,'path':pack(best)} if best else None
      f.write(json.dumps({'instance_id':iid,'node':i,'grid_index':gi,'grid_id':g['grid_id'],'direction':direction,'R':R,'q0':q0,'q1':q1,'candidates':[pack(p) for p in paths], 'unavailable_words':[w for w in ('LSL','RSR','RSL','LSR','RLR','LRL') if w not in [p['word'] for p in paths]],'selected_word':best['word'] if best else None,'cost':best['length'] if best else None},separators=(',',':'),allow_nan=False)+'\n')
      local['leg_pairs']+=1;local['candidates']+=len(paths);local['valid_candidates']+=len(fps);local['missing_legs']+=best is None
   cost=[[math.inf]*8 for _ in range(8)];ocost=[[math.inf]*8 for _ in range(8)];edges={}
   for i in range(8):
    for j in range(8):
     if i==j:continue
     o=originals[(iid,i,j)];best=None;bestkey=None
     if o['cost'] is not None:
      p=next(p for p in o['candidates'] if p['word']==o['selected_word'])
      ocost[i][j]=o['cost'];best={'i':i,'j':j,'type':'direct','grid_id':None,'grid_index':None,'length':o['cost'],'original_cost':o['cost'],'components':[{'q0':ps[i],'q1':ps[j],'path':pack(p)}]};bestkey=(o['cost'],0,-1)
     for gi,g in enumerate(grid):
      a,b=legs[(i,gi,'out')],legs[(j,gi,'in')];local['via_pairs_evaluated']+=1
      if a is None or b is None:continue
      local['via_pairs_feasible']+=1;length=a['path']['length']+b['path']['length'];key=(length,1,gi)
      if bestkey is None or key<bestkey:
       bestkey=key;best={'i':i,'j':j,'type':'via_one_grid_pose','grid_id':g['grid_id'],'grid_index':gi,'length':length,'original_cost':o['cost'],'components':[a,b]}
     if best:cost[i][j]=best['length'];edges[f'{i},{j}']=best
     assert cost[i][j]<=ocost[i][j]
   original_value,original_route=held_karp(ocost);assert original_route is None
   value,route=held_karp(cost)
   row={'instance_id':iid,'selected_after_original_failure':True,'original_feasible_edges':sum(math.isfinite(x) for r in ocost for x in r),'expanded_feasible_edges':sum(math.isfinite(x) for r in cost for x in r),'newly_connected_edges':[[i,j] for i in range(8) for j in range(8) if math.isfinite(cost[i][j]) and not math.isfinite(ocost[i][j])], 'outgoing_missing_nodes':[i for i in range(8) if not any(math.isfinite(cost[i][j]) for j in range(8))], 'incoming_missing_nodes':[j for j in range(8) if not any(math.isfinite(cost[i][j]) for i in range(8))], 'feasible':route is not None,'tour':list(route) if route else None,'length':finite(value),'status':'continuous_feasible_witness_pending_independent_verification' if route else 'expanded_finite_graph_no_tour','counts':local}
   graphs.append({'instance_id':iid,'cost':[[finite(x) for x in r] for r in cost],'selected_edges':edges,'original_cost':[[finite(x) for x in r] for r in ocost]})
   if route:
    selected=[edges[f'{i},{j}'] for i,j in zip(route,route[1:])]
    witness={'instance_id':iid,'scope':'Synthetic single-vehicle geometric/task-order component, not a complete multi-vehicle system.','R':R,'rectangle':box,'fixed_service_poses':ps,'route':list(route),'length':value,'edges':selected,'original_missing_edges_on_route':[[e['i'],e['j']] for e in selected if e['original_cost'] is None]}
    dump(ROOT/'routes'/f'{iid}.json',witness)
   for k in cnt:cnt[k]+=local[k]
   rows.append(row);print(json.dumps(row,ensure_ascii=False),flush=True)
 dump(ROOT/'raw/results.json',rows);dump(ROOT/'raw/graphs.json',graphs);dump(ROOT/'raw/failures.json',[r for r in rows if not r['feasible']])
 status={'status':'completed','started_utc':start,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'wall_seconds':time.perf_counter()-t,'cpu_seconds':time.process_time()-cpu,'counts':cnt,'external_model_calls':0,'paid_calls':0,'freeze_sha256':hashlib.sha256((ROOT/'freeze.json').read_bytes()).hexdigest()}
 dump(ROOT/'evidence/run_status.json',status)
 print(json.dumps(status),flush=True)
if __name__=='__main__':main()
