#!/usr/bin/env python3
"""Postprocessing only: export already-selected new edges; no search/grid change."""
import json,csv,math,hashlib,time
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from verify import verify_path,error,S
ROOT=Path(__file__).resolve().parents[1]
def dump(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
def main():
 cpu=time.process_time();cfg=json.loads((ROOT/'freeze.json').read_text());rows=json.loads((ROOT/'raw/results.json').read_text());graphs={x['instance_id']:x for x in json.loads((ROOT/'raw/graphs.json').read_text())};grids=json.loads((ROOT/'input/intermediate_grid.json').read_text());R=cfg['R'];box=cfg['rectangle'];tol=cfg['tolerances'];out=ROOT/'edge_witnesses';out.mkdir(exist_ok=True)
 original={}
 for l in (ROOT/'input/original_edges_selected5.jsonl').open():
  x=json.loads(l);original[(x['instance_id'],x['i'],x['j'])]=x
 needed=set()
 for row in rows:
  for i,j in row['newly_connected_edges']:
   edge=graphs[row['instance_id']]['selected_edges'][f'{i},{j}'];gi=edge['grid_index'];needed|={(row['instance_id'],i,gi,'out'),(row['instance_id'],j,gi,'in')}
 raw={}
 for l in (ROOT/'raw/legs.jsonl').open():
  x=json.loads(l);key=(x['instance_id'],x['node'],x['grid_index'],x['direction'])
  if key in needed:raw[key]=x
 assert len(raw)==len(needed)
 index=[];example=None
 for row in rows:
  iid=row['instance_id']
  for i,j in row['newly_connected_edges']:
   edge=graphs[iid]['selected_edges'][f'{i},{j}'];o=original[(iid,i,j)];assert o['cost'] is None and all(not p['feasible'] for p in o['candidates']);gi=edge['grid_index'];prev=edge['components'][0]['q0'];samples=[];total=0.;margins=[]
   for ci,c in enumerate(edge['components']):
    record=raw[(iid,i if ci==0 else j,gi,'out' if ci==0 else 'in')];p=next(p for p in record['candidates'] if p['word']==record['selected_word'])
    assert c['path']==p and c['q0']==record['q0'] and c['q1']==record['q1']
    pe,he=error(prev,c['q0']);assert pe<tol['endpoint_m'] and he<tol['heading_rad']
    margin,pts,end=verify_path(c['q0'],c['q1'],c['path'],R,box,tol,True);assert margin>=-tol['boundary_m'];margins.append(margin)
    for s in pts:s.update(component=ci,s_global_m=total+s['s_in_component_m'])
    samples.extend(pts);total+=c['path']['length'];prev=end
   assert edge['components'][0]['q1']==edge['components'][1]['q0']==grids[gi]['pose'];assert abs(total-edge['length'])<tol['tour_m']
   name=f'{iid}_{i}_to_{j}'
   proof={'kind':'partial_node_pair_connection_only','not_a_complete_7_task_tour':True,'instance_id':iid,'R':R,'rectangle':box,'edge':edge,'original_direct_candidates':[{k:p[k] for k in ['word','params','length','bbox','boundary_margin','feasible']} for p in o['candidates']],'original_unavailable_words':[w for w in ['LSL','RSR','RSL','LSR','RLR','LRL'] if w not in [p['word'] for p in o['candidates']]],'independent_integral_check':{'passed':True,'minimum_boundary_margin_m':min(margins),'component_join_pose':grids[gi]['pose']},'scope':'Synthetic single-vehicle geometric connection; full selected instance still has no tour in the expanded graph.'}
   dump(out/f'{name}.json',proof)
   with (out/f'{name}.csv').open('w',newline='') as f:
    wr=csv.DictWriter(f,fieldnames=list(samples[0]));wr.writeheader();wr.writerows(samples)
   index.append({'instance_id':iid,'i':i,'j':j,'length_m':total,'via_pose':grids[gi]['pose'],'words':[c['path']['word'] for c in edge['components']],'minimum_margin_m':min(margins),'json':f'{name}.json','csv':f'{name}.csv'})
   if example is None:example=(proof,samples)
 assert len(index)==10;dump(out/'index.json',index)
 proof,pts=example;edge=proof['edge'];fig,(ax,txt)=plt.subplots(1,2,figsize=(12,5),gridspec_kw={'width_ratios':[1.4,1]},constrained_layout=True)
 ax.add_patch(Rectangle((0,0),40,30,fill=False,color='black',lw=1.5))
 for ci,col in [(0,'#2165a0'),(1,'#d4761e')]:
  data=[p for p in pts if p['component']==ci];ax.plot([p['x'] for p in data],[p['y'] for p in data],c=col,lw=2,label=f"Leg {ci+1}: {edge['components'][ci]['path']['word']}")
 poses=[(edge['components'][0]['q0'],str(edge['i'])),(edge['components'][0]['q1'],'via'),(edge['components'][1]['q1'],str(edge['j']))]
 for (x,y,h),label in poses:
  ax.scatter([x],[y],c='black',s=35);ax.arrow(x,y,2*math.cos(h),2*math.sin(h),width=.06,head_width=.6,color='black',length_includes_head=True);ax.annotate(label,(x,y),xytext=(6,7),textcoords='offset points')
 ax.set(xlim=(-1,41),ylim=(-1,31),aspect='equal',xlabel='x (m)',ylabel='y (m)',title=f"{proof['instance_id']}: node {edge['i']} to {edge['j']}");ax.legend(loc='lower left');ax.grid(alpha=.15)
 txt.axis('off');lines=['PARTIAL CONNECTION WITNESS','',f"Length: {edge['length']:.6f} m",f"Via pose: {edge['components'][0]['q1']}",'','All original standard direct candidates fail:',*[(p['word']+f": boundary margin {p['boundary_margin']:.3f} m") for p in proof['original_direct_candidates']],*[(w+': no real-valued candidate') for w in proof['original_unavailable_words']],'','Both extended legs verified by integration.','Same R, endpoints, headings and rectangle.','','This is one node-pair connection only.','The full 7-task tour is still unavailable.','Synthetic geometric component;','not a complete multi-vehicle system.']
 txt.text(0,1,'\n'.join(lines),va='top',fontsize=10)
 fig.savefig(ROOT/'figures/partial_connection_example.png',dpi=150);plt.close(fig)
 note='''局部连接见证补充说明\n\n本补充只导出已冻结、已运行结果中的10条新增节点对连接，没有追加搜索、扩大格点或调整顺序。所有5个完整7任务tour仍失败。\n\n10条连接分别为 near_boundary_01_R6 的2→4、3→7、6→2、6→7，near_boundary_03_R6 的3→2，near_boundary_11_R6 的2→4、3→1、3→6、4→2、6→3。\n\n这些原节点对的全部原标准直接Dubins候选均越界或无实数解；经一个冻结中间位姿可由两条合法曲线拼接。两段分别采用原R=6、原端点/方向和矩形，拼接位置及航向连续。逐组件数值积分、完整弧段边界极值和曲率验证通过。因此它们是连续空间中“单个节点对连接”的可行见证，确实表明原直接候选边集不完备，但不能说任何原失败实例已被完整救回。\n\nedge_witnesses/index.json列出全部10条；每条均有精确参数JSON及0.1米以内步长的可视化CSV，CSV本身不承担连续碰撞证明。figures/partial_connection_example.png展示按原实例顺序、节点序选出的第一条，不是按视觉或效果挑选。\n\n119位姿的来源已在运行前freeze.json冻结：15位置×8方向=120，唯一剔除项为x2_y1_h0，即(20,15,0)，它与原depot完全重合。该剔除不依据可行性；没有地图外过滤、结果后删点或增加格点。\n'''
 (ROOT/'EDGE_WITNESSES_ZH.txt').write_text(note)
 dump(ROOT/'evidence/edge_witness_verification.json',{'status':'passed','edges_exported':len(index),'all_full_tours_still_failed':all(not r['feasible'] for r in rows),'new_search_calls':0,'grid_changed':False,'direct_candidates_rechecked_from_original_records':True,'selected_components_match_raw_legs':True,'independent_geometry_stats':S,'cpu_seconds':time.process_time()-cpu,'figure_example_selection':'First new edge in original instance order and lexicographic node order; no selection by success quality.'})
 print(json.dumps({'exported':len(index),'new_search_calls':0,'cpu_seconds':time.process_time()-cpu},indent=2))
if __name__=='__main__':main()
