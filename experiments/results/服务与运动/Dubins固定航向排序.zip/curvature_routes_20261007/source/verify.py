#!/usr/bin/env python3
"""Independent raw-output verification. Does NOT import production dubins.py.
Uses Gauss-Legendre integration of (cos heading, sin heading), derivative
roots for box extrema, Menger curvature, and all permutations for tours.
The pinned C++ check is additional implementation consistency evidence.
"""
import json, math, itertools, subprocess, time, resource
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
TAU=2*math.pi
WORDS=['LSL','RSR','RSL','LSR','RLR','LRL']
GN,GW=np.polynomial.legendre.leggauss(32)

def clean_cost(mat): return np.array([[np.inf if v is None else v for v in r] for r in mat])

def integral_xy(h,k,lengths):
    """Vector of displacements, integrating the unit-speed ODE by quadrature."""
    lengths=np.atleast_1d(lengths).astype(float)
    s=(GN[None,:]+1)*lengths[:,None]/2
    hs=h+k*s
    return np.column_stack(((np.cos(hs)*GW).sum(axis=1)*lengths/2,
                            (np.sin(hs)*GW).sum(axis=1)*lengths/2))

def main():
    start=time.perf_counter();cpu=time.process_time()
    cfg=json.loads((ROOT/'freeze.json').read_text()); box=cfg['rectangle'];tol=cfg['numeric_verification_tolerances']
    graphs={g['instance_id']:g for g in json.loads((ROOT/'raw/graphs.json').read_text())}
    rows=json.loads((ROOT/'raw/results.json').read_text())
    geoms={g['geometry_id']:g for g in json.loads((ROOT/'instances.json').read_text())}
    stats={'edges_checked':0,'candidates_checked':0,'segments_checked':0,'curvature_checks':0,
           'zero_length_curvature_skips':0,'feasible_candidates':0,
           'max_endpoint_error_m':0.,'max_heading_error_rad':0.,'max_length_error_m':0.,
           'max_curvature_error':0.,'max_bbox_error_m':0.,'max_ompl_parameter_error':0.,
           'max_dp_bruteforce_cost_error_m':0.,'max_euclidean_bruteforce_cost_error_m':0.,
           'candidate_words_checked':{w:0 for w in WORDS}}
    edges=[json.loads(s) for s in (ROOT/'raw/edges.jsonl').read_text().splitlines()]
    # Reference raw six-word comparison, all 4032 formal edges (including infeasible ones).
    lines=[]
    for e in edges:
        q0,q1,R=e['q0'],e['q1'],e['R'];dx=q1[0]-q0[0];dy=q1[1]-q0[1];th=math.atan2(dy,dx)
        lines.append(f'{math.hypot(dx,dy)/R:.17g} {(q0[2]-th)%TAU:.17g} {(q1[2]-th)%TAU:.17g}\n')
    ref=subprocess.run([str(ROOT/'reference/ompl_six_word_harness')],input=''.join(lines),text=True,capture_output=True)
    assert ref.returncode==0,ref.stderr
    (ROOT/'evidence/ompl_formal_input.txt').write_text(''.join(lines))
    (ROOT/'evidence/ompl_formal_output.txt').write_text(ref.stdout)
    for e,refline in zip(edges,ref.stdout.splitlines(),strict=True):
      refs=list(map(float,refline.split()));ps={p['word']:p for p in e['candidates']}
      assert len(refs)==18
      for wi,word in enumerate(WORDS):
        values=refs[wi*3:wi*3+3]
        assert (word in ps)==math.isfinite(values[0]),('word_domain',e['instance_id'],e['i'],e['j'],word)
        if word in ps:
            err=max(abs(x-y) for x,y in zip(values,ps[word]['params']))
            stats['max_ompl_parameter_error']=max(stats['max_ompl_parameter_error'],err)
            assert err<1e-8,('OMPL',err,e,word)
      for path in e['candidates']:
        stats['candidates_checked']+=1;stats['candidate_words_checked'][path['word']]+=1
        R=e['R'];q=np.array(e['q0'],dtype=float);boxes=[];total=0
        for letter,u,sg in zip(path['word'],path['params'],path['segments'],strict=True):
          stats['segments_checked']+=1
          assert u>=0 and math.isfinite(u)
          length=u*R;k=0. if letter=='S' else (1. if letter=='L' else -1.)/R
          assert np.max(abs(q-np.array(sg['start'])))<tol['endpoint_m']
          times=[0.,length]
          if k!=0:
            lo,hi=sorted((q[2],q[2]+k*length))
            for n in range(math.ceil(lo/(math.pi/2)),math.floor(hi/(math.pi/2))+1):
              s=(n*(math.pi/2)-q[2])/k
              if 0<=s<=length: times.append(s)
          points=integral_xy(q[2],k,times)+q[:2]
          bx=[points[:,0].min(),points[:,0].max(),points[:,1].min(),points[:,1].max()];boxes.append(bx)
          be=float(np.max(abs(np.array(bx)-np.array(sg['bbox']))))
          stats['max_bbox_error_m']=max(stats['max_bbox_error_m'],be)
          assert be<tol['bbox_m'],('segment_bbox',be)
          # Integrate speed separately. Signed Menger curvature is estimated from trajectory positions.
          angles=q[2]+k*(GN+1)*length/2
          integrated_length=float(np.dot(np.hypot(np.cos(angles),np.sin(angles)),GW)*length/2)
          le=abs(integrated_length-sg['length']);stats['max_length_error_m']=max(stats['max_length_error_m'],le)
          assert le<tol['segment_length_m'];total+=integrated_length
          if length>1e-8:
            pts=integral_xy(q[2],k,[.3*length,.5*length,.7*length])
            a=pts[1]-pts[0];b=pts[2]-pts[1];c=pts[2]-pts[0]
            denom=np.linalg.norm(a)*np.linalg.norm(b)*np.linalg.norm(c)
            curv=2*(a[0]*b[1]-a[1]*b[0])/denom
            ce=abs(curv-k);stats['max_curvature_error']=max(stats['max_curvature_error'],float(ce));stats['curvature_checks']+=1
            assert ce<tol['curvature_abs'],('curvature',ce,letter,length,e['instance_id'])
            assert abs(curv)<=1/R+tol['curvature_abs']
          else: stats['zero_length_curvature_skips']+=1
          endxy=integral_xy(q[2],k,[length])[0]+q[:2]
          q=np.r_[endxy,q[2]+k*length]
          assert np.max(abs(q-np.array(sg['end'])))<tol['endpoint_m']
        pe=float(np.linalg.norm(q[:2]-np.array(e['q1'][:2])));he=abs(math.remainder(float(q[2])-e['q1'][2],TAU))
        stats['max_endpoint_error_m']=max(stats['max_endpoint_error_m'],pe)
        stats['max_heading_error_rad']=max(stats['max_heading_error_rad'],he)
        assert pe<tol['endpoint_m'] and he<tol['heading_rad'],('endpoint',pe,he)
        assert abs(total-path['length'])<tol['segment_length_m']
        bbox=[min(b[0] for b in boxes),max(b[1] for b in boxes),min(b[2] for b in boxes),max(b[3] for b in boxes)]
        margin=min(bbox[0]-box[0],box[1]-bbox[1],bbox[2]-box[2],box[3]-bbox[3])
        assert (margin>=-1e-9)==path['feasible'],('boundary_classification',margin,path['boundary_margin'])
        if path['feasible']: stats['feasible_candidates']+=1
      fps=[p for p in e['candidates'] if p['feasible']]
      best=min(fps,key=lambda p:(p['length'],p['word'])) if fps else None
      assert e['cost']==(best['length'] if best else None)
      assert e['selected_word']==(best['word'] if best else None)
      gr=graphs[e['instance_id']]
      assert gr['cost'][e['i']][e['j']]==e['cost']
      stats['edges_checked']+=1
    routes=np.array([(0,)+p+(0,) for p in itertools.permutations(range(1,8))])
    brute=[]
    for row in rows:
      cost=clean_cost(graphs[row['instance_id']]['cost'])
      all_cost=cost[routes[:,:-1],routes[:,1:]].sum(axis=1)
      ix=int(np.argmin(all_cost));optimal=float(all_cost[ix]);finite=math.isfinite(optimal)
      assert finite==row['dubins_dp_feasible']
      if finite:
        err=abs(optimal-row['dubins_dp_cost']);stats['max_dp_bruteforce_cost_error_m']=max(stats['max_dp_bruteforce_cost_error_m'],err)
        assert err<tol['tour_cost_m']
        tour=row['dubins_dp_route'];assert sorted(tour[1:-1])==list(range(1,8)) and tour[0]==tour[-1]==0
        assert abs(sum(cost[a,b] for a,b in zip(tour,tour[1:]))-optimal)<tol['tour_cost_m']
      xy=np.array(geoms[row['geometry_id']]['poses'])[:,:2]
      ec=np.linalg.norm(xy[:,None,:]-xy[None,:,:],axis=2)
      es=ec[routes[:,:-1],routes[:,1:]].sum(axis=1);ev=float(es.min())
      ee=abs(ev-row['euclidean_optimum']);stats['max_euclidean_bruteforce_cost_error_m']=max(stats['max_euclidean_bruteforce_cost_error_m'],ee)
      assert ee<tol['tour_cost_m']
      tied=np.flatnonzero(abs(es-ev)<=1e-8)
      assert routes[tied].tolist()==row['euclidean_optimal_orders']
      baseline=float(all_cost[tied].min())
      assert math.isfinite(baseline)==row['baseline_feasible']
      if math.isfinite(baseline): assert abs(baseline-row['baseline_cost'])<tol['tour_cost_m']
      assert row['ordering_only_failure']==(finite and not math.isfinite(baseline))
      brute.append({'instance_id':row['instance_id'],'permutations':len(routes),'feasible_orders':int(np.isfinite(all_cost).sum()),
        'graph_optimum':optimal if finite else None,'graph_optimal_order':routes[ix].tolist() if finite else None,
        'baseline_best_tied_cost':baseline if math.isfinite(baseline) else None,'passed':True})
    (ROOT/'evidence/bruteforce_all_instances.json').write_text(json.dumps(brute,indent=2)+'\n')
    stats.update(status='passed',formal_instances_verified=len(rows),permutations_per_instance=len(routes),
                 total_orders_enumerated=len(rows)*len(routes),wall_seconds=time.perf_counter()-start,
                 cpu_seconds=time.process_time()-cpu,max_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                 independence='No imports from production implementation; quadrature trajectory, derivative-root extrema, Menger curvature, all-permutation tour oracle. Official OMPL comparison is formula consistency, not independent derivation.')
    (ROOT/'evidence/verification.json').write_text(json.dumps(stats,indent=2)+'\n')
    print(json.dumps(stats,indent=2))
if __name__=='__main__': main()
