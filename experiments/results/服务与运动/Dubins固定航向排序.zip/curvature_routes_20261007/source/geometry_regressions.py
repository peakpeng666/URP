"""Targeted edge/arc checks, auxiliary validation rather than formal samples."""
import json,math,time
from pathlib import Path
from dubins import segment
ROOT=Path(__file__).resolve().parents[1];cpu=time.process_time()
cases=[
 ('long_left_arc',[0,0,0],'L',3*math.pi/2,1,[-1,1,0,2]),
 ('full_left_circle',[0,0,0],'L',2*math.pi,1,[-1,1,0,2]),
 ('full_right_circle',[0,0,0],'R',2*math.pi,1,[-1,1,-2,0]),
 ('cardinal_wrap',[2,3,3*math.pi/2],'L',math.pi,2,[2,6,1,3]),
 ('straight_on_boundary',[0,0,0],'S',4,2,[0,8,0,0])]
res=[]
for name,q,k,u,R,expected in cases:
 sg=segment(q,k,u,R);err=max(abs(a-b) for a,b in zip(sg['bbox'],expected))
 assert err<1e-10,(name,sg['bbox'],expected)
 res.append({'name':name,'bbox':sg['bbox'],'expected_bbox':expected,'passed':True})
# In this rectangle the long left arc has both endpoints inside yet goes out.
sg=segment([0,0,0],'L',3*math.pi/2,1);box=[-1.1,.1,-.1,1.1]
inside=lambda q:box[0]<=q[0]<=box[1] and box[2]<=q[1]<=box[3]
assert inside(sg['start']) and inside(sg['end'])
assert not(box[0]<=sg['bbox'][0] and sg['bbox'][1]<=box[1] and box[2]<=sg['bbox'][2] and sg['bbox'][3]<=box[3])
res.append({'name':'both_endpoints_inside_arc_outside','passed':True,'start':sg['start'],'end':sg['end'],'bbox':sg['bbox'],'rectangle':box})
status={'status':'passed','auxiliary_cases':res,'not_formal_samples':True,'cpu_seconds':time.process_time()-cpu}
(ROOT/'evidence/geometry_regressions.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status,indent=2))
