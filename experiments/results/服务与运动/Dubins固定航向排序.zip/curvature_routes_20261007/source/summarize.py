#!/usr/bin/env python3
import json,csv,statistics,math,time,resource
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
ROOT=Path(__file__).resolve().parents[1]

def main():
  t=time.perf_counter();cpu=time.process_time()
  rows=json.loads((ROOT/'raw/results.json').read_text())
  geoms={g['geometry_id']:g for g in json.loads((ROOT/'instances.json').read_text())}
  summary=[]
  for group in ['all','interior','near_boundary']:
    for radius in ['all',1.,3.,6.]:
      rs=[r for r in rows if(group=='all' or r['group']==group)and(radius=='all' or r['R']==radius)]
      gaps=[r['common_feasible_gap_pct'] for r in rs if r['common_feasible_gap_pct'] is not None]
      summary.append({'group':group,'R':radius,'instances':len(rs),
        'baseline_feasible':sum(r['baseline_feasible'] for r in rs),
        'dubins_dp_feasible':sum(r['dubins_dp_feasible'] for r in rs),
        'ordering_only_failures':sum(r['ordering_only_failure'] for r in rs),
        'both_failures':sum(not r['baseline_feasible'] and not r['dubins_dp_feasible'] for r in rs),
        'common_feasible':len(gaps),'gap_mean_pct':statistics.mean(gaps) if gaps else None,
        'gap_median_pct':statistics.median(gaps) if gaps else None,
        'gap_min_pct':min(gaps) if gaps else None,'gap_max_pct':max(gaps) if gaps else None,
        'ties_rescued_failure_diagnostic':sum(r['tie_resolution_rescued_failure'] for r in rs)})
  (ROOT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
  with (ROOT/'summary.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(summary[0]));w.writeheader();w.writerows(summary)
  (ROOT/'failure_index.json').write_text(json.dumps({
    'ordering_only_failures':[r['instance_id'] for r in rows if r['ordering_only_failure']],
    'both_failures_in_candidate_graph':[r['instance_id'] for r in rows if not r['dubins_dp_feasible']],
    'tie_direction_rescues':[r['instance_id'] for r in rows if r['tie_resolution_rescued_failure']],
    'all_failures_retained':'raw/failures.json'},indent=2)+'\n')
  fig,axes=plt.subplots(1,2,figsize=(11.6,4.5),layout='constrained')
  x=np.arange(3);ss=[r for r in summary if r['group']=='all' and r['R']!='all']
  for offset,key,label,color in [(-.18,'baseline_feasible','Euclidean order + Dubins','#f09146'),(.18,'dubins_dp_feasible','Feasible-Dubins graph DP','#247c69')]:
    bars=axes[0].bar(x+offset,[r[key] for r in ss],.36,label=label,color=color)
    axes[0].bar_label(bars,labels=[f"{r[key]}/24" for r in ss],padding=3,fontsize=10)
  axes[0].set(xticks=x,xticklabels=['1 m','3 m','6 m'],ylim=(0,29),ylabel='Feasible closed tours',xlabel='Minimum turning radius')
  axes[0].legend(loc='upper right',fontsize=8);axes[0].set_title('All 72 cases retained')
  gs=[[r['common_feasible_gap_pct'] for r in rows if r['R']==rad and r['common_feasible_gap_pct'] is not None] for rad in [1.,3.,6.]]
  axes[1].boxplot(gs,tick_labels=[f'1 m (n={len(gs[0])})',f'3 m (n={len(gs[1])})',f'6 m (n={len(gs[2])})'],patch_artist=True,
     boxprops={'facecolor':'#dbece8'},medianprops={'color':'#247c69','linewidth':2})
  axes[1].set(ylabel='(Baseline / graph optimum - 1) x 100 (%)',xlabel='Radius; common-feasible cases only')
  axes[1].set_title('Euclidean-order excess length')
  fig.suptitle('Fixed-heading, forward-only Dubins routing component',fontsize=14)
  fig.savefig(ROOT/'summary.png',dpi=180);plt.close(fig)
  # Explicit, post-outcome illustration selection, never a sample used for inference.
  chosen=next(r for r in rows if r['ordering_only_failure'])
  eid=chosen['instance_id'];edges={}
  for line in (ROOT/'raw/edges.jsonl').read_text().splitlines():
    e=json.loads(line)
    if e['instance_id']==eid: edges[e['i'],e['j']]=e
  poses=np.array(geoms[chosen['geometry_id']]['poses'])
  fig,axs=plt.subplots(1,2,figsize=(12,6.3))
  fig.subplots_adjust(top=.78,bottom=.09,left=.055,right=.99,wspace=.17)
  for ax,kind,route in [(axs[0],'Euclidean-tie baseline',chosen['baseline_route']),(axs[1],'Feasible-Dubins graph optimum',chosen['dubins_dp_route'])]:
    ax.add_patch(plt.Rectangle((0,0),40,30,fill=False,color='#384049',linewidth=1.5))
    for i,j in zip(route,route[1:]):
      e=edges[i,j]
      p=next((p for p in e['candidates'] if p['word']==e['selected_word']),None)
      missing=p is None
      if p is None: p=min(e['candidates'],key=lambda p:p['length'])
      for sg in p['segments']:
        q=sg['start'];R=e['R'];u=np.linspace(0,sg['u'],90)
        if sg['kind']=='S': X=q[0]+R*u*np.cos(q[2]);Y=q[1]+R*u*np.sin(q[2])
        else:
          sign=1 if sg['kind']=='L' else -1;h=q[2]+sign*u
          X=q[0]+sign*R*(np.sin(h)-np.sin(q[2]));Y=q[1]+sign*R*(-np.cos(h)+np.cos(q[2]))
        ax.plot(X,Y,color='#b83c35' if missing else '#247c69',linestyle='--' if missing else '-',linewidth=1.45,alpha=.9)
    ax.scatter(poses[:,0],poses[:,1],c=['#192732']+['#ffffff']*7,edgecolors='#192732',s=45,zorder=5)
    ax.quiver(poses[:,0],poses[:,1],np.cos(poses[:,2]),np.sin(poses[:,2]),angles='xy',scale_units='xy',scale=.38,width=.004,color='#192732',zorder=6)
    for i,(x,y,h) in enumerate(poses): ax.text(x+.6,y+.8,'D' if i==0 else str(i),fontsize=9,zorder=7)
    ax.set(aspect='equal',xlim=(-7,47),ylim=(-7,37),xlabel='x (m)',ylabel='y (m)')
    ax.set_title(kind+ ('\nNo feasible candidate on '+str(chosen['baseline_missing_edges']) if kind.startswith('Euclidean') else f"\nLength = {chosen['dubins_dp_cost']:.2f} m"),fontsize=11)
    ax.grid(alpha=.16)
  fig.suptitle(f'{eid}: one ordering failure recovered by reordering\nRed dashed: shortest unbounded candidate on a missing edge, not an admissible solution',fontsize=12,y=.96)
  fig.savefig(ROOT/'route_example.png',dpi=180);plt.close(fig)
  (ROOT/'evidence/illustration_selection.json').write_text(json.dumps({'instance_id':eid,'selection':'First ordering-only failure in frozen geometry order; selected after results solely for illustration.','not_additional_formal_sample':True},indent=2)+'\n')
  status={'wall_seconds':time.perf_counter()-t,'cpu_seconds':time.process_time()-cpu,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
  (ROOT/'evidence/summarize_status.json').write_text(json.dumps(status,indent=2)+'\n')
  print(json.dumps({'summary':summary,'resources':status},indent=2))
if __name__=='__main__':main()
