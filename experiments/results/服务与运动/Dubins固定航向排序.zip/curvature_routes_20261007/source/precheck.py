from pathlib import Path
import json, math, subprocess, time
from dubins import normalized,word_parameters,candidates,WORDS
ROOT=Path(__file__).resolve().parents[1];t=time.process_time()
cases=json.loads((ROOT/'reference/random_cases.json').read_text())
inp=''.join(' '.join(map(str,normalized(c['q0'],c['q1'],c['R'])))+'\n' for c in cases)
p=subprocess.run([str(ROOT/'reference/ompl_six_word_harness')],input=inp,text=True,capture_output=True)
assert p.returncode==0,p.stderr
max_diff=0; count=0
for c,line in zip(cases,p.stdout.splitlines(),strict=True):
 refs=list(map(float,line.split()));actual=word_parameters(*normalized(c['q0'],c['q1'],c['R']))
 for k,w in enumerate(WORDS):
  ref=refs[3*k:3*k+3]
  assert (w in actual)==math.isfinite(ref[0]),(c,w,ref,actual)
  if w in actual:
   dif=max(abs(x-y) for x,y in zip(ref,actual[w]));max_diff=max(max_diff,dif);count+=1
   assert dif<1e-8,(c,w,ref,actual[w])
 # Closure for reference validation set, not a formal sample.
 candidates(c['q0'],c['q1'],c['R'],[-1000,1000,-1000,1000])
fixed=[('straight',[0,0,0],[5,0,0],1,5),('identity',[0,0,0],[0,0,0],1,0),
 ('quarter_left',[0,0,0],[1,1,math.pi/2],1,math.pi/2),
 ('quarter_right',[0,0,0],[1,-1,-math.pi/2],1,math.pi/2),
 ('half_left',[0,0,0],[0,2,math.pi],1,math.pi),
 ('scaled_left',[2,3,0],[5,6,math.pi/2],3,3*math.pi/2),
 ('wrapped_heading',[0,0,2*math.pi],[5,0,0],1,5),
 ('opposed_same_position',[0,0,0],[0,0,math.pi],1,7*math.pi/3)]
fixed_out=[]
for name,q0,q1,R,target in fixed:
 ps=candidates(q0,q1,R,[-1000,1000,-1000,1000]); best=min(p['length'] for p in ps)
 assert abs(best-target)<1e-7,(name,best,target)
 fixed_out.append({'id':name,'q0':q0,'q1':q1,'R':R,'target_length':target,'actual_length':best,'passed':True})
res={'status':'passed','random_pairs':len(cases),'valid_words_compared':count,'max_normalized_parameter_error':max_diff,
 'analytic_fixed_cases':fixed_out,'cpu_seconds':time.process_time()-t}
(ROOT/'evidence/precheck.json').write_text(json.dumps(res,indent=2)+'\n')
print(json.dumps(res,indent=2))
