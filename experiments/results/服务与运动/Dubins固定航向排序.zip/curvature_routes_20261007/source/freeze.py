#!/usr/bin/env python3
"""Generate the pre-registered geometry and protocol, without solving any route."""
import json, random, math, datetime, hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SEED=202610070503

def dump(name,obj):
    (ROOT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False)+'\n')

def main():
    assert not (ROOT/'freeze.json').exists(), 'Do not overwrite a frozen experiment.'
    cfg={
      'experiment_id':'curvature_routes_20261007',
      'frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
      'seed':SEED, 'validation_seed':202610070504,
      'scope':'Geometric connection and task visitation-order component of VRP; single vehicle, no assignment or capacity comparison.',
      'geometry_count':24, 'groups':{'interior':12,'near_boundary':12},
      'tasks_per_geometry':7,'depot_pose':[20.0,15.0,0.0],
      'rectangle':[0.0,40.0,0.0,30.0], 'radius_values':[1.0,3.0,6.0],
      'pose_units':'positions and radius in metres; heading radians, CCW from +x',
      'interior_distribution':'All 7 task positions independent x U[8,32], y U[7,23]; headings U[-pi,pi].',
      'near_boundary_distribution':'Tasks 1..4 placed one per left/right/bottom/top edge, inward margin U[0.5,4.0], along-edge coordinate U[5,25] for vertical edges and U[5,35] for horizontal edges. Heading parallel to edge with random sign plus U[-pi/12,pi/12]. Tasks 5..7 follow interior distribution. No filtering by outcome.',
      'sampling_order':'Python random.Random(seed); 12 interior layouts then 12 boundary layouts; task-order generation; no resampling.',
      'motion_model':'Forward-only unit-speed point Dubins vehicle, curvature bounded by 1/R. Fixed task and depot headings. No obstacles except axis-aligned rectangle. Heading continuous, curvature discontinuous at switches; no footprint, steering-rate, acceleration, collision or real-vehicle dynamics.',
      'candidate_set':['LSL','RSR','RSL','LSR','RLR','LRL'],
      'edge_cost':'Minimum length among the six standard Dubins candidates wholly within rectangle; missing if none. All generated candidates and failures retained.',
      'boundary_check':'Analytic endpoints and all crossed cardinal-angle arc extrema, not sample-only; tolerance 1e-9 metres.',
      'formula_domain_tolerance':1e-12,
      'methods':{
        'euclidean_then_dubins':'Euclidean closed-tour minimum via Held-Karp DP. Enumerate all 7! orders to collect all Euclidean ties within 1e-8 m; among them choose lowest feasible Dubins tour cost, lexicographic secondary tie. This favors baseline and handles reverse symmetry. If all tied Euclidean orders fail, record failure.',
        'dubins_graph_dp':'Exact Held-Karp on constructed directed feasible-candidate graph; ties by lexicographic order.',
        'euclidean_canonical_diagnostic':'Lexicographically first Euclidean-optimal order evaluated with same Dubins edges. Diagnostic only; not primary baseline.'},
      'primary_metrics':['paired feasible counts out of all 72 geometry-radius instances','ordering-only failure count where graph DP feasible but baseline fails','common-feasible per-instance gap percent (baseline/DP - 1)*100, mean/median/min/max','paired counts and common-feasible gaps grouped by layout and radius','all failed instance IDs and missing tour edges'],
      'statistics':'Descriptive finite benchmark only; no p-values or population claims. Same geometry at different radii is not independent.',
      'validation':'200 independent random reference pose pairs and fixed analytic cases separate from formal 72. Compare nondegenerate six-word outputs to pinned official OMPL 1.7.0 C++ functions. Verify all formal candidates using independent Gauss-Legendre integration, trajectory-derived curvature, and independent extrema via derivative roots; verify every formal DP tour with all 7! orders.',
      'numeric_verification_tolerances':{'endpoint_m':2e-8,'heading_rad':2e-10,'segment_length_m':2e-9,'curvature_abs':2e-7,'bbox_m':2e-8,'tour_cost_m':1e-8},
      'cpu_budget_seconds':120,'no_llm_api':True,'paid_calls':0,
      'infeasibility_limit':'No candidate edge/tour does not prove physical infeasibility in continuous bounded space; exactness is restricted to this candidate graph.',
      'sources':['https://raw.githubusercontent.com/ompl/ompl/1.7.0/src/ompl/base/spaces/src/DubinsStateSpace.cpp','https://ompl.kavrakilab.org/classompl_1_1base_1_1DubinsStateSpace.html','https://lavalle.pl/planning/node821.html']}
    rng=random.Random(SEED); layouts=[]
    for group in ['interior','near_boundary']:
      for k in range(12):
        poses=[cfg['depot_pose'][:]]
        for t in range(7):
          if group=='near_boundary' and t<4:
            margin=rng.uniform(.5,4.)
            along=rng.uniform(5.,25. if t<2 else 35.)
            if t==0: x,y=margin,along
            elif t==1: x,y=40-margin,along
            elif t==2: x,y=along,margin
            else: x,y=along,30-margin
            h=(math.pi/2 if t<2 else 0)+(rng.choice([0,1])*math.pi)+rng.uniform(-math.pi/12,math.pi/12)
            h=(h+math.pi)%(2*math.pi)-math.pi
          else: x,y,h=rng.uniform(8.,32.),rng.uniform(7.,23.),rng.uniform(-math.pi,math.pi)
          poses.append([x,y,h])
        layouts.append({'geometry_id':f'{group}_{k:02d}','group':group,'poses':poses})
    dump('freeze.json',cfg); dump('instances.json',layouts)
    with (ROOT/'freeze.sha256').open('w') as f:
      for name in ['freeze.json','instances.json','source/freeze.py']:
        f.write(hashlib.sha256((ROOT/name).read_bytes()).hexdigest()+'  '+name+'\n')
    print('Frozen',len(layouts),'geometries and',len(layouts)*len(cfg['radius_values']),'formal instances.')
if __name__=='__main__': main()
