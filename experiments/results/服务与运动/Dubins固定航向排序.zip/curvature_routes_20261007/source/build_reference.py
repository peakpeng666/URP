#!/usr/bin/env python3
"""Extract six untouched official OMPL word functions into a small C++ harness.
No full OMPL installation. The reference is formula consistency, not an
independent derivation. Numerical geometry integration is separate.
"""
from pathlib import Path
import subprocess, json, math, random, time, hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'reference/ompl_DubinsStateSpace_1.7.0.cpp').read_text()
license=s[:s.index('/* Author:')]
mod=s[s.index('    inline double mod2pi'):s.index('    inline double t_lsr')]
fns=s[s.index('    DubinsStateSpace::DubinsPath dubinsLSL'):s.index('    bool isLongPath')]
stub='''
#include <cmath>
#include <cassert>
#include <algorithm>
#include <limits>
#include <iostream>
#include <iomanip>
constexpr double twopi=6.283185307179586476925286766559;
const double DUBINS_EPS=1e-6, DUBINS_ZERO=-1e-7;
struct DubinsStateSpace {
 static int dubinsPathType[6][3];
 struct DubinsPath {
  double length_[3];
  DubinsPath(){length_[0]=length_[1]=length_[2]=std::numeric_limits<double>::infinity();}
  DubinsPath(const int(*)[3],double t,double p,double q){length_[0]=t;length_[1]=p;length_[2]=q;}
 };
};
int DubinsStateSpace::dubinsPathType[6][3]={};
'''
main='''
int main(){
 std::cout << std::setprecision(17);
 double d,a,b;
 while(std::cin>>d>>a>>b){
  auto ps={dubinsLSL(d,a,b),dubinsRSR(d,a,b),dubinsRSL(d,a,b),dubinsLSR(d,a,b),dubinsRLR(d,a,b),dubinsLRL(d,a,b)};
  for(auto p:ps)for(double v:p.length_)std::cout<<v<<' ';
  std::cout<<'\\n';
 }
}
'''
cpp=ROOT/'reference/ompl_six_word_harness.cpp';cpp.write_text(license+stub+mod+fns+main)
t=time.perf_counter(); p=subprocess.run(['g++','-std=c++17','-O2',str(cpp),'-o',str(ROOT/'reference/ompl_six_word_harness')],capture_output=True,text=True)
(ROOT/'evidence/reference_build.log').write_text(p.stdout+p.stderr)
assert p.returncode==0,p.stderr
cfg=json.loads((ROOT/'freeze.json').read_text());rng=random.Random(cfg['validation_seed'])
cases=[]
for j in range(200):
 q0=[rng.uniform(-20,20),rng.uniform(-20,20),rng.uniform(-math.pi,math.pi)]
 q1=[rng.uniform(-20,20),rng.uniform(-20,20),rng.uniform(-math.pi,math.pi)]
 cases.append({'id':j,'q0':q0,'q1':q1,'R':rng.uniform(.4,7)})
(ROOT/'reference/random_cases.json').write_text(json.dumps(cases,indent=2)+'\n')
(ROOT/'evidence/reference_build.json').write_text(json.dumps({'status':'passed','wall_seconds':time.perf_counter()-t,
  'official_url':'https://raw.githubusercontent.com/ompl/ompl/1.7.0/src/ompl/base/spaces/src/DubinsStateSpace.cpp',
  'official_sha256':hashlib.sha256(s.encode()).hexdigest(),'extracted_function_text_unchanged':True,
  'role':'Pinned implementation consistency, not independent geometry validation.'},indent=2)+'\n')
print('Compiled official six-word reference; generated 200 validation pairs.')
