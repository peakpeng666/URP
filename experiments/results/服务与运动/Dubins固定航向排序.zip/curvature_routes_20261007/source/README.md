# Scripts

- freeze.py: one-shot pre-registration and generation; refuses to overwrite freeze.
- dubins.py: six formula candidates, analytic circular extrema, Held–Karp DP.
- build_reference.py: extracts unmodified six-word functions from retained official OMPL source, compiles minimal C++ harness, generates separate reference poses.
- precheck.py: formula agreement on 200 independent poses and eight known-length cases.
- experiment.py: one formal solve over all frozen layouts and radii; retains every edge/candidate and all tour failures.
- verify.py: independent raw-output verification without importing dubins.py; numerical quadrature, derivative-root extrema, Menger curvature, all 7! orders, plus external C++ formula consistency.
- geometry_regressions.py: six auxiliary analytic box tests, not formal experimental samples.
- summarize.py: paired descriptive summaries and two presentation figures; no extra experimental runs.

No downloaded executable is run. The OMPL reference binary is locally compiled from the retained official source.
