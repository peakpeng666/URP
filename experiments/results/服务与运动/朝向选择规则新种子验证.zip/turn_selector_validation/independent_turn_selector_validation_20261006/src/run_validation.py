#!/usr/bin/env python3
"""Frozen real selector validation. All numerical work and checks in one process."""
import resource
resource.setrlimit(resource.RLIMIT_CPU,(110,110))
resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3))
import signal
signal.alarm(780)
import time, json, hashlib, datetime, sys, os, platform, itertools, math, statistics, csv, traceback, gc
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from search_core import search
from reference import reverse_dijkstra, encode_state, verify_path
import selector as selection
T0=time.perf_counter();START=datetime.datetime.now(datetime.timezone.utc).isoformat()
ALGORITHMS=('astar_manhattan','astar_turn','selector');PERMS=list(itertools.permutations(ALGORITHMS))
COUNTS=dict(oracles=0,warmup_searches=0,calibration_searches=0,formal_searches=0,path_checks=0,batch_checks=0,selector_branch_result_checks=0,dispatch_probes=0)

def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def canonical(obj):return json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
def objsha(obj):return hashlib.sha256(canonical(obj).encode()).hexdigest()
def dump(name,obj):(ROOT/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
def load(name):return json.loads((ROOT/name).read_text())
def tree(root):return {str(p.relative_to(root)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(root.rglob('*')) if p.is_file()}
def check_freeze(freeze):
 for name,rec in freeze['files'].items():assert sha(ROOT/name)==rec['sha256'],name

def expected_branch(weight):
 # Separate rule implementation for validation, not called in the timing loop.
 assert math.isfinite(weight) and weight>=0
 return {True:'astar_manhattan',False:'astar_turn'}[weight==0]

def safety():
 if time.process_time()>=100 or time.perf_counter()-T0>=750:raise RuntimeError('PREDECLARED_SAFETY_STOP')

def dispatch_probe():
 original=selection.search;calls=[];sentinel=object()
 def fake(rows,start,goal,weight,algorithm):
  calls.append(dict(weight=weight,algorithm=algorithm));return sentinel
 try:
  selection.search=fake
  for w in [0,2,8,1]:
   assert selection.select_search(None,None,None,w) is sentinel
   assert calls[-1]['algorithm']==expected_branch(w);COUNTS['dispatch_probes']+=1
  for w,label in [(-1,'negative'),(float('inf'),'positive_infinity'),(float('nan'),'nan')]:
   before=len(calls)
   try:selection.select_search(None,None,None,w)
   except ValueError:pass
   else:raise AssertionError('invalid weight accepted')
   assert len(calls)==before;COUNTS['dispatch_probes']+=1
 finally:selection.search=original
 dump('checks/dispatch_probe.json',dict(passed=True,actual_kernel_arguments=calls,invalid_weights_rejected=['negative','positive_infinity','nan'],search_calls=0,scope='Stub intercept tests real selector dispatch; independent from path-based branch checks'))

def measure(m,c,a,n):
 results=[None]*n
 if a=='selector':call=selection.select_search;args=(m['rows'],m['start'],m['goal'],c['weight'])
 else:call=search;args=(m['rows'],m['start'],m['goal'],c['weight'],a)
 w0=time.perf_counter_ns();p0=time.process_time_ns();t0=time.thread_time_ns()
 for j in range(n):results[j]=call(*args)
 t1=time.thread_time_ns();p1=time.process_time_ns();w1=time.perf_counter_ns()
 return results,dict(wall_ns=w1-w0,cpu_ns=p1-p0,thread_cpu_ns=t1-t0)

def check_results(m,c,a,results,exact,baseline,phase):
 for result in results:
  verify_path(m['rows'],m['start'],m['goal'],c['weight'],result,exact)
  assert result==baseline,(c['case_id'],a,'nondeterminism')
  assert result['reexpansions']==0
  COUNTS['path_checks']+=1
  if a=='selector':COUNTS['selector_branch_result_checks']+=1
 COUNTS[phase+'_searches']+=len(results);COUNTS['batch_checks']+=1

def line(f,o):f.write(canonical(o)+'\n');f.flush()
def csvwrite(name,rows):
 with (ROOT/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def summarize(formal,base,cases,maps):
 clocks=['wall_ns','cpu_ns','thread_cpu_ns'];pairs=[]
 for c in cases:
  cid=c['case_id'];m=maps[c['map_id']];branch=expected_branch(c['weight'])
  p=dict(**c,n=m['n'],seed=m['seed'],obstacle_probability=m['obstacle_probability'],reachable=base[(cid,'selector')]['reachable'],selected_kernel=branch)
  for a in ALGORITHMS:
   rr=[r for r in formal if r['case_id']==cid and r['algorithm']==a];assert len(rr)==6
   for k in clocks:
    vals=[r[k]/r['repetitions'] for r in rr]
    p[a+'_'+k+'_median']=statistics.median(vals);p[a+'_'+k+'_min']=min(vals);p[a+'_'+k+'_max']=max(vals)
   p[a+'_expansions']=base[(cid,a)]['expansions'];p[a+'_heap_pushes']=base[(cid,a)]['heap_pushes']
  for k in clocks:
   p['selected_branch_'+k]=p[branch+'_'+k+'_median']
   p['selector_excess_'+k]=p['selector_'+k+'_median']-p[branch+'_'+k+'_median']
  p['selector_wall_ratio_to_manhattan']=p['selector_wall_ns_median']/p['astar_manhattan_wall_ns_median']
  p['selector_wall_ratio_to_turn']=p['selector_wall_ns_median']/p['astar_turn_wall_ns_median']
  p['selector_wall_ratio_to_selected']=p['selector_wall_ns_median']/p[branch+'_wall_ns_median']
  p['turn_fewer_expansions_but_wall_slower']=p['astar_turn_expansions']<p['astar_manhattan_expansions'] and p['astar_turn_wall_ns_median']>p['astar_manhattan_wall_ns_median']
  p['selector_fewer_expansions_but_wall_slower']=p['selector_expansions']<p['astar_manhattan_expansions'] and p['selector_wall_ns_median']>p['astar_manhattan_wall_ns_median']
  pairs.append(p)
 groups=[]
 criteria=[('all','all',lambda p:True)]
 for key,values in [('weight',[0,2,8]),('n',[16,32,48]),('obstacle_probability',[0.1,0.25]),('seed',[932117,932129,932141,932153]),('reachable',[True,False])]:
  for value in values:criteria.append((key,value,lambda p,key=key,value=value:p[key]==value))
 for w in [0,2,8]:
  for reachable in [True,False]:criteria.append(('weight_reachable',f'{w}|{reachable}',lambda p,w=w,reachable=reachable:p['weight']==w and p['reachable']==reachable))
 for key,value,pred in criteria:
  pp=[p for p in pairs if pred(p)];totals={}
  for a in ALGORITHMS:
   totals[a]={k:sum(p[a+'_'+k+'_median'] for p in pp) for k in clocks}
   totals[a].update(expansions=sum(p[a+'_expansions'] for p in pp),heap_pushes=sum(p[a+'_heap_pushes'] for p in pp))
  selected={k:sum(p['selected_branch_'+k] for p in pp) for k in clocks}
  ratios={a:{k:1-totals['selector'][k]/totals[a][k] if totals[a][k] else None for k in clocks+['expansions']} for a in ['astar_manhattan','astar_turn']}
  wins={a:[sum(p['selector_wall_ns_median']<p[a+'_wall_ns_median'] for p in pp),sum(p['selector_wall_ns_median']==p[a+'_wall_ns_median'] for p in pp),sum(p['selector_wall_ns_median']>p[a+'_wall_ns_median'] for p in pp)] for a in ['astar_manhattan','astar_turn']}
  groups.append(dict(group_by=key,value=value,cases=len(pp),maps=len({p['map_id'] for p in pp}),totals=totals,selector_reduction_vs=ratios,selector_wall_win_tie_loss_vs=wins,offline_selected_branch_totals=selected,selector_excess_vs_selected={k:totals['selector'][k]-selected[k] for k in clocks},selector_excess_ratio_vs_selected={k:totals['selector'][k]/selected[k]-1 if selected[k] else None for k in clocks}))
 roundgroups=[]
 for r in range(6):
  rr=[x for x in formal if x['round']==r]
  for w in ['all',0,2,8]:
   vv=[x for x in rr if w=='all' or x['weight']==w]
   totals={a:sum(x['wall_ns']/x['repetitions'] for x in vv if x['algorithm']==a) for a in ALGORITHMS}
   selected=sum(x['wall_ns']/x['repetitions'] for x in vv if x['algorithm']==expected_branch(x['weight']))
   roundgroups.append(dict(round=r,weight=w,wall_ns=totals,offline_selected_wall_ns=selected,selector_ratio_to_manhattan=totals['selector']/totals['astar_manhattan'],selector_ratio_to_turn=totals['selector']/totals['astar_turn'],selector_ratio_to_selected=totals['selector']/selected))
 result=dict(created_utc=utc(),maps=24,cases=72,formal_batches=len(formal),formal_rounds=6,formal_searches=sum(r['repetitions'] for r in formal),counts=COUNTS,all_paths_verified=True,reachable_maps=len({p['map_id'] for p in pairs if p['reachable']}),unreachable_maps=len({p['map_id'] for p in pairs if not p['reachable']}),unreachable_cases=[p['case_id'] for p in pairs if not p['reachable']],zero_time_batches={k:sum(r[k]==0 for r in formal) for k in clocks},batch_ranges_ns={k:[min(r[k] for r in formal),max(r[k] for r in formal)] for k in clocks},groups=groups,turn_fewer_expansions_but_wall_slower_cases=[p['case_id'] for p in pairs if p['turn_fewer_expansions_but_wall_slower']],selector_fewer_expansions_but_wall_slower_cases=[p['case_id'] for p in pairs if p['selector_fewer_expansions_but_wall_slower']],FE='not applicable: deterministic graph search, not black-box objective evaluations',interpretation='Post-hoc rule from old results; frozen new-seed synthetic validation in one shared-cloud session; not new-distribution generalization, real-vehicle validation, full-paper replication, or statistical significance')
 dump('raw/summary.json',result);dump('raw/paired_cases.json',pairs);csvwrite('raw/paired_cases.csv',pairs);csvwrite('raw/formal_batches.csv',formal);dump('raw/round_group_sensitivity.json',roundgroups)
 clockdiag={}
 for k in ['cpu_ns','thread_cpu_ns']:
  vals=[r[k]/r['wall_ns'] for r in formal]
  clockdiag[k+'_to_wall']=dict(min=min(vals),median=statistics.median(vals),max=max(vals))
 dump('raw/clock_comparison_diagnostic.json',clockdiag)
 return result

def run():
 freeze=load('PRE_RUN_FREEZE.json');check_freeze(freeze);original=load('checks/original_tree_snapshot.json')
 for old,snapshot in original.items():assert tree(ROOT.parent/old)==snapshot
 config=load('inputs/config.json');maps_list=load('inputs/maps.json');maps={m['map_id']:m for m in maps_list};cases=load('inputs/cases.json')
 assert len(maps)==24 and len(cases)==72
 dump('checks/environment.json',dict(python=sys.version,platform=platform.platform(),pid=os.getpid(),start_utc=START,clock_info={k:vars(time.get_clock_info(k)) for k in ['perf_counter','process_time','thread_time']},rlimit_cpu=resource.getrlimit(resource.RLIMIT_CPU),rlimit_as=resource.getrlimit(resource.RLIMIT_AS),gc_enabled=gc.isenabled(),gc_threshold=gc.get_threshold(),cpu_affinity=sorted(os.sched_getaffinity(0)),pythonhashseed=os.environ.get('PYTHONHASHSEED'),numerical_processes=1,model_api_calls=0,network_calls=0))
 dispatch_probe();base={};exact={};cal=[];reps={};est={};canonical_rows=[]
 with (ROOT/'raw/oracles.jsonl').open('w') as of,(ROOT/'raw/warmup.jsonl').open('w') as wf,(ROOT/'raw/calibration.jsonl').open('w') as cf:
  for i,c in enumerate(cases):
   safety();cid=c['case_id'];m=maps[c['map_id']];branch=expected_branch(c['weight']);assert selection.chosen_kernel(c['weight'])==branch
   p0=time.process_time_ns();w0=time.perf_counter_ns();distances,edges,info=reverse_dijkstra(m['rows'],m['goal'],c['weight']);value=distances.get(encode_state(m['start']));COUNTS['oracles']+=1;exact[cid]=value
   line(of,dict(**c,exact_cost=value,**info,cpu_ns=time.process_time_ns()-p0,wall_ns=time.perf_counter_ns()-w0));del distances,edges
   warmresults={}
   for pos,a in enumerate(PERMS[i%6]):
    results,times=measure(m,c,a,1);base[(cid,a)]=results[0];warmresults[a]=(results,times,pos)
   assert base[(cid,'selector')]==base[(cid,branch)]
   for a,(results,times,pos) in warmresults.items():
    baseline=base[(cid,branch)] if a=='selector' else base[(cid,a)]
    check_results(m,c,a,results,value,baseline,'warmup')
    line(wf,dict(**c,algorithm=a,phase='warmup',repetitions=1,order=pos,selected_kernel=branch if a=='selector' else a,**times,path_checks=1,result_sha256=objsha(base[(cid,a)])))
    canonical_rows.append(dict(**c,algorithm=a,selected_kernel=branch if a=='selector' else a,result_sha256=objsha(base[(cid,a)]),result=base[(cid,a)]))
   del warmresults
   for cr in range(2):
    for pos,a in enumerate(PERMS[(i+cr)%6]):
     safety();results,times=measure(m,c,a,8);baseline=base[(cid,branch)] if a=='selector' else base[(cid,a)];check_results(m,c,a,results,value,baseline,'calibration')
     row=dict(**c,algorithm=a,phase='calibration',calibration_round=cr,repetitions=8,order=pos,**times,path_checks=8,result_sha256=objsha(base[(cid,a)]));line(cf,row);cal.append(row);del results
   for a in ALGORITHMS:
    tt=min(x['wall_ns']/8 for x in cal if x['case_id']==cid and x['algorithm']==a);assert tt>0
    reps[(cid,a)]=min(20000,max(4,math.ceil(25_000_000/tt)));est[(cid,a)]=tt
   shared=max(reps[(cid,branch)],reps[(cid,'selector')]);reps[(cid,branch)]=shared;reps[(cid,'selector')]=shared
   if (i+1)%12==0:print('CALIBRATION',i+1,'cpu',time.process_time(),flush=True)
 dump('raw/canonical_results.json',canonical_rows)
 predicted=sum(reps[k]*est[k] for k in reps)/1e9;forecast=time.process_time()+1.6*6*predicted+8
 plan=[dict(case_id=cid,algorithm=a,repetitions=reps[(cid,a)],calibration_ns_per_search=est[(cid,a)],selected_kernel=expected_branch(next(c['weight'] for c in cases if c['case_id']==cid)) if a=='selector' else a) for cid,a in reps]
 dump('CALIBRATION_FREEZE.json',dict(frozen_utc=utc(),pre_run_freeze_sha256=sha(ROOT/'PRE_RUN_FREEZE.json'),calibration_sha256=sha(ROOT/'raw/calibration.jsonl'),canonical_results_sha256=sha(ROOT/'raw/canonical_results.json'),selected_rounds=6,estimated_round_seconds=predicted,cpu_seconds_at_freeze=time.process_time(),forecast_cpu_with_margin_seconds=forecast,plan=plan))
 calhash=sha(ROOT/'CALIBRATION_FREEZE.json');check_freeze(freeze)
 print('CALIBRATION_FROZEN','predicted_round_seconds',predicted,'forecast_cpu',forecast,flush=True)
 assert forecast<=100,'Frozen forecast prohibits six-round formal launch'
 formal=[]
 with (ROOT/'raw/formal_batches.jsonl').open('w') as ff:
  for r in range(6):
   indexes=list(range(72));shift=(12*r)%72;indexes=indexes[shift:]+indexes[:shift]
   if r%2:indexes.reverse()
   for position,i in enumerate(indexes):
    c=cases[i];cid=c['case_id'];m=maps[c['map_id']];branch=expected_branch(c['weight'])
    for apos,a in enumerate(PERMS[(i+r)%6]):
     safety();n=reps[(cid,a)];results,times=measure(m,c,a,n);baseline=base[(cid,branch)] if a=='selector' else base[(cid,a)];check_results(m,c,a,results,exact[cid],baseline,'formal')
     row=dict(batch_id=len(formal),round=r,case_index=i,case_position=position,algorithm_position=apos,**c,n=m['n'],seed=m['seed'],obstacle_probability=m['obstacle_probability'],reachable=baseline['reachable'],algorithm=a,selected_kernel=branch if a=='selector' else a,repetitions=n,**times,exact_cost=exact[cid],path_checks=n,all_results_identical=True,result_sha256=objsha(baseline),expansions_per_search=baseline['expansions'],heap_pushes_per_search=baseline['heap_pushes'])
     line(ff,row);formal.append(row);del results
   print('FORMAL_ROUND_COMPLETE',r+1,'batches',len(formal),'searches',COUNTS['formal_searches'],'cpu',time.process_time(),flush=True)
 assert len(formal)==1296
 assert COUNTS['path_checks']==sum(COUNTS[k] for k in ['warmup_searches','calibration_searches','formal_searches'])
 check_freeze(freeze);assert sha(ROOT/'CALIBRATION_FREEZE.json')==calhash
 for old,snapshot in original.items():assert tree(ROOT.parent/old)==snapshot
 result=summarize(formal,base,cases,maps)
 dump('checks/post_run_checks.json',dict(completed_utc=utc(),passed=True,counts=COUNTS,all_costs_match_independent_oracle=True,all_paths_verified_individually=True,all_selector_results_match_independent_branch_rule=True,dispatch_probes_passed=True,all_repeated_results_identical=True,old_directories_unchanged=list(original),pre_run_freeze_unchanged=True,calibration_freeze_unchanged=True,planned_rounds=6,completed_rounds=6,deviations=[]))
 u=resource.getrusage(resource.RUSAGE_SELF)
 dump('checks/resource_usage.json',dict(status='completed',measured_at_utc=utc(),user_cpu_seconds=u.ru_utime,system_cpu_seconds=u.ru_stime,process_cpu_seconds=u.ru_utime+u.ru_stime,process_time_seconds=time.process_time(),wall_seconds=time.perf_counter()-T0,max_rss_kib=u.ru_maxrss,hard_cpu_limit_seconds=110,numerical_cpu_budget_seconds=120,wall_alarm_seconds=780,counts=COUNTS,scope='Entire numerical process including oracle, all path checks, calibration, formal searches, summary and freeze checks; before final file writes'))
 print('COMPLETE',canonical(result['groups'][:4]),flush=True)

if __name__=='__main__':
 try:run()
 except BaseException as exc:
  dump('checks/FAILURE.json',dict(at_utc=utc(),error_type=type(exc).__name__,error=str(exc),traceback=traceback.format_exc(),counts=COUNTS,process_cpu_seconds=time.process_time(),wall_seconds=time.perf_counter()-T0))
  traceback.print_exc();raise
