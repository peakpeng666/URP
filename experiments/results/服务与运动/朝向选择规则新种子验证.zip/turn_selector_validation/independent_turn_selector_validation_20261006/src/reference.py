"""Independent explicit reverse graph, oracle and path verification.

Does not import the tested search module. Dot products, rather than modular
heading arithmetic, determine the turn cost. Reverse multi-source Dijkstra
uses a distinct state encoding ((column,row), direction vector).
"""
import heapq

VECTORS = ((1, 0), (0, 1), (-1, 0), (0, -1))


def angle_units(before, after):
    dot = before[0] * after[0] + before[1] * after[1]
    return {1: 0, 0: 1, -1: 2}[dot]


def build_reverse_graph(rows, weight):
    free = {(column, row) for row, line in enumerate(rows)
            for column, cell in enumerate(line) if cell == "."}
    reverse = {(cell, vector): [] for cell in sorted(free) for vector in VECTORS}
    edges = []
    for cell in sorted(free):
        for before in VECTORS:
            source = (cell, before)
            for after in VECTORS:
                neighbor = (cell[0] + after[0], cell[1] + after[1])
                if neighbor in free:
                    target = (neighbor, after)
                    cost = 1 + weight * angle_units(before, after)
                    reverse[target].append((source, cost))
                    edges.append((source, target, cost))
    return reverse, edges


def reverse_dijkstra(rows, goal, weight):
    reverse, edges = build_reverse_graph(rows, weight)
    distances = {}
    queue = []
    for vector in VECTORS:
        state = (tuple(goal), vector)
        distances[state] = 0
        heapq.heappush(queue, (0, state))
    popped = 0
    while queue:
        cost, state = heapq.heappop(queue)
        if distances[state] != cost:
            continue
        popped += 1
        for predecessor, edge in reverse[state]:
            candidate = cost + edge
            if candidate < distances.get(predecessor, float("inf")):
                distances[predecessor] = candidate
                heapq.heappush(queue, (candidate, predecessor))
    return distances, edges, dict(graph_states=len(reverse), graph_edges=len(edges),
                                 oracle_settled_states=popped)


def encode_state(forward_state):
    x, y, heading = forward_state
    return ((x, y), VECTORS[heading])


def verify_path(rows, start, goal, weight, result, exact_cost):
    if exact_cost is None:
        assert result["reachable"] is False
        assert result["cost"] is None and result["path"] == []
        return dict(valid=True, steps=None, turn_units=None, recomputed_cost=None)
    assert result["reachable"] is True
    path = result["path"]
    assert path and tuple(path[0]) == tuple(start)
    assert tuple(path[-1][:2]) == tuple(goal)
    total_turns = 0
    for state in path:
        x, y, heading = state
        assert 0 <= y < len(rows) and 0 <= x < len(rows[y])
        assert rows[y][x] == "." and heading in (0, 1, 2, 3)
    for previous, current in zip(path, path[1:]):
        move = (current[0] - previous[0], current[1] - previous[1])
        assert move in VECTORS
        assert VECTORS[current[2]] == move
        total_turns += angle_units(VECTORS[previous[2]], move)
    steps = len(path) - 1
    recomputed = steps + weight * total_turns
    assert recomputed == result["cost"] == exact_cost
    return dict(valid=True, steps=steps, turn_units=total_turns, recomputed_cost=recomputed)
