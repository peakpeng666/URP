#!/usr/bin/env python3
import datetime, hashlib, json, random, resource, time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
T0=time.perf_counter()
def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,o): (ROOT/p).write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n')
def snap(root): return {str(p.relative_to(root)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(root.rglob('*')) if p.is_file()}
def files(names): return {n:dict(bytes=(ROOT/n).stat().st_size,sha256=sha(ROOT/n)) for n in names}
assert not (ROOT/'PLAN_FREEZE.json').exists()
config=json.loads((ROOT/'inputs/config.json').read_text())
dump('PLAN_FREEZE.json',dict(frozen_utc=utc(),stage='before_new_map_generation_and_search',files=files(['PROTOCOL.md','inputs/config.json','src/prepare.py'])))
oldnames=['independent_turn_search_timing_20261006','independent_turn_aware_search_20261006']
dump('checks/original_tree_snapshot.json',{n:snap(ROOT.parent/n) for n in oldnames})
oldconf=json.loads((ROOT.parent/oldnames[0]/'inputs/config.json').read_text())
assert not set(config['seeds']) & set(oldconf['seeds'])
maps=[];cases=[]
for n in config['sizes']:
 for seed in config['seeds']:
  for p in config['obstacle_probabilities']:
   key=f"turn-aware-grid-v1|n={n}|seed={seed}|p={p:.2f}"
   seednum=int.from_bytes(hashlib.sha256(key.encode()).digest(),'big');rng=random.Random(seednum)
   rows=[''.join('#' if rng.random()<p else '.' for _ in range(n)) for _ in range(n)]
   free=[(x,y) for y in range(n) for x in range(n) if rows[y][x]=='.'];assert len(free)>=2
   start,goal=rng.sample(free,2);heading=rng.randrange(4);mid=f'n{n}_s{seed}_p{int(p*100):02d}'
   maps.append(dict(map_id=mid,n=n,seed=seed,obstacle_probability=p,rng_key=key,rng_seed_hex=hex(seednum),rows=rows,start=[*start,heading],goal=list(goal),obstacle_count=n*n-len(free)))
   for w in config['weights']: cases.append(dict(case_id=f'{mid}_w{w}',map_id=mid,weight=w))
assert len(maps)==24 and len(cases)==72
dump('inputs/maps.json',maps);dump('inputs/cases.json',cases)
oldmaps=json.loads((ROOT.parent/oldnames[0]/'inputs/maps.json').read_text())
assert not {json.dumps(m['rows']) for m in maps}&{json.dumps(m['rows']) for m in oldmaps}
for name in ['search_core.py','reference.py']:
 assert sha(ROOT/'src'/name)==sha(ROOT.parent/oldnames[0]/'src'/name)
names=['PROTOCOL.md','PLAN_FREEZE.json','run_limited.sh','checks/original_tree_snapshot.json']+[str(p.relative_to(ROOT)) for folder in ['src','inputs'] for p in sorted((ROOT/folder).rglob('*')) if p.is_file()]
dump('PRE_RUN_FREEZE.json',dict(frozen_utc=utc(),stage='before_any_new_solver_execution',maps=24,cases=72,new_seeds=config['seeds'],files=files(names)))
u=resource.getrusage(resource.RUSAGE_SELF)
dump('checks/preparation_resource.json',dict(measured_at_utc=utc(),wall_seconds=time.perf_counter()-T0,user_cpu_seconds=u.ru_utime,system_cpu_seconds=u.ru_stime,max_rss_kib=u.ru_maxrss,scope='This prepare.py process only; earlier source reading/writing was not metered individually',maps_generated=24,search_calls=0,oracle_calls=0,freeze_sha256=sha(ROOT/'PRE_RUN_FREEZE.json')))
print('FROZEN',sha(ROOT/'PRE_RUN_FREEZE.json'),'maps',len(maps),'cases',len(cases))
