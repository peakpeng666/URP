"""Common forward search engine; no external dependencies."""
from heapq import heappush, heappop

DIRECTIONS = ((1, 0), (0, 1), (-1, 0), (0, -1))
ALGORITHMS = ("dijkstra", "astar_manhattan", "astar_turn")


def turns(a, b):
    delta = abs(a - b)
    return min(delta, 4 - delta)


def heuristic(state, goal, weight, algorithm):
    if algorithm == "dijkstra":
        return 0
    x, y, heading = state
    dx, dy = goal[0] - x, goal[1] - y
    distance = abs(dx) + abs(dy)
    if algorithm == "astar_manhattan" or distance == 0:
        return distance
    required = []
    if dx:
        required.append(0 if dx > 0 else 2)
    if dy:
        required.append(1 if dy > 0 else 3)
    if len(required) == 1:
        min_turns = turns(heading, required[0])
    else:
        min_turns = 1 if heading in required else 2
    return distance + weight * min_turns


def search(rows, start, goal, weight, algorithm):
    n = len(rows)
    start = tuple(start)
    goal = tuple(goal)
    best = {start: 0}
    parent = {}
    frontier = []
    sequence = 0
    heappush(frontier, (heuristic(start, goal, weight, algorithm), 0, *start, sequence))
    expanded = set()
    counters = dict(expansions=0, accepted_pops=0, stale_pops=0,
                    heap_pushes=1, max_heap=1, reexpansions=0,
                    successor_candidates=0, traversable_successors=0)
    terminal = None
    while frontier:
        _, g, x, y, heading, _ = heappop(frontier)
        state = (x, y, heading)
        if best.get(state) != g:
            counters["stale_pops"] += 1
            continue
        counters["accepted_pops"] += 1
        if (x, y) == goal:
            terminal = state
            break
        counters["expansions"] += 1
        counters["reexpansions"] += state in expanded
        expanded.add(state)
        for new_heading, (vx, vy) in enumerate(DIRECTIONS):
            counters["successor_candidates"] += 1
            nx, ny = x + vx, y + vy
            if not (0 <= nx < n and 0 <= ny < n and rows[ny][nx] == "."):
                continue
            counters["traversable_successors"] += 1
            next_state = (nx, ny, new_heading)
            proposal = g + 1 + weight * turns(heading, new_heading)
            if proposal < best.get(next_state, float("inf")):
                best[next_state] = proposal
                parent[next_state] = state
                sequence += 1
                heappush(frontier, (proposal + heuristic(next_state, goal, weight, algorithm),
                                    proposal, nx, ny, new_heading, sequence))
                counters["heap_pushes"] += 1
                counters["max_heap"] = max(counters["max_heap"], len(frontier))
    if terminal is None:
        return dict(reachable=False, cost=None, path=[], **counters)
    path = [terminal]
    while path[-1] != start:
        path.append(parent[path[-1]])
    path.reverse()
    return dict(reachable=True, cost=best[terminal], path=path, **counters)
