"""Post-hoc rule proposed from prior data; frozen before new-seed evaluation."""
from math import isfinite
from search_core import search


def chosen_kernel(weight):
    if not isfinite(weight) or weight < 0:
        raise ValueError("The frozen selector requires finite nonnegative weights")
    if weight == 0:
        return "astar_manhattan"
    if weight > 0:
        return "astar_turn"
    raise ValueError("The frozen selector only supports nonnegative weights")


def select_search(rows, start, goal, weight):
    return search(rows, start, goal, weight, chosen_kernel(weight))
