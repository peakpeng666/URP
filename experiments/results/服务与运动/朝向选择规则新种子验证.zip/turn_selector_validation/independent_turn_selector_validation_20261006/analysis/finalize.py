#!/usr/bin/env python3
"""Read-only scientific evidence verification, then package metadata; no solver calls."""
import ast,datetime,hashlib,json,resource,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];T0=time.perf_counter()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(name):return json.loads((ROOT/name).read_text())
def dump(name,obj):(ROOT/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
def tree(root):return {str(p.relative_to(root)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(root.rglob('*')) if p.is_file()}
for freeze in ['PLAN_FREEZE.json','PRE_RUN_FREEZE.json']:
 for name,rec in read(freeze)['files'].items():assert sha(ROOT/name)==rec['sha256'],name
for old,snapshot in read('checks/original_tree_snapshot.json').items():assert tree(ROOT.parent/old)==snapshot
for p in (ROOT/'src').glob('*.py'):ast.parse(p.read_text())
assert read('LAUNCH_EXIT.json')['exit_code']==0
assert not (ROOT/'checks/FAILURE.json').exists()
summary=read('raw/summary.json');counts=summary['counts']
assert counts['path_checks']==328932 and counts['formal_searches']==325260 and counts['oracles']==72
formal=[json.loads(x) for x in (ROOT/'raw/formal_batches.jsonl').read_text().splitlines()]
assert len(formal)==1296 and sum(x['repetitions'] for x in formal)==325260
assert read('checks/post_run_checks.json')['passed']
expected=['REPORT_ZH.md','README_ZH.md','PROTOCOL.md','PRE_RUN_FREEZE.json','PLAN_FREEZE.json','CALIBRATION_FREEZE.json','inputs/maps.json','inputs/cases.json','raw/summary.json','raw/paired_cases.csv','raw/formal_batches.csv','raw/canonical_results.json','raw/oracles.jsonl','src/selector.py','src/search_core.py','src/reference.py','src/run_validation.py']
for name in expected:assert (ROOT/name).is_file() and (ROOT/name).stat().st_size>0
costs={}
for name in ['preparation_launcher_resource.txt','launcher_resource_usage.txt','report_launcher_resource.txt','report_revision_launcher_resource.txt']:
 parts=dict(x.split('=') for x in (ROOT/'checks'/name).read_text().split())
 costs[name]={k:float(v) for k,v in parts.items()}
u=resource.getrusage(resource.RUSAGE_SELF)
costs['finalization_process_snapshot']=dict(user_cpu_seconds=u.ru_utime,system_cpu_seconds=u.ru_stime,wall_seconds=time.perf_counter()-T0)
dump('checks/RESOURCE_ACCOUNTING.json',dict(created_utc=utc(),measured_processes=costs,measured_cpu_subtotal_seconds=sum(x['user_cpu_seconds']+x['system_cpu_seconds'] for x in costs.values()),scope='Tracked preparation process, numerical launcher, two report builds, finalization snapshot. Earlier inspection/authoring/syntax shell commands were not individually metered; independent audit is separate. Not a full-task exact total.',new_model_api_calls=0,new_network_calls=0,dependency_installs=0,uploads_by_author=0,FE='not applicable'))
dump('checks/author_final_qa.json',dict(completed_utc=utc(),passed=True,plan_and_numerical_freezes_unchanged=True,old_directories_unchanged=True,all_expected_files_present=True,numerical_exit_code=0,failures_found=[],formal_batches=len(formal),counts=counts,solver_calls_during_this_check=0))
files={str(p.relative_to(ROOT)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(ROOT.rglob('*')) if p.is_file() and p.name!='MANIFEST.json'}
dump('MANIFEST.json',dict(completed_utc=utc(),experiment_id=ROOT.name,status='completed_author_artifact',report='REPORT_ZH.md',files=files,self_excluded=True,pre_run_freeze_sha256=sha(ROOT/'PRE_RUN_FREEZE.json'),calibration_freeze_sha256=sha(ROOT/'CALIBRATION_FREEZE.json'),numerical_exit_code=0,claims='New-seed synthetic validation of post-hoc frozen selector; no universal speed, statistical significance, real-vehicle, or full-paper replication claim. Independent audit delivered separately.'))
for name,rec in read('MANIFEST.json')['files'].items():assert sha(ROOT/name)==rec['sha256']
print(json.dumps(dict(manifest=str(ROOT/'MANIFEST.json'),manifest_sha256=sha(ROOT/'MANIFEST.json'),files=len(files),bytes=sum(x['bytes'] for x in files.values()),report_sha256=sha(ROOT/'REPORT_ZH.md'),resource_accounting=read('checks/RESOURCE_ACCOUNTING.json')),ensure_ascii=False))
