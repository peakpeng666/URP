#!/usr/bin/env python3
import resource,signal
resource.setrlimit(resource.RLIMIT_CPU,(110,110));resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3));signal.alarm(300)
import sys,json,random,hashlib,math,time,itertools,statistics,datetime,collections,csv
from pathlib import Path
sys.dont_write_bytecode=True
A=Path(__file__).resolve().parent;R=A.parent/'independent_turn_selector_validation_20261006';T=time.perf_counter()
from independent_core import independent_cost,check_path,sha,objsha,V
sys.path.insert(0,str(R/'src'))
import search_core,selector
ALG=['astar_manhattan','astar_turn','selector'];CLOCKS=['wall_ns','cpu_ns','thread_cpu_ns'];PERMS=list(itertools.permutations(ALG))
checks=[];failures=[]
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def load(p):return json.loads((R/p).read_text())
def lines(p):return [json.loads(s) for s in (R/p).read_text().splitlines()]
def save(p,v):(A/p).write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def check(name,ok,details=None):
 row={'check':name,'passed':bool(ok)}
 if details is not None:row['details']=details
 checks.append(row)
 if not ok:failures.append(row)
def eq(x,y):
 if isinstance(x,dict):return isinstance(y,dict) and x.keys()==y.keys() and all(eq(x[k],y[k]) for k in x)
 if isinstance(x,list):return isinstance(y,list) and len(x)==len(y) and all(eq(a,b) for a,b in zip(x,y))
 if isinstance(x,(int,float)) and not isinstance(x,bool) and isinstance(y,(int,float)) and not isinstance(y,bool):return math.isclose(x,y,rel_tol=1e-12,abs_tol=1e-8)
 return x==y

def main():
 started=utc();freeze=load('PRE_RUN_FREEZE.json');planfreeze=load('PLAN_FREEZE.json');calfreeze=load('CALIBRATION_FREEZE.json')
 check('pre_run_freeze_matches_hash_received_before_launch',sha(R/'PRE_RUN_FREEZE.json')=='35293c28952849930f87f81f886dc2ca9626d03d27f7de5decc62e20b6bc76a7')
 check('auditor_sampling_plan_unchanged',sha(A/'AUDIT_PLAN_FROZEN.json')=='29d80847fcdd4b4ca34cac92b43ef0e32394825fded491d3e95eb66972bcbd23')
 for label,fr in [('plan',planfreeze),('pre_run',freeze)]:
  check(label+'_pins_unchanged',all(sha(R/p)==d['sha256'] and (R/p).stat().st_size==d['bytes'] for p,d in fr['files'].items()))
 check('calibration_freeze_links',calfreeze['pre_run_freeze_sha256']==sha(R/'PRE_RUN_FREEZE.json') and calfreeze['calibration_sha256']==sha(R/'raw/calibration.jsonl') and calfreeze['canonical_results_sha256']==sha(R/'raw/canonical_results.json'))
 snapshots=load('checks/original_tree_snapshot.json')
 for name,snapshot in snapshots.items():
  rr=R.parent/name
  actual={str(p.relative_to(rr)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(rr.rglob('*')) if p.is_file()}
  check('old_tree_unchanged_'+name,actual==snapshot)
 for file in ['search_core.py','reference.py']:
  check('original_core_copy_'+file,sha(R/'src'/file)==sha(R.parent/'independent_turn_search_timing_20261006'/'src'/file))
 conf=load('inputs/config.json');maps=load('inputs/maps.json');cases=load('inputs/cases.json');M={x['map_id']:x for x in maps};C={x['case_id']:x for x in cases}
 check('expected_design_shape',len(maps)==len(M)==24 and len(cases)==len(C)==72 and conf['seeds']==[932117,932129,932141,932153])
 rebuilt=[];rcases=[]
 for n in conf['sizes']:
  for seed in conf['seeds']:
   for p in conf['obstacle_probabilities']:
    key=f'turn-aware-grid-v1|n={n}|seed={seed}|p={p:.2f}';seednum=int.from_bytes(hashlib.sha256(key.encode()).digest(),'big');rng=random.Random(seednum)
    rows=[''.join('#' if rng.random()<p else '.' for _ in range(n)) for _ in range(n)]
    free=[(x,y) for y,row in enumerate(rows) for x,bit in enumerate(row) if bit=='.'];s,g=rng.sample(free,2);h=rng.randrange(4);mid=f'n{n}_s{seed}_p{int(p*100):02d}'
    rebuilt.append(dict(map_id=mid,n=n,seed=seed,obstacle_probability=p,rng_key=key,rng_seed_hex=hex(seednum),rows=rows,start=[*s,h],goal=list(g),obstacle_count=n*n-len(free)))
    rcases.extend(dict(case_id=f'{mid}_w{w}',map_id=mid,weight=w) for w in conf['weights'])
 check('all_map_bits_metadata_and_case_order_regenerated',maps==rebuilt and cases==rcases)
 oldmaps=json.loads((R.parent/'independent_turn_search_timing_20261006/inputs/maps.json').read_text());oldseeds={m['seed'] for m in oldmaps}
 check('no_old_seed_or_map_bit_overlap',not oldseeds.intersection(conf['seeds']) and not {objsha(m['rows']) for m in maps}.intersection(objsha(m['rows']) for m in oldmaps))
 env=load('checks/environment.json');resourceinfo=load('checks/resource_usage.json');post=load('checks/post_run_checks.json');summary=load('raw/summary.json')
 check('freeze_temporal_order',json.loads((A/'AUDIT_PLAN_FROZEN.json').read_text())['frozen_utc']<planfreeze['frozen_utc']<=freeze['frozen_utc']<env['start_utc']<calfreeze['frozen_utc']<resourceinfo['measured_at_utc']<started)
 check('single_successful_launch_no_failure',load('LAUNCH_EXIT.json')['exit_code']==0 and (R/'LAUNCH_ATTEMPT.json').exists() and not (R/'checks/FAILURE.json').exists())
 check('resource_and_clock_limits',env['gc_enabled'] and env['rlimit_cpu']==[110,110] and env['rlimit_as']==[1024**3,1024**3] and resourceinfo['process_cpu_seconds']<100 and resourceinfo['wall_seconds']<750)
 oracles=lines('raw/oracles.jsonl');O={x['case_id']:x for x in oracles};canonical=load('raw/canonical_results.json');B={(x['case_id'],x['algorithm']):x for x in canonical}
 check('oracle_and_canonical_completeness',len(O)==len(oracles)==72 and len(B)==len(canonical)==216 and set(B)==set(itertools.product(C,ALG)))
 exact={};costrows=[];pathrows=[]
 for c in cases:
  cid=c['case_id'];m=M[c['map_id']];opt,popped=independent_cost(m['rows'],m['start'],m['goal'],c['weight']);exact[cid]=opt
  check('oracle_cost_'+cid,opt==O[cid]['exact_cost']);costrows.append(dict(case_id=cid,independent_cost=opt,author_cost=O[cid]['exact_cost'],forward_states_popped=popped))
  for a in ALG:
   b=B[cid,a];r=b['result'];v=check_path(m['rows'],m['start'],m['goal'],c['weight'],r,opt);pathrows.append(dict(case_id=cid,algorithm=a,**v))
   check('canonical_hash_'+cid+'_'+a,b['result_sha256']==objsha(r))
  branch='astar_manhattan' if c['weight']==0 else 'astar_turn'
  check('selector_identical_branch_'+cid,B[cid,'selector']['result']==B[cid,branch]['result'] and B[cid,'selector']['selected_kernel']==branch)
  if c['weight']==0:check('zero_weight_fixed_outputs_identical_'+cid,B[cid,'astar_manhattan']['result']==B[cid,'astar_turn']['result'])
 save('independent_costs.json',costrows);save('independent_paths.json',pathrows)
 selected=sorted(C,key=lambda cid:hashlib.sha256(('turn-selector-audit-v1|'+cid).encode()).digest())[:12]
 save('selected_replay_cases.json',{'frozen_rule':'SHA256(turn-selector-audit-v1|case_id), lowest twelve','cases':selected})
 replay=[]
 for cid in selected:
  c=C[cid];m=M[c['map_id']]
  for a in ALG:
   args=(m['rows'],m['start'],m['goal'],c['weight'])
   r=selector.select_search(*args) if a=='selector' else search_core.search(*args,a)
   equal=json.loads(json.dumps(r))==B[cid,a]['result'];check('actual_replay_'+cid+'_'+a,equal);replay.append({'case_id':cid,'algorithm':a,'matches':equal,'result_sha256':objsha(r)})
 save('numerical_replay.json',replay)
 original=selector.search;calls=[]
 def spy(*args):calls.append(args[-1]);return {'sentinel':True}
 try:
  selector.search=spy
  weights=[0,-0.0,0.0,2,8,1,0.5]
  for w in weights:
   ret=selector.select_search(None,None,None,w);check('dispatch_'+str(w),ret=={'sentinel':True} and calls[-1]==('astar_manhattan' if w==0 else 'astar_turn'))
  for label,w in [('negative',-1),('negative_fraction',-0.1),('inf',math.inf),('negative_inf',-math.inf),('nan',math.nan)]:
   k=len(calls)
   try:selector.select_search(None,None,None,w);raised=False
   except ValueError:raised=True
   check('invalid_weight_rejected_'+label,raised and len(calls)==k)
 finally:selector.search=original
 boundary={'grid_masks':0,'cases':0,'oracle_calls':0,'tested_search_calls':0,'path_checks':0}
 for n in [2,3]:
  variable=[(x,y) for y in range(n) for x in range(n) if (x,y) not in [(0,0),(n-1,n-1)]]
  for mask in range(2**len(variable)):
   grid=[['.']*n for _ in range(n)]
   for i,(x,y) in enumerate(variable):
    if (mask>>i)&1:grid[y][x]='#'
   rows=[''.join(row) for row in grid];boundary['grid_masks']+=1
   for h,w in itertools.product(range(4),[0,2,8]):
    args=(rows,(0,0,h),(n-1,n-1),w);opt,_=independent_cost(*args);boundary['oracle_calls']+=1;boundary['cases']+=1
    for a in ALG:
     r=selector.select_search(*args) if a=='selector' else search_core.search(*args,a)
     check_path(*args,r,opt);boundary['tested_search_calls']+=1;boundary['path_checks']+=1
 extras=[('start_is_goal',['...']*3,(1,1,2),(1,1)),('reverse',['...']*3,(1,1,0),(0,1)),('unreachable',['.#.']*3,(0,0,1),(2,2))]
 for label,rows,s,g in extras:
  for w in [0,2,8]:
   args=(rows,s,g,w);opt,_=independent_cost(*args);boundary['oracle_calls']+=1;boundary['cases']+=1
   for a in ALG:
    r=selector.select_search(*args) if a=='selector' else search_core.search(*args,a);check_path(*args,r,opt);boundary['tested_search_calls']+=1;boundary['path_checks']+=1
 check('exhaustive_boundary_tests',True,boundary);save('boundary_checks.json',boundary)
 warm=lines('raw/warmup.jsonl');cal=lines('raw/calibration.jsonl');formal=lines('raw/formal_batches.jsonl');allrows=warm+cal+formal
 check('phase_record_counts',len(warm)==216 and len(cal)==432 and len(formal)==1296)
 check('all_batch_identity_path_counts',all(r['result_sha256']==B[r['case_id'],r['algorithm']]['result_sha256'] and r['path_checks']==r['repetitions'] for r in allrows))
 expected_w=[];expected_c=[];expected_f=[]
 for i,c in enumerate(cases):
  cid=c['case_id']
  expected_w.extend((cid,a,pos,1) for pos,a in enumerate(PERMS[i%6]))
  for cr in range(2):expected_c.extend((cid,a,cr,pos,8) for pos,a in enumerate(PERMS[(i+cr)%6]))
 for r in range(6):
  indexes=list(range(72));sh=12*r;indexes=indexes[sh:]+indexes[:sh]
  if r%2:indexes.reverse()
  for pos,i in enumerate(indexes):expected_f.extend((r,i,pos,ap,cases[i]['case_id'],a) for ap,a in enumerate(PERMS[(i+r)%6]))
 check('warmup_order_and_n',[(r['case_id'],r['algorithm'],r['order'],r['repetitions']) for r in warm]==expected_w)
 check('calibration_order_and_n',[(r['case_id'],r['algorithm'],r['calibration_round'],r['order'],r['repetitions']) for r in cal]==expected_c)
 check('formal_exact_order_and_balance',[(r['round'],r['case_index'],r['case_position'],r['algorithm_position'],r['case_id'],r['algorithm']) for r in formal]==expected_f and [r['batch_id'] for r in formal]==list(range(1296)))
 for cid in C:
  for a in ALG:check('balanced_positions_'+cid+'_'+a,collections.Counter(r['algorithm_position'] for r in formal if r['case_id']==cid and r['algorithm']==a)=={0:2,1:2,2:2})
 times={(cid,a):min(r['wall_ns']/r['repetitions'] for r in cal if r['case_id']==cid and r['algorithm']==a) for cid,a in B};N={k:min(20000,max(4,math.ceil(25_000_000/t))) for k,t in times.items()}
 for cid,c in C.items():
  branch='astar_manhattan' if c['weight']==0 else 'astar_turn';shared=max(N[cid,branch],N[cid,'selector']);N[cid,branch]=N[cid,'selector']=shared
 cp={(r['case_id'],r['algorithm']):r for r in calfreeze['plan']}
 check('calibration_repetition_freeze',len(cp)==216 and all(cp[k]['repetitions']==N[k] and cp[k]['calibration_ns_per_search']==times[k] for k in N) and all(r['repetitions']==N[r['case_id'],r['algorithm']] for r in formal))
 forecast=sum(N[k]*times[k] for k in N)/1e9
 check('forecast_budget_and_rounds',eq(forecast,calfreeze['estimated_round_seconds']) and calfreeze['selected_rounds']==6 and calfreeze['forecast_cpu_with_margin_seconds']<=100 and abs(calfreeze['forecast_cpu_with_margin_seconds']-(calfreeze['cpu_seconds_at_freeze']+1.6*6*forecast+8))<0.01)
 counts=dict(oracles=len(oracles),warmup_searches=sum(r['repetitions'] for r in warm),calibration_searches=sum(r['repetitions'] for r in cal),formal_searches=sum(r['repetitions'] for r in formal),path_checks=sum(r['path_checks'] for r in allrows),batch_checks=len(allrows),selector_branch_result_checks=sum(r['repetitions'] for r in allrows if r['algorithm']=='selector'),dispatch_probes=7)
 check('all_reported_search_counts',counts==summary['counts']==post['counts']==resourceinfo['counts'])
 zero_by_phase={name:{k:sum(r[k]==0 for r in rows) for k in CLOCKS} for name,rows in [('warmup',warm),('calibration',cal),('formal',formal)]}
 check('nonnegative_all_timestamps',all(r[k]>=0 for r in allrows for k in CLOCKS))
 check('formal_zero_and_ranges',zero_by_phase['formal']==summary['zero_time_batches'] and {k:[min(r[k] for r in formal),max(r[k] for r in formal)] for k in CLOCKS}==summary['batch_ranges_ns'])
 pairs=[]
 for c in cases:
  cid=c['case_id'];m=M[c['map_id']];branch='astar_manhattan' if c['weight']==0 else 'astar_turn';p=dict(**c,n=m['n'],seed=m['seed'],obstacle_probability=m['obstacle_probability'],reachable=exact[cid] is not None,selected_kernel=branch)
  for a in ALG:
   rr=[r for r in formal if r['case_id']==cid and r['algorithm']==a]
   for k in CLOCKS:
    v=sorted(r[k]/r['repetitions'] for r in rr)
    p[a+'_'+k+'_median']=(v[2]+v[3])/2;p[a+'_'+k+'_min']=v[0];p[a+'_'+k+'_max']=v[-1]
   for k in ['expansions','heap_pushes']:p[a+'_'+k]=B[cid,a]['result'][k]
  for k in CLOCKS:p['selected_branch_'+k]=p[branch+'_'+k+'_median'];p['selector_excess_'+k]=p['selector_'+k+'_median']-p[branch+'_'+k+'_median']
  for target,a in [('manhattan','astar_manhattan'),('turn','astar_turn'),('selected',branch)]:p['selector_wall_ratio_to_'+target]=p['selector_wall_ns_median']/p[a+'_wall_ns_median']
  for a,label in [('astar_turn','turn'),('selector','selector')]:p[label+'_fewer_expansions_but_wall_slower']=p[a+'_expansions']<p['astar_manhattan_expansions'] and p[a+'_wall_ns_median']>p['astar_manhattan_wall_ns_median']
  pairs.append(p)
 check('all_paired_case_fields_recomputed',eq(pairs,load('raw/paired_cases.json')))
 groups=[]
 for authored in summary['groups']:
  key,value=authored['group_by'],authored['value']
  if key=='all':pp=pairs
  elif key=='weight_reachable':pp=[p for p in pairs if str(p['weight'])+'|'+str(p['reachable'])==value]
  else:pp=[p for p in pairs if p[key]==value]
  totals={a:{**{k:sum(p[a+'_'+k+'_median'] for p in pp) for k in CLOCKS},**{k:sum(p[a+'_'+k] for p in pp) for k in ['expansions','heap_pushes']}} for a in ALG}
  selected={k:sum(p['selected_branch_'+k] for p in pp) for k in CLOCKS};ratios={a:{k:1-totals['selector'][k]/totals[a][k] if totals[a][k] else None for k in CLOCKS+['expansions']} for a in ALG[:2]}
  wins={a:[sum(p['selector_wall_ns_median']<p[a+'_wall_ns_median'] for p in pp),sum(p['selector_wall_ns_median']==p[a+'_wall_ns_median'] for p in pp),sum(p['selector_wall_ns_median']>p[a+'_wall_ns_median'] for p in pp)] for a in ALG[:2]}
  group=dict(group_by=key,value=value,cases=len(pp),maps=len({p['map_id'] for p in pp}),totals=totals,selector_reduction_vs=ratios,selector_wall_win_tie_loss_vs=wins,offline_selected_branch_totals=selected,selector_excess_vs_selected={k:totals['selector'][k]-selected[k] for k in CLOCKS},selector_excess_ratio_vs_selected={k:totals['selector'][k]/selected[k]-1 if selected[k] else None for k in CLOCKS});groups.append(group)
 check('all_21_group_fields_recomputed',len(groups)==21 and eq(groups,summary['groups']))
 rounds=[]
 for rd in range(6):
  for weight in ['all',0,2,8]:
   records=[r for r in formal if r['round']==rd and (weight=='all' or r['weight']==weight)]
   totals={a:sum(r['wall_ns']/r['repetitions'] for r in records if r['algorithm']==a) for a in ALG}
   chosen=sum(r['wall_ns']/r['repetitions'] for r in records if r['algorithm']==('astar_manhattan' if r['weight']==0 else 'astar_turn'))
   rounds.append(dict(round=rd,weight=weight,wall_ns=totals,offline_selected_wall_ns=chosen,selector_ratio_to_manhattan=totals['selector']/totals['astar_manhattan'],selector_ratio_to_turn=totals['selector']/totals['astar_turn'],selector_ratio_to_selected=totals['selector']/chosen))
 check('all_24_round_sensitivity_fields',eq(rounds,load('raw/round_group_sensitivity.json')))
 clockdiag={k+'_to_wall':{'min':min(r[k]/r['wall_ns'] for r in formal),'median':statistics.median(r[k]/r['wall_ns'] for r in formal),'max':max(r[k]/r['wall_ns'] for r in formal)} for k in CLOCKS[1:]}
 check('clock_diagnostics_recomputed',eq(clockdiag,load('raw/clock_comparison_diagnostic.json')))
 for label in ['turn','selector']:check('counterexamples_'+label,[p['case_id'] for p in pairs if p[label+'_fewer_expansions_but_wall_slower']]==summary[label+'_fewer_expansions_but_wall_slower_cases'])
 check('unreachable_retained',summary['unreachable_maps']==1 and summary['unreachable_cases']==[p['case_id'] for p in pairs if not p['reachable']])
 for name,rows in [('formal_batches',formal),('paired_cases',pairs)]:
  with (R/('raw/'+name+'.csv')).open() as f:csvrows=list(csv.DictReader(f))
  check(name+'_csv_agrees_with_json',len(rows)==len(csvrows) and all(set(x)==set(y) and all(('' if x[k] is None else str(x[k]))==y[k] for k in x) for x,y in zip(rows,csvrows)))
 losses={a:[p for p in pairs if p['selector_wall_ns_median']>p[a+'_wall_ns_median']] for a in ALG[:2]}
 details={'counts':counts,'zero_by_phase':zero_by_phase,'batch_ranges_ns':summary['batch_ranges_ns'],'groups':groups,'rounds':rounds,'clock_diagnostics':clockdiag,'selector_losses':losses,'fewer_expansions_but_slower':{a:[p for p in pairs if p[a+'_fewer_expansions_but_wall_slower']] for a in ['turn','selector']},'negative_selector_difference_cases':sum(p['selector_excess_wall_ns']<0 for p in pairs),'positive_selector_difference_cases':sum(p['selector_excess_wall_ns']>0 for p in pairs),'branch_ranges_overlap_cases':sum(max(p['selector_wall_ns_min'],p[p['selected_kernel']+'_wall_ns_min'])<=min(p['selector_wall_ns_max'],p[p['selected_kernel']+'_wall_ns_max']) for p in pairs),'selector_vs_turn_saving_by_round':[1-r['selector_ratio_to_turn'] for r in rounds if r['weight']=='all'],'pinned_inputs':{str(p.relative_to(R)):{'bytes':p.stat().st_size,'sha256':sha(p)} for folder in ['inputs','src','raw','checks'] for p in sorted((R/folder).rglob('*')) if p.is_file()}}
 save('recomputed_results.json',details)
 u=resource.getrusage(resource.RUSAGE_SELF);save('AUDIT_CHECKS.json',{'started_utc':started,'completed_utc':utc(),'status':'PASS' if not failures else 'FAIL','checks_count':len(checks),'failed_checks':failures,'checks':checks,'sampling_plan_sha256':sha(A/'AUDIT_PLAN_FROZEN.json'),'independent_main_oracles':72,'canonical_paths_checked':216,'real_replay_searches':36,'boundary':boundary,'resource':{'process_cpu_seconds':u.ru_utime+u.ru_stime,'wall_seconds':time.perf_counter()-T,'max_rss_kib':u.ru_maxrss,'hard_cpu_seconds':110},'no_author_files_written':True})
 print(json.dumps({'status':'PASS' if not failures else 'FAIL','checks':len(checks),'failures':failures,'counts':counts,'audit_cpu_seconds':u.ru_utime+u.ru_stime,'boundary':boundary},ensure_ascii=False))

if __name__=='__main__':main()
