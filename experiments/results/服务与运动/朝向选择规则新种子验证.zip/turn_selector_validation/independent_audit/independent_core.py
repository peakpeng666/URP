"""Auditor implementation. Does not import author oracle or solver."""
import heapq, hashlib, json, math
V=((1,0),(0,1),(-1,0),(0,-1))

def turn_cost(h,j):
    a,b=V[h],V[j]
    d=a[0]*b[0]+a[1]*b[1]
    return {1:0,0:1,-1:2}[d]

def independent_cost(rows,start,goal,w):
    n=len(rows)
    start=tuple(start);goal=tuple(goal)
    # Integer-coded forward graph, as distinct from the author's reverse graph.
    code=lambda x,y,h:4*(y*n+x)+h
    s=code(*start);d={s:0};q=[(0,s)];popped=0
    while q:
        g,z=heapq.heappop(q)
        if d.get(z)!=g:continue
        h=z%4;cell=z//4;x=cell%n;y=cell//n;popped+=1
        if (x,y)==goal:return g,popped
        for j,(dx,dy) in enumerate(V):
            xx,yy=x+dx,y+dy
            if 0<=xx<n and 0<=yy<len(rows) and rows[yy][xx]=='.':
                zz=code(xx,yy,j);gg=g+1+w*turn_cost(h,j)
                if gg<d.get(zz,math.inf):d[zz]=gg;heapq.heappush(q,(gg,zz))
    return None,popped

def check_path(rows,start,goal,w,r,opt):
    assert r['reachable']==(opt is not None)
    assert r['cost']==opt
    if opt is None:
        assert r['path']==[];return {'steps':None,'turn_units':None,'cost':None}
    p=r['path'];assert p and tuple(p[0])==tuple(start) and tuple(p[-1][:2])==tuple(goal)
    turns=0
    for i,(x,y,h) in enumerate(p):
        assert h in range(4) and 0<=y<len(rows) and 0<=x<len(rows[y]) and rows[y][x]=='.'
        if i:
            px,py,ph=p[i-1]
            assert (x-px,y-py)==V[h]
            turns+=turn_cost(ph,h)
    assert len(p)-1+w*turns==opt
    assert r['successor_candidates']==r['expansions']*4
    assert r['accepted_pops']==r['expansions']+int(r['reachable'])
    assert r['reexpansions']==0
    return {'steps':len(p)-1,'turn_units':turns,'cost':opt}

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def objsha(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
