"""Forward-only Dubins candidate generation and exact box extrema.

The six-word algebra follows official OMPL 1.7.0 DubinsStateSpace.cpp,
Copyright (c) 2010 Rice University, BSD-3-Clause; complete source/license
retained in ../reference/ompl_DubinsStateSpace_1.7.0.cpp.
Adaptations: Python double precision; domain tolerance 1e-12; inclusive
CCC degeneracies; no OMPL short-distance or float-based classification.
Only candidate enumeration is adapted. Box checks and routing are new.
"""
import math
TAU=2*math.pi
WORDS=('LSL','RSR','RSL','LSR','RLR','LRL')
DOMAIN_EPS=1e-12

def mod(x):
    z=x%TAU
    return 0.0 if z<1e-12 or TAU-z<1e-12 else z

def word_parameters(d,a,b):
    ca,sa,cb,sb=math.cos(a),math.sin(a),math.cos(b),math.sin(b)
    c=ca*cb+sa*sb
    ans={}
    z=2+d*d-2*(c-d*(sa-sb))
    if z>=-DOMAIN_EPS:
        th=math.atan2(cb-ca,d+sa-sb)
        ans['LSL']=(mod(-a+th),math.sqrt(max(z,0.)),mod(b-th))
    z=2+d*d-2*(c-d*(sb-sa))
    if z>=-DOMAIN_EPS:
        th=math.atan2(ca-cb,d-sa+sb)
        ans['RSR']=(mod(a-th),math.sqrt(max(z,0.)),mod(-b+th))
    z=d*d-2+2*(c-d*(sa+sb))
    if z>=-DOMAIN_EPS:
        p=math.sqrt(max(z,0.)); th=math.atan2(ca+cb,d-sa-sb)-math.atan2(2.,p)
        ans['RSL']=(mod(a-th),p,mod(b-th))
    z=d*d-2+2*(c+d*(sa+sb))
    if z>=-DOMAIN_EPS:
        p=math.sqrt(max(z,0.)); th=math.atan2(-ca-cb,d+sa+sb)-math.atan2(-2.,p)
        ans['LSR']=(mod(-a+th),p,mod(-b+th))
    z=(6-d*d+2*(c+d*(sa-sb)))/8
    if abs(z)<=1+DOMAIN_EPS:
        p=TAU-math.acos(max(-1.,min(1.,z)))
        t=mod(a-math.atan2(ca-cb,d-sa+sb)+p/2)
        ans['RLR']=(t,p,mod(a-b-t+p))
    z=(6-d*d+2*(c-d*(sa-sb)))/8
    if abs(z)<=1+DOMAIN_EPS:
        p=TAU-math.acos(max(-1.,min(1.,z)))
        t=mod(-a+math.atan2(cb-ca,d+sa-sb)+p/2)
        ans['LRL']=(t,p,mod(b-a-t+p))
    return ans

def normalized(q0,q1,R):
    dx,dy=q1[0]-q0[0],q1[1]-q0[1]
    direction=math.atan2(dy,dx)
    return math.hypot(dx,dy)/R,mod(q0[2]-direction),mod(q1[2]-direction)

def propagate(q,kind,u,R):
    x,y,h=q
    if kind=='S': return (x+R*u*math.cos(h),y+R*u*math.sin(h),h)
    sign=1 if kind=='L' else -1
    end=h+sign*u
    return (x+sign*R*(math.sin(end)-math.sin(h)),
            y+sign*R*(-math.cos(end)+math.cos(h)),end)

def segment(q,kind,u,R):
    end=propagate(q,kind,u,R)
    pts=[q[:2],end[:2]]
    if kind!='S':
        sign=1 if kind=='L' else -1
        cx=q[0]-sign*R*math.sin(q[2]); cy=q[1]+sign*R*math.cos(q[2])
        start_angle=math.atan2(q[1]-cy,q[0]-cx)
        # A circle reaches axis-aligned extrema at its four cardinal angles.
        for angle in (0.,math.pi/2,math.pi,3*math.pi/2):
            travel=(sign*(angle-start_angle))%TAU
            if travel<=u+1e-12:
                pts.append((cx+R*math.cos(angle),cy+R*math.sin(angle)))
    bbox=[min(p[0] for p in pts),max(p[0] for p in pts),min(p[1] for p in pts),max(p[1] for p in pts)]
    return {'kind':kind,'u':u,'length':R*u,'start':list(q),'end':list(end),'bbox':bbox,
            'curvature':0. if kind=='S' else (1. if kind=='L' else -1.)/R}

def candidates(q0,q1,R,box):
    out=[]
    for word,pars in word_parameters(*normalized(q0,q1,R)).items():
        q=q0; segs=[]
        for kind,u in zip(word,pars):
            sg=segment(q,kind,u,R); segs.append(sg); q=sg['end']
        bbox=[min(s['bbox'][0] for s in segs),max(s['bbox'][1] for s in segs),min(s['bbox'][2] for s in segs),max(s['bbox'][3] for s in segs)]
        margin=min(bbox[0]-box[0],box[1]-bbox[1],bbox[2]-box[2],box[3]-bbox[3])
        pe=math.hypot(q[0]-q1[0],q[1]-q1[1]); he=abs(math.remainder(q[2]-q1[2],TAU))
        if pe>2e-8 or he>2e-10: raise AssertionError(('Formula closure',word,q0,q1,R,pars,pe,he))
        out.append({'word':word,'params':pars,'length':sum(pars)*R,'segments':segs,'bbox':bbox,
                    'boundary_margin':margin,'feasible':margin>=-1e-9,
                    'endpoint_error':pe,'heading_error':he})
    return out

def held_karp(cost):
    n=len(cost)-1
    D={}
    for j in range(1,n+1):
        if math.isfinite(cost[0][j]): D[(1<<(j-1),j)]=(cost[0][j],(j,))
    for mask in range(1,1<<n):
        for j in range(1,n+1):
            prior=D.get((mask,j))
            if prior is None: continue
            for k in range(1,n+1):
                bit=1<<(k-1)
                if mask&bit or not math.isfinite(cost[j][k]): continue
                candidate=(prior[0]+cost[j][k],prior[1]+(k,))
                key=(mask|bit,k)
                if key not in D or candidate<D[key]: D[key]=candidate
    finals=[(c+cost[j][0],p) for (mask,j),(c,p) in D.items() if mask==(1<<n)-1 and math.isfinite(cost[j][0])]
    if not finals: return math.inf,None
    value,order=min(finals)
    return value,(0,)+order+(0,)

def tour_cost(cost,route):
    return sum(cost[a][b] for a,b in zip(route,route[1:]))
