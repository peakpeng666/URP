#!/usr/bin/env python3
import csv, json, time, math, hashlib, datetime, itertools, resource, platform
from pathlib import Path
from dubins import candidates, held_karp, tour_cost
ROOT=Path(__file__).resolve().parents[1]

def dump(path,obj):
    path.write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False)+'\n')

def finite(x): return x if math.isfinite(x) else None

def main():
    t0=time.perf_counter(); cpu=time.process_time()
    cfg=json.loads((ROOT/'freeze.json').read_text()); instances=json.loads((ROOT/'instances.json').read_text())
    for line in (ROOT/'freeze.sha256').read_text().splitlines():
        sha,name=line.split('  ')
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==sha,name
    assert not (ROOT/'raw/results.json').exists(),'Do not overwrite formal results.'
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    perms=[(0,)+p+(0,) for p in itertools.permutations(range(1,8))]
    out=[]; failures=[]; graphs=[]; candidate_n=0
    with (ROOT/'raw/edges.jsonl').open('w') as edge_file:
      for g in instances:
        poses=g['poses']; n=len(poses)
        ec=[[math.dist(a[:2],b[:2]) for b in poses] for a in poses]
        emin,eroute=held_karp(ec)
        tied=[p for p in perms if abs(tour_cost(ec,p)-emin)<=1e-8]
        assert tied and len(tied)%2==0
        for R in cfg['radius_values']:
            name=g['geometry_id']+f'_R{R:g}'
            c=[[math.inf]*n for _ in range(n)]; selected={}; unconstrained=[[math.inf]*n for _ in range(n)]
            for i in range(n):
              for j in range(n):
                if i==j: continue
                paths=candidates(poses[i],poses[j],R,cfg['rectangle']); candidate_n+=len(paths)
                feasible=[p for p in paths if p['feasible']]
                unconstrained[i][j]=min(p['length'] for p in paths)
                best=min(feasible,key=lambda p:(p['length'],p['word'])) if feasible else None
                if best: c[i][j]=best['length']; selected[f'{i},{j}']=best['word']
                edge_file.write(json.dumps({'instance_id':name,'i':i,'j':j,'R':R,'q0':poses[i],'q1':poses[j],
                  'candidates':paths,'selected_word':best['word'] if best else None,'cost':finite(c[i][j])},allow_nan=False)+'\n')
            dc,dr=held_karp(c)
            bc,br=min((tour_cost(c,p),p) for p in tied)
            canonical=tied[0]; cc=tour_cost(c,canonical)
            missing=[[a,b] for a,b in zip(br,br[1:]) if not math.isfinite(c[a][b])]
            row={'instance_id':name,'geometry_id':g['geometry_id'],'group':g['group'],'R':R,
              'euclidean_optimum':emin,'euclidean_tie_count':len(tied),
              'euclidean_optimal_orders':[list(p) for p in tied],
              'baseline_route':list(br),'baseline_cost':finite(bc),'baseline_feasible':math.isfinite(bc),
              'baseline_missing_edges':missing,'canonical_route':list(canonical),'canonical_cost':finite(cc),
              'canonical_feasible':math.isfinite(cc),'tie_resolution_rescued_failure':not math.isfinite(cc) and math.isfinite(bc),
              'dubins_dp_route':list(dr) if dr else None,'dubins_dp_cost':finite(dc),'dubins_dp_feasible':math.isfinite(dc),
              'ordering_only_failure':not math.isfinite(bc) and math.isfinite(dc),
              'common_feasible_gap_pct':(bc/dc-1)*100 if math.isfinite(bc) and math.isfinite(dc) else None,
              'feasible_edge_count':sum(math.isfinite(c[i][j]) for i in range(n) for j in range(n) if i!=j),
              'outgoing_missing_nodes':[i for i in range(n) if not any(math.isfinite(c[i][j]) for j in range(n) if i!=j)],
              'incoming_missing_nodes':[j for j in range(n) if not any(math.isfinite(c[i][j]) for i in range(n) if i!=j)]}
            if math.isfinite(bc): assert math.isfinite(dc) and dc<=bc+1e-8
            if not math.isfinite(bc) or not math.isfinite(dc): failures.append(row)
            out.append(row)
            graphs.append({'instance_id':name,'cost':[[finite(v) for v in r] for r in c],
               'unbounded_cost':[[finite(v) for v in r] for r in unconstrained],'selected_words':selected})
        print(g['geometry_id'],'done',flush=True)
    dump(ROOT/'raw/results.json',out); dump(ROOT/'raw/graphs.json',graphs); dump(ROOT/'raw/failures.json',failures)
    fields=[k for k,v in out[0].items() if not isinstance(v,list) and not k.endswith('route')]
    with (ROOT/'raw/results.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(out)
    status={'status':'completed','started_utc':start,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
      'instances':len(out),'geometries':len(instances),'directed_edges':len(out)*56,'candidate_paths':candidate_n,
      'wall_seconds':time.perf_counter()-t0,'cpu_seconds':time.process_time()-cpu,
      'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'python':platform.python_version(),
      'external_model_calls':0,'paid_calls':0}
    dump(ROOT/'evidence/run_status.json',status); print(json.dumps(status,indent=2))
if __name__=='__main__': main()
