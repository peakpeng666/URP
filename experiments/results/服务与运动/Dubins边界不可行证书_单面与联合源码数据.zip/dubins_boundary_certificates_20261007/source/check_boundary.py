#!/usr/bin/env python3
"""Bounded, exact-rational necessary-condition audit. No trajectory search.

Uses only Python's standard library. Input JSON numbers are interpreted as the
exact binary64 numbers used by the original Python experiment. All certificate
decisions use Fraction arithmetic and a rigorous Taylor remainder, not libm.
"""
import argparse
import csv
import datetime
from fractions import Fraction as F
import hashlib
import json
import math
from pathlib import Path
import resource
import time

BASE = Path(__file__).resolve().parents[1]
DEGREE = 64
BOUNDARY_TOL = F(1, 10**9)
LENGTH_GUARD = F(1, 10**6)
PROJECTION_GUARD = F(1, 10**12)
DECIMAL_PLACES = 24
FACES = [('left', (-1, 0), 0), ('right', (1, 0), 1),
         ('bottom', (0, -1), 2), ('top', (0, 1), 3)]


def dump(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False,
                               allow_nan=False) + '\n')


def rational(value):
    return F.from_float(value) if isinstance(value, float) else F(value)


def directed_decimal(value, up=False):
    """Outward rounding to exact decimal strings; no float conversion."""
    scale = 10**DECIMAL_PLACES
    scaled = value * scale
    integer = -((-scaled.numerator) // scaled.denominator) if up else scaled.numerator // scaled.denominator
    sign = '-' if integer < 0 else ''
    integer = abs(integer)
    return f'{sign}{integer // scale}.{integer % scale:0{DECIMAL_PLACES}d}'


def interval_json(interval):
    return {'lower': directed_decimal(interval[0]),
            'upper': directed_decimal(interval[1], up=True)}


def sin_cos_interval(x):
    # Taylor polynomials through degree 64 about 0. Lagrange remainder:
    # |f(x) - P_64(x)| <= |x|^65 / 65!, since every derivative has |.| <= 1.
    # Fraction arithmetic makes this enclosure rigorous for exact binary64 x.
    assert abs(x) <= 4, 'Fixed dataset only; unexpected input angle.'
    sine, cosine = F(0), F(0)
    term = F(1)
    for k in range(DEGREE + 1):
        if k % 2:
            sine += (-1 if ((k - 1) // 2) % 2 else 1) * term
        else:
            cosine += (-1 if (k // 2) % 2 else 1) * term
        term *= x / (k + 1)
    error = abs(x)**(DEGREE + 1) / math.factorial(DEGREE + 1)
    return ((max(F(-1), sine - error), min(F(1), sine + error)),
            (max(F(-1), cosine - error), min(F(1), cosine + error)), error)


def mul(interval, c):
    a, b = interval[0] * c, interval[1] * c
    return min(a, b), max(a, b)


def add(a, b):
    return a[0] + b[0], a[1] + b[1]


def absolute(interval):
    a, b = interval
    return (F(0) if a <= 0 <= b else min(abs(a), abs(b)), max(abs(a), abs(b)))


def check_case(instance, name, cfg, radius):
    box = [rational(x) for x in cfg['rectangle']]
    depot = [rational(x) for x in instance['poses'][0][:2]]
    records, certificates = [], []
    max_remainder = F(0)
    for i, original_pose in enumerate(instance['poses'][1:], start=1):
        x, y, theta = map(rational, original_pose)
        s, c, remainder = sin_cos_interval(theta)
        max_remainder = max(max_remainder, remainder)
        for face, (nx, ny), index in FACES:
            # Each face is n dot p <= h.
            h = box[index] if face in ('right', 'top') else -box[index]
            position_projection = nx * x + ny * y
            d = h - position_projection
            depot_delta = nx * (depot[0] - x) + ny * (depot[1] - y)
            assert d >= 0
            for direction, sign in [('outgoing_to_depot', 1), ('incoming_from_depot_reversed', -1)]:
                cos_phi = mul(add(mul(c, nx), mul(s, ny)), sign)
                sin_phi = mul(add(mul(s, nx), mul(c, -ny)), sign)
                abs_sin = absolute(sin_phi)
                lower_bound = (radius * (1 - abs_sin[1]), radius * (1 - abs_sin[0]))
                # Include original boundary tolerance plus a separate one-micron
                # guard. This does not relax/change the model; it weakens the test.
                margin = (lower_bound[0] - d - BOUNDARY_TOL - LENGTH_GUARD,
                          lower_bound[1] - d - BOUNDARY_TOL - LENGTH_GUARD)
                outward = cos_phi[0] > PROJECTION_GUARD
                target_inside = depot_delta < -LENGTH_GUARD
                certified = outward and target_inside and margin[0] > 0
                reasons = []
                if not outward:
                    reasons.append('strict outward projection not established')
                if not target_inside:
                    reasons.append('depot strictly inward not established')
                if margin[0] <= 0:
                    reasons.append('strict displacement deficit beyond all guards not established')
                rec = {
                    'instance_id': name, 'service_pose_index': i,
                    'pose': original_pose, 'face': face, 'outward_normal': [nx, ny],
                    'face_h_exact': str(h), 'direction': direction,
                    'R_m': float(radius), 'heading_rad': original_pose[2],
                    'auxiliary_heading': 'theta' if sign == 1 else 'theta + pi (exact symbolic pi)',
                    'cos_phi_interval': interval_json(cos_phi),
                    'sin_phi_interval': interval_json(sin_phi),
                    'clearance_d_m_exact': str(d), 'clearance_d_m': float(d),
                    'required_outward_displacement_m_interval': interval_json(lower_bound),
                    'required_outward_displacement_m_display': float((lower_bound[0] + lower_bound[1]) / 2),
                    'raw_deficit_m_interval': interval_json((lower_bound[0] - d, lower_bound[1] - d)),
                    'boundary_tolerance_m': str(BOUNDARY_TOL),
                    'additional_length_guard_m': str(LENGTH_GUARD),
                    'strict_margin_m_interval': interval_json(margin),
                    'strict_margin_m_display': float(margin[0]),
                    'depot_pose': instance['poses'][0],
                    'target_normal_displacement_m_exact': str(depot_delta),
                    'target_normal_displacement_m': float(depot_delta),
                    'target_strictly_inward': target_inside,
                    'initial_auxiliary_velocity_strictly_outward': outward,
                    'status': 'certified_model_infeasible' if certified else 'not_proved_by_this_test',
                    'non_certificate_reasons': reasons,
                }
                records.append(rec)
                if certified:
                    certificates.append(rec)
    result = {'instance_id': name, 'service_poses_checked': 7,
              'faces_per_pose': 4, 'directions_per_face': 2,
              'checks': len(records), 'certificate_count': len(certificates),
              'status': 'certified_model_infeasible' if certificates else 'not_proved_by_this_test',
              'certificates': certificates}
    return records, result, max_remainder


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, default=BASE)
    args = parser.parse_args()
    start_cpu, start_wall = time.process_time(), time.perf_counter()
    # Includes this process only; no subprocess or solver is launched.
    resource.setrlimit(resource.RLIMIT_CPU, (9, 10))
    manifest = json.loads((BASE / 'input_manifest.json').read_text())
    for entry in manifest:
        assert hashlib.sha256((BASE / entry['copy']).read_bytes()).hexdigest() == entry['sha256'], entry
    cfg = json.loads((BASE / 'input/original_freeze.json').read_text())
    diagnostic = json.loads((BASE / 'input/diagnostic_freeze.json').read_text())
    instances = json.loads((BASE / 'input/original_instances.json').read_text())
    selected_copy = json.loads((BASE / 'input/diagnostic_instances_selected5.json').read_text())
    failure_index = json.loads((BASE / 'input/original_failure_index.json').read_text())
    names = failure_index['both_failures_in_candidate_graph']
    assert names == diagnostic['instance_ids']
    assert len(names) == 5 and cfg['tasks_per_geometry'] == 7
    assert cfg['rectangle'] == diagnostic['rectangle'] == [0.0, 40.0, 0.0, 30.0]
    assert cfg['depot_pose'] == [20.0, 15.0, 0.0]
    assert diagnostic['R'] == 6.0
    assert cfg['motion_model'] == ('Forward-only unit-speed point Dubins vehicle, curvature bounded by 1/R. '
                                  'Fixed task and depot headings. No obstacles except axis-aligned rectangle. '
                                  'Heading continuous, curvature discontinuous at switches; no footprint, '
                                  'steering-rate, acceleration, collision or real-vehicle dynamics.')
    chosen = []
    all_checks, case_results = [], []
    remainder = F(0)
    for name in names:
        geometry_id, radius_text = name.rsplit('_R', 1)
        radius = F(radius_text)
        assert radius == rational(diagnostic['R'])
        instance = next(g for g in instances if g['geometry_id'] == geometry_id)
        assert len(instance['poses']) == 8 and instance['poses'][0] == cfg['depot_pose']
        chosen.append(instance)
        checks, result, err = check_case(instance, name, cfg, radius)
        all_checks.extend(checks)
        case_results.append(result)
        remainder = max(remainder, err)
    assert chosen == selected_copy, 'Diagnostic inputs differ from original instances.'
    assert len(all_checks) == 5 * 7 * 4 * 2
    for result in case_results:
        dump(args.output / 'certificates' / (result['instance_id'] + '.json'), result)
    dump(args.output / 'all_checks.json', all_checks)
    flattened = [r for result in case_results for r in result['certificates']]
    fields = ['instance_id', 'service_pose_index', 'face', 'direction', 'R_m', 'heading_rad',
              'clearance_d_m', 'required_outward_displacement_m_display', 'strict_margin_m_display',
              'target_normal_displacement_m', 'target_strictly_inward', 'status']
    with (args.output / 'certificates.csv').open('w', newline='') as fp:
        writer = csv.DictWriter(fp, fieldnames=fields, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(flattened)
    summary = {
        'status': 'completed', 'generated_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'instances_checked': 5, 'total_pose_face_direction_checks': len(all_checks),
        'certificate_count': len(flattened),
        'certified_model_infeasible_instances': [r['instance_id'] for r in case_results if r['certificates']],
        'not_proved_instances': [r['instance_id'] for r in case_results if not r['certificates']],
        'per_instance': [{k: v for k, v in r.items() if k != 'certificates'} for r in case_results],
        'model_scope': cfg['motion_model'],
        'classification_limit': 'Only the fixed forward-only, bounded-curvature point-vehicle rectangle model. No claim for vehicles allowed to reverse or rotate in place.',
        'arithmetic': 'All decisions exact Fraction arithmetic; degree-64 Taylor sin/cos with Lagrange remainder. Interval display directed-rounded to 24 decimal places.',
        'input_number_semantics': 'Exact binary64 values obtained by Python JSON parsing, matching original experiment.',
        'maximum_trig_remainder_upper_bound': directed_decimal(remainder, up=True),
        'maximum_trig_remainder_float_display': float(remainder),
        'boundary_tolerance_m': str(BOUNDARY_TOL), 'additional_length_guard_m': str(LENGTH_GUARD),
        'positive_projection_guard': str(PROJECTION_GUARD),
        'input_hashes_verified': True, 'selected_copy_matches_original': True,
        'trajectory_searches': 0, 'grid_constructions': 0, 'tour_solves': 0,
        'external_model_calls': 0, 'paid_calls': 0,
        'cpu_hard_limit_seconds': 10, 'cpu_soft_limit_seconds': 9,
        'cpu_seconds': time.process_time() - start_cpu,
        'wall_seconds': time.perf_counter() - start_wall,
    }
    dump(args.output / 'summary.json', summary)
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()
