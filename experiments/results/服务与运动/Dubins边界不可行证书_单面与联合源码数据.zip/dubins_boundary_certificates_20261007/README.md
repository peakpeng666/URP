# Dubins 边界必要条件证书

本目录对原五个失败实例做独立于候选图的局部数学必要条件检查。

- 数学说明：`PROOF_ZH.txt`
- 原输入、模型源代码与 SHA256：`input/`、`input_manifest.json`
- 全部 280 项检查：`all_checks.json`
- 每例机器结果与成立证书：`certificates/*.json`
- 四张成立证书概要：`certificates.csv`
- 汇总：`summary.json`
- 可复核脚本：`source/check_boundary.py`（仅 Python 3 标准库）
- 资源和原文件未改动证据：`evidence/`

从本目录执行以下命令，输出复核结果到单独目录，避免覆盖交付结果：

    python source/check_boundary.py --output /tmp/dubins_boundary_recheck

脚本核对所有复制输入的 SHA256、原五例ID、半径、边界和固定 depot，再逐姿态/边界/方向检查。它不导入原 Dubins 生成器，不构造图或调用求解器，也不调用网络。

所有判定以精确 `Fraction` 运算为准。`*_display` 和一般浮点数值字段只方便阅读；`*_interval` 字段是向外舍入的可靠包围区间。`*_exact` 字段保留相应精确有理数。`certified_model_infeasible` 只用于限定的原模型；`not_proved_by_this_test` 不表示可行。

数值基础为原 Python JSON 解析使用的确切 binary64 值，而非擅自重新解释为十进制实数。sin/cos 多项式的64阶 Lagrange 余项在本数据至多约1.95e-59。机器输出中的24位向外舍入上界为1e-24，这是更松但仍严格的显示包围，并不是实际算术误差。

输入姿态未改变，所有证书均检查 depot 严格在相关面的内侧。入边检查严格使用反向参数化辅助路径的切向；这不授权或模拟原车倒车。更多模型限定见数学说明。

本目录是新证据包；原72例及后续有限图实验文件保持不变。只有审查通过后，才适合把对应三例的整体结论提升为原连续模型不可行；其他两例仍未解决。
