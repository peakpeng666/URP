#!/usr/bin/env python3
"""Post-hoc adjacent-face necessary-condition audit; no search or tour solve.
Reads the finalized single-face input copies and exact-rational trig enclosure.
Writes only the separate joint/ directory. All decisions use Fractions.
"""
import csv
import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import resource
import sys
import time
sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parents[2]
OUT = BASE / 'joint'
spec = importlib.util.spec_from_file_location('single_face_arithmetic', BASE / 'source/check_boundary.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
F = m.F
PAIR_NAMES = [('left', 'bottom'), ('left', 'top'), ('right', 'bottom'), ('right', 'top')]
FACES = {name: (normal, index) for name, normal, index in m.FACES}


def bounds_shift(interval, constant, sign, radius):
    z = m.mul(interval, sign)
    return radius * (constant + z[0]), radius * (constant + z[1])


def main():
    t0, c0 = time.perf_counter(), time.process_time()
    resource.setrlimit(resource.RLIMIT_CPU, (1, 2))
    manifest = json.loads((BASE / 'input_manifest.json').read_text())
    for entry in manifest:
        assert hashlib.sha256((BASE / entry['copy']).read_bytes()).hexdigest() == entry['sha256']
    cfg = json.loads((BASE / 'input/original_freeze.json').read_text())
    instances = json.loads((BASE / 'input/diagnostic_instances_selected5.json').read_text())
    originals = json.loads((BASE / 'input/original_instances.json').read_text())
    names = json.loads((BASE / 'input/original_failure_index.json').read_text())['both_failures_in_candidate_graph']
    assert [g for g in originals if g['geometry_id'] + '_R6' in names] == instances
    assert len(names) == len(instances) == 5
    assert cfg['rectangle'] == [0.,40.,0.,30.] and cfg['depot_pose'] == [20.,15.,0.]
    box = list(map(m.rational, cfg['rectangle']))
    radius = F(6)
    padding = m.BOUNDARY_TOL + m.LENGTH_GUARD
    cases, rows = [], []
    for g in instances:
        name = g['geometry_id'] + '_R6'
        assert name in names and g['poses'][0] == cfg['depot_pose'] and len(g['poses']) == 8
        certs = []
        depot = list(map(m.rational, g['poses'][0][:2]))
        for i, pose in enumerate(g['poses'][1:], 1):
            x, y, theta = map(m.rational, pose)
            sint, cost, _ = m.sin_cos_interval(theta)
            for fx, fy in PAIR_NAMES:
                nx, ix = FACES[fx]
                ny, iy = FACES[fy]
                assert nx[0]*ny[0] + nx[1]*ny[1] == 0
                hx = box[ix] if fx in ('right','top') else -box[ix]
                hy = box[iy] if fy in ('right','top') else -box[iy]
                dx = hx - nx[0]*x - nx[1]*y
                dy = hy - ny[0]*x - ny[1]*y
                target_x = nx[0]*(depot[0]-x) + nx[1]*(depot[1]-y)
                target_y = ny[0]*(depot[0]-x) + ny[1]*(depot[1]-y)
                for direction, sign in [('outgoing_to_depot',1),('incoming_from_depot_reversed',-1)]:
                    a = m.mul(m.add(m.mul(cost,nx[0]),m.mul(sint,nx[1])),sign)
                    b = m.mul(m.add(m.mul(cost,ny[0]),m.mul(sint,ny[1])),sign)
                    requirements = {
                        'A_first_a_zero': (bounds_shift(b,F(1),-1,radius), bounds_shift(a,F(1),1,radius)),
                        'B_first_b_zero': (bounds_shift(b,F(1),1,radius), bounds_shift(a,F(1),-1,radius))}
                    branches = {}
                    for branch, (bx,by) in requirements.items():
                        mx = (bx[0]-dx-padding,bx[1]-dx-padding)
                        my = (by[0]-dy-padding,by[1]-dy-padding)
                        violations = []
                        if mx[0]>0: violations.append(fx)
                        if my[0]>0: violations.append(fy)
                        branches[branch] = {
                            'required_x_displacement_m_interval':m.interval_json(bx),
                            'required_y_displacement_m_interval':m.interval_json(by),
                            'x_strict_deficit_m_interval':m.interval_json(mx),
                            'y_strict_deficit_m_interval':m.interval_json(my),
                            'x_strict_deficit_display':float(mx[0]),
                            'y_strict_deficit_display':float(my[0]),
                            'excluded_by_faces':violations,
                            'excluded':bool(violations)}
                    hypotheses = a[0]>m.PROJECTION_GUARD and b[0]>m.PROJECTION_GUARD and target_x < -m.LENGTH_GUARD and target_y < -m.LENGTH_GUARD
                    certified = hypotheses and all(v['excluded'] for v in branches.values())
                    row = {'instance_id':name,'service_pose_index':i,'pose':pose,'heading_rad':pose[2],
                           'R_m':6,'faces':[fx,fy],'normals':[list(nx),list(ny)],'direction':direction,
                           'a_interval':m.interval_json(a),'b_interval':m.interval_json(b),
                           'clearance_dx_m_exact':str(dx),'clearance_dy_m_exact':str(dy),
                           'clearance_dx_m_display':float(dx),'clearance_dy_m_display':float(dy),
                           'depot_pose':g['poses'][0],
                           'depot_x_displacement_m_exact':str(target_x),'depot_y_displacement_m_exact':str(target_y),
                           'both_initial_components_positive':a[0]>m.PROJECTION_GUARD and b[0]>m.PROJECTION_GUARD,
                           'depot_strictly_inward_both_faces':target_x < -m.LENGTH_GUARD and target_y < -m.LENGTH_GUARD,
                           'boundary_tolerance_m':str(m.BOUNDARY_TOL),'additional_guard_m':str(m.LENGTH_GUARD),
                           'branches':branches,
                           'status':'joint_certificate_pending_independent_review' if certified else 'not_proved_by_joint_test'}
                    rows.append(row)
                    if certified: certs.append(row)
        case = {'instance_id':name,'post_hoc':True,'checks':56,'certificate_count':len(certs),
                'status':'joint_certificate_pending_independent_review' if certs else 'not_proved_by_joint_test',
                'certificates':certs}
        cases.append(case)
        m.dump(OUT/'certificates'/(name+'.json'),case)
    assert len(rows)==280
    m.dump(OUT/'all_checks.json',rows)
    prior = json.loads((BASE/'summary.json').read_text())
    joint_ids=[r['instance_id'] for r in cases if r['certificates']]
    newly=[x for x in joint_ids if x not in prior['certified_model_infeasible_instances']]
    result={'status':'completed_pending_independent_review','post_hoc':True,
            'generated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'instances':5,'checks':280,'candidate_certificate_count':sum(r['certificate_count'] for r in cases),
            'joint_candidate_instance_ids':joint_ids,'newly_covered_beyond_single_face':newly,
            'single_face_only_instance_ids_unchanged':prior['certified_model_infeasible_instances'],
            'still_unproved_after_both_tests':[x for x in names if x not in set(joint_ids+prior['certified_model_infeasible_instances'])],
            'per_instance':[{k:v for k,v in r.items() if k!='certificates'} for r in cases],
            'input_manifest_sha256':hashlib.sha256((BASE/'input_manifest.json').read_bytes()).hexdigest(),
            'shared_exact_arithmetic_source_sha256':hashlib.sha256((BASE/'source/check_boundary.py').read_bytes()).hexdigest(),
            'single_face_files_modified':False,'searches':0,'grids':0,'tour_solves':0,'api_calls':0,
            'cpu_soft_limit_seconds':1,'cpu_hard_limit_seconds':2,
            'cpu_seconds':time.process_time()-c0,'wall_seconds':time.perf_counter()-t0}
    m.dump(OUT/'summary.json',result)
    print(json.dumps(result,indent=2))
    for case in cases:
        for r in case['certificates']:
            print(r['instance_id'],r['service_pose_index'],r['direction'],r['faces'],
                  {k:{'excluded_by_faces':v['excluded_by_faces'],'x_margin':v['x_strict_deficit_display'],'y_margin':v['y_strict_deficit_display']} for k,v in r['branches'].items()})


if __name__=='__main__':
    main()
