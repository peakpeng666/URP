# 相邻两面联合条件：事后核查

这是单面结果之后追加的独立子目录。原单面结果没有覆盖。

- 推导和限定：`PROOF_ZH.txt`
- 精确有理数脚本：`source/check_joint.py`
- 5例逐例候选证书：`certificates/`
- 280项逐面对/方向检查：`all_checks.json`
- 概要和资源：`summary.json`、`evidence/`
- 子目录文件SHA256：`SHA256SUMS.txt`

本脚本只读上层的定稿输入及 `source/check_boundary.py` 中的精确三角函数包围工具。输入manifest及共享工具SHA256记录在summary中。运行使用Python标准库；不安装依赖，不调用网络，不生成搜索网格，不求解tour。

`joint_certificate_pending_independent_review` 表示本次数学推导和有理区间运算已给出候选证书，仍需独立审查后采用连续不可行主张。`not_proved_by_joint_test` 不表示可行。A/B是析取必要条件：只有两支都被严格排除，结论才成立。

本目录不会修改上层单面证书。上层旧SHA256清单继续描述追加前的定稿文件；新增内容由本目录自己的清单覆盖。
