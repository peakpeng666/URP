# P102 容量异质与聚类配对扩展

先读 REPORT.zh.md；技术协议 PROTOCOL.zh.md；完整数据 results/raw.jsonl；冻结 FREEZE.json。

本目录是2026-10-07新实验。reference/及source_P102.zip是昨日恢复的原包，只作溯源，不计新样本。

## 复核已有结果

需要Python3.12，仅标准库，无安装、模型或网络调用。

    python -m unittest discover -s tests -v
    python validation/validate_results.py

复核会更新validation/full_validation.json的时钟，不会改正式raw或冻结文件。要保持交付字节，请在独立拷贝目录操作，并保留新校验输出为单独证据。

汇总复算：python src/summarize.py；只读raw，重写summary.json/results.csv/标准输出，不运行算法。

## 独立新运行

复制本目录到另一个全新工作目录，保留所有冻结输入与源码但不要复制results目录中的文件；创建空results目录后运行python supervisor.py，再python src/summarize.py。新结果不是本交付正式样本。入口遇已有raw.jsonl或run.log会拒绝覆盖，禁止在本交付目录删掉旧raw后冒称同次运行。

正式数据只运行过一次。source_P102.zip的旧结果未重跑。20单测、oracle和审计不计正式样本。

## SHA

SHA256SUMS及MANIFEST.json为作者交付集合。独审文件如果后来加入，由父线程另生成包级清单。__pycache__临时缓存不属于交付集合。
