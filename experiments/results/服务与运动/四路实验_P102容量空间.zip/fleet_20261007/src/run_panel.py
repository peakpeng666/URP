import sys,pathlib,json,hashlib,time,datetime,csv,traceback,resource,signal,os,statistics,itertools
ROOT=pathlib.Path(__file__).resolve().parents[1]
from solver import exact_all,greedy
from oracle import solve
from checker import check
ALG=['two_stage_lex','two_stage_best_tie','greedy']
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def timed(f,*a):
 c=time.process_time();w=time.perf_counter();r=f(*a);return r,{'cpu_s':time.process_time()-c,'wall_s':time.perf_counter()-w}
def run():
 resource.setrlimit(resource.RLIMIT_CPU,(160,165));signal.alarm(900)
 freeze=json.loads((ROOT/'FREEZE.json').read_text())
 for p,h in freeze['files'].items():assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h,p
 instances=json.loads((ROOT/'data/instances.json').read_text());raw=ROOT/'results/raw.jsonl'
 assert not raw.exists(),'Will not overwrite or replay formal results'
 start=utc();w0=time.perf_counter();c0=time.process_time();rows=[];fatal=None
 with raw.open('x') as f:
  for k,inst in enumerate(instances):
   rec={'id':inst['id'],'metadata':inst['metadata'],'started_utc':utc(),'ordinal':k}
   try:
    outputs,t_exact=timed(exact_all,inst);g,t_greedy=timed(greedy,inst);outputs['greedy']=g
    ref,t_oracle=timed(solve,inst)
    checks={name:check(inst,ans) for name,ans in outputs.items()};refcheck=check(inst,ref)
    j=outputs['joint_exact'];assert (j['status'],j['objective_total'])==(ref['status'],ref['objective_total']),'oracle_mismatch'
    assert ref['status']!='FEASIBLE' or refcheck['feasible'],'oracle_bad_route'
    for name,ans in outputs.items():
     assert ans['status']!='FEASIBLE' or checks[name]['feasible'],name+':invalid_full_route'
     assert not checks[name]['feasible'] or j['status']=='FEASIBLE',name+':false_infeasible'
     assert not checks[name]['feasible'] or ans['objective_total']>=j['objective_total'],name+':below_optimum'
    rec.update({'execution':'OK','outputs':outputs,'oracle':ref,'checks':checks,'oracle_check':refcheck,'timing':{'exact_all_shared':t_exact,'greedy':t_greedy,'oracle_validation':t_oracle}})
   except Exception as e:
    rec.update({'execution':'FAILED','error_type':type(e).__name__,'error':str(e),'traceback':traceback.format_exc()});fatal=rec['error']
   rec['finished_utc']=utc();f.write(json.dumps(rec,ensure_ascii=False)+'\n');f.flush();os.fsync(f.fileno());rows.append(rec)
   print(k,inst['id'],rec['execution'],rec.get('outputs',{}).get('joint_exact',{}).get('status'),flush=True)
   if fatal:break
 write(ROOT/'results/run_budget.json',{'started_utc':start,'finished_utc':utc(),'numeric_process_cpu_s':time.process_time()-c0,'numeric_wall_s':time.perf_counter()-w0,'limits_cpu_soft_hard_s':[160,165],'wall_alarm_s':900,'descendants_created':0,'planned_instances':len(instances),'recorded_instances':len(rows),'missing_ids':[i['id'] for i in instances[len(rows):]],'fatal':fatal,'model_api_calls':0,'paid_compute_purchases':0,'old_formal_runs_replayed':0,'new_formal_runs_replayed':0,'preparation_download_reporting_and_platform_cost':'not_exactly_observed'})
 return 1 if fatal else 0
if __name__=='__main__':sys.exit(run())
