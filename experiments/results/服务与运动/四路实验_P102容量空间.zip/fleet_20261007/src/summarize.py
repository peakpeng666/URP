"""Frozen read-only analysis of preserved formal rows. Never calls solvers."""
import pathlib,json,csv,itertools,statistics
ROOT=pathlib.Path(__file__).resolve().parents[1]
ALG=['two_stage_lex','two_stage_best_tie','greedy']
def summarize():
 rows=[json.loads(l) for l in (ROOT/'results/raw.jsonl').read_text().splitlines()];good=[r for r in rows if r['execution']=='OK'];flat=[];cells=[]
 for r in good:
  opt=r['outputs']['joint_exact'];refok=opt['status']=='FEASIBLE'
  for name,a in r['outputs'].items():
   ok=a['status']=='FEASIBLE';gap=(a['objective_total']/opt['objective_total']-1)*100 if ok and refok else None
   flat.append({'id':r['id'],**r['metadata'],'algorithm':name,'status':a['status'],'oracle_feasible':refok,'objective':a['objective_total'] if ok else None,'partial_objective':a['objective_total'] if not ok else None,'optimum':opt['objective_total'],'gap_percent':gap,'route_count':len(a['routes'])})
 for h,geometry in itertools.product([0,2,4],['four_quadrants','two_clusters']):
  rr=[r for r in good if r['metadata']['capacity_h']==h and r['metadata']['geometry']==geometry]
  for name in ['joint_exact']+ALG:
   ff=[x for x in flat if x['capacity_h']==h and x['geometry']==geometry and x['algorithm']==name];gaps=[x['gap_percent'] for x in ff if x['gap_percent'] is not None];st={}
   for x in ff:st[x['status']]=st.get(x['status'],0)+1
   cells.append({'capacity_h':h,'geometry':geometry,'algorithm':name,'all_instances':len(rr),'exact_feasible':sum(r['outputs']['joint_exact']['status']=='FEASIBLE' for r in rr),'complete':len(gaps),'statuses':st,'gap_n':len(gaps),'gap_mean_pct':statistics.mean(gaps) if gaps else None,'gap_max_pct':max(gaps) if gaps else None})
 pair=[]
 for a,b in itertools.combinations(ALG,2):
  win=tie=loss=bothfail=0;d=[]
  for r in good:
   if r['outputs']['joint_exact']['status']!='FEASIBLE':continue
   aa,bb=r['outputs'][a],r['outputs'][b];ao,bo=aa['status']=='FEASIBLE',bb['status']=='FEASIBLE'
   if not ao and not bo:bothfail+=1;continue
   if ao and bo:
    v=aa['objective_total']-bb['objective_total'];d.append(v)
   else:v=-1 if ao else 1
   win+=v<0;tie+=v==0;loss+=v>0
  pair.append({'a':a,'b':b,'a_wins':win,'ties':tie,'a_losses':loss,'both_failed':bothfail,'both_complete_n':len(d),'a_minus_b_cost_mean_on_both_complete':statistics.mean(d) if d else None})
 transitions=[];bykey={(r['metadata']['seed'],r['metadata']['capacity_h'],r['metadata']['geometry']):r for r in good}
 comparisons=[('clustering',h,'four_quadrants',h,'two_clusters') for h in [0,2,4]]+[(f'h{h}_vs_h0',0,g,h,g) for g in ['four_quadrants','two_clusters'] for h in [2,4]]
 for label,h0,g0,h1,g1 in comparisons:
  for a in ['joint_exact']+ALG:
   cc={'FF':0,'FT':0,'TF':0,'TT':0}
   for seed in range(771001,771025):
    if (seed,h0,g0) not in bykey or (seed,h1,g1) not in bykey:continue
    x=bykey[seed,h0,g0]['outputs'][a]['status']=='FEASIBLE';y=bykey[seed,h1,g1]['outputs'][a]['status']=='FEASIBLE';cc[('T' if x else 'F')+('T' if y else 'F')]+=1
   transitions.append({'contrast':label,'from_h':h0,'from_geometry':g0,'to_h':h1,'to_geometry':g1,'algorithm':a,**cc})
 summary={'recorded_instances':len(rows),'successful_execution_records':len(good),'failed_execution_records':len(rows)-len(good),'base_blocks':len(set(r['metadata']['seed'] for r in good)),'cells':cells,'pairwise':pair,'paired_feasibility_transitions':transitions,'timing_sums':{k:{t:sum(r['timing'][k][t] for r in good) for t in ['cpu_s','wall_s']} for k in ['exact_all_shared','greedy','oracle_validation']}}
 (ROOT/'results/summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
 with (ROOT/'results/results.csv').open('w') as f:
  w=csv.DictWriter(f,fieldnames=list(flat[0]));w.writeheader();w.writerows(flat)
 print(json.dumps(summary,ensure_ascii=False,indent=2))
if __name__=='__main__':summarize()
