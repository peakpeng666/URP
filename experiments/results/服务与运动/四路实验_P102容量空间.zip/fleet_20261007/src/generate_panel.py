"""New paired P102 panel; no optimizer runs or output-dependent rejection."""
import json,random,pathlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
SEEDS=list(range(771001,771025))
def generate():
 out=[];signs=[(1,1),(-1,1),(-1,-1),(1,-1)]
 for block,seed in enumerate(SEEDS):
  rng=random.Random(seed);rot=rng.randrange(4)
  latent=[{'x':rng.randint(3,12),'y':rng.randint(3,12),'q':rng.randint(1,3)} for _ in range(8)]
  for h in [0,2,4]:
   for geometry in ['four_quadrants','two_clusters']:
    tasks=[]
    for i,l in enumerate(latent):
     j=i//2;op=i%2
     # Each operation spans all four quadrants, or two opposite quadrants.
     k=j if geometry=='four_quadrants' else (0 if j<2 else 2)
     sx,sy=signs[(rot+k)%4]
     tasks.append({'id':i+1,'xy':[sx*l['x'],sy*l['y']],'operation':op,'demand':l['q']})
    pair=[5-h,5+h] if block%2==0 else [5+h,5-h]
    out.append({'id':f'F{seed}_h{h}_{geometry}','family':'new_paired_panel','metadata':{'seed':seed,'block':block,'capacity_h':h,'capacity_cv':h/5,'geometry':geometry,'large_capacity_orientation':'odd_implement' if block%2==0 else 'even_implement','rotation':rot},'depot':[0,0],'tasks':tasks,'implements':[{'id':i,'operation':i//2,'capacity':pair[i%2]} for i in range(4)],'vehicles':[{'id':i,'distance_limit':d,'cost_per_distance':c,'compatible_implements':cm} for i,(d,c,cm) in enumerate(zip([56,76,108],[1,2,3],[[0,2],[1,3],[0,1,2,3]]))]})
 assert len(out)==144
 return out
if __name__=='__main__':
 (ROOT/'data/instances.json').write_text(json.dumps(generate(),ensure_ascii=False,indent=2)+'\n')
