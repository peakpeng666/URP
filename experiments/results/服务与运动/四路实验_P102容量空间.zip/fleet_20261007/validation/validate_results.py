"""Post-run author verification; direct route recomputation, no solver imports."""
import pathlib,json,hashlib,collections,statistics,time,datetime,csv,sys
R=pathlib.Path(__file__).resolve().parents[1]
c0=time.process_time();w0=time.perf_counter();counts=collections.Counter()
def ck(c,label):
 counts[label]+=1
 if not c:raise AssertionError(label)
freeze=json.loads((R/'FREEZE.json').read_text())
for f,h in freeze['files'].items():ck(hashlib.sha256((R/f).read_bytes()).hexdigest()==h,'frozen_file_hash')
I=json.loads((R/'data/instances.json').read_text());raw=[json.loads(x) for x in (R/'results/raw.jsonl').read_text().splitlines()];ck(len(I)==len(raw)==144,'panel_count');ck(len(set(i['id'] for i in I))==144,'unique_ids');ck([i['id'] for i in I]==[r['id'] for r in raw],'order')
ck(freeze['frozen_utc']<raw[0]['started_utc'],'freeze_precedes_formal')
blocks=collections.defaultdict(list)
for i in I:blocks[i['metadata']['seed']].append(i)
for seed,group in blocks.items():
 ck(len(group)==6,'six_paired_variants')
 ck({(i['metadata']['capacity_h'],i['metadata']['geometry']) for i in group}=={(h,g) for h in [0,2,4] for g in ['four_quadrants','two_clusters']},'full_factorial')
 base=group[0]
 for i in group:
  ck(i['vehicles']==base['vehicles'],'vehicle_and_compatibility_matched')
  for a,b in zip(i['tasks'],base['tasks']):
   ck((a['id'],a['operation'],a['demand'])==(b['id'],b['operation'],b['demand']),'task_demand_operation_matched')
   ck(list(map(abs,a['xy']))==list(map(abs,b['xy'])),'absolute_xy_and_radius_matched')
  for op in [0,1]:ck(sum(m['capacity'] for m in i['implements'] if m['operation']==op)==10,'equal_total_capacity')

def direct(i,a,complete):
 seen=collections.Counter();used=set();vehicle_dist=[0]*3;objective=0
 for route in a['routes']:
  v=route['vehicle_id'];m=route['implement_id'];nodes=route['nodes'];ck(type(v)is int and 0<=v<3,'vehicle_id');ck(type(m)is int and 0<=m<4,'implement_id');ck(m not in used,'no_tool_reuse');used.add(m);ck(m in i['vehicles'][v]['compatible_implements'],'compatibility');ck(nodes[0]==nodes[-1]==0 and 0 not in nodes[1:-1],'closed_depot_route');load=0;xy=[i['depot']]
  for n in nodes[1:-1]:
   ck(type(n)is int and 1<=n<=8,'task_id');t=i['tasks'][n-1];ck(t['operation']==i['implements'][m]['operation'],'operation');seen[n]+=1;load+=t['demand'];xy.append(t['xy'])
  xy.append(i['depot']);d=sum(abs(p[0]-q[0])+abs(p[1]-q[1]) for p,q in zip(xy,xy[1:]));vehicle_dist[v]+=d;objective+=d*i['vehicles'][v]['cost_per_distance'];ck(load<=i['implements'][m]['capacity'],'capacity')
 ck(all(n==1 for n in seen.values()),'no_duplicate_tasks');ck(not complete or set(seen)==set(range(1,9)),'full_coverage_if_complete');ck(all(d<=v['distance_limit'] for d,v in zip(vehicle_dist,i['vehicles'])),'cumulative_distance')
 if a['objective_total'] is not None:ck(objective==a['objective_total'],'objective_recompute')
 return objective
for i,r in zip(I,raw):
 ck(r['execution']=='OK','execution_ok');ck(r['metadata']==i['metadata'],'metadata');j=r['outputs']['joint_exact'];o=r['oracle'];ck((j['status'],j['objective_total'])==(o['status'],o['objective_total']),'dual_exact_agreement');direct(i,o,o['status']=='FEASIBLE')
 for a in r['outputs'].values():direct(i,a,a['status']=='FEASIBLE')
 ck(len(r['outputs']['greedy']['all_start_outputs'])==12,'twelve_greedy_starts_preserved')
 for a in r['outputs']['greedy']['all_start_outputs']:direct(i,a,a['status']=='FEASIBLE')
solved=[r for r in raw if r['outputs']['joint_exact']['status']=='FEASIBLE'];ck(len(solved)==109,'global_feasible_count')
s=json.loads((R/'results/summary.json').read_text())
for c in s['cells']:
 subset=[r for r in raw if r['metadata']['capacity_h']==c['capacity_h'] and r['metadata']['geometry']==c['geometry']];a=c['algorithm'];status=collections.Counter(r['outputs'][a]['status'] for r in subset);ck(dict(status)==c['statuses'],'summary_statuses');z=[r['outputs'][a]['objective_total']/r['outputs']['joint_exact']['objective_total']*100-100 for r in subset if r['outputs'][a]['status']=='FEASIBLE'];ck(len(z)==c['complete']==c['gap_n'],'summary_denominator');ck(not z or abs(statistics.mean(z)-c['gap_mean_pct'])<1e-10,'summary_gap_mean');ck(not z or abs(max(z)-c['gap_max_pct'])<1e-10,'summary_gap_max')
receipt=json.loads((R/'results/supervisor_receipt.json').read_text());ck(receipt['exit_code']==0,'formal_exit');ck(receipt['numeric_child_tree_total_cpu_s']+receipt['supervisor_cpu_s']<180,'cpu_budget');ck(receipt['supervised_wall_s']<1200,'wall_budget');csvrows=list(csv.DictReader((R/'results/results.csv').open()));ck(len(csvrows)==576,'csv_row_count')
out={'status':'PASS','role':'post_run_author_validation_not_independent_review_or_formal_samples','finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks_by_type':dict(counts),'total_assertions':sum(counts.values()),'formal_instances':144,'formal_heuristic_outputs':432,'formal_joint_references':144,'oracle_validation_calls':144,'greedy_start_outputs_checked':1728,'global_feasible':109,'global_infeasible':35,'validation_cpu_s':time.process_time()-c0,'validation_wall_s':time.perf_counter()-w0}
(R/'validation/full_validation.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
