import json,random,math,pathlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
def case(name, tasks, caps=(8,8,8,8), D=(80,100,120), C=(1,2,3), compat=None, family='edge', **meta):
    tools=[{'id':i,'operation':i//2,'capacity':caps[i]} for i in range(4)]
    if compat is None: compat=[list(range(4)) for _ in range(3)]
    return {'id':name,'family':family,'metadata':meta,'depot':[0,0],'tasks':[{'id':i+1,'xy':[x,y],'operation':op,'demand':q} for i,(x,y,op,q) in enumerate(tasks)],'implements':tools,'vehicles':[{'id':v,'distance_limit':D[v],'cost_per_distance':C[v],'compatible_implements':compat[v]} for v in range(3)]}
def generate():
    out=[]
    for n in (6,8):
      for cap in ('tight','loose'):
       for compat in ('dense','sparse'):
        for seed in (101,202):
         r=random.Random(seed+1000*n)
         tasks=[]
         for i in range(n):
          xy=(r.randint(-12,12),r.randint(-12,12))
          if xy==(0,0): xy=(1,0)
          tasks.append((*xy,i%2,r.randint(1,4)))
         totals=[sum(t[3] for t in tasks if t[2]==o) for o in (0,1)]
         caps=[]
         for total in totals:
          q=math.ceil(total/2) if cap=='tight' else total
          caps.extend([q,q+1])
         cm=[list(range(4)) for _ in range(3)] if compat=='dense' else [[0,2],[1,3],[0,1,2,3]]
         out.append(case(f'R{n}_{cap}_{compat}_{seed}',tasks,caps,(65,90,115),(1,2,3),cm,'random',seed=seed,capacity_factor=cap,compatibility_factor=compat,n=n))
    out += [
      case('E01_zero_demand',[(2,0,0,0),(3,0,0,0),(0,2,1,0),(0,3,1,0)],(0,0,0,0),D=(12,12,12)),
      case('E02_total_capacity_impossible',[(2,1,0,5),(3,1,0,5),(1,2,1,1),(1,3,1,1)],(4,4,4,4)),
      case('E03_no_compatible_vehicle',[(2,1,0,1),(3,1,0,1),(1,2,1,1),(1,3,1,1)],compat=[[0,1],[0,1],[0,1]]),
      case('E04_autonomy_impossible',[(10,0,0,1),(0,10,1,1)],D=(3,3,3)),
      case('E05_stage_one_split_trap',[(10,1,0,1),(10,-1,0,1),(0,1,1,1),(0,2,1,1)],(4,4,4,4),(22,22,10),(1,2,3),[[0,1],[0,1],[2,3]]),
      case('E06_cheap_vehicle_budget', [(-5,1,0,1),(-5,-1,0,1),(5,1,0,1),(5,-1,0,1),(0,1,1,1),(0,2,1,1)],(6,6,6,6),(24,100,100)),
      case('E07_packing_impossible',[(1,0,0,3),(2,0,0,3),(3,0,0,3),(0,1,1,1)],(5,5,4,4)),
      case('E08_colocated_boundary',[(4,0,0,2),(4,0,1,3),(4,0,0,0),(0,2,1,1)],(2,3,3,4),(8,12,20),(1,3,2),[[0],[1,2],[3]])
    ]
    assert len(out)==24
    return out
if __name__=='__main__':
 p=ROOT/'data/instances.json'; p.write_text(json.dumps(generate(),ensure_ascii=False,indent=2)+'\n')
 print(f'{len(generate())} frozen cases -> {p}')
