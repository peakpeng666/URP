"""Evaluate pre-produced route JSON. This does not execute arbitrary candidate code."""
import argparse,json,pathlib,hashlib
from checker import check
ROOT=pathlib.Path(__file__).resolve().parents[1]
def main():
 p=argparse.ArgumentParser();p.add_argument('solutions',help='JSON object mapping frozen instance IDs to answer objects');p.add_argument('--output',required=True);a=p.parse_args()
 instances=json.loads((ROOT/'data/instances.json').read_text());supplied=json.loads(pathlib.Path(a.solutions).read_text());reference={r['instance_id']:r['answers']['independent_oracle'] for r in json.loads((ROOT/'results/raw_runs.json').read_text())}
 if not isinstance(supplied,dict):raise ValueError('solutions must be an object keyed by instance ID')
 expected={i['id'] for i in instances};unknown=sorted(set(supplied)-expected)
 out={'unknown_instance_ids':unknown,'scoring_policy':'Report coverage first. Only checker-feasible outputs on oracle-feasible instances get cost gaps. Claims of infeasibility by candidates are not proofs.','results':[]}
 for i in instances:
  ans=supplied.get(i['id']);checked=check(i,ans);opt=reference[i['id']]['objective_total'];gap=(checked['recomputed_objective']/opt-1)*100 if checked['feasible'] and opt is not None and opt>0 else None
  out['results'].append({'instance_id':i['id'],'submitted':i['id'] in supplied,'oracle_status':reference[i['id']]['status'],'check':checked,'gap_percent_if_valid':gap})
 out['feasible_outputs']=sum(r['check']['feasible'] for r in out['results']);out['input_solution_sha256']=hashlib.sha256(pathlib.Path(a.solutions).read_bytes()).hexdigest()
 pathlib.Path(a.output).write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'feasible_outputs':out['feasible_outputs'],'unknown_instance_ids':unknown}))
if __name__=='__main__':main()
