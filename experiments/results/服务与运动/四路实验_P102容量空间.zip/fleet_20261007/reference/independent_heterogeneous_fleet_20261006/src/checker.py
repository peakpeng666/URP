"""Independent fail-closed route contract. Imports no solver/oracle code."""
import json,sys

def integer(x,minimum=0): return type(x) is int and x>=minimum

def check(inst, answer):
    errors=[]
    try:
        tasks={t['id']:t for t in inst['tasks']}; implements={m['id']:m for m in inst['implements']}; vehicles={v['id']:v for v in inst['vehicles']}
        if not isinstance(answer,dict): return {'feasible':False,'errors':['answer_not_object']}
        routes=answer.get('routes')
        if not isinstance(routes,list): return {'feasible':False,'errors':['routes_not_list']}
        visit={i:0 for i in tasks}; used_tools=set(); distances={v:0 for v in vehicles}; details=[]
        for ri,r in enumerate(routes):
            tag=f'route_{ri}'
            if not isinstance(r,dict): errors.append(tag+':not_object'); continue
            vi=r.get('vehicle_id'); mi=r.get('implement_id'); nodes=r.get('nodes')
            if not integer(vi) or vi not in vehicles: errors.append(tag+':unknown_vehicle'); continue
            if not integer(mi) or mi not in implements: errors.append(tag+':unknown_implement'); continue
            if mi in used_tools: errors.append(tag+':implement_reused')
            used_tools.add(mi)
            m=implements[mi]; v=vehicles[vi]
            if mi not in v['compatible_implements']: errors.append(tag+':vehicle_implement_incompatible')
            if not isinstance(nodes,list) or len(nodes)<3 or any(not integer(i) for i in nodes): errors.append(tag+':invalid_nodes'); continue
            if nodes[0]!=0 or nodes[-1]!=0 or 0 in nodes[1:-1]: errors.append(tag+':depot_contract')
            if any(i not in tasks for i in nodes[1:-1]): errors.append(tag+':unknown_task'); continue
            if nodes[0]!=0 or nodes[-1]!=0: continue
            load=0
            for i in nodes[1:-1]:
                t=tasks[i];visit[i]+=1;load+=t['demand']
                if t['operation']!=m['operation']: errors.append(tag+':task_operation_incompatible')
            if load>m['capacity']: errors.append(tag+':capacity_exceeded')
            xy={0:inst['depot']};xy.update({i:t['xy'] for i,t in tasks.items()})
            d=sum(abs(xy[a][0]-xy[b][0])+abs(xy[a][1]-xy[b][1]) for a,b in zip(nodes,nodes[1:]))
            distances[vi]+=d
            details.append({'route_index':ri,'vehicle_id':vi,'implement_id':mi,'load':load,'capacity':m['capacity'],'distance':d,'cost':d*v['cost_per_distance']})
        for i,n in visit.items():
            if n!=1: errors.append(f'task_{i}:visit_count_{n}')
        for vi,d in distances.items():
            if d>vehicles[vi]['distance_limit']: errors.append(f'vehicle_{vi}:distance_limit_exceeded')
        objective=sum(d*vehicles[v]['cost_per_distance'] for v,d in distances.items())
        if not integer(answer.get('objective_total')) or answer['objective_total']!=objective: errors.append('claimed_objective_mismatch')
        if answer.get('status')!='FEASIBLE': errors.append('status_not_feasible')
        return {'feasible':not errors,'errors':sorted(set(errors)),'recomputed_objective':objective,'vehicle_distances':distances,'route_details':details}
    except (KeyError,TypeError,ValueError,IndexError) as e:
        return {'feasible':False,'errors':['malformed_input:'+type(e).__name__]}

if __name__=='__main__':
    instance=json.load(open(sys.argv[1]));answer=json.load(open(sys.argv[2]));res=check(instance,answer)
    print(json.dumps(res,ensure_ascii=False,indent=2));sys.exit(0 if res['feasible'] else 1)
