from pathlib import Path
import re
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
ROOT=Path(__file__).resolve().parents[1]
doc=Document();sec=doc.sections[0];sec.top_margin=Inches(.62);sec.bottom_margin=Inches(.62);sec.left_margin=Inches(.62);sec.right_margin=Inches(.62)
for name in ['Normal','Title','Heading 1','Heading 2']:
 s=doc.styles[name];s.font.name='Noto Sans CJK SC';s.element.rPr.rFonts.set(qn('w:eastAsia'),'Noto Sans CJK SC')

for border in doc.styles['Title'].element.xpath('.//w:pBdr'): border.getparent().remove(border)
normal=doc.styles['Normal'];normal.font.size=Pt(10);normal.paragraph_format.line_spacing=1.15;normal.paragraph_format.space_after=Pt(6)
doc.styles['Title'].font.size=Pt(23);doc.styles['Title'].font.color.rgb=RGBColor.from_string('0F4260');doc.styles['Heading 1'].font.size=Pt(14);doc.styles['Heading 1'].font.color.rgb=RGBColor.from_string('0F4260');doc.styles['Heading 2'].font.size=Pt(11.5)
lines=(ROOT/'reports/REPORT.zh.md').read_text().splitlines();j=0
while j<len(lines):
 line=lines[j].strip();j+=1
 if not line:continue
 if line.startswith('|'):
  tablelines=[line]
  while j<len(lines) and lines[j].strip().startswith('|'):tablelines.append(lines[j].strip());j+=1
  tablelines=[s for s in tablelines if not re.match(r'^\|[\s:|-]+\|$',s)]
  rows=[[x.strip() for x in s.strip('|').split('|')] for s in tablelines]
  tab=doc.add_table(rows=1,cols=len(rows[0]));tab.style='Light Shading Accent 1'
  for k,x in enumerate(rows[0]):tab.rows[0].cells[k].text=x
  for row in rows[1:]:
   cells=tab.add_row().cells
   for k,x in enumerate(row):cells[k].text=x
  for row in tab.rows:
   for cell in row.cells:
    for p in cell.paragraphs:
     p.paragraph_format.space_after=Pt(4)
     for r in p.runs:r.font.size=Pt(8.5)
  trPr=tab.rows[0]._tr.get_or_add_trPr();repeat=OxmlElement('w:tblHeader');trPr.append(repeat)
  doc.add_paragraph();continue
 if line.startswith('!['):
  img=re.search(r'\]\(([^)]+)\)',line).group(1);doc.add_picture(str((ROOT/'reports'/img).resolve()),width=Inches(7.0));continue
 if line.startswith('# '):doc.add_heading(line[2:],0);continue
 if line.startswith('## '):doc.add_heading(line[3:],1);continue
 if line.startswith('### '):doc.add_heading(line[4:],2);continue
 # Keep URLs legible as text in this portable report; source card has exact links too.
 line=re.sub(r'\[([^\]]+)\]\(([^)]+)\)',r'\1（\2）',line)
 p=doc.add_paragraph(line)
 if re.match(r'^\d+\. ',line):p.paragraph_format.left_indent=Inches(.12)
doc.core_properties.title='P102有限异构车具共同仓库机制实验';doc.core_properties.subject='独立路线校验与精确oracle复核';doc.core_properties.author='研究助理'
doc.save(ROOT/'reports/REPORT.zh.docx')
print('saved report')
