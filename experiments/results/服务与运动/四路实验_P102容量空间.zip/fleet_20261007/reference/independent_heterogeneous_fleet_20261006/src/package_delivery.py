import pathlib,hashlib,json,zipfile,datetime
ROOT=pathlib.Path(__file__).resolve().parents[1]
def sha(b):return hashlib.sha256(b).hexdigest()
for f in ['FREEZE_RECEIPT.json','IMPLEMENTATION_FREEZE.json']:
 rec=json.loads((ROOT/f).read_text())
 assert all(sha((ROOT/p).read_bytes())==h for p,h in rec['files'].items()),f
files=sorted(p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and 'rendered' not in p.parts and p.name not in ['MANIFEST.json','DELIVERY_RECEIPT.json'])
manifest={'root':ROOT.name,'files':[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in files]}
(ROOT/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
files.append(ROOT/'MANIFEST.json');files.sort()
archive=ROOT.parent/(ROOT.name+'_COMPLETED.zip')
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files:
  info=zipfile.ZipInfo(ROOT.name+'/'+str(p.relative_to(ROOT)),date_time=(2026,10,6,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o644<<16;z.writestr(info,p.read_bytes())
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for f in manifest['files']:assert sha(z.read(ROOT.name+'/'+f['path']))==f['sha256']
receipt={'archive':str(archive),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive.read_bytes()),'members':len(files),'all_file_hashes_verified':True,'frozen_inputs_and_scoring_source_unchanged':True,'zip_crc_verified':True,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(ROOT/'DELIVERY_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
