import time
from generate_data import case
from solver import exact_all
from oracle import solve
from checker import check
# Non-scoring fixture; not part of the frozen 24.
i=case('NONSCORING_SMOKE',[(1,3,0,1),(2,2,0,2),(3,1,1,1),(1,1,1,2),(2,3,0,1)])
t=time.perf_counter();a=exact_all(i)['joint_exact'];b=solve(i)
assert a['objective_total']==b['objective_total']
assert check(i,a)['feasible'] and check(i,b)['feasible']
print({'smoke_objective':a['objective_total'],'wall_seconds':time.perf_counter()-t,'oracle_budget':b['diagnostics']})
