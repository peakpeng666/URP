"""Independent exact oracle: task-to-tool Cartesian enumeration + permutations.
No solver or checker import. Cache is local and never receives solver results.
"""
from itertools import product,permutations
from functools import lru_cache

def solve(instance):
    tasks=instance['tasks'];tools=instance['implements'];vehicles=instance['vehicles'];n=len(tasks)
    positions={0:tuple(instance['depot']),**{t['id']:tuple(t['xy']) for t in tasks}}
    def dist(i,j):
        a,b=positions[i],positions[j]
        return abs(a[0]-b[0])+abs(a[1]-b[1])
    permutations_seen=0
    @lru_cache(None)
    def shortest(ids):
        nonlocal permutations_seen
        if not ids:return 0,()
        best=None
        for p in permutations(ids):
            permutations_seen+=1
            walked=(0,)+p+(0,)
            value=sum(dist(walked[k],walked[k+1]) for k in range(len(walked)-1))
            if best is None or (value,p)<best: best=(value,p)
        return best
    compatible_tools=[[j for j,m in enumerate(tools) if m['operation']==t['operation']] for t in tasks]
    best=None;task_assignments=0;vehicle_assignments=0
    for chosen in product(*compatible_tools):
        task_assignments+=1
        bundles=[[] for _ in tools];amounts=[0]*len(tools)
        for t,mi in zip(tasks,chosen):bundles[mi].append(t['id']);amounts[mi]+=t['demand']
        if any(q>m['capacity'] for q,m in zip(amounts,tools)):continue
        used=[i for i,b in enumerate(bundles) if b]
        trips={i:shortest(tuple(bundles[i])) for i in used}
        vehicle_options=[[j for j,v in enumerate(vehicles) if tools[i]['id'] in v['compatible_implements']] for i in used]
        for allocated in product(*vehicle_options):
            vehicle_assignments+=1
            mileage=[0]*len(vehicles)
            for i,v in zip(used,allocated):mileage[v]+=trips[i][0]
            if any(k>v['distance_limit'] for k,v in zip(mileage,vehicles)):continue
            value=sum(k*v['cost_per_distance'] for k,v in zip(mileage,vehicles))
            if best is None or value<best['objective_total']:
                best={'status':'FEASIBLE','objective_total':value,'routes':[{'vehicle_id':vehicles[v]['id'],'implement_id':tools[i]['id'],'nodes':[0,*trips[i][1],0]} for i,v in zip(used,allocated)]}
    if best is None:best={'status':'INFEASIBLE_PROVEN','objective_total':None,'routes':[]}
    best['diagnostics']={'task_assignments':task_assignments,'vehicle_assignments':vehicle_assignments,'permutations_examined':permutations_seen,'permutation_cache':shortest.cache_info()._asdict()}
    return best
