import json,pathlib,time,hashlib,sys,platform,resource,csv,datetime,os
from solver import exact_all,greedy
from oracle import solve
from checker import check
ROOT=pathlib.Path(__file__).resolve().parents[1]
def run(output):
    output.mkdir(parents=True,exist_ok=True)
    freeze=json.loads((ROOT/'FREEZE_RECEIPT.json').read_text())
    assert all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h for p,h in freeze['files'].items()),'frozen file changed'
    instances=json.loads((ROOT/'data/instances.json').read_text());rows=[];raw=[]
    t0=time.perf_counter();cpu0=time.process_time()
    for inst in instances:
        t=time.perf_counter();c=time.process_time();exact=exact_all(inst);exact_wall=time.perf_counter()-t;exact_cpu=time.process_time()-c
        t=time.perf_counter();c=time.process_time();oracle=solve(inst);oracle_wall=time.perf_counter()-t;oracle_cpu=time.process_time()-c
        assert exact['joint_exact']['status']==oracle['status'],inst['id']
        assert exact['joint_exact']['objective_total']==oracle['objective_total'],inst['id']
        t=time.perf_counter();c=time.process_time();g=greedy(inst);greedy_wall=time.perf_counter()-t;greedy_cpu=time.process_time()-c
        answers={**exact,'greedy_multistart':g,'independent_oracle':oracle}
        diagnostic_t=time.perf_counter();dc=time.process_time()
        for label,opts in [('omit_vehicle_compatibility',{'drop_compat':True}),('omit_implement_capacity',{'drop_capacity':True})]:answers[label]=exact_all(inst,**opts)['joint_exact']
        diagnostic_wall=time.perf_counter()-diagnostic_t;diagnostic_cpu=time.process_time()-dc
        checks={k:check(inst,a) for k,a in answers.items()}
        starts=[check(inst,a) for a in g['all_start_outputs']]
        for k in ['joint_exact','two_stage_lex','two_stage_best_tie','greedy_multistart','independent_oracle']:
            if answers[k]['status']=='FEASIBLE':assert checks[k]['feasible'],(inst['id'],k,checks[k])
        assert all(ch['feasible']==(ans['status']=='FEASIBLE') for ch,ans in zip(starts,g['all_start_outputs']))
        if oracle['status']=='FEASIBLE':assert checks['independent_oracle']['feasible']
        opt=oracle['objective_total']
        for method,ans in answers.items():
            diagnostic=method.startswith('omit_'); valid=checks[method]['feasible']
            gap=(ans['objective_total']/opt-1)*100 if valid and opt is not None and opt>0 and not diagnostic else None
            assert gap is None or gap>=-1e-10
            rows.append({'instance_id':inst['id'],'family':inst['family'],'method':method,'status':ans['status'],'checker_feasible':valid,'oracle_status':oracle['status'],'objective':ans['objective_total'],'oracle_objective':opt,'gap_percent':gap,'diagnostic_only':diagnostic,'errors':'|'.join(checks[method]['errors'])})
        raw.append({'instance_id':inst['id'],'answers':answers,'independent_checks':checks,'greedy_start_checks':starts,'budget':{'exact_three_methods_wall_seconds':exact_wall,'exact_three_methods_cpu_seconds':exact_cpu,'oracle_wall_seconds':oracle_wall,'oracle_cpu_seconds':oracle_cpu,'greedy_wall_seconds':greedy_wall,'greedy_cpu_seconds':greedy_cpu,'diagnostics_wall_seconds':diagnostic_wall,'diagnostics_cpu_seconds':diagnostic_cpu}})
        print(inst['id'],oracle['status'],opt,'greedy',g['objective_total'],g['status'],'stage',answers['two_stage_best_tie']['status'],flush=True)
    summary={'instances':len(instances),'random_instances':sum(i['family']=='random' for i in instances),'oracle_feasible':sum(r['answers']['independent_oracle']['status']=='FEASIBLE' for r in raw),'oracle_infeasible':sum(r['answers']['independent_oracle']['status']=='INFEASIBLE_PROVEN' for r in raw),'oracle_agreement_all':True,'methods':{},'families':{},'diagnostics':{}}
    for family in ['all','random','edge']:
        section={}
        for method in ['joint_exact','two_stage_lex','two_stage_best_tie','greedy_multistart']:
            rr=[r for r in rows if r['method']==method and (family=='all' or r['family']==family)]
            feasible=[r for r in rr if r['oracle_status']=='FEASIBLE'];valid=[r for r in feasible if r['checker_feasible']]
            gaps=[r['gap_percent'] for r in valid]
            section[method]={'instances':len(rr),'globally_feasible':len(feasible),'valid_outputs_on_feasible':len(valid),'failures_on_feasible':len(feasible)-len(valid),'mean_gap_on_success_percent':sum(gaps)/len(gaps) if gaps else None,'max_gap_on_success_percent':max(gaps) if gaps else None,'optimal_count_on_success':sum(abs(g)<1e-10 for g in gaps),'success_instance_ids':[r['instance_id'] for r in valid],'failure_instance_ids':[r['instance_id'] for r in feasible if not r['checker_feasible']]}
        summary['families'][family]=section
    summary['methods']=summary['families']['all']
    for method in ['omit_vehicle_compatibility','omit_implement_capacity']:
        rr=[r for r in rows if r['method']==method]
        summary['diagnostics'][method]={'raw_feasible_claims':sum(r['status']=='FEASIBLE' for r in rr),'checker_rejected_claims':sum(r['status']=='FEASIBLE' and not r['checker_feasible'] for r in rr),'false_feasibility_on_globally_infeasible':sum(r['status']=='FEASIBLE' and r['oracle_status']!='FEASIBLE' for r in rr),'not_ranked':True}
    (output/'raw_runs.json').write_text(json.dumps(raw,ensure_ascii=False,indent=2)+'\n')
    (output/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
    with (output/'results.csv').open('w') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    budget={'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'wall_seconds':time.perf_counter()-t0,'cpu_seconds':time.process_time()-cpu0,'max_rss_kib_linux':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'python':sys.version,'platform':platform.platform(),'llm_calls':0,'external_paid_calls':0,'sequential_processes':1,'threads_requested':1,'oracle_independent_no_imports_from_solver':True,'exact_evaluation_counts':{k:sum(r['answers']['independent_oracle']['diagnostics'][k] for r in raw) for k in ['task_assignments','vehicle_assignments','permutations_examined']},'timing_note':'started_utc records completion of run before budget writing; wall/cpu timers include raw validation and serialization. Exact three methods share precomputation; do not treat per-method exact times as independent.'}
    (output/'budget.json').write_text(json.dumps(budget,indent=2)+'\n')
    print(json.dumps(summary,ensure_ascii=False,indent=2));print('budget',budget)
if __name__=='__main__':run(pathlib.Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'results')
