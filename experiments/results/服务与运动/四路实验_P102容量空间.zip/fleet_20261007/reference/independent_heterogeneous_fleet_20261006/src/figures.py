import os
os.environ.setdefault('MPLCONFIGDIR','/tmp/mpl-heterogeneous-fleet')
import json,pathlib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
from matplotlib.patches import Patch
ROOT=pathlib.Path(__file__).resolve().parents[1]
font=FontProperties(fname='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
plt.rcParams.update({'font.family':font.get_name(),'axes.unicode_minus':False,'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'white','savefig.facecolor':'white'})
from matplotlib import font_manager
font_manager.fontManager.addfont('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
raw=json.loads((ROOT/'results/raw_runs.json').read_text());data={i['id']:i for i in json.loads((ROOT/'data/instances.json').read_text())};s=json.loads((ROOT/'results/summary.json').read_text())
methods=['joint_exact','two_stage_best_tie','two_stage_lex','greedy_multistart'];labels=['联合精确','两阶段：最佳同值','两阶段：固定同值','12-start 贪心'];colors=['#0072B2','#009E73','#E69F00','#CC79A7']
fig,(ax,bx)=plt.subplots(1,2,figsize=(14,5.8),gridspec_kw={'width_ratios':[1,1.18]})
for j,(m,l,c) in enumerate(zip(methods,labels,colors)):
 vals=[s['families'][f][m]['valid_outputs_on_feasible'] for f in ['random','edge']];xs=[j*.19-.285,1+j*.19-.285]
 ax.bar(xs,vals,width=.17,label=l,color=c)
 for x,y,total in zip(xs,vals,[16,4]):ax.text(x,y+.2,f'{y}/{total}',ha='center',fontsize=9)
ax.set_xticks([0,1],['随机因子面板','构造边界（仅全局可行例）']);ax.set_ylim(0,18);ax.set_ylabel('通过完整路线合同的实例数');ax.set_title('A  先报成功率，再比较成功解质量',loc='left',fontweight='bold');ax.legend(fontsize=9,loc='upper right',frameon=False);ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True)
rows=[r for r in raw if data[r['instance_id']]['family']=='random'];heat=[]
for r in rows:
 opt=r['answers']['independent_oracle']['objective_total'];heat.append([(r['answers'][m]['objective_total']/opt-1)*100 if r['independent_checks'][m]['feasible'] else float('nan') for m in methods[1:]])
import numpy as np
cm=plt.colormaps['YlOrRd'].copy();cm.set_bad('#e3e7eb');im=bx.imshow(np.array(heat),aspect='auto',cmap=cm,vmin=0,vmax=70)
for i,row in enumerate(heat):
 for j,g in enumerate(row):bx.text(j,i,'未完成' if np.isnan(g) else f'{g:.1f}%',ha='center',va='center',fontsize=8,color='white' if g>45 else '#17202a')
bx.set_xticks(range(3),labels[1:],fontsize=9);bx.set_yticks(range(16),[r['instance_id'].replace('R','').replace('_tight','紧').replace('_loose','松').replace('_dense','稠').replace('_sparse','疏').replace('_','/') for r in rows],fontsize=8);bx.set_title('B  随机16例：相对独立最优成本差距',loc='left',fontweight='bold');bx.spines[['left','bottom']].set_visible(False)
fig.suptitle('P102 共同仓库有限车具机制复验',fontsize=17,fontweight='bold',x=.06,ha='left');fig.text(.06,.025,'固定24例，20例全局可行。随机16例与构造边界分开报告；灰色表示没有完整解，不是全局无解。',fontsize=10,color='#475569');fig.tight_layout(rect=[.02,.07,1,.93]);fig.savefig(ROOT/'figures/main_results.png',dpi=180);fig.savefig(ROOT/'figures/main_results.svg');plt.close(fig)
# Mechanism counterexamples, raw numbers only.
fig,axes=plt.subplots(1,3,figsize=(14,4.8))
r=next(r for r in raw if r['instance_id']=='E05_stage_one_split_trap');i=data[r['instance_id']];xy={0:[0,0],**{t['id']:t['xy'] for t in i['tasks']}}
ax=axes[0]
for rr in r['answers']['joint_exact']['routes']:
 v=rr['vehicle_id'];pts=[xy[k] for k in rr['nodes']]
 # Manhattan schematic: first horizontal then vertical; overlapping is permitted.
 for a,b in zip(pts,pts[1:]):ax.plot([a[0],b[0],b[0]],[a[1],a[1],b[1]],color=colors[v],alpha=.7,lw=2)
for k,(x,y) in xy.items():ax.scatter(x,y,marker='s' if k==0 else 'o',s=80 if k==0 else 50,color='#17202a' if k==0 else '#ffffff',edgecolors='#17202a',zorder=5);ax.annotate('仓库' if k==0 else f'T{k}',(x,y),xytext=(4,5),textcoords='offset points',fontsize=9)
ax.set_title('A  E05：联合分拆可以完成');ax.set_xlabel('Manhattan 路网示意 x');ax.set_ylabel('y');ax.set_xlim(-1,12);ax.set_ylim(-2,4);ax.text(.03,.95,'A合并路线24 > 两台兼容车限额22\n分拆22+22可行；总车成本78',transform=ax.transAxes,va='top',fontsize=9,bbox=dict(facecolor='white',alpha=.9,edgecolor='none'))
ax=axes[1];ax.bar(['联合最优','两阶段最佳同值'],[46,56],color=[colors[0],colors[1]],width=.55);ax.set_title('B  E06：阶段目标与最终成本错位');ax.set_ylabel('总车辆成本（越低越好）');ax.set_ylim(0,68)
for x,y in enumerate([46,56]):ax.text(x,y+1,str(y),ha='center')
ax.text(.5,62,'相对差距 21.74%',ha='center',fontsize=11);ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True)
ax=axes[2];di=s['diagnostics'];ks=['omit_vehicle_compatibility','omit_implement_capacity'];a=[di[k]['raw_feasible_claims']-di[k]['checker_rejected_claims'] for k in ks];b=[di[k]['checker_rejected_claims'] for k in ks]
ax.bar(['删车具兼容','删农具容量'],a,label='原合同仍可行',color='#94a3b8');ax.bar(['删车具兼容','删农具容量'],b,bottom=a,label='被原合同拒绝',color='#D55E00');ax.set_ylim(0,25);ax.set_title('C  缺约束解不进入性能排名');ax.set_ylabel('自称可行的原始输出数');ax.legend(frameon=False,fontsize=9)
for x,(ok,bad) in enumerate(zip(a,b)):ax.text(x,ok+bad+.4,f'{bad}/{ok+bad} 被拒绝',ha='center',fontsize=9)
fig.suptitle('反例与独立路线校验：区分模型、算法和输出失败',fontsize=16,x=.055,ha='left',fontweight='bold');fig.text(.055,.02,'E05/E06是预先冻结的构造机制例，不估计自然发生率。共同仓库、单具单次、车辆可串行换具，无速度/时间模型。',fontsize=9,color='#475569');fig.tight_layout(rect=[.01,.07,1,.91]);fig.savefig(ROOT/'figures/mechanism_checks.png',dpi=180);fig.savefig(ROOT/'figures/mechanism_checks.svg');plt.close(fig)
print('four figure files saved')
