"""Exact Held-Karp/subset mechanism and bounded greedy. No oracle/checker imports."""
import itertools,random

def distances(inst):
    xy=[inst['depot']]+[t['xy'] for t in inst['tasks']]
    return [[sum(abs(a-b) for a,b in zip(x,y)) for y in xy] for x in xy]

def tour_table(inst):
    d=distances(inst);n=len(inst['tasks']); dp={}; tours={0:(0,())}
    for mask in range(1,1<<n):
        for j in range(n):
            if mask>>j&1:
                prev=mask^(1<<j)
                if not prev: dp[mask,j]=(d[0][j+1],(j+1,))
                else: dp[mask,j]=min((dp[prev,k][0]+d[k+1][j+1],dp[prev,k][1]+(j+1,)) for k in range(n) if prev>>k&1)
        tours[mask]=min((dp[mask,j][0]+d[j+1][0],dp[mask,j][1]) for j in range(n) if mask>>j&1)
    return tours

def partitions(inst,tours,drop_capacity=False):
    n=len(inst['tasks']);full=(1<<n)-1;opts=[]
    for m in inst['implements']:
        allowed=sum(1<<j for j,t in enumerate(inst['tasks']) if t['operation']==m['operation'])
        valid=[];sub=allowed
        while True:
            if drop_capacity or sum(t['demand'] for j,t in enumerate(inst['tasks']) if sub>>j&1)<=m['capacity']: valid.append(sub)
            if sub==0: break
            sub=(sub-1)&allowed
        opts.append(sorted(valid))
    def rec(k,covered,masks):
        if k==len(opts):
            if covered==full: yield tuple(masks)
            return
        for mask in opts[k]:
            if not mask&covered: yield from rec(k+1,covered|mask,masks+[mask])
    yield from rec(0,0,[])

def assignment(inst,masks,tours,drop_compat=False):
    active=[i for i,m in enumerate(masks) if m];vcount=len(inst['vehicles']);options=[]
    for i in active:
        options.append([v for v,V in enumerate(inst['vehicles']) if drop_compat or inst['implements'][i]['id'] in V['compatible_implements']])
    best=None;attempts=0
    for vs in itertools.product(*options):
        attempts+=1; loads=[0]*vcount
        for i,v in zip(active,vs): loads[v]+=tours[masks[i]][0]
        if any(x>v['distance_limit'] for x,v in zip(loads,inst['vehicles'])): continue
        val=sum(x*v['cost_per_distance'] for x,v in zip(loads,inst['vehicles']))
        key=(val,vs)
        if best is None or key<best[0]: best=(key,tuple(zip(active,vs)))
    return best,attempts

def output(inst,masks,tours,a,status='FEASIBLE'):
    if a is None: return {'status':'INFEASIBLE_PROVEN' if status=='FEASIBLE' else status,'routes':[],'objective_total':None}
    pairs=a[1]
    return {'status':'FEASIBLE','routes':[{'implement_id':inst['implements'][i]['id'],'vehicle_id':inst['vehicles'][v]['id'],'nodes':[0,*tours[masks[i]][1],0]} for i,v in pairs],'objective_total':a[0][0]}

def exact_all(inst,drop_capacity=False,drop_compat=False):
    tours=tour_table(inst); parts=list(partitions(inst,tours,drop_capacity));best=None;stages=[];attempts=0
    phase_min=min((sum(tours[s][0] for s in ms) for ms in parts),default=None)
    for ms in parts:
        a,cnt=assignment(inst,ms,tours,drop_compat);attempts+=cnt
        if a:
            key=(a[0][0],ms,a[0][1])
            if best is None or key<best[0]: best=(key,ms,a)
        if sum(tours[s][0] for s in ms)==phase_min: stages.append((ms,a))
    joint=output(inst,best[1],tours,best[2]) if best else output(inst,(),tours,None)
    if stages:
        stages.sort(key=lambda x:x[0]);ms,a=stages[0]
        lex=output(inst,ms,tours,a,status='STAGE_FIXED_INFEASIBLE')
        feasible=[(a[0][0],ms,a) for ms,a in stages if a]
        if feasible:
            _,ms,a=min(feasible,key=lambda x:(x[0],x[1],x[2][0][1]));tie=output(inst,ms,tours,a)
        else: tie=output(inst,(),tours,None,status='STAGE_FIXED_INFEASIBLE')
    else: lex=tie={'status':'PHASE_ONE_INFEASIBLE','routes':[],'objective_total':None}
    stats={'partitions':len(parts),'assignment_attempts':attempts,'phase_one_min_distance':phase_min,'phase_one_optimal_partitions':len(stages),'held_karp_subsets':len(tours)}
    for ans in (joint,lex,tie): ans['diagnostics']=stats.copy()
    return {'joint_exact':joint,'two_stage_lex':lex,'two_stage_best_tie':tie}

def route_length(ids,d): return sum(d[a][b] for a,b in zip([0]+ids,ids+[0]))
def greedy(inst,starts=12):
    n=len(inst['tasks']); ts=inst['tasks'];ms=inst['implements'];vs=inst['vehicles'];d=distances(inst)
    rarity=[sum(m['operation']==t['operation'] and t['demand']<=m['capacity'] and m['id'] in v['compatible_implements'] for m in ms for v in vs) for t in ts]
    ids=list(range(n));orders=[sorted(ids,key=lambda i:(rarity[i],-ts[i]['demand'],-d[0][i+1],i)),sorted(ids,key=lambda i:(-ts[i]['demand'],rarity[i],i)),sorted(ids,key=lambda i:(-d[0][i+1],i)),ids]
    rng=random.Random(20261006)
    for _ in range(starts-len(orders)):
        o=ids.copy();rng.shuffle(o);orders.append(o)
    results=[];insertion_checks=0
    for order in orders:
        routes=[[] for _ in ms]; owners=[None]*len(ms); loads=[0]*len(ms); vehicle_d=[0]*len(vs);failed=False
        for i in order:
            t=ts[i]; choices=[]
            for mi,m in enumerate(ms):
                if t['operation']!=m['operation'] or loads[mi]+t['demand']>m['capacity']: continue
                for vi,v in enumerate(vs):
                    if m['id'] not in v['compatible_implements'] or (owners[mi] is not None and owners[mi]!=vi): continue
                    for at in range(len(routes[mi])+1):
                        insertion_checks+=1;a=routes[mi][at-1] if at else 0;b=routes[mi][at] if at<len(routes[mi]) else 0
                        delta=d[a][i+1]+d[i+1][b]-d[a][b]
                        if vehicle_d[vi]+delta<=v['distance_limit']: choices.append((delta*v['cost_per_distance'],delta,mi,vi,at))
            if not choices:failed=True;break
            _,delta,mi,vi,at=min(choices);routes[mi].insert(at,i+1);loads[mi]+=t['demand'];owners[mi]=vi;vehicle_d[vi]+=delta
        for mi,route in enumerate(routes):
            improvement=True
            while improvement:
                improvement=False;old=route_length(route,d)
                for a in range(len(route)):
                    for b in range(a+2,len(route)+1):
                        candidate=route[:a]+list(reversed(route[a:b]))+route[b:]
                        new=route_length(candidate,d)
                        if new<old:
                            vehicle_d[owners[mi]]+=new-old;route[:]=candidate;improvement=True;break
                    if improvement:break
        result={'status':'UNKNOWN_INCOMPLETE' if failed else 'FEASIBLE','routes':[{'implement_id':m['id'],'vehicle_id':vs[owners[mi]]['id'],'nodes':[0,*routes[mi],0]} for mi,m in enumerate(ms) if routes[mi]],'objective_total':sum(di*v['cost_per_distance'] for di,v in zip(vehicle_d,vs)),'assigned_tasks':sum(map(len,routes))}
        results.append(result)
    valid=[r for r in results if r['status']=='FEASIBLE']
    chosen=min(valid,key=lambda r:(r['objective_total'],str(r['routes']))) if valid else max(results,key=lambda r:(r['assigned_tasks'],-r['objective_total']))
    chosen=chosen.copy(); chosen['diagnostics']={'starts':starts,'insertion_checks':insertion_checks};chosen['all_start_outputs']=results
    return chosen
