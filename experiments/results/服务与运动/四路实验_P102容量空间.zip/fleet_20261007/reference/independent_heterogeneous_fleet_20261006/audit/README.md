# 外部独立审计

此目录文件原样复制自独立审阅者，没有修改其数值逻辑。审计结论见P102_AUDIT_ZH.md；原审计用目录与实验目录为同级。

如需完整复跑独立审计，在本实验目录执行以下命令（保留原脚本相对路径合同）：

    mkdir -p ../audit_parallel_mechanisms_20261006
    cp audit/audit_fleet.py audit/audit_fleet_adversarial.py ../audit_parallel_mechanisms_20261006/
    python ../audit_parallel_mechanisms_20261006/audit_fleet.py
    python ../audit_parallel_mechanisms_20261006/audit_fleet_adversarial.py

新审计证据会写在同级审计目录，不覆盖本包保留的原始证据。
