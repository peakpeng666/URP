"""Independent fixture expectations; submitted checker invoked only as test subject."""
import pathlib, importlib.util,copy,json,subprocess,os
from audit_fleet import cert
BASE=pathlib.Path(__file__).resolve().parents[1];SRC=BASE/'independent_heterogeneous_fleet_20261006';OUT=pathlib.Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('subject_checker',SRC/'src/checker.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
i={'depot':[0,0],'tasks':[{'id':1,'xy':[1,0],'operation':0,'demand':2},{'id':2,'xy':[2,0],'operation':0,'demand':2}], 'implements':[{'id':0,'operation':0,'capacity':2},{'id':1,'operation':0,'capacity':2}], 'vehicles':[{'id':0,'cost_per_distance':2,'distance_limit':6,'compatible_implements':[0,1]},{'id':1,'cost_per_distance':3,'distance_limit':10,'compatible_implements':[]}]}
a={'status':'FEASIBLE','routes':[{'vehicle_id':0,'implement_id':0,'nodes':[0,1,0]},{'vehicle_id':0,'implement_id':1,'nodes':[0,2,0]}],'objective_total':12}
cases=[('valid_cumulative_boundary',i,a,True)]
def add(name,edit):
    ii,aa=copy.deepcopy(i),copy.deepcopy(a);edit(ii,aa);cases.append((name,ii,aa,False))
add('missing_task',lambda i,a:a['routes'].pop())
add('duplicate_task',lambda i,a:a['routes'][1].update(nodes=[0,1,0]))
add('wrong_operation',lambda i,a:i['implements'][0].update(operation=1))
add('wrong_vehicle_implement',lambda i,a:a['routes'][0].update(vehicle_id=1))
add('capacity_exceeded',lambda i,a:i['implements'][0].update(capacity=1))
add('unknown_vehicle',lambda i,a:a['routes'][0].update(vehicle_id=99))
add('unknown_implement',lambda i,a:a['routes'][0].update(implement_id=99))
add('implement_reused',lambda i,a:a['routes'][1].update(implement_id=0))
add('cumulative_autonomy_but_each_trip_fits',lambda i,a:i['vehicles'][0].update(distance_limit=4))
add('false_cost',lambda i,a:a.update(objective_total=11))
add('nan_cost',lambda i,a:a.update(objective_total=float('nan')))
add('infinite_cost',lambda i,a:a.update(objective_total=float('inf')))
add('boolean_cost',lambda i,a:a.update(objective_total=True))
add('boolean_vehicle',lambda i,a:a['routes'][0].update(vehicle_id=False))
add('boolean_implement',lambda i,a:a['routes'][0].update(implement_id=False))
add('boolean_task',lambda i,a:a['routes'][0].update(nodes=[0,True,0]))
add('negative_vehicle',lambda i,a:a['routes'][0].update(vehicle_id=-1))
add('float_task',lambda i,a:a['routes'][0].update(nodes=[0,1.0,0]))
add('unknown_task',lambda i,a:a['routes'][0].update(nodes=[0,99,0]))
add('missing_start_depot',lambda i,a:a['routes'][0].update(nodes=[1,1,0]))
add('intermediate_depot',lambda i,a:a['routes'][0].update(nodes=[0,1,0,1,0]))
add('empty_route',lambda i,a:a['routes'][0].update(nodes=[0,0]))
add('routes_not_list',lambda i,a:a.update(routes={}))
add('route_not_object',lambda i,a:a['routes'].__setitem__(0,None))
add('status_unknown_even_complete',lambda i,a:a.update(status='UNKNOWN_INCOMPLETE'))
res=[]
for name,ii,aa,want in cases:
    own=not cert(ii,aa);got=m.check(ii,aa)['feasible'];assert own==got==want,(name,own,got,want);res.append({'test':name,'expected_accepted':want,'auditor_accepted':own,'subject_accepted':got})
(OUT/'fleet_adversarial_evidence.json').write_text(json.dumps({'passed':True,'tests':res},indent=2)+'\n')
p=subprocess.run(['python','-m','unittest','discover','-s',str(SRC/'tests'),'-v'],cwd=SRC,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},capture_output=True,text=True)
(OUT/'fleet_supplied_tests.log').write_text(p.stdout+p.stderr);assert p.returncode==0
print('25 independent black-box fixtures PASS; supplied 20 tests also PASS')
