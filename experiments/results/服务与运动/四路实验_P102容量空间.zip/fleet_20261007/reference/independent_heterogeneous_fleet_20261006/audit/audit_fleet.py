"""External auditor. No imports from the submitted solver, oracle or checker.
Exhaustive route-option recursion proves exact optima; separate certificate logic.
"""
import itertools, json, pathlib, hashlib, time, collections, copy, subprocess, sys
BASE=pathlib.Path(__file__).resolve().parents[1]
SRC=BASE/'independent_heterogeneous_fleet_20261006'
OUT=pathlib.Path(__file__).resolve().parent

def cert(inst,a,complete=True):
    ts={t['id']:t for t in inst['tasks']};ms={m['id']:m for m in inst['implements']};vs={v['id']:v for v in inst['vehicles']}
    xy={0:inst['depot'],**{k:t['xy'] for k,t in ts.items()}}
    seen=collections.Counter();tools=[];mileage=collections.Counter();cost=0;errors=[]
    if type(a)!=dict or type(a.get('routes'))!=list: return ['schema']
    for r in a['routes']:
        if type(r)!=dict: errors.append('route_schema');continue
        vi,mi,ns=(r.get(k) for k in ['vehicle_id','implement_id','nodes'])
        if type(vi)!=int or vi not in vs or type(mi)!=int or mi not in ms:errors.append('resource_id');continue
        if type(ns)!=list or len(ns)<3 or any(type(k)!=int for k in ns):errors.append('nodes_schema');continue
        if ns[0]!=0 or ns[-1]!=0 or any(k not in ts for k in ns[1:-1]):errors.append('nodes_domain');continue
        tools.append(mi);seen.update(ns[1:-1]);v,m=vs[vi],ms[mi]
        if mi not in v['compatible_implements']: errors.append('compatibility')
        if any(ts[k]['operation']!=m['operation'] for k in ns[1:-1]):errors.append('operation')
        if sum(ts[k]['demand'] for k in ns[1:-1])>m['capacity']:errors.append('capacity')
        dist=sum(sum(abs(x-y) for x,y in zip(xy[k],xy[j])) for k,j in zip(ns,ns[1:]))
        mileage[vi]+=dist;cost+=v['cost_per_distance']*dist
    if len(tools)!=len(set(tools)):errors.append('implement_reuse')
    if any(n>1 for n in seen.values()) or (complete and seen!=collections.Counter({k:1 for k in ts})):errors.append('coverage')
    if any(d>vs[k]['distance_limit'] for k,d in mileage.items()):errors.append('autonomy')
    if type(a.get('objective_total'))!=int or a['objective_total']!=cost:errors.append('cost')
    if complete and a.get('status')!='FEASIBLE':errors.append('status')
    return sorted(set(errors))

def exact(inst):
    ts=inst['tasks'];ms=inst['implements'];vs=inst['vehicles'];xy={0:inst['depot'],**{t['id']:t['xy'] for t in ts}};full=frozenset(t['id'] for t in ts)
    options=[]; route_permutations=0
    for m in ms:
        eligible=[t for t in ts if t['operation']==m['operation']];opts=[(frozenset(),0)]
        for size in range(1,len(eligible)+1):
            for subset in itertools.combinations(eligible,size):
                if sum(t['demand'] for t in subset)>m['capacity']:continue
                ids=tuple(t['id'] for t in subset); shortest=None
                for perm in itertools.permutations(ids):
                    route_permutations+=1;seq=(0,)+perm+(0,)
                    d=sum(sum(abs(x-y) for x,y in zip(xy[k],xy[j])) for k,j in zip(seq,seq[1:]))
                    if shortest is None or d<shortest:shortest=d
                opts.append((frozenset(ids),shortest))
        options.append(opts)
    feasible=[];phase_candidates=[]
    def assign_routes(k,covered,chosen):
        if k==len(ms):
            if covered!=full:return
            masks=tuple(sum(2**(i-1) for i in subset) for subset,d in chosen)
            length=sum(d for subset,d in chosen);values=[]
            def assign_vehicle(j,loads):
                if j==len(ms):
                    values.append(sum(l*v['cost_per_distance'] for l,v in zip(loads,vs)));return
                subset,d=chosen[j]
                if not subset:assign_vehicle(j+1,loads);return
                for vidx,v in enumerate(vs):
                    if ms[j]['id'] not in v['compatible_implements'] or loads[vidx]+d>v['distance_limit']:continue
                    loads[vidx]+=d;assign_vehicle(j+1,loads);loads[vidx]-=d
            assign_vehicle(0,[0]*len(vs))
            value=min(values) if values else None
            phase_candidates.append((length,masks,value))
            if value is not None:feasible.append(value)
            return
        for subset,d in options[k]:
            if not covered&subset: assign_routes(k+1,covered|subset,chosen+[(subset,d)])
    assign_routes(0,frozenset(),[])
    joint=min(feasible) if feasible else None
    if not phase_candidates: phase=None;lex=None;besttie=None;nphase=0;phase_status='PHASE_ONE_INFEASIBLE'
    else:
        phase=min(p[0] for p in phase_candidates);sub=[p for p in phase_candidates if p[0]==phase];nphase=len(sub)
        lex=min(sub,key=lambda p:p[1])[2];vals=[p[2] for p in sub if p[2] is not None];besttie=min(vals) if vals else None;phase_status='STAGE_FIXED_INFEASIBLE'
    return {'joint_objective':joint,'joint_status':'FEASIBLE' if joint is not None else 'INFEASIBLE_PROVEN','phase_min':phase,'phase_optimal_partitions':nphase,'lex_objective':lex,'besttie_objective':besttie,'phase_failure_status':phase_status,'route_permutations':route_permutations}

def main():
    start=time.perf_counter();checks=[]
    for filename in ['FREEZE_RECEIPT.json','IMPLEMENTATION_FREEZE.json']:
        frozen=json.loads((SRC/filename).read_text())
        for rel,h in frozen['files'].items():
            got=hashlib.sha256((SRC/rel).read_bytes()).hexdigest();assert got==h,(rel,got,h);checks.append({'path':rel,'sha256':h,'freeze':filename})
    instances=json.loads((SRC/'data/instances.json').read_text());raw=json.loads((SRC/'results/raw_runs.json').read_text());assert len(instances)==len(raw)==24
    records=[];nc=0;npartial=0;comparisons=0
    for inst,r in zip(instances,raw):
        assert inst['id']==r['instance_id'];ex=exact(inst)
        for method,a in r['answers'].items():
            err=cert(inst,a);accepted=not err;assert accepted==r['independent_checks'][method]['feasible'],(inst['id'],method,err)
            nc+=1
            if method in ['joint_exact','independent_oracle']:
                assert (a['status'],a['objective_total'])==(ex['joint_status'],ex['joint_objective']);comparisons+=1
            elif method in ['two_stage_lex','two_stage_best_tie']:
                obj=ex['lex_objective' if method=='two_stage_lex' else 'besttie_objective'];status='FEASIBLE' if obj is not None else ex['phase_failure_status']
                assert (a['status'],a['objective_total'])==(status,obj),(inst['id'],method,ex,a);comparisons+=1
            if a['status']=='FEASIBLE' and not method.startswith('omit_'):assert not err
            if method=='greedy_multistart':
                for s,c in zip(a['all_start_outputs'],r['greedy_start_checks']):
                    assert (not cert(inst,s))==c['feasible'];nc+=1
                    assert not cert(inst,s,complete=False),(inst['id'],s);npartial+=1
                assert a['status'] in ['FEASIBLE','UNKNOWN_INCOMPLETE']
        records.append({'instance':inst['id'],'family':inst['family'],**ex,'greedy_status':r['answers']['greedy_multistart']['status'],'greedy_objective':r['answers']['greedy_multistart']['objective_total']})
    summary={'verdict':'PASS_WITH_SCOPE_LIMITATIONS','freeze_files':checks,'instances':24,'status_objective_comparisons':comparisons,'certificates_including_greedy_starts':nc,'greedy_start_partial_contract_checks':npartial,'random_instances':sum(i['family']=='random' for i in instances),'edge_instances':sum(i['family']=='edge' for i in instances),'globally_feasible':sum(r['joint_objective'] is not None for r in records),'independent_exact_implementation':'ordered route option enumeration + disjoint cover recursion + bounded named-vehicle assignment; no submitted imports','records':records,'wall_seconds':time.perf_counter()-start}
    (OUT/'fleet_independent_evidence.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps({k:v for k,v in summary.items() if k not in ['records','freeze_files']},indent=2))
if __name__=='__main__':main()
