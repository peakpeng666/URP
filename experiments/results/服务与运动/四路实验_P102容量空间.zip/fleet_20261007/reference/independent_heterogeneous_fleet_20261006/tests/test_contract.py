import sys,pathlib,copy,unittest
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'src'))
from checker import check
from generate_data import case
from solver import exact_all
from oracle import solve
class ContractTests(unittest.TestCase):
 def setUp(self):
  self.i=case('test',[(1,0,0,2),(2,0,0,2),(0,1,1,1)],(5,5,5,5),D=(10,10,10),compat=[[0,1],[2,3],[0,1,2,3]])
  self.a={'status':'FEASIBLE','routes':[{'vehicle_id':0,'implement_id':0,'nodes':[0,1,2,0]},{'vehicle_id':1,'implement_id':2,'nodes':[0,3,0]}],'objective_total':8}
 def rejected(self,a,part,inst=None):
  out=check(inst or self.i,a);self.assertFalse(out['feasible']);self.assertTrue(any(part in s for s in out['errors']),out)
 def test_valid(self):self.assertTrue(check(self.i,self.a)['feasible'])
 def test_missing(self):a=copy.deepcopy(self.a);a['routes'][0]['nodes']=[0,1,0];self.rejected(a,'visit_count_0')
 def test_duplicate(self):a=copy.deepcopy(self.a);a['routes'][0]['nodes']=[0,1,2,1,0];self.rejected(a,'visit_count_2')
 def test_wrong_operation(self):a=copy.deepcopy(self.a);a['routes'][0]['implement_id']=2;self.rejected(a,'task_operation_incompatible')
 def test_wrong_compatibility(self):a=copy.deepcopy(self.a);a['routes'][0]['vehicle_id']=1;self.rejected(a,'vehicle_implement_incompatible')
 def test_capacity(self):i=copy.deepcopy(self.i);i['implements'][0]['capacity']=3;self.rejected(self.a,'capacity_exceeded',i)
 def test_fake_vehicle(self):a=copy.deepcopy(self.a);a['routes'][0]['vehicle_id']=99;self.rejected(a,'unknown_vehicle')
 def test_fake_implement(self):a=copy.deepcopy(self.a);a['routes'][0]['implement_id']=99;self.rejected(a,'unknown_implement')
 def test_tool_reused(self):a=copy.deepcopy(self.a);a['routes'].append(copy.deepcopy(a['routes'][0]));self.rejected(a,'implement_reused')
 def test_autonomy(self):i=copy.deepcopy(self.i);i['vehicles'][0]['distance_limit']=3;self.rejected(self.a,'distance_limit_exceeded',i)
 def test_cost(self):a=copy.deepcopy(self.a);a['objective_total']=0;self.rejected(a,'claimed_objective')
 def test_depot(self):a=copy.deepcopy(self.a);a['routes'][0]['nodes']=[0,1,0,2,0];self.rejected(a,'depot_contract')
 def test_bool_id(self):a=copy.deepcopy(self.a);a['routes'][0]['vehicle_id']=False;self.rejected(a,'unknown_vehicle')
 def test_nan_cost(self):a=copy.deepcopy(self.a);a['objective_total']=float('nan');self.rejected(a,'claimed_objective')
 def test_bool_cost(self):a=copy.deepcopy(self.a);a['objective_total']=True;self.rejected(a,'claimed_objective')
 def test_malformed(self):self.rejected({'routes':'bad'},'routes_not_list')
 def test_partial_not_infeasible(self):a=copy.deepcopy(self.a);a['status']='UNKNOWN_INCOMPLETE';self.rejected(a,'status_not_feasible')
 def test_same_vehicle_multiple_implements_permitted(self):
  i=copy.deepcopy(self.i);i['vehicles'][0]['compatible_implements']=[0,2];a=copy.deepcopy(self.a);a['routes'][1]['vehicle_id']=0;a['objective_total']=6;self.assertTrue(check(i,a)['feasible'])
 def test_cumulative_vehicle_budget(self):
  i=copy.deepcopy(self.i);i['vehicles'][0]['compatible_implements']=[0,2];i['vehicles'][0]['distance_limit']=5;a=copy.deepcopy(self.a);a['routes'][1]['vehicle_id']=0;a['objective_total']=6;self.rejected(a,'distance_limit_exceeded',i)
 def test_exact_non_scoring(self):
  a=exact_all(self.i)['joint_exact'];b=solve(self.i);self.assertEqual(a['objective_total'],b['objective_total']);self.assertTrue(check(self.i,b)['feasible'])
if __name__=='__main__':unittest.main(verbosity=2)
