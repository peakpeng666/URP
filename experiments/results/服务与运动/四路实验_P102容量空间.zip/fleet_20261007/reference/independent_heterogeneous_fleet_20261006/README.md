# P102：共同仓库有限异构车具实验

用途：检验操作/农具/车辆兼容、容量与车辆累计续航，区分全局无解、两阶段失败和启发式未找到完整解。不是原论文323任务复现；不含LLM/API，不修改原60/132实验。

## 快速重跑

环境：Python 3.12（核心算法仅标准库）；作图另需已经存在的 matplotlib 3.10.8 / numpy。无安装步骤。

从解压目录执行：

    python -m unittest discover -s tests -v
    python src/smoke_test.py
    python src/run.py results_rerun
    python src/figures.py

不要覆盖data/instances.json或已有results。固定面板24例包含4真不可行例。预冻结数据hash见FREEZE_RECEIPT.json，评分前源码hash见IMPLEMENTATION_FREEZE.json。后续figure/evaluate/report辅助脚本不参与原数值求解，最终hash见MANIFEST.json。

主报告：reports/REPORT.zh.md；科研图：figures/main_results.png和mechanism_checks.png；机器可读全量结果：results/raw_runs.json、results/results.csv、results/summary.json；预算results/budget.json。源论文原文和3–5页核查图在evidence中。

## 后续生成算法的路线接口

CONTRACT.json定义输出；其nonnegative integers措辞限定ID/目标及需求容量等，任务坐标允许有符号整数。每个任务必须恰出现一次，数字ID严格区分bool。每辆车允许依次执行多个工具路线，每条工具路线只有一个绑定车辆，不得重复使用同一工具。共同仓库的每个路线片段均以0开始结束，不准在片段中途补给。不同片段之间的0是换具事件，不是无限补货或增加农具数。

把预先运行候选算法得到的输出保存为JSON对象，键是实例ID，值为status/routes/objective_total。执行：

    python src/evaluate_candidate.py candidate_solutions.json --output candidate_check.json

也可单例运行：

    python src/checker.py one_instance.json one_answer.json

checker完全独立于solver/oracle，只重算原始路线；核心solver和oracle只支持本冻结生成器的连续任务ID（1..n）和顺序车/具ID。checker面向可信、已验hash的实例，拒绝不可信的解；它不是任意不可信实例文件的完整schema验证器。

evaluate_candidate只读取路线JSON，不执行任意生成代码；尚未搭建生成代码的系统隔离、超时沙箱和反作弊环境。因此当前是route-checker基建，不是一次LLM生成算法实验。正式生成任务应将数据、checker、oracle与候选执行进程隔离，禁止候选读取最优解；本公开可见面板应成为开发/回归集，另行预注册未见测试集，避免污染。

## 不可跨越的结论边界

16随机配置只来自4个几何/需求底图（任务数6/8×两seed），容量/兼容的配对变体不是16独立抽样。8边界例是预先设计的机制测试，不估计现实发生率；因此不做显著性检验或算法总体优越性结论。双精确算法仍共享同一数学合同，独立实现一致不能证明合同就是作者完整模型，也不能证明田间运动安全。
