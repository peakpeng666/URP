import subprocess,time,resource,pathlib,json,datetime,sys
ROOT=pathlib.Path(__file__).resolve().parent
if __name__=='__main__':
 t=time.perf_counter();c=time.process_time();before=resource.getrusage(resource.RUSAGE_CHILDREN);started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (ROOT/'results/run.log').open('x') as log:
  p=subprocess.Popen([sys.executable,'src/run_panel.py'],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
  try:code=p.wait(timeout=910)
  except subprocess.TimeoutExpired:p.kill();code=p.wait()
 after=resource.getrusage(resource.RUSAGE_CHILDREN)
 result={'started_utc':started,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':code,'numeric_child_tree_user_cpu_s':after.ru_utime-before.ru_utime,'numeric_child_tree_system_cpu_s':after.ru_stime-before.ru_stime,'numeric_child_tree_total_cpu_s':after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime,'supervisor_cpu_s':time.process_time()-c,'supervised_wall_s':time.perf_counter()-t,'max_rss_kib':after.ru_maxrss,'command':[sys.executable,'src/run_panel.py'],'budget_limit_cpu_s':180,'external_tool_or_platform_cpu':'unknown'}
 (ROOT/'results/supervisor_receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));sys.exit(code)
