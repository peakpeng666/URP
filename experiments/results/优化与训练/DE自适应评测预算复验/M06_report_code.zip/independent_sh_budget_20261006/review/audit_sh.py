"""Third-party SH audit; imports no submitted implementation.
Checks the complete ledger and all saved curves/points, reproduces selection,
reimplements paired DE trajectories, and independently recomputes statistics.
"""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[k]='1'
import pathlib,json,math,hashlib,collections,time,numpy as np
ROOT=pathlib.Path(__file__).resolve().parents[1]/'independent_sh_budget_20261006';OUT=pathlib.Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def formula(X,p):
    Z=np.asarray(X)-np.array(p['shift']);n=Z.shape[1]
    if p['family']=='sphere': return np.einsum('ij,ij->i',Z,Z)/n
    if p['family']=='ellipsoid':
        R=np.array(p['rotation']);Z=np.sum(Z[:,:,None]*R[None,:,:],axis=1);w=10.**(np.arange(n)*4/(n-1));return np.einsum('ij,ij,j->i',Z,Z,w)/sum(w)
    if p['family']=='rastrigin':return np.maximum(0.,np.sum(Z**2+10*(1-np.cos(2*math.pi*Z)),axis=1)/n)
    assert p['family']=='rosenbrock';Z=Z+1;return (100*np.sum((Z[:,1:]-Z[:,:-1]**2)**2,axis=1)+np.sum((Z[:,:-1]-1)**2,axis=1))/(101*(n-1))
def score(a):return math.fsum(math.log10(max(float(v),1e-12)) for v in a)/len(a)
def close(a,b):return np.allclose(a,b,rtol=1e-9,atol=1e-10)
def independent_replay(p,cfg):
    """Vector random draws, but exclusion mapped independently by explicit lists."""
    pop=np.random.Generator(np.random.PCG64(p['initial_seed'])).uniform(-5,5,(40,12));rng=np.random.Generator(np.random.PCG64(p['operator_seed']));fitness=None;hashes=[];values=[];traces=[]
    for gen in range(181):
        if gen==0: pts=pop.copy()
        else:
            choices=[]
            for width in [39,38,37]:
                raw=rng.integers(0,width,size=40);chosen=[]
                for i,j in enumerate(raw):
                    excluded={i,*[a[i] for a in choices]};allowed=[k for k in range(40) if k not in excluded];chosen.append(allowed[int(j)])
                choices.append(np.array(chosen))
            assert all(len({i,*(a[i] for a in choices)})==4 for i in range(40))
            cross=rng.random((40,12))<cfg['CR'];forced=rng.integers(0,12,size=40);cross[np.arange(40),forced]=True
            mutation=pop[choices[0]]+cfg['F']*(pop[choices[1]]-pop[choices[2]])
            pts=np.clip(np.where(cross,mutation,pop),-5,5)
        y=formula(pts,p);hashes.append(hashlib.sha256(pts.astype('<f8').tobytes()).hexdigest());values.append(y)
        if gen==0:fitness=y.copy()
        else:
            better=y<fitness;pop[better]=pts[better];fitness[better]=y[better]
        traces.append([40*(gen+1),min(fitness),min(y),np.mean(y)])
    return np.array(hashes),np.array(values),pop,fitness,rng.bit_generator.state

def main():
    cpu0=time.process_time();wall0=time.monotonic();plan=json.loads((ROOT/'plan.json').read_text());freeze=json.loads((ROOT/'prerun_freeze.json').read_text());selection=json.loads((ROOT/'results/selection.json').read_text());analysis=json.loads((ROOT/'results/analysis.json').read_text());summary=json.loads((ROOT/'results/run_summary.json').read_text())
    freezes=[]
    for p,h in freeze['files'].items():assert sha(ROOT/p)==h;freezes.append({'path':p,'sha256':h})
    assert sha(ROOT/'plan.json')==selection['plan_sha256'];assert sha(ROOT/'results/selection.json')==(ROOT/'results/selection.sha256').read_text().strip()
    rawlines=(ROOT/'results/ledger.jsonl').read_bytes().splitlines(keepends=True);rows=[json.loads(x) for x in rawlines];assert len(rows)==8064==summary['actual_segments']
    assert len(set(r['run_id'] for r in rows))==len(rows);assert len(set(r['path'] for r in rows))==len(rows)
    assert [r for r in rows if r['phase']=='search']==rows[:4416]
    assert hashlib.sha256(b''.join(rawlines[:4416])).hexdigest()==selection['input_ledger_sha256']
    phase_order={'search':0,'selected_confirmation':1,'train_diagnostic_completion':2,'unselected_confirmation_diagnostic':2}
    assert all(phase_order[a['phase']]<=phase_order[b['phase']] for a,b in zip(rows,rows[1:]))
    assert all(r['status']=='complete' and r['error'] is None for r in rows) and summary['failures']==[]
    assert plan['dimension']==12 and plan['population']==40 and plan['bounds']==[-5,5]
    assert [30720//(n*4) for n in [16,8,4,2]]==plan['sh']['increment_FE']==[480,960,1920,3840]
    assert 40*16+sum(n*r for n,r in zip([16,8,4,2],plan['sh']['increment_FE']))==1960*16==31360
    assert plan['confirmation_FE']==7240 and plan['trial_count']==12
    seeds=[];problem_fingerprints=[];scalar_count=0;maxerror=0.;segments=0;prefixes=0;replay_count=0;replay_FE=0;trialres=[];computed_curves={'sh':[],'uniform':[]};low_floor_count=0;allpoints=0;phasefe=collections.Counter();group_count=0
    for r in rows:phasefe[r['phase']]+=r['actual_FE']
    assert sum(phasefe.values())==30812160==summary['actual_FE'];assert dict(phasefe)==summary['phase_FE']
    for trial,sel in zip(plan['trials'],selection['selections']):
        t=trial['trial'];assert t==sel['trial'];train=[p for p in trial['problems'] if p['stage']=='train'];confirm=[p for p in trial['problems'] if p['stage']=='confirm'];assert len(train)==8 and len(confirm)==12
        assert collections.Counter(p['family'] for p in train)=={f:2 for f in plan['families']};assert collections.Counter(p['family'] for p in confirm)=={f:3 for f in plan['families']}
        for p in trial['problems']:
            seeds.extend(p[k] for k in ['initial_seed','operator_seed','instance_seed']);problem_fingerprints.append(json.dumps([p['family'],p['shift'],p['rotation']]))
            assert close(np.array(p['rotation']).T@np.array(p['rotation']),np.eye(12))
            assert close(formula(np.array([p['shift']]),p),[0])
        pp={p['id']:p for p in trial['problems']};cc={c['id']:c for c in trial['configs']};assert len(cc)==16
        trialrows=[r for r in rows if r['trial']==t];groups=collections.defaultdict(list)
        for r in trialrows:groups[r['method'],r['config'],r['problem']].append(r)
        full={};checkpoint={};group_count+=len(groups)
        for key,rr in groups.items():
            rr.sort(key=lambda r:r['start_FE']);assert rr[0]['start_FE']==0;prev=None;part=[];hh=[];vv=[]
            for r in rr:
                assert sha(ROOT/r['path'])==r['sha256'];p=pp[r['problem']]
                with np.load(ROOT/r['path'],allow_pickle=False) as z:
                    a={k:z[k] for k in z.files}
                state=json.loads(str(a['state']));assert state['fe']==r['end_FE'] and state['rng']==r['rng_end'];assert r['actual_FE']==r['end_FE']-r['start_FE'];assert a['values'].shape==(r['actual_FE']//40,40)
                assert np.all(np.isfinite(a['values'])) and np.all(a['values']>=0);allpoints+=a['values'].size;low_floor_count+=int(np.sum(a['values']<1e-12))
                for ar in ['sample_points','population']:assert np.all(np.isfinite(a[ar])) and np.max(abs(a[ar]))<=5
                if prev:
                    pr,pa=prev;assert r['continued_from']==pr['path'] and r['start_FE']==pr['end_FE'] and r['rng_start']==pr['rng_end'];startbest=min(pa['fitness'])
                else:
                    assert r['continued_from'] is None and r['start_FE']==0;startbest=math.inf
                    assert r['rng_start']==np.random.Generator(np.random.PCG64(p['operator_seed'])).bit_generator.state
                tr=a['trace'];assert np.array_equal(tr[:,0],np.arange(r['start_FE']+40,r['end_FE']+1,40));best=np.minimum.accumulate(np.r_[startbest,np.min(a['values'],axis=1)])[1:]
                assert np.array_equal(best,tr[:,1]) and np.array_equal(np.min(a['values'],axis=1),tr[:,2]);assert close(np.mean(a['values'],axis=1),tr[:,3]);assert min(a['fitness'])==r['best']==tr[-1,1]
                # sample index rotates by global generation, not segment-relative.
                which=(np.arange(r['start_FE']//40,r['end_FE']//40)%40);assert np.array_equal(a['values'][np.arange(len(which)),which],a['sample_values'])
                for pts,y in [(a['sample_points'],a['sample_values']),(a['population'],a['fitness']),(np.array([r['best_point']]),np.array([r['best']]))]:
                    got=formula(pts,p);assert close(got,y),(r['run_id'],max(abs(got-y)));scalar_count+=len(y);maxerror=max(maxerror,float(max(abs(got-y)/np.maximum(1,abs(got)))))
                assert close(a['fitness'][np.argmin(a['fitness'])],formula(np.array([r['best_point']]),p)[0]);segments+=1
                checkpoint[r['path']]=(a['population'],a['fitness'],state);part.append(tr);hh.append(a['point_hashes']);vv.append(a['values']);prev=(r,a)
            full[key]={'trace':np.concatenate(part),'hashes':np.concatenate(hh),'values':np.concatenate(vv),'last':rr[-1]}
            assert rr[-1]['end_FE']==(1960 if key[0]=='uniform' else 7240)
        for method in ['sh','uniform']:
            for p in train:assert sum(r['actual_FE'] for r in trialrows if r['method']==method and r['problem']==p['id'] and r['phase']=='search')==31360
        for cid in cc:
            for p in train:
                u=full['uniform',cid,p['id']];s=full['sh',cid,p['id']]
                for field in ['trace','hashes','values']:assert np.array_equal(s[field][:49],u[field]);prefixes+=1
        active=list(cc)
        for k,end in enumerate([520,1480,3400,7240]):
            rd=sel['rounds'][k];assert rd['candidates']==active and rd['end_FE']==end and rd['rung']==k
            scores={cid:score([full['sh',cid,p['id']]['trace'][end//40-1,1] for p in train]) for cid in active}
            assert all(abs(scores[x['config']]-x['score'])<1e-13 for x in rd['scores'])
            active=sorted(active,key=lambda cid:(scores[cid],cid))[:len(active)//2];assert active==rd['survivors']
        assert active[0]==sel['sh']
        uscores={cid:score([full['uniform',cid,p['id']]['trace'][-1,1] for p in train]) for cid in cc};assert min(uscores,key=lambda cid:(uscores[cid],cid))==sel['uniform']
        assert all(abs(uscores[x['config']]-x['score'])<1e-13 for x in sel['uniform_scores'])
        # All 96 chosen SH train trajectories reconstructed without core imports.
        for p in train:
            cid=sel['sh'];r=full['sh',cid,p['id']];hh,vv,pop,fit,rng=independent_replay(p,cc[cid]);assert np.array_equal(hh,r['hashes']),(t,p['id'],'independent replay point mismatch')
            assert close(vv,r['values']);saved=checkpoint[r['last']['path']];assert np.array_equal(pop,saved[0]) and close(fit,saved[1]) and rng==saved[2]['rng'];replay_count+=1;replay_FE+=7240
        train_scores={cid:score([full['sh',cid,p['id']]['trace'][-1,1] for p in train]) for cid in cc};test_scores={cid:score([full['confirmation',cid,p['id']]['trace'][-1,1] for p in confirm]) for cid in cc}
        train_oracle=min(cc,key=lambda cid:(train_scores[cid],cid));test_oracle=min(cc,key=lambda cid:(test_scores[cid],cid))
        def eliminated(cid):return next((rd['rung']+1 for rd in sel['rounds'] if cid in rd['candidates'] and cid not in rd['survivors']),None)
        d=test_scores[sel['sh']]-test_scores[sel['uniform']]
        fam={f:score([full['confirmation',sel['sh'],p['id']]['trace'][-1,1] for p in confirm if p['family']==f])-score([full['confirmation',sel['uniform'],p['id']]['trace'][-1,1] for p in confirm if p['family']==f]) for f in plan['families']}
        result={'trial':t,'difference':d,'ratio':10**d,'family_differences':fam,'train_oracle':train_oracle,'train_oracle_eliminated_round':eliminated(train_oracle),'confirmation_oracle':test_oracle,'confirmation_oracle_eliminated_round':eliminated(test_oracle)}
        recorded=analysis['per_trial'][t]
        for k,v in result.items():assert (v==recorded[k] if type(v) in [str,int,type(None)] else (all(abs(x-recorded[k][f])<1e-12 for f,x in v.items()) if type(v)==dict else abs(v-recorded[k])<1e-12)),(t,k,v,recorded[k])
        trialres.append(result)
        for method in computed_curves:computed_curves[method].append(np.mean([np.log10(np.maximum(full['confirmation',sel[method],p['id']]['trace'][:,1],1e-12)) for p in confirm],axis=0).tolist())
        print('independent trial verified',t,flush=True)
    assert len(seeds)==len(set(seeds))==720;assert len(problem_fingerprints)==len(set(problem_fingerprints))==240
    assert segments==8064 and group_count==5376 and allpoints==30812160
    aliases=json.loads((ROOT/'results/confirmation_aliases.json').read_text());assert len(aliases)==288
    for a in aliases:
        assert a['config']==selection['selections'][a['trial']][a['method']]
        assert a['path']==f'data/t{a["trial"]:02d}_confirmation_{a["config"]}_{a["problem"]}_7240.npz'
    delta=np.array([r['difference'] for r in trialres]);rng=np.random.Generator(np.random.PCG64(plan['statistics_seed']));boots=np.mean(delta[rng.integers(0,12,size=(20000,12))],axis=1);ci=np.quantile(boots,[.025,.975]);wins=int(sum(delta<-1e-12));losses=int(sum(delta>1e-12));ties=12-wins-losses;sign=min(1.,sum(math.comb(wins+losses,i) for i in range(min(wins,losses)+1))*2/2**(wins+losses));familymeans={f:np.mean([r['family_differences'][f] for r in trialres]) for f in plan['families']}
    assert close(ci,analysis['mean_difference_bootstrap95_percentile']) and abs(np.mean(delta)-analysis['mean_difference_log10_SH_minus_uniform'])<1e-12 and [wins,ties,losses]==analysis['wins_ties_losses_SH'] and sign==analysis['exact_two_sided_sign_p']
    trainbad=sum(r['train_oracle_eliminated_round'] is not None for r in trialres);testbad=sum(r['confirmation_oracle_eliminated_round'] is not None for r in trialres);assert trainbad==2==analysis['train_oracle_discarded'] and testbad==7==analysis['confirmation_oracle_discarded']
    curve=json.loads((ROOT/'figures/curve_data.json').read_text());assert curve['FE']==list(range(40,7241,40));assert all(close(computed_curves[k],curve['trial_mean_log10'][k]) for k in computed_curves)
    evidence={'verdict':'PASS_WITH_SCOPE_LIMITATIONS','frozen_files':freezes,'selection_sha256':sha(ROOT/'results/selection.json'),'selection_ledger_prefix_SHA_verified':True,'selection_precedes_confirmation_and_diagnostic_evidence':'Frozen run.py write order + selection witness hashing exact first 4416 ledger rows + monotone phase order; not externally timestamp-attested.','segments':segments,'logical_trajectories':group_count,'actual_experiment_FE':allpoints,'phase_FE':dict(phasefe),'failures':0,'retained_HPO_trial_denominator':12,'training_trajectories_each_method':1536,'confirmation_matrix_trajectories':2304,'seeds_unique':720,'independent_instance_transforms':240,'stored_point_recalculations':scalar_count,'max_scaled_recalculation_error':maxerror,'all_training_prefix_array_comparisons':prefixes,'independently_reimplemented_DE_replay_trajectories':replay_count,'independent_replay_FE':replay_FE,'mean_log_difference':float(np.mean(delta)),'median_geomean_loss_ratio':float(np.median(10**delta)),'bootstrap95':ci.tolist(),'wins_ties_losses':[wins,ties,losses],'exact_sign_p':sign,'family_mean_log_difference':familymeans,'train_oracle_discarded':trainbad,'confirmation_oracle_discarded':testbad,'loss_values_below_frozen_floor':low_floor_count,'all_plot_curves_recomputed':True,'per_trial':trialres,'audit_cpu_seconds':time.process_time()-cpu0,'audit_wall_seconds':time.monotonic()-wall0}
    (OUT/'sh_independent_evidence.json').write_text(json.dumps(evidence,indent=2)+'\n');print(json.dumps({k:v for k,v in evidence.items() if k not in ['frozen_files','per_trial']},indent=2))
if __name__=='__main__':main()
