"""Post-run presentation only. Does not select candidates or alter raw results."""
import os
os.environ['MPLCONFIGDIR']=str(__import__('pathlib').Path(__file__).resolve().parents[1]/'.mplcache')
os.environ['XDG_CACHE_HOME']=str(__import__('pathlib').Path(__file__).resolve().parents[1]/'.cache')
import json,csv,math,hashlib
from pathlib import Path
from collections import defaultdict
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from core import dump,sha
ROOT=Path(__file__).resolve().parents[1];a=json.loads((ROOT/'results/analysis.json').read_text());s=json.loads((ROOT/'results/run_summary.json').read_text());q=json.loads((ROOT/'results/audit.json').read_text());p=json.loads((ROOT/'plan.json').read_text());sel=json.loads((ROOT/'results/selection.json').read_text())['selections'];rows=[json.loads(x) for x in (ROOT/'results/ledger.jsonl').read_text().splitlines()];trials=a['per_trial']
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.grid':True,'grid.alpha':.2,'savefig.dpi':180})
colors={'sh':'#1864ab','uniform':'#d97706'}
def save(fig,name):
    fig.savefig(ROOT/'figures'/f'{name}.png',bbox_inches='tight');fig.savefig(ROOT/'figures'/f'{name}.svg',bbox_inches='tight');plt.close(fig)
fig,ax=plt.subplots(1,2,figsize=(11,4.4))
for i,t in enumerate(trials):
    ax[0].plot([0,1],[t['uniform_confirmation_score'],t['sh_confirmation_score']],color='#94a3b8',alpha=.8,lw=1)
    for j,k in enumerate(['uniform','sh']):ax[0].scatter(j,t[k+'_confirmation_score'],c=colors[k],s=28,zorder=4)
ax[0].set_xticks([0,1],['Uniform','Successive Halving']);ax[0].set_ylabel('Fresh-instance mean log10 normalized loss');ax[0].set_title('Equal final evaluation: 7,240 FE per run')
d=np.array([t['difference'] for t in trials]);ax[1].bar(np.arange(12)+1,d,color=[colors['sh'] if x<0 else colors['uniform'] for x in d]);ax[1].axhline(0,color='black',lw=1);ax[1].set_xlabel('Independent HPO trial (entire configuration pool)');ax[1].set_ylabel('SH minus uniform (log10 loss)');ax[1].set_title('Negative favors SH; zero means same outcome');ax[1].set_xticks(np.arange(12)+1)
fig.suptitle('Budget allocation changes which configuration generalizes',fontsize=14);fig.tight_layout();save(fig,'01_confirmation_paired')
fig,ax=plt.subplots(1,2,figsize=(11,4.4));costs=[(8,520),(4,1480),(2,3400),(2,7240)];x=np.arange(16);alloc=np.concatenate([np.repeat(v,n) for n,v in costs]);ax[0].barh(x,alloc,color=colors['sh'],alpha=.8,label='SH terminal FE');ax[0].axvline(1960,color=colors['uniform'],lw=2,label='Uniform: 1,960 each');ax[0].set_xlabel('FE per candidate, including 40-FE initialization');ax[0].set_ylabel('Candidate sorted by allocated budget');ax[0].set_title('Both methods spend 31,360 FE per train instance');ax[0].legend(fontsize=8)
phases=list(s['phase_FE']);val=[s['phase_FE'][k]/1e6 for k in phases];labels={'search':'Both actual searches','selected_confirmation':'Selected confirmation','train_diagnostic_completion':'Train oracle completion','unselected_confirmation_diagnostic':'Unselected test oracle'};ax[1].barh([labels[k] for k in phases],val,color=['#64748b','#1864ab','#7c3aed','#94a3b8']);ax[1].set_xlabel('Actual objective evaluations (millions)');ax[1].set_title('Offline diagnostic cost is charged separately')
fig.tight_layout();save(fig,'02_budget_ledger')
fig,ax=plt.subplots(1,2,figsize=(11,4.4));ax[0].scatter([t['sh_test_rank'] for t in trials],[t['uniform_test_rank'] for t in trials],color=colors['sh'],s=55);ax[0].plot([1,16],[1,16],'--',color='gray');ax[0].set_xlim(.5,16.5);ax[0].set_ylim(.5,16.5);ax[0].set_xlabel('SH selected candidate: paid test-oracle rank');ax[0].set_ylabel('Uniform selected candidate: paid test-oracle rank');ax[0].set_title('Rank 1 is best of only the frozen 16 candidates')
rounds=[t['confirmation_oracle_eliminated_round'] or 5 for t in trials];counts=[rounds.count(i) for i in range(1,6)];ax[1].bar(['Round 1','Round 2','Round 3','Round 4','Retained'],counts,color=['#dc2626','#f97316','#f59e0b','#eab308','#1864ab']);ax[1].set_ylabel('Number of HPO trials (denominator 12)');ax[1].set_title('When SH eliminated the paid test-oracle best');ax[1].set_ylim(0,12)
fig.suptitle('Retrospective diagnostics only: never available to the selector',fontsize=13);fig.tight_layout();save(fig,'03_offline_elimination')
curves={'sh':[],'uniform':[]};families=p['families'];bykey={(r['trial'],r['config'],r['problem']):r for r in rows if r['method']=='confirmation'}
for i in range(12):
    for method in curves:
        seq=[]
        for pr in p['trials'][i]['problems']:
            if pr['stage']=='confirm':
                r=bykey[(i,sel[i][method],pr['id'])]
                with np.load(ROOT/r['path'],allow_pickle=False) as data:seq.append(np.log10(np.maximum(data['trace'][:,1],1e-12)))
        curves[method].append(np.mean(seq,axis=0))
fig,ax=plt.subplots(figsize=(7.8,4.6));fe=np.arange(40,7241,40)
for method in curves:
    v=np.array(curves[method]);ax.plot(fe,np.median(v,axis=0),color=colors[method],label=method);ax.fill_between(fe,np.quantile(v,.25,axis=0),np.quantile(v,.75,axis=0),color=colors[method],alpha=.18)
ax.set_xlabel('Fresh confirmation FE per run (initialization included)');ax.set_ylabel('Mean log10 normalized objective over 12 instances');ax.set_title('Selected configurations on fresh instances at matched FE');ax.legend();fig.text(.12,.01,'Line: median of 12 HPO trials. Band: trial IQR, not a confidence interval.',fontsize=9);fig.tight_layout(rect=[0,.04,1,1]);save(fig,'04_confirmation_curves');dump(ROOT/'figures/curve_data.json',{'FE':fe.tolist(),'trial_mean_log10':{k:np.asarray(v).tolist() for k,v in curves.items()}})
fig,ax=plt.subplots(figsize=(8.5,4.5)); vals=np.array([[t['family_differences'][fam] for t in trials] for fam in families]); means=vals.mean(axis=1); ax.bar(np.arange(4),means,color=[colors['sh'] if x<0 else colors['uniform'] for x in means],alpha=.8);
for j in range(4): ax.scatter(j+np.linspace(-.16,.16,12),vals[j],s=15,c='#475569',alpha=.7)
ax.axhline(0,color='black',lw=1);ax.set_xticks(range(4),['Sphere','Ellipsoid','Rastrigin','Rosenbrock']);ax.set_ylabel('SH minus uniform (fresh-instance log10 loss)');ax.set_title('Aggregate improvement is dominated by Sphere');fig.text(.12,.01,'Bars: means. Dots: all 12 paired HPO trials. No per-family significance claim.',fontsize=9);fig.tight_layout(rect=[0,.04,1,1]);save(fig,'05_family_heterogeneity')
with (ROOT/'results/trial_summary.csv').open('w') as f:
    keys=[k for k in trials[0] if k!='family_differences'];w=csv.DictWriter(f,fieldnames=keys,extrasaction='ignore');w.writeheader();w.writerows(trials)
with (ROOT/'results/all_candidate_scores.csv').open('w') as f:
    w=csv.DictWriter(f,fieldnames=list(a['all_candidate_scores'][0]));w.writeheader();w.writerows(a['all_candidate_scores'])
mean=a['mean_difference_log10_SH_minus_uniform'];ci=a['mean_difference_bootstrap95_percentile'];wins,ties,losses=a['wins_ties_losses_SH'];ratio=a['median_ratio_of_normalized_geomean_losses_SH_over_uniform'];tab='\n'.join(f"| {t['trial']+1} | {t['sh_config']} | {t['uniform_config']} | {t['difference']:.4f} | {t['ratio']:.4f} | {t['sh_test_rank']} / {t['uniform_test_rank']} |" for t in trials)
family='\n'.join(f"| {fam} | {np.mean([t['family_differences'][fam] for t in trials]):.4f} | {sum(t['family_differences'][fam]<-1e-12 for t in trials)} / {sum(abs(t['family_differences'][fam])<=1e-12 for t in trials)} / {sum(t['family_differences'][fam]>1e-12 for t in trials)} |" for fam in families)
cost='\n'.join(f"| {labels[k]} | {s['phase_FE'][k]:,} | {s['phase_cpu_seconds'][k]:.2f} |" for k in phases)
text=f'''# Successive Halving预算机制的DE任务迁移复验

2026年10月6日 UTC。独立新增CPU实验。本文检验M06论文的真实预算分配机制，不是作者代码、原论文整表或BBOB复现。

## 主要结论

在12次完整、配对、独立候选池的调参试验中，SH与均匀分配的搜索FE严格相同。两者选出的配置随后从头运行于新的实例和RNG，均获得7240FE。SH相对均匀分配的“确认实例平均log10归一化损失”差值均值为 **{mean:.4f}**，预设20000次成对bootstrap的95%百分位区间 **[{ci[0]:.4f}, {ci[1]:.4f}]**。12个调参块的SH胜/同/负为 **{wins}/{ties}/{losses}**，精确双侧符号检验p={a['exact_two_sided_sign_p']:.4g}。

每块先计算SH/均匀分配的归一化几何平均损失比，再对12块取中位数，得到 **{ratio:.4f}**；小于1有利于SH。该量不是原目标的算术平均下降率，也不是求解速度倍数。区间和p值只描述本预设合成任务分布，不支持一般算法或新任务域的普适优越性。

总体差值主要由Sphere推动：四族平均log10差分别为Sphere −2.2385、Ellipsoid +0.1801、Rastrigin +0.0686、Rosenbrock −0.1077。因此Ellipsoid与Rastrigin的平均结果反而较差，不能把总体比值当作各类任务都改善。

全候选付费补跑显示：SH在{a['train_oracle_discarded']}/12个候选池淘汰了最终7240FE训练面板第一名；在{a['confirmation_oracle_discarded']}/12个池淘汰了事后7240FE确认面板第一名，其中{a['confirmation_oracle_discarded_first_rung']}/12发生在第一轮。这说明有限低预算筛选仍可能丢掉最终好配置。离线第一名来自额外全候选测量，绝不是已部署选择器或真实全局最优。

![独立确认配对结果](figures/01_confirmation_paired.png)

## 论文来源与复验位置

核心机制来自Jamieson与Talwalkar的Non-stochastic Best Arm Identification and Hyperparameter Optimization。项目M06/P344精读使用arXiv:1502.07943v1（2015，13页），本轮重新核对公开2016 PMLR正文第4页Figure 3：预算按轮数及存活候选数均分，新增训练资源后按累计损失保留一半，直到一个候选。来源：[PMLR论文页](https://proceedings.mlr.press/v51/jamieson16.html)。P246 [Hyperband](https://jmlr.org/papers/v18/16-558.html)的精读用于检查启动成本、低保真错序与资源定义边界，本轮没有执行Hyperband多bracket。

把这套机制迁移到DE参数配置时，资源是目标函数评价数FE，臂是固定F、CR配置，损失是当前8个训练实例上的聚合优化误差。DE当前最优值有界且单调，但本次终点是预定7240FE；没有证明未知收敛包络、原论文充分预算条件或独立实例泛化保证。训练实例上的排序和新实例确认性能是两件事。

旧独立DE包做的是9网格对9随机静态调参、D=10/N=50、三个未变换函数、216 run。本次新建D=12/N=40、四类变换实例、12个全新随机配置池以及磁盘续训状态。旧方案和结果用于避免重复，未用于后验挑本次函数/候选/seed；因研究背景可见，本次称独立开发确认，不称完全盲测。旧代码与132/60生成协议均未修改。

## 事前冻结的设计与成本

- 12个独立调参试验，每试验16个独立均匀随机候选：F∈[0.2,1.0]，CR∈[0.1,1.0]。全部具体数值和RNG种子写入plan.json后才开始正式评分。
- D=12，N=40，同步DE/rand/1/bin，供体互异且排除目标；强制至少一个坐标交叉；逐坐标clip至[-5,5]；严格改善才替换。固定结构，不是新算法发现。
- 四函数族：平移Sphere、平移Rastrigin、平移旋转条件数10000的Ellipsoid、平移Rosenbrock。每试验每族2个训练实例及3个新确认实例，合计8/12。平移在[-1,1]内事前产生，最优值均0；只旋转Ellipsoid。
- 各候选、各方法对同一实例使用完全相同的初始种群和PCG64算子流；不同试验/实例/确认阶段使用独立命名RNG域。候选参数不改变随机数消耗。
- 全部16候选各支付40FE初始化。SH四轮每个存活候选新增480/960/1920/3840FE，存活数16/8/4/2，累计520/1480/3400/7240FE。新增资源每轮7680FE，初始化640FE，总31360FE/训练实例。
- 均匀分配各候选1960FE，包括40FE初始化；16×1960=31360FE。每种方法每次调参8×31360=250880FE，12次各3010560FE。
- 选择分数固定为8实例的log10(max(归一化最优误差,1e-12))算术平均，同分按候选ID。归一化是解析常数：Sphere及Rastrigin除以12，Ellipsoid除以权重和，Rosenbrock除以101×11。没有按观测最小/最大值归一化，没有使用确认或oracle校准阈值。
- 所有12次、两种方法的选择先写入结果文件并做SHA256封存，之后才开始新实例确认。随后所有淘汰配置按原状态补到7240FE，以及所有未选配置在确认实例跑满7240FE，仅作付费诊断。补跑不反向改变任何选择。
- 两方法若选择同配置，确认实际执行一次并记录双角色别名；不会把别名当独立样本。调参训练本身两方法独立实际执行，不使用离线曲线模拟分配。

![预算明细](figures/02_budget_ledger.png)

| 计算阶段 | 实际FE | CPU秒（分段内含保存） |
|---|---:|---:|
{cost}
| 正式实验合计 | {s['actual_FE']:,} | {s['cpu_seconds']:.2f} |

正式实验墙钟{s['wall_seconds']:.2f}秒。非评分测试21720FE、{json.loads((ROOT/'results/prerun_tests.json').read_text())['cpu_seconds']:.3f} CPU秒。独立审计另有{q['replay_FE']:,}FE直跑重放，不反馈优化器；审计总CPU {q['audit_cpu_seconds']:.2f}秒、墙钟{q['audit_wall_seconds']:.2f}秒。此外审计独立公式重算样本点和保存种群，不属于优化器FE但确实消耗CPU，已包含在审计耗时。数值运行采用单进程/原生单线程，未调用LLM、远程评价API、付费服务或安装依赖。绘图与归档是后处理，另行记录。

FE相同不等于端到端墙钟相同。本目标函数非常廉价，归档压缩和框架开销可能大于函数本身；不可从本实验推导昂贵训练的速度倍数。选择观测次数SH为每试验30次聚合评分、均匀为16次；它们读取已有最优值，不新增FE。初始化、排序和序列化CPU已在实际执行中发生。

## 完整12块结果

负差值有利于SH；比值是SH/均匀的归一化几何平均损失；排名依赖额外全候选确认，不能上线使用。

| 试验 | SH配置 | 均匀配置 | 配对log10差 | 配对比值 | 事后确认排名 SH/均匀 |
|---:|---|---|---:|---:|---:|
{tab}

按函数族的以下分解为预设四族的描述性结果；没有分别做显著性结论或筛掉较差函数。每族分母仍是12个完整调参块，而非把36个实例当独立调参试验。

| 函数族 | 平均SH减均匀log10差 | SH胜/同/负 |
|---|---:|---:|
{family}

![四族差异](figures/05_family_heterogeneity.png)

![等预算确认曲线](figures/04_confirmation_curves.png)

曲线对每试验先在12个新实例上平均log10损失，再取12试验中位数；色带为试验间四分位，不是置信区间。曲线显示部署所选配置在相同FE的行为；不能把训练期长跑与短跑末值直接比较来声称选参优势。

## 误淘汰与离线诊断

![付费事后诊断](figures/03_offline_elimination.png)

原始候选池中第一轮520FE排名与7240FE训练排名、训练第一名淘汰轮次、确认第一名淘汰轮次、两选择的最终有限池排名均在analysis.json和CSV内。可能存在低预算慢起步，也可能存在训练到新实例的排序变化；本实验没有把二者混成同一种失败。确认oracle同时包含实例随机性与固定有限候选池选择的乐观偏差，因此只报告风险诊断。

低预算相关性再高也不构成无误淘汰证明。SH最终胜过或落后均匀分配，并不改变该限制。尚未比较Hyperband保守bracket、不同最小资源、更多训练实例或SMAC/irace；不能根据此结果事后挑一个更好早停方案再复用相同确认面板。

## 完整性与核验

12个完整调参试验全部完成；每种方法1536条训练轨迹、两方法合计3072条；确认全矩阵2304条，合计5376条真实逻辑轨迹。SH多次恢复使实际保存分段为{s['actual_segments']}个，分段不是新的独立run。失败、非有限值、超时、删除、替换均0。所有事前分母保留。

- 12项非评分合同测试通过：解析值、供体互异排除目标、非法预算、磁盘恢复后逐代值/点hash/样本/种群/fitness/RNG与直跑精确一致。
- {q['segment_count']}个分段逐一核SHA、评价数量、FE连续性、保存人口/最佳点、单调最优曲线、每代最小与均值、RNG前后衔接。
- {q['independent_scalar_point_samples']:,}个预设每代1-of-40样本点用标准库标量目标公式重新计算；最大max(1,abs(value))缩放误差为{q['max_scaled_sample_error']:.3g}。另外重算每段40个最终个体，共{q['additional_final_population_scalar_checks']:,}点。样本检查不是全坐标点重算。
- 对全部1536条SH训练轨迹，补跑完整前1960FE的每代所有评价值、整批点SHA及曲线，与均匀臂独立执行前缀逐项精确匹配。
- 对事前约定的12个SH赢家×8训练实例共96条轨迹，从初始seed直跑7240FE，逐代全部值、整批点hash和曲线与磁盘多段续训精确匹配，共{q['replay_FE']:,}审计FE。
- 从原始曲线另行重算两方法全部淘汰与赢家；确认选择SHA不变；全部统计以完整调参块为单位重算。原DE文件hash不变。

独立指另一套标量公式、账本与统计检查，加上可重复直跑；并不表示由外部研究团队完成。记录保存全部FE值、每代曲线、每代固定样本点、每批点hash和续训状态，未保存每个坐标点。冻结源与种子可重建整条轨迹。

## 独立审阅

另一位审阅者未导入core.py，独立重写DE并完整重放同96条赢家轨迹，逐代匹配通过；同时核查全部分段、选择、统计与24份原始ZIP。结论为PASS_WITH_SCOPE_LIMITATIONS，完整意见见review/M06_AUDIT_ZH.md。其额外695040FE重放和16.31CPU秒单列，不与前述作者自检混算。独立审阅确认所有正式FE目标值均未触及事前1e-12下限。

## 可复核文件与使用边界

plan.json给出所有配置、实例变换、种子、指标、预算与失败处理；prerun_freeze.json列正式前代码SHA。src/包含冻结、核心DE、运行、审计、后处理。results/ledger.jsonl是实际调用账本，selection.json是确认前锁定选择，confirmation_aliases.json记录重复角色，analysis.json/CSV与audit.json保存汇总及验证。data/*.npz使用NumPy allow_pickle=False读取，含每阶段原始值和checkpoint。figures/含PNG、SVG及曲线数据。

重跑须解压到新目录并更换或另存results/data输出，原运行器会拒绝覆盖既有账本。不要修改plan后仍称同一预注册复验。这里只使用固定四函数族、一个维度、一个预算、12候选池和有限F/CR空间；新实例确认是同分布变换，绝非未见函数族、噪声、工程任务、算法结构发现或农业可行性证据。

计划SHA256：{sha(ROOT/'plan.json')}。选择SHA256：{sha(ROOT/'results/selection.json')}。审计SHA256：{sha(ROOT/'results/audit.json')}。
'''
(ROOT/'REPORT_ZH.md').write_text(text)
print(json.dumps({'figures':5,'report_bytes':len(text.encode()),'mean_delta':mean,'ci':ci,'win_tie_loss':[wins,ties,losses]}))
