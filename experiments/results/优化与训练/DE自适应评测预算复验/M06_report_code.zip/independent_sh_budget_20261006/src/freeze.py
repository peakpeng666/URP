import sys,platform,json,shutil
from pathlib import Path
from datetime import datetime,timezone
import numpy as np
from core import *
ROOT=Path(__file__).resolve().parents[1]
assert not (ROOT/'plan.json').exists(), 'Do not replace frozen design'
plans=[]
for trial in range(12):
    r=np.random.Generator(np.random.PCG64(seed(f'pool/{trial}')))
    configs=[{'id':f'c{i:02d}','F':float(r.uniform(.2,1.0)),'CR':float(r.uniform(.1,1.0))} for i in range(16)]
    problems=[]
    for stage,count in [('train',2),('confirm',3)]:
        for family in ['sphere','ellipsoid','rastrigin','rosenbrock']:
            for k in range(count):
                label=f'trial/{trial}/{stage}/{family}/{k}'; gen=np.random.Generator(np.random.PCG64(seed(label+'/instance')))
                shift=gen.uniform(-1,1,D); rotation=np.eye(D)
                if family=='ellipsoid':
                    q,rr=np.linalg.qr(gen.normal(size=(D,D)));rotation=q*np.where(np.diag(rr)>=0,1,-1)[None,:]
                problems.append({'id':f'{stage}_{family}_{k}','stage':stage,'family':family,'shift':shift.tolist(),'rotation':rotation.tolist(),'instance_seed':seed(label+'/instance'),'initial_seed':seed(label+'/init'),'operator_seed':seed(label+'/op')})
    plans.append({'trial':trial,'pool_seed':seed(f'pool/{trial}'),'configs':configs,'problems':problems})
plan={'id':'dot.sh-budget.20261006.v1','created_utc':datetime.now(timezone.utc).isoformat(),'dimension':D,'population':N,'bounds':[-5,5],
'families':['sphere','ellipsoid','rastrigin','rosenbrock'],'normalization':{'sphere':'raw/D','ellipsoid':'raw/sum(10**(4*j/(D-1)))','rastrigin':'raw/D','rosenbrock':'raw/(101*(D-1))'},
'selection':'Arithmetic mean over 8 training instance runs of log10(max(normalized best objective,1e-12)); ties ascending config id.',
'primary_endpoint':'For each of 12 pools, paired difference SH minus uniform of mean log10 normalized loss over 12 fresh confirmation instances, both 7240 FE. Negative favors SH.',
'statistics':'12 independent entire HPO trials are paired blocks. Mean difference and median ratio 10**difference, paired wins/ties/losses (1e-12 log tie tolerance). 20000 paired bootstrap means, fixed seed; two-sided exact sign test excluding ties. Descriptive evidence in this fixed synthetic domain, not confirmatory external generalization. No per-instance pseudoreplication.',
'statistics_seed':seed('statistics/bootstrap'),'sh':{'survivors':[16,8,4,2],'increment_FE':[480,960,1920,3840],'cumulative_FE':[520,1480,3400,7240]},'uniform_FE':1960,'per_method_per_training_instance_FE':31360,'per_method_per_pool_FE':250880,
'initialization_FE_per_candidate':40,'confirmation_FE':7240,'trial_count':12,'trials':plans,
'procedure':['All SH and uniform actual evaluations run independently using paired initial and operator RNG. No offline curves used by selector.','All 12 method selections written, hashed and closed before any confirm or counterfactual completion.','Run selected configurations from scratch on 12 new instances at 7240 FE; aliases execute once if identical.','Only after selections and selected confirmation, continue all train SH states and fill all unselected confirmation configs to 7240 FE for offline diagnostic oracle. Never modify selections.'],
'costs':{'planned_search_FE':6021120,'planned_train_diagnostic_increment_FE':8110080,'full_confirmation_matrix_FE':16680960,'physical_total_experiment_FE':30812160,'hard_CPU_seconds_including_benchmark_tests_run_audit_replay':1800,'hard_wall_seconds_run':1800,'processes':1,'native_threads':1},
'failure_policy':'Stop and preserve partial record for any nonfinite objective, exception or hard resource limit; retain all planned denominators, no replacements or post hoc removal. Non-scoring unit/benchmark seeds are separate.',
'logging':'Every FE value, every generation best/min/mean and point-batch SHA256, deterministic 1-of-40 point sample for independent scalar recalculation, saved population/fitness/PCG64 state at every promotion. Not every point is stored; source/seeds/hashes support exact replay.',
'scope':'P344 Successive Halving budget mechanism transferred to fresh DE configuration search; not author code or paper full-table reproduction, not BBOB, not LLM algorithm discovery. Historical experiment plan/report/method source inspected, hence independent development confirmation not pristine blinded research.'}
dump(ROOT/'plan.json',plan)
for pid in ['P344','P246']:
    src=ROOT.parent/'paper_to_experiment_20261006/all_modules/M06/逐篇笔记'/f'{pid}.md';shutil.copyfile(src,ROOT/'provenance'/f'{pid}_reading.md')
old=ROOT.parent/'independent_de_hpo_20261006'; oldfiles=['plan.json','REPORT_ZH.md','src/run.py','sources/function_optimization_de/src/de.py']
dump(ROOT/'provenance/historical_readonly_fence.json',{str(old/p):sha(old/p) for p in oldfiles})
dump(ROOT/'provenance/environment.json',{'python':sys.version,'numpy':np.__version__,'platform':platform.platform()})
files=['plan.json','src/core.py','src/run.py','src/audit.py','src/tests.py','src/freeze.py']
dump(ROOT/'prerun_freeze.json',{'utc':datetime.now(timezone.utc).isoformat(),'files':{p:sha(ROOT/p) for p in files}})
print(json.dumps({'plan_sha256':sha(ROOT/'plan.json'),'freeze_sha256':sha(ROOT/'prerun_freeze.json'),'total_FE':30812160}))
