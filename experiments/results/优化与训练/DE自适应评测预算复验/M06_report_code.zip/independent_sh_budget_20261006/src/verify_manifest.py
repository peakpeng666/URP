"""Portable, read-only delivery verification; no optimizer calls or original-workspace dependency."""
import json,hashlib,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
m=json.loads((root/'FILE_MANIFEST.json').read_text()); errors=[]
for r in m['files']:
 p=root/r['path']
 if not p.is_file(): errors.append({'path':r['path'],'reason':'missing'});continue
 if p.stat().st_size!=r['bytes'] or hashlib.sha256(p.read_bytes()).hexdigest()!=r['sha256']:errors.append({'path':r['path'],'reason':'content mismatch'})
print(json.dumps({'passed':not errors,'checked_files':len(m['files']),'errors':errors},ensure_ascii=False,indent=2))
sys.exit(bool(errors))
