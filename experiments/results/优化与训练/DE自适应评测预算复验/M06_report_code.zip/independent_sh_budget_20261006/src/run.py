import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']: os.environ[k]='1'
from pathlib import Path
import time,json,traceback,sys,resource
from datetime import datetime,timezone
import numpy as np
from core import *
ROOT=Path(__file__).resolve().parents[1]

def main():
    resource.setrlimit(resource.RLIMIT_CPU,(1750,1751))
    plan=json.loads((ROOT/'plan.json').read_text()); freeze=json.loads((ROOT/'prerun_freeze.json').read_text())
    for p,h in freeze['files'].items(): assert sha(ROOT/p)==h,p
    assert not (ROOT/'results/ledger.jsonl').exists(),'Refuse overwrite of actual runs'
    cpu0=time.process_time();t0=time.monotonic(); rows=[];sels=[]; failures=[];pathmap={}; bestmap={}
    def run_segment(tr,method,cfg,p,end,source=None,phase='search'):
        if time.process_time()-cpu0>1600 or time.monotonic()-t0>1750: raise TimeoutError('Bound reached before next segment; no selective dropping')
        prefix=f't{tr:02d}_{method}_{cfg["id"]}_{p["id"]}_{end}'
        out=ROOT/'data'/f'{prefix}.npz'; startcpu=time.process_time();startwall=time.monotonic()
        obj=DE.restore(p,cfg,source) if source else DE(p,cfg)
        startfe=obj.fe; rng0=obj.rng.bit_generator.state; status='complete';error=None
        try:
            arrays=obj.advance(end);obj.save(out,arrays)
        except BaseException as e:
            failures.append({'run_id':prefix,'error':repr(e),'traceback':traceback.format_exc(),'completed_FE':obj.fe,'target_FE':end}); raise
        row={'run_id':prefix,'trial':tr,'method':method,'phase':phase,'config':cfg['id'],'problem':p['id'],'family':p['family'],'start_FE':startfe,'end_FE':obj.fe,'actual_FE':obj.fe-startfe,'best':obj.best(),'best_point':obj.pop[int(np.argmin(obj.fitness))].tolist(),'rng_start':rng0,'rng_end':obj.rng.bit_generator.state,'status':status,'error':error,'cpu_seconds':time.process_time()-startcpu,'wall_seconds':time.monotonic()-startwall,'path':str(out.relative_to(ROOT)),'sha256':sha(out),'continued_from':str(Path(source).relative_to(ROOT)) if source else None}
        rows.append(row)
        with (ROOT/'results/ledger.jsonl').open('a') as f: f.write(json.dumps(row,allow_nan=False)+'\n')
        return row
    try:
        for trial in plan['trials']:
            tr=trial['trial'];cfgs={c['id']:c for c in trial['configs']};ps=[p for p in trial['problems'] if p['stage']=='train'];active=list(cfgs); rounds=[]
            method_order=['sh','uniform'] if tr%2==0 else ['uniform','sh']
            for method in method_order:
                if method=='sh':
                    for rung,end in enumerate(plan['sh']['cumulative_FE']):
                        scores=[]
                        for cid in active:
                            vals=[]
                            for p in ps:
                                key=(tr,'sh',cid,p['id']); r=run_segment(tr,'sh',cfgs[cid],p,end,pathmap.get(key));pathmap[key]=ROOT/r['path'];bestmap[key]=r['best'];vals.append(r['best'])
                            scores.append({'config':cid,'score':score(vals)})
                        ranked=sorted(scores,key=lambda x:(x['score'],x['config']));survivors=[r['config'] for r in ranked[:len(active)//2]]
                        rounds.append({'rung':rung,'end_FE':end,'candidates':list(active),'scores':scores,'survivors':survivors});active=survivors
                    shwin=active[0];shscore=next(x['score'] for x in rounds[-1]['scores'] if x['config']==shwin)
                else:
                    uscores=[]
                    for cid in cfgs:
                        vals=[]
                        for p in ps:
                            r=run_segment(tr,'uniform',cfgs[cid],p,plan['uniform_FE']);vals.append(r['best'])
                        uscores.append({'config':cid,'score':score(vals)})
                    u=min(uscores,key=lambda x:(x['score'],x['config']));uwin=u['config'];uscore=u['score']
            sel={'trial':tr,'sh':shwin,'uniform':uwin,'sh_search_score':shscore,'uniform_search_score':uscore,'rounds':rounds,'uniform_scores':uscores,'method_execution_order':method_order,'selection_utc':datetime.now(timezone.utc).isoformat()};sels.append(sel)
            dump(ROOT/'results'/f'selection_t{tr:02d}.json',sel)
            print('SEARCH_COMPLETE',tr,shwin,uwin,flush=True)
        searchrows=[r for r in rows if r['phase']=='search']; assert sum(r['actual_FE'] for r in searchrows)==plan['costs']['planned_search_FE']
        selection={'utc':datetime.now(timezone.utc).isoformat(),'plan_sha256':sha(ROOT/'plan.json'),'input_ledger_sha256':sha(ROOT/'results/ledger.jsonl'),'search_actual_FE':sum(r['actual_FE'] for r in searchrows),'selections':sels,'locked_before_confirmation_and_diagnostic':True}
        dump(ROOT/'results/selection.json',selection);selecthash=sha(ROOT/'results/selection.json');(ROOT/'results/selection.sha256').write_text(selecthash+'\n')
        print('ALL_SELECTIONS_FROZEN',selecthash,flush=True)
        aliases=[]
        for trial,sel in zip(plan['trials'],sels):
            tr=trial['trial'];cfgs={c['id']:c for c in trial['configs']};ps=[p for p in trial['problems'] if p['stage']=='confirm'];chosen=list(dict.fromkeys([sel['sh'],sel['uniform']]))
            for cid in chosen:
                for p in ps:
                    r=run_segment(tr,'confirmation',cfgs[cid],p,plan['confirmation_FE'],phase='selected_confirmation');pathmap[(tr,'confirmation',cid,p['id'])]=ROOT/r['path'];bestmap[(tr,'confirmation',cid,p['id'])]=r['best']
            for method in ['sh','uniform']:
                for p in ps: aliases.append({'trial':tr,'method':method,'config':sel[method],'problem':p['id'],'path':str(pathmap[(tr,'confirmation',sel[method],p['id'])].relative_to(ROOT))})
            print('CONFIRM_COMPLETE',tr,flush=True)
        dump(ROOT/'results/confirmation_aliases.json',aliases)
        # Separate paid diagnostics, after all actual selections and their confirmation.
        for trial in plan['trials']:
            tr=trial['trial'];cfgs={c['id']:c for c in trial['configs']}
            for cid in cfgs:
                for p in trial['problems']:
                    method='sh' if p['stage']=='train' else 'confirmation';key=(tr,method,cid,p['id']);source=pathmap.get(key)
                    current=0
                    if source:
                        with np.load(source,allow_pickle=False) as a: current=json.loads(str(a['state']))['fe']
                    if current==plan['confirmation_FE']:continue
                    phase='train_diagnostic_completion' if p['stage']=='train' else 'unselected_confirmation_diagnostic'
                    r=run_segment(tr,method,cfgs[cid],p,plan['confirmation_FE'],source,phase);pathmap[key]=ROOT/r['path'];bestmap[key]=r['best']
            print('DIAGNOSTIC_COMPLETE',tr,flush=True)
        assert sha(ROOT/'results/selection.json')==selecthash
    except BaseException as e:
        failures.append({'error':repr(e),'traceback':traceback.format_exc()})
    summary={'status':'complete' if not failures else 'incomplete','planned_trials':12,'selected_trials':len(sels),'actual_segments':len(rows),'actual_FE':sum(r['actual_FE'] for r in rows),'planned_FE':plan['costs']['physical_total_experiment_FE'],'failures':failures,'phase_FE':{k:sum(r['actual_FE'] for r in rows if r['phase']==k) for k in sorted({r['phase'] for r in rows})},'phase_cpu_seconds':{k:sum(r['cpu_seconds'] for r in rows if r['phase']==k) for k in sorted({r['phase'] for r in rows})},'wall_seconds':time.monotonic()-t0,'cpu_seconds':time.process_time()-cpu0,'end_utc':datetime.now(timezone.utc).isoformat(),'nominal_training_trajectories_per_method':1536,'nominal_confirmation_trajectories_all_candidates':2304}
    dump(ROOT/'results/run_summary.json',summary);print('SUMMARY',json.dumps(summary),flush=True)
    if failures:sys.exit(1)
    assert summary['actual_FE']==summary['planned_FE']
if __name__=='__main__':main()
