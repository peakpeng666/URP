"""Fresh, resumable synchronous DE/rand/1/bin and analytic objectives.
No imports from historical experiment packages. Float64; every evaluated point costs 1 FE.
"""
import hashlib, json, math
from pathlib import Path
import numpy as np

N=40; D=12

def dump(path,obj):
    Path(path).write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def seed(label): return int.from_bytes(hashlib.sha256(('dot.sh-budget.20261006.v1:'+label).encode()).digest()[:8],'little')
def objective(x,p):
    z=x-np.asarray(p['shift'])
    if p['family']=='sphere': y=np.sum(z*z,axis=1)/D
    elif p['family']=='ellipsoid':
        z=z@np.asarray(p['rotation']); y=np.sum(z*z*np.geomspace(1,1e4,D),axis=1)/float(np.sum(np.geomspace(1,1e4,D)))
    elif p['family']=='rastrigin': y=(10*D+np.sum(z*z-10*np.cos(2*np.pi*z),axis=1))/D
    elif p['family']=='rosenbrock':
        z=z+1.; y=np.sum(100*(z[:,1:]-z[:,:-1]**2)**2+(z[:,:-1]-1)**2,axis=1)/(101*(D-1))
    else: raise ValueError(p['family'])
    if not np.all(np.isfinite(y)) or np.min(y)<-1e-10: raise ValueError('Invalid objective result')
    return np.maximum(y,0.)

def scalar_objective(x,p):
    z=[float(a)-float(b) for a,b in zip(x,p['shift'])]
    if p['family']=='sphere': return math.fsum(t*t for t in z)/len(z)
    if p['family']=='ellipsoid':
        q=p['rotation']; v=[math.fsum(z[i]*q[i][j] for i in range(len(z))) for j in range(len(z))]
        weights=[10**(4*j/(len(z)-1)) for j in range(len(z))]
        return math.fsum(a*a*w for a,w in zip(v,weights))/math.fsum(weights)
    if p['family']=='rastrigin': return max(0.,math.fsum(t*t+10*(1-math.cos(2*math.pi*t)) for t in z)/len(z))
    if p['family']=='rosenbrock':
        v=[t+1 for t in z]; return math.fsum(100*(b-a*a)**2+(a-1)**2 for a,b in zip(v[:-1],v[1:]))/(101*(len(z)-1))
    raise ValueError(p['family'])

def donors_from_rng(rng,n):
    target=np.arange(n)
    a=rng.integers(0,n-1,size=n); a+=a>=target
    exc=np.sort(np.column_stack([target,a]),axis=1)
    b=rng.integers(0,n-2,size=n)
    for j in range(2): b+=b>=exc[:,j]
    exc=np.sort(np.column_stack([target,a,b]),axis=1)
    c=rng.integers(0,n-3,size=n)
    for j in range(3): c+=c>=exc[:,j]
    return np.column_stack([a,b,c])

def make_trials(pop,rng,cfg):
    n,d=pop.shape; donors=donors_from_rng(rng,n)
    uniforms=rng.random((n,d)); forced=rng.integers(0,d,size=n)
    mutant=pop[donors[:,0]]+cfg['F']*(pop[donors[:,1]]-pop[donors[:,2]])
    cross=uniforms<cfg['CR']; cross[np.arange(n),forced]=True
    return np.clip(np.where(cross,mutant,pop),-5.,5.)

class DE:
    def __init__(self,p,cfg):
        self.p=p; self.cfg=cfg; self.rng=np.random.Generator(np.random.PCG64(p['operator_seed']))
        self.pop=np.random.Generator(np.random.PCG64(p['initial_seed'])).uniform(-5,5,(N,D))
        self.fitness=None; self.fe=0
    @classmethod
    def restore(cls,p,cfg,path):
        arr=np.load(path,allow_pickle=False); s=json.loads(str(arr['state']))
        obj=cls.__new__(cls); obj.p=p; obj.cfg=cfg; obj.pop=arr['population'].copy(); obj.fitness=arr['fitness'].copy(); obj.fe=s['fe']
        obj.rng=np.random.Generator(np.random.PCG64());obj.rng.bit_generator.state=s['rng']
        return obj
    def advance(self,target):
        if target<max(self.fe,N) or target%N: raise ValueError('Budget must be >= current and a positive full generation')
        values=[]; samples=[]; samplevals=[]; trace=[]; hashes=[]
        while self.fe<target:
            points=self.pop.copy() if self.fe==0 else make_trials(self.pop,self.rng,self.cfg)
            if not np.all(np.isfinite(points)) or np.max(np.abs(points))>5: raise ValueError('Bad point')
            y=objective(points,self.p); index=(self.fe//N)%N
            values.append(y.copy()); samples.append(points[index].copy()); samplevals.append(y[index]); hashes.append(hashlib.sha256(points.astype('<f8').tobytes()).hexdigest())
            if self.fe==0: self.fitness=y
            else:
                mask=y<self.fitness;self.pop[mask]=points[mask];self.fitness[mask]=y[mask]
            self.fe+=N
            trace.append([self.fe,float(np.min(self.fitness)),float(np.min(y)),float(np.mean(y))])
        return {'values':np.asarray(values),'sample_points':np.asarray(samples),'sample_values':np.asarray(samplevals),'trace':np.asarray(trace),'point_hashes':np.asarray(hashes,dtype='U64')}
    def save(self,path,arrays):
        np.savez_compressed(path,**arrays,population=self.pop,fitness=self.fitness,state=json.dumps({'fe':self.fe,'rng':self.rng.bit_generator.state},sort_keys=True))
    def best(self): return float(np.min(self.fitness))

def score(values): return math.fsum(math.log10(max(float(v),1e-12)) for v in values)/len(values)
