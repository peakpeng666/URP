import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[k]='1'
from core import *
import tempfile,time,json,sys
ROOT=Path(__file__).resolve().parents[1]
def main():
    t=time.process_time();checks=[];fe=0
    p={'family':'sphere','shift':[0]*D,'rotation':np.eye(D).tolist(),'initial_seed':13,'operator_seed':27};cfg={'id':'test','F':.53,'CR':.67}
    for fam in ['sphere','ellipsoid','rastrigin','rosenbrock']:
        pp={**p,'family':fam};xx=np.array([[0.]*D,[1.]*D,[-.2]*D]);assert np.allclose(objective(xx,pp),[scalar_objective(x,pp) for x in xx],rtol=1e-11,atol=1e-13);checks.append(fam+'_hand_values')
    rng=np.random.default_rng(555)
    for n in [4,5,40]:
        for _ in range(100):
            a=donors_from_rng(rng,n);assert all(len(set(v))==3 and i not in v for i,v in enumerate(a));assert np.all((a>=0)&(a<n))
    checks.append('300_donor_batches_distinct_exclude_target')
    a=DE(p,cfg); aa=a.advance(7240);fe+=7240
    b=DE(p,cfg);segments=[]
    with tempfile.TemporaryDirectory(dir=ROOT/'results') as td:
        for n in [520,1480,3400,7240]:
            bb=b.advance(n);segments.append(bb);f=Path(td)/'state.npz';b.save(f,bb);b=DE.restore(p,cfg,f)
        fe+=7240
        for key in ['values','sample_points','sample_values','trace','point_hashes']:
            assert np.array_equal(aa[key],np.concatenate([s[key] for s in segments]));checks.append('resume_equals_uninterrupted_'+key)
        assert np.array_equal(a.pop,b.pop) and np.array_equal(a.fitness,b.fitness) and a.rng.bit_generator.state==b.rng.bit_generator.state;checks.append('resume_final_population_fitness_rng_exact')
    # Non-scoring speed probe: a different synthetic rotated ellipsoid seed.
    pp={**p,'family':'ellipsoid','initial_seed':8881,'operator_seed':9921};c=DE(pp,cfg);cpu=time.process_time();cc=c.advance(7240);fe+=7240;elapsed=time.process_time()-cpu
    assert sum(np.asarray(cc['values']).shape)==181+40 and c.fe==7240
    try:c.advance(7241);raise AssertionError('Partial generation accepted')
    except ValueError:checks.append('invalid_budget_rejected')
    dump(ROOT/'results/prerun_tests.json',{'passed':True,'checks':checks,'non_scoring_FE':fe,'cpu_seconds':time.process_time()-t,'benchmark_FE':7240,'benchmark_cpu_seconds':elapsed,'projected_30812160_FE_CPU_seconds_no_IO':elapsed/7240*30812160,'scope':'Only non-scoring synthetic seeds, before freeze. Main panel never evaluated.'})
    print((ROOT/'results/prerun_tests.json').read_text())
if __name__=='__main__':main()
