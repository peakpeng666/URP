"""Read-only audit: standalone scalar math objectives, ledger budget accounting,
paired prefix equality, direct replay, independent selection and heldout statistics.
Does not change any method decision or raw experiment output.
"""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[k]='1'
import json,math,time,hashlib,sys,resource
from pathlib import Path
import numpy as np
from core import DE,sha,dump
ROOT=Path(__file__).resolve().parents[1]

def independent_formula(x,p):
    z=[float(x[i])-p['shift'][i] for i in range(12)];f=p['family']
    if f=='sphere':return math.fsum(v**2 for v in z)/12
    if f=='ellipsoid':
        v=[math.fsum(z[i]*p['rotation'][i][j] for i in range(12)) for j in range(12)];w=[math.pow(10,4*j/11) for j in range(12)]
        return math.fsum(v[j]**2*w[j] for j in range(12))/math.fsum(w)
    if f=='rastrigin':return max(0.,math.fsum(v*v+10*(1-math.cos(math.tau*v)) for v in z)/12)
    v=[a+1 for a in z];return math.fsum(100*math.pow(v[i+1]-v[i]**2,2)+(v[i]-1)**2 for i in range(11))/1111

def independent_score(values):return math.fsum(math.log10(max(float(x),1e-12)) for x in values)/len(values)
def main():
    t=time.monotonic();cpu=time.process_time();plan=json.loads((ROOT/'plan.json').read_text());sels=json.loads((ROOT/'results/selection.json').read_text())['selections'];rows=[json.loads(l) for l in (ROOT/'results/ledger.jsonl').read_text().splitlines()];summary=json.loads((ROOT/'results/run_summary.json').read_text());checks=[];groups={};maxerr=0;sample_n=0
    spent=summary['cpu_seconds']+json.loads((ROOT/'results/prerun_tests.json').read_text())['cpu_seconds']; remaining=max(1,int(1800-spent));resource.setrlimit(resource.RLIMIT_CPU,(remaining,remaining+1))
    for p,h in json.loads((ROOT/'prerun_freeze.json').read_text())['files'].items():assert sha(ROOT/p)==h,p
    checks.append('all_frozen_inputs_unchanged')
    for p,h in json.loads((ROOT/'provenance/historical_readonly_fence.json').read_text()).items():assert sha(p)==h,p
    checks.append('historical_package_readonly_fence')
    assert summary['status']=='complete' and summary['actual_FE']==30812160 and not summary['failures']
    assert sha(ROOT/'results/selection.json')==(ROOT/'results/selection.sha256').read_text().strip();checks.append('selection_hash_unchanged')
    for r in rows:
        p=next(p for p in plan['trials'][r['trial']]['problems'] if p['id']==r['problem']);f=ROOT/r['path'];assert sha(f)==r['sha256'];a=np.load(f,allow_pickle=False);v=a['values'];tr=a['trace'];sample=a['sample_points'];sval=a['sample_values'];state=json.loads(str(a['state']))
        assert v.shape==(r['actual_FE']//40,40) and len(tr)==len(v) and r['actual_FE']==r['end_FE']-r['start_FE'] and state['fe']==r['end_FE']
        assert np.all(np.isfinite(v)) and np.all(np.isfinite(sample)) and np.all(np.abs(sample)<=5)
        assert np.array_equal(tr[:,0],np.arange(r['start_FE']+40,r['end_FE']+1,40))
        previous=math.inf
        if r['continued_from']:
            with np.load(ROOT/r['continued_from'],allow_pickle=False) as prev: previous=float(np.min(prev['fitness']));ps=json.loads(str(prev['state']));assert ps['fe']==r['start_FE'] and ps['rng']==r['rng_start']
        b=np.minimum.accumulate(np.r_[previous,np.min(v,axis=1)])[1:];assert np.array_equal(b,tr[:,1]) and np.array_equal(np.min(v,axis=1),tr[:,2]);assert np.allclose(np.mean(v,axis=1),tr[:,3],rtol=1e-14,atol=1e-14)
        assert float(np.min(a['fitness']))==r['best']==float(tr[-1,1]);assert state['rng']==r['rng_end']
        for x,y in zip(sample,sval):
            val=independent_formula(x,p);err=abs(val-y)/max(1,abs(val));maxerr=max(maxerr,err);assert err<1e-10,(r['run_id'],val,y);sample_n+=1
        val=independent_formula(r['best_point'],p);assert abs(val-r['best'])/max(1,abs(val))<1e-10
        assert np.allclose([independent_formula(x,p) for x in a['population']],a['fitness'],rtol=1e-9,atol=1e-10)
        key=(r['trial'],r['method'],r['config'],r['problem']);groups.setdefault(key,[]).append(r)
    checks.append('all_segments_hash_budget_curve_samples_population_rng')
    def full_arrays(key):
        rr=sorted(groups[key],key=lambda r:r['start_FE']);assert rr[0]['start_FE']==0;end=0;vv=[];hh=[];tr=[]
        for r in rr:
            assert r['start_FE']==end;end=r['end_FE']
            with np.load(ROOT/r['path'],allow_pickle=False) as a:vv.append(a['values']);hh.append(a['point_hashes']);tr.append(a['trace'])
        return {'values':np.concatenate(vv),'point_hashes':np.concatenate(hh),'trace':np.concatenate(tr),'end_FE':end}
    def finalbest(tr,method,cid,pid):return max(groups[(tr,method,cid,pid)],key=lambda r:r['end_FE'])['best']
    prefix_tests=0;replay_FE=0;replay_n=0;trialresults=[];scores_table=[]
    for trial,sel in zip(plan['trials'],sels):
        tr=trial['trial'];train=[p for p in trial['problems'] if p['stage']=='train'];conf=[p for p in trial['problems'] if p['stage']=='confirm'];cfgs=trial['configs'];active=[c['id'] for c in cfgs];alltrain={};allconfirm={};low={};unif={}
        for cfg in cfgs:
            cid=cfg['id'];trainvals=[];testvals=[];lowvals=[];uvals=[]
            for p in train:
                full=full_arrays((tr,'sh',cid,p['id']));uniform=full_arrays((tr,'uniform',cid,p['id']));assert full['end_FE']==7240 and uniform['end_FE']==1960
                for k in ['values','point_hashes','trace']:assert np.array_equal(full[k][:49],uniform[k]);prefix_tests+=1
                trainvals.append(full['trace'][-1,1]);lowvals.append(full['trace'][12,1]);uvals.append(uniform['trace'][-1,1])
                if cid==sel['sh']:
                    obj=DE(p,cfg);re=obj.advance(7240);replay_FE+=7240;replay_n+=1
                    for k in ['values','point_hashes','trace']:assert np.array_equal(re[k],full[k])
            for p in conf:testvals.append(finalbest(tr,'confirmation',cid,p['id']))
            alltrain[cid]=independent_score(trainvals);allconfirm[cid]=independent_score(testvals);low[cid]=independent_score(lowvals);unif[cid]=independent_score(uvals)
            scores_table.append({'trial':tr,'config':cid,'F':cfg['F'],'CR':cfg['CR'],'train520':low[cid],'train1960':unif[cid],'train7240':alltrain[cid],'confirmation7240':allconfirm[cid]})
        for k,end in enumerate([520,1480,3400,7240]):
            scr={cid:independent_score([full_arrays((tr,'sh',cid,p['id']))['trace'][end//40-1,1] for p in train]) for cid in active}
            survivors=sorted(active,key=lambda cid:(scr[cid],cid))[:len(active)//2]
            assert survivors==sel['rounds'][k]['survivors'];active=survivors
        assert active[0]==sel['sh'];assert min(unif,key=lambda cid:(unif[cid],cid))==sel['uniform']
        trainoracle=min(alltrain,key=lambda cid:(alltrain[cid],cid));testoracle=min(allconfirm,key=lambda cid:(allconfirm[cid],cid));testordered=sorted(allconfirm,key=lambda cid:(allconfirm[cid],cid))
        def eliminated_round(cid):
            for r in sel['rounds']:
                if cid in r['candidates'] and cid not in r['survivors']:return r['rung']+1
            return None
        rankslow={cid:i for i,cid in enumerate(sorted(low,key=lambda cid:(low[cid],cid)))};rankshigh={cid:i for i,cid in enumerate(sorted(alltrain,key=lambda cid:(alltrain[cid],cid)))}
        rho=1-6*sum((rankslow[cid]-rankshigh[cid])**2 for cid in low)/(16*(16*16-1))
        delta=allconfirm[sel['sh']]-allconfirm[sel['uniform']]
        byfamily={f:independent_score([finalbest(tr,'confirmation',sel['sh'],p['id']) for p in conf if p['family']==f])-independent_score([finalbest(tr,'confirmation',sel['uniform'],p['id']) for p in conf if p['family']==f]) for f in plan['families']}
        trialresults.append({'trial':tr,'sh_config':sel['sh'],'uniform_config':sel['uniform'],'sh_confirmation_score':allconfirm[sel['sh']],'uniform_confirmation_score':allconfirm[sel['uniform']],'difference':delta,'ratio':10**delta,'family_differences':byfamily,'sh_test_rank':testordered.index(sel['sh'])+1,'uniform_test_rank':testordered.index(sel['uniform'])+1,'train_oracle':trainoracle,'train_oracle_eliminated_round':eliminated_round(trainoracle),'confirmation_oracle':testoracle,'confirmation_oracle_eliminated_round':eliminated_round(testoracle),'first_rung_rank_spearman_vs_full_training':rho})
    checks+=['all_1536_training_trajectories_paired_prefix_equal','all_96_SH_winner_trajectories_full_uninterrupted_replay','all_selections_independently_recomputed']
    actual=sum(r['actual_FE'] for r in rows);assert actual==summary['actual_FE'];assert len(groups)==5376
    for tr in range(12):
        for m in ['sh','uniform']:assert sum(r['actual_FE'] for r in rows if r['trial']==tr and r['method']==m and r['phase']=='search')==250880
    delta=np.array([r['difference'] for r in trialresults]);rng=np.random.Generator(np.random.PCG64(plan['statistics_seed']));boot=np.mean(delta[rng.integers(0,len(delta),size=(20000,len(delta)))],axis=1);wins=int(np.sum(delta<-1e-12));losses=int(np.sum(delta>1e-12));ties=12-wins-losses;n=wins+losses;signp=min(1.,2*sum(math.comb(n,k) for k in range(min(wins,losses)+1))/2**n) if n else 1.
    result={'n_independent_HPO_trials':12,'mean_difference_log10_SH_minus_uniform':float(np.mean(delta)),'median_ratio_of_normalized_geomean_losses_SH_over_uniform':float(np.median(10**delta)),'mean_difference_bootstrap95_percentile':np.quantile(boot,[.025,.975]).tolist(),'wins_ties_losses_SH':[wins,ties,losses],'exact_two_sided_sign_p':signp,'train_oracle_discarded':sum(r['train_oracle_eliminated_round'] is not None for r in trialresults),'confirmation_oracle_discarded':sum(r['confirmation_oracle_eliminated_round'] is not None for r in trialresults),'confirmation_oracle_discarded_first_rung':sum(r['confirmation_oracle_eliminated_round']==1 for r in trialresults),'per_trial':trialresults,'all_candidate_scores':scores_table,'offline_oracle_caveat':'Paid all-candidate retrospective diagnostic only. Never used in actual selection; finite pool and fixed budget, not true global optimum or deployed selector.'}
    dump(ROOT/'results/analysis.json',result)
    audit={'passed':True,'checks':checks,'segment_count':len(rows),'unique_trajectories':len(groups),'independent_scalar_point_samples':sample_n,'additional_final_population_scalar_checks':40*len(rows),'max_scaled_sample_error':maxerr,'actual_optimizer_FE':actual,'paired_prefix_array_comparisons':prefix_tests,'full_uninterrupted_replay_trajectories':replay_n,'replay_FE':replay_FE,'audit_cpu_seconds':time.process_time()-cpu,'audit_wall_seconds':time.monotonic()-t,'planned_denominator':{'HPO_trials':12,'search_trajectories_per_method':1536,'confirmation_trajectories_all_configs':2304},'failures':0}
    dump(ROOT/'results/audit.json',audit);print(json.dumps(audit));print(json.dumps({k:v for k,v in result.items() if k not in ['per_trial','all_candidate_scores']}))
if __name__=='__main__':main()
