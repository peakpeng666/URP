"""Only formal run entry; executed under external CPU180s/wall600s hard limits."""
import csv,datetime,hashlib,itertools,json,math,sys,time,traceback
from pathlib import Path
import numpy as np
import core,reference
R=Path(__file__).resolve().parents[1]
def dump(p,obj):p.write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
start=time.monotonic();cpu=time.process_time();P=json.loads((R/'protocol.json').read_text());M=json.loads((R/'PRE_RUN_MANIFEST.json').read_text())
for name,entry in M['files'].items():assert sha(R/name)==entry['sha256'],f'Frozen file changed: {name}'
assert not (R/'results/runs.jsonl').exists(), 'Do not rerun or append a second attempt.'
q=np.load(R/'inputs/Q.npy',allow_pickle=False)
T={seed:dict(np.load(R/f'inputs/random_tape_{seed}.npz',allow_pickle=False)) for seed in P['search_seeds']}
rows=[];status='running';optimization_start_meter=None;optimization_end_meter=None
validation={'start_utc':now(),'status':'running','prechecks':{},'final_population_checks':[],'reference_replays':[]}
progress={'planned_runs':256,'completed_runs':0,'failed_runs':0,'formal_objective_fe':0}
dump(R/'results/progress.json',progress)
try:
    orth=float(np.max(np.abs(q.T@q-np.eye(10))));det=float(np.linalg.det(q))
    assert orth<=1e-12 and abs(det-1.)<=1e-12
    validation['prechecks'].update(q_orthogonality_max_abs=orth,q_determinant=det,q_sha256=sha(R/'inputs/Q.npy'))
    # Scalar and vector implementations see exactly the pre-frozen test vectors.
    points=np.load(R/'inputs/objective_test_points.npy',allow_pickle=False);test_values={};max_ref_rel=0.
    for family in P['families']:
        for orientation in P['orientations']:
            vector=core.Objective(family,orientation,q)(points)
            scalar=np.array([reference.value(x,family,orientation,q) for x in points])
            assert np.allclose(vector,scalar,rtol=1e-12,atol=1e-12)
            assert vector[0]==0. and scalar[0]==0.
            max_ref_rel=max(max_ref_rel,float(np.max(np.abs(vector-scalar)/np.maximum(np.abs(scalar),1e-300))))
            test_values[family+'_'+orientation]=vector
    sphere_abs=float(np.max(np.abs(test_values['sphere_rotated']-test_values['sphere_axis'])))
    sphere_rel=float(np.max(np.abs(test_values['sphere_rotated']-test_values['sphere_axis'])/np.maximum(test_values['sphere_axis'],1e-300)))
    assert np.allclose(test_values['sphere_rotated'],test_values['sphere_axis'],rtol=1e-12,atol=1e-12)
    validation['prechecks'].update(objective_test_points=len(points),pointwise_objective_comparison_max_relative_error=max_ref_rel,sphere_invariance_max_abs=sphere_abs,sphere_invariance_max_relative=sphere_rel,all_optima_zero=True)
    np.savez_compressed(R/'validation/objective_test_values.npz',**test_values)
    optimization_start_meter=core.EVALUATED_POINTS
    with (R/'results/runs.jsonl').open('w') as jl,(R/'results/runs.csv').open('w',newline='') as csvout,(R/'results/curves.csv').open('w',newline='') as curves:
        fields=['run_id','family','orientation','config_id','F','CR','seed','fe','final_best_loss','log10_loss_eps','elapsed_wall_seconds']
        cw=csv.DictWriter(csvout,fieldnames=fields);cw.writeheader();tc=csv.writer(curves);tc.writerow(['run_id','generation','fe','best_loss'])
        for family,orientation,cfg,seed in itertools.product(P['families'],P['orientations'],P['configs'],P['search_seeds']):
            run_id=f'{family}_{orientation}_{cfg["id"]}_s{seed}';active_run_id=run_id;ts=time.monotonic()
            result=core.run(T[seed],cfg,family,orientation,q)
            assert result['fe']==2000
            assert np.all(np.diff(result['curve_best_loss'])<=0.)
            loss=result['final_best_loss']
            record={'run_id':run_id,'family':family,'orientation':orientation,'config_id':cfg['id'],'F':cfg['F'],'CR':cfg['CR'],'seed':seed,'fe':result['fe'],'final_best_loss':loss,'log10_loss_eps':math.log10(loss+1e-12),'elapsed_wall_seconds':time.monotonic()-ts}
            arrays={k:v for k,v in result.items() if isinstance(v,np.ndarray)}
            output=R/f'results/{run_id}.npz';np.savez_compressed(output,**arrays)
            jl.write(json.dumps(dict(record,best_vector=result['best_vector'].tolist(),output_file=str(output.relative_to(R)),output_sha256=sha(output)))+'\n');jl.flush()
            cw.writerow(record);csvout.flush()
            for gen,v in enumerate(result['curve_best_loss']):tc.writerow([run_id,gen,20*(gen+1),float(v)])
            curves.flush();rows.append(record)
            progress.update(completed_runs=len(rows),formal_objective_fe=core.EVALUATED_POINTS-optimization_start_meter,last_completed_run_id=run_id)
            dump(R/'results/progress.json',progress)
            if len(rows)%32==0:print(json.dumps({'at':now(),**progress}),flush=True)
    optimization_end_meter=core.EVALUATED_POINTS
    assert len(rows)==256 and sum(r['fe'] for r in rows)==512000
    assert optimization_end_meter-optimization_start_meter==512000
    # Validate every final vector, not just the selected best individual.
    max_final_relative=0.;max_final_absolute=0.
    for row in rows:
        a=np.load(R/f'results/{row["run_id"]}.npz',allow_pickle=False)
        ref=np.array([reference.value(x,row['family'],row['orientation'],q) for x in a['final_population']])
        err=np.abs(ref-a['final_fitness']);rel=err/np.maximum(np.abs(ref),1e-300)
        assert np.allclose(ref,a['final_fitness'],rtol=1e-10,atol=1e-10)
        assert np.all(np.abs(a['final_population'])<=5.)
        assert a['eval_values'].shape==(100,20) and a['curve_best_loss'].shape==(100,)
        assert np.allclose(a['curve_best_loss'],np.minimum.accumulate(np.min(a['eval_values'],axis=1)),rtol=1e-14,atol=1e-14)
        assert row['final_best_loss']==float(a['final_fitness'].min())
        assert np.array_equal(a['best_vector'],a['final_population'][int(np.argmin(a['final_fitness']))])
        max_final_relative=max(max_final_relative,float(np.max(rel)));max_final_absolute=max(max_final_absolute,float(np.max(err)))
        validation['final_population_checks'].append({'run_id':row['run_id'],'vectors':20,'max_absolute_error':float(np.max(err)),'max_relative_error':float(np.max(rel)),'pass':True})
    validation['final_population_summary']={'runs':256,'vectors':5120,'max_absolute_error':max_final_absolute,'max_relative_error':max_final_relative}
    pre=P['reference_replay_preselected']
    for row in rows:
        if row['seed'] not in pre['search_seeds'] or row['config_id'] not in pre['configs']:continue
        cfg=next(c for c in P['configs'] if c['id']==row['config_id'])
        rr=reference.replay(T[row['seed']],cfg,row['family'],row['orientation'],q)
        main=np.load(R/f'results/{row["run_id"]}.npz',allow_pickle=False)
        assert rr['fe']==2000
        assert np.allclose(rr['final_population'],main['final_population'],rtol=1e-12,atol=1e-12)
        assert np.allclose(rr['final_fitness'],main['final_fitness'],rtol=1e-9,atol=1e-9)
        assert np.allclose(rr['curve_best_loss'],main['curve_best_loss'],rtol=1e-9,atol=1e-9)
        rr['run_id']=row['run_id'];rr['purpose']='validation_only_not_new_experiment_sample'
        dump(R/f'validation/reference_{row["run_id"]}.json',rr)
        validation['reference_replays'].append({'run_id':row['run_id'],'fe':rr['fe'],'max_population_abs_difference':float(np.max(np.abs(np.asarray(rr['final_population'])-main['final_population']))),'max_curve_abs_difference':float(np.max(np.abs(np.asarray(rr['curve_best_loss'])-main['curve_best_loss']))),'pass':True})
    assert len(validation['reference_replays'])==8
    index={(r['family'],r['orientation'],r['config_id'],r['seed']):r for r in rows}
    rankings={};config_stats=[];paired=[]
    for family in P['families']:
        scores={}
        for orientation in P['orientations']:
            score={cfg['id']:math.fsum(index[(family,orientation,cfg['id'],s)]['log10_loss_eps'] for s in P['search_seeds'])/4 for cfg in P['configs']}
            order=sorted(score,key=lambda c:(score[c],c));ranks={c:i+1 for i,c in enumerate(order)}
            scores[orientation]={'mean_log10_loss_eps':score,'order':order,'ranks':ranks}
        inversions=0
        for x,y in itertools.combinations([c['id'] for c in P['configs']],2):
            inversions+=int((scores['axis']['ranks'][x]-scores['axis']['ranks'][y])*(scores['rotated']['ranks'][x]-scores['rotated']['ranks'][y])<0)
        rank_diffs=[]
        for cfg in P['configs']:
            deltas=[]
            for seed in P['search_seeds']:
                a=index[(family,'axis',cfg['id'],seed)];b=index[(family,'rotated',cfg['id'],seed)];delta=b['log10_loss_eps']-a['log10_loss_eps'];deltas.append(delta)
                paired.append({'family':family,'config_id':cfg['id'],'seed':seed,'axis_loss':a['final_best_loss'],'rotated_loss':b['final_best_loss'],'paired_log10_delta':delta})
            rd=scores['rotated']['ranks'][cfg['id']]-scores['axis']['ranks'][cfg['id']];rank_diffs.append(rd)
            config_stats.append({'family':family,'config_id':cfg['id'],'F':cfg['F'],'CR':cfg['CR'],'axis_mean_log10_loss_eps':scores['axis']['mean_log10_loss_eps'][cfg['id']],'rotated_mean_log10_loss_eps':scores['rotated']['mean_log10_loss_eps'][cfg['id']],'axis_rank':scores['axis']['ranks'][cfg['id']],'rotated_rank':scores['rotated']['ranks'][cfg['id']],'rank_change_rotated_minus_axis':rd,'paired_mean_delta':math.fsum(deltas)/4,'paired_median_delta':float(np.median(deltas)),'paired_min_delta':min(deltas),'paired_max_delta':max(deltas)})
        scores['rank_spearman']=1-6*sum(d*d for d in rank_diffs)/(16*(16*16-1));scores['pairwise_inversions']=inversions;scores['possible_pairs']=120
        fpair=[r['paired_log10_delta'] for r in paired if r['family']==family]
        scores['all_config_seed_paired_summary']={'n_pairs':64,'mean_delta':math.fsum(fpair)/64,'median_delta':float(np.median(fpair)),'min_delta':min(fpair),'max_delta':max(fpair),'positive':sum(x>0 for x in fpair),'negative':sum(x<0 for x in fpair),'exact_zero':sum(x==0 for x in fpair)}
        rankings[family]=scores
    for name,data in [('paired_differences.csv',paired),('config_summary.csv',config_stats)]:
        with (R/'results'/name).open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
    validation['core_objective_test_fe']=optimization_start_meter
    validation['reference_total_fe']=reference.EVALUATED_POINTS
    validation['validation_fe']=core.EVALUATED_POINTS-512000+reference.EVALUATED_POINTS
    assert validation['validation_fe']==21632
    validation.update(status='passed',end_utc=now())
    dump(R/'validation/validation.json',validation)
    summary={'status':'completed','experiment_id':P['experiment_id'],'frozen_protocol_sha256':sha(R/'protocol.json'),'completed_runs':256,'failed_runs':0,'optimization_fe':512000,'validation_fe':validation['validation_fe'],'all_objective_evaluations':512000+validation['validation_fe'],'rankings':rankings,'config_summary':config_stats,'pointwise_sphere_negative_control_max_relative_error':sphere_rel,'end_utc':now(),'numerics_and_validation_elapsed_wall_seconds':time.monotonic()-start,'numerics_and_validation_process_cpu_seconds':time.process_time()-cpu}
    dump(R/'results/summary.json',summary);status='completed'
    print(json.dumps({'status':status,'completed_runs':256,'optimization_fe':512000,'validation_fe':21632,'rankings':rankings}),flush=True)
except BaseException as e:
    status='failed';traceback.print_exc()
    progress['failed_runs']=1 if len(rows)<256 else 0
    dump(R/'results/first_failure.json',{'time_utc':now(),'error_type':type(e).__name__,'error':str(e),'traceback':traceback.format_exc(),'active_run_id':locals().get('active_run_id'),'completed_runs':len(rows),'core_evaluated_points':core.EVALUATED_POINTS,'reference_evaluated_points':reference.EVALUATED_POINTS})
    validation.update(status='failed',error=str(e));dump(R/'validation/validation.json',validation)
    raise
finally:
    progress.update(status=status,completed_runs=len(rows),core_evaluated_points=core.EVALUATED_POINTS,reference_evaluated_points=reference.EVALUATED_POINTS,end_utc=now(),elapsed_wall_seconds=time.monotonic()-start,process_cpu_seconds=time.process_time()-cpu)
    dump(R/'results/progress.json',progress)
