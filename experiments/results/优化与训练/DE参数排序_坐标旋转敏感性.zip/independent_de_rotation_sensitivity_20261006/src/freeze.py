"""Create the frozen design and exact random input bytes, before any objective calls."""
import json, hashlib, platform, sys, datetime
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
def dump(p,o):p.write_text(json.dumps(o,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert not (ROOT/'PRE_RUN_MANIFEST.json').exists(), 'Do not overwrite a frozen design.'
configs=[{'id':f'F{f:.1f}_CR{cr:.1f}','F':f,'CR':cr} for f in [.4,.6,.8,1.] for cr in [.1,.3,.7,.9]]
seeds=[202610060701,202610060702,202610060703,202610060704]
qseed=202610069999
q,r=np.linalg.qr(np.random.Generator(np.random.PCG64(qseed)).normal(size=(10,10)))
q=q*np.where(np.diag(r)<0,-1.,1.)[None,:]
# A proper rotation, deterministic column sign, without drawing additional random values.
if np.linalg.det(q)<0:q[:,-1]*=-1
np.save(ROOT/'inputs/Q.npy',q,allow_pickle=False)
np.savetxt(ROOT/'inputs/Q.csv',q,delimiter=',',fmt='%.17g')
for seed in seeds:
    init=np.random.Generator(np.random.PCG64(np.random.SeedSequence([seed,0]))).uniform(-5.,5.,size=(20,10))
    rng=np.random.Generator(np.random.PCG64(np.random.SeedSequence([seed,1])))
    a=np.empty((99,20),dtype=np.int64);b=a.copy();c=a.copy();u=np.empty((99,20,10));forced=a.copy()
    for g in range(99):
        a[g]=rng.integers(0,19,size=20);b[g]=rng.integers(0,18,size=20);c[g]=rng.integers(0,17,size=20)
        u[g]=rng.random((20,10));forced[g]=rng.integers(0,10,size=20)
    np.savez_compressed(ROOT/f'inputs/random_tape_{seed}.npz',initial_population=init,donor_rank_a=a,donor_rank_b=b,donor_rank_c=c,crossover_uniform=u,forced_coordinate=forced)
protocol={
 'experiment_id':ROOT.name,'frozen_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'question':'Fixed-budget DE parameter ranking sensitivity to a fixed orthogonal coordinate rotation.',
 'not_original_research':'Independent synthetic experiment, no original132 reads or writes; no model calls or dependency installation.',
 'dimension':10,'bounds':[-5.,5.],'optimum':[0.]*10,'families':['sphere','ellipsoid'],'orientations':['axis','rotated'],
 'objective_formulas':{'sphere_axis':'sum_i x_i**2','sphere_rotated':'sum_i (Q @ x)_i**2','ellipsoid_axis':'sum_i 10**(6*i/9)*x_i**2','ellipsoid_rotated':'sum_i 10**(6*i/9)*(Q @ x)_i**2'},
 'rotation_seed':qseed,'rotation_generation':'numpy PCG64 normal(10,10); QR; normalize R diagonal signs; flip final Q column if det(Q)<0. Stored Q.npy is authoritative.',
 'search_seeds':seeds,'rng_plan':'Initial: PCG64(SeedSequence([seed,0])); operators: PCG64(SeedSequence([seed,1])). For each of 99 generations, draw a rank[0,19), b rank[0,18), c rank[0,17), each 20; crossover uniforms (20,10); forced dimensions 20 in [0,10). Map each donor rank into sorted indices excluding target and earlier donors. Save all bytes before objective calls. Across configs/families/orientations, same seed uses identical initial population and operator tape.',
 'algorithm':'Synchronous DE/rand/1/bin, strict fitness improvement (<), float64, coordinate clip after binomial crossover, one forced coordinate per target, donors distinct and exclude target.',
 'population':20,'generations':99,'fe_per_run':2000,'planned_runs':256,'planned_optimization_fe':512000,'configs':configs,
 'ranking':'Ascending arithmetic mean across 4 seeds of log10(final_best_loss + 1e-12), separately by family and orientation; exact ties use config ID only for display.',
 'paired_metric':'Per family/config/seed: log10(rotated_loss+1e-12) - log10(axis_loss+1e-12). Summarize each config by mean, median, minimum, maximum. Positive means rotation worsened loss.',
 'rank_change_metrics':['config rank_rotated - rank_axis','Spearman correlation of 16 ranks','Kendall pairwise inversion count of 120 unordered config pairs'],
 'reference_replay_preselected':{'configs':['F0.4_CR0.1','F1.0_CR0.9'],'search_seeds':[seeds[0]],'families':['sphere','ellipsoid'],'orientations':['axis','rotated'],'runs':8,'fe':16000},
 'validation':'Independent scalar objective on every final population member (5120 evaluations); 8 preselected scalar DE full replays (16000 evaluations); 64 pre-frozen test points used for objective checks and Sphere rotational invariance (512 evals); total expected validation FE 21632, separate from optimization budget. Q.T@Q orthogonality and det also checked. Validation is not new experiment samples.',
 'tolerances':{'q_max_abs_orthogonality_error':1e-12,'q_determinant_abs_error':1e-12,'sphere_pointwise_relative':1e-12,'final_fitness_relative':1e-10,'final_fitness_absolute':1e-10,'reference_trace_relative':1e-9,'reference_trace_absolute':1e-9,'reference_vectors_relative':1e-12,'reference_vectors_absolute':1e-12},
 'limits':{'entire_numerics_and_validation_child_cpu_seconds':180,'entire_numerics_and_validation_child_wall_seconds':600},
 'failure_policy':'One formal attempt; append completed runs incrementally, retain first failure, do not replace seeds/configurations/budget or silently rerun. Hard limit may leave partial.',
 'interpretation_limits':['Single rotation Q','Four search seeds','Synthetic D=10 Sphere and condition-number-1e6 Ellipsoid','Coordinate-aligned box clipping retained in both orientations','Descriptive grid only, no held-out selection, no statistical significance, no general DE superiority or paper reproduction claims']}
# Fixed objective-test points from a separate unused RNG; zero + 10 basis + 53 uniform points.
rng=np.random.Generator(np.random.PCG64(202610069998))
pts=np.vstack([np.zeros((1,10)),np.eye(10),rng.uniform(-5,5,(53,10))])
np.save(ROOT/'inputs/objective_test_points.npy',pts,allow_pickle=False)
dump(ROOT/'protocol.json',protocol)
dump(ROOT/'provenance/environment.json',{'python':sys.version,'numpy':np.__version__,'platform':platform.platform(),'machine':platform.machine(),'byteorder':sys.byteorder,'numerics':'float64','threads':1})
dump(ROOT/'provenance/source_reuse.json',{'reviewed_reference_path':'independent_sh_budget_20261006/src/core.py','sha256':'6871d00e07605133068672924aabac2409b5f123d3e09c2479d14bc13104a6ad','reused_design':'Vectorized rank-to-donor exclusion mapping and synchronous DE/rand/1/bin semantics. New experiment sources do not import the historical package. New objective formulas, dimensions, seeds, budgets, audit and inputs.'})
files={str(p.relative_to(ROOT)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(ROOT.rglob('*')) if p.is_file()}
dump(ROOT/'PRE_RUN_MANIFEST.json',{'frozen_at_utc':protocol['frozen_at_utc'],'files':files})
print(json.dumps({'status':'frozen','files':len(files),'protocol_sha256':sha(ROOT/'protocol.json'),'Q_sha256':sha(ROOT/'inputs/Q.npy'),'manifest_sha256':sha(ROOT/'PRE_RUN_MANIFEST.json')}))
