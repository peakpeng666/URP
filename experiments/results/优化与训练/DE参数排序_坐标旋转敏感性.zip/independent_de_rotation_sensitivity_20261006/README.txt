Independent DE coordinate-rotation sensitivity experiment, 2026-10-06
Read REPORT_ZH.md first.
256 completed research runs; 512000 optimization FE.
21632 separately-accounted validation FE; zero failed runs.
Sources, exact Q/random input tapes, raw results, analysis and CPU/wall receipt are included.
Frozen manifest: PRE_RUN_MANIFEST.json. Delivery manifest: MANIFEST.json.
Formal attempt is deliberately write-once. Do not rerun launch.py in this directory.
No original132 experiment content, model calls, dependency installations or GitHub publication.
