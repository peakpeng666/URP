# 固定 DE 数值调参材料读取说明

先读 REPORT_ZH.md。该实验已经真实执行完成，216 run、594000 次优化器目标评价；其中选择集 162 run / 324000 评价，另 54 run / 270000 评价为相同三函数上的新开发重复。不是盲测、跨函数泛化或完整 LLaMEA-HPO 复现。

## 数据归档

交付由一个报告代码 ZIP、六个原始数据 ZIP，以及 archive_manifest.json 构成。六个数据 ZIP 按 search/repeat 阶段和 Sphere/Rastrigin/Ackley 函数划分；每个都包含完整 NPZ 文件，可单独读取，不是必须拼接的分卷压缩文件。所有 ZIP 的路径以 independent_de_hpo_20261006/ 开始。

1. 先校验每个 ZIP 的 SHA256 和字节数，见 archive_manifest.json
2. 把七个 ZIP 解压到同一个父目录，路径会自然合并到 independent_de_hpo_20261006/，不应覆盖不同内容
3. 在解压后的目录执行 python src/verify_manifest.py，仅使用标准库，检查所有交付文件完整性；不会重新运行实验
4. 如果已有兼容 NumPy，可执行 python src/audit.py 从保存数组独立复算目标、预算、选优及配对；这是审计计算，不是重新优化

file_manifest.json 包含 216 个 NPZ 及报告代码等全部文件的路径、字节数、SHA256；data_inventory.json 对每个数据 NPZ 额外列出阶段、函数和评价点数。archive_manifest.json 同时给出每个数据 ZIP 的总评价点数与文件数，六包合计必须是 216 NPZ、594000 点。

不需要联网、API key、模型或作者框架。不安装依赖即可做标准库哈希核验。若要独立计算审计则需要 NumPy。运行所用 venv 未打包，因为其 NumPy 是对当前云端预装目录的只读使用链接；具体版本在 provenance/environment.json。绘图使用已安装 matplotlib，属于实验结束后的展示步骤。

## 单个 NPZ 的内容

- points：所有被评价候选，形状为 (2000,10) 或 (5000,10)，包括前 50 行初始化，按真实评价顺序保存
- values：对应原始目标值，包含未接受、重复或被裁剪的候选，不做删减
- trace：每代 [累计评价数, 历史最好值, 本批最小值, 本批均值]，共 40 或 100 行
- initial_population：50×10 初始种群
- best_x：运行记录的最终最优点，长度 10

使用 np.load(path, allow_pickle=False) 读取，不要启用 pickle。JSON 和 CSV 中同一 run_id 可查预算、参数、CPU/墙钟、最佳目标、最优点和原始数组哈希。aliases.json 记录名义角色到实际 run 的映射，本轮没有身份重复而省略执行的 run。

## 可审计的时间顺序

src/freeze.py 在运行前生成 plan.json 与 prerun_freeze.json；后者包含真实运行代码和审计代码的哈希。src/run.py 先执行合成合同测试，再完整执行选择集；随后写 selection.json 和 selection.sha256，最后执行新开发重复。selection.json 保存选优输入 JSONL 前缀的 SHA256，audit.py 已据前缀复核。

src/make_report.py、src/verify_manifest.py 与打包说明是结果产生后的展示/交付材料，没有参与选择规则或优化器执行。src/run.py 拒绝在已存在 runs.jsonl 的目录中覆盖运行。

## 阅读图表

三张图均同时提供 PNG/SVG。01 展示每函数六个同种子配对的全部最终值，横杠为中位数。02 展示中位收敛曲线和四分位区间，区间不是置信区间。03 展示全部 18 个配置的预定选优分数，菱形为两臂赢家。图像已目视检查，无缺字、裁剪、图例遮挡。
