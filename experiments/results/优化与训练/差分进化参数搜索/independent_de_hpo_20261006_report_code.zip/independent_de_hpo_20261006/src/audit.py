"""Independent ledger auditor: no import of trusted optimizer or objective code."""
from pathlib import Path
import csv, hashlib, json, math, time
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def dump(path,value): path.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def independent_values(name,points):
    # Scalar standard-library formulas; deliberately separate from NumPy source formulas.
    def evaluate(x):
        sq=math.fsum(float(v)*float(v) for v in x)
        if name=='Sphere': return sq
        cs=math.fsum(math.cos(2*math.pi*float(v)) for v in x)
        if name=='Rastrigin': return 10*len(x)+sq-10*cs
        return -20*math.exp(-.2*math.sqrt(sq/len(x)))-math.exp(cs/len(x))+20+math.e
    return np.array([evaluate(x) for x in points])

def main():
    start=time.monotonic(); cpu=time.process_time()
    plan=json.loads((ROOT/'plan.json').read_text()); freeze=json.loads((ROOT/'prerun_freeze.json').read_text())
    rows=json.loads((ROOT/'results/runs.json').read_text()); aliases=json.loads((ROOT/'results/aliases.json').read_text())
    selection=json.loads((ROOT/'results/selection.json').read_text()); summary=json.loads((ROOT/'results/run_summary.json').read_text())
    checks=[]; failures=[]; verified=[]; recomputed={}
    def check(condition,label):
        checks.append(label)
        if not condition: failures.append(label)
    for path,h in freeze['files'].items(): check(sha(ROOT/path)==h,'frozen_source:'+path)
    check(sha(ROOT/'results/selection.json')==(ROOT/'results/selection.sha256').read_text().strip(),'selection_sha256')
    lines=(ROOT/'results/runs.jsonl').read_bytes().splitlines(keepends=True)
    search_lines=b''.join(line for line in lines if json.loads(line)['stage']=='search')
    check(hashlib.sha256(search_lines).hexdigest()==selection['input_runs_sha256'],'selection_input_search_ledger_hash')
    init_groups={}; states={}; params={}; total=0; max_abs=0.; max_rel=0.
    for row in rows:
        rid=row['run_id']; path=ROOT/row['ledger_path']; f=plan['functions'][row['function_index']]
        check(sha(path)==row['ledger_sha256'],rid+':ledger_hash')
        with np.load(path,allow_pickle=False) as data:
            p=data['points']; values=data['values']; trace=data['trace']; x0=data['initial_population']; best_x=data['best_x']
            check(p.shape==(row['budget'],plan['dimension']),rid+':candidate_shape_exact_budget')
            check(len(values)==row['evaluations']==row['budget'],rid+':charged_exact_budget')
            check(np.all(np.isfinite(p)) and np.all(p>=f['lower']) and np.all(p<=f['upper']),rid+':every_candidate_in_bounds_finite')
            check(np.array_equal(p[:50],x0),rid+':initial_population_charged_first')
            h=hashlib.sha256(np.ascontiguousarray(x0,dtype='<f8').tobytes()).hexdigest()
            check(h==row['initial_population_sha256'],rid+':initial_hash')
            # Regenerate only initial population, not an optimization run.
            rng=np.random.Generator(np.random.PCG64(np.random.SeedSequence([plan['root_seed'],row['function_index'],row['seed'],0])))
            expected_x0=rng.uniform(f['lower'],f['upper'],(plan['population_size'],plan['dimension']))
            check(np.array_equal(x0,expected_x0),rid+':initial_matches_frozen_seed')
            y=independent_values(row['function'],p); total+=len(y)
            errors=np.abs(y-values); absolute=float(errors.max()); relative=float((errors/np.maximum(np.abs(y),1)).max())
            max_abs=max(max_abs,absolute); max_rel=max(max_rel,relative)
            check(np.allclose(values,y,rtol=1e-12,atol=2e-12),rid+':all_values_independently_recomputed')
            idx=int(np.argmin(values)); best=float(values[idx]); recomputed[rid]=float(y[int(np.argmin(y))])
            check(best==row['best_f'],rid+':best_matches_all_values')
            check(np.array_equal(best_x,p[idx]) and np.array_equal(best_x,row['best_x']),rid+':best_point_is_first_ledger_minimum')
            independent_best=independent_values(row['function'],np.asarray([best_x]))[0]
            check(math.isclose(float(independent_best),row['best_f'],rel_tol=1e-12,abs_tol=2e-12),rid+':best_point_recalculation')
            generation=values.reshape(-1,50); minimum=np.minimum.accumulate(generation.min(axis=1))
            check(np.array_equal(trace[:,0],np.arange(50,row['budget']+1,50)),rid+':trace_evaluation_counts')
            check(np.array_equal(trace[:,1],minimum),rid+':trace_running_best')
            check(np.array_equal(trace[:,2],generation.min(axis=1)),rid+':trace_batch_minimum')
            check(np.array_equal(trace[:,3],generation.mean(axis=1)),rid+':trace_batch_mean')
            check(int(np.sum((p==f['lower'])|(p==f['upper'])))==row['boundary_coordinate_count'],rid+':boundary_coordinate_count')
            group=(row['stage'],row['function'],row['seed'])
            init_groups.setdefault(group,set()).add(h)
            states.setdefault(group,set()).add(json.dumps([row['rng_initial'],row['rng_final']],sort_keys=True))
            identity=group+(row['F'],row['CR'])
            check(identity not in params,rid+':not_duplicate_physical_run');params[identity]=rid
            verified.append({'run_id':rid,'recomputed_best_f':recomputed[rid],'max_abs_objective_error':absolute,'max_scaled_objective_error':relative,'evaluations_checked':len(y)})
    for group,hashes in init_groups.items(): check(len(hashes)==1,str(group)+':paired_initial_population')
    for group,stateset in states.items(): check(len(stateset)==1,str(group)+':paired_operator_stream_start_and_end')
    byid={r['run_id']:r for r in rows}
    check(len(aliases)==216,'nominal_alias_count_216')
    for alias in aliases: check(alias['actual_run_id'] in byid,'alias_exists:'+alias['actual_run_id'])
    score_rows=[]
    for config in plan['search']['configs']:
        ids=[a['actual_run_id'] for a in aliases if a['stage']=='search' and a['alias']==config['id']]
        check(len(ids)==9,config['id']+':selection_nine_blocks')
        score=math.fsum(math.log10(max(recomputed[rid],1e-16)) for rid in ids)/9
        rawscore=math.fsum(math.log10(max(byid[rid]['best_f'],1e-16)) for rid in ids)/9
        saved=next(s for s in selection['all_scores'] if s['id']==config['id'])
        check(rawscore==saved['score'],config['id']+':selection_recalculation_exact_saved_values')
        score_rows.append({**config,'independent_recomputed_score':score,'saved_value_recomputed_score':rawscore})
    for arm in ['grid','random']:
        win=min((s for s in score_rows if s['arm']==arm),key=lambda s:(s['independent_recomputed_score'],s['id']))
        check(win['id']==selection['winners'][arm]['id'],arm+':winner_independently_recomputed')
    check(total==summary['actual_evaluations'],'total_evaluations_match')
    check(sum(r['evaluations'] for r in rows if r['stage']=='search')==324000,'search_budget_324000')
    check(sum(r['evaluations'] for r in rows if r['stage']=='repeat')<=270000,'repeat_actual_budget_not_exceed_nominal')
    check(set(plan['search']['seeds']).isdisjoint(plan['repeat']['seeds']),'search_and_repeat_seeds_disjoint')
    check(all(r['status']=='complete' and r['error'] is None for r in rows),'no_failed_or_truncated_runs')
    check(summary['wall_seconds']<=300 and summary['compute_processes']==1,'wall_clock_and_process_contract')
    functions=[]; aggregate={}
    for fn in plan['functions']:
        values={}
        for role in plan['repeat']['roles']:
            matches=[a for a in aliases if a['stage']=='repeat' and a['function']==fn['name'] and a['alias']==role]
            matches.sort(key=lambda a:plan['repeat']['seeds'].index(a['seed']))
            values[role]=np.array([byid[a['actual_run_id']]['best_f'] for a in matches])
        comparisons={}
        for role in ['grid_winner','random_winner']:
            a=values[role]; b=values['default']; ratios=a/b
            comparisons[role]={'paired_median_ratio_vs_default':float(np.median(ratios)), 'wins':int(np.sum(a<b)), 'ties':int(np.sum(a==b)), 'losses':int(np.sum(a>b)),
                'paired_ratios':ratios.tolist()}
        functions.append({'function':fn['name'],'median_best_f':{k:float(np.median(v)) for k,v in values.items()},'all_paired_best_f':{k:v.tolist() for k,v in values.items()},'comparisons':comparisons})
    for role in plan['repeat']['roles']:
        vals=[byid[a['actual_run_id']]['best_f'] for a in aliases if a['stage']=='repeat' and a['alias']==role]
        aggregate[role]={'mean_log10_best_f':math.fsum(math.log10(max(v,1e-16)) for v in vals)/len(vals), 'n_function_seed_blocks':len(vals)}
    result={'passed':len(failures)==0,'checks':len(checks),'failures':failures,'actual_optimization_evaluations_recomputed':total,
        'additional_best_point_checks':len(rows),'unit_test_evaluations':json.loads((ROOT/'results/prerun_tests.json').read_text())['optimizer_or_test_objective_calls'],
        'max_abs_objective_error':max_abs,'max_scaled_objective_error':max_rel,'per_run':verified,'independently_recomputed_search_scores':score_rows,
        'wall_seconds':time.monotonic()-start,'cpu_seconds':time.process_time()-cpu}
    dump(ROOT/'results/audit.json',result)
    dump(ROOT/'results/analysis.json',{'functions':functions,'aggregate':aggregate,'interpretation':'Exploratory, same 3 known functions, fresh development repeats only. Paired blocks are not independent functions. No significance test or cross-function claim.'})
    dump(ROOT/'results/audit_check_labels.json',checks)
    print(json.dumps({k:v for k,v in result.items() if k not in ['per_run','independently_recomputed_search_scores']},indent=2))
    print(json.dumps({'functions':functions,'aggregate':aggregate},indent=2))
    if failures: raise SystemExit(1)

if __name__=='__main__':main()
