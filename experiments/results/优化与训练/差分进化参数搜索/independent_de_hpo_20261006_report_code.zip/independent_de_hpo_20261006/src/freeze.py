"""Freeze this fresh component experiment before any optimization evaluation."""
from pathlib import Path
import hashlib, json, sys, platform, datetime
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
DOMAIN = 'dot.independent.de-hpo.component.20261006.v1'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def seed(label): return int.from_bytes(hashlib.sha256((DOMAIN + ':' + label).encode()).digest()[:8], 'little')
def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+'\n')

if __name__ == '__main__':
    assert not (ROOT/'plan.json').exists(), 'Refusing to overwrite frozen plan'
    grid=[{'id':f'grid_{i:02}', 'arm':'grid', 'F':f, 'CR':cr} for i,(f,cr) in enumerate((f,cr) for f in [.3,.5,.8] for cr in [.2,.5,.9])]
    rng=np.random.Generator(np.random.PCG64(seed('parameter-sampling')))
    random=[{'id':f'random_{i:02}', 'arm':'random', 'F':float(rng.uniform(.3,.8)), 'CR':float(rng.uniform(.2,.9))} for i in range(9)]
    plan={'experiment_id':DOMAIN, 'created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'scope':'Fixed trusted DE numerical parameter tuning only; fresh development repeats, not holdout or BBOB or LLaMEA-HPO reproduction',
        'dimension':10, 'population_size':50, 'root_seed':seed('root'), 'parameter_sampling_seed':seed('parameter-sampling'),
        'rng':'NumPy PCG64; seed derivation SHA256(namespace:label), first 8 bytes little-endian',
        'functions':[{'name':'Sphere','lower':-5.12,'upper':5.12}, {'name':'Rastrigin','lower':-5.12,'upper':5.12}, {'name':'Ackley','lower':-32.768,'upper':32.768}],
        'search':{'seeds':[seed('search-repeat-'+str(i)) for i in range(3)],'budget':2000,'configs':grid+random,'evaluations_per_arm':162000},
        'repeat':{'seeds':[seed('fresh-development-repeat-'+str(i)) for i in range(6)], 'budget':5000,
            'roles':['grid_winner','random_winner','default'], 'default':{'F':.5,'CR':.9},'nominal_evaluations':270000},
        'selection':{'metric':'mean(log10(max(best_f,1e-16))) over the 3 functions and 3 search seeds',
            'tie_break':'ascending frozen config id', 'failure':'Any incomplete/failed search panel prevents winner selection; no imputation or replacements',
            'freeze':'Write selection.json and SHA256 before any fresh-repeat objective calls'},
        'pairing':'Same initial population and identical operator random stream across configs for each function/seed. Initialization uses P1 SeedSequence([root_seed,function_index,seed,0]); operator SeedSequence([root_seed,function_index,seed,3]).',
        'execution_order':'Search: function order, seed order, then all grid configs then random configs in frozen list order. Repeat: function order, seed order, deduplicated role order.',
        'deduplication':'Within each stage, exact F/CR float identity shares one actual run for a paired function/seed; aliases recorded. No duplicated rows treated as independent.',
        'budgets':{'nominal_evaluations':594000,'nominal_search_runs':162,'nominal_repeat_runs':54,'wallclock_limit_seconds':300,'compute_processes':1,'native_threads':1},
        'failure_policy':'Preserve partial candidate ledger and error, stop on hard wall clock or any error; no restarts, no dropped runs.',
        'auditing':'Save every evaluated candidate and value, best point, generation trace, init hash, RNG start/end states, CPU/wall time. Independent evaluator recomputes all saved points and selection after run.',
        'no_historical_data':'No reads of old result/data files or historical/holdout seed files. Existing source review and targeted README source metadata were inspected; this is development, not blind.',
        'analysis':'Report per-function paired values and median ratios, win/tie/loss and descriptive aggregate log scores; no confirmatory significance or cross-function generalization claim.'}
    assert len(set(plan['search']['seeds']+plan['repeat']['seeds']))==9
    dump(ROOT/'plan.json',plan)
    sources=[]
    for p in sorted((ROOT/'sources').rglob('*.py'))+sorted((ROOT/'provenance').glob('*.md')):
        sources.append({'path':str(p.relative_to(ROOT)),'sha256':sha(p),'bytes':p.stat().st_size})
    dump(ROOT/'provenance/source_manifest.json',{'sources':sources, 'paper':'https://arxiv.org/abs/2410.16309',
        'paper_title':'In-the-loop Hyper-Parameter Optimization for LLM-Based Automated Design of Heuristics',
        'paper_relation':'Conceptual component validation only. No author optimizer code executed.',
        'repository_status':'URP is not a Git worktree; source identified by SHA256, no invented commit.',
        'bounds_source':'URP/experiments/function_optimization/README.md lines 18–19',
        'source_origin':{'sources/function_optimization_de/src/de.py':'URP/experiments/function_optimization_de/src/de.py','sources/function_optimization/src/baselines.py':'URP/experiments/function_optimization/src/baselines.py'}})
    dump(ROOT/'provenance/environment.json',{'python':sys.version,'executable':sys.executable,'platform':platform.platform(),'numpy_version':np.__version__,
        'numpy_path':np.__file__, 'numpy_realpath':str(Path(np.__file__).resolve()), 'numpy_init_sha256':sha(Path(np.__file__)),
        'venv':'Isolated --without-pip venv; existing numpy and numpy.libs symlinked read-only by use; no installation or global environment modification',
        'filesystem_clock_notice':'UTC timestamps are process system clock values; parent orchestration clock may differ and is recorded separately in report.'})
    frozen=[ROOT/'plan.json']+list((ROOT/'sources').rglob('*.py'))+list((ROOT/'src').glob('*.py'))+[ROOT/'provenance/source_manifest.json',ROOT/'provenance/environment.json']
    dump(ROOT/'prerun_freeze.json',{'plan_sha256':sha(ROOT/'plan.json'),'files':{str(p.relative_to(ROOT)):sha(p) for p in sorted(frozen)}})
    print(json.dumps({'plan_sha256':sha(ROOT/'plan.json'),'grid_configs':grid,'random_configs':random,'search_seeds':plan['search']['seeds'],'repeat_seeds':plan['repeat']['seeds']},indent=2))
