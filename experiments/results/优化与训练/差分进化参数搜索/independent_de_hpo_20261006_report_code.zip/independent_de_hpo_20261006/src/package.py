"""Pack every evidence point in independently readable stage/function archives."""
from pathlib import Path
import json, hashlib, zipfile, datetime
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT.parent/'independent_de_hpo_20261006_delivery'
OUT.mkdir(exist_ok=True)
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def dump(path,x): path.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
rows=json.loads((ROOT/'results/runs.json').read_text())
inventory=[{'path':r['ledger_path'],'run_id':r['run_id'],'stage':r['stage'],'function':r['function'],'evaluated_points':r['evaluations'],'bytes':(ROOT/r['ledger_path']).stat().st_size,'sha256':sha(ROOT/r['ledger_path'])} for r in rows]
dump(ROOT/'data_inventory.json',{'files':inventory,'npz_file_count':len(inventory),'evaluated_points':sum(x['evaluated_points'] for x in inventory),'npz_total_bytes':sum(x['bytes'] for x in inventory),'point_coordinate_uncompressed_bytes':594000*10*8,'objective_value_uncompressed_bytes':594000*8})
originals={
    'sources/function_optimization_de/src/de.py':ROOT.parent/'URP/experiments/function_optimization_de/src/de.py',
    'sources/function_optimization/src/baselines.py':ROOT.parent/'URP/experiments/function_optimization/src/baselines.py'}
dump(ROOT/'provenance/original_source_unchanged.json',{'verified_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':[{'copy':p,'original':str(original),'copy_sha256':sha(ROOT/p),'original_sha256':sha(original),'equal':sha(ROOT/p)==sha(original)} for p,original in originals.items()]})
dump(ROOT/'provenance/visual_qa.json',{'images':['figures/01_paired_development_repeats.png','figures/02_convergence.png','figures/03_all_search_configs.png'],'method':'Displayed and visually inspected at output resolution','passed':True,'observations':'Chinese titles visible; no clipping, overlapping text, or obscuring legends; complete raw paired dots and all 18 search configs shown.'})
exclude={'.venv','.cache','.mplconfig','__pycache__'}
files=sorted(p for p in ROOT.rglob('*') if p.is_file() and not any(part in exclude for part in p.relative_to(ROOT).parts) and p.name!='file_manifest.json')
manifest={'experiment_id':'dot.independent.de-hpo.component.20261006.v1','files':[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files]}
dump(ROOT/'file_manifest.json',manifest)
entries=[]
for stage in ['search','repeat']:
    for fn in ['Sphere','Rastrigin','Ackley']:
        sub=[r for r in inventory if r['stage']==stage and r['function']==fn]
        name=f'independent_de_hpo_20261006_data_{stage}_{fn}.zip'
        with zipfile.ZipFile(OUT/name,'w',compression=zipfile.ZIP_STORED) as z:
            for row in sub: z.write(ROOT/row['path'],ROOT.name+'/'+row['path'])
        entries.append({'filename':name,'role':'complete_raw_data','stage':stage,'function':fn,'npz_files':len(sub),'evaluated_points':sum(r['evaluated_points'] for r in sub),'bytes':(OUT/name).stat().st_size,'sha256':sha(OUT/name)})
name='independent_de_hpo_20261006_report_code.zip'
with zipfile.ZipFile(OUT/name,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in files+[ROOT/'file_manifest.json']:
        if p.suffix!='.npz': z.write(p,ROOT.name+'/'+str(p.relative_to(ROOT)))
entries.append({'filename':name,'role':'report_code_plan_manifest','bytes':(OUT/name).stat().st_size,'sha256':sha(OUT/name)})
archive_manifest={'experiment_id':manifest['experiment_id'],'archives':entries,'all_under_24_MiB':all(e['bytes']<24*1024**2 for e in entries),'raw_npz_total_bytes':sum(r['bytes'] for r in inventory),'raw_npz_files':len(inventory),'raw_evaluated_points':sum(r['evaluated_points'] for r in inventory),'file_manifest_sha256':sha(ROOT/'file_manifest.json'),'instructions':'Verify archive byte count and SHA256, then extract all seven independent ZIPs into the same parent directory. Run python independent_de_hpo_20261006/src/verify_manifest.py. Each raw-data archive can also be read independently.'}
dump(OUT/'archive_manifest.json',archive_manifest)
for e in entries:
    with zipfile.ZipFile(OUT/e['filename']) as z:
        assert z.testzip() is None
        for member in z.infolist():
            rel=member.filename.split('/',1)[1]
            assert hashlib.sha256(z.read(member)).hexdigest()==sha(ROOT/rel)
dump(OUT/'archive_verification.json',{'passed':True,'archives':len(entries),'every_member_verified_against_original':True,'all_under_24_MiB':archive_manifest['all_under_24_MiB'],'total_archived_bytes':sum(e['bytes'] for e in entries)})
print(json.dumps(archive_manifest,indent=2))
