"""Bounded runner. Imports unchanged trusted source; all data is freshly generated."""
import os
for key in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:
    os.environ[key]='1'
os.environ['PYTHONDONTWRITEBYTECODE']='1'
from pathlib import Path
import json, hashlib, importlib.util, sys, time, signal, csv, traceback, math
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def dump(path,value): path.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
spec=importlib.util.spec_from_file_location('trusted_de',ROOT/'sources/function_optimization_de/src/de.py')
de=importlib.util.module_from_spec(spec); spec.loader.exec_module(de)

class LoggedObjective(de.p1.CountedObjective):
    def __post_init__(self):
        super().__post_init__(); self.points=[]
    def evaluate(self,x):
        result=super().evaluate(x)
        self.points.append(np.array(x,copy=True))
        return result

def contract_tests():
    checks=[]; calls=0
    for name in ['Sphere','Rastrigin','Ackley']:
        obj=LoggedObjective(name,2,-40,40,6)
        points=np.array([[0.,0.],[1.,1.],[-2.,3.]])
        got=obj.evaluate(points); calls+=3
        expected=[]
        for row in points:
            if name=='Sphere': v=math.fsum(float(t*t) for t in row)
            elif name=='Rastrigin': v=20+math.fsum(float(t*t)-10*math.cos(2*math.pi*float(t)) for t in row)
            else: v=-20*math.exp(-.2*math.sqrt(math.fsum(float(t*t) for t in row)/2))-math.exp(math.fsum(math.cos(2*math.pi*float(t)) for t in row)/2)+20+math.e
            expected.append(v)
        assert np.allclose(got,expected,rtol=1e-12,atol=1e-13)
        assert got[0]==0 and obj.best_f==0 and np.array_equal(obj.best_x,[0,0])
        checks.append(name+'_analytic_values_and_origin')
        for bad in [np.array([[41.,0.]]),np.array([[float('nan'),0.]])]:
            before=obj.count
            try: obj.evaluate(bad); raise AssertionError('invalid accepted')
            except ValueError: pass
            assert obj.count==before
        checks.append(name+'_bounds_nonfinite_rejected_without_charge')
        try: obj.evaluate(np.zeros((4,2))); raise AssertionError('budget overflow accepted')
        except ValueError: pass
        assert obj.count==3
        checks.append(name+'_overflow_rejected_without_charge')
    pop=np.array([[0.,1.],[2.,3.],[4.,5.],[6.,7.]])
    donors=np.array([[1,2,3],[0,2,3],[0,1,3],[0,1,2]])
    u=np.ones((4,2))*.7; forced=np.array([0,1,0,1])
    got=de.trials_from_draws(pop,donors,u,forced,.5,.2,0,6)
    expected=np.array([[1.,1.],[2.,0.],[0.,5.],[6.,0.]])
    assert np.array_equal(got,expected); checks.append('DE_hand_calculated_forced_coordinates_and_clipping')
    for budget in [4,12]:
        o=LoggedObjective('Sphere',2,-8,8,budget)
        de.run_de(o,pop,np.random.Generator(np.random.PCG64(123456789)),{'F':.5,'CR':.9})
        calls+=budget
        assert o.count==budget and len(o.trace)==budget//4 and len(np.concatenate(o.points))==budget
        assert o.best_f==min(np.concatenate(o.all_values))
        assert np.all(np.abs(np.concatenate(o.points))<=8)
        checks.append(f'exact_budget_including_initialization_{budget}')
    return {'passed':True,'checks':checks,'optimizer_or_test_objective_calls':calls,'scope':'Synthetic unit tests; none use planned experiment seeds, and results are not included in experiment.'}

def main():
    freeze=json.loads((ROOT/'prerun_freeze.json').read_text())
    for p,h in freeze['files'].items(): assert sha(ROOT/p)==h, 'Frozen file changed: '+p
    plan=json.loads((ROOT/'plan.json').read_text())
    assert not (ROOT/'results/runs.jsonl').exists(), 'Refusing rerun'
    start=time.monotonic(); cpu=time.process_time(); rows=[]; aliases=[]; failed=None
    def alarm(signum, frame): raise TimeoutError('300 second experiment hard wall clock limit')
    signal.signal(signal.SIGALRM,alarm); signal.signal(signal.SIGTERM,alarm)
    signal.setitimer(signal.ITIMER_REAL,plan['budgets']['wallclock_limit_seconds'])
    def run_one(stage,config,fi,seed,budget,role):
        nonlocal failed
        name=plan['functions'][fi]['name']; f=plan['functions'][fi]
        run_id=f'{stage}_{config["id"]}_{name}_{seed}'
        o=LoggedObjective(name,plan['dimension'],f['lower'],f['upper'],budget)
        x0=de.p1.initial_population(plan,fi,seed)
        rng=np.random.Generator(np.random.PCG64(np.random.SeedSequence([plan['root_seed'],fi,seed,3])))
        state0=rng.bit_generator.state
        t=time.monotonic(); c=time.process_time(); status='complete'; error=None
        try: de.run_de(o,x0,rng,config)
        except BaseException as exc:
            status='truncated' if isinstance(exc,TimeoutError) else 'failed'
            error=repr(exc); failed={'run_id':run_id,'status':status,'error':error,'traceback':traceback.format_exc()}
        wall=time.monotonic()-t; process_cpu=time.process_time()-c
        path=ROOT/'results/runs'/f'{run_id}.npz'
        points=np.concatenate(o.points) if o.points else np.empty((0,plan['dimension']))
        values=np.concatenate(o.all_values) if o.all_values else np.empty(0)
        np.savez_compressed(path,points=points,values=values,trace=np.asarray(o.trace),initial_population=x0,best_x=o.best_x if o.best_x is not None else np.empty(0))
        row={'run_id':run_id,'stage':stage,'config_id':config['id'],'role':role,'function':name,'function_index':fi,'seed':seed,'F':config['F'],'CR':config['CR'],
            'budget':budget,'evaluations':o.count,'best_f':o.best_f if np.isfinite(o.best_f) else None,'best_x':o.best_x.tolist() if o.best_x is not None else None,
            'initial_population_sha256':de.p1.population_hash(x0),'rng_initial':state0,'rng_final':rng.bit_generator.state,'status':status,'error':error,
            'wall_seconds':wall,'cpu_seconds':process_cpu,'boundary_coordinate_count':o.boundary_coordinate_count,'ledger_path':str(path.relative_to(ROOT)),'ledger_sha256':sha(path)}
        rows.append(row)
        with (ROOT/'results/runs.jsonl').open('a') as out: out.write(json.dumps(row,allow_nan=False)+'\n'); out.flush()
        if failed: raise RuntimeError('Run failed; retained complete partial ledger')
        return row
    try:
        tests=contract_tests(); dump(ROOT/'results/prerun_tests.json',tests)
        print('PRECHECK_PASSED '+json.dumps(tests),flush=True)
        for fi,f in enumerate(plan['functions']):
            for si,seed in enumerate(plan['search']['seeds']):
                seen={}
                for config in plan['search']['configs']:
                    identity=(config['F'],config['CR'])
                    if identity not in seen: seen[identity]=run_one('search',config,fi,seed,plan['search']['budget'],config['arm'])
                    aliases.append({'stage':'search','function':f['name'],'seed':seed,'alias':config['id'],'actual_run_id':seen[identity]['run_id']})
                if fi==0 and si==0:
                    panel=[r for r in rows if r['function']==f['name'] and r['seed']==seed]
                    dump(ROOT/'results/first_frozen_panel.json',panel)
                    print('FIRST_FROZEN_PANEL '+json.dumps([{'config_id':r['config_id'],'best_f':r['best_f']} for r in panel]),flush=True)
        scores=[]
        byid={r['run_id']:r for r in rows}
        for config in plan['search']['configs']:
            matches=[byid[a['actual_run_id']] for a in aliases if a['stage']=='search' and a['alias']==config['id']]
            assert len(matches)==9 and all(r['status']=='complete' for r in matches)
            score=math.fsum(math.log10(max(r['best_f'],1e-16)) for r in matches)/9
            scores.append({**config,'score':score,'n_paired_function_seed_blocks':9})
        winners={arm:min((c for c in scores if c['arm']==arm),key=lambda c:(c['score'],c['id'])) for arm in ['grid','random']}
        selection={'winners':winners,'all_scores':scores,'input_runs_sha256':sha(ROOT/'results/runs.jsonl'),
            'plan_sha256':sha(ROOT/'plan.json'),'frozen_before_fresh_repeat':True,'elapsed_seconds_before_repeat':time.monotonic()-start}
        dump(ROOT/'results/selection.json',selection)
        (ROOT/'results/selection.sha256').write_text(sha(ROOT/'results/selection.json')+'\n')
        print('SELECTION_FROZEN '+json.dumps(winners),flush=True)
        repeatconfigs=[{**winners['grid'],'role':'grid_winner'},{**winners['random'],'role':'random_winner'},{'id':'default','F':.5,'CR':.9,'role':'default'}]
        for fi,f in enumerate(plan['functions']):
            for seed in plan['repeat']['seeds']:
                seen={}
                for config in repeatconfigs:
                    identity=(config['F'],config['CR'])
                    if identity not in seen: seen[identity]=run_one('repeat',config,fi,seed,plan['repeat']['budget'],config['role'])
                    aliases.append({'stage':'repeat','function':f['name'],'seed':seed,'alias':config['role'],'actual_run_id':seen[identity]['run_id']})
    except BaseException as exc:
        if failed is None: failed={'error':repr(exc),'traceback':traceback.format_exc()}
        print('FAILURE '+json.dumps(failed),flush=True)
    finally:
        signal.setitimer(signal.ITIMER_REAL,0)
        summary={'status':'complete' if failed is None else 'failed','actual_runs':len(rows),'actual_evaluations':sum(r['evaluations'] for r in rows),
            'nominal_runs':216,'nominal_evaluations':594000,'wall_seconds':time.monotonic()-start,'cpu_seconds':time.process_time()-cpu,
            'compute_processes':1,'native_threads':1,'failed':failed,'optimization_only_cpu_seconds':sum(r['cpu_seconds'] for r in rows),'optimization_only_wall_seconds':sum(r['wall_seconds'] for r in rows)}
        dump(ROOT/'results/aliases.json',aliases); dump(ROOT/'results/runs.json',rows); dump(ROOT/'results/run_summary.json',summary)
        fields=['run_id','stage','config_id','role','function','seed','F','CR','budget','evaluations','best_f','status','wall_seconds','cpu_seconds','initial_population_sha256','ledger_sha256']
        with (ROOT/'results/runs.csv').open('w') as out:
            writer=csv.DictWriter(out,fieldnames=fields,extrasaction='ignore');writer.writeheader();writer.writerows(rows)
        print('RUN_SUMMARY '+json.dumps(summary),flush=True)
    if failed: sys.exit(1)

if __name__=='__main__': main()
