"""Read-only delivery check, does not rerun experiments."""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[1]
manifest=json.loads((root/'file_manifest.json').read_text())
failures=[]
for row in manifest['files']:
    p=root/row['path']
    if not p.is_file() or p.stat().st_size!=row['bytes'] or hashlib.sha256(p.read_bytes()).hexdigest()!=row['sha256']:
        failures.append(row['path'])
print(json.dumps({'files':len(manifest['files']),'passed':not failures,'failures':failures},indent=2))
raise SystemExit(bool(failures))
