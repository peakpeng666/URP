# 第三批：结构生成、数值调参与父代潜力

2026-10-05。仅静态阅读与文本/元数据解析，未执行作者程序、安装、训练、调用模型或取权重。独立增量目录，不修改前两批报告、源码、累计索引或稳定包清单。

## 影响下一实验的机制

- LLaMEA-HPO把结构生成与数值调参分开；我们的固定公式参数网格只能验证后者，不能叫新算法生成。应分列结构提案数、调参配置数、每配置实例/目标评价数、最终复评成本
- HSEvo也是“LLM先抽出参数→传统Harmony Search调参”，但当前版本把全失败初始HS配置的FE减回，且存在待调参子列表与原种群索引错位。不能沿用其FE分母作为公平预算
- MEoH保留质量—运行时间Pareto集合；第二目标是内层宿主求解墙钟，未含生成/解析/淘汰/模型重试，不能宣称整个发现过程更便宜
- QUBE区分父本自身分数与产好后代的潜力，但官方固定仓仍是README/TBD，没有可核UIQ更新实现。ReVEL及CoEvo-AHD本轮仍未定位作者源码，不用相近框架补造

## P252 LLaMEA-HPO

正式题名：In-the-loop Hyper-Parameter Optimization for LLM-Based Automated Design of Heuristics，[arXiv元数据](https://arxiv.org/abs/2410.16309)。核当前官方LLaMEA `0b08a42789d130081ee3dd3ab2b65b2ee339dced` 的 `examples/black-box-opt-with-HPO.py`全文件，配合第二批同commit的llamea/llm/solution与AOCC工具；不是2024论文冻结源码。MIT许可沿用同commit原文。

链：LLM输出类+ConfigSpace→sample_solution提取→用户evaluateBBOBWithHPO→100次内预算烟测→SMAC配置搜索→按incumbent复评→AOCC/配置写回feedback→外层plus选择。直接依赖NumPy、IOH、ConfigSpace、SMAC；本轮未锁定全部版本，未安装。

- 当前例Gemini-1.5-flash；默认父/子各5（非论文1+1）。外层默认100候选，内层5维×10000目标评价上限；SMAC场景n_trials2000/min_budget12/max_budget200，不能将这几个budget相乘后假称真实已调用数，实际由SMAC强度器/实例与失败路径决定
- tuning集合24函数×3实例；之后名为final validation的阶段仍同24×3，每个3重复，随机seed=rep。它是配置复评而非新任务/新实例盲测，不能据这个标签宣称泛化
- 评价函数对调参运行的一般异常只打印再计算AOCC，和完整复评的异常处理不同；需把部分轨迹失败与正常提前终止分开
- 当前示例传`mutation_prompts=...`，而同commit LLaMEA.__init__没有这个参数，也没有**kwargs；在该入口有静态接口不兼容
- 示例又用`'_configspace' not in solution.keys()`，当前Solution是具configspace属性的对象，没有keys方法；即便解决构造参数，评价路径仍需迁移
- ConfigSpace提取用`eval`解析模型块，评价用`exec`加载生成类，不是声明式参数空间的安全解析。不得借HPO名义直接在当前工作进程执行任意模型文本

可借用：固定候选结构的数值参数优化、保存incumbent与错误反馈。对照应包括默认参数、等内层预算随机/网格/SMAC，并在结构生成变化与参数变化之间做单因素分账。未将当前示例不兼容倒推成历史论文运行失败。

## P241 HSEvo

[正式题名与作者](https://arxiv.org/abs/2412.14995)：HSEvo: Elevating Automatic Heuristic Design with Diversity-Driven Harmony Search and Genetic Algorithm Using LLMs。
官方 https://github.com/datphamvn/HSEvo ，固定 `f3afffabc2b458fddf70a42a8678758039671297`，MIT；比既有无commit的随包摘取更可追溯，不能当2024原始快照。

### 已读链
hsevo.py110–174初始化、219–327评价、347–559选择/反思/交叉/变异、559–740 Harmony Search及停止；main入口、cfg、utils客户端135–175、装箱eval1–110、HS提示文件已取得但本轮未全文语义核查。

seed评价+角色轮换30份初始化→不等分随机父对→排序集合Flash reflection→结合历史good/bad的comprehensive reflection→10交叉+5elite变异→选未HS候选→一次LLM参数化→HM5随机配置+5次HS新配置→加入种群。反思被记good/bad依据elite代码路径是否变，不是独立因果贡献估计。

### 预算、选择与静态风险
1. 配置max_fe450只在轮首检查；反思与HS参数化LLM不计FE，网络最多30尝试。HS初始5配置全exec失败时`function_evals -= hm_size`，失败成本被抹去，必须保留我们自己的不可回退账本
2. `sel_individual_hs`先筛tryHS=False，argmin得到子列表下标，却用该下标索引原population并打标/返回code；在前部已有tryHS=True时会选错个体。空候选也无显式处理
3. pitch adjustment加扰动后未clip到bounds；“参数范围”不是执行约束。全是uniform连续数，若参数需要整数/类别需另设合同
4. Flash去重字符串包含本轮排序编号，所以相同代码位于不同idx时字符串不同，所见去重不会消掉这种重复；反馈上下文不一定如预期精简
5. cfg seed2026只在main设NumPy；没有由此证明所有内层solver随机源重放。当前模型是gpt-4o-mini-2024-07-18别名，非原历史请求快照
6. max_tokens32768只有检测到OPENAI_API_BASE时才加入客户端kwargs；不能只看YAML以为全部后端都收到长度上限。tiktoken按cl100k_base对消息字段和响应估算，不是服务端实际计费/隐藏推理token账本
7. 子进程前等首次stdout，无deadline；随后communicate(timeout)并非整个候选的墙钟上界。exec_success标量解析不独立检验数学约束
8. OBP宿主过滤可行箱再argmax，返回负平均箱数；有is_valid_packing函数定义，但已读evaluate没有调用它。数据pickle本轮未下载/逐项核验，不能宣布独立验证全面存在

requirements固定NumPy1.26.3、SciPy1.11.4、litellm1.55.9等，torch/joblib/numba部分未固定。依赖未安装，无动态故障证明。

## P329 MEoH

[AAAI正式论文](https://ojs.aaai.org/index.php/AAAI/article/download/34922/37077)明确链接LLM4AD，题名Multi-Objective Evolution of Heuristic Using Large Language Model。固定平台 `ffb6acf64497be93932c98d25369352efd3865cf`。根BSD式许可与文件头研究用途文字冲突沿用首批记录，不据公开可读承诺任意重分发。

链：MEoH任务模板→I1/E1/E2/M1/M2→thought/function解析→SecureEvaluator→双目标score→Population非支配档案及dominance-syntax选择→生成。已读meoh.py40–325、population.py与sampler全文件、run_meoh_obp及具体OBP两目标评价/实际import的数据生成器；prompt正文未全读。

- 默认20群体，但初始可在pop_size//4有效新个体时生存；实际例pop10、1000样本、1000代、4samplers/4evaluators。不能照20/20论文口径写结果
- 不等式用所有目标>=，没有严格优于条件，完全相等时前项可被当作支配后项；syntax_match惩罚再softmax选择具有顺序依赖。非支配archive按完整score tuple去重，可能删除同质量/时间但不同行为的程序
- `has_duplicate_function`只在同代码且新第一目标更好、或第一相等第二更好时替换并返回True；同代码更差/相等反而未拒绝，可继续进入新群体。运行时间噪声还会令同代码看似不同目标点
- 第二目标实为从实例循环前time.time到循环结束的平均宿主墙钟（含Python宿主开销），不是单个priority函数纯耗时，不含LLM、语法解析、子进程启动、编译或整个搜索成本。四评估器并发的竞争会影响测量
- 数据不是data_file/data_key真正加载；构造器忽略这两个参数，实际调用单目标online_bin_packing目录生成器：seed2024、5×5000物品、容量100、Weibull shape3×scale45，clip[1,C]后round。生成器重复实例化是同一设计集，不能靠改文件名制造新测试
- 计数仅在Profiler非空分支增加，解析失败不计；无原子预占额度，并发可超发。run发现有效父不足会generation减1重初始化；预算用尽仍不足父代时外层while没有退出条件，可能空转，不能把max_sample_nums看成完整终止保证
- Population只筛Inf、不统一拒NaN；SecureEvaluator能力边界见首批，子进程不等完整权限隔离

可借用多目标存档与质量—部署时间曲线；当前固定公式网格若调不出质量差异，应先报告真实平局和重复行为，不用有噪声的单次时间差造“新算法Pareto优势”。

## P406 QUBE：官方仓只有占位说明

正式题名已在 https://arxiv.org/abs/2412.20694 核为QUBE: Enhancing Automatic Heuristic Design via Quality-Uncertainty Balanced Evolution，早期UBER不另计一篇。
官方 https://github.com/zzjchen/QUBE_code 固定 `94245cdda8f21a7ceef0bea27d0312063cbbbbdf`，递归Git树只有README.md。README的Introduction/Usage/Requirements/Running均TBD，引用旧UBER版本，无LICENSE或实现文件。

状态是`no_released_code_at_verified_snapshot`：证据仅针对该官方仓该commit，不断言别处永远没有代码。读取README不记code_inspected=true。UIQ/零计数/重置/父贡献归因只有论文描述，未沿源码核验。

## P432 ReVEL 与 P309 CoEvo-AHD：未定位，不等于确认未发布

- [ReVEL v3](https://arxiv.org/html/2604.04940v3)正式题名ReVEL: Multi-Turn Reflective LLM-Guided Heuristic Evolution via Structured Performance Feedback。正式HTML及题名/作者检索未取得本篇作者实现；其中HSEvo的GitHub只是参考文献，不能当ReVEL代码
- [CoEvo-AHD v1](https://arxiv.org/html/2606.00718v1)正式题名LLM-Driven Co-Evolutionary Automated Heuristic Design for Bi-Component Coupled Combinatorial Optimization。官方HTML与题名检索未定位作者仓；页上GitHub是arXiv转换报告入口，不是研究代码

两篇均`not_located`，repo/commit/license=null，code_inspected=false。保留已读论文的机制假说：ReVEL多轮群体反馈，CoEvo完整耦合目标下组件交替与工具接口；本轮不重述大量论文细节，不将附录打印函数或G-LNS当完整实现。没有对外联系作者、运行第三方自动重现工具或构造猜测仓名。

## 全46项的状态分类

第三批另存 `scope_classification.json`，与“是否已精读论文”正交：
- `not_applicable`：只在已有全文证据明确是综述、无独立方法实验时使用，本轮确认P023、P026。表示不需要凭空寻找该综述独立求解器源码，不表示其引用论文均无代码
- `source_obtained`：实际取到相关作者实现，但仍须看read_ranges；AEL只取得后续移植另加标志
- `no_released_code_at_verified_snapshot`：目前只QUBE这种已核官方树占位状态
- `not_located`：有针对性查找但本轮未取得，如CoupleEvo/DGS/ReVEL/CoEvo；404不能改成未开源
- `not_assessed_in_code_review`：剩余尚未在三批代码专项评估，绝不能自动叫代码缺失

未取得来源不伪造依赖、预算或安全结论。第三批只有3篇实质源码路径读取，另1篇官方占位核验、2篇未定位。全部executed=false、numerically_aligned=false。
