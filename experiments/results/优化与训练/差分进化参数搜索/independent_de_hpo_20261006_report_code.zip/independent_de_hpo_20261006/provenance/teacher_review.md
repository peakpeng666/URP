# 教师六阶段：要求、代码调用链与证据边界

核查日期：2026-10-04 UTC；P3与DEAP最新证据小范围更新：2026-10-05 UTC。重新经已连接Drive读取教师原DOCX完整可提取正文，保存于`teacher_original_extract.txt`；未执行其中示例。只新增本目录静态审阅材料，未运行作者代码、模型、训练或既有冻结实验。源码快照按固定commit取回为`.txt`，Git blob和SHA256见`upstream_manifest.json`。本地URP不是Git工作树，因此以具体文件哈希标识，不能虚构URP commit。

## 先看影响推进的结论

1. 教师教学交付与论文原规模复现必须分开。P1 GA/PSO及独立DE扩展有真实运行；P2生成、有效排序输入评测、提示对照和报告有真实证据；P4简单RL NAS已跑通。它们未重现原论文全表，不等于基础教学全部失败
2. P2新批次三段可执行程序的360次有效输入测量全部符合；24个反例全来自无效输入未抛精确TypeError。教师没有规定这一异常合同。完整严格协议A/B均0/5仍需保留，但不能改写成“不会排序”。另7段语言拒绝不能算已测功能错误，不能据其反推通用Python正确率
3. P3已运行两个22请求研究。最新compact两代有4个有效记录，但2个复制FF/BF、2个劣化成最大剩余容量优先；所有代保留FF/BF，尚无生成父代被后代继续改进的实证。固定论文公式重评分23胜7平不能算本地模型发现
4. 教师§4.1.1声称的LLM4AlgorithmDesign代码树不存在于本次固定仓库：完整树只有README、图及.gitattributes。不要执行指南中的不存在入口。真实LLM4AD、EoH是另外的仓库/版本
5. 教师GA示例本身有方向与未评价错误；作者EoH/LLM4AD特定版本也有入口和预算风险。应借机制与接口，不能把默认脚本直接当安全、有限预算的复现管线

## P1 GA、PSO与周计划DE

### 原要求

原文§6.1项目1（提取行540–544）：GA、PSO；Sphere/Rastrigin/Ackley；NumPy、性能图、5–10页报告。DE及“DEAP实现优化器”在第13–14周表（行672–674），不是§6.1新增的第三项硬指标。教师没有给固定维度/种子数/评价预算，也没有指定唯一GA/PSO论文或官方实现。

### 已读调用链与实情

- `experiments/function_optimization/src/run_experiment.py`调`baselines.optimize`；核心静态审阅为`CountedObjective.evaluate → run_ga / run_pso → sbx_children / polynomial_mutation / pso_step`。目标最小化，初始及重复点评价均计数，GA先评估子代再保留精英；PSO同步gbest、速度限幅、位置截断并清零越界速度
- 固定D=10、N=50、10000评价、20种子、3函数，共120次GA/PSO；GA SBX eta15、边界距离多项式变异eta20、2精英；PSO惯性0.9→0.4、c1=c2=1.5、vmax=0.2范围。它不是DEAP默认算法
- `function_optimization_de/src/de.py: optimize → run_de → make_trials → trials_from_draws → select`：从旧代排除目标且无放回选互异供体，F=.5、CR=.9、强制坐标、clip、严格改善同步替换；独立目录已60次/600000评价。继承P1初始种群及目标，不能因旧P1入口只有GA/PSO误报DE缺失
- 运行证据分别为P1 `results/{runs.csv,verification.json}`、DE `results/{runs.json,postrun_audit.json}`；本次只读，未重跑。P1已有8页报告；DE是见过GA/PSO结果后的探索扩展，不是新盲测

### 原示例静态错误及DEAP差异

原文§4.5示例1行331 `return max(candidates)`配合`Individual.__lt__`直接比较fitness，若输入Sphere等原始最小化值会选更差父代。行363–373每个child为新Individual、fitness默认None；赋新种群后未评价便`max(...fitness)`，默认多成员时比较None会报TypeError，随后格式化None也无效。这是未执行的直接静态推导；现有URP实现不含这两处问题。

本次已读[DEAP固定8a96fd3…](https://github.com/DEAP/deap/tree/8a96fd3a75026f7b30e835f595a5199c75634ddf)的`examples/de/basic.py`、`examples/pso/basic.py`和`algorithms.py:eaSimple`、`base.py:Fitness`。DE例子10维、MU300、NGEN200、F1、CR.25，原地顺序更新，不明确排除目标/供体互异且无边界修复；PSO例子是2维h1最大化、5粒子、1000代，不能原封不动对P1表。DEAP Fitness用权重转换，weights=(-1,)时`fitness >`反而代表更小原目标，不能把它和教师普通float的max混淆。`eaSimple`只评价invalid fitness且非内置精英保留，也不等于URP每代50次计费合同。

可复用：CountedObjective、配对初始化、算子纯函数测试、原始评价账本、DE分析器。新增DEAP框架实际教学运行已完成，见下。未完成：独立环境复验；若目标是论文复现需另选论文表图/参数。本次固定GitHub DEAP示例仅已读、未执行；新增教学实际使用的是官方PyPI DEAP1.4.3库，二者版本证据不能混同。

### 2026-10-05更新：DEAP最小化教学单槽已完成

`experiments/deap_teaching_v1/`已完成一次固定Sphere运行：D5、N20、20代、seed20261005，420/420目标评价与21条最优轨迹。初始最好18.591493140617015，最终0.008735831615323184；8项代码测试通过，`results/postrun_audit.json`独立从保存账本复算420值/21轨迹，未重跑优化器。结果SHA256为`12644852d5eb120106135724965cc9b29684fcde788cbe1d26363ec2e3d328ce`。

静态已读`src/sphere_ga.py`：`run → make_toolbox → evaluate_invalid → vary → evaluate_invalid → replace`。weights=(-1,)表示最小化；父代引用必须clone，原地算子只动克隆；每个子代失效fitness并重新收费，先评价再父子精英存活。SBX eta15/cxpb.8、多项式变异eta20/个体概率.3/坐标概率1/5、锦标赛3。保存恢复Python random状态但不用于并发。

这是官方PyPI DEAP1.4.3的真实框架练习，补上周计划缺口；并非旧P1自写GA数值等价、DEAP eaSimple默认复现、算法优势比较或论文复现。仅单函数单种子，不能据此声称全部DEAP知识掌握。正式420评价与单元测试微型调用分开，未改原GA/PSO/DE180次冻结结果。依赖版本与wheel SHA见该目录dependency_verification；本轮只读更新报告。

## P2 CodeGen排序生成

原文§6.1项目2行545–549只要求CodeGen350M、排序提示、正确率与提示优化报告，未规定非法输入精确TypeError、plain-list、排除bool、输入不变或返回新对象。后四类是本项目研究合同，不能倒写成教师标准。

### 官方与URP入口

- 官方[Salesforce/CodeGen固定ec21c93…](https://github.com/salesforce/CodeGen/tree/ec21c93bda19c087f419f552c196afa9a36ee890)：`codegen1/jaxformer/hf/sample.py:main → create_model/create_custom_gpt2_tokenizer → sample → model.generate → truncate`。默认350M-mono、t=.2、p=.95、128新token，GPU默认而CPU可fp32
- `benchmark/mtpb_sample.py:main → create_problem_set → sample_completions`按每题输入逐轮拼接prompt和前轮代码；`mtpb_exec.py:eval_problems → AST补print → do_exec → check_equivalence → estimate_pass_at_k`。原benchmark会转换输出类型、float容差1e-6，和URP精确类型排序合同不同；其exec/reliability_guard不应视为完整隔离沙箱。正式论文多轮结果不等于单排序A/B
- 该源码requirements为torch1.13.1/transformers4.30.0（文件正文另有历史torch1.9/transformers4.16.2说明）；不能声称与目前torch2.14.1+cpu/transformers5.18.0严格数值相同
- URP权重固定Salesforce/codegen-350M-mono revision `d9107f71cca463240db1143f4a75a927a27fcb27`，SHA256 `90e20f4887289739a435452f26974d97937adb41485f9c1a7b3d3810aac6773d`；这是模型revision，不是上述源码commit
- 原生成`sorting_generation/src/generate_static.py:main`离线哈希检查、安全加载后generate，绝不执行候选。新批次`isolated_evaluator/prospective_prompt_v4_compat/src/run_generation.py:run_jobs/load_trusted_generator`固定10调用及512新token；`extract.py`固定提取，`evaluation_core.run_forms`经v3适配进入有界工作进程，`limited_semantics_v3/src/host_checker.py:check_payload`独立查期望值/类型/对象/最终输入及异常合同

### 结论分层

v4新10样本：7个语言拒绝，3个进入144用例各自评分，共432调用=408符合+24不符合。有效输入为3×2面板×60=360，全部通过；无效输入72测量有24不符合。A至少1/5、B至少2/5生成形式通过已执行的有效排序面板；未执行形式未知，不能把它们算全部功能失败，也不能称所有输入正确。严格全部144用例A/B均0/5；5对样本不足以证明提示等效或优化有效。报告已经完成一次提示比较，负结果同样交付，不必以“必须提高”作为教师未说的验收门槛。内置sorted被允许，故是代码生成练习而非新排序算法发现。

可复用：离线固定检查点加载、原始token/原文、确定提取谱系、完整分母账本、测试独立checker。未完成：完整Python语义、论文HumanEval/MTPB对齐、更多题/模型泛化；256MiB进程树RSS硬限制未证明。旧失败/旧冻结均保留。

## P3 EoH双表示演化

原文§6.2项目3行551–555要求读论文、thought/code双表示演化、在线装箱、baseline及详细报告；微调出现在技术要求，但原EoH机制并不据此自动需要训练权重，需把微调教学单列。五个策略应是E1/E2/M1/M2/M3，初始化I1另列；教师“交叉/变异/反思/学习/初始化”不是源码准确调用表。

### 官方调用链与版本

已重新逐函数读本地`evolution_readiness/sources/icml2024`固定`e4b5ddba03b2b88025747e11c6049f8b529a4368`和current_pinned `472545785c936dcfc863d2bc0d6109cf23c7ce62`相关核心。原来源哈希见既有source_manifest，后续本目录inspected_source_index提供本次证据定位。

- 历史入口`examples/bp_online/runEoH.py`→配置/演化入口→`EOH.run`→`InterfaceEC.population_generation/get_algorithm/get_offspring/_get_alg`→`Evolution.get_prompt_* / _get_alg`→LLM响应抽取→`BPONLINE.evaluate`→`exec`→`evaluateGreedy/online_binpack`→score→argmax；`prob_rank.parent_selection`按逆秩权重有放回选父；`pop_greedy.population_management`按objective去重、最小值保优
- 抽取使用正则从import/def到return，再拼规定输出变量，不是原字节直接保持；目标round到5位且按分数去重，可能合并行为不同程序。默认历史四算子e1/e2/m1/m2，M3无调度；初始化2N、每轮每算子N不是论文N初始化/5N后代的直接执行对应
- 静态风险：`population_generation_seed(self,seeds,n_p)`与run的单参调用不合；低于1的operator_weights分支外无条件用offsprings，可能未赋值或复用旧值。默认全1不触发后一问题，不能说默认必坏。ThreadPoolExecutor的future超时/cancel不保证终止正在执行线程；候选exec与屏蔽warnings不提供网络/文件边界
- 新固定版是异步steady-state，初始化2N、默认演化预算n_pop×pop_size、默认仍四算子；因此相同“20代”标签不同于原论文代际成本，不能混算
- 官方问题预置n个箱，score收到所有可行箱含未用箱，暴露总长度；与旧URP仅既有箱的严格在线接口不同。历史跨容量错误已在本地更正重评分中明确修正；历史测试数值与2026新数据不同，必须固定历史字节

### 现有URP与复用边界

最新调用链：`math_dag_evolution_compact_v2/run_study.py`→`src/pipeline.py:Study.run/candidate/score_cases`→`policy.build_prompt/parents/retain/fitness`→本地generation/scoring适配→`math_dag_v1/schema.validate_program`→`interpreter.pack/evaluate`。双表示为短description+JSON DAG；最多4节点/3常数/64字符描述，受限8种算子，明确不是完整Python。所有分数最终必须有限；中间Inf警告记录且不自动“修复”。保优按图身份去重、精确有理fitness和来源次序平局，和作者分数去重不同。

已执行证据：历史FF/BF60槽，已发表公式可信重实现30槽，以及v1/compact各22本地Qwen3-4B量化请求。compact四有效记录两复制两劣化；每代仍FF/BF；受限搜索没有证明演化反馈收益。原论文GPT-3.5-turbo、N20/20代、5000物品设计、完整程序空间及FunSearch对照仍未对齐。早期公式重实现门槛为45050合法数值对；后续新增的作者源码动态数值门槛与完整设计集证据见下，不能继续笼统称“从未执行作者函数”。“数值对齐完整论文”仍应false，已对齐组件须单列true。

### 2026-10-05更新：已对齐的固定公式/设计集/论文数字组件

本次只读`paper_design_panel_v1/{report,numeric_gate,postcheck,source_verification,protocol_frozen}.json`及`run_once.py`，不重跑门槛或solver。该阶段已完成15/15正式槽：历史2024设计集5×5000物品、容量100、FF/BF/固定EoH。总箱数FF10359、BF10335、EoH10007，L1总9939；固定EoH的论文指标mean(L1_i/bins_i)=0.9932044091493765，按论文精度为0.993。正式分配由保存记录独立重算验收；这不是5000长度上的生成反馈搜索。

前置门槛确实在独立限额进程执行了已审的615字节作者函数，与可信公式重实现动态比较：int64输入上500种向量/592200数值对，最终float64逐bit及first-argmax全部相同、输入不变，800次预期中间乘法overflow保留。可信实现仅将scalar类型守卫np.int32改为np.int64，数学式未变。门槛覆盖范围以这些向量为限，不声称所有输入或全部装箱轨迹双实现对照。正式15槽中的EoH仍用可信重实现，不能把15槽统称作者源码执行。

作者函数SHA256为`f3d50f0e81ca061a0377b9fb61b75cf16ecde9f091876db0d8baca8323655995`，来自2026固定官方commit `472545785c936dcfc863d2bc0d6109cf23c7ce62`中标为original EoH paper的文件；历史数据另固定2024版本。没有证明此作者文件字节在2024就已存在。旧来源记录中的author_code_execution=false描述当时静态取回，不覆盖后来实际门槛执行。

论文Table1组件按原有C100九格及混合容量九格分开：`table1_mixed_capacity_diagnostic.json`用已保存逐例结果重组[500,100,100,100,100]，FF/BF/EoH×三规模九格均按论文精度匹配，solver_calls=0。它解释标称容量500列的历史容量更新问题，绝不能改写成五例全部C500正确。全部18格的对照不增加实验样本；C100旧运行与C500混合重组的来源必须分别保留。

因此component numerically_aligned=true仅限固定公式门槛、完整设计集固定策略指标及明确容量语义的表格数字组件；原GPT-3.5模型、N20×20代、完整Python候选空间、5000物品生成反馈、FunSearch对照仍未复现，整篇numerically_aligned=false。相应结构字段已同步，审阅自身仍零模型/solver执行。

可复用：冻结原数据与容量、独立分配checker、状态机/完整事件/预算预留、保留失败、graph_identity/behavior_signature、验证前持久承诺。不要继续把语言约束当论文机制的无损替身；下一步需独立定义更忠实表示/模型/预算及何谓可接受教学复验。

## P4 简单RL NAS

原文项目4行556–560是简单搜索空间+RL+CIFAR10，没有指定名为“RLNAS”的唯一论文或官方仓库，也没有规定必须DARTS。周表DARTS/ENAS/ProxylessNAS是扩展学习，未下载其仓库或读核心的项目不能写已读。

实际链`architecture_search/run_experiment.py:run_search → train_child → TinyCNN → evaluate`；控制器是3×2独立分类logits，采样深度{2,3}/宽{8,16}/核{3,5}；REINFORCE loss为负(验证准确率−EMA baseline)×log概率，另减.005熵，Adam控制lr.05、baseline .1/decay .9。子模型Adam .003、weight_decay1e-4、2epoch、batch128；无共享权重/无RNN控制器/无DARTS连续混合边。

官方CIFAR10 binary archive MD5 c32a1d4ab5d03f1284b67883e8d87530；4000训练/1000搜索验证，3搜索seed×8候选×2法=48，另1固定基线。`run_postselection.py:freeze/state_hash → run → statistics`将6赢家别名去重为3权重，与基线共4，5000保留训练图只做评估不重训。官方测试未提取/评估。

教学NAS实现、架构选择、性能报告均已有。独立开发准确率23.92/21.40/23.66%，基线19.82%；两法相同赢家权重，因此不能声称RL胜随机。候选数相同不等于FLOPs/时间相同，2epoch不能称优秀最终CIFAR模型。可复用搜索空间、独立RNG、成本计数、checkpoint去重、冻结split；后续若研究RL优势需多种子/独立重训/等算力协议，论文对齐另卡。

## P5 多问题完整系统

原文行562–566要求完整LLM+EA+评估、多问题、既有方法比较和全面报告。多个目录中各自可运行，不等于共用系统已经验收；目前无足够证据认定P5完成。

教师LLM4AlgorithmDesign仓固定`a198a9c597ddf185d1c6b0f7f6fd987f580032f7`完整树仅7文件；不存在指南示例的algorithms/llm_models/tasks/examples目录。实际[LLM4AD固定fd847257…](https://github.com/FeiLiu36/LLM4AD/tree/fd8472573211a87b8cb68a6478581fde5202af8b)入口`example/online_bin_packing/run_eoh.py`→`EoH.run/_init_population/_do_sample`→`EoHSampler.get_thought_and_function`→`SecureEvaluator.evaluate_program_record_time`→任务`OBPEvaluation.evaluate_program`→`online_binpack`→`Population.register_function/selection`。

实例由`generate_weibull_dataset(5,5000,100)`固定np seed2024、Weibull(shape3)×45、clip[1,100]、round生成。构造器data_file/data_key参数未实际读取文件，不能把传入路径当数据已替换。评价为负平均箱数且population最大化，和URP L1超额正值最小化须接口转换。依赖numpy≤2/scipy/numba/requests/openai/torch等，未形成严格完整lock；不能覆盖URP NumPy2.3.5原环境。

已读源码风险：解析thought/function失败直接返回且不增样本；计数只在profiler非空时递增；初始化只等generation>0没有max_sample_nums闸门，长期无有效候选可持续调用；一项停止条件None另一项有值时continue_loop的两个布尔相与会提前停止。`SecureEvaluator`子进程exec/terminate是超时机制，不是拒网拒写沙箱。以上仅特定固定commit静态事实，未执行故障证明。

可借抽象：LLM、Evaluation、Program/Function、方法与任务分层；保留URP自己的不可越过预算、原文谱系、语义checker。最小有意义P5是统一两个任务合同、同一调用/成本账本、相同对照与终止规则，并分别验收，不能只把作者包import成功计完整系统。当前未执行作者LLM4AD、未数值对齐平台论文。

## P6 原创研究

原文行567–571要求明确研究空白、新方法、实验、论文，不是多添加一个目录。没有指定单一官方仓库；继承P3/P5机制可用于研究设计，但已有小先导负结果不能独自证明领域空白或原创优势。当前无经过冻结、对照、消融和确认性结果支持的完整原创方法验收。

可复用：失败类型/成本分解、表示对齐审计、数据与split核验、选择后验证。待解决：从精读近邻提出可证伪假设；与最接近方法而非只FF/BF比；控制表示/模型/提示/预算混杂；必要消融/失败成本/跨实例证据。论文及代码新增只在这些条件明确后推进，不能把原EoH模型不可精确重放当作我方原创性。

## 引用勘误（本轮直开arXiv确认）

- 2305.08857=COWPEA投票；2308.12345=早期引力修正；2301.02345=轴子理论；均不是指南所写综述
- 1908.09791=Once-for-All，不是NAS综述；可保留为另一研究对象，不能静默替代
- 2205.00527=Schmidt问题有限类比，不是FunSearch；正确FunSearch为Nature DOI10.1038/s41586-023-06924-6，与矩阵乘法RL/AlphaTensor分开
- 2501.12345=The doubly librating Plutinos，不是AlphaEvolve；目标AlphaEvolve唯一版本由相关论文核查卡继续定位
- LLM4AD平台论文为2412.17287；教师2502.23456未在本轮重新验证有效对应，仍不能使用
- CodeGen为2203.13474，EoH为2401.02051；P4的简单RL实践不凭空指定另一“RLNAS”论文

以上arXiv链接均可用`https://arxiv.org/abs/编号`直达。错误引用不改变教学任务本身，也不授权把相似题名论文随意纳入已复现计数。

## 三态记录与停止边界

`teacher_code_map.json`按code_inspected、executed、numerically_aligned分别存证据。executed区分“历史本地实现已跑”与“本次审阅零执行”；numerically_aligned指论文/作者实现数值对齐，不是程序有输出、通过本地checker或结果看起来接近。本目录源码索引只覆盖明确列出的核心文件，不宣称全仓逐行审完；论文模型内部训练、第三方库完整实现和其他NAS论文代码均未在本轮审全。
