"""Synchronous DE/rand/1/bin; frozen P1 objectives and initialization are read-only."""
from pathlib import Path
import importlib.util
import sys
import numpy as np

P1 = Path(__file__).resolve().parents[2] / 'function_optimization'
spec = importlib.util.spec_from_file_location('p1_frozen_baselines', P1 / 'src/baselines.py')
p1 = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = p1
spec.loader.exec_module(p1)


def trials_from_draws(pop, donors, uniforms, forced, F, CR, lower, upper):
    """Pure operator, exposed for independently hand-calculated tests."""
    n, d = pop.shape
    if donors.shape != (n, 3) or uniforms.shape != (n, d) or forced.shape != (n,):
        raise ValueError('Malformed operator draws')
    if any(len(set(row)) != 3 or i in row for i, row in enumerate(donors)):
        raise ValueError('Donors must be distinct and exclude the target')
    if np.any(donors < 0) or np.any(donors >= n) or np.any(forced < 0) or np.any(forced >= d):
        raise ValueError('Index out of range')
    mutant = pop[donors[:, 0]] + F * (pop[donors[:, 1]] - pop[donors[:, 2]])
    mask = uniforms < CR
    mask[np.arange(n), forced] = True
    return np.clip(np.where(mask, mutant, pop), lower, upper)


def make_trials(pop, rng, F, CR, lower, upper):
    n, d = pop.shape
    indices = np.arange(n)
    donors = np.array([rng.choice(indices[indices != i], 3, replace=False) for i in range(n)])
    uniforms = rng.random((n, d))
    forced = rng.integers(0, d, size=n)
    return trials_from_draws(pop, donors, uniforms, forced, F, CR, lower, upper)


def select(pop, fitness, trials, trial_fitness):
    improved = trial_fitness < fitness
    return np.where(improved[:, None], trials, pop), np.where(improved, trial_fitness, fitness)


def run_de(objective, x0, rng, params):
    pop = np.array(x0, dtype=np.float64, copy=True)
    n = len(pop)
    if pop.ndim != 2 or n < 4 or objective.budget < n or objective.budget % n:
        raise ValueError('DE requires >=4 individuals and an integral positive generation budget')
    F, CR = params['F'], params['CR']
    if not (0 < F <= 2 and 0 <= CR <= 1):
        raise ValueError('Invalid F/CR')
    fitness = objective.evaluate(pop)
    while objective.count < objective.budget:
        trials = make_trials(pop, rng, F, CR, objective.lower, objective.upper)
        trial_fitness = objective.evaluate(trials)
        pop, fitness = select(pop, fitness, trials, trial_fitness)
    return objective


def optimize(config, function_index, seed):
    f = config['functions'][function_index]
    obj = p1.CountedObjective(f['name'], config['dimension'], f['lower'], f['upper'], config['evaluation_budget'])
    x0 = p1.initial_population(config, function_index, seed)
    rng = np.random.Generator(np.random.PCG64(np.random.SeedSequence([config['root_seed'], function_index, seed, 3])))
    return run_de(obj, x0, rng, config['de']), x0
