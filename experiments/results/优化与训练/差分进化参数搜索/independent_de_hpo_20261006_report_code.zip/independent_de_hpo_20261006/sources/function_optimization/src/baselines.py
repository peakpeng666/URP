"""Transparent NumPy baselines; no external optimizer library or model API.

All objective calls made by the optimizers pass through CountedObjective.
Initial population is charged; duplicate candidates are charged; no early stop.
"""
from __future__ import annotations
import hashlib
from dataclasses import dataclass
import numpy as np


def sphere(x):
    x = np.asarray(x, dtype=np.float64)
    return np.sum(x * x, axis=-1)


def rastrigin(x):
    x = np.asarray(x, dtype=np.float64)
    # This equivalent expression avoids subtracting two large sums at x=0.
    return np.sum(x * x + 10.0 * (1.0 - np.cos(2.0 * np.pi * x)), axis=-1)


def ackley(x):
    x = np.asarray(x, dtype=np.float64)
    radial = -0.2 * np.sqrt(np.mean(x * x, axis=-1))
    oscillatory = np.mean(np.cos(2.0 * np.pi * x), axis=-1) - 1.0
    # Algebraically -20 exp(radial) - exp(mean cos) + 20 + e.
    # expm1 improves accuracy near zero; no artificial flooring in objective.
    return -20.0 * np.expm1(radial) - np.e * np.expm1(oscillatory)


FUNCTIONS = {"Sphere": sphere, "Rastrigin": rastrigin, "Ackley": ackley}


@dataclass
class CountedObjective:
    name: str
    dimension: int
    lower: float
    upper: float
    budget: int

    def __post_init__(self):
        self.count = 0
        self.best_f = float("inf")
        self.best_x = None
        self.trace = []
        self.all_values = []
        self.boundary_coordinate_count = 0

    def evaluate(self, x):
        x = np.asarray(x, dtype=np.float64)
        if x.ndim != 2 or x.shape[1] != self.dimension or len(x) == 0:
            raise ValueError("Objective requires a nonempty (n, dimension) array")
        if self.count + len(x) > self.budget:
            raise ValueError("Objective evaluation budget exceeded")
        if not np.all(np.isfinite(x)):
            raise ValueError("Nonfinite candidate")
        if np.any(x < self.lower) or np.any(x > self.upper):
            raise ValueError("Out-of-bounds candidate")
        y = FUNCTIONS[self.name](x)
        self.count += len(x)
        if y.shape != (len(x),) or not np.all(np.isfinite(y)):
            raise ValueError("Nonfinite or malformed objective result")
        i = int(np.argmin(y))
        if y[i] < self.best_f:
            self.best_f = float(y[i])
            self.best_x = x[i].copy()
        self.boundary_coordinate_count += int(np.sum((x == self.lower) | (x == self.upper)))
        self.trace.append((self.count, self.best_f, float(np.min(y)), float(np.mean(y))))
        self.all_values.append(y.copy())
        return y


def initial_population(config, function_index, seed):
    f = config["functions"][function_index]
    rng = np.random.default_rng(np.random.SeedSequence([config["root_seed"], function_index, seed, 0]))
    return rng.uniform(f["lower"], f["upper"], (config["population_size"], config["dimension"]))


def population_hash(x):
    return hashlib.sha256(np.ascontiguousarray(x, dtype="<f8").tobytes()).hexdigest()


def operator_rng(config, function_index, seed, algorithm):
    # Distinct streams from shared initialization. Algorithm order cannot alter RNG.
    stream = {"GA": 1, "PSO": 2}[algorithm]
    return np.random.default_rng(np.random.SeedSequence([config["root_seed"], function_index, seed, stream]))


def sbx_children(parents, rng, lower, upper, eta, p_pair, p_coordinate):
    """SBX inverse CDF on paired real parents, followed by explicit clipping.

    beta=(2u)^(1/(eta+1)) for u<=.5, else (1/(2(1-u)))^(1/(eta+1)).
    Children are midpoint +/- beta * half parent difference. This is unbounded
    SBX with clip repair, not the distribution-conditioned bounded SBX variant.
    """
    a, b = parents[0::2], parents[1::2]
    if a.shape != b.shape:
        raise ValueError("SBX requires an even number of parents")
    active = (rng.random((len(a), 1)) < p_pair) & (rng.random(a.shape) < p_coordinate)
    u = rng.random(a.shape)
    beta = np.where(u <= 0.5, (2.0 * u) ** (1.0 / (eta + 1.0)),
                    (1.0 / (2.0 * (1.0 - u))) ** (1.0 / (eta + 1.0)))
    c1 = 0.5 * ((1.0 + beta) * a + (1.0 - beta) * b)
    c2 = 0.5 * ((1.0 - beta) * a + (1.0 + beta) * b)
    out = parents.copy()
    out[0::2] = np.where(active, c1, a)
    out[1::2] = np.where(active, c2, b)
    return np.clip(out, lower, upper)


def polynomial_mutation(x, rng, lower, upper, eta, probability):
    """Boundary-distance polynomial mutation, Deb & Deb (2012), equations 1–3.

    Left displacement scales by x-lower, right displacement by upper-x.
    Explicit choice, different from the common NSGA-II full-range variant.
    """
    active = rng.random(x.shape) < probability
    u = rng.random(x.shape)
    left = (2.0 * u) ** (1.0 / (eta + 1.0)) - 1.0
    right = 1.0 - (2.0 * (1.0 - u)) ** (1.0 / (eta + 1.0))
    delta = np.where(u <= 0.5, left * (x - lower), right * (upper - x))
    return np.clip(np.where(active, x + delta, x), lower, upper)


def run_ga(objective, x0, rng, params):
    pop = x0.copy()
    n = len(pop)
    if n % 2 or objective.budget % n:
        raise ValueError("GA needs even population and budget divisible by population")
    fitness = objective.evaluate(pop)
    while objective.count < objective.budget:
        contestants = rng.integers(0, n, (n, params["tournament_size"]))
        winners = contestants[np.arange(n), np.argmin(fitness[contestants], axis=1)]
        children = sbx_children(pop[winners], rng, objective.lower, objective.upper,
                               params["sbx_eta"], params["crossover_probability_per_pair"],
                               params["crossover_probability_per_coordinate"])
        children = polynomial_mutation(children, rng, objective.lower, objective.upper,
                                       params["mutation_eta"], params["mutation_probability_per_coordinate"])
        child_fitness = objective.evaluate(children)
        e = params["parent_elites"]
        elite_ids = np.argsort(fitness, kind="stable")[:e]
        merged = np.concatenate([pop[elite_ids], children])
        merged_fitness = np.concatenate([fitness[elite_ids], child_fitness])
        keep = np.argsort(merged_fitness, kind="stable")[:n]
        pop, fitness = merged[keep], merged_fitness[keep]
    return objective


def pso_step(x, v, pbest, gbest, rng, w, params, lower, upper):
    vmax = params["velocity_limit_fraction_of_range"] * (upper - lower)
    v = (w * v + params["cognitive"] * rng.random(x.shape) * (pbest - x)
         + params["social"] * rng.random(x.shape) * (gbest - x))
    v = np.clip(v, -vmax, vmax)
    proposal = x + v
    crossed = (proposal < lower) | (proposal > upper)
    x = np.clip(proposal, lower, upper)
    v[crossed] = 0.0
    return x, v


def run_pso(objective, x0, rng, params):
    x = x0.copy()
    n = len(x)
    if objective.budget % n:
        raise ValueError("PSO budget must be divisible by population")
    v = np.zeros_like(x)
    pbest = x.copy()
    pbest_f = objective.evaluate(x)
    updates = objective.budget // n - 1
    for t in range(updates):
        fraction = t / max(updates - 1, 1)
        w = params["inertia_start"] + fraction * (params["inertia_end"] - params["inertia_start"])
        gbest = pbest[int(np.argmin(pbest_f))].copy()
        x, v = pso_step(x, v, pbest, gbest, rng, w, params, objective.lower, objective.upper)
        f = objective.evaluate(x)
        improved = f < pbest_f
        pbest[improved], pbest_f[improved] = x[improved], f[improved]
    return objective


def optimize(config, function_index, seed, algorithm):
    f = config["functions"][function_index]
    obj = CountedObjective(f["name"], config["dimension"], f["lower"], f["upper"], config["evaluation_budget"])
    x0 = initial_population(config, function_index, seed)
    rng = operator_rng(config, function_index, seed, algorithm)
    runner = {"GA": run_ga, "PSO": run_pso}[algorithm]
    return runner(obj, x0, rng, config[algorithm.lower()]), x0
