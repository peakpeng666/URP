from pathlib import Path
import os,json
os.environ.setdefault('MPLCONFIGDIR','/tmp/nas_matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm
import numpy as np
R=Path(__file__).resolve().parents[1];s=json.load(open(R/'reports/summary.json'));cfg=json.load(open(R/'config.json'))
font=fm.FontProperties(fname='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
plt.rcParams.update({'font.family':font.get_name(),'axes.unicode_minus':False,'axes.spines.top':False,'axes.spines.right':False,'axes.spines.left':False,'axes.spines.bottom':False,'font.size':11,'savefig.facecolor':'white'})
colors=['#536B7A','#A47864','#4C8A99','#8E78A3','#9A9A64','#C18A3E','#667BB0','#007E73']
fig,ax=plt.subplots(figsize=(11.4,6.4));fig.subplots_adjust(left=.1,right=.93,top=.79,bottom=.19)
for row,col in zip(s['architectures'],colors):
 y=[row[k] for k in ['discovery_2_rank','discovery_20_rank','confirmation_20_rank']]
 win=row['architecture_id']==s['selection']['low'];ax.plot([0,1,2],y,'o-',color=col,lw=3 if win else 1.6,ms=7 if win else 5,alpha=1 if win else .85)
 ax.text(2.06,y[-1],row['architecture_id'],va='center',color=col,fontweight='bold' if win else 'normal',fontsize=10)
ax.set_xlim(-.12,2.58);ax.set_ylim(8.55,.45);ax.set_yticks(range(1,9));ax.set_ylabel('5-seed均值排名（1最好）',labelpad=12)
ax.set_xticks([0,1,2],['发现组 · 2轮','发现组 · 20轮','独立新seed · 20轮']);ax.grid(axis='y',color='#E8ECED',lw=.8);ax.tick_params(axis='both',length=0,pad=8)
fig.text(.085,.935,'Top1保持，完整排名仍有变化',fontproperties=font,fontsize=22,fontweight='bold',color='#183A44')
fig.text(.085,.874,'2轮 vs 20轮：Kendall τ = 0.500     20轮 vs 独立确认：τ = 0.929',fontproperties=font,fontsize=12,color='#53616B')
fig.text(.085,.087,'8种固定CNN；发现5seed、确认另5seed；同一4,000训练 / 1,000 validation划分。',fontproperties=font,fontsize=10,color='#52606B')
fig.text(.085,.047,'20轮为更高固定预算，非收敛真值。确认独立性限训练随机性；官方test未使用。',fontproperties=font,fontsize=10,color='#52606B')
for ext in ['png','pdf']:fig.savefig(R/'figures'/('01_排名变化.'+ext),dpi=180)
plt.close(fig)
rows=sorted(s['architectures'],key=lambda r:-r['confirmation_20_mean_accuracy'])
fig,ax=plt.subplots(figsize=(11.4,6.4));fig.subplots_adjust(left=.20,right=.94,top=.79,bottom=.19)
for i,row in enumerate(rows):
 vals=[json.load(open(R/'raw'/f"confirmation_{seed}_{row['architecture_id']}.json"))['epochs'][-1]['validation']['accuracy']*100 for seed in cfg['confirmation_seeds']]
 col='#007E73' if i==0 else '#7894A3';ax.scatter(vals,[i+v for v in [-.12,-.06,0,.06,.12]],s=22,color='#A7B4B9',zorder=2)
 ax.errorbar(row['confirmation_20_mean_accuracy']*100,i,xerr=row['confirmation_20_seed_std']*100,fmt='D',color=col,markersize=7,capsize=5,lw=2,zorder=3)
 ax.text(max(vals)+1.3,i,f"{row['confirmation_20_mean_accuracy']*100:.2f}%",va='center',color=col,fontsize=10)
ax.set_yticks(range(8),[r['architecture_id'] for r in rows]);ax.set_ylim(7.65,-.65);ax.set_xlim(22,48);ax.set_xlabel('确认组20轮 validation准确率（%）',labelpad=10);ax.grid(axis='x',color='#E8ECED',lw=.8);ax.tick_params(axis='both',length=0,pad=8)
fig.text(.085,.935,'独立重训：保留每一个seed',fontproperties=font,fontsize=22,fontweight='bold',color='#183A44')
fig.text(.085,.874,'灰点 = 每seed实测；菱形 / 横线 = 5-seed均值 ± 1个样本标准差（不是置信区间）',fontproperties=font,fontsize=11,color='#53616B')
fig.text(.085,.087,'两预算均选 d3_w16_k5，确认均值40.92%、经验后悔0；单seed的2/20轮top1有3/5改变。',fontproperties=font,fontsize=10,color='#52606B')
fig.text(.085,.047,'同一验证集上的经验比较，不是population最优或未见测试泛化证明。',fontproperties=font,fontsize=10,color='#52606B')
for ext in ['png','pdf']:fig.savefig(R/'figures'/('02_独立重训分布.'+ext),dpi=180)
plt.close(fig)
print('Rendered two evidence-based figures, PNG and vector PDF.')
