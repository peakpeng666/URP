from pathlib import Path
import json,re
R=Path(__file__).resolve().parents[1]
read=lambda p:json.loads(p.read_text())
s=read(R/'reports/summary.json');a=read(R/'audit/results_audit.json');data=read(R/'artifacts/data_recovery.json');analysis=read(R/'artifacts/analysis_cost.json')
process=read(next((R/'artifacts').glob('process_all_*.json')));env=read(next((R/'artifacts').glob('environment_all_*.json')))
components=[{'stage':'official-data hash/extraction','wall_seconds':data['preparation_wall_seconds'],'cpu_seconds':data['preparation_process_cpu_seconds']},
{'stage':'formal process data load','wall_seconds':env['data_loading_wall_seconds'],'cpu_seconds':env['data_loading_cpu_seconds']},
{'stage':'formal model training/validation/selection-freeze body','wall_seconds':process['wall_seconds'],'cpu_seconds':process['cpu_seconds']},
{'stage':'primary result analysis process','wall_seconds':analysis['wall_seconds'],'cpu_seconds':analysis['cpu_seconds']},
{'stage':'independent final audit','wall_seconds':a['wall_seconds'],'cpu_seconds':a['cpu_seconds']}]
for fn in ['data_download_clean_time.log','data_download_clean_retry_time.log','data_download_final_resume_time.log']:
 text=(R/'artifacts'/fn).read_text();out={}
 for key in ['real','user','sys']:
  matches=re.findall(r'\b'+key+r'\s+(\d+)m([\d.]+)s',text)
  if matches:out[key]=int(matches[-1][0])*60+float(matches[-1][1])
 if len(out)==3:components.append({'stage':fn,'wall_seconds':out['real'],'cpu_seconds':out['user']+out['sys']})
obj={'scope':'Read-only post-run cost aggregation; no new training/evaluation/selection and no frozen source changes',
'nonoverlapping_known_main_components':components,'summed_known_cpu_seconds':sum(x['cpu_seconds'] for x in components),
'summed_component_wall_seconds':sum(x['wall_seconds'] for x in components),
'wall_sum_warning':'sum of listed stages, not end-to-end assistant latency; parallel setup and interactions make latency different',
'not_in_known_sum':['dependency installation','initial interrupted/conflicting download CPU','preliminary/final preflights','synthetic smoke and fault injection','figure/report rendering','zip packaging and Drive transfers/hash readback'],
'known_training_body_wall_seconds':process['wall_seconds'],'known_training_body_cpu_seconds':process['cpu_seconds'],
'formal_training_runs':80,'formal_optimizer_steps':51200,'train_presentations':6400000,'primary_validation_presentations':1600000,'audit_validation_presentations':160000,
'new_study_total_validation_presentations':1760000,'official_test_presentations':0,'gpu_used':False,'new_model_api_calls':0,
'prior_p4_costs_included':False,'maxrss_mib':process['maxrss_kib']/1024}
(R/'reports/cost_ledger.json').write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
lines=['# 成本补充：训练、恢复与审计分账','',f"正式训练主体墙钟 {process['wall_seconds']:.3f} 秒（{process['wall_seconds']/60:.2f} 分钟），进程CPU {process['cpu_seconds']:.3f} 秒；最高RSS {obj['maxrss_mib']:.1f} MiB。80条轨迹无失败、无恢复，源文件freeze未变。",'',
'独立确认40条×20轮已计入训练主体；主研究160万validation呈现及独立审计16万次共176万次，均为重复使用同1000张validation。没有官方测试呈现。',
'', '| 分项 | 墙钟秒 | CPU秒 |','|---|---:|---:|']
for x in components:lines.append(f"| {x['stage']} | {x['wall_seconds']:.3f} | {x['cpu_seconds']:.3f} |")
lines+=['',f"以上已测且不互相包含的主分项CPU合计 {obj['summed_known_cpu_seconds']:.3f} 秒；并非所有工程/网络活动的完整费用。两次前期下载中断/冲突、安装、前置审查、synthetic测试、制图、打包和Drive传输另有日志，部分未完整量测，不能当零。各分项墙钟相加也不等于对话中的端到端等待时间。",'',
'主报告中的2197.609秒是80个run计时之和，包含于本表2197.724秒正式主体中，二者不可重复相加。104.101秒与992.046秒的2/20轮逻辑评分成本是嵌套反事实选择预算，亦不可加作额外实际训练。', '',
'cost_ledger.py仅在结果后汇整既有计时，不训练、不评分、不修改冻结选择。原P4历史费用不并入本新研究。']
(R/'reports/成本补充_中文.md').write_text('\n'.join(lines)+'\n')
print(json.dumps(obj,ensure_ascii=False,indent=2))
