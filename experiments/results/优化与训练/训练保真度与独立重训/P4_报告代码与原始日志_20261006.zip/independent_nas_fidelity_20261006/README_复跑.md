# P4保真度实验：文件与复跑

本项目保留旧P4八种CNN、同一4000/1000开发划分与训练配方，补做2/20轮端点排名和新seed独立重训。正式结果见 `reports/结果报告_中文.md`，执行前设计见 `PROTOCOL_中文.md`。20轮不代表已充分收敛；官方测试集不读取。

## 内容

- `config.json`、`artifacts/pre_run_freeze.json`：预设80条运行顺序与冻结哈希
- `source/`：训练、安全训练集解析、故障恢复、统计与报告生成
- `raw/attempts.jsonl`、`raw/epochs.jsonl`：全量尝试和逐epoch原始日志
- `raw/*_predictions.json`、`checkpoints/`：160个预设端点的预测、模型和优化器；另有80个逐epoch替换式恢复点
- `artifacts/selection_freeze*.json`：确认训练开始前的两项top1选择及哈希
- `reports/summary.json`、`reports/*.csv`：可重算结构分数、全部逐轮统计和成本
- `audit/`：另一实现独立复核，160端点以batch73重算，统计和费用另列
- `evidence/original_p4/`：完整124文件只读旧P4快照（不含数据集），供配方、围栏和旧结果对照
- `evidence/P176_inherited_reading.md`、`P408_inherited_reading.md`：继承阅读证据，不冒称本轮全文复读

## 环境

Python 3.12，PyTorch 2.14.1+cpu和NumPy2.5.3。依赖锁在requirements.lock.txt。当前执行未使用GPU或新模型API。不要把venv或数据集提交到GitHub。

## 在新目录中重跑

不要删除或覆盖本次证据。先准备一个全新父目录，例如 `/tmp/nas_reproduction`，将本目录复制为其下的 `nas_fidelity`。从复制件移出 `raw/`、`checkpoints/`、`reports/` 和本次动态 `artifacts/` 后重新建立空目录；原交付件保持不动。把复制件的 `evidence/original_p4/` 完整复制到新父目录的 `URP/experiments/architecture_search/`，使只读围栏可重核。

在新实验目录中依次运行：

```sh
python -m venv .venv
.venv/bin/python -m pip install torch==2.14.1+cpu --index-url https://download.pytorch.org/whl/cpu
.venv/bin/python -m pip install numpy==2.5.3
.venv/bin/python -m pip freeze > requirements.lock.txt
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
mkdir -p data artifacts raw checkpoints reports
curl --fail --location --max-time 1800 https://cave.cs.toronto.edu/kriz/cifar-10-binary.tar.gz -o data/cifar-10-binary.tar.gz
.venv/bin/python source/prepare_data.py
.venv/bin/python source/smoke_timing.py > artifacts/smoke_stdout.json
.venv/bin/python source/test_primitives.py > artifacts/pre_run_tests.txt 2>&1
.venv/bin/python source/test_recovery.py > artifacts/recovery_fault_tests.txt 2>&1
.venv/bin/python source/freeze.py
.venv/bin/python audit/check_fidelity.py --phase preflight
.venv/bin/python source/run_fidelity.py --phase all > artifacts/training.log 2>&1
.venv/bin/python source/analyze.py > artifacts/analysis.log
.venv/bin/python audit/check_fidelity.py --phase results --checkpoints all
.venv/bin/python source/build_report.py
```

复跑应有独立的freeze时间和费用；不修改本次已冻结结果。如果网络下载中断，先确认旧进程终止后才能对同一文件续传；必须通过完整archive SHA256/MD5与五个训练成员hash才可训练。不要并行写同一路径。代码从压缩包只提取五个训练batch，禁止提取test。

确需恢复未完成训练时，只对该次未完成复跑执行 `source/run_fidelity.py --phase all --resume`。这会保留既有结果并验证检查点/日志一致；中断的部分epoch成本可能无法恢复，会明确标记不完整。不能以重新建目录、换seed或删除失败记录的方式挑结果。

上述是可执行复跑路径，包内代码与当前版本均已本机检查；干净机器重新安装和跨硬件位级一致不作未经测试的保证。正式freeze与独立审查报告记录实际运行证据。
