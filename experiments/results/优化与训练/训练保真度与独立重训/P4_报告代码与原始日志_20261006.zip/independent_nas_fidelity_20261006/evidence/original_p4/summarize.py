#!/usr/bin/env python3
import csv
import json
from pathlib import Path
from statistics import mean
import run_experiment as exp

root=exp.ROOT
cfg=json.loads(exp.CONFIG.read_text())
rows=[]
trials=[]
for seed in cfg["search_seeds"]:
    for method in ["reinforce","random"]:
        run=json.loads((root/f"results/{method}_{seed}.json").read_text())
        row={key:run[key] for key in ["method","seed","selected_trial","selected_validation_accuracy","unique_architectures","total_wall_seconds","total_process_cpu_seconds"]}
        row.update(run["selected_architecture"])
        for field in ["optimizer_steps","train_image_presentations","validation_image_presentations","train_forward_conv_linear_macs","validation_forward_conv_linear_macs","selector_wall_seconds","selector_process_cpu_seconds"]:
            row[field]=sum(trial[field] for trial in run["trials"])
        rows.append(row)
        for trial in run["trials"]:
            trials.append(dict(method=method,seed=seed,trial_index=trial["trial_index"],**trial["architecture"],validation_accuracy=trial["validation"]["accuracy"],parameter_count=trial["parameter_count"],training_seed=trial["training_seed"],wall_seconds=trial["total_wall_seconds"],process_cpu_seconds=trial["total_process_cpu_seconds"]))
for name,data in [("search_summary.csv",rows),("trials.csv",trials)]:
    with open(root/"results"/name,"w",newline="") as output:
        writer=csv.DictWriter(output,fieldnames=list(data[0]));writer.writeheader();writer.writerows(data)
paired=[]
for seed in cfg["search_seeds"]:
    pair={r["method"]:r for r in rows if r["seed"]==seed}
    paired.append({"seed":seed,"reinforce_selected_validation_accuracy":pair["reinforce"]["selected_validation_accuracy"],"random_selected_validation_accuracy":pair["random"]["selected_validation_accuracy"],"reinforce_minus_random_percentage_points":100*(pair["reinforce"]["selected_validation_accuracy"]-pair["random"]["selected_validation_accuracy"])})
baseline=json.loads((root/"results/baseline.json").read_text())
audit=json.loads((root/"artifacts/verification_recompute.json").read_text())
summary={"protocol_id":cfg["protocol_id"],"scope":cfg["scope"],"baseline_initial_validation_accuracy":baseline["initial_validation"]["accuracy"],"baseline_final_validation_accuracy":baseline["validation"]["accuracy"],
    "paired_results":paired,"method_descriptive_means":{method:{"selected_validation_accuracy":mean(r["selected_validation_accuracy"] for r in rows if r["method"]==method),"total_search_wall_seconds":sum(r["total_wall_seconds"] for r in rows if r["method"]==method),"total_search_process_cpu_seconds":sum(r["total_process_cpu_seconds"] for r in rows if r["method"]==method),"train_forward_conv_linear_macs":sum(r["train_forward_conv_linear_macs"] for r in rows if r["method"]==method)} for method in ["reinforce","random"]},
    "cost_accounting":{"search_child_trainings":48,"fixed_baseline_trainings":1,"total_optimizer_steps":sum(r["optimizer_steps"] for r in rows)+baseline["optimizer_steps"],"total_train_image_presentations":sum(r["train_image_presentations"] for r in rows)+baseline["train_image_presentations"],"search_validation_image_presentations":sum(r["validation_image_presentations"] for r in rows),"baseline_validation_image_presentations":baseline["validation_image_presentations"],"audit_validation_image_presentations":audit["audit_validation_image_presentations"],"total_validation_image_presentations":sum(r["validation_image_presentations"] for r in rows)+baseline["validation_image_presentations"]+audit["audit_validation_image_presentations"],"controller_optimizer_steps":24,"selected_architecture_retrainings":0,"official_test_evaluations":0,"failed_trials":audit["failed_search_trials"]},
    "inference_warning":"Only three paired search seeds on one reused development split; selected maxima are optimistic. No independent-generalization, convergence, statistical-superiority, or matched-compute claim is supported."}
exp.save_json(root/"results/summary.json",summary)
print(json.dumps(summary,ensure_ascii=False,indent=2))
