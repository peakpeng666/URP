#!/usr/bin/env python3
"""Verify all accounting and independently re-score saved models; never access test."""
import argparse
import json
import math
from pathlib import Path
import time
import numpy as np
import torch
import run_experiment as exp

def verify(recompute=False):
    started_wall, started_cpu = time.perf_counter(), time.process_time()
    cfg = json.loads(exp.CONFIG.read_text())
    exp.configure(cfg)
    root = exp.ROOT
    split = json.loads((root/"artifacts/split.json").read_text())
    assert [len(split[k]) for k in ["train","validation","reserved"]] == [4000,1000,45000]
    assert len(set(split["train"]+split["validation"]+split["reserved"])) == 50000
    assert set(split["train"]+split["validation"]+split["reserved"]) == set(range(50000))
    assert not list((root/"data").rglob("*test*")), "Official test must remain unextracted"
    freeze = json.loads((root/"artifacts/presearch_freeze.json").read_text())
    for name, digest in freeze["files"].items():
        assert exp.digest(root/name) == digest, f"Pre-search frozen file changed: {name}"
    sources=[root/"artifacts/source_at_baseline.py",root/"artifacts/source_at_search.py"]
    source_hashes={exp.digest(p) for p in sources}
    for env in (root/"artifacts").glob("environment_*.json"):
        record=json.loads(env.read_text())
        assert record["source_sha256"] in source_hashes
        assert record["config_sha256"] == exp.digest(exp.CONFIG)
        assert record["torch_threads"] == 1 and record["deterministic_algorithms"]
    baseline=json.loads((root/"results/baseline.json").read_text())
    all_trials=[baseline]
    for seed in cfg["search_seeds"]:
        pair={}
        for method in ["reinforce","random"]:
            result=json.loads((root/f"results/{method}_{seed}.json").read_text())
            assert result["config_sha256"]==exp.digest(exp.CONFIG)
            assert result["split_sha256"]==exp.digest(root/"artifacts/split.json")
            trials=result["trials"]
            assert len(trials)==cfg["trials_per_search"]
            journal=[json.loads(line) for line in (root/f"results/{method}_{seed}.jsonl").read_text().splitlines()]
            assert journal==trials
            attempts=[json.loads(line) for line in (root/f"results/{method}_{seed}_attempts.jsonl").read_text().splitlines()]
            assert len(attempts)==2*len(trials)
            for i,t in enumerate(trials):
                assert attempts[2*i]["status"]=="started" and attempts[2*i+1]["status"]=="completed"
                assert attempts[2*i]["trial_index"]==attempts[2*i+1]["trial_index"]==i
                assert attempts[2*i+1]["consumed_wall_seconds"]>=t["total_wall_seconds"]
                assert t["training_seed"]==1000000+seed*100+i
                assert t["trial_index"]==i
                assert t["validation_image_presentations"]==1000
                probabilities=np.array(t["sampling_probabilities"])
                assert np.allclose(probabilities.sum(axis=1),1)
                if method=="random": assert np.all(probabilities==0.5)
                else: assert t["controller_loss"] is not None
            selected=max(range(len(trials)), key=lambda i: trials[i]["validation"]["accuracy"])
            assert result["selected_trial"]==selected
            assert result["selected_validation_accuracy"]==trials[selected]["validation"]["accuracy"]
            assert result["official_test_evaluations"]==0
            all_trials+=trials
            pair[method]=trials
        for a,b in zip(pair["reinforce"],pair["random"]):
            if a["architecture"]==b["architecture"]:
                assert a["validation"]==b["validation"], "Paired equal-architecture model must be deterministic"
    recomputed=[]
    tensors=exp.load_development(cfg) if recompute else None
    for trial in all_trials:
        assert trial["optimizer_steps"]==64
        assert trial["train_image_presentations"]==8000
        assert len(trial["epochs"])==2
        assert trial["validation"]["n"]==1000
        assert trial["validation"]["accuracy"]==trial["validation"]["correct"]/1000
        checkpoint=root/trial["checkpoint"]
        assert checkpoint.exists() and exp.digest(checkpoint)==trial["checkpoint_sha256"]
        saved=torch.load(checkpoint,weights_only=True,map_location="cpu")
        assert saved["config_sha256"]==exp.digest(exp.CONFIG)
        assert saved["epochs_completed"]==2
        model=exp.TinyCNN(saved["architecture"])
        model.load_state_dict(saved["model_state_dict"],strict=True)
        assert sum(p.numel() for p in model.parameters())==trial["parameter_count"]
        assert all(torch.isfinite(p).all() for p in model.parameters())
        if recompute:
            # Different batch size and separate metric implementation from training.
            model.eval(); correct=0; loss_sum=0.0
            images,labels=tensors["validation"]
            with torch.no_grad():
                for start in range(0,len(labels),64):
                    scores=model(images[start:start+64])
                    targets=labels[start:start+64]
                    correct+=int((scores.argmax(dim=1)==targets).sum())
                    loss_sum+=float((-scores.log_softmax(1)[torch.arange(len(targets)),targets]).sum())
            assert correct==trial["validation"]["correct"]
            assert abs(loss_sum/1000-trial["validation"]["loss"])<1e-5
            recomputed.append({"checkpoint":trial["checkpoint"],"correct":correct,"n":1000,"loss":loss_sum/1000})
    report={"status":"passed","checkpoints_verified":len(all_trials),"search_runs":6,"completed_search_trials":48,
        "failed_search_trials":0,"incomplete_attempts":0,"same_architecture_pair_determinism":"passed",
        "config_and_split_and_source_freeze":"passed","test_file_absence":"passed",
        "official_test_evaluations":0,"checkpoint_recomputations":recomputed,
        "audit_validation_image_presentations":len(recomputed)*1000,"audit_training_image_presentations":0,
        "audit_wall_seconds":time.perf_counter()-started_wall,"audit_process_cpu_seconds":time.process_time()-started_cpu,
        "completed_at_utc":exp.timestamp(),"note":"Audit validation passes are additional cost, excluded from search budget and included in reporting"}
    exp.save_json(root/"artifacts/verification_recompute.json" if recompute else root/"artifacts/verification.json",report)
    print(json.dumps({k:v for k,v in report.items() if k!="checkpoint_recomputations"},indent=2))

if __name__=="__main__":
    parser=argparse.ArgumentParser(); parser.add_argument("--recompute",action="store_true")
    verify(parser.parse_args().recompute)
