#!/usr/bin/env python3
"""Freeze first, then assess existing models on new reserved IDs without retraining."""
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import time

import numpy as np
import torch
import run_experiment as exp

ROOT=exp.ROOT
POST=ROOT/"postselection"
PROTOCOL=POST/"protocol.json"

def state_hash(state):
    digest=hashlib.sha256()
    for key,tensor in sorted(state.items()):
        array=tensor.detach().cpu().contiguous().numpy()
        digest.update(key.encode());digest.update(str(array.dtype).encode());digest.update(str(array.shape).encode());digest.update(array.tobytes())
    return digest.hexdigest()

def freeze():
    if (POST/"selection_freeze.json").exists():
        raise FileExistsError("Postselection identities already frozen; do not overwrite")
    protocol=json.loads(PROTOCOL.read_text())
    cfg=json.loads(exp.CONFIG.read_text())
    split=json.loads((ROOT/"artifacts/split.json").read_text())
    # Only index metadata and frozen model weights are read here, not data samples/labels.
    chosen=np.random.default_rng(protocol["sampling_seed"]).choice(np.array(split["reserved"]),size=protocol["assessment_count"],replace=False).tolist()
    exp.save_json(POST/"assessment_indices.json",chosen)
    refs=[]
    baseline=json.loads((ROOT/"results/baseline.json").read_text())
    refs.append({"alias":"baseline","method":"fixed_baseline","search_seed":None,"trial":baseline})
    for seed in cfg["search_seeds"]:
        for method in ["reinforce","random"]:
            run=json.loads((ROOT/f"results/{method}_{seed}.json").read_text())
            refs.append({"alias":f"{method}_{seed}","method":method,"search_seed":seed,"trial":run["trials"][run["selected_trial"]]})
    unique={}
    aliases=[]
    for ref in refs:
        trial=ref.pop("trial")
        checkpoint=ROOT/trial["checkpoint"]
        assert exp.digest(checkpoint)==trial["checkpoint_sha256"]
        saved=torch.load(checkpoint,weights_only=True,map_location="cpu")
        weight_hash=state_hash(saved["model_state_dict"])
        if weight_hash not in unique:
            model_id="baseline" if ref["alias"]=="baseline" else f"winner_seed_{ref['search_seed']}"
            unique[weight_hash]={"model_id":model_id,"checkpoint":trial["checkpoint"],"checkpoint_sha256":trial["checkpoint_sha256"],"weights_sha256":weight_hash,"architecture":trial["architecture"],"training_seed":trial["training_seed"],"search_validation_accuracy":trial["validation"]["accuracy"],"search_validation_correct":trial["validation"]["correct"],"aliases":[]}
        model=unique[weight_hash]
        model["aliases"].append(ref["alias"])
        aliases.append(dict(ref,model_id=model["model_id"],checkpoint=trial["checkpoint"],checkpoint_sha256=trial["checkpoint_sha256"],weights_sha256=weight_hash))
    assert len(unique)==4,"Unexpected deduplication; requires protocol review"
    record={"frozen_at_utc":exp.timestamp(),"protocol_sha256":exp.digest(PROTOCOL),"indices_sha256":exp.digest(POST/"assessment_indices.json"),"source_sha256":exp.digest(Path(__file__)),"pilot_config_sha256":exp.digest(exp.CONFIG),"pilot_split_sha256":exp.digest(ROOT/"artifacts/split.json"),"sampling_used_labels":False,"official_test_access":False,"unique_models":list(unique.values()),"aliases":aliases,"assessment_count":len(chosen),"reserved_remaining_unassessed":len(split["reserved"])-len(chosen)}
    exp.save_json(POST/"selection_freeze.json",record)
    print(f"Frozen {len(chosen)} indices and {len(unique)} unique models from {len(aliases)} aliases before assessment labels/predictions")

def validate_freeze():
    record=json.loads((POST/"selection_freeze.json").read_text())
    assert exp.digest(PROTOCOL)==record["protocol_sha256"]
    assert exp.digest(POST/"assessment_indices.json")==record["indices_sha256"]
    assert exp.digest(Path(__file__))==record["source_sha256"]
    assert exp.digest(ROOT/"artifacts/split.json")==record["pilot_split_sha256"]
    assert exp.digest(exp.CONFIG)==record["pilot_config_sha256"]
    indices=json.loads((POST/"assessment_indices.json").read_text())
    split=json.loads((ROOT/"artifacts/split.json").read_text())
    assert len(indices)==len(set(indices))==5000
    assert set(indices)<=set(split["reserved"])
    assert set(indices).isdisjoint(split["train"]+split["validation"])
    assert not list((ROOT/"data").rglob("*test*"))
    for alias in record["aliases"]:
        assert exp.digest(ROOT/alias["checkpoint"])==alias["checkpoint_sha256"]
        state=torch.load(ROOT/alias["checkpoint"],weights_only=True,map_location="cpu")["model_state_dict"]
        assert state_hash(state)==alias["weights_sha256"]
    return record,indices

def wilson(correct,n,z):
    p=correct/n;den=1+z*z/n
    center=(p+z*z/(2*n))/den
    radius=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
    return [center-radius,center+radius]

def statistics(labels,predictions,models,protocol):
    n=len(labels);metrics=[];paired=[]
    base=(predictions["baseline"]==labels).astype(np.int8)
    for model in models:
        name=model["model_id"];correct_flags=(predictions[name]==labels).astype(np.int8)
        correct=int(correct_flags.sum());accuracy=correct/n
        metrics.append({"model_id":name,"aliases":model["aliases"],"correct":correct,"n":n,"accuracy":accuracy,"wilson95":wilson(correct,n,protocol["z"]),"search_validation_accuracy":model["search_validation_accuracy"],"search_validation_minus_assessment_percentage_points":100*(model["search_validation_accuracy"]-accuracy)})
        if name!="baseline":
            win=int(((correct_flags==1)&(base==0)).sum())
            loss=int(((correct_flags==0)&(base==1)).sum())
            both=int(((correct_flags==1)&(base==1)).sum())
            neither=n-win-loss-both
            delta=(win-loss)/n
            se=math.sqrt(max(0,((win+loss)/n-delta*delta)/(n-1)))
            paired.append({"model_id":name,"reference":"baseline","winner_only_correct":win,"baseline_only_correct":loss,"both_correct":both,"both_wrong":neither,"n":n,"accuracy_difference_percentage_points":100*delta,"paired_approximate95_percentage_points":[100*max(-1,delta-protocol["z"]*se),100*min(1,delta+protocol["z"]*se)]})
    return metrics,paired

def run():
    if (POST/"summary.json").exists() or (POST/"attempts.jsonl").exists():
        raise FileExistsError("Assessment already attempted; preserve original evidence")
    protocol=json.loads(PROTOCOL.read_text());record,indices=validate_freeze()
    torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
    started_wall,started_cpu=time.perf_counter(),time.process_time()
    exp.append_event(POST/"attempts.jsonl",{"status":"started","at_utc":exp.timestamp(),"selection_freeze_sha256":exp.digest(POST/"selection_freeze.json")})
    try:
        manifest=json.loads((ROOT/"artifacts/data_manifest.json").read_text())
        batches=[]
        for name in exp.TRAIN_FILES:
            assert exp.digest(ROOT/"data"/name)==manifest["extracted_files"][name]["sha256"]
            batches.append(np.memmap(ROOT/"data"/name,mode="r",dtype=np.uint8,shape=(10000,3073)))
        # This is the first materialization of these reserved labels/images for assessment.
        rows=np.stack([batches[i//10000][i%10000] for i in indices])
        labels=rows[:,0].copy().astype(np.int64)
        images=torch.from_numpy(rows[:,1:].copy()).reshape(-1,3,32,32).float().div_(255)
        predictions={};timings=[]
        for model in record["unique_models"]:
            wall,cpu=time.perf_counter(),time.process_time()
            checkpoint=torch.load(ROOT/model["checkpoint"],weights_only=True,map_location="cpu")
            network=exp.TinyCNN(model["architecture"])
            network.load_state_dict(checkpoint["model_state_dict"]);network.eval()
            outputs=[]
            with torch.no_grad():
                for start in range(0,len(labels),protocol["batch_size"]):
                    outputs.append(network(images[start:start+protocol["batch_size"]]).argmax(1).numpy())
            predictions[model["model_id"]]=np.concatenate(outputs)
            timings.append({"model_id":model["model_id"],"image_presentations":len(labels),"forward_conv_linear_macs":exp.forward_macs(model["architecture"])*len(labels),"wall_seconds":time.perf_counter()-wall,"process_cpu_seconds":time.process_time()-cpu})
        fields=["cifar_training_index","label"]+[model["model_id"] for model in record["unique_models"]]
        with open(POST/"predictions.csv","w",newline="") as output:
            writer=csv.DictWriter(output,fieldnames=fields);writer.writeheader()
            for j,index in enumerate(indices):
                writer.writerow(dict(cifar_training_index=index,label=int(labels[j]),**{name:int(pred[j]) for name,pred in predictions.items()}))
        metrics,paired=statistics(labels,predictions,record["unique_models"],protocol)
        summary={"protocol_id":protocol["protocol_id"],"assessment_sample_count":len(labels),"class_counts":np.bincount(labels,minlength=10).tolist(),"unique_models":len(record["unique_models"]),"model_aliases":len(record["aliases"]),"models":metrics,"paired_vs_baseline":paired,"model_costs":timings,"total_assessment_image_presentations":sum(t["image_presentations"] for t in timings),"training_image_presentations":0,"optimizer_updates":0,"official_test_image_presentations":0,"remaining_reserved_unassessed":record["reserved_remaining_unassessed"],"freeze_sha256":exp.digest(POST/"selection_freeze.json"),"predictions_sha256":exp.digest(POST/"predictions.csv"),"completed_at_utc":exp.timestamp(),"total_wall_seconds":time.perf_counter()-started_wall,"total_process_cpu_seconds":time.process_time()-started_cpu,"caveat":protocol["interpretation"]}
        exp.save_json(POST/"summary.json",summary)
    except BaseException as error:
        exp.append_event(POST/"attempts.jsonl",{"status":"failed","at_utc":exp.timestamp(),"error":str(error),"consumed_wall_seconds":time.perf_counter()-started_wall,"consumed_process_cpu_seconds":time.process_time()-started_cpu})
        raise
    exp.append_event(POST/"attempts.jsonl",{"status":"completed","at_utc":exp.timestamp(),"consumed_wall_seconds":time.perf_counter()-started_wall,"consumed_process_cpu_seconds":time.process_time()-started_cpu})
    print(json.dumps(summary,indent=2))

def verify():
    record,indices=validate_freeze();protocol=json.loads(PROTOCOL.read_text());summary=json.loads((POST/"summary.json").read_text())
    assert summary["freeze_sha256"]==exp.digest(POST/"selection_freeze.json")
    assert summary["predictions_sha256"]==exp.digest(POST/"predictions.csv")
    with open(POST/"predictions.csv") as source: rows=list(csv.DictReader(source))
    assert [int(row["cifar_training_index"]) for row in rows]==indices
    labels=np.array([int(row["label"]) for row in rows]); assert ((0<=labels)&(labels<10)).all()
    predictions={model["model_id"]:np.array([int(row[model["model_id"]]) for row in rows]) for model in record["unique_models"]}
    assert all(((0<=p)&(p<10)).all() for p in predictions.values())
    metrics,paired=statistics(labels,predictions,record["unique_models"],protocol)
    assert summary["models"]==metrics and summary["paired_vs_baseline"]==paired
    assert summary["total_assessment_image_presentations"]==20000
    assert summary["training_image_presentations"]==summary["optimizer_updates"]==summary["official_test_image_presentations"]==0
    events=[json.loads(line) for line in (POST/"attempts.jsonl").read_text().splitlines()]
    assert [event["status"] for event in events]==["started","completed"]
    assert record["frozen_at_utc"]<=events[0]["at_utc"]<=summary["completed_at_utc"]
    result={"status":"passed","assessment_rows":len(rows),"unique_models":len(predictions),"alias_count":len(record["aliases"]),"indices_disjoint_from_search_train_and_validation":True,"frozen_weights_unchanged":True,"counts_and_paired_outcomes_recomputed_from_csv":True,"official_test_access":False,"verification_extra_inference_presentations":0,"completed_at_utc":exp.timestamp()}
    exp.save_json(POST/"verification.json",result);print(json.dumps(result,indent=2))

if __name__=="__main__":
    parser=argparse.ArgumentParser();parser.add_argument("command",choices=["freeze","run","verify"])
    {"freeze":freeze,"run":run,"verify":verify}[parser.parse_args().command]()
