#!/usr/bin/env python3
"""Fault injection for the added journal, without any CIFAR training."""
import json
from pathlib import Path
import tempfile
from unittest.mock import patch
import run_experiment as exp

cfg=json.loads(exp.CONFIG.read_text())
with tempfile.TemporaryDirectory() as directory:
    root=Path(directory)
    (root/"results").mkdir()
    with patch.object(exp,"ROOT",root),patch.object(exp,"train_child",side_effect=RuntimeError("deliberate fault-injection")):
        try:
            exp.run_search("reinforce",101,{},cfg)
        except RuntimeError as error:
            assert str(error)=="deliberate fault-injection"
        else:
            raise AssertionError("Injected failure did not propagate")
    events=[json.loads(line) for line in (root/"results/reinforce_101_attempts.jsonl").read_text().splitlines()]
    assert [event["status"] for event in events]==["started","failed"]
    assert events[1]["consumed_process_cpu_seconds"]>0
    assert events[1]["consumed_wall_seconds"]>0
    assert not (root/"results/reinforce_101.json").exists()
    print("PASS: started and measured failed events persisted; no successful result created")
