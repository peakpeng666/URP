#!/usr/bin/env python3
"""Trusted fixed-primitives CIFAR-10 CPU NAS pilot. No test-data loader exists."""
from __future__ import annotations
import argparse
import hashlib
import itertools
import json
import math
import os
from pathlib import Path
import platform
import resource
import sys
import tarfile
import time
import urllib.request

import numpy as np
import torch
from torch import nn

ROOT = Path(__file__).resolve().parent
CONFIG = ROOT / "config.json"
TRAIN_FILES = [f"data_batch_{i}.bin" for i in range(1, 6)]

def digest(path, algorithm="sha256"):
    h = hashlib.new(algorithm)
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()

def save_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    temp.replace(path)

def timestamp():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

def append_event(path, value):
    with open(path, "a") as output:
        output.write(json.dumps(value) + "\n")
        output.flush()
        os.fsync(output.fileno())

def configure(cfg):
    torch.set_num_threads(cfg["threads"])
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)

def prepare(cfg):
    start_wall, start_cpu = time.perf_counter(), time.process_time()
    data = ROOT / "data"
    data.mkdir(exist_ok=True)
    archive = data / "cifar-10-binary.tar.gz"
    if not archive.exists():
        urllib.request.urlretrieve(cfg["dataset_url"], archive)
    if digest(archive, "md5") != cfg["dataset_md5"]:
        raise ValueError("Official archive checksum mismatch; refusing to parse")
    # Explicit whitelist: never extract or open test_batch.bin.
    with tarfile.open(archive, "r:gz") as tar:
        for filename in TRAIN_FILES:
            member = tar.getmember("cifar-10-batches-bin/" + filename)
            if not member.isfile() or member.size != 30730000:
                raise ValueError("Unexpected training member")
            with tar.extractfile(member) as source:
                (data / filename).write_bytes(source.read())
    labels = np.concatenate([np.fromfile(data / name, dtype=np.uint8).reshape(10000, 3073)[:, 0] for name in TRAIN_FILES])
    split = make_split(labels, cfg)
    save_json(ROOT / "artifacts/split.json", split)
    save_json(ROOT / "artifacts/data_manifest.json", {
        "source_url": cfg["dataset_url"], "archive_md5": digest(archive, "md5"),
        "archive_sha256": digest(archive), "archive_bytes": archive.stat().st_size,
        "extracted_files": {name: {"sha256": digest(data / name), "bytes": (data / name).stat().st_size} for name in TRAIN_FILES},
        "official_test": "Downloaded only inside the official compressed archive; no test member extracted, parsed as samples, or evaluated",
        "class_counts": {key: np.bincount(labels[split[key]], minlength=10).tolist() for key in ["train", "validation", "reserved"]},
        "split_sha256": digest(ROOT / "artifacts/split.json"),
        "prepared_at_utc": timestamp(), "preparation_wall_seconds": time.perf_counter() - start_wall,
        "preparation_process_cpu_seconds": time.process_time() - start_cpu,
        "download_timing_note": "Archive may have been downloaded before this command; preparation timing excludes such prior transfer"
    })
    print("Prepared 4000 train / 1000 search-validation / 45000 reserved; official test not extracted", flush=True)

def make_split(labels, cfg):
    rng = np.random.default_rng(cfg["split_seed"])
    split = {key: [] for key in ["train", "validation", "reserved"]}
    for label in range(10):
        indices = rng.permutation(np.flatnonzero(labels == label))
        a, b = cfg["train_per_class"], cfg["validation_per_class"]
        split["train"].extend(indices[:a].tolist())
        split["validation"].extend(indices[a:a+b].tolist())
        split["reserved"].extend(indices[a+b:].tolist())
    return split

def load_development(cfg):
    manifest = json.loads((ROOT / "artifacts/data_manifest.json").read_text())
    if digest(ROOT / "artifacts/split.json") != manifest["split_sha256"]:
        raise ValueError("Split modified after preparation")
    split = json.loads((ROOT / "artifacts/split.json").read_text())
    # Only the selected train/validation pixels are materialized as float tensors.
    # Reserved training labels were read to stratify, but their images are not trained/evaluated.
    batches = []
    for name in TRAIN_FILES:
        path = ROOT / "data" / name
        if digest(path) != manifest["extracted_files"][name]["sha256"]:
            raise ValueError("Training data hash mismatch")
        batches.append(np.memmap(path, mode="r", dtype=np.uint8, shape=(10000, 3073)))
    tensors = {}
    for key in ["train", "validation"]:
        rows = np.stack([batches[i // 10000][i % 10000] for i in split[key]])
        tensors[key] = (torch.from_numpy(rows[:, 1:].copy()).reshape(-1, 3, 32, 32).float().div_(255), torch.from_numpy(rows[:, 0].copy()).long())
    return tensors

def architecture_space(cfg):
    return [dict(zip(["depth", "width", "kernel"], values)) for values in itertools.product(*(cfg["space"][key] for key in ["depth", "width", "kernel"]))]

class TinyCNN(nn.Module):
    def __init__(self, arch):
        super().__init__()
        if set(arch) != {"depth", "width", "kernel"} or arch["depth"] not in [2, 3] or arch["width"] not in [8, 16] or arch["kernel"] not in [3, 5]:
            raise ValueError("Architecture outside trusted frozen search space")
        layers, channels = [], 3
        for layer in range(arch["depth"]):
            out = arch["width"] * (2 ** layer)
            layers.extend([nn.Conv2d(channels, out, arch["kernel"], padding=arch["kernel"] // 2), nn.ReLU(), nn.AvgPool2d(2)])
            channels = out
        layers.extend([nn.AdaptiveAvgPool2d(1), nn.Flatten(), nn.Linear(channels, 10)])
        self.layers = nn.Sequential(*layers)

    def forward(self, x):
        return self.layers(x)

def forward_macs(arch):
    channels, side, count = 3, 32, 0
    for layer in range(arch["depth"]):
        out = arch["width"] * (2 ** layer)
        count += side * side * out * channels * arch["kernel"] ** 2
        channels, side = out, side // 2
    return count + channels * 10  # conv/linear only; excludes bias, activations, pooling, backward and optimizer

@torch.no_grad()
def evaluate(model, data, batch_size):
    model.eval()
    x, y = data
    loss_sum, correct = 0.0, 0
    for i in range(0, len(y), batch_size):
        logits = model(x[i:i+batch_size])
        loss_sum += nn.functional.cross_entropy(logits, y[i:i+batch_size], reduction="sum").item()
        correct += (logits.argmax(1) == y[i:i+batch_size]).sum().item()
    return {"loss": loss_sum / len(y), "accuracy": correct / len(y), "correct": correct, "n": len(y)}

def train_child(arch, seed, tensors, cfg, checkpoint_path, initial_validation=False):
    start_wall, start_cpu = time.perf_counter(), time.process_time()
    torch.manual_seed(seed)
    model = TinyCNN(arch)
    optimizer = torch.optim.Adam(model.parameters(), lr=cfg["child_lr"], weight_decay=cfg["child_weight_decay"])
    order_rng = torch.Generator().manual_seed(seed + 10000000)
    x, y = tensors["train"]
    epochs = []
    initial = evaluate(model, tensors["validation"], cfg["batch_size"]) if initial_validation else None
    steps, presentations, train_wall, train_cpu = 0, 0, 0.0, 0.0
    for epoch in range(cfg["epochs_per_trial"]):
        t0, c0 = time.perf_counter(), time.process_time()
        order = torch.randperm(len(y), generator=order_rng)
        model.train()
        loss_sum, correct = 0.0, 0
        for i in range(0, len(y), cfg["batch_size"]):
            index = order[i:i+cfg["batch_size"]]
            optimizer.zero_grad(set_to_none=True)
            logits = model(x[index])
            loss = nn.functional.cross_entropy(logits, y[index])
            loss.backward()
            optimizer.step()
            loss_sum += loss.item() * len(index)
            correct += (logits.argmax(1) == y[index]).sum().item()
            steps += 1
            presentations += len(index)
        wall, cpu = time.perf_counter() - t0, time.process_time() - c0
        train_wall += wall
        train_cpu += cpu
        epochs.append({"epoch": epoch + 1, "online_train_loss": loss_sum / len(y), "online_train_accuracy": correct / len(y), "wall_seconds": wall, "process_cpu_seconds": cpu})
    ev_wall, ev_cpu = time.perf_counter(), time.process_time()
    validation = evaluate(model, tensors["validation"], cfg["batch_size"])
    eval_wall, eval_cpu = time.perf_counter()-ev_wall, time.process_time()-ev_cpu
    checkpoint_path.parent.mkdir(parents=True, exist_ok=True)
    torch.save({"architecture": arch, "seed": seed, "model_state_dict": model.state_dict(), "optimizer_state_dict": optimizer.state_dict(), "epochs_completed": cfg["epochs_per_trial"], "config_sha256": digest(CONFIG)}, checkpoint_path)
    result = {"architecture": arch, "training_seed": seed, "epochs": epochs, "validation": validation,
        "initial_validation": initial, "parameter_count": sum(p.numel() for p in model.parameters()),
        "optimizer_steps": steps, "train_image_presentations": presentations,
        "validation_image_presentations": validation["n"] * (2 if initial_validation else 1),
        "forward_conv_linear_macs_per_image": forward_macs(arch),
        "train_forward_conv_linear_macs": forward_macs(arch) * presentations,
        "validation_forward_conv_linear_macs": forward_macs(arch) * validation["n"] * (2 if initial_validation else 1),
        "train_wall_seconds": train_wall, "train_process_cpu_seconds": train_cpu,
        "final_validation_wall_seconds": eval_wall, "final_validation_process_cpu_seconds": eval_cpu,
        "checkpoint": str(checkpoint_path.relative_to(ROOT)), "checkpoint_sha256": digest(checkpoint_path),
        "total_wall_seconds": time.perf_counter()-start_wall, "total_process_cpu_seconds": time.process_time()-start_cpu,
        "completed_at_utc": timestamp()}
    return result

def run_search(method, seed, tensors, cfg):
    out = ROOT / f"results/{method}_{seed}.json"
    if out.exists():
        raise FileExistsError(f"Refusing to overwrite completed evidence: {out}")
    wall, cpu = time.perf_counter(), time.process_time()
    rng = np.random.default_rng(seed)
    logits = nn.Parameter(torch.zeros(3, 2))
    controller_optimizer = torch.optim.Adam([logits], lr=cfg["controller_lr"])
    baseline = cfg["controller_baseline_initial"]
    trials = []
    for index in range(cfg["trials_per_search"]):
        selector_wall, selector_cpu = time.perf_counter(), time.process_time()
        probabilities = torch.softmax(logits, dim=1) if method == "reinforce" else torch.full((3,2), 0.5)
        p = probabilities.detach().numpy()
        # Own RNG stream: child torch.manual_seed cannot change architecture draws.
        actions = [int(rng.choice(2, p=dim / dim.sum())) for dim in p]
        arch = {key: cfg["space"][key][actions[i]] for i,key in enumerate(["depth", "width", "kernel"])}
        selection_wall, selection_cpu = time.perf_counter()-selector_wall, time.process_time()-selector_cpu
        attempt_path = ROOT/f"results/{method}_{seed}_attempts.jsonl"
        attempt_wall, attempt_cpu = time.perf_counter(), time.process_time()
        attempt = {"method":method,"search_seed":seed,"trial_index":index,"architecture":arch,
            "training_seed":1000000 + seed*100 + index,"config_sha256":digest(CONFIG)}
        append_event(attempt_path, dict(attempt, status="started", at_utc=timestamp()))
        try:
            result = train_child(arch, 1000000 + seed*100 + index, tensors, cfg, ROOT/f"checkpoints/{method}_{seed}/trial_{index:02d}.pt")
        except BaseException as error:
            append_event(attempt_path, dict(attempt,status="failed",at_utc=timestamp(),error_type=type(error).__name__,error=str(error),
                consumed_wall_seconds=time.perf_counter()-attempt_wall,consumed_process_cpu_seconds=time.process_time()-attempt_cpu))
            raise
        append_event(attempt_path, dict(attempt,status="completed",at_utc=timestamp(),
            consumed_wall_seconds=time.perf_counter()-attempt_wall,consumed_process_cpu_seconds=time.process_time()-attempt_cpu))
        reward = result["validation"]["accuracy"]
        update_wall, update_cpu = time.perf_counter(), time.process_time()
        previous_baseline = baseline
        controller_loss = None
        if method == "reinforce":
            selected_log_prob = torch.log(probabilities[torch.arange(3), torch.tensor(actions)]).sum()
            entropy = -(probabilities * torch.log(probabilities)).sum()
            loss = -(reward - baseline) * selected_log_prob - cfg["controller_entropy_weight"] * entropy
            controller_optimizer.zero_grad(set_to_none=True)
            loss.backward()
            controller_optimizer.step()
            controller_loss = loss.item()
            baseline = cfg["controller_baseline_decay"]*baseline + (1-cfg["controller_baseline_decay"])*reward
        result.update({"trial_index": index, "actions": actions, "sampling_probabilities": p.tolist(),
            "controller_baseline_before": previous_baseline if method == "reinforce" else None,
            "controller_loss": controller_loss,
            "controller_logits_after": logits.detach().tolist() if method == "reinforce" else None,
            "selector_wall_seconds": selection_wall + time.perf_counter()-update_wall,
            "selector_process_cpu_seconds": selection_cpu + time.process_time()-update_cpu})
        trials.append(result)
        # Raw trial journal exists even if the process is interrupted later.
        with open(ROOT/f"results/{method}_{seed}.jsonl", "a") as journal:
            journal.write(json.dumps(result) + "\n")
        print(f"{method} seed={seed} trial={index+1}/8 arch={arch} val={reward:.3f} child_s={result['total_wall_seconds']:.1f}", flush=True)
    best = max(range(len(trials)), key=lambda i: trials[i]["validation"]["accuracy"])
    torch.save({"logits": logits.detach(), "optimizer_state_dict": controller_optimizer.state_dict(), "baseline": baseline, "method": method, "seed": seed}, ROOT/f"checkpoints/{method}_{seed}/controller.pt")
    result = {"method": method, "seed": seed, "config_sha256": digest(CONFIG), "split_sha256": digest(ROOT/"artifacts/split.json"),
        "trials": trials, "selected_trial": best, "selected_validation_accuracy": trials[best]["validation"]["accuracy"],
        "selected_architecture": trials[best]["architecture"], "unique_architectures": len({json.dumps(t["architecture"],sort_keys=True) for t in trials}),
        "total_wall_seconds": time.perf_counter()-wall, "total_process_cpu_seconds": time.process_time()-cpu,
        "completed_at_utc": timestamp(), "official_test_evaluations": 0}
    save_json(out, result)

def environment_record():
    return {"python": sys.version, "torch": torch.__version__, "numpy": np.__version__, "platform": platform.platform(),
        "torch_threads": torch.get_num_threads(), "torch_interop_threads": torch.get_num_interop_threads(),
        "deterministic_algorithms": torch.are_deterministic_algorithms_enabled(), "cuda_available": torch.cuda.is_available(),
        "executable": sys.executable, "config_sha256": digest(CONFIG), "source_sha256": digest(Path(__file__)), "recorded_at_utc": timestamp()}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=["prepare", "baseline", "search"])
    parser.add_argument("--method", choices=["reinforce", "random", "all"], default="all")
    parser.add_argument("--seed", type=int)
    args = parser.parse_args()
    cfg = json.loads(CONFIG.read_text())
    configure(cfg)
    for folder in ["artifacts", "results", "checkpoints"]:
        (ROOT / folder).mkdir(exist_ok=True)
    if args.command == "prepare":
        prepare(cfg)
        return
    env_path = ROOT / f"artifacts/environment_{args.command}_{args.method}_{args.seed}.json"
    if not env_path.exists():
        save_json(env_path, environment_record())
    tensors = load_development(cfg)
    if args.command == "baseline":
        output = ROOT / "results/baseline.json"
        if output.exists():
            raise FileExistsError("Baseline already exists")
        fixed = cfg["fixed_baseline"]
        result = train_child({k:fixed[k] for k in ["depth","width","kernel"]}, fixed["seed"], tensors, cfg, ROOT/"checkpoints/baseline.pt", initial_validation=True)
        result["config_sha256"] = digest(CONFIG)
        result["split_sha256"] = digest(ROOT / "artifacts/split.json")
        save_json(output, result)
        print(json.dumps(result), flush=True)
    else:
        if args.seed is not None and args.seed not in cfg["search_seeds"]:
            raise ValueError("Seed not preregistered")
        for seed in ([args.seed] if args.seed is not None else cfg["search_seeds"]):
            # Alternate first method across paired seeds to reduce serial-order timing bias.
            methods = (["reinforce", "random"] if cfg["search_seeds"].index(seed)%2 == 0 else ["random", "reinforce"]) if args.method == "all" else [args.method]
            for method in methods:
                if (ROOT/f"results/{method}_{seed}.json").exists():
                    print(f"Skipping completed {method}/{seed}; original evidence preserved", flush=True)
                    continue
                if (ROOT/f"results/{method}_{seed}.jsonl").exists() or (ROOT/f"results/{method}_{seed}_attempts.jsonl").exists():
                    raise RuntimeError("Partial run found. Preserve it; start a new explicitly versioned run rather than silently append")
                run_search(method, seed, tensors, cfg)
    save_json(ROOT/f"artifacts/process_exit_{args.command}_{args.method}_{args.seed}.json", {"max_rss_kib":resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,"finished_at_utc":timestamp()})

if __name__ == "__main__":
    main()
