#!/usr/bin/env python3
"""Fast, data-independent unit and fault-injection tests."""
import json
import tempfile
import unittest
from pathlib import Path
import numpy as np
import torch
import run_experiment as exp

CFG = json.loads(exp.CONFIG.read_text())
torch.set_num_threads(1)

class Tests(unittest.TestCase):
    def test_search_space_has_eight_unique_trusted_models(self):
        space = exp.architecture_space(CFG)
        self.assertEqual(len(space), 8)
        self.assertEqual(len({json.dumps(a, sort_keys=True) for a in space}), 8)
        for a in space:
            model = exp.TinyCNN(a)
            output = model(torch.ones(2,3,32,32))
            self.assertEqual(tuple(output.shape), (2,10))
            output.sum().backward()
            self.assertTrue(all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters()))

    def test_untrusted_architecture_rejected(self):
        for arch in [{"depth":20,"width":16,"kernel":3},{"depth":2,"width":16,"kernel":3,"code":"x"},{}]:
            with self.assertRaises(ValueError): exp.TinyCNN(arch)

    def test_split_disjoint_complete_balanced_and_reproducible(self):
        labels = np.repeat(np.arange(10),5000)
        split = exp.make_split(labels, CFG)
        self.assertEqual(split, exp.make_split(labels,CFG))
        self.assertEqual([len(split[k]) for k in split], [4000,1000,45000])
        self.assertEqual(len(set(sum(split.values(), []))), 50000)
        self.assertEqual(set(sum(split.values(),[])),set(range(50000)))
        for key,n in [("train",400),("validation",100),("reserved",4500)]:
            self.assertEqual(np.bincount(labels[split[key]]).tolist(),[n]*10)

    def test_train_file_whitelist_excludes_test(self):
        self.assertEqual(exp.TRAIN_FILES,[f"data_batch_{i}.bin" for i in range(1,6)])
        self.assertTrue(all("test" not in name for name in exp.TRAIN_FILES))

    def test_forward_mac_count_hand_calculation(self):
        a={"depth":2,"width":8,"kernel":3}
        self.assertEqual(exp.forward_macs(a),32*32*8*3*9+16*16*16*8*9+16*10)

    def test_policy_positive_advantage_increases_chosen_probability(self):
        logits=torch.nn.Parameter(torch.zeros(3,2))
        optimizer=torch.optim.Adam([logits],lr=CFG["controller_lr"])
        probabilities=logits.softmax(1)
        loss= -0.2*probabilities[:,0].log().sum()
        loss.backward(); optimizer.step()
        self.assertTrue(bool((logits.softmax(1)[:,0] > 0.5).all()))

    def test_selection_ties_use_earliest(self):
        values=[0.1,0.4,0.4,0.2]
        self.assertEqual(max(range(len(values)), key=lambda i:values[i]),1)

    def test_child_reproducible_on_synthetic_samples(self):
        torch.manual_seed(1)
        data=(torch.rand(16,3,32,32),torch.arange(16)%10)
        tensors={"train":data,"validation":data}
        with tempfile.TemporaryDirectory(dir=exp.ROOT/"artifacts") as temp:
            p=Path(temp)
            a=exp.train_child({"depth":2,"width":8,"kernel":3},10,tensors,CFG,p/"one.pt")
            b=exp.train_child({"depth":2,"width":8,"kernel":3},10,tensors,CFG,p/"two.pt")
            self.assertEqual(a["validation"],b["validation"])
            self.assertEqual(a["optimizer_steps"],2)
            self.assertEqual(a["train_image_presentations"],32)
            self.assertEqual(a["validation_image_presentations"],16)
            one=torch.load(p/"one.pt",weights_only=True)["model_state_dict"]
            two=torch.load(p/"two.pt",weights_only=True)["model_state_dict"]
            self.assertTrue(all(torch.equal(one[k],two[k]) for k in one))

if __name__ == "__main__":
    unittest.main(verbosity=2)
