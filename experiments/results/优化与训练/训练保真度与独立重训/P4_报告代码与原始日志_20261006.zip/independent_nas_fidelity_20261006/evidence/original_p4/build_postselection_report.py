#!/usr/bin/env python3
import json
from pathlib import Path
root=Path(__file__).resolve().parent
post=root/"postselection"
summary=json.loads((post/"summary.json").read_text())
freeze=json.loads((post/"selection_freeze.json").read_text())
lines=["# P4：冻结检查点的选优后独立开发评估", "", "## 这一轮回答什么", "",
"把已经选出的模型直接用于未参与训练/搜索验证的 5,000 张图片，检查搜索分数能否保持。所有权重、图片索引和统计规则都在首次评估前固定，没有重新训练，没有根据这批分数调整模型或再次选优。", "",
"两种搜索方法在每个种子选中的是相同权重；六个方法名/种子标签只对应三个模型，加上固定监督基线共四个模型。重复标签不增加独立模型数，也无法在这一轮产生 RL 相对随机搜索的差异。", "",
"这 5,000 张从原 CIFAR-10 训练集的 45,000 张保留池均匀无放回抽样，与 4,000 张训练图片和 1,000 张搜索验证图片完全不相交。官方 10,000 张测试集继续不读取、不评估。原保留池现剩 40,000 张未评估图片。", "",
"## 实际结果", "", "| 固定模型 | 搜索验证（n=1000） | 独立开发评估（n=5000） | Wilson 95%区间 | 搜索验证减评估（百分点） |", "|---|---:|---:|---:|---:|"]
for model in summary["models"]:
    lo,hi=model["wilson95"]
    lines.append(f"| {model['model_id']} | {100*model['search_validation_accuracy']:.2f}% | {100*model['accuracy']:.2f}% ({model['correct']}/5000) | [{100*lo:.2f}%, {100*hi:.2f}%] | {model['search_validation_minus_assessment_percentage_points']:+.2f} |")
lines += ["", "搜索验证减评估的差值只是本次观察到的分数落差，混合了选优影响、样本差异及训练随机性；不能把它全归因于选择偏差，也不能保证未来都出现同方向落差。区间只近似描述固定模型对这类图片的准确率不确定性，不代表跨训练/搜索随机种子的方法优劣。", "",
"## 同一批图片上的成对结果", "",
"以下所有模型与基线使用相同 5,000 张图片，因而用每张图片的正确/错误差值分析，不把两个准确率当成独立样本。", "",
"| 固定模型对基线 | 仅模型正确 | 仅基线正确 | 都正确 | 都错误 | 准确率差（百分点） | 配对近似95%区间（百分点） |", "|---|---:|---:|---:|---:|---:|---:|"]
for row in summary["paired_vs_baseline"]:
    lo,hi=row["paired_approximate95_percentage_points"]
    lines.append(f"| {row['model_id']} | {row['winner_only_correct']} | {row['baseline_only_correct']} | {row['both_correct']} | {row['both_wrong']} | {row['accuracy_difference_percentage_points']:+.2f} | [{lo:+.2f}, {hi:+.2f}] |")
lines += ["", "这些区间使用每图正确性差值的配对正态近似，未做多重比较校正；不作 RL 优越性或强基线优势检验。5000 张图片只是这一固定评估集的样本数，不是5000次独立架构搜索。三个选中模型也来自同一搜索验证划分，相关性不能忽略。", "",
"## 证据与成本", "",
f"- 冻结时间：{freeze['frozen_at_utc']}；评估完成：{summary['completed_at_utc']}",
f"- 四套不同权重合计 {summary['total_assessment_image_presentations']:,} 次图片前向推理；没有训练、优化器更新、额外模型选择或官方测试推理",
f"- 数据加载、推理及结果计算记录阶段的墙钟 / 进程 CPU：{summary['total_wall_seconds']:.3f} / {summary['total_process_cpu_seconds']:.3f} 秒，逐模型时间与正向 MAC 另存 summary.json；此计时不含解释器启动和此前的冻结哈希检查",
f"- 评估标签的实际类别计数（类别0至9）：{summary['class_counts']}",
"- predictions.csv 保存每张图片原索引、真标签和四个固定模型的预测；verification.json 从这些记录重算准确数、成对计数与区间，核验没有增加模型推理",
"- selection_freeze.json 保存实际 checkpoint 身份、tensor 权重哈希和方法别名映射；assessment_indices.json 保存固定样本索引；protocol.json 固定抽样和统计规则",
"- dependency_verification.json 验证评估前后导入的训练/模型代码仍与先导搜索前的源码冻结一致",
"", "先导原 summary.json 没有重写。先导搜索、基线、首次检查点审计累计99,000次验证呈现；后续独立代码核验另加49,000次；本轮评估再加20,000次，累计168,000次图片评估呈现（不是168,000张不同图片）。所有阶段正式训练仍为49个子模型、392,000次训练图片呈现。", "",
"## 复现", "", "在已完成先导结果的全新副本中，从 architecture_search 目录执行：", "",
"```sh", "PY=../sorting_generation/.venv/bin/python", "export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1", "$PY run_postselection.py freeze", "$PY run_postselection.py run", "$PY run_postselection.py verify", "$PY build_postselection_report.py", "```", "",
"freeze 和 run 都拒绝覆盖既有证据。复现时另建版本目录，保留原始结果。原 data/、环境与缓存仍不随交付分发。未来实验不能把已评估的这5000张重新称为未见保留数据。", ""]
(post/"RESULTS.md").write_text("\n".join(lines))
print("Built postselection/RESULTS.md")
