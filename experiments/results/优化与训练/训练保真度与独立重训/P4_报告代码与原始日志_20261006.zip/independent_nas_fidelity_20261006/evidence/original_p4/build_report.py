#!/usr/bin/env python3
"""Build readable results solely from actual saved metrics; never run training."""
import csv
import json
from pathlib import Path
from statistics import mean
import run_experiment as exp

root=exp.ROOT
summary=json.loads((root/"results/summary.json").read_text())
rows=list(csv.DictReader((root/"results/search_summary.csv").open()))
baseline=json.loads((root/"results/baseline.json").read_text())
audit=json.loads((root/"artifacts/verification_recompute.json").read_text())
process=json.loads((root/"artifacts/process_exit_search_all_None.json").read_text())
cost=summary["cost_accounting"]
text=["# P4：CIFAR-10 / RL 架构选择 CPU 先导结果", "", "## 结论", "",
"真实 CIFAR-10 监督训练、REINFORCE 奖励更新、随机搜索对照和检查点重评分均已完成。本轮主要证据是端到端链路可运行、成本与选择记录可审计；不能据此判定 RL 比随机搜索更好。",
"",f"固定监督基线从未训练的 {100*summary['baseline_initial_validation_accuracy']:.1f}% 提高到两轮训练后的 {100*summary['baseline_final_validation_accuracy']:.1f}% 搜索验证正确率。每轮仅使用 4,000 张训练图片，没有做独立评估或官方测试。", "",
"## 每个配对搜索种子的结果", "", "下面是各自 8 次候选训练后选出的最高开发验证分数；不是独立测试分数。三次搜索共享同一份开发划分，48 次子模型训练不等于 48 个独立比较。", "",
"| 搜索种子 | 方法 | 选中验证正确率 | 深度 / 宽度 / 核 | 选中候选序号（从0起） | 唯一架构 | 搜索墙钟 / CPU 秒 |", "|---|---|---:|---|---:|---:|---:|"]
for row in rows:
    text.append(f"| {row['seed']} | {row['method']} | {100*float(row['selected_validation_accuracy']):.1f}% | {row['depth']} / {row['width']} / {row['kernel']} | {row['selected_trial']} | {row['unique_architectures']} / 8 | {float(row['total_wall_seconds']):.3f} / {float(row['total_process_cpu_seconds']):.3f} |")
text += ["", "REINFORCE 减随机搜索的配对差值（百分点）：" + "；".join(f"seed={p['seed']}: {p['reinforce_minus_random_percentage_points']:+.2f}" for p in summary["paired_results"]) + "。", ""]
means=summary["method_descriptive_means"]
text += [f"三种子选优验证分数的描述性平均：REINFORCE {100*means['reinforce']['selected_validation_accuracy']:.2f}%，随机搜索 {100*means['random']['selected_validation_accuracy']:.2f}%。这些经过重复选优的分数存在乐观偏差，不报告显著性，也不把小差值当作方法优势。", "",
"## 实际成本", "", "两方法按相同候选次数、轮数、更新数和图片呈现量对照，计算量与时间并不相等。所有重复采样都重新训练，未使用缓存或继承权重。", "",
f"- 真实搜索子模型：{cost['search_child_trainings']}；固定监督基线：{cost['fixed_baseline_trainings']}；正式训练失败：{cost['failed_trials']}；未完成尝试：{audit['incomplete_attempts']}",
f"- 子模型优化器更新总计：{cost['total_optimizer_steps']:,} 次；训练图片呈现总计：{cost['total_train_image_presentations']:,} 次，其中搜索为 384,000，基线为 8,000",
f"- 搜索验证图片呈现：{cost['search_validation_image_presentations']:,}；基线训练前/后验证：{cost['baseline_validation_image_presentations']:,}；检查点审计额外验证：{cost['audit_validation_image_presentations']:,}；合计：{cost['total_validation_image_presentations']:,}",
f"- REINFORCE 控制器优化器更新：{cost['controller_optimizer_steps']} 次；选优后额外重训：0；官方测试图片推理：0",
f"- 固定基线子模型墙钟 / CPU：{baseline['total_wall_seconds']:.3f} / {baseline['total_process_cpu_seconds']:.3f} 秒",
f"- REINFORCE 三次搜索墙钟 / CPU：{means['reinforce']['total_search_wall_seconds']:.3f} / {means['reinforce']['total_search_process_cpu_seconds']:.3f} 秒",
f"- 随机搜索三次搜索墙钟 / CPU：{means['random']['total_search_wall_seconds']:.3f} / {means['random']['total_search_process_cpu_seconds']:.3f} 秒",
f"- 检查点审计墙钟 / CPU：{audit['audit_wall_seconds']:.3f} / {audit['audit_process_cpu_seconds']:.3f} 秒，单列而不假装免费",
f"- 搜索进程最高 RSS：{process['max_rss_kib']/1024:.1f} MiB，单线程 CPU，无 GPU", "",
f"训练正向卷积/线性 MAC：REINFORCE {means['reinforce']['train_forward_conv_linear_macs']:,}，随机搜索 {means['random']['train_forward_conv_linear_macs']:,}。这里只计卷积和线性层的正向乘累加，不含反向、优化器、池化等，不能写成总 FLOPs。逐项成本见 results/search_summary.csv。", "",
"子模型计时含构建、训练、验证和检查点保存；整次搜索还含控制器及日志。搜索进程整体启动与数据读取时间另见 artifacts/search_process_time.txt。下载、数据准备、工程单元测试不混入搜索候选预算；它们的日志/时间信息单独保存。", "",
"## 验证", "",
"- 8 项数据独立单元测试通过，另有 1 项故障注入验证 started/failed 落盘与失败成本保留；故障注入不是正式 CIFAR 训练失败",
f"- {audit['checkpoints_verified']} 个最终子模型检查点哈希、参数形状和有限性全部通过；另保留 6 个控制器状态",
"- 用不同 batch size 和独立指标代码重算全部 49 个模型的最终验证结果，正确样本数与原记录逐项完全一致，交叉熵在 1e-5 容差内一致",
"- 同一搜索种子/候选序号、相同架构的配对子模型，验证结果完全一致",
"- 验证 4,000 / 1,000 / 45,000 索引互斥且完整覆盖原 50,000 张训练图片，冻结哈希未改变",
"- 提取文件只有五个训练 batch；目录内没有官方测试样本文件，训练与审计代码均无测试加载分支",
"- 保留实验前固定配置、基线源码、搜索前源码快照、原始试验轨迹、尝试日志、逐轮指标、全部检查点和汇总生成脚本", "",
"## 解释边界与后续", "",
"只有 8 个小 CNN、每个 2 轮、3 个配对搜索种子。这是短训练的低保真选择任务，没有验证架构排序在充分训练后是否保持；控制器只有 8 次更新/种子，也没有收敛证据。固定基线不是强 CIFAR 分类基线。控制器使用三个独立分类策略，不是递归 NAS 控制器或现代 NAS 论文的完整复现。", "",
"下一阶段应另行冻结预算与独立评估划分，对预先选定结构从头更充分训练，检查低保真排序是否稳定，并增加搜索种子和公平计算量对照；正式测试集继续保留到模型与规则完全冻结。不能把本轮搜索验证分数当作最终泛化结果。", "",
"官方数据与 API 来源、算法细节和版本边界见 PROTOCOL.md；复现命令见 README.md。数据集下载文件、虚拟环境和缓存不进入交付包。", ""]
if (root/"artifacts/reviewer_cost_addendum.json").exists():
    review=json.loads((root/"artifacts/reviewer_cost_addendum.json").read_text())
    text += ["## 追加核验成本（原搜索摘要保持不变）", "",
        f"另一份独立实现重新构建模型并重算全部 49 个检查点，同时重放 48 次采样与 24 次控制器梯度更新。新增 {review['extra_validation_image_presentations']:,} 次验证图片呈现、{review['review_process_cpu_seconds']:.3f} CPU 秒及 {review['review_wall_seconds']:.3f} 墙钟秒，没有新增 CIFAR 训练。故原摘要的 99,000 次是搜索、基线和第一轮审计范围；加上此轮独立核验累计为 {review['cumulative_pilot_validation_presentations_including_review']:,} 次，不能漏计额外核验。数值见 artifacts/reviewer_cost_addendum.json。", ""]
if (root/"postselection/summary.json").exists():
    text += ["## 另行冻结的选优后评估", "", "本先导原始搜索记录与 summary.json 保持不变。随后对固定检查点开展的新 5,000 张保留图片评估，见 postselection/RESULTS.md；这一阶段不重训、不再次选优，官方测试集仍未使用。该 5,000 张现已消耗为评估集，原 45,000 张保留池剩余 40,000 张未评估。", ""]
(root/"RESULTS.md").write_text("\n".join(text))
excluded={"data",".venv","__pycache__"}
files={str(p.relative_to(root)):{"sha256":exp.digest(p),"bytes":p.stat().st_size} for p in sorted(root.rglob("*")) if p.is_file() and not any(part in excluded for part in p.relative_to(root).parts) and p.name!="manifest.json" and not p.name.endswith((".pyc",".tmp"))}
exp.save_json(root/"manifest.json",{"created_at_utc":exp.timestamp(),"scope":"P4 development pilot deliverable; dataset/env/cache excluded","file_count":len(files),"files":files})
print(f"Built RESULTS.md and manifest for {len(files)} files")
