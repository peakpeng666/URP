"""Independent statistics: raw NPZ final fitness, scalar math/statistics.

Does not import the primary analysis implementation. Also validates all raw
metadata, evaluation traces and the common-axis deduplication.
"""
import itertools, math, statistics, hashlib
import numpy as np
def recompute(rows,P,R):
    I={};raw_count=0
    for row in rows:
        path=R/row['output_file']
        assert hashlib.sha256(path.read_bytes()).hexdigest()==row['output_sha256']
        with np.load(path,allow_pickle=False) as a:
            vals=[float(x) for x in a['final_fitness']];loss=min(vals)
            assert row['final_best_loss']==loss
            assert a['eval_values'].shape==(100,20)
            assert a['final_population'].shape==(20,10)
            assert np.array_equal(a['best_vector'],a['final_population'][vals.index(loss)])
            running=float('inf')
            for g,values in enumerate(a['eval_values']):
                running=min(running,min(float(x) for x in values))
                assert float(a['curve_best_loss'][g])==running
            assert row['fe']==2000
            key=(row['family'],row['group'],row['config_id'],row['seed'])
            assert key not in I
            I[key]=math.log10(loss+1e-12);raw_count+=1
    assert raw_count==640
    ids=[x['id'] for x in P['configs']];new=[x['id'] for x in P['new_rotations']]
    groups=['axis','old_rotation']+new;out={}
    def stats(v):
        return {'n':len(v),'mean':math.fsum(v)/len(v),'median':statistics.median(v),'min':min(v),'max':max(v),'positive':sum(x>0 for x in v),'negative':sum(x<0 for x in v),'zero':sum(x==0 for x in v)}
    for fam in P['families']:
        G={};pairs=[];C={};cp=[];st=[]
        for group in groups:
            scores={c:math.fsum(I[fam,group,c,s] for s in P['search_seeds'])/4 for c in ids}
            order=sorted(ids,key=lambda c:(scores[c],c));ranks={c:order.index(c)+1 for c in ids}
            G[group]={'scores':scores,'order':order,'ranks':ranks,'exact_score_ties':16-len(set(scores.values()))}
        for group in groups[1:]:
            all_ds=[]
            for c in ids:
                v=[I[fam,group,c,s]-I[fam,'axis',c,s] for s in P['search_seeds']]
                for s,d in zip(P['search_seeds'],v):pairs.append({'group':group,'config_id':c,'seed':s,'delta':d})
                all_ds.extend(v)
                cp.append({'group':group,'config_id':c,'mean':math.fsum(v)/4,'median':statistics.median(v),'min':min(v),'max':max(v),'rank_change':G[group]['ranks'][c]-G['axis']['ranks'][c]})
            C[group]=stats(all_ds)
        comps=[]
        for a,b in itertools.combinations(groups,2):
            diff=[G[a]['ranks'][c]-G[b]['ranks'][c] for c in ids]
            inv=0
            for i,j in itertools.combinations(ids,2):
                if (G[a]['ranks'][i]-G[a]['ranks'][j])*(G[b]['ranks'][i]-G[b]['ranks'][j])<0:inv+=1
            comps.append({'a':a,'b':b,'spearman':1.-6.*sum(x*x for x in diff)/(16*(16*16-1)),'inversions':inv,'possible_pairs':120})
        pool={c:math.fsum(G[g]['scores'][c] for g in new)/3 for c in ids}
        order=sorted(ids,key=lambda c:(pool[c],c))
        for c in ids:
            ranks=[G[g]['ranks'][c] for g in new];d=[r-G['axis']['ranks'][c] for r in ranks]
            st.append({'config_id':c,'axis_rank':G['axis']['ranks'][c],'new_ranks':ranks,'new_rank_mean':math.fsum(ranks)/3,'new_rank_min':min(ranks),'new_rank_max':max(ranks),'top1_count':ranks.count(1),'rank_worse_count':sum(x>0 for x in d),'rank_better_count':sum(x<0 for x in d),'rank_equal_count':d.count(0),'pooled_new_score':pool[c],'pooled_new_rank':order.index(c)+1})
        nd=[x['delta'] for x in pairs if x['group'] in new]
        out[fam]={'groups':G,'paired':pairs,'config_pairs':cp,'paired_summary':C,'rank_comparisons':comps,'stability':st,'pooled_new_order':order,'new_paired_summary':stats(nd)}
    return out,raw_count
def compare(a,b,path='root'):
    if isinstance(a,dict):
        assert set(a)==set(b),path
        return sum(compare(a[k],b[k],path+'.'+k) for k in a)
    if isinstance(a,list):
        assert len(a)==len(b),path
        return sum(compare(x,y,path+f'[{i}]') for i,(x,y) in enumerate(zip(a,b)))
    if isinstance(a,float):assert math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-12),(path,a,b)
    else:assert a==b,(path,a,b)
    return 1
