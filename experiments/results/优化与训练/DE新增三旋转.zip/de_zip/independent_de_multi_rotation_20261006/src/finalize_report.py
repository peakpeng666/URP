"""Write the Chinese report and delivery integrity manifest; no objectives."""
import datetime,hashlib,json
from pathlib import Path
import numpy as np
R=Path(__file__).resolve().parents[1]
def read(p):return json.loads((R/p).read_text())
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
P=read('protocol.json');A=read('results/analysis.json');V=read('validation/validation.json');SV=read('validation/statistics_validation.json')
first=read('provenance/execution_attempt_01.json');recovery=read('provenance/statistics_recovery_external_receipt.json')
assert first['return_code']==1 and recovery['exit_code']==0
for fn in ['PRE_RUN_MANIFEST.json','STATISTICS_RECOVERY_MANIFEST.json']:
    for name,e in read(fn)['files'].items():assert sha(R/name)==e['sha256'],name
S=R.parent/P['source_experiment'];source=read('reused_source/MANIFEST.json')
for name,e in source['files'].items():assert sha(S/name)==e['sha256'],name
total_cpu=first['child_cpu_seconds']+recovery['cpu_seconds'];total_wall=first['elapsed_wall_seconds']+recovery['wall_seconds']
assert total_cpu<120
Q=[np.load(R/'reused_source/inputs/Q.npy')]+[np.load(R/x['authoritative_file']) for x in P['new_rotations']]
separation=[{'a':i,'b':j,'frobenius_distance':float(np.linalg.norm(Q[i]-Q[j]))} for i in range(4) for j in range(i+1,4)]
assert all(x['frobenius_distance']>1 for x in separation)
dump(R/'provenance/resource_accounting.json',{'status':'Numerical runs complete; aggregate validation failed once and recovered read-only','new_optimization_runs':384,'new_optimization_fe':768000,'new_validation_fe':32512,'new_total_fe':800512,'formal_child_exit_code':1,'statistics_recovery_exit_code':0,'formal_child_cpu_seconds':first['child_cpu_seconds'],'statistics_recovery_child_cpu_seconds':recovery['cpu_seconds'],'combined_child_cpu_seconds':total_cpu,'combined_child_wall_seconds':total_wall,'cpu_budget_seconds':120,'maximum_child_rss_kib':max(first['child_max_rss_kib'],recovery['max_rss_kib']),'new_api_calls':0,'new_paid_calls':0,'known_incremental_external_spend_usd':0,'not_measured':'Preparation/report authoring, external reviewer and internal platform/subscription allocation are outside this process meter. No cloud billing estimate invented.'})
dump(R/'validation/integrity_final.json',{'status':'passed','original_source_files_unchanged':len(source['files']),'original_pre_run_files_unchanged':len(read('PRE_RUN_MANIFEST.json')['files']),'recovery_pre_run_files_unchanged':len(read('STATISTICS_RECOVERY_MANIFEST.json')['files']),'matrix_pair_distances':separation,'independent_statistics_passed':SV['status'],'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
ell=A['ellipsoid'];rows=[]
for g in ['old_rotation','rotation_1','rotation_2','rotation_3']:
    comp=next(x for x in ell['rank_comparisons'] if x['a']=='axis' and x['b']==g);pair=ell['paired_summary'][g]
    label='旧Q（仅复用）' if g=='old_rotation' else g
    rows.append(f"| {label} | {comp['spearman']:.6f} | {comp['inversions']}/120 | {pair['mean']:+.6f} | [{pair['min']:+.6f}, {pair['max']:+.6f}] | {ell['groups'][g]['order'][0]} |")
rankrows=[]
for cfg in P['configs']:
    c=cfg['id'];ranks=[ell['groups'][g]['ranks'][c] for g in ['axis','old_rotation','rotation_1','rotation_2','rotation_3']]
    rankrows.append('| '+c+' | '+' | '.join(map(str,ranks))+' |')
maxpop=max(x['max_population_abs_difference'] for x in V['reference_replays'])
maxorth=max(x['orthogonality_max_abs'] for x in V['matrices'])
text=f'''# 三个新增固定旋转下的 DE 参数排序敏感性

## 状态与核心结论

2026-10-06 完成384条新增优化，12:59:50 UTC完成只读汇总恢复。状态为：**数值运行完成，汇总校验失败后只读恢复**。首次流程exit 1及所有失败证据保留，未重跑优化、未修改原始结果或原冻结文件。

在本次10维、条件数10⁶的盒约束Ellipsoid上，三个新增独立种子的固定旋转都再次改变了16配置的排名；轴向排名与新旋转排名的相关仅0.1412–0.2206。大方向跨这些旋转存在，精细排序并不固定。该结果只涉及当前DE/rand/1/bin、预算、目标、4种子和盒边界设置，不能宣称全算法或全问题普遍有效。

三个新Q各自64个配置×种子配对的旋转损失均高于axis。共192个新配对的平均log10差为+{ell['new_paired_summary']['mean']:.6f}，中位数+{ell['new_paired_summary']['median']:.6f}，范围[{ell['new_paired_summary']['min']:+.6f}, {ell['new_paired_summary']['max']:+.6f}]。这是配对描述统计，192个配对不是192个独立样本：复用了同4份搜索随机带和每个配置同一个axis对照。

| 旋转 | 相对axis的Spearman | 逆序配置对 | 平均配对log10差 | 配对差范围 | 本组第1名 |
|---|---:|---:|---:|---|---|
{chr(10).join(rows)}

Sphere负对照在三新Q和旧Q中均保持全部配置排名，Spearman=1、逆序0；全部新/旧配对log10差最大绝对值为{SV['all_rotations_sphere_max_absolute_paired_log10_delta']:.3e}，无实质差异。

## 稳定部分与反例

- 新Q的第1名均为F=0.6、CR=0.9；axis上该配置排第7。三个新Q的第2名均为F=0.4、CR=0.9，其axis排名为10。
- axis冠军F=0.4、CR=0.7在三个新Q分别排3、4、4。
- **反例1：旧Q的冠军并未延续。** 旧Q冠军为F=0.4、CR=0.9，三个新Q都变成第2，说明不能把单一Q上的冠军当作跨旋转最优参数。
- **反例2：排名移动方向并非所有配置都一致。** F=1.0、CR=0.1的axis排名13，而新Q排名15、5、8，在第一个旋转变差、另外两个变好；F=1.0、CR=0.7为axis第15，新Q排名13、14、16。
- **反例3：新Q之间仍有明显次序差异。** 三组新Q两两Spearman分别0.658824、0.755882、0.894118，分别有30、25、17对配置逆序。这支持大方向重复出现，而不支持全排序稳定。
- “CR=0.9的配置占据若干前列”仅是此Ellipsoid上的现象。Sphere冠军为F=0.4、CR=0.3，且Sphere整个配置排序旋转不变。不能外推高CR普遍更好。

完整Ellipsoid排名：

| 配置 | axis复用 | 旧Q复用 | 新Q1 | 新Q2 | 新Q3 |
|---|---:|---:|---:|---:|---:|
{chr(10).join(rankrows)}

## 冻结方案、复用边界与实际样本

- 原协议、实现、结果及MANIFEST共{len(source['files'])}个文件经SHA256全量核验；原目录保持不动。原样复制DE核心和独立标量实现。协议、全部程序、复用NPZ、随机带与矩阵等284文件于{P['frozen_at_utc']}冻结；首个新目标计算在12:58:02 UTC后开始。
- 16配置保持F∈{{0.4,0.6,0.8,1.0}}、CR∈{{0.1,0.3,0.7,0.9}}。目标保持Sphere和Ellipsoid；D=10，20个体，初始化20 FE+99代×20 FE=2000 FE/run；同步DE/rand/1/bin、严格改善替换、互异donors排除target、binomial交叉强制一维、[-5,5]坐标clip均不变。
- Sphere为Σxᵢ²；Ellipsoid为Σ10^(6i/9)xᵢ²；旋转版本把x换为Qx，最优点0。
- 新Q种子为202610061101、202610061102、202610061103；独立PCG64高斯矩阵QR，按R对角符号规范Q，必要时翻末列使det=+1。独立是指不同固定伪随机种子产生的矩阵流；三个新Q与旧Q逐一不相同，实际二进制矩阵为权威输入。
- 搜索种子仍为202610060701–202610060704，4份初始种群/全部操作随机带直接复制原字节。同seed跨全部配置、目标、旋转共用随机带。没有新增搜索种子、删选配置或按观察结果挑Q。
- **新增：3旋转×2目标×16配置×4种子=384优化runs，768000优化FE。** 384完成，0失败优化run、0未执行。
- **复用：128条唯一axis runs，加128条唯一旧旋转runs。** 旧优化FE合计512000仅标记历史来源，不算本批新增FE；分析读取共640条唯一runs。相同axis对照在三个配对中反复引用，不算三个axis样本；没有重跑axis。
- 每组按4 seeds的mean log10(loss+10⁻¹²)升序排名；全部组无精确分数并列。三新Q的pool仅含新Q，不混旧Q，是3旋转×4seed的描述平均，不是12个独立种子，也不是留出验证。

## 独立实现验证及首次汇总失败

1. 三Q最大正交误差{maxorth:.3e}；det均在1±10⁻¹²内；64个预冻测试点含0点、标准基和53个随机点。新旋转目标的向量/标量实现对照及Sphere轴向参照共832 FE。公式最大相对差{V['objective_tests']['max_relative_formula_error']:.3e}；Sphere点值旋转不变性最大相对误差{V['objective_tests']['max_relative_sphere_invariance_error']:.3e}；所有0点最优值通过。
2. 全部384条新run的7680个最终个体用独立标量目标重算，共7680 FE，最大相对误差{V['final_population_summary']['max_relative_error']:.3e}；逐代最优曲线由保存的全部评估值复算，最终fitness/最佳向量/边界/文件哈希均检查。
3. 预选首seed、F=0.4/CR=0.1与F=1.0/CR=0.9、两目标、三新Q，共12个完整标量DE重放，24000 FE。显式donor排除列表与标量运算不导入主DE核心；最大最终种群坐标差{maxpop:.3e}，所有最终值/曲线通过预冻容差。这些都是验证，不是新增研究样本。实现与主程序由同一执行者整理，独立审计另行进行。
4. **首次流程的统计校验失败。** 主统计用NumPy log10，第二统计用math.log10。Sphere接近相等时，最后数位舍入改变精确正/负/零计数；首次触发项为旧Q负计数15 vs 14。完整检查共发现9个此类计数字段差异，全部属于Sphere。单个log10值两种实现最大差{SV['max_np_math_log10_absolute_difference']:.3e}；浮点聚合均在预冻复算容差rtol=atol=10⁻¹²内，排名没有因此改变。精确正负号数不能作为Sphere优劣证据。
5. 冻结`STATISTICS_RECOVERY_PROTOCOL.json`及对应4文件清单后，只读现成结果，将主log10统一为原实验使用的math.log10；保留NumPy聚合与独立math.fsum/statistics.median聚合，独立Spearman用秩差公式复算。所有640条原始NPZ及**4094个叶字段**全部通过，涵盖所有排名、均值/中位数/极值/计数、配置对逆序、跨Q比较、pool及稳定性字段。恢复不调用目标函数，不重跑任何优化；原协议、冻结程序、raw、失败日志及exit1完整保留。

## 真实FE、退出码与成本

- 新优化：768000 FE。
- 验证：832测试点值+7680最终个体+24000标量重放=32512 FE。
- **本批实际总新目标点值评估：800512 FE。** 只读统计恢复和统计复算不增加FE；旧512000优化FE不计入本批。
- 唯一正式数值子进程：{first['child_cpu_seconds']:.6f} CPU秒，{first['elapsed_wall_seconds']:.6f} wall秒，exit **1**（发生于末尾聚合复算；384优化无失败）。
- 只读统计恢复子进程：{recovery['cpu_seconds']:.6f} CPU秒，{recovery['wall_seconds']:.6f} wall秒，exit **0**。
- 两子进程合计：**{total_cpu:.6f} CPU秒**，{total_wall:.6f} wall秒；最高RSS {max(first['child_max_rss_kib'],recovery['max_rss_kib'])} KiB。总CPU低于120秒；首子进程120秒硬限，恢复110秒硬限，加已消耗8.623359秒仍低于120秒总预算。没有触发超时。
- float64、Python/NumPy及系统版本见环境记录，数值计算单线程。实验没有模型API、付费API、依赖安装或远端长任务，已知额外外部支出$0。内部平台/订阅分摊费用不可观测，不能声称零基础设施成本。上述子进程计时不含准备、报告、打包和外部审计；预冻结输入及代码编译准备没有目标评估。

## 限制与下一步解释边界

本批只把一个Q扩展为三个新的固定Q，仍只有4份搜索随机带，且同axis控制跨旋转复用。没有统计显著性分析、随机旋转总体保证或独立留出集。新增研究只涉及Sphere与同一个条件数10⁶的Ellipsoid，不涉及其他函数、维度、种群规模、预算或DE变体。

搜索盒、初始化及clip保持在原坐标，而非整体旋转可行域；因此这是当前目标/交叉/边界组合的坐标敏感性，不能单独归因于交叉算子，也不能解读为纯几何旋转下算法不变性的完整检验。排名上升不代表绝对优化更好，本批Ellipsoid的全部旋转损失配对都更高。

下一步若继续，优先用不同维度/预算或另一各向异性函数做新冻结验证；不应从这份完整网格再挑赢家并把同一批结果当确认集。本批没有执行这些扩展，也未触碰原132研究。

## 文件导航

- `protocol.json`、`PRE_RUN_MANIFEST.json`：原冻结协议与284输入/源文件哈希。
- `STATISTICS_RECOVERY_PROTOCOL.json`、`STATISTICS_RECOVERY_MANIFEST.json`：明确的统计后处理补充协议及4文件冻结清单。
- `results/runs.jsonl`、`runs.csv`：384条新增run；`results/*.npz`：全部新评估值、最终个体、曲线和批点哈希。
- `reused_source/results/*.npz`：256条旧结果原字节；`results/reused_runs.json`及`provenance/source_reuse.json`：复用身份与来源哈希。
- `results/analysis.json`：全部描述统计；`config_summary.csv`、`paired_differences.csv`、`rank_comparisons.csv`、`rotation_stability.csv`：完整可检视表。
- `validation/validation.json`：首次流程保留的失败状态，内含已通过的目标/最终种群/12重放检查。最终统计状态见`validation/statistics_validation.json`；不是把原失败覆盖为成功。
- `validation/original_statistics_discrepancies.json`：9个精确计数字段差异；`validation/recomputed_statistics.json`：独立全部统计。
- `provenance/execution_attempt_01.json`、`results/first_failure.json`及stdout/stderr：首次exit1证据；`provenance/statistics_recovery_external_receipt.json`：只读恢复exit0及计时。
- `provenance/resource_accounting.json`：权威合计资源与FE；`validation/integrity_final.json`：源文件未改动/矩阵不同/全部冻结哈希核验。
- `MANIFEST.json`：最终交付完整性清单，自身及运行缓存除外。

本目录的正式启动器拒绝覆盖已有尝试。复现请复制到新的独立目录并记录新尝试，不把新运行混入本批。
'''
(R/'REPORT_ZH.md').write_text(text)
(R/'README.txt').write_text('状态：数值运行完成，汇总校验失败后只读恢复。\n先读REPORT_ZH.md；原失败记录完整保留；384条新优化、768000优化FE、32512验证FE；复用256条旧结果不计新增样本。\n无需重跑启动器。所有正式冻结文件和旧实验保持不变。\n')
files={str(p.relative_to(R)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(R.rglob('*')) if p.is_file() and p.name!='MANIFEST.json' and '__pycache__' not in p.parts}
# Include the historical manifest; exclude only this top-level manifest itself.
p=R/'reused_source/MANIFEST.json';files[str(p.relative_to(R))]={'sha256':sha(p),'bytes':p.stat().st_size}
dump(R/'MANIFEST.json',{'experiment_id':P['experiment_id'],'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'file_count':len(files),'excluded':'Top-level MANIFEST.json itself and Python __pycache__ runtime cache','files':dict(sorted(files.items()))})
print(json.dumps({'report':'REPORT_ZH.md','manifest_sha256':sha(R/'MANIFEST.json'),'file_count':len(files),'combined_child_cpu_seconds':total_cpu,'completed_new_runs':384}))
