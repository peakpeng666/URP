"""Single formal run, numerics + independent replay + two complete analyses."""
import csv,datetime,hashlib,itertools,json,math,time,traceback
from pathlib import Path
import numpy as np
import core,reference,analysis_primary,audit_statistics
R=Path(__file__).resolve().parents[1]
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def csvwrite(name,rows):
    with (R/'results'/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
P=json.loads((R/'protocol.json').read_text());M=json.loads((R/'PRE_RUN_MANIFEST.json').read_text())
for name,entry in M['files'].items():assert sha(R/name)==entry['sha256'],name
assert not (R/'results/runs.jsonl').exists(),'No second attempt permitted'
T={s:dict(np.load(R/f'inputs/random_tape_{s}.npz',allow_pickle=False)) for s in P['search_seeds']}
Q={r['id']:np.load(R/r['authoritative_file'],allow_pickle=False) for r in P['new_rotations']}
rows=[];status='running';active=None;optimization_start=None;optimization_end=None
start=time.monotonic();cpu=time.process_time()
V={'status':'running','start_utc':now(),'matrices':[],'final_populations':[],'reference_replays':[]}
progress={'status':status,'planned_new_runs':384,'completed_new_runs':0,'failed_optimization_runs':0,'new_optimization_fe':0,'reused_axis_runs':128,'reused_old_rotation_runs':128}
dump(R/'results/progress.json',progress)
try:
    points=np.load(R/'inputs/objective_test_points.npy',allow_pickle=False)
    sphere_axis=core.Objective('sphere','axis',np.eye(10))(points)
    tv={};max_obj_rel=0.;max_sphere_rel=0.
    for gid,q in Q.items():
        orth=float(np.max(np.abs(q.T@q-np.eye(10))));det=float(np.linalg.det(q))
        assert orth<=1e-12 and abs(det-1.)<=1e-12
        V['matrices'].append({'group':gid,'orthogonality_max_abs':orth,'determinant':det,'sha256':sha(R/f'inputs/{gid}.npy')})
        for fam in P['families']:
            vector=core.Objective(fam,'rotated',q)(points)
            scalar=np.array([reference.value(x,fam,'rotated',q) for x in points])
            assert np.allclose(vector,scalar,rtol=1e-12,atol=1e-12)
            assert vector[0]==scalar[0]==0.
            max_obj_rel=max(max_obj_rel,float(np.max(np.abs(vector-scalar)/np.maximum(np.abs(scalar),1e-300))))
            if fam=='sphere':
                assert np.allclose(vector,sphere_axis,rtol=1e-12,atol=1e-12)
                max_sphere_rel=max(max_sphere_rel,float(np.max(np.abs(vector-sphere_axis)/np.maximum(np.abs(sphere_axis),1e-300))))
            tv[gid+'_'+fam]=vector
    np.savez_compressed(R/'validation/objective_test_values.npz',sphere_axis=sphere_axis,**tv)
    V['objective_tests']={'fe':core.EVALUATED_POINTS+reference.EVALUATED_POINTS,'max_relative_formula_error':max_obj_rel,'max_relative_sphere_invariance_error':max_sphere_rel,'zero_optima_all_passed':True}
    assert V['objective_tests']['fe']==832
    optimization_start=core.EVALUATED_POINTS
    with (R/'results/runs.jsonl').open('w') as jl,(R/'results/curves.csv').open('w',newline='') as cf:
        cw=csv.writer(cf);cw.writerow(['run_id','generation','fe','best_loss'])
        for gid,fam,cfg,seed in itertools.product(Q,P['families'],P['configs'],P['search_seeds']):
            rid=f'{fam}_{gid}_{cfg["id"]}_s{seed}';active=rid;t=time.monotonic()
            res=core.run(T[seed],cfg,fam,'rotated',Q[gid])
            assert res['fe']==2000 and np.all(np.diff(res['curve_best_loss'])<=0.)
            p=R/f'results/{rid}.npz'
            np.savez_compressed(p,**{k:v for k,v in res.items() if isinstance(v,np.ndarray)})
            row={'run_id':rid,'family':fam,'group':gid,'orientation':'rotated','config_id':cfg['id'],'F':cfg['F'],'CR':cfg['CR'],'seed':seed,'fe':2000,'final_best_loss':res['final_best_loss'],'log10_loss_eps':math.log10(res['final_best_loss']+1e-12),'elapsed_wall_seconds':time.monotonic()-t,'output_file':str(p.relative_to(R)),'output_sha256':sha(p),'origin':'new_optimization'}
            jl.write(json.dumps(row)+'\n');jl.flush();rows.append(row)
            for g,val in enumerate(res['curve_best_loss']):cw.writerow([rid,g,20*(g+1),float(val)])
            cf.flush();active=None
            progress.update(completed_new_runs=len(rows),new_optimization_fe=core.EVALUATED_POINTS-optimization_start,last_completed_run_id=rid)
            dump(R/'results/progress.json',progress)
            if len(rows)%64==0:print(json.dumps({'at':now(),**progress}),flush=True)
    optimization_end=core.EVALUATED_POINTS
    assert len(rows)==384 and optimization_end-optimization_start==768000
    csvwrite('runs.csv',rows)
    before=reference.EVALUATED_POINTS;max_final_rel=0.;max_final_abs=0.
    for row in rows:
        with np.load(R/row['output_file'],allow_pickle=False) as a:
            ref=np.array([reference.value(x,row['family'],'rotated',Q[row['group']]) for x in a['final_population']])
            err=np.abs(ref-a['final_fitness']);rel=err/np.maximum(np.abs(ref),1e-300)
            assert np.allclose(ref,a['final_fitness'],rtol=1e-10,atol=1e-10)
            assert np.all(np.abs(a['final_population'])<=5.)
            max_final_rel=max(max_final_rel,float(np.max(rel)));max_final_abs=max(max_final_abs,float(np.max(err)))
            V['final_populations'].append({'run_id':row['run_id'],'vectors':20,'max_absolute_error':float(np.max(err)),'max_relative_error':float(np.max(rel)),'pass':True})
    V['final_population_summary']={'runs':384,'vectors':7680,'fe':reference.EVALUATED_POINTS-before,'max_relative_error':max_final_rel,'max_absolute_error':max_final_abs}
    before=reference.EVALUATED_POINTS;pre=P['reference_replay_preselected']
    for row in rows:
        if row['config_id'] not in pre['configs'] or row['seed'] not in pre['search_seeds']:continue
        cfg=next(x for x in P['configs'] if x['id']==row['config_id'])
        rr=reference.replay(T[row['seed']],cfg,row['family'],'rotated',Q[row['group']])
        with np.load(R/row['output_file'],allow_pickle=False) as a:
            assert rr['fe']==2000
            assert np.allclose(rr['final_population'],a['final_population'],rtol=1e-12,atol=1e-12)
            assert np.allclose(rr['final_fitness'],a['final_fitness'],rtol=1e-9,atol=1e-9)
            assert np.allclose(rr['curve_best_loss'],a['curve_best_loss'],rtol=1e-9,atol=1e-9)
            V['reference_replays'].append({'run_id':row['run_id'],'fe':rr['fe'],'max_population_abs_difference':float(np.max(np.abs(np.array(rr['final_population'])-a['final_population']))),'max_curve_abs_difference':float(np.max(np.abs(np.array(rr['curve_best_loss'])-a['curve_best_loss']))),'pass':True})
        rr['purpose']='Validation replay only, not a new research sample';dump(R/f'validation/reference_{row["run_id"]}.json',rr)
    assert len(V['reference_replays'])==12 and reference.EVALUATED_POINTS-before==24000
    reused=[]
    for line in (R/'reused_source/results/runs.jsonl').read_text().splitlines():
        row=json.loads(line);row['group']='axis' if row['orientation']=='axis' else 'old_rotation'
        row['origin']='reused_axis_control' if row['orientation']=='axis' else 'reused_historical_rotation'
        row['output_file']='reused_source/'+row['output_file'];reused.append(row)
    assert len(reused)==256 and sum(x['group']=='axis' for x in reused)==128
    dump(R/'results/reused_runs.json',reused)
    all_rows=reused+rows
    analysis=analysis_primary.analyze(all_rows,P)
    independent,nraw=audit_statistics.recompute(all_rows,P,R)
    checked=audit_statistics.compare(analysis,independent)
    dump(R/'validation/recomputed_statistics.json',independent)
    V['independent_statistics']={'status':'passed','raw_npz_runs':nraw,'compared_leaf_fields':checked,'objective_evaluations':0,'primary':'JSONL input with NumPy reductions and covariance Spearman','independent':'raw NPZ min final fitness with math.fsum, statistics.median, rank-difference Spearman; no primary analysis import','reuse_deduplicated':True}
    dump(R/'results/analysis.json',analysis)
    for name,key in [('paired_differences.csv','paired'),('config_summary.csv','config_pairs'),('rank_comparisons.csv','rank_comparisons'),('rotation_stability.csv','stability')]:
        csvwrite(name,[{'family':fam,**item} for fam in P['families'] for item in analysis[fam][key]])
    V['validation_fe']=core.EVALUATED_POINTS-768000+reference.EVALUATED_POINTS
    assert V['validation_fe']==32512
    V.update(status='passed',end_utc=now())
    dump(R/'validation/validation.json',V)
    summary={'status':'completed','experiment_id':P['experiment_id'],'frozen_protocol_sha256':sha(R/'protocol.json'),'new_completed_runs':384,'new_failed_optimization_runs':0,'new_unexecuted_runs':0,'new_optimization_fe':768000,'new_validation_fe':V['validation_fe'],'all_new_objective_evaluations':core.EVALUATED_POINTS+reference.EVALUATED_POINTS,'reused_unique_axis_runs':128,'reused_unique_historical_rotation_runs':128,'reused_source_optimization_fe_not_added_to_new_budget':512000,'unique_analyzed_runs':640,'independent_statistics_checked_leaf_fields':checked,'api_calls':0,'paid_calls':0,'incremental_external_monetary_spend_usd':0,'resource_billing_unknown':'Internal platform/agent subscription or infrastructure charges are unavailable and not estimated. CPU receipt excludes preparation/reporting/external reviewer.','end_utc':now(),'elapsed_wall_seconds':time.monotonic()-start,'process_cpu_seconds':time.process_time()-cpu}
    assert summary['all_new_objective_evaluations']==800512
    dump(R/'results/summary.json',summary);status='completed';print(json.dumps(summary),flush=True)
except BaseException as e:
    status='failed';traceback.print_exc()
    progress['failed_optimization_runs']=int(active is not None)
    dump(R/'results/first_failure.json',{'at':now(),'type':type(e).__name__,'error':str(e),'traceback':traceback.format_exc(),'active_run_id':active,'completed_new_runs':len(rows),'core_evaluated_points':core.EVALUATED_POINTS,'reference_evaluated_points':reference.EVALUATED_POINTS})
    V.update(status='failed',error=str(e));dump(R/'validation/validation.json',V);raise
finally:
    progress.update(status=status,completed_new_runs=len(rows),core_evaluated_points=core.EVALUATED_POINTS,reference_evaluated_points=reference.EVALUATED_POINTS,end_utc=now(),elapsed_wall_seconds=time.monotonic()-start,process_cpu_seconds=time.process_time()-cpu)
    dump(R/'results/progress.json',progress)
