"""Experiment implementation: vectorized float64 synchronous DE. No external inputs."""
import hashlib
import numpy as np

EVALUATED_POINTS=0

class Objective:
    def __init__(self,family,orientation,q):
        self.family=family;self.orientation=orientation;self.q=q;self.fe=0
        self.w=10.**(6.*np.arange(10)/9.)
    def __call__(self,points):
        global EVALUATED_POINTS
        x=np.asarray(points,dtype=np.float64)
        assert x.ndim==2 and x.shape[1]==10
        EVALUATED_POINTS+=len(x)
        z=x@self.q.T if self.orientation=='rotated' else x
        v=np.sum(z*z,axis=1) if self.family=='sphere' else np.sum(self.w*z*z,axis=1)
        assert np.all(np.isfinite(v)) and np.all(v>=0.)
        self.fe+=len(x)
        return v

def donor_indices(a,b,c):
    target=np.arange(20)
    a=a.copy();a+=a>=target
    exc=np.sort(np.column_stack([target,a]),axis=1)
    b=b.copy()
    for j in range(2):b+=b>=exc[:,j]
    exc=np.sort(np.column_stack([target,a,b]),axis=1)
    c=c.copy()
    for j in range(3):c+=c>=exc[:,j]
    donors=np.column_stack([a,b,c])
    assert np.all(donors!=target[:,None])
    assert np.all(donors[:,0]!=donors[:,1]) and np.all(donors[:,1]!=donors[:,2]) and np.all(donors[:,0]!=donors[:,2])
    return donors

def run(tape,cfg,family,orientation,q):
    obj=Objective(family,orientation,q)
    pop=tape['initial_population'].copy()
    values=[];trace=[];hashes=[]
    fitness=obj(pop);values.append(fitness.copy());trace.append(float(np.min(fitness)));hashes.append(hashlib.sha256(pop.astype('<f8').tobytes()).hexdigest())
    for g in range(99):
        donors=donor_indices(tape['donor_rank_a'][g],tape['donor_rank_b'][g],tape['donor_rank_c'][g])
        mutant=pop[donors[:,0]]+cfg['F']*(pop[donors[:,1]]-pop[donors[:,2]])
        cross=tape['crossover_uniform'][g]<cfg['CR'];cross[np.arange(20),tape['forced_coordinate'][g]]=True
        trial=np.clip(np.where(cross,mutant,pop),-5.,5.)
        assert np.all(np.isfinite(trial)) and np.all(np.abs(trial)<=5.)
        y=obj(trial);values.append(y.copy());hashes.append(hashlib.sha256(trial.astype('<f8').tobytes()).hexdigest())
        improve=y<fitness;pop[improve]=trial[improve];fitness[improve]=y[improve]
        trace.append(float(np.min(fitness)))
    k=int(np.argmin(fitness));assert obj.fe==2000
    return {'fe':obj.fe,'final_population':pop,'final_fitness':fitness,'best_vector':pop[k].copy(),'final_best_loss':float(fitness[k]),'curve_best_loss':np.asarray(trace),'eval_values':np.asarray(values),'point_batch_sha256':np.asarray(hashes,dtype='U64')}
