"""Main statistics: metadata JSONL input and NumPy calculations."""
import itertools
import numpy as np
def analyze(rows,P):
    ids=[x['id'] for x in P['configs']];new=[x['id'] for x in P['new_rotations']]
    groups=['axis','old_rotation']+new
    I={(r['family'],r['group'],r['config_id'],r['seed']):np.log10(r['final_best_loss']+1e-12) for r in rows}
    out={}
    for fam in P['families']:
        G={};pairs=[];C={};config_pairs=[];stability=[]
        for group in groups:
            scores={c:float(np.mean([I[fam,group,c,s] for s in P['search_seeds']])) for c in ids}
            order=sorted(ids,key=lambda c:(scores[c],c));ranks={c:i+1 for i,c in enumerate(order)}
            G[group]={'scores':scores,'order':order,'ranks':ranks,'exact_score_ties':len(scores)-len(set(scores.values()))}
        for group in groups[1:]:
            ds=[]
            for c in ids:
                vals=[]
                for s in P['search_seeds']:
                    d=float(I[fam,group,c,s]-I[fam,'axis',c,s]);vals.append(d);ds.append(d)
                    pairs.append({'group':group,'config_id':c,'seed':s,'delta':d})
                config_pairs.append({'group':group,'config_id':c,'mean':float(np.mean(vals)),'median':float(np.median(vals)),'min':float(np.min(vals)),'max':float(np.max(vals)),'rank_change':G[group]['ranks'][c]-G['axis']['ranks'][c]})
            C[group]={'n':len(ds),'mean':float(np.mean(ds)),'median':float(np.median(ds)),'min':float(np.min(ds)),'max':float(np.max(ds)),'positive':int(np.count_nonzero(np.array(ds)>0)),'negative':int(np.count_nonzero(np.array(ds)<0)),'zero':int(np.count_nonzero(np.array(ds)==0))}
        comps=[]
        for a,b in itertools.combinations(groups,2):
            ar=np.array([G[a]['ranks'][c] for c in ids]);br=np.array([G[b]['ranks'][c] for c in ids])
            inversions=sum((ar[i]-ar[j])*(br[i]-br[j])<0 for i in range(16) for j in range(i+1,16))
            comps.append({'a':a,'b':b,'spearman':float(np.corrcoef(ar,br)[0,1]),'inversions':int(inversions),'possible_pairs':120})
        pool={c:float(np.mean([G[g]['scores'][c] for g in new])) for c in ids}
        order=sorted(ids,key=lambda c:(pool[c],c));pr={c:i+1 for i,c in enumerate(order)}
        for c in ids:
            ranks=np.array([G[g]['ranks'][c] for g in new]);d=ranks-G['axis']['ranks'][c]
            stability.append({'config_id':c,'axis_rank':G['axis']['ranks'][c],'new_ranks':ranks.tolist(),'new_rank_mean':float(np.mean(ranks)),'new_rank_min':int(np.min(ranks)),'new_rank_max':int(np.max(ranks)),'top1_count':int(np.count_nonzero(ranks==1)),'rank_worse_count':int(np.count_nonzero(d>0)),'rank_better_count':int(np.count_nonzero(d<0)),'rank_equal_count':int(np.count_nonzero(d==0)),'pooled_new_score':pool[c],'pooled_new_rank':pr[c]})
        nd=[x['delta'] for x in pairs if x['group'] in new]
        out[fam]={'groups':G,'paired':pairs,'config_pairs':config_pairs,'paired_summary':C,'rank_comparisons':comps,'stability':stability,'pooled_new_order':order,'new_paired_summary':{'n':len(nd),'mean':float(np.mean(nd)),'median':float(np.median(nd)),'min':float(np.min(nd)),'max':float(np.max(nd)),'positive':int(np.count_nonzero(np.array(nd)>0)),'negative':int(np.count_nonzero(np.array(nd)<0)),'zero':int(np.count_nonzero(np.array(nd)==0))}}
    return out
