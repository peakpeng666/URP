"""Separate scalar implementation: no imports from core, explicit donor exclusion lists.
Replays only preselected controls; these repeats are validation, not research samples.
"""
import math
EVALUATED_POINTS=0

def value(x,family,orientation,q):
    global EVALUATED_POINTS
    EVALUATED_POINTS+=1
    if orientation=='rotated':
        z=[math.fsum(float(q[i][j])*float(x[j]) for j in range(10)) for i in range(10)]
    else:z=[float(t) for t in x]
    if family=='sphere':return math.fsum(t*t for t in z)
    return math.fsum((10**(6*i/9))*z[i]*z[i] for i in range(10))

def replay(tape,cfg,family,orientation,q):
    population=[[float(v) for v in row] for row in tape['initial_population']]
    fitness=[value(x,family,orientation,q) for x in population];nfe=20;curve=[min(fitness)]
    for generation in range(99):
        new_population=[];new_fitness=[]
        for target in range(20):
            available=[index for index in range(20) if index!=target]
            a=available.pop(int(tape['donor_rank_a'][generation,target]))
            b=available.pop(int(tape['donor_rank_b'][generation,target]))
            c=available.pop(int(tape['donor_rank_c'][generation,target]))
            assert len({target,a,b,c})==4
            force=int(tape['forced_coordinate'][generation,target])
            trial=[]
            for dimension in range(10):
                if dimension==force or float(tape['crossover_uniform'][generation,target,dimension])<cfg['CR']:
                    proposal=population[a][dimension]+cfg['F']*(population[b][dimension]-population[c][dimension])
                else:proposal=population[target][dimension]
                trial.append(min(5.,max(-5.,proposal)))
            y=value(trial,family,orientation,q);nfe+=1
            if y<fitness[target]:new_population.append(trial);new_fitness.append(y)
            else:new_population.append(population[target][:]);new_fitness.append(fitness[target])
        population=new_population;fitness=new_fitness;curve.append(min(fitness))
    return {'fe':nfe,'final_population':population,'final_fitness':fitness,'curve_best_loss':curve}
