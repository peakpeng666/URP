"""Freeze three independently seeded rotations, unchanged controls and all code."""
import datetime, hashlib, json, platform, shutil, sys
from pathlib import Path
import numpy as np
R=Path(__file__).resolve().parents[1]
S=R.parent/'independent_de_rotation_sensitivity_20261006'
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert not (R/'PRE_RUN_MANIFEST.json').exists()
old_manifest=json.loads((S/'MANIFEST.json').read_text())
for name,meta in old_manifest['files'].items():
    assert sha(S/name)==meta['sha256'] and (S/name).stat().st_size==meta['bytes'],name
copied=[]
for name in ['protocol.json','PRE_RUN_MANIFEST.json','MANIFEST.json','results/runs.jsonl','results/summary.json','provenance/execution_attempt_01.json','inputs/Q.npy']+[str(p.relative_to(S)) for p in sorted((S/'results').glob('*.npz'))]:
    dest=R/'reused_source'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(S/name,dest)
    copied.append({'source_relative':name,'destination_relative':str(dest.relative_to(R)),'sha256':sha(dest),'bytes':dest.stat().st_size})
for name in ['objective_test_points.npy']+[p.name for p in sorted((S/'inputs').glob('random_tape_*.npz'))]:
    shutil.copyfile(S/'inputs'/name,R/'inputs'/name)
    copied.append({'source_relative':'inputs/'+name,'destination_relative':'inputs/'+name,'sha256':sha(R/'inputs'/name),'bytes':(R/'inputs'/name).stat().st_size})
old=json.loads((S/'protocol.json').read_text())
rots=[{'id':f'rotation_{i+1}','seed':202610061101+i} for i in range(3)]
for rot in rots:
    q,r=np.linalg.qr(np.random.Generator(np.random.PCG64(rot['seed'])).normal(size=(10,10)))
    q=q*np.where(np.diag(r)<0,-1.,1.)[None,:]
    if np.linalg.det(q)<0:q[:,-1]*=-1
    np.save(R/f'inputs/{rot["id"]}.npy',q,allow_pickle=False)
    np.savetxt(R/f'inputs/{rot["id"]}.csv',q,delimiter=',',fmt='%.17g')
    rot['authoritative_file']=f'inputs/{rot["id"]}.npy'
P={k:old[k] for k in ['dimension','bounds','optimum','families','objective_formulas','search_seeds','rng_plan','algorithm','population','generations','fe_per_run','configs','ranking','paired_metric','rank_change_metrics','tolerances']}
P.update(experiment_id=R.name,frozen_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    question='Across three fresh pre-fixed independent Gaussian-QR rotations, does the previously observed Ellipsoid DE parameter-rank change persist, and how stable is its detailed ordering?',
    source_experiment=S.name,source_manifest_sha256=sha(S/'MANIFEST.json'),
    new_rotations=rots,rotation_generation=old['rotation_generation'].replace('Q.npy','rotation_N.npy'),
    rotated_variables='For every run evaluate f(Qx), retaining the identical unrotated population/tape, coordinate-aligned [-5,5]^10 box and clip. This is not an invariance test that rotates the whole feasible domain.',
    primary_new_runs=384,primary_new_optimization_fe=768000,
    reused_unique_axis_runs=128,reused_unique_old_rotation_runs=128,
    reuse_policy='Copy and SHA256-verify existing raw results. Never rerun axis optimization. Repeated references to one axis run are not new samples. Old rotation is historical comparison only, excluded from primary three-rotation pooled metrics.',
    preregistered_analysis={'per_group':'Across four frozen search seeds, arithmetic mean log10(loss+1e-12) and ranks for each of 16 configurations. Groups: axis, historical old_rotation, and three new rotations; exact ties flagged, config ID used only as deterministic display tie-break.',
      'per_rotation':'Paired log10(rotated)-log10(axis) for each family/config/search seed; config mean, median, minimum, maximum; whole-grid descriptive mean, median, minimum, maximum and positive/negative/zero counts. 64 pairs are not independent observations.',
      'rank_comparisons':'For all ten group pairs per family: Spearman rank correlation and inversions among 120 unordered configuration pairs. No inferential p values or confidence intervals.',
      'cross_rotation_stability':'For each family/config across only three new rotations: rank mean/min/max, top1 count, counts of rank-shift signs relative to fixed axis rank. Across new rotations: mean log10 loss and pooled rank; give a positive and negative/counterexample account rather than selecting only supportive configurations.',
      'boundaries':'Do not claim statistically significant effects, a universal DE ranking, cross-function generalization, pure crossover causality, held-out selection or paper replication.'},
    reference_replay_preselected={'configs':['F0.4_CR0.1','F1.0_CR0.9'],'search_seeds':[old['search_seeds'][0]],'families':old['families'],'new_rotations':[x['id'] for x in rots],'runs':12,'fe':24000},
    validation={'test_points':'Reuse the 64 frozen points. New rotated objectives: 3 matrices x 2 families x 64 points x 2 implementations = 768 FE; one common vectorized Sphere axis check = 64 FE. Zero optimum included in points.',
      'all_final_populations':'384 x 20 scalar objective evaluations = 7680 FE; all traces/raw values checked.',
      'scalar_replay':'12 preselected full DE runs = 24000 FE, validation only; separate scalar source imports no main core.',
      'all_statistics':'Independent raw-NPZ analysis recomputes all rankings, paired statistics, correlations, inversions, and pooled/stability fields using scalar math/statistics, comparing every field against the main JSONL/NumPy analysis.',
      'planned_validation_fe':32512,'planned_all_new_objective_evaluations':800512},
    limits={'entire_numerics_and_validation_child_cpu_seconds':120,'entire_numerics_and_validation_child_wall_seconds':600,'threads':1,'model_api_calls':0,'paid_calls':0,'dependency_installations':0},
    failure_policy='One formal optimization attempt; durable per-run writes; preserve first failure and partial raw data; no outcome-based replacement of rotation, seed, configuration or budget, and no silent rerun.',
    interpretation_limits=['Only three new pseudo-independent rotations and one historical rotation','Only four reused search seeds and shared random tapes across all groups','Only D=10 Sphere negative control and condition-number 1e6 Ellipsoid','Coordinate aligned box, initialization and clipping held fixed; cannot separate these effects from crossover','Descriptive fully evaluated 16-configuration grid, no holdout or inferential significance'])
dump(R/'protocol.json',P)
dump(R/'provenance/source_reuse.json',{'source_directory':str(S),'source_manifest_sha256':sha(S/'MANIFEST.json'),'source_manifest_verified_files':len(old_manifest['files']),'source_core_sha256':sha(S/'src/core.py'),'source_reference_sha256':sha(S/'src/reference.py'),'unchanged_core':sha(S/'src/core.py')==sha(R/'src/core.py'),'unchanged_reference':sha(S/'src/reference.py')==sha(R/'src/reference.py'),'copied_files':copied})
dump(R/'provenance/environment.json',{'python':sys.version,'numpy':np.__version__,'platform':platform.platform(),'machine':platform.machine(),'byteorder':sys.byteorder,'numerics':'float64','threads':1})
files={str(p.relative_to(R)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(R.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
dump(R/'PRE_RUN_MANIFEST.json',{'frozen_at_utc':P['frozen_at_utc'],'files':files})
print(json.dumps({'status':'frozen','files':len(files),'manifest_sha256':sha(R/'PRE_RUN_MANIFEST.json'),'protocol_sha256':sha(R/'protocol.json')}))
