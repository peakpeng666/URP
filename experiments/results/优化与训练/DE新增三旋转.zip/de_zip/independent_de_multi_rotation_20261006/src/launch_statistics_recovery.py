"""Budgeted post-processing only; retained formal failure cannot be overwritten."""
import datetime,json,os,resource,subprocess,sys,time
from pathlib import Path
R=Path(__file__).resolve().parents[1]
out=R/'provenance/statistics_recovery_external_receipt.json'
assert not out.exists()
def limit():resource.setrlimit(resource.RLIMIT_CPU,(110,110))
start=time.monotonic();r0=resource.getrusage(resource.RUSAGE_CHILDREN)
env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
s={'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cpu_limit_s':110,'wall_limit_s':300,'new_objective_evaluations':0,'new_optimization_runs':0}
out.write_text(json.dumps(s,indent=2)+'\n')
with (R/'results/statistics_recovery_stdout.log').open('w') as o,(R/'results/statistics_recovery_stderr.log').open('w') as e:
    p=subprocess.Popen([sys.executable,str(R/'src/recover_statistics.py')],cwd=R,env=env,preexec_fn=limit,stdout=o,stderr=e)
    try:code=p.wait(timeout=300)
    except subprocess.TimeoutExpired:p.kill();code=p.wait();s['wall_limit_kill']=True
r1=resource.getrusage(resource.RUSAGE_CHILDREN)
s.update(exit_code=code,status='completed' if code==0 else 'failed',end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),wall_seconds=time.monotonic()-start,cpu_seconds=r1.ru_utime-r0.ru_utime+r1.ru_stime-r0.ru_stime,max_rss_kib=r1.ru_maxrss)
out.write_text(json.dumps(s,indent=2)+'\n');print(json.dumps(s));sys.exit(code)
