"""Read-only recovery from persisted raw results. No objective or DE calls."""
import csv,datetime,hashlib,json,math,resource,time
from pathlib import Path
import analysis_primary,analysis_primary_canonical,audit_statistics
R=Path(__file__).resolve().parents[1]
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def csvwrite(name,rows):
    with (R/'results'/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def differences(a,b,path='root'):
    if isinstance(a,dict):return sum([differences(a[k],b[k],path+'.'+k) for k in a],[])
    if isinstance(a,list):return sum([differences(x,y,path+f'[{i}]') for i,(x,y) in enumerate(zip(a,b))],[])
    if isinstance(a,float) and math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-12):return []
    if a==b:return []
    return [{'field':path,'primary_numpy':a,'independent_scalar':b}]
start=time.monotonic();cpu=time.process_time()
assert not (R/'provenance/statistics_recovery_receipt.json').exists()
P=json.loads((R/'protocol.json').read_text())
for fn in ['PRE_RUN_MANIFEST.json','STATISTICS_RECOVERY_MANIFEST.json']:
    M=json.loads((R/fn).read_text())
    for name,entry in M['files'].items():assert sha(R/name)==entry['sha256'],name
progress=json.loads((R/'results/progress.json').read_text());V=json.loads((R/'validation/validation.json').read_text())
assert progress['completed_new_runs']==384 and progress['new_optimization_fe']==768000
assert progress['failed_optimization_runs']==0 and len(V['reference_replays'])==12
assert len(V['final_populations'])==384 and all(x['pass'] for x in V['final_populations']+V['reference_replays'])
assert progress['core_evaluated_points']+progress['reference_evaluated_points']==800512
new=[json.loads(x) for x in (R/'results/runs.jsonl').read_text().splitlines()]
reused=json.loads((R/'results/reused_runs.json').read_text());rows=reused+new
independent,nraw=audit_statistics.recompute(rows,P,R)
old=analysis_primary.analyze(rows,P)
mismatch=differences(old,independent)
dump(R/'validation/original_statistics_discrepancies.json',{'cause':'NumPy log10 and math.log10 produce different last bits near exact Sphere equality; exact positive/negative/zero counts are implementation-sensitive. No substantial Sphere loss difference.','differences_outside_frozen_comparison_tolerance':mismatch})
canonical=analysis_primary_canonical.analyze(rows,P)
checked=audit_statistics.compare(canonical,independent)
dump(R/'validation/recomputed_statistics.json',independent)
dump(R/'results/analysis.json',canonical)
for name,key in [('paired_differences.csv','paired'),('config_summary.csv','config_pairs'),('rank_comparisons.csv','rank_comparisons'),('rotation_stability.csv','stability')]:
    csvwrite(name,[{'family':fam,**item} for fam in P['families'] for item in canonical[fam][key]])
maxlog=max(abs(float(__import__('numpy').log10(r['final_best_loss']+1e-12))-math.log10(r['final_best_loss']+1e-12)) for r in rows)
sphere_max=max(abs(x['delta']) for x in canonical['sphere']['paired'])
dump(R/'validation/statistics_validation.json',{'status':'passed_after_explicit_read_only_recovery','raw_runs_checked':nraw,'checked_leaf_fields':checked,'new_objective_evaluations':0,'new_optimization_runs':0,'comparison_rtol':1e-12,'comparison_atol':1e-12,'max_np_math_log10_absolute_difference':maxlog,'all_rotations_sphere_max_absolute_paired_log10_delta':sphere_max,'original_mismatched_fields':mismatch,'canonical_log10':'math.log10 exactly as original experiment; NumPy aggregations checked independently with math.fsum/statistics.median/rank-difference correlation','initial_execution_status_remains_failed':True,'end_utc':now()})
receipt={'status':'completed','start_description':'One post-failure statistics-only attempt, no optimization or objective calls','exit_code':0,'end_utc':now(),'new_objective_evaluations':0,'wall_seconds':time.monotonic()-start,'process_cpu_seconds':time.process_time()-cpu,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
dump(R/'provenance/statistics_recovery_receipt.json',receipt)
main=json.loads((R/'provenance/execution_attempt_01.json').read_text())
summary={'status':'completed_after_documented_statistics_recovery','new_completed_runs':384,'new_failed_optimization_runs':0,'new_unexecuted_runs':0,'new_optimization_fe':768000,'new_validation_fe':32512,'all_new_objective_evaluations':800512,'reused_unique_axis_runs':128,'reused_unique_historical_rotation_runs':128,'reused_source_optimization_fe_not_added_to_new_budget':512000,'unique_analyzed_runs':640,'independent_statistics_checked_leaf_fields':checked,'first_formal_process_exit_code':main['return_code'],'statistics_recovery_exit_code':0,'formal_child_cpu_seconds':main['child_cpu_seconds'],'statistics_recovery_inprocess_cpu_seconds':receipt['process_cpu_seconds'],'combined_partial_meter_cpu_seconds':main['child_cpu_seconds']+receipt['process_cpu_seconds'],'api_calls':0,'paid_calls':0,'incremental_external_monetary_spend_usd':0,'resource_billing_unknown':'Internal infrastructure/subscription charges are not observable. CPU excludes file preparation/report writing/external reviewer; recovery external receipt is authoritative for interpreter startup-inclusive resource use.','end_utc':now()}
dump(R/'results/summary.json',summary)
print(json.dumps(summary))
