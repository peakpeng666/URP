"""One formal child; CPU hard limit and wall kill, durable first-attempt receipt."""
import os,subprocess,resource,time,datetime,json,sys
from pathlib import Path
R=Path(__file__).resolve().parents[1]
receipt=R/'provenance/execution_attempt_01.json'
assert not receipt.exists(),'Formal attempt already exists; never silently rerun.'
env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',PYTHONHASHSEED='0')
def limits():resource.setrlimit(resource.RLIMIT_CPU,(120,120))
def dump(x):receipt.write_text(json.dumps(x,indent=2)+'\n')
s={'attempt':1,'status':'launching','start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cpu_hard_limit_s':120,'wall_hard_limit_s':600,'command':[sys.executable,'src/run_and_validate.py'],'thread_environment':{k:env[k] for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','VECLIB_MAXIMUM_THREADS','PYTHONHASHSEED']}}
dump(s);start=time.monotonic();r0=resource.getrusage(resource.RUSAGE_CHILDREN)
with (R/'results/stdout.log').open('w') as out,(R/'results/stderr.log').open('w') as err:
    child=subprocess.Popen([sys.executable,str(R/'src/run_and_validate.py')],cwd=R,stdout=out,stderr=err,env=env,preexec_fn=limits)
    s.update(status='running',pid=child.pid);dump(s)
    try:rc=child.wait(timeout=600)
    except subprocess.TimeoutExpired:
        child.kill();rc=child.wait();s['wall_limit_kill']=True
r1=resource.getrusage(resource.RUSAGE_CHILDREN)
s.update(status='completed' if rc==0 else 'failed',return_code=rc,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_wall_seconds=time.monotonic()-start,child_user_cpu_seconds=r1.ru_utime-r0.ru_utime,child_system_cpu_seconds=r1.ru_stime-r0.ru_stime,child_cpu_seconds=(r1.ru_utime-r0.ru_utime)+(r1.ru_stime-r0.ru_stime),child_max_rss_kib=r1.ru_maxrss)
dump(s);print(json.dumps(s));sys.exit(0 if rc==0 else 1)
