"""New namespace only. No model API. Original worker and score ABI unchanged."""
import os,sys,json,hashlib,signal,time
from pathlib import Path
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parent.parent
os.umask(0o077)
def sha(b):return hashlib.sha256(b).hexdigest()
def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
def digest(x):return sha(canon(x).encode())
def read(n):return json.loads((R/n).read_text())
def put(n,x):
 with (R/n).open('x') as f:f.write(canon(x)+'\n');f.flush();os.fsync(f.fileno())
 fd=os.open(R/n if False else (R/n).parent,os.O_RDONLY|os.O_DIRECTORY);os.fsync(fd);os.close(fd)
assert len(sys.argv)==2
A=sys.argv[1]
assert os.getppid()==int(os.environ['PRECHECK_GUARD_PID'])
signal.signal(signal.SIGXCPU,signal.SIG_DFL);signal.pthread_sigmask(signal.SIG_UNBLOCK,{signal.SIGXCPU})
assert sys.stdin.read(1)=='G'
p=read('PLAN.json'); runtime=Path(p['runtime']);sys.path.insert(0,str(runtime))
if A=='prepare':
 import hmac
 import numpy as np
 wf=json.loads((runtime/'worker_freeze.json').read_text());bad=[]
 for name,h in wf['dependencies'].items():
  if sha(Path(name).read_bytes())!=h:bad.append(name)
 for name,h in wf['files'].items():
  if sha((runtime/name).read_bytes())!=h:bad.append('runtime/'+name)
 assert not bad,'dependency drift'
 assert sys.version==wf['python'] and np.__version__==wf['numpy_version']
 assert sha((runtime/'worker_freeze.json').read_bytes())==p['worker_freeze_sha256']
 put('DEPENDENCIES.json',{'status':'PASS','python':sys.version,'numpy':np.__version__,'dependencies_verified':len(wf['dependencies']),'runtime_files_verified':len(wf['files']),'worker_freeze_sha256':p['worker_freeze_sha256'],'dynamic_worker_started':False})
 master=os.urandom(32);commit=sha(b'bpp-zero-precheck-v1|'+master)
 put('DATA_CLAIM.json',{'master_commitment':commit,'plan_sha256':sha((R/'PLAN.json').read_bytes()),'once_only':True,'no_reroll':True})
 put('SEED_REPRODUCIBILITY.json',{'master_hex':master.hex(),'scientific_secret':False,'purpose':'public exploratory reproducibility after one-time commitment; not an account credential'})
 entries=[]
 for family in ['W','U']:
  seed=int.from_bytes(hmac.new(master,(sha((R/'PLAN.json').read_bytes())+'|'+family).encode(),'sha256').digest()[:16],'big')
  g=np.random.Generator(np.random.PCG64(seed))
  v=np.round(np.clip(45*g.weibull(3,size=1000),1,100)).astype(np.int64) if family=='W' else g.integers(1,101,size=1000,dtype=np.int64)
  data={'items':v.tolist(),'capacity':100};assert len(data['items'])==1000 and all(type(x)is int and 1<=x<=100 for x in data['items'])
  put('inputs/'+family+'.json',data)
  entries.append({'family':family,'n':1000,'input_sha256':digest(data),'file_sha256':sha((R/'inputs'/f'{family}.json').read_bytes())})
 assert entries[0]['input_sha256']!=entries[1]['input_sha256']
 put('INPUT_MANIFEST.json',{'entries':entries,'master_commitment':commit,'generated_before_any_scientific_evaluation':True,'no_seed_or_quality_selection':True,'prior_full_dataset_duplicate_comparison':'not performed; independent fresh entropy, no efficacy filtering'})
 put('payload_prepare.json',{'dependency_check':'PASS','input_sequences':2,'n':1000,'new_model_calls':0,'scientific_packs':0,'runtime_code_unchanged':True})
else:
 from resource_profile import profile_sha256,DIAGNOSTIC_PROFILE_ID,PRODUCTION_PROFILE_ID
 from policy import policy_sha256
 from registry import source_bytes
 methods=read('METHODS.json')['methods']
 if A.startswith('admission_'):kind='admission';mid=A[len('admission_'):];family=None;idx=0
 elif A.startswith('toy_'):kind='toy';mid='BF' if A=='toy_BF_technical_r1' else A[len('toy_'):];family=None;idx=0
 else:
  kind='scientific';x=next(x for x in p['packs'] if x['id']==A);mid=x['method'];family=x['family'];idx=x['index']
  auth=read('EXECUTION_AUTHORIZATION.json');assert auth['scientific_execution_authorized'] is True
  assert auth['seal_sha256']==sha((R/'PREPARATION_SEAL.json').read_bytes())
 m=methods[mid];candidate={k:m[k] for k in ('description','code','description_sha256','code_sha256','pair_sha256','description_consistency')};source_bytes(candidate)
 profile=DIAGNOSTIC_PROFILE_ID if kind=='toy' else PRODUCTION_PROFILE_ID
 claim=read('claims/'+A+'.json')
 binding={'batch_id':p['id'],'wave_id':p['id']+'-fixed','slot_id':mid,'raw_response_sha256':digest(m),'source_sha256':candidate['code_sha256'],'policy_sha256':policy_sha256(),'runtime_freeze_sha256':p['worker_freeze_sha256'],'claim_sha256':digest(claim),'claim_id':digest([p['id'],A]),'registry_sha256':digest(read('METHODS.json')),'resource_profile_sha256':profile_sha256(profile)}
 if kind=='admission':
  from runner import Session
  w=Session(candidate,binding,worker_role='admission',execution_id=p['id']+'/'+A)
  adm=w.admission.copy();w.close();ev=w.evidence()
  assert adm['admitted'] and ev['reaped'] and not ev['cleanup_error'] and ev['source_after_host_gate']
  payload={'kind':kind,'method':mid,'admission':adm,'worker':ev}
 else:
  from supervised_runner import supervised_pack
  from checker import check_assignment
  if kind=='toy':items=p['toy']
  else:
   data=read('inputs/'+family+'.json');e=next(x for x in read('INPUT_MANIFEST.json')['entries'] if x['family']==family)
   assert digest(data)==e['input_sha256'];items=data['items'];assert len(items)==1000
  execution_id=binding['claim_id']+'/instance/'+str(idx)
  assert execution_id==binding['claim_id']+'/instance/'+str(idx), 'original supervisor execution identity contract'
  try:
   report=supervised_pack(items,100,candidate,binding,execution_id=execution_id,instance_index=idx)
  except BaseException as exc:
   put('failure_'+A+'.json',{'exception_type':type(exc).__name__,'message':str(exc),'supervisor_evidence':getattr(exc,'supervisor_evidence',None),'worker_evidence':getattr(exc,'worker_evidence',None),'execution_id':execution_id,'claim_id':binding['claim_id'],'instance_index':idx,'missing_evidence_is_null':True,'no_retry':True})
   raise
  assert report['worker']['reaped'] and report['supervisor_evidence']['reaped']
  assert report['worker']['cleanup_error'] is None and report['supervisor_evidence']['cleanup_error'] is None
  assert report['outcome']=='ok','fixed baseline or interface failure; no retry'
  checked=check_assignment(items,100,report['result'])
  if mid=='BF':
   rem=[100]*len(items)
   for item,j in zip(items,report['result']['assignment']):
    expected=min((i for i in range(len(rem)) if rem[i]>=item),key=lambda i:(rem[i],i));assert j==expected;rem[j]-=item
  prior=read('payload_admission_'+mid+'.json')['admission']
  assert sha(report['worker']['admission']['canonical_text'].encode())==sha(prior['canonical_text'].encode())
  payload={'kind':kind,'method':mid,'family':family,'n':len(items),'input_sha256':digest({'items':items,'capacity':100}),'code_sha256':candidate['code_sha256'],'L1':(sum(items)+99)//100,'checker':checked,'original_pack_report':report,'scientific':kind=='scientific'}
 put('payload_'+A+'.json',payload)
