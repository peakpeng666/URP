"""Durable one-action guard. Science needs new exact root authorization."""
import os,sys,json,hashlib,signal,resource,time,fcntl
from pathlib import Path
sys.dont_write_bytecode=True;os.umask(0o077)
R=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(R))
from guard_collect_blocking import collect_driver
from driver_helpers import canon,digest,read,put,sha
resource.setrlimit(resource.RLIMIT_CPU,(1,200));signal.signal(signal.SIGXCPU,signal.SIG_DFL);signal.pthread_sigmask(signal.SIG_UNBLOCK,{signal.SIGXCPU})
assert len(sys.argv)==2;A=sys.argv[1]
lock=(R/'LOCK').open('a+b');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
f=read('technical-r1/SOURCE_FREEZE.json')
for name,h in f['files'].items():assert sha((R/name).read_bytes())==h,'frozen file drift'
p=read('PLAN.json');science=[]
assert A in ('toy_BF_technical_r1','toy_published_EoH'), 'technical toys only; no scientific entrypoint'
auth=read('technical-r1/AUTHORIZATION.json');assert auth['technical_toys_only'] is True
for n,h in auth['preserved_old_files'].items():assert sha((R/n).read_bytes())==h, 'old evidence must remain unchanged'
for earlier in ('prepare','admission_BF','admission_published_EoH'):
 c=read('claims/'+earlier+'.json');z=read('results/'+earlier+'.json');assert z['claim_sha256']==digest(c) and z['status']=='passed'
assert read('results/toy_BF.json')['status']=='blocked_no_retry' and read('HALT.json')['action']=='toy_BF'
if A=='toy_published_EoH':
 c=read('claims/toy_BF_technical_r1.json');z=read('results/toy_BF_technical_r1.json');assert z['claim_sha256']==digest(c) and z['status']=='passed'
assert not (R/'technical-r1/HALT.json').exists()
CPU,wall,soft=(80,100,20) if A=='prepare' else ((5,7,2) if A.startswith('admission_') else ((20,10,2) if A.startswith('toy_') else (125,93,2)))
claims=[json.loads(x.read_text()) for x in (R/'claims').glob('*.json')]
usedcpu=sum(x['CPU_reserve'] for x in claims);usedwall=sum(x['wall_reserve'] for x in claims)
# Whole future schedule including separately reserved dispatcher/analysis/review.
assert usedcpu+CPU+72<=900 and usedwall+wall+140<=700
claim={'action_id':A,'CPU_reserve':CPU,'wall_reserve':wall,'source_freeze_sha256':sha((R/'technical-r1/SOURCE_FREEZE.json').read_bytes()),'no_retry':True,'scientific':A in science}
put('claims/'+A+'.json',claim)
started=time.monotonic();signal.signal(signal.SIGALRM,signal.SIG_DFL);signal.setitimer(signal.ITIMER_REAL,wall)
env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1','OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','BLIS_NUM_THREADS':'1','PRECHECK_GUARD_PID':str(os.getpid())}
cmd=['/usr/bin/prlimit',f'--cpu={soft}:200','--as=268435456:536870912','--nofile=64:64','--core=0:0','--',sys.executable,'-B',str(R/'technical-r1/driver.py'),A]
c=collect_driver(cmd,env,CPU,started+wall,R/'logs'/f'{A}.stdout',R/'logs'/f'{A}.stderr');u=c['usage'];actual=u.ru_utime+u.ru_stime
payload=R/('payload_'+A+'.json')
status='passed' if c['returncode']==0 and payload.is_file() and actual+1<=CPU and time.monotonic()-started<=wall else 'blocked_no_retry'
put('results/'+A+'.json',{'action_id':A,'claim_sha256':digest(claim),'status':status,'payload_sha256':sha(payload.read_bytes()) if payload.exists() else None,'resources':{'driver_reaped':True,'driver_exit_code':c['returncode'],'driver_wait4_inclusive_CPU':actual,'guard_CPU_hard_cap':1,'whole_tree_CPU_conservative_upper':actual+1,'wall_at_emit':time.monotonic()-started,'guard_tail_and_unknown_covered_by_full_reservation':True,'driver_peak_RSS_kib':u.ru_maxrss,'CPU_reserved_cumulative':usedcpu+CPU,'wall_reserved_cumulative':usedwall+wall}})
if status!='passed':put('technical-r1/HALT.json',{'action':A,'status':status,'no_retry':True})
print(canon({'action':A,'status':status,'driver_CPU':actual,'driver_exit':c['returncode'],'scientific_packs_started':sum(x.get('scientific',False) for x in claims)+int(A in science)}));sys.exit(0 if status=='passed' else 1)
