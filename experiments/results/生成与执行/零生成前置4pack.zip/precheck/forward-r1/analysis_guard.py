import os,sys,json,time,signal,resource,fcntl
from pathlib import Path
R=Path(__file__).resolve().parent.parent;sys.path.insert(0,str(R));sys.dont_write_bytecode=True
from driver_helpers import read,put,sha,digest
from guard_collect_blocking import collect_driver
resource.setrlimit(resource.RLIMIT_CPU,(1,200));signal.signal(signal.SIGXCPU,signal.SIG_DFL);signal.pthread_sigmask(signal.SIG_UNBLOCK,{signal.SIGXCPU})
lock=(R/'LOCK').open('a+b');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
a=read('EXECUTION_AUTHORIZATION.json');assert a['analysis_authorized'] and a['scientific_execution_authorized']
assert a['forward_source_freeze_sha256']==sha((R/'forward-r1/SOURCE_FREEZE.json').read_bytes())
for n,h in read('forward-r1/SOURCE_FREEZE.json')['files'].items():assert sha((R/n).read_bytes())==h
for n,h in read('PREPARATION_SEAL.json')['files'].items():assert sha((R/n).read_bytes())==h
assert not (R/'forward-r1/HALT.json').exists()
for x in read('PLAN.json')['packs']:
 t=read('results/'+x['id']+'.json');assert t['status']=='passed' and t['resources']['driver_exit_code']==0
claims=[json.loads(x.read_text()) for x in (R/'claims').glob('*.json')]
assert sum(x['CPU_reserve'] for x in claims)+22+40+10<=900
assert sum(x['wall_reserve'] for x in claims)+60+60+20<=700
claim={'action_id':'forward-r1-analysis','CPU_reserve':40,'wall_reserve':60,'source_freeze_sha256':a['forward_source_freeze_sha256'],'no_retry':True}
put('claims/forward-r1-analysis.json',claim)
start=time.monotonic();signal.signal(signal.SIGALRM,signal.SIG_DFL);signal.setitimer(signal.ITIMER_REAL,60)
env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1','PRECHECK_GUARD_PID':str(os.getpid())}
cmd=['/usr/bin/prlimit','--cpu=30:200','--as=268435456:536870912','--core=0:0','--',sys.executable,'-B',str(R/'forward-r1/analyze.py')]
x=collect_driver(cmd,env,40,start+60,R/'logs/forward-r1-analysis.stdout',R/'logs/forward-r1-analysis.stderr');cpu=x['usage'].ru_utime+x['usage'].ru_stime
ok=x['returncode']==0 and (R/'forward-r1/ANALYSIS.json').is_file() and cpu+1<=40 and time.monotonic()-start<=60
put('results/forward-r1-analysis.json',{'status':'passed' if ok else 'blocked_no_retry','claim_sha256':digest(claim),'resources':{'driver_reaped':True,'driver_exit_code':x['returncode'],'driver_wait4_inclusive_CPU':cpu,'guard_CPU_hard_cap':1,'wall_at_emit':time.monotonic()-start},'analysis_sha256':sha((R/'forward-r1/ANALYSIS.json').read_bytes()) if ok else None})
if not ok:put('forward-r1/HALT.json',{'action':'analysis','no_retry':True})
print(json.dumps({'analysis_status':'passed' if ok else 'blocked','driver_CPU':cpu}));sys.exit(0 if ok else 1)
