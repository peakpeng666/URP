from pathlib import Path
import json,hashlib,zipfile,resource,time
R=Path(__file__).resolve().parent.parent;F=R/'forward-r1';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rd=lambda p:json.loads(p.read_text())
analysis=rd(F/'ANALYSIS.json');prep=rd(R/'PREPARATION_SEAL.json')
assert all(sha(R/n)==h for n,h in prep['files'].items())
frozen=rd(F/'SOURCE_FREEZE.json');assert all(sha(R/n)==h for n,h in frozen['files'].items())
claims=[rd(p) for p in (R/'claims').glob('*.json')];terms=[rd(p) for p in (R/'results').glob('*.json')]
assert sum(x.get('scientific',False) for x in claims)==4 and len(claims)==11
assert sum(x['CPU_reserve'] for x in claims)==690 and sum(x['wall_reserve'] for x in claims)==576
science=[]
for x in rd(R/'PLAN.json')['packs']:
 a=x['id'];t=rd(R/'results'/f'{a}.json');p=rd(R/f'payload_{a}.json');rep=p['original_pack_report'];assert t['status']=='passed'
 science.append({'action':a,'driver_exit':t['resources']['driver_exit_code'],'driver_wait4_inclusive_CPU':t['resources']['driver_wait4_inclusive_CPU'],'guard_wall_at_emit':t['resources']['wall_at_emit'],'worker_exit':rep['worker']['returncode'],'supervisor_exit':rep['supervisor_evidence']['returncode'],'worker_reaped':rep['worker']['reaped'],'supervisor_reaped':rep['supervisor_evidence']['reaped'],'execution_id':rep['execution_id'],'index':rep['instance_index'],'checker':p['checker']['checker_status']})
sciCPU=sum(x['driver_wait4_inclusive_CPU'] for x in science);allCPU=sum(x['resources']['driver_wait4_inclusive_CPU'] for x in terms);allwall=sum(x['resources']['wall_at_emit'] for x in terms)
closed={'status':'FOUR_FIXED_PACKS_AND_INTEGER_ANALYSIS_COMPLETED_PENDING_INDEPENDENT_READONLY_REVIEW','four_scientific_slots_consumed_once':True,'analysis_consumed_once':True,'new_model_API_calls':0,'main76_or8_generation_authorized':False,'old_preparation_seal_unchanged':sha(R/'PREPARATION_SEAL.json'),'forward_seal_sha256':sha(F/'SEAL.json'),'old_error_claim_HALT_and_unknown_preserved':True,'scientific':science,'costs':{'all_action_claims_CPU_reservation':690,'all_action_claims_wall_reservation':576,'forward_preparation_dispatch_reservation':{'CPU':22,'wall':60},'consumed_plus_control_reservation':{'CPU':712,'wall':636},'pending_independent_review_reservation':{'CPU':10,'wall':20},'full_schedule_reservation':{'CPU':722,'wall':656},'caps':{'CPU':900,'wall':700},'unallocated':{'CPU':178,'wall':44},'four_scientific_driver_tree_CPU':sciCPU,'all_eleven_reaped_driver_tree_CPU':allCPU,'eleven_guard_wall_to_emit_sum':allwall,'guard_complete_CPU_upper_total':11,'archive_CPU':'separately measured in PACKAGING_WAIT4.json after this archive is closed','exact_global_all_in_CPU':None,'scope':'inclusive driver trees counted once, never add child/supervisor CPU again; full reservation retained for original failure; unmetered source/file/control-plane overhead not invented as0; guard tail separately bounded'},'independent_review_pending':True,'no_automatic_resume':'all four whitelisted scientific IDs have permanent claims; oldHALT retained; no further scientific or model work authorized'}
(F/'CLOSEOUT.json').write_text(json.dumps(closed,ensure_ascii=False,indent=2)+'\n')
text=f'''零生成在线装箱前置检查 1000项

4个固定评价与独立整数复算完成，等待只读独审。未调用模型或API，未启动8生成主案。

Weibull流：总重量39911，下界ceil(39911/100)=400。BF417箱，F=400/417；published410箱，F=40/41，published少7箱。
Uniform流：总重量51377，下界ceil(51377/100)=514。BF537箱，F=514/537；published547箱，F=514/547，published多10箱。
BF距下界分别17、23箱。下界差并不证明可以实现同样改进。

四次都使用同一冻结score合同、原受限worker和production profile。W index0、U index1均满足原ABI。原始分配、剩余容量、源/输入hash、worker/supervisor退出与清理回执齐全；独立整数重算验证装箱可行性、守恒、箱数、精确F和BF选择规则。每个科学worker/supervisor都exit0并已收割，未出现新unknown。

这两条流出现基准排序变化，支持继续提出训练分布问题，但只是接口和描述性余地检查。每族仅1条，不作显著性/族效能确认，不是5000项尺度复现；未换种子、改父代或按排名筛数据。主案是否启动仍由root另行决定。

保留的技术失败：首次BF小玩具因新包装器execution_id不符合原合同而EOF；原claim、HALT和未知监督器结局仍在，未改成成功。明确授权的technical-r1修订后，BF新技术槽及published原未claim槽各一次8项玩具通过。修订未改变任何旧C1/P2文件、固定源或W/U数据。

资源：4科学driver完整树CPU合计{sciCPU:.6f}秒；含准备、两准入、旧失败、两成功玩具、科学4和分析的11条已收割driver树合计{allCPU:.6f}秒。11条guard到emit的wall合计{allwall:.6f}秒；各guard尾部有单独硬界，不与后代CPU重复加总。文件准备/控制面未完整计量，不能把上述数称为精确全包成本。
完整预约722CPU/656活动wall（900/700上限），含旧失败不退款。已claim690/576，前向准备与调度22/60另列，待独审10/20；未分配178/44。封包CPU另附真实wait4回执，不增加预约。
'''
(F/'简短中文报告.txt').write_text(text)
# Include only task evidence and exact non-secret runtime source/metadata allowlist.
runtime=Path(rd(R/'PLAN.json')['runtime']);wf=rd(runtime/'worker_freeze.json')
files=[(p,'precheck/'+str(p.relative_to(R))) for p in sorted(R.rglob('*')) if p.is_file() and p.name!='LOCK' and '__pycache__' not in p.parts and p.suffix!='.zip']
for n in list(wf['files'])+['worker_freeze.json','pre_run_freeze.json']:files.append((runtime/n,'unchanged_runtime/'+n))
design=Path('/workspace/shared/bpp_training_distribution_pilot_design_20261008')
for p in sorted(design.rglob('*')):
 if p.is_file():files.append((p,'pilot_design/'+str(p.relative_to(design))))
manifest={name:{'sha256':sha(p),'bytes':p.stat().st_size} for p,name in files}
archive=F/'零生成4pack完整证据_20261008.zip'
assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for p,name in files:z.write(p,name)
 z.writestr('MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 m=json.loads(z.read('MANIFEST.json'))
 assert all(hashlib.sha256(z.read(name)).hexdigest()==v['sha256'] for name,v in m.items())
receipt={'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'payload_files':len(manifest),'CRC_and_all_member_hashes':'PASS','evidence_sealed':True,'scientific_execution_in_packaging':False}
(F/'ARCHIVE_RECEIPT.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(receipt,ensure_ascii=False))
