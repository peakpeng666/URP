"""Independent integer replay and exact rational description, no policy execution."""
from pathlib import Path
import json,hashlib,sys,os,signal
from fractions import Fraction
R=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(R))
from driver_helpers import read,put,sha,digest
assert os.getppid()==int(os.environ['PRECHECK_GUARD_PID']) and sys.stdin.read(1)=='G'
signal.signal(signal.SIGXCPU,signal.SIG_DFL);signal.pthread_sigmask(signal.SIG_UNBLOCK,{signal.SIGXCPU})
rows=[]
for x in read('PLAN.json')['packs']:
 aid=x['id'];t=read('results/'+aid+'.json');c=read('claims/'+aid+'.json');assert t['status']=='passed' and t['claim_sha256']==digest(c)
 raw=(R/('payload_'+aid+'.json')).read_bytes();assert sha(raw)==t['payload_sha256'];p=json.loads(raw)
 d=read('inputs/'+x['family']+'.json');items=d['items'];assert len(items)==1000 and p['input_sha256']==digest(d)
 assert p['code_sha256']==read('METHODS.json')['methods'][x['method']]['code_sha256']
 rep=p['original_pack_report'];assign=rep['result']['assignment'];assert len(assign)==1000
 rem=[100]*1000
 for item,j in zip(items,assign):
  assert type(item)is int and 1<=item<=100 and type(j)is int and 0<=j<1000 and rem[j]>=item
  if x['method']=='BF':assert j==min((i for i,b in enumerate(rem) if b>=item),key=lambda i:(rem[i],i))
  rem[j]-=item
 assert rem==rep['result']['remaining'] and sum(items)==sum(100-z for z in rem)
 used=sum(z!=100 for z in rem);lower=(sum(items)+99)//100
 assert used==rep['result']['used_bins']==p['checker']['used_bins'] and lower==p['L1'] and used>=lower
 assert rep['execution_id']==rep['binding']['claim_id']+'/instance/'+str(x['index'])
 for role in ['worker','supervisor_evidence']:
  e=rep[role];assert e['reaped'] and e['returncode']==0 and e['cleanup_error'] is None
 q=Fraction(lower,used)
 rows.append({'action_id':aid,'family':x['family'],'method':x['method'],'n':1000,'capacity':100,'total_weight':sum(items),'L1':lower,'used_bins':used,'bins_above_L1':used-lower,'F':str(q),'F_float_display':float(q),'integer_replay_pass':True,'input_sha256':digest(d),'source_sha256':p['code_sha256']})
comparisons=[]
for family in ['W','U']:
 b=next(z for z in rows if z['family']==family and z['method']=='BF');h=next(z for z in rows if z['family']==family and z['method']=='published_EoH')
 comparisons.append({'family':family,'published_minus_BF_F':str(Fraction(h['F'])-Fraction(b['F'])),'published_minus_BF_bins':h['used_bins']-b['used_bins'],'BF_L1_headroom_bins':b['bins_above_L1'],'interpretation':'single exploratory sequence, not family efficacy estimate; L1 is only a lower bound'})
out={'status':'FOUR_PACKS_INTEGER_REPLAY_PASS','rows':rows,'by_family':comparisons,'model_calls':0,'scientific_packs':4,'independent_sequence_count':2,'n':1000,'scope':'interface validation and descriptive headroom only; not confirmation, not5000 scale replication','no_p_values':True,'no_distribution_selection_or_reroll':True,'lower_bound_caveat':'positive bins-minus-L1 does not prove attainable improvement; lack of room on2 streams does not reject entire research question','analysis_code_sha256':sha(Path(__file__).read_bytes())}
put('forward-r1/ANALYSIS.json',out)
