"""Bounded serial technical controller. One durable claim per fixture, no retries."""
import os,sys,json,hashlib,subprocess,signal,resource,time,ctypes
from pathlib import Path
sys.dont_write_bytecode=True;os.umask(0o077)
R=Path(__file__).resolve().parent
signal.signal(signal.SIGXCPU,signal.SIG_DFL);signal.pthread_sigmask(signal.SIG_UNBLOCK,{signal.SIGXCPU})
def sha(b):return hashlib.sha256(b).hexdigest()
def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
def put(name,data):
 with (R/name).open('x') as f:f.write(canon(data)+'\n');f.flush();os.fsync(f.fileno())
 fd=os.open((R/name).parent,os.O_RDONLY|os.O_DIRECTORY);os.fsync(fd);os.close(fd)
plan=json.loads((R/'PLAN.json').read_text());freeze=json.loads((R/'FREEZE.json').read_text());auth=json.loads((R/'EXECUTION_AUTHORIZATION.json').read_text())
assert auth['authorized'] and auth['freeze_sha256']==sha((R/'FREEZE.json').read_bytes())
for rel,h in freeze['files'].items():assert sha((R/rel).read_bytes())==h,rel
for p,h in freeze['runtime_files'].items():assert sha(Path(p).read_bytes())==h,p
assert resource.getrlimit(resource.RLIMIT_CPU)==(4,4)
assert resource.getrlimit(resource.RLIMIT_AS)==(134217728,536870912)
assert not list((R/'claims').iterdir()),'No replay of claimed stage'
libc=ctypes.CDLL(None,use_errno=True);assert libc.prctl(36,1,0,0,0)==0
started=time.monotonic();deadline=started+180;controller_pid=os.getpid();tot_cpu=0.0;results=[]
put('START.json',{'started_utc':time.time(),'monotonic':started,'pid':controller_pid,'cpu_hard':4,'memory_as_soft_hard':[134217728,536870912],'fixed_max_live_processes':3,'aggregate_memory_hard_cap':None,'profile_memory_per_worker':536870912,'wall_seconds':180})
def pdeath():
 if libc.prctl(1,signal.SIGKILL,0,0,0)!=0 or os.getppid()!=controller_pid:os._exit(76)
for A in plan['actions']:
 if time.monotonic()+plan['wall_per_action'][A]>deadline:put('HALT.json',{'before_action':A,'reason':'global_wall_reservation'});break
 if A!='DUMMY':
  d=json.loads((R/'results'/'DUMMY.json').read_text());assert d['status']=='completed' and d['expectation_match']
 claim={'id':A,'attempt':1,'freeze_sha256':auth['freeze_sha256'],'CPU_reserved':plan['CPU_per_action'][A],'wall_reserved':plan['wall_per_action'][A],'no_retry':True}
 put('claims/'+A+'.json',claim)
 env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1','OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','BLIS_NUM_THREADS':'1','CONTRACT_CONTROLLER_PID':str(controller_pid)}
 cmd=['/usr/bin/prlimit','--cpu=1:2','--as=134217728:536870912','--nofile=64:64','--core=0:0','--fsize=1048576:1048576','--',sys.executable,'-I','-B',str(R/'driver.py'),A]
 out=(R/'logs'/f'{A}.stdout').open('xb');err=(R/'logs'/f'{A}.stderr').open('xb')
 t=time.monotonic();child=subprocess.Popen(cmd,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,close_fds=True,start_new_session=True,preexec_fn=pdeath)
 limit=min(t+plan['wall_per_action'][A]-2,deadline-2);timedout=False;status=None;usage=None
 while True:
  pid,status,usage=os.wait4(child.pid,os.WNOHANG)
  if pid:break
  if time.monotonic()>=limit:
   timedout=True
   try:os.killpg(child.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   pid,status,usage=os.wait4(child.pid,0);break
  time.sleep(.01)
 child.returncode=os.waitstatus_to_exitcode(status);out.close();err.close()
 adopted=[]
 # Worker PDEATHSIG and subreaper make abnormal cleanup observable.
 until=time.monotonic()+2
 while True:
  try:pid,st,u=os.wait4(-1,os.WNOHANG)
  except ChildProcessError:break
  if pid:
   adopted.append({'pid':pid,'returncode':os.waitstatus_to_exitcode(st),'CPU':u.ru_utime+u.ru_stime});continue
  own=Path(f'/proc/{controller_pid}/task/{controller_pid}/children').read_text().split()
  for s in own:
   try:os.kill(int(s),signal.SIGKILL)
   except ProcessLookupError:pass
  if time.monotonic()>=until:raise RuntimeError('unreaped descendants')
  time.sleep(.01)
 cpu=usage.ru_utime+usage.ru_stime+sum(x['CPU'] for x in adopted);tot_cpu+=cpu
 payload=R/f'payload_{A}.json';p=json.loads(payload.read_text()) if payload.exists() else {}
 good=not timedout and child.returncode==0 and p.get('status')=='completed' and not adopted
 row={'id':A,'status':'completed' if good else 'infrastructure_unknown','expectation_match':bool(p.get('expectation_match')) if good else False,'payload_sha256':sha(payload.read_bytes()) if payload.exists() else None,'driver_reaped':True,'driver_exit':child.returncode,'timed_out':timedout,'inclusive_driver_CPU':cpu,'driver_peak_RSS_kib':usage.ru_maxrss,'wall_seconds':time.monotonic()-t,'adopted_reaped':adopted}
 put('results/'+A+'.json',row);results.append(row);print(canon(row),flush=True)
 if not good or (A=='DUMMY' and not p['expectation_match']):put('HALT.json',{'action':A,'reason':'infrastructure_or_dummy_failure','no_retry':True});break
put('RUN_COMPLETE.json',{'status':'complete' if len(results)==len(plan['actions']) else 'halted','actions_completed':len(results),'planned_actions':len(plan['actions']),'inclusive_driver_CPU':tot_cpu,'controller_CPU':resource.getrusage(resource.RUSAGE_SELF).ru_utime+resource.getrusage(resource.RUSAGE_SELF).ru_stime,'elapsed_active_wall':time.monotonic()-started,'all_expectations_match':all(x['expectation_match'] for x in results),'toy_count':0,'model_calls':0,'host_candidate_AST_parses':0,'results':results})
