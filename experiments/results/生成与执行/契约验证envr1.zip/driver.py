"""One frozen handwritten fixture; candidate source is processed only by Session child."""
import sys,os,json,hashlib,signal,math,resource,time
from pathlib import Path
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parent
sys.path.insert(0,str(R))
signal.signal(signal.SIGXCPU,signal.SIG_DFL)
signal.pthread_sigmask(signal.SIG_UNBLOCK,{signal.SIGXCPU})
assert len(sys.argv)==2
A=sys.argv[1]
def sha(b):return hashlib.sha256(b).hexdigest()
def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
def dig(x):return sha(canon(x).encode())
def put(name,data):
 with (R/name).open('x') as f:f.write(canon(data)+'\n');f.flush();os.fsync(f.fileno())
plan=json.loads((R/'PLAN.json').read_text())
assert A in plan['actions']
row=next((x for x in json.loads((R/'CASES.json').read_text())['cases'] if x['id']==A),None)
receipt={'id':A,'driver_pid':os.getpid(),'driver_parent_pid':os.getppid(),'driver_rlimits':{'cpu':resource.getrlimit(resource.RLIMIT_CPU),'as':resource.getrlimit(resource.RLIMIT_AS),'nofile':resource.getrlimit(resource.RLIMIT_NOFILE)},'single_attempt':True,'toy_count':0}
assert receipt['driver_rlimits']['cpu']==(1,2)
assert receipt['driver_rlimits']['as']==(134217728,536870912)
assert receipt['driver_rlimits']['nofile']==(64,64)
assert os.getppid()==int(os.environ['CONTRACT_CONTROLLER_PID'])
if A=='FORMAT':
 from extract_source import extract_source,FormatFailure
 results=[]
 for case in json.loads((R/'CASES.json').read_text())['format_cases']:
  raw=Path(case['raw_path']).read_bytes();assert sha(raw)==case['raw_sha256']
  observed={}
  try:
   code=extract_source(raw);observed={'status':'passed','source_sha256':sha(code.encode()),'bytes':len(code.encode())}
   passed=case['expected_extraction'].startswith('passed') and sha(code.encode())==case['expected_source_sha256']
  except FormatFailure as exc:
   observed={'status':'format_failure','reason':str(exc)}
   passed=case['expected_extraction'].startswith('format_failure')
   if case['id']=='F06':passed=passed and len(raw)==16385 and 'oversized' in str(exc)
  results.append({'id':case['id'],'raw_sha256':sha(raw),'expected':case['expected_extraction'],'observed':observed,'expectation_match':passed,'attempts':1})
 receipt.update(status='completed',results=results,expectation_match=all(x['expectation_match'] for x in results))
 put('payload_FORMAT.json',receipt);raise SystemExit(0)
sys.path.insert(0,plan['runtime'])
from resource_profile import profile_sha256,DIAGNOSTIC_PROFILE_ID
from policy import policy_sha256
from runner import Session,NumericalFailure
if A=='DUMMY':code='# No source is transmitted in this startup-only dummy.\n'
else:
 raw=Path(row['source_path']).read_bytes();assert sha(raw)==row['source_sha256'];code=raw.decode('utf-8')
description='Handwritten contract technical fixture '+A
candidate={'code':code,'code_sha256':sha(code.encode()),'description':description,'description_sha256':sha(description.encode()),'pair_sha256':dig({'description':description,'code':code})}
claim=json.loads((R/'claims'/f'{A}.json').read_text())
binding={'batch_id':plan['id'],'wave_id':plan['id'],'slot_id':A,'raw_response_sha256':candidate['code_sha256'],'source_sha256':candidate['code_sha256'],'policy_sha256':policy_sha256(),'runtime_freeze_sha256':plan['worker_freeze_sha256'],'claim_sha256':dig(claim),'claim_id':dig([plan['id'],A]),'registry_sha256':sha((R/'CASES.json').read_bytes()),'resource_profile_sha256':profile_sha256(DIAGNOSTIC_PROFILE_ID)}
w=None
try:
 w=Session(candidate,binding,worker_role='instance',execution_id=binding['claim_id']+'/technical',instance_index=0,defer_source=(A=='DUMMY'))
 if A=='DUMMY':
  w.close();ev=w.evidence()
  assert not ev['source_sent'] and ev['admission'] is None and ev['steps']==0
  assert ev['reaped'] and ev['returncode']==0 and ev['cleanup_error'] is None
  assert ev['host_observed_limits']['cpu_seconds']==[1,1] and ev['host_observed_limits']['address_space_bytes']==[536870912,536870912]
  receipt.update(status='completed',expectation_match=True,source_transmitted=False,worker=ev)
 else:
  observed={'admission':'passed' if w.admission['admitted'] else w.admission['kind']+'_rejection','numeric':'not_run_ineligible','scores':None,'first_max_index':None}
  if w.admission['admitted']:
   try:
    values,argmax,events=w.scores(row['input_data']['item'],row['input_data']['bins'])
    observed.update(numeric='passed',scores=values,first_max_index=argmax,arithmetic_events=events)
   except NumericalFailure:
    observed.update(numeric='numeric_failure',exception_category=w.last_numerical_failure['exception_kind'],arithmetic_events=w.last_numerical_failure['arithmetic_events'])
  w.close();ev=w.evidence()
  assert ev['reaped'] and ev['returncode']==0 and ev['cleanup_error'] is None
  expected=row['expected'];match=observed['admission']==expected['bounded_admission']
  if expected['bounded_admission']=='passed':
   e=expected['numeric_outcome'];match=match and observed['numeric']==e['status']
   if e['status']=='passed':
    match=match and observed['first_max_index']==e['first_max_index']
    if 'scores' in e:match=match and observed['scores']==e['scores']
    if e.get('dtype')=='float64':
     match=match and all(type(v) is float for v in observed['scores']);observed['dtype_check']='validated final numeric dtype plus all returned score elements are Python float (float64 route)'
    if A=='C20':
     match=match and all(abs(v-target)<=1e-12 for v,target in zip(observed['scores'],[0.0,math.log(20),math.log(60)])) and observed['arithmetic_events']['instance']['divide']>=1
   elif 'exception_category' in e:match=match and observed.get('exception_category')==e['exception_category']
  receipt.update(status='completed',expectation_match=bool(match),expected=expected,observed=observed,worker=ev,source_sha256=row['source_sha256'])
 put('payload_'+A+'.json',receipt)
except BaseException as exc:
 ev=getattr(exc,'worker_evidence',None)
 if w is not None:
  try:w.close(kill=True)
  except BaseException:pass
  ev=w.evidence()
 receipt.update(status='infrastructure_unknown',expectation_match=False,error_type=type(exc).__name__,error=str(exc)[:1024],worker=ev)
 put('payload_'+A+'.json',receipt)
 raise
