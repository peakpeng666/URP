def score(item, bins):
    return np.where(bins == item, 1.0, 0.0)
