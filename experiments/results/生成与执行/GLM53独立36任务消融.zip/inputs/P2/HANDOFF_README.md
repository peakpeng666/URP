# Original 132 phase2: portable DISABLED producer preflight bundle

This is a prepared input/data/code handoff, not permission to make model calls.
All 60 scientific inputs were produced by the exact frozen scheduler after independent final P1 acceptance. Preserve every byte. Do not rerun the builder, choose parents, edit prompts/configuration, run candidates, or start generation.

Extract once into a NEW consumer-local directory, preserving the workspace-relative paths. Do not overwrite the prior P1 workspace, index, archive, or journals. Check the externally supplied ZIP SHA, then HANDOFF_MANIFEST.json, all 456 source/input pins, and all 177 frozen package file pins. PACKAGE_MANIFEST.json is the authoritative newly bound package; audit/actual-tool evidence is only under handoff_evidence/ outside that package.

The complete original exporter/src, receiver and durable adapter source dependencies are included under their original relative paths. The archive intentionally does not ship a new native CLI, credentials, native runtime libraries, or a model provider. Reuse only the original verified OpenCode 1.18.34 binary SHA9ca0b9953d49997601655e54f846a3efa464f237e47c6f1b04716d0f2e64c4c2 and the exact original config/source pins. Do not replace it with Codex CLI, install another provider, or request new credentials.

The frozen history files preserve original dot-cloud absolute evidence references. They are immutable provenance, not paths to rewrite for the consumer. Producer static verification and the once-only bridge use the packaged relative files and the later parent gate. Numeric evaluation remains a separate dot-cloud task and is not authorized in this producer environment.

The original numeric runtime dependency manifest may name absolute host paths. These are not included native binaries and are not a claim that this consumer can execute numeric work. No numeric work is allowed here. Do not run preparation-era tests that assume an unbound package against the real bound directory.

Current state: BOUND_DISABLED_NOT_ACTIVATED. inputs/EXECUTION_SWITCH.json is false; NUMERICAL_SWITCH.json is false. No storage IDs or producer workspace/journal activation is granted. Wait for a separate parent generation gate matching the exact plan/freeze/roster/request list and an independently reviewed generation-accounting wrapper. The new accounting work is not included or silently activated by this handoff.

Fixed scope when separately authorized later: orders73..132, EOH30/IID30, original operators/order/parent draws, GLM-5.3 Coding Plan high/.7/.9/32000/900s/steps2/tools=false, zero outer retries and zero replacement slots. Full original ledgers remain132 generation and780 potential score rows. P1 index version120/archive60 and all four original stable storage IDs stay untouched.
