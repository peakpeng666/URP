"""Parent evidence and disabled builder tests with explicitly synthetic documents."""
import copy,hashlib,json,pathlib,shutil,sys,tempfile,unittest
from unittest.mock import patch
HERE=pathlib.Path(__file__).resolve().parent;ROOT=HERE.parent
sys.path.insert(0,str(HERE))
import phase2_binding as b
import bind_final_p1 as builder
import phase2_scheduler as scheduler
# This imports only trusted test helpers and fake receipts, never real P1 state.
from test_phase2_integration import initial_runner,module,P1


def fixture_evidence(root):
    runner=initial_runner();ledger=runner.export();slots=[s for s in ledger['generation'] if s['phase']==1]
    packet={'schema':'phase1-scheduler-packet-v1','mode':'production_verified_receipts','plan_sha256':'9'*64,
        'rows':[{'slot_id':s['id'],'pack':{'order':s['order']}} for s in slots],
        'observations':[{'slot_id':s['id']} for s in slots]}
    report=b.seal({'schema':'phase1-numerical-report-v1','status':'phase1_complete','halt_reason':None,
        'generation_denominator':60,'authenticated_generation_terminals':60,'plan_sha256':'9'*64,
        'scheduler_ledger_sha256':ledger['sha256'],'snapshots':ledger['snapshots']})
    index=b.seal({'schema':'eoh-cli-index-ledger-v2','run_id':'urp132_20261005_b01_phase1','freeze_sha256':b.P1_FREEZE,
        'rows':[{'state':'terminal','phase':1,'claim':{'slot_id':s['id']}} for s in slots]})
    index_raw=b.canon(index)
    identity={'library_file_id':'libfile_SYNTHETIC_FINAL_INDEX','file_id':'file_SYNTHETIC_FINAL_INDEX','version':61,'sha256':b.sha(index_raw)}
    def put(name,value):
        p=root/(name+'.json');p.write_bytes(b.canon(value));return {'path':str(p),'file_sha256':b.sha(p.read_bytes())}
    refs={k:put(k,v) for k,v in [('report',report),('packet',packet),('ledger',ledger)]}
    audit={'schema':'phase1-independent-terminal-audit-v1','status':'passed','phase':1,
        'report_file_sha256':refs['report']['file_sha256'],'report_sha256':report['sha256'],'ledger_sha256':ledger['sha256'],
        'plan_sha256':'9'*64,'unknown_claims':0,'all_reaped_cleanly':True,'frozen_state_unchanged':True,
        'generation_denominator':60,'controls':0,'heldout':0,'parent_rescores':0,'design_packs':300,
        'authenticated_index_identity':identity,'TEST_ONLY':True}
    refs['audit']=put('audit',audit)
    reviewer={'schema':'phase1-terminal-parent-review-v1','accepted':True,'scientific_run_id':b.SCIENTIFIC,
        'evidence_file_sha256':{k:refs[k]['file_sha256'] for k in ('report','packet','ledger','audit')},'TEST_ONLY':True}
    refs['reviewer']=put('reviewer',reviewer)
    r={'api_tool_source':'files/read','results':[{'library_file_id':identity['library_file_id'],'file_id':identity['file_id'],
        'version_id':'61','has_more':False,'file_provider':'native','content':[index_raw.decode()]}]}
    proof={'schema':'authenticated-library-readback-v1','evidence_kind':'actual_authenticated_tool_results',
           'read_before':r,'read_after':copy.deepcopy(r),'TEST_ONLY_NO_AUTHENTICATION':True}
    fence={'schema':'producer-fence-status-v1','external_write_pending':False,'unresolved_dispatch_fences':0,
        'observation_kind':'actual_producer_status_tool_stdout','run_id':'urp132_20261005_b01_phase1','freeze_sha256':b.P1_FREEZE,
        'library_file_id':identity['library_file_id'],'file_id':identity['file_id'],'current_version_number':identity['version'],
        'index_blob_sha256':identity['sha256'],'TEST_ONLY_NO_PRODUCER':True}
    refs['generation_readback']=put('generation_readback',proof);refs['producer_fence']=put('producer_fence',fence)
    boundary={'schema':'phase2-parent-boundary-v1','status':'FINAL_P1_INDEPENDENTLY_ACCEPTED','scientific_run_id':b.SCIENTIFIC,
        'phase1_freeze_sha256':b.P1_FREEZE,'phase1_lineage_sha256':b.P1_LINEAGE,'evidence':refs,'TEST_ONLY':True}
    return runner,boundary,put


class BindingTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='phase2-binding-test-',dir=HERE);self.root=pathlib.Path(self.tmp.name)
        self.runner,self.boundary,self.put=fixture_evidence(self.root)
    def tearDown(self):self.tmp.cleanup()
    def test_01_bound_synthetic_evidence_shapes(self):
        ev=b.validate_final_p1(self.boundary);self.assertEqual(ev['ledger']['reserved']['logical_requests'],72)
    def test_02_unpinned_tamper_rejected(self):
        p=pathlib.Path(self.boundary['evidence']['packet']['path']);p.write_bytes(p.read_bytes()+b' ')
        with self.assertRaisesRegex(ValueError,'pin mismatch'):b.validate_final_p1(self.boundary)
    def test_03_old_fence_same_run_is_rejected(self):
        bad=copy.deepcopy(self.boundary);fence=b.reference(bad['evidence']['producer_fence']);fence['current_version_number']=42
        bad['evidence']['producer_fence']=self.put('old_fence',fence)
        with self.assertRaisesRegex(ValueError,'audited final head'):b.validate_final_p1(bad)
    def test_04_partial_readback_or_different_head_rejected(self):
        bad=copy.deepcopy(self.boundary);proof=b.reference(bad['evidence']['generation_readback'])
        proof['read_after']['results'][0]['version_id']='60';bad['evidence']['generation_readback']=self.put('old_proof',proof)
        with self.assertRaisesRegex(ValueError,'identity changed'):b.validate_final_p1(bad)
        proof=b.reference(self.boundary['evidence']['generation_readback']);proof['read_before']['results'][0]['has_more']=True
        bad['evidence']['generation_readback']=self.put('partial_proof',proof)
        with self.assertRaisesRegex(ValueError,'incomplete'):b.validate_final_p1(bad)
    def test_05_unknown_historical_balance_never_reset(self):
        proposal=json.loads((HERE/'RESOURCE_ACCOUNTING_PROPOSAL.json').read_bytes())
        with self.assertRaisesRegex(ValueError,'separate reviewed'):b.validate_accounting(proposal)
        proposal.update(status='APPROVED_FORWARD_ACCOUNTING_ONLY',parent_review_accepted=True,historical_original_preparation_and_orchestration_balance=120)
        with self.assertRaisesRegex(ValueError,'invent/reset'):b.validate_accounting(proposal)
    def test_06_full_builder_disabled_outputs_no_calls(self):
        package=self.root/'package';package.mkdir()
        for name in ('BINDINGS.json','phase2_meter.py','phase2_producer_bridge.py','phase2_scheduler.py','phase2_binding.py','phase2_numerical.py'):
            shutil.copyfile(HERE/name,package/name)
        boundary_ref=self.put('parent_boundary',self.boundary)
        accounting=json.loads((HERE/'RESOURCE_ACCOUNTING_PROPOSAL.json').read_bytes())
        accounting.update(status='APPROVED_FORWARD_ACCOUNTING_ONLY',parent_review_accepted=True,independent_review_file_sha256='7'*64,
            phase2_meter_file_sha256=b.sha((package/'phase2_meter.py').read_bytes()),prior_phase1_accounting_receipt_file_sha256='8'*64,
            prior_numeric_reservations_audit_file_sha256=self.boundary['evidence']['audit']['file_sha256'])
        accounting['input_binding_and_generation_bookkeeping_accounting']={'status':'PARENT_APPROVED_FORWARD_OR_VERIFIED_BALANCE','allowance_or_verified_balance_file_sha256':'6'*64}
        accounting_ref=self.put('accounting',accounting)
        pc=module('phase2_builder_producer_capture',P1/'exporter/src/capture_v2.py')
        with patch.object(builder,'HERE',package),patch.object(scheduler,'replay_phase1',side_effect=lambda *_:copy.deepcopy(self.runner)),\
             patch.dict(sys.modules,{'capture_v2':pc}),patch('ast.parse',side_effect=AssertionError('candidate AST')),\
             patch('subprocess.Popen',side_effect=AssertionError('process')),patch('socket.socket',side_effect=AssertionError('network')):
            result=builder.build(boundary_ref['path'],boundary_ref['file_sha256'],accounting_ref['path'],accounting_ref['file_sha256'])
            with self.assertRaisesRegex(ValueError,'existing package'):
                builder.build(boundary_ref['path'],boundary_ref['file_sha256'],accounting_ref['path'],accounting_ref['file_sha256'])
        self.assertEqual(result['requests_prepared'],60);self.assertEqual(result['model_calls'],0)
        bound,ev=b.load_bound_package(package)
        self.assertFalse(bound['execution_enabled'])
        roster=b.read(package/'inputs/roster.json');self.assertEqual([r['order'] for r in roster['records']],list(range(73,133)))
        switch=b.read(package/'inputs/EXECUTION_SWITCH.json');self.assertFalse(switch['enabled']);self.assertFalse(switch['parent_review_accepted'])
        self.assertEqual(len(switch['authorized_request_sha256']),60);self.assertIsNone(switch['producer_workspace'])
        self.assertEqual((package/'inputs/config.raw.json').read_bytes(),(P1/'inputs/config.raw.json').read_bytes())
        import phase2_producer_bridge as bridge
        with patch.object(bridge,'HERE',package):
            bridge.verify_local_package();bridge.check_phase2_scope(b.read(package/'PLAN.json'),roster)
            with self.assertRaisesRegex(ValueError,'disabled'):bridge.check_gate(switch,b.read(package/'PLAN.json'),roster)

if __name__=='__main__':unittest.main(verbosity=2)
