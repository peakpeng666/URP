"""Trusted temporary phase2 bridge fixtures, never production evidence.

Only the immutable generation order and accepted protocol V2 are read. Every
plan, parent, request, receipt, manifest and journal is synthetic. The production
package verifier is patched explicitly; real package/plan/roster do not exist.
No model, external API, candidate parser/executor or real state is invoked.
"""
from collections import Counter
import copy
import importlib.util
import json
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import Mock, patch

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path.insert(0,str(HERE))
import phase2_producer_bridge as b

PREP=ROOT/'original132_phase1_preparation_20261005'
spec=importlib.util.spec_from_file_location('phase2_fixture_protocol_v2',PREP/'exporter/src/protocol_v2.py')
p=importlib.util.module_from_spec(spec)
spec.loader.exec_module(p)
SLOTS=ROOT/'URP/experiments/online_bin_packing/eoh_evolution_runner_v1/generation_slots.json'
SLOTS_SHA256='5135dc44aa21e8bd5964ab82d7fc8a9080f3f26e2f0bff125857bcfcc985fd9a'
BASELINE_SHA256='95cb4bb4324350d77b51df4e85f80ab1b61a2a1e28342bfe3f9d51f5e6871be8'
BINDINGS=('parent_boundary_sha256','parent_review_acceptance_sha256','resource_accounting_binding_sha256')


def reseal(value):
    return b.seal({k:v for k,v in value.items() if k!='sha256'})


class Phase2BridgeTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='TEST_ONLY-phase2-bridge-')
        self.addCleanup(self.tmp.cleanup)
        self.workspace=Path(self.tmp.name).resolve()
        self.root=self.workspace/'phase2-bridge-journal'
        # Explicit trusted fixture, not a synthetic "production" package.
        self.manifest=b.seal({'TEST_ONLY':True,'files':{
            'phase2_producer_bridge.py':b.sha(b'TEST_ONLY bridge'),
            'PLAN.json':b.sha(b'TEST_ONLY plan'),
            'inputs/roster.json':b.sha(b'TEST_ONLY roster')}})
        self.package_patch=patch.object(b,'verify_local_package',return_value=self.manifest)
        self.package_patch.start();self.addCleanup(self.package_patch.stop)
        for owner,name in ((socket,'socket'),(subprocess,'Popen'),(subprocess,'run')):
            guard=patch.object(owner,name,side_effect=AssertionError('external/candidate execution forbidden'))
            guard.start();self.addCleanup(guard.stop)
        self.config=b'{"TEST_ONLY":true,"not_model_configuration":true}'
        self.run='TEST_ONLY_original132_phase2_bridge'
        self.freeze=b.seal({'TEST_ONLY':True,'run_id':self.run,'config_file_sha256':b.sha(self.config)})
        slots_bytes=SLOTS.read_bytes()
        self.assertEqual(b.sha(slots_bytes),SLOTS_SHA256)
        self.slots=[r for r in json.loads(slots_bytes)['records'] if r['phase']==2]
        self.packs={};self.claims={};records=[]
        for position,slot in enumerate(self.slots,1):
            sid=slot['id']
            parent_count=0 if slot['arm']=='IID_TC' else 5 if slot['operator'] in ('e1','e2') else 1
            parents=['TEST_ONLY_opaque_P1_parent']*parent_count
            parent_snapshot=b.sha(b'TEST_ONLY_P1_snapshot') if parents else None
            prompt='TEST_ONLY OPAQUE non-source fixture '+sid
            pack=b.seal({'TEST_ONLY':True,'schema':'wave-prompt-pack-v1','run_id':self.run,
                'slot_id':sid,'phase':2,'arm':slot['arm'],'operator':slot['operator'],'order':slot['order'],
                'parents':parents,'parent_snapshot_sha256':parent_snapshot,'prompt':prompt,
                'freeze_sha256':self.freeze['sha256'],'prompt_sha256':b.sha(prompt.encode())})
            claim=b.seal({'TEST_ONLY':True,'schema':'wave-external-claim-v1','run_id':self.run,
                'slot_id':sid,'phase':2,'claim_id':b.sha(b.canon(['TEST_ONLY',self.run,sid])),
                'request_sha256':pack['sha256'],'freeze_sha256':self.freeze['sha256']})
            records.append({'position':position,'order':slot['order'],'slot_id':sid,'run_id':self.run,
                'arm':slot['arm'],'phase':2,'operator':slot['operator'],'parents':parents,
                'parent_snapshot_sha256':parent_snapshot,'claim_id':claim['claim_id'],
                'claim_sha256':claim['sha256'],'request_sha256':pack['sha256'],
                'freeze_sha256':self.freeze['sha256'],'config_file_sha256':b.sha(self.config),
                'prompt_sha256':b.sha(prompt.encode()),'actual_cli_payload_bytes':len(prompt.encode())})
            self.packs[sid]=pack;self.claims[sid]=claim
        self.roster=b.seal({'TEST_ONLY':True,'schema':'original132-phase2-fixed-roster-v1',
            'run_id':self.run,'scientific_run_id':'TEST_ONLY_scientific_run','phase':2,'count':60,
            'freeze_sha256':self.freeze['sha256'],'records':records})
        predecessor={'TEST_ONLY':True,'library_file_id':'libfile_TEST_ONLY_P1_INDEX',
            'file_id':'file_TEST_ONLY_P1_INDEX','current_version_number':1,
            'index_blob_sha256':b.sha(b'TEST_ONLY_final_P1_index')}
        self.plan=b.seal({'TEST_ONLY':True,'schema':'original132-phase2-continuation-plan-v1',
            'run_id':self.run,'scientific_run_id':'TEST_ONLY_scientific_run',
            'freeze_sha256':self.freeze['sha256'],'roster_sha256':self.roster['sha256'],
            'predecessor':predecessor,'forbidden_storage_ids':sorted(b.HISTORICAL_STORAGE_IDS),
            **{key:b.sha(('TEST_ONLY '+key).encode()) for key in BINDINGS}})
        self.storage={'index_library_file_id':'libfile_TEST_ONLY_PHASE2_INDEX',
            'archive_library_file_id':'libfile_TEST_ONLY_PHASE2_ARCHIVE'}
        self.gate={'TEST_ONLY':True,'enabled':True,'parent_review_accepted':True,
            'package_manifest_sha256':self.manifest['sha256'],'plan_sha256':self.plan['sha256'],
            'roster_sha256':self.roster['sha256'],'freeze_sha256':self.freeze['sha256'],
            'authorized_phase':2,'original_head_current_confirmed':True,
            'original_index_blob_sha256':predecessor['index_blob_sha256'],
            'authorized_request_sha256':[r['request_sha256'] for r in records],
            'authorized_slot_order':[r['slot_id'] for r in records],
            'producer_workspace':str(self.workspace),'bridge_journal_root':str(self.root),
            'storage':self.storage,**{key:self.plan[key] for key in BINDINGS}}
        self.index=p.initial_index(self.run,self.freeze['sha256'],['EOH_TC','IID_TC'],'official_cli',predecessor)
        self.version=1

    def head(self):
        receipt={'TEST_ONLY':True,'write_result_confirmed':True,'index_readback_confirmed':True,
            'library_file_id':self.storage['index_library_file_id'],'file_id':'file_TEST_ONLY_PHASE2_INDEX',
            'current_version_number':self.version,'local_blob_sha256':b.sha(b.canon(self.index))}
        status={'TEST_ONLY':True,'schema':'producer-fence-status-v1',
            'observation_kind':'actual_producer_status_tool_stdout','external_write_pending':False,
            'unresolved_dispatch_fences':0,'library_file_id':receipt['library_file_id'],
            'file_id':receipt['file_id'],'current_version_number':self.version,
            'index_blob_sha256':receipt['local_blob_sha256'],'run_id':self.run,
            'freeze_sha256':self.freeze['sha256'],'commit_receipt':receipt}
        return receipt,status

    def reserve(self):
        receipt,status=self.head()
        return b.reserve_next(self.root,self.plan,self.roster,self.index,receipt,self.storage,p,status,self.gate)

    def inspect(self):
        receipt,status=self.head()
        return b.inspect_head(self.plan,self.roster,self.index,receipt,self.storage,p,status)

    def advance(self,terminal_status='TEST_ONLY_authenticated_timeout'):
        reservation=self.reserve();rec=reservation['record'];claim=self.claims[rec['slot_id']]
        b.verify_reserved(self.root,reservation,self.plan,self.packs[rec['slot_id']],claim,self.freeze,self.config)
        self.index,inv=p.claim_index(self.index,claim,rec['arm'],rec['config_file_sha256']);self.version+=1
        archive={'TEST_ONLY':True,'write_result_confirmed':True,'remote_bytes_verified':False,
            'library_file_id':self.storage['archive_library_file_id'],'file_id':'file_TEST_ONLY_ARCHIVE',
            'current_version_number':rec['position']+1}
        ref={'archive_file_id':archive['file_id'],'archive_version':archive['current_version_number'],
            'actual_session_id':None,'status':terminal_status}
        self.index=p.terminal_index(self.index,claim['claim_id'],ref,archive);self.version+=1
        receipt,status=self.head()
        terminal=b.finish_position(self.root,reservation,self.plan,self.roster,self.index,receipt,self.storage,p,status)
        self.assertEqual(terminal['schema'],'original132-phase2-terminal-ack-v1')
        return reservation,terminal,inv

    def rebind_roster(self,roster):
        self.roster=reseal(roster)
        self.plan=reseal(dict(self.plan,roster_sha256=self.roster['sha256']))
        self.gate.update(plan_sha256=self.plan['sha256'],roster_sha256=self.roster['sha256'],
            authorized_request_sha256=[r['request_sha256'] for r in self.roster['records']],
            authorized_slot_order=[r['slot_id'] for r in self.roster['records']])

    def test_baseline_unchanged(self):
        self.assertEqual(b.sha((PREP/'producer_bridge.py').read_bytes()),BASELINE_SHA256)

    def test_exact_original_order_and_all_sixty_terminals_stop(self):
        expected=[r['id'] for r in self.slots]
        reserved=[]
        for position in range(1,61):
            reservation,_,_=self.advance()
            self.assertEqual(reservation['schema'],'original132-phase2-generation-reservation-v1')
            self.assertEqual(reservation['record']['position'],position)
            self.assertEqual(reservation['record']['order'],position+72)
            self.assertEqual(reservation['record']['phase'],2)
            self.assertEqual((reservation['logical_requests'],reservation['configured_completion_tokens'],
                reservation['generation_window_seconds']),(1,32000,900))
            reserved.append(reservation['record']['slot_id'])
        self.assertEqual(reserved,expected)
        self.assertEqual(Counter(r['arm'] for r in self.roster['records']),{'EOH_TC':30,'IID_TC':30})
        self.assertEqual(Counter(r['operator'] for r in self.roster['records'] if r['arm']=='EOH_TC'),
                         {'e1':6,'e2':6,'m1':6,'m2':6,'m3':6})
        before={x.name:x.read_bytes() for x in self.root.iterdir()}
        self.assertIsNone(self.reserve());self.assertIsNone(self.reserve())
        self.assertEqual(before,{x.name:x.read_bytes() for x in self.root.iterdir()})
        self.assertEqual(len(list(self.root.glob('*.reserved.json'))),60)
        receipt,status=self.head()
        snapshot=b.status_snapshot(self.plan,self.roster,self.index,receipt,self.storage,p,status)
        self.assertEqual(snapshot['schema'],'original132-phase2-generation-status-v1')
        self.assertEqual(snapshot['generation_scope_phase'],2)
        self.assertEqual(snapshot['phase2_claimed_requests'],60)
        self.assertEqual(snapshot['phase2_terminal_requests'],60)
        self.assertTrue(snapshot['phase2_generation_complete'])
        self.assertEqual(snapshot['assigned_denominator'],60)
        self.assertEqual(snapshot['planned_total_original'],132)
        self.assertEqual(snapshot['configured_completion_reserved'],1920000)
        self.assertEqual(snapshot['generation_window_reserved'],54000)
        self.assertFalse(snapshot['numerical_activated']);self.assertFalse(snapshot['holdout_activated'])

    def test_disabled_gate_cannot_reserve(self):
        self.gate['enabled']=False
        with self.assertRaisesRegex(ValueError,'disabled'):self.reserve()
        self.assertFalse(self.root.exists())

    def test_review_boolean_is_insufficient_without_all_final_bindings(self):
        for key in BINDINGS:
            for missing in (None,'','not_a_hash','G'*64):
                with self.subTest(key=key,missing=missing):
                    plan=reseal(dict(self.plan,**{key:missing}))
                    gate=dict(self.gate,plan_sha256=plan['sha256'],**{key:missing})
                    with self.assertRaisesRegex(ValueError,'final reviewed binding'):
                        b.check_gate(gate,plan,self.roster)
        self.assertFalse(self.root.exists())

    def test_reviewer_boundary_and_resources_must_match_plan(self):
        for key in BINDINGS:
            with self.subTest(key=key):
                gate=dict(self.gate,**{key:b.sha(b'TEST_ONLY_changed_binding')})
                with self.assertRaisesRegex(ValueError,'final reviewed binding'):
                    b.check_gate(gate,self.plan,self.roster)

    def test_parent_review_required_even_with_bindings(self):
        self.gate['parent_review_accepted']=False
        with self.assertRaisesRegex(ValueError,'unreviewed'):self.reserve()

    def test_phase1_or_holdout_activation_rejected(self):
        for phase in (0,1,3):
            with self.subTest(phase=phase):
                self.gate['authorized_phase']=phase
                with self.assertRaisesRegex(ValueError,'freeze/phase'):self.reserve()
        self.assertFalse(self.root.exists())

    def test_phase1_roster_schema_rejected(self):
        self.rebind_roster(dict(self.roster,schema='original132-phase1-fixed-roster-v1'))
        with self.assertRaisesRegex(ValueError,'phase2 plan and roster'):self.reserve()

    def test_resealed_phase1_record_rejected(self):
        altered=copy.deepcopy(self.roster);altered['records'][0]['phase']=1
        self.rebind_roster(altered)
        with self.assertRaisesRegex(ValueError,'exact phase2 positions'):self.reserve()

    def test_resealed_orders13_to72_rejected(self):
        altered=copy.deepcopy(self.roster)
        for record in altered['records']:record['order']-=60
        self.rebind_roster(altered)
        with self.assertRaisesRegex(ValueError,'exact phase2 positions'):self.reserve()

    def test_resealed_reordered_or_incomplete_roster_rejected(self):
        for kind in ('swap','partial','position'):
            with self.subTest(kind=kind):
                altered=copy.deepcopy(self.roster)
                if kind=='swap':altered['records'][0],altered['records'][1]=altered['records'][1],altered['records'][0]
                elif kind=='partial':altered['records'].pop()
                else:altered['records'][0]['position']=2
                saved=(self.roster,self.plan,copy.deepcopy(self.gate))
                self.rebind_roster(altered)
                with self.assertRaisesRegex(ValueError,'exact phase2 positions'):self.reserve()
                self.roster,self.plan,self.gate=saved

    def test_roster_unsealed_tamper_rejected(self):
        self.roster['records'][0]['parents']=['TEST_ONLY_TAMPER']
        with self.assertRaisesRegex(ValueError,'seal mismatch'):self.reserve()

    def test_exact_request_and_slot_order_pin_required(self):
        for key in ('authorized_request_sha256','authorized_slot_order'):
            with self.subTest(key=key):
                gate=copy.deepcopy(self.gate);gate[key][0],gate[key][1]=gate[key][1],gate[key][0]
                with self.assertRaisesRegex(ValueError,'exact scope'):
                    b.check_gate(gate,self.plan,self.roster)

    def test_phase0_and_phase1_storage_overwrite_rejected(self):
        for historical in b.HISTORICAL_STORAGE_IDS:
            for field in self.storage:
                with self.subTest(historical=historical,field=field):
                    storage=dict(self.storage,**{field:historical})
                    gate=dict(self.gate,storage=storage)
                    with self.assertRaisesRegex(ValueError,'storage collision'):
                        b.check_gate(gate,self.plan,self.roster)
                    receipt,status=self.head()
                    with self.assertRaisesRegex(ValueError,'fresh linked namespace'):
                        b.inspect_head(self.plan,self.roster,self.index,receipt,storage,p,status)
        self.assertFalse(self.root.exists())

    def test_plan_cannot_omit_phase1_protected_storage(self):
        plan=reseal(dict(self.plan,forbidden_storage_ids=[]))
        gate=dict(self.gate,plan_sha256=plan['sha256'])
        with self.assertRaisesRegex(ValueError,'all original P0/P1 storage'):
            b.check_gate(gate,plan,self.roster)

    def test_alternate_journal_or_workspace_or_storage_rejected(self):
        for changed in ({'root':self.workspace/'alternate-journal'},
                        {'workspace':self.workspace/'alternate-workspace'},
                        {'storage':dict(self.storage,index_library_file_id='libfile_TEST_ONLY_ALT')}):
            with self.subTest(changed=changed):
                with self.assertRaisesRegex(ValueError,'alternate'):
                    b.check_gate(self.gate,self.plan,self.roster,**changed)
        gate=dict(self.gate,bridge_journal_root=str(self.workspace/'phase1-bridge-journal'))
        with self.assertRaisesRegex(ValueError,'one fixed journal'):
            b.check_gate(gate,self.plan,self.roster)

    def test_unknown_reservation_never_replayed(self):
        reservation=self.reserve()
        contents=(self.root/'01.reserved.json').read_bytes()
        with self.assertRaisesRegex(ValueError,'unknown reservation'):self.reserve()
        self.assertEqual(contents,(self.root/'01.reserved.json').read_bytes())
        self.assertEqual(len(list(self.root.glob('*.reserved.json'))),1)
        self.assertEqual(reservation['record']['order'],73)

    def test_unknown_terminal_ack_never_replayed(self):
        self.advance()
        (self.root/'01.terminal.json').unlink()  # Only this test's private fixture.
        with self.assertRaisesRegex(ValueError,'terminal acknowledgment'):self.reserve()
        self.assertEqual(len(list(self.root.glob('*.reserved.json'))),1)

    def test_claimed_index_or_unknown_write_stops(self):
        reservation=self.reserve();rec=reservation['record']
        self.index,_=p.claim_index(self.index,self.claims[rec['slot_id']],rec['arm'],rec['config_file_sha256'])
        self.version+=1
        with self.assertRaisesRegex(ValueError,'unresolved claim'):self.reserve()
        receipt,status=self.head();status['external_write_pending']=True
        with self.assertRaisesRegex(ValueError,'producer uncertainty'):
            b.reserve_next(self.root,self.plan,self.roster,self.index,receipt,self.storage,p,status,self.gate)
        self.assertEqual(len(list(self.root.glob('*.reserved.json'))),1)

    def test_changed_index_predecessor_rejected(self):
        self.index=reseal(dict(self.index,predecessor={'TEST_ONLY':'foreign predecessor'}))
        with self.assertRaisesRegex(ValueError,'operational/scientific lineage'):self.reserve()

    def test_phase1_index_row_or_archive_rejected(self):
        rec=self.roster['records'][0]
        claim=reseal(dict(self.claims[rec['slot_id']],phase=1))
        self.index,_=p.claim_index(self.index,claim,rec['arm'],rec['config_file_sha256'])
        with self.assertRaisesRegex(ValueError,'exact original phase2'):self.inspect()
        self.index=p.initial_index(self.run,self.freeze['sha256'],['EOH_TC','IID_TC'],'official_cli',self.plan['predecessor'])
        self.index=reseal(dict(self.index,archives={'1':{'library_file_id':self.storage['archive_library_file_id']}}))
        with self.assertRaisesRegex(ValueError,'phase2 archive only'):self.inspect()

    def test_index_prefix_reordering_rejected(self):
        self.advance();self.advance()
        value=copy.deepcopy(self.index);value['rows'][0],value['rows'][1]=value['rows'][1],value['rows'][0]
        self.index=reseal(value)
        with self.assertRaisesRegex(ValueError,'exact original phase2'):self.reserve()

    def test_persistent_journal_tamper_rejected(self):
        self.advance();prior=b.load(self.root/'01.reserved.json');prior['logical_requests']=2
        (self.root/'01.reserved.json').write_bytes(b.canon(prior))
        with self.assertRaisesRegex(ValueError,'seal mismatch'):self.reserve()

    def test_config_prompt_parent_or_phase_tamper_rejected(self):
        reservation=self.reserve();sid=reservation['record']['slot_id'];pack=self.packs[sid];claim=self.claims[sid]
        for changed_pack,changed_config in ((pack,b'TEST_ONLY_changed_config'),
                (reseal(dict(pack,prompt='TEST_ONLY_changed_prompt')),self.config),
                (reseal(dict(pack,parents=['TEST_ONLY_foreign_parent'])),self.config),
                (reseal(dict(pack,phase=1)),self.config)):
            with self.subTest(changed_pack=changed_pack['sha256'],changed_config=changed_config):
                with self.assertRaises(ValueError):
                    b.verify_reserved(self.root,reservation,self.plan,changed_pack,claim,self.freeze,changed_config)

    def test_unissued_status_rows_are_not_fabricated(self):
        self.advance();receipt,status=self.head()
        snapshot=b.status_snapshot(self.plan,self.roster,self.index,receipt,self.storage,p,status)
        self.assertEqual(snapshot['phase2_terminal_requests'],1)
        self.assertFalse(snapshot['phase2_generation_complete'])
        self.assertEqual(len(snapshot['rows']),60)
        self.assertEqual(snapshot['rows'][0]['state'],'terminal')
        self.assertTrue(all(row['state']=='not_dispatched' and row['terminal'] is None for row in snapshot['rows'][1:]))

    def test_prepare_keeps_existing_driver_call_and_rejects_bad_gate_first(self):
        reservation=self.reserve();sid=reservation['record']['slot_id'];receipt,_=self.head()
        driver=Mock();driver.prepare.return_value={'TEST_ONLY':'prepared'}
        kwargs=dict(root=self.root,reservation=reservation,plan=self.plan,roster=self.roster,index=self.index,
            receipt=receipt,pack=self.packs[sid],claim=self.claims[sid],freeze=self.freeze,config=self.config,
            base=b'TEST_ONLY_base',route=b'TEST_ONLY_route',gate=self.gate,workspace=self.workspace,driver=driver)
        self.assertEqual(b.prepare_reserved(**kwargs),{'TEST_ONLY':'prepared'})
        driver.prepare.assert_called_once_with(self.index,receipt,self.packs[sid],self.claims[sid],self.freeze,
            self.config,b'TEST_ONLY_base',b'TEST_ONLY_route',self.gate,workspace=self.workspace)
        driver.reset_mock();kwargs['gate']=dict(self.gate,authorized_phase=1)
        with self.assertRaises(ValueError):b.prepare_reserved(**kwargs)
        driver.prepare.assert_not_called()

    def test_collect_preserves_integrity_halt_and_driver_route(self):
        reservation=self.reserve();sid=reservation['record']['slot_id'];rec=reservation['record']
        claimed,inv=p.claim_index(self.index,self.claims[sid],rec['arm'],rec['config_file_sha256'])
        self.index=claimed;self.version+=1;receipt,_=self.head()
        retained=self.workspace/'retained'/sid;retained.mkdir(parents=True)
        (retained/'metadata.json').write_bytes(b.canon({'TEST_ONLY':True,'stop_reason':'tool_event'}))
        (retained/'export.json').write_bytes(b.canon({'TEST_ONLY':True,'cli':{'resume_requested':False},'terminal':{}}))
        driver=Mock();driver.check_input.return_value={'TEST_ONLY':'checked'}
        driver.collect_slot.return_value={'TEST_ONLY':True,'schema_integrity_verified_locally':True}
        summary=b.collect_reserved(root=self.root,reservation=reservation,plan=self.plan,roster=self.roster,
            pack=self.packs[sid],claim=self.claims[sid],producer_reservation=inv,freeze=self.freeze,
            config=self.config,base=b'TEST_ONLY_base',route=b'TEST_ONLY_route',fresh_claim_receipt=receipt,
            gate=self.gate,workspace=self.workspace,driver=driver)
        driver.collect_slot.assert_called_once_with(self.workspace,self.claims[sid],inv,self.freeze,self.config,
            {'TEST_ONLY':'checked'},receipt,gate=self.gate)
        self.assertTrue(summary['phase2_halt_required'])
        self.assertEqual(summary['phase2_halt_reasons'],['tool_event'])
        self.assertTrue((self.root/'HALTED.json').is_file())
        with self.assertRaisesRegex(ValueError,'integrity halt'):self.reserve()

    def test_actual_package_verifier_rejects_missing_or_changed_inputs(self):
        # This one tests only fresh, temporary file integrity, not authenticity.
        self.package_patch.stop()
        package=self.workspace/'TEST_ONLY_package';package.mkdir();(package/'inputs').mkdir()
        with patch.object(b,'HERE',package):
            with self.assertRaises(FileNotFoundError):b.verify_local_package()
            files={'PLAN.json':b'{"TEST_ONLY":"plan"}',
                'inputs/roster.json':b'{"TEST_ONLY":"roster"}',
                'phase2_producer_bridge.py':b'# TEST_ONLY non-executable bridge fixture\n'}
            for name,data in files.items():(package/name).write_bytes(data)
            manifest=b.seal({'TEST_ONLY':True,'files':{name:b.sha(data) for name,data in files.items()}})
            (package/'PACKAGE_MANIFEST.json').write_bytes(b.canon(manifest))
            self.assertEqual(b.verify_local_package(),manifest)
            (package/'PLAN.json').write_bytes(b'{"TEST_ONLY":"tampered"}')
            with self.assertRaisesRegex(ValueError,'package drift: PLAN.json'):b.verify_local_package()
            missing=b.seal({'TEST_ONLY':True,'files':{}})
            (package/'PACKAGE_MANIFEST.json').write_bytes(b.canon(missing))
            with self.assertRaisesRegex(ValueError,'reviewed phase2 package inputs'):b.verify_local_package()


if __name__=='__main__':
    unittest.main(verbosity=2)
