# 原132第二代接线：实现完成，真实绑定与执行仍关闭

工程准备不等于实验。本目录是独立审阅包；没有真实P2父代、请求、claims、freeze、roster、PLAN、registry、数值state或执行批准。没有模型调用、真实候选执行或Codex任务。本次只读过明确允许的P1 rows.json文本长度；没有读results、bundles或进行中分数。原P1包、协议、计量器及active state均未修改。

## 已实现

- bind_final_p1.py / phase2_binding.py：验证外部父代理固定的完整P1 report、packet、ledger、audit、reviewer、generation readback和producer fence；三者必须是同一最终60终态头。原scheduler精确replay通过后，才可一次性生成60项新的disabled输入包。
- phase2_scheduler.py：复用原SafeRunner、原冻结slot顺序、抽父算法和种子；恢复最终P1后输出73..132，EOH/IID各30，五算子各6。全部真实g2终态后投影P2，132次logical与780行score计划边界不变，不能再发g3请求。
- phase2_producer_bridge.py：复制P1窄改，保留原exporter V2、once-only claim/journal、未知结果停机；保护P0/P1四个Library稳定ID，60终态即停止。
- phase2_numerical.py：复制P1窄改，固定独立phase2 state、phase2 registry/deployment/receipt scope；60 admission/300packs上限、原runtime与checker不变。
- phase2_preflight_handoff.py / phase2_audit_terminal.py：完整60终态接收预检；终态审计逐项重验receipts/journals、数值资源、exact Fraction排序，独立重算完整parent RNG票据，核对P0/P1及所有非g2 score（含controls/heldout）不变、P2及实际g1→g2谱系。forward meter终态回执、stdout与实际exitcode仍由父代理另行审核，数值审计不冒称覆盖这一步。
- phase2_meter.py：复制已审P1外置meter的进程/时钟/清理逻辑，只改phase2固定目标和后填绑定。数值prepare/run额外检查直接meter父进程、精确forward grant、once-only claim、实际命令及继承CPU limit，不能拿数值批准直接绕过计量入口。
- PARENT_BOUNDARY_TEMPLATE.json、P1_REVIEWER_TEMPLATE.json、RESOURCE_ACCOUNTING_PROPOSAL.json：全部未批准或未绑定。

本审阅ZIP只包含窄适配、测试、模板和静态引用，不是自包含的新执行环境；继续复用本云原冻结依赖。真正绑定后再为已核连接的producer准备所需原exporter/adapter和disabled包，并按原哈希逐项校验，不因缺文件更换源码或CLI。

原exporter、receiver、隔离runtime、source/description界限、64KiB base及1MiB提示界限没有改。没有重造沙箱或模型客户端。PHASE2_*_DIFF.patch枚举各复制适配相对原文件的差异。

## 已验证的工程范围

73项测试通过（另含10个重封篡改子例和4个错误启动形式子例）：

- 12项原调度/提示synthetic检查
- 28项producer桥scope、未知状态、计数与篡改测试
- 4项整链测试：完整60项export→capture/import→真实ReceiptBridge验证synthetic数值回执→实际get_or_execute mock backend→P2投影
- 6项数值prepare/registry/deployment、0源、60/300 cap及不重放测试
- 10项meter trusted dummy/入口测试：CPU继承、wait4、绝对wall、孤儿清理、父死亡，以及错误启动在attempt前拒绝
- 6项最终P1证据/builder测试：早期clean fence、变更readback、partial、hash篡改拒绝，真实builder在隔离fixture目录产出disabled包
- 4项终态审计测试：完整60/300 fabricated receipts；全部格式失败；已admit但pack不完整；完整混合普通失败（格式失败、static admission拒绝、resource_limit），后者59 admissions/286 packs均被正确核验。完整候选archive、派生字段、历史archive、完整score视图/ID序列、逐slot恰好1次logical、P2快照及完整scheduler摘要（含winner）全部绑定；重封ledger/report仍不能掩盖篡改。
- 3项数值meter入口guard的metadata double测试

上述数值回执、session信任、审批与backend均为明确的测试double。测试不证明真实外部身份、候选质量、真实隔离执行或实验结果。所有测试目录已清理；只有日志/源代码留下。

运行全套可用 REVIEW_TESTS.sh。生产脚本不能使用测试double或把fixture更名作为真实证据。

## 最后填充顺序：必须等P1独立终态审通过

1. 完成真实P1 terminal audit并独立review。填P1_REVIEWER_TEMPLATE副本：accepted=true，精确绑定report、packet、ledger、audit四个文件字节SHA；schema保留phase1-terminal-parent-review-v1。保留真正独立reviewer身份/来源证据。
2. 填PARENT_BOUNDARY_TEMPLATE副本。每个evidence都是绝对规范path+外部已核的file_sha256。status必须由父代理设为FINAL_P1_INDEPENDENTLY_ACCEPTED。report必须phase1_complete、无halt；packet60项且13..72；ledger72已发、4快照，g2仍planned；audit必须passed且无unknown/清理问题。readback、audit.identity、原producer fence须同一个最终index头。已completed/disconnected的原producer不是重跑理由，禁止在复制workspace制造“原端fence”。
3. 另行独立审查P2 forward accounting。RESOURCE_ACCOUNTING_PROPOSAL目前未批准：原shared历史余额仍null，不能声称恢复旧120/600/900余量，也不能默认reset。必须填真实P1计量终态回执与numeric审计的SHA，并且input_binding_and_generation_bookkeeping_accounting也必须有父代理批准的明确前瞻额度或真实余额证据文件SHA。当前该项故意未绑定。
4. 本地binding/numeric的前瞻proposal分别列清范围：numeric prepare的静态CPU上界120s、inclusive wall120s；numeric run的静态trusted CPU上界900s、inclusive wall=5*A+90*P+900。它们是新前瞻协调额度提案，不是旧总CPU预算合规证明。input-binding及生成bookkeeping需要上一步额外明确绑定；不能用数值meter暗示已覆盖这些步骤。accounting的parent_review_accepted/status、独立review SHA和phase2_meter SHA均由父代理审后填写，仍不授予generation或numeric执行权。
5. 在已批准的输入准备/协调资源范围内执行一次：

    python -I -B original132_phase2_continuation_draft_20261006/bind_final_p1.py --parent-boundary FINAL_BOUNDARY --parent-boundary-sha256 PARENT_PIN --accounting APPROVED_ACCOUNTING --accounting-sha256 PARENT_PIN

   builder先完整验证并replay已审P1，再预检所有60个prompt，随后才写新inputs/history/LINEAGE/PLAN/SOURCE_INPUT_PLAN/PACKAGE_MANIFEST。仍为disabled，不发请求。任一步出现partial输出立即停并对账，不删目录重建。现有BINDINGS.json只允许从已知UNBOUND_DISABLED占位一次转为FINAL_P1_BOUND_DISABLED；不是执行switch。
6. 独立审核builder结果及全部代码diff。父代理在届时检查实际环境连接、既有授权Coding Plan通道、原官方CLI版本和binary SHA，不能换模型、provider、endpoint、config、session/重试语义。没有连接时保留等待；本包不创建Codex。
7. 获得两个新且真实确认的phase2 Library身份，建立唯一workspace/phase2-bridge-journal。以inputs/EXECUTION_SWITCH.json作模板，在包外新建完整父生成批准，填package manifest、workspace、journal、storage与最新前驱头确认；绑定所有60请求/slot序列和三项parent/reviewer/accounting SHA。不要编辑包内冻结switch，也不能仅把enabled改true，否则source/package哈希会变。
8. 生成仅通过phase2_producer_bridge的reserve→原driver.prepare→真实Library claim确认→原driver.collect_slot→真实archive/index终态提交→finish_position。失败消费位置，不补抽；不确定写入/session/dispatch立即停并对账。不得覆盖四个P0/P1 Library ID，不掺入side-experiment9候选。
9. 60项生成全终态后，用原adapter取得真实authenticated readback和原phase2 producer fence。另填phase2-authenticated-handoff-v1，含run_id=urp132_20261005_b01_phase2、最终freeze、科学run和lineage、readback/fence路径及外部trusted hashes，固定保存到本目录runtime-evidence/phase2-authenticated-handoff.json。
10. 外部父prepare grant使用schema phase2-forward-coordination-grant-v1、action=prepare、精确meter SHA、package_manifest_file_sha256、command_source_sha256三个固定脚本文件、resource_accounting_binding_sha256、handoff SHA、明确的forward额度。通过meter而非直接harness调用：

    python -I -B /workspace/scratch/27470b7a9f17/original132_phase2_continuation_draft_20261006/phase2_meter.py --grant /ABSOLUTE/PARENT_PREPARE_GRANT.json --grant-sha256 PARENT_PIN

   meter脚本及grant均必须使用绝对规范路径，使用精确python -I -B标志，参数严格按--grant再--grant-sha256顺序；相对路径、交换参数或额外interpreter标志现在均在写attempt/claim之前拒绝，避免消费一次性额度。run同样采用上述绝对meter入口，只替换为绝对PARENT_RUN_GRANT路径。

   meter prepare完成后得到唯一新state的plan/registry/deployment。A来自真实文本提取数量，不假设60；P最多5A。prepare不执行候选。
11. 父代理另行批准精确phase2-execution-approval-v1，绑定package manifest、plan/registry/deployment、A/P、controls=heldout=0及parent_boundary、parent_review_acceptance、resource_accounting三SHA；保存到phase2 state/parent_execution_approval.json。保持原receipt trust文件及SHA。另给action=run的forward grant（plan/approval字节SHA和5*A+90*P+900 wall），仍经phase2_meter启动。未知状态或失败不自动重试。
12. 数值完成后运行只读phase2_audit_terminal.py，使用真实report/approval及外部保留的文件SHA，输出路径必须新。再独立review审计结果。它按已验observation重建完整archive及score视图，保留历史archive，重建完整P2快照并把winner摘要绑定到快照首名。它明确区分审计通过与谱系接力criterion：若原抽样没用到保留g1后代，报告false，不强制换父。
13. P2完成后没有新generation。先封存两臂winner，heldout仍须原独立门禁；本包不授权controls/heldout，也未读取heldout数据。

## 科学与资源不变量

- 科学计划132=12+60+60；score计划780=660 candidate design+20 control+100 heldout。失败/未执行位置保留，不能拿空余额补抽。
- g2固定73..132，EOH/IID各30。原slot-local SHA256 parent PRNG及seed610050101，原顺序/tie种子、精确有理数排名、joint去重及带放回抽样不变。所有父来自已审P1快照。
- 公共提示只含id/description/code/pair_sha256；不把内部含fitness的parent_provenance送模型。IID原i1字节不变；每个提示一个parent块和一个原response rule。
- 同一原模型glm-5.3、Coding Plan、effort high、temperature0.7、top_p0.9、32k、900s、steps2、tools=false、outer_retries0。物理HTTP次数和wire实参仍未知，不作等实际成本断言。
- g2最多60 admission/300实例packs；60+300*(60+60)=36,060 reserved CPU；60*5+300*90=27,300 shared wall。生成另54,000 window秒。原runtime profile、checker、无跨slot缓存及不重评保留父均不变。
- 已知原P0是4 admission/20packs；P1实际数量与预留从最终审计后填。原nominal总95,100 CPU/194,220 summed wall不能在旧shared历史不明时冒称实际合规。前瞻addendum单列，不篡改原科学台账，也不伪造剩余额度。

## 当前文本长度已排除64KiB风险

按明确授权，仅从rows.json取29个文本候选，再从冻结P1提示取保留P0的1个公开父文本。该30项超集含IID，因此覆盖任何最终EOH父代可能。按精确嵌套JSON转义最长对象重复5次，e2完整serialized base最大19,484/65,536字节，余46,052；user payload18,207字节。原五个operator builder均通过。源最长435 bytes、描述最长807 bytes。rows前后字节SHA均为402288a726023d210f0820a86e53d0d1e753a3b6bd6461ed3ff95dc680caa637。

极端synthetic五长父仍会命中原64KiB检查，仅作为接口负例保留；当前真实材料不需要放宽任何限制。最终真实P2提示身份/字节仍在P1终态审后精确预检。
