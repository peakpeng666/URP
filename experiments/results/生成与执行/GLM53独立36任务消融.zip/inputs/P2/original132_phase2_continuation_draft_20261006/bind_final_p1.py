"""One-time DISABLED g2 package construction from externally pinned final P1.

This command never authorizes or performs generation, admission or numeric work.
Currently unusable: required final evidence and approved accounting do not exist.
"""
import argparse,copy,json,os
from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent;P1=ROOT/'original132_phase1_preparation_20261005'
sys.path.insert(0,str(HERE))
from phase2_binding import canon,sha,seal,verify,need,read,validate_final_p1,validate_accounting,RUN,SCIENTIFIC


def put(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as f:f.write(value if isinstance(value,bytes) else canon(value));f.flush();os.fsync(f.fileno())


def build(boundary_path,boundary_sha,accounting_path,accounting_sha):
    need(not (HERE/'inputs').exists() and not (HERE/'history').exists() and not (HERE/'PLAN.json').exists(),'existing package; no rebuild/reset')
    need(read(HERE/'BINDINGS.json')['status']=='UNBOUND_DISABLED','only unbound draft may bind once')
    boundary=read(boundary_path,boundary_sha);ev=validate_final_p1(boundary)
    accounting=read(accounting_path,accounting_sha);validate_accounting(accounting)
    need(accounting['prior_numeric_reservations_audit_file_sha256']==boundary['evidence']['audit']['file_sha256'],'prior actual numeric accounting audit binding')
    need(sha((HERE/'phase2_meter.py').read_bytes())==accounting['phase2_meter_file_sha256'],'reviewed prospective meter')
    from phase2_draft import verify_static_pins
    verify_static_pins()
    from phase2_scheduler import replay_phase1,phase2_requests
    runner=replay_phase1(ev['packet'],ev['ledger'])
    prior=verify(read(P1/'inputs/freeze.json'))
    requests=phase2_requests(runner,prior['input_route_evidence_sha256'])
    # All 60 prompts are preflighted before writing the package or any external claim.
    sys.path.insert(0,str(P1/'exporter/src'))
    import protocol_v2,capture_v2
    lineage=seal({'schema':'original132-phase2-lineage-v1','scientific_run_id':SCIENTIFIC,'operational_run_id':RUN,
        'original_scientific_freeze_sha256':prior['original_scientific_freeze_sha256'],
        'phase1_freeze_sha256':prior['sha256'],'phase1_lineage_sha256':prior['lineage_sha256'],
        'parent_boundary_file_sha256':boundary_sha,'parent_ledger_sha256':ev['ledger']['sha256'],
        'parent_review_acceptance_sha256':boundary['evidence']['reviewer']['file_sha256'],
        'resource_accounting_binding_sha256':accounting_sha,
        'generation_before':72,'generation_total':132,'score_plan_total':780,'side_experiment_candidates':0})
    p1_eoh=next(x for x in ev['ledger']['snapshots'] if x['phase']==1 and x['arm']=='EOH_TC')
    scope=seal({'schema':'original132-phase2-resource-scope-v1','scientific_run_id':SCIENTIFIC,'operational_run_id':RUN,
        'generation_requests':60,'generation_per_arm':30,'configured_completion_tokens_maximum':1920000,
        'summed_generation_window_reservation_seconds':54000,'maximum_admissions':60,'maximum_design_packs':300,
        'maximum_numerical_reserved_cpu_seconds':36060,'maximum_numerical_reserved_shared_wall_seconds':27300,
        'prior_P0_design_packs':20,'prior_P1_design_packs':ev['audit']['design_packs'],
        'original_overall_generation_maximum':132,'original_overall_score_maximum':780,
        'historical_original_shared_balance':None,'historical_shared_cap_compliance':'not authenticated; not claimed',
        'forward_accounting_binding_sha256':accounting_sha,'no_implicit_reset':True,
        'controls':0,'heldout':0,'retained_parent_rescores':0,'outer_retries':0,'replacements':0,
        'execution_authorized_by_this_file':False})
    fields={k:copy.deepcopy(v) for k,v in prior.items() if k not in ('sha256','phase1_resource_scope_sha256')}
    fields.update(schema='original132-phase2-operational-freeze-v1',run_id=RUN,phase=2,
        lineage_sha256=lineage['sha256'],phase2_resource_scope_sha256=scope['sha256'],
        parent_boundary_sha256=boundary_sha,parent_ledger_sha256=ev['ledger']['sha256'],
        parent_snapshot_sha256=p1_eoh['sha256'],resource_accounting_binding_sha256=accounting_sha,
        status='PREPARED_DISABLED_REQUIRES_PARENT_REVIEW',authorization_scope='Original phase2 orders73..132 only after explicit activation. No further generation, controls or heldout.',
        final_generation_phase_scope=2,final_generation_dispatch_count=60)
    freeze=seal(fields)
    base=(P1/'inputs/base-artifact.json').read_bytes();config=(P1/'inputs/config.raw.json').read_bytes();route=(P1/'inputs/input-route.json').read_bytes()
    records=[];packs=[];claims=[];parents=[]
    original_iid=next(x for x in read(P1/'inputs/roster.json')['records'] if x['arm']=='IID_TC')
    iid_prompt=read(P1/'inputs/packs'/(original_iid['slot_id']+'.json'))['prompt']
    for request,prompt in requests:
        slot=request['id']
        pack=seal({'schema':'wave-prompt-pack-v1','run_id':RUN,'slot_id':slot,'phase':2,
            'arm':request['arm'],'operator':request['operator'],'order':request['order'],
            'parents':request['parents'],'parent_snapshot_sha256':request['parent_snapshot_sha256'],
            'parent_pair_hashes':[p['pair_sha256'] for p in request['parent_provenance']],
            'prompt':prompt['cli_user_prompt'],'prompt_sha256':sha(prompt['cli_user_prompt'].encode()),
            'serialized_messages_sha256':prompt['prompt_sha256'],'source_prompt_artifact_sha256':sha(canon(prompt)),
            'configuration':freeze['configuration'],'configuration_sha256':sha(canon(freeze['configuration'])),
            'freeze_sha256':freeze['sha256'],'contains_data_bytes':False,'mode':'official_cli'})
        claim=seal({'schema':'wave-external-claim-v1','run_id':RUN,'slot_id':slot,'phase':2,
            'claim_id':sha(canon(['wave-claim-v1',RUN,slot])),'request_sha256':pack['sha256'],'freeze_sha256':freeze['sha256']})
        checked=capture_v2.check_input(pack,claim,freeze,config,base,route)
        if request['arm']=='IID_TC':need(pack['prompt']==iid_prompt and not pack['parents'],'unchanged IID')
        packs.append(pack);claims.append(claim)
        records.append({'position':len(records)+1,'order':request['order'],'slot_id':slot,'run_id':RUN,'phase':2,
            'arm':request['arm'],'operator':request['operator'],'parents':request['parents'],
            'parent_snapshot_sha256':request['parent_snapshot_sha256'],'claim_id':claim['claim_id'],
            'claim_sha256':claim['sha256'],'request_sha256':pack['sha256'],'freeze_sha256':freeze['sha256'],
            'config_file_sha256':freeze['config_file_sha256'],'prompt_sha256':pack['prompt_sha256'],
            'actual_cli_payload_bytes':len(checked['prompt']),'serialized_messages_sha256':pack['serialized_messages_sha256']})
        parents.append({k:copy.deepcopy(request[k]) for k in ('id','order','arm','operator','parents','parent_draw','parent_snapshot_sha256','parent_provenance','tie_priority')})
    roster=seal({'schema':'original132-phase2-fixed-roster-v1','run_id':RUN,'scientific_run_id':SCIENTIFIC,'phase':2,'count':60,'freeze_sha256':freeze['sha256'],'records':records})
    fence=ev['producer_fence']
    predecessor={'scientific_run_id':SCIENTIFIC,'freeze_sha256':prior['sha256'],'ledger_sha256':ev['ledger']['sha256'],
        'lineage_sha256':prior['lineage_sha256'],**{k:fence[k] for k in ('library_file_id','file_id','current_version_number','index_blob_sha256')}}
    plan=seal({'schema':'original132-phase2-continuation-plan-v1','run_id':RUN,'scientific_run_id':SCIENTIFIC,'phase':2,
        'status':'PREPARED_DISABLED','freeze_sha256':freeze['sha256'],'roster_sha256':roster['sha256'],
        'lineage_sha256':lineage['sha256'],'resource_scope_sha256':scope['sha256'],'parent_boundary_sha256':boundary_sha,
        'parent_review_acceptance_sha256':boundary['evidence']['reviewer']['file_sha256'],
        'resource_accounting_binding_sha256':accounting_sha,'predecessor':predecessor,
        'storage':{'index_library_file_id':None,'archive_library_file_id':None},
        'forbidden_storage_ids':['libfile_c904cc20ec4c81918b438f206e1b60ad','libfile_911c5755e8b081918c4901ff766ee71f','libfile_9afab4077ef48191ba90b2adbe95093f','libfile_221f3504a0d081918fd9aab558c12577'],
        'generation_switch_enabled':False,'numerical_switch_enabled':False,'phase2_activation':False,'holdout_activation':False,
        'generation_calls':0,'admissions':0,'scores':0,'external_writes':0,'new_operational_namespace_not_new_scientific_sample':True})
    # No writes until all evidence, exact replay and all 60 prompt checks passed.
    put(HERE/'history/parent-boundary.json',Path(boundary_path).read_bytes())
    put(HERE/'history/resource-accounting-binding.json',Path(accounting_path).read_bytes())
    for key,name in [('ledger','scheduler-ledger.json'),('packet','scheduler-input.json')]:put(HERE/'history'/name,Path(boundary['evidence'][key]['path']).read_bytes())
    for name in ('config.raw.json','base-artifact.json','input-route.json','resource-amendment.json'):put(HERE/'inputs'/name,(P1/'inputs'/name).read_bytes())
    for name,value in [('LINEAGE.json',lineage),('RESOURCE_SCOPE.json',scope),('PLAN.json',plan),('inputs/freeze.json',freeze),('inputs/roster.json',roster),('inputs/index.initial.json',protocol_v2.initial_index(RUN,freeze['sha256'],['EOH_TC','IID_TC'],'official_cli',predecessor))]:put(HERE/name,value)
    for pack,claim in zip(packs,claims):put(HERE/'inputs/packs'/(pack['slot_id']+'.json'),pack);put(HERE/'inputs/uncommitted-claims'/(pack['slot_id']+'.json'),claim)
    put(HERE/'INTERNAL_PARENT_PROVENANCE.json',{'not_model_input':True,'audited_P1_ledger_sha256':ev['ledger']['sha256'],'P1':ev['ledger']['snapshots'][2:],'records':parents})
    put(HERE/'inputs/EXECUTION_SWITCH.json',{'enabled':False,'parent_review_accepted':False,'authorized_phase':2,'freeze_sha256':freeze['sha256'],'resource_amendment_sha256':freeze['resource_amendment_sha256'],'plan_sha256':plan['sha256'],'roster_sha256':roster['sha256'],'parent_boundary_sha256':boundary_sha,'parent_review_acceptance_sha256':boundary['evidence']['reviewer']['file_sha256'],'resource_accounting_binding_sha256':accounting_sha,'authorized_request_sha256':[r['request_sha256'] for r in records],'authorized_slot_order':[r['slot_id'] for r in records],'package_manifest_sha256':None,'producer_workspace':None,'bridge_journal_root':None,'storage':{'index_library_file_id':None,'archive_library_file_id':None},'original_head_current_confirmed':False,'original_index_blob_sha256':predecessor['index_blob_sha256'],'reason':'Independent package, environment, storage and exact activation review required; never merely flip enabled'})
    put(HERE/'NUMERICAL_SWITCH.json',{'enabled':False,'run_id':RUN,'max_admissions':60,'max_design_packs':300,'controls':0,'heldout':0})
    bound=seal({'schema':'phase2-bound-package-v1','status':'FINAL_P1_BOUND_DISABLED','run_id':RUN,'execution_enabled':False,
        'generation_freeze_sha256':freeze['sha256'],'parent_boundary_sha256':boundary_sha,
        'parent_review_acceptance_sha256':boundary['evidence']['reviewer']['file_sha256'],'resource_accounting_binding_sha256':accounting_sha})
    # Only this known draft placeholder may be replaced; partial runs cannot resume.
    need(read(HERE/'BINDINGS.json')['status']=='UNBOUND_DISABLED','binding changed concurrently')
    (HERE/'BINDINGS.json').write_bytes(canon(bound))
    original=verify(read(P1/'SOURCE_INPUT_PLAN.json'));files=dict(original['source_and_input_files'])
    for rel,expected in files.items():need(sha((ROOT/rel).read_bytes())==expected,'inherited source drift '+rel)
    for path in sorted(HERE.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts and path.name not in ('PACKAGE_MANIFEST.json','SOURCE_INPUT_PLAN.json','MANIFEST.json'):
            files[path.relative_to(ROOT).as_posix()]=sha(path.read_bytes())
    source=seal({'schema':'phase2-source-input-plan-v1','run_id':RUN,'scientific_run_id':SCIENTIFIC,
        'source_and_input_files':files,'runtime_sha256':original['runtime_sha256'],'design_panel':original['design_panel'],
        'design_file_sha256':original['design_file_sha256'],'execution_authorized':False,'holdout_access':False})
    put(HERE/'SOURCE_INPUT_PLAN.json',source)
    packagefiles={p.relative_to(HERE).as_posix():sha(p.read_bytes()) for p in sorted(HERE.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.name not in ('PACKAGE_MANIFEST.json','MANIFEST.json')}
    manifest=seal({'schema':'original132-phase2-package-manifest-v1','status':'PREPARED_DISABLED_PENDING_INDEPENDENT_REVIEW','files':packagefiles,'source_input_plan_sha256':source['sha256']})
    put(HERE/'PACKAGE_MANIFEST.json',manifest)
    return {'status':'BOUND_DISABLED_NOT_ACTIVATED','freeze_sha256':freeze['sha256'],'roster_sha256':roster['sha256'],'plan_sha256':plan['sha256'],'package_manifest_sha256':manifest['sha256'],'requests_prepared':60,'model_calls':0}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--parent-boundary',required=True);p.add_argument('--parent-boundary-sha256',required=True);p.add_argument('--accounting',required=True);p.add_argument('--accounting-sha256',required=True);a=p.parse_args()
    print(json.dumps(build(a.parent_boundary,a.parent_boundary_sha256,a.accounting,a.accounting_sha256)))
