"""Trusted process-metadata doubles; no process or candidate execution."""
import hashlib,pathlib,sys,tempfile,unittest
from unittest.mock import patch
HERE=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import phase2_binding as b

class GuardTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='phase2-meter-guard-test-');self.root=pathlib.Path(self.tmp.name)
        self.meter=self.root/'phase2_meter.py';self.meter.write_text('# TRUSTED TEST MARKER; NEVER RUN\n')
        self.meter_sha=b.sha(self.meter.read_bytes());self.grant_path=self.root/'grant.json';self.pid=987654
        self.binding={'resource_accounting_binding_sha256':'1'*64}
        self.accounting={'phase2_meter_file_sha256':self.meter_sha}
        self.grant={'schema':'phase2-forward-coordination-grant-v1','action':'run','enabled':True,'parent_review_accepted':True,
                    'meter_sha256':self.meter_sha,'resource_accounting_binding_sha256':'1'*64}
        self.parent_cmd=[str(pathlib.Path(sys.executable).resolve()),'-I','-B',str(self.meter),'--grant',str(self.grant_path),'--grant-sha256','2'*64]
        self.own=[str(pathlib.Path(sys.executable).resolve()),'-I','-B',str(self.root/'phase2_numerical.py'),'run','--plan-file-sha256','3'*64]
        self.attempt={'grant_file_sha256':'2'*64,'meter_sha256':self.meter_sha}
        self.claim={**self.attempt,'action':'run','retry_authorized':False,'commands':[['run',['/usr/bin/prlimit','--cpu=300:300','--']+self.own]]}
        self.actual_read=pathlib.Path.read_bytes;self.actual_resolve=pathlib.Path.resolve;self.actual_exists=pathlib.Path.exists
    def tearDown(self):self.tmp.cleanup()
    def check(self,*,bad_parent=False,bad_command=False,cpu=300):
        def read(path,expected=None):
            path=pathlib.Path(path)
            if path.name=='resource-accounting-binding.json':return self.accounting
            if path==self.grant_path:return self.grant
            if path.name=='run.attempt.json':return self.attempt
            if path.name=='run.claim.json':return self.claim
            raise AssertionError(str(path))
        def bytes_(path):
            if str(path)==f'/proc/{self.pid}/cmdline':return b'\0'.join(x.encode() for x in (['not-meter'] if bad_parent else self.parent_cmd))+b'\0'
            if str(path)=='/proc/self/cmdline':return b'\0'.join(x.encode() for x in (self.own+['TAMPER'] if bad_command else self.own))+b'\0'
            return self.actual_read(path)
        def resolve(path,*a,**kw):
            if str(path)==f'/proc/{self.pid}/exe':return pathlib.Path(sys.executable).resolve()
            return self.actual_resolve(path,*a,**kw)
        def exists(path):
            if path.name=='run.receipt.json':return False
            return self.actual_exists(path)
        with patch.object(b,'load_bound_package',return_value=(self.binding,{})),patch.object(b,'read',side_effect=read),\
             patch('os.getppid',return_value=self.pid),patch('resource.getrlimit',return_value=(cpu,cpu)),\
             patch.object(pathlib.Path,'read_bytes',bytes_),patch.object(pathlib.Path,'resolve',resolve),patch.object(pathlib.Path,'exists',exists):
            return b.require_forward_meter('run',self.root)
    def test_exact_parent_claim_command_and_CPU(self):
        self.assertEqual(self.check()['parent_pid'],self.pid)
    def test_direct_or_wrong_command_rejected(self):
        with self.assertRaisesRegex(ValueError,'direct phase2 meter'):self.check(bad_parent=True)
        with self.assertRaisesRegex(ValueError,'exact forward claim'):self.check(bad_command=True)
    def test_wrong_CPU_or_reused_claim_rejected(self):
        with self.assertRaisesRegex(ValueError,'CPU limit'):self.check(cpu=40)
        self.claim['grant_file_sha256']='4'*64
        with self.assertRaisesRegex(ValueError,'once-only'):self.check()
if __name__=='__main__':unittest.main(verbosity=2)
