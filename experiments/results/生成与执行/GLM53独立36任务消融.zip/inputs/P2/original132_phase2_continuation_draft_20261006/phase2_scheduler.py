"""Pure phase2 replay/projection over unchanged original SafeRunner. No execution."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
P1=ROOT/'original132_phase1_preparation_20261005'
sys.path[:0]=[str(HERE),str(P1),str(ROOT/'URP/experiments/online_bin_packing/eoh_evolution_wave_v1')]
import scheduler_continuation as prior
from common import digest,require
from prompts import build_prompt, PUBLIC_RESPONSE_RULE


def restore_phase1():
    """Only complete parent-pinned, independently accepted final P1 can reach here."""
    from phase2_binding import load_bound_package
    binding, evidence=load_bound_package(HERE)
    return replay_phase1(evidence['packet'],evidence['ledger'])


def replay_phase1(packet,expected):
    require(packet['schema']=='phase1-scheduler-packet-v1' and
            packet['mode']=='production_verified_receipts','final P1 packet')
    original=json.loads((P1/'history/scheduler-input.json').read_bytes())
    ledger0=json.loads((P1/'history/scheduler-ledger.json').read_bytes())
    runner=prior.restore_phase0(original,ledger0)
    require(len(packet['rows'])==len(packet['observations'])==60,'sixty final P1 observations')
    prior.bind_phase1_dispatch(runner,packet['rows'])
    for row,obs in zip(packet['rows'],packet['observations']):
        require(row['slot_id']==obs['slot_id'],'P1 observation order')
        runner.observe_verified(obs['slot_id'],obs['capture'],obs['extraction'],obs['scores'],obs['admission'],obs['integrity_error'])
    require(runner.export()==expected,'exact audited P1 scheduler replay')
    require(runner._phase==2 and runner._halt_reason is None and len(runner._snapshots)==4,'clean P1 boundary')
    return runner


def phase2_requests(runner,route_sha256):
    before=copy.deepcopy(runner._snapshots)
    require(runner._phase==2 and runner._halt_reason is None and len(before)==4,'clean P1 boundary')
    require(sum(s['logical_requests_observed'] for s in runner._slots)==72,'72 prior logical requests')
    require(all(s['state']=='planned' for s in runner._slots if s['phase']==2),'g2 untouched')
    result=[]
    for order in range(73,133):
        request=runner.next_request()
        require(request is not None and request['phase']==2 and request['order']==order,'exact phase2 schedule; no refill')
        parents=[runner._archive[p] for p in request['parents']]
        count=0 if request['arm']=='IID_TC' else 5 if request['operator'] in ('e1','e2') else 1
        require(len(parents)==count,'original parent multiplicity')
        if parents:
            snapshot=next(s for s in before if s['phase']==1 and s['arm']=='EOH_TC')
            require(request['parent_snapshot_sha256']==snapshot['sha256'] and
                    set(request['parents'])<=set(snapshot['survivor_ids']) and request['parent_draw']['replacement'] is True,
                    'audited frozen P1 only')
        marker='\n\nOrdered parent draws (duplicates deliberately preserved):\n'
        content=request['prompt'][-1]['content']
        require(content.count(marker)==bool(parents),'one public parent block')
        if parents:
            public=json.loads(content.split(marker,1)[1].split('\n\n'+runner.public_contract,1)[0])
            require(public==[{k:p[k] for k in ('id','description','code','pair_sha256')} for p in parents], 'public whitelist')
        prompt=build_prompt(request['prompt'],[],delivery={'method':'stdin','verified_support':True,
            'support_evidence_sha256':route_sha256,'max_payload_bytes':1048576})
        result.append((request,prompt))
    require(runner.next_request() is None and runner._snapshots==before,'wait for sixty g2 observations')
    require(runner._reserved=={'logical_requests':132,'completion_tokens':4224000,'generation_wall_seconds':118800},'original generation caps')
    return result


def bind_phase2_dispatch(runner,rows):
    require(len(rows)==60 and [r['pack']['order'] for r in rows]==list(range(73,133)),'sixty g2 rows')
    for expected in rows:
        request=runner.next_request();pack=expected['pack']
        require(request is not None and request['phase']==2 and request['id']==pack['slot_id']
                and request['order']==pack['order'] and request['arm']==pack['arm']
                and request['operator']==pack['operator'] and request['parents']==pack['parents']
                and request['parent_snapshot_sha256']==pack['parent_snapshot_sha256'],'phase2 dispatch identity')
        prompt=copy.deepcopy(request['prompt']);prompt[-1]['content']+='\n\n'+PUBLIC_RESPONSE_RULE
        require(prompt[-1]['content']==pack['prompt'] and digest(prompt)==pack['serialized_messages_sha256'],'exact g2 prompt')
        slot=runner._slot(request['id'])
        slot.update(prompt=prompt,prompt_sha256=digest(prompt),configured=copy.deepcopy(pack['configuration']),
            cli_user_prompt_sha256=pack['prompt_sha256'],actual_pack_sha256=pack['sha256'],
            operational_run_id=pack['run_id'],operational_freeze_sha256=pack['freeze_sha256'])
        event=runner._events.pop();require(event['kind']=='dispatch','g2 dispatch event')
        event['payload'].update(prompt=prompt,prompt_sha256=digest(prompt),configured=slot['configured'])
        runner._event('dispatch',event['payload'])


def reconstruct(packet):
    require(packet['schema']=='phase2-scheduler-packet-v1' and packet['mode']=='production_verified_receipts','phase2 packet')
    runner=restore_phase1();old=runner.export()
    rows,observations=packet['rows'],packet['observations']
    require(len(rows)==len(observations)==60,'sixty assigned g2 observations')
    bind_phase2_dispatch(runner,rows)
    for row,obs in zip(rows,observations):
        require(row['slot_id']==obs['slot_id'],'g2 observation order')
        runner.observe_verified(obs['slot_id'],obs['capture'],obs['extraction'],obs['scores'],obs['admission'],obs['integrity_error'])
    ledger=runner.export()
    require(len(ledger['generation'])==132 and len(ledger['scores'])==780,'original denominator')
    require(sum(s['logical_requests_observed'] for s in ledger['generation'])==132,'no extra generation')
    require(ledger['snapshots'][:4]==old['snapshots'],'P0/P1 immutable')
    old_slots={s['id']:s for s in old['generation'] if s['phase']<2}
    require(all(s==old_slots[s['id']] for s in ledger['generation'] if s['phase']<2),'earlier generation immutable')
    old_scores={s['id']:s for s in old['scores'] if s.get('source_generation_slot') in old_slots}
    require(all(s==old_scores[s['id']] for s in ledger['scores'] if s.get('source_generation_slot') in old_slots),'earlier scores immutable')
    if runner._halt_reason is None:
        require(runner._phase==3 and len(ledger['snapshots'])==6 and runner.done,'P2 terminal boundary')
        require(runner.next_request() is None,'no generation after P2')
    return ledger


def main():
    source=Path(sys.argv[1]);raw=source.read_bytes()
    require(len(raw)<=64*1024*1024 and hashlib.sha256(raw).hexdigest()==sys.argv[2],'pinned g2 packet')
    ledger=reconstruct(json.loads(raw))
    with Path(sys.argv[3]).open('x') as stream:json.dump(ledger,stream,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False);stream.write('\n')
    print(json.dumps({'ledger_sha256':ledger['sha256'],'snapshots':len(ledger['snapshots'])}))
if __name__=='__main__':main()
