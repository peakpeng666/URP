"""Temporary source/receipt doubles; no actual candidate admission or execution."""
import copy,importlib.util,json,pathlib,sys,tempfile,unittest
from types import SimpleNamespace
from unittest.mock import patch
HERE=pathlib.Path(__file__).resolve().parent;ROOT=HERE.parent
sys.path.insert(0,str(HERE))
import phase2_numerical as h
m=h.modules()
P1=ROOT/'original132_phase1_preparation_20261005'


class NumericalTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='phase2-numeric-double-');self.root=pathlib.Path(self.tmp.name)
        self.inputs=self.root/'inputs';self.inputs.mkdir()
        freeze=json.loads((P1/'inputs/freeze.json').read_bytes());freeze.pop('sha256');freeze.update(run_id=h.RUN,phase=2)
        self.freeze=h.seal(freeze);h.write_once(self.inputs/'freeze.json',self.freeze)
        self.binding=h.seal({'parent_boundary_sha256':'1'*64,'parent_review_acceptance_sha256':'2'*64,'resource_accounting_binding_sha256':'3'*64})
        h.write_once(self.root/'BINDINGS.json',self.binding);h.write_once(self.root/'LINEAGE.json',h.seal({'TEST_ONLY':True}))
        h.write_once(self.root/'handoff.json',{'TEST_ONLY':True})
        self.patches=[patch.object(h,'HERE',self.root),patch.object(h,'INPUTS',self.inputs),patch.object(h,'STATE',self.root/'state'),
            patch.object(h,'require_forward_meter',return_value={'TEST_ONLY':True}),patch.object(h,'verify_sources',return_value={'sha256':'4'*64}),patch.object(h,'bound_freeze',return_value=self.freeze['sha256']),
            patch('ast.parse',side_effect=AssertionError('candidate AST forbidden')),patch('subprocess.Popen',side_effect=AssertionError('worker forbidden'))]
        for p in self.patches:p.start()
    def tearDown(self):
        for p in reversed(self.patches):p.stop()
        self.tmp.cleanup()
    def rows(self,empty=False):
        slots=json.loads((ROOT/'URP/experiments/online_bin_packing/eoh_evolution_runner_v1/generation_slots.json').read_bytes())['records'];rows=[];raws={}
        for s in slots:
            if s['phase']!=2:continue
            claim=h.seal({'schema':'wave-external-claim-v1','run_id':h.RUN,'slot_id':s['id'],'phase':2,
                'claim_id':h.digest(['wave-claim-v1',h.RUN,s['id']]),'request_sha256':'5'*64,'freeze_sha256':self.freeze['sha256']})
            raw='' if empty else '{Trusted synthetic '+s['id']+'}\n```python\nOPAQUE UNPARSABLE SENTINEL\n```'
            capture={'raw':raw,'status':'ok','capture_complete':True,'finish_reason':'stop','tool_calls':[]}
            c,raw_sha,metrics=(None,h.sha(b''),{'unique':False,'strict':False}) if empty else m['extract'](capture)
            raws[claim['claim_id']]=raw.encode();rows.append({'slot_id':s['id'],'arm':s['arm'],'order':s['order'],'claim':claim,
                'capture':capture,'candidate':c,'raw_response_sha256':raw_sha,'format_metrics':metrics,'reason':'TEST_ONLY' if empty else None})
        return rows,SimpleNamespace(raw=lambda c:raws[c],index_identity={'TEST_ONLY':True})
    def test_sixty_prepare_phase2_registry_deployment_no_workers(self):
        rows,store=self.rows()
        with patch.object(h,'imported_rows',return_value=(store,rows)):
            result=h.prepare(self.root/'handoff.json',h.sha((self.root/'handoff.json').read_bytes()))
        plan=h.verify(h.read(h.STATE/'plan.json'))
        self.assertEqual(result['textually_extractable'],60);self.assertEqual(plan['phase'],2)
        self.assertEqual(plan['max_admissions'],60);self.assertEqual(plan['max_candidate_packs'],300)
        self.assertEqual(h.read(h.STATE/'registry.json')['phase'],2);self.assertEqual(h.read(h.STATE/'deployment.json')['phase'],2)
        self.assertIsNone(plan['historical_original_shared_balance']);self.assertFalse(plan['execution_enabled'])
        self.assertEqual(list((h.STATE/'runtime_journal').iterdir()),[])
        self.assertEqual(plan['parent_boundary_sha256'],'1'*64)
    def test_zero_source_prepare_no_registry(self):
        rows,store=self.rows(empty=True)
        with patch.object(h,'imported_rows',return_value=(store,rows)):
            result=h.prepare(self.root/'handoff.json',h.sha((self.root/'handoff.json').read_bytes()))
        self.assertEqual(result['textually_extractable'],0)
        self.assertFalse((h.STATE/'registry.json').exists());self.assertIsNone(h.read(h.STATE/'plan.json')['registry_sha256'])
    def test_preparation_cannot_reset_existing_state(self):
        rows,store=self.rows(empty=True)
        with patch.object(h,'imported_rows',return_value=(store,rows)):
            h.prepare(self.root/'handoff.json',h.sha((self.root/'handoff.json').read_bytes()))
            with self.assertRaises(FileExistsError):h.prepare(self.root/'handoff.json',h.sha((self.root/'handoff.json').read_bytes()))
    def test_partial_capture_roster_rejected(self):
        slots=json.loads((ROOT/'URP/experiments/online_bin_packing/eoh_evolution_runner_v1/generation_slots.json').read_bytes())['records']
        roster=[{'slot_id':s['id'],'order':s['order'],'claim_id':h.digest(s['id'])} for s in slots if s['phase']==2]
        h.write_once(self.inputs/'roster.json',{'records':roster})
        store=SimpleNamespace(_records={x['claim_id']:{} for x in roster[:59]})
        with patch.object(h,'open_store',return_value=store),self.assertRaisesRegex(ValueError,'all sixty'):h.imported_rows({},m)
    def test_phase2_numeric_limits_once_only(self):
        root=self.root/'reservations';root.mkdir();ids=['TEST'+str(i) for i in range(61)];r=h.Reservations(root,ids,60,300)
        for cid in ids[:60]:
            r.worker(cpu_seconds=1,worker_role='admission',execution_id=cid+'/admission')
            for i in range(5):
                r.worker(cpu_seconds=60,worker_role='instance',execution_id=cid+'/instance/'+str(i))
                r.supervisor(cpu_seconds=60,execution_id=cid+'/instance/'+str(i))
        self.assertEqual(sum(x['cpu_seconds'] for x in r.entries()),36060)
        self.assertEqual(sum(x['shared_wall_seconds'] for x in r.entries()),27300)
        with self.assertRaisesRegex(ValueError,'cap'):r.worker(cpu_seconds=1,worker_role='admission',execution_id=ids[60]+'/admission')
        with self.assertRaisesRegex(ValueError,'consumed'):r.worker(cpu_seconds=1,worker_role='admission',execution_id=ids[0]+'/admission')
    def test_empty_approval_blocks_before_runtime(self):
        with patch.object(h,'read',side_effect=[h.seal({'source_input_plan_sha256':'4'*64}),{},h.seal({})]),patch.object(h,'modules',side_effect=AssertionError('runtime')):
            with self.assertRaisesRegex(ValueError,'activation'):h.run('TEST','TEST','TEST')

if __name__=='__main__':unittest.main(verbosity=2)
