"""Approved read-only LENGTH check; no scores, candidate parsing, or parent draws.

Read only the fixed textual-extraction rows and frozen phase1 input prompts.
The complete available candidate superset, including IID, bounds any eventual
P1 selection. The largest escaped public object repeated five times is an upper
bound, not a recommendation or a real parent selection.
"""
import ast
from copy import deepcopy
import json
from pathlib import Path
import sys
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parent))
import phase2_draft as d
from dependencies import core
from safe_scheduler import public_contract
from prompts import PUBLIC_RESPONSE_RULE, MAX_BASE_PROMPT_BYTES, MAX_PROMPT_BYTES


def check():
    d.verify_static_pins()
    path = d.ROOT/'urp132_20261005_b01_phase1_numerical_state/rows.json'
    raw = path.read_bytes(); rows = json.loads(raw)
    d.require(len(rows) == 60 and [x['order'] for x in rows] == list(range(13,73)), 'fixed P1 rows')
    candidates = [{k: deepcopy(row['candidate'][k]) for k in ('description','code','pair_sha256')}
                  | {'id': row['slot_id']} for row in rows if row['candidate'] is not None]
    roster = json.loads((d.PREP/'inputs/roster.json').read_bytes())['records']
    p0 = {}
    marker = '\n\nOrdered parent draws (duplicates deliberately preserved):\n'
    for record in roster:
        if record['arm'] == 'EOH_TC':
            pack = json.loads((d.PREP/'inputs/packs'/(record['slot_id']+'.json')).read_bytes())
            d.require(d.digest({k:v for k,v in pack.items() if k!='sha256'}) == record['request_sha256'], 'frozen prompt pack')
            parents = json.loads(pack['prompt'].split(marker,1)[1].split('\n\n'+public_contract(),1)[0])
            for parent in parents:
                d.require(set(parent) == {'id','description','code','pair_sha256'}, 'public P0 only')
                d.require(parent['id'] not in p0 or p0[parent['id']] == parent, 'immutable public P0')
                p0[parent['id']] = parent
    candidates += list(p0.values())
    d.require(candidates and len(p0) == 1, 'known retained P0 public population')
    for candidate in candidates:
        d.require(d.digest({k:candidate[k] for k in ('description','code')}) == candidate['pair_sha256'], 'public pair identity')
    # The surrounding messages JSON escapes the already serialized parent JSON.
    # Rank by that exact nested-string contribution, not raw source length alone.
    def escaped_bytes(candidate):
        return len(d.canon(d.canon(candidate).decode())) - 2
    longest = max(candidates, key=escaped_bytes)
    route = json.loads((d.PREP/'inputs/freeze.json').read_bytes())['input_route_evidence_sha256']
    measurements = []
    with patch('ast.parse', side_effect=AssertionError('no AST')), \
         patch('subprocess.Popen', side_effect=AssertionError('no process')), \
         patch('socket.socket', side_effect=AssertionError('no network')):
        for op in ('e1','e2','m1','m2','m3'):
            count = 5 if op in ('e1','e2') else 1
            messages = core.assemble_prompt(op, [longest]*count)
            messages[-1]['content'] += '\n\n'+public_contract()
            with_rule = deepcopy(messages); with_rule[-1]['content'] += '\n\n'+PUBLIC_RESPONSE_RULE
            base_bytes = len(d.canon(with_rule))
            projected = d.build_prompt(messages, [], delivery={'method':'stdin','verified_support':True,
                'support_evidence_sha256':route,'max_payload_bytes':MAX_PROMPT_BYTES})
            measurements.append({'operator':op,'repeated_parent_count':count,
                'conservative_serialized_base_bytes':base_bytes,
                'base_limit_bytes':MAX_BASE_PROMPT_BYTES,'base_headroom_bytes':MAX_BASE_PROMPT_BYTES-base_bytes,
                'user_payload_bytes':len(projected['cli_user_prompt'].encode()),
                'total_limit_bytes':MAX_PROMPT_BYTES,'existing_builder_passed':True})
    d.require(path.read_bytes() == raw, 'textual extraction rows changed during read')
    return {'schema':'phase2-readonly-parent-length-upper-bound-v1','scope':'length/interface only; not parent selection',
        'row_file_sha256':d.sha(raw),'rows_read':60,'P1_textually_extracted_candidates':sum(row['candidate'] is not None for row in rows),
        'retained_P0_public_candidates':len(p0),'candidate_superset_count':len(candidates),
        'includes_IID_for_conservative_superset':True,'max_description_utf8_bytes':max(len(c['description'].encode()) for c in candidates),
        'max_source_utf8_bytes':max(len(c['code'].encode()) for c in candidates),
        'max_single_public_object_nested_escaped_bytes':escaped_bytes(longest),
        'largest_escaped_public_object_repeated_is_not_real_parent_selection':True,
        'measurements':measurements,'current_material_cannot_exceed_base_limit_for_any_five_parent_draw':True,
        'partial_scores_results_bundles_read':False,'real_parents_drawn':False,'model_requests':0,
        'candidate_execution':0,'original_P1_rows_unchanged':True,
        'limit_relaxation_needed_for_current_material':False,
        'final_audited_P1_prompt_identity_preflight_still_required':True}

if __name__ == '__main__':
    result = check()
    with (d.HERE/'LENGTH_PREFLIGHT.json').open('x') as stream:
        json.dump(result,stream,indent=2);stream.write('\n')
    print(json.dumps(result,indent=2))
