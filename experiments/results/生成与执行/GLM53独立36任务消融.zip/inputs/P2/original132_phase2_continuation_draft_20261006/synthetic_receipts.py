"""Handwritten fabricated receipts only; no backend/runtime/candidate execution."""
import ast
import base64
from copy import deepcopy
import unittest
from unittest.mock import patch

from bridge import ReceiptBridge, LIMITS, EVENTS, TIMING_SCOPE, bound, canonical, digest, extract, sha
from capture_v2 import CaptureImporter, MockSessionStore, CONFIG_EVIDENCE
from prompts import build_prompt, PromptBoundFailure
from profiles import document, configured, PRODUCTION


def sealed(value):
    value = deepcopy(value); value.pop('sha256', None)
    return dict(value, sha256=digest(value))


def fake(mode='handwritten_registry_test', prose=False, freeze_extra=None, *, slot_id='TEST_SLOT', phase=2, run_id='urp132_20261005_b01_phase2', raw_override=None, request_sha256=None, panel_n=3):
    profile = document(PRODUCTION) if mode == 'registered_source_study' else None
    policy = {'schema': 'bounded-arithmetic-finite-final-v1', 'events': list(EVENTS),
              'per_placement_callback_limit': 64, 'per_instance_callback_limit': 320000,
              'intermediate_nonfinite': 'allowed_program_managed', 'repairs': False,
              'applies_to': 'both experimental arms identically'}
    freeze_fields = {'mode': mode, 'policy_sha256': digest(policy), 'runtime_sha256': digest('FAKE_RUNTIME'),
                     'intake_manifest_sha256': digest('FAKE_INTAKE'), 'isolation_profile_sha256': digest('FAKE_ISOLATION'),
                     'checker_sha256': digest('FAKE_CHECKER')}
    if profile:
        freeze_fields.update(mode='official_cli', evaluation_mode='registered_source_study',
                             resource_profile_sha256=digest(profile))
    if freeze_extra is not None: freeze_fields.update(deepcopy(freeze_extra))
    freeze = sealed(freeze_fields)
    raw = '{Public mock strategy.}\n```python\ndef score(item, bins):\n    return bins\n```'
    if raw_override is not None: raw=raw_override
    if prose: raw = 'Surrounding prose.\n' + raw + '\nMore prose.'
    capture = {'raw': raw, 'status': 'ok', 'capture_complete': True, 'tool_calls': [], 'finish_reason': 'stop'}
    candidate, raw_hash, metrics = extract(capture)
    claim = sealed({'schema': 'wave-external-claim-v1', 'run_id': run_id, 'slot_id': slot_id, 'phase': phase,
                    'claim_id': digest(['wave-claim-v1', run_id, slot_id]), 'request_sha256': request_sha256 or digest('FAKE_REQUEST'),
                    'freeze_sha256': freeze['sha256']})
    origin = 'handwritten_fixture' if mode == 'handwritten_registry_test' else 'model_response'
    entry = {'slot_id': slot_id, 'claim_id': claim['claim_id'], 'claim_sha256': claim['sha256'],
             'raw_response_sha256': raw_hash, 'source_sha256': candidate['code_sha256'],
             'description_sha256': candidate['description_sha256'], 'pair_sha256': candidate['pair_sha256']}
    registry_fields = {'schema': 'frozen-candidate-wave-registry-v1', 'batch_id': run_id, 'wave_id': run_id+'-phase2',
                       'phase': phase, 'policy_sha256': digest(policy), 'runtime_freeze_sha256': freeze['runtime_sha256'],
                       'source_origin': origin, 'slots': [entry]}
    if profile: registry_fields['resource_profile_sha256'] = digest(profile)
    registry = sealed(registry_fields)
    deployment_fields = {'schema': 'candidate-deployment-freeze-v1', 'mode': mode, 'source_origin': origin,
                         'registry_sha256': registry['sha256'], 'wave_freeze_sha256': freeze['sha256'],
                         'batch_id': run_id, 'wave_id': run_id+'-phase2', 'phase': phase,
                         'runtime_freeze_sha256': freeze['runtime_sha256'], 'policy_sha256': digest(policy),
                         'isolation_profile_sha256': freeze['isolation_profile_sha256'], 'checker_sha256': freeze['checker_sha256'],
                         'intake_manifest_sha256': freeze['intake_manifest_sha256'], 'worker_cpu_seconds': 1,
                         'worker_as_bytes': 536870912, 'max_source_bytes': 16384, 'max_steps': 5000, 'max_instances': 5}
    if profile:
        for key in ('worker_cpu_seconds', 'worker_as_bytes', 'max_source_bytes', 'max_steps', 'max_instances'):
            deployment_fields.pop(key)
        deployment_fields.update(schema='candidate-deployment-freeze-v2', resource_profile_sha256=digest(profile))
    deployment = sealed(deployment_fields)
    security = {'Threads': 1, 'NoNewPrivs': 1, 'Seccomp': 2, 'Seccomp_filters': 2}
    bridge = ReceiptBridge(registry, registry_sha256=registry['sha256'], run_id=run_id, phase=phase, wave_id=run_id+'-phase2',
        policy=policy, policy_sha256=digest(policy), runtime_freeze_sha256=freeze['runtime_sha256'],
        manifest_sha256=digest('FAKE_MANIFEST'), api_names=['api'+str(i) for i in range(46)], expected_security=security,
        expected_limits=LIMITS, handwritten_source_hashes=[candidate['code_sha256']], deployment_document=deployment,
        deployment_sha256=deployment['sha256'])
    _, binding, _ = bridge.expected_binding(capture, claim, freeze)
    canonical_text = 'FAKE_CHILD_AST_TEXT_NEVER_PARSED'
    identity = {'method': 'bounded-child-ast-dump-v1', 'canonical_text': canonical_text,
                'code_identity': sha(canonical_text.encode()), 'joint_identity': digest([candidate['description'], canonical_text])}
    inner_admission = {'admitted': True, 'source_sha256': candidate['code_sha256'], 'manifest_sha256': digest('FAKE_MANIFEST'),
        'node_count': 8, 'ast_depth': 4, 'apis': [], 'canonical_text_sha256': identity['code_identity'],
        'binding_sha256': digest(binding), 'open_denials': 0}
    def worker(steps, role='admission', index=None):
        limits = deepcopy(LIMITS)
        if profile: limits['cpu_seconds'] = [profile['roles'][role]['cpu_seconds']]*2
        value = {'registry_binding': deepcopy(binding), 'source_id': slot_id, 'source_sha256': candidate['code_sha256'],
            'source_sent': True, 'source_after_host_gate': True, 'dependency_freeze_sha256': freeze['runtime_sha256'],
            'security': deepcopy(security), 'host_observed_limits': limits, 'pid': 12345,
            'private_pipes': ['pipe:[101]', 'pipe:[102]', 'pipe:[103]'], 'mapped_dependencies_sha256': digest('FAKE_MAPS'),
            'reaped': True, 'returncode': 0, 'cleanup_error': None, 'steps': steps, 'score_call_cpu_ns': 1000 if steps else 0,
            'score_timing_scope': TIMING_SCOPE, 'wall_seconds': .1, 'startup_seconds': .01, 'cleanup_seconds': .01,
            'cpu_seconds': .01, 'peak_rss_kib': 100, 'input_bytes': 100, 'output_bytes': 100, 'write_calls': 2,
            'read_calls': 2, 'short_writes': 0, 'stderr_bytes': 0, 'input_sha256': digest('FAKE_INPUT_TRANSCRIPT'),
            'output_sha256': digest('FAKE_OUTPUT_TRANSCRIPT'), 'admission': deepcopy(inner_admission),
            'arithmetic_events': {event: 0 for event in EVENTS}, 'max_placement_event_count': 0,
            'arithmetic_steps_checked': steps, 'numerical_failure': None}
        if profile:
            value.update(resource_profile_sha256=digest(profile),resource_profile_id=profile['profile_id'],worker_role=role,
                configured_limits=configured(profile,role),execution_id=claim['claim_id']+'/admission' if index is None else claim['claim_id']+'/instance/'+str(index),
                instance_index=index,terminal_reason=None,resource_limit=None,cpu_cap_evidence=None,
                parent_kill_attempted=False,parent_kill_sent=False,assignment_complete=role=='instance',
                instance_started=100.0,total_wall_deadline=100.0+profile['roles'][role]['wall_seconds'],
                absolute_deadline=100.0+profile['roles'][role]['wall_seconds']-2,instance_wall_seconds=.1,
                active_completed_at=100.05 if role=='instance' else None)
            value['admission'].update(resource_profile_sha256=digest(profile),worker_role=role)
        return value
    admission = dict(inner_admission)
    admission.pop('canonical_text_sha256')
    admission.update(bounded_child_verified=True, runtime_sha256=freeze['runtime_sha256'],
        isolation_profile_sha256=freeze['isolation_profile_sha256'], cleanup_status='passed', registry_binding=deepcopy(binding),
        policy_sha256=digest(policy), deployment_sha256=deployment['sha256'], source_origin=origin, worker=worker(0))
    if profile: admission.update(resource_profile_sha256=digest(profile),worker_role='admission')
    count = 1 if mode == 'handwritten_registry_test' else 5
    panel = {'kind': mode, 'instances': [{'instance_index': i, 'input_sha256': digest(['FAKE_INSTANCE', i]),
                                       'n': panel_n, 'L1': 2, 'capacity': 100} for i in range(count)]}
    scores = []
    for item in panel['instances']:
        i = item['instance_index']
        evidence = {'slot_id': slot_id, 'claim_id': claim['claim_id'], 'execution_id': claim['claim_id']+'/instance/'+str(i),
            'intake_manifest_sha256': freeze['intake_manifest_sha256'], 'runtime_sha256': freeze['runtime_sha256'],
            'isolation_profile_sha256': freeze['isolation_profile_sha256'], 'checker_sha256': freeze['checker_sha256'],
            'policy_sha256': digest(policy), 'registry_binding': deepcopy(binding), 'deployment_sha256': deployment['sha256'],
            'source_origin': origin, 'no_cross_slot_cache': True, 'cleanup_status': 'passed', 'checker_status': 'passed',
            'assignment_sha256': digest(['FAKE_ASSIGNMENT', i]), 'worker': worker(panel_n,'instance',i)}
        if profile:
            evidence.update(resource_profile_sha256=digest(profile),worker_role='instance',instance_index=i,assignment_complete=True)
            supervisor_limits=deepcopy(LIMITS);supervisor_limits['cpu_seconds']=[profile['supervisor_cpu_seconds']]*2
            supervisor_limits['open_files']=[32,32]
            evidence['supervisor']={'pid':54321,'role':'instance_supervisor','resource_profile_sha256':digest(profile),
                'runtime_freeze_sha256':freeze['runtime_sha256'],'execution_id':evidence['execution_id'],'instance_index':i,
                'host_observed_limits':supervisor_limits,'configured_wall_seconds':profile['roles']['instance']['wall_seconds'],
                'cleanup_within_wall':True,'shared_instance_started':100.0,'shared_absolute_deadline':100.0+profile['roles']['instance']['wall_seconds'],
                'reaped':True,'returncode':0,'wait4_cpu_seconds':.03,'self_cpu_at_emit':.015,
                'actual_supervisor_cpu_seconds':.02,'child_cpu_seconds':.01,'wall_seconds':.15,'peak_rss_kib':100,
                'input_bytes':100,'output_bytes':100,'stderr_bytes':0,'cleanup_error':None,
                'cpu_accounting_scope':'Linux wait4 inclusive descendants; self_at_emit excludes final serialization tail'}
        scores.append({'kind': mode, 'instance_index': i, 'input_sha256': item['input_sha256'],
            'code_sha256': candidate['code_sha256'], 'outcome': 'ok', 'used_bins': 2, 'L1': 2, 'evidence': evidence})
    bundle_fields = {'schema': 'wave-bounded-verification-v1', 'mode': mode, 'claim_id': claim['claim_id'], 'slot_id': slot_id,
        'source_sha256': candidate['code_sha256'], 'description_sha256': candidate['description_sha256'],
        'freeze_sha256': freeze['sha256'], 'intake_manifest_sha256': freeze['intake_manifest_sha256'],
        'policy_sha256': digest(policy), 'arithmetic_policy': deepcopy(policy), 'registry_binding': deepcopy(binding),
        'deployment_sha256': deployment['sha256'], 'source_origin': origin, 'admission': admission,
        'identity': identity, 'scores': scores}
    if profile:bundle_fields.update(resource_profile_sha256=digest(profile),resource_profile=deepcopy(profile))
    bundle = sealed(bundle_fields)
    return bridge, bundle, capture, claim, panel, freeze

