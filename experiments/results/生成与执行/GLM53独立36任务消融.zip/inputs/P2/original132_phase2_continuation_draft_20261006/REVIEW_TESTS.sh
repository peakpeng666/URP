#!/bin/sh
# Trusted synthetic and dummy-process tests only; no production inputs or grants.
set -eu
cd "$(dirname "$0")/.."
for suite in draft producer_bridge integration numerical meter binding audit_terminal meter_guard; do
  python -I -B "original132_phase2_continuation_draft_20261006/test_phase2_${suite}.py"
done
