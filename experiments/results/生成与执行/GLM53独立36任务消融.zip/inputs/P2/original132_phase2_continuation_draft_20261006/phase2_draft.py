"""Pure, mock-only g2 input projection. No live CLI, model, scoring or state I/O.

A real implementation must first bind independently audited P1 evidence and replay
it through the original phase1 scheduler continuation. This draft intentionally
rejects a production runner: tests cannot be mistaken for real request preparation.
"""
from collections import Counter
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
PREP = ROOT / 'original132_phase1_preparation_20261005'
WAVE = ROOT / 'URP/experiments/online_bin_packing/eoh_evolution_wave_v1'
sys.path[:0] = [str(WAVE), str(PREP / 'receiver')]
from safe_scheduler import SafeRunner
from common import digest, require
from prompts import build_prompt


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canon(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False).encode()


def verify_static_pins():
    pins = json.loads((HERE / 'SOURCE_PINS.json').read_bytes())['files']
    for name, expected in pins.items():
        path = ROOT / name
        require(path.is_file() and not path.is_symlink() and sha(path.read_bytes()) == expected,
                'static source drift: ' + name)
    return len(pins)


def assert_p1_boundary(runner):
    ledger = runner.export()
    require(runner._halt_reason is None and runner._phase == 2, 'clean terminal P1 required')
    require(len(ledger['generation']) == 132 and len(ledger['scores']) == 780, 'frozen denominator')
    require(len(ledger['snapshots']) == 4, 'P0 and P1 only')
    require(sum(s['logical_requests_observed'] for s in ledger['generation']) == 72,
            'exact original 72 observations')
    require(all(s['state'] in ('eligible', 'generation_failed', 'evaluation_failed')
                for s in ledger['generation'] if s['phase'] < 2), 'incomplete prior generation')
    require(all(s['state'] == 'planned' and s['logical_requests_observed'] == 0
                for s in ledger['generation'] if s['phase'] == 2), 'phase2 must be untouched')
    require(Counter(s['arm'] for s in ledger['generation'] if s['phase'] == 2)
            == {'EOH_TC': 30, 'IID_TC': 30}, 'two frozen arms')
    require({c['id'] for c in ledger['archive']} <=
            {s['id'] for s in ledger['generation'] if s['phase'] < 2}, 'foreign lineage')
    return ledger


def project_mock_phase2(runner):
    """Reserve g2 in an isolated in-memory copy, return synthetic input artifacts.

    No object supplied by the caller is mutated. This does not claim, dispatch,
    receive, approve or activate anything. Mock mode is mandatory.
    """
    require(runner._panel['kind'] == 'mock', 'production preparation disabled in this draft')
    before = assert_p1_boundary(runner)
    work = deepcopy(runner)
    freeze = json.loads((PREP / 'inputs/freeze.json').read_bytes())
    route = freeze['input_route_evidence_sha256']
    frozen_snapshots = deepcopy(work._snapshots)
    population, p1 = work._population(1)
    require(population, 'empty P1: original scheduler skips EOH, no replacement or equal-budget claim')
    drafts = []
    for order in range(73, 133):
        request = work.next_request()
        require(request is not None and request['phase'] == 2 and request['order'] == order,
                'exact original phase2 schedule')
        parents = [work._archive[p] for p in request['parents']]
        count = 0 if request['arm'] == 'IID_TC' else 5 if request['operator'] in ('e1', 'e2') else 1
        require(len(parents) == count, 'parent multiplicity')
        if parents:
            require(request['parent_snapshot_sha256'] == p1['sha256'] and
                    set(request['parents']) <= set(p1['survivor_ids']), 'frozen P1 only')
        marker = '\n\nOrdered parent draws (duplicates deliberately preserved):\n'
        content = request['prompt'][-1]['content']
        require(content.count(marker) == bool(parents), 'one parent block')
        if parents:
            public = json.loads(content.split(marker, 1)[1].split('\n\n' + work.public_contract, 1)[0])
            require(public == [{k: p[k] for k in ('id', 'description', 'code', 'pair_sha256')}
                               for p in parents], 'only public fields, duplicates intact')
        # Exact accepted phase1 method: public parents already embedded by SafeRunner.
        # Passing parents again would duplicate them and change the scientific prompt.
        prompt = build_prompt(request['prompt'], [], delivery={
            'method': 'stdin', 'verified_support': True,
            'support_evidence_sha256': route, 'max_payload_bytes': 1048576})
        drafts.append({'TEST_ONLY': True, 'not_a_production_pack': True,
                       'request': request, 'prompt': prompt,
                       'configuration': deepcopy(freeze['configuration'])})
    require(work.next_request() is None and work._snapshots == frozen_snapshots,
            'wait for all g2 observations; no P2 yet')
    after = work.export()
    require(after['reserved'] == {'logical_requests': 132, 'completion_tokens': 4224000,
                                  'generation_wall_seconds': 118800}, 'original whole-study generation caps')
    require(before == runner.export(), 'caller changed')
    return drafts, after


def validate_mock_terminal_index(index, roster):
    """Roster-bound shape test only; cannot authenticate or receive real captures."""
    require(index.get('mode') == 'fixture_only', 'production reception disabled in this draft')
    require(len(roster) == len(index.get('rows', [])) == 60, 'all sixty terminal rows required')
    require([r['order'] for r in roster] == list(range(73, 133)), 'original orders')
    for row, expected in zip(index['rows'], roster):
        require(row.get('state') == 'terminal' and row.get('phase') == 2, 'terminal phase2 only')
        require(row.get('slot_id') == expected['id'] and row.get('arm') == expected['arm']
                and row.get('order') == expected['order'], 'exact roster identity and order')
    return {'TEST_ONLY': True, 'terminals': 60, 'admissions': 0, 'scores': 0}


def require_final_bindings(contract):
    """Negative readiness guard only. A populated JSON is not authentication."""
    require(contract['status'] in ('ENGINEERING_DRAFT_UNBOUND_DISABLED','IMPLEMENTED_MOCK_TESTED_UNBOUND_DISABLED'), 'unexpected draft status')
    missing = [key for key, value in contract['parent_evidence_required'].items() if value is None]
    require(not missing, 'unbound final P1 evidence: ' + ', '.join(missing))
    raise ValueError('production activation not implemented; independent review is still required')
