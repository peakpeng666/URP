# R2 独立审阅修复

仍为未绑定、未批准、disabled工程包，不是实验。原R1 ZIP保留用于基线复现。

1. meter启动合同改为文档、main和child守卫一致：绝对规范脚本/绝对grant，精确 -I -B 及 --grant / --grant-sha256 顺序。main在读grant、设CPU、写attempt/claim前拒绝错误形式，避免烧掉once-only位置。
2. 完整candidate archive由已验projected candidate深复制重建，独立派生slot、parents、lineages、eligibility、fitness/gap及duplicate字段；全部历史archive逐项保留。拒绝额外、丢失或重复候选。
3. 全部score视图从原冻结模板和已验score observations重建；generation及score完整ID序列/唯一性固定，含controls/heldout，防止保留总数的替换攻击；每个slot的logical_requests_observed必须精确整数1，不能以2/0抵消。
4. 每个snapshot全字段及seal重建，summary.winners必须精确等于P2快照首名并指向真实eligible档案，完整scheduler摘要也从已验ledger视图重建。
5. 新负例包含篡改winner、g2 code/description、历史code、伪造joint_identity改变真实winner、重复/丢失历史generation或score、删snapshot member字段及伪造lineage，均重新密封ledger/report后仍须拒绝。
6. 合法普通失败继续可终审：无代码块、admission rejection和实例resource_limit不产生补抽、不伪造fitness；mixed full audit测试通过。

没有读真实P1结果，没有选真实父代，没有启用P2。P1终态证据、资源决定、source连接及执行批准仍必须后填。
