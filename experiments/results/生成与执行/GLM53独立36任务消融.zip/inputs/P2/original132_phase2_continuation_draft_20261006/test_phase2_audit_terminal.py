"""Full terminal auditor over 60 synthetic receipts; never production evidence."""
import copy,json,pathlib,sys,tempfile,unittest
from types import SimpleNamespace
from fractions import Fraction
from unittest.mock import patch
HERE=pathlib.Path(__file__).resolve().parent;ROOT=HERE.parent
sys.path.insert(0,str(HERE))
from test_phase2_integration import initial_runner,make_value,export_value,ExplicitTrustedSessionDouble,receiver,producer,extract,h,scheduler,audit,digest,P1


class TerminalAuditTests(unittest.TestCase):
    def test_all_generation_failures_keep_only_exact_historical_archive(self):
        runner=initial_runner();old=runner.export();observations=[]
        requests=[]
        for _ in range(60):requests.append(runner.next_request())
        for request in requests:
            obs={'slot_id':request['id'],'capture':{'status':'TRUSTED_TEST_FAILURE','raw':'','usage':None},
                'extraction':{'unique':False,'strict':False,'reason':'TRUSTED_TEST_FAILURE','candidate':None},
                'scores':[],'admission':None,'integrity_error':None}
            runner.observe_verified(obs['slot_id'],obs['capture'],obs['extraction'],obs['scores'],obs['admission']);observations.append(obs)
        ledger=runner.export();result=audit.verified_archive_and_scores(ledger,old,observations)
        self.assertEqual(result['g2_candidates'],0);self.assertEqual(ledger['archive'],old['archive'])
        audit.independent_selection(ledger,2);audit.terminal_boundary(ledger,old)
    def test_incomplete_numeric_panels_remain_archived_but_ineligible(self):
        runner=initial_runner();old=runner.export();observations=[]
        route=json.loads((P1/'inputs/freeze.json').read_bytes())['input_route_evidence_sha256']
        requests=scheduler.phase2_requests(runner,route)
        for request,prompt in requests:
            value=make_value(request,prompt);capture={'raw':value['raw'].decode(),'status':'ok','capture_complete':True,'finish_reason':'stop','tool_calls':[]}
            verified=value['bridge'].scheduler_observation(value['bundle'],capture,value['claim'],value['panel'],value['freeze'])
            scores=copy.deepcopy(verified['scores']);scores[-1]['outcome']='numeric_failure';scores[-1]['used_bins']=None
            obs={'slot_id':request['id'],'capture':capture,'extraction':{'unique':True,'strict':True,'reason':None,'candidate':verified['candidate']},
                'scores':scores,'admission':verified['admission'],'integrity_error':None}
            runner.observe_verified(obs['slot_id'],obs['capture'],obs['extraction'],obs['scores'],obs['admission']);observations.append(obs)
        ledger=runner.export();result=audit.verified_archive_and_scores(ledger,old,observations)
        self.assertEqual(result['g2_candidates'],60)
        self.assertTrue(all(not c['eligible'] and c['fitness'] is None for c in ledger['archive'] if c['phase']==2))
        audit.independent_selection(ledger,2);audit.terminal_boundary(ledger,old)
    def test_complete_receipts_and_reject_missing_or_partial(self):
        self.run_full_fixture(mixed_failures=False)
    def test_mixed_ordinary_failures_pass_complete_receipt_audit(self):
        self.run_full_fixture(mixed_failures=True)
    def run_full_fixture(self,*,mixed_failures):
        original=initial_runner(n=5000);old=original.export()
        route=json.loads((P1/'inputs/freeze.json').read_bytes())['input_route_evidence_sha256']
        requests=scheduler.phase2_requests(copy.deepcopy(original),route)
        with tempfile.TemporaryDirectory(prefix='phase2-audit-TEST-ONLY-') as tmp:
            root=pathlib.Path(tmp);state=root/'state';state.mkdir();inputs=root/'inputs';inputs.mkdir();(root/'history').mkdir()
            for folder in ('attempts','results','bundles','runtime_journal','reservations'):(state/folder).mkdir()
            values=[make_value(req,prompt,n=5000) for req,prompt in requests]
            if mixed_failures:
                # One malformed generation, one explicit static admission rejection,
                # and one verified instance CPU-limit failure; all remain terminal.
                values[0]['raw']=b'TRUSTED SYNTHETIC NO COMPLETE CODE BLOCK'
                rejected=copy.deepcopy(values[1]['bundle']);rejected.pop('sha256')
                admission=rejected['admission'];admission.update(admitted=False,kind='static')
                admission['worker']['admission']={k:admission[k] for k in ('admitted','kind','binding_sha256','open_denials','resource_profile_sha256','worker_role')}
                rejected.update(identity=None,scores=[]);values[1]['bundle']=h.seal(rejected)
                failed=copy.deepcopy(values[2]['bundle']);failed.pop('sha256');failed['scores']=failed['scores'][:1]
                score=failed['scores'][0];score.update(outcome='resource_limit',used_bins=None)
                ev=score['evidence'];ev.update(checker_status='not_run',assignment_sha256=None,assignment_complete=False)
                worker=ev['worker'];worker.update(admission=None,steps=0,arithmetic_steps_checked=0,score_call_cpu_ns=0,
                    active_completed_at=None,assignment_complete=False,returncode=-9,cpu_seconds=60.01,wall_seconds=70,instance_wall_seconds=70)
                reason={'kind':'worker_cpu_limit','scope':'worker_cpu','limit_seconds':60,'observed_seconds':60.01,
                    'trigger':'wait4_sigkill_cpu_near_cap','stage':'admission','signal':9,'returncode':-9}
                worker.update(resource_limit=dict(reason),terminal_reason=dict(reason),
                    cpu_cap_evidence={'typed_eof':True,'natural_wait4_reap':True,'near_cap_tolerance_seconds':{'below':.05,'above':1.0},'os_confirmed_cause':False})
                ev['supervisor'].update(wait4_cpu_seconds=60.03,child_cpu_seconds=60.01,wall_seconds=70.1)
                values[2]['bundle']=h.seal(failed)
            source={'sha256':digest('TEST_SOURCE_PLAN'),'source_and_input_files':{}}
            plan_body={'source_input_plan_sha256':source['sha256'],'registry_sha256':digest('TEST_REGISTRY'),'deployment_sha256':digest('TEST_DEPLOYMENT'),
                'max_admissions':60,'max_candidate_packs':300,'candidate_source_count':60,'parent_boundary_sha256':'1'*64,'parent_review_acceptance_sha256':'3'*64,'resource_accounting_binding_sha256':'2'*64}
            rows=[];store=ExplicitTrustedSessionDouble();index=producer.initial_index(h.RUN,values[0]['freeze']['sha256'],['EOH_TC','IID_TC'],'official_cli')
            for value,(request,_) in zip(values,requests):
                index=export_value(value,index)
                capture=receiver.CaptureImporter(store).import_capture(value['export'],h.sha(value['export']),value['claim'],value['freeze'],value['invocation'])
                reason=None
                try:c,raw_sha,metrics=extract(capture)
                except ValueError as exc:
                    c=None;raw_sha=h.sha(capture['raw'].encode());metrics={'unique':False,'strict':False};reason='generation_format:'+str(exc)
                rows.append({'slot_id':request['id'],'arm':request['arm'],'order':request['order'],'claim':value['claim'],'pack':value['pack'],
                    'capture':capture,'candidate':c,'raw_response_sha256':raw_sha,'format_metrics':metrics,'reason':reason})
            source_count=sum(row['candidate'] is not None for row in rows)
            plan_body.update(candidate_source_count=source_count,max_admissions=source_count,max_candidate_packs=5*source_count)
            panel=values[0]['panel'];freeze=values[0]['freeze']
            for name,obj in [('handoff.json',{'TEST_ONLY':True}),('rows.json',rows),('panel.json',panel)]:
                h.write_once(state/name,obj);plan_body[{'handoff.json':'handoff_file_sha256','rows.json':'rows_file_sha256','panel.json':'panel_file_sha256'}[name]]=h.sha((state/name).read_bytes())
            plan=h.seal(plan_body);h.write_once(state/'plan.json',plan);h.write_once(inputs/'freeze.json',freeze)
            h.write_once(root/'history/scheduler-ledger.json',old)
            package=h.seal({'TEST_ONLY':True});h.write_once(root/'PACKAGE_MANIFEST.json',package)
            h.write_once(root/'BINDINGS.json',h.seal({k:plan[k] for k in ('parent_boundary_sha256','parent_review_acceptance_sha256','resource_accounting_binding_sha256')}))
            trust=ROOT/'phase0_numerical_harness_20261005/RECEIPT_TRUST_REVIEW_CANDIDATE.json'
            approval={'schema':'phase2-execution-approval-v1','explicit_execution_grant':True,'enabled':True,'parent_review_accepted':True,
                'package_manifest_sha256':package['sha256'],'plan_sha256':plan['sha256'],'run_id':h.RUN,'controls':0,'heldout':0,
                'receipt_trust_path':str(trust),'receipt_trust_file_sha256':h.sha(trust.read_bytes()),**{k:plan[k] for k in ('registry_sha256','deployment_sha256','max_admissions','max_candidate_packs','parent_boundary_sha256','parent_review_acceptance_sha256','resource_accounting_binding_sha256')}}
            h.write_once(root/'approval.json',approval)
            reservations=h.Reservations(state/'reservations',[r['claim']['claim_id'] for r in rows],60,300)
            observations=[];bundles=[];by_claim={v['claim']['claim_id']:v for v in values}
            class BridgeRouterDouble:
                def scheduler_observation(self,bundle,capture,claim,panel,freeze):
                    return by_claim[claim['claim_id']]['bridge'].scheduler_observation(bundle,capture,claim,panel,freeze)
            bridge=BridgeRouterDouble()
            with patch.object(h,'STATE',state),patch('ast.parse',side_effect=AssertionError('candidate AST')),patch('subprocess.Popen',side_effect=AssertionError('process launch')):
                for row,value in zip(rows,values):
                    class BackendDouble:
                        def bind_capture(self,*a):pass
                        def verify(self,*a):
                            cid=row['claim']['claim_id'];bundle=copy.deepcopy(value['bundle'])
                            reservations.worker(cpu_seconds=1,worker_role='admission',execution_id=cid+'/admission')
                            entries=[('verify',bundle)]
                            for score in bundle['scores']:
                                eid=cid+'/instance/'+str(score['instance_index']);reservations.worker(cpu_seconds=60,worker_role='instance',execution_id=eid);reservations.supervisor(cpu_seconds=60,execution_id=eid);entries.append((eid,score))
                            for eid,receipt in entries:
                                token=h.digest(['registry-execution-v1',h.RUN,row['slot_id'],eid])
                                h.write_once(state/'runtime_journal'/(token+'.claim.json'),h.seal({'binding':bundle['registry_binding'],'execution_id':eid}))
                                h.write_once(state/'runtime_journal'/(token+'.result.json'),h.seal({'receipt':receipt}))
                            return bundle
                    saved,bundle=h.get_or_execute(row,plan,BackendDouble(),bridge,panel,freeze,None)
                    observations.append(saved['observation'])
                    if bundle is not None:bundles.append(bundle)
            packet={'schema':'phase2-scheduler-packet-v1','mode':'production_verified_receipts','rows':rows,'observations':observations}
            with patch.object(scheduler,'restore_phase1',side_effect=lambda:copy.deepcopy(original)):
                ledger=scheduler.reconstruct(packet)
            h.write_once(state/'scheduler-ledger.json',ledger)
            report=h.seal({'status':'phase2_complete','halt_reason':None,'plan_sha256':plan['sha256'],
                'generation_denominator':60,'authenticated_generation_terminals':60,'scheduler_ledger_path':str(state/'scheduler-ledger.json'),
                'scheduler_ledger_sha256':ledger['sha256'],'control_packs':0,'heldout_packs':0,'parent_rescores':0,
                'usage':h.account(bundles,reservations.entries()),'snapshots':ledger['snapshots'],'phase2_activated':True,'heldout_activated':False,
                'parent_boundary_sha256':'1'*64,'parent_review_acceptance_sha256':'3'*64,'resource_accounting_binding_sha256':'2'*64})
            h.write_once(state/'report.json',report)
            store_identity=SimpleNamespace(index_identity={'TEST_ONLY':True})
            patches=[patch.object(h,'HERE',root),patch.object(h,'STATE',state),patch.object(h,'INPUTS',inputs),
                patch.object(h,'verify_sources',return_value=source),patch.object(h,'modules',return_value={}),
                patch.object(h,'imported_rows',return_value=(store_identity,rows)),patch.object(h,'design_panel',return_value=(panel,[])),
                patch.object(h,'receipt_bridge',return_value=bridge)]
            for p in patches:p.start()
            try:
                args=(h,2,state/'report.json',h.sha((state/'report.json').read_bytes()),root/'approval.json',h.sha((root/'approval.json').read_bytes()))
                result=audit.audit(*args)
                expected_admissions,expected_packs=(59,286) if mixed_failures else (60,300)
                self.assertEqual(result['status'],'passed');self.assertEqual(result['admissions'],expected_admissions);self.assertEqual(result['design_packs'],expected_packs)
                self.assertEqual(result['worker_receipts'],expected_admissions+expected_packs);self.assertEqual(result['supervisor_receipts'],expected_packs)
                self.assertEqual(result['runtime_claim_result_pairs'],expected_admissions+expected_packs);self.assertTrue(result['frozen_state_unchanged'])
                self.assertTrue(result['archive_verification']['complete_archive_verified']);self.assertTrue(result['winner_summary_verified'])
                if mixed_failures:
                    archive={c['id']:c for c in ledger['archive']}
                    self.assertIsNotNone(rows[1]['candidate']);self.assertIsNone(observations[1]['extraction']['candidate'])
                    self.assertNotIn(rows[0]['slot_id'],archive);self.assertNotIn(rows[1]['slot_id'],archive)
                    self.assertFalse(archive[rows[2]['slot_id']]['eligible']);self.assertIsNone(archive[rows[2]['slot_id']]['fitness'])
                    self.assertEqual(result['archive_verification']['g2_candidates'],58)
                    return
                def reseal(value):
                    value=copy.deepcopy(value);value.pop('sha256',None);return h.seal(value)
                def forged_identity_changes_winner(value):
                    previous=value['summary']['winners']['EOH_TC'];archive={c['id']:c for c in value['archive']}
                    target=archive[previous];self.assertEqual(target['phase'],2)
                    prior=next(s for s in value['snapshots'] if s['phase']==1 and s['arm']=='EOH_TC')
                    snap=next(s for s in value['snapshots'] if s['phase']==2 and s['arm']=='EOH_TC')
                    target['joint_identity']=archive[prior['survivor_ids'][0]]['joint_identity']
                    pool=[archive[sid] for sid in prior['survivor_ids']]+[c for c in archive.values() if c['phase']==2 and c['arm']=='EOH_TC' and c['eligible']]
                    unique={};duplicates={}
                    for candidate in sorted(pool,key=lambda c:c['order']):
                        identity=candidate['joint_identity']
                        if identity in unique:duplicates[candidate['id']]=unique[identity]['id']
                        else:unique[identity]=candidate
                    ranked=sorted(unique.values(),key=lambda c:(-Fraction(c['fitness']['numerator'],c['fitness']['denominator']),c['tie_priority'],c['id']))
                    survivors=ranked[:6];ids=[c['id'] for c in survivors]
                    snap.update(survivor_ids=ids,members=[{k:c[k] for k in ('id','pair_sha256','code_identity','joint_identity','fitness','report_gap','tie_priority','initial_lineages')} for c in survivors],
                        decisions={'eligible_ids':[c['id'] for c in sorted(pool,key=lambda c:c['order'])],'ranked_ids':[c['id'] for c in ranked],
                          'duplicates':duplicates,'reasons':{c['id']:('exact_joint_duplicate' if c['id'] in duplicates else 'retained' if c['id'] in ids else 'outside_capacity') for c in pool}},
                        population_size=len(ids),underfilled=len(ids)<6,distinct_code_count=len({c['code_identity'] for c in survivors}),
                        active_initial_lineages=sorted({lineage for c in survivors for lineage in c['initial_lineages']}))
                    snap.update(reseal(snap));value['summary']['winners']['EOH_TC']=ids[0]
                    seen={}
                    for candidate in sorted(value['archive'],key=lambda c:c['order']):
                        key=(candidate['arm'],candidate['joint_identity']);candidate['joint_duplicate_of']=seen.get(key);seen.setdefault(key,candidate['id'])
                    self.assertNotEqual(previous,ids[0])
                def wrong_source(value):
                    candidate=next(c for c in value['archive'] if c['phase']==2)
                    candidate.update(code='SYNTHETIC_TAMPERED_SOURCE',description='SYNTHETIC_TAMPERED_DESCRIPTION')
                def wrong_historical_source(value):
                    next(c for c in value['archive'] if c['phase']==1)['code']='SYNTHETIC_CHANGED_P1_SOURCE'
                def duplicate_generation(value):
                    positions=[i for i,g in enumerate(value['generation']) if g['phase']==0 and g['arm']=='IID_TC']
                    value['generation'][positions[0]]=copy.deepcopy(value['generation'][positions[1]])
                def duplicate_score(value):value['scores'][0]=copy.deepcopy(value['scores'][1])
                def balanced_but_wrong_logical_counts(value):
                    slots=[slot for slot in value['generation'] if slot['phase']==2]
                    slots[0]['logical_requests_observed']=2;slots[1]['logical_requests_observed']=0
                def stripped_snapshot_member(value):
                    snap=next(x for x in value['snapshots'] if x['phase']==2 and x['arm']=='EOH_TC')
                    snap['members'][0].pop('code_identity');snap.update(reseal(snap))
                def forged_derived_lineage(value):
                    next(c for c in value['archive'] if c['phase']==2)['initial_lineages']=['SYNTHETIC_FOREIGN_LINEAGE']
                mutations=[('winner_summary',lambda v:v['summary'].update(winners={'EOH_TC':'NONEXISTENT_TAMPERED_WINNER','IID_TC':None})),
                    ('source_description',wrong_source),('historical_source',wrong_historical_source),('identity_changes_winner',forged_identity_changes_winner),
                    ('duplicate_generation',duplicate_generation),('duplicate_score',duplicate_score),('snapshot_member',stripped_snapshot_member),
                    ('derived_lineage',forged_derived_lineage),('logical_counts_2_0',balanced_but_wrong_logical_counts),
                    ('summary_aggregate',lambda value:value['summary'].update(generation_counts_by_arm={'EOH_TC':67,'IID_TC':65}))]
                for label,mutate in mutations:
                    with self.subTest(resealed_tamper=label):
                        changed=copy.deepcopy(ledger);mutate(changed);changed=reseal(changed)
                        ledger_path=state/('tampered-'+label+'-ledger.json');h.write_once(ledger_path,changed)
                        changed_report=copy.deepcopy(report);changed_report.update(scheduler_ledger_path=str(ledger_path),scheduler_ledger_sha256=changed['sha256'],snapshots=changed['snapshots'])
                        changed_report=reseal(changed_report);report_path=state/('tampered-'+label+'-report.json');h.write_once(report_path,changed_report)
                        with self.assertRaises(ValueError):
                            audit.audit(h,2,report_path,h.sha(report_path.read_bytes()),root/'approval.json',h.sha((root/'approval.json').read_bytes()))
                journal=next((state/'runtime_journal').glob('*.result.json'));retained=journal.read_bytes();journal.unlink()
                with self.assertRaises(ValueError):audit.audit(*args)
                journal.write_bytes(retained)
                bad=dict(report);bad.pop('sha256');bad['status']='halted';h.write_once(state/'partial-report.json',h.seal(bad))
                with self.assertRaisesRegex(ValueError,'clean terminal'):
                    audit.audit(h,2,state/'partial-report.json',h.sha((state/'partial-report.json').read_bytes()),root/'approval.json',h.sha((root/'approval.json').read_bytes()))
            finally:
                for p in reversed(patches):p.stop()

if __name__=='__main__':unittest.main(verbosity=2)
