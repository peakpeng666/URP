"""Read-only validation of an authenticated final handoff, never execution."""
import argparse
from collections import Counter
import importlib.util,json,pathlib
from unittest.mock import patch
ROOT=pathlib.Path(__file__).resolve().parent.parent

def main():
    p=argparse.ArgumentParser();p.add_argument('--handoff',required=True);p.add_argument('--handoff-sha256',required=True);a=p.parse_args()
    spec=importlib.util.spec_from_file_location('h_phase2_preflight',ROOT/'original132_phase2_continuation_draft_20261006/phase2_numerical.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
    with patch('ast.parse',side_effect=AssertionError('host candidate AST forbidden')),patch('subprocess.Popen',side_effect=AssertionError('process launch forbidden')):
        source=h.verify_sources();handoff=h.read(a.handoff,a.handoff_sha256);m=h.modules();store,rows=h.imported_rows(handoff,m);panel,_=h.design_panel()
        result={'schema':'phase2-authenticated-intake-preflight-v1','status':'passed_not_prepared_or_executed','handoff_file_sha256':a.handoff_sha256,'source_plan_sha256':source['sha256'],'authenticated_index_identity':store.index_identity,'assigned_generation_denominator':60,'terminal_captures':len(rows),'arms':dict(Counter(r['arm'] for r in rows)),'generation_status':dict(Counter(r['capture']['status'] for r in rows)),'format_failure_reasons':dict(Counter(r['reason'] for r in rows if r['candidate'] is None)),'textually_extractable':sum(r['candidate'] is not None for r in rows),'max_admissions':sum(r['candidate'] is not None for r in rows),'max_candidate_packs':5*sum(r['candidate'] is not None for r in rows),'design_panel':panel,'production_state_exists':h.STATE.exists(),'execution_enabled':False,'candidate_AST_calls':0,'admissions':0,'score_calls':0,'model_calls':0}
    print(json.dumps(result,sort_keys=True,indent=2))
if __name__=='__main__':main()
