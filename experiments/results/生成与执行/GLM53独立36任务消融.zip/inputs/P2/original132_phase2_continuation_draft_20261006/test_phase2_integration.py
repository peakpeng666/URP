"""60-slot trusted synthetic integration, NEVER external or execution evidence.

Exporter/importer/receipt validators and numeric once-only orchestration are real;
all captures, session trust, bounded-worker receipts and numeric backend are explicit
in-memory test doubles. No AST, CLI, worker, socket, or candidate code executes.
"""
import ast,copy,importlib.util,json,pathlib,sys,tempfile,unittest
from types import SimpleNamespace
from unittest.mock import patch
HERE=pathlib.Path(__file__).resolve().parent;ROOT=HERE.parent;P1=ROOT/'original132_phase1_preparation_20261005'
sys.path.insert(0,str(HERE))
import phase2_scheduler as scheduler
import phase2_binding as binding
import phase2_audit_terminal as audit
from common import digest
from safe_scheduler import SafeRunner
from bridge import extract

def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
sys.path.insert(0,str(P1/'exporter/src'))
import protocol_v2 as producer
import driver_v2 as driver
receiver=module('phase2_test_receiver',P1/'receiver/capture_v2.py')
sys.modules['capture_v2']=receiver
fx=module('phase2_test_receipts',HERE/'synthetic_receipts.py')
h=module('phase2_test_numerical',HERE/'phase2_numerical.py')


def initial_runner(n=3):
    panel={'kind':'externally_verified','instances':[{'instance_index':i,'L1':2,'n':n,'capacity':100,'input_sha256':digest(['FAKE_INSTANCE',i])} for i in range(5)]}
    r=SafeRunner(panel)
    for phase in (0,1):
        requests=[]
        while True:
            req=r.next_request()
            if req is None:break
            requests.append(req)
        for req in requests:
            text='TRUSTED OPAQUE PARENT '+req['id'];description='SYNTHETIC '+req['id']
            candidate={'description':description,'code':text,'description_sha256':h.sha(description.encode()),'code_sha256':h.sha(text.encode()),
                'pair_sha256':digest({'description':description,'code':text}),'code_identity':digest(['FIXTURE_CODE',req['id']]),
                'joint_identity':digest(['FIXTURE_JOINT',req['id']]),'description_consistency':'TEST_ONLY'}
            scores=[{'kind':'externally_verified','instance_index':i,'input_sha256':x['input_sha256'],'code_sha256':candidate['code_sha256'],
                'L1':2,'used_bins':3 if phase==0 else 2,'outcome':'ok','evidence':{'runtime_sha256':'1'*64,'isolation_profile_sha256':'2'*64,
                    'checker_sha256':'3'*64,'cleanup_status':'passed','checker_status':'passed','assignment_sha256':'4'*64}} for i,x in enumerate(panel['instances'])]
            r.observe_verified(req['id'],{'status':'TRUSTED_SYNTHETIC','raw':'','usage':None},
                {'unique':True,'strict':True,'reason':None,'candidate':candidate},scores,{'TEST_ONLY':True})
    return r


class ExplicitTrustedSessionDouble:
    """Models the authenticated store trust boundary inside tests only.

    It is NOT a CommittedSessionStore and cannot pass h.open_store's type check.
    """
    durable_external=True
    def __init__(self):self.store=receiver.MockSessionStore()
    def claim(self,*a,**kw):return self.store.claim(*a,**kw)


def make_value(request,prompt,n=3):
    prior=json.loads((P1/'inputs/freeze.json').read_bytes())
    extra={k:copy.deepcopy(prior[k]) for k in ('configuration','configured_settings','config_file_sha256','exporter_source_sha256','cli_exporter_source_sha256')}
    extra.update(cli_binary_sha256=digest('TRUSTED_NO_BINARY_FIXTURE'),cli_version='TRUSTED_SYNTHETIC_NO_CLI')
    raw='{Synthetic public strategy '+request['id']+'.}\n```python\ndef score(item, bins):\n    return bins\n```'
    values=fx.fake('registered_source_study',freeze_extra=extra,slot_id=request['id'],raw_override=raw,panel_n=n)
    freeze=values[-1]
    pack=h.seal({'schema':'wave-prompt-pack-v1','run_id':h.RUN,'slot_id':request['id'],'phase':2,
        'arm':request['arm'],'operator':request['operator'],'order':request['order'],'parents':request['parents'],
        'parent_snapshot_sha256':request['parent_snapshot_sha256'],'prompt':prompt['cli_user_prompt'],
        'prompt_sha256':h.sha(prompt['cli_user_prompt'].encode()),'serialized_messages_sha256':prompt['prompt_sha256'],
        'configuration':extra['configuration'],'configuration_sha256':digest(extra['configuration']),'freeze_sha256':freeze['sha256']})
    bridge,bundle,_,claim,panel,freeze=fx.fake('registered_source_study',freeze_extra=extra,slot_id=request['id'],raw_override=raw,request_sha256=pack['sha256'],panel_n=n)
    config=(P1/'inputs/config.raw.json').read_bytes()
    return {'pack':pack,'claim':claim,'panel':panel,'freeze':freeze,'bridge':bridge,'bundle':bundle,'raw':raw.encode(),'config':config}


def export_value(value,index):
    claim=value['claim'];config=value['config'];index,reservation=producer.claim_index(index,claim,value['pack']['arm'],h.sha(config))
    session='ses_SYNTHETIC_'+value['pack']['slot_id']
    evidence=producer.canon({'schema':'opencode-session-evidence-v2','claim_id':claim['claim_id'],'invocation_id':reservation['invocation_id'],
        'config_file_sha256':h.sha(config),'resume_requested':False,'state_was_empty':True,'process_started_unix_ms':1000,'process_terminal_unix_ms':2000,
        'observations':[{'event_type':'text','session_id':session,'part_session_id':session,'message_id':'msg_SYNTHETIC'}],
        'creation':{'source':'official_local_session_row','id':session,'parent_id':None,'time_created':1500}})
    terminal={'status':'ok','process_terminal':True,'capture_complete':True,'finish_reason':'stop','tool_calls':[],
        'usage':{'input_tokens':None,'output_tokens':None,'reasoning_tokens':None,'wall_seconds':.1},'physical_http_attempts':None,'exit_code':0}
    freeze=value['freeze'];inv=producer.make_invocation_receipt(claim,reservation,config,evidence)
    packet=producer.build_export(claim,reservation,config,freeze['configuration'],
        {'binary_sha256':freeze['cli_binary_sha256'],'exporter_source_sha256':freeze['exporter_source_sha256'],'version':freeze['cli_version'],'mode':freeze['mode']},evidence,value['raw'],terminal)
    producer.verify_export(packet,h.sha(packet),claim,reservation,freeze,inv,config,evidence)
    receipt={'library_file_id':'libfile_SYNTHETIC_ARCHIVE','file_id':'file_SYNTHETIC_ARCHIVE','current_version_number':1,'write_result_confirmed':True,'remote_bytes_verified':False}
    ref={'artifact_sha256':h.sha(packet),'session_evidence_sha256':h.sha(evidence),'invocation_receipt_sha256':h.sha(producer.canon(inv)),
        'config_file_sha256':h.sha(config),'actual_session_id':session,'status':'ok','capture_complete':True,'archive_file_id':receipt['file_id'],'archive_version':1}
    index=producer.terminal_index(index,claim['claim_id'],ref,receipt)
    value.update(export=packet,reservation=reservation,invocation=inv,evidence=evidence)
    return index


class IntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.guards=[patch('ast.parse',side_effect=AssertionError('candidate AST forbidden')),
                    patch('subprocess.Popen',side_effect=AssertionError('process launch forbidden')),
                    patch('socket.socket',side_effect=AssertionError('network forbidden'))]
        for g in cls.guards:g.start()
    @classmethod
    def tearDownClass(cls):
        for g in reversed(cls.guards):g.stop()

    def test_01_full_sixty_export_import_numeric_mock_P2(self):
        original=initial_runner();before=original.export();projection=copy.deepcopy(original)
        route=json.loads((P1/'inputs/freeze.json').read_bytes())['input_route_evidence_sha256']
        requests=scheduler.phase2_requests(projection,route)
        rows=[];observations=[];additions={};store=ExplicitTrustedSessionDouble();index=None;backend_calls=[]
        with tempfile.TemporaryDirectory(prefix='phase2-full-chain-') as tmp:
            state=pathlib.Path(tmp)/'state';state.mkdir()
            for folder in ('attempts','results','bundles','runtime_journal'):(state/folder).mkdir()
            for request,prompt in requests:
                value=make_value(request,prompt)
                if index is None:index=producer.initial_index(h.RUN,value['freeze']['sha256'],['EOH_TC','IID_TC'],'official_cli')
                index=export_value(value,index)
                capture=receiver.CaptureImporter(store).import_capture(value['export'],h.sha(value['export']),value['claim'],value['freeze'],value['invocation'])
                c,raw_sha,metrics=extract(capture)
                row={'slot_id':request['id'],'arm':request['arm'],'order':request['order'],'claim':value['claim'],'pack':value['pack'],
                     'capture':capture,'candidate':c,'raw_response_sha256':raw_sha,'format_metrics':metrics,'reason':None}
                class BackendDouble:
                    def bind_capture(self,*a):pass
                    def verify(self,*a):backend_calls.append(request['id']);return copy.deepcopy(value['bundle'])
                with patch.object(h,'STATE',state):
                    saved,bundle=h.get_or_execute(row,{'sha256':digest('SYNTHETIC_PLAN')},BackendDouble(),value['bridge'],value['panel'],value['freeze'],None)
                    again,_=h.get_or_execute(row,{'sha256':digest('SYNTHETIC_PLAN')},None,value['bridge'],value['panel'],value['freeze'],None)
                self.assertEqual(saved,again)
                rows.append(row);observations.append(saved['observation'])
                for name,raw in {'raw.txt':value['raw'],'export.json':value['export'],'session-evidence.json':value['evidence'],
                    'invocation-receipt.json':producer.canon(value['invocation']),'config.raw.json':value['config'],
                    'metadata.json':producer.canon({'TEST_ONLY':True,'candidate_executions':0})}.items():
                    additions[f'slots/{request["id"]}/{name}']=raw
            self.assertEqual(len(backend_calls),60)
            archive=pathlib.Path(tmp)/'synthetic-wave.zip';receipt=driver.build_wave_archive(archive,2,additions=additions)
            self.assertEqual(receipt['slot_count'],60);files=driver.read_archive(archive,receipt['local_blob_sha256'])
            self.assertEqual(len(files),362);producer.verify_index(index)
            packet={'schema':'phase2-scheduler-packet-v1','mode':'production_verified_receipts','rows':rows,'observations':observations}
            with patch.object(scheduler,'restore_phase1',side_effect=lambda:copy.deepcopy(original)):
                ledger=scheduler.reconstruct(packet)
            self.assertEqual(len(ledger['snapshots']),6);self.assertEqual(len(audit.independent_selection(ledger,2)),6)
            lineage=audit.terminal_boundary(ledger,before)
            self.assertTrue(lineage['at_least_one_retained_g1_parent_used'])
            self.assertTrue(ledger['summary']['terminal']);self.assertEqual(ledger['reserved']['logical_requests'],132)
            self.assertEqual(len(ledger['scores']),780);self.assertEqual(original.export(),before)
            for kind in ('rows','observations'):
                bad=copy.deepcopy(packet);bad[kind].pop()
                with patch.object(scheduler,'restore_phase1',side_effect=lambda:copy.deepcopy(original)),self.assertRaisesRegex(ValueError,'sixty'):
                    scheduler.reconstruct(bad)
            bad=copy.deepcopy(packet);bad['rows'][0]['pack']['prompt']+=' TAMPER'
            with patch.object(scheduler,'restore_phase1',side_effect=lambda:copy.deepcopy(original)),self.assertRaisesRegex(ValueError,'prompt'):
                scheduler.reconstruct(bad)
            bad=copy.deepcopy(ledger);bad['snapshots'][0]['population_size']+=1
            with self.assertRaises(ValueError):audit.terminal_boundary(bad,before)
            bad=copy.deepcopy(ledger);bad['snapshots'][-1]['survivor_ids']=[]
            with self.assertRaises(ValueError):audit.independent_selection(bad,2)
            bad=copy.deepcopy(ledger)
            target=next(x for x in bad['generation'] if x['phase']==2 and x['arm']=='EOH_TC')
            target['parent_draw']['tickets'][0]+=1
            with self.assertRaisesRegex(ValueError,'independent exact'):audit.terminal_boundary(bad,before)
            bad=copy.deepcopy(ledger)
            target=next(x for x in bad['scores'] if x.get('source_generation_slot') is None)
            target['reason']='TAMPERED_CONTROL_OR_HELDOUT'
            with self.assertRaisesRegex(ValueError,'controls/heldout'):audit.terminal_boundary(bad,before)
            # Removal of one retained archive member is detectable by frozen reader.
            read_wave=module('phase2_test_session_store',P1/'adapter/session_store.py').read_wave
            missing=copy.deepcopy(additions);missing.pop(next(iter(missing)))
            broken=pathlib.Path(tmp)/'missing.zip';broken_receipt=driver.build_wave_archive(broken,2,additions=missing)
            with self.assertRaisesRegex(ValueError,'missing_members'):read_wave(broken,broken_receipt['local_blob_sha256'],producer)

    def test_02_capture_tamper_and_untrusted_store_rejected(self):
        r=initial_runner();route=json.loads((P1/'inputs/freeze.json').read_bytes())['input_route_evidence_sha256']
        request,prompt=scheduler.phase2_requests(r,route)[0];v=make_value(request,prompt)
        export_value(v,producer.initial_index(h.RUN,v['freeze']['sha256'],['EOH_TC','IID_TC'],'official_cli'))
        with self.assertRaisesRegex(ValueError,'production_requires_durable'):
            receiver.CaptureImporter(receiver.MockSessionStore()).import_capture(v['export'],h.sha(v['export']),v['claim'],v['freeze'],v['invocation'])
        with self.assertRaisesRegex(ValueError,'independent_receiver_hash'):
            receiver.CaptureImporter(ExplicitTrustedSessionDouble()).import_capture(v['export']+b' ',h.sha(v['export']),v['claim'],v['freeze'],v['invocation'])
        capture=receiver.CaptureImporter(ExplicitTrustedSessionDouble()).import_capture(v['export'],h.sha(v['export']),v['claim'],v['freeze'],v['invocation'])
        bad=copy.deepcopy(v['bundle']);bad['scores'][0]['used_bins']+=1
        with self.assertRaises(ValueError):v['bridge'].scheduler_observation(bad,capture,v['claim'],v['panel'],v['freeze'])

    def test_03_unknown_numeric_attempt_never_replayed(self):
        with tempfile.TemporaryDirectory(prefix='phase2-unknown-') as tmp:
            state=pathlib.Path(tmp)
            for folder in ('attempts','results','bundles','runtime_journal'):(state/folder).mkdir()
            row={'slot_id':'TEST','claim':{'claim_id':'TEST','sha256':'TEST'},'candidate':{'TEST_ONLY':True}}
            h.write_once(state/'attempts/TEST.json',h.seal({'plan_sha256':'TEST'}))
            class Forbidden:
                def __getattr__(self,*a):raise AssertionError('backend invoked after unknown')
            with patch.object(h,'STATE',state),self.assertRaisesRegex(ValueError,'UNKNOWN'):
                h.get_or_execute(row,{'sha256':'TEST'},Forbidden(),None,None,None,None)

    def test_04_unbound_production_and_accounting_fail_closed(self):
        with self.assertRaisesRegex(ValueError,'unbound production'):binding.load_bound_package(HERE)
        proposal=json.loads((HERE/'RESOURCE_ACCOUNTING_PROPOSAL.json').read_bytes())
        with self.assertRaisesRegex(ValueError,'separate reviewed'):binding.validate_accounting(proposal)
        with self.assertRaises((ValueError,FileNotFoundError)):h.verify_sources()

if __name__=='__main__':unittest.main(verbosity=2)
