"""Parent-pinned final-P1 and forward-accounting bindings. No execution authority."""
import hashlib,json,math
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
RUN='urp132_20261005_b01_phase2'
SCIENTIFIC='urp132_20261005_b01'
P1_FREEZE='1e3e0bf30681e13c80747bdc406a05b34190623bab43467b91be6a0aea7ac45e'
P1_LINEAGE='ad18683fa4afe67c8b1722be6058c94a1bd4bb5fecf83490a03851b6452b1c76'

def need(ok,reason):
    if not ok:raise ValueError(reason)
def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def seal(x):return dict(x,sha256=sha(canon(x)))
def verify(x):
    need(type(x) is dict and x.get('sha256')==sha(canon({k:v for k,v in x.items() if k!='sha256'})),'seal mismatch');return x
def is_hash(x):return isinstance(x,str) and len(x)==64 and all(c in '0123456789abcdef' for c in x)
def read(path,expected=None):
    p=Path(path);need(p.is_file() and not p.is_symlink() and p.stat().st_size<=64*1024*1024,'bounded file required')
    raw=p.read_bytes();need(expected is None or is_hash(expected) and sha(raw)==expected,'file pin mismatch');return json.loads(raw)
def reference(ref):
    need(type(ref) is dict and set(ref)=={'path','file_sha256'},'exact reference shape')
    p=Path(ref['path']);need(p.is_absolute() and p.resolve()==p and not any(x.is_symlink() for x in [p,*p.parents]),'canonical reference')
    return read(p,ref['file_sha256'])

def validate_final_p1(boundary):
    need(boundary['schema']=='phase2-parent-boundary-v1' and boundary['status']=='FINAL_P1_INDEPENDENTLY_ACCEPTED'
         and boundary['scientific_run_id']==SCIENTIFIC,'accepted final P1 boundary required')
    need(boundary['phase1_freeze_sha256']==P1_FREEZE and boundary['phase1_lineage_sha256']==P1_LINEAGE,'original P1 lineage')
    refs=boundary['evidence'];need(set(refs)=={'report','packet','ledger','audit','reviewer','generation_readback','producer_fence'},'complete final P1 evidence')
    ev={name:reference(ref) for name,ref in refs.items()}
    report,packet,ledger,audit,reviewer=[ev[k] for k in ('report','packet','ledger','audit','reviewer')]
    verify(report);verify(ledger)
    need(report['schema']=='phase1-numerical-report-v1' and report['status']=='phase1_complete'
         and report['halt_reason'] is None and report['generation_denominator']==report['authenticated_generation_terminals']==60,'clean P1 report')
    need(packet['schema']=='phase1-scheduler-packet-v1' and packet['mode']=='production_verified_receipts'
         and len(packet['rows'])==len(packet['observations'])==60 and packet['plan_sha256']==report['plan_sha256'],'complete bound P1 packet')
    need(report['scheduler_ledger_sha256']==ledger['sha256'] and report['snapshots']==ledger['snapshots'],'report ledger binding')
    need(audit['schema']=='phase1-independent-terminal-audit-v1' and audit['status']=='passed'
         and audit['phase']==1 and audit['report_file_sha256']==refs['report']['file_sha256']
         and audit['report_sha256']==report['sha256'] and audit['ledger_sha256']==ledger['sha256']
         and audit['plan_sha256']==report['plan_sha256'],'accepted independent P1 audit')
    need(audit['unknown_claims']==0 and audit['all_reaped_cleanly'] is True and audit['frozen_state_unchanged'] is True
         and audit['generation_denominator']==60 and audit['controls']==audit['heldout']==audit['parent_rescores']==0,'audit integrity/scope')
    need(reviewer['schema']=='phase1-terminal-parent-review-v1' and reviewer['accepted'] is True
         and reviewer['scientific_run_id']==SCIENTIFIC
         and reviewer['evidence_file_sha256']=={k:refs[k]['file_sha256'] for k in ('report','packet','ledger','audit')},'independent reviewer exact acceptance')
    need(len(ledger['generation'])==132 and len(ledger['scores'])==780 and len(ledger['snapshots'])==4,'P1 denominator/snapshots')
    need(sum(x['logical_requests_observed'] for x in ledger['generation'])==72
         and ledger['summary']['halt_reason'] is None,'P1 request boundary')
    need(all(x['state']=='planned' and x['logical_requests_observed']==0 for x in ledger['generation'] if x['phase']==2),'g2 untouched')
    need([x['pack']['order'] for x in packet['rows']]==list(range(13,73))
         and [x['slot_id'] for x in packet['rows']]==[x['slot_id'] for x in packet['observations']],'original P1 roster')
    need(ev['generation_readback']['schema']=='authenticated-library-readback-v1'
         and ev['producer_fence']['schema']=='producer-fence-status-v1'
         and ev['producer_fence']['external_write_pending'] is False
         and ev['producer_fence']['unresolved_dispatch_fences']==0,'real final generation receipts')
    need(ev['producer_fence']['run_id']=='urp132_20261005_b01_phase1'
         and ev['producer_fence']['freeze_sha256']==P1_FREEZE,'final producer phase1 scope')
    fence=ev['producer_fence'];proof=ev['generation_readback']
    need(fence.get('observation_kind')=='actual_producer_status_tool_stdout'
         and proof.get('evidence_kind')=='actual_authenticated_tool_results','real producer/readback evidence')
    import importlib.util
    spec=importlib.util.spec_from_file_location('_phase2_parent_session_store',ROOT/'original132_phase1_preparation_20261005/adapter/session_store.py')
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    before=mod.CommittedSessionStore._read_result(proof['read_before'])
    after=mod.CommittedSessionStore._read_result(proof['read_after'])
    need(all(before[k]==after[k] for k in ('library_file_id','file_id','version_id','content')),'final P1 readback identity changed')
    content='\n'.join(before['content']).encode();index=verify(json.loads(content))
    identity={'library_file_id':before['library_file_id'],'file_id':before['file_id'],
              'version':int(before['version_id']),'sha256':sha(content)}
    need(identity==audit['authenticated_index_identity'],'audited final P1 head required')
    need(identity=={'library_file_id':fence['library_file_id'],'file_id':fence['file_id'],
                    'version':fence['current_version_number'],'sha256':fence['index_blob_sha256']},'fence must bind audited final head')
    need(canon(index)==content and index['run_id']=='urp132_20261005_b01_phase1'
         and index['freeze_sha256']==P1_FREEZE and len(index['rows'])==60
         and all(r['state']=='terminal' and r['phase']==1 for r in index['rows'])
         and [r['claim']['slot_id'] for r in index['rows']]==[r['slot_id'] for r in packet['rows']], 'complete final generation head')
    # Existing independent audit already reimports the pinned archive/receipts.
    return ev

def validate_accounting(value):
    need(value['schema']=='phase2-resource-accounting-binding-v1' and value['operational_run_id']==RUN
         and value['scientific_run_id']==SCIENTIFIC and value['parent_review_accepted'] is True
         and value['status']=='APPROVED_FORWARD_ACCOUNTING_ONLY','separate reviewed phase2 accounting binding required')
    need(value['numeric_execution_granted'] is False and value['generation_execution_granted'] is False,'accounting is not execution approval')
    need(value['historical_original_preparation_and_orchestration_balance'] is None
         and value['historical_original_shared_cap_compliance']=='not authenticated; not claimed','do not invent/reset historical balance')
    need(value['mode']=='forward_only' and is_hash(value['independent_review_file_sha256']),'reviewed forward-only allowance')
    need(value['science_limits']=={'generation_slots':132,'score_rows':780,'phase2_generation':60,'phase2_admissions':60,'phase2_packs':300},'original science limits')
    # Explicit prospective coordination allowances, NEVER a recovered old balance.
    need(value['prepare_forward_cpu_upper_bound']==120 and value['prepare_inclusive_wall_seconds']==120
         and value['run_forward_cpu_upper_bound']==900 and value['run_inclusive_wall_formula']=='5*A+90*P+900','fixed prospective allowances')
    need(is_hash(value['phase2_meter_file_sha256']) and is_hash(value['prior_phase1_accounting_receipt_file_sha256'])
         and is_hash(value['prior_numeric_reservations_audit_file_sha256']),'meter and prior actual accounting evidence required')
    coordination=value.get('input_binding_and_generation_bookkeeping_accounting',{})
    need(coordination.get('status')=='PARENT_APPROVED_FORWARD_OR_VERIFIED_BALANCE'
         and is_hash(coordination.get('allowance_or_verified_balance_file_sha256')),
         'input-binding/generation bookkeeping accounting remains unbound')
    return value

def load_bound_package(root=HERE):
    root=Path(root);binding=verify(read(root/'BINDINGS.json'))
    need(binding['status']=='FINAL_P1_BOUND_DISABLED' and binding['execution_enabled'] is False
         and binding['run_id']==RUN and is_hash(binding['generation_freeze_sha256']),'unbound production package')
    boundary=read(root/'history/parent-boundary.json',binding['parent_boundary_sha256'])
    ev=validate_final_p1(boundary)
    accounting=read(root/'history/resource-accounting-binding.json',binding['resource_accounting_binding_sha256'])
    validate_accounting(accounting)
    need(binding['parent_review_acceptance_sha256']==boundary['evidence']['reviewer']['file_sha256'],'reviewer binding')
    need(read(root/'history/scheduler-ledger.json')==ev['ledger'] and read(root/'history/scheduler-input.json')==ev['packet'],'bound historical copies')
    return binding,ev


def require_forward_meter(action,root=HERE):
    """Trusted coordination guard: numeric mutation must be a direct metered child.

    This is an additional fail-closed orchestration check, not a new sandbox or
    authentication provider. Candidate isolation remains the unchanged runtime.
    """
    import os,resource,sys
    root=Path(root);need(action in ('prepare','run'),'meter action scope')
    binding,_=load_bound_package(root)
    accounting=read(root/'history/resource-accounting-binding.json',binding['resource_accounting_binding_sha256'])
    meter=(root/'phase2_meter.py').resolve()
    need(sha(meter.read_bytes())==accounting['phase2_meter_file_sha256'],'approved forward meter source')
    parent=os.getppid();cmd=Path(f'/proc/{parent}/cmdline').read_bytes().split(b'\0');cmd=[x.decode() for x in cmd if x]
    need(len(cmd)==8 and cmd[1:4]==['-I','-B',str(meter)]
         and cmd[4]=='--grant' and cmd[6]=='--grant-sha256','numeric entry requires exact direct phase2 meter parent')
    exe=Path(f'/proc/{parent}/exe').resolve();need(exe==Path(sys.executable).resolve(),'meter interpreter identity')
    grant=read(Path(cmd[5]),cmd[7])
    need(grant['schema']=='phase2-forward-coordination-grant-v1' and grant['action']==action
         and grant['enabled'] is True and grant['parent_review_accepted'] is True
         and grant['meter_sha256']==accounting['phase2_meter_file_sha256']
         and grant['resource_accounting_binding_sha256']==binding['resource_accounting_binding_sha256'],'exact active forward grant')
    log=ROOT/'original132_phase2_forward_accounting_20261006'
    attempt=read(log/(action+'.attempt.json'));claim=read(log/(action+'.claim.json'))
    need(attempt['grant_file_sha256']==claim['grant_file_sha256']==cmd[7]
         and attempt['meter_sha256']==claim['meter_sha256']==grant['meter_sha256']
         and claim['action']==action and claim['retry_authorized'] is False
         and not (log/(action+'.receipt.json')).exists(),'fresh once-only forward accounting claim')
    own=[x.decode() for x in Path('/proc/self/cmdline').read_bytes().split(b'\0') if x]
    need(any(command[3:]==own for _,command in claim['commands']),'numeric command not in exact forward claim')
    limit=40 if action=='prepare' else 300
    need(resource.getrlimit(resource.RLIMIT_CPU)==(limit,limit),'exact inherited trusted CPU limit')
    return {'action':action,'grant_file_sha256':cmd[7],'meter_file_sha256':grant['meter_sha256'],'parent_pid':parent}
