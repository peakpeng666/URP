"""Trusted synthetic data only. No candidate parser, worker, CLI or network."""
from collections import Counter
from copy import deepcopy
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
import sys
import unittest
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parent))
import phase2_draft as d


def candidate(slot, *, source=None, duplicate=None):
    tag = duplicate or slot['id']
    description = 'TRUSTED SYNTHETIC DESCRIPTION ' + tag
    code = source or 'OPAQUE UNPARSABLE SYNTHETIC SOURCE ' + tag
    return {'description': description, 'code': code,
            'description_sha256': d.sha(description.encode()), 'code_sha256': d.sha(code.encode()),
            'pair_sha256': d.digest({'description': description, 'code': code}),
            'joint_identity': d.digest(['SYNTHETIC_JOINT', tag]),
            'code_identity': d.digest(['SYNTHETIC_CODE', tag]),
            'description_consistency': 'TEST_ONLY'}


def observe(runner, request, *, failed=False, source=None):
    capture = {'status': 'TEST_ONLY', 'raw': 'TRUSTED SYNTHETIC', 'usage': None}
    if failed:
        runner.observe_verified(request['id'], capture,
            {'unique': False, 'strict': False, 'reason': 'SYNTHETIC_FAILURE', 'candidate': None}, [], None)
        return
    c = candidate(request, source=source)
    # Later synthetic offspring outrank initial fixtures; this is never real evidence.
    bins = 8 if request['phase'] == 0 else 6 + request['order'] % 2
    scores = [{'kind': 'mock', 'instance_index': i, 'input_sha256': manifest['input_sha256'],
               'code_sha256': c['code_sha256'], 'L1': manifest['L1'], 'outcome': 'ok',
               'used_bins': bins, 'evidence': {'runtime_sha256': '1'*64,
                'isolation_profile_sha256': '2'*64, 'checker_sha256': '3'*64,
                'cleanup_status': 'passed', 'checker_status': 'passed', 'assignment_sha256': '4'*64}}
              for i, manifest in enumerate(runner._panel['instances'])]
    runner.observe_verified(request['id'], capture,
        {'unique': True, 'strict': True, 'reason': None, 'candidate': c}, scores,
        {'notice': 'TRUSTED MOCK; NEVER RUNTIME EVIDENCE'})


def fixture(*, partial=False, one_parent=False, big=False, p1_failures=False):
    panel = {'kind': 'mock', 'instances': [{'instance_index': i, 'L1': 4, 'n': 10,
              'capacity': 100, 'input_sha256': d.digest(['SYNTHETIC_PANEL', i])} for i in range(5)]}
    r = d.SafeRunner(panel)
    for phase in (0, 1):
        requests = []
        while True:
            request = r.next_request()
            if request is None:
                break
            assert request['phase'] == phase
            requests.append(request)
        for index, request in enumerate(requests):
            if partial and phase == 1 and index == len(requests) - 1:
                return r
            failed = (one_parent and request['arm'] == 'EOH_TC' and
                      not (phase == 0 and request['id'].endswith('_01')))
            failed = failed or (p1_failures and phase == 1)
            observe(r, request, failed=failed, source='SYNTHETIC_OPAQUE_' + 'X'*16000 if big else None)
    return r


def independent_draws(population, slot):
    m = len(population); weights = [Fraction(1, m+i) for i in range(1, m+1)]
    denominator = math.lcm(*(x.denominator for x in weights))
    weights = [int(x*denominator) for x in weights]; total = sum(weights)
    limit = 2**256 // total * total; answer = []; counter = 0
    while len(answer) < slot['parent_draws']:
        raw = hashlib.sha256(f'parent-v1|610050101|{slot["id"]}|{counter}'.encode()).digest()
        counter += 1; value = int.from_bytes(raw, 'big')
        if value >= limit:
            continue
        ticket = value % total; accum = 0
        for parent, weight in zip(population, weights):
            accum += weight
            if ticket < accum:
                answer.append(parent['id']); break
    return answer


class DraftTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.parse_guard = patch('ast.parse', side_effect=AssertionError('host candidate parse'))
        cls.process_guard = patch('subprocess.Popen', side_effect=AssertionError('process launch'))
        cls.socket_guard = patch('socket.socket', side_effect=AssertionError('network'))
        cls.parse_guard.start(); cls.process_guard.start(); cls.socket_guard.start()

    @classmethod
    def tearDownClass(cls):
        cls.socket_guard.stop(); cls.process_guard.stop(); cls.parse_guard.stop()

    def test_01_static_sources_unchanged(self):
        self.assertEqual(d.verify_static_pins(), 57)

    def test_02_real_bindings_remain_null_and_live_blocked(self):
        c = json.loads((d.HERE/'DRAFT_CONTRACT.json').read_bytes())
        self.assertTrue(all(v is None for v in c['parent_evidence_required'].values()))
        self.assertTrue(all(v is None for v in c['future_phase2_bindings'].values()))
        with self.assertRaisesRegex(ValueError, 'unbound final P1'):
            d.require_final_bindings(c)

    def test_03_full_order_prompt_rng_and_budget(self):
        r = fixture(); before = r.export(); drafts, ledger = d.project_mock_phase2(r)
        self.assertEqual(before, r.export())
        plan = json.loads((d.ROOT/'URP/experiments/online_bin_packing/eoh_evolution_runner_v1/generation_slots.json').read_bytes())['records']
        self.assertEqual([x['request']['id'] for x in drafts], [x['id'] for x in plan if x['phase'] == 2])
        self.assertEqual([x['request']['order'] for x in drafts], list(range(73, 133)))
        self.assertEqual(Counter(x['request']['arm'] for x in drafts), {'EOH_TC': 30, 'IID_TC': 30})
        self.assertEqual(Counter(x['request']['operator'] for x in drafts if x['request']['arm'] == 'EOH_TC'),
                         dict.fromkeys(('e1','e2','m1','m2','m3'), 6))
        original_iid = json.loads((d.PREP/'inputs/roster.json').read_bytes())['records']
        sid = next(x['slot_id'] for x in original_iid if x['arm'] == 'IID_TC')
        iid_prompt = json.loads((d.PREP/'inputs/packs'/(sid+'.json')).read_bytes())['prompt']
        population, snapshot = r._population(1)
        for item in drafts:
            request, prompt = item['request'], item['prompt']
            self.assertEqual(prompt['messages'][-1]['content'].count(d.build_prompt.__globals__['PUBLIC_RESPONSE_RULE']), 1)
            if request['arm'] == 'IID_TC':
                self.assertEqual(prompt['cli_user_prompt'], iid_prompt); self.assertEqual(request['parents'], [])
            else:
                self.assertEqual(request['parents'], independent_draws(population, request))
                self.assertEqual(request['parent_snapshot_sha256'], snapshot['sha256'])
                self.assertNotIn('"fitness"', prompt['cli_user_prompt'])
                self.assertNotIn('"report_gap"', prompt['cli_user_prompt'])
        self.assertEqual(len(ledger['generation']), 132); self.assertEqual(len(ledger['scores']), 780)
        self.assertEqual(len(ledger['snapshots']), 4)
        self.assertTrue(ledger['summary']['actual_g1_to_g2_parent_ids'])

    def test_04_partial_p1_fails_before_projection(self):
        r = fixture(partial=True); before = r.export()
        with self.assertRaisesRegex(ValueError, 'terminal P1'): d.project_mock_phase2(r)
        self.assertEqual(before, r.export())

    def test_05_one_parent_replacement_is_preserved(self):
        r = fixture(one_parent=True); drafts, _ = d.project_mock_phase2(r)
        for x in drafts:
            s = x['request']
            if s['arm'] == 'EOH_TC':
                self.assertEqual(len(set(s['parents'])), 1)
                self.assertEqual(len(s['parents']), 5 if s['operator'] in ('e1','e2') else 1)
                self.assertTrue(s['parent_draw']['replacement'])

    def test_06_all_p1_format_failures_keep_prior_population_without_refill(self):
        r = fixture(p1_failures=True); drafts, after = d.project_mock_phase2(r)
        self.assertEqual(len(drafts), 60)
        self.assertEqual(after['summary']['actual_g1_to_g2_parent_ids'], [])

    def test_07_production_runner_is_explicitly_rejected(self):
        r = fixture(); r._panel['kind'] = 'externally_verified'
        with self.assertRaisesRegex(ValueError, 'production preparation disabled'): d.project_mock_phase2(r)

    def test_08_foreign_lineage_rejected(self):
        r = fixture(); r._archive['side_experiment_9'] = deepcopy(next(iter(r._archive.values())))
        r._archive['side_experiment_9']['id'] = 'side_experiment_9'
        with self.assertRaisesRegex(ValueError, 'foreign lineage'): d.project_mock_phase2(r)

    def test_09_preembedded_five_large_parents_hit_existing_base_limit(self):
        r = fixture(big=True); before = r.export()
        with self.assertRaisesRegex(ValueError, 'base_prompt_byte_bound'): d.project_mock_phase2(r)
        self.assertEqual(before, r.export())

    def test_10_receiver_rejects_partial_mixed_reordered_and_live_index(self):
        drafts, _ = d.project_mock_phase2(fixture()); roster = [x['request'] for x in drafts]
        index = {'mode': 'fixture_only', 'rows': [{'state': 'terminal', 'phase': 2, 'slot_id': x['id'],
                    'arm': x['arm'], 'order': x['order']} for x in roster]}
        self.assertEqual(d.validate_mock_terminal_index(index, roster)['terminals'], 60)
        bad = deepcopy(index); bad['rows'].pop()
        with self.assertRaisesRegex(ValueError, 'sixty'): d.validate_mock_terminal_index(bad, roster)
        bad = deepcopy(index); bad['rows'][0]['phase'] = 1
        with self.assertRaisesRegex(ValueError, 'phase2'): d.validate_mock_terminal_index(bad, roster)
        bad = deepcopy(index); bad['rows'][0], bad['rows'][1] = bad['rows'][1], bad['rows'][0]
        with self.assertRaisesRegex(ValueError, 'roster'): d.validate_mock_terminal_index(bad, roster)
        bad = deepcopy(index); bad['mode'] = 'official_cli'
        with self.assertRaisesRegex(ValueError, 'production reception disabled'): d.validate_mock_terminal_index(bad, roster)

    def test_11_phase2_failure_is_terminal_without_extra_request(self):
        r = fixture(); ids = []
        for _ in range(60):
            req = r.next_request(); ids.append(req['id']); observe(r, req, failed=True)
        self.assertEqual(len(set(ids)), 60); self.assertIsNone(r.next_request())
        self.assertEqual(len(r._snapshots), 6)
        self.assertEqual(r.export()['reserved']['logical_requests'], 132)

    def test_12_resource_arithmetic(self):
        c = json.loads((d.HERE/'DRAFT_CONTRACT.json').read_bytes())['resources']
        self.assertEqual(60+300*(60+60), c['phase2_maximum_numerical_cpu_reservation'])
        self.assertEqual(60*5+300*90, c['phase2_maximum_numerical_shared_wall_reservation'])
        self.assertEqual(132*5+20+100, c['score_plan']['total'])
        self.assertFalse(c['shared_budgets_reset_allowed'])

if __name__ == '__main__': unittest.main(verbosity=2)
