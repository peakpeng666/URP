"""Read-only phase-two evidence audit; no candidate AST, execution, or API calls.

The accepted runtime already checks every assignment with its independent exact
integer checker. Its persisted receipts contain assignment hashes, not vectors.
This auditor revalidates those receipts and independently recomputes rational
fitness, gap, deduplication, selection, counts and accounting from retained data.
"""
import argparse
from collections import Counter
from copy import deepcopy
from fractions import Fraction
import hashlib,importlib.util,json,math,pathlib,sys
from unittest.mock import patch
ROOT=pathlib.Path(__file__).resolve().parent.parent

def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

def require(ok,reason):
    if not ok:raise ValueError(reason)

def frac(v):return Fraction(v['numerator'],v['denominator'])
def rational(v):return {'numerator':v.numerator,'denominator':v.denominator}
def snapshot(h):return {str(p.relative_to(h.STATE)):h.sha(p.read_bytes()) for p in sorted(h.STATE.rglob('*')) if p.is_file()}
def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()

def independent_selection(ledger,phase):
    archive={x['id']:x for x in ledger['archive']};generations={x['id']:x for x in ledger['generation']};out=[]
    for snap in ledger['snapshots']:
        require(snap['phase']<=phase,'unexpected later selection')
        arm=snap['arm'];stage=snap['phase']
        offspring=[x for x in archive.values() if x['arm']==arm and x['phase']==stage and x['eligible']]
        if arm=='EOH_TC':
            prev=next((s for s in ledger['snapshots'] if s['phase']==stage-1 and s['arm']==arm),None)
            pool=([archive[i] for i in prev['survivor_ids']] if prev else [])+offspring;capacity=6
        else:
            pool=[x for x in archive.values() if x['arm']==arm and x['phase']<=stage and x['eligible']];capacity=1
        unique={};duplicates={}
        for candidate in sorted(pool,key=lambda x:x['order']):
            identity=candidate['joint_identity']
            if identity in unique:duplicates[candidate['id']]=unique[identity]['id']
            else:unique[identity]=candidate
        ranked=sorted(unique.values(),key=lambda x:(-frac(x['fitness']),x['tie_priority'],x['id']))
        survivors=[x['id'] for x in ranked[:capacity]]
        decisions={'eligible_ids':[x['id'] for x in sorted(pool,key=lambda x:x['order'])], 'ranked_ids':[x['id'] for x in ranked],'duplicates':duplicates,'reasons':{x['id']:('exact_joint_duplicate' if x['id'] in duplicates else 'retained' if x['id'] in survivors else 'outside_capacity') for x in pool}}
        require(snap['decisions']==decisions and snap['survivor_ids']==survivors,'independent dedup/ranking mismatch')
        require(snap['population_size']==len(survivors) and snap['underfilled']==(len(survivors)<capacity),'selection capacity mismatch')
        expected_failed=[{'id':x['id'],'state':x['state'],'reason':x['reason']} for x in ledger['generation'] if x['arm']==arm and x['phase']==stage and x['state']!='eligible']
        require(snap['failed_offspring']==expected_failed,'failed denominator changed')
        member_keys=('id','pair_sha256','code_identity','joint_identity','fitness','report_gap','tie_priority','initial_lineages')
        members=[{key:deepcopy(archive[sid][key]) for key in member_keys} for sid in survivors]
        expected={'name':f'P{stage}','arm':arm,'phase':stage,'survivor_ids':survivors,'members':members,
            'decisions':decisions,'failed_offspring':expected_failed,'population_size':len(survivors),
            'underfilled':len(survivors)<capacity,'distinct_code_count':len({archive[sid]['code_identity'] for sid in survivors}),
            'behavior_diversity':'unknown_without_assignment_evidence',
            'active_initial_lineages':sorted({lineage for sid in survivors for lineage in archive[sid]['initial_lineages']})}
        expected['sha256']=digest(expected)
        require(snap==expected,'complete independently reconstructed snapshot mismatch')
        out.append({'phase':stage,'arm':arm,'survivor_ids':survivors,'ranked_ids':decisions['ranked_ids'],'joint_duplicates':duplicates,'capacity':capacity})
    return out

def verified_archive_and_scores(ledger,original,observations):
    """Bind complete archived candidates and score views to verified observations.

    Canonical code identity is supplied by the unchanged bounded receipt verifier;
    this function never parses candidate source or trusts identity from the ledger.
    """
    require([s['id'] for s in ledger['generation']]==[s['id'] for s in original['generation']],
            'original generation order and identities')
    require(len({c['id'] for c in ledger['archive']})==len(ledger['archive']),'duplicate archive identity')
    original_archive={c['id']:deepcopy(c) for c in original['archive']}
    current_archive={c['id']:c for c in ledger['archive']}
    require(all(current_archive.get(sid)==candidate for sid,candidate in original_archive.items()),
            'complete P0/P1 archive preservation')
    generation={s['id']:s for s in ledger['generation']}
    stage=[s for s in ledger['generation'] if s['phase']==2]
    require([o['slot_id'] for o in observations]==[s['id'] for s in stage],'exact g2 observation roster')
    expected=deepcopy(original_archive)
    scores=deepcopy(original['scores'])
    for obs in observations:
        slot=generation[obs['slot_id']];extraction=obs['extraction'];verified=obs['scores']
        require(obs['integrity_error'] is None,'clean terminal observations only')
        require(slot['admission']==obs['admission'] and slot['observed']==obs['capture'].get('usage')
                and slot['physical_http_attempts']==obs['capture'].get('physical_http_attempts'),
                'verified admission and capture metadata')
        score_rows=[r for r in scores if r.get('source_generation_slot')==slot['id']]
        require(len(score_rows)==5,'five original score positions')
        if not extraction['unique']:
            require(extraction['candidate'] is None and not verified and slot['state']=='generation_failed'
                    and slot['reason']==extraction['reason'],'unadmitted source absent from archive')
            for row in score_rows:row['reason']='generation_'+str(extraction['reason'])
            continue
        candidate=deepcopy(extraction['candidate'])
        require(type(candidate) is dict and all(parent in original_archive for parent in slot['parents']),
                'verified candidate and prior parents')
        candidate.update(id=slot['id'],arm=slot['arm'],phase=slot['phase'],order=slot['order'],
            tie_priority=slot['tie_priority'],eligible=False,fitness=None,report_gap=None,
            parents=list(slot['parents']),joint_duplicate_of=None,code_duplicate_of=None,
            initial_lineages=([slot['id']] if slot['arm']=='IID_TC' else
                sorted({lineage for parent in slot['parents'] for lineage in original_archive[parent]['initial_lineages']})))
        indexes=[score['instance_index'] for score in verified]
        require(len(indexes)==len(set(indexes)) and set(indexes)<=set(range(5)),'unique verified score positions')
        for score in verified:
            row=score_rows[score['instance_index']];outcome=score['outcome']
            row.update(state='verified' if outcome=='ok' else 'not_run' if outcome=='not_run' else 'failed',
                reason=None if outcome=='ok' else outcome,used_bins=score.get('used_bins'),L1=score['L1'],
                code_hash=candidate['code_sha256'],runtime_hash=score['evidence']['runtime_sha256'],evidence=deepcopy(score))
        for row in score_rows:
            if row['state']=='not_run' and row['evidence'] is None:row['reason']='missing_verified_observation'
        eligible=all(row['state']=='verified' for row in score_rows)
        require(slot['state']==('eligible' if eligible else 'evaluation_failed')
                and slot['reason']==(None if eligible else 'incomplete_or_failed_design_panel'),
                'eligibility derives only from complete verified panel')
        if eligible:
            candidate['eligible']=True
            candidate['fitness']=rational(sum((Fraction(r['L1'],r['used_bins']) for r in score_rows),Fraction())/5)
            candidate['report_gap']=rational(100*Fraction(sum(r['used_bins']-r['L1'] for r in score_rows),sum(r['L1'] for r in score_rows)))
        expected[slot['id']]=candidate
    seen_joint={};seen_code={}
    ordered=sorted(expected.values(),key=lambda c:c['order'])
    for candidate in ordered:
        joint=(candidate['arm'],candidate['joint_identity']);code=(candidate['arm'],candidate['code_identity'])
        candidate['joint_duplicate_of']=seen_joint.get(joint);candidate['code_duplicate_of']=seen_code.get(code)
        seen_joint.setdefault(joint,candidate['id']);seen_code.setdefault(code,candidate['id'])
    require(ledger['archive']==ordered,'complete archive mismatch against verified observations and scheduler-derived fields')
    require(ledger['scores']==scores,'complete score views mismatch against verified observations')
    return {'candidates':len(ordered),'historical_candidates':len(original_archive),
            'g2_candidates':len(ordered)-len(original_archive),'complete_archive_verified':True}

def independent_parent_draw(population,slot,seed):
    def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
    m=len(population);require(m>0,'empty audited P1')
    weights=[Fraction(1,m+rank) for rank in range(1,m+1)]
    den=math.lcm(*(w.denominator for w in weights));integers=[int(w*den) for w in weights];total=sum(integers)
    domain=f'parent-v1|{seed}|{slot["id"]}';bound=2**256//total*total;tickets=[];chosen=[];counter=0
    while len(chosen)<slot['parent_draws']:
        value=int.from_bytes(hashlib.sha256(f'{domain}|{counter}'.encode()).digest(),'big');counter+=1
        if value>=bound:continue
        ticket=value%total;tickets.append(ticket);acc=0
        for parent,weight in zip(population,integers):
            acc+=weight
            if ticket<acc:chosen.append(parent);break
    return {'ids':chosen,'distinct_count':len(set(chosen)),'multiplicities':{p:chosen.count(p) for p in sorted(set(chosen))},
        'weights':[rational(w) for w in weights],'integer_weights':integers,'replacement':True,'tickets':tickets,
        'rng_algorithm':'sha256-counter-rejection-v1','rng_state_before_sha256':digest([domain,0]),
        'rng_state_after_sha256':digest([domain,counter]),'rng_counter_after':counter}

def terminal_boundary(ledger,original):
    require(len(ledger['generation'])==132 and len(ledger['scores'])==780,'full frozen denominator')
    require([row['id'] for row in ledger['generation']]==[row['id'] for row in original['generation']] and len({row['id'] for row in ledger['generation']})==132,'complete unique frozen generation ID sequence')
    require([row['id'] for row in ledger['scores']]==[row['id'] for row in original['scores']] and len({row['id'] for row in ledger['scores']})==780,'complete unique frozen score ID sequence')
    require(sum(x['logical_requests_observed'] for x in ledger['generation'])==132,'exact generation total')
    require(all(type(slot['logical_requests_observed']) is int and slot['logical_requests_observed']==1 for slot in ledger['generation']),'exactly one logical request per original slot')
    require(all(x['state'] in ('eligible','generation_failed','evaluation_failed') for x in ledger['generation']),'all generation terminal')
    require(ledger['summary']['terminal'] is True and ledger['summary']['halt_reason'] is None,'clean terminal scheduler')
    require(len(ledger['snapshots'])==6 and ledger['snapshots'][:4]==original['snapshots'],'P0/P1 snapshot preservation')
    require([(snap['phase'],snap['arm']) for snap in ledger['snapshots']]==[(phase,arm) for phase in range(3) for arm in ('EOH_TC','IID_TC')],'exact snapshot roster')
    old={x['id']:x for x in original['generation'] if x['phase']<2}
    require(all(x==old[x['id']] for x in ledger['generation'] if x['phase']<2),'P0/P1 generation preservation')
    scores={x['id']:x for x in original['scores'] if x.get('source_generation_slot') in old}
    require(all(x==scores[x['id']] for x in ledger['scores'] if x.get('source_generation_slot') in old),'P0/P1 score preservation')
    require(ledger['spec']==original['spec'] and ledger['budget']==original['budget'],'frozen spec and budget')
    require(ledger['reserved']=={'logical_requests':132,'completion_tokens':4224000,'generation_wall_seconds':118800},'whole generation reservations')
    prior_gen={x['id']:x for x in original['generation']}
    g2_ids={x['id'] for x in ledger['generation'] if x['phase']==2}
    untouched={x['id']:x for x in original['scores'] if x.get('source_generation_slot') not in g2_ids}
    require(all(x==untouched[x['id']] for x in ledger['scores'] if x.get('source_generation_slot') not in g2_ids),'all non-g2 scores and controls/heldout preserved')
    archive={x['id']:x for x in ledger['archive']}
    p1=next(x for x in original['snapshots'] if x['phase']==1 and x['arm']=='EOH_TC')
    g1=set()
    for slot in ledger['generation']:
        if slot['phase']!=2:continue
        require(all(slot[k]==prior_gen[slot['id']][k] for k in ('id','order','arm','phase','operator','parent_draws','tie_priority')),'original g2 slot and tie')
        if slot['arm']=='EOH_TC':
            draws=independent_parent_draw(p1['survivor_ids'],slot,original['spec']['seeds']['parents'])
            require(slot['parent_draw']==draws and slot['parents']==draws['ids'],'independent exact g2 parent draw')
            require(slot['parent_snapshot_sha256']==p1['sha256'] and set(slot['parents'])<=set(p1['survivor_ids']),'g2 audited P1 parents only')
            for parent in slot['parents']:
                if archive[parent]['phase']==1:g1.add(parent)
        else:require(slot['parents']==[] and slot['parent_draw'] is None,'IID must remain parentless')
    require(ledger['summary']['actual_g1_to_g2_parent_ids']==sorted(g1),'lineage summary')
    winners={snap['arm']:(snap['survivor_ids'][0] if snap['survivor_ids'] else None) for snap in ledger['snapshots'] if snap['phase']==2}
    require(ledger['summary']['winners']==winners and all(sid is None or sid in archive and archive[sid]['eligible'] for sid in winners.values()),'winner summary must equal verified P2 snapshots')
    expected_summary={'planned_generation_slots':132,'planned_scoring_rows':780,'actual_provider_calls':0,'candidate_executions':0,
        'scheduler_request_records':132,'generation_counts_by_arm':{arm:sum(slot['logical_requests_observed'] for slot in ledger['generation'] if slot['arm']==arm) for arm in ('EOH_TC','IID_TC')},
        'not_run_generation_slots':0,'verified_score_records':sum(row['state']=='verified' for row in ledger['scores']),
        'remaining_generation_slots':[],'terminal':True,'halt_reason':None,'equal_full_66_request_records':True,
        'actual_tokens_equal':'not_claimed','physical_http_attempts':None,'actual_g1_to_g2_parent_ids':sorted(g1),'winners':winners}
    require(ledger['summary']==expected_summary,'complete scheduler summary must equal verified ledger views')
    return {'actual_g1_to_g2_parent_ids':sorted(g1),'at_least_one_retained_g1_parent_used':bool(g1),
            'criterion_not_forced':True,'no_generation_after_P2':True,'heldout_activation_authorized':False}

def audit(h,phase,report_path,report_sha,approval_path,approval_sha):
    require(phase==2,'phase2 auditor only')
    before=snapshot(h)
    with patch('ast.parse',side_effect=AssertionError('candidate AST forbidden')),patch('subprocess.Popen',side_effect=AssertionError('process launch forbidden')):
        sources=h.verify_sources();report=h.verify(h.read(report_path,report_sha));plan=h.verify(h.read(h.STATE/'plan.json'))
        require(report['status']==f'phase{phase}_complete' and report['halt_reason'] is None,'not a clean terminal report')
        require(report['plan_sha256']==plan['sha256'] and plan['source_input_plan_sha256']==sources['sha256'],'plan/report/source binding')
        approval=h.read(approval_path,approval_sha)
        require(approval['schema']==f'phase{phase}-execution-approval-v1' and approval['explicit_execution_grant'] is True,'approval identity')
        if phase==2:
            package=h.verify(h.read(h.HERE/'PACKAGE_MANIFEST.json'))
            require(approval['enabled'] is True and approval['parent_review_accepted'] is True and approval['package_manifest_sha256']==package['sha256'],'phase-two parent grant')
        for k in ('plan_sha256','registry_sha256','deployment_sha256','max_admissions','max_candidate_packs'):
            require(approval[k]==(plan['sha256'] if k=='plan_sha256' else plan[k]),'approval binding '+k)
        require(approval['run_id']==h.RUN and approval['controls']==approval['heldout']==0,'approval scope')
        trust=h.read(approval['receipt_trust_path'],approval['receipt_trust_file_sha256'])
        require(approval['receipt_trust_file_sha256']=='a16084586b4ae388cf0b59b266423d3ee7b68717f69f5e74f1391387265bf388','unchanged receipt trust')
        handoff=h.read(h.STATE/'handoff.json',plan['handoff_file_sha256']);m=h.modules();store,rows=h.imported_rows(handoff,m)
        require(rows==h.read(h.STATE/'rows.json',plan['rows_file_sha256']),'capture reimport mismatch')
        panel,instances=h.design_panel();require(panel==h.read(h.STATE/'panel.json',plan['panel_file_sha256']),'design mismatch')
        freeze=h.verify(h.read(h.INPUTS/'freeze.json'));bridge=h.receipt_bridge(plan,trust,m) if plan['candidate_source_count'] else None
        ledger=h.verify(h.read(report['scheduler_ledger_path']));require(ledger['sha256']==report['scheduler_ledger_sha256'],'ledger binding')
        denominator=60
        require(len(rows)==report['generation_denominator']==report['authenticated_generation_terminals']==denominator,'denominator')
        require(len(ledger['generation'])==132 and len(ledger['scores'])==780,'scientific full scope')
        require(sum(x['logical_requests_observed'] for x in ledger['generation'])==132,'logical request scope')
        require(all(x['state']=='planned' and x['logical_requests_observed']==0 for x in ledger['generation'] if x['phase']>phase),'later phase touched')
        require(report['control_packs']==report['heldout_packs']==report['parent_rescores']==0,'unauthorized evaluation')
        if phase:
            original=h.verify(h.read(h.HERE/'history/scheduler-ledger.json'))
            require(ledger['snapshots'][:4]==original['snapshots'],'P0/P1 changed')
            old_gen={x['id']:x for x in original['generation'] if x['phase']<2}
            require(all(x==old_gen[x['id']] for x in ledger['generation'] if x['phase']<2),'P0/P1 generation history changed')
            old_scores={x['id']:x for x in original['scores'] if x.get('source_generation_slot') in old_gen}
            require(all(x==old_scores[x['id']] for x in ledger['scores'] if x.get('source_generation_slot') in old_gen),'P0/P1 score history changed')
        require(len(ledger['snapshots'])==6,'selection boundary')
        bundles=[];workers=[];supervisors=[];expected_tokens=set();expected_reservations=set();candidates=[];observations=[]
        generation={x['id']:x for x in ledger['generation']};archive={x['id']:x for x in ledger['archive']}
        for row in rows:
            cid=row['claim']['claim_id'];attempt=h.verify(h.read(h.STATE/'attempts'/(cid+'.json')));saved=h.verify(h.read(h.STATE/'results'/(cid+'.json')))
            require(attempt['plan_sha256']==saved['plan_sha256']==plan['sha256'],'attempt plan')
            require(attempt['claim_sha256']==saved['claim_sha256']==row['claim']['sha256'],'attempt claim')
            bundle=h.verify(h.read(h.STATE/'bundles'/(cid+'.json'))) if row['candidate'] else None
            projected=h.project(row,bundle,bridge,panel,freeze);observations.append(projected)
            require(projected==saved['observation'] and saved['bundle_sha256']==(bundle['sha256'] if bundle else None),'verified projection')
            slot=generation[row['slot_id']]
            require(slot['parents']==row['pack']['parents'] and slot['parent_snapshot_sha256']==row['pack']['parent_snapshot_sha256']
                    and slot['prompt'][-1]['content']==row['pack']['prompt'] and h.digest(slot['prompt'])==row['pack']['serialized_messages_sha256']
                    and slot['configured']==row['pack']['configuration'],'frozen source pack prompt/parents/config')
            require(slot['capture']==row['capture'] and slot['extraction']=={k:v for k,v in projected['extraction'].items() if k!='candidate'},'scheduler capture/extraction')
            if bundle is None:
                require(slot['state']=='generation_failed','format failure state');continue
            bundles.append(bundle);workers.append(bundle['admission']['worker']);expected_reservations.add(('admission',cid+'/admission'))
            token=h.digest(['registry-execution-v1',h.RUN,row['slot_id'],'verify']);expected_tokens.add(token)
            require(h.verify(h.read(h.STATE/'runtime_journal'/(token+'.result.json')))['receipt']==bundle,'bundle journal')
            journal=h.verify(h.read(h.STATE/'runtime_journal'/(token+'.claim.json')))
            require(journal['binding']==bundle['registry_binding'] and journal['execution_id']=='verify','bundle journal claim')
            for score,projected_score in zip(bundle['scores'],projected['scores']):
                i=score['instance_index'];ev=score['evidence'];worker=ev['worker'];supervisor=ev['supervisor'];workers.append(worker);supervisors.append(supervisor)
                eid=cid+'/instance/'+str(i);expected_reservations.update({('instance',eid),('supervisor',eid)})
                token=h.digest(['registry-execution-v1',h.RUN,row['slot_id'],eid]);expected_tokens.add(token)
                require(h.verify(h.read(h.STATE/'runtime_journal'/(token+'.result.json')))['receipt']==score,'score journal')
                journal=h.verify(h.read(h.STATE/'runtime_journal'/(token+'.claim.json')))
                require(journal['binding']==bundle['registry_binding'] and journal['execution_id']==eid,'score journal claim')
                require(score['input_sha256']==panel['instances'][i]['input_sha256'] and score['L1']==panel['instances'][i]['L1'],'exact score input')
                ledger_score=next(x for x in ledger['scores'] if x.get('source_generation_slot')==row['slot_id'] and x['instance_index']==i)
                require(ledger_score['evidence']==projected_score,'scheduler score evidence')
                if score['outcome']=='ok':
                    require(ledger_score['state']=='verified' and ledger_score['used_bins']==score['used_bins'],'score bin/state')
                    require(ev['checker_status']=='passed' and ev['assignment_complete'] is True and ev['no_cross_slot_cache'] is True,'assignment evidence')
                    require(worker['steps']==5000 and worker['assignment_complete'] is True,'full 5000 assignments')
                else:require(score['used_bins'] is None and ev['assignment_complete'] is False,'no invented failed fitness')
            if slot['state']=='eligible':
                require(len(bundle['scores'])==5 and all(s['outcome']=='ok' for s in bundle['scores']),'eligible incomplete panel')
                fitness=sum((Fraction(s['L1'],s['used_bins']) for s in bundle['scores']),Fraction())/5
                gap=100*Fraction(sum(s['used_bins']-s['L1'] for s in bundle['scores']),sum(s['L1'] for s in bundle['scores']))
                candidate=archive[row['slot_id']]
                require(candidate['fitness']==rational(fitness) and candidate['report_gap']==rational(gap),'independent exact fitness/gap')
                require(candidate['tie_priority']==slot['tie_priority'],'frozen tie priority')
                candidates.append({'slot_id':row['slot_id'],'arm':row['arm'],'source_sha256':row['candidate']['code_sha256'],'used_bins':[s['used_bins'] for s in bundle['scores']],'fitness':rational(fitness),'fitness_decimal':float(fitness),'assignment_hashes':[s['evidence']['assignment_sha256'] for s in bundle['scores']]})
            elif row['slot_id'] in archive:require(archive[row['slot_id']]['fitness'] is None and archive[row['slot_id']]['eligible'] is False,'failed candidate fitness')
        require({p.stem for p in (h.STATE/'attempts').glob('*.json')}=={x['claim']['claim_id'] for x in rows},'attempt roster')
        require({p.stem for p in (h.STATE/'results').glob('*.json')}=={x['claim']['claim_id'] for x in rows},'result roster')
        for suffix in ('.claim.json','.result.json'):require({p.name.removesuffix(suffix) for p in (h.STATE/'runtime_journal').glob('*'+suffix)}==expected_tokens,'unknown runtime journal')
        require(not list(h.STATE.glob('halt-*.json')),'retained infrastructure halt')
        require(all(x['reaped'] is True and x['cleanup_error'] is None for x in workers+supervisors),'worker/supervisor cleanup')
        require(all(x['source_sent'] is True and x['source_after_host_gate'] is True and x['security']==trust['expected_security'] for x in workers),'sandbox evidence')
        reservations=[h.verify(h.read(p)) for p in sorted((h.STATE/'reservations').glob('*.json'))]
        require(len(reservations)==len(expected_reservations) and {(x['role'],x['execution_id']) for x in reservations}==expected_reservations,'reservation exactness')
        usage=h.account(bundles,reservations);require(usage==report['usage'],'usage report')
        cpu=sum(x['cpu_seconds'] for x in workers)+sum(x['actual_supervisor_cpu_seconds'] for x in supervisors)
        require(abs(cpu-usage['numerical_cpu_seconds_no_double_count'])<1e-8,'independent CPU accounting')
        require(usage['score_call_cpu_ns']==sum(x['score_call_cpu_ns'] for x in workers),'score timing')
        require(usage['reserved_cpu_seconds']<= (36060 if phase else 7212) and usage['reserved_shared_wall_seconds']<=(27300 if phase else 5460),'phase resources')
        require(len(bundles)<=plan['max_admissions'] and usage['instance_packs']<=plan['max_candidate_packs'],'phase execution counts')
        require(report['snapshots']==ledger['snapshots'],'report snapshots')
        archive_verification=verified_archive_and_scores(ledger,original,observations)
        selections=independent_selection(ledger,phase)
        lineage=terminal_boundary(ledger,original)
        require(report['phase2_activated'] is True and report['heldout_activated'] is False,'terminal activation boundary')
        for key in ('parent_boundary_sha256','parent_review_acceptance_sha256','resource_accounting_binding_sha256'):
            require(report[key]==plan[key]==approval[key]==h.verify(h.read(h.HERE/'BINDINGS.json'))[key],'exact parent/accounting report binding')
    require(snapshot(h)==before,'audit changed frozen state')
    return {'schema':'phase2-independent-terminal-audit-v1','status':'passed','phase':phase,'report_file_sha256':report_sha,'report_sha256':report['sha256'],'plan_sha256':plan['sha256'],'ledger_sha256':ledger['sha256'],'authenticated_index_identity':store.index_identity,'generation_denominator':denominator,'full_generation_logical_count':132,'full_score_plan_rows':780,'lineage_acceptance':lineage,'archive_verification':archive_verification,'winner_summary_verified':True,'generation_per_arm':dict(Counter(x['arm'] for x in rows)),'generation_states':dict(Counter(generation[x['slot_id']]['state'] for x in rows)),'eligible_per_arm':dict(Counter(x['arm'] for x in candidates)),'admissions':len(bundles),'design_packs':usage['instance_packs'],'source_files_verified':len(sources['source_and_input_files']),'worker_receipts':len(workers),'supervisor_receipts':len(supervisors),'runtime_claim_result_pairs':len(expected_tokens),'unknown_claims':0,'all_reaped_cleanly':True,'usage':usage,'candidates':candidates,'selection_recomputation':selections,'controls':0,'heldout':0,'parent_rescores':0,'candidate_execution_during_audit':0,'source_AST_calls_during_audit':0,'model_calls_during_audit':0,'frozen_state_unchanged':True,'historical_original_shared_balance':None,'original_global_cap_compliance_claimed':False,'forward_meter_terminal_receipt_audited':False,'state_files_hashed':len(before),'assignment_verification_scope':'The frozen runtime independently checks every full assignment using exact integers before emitting receipts. This audit checks accepted checker receipts, assignment hashes, exact rational fitness and selection. Candidate vectors are not persisted; no claimed second offline vector replay.'}

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--report',required=True);parser.add_argument('--report-file-sha256',required=True);parser.add_argument('--approval',required=True);parser.add_argument('--approval-file-sha256',required=True);parser.add_argument('--output',required=True);args=parser.parse_args()
    harness=ROOT/'original132_phase2_continuation_draft_20261006/phase2_numerical.py'
    h=load(harness,'audited_phase2_numerical_harness');result=audit(h,2,args.report,args.report_file_sha256,args.approval,args.approval_file_sha256)
    with pathlib.Path(args.output).open('x') as stream:json.dump(result,stream,sort_keys=True,indent=2);stream.write('\n')
    print(json.dumps({k:result[k] for k in ('status','phase','generation_denominator','admissions','design_packs','unknown_claims','all_reaped_cleanly','frozen_state_unchanged','lineage_acceptance')},sort_keys=True))
if __name__=='__main__':main()
