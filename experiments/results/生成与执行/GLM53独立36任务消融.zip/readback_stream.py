"""Materialize an authenticated connector file_uri from stdin, never log its URL."""
import hashlib,json,sys,urllib.request
from pathlib import Path
if sys.stdin.isatty():
 import termios
 attrs=termios.tcgetattr(sys.stdin.fileno());attrs[3] &= ~termios.ECHO
 termios.tcsetattr(sys.stdin.fileno(),termios.TCSANOW,attrs)
 print('READY: authenticated URI input stays unlogged',flush=True)
m=json.loads(sys.stdin.readline())
assert m['download_url'].startswith('https://')
p=Path(m['path']);assert p.is_relative_to('/workspace/ablation_20261007/readbacks')
p.parent.mkdir(parents=True,exist_ok=True)
digest=hashlib.sha256();size=0
with urllib.request.urlopen(m['download_url'],timeout=60) as r,p.open('wb') as f:
 while True:
  chunk=r.read(1024*1024)
  if not chunk:break
  f.write(chunk);digest.update(chunk);size+=len(chunk)
actual=digest.hexdigest()
assert size==m['expected_bytes'] and actual==m['expected_sha256'],'Readback size/SHA mismatch'
print(json.dumps({'verified':True,'bytes':size,'sha256':actual,'path':str(p)}),flush=True)
