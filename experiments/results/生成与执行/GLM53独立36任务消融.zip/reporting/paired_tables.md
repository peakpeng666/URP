
## 每题六条件与可用配对

每题保留六个冻结条件；失败、超时和未运行的分值均为unknown，不填零。只有同一题双方AST准入且真实完成3×1000评分、gap已观察，才进入配对。合法且已完整评分的截断输出仍保留truncation标记。

| 题目 | 模型 | effort | 任务 | 状态 | 秒 | 服务端usage末项 | AST准入 | 评分状态 | 3×1000 gap% |
|---|---|---|---|---|---:|---|---|---|---:|
| q01 | glm-5.3 | low | a21 | completed | 14.776 | {"prompt_tokens":4444,"completion_tokens":748,"total_tokens":5192,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":509}} | ast_passed | complete | 4.250 |
| q01 | glm-5.3 | high | a15 | completed | 335.133 | {"prompt_tokens":4444,"completion_tokens":24201,"total_tokens":28645,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":23839}} | ast_passed | complete | 5.417 |
| q01 | glm-5.3 | max | a05 | completed | 624.299 | {"prompt_tokens":4444,"completion_tokens":42251,"total_tokens":46695,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":41759}} | ast_passed | complete | 5.417 |
| q01 | glm-5.3-flash | low | a24 | completed | 12.464 | {"prompt_tokens":4444,"completion_tokens":390,"total_tokens":4834,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":173}} | ast_rejected | admission_rejected | unknown |
| q01 | glm-5.3-flash | high | a34 | completed | 429.658 | {"prompt_tokens":4444,"completion_tokens":18242,"total_tokens":22686,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":17910}} | ast_passed | complete | 4.917 |
| q01 | glm-5.3-flash | max | a17 | completed | 281.809 | {"prompt_tokens":4444,"completion_tokens":12840,"total_tokens":17284,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":12469}} | ast_rejected | admission_rejected | unknown |
| q02 | glm-5.3 | low | a32 | completed | 7.947 | {"prompt_tokens":4413,"completion_tokens":327,"total_tokens":4740,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":0}} | ast_rejected | admission_rejected | unknown |
| q02 | glm-5.3 | high | a09 | completed | 594.712 | {"prompt_tokens":4413,"completion_tokens":42861,"total_tokens":47274,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":42082}} | ast_rejected | admission_rejected | unknown |
| q02 | glm-5.3 | max | a31 | completed | 430.008 | {"prompt_tokens":4413,"completion_tokens":32423,"total_tokens":36836,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":31995}} | ast_passed | complete | 3.667 |
| q02 | glm-5.3-flash | low | a10 | completed | 6.537 | {"prompt_tokens":4413,"completion_tokens":242,"total_tokens":4655,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":28}} | ast_passed | complete | 4.250 |
| q02 | glm-5.3-flash | high | a04 | completed | 392.893 | {"prompt_tokens":4413,"completion_tokens":19902,"total_tokens":24315,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":19502}} | ast_passed | complete | 4.583 |
| q02 | glm-5.3-flash | max | a13 | completed | 280.996 | {"prompt_tokens":4413,"completion_tokens":13835,"total_tokens":18248,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":13578}} | ast_passed | complete | 4.250 |
| q03 | glm-5.3 | low | a08 | completed | 9.204 | {"prompt_tokens":3240,"completion_tokens":386,"total_tokens":3626,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":149}} | ast_rejected | admission_rejected | unknown |
| q03 | glm-5.3 | high | a11 | completed | 416.312 | {"prompt_tokens":3240,"completion_tokens":27416,"total_tokens":30656,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":27140}} | ast_passed | complete | 3.917 |
| q03 | glm-5.3 | max | a36 | completed | 393.203 | {"prompt_tokens":3240,"completion_tokens":26368,"total_tokens":29608,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":26123}} | ast_passed | complete | 5.667 |
| q03 | glm-5.3-flash | low | a22 | completed | 7.648 | {"prompt_tokens":3240,"completion_tokens":233,"total_tokens":3473,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":20}} | ast_passed | complete | 4.083 |
| q03 | glm-5.3-flash | high | a27 | completed | 346.664 | {"prompt_tokens":3240,"completion_tokens":14449,"total_tokens":17689,"prompt_tokens_details":{"cached_tokens":3200},"completion_tokens_details":{"reasoning_tokens":14057}} | ast_passed | complete | 4.583 |
| q03 | glm-5.3-flash | max | a26 | completed | 147.848 | {"prompt_tokens":3240,"completion_tokens":7102,"total_tokens":10342,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":6869}} | ast_passed | complete | 4.250 |
| q04 | glm-5.3 | low | a33 | completed | 5.535 | {"prompt_tokens":3299,"completion_tokens":294,"total_tokens":3593,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":11}} | ast_passed | complete | 3.583 |
| q04 | glm-5.3 | high | a02 | timeout | 900.392 | unknown | not_run | not_run | unknown |
| q04 | glm-5.3 | max | a07 | completed | 534.467 | {"prompt_tokens":3299,"completion_tokens":39679,"total_tokens":42978,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":39275}} | ast_passed | complete | 4.917 |
| q04 | glm-5.3-flash | low | a14 | completed | 7.088 | {"prompt_tokens":3299,"completion_tokens":309,"total_tokens":3608,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":17}} | ast_passed | complete | 3.417 |
| q04 | glm-5.3-flash | high | a35 | completed | 218.567 | {"prompt_tokens":3299,"completion_tokens":10360,"total_tokens":13659,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":10049}} | ast_passed | complete | 3.500 |
| q04 | glm-5.3-flash | max | a23 | completed | 268.109 | {"prompt_tokens":3299,"completion_tokens":13406,"total_tokens":16705,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":13087}} | ast_passed | complete | 3.417 |
| q05 | glm-5.3 | low | a25 | completed | 5.288 | {"prompt_tokens":3173,"completion_tokens":160,"total_tokens":3333,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":37}} | ast_passed | complete | 4.333 |
| q05 | glm-5.3 | high | a18 | completed | 47.797 | {"prompt_tokens":3173,"completion_tokens":3473,"total_tokens":6646,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":3333}} | ast_passed | complete | 4.333 |
| q05 | glm-5.3 | max | a29 | completed | 74.152 | {"prompt_tokens":3173,"completion_tokens":5600,"total_tokens":8773,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":5459}} | ast_passed | complete | 4.333 |
| q05 | glm-5.3-flash | low | a30 | completed | 4.785 | {"prompt_tokens":3173,"completion_tokens":124,"total_tokens":3297,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":0}} | ast_passed | complete | 4.333 |
| q05 | glm-5.3-flash | high | a16 | completed | 70.153 | {"prompt_tokens":3173,"completion_tokens":2892,"total_tokens":6065,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":2755}} | ast_passed | complete | 4.333 |
| q05 | glm-5.3-flash | max | a06 | completed | 39.946 | {"prompt_tokens":3173,"completion_tokens":1285,"total_tokens":4458,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":1146}} | ast_passed | complete | 4.333 |
| q06 | glm-5.3 | low | a03 | completed | 34.838 | {"prompt_tokens":4510,"completion_tokens":1681,"total_tokens":6191,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":1403}} | ast_passed | complete | 4.583 |
| q06 | glm-5.3 | high | a20 | completed | 743.752 | {"prompt_tokens":4510,"completion_tokens":38740,"total_tokens":43250,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":38202}} | ast_passed | complete | 3.917 |
| q06 | glm-5.3 | max | a12 | completed | 390.470 | {"prompt_tokens":4510,"completion_tokens":24952,"total_tokens":29462,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":24582}} | ast_passed | complete | 3.083 |
| q06 | glm-5.3-flash | low | a28 | completed | 7.749 | {"prompt_tokens":4510,"completion_tokens":286,"total_tokens":4796,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":13}} | ast_passed | complete | 4.583 |
| q06 | glm-5.3-flash | high | a19 | completed | 369.615 | {"prompt_tokens":4510,"completion_tokens":16239,"total_tokens":20749,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":15808}} | ast_passed | complete | 2.833 |
| q06 | glm-5.3-flash | max | a01 | completed | 286.456 | {"prompt_tokens":4510,"completion_tokens":14165,"total_tokens":18675,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":13773}} | ast_passed | complete | 2.250 |

各条件分母：

| 条件 | planned | attempted | completed | admitted | scored | 失败 | 未运行 | 未知终态 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| glm-5.3/low | 6 | 6 | 6 | 4 | 4 | 0 | 0 | 0 |
| glm-5.3/high | 6 | 6 | 5 | 4 | 4 | 1 | 0 | 0 |
| glm-5.3/max | 6 | 6 | 6 | 6 | 6 | 0 | 0 | 0 |
| glm-5.3-flash/low | 6 | 6 | 6 | 5 | 5 | 0 | 0 | 0 |
| glm-5.3-flash/high | 6 | 6 | 6 | 6 | 6 | 0 | 0 | 0 |
| glm-5.3-flash/max | 6 | 6 | 6 | 5 | 5 | 0 | 0 | 0 |

配对结果仅描述已观测小样本。A−B gap为百分点，较低gap较好；不足配对时不报告差值。

| 条件A | 条件B | 计划同题对数 | 可用同题对数 | 平均gap A−B（百分点） |
|---|---|---:|---:|---:|
| glm-5.3/low | glm-5.3/high | 6 | 3 | -0.167 |
| glm-5.3/low | glm-5.3/max | 6 | 4 | -0.250 |
| glm-5.3/low | glm-5.3-flash/low | 6 | 3 | 0.056 |
| glm-5.3/low | glm-5.3-flash/high | 6 | 4 | 0.292 |
| glm-5.3/low | glm-5.3-flash/max | 6 | 3 | 0.833 |
| glm-5.3/high | glm-5.3/max | 6 | 4 | -0.229 |
| glm-5.3/high | glm-5.3-flash/low | 6 | 3 | -0.278 |
| glm-5.3/high | glm-5.3-flash/high | 6 | 4 | 0.229 |
| glm-5.3/high | glm-5.3-flash/max | 6 | 3 | 0.444 |
| glm-5.3/max | glm-5.3-flash/low | 6 | 5 | 0.200 |
| glm-5.3/max | glm-5.3-flash/high | 6 | 6 | 0.389 |
| glm-5.3/max | glm-5.3-flash/max | 6 | 5 | 0.633 |
| glm-5.3-flash/low | glm-5.3-flash/high | 6 | 5 | 0.167 |
| glm-5.3-flash/low | glm-5.3-flash/max | 6 | 5 | 0.433 |
| glm-5.3-flash/high | glm-5.3-flash/max | 6 | 5 | 0.267 |

n=6仅用于筛选；可用对数低于6时不能按完整配对解释。未做显著性或稳定赢家判断。
