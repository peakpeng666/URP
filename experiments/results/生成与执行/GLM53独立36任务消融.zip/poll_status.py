"""Passive local status read; no model, Drive, credentials or mutations."""
import datetime,json,time
from pathlib import Path

root=Path(__file__).resolve().parent
initial=len(list((root/'raw').glob('*/terminal.json')))
deadline=time.monotonic()+25
while time.monotonic()<deadline:
    if len(list((root/'raw').glob('*/terminal.json')))!=initial or (root/'STOP.json').exists():
        break
    time.sleep(1)
rows=[json.loads(p.read_text()) for p in sorted((root/'raw').glob('*/terminal.json'))]
active=[]
now=datetime.datetime.now(datetime.timezone.utc)
for d in sorted((root/'raw').iterdir()):
    if (d/'invocation.json').exists() and not (d/'terminal.json').exists():
        x=json.loads((d/'invocation.json').read_text())
        active.append({'task':d.name,'model':x['model'],'effort':x['reasoning_effort'],
                       'elapsed_seconds':round((now-datetime.datetime.fromisoformat(x['started_utc'])).total_seconds(),1)})
print(json.dumps({'utc':now.isoformat(),'terminal':len(rows),
                  'completed':sum(x['status']=='completed' for x in rows),
                  'failed':sum(x['status']=='failed' for x in rows),
                  'active':active,'STOP':(root/'STOP.json').exists(),
                  'last_terminal':rows[-1]['task_id'] if rows else None,
                  'controller_stderr_bytes':(root/'controller_after19.stderr.log').stat().st_size
                  if (root/'controller_after19.stderr.log').exists() else None},ensure_ascii=False))
