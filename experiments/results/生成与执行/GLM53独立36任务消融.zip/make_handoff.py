"""Create complete audit ZIP; exclude runtime state, caches and all credentials."""
import hashlib,json,os,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'GLM53独立36任务消融_20261007.zip'
TEXT_EXT={'.ts','.tsx','.js','.jsx','.mjs','.cjs','.json','.jsonc','.md','.txt','.patch','.toml','.lock','.yml','.yaml','.rs','.py','.sql','.c','.h'}
def include(p):
 rel=p.relative_to(ROOT);parts=rel.parts
 if not p.is_file() or p.is_symlink() or p==OUT:return False
 if len(parts)==1 and p.name in ['HANDOFF_MANIFEST.json','delivery_pin.json','drive_delivery.json']:return False
 if any(x in parts for x in ['__pycache__','npm-cache','offline_mock','.git']):return False
 if parts[0]=='raw' and 'runtime' in parts:return False
 if parts[0]=='xdg' or parts[0]=='work':return False
 if parts[0]=='batches':return p.name.endswith('.delivery.json') or p.name.endswith('.pin.json') # Keep transport receipts; original task records are included once.
 if parts[0]=='readbacks':return False # Verified Drive transport copies; original payload is included.
 if parts[0]=='pins' and p.name=='opencode-linux-x64-1.18.34.tgz':return False # Exact binary is included once.
 if parts[0]=='source_audit':
  if p.name=='opencode-v1.18.34.tar.gz':return False # Full code text and archive origin/SHA are included.
  if parts[1]=='offline_cli':
   if len(parts)>2 and parts[2] in ['data','cache','state']:return False
  if parts[1]=='opencode-1.18.34':return p.suffix in TEXT_EXT or p.name in ['LICENSE','LICENSE.md','bun.lock','NOTICE']
 if len(parts)==1:return p.suffix in TEXT_EXT or p.name in ['all36.csv','condition_summary.csv']
 return True
files=sorted(p for p in ROOT.rglob('*') if include(p))
secret_names=['ZHIPU_API_KEY','HTTP_PROXY','HTTPS_PROXY','http_proxy','https_proxy']
secret_values=[os.environ[n].encode() for n in secret_names if os.environ.get(n) and len(os.environ[n])>=8]
pins={}
blocked=[]
for p in files:
 d=p.read_bytes()
 if any(v in d for v in secret_values):blocked.append(str(p.relative_to(ROOT)))
 pins[str(p.relative_to(ROOT))]={'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()}
assert not blocked,'Secret literal detected; no ZIP/upload: '+str(blocked)
manifest={'schema':'independent-ablation-complete-handoff-v1','files':pins,'credential_scan_passed':True,'credential_values_in_manifest':False,'excluded':'Private CLI runtime DB/auth/cache/state, caches, offline synthetic mock receipts, duplicate binary tar and duplicate upstream source tar; unrelated upstream website/desktop media and source files outside the explicit audit extension list. Exact native binary, selected upstream audit source text, SDK, installed plugin scaffold, source/input ZIP and all experiment source, protocol, raw, failure, candidate, score and statistics evidence are included. This is a complete experiment audit package, not a complete upstream repository mirror.'}
manifest_bytes=json.dumps(manifest,sort_keys=True,ensure_ascii=False,indent=2).encode()
(ROOT/'HANDOFF_MANIFEST.json').write_bytes(manifest_bytes)
with zipfile.ZipFile(OUT,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=True) as z:
 for p in files:
  if p==ROOT/'HANDOFF_MANIFEST.json':continue
  z.write(p,str(p.relative_to(ROOT)))
 z.writestr('HANDOFF_MANIFEST.json',manifest_bytes)
result={'path':str(OUT),'bytes':OUT.stat().st_size,'sha256':hashlib.sha256(OUT.read_bytes()).hexdigest(),'payload_files':len(pins),'credentials_detected':False}
(ROOT/'delivery_pin.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result,ensure_ascii=False))
