import hashlib,json,random
from pathlib import Path

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'inputs/P2/original132_phase2_continuation_draft_20261006/inputs'
OUT=ROOT/'protocol'
OUT.mkdir(exist_ok=True)
def canon(x): return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def sha(x): return hashlib.sha256(x).hexdigest()
roster=json.loads((SOURCE/'roster.json').read_text())
assert roster['phase']==2 and roster['count']==60
base=json.loads((SOURCE/'base-artifact.json').read_text())
system=base[0]['content']
packs=[]
for r in sorted(roster['records'],key=lambda r:r['slot_id']):
    p=SOURCE/'packs'/(r['slot_id']+'.json')
    d=json.loads(p.read_text())
    assert d['phase']==2 and sha(d['prompt'].encode())==d['prompt_sha256']
    assert sha(canon([{'role':'system','content':system},{'role':'user','content':d['prompt']}]))==d['serialized_messages_sha256']
    packs.append((r,d,p))
rng=random.Random(20261007)
selected=[]
for op in ['e1','e2','m1','m2','m3']:
    group=[x for x in packs if x[0]['arm']=='EOH_TC' and x[0]['operator']==op]
    assert len(group)==6
    selected.append(rng.choice(group))
remaining=[x for x in packs if x not in selected]
def sixth_key(x):return (sha(b'20261007\x00sixth\x00'+x[1]['prompt'].encode()+b'\x00'+x[0]['slot_id'].encode()),x[0]['slot_id'])
selected.append(min(remaining,key=sixth_key))
selection=[]
for n,(r,d,p) in enumerate(selected,1):
    qid=f'q{n:02}'
    (OUT/(qid+'.system.txt')).write_bytes(system.encode())
    (OUT/(qid+'.user.txt')).write_bytes(d['prompt'].encode())
    (OUT/(qid+'.source-pack.json')).write_bytes(p.read_bytes())
    selection.append({'question_id':qid,'source_slot_id':r['slot_id'],'source_order':r['order'],'operator':r['operator'],'arm':r['arm'],'system_sha256':sha(system.encode()),'user_sha256':d['prompt_sha256'],'messages_sha256':d['serialized_messages_sha256'],'source_pack_sha256':sha(p.read_bytes()),'parents':d['parents']})
tasks=[{'question_id':q['question_id'],'model':m,'reasoning_effort':e} for q in selection for m in ['glm-5.3','glm-5.3-flash'] for e in ['low','high','max']]
random.Random(20261007).shuffle(tasks)
for n,t in enumerate(tasks,1): t.update(order=n,task_id=f'a{n:02}')
record={'seed':20261007,'source_roster_sha256':sha((SOURCE/'roster.json').read_bytes()),'source_zip_sha256':'b48fcbf84aab8def4f676d3b12873926683d116c309ccdd3efb5116726a13760','selection_rule':'Sort source_slot_id; Python random.Random(20261007), sequential choice from each EOH e1/e2/m1/m2/m3 stratum (6 per stratum). Sixth is minimum SHA256 of seed ASCII+NUL+sixth+NUL+exact user UTF8+NUL+source_slot_id among the other 55. No results inspected. Task order: Cartesian question/model/effort then separate random.Random(20261007).shuffle.','selection':selection,'tasks':tasks}
(OUT/'selection_and_order.json').write_bytes(canon(record))
print(json.dumps(selection,ensure_ascii=False,indent=2));print('selection/order SHA256',sha(canon(record)))
