# 独立消融中止报告：2/36 已尝试

本轮未完成36项。a01（q06 / GLM-5.3-Flash / max）正常完成；a02（q04 / GLM-5.3 / high）在900秒客户端期限后被终止，未观察到服务端finish_reason或最终usage。按照事前冻结的“不可确认外部终态则停止”规则，后续34项保持未运行。没有补跑、替换任务、切标准付费接口或改变原132主线。

2项各启动OpenCode一次，各观察到1次SDK fetch；底层HTTP/网络尝试次数unknown。两项实际请求体均核对指定模型/档位、max_tokens=64000、temperature=0.7、top_p=0.9、工具数0以及冻结system/user全文。仅2个已派发条件有实际发送证据，其余34个未派发；不能声称完成跨两模型三档的完整实测一致性核验。服务端内部effort执行方式及输出上限执行行为未独立观察。

a01严格格式和原AST/接口准入通过，源码286B，SHA256 `c97204b5ae5f7c577ef8255a8dfb75b32093352d21a658c1704b1ba96332ec70`。3个公开design前1000件的used_bins为412/404/411，对应L1为404/397/399；汇总超额2.25%。数值总CPU含准备与整个评分树为8.747161秒，低于600秒门禁。a02无公开候选输出，未评分；34项未运行，未评分。

实际账户扣积分及总成本unknown。只有a01的完整usage可估算积分；a02最终usage缺失，因此该估计不涵盖全轮成本。没有完成同题跨条件配对，不能比较模型/档位、更不能给出赢家。

最终冻结SHA256：`fe50f24271630d269dbddc7582f1195ecac25624086161051c99d186767097b3`。首次预检因支持文档mapping/source-pins并行更新而在CLI启动前拦住；保留首次FREEZE，刷新支持pins后才启动a01，选题、顺序、system/user与实验条件没有改变。

固定计划 36 项（2 模型 × 3 档位 × 6 题），已尝试 2 项；完成 1，失败 1（普通失败 0、超时 1、截断 0），未运行 34，已启动结果未知 0。

本统计只读取本独立目录的冻结任务和真实记录；原 132 主线未纳入。未启动的阻塞任务保留为 not_run。观察到的是 SDK fetch 调用次数，底层 HTTP/网络请求次数与 SDK 内部重试行为均为 unknown。

选题种子 `20261007`；P2 输入 SHA256 `b48fcbf84aab8def4f676d3b12873926683d116c309ccdd3efb5116726a13760`。选题与顺序文件 SHA256 `8b74841f8b415e6cbc336585abe7dfb3e2cb89cb3c378f900b925f73c2605594`。

六个条件的计划样本数均为6，实际尝试数见下表。以下耗时包括所有有耗时终态的已尝试任务，包含失败、超时和截断；缺失耗时不填零。

| 模型 | 档位 | n | attempted | completed | failed | timeout | truncation | not_run | unknown | 耗时观测n | 平均秒 | 中位秒 | SDK fetch观测 |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| glm-5.3 | low | 6 | 0 | 0 | 0 | 0 | 0 | 6 | 0 | 0 | unknown | unknown | 0 |
| glm-5.3 | high | 6 | 1 | 0 | 1 | 1 | 0 | 5 | 0 | 1 | 900.392 | 900.392 | 1 |
| glm-5.3 | max | 6 | 0 | 0 | 0 | 0 | 0 | 6 | 0 | 0 | unknown | unknown | 0 |
| glm-5.3-flash | low | 6 | 0 | 0 | 0 | 0 | 0 | 6 | 0 | 0 | unknown | unknown | 0 |
| glm-5.3-flash | high | 6 | 0 | 0 | 0 | 0 | 0 | 6 | 0 | 0 | unknown | unknown | 0 |
| glm-5.3-flash | max | 6 | 1 | 1 | 0 | 0 | 0 | 5 | 0 | 1 | 286.456 | 286.456 | 1 |

原始服务端 usage 已观察到 1 次 fetch 的末项记录。每次 fetch 只取最后一个 usage 快照；每任务最后一个 fetch 的原始 usage 另列于 all36.csv/summary.json。不使用字符数或 CLI 归一化 token 替代服务端 usage；缺失字段保留 unknown。

仅对已观察 usage，估计基础积分为 12.369，按官方非高峰规则估计积分为 6.185。实际账户扣积分与实际成本均为 unknown。缓存分项缺失时仅作无缓存假设估算；假设标准 prompt_tokens 包含缓存命中 token。仅应用已核实的非高峰/节日50%规则，不把夜间额度翻倍活动换算为实扣折扣；估算不是账户账单。[官方积分系数](https://docs.bigmodel.cn/cn/coding-plan/overview)：GLM-5.3 输入/缓存/输出 6.9/1.7/24，Flash 为 2.3/0.56/8，除以10000。

准入/评分说明文件覆盖 36 项任务，实际评估接口/准入尝试 1 项，完整公开3case计分 1 项，实测完整 case 分值 3 个。只应解释为事前固定公开 design 序列各前1000件上的评分；没有读取 heldout，也不替代主线5000件得分。具体 AST/接口准入与每 case 结果保留于 summary.json。

事前设计每条件n=6，本轮实际仅完成1项、超时1项，消融比较未完成；不宣称显著差异、稳定赢家或同 token 上限对应相同真实算力。

## 所有36项

| 顺序 | 任务 | 题目 | 模型 | 档位 | attempted | 终态 | 退出码 | 秒 | finish_reason | usage末项 | SDK fetch观测 | 准入/评分 |
|---:|---|---|---|---|---|---|---:|---:|---|---|---:|---|
| 1 | a01 | q06 | glm-5.3-flash | max | True | completed | 0 | 286.456 | stop | {"prompt_tokens":4510,"completion_tokens":14165,"total_tokens":18675,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":13773}} | 1 | ast_passed/complete |
| 2 | a02 | q04 | glm-5.3 | high | True | timeout | -15 | 900.392 | unknown | unknown | 1 | not_run/not_run |
| 3 | a03 | q06 | glm-5.3 | low | False | not_run | unknown | unknown | unknown | unknown | 0 | not_run/not_run |
| 4 | a04 | q02 | glm-5.3-flash | high | False | not_run | unknown | unknown | unknown | unknown | 0 | not_run/not_run |
| 5 | a05 | q01 | glm-5.3 | max | False | not_run | unknown | unknown | unknown | unknown | 0 | not_run/not_run |
| 6 | a06 | q05 | glm-5.3-flash | max | False | not_run | unknown | unknown | unknown | unknown | 0 | not_run/not_run |
| 7 | a07 | q04 | glm-5.3 | max | False | not_run | unknown | unknown | unknown | unknown | 0 | not_run/not_run |
| 8 | a08 | q03 | glm-5.3 | low | False | not_run | unknown | unknown | unknown | unknown | 0 | not_run/not_run |
| 9 | a09 | q02 | glm-5.3 | high | False | not_run | unknown | unknown | unknown | unknown | 0 | not_run/not_run |
| 10 | a10 | q02 | glm-5.3-flash | low | False | not_run | unknown | unknown | unknown | unknown | 0 | not_run/not_run |
| 11 | a11 | q03 | glm-5.3 | high | False | not_run | unknown | unknown | unknown | unknown | 0 | not_run/not_run |
| 12 | a12 | q06 | glm-5.3 | max | False | not_run | unknown | unknown | unknown | unknown | 0 | not_run/not_run |
| 13 | a13 | q02 | glm-5.3-flash | max | False | not_run | unknown | unknown | unknown | unknown | 0 | not_run/not_run |
| 14 | a14 | q04 | glm-5.3-flash | low | False | not_run | unknown | unknown | unknown | unknown | 0 | not_run/not_run |
| 15 | a15 | q01 | glm-5.3 | high | False | not_run | unknown | unknown | unknown | unknown | 0 | not_run/not_run |
| 16 | a16 | q05 | glm-5.3-flash | high | False | not_run | unknown | unknown | unknown | unknown | 0 | not_run/not_run |
| 17 | a17 | q01 | glm-5.3-flash | max | False | not_run | unknown | unknown | unknown | unknown | 0 | not_run/not_run |
| 18 | a18 | q05 | glm-5.3 | high | False | not_run | unknown | unknown | unknown | unknown | 0 | not_run/not_run |
| 19 | a19 | q06 | glm-5.3-flash | high | False | not_run | unknown | unknown | unknown | unknown | 0 | not_run/not_run |
| 20 | a20 | q06 | glm-5.3 | high | False | not_run | unknown | unknown | unknown | unknown | 0 | not_run/not_run |
| 21 | a21 | q01 | glm-5.3 | low | False | not_run | unknown | unknown | unknown | unknown | 0 | not_run/not_run |
| 22 | a22 | q03 | glm-5.3-flash | low | False | not_run | unknown | unknown | unknown | unknown | 0 | not_run/not_run |
| 23 | a23 | q04 | glm-5.3-flash | max | False | not_run | unknown | unknown | unknown | unknown | 0 | not_run/not_run |
| 24 | a24 | q01 | glm-5.3-flash | low | False | not_run | unknown | unknown | unknown | unknown | 0 | not_run/not_run |
| 25 | a25 | q05 | glm-5.3 | low | False | not_run | unknown | unknown | unknown | unknown | 0 | not_run/not_run |
| 26 | a26 | q03 | glm-5.3-flash | max | False | not_run | unknown | unknown | unknown | unknown | 0 | not_run/not_run |
| 27 | a27 | q03 | glm-5.3-flash | high | False | not_run | unknown | unknown | unknown | unknown | 0 | not_run/not_run |
| 28 | a28 | q06 | glm-5.3-flash | low | False | not_run | unknown | unknown | unknown | unknown | 0 | not_run/not_run |
| 29 | a29 | q05 | glm-5.3 | max | False | not_run | unknown | unknown | unknown | unknown | 0 | not_run/not_run |
| 30 | a30 | q05 | glm-5.3-flash | low | False | not_run | unknown | unknown | unknown | unknown | 0 | not_run/not_run |
| 31 | a31 | q02 | glm-5.3 | max | False | not_run | unknown | unknown | unknown | unknown | 0 | not_run/not_run |
| 32 | a32 | q02 | glm-5.3 | low | False | not_run | unknown | unknown | unknown | unknown | 0 | not_run/not_run |
| 33 | a33 | q04 | glm-5.3 | low | False | not_run | unknown | unknown | unknown | unknown | 0 | not_run/not_run |
| 34 | a34 | q01 | glm-5.3-flash | high | False | not_run | unknown | unknown | unknown | unknown | 0 | not_run/not_run |
| 35 | a35 | q04 | glm-5.3-flash | high | False | not_run | unknown | unknown | unknown | unknown | 0 | not_run/not_run |
| 36 | a36 | q03 | glm-5.3 | max | False | not_run | unknown | unknown | unknown | unknown | 0 | not_run/not_run |

完整字段、服务端返回 response/model ID、每 fetch usage 和评分见 `all36.csv`、`condition_summary.csv`、`summary.json`。
