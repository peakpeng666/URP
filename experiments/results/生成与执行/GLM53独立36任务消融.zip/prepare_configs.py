import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def canon(x):return json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()
plan=json.loads((ROOT/'protocol/selection_and_order.json').read_bytes())
template=json.loads((ROOT/'inputs/P2/original132_phase2_continuation_draft_20261006/inputs/config.raw.json').read_bytes())
pins=[]
for task in plan['tasks']:
    c=json.loads(json.dumps(template))
    m=task['model'];e=task['reasoning_effort']
    old=c['provider']['zhipuai-coding-plan']['models']['glm-5.3']
    old['name']=m
    old['limit']['output']=64000
    old['options']['reasoningEffort']=e
    old['variants']={v:{'reasoningEffort':v} for v in ['low','high','max']}
    c['provider']['zhipuai-coding-plan']['models']={m:old}
    c['provider']['zhipuai-coding-plan']['npm']='@ai-sdk/openai-compatible'
    c['provider']['zhipuai-coding-plan']['options']['baseURL']='ABLATION_PLUGIN_REQUIRED'
    c['provider']['zhipuai-coding-plan']['options'].update(timeout=900000,headerTimeout=900000,chunkTimeout=900000)
    c['model']=c['small_model']='zhipuai-coding-plan/'+m
    c['plugin']=['file://'+str(ROOT/'source_audit/ablation-recorder.mjs')]
    p=ROOT/'protocol'/('config-'+task['task_id']+'.json')
    data=canon(c);p.write_bytes(data)
    pins.append({'task_id':task['task_id'],'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
(ROOT/'protocol/config_pins.json').write_bytes(canon(pins))
print('36 explicit model/effort config files prepared; key is only env placeholder')
