#!/usr/bin/env python3
"""Unfrozen descriptive paired tables from recorded rows; no scoring or requests."""
import argparse
import itertools
import json
import statistics
from pathlib import Path


def measured_gap(row):
    from summarize import number
    if not row.get("score_observed") or row.get("code_admission") != "ast_passed" or row.get("evaluation_status") != "complete":
        return None
    for entry in reversed(row.get("evaluation_records", [])):
        gap = number(entry.get("data", {}).get("report_gap_percent"))
        if gap is not None:
            return gap
    return None


def build_paired_tables(rows):
    from summarize import MODELS, EFFORTS, number
    conditions = [(model, effort) for model in MODELS for effort in EFFORTS]
    questions = sorted({r["question_id"] for r in rows})
    index = {(r["question_id"], r["model"], r["reasoning_effort"]): r for r in rows}
    table = []
    coverage = []
    for question in questions:
        for model, effort in conditions:
            r = index[(question, model, effort)]
            gap = measured_gap(r)
            table.append({
                "question_id": question, "model": model, "reasoning_effort": effort, "task_id": r["task_id"],
                "planned": True, "attempted": r["attempted"], "generation_outcome": r["outcome"],
                "wall_seconds": r["wall_seconds"], "usage_last_raw": r["usage_last_raw"],
                "prompt_tokens_observed_sum": r["prompt_tokens_observed_sum"],
                "completion_tokens_observed_sum": r["completion_tokens_observed_sum"],
                "code_admission": r["code_admission"], "evaluation_status": r["evaluation_status"],
                "evaluation_attempted": r["evaluation_attempted"], "complete_case_scores": r["complete_case_scores"],
                "score_observed": r["score_observed"], "public_3x1000_gap_percent": gap,
                "paired_score_eligible": gap is not None,
            })
    for model, effort in conditions:
        subset = [r for r in rows if r["model"] == model and r["reasoning_effort"] == effort]
        coverage.append({"model": model, "reasoning_effort": effort, "planned_n": 6,
                         "attempted": sum(r["attempted"] for r in subset), "completed": sum(r["completed"] for r in subset),
                         "failed": sum(r["failed"] for r in subset), "not_run": sum(r["not_run"] for r in subset),
                         "unknown": sum(r["outcome"] == "unknown" for r in subset),
                         "admitted": sum(r["code_admission"] == "ast_passed" for r in subset),
                         "scored": sum(r["score_observed"] for r in subset),
                         "paired_score_eligible": sum(measured_gap(r) is not None for r in subset)})
    pairs = []
    for left, right in itertools.combinations(conditions, 2):
        available = []
        for question in questions:
            a, b = index[(question, *left)], index[(question, *right)]
            ga, gb = measured_gap(a), measured_gap(b)
            if ga is None or gb is None:
                continue
            wa, wb = number(a["wall_seconds"]), number(b["wall_seconds"])
            available.append({"question_id": question, "task_a": a["task_id"], "task_b": b["task_id"],
                              "gap_a_percent": ga, "gap_b_percent": gb, "gap_a_minus_b_percentage_points": ga - gb,
                              "wall_a_seconds": wa, "wall_b_seconds": wb,
                              "wall_a_minus_b_seconds": wa - wb if wa is not None and wb is not None else None,
                              "generation_outcome_a": a["outcome"], "generation_outcome_b": b["outcome"]})
        differences = [x["gap_a_minus_b_percentage_points"] for x in available]
        pairs.append({"condition_a": "/".join(left), "condition_b": "/".join(right), "planned_pair_n": 6,
                      "available_pair_count": len(available), "available_questions": [x["question_id"] for x in available],
                      "mean_gap_a_minus_b_percentage_points": statistics.mean(differences) if differences else None,
                      "median_gap_a_minus_b_percentage_points": statistics.median(differences) if differences else None,
                      "paired_rows": available})
    return {"schema": "independent-ablation-paired-public-score-tables-v1", "planned_questions": 6,
            "planned_condition_rows": 36, "rows": table, "condition_coverage": coverage, "pair_comparisons": pairs,
            "eligibility_rule": "Same frozen question; both AST admitted; complete actual 3x1000 scoring receipt; finite observed report_gap_percent. A valid scored truncated generation retains its truncation flag. No imputation of failure/timeouts as zero.",
            "interpretation": "Descriptive screening only, planned n=6; report actual paired count. No significance or stable-winner claim; identical token cap does not imply identical realized compute."}


def render_paired_tables(data):
    from summarize import cell
    lines = ["", "## 每题六条件与可用配对", "", "每题保留六个冻结条件；失败、超时和未运行的分值均为unknown，不填零。"
             "只有同一题双方AST准入且真实完成3×1000评分、gap已观察，才进入配对。合法且已完整评分的截断输出仍保留truncation标记。", "",
             "| 题目 | 模型 | effort | 任务 | 状态 | 秒 | 服务端usage末项 | AST准入 | 评分状态 | 3×1000 gap% |",
             "|---|---|---|---|---|---:|---|---|---|---:|"]
    for row in data["rows"]:
        usage = json.dumps(row["usage_last_raw"], ensure_ascii=False, separators=(",", ":")) if row["usage_last_raw"] is not None else "unknown"
        fields = [row[x] for x in ("question_id", "model", "reasoning_effort", "task_id", "generation_outcome", "wall_seconds")]
        fields += [usage, row["code_admission"], row["evaluation_status"], row["public_3x1000_gap_percent"]]
        lines.append("| " + " | ".join(map(cell, fields)) + " |")
    lines += ["", "各条件分母：", "", "| 条件 | planned | attempted | completed | admitted | scored | 失败 | 未运行 | 未知终态 |",
              "|---|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for row in data["condition_coverage"]:
        fields = [row["model"] + "/" + row["reasoning_effort"]] + [row[x] for x in ("planned_n", "attempted", "completed", "admitted", "scored", "failed", "not_run", "unknown")]
        lines.append("| " + " | ".join(map(cell, fields)) + " |")
    lines += ["", "配对结果仅描述已观测小样本。A−B gap为百分点，较低gap较好；不足配对时不报告差值。", "",
              "| 条件A | 条件B | 计划同题对数 | 可用同题对数 | 平均gap A−B（百分点） |", "|---|---|---:|---:|---:|"]
    for pair in data["pair_comparisons"]:
        fields = [pair[x] for x in ("condition_a", "condition_b", "planned_pair_n", "available_pair_count", "mean_gap_a_minus_b_percentage_points")]
        lines.append("| " + " | ".join(map(cell, fields)) + " |")
    lines += ["", "n=6仅用于筛选；可用对数低于6时不能按完整配对解释。未做显著性或稳定赢家判断。", ""]
    return "\n".join(lines)


def write_outputs(data, out):
    from summarize import write_csv
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    (out / "paired_tables.json").write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (out / "paired_tables.md").write_text(render_paired_tables(data), encoding="utf-8")
    write_csv(out / "paired_question_rows.csv", data["rows"])
    write_csv(out / "paired_comparisons.csv", data["pair_comparisons"])


def main():
    from summarize import evaluation_index, task_row
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    root = args.root
    plan = json.loads((root / "protocol/selection_and_order.json").read_text())
    selections = {x["question_id"]: x for x in plan.get("selection", [])}
    evaluations = evaluation_index(root, [])
    rows = [task_row(root, task, selections, evaluations) for task in plan["tasks"]]
    data = build_paired_tables(rows)
    write_outputs(data, args.out or root / "reporting")
    print(json.dumps({"planned_condition_rows": 36, "pair_comparisons": 15,
                      "available_pair_count_total": sum(p["available_pair_count"] for p in data["pair_comparisons"])}))


if __name__ == "__main__":
    main()
