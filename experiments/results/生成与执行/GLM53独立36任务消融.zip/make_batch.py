import hashlib,json,os,sys,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
count=int(sys.argv[1]);assert count in [6,12,18,24,30,36]
plan=json.loads((ROOT/'protocol/selection_and_order.json').read_bytes())
batch=(count//6);chosen=plan['tasks'][count-6:count]
assert all((ROOT/'raw'/t['task_id']/'terminal.json').exists() for t in chosen)
outdir=ROOT/'batches';outdir.mkdir(exist_ok=True)
out=outdir/(f'GLM53消融_第{batch:02}批_累计{count:02}终态_20261007.zip')
assert not out.exists(),'Do not overwrite a delivered batch'
files=[p for p in (ROOT/'protocol').glob('*') if p.is_file()]
files += [ROOT/n for n in ['environment_evidence.json','request_audit.json','report.md','all36.csv','condition_summary.csv','summary.json'] if (ROOT/n).exists()]
for t in chosen:
 files += [p for p in (ROOT/'raw'/t['task_id']).rglob('*') if p.is_file() and 'runtime' not in p.parts]
values=[os.environ[n].encode() for n in ['ZHIPU_API_KEY','HTTP_PROXY','HTTPS_PROXY','http_proxy','https_proxy'] if os.environ.get(n) and len(os.environ[n])>=8]
pins={}
for p in files:
 d=p.read_bytes();assert not any(v in d for v in values),'Secret literal present; no upload'
 pins[str(p.relative_to(ROOT))]={'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()}
manifest={'batch':batch,'cumulative_terminal_count':count,'tasks_in_this_batch':chosen,'scope':'generation raw receipts only; scoring follows after generation; cumulative statistics include failures and unstarted rows; full source/binary ZIP follows at final handoff','credential_scan_passed':True,'files':pins}
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(set(files)):z.write(p,str(p.relative_to(ROOT)))
 z.writestr('BATCH_MANIFEST.json',json.dumps(manifest,ensure_ascii=False,sort_keys=True,indent=2))
result={'batch':batch,'path':str(out),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'cumulative_terminals':count}
(outdir/f'batch{batch:02}.pin.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result,ensure_ascii=False))
