#!/usr/bin/env python3
"""Unfrozen reporting only: operational evidence and historical delivery ledger."""
import argparse
import datetime as dt
import difflib
import hashlib
import json
import re
from pathlib import Path


def read_json(path):
    if not path.is_file():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (ValueError, OSError):
        return {}


def pin(path):
    if not path.is_file():
        return None
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def pin_group(old, new, names):
    names = sorted(names)
    return {"pin_count": len(names), "unchanged_between_freezes": all(old.get(n) == new.get(n) for n in names),
            "changed_files": [n for n in names if old.get(n) != new.get(n)]}


def administrative_manager_revision(root):
    path = root / "evaluation/history_checkpoint2/MANIFEST.json"
    manifest = read_json(path)
    if not manifest:
        return None
    protected = manifest.get("protected_before_and_after_identical", {})
    fixed_checks = []
    for name in ("evaluate_candidate.py", "evaluation_protocol.json", "public_design_prefixes.json",
                 "runtime/admission.py", "runtime/policy.py", "runtime/runner.py", "runtime/worker.py",
                 "runtime/checker.py", "runtime/CONTRACT.json", "runtime/ISOLATION.json"):
        expected = protected.get(name)
        fixed_checks.append({"file": "evaluation/" + name, "migration_protected_pin": expected,
                             "current_bytes_match_migration_pin": expected is not None and pin(root / "evaluation" / name) == expected})
    real_record_checks = []
    for name in ("results/a01/assessment.json", "results/a02/assessment.json"):
        expected = protected.get(name)
        real_record_checks.append({"file": "evaluation/" + name, "migration_protected_pin": expected,
                                   "current_bytes_match_migration_pin": expected is not None and pin(root / "evaluation" / name) == expected})
    moved = []
    for item in manifest.get("moved_unstarted_wrappers", []):
        if not isinstance(item, dict) or not re.fullmatch(r"a[0-9]{2}", str(item.get("task_id", ""))):
            continue
        moved.append({k: item[k] for k in ("task_id", "original", "archived", "assessment_pin") if k in item})
    return {
        "manifest": "evaluation/history_checkpoint2/MANIFEST.json", "manifest_pin": pin(path),
        "migration_utc_from_manifest": manifest.get("utc", "unknown"),
        "wrapper_revision_exact_write_utc": "unknown; no historical wrapper-write timestamp inferred",
        "current_wrapper": "assess_results.py", "current_wrapper_pin": pin(root / "assess_results.py"),
        "current_wrapper_pin_observed_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "fixed_safe_evaluator_boundary": "Safe numeric evaluator/interface/runtime, public3x1000 panel and fixed CPU/memory/time gates stay fixed; administrative reporting/dispatch wrapper changed to incremental management.",
        "purpose": "Archive historical checkpoint2 not_run placeholders so their directory presence cannot suppress first evaluation of a newly terminal admissible task; retain consumed real score identities.",
        "moved_historical_placeholder_count": len(moved), "moved_historical_placeholders": moved,
        "actual_scoring_invocations_during_migration_as_recorded": manifest.get("actual_scoring_invocations", "unknown"),
        "candidate_code_changes_as_recorded": manifest.get("candidate_code_changes", "unknown"),
        "model_content_reads_for_decision_as_recorded": manifest.get("model_content_reads_for_decision", "unknown"),
        "previous_aggregate_pin": manifest.get("previous_aggregate_pin"),
        "protected_fixed_current_byte_checks": fixed_checks,
        "existing_a01_a02_current_byte_checks": real_record_checks,
        "budget_pin_preserved_at_migration_from_manifest": protected.get("budget.json"),
        "budget_scope_note": "The manifest records unchanged budget bytes during migration. Budget is mutable afterward as new evaluations consume CPU; current budget is not asserted equal to this historical pin.",
        "observation_scope": "Zero scoring calls/code changes/content reads are statements preserved from the migration manifest; this reporting generator does not execute scoring or model calls.",
    }


def receipt_deliveries(root, path, final=False):
    """Positive receipt schema; intentionally ignore all URL and people fields."""
    data = read_json(path)
    if not isinstance(data, dict):
        return []
    records = []
    if data.get("drive_file_id", data.get("file_id")):
        records.append(data)
    for key in ("report", "zip", "ZIP", "deliveries", "artifacts", "files"):
        nested = data.get(key)
        if isinstance(nested, list):
            records.extend(x for x in nested if isinstance(x, dict))
        elif isinstance(nested, dict):
            if nested.get("drive_file_id", nested.get("file_id")):
                records.append(dict(nested, kind=nested.get("kind", key)))
            else:
                records.extend(dict(value, kind=value.get("kind", name)) for name, value in nested.items() if isinstance(value, dict))
    deliveries = []
    for record in records:
        file_id = record.get("drive_file_id", record.get("file_id"))
        if not isinstance(file_id, str) or not re.fullmatch(r"[A-Za-z0-9_-]{10,}", file_id):
            continue
        digest = record.get("sha256", record.get("local_sha256"))
        if not isinstance(digest, str) or not re.fullmatch(r"[0-9a-fA-F]{64}", digest):
            digest = "unknown"
        verified = record.get("byte_readback_verified", record.get("remote_readback_verified", record.get("readback_verified", "unknown")))
        owner_only = record.get("owner_only_metadata_verified", record.get("owner_only_observed", record.get("owner_only", "unknown")))
        verified = verified if isinstance(verified, bool) else "unknown"
        owner_only = owner_only if isinstance(owner_only, bool) else "unknown"
        batch = record.get("batch", data.get("batch"))
        cumulative = record.get("cumulative_terminals", data.get("cumulative_terminals"))
        batch = batch if isinstance(batch, int) and not isinstance(batch, bool) and 1 <= batch <= 6 else None
        cumulative = cumulative if isinstance(cumulative, int) and not isinstance(cumulative, bool) and 0 <= cumulative <= 36 else "unknown"
        verified_utc = record.get("verified_utc", data.get("verified_utc", "unknown"))
        try:
            dt.datetime.fromisoformat(verified_utc.replace("Z", "+00:00"))
        except (AttributeError, TypeError, ValueError):
            verified_utc = "unknown"
        source = record.get("path", record.get("local_source_file"))
        local_source = "unknown"
        if isinstance(source, str) and not any(marker in source for marker in ("://", "?", "&", "@")) and ".." not in Path(source).parts:
            try:
                local_source = str(Path(source).relative_to(root)) if Path(source).is_absolute() else source
            except ValueError:
                local_source = "path_outside_experiment_not_copied"
        kind = record.get("kind")
        if kind not in {"report", "zip", "ZIP", "Chinese_report", "full_ZIP", "batch_ZIP", "final_artifact", "final_report", "final_ZIP"}:
            kind = "final_artifact" if final else "batch_ZIP"
        size = record.get("bytes", record.get("size"))
        if isinstance(size, str) and size.isdigit():
            size = int(size)
        if not isinstance(size, int) or isinstance(size, bool) or size < 0:
            size = "unknown"
        entry = {
            "snapshot": "final_delivery_receipt" if final else f"batch{batch:02d}_cumulative{cumulative}_terminals" if isinstance(batch, int) else path.stem,
            "kind": kind,
            "planned": 36, "file_id": file_id, "bytes": size,
            "local_sha256": digest, "remote_sha256": digest if verified is True and digest != "unknown" else "unknown",
            "remote_readback_verified": verified, "owner_only_observed": owner_only,
            "metadata_size_verified": record.get("metadata_size_verified", "unknown"),
            "verification_actor": "root", "provenance": str(path.relative_to(root)),
            "local_source_file": local_source, "batch_number": batch,
            "cumulative_terminal_count": cumulative, "verified_utc": verified_utc,
            "is_final_delivery_receipt": final,
        }
        if isinstance(record.get("terminal_task_ids"), list):
            entry["terminal_task_ids"] = [task for task in record["terminal_task_ids"] if isinstance(task, str) and re.fullmatch(r"a[0-9]{2}", task)]
        for key in ("attempted", "completed", "timeout_failed", "not_run"):
            if isinstance(record.get(key), int):
                entry[key] = record[key]
        deliveries.append(entry)
    return deliveries


def local_batch_archives(root):
    """Local archive pins are evidence of local bytes, never Drive delivery."""
    archives = []
    for path in sorted((root / "batches").glob("batch*.pin.json")):
        record = read_json(path)
        batch = record.get("batch")
        source = record.get("path")
        if not isinstance(batch, int) or isinstance(batch, bool) or not 1 <= batch <= 6 or not isinstance(source, str):
            continue
        if any(marker in source for marker in ("://", "?", "&", "@")) or ".." in Path(source).parts:
            continue
        source_path = Path(source)
        if not source_path.is_absolute():
            source_path = root / source_path
        try:
            local_name = str(source_path.relative_to(root))
        except ValueError:
            continue
        digest, size = record.get("sha256"), record.get("bytes")
        if not isinstance(digest, str) or not re.fullmatch(r"[0-9a-fA-F]{64}", digest):
            continue
        if not isinstance(size, int) or isinstance(size, bool) or size < 0:
            continue
        expected = {"bytes": size, "sha256": digest.lower()}
        observed = pin(source_path)
        cumulative = record.get("cumulative_terminals")
        if not isinstance(cumulative, int) or isinstance(cumulative, bool) or not 0 <= cumulative <= 36:
            cumulative = "unknown"
        receipt_path = path.with_name(path.name.replace(".pin.json", ".delivery.json"))
        receipt_observed = bool(receipt_deliveries(root, receipt_path))
        archives.append({"batch_number": batch, "cumulative_terminal_count": cumulative,
                         "local_source_file": local_name, "pin_file": str(path.relative_to(root)),
                         "expected_pin": expected, "current_local_bytes_pin": observed,
                         "current_local_bytes_match_pin": observed == expected,
                         "delivery_receipt_observed": receipt_observed,
                         "remote_byte_verification": "see separate delivery receipt" if receipt_observed else "unknown; delivery receipt not observed",
                         "absence_of_receipt_does_not_establish_no_upload": True})
    return archives


def handoff_operational_status(root):
    """Authorization to resume is separate from observed upload verification."""
    resume = read_json(root / "DRIVE_WRITES_RESUMED.json")
    resume = {k: v for k, v in resume.items() if k in {"utc", "data_folder", "report_audit_folder",
              "both_parent", "owner_only_verified", "model_dispatch_stopped"}}
    correction = read_json(root / "PACKAGING_CORRECTION.json")
    correction = {k: v for k, v in correction.items() if k in {"utc", "issue", "fix", "unchanged",
                  "earlier_local_builds_preserved_outside_final_payload_root", "old_builds_moved", "final_rebuild_not_yet_uploaded"}}
    batch_entries = []
    for path in sorted((root / "batches").glob("*.delivery.json")):
        batch_entries.extend(receipt_deliveries(root, path))
    observed_batches = sorted({item["batch_number"] for item in batch_entries if item.get("batch_number") is not None})
    verified_batches = sorted({item["batch_number"] for item in batch_entries if item.get("batch_number") is not None
                              and item.get("remote_readback_verified") is True and item.get("owner_only_observed") is True
                              and item.get("remote_sha256") != "unknown"})
    final_paths = set()
    for folder in (root, root / "reporting", root / "deliveries", root / "delivery"):
        if folder.is_dir():
            final_paths.update(path for path in folder.glob("*.json")
                               if path.name.lower().startswith("final") and any(term in path.name.lower() for term in ("delivery", "receipt")))
    final_entries = []
    for path in sorted(final_paths):
        final_entries.extend(receipt_deliveries(root, path, final=True))
    return {"schema": "independent-ablation-handoff-operational-status-v1",
            "Drive_resume_record": resume or None,
            "current_Drive_writes_paused": not bool(resume.get("utc")),
            "current_write_status_provenance": "DRIVE_WRITES_RESUMED.json" if resume else "latest parent pause instruction; no local resume record observed",
            "authorization_is_not_delivery_evidence": True,
            "batch_delivery_receipts_observed": observed_batches,
            "batch_remote_owner_and_bytes_verified": verified_batches,
            "batches_without_verified_remote_receipt": sorted(set(range(1, 7)) - set(verified_batches)),
            "batch_delivery_entries": batch_entries,
            "final_delivery_entries": final_entries,
            "complete_expected_final_artifact_set": "unknown; receipt count alone cannot establish the full artifact set",
            "packaging_correction_record": correction or None}


def controller_boundary_19(root, rows):
    boundary = read_json(root / "CONTROLLER_BOUNDARY_19.json")
    restart = read_json(root / "CONTROLLER_AFTER19_START.json")
    if not boundary and not restart:
        return None
    allowed = {"utc", "prior_controller_pid", "prior_controller_state", "prior_tool_session", "cause",
               "terminal_count", "last_terminal", "next_task", "prior_cli_observed_absent_since",
               "existing_terminal_tasks_relaunched", "frozen_check_passed", "scientific_controls_changed",
               "new_controller_stdout_stderr", "Drive_writes_paused"}
    # Read one observer snapshot once: this file is updated by the external observer.
    observer_path = root / "process_observation/summary.json"
    observer, observer_pin = {}, None
    if observer_path.is_file():
        try:
            raw = observer_path.read_bytes()
            observer = json.loads(raw)
            observer_pin = {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
        except (OSError, ValueError):
            pass
    observed_a19 = observer.get("tasks", {}).get("a19", {})
    observation_fields = {"root_pid", "root_ppid", "root_pgid", "first_seen_utc", "last_seen_utc",
                          "root_first_absent_utc", "terminal_first_seen_utc", "postterminal_absence_samples",
                          "postterminal_cleanup_first_observed_utc", "server_cancellation", "underlying_network_http_attempts"}
    from summarize import summarize_group
    prefix = [row for row in rows if row.get("task_id") in {f"a{i:02d}" for i in range(1, 20)}]
    return {"boundary_record": {k: v for k, v in boundary.items() if k in allowed},
            "restart_record": {k: v for k, v in restart.items() if k in {"utc", "pid", "cli_task_scope", "runner"}},
            "historical_prefix_through_a19_actual_records": summarize_group(prefix),
            "observer_snapshot": {"file": "process_observation/summary.json", "pin": observer_pin,
                                  "last_sample_utc": observer.get("last_sample_utc", "unknown"),
                                  "a19": {k: v for k, v in observed_a19.items() if k in observation_fields}},
            "prior_controller_ppid_at_boundary": "not recorded in these local controller receipts",
            "parent_reported_prior_controller_ppid_at_boundary": {"ppid": 1,
                    "source": "parent delegated task message", "independently_verified_by_this_generator": False},
            "parent_reported_a20_before_resume": {"task_directory_or_cli_started": False,
                    "source": "parent delegated task message", "independently_verified_by_this_generator": False},
            "cause": "unknown; no exception log captured from the expired tool session",
            "observation_scope": "Controller zombie/unknown-session records and external observer client absence do not establish the controller exit mechanism, any remote server cancellation, or network HTTP attempt count. Observer counts refer to its own last_sample_utc, not the earlier boundary timestamp.",
            "observer_time_precision": "Observer UTC fields have one-second precision; a19 root_first_absent_utc 04:04:00Z does not establish a subsecond disappearance instant relative to its terminal ended_utc.",
            "duplicate_batch_pack_requests": {"disposition": "root reported rejection before archive overwrite",
                                               "source": "parent delegated task message; no local rejection receipt observed by this generator",
                                               "independently_verified_rejection": False}}


def build_addendum(root, rows=None):
    root = Path(root).resolve()
    if rows is None:
        from summarize import evaluation_index, task_row
        plan = read_json(root / "protocol/selection_and_order.json")
        selections = {x["question_id"]: x for x in plan.get("selection", [])}
        evaluations = evaluation_index(root, [])
        rows = [task_row(root, task, selections, evaluations) for task in sorted(plan.get("tasks", []), key=lambda x: x["order"])]
    from summarize import summarize_group
    protocol = read_json(root / "protocol/protocol.json")
    amendment = read_json(root / "protocol/OPERATIONAL_AMENDMENT_01.json")
    previous = read_json(root / "protocol/FREEZE.pre_amendment.json")
    current = read_json(root / "protocol/FREEZE.json")
    old, new = previous.get("files", {}), current.get("files", {})
    stop = read_json(root / "STOP.pre_resume.json")
    pause = read_json(root / "PAUSE_AT_NATURAL_BOUNDARY.json")
    resume = read_json(root / "RESUME_AFTER_PARENT_LATEST.json")
    manager_revision = administrative_manager_revision(root)
    controller_boundary = controller_boundary_19(root, rows)
    handoff_status = handoff_operational_status(root)
    by_id = {x["task_id"]: x for x in rows}
    changed = [{"file": name, "before": old.get(name), "after": new.get(name)}
               for name in sorted(set(old) | set(new)) if old.get(name) != new.get(name)]
    groups = {
        "frozen_system_user_contexts": pin_group(old, new, [n for n in old if n.startswith("protocol/q") and n.endswith((".system.txt", ".user.txt"))]),
        "36_model_sampling_configs": pin_group(old, new, [n for n in old if n.startswith("protocol/config-a")]),
        "selection_and_order": pin_group(old, new, ["protocol/selection_and_order.json"]),
        "original_scientific_protocol": pin_group(old, new, ["protocol/protocol.json"]),
        "official_cli_binary": pin_group(old, new, ["pins/opencode"]),
        "recorder_plugin": pin_group(old, new, ["source_audit/ablation-recorder.mjs"]),
        "scoring_control_pins": pin_group(old, new, [n for n in old if n.startswith("evaluation/") and n != "evaluation/budget.json"]),
    }
    primary = [n for n in old if n.startswith("protocol/config-a") or
               (n.startswith("protocol/q") and n.endswith((".system.txt", ".user.txt")))]
    primary += ["protocol/selection_and_order.json", "protocol/protocol.json", "pins/opencode",
                "source_audit/ablation-recorder.mjs", "evaluation/evaluation_protocol.json"]
    byte_checks = [{"file": n, "matches_original_pin": old.get(n) is not None and pin(root / n) == old.get(n)} for n in sorted(set(primary))]
    v1_path, v2_path = root / "run_ablation.v1.py", root / "run_ablation.py"
    diff = None
    v1_stop_block = "unknown"
    if v1_path.is_file() and v2_path.is_file():
        v1_text = v1_path.read_text()
        start = v1_text.find("    if not success:\n")
        end = v1_text.find("        return False\n", start)
        if start >= 0 and end >= 0:
            v1_stop_block = v1_text[start:end + len("        return False\n")]
        diff = "".join(difflib.unified_diff(v1_path.read_text().splitlines(keepends=True),
                                          v2_path.read_text().splitlines(keepends=True),
                                          fromfile="run_ablation.v1.py", tofile="run_ablation.py"))
    events = []
    def event(kind, when, evidence, detail, **extra):
        events.append({"kind": kind, "utc": when or "unknown", "evidence": evidence, "detail": detail, **extra})
    event("initial_freeze", protocol.get("frozen_utc"), "protocol/protocol.json", "36题次/配置及原v1操作策略冻结。")
    for task_id in ("a01", "a02"):
        row = by_id.get(task_id, {})
        if row.get("attempted"):
            event(task_id + "_cli_start", row.get("started_utc"), f"raw/{task_id}/invocation.json", "原v1单次CLI启动。")
        if row.get("terminal_observed"):
            event(task_id + "_client_terminal", row.get("ended_utc"), f"raw/{task_id}/terminal.json",
                  "服务端stop完成。" if row.get("completed") else "客户端超时失败；服务端最终完成与最终usage未知。",
                  outcome=row.get("outcome"), exit_code=row.get("exit_code"), wall_seconds=row.get("wall_seconds"))
    if stop:
        event("v1_stopped_after_a02", stop.get("utc"), "STOP.pre_resume.json", "v1按不成功即停止的实现停止队列；a02保留且不重跑。")
    if amendment:
        event("parent_authorized_operational_v2", amendment.get("utc"), "protocol/OPERATIONAL_AMENDMENT_01.json",
              "父随后授权继续原冻结顺序；特定已观察HTTP200及model/response ID的客户端超时允许调度下一题。该变更发生在观察a02结果之后。",
              authorization_quote=amendment.get("authorization_latest_parent"))
        event("amendment_pin_record_updated", current.get("operational_amendment_01_utc"), "protocol/FREEZE.json",
              "更新runner pin、保存v1/旧freeze/修订记录，去掉误冻结的可变预算账本pin。")
    for task_id in ("a03", "a04"):
        row = by_id.get(task_id, {})
        if row.get("attempted"):
            event(task_id + "_resumed_start", row.get("started_utc"), f"raw/{task_id}/invocation.json", "继续原冻结下一题，既有任务未重启。")
        if row.get("terminal_observed"):
            event(task_id + "_client_terminal", row.get("ended_utc"), f"raw/{task_id}/terminal.json", "保存CLI终态及原始服务端回执。",
                  outcome=row.get("outcome"), wall_seconds=row.get("wall_seconds"))
    if pause:
        event("stale_pause_at_a04_natural_boundary", None, "PAUSE_AT_NATURAL_BOUNDARY.json",
              "旧暂停指令在a04持久终态后作用于串行调度器；记录声明未中断CLI。暂停记录无内部UTC，不能声称准确发信号时间。",
              after_utc=by_id.get("a04", {}).get("ended_utc", "unknown"), before_utc=resume.get("utc", "unknown"),
              cli_interrupted_by_pause=pause.get("CLI_interrupted_by_pause"), terminal_count_at_pause=pause.get("terminal_count"))
    if resume:
        event("latest_parent_resume_before_a05", resume.get("utc"), "RESUME_AFTER_PARENT_LATEST.json",
              "最新父指令继续剩余原36范围；保留a02失败与usage/server终态未知；既有任务不重新启动。",
              authorization_quote=resume.get("latest_parent_instruction"), next_task=resume.get("next_task"))
    if by_id.get("a05", {}).get("attempted"):
        event("a05_actual_start", by_id["a05"].get("started_utc"), "raw/a05/invocation.json", "最新恢复记录之后首次启动a05。")
    if controller_boundary:
        boundary = controller_boundary["boundary_record"]
        restart = controller_boundary["restart_record"]
        if by_id.get("a19", {}).get("terminal_observed"):
            row = by_id["a19"]
            event("a19_client_terminal_before_controller_boundary", row.get("ended_utc"), "raw/a19/terminal.json",
                  "a19已保存真实CLI终态及原始stop回执；后续控制器边界不改变其身份。",
                  outcome=row.get("outcome"), wall_seconds=row.get("wall_seconds"))
        if boundary:
            historical = controller_boundary["historical_prefix_through_a19_actual_records"]
            event("controller_boundary_after_19_terminals", boundary.get("utc"), "CONTROLLER_BOUNDARY_19.json",
                  f"记录当刻已有{boundary.get('terminal_count', 'unknown')}真实终态；原a01–a19记录完成{historical['completed']}项、超时{historical['timeout']}项。旧控制器{boundary.get('prior_controller_pid', 'unknown')}为{boundary.get('prior_controller_state', 'unknown')}，工具会话为unknown process。消失原因unknown，未保存过期会话异常日志。记录声明冻结校验通过、既有任务不重启、Drive写入暂停。",
                  historical_terminal_count=boundary.get("terminal_count"), next_task=boundary.get("next_task"))
        if restart:
            event("unchanged_v2_controller_restart_for_a20_a36", restart.get("utc"), "CONTROLLER_AFTER19_START.json",
                  "以相同pinned v2从a20继续至a36；新控制器PID6186，stdout/stderr重定向本地审计日志；既有终态任务跳过不重跑。")
        if by_id.get("a20", {}).get("attempted"):
            event("a20_actual_start_after_controller_restart", by_id["a20"].get("started_utc"), "raw/a20/invocation.json",
                  "新控制器记录之后单次启动原冻结下一任务a20；历史19终态快照不能当作当前累计终态。")
    correction = handoff_status["packaging_correction_record"]
    if correction:
        event("local_handoff_packaging_correction", correction.get("utc"), "PACKAGING_CORRECTION.json",
              "原本地打包循环误跳过嵌套输入HANDOFF_MANIFEST.json，本地逐件CRC/清单核验在上传前拒绝；改为仅跳过根目录生成清单。旧本地产物另行保留，36生成/评分/控制pin不变，无重跑。")
    drive_resume = handoff_status["Drive_resume_record"]
    if drive_resume:
        event("user_released_Drive_write_pause", drive_resume.get("utc"), "DRIVE_WRITES_RESUMED.json",
              "最新用户解除临时Drive写入暂停；实验资料与报告/审计分入指定私有目录，恢复记录载有owner-only核验。恢复授权本身不证明任何上传或回读完成。")
    if manager_revision:
        manager_event = {"kind": "administrative_evaluation_manager_revision",
                         "utc": manager_revision["migration_utc_from_manifest"],
                         "evidence": manager_revision["manifest"],
                         "detail": "迁移原2/36快照的a03–a36 not_run占位；报告/调度包装器改为增量管理。清单记录评分调用0；固定安全评估器、接口、公开panel与门禁未变。"}
        insertion = len(events)
        if manager_event["utc"] != "unknown":
            try:
                stamp = dt.datetime.fromisoformat(manager_event["utc"].replace("Z", "+00:00"))
                for index, item in enumerate(events):
                    if item["utc"] != "unknown" and dt.datetime.fromisoformat(item["utc"].replace("Z", "+00:00")) > stamp:
                        insertion = index
                        break
            except (AttributeError, TypeError, ValueError):
                pass
        events.insert(insertion, manager_event)
    receipts = {}
    for rel in ["run_ablation.v1.py", "run_ablation.py", "protocol/protocol.json", "protocol/selection_and_order.json",
                "protocol/FREEZE.pre_amendment.json", "protocol/FREEZE.json", "protocol/OPERATIONAL_AMENDMENT_01.json",
                "STOP.pre_resume.json", "PAUSE_AT_NATURAL_BOUNDARY.json", "RESUME_AFTER_PARENT_LATEST.json",
                "CONTROLLER_BOUNDARY_19.json", "CONTROLLER_AFTER19_START.json", "DRIVE_WRITES_RESUMED.json", "PACKAGING_CORRECTION.json"]:
        receipts[rel] = pin(root / rel)
    historical = read_json(root / "reporting/historical_delivery_evidence.json")
    checkpoint = read_json(root / "checkpoint_01_readback.json")
    if checkpoint:
        perms = checkpoint.get("permissions") or []
        historical.setdefault("deliveries", []).insert(0, {
            "snapshot": "checkpoint_01_one_terminal", "kind": "checkpoint_zip", "planned": 36,
            "terminal_task_ids": checkpoint.get("terminal_task_ids"), "file_id": checkpoint.get("file_id"),
            "bytes": checkpoint.get("bytes"), "local_sha256": checkpoint.get("sha256"),
            "remote_sha256": checkpoint.get("sha256") if checkpoint.get("readback_verified") is True else "unknown",
            "remote_readback_verified": checkpoint.get("readback_verified", "unknown"),
            "owner_only_observed": bool(perms) and all(isinstance(p, dict) and p.get("role") == "owner" for p in perms),
            "provenance": "checkpoint_01_readback.json; copied numeric/digest/file-ID evidence only",
        })
    # Positive schema: no signed download URLs, people, permission IDs or recipients.
    allowed = {"snapshot", "kind", "planned", "attempted", "completed", "timeout_failed", "not_run", "terminal_task_ids",
               "file_id", "bytes", "local_sha256", "remote_sha256", "remote_readback_verified", "owner_only_observed",
               "metadata_size_verified", "provenance", "verification_actor", "remote_sha_blocker", "local_source_file",
               "local_file_may_be_overwritten_at_final", "batch_number", "cumulative_terminal_count", "verified_utc", "is_final_delivery_receipt"}
    deliveries = [{k: v for k, v in item.items() if k in allowed} for item in historical.get("deliveries", []) if isinstance(item, dict)]
    for path in sorted((root / "batches").glob("*.delivery.json")):
        deliveries.extend(receipt_deliveries(root, path))
    final_paths = set()
    for folder in (root, root / "reporting", root / "deliveries", root / "delivery"):
        if not folder.is_dir():
            continue
        for path in folder.glob("*.json"):
            name = path.name.lower()
            if name.startswith("final") and ("delivery" in name or "receipt" in name):
                final_paths.add(path)
    for path in sorted(final_paths):
        deliveries.extend(receipt_deliveries(root, path, final=True))
    final_entries = [item for item in deliveries if item.get("is_final_delivery_receipt") is True]
    final_status = "not_established_by_this_ledger"
    if final_entries:
        final_status = "observed_final_receipts_remote_bytes_verified" if all(item.get("remote_readback_verified") is True and item.get("remote_sha256") != "unknown" for item in final_entries) else "final_receipts_present_verification_incomplete"
    ledger = {
        "schema": "independent-ablation-historical-delivery-ledger-v1",
        "deliveries": deliveries, "signed_urls_recorded": False, "account_or_recipient_fields_recorded": False,
        "local_batch_archives": local_batch_archives(root),
        "local_archive_scope": "Local ZIP pins are kept separately from verified Drive deliveries. Missing delivery receipts leave remote bytes/ownership unknown and do not prove no upload occurred.",
        "current_handoff_operational_status": handoff_status,
        "historical_snapshot_note": "2/36 snapshot is historical; remote file remains that snapshot even if the identically named local ZIP is rebuilt at final.",
        "final_snapshot_delivery_status": final_status,
        "final_delivery_receipts_observed": len(final_entries),
        "complete_expected_final_artifact_set": "unknown; receipt count alone does not establish the entire expected final set",
    }
    a02 = by_id.get("a02", {})
    return {
        "schema": "independent-ablation-operational-report-addendum-v1", "generated_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "original_stop_policy_quote": protocol.get("stop_policy", "unknown"),
        "original_v1_implementation_quote": v1_stop_block,
        "midrun_deviation": "Operational stop/continue rule changed after two observed task terminals; this was not part of the original prefreeze policy. Original scientific inputs/order/model parameters/scoring controls retain their pins.",
        "v2_declared_effective_utc": amendment.get("utc", "unknown"), "v2_pin_update_utc": current.get("operational_amendment_01_utc", "unknown"),
        "chronology": events, "runner_unified_diff": diff, "evidence_pins": receipts, "freeze_pin_changes": changed,
        "scientific_pin_groups": groups, "primary_control_current_byte_checks": byte_checks,
        "scientific_common_pins_unchanged": bool(old and new) and all(g["unchanged_between_freezes"] for g in groups.values()),
        "primary_current_bytes_match_original_pins": all(x["matches_original_pin"] for x in byte_checks),
        "mutable_budget_pin_removal": "evaluation/budget.json administrative mutable ledger pin removed; numerical600CPU evaluation protocol remains unchanged. Amendment states failed preflight launched no CLI; preflight itself not independently observed by this reporting code.",
        "administrative_evaluation_manager_revision": manager_revision,
        "controller_boundary_after19": controller_boundary,
        "handoff_operational_status": handoff_status,
        "a02_timeout_observation": {"client_outcome": a02.get("outcome", "unknown"), "wall_seconds": a02.get("wall_seconds"),
            "sdk_fetch_calls_observed": a02.get("sdk_fetch_calls_observed", 0), "provider_response_ids_observed": a02.get("provider_response_ids", []),
            "provider_model_ids_observed": a02.get("provider_model_ids", []), "finish_reasons_observed": a02.get("finish_reasons", []),
            "usage_snapshots_observed": a02.get("usage_last_raw"), "final_service_usage": "unknown", "server_completion_state": "unknown",
            "underlying_network_request_count": "unknown", "actual_cost": "unknown"},
        "current_totals": summarize_group(rows),
        "current_condition_coverage": [summarize_group([r for r in rows if r["model"] == m and r["reasoning_effort"] == e], m, e)
                                       for m in ("glm-5.3", "glm-5.3-flash") for e in ("low", "high", "max")],
        "delivery_ledger": ledger,
        "external_observer_note": {k: v for k, v in historical.get("observer_note", {}).items() if k in {
            "provenance", "a05_pid_observed", "a05_ppid_observed", "a05_pgid_observed", "socket_fd_state", "a02_pid",
            "server_cancellation_or_completion"}},
        "observation_limits": ["HTTP200 and response/model ID at stream start do not prove final server completion, final usage, billing, or HTTP attempt count.",
            "Pause JSON has no internal UTC; only the after-a04/before-latest-resume interval is supported.",
            "The after-a19 controller exit mechanism remains unknown; no SIGPIPE, session TTL, or remote cancellation diagnosis is supported.",
            "Actual cost and account points deduction remain unknown; points from observed usage are estimates only.",
            "Six planned tasks per condition are not six completed or scored tasks; no significance/stable-winner claim."],
    }


def render_addendum(data):
    total = data["current_totals"]
    lines = ["", "## 运行中操作修订与交付来源", "",
             "原冻结停止策略原文：", "", "> " + data["original_stop_policy_quote"], "",
             "原v1实现不成功即停止，a02客户端超时后停止整队列；父随后授权继续原冻结36顺序。"
             f"v2声明生效时间 `{data['v2_declared_effective_utc']}`，runner pin补记时间 `{data['v2_pin_update_utc']}`。"
             "这是观察结果后的操作规则变更，不能写成完全遵循原事前冻结停止策略。"
             "v2允许特定已观察到批准服务HTTP200和response/model ID的客户端超时之后调度下一题；"
             "a02仍是失败，其服务端最终完成和最终usage仍为unknown。", "",
             "| 事件 | UTC或证据范围 | 记录 |", "|---|---|---|"]
    for event in data["chronology"]:
        when = event["utc"]
        if when == "unknown" and event.get("after_utc"):
            when = f"准确时间unknown；{event['after_utc']}之后、{event['before_utc']}之前"
        lines.append(f"| {event['kind']} | {when} | `{event['evidence']}`；{event['detail']} |")
    lines += ["", f"科学控制共同pins一致：`{data['scientific_common_pins_unchanged']}`；"
              f"当前主要控制文件字节与原pin一致：`{data['primary_current_bytes_match_original_pins']}`。"
              "12份system/user、36配置、选题/顺序、OpenCode binary、recorder与固定安全评估器/接口/panel/门禁仍保持原pin。"
              "预算账本的误冻结pin被移除；固定600CPU门禁未变。修订记录声明失败的账本preflight未启动CLI，"
              "报告代码没有独立观察那次preflight。", "", "原v1停止分支原文：", "", "```python", data["original_v1_implementation_quote"], "```", "",
              "精确runner差异：", "", "```diff", data.get("runner_unified_diff") or "unknown", "```", "",
              "| 文件 | 原pin SHA256 / bytes | 修订后pin SHA256 / bytes |", "|---|---|---|"]
    for change in data["freeze_pin_changes"]:
        def show(value):
            return f"{value['sha256']} / {value['bytes']}" if value else "未列入"
        lines.append(f"| `{change['file']}` | {show(change['before'])} | {show(change['after'])} |")
    manager = data.get("administrative_evaluation_manager_revision")
    if manager:
        wrapper = manager.get("current_wrapper_pin") or {}
        manifest_pin = manager.get("manifest_pin") or {}
        fixed_ok = all(x["current_bytes_match_migration_pin"] for x in manager["protected_fixed_current_byte_checks"])
        retained_ok = all(x["current_bytes_match_migration_pin"] for x in manager["existing_a01_a02_current_byte_checks"])
        lines += ["", "评分管理器另有行政修订，不能宣称所有评分软件完全未改。"
                  f"迁移清单 `evaluation/history_checkpoint2/MANIFEST.json` 的时间为 `{manager['migration_utc_from_manifest']}`，"
                  f"SHA `{manifest_pin.get('sha256','unknown')}` / {manifest_pin.get('bytes','unknown')} B。"
                  f"原2/36快照的 {manager['moved_historical_placeholder_count']} 个 a03–a36 `not_run` 占位目录被归档，"
                  "避免占位目录阻止新终态任务的首次准入/评分；历史真实评分身份继续保留。"
                  f"清单记录此次迁移评分调用={manager['actual_scoring_invocations_during_migration_as_recorded']}、"
                  f"候选代码修改={manager['candidate_code_changes_as_recorded']}、"
                  f"为决策读取模型内容={manager['model_content_reads_for_decision_as_recorded']}。", "",
                  f"未冻结的 `assess_results.py` 当前SHA `{wrapper.get('sha256','unknown')}` / {wrapper.get('bytes','unknown')} B，"
                  f"摘要观察时间 `{manager['current_wrapper_pin_observed_utc']}`；其精确改版写入时间unknown，未从mtime推定。"
                  "该包装器改为增量报告/调度；固定安全数值评估器、接口、runtime、公开3×1000 panel与CPU/内存/时间门禁保持原控制。"
                  f"本报告抽核这些固定文件当前字节与迁移保护pin一致={fixed_ok}；a01/a02 assessment一致={retained_ok}。"
                  "预算在迁移当刻按清单原样保留；后续真实评估可累计消耗预算，不能把历史预算摘要当作当前预算摘要。"
                  "此次管理器更新本身没有模型调用或新数值评分，零调用证据来自迁移清单。", ""]
    controller = data.get("controller_boundary_after19")
    if controller:
        boundary = controller["boundary_record"]
        restart = controller["restart_record"]
        observer = controller["observer_snapshot"]
        a19 = observer["a19"]
        lines += ["", "第19项后的另一次行政边界不涉及新的科学配置修订。"
                  f"`CONTROLLER_BOUNDARY_19.json` 于 `{boundary.get('utc','unknown')}` 记录历史19终态，"
                  f"旧控制器PID `{boundary.get('prior_controller_pid','unknown')}` 状态 `{boundary.get('prior_controller_state','unknown')}`、"
                  "工具会话unknown process；退出原因unknown，缺少过期会话异常日志不能证明未发生异常。"
                  "父另报告旧控制器PPID=1、恢复前无a20目录或CLI；这些细节未列在本地控制器JSON，作为父报告来源保存。"
                  f"新控制器记录于 `{restart.get('utc','unknown')}` 启动PID `{restart.get('pid','unknown')}`，"
                  "继续相同pinned v2的a20–a36并跳过既有终态，stdout/stderr重定向本地审计日志。"
                  f"边界记录Drive写入暂停=`{boundary.get('Drive_writes_paused','unknown')}`；这是该时点记录，不推定后续写入状态。", "",
                  f"外部观察器摘要（截至 `{observer.get('last_sample_utc','unknown')}`）记录a19进程首次缺席为 "
                  f"`{a19.get('root_first_absent_utc','unknown')}`、终态后缺席样本 `{a19.get('postterminal_absence_samples','unknown')}`。"
                  "观察器时间只有秒精度，不能把04:04:00Z当作相对04:04:00.351769Z终态的精确消失时刻；"
                  "样本数属于摘要自己的观察截止时间，不冒充较早边界当刻计数。"
                  "进程缺席/Z状态不支持SIGPIPE、会话TTL或服务端取消诊断；底层HTTP次数与费用仍为unknown。"
                  "根报告重复归档请求在覆盖前被拒绝；此处来源为父任务消息，未独立读取审批回执。", ""]
    lines += ["", f"本快照36计划：attempted={total['attempted']}，completed={total['completed']}，failed={total['failed']}，"
              f"not_run={total['not_run']}，未知终态={total['outcome_unknown']}。每条件planned n=6，实际覆盖须按条件表逐项看。", "",
              "历史2/36 Drive报告与ZIP均保留历史身份；同名本地ZIP最终重建不改变已上传的历史文件。"
              "交付ledger只保存file ID、大小、摘要与校验来源，不保存签名URL、账户或收件人。", "",
              "| 历史/批次/最终交付 | Drive file ID | bytes | 本地SHA256 | 远端SHA回读 | owner-only证据 |", "|---|---|---:|---|---|---|"]
    for item in data["delivery_ledger"]["deliveries"]:
        remote = item.get("remote_sha256", "unknown")
        if item.get("remote_readback_verified") is not True:
            remote = "unknown；" + item.get("remote_sha_blocker", "没有已证实的SHA回读")
        lines.append(f"| {item.get('snapshot')}/{item.get('kind')} | `{item.get('file_id','unknown')}` | {item.get('bytes','unknown')} | "
                     f"{item.get('local_sha256','unknown')} | {remote} | {item.get('owner_only_observed','unknown')} |")
    local_archives = data["delivery_ledger"].get("local_batch_archives", [])
    if local_archives:
        lines += ["", "本地批次归档另外列示；pin及当前ZIP一致只证明本地字节。未观察到delivery回执时，"
                  "远端上传、SHA回读与owner-only均不据此推断，也不能由回执缺席断言从未上传。", "",
                  "| 本地批次 | 历史累计终态 | bytes | 本地SHA256 | 当前ZIP与pin一致 | delivery回执 |",
                  "|---|---:|---:|---|---|---|"]
        for item in local_archives:
            expected = item["expected_pin"]
            lines.append(f"| 第{item['batch_number']:02d}批 | {item['cumulative_terminal_count']} | {expected['bytes']} | "
                         f"{expected['sha256']} | {item['current_local_bytes_match_pin']} | {item['delivery_receipt_observed']} |")
    lines += ["", "历史2/36交付的报告SHA/size回读由根工具完成；ZIP仅有owner-only与远端大小metadata核验，"
              "本地SHA不能冒充远端回读。32MiB下载限制及一次proxy CONNECT403阻止其SHA核验；这不是审批拒绝，未重试或绕过。"
              f"当前最终交付回执状态：`{data['delivery_ledger']['final_snapshot_delivery_status']}`；"
              "仅评价已观察到的回执，回执数量本身不能证明整个预期最终交付集合完整。", ""]
    handoff = data.get("handoff_operational_status", {})
    resume = handoff.get("Drive_resume_record")
    if resume:
        lines += [f"最新用户于 `{resume.get('utc','unknown')}` 解除Drive写入暂停；恢复记录标记两个指定私有目标目录owner-only已核验。"
                  "恢复许可不等于上传完成，当前批次/最终文件状态仍以逐件实际交付回执为准。"
                  f"已观察到owner-only与SHA字节回读均通过的批次：`{handoff.get('batch_remote_owner_and_bytes_verified',[])}`；"
                  f"尚无完整远端验证回执的批次：`{handoff.get('batches_without_verified_remote_receipt',[])}`。", ""]
    correction = handoff.get("packaging_correction_record")
    if correction:
        lines += [f"本地打包行政修正记录时间 `{correction.get('utc','unknown')}`：原循环按basename跳过所有HANDOFF_MANIFEST.json，"
                  "连已列入输入pins的嵌套清单也被误省；本地逐件CRC/manifest核验在上传前拒绝该包。"
                  "修正为只跳过根目录自动生成清单，保留嵌套源码清单；旧本地产物移到最终payload根目录外保留。"
                  "此修正未改36项生成回执/候选、任何评分、协议/runtime/模型/工具pins，未重跑或重评分，"
                  "不导致统计差异；该修正记录的“尚未上传”是历史时点，当前交付只按后续实际回执判断。", ""]
    return "\n".join(lines)


def write_outputs(root, data, out=None):
    out = Path(out or Path(root) / "reporting")
    out.mkdir(parents=True, exist_ok=True)
    (out / "operational_addendum.json").write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (out / "operational_addendum.md").write_text(render_addendum(data), encoding="utf-8")
    (out / "delivery_ledger.json").write_text(json.dumps(data["delivery_ledger"], ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    data = build_addendum(args.root)
    write_outputs(args.root, data, args.out)
    print(json.dumps({"outputs": ["operational_addendum.md", "operational_addendum.json", "delivery_ledger.json"],
                      "planned": 36, "attempted": data["current_totals"]["attempted"],
                      "scientific_common_pins_unchanged": data["scientific_common_pins_unchanged"]}))


if __name__ == "__main__":
    main()
