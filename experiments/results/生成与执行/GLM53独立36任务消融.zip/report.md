# 独立小规模消融实验记录

固定计划 36 项（2 模型 × 3 档位 × 6 题），已尝试 36 项；完成 35，失败 1（普通失败 0、超时 1、截断 0），未运行 0，已启动结果未知 0。

本统计只读取本独立目录的冻结任务和真实记录；原 132 主线未纳入。未启动的阻塞任务保留为 not_run。观察到的是 SDK fetch 调用次数，底层 HTTP/网络请求次数与 SDK 内部重试行为均为 unknown。

选题种子 `20261007`；P2 输入 SHA256 `b48fcbf84aab8def4f676d3b12873926683d116c309ccdd3efb5116726a13760`。选题与顺序文件 SHA256 `8b74841f8b415e6cbc336585abe7dfb3e2cb89cb3c378f900b925f73c2605594`。

六个条件均固定 n=6。以下耗时包括所有有耗时终态的已尝试任务，包含失败、超时和截断；缺失耗时不填零。

| 模型 | 档位 | n | attempted | completed | failed | timeout | truncation | not_run | unknown | 耗时观测n | 平均秒 | 中位秒 | SDK fetch观测 |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| glm-5.3 | low | 6 | 6 | 6 | 0 | 0 | 0 | 0 | 0 | 6 | 12.931 | 8.576 | 6 |
| glm-5.3 | high | 6 | 6 | 5 | 1 | 1 | 0 | 0 | 0 | 6 | 506.350 | 505.512 | 6 |
| glm-5.3 | max | 6 | 6 | 6 | 0 | 0 | 0 | 0 | 0 | 6 | 407.767 | 411.606 | 6 |
| glm-5.3-flash | low | 6 | 6 | 6 | 0 | 0 | 0 | 0 | 0 | 6 | 7.712 | 7.368 | 6 |
| glm-5.3-flash | high | 6 | 6 | 6 | 0 | 0 | 0 | 0 | 0 | 6 | 304.592 | 358.139 | 6 |
| glm-5.3-flash | max | 6 | 6 | 6 | 0 | 0 | 0 | 0 | 0 | 6 | 217.528 | 274.553 | 6 |

原始服务端 usage 已观察到 35 次 fetch 的末项记录。每次 fetch 只取最后一个 usage 快照；每任务最后一个 fetch 的原始 usage 另列于 all36.csv/summary.json。不使用字符数或 CLI 归一化 token 替代服务端 usage；缺失字段保留 unknown。

仅对已观察 usage，估计基础积分为 925.650，按官方非高峰规则估计积分为 462.825。实际账户扣积分与实际成本均为 unknown。缓存分项缺失时仅作无缓存假设估算；假设标准 prompt_tokens 包含缓存命中 token。仅应用已核实的非高峰/节日50%规则，不把夜间额度翻倍活动换算为实扣折扣；估算不是账户账单。[官方积分系数](https://docs.bigmodel.cn/cn/coding-plan/overview)：GLM-5.3 输入/缓存/输出 6.9/1.7/24，Flash 为 2.3/0.56/8，除以10000。

准入/评分说明文件覆盖 36 项任务，实际评估接口/准入尝试 35 项，完整公开3case计分 30 项，实测完整 case 分值 90 个。只应解释为事前固定公开 design 序列各前1000件上的评分；没有读取 heldout，也不替代主线5000件得分。具体 AST/接口准入与每 case 结果保留于 summary.json。

本轮每条件 n=6，只用于筛选；不宣称显著差异、稳定赢家或同 token 上限对应相同真实算力。

## 所有36项

| 顺序 | 任务 | 题目 | 模型 | 档位 | attempted | 终态 | 退出码 | 秒 | finish_reason | usage末项 | SDK fetch观测 | 准入/评分 |
|---:|---|---|---|---|---|---|---:|---:|---|---|---:|---|
| 1 | a01 | q06 | glm-5.3-flash | max | True | completed | 0 | 286.456 | stop | {"prompt_tokens":4510,"completion_tokens":14165,"total_tokens":18675,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":13773}} | 1 | ast_passed/complete |
| 2 | a02 | q04 | glm-5.3 | high | True | timeout | -15 | 900.392 | unknown | unknown | 1 | not_run/not_run |
| 3 | a03 | q06 | glm-5.3 | low | True | completed | 0 | 34.838 | stop | {"prompt_tokens":4510,"completion_tokens":1681,"total_tokens":6191,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":1403}} | 1 | ast_passed/complete |
| 4 | a04 | q02 | glm-5.3-flash | high | True | completed | 0 | 392.893 | stop | {"prompt_tokens":4413,"completion_tokens":19902,"total_tokens":24315,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":19502}} | 1 | ast_passed/complete |
| 5 | a05 | q01 | glm-5.3 | max | True | completed | 0 | 624.299 | stop | {"prompt_tokens":4444,"completion_tokens":42251,"total_tokens":46695,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":41759}} | 1 | ast_passed/complete |
| 6 | a06 | q05 | glm-5.3-flash | max | True | completed | 0 | 39.946 | stop | {"prompt_tokens":3173,"completion_tokens":1285,"total_tokens":4458,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":1146}} | 1 | ast_passed/complete |
| 7 | a07 | q04 | glm-5.3 | max | True | completed | 0 | 534.467 | stop | {"prompt_tokens":3299,"completion_tokens":39679,"total_tokens":42978,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":39275}} | 1 | ast_passed/complete |
| 8 | a08 | q03 | glm-5.3 | low | True | completed | 0 | 9.204 | stop | {"prompt_tokens":3240,"completion_tokens":386,"total_tokens":3626,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":149}} | 1 | ast_rejected/admission_rejected |
| 9 | a09 | q02 | glm-5.3 | high | True | completed | 0 | 594.712 | stop | {"prompt_tokens":4413,"completion_tokens":42861,"total_tokens":47274,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":42082}} | 1 | ast_rejected/admission_rejected |
| 10 | a10 | q02 | glm-5.3-flash | low | True | completed | 0 | 6.537 | stop | {"prompt_tokens":4413,"completion_tokens":242,"total_tokens":4655,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":28}} | 1 | ast_passed/complete |
| 11 | a11 | q03 | glm-5.3 | high | True | completed | 0 | 416.312 | stop | {"prompt_tokens":3240,"completion_tokens":27416,"total_tokens":30656,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":27140}} | 1 | ast_passed/complete |
| 12 | a12 | q06 | glm-5.3 | max | True | completed | 0 | 390.470 | stop | {"prompt_tokens":4510,"completion_tokens":24952,"total_tokens":29462,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":24582}} | 1 | ast_passed/complete |
| 13 | a13 | q02 | glm-5.3-flash | max | True | completed | 0 | 280.996 | stop | {"prompt_tokens":4413,"completion_tokens":13835,"total_tokens":18248,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":13578}} | 1 | ast_passed/complete |
| 14 | a14 | q04 | glm-5.3-flash | low | True | completed | 0 | 7.088 | stop | {"prompt_tokens":3299,"completion_tokens":309,"total_tokens":3608,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":17}} | 1 | ast_passed/complete |
| 15 | a15 | q01 | glm-5.3 | high | True | completed | 0 | 335.133 | stop | {"prompt_tokens":4444,"completion_tokens":24201,"total_tokens":28645,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":23839}} | 1 | ast_passed/complete |
| 16 | a16 | q05 | glm-5.3-flash | high | True | completed | 0 | 70.153 | stop | {"prompt_tokens":3173,"completion_tokens":2892,"total_tokens":6065,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":2755}} | 1 | ast_passed/complete |
| 17 | a17 | q01 | glm-5.3-flash | max | True | completed | 0 | 281.809 | stop | {"prompt_tokens":4444,"completion_tokens":12840,"total_tokens":17284,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":12469}} | 1 | ast_rejected/admission_rejected |
| 18 | a18 | q05 | glm-5.3 | high | True | completed | 0 | 47.797 | stop | {"prompt_tokens":3173,"completion_tokens":3473,"total_tokens":6646,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":3333}} | 1 | ast_passed/complete |
| 19 | a19 | q06 | glm-5.3-flash | high | True | completed | 0 | 369.615 | stop | {"prompt_tokens":4510,"completion_tokens":16239,"total_tokens":20749,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":15808}} | 1 | ast_passed/complete |
| 20 | a20 | q06 | glm-5.3 | high | True | completed | 0 | 743.752 | stop | {"prompt_tokens":4510,"completion_tokens":38740,"total_tokens":43250,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":38202}} | 1 | ast_passed/complete |
| 21 | a21 | q01 | glm-5.3 | low | True | completed | 0 | 14.776 | stop | {"prompt_tokens":4444,"completion_tokens":748,"total_tokens":5192,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":509}} | 1 | ast_passed/complete |
| 22 | a22 | q03 | glm-5.3-flash | low | True | completed | 0 | 7.648 | stop | {"prompt_tokens":3240,"completion_tokens":233,"total_tokens":3473,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":20}} | 1 | ast_passed/complete |
| 23 | a23 | q04 | glm-5.3-flash | max | True | completed | 0 | 268.109 | stop | {"prompt_tokens":3299,"completion_tokens":13406,"total_tokens":16705,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":13087}} | 1 | ast_passed/complete |
| 24 | a24 | q01 | glm-5.3-flash | low | True | completed | 0 | 12.464 | stop | {"prompt_tokens":4444,"completion_tokens":390,"total_tokens":4834,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":173}} | 1 | ast_rejected/admission_rejected |
| 25 | a25 | q05 | glm-5.3 | low | True | completed | 0 | 5.288 | stop | {"prompt_tokens":3173,"completion_tokens":160,"total_tokens":3333,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":37}} | 1 | ast_passed/complete |
| 26 | a26 | q03 | glm-5.3-flash | max | True | completed | 0 | 147.848 | stop | {"prompt_tokens":3240,"completion_tokens":7102,"total_tokens":10342,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":6869}} | 1 | ast_passed/complete |
| 27 | a27 | q03 | glm-5.3-flash | high | True | completed | 0 | 346.664 | stop | {"prompt_tokens":3240,"completion_tokens":14449,"total_tokens":17689,"prompt_tokens_details":{"cached_tokens":3200},"completion_tokens_details":{"reasoning_tokens":14057}} | 1 | ast_passed/complete |
| 28 | a28 | q06 | glm-5.3-flash | low | True | completed | 0 | 7.749 | stop | {"prompt_tokens":4510,"completion_tokens":286,"total_tokens":4796,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":13}} | 1 | ast_passed/complete |
| 29 | a29 | q05 | glm-5.3 | max | True | completed | 0 | 74.152 | stop | {"prompt_tokens":3173,"completion_tokens":5600,"total_tokens":8773,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":5459}} | 1 | ast_passed/complete |
| 30 | a30 | q05 | glm-5.3-flash | low | True | completed | 0 | 4.785 | stop | {"prompt_tokens":3173,"completion_tokens":124,"total_tokens":3297,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":0}} | 1 | ast_passed/complete |
| 31 | a31 | q02 | glm-5.3 | max | True | completed | 0 | 430.008 | stop | {"prompt_tokens":4413,"completion_tokens":32423,"total_tokens":36836,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":31995}} | 1 | ast_passed/complete |
| 32 | a32 | q02 | glm-5.3 | low | True | completed | 0 | 7.947 | stop | {"prompt_tokens":4413,"completion_tokens":327,"total_tokens":4740,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":0}} | 1 | ast_rejected/admission_rejected |
| 33 | a33 | q04 | glm-5.3 | low | True | completed | 0 | 5.535 | stop | {"prompt_tokens":3299,"completion_tokens":294,"total_tokens":3593,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":11}} | 1 | ast_passed/complete |
| 34 | a34 | q01 | glm-5.3-flash | high | True | completed | 0 | 429.658 | stop | {"prompt_tokens":4444,"completion_tokens":18242,"total_tokens":22686,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":17910}} | 1 | ast_passed/complete |
| 35 | a35 | q04 | glm-5.3-flash | high | True | completed | 0 | 218.567 | stop | {"prompt_tokens":3299,"completion_tokens":10360,"total_tokens":13659,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":10049}} | 1 | ast_passed/complete |
| 36 | a36 | q03 | glm-5.3 | max | True | completed | 0 | 393.203 | stop | {"prompt_tokens":3240,"completion_tokens":26368,"total_tokens":29608,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":26123}} | 1 | ast_passed/complete |

完整字段、服务端返回 response/model ID、每 fetch usage 和评分见 `all36.csv`、`condition_summary.csv`、`summary.json`。

## 运行中操作修订与交付来源

原冻结停止策略原文：

> Stop on access/plan/configuration/ambiguous external result or unknown charging route; retain all attempted terminal failures and all unstarted tasks; no reslots or automatic fallback.

原v1实现不成功即停止，a02客户端超时后停止整队列；父随后授权继续原冻结36顺序。v2声明生效时间 `2026-10-07T02:45:57.331713+00:00`，runner pin补记时间 `2026-10-07T02:45:58.584219+00:00`。这是观察结果后的操作规则变更，不能写成完全遵循原事前冻结停止策略。v2允许特定已观察到批准服务HTTP200和response/model ID的客户端超时之后调度下一题；a02仍是失败，其服务端最终完成和最终usage仍为unknown。

| 事件 | UTC或证据范围 | 记录 |
|---|---|---|
| initial_freeze | 2026-10-07T02:11:22.593875+00:00 | `protocol/protocol.json`；36题次/配置及原v1操作策略冻结。 |
| a01_cli_start | 2026-10-07T02:11:23.186842+00:00 | `raw/a01/invocation.json`；原v1单次CLI启动。 |
| a01_client_terminal | 2026-10-07T02:16:09.643101+00:00 | `raw/a01/terminal.json`；服务端stop完成。 |
| a02_cli_start | 2026-10-07T02:16:17.808049+00:00 | `raw/a02/invocation.json`；原v1单次CLI启动。 |
| a02_client_terminal | 2026-10-07T02:31:18.200162+00:00 | `raw/a02/terminal.json`；客户端超时失败；服务端最终完成与最终usage未知。 |
| v1_stopped_after_a02 | 2026-10-07T02:31:18.200992+00:00 | `STOP.pre_resume.json`；v1按不成功即停止的实现停止队列；a02保留且不重跑。 |
| parent_authorized_operational_v2 | 2026-10-07T02:45:57.331713+00:00 | `protocol/OPERATIONAL_AMENDMENT_01.json`；父随后授权继续原冻结顺序；特定已观察HTTP200及model/response ID的客户端超时允许调度下一题。该变更发生在观察a02结果之后。 |
| amendment_pin_record_updated | 2026-10-07T02:45:58.584219+00:00 | `protocol/FREEZE.json`；更新runner pin、保存v1/旧freeze/修订记录，去掉误冻结的可变预算账本pin。 |
| a03_resumed_start | 2026-10-07T02:46:22.457710+00:00 | `raw/a03/invocation.json`；继续原冻结下一题，既有任务未重启。 |
| a03_client_terminal | 2026-10-07T02:46:57.295354+00:00 | `raw/a03/terminal.json`；保存CLI终态及原始服务端回执。 |
| a04_resumed_start | 2026-10-07T02:46:57.634921+00:00 | `raw/a04/invocation.json`；继续原冻结下一题，既有任务未重启。 |
| administrative_evaluation_manager_revision | 2026-10-07T02:50:19.882016+00:00 | `evaluation/history_checkpoint2/MANIFEST.json`；迁移原2/36快照的a03–a36 not_run占位；报告/调度包装器改为增量管理。清单记录评分调用0；固定安全评估器、接口、公开panel与门禁未变。 |
| a04_client_terminal | 2026-10-07T02:53:30.528062+00:00 | `raw/a04/terminal.json`；保存CLI终态及原始服务端回执。 |
| stale_pause_at_a04_natural_boundary | 准确时间unknown；2026-10-07T02:53:30.528062+00:00之后、2026-10-07T02:57:05.824886+00:00之前 | `PAUSE_AT_NATURAL_BOUNDARY.json`；旧暂停指令在a04持久终态后作用于串行调度器；记录声明未中断CLI。暂停记录无内部UTC，不能声称准确发信号时间。 |
| latest_parent_resume_before_a05 | 2026-10-07T02:57:05.824886+00:00 | `RESUME_AFTER_PARENT_LATEST.json`；最新父指令继续剩余原36范围；保留a02失败与usage/server终态未知；既有任务不重新启动。 |
| a05_actual_start | 2026-10-07T02:57:06.485024+00:00 | `raw/a05/invocation.json`；最新恢复记录之后首次启动a05。 |
| a19_client_terminal_before_controller_boundary | 2026-10-07T04:04:00.351769+00:00 | `raw/a19/terminal.json`；a19已保存真实CLI终态及原始stop回执；后续控制器边界不改变其身份。 |
| controller_boundary_after_19_terminals | 2026-10-07T04:09:41.128636+00:00 | `CONTROLLER_BOUNDARY_19.json`；记录当刻已有19真实终态；原a01–a19记录完成18项、超时1项。旧控制器4587为Z，工具会话为unknown process。消失原因unknown，未保存过期会话异常日志。记录声明冻结校验通过、既有任务不重启、Drive写入暂停。 |
| unchanged_v2_controller_restart_for_a20_a36 | 2026-10-07T04:09:41.129633+00:00 | `CONTROLLER_AFTER19_START.json`；以相同pinned v2从a20继续至a36；新控制器PID6186，stdout/stderr重定向本地审计日志；既有终态任务跳过不重跑。 |
| a20_actual_start_after_controller_restart | 2026-10-07T04:09:41.541606+00:00 | `raw/a20/invocation.json`；新控制器记录之后单次启动原冻结下一任务a20；历史19终态快照不能当作当前累计终态。 |
| local_handoff_packaging_correction | 2026-10-07T05:16:15.709884+00:00 | `PACKAGING_CORRECTION.json`；原本地打包循环误跳过嵌套输入HANDOFF_MANIFEST.json，本地逐件CRC/清单核验在上传前拒绝；改为仅跳过根目录生成清单。旧本地产物另行保留，36生成/评分/控制pin不变，无重跑。 |
| user_released_Drive_write_pause | 2026-10-07T05:16:15.710053+00:00 | `DRIVE_WRITES_RESUMED.json`；最新用户解除临时Drive写入暂停；实验资料与报告/审计分入指定私有目录，恢复记录载有owner-only核验。恢复授权本身不证明任何上传或回读完成。 |

科学控制共同pins一致：`True`；当前主要控制文件字节与原pin一致：`True`。12份system/user、36配置、选题/顺序、OpenCode binary、recorder与固定安全评估器/接口/panel/门禁仍保持原pin。预算账本的误冻结pin被移除；固定600CPU门禁未变。修订记录声明失败的账本preflight未启动CLI，报告代码没有独立观察那次preflight。

原v1停止分支原文：

```python
    if not success:
        write(ROOT/'STOP.json',{'task':task,'reason':'CLI/configuration/provider result requires review. No retry or later task started.','terminal':str(td/'terminal.json'),'utc':utc()})
        return False

```

精确runner差异：

```diff
--- run_ablation.v1.py
+++ run_ablation.py
@@ -85,7 +85,11 @@
     allterm=[json.loads(x.read_bytes()) for x in sorted((ROOT/'raw').glob('*/terminal.json'))]
     write(ROOT/'progress.json',{'terminal_count':len(allterm),'completed':sum(x['status']=='completed' for x in allterm),'failed':sum(x['status']=='failed' for x in allterm),'last':task,'updated_utc':utc()})
     print(json.dumps({'terminal':task,'status':terminal['status'],'exit':p.returncode,'seconds':round(terminal['wall_seconds'],2),'responses':len(records),'finish':finishes}),flush=True)
-    if not success:
+    events=[]
+    if (td/'recorder.jsonl').exists():
+        events=[json.loads(line) for line in (td/'recorder.jsonl').read_text().splitlines()]
+    confirmed_client_timeout=timed_out and p.returncode in [-15,-9] and any(x.get('event')=='sdk_fetch_headers' and x.get('status')==200 for x in events) and any(task['model'] in rr['provider_model_ids'] and rr['provider_response_ids'] for rr in records)
+    if not success and not confirmed_client_timeout:
         write(ROOT/'STOP.json',{'task':task,'reason':'CLI/configuration/provider result requires review. No retry or later task started.','terminal':str(td/'terminal.json'),'utc':utc()})
         return False
     if (td/'stop.json').exists() or (td/'STOP.json').exists():

```

| 文件 | 原pin SHA256 / bytes | 修订后pin SHA256 / bytes |
|---|---|---|
| `evaluation/budget.json` | 84fa43496da3782a8f2a7d292b943a150515fbbb0bb84b3978da8098b051c63d / 289 | 未列入 |
| `protocol/FREEZE.pre_amendment.json` | 未列入 | fe50f24271630d269dbddc7582f1195ecac25624086161051c99d186767097b3 / 22382 |
| `protocol/OPERATIONAL_AMENDMENT_01.json` | 未列入 | 9d3d8d25fe885b74cc226700e4ab15f6a15caccaedd0736651e88516cde8a6e2 / 1126 |
| `run_ablation.py` | 6968b085c2a432088e9fade6048c8b0812305f46628af26d93186d0e9396f8c7 / 7201 | 2215b15fa231fdfd202acf3822cbc0c038bcfed0131eed4dd5b2cd20f2b5a118 / 7635 |
| `run_ablation.v1.py` | 未列入 | 6968b085c2a432088e9fade6048c8b0812305f46628af26d93186d0e9396f8c7 / 7201 |

评分管理器另有行政修订，不能宣称所有评分软件完全未改。迁移清单 `evaluation/history_checkpoint2/MANIFEST.json` 的时间为 `2026-10-07T02:50:19.882016+00:00`，SHA `2d87139f699e9355579dd9d3433c658cd5e5ffa859021f677bd56ef7f1d85f29` / 14731 B。原2/36快照的 34 个 a03–a36 `not_run` 占位目录被归档，避免占位目录阻止新终态任务的首次准入/评分；历史真实评分身份继续保留。清单记录此次迁移评分调用=0、候选代码修改=0、为决策读取模型内容=0。

未冻结的 `assess_results.py` 当前SHA `b5c1586c0185a740d544d8564994ea8db7bcc9d8158c4db58b9ef83cfe08e429` / 31912 B，摘要观察时间 `2026-10-07T05:19:53.905541+00:00`；其精确改版写入时间unknown，未从mtime推定。该包装器改为增量报告/调度；固定安全数值评估器、接口、runtime、公开3×1000 panel与CPU/内存/时间门禁保持原控制。本报告抽核这些固定文件当前字节与迁移保护pin一致=True；a01/a02 assessment一致=True。预算在迁移当刻按清单原样保留；后续真实评估可累计消耗预算，不能把历史预算摘要当作当前预算摘要。此次管理器更新本身没有模型调用或新数值评分，零调用证据来自迁移清单。


第19项后的另一次行政边界不涉及新的科学配置修订。`CONTROLLER_BOUNDARY_19.json` 于 `2026-10-07T04:09:41.128636+00:00` 记录历史19终态，旧控制器PID `4587` 状态 `Z`、工具会话unknown process；退出原因unknown，缺少过期会话异常日志不能证明未发生异常。父另报告旧控制器PPID=1、恢复前无a20目录或CLI；这些细节未列在本地控制器JSON，作为父报告来源保存。新控制器记录于 `2026-10-07T04:09:41.129633+00:00` 启动PID `6186`，继续相同pinned v2的a20–a36并跳过既有终态，stdout/stderr重定向本地审计日志。边界记录Drive写入暂停=`True`；这是该时点记录，不推定后续写入状态。

外部观察器摘要（截至 `2026-10-07T05:01:50Z`）记录a19进程首次缺席为 `2026-10-07T04:04:00Z`、终态后缺席样本 `3470`。观察器时间只有秒精度，不能把04:04:00Z当作相对04:04:00.351769Z终态的精确消失时刻；样本数属于摘要自己的观察截止时间，不冒充较早边界当刻计数。进程缺席/Z状态不支持SIGPIPE、会话TTL或服务端取消诊断；底层HTTP次数与费用仍为unknown。根报告重复归档请求在覆盖前被拒绝；此处来源为父任务消息，未独立读取审批回执。


本快照36计划：attempted=36，completed=35，failed=1，not_run=0，未知终态=0。每条件planned n=6，实际覆盖须按条件表逐项看。

历史2/36 Drive报告与ZIP均保留历史身份；同名本地ZIP最终重建不改变已上传的历史文件。交付ledger只保存file ID、大小、摘要与校验来源，不保存签名URL、账户或收件人。

| 历史/批次/最终交付 | Drive file ID | bytes | 本地SHA256 | 远端SHA回读 | owner-only证据 |
|---|---|---:|---|---|---|
| checkpoint_01_one_terminal/checkpoint_zip | `1lgdEQ7AAXePIOl7FyhVYihXsiLKEkO5H` | 190533 | 5dcc1ce00e832c2d2a7deff035754fe662c794cfe8bc9ee28d0a0bbc6280f17a | 5dcc1ce00e832c2d2a7deff035754fe662c794cfe8bc9ee28d0a0bbc6280f17a | True |
| historical_checkpoint2_2_of_36/Chinese_report | `1oRgH6JH_635cDAH7ZkIEhIiBwHooUchK` | 9454 | 64ebe8274695b9b8c49197000bdd986262e9860fd2dd3ba34033155f18d68b4c | 64ebe8274695b9b8c49197000bdd986262e9860fd2dd3ba34033155f18d68b4c | True |
| historical_checkpoint2_2_of_36/full_ZIP | `1hU34cPyHPhDbyVJsa9w8VdcSI0zw46wZ` | 87242318 | c7ee06f6fe0e42156c3ad6a2108cd5dc74e95c9def8d9e94816771864850a8e1 | unknown；download_file 32MiB limit; one actual file_uri fetch returned proxy CONNECT403, not an approval rejection; no retry or bypass. Root additionally requested sha256Checksum/version/headRevisionId once; mapped structuredContent exposed no checksum or revision fields, so metadata checksum also not observed. | True |
| batch01_cumulative6_terminals/batch_ZIP | `1UiqafpWo2gA-dfdFako02cufv_RmK-ox` | 658629 | c9bde56e3204520d2b1101e897c9652f5a0cdfd60cd3634c3195faed955d945d | c9bde56e3204520d2b1101e897c9652f5a0cdfd60cd3634c3195faed955d945d | True |
| batch02_cumulative12_terminals/batch_ZIP | `1-HVY-iK7yL1hpFmWwhO0SGbGwL3XqW6M` | 649924 | 76aa88d2c1bcaf0e2356e7eb90da72722a41cc7f79bc6b6fb08b78736e06210d | 76aa88d2c1bcaf0e2356e7eb90da72722a41cc7f79bc6b6fb08b78736e06210d | True |
| batch03_cumulative18_terminals/batch_ZIP | `1CVr62CP14L1IouKXkpnAHsAXNPpXTzhS` | 410312 | 7d852a528528dc23f5716dc936e9acd01adc52bebd9d091b914348a58772c8c6 | 7d852a528528dc23f5716dc936e9acd01adc52bebd9d091b914348a58772c8c6 | True |
| batch04_cumulative24_terminals/batch_ZIP | `1Rk9FSJWEs8h11MfUXdpg2UaRvBjZnc5E` | 453582 | 4a9c5261dcd0e8ef89e842355a9efc4c80c24f765af749ef334d366010c11440 | 4a9c5261dcd0e8ef89e842355a9efc4c80c24f765af749ef334d366010c11440 | True |
| batch05_cumulative30_terminals/batch_ZIP | `1W37NnONOXavpAruC01gYQOJ3WteSArIi` | 319093 | c33a12527bc5a880378c788ce316a79e832385982c8aa8ba759b691802a97e3b | c33a12527bc5a880378c788ce316a79e832385982c8aa8ba759b691802a97e3b | True |
| batch06_cumulative36_terminals/batch_ZIP | `1Ms5BnJ5u6ti7dZk5fuV3JzSKntO5bDmO` | 514178 | ceb3510a29cf9e3e25422545c39bb0cbea3d8abbcf20427bbb8ef6c39b74d145 | ceb3510a29cf9e3e25422545c39bb0cbea3d8abbcf20427bbb8ef6c39b74d145 | True |

本地批次归档另外列示；pin及当前ZIP一致只证明本地字节。未观察到delivery回执时，远端上传、SHA回读与owner-only均不据此推断，也不能由回执缺席断言从未上传。

| 本地批次 | 历史累计终态 | bytes | 本地SHA256 | 当前ZIP与pin一致 | delivery回执 |
|---|---:|---:|---|---|---|
| 第01批 | 6 | 658629 | c9bde56e3204520d2b1101e897c9652f5a0cdfd60cd3634c3195faed955d945d | True | True |
| 第02批 | 12 | 649924 | 76aa88d2c1bcaf0e2356e7eb90da72722a41cc7f79bc6b6fb08b78736e06210d | True | True |
| 第03批 | 18 | 410312 | 7d852a528528dc23f5716dc936e9acd01adc52bebd9d091b914348a58772c8c6 | True | True |
| 第04批 | 24 | 453582 | 4a9c5261dcd0e8ef89e842355a9efc4c80c24f765af749ef334d366010c11440 | True | True |
| 第05批 | 30 | 319093 | c33a12527bc5a880378c788ce316a79e832385982c8aa8ba759b691802a97e3b | True | True |
| 第06批 | 36 | 514178 | ceb3510a29cf9e3e25422545c39bb0cbea3d8abbcf20427bbb8ef6c39b74d145 | True | True |

历史2/36交付的报告SHA/size回读由根工具完成；ZIP仅有owner-only与远端大小metadata核验，本地SHA不能冒充远端回读。32MiB下载限制及一次proxy CONNECT403阻止其SHA核验；这不是审批拒绝，未重试或绕过。当前最终交付回执状态：`not_established_by_this_ledger`；仅评价已观察到的回执，回执数量本身不能证明整个预期最终交付集合完整。

最新用户于 `2026-10-07T05:16:15.710053+00:00` 解除Drive写入暂停；恢复记录标记两个指定私有目标目录owner-only已核验。恢复许可不等于上传完成，当前批次/最终文件状态仍以逐件实际交付回执为准。已观察到owner-only与SHA字节回读均通过的批次：`[1, 2, 3, 4, 5, 6]`；尚无完整远端验证回执的批次：`[]`。

本地打包行政修正记录时间 `2026-10-07T05:16:15.709884+00:00`：原循环按basename跳过所有HANDOFF_MANIFEST.json，连已列入输入pins的嵌套清单也被误省；本地逐件CRC/manifest核验在上传前拒绝该包。修正为只跳过根目录自动生成清单，保留嵌套源码清单；旧本地产物移到最终payload根目录外保留。此修正未改36项生成回执/候选、任何评分、协议/runtime/模型/工具pins，未重跑或重评分，不导致统计差异；该修正记录的“尚未上传”是历史时点，当前交付只按后续实际回执判断。

## 每题六条件与可用配对

每题保留六个冻结条件；失败、超时和未运行的分值均为unknown，不填零。只有同一题双方AST准入且真实完成3×1000评分、gap已观察，才进入配对。合法且已完整评分的截断输出仍保留truncation标记。

| 题目 | 模型 | effort | 任务 | 状态 | 秒 | 服务端usage末项 | AST准入 | 评分状态 | 3×1000 gap% |
|---|---|---|---|---|---:|---|---|---|---:|
| q01 | glm-5.3 | low | a21 | completed | 14.776 | {"prompt_tokens":4444,"completion_tokens":748,"total_tokens":5192,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":509}} | ast_passed | complete | 4.250 |
| q01 | glm-5.3 | high | a15 | completed | 335.133 | {"prompt_tokens":4444,"completion_tokens":24201,"total_tokens":28645,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":23839}} | ast_passed | complete | 5.417 |
| q01 | glm-5.3 | max | a05 | completed | 624.299 | {"prompt_tokens":4444,"completion_tokens":42251,"total_tokens":46695,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":41759}} | ast_passed | complete | 5.417 |
| q01 | glm-5.3-flash | low | a24 | completed | 12.464 | {"prompt_tokens":4444,"completion_tokens":390,"total_tokens":4834,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":173}} | ast_rejected | admission_rejected | unknown |
| q01 | glm-5.3-flash | high | a34 | completed | 429.658 | {"prompt_tokens":4444,"completion_tokens":18242,"total_tokens":22686,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":17910}} | ast_passed | complete | 4.917 |
| q01 | glm-5.3-flash | max | a17 | completed | 281.809 | {"prompt_tokens":4444,"completion_tokens":12840,"total_tokens":17284,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":12469}} | ast_rejected | admission_rejected | unknown |
| q02 | glm-5.3 | low | a32 | completed | 7.947 | {"prompt_tokens":4413,"completion_tokens":327,"total_tokens":4740,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":0}} | ast_rejected | admission_rejected | unknown |
| q02 | glm-5.3 | high | a09 | completed | 594.712 | {"prompt_tokens":4413,"completion_tokens":42861,"total_tokens":47274,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":42082}} | ast_rejected | admission_rejected | unknown |
| q02 | glm-5.3 | max | a31 | completed | 430.008 | {"prompt_tokens":4413,"completion_tokens":32423,"total_tokens":36836,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":31995}} | ast_passed | complete | 3.667 |
| q02 | glm-5.3-flash | low | a10 | completed | 6.537 | {"prompt_tokens":4413,"completion_tokens":242,"total_tokens":4655,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":28}} | ast_passed | complete | 4.250 |
| q02 | glm-5.3-flash | high | a04 | completed | 392.893 | {"prompt_tokens":4413,"completion_tokens":19902,"total_tokens":24315,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":19502}} | ast_passed | complete | 4.583 |
| q02 | glm-5.3-flash | max | a13 | completed | 280.996 | {"prompt_tokens":4413,"completion_tokens":13835,"total_tokens":18248,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":13578}} | ast_passed | complete | 4.250 |
| q03 | glm-5.3 | low | a08 | completed | 9.204 | {"prompt_tokens":3240,"completion_tokens":386,"total_tokens":3626,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":149}} | ast_rejected | admission_rejected | unknown |
| q03 | glm-5.3 | high | a11 | completed | 416.312 | {"prompt_tokens":3240,"completion_tokens":27416,"total_tokens":30656,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":27140}} | ast_passed | complete | 3.917 |
| q03 | glm-5.3 | max | a36 | completed | 393.203 | {"prompt_tokens":3240,"completion_tokens":26368,"total_tokens":29608,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":26123}} | ast_passed | complete | 5.667 |
| q03 | glm-5.3-flash | low | a22 | completed | 7.648 | {"prompt_tokens":3240,"completion_tokens":233,"total_tokens":3473,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":20}} | ast_passed | complete | 4.083 |
| q03 | glm-5.3-flash | high | a27 | completed | 346.664 | {"prompt_tokens":3240,"completion_tokens":14449,"total_tokens":17689,"prompt_tokens_details":{"cached_tokens":3200},"completion_tokens_details":{"reasoning_tokens":14057}} | ast_passed | complete | 4.583 |
| q03 | glm-5.3-flash | max | a26 | completed | 147.848 | {"prompt_tokens":3240,"completion_tokens":7102,"total_tokens":10342,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":6869}} | ast_passed | complete | 4.250 |
| q04 | glm-5.3 | low | a33 | completed | 5.535 | {"prompt_tokens":3299,"completion_tokens":294,"total_tokens":3593,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":11}} | ast_passed | complete | 3.583 |
| q04 | glm-5.3 | high | a02 | timeout | 900.392 | unknown | not_run | not_run | unknown |
| q04 | glm-5.3 | max | a07 | completed | 534.467 | {"prompt_tokens":3299,"completion_tokens":39679,"total_tokens":42978,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":39275}} | ast_passed | complete | 4.917 |
| q04 | glm-5.3-flash | low | a14 | completed | 7.088 | {"prompt_tokens":3299,"completion_tokens":309,"total_tokens":3608,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":17}} | ast_passed | complete | 3.417 |
| q04 | glm-5.3-flash | high | a35 | completed | 218.567 | {"prompt_tokens":3299,"completion_tokens":10360,"total_tokens":13659,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":10049}} | ast_passed | complete | 3.500 |
| q04 | glm-5.3-flash | max | a23 | completed | 268.109 | {"prompt_tokens":3299,"completion_tokens":13406,"total_tokens":16705,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":13087}} | ast_passed | complete | 3.417 |
| q05 | glm-5.3 | low | a25 | completed | 5.288 | {"prompt_tokens":3173,"completion_tokens":160,"total_tokens":3333,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":37}} | ast_passed | complete | 4.333 |
| q05 | glm-5.3 | high | a18 | completed | 47.797 | {"prompt_tokens":3173,"completion_tokens":3473,"total_tokens":6646,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":3333}} | ast_passed | complete | 4.333 |
| q05 | glm-5.3 | max | a29 | completed | 74.152 | {"prompt_tokens":3173,"completion_tokens":5600,"total_tokens":8773,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":5459}} | ast_passed | complete | 4.333 |
| q05 | glm-5.3-flash | low | a30 | completed | 4.785 | {"prompt_tokens":3173,"completion_tokens":124,"total_tokens":3297,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":0}} | ast_passed | complete | 4.333 |
| q05 | glm-5.3-flash | high | a16 | completed | 70.153 | {"prompt_tokens":3173,"completion_tokens":2892,"total_tokens":6065,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":2755}} | ast_passed | complete | 4.333 |
| q05 | glm-5.3-flash | max | a06 | completed | 39.946 | {"prompt_tokens":3173,"completion_tokens":1285,"total_tokens":4458,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":1146}} | ast_passed | complete | 4.333 |
| q06 | glm-5.3 | low | a03 | completed | 34.838 | {"prompt_tokens":4510,"completion_tokens":1681,"total_tokens":6191,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":1403}} | ast_passed | complete | 4.583 |
| q06 | glm-5.3 | high | a20 | completed | 743.752 | {"prompt_tokens":4510,"completion_tokens":38740,"total_tokens":43250,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":38202}} | ast_passed | complete | 3.917 |
| q06 | glm-5.3 | max | a12 | completed | 390.470 | {"prompt_tokens":4510,"completion_tokens":24952,"total_tokens":29462,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":24582}} | ast_passed | complete | 3.083 |
| q06 | glm-5.3-flash | low | a28 | completed | 7.749 | {"prompt_tokens":4510,"completion_tokens":286,"total_tokens":4796,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":13}} | ast_passed | complete | 4.583 |
| q06 | glm-5.3-flash | high | a19 | completed | 369.615 | {"prompt_tokens":4510,"completion_tokens":16239,"total_tokens":20749,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":15808}} | ast_passed | complete | 2.833 |
| q06 | glm-5.3-flash | max | a01 | completed | 286.456 | {"prompt_tokens":4510,"completion_tokens":14165,"total_tokens":18675,"prompt_tokens_details":{"cached_tokens":0},"completion_tokens_details":{"reasoning_tokens":13773}} | ast_passed | complete | 2.250 |

各条件分母：

| 条件 | planned | attempted | completed | admitted | scored | 失败 | 未运行 | 未知终态 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| glm-5.3/low | 6 | 6 | 6 | 4 | 4 | 0 | 0 | 0 |
| glm-5.3/high | 6 | 6 | 5 | 4 | 4 | 1 | 0 | 0 |
| glm-5.3/max | 6 | 6 | 6 | 6 | 6 | 0 | 0 | 0 |
| glm-5.3-flash/low | 6 | 6 | 6 | 5 | 5 | 0 | 0 | 0 |
| glm-5.3-flash/high | 6 | 6 | 6 | 6 | 6 | 0 | 0 | 0 |
| glm-5.3-flash/max | 6 | 6 | 6 | 5 | 5 | 0 | 0 | 0 |

配对结果仅描述已观测小样本。A−B gap为百分点，较低gap较好；不足配对时不报告差值。

| 条件A | 条件B | 计划同题对数 | 可用同题对数 | 平均gap A−B（百分点） |
|---|---|---:|---:|---:|
| glm-5.3/low | glm-5.3/high | 6 | 3 | -0.167 |
| glm-5.3/low | glm-5.3/max | 6 | 4 | -0.250 |
| glm-5.3/low | glm-5.3-flash/low | 6 | 3 | 0.056 |
| glm-5.3/low | glm-5.3-flash/high | 6 | 4 | 0.292 |
| glm-5.3/low | glm-5.3-flash/max | 6 | 3 | 0.833 |
| glm-5.3/high | glm-5.3/max | 6 | 4 | -0.229 |
| glm-5.3/high | glm-5.3-flash/low | 6 | 3 | -0.278 |
| glm-5.3/high | glm-5.3-flash/high | 6 | 4 | 0.229 |
| glm-5.3/high | glm-5.3-flash/max | 6 | 3 | 0.444 |
| glm-5.3/max | glm-5.3-flash/low | 6 | 5 | 0.200 |
| glm-5.3/max | glm-5.3-flash/high | 6 | 6 | 0.389 |
| glm-5.3/max | glm-5.3-flash/max | 6 | 5 | 0.633 |
| glm-5.3-flash/low | glm-5.3-flash/high | 6 | 5 | 0.167 |
| glm-5.3-flash/low | glm-5.3-flash/max | 6 | 5 | 0.433 |
| glm-5.3-flash/high | glm-5.3-flash/max | 6 | 5 | 0.267 |

n=6仅用于筛选；可用对数低于6时不能按完整配对解释。未做显著性或稳定赢家判断。
