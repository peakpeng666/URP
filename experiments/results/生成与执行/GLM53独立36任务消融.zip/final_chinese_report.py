#!/usr/bin/env python3
"""Unfrozen local reporting only; read final receipts, write the Chinese handoff."""
import argparse
import datetime as dt
import hashlib
import json
import math
from pathlib import Path
from statistics import mean
from report_addendum import handoff_operational_status


REPORT_NAME = "GLM53独立消融_36任务中文报告_20261007.md"
CONDITIONS = [(model, effort) for model in ("glm-5.3", "glm-5.3-flash") for effort in ("low", "high", "max")]
PAIR_A, PAIR_B = "glm-5.3/max", "glm-5.3-flash/high"


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def file_pin(path):
    raw = path.read_bytes()
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def numeric(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def gap_value(task):
    if task.get("code_admission") != "ast_passed" or task.get("evaluation_status") != "complete" or task.get("score_observed") is not True:
        return None
    if task.get("complete_case_scores") != 3:
        return None
    values = [record.get("data", {}).get("report_gap_percent") for record in task.get("evaluation_records", [])]
    values = [value for value in values if numeric(value)]
    return values[-1] if values else None


def evidence_appendix(source):
    """Keep all evidence; hide the old table of partial-pair contrasts only."""
    marker = "配对结果仅描述已观测小样本。A−B gap为百分点，较低gap较好；不足配对时不报告差值。"
    if source.count(marker) != 1:
        raise ValueError("Expected one known paired-comparison summary marker in report.md")
    head, tail = source.split(marker, 1)
    table_header = "| 条件A | 条件B | 计划同题对数 | 可用同题对数 | 平均gap A−B（百分点） |"
    if table_header not in tail:
        raise ValueError("Expected the comparison summary table; refuse broad evidence removal")
    appendix = head.rstrip() + "\n\n最终中文报告仅展示上文6/6完整配对比较。全部15组可用配对的原始记录与对数仍完整保存在 "
    appendix += "`reporting/paired_comparisons.csv` 和 `reporting/paired_tables.json`；原 `report.md` 保持原样。\n"
    return appendix, {"source_report_unchanged": True,
                      "projection": "retain full task/evidence/operational/delivery/per-question-six-condition sections; omit only old 15-row paired contrast summary from this final prose report",
                      "full_partial_pair_data_retained_in": ["reporting/paired_comparisons.csv", "reporting/paired_tables.json"]}


def validate_final(summary, paired, audit, budget):
    tasks = summary["tasks"]
    totals = summary["totals"]
    if len(tasks) != 36 or len({task["task_id"] for task in tasks}) != 36:
        raise ValueError("Final summary must retain all 36 unique logical tasks")
    if any(totals.get(key) != expected for key, expected in {"planned_n": 36, "attempted": 36, "terminal_observed": 36,
            "completed": 35, "timeout": 1, "not_run": 0, "outcome_unknown": 0, "ast_passed": 30,
            "ast_rejected": 5, "score_observed_tasks": 30, "complete_case_scores_observed": 90}.items()):
        raise ValueError("Observed final counts differ from the authorized final handoff; inspect records")
    for model, effort in CONDITIONS:
        rows = [task for task in tasks if task["model"] == model and task["reasoning_effort"] == effort]
        if len(rows) != 6 or len({row["question_id"] for row in rows}) != 6 or not all(row["attempted"] for row in rows):
            raise ValueError("Every final condition needs its six original attempted questions")
        if not all(numeric(row.get("wall_seconds")) for row in rows):
            raise ValueError("All-six wall-time mean cannot impute missing time")
    timeouts = [task["task_id"] for task in tasks if task["timeout"]]
    rejected = sorted(task["task_id"] for task in tasks if task["code_admission"] == "ast_rejected")
    if timeouts != ["a02"] or rejected != ["a08", "a09", "a17", "a24", "a32"]:
        raise ValueError("Final timeout/rejection identities differ")
    pair = next((item for item in paired["pair_comparisons"] if item["condition_a"] == PAIR_A and item["condition_b"] == PAIR_B), None)
    if not pair or pair.get("available_pair_count") != 6 or len(pair.get("paired_rows", [])) != 6:
        raise ValueError("Requested comparison does not have six fully scored same-question pairs")
    if audit.get("complete_case_scores") != 90 or audit.get("eligible_complete_panel_count") != 30 or audit.get("CPU_gate_halted") is not False:
        raise ValueError("Final offline assessment audit does not match the final summary")
    if budget.get("halted") is not False or budget.get("active") is not None or not numeric(budget.get("completed_cpu_seconds")):
        raise ValueError("Final CPU ledger is unresolved")
    return tasks, totals, pair, rejected


def build_report(root):
    summary = read_json(root / "summary.json")
    paired = read_json(root / "reporting/paired_tables.json")
    audit = read_json(root / "evaluation/orchestration/final_assessment_terminal.json")
    budget = read_json(root / "evaluation/budget.json")
    evaluation_protocol = read_json(root / "evaluation/evaluation_protocol.json")
    protocol = read_json(root / "protocol/protocol.json")
    tasks, totals, pair, rejected = validate_final(summary, paired, audit, budget)
    source_report = (root / "report.md").read_text(encoding="utf-8")
    appendix, projection = evidence_appendix(source_report)
    generated = dt.datetime.now(dt.timezone.utc).isoformat()
    condition_rows = []
    for model, effort in CONDITIONS:
        rows = [task for task in tasks if task["model"] == model and task["reasoning_effort"] == effort]
        gaps = [(task["question_id"], gap_value(task)) for task in rows]
        gaps = [(question, value) for question, value in gaps if value is not None]
        condition_rows.append({"model": model, "reasoning_effort": effort, "planned_n": 6, "attempted": len(rows),
                               "completed": sum(task["completed"] for task in rows),
                               "ast_passed": sum(task["code_admission"] == "ast_passed" for task in rows),
                               "ast_rejected": sum(task["code_admission"] == "ast_rejected" for task in rows),
                               "wall_all6_mean_seconds": mean(task["wall_seconds"] for task in rows),
                               "valid_score_n": len(gaps), "valid_score_questions": sorted(question for question, _ in gaps),
                               "valid_subset_gap_mean_percent": mean(value for _, value in gaps) if gaps else None})
    cpu = budget["completed_cpu_seconds"]
    cap = protocol["evaluation_total_cpu_seconds_max"]
    candidate_cpu = sum(row["whole_process_tree_cpu_seconds"] for row in budget["completed_tasks"])
    preparation_cpu = evaluation_protocol["budget"]["offline_preparation_and_ready_cpu_seconds"]
    if not math.isclose(cpu, candidate_cpu + preparation_cpu, abs_tol=1e-8):
        raise ValueError("CPU scalar does not reconcile with candidate ledger plus frozen preparation/READY CPU")
    handoff = handoff_operational_status(root)
    verified_batches = handoff["batch_remote_owner_and_bytes_verified"]
    pending_batches = handoff["batches_without_verified_remote_receipt"]
    if handoff["current_Drive_writes_paused"]:
        delivery_text = "**当前Drive写入依父指令暂停；最终完整ZIP/最终报告远端交接待恢复授权及实际验收回执。**"
    else:
        resume = handoff["Drive_resume_record"]
        delivery_text = f"**Drive写入暂停已于{resume['utc']}依最新用户指令解除；恢复许可不等于交付完成。**"
        delivery_text += "恢复记录载明指定实验资料与报告/审计私有目录均已核验owner-only；实际文件交付进度只按逐件回执判断。"
    delivery_text += f"本轮六份批次ZIP中，已观察到owner-only及实际SHA/大小回读通过的批次为 `{verified_batches}`；"
    delivery_text += f"尚无完整远端验证回执的批次为 `{pending_batches}`。本地pin或ZIP不算远端交付证据。"
    if not handoff["final_delivery_entries"]:
        delivery_text += "最终完整ZIP与最终中文报告仍待实际上传及核验回执。"
    else:
        final_verified = sum(item.get("remote_readback_verified") is True and item.get("owner_only_observed") is True
                             and item.get("remote_sha256") != "unknown" for item in handoff["final_delivery_entries"])
        delivery_text += f"最终文件现观察到{len(handoff['final_delivery_entries'])}份交付回执，其中{final_verified}份有owner-only和SHA回读证据；"
        delivery_text += "回执数量本身不证明全部预期交付集合完整，逐件证据见交付ledger。"
    delivery_text += "历史第1批回执不能据此证明已迁入新子目录。历史2/36报告的远端SHA回读已验证；"
    delivery_text += "历史2/36完整ZIP仅核过owner-only/大小，远端SHA仍unknown（32MiB下载限制及一次proxy CONNECT403，未重试或绕过）。"
    delivery_text += "这些历史文件不代表本次最终36项交付。"
    lines = ["# GLM-5.3 / GLM-5.3-Flash 独立36任务消融中文报告", "",
             f"最终本地记录生成时间：`{generated}`。36项均已单次尝试并保留终态：**35项生成完成，1项客户端超时（a02）**；"
             "未补跑、无截断、无未启动项。AST/接口准入通过30项、拒绝5项；30份合法候选完成90个公开数值case，数值case失败0。"
             f"评分CPU合计 **{cpu:.6f} / {cap} 秒**，门禁未停。5项拒绝为 `{', '.join(rejected)}`；"
             "这些拒绝的15个case占位未执行数值评分，a02也未评分。", "",
             f"CPU总额由候选评估明细{candidate_cpu:.6f}秒与冻结评分协议所记离线准备/READY {preparation_cpu:.6f}秒组成。", "",
             "原132主线的源码、种群、slot、Library身份与账本不纳入本实验。六题由既有冻结P2输入按seed20261007选出，"
             "同题system/user文本跨六条件相同、全为纯文本；36任务顺序预先交错冻结。"
             f"实际执行为官方OpenCode1.18.34、既有国内Coding Plan端点 `{protocol['endpoint']}`；"
             f"每任务输出上限{protocol['max_completion_tokens']}、客户端超时阈值{protocol['client_timeout_seconds']}秒、"
             f"temperature={protocol['temperature']}、top_p={protocol['top_p']}、最多{protocol['max_cli_steps']}个CLI step、tools=false。", "",
             "| 模型 | reasoning_effort | 全6项平均耗时/秒 | 生成完成/6 | AST通过/6 | AST拒绝 | 完整评分/6 | 合法已评分子集平均gap/% |",
             "|---|---|---:|---:|---:|---:|---:|---:|"]
    for row in condition_rows:
        lines.append(f"| {row['model']} | {row['reasoning_effort']} | {row['wall_all6_mean_seconds']:.3f} | "
                     f"{row['completed']}/6 | {row['ast_passed']}/6 | {row['ast_rejected']} | {row['valid_score_n']}/6 | "
                     f"{row['valid_subset_gap_mean_percent']:.3f}（n={row['valid_score_n']}） |")
    lines += ["", "每条件planned=6、attempted=6。耗时均值包含全部6项终态，也包含GLM-5.3/high的a02超时"
              "（实际客户端墙钟900.392秒）；没有只取成功样本。gap仅取该条件真实完整评分的候选，失败/拒绝/超时不填零。"
              "不同条件的有效子集并不相同，子集gap均值不可直接作为六题整体排名。gap是三个case总箱数相对总L1的额外比例，越低越好；"
              "原固定fitness仍为三个case的L1/used_bins均值。", "",
              "本样本的low档耗时较短；GLM-5.3/low仅4/6准入，低于同模型max的6/6；Flash/low为5/6，低于同模型high的6/6。"
              "这呈现了速度与准入覆盖的取舍，不能仅凭成功速度或合法子集均值确定选择。", "",
              "下面仅展示两条件都在原六题完整准入并完成3×1000评分的一组配对。A=GLM-5.3/max，B=GLM-5.3-Flash/high，"
              "可用同题对数=6/6；A−B为百分点。", "",
              "| 同一题 | A任务 | B任务 | A gap/% | B gap/% | A−B/百分点 | A耗时/秒 | B耗时/秒 |",
              "|---|---|---|---:|---:|---:|---:|---:|"]
    for row in pair["paired_rows"]:
        lines.append(f"| {row['question_id']} | {row['task_a']} | {row['task_b']} | {row['gap_a_percent']:.3f} | "
                     f"{row['gap_b_percent']:.3f} | {row['gap_a_minus_b_percentage_points']:+.3f} | "
                     f"{row['wall_a_seconds']:.3f} | {row['wall_b_seconds']:.3f} |")
    pair_wall_difference = mean(row["wall_a_minus_b_seconds"] for row in pair["paired_rows"])
    lines += ["", f"这六对的平均gap A−B为 **{pair['mean_gap_a_minus_b_percentage_points']:+.3f}个百分点**，"
              f"平均耗时A−B为 **{pair_wall_difference:+.3f}秒**。这只是本次观测的描述；"
              "每条件n=6用于筛选，未做显著性检验，不宣称稳定赢家。同一token上限也不代表相同真实算力。"
              "评分仅使用事前固定3个公开design序列各前1000件，未读取heldout，不替代原主线5000件得分。", "",
              f"已观察到35项服务端末项usage，合计 **{totals['total_tokens_observed_sum']:,} token**："
              f"prompt={totals['prompt_tokens_observed_sum']:,}、completion={totals['completion_tokens_observed_sum']:,}；"
              f"缓存命中{totals['cached_tokens_observed_sum']:,}为prompt分项。观察到36次SDK fetch调用，底层HTTP请求次数、SDK自动行为未知。"
              "a02超时后的服务端最终完成、最终usage与取消状态仍未知。"
              f"仅按已观察usage估算基础积分{totals['estimated_base_points_observed_usage_only']:.3f}、"
              f"按已核实节日/非高峰系数估算{totals['estimated_offpeak_points_observed_usage_only']:.3f}积分；"
              "**实际账户扣积分及RMB成本均未知**，不能把这35项估算当完整36项实际费用。", "",
              "操作过程有事后修订：v1在a02超时后停止，父随后授权v2于02:45:57.331713UTC生效，"
              "允许特定已收到HTTP200及response/model ID的客户端超时后继续原顺序；原科学控制pins保持不变。"
              "报告/评分管理包装器后来改为增量管理，固定安全评估器、接口、panel与CPU/内存/时间门禁保持原控制。"
              "a04自然边界暂停以及a19后控制器恢复均在附录保留；旧控制器消失原因unknown。", "",
              delivery_text, "",
              "完整协议、所有36项状态/耗时/usage/错误、原始回执、源码、pins及固定评分记录保留在独立目录中。"
              "下面附运行记录正文；仅省去旧的15组配对差值汇总表，所有逐题六条件数据与对应CSV/JSON仍完整保留。", "",
              "---", "", "## 完整运行证据附录", "", appendix]
    correction = handoff.get("packaging_correction_record")
    if correction:
        note = f"本地打包修正（`{correction.get('utc','unknown')}`）：原循环误按basename跳过全部HANDOFF_MANIFEST.json，"
        note += "连已列入pins的嵌套输入清单也被省略；本地逐件CRC/manifest核验在上传前拒绝旧包。"
        note += "修正为只跳过根目录生成清单、保留嵌套源清单，旧本地构建另行保留于payload根目录外。"
        note += "此修正未改变36项生成/候选、任何评分、协议/runtime/模型/工具pins，没有重跑或重评分，统计不变；"
        note += "修正记录中尚未上传是历史时点，后续交付以实际回执为准。"
        insertion = lines.index("---")
        lines[insertion:insertion] = [note, ""]
    pins = {name: file_pin(root / name) for name in ("summary.json", "report.md", "reporting/paired_tables.json",
            "protocol/protocol.json", "protocol/selection_and_order.json", "evaluation/budget.json",
            "evaluation/assessment.json", "evaluation/evaluation_protocol.json", "evaluation/orchestration/final_assessment_terminal.json")}
    for name in ("DRIVE_WRITES_RESUMED.json", "PACKAGING_CORRECTION.json"):
        if (root / name).is_file():
            pins[name] = file_pin(root / name)
    receipt = {"schema": "independent-ablation-final-chinese-report-v1", "generated_utc": generated,
               "scientific_or_raw_files_modified": False, "model_scoring_or_Drive_calls": 0,
               "conditions": condition_rows, "single_displayed_full_pair": pair,
               "pair_wall_mean_a_minus_b_seconds": pair_wall_difference, "source_pins": pins,
               "CPU_accounting": {"candidate_ledger_cpu_seconds": candidate_cpu, "preparation_and_READY_cpu_seconds": preparation_cpu,
                                  "preparation_source": "evaluation/evaluation_protocol.json budget.offline_preparation_and_ready_cpu_seconds",
                                  "total_budget_cpu_seconds": cpu, "cap_seconds": cap, "reconciled": True},
               "appendix_projection": projection, "current_Drive_writes_paused": handoff["current_Drive_writes_paused"],
               "Drive_write_status_provenance": handoff["current_write_status_provenance"],
               "handoff_operational_status": handoff,
               "final_remote_handoff": "pending final actual delivery receipts" if not handoff["final_delivery_entries"] else "evaluate observed receipts individually; whole final set completeness unknown",
               "actual_cost": "unknown", "underlying_network_request_count": "unknown"}
    return "\n".join(lines).rstrip() + "\n", receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    out = (args.out or root).resolve()
    out.mkdir(parents=True, exist_ok=True)
    body, receipt = build_report(root)
    target = out / REPORT_NAME
    target.write_text(body, encoding="utf-8")
    receipt["output"] = {"file": REPORT_NAME, **file_pin(target)}
    receipt_dir = out / "reporting"
    receipt_dir.mkdir(parents=True, exist_ok=True)
    (receipt_dir / "final_report_receipt.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    # Small portable pointer, so the full prose body is not duplicated in handoff ZIPs.
    (out / "final_report.md").write_text(f"最终中文报告见 [{REPORT_NAME}]({REPORT_NAME})。\n", encoding="utf-8")
    print(json.dumps({"report": str(target), "bytes": receipt["output"]["bytes"], "sha256": receipt["output"]["sha256"],
                      "planned": 36, "completed": 35, "score_observed": 30, "Drive_writes_paused": receipt["current_Drive_writes_paused"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
