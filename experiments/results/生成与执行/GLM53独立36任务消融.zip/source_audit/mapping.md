# OpenCode 1.18.34 配置与 SDK 传递核验（生成前）

本核验没有发出模型请求，没有读取或保存任何密钥。离线记录器测试全部使用内存 mock fetch；其中 mock-server-id 与 token 数只用于测试，不能计入实验。真实服务端是否接受或如何执行 effort/max_tokens，必须以首条及后续真实原始回执为准，配置或源码映射不能证明服务端实际算力。

## 固定源码和 SDK

- 官方源码：`https://codeload.github.com/anomalyco/opencode/tar.gz/refs/tags/v1.18.34`，归档 `opencode-v1.18.34.tar.gz`，SHA256 `c2c60efde22639b64c7bfa740da39b9c8079391a7540e2f67bf91b36e5797f17`。
- 官方 `git ls-remote https://github.com/anomalyco/opencode.git refs/tags/v1.18.34` 返回提交 `aec0b9a6d8898f68f923aaf08b7306d931fd9d76`，原始结果在 `git-tag-v1.18.34.txt`。GitHub refs REST 查询返回 HTTP 403；git 官方只读查询成功。
- 解包源码根：`source_audit/opencode-1.18.34/`；`packages/opencode/package.json:4` 为版本 1.18.34，`:71` 固定 `@ai-sdk/openai-compatible=2.0.41`。
- SDK 官方 npm tar：`https://registry.npmjs.org/@ai-sdk/openai-compatible/-/openai-compatible-2.0.41.tgz`，SHA256 `1067423d0df534c545de4b2aaa86aef5e181cc0da2af050ee6d821eb280a5d7c`。计算 sha512 与该版本 `bun.lock:6407` 的 integrity 逐字相符：`sha512-kNAGINk71AlOXx10Dq/PXw4t/9XjdK8uxfpVElRwtSFMdeSiLVt58p9TPx4/FJD+hxZuVhvxYj9r42osxWq79g==`。
- 官方 `patches/@ai-sdk%2Fopenai-compatible@2.0.41.patch` 只把 stream error 从 message 字符串改为完整 error 对象；没有修改 max_tokens、effort 或 sampling 的映射。
- SDK 解包根：`source_audit/sdk_openai_compatible_2.0.41/package/`。

## 完成上限和 effort 的实际传递路径

| 入口 | 固定版本源码证据 | 结果 |
|---|---|---|
| 模型 `limit.output:64000` | OpenCode `src/provider/provider.ts:1609-1613` | 写入解析模型 limit |
| 仅子进程 `OPENCODE_EXPERIMENTAL_OUTPUT_TOKEN_MAX=64000` | `src/effect/runtime-flags.ts:5-8,52` | 正整数 runtime flag `outputTokenMax` |
| 上述两个上限 | `src/provider/transform.ts:1481-1482` | `Math.min(model.limit.output, outputTokenMax) || outputTokenMax`；两处必须都 64000 |
| `maxOutputTokens` | `src/session/llm/request.ts:129`、`src/session/llm.ts:320` | 传入 AI SDK `streamText` |
| SDK `maxOutputTokens` | SDK `src/chat/openai-compatible-chat-language-model.ts:208` | JSON wire 字段 `max_tokens` |
| 显式 CLI `--variant low/high/max` | OpenCode `src/cli/cmd/run.ts:212-214`；`src/session/llm/request.ts:80-91` | variant 最后合并，覆盖 base/model/agent options |
| 模型显式 `variants.<effort>.reasoningEffort=<effort>` | `src/provider/provider.ts:1619-1627` | 配置 variants 合并，未 disabled 者保留 |
| provider options 命名空间 | `src/provider/transform.ts:1462-1478` | compatible provider 以 providerID 点号前缀为 key；SDK 同样在 `:103-104` split('.') |
| SDK `reasoningEffort` | SDK `src/chat/openai-compatible-chat-language-model.ts:132-163,243` | JSON wire 字段 `reasoning_effort` |

每模型显式列出 low/high/max 三个 variant，不依赖当前 models.dev 或默认档位。模型 API ID 必须分别明确为 `glm-5.3`、`glm-5.3-flash`，provider npm 显式 `@ai-sdk/openai-compatible`。不要启用 `OPENCODE_EXPERIMENTAL_NATIVE_LLM`。

## Sampling、工具、step 与 timeout

agent 配置用 `temperature:0.7`、`top_p:0.9`、`steps:2`、`tools:{"*":false}`、`permission:{"*":"deny"}`。模型必须 `temperature:true`，否则 OpenCode `src/session/llm/request.ts:124-126` 会省略 temperature。agent 的 `top_p` 在 `src/agent/agent.ts:285-286` 转为 topP；`:291` 保留 steps。SDK `src/chat/openai-compatible-chat-language-model.ts:209-210` 分别发出 `temperature`、`top_p`。

`tools:false` 的实际可用配置是 wildcard false 对象。`packages/core/src/v1/config/agent.ts:68-80` 将它转换为 deny permission。`src/session/llm/request.ts:210-215` 真正删除禁止工具；SDK 的空 tools 转换不发送工具定义。记录器另外检查 wire `tools` 长度为 0 且 `tool_choice` 未启用，拒绝 file/image/audio/tool roles。没有生成内容执行。

**仅写 steps=2 并不能证明硬停止。** `src/session/prompt.ts:1178-1179,1281` 只在达到 maxSteps 后附加 MAX_STEPS_PROMPT，循环没有相应 break。记录器通过官方 `experimental.chat.messages.transform` 逐 CLI loop 计数，第 3 步抛出非可重试 gate 错误，且每次 fetch 再次检查 step 不超过 2。成功第一步返回 stop 时，`src/session/prompt.ts:1111-1129` 直接退出。

provider options 设 `timeout:900000`、`headerTimeout:900000`、`chunkTimeout:900000`。`src/provider/provider.ts:96-125` 在 fetch 层组合 AbortSignal 并包装 SSE idle timeout；默认为 header/chunk 300000，故不能只设置 timeout。外层 runner 另外使用整条 CLI 的 900 秒总截止；不重启 CLI、不补跑。

关闭 autocompact/prune、snapshot、autoupdate、模型列表刷新和默认插件；title agent 禁用并传非默认 `--title`。title 额外生成入口在 `src/session/prompt.ts:193-235`，非默认 title 或 agent 缺失都会提前返回。`src/session/summary.ts:102-127` 只生成代码 diff，不调用模型。`--pure` 会在 `src/plugin/index.ts:181` 禁掉本地插件，因此本实验不可带该选项。

AI SDK 本路径 `src/session/llm.ts:323` 为 `maxRetries:input.retries??0`；但 OpenCode processor 在 `src/session/processor.ts:674-687` 另有 session retry，`src/session/retry.ts:31,183-205` 上限 5。透明记录器在一次 transport/provider failure 后阻断后续 fetch，而不改变首次 SDK 请求。任何尝试记录不能误算为重新 CLI 启动。SDK fetch 次数可观察，底层 TCP/HTTP 自动行为未完整观测，必须记 `unknown`。

## 六条件逐字相同上下文

仅统一 cwd/XDG 不够：OpenCode `src/session/system.ts:76` 会把当前模型名称和模型 ID 插入 system，`:79-83` 还写 cwd/worktree/platform/date。`src/session/llm/request.ts:58-73` 拼出完整 system 后调用官方 `experimental.chat.system.transform`。

冻结插件 `ablation-recorder.mjs` 使用这个 hook 将 final system array 整体替换成单一冻结 system 字符串，不增删该字符串的换行或 UTF-8 字节；同题六条件读取同一 system/user 文件及 SHA。官方插件类型在 `packages/plugin/src/index.ts:247-255,282-296`；自定义 provider fetch 入口已在 `src/provider/provider.ts:1491-1495,1539,1698-1705,1849,1853-1860` 核实。插件不改二进制、不换执行器、不独立直接循环调用 API。

`chat.message` 检查实际 CLI user，loop hook 检查 user history，`chat.params` 检查解析模型与计算参数；最后 SDK fetch 前再次检查 JSON body 的唯一 system 和唯一 user 逐字相等，以及 `model/reasoning_effort/max_tokens/temperature/top_p/tools`。保存 `actual_system.txt`、`actual_user.txt` 与实际请求的三个 SHA（system/user/messages）。第 2 step 的模型产出历史可能不同，这属于输出导致的变化，不伪称后续 assistant 历史相同；初始完整 system/user 在六条件逐字相同。

## 原始回执与失败保全

CLI `--format json` 在 `src/cli/cmd/run.ts:745-750` 保存 `step_start/step_finish`；`:781-789` 保存 error。`src/session/processor.ts:452-469` 保存归一 usage/finish。单靠这些会丢弃服务端 response ID、returned model ID、原始 usage（AI SDK adapter `src/session/llm/ai-sdk.ts:88-120,283-286`），不得把 CLI session/message ID 当服务端返回 ID。

透明 fetch 仅原样调用原 SDK fetch 一次，完全不保存或读取 request headers/auth/provider secret options。它保存：

- `fetch-NNN.request.json`：实际 SDK JSON body，包含纯文本输入和真实 wire 参数。
- `fetch-NNN.response.bin`：原始响应 body 字节，含所有 SSE 及失败响应；边到达边追加，超时保留已收到字节。
- `fetch-NNN.metadata.json`：实际 HTTP status、服务端出现过的 ID/model ID、finish_reason、raw usage、完成标志、字节数、SHA、耗时；未提供字段保留空数组或 null。
- `recorder.jsonl`：上下文/参数检查、可观察 SDK fetch 序号、回执、时间；`underlying_network_request_count:"unknown"`。
- `stop.json`：401/403/429 或实际响应中的套餐/额度/鉴权等阻塞指示。

SDK 原始映射证据：`src/chat/openai-compatible-chat-language-model.ts:454-473` 从 SSE 提取 id/model、usage、finish_reason，`src/chat/get-response-metadata.ts:10-13` 读取服务端 id/model。记录器从同一原始 SSE 保存这些字段。OpenCode 本地计算的 cost 不等于套餐账单或服务端实际成本。

插件加载失败在 `src/plugin/index.ts:230-251` 会被忽略，因此配置 `baseURL:"ABLATION_PLUGIN_REQUIRED"` 作为无效 URL 哨兵。插件完成检查并安装 recorder 后才把它替换为唯一获准 `https://open.bigmodel.cn/api/coding/paas/v4`；插件缺失时 SDK 不能向有效外部模型 URL 发送。provider npm 需 root 级显式配置，禁用默认插件，保留本地已审核插件。

每任务设置非秘密变量 `ABLATION_TASK_MANIFEST` 指向 JSON manifest。必填：task_id、provider_id、model_id、reasoning_effort、system_text_path、user_text_path、system_sha256、user_sha256、raw_dir。插件路径为本目录 `ablation-recorder.mjs`。本插件只读取 ABLATION_TASK_MANIFEST；它不读任何 API_KEY 变量。

## 离线验证结果

`node offline-recorder-test.mjs` 成功，`offline_recorder_test.json` 记录 network_calls=0、mock_calls=2。覆盖 UTF-8 完整上下文、final system 规范化、CLI 计算参数、错误上限在发出 mock 前阻断、原始响应逐字节保全、返回 ID/model ID/finish/raw usage、第三 CLI step 阻断、quota stop 文件和失败后 fetch 阻断。离线 mock 输出位于 `offline_mock/`，明确不属于 36 个真实任务；应在交付 ZIP 中与实验 raw 分开或排除。

官方 CLI 静态装载另外通过：同一已批准 binary 执行 `opencode models test-coding`，退出码 0，stdout=`test-coding/glm-5.3`，plugin_initialized=true、fetch_recorder_installed=true、sdk_fetch_starts=0。原始证据为 `offline_cli/result.json`、`offline_cli/raw/recorder.jsonl`，该命令未请求模型生成。

插件依赖从官方 registry 用 npm install `@opencode-ai/plugin@1.18.34 --ignore-scripts --no-audit --no-fund --save-exact` 准备，27 packages 安装成功。两个独立空 npmrc 避免读取用户 npm 凭证，所有可写 cache/config 均在本任务目录。首次最小环境丢弃云网络/TLS配置，得到 EAI_AGAIN；白名单内存继承执行器的 HTTP_PROXY/HTTPS_PROXY、其小写形式、NO_PROXY/no_proxy、NODE_EXTRA_CA_CERTS/SSL_CERT_FILE 后成功。只保存变量名称，不打印/保存其值，不向 npm/静态 CLI 传模型 key。初次静态 CLI 在依赖未完成时 45秒超时，没有模型生成。

可复用 scaffold 为 `offline_cli/config/opencode/`（真实 package.json、package-lock.json、node_modules）。新 task 的 XDG_CONFIG_HOME/opencode 可复制这三件；node_modules 存在且 root package-lock 已列声明依赖时，固定版本 `packages/core/src/npm.ts:155-195` 跳过 reify，避免每 task npm 网络安装。若使用 OPENCODE_CONFIG_DIR，该目录和 global XDG_CONFIG_HOME/opencode 均需同样就绪。官方包锁应保全；临时 npm-cache 与 npm debug log 不需要进入实验交付 ZIP。
