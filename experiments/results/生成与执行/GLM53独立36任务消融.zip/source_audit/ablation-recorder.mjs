import { readFileSync, writeFileSync, appendFileSync, mkdirSync } from 'node:fs';
import { resolve, join } from 'node:path';
import { createHash } from 'node:crypto';

// Official OpenCode plugin hooks only. No independent API client or retry loop.
// The config hook wraps the SDK's original fetch once, without saving headers.
export default async function AblationRecorder() {
  const manifestPath = process.env.ABLATION_TASK_MANIFEST;
  if (!manifestPath) throw new Error('ABLATION_HARD_GATE: missing task manifest');
  const m = JSON.parse(readFileSync(manifestPath, 'utf8'));
  const hash = x => createHash('sha256').update(x).digest('hex');
  const fail = why => { throw new Error(`ABLATION_HARD_GATE: ${why}`); };
  if (!['glm-5.3', 'glm-5.3-flash'].includes(m.model_id)) fail('unapproved model');
  if (!['low', 'high', 'max'].includes(m.reasoning_effort)) fail('unapproved effort');
  if (!m.provider_id || !m.task_id) fail('missing identity');
  const rawDir = resolve(m.raw_dir);
  if (!rawDir.startsWith('/workspace/ablation_20261007/')) fail('raw path outside experiment');
  mkdirSync(rawDir, { recursive: true, mode: 0o700 });
  const system = readFileSync(m.system_text_path, 'utf8');
  const user = readFileSync(m.user_text_path, 'utf8');
  if (hash(system) !== m.system_sha256 || hash(user) !== m.user_sha256) fail('frozen input SHA mismatch');
  const log = record => appendFileSync(join(rawDir, 'recorder.jsonl'), JSON.stringify({ time_utc: new Date().toISOString(), task_id: m.task_id, ...record }) + '\n', { mode: 0o600 });
  const stop = (reason, detail) => writeFileSync(join(rawDir, 'stop.json'), JSON.stringify({ task_id: m.task_id, time_utc: new Date().toISOString(), reason, detail }, null, 2), { mode: 0o600 });
  const checkProviderError = error => {
    const message = JSON.stringify(error ?? {});
    if (/quota|rate.?limit|insufficient|balance|credit|auth|api.?key|套餐|额度|余额|欠费|次数|限流|密钥|认证|权限|账户/i.test(message)) stop('provider_access_or_plan_limit', error);
  };
  const textContent = content => {
    if (typeof content === 'string') return content;
    if (!Array.isArray(content) || content.some(p => p.type !== 'text' || typeof p.text !== 'string')) fail('nontext content');
    return content.map(p => p.text).join('');
  };
  let cliStep = 0;
  let fetchCalls = 0;
  let blocked = false;
  let activeModel;
  log({ event: 'plugin_initialized', frozen_system_sha256: m.system_sha256, frozen_user_sha256: m.user_sha256, plugin_uses_secrets: false });

  function checkBody(body) {
    if (blocked) fail('a previous transport or provider failure forbids another fetch');
    if (cliStep < 1 || cliStep > 2) fail('CLI step limit violated');
    if (body.model !== m.model_id || body.reasoning_effort !== m.reasoning_effort) fail('wire model or effort differs');
    if (body.max_tokens !== 64000 || body.temperature !== 0.7 || body.top_p !== 0.9) fail('wire sampling or completion limit differs');
    if (body.stream !== true) fail('unexpected nonstream request');
    if (body.tools?.length || body.tool_choice != null) fail('tools enabled on wire');
    if (!Array.isArray(body.messages)) fail('missing wire messages');
    const systems = body.messages.filter(x => x.role === 'system');
    const users = body.messages.filter(x => x.role === 'user');
    if (systems.length !== 1 || users.length !== 1) fail('wire system/user count differs');
    if (textContent(systems[0].content) !== system || textContent(users[0].content) !== user) fail('wire frozen context differs');
    for (const msg of body.messages) {
      if (!['system', 'user', 'assistant'].includes(msg.role)) fail('wire unexpected role');
      textContent(msg.content);
      if (msg.tool_calls?.length) fail('unexpected historical tool call');
    }
    return { system_sha256: hash(textContent(systems[0].content)), user_sha256: hash(textContent(users[0].content)), messages_sha256: hash(JSON.stringify(body.messages)) };
  }

  return {
    config: async cfg => {
      const p = cfg.provider?.[m.provider_id];
      if (!p) fail('configured provider missing');
      p.options ??= {};
      if (!['https://open.bigmodel.cn/api/coding/paas/v4', 'ABLATION_PLUGIN_REQUIRED'].includes(p.options.baseURL)) fail('Coding Plan endpoint differs');
      if (p.npm !== '@ai-sdk/openai-compatible') fail('unexpected provider SDK');
      for (const field of ['timeout', 'headerTimeout', 'chunkTimeout']) if (p.options[field] !== 900000) fail(`${field} differs`);
      const originalFetch = p.options.fetch ?? globalThis.fetch.bind(globalThis);
      p.options.fetch = async (input, init) => {
        const url = input instanceof Request ? input.url : String(input);
        if (url !== 'https://open.bigmodel.cn/api/coding/paas/v4/chat/completions') fail('unexpected destination');
        if (typeof init?.body !== 'string') fail('unexpected SDK body encoding');
        let body;
        try { body = JSON.parse(init.body); } catch { fail('invalid SDK JSON body'); }
        const contextHashes = checkBody(body);
        const id = ++fetchCalls;
        const prefix = join(rawDir, `fetch-${String(id).padStart(3, '0')}`);
        // Never log, read, serialize or copy init.headers, auth or provider options.
        writeFileSync(prefix + '.request.json', init.body, { mode: 0o600 });
        log({ event: 'sdk_fetch_start', observable_fetch_call: id, cli_step: cliStep, url, ...contextHashes, model: body.model, reasoning_effort: body.reasoning_effort, max_tokens: body.max_tokens, temperature: body.temperature, top_p: body.top_p, tool_count: body.tools?.length ?? 0 });
        const started = performance.now();
        let res;
        try { res = await originalFetch(input, init); }
        catch (error) {
          blocked = true;
          log({ event: 'sdk_fetch_throw', observable_fetch_call: id, elapsed_ms: performance.now() - started, error_name: error?.name ?? 'unknown' });
          throw error;
        }
        if (!res.ok) blocked = true;
        if ([401, 403, 429].includes(res.status)) stop('provider_http_access_or_plan_limit', { status: res.status });
        log({ event: 'sdk_fetch_headers', observable_fetch_call: id, status: res.status, elapsed_ms: performance.now() - started, content_type: res.headers.get('content-type') });
        const rawPath = prefix + '.response.bin';
        writeFileSync(rawPath, '', { mode: 0o600 });
        const metadata = { task_id: m.task_id, observable_fetch_call: id, underlying_network_request_count: 'unknown', status: res.status, complete: false, returned_response_ids: [], returned_model_ids: [], finish_reasons: [], usages: [] };
        const saveMetadata = () => writeFileSync(prefix + '.metadata.json', JSON.stringify(metadata, null, 2), { mode: 0o600 });
        saveMetadata();
        if (!res.body) return res;
        const digest = createHash('sha256');
        const decoder = new TextDecoder();
        let remainder = '';
        let size = 0;
        const parseLine = line => {
          if (!line.startsWith('data:')) return;
          const data = line.slice(5).trim();
          if (data === '[DONE]') { log({ event: 'sse_done', observable_fetch_call: id }); return; }
          let chunk;
          try { chunk = JSON.parse(data); } catch { return; }
          if (chunk.error != null) { blocked = true; checkProviderError(chunk.error); }
          const newId = chunk.id != null && !metadata.returned_response_ids.includes(chunk.id);
          const newModel = chunk.model != null && !metadata.returned_model_ids.includes(chunk.model);
          if (newId) metadata.returned_response_ids.push(chunk.id);
          if (newModel) metadata.returned_model_ids.push(chunk.model);
          const finish = chunk.choices?.filter(c => c.finish_reason != null).map(c => ({ index: c.index, finish_reason: c.finish_reason })) ?? [];
          metadata.finish_reasons.push(...finish);
          if (chunk.usage != null) metadata.usages.push(chunk.usage);
          if (newId || newModel || chunk.usage != null || chunk.error != null || finish.length) {
            log({ event: 'provider_receipt', observable_fetch_call: id, response_id: chunk.id ?? null, returned_model_id: chunk.model ?? null, created: chunk.created ?? null, finish_reasons: chunk.choices?.filter(c => c.finish_reason != null).map(c => ({ index: c.index, finish_reason: c.finish_reason })) ?? [], usage: chunk.usage ?? null, error: chunk.error ?? null });
          }
        };
        const recordedBody = res.body.pipeThrough(new TransformStream({
          transform(chunk, controller) {
            appendFileSync(rawPath, chunk);
            digest.update(chunk);
            size += chunk.byteLength;
            remainder += decoder.decode(chunk, { stream: true });
            let idx;
            while ((idx = remainder.indexOf('\n')) >= 0) {
              parseLine(remainder.slice(0, idx).replace(/\r$/, ''));
              remainder = remainder.slice(idx + 1);
            }
            controller.enqueue(chunk);
          },
          flush() {
            remainder += decoder.decode();
            if (remainder) parseLine(remainder);
            if (!res.ok) {
              try { checkProviderError(JSON.parse(readFileSync(rawPath, 'utf8'))); } catch {}
            }
            Object.assign(metadata, { complete: true, elapsed_ms: performance.now() - started, response_bytes: size, response_sha256: digest.digest('hex') });
            saveMetadata();
            log({ event: 'sdk_fetch_body_complete', observable_fetch_call: id, elapsed_ms: metadata.elapsed_ms, response_bytes: size, response_sha256: metadata.response_sha256 });
          },
        }));
        return new Response(recordedBody, { status: res.status, statusText: res.statusText, headers: res.headers });
      };
      // With the sentinel the provider cannot connect if plugin loading fails.
      p.options.baseURL = 'https://open.bigmodel.cn/api/coding/paas/v4';
      log({ event: 'fetch_recorder_installed', provider_id: m.provider_id });
    },
    'chat.message': async (_input, output) => {
      const parts = output.parts.filter(x => x.type === 'text' && !x.ignored);
      if (output.parts.some(x => !['text', 'step-start'].includes(x.type))) fail('nontext CLI input');
      if (parts.map(x => x.text).join('') !== user) fail('CLI user differs from frozen prompt');
      writeFileSync(join(rawDir, 'actual_user.txt'), user, { mode: 0o600 });
      log({ event: 'cli_user_checked', user_sha256: hash(user) });
    },
    'experimental.chat.messages.transform': async (_input, output) => {
      cliStep++;
      if (cliStep > 2) fail('CLI step limit reached before generation');
      const users = output.messages.filter(x => x.info.role === 'user');
      if (users.length !== 1 || users[0].parts.filter(x => x.type === 'text' && !x.ignored).map(x => x.text).join('') !== user) fail('user context differs in loop');
      log({ event: 'cli_step_context_checked', cli_step: cliStep, user_sha256: hash(user) });
    },
    'experimental.chat.system.transform': async (input, output) => {
      const oldHash = hash(JSON.stringify(output.system));
      output.system.splice(0, output.system.length, system);
      writeFileSync(join(rawDir, 'actual_system.txt'), system, { mode: 0o600 });
      log({ event: 'system_context_normalized', cli_step: cliStep, original_system_array_sha256: oldHash, actual_system_sha256: hash(system), cli_model_id: input.model.id, cli_api_model_id: input.model.api.id });
    },
    'chat.params': async (input, output) => {
      activeModel = input.model;
      if (input.model.providerID !== m.provider_id || input.model.api.id !== m.model_id) fail('CLI resolved model differs');
      if (output.maxOutputTokens !== 64000 || input.model.limit.output !== 64000) fail('CLI computed completion limit differs');
      if (output.options.reasoningEffort !== m.reasoning_effort || output.temperature !== 0.7 || output.topP !== 0.9) fail('CLI computed effort or sampling differs');
      log({ event: 'cli_params_checked', cli_step: cliStep, model_id: activeModel.id, api_model_id: activeModel.api.id, maxOutputTokens: output.maxOutputTokens, model_limit_output: activeModel.limit.output, reasoningEffort: output.options.reasoningEffort, temperature: output.temperature, topP: output.topP });
    },
  };
}
