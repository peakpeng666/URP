#!/usr/bin/env python3
"""Passive observer: process metadata only; no env, FD contents or endpoints."""
import argparse
import errno
import json
import os
from pathlib import Path
import re
import time

ROOT = Path('/workspace/ablation_20261007')
OUT = ROOT / 'process_observation'
OFFICIAL_EXECUTABLE = str(ROOT / 'pins/opencode')


def utc():
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())


def stat_row(pid):
    try:
        text = Path(f'/proc/{pid}/stat').read_text()
        left, right = text.find('('), text.rfind(')')
        fields = text[right + 2:].split()
        return dict(pid=pid, comm=text[left + 1:right], state=fields[0],
                    ppid=int(fields[1]), pgid=int(fields[2]),
                    start_ticks=int(fields[19]))
    except (OSError, ValueError, IndexError):
        return None


def filtered_identity(pid):
    """Read argv0 and only the known safe prefix ending just after --title.

    os.read(..., 1) avoids reading ahead through the rest of cmdline. No full
    argument list is constructed, stored or emitted. No prompt is read.
    """
    result = dict(executable_argv0=None, title_task_id=None,
                  full_command_line_read=False)
    try:
        result['exe_symlink'] = os.readlink(f'/proc/{pid}/exe')
    except OSError as e:
        result['exe_symlink_error_errno'] = e.errno
    try:
        result['cwd_symlink'] = os.readlink(f'/proc/{pid}/cwd')
    except OSError as e:
        result['cwd_symlink_error_errno'] = e.errno
    fd = None
    try:
        fd = os.open(f'/proc/{pid}/cmdline', os.O_RDONLY)
        def token():
            value = bytearray()
            for _ in range(512):
                b = os.read(fd, 1)
                if not b or b == b'\0':
                    return value.decode('utf8', 'replace')
                value.extend(b)
            raise ValueError('token_bound_exceeded')
        first = token()
        if first != OFFICIAL_EXECUTABLE:
            result['argv0_matches_official'] = False
            return result
        result['executable_argv0'] = first
        result['argv0_matches_official'] = True
        allowed_options = {'--log-level', '--dir', '--agent', '--model', '--variant'}
        for _ in range(12):
            flag = token()
            if flag == '--title':
                title = token()
                if re.fullmatch(r'a(?:0[1-9]|[12][0-9]|3[0-6])', title):
                    result['title_task_id'] = title
                else:
                    result['title_rejected'] = True
                break
            if flag == 'run':
                continue
            if flag in allowed_options:
                token()  # Known nonsensitive argument, discarded immediately.
                continue
            result['prefix_scan_stopped_at_unknown_flag'] = True
            break  # Never read a possible sensitive value or prompt argument.
    except OSError as e:
        result['identity_read_error_errno'] = e.errno
    except ValueError:
        result['identity_bounds_exceeded'] = True
    finally:
        if fd is not None:
            os.close(fd)
    return result


def fd_counts(pid):
    try:
        entries = os.listdir(f'/proc/{pid}/fd')
    except OSError as e:
        return dict(fd_count=None, socket_fd_count=None, fd_directory_error_errno=e.errno)
    sockets = 0
    unknown = 0
    socket_inodes = set()
    for entry in entries:
        try:
            target = os.readlink(f'/proc/{pid}/fd/{entry}')
            if target.startswith('socket:['):
                sockets += 1
                socket_inodes.add(target)  # Count only; never emitted.
        except OSError:
            unknown += 1
    return dict(fd_count=len(entries), socket_fd_count=sockets if unknown == 0 else None,
                observed_socket_fd_lower_bound=sockets, observed_unique_socket_lower_bound=len(socket_inodes),
                fd_link_unknown_count=unknown)


def process_table():
    table = {}
    for entry in os.scandir('/proc'):
        if entry.name.isdigit():
            row = stat_row(int(entry.name))
            if row:
                table[row['pid']] = row
    return table


def dump_json(path, value):
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    os.replace(temp, path)


def run(args):
    OUT.mkdir(exist_ok=True)
    started = utc()
    initial_cpu = time.process_time()
    began = time.monotonic()
    monitor_pid = os.getpid()
    identities = {}
    tasks = {}
    sample_number = 0
    events = open(OUT / 'events.jsonl', 'a', buffering=1)
    samples = open(OUT / 'samples.jsonl', 'a', buffering=1)
    emit = lambda record: events.write(json.dumps(dict(time_utc=utc(), **record)) + '\n')
    limitations = {
        'no_environ_read': True, 'no_full_command_line_read': True,
        'no_fd_content_read': True, 'no_remote_address_read_or_record': True,
        'no_network_requests_made': True, 'no_escalation_requested': True,
        'retrospective_a02_pid': 'not_recorded_unknown',
        'server_cancellation': 'unknown', 'underlying_network_http_attempts': 'unknown',
        'socket_fd_count_null_means_unobservable_not_zero': True,
        'process_absence_and_runner_terminal_support_client_cleanup_only': True,
    }
    metadata = dict(observer_pid=monitor_pid, observer_ppid=os.getppid(),
                    started_utc=started, polling_interval_seconds=args.interval,
                    approved_executable=OFFICIAL_EXECUTABLE, limitations=limitations)
    dump_json(OUT / 'observer_metadata.json', metadata)
    emit(dict(event='observer_started', **metadata))
    print(json.dumps(dict(observer_pid=monitor_pid, output_directory=str(OUT), started_utc=started)), flush=True)
    while time.monotonic() - began < args.max_hours * 3600:
        tick = time.monotonic()
        table = process_table()
        now = utc()
        for row in table.values():
            if row['comm'] != 'opencode':
                continue
            key = f"{row['pid']}:{row['start_ticks']}"
            if key not in identities:
                identity = filtered_identity(row['pid'])
                identities[key] = identity
                if identity.get('argv0_matches_official') and identity.get('title_task_id'):
                    task_id = identity['title_task_id']
                    previous = tasks.get(task_id)
                    if previous and previous['root_process_key'] != key:
                        emit(dict(event='additional_client_process_seen_for_task', task_id=task_id, **row))
                    tasks[task_id] = dict(task_id=task_id, root_process_key=key,
                        root_pid=row['pid'], root_start_ticks=row['start_ticks'],
                        root_ppid=row['ppid'], root_pgid=row['pgid'],
                        identity=identity, first_seen_utc=now, last_seen_utc=now,
                        root_first_absent_utc=None, terminal_first_seen_utc=None,
                        postterminal_absence_samples=0, tracked_descendants={},
                        server_cancellation='unknown', underlying_network_http_attempts='unknown')
                    emit(dict(event='official_client_first_seen', task_id=task_id, **row, **identity))
        task_samples = []
        for task_id, state in tasks.items():
            root = table.get(state['root_pid'])
            root_live = root is not None and root['start_ticks'] == state['root_start_ticks']
            terminal_path = ROOT / 'raw' / task_id / 'terminal.json'
            if terminal_path.is_file() and state['terminal_first_seen_utc'] is None:
                state['terminal_first_seen_utc'] = now
                try:
                    terminal = json.loads(terminal_path.read_text())
                    terminal_fields = {k:terminal[k] for k in ['exit_code', 'timed_out', 'success', 'finished_utc', 'status'] if k in terminal and isinstance(terminal[k], (str, bool, int, float, type(None)))}
                except (OSError, ValueError):
                    terminal_fields = {'terminal_fields_read': 'unavailable'}
                state['terminal_fields'] = terminal_fields
                emit(dict(event='runner_terminal_first_seen', task_id=task_id, **terminal_fields))
            descendant_pids = {state['root_pid']}
            changed = True
            while changed:
                changed = False
                for row in table.values():
                    if row['ppid'] in descendant_pids and row['pid'] not in descendant_pids:
                        descendant_pids.add(row['pid'])
                        changed = True
            descendants = []
            for row in table.values():
                key = f"{row['pid']}:{row['start_ticks']}"
                previous = state['tracked_descendants'].get(key)
                member = row['pid'] != state['root_pid'] and (row['pid'] in descendant_pids or row['pgid'] == state['root_pgid'] or previous is not None)
                if not member:
                    continue
                if previous is None:
                    state['tracked_descendants'][key] = dict(**row, first_seen_utc=now, last_seen_utc=now)
                    emit(dict(event='descendant_first_seen', task_id=task_id, **row))
                else:
                    previous['last_seen_utc'] = now
                descendants.append(dict(**row, **fd_counts(row['pid'])))
            if root_live:
                state['last_seen_utc'] = now
            elif state['root_first_absent_utc'] is None:
                state['root_first_absent_utc'] = now
                emit(dict(event='client_pid_absent_in_proc', task_id=task_id, pid=state['root_pid'], start_ticks=state['root_start_ticks'], server_cancellation='unknown'))
            terminal_seen = state['terminal_first_seen_utc'] is not None
            if terminal_seen and not root_live and not descendants:
                state['postterminal_absence_samples'] += 1
                if state['postterminal_absence_samples'] == 1:
                    state['postterminal_cleanup_first_observed_utc'] = now
                    emit(dict(event='postterminal_client_and_descendants_absent', task_id=task_id, root_pid=state['root_pid'], server_cancellation='unknown', underlying_network_http_attempts='unknown'))
            if root_live or descendants or (terminal_seen and state['postterminal_absence_samples'] <= 5):
                processes = ([dict(**root, **fd_counts(root['pid']))] if root_live else []) + descendants
                task_samples.append(dict(task_id=task_id, root_present=root_live, process_count=len(processes), descendant_count=len(descendants), processes=processes, terminal_seen=terminal_seen, postterminal_absence_samples=state['postterminal_absence_samples']))
        sample_number += 1
        samples.write(json.dumps(dict(time_utc=now, sample_number=sample_number, tasks=task_samples)) + '\n')
        summary = dict(**metadata, last_sample_utc=now, sample_count=sample_number,
                       monitor_cpu_seconds=time.process_time() - initial_cpu,
                       wall_seconds=time.monotonic() - began, tasks=tasks)
        if sample_number % 10 == 1 or args.snapshot:
            dump_json(OUT / 'summary.json', summary)
        if args.snapshot or (OUT / 'stop.request').exists():
            break
        if len(tasks) and all(state['postterminal_absence_samples'] >= 5 for state in tasks.values()) and all((ROOT / 'raw' / f'a{i:02}' / 'terminal.json').exists() for i in range(1, 37)):
            break
        time.sleep(max(0, args.interval - (time.monotonic() - tick)))
    summary['ended_utc'] = utc()
    dump_json(OUT / 'summary.json', summary)
    emit(dict(event='observer_ended', sample_count=sample_number, monitor_cpu_seconds=time.process_time() - initial_cpu))
    events.close()
    samples.close()
    print(json.dumps(dict(observer_pid=monitor_pid, sample_count=sample_number, ended_utc=summary['ended_utc'])), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--interval', type=float, default=1.0)
    parser.add_argument('--max-hours', type=float, default=12.0)
    parser.add_argument('--snapshot', action='store_true')
    args = parser.parse_args()
    if args.interval < 1:
        parser.error('interval must be at least one second')
    run(args)
