"""Assess all36 frozen logical tasks, then score exact sources in restricted children.

The public-text extractor preserves the original receiver_revision_v2 rules.
This host performs no AST parsing, compilation, import or execution of candidates.
Incremental runs reuse every real score identity without relaunching it. Pending
generation rows live only in the aggregate checkpoint, not score result folders.
"""
import argparse
import collections
import fcntl
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import re
import resource
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
EVALUATION = ROOT / 'evaluation'
MAX_RAW = 262144
MAX_SOURCE = 16384
MAX_DESCRIPTION = 2048
MINIMAL_ENV = {'LANG': 'C.UTF-8', 'PYTHONDONTWRITEBYTECODE': '1',
               'OPENBLAS_NUM_THREADS': '1', 'OMP_NUM_THREADS': '1',
               'MKL_NUM_THREADS': '1', 'NUMEXPR_NUM_THREADS': '1',
               'BLIS_NUM_THREADS': '1', 'VECLIB_MAXIMUM_THREADS': '1'}
NO_FUTURE_SCORE = {'budget_stop', 'budget_or_unknown_accounting_stop', 'integrity_stop',
                   'score_timeout', 'unknown_score_result', 'unresolved_prior_score_attempt'}

def now():
    return datetime.now(timezone.utc).isoformat()

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False)

def digest(value):
    return sha(canonical(value).encode('utf-8'))

def require(condition, reason):
    if not condition:
        raise ValueError(reason)

def write_new(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8') as handle:
        handle.write(canonical(value) + '\n')
        handle.flush()
        os.fsync(handle.fileno())

def replace_json(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    with temporary.open('w', encoding='utf-8') as handle:
        handle.write(canonical(value) + '\n')
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)

def load(path):
    return json.loads(path.read_bytes())

def extract(capture):
    """Exact original receiver_revision_v2 unique extraction and strict metric."""
    require(type(capture) is dict and type(capture.get('raw')) is str, 'capture_type')
    raw = capture['raw']
    require(len(raw) <= MAX_RAW, 'raw_character_bound')
    encoded = raw.encode('utf-8', errors='strict')
    require(0 < len(encoded) <= MAX_RAW, 'raw_byte_bound')
    require(capture.get('status') == 'ok' and capture.get('capture_complete') is True,
            'nonterminal_or_failed_capture')
    require(capture.get('finish_reason') in ('stop', 'length') and
            type(capture.get('tool_calls')) is list and not capture['tool_calls'], 'finish_or_tool_call')
    require(raw.count('```') == 2, 'unique_code_block')
    blocks = list(re.finditer(r'```python\r?\n(.*?)```', raw, re.DOTALL))
    require(len(blocks) == 1, 'unique_complete_python_block')
    block = blocks[0]
    outside = raw[:block.start()] + raw[block.end():]
    descriptions = list(re.finditer(r'\{([^{}]+)\}', outside))
    require(len(descriptions) == 1 and outside.count('{') == outside.count('}') == 1,
            'unique_public_description')
    description, code = descriptions[0].group(1).strip(), block.group(1)
    require(0 < len(description.encode('utf-8')) <= MAX_DESCRIPTION, 'public_description_byte_bound')
    require(code.endswith('\n') and 0 < len(code.encode('utf-8')) <= MAX_SOURCE, 'exact_source_bound')
    candidate = {'description': description, 'code': code,
            'description_sha256': sha(description.encode('utf-8')),
            'code_sha256': sha(code.encode('utf-8')),
            'pair_sha256': digest({'description': description, 'code': code}),
            'description_consistency': 'undetermined'}
    strict = re.fullmatch(r'\s*\{[^{}]+\}\s*```python\r?\n.*?```\s*', raw, re.DOTALL) is not None
    return candidate, sha(encoded), {'unique': True, 'strict': strict}

def frozen_inputs():
    freeze = load(ROOT / 'protocol/FREEZE.json')
    for name in ('protocol/selection_and_order.json', 'protocol/protocol.json',
                 'evaluation/evaluation_protocol.json', 'evaluation/evaluate_candidate.py',
                 'evaluation/public_design_prefixes.json'):
        pin = freeze['files'][name]
        value = (ROOT / name).read_bytes()
        require(len(value) == pin['bytes'] and sha(value) == pin['sha256'], 'frozen_file_changed:' + name)
    plan = load(ROOT / 'protocol/selection_and_order.json')
    tasks = plan['tasks']
    require(len(tasks) == 36 and len({task['task_id'] for task in tasks}) == 36, 'logical_task_count')
    require([task['order'] for task in tasks] == list(range(1, 37)), 'frozen_task_order')
    return tasks, sha((ROOT / 'protocol/FREEZE.json').read_bytes())

def finish_values(values):
    return [value.get('finish_reason') if isinstance(value, dict) else value for value in values]

def stream_content(raw):
    """Mirror runner concatenation; independently check exact emitted bytes."""
    try:
        objects = [json.loads(raw)]
    except (ValueError, UnicodeDecodeError):
        objects = []
        for line in raw.decode('utf-8', errors='strict').splitlines():
            if line.startswith('data:') and line[5:].strip() != '[DONE]':
                try:
                    objects.append(json.loads(line[5:].strip()))
                except ValueError:
                    # Match recorder/runner treatment while metadata SHA and
                    # complete-stream gates remain mandatory below.
                    continue
    content = []
    finishes = []
    calls = []
    indices = set()
    errors = []
    for obj in objects:
        if not isinstance(obj, dict):
            continue
        if obj.get('error') is not None:
            errors.append(True)
        for choice in obj.get('choices', []):
            if choice.get('index') is not None:
                indices.add(choice['index'])
            if choice.get('finish_reason') is not None:
                finishes.append(choice['finish_reason'])
            piece = choice.get('delta', choice.get('message', {}))
            if isinstance(piece.get('content'), str):
                content.append(piece['content'])
            if piece.get('tool_calls'):
                calls.extend(piece['tool_calls'])
            if piece.get('function_call'):
                calls.append(piece['function_call'])
    require(not errors, 'provider_error_in_capture')
    require(not indices or indices == {0}, 'multiple_or_unknown_choice_indices')
    return ''.join(content).encode('utf-8'), finishes, calls

def terminal_assessment(task):
    folder = ROOT / 'raw' / task['task_id']
    row = dict(task, schema='independent-ablation-task-assessment-v1',
               generation_status='not_run', status='not_scored', evaluation_status='not_run',
               code_admission='not_run', format_unique=False, format_strict=None,
               truncated=False, timed_out=False, finish_reasons=[], cases=[],
               fitness=None, report_gap_percent=None, total_cpu_seconds=None,
               source_rewritten=False, retries=0, scored=False)
    row.update(evaluation_attempted=False, evaluation_process_started=False,
               score_observed=False, case_attempts=0, complete_case_scores=0,
               generation_terminal_observed=False)
    if not (folder / 'invocation.json').exists():
        row['reason'] = 'logical_generation_task_not_started'
        return row, None, None
    if not (folder / 'terminal.json').exists():
        row.update(generation_status='unknown', code_admission='unknown', reason='invocation_without_terminal')
        return row, None, None
    terminal = load(folder / 'terminal.json')
    require(all(terminal.get(key) == task[key] for key in ('task_id', 'question_id', 'model', 'reasoning_effort', 'order')),
            'terminal_task_identity_mismatch')
    row.update(terminal_sha256=sha((folder / 'terminal.json').read_bytes()),
               generation_terminal_observed=True,
               exit_code=terminal.get('exit_code'), generation_wall_seconds=terminal.get('wall_seconds'),
               timed_out=terminal.get('timed_out') is True, terminal_status_raw=terminal.get('status'))
    records = terminal.get('responses', [])
    row['finish_reasons'] = [reason for record in records for reason in record.get('raw_finish_reasons', [])]
    row['truncated'] = any(reason in ('length', 'max_tokens', 'max_output_tokens', 'token_limit') for reason in row['finish_reasons'])
    if row['timed_out']:
        row.update(generation_status='timeout', code_admission='not_run', reason='generation_client_timeout')
        return row, None, None
    if terminal.get('exit_code') != 0 or terminal.get('status') != 'completed':
        row.update(generation_status='failed', code_admission='not_run', reason='failed_generation_terminal')
        return row, None, None
    row['generation_status'] = 'truncated' if row['truncated'] else 'completed'
    try:
        require(records, 'no_provider_response')
        pieces, all_calls, checked_finishes, evidence = [], [], [], []
        for record in records:
            response_path = (ROOT / record['file']).resolve(strict=True)
            require(response_path.parent == folder.resolve() and re.fullmatch(r'fetch-\d{3}\.response\.bin', response_path.name),
                    'response_path_not_expected')
            response_raw = response_path.read_bytes()
            require(len(response_raw) == record['bytes'] and sha(response_raw) == record['sha256'], 'response_terminal_SHA_mismatch')
            prefix = response_path.name.removesuffix('.response.bin')
            metadata_path = folder / (prefix + '.metadata.json')
            metadata = load(metadata_path)
            require(metadata.get('task_id') == task['task_id'], 'response_metadata_task')
            require(type(metadata.get('status')) is int and 200 <= metadata['status'] < 300, 'response_http_status')
            require(metadata.get('complete') is True, 'response_stream_not_complete')
            require(metadata.get('response_bytes') == len(response_raw) and metadata.get('response_sha256') == sha(response_raw),
                    'response_metadata_SHA_mismatch')
            content, finishes, calls = stream_content(response_raw)
            require(finishes and finishes == record['raw_finish_reasons'], 'provider_finish_receipt_mismatch')
            require(finish_values(metadata.get('finish_reasons', [])) == finishes, 'metadata_finish_mismatch')
            require(all(reason in ('stop', 'length') for reason in finishes), 'unsupported_provider_finish_reason')
            content_path = folder / (prefix + '.response.candidate.txt')
            require(content_path.is_file() and content_path.read_bytes() == content, 'runner_candidate_not_exact_provider_content')
            pieces.append(content)
            all_calls.extend(calls)
            checked_finishes.extend(finishes)
            evidence.append({'response_file': str(response_path.relative_to(ROOT)),
                             'response_sha256': sha(response_raw), 'content_file': str(content_path.relative_to(ROOT)),
                             'content_sha256': sha(content), 'content_bytes': len(content),
                             'metadata_sha256': sha(metadata_path.read_bytes()), 'finish_reasons': finishes})
        raw = b''.join(pieces)  # Original ordered emitted content; no inserted whitespace or repair.
        require(0 < len(raw) <= MAX_RAW, 'raw_byte_bound')
        text = raw.decode('utf-8', errors='strict')
        candidate, raw_sha, metrics = extract({'raw': text, 'status': 'ok', 'capture_complete': True,
                                              'finish_reason': checked_finishes[-1], 'tool_calls': all_calls})
        row.update(code_admission='format_passed', format_unique=metrics['unique'], format_strict=metrics['strict'],
                   raw_content_sha256=raw_sha, raw_content_bytes=len(raw),
                   source_sha256=candidate['code_sha256'], source_bytes=len(candidate['code'].encode('utf-8')),
                   description_sha256=candidate['description_sha256'], description_consistency='undetermined',
                   provider_content_evidence=evidence,
                   truncation_policy='length flagged; complete original-format source may still undergo AST/scoring as in original receiver')
        return row, candidate, raw
    except (ValueError, UnicodeError, OSError, KeyError, TypeError) as exc:
        row.update(code_admission='format_rejected', evaluation_status='not_run',
                   reason=type(exc).__name__ + ':' + str(exc))
        return row, None, None

def score_fields(receipt):
    admission = receipt.get('admission') or {}
    admitted = (admission.get('result') or {}).get('admitted')
    cpu = receipt.get('cpu') or {}
    cases = []
    for case in receipt.get('cases', []):
        cases.append({key: case.get(key) for key in ('case_id', 'instance_index', 'n', 'input_sha256',
                                                    'outcome', 'used_bins', 'L1', 'assignment_sha256', 'checker_status')})
    attempted_cases = sum(case.get('outcome') in ('ok', 'numeric_failure', 'resource_limit', 'timeout') for case in cases)
    complete_cases = sum(case.get('outcome') == 'ok' and case.get('used_bins') is not None for case in cases)
    return {'status': receipt.get('status', 'unknown_score_result'),
            'evaluation_status': receipt.get('status', 'unknown_score_result'),
            'code_admission': 'ast_passed' if admitted is True else ('ast_rejected' if admitted is False else 'unknown'),
            'ast_admission_kind': (admission.get('result') or {}).get('kind'),
            'scored': admitted is True and attempted_cases > 0,
            'evaluation_attempted': bool(admission),
            'evaluation_process_started': True,
            'score_observed': receipt.get('public_prefix_fitness') is not None,
            'case_attempts': attempted_cases, 'complete_case_scores': complete_cases,
            'cases': cases, 'fitness': receipt.get('public_prefix_fitness'),
            'report_gap_percent': receipt.get('report_gap_percent'),
            'total_cpu_seconds': cpu.get('whole_process_tree_cpu_seconds'),
            'evaluation_wall_seconds': receipt.get('wall_seconds'),
            'cumulative_numeric_CPU_gate_seconds': receipt.get('total_gate_cpu_after_this_candidate'),
            'reason': receipt.get('reason')}

def score_one(task, row, candidate, raw):
    folder = ROOT / 'raw' / task['task_id']
    source_path = folder / 'candidate.py'
    exact = candidate['code'].encode('utf-8')
    if source_path.exists():
        require(source_path.read_bytes() == exact, 'existing_extracted_source_changed')
    else:
        with source_path.open('xb') as handle:
            handle.write(exact)
    require(sha(source_path.read_bytes()) == row['source_sha256'], 'written_source_identity')
    content_path = folder / 'assessment.model_content.txt'
    if content_path.exists():
        require(content_path.read_bytes() == raw, 'existing_content_capture_changed')
    else:
        content_path.write_bytes(raw)
    receipt_path = EVALUATION / 'results' / task['task_id'] / 'receipt.json'
    attempt_path = folder / 'assessment_invocation.json'
    if receipt_path.exists():
        receipt = load(receipt_path)
        require(receipt.get('task_id') == task['task_id'] and receipt.get('source_sha256', row['source_sha256']) == row['source_sha256'],
                'existing_score_receipt_identity')
        row.update(score_fields(receipt), evaluator_receipt_sha256=sha(receipt_path.read_bytes()),
                   evaluator_receipt=str(receipt_path.relative_to(ROOT)), replayed_existing_receipt=True)
        return row
    if attempt_path.exists() or (EVALUATION / 'results' / task['task_id']).exists():
        row.update(status='unresolved_prior_score_attempt', evaluation_status='not_scored',
                   reason='consumed score identity without terminal receipt; never retry')
        return row
    command = [sys.executable, '-I', '-B', str(EVALUATION / 'evaluate_candidate.py'),
               '--task-id', task['task_id'], '--source-path', str(source_path),
               '--raw-response-path', str(content_path)]
    write_new(attempt_path, {'task_id': task['task_id'], 'started_utc': now(), 'command': command,
                            'environment_variable_names': sorted(MINIMAL_ENV),
                            'secrets_or_proxy_inherited': False, 'source_sha256': row['source_sha256'],
                            'score_starts': 1, 'retries': 0, 'timeout_seconds': 120})
    row['evaluation_process_started'] = True
    started = time.monotonic()
    timed_out = False
    with (folder / 'assessment.stdout.log').open('xb') as out, (folder / 'assessment.stderr.log').open('xb') as err:
        child = subprocess.Popen(command, cwd=ROOT, env=dict(MINIMAL_ENV), stdin=subprocess.DEVNULL,
                                 stdout=out, stderr=err, start_new_session=True, close_fds=True)
        try:
            child.wait(timeout=120)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(child.pid, signal.SIGTERM)
            try:
                child.wait(timeout=2)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait(timeout=2)
    write_new(folder / 'assessment_terminal.json', {'task_id': task['task_id'], 'ended_utc': now(),
              'exit_code': child.returncode, 'timed_out': timed_out, 'wall_seconds': time.monotonic() - started,
              'receipt_present': receipt_path.exists(), 'retries': 0})
    row.update(evaluator_exit_code=child.returncode, evaluator_outer_timeout=timed_out)
    if timed_out:
        row.update(status='score_timeout', evaluation_status='not_scored',
                   reason='wrapper timeout; descendant cleanup/accounting not independently proved; stop all later scoring')
    elif not receipt_path.exists():
        row.update(status='unknown_score_result', evaluation_status='not_scored',
                   reason='evaluator exited without terminal receipt; never retry; stop all later scoring')
    else:
        receipt = load(receipt_path)
        require(receipt.get('task_id') == task['task_id'] and receipt.get('source_sha256', row['source_sha256']) == row['source_sha256'],
                'score_receipt_identity')
        row.update(score_fields(receipt), evaluator_receipt_sha256=sha(receipt_path.read_bytes()),
                   evaluator_receipt=str(receipt_path.relative_to(ROOT)))
    return row

def self_check():
    code = 'def score(item, bins):\n    return bins\n'
    raw = '{Public algorithm}\n```python\n' + code + '```\n'
    candidate, _, metrics = extract({'raw': raw, 'status': 'ok', 'capture_complete': True,
                                     'finish_reason': 'stop', 'tool_calls': []})
    require(candidate['code'].encode() == code.encode() and metrics == {'unique': True, 'strict': True}, 'exact_extraction_self_check')
    for value in (raw + raw, raw.replace('```python', '```'), raw.replace('Public algorithm', 'A{B}')):
        try:
            extract({'raw': value, 'status': 'ok', 'capture_complete': True, 'finish_reason': 'stop', 'tool_calls': []})
        except ValueError:
            pass
        else:
            raise ValueError('malformed_format_self_check')
    require(not any(re.search(r'key|secret|proxy|token|auth', key, re.I) for key in MINIMAL_ENV), 'minimal_environment_names')
    print(json.dumps({'status': 'passed', 'candidate_AST_parses': 0, 'candidate_compilations': 0,
                      'candidate_invocations': 0, 'minimal_environment_variable_names': sorted(MINIMAL_ENV)}))

def safe_unstarted_placeholder(task, row, directory, budget):
    """Administrative evidence only: never inspect candidate/model text here."""
    return (
        row.get('task_id') == task['task_id']
        and row.get('generation_status') == 'not_run'
        and row.get('status') == 'not_scored'
        and row.get('evaluation_status') == 'not_run'
        and row.get('code_admission') == 'not_run'
        and not row.get('scored')
        and not row.get('evaluation_attempted')
        and not row.get('evaluation_process_started')
        and not row.get('score_observed')
        and not row.get('cases')
        and not row.get('numerical_gate_prevented_score')
        and row.get('total_cpu_seconds') is None
        and sorted(path.name for path in directory.iterdir()) == ['assessment.json']
        and not (ROOT / 'raw' / task['task_id'] / 'assessment_invocation.json').exists()
        and not any(entry.get('task_id') == task['task_id'] for entry in budget['completed_tasks'])
        and (budget.get('active') or {}).get('task_id') != task['task_id']
    )

def administrative_pins():
    """Hash identity evidence only; never parse candidate source or model text."""
    paths = [EVALUATION / 'budget.json', EVALUATION / 'evaluation_protocol.json',
             EVALUATION / 'evaluate_candidate.py', EVALUATION / 'public_design_prefixes.json']
    paths.extend(path for path in (EVALUATION / 'runtime').iterdir() if path.is_file())
    for task_id in ('a01', 'a02'):
        directory = EVALUATION / 'results' / task_id
        if directory.exists():
            paths.extend(path for path in directory.rglob('*') if path.is_file())
    return {str(path.relative_to(EVALUATION)): {'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes())}
            for path in sorted(set(paths))}

def archive_unstarted_placeholders(tasks):
    """One-time checkpoint2 migration of never-scored administrative records."""
    budget = load(EVALUATION / 'budget.json')
    eligible = []
    for task in tasks:
        if task['order'] < 3:
            continue
        directory = EVALUATION / 'results' / task['task_id']
        assessment = directory / 'assessment.json'
        if assessment.exists():
            row = load(assessment)
            if safe_unstarted_placeholder(task, row, directory, budget):
                eligible.append((task, directory))
    if not eligible:
        return []
    before = administrative_pins()
    history = EVALUATION / 'history_checkpoint2'
    history.mkdir(exist_ok=True)
    destinations = history / 'results'
    destinations.mkdir(exist_ok=True)
    require(not (history / 'MANIFEST.json').exists(), 'checkpoint2 migration already sealed')
    aggregate = EVALUATION / 'assessment.json'
    aggregate_pin = None
    if aggregate.exists():
        aggregate_pin = {'bytes': aggregate.stat().st_size, 'sha256': sha(aggregate.read_bytes())}
        require(not (history / 'assessment.json').exists(), 'checkpoint2 aggregate destination exists')
        aggregate.rename(history / 'assessment.json')
    moves = []
    for task, directory in eligible:
        target = destinations / task['task_id']
        require(not target.exists(), 'checkpoint2 task destination exists:' + task['task_id'])
        original = directory / 'assessment.json'
        pin = {'bytes': original.stat().st_size, 'sha256': sha(original.read_bytes())}
        directory.rename(target)
        require(sha((target / 'assessment.json').read_bytes()) == pin['sha256'], 'archived_wrapper_SHA_mismatch')
        moves.append({'task_id': task['task_id'], 'original': str(directory.relative_to(EVALUATION)),
                      'archived': str(target.relative_to(EVALUATION)), 'assessment_pin': pin})
    after = administrative_pins()
    require(before == after, 'protected_score_runtime_or_CPU_ledger_changed')
    write_new(history / 'MANIFEST.json', {'schema': 'administrative-wrapper-checkpoint2-migration-v1',
              'utc': now(), 'moved_unstarted_wrappers': moves, 'previous_aggregate_pin': aggregate_pin,
              'protected_before_and_after_identical': before, 'actual_scoring_invocations': 0,
              'model_content_reads_for_decision': 0, 'candidate_code_changes': 0,
              'reason': 'Archive pre-amendment not_run placeholders to permit each newly terminal logical task its first evaluation; real score identities remain consumed'})
    print(json.dumps({'archived_never_scored_placeholders': len(moves),
                      'task_ids': [move['task_id'] for move in moves],
                      'protected_pins_unchanged': True}), flush=True)
    return moves

def main_locked(args):
    tasks, freeze_sha = frozen_inputs()
    migrated = archive_unstarted_placeholders(tasks)
    if args.archive_placeholders_only:
        return 0
    terminal_count = sum((ROOT / 'raw' / task['task_id'] / 'terminal.json').exists() for task in tasks)
    if args.require_all_terminal:
        uncertain = [task['task_id'] for task in tasks if (ROOT / 'raw' / task['task_id'] / 'invocation.json').exists()
                     and not (ROOT / 'raw' / task['task_id'] / 'terminal.json').exists()]
        require(not uncertain, 'generation_still_running_or_unknown:' + ','.join(uncertain))
        require(terminal_count == 36 or (ROOT / 'STOP.json').is_file(), 'generation_not_terminal_for_all_tasks_and_no_stop')
    source_bridge = ROOT / 'inputs/P2/exporter_receiver_compatibility_20261005/receiver_revision_v2/bridge.py'
    protocol = load(EVALUATION / 'evaluation_protocol.json')
    aggregate = {'schema': 'independent-ablation-assessment-v1', 'started_utc': now(),
                 'logical_tasks': 36, 'freeze_sha256': freeze_sha,
                 'management_mode': 'incremental terminal-only assessment; real scored identities reused without retries',
                 'generation_terminal_count_at_start': terminal_count,
                 'placeholder_migrations_this_run': [move['task_id'] for move in migrated],
                 'evaluation_protocol_sha256': sha((EVALUATION / 'evaluation_protocol.json').read_bytes()),
                 'assessment_source_sha256': sha(Path(__file__).read_bytes()),
                 'text_extraction_basis': {'source': str(source_bridge.relative_to(ROOT)), 'sha256': sha(source_bridge.read_bytes()),
                                           'rules': 'original extract format/source constraints; strict format is separate metric; no AST on host'},
                 'score_environment_variable_names': sorted(MINIMAL_ENV), 'secrets_or_proxy_inherited': False,
                 'candidate_source_rewritten': False, 'scoring_retries': 0,
                 'numerical_budget_gate': protocol['budget'], 'results': [], 'scoring_stopped': False,
                 'small_n_claim_limit': 'n6 screening; no significance/stable winner; same token cap is not same real compute'}
    results_root = EVALUATION / 'results'
    results_root.mkdir(exist_ok=True)
    stopped = False
    stop_reason = None
    for task in tasks:
        assessment_path = results_root / task['task_id'] / 'assessment.json'
        if assessment_path.exists():
            row = load(assessment_path)
            require(row['task_id'] == task['task_id'], 'existing_assessment_task')
            # Immutable terminal assessment, including a01's real score and
            # a02's known generation timeout. Never relaunch or rewrite it.
            if row.get('status') in NO_FUTURE_SCORE or row.get('numerical_gate_prevented_score'):
                stopped = True
                stop_reason = row.get('reason', row['status'])
        else:
            generation_is_terminal = (ROOT / 'raw' / task['task_id'] / 'terminal.json').exists()
            try:
                row, candidate, raw = terminal_assessment(task)
                if candidate is not None:
                    budget = load(EVALUATION / 'budget.json')
                    if stopped or budget.get('halted') or budget.get('active') is not None:
                        row.update(status='not_scored', evaluation_status='not_scored',
                                   reason=stop_reason or 'numerical budget halted or unresolved score accounting',
                                   numerical_gate_prevented_score=True)
                        stopped = True
                        stop_reason = row['reason']
                    else:
                        row = score_one(task, row, candidate, raw)
                        if row['status'] in NO_FUTURE_SCORE:
                            stopped = True
                            stop_reason = row.get('reason', row['status'])
            except BaseException as exc:
                row = dict(task, schema='independent-ablation-task-assessment-v1', status='integrity_stop',
                           evaluation_status='not_scored', code_admission='unknown', cases=[],
                           scored=False, reason=type(exc).__name__ + ':' + str(exc), retries=0)
                stopped = True
                stop_reason = row['reason']
            if generation_is_terminal:
                write_new(assessment_path, row)
            else:
                # Aggregate-only checkpoint: no result directory, invocation,
                # execution identity or CPU reservation is consumed for pending
                # generation. The future terminal gets exactly its first score.
                row['provisional_checkpoint_only'] = True
        aggregate['results'].append(row)
        aggregate.update(scoring_stopped=stopped, scoring_stop_reason=stop_reason, updated_utc=now())
        replace_json(EVALUATION / 'assessment.json', aggregate)
        print(json.dumps({'task_id': task['task_id'], 'generation_status': row.get('generation_status'),
                          'code_admission': row.get('code_admission'), 'evaluation_status': row.get('evaluation_status'),
                          'scoring_stopped': stopped}), flush=True)
    budget = load(EVALUATION / 'budget.json')
    own = resource.getrusage(resource.RUSAGE_SELF)
    aggregate.update(ended_utc=now(), logical_tasks_accounted=len(aggregate['results']),
                     generation_status_counts=dict(collections.Counter(row.get('generation_status', 'unknown') for row in aggregate['results'])),
                     code_admission_counts=dict(collections.Counter(row.get('code_admission', 'unknown') for row in aggregate['results'])),
                     evaluation_status_counts=dict(collections.Counter(row.get('evaluation_status', 'unknown') for row in aggregate['results'])),
                     actual_numeric_CPU_gate_seconds=budget['completed_cpu_seconds'],
                     numeric_CPU_gate_halted=budget['halted'], unresolved_numeric_job=budget.get('active'),
                     assessment_text_only_controller_cpu_seconds=own.ru_utime + own.ru_stime,
                     text_only_controller_accounting_scope='reported separately; no numeric candidate code executes in this process')
    replace_json(EVALUATION / 'assessment.json', aggregate)
    return 2 if stopped else 0

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--check-only', action='store_true')
    parser.add_argument('--archive-placeholders-only', action='store_true',
                        help='Only move never-scored administrative placeholders; no model-text reads or score launch')
    parser.add_argument('--require-all-terminal', action='store_true',
                        help='Require completed generation or explicit stop before the final assessment')
    args = parser.parse_args()
    if args.check_only:
        self_check()
        return 0
    with (EVALUATION / 'assessment-manager.lock').open('a+b') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        return main_locked(args)

if __name__ == '__main__':
    raise SystemExit(main())
