官方只读核验，2026-10-07

本核验没有发模型请求、读取凭证或安装工具。

1. 国内 Coding Plan 与工具范围
   - https://docs.bigmodel.cn/cn/coding-plan/overview ：所有套餐支持 GLM-5.3、GLM-5.3-Flash；适用工具列出 OpenCode。额度耗尽后等待下一个 5 小时周期，不继续消耗其他资源包或账户余额。
   - https://docs.bigmodel.cn/cn/coding-plan/tool/others ：官方指定工具清单包含 OpenCode；OpenAI Chat Completion 的 Coding Plan Base URL 是 https://open.bigmodel.cn/api/coding/paas/v4 。该页还说明错误端点无法使用套餐额度。
   - https://docs.bigmodel.cn/cn/coding-plan/latest-model ：两模型已面向 Max/Pro/Lite 全量可用，显式模型 ID glm-5.3 / glm-5.3-flash；显式 effort 优先，支持 low/high/max。该页的转换表将 minimal/light/low 转 low、medium/high 转 high、xhigh/max/ultra 转 max。

2. 模型规格与参数
   - https://docs.bigmodel.cn/cn/guide/models/text/glm-5.3 ：文本模型，1M context，128K output；reasoning_effort=low/high/max，默认 max；thinking.type=enabled，思考始终启用。示例明确传 reasoning_effort 与 max_tokens。
   - https://docs.z.ai/guides/vlm/glm-5.3-flash ：官方英文 Flash 模型文档全文核实 1M context、128K output、模型编码 glm-5.3-flash；文本参数与 GLM-5.3 一致，只支持 thinking.type=enabled；默认建议 reasoning_effort=max。中文页面 https://docs.bigmodel.cn/cn/guide/models/vlm/glm-5.3-flash 的官方搜索摘要同样给出 128K、1M 和文本参数与 GLM-5.3 一致，但全文抓取失败（web timeout；环境 fetch 403），因此英文官方全文作为补充证据。
   - 支持低/高/max 不等于证明 CLI 最终请求实际传递这些值；必须另行检查冻结版本的 SDK 映射及本次实际记录。

3. Coding Plan 积分消耗（不是标准 API 按量价格）
   - https://docs.bigmodel.cn/cn/coding-plan/overview ：积分=(输入Token×Input系数+缓存Token×Cached Input系数+输出Token×Output系数)/10000。
   - GLM-5.3 系数为 6.9 / 1.7 / 24；GLM-5.3-Flash 为 2.3 / 0.56 / 8；非高峰消耗50%。页面注明 2026-09-25 至 2026-10-07 全天按非高峰消耗，并有每日23:00至次日09:00其他Agent额度翻倍活动。计费/消耗实测仍应依据账户费用明细；仅用usage推算时标为估计积分，不能声称账户实际扣减或新增人民币支出已观察。

4. OpenCode 1.18.34 官方来源链
   - https://opencode.ai/docs/ ：官方安装文档列出 npm install -g opencode-ai，并链接 GitHub releases。
   - https://opencode.ai/changelog ：2026-09-30 的 v1.18.34 直接链接 https://github.com/anomalyco/opencode/releases/tag/v1.18.34 。2026-10-06 已发布1.18.35，本实验仍应冻结明确指定的1.18.34。
   - https://github.com/anomalyco/opencode/releases/tag/v1.18.34 ：官方不可变release，tag v1.18.34，显示commit aec0b9a 和40个附件。
   - https://registry.npmjs.org/opencode-ai/1.18.34 ：本环境实际只读下载元数据到 npm_opencode_ai_1.18.34.json，2037 B，SHA256 3c7099a0c395a86485739cff41fbdd1fce421d6df53ab18bd074ece058e22f36。所有列出的平台可选包均锁1.18.34。
   - registry tarball=https://registry.npmjs.org/opencode-ai/-/opencode-ai-1.18.34.tgz ，SHA1=d7f954b669f1cacb24637e8e302b2ec4faaef63e，SRI=sha512-9WUS2T0t4HHDVzXvuwTHF0nvhXvZ9mQ0r+ozCvKdJu0LVoQpOzqAW4qWTC3ygNc5Oedcc7j+Oct24JYlQYnySA==。
   - 没有安装、下载binary或比对用户给定binary SHA；该工作由执行负责人完成。

结论：未发现文档层面的模型/档位/指定端点/OpenCode支持障碍。账户余额、套餐当前额度、凭证、工具实际请求映射及二进制SHA不属于本只读文档核验已观察范围。
