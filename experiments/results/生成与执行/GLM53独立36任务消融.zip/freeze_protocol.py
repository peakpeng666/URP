import datetime,hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def canon(x):return json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()
def pin(p):return {'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
assert not list((ROOT/'raw').glob('*/invocation.json')),'No protocol changes after any model result'
assert (ROOT/'source_audit/offline_recorder_test.json').exists(),'Recorder offline test must pass'
assert (ROOT/'evaluation/evaluation_protocol.json').exists(),'Evaluation protocol must exist'
assert (ROOT/'evaluation/ready_only_receipt.json').exists(),'Isolation READY gate must pass'
plan=json.loads((ROOT/'protocol/selection_and_order.json').read_bytes())
protocol={
 'experiment_id':'glm53_effort_ablation_20261007_seed20261007',
 'frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'authorization':'Independent 36 logical generation tasks explicitly authorized by user in parent. No original132 slot, population, source, Library identity or ledger changes. No replacement of failures.',
 'logical_task_count':36,'questions':6,'task_order_file':'protocol/selection_and_order.json',
 'source_drive_file_id':'1vHrzTaZJqHgbzf31nTIBf4BwIab2ymQq','source_zip':pin(ROOT/'inputs/P2.zip'),
 'endpoint':'https://open.bigmodel.cn/api/coding/paas/v4','provider':'zhipuai-coding-plan',
 'executor':'official OpenCode 1.18.34, original binary SHA matched; no alternative executor or direct API loop',
 'models':['glm-5.3','glm-5.3-flash'],'reasoning_efforts':['low','high','max'],
 'max_completion_tokens':64000,'model_limit_output':64000,'process_outputTokenMax':64000,
 'temperature':0.7,'top_p':0.9,'max_cli_steps':2,'tools':False,'client_timeout_seconds':900,
 'outer_retries':0,'cli_starts_per_task_max':1,'parallel_generation':False,'probe_model_requests':0,
 'sdk_recording':'Official plugin hooks replace final system with frozen exact system; check exact user and wire body; install one transparent original SDK fetch wrapper; no headers/auth saved; no independent requests; no retries. Plugin-required invalid URL sentinel fails closed until hook installs approved endpoint.',
 'http_count_policy':'SDK fetch calls are observed and logged; underlying transport/network attempt count remains unknown unless independently observed. 36 logical tasks is not an actual HTTP request count.',
 'cost_policy':'Use existing domestic Coding Plan only. Official token-credit method is known; account actual deductions/RMB charges unobserved and unknown. No switch to standard paid API, recharge or upgrade. Usage-derived credits are estimates only.',
 'evaluation_protocol':'evaluation/evaluation_protocol.json','evaluation_total_cpu_seconds_max':600,
 'stop_policy':'Stop on access/plan/configuration/ambiguous external result or unknown charging route; retain all attempted terminal failures and all unstarted tasks; no reslots or automatic fallback.',
 'claim_limits':'n=6 is screening; no significance or stable-winner claim. Same output cap is not equal realized compute. Public 3x1000 score is not mainline5000 or heldout score.',
 'delivery_drive_folder':'1zs4eHCumbKPNV0ZnI9JWK6JnQHV1569T','delivery_owner_only':True,
}
(ROOT/'protocol/protocol.json').write_bytes(canon(protocol))
files={}
paths=list((ROOT/'protocol').glob('*'))+[ROOT/n for n in ['select_prompts.py','prepare_configs.py','run_ablation.py','freeze_protocol.py','pins/opencode','pins/official_verification.md','pins/registry.json','source_audit/ablation-recorder.mjs','source_audit/offline_recorder_test.json','source_audit/mapping.md','evaluation/evaluation_protocol.json','evaluation/ready_only_receipt.json','evaluation/prepare_local.py','evaluation/ready_only.py','evaluation/evaluate_candidate.py']]
paths+=list((ROOT/'evaluation/runtime').glob('*'))
paths+=list((ROOT/'evaluation').glob('*'))
paths += [ROOT/'source_audit/offline-recorder-test.mjs',ROOT/'source_audit/source-pins.json',ROOT/'source_audit/git-tag-v1.18.34.txt']
paths += [ROOT/'source_audit/offline_cli/result.json']
paths += list((ROOT/'source_audit/offline_cli/config/opencode').rglob('package*.json'))
for p in sorted(set(paths)):
 if p.is_file() and p.name!='FREEZE.json':files[str(p.relative_to(ROOT))]=pin(p)
f={'schema':'independent-ablation-freeze-v1','frozen_utc':protocol['frozen_utc'],'files':files}
(ROOT/'protocol/FREEZE.json').write_bytes(canon(f))
print('FROZEN',pin(ROOT/'protocol/FREEZE.json'),'files',len(files),'model_requests_before_freeze',0)
