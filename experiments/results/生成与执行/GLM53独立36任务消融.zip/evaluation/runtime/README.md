# Independent 20261007 ablation runtime

This copy is separate from all original study sources and ledgers. Original
worker initialization, seccomp rules, AST admission, finite numerical facade,
packing/checker and resource evidence logic are unchanged. This environment's
dependency hashes are frozen separately; glibc and loader hashes differ from the
original environment.

The additional closed ablation profile uses 20 CPU seconds for the numerical
worker and 20 for the trusted supervisor, one shared 30-second wall deadline
including startup and 2-second cleanup, and 512 MiB address space per process.
Only the frozen public case IDs 0, 1 and 2, each first 1000 items, are dispatched.
Admission is separately bounded at 1 CPU second and 5 total wall seconds.

The whole evaluation CPU gate is 600 seconds, including controller self CPU and
Linux wait4 inclusive descendant CPU. Each case reserves 40 CPU seconds before
dispatch; unknown cleanup or resource accounting halts scoring. This is not an
aggregate RSS cgroup, namespace or VM sandbox. Source is sent only after the
original host-observed seccomp, private FD, resource and mapped-dependency gates.
