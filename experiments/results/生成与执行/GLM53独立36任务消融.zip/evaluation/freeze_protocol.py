"""Freeze public prefixes and offline evaluator before seeing model results."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'runtime'))
from checker import instance_identity
from resource_profile import ABLATION_PROFILE_ID, profile_sha256, profile_document
from policy import policy_sha256

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, value):
    with path.open('x') as handle:
        json.dump(value, handle, sort_keys=True, indent=2, allow_nan=False)
        handle.write('\n')

def main():
    source = ROOT.parent / 'inputs/P2/URP/experiments/online_bin_packing/paper_scale_dag_evaluator_v1/data/design_5000.json'
    assert source.stat().st_size == 300758
    assert sha(source) == '5358c41aa758e1d399d29157f8cbdc5fb422f4c8acd56b2cb95c41af3f1750ca'
    data = json.loads(source.read_bytes())
    assert data['capacity'] == 100 and len(data['cases']) == 5
    cases = []
    for case in sorted(data['cases'], key=lambda value: value['id'])[:3]:
        assert len(case['items']) == 5000
        items = case['items'][:1000]
        assert all(type(item) is int and 1 <= item <= 100 for item in items)
        cases.append({'id': case['id'], 'items': items, 'n': 1000,
                      'L1': (sum(items) + 99) // 100,
                      'original_5000_array_sha256': case['array_sha256'],
                      'input_sha256': instance_identity(items, 100)})
    assert [case['id'] for case in cases] == [0, 1, 2]
    panel_path = ROOT / 'public_design_prefixes.json'
    write(panel_path, {'schema': 'independent-public-design-prefixes-v1', 'capacity': 100,
                      'source_file_sha256': sha(source), 'selection': 'case ID ascending first3; each exact first1000',
                      'cases': cases})
    ready = json.loads((ROOT / 'ready_only_receipt.json').read_text())
    assert ready['status'] == 'passed' and ready['source_frames'] == 0
    original = json.loads((ROOT / 'original_runtime_pins.json').read_text())
    security_sources = ('worker.py', 'admission.py', 'facade.py', 'manifest.py',
                        'api_manifest.json', 'policy.py', 'checker.py', 'runner.py',
                        'instance_supervisor.py', 'supervised_runner.py', 'supervisor_transport.py', 'protocol.py')
    assert all(sha(ROOT / 'runtime' / name) == original['files'][name] for name in security_sources)
    runtime_path = ROOT / 'runtime/worker_freeze.json'
    runtime = json.loads(runtime_path.read_text())
    prep = json.loads((ROOT / 'runtime/pre_run_freeze.json').read_text())
    offline_cpu = prep['prep_cpu_seconds'] + ready['whole_process_tree_cpu_seconds']
    evaluator_files = {name: sha(ROOT / name) for name in ('evaluate_candidate.py', 'prepare_local.py', 'ready_only.py', 'freeze_protocol.py')}
    protocol = {
        'schema': 'independent-ablation-evaluation-protocol-v1',
        'status': 'FROZEN_READY_ONLY_PASSED',
        'frozen_utc': datetime.now(timezone.utc).isoformat(),
        'candidate_executions_before_freeze': 0, 'model_results_seen_before_freeze': 0,
        'independent_of_original132': True, 'heldout_access': False,
        'public_design_source': {'path': str(source), 'bytes': source.stat().st_size, 'sha256': sha(source)},
        'public_panel_sha256': sha(panel_path), 'public_panel_bytes': panel_path.stat().st_size,
        'selection': 'original public case IDs sorted ascending; select0,1,2 and exact first1000 items each; fixed before outputs',
        'cases': [{k: v for k, v in case.items() if k != 'items'} for case in cases],
        'runtime_freeze_sha256': sha(runtime_path), 'original_runtime_freeze_sha256': original['worker_freeze_sha256'],
        'runtime_python': runtime['python'], 'runtime_numpy': runtime['numpy_version'],
        'separate_current_environment_dependency_pins': True,
        'known_environment_difference': ['glibc and dynamic loader hashes differ from original accepted environment'],
        'preserved_security_source_sha256': {name: original['files'][name] for name in security_sources},
        'numerical_policy_sha256': policy_sha256(),
        'resource_profile_sha256': profile_sha256(ABLATION_PROFILE_ID),
        'resource_profile': profile_document(ABLATION_PROFILE_ID),
        'evaluation_execution_order': 'generation logical task order; three public cases ascending for every admitted candidate',
        'admission': 'Original AST/interface checker parses and compiles exact bytes only inside verified restricted worker;1CPU/5wall; no host AST parsing',
        'candidate_execution': 'original Session and supervised_pack; seccomp denies open/socket/clone/exec; cleared environment/private pipes; future items stay in trusted supervisor',
        'per_case': {'numerical_child_cpu_seconds': 20, 'trusted_supervisor_cpu_seconds': 20,
                     'shared_wall_seconds': 30, 'cleanup_inside_wall_seconds': 2,
                     'address_space_bytes_per_process': 536870912, 'fresh_worker_per_case': True},
        'budget': {'total_actual_cpu_seconds': 600, 'scope': 'prep plus READY plus every scoring controller self and Linux inclusive descendant CPU',
                   'offline_preparation_and_ready_cpu_seconds': offline_cpu,
                   'reservation_per_case_cpu_seconds': 40,
                   'controller_hard_cpu_seconds_per_candidate': 25,
                   'controller_reservation_cpu_seconds': 30,
                   'controller_margin_cpu_seconds': 5,
                   'admission_reservation_cpu_seconds': 1,
                   'gate': 'before each spawn prior completedCPU + current inclusive descendantCPU +30 controller reservation + next child cap <=600',
                   'settlement': 'actual controller self + rusage_children inclusive trees; do not add worker CPU again to supervisor-inclusive wait4 CPU',
                   'unknown_accounting_or_cleanup': 'stop; active unresolved job also stops; no retry'},
        'case_failure_policy': 'typed numeric/cap failure is retained and next fixed case runs; unknown isolation/integrity/cleanup stops; no repairs or replacement',
        'full_panel_metric': 'Only three complete checker-passed cases: maximize mean L1_i/used_bins_i with exact rational comparison',
        'report_metric': '100*(sum used_bins-sum L1)/sum L1; same prefix panel only',
        'failed_or_incomplete_panel_metric': None,
        'cache_or_baseline_insertion': False,
        'source_execution_only_for_scoring': True,
        'isolation_limits': 'shared kernel/native runtime; no namespace/VM/cgroup or aggregate RSS isolation; AST/facade alone not a sandbox',
        'no_security_boundary_relaxation': True,
        'ready_only_receipt_sha256': sha(ROOT / 'ready_only_receipt.json'),
        'evaluator_files': evaluator_files,
    }
    write(ROOT / 'evaluation_protocol.json', protocol)
    write(ROOT / 'budget.json', {'schema': 'independent-ablation-total-CPU-gate-v1',
                                'completed_cpu_seconds': offline_cpu, 'completed_tasks': [],
                                'active': None, 'halted': False, 'halt_reason': None,
                                'evaluation_protocol_sha256': sha(ROOT / 'evaluation_protocol.json')})
    print(json.dumps({'status': protocol['status'], 'evaluation_protocol_sha256': sha(ROOT / 'evaluation_protocol.json'),
                      'runtime_freeze_sha256': sha(runtime_path), 'public_panel_sha256': sha(panel_path),
                      'public_case_ids': [case['id'] for case in cases], 'offline_cpu_seconds': offline_cpu}))

if __name__ == '__main__':
    main()
