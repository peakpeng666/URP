def score(item, bins):
    r = (bins - item) * 1.0
    a = (r - 0.5) / 45.0
    b = (r + 0.5) / 45.0
    p1 = np.exp(-(a * a * a)) - np.exp(-(b * b * b))
    d = (r - 80.37) / 20.65
    p2 = 0.01932 * np.exp(-0.5 * d * d)
    s = p1 + p2 - 0.000002 * r
    return np.where(r == 0.0, s + 1.0, s)
