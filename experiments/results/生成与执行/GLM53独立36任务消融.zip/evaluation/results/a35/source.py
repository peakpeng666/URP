def score(item, bins):
    r = bins - item
    u = (r - 39.5) / 7.0
    v = (r - 78.5) / 10.0
    live = 9.4 - 3.3 * np.exp(-u * u) - 2.7 * np.exp(-v * v)
    phi = np.minimum(r + 1.0, live)
    phi = np.maximum(phi, 0.0)
    return -phi - 0.011 * r
