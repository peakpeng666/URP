def score(item, bins):
    r = bins - item
    s = -((r - 40) * (r - 40)) / 900.0
    s = s - 25.0 * ((r >= 1) & (r <= 24))
    s = np.where(r == 0, s + 100.0, s)
    s = np.where(bins < 100, s + 10.0, s)
    return s
