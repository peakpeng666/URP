def score(item, bins):
    r = bins - item
    s = -1.0 * r
    s = s + np.where(r == 0, 100.0, 0.0)
    s = s + np.where((r >= 25) & (r <= 55), 12.0, 0.0)
    s = s + np.where((r >= 1) & (r < 25), -15.0, 0.0)
    s = s + np.where(r > 55, -0.01 * (r - 55), 0.0)
    return s
