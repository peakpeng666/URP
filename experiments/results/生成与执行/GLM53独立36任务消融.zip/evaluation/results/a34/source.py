def score(item, bins):
    r = bins - item
    t = r / 45.0
    dens = (3.0 / 45.0) * t * t * np.exp(0.0 - t * t * t)
    recover = 10.0 * r * dens
    used = bins < 100
    exact = r == 0
    s = np.where(used, 1000.0, 0.0) + np.where(exact, 100.0, 0.0) + recover - 0.001 * r
    return s
