def score(item, bins):
    r = bins - item
    v = np.arange(0, 101)
    c = (v - 0.5) / 45.0
    d = (v + 0.5) / 45.0
    p = np.exp(0.0 - c * c * c) - np.exp(0.0 - d * d * d)
    p1 = p[np.clip(r, 0, 100)]
    p2 = r * 0.0
    for a in range(1, 91):
        j = r - a
        pj = p[np.clip(j, 1, 100)]
        p2 = p2 + np.where(j >= 1, pj * p[a], 0.0)
    used = np.where(bins < 100, 0.5, 0.0)
    tight = -0.00001 * (r * r)
    s = p1 + p2 + used + tight
    return np.where(r == 0, 1.0 + used, s)
