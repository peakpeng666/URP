def score(item, bins):
    r = bins - item
    u = r / 45.0
    fill = -np.expm1(-u * u * u)
    sweet = np.exp(-0.5 * np.square((r - 39.5) / 11.0))
    dead = np.exp(-0.5 * np.square((r - 16.0) / 5.5))
    exact = np.where(r == 0, 90.0, 0.0)
    return exact - r + 26.0 * sweet - 26.0 * dead + 6.0 * fill
