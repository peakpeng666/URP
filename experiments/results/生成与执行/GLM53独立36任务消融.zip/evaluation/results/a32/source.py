def score(item, bins):
    r = (bins - item).astype(np.float64)
    base = (item - bins).astype(np.float64)
    u = (r - 40.0) / 7.5
    v = (r - 80.0) / 9.0
    kernel = 10.5 * np.exp(-u * u) + 6.0 * np.exp(-v * v)
    dead = np.where((r >= 1.0) & (r <= 30.0), -1.2 * (31.0 - r), 0.0)
    perfect = np.where(r == 0.0, 50.0, 0.0)
    used = np.where(bins < 100, 1.5, 0.0)
    return base + kernel + dead + perfect + used
