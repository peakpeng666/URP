def score(item, bins):
    r = bins - item
    return -r + 31 * np.exp(-np.square(r - 41) / 300)
