def score(item, bins):
    r = bins - item
    base = item - bins
    dead = np.where((r >= 1) & (r <= 24), -22.0, 0.0)
    sweet = np.where((r >= 33) & (r <= 62), 9.0, 0.0)
    perfect = np.where(r == 0, 40.0, 0.0)
    fresh = np.where(bins == 100, -3.0, 0.0)
    return base + dead + sweet + perfect + fresh
