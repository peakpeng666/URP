def score(item, bins):
    r = (bins - item) * 1.0
    c = bins * 1.0
    u = (r - 40.0) / 8.5
    v = (r - 79.0) / 9.5
    live = 9.3 - 3.0 * np.exp(-u * u) - 2.0 * np.exp(-v * v)
    tail = 0.045 * np.maximum(r - 88.0, 0.0)
    phi = np.minimum(r + 1.0, live) + tail
    a = (c - 40.0) / 8.5
    b = (c - 79.0) / 9.5
    livec = 9.3 - 3.0 * np.exp(-a * a) - 2.0 * np.exp(-b * b)
    tailc = 0.045 * np.maximum(c - 88.0, 0.0)
    phic = np.minimum(c + 1.0, livec) + tailc
    base = np.where(c < 99.5, phic, 0.0)
    return base - phi - 0.012 * r
