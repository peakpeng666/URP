def score(item, bins):
    r = bins - item
    u = (r - 40.0) / 9.0
    v = (r - 80.0) / 12.0
    live = 9.6 - 3.8 * np.exp(-u * u) - 2.7 * np.exp(-v * v)
    phi = np.minimum(r + 0.6, live)
    phi = np.maximum(phi, 0.0)
    return -phi - 0.015 * r
