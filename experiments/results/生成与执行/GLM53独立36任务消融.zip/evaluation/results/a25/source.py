def score(item, bins):
    r = bins - item
    return -r + 31.0 * np.exp(-np.square(r - 41.0) / 300.0)
