def score(item, bins):
    r = (bins - item).astype(np.float64)
    base = np.negative(r)
    closeness = np.reciprocal(r + 1.0) * 50.0
    bump = np.maximum(25.0 - 0.5 * np.abs(r - 45.0), 0.0)
    dead = np.where(r <= 24.0, np.where(r >= 1.0, -20.0, 0.0), 0.0)
    return base + closeness + bump + dead
