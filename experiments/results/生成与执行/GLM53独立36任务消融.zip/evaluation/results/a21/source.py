def score(item, bins):
    r = (bins - item) * 1.0
    tight = np.log1p(100.0 / (r + 1.0))
    z = (r - 40.0) / 18.0
    bump = 1.5 * np.exp(0.0 - z * z)
    s = tight + bump
    s = np.where(bins < 100, s + 0.4, s)
    s = np.where(r == 0.0, s + 7.0, s)
    return s
