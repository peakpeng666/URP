def score(item, bins):
    r = bins - item
    rf = r * 1.0
    base = -rf
    near = 50.0 * np.exp(-(rf * rf) / 64.0)
    dead = -34.0 * np.clip((30.0 - rf) / 30.0, 0.0, 1.0)
    ramp = 20.0 * np.clip((rf - 28.0) / 14.0, 0.0, 1.0)
    return base + near + dead + ramp
