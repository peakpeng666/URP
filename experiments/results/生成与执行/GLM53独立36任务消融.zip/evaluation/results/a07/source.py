def score(item, bins):
    r = bins - item + 0.0
    h = (r - 22.0) / 9.0
    live = 5.6 + 8.8 * np.exp(-h * h)
    a = (r - 40.0) / 9.0
    live = live - 4.4 * np.exp(-a * a)
    b = (r - 58.0) / 8.0
    live = live - 1.1 * np.exp(-b * b)
    d = (r - 78.0) / 8.5
    live = live - 3.1 * np.exp(-d * d)
    phi = np.minimum(r + 0.7, live)
    phi = np.maximum(phi, 0.0)
    return -phi - 0.01 * r
