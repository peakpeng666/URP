def score(item, bins):
    return item - bins + 31.0 * np.exp(-np.square(bins - item - 41) / 300.0)
