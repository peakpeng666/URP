def score(item, bins):
    r = bins - item
    u = (r - 40.0) / 13.0
    v = (r - 80.0) / 12.0
    disc = 38.0 * np.exp(-u * u) + 18.0 * np.exp(-v * v)
    bonus = np.where(r == 0, 50.0, 0.0)
    return bonus - r + disc
