def score(item, bins):
    r = (bins - item) * 1.0
    exact = np.where(r == 0.0, 60.0, 0.0)
    u = (r - 42.0) / 9.0
    v = (r - 84.0) / 10.0
    live = 3.4 * np.exp(-u * u) + 2.6 * np.exp(-v * v)
    dead = -2.2 * np.exp(-np.square((r - 20.0) / 9.0))
    return -r + exact + live + dead
