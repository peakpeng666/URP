def score(item, bins):
    r = bins - item
    c1 = (r - 0.5) / 45.0
    c2 = (r + 0.5) / 45.0
    p1 = np.exp(-(c1 * c1 * c1)) - np.exp(-(c2 * c2 * c2))
    d = r - 80.4
    p2 = 0.0171 * np.exp(-(d * d) / 853.0)
    fill = p1 + p2
    eff = r * (1.0 - 26.0 * fill)
    s = -eff
    s = np.where(bins < 100, s + 2.0, s)
    s = np.where(r == 0, 1000.0, s)
    return s
