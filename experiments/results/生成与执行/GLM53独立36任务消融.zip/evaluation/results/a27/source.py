def score(item, bins):
    r = bins - item
    fit = -1.0 * r
    exact = np.where(r == 0, 150.0, 0.0)
    pos = np.where(r >= 1, 1.0, 0.0)
    near = 5.0 * np.clip((10.0 - r) / 10.0, 0.0, 1.0) * pos
    t = np.clip((r - 10) / 14.0, 0.0, 1.0)
    valley = -6.0 * (1.0 - t) * pos
    sweet = 10.0 * np.exp(-((r - 39.0) * (r - 39.0)) / 169.0)
    tail = -6.0 * np.clip((r - 62) / 38.0, 0.0, 1.0)
    if item <= 20:
        s = fit + exact + 15.0 * np.exp(-1.0 * (r * r) / 64.0)
    elif item >= 55:
        s = fit + exact
    else:
        s = fit + exact + near + valley + sweet + tail
    return s
