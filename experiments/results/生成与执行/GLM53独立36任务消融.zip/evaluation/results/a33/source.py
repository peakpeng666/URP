def score(item, bins):
    r = bins - item
    u = (r - 40.0) / 7.5
    v = (r - 80.0) / 12.5
    live = 9.6 - 3.5 * np.exp(-u * u) - 2.1 * np.exp(-v * v)
    phi = np.minimum(r + 1.0, live)
    phi = np.maximum(phi, 0.0)
    return -phi - 0.008 * r
