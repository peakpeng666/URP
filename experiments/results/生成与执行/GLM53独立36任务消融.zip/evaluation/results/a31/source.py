def score(item, bins):
    r = bins - item
    a = (r - 0.5) / 45.0
    e1 = np.exp(-a * a * a)
    b = (r + 0.5) / 45.0
    e2 = np.exp(-b * b * b)
    p1 = e1 - e2
    fit = 1.0 - e2
    d = (r - 80.4) / 29.2
    p2 = 0.0193 * np.exp(-d * d)
    s = 60.0 * p1 + 60.0 * p2 + 0.35 * fit - 0.03 * r - 0.05 * r * e2
    s = s + np.where(bins < 100, 0.3, 0.0)
    s = s + np.where(r == 0, 30.0, 0.0)
    return s
