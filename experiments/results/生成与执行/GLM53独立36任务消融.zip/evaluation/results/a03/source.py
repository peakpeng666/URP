def score(item, bins):
    r = (bins - item) * 1.0
    lo = (r - 0.5) / 45.0
    hi = (r + 0.5) / 45.0
    plo = np.exp(0.0 - lo * lo * lo)
    phi = np.exp(0.0 - hi * hi * hi)
    p = plo - phi
    s = -r + 40.0 * p - 0.001 * r
    s = np.where(r == 0.0, s + 5.0, s)
    return s
