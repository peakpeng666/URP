def score(item, bins):
    r = (bins - item) * 1.0
    t = (r - 0.5) / 45.0
    u = (r + 0.5) / 45.0
    p = np.exp(-t * t * t) - np.exp(-u * u * u)
    w = (r - 80.0) / 11.0
    psi = 7.0 - 120.0 * p - 0.8 * np.exp(-w * w)
    phi = np.minimum(r + 1.0, psi)
    return -phi - 0.01 * r
