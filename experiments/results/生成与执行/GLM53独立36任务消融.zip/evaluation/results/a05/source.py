def score(item, bins):
    r = bins - item
    lo = (r - 0.5) / 45.0
    hi = (r + 0.5) / 45.0
    one = np.exp(-(lo * lo * lo)) - np.exp(-(hi * hi * hi))
    d2 = (r - 80.368) / 20.653
    two = 0.0193174 * np.exp(-0.5 * d2 * d2)
    d3 = (r - 120.552) / 25.289
    three = 0.0094652 * np.exp(-0.5 * d3 * d3)
    s = one + two + three
    s = s + np.where(bins < 100, 0.002, 0.0)
    s = s - 0.000003 * r
    s = np.where(r == 0, 10.0, s)
    return s
