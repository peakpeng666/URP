def score(item, bins):
    r = (bins - item) * 1.0
    exact = np.where(r == 0.0, 46.0, 0.0)
    m1 = 24.0 * np.exp(-np.square(r - 39.5) / 81.0)
    m2 = 8.0 * np.exp(-np.square(r - 80.5) / 144.0)
    near = 2.2 * np.exp(-np.square(r) / 6.76)
    dead = -5.0 * np.exp(-np.square(r - 14.0) / 64.0)
    return exact + m1 + m2 + near + dead - 0.13 * r
