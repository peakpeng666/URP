def score(item, bins):
    r = bins - item
    waste_new = r * np.exp(-(r * r * r) / 2025.0)
    waste_old = bins * np.exp(-(bins * bins * bins) / 2025.0)
    perfect = np.where(r == 0, 100.0, 0.0)
    return waste_old - waste_new - 0.02 * r + perfect
