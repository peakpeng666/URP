def score(item, bins):
    r = bins - item
    return -r + 31.0 * np.exp(-(r - 41) ** 2 / 300.0)
