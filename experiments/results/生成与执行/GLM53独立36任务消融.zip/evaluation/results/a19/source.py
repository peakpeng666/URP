def score(item, bins):
    r = (bins - item) * 1.0
    a = (r - 0.5) / 45.0
    b = (r + 0.5) / 45.0
    pmf = np.exp(-a * a * a) - np.exp(-b * b * b)
    u = (r - 40.0) / 8.0
    v = (r - 80.0) / 11.0
    live = 9.2 - 3.2 * np.exp(-u * u) - 2.4 * np.exp(-v * v)
    cap = np.minimum(r + 1.0, live)
    s = -cap - 0.012 * r + 55.0 * pmf
    return np.where(r == 0.0, s + 31.0, s)
