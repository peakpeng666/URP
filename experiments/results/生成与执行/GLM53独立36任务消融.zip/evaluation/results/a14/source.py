def score(item, bins):
    r = bins - item
    u = (r - 38.0) / 7.0
    v = (r - 79.0) / 12.0
    live = 9.5 - 3.6 * np.exp(-u * u) - 2.1 * np.exp(-v * v)
    phi = np.minimum(r + 1.0, live)
    phi = np.maximum(phi, 0.0)
    return -phi - 0.018 * r
