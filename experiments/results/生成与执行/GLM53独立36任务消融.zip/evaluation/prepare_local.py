"""Freeze this independent environment; never parse or execute candidate source."""
import hashlib
import json
import os
from pathlib import Path
import resource
import sys
import time

START = time.monotonic()
ROOT = Path(__file__).resolve().parent / 'runtime'
sys.path.insert(0, str(ROOT))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    assert resource.getrlimit(resource.RLIMIT_CPU) == (3, 3)
    assert resource.getrlimit(resource.RLIMIT_AS) == (536870912, 536870912)
    assert not (ROOT / 'worker_freeze.json').exists()
    import worker
    import runner
    import instance_supervisor
    import supervised_runner
    import numpy as np
    import numpy.ma
    from dependencies import inventory
    from policy import policy_sha256
    worker.preload_library()
    original = json.loads((ROOT.parent / 'original_runtime_pins.json').read_text())
    changed = {'resource_profile.py', 'deployment.py', 'ISOLATION.json', 'README.md'}
    for name, expected in original['files'].items():
        if name not in changed:
            assert sha(ROOT / name) == expected, name
    files = {name: sha(ROOT / name) for name in original['files']}
    dependencies = inventory()
    for path in Path(np.__file__).resolve().parent.rglob('*'):
        if path.is_file() and path.suffix in ('.py', '.pyc', '.so'):
            dependencies[str(path.resolve())] = sha(path)
    fixtures = json.loads((ROOT / 'handwritten_fixtures.json').read_text())
    value = {
        'identity': 'independent-ablation-runtime-20261007-v1',
        'python': sys.version, 'numpy_version': np.__version__,
        'files': files, 'dependencies': dependencies,
        'policy_sha256': policy_sha256(),
        'original_runtime_pins_sha256': sha(ROOT.parent / 'original_runtime_pins.json'),
        'preserved_security_boundary': 'worker.initialize, seccomp rules, AST, finite facade, numerical policy, checker unchanged',
        'handwritten_test_source_hashes': [v['source_sha256'] for v in fixtures.values()],
        'compile': {'mode': 'exec', 'flags': 0, 'dont_inherit': True, 'optimize': 0, 'same_accepted_ast': True},
    }
    with (ROOT / 'source_freeze.json').open('x') as handle:
        json.dump({'files': files}, handle, sort_keys=True, indent=2)
        handle.write('\n')
    with (ROOT / 'worker_freeze.json').open('x') as handle:
        json.dump(value, handle, sort_keys=True, indent=2)
        handle.write('\n')
    own = resource.getrusage(resource.RUSAGE_SELF)
    value = dict(value, worker_freeze_sha256=sha(ROOT / 'worker_freeze.json'),
                 prep_cpu_seconds=own.ru_utime + own.ru_stime,
                 prep_wall_seconds=time.monotonic() - START)
    with (ROOT / 'pre_run_freeze.json').open('x') as handle:
        json.dump(value, handle, sort_keys=True, indent=2)
        handle.write('\n')
    print(json.dumps({'status': 'prepared', 'cpu_seconds': value['prep_cpu_seconds'],
                      'wall_seconds': value['prep_wall_seconds'],
                      'runtime_freeze_sha256': value['worker_freeze_sha256']}))

if __name__ == '__main__':
    main()
