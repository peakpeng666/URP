"""Observe the original worker gate, then EOF; no source frame is sent."""
import hashlib
import json
from pathlib import Path
import resource
import sys
import time

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'runtime'))
from runner import Session
from resource_profile import ABLATION_PROFILE_ID, profile_sha256
from test_support import binding

def main():
    assert resource.getrlimit(resource.RLIMIT_CPU) == (30, 30)
    start = time.monotonic()
    candidate, bind = binding('finite')
    bind['resource_profile_sha256'] = profile_sha256(ABLATION_PROFILE_ID)
    worker = None
    try:
        worker = Session(candidate, bind, worker_role='instance',
                         execution_id='ablation-ready-only', defer_source=True)
        assert worker.source_sent is False
        worker.close()
        evidence = worker.evidence()
        assert evidence['source_sent'] is False and evidence['steps'] == 0
        assert evidence['reaped'] and evidence['returncode'] == 0
        assert evidence['cleanup_error'] is None
        value = {'status': 'passed', 'source_frames': 0,
                 'candidate_AST_parses': 0, 'candidate_compilations': 0,
                 'candidate_invocations': 0, 'evidence': evidence}
    except BaseException as exc:
        if worker is not None and not worker.reaped:
            exc = worker._preserve_failure(exc, kill=True)
        value = {'status': 'failed', 'error': type(exc).__name__ + ': ' + str(exc),
                 'evidence': getattr(exc, 'worker_evidence', None)}
    own = resource.getrusage(resource.RUSAGE_SELF)
    descendants = resource.getrusage(resource.RUSAGE_CHILDREN)
    value['whole_process_tree_cpu_seconds'] = own.ru_utime + own.ru_stime + descendants.ru_utime + descendants.ru_stime
    value['whole_process_tree_wall_seconds'] = time.monotonic() - start
    with (ROOT / 'ready_only_receipt.json').open('x') as handle:
        json.dump(value, handle, sort_keys=True, indent=2)
        handle.write('\n')
    print(json.dumps({'status': value['status'], 'source_frames': 0,
                      'whole_process_tree_cpu_seconds': value['whole_process_tree_cpu_seconds'],
                      'error': value.get('error')}))
    return 0 if value['status'] == 'passed' else 1

if __name__ == '__main__':
    raise SystemExit(main())
