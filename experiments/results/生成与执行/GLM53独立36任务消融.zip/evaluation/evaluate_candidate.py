"""One independently journaled candidate; generated source is never parsed here.

Usage: python -I -B evaluate_candidate.py --task-id TASK --source-path PATH
Runs only the original restricted child and trusted supervised_pack interface.
"""
import argparse
import copy
import fcntl
from fractions import Fraction
import hashlib
import json
import math
import os
from pathlib import Path
import re
import resource
import sys
import time

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent
sys.path.insert(0, str(ROOT / 'runtime'))
from checker import check_assignment, check_instance
from dependencies import load_worker_freeze, verify_files
from registry import ExecutionJournal, FrozenRegistry, digest, freeze_wave, seal, sha
from resource_profile import ABLATION_PROFILE_ID, profile_sha256
from runner import ResourceLimitFailure, Session
from supervised_runner import supervised_pack

ID = re.compile(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,100}\Z', re.ASCII)
CONTROLLER_CPU_CAP = 25
CONTROLLER_RESERVATION = 30  # Includes 5 CPU seconds for hard-cap quantization/cleanup margin.
CASE_RESERVATION = 40        # Supervisor20 + numerical child20, no double-counting on settlement.
TOTAL_CPU_GATE = 600

def write_json(path, value):
    raw = (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()
    with path.open('xb') as handle:
        handle.write(raw)
        handle.flush()
        os.fsync(handle.fileno())

def replace_json(path, value):
    tmp = path.with_suffix(path.suffix + '.tmp')
    raw = (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()
    with tmp.open('wb') as handle:
        handle.write(raw)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(tmp, path)

def cpu_usage():
    own = resource.getrusage(resource.RUSAGE_SELF)
    children = resource.getrusage(resource.RUSAGE_CHILDREN)
    return {'controller_self_cpu_seconds': own.ru_utime + own.ru_stime,
            'inclusive_descendant_cpu_seconds': children.ru_utime + children.ru_stime,
            'whole_process_tree_cpu_seconds': own.ru_utime + own.ru_stime + children.ru_utime + children.ru_stime}

def bounded_read(path, cap):
    resolved = path.resolve(strict=True)
    if not resolved.is_relative_to(BASE):
        raise ValueError('input path must be inside this independent experiment')
    with resolved.open('rb') as handle:
        value = handle.read(cap + 1)
    if not 0 < len(value) <= cap:
        raise ValueError('input byte cap')
    return value

def run(args):
    if not ID.fullmatch(args.task_id):
        raise ValueError('task identity')
    # A fixed controller hard cap bounds its remaining CPU reservation and still
    # permits the existing 20CPU supervisor/child to install their own caps.
    inherited = resource.getrlimit(resource.RLIMIT_CPU)[1]
    if inherited != resource.RLIM_INFINITY and inherited < CONTROLLER_CPU_CAP:
        raise ValueError('controller inherited CPU ceiling too low')
    resource.setrlimit(resource.RLIMIT_CPU, (CONTROLLER_CPU_CAP, CONTROLLER_CPU_CAP))
    resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    start = time.monotonic()
    protocol_path = ROOT / 'evaluation_protocol.json'
    protocol_raw = protocol_path.read_bytes()
    protocol = json.loads(protocol_raw)
    if protocol['status'] != 'FROZEN_READY_ONLY_PASSED':
        raise ValueError('evaluation protocol not frozen ready')
    for name, expected in protocol['evaluator_files'].items():
        if sha((ROOT / name).read_bytes()) != expected:
            raise ValueError('frozen evaluator source changed: ' + name)
    runtime, runtime_sha = load_worker_freeze()
    if runtime_sha != protocol['runtime_freeze_sha256']:
        raise ValueError('runtime pin changed')
    verify_files({str(ROOT / 'runtime' / name): expected for name, expected in runtime['files'].items()})
    verify_files(runtime['dependencies'])
    panel_raw = (ROOT / 'public_design_prefixes.json').read_bytes()
    if sha(panel_raw) != protocol['public_panel_sha256']:
        raise ValueError('panel pin changed')
    panel = json.loads(panel_raw)
    if len(panel['cases']) != 3 or [c['id'] for c in panel['cases']] != [0, 1, 2]:
        raise ValueError('panel case identity')
    output_root = ROOT / 'results'
    output_root.mkdir(exist_ok=True)
    output = output_root / args.task_id
    output.mkdir(exist_ok=False)  # Consumed identity; no automatic retry after any result or crash.
    journal = ExecutionJournal(output / 'journal')
    receipt = {'schema': 'independent-ablation-candidate-score-v1',
               'task_id': args.task_id, 'evaluation_protocol_sha256': sha(protocol_raw),
               'runtime_freeze_sha256': runtime_sha,
               'resource_profile_sha256': profile_sha256(ABLATION_PROFILE_ID),
               'public_panel_sha256': sha(panel_raw), 'source_rewritten': False,
               'admission': None, 'cases': [], 'status': 'started',
               'metric_scope': '3 public design sequences first1000 each; no mainline score or heldout'}
    lock_path = ROOT / 'budget.lock'
    with lock_path.open('a+b') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        budget_path = ROOT / 'budget.json'
        budget = json.loads(budget_path.read_text())
        if budget['halted'] or budget.get('active') is not None:
            receipt.update(status='budget_or_unknown_accounting_stop',
                           reason='previous halted or unresolved evaluation identity', cpu=cpu_usage())
            write_json(output / 'receipt.json', receipt)
            print(json.dumps({'task_id': args.task_id, 'status': receipt['status']}))
            return 2
        prior = budget['completed_cpu_seconds']
        budget['active'] = {'task_id': args.task_id, 'controller_reserved_cpu': CONTROLLER_RESERVATION,
                            'pending_child_reserved_cpu': 0, 'source_path': str(args.source_path)}
        replace_json(budget_path, budget)
        halted = False

        def reserve(child_cpu, stage):
            measured = cpu_usage()
            ceiling = prior + measured['inclusive_descendant_cpu_seconds'] + CONTROLLER_RESERVATION + child_cpu
            if not math.isfinite(ceiling) or ceiling > TOTAL_CPU_GATE:
                raise BudgetStop(stage + ': insufficient CPU reservation before spawn')
            budget['active'].update(stage=stage, pending_child_reserved_cpu=child_cpu,
                                    observed_descendant_cpu=measured['inclusive_descendant_cpu_seconds'],
                                    committed_ceiling_cpu_seconds=ceiling)
            replace_json(budget_path, budget)

        worker = None
        try:
            source = bounded_read(args.source_path, 16384)
            code = source.decode('utf-8', errors='strict')
            (output / 'source.py').write_bytes(source)
            if args.raw_response_path is None:
                raw = source
                receipt['raw_capture_binding'] = 'exact_source_only; full generation capture retained by generation recorder'
            else:
                raw = bounded_read(args.raw_response_path, 262144)
                receipt['raw_capture_binding'] = 'exact_supplied_response_bytes'
            description = 'Independent ablation source ' + args.task_id
            candidate = {'description': description, 'code': code,
                         'description_sha256': sha(description.encode()), 'code_sha256': sha(source),
                         'pair_sha256': digest({'description': description, 'code': code}),
                         'description_consistency': 'not_evaluated'}
            claim = seal({'schema': 'wave-external-claim-v1',
                          'run_id': 'independent-ablation-20261007', 'slot_id': args.task_id,
                          'claim_id': digest(['wave-claim-v1', 'independent-ablation-20261007', args.task_id]),
                          'phase': 0, 'request_sha256': sha(source), 'freeze_sha256': sha(protocol_raw)})
            registry_doc = freeze_wave(output / 'registry.json', batch_id=claim['run_id'],
                                      wave_id='public-prefix-score', phase=0,
                                      runtime_freeze_sha256=runtime_sha,
                                      resource_profile_sha256=profile_sha256(ABLATION_PROFILE_ID),
                                      slots=[(candidate, claim, raw)], source_origin='model_response')
            registry = FrozenRegistry(output / 'registry.json', registry_doc['sha256'])
            binding = registry.match(candidate, claim, raw)
            receipt.update(source_sha256=sha(source), source_bytes=len(source), registry_binding=binding)
            token = journal.reserve(binding, claim['claim_id'] + '/admission')
            reserve(1, 'admission')
            try:
                worker = Session(candidate, binding, worker_role='admission',
                                 execution_id=claim['claim_id'] + '/admission')
                admitted = copy.deepcopy(worker.admission)
                worker.close()
                evidence = worker.evidence()
                if not evidence['reaped'] or evidence['returncode'] != 0 or evidence['cleanup_error'] is not None:
                    raise ValueError('admission cleanup integrity')
                canonical = admitted.pop('canonical_text', None)
            except ResourceLimitFailure as exc:
                evidence = exc.worker_evidence
                if not (evidence['source_sent'] and evidence['source_after_host_gate'] and evidence['reaped']
                        and evidence['cleanup_error'] is None and evidence['terminal_reason'] is not None):
                    raise ValueError('admission limit evidence integrity')
                admitted = {'admitted': False, 'kind': evidence['terminal_reason']['kind']}
                canonical = None
            admission = {'result': admitted, 'worker': evidence}
            receipt['admission'] = admission
            journal.finish(token, admission)
            worker = None
            if not admitted['admitted']:
                receipt.update(status='admission_rejected', reason=admitted['kind'])
                for case in panel['cases']:
                    receipt['cases'].append({'case_id': case['id'], 'outcome': 'not_run_admission_rejected'})
            else:
                receipt['canonical_AST_text_sha256'] = sha(canonical.encode())
                for index, case in enumerate(panel['cases']):
                    items = case['items']
                    expected = {'input_sha256': case['input_sha256'], 'n': 1000,
                                'capacity': panel['capacity'], 'L1': case['L1']}
                    check_instance(items, panel['capacity'], expected)
                    execution_id = claim['claim_id'] + '/instance/' + str(index)
                    token = journal.reserve(binding, execution_id)
                    reserve(CASE_RESERVATION, 'case/' + str(case['id']))
                    report = supervised_pack(items, panel['capacity'], candidate, binding,
                                             execution_id=execution_id, instance_index=index)
                    evidence = report['worker']
                    checked = None
                    if report['outcome'] == 'ok':
                        checked = check_assignment(items, panel['capacity'], report['result'])
                        if evidence['admission']['canonical_text'] != canonical or evidence['assignment_complete'] is not True:
                            raise ValueError('case AST/completion identity')
                    elif not (evidence['reaped'] and evidence['cleanup_error'] is None and not evidence['assignment_complete']):
                        raise ValueError('case failure cleanup integrity')
                    row = {'case_id': case['id'], 'instance_index': index, 'n': 1000,
                           'input_sha256': case['input_sha256'], 'outcome': report['outcome'],
                           'used_bins': checked['used_bins'] if checked else None, 'L1': case['L1'],
                           'assignment_sha256': checked['assignment_sha256'] if checked else None,
                           'checker_status': 'passed' if checked else 'not_run',
                           'worker': evidence, 'supervisor': report['supervisor_evidence']}
                    write_json(output / ('case_' + str(case['id']) + '_raw_report.json'), report)
                    journal.finish(token, row)
                    receipt['cases'].append(row)
                    # Run the same three independently isolated cases even after a
                    # typed numerical/cap failure; never fix or replace the code.
                if all(case['outcome'] == 'ok' for case in receipt['cases']):
                    fitness = sum((Fraction(case['L1'], case['used_bins']) for case in receipt['cases']), Fraction()) / 3
                    gap = 100 * Fraction(sum(c['used_bins'] for c in receipt['cases']) - sum(c['L1'] for c in receipt['cases']),
                                         sum(c['L1'] for c in receipt['cases']))
                    receipt.update(status='complete', public_prefix_fitness={'numerator': fitness.numerator, 'denominator': fitness.denominator},
                                   report_gap_percent=float(gap))
                else:
                    receipt.update(status='evaluation_failed', public_prefix_fitness=None, report_gap_percent=None)
        except BudgetStop as exc:
            receipt.update(status='budget_stop', reason=str(exc), public_prefix_fitness=None)
            done = {case['case_id'] for case in receipt['cases']}
            for case in panel['cases']:
                if case['id'] not in done:
                    receipt['cases'].append({'case_id': case['id'], 'outcome': 'not_run_total_CPU_gate'})
            halted = True
        except (UnicodeError, ValueError) as exc:
            # Source-size/encoding errors occur before any candidate child exists;
            # after binding/admission, any unexplained error is an integrity stop.
            receipt.update(status='invalid_source' if receipt['admission'] is None and 'registry_binding' not in receipt else 'integrity_stop',
                           reason=type(exc).__name__ + ': ' + str(exc),
                           worker_evidence=getattr(exc, 'worker_evidence', None),
                           supervisor_evidence=getattr(exc, 'supervisor_evidence', None))
            halted = receipt['status'] == 'integrity_stop'
        except BaseException as exc:
            if worker is not None and not worker.reaped:
                exc = worker._preserve_failure(exc, kill=True)
            receipt.update(status='integrity_stop', reason=type(exc).__name__ + ': ' + str(exc),
                           worker_evidence=getattr(exc, 'worker_evidence', None),
                           supervisor_evidence=getattr(exc, 'supervisor_evidence', None))
            halted = True
        finally:
            measured = cpu_usage()
            receipt['cpu'] = measured
            receipt['wall_seconds'] = time.monotonic() - start
            receipt['total_gate_cpu_after_this_candidate'] = prior + measured['whole_process_tree_cpu_seconds']
            if receipt['total_gate_cpu_after_this_candidate'] > TOTAL_CPU_GATE:
                receipt.update(status='integrity_stop', reason='total actual CPU gate exceeded')
                halted = True
            write_json(output / 'receipt.json', receipt)
            budget.update(completed_cpu_seconds=receipt['total_gate_cpu_after_this_candidate'], active=None,
                          halted=halted, halt_reason=receipt.get('reason') if halted else None)
            budget['completed_tasks'].append({'task_id': args.task_id, 'status': receipt['status'],
                                               'whole_process_tree_cpu_seconds': measured['whole_process_tree_cpu_seconds'],
                                               'receipt_sha256': sha((output / 'receipt.json').read_bytes())})
            replace_json(budget_path, budget)
            print(json.dumps({'task_id': args.task_id, 'status': receipt['status'],
                              'cases': len(receipt['cases']), 'cpu_seconds': measured['whole_process_tree_cpu_seconds'],
                              'cumulative_cpu_seconds': budget['completed_cpu_seconds'], 'halted': halted}))
        return 2 if halted else (0 if receipt['status'] == 'complete' else 1)

class BudgetStop(RuntimeError):
    pass

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--task-id', required=True)
    parser.add_argument('--source-path', required=True, type=Path)
    parser.add_argument('--raw-response-path', type=Path)
    raise SystemExit(run(parser.parse_args()))
