#!/usr/bin/env python3
"""Build the final records/source/pins ZIP; no model, scoring or network calls.

Run only after dispatch has ended and assessment/statistics have been refreshed.
This is an independent, unfrozen packaging helper. It never changes the existing
large ZIP, HANDOFF_MANIFEST.json, delivery_pin.json, protocol or execution pins.
"""
import argparse
from collections import Counter
import fcntl
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile
import time
import zipfile

ROOT = Path(__file__).resolve().parent
DEFAULT_NAME = 'GLM53独立消融_实验记录源码固定_不含原生CLI_20261007.zip'
MANIFEST_NAME = 'RECORDS_HANDOFF_MANIFEST.json'
PIN_NAME = 'records_delivery_pin.json'
LARGE_NAME = 'GLM53独立36任务消融_20261007.zip'
LIMIT_32MIB = 32 * 1024 * 1024
BINARY_BYTES = 185632896
BINARY_SHA = '9ca0b9953d49997601655e54f846a3efa464f237e47c6f1b04716d0f2e64c4c2'
TEXT_EXT = {
    '.ts', '.tsx', '.js', '.jsx', '.mjs', '.cjs', '.mts', '.cts',
    '.json', '.jsonc', '.md', '.mdx', '.txt', '.patch', '.toml', '.lock',
    '.yml', '.yaml', '.rs', '.py', '.sql', '.c', '.h', '.cc', '.cpp', '.cxx',
    '.hpp', '.css', '.scss', '.sass', '.less', '.html', '.astro', '.svelte',
    '.vue', '.sh', '.ps1', '.nix', '.xml', '.plist', '.webmanifest', '.desktop',
    '.snap', '.example', '.cmake', '.go', '.rb',
}
SOURCE_NAMES = {'LICENSE', 'LICENSE.md', 'NOTICE', 'bun.lock', 'Dockerfile',
                'Makefile', 'CMakeLists.txt', 'Justfile', 'install',
                '.gitignore', '.gitattributes', '.dockerignore', '.editorconfig',
                '.npmrc', '.prettierignore', '.prettierrc', '.node-version', '.tool-versions'}
SECRET_NAMES = ['ZHIPU_API_KEY', 'HTTP_PROXY', 'HTTPS_PROXY',
                'http_proxy', 'https_proxy', 'ALL_PROXY', 'all_proxy']


def utc():
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())


def load(path):
    return json.loads(path.read_bytes())


def sha_file(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def include(path, output):
    """Original safe selection, plus source text and only one new omission."""
    rel = path.relative_to(ROOT)
    parts = rel.parts
    if not path.is_file() or path.is_symlink() or path == output:
        return False
    if len(parts) == 1 and path.name in {
        LARGE_NAME, 'HANDOFF_MANIFEST.json', 'delivery_pin.json', 'drive_delivery.json',
        MANIFEST_NAME, PIN_NAME,
    }:
        return False
    if any(part in {'__pycache__', 'npm-cache', 'offline_mock', '.git'} for part in parts):
        return False
    if parts[0] == 'raw' and 'runtime' in parts:
        return False
    if parts[0] in {'xdg', 'work', 'readbacks'}:
        return False
    if parts[0] == 'batches':
        return path.name.endswith('.delivery.json') or path.name.endswith('.pin.json')
    if parts[0] == 'pins' and path.name in {
        'opencode',  # The sole additional exclusion versus the large package.
        'opencode-linux-x64-1.18.34.tgz',  # Original duplicate archive exclusion.
    }:
        return False
    if parts[0] == 'source_audit':
        if path.name == 'opencode-v1.18.34.tar.gz':
            return False  # Original duplicate upstream archive exclusion.
        if len(parts) > 2 and parts[1] == 'offline_cli' and parts[2] in {'data', 'cache', 'state'}:
            return False
        if len(parts) > 1 and parts[1] == 'opencode-1.18.34':
            return path.suffix.lower() in TEXT_EXT or path.name in SOURCE_NAMES
    if len(parts) == 1:
        return path.suffix.lower() in TEXT_EXT or path.name in {'all36.csv', 'condition_summary.csv'}
    return True


def active_official_client_pids():
    """Only argv0 for processes named opencode, never env/full command lines."""
    found = []
    official = str(ROOT / 'pins/opencode').encode()
    for entry in Path('/proc').iterdir():
        if not entry.name.isdigit():
            continue
        try:
            stat = (entry / 'stat').read_text()
            left, right = stat.find('('), stat.rfind(')')
            if stat[left + 1:right] != 'opencode' or stat[right + 2:].split()[0] == 'Z':
                continue
            fd = os.open(entry / 'cmdline', os.O_RDONLY)
            try:
                argv0 = bytearray()
                for _ in range(1024):
                    byte = os.read(fd, 1)
                    if not byte or byte == b'\0':
                        break
                    argv0.extend(byte)
                if bytes(argv0) == official:
                    found.append(int(entry.name))
            finally:
                os.close(fd)
        except FileNotFoundError:
            continue
        except PermissionError:
            raise SystemExit('Cannot establish generation quiescence from process metadata; no package written.')
    return found


def generation_boundary():
    plan = load(ROOT / 'protocol/selection_and_order.json')
    tasks = plan.get('tasks', [])
    if len(tasks) != 36 or len({task.get('task_id') for task in tasks}) != 36:
        raise SystemExit('Frozen unique 36-task plan missing or invalid; no package written.')
    expected = Counter({(model, effort): 6 for model in ['glm-5.3', 'glm-5.3-flash']
                        for effort in ['low', 'high', 'max']})
    if Counter((task['model'], task['reasoning_effort']) for task in tasks) != expected:
        raise SystemExit('Frozen model/effort allocation differs; no package written.')
    rows = []
    for task in tasks:
        folder = ROOT / 'raw' / task['task_id']
        terminal_path = folder / 'terminal.json'
        if terminal_path.exists():
            terminal = load(terminal_path)
            if terminal.get('task_id') != task['task_id']:
                raise SystemExit('Terminal identity differs; no package written.')
            state = 'terminal'
            result = {key: terminal.get(key) for key in ['status', 'exit_code', 'timed_out', 'ended_utc']}
        elif folder.exists():
            state = 'started_without_terminal_unknown'
            result = {}
        else:
            state = 'frozen_not_started'
            result = {}
        rows.append(dict(task_id=task['task_id'], order=task['order'], model=task['model'],
                         reasoning_effort=task['reasoning_effort'], question_id=task['question_id'],
                         state=state, **result))
    counts = Counter(row['state'] for row in rows)
    stop_path = ROOT / 'STOP.json'
    stop = load(stop_path) if stop_path.exists() else None
    if counts['terminal'] == 36:
        mode = 'all_36_client_terminals_present'
    else:
        if not isinstance(stop, dict) or not isinstance(stop.get('reason'), str) or not stop['reason'].strip():
            raise SystemExit('Generation still incomplete without current STOP.json; no package written.')
        stop_task = stop.get('task')
        stop_id = stop_task.get('task_id') if isinstance(stop_task, dict) else stop_task
        by_id = {row['task_id']: row for row in rows}
        if stop_id not in by_id:
            raise SystemExit('Current STOP lacks a frozen task identity; no package written.')
        if any(row['order'] > by_id[stop_id]['order'] and row['state'] != 'frozen_not_started' for row in rows):
            raise SystemExit('STOP precedes later attempts and may be stale; no package written.')
        mode = 'current_stop_with_all_remaining_and_uncertainty_reported'
    active = active_official_client_pids()
    if active:
        raise SystemExit(f'Official OpenCode client still active (PIDs {active}); no package written.')
    for name in ['summary.json', 'all36.csv', 'condition_summary.csv', 'report.md', 'evaluation/assessment.json']:
        if not (ROOT / name).is_file():
            raise SystemExit(f'Final assessment/statistics evidence missing: {name}; no package written.')
    summary = load(ROOT / 'summary.json')
    attempted = counts['terminal'] + counts['started_without_terminal_unknown']
    if summary.get('totals', {}).get('attempted') != attempted:
        raise SystemExit('Statistics attempted count is stale; refresh statistics before packaging.')
    return dict(mode=mode, planned=36, client_terminal_count=counts['terminal'],
                started_without_terminal_count=counts['started_without_terminal_unknown'],
                frozen_not_started_count=counts['frozen_not_started'],
                remaining_frozen_not_started=[row['task_id'] for row in rows if row['state'] == 'frozen_not_started'],
                unresolved_started=[row['task_id'] for row in rows if row['state'] == 'started_without_terminal_unknown'],
                tasks=rows, current_stop=stop, server_cancellation='unknown',
                underlying_network_http_attempts='unknown')


def native_metadata():
    binary = ROOT / 'pins/opencode'
    if not binary.is_file() or binary.stat().st_size != BINARY_BYTES or sha_file(binary) != BINARY_SHA:
        raise SystemExit('Local official binary differs from its fixed pin; no package written.')
    metadata = dict(path='pins/opencode', version='1.18.34', bytes=BINARY_BYTES,
                    sha256=BINARY_SHA, included_in_this_zip=False,
                    official_npm_package='opencode-linux-x64@1.18.34',
                    official_registry_tarball='https://registry.npmjs.org/opencode-linux-x64/-/opencode-linux-x64-1.18.34.tgz',
                    official_source_tag='https://github.com/anomalyco/opencode/tree/v1.18.34',
                    provenance_files=['pins/registry.json', 'pins/official_verification.md',
                                      'pins/npm_opencode_ai_1.18.34.json', 'source_audit/source-pins.json'],
                    restoration_requires_official_pinned_binary=True)
    old_pin_path = ROOT / 'delivery_pin.json'
    if old_pin_path.is_file():
        old_pin = load(old_pin_path)
        metadata['existing_large_zip_local_pin'] = {key: old_pin.get(key) for key in ['path', 'bytes', 'sha256']}
    metadata['existing_large_zip_name'] = LARGE_NAME
    metadata['existing_large_zip_drive_byte_readback'] = 'unverified_due_to_HTTP_403; no retry or bypass by this helper'
    return metadata


def source_exclusions(files):
    selected = {path.relative_to(ROOT).as_posix() for path in files}
    excluded = Counter()
    source = ROOT / 'source_audit/opencode-1.18.34'
    for path in source.rglob('*'):
        if path.is_file() and not path.is_symlink() and path.relative_to(ROOT).as_posix() not in selected:
            excluded[path.suffix.lower() or '<no extension>'] += 1
    return dict(sorted(excluded.items()))


def snapshot_stat(path):
    stat = path.stat()
    return stat.st_size, stat.st_mtime_ns, stat.st_ino


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-name', default=DEFAULT_NAME,
                        help='A distinct .zip basename in this experiment directory; never overwrites.')
    parser.add_argument('--dry-run', action='store_true',
                        help='Read-only selection and byte counts; permitted while generation continues.')
    args = parser.parse_args()
    if Path(args.output_name).name != args.output_name or not args.output_name.endswith('.zip') or args.output_name == LARGE_NAME:
        raise SystemExit('Output must be a distinct ZIP basename.')
    output = ROOT / args.output_name
    files = sorted(path for path in ROOT.rglob('*') if include(path, output))
    if args.dry_run:
        print(json.dumps(dict(dry_run=True, files=len(files),
                              uncompressed_bytes=sum(path.stat().st_size for path in files),
                              no_archive_written=True, native_binary_excluded=True,
                              expanded_upstream_source_text_extensions=sorted(TEXT_EXT)), ensure_ascii=False))
        return 0
    if output.exists() or (ROOT / MANIFEST_NAME).exists() or (ROOT / PIN_NAME).exists():
        raise SystemExit('Records package or sidecars already exist; no existing artifact overwritten.')
    boundary = generation_boundary()
    assessment_lock = ROOT / 'evaluation/assessment-manager.lock'
    lock_fd = os.open(assessment_lock, os.O_RDONLY) if assessment_lock.exists() else None
    temp_path = None
    try:
        if lock_fd is not None:
            try:
                fcntl.flock(lock_fd, fcntl.LOCK_SH | fcntl.LOCK_NB)
            except BlockingIOError:
                raise SystemExit('Assessment manager is active; no package written.')
        native = native_metadata()
        # Values exist only in memory for exact literal checks. Never serialize.
        secret_values = [value.encode() for name in SECRET_NAMES
                         if (value := os.environ.get(name)) and len(value) >= 8]
        pins = {}
        initial_stats = {path: snapshot_stat(path) for path in files}
        fd, temp = tempfile.mkstemp(prefix='.records-handoff-', suffix='.tmp', dir=ROOT)
        os.close(fd)
        temp_path = Path(temp)
        with zipfile.ZipFile(temp_path, 'w', compression=zipfile.ZIP_DEFLATED,
                             compresslevel=6, allowZip64=True) as archive:
            for path in files:
                data = path.read_bytes()
                relative = path.relative_to(ROOT).as_posix()
                if any(value in data for value in secret_values):
                    raise SystemExit(f'Credential literal detected in {relative}; no published records package.')
                pins[relative] = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
                archive.writestr(relative, data)
            manifest = dict(
                schema='independent-ablation-records-source-pins-no-native-cli-v1',
                created_utc=utc(), package_label='实验记录、审计源码与版本固定包（不含原生 CLI 二进制）',
                self_contained=False, task_boundary=boundary, files=pins,
                credential_scan_passed=True, credential_values_serialized=False,
                omitted_native_binary=native,
                included_scope=[
                    'Frozen private input/source ZIP and its extracted approved input/source files',
                    'All six prompt/source packs, all 36 configurations, protocol, freezes and amendments',
                    'Every existing terminal, raw SDK request/response, receipt, timeout and failure record',
                    'All existing candidate/admission/scoring receipts, evaluation source/data pins and statistics',
                    'Experiment/runner/recorder source, SDK mapping/source, installed plugin scaffold and pins',
                    'Passive process observations, operational evidence and batch delivery receipts',
                    'Upstream audit/source text including CSS, HTML, MDX, Astro, shell and configuration text',
                ],
                original_exclusions_retained=[
                    'Private CLI runtime databases/auth/cache/state, work directory and cache directories',
                    'Offline synthetic mock receipts and duplicate transport copies/archive payloads',
                    'Duplicate official native binary tar and duplicate upstream source tar',
                    'Unneeded upstream website/desktop media, fonts, icons, screenshots and other nonselected assets',
                ],
                upstream_source_text_scope='All selected experiment audit code and expanded upstream source/documentation text; this is not a claim of a complete upstream repository/assets copy.',
                upstream_nonselected_extension_counts=source_exclusions(files),
                upload_performed=False, drive_readback_verification='not_attempted_by_this_local_helper',
            )
            manifest_bytes = json.dumps(manifest, sort_keys=True, ensure_ascii=False, indent=2).encode()
            if any(value in manifest_bytes for value in secret_values):
                raise SystemExit('Credential literal detected in generated manifest; no published records package.')
            archive.writestr(MANIFEST_NAME, manifest_bytes)
        if any(snapshot_stat(path) != initial_stats[path] or sha_file(path) != pins[path.relative_to(ROOT).as_posix()]['sha256'] for path in files):
            raise SystemExit('Source records changed during packaging; temporary package removed, no final archive published.')
        if set(files) != {path for path in ROOT.rglob('*') if include(path, output)}:
            raise SystemExit('Selected file roster changed during packaging; no final archive published.')
        if generation_boundary() != boundary:
            raise SystemExit('Task boundary changed during packaging; no final archive published.')
        # Atomic publication without overwriting a competing/existing archive.
        os.link(temp_path, output)
        temp_path.unlink()
        temp_path = None
        with (ROOT / MANIFEST_NAME).open('xb') as stream:
            stream.write(manifest_bytes)
        result = dict(path=str(output), bytes=output.stat().st_size, sha256=sha_file(output),
                      payload_files=len(pins), zip_entries=len(pins) + 1,
                      self_contained=False, native_binary_included=False,
                      manifest_bytes=len(manifest_bytes), manifest_sha256=hashlib.sha256(manifest_bytes).hexdigest(),
                      limit_32MiB_bytes=LIMIT_32MIB, fits_32MiB=output.stat().st_size <= LIMIT_32MIB,
                      credential_scan_passed=True, upload_performed=False,
                      drive_byte_readback='not_attempted', task_boundary_mode=boundary['mode'])
        with (ROOT / PIN_NAME).open('x') as stream:
            stream.write(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
        print(json.dumps(result, ensure_ascii=False))
        # Preserve the complete local ZIP even if it grows beyond the transport
        # target; never silently discard evidence or remove more components.
        return 0 if result['fits_32MiB'] else 2
    finally:
        if temp_path is not None:
            temp_path.unlink(missing_ok=True)
        if lock_fd is not None:
            os.close(lock_fd)


if __name__ == '__main__':
    sys.exit(main())
