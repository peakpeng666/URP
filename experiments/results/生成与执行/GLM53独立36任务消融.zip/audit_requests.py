"""Read real captured SDK JSON only; no network and no model calls."""
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def canon(x):return json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()
def content(x):
 if isinstance(x,str):return x
 assert isinstance(x,list) and all(p.get('type')=='text' for p in x)
 return ''.join(p['text'] for p in x)
plan=json.loads((ROOT/'protocol/selection_and_order.json').read_bytes())
rows=[]
for task in plan['tasks']:
 for p in sorted((ROOT/'raw'/task['task_id']).glob('fetch-*.request.json')):
  b=json.loads(p.read_bytes());systems=[m for m in b['messages'] if m['role']=='system'];users=[m for m in b['messages'] if m['role']=='user']
  assert len(systems)==len(users)==1
  system=content(systems[0]['content']).encode();user=content(users[0]['content']).encode()
  q=task['question_id']
  assert system==(ROOT/'protocol'/(q+'.system.txt')).read_bytes()
  assert user==(ROOT/'protocol'/(q+'.user.txt')).read_bytes()
  assert b['model']==task['model'] and b['reasoning_effort']==task['reasoning_effort']
  assert b['max_tokens']==64000 and b['temperature']==0.7 and b['top_p']==0.9
  assert not b.get('tools') and b.get('tool_choice') is None
  assert b['stream'] is True
  rows.append(dict(task,request_file=str(p.relative_to(ROOT)),request_sha256=sha(p.read_bytes()),system_sha256=sha(system),user_sha256=sha(user),tool_definitions=b.get('tools'),tool_definitions_sha256=sha(canon(b.get('tools'))),tool_count=0,parameters_observed_on_SDK_wire=True,server_internal_effort_and_output_cap_observation='unknown'))
conditions={}
for r in rows:
 conditions.setdefault(r['question_id'],[]).append({'model':r['model'],'effort':r['reasoning_effort'],'system_sha256':r['system_sha256'],'user_sha256':r['user_sha256'],'tools_sha256':r['tool_definitions_sha256']})
result={'schema':'captured-sdk-request-audit-v1','observed_fetch_request_bodies':len(rows),'underlying_actual_network_attempts':'unknown','all_observed_bodies_match_frozen_system_user_and_explicit_parameters':True,'rows':rows,'per_question_observed_conditions':conditions,'complete_six_condition_text_check':{q:len({(r['model'],r['effort']) for r in c})==6 and len({(r['system_sha256'],r['user_sha256'],r['tools_sha256']) for r in c})==1 for q,c in conditions.items()}}
(ROOT/'request_audit.json').write_bytes(canon(result))
print('Captured SDK request bodies verified:',len(rows))
