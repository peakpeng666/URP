"""Stop only the serial controller after its active CLI has a persisted terminal."""
import ctypes,json,os,select,signal,struct,sys,time
from pathlib import Path
root=Path('/workspace/ablation_20261007');task=sys.argv[1];pid=int(sys.argv[2]);folder=root/'raw'/task
libc=ctypes.CDLL(None,use_errno=True);fd=libc.inotify_init1(0)
assert fd>=0
assert libc.inotify_add_watch(fd,os.fsencode(folder),0x8|0x80)>=0
def ready():
 p=folder/'terminal.json'
 if not p.exists():return False
 try:return json.loads(p.read_bytes())
 except (ValueError,OSError):return False
while not ready():
 select.select([fd],[],[],1)
 if select.select([fd],[],[],0)[0]:os.read(fd,65536)
terminal=ready()
# run_one writes this only after communicate()/wait() reaped the sole CLI.
os.kill(pid,signal.SIGTERM)
record={'task_id':task,'controller_pid':pid,'action':'SIGTERM serial controller only AFTER durable CLI terminal; no future dispatch','CLI_interrupted_by_pause':False,'CLI_exit_code':terminal['exit_code'],'CLI_timed_out':terminal['timed_out'],'terminal_count':len(list((root/'raw').glob('*/terminal.json'))),'remaining_tasks_never_started':36-len(list((root/'raw').glob('*/invocation.json'))),'latest_parent_instruction':'先报告证据和最小建议，不擅自重发或改freeze。'}
(root/'PAUSE_AT_NATURAL_BOUNDARY.json').write_text(json.dumps(record,ensure_ascii=False,indent=2))
print(json.dumps(record,ensure_ascii=False),flush=True)
