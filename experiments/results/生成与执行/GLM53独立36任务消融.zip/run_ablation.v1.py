"""Serial official OpenCode runner. Never retry a task or activate original ledgers."""
import datetime,hashlib,json,os,signal,subprocess,sys,time,shutil
from pathlib import Path

ROOT=Path(__file__).resolve().parent
def canon(x):return json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()
def write(p,x):p.write_bytes(canon(x))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def frozen_check():
    f=json.loads((ROOT/'protocol/FREEZE.json').read_bytes())
    for n,pin in f['files'].items():
        p=ROOT/n
        assert p.stat().st_size==pin['bytes'] and sha(p)==pin['sha256'],n
    assert sha(ROOT/'pins/opencode')=='9ca0b9953d49997601655e54f846a3efa464f237e47c6f1b04716d0f2e64c4c2'
def summaries(folder):
    rows=[]
    for p in sorted(folder.glob('fetch-*.response.bin')):
        data=p.read_bytes();objs=[]
        try:
            objs=[json.loads(data)]
        except (ValueError,UnicodeDecodeError):
            for line in data.decode('utf-8',errors='replace').splitlines():
                if line.startswith('data:') and line[5:].strip()!='[DONE]':
                    try:objs.append(json.loads(line[5:].strip()))
                    except ValueError:pass
        ids=sorted({o['id'] for o in objs if isinstance(o,dict) and o.get('id')})
        models=sorted({o['model'] for o in objs if isinstance(o,dict) and o.get('model')})
        usages=[o['usage'] for o in objs if isinstance(o,dict) and o.get('usage') is not None]
        finishes=[];parts=[]
        for o in objs:
            if not isinstance(o,dict):continue
            for c in o.get('choices',[]):
                if c.get('finish_reason') is not None:finishes.append(c['finish_reason'])
                text=c.get('delta',c.get('message',{})).get('content')
                if isinstance(text,str):parts.append(text)
        rows.append({'file':str(p.relative_to(ROOT)),'bytes':len(data),'sha256':sha(p),'provider_response_ids':ids,'provider_model_ids':models,'raw_usage':usages,'raw_finish_reasons':finishes})
        if parts:(folder/(p.stem+'.candidate.txt')).write_bytes(''.join(parts).encode())
    return rows
def run_one(task):
    frozen_check()
    td=ROOT/'raw'/task['task_id']
    td.mkdir(exist_ok=False)
    q=task['question_id'];system=ROOT/'protocol'/(q+'.system.txt');user=ROOT/'protocol'/(q+'.user.txt')
    manifest=dict(task,provider_id='zhipuai-coding-plan',model_id=task['model'],system_text_path=str(system),user_text_path=str(user),system_sha256=sha(system),user_sha256=sha(user),raw_dir=str(td))
    write(td/'task-manifest.json',manifest)
    runtime=td/'runtime'
    for n in ['config','data','cache','state']: (runtime/n).mkdir(parents=True)
    config_dir=runtime/'config/opencode'
    config_dir.mkdir()
    scaffold=ROOT/'source_audit/offline_cli/config/opencode'
    for n in ['package.json','package-lock.json']:
        shutil.copyfile(scaffold/n,config_dir/n)
    (config_dir/'node_modules').symlink_to(scaffold/'node_modules',target_is_directory=True)
    env={k:os.environ[k] for k in ['PATH','LANG','LC_ALL','TMPDIR','ZHIPU_API_KEY','HTTP_PROXY','HTTPS_PROXY','http_proxy','https_proxy','NO_PROXY','no_proxy','NODE_EXTRA_CA_CERTS','SSL_CERT_FILE'] if k in os.environ}
    assert bool(env.get('ZHIPU_API_KEY')),'ZHIPU_API_KEY missing'
    env.update({
        'XDG_CONFIG_HOME':str(runtime/'config'),'XDG_DATA_HOME':str(runtime/'data'),
        'XDG_CACHE_HOME':str(runtime/'cache'),'XDG_STATE_HOME':str(runtime/'state'),
        'OPENCODE_CONFIG':str(ROOT/'protocol'/('config-'+task['task_id']+'.json')),
        'OPENCODE_CONFIG_DIR':str(config_dir),'PWD':str(ROOT/'work'),
        'OPENCODE_EXPERIMENTAL_OUTPUT_TOKEN_MAX':'64000',
        'ABLATION_TASK_MANIFEST':str(td/'task-manifest.json'),
    })
    for name in ['OPENCODE_DISABLE_AUTOUPDATE','OPENCODE_DISABLE_MODELS_FETCH','OPENCODE_DISABLE_DEFAULT_PLUGINS','OPENCODE_DISABLE_CLAUDE_CODE','OPENCODE_DISABLE_PROJECT_CONFIG','OPENCODE_DISABLE_AUTOCOMPACT','OPENCODE_DISABLE_LSP_DOWNLOAD','OPENCODE_EXPERIMENTAL_DISABLE_FILEWATCHER']:
        env[name]='true'
    cmd=[str(ROOT/'pins/opencode'),'--log-level','ERROR','run','--dir',str(ROOT/'work'),'--agent','candidate','--model','zhipuai-coding-plan/'+task['model'],'--variant',task['reasoning_effort'],'--title',task['task_id'],'--format','json']
    receipt=dict(task,started_utc=utc(),command=cmd,cli_starts=1,outer_retries=0,timeout_seconds=900,environment_variable_names=sorted(env),secrets_recorded=False)
    write(td/'invocation.json',receipt)
    start=time.monotonic();timed_out=False
    with open(td/'stdout.jsonl','wb') as out,open(td/'stderr.log','wb') as err:
        p=subprocess.Popen(cmd,cwd=ROOT/'work',env=env,stdin=subprocess.PIPE,stdout=out,stderr=err,start_new_session=True)
        try:p.communicate(user.read_bytes(),timeout=900)
        except subprocess.TimeoutExpired:
            timed_out=True
            os.killpg(p.pid,signal.SIGTERM)
            try:p.wait(timeout=2)
            except subprocess.TimeoutExpired:
                os.killpg(p.pid,signal.SIGKILL);p.wait()
    records=summaries(td)
    finishes=[r for rr in records for r in rr['raw_finish_reasons']]
    success=p.returncode==0 and bool(records) and bool(finishes) and not timed_out
    terminal=dict(receipt,ended_utc=utc(),wall_seconds=time.monotonic()-start,exit_code=p.returncode,timed_out=timed_out,status='completed' if success else 'failed',responses=records,actual_account_credit_deduction='unknown',actual_RMB_charge='not_observed',underlying_network_attempts='unknown; recorder observes SDK fetch invocations only')
    write(td/'terminal.json',terminal)
    allterm=[json.loads(x.read_bytes()) for x in sorted((ROOT/'raw').glob('*/terminal.json'))]
    write(ROOT/'progress.json',{'terminal_count':len(allterm),'completed':sum(x['status']=='completed' for x in allterm),'failed':sum(x['status']=='failed' for x in allterm),'last':task,'updated_utc':utc()})
    print(json.dumps({'terminal':task,'status':terminal['status'],'exit':p.returncode,'seconds':round(terminal['wall_seconds'],2),'responses':len(records),'finish':finishes}),flush=True)
    if not success:
        write(ROOT/'STOP.json',{'task':task,'reason':'CLI/configuration/provider result requires review. No retry or later task started.','terminal':str(td/'terminal.json'),'utc':utc()})
        return False
    if (td/'stop.json').exists() or (td/'STOP.json').exists():
        write(ROOT/'STOP.json',{'task':task,'reason':'Recorder provider or quota safety gate stopped run','utc':utc()})
        return False
    return True

if __name__=='__main__':
    plan=json.loads((ROOT/'protocol/selection_and_order.json').read_bytes())
    maximum=int(sys.argv[1]) if len(sys.argv)>1 else 36
    assert 1<=maximum<=36
    assert not (ROOT/'STOP.json').exists(),'Run stopped; no automatic restart'
    started=0
    for t in plan['tasks']:
        d=ROOT/'raw'/t['task_id']
        if d.exists():
            assert (d/'terminal.json').exists(),'Uncertain prior CLI result; stop'
            continue
        if started>=maximum:break
        started+=1
        if not run_one(t):break
