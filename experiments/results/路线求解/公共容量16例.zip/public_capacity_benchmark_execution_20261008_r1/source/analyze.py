"""Post-run analysis only; no solver imports or execution."""
import json,hashlib,math,csv
from pathlib import Path
from collections import Counter
from independent_check import validate
R=Path(__file__).resolve().parents[1]
def read(p):return json.loads((R/p).read_text())
def dump(p,x):
 with (R/p).open('x') as f:json.dump(x,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')
rs=[json.loads(s) for s in (R/'raw/results.jsonl').read_text().splitlines()];sched=read('freeze/SCHEDULE.json');assert len(rs)==len(sched)==96
for i,r in enumerate(rs):
 assert all(r[k]==sched[i][k] for k in sched[i])
 p=R/'input'/f"{r['instance_id']}.json";assert hashlib.sha256(p.read_bytes()).hexdigest()==r['input_sha256']
 for ext in ['stdout','stderr']:assert hashlib.sha256((R/'raw/calls'/f"{r['call_id']}.{ext}").read_bytes()).hexdigest()==r[ext+'_sha256']
 if r['status']=='SUCCESS':assert validate(json.loads(p.read_text()),r['groups'],r['output'])['accepted']
 assert not r['reference_access_denied_paths'] and r['solver_witness_or_BKS_reads']==0 and r['local_search_calls']==0
for f in read('freeze/PRE_RUN_FREEZE.json')['files']:
 p=R/f['path'];assert p.stat().st_size==f['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==f['sha256']
def diag(r):return r['diagnostic'] if r['endpoint']=='partition_256' else r['diagnostic'].get('capacity_partition')
metrics=[]
for r in rs:
 d=diag(r);raw=read('input/'+r['instance_id']+'.json')
 metrics.append({**{k:r[k] for k in ['call_id','instance_id','arm','endpoint','status']},'n_customers':len(raw['demands'])-1,'K':raw['K'],'Q':raw['capacity'],'dfs_entered':d is not None,'nodes':(d or {}).get('nodes',0),'prunes':(d or {}).get('prunes',0),'guard_checks':(d or {}).get('guard_checks',0),'waste_checks':(d or {}).get('waste_checks',0),'residual_checks':(d or {}).get('residual_checks',0),'savings_route_count':r['diagnostic'].get('savings_route_count'),'ffd_fallback':r['diagnostic'].get('fallback_triggered',False),'delta_count':(r['budget'] or {}).get('deltas'),'endpoint_cpu_ns':r['measured_cpu_ns'],'endpoint_wall_ns':r['measured_wall_ns'],'parse_cpu_ns':r['parse_cpu_ns'],'import_cpu_ns':r['import_cpu_ns'],'checker_cpu_ns':r['checker_cpu_ns'],'process_cpu_seconds':r['process_cpu_seconds'],'process_wall_seconds':r['process_wall_seconds'],'child_own_peak_RSS_KiB':r['child_self_maxrss_KiB']})
with (R/'reports/METRICS.csv').open('x',newline='') as f:w=csv.DictWriter(f,fieldnames=list(metrics[0]));w.writeheader();w.writerows(metrics)
summary={}
for ep in ['partition_256','initialize_256']:
 summary[ep]={}
 for arm in ['capacity_solver','pruned_solver','waste_solver']:
  mm=[m for m in metrics if m['endpoint']==ep and m['arm']==arm]
  summary[ep][arm]={'calls':len(mm),'statuses':dict(Counter(m['status'] for m in mm)),'successes':sum(m['status']=='SUCCESS' for m in mm),'dfs_entered':sum(m['dfs_entered'] for m in mm),'nodes':sum(m['nodes'] for m in mm),'prunes':sum(m['prunes'] for m in mm),'ffd_fallbacks':sum(m['ffd_fallback'] for m in mm),'deltas':sum(m['delta_count'] or 0 for m in mm),'endpoint_cpu_ns_total':sum(m['endpoint_cpu_ns'] for m in mm),'endpoint_wall_ns_total':sum(m['endpoint_wall_ns'] for m in mm),'endpoint_cpu_zero_observations':sum(m['endpoint_cpu_ns']==0 for m in mm),'process_cpu_seconds_sum':math.fsum(m['process_cpu_seconds'] for m in mm),'own_peak_RSS_KiB':max(m['child_own_peak_RSS_KiB'] for m in mm)}
paired=[]
for ep in ['partition_256','initialize_256']:
 for name in sorted({r['instance_id'] for r in rs}):
  group={r['arm']:r for r in rs if r['endpoint']==ep and r['instance_id']==name};b=group['capacity_solver'];w=group['waste_solver'];p=group['pruned_solver']
  paired.append({'instance_id':name,'endpoint':ep,'statuses_equal':b['status']==p['status']==w['status'],'all_success':all(x['status']=='SUCCESS' for x in group.values()),'groups_equal':b['groups']==p['groups']==w['groups'],'outputs_equal':b['output']==p['output']==w['output'],'nodes_equal':len({(diag(x) or {}).get('nodes',0) for x in group.values()})==1,'waste_rescue':b['status']!='SUCCESS' and w['status']=='SUCCESS','waste_loss':b['status']=='SUCCESS' and w['status']!='SUCCESS','direct_first_branch_without_backtracking':ep=='partition_256' and all((diag(x) or {}).get('nodes')==len(read('input/'+name+'.json')['demands']) for x in group.values())})
finish=read('raw/FINISHED.json');assert math.isclose(finish['children_cpu_seconds'],math.fsum(r['process_cpu_seconds'] for r in rs),abs_tol=1e-9)
summary['overall']={'tasks':16,'distinct_geometry_demand_bases':14,'unique_calls':96,'statuses':dict(Counter(r['status'] for r in rs)),'independently_accepted_successes':96,'paired_rescues':sum(x['waste_rescue'] for x in paired),'paired_losses':sum(x['waste_loss'] for x in paired),'all_paired_outputs_groups_nodes_equal':all(x['outputs_equal'] and x['groups_equal'] and x['nodes_equal'] for x in paired),'all_direct_calls_first_branch_no_backtrack':all(x['direct_first_branch_without_backtracking'] for x in paired if x['endpoint']=='partition_256'),'parent_cpu_seconds':finish['parent_cpu_seconds'],'children_cpu_seconds':finish['children_cpu_seconds'],'total_attributable_cpu_seconds':finish['parent_cpu_seconds']+finish['children_cpu_seconds'],'wall_seconds':finish['wall_seconds'],'hard_timeout_or_error_count':sum(r['process_returncode']!=0 for r in rs),'solver_reruns':0,'model_calls':0,'local_search_calls':0,'interpretation':'No positive-slack prune or construction-success benefit observed. Full initializer never reached capacity DFS. Short single-call timings cannot establish stable speed differences.'}
dump('reports/SUMMARY.json',summary);dump('reports/PAIRED.json',paired);dump('reports/ANALYSIS_CHECKS.json',{'96_schedule_rows_match':True,'input_stdout_stderr_hashes_match':True,'all_preexecution_frozen_bytes_match':True,'96_arithmetic_output_checks_pass':True,'child_CPU_delta_sum_matches':True,'witness_reads_zero_per_audit_log':True,'analysis_only_no_solver_rerun':True})
print(json.dumps(summary,ensure_ascii=False,indent=2))
