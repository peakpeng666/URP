Public fixed-reference-K capacity initialization diagnostic r1.
16 tasks, 3 arms, 2 modes = 96 first calls; no local search or model.
Execution is gated on a privately archived and read-back-verified preexecution snapshot.
Use continuous Euclidean initializer; no original CVRP optimality gap claim.
