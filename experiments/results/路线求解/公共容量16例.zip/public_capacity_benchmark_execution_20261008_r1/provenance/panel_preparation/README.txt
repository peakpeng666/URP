Public capacity benchmark preparation, 2026-10-08.
16 fixed slots, 32 official raw files, independent arithmetic validation, static applicability only.
No candidate/solver/model executed in this preparation directory.
Read reports/REPORT_ZH.txt, reports/PANEL_METADATA.csv, freeze/PREREGISTRATION_PROPOSAL.json.
Raw bytes and SHA256 provenance are retained. K_ref derives from verified public reference route counts.
Proposed 96-call execution is a separately authorized stage, after verified private snapshot.
Dataset redistribution permission beyond research use is not established; private research archive only.
