"""Download official author source as inert text evidence only, never execute it."""
from pathlib import Path
import urllib.request,datetime,json,hashlib
R=Path(__file__).resolve().parents[1]
records=[]
for p in ['Program/InstanceCVRPLIB.cpp','Program/Individual.cpp','LICENSE']:
 url='https://raw.githubusercontent.com/vidalt/HGS-CVRP/main/'+p
 rec={'url_requested':url,'purpose':'public author format evidence, never executed','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'Accept-Encoding':'identity'}),timeout=45) as h:
   b=h.read(131073);assert len(b)<=131072
   rec.update(http_status=h.status,url_final=h.url,content_type=h.headers.get('Content-Type'),etag=h.headers.get('ETag'))
  dest=R/'provenance'/('HGS_CVRP_'+p.replace('/','_')+'.txt');dest.write_bytes(b)
  rec.update(success=True,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),saved_path=str(dest.relative_to(R)))
 except Exception as e:rec.update(success=False,error=repr(e))
 rec['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();records.append(rec);print(rec['url_requested'],rec['success'],flush=True)
(R/'provenance/FORMAT_SOURCE_ACQUISITION.json').write_text(json.dumps(records,indent=2)+'\n')
