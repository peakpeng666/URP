"""Fetch selected official public data only; no solver/model/authentication calls."""
import urllib.request,urllib.error,hashlib,json,time,datetime,concurrent.futures,threading
from pathlib import Path
R=Path(__file__).resolve().parents[1]
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
lock=threading.Lock()
log=R/'provenance/ACQUISITION.jsonl'
def fetch(t):
 name,kind,url,path=t
 r={'name':name,'kind':kind,'url_requested':url,'started_utc':now(),'destination':str(path.relative_to(R)),'method':'GET','authentication':'none'}
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'CVRP academic data preparation (read-only)','Accept-Encoding':'identity'})
  with urllib.request.urlopen(req,timeout=60) as h:
   b=h.read(2*1024*1024+1)
   if len(b)>2*1024*1024:raise ValueError('response exceeds 2MiB cap')
   if h.url.split('/')[2]!='galgos.inf.puc-rio.br':raise ValueError('unexpected redirect domain')
   r.update(status=h.status,url_final=h.url,content_type=h.headers.get('Content-Type'),content_encoding=h.headers.get('Content-Encoding'),http_date=h.headers.get('Date'),last_modified=h.headers.get('Last-Modified'),etag=h.headers.get('ETag'),content_length_header=h.headers.get('Content-Length'))
  with path.open('xb') as f:f.write(b)
  r.update(success=True,bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
 except Exception as e:r.update(success=False,error_type=type(e).__name__,error=str(e))
 r['finished_utc']=now()
 with lock:
  with log.open('a') as f:f.write(json.dumps(r,ensure_ascii=False)+'\n')
 print(name,kind,r['success'],r.get('bytes'),flush=True)
 return r
rows=json.loads((R/'freeze/SELECTED_PANEL.json').read_text())
jobs=[]
for x in rows:
 jobs.extend([(x['name'],'instance',x['instance_url'],R/'raw/instances'/f"{x['name']}.vrp"),(x['name'],'solution',x['solution_url'],R/'raw/solutions'/f"{x['name']}.sol")])
jobs += [('cvrplib_terms','terms','https://galgos.inf.puc-rio.br/cvrplib/en/register/terms',R/'provenance/cvrplib_terms.html')]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex: out=list(ex.map(fetch,jobs))
(R/'reports/ACQUISITION_SUMMARY.json').write_text(json.dumps({'completed_utc':now(),'attempts':len(out),'success':sum(x['success'] for x in out),'failure':sum(not x['success'] for x in out),'selected_instances':len(rows),'solver_calls':0},indent=2)+'\n')
