"""Metadata-only deterministic panel selection. Never imports or runs a solver."""
import json,hashlib,datetime
from pathlib import Path
R=Path(__file__).resolve().parents[1]
def write(p,o):
 with (R/p).open('x') as f: json.dump(o,f,indent=2,ensure_ascii=False);f.write('\n')
old=Path('/workspace/shared/recovery_original_archives_20261008/prior_positive_slack_72/positive_slack_capacity_bound_20261008/reports/OFFICIAL_READ_ONLY.json')
prior=json.loads(old.read_text()); excluded=[x['name'] for x in prior]
rows=json.loads((R/'provenance/catalog_ABEFP.json').read_text())
targets={'A':[35,50,65,75],'B':[35,50,65,75],'P':[35,50,65,75],'E':[50,75],'F':[45,75]}
selected=[]; decisions=[]
for family,targets_for_family in targets.items():
 for target in targets_for_family:
  pool=[r for r in rows if r['family']==family and 12<=r['n_customers']<=80 and r['name'] not in excluded and r['name'] not in [x['name'] for x in selected]]
  ranked=sorted(pool,key=lambda r:(abs(r['n_customers']-target),r['n_customers'],r['filename_k'],r['name']))
  r=dict(ranked[0],target_n_customers=target,selection_slot=len(selected)+1); selected.append(r)
  decisions.append({'family':family,'target':target,'ranked_eligible_names':[r['name'] for r in ranked],'chosen':r['name']})
write('freeze/SELECTION_RULE.json',{'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stage':'preparation_only','solver_calls_authorized':False,'claim_namespace':'public-capacity-panel-preparation-20261008','source_catalog':'https://galgos.inf.puc-rio.br/cvrplib/en/instances/1','catalog_sha256':hashlib.sha256((R/'provenance/cvrplib_catalog.html').read_bytes()).hexdigest(),'families':['A','B','P','E','F'],'size_inclusion_customers':[12,80],'prior_ids_excluded':excluded,'target_counts':targets,'ranking':['absolute customer-count distance to target','customer count ascending','filename k numeric ascending solely as tie-break label','instance name ascending'],'no_replacements':True,'no_selection_based_on_demands_slack_triggerability_solver_performance':True,'data_failure_rule':'Retain selected slot and report missing/ineligible; do not replace. EUC_2D coordinates, demands, positive Q, single depot and feasible reference solution must verify before execution eligibility.','reference_K_rule':'Number of independently validated nonempty routes in downloaded public reference solution. Never infer hard fleet requirement from filename k.','prior_web_inspections':['A-n34-k5 .vrp/.sol','E-n13-k4 .vrp/.sol','E-n31-k7 .vrp','E-n51-k5 .vrp','E-n76-k7 .vrp','F-n45-k4 .vrp','F-n72-k4 .vrp'],'design_context':'Family and size stratified convenience panel. E targets 50/75 use known coordinate-based examples; smaller E entries seen to use EXPLICIT distances and no coordinates, unsupported by unchanged initializer. F adds documented decimal coordinates and much larger capacity units. No algorithm outcomes inspected for selection.'})
write('freeze/SELECTED_PANEL.json',selected);write('freeze/SELECTION_DECISIONS.json',decisions)
(R/'provenance/PRIOR_NINE_OFFICIAL_READ_ONLY.json').write_bytes(old.read_bytes())
write('provenance/PRIOR_NINE_SOURCE.json',{'path':str(old),'sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'historical_numeric_evidence_only':True,'original_input_bytes_not_reverified_this_stage':True,'records':prior})
print('\n'.join(x['name'] for x in selected))
