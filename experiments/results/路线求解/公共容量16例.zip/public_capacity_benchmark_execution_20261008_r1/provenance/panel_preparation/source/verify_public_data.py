"""Independent arithmetic validation of public files. No candidate or solver imports.
Parse .vrp strict sections, .sol strict lines; independently count coverage and
sum loads. Never solve a partition or optimize a route.
"""
from pathlib import Path
from collections import Counter,defaultdict
import json,re,math,hashlib,statistics,datetime
R=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):
 with (R/p).open('x') as f:json.dump(x,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')
def parse_instance(path):
 s=path.read_bytes().decode('utf-8-sig');meta={};coords={};demand={};depots=[];state=None;eof=False
 for line in s.splitlines():
  line=line.strip()
  if not line:continue
  if line=='EOF':eof=True;break
  if line.endswith('_SECTION'):
   if line not in ('NODE_COORD_SECTION','DEMAND_SECTION','DEPOT_SECTION'):raise ValueError('unsupported section '+line)
   state=line;continue
  if state=='NODE_COORD_SECTION':
   a=line.split(); assert len(a)==3,('bad coordinate',line);i=int(a[0]);assert i not in coords,'duplicate coordinate id';coords[i]=[float(a[1]),float(a[2])];assert all(math.isfinite(z) for z in coords[i])
  elif state=='DEMAND_SECTION':
   a=line.split();assert len(a)==2,('bad demand',line);i=int(a[0]);assert i not in demand,'duplicate demand id';demand[i]=int(a[1])
  elif state=='DEPOT_SECTION':
   for tok in line.split():
    i=int(tok)
    if i!=-1:depots.append(i)
  else:
   a=line.split(':',1);assert len(a)==2,('unrecognized header',line);k=a[0].strip();v=a[1].strip();assert k not in meta,'duplicate header';meta[k]=v
 assert meta['TYPE']=='CVRP'
 assert meta['EDGE_WEIGHT_TYPE']=='EUC_2D','unchanged initializer requires Euclidean coordinates'
 n=int(meta['DIMENSION']);Q=int(meta['CAPACITY']);assert Q>0
 assert len(coords)==n and len(demand)==n
 assert set(coords)==set(demand)==set(range(1,n+1)),'noncanonical node IDs require separate reviewed adapter'
 assert depots==[1],'requires single depot id 1'
 assert demand[1]==0
 assert all(d>=0 for d in demand.values()),'negative demand'
 assert all(d<=Q for d in demand.values()),'individual demand exceeds Q'
 assert eof,'missing EOF'
 return meta,coords,demand,depots

def parse_solution(path):
 routes=[];numbers=[];cost=None
 for line in path.read_bytes().decode('utf-8-sig').splitlines():
  line=line.strip()
  if not line:continue
  m=re.fullmatch(r'Route\s+#(\d+):\s*(.*)',line)
  if m:
   numbers.append(int(m[1]));r=[int(t) for t in m[2].split()];assert r,'empty reference route';routes.append(r);continue
  m=re.fullmatch(r'Cost\s+([0-9]+(?:\.[0-9]+)?)',line)
  if m:assert cost is None,'duplicate cost';cost=float(m[1]);continue
  raise ValueError('unrecognized solution line '+line)
 assert numbers==list(range(1,len(routes)+1)) and routes and cost is not None
 return routes,cost

out=[];normalized_fingerprints=defaultdict(list);geometry_demand_fingerprints=defaultdict(list)
for slot in json.loads((R/'freeze/SELECTED_PANEL.json').read_text()):
 name=slot['name'];rec={'name':name,'slot':slot['selection_slot'],'source_instance':slot['instance_url'],'source_solution':slot['solution_url'],'solver_executed':False}
 try:
  ip=R/'raw/instances'/f'{name}.vrp';sp=R/'raw/solutions'/f'{name}.sol'
  meta,xy,d,dep=parse_instance(ip);routes,claimed=parse_solution(sp);n=len(d)-1
  assert meta['NAME']==name and n==slot['n_customers']
  # CVRPLIB .sol labels 1..n are zero-based labels relative to .vrp 1..n+1:
  # depot 0 is omitted. Prove mapping by exact coverage and claimed cost equality.
  counts=Counter(j for route in routes for j in route)
  assert counts==Counter(range(1,n+1)),('coverage',counts)
  vrp_routes=[[j+1 for j in r] for r in routes]
  loads=[sum(d[j] for j in r) for r in vrp_routes]
  assert max(loads)<=int(meta['CAPACITY'])
  edges=[]
  for r in vrp_routes:
   edges += [math.hypot(xy[a][0]-xy[b][0],xy[a][1]-xy[b][1]) for a,b in zip([1]+r,r+[1])]
  rounded=sum(math.floor(x+0.5) for x in edges);continuous=math.fsum(edges)
  assert rounded==claimed,('EUC_2D cost mismatch',rounded,claimed)
  Q=int(meta['CAPACITY']);K=len(routes);ds=[d[i] for i in range(2,n+2)];pos=[x for x in ds if x>0]
  m=min(pos) if pos else None;D=sum(ds);U=K*Q-D;Wmax=K*(m-1) if m is not None else 0
  # With descending demand, a global-minimum positive customer remains until no
  # positive demand remains. For integer residuals each dead residual <=m-1.
  no_trigger=Wmax<=U
  raw={'instance_id':name+'__Kref'+str(K)+'__continuous_euclidean_init','source_instance_id':name,'problem_definition':'derived fixed K_ref slots, at most K_ref nonempty routes; continuous Euclidean initialization feasibility diagnostic','capacity':Q,'K':K,'K_basis':'independently validated public reference nonempty route count','distance_convention':'continuous_euclidean (unchanged initializer); original benchmark declares EUC_2D rounded per edge','demands':[d[i] for i in range(1,n+2)],'coordinates':[xy[i] for i in range(1,n+2)],'node_mapping':{'depot_source_id':1,'normalized_depot':0,'source_id_equals_normalized_plus':1},'source_instance_sha256':sha(ip),'source_reference_sha256':sha(sp)}
  witness={'source_instance_id':name,'normalized_customer_routes':routes,'vrp_node_routes':vrp_routes,'source_depot':1,'normalized_depot':0,'loads':loads,'K_ref':K,'reference_reported_cost':claimed,'independently_recomputed_EUC_2D_cost':rounded,'independently_recomputed_continuous_euclidean_cost':continuous,'reference_feasible':True,'source_solution_sha256':sha(sp),'not_available_to_future_solver':True}
  write(f'normalized/{name}.json',raw);write(f'witness/{name}.json',witness)
  normfp=hashlib.sha256(json.dumps([K,Q,sorted(ds)],separators=(',',':')).encode()).hexdigest();geomfp=hashlib.sha256(json.dumps([raw['coordinates'],raw['demands']],separators=(',',':')).encode()).hexdigest()
  normalized_fingerprints[normfp].append(name);geometry_demand_fingerprints[geomfp].append(name)
  rec.update(eligible=True,errors=[],dimension=n+1,n_customers=n,Q=Q,K_ref=K,filename_k_label=slot['filename_k'],filename_k_equals_K_ref=slot['filename_k']==K,node_ids=list(range(1,n+2)),depot_ids=dep,zero_demand_customers=sum(x==0 for x in ds),all_customers_positive=all(x>0 for x in ds),nonnegative_demands=True,max_demand=max(ds),min_positive_demand=m,total_demand=D,slack_U=U,dead_capacity_upper_K_times_m_minus_1=Wmax,theoretically_never_triggers_under_fixed_descending_order=no_trigger,static_test_is_not_solver_performance=True,reference_route_loads=loads,reference_route_residuals=[Q-l for l in loads],reference_coverage_exact_once=True,reference_capacity_valid=True,reference_route_count=K,reference_cost_claimed=claimed,reference_cost_EUC_2D_recomputed=rounded,reference_cost_continuous_recomputed=continuous,source_instance_bytes=ip.stat().st_size,source_instance_sha256=sha(ip),source_reference_bytes=sp.stat().st_size,source_reference_sha256=sha(sp),demand_mean=statistics.mean(ds),demand_stddev_population=statistics.pstdev(ds),demand_cv=statistics.pstdev(ds)/statistics.mean(ds),distinct_demand_count=len(set(ds)),demand_multiset_hash=normfp,geometry_demands_hash=geomfp,normalized_input_sha256=sha(R/'normalized'/f'{name}.json'))
 except Exception as e:rec.update(eligible=False,errors=[type(e).__name__+': '+str(e)])
 out.append(rec)
write('reports/INDEPENDENT_ARITHMETIC_CHECKS.json',out)
write('reports/PANEL_SUMMARY.json',{'selected_slots':len(out),'eligible':sum(x['eligible'] for x in out),'ineligible':sum(not x['eligible'] for x in out),'all_eligible_theoretically_nontriggering':all(x.get('theoretically_never_triggers_under_fixed_descending_order',False) for x in out if x['eligible']),'nontriggering_count':sum(x.get('theoretically_never_triggers_under_fixed_descending_order',False) for x in out),'duplicate_K_Q_demand_multisets':[v for v in normalized_fingerprints.values() if len(v)>1],'duplicate_geometry_and_demands':[v for v in geometry_demand_fingerprints.values() if len(v)>1],'solver_calls':0,'local_search_calls':0,'model_calls':0,'verification_scope':'parsing, arithmetic, coverage, capacity, reference cost, static upper bound only'})
for x in out:print(x['name'],x.get('eligible'),x.get('K_ref'),x.get('Q'),x.get('min_positive_demand'),x.get('dead_capacity_upper_K_times_m_minus_1'),x.get('slack_U'),x.get('theoretically_never_triggers_under_fixed_descending_order'),x['errors'])
