"""Independent arithmetic-only post-execution audit.
Never imports or runs submitted code, candidates, solvers, or a search procedure.
"""
import ast, collections, csv, datetime, hashlib, json, math
from pathlib import Path

ROOT = Path('/workspace/shared/public_capacity_benchmark_execution_20261008_r1')
PREP = Path('/workspace/shared/public_capacity_benchmark_preparation_20261008')
ORIGIN = Path('/workspace/shared/capacity_cross_structure_reproduction_20261008_r1')
OUT = Path(__file__).resolve().parent
ARMS = ('capacity_solver','pruned_solver','waste_solver')
ENDPOINTS = ('partition_256','initialize_256')
errors = []
def require(cond, label):
    if not cond: errors.append(label)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p): return json.loads(p.read_text())
def save(name, data): (OUT/name).write_text(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def close(a,b): return math.isclose(a,b,rel_tol=1e-10,abs_tol=1e-8)
def snapshot(): return {str(p.relative_to(ROOT)):sha(p) for base in ('source','input','raw','freeze','provenance') for p in (ROOT/base).rglob('*') if p.is_file()}

def arithmetic(raw, groups=None, output=None):
    """Coverage, capacity and continuous distance, with no construction/search."""
    issues=[]; n=len(raw['demands'])-1; costs=[]; cost=None
    if output is not None:
        if type(output) is not dict or type(output.get('routes')) is not list:
            return {'accepted':False,'errors':['route container']}
        groups=[]
        for route in output['routes']:
            if type(route) is not list or len(route)<3 or any(type(j) is not int or j<0 or j>n for j in route):
                issues.append('route node/type/shape');continue
            if route[0] != 0 or route[-1] != 0 or 0 in route[1:-1]: issues.append('depot convention')
            groups.append(route[1:-1])
            for a,b in zip(route,route[1:]):
                xa,ya=raw['coordinates'][a];xb,yb=raw['coordinates'][b]
                costs.append(math.sqrt((xa-xb)**2+(ya-yb)**2))
        cost=math.fsum(costs); claimed=output.get('reported_cost')
        if type(claimed) not in (int,float) or not math.isfinite(claimed) or not close(claimed,cost):issues.append('continuous cost')
    if type(groups) is not list: return {'accepted':False,'errors':['group container']}
    flat=[];loads=[]
    for group in groups:
        if type(group) is not list or not group or any(type(x) is not int or not 1<=x<=n for x in group):
            issues.append('group node/type/shape');continue
        flat.extend(group);loads.append(sum(raw['demands'][j] for j in group))
    if sorted(flat)!=list(range(1,n+1)):issues.append('exact once coverage')
    if len(groups)>raw['K']:issues.append('fleet cap')
    if any(l<0 or l>raw['capacity'] for l in loads):issues.append('capacity')
    return {'accepted':not issues,'errors':issues,'loads':loads,'n_routes':len(groups),'continuous_cost':cost}

def diagnostic(raw, d, arm, cid, groups=None):
    n=len(raw['demands'])-1;K=raw['K'];Q=raw['capacity'];demands=raw['demands'];slack=K*Q-sum(demands)
    require(type(d) is dict,cid+' diagnostic present')
    if type(d) is not dict:return
    nodes=d.get('nodes'); require(type(nodes) is int and 1<=nodes<=256,cid+' nodes within bound')
    require(d.get('node_limit')==256,cid+' node limit exact')
    require(d.get('mathematical_infeasibility_claim') is False,cid+' no infeasibility claim')
    outcome=d.get('outcome'); found=outcome=='FOUND'
    require(outcome in ('FOUND','NODE_LIMIT','SEARCH_EXHAUSTED'),cid+' diagnostic outcome')
    require(bool(d.get('limit_reached'))==(outcome=='NODE_LIMIT'),cid+' limit outcome consistent')
    if outcome=='NODE_LIMIT':require(nodes==256,cid+' node limit consumes 256 nodes')
    if found:require(nodes>=n+1,cid+' successful path at least n+1 states')
    if groups is not None:require(found,cid+' groups require FOUND')
    if arm=='capacity_solver':return
    trace=d.get('prune_trace'); require(type(trace) is list,cid+' prune trace list')
    if type(trace) is not list:return
    require(d.get('prunes')==len(trace),cid+' prune count agrees trace length')
    require(d.get('guard_checks')==nodes-int(found),cid+' guards per nonterminal entered node')
    if arm=='pruned_solver':
        require(d.get('prunes')==0 and d.get('tight_checks')==0 and d.get('residual_checks')==0,cid+' full-tight impossible with positive slack')
    else:
        require(d.get('waste_checks')==d.get('guard_checks'),cid+' all positive demands scanned')
        require(d.get('residual_checks')==K*d.get('waste_checks'),cid+' residual scanning count')
        if slack>=K*(min(demands[1:])-1):require(d.get('prunes')==0,cid+' static nontrigger stratum')
    order=sorted(range(1,n+1),key=lambda j:(-demands[j],j)); prior=0
    for i,t in enumerate(trace):
        tag=f'{cid} prune {i}'
        depth=t.get('depth');state=t.get('entered_node');g=t.get('groups');residual=t.get('residual');rem=t.get('remaining')
        require(type(state) is int and prior<state<=nodes,tag+' entered node order'); prior=state
        require(type(depth) is int and 0<=depth<n,tag+' depth')
        if type(depth) is not int or not 0<=depth<n:continue
        require(type(g) is list and len(g)==K,tag+' K bins')
        if type(g) is not list or len(g)!=K:continue
        placed=[j for x in g for j in x]
        require(sorted(placed)==sorted(order[:depth]),tag+' assigned prefix exactly once')
        require(rem==[demands[j] for j in order[depth:]],tag+' remaining demands')
        derived=[Q-sum(demands[j] for j in x) for x in g]
        require(residual==derived and all(x>=0 for x in derived),tag+' residual recomputed')
        require(sum(derived)-sum(rem)==slack,tag+' conserved global slack')
        m=min(x for x in rem if x>0);waste=sum(x for x in derived if 0<x<m)
        require(waste>slack,tag+' necessary obstruction verified')

def main():
    before=snapshot(); freeze=read(ROOT/'freeze/PRE_RUN_FREEZE.json'); schedule=read(ROOT/'freeze/SCHEDULE.json')
    require(not (ROOT/'raw/ABORTED.json').exists(),'no ABORTED marker')
    for f in freeze['files']:
        p=ROOT/f['path'];require(p.is_file() and p.stat().st_size==f['bytes'] and sha(p)==f['sha256'],'frozen file '+f['path'])
    fields=('instance_id','arm','endpoint','node_limit')
    prior=read(PREP/'freeze/PROPOSED_SCHEDULE_NOT_EXECUTED.json')
    require([[i[k] for k in fields] for i in schedule]==[[i[k] for k in fields] for i in prior],'schedule original order exact')
    require(len(schedule)==96 and len({(x['instance_id'],x['arm'],x['endpoint']) for x in schedule})==96,'96 unique planned triples')
    require([x['call_id'] for x in schedule]==[f'C{i:03}' for i in range(1,97)],'call ID order')
    inputs={}; input_checks=[]; coords=set()
    for p in sorted((ROOT/'input').glob('*.json')):
        raw=read(p);normalized=read(PREP/'normalized'/p.name);inputs[p.stem]=raw
        require(set(raw)=={'instance_id','demands','coordinates','capacity','K'},p.stem+' minimal input keys')
        require(raw['instance_id']==normalized['source_instance_id'],p.stem+' source ID')
        require(all(raw[k]==normalized[k] for k in ('demands','coordinates','capacity','K')),p.stem+' original numerical fields')
        require(all(type(x) is int and x>0 for x in raw['demands'][1:]),p.stem+' positive integer demands')
        coords.add(json.dumps([raw['coordinates'],raw['demands']],sort_keys=True))
        input_checks.append({'instance_id':p.stem,'input_sha256':sha(p),'n_customers':len(raw['demands'])-1,'K':raw['K'],'Q':raw['capacity'],'U':raw['K']*raw['capacity']-sum(raw['demands']),'K_min_demand_minus_one':raw['K']*(min(raw['demands'][1:])-1)})
    require(len(inputs)==16 and len(coords)==14,'16 tasks / 14 coordinate-demand bases')
    copied=[]
    for f in sorted((ROOT/'source').rglob('*.py')):
        ast.parse(f.read_text());rel=f.relative_to(ROOT)
        if f.name not in ('run.py','call_once.py','independent_check.py','analyze.py'):
            require(f.read_bytes()==(ORIGIN/rel).read_bytes(),'unchanged source '+str(rel));copied.append(str(rel))
    started=read(ROOT/'raw/STARTED.json');finished=read(ROOT/'raw/FINISHED.json');gate=read(ROOT/'freeze/PRIVATE_SNAPSHOT_VERIFIED.json')
    require(started['freeze_sha256']==sha(ROOT/'freeze/PRE_RUN_FREEZE.json'),'started freeze digest')
    require(gate.get('download_sha256_matches') is True,'snapshot readback gate true')
    require(started.get('snapshot_gate')==gate,'started gate copy')
    require(finished['results_sha256']==sha(ROOT/'raw/results.jsonl'),'sealed result digest')
    records=[json.loads(l) for l in (ROOT/'raw/results.jsonl').read_text().splitlines()]
    require(len(records)==96 and finished['calls']==96,'96 observed results')
    require(len(list((ROOT/'raw/calls').glob('*.stdout')))==96 and len(list((ROOT/'raw/calls').glob('*.stderr')))==96,'exactly 96 stdout/stderr pairs')
    call_checks=[];by={};stats=collections.Counter();table=[]
    for item,r in zip(schedule,records):
        cid=item['call_id'];tag=cid+' '+item['instance_id']+' '+item['arm']+' '+item['endpoint'];raw=inputs[item['instance_id']]
        require(all(r.get(k)==v for k,v in item.items()),tag+' exact schedule record')
        stdout=ROOT/'raw/calls'/f'{cid}.stdout';stderr=ROOT/'raw/calls'/f'{cid}.stderr'
        require(sha(stdout)==r['stdout_sha256'] and sha(stderr)==r['stderr_sha256'],tag+' raw stream hashes')
        require(r['input_sha256']==sha(ROOT/'input'/f"{item['instance_id']}.json"),tag+' input digest')
        if r['process_returncode']==0:
            payload=read(stdout);require(all(r.get(k)==v for k,v in payload.items()),tag+' original stdout preserved in result')
        require(r.get('reference_access_denied_paths')==[],tag+' no denied reference reads')
        require(r.get('solver_witness_or_BKS_reads')==0 and r.get('local_search_calls')==0,tag+' no witness or local search calls')
        require(all(x.startswith('source/') or x==f"input/{item['instance_id']}.json" for x in r.get('local_files_read',[])),tag+' observed local read scope')
        legal=None
        if r['status']=='SUCCESS':
            legal=arithmetic(raw,r.get('groups'),r.get('output'));require(legal['accepted'],tag+' independent arithmetic acceptance')
            check=r.get('independent_check') or {};require(check.get('accepted') is True,tag+' runner checker accepted')
            require(check.get('loads')==legal['loads'] and check.get('n_routes')==legal['n_routes'],tag+' checker details agree')
            if legal['continuous_cost'] is not None:require(close(check['continuous_cost'],legal['continuous_cost']),tag+' checker cost agrees')
        d=r.get('diagnostic') or {};part=d if item['endpoint']=='partition_256' else d.get('capacity_partition')
        if part is not None: diagnostic(raw,part,item['arm'],tag,r.get('groups') if item['endpoint']=='partition_256' else part.get('groups'))
        n=len(raw['demands'])-1
        if item['endpoint']=='initialize_256' and r['status']=='SUCCESS':
            savings=d.get('savings_routes');scheck=arithmetic({**raw,'K':max(raw['K'],len(savings))},savings)
            require(scheck['accepted'],tag+' savings coverage/capacity')
            require(d.get('savings_route_count')==len(savings),tag+' savings route count')
            require(d.get('fallback_triggered')==(len(savings)>raw['K']),tag+' fallback trigger')
            require((part is not None)==('original_ffd_failure' in d),tag+' DFS only following FFD failure')
            budget=r.get('budget') or {};require(budget.get('matrix_distances')==(n+1)**2,tag+' full matrix arithmetic ledger')
            require(budget.get('objective_edges')==n+legal['n_routes'],tag+' objective edge ledger')
            require(budget.get('deltas',10**9)<=100000,tag+' delta budget')
            require(budget.get('delta_by_kind',{}).get('savings')==n*(n-1)//2,tag+' savings pair ledger')
            require(budget.get('delta_by_kind',{}).get('removal')==0,tag+' no removal ledger')
        stats[(item['endpoint'],item['arm'],r['status'])]+=1
        by[(item['instance_id'],item['endpoint'],item['arm'])]=r
        call_checks.append({'call_id':cid,'instance_id':item['instance_id'],'arm':item['arm'],'endpoint':item['endpoint'],'status':r['status'],'independent_arithmetic':legal,'observed_DFS':part is not None,'nodes':part.get('nodes') if part else None,'prunes':part.get('prunes',0) if part else None,'reported_whole_process_cpu_seconds':r['process_cpu_seconds'],'reported_child_self_maxrss_KiB':r.get('child_self_maxrss_KiB')})
        table.append({k:r.get(k) for k in ('call_id','instance_id','arm','endpoint','status','process_cpu_seconds','process_wall_seconds','measured_cpu_ns','measured_wall_ns','parse_cpu_ns','parse_wall_ns','import_cpu_ns','matrix_cpu_ns','matrix_wall_ns','checker_cpu_ns','checker_wall_ns','child_self_maxrss_KiB')})
    paired=[];paired_summary=[]
    for endpoint in ENDPOINTS:
        for arm in ARMS[1:]:
            counts=collections.Counter()
            for name in inputs:
                b=by[(name,endpoint,ARMS[0])];c=by[(name,endpoint,arm)];bs=b['status']=='SUCCESS';cs=c['status']=='SUCCESS'
                cat='both_success' if bs and cs else 'both_failure' if not bs and not cs else 'rescued' if cs else 'lost';counts[cat]+=1
                bd=b['diagnostic'] if endpoint=='partition_256' else (b.get('diagnostic') or {}).get('capacity_partition');cd=c['diagnostic'] if endpoint=='partition_256' else (c.get('diagnostic') or {}).get('capacity_partition')
                same=b.get('groups')==c.get('groups') and b.get('output')==c.get('output')
                if name!='P-n23-k8' or arm=='pruned_solver':
                    require(same,f'{name} {endpoint} {arm} control output identical')
                    require((bd or {}).get('nodes')==(cd or {}).get('nodes'),f'{name} {endpoint} {arm} control nodes identical')
                paired.append({'instance_id':name,'endpoint':endpoint,'arm':arm,'category':cat,'output_identical':same,'baseline_nodes':(bd or {}).get('nodes'),'arm_nodes':(cd or {}).get('nodes'),'baseline_DFS_reached':bd is not None,'arm_DFS_reached':cd is not None,'arm_prunes':(cd or {}).get('prunes',0),'solver_cpu_delta_ns':c['measured_cpu_ns']-b['measured_cpu_ns'],'whole_process_cpu_delta_seconds':c['process_cpu_seconds']-b['process_cpu_seconds']})
            paired_summary.append({'endpoint':endpoint,'arm':arm,**{k:counts[k] for k in ('both_success','both_failure','rescued','lost')}})
    child=math.fsum(r['process_cpu_seconds'] for r in records);delta=finished['children_cpu_final_absolute']-finished['children_cpu_initial'];total=child+finished['parent_cpu_seconds']
    require(close(child,delta) and close(child,finished['children_cpu_seconds']) and close(child,finished['sum_per_call_child_cpu']),'child CPU differences sum exactly once')
    require(total<=120 and finished['wall_seconds']<=240,'total execution CPU/wall cap')
    require(all(0<=r['process_cpu_seconds']<=1.05 and 0<=r['process_wall_seconds']<=2.05 for r in records),'per-call observed CPU/wall limits with 50ms accounting tolerance')
    require(all(r.get('child_self_maxrss_KiB',0)<=256*1024 for r in records),'child observed RSS below memory bound')
    require(finished.get('no_reruns') is True,'finished no-reruns flag')
    after=snapshot();require(before==after,'audit did not alter execution source/raw materials')
    summary={'audit_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verdict':'PASS_WITH_SCOPE_LIMITS' if not errors else 'FAIL','errors':errors,'audit_mode':'arithmetic and static source/log consistency only; no solver imports, runs, or search','freeze_revision':freeze.get('revision'),'freeze_sha256':sha(ROOT/'freeze/PRE_RUN_FREEZE.json'),'freeze_files_verified':len(freeze['files']),'results_sha256':sha(ROOT/'raw/results.jsonl'),'original_source_files_identical':copied,'schedule_matches_preparation':True,'input_checks':input_checks,'coordinate_demand_bases':len(coords),'status_counts':[{'endpoint':e,'arm':a,'status':s,'count':v} for (e,a,s),v in sorted(stats.items())],'paired_counts':paired_summary,'cpu_accounting':{'sum_per_call_child_seconds':child,'end_minus_start_children_seconds':delta,'parent_delta_seconds':finished['parent_cpu_seconds'],'total_seconds':total,'wall_seconds':finished['wall_seconds'],'cumulative_children_final_not_added_again':True},'private_snapshot_gate':gate,'started_utc':started['utc'],'finished_utc':finished['utc'],'raw_and_source_unchanged_during_audit':before==after,'scope_limits':['No full entered-node trajectory was recorded. Nodes/guards are source-reviewed and diagnostic-consistency checked, not independently re-executed. Every recorded prune state is independently arithmetically checked.','Exactly-once applies to this frozen run: unique schedule, exclusive creation of raw output and 96 preserved stream pairs. Logs cannot prove that no unrecorded execution occurred elsewhere.','Python file audit hook plus static frozen-source inspection supports no reference access; it is not an operating-system security sandbox.','One deterministic call per cell supports functional counts and descriptive timing only, not stable speed rankings or statistical population claims.','16 public-derived K/Q tasks have 14 coordinate-demand bases; convenience sample and shared geometry do not establish statistical independence.','Continuous Euclidean output costs are not original EUC_2D benchmark optimality gaps.','Configured address-space limits are parent768MiB and child256MiB after child startup. There is no cgroup aggregate-memory high-water measurement; the parent own peak RSS is not recorded. Per-call child_self_maxrss is distinct from the parent cumulative children_maxrss. These observations must not be described as a direct aggregate peak-RSS measurement.'],'call_checks':call_checks,'paired_details':paired,'input_source_snapshot':before}
    save('INDEPENDENT_EXECUTION_AUDIT.json',summary)
    with (OUT/'PER_CALL_ARITHMETIC_AND_TIMING.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(table[0]));w.writeheader();w.writerows(table)
    save('PAIRED_COUNTS_AND_DIAGNOSTICS.json',paired)
    print(json.dumps({'verdict':summary['verdict'],'errors':errors,'status_counts':summary['status_counts'],'paired_counts':paired_summary,'cpu_accounting':summary['cpu_accounting'],'p23':[x for x in call_checks if x['instance_id']=='P-n23-k8']},ensure_ascii=False,indent=2))
    if errors: raise SystemExit(1)
if __name__=='__main__':main()
