"""Cross-check executor's derived summaries against original records, no solver."""
import json,csv,hashlib,math
from pathlib import Path
R=Path('/workspace/shared/public_capacity_benchmark_execution_20261008_r1');O=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text())
rows=[json.loads(l) for l in (R/'raw/results.jsonl').read_text().splitlines()]
s=load(R/'reports/SUMMARY.json');pairs=load(R/'reports/PAIRED.json');m=list(csv.DictReader((R/'reports/METRICS.csv').open()))
assert len(m)==96
for a,b in zip(rows,m):
 for k in ('call_id','instance_id','arm','endpoint','status'):assert a[k]==b[k]
 for k in ('process_cpu_seconds','process_wall_seconds'):assert float(b[k])==a[k]
 for akey,bkey in [('measured_cpu_ns','endpoint_cpu_ns'),('measured_wall_ns','endpoint_wall_ns'),('parse_cpu_ns','parse_cpu_ns'),('import_cpu_ns','import_cpu_ns'),('checker_cpu_ns','checker_cpu_ns'),('child_self_maxrss_KiB','child_own_peak_RSS_KiB')]:assert int(b[bkey])==a[akey]
for ep in ('partition_256','initialize_256'):
 for arm in ('capacity_solver','pruned_solver','waste_solver'):
  rr=[r for r in rows if r['endpoint']==ep and r['arm']==arm];d=[r['diagnostic'] if ep=='partition_256' else r['diagnostic'].get('capacity_partition') for r in rr];ds=[x for x in d if x is not None];x=s[ep][arm]
  checks={'calls':len(rr),'successes':sum(r['status']=='SUCCESS' for r in rr),'dfs_entered':len(ds),'nodes':sum(y['nodes'] for y in ds),'prunes':sum(y.get('prunes',0) for y in ds),'ffd_fallbacks':sum(r['diagnostic'].get('fallback_triggered',False) for r in rr),'deltas':sum((r.get('budget') or {}).get('deltas',0) for r in rr),'endpoint_cpu_ns_total':sum(r['measured_cpu_ns'] for r in rr),'endpoint_wall_ns_total':sum(r['measured_wall_ns'] for r in rr),'endpoint_cpu_zero_observations':sum(r['measured_cpu_ns']==0 for r in rr),'process_cpu_seconds_sum':math.fsum(r['process_cpu_seconds'] for r in rr),'own_peak_RSS_KiB':max(r['child_self_maxrss_KiB'] for r in rr)}
  for k,v in checks.items():assert x[k]==v,(ep,arm,k)
assert len(pairs)==32 and len({(p['instance_id'],p['endpoint']) for p in pairs})==32
for p in pairs:
 rr=[r for r in rows if r['instance_id']==p['instance_id'] and r['endpoint']==p['endpoint']]
 assert len(rr)==3
 for k in ('statuses_equal','all_success','groups_equal','outputs_equal','nodes_equal'):assert p[k] is True
 assert p['waste_rescue'] is False and p['waste_loss'] is False
 assert p['direct_first_branch_without_backtracking']==(p['endpoint']=='partition_256')
f=load(R/'raw/FINISHED.json');assert math.isclose(s['overall']['total_attributable_cpu_seconds'],math.fsum(r['process_cpu_seconds'] for r in rows)+f['parent_cpu_seconds'],abs_tol=1e-10)
result={'verdict':'PASS','summary_six_cells_recomputed':True,'metrics_96_identity_and_timing_rows_recomputed':True,'paired_32_three_arm_groups_agree':True,'whole_process_cpu_checked_without_double_counting':True,'analyze_script_reviewed_read_only_and_not_imported':True,'derived_report_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (R/'reports').iterdir() if p.is_file() and p.name in ('SUMMARY.json','PAIRED.json','METRICS.csv','ANALYSIS_CHECKS.json','REPORT_ZH.txt')},'note':'The no-backtracking statement is consistent with reported n+1 entered nodes and frozen code; it is not an independent replay of a full node trace.'}
(O/'REPORT_CONSISTENCY_AUDIT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2))
