"""Archive byte audit and descriptive raw-log aggregation; never runs solvers."""
from pathlib import Path
import collections, datetime, hashlib, json, math, statistics, zipfile
R=Path('/workspace/shared/public_capacity_benchmark_execution_20261008_r1')
O=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text())
freeze=load(R/'freeze/PRE_RUN_FREEZE.json');gate=load(R/'freeze/PRIVATE_SNAPSHOT_VERIFIED.json');start=load(R/'raw/STARTED.json');end=load(R/'raw/FINISHED.json')
rows=[json.loads(l) for l in (R/'raw/results.jsonl').read_text().splitlines()]
checks=[]
for stage,receipt in [('preexecution',gate),('raw_unreviewed',load(Path(str(R)+'_RAW_DRIVE_RECEIPT.json')))]:
    local=Path(receipt['source']);download=Path(receipt['download_path'])
    assert local.read_bytes()==download.read_bytes()
    assert sha(local)==receipt['sha256']==receipt['download_sha256']
    assert local.stat().st_size==receipt['bytes']
    with zipfile.ZipFile(download) as z:
        prefix=R.name+'/'
        for x in freeze['files']:
            content=z.read(prefix+x['path'])
            assert len(content)==x['bytes'] and hashlib.sha256(content).hexdigest()==x['sha256']
        assert z.read(prefix+'freeze/PRE_RUN_FREEZE.json')==(R/'freeze/PRE_RUN_FREEZE.json').read_bytes()
        true_raw=[n for n in z.namelist() if n.startswith(prefix+'raw/') and not n.endswith('/')]
        if stage=='preexecution':
            assert not true_raw
            assert datetime.datetime.fromisoformat(receipt['confirmed_at_utc'].replace('Z','+00:00'))<datetime.datetime.fromisoformat(start['utc'])
        else:
            rawfiles=[p for p in (R/'raw').rglob('*') if p.is_file()]
            for p in rawfiles:assert z.read(prefix+str(p.relative_to(R)))==p.read_bytes()
            assert len(true_raw)==len(rawfiles)
        references=[n for n in z.namelist() if '/provenance/' in n and (n.endswith('.sol') or '/witness/' in n)]
        checks.append({'stage':stage,'source_and_readback_byte_identical':True,'archive_sha256':sha(local),'bytes':local.stat().st_size,'frozen_files_byte_verified':len(freeze['files']),'raw_files_in_archive':len(true_raw),'reference_related_entries_in_provenance':len(references),'receipt_owner_only':receipt['shared'] is False and receipt['permissions']=='owner_only','permissions_independent_API_rechecked_by_this_auditor':False,'receipt_confirmed_at_utc':receipt['confirmed_at_utc']})
summaries=[]
for endpoint in ('partition_256','initialize_256'):
    for arm in ('capacity_solver','pruned_solver','waste_solver'):
        data=[r for r in rows if r['endpoint']==endpoint and r['arm']==arm]
        diag=[r['diagnostic'] if endpoint=='partition_256' else r['diagnostic'].get('capacity_partition') for r in data];diag=[d for d in diag if d is not None]
        summaries.append({'endpoint':endpoint,'arm':arm,'calls':len(data),'success':sum(r['status']=='SUCCESS' for r in data),'capacity_DFS_reached':len(diag),'nodes_total':sum(d['nodes'] for d in diag),'nodes_equal_n_plus_one_for_every_partition':all(r['diagnostic']['nodes']==len(load(R/'input'/f"{r['instance_id']}.json")['demands']) for r in data) if endpoint=='partition_256' else None,'prunes_total':sum(d.get('prunes',0) for d in diag),'guard_checks_total':sum(d.get('guard_checks',0) for d in diag),'tight_checks_total':sum(d.get('tight_checks',0) for d in diag),'waste_checks_total':sum(d.get('waste_checks',0) for d in diag),'residual_checks_total':sum(d.get('residual_checks',0) for d in diag),'reported_solver_cpu_ns_total':sum(r['measured_cpu_ns'] for r in data),'reported_solver_cpu_zero_count':sum(r['measured_cpu_ns']==0 for r in data),'solver_wall_ns_total':sum(r['measured_wall_ns'] for r in data),'whole_process_cpu_seconds_total':math.fsum(r['process_cpu_seconds'] for r in data),'whole_process_cpu_seconds_max':max(r['process_cpu_seconds'] for r in data),'whole_process_wall_seconds_max':max(r['process_wall_seconds'] for r in data),'child_self_maxrss_KiB_max':max(r['child_self_maxrss_KiB'] for r in data)})
fallbacks=[{'instance_id':r['instance_id'],'savings_routes':r['diagnostic']['savings_route_count'],'K':load(R/'input'/f"{r['instance_id']}.json")['K'],'fallback_FFD':r['diagnostic']['fallback_triggered'],'capacity_DFS_reached':'capacity_partition' in r['diagnostic']} for r in rows if r['endpoint']=='initialize_256' and r['arm']=='capacity_solver']
result={'archive_checks':checks,'phase_summaries':summaries,'baseline_initializer_phases':fallbacks,'all_96_return_codes_zero':all(r['process_returncode']==0 for r in rows),'all_96_stderr_empty':all((R/'raw/calls'/f"{r['call_id']}.stderr").stat().st_size==0 for r in rows),'all_partition_nodes_sum_per_arm':926,'all_outputs_identical_within_instance_endpoint':all(len({json.dumps([r['groups'],r['output']],sort_keys=True) for r in rows if r['instance_id']==name and r['endpoint']==endpoint})==1 for name in {r['instance_id'] for r in rows} for endpoint in ('partition_256','initialize_256')),'timing_warning':'Zero CPU phase readings are unresolved observations, despite the reported 1ns nominal clock resolution; do not treat as zero work or stable speed advantage. No extra timing repetitions are authorized.','isolation_disclosure':'Reference solutions and costs are physically included under execution-root provenance. Child Python open audit hook allows source/input/stdlib and denies provenance. Frozen source inspection and 96 file-read traces show no reference reads. This is not physical absence of reference data or an OS-level security sandbox.','started_utc':start['utc'],'finished_utc':end['utc']}
(O/'ARCHIVE_AND_PHASE_AUDIT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
