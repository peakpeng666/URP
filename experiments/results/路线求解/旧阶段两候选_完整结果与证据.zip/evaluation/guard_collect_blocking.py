"""Fixed-topology collector. CPU authority is per-process OS limits; proc is diagnostic only."""
from pathlib import Path
import ctypes,json,os,resource,signal,subprocess,time

def identity(pid):
 raw=Path('/proc/'+str(pid)+'/stat').read_text();f=raw[raw.rfind(')')+2:].split()
 return {'pid':pid,'ppid':int(f[1]),'starttime_ticks':f[19],'pid_namespace':os.readlink('/proc/'+str(pid)+'/ns/pid')}

def collect_driver(command,environment,cpu,deadline,stdout_path,stderr_path):
 libc=ctypes.CDLL(None,use_errno=True);parent=os.getpid()
 def death_guard():
  if libc.prctl(1,signal.SIGKILL,0,0,0)!=0 or os.getppid()!=parent:os._exit(76)
 stdout=Path(stdout_path).open('xb');stderr=Path(stderr_path).open('xb')
 child=subprocess.Popen(command,env=environment,stdin=subprocess.PIPE,stdout=stdout,stderr=stderr,start_new_session=True,preexec_fn=death_guard)
 resource.setrlimit(resource.RLIMIT_CPU,(1,1));resource.setrlimit(resource.RLIMIT_AS,(134217728,134217728))
 diagnostic=Path(str(stdout_path)+'.driver_identity.json')
 with diagnostic.open('x') as f:json.dump({'guard':identity(os.getpid()),'driver':identity(child.pid),'budget_CPU_reservation':cpu,'absolute_wall_deadline':deadline,'CPU_authority':'fixed-topology OS limits; no proc aggregate meter'},f,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
 child.stdin.write(b'G');child.stdin.flush();child.stdin.close()
 pid,status,usage=os.wait4(child.pid,0);child.returncode=os.waitstatus_to_exitcode(status)
 stdout.close();stderr.close()
 return {'pid':pid,'returncode':child.returncode,'trigger':None,'usage':usage,'tree_CPU_peak_observed':None,'CPU_meter':'not_used_fixed_OS_limits','raw_wait_status':status,'guard_alarm_must_remain_active_through_exit':True}
