# EoH heuristic (mutated): expected-waste minimization for Weibull(3, 45)
# streams, capacity 100.  Placing item s into a bin with residual r leaves
# gap g = r - s.  An open gap x is charged its expected final waste
#     c(x) = x*exp(-lam) + W*(1 - exp(-lam)),   lam = N*F(x),
# where F is the Weibull(3, 45) CDF, N = 500 expected future items and
# W = 2.5 is the typical terminal waste of a gap that does get reused.
# Bins are scored by the waste they remove, c(r) - c(g): perfect fits (g=0)
# and near-perfect fits (g=1,2) are rewarded, dead gaps (g ~ 3..9) are
# avoided, a density-shaped bonus keeps reusable gaps near the item mode
# (~39-45), and fresh bins are opened only when they beat every gap.

def score(item, bins):
    r = np.asarray(bins, dtype=np.float64)      # feasible residual capacities
    s = float(item)                             # current item size
    g = r - s                                   # leftover after placement

    def cost(x):                                # expected final waste of gap x
        lam = 500.0 * (1.0 - np.exp(-(x / 45.0) ** 3))
        surv = np.exp(-lam)                     # P(no future item fits gap x)
        return x * surv + 2.5 * (1.0 - surv)

    # waste removed by this placement: perfect fit dominates, dead gaps penalized
    scores = cost(r) - cost(g)

    # keep reusable leftovers near the mode of the item distribution
    scores = scores + 0.000101 * g * g * np.exp(-(g / 45.0) ** 3)

    # mild preference for existing bins over opening fresh ones
    scores = scores - 0.015 * (r >= 99.5)

    return scores
