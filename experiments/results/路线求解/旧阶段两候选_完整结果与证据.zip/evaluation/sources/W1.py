# Online bin-packing heuristic (mutated EoH parent), capacity 100.
# 1) widened exp(diff/2) cascade: rewards post-placement residuals 0..3,
#    scaled by bin residual -> exact/near-exact closures dominate;
# 2) utilization*sqrt term kept from parent (peak at r ~= 2*item) so bins
#    keep filling actively; +0.8 for placements leaving > 3x item groups
#    small items into fresh/large-residual bins;
# 3) scavenging bonus lures items into doomed small residuals (~8..22)
#    to plug small holes instead of opening new bins.
def score(item, bins):
    diff = bins - item                          # residual after placement
    eh = np.exp(diff * 0.5)                     # slow-decay exponent term
    hybrid_exp = bins / ((eh + 0.7) * eh)       # near-exact fill cascade
    sqrt = np.sqrt(np.maximum(diff, 0.0))       # square-root term
    safe = np.maximum(bins, 1e-9)               # guard against zero residual
    ulti = 1.0 - diff / safe                    # utilization after placement
    comb = ulti * sqrt                          # utilization x sqrt blend
    adjust = np.where(diff > (item * 3), comb + 0.8, comb + 0.3)
    scav = 0.35 * np.exp(-((bins - 13.0) / 10.0) ** 2)  # doomed-hole lure
    scores = hybrid_exp + adjust + scav
    return scores
