import json,hashlib,os
from pathlib import Path
R=Path(__file__).resolve().parent
def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
def sha(b):return hashlib.sha256(b).hexdigest()
def digest(x):return sha(canon(x).encode())
def read(n):return json.loads((R/n).read_text())
def put(n,x):
 with (R/n).open('x') as f:f.write(canon(x)+'\n');f.flush();os.fsync(f.fileno())
 fd=os.open((R/n).parent,os.O_RDONLY|os.O_DIRECTORY);os.fsync(fd);os.close(fd)
