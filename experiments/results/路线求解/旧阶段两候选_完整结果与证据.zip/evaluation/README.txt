PREPARATION ONLY. Explicit root execution release is required; current authorization is false.

This is a distinct, retrospective exploratory evaluation of recovered OLD generation
W1/W2 from the 64000-token/900-second phase. It does not run or complete the frozen
full eight-slot W-vs-M plan, or belong to the new 131072-token/3600-second phase.
The original four attempted generation slots were W1, M1, M2, W2. M1/M2 timed out
without public candidates and remain generation failures. Original W3/M3/M4/W4 were
not attempted. No candidate or failed opportunity is replaced.

CANDIDATES.json binds the original public-response bytes and independently extracted
source. The inherited extraction rule is byte-preserving: entire strict-UTF8 response
if no fence, otherwise exactly one complete empty/python/py fenced block; outside
prose may be omitted. No repairs, dedent, newline normalization, or import changes.
W1's stored response has 2599 bytes and 2561 Unicode characters versus historical
reported 2598 bytes. Character count does not explain the discrepancy. Stored archive
and internal hashes verify; the old collector source is absent and no repair is made.
The retrieval worker previously host-parsed sources; this is disclosed and is not
admission evidence. This stage does not host-parse/import/compile candidate source.

PLAN.json has 12 candidate actions: admission, fixed toy, and four original W training
streams for each candidate, plus one non-scientific integer-replay/analysis action.
There are at most eight scientific packs. Training sequences are exactly original
W1/W2/W3/W4 (1000 integers each, capacity100). Generation-slot labels and training
sequence labels are different identities. No U arrays, confirmation seeds or held-out
arrays are inputs. Frozen baseline result files are replayed, never rerun.

Execution uses the old verified bounded runtime by reference, unchanged; all its
current files are hash-bound. Candidate AST checks/compilation happen only in its
bounded child after launch gates. The unchanged integer checker and final independent
replay validate every assignment. Known failures preserve downstream ineligible
receipts; infrastructure uncertainty halts the stage with durable consumed claims.
No retries, replacements, source changes, new generation, or model/network calls.

Reserve 1250 CPU seconds and 1018 active-wall seconds; schedule ceilings 1350/1150.
Candidate actions reserve1050 CPU/778wall; analysis30CPU/40wall; other overhead170/200.
Preparation exact-complete usage is unmeasured, so all-in actual fields remain null.
No old budget is transferred. Driver wait4 includes reaped descendants and is counted
once; nested worker/supervisor receipts are diagnostics, not additional CPU charges.
Guard1CPU; driver2CPU soft/200 hard permits child60CPU; production supervisor60CPU and
worker60CPU; per-pack reserve125CPU. Runtime wall90seconds plus outer margin3seconds.
Memory limits are per process: guard128MiB, driver256MiB soft/512MiB hard, supervisor
and worker512MiB each, fixed-topology hard-limit sum1664MiB. Whole-tree RSS is not measured.

Both candidates remain separate even if duplicate. Report exact Fraction fitness,
same-stream BF/parent differences, original generation failures, duplicates and all
numeric/admission failures. No W-vs-M effect, novelty, significance, independent
confirmation or generalization inference. No finalist selection or confirmation release.

After static review, root may replace EXECUTION_AUTHORIZATION.json with an explicit
release binding SOURCE_FREEZE.json SHA256, CANDIDATES.json SHA256, frozen_subset_terminal
true, and the exact PLAN action ID list. This release is the only mutable control file.
Invoke PLAN's frozen python with -B guard.py ACTION_ID, one action at a time, in order.
Never run driver.py directly, call the old baseline guard, or activate the full evaluator.
Once an action is claimed it is permanently consumed, including uncertain outcomes.
Static checks certify configuration/hash consistency only, not future dynamic success.
