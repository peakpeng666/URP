"""Frozen byte-preserving public-answer extraction; no parsing or execution."""
class FormatFailure(ValueError):
    pass

def extract_source(raw):
    try:
        text=raw.decode('utf-8',errors='strict')
    except UnicodeError as exc:
        raise FormatFailure('invalid UTF-8') from exc
    lines=text.splitlines(keepends=True)
    marks=[]
    for i,line in enumerate(lines):
        marker=line.rstrip('\r\n').strip(' \t')
        if marker.startswith('~~~'):
            raise FormatFailure('unsupported tilde fence')
        if marker.startswith('```'):
            marks.append((i,marker))
    if not marks:
        code=text
    elif len(marks)==2 and marks[0][1] in ('```','```python','```py') and marks[1][1]=='```':
        code=''.join(lines[marks[0][0]+1:marks[1][0]])
    else:
        raise FormatFailure('multiple, incomplete, or unsupported code fences')
    encoded=code.encode('utf-8')
    if not code.strip() or not 0<len(encoded)<=16384:
        raise FormatFailure('empty or oversized source')
    return code
