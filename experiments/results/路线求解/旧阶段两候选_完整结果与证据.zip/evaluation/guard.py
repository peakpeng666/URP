"""Minimal baseline guard adaptation; durable claims, known failures continue, unknown halts."""
import os,sys,json,signal,resource,time,fcntl
from pathlib import Path
sys.dont_write_bytecode=True;os.umask(0o077)
from guard_collect_blocking import collect_driver
from driver_helpers import R,canon,digest,read,put,sha
resource.setrlimit(resource.RLIMIT_CPU,(1,200))
signal.signal(signal.SIGXCPU,signal.SIG_DFL);signal.pthread_sigmask(signal.SIG_UNBLOCK,{signal.SIGXCPU})
assert len(sys.argv)==2;A=sys.argv[1]
lock=(R/'LOCK').open('a+b');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
# Authorization is checked before any candidate read or claim consumption.
auth=read('EXECUTION_AUTHORIZATION.json')
assert auth['execution_authorized'] is True and auth['frozen_subset_terminal'] is True
assert not (R/'HALT.json').exists()
freeze=read('SOURCE_FREEZE.json')
assert sha((R/'SOURCE_FREEZE.json').read_bytes())==auth['source_freeze_sha256']
for name,h in freeze['files'].items():assert sha((R/name).read_bytes())==h,'frozen source drift'
p=read('PLAN.json');actions=p['actions'];ids=[x['id'] for x in actions]
assert A in ids and auth['allowed_action_ids']==ids
assert str(Path(sys.executable).resolve())==p['python_realpath']
assert sha(Path(sys.executable).resolve().read_bytes())==p['python_sha256']
assert sha((R/'CANDIDATES.json').read_bytes())==auth['candidate_manifest_sha256']
registry=read('CANDIDATES.json')
assert registry['frozen_subset_terminal'] is True
assert [x['slot_id'] for x in registry['slots']]==[x['slot_id'] for x in p['slots']]
assert all(x['generation_status'] in ('completed_public_response','known_failure') for x in registry['slots'])
runtime=read('RUNTIME_BINDINGS.json')
assert runtime['path']==p['runtime']
for name,h in runtime['files'].items():assert sha((Path(runtime['path'])/name).read_bytes())==h,'runtime source drift'
# A missing/uncertain terminal stops the whole stage without reclaiming its budget.
known=('passed','candidate_failure','not_run_ineligible')
for path in (R/'claims').glob('*.json'):
    old=json.loads(path.read_text());terminal=R/'results'/path.name
    if not terminal.exists():
        put('HALT.json',{'action':old['action_id'],'status':'unknown_missing_terminal','no_retry':True})
        raise SystemExit(1)
    t=json.loads(terminal.read_text());r=t.get('resources',{})
    if t.get('claim_sha256')!=digest(old) or t.get('status') not in known or not r.get('driver_reaped') or r.get('driver_exit_code')!=0:
        put('HALT.json',{'action':old['action_id'],'status':'unknown_invalid_terminal','no_retry':True})
        raise SystemExit(1)
for earlier in ids[:ids.index(A)]:
    c=read('claims/'+earlier+'.json');t=read('results/'+earlier+'.json')
    assert t['claim_sha256']==digest(c) and t['status'] in known
    assert t['payload_sha256']==sha((R/('payload_'+earlier+'.json')).read_bytes())
assert not (R/'claims'/(A+'.json')).exists(),'claimed slots are permanently consumed'
a=next(x for x in actions if x['id']==A);CPU=a['CPU_reserve'];wall=a['wall_reserve']
claims=[json.loads(x.read_text()) for x in (R/'claims').glob('*.json')]
usedcpu=sum(x['CPU_reserve'] for x in claims);usedwall=sum(x['wall_reserve'] for x in claims)
assert usedcpu+CPU+p['budget']['non_scientific_outside_actions']['CPU']<=p['budget']['caps']['CPU'] and usedwall+wall+p['budget']['non_scientific_outside_actions']['active_wall']<=p['budget']['caps']['active_wall']
claim={'namespace':p['id'],'claim_id':digest([p['id'],A]),'action_id':A,'slot_id':a['slot_id'],'kind':a['kind'],'scientific':a['kind']=='scientific','CPU_reserve':CPU,'wall_reserve':wall,'source_freeze_sha256':auth['source_freeze_sha256'],'candidate_manifest_sha256':auth['candidate_manifest_sha256'],'no_retry':True}
put('claims/'+A+'.json',claim)
started=time.monotonic();signal.signal(signal.SIGALRM,signal.SIG_DFL);signal.setitimer(signal.ITIMER_REAL,wall)
env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1','OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','BLIS_NUM_THREADS':'1','PRECHECK_GUARD_PID':str(os.getpid())}
cmd=['/usr/bin/prlimit','--cpu=2:200','--as=268435456:536870912','--nofile=64:64','--core=0:0','--',sys.executable,'-B',str(R/'driver.py'),A]
c=collect_driver(cmd,env,CPU,started+wall,R/'logs'/f'{A}.stdout',R/'logs'/f'{A}.stderr')
u=c['usage'];actual=u.ru_utime+u.ru_stime;payload=R/('payload_'+A+'.json')
status='infrastructure_unknown'
if c['returncode']==0 and payload.is_file() and actual+1<=CPU and time.monotonic()-started<=wall:
    value=json.loads(payload.read_text())
    if value.get('action_id')==A and value.get('outcome') in known:status=value['outcome']
put('results/'+A+'.json',{'action_id':A,'claim_sha256':digest(claim),'status':status,'payload_sha256':sha(payload.read_bytes()) if payload.exists() else None,'resources':{'driver_reaped':True,'driver_exit_code':c['returncode'],'driver_wait4_inclusive_CPU':actual,'guard_CPU_hard_cap':1,'whole_tree_CPU_conservative_upper':actual+1,'wall_at_emit':time.monotonic()-started,'guard_tail_and_unknown_covered_by_full_reservation':True,'driver_peak_RSS_kib':u.ru_maxrss,'CPU_reserved_cumulative':usedcpu+CPU,'wall_reserved_cumulative':usedwall+wall}})
if status=='infrastructure_unknown':put('HALT.json',{'action':A,'status':status,'no_retry':True,'retain_full_reservation':True})
print(canon({'action':A,'status':status,'driver_CPU':actual,'driver_exit':c['returncode']}))
sys.exit(1 if status=='infrastructure_unknown' else 0)
