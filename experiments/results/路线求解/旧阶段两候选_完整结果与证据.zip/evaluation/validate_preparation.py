"""Pure hash/configuration/byte-extraction checks. No runtime or candidate execution."""
from pathlib import Path
import json, hashlib, sys
sys.dont_write_bytecode=True
from driver_helpers import R, read, sha, digest
from extract_source import extract_source, FormatFailure

def validate():
    plan=read('PLAN.json');registry=read('CANDIDATES.json');bindings=read('INPUT_BINDINGS.json')
    assert read('EXECUTION_AUTHORIZATION.json')['execution_authorized'] is False
    assert not list((R/'claims').glob('*')) and not list((R/'results').glob('*')) and not list((R/'logs').glob('*'))
    assert not (R/'ANALYSIS.json').exists()
    assert plan['id']=='bpp-old-partial-candidate-eval-20261008'
    assert len(plan['slots'])==2 and [s['generation_slot'] for s in plan['slots']]==['W1','W2']
    assert all(s['sequences']==['W1','W2','W3','W4'] for s in plan['slots'])
    assert len(plan['actions'])==13 and sum(a['kind']=='scientific' for a in plan['actions'])==8
    assert all(a['instance_index']==0 for a in plan['actions'] if a['kind']!='analysis')
    assert plan['actions'][-1]['kind']=='analysis'
    ids=[a['id'] for a in plan['actions']];assert len(ids)==len(set(ids))
    claims=read('CLAIM_PLAN.json')['action_claims'];assert [c['action_id'] for c in claims]==ids
    assert all(c['claim_id']==digest([plan['id'],c['action_id']]) and c['claimed'] is False for c in claims)
    budget=plan['budget'];assert sum(a['CPU_reserve'] for a in plan['actions'])+budget['non_scientific_outside_actions']['CPU']==1250==budget['reserved']['CPU']
    assert sum(a['wall_reserve'] for a in plan['actions'])+budget['non_scientific_outside_actions']['active_wall']==1018==budget['reserved']['active_wall']
    assert budget['caps']=={'CPU':1350,'active_wall':1150}
    assert [e['sequence'] for e in bindings['entries']]==['W1','W2','W3','W4']
    for entry in bindings['entries']:
        raw=Path(entry['path']).read_bytes();data=json.loads(raw)
        assert sha(raw)==entry['file_sha256'] and digest(data)==entry['input_sha256']
        assert len(data['items'])==1000 and data['capacity']==100
    for entry in bindings['read_only_baseline_reference_files'].values():assert sha(Path(entry['path']).read_bytes())==entry['sha256']
    runtime=read('RUNTIME_BINDINGS.json');assert runtime['path']==plan['runtime']
    for name,h in runtime['files'].items():assert sha((Path(runtime['path'])/name).read_bytes())==h
    assert sha(Path(plan['python_realpath']).read_bytes())==plan['python_sha256']
    for c in registry['slots']:
        raw=Path(c['raw_path']).read_bytes();assert sha(raw)==c['raw_response_sha256']
        source=extract_source(raw).encode('utf8');assert sha(source)==c['source_sha256'] and source==Path(c['source_path']).read_bytes()
    # Pure data tests target only the trusted extractor, never parse these strings.
    for raw,expected in [(b'def score(x,y):\r\n  return y\r\n',b'def score(x,y):\r\n  return y\r\n'),(b'prose\n```python\n  abc\r\n```\nend',b'  abc\r\n'),(b'```py\nx\n```',b'x\n'),(b'```\nx\n```',b'x\n')]:assert extract_source(raw).encode()==expected
    for raw in [b'',b'```python\nx',b'~~~python\nx\n~~~',b'```js\nx\n```',b'```\nx\n```\n```\ny\n```',b'\xff',b'x'*16385]:
        try:extract_source(raw)
        except FormatFailure:pass
        else:raise AssertionError('invalid extraction accepted')
    for f in R.glob('*.py'):compile(f.read_bytes(),str(f),'exec')
    prior=Path('/workspace/shared/bpp_training_distribution_candidate_evaluation_20261008')
    oldfreeze=json.loads((prior/'SOURCE_FREEZE.json').read_text())
    for name,h in oldfreeze['files'].items():assert sha((prior/name).read_bytes())==h
    assert json.loads((prior/'EXECUTION_AUTHORIZATION.json').read_text())['execution_authorized'] is False
    assert not list((prior/'claims').glob('*'))
    if (R/'SOURCE_FREEZE.json').exists():
        for name,h in read('SOURCE_FREEZE.json')['files'].items():assert sha((R/name).read_bytes())==h
    return {'status':'PASS_STATIC_ONLY','candidate_actions':12,'scientific_packs_max':8,'analysis_actions':1,'claims_count':0,'execution_authorized':False,'candidate_launches':0,'candidate_AST_parse_compile_import_execute_in_this_stage':0,'prior_retrieval_AST_parse_disclosed_not_admission':True,'confirmation_data_reads_or_materialization':0,'old_full_evaluator_claims_consumed':0,'runtime_dynamic_tests':0,'source_repairs':0,'checked':'Trusted-code syntax; extractor pure-data edge cases; response/source/training/runtime hashes; distinct plan/claims/resource arithmetic; original preparation remains locked and unchanged','complete_preparation_CPU':None,'complete_preparation_active_wall':None,'preparation_reservation':{'CPU':60,'wall':90},'dynamic_execution_certified':False}

if __name__=='__main__':print(json.dumps(validate(),sort_keys=True,indent=2))
