"""Single authorized action, unchanged frozen runtime; never host-parse a candidate."""
import os,sys,json,signal
from pathlib import Path
sys.dont_write_bytecode=True
from driver_helpers import R,read,put,sha,digest
from extract_source import extract_source,FormatFailure
os.umask(0o077)
assert len(sys.argv)==2
A=sys.argv[1]
assert os.getppid()==int(os.environ['PRECHECK_GUARD_PID'])
signal.signal(signal.SIGXCPU,signal.SIG_DFL)
signal.pthread_sigmask(signal.SIG_UNBLOCK,{signal.SIGXCPU})
assert sys.stdin.read(1)=='G'
p=read('PLAN.json');a=next(x for x in p['actions'] if x['id']==A)
slot=a['slot_id'];kind=a['kind'];auth=read('EXECUTION_AUTHORIZATION.json')
assert auth['execution_authorized'] is True and auth['frozen_subset_terminal'] is True
assert sha((R/'SOURCE_FREEZE.json').read_bytes())==auth['source_freeze_sha256']
assert sha((R/'CANDIDATES.json').read_bytes())==auth['candidate_manifest_sha256']
registry=read('CANDIDATES.json')
if kind=='analysis':
    from analyze import run_analysis
    run_analysis(A)
    raise SystemExit(0)
row=next(x for x in registry['slots'] if x['slot_id']==slot)
payload={'action_id':A,'slot_id':slot,'kind':kind,'scientific':kind=='scientific','candidate_execution_started':False}
def finish(outcome,**fields):
    put('payload_'+A+'.json',{**payload,'outcome':outcome,**fields})
    raise SystemExit(0)
# Known prerequisite failures retain their own slots; never launch that candidate.
if kind!='admission':
    prior=read('payload_'+slot+'_admission.json')
    if prior['outcome']!='passed':finish('not_run_ineligible',reason='admission_not_passed')
    if kind=='scientific' and read('payload_'+slot+'_toy.json')['outcome']!='passed':
        finish('not_run_ineligible',reason='toy_not_passed')
if row['generation_status']=='known_failure':
    assert kind=='admission'
    finish('candidate_failure',failure_class='generation_failure')
assert row['generation_status']=='completed_public_response'
raw=Path(row['raw_path']).read_bytes()
assert sha(raw)==row['raw_response_sha256']
try:code=extract_source(raw)
except FormatFailure as exc:
    assert kind=='admission'
    finish('candidate_failure',failure_class='format_failure',detail=str(exc))
assert sha(code.encode())==row['source_sha256']
assert Path(row['source_path']).read_bytes()==code.encode()
description='Recovered old 64000-token/900-second exploratory slot '+slot
candidate={'description':description,'code':code,'description_sha256':sha(description.encode()),'code_sha256':sha(code.encode()),'pair_sha256':digest({'description':description,'code':code}),'description_consistency':'undetermined'}
payload['code_sha256']=candidate['code_sha256']
sys.path.insert(0,p['runtime'])
from resource_profile import profile_sha256
from policy import policy_sha256
from registry import source_bytes
source_bytes(candidate)
claim=read('claims/'+A+'.json')
binding={'batch_id':p['id'],'wave_id':p['id']+'-old-recovered','slot_id':slot,'raw_response_sha256':row['raw_response_sha256'],'source_sha256':candidate['code_sha256'],'policy_sha256':policy_sha256(),'runtime_freeze_sha256':p['worker_freeze_sha256'],'claim_sha256':digest(claim),'claim_id':digest([p['id'],A]),'registry_sha256':digest(registry),'resource_profile_sha256':profile_sha256(p['profiles'][kind])}
def clean_worker(ev):
    assert ev['reaped'] is True and ev['cleanup_error'] is None
    assert ev['source_sent'] is True and ev['source_after_host_gate'] is True
payload['candidate_execution_started']=True
try:
    if kind=='admission':
        from runner import Session,ResourceLimitFailure
        try:
            w=Session(candidate,binding,worker_role='admission',execution_id=binding['claim_id']+'/admission')
            adm=w.admission.copy();w.close();ev=w.evidence()
        except ResourceLimitFailure as exc:
            ev=exc.worker_evidence;clean_worker(ev)
            assert ev['terminal_reason'] is not None
            finish('candidate_failure',failure_class='resource_limit',worker=ev)
        clean_worker(ev);assert ev['returncode']==0
        if adm['admitted'] is False:
            assert adm['kind'] in ('static','compile')
            finish('candidate_failure',failure_class=adm['kind']+'_rejection',admission=adm,worker=ev)
        assert adm['admitted'] is True
        finish('passed',admission=adm,worker=ev,canonical_sha256=sha(adm['canonical_text'].encode()))
    from supervised_runner import supervised_pack
    from checker import check_assignment
    if kind=='toy':items=p['toy']
    else:
        entry=next(x for x in read('INPUT_BINDINGS.json')['entries'] if x['sequence']==a['sequence'])
        source=Path(entry['path']).read_bytes();assert sha(source)==entry['file_sha256']
        data=json.loads(source);assert digest(data)==entry['input_sha256']
        items=data['items'];assert len(items)==1000
    report=supervised_pack(items,100,candidate,binding,execution_id=binding['claim_id']+'/instance/0',instance_index=0)
    worker=report['worker'];sup=report['supervisor_evidence'];clean_worker(worker)
    assert sup['reaped'] is True and sup['cleanup_error'] is None and sup['returncode']==0
    assert worker['admission']['canonical_text']==prior['admission']['canonical_text']
    if report['outcome']!='ok':
        assert report['outcome'] in ('numeric_failure','resource_limit','timeout')
        finish('candidate_failure',failure_class=report['outcome'],original_pack_report=report)
    assert worker['returncode']==0
    checked=check_assignment(items,100,report['result']);assert checked['checker_status']=='passed'
    finish('passed',sequence=a['sequence'],n=len(items),L1=(sum(items)+99)//100,input_sha256=digest({'items':items,'capacity':100}),checker=checked,original_pack_report=report)
except SystemExit:
    raise
except BaseException as exc:
    put('failure_'+A+'.json',{'action_id':A,'exception_type':type(exc).__name__,'message':str(exc)[:1024],'worker_evidence':getattr(exc,'worker_evidence',None),'supervisor_evidence':getattr(exc,'supervisor_evidence',None),'missing_evidence_is_null':True,'no_retry':True})
    raise
