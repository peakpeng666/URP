"""Read-only exact integer replay of frozen receipts; never import candidate code."""
from pathlib import Path
from fractions import Fraction
import json
from driver_helpers import R, read, put, sha, digest

def replay(items, result):
    assert type(items) is list and all(type(x) is int and 1<=x<=100 for x in items)
    assignment=result['assignment'];assert type(assignment) is list and len(assignment)==len(items)
    remaining=[100]*len(items)
    for item,index in zip(items,assignment):
        assert type(index) is int and 0<=index<len(items) and remaining[index]>=item
        remaining[index]-=item
    assert remaining==result['remaining'] and all(x>=0 for x in remaining)
    assert sum(items)==sum(100-x for x in remaining)
    used=sum(x!=100 for x in remaining);lower=(sum(items)+99)//100
    assert used==result['used_bins'] and used>=lower
    return {'used_bins':used,'L1':lower,'bins_above_L1':used-lower,'F':str(Fraction(lower,used)),'F_float_display':float(Fraction(lower,used)),'assignment_sha256':digest(assignment),'integer_replay_pass':True}

def run_analysis(action_id):
    plan=read('PLAN.json');bindings=read('INPUT_BINDINGS.json');registry=read('CANDIDATES.json')
    inputs={}
    for entry in bindings['entries']:
        raw=Path(entry['path']).read_bytes();assert sha(raw)==entry['file_sha256']
        data=json.loads(raw);assert digest(data)==entry['input_sha256'] and len(data['items'])==1000 and data['capacity']==100
        inputs[entry['sequence']]=data
    refs={}
    for name,entry in bindings['read_only_baseline_reference_files'].items():
        raw=Path(entry['path']).read_bytes();assert sha(raw)==entry['sha256'];refs[name]=json.loads(raw)
    parent=refs['METHODS.json']['methods']['published_EoH']
    parent_admission=refs['payload_admission_published_EoH.json']['admission']
    assert parent_admission['admitted'] is True
    baseline_rows=[]
    for sequence,data in inputs.items():
        for method in ['BF','published_EoH']:
            payload=refs[f'payload_{sequence}_{method}.json']
            assert payload['input_sha256']==digest(data) and payload['code_sha256']==refs['METHODS.json']['methods'][method]['code_sha256']
            report=payload['original_pack_report'];assert report['outcome']=='ok'
            for role in ['worker','supervisor_evidence']:
                ev=report[role];assert ev['reaped'] is True and ev['returncode']==0 and ev['cleanup_error'] is None
            replayed=replay(data['items'],report['result'])
            assert replayed['used_bins']==payload['checker']['used_bins'] and replayed['L1']==payload['L1']
            baseline_rows.append({'sequence':sequence,'method':method,**replayed})
    candidate_rows=[];failures=[];outcomes=[];admissions={};toy_rows=[]
    for action in plan['actions']:
        if action['kind']=='analysis':continue
        aid=action['id'];claim=read('claims/'+aid+'.json');terminal=read('results/'+aid+'.json')
        assert claim['namespace']==plan['id'] and terminal['claim_sha256']==digest(claim)
        assert terminal['status'] in ('passed','candidate_failure','not_run_ineligible')
        assert terminal['resources']['driver_reaped'] is True and terminal['resources']['driver_exit_code']==0
        raw=(R/('payload_'+aid+'.json')).read_bytes();assert sha(raw)==terminal['payload_sha256']
        payload=json.loads(raw);assert payload['action_id']==aid and payload['outcome']==terminal['status']
        outcomes.append({'action_id':aid,'slot_id':action['slot_id'],'kind':action['kind'],'status':terminal['status'],'CPU_reserved':claim['CPU_reserve'],'wall_reserved':claim['wall_reserve'],'driver_wait4_inclusive_CPU':terminal['resources']['driver_wait4_inclusive_CPU']})
        if terminal['status']!='passed':
            failures.append({'action_id':aid,'status':terminal['status'],'failure_class':payload.get('failure_class'),'reason':payload.get('reason'),'no_replacement':True});continue
        candidate=next(x for x in registry['slots'] if x['slot_id']==action['slot_id'])
        assert payload['code_sha256']==candidate['source_sha256']
        if action['kind']=='admission':
            assert payload['admission']['admitted'] is True;admissions[action['slot_id']]=payload['admission'];continue
        report=payload['original_pack_report'];assert report['outcome']=='ok'
        assert report['execution_id']==report['binding']['claim_id']+'/instance/0' and report['instance_index']==0
        for role in ['worker','supervisor_evidence']:
            ev=report[role];assert ev['reaped'] is True and ev['returncode']==0 and ev['cleanup_error'] is None
        items=plan['toy'] if action['kind']=='toy' else inputs[action['sequence']]['items']
        assert payload['input_sha256']==digest({'items':items,'capacity':100})
        replayed=replay(items,report['result']);assert replayed['used_bins']==payload['checker']['used_bins'] and replayed['L1']==payload['L1']
        row={'slot_id':action['slot_id'],'generation_slot':candidate['generation_slot'],'action_id':aid,'sequence':action['sequence'],'n':len(items),'source_sha256':candidate['source_sha256'],**replayed}
        if action['kind']=='toy':toy_rows.append(row)
        else:candidate_rows.append(row)
    summaries=[]
    for candidate in registry['slots']:
        slot=candidate['slot_id'];rows=[x for x in candidate_rows if x['slot_id']==slot]
        complete=len(rows)==4 and [x['sequence'] for x in rows]==['W1','W2','W3','W4']
        mean=sum((Fraction(x['F']) for x in rows),Fraction())/4 if complete else None
        comparison=[]
        for row in rows:
            same={x['method']:x for x in baseline_rows if x['sequence']==row['sequence']}
            comparison.append({'sequence':row['sequence'],'candidate_used_bins':row['used_bins'],'parent_used_bins':same['published_EoH']['used_bins'],'BF_used_bins':same['BF']['used_bins'],'candidate_minus_parent_bins':row['used_bins']-same['published_EoH']['used_bins'],'candidate_minus_BF_bins':row['used_bins']-same['BF']['used_bins'],'candidate_minus_parent_F':str(Fraction(row['F'])-Fraction(same['published_EoH']['F'])),'candidate_minus_BF_F':str(Fraction(row['F'])-Fraction(same['BF']['F']))})
        summaries.append({'slot_id':slot,'complete_four_streams':complete,'four_stream_mean_F':str(mean) if mean is not None else None,'four_stream_mean_F_float_display':float(mean) if mean is not None else None,'source_equal_parent':candidate['source_sha256']==parent['code_sha256'],'canonical_AST_equal_parent':admissions[slot]['canonical_text']==parent_admission['canonical_text'] if slot in admissions else None,'comparisons':comparison})
    first,second=registry['slots']
    duplicate={'exact_source_equal':first['source_sha256']==second['source_sha256'],'canonical_AST_equal':admissions[first['slot_id']]['canonical_text']==admissions[second['slot_id']]['canonical_text'] if len(admissions)==2 else None,'canonical_observation_source':'bounded admission child only; parent from verified saved baseline admission','novelty_inferred':False}
    out={'schema':'old-partial-training-analysis-v1','status':'EXPLORATORY_TWO_OLD_CANDIDATES_COMPLETE_WITH_RECORDED_FAILURES' if failures else 'EXPLORATORY_TWO_OLD_CANDIDATES_ALL_PASSED','scope':plan['scope'],'provenance_sha256':sha((R/'PROVENANCE.json').read_bytes()),'original_attempted_generation_denominator':4,'original_generation_failure_slots':['M1','M2'],'original_unattempted_slots':['W3','M3','M4','W4'],'candidate_rows':candidate_rows,'toy_replay':toy_rows,'candidate_summaries':summaries,'same_stream_verified_frozen_baselines':baseline_rows,'duplicate_observations':duplicate,'action_outcomes':outcomes,'failures':failures,'no_replacement':True,'no_W_vs_M_arm_comparison':True,'no_novelty_claim':True,'no_generalization_or_confirmation_claim':True,'no_p_values':True,'held_out_confirmation_arrays_materialized':0,'model_API_calls':0,'baseline_candidate_execution_reruns':0,'resource_accounting':'driver wait4 inclusive descendants is counted once per claim; nested worker/supervisor figures are diagnostic only; preparation/all-in actual totals remain unmeasured/null','complete_all_in_CPU_seconds':None,'complete_all_in_active_wall_seconds':None,'reserved_budget':plan['budget']['reserved']}
    put('ANALYSIS.json',out)
    put('payload_'+action_id+'.json',{'action_id':action_id,'slot_id':None,'kind':'analysis','scientific':False,'candidate_execution_started':False,'outcome':'passed','analysis_sha256':sha((R/'ANALYSIS.json').read_bytes()),'integer_replay_completed':True})
