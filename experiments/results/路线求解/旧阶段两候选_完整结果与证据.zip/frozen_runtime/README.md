# Profiled registered-source backend v2

This is a separate resource-profile revision. Accepted r4 and all older source, runtime and failure evidence remain unchanged. No transport optimization is included.

Production uses a numeric worker with hard60CPU and a trusted per-instance supervisor with hard60CPU, sharing one90wall deadline from supervisor dispatch. Startup and two seconds of cleanup are inside90; active processing stops at88. Each request wait is clamped to that same active deadline. Admission-only work is separately bounded1CPU/5totalwall (3active+2cleanup). Exact AST/facade/numerical policy and worker.initialize/kernel rules remain unchanged.

The old design-panel5CPU/10wall worker and60CPU/120wall total commitments remain historical. The later mathematical-DAG60/90 control was not reused as Python authority. This revision records the separately approved production amendment.

Profile hash is mandatory in registry, wave freeze, deployment, worker and receipt. Worker role, configured and observed limits, total/active deadlines, CPU/wall and incomplete-assignment status are explicit. Known numeric-child caps can produce authenticated consumed-slot failure receipts. CPU-cap inference requires typed EOF, natural wait4 reap before parent kill, SIGKILL, clean stderr/cleanup and frozen near-cap CPU tolerance; it is explicitly evidence-based, not an OS-certified cause. Unknown exits or missing cleanup stop integrity flow. A supervisor hard death without descendant-reap proof also stops; no result or cleanup is invented.

The supervisor only wraps the existing trusted pack loop. Its job contains exact source bytes and current parent-owned instance; no raw response, public description or thought text is transmitted. It sends the numeric child only each current placement after the original verified gates. The helper is not a new candidate sandbox.

780pack allocation means660candidate-design+20controls+100confirmation. Parents reuse verified design fitness, not new rescoring. Instance reservations are46800numeric-childCPU+46800supervisorCPU=93600CPU and70200serializedwall; generation/admission/preparation/exceptional cleanup are separate. Later confirmation requires distinct evaluation IDs and data hashes and is not silently covered by this initial five-design-instance bridge.

Prepared smoke is one four-item handwritten control under production caps, budget190CPU/120wall:120instance reservation,1admission,3prep,60launcher,6margin. The initial140CPU proposal was not run because a hard10CPU launcher cannot raise an inherited child hard ceiling to60. The outer60CPU launcher cap is specific to this engineering smoke; study-controller overhead remains separately accounted and is not multiplied perpack. Run only after exact source review and external backup. No5000 calibration, model call, generated candidate execution or data-panel access is authorized by this smoke. The old r4 launcher is disabled in this revision because its budget does not include the supervisor.

All source files are preparation-only until profile_smoke_results.json and independent readback establish the smoke outcome. The smoke alone does not certify full5000 fitness feasibility.
