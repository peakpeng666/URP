"""Recovered v2 trusted-source and exact signed-integer score protocol."""
import json
import math
import base64
import hashlib
import re

MAX_REQUEST = 32768
MAX_RESPONSE = 180000
MAX_STEPS = 5000
MAX_BINS = 5000
MAX_DEPTH = 4
MAX_SOURCE_BYTES = 16384
MAX_SOURCE_FRAME = 26000
MAX_ADMISSION = 280000
MAX_AST_TEXT = 262144
from registry import BINDING_KEYS, digest, is_hash
from policy import POLICY, policy_sha256
from resource_profile import role_limits, resolve_profile


def strict_json(raw, cap):
    if type(raw) is not bytes or not raw or len(raw) > cap:
        raise ValueError('frame size/type')
    text = raw.decode('utf-8', errors='strict')
    depth = 0
    in_string = False
    escaped = False
    for c in text:
        if in_string:
            if escaped:
                escaped = False
            elif c == '\\':
                escaped = True
            elif c == '"':
                in_string = False
        elif c == '"':
            in_string = True
        elif c in '[{':
            depth += 1
            if depth > MAX_DEPTH:
                raise ValueError('JSON depth')
        elif c in ']}':
            depth -= 1
            if depth < 0:
                raise ValueError('JSON balance')
    if depth or in_string:
        raise ValueError('JSON incomplete')
    def integer(token):
        if len(token) > 20:
            raise ValueError('integer token bound')
        value = int(token)
        if not -(2**63) <= value < 2**63:
            raise ValueError("signed int64 token bound")
        return value
    def floating(token):
        if len(token) > 32:
            raise ValueError('float token bound')
        value = float(token)
        if not math.isfinite(value):
            raise ValueError('nonfinite number')
        return value
    def constant(_):
        raise ValueError('nonstandard JSON number')
    def pairs(entries):
        obj = {}
        for k, v in entries:
            if k in obj:
                raise ValueError('duplicate key')
            obj[k] = v
        return obj
    return json.loads(text, parse_int=integer, parse_float=floating,
                      parse_constant=constant, object_pairs_hook=pairs)


def encode(obj, cap):
    raw = json.dumps(obj, ensure_ascii=True, allow_nan=False,
                     separators=(',', ':')).encode('ascii') + b'\n'
    if len(raw) > cap:
        raise ValueError('encoded frame too large')
    return raw


def request(value, expected_step):
    if type(value) is not dict or set(value) != {'v', 'step', 'item', 'bins'}:
        raise ValueError('request fields')
    if type(value['v']) is not int or value['v'] != 2:
        raise ValueError('protocol version')
    if type(value['step']) is not int or value['step'] != expected_step or not 0 <= expected_step < MAX_STEPS:
        raise ValueError('step mismatch')
    item = value['item']
    bins = value['bins']
    if type(item) is not int or not 1 <= item <= 100:
        raise ValueError('item domain')
    if type(bins) is not list or not 1 <= len(bins) <= MAX_BINS:
        raise ValueError('bin shape/length')
    if any(type(b) is not int or not item <= b <= 500 for b in bins):
        raise ValueError('bin domain/type')
    return item, bins


def arithmetic_evidence(value, *, failed=False):
    if type(value) is not dict or set(value)!={'placement','instance','budget_exceeded'}:raise ValueError('arithmetic evidence schema')
    if type(value['budget_exceeded']) is not bool or value['budget_exceeded'] and not failed:raise ValueError('arithmetic exceeded flag')
    for key,limit in [('placement',POLICY['per_placement_callback_limit']),('instance',POLICY['per_instance_callback_limit'])]:
        counts=value[key]
        if type(counts) is not dict or set(counts)!=set(POLICY['events']):raise ValueError('event categories')
        if any(type(n) is not int or not 0<=n<=limit+int(failed) for n in counts.values()) or sum(counts.values())>limit+int(failed):raise ValueError('event budget')
    exceeded=(sum(value['placement'].values())>POLICY['per_placement_callback_limit'] or sum(value['instance'].values())>POLICY['per_instance_callback_limit'])
    if value['budget_exceeded']!=exceeded:raise ValueError('event exceeded consistency')
    if any(value['placement'][k]>value['instance'][k] for k in POLICY['events']):raise ValueError('event monotonicity')
    return value


def response(value, step, length, policy, resource_profile_sha256, worker_role):
    cpu_bound = role_limits(resource_profile_sha256, worker_role)['cpu_seconds'] * 1000000000
    if type(value) is not dict or set(value) != {'v', 'step', 'scores', 'arithmetic_events', 'dtype', 'binding_sha256', 'score_call_cpu_ns'}:
        raise ValueError('response fields')
    if type(value['v']) is not int or value['v'] != 3 or type(value['step']) is not int or value['step'] != step:
        raise ValueError('response version/step')
    if value['binding_sha256']!=policy:raise ValueError('score binding')
    if type(value['score_call_cpu_ns']) is not int or not 0<=value['score_call_cpu_ns']<=cpu_bound:raise ValueError('score call CPU metadata')
    scores=value['scores']
    if type(scores) is not list or len(scores)!=length:raise ValueError('score shape')
    dtype=value['dtype']
    if type(dtype) is not str or dtype not in ('int32','int64','float64'):raise ValueError('score dtype')
    for x in scores:
        if dtype=='float64':
            if type(x) is not float or not math.isfinite(x):raise ValueError('finite exact float required')
        else:
            bits=32 if dtype=='int32' else 64
            if type(x) is not int or not -(2**(bits-1)) <= x < 2**(bits-1):raise ValueError('exact signed integer required')
    events=arithmetic_evidence(value['arithmetic_events'])
    return scores,events


def numerical_failure(value,step,binding_sha256,resource_profile_sha256,worker_role):
    cpu_bound = role_limits(resource_profile_sha256, worker_role)['cpu_seconds'] * 1000000000
    if type(value) is not dict or 'failure' not in value:return False
    if set(value)!={'v','step','failure','arithmetic_events','binding_sha256','exception_kind','score_call_cpu_ns'} or type(value['v']) is not int or value['v']!=3 or type(value['step']) is not int or value['step']!=step:raise ValueError('failure fields')
    if value['binding_sha256']!=binding_sha256 or value['failure']!='numerical_policy':raise ValueError('failure binding')
    if value['exception_kind'] not in ('ArithmeticBudgetExceeded','ArithmeticError','FloatingPointError','OverflowError','ZeroDivisionError','ValueError','TypeError','IndexError','NumericContractError'):raise ValueError('failure kind')
    if type(value['score_call_cpu_ns']) is not int or not 0<=value['score_call_cpu_ns']<=cpu_bound:raise ValueError('failure CPU metadata')
    arithmetic_evidence(value['arithmetic_events'],failed=True)
    if (value['exception_kind']=='ArithmeticBudgetExceeded')!=value['arithmetic_events']['budget_exceeded']:raise ValueError('failure budget kind consistency')
    return True


def source_frame(value,expected_freeze,expected_binding,expected_resource_profile):
    resolve_profile(expected_resource_profile)
    if type(value) is not dict or set(value)!={'v','kind','source_b64','binding'}:raise ValueError('source fields')
    if type(value['v']) is not int or value['v']!=3 or value['kind']!='registered_source':raise ValueError('source version/kind')
    binding=value['binding']
    if type(binding) is not dict or set(binding)!=set(BINDING_KEYS) or digest(binding)!=expected_binding:raise ValueError('registry binding')
    for key in BINDING_KEYS:
        if key.endswith('sha256') and not is_hash(binding[key]):raise ValueError('binding hash format')
    if binding.get('resource_profile_sha256')!=expected_resource_profile:raise ValueError('resource profile binding')
    if binding['runtime_freeze_sha256']!=expected_freeze or binding['policy_sha256']!=policy_sha256():raise ValueError('runtime/policy mismatch')
    encoded=value['source_b64'];claimed=binding['source_sha256']
    if type(encoded) is not str or len(encoded)>21848 or not encoded.isascii():raise ValueError('source encoded bound')
    source=base64.b64decode(encoded,validate=True)
    if not 0<len(source)<=MAX_SOURCE_BYTES or base64.b64encode(source).decode('ascii')!=encoded:raise ValueError('source bytes/canonical bound')
    if hashlib.sha256(source).hexdigest()!=claimed:raise ValueError('source hash mismatch')
    return source,binding
