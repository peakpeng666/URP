"""Externally pinned activation with fixed role-specific resource profile.

Profile selection does not authorize a study. Parent pins the separately approved
registry, wave and resource identities and reserves total work before dispatch.
"""
from registry import load_document,require,verify_seal
from policy import policy_sha256
from resource_profile import PRODUCTION_PROFILE_ID,resolve_profile
MODES={'handwritten_registry_test':'handwritten_fixture','registered_source_study':'model_response'}
FIELDS={'schema','mode','source_origin','registry_sha256','wave_freeze_sha256','batch_id','wave_id','phase',
        'runtime_freeze_sha256','resource_profile_sha256','policy_sha256','isolation_profile_sha256','checker_sha256',
        'intake_manifest_sha256','sha256'}
class DeploymentFreeze:
    def __init__(self,path,expected_sha256):
        self.path=path;self.expected=expected_sha256
        self.document=load_document(path,expected_sha256)
        value=self.document
        require(set(value)==FIELDS and value['schema']=='candidate-deployment-freeze-v2','deployment schema')
        require(value['mode'] in MODES and value['source_origin']==MODES[value['mode']],'deployment mode/provenance')
        require(value['policy_sha256']==policy_sha256(),'deployment policy')
        profile=resolve_profile(value['resource_profile_sha256'])
        if value['mode']=='registered_source_study':
            require(profile['profile_id']==PRODUCTION_PROFILE_ID,'study requires common approved production profile')
    def validate(self,registry,wave_freeze):
        require(load_document(self.path,self.expected)==self.document,'deployment changed')
        verify_seal(wave_freeze)
        value=self.document;document=registry.document
        require(value['registry_sha256']==document['sha256'],'deployment authorized registry')
        require(value['wave_freeze_sha256']==wave_freeze['sha256'],'deployment wave freeze')
        for key in ('batch_id','wave_id','phase','source_origin','runtime_freeze_sha256','policy_sha256','resource_profile_sha256'):
            require(value[key]==document[key],'deployment registry '+key)
        if value['mode']=='registered_source_study':
            require(wave_freeze.get('mode')=='official_cli','deployment generation mode mismatch')
            require(wave_freeze.get('evaluation_mode')==value['mode'],'deployment evaluation mode mismatch')
        else:
            require(value['mode']==wave_freeze.get('mode'),'deployment mode mismatch')
            require(wave_freeze.get('evaluation_mode',value['mode'])==value['mode'],'deployment evaluation mode mismatch')
        require(wave_freeze.get('source_origin',value['source_origin'])==value['source_origin'],'deployment wave source_origin')
        require(value['runtime_freeze_sha256']==wave_freeze['runtime_sha256'],'deployment runtime')
        for key in ('policy_sha256','resource_profile_sha256','isolation_profile_sha256','checker_sha256','intake_manifest_sha256'):
            require(value[key]==wave_freeze[key],'deployment wave '+key)
        return dict(value)
