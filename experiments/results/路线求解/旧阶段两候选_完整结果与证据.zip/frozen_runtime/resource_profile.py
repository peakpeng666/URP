"""Two closed resource profiles. No caller-supplied resource values are accepted.

Profiles are public, JSON-safe identities, independent of source and instances.
Every lookup returns a fresh document, so callers cannot mutate the allowlist.
"""
import hashlib
import json

PRODUCTION_PROFILE_ID = 'production-60cpu-90wall-v1'
DIAGNOSTIC_PROFILE_ID = 'diagnostic-1cpu-5wall-v1'
PROFILE_IDS = (PRODUCTION_PROFILE_ID, DIAGNOSTIC_PROFILE_ID)
WORKER_ROLES = ('admission', 'instance')


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True,
                      allow_nan=False)


def profile_document(profile_id):
    if type(profile_id) is not str or profile_id not in PROFILE_IDS:
        raise ValueError('unknown fixed resource profile')
    production = profile_id == PRODUCTION_PROFILE_ID
    return {
        'schema': 'registered-numpy-resource-profile-v1',
        'profile_id': profile_id,
        'roles': {
            'admission': {'cpu_seconds': 1, 'wall_seconds': 5,
                          'request_wall_seconds': 5 if production else 2,
                          'startup_wall_seconds': 5},
            'instance': {'cpu_seconds': 60 if production else 1,
                         'wall_seconds': 90 if production else 5,
                         'request_wall_seconds': 90 if production else 2,
                         'startup_wall_seconds': 5},
        },
        'worker_as_bytes': 536870912,
        'max_open_files': 3,
        'max_file_size_bytes': 0,
        'max_core_bytes': 0,
        'max_steps': 5000,
        'max_source_bytes': 16384,
        'max_instances': 5,
        'supervisor_cpu_seconds': 60 if production else 10,
        'both_arms_identical': True,
        'cleanup_wall_seconds': 2,
        'cleanup_within_wall': True,
    }


def profile_sha256(profile_id):
    return hashlib.sha256(canonical(profile_document(profile_id)).encode('ascii')).hexdigest()


def resolve_profile(resource_profile_sha256):
    if type(resource_profile_sha256) is not str:
        raise ValueError('resource profile hash type')
    for profile_id in PROFILE_IDS:
        if resource_profile_sha256 == profile_sha256(profile_id):
            return profile_document(profile_id)
    raise ValueError('unknown fixed resource profile hash')


def role_limits(resource_profile_sha256, worker_role):
    if type(worker_role) is not str or worker_role not in WORKER_ROLES:
        raise ValueError('unknown fixed worker role')
    return resolve_profile(resource_profile_sha256)['roles'][worker_role]


def configured_limits(resource_profile_sha256, worker_role):
    profile = resolve_profile(resource_profile_sha256)
    return {
        **role_limits(resource_profile_sha256, worker_role),
        **{key: profile[key] for key in ('worker_as_bytes', 'max_open_files',
           'max_file_size_bytes', 'max_core_bytes', 'max_steps', 'max_source_bytes', 'max_instances',
           'supervisor_cpu_seconds', 'cleanup_wall_seconds', 'cleanup_within_wall')},
    }
