"""Proposed numeric-only NumPy facade, source-reviewed but NOT runtime-probed.

No NumPy import or factory invocation occurs at module import. A separately
reviewed restricted worker would inject its preloaded, frozen NumPy module.
The AST language and OS-level child isolation remain mandatory. This wrapper
is NOT a sandbox and Python object introspection must never be admitted.
"""
import math
from dataclasses import dataclass
from types import MappingProxyType
from manifest import API_SPECS, DTYPES, MAX_VECTOR

class NumericContractError(ValueError):
    pass

@dataclass(frozen=True, slots=True)
class DTypeToken:
    name: str

class NumericFacade:
    __slots__ = ('_values',)
    def __init__(self, values):
        object.__setattr__(self, '_values', MappingProxyType(dict(values)))
    def __getattr__(self, name):
        values = object.__getattribute__(self, '_values')
        if name not in values:
            raise AttributeError('unlisted numeric API')
        return values[name]
    def __setattr__(self, name, value):
        raise AttributeError('numeric facade is immutable')
    def __delattr__(self, name):
        raise AttributeError('numeric facade is immutable')


def build_facade(np):
    """Trusted restricted-child-only factory; never pass host objects to source."""
    scalar_types = (np.float64, np.int64, np.int32, np.bool_)
    dtype_map = {name: np.dtype(getattr(np, name)) for name in DTYPES}
    allowed_dtypes = frozenset(dtype_map.values())
    dtype_tokens = {name: DTypeToken(name) for name in DTYPES}

    def check(value, *, sequences=False):
        # Exact types prevent callbacks via array protocols, subclasses, objects,
        # custom iterators, dtype hooks or Python numeric conversion methods.
        t = type(value)
        if t is np.ndarray:
            if value.ndim != 1 or value.size > MAX_VECTOR or value.dtype not in allowed_dtypes:
                raise NumericContractError('array rank/size/dtype')
        elif t in scalar_types:
            if value.dtype not in allowed_dtypes:
                raise NumericContractError('scalar dtype')
        elif t is int:
            if not -(2**63) <= value < 2**63:
                raise NumericContractError('integer width')
        elif t in (float, bool):
            # Intermediate nonfinite IEEE values are retained. Final output is
            # checked separately and the worker owns fixed FP-event policy.
            pass
        elif sequences and t in (list, tuple):
            if not 1 <= len(value) <= MAX_VECTOR:
                raise NumericContractError('sequence size')
            for element in value:
                if type(element) in (list, tuple, np.ndarray):
                    raise NumericContractError('nested numerical sequence')
                check(element)
        else:
            raise NumericContractError('non-numerical, object or subclass argument')
        return value

    def vector(value):
        check(value)
        if type(value) is not np.ndarray or value.ndim != 1:
            raise NumericContractError('one-dimensional ndarray required')
        return value

    def scalar(value):
        check(value)
        if type(value) is np.ndarray:
            raise NumericContractError('scalar required')
        return value

    def integer(value):
        if type(value) not in (int, np.int64, np.int32):
            raise NumericContractError('exact integer required')
        check(value)
        return int(value)

    def invoke(name, args, kwargs):
        lo, hi, keys, rule = API_SPECS[name]
        if not lo <= len(args) <= hi or set(kwargs) - set(keys):
            raise NumericContractError('API arity/keywords')
        for value in args:
            check(value, sequences=(rule in ('constructor', 'reshape_one_dimension')))
        clean = dict(kwargs)
        if 'dtype' in clean:
            token = clean['dtype']
            if type(token) is not DTypeToken or token.name not in dtype_map or token is not dtype_tokens[token.name]:
                raise NumericContractError('unapproved dtype token')
            clean['dtype'] = dtype_map[token.name]
        if 'axis' in clean and (type(clean['axis']) is not int or clean['axis'] != 0):
            raise NumericContractError('axis must be exact integer zero')
        if 'n' in clean and (type(clean['n']) is not int or clean['n'] not in (0, 1, 2)):
            raise NumericContractError('diff n must be 0,1,2')
        if rule == 'bounded_integer_range':
            values = tuple(integer(x) for x in args)
            if any(abs(x) > 1000000 for x in values):
                raise NumericContractError('arange integer bound')
            if len(values) == 3 and values[2] == 0:
                raise NumericContractError('arange zero step')
            if len(range(*values)) > MAX_VECTOR:
                raise NumericContractError('arange allocation cap before call')
        elif rule == 'constructor':
            # The pre-call check guarantees at most one numerical dimension and
            # 5000 elements; no object protocol is reached by array/asarray.
            if type(args[0]) not in (np.ndarray, list, tuple):
                raise NumericContractError('constructor requires vector or flat sequence')
        elif rule in ('like', 'preserve', 'vector_preserve', 'integer_vector', 'integer_scalar',
                      'difference', 'reduction', 'quantile', 'full_like'):
            vector(args[0])
            if rule == 'full_like': scalar(args[1])
            if rule == 'quantile':
                q = scalar(args[1]); upper = 100 if name == 'percentile' else 1
                if type(q) is bool or not math.isfinite(float(q)) or not 0 <= q <= upper:
                    raise NumericContractError('quantile scalar bound')
        elif rule == 'reshape_one_dimension':
            value = vector(args[0]); shape = args[1]
            if type(shape) not in (tuple, list) or len(shape) != 1:
                raise NumericContractError('singleton shape required')
            n = integer(shape[0])
            if n < -1 or n > MAX_VECTOR or (n != -1 and n != value.size):
                raise NumericContractError('reshape size mismatch/cap before call')
        elif rule == 'searchsorted':
            vector(args[0])
        elif rule == 'where':
            if not any(type(value) is np.ndarray for value in args):
                raise NumericContractError('all-scalar where is excluded')
            condition = args[0]
            if type(condition) is np.ndarray:
                if condition.dtype != dtype_map['bool_']:
                    raise NumericContractError('where requires boolean mask')
            elif type(condition) not in (bool, np.bool_):
                raise NumericContractError('where requires boolean condition')
        # Every array argument is rank 1 and <=5000, so elementwise broadcasting
        # cannot construct a rank-2 Cartesian product. Unequal incompatible
        # lengths raise normally, rather than being repaired.
        result = getattr(np, name)(*args, **clean)
        check(result)
        if type(result) is np.ndarray:
            # Prevent writes through aliases/views of input and returned arrays.
            # The syntax independently forbids subscript/attribute assignment.
            result.flags.writeable = False
        return result

    def wrapper(name):
        def numerical_call(*args, **kwargs):
            return invoke(name, args, kwargs)
        return numerical_call

    values = {name: wrapper(name) for name in API_SPECS}
    values.update(dtype_tokens)
    return NumericFacade(values)


def prepare_numeric_inputs(np, item, bins):
    """Trusted child helper. Supervisor must independently validate its request."""
    if type(item) is not int or not 1 <= item <= 100:
        raise NumericContractError('item must be exact integer 1..100')
    if type(bins) is not list or not 1 <= len(bins) <= MAX_VECTOR:
        raise NumericContractError('bins must be bounded exact list')
    if any(type(x) is not int or not item <= x <= 500 for x in bins):
        raise NumericContractError('feasible bin must be exact integer item..500')
    current = np.array(bins, dtype=np.int64, copy=True)
    current.flags.writeable = False
    return np.int64(item), current


def validate_final_scores(np, scores, expected_size):
    """No casts, epsilon, clipping or replacements. Host repeats all checks."""
    if type(expected_size) is not int or not 1 <= expected_size <= MAX_VECTOR:
        raise NumericContractError('expected length')
    if (type(scores) is not np.ndarray or scores.dtype not in (np.dtype(np.float64), np.dtype(np.int64), np.dtype(np.int32)) or
            scores.shape != (expected_size,) or not np.all(np.isfinite(scores))):
        raise NumericContractError('final output requires exact finite signed-integer/float64 vector')
    return scores


def validate_host_scores(values, expected_size):
    """Independent numerical boundary for a future strict JSON response parser.

    Keep signed integers exact. In particular, do not coerce int64 to binary64
    before stable argmax: distinct scores above 2**53 may otherwise collapse.
    Frame byte caps, duplicate-key rejection and token bounds belong to the
    separately reviewed future protocol, not to this value-only helper.
    """
    if type(expected_size) is not int or not 1 <= expected_size <= MAX_VECTOR:
        raise NumericContractError('expected length')
    if type(values) is not list or len(values) != expected_size:
        raise NumericContractError('score shape/length')
    for value in values:
        if type(value) is int:
            if not -(2**63) <= value < 2**63:
                raise NumericContractError('score integer outside signed int64')
        elif type(value) is float:
            if not math.isfinite(value):
                raise NumericContractError('nonfinite score')
        else:
            raise NumericContractError('score must be exact int or float; bool excluded')
    return values


def stable_first_argmax(values, expected_size):
    """Trusted host comparison preserves exact int/float values and first ties."""
    validate_host_scores(values, expected_size)
    best = 0
    for index in range(1, len(values)):
        if values[index] > values[best]:
            best = index
    return best
