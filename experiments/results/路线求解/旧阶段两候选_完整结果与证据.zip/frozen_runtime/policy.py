"""Common arithmetic policy for both arms. No candidate API is added."""
import hashlib
import json

POLICY = {
    'schema': 'bounded-arithmetic-finite-final-v1',
    'events': ['divide', 'overflow', 'invalid', 'underflow', 'python_runtimewarning'],
    'numpy_seterr': {'divide':'call', 'over':'call', 'invalid':'call', 'under':'call'},
    'event_unit': 'one NumPy callback by message OR one Python RuntimeWarning emission; not element count',
    'python_warnings': 'always capture RuntimeWarning category without message formatting or filename inspection; other warning categories fail',
    'per_placement_callback_limit': 64,
    'per_instance_callback_limit': 320000,
    'intermediate_nonfinite': 'allowed_program_managed',
    'final': 'exact finite rank1 int32/int64/float64 vector of feasible-bin length',
    'repairs': False,
    'input': 'exact int64 item; copied read-only int64 bins',
    'exception_policy': 'unhandled exceptions fail; no automatic retry',
    'applies_to': 'both experimental arms identically',
}

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False)

def policy_sha256():
    return hashlib.sha256(canonical(POLICY).encode()).hexdigest()

class ArithmeticBudgetExceeded(ArithmeticError):
    pass

class ArithmeticEvents:
    def __init__(self):
        self.total = {name:0 for name in POLICY['events']}
        self.current = {name:0 for name in POLICY['events']}
        self.exceeded = False
    def begin(self):
        self.current = {name:0 for name in POLICY['events']}
    def callback(self, message, flag):
        # NumPy may provide a combined status flag; classify by callback message.
        names = {'divide by zero':'divide','overflow':'overflow','invalid value':'invalid','underflow':'underflow'}
        name = names.get(message)
        bits = {'divide':1,'overflow':2,'underflow':4,'invalid':8}
        if name is None or type(flag) is not int or not 1 <= flag <= 15 or not flag & bits[name]:
            raise ArithmeticError('unknown numerical callback')
        self.increment(name)
    def python_warning(self, message, category, filename, lineno, file=None, line=None):
        if category is not RuntimeWarning:raise ArithmeticError('unlisted warning category')
        self.increment('python_runtimewarning')
    def increment(self,name):
        # At most limit+1 events are retained; no unbounded warning text storage.
        self.current[name] += 1
        self.total[name] += 1
        if sum(self.current.values()) > POLICY['per_placement_callback_limit'] or sum(self.total.values()) > POLICY['per_instance_callback_limit']:
            self.exceeded = True
            raise ArithmeticBudgetExceeded('arithmetic callback budget')
    def evidence(self):
        return {'placement':dict(self.current), 'instance':dict(self.total), 'budget_exceeded':self.exceeded}
