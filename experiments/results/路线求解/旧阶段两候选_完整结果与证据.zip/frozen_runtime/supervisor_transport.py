"""Bounded transport for the trusted per-instance supervisor, never source AST."""
import json
import math
import os
import selectors
import time
MAX_JOB=65536
MAX_RESULT=1048576

def decode(raw,cap):
    if type(raw) is not bytes or not 0<len(raw)<=cap:raise ValueError('supervisor frame bytes')
    text=raw.decode('utf-8',errors='strict');depth=0;quoted=False;escaped=False
    for c in text:
        if quoted:
            if escaped:escaped=False
            elif c=='\\':escaped=True
            elif c=='"':quoted=False
        elif c=='"':quoted=True
        elif c in '[{':
            depth+=1
            if depth>16:raise ValueError('supervisor JSON depth')
        elif c in ']}':
            depth-=1
            if depth<0:raise ValueError('supervisor JSON balance')
    if depth or quoted:raise ValueError('supervisor JSON incomplete')
    def integer(token):
        if len(token)>20:raise ValueError('supervisor integer token')
        value=int(token)
        if not -(2**63)<=value<2**63:raise ValueError('supervisor integer range')
        return value
    def floating(token):
        if len(token)>32:raise ValueError('supervisor float token')
        value=float(token)
        if not math.isfinite(value):raise ValueError('supervisor finite float')
        return value
    def pairs(entries):
        value={}
        for key,item in entries:
            if key in value:raise ValueError('supervisor duplicate key')
            value[key]=item
        return value
    def invalid(_):raise ValueError('supervisor nonstandard number')
    return json.loads(text,parse_int=integer,parse_float=floating,parse_constant=invalid,object_pairs_hook=pairs)

def encode(value,cap):
    raw=json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode()+b'\n'
    if len(raw)>cap:raise ValueError('supervisor encoded frame cap')
    return raw

def read_child_input(cap):
    raw=bytearray()
    while True:
        block=os.read(0,min(4096,cap+1-len(raw)))
        if not block:raise ValueError('supervisor input EOF')
        raw.extend(block)
        if len(raw)>cap:raise ValueError('supervisor input cap')
        if b'\n' in block:
            if not raw.endswith(b'\n') or raw.count(b'\n')!=1:raise ValueError('supervisor input framing')
            return bytes(raw[:-1])

def write_child_output(raw):
    offset=0
    while offset<len(raw):
        count=os.write(1,raw[offset:offset+65536])
        if count<=0:raise RuntimeError('supervisor output stopped')
        offset+=count

class BoundedPipe:
    def __init__(self,process):
        self.process=process
        for stream in (process.stdin,process.stdout,process.stderr):os.set_blocking(stream.fileno(),False)
        self.input_bytes=0;self.output_bytes=0;self.stderr_bytes=0
    def exchange(self,payload,deadline,cap):
        proc=self.process;out=bytearray();offset=0
        with selectors.DefaultSelector() as selector:
            selector.register(proc.stdout,selectors.EVENT_READ)
            selector.register(proc.stderr,selectors.EVENT_READ)
            if payload is not None:selector.register(proc.stdin,selectors.EVENT_WRITE)
            while True:
                remaining=deadline-time.monotonic()
                if remaining<=0:raise TimeoutError('trusted supervisor transport deadline')
                for key,_ in selector.select(min(.05,remaining)):
                    stream=key.fileobj
                    if stream is proc.stdin:
                        try:count=os.write(stream.fileno(),payload[offset:offset+16384])
                        except (BlockingIOError,InterruptedError):continue
                        if count<=0:raise RuntimeError('supervisor input stalled')
                        offset+=count;self.input_bytes+=count
                        if offset==len(payload):selector.unregister(stream)
                    else:
                        try:block=os.read(stream.fileno(),min(16384,cap+1-len(out)) if stream is proc.stdout else 1)
                        except (BlockingIOError,InterruptedError):continue
                        if stream is proc.stderr:
                            if block:self.stderr_bytes+=len(block);raise RuntimeError('supervisor stderr')
                            selector.unregister(stream);continue
                        if not block:raise EOFError('supervisor result EOF')
                        self.output_bytes+=len(block);out.extend(block)
                        if len(out)>cap:raise ValueError('supervisor result cap')
                        if b'\n' in block:
                            if not out.endswith(b'\n') or out.count(b'\n')!=1 or payload is not None and offset!=len(payload):raise ValueError('supervisor result framing/order')
                            return bytes(out[:-1])
