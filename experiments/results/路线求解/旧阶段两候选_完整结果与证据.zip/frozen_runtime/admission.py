"""Finite source admission, not a security sandbox and never an executor.

This module parses and validates source only. In production it may be called
ONLY inside a resource-limited, fail-closed child after the host security gate.
Host tests in this package parse only reviewed handwritten test strings.
No candidate compile/eval/exec/import facility is implemented here.
"""
import ast
import hashlib
import io
import math
import re
import sys
import tokenize
from dataclasses import dataclass
from manifest import (API_SPECS, CONTRACT_VERSION, DTYPES, PYTHON_VERSION,
                      MAX_SOURCE_BYTES, MAX_AST_NODES, MAX_AST_DEPTH,
                      MAX_VECTOR, MAX_LOOP_DEPTH, MAX_LOOP_PRODUCT,
                      MAX_NUMBER_TOKEN, manifest_sha256)

class AdmissionError(ValueError):
    pass

# Exact _fields are frozen for CPython 3.12.14. No generic visit fallback.
FIELDS = {
    ast.Module: ('body', 'type_ignores'),
    ast.FunctionDef: ('name', 'args', 'body', 'decorator_list', 'returns', 'type_comment', 'type_params'),
    ast.arguments: ('posonlyargs', 'args', 'vararg', 'kwonlyargs', 'kw_defaults', 'kwarg', 'defaults'),
    ast.arg: ('arg', 'annotation', 'type_comment'),
    ast.Assign: ('targets', 'value', 'type_comment'),
    ast.AugAssign: ('target', 'op', 'value'),
    ast.If: ('test', 'body', 'orelse'),
    ast.For: ('target', 'iter', 'body', 'orelse', 'type_comment'),
    ast.Return: ('value',), ast.Break: (), ast.Continue: (),
    ast.Name: ('id', 'ctx'), ast.Constant: ('value', 'kind'),
    ast.List: ('elts', 'ctx'), ast.Tuple: ('elts', 'ctx'),
    ast.BinOp: ('left', 'op', 'right'), ast.UnaryOp: ('op', 'operand'),
    ast.BoolOp: ('op', 'values'), ast.Compare: ('left', 'ops', 'comparators'),
    ast.IfExp: ('test', 'body', 'orelse'),
    ast.Call: ('func', 'args', 'keywords'), ast.Attribute: ('value', 'attr', 'ctx'),
    ast.keyword: ('arg', 'value'), ast.Subscript: ('value', 'slice', 'ctx'),
    ast.Slice: ('lower', 'upper', 'step'),
    **{t: () for t in (ast.Load, ast.Store, ast.Add, ast.Sub, ast.Mult, ast.Div,
                      ast.FloorDiv, ast.Mod, ast.Pow, ast.UAdd, ast.USub, ast.Not,
                      ast.Invert, ast.And, ast.Or, ast.BitAnd, ast.BitOr, ast.BitXor,
                      ast.Eq, ast.NotEq, ast.Lt, ast.LtE, ast.Gt, ast.GtE)},
}
NUM = {'int', 'real', 'ivec', 'rvec'}
VEC = {'ivec', 'rvec', 'mask'}
BOOL = {'bool', 'mask'}
VALUE = NUM | BOOL
RESERVED = {'np', 'item', 'bins', 'score', 'len', 'range'}
IDENT = re.compile(r'[A-Za-z][A-Za-z0-9_]*\Z', re.ASCII)

@dataclass(frozen=True)
class Admission:
    source_sha256: str
    manifest_sha256: str
    policy_version: str
    node_count: int
    ast_depth: int
    called_apis: tuple
    # The eventual child must compile this exact object immediately, without
    # serialization, host transfer, transformations or candidate access.
    tree: ast.Module


def reject(reason):
    raise AdmissionError(reason)


def _int_literal(node):
    if type(node) is ast.Constant and type(node.value) is int:
        return node.value
    if type(node) is ast.UnaryOp and type(node.op) in (ast.UAdd, ast.USub):
        if type(node.operand) is ast.Constant and type(node.operand.value) is int:
            return node.operand.value if type(node.op) is ast.UAdd else -node.operand.value
    return None


def _number_literal(node):
    if type(node) is ast.Constant and type(node.value) in (int, float):
        return node.value
    if type(node) is ast.UnaryOp and type(node.op) in (ast.UAdd, ast.USub):
        value = _number_literal(node.operand)
        if value is not None:
            return value if type(node.op) is ast.UAdd else -value
    return None


def _is_len_bins(node):
    return (type(node) is ast.Call and type(node.func) is ast.Name and
            node.func.id == 'len' and not node.keywords and len(node.args) == 1 and
            type(node.args[0]) is ast.Name and node.args[0].id == 'bins')


def _join(a, b):
    if a == b:
        return a
    if a in NUM and b in NUM:
        return 'rvec' if a in VEC or b in VEC else 'real'
    reject('incompatible value types')


def _numeric(types):
    if any(t not in NUM for t in types):
        reject('numeric values required; sequence arithmetic is forbidden')


class Validator:
    def __init__(self):
        self.apis = set()
        self.loop_depth = 0
        self.loop_product = 1
        self.return_count = 0

    def name(self, name, *, target=False):
        if not IDENT.fullmatch(name) or '__' in name:
            reject('private, dunder or non-ASCII identifier')
        if target and name in RESERVED:
            reject('reserved name cannot be rebound')

    def target(self, node):
        if type(node) is not ast.Name or type(node.ctx) is not ast.Store:
            reject('only local-name assignment is admitted')
        self.name(node.id, target=True)
        return node.id

    def body(self, statements, env):
        env = dict(env)
        terminal = False
        for s in statements:
            if terminal:
                reject('unreachable statement after terminal control')
            kind = type(s)
            if kind is ast.Assign:
                if len(s.targets) != 1 or s.type_comment is not None:
                    reject('single assignment only; no type comments')
                name = self.target(s.targets[0]); value = self.expr(s.value, env)
                env[name] = value
            elif kind is ast.AugAssign:
                name = self.target(s.target)
                if name not in env:
                    reject('unbound augmented assignment')
                right = self.expr(s.value, env)
                if env[name] in VEC or right in VEC:
                    reject('vector augmented assignment is not admitted; use explicit local rebinding')
                env[name] = self.binary(s.op, env[name], right, s.value)
            elif kind is ast.Return:
                if s.value is None or self.expr(s.value, env) not in ('ivec', 'rvec'):
                    reject('return must be a numerical vector; final dtype/length checked by host')
                self.return_count += 1; terminal = True
            elif kind is ast.If:
                if self.expr(s.test, env) != 'bool':
                    reject('if condition must be scalar boolean')
                a, ta = self.body(s.body, env); b, tb = self.body(s.orelse, env)
                if ta and not tb:
                    env = b
                elif tb and not ta:
                    env = a
                else:
                    env = {k: _join(a[k], b[k]) for k in a.keys() & b.keys()}
                terminal = ta and tb
            elif kind is ast.For:
                name = self.target(s.target)
                if s.orelse or s.type_comment is not None:
                    reject('loop else and type comments are not admitted')
                bound = self.loop_bound(s.iter)
                if self.loop_depth >= MAX_LOOP_DEPTH or self.loop_product * max(1, bound) > MAX_LOOP_PRODUCT:
                    reject('nested loop bound exceeded')
                before = dict(env); loop_env = dict(env); loop_env[name] = 'int'
                self.loop_depth += 1; old_product = self.loop_product
                self.loop_product *= max(1, bound)
                after, _ = self.body(s.body, loop_env)
                self.loop_depth -= 1; self.loop_product = old_product
                # A loop may run zero times, or break/continue before a write.
                # New names do not become definitely assigned outside it.
                for key in before.keys() & after.keys():
                    env[key] = _join(before[key], after[key])
            elif kind in (ast.Break, ast.Continue):
                if not self.loop_depth:
                    reject('break/continue outside a loop')
                terminal = True
            else:
                reject('statement is outside the finite language')
        return env, terminal

    def loop_bound(self, node):
        if type(node) is ast.Name and node.id == 'bins':
            return MAX_VECTOR
        if (type(node) is ast.Call and type(node.func) is ast.Name and
                node.func.id == 'range' and len(node.args) == 1 and not node.keywords):
            arg = node.args[0]
            if _is_len_bins(arg):
                return MAX_VECTOR
            value = _int_literal(arg)
            if value is not None and 0 <= value <= MAX_VECTOR:
                return value
        reject('for accepts bins or range(literal/len(bins)) only')

    def binary(self, op, a, b, right):
        if type(op) in (ast.BitAnd, ast.BitOr, ast.BitXor):
            if a not in BOOL or b not in BOOL:
                reject('bitwise operators are restricted to booleans')
            return 'mask' if a == 'mask' or b == 'mask' else 'bool'
        _numeric([a, b])
        if type(op) is ast.Pow:
            exponent = _int_literal(right)
            if exponent is None or not -8 <= exponent <= 8:
                reject('power requires integer literal exponent -8..8')
        result = _join(a, b)
        if type(op) is ast.Div or (type(op) is ast.Pow and _int_literal(right) < 0):
            return 'rvec' if result in VEC else 'real'
        return result

    def expr(self, node, env):
        kind = type(node)
        if kind is ast.Constant:
            if node.kind is not None:
                reject('constant kind is not admitted')
            value = node.value
            if type(value) is bool:
                return 'bool'
            if type(value) is int and abs(value) <= 1000000:
                return 'int'
            if type(value) is float and math.isfinite(value) and abs(value) <= 1e100:
                return 'real'
            reject('only bounded finite numerical/boolean constants are admitted')
        if kind is ast.Name:
            self.name(node.id)
            if type(node.ctx) is not ast.Load or node.id not in env:
                reject('unbound name or callable/module alias')
            return env[node.id]
        if kind in (ast.List, ast.Tuple):
            if not 1 <= len(node.elts) <= MAX_VECTOR or type(node.ctx) is not ast.Load:
                reject('literal sequence length/context')
            types = [self.expr(x, env) for x in node.elts]
            if any(t not in ('int', 'real', 'bool') for t in types):
                reject('flat scalar numerical sequence required')
            return 'seq'
        if kind is ast.BinOp:
            return self.binary(node.op, self.expr(node.left, env), self.expr(node.right, env), node.right)
        if kind is ast.UnaryOp:
            value = self.expr(node.operand, env)
            if type(node.op) is ast.Not:
                if value != 'bool': reject('not requires scalar boolean')
                return 'bool'
            if type(node.op) is ast.Invert:
                if value not in BOOL: reject('invert requires boolean')
                return value
            _numeric([value]); return value
        if kind is ast.BoolOp:
            if any(self.expr(x, env) != 'bool' for x in node.values):
                reject('and/or require scalar booleans')
            return 'bool'
        if kind is ast.Compare:
            types = [self.expr(node.left, env)] + [self.expr(x, env) for x in node.comparators]
            if any(t not in VALUE for t in types): reject('comparison requires numerical/boolean values')
            if len(node.ops) > 1 and any(t in VEC for t in types):
                reject('chained vector comparison is ambiguous')
            return 'mask' if any(t in VEC for t in types) else 'bool'
        if kind is ast.IfExp:
            if self.expr(node.test, env) != 'bool': reject('conditional expression requires scalar boolean')
            return _join(self.expr(node.body, env), self.expr(node.orelse, env))
        if kind is ast.Subscript:
            value = self.expr(node.value, env)
            if value not in VEC or type(node.ctx) is not ast.Load:
                reject('only read-only one-dimensional numerical vector indexing')
            if type(node.slice) is ast.Slice:
                for part in (node.slice.lower, node.slice.upper, node.slice.step):
                    if part is not None and self.expr(part, env) != 'int': reject('slice bounds require integers')
                if node.slice.step is not None and _int_literal(node.slice.step) == 0:
                    reject('zero slice step')
                return value
            index = self.expr(node.slice, env)
            if index == 'int': return {'ivec':'int', 'rvec':'real', 'mask':'bool'}[value]
            if index in ('ivec', 'mask'): return value
            reject('index requires integer, integer vector or boolean mask')
        if kind is ast.Call:
            return self.call(node, env)
        reject('expression is outside the finite language')

    def call(self, node, env):
        if any(type(x) is ast.Starred for x in node.args): reject('starred arguments')
        names = [x.arg for x in node.keywords]
        if None in names or len(names) != len(set(names)): reject('expanded/duplicate keywords')
        if type(node.func) is ast.Name:
            if node.func.id == 'len' and len(node.args) == 1 and not names:
                if self.expr(node.args[0], env) not in VEC: reject('len requires numerical vector')
                return 'int'
            reject('only len(vector), bounded loop range and direct np API calls')
        if not (type(node.func) is ast.Attribute and type(node.func.value) is ast.Name and
                node.func.value.id == 'np' and type(node.func.ctx) is ast.Load):
            reject('call target must be a direct np API')
        name = node.func.attr
        if name not in API_SPECS: reject('NumPy API is not listed')
        lo, hi, keywords, rule = API_SPECS[name]
        if not lo <= len(node.args) <= hi or any(x not in keywords for x in names):
            reject('NumPy call arity/keyword contract')
        self.apis.add(name)
        args = [self.expr(x, env) for x in node.args]
        kw = {x.arg: x.value for x in node.keywords}
        dtype = None
        if 'dtype' in kw:
            d = kw['dtype']
            if not (type(d) is ast.Attribute and type(d.value) is ast.Name and
                    d.value.id == 'np' and d.attr in DTYPES and type(d.ctx) is ast.Load):
                reject('dtype must be an approved direct np constant')
            dtype = {'float64':'real', 'int64':'int', 'int32':'int', 'bool_':'bool'}[d.attr]
        if 'axis' in kw and _int_literal(kw['axis']) != 0: reject('only explicit axis=0')
        if 'n' in kw and _int_literal(kw['n']) not in (0, 1, 2): reject('diff n must be literal 0,1,2')
        def cast(t):
            if dtype is None: return t
            return {'real':'rvec', 'int':'ivec', 'bool':'mask'}[dtype] if t in VEC else dtype
        if rule == 'constructor':
            if args[0] not in VEC | {'seq'}: reject('constructor requires vector/flat sequence; scalar/0-D arrays excluded')
            return cast('rvec' if args[0] == 'seq' else args[0])
        if rule == 'bounded_integer_range':
            if any(t != 'int' for t in args): reject('arange requires integers')
            literals = [_int_literal(x) for x in node.args]
            if all(x is not None for x in literals):
                if len(literals) == 3 and literals[2] == 0: reject('arange zero step')
                if len(range(*literals)) > MAX_VECTOR: reject('arange static size cap')
            elif not (len(node.args) == 1 and _is_len_bins(node.args[0])):
                reject('arange requires integer literals or len(bins)')
            return cast('ivec')
        if rule in ('like', 'full_like', 'preserve', 'vector_preserve', 'integer_vector', 'difference'):
            if args[0] not in VEC: reject('vector input required')
            if rule == 'full_like' and args[1] not in ('int', 'real', 'bool'): reject('scalar fill value required')
            if rule == 'integer_vector': return 'ivec'
            return cast(args[0])
        if rule in ('elementwise', 'binary', 'clip'):
            _numeric(args)
            result = args[0]
            for other in args[1:]: result = _join(result, other)
            if name in ('exp', 'expm1', 'log', 'log1p', 'sqrt', 'cbrt'):
                result = 'rvec' if result in VEC else 'real'
            return result
        if rule == 'where':
            if args[0] not in BOOL: reject('where requires boolean condition')
            if not any(t in VEC for t in args): reject('all-scalar where creates excluded 0-D array')
            _numeric(args[1:]); result = _join(args[1], args[2])
            if args[0] == 'mask' and result not in VEC:
                result = 'ivec' if result == 'int' else 'rvec'
            return result
        if rule in ('reduction', 'integer_scalar', 'quantile'):
            if args[0] not in VEC: reject('reduction requires one-dimensional vector')
            if rule == 'integer_scalar': return 'int'
            if rule == 'quantile':
                q = _number_literal(node.args[1]); upper = 100 if name == 'percentile' else 1
                if q is None or not 0 <= q <= upper: reject('quantile requires a bounded scalar literal')
            return 'int' if name in ('sum', 'prod', 'min', 'max') and args[0] in ('ivec', 'mask') else 'real'
        if rule == 'searchsorted':
            if args[0] not in ('ivec', 'rvec') or args[1] not in NUM: reject('searchsorted numerical input')
            return 'ivec' if args[1] in VEC else 'int'
        if rule == 'reshape_one_dimension':
            shape = node.args[1]
            if args[0] not in VEC or type(shape) not in (ast.Tuple, ast.List) or len(shape.elts) != 1:
                reject('reshape requires a one-dimensional singleton shape')
            extent = _int_literal(shape.elts[0])
            if extent is None and not _is_len_bins(shape.elts[0]): reject('reshape extent must be literal/len(bins)')
            if extent is not None and not -1 <= extent <= MAX_VECTOR: reject('reshape extent bound')
            return args[0]
        if rule == 'ravel':
            if args[0] not in VALUE: reject('ravel numerical input')
            return {'int':'ivec', 'real':'rvec', 'bool':'mask'}.get(args[0], args[0])
        if rule == 'predicate':
            if args[0] not in VALUE: reject('predicate numerical input')
            return 'mask' if args[0] in VEC else 'bool'
        reject('unimplemented API rule')


def validate_source(source):
    """Return an admission record; do not execute or compile the returned AST.

    Only reviewed static fixtures may call this on the host. Eventual untrusted
    source processing belongs inside the already restricted child, not here in
    a parent holding credentials or future input data.
    """
    if type(source) is not bytes or len(source) > MAX_SOURCE_BYTES:
        reject('source must be exact bytes within cap')
    if sys.version_info[:3] != PYTHON_VERSION:
        reject('interpreter version is not frozen version')
    try:
        text = source.decode('utf-8', errors='strict')
        if '\x00' in text: reject('NUL in source')
        for token in tokenize.generate_tokens(io.StringIO(text).readline):
            if token.type == tokenize.NAME and not token.string.isascii():
                reject('non-ASCII identifier token')
            if token.type == tokenize.NUMBER and len(token.string) > MAX_NUMBER_TOKEN:
                reject('number token length cap')
            if token.type == tokenize.COMMENT and re.match(r'#\s*type\s*:', token.string):
                reject('type comments are forbidden')
        tree = ast.parse(text, filename='<candidate>', mode='exec', type_comments=True)
    except (SyntaxError, UnicodeError, tokenize.TokenError, IndentationError, RecursionError) as exc:
        raise AdmissionError('source parse failure') from exc
    stack = [(tree, 1)]; count = depth = 0
    while stack:
        node, level = stack.pop(); count += 1; depth = max(depth, level)
        if count > MAX_AST_NODES or depth > MAX_AST_DEPTH: reject('AST size/depth cap')
        expected = FIELDS.get(type(node))
        if expected is None or tuple(node._fields) != expected: reject('unknown AST node or field schema')
        for _, value in ast.iter_fields(node):
            if isinstance(value, ast.AST): stack.append((value, level + 1))
            elif type(value) is list:
                stack.extend((x, level + 1) for x in value if isinstance(x, ast.AST))
    if tree.type_ignores or len(tree.body) != 1 or type(tree.body[0]) is not ast.FunctionDef:
        reject('exactly one top-level score function is required')
    f = tree.body[0]; a = f.args
    if (f.name != 'score' or f.decorator_list or f.returns is not None or
            f.type_comment is not None or f.type_params or a.posonlyargs or a.vararg or
            a.kwonlyargs or a.kw_defaults or a.kwarg or a.defaults or
            [x.arg for x in a.args] != ['item', 'bins'] or
            any(x.annotation is not None or x.type_comment is not None for x in a.args)):
        reject('exact undecorated, unannotated score(item, bins) signature required')
    validator = Validator()
    _, terminal = validator.body(f.body, {'item':'int', 'bins':'ivec'})
    if not terminal or validator.return_count == 0:
        reject('all normal function paths must return numerical vectors')
    return Admission(hashlib.sha256(source).hexdigest(), manifest_sha256(),
                     CONTRACT_VERSION, count, depth, tuple(sorted(validator.apis)), tree)
