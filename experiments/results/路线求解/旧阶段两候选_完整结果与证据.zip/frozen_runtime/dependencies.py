"""Trusted dependency inventory. No fixture parse/compile or numerical calls."""
import hashlib
import json
import pathlib
import sys
import sysconfig
ROOT=pathlib.Path(__file__).resolve().parent

def digest(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        while block:=f.read(1024*1024):h.update(block)
    return h.hexdigest()

def mapped(pid='self'):
    paths=set()
    for line in pathlib.Path(f'/proc/{pid}/maps').read_text().splitlines():
        fields=line.split(None,5)
        if len(fields)==6 and fields[5].startswith('/'):
            paths.add(str(pathlib.Path(fields[5]).resolve(strict=True)))
    return paths

def inventory():
    paths=mapped()|{str(pathlib.Path(sys.executable).resolve()),'/usr/bin/prlimit','/usr/bin/timeout','/usr/bin/bash'}
    for module in tuple(sys.modules.values()):
        for attr in ('__file__','__cached__'):
            name=getattr(module,attr,None)
            if name and pathlib.Path(name).is_file():paths.add(str(pathlib.Path(name).resolve()))
    paths.update(str(p.resolve()) for p in pathlib.Path(sysconfig.get_path('purelib')).glob('*.pth'))
    return {p:digest(p) for p in sorted(paths) if not p.startswith(str(ROOT)+'/')}

def verify_files(expected):
    for path,sha in expected.items():
        if digest(path)!=sha:raise RuntimeError('dependency hash mismatch: '+path)

def load_freeze():
    raw=(ROOT/'pre_run_freeze.json').read_bytes()
    return json.loads(raw),hashlib.sha256(raw).hexdigest()

def load_worker_freeze():
    raw=(ROOT/'worker_freeze.json').read_bytes()
    return json.loads(raw),hashlib.sha256(raw).hexdigest()
