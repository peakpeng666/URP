"""Finite handwritten registry/IEEE tests; no data panels or generated code."""
import copy
import hashlib
import json
import os
import pathlib
import resource
import signal
import subprocess
import sys
import time
ROOT=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT))
from registry import FrozenRegistry,ExecutionJournal,freeze_wave,digest,sha,seal
from runner import Session,NumericalFailure
from protocol import source_frame,response,strict_json,MAX_SOURCE_FRAME
from policy import POLICY,policy_sha256
from dependencies import load_freeze,load_worker_freeze,verify_files,digest as file_sha
from test_support import candidate,claim,raw
from backend import RegistryBackend
from deployment import DeploymentFreeze
from registry import frozen_write
from checker import instance_identity
LAUNCH=json.loads((ROOT/'launch_state.json').read_text());START=LAUNCH['start_monotonic'];DEADLINE=START+55
PLAN=json.loads((ROOT/'test_plan.json').read_text())['gates']
ROWS=[];ALLOCATIONS=[];ACTIVE=None;WORKERS=0;CURRENT=PLAN[0]

def checkpoint():
    (ROOT/'live_ledger.json').write_text(json.dumps({'rows':ROWS,'allocations':ALLOCATIONS,'workers_reserved':WORKERS,'current_gate':CURRENT,'wall':time.monotonic()-START},indent=2)+'\n')
def record(name,**details):
    global CURRENT
    require(name==CURRENT and name in PLAN and all(row['test']!=name for row in ROWS),'gate plan order/identity')
    ROWS.append({'test':name,'passed':True,**details})
    CURRENT=PLAN[len(ROWS)] if len(ROWS)<len(PLAN) else None
    checkpoint()
def require(test,message):
    if not test:raise AssertionError(message)
def rejects(call):
    try:call()
    except (ValueError,TypeError,FileExistsError):return True
    return False

def reserve():
    global WORKERS
    require(WORKERS<20 and time.monotonic()<DEADLINE-5,'reservation bound')
    WORKERS+=1;ALLOCATIONS.append({'worker_number':WORKERS,'CPU_reserved':1});checkpoint()

def main():
    global ACTIVE
    require(len(PLAN)==41 and len(set(PLAN))==41,'fixed unique gate plan')
    checkpoint()
    require(resource.getrlimit(resource.RLIMIT_CPU)==(10,10),'host CPU')
    frozen,freeze_sha=load_freeze();_,runtime=load_worker_freeze()
    verify_files(frozen['dependencies']);verify_files({str(ROOT/n):h for n,h in frozen['files'].items()})
    record('frozen_runtime_dependencies',runtime_sha256=runtime)
    fixtures=json.loads((ROOT/'handwritten_fixtures.json').read_text())
    staged=[(candidate(name),claim(name),raw(candidate(name))) for name in fixtures]
    doc=freeze_wave(ROOT/'test_wave_registry.json',batch_id='registry-handwritten-batch',wave_id='handwritten-wave-0',phase=0,runtime_freeze_sha256=runtime,slots=staged)
    registry=FrozenRegistry(ROOT/'test_wave_registry.json',doc['sha256'])
    first,cl,raw_bytes=staged[0]
    base=registry.match(first,cl,raw_bytes)
    for field in ('code_sha256','description_sha256','pair_sha256'):
        bad=copy.deepcopy(first);bad[field]='0'*64
        require(rejects(lambda:registry.match(bad,cl,raw_bytes)),field);record('registry_reject_'+field)
    require(rejects(lambda:registry.match(first,cl,raw_bytes+b' ')),'raw mismatch');record('raw_response_independent_binding')
    bad=copy.deepcopy(cl);bad['slot_id']='unknown';bad.pop('sha256');bad=seal(bad)
    require(rejects(lambda:registry.match(first,bad,raw_bytes)),'slot mismatch');record('slot_mismatch')
    journal=ExecutionJournal(ROOT/'test_journal');token=journal.reserve(base,'test_once')
    require(rejects(lambda:journal.reserve(base,'test_once')),'replay');journal.finish(token,{'passed':True})
    require(rejects(lambda:journal.finish(token,{'passed':True})),'receipt replay');record('durable_slot_receipt_replay_rejected')
    # Source-frame identity tests call only the trusted bounded JSON/base64 helper.
    import base64
    frame={'v':3,'kind':'registered_source','source_b64':base64.b64encode(first['code'].encode()).decode(),'binding':base}
    for field in ('batch_id','wave_id','slot_id','raw_response_sha256','source_sha256','policy_sha256','runtime_freeze_sha256','claim_sha256','registry_sha256'):
        bad=copy.deepcopy(frame);bad['binding'][field]='0'*64
        require(rejects(lambda:source_frame(bad,runtime,digest(base))),'binding '+field);record('source_binding_reject_'+field)
    for name,fixture in fixtures.items():
        c=candidate(name);binding=registry.match(c,claim(name),raw(c));reserve()
        ACTIVE=Session(c,binding,wall=min(5,DEADLINE-time.monotonic()))
        outcome=fixture['kind'];failure=None;last=None
        if outcome in ('static','compile'):
            require(ACTIVE.admission['admitted'] is False and ACTIVE.admission['kind']==outcome,'admission kind')
        else:
            require(ACTIVE.admission['admitted'] is True,'fixture admitted')
            try:
                for _ in range(fixture['steps']):
                    values,best,events=ACTIVE.scores(fixture['item'],fixture['bins']);last={'scores':values,'argmax':best,'events':events}
                    if outcome=='ok':require(values==fixture['expected'],'exact fixture result')
                require(outcome=='ok','expected numerical failure')
            except NumericalFailure as exc:
                failure=exc.worker_evidence
                require(outcome=='numeric_failure','unexpected numerical failure')
                observed=failure['numerical_failure'];counts=observed['arithmetic_events']
                expected_counts={k:0 for k in POLICY['events']}
                if name=='nonfinite_final':
                    expected_counts['overflow']=1;expected_kind='NumericContractError';exceeded=False
                elif name=='placement_budget':
                    expected_counts['overflow']=65;expected_kind='ArithmeticBudgetExceeded';exceeded=True
                elif name=='python_warning_budget':
                    expected_counts.update(python_runtimewarning=33,invalid=32);expected_kind='ArithmeticBudgetExceeded';exceeded=True
                else:raise AssertionError('unplanned numerical failure')
                require(observed['exception_kind']==expected_kind and counts['budget_exceeded'] is exceeded,'exact numerical failure classification')
                require(counts['placement']==expected_counts and counts['instance']==expected_counts,'exact numerical failure event counts')
            if name in ('handled_divide','handled_overflow','handled_invalid','handled_underflow'):
                expected_counts={k:0 for k in POLICY['events']};expected_counts[name.removeprefix('handled_')]=1
                require(last['events']['placement']==expected_counts and last['events']['instance']==expected_counts,'exact handled event semantics')
            if name=='int64_exact':require(last['argmax']==1,'stable exact argmax')
            if name=='instance_accounting':require(last['events']['instance']['overflow']==4160,'cumulative warning count')
            if name=='handled_empty_mean':require(last['events']['placement']['python_runtimewarning']==1 and last['events']['placement']['invalid']==1,'empty mean event semantics')
        ACTIVE.close();evidence=ACTIVE.evidence();require(evidence['reaped'],'reaping')
        record(name,worker=evidence,last=last,exception_worker_evidence=failure);ACTIVE=None
    c=candidate('finite');binding=registry.match(c,claim('finite'),raw(c));reserve()
    ACTIVE=Session(c,binding,defer_source=True)
    from protocol import encode
    badframe={'v':3,'kind':'registered_source','source_b64':base64.b64encode((c['code']+'# mismatch').encode()).decode(),'binding':binding}
    admission=ACTIVE.admit(encode(badframe,MAX_SOURCE_FRAME))
    require(admission['admitted'] is False and admission['kind']=='source_protocol','worker rejects source mismatch')
    ACTIVE.close();record('postgate_worker_source_mismatch',worker=ACTIVE.evidence());ACTIVE=None
    events={'placement':{k:0 for k in POLICY['events']},'instance':{k:0 for k in POLICY['events']},'budget_exceeded':False}
    good={'v':3,'step':0,'scores':[10000000000000000,10000000000000001],'arithmetic_events':events,'dtype':'int64','binding_sha256':digest(binding),'score_call_cpu_ns':17}
    require(response(good,0,2,digest(binding))[0][1]==10000000000000001,'host exact integer')
    for case,field,value in [('dtype','dtype','float64'),('timing_bool','score_call_cpu_ns',True),('timing_range','score_call_cpu_ns',1000000001),('binding','binding_sha256','0'*64),('lossy_float','scores',[1.0,2.0])]:
        bad=copy.deepcopy(good);bad[field]=value
        require(rejects(lambda:response(bad,0,2,digest(binding))),'host metadata rejection');record('host_response_reject_'+case)
    # Real callback integration uses only a tiny handwritten parent-only instance.
    c=candidate('finite');slot='backend_finite'
    freeze=seal({'schema':'wave-freeze-v1','mode':'handwritten_registry_test','runtime_sha256':runtime,
        'policy_sha256':policy_sha256(),'isolation_profile_sha256':file_sha(ROOT/'ISOLATION.json'),
        'checker_sha256':file_sha(ROOT/'checker.py'),'intake_manifest_sha256':file_sha(ROOT/'INTAKE.json')})
    cl=claim(slot,freeze['sha256']);capture=raw(c)
    doc2=freeze_wave(ROOT/'backend_registry.json',batch_id=cl['run_id'],wave_id='backend-wave-0',phase=0,runtime_freeze_sha256=runtime,slots=[(c,cl,capture)])
    reg2=FrozenRegistry(ROOT/'backend_registry.json',doc2['sha256'])
    items=[2,3,4,2];capacity=100
    panel={'kind':'handwritten_registry_test','instances':[{'instance_index':0,'input_sha256':instance_identity(items,capacity),'n':4,'capacity':capacity,'L1':1}]}
    deployment=seal({'schema':'candidate-deployment-freeze-v1','mode':freeze['mode'],'source_origin':'handwritten_fixture',
        'registry_sha256':doc2['sha256'],'wave_freeze_sha256':freeze['sha256'],'batch_id':cl['run_id'],'wave_id':doc2['wave_id'],'phase':0,
        'runtime_freeze_sha256':runtime,'policy_sha256':policy_sha256(),'isolation_profile_sha256':freeze['isolation_profile_sha256'],
        'checker_sha256':freeze['checker_sha256'],'intake_manifest_sha256':freeze['intake_manifest_sha256'],
        'worker_cpu_seconds':1,'worker_as_bytes':536870912,'max_source_bytes':16384,'max_steps':5000,'max_instances':5})
    frozen_write(ROOT/'acceptance_deployment.json',deployment)
    activation=DeploymentFreeze(ROOT/'acceptance_deployment.json',deployment['sha256'])
    mislabeled=dict(freeze);mislabeled['mode']='registered_source_study'
    require(rejects(lambda:activation.validate(reg2,mislabeled)),'acceptance must not become study evidence')
    backend=RegistryBackend(reg2,ExecutionJournal(ROOT/'backend_journal'),raw_reader=lambda key:capture,instance_provider=lambda idx:{'items':list(items),'capacity':capacity},reserve_worker=reserve,deployment_freeze=activation)
    require(rejects(lambda:backend.bind_capture(cl,sha(capture+b' '))),'actual capture mismatch')
    backend.bind_capture(cl,sha(capture));bundle=backend.verify(c,cl,panel,freeze)
    require(bundle['admission']['admitted'] and bundle['scores'][0]['outcome']=='ok','real callback receipt')
    (ROOT/'backend_bundle.json').write_text(json.dumps(bundle,indent=2)+'\n')
    backend.bind_capture(cl,sha(capture))
    require(rejects(lambda:backend.verify(c,cl,panel,freeze)),'callback replay')
    record('real_backend_admission_scores_and_replay',bundle_sha256=bundle['sha256'])
    # Two dedicated helpers each inherit hard2CPU; numeric worker reserved1CPU.
    reserve()
    env={'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1'}
    p=subprocess.Popen(['/usr/bin/prlimit','--cpu=2:2','--',sys.executable,'-I','-B',str(ROOT/'harddeath_test.py'),str(os.getpid())],stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,start_new_session=True,close_fds=True)
    try:out,err=p.communicate(timeout=min(6,max(.1,DEADLINE-time.monotonic())))
    except BaseException:
        os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=2);raise
    require(p.returncode==0 and not err,'harddeath helper '+repr(err));hard=json.loads(out)
    require(hard['passed'] and hard['worker_cpu_seconds']<0.8 and hard['busy_no_read_fixture'],'harddeath evidence');record('harddeath_busy_no_read',evidence=hard)
    verify_files(frozen['dependencies']);verify_files({str(ROOT/n):h for n,h in frozen['files'].items()})
    require(WORKERS==20,'exact worker reservation count')
    record('postrun_frozen_identity')
    require(CURRENT is None and [row['test'] for row in ROWS]==PLAN,'complete exact plan before PASS')

if __name__=='__main__':
    status='passed';error=None;failure=None
    try:main()
    except BaseException as exc:
        status='failed';error=type(exc).__name__+': '+str(exc);failure=getattr(exc,'worker_evidence',None)
    finally:
        cleanup_error=None;active_evidence=None
        if ACTIVE is not None:
            try:ACTIVE.close(kill=True)
            except BaseException as exc:cleanup_error=type(exc).__name__+': '+str(exc)
            active_evidence=ACTIVE.evidence()
        own=resource.getrusage(resource.RUSAGE_SELF);children=resource.getrusage(resource.RUSAGE_CHILDREN)
        if status=='passed' and (cleanup_error is not None or CURRENT is not None or [row['test'] for row in ROWS]!=PLAN):
            status='failed';error=error or 'terminal cleanup/plan mismatch'
        failed_gate=CURRENT if status=='failed' else None
        completed={row['test'] for row in ROWS}
        not_run=[name for name in PLAN if name not in completed and name!=failed_gate]
        result={'failed_test':failed_gate,'failed':int(status!='passed'),'not_run':not_run,'planned':PLAN,'status':status,'error':error,'rows':ROWS,'passed':len(ROWS),'planned_numeric_workers_max':20,'workers_reserved':WORKERS,
            'exception_worker_evidence':failure,'final_active_worker':active_evidence,'cleanup_error':cleanup_error,
            'actual_host_CPU':own.ru_utime+own.ru_stime,'actual_children_CPU':children.ru_utime+children.ru_stime,
            'actual_total_CPU':own.ru_utime+own.ru_stime+children.ru_utime+children.ru_stime,'wall_seconds':time.monotonic()-START,
            'budget':{'total_CPU':40,'wall':60,'host':10,'prep':3,'workers_max':20,'worker_CPU':1,'helpers':4,'margin':3},
            'model_calls':0,'generated_source_executions':0,'data_panel_reads':0,'extra5000_replays':0}
        (ROOT/'results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':status,'passed':len(ROWS),'error':error,'workers':WORKERS}),flush=True)
    sys.exit(0 if status=='passed' else 1)
