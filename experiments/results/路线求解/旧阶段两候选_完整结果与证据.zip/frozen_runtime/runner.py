"""Supervisor owns every future item; a worker receives one current placement only."""
import hashlib
import base64
import json
import math
import fcntl
import os
import pathlib
import resource
import selectors
import signal
import stat
import subprocess
import sys
import time
from protocol import MAX_REQUEST, MAX_RESPONSE, MAX_SOURCE_FRAME, MAX_ADMISSION, MAX_AST_TEXT, encode, strict_json, request, response, numerical_failure
from dependencies import load_freeze,load_worker_freeze,mapped,digest as file_digest
from manifest import manifest_sha256,API_SPECS
from registry import digest as binding_digest,source_bytes
from policy import POLICY
from resource_profile import resolve_profile, role_limits, configured_limits, DIAGNOSTIC_PROFILE_ID

ROOT = pathlib.Path(__file__).resolve().parent
ENV = {'OPENBLAS_NUM_THREADS':'1', 'OMP_NUM_THREADS':'1', 'MKL_NUM_THREADS':'1',
       'NUMEXPR_NUM_THREADS':'1', 'BLIS_NUM_THREADS':'1', 'VECLIB_MAXIMUM_THREADS':'1',
       'LANG':'C.UTF-8', 'PYTHONDONTWRITEBYTECODE':'1'}
INSTANCE_OUTPUT = 600 * 1024**2
INSTANCE_INPUT = 160 * 1024**2
STDERR_CAP = 8192

class RunnerError(RuntimeError):
    pass


def kernel_status(pid):
    rows = pathlib.Path(f'/proc/{pid}/status').read_text().splitlines()
    names = ('Threads', 'NoNewPrivs', 'Seccomp', 'Seccomp_filters')
    return {k: int(v.strip()) for k, v in (row.split(':', 1) for row in rows) if k in names}


class NumericalFailure(RunnerError):
    pass


class WorkerEOF(RunnerError):
    """Typed transport failure; an EOF alone never establishes a resource cap."""
    pass


class ResourceLimitFailure(RunnerError):
    pass


class WallLimitFailure(ResourceLimitFailure):
    def __init__(self, *, scope, limit_seconds, observed_seconds, stage):
        if scope not in ('instance_wall', 'request_wall'):
            raise ValueError('wall limit scope')
        self.resource_limit = {
            'kind':scope+'_limit','scope': scope, 'limit_seconds': limit_seconds,
            'observed_seconds': observed_seconds,
            'trigger': 'parent_monotonic_deadline', 'stage': stage,
            'signal': None, 'returncode': None,
        }
        super().__init__(scope + ' deadline reached')


class WorkerCPULimitFailure(ResourceLimitFailure):
    def __init__(self, *, limit_seconds, observed_seconds, stage):
        self.resource_limit = {
            'kind':'worker_cpu_limit','scope': 'worker_cpu', 'limit_seconds': limit_seconds,
            'observed_seconds': observed_seconds,
            'trigger': 'wait4_sigkill_cpu_near_cap', 'stage': stage,
            'signal': signal.SIGKILL, 'returncode': -signal.SIGKILL,
        }
        super().__init__('worker CPU cap evidence rule satisfied')

class Session:
    def __init__(self, candidate, binding, *, worker_role='instance',
                 execution_id=None, instance_index=None, absolute_deadline=None,
                 instance_started=None, fixture=None, io_chunk=16384,
                 pipe_size=None, defer_source=False):
        # Resolve a closed registry-bound profile before touching source or spawning.
        self.binding=dict(binding)
        self.resource_profile_sha256=binding['resource_profile_sha256']
        self.profile=resolve_profile(self.resource_profile_sha256)
        self.worker_role=worker_role
        self.role=role_limits(self.resource_profile_sha256,worker_role)
        self.configured_limits=configured_limits(self.resource_profile_sha256,worker_role)
        cpu_limit=self.role['cpu_seconds']
        self.score_cpu_bound_ns=cpu_limit*1000000000
        if execution_id is not None and (type(execution_id) is not str or not 1<=len(execution_id)<=256):raise ValueError('execution identity')
        if instance_index is not None and (type(instance_index) is not int or not 0<=instance_index<5):raise ValueError('instance index')
        self.execution_id=execution_id;self.instance_index=instance_index
        self.started=time.monotonic()
        if (absolute_deadline is None)!=(instance_started is None):raise ValueError('shared deadline pair')
        if absolute_deadline is not None:
            if any(type(x) not in (int,float) or not math.isfinite(x) for x in (absolute_deadline,instance_started)):raise ValueError('shared deadline type')
            if instance_started>self.started or not instance_started<absolute_deadline:raise ValueError('shared deadline ordering')
        self.instance_started=self.started if instance_started is None else instance_started
        own_deadline=self.instance_started+self.role['wall_seconds']
        self.total_wall_deadline=own_deadline if absolute_deadline is None else min(own_deadline,absolute_deadline)
        # The fixed wall budget includes startup and the existing two-second
        # cleanup allowance. Requests may consume only the remaining active time.
        self.deadline=self.total_wall_deadline-self.profile['cleanup_wall_seconds']
        self.active_wall_limit_seconds=self.deadline-self.instance_started
        self.request_wall=self.role['request_wall_seconds']
        self.step=0
        self.assignment_complete=False
        self.terminal_reason=None
        self.resource_limit=None
        self.cpu_cap_evidence=None
        self.failure_stage='startup'
        self.parent_kill_attempted=False
        self.parent_kill_sent=False
        self.cleanup_error=None
        self.first_exception=None
        freeze,self.suite_freeze_sha=load_freeze()
        _,self.freeze_sha=load_worker_freeze()
        self.freeze=freeze
        self.source=source_bytes(candidate)
        if binding['runtime_freeze_sha256']!=self.freeze_sha or binding['source_sha256']!=hashlib.sha256(self.source).hexdigest():raise ValueError('frozen source/runtime identity')
        self.source_id=binding['slot_id']
        self.source_entry={'sha256':binding['source_sha256']}
        self.fixture=fixture
        if fixture is not None and (self.profile['profile_id']!=DIAGNOSTIC_PROFILE_ID or fixture not in ('shutdown_tail','cpu','wall','memory','no_read','partial','malformed_response','open_deny')):raise ValueError('fixed diagnostic fault whitelist')
        if pipe_size is not None and (fixture != 'no_read' or pipe_size != 4096):raise ValueError('pipe resize whitelist')
        if type(io_chunk) is not int or not 1<=io_chunk<=65536:raise ValueError('I/O chunk bound')
        self.control=binding_digest(binding)
        self.event_total={name:0 for name in POLICY['events']}
        self.last_numerical_failure=None
        self.score_call_cpu_ns=0
        self.max_placement_event_count=0
        self.arithmetic_steps_checked=0
        self.source_sent=False
        self.admission=None
        self.io_chunk = io_chunk
        self.input_bytes = self.output_bytes = self.stderr_bytes = 0
        self.write_calls = self.read_calls = self.short_writes = 0
        self.out_hash = hashlib.sha256()
        self.in_hash = hashlib.sha256()
        self.stderr = bytearray()
        self.reaped = False
        self.usage = None
        self.returncode = None
        self.security = None
        self.transcript = []
        parent_security = kernel_status(os.getpid())
        self.expected_filters = parent_security.get('Seccomp_filters', 0) + 1
        script = ROOT / ('worker.py' if fixture is None else 'fixture_worker.py')
        argument = fixture
        # Limits are installed by trusted prlimit BEFORE CPython/NumPy startup.
        command = ['/usr/bin/prlimit', '--as=536870912:536870912', f'--cpu={cpu_limit}:{cpu_limit}',
                   '--core=0:0', '--fsize=0:0', '--nofile=32:32', '--',
                   sys.executable, '-I', '-B', str(script), *([argument] if fixture else []), str(cpu_limit),str(os.getpid()),*([self.control,self.resource_profile_sha256,self.worker_role] if fixture is None else [])]
        if time.monotonic()>=self.deadline:raise RunnerError('active deadline expired before worker spawn')
        self.p = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                  stderr=subprocess.PIPE, cwd=ROOT, env=ENV, close_fds=True,
                                  start_new_session=True, bufsize=0, pipesize=-1 if pipe_size is None else pipe_size)
        self.sel = None
        try:
            self.sel = selectors.DefaultSelector()
            for f in (self.p.stdin, self.p.stdout, self.p.stderr):
                os.set_blocking(f.fileno(), False)
            self.sel.register(self.p.stdout, selectors.EVENT_READ)
            self.sel.register(self.p.stderr, selectors.EVENT_READ)
            ready = self._frame(None, self.started + self.role['startup_wall_seconds'], 64, stage='startup', request_started=self.started, request_limit=self.role['startup_wall_seconds'])
            if strict_json(ready, 64) != {'ready': 2} or ready != b'{"ready":2}':
                raise RunnerError('bad ready frame')
            self.security = kernel_status(self.p.pid)
            expected = {'Threads':1, 'NoNewPrivs':1, 'Seccomp':2, 'Seccomp_filters':self.expected_filters}
            if self.security != expected:
                raise RunnerError('host-observed security gate mismatch')
            limits = pathlib.Path(f'/proc/{self.p.pid}/limits').read_text()
            for label, soft, hard in [('Max cpu time', str(cpu_limit), str(cpu_limit)), ('Max address space', '536870912', '536870912'), ('Max open files', '3', '3'), ('Max file size', '0', '0'), ('Max core file size', '0', '0')]:
                matching = [r for r in limits.splitlines() if r.startswith(label)]
                if len(matching) != 1 or matching[0][len(label):].split()[:2] != [soft, hard]:
                    raise RunnerError('host-observed resource gate mismatch')
            self.host_observed_limits={'cpu_seconds':[cpu_limit,cpu_limit],'address_space_bytes':[536870912,536870912],'open_files':[3,3],'file_size_bytes':[0,0],'core_bytes':[0,0]}
            links = []
            for number, stream in enumerate((self.p.stdin, self.p.stdout, self.p.stderr)):
                child_fd = f'/proc/{self.p.pid}/fd/{number}'
                link = os.readlink(child_fd)
                if not link.startswith('pipe:[') or link != os.readlink(f'/proc/self/fd/{stream.fileno()}') or not stat.S_ISFIFO(os.stat(child_fd).st_mode):
                    raise RunnerError('private pipe verification failed')
                links.append(link)
            if len(set(links)) != 3 or set(os.listdir(f'/proc/{self.p.pid}/fd')) != {'0','1','2'}:
                raise RunnerError('unexpected inherited descriptor')
            self.fd_evidence = links
            self.pipe_capacities = [fcntl.fcntl(f.fileno(),fcntl.F_GETPIPE_SZ) for f in (self.p.stdin,self.p.stdout,self.p.stderr)]
            if pipe_size is not None and self.pipe_capacities != [pipe_size]*3:
                raise RunnerError('requested private pipe capacity not observed')
            status_rows={r.split(':',1)[0]:r.split(':',1)[1].strip() for r in pathlib.Path(f'/proc/{self.p.pid}/status').read_text().splitlines()}
            if int(status_rows['Pid'])!=self.p.pid or int(status_rows['PPid'])!=os.getpid():raise RunnerError('true PID/parent mismatch')
            if pathlib.Path(f'/proc/{self.p.pid}/exe').resolve()!=pathlib.Path(sys.executable).resolve():raise RunnerError('executable mismatch')
            deps=mapped(self.p.pid)
            if deps-set(freeze['dependencies']):raise RunnerError('unfrozen worker mapping')
            for name in deps:
                if file_digest(name)!=freeze['dependencies'][name]:raise RunnerError('mapped dependency hash mismatch')
            self.mapped_dependencies=sorted(deps)
            self.security_checked_at=time.monotonic()
            self.startup_seconds=time.monotonic()-self.started
            if fixture is None and not defer_source:self.admit()
        except BaseException as exc:
            preserved=self._preserve_failure(exc,kill=True)
            if preserved is not exc:raise preserved from exc
            raise

    def _read(self, stream, n):
        while True:
            try:
                block = os.read(stream.fileno(), n)
                self.read_calls += 1
                return block
            except InterruptedError:
                continue

    def _idle_check(self):
        for f in (self.p.stdout, self.p.stderr):
            try:
                block = self._read(f, 1)
            except BlockingIOError:
                continue
            if block:
                raise RunnerError('unsolicited stdout/stderr')
            raise WorkerEOF('worker exited before next request')

    def _frame(self, payload, deadline, cap, *, stage='score', request_started=None, request_limit=None):
        self.failure_stage=stage
        if request_started is None:request_started=time.monotonic()
        if request_limit is None:request_limit=self.request_wall
        out = bytearray()
        offset = 0
        if payload is not None:
            self._idle_check()
            if self.input_bytes + len(payload) > INSTANCE_INPUT:
                raise RunnerError('cumulative input cap')
            self.sel.register(self.p.stdin, selectors.EVENT_WRITE)
        try:
            while True:
                now=time.monotonic()
                remaining = min(deadline, self.deadline) - now
                if remaining <= 0:
                    instance_limit=self.deadline<=deadline
                    raise WallLimitFailure(scope='instance_wall' if instance_limit else 'request_wall',
                        limit_seconds=self.active_wall_limit_seconds if instance_limit else request_limit,
                        observed_seconds=now-(self.instance_started if instance_limit else request_started),stage=stage)
                for key, mask in self.sel.select(min(remaining, .05)):
                    f = key.fileobj
                    if f is self.p.stdin:
                        part = payload[offset:offset + self.io_chunk]
                        try:
                            n = os.write(f.fileno(), part)
                        except (BlockingIOError, InterruptedError):
                            continue
                        except BrokenPipeError as exc:
                            raise WorkerEOF('mid-request broken pipe') from exc
                        if n <= 0:
                            raise RunnerError('write did not progress')
                        self.write_calls += 1
                        self.short_writes += int(n < len(part))
                        self.in_hash.update(part[:n])
                        offset += n
                        self.input_bytes += n
                        if offset == len(payload):
                            self.sel.unregister(self.p.stdin)
                    elif f is self.p.stderr:
                        try:
                            block = self._read(f, min(self.io_chunk, STDERR_CAP + 1 - len(self.stderr)))
                        except BlockingIOError:
                            continue
                        if not block:
                            self.sel.unregister(f)
                        else:
                            self.stderr.extend(block)
                            self.stderr_bytes += len(block)
                            raise RunnerError('unexpected stderr' if len(self.stderr) <= STDERR_CAP else 'stderr cap')
                    else:
                        try:
                            block = self._read(f, min(self.io_chunk, cap + 1 - len(out)))
                        except BlockingIOError:
                            continue
                        if not block:
                            raise WorkerEOF('mid-response EOF')
                        self.output_bytes += len(block)
                        self.out_hash.update(block)
                        if self.output_bytes > INSTANCE_OUTPUT:
                            raise RunnerError('cumulative output cap')
                        out.extend(block)
                        if len(out) > cap:
                            raise RunnerError('response frame cap')
                        if b'\n' in block:
                            if not out.endswith(b'\n') or out.count(b'\n') != 1:
                                raise RunnerError('extra/multiline response')
                            if payload is not None and offset != len(payload):
                                raise RunnerError('response before complete request')
                            # At most one frame may be buffered. Request IDs catch delayed repeats.
                            for check in (self.p.stdout, self.p.stderr):
                                try:
                                    trailing = self._read(check, 1)
                                except BlockingIOError:
                                    continue
                                if trailing:
                                    raise RunnerError('trailing or unsolicited output')
                            return bytes(out[:-1])
        finally:
            if payload is not None:
                try:
                    self.sel.unregister(self.p.stdin)
                except KeyError:
                    pass

    def _reap_if_exited(self):
        if self.reaped:return
        pid,status,usage=os.wait4(self.p.pid,os.WNOHANG)
        if pid:
            self.returncode=os.waitstatus_to_exitcode(status)
            self.p.returncode=self.returncode
            self.usage=usage
            self.reaped=True

    def _preserve_failure(self,exc,kill=True):
        prior=getattr(exc,'worker_evidence',None)
        if self.first_exception is None:
            self.first_exception={'type':type(exc).__name__,'message':str(exc)[:1024]}
        cleanup_error=None
        if not hasattr(self,'failure_cleanup_started'):self.failure_cleanup_started=time.monotonic()
        try:
            if isinstance(exc,WorkerEOF) and not self.reaped:
                # EOF precedes waitability on some schedules. A short natural-reap
                # interval preserves evidence without manufacturing SIGKILL.
                until=time.monotonic()+0.05
                while not self.reaped:
                    self._reap_if_exited()
                    if self.reaped or time.monotonic()>=until:break
                    time.sleep(.001)
            if isinstance(exc,WorkerEOF) and self.reaped and not self.parent_kill_attempted:
                # A wait4 CPU receipt is insufficient if stderr/tail was never read.
                for stream in (self.p.stdout,self.p.stderr):
                    if stream.closed:continue
                    block=self._read(stream,1)
                    if block:
                        if stream is self.p.stderr:
                            self.stderr.extend(block);self.stderr_bytes+=len(block)
                        raise RunnerError('unexpected output after worker EOF')
            self.close(kill=kill)
        except BaseException as cleanup:
            cleanup_error=type(cleanup).__name__+': '+str(cleanup)[:1024]
            try:self.close(kill=True)
            except BaseException as final_cleanup:
                cleanup_error+='; '+type(final_cleanup).__name__+': '+str(final_cleanup)[:1024]
        self.cleanup_error=cleanup_error or self.cleanup_error or (prior or {}).get('cleanup_error')
        cpu=None if self.usage is None else self.usage.ru_utime+self.usage.ru_stime
        limit=self.role['cpu_seconds']
        if (isinstance(exc,WorkerEOF) and self.reaped and not self.parent_kill_attempted
                and self.returncode == -signal.SIGKILL and not self.stderr
                and self.cleanup_error is None and cpu is not None
                and limit-0.05<=cpu<=limit+1.0):
            exc=WorkerCPULimitFailure(limit_seconds=limit,observed_seconds=cpu,stage=self.failure_stage)
            self.cpu_cap_evidence={'typed_eof':True,'natural_wait4_reap':True,
                'near_cap_tolerance_seconds':{'below':0.05,'above':1.0},'os_confirmed_cause':False}
        if isinstance(exc,ResourceLimitFailure):
            # Cleanup failure or incomplete arithmetic evidence is integrity failure,
            # even if a timeout was the first observed exception.
            self.resource_limit=dict(exc.resource_limit)
            self.resource_limit['returncode']=self.returncode
            self.resource_limit['signal']=-self.returncode if self.returncode is not None and self.returncode<0 else None
            exc.resource_limit=dict(self.resource_limit)
            expected_exit=(self.parent_kill_sent and self.returncode==-signal.SIGKILL
                           if isinstance(exc,WallLimitFailure) else
                           not self.parent_kill_attempted and self.returncode==-signal.SIGKILL)
            valid=(self.reaped and self.cleanup_error is None and self.last_numerical_failure is None
                   and self.arithmetic_steps_checked==self.step and expected_exit)
            self.terminal_reason=dict(self.resource_limit) if valid else None
            if not valid:exc=RunnerError('resource limit cleanup/evidence integrity failure')
        else:self.terminal_reason=None
        self.assignment_complete=False
        exc.worker_evidence=self.evidence()
        exc.worker_evidence['exception']=self.first_exception['type']+': '+self.first_exception['message']
        if prior is not None:
            first=prior.get('first_failure_evidence',prior)
            exc.worker_evidence['first_failure_evidence']={k:v for k,v in first.items() if k!='first_failure_evidence'}
        return exc

    def admit(self,raw_override=None):
        try:return self._admit(raw_override)
        except BaseException as exc:
            preserved=self._preserve_failure(exc,kill=True)
            if preserved is not exc:raise preserved from exc
            raise

    def _admit(self,raw_override=None):
        if self.source_sent or self.security is None:raise RunnerError('source state violation')
        obj={'v':3,'kind':'registered_source','source_b64':base64.b64encode(self.source).decode('ascii'),'binding':self.binding}
        payload=encode(obj,MAX_SOURCE_FRAME) if raw_override is None else raw_override
        if type(payload) is not bytes or len(payload)>MAX_SOURCE_FRAME:raise ValueError('source frame size')
        self.source_sent=True;self.source_sent_at=time.monotonic()
        request_started=time.monotonic()
        value=strict_json(self._frame(payload,request_started+self.request_wall,MAX_ADMISSION,stage='admission',request_started=request_started),MAX_ADMISSION)
        if type(value) is not dict or value.get('binding_sha256')!=self.control:raise RunnerError('admission binding/schema')
        if value.get('resource_profile_sha256')!=self.resource_profile_sha256 or value.get('worker_role')!=self.worker_role:raise RunnerError('admission resource profile/role')
        if type(value.get('open_denials')) is not int or not 0<=value['open_denials']<=1024:raise RunnerError('audit evidence schema')
        if value.get('admitted') is False:
            if set(value)!={'admitted','kind','binding_sha256','resource_profile_sha256','worker_role','open_denials'} or value['kind'] not in ('source_protocol','static','compile'):raise RunnerError('rejection schema')
            self.admission=value;return value
        if set(value)!={'admitted','source_sha256','manifest_sha256','node_count','ast_depth','apis','canonical_text','binding_sha256','resource_profile_sha256','worker_role','open_denials'} or value['admitted'] is not True:raise RunnerError('admission fields')
        if value['source_sha256']!=self.binding['source_sha256'] or value['manifest_sha256']!=manifest_sha256():raise RunnerError('admission identity')
        if type(value['node_count']) is not int or not 1<=value['node_count']<=4096 or type(value['ast_depth']) is not int or not 1<=value['ast_depth']<=64:raise RunnerError('admission bounds')
        text=value['canonical_text']
        if type(text) is not str or not 0<len(text.encode('utf-8'))<=MAX_AST_TEXT:raise RunnerError('canonical text bound')
        apis=value['apis']
        if type(apis) is not list or len(apis)>46 or any(type(x) is not str or x not in API_SPECS for x in apis) or len(set(apis))!=len(apis):raise RunnerError('admission APIs')
        self.admission=value;return value

    def scores(self, item, bins):
        try:
            if self.worker_role!='instance':raise RunnerError('admission-only worker forbids placements')
            if self.fixture is None and (self.admission is None or self.admission.get('admitted') is not True):raise RunnerError('numeric request requires successful admission')
            obj = {'v':2, 'step':self.step, 'item':item, 'bins':bins}
            request(obj, self.step)
            payload = encode(obj, MAX_REQUEST)
            request_started=time.monotonic()
            raw = self._frame(payload, request_started + self.request_wall, MAX_RESPONSE,stage='score',request_started=request_started)
            parsed=strict_json(raw,MAX_RESPONSE)
            if numerical_failure(parsed,self.step,self.control,self.resource_profile_sha256,self.worker_role):
                self.last_numerical_failure=parsed
                self.score_call_cpu_ns+=parsed['score_call_cpu_ns']
                if self.score_call_cpu_ns>self.score_cpu_bound_ns:raise RunnerError('failure cumulative score CPU metadata')
                counts=parsed['arithmetic_events']
                if any(counts['instance'][name]!=self.event_total[name]+counts['placement'][name] for name in POLICY['events']):raise RunnerError('failure arithmetic event sequence')
                self.event_total=dict(counts['instance'])
                self.max_placement_event_count=max(self.max_placement_event_count,sum(counts['placement'].values()))
                self.arithmetic_steps_checked+=1
                raise NumericalFailure('restricted numerical evaluation rejected')
            values,events=response(parsed,self.step,len(bins),self.control,self.resource_profile_sha256,self.worker_role)
            if any(events['instance'][name]!=self.event_total[name]+events['placement'][name] for name in POLICY['events']):raise RunnerError('arithmetic event sequence')
            self.event_total=dict(events['instance'])
            self.score_call_cpu_ns+=parsed['score_call_cpu_ns']
            if self.score_call_cpu_ns>self.score_cpu_bound_ns:raise RunnerError('cumulative score CPU metadata')
            self.max_placement_event_count=max(self.max_placement_event_count,sum(events['placement'].values()))
            self.arithmetic_steps_checked+=1
            # Stable first argmax is computed only here, after complete validation.
            argmax = max(range(len(values)), key=values.__getitem__)
            self.step += 1
            return values, argmax, events
        except BaseException as exc:
            preserved=self._preserve_failure(exc,kill=not isinstance(exc,NumericalFailure))
            if preserved is not exc:raise preserved from exc
            raise

    def send_fixture_raw(self, raw):
        if type(raw) is not bytes or len(raw) > MAX_REQUEST + 1:
            raise ValueError('test fixture size')
        request_started=time.monotonic()
        return self._frame(raw, request_started + self.request_wall, MAX_RESPONSE,stage='score',request_started=request_started)

    def close(self, kill=False):
        if self.reaped and all(f.closed for f in (self.p.stdin,self.p.stdout,self.p.stderr)):
            return
        begin = getattr(self,'failure_cleanup_started',time.monotonic())
        error = None
        if not self.p.stdin.closed:
            self.p.stdin.close()
        killed = False
        eof = set()
        def terminate():
            nonlocal killed
            if killed or self.reaped:
                return
            self.parent_kill_attempted=True
            try:
                os.killpg(self.p.pid, signal.SIGKILL)
                self.parent_kill_sent=True
            except ProcessLookupError:
                pass
            killed = True
        if kill:
            self._reap_if_exited()
            terminate()
        cleanup_deadline=min(begin+self.profile['cleanup_wall_seconds'],self.total_wall_deadline)
        deadline = min(begin + 1,cleanup_deadline)
        try:
            while time.monotonic() < deadline:
                if not self.reaped:
                    pid, status, usage = os.wait4(self.p.pid, os.WNOHANG)
                    if pid:
                        self.returncode = os.waitstatus_to_exitcode(status)
                        self.p.returncode = self.returncode
                        self.usage = usage
                        self.reaped = True
                # Even forced teardown must inspect bounded stderr before closure.
                if kill and self.p.stderr not in eof and len(self.stderr)<=STDERR_CAP:
                    try:block=self._read(self.p.stderr,min(self.io_chunk,STDERR_CAP+1-len(self.stderr)))
                    except BlockingIOError:block=None
                    if block:
                        self.stderr.extend(block);self.stderr_bytes+=len(block)
                        error=error or 'unexpected stderr during cleanup'
                    elif block==b'':eof.add(self.p.stderr)
                # Reaping does NOT imply pipes empty: inspect tail even after wait4.
                if not kill:
                    for f in (self.p.stdout, self.p.stderr):
                        if f in eof:
                            continue
                        try:
                            block = self._read(f, 1)
                        except BlockingIOError:
                            continue
                        if block:
                            error = 'unexpected output at shutdown'
                            terminate()
                            kill = True
                            break
                        eof.add(f)
                if self.reaped and (kill or len(eof) == 2):
                    break
                time.sleep(.002)
            if not self.reaped:
                terminate()
                # One additional bounded cleanup second, never silently leak.
                until = cleanup_deadline
                while time.monotonic() < until:
                    pid,status,usage=os.wait4(self.p.pid,os.WNOHANG)
                    if pid:
                        self.returncode=os.waitstatus_to_exitcode(status)
                        self.p.returncode=self.returncode
                        self.usage=usage
                        self.reaped=True
                        break
                    time.sleep(.002)
                error = error or 'normal shutdown timed out'
            if not self.reaped:
                error = 'cleanup deadline: worker not reaped'
            elif not kill and len(eof) != 2:
                error = error or 'cleanup deadline: missing pipe EOF'
        finally:
            if self.sel is not None:
                self.sel.close()
            for f in (self.p.stdin,self.p.stdout,self.p.stderr):
                f.close()
        cleanup_finished=time.monotonic()
        self.cleanup_seconds=cleanup_finished-begin
        if cleanup_finished>self.total_wall_deadline:error=error or 'cleanup exceeded total wall deadline'
        if not kill and self.returncode != 0:error=error or 'nonzero worker exit '+str(self.returncode)
        if error:
            self.cleanup_error=error
            raise RunnerError(error)

    def evidence(self):
        return {'resource_profile_sha256':self.resource_profile_sha256,'resource_profile_id':self.profile['profile_id'],'worker_role':self.worker_role,'configured_limits':dict(self.configured_limits),'execution_id':self.execution_id,'instance_index':self.instance_index,'terminal_reason':self.terminal_reason,'resource_limit':self.resource_limit,'cpu_cap_evidence':self.cpu_cap_evidence,'assignment_complete':self.assignment_complete,'first_exception':self.first_exception,'cleanup_error':self.cleanup_error,'parent_kill_attempted':self.parent_kill_attempted,'parent_kill_sent':self.parent_kill_sent,'registry_binding':dict(self.binding),'arithmetic_events':dict(self.event_total),'max_placement_event_count':self.max_placement_event_count,'arithmetic_steps_checked':self.arithmetic_steps_checked,'score_call_cpu_ns':self.score_call_cpu_ns,'score_timing_scope':'function call including facade; excludes prep/check/serialization','numerical_failure':self.last_numerical_failure,'source_id':self.source_id,'source_sha256':self.source_entry['sha256'],'source_sent':self.source_sent,'source_after_host_gate':not self.source_sent or self.source_sent_at>=self.security_checked_at,'admission':self.admission,'dependency_freeze_sha256':self.freeze_sha,'mapped_dependencies':getattr(self,'mapped_dependencies',None),'pid':self.p.pid, 'security':self.security,'host_observed_limits':getattr(self,'host_observed_limits',None), 'private_pipes':getattr(self,'fd_evidence',None), 'steps':self.step, 'pipe_capacities':getattr(self,'pipe_capacities',None),
                'reaped':self.reaped, 'returncode':self.returncode,
                'wall_seconds':time.monotonic()-self.started,
                'absolute_deadline':self.deadline,'total_wall_deadline':self.total_wall_deadline,'instance_started':self.instance_started,
                'instance_wall_seconds':time.monotonic()-self.instance_started,
                'active_completed_at':getattr(self,'active_completed_at',None),
                'startup_seconds':getattr(self, 'startup_seconds', None),
                'cleanup_seconds':getattr(self, 'cleanup_seconds', None),
                'cpu_seconds':None if self.usage is None else self.usage.ru_utime+self.usage.ru_stime,
                'peak_rss_kib':None if self.usage is None else self.usage.ru_maxrss,
                'input_bytes':self.input_bytes, 'output_bytes':self.output_bytes,
                'write_calls':self.write_calls, 'read_calls':self.read_calls,
                'short_writes':self.short_writes, 'input_sha256':self.in_hash.hexdigest(),
                'output_sha256':self.out_hash.hexdigest(), 'stderr_bytes':self.stderr_bytes}


def pack(items, capacity, candidate, binding, *, reserve_worker=None, **kwargs):
    if type(items) is not list or not 1 <= len(items) <= 5000 or type(capacity) is not int or capacity not in (100, 500):
        raise ValueError('instance shape')
    if any(type(x) is not int or not 1 <= x <= min(100, capacity) for x in items):
        raise ValueError('instance item domain')
    bins = [capacity] * len(items)
    assignment = []
    counts = []
    events = {name:0 for name in POLICY['events']}
    if reserve_worker is not None:reserve_worker()
    worker = Session(candidate, binding, **kwargs)
    try:
        for item in items:
            feasible = [i for i, b in enumerate(bins) if b >= item]
            counts.append(len(feasible))
            _, chosen, arithmetic = worker.scores(item, [bins[i] for i in feasible])
            target = feasible[chosen]
            if bins[target] < item:
                raise RunnerError('supervisor feasibility check')
            bins[target] -= item
            assignment.append(target)
            events=dict(arithmetic['instance'])
        if sum(items) != sum(capacity - b for b in bins) or any(b < 0 for b in bins):
            raise RunnerError('supervisor conservation check')
        active_completed_at=time.monotonic()
        if active_completed_at>=worker.deadline:
            raise WallLimitFailure(scope='instance_wall',limit_seconds=worker.active_wall_limit_seconds,
                observed_seconds=active_completed_at-worker.instance_started,stage='score')
        worker.active_completed_at=active_completed_at
        worker.close()
    except BaseException as exc:
        preserved=worker._preserve_failure(exc,kill=True)
        if preserved is not exc:raise preserved from exc
        raise
    worker.assignment_complete=True
    worker.terminal_reason=None
    return {'assignment':assignment, 'remaining':bins, 'feasible_counts':counts,
            'used_bins':sum(b != capacity for b in bins), 'arithmetic_events':events,
            'worker':worker.evidence()}
