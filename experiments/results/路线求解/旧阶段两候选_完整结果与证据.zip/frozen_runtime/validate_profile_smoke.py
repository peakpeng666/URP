"""One tiny handwritten production-profile smoke; no5000/data/model work."""
import hashlib
import json
import os
import pathlib
import resource
import subprocess
import sys
import time
ROOT=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT))
START=time.monotonic();ROWS=[];RESERVATIONS=[];PLAN=['prepare','freeze_profile','production_profile_callback','postrun_identity'];CURRENT=PLAN[0];TOTAL_RESERVED=0

def mark(name,**evidence):
    global CURRENT
    require(name==PLAN[len(ROWS)] and name==CURRENT,'exact smoke gate identity')
    ROWS.append({'test':name,'passed':True,**evidence});CURRENT=PLAN[len(ROWS)] if len(ROWS)<len(PLAN) else None
    (ROOT/'smoke_live_ledger.json').write_text(json.dumps({'rows':ROWS,'reservations':RESERVATIONS,'current':CURRENT},indent=2)+'\n')
def require(value,message):
    if not value:raise AssertionError(message)

def main():
    global CURRENT,TOTAL_RESERVED
    require(resource.getrlimit(resource.RLIMIT_CPU)==(60,60) and resource.getrlimit(resource.RLIMIT_AS)==(536870912,)*2,'smoke host caps')
    with (ROOT/'smoke_started.json').open('x') as handle:json.dump({'started_unix':time.time(),'scope':'single tiny handwritten production-profile instance','CPU_cap_total':190,'wall_cap_total':120},handle)
    env={'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1','LANG':'C.UTF-8'}
    prep=subprocess.Popen(['/usr/bin/prlimit','--cpu=3:3','--as=536870912:536870912','--',sys.executable,'-I','-B',str(ROOT/'prepare.py'),str(os.getpid())],stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,close_fds=True)
    try:out,err=prep.communicate(timeout=10)
    except BaseException:prep.kill();prep.wait(timeout=2);raise
    require(prep.returncode==0 and not err,'profile preparation '+repr(out)+repr(err));mark('prepare',receipt=json.loads(out))
    from registry import FrozenRegistry,ExecutionJournal,freeze_wave,digest,sha,seal,frozen_write
    from dependencies import load_worker_freeze,digest as file_sha,verify_files
    from resource_profile import PRODUCTION_PROFILE_ID,profile_sha256,profile_document
    from policy import policy_sha256
    from deployment import DeploymentFreeze
    from backend import RegistryBackend
    from test_support import candidate,claim,raw
    from checker import instance_identity
    worker_freeze,runtime=load_worker_freeze();profile_hash=profile_sha256(PRODUCTION_PROFILE_ID)
    CURRENT='freeze_profile'
    freeze=seal({'schema':'wave-freeze-v1','mode':'handwritten_registry_test','runtime_sha256':runtime,'resource_profile_sha256':profile_hash,
                 'policy_sha256':policy_sha256(),'isolation_profile_sha256':file_sha(ROOT/'ISOLATION.json'),
                 'checker_sha256':file_sha(ROOT/'checker.py'),'intake_manifest_sha256':file_sha(ROOT/'INTAKE.json')})
    c=candidate('finite');cl=claim('production_profile_smoke',freeze['sha256']);capture=raw(c)
    registry_doc=freeze_wave(ROOT/'smoke_registry.json',batch_id=cl['run_id'],wave_id='profile-smoke-0',phase=0,
                            runtime_freeze_sha256=runtime,resource_profile_sha256=profile_hash,slots=[(c,cl,capture)])
    registry=FrozenRegistry(ROOT/'smoke_registry.json',registry_doc['sha256'])
    deployment=seal({'schema':'candidate-deployment-freeze-v2','mode':freeze['mode'],'source_origin':'handwritten_fixture','registry_sha256':registry_doc['sha256'],
                    'wave_freeze_sha256':freeze['sha256'],'batch_id':cl['run_id'],'wave_id':registry_doc['wave_id'],'phase':0,
                    'runtime_freeze_sha256':runtime,'resource_profile_sha256':profile_hash,'policy_sha256':policy_sha256(),
                    'isolation_profile_sha256':freeze['isolation_profile_sha256'],'checker_sha256':freeze['checker_sha256'],'intake_manifest_sha256':freeze['intake_manifest_sha256']})
    frozen_write(ROOT/'smoke_deployment.json',deployment);frozen_write(ROOT/'smoke_wave_freeze.json',freeze)
    frozen_write(ROOT/'smoke_claim.json',cl)
    (ROOT/'smoke_capture.json').write_text(json.dumps({'raw':capture.decode(),'status':'ok','capture_complete':True,'finish_reason':'stop','tool_calls':[]},indent=2)+'\n')
    mark('freeze_profile',profile_sha256=profile_hash,profile=profile_document(PRODUCTION_PROFILE_ID))
    def reserve_worker(*,cpu_seconds,worker_role,execution_id):
        global TOTAL_RESERVED
        require((worker_role,cpu_seconds) in [('admission',1),('instance',60)],'worker reservation schema')
        require(len([r for r in RESERVATIONS if r['role']==worker_role])==0,'no repeated worker')
        TOTAL_RESERVED+=cpu_seconds;RESERVATIONS.append({'role':worker_role,'CPU_reserved':cpu_seconds,'execution_id':execution_id})
        require(TOTAL_RESERVED<=121,'child/supervisor reservation cap')
    def reserve_supervisor(*,cpu_seconds,execution_id):
        global TOTAL_RESERVED
        require(cpu_seconds==60 and all(r['role']!='supervisor' for r in RESERVATIONS),'supervisor reservation')
        TOTAL_RESERVED+=cpu_seconds;RESERVATIONS.append({'role':'supervisor','CPU_reserved':cpu_seconds,'execution_id':execution_id})
        require(TOTAL_RESERVED<=121,'child/supervisor reservation cap')
    items=[2,3,4,2];capacity=100
    panel={'kind':'handwritten_registry_test','instances':[{'instance_index':0,'input_sha256':instance_identity(items,capacity),'n':4,'capacity':100,'L1':1}]}
    (ROOT/'smoke_panel_metadata.json').write_text(json.dumps(panel,indent=2)+'\n')
    backend=RegistryBackend(registry,ExecutionJournal(ROOT/'smoke_journal'),raw_reader=lambda key:capture,
             instance_provider=lambda idx:{'items':list(items),'capacity':capacity},reserve_worker=reserve_worker,
             reserve_supervisor=reserve_supervisor,deployment_freeze=DeploymentFreeze(ROOT/'smoke_deployment.json',deployment['sha256']))
    CURRENT='production_profile_callback'
    backend.bind_capture(cl,sha(capture));bundle=backend.verify(c,cl,panel,freeze)
    require(bundle['admission']['admitted'] is True and len(bundle['scores'])==1,'complete callback')
    score=bundle['scores'][0];worker=score['evidence']['worker'];supervisor=score['evidence']['supervisor']
    require(score['outcome']=='ok' and worker['steps']==4 and worker['assignment_complete'] is True,'tiny placement result')
    require(worker['host_observed_limits']['cpu_seconds']==[60,60] and supervisor['host_observed_limits']['cpu_seconds']==[60,60],'actual60/60 CPU caps')
    require(worker['configured_limits']['wall_seconds']==90 and supervisor['configured_wall_seconds']==90,'shared90 wall')
    require(worker['total_wall_deadline']==supervisor['shared_absolute_deadline'] and abs(worker['total_wall_deadline']-worker['absolute_deadline']-2)<1e-6,'cleanup inside shared deadline')
    require(worker['reaped'] and worker['returncode']==0 and supervisor['reaped'] and supervisor['returncode']==0,'both reaped')
    require(bundle['admission']['worker']['host_observed_limits']['cpu_seconds']==[1,1],'admission CPU1')
    require(TOTAL_RESERVED==121 and len(RESERVATIONS)==3,'exact smoke reservations')
    (ROOT/'smoke_bundle.json').write_text(json.dumps(bundle,indent=2)+'\n');mark('production_profile_callback',bundle_sha256=bundle['sha256'])
    CURRENT='postrun_identity'
    verify_files(worker_freeze['dependencies']);verify_files({str(ROOT/name):expected for name,expected in worker_freeze['files'].items()})
    mark('postrun_identity')
    require([r['test'] for r in ROWS]==['prepare','freeze_profile','production_profile_callback','postrun_identity'],'complete smoke plan')

if __name__=='__main__':
    status='passed';error=None;worker_evidence=None;supervisor_evidence=None
    try:main()
    except BaseException as exc:
        status='failed';error=type(exc).__name__+': '+str(exc)
        worker_evidence=getattr(exc,'worker_evidence',None);supervisor_evidence=getattr(exc,'supervisor_evidence',None)
    own=resource.getrusage(resource.RUSAGE_SELF);children=resource.getrusage(resource.RUSAGE_CHILDREN)
    result={'status':status,'error':error,'failed_gate':CURRENT if status!='passed' else None,'planned':PLAN,'not_run':[name for name in PLAN if name not in {row['test'] for row in ROWS} and (status=='passed' or name!=CURRENT)],'rows':ROWS,'passed':len(ROWS),
            'reservations':RESERVATIONS,'reserved_runtime_CPU':TOTAL_RESERVED,'budget_CPU':190,'budget_wall':120,
            'host_CPU':own.ru_utime+own.ru_stime,'children_CPU':children.ru_utime+children.ru_stime,
            'total_CPU':own.ru_utime+own.ru_stime+children.ru_utime+children.ru_stime,'wall_seconds':time.monotonic()-START,
            'exception_worker_evidence':worker_evidence,'exception_supervisor_evidence':supervisor_evidence,
            'model_calls':0,'generated_source_executions':0,'full5000_runs':0,'data_panel_reads':0}
    (ROOT/'profile_smoke_results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':status,'passed':len(ROWS),'error':error}),flush=True)
    sys.exit(0 if status=='passed' else 1)
