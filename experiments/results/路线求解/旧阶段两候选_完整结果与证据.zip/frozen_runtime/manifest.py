"""Frozen proposed API surface. Static admission is NOT runtime readiness."""
import hashlib
import json
from types import MappingProxyType

CONTRACT_VERSION = 'numpy-candidate-static-v1'
PYTHON_VERSION = (3, 12, 14)
MAX_SOURCE_BYTES = 16384
MAX_AST_NODES = 4096
MAX_AST_DEPTH = 64
MAX_VECTOR = 5000
MAX_LOOP_DEPTH = 2
MAX_LOOP_PRODUCT = 5000
MAX_NUMBER_TOKEN = 32
DTYPES = ('float64', 'int64', 'int32', 'bool_')

# API: (minimum positional args, maximum positional args, accepted keywords,
#       rule for arguments and return). Unlisted keywords are forbidden.
_specs = {
    'array': (1, 1, ('dtype',), 'constructor'),
    'asarray': (1, 1, ('dtype',), 'constructor'),
    'copy': (1, 1, (), 'preserve'),
    'arange': (1, 3, ('dtype',), 'bounded_integer_range'),
    'zeros_like': (1, 1, ('dtype',), 'like'),
    'ones_like': (1, 1, ('dtype',), 'like'),
    'full_like': (2, 2, ('dtype',), 'full_like'),
    **{n: (1, 1, (), 'elementwise') for n in
       ('absolute', 'abs', 'negative', 'exp', 'expm1', 'log', 'log1p',
        'sqrt', 'cbrt', 'square', 'reciprocal', 'sign')},
    **{n: (2, 2, (), 'binary') for n in ('maximum', 'minimum')},
    'clip': (3, 3, (), 'clip'),
    'where': (3, 3, (), 'where'),
    **{n: (1, 1, ('axis',), 'reduction') for n in
       ('sum', 'prod', 'mean', 'std', 'var', 'min', 'max', 'median')},
    **{n: (2, 2, (), 'quantile') for n in ('percentile', 'quantile')},
    'sort': (1, 1, (), 'vector_preserve'),
    'argsort': (1, 1, (), 'integer_vector'),
    'argmin': (1, 1, (), 'integer_scalar'),
    'argmax': (1, 1, (), 'integer_scalar'),
    'cumsum': (1, 1, (), 'vector_preserve'),
    'diff': (1, 1, ('n',), 'difference'),
    'searchsorted': (2, 2, (), 'searchsorted'),
    'size': (1, 1, (), 'integer_scalar'),
    'reshape': (2, 2, (), 'reshape_one_dimension'),
    'ravel': (1, 1, (), 'ravel'),
    **{n: (1, 1, (), 'predicate') for n in ('isfinite', 'isnan', 'isinf')},
}
API_SPECS = MappingProxyType(_specs)
RULE_CONTRACTS = MappingProxyType({
    'constructor': ('one rank-1 numeric array or flat numeric sequence; optional approved dtype token', 'rank-1 numeric array, native/default or requested allowed dtype'),
    'preserve': ('one rank-1 numeric array', 'rank-1 numeric array preserving dtype and length'),
    'bounded_integer_range': ('1..3 integer literals or single len(bins); nonzero step; precomputed size <=5000; optional dtype token', 'rank-1 numeric array of prechecked range length'),
    'like': ('one rank-1 numeric array; optional approved dtype token', 'rank-1 numeric array of identical length, native/requested dtype'),
    'full_like': ('rank-1 numeric array and scalar fill; optional approved dtype token', 'rank-1 numeric array of identical length, native/requested dtype'),
    'elementwise': ('one numeric scalar or rank-1 numeric array', 'native numeric scalar or same-length rank-1 array'),
    'binary': ('two numeric scalars/arrays; each array rank-1 <=5000; native compatible broadcasting', 'numeric scalar or rank-1 array <=5000'),
    'clip': ('three numeric scalars/arrays; each array rank-1 <=5000; native compatible broadcasting', 'numeric scalar or rank-1 array <=5000'),
    'where': ('boolean scalar/mask plus two numeric choices; at least one vector; native compatible broadcasting', 'rank-1 numeric array <=5000'),
    'reduction': ('one rank-1 numeric array; optional axis=0 only', 'native numeric scalar'),
    'quantile': ('rank-1 numeric array; literal scalar percentile q in [0,100] or quantile q in [0,1]', 'native numeric scalar'),
    'vector_preserve': ('one rank-1 numeric array', 'rank-1 native numeric array <=5000; cumsum may promote dtype'),
    'integer_vector': ('one rank-1 numeric array; no sorting options', 'rank-1 int64 array with same length'),
    'integer_scalar': ('one rank-1 numeric array', 'integer scalar'),
    'difference': ('rank-1 numeric array; optional literal n in {0,1,2}', 'rank-1 native numeric array, length no larger than input'),
    'searchsorted': ('rank-1 numeric array and numeric scalar/vector; native default side=left; caller responsible for sorted input', 'integer scalar or rank-1 int64 array matching values length'),
    'reshape_one_dimension': ('rank-1 numeric array; singleton tuple/list with integer literal -1..5000 or len(bins); size preserved before call', 'rank-1 numeric array of identical element count'),
    'ravel': ('numeric scalar or rank-1 numeric array', 'rank-1 numeric array <=5000'),
    'predicate': ('numeric scalar or rank-1 numeric array', 'boolean scalar or same-length rank-1 bool array'),
})

def manifest_document():
    return {
        'contract': CONTRACT_VERSION,
        'python_exact': list(PYTHON_VERSION),
        'status': 'STATIC_ONLY_ALL_NUMPY_RUNTIME_PROBES_NOT_RUN',
        'limits': {'source_bytes': MAX_SOURCE_BYTES, 'ast_nodes': MAX_AST_NODES,
                   'ast_depth': MAX_AST_DEPTH, 'vector_elements': MAX_VECTOR,
                   'loop_depth': MAX_LOOP_DEPTH, 'nested_loop_iteration_product': MAX_LOOP_PRODUCT,
                   'number_token_chars': MAX_NUMBER_TOKEN},
        'dtypes': list(DTYPES),
        'apis': {name: {'positional_min': v[0], 'positional_max': v[1],
                        'keywords': list(v[2]), 'rule': v[3],
                        'arguments': RULE_CONTRACTS[v[3]][0],
                        'returns': RULE_CONTRACTS[v[3]][1],
                        'runtime_probe': 'NOT_RUN', 'max_output_elements': MAX_VECTOR}
                 for name, v in sorted(API_SPECS.items())},
    }

def manifest_sha256():
    raw = json.dumps(manifest_document(), sort_keys=True, separators=(',', ':')).encode()
    return hashlib.sha256(raw).hexdigest()
