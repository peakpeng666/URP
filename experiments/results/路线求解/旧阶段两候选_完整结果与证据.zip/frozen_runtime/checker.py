"""Independent exact-integer parent checker, no candidate imports or NumPy."""
from registry import digest,require

def instance_identity(items,capacity):
    return digest({'items':items,'capacity':capacity})

def check_instance(items,capacity,expected):
    require(type(items) is list and 1<=len(items)<=5000,'instance count')
    require(type(capacity) is int and capacity in (100,500),'capacity')
    require(all(type(x) is int and 1<=x<=min(100,capacity) for x in items),'item domain')
    require(expected['input_sha256']==instance_identity(items,capacity),'exact input identity')
    lower=(sum(items)+capacity-1)//capacity
    require(expected['n']==len(items) and expected['capacity']==capacity and expected['L1']==lower,'input metadata')

def check_assignment(items,capacity,result):
    assignment=result['assignment']
    require(type(assignment) is list and len(assignment)==len(items),'assignment shape')
    remaining=[capacity]*len(items)
    for item,index in zip(items,assignment):
        require(type(index) is int and 0<=index<len(items) and remaining[index]>=item,'assignment feasibility')
        remaining[index]-=item
    require(remaining==result['remaining'] and all(x>=0 for x in remaining),'remaining mismatch')
    require(sum(items)==sum(capacity-x for x in remaining),'conservation')
    used=sum(x!=capacity for x in remaining)
    require(used==result['used_bins'],'used bin mismatch')
    return {'assignment_sha256':digest(assignment),'used_bins':used,'checker_status':'passed'}
