"""Frozen per-wave host registry and durable single-use execution claims.

No AST parsing, compilation, source execution, dataset loading or NumPy import.
SHA identities bind bytes and detect corruption; they are not signatures and do
not defend against a privileged actor replacing both artifacts and trust roots.
"""
import base64
import hashlib
import json
import os
import pathlib
import re
from policy import canonical, policy_sha256
from resource_profile import DIAGNOSTIC_PROFILE_ID,profile_sha256,resolve_profile

HASH = re.compile(r'[0-9a-f]{64}\Z', re.ASCII)
ID = re.compile(r'[A-Za-z0-9][A-Za-z0-9_.:/-]{0,127}\Z', re.ASCII)
BINDING_KEYS = ('batch_id','wave_id','slot_id','raw_response_sha256','source_sha256','policy_sha256','runtime_freeze_sha256','claim_sha256','claim_id','registry_sha256','resource_profile_sha256')
MAX_RAW = 262144
MAX_REGISTRY = 262144

def require(ok, message):
    if not ok: raise ValueError(message)

def sha(raw): return hashlib.sha256(raw).hexdigest()
def digest(value): return sha(canonical(value).encode('utf-8'))
def is_hash(value): return type(value) is str and HASH.fullmatch(value) is not None

def seal(value):
    require(type(value) is dict and 'sha256' not in value, 'seal input')
    return dict(value, sha256=digest(value))

def verify_seal(value):
    require(type(value) is dict, 'sealed type')
    plain = dict(value); expected = plain.pop('sha256', None)
    require(is_hash(expected) and digest(plain) == expected, 'seal mismatch')
    return plain

def frozen_write(path, value):
    # Exclusive creation consumes identity permanently, including interrupted writes.
    raw = (canonical(value)+'\n').encode('utf-8')
    fd = os.open(path, os.O_WRONLY|os.O_CREAT|os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, 'wb') as handle:
            handle.write(raw); handle.flush(); os.fsync(handle.fileno())
        parent = os.open(str(pathlib.Path(path).parent), os.O_RDONLY|os.O_DIRECTORY)
        try: os.fsync(parent)
        finally: os.close(parent)
    except BaseException:
        # Never unlink a partial claim or silently retry an uncertain execution.
        raise

def load_document(path, expected_sha256):
    require(is_hash(expected_sha256), 'expected seal')
    with open(path, 'rb') as handle: raw=handle.read(MAX_REGISTRY+1)
    require(0 < len(raw) <= MAX_REGISTRY, 'registry byte cap')
    value=json.loads(raw)
    verify_seal(value)
    require(value['sha256']==expected_sha256, 'frozen registry identity')
    require(raw==(canonical(value)+'\n').encode(), 'registry noncanonical bytes')
    return value

def source_bytes(candidate):
    require(type(candidate) is dict and type(candidate.get('code')) is str, 'candidate source type')
    raw=candidate['code'].encode('utf-8',errors='strict')
    require(0 < len(raw) <= 16384 and sha(raw)==candidate.get('code_sha256'), 'source byte identity')
    description=candidate.get('description')
    require(type(description) is str and len(description.encode())<=MAX_RAW and sha(description.encode())==candidate.get('description_sha256'), 'description identity')
    require(candidate.get('pair_sha256')==digest({'description':description,'code':candidate['code']}), 'pair identity')
    return raw

def claim_fields(claim):
    verify_seal(claim)
    require(claim.get('schema')=='wave-external-claim-v1', 'claim schema')
    for key in ('run_id','slot_id'):
        require(type(claim.get(key)) is str and ID.fullmatch(claim[key]), 'claim identifier')
    require(type(claim.get('phase')) is int and 0<=claim['phase']<=2, 'claim phase')
    require(claim.get('claim_id')==digest(['wave-claim-v1',claim['run_id'],claim['slot_id']]), 'claim ID')
    require(is_hash(claim.get('request_sha256')) and is_hash(claim.get('freeze_sha256')), 'claim hashes')

def freeze_wave(path, *, batch_id, wave_id, phase, runtime_freeze_sha256, slots, source_origin='handwritten_fixture', resource_profile_sha256=None):
    """Freeze exact host-provided (candidate,claim,raw bytes) slots before execution.

    Parent stages explicit input mapping; this function never reads panel data.
    Only hashes and approved public description identities enter this document.
    """
    require(type(batch_id) is str and ID.fullmatch(batch_id), 'batch id')
    require(type(wave_id) is str and ID.fullmatch(wave_id), 'wave id')
    require(type(phase) is int and 0<=phase<=2 and is_hash(runtime_freeze_sha256), 'wave/runtime')
    if resource_profile_sha256 is None:resource_profile_sha256=profile_sha256(DIAGNOSTIC_PROFILE_ID)
    resolve_profile(resource_profile_sha256)
    require(source_origin in ('handwritten_fixture','model_response'),'explicit source provenance')
    require(type(slots) is list and 0<len(slots)<=128, 'slot count')
    entries=[]; seen=set(); claim_ids=set()
    for candidate, claim, raw in slots:
        source=source_bytes(candidate); claim_fields(claim)
        require(claim['run_id']==batch_id and claim['phase']==phase, 'explicit batch/phase mapping')
        require(type(raw) is bytes and 0<len(raw)<=MAX_RAW, 'raw response bytes')
        require(claim['slot_id'] not in seen and claim['claim_id'] not in claim_ids, 'duplicate slot/claim')
        seen.add(claim['slot_id']);claim_ids.add(claim['claim_id'])
        entries.append({'slot_id':claim['slot_id'],'claim_id':claim['claim_id'],'claim_sha256':claim['sha256'],
                        'raw_response_sha256':sha(raw),'source_sha256':sha(source),
                        'description_sha256':candidate['description_sha256'],'pair_sha256':candidate['pair_sha256']})
    value=seal({'schema':'frozen-candidate-wave-registry-v1','batch_id':batch_id,'wave_id':wave_id,'phase':phase,
                'resource_profile_sha256':resource_profile_sha256,'source_origin':source_origin,'policy_sha256':policy_sha256(),'runtime_freeze_sha256':runtime_freeze_sha256,
                'slots':sorted(entries,key=lambda entry:entry['slot_id'])})
    require(len(canonical(value).encode())<=MAX_REGISTRY, 'registry bytes')
    frozen_write(path,value)
    return value

class FrozenRegistry:
    def __init__(self,path,expected_sha256):
        self.path=pathlib.Path(path);self.expected=expected_sha256
        self.document=load_document(self.path,expected_sha256)
        value=self.document
        require(set(value)=={'schema','batch_id','wave_id','phase','policy_sha256','runtime_freeze_sha256','resource_profile_sha256','source_origin','slots','sha256'}, 'registry fields')
        resolve_profile(value['resource_profile_sha256'])
        require(value['source_origin'] in ('handwritten_fixture','model_response'),'registry provenance')
        require(value['schema']=='frozen-candidate-wave-registry-v1' and value['policy_sha256']==policy_sha256(), 'registry policy')
        require(type(value['slots']) is list and 0<len(value['slots'])<=128, 'registry slots')
        self.entries={entry['slot_id']:entry for entry in value['slots']}
        require(len(self.entries)==len(value['slots']), 'duplicate registry slot')
    def reverify(self):
        require(load_document(self.path,self.expected)==self.document, 'registry changed')
    def match(self,candidate,claim,raw_response):
        self.reverify();source=source_bytes(candidate);claim_fields(claim)
        value=self.document
        require(claim['run_id']==value['batch_id'] and claim['phase']==value['phase'], 'wave mapping')
        entry=self.entries.get(claim['slot_id']);require(entry is not None,'unregistered slot')
        require(type(raw_response) is bytes and 0<len(raw_response)<=MAX_RAW,'raw bytes')
        expected={'slot_id':claim['slot_id'],'claim_id':claim['claim_id'],'claim_sha256':claim['sha256'],
                  'raw_response_sha256':sha(raw_response),'source_sha256':sha(source),
                  'description_sha256':candidate['description_sha256'],'pair_sha256':candidate['pair_sha256']}
        require(entry==expected,'slot/raw/source/claim mismatch')
        return self.binding(claim['slot_id'])
    def binding(self,slot_id):
        entry=self.entries[slot_id];value=self.document
        return {**{key:value[key] for key in ('batch_id','wave_id','policy_sha256','runtime_freeze_sha256','resource_profile_sha256')},
                **{key:entry[key] for key in ('slot_id','claim_id','claim_sha256','raw_response_sha256','source_sha256')},
                'registry_sha256':value['sha256']}

class ExecutionJournal:
    """A missing result after a claim is UNKNOWN, never a retry permission."""
    def __init__(self, root):
        self.root=pathlib.Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
    def reserve(self,binding,execution_id):
        token=digest(['registry-execution-v1',binding['batch_id'],binding['slot_id'],execution_id])
        record=seal({'schema':'registry-execution-claim-v1','binding':dict(binding),'execution_id':execution_id})
        frozen_write(self.root/(token+'.claim.json'),record)
        return token
    def finish(self,token,receipt):
        require(is_hash(token),'execution token')
        require((self.root/(token+'.claim.json')).is_file(),'missing claim')
        frozen_write(self.root/(token+'.result.json'),seal({'schema':'registry-execution-result-v1','receipt':receipt}))
