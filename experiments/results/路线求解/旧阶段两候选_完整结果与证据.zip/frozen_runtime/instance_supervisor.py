"""Thin trusted wrapper around the existing pack loop with per-instance CPU cap.

It sees the instance as the original trusted parent did. Only the nested numeric
worker executes admitted source, and only its current placement is delivered.
"""
import base64
import ctypes as C
import hashlib
import json
import os
import pathlib
import resource
import signal
import sys
import time
ROOT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from registry import require,digest,sha,source_bytes
from dependencies import load_worker_freeze,verify_files,mapped
from resource_profile import resolve_profile,role_limits
from supervisor_transport import MAX_JOB,MAX_RESULT,decode,encode,read_child_input,write_child_output
from runner import pack,NumericalFailure,ResourceLimitFailure

def main():
    require(len(sys.argv)==4,'supervisor arguments')
    expected_parent=int(sys.argv[1]);profile_sha=sys.argv[2];runtime_sha=sys.argv[3]
    profile=resolve_profile(profile_sha);limits=role_limits(profile_sha,'instance')
    require(resource.getrlimit(resource.RLIMIT_CPU)==(profile['supervisor_cpu_seconds'],)*2,'supervisor CPU cap')
    require(resource.getrlimit(resource.RLIMIT_AS)==(profile['worker_as_bytes'],)*2,'supervisor address space cap')
    for kind,expected in [(resource.RLIMIT_CORE,0),(resource.RLIMIT_FSIZE,0),(resource.RLIMIT_NOFILE,32)]:
        require(resource.getrlimit(kind)==(expected,expected),'supervisor auxiliary limits')
    libc=C.CDLL(None,use_errno=True)
    require(libc.prctl(1,signal.SIGKILL,0,0,0)==0 and os.getppid()==expected_parent,'supervisor parent guard')
    armed=C.c_int()
    require(libc.prctl(2,C.byref(armed),0,0,0)==0 and armed.value==signal.SIGKILL,'supervisor parent signal')
    freeze,actual=load_worker_freeze();require(actual==runtime_sha,'supervisor runtime identity')
    verify_files({str(ROOT/name):sha for name,sha in freeze['files'].items()})
    verify_files(freeze['dependencies'])
    require(not mapped()-set(freeze['dependencies']),'supervisor unfrozen mapping')
    write_child_output(b'{"ready":"instance_supervisor_v1"}\n')
    job=decode(read_child_input(MAX_JOB),MAX_JOB)
    fields={'v','source_b64','binding','items','capacity','execution_id','instance_index','instance_started','absolute_deadline'}
    require(type(job) is dict and set(job)==fields and type(job['v']) is int and job['v']==1,'supervisor job schema')
    binding=job['binding']
    encoded=job['source_b64'];require(type(encoded) is str and len(encoded)<=21848,'supervisor source bound')
    source=base64.b64decode(encoded,validate=True)
    require(0<len(source)<=16384 and base64.b64encode(source).decode()==encoded and sha(source)==binding['source_sha256'],'supervisor exact source identity')
    code=source.decode('utf-8',errors='strict');description='Registry-bound exact source'
    source_record={'description':description,'code':code,'description_sha256':sha(description.encode()),'code_sha256':sha(source),'pair_sha256':digest({'description':description,'code':code}),'description_consistency':'undetermined'}
    source_bytes(source_record)
    require(binding['resource_profile_sha256']==profile_sha and binding['runtime_freeze_sha256']==runtime_sha,'supervisor profile binding')
    require(type(job['instance_index']) is int and 0<=job['instance_index']<profile['max_instances'],'supervisor instance index')
    require(job['execution_id']==binding['claim_id']+'/instance/'+str(job['instance_index']),'supervisor execution identity')
    start=job['instance_started'];deadline=job['absolute_deadline'];now=time.monotonic()
    require(type(start) is float and type(deadline) is float and start<=now<deadline and abs(deadline-start-limits['wall_seconds'])<1e-6,'shared absolute instance deadline')
    outcome='ok';result=None;evidence=None
    try:
        result=pack(job['items'],job['capacity'],source_record,binding,worker_role='instance',
                    execution_id=job['execution_id'],instance_index=job['instance_index'],
                    absolute_deadline=deadline,instance_started=start)
        evidence=result['worker']
    except NumericalFailure as exc:
        outcome='numeric_failure';evidence=exc.worker_evidence
    except ResourceLimitFailure as exc:
        evidence=exc.worker_evidence
        reason=evidence['terminal_reason']
        outcome='resource_limit' if reason['kind']=='worker_cpu_limit' else 'timeout'
    own=resource.getrusage(resource.RUSAGE_SELF)
    report={'schema':'trusted-instance-supervisor-result-v1','outcome':outcome,'result':result,'worker':evidence,
            'execution_id':job['execution_id'],'instance_index':job['instance_index'],'binding':binding,
            'resource_profile_sha256':profile_sha,'supervisor_role':'instance_supervisor',
            'supervisor_self_cpu_at_emit':own.ru_utime+own.ru_stime,'supervisor_peak_rss_kib':own.ru_maxrss,
            'shared_instance_started':start,'shared_absolute_deadline':deadline}
    encoded_report=encode(report,MAX_RESULT)
    require(time.monotonic()<deadline,'supervisor final shared deadline')
    write_child_output(encoded_report)

if __name__=='__main__':
    try:main()
    except BaseException:
        # No invented result or traceback from an unknown/infrastructure failure.
        os._exit(70)
