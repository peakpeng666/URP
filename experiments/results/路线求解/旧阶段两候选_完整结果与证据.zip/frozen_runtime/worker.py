"""Recovered r1 trusted-only source worker. Restricted before source frame."""
import ast
import base64
import ctypes as C
import hashlib
import json
import os
import pathlib
import resource
import signal
import sys
import warnings
import time
AUDIT_STATE={'open_denials':0}
ROOT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from admission import validate_source,AdmissionError
from facade import build_facade,prepare_numeric_inputs,validate_final_scores,NumericContractError
from dependencies import load_worker_freeze,verify_files,mapped
from protocol import MAX_SOURCE_FRAME,MAX_REQUEST,MAX_RESPONSE,MAX_STEPS,strict_json,encode,request,source_frame,MAX_ADMISSION,MAX_AST_TEXT
from policy import ArithmeticEvents,POLICY
from registry import digest,is_hash
from resource_profile import role_limits

def preload_library():
    return C.CDLL('libseccomp.so.2',use_errno=True),C.CDLL(None,use_errno=True)

def initialize(cpu_limit,parent_pid):
    required={resource.RLIMIT_AS:512*1024**2,resource.RLIMIT_CPU:cpu_limit,resource.RLIMIT_CORE:0,resource.RLIMIT_FSIZE:0,resource.RLIMIT_NOFILE:32}
    for kind,limit in required.items():
        if resource.getrlimit(kind)!=(limit,limit):raise RuntimeError('startup rlimit mismatch')
    lib,libc=preload_library()
    if libc.prctl(1,signal.SIGKILL,0,0,0)!=0:raise RuntimeError('PDEATHSIG unavailable')
    if os.getppid()!=parent_pid:os._exit(76)
    armed=C.c_int()
    if libc.prctl(2,C.byref(armed),0,0,0)!=0 or armed.value!=signal.SIGKILL:raise RuntimeError('PDEATHSIG mismatch')
    import numpy as np
    import numpy.ma  # Explicit trusted eager dependency; no runtime import permission.
    freeze,freeze_sha=load_worker_freeze()
    if sys.version!=freeze['python'] or np.__version__!=freeze['numpy_version']:raise RuntimeError('version mismatch')
    verify_files(freeze['dependencies'])
    verify_files({str(ROOT/name):sha for name,sha in freeze['files'].items()})
    if mapped()-set(freeze['dependencies']):raise RuntimeError('unfrozen mapped dependency')
    if len(os.listdir('/proc/self/task'))!=1:raise RuntimeError('preload multithreaded')
    lib.seccomp_init.argtypes=[C.c_uint32];lib.seccomp_init.restype=C.c_void_p
    lib.seccomp_syscall_resolve_name.argtypes=[C.c_char_p];lib.seccomp_syscall_resolve_name.restype=C.c_int
    class Cmp(C.Structure):
        _fields_=[('arg',C.c_uint),('op',C.c_int),('a',C.c_uint64),('b',C.c_uint64)]
    lib.seccomp_rule_add_array.argtypes=[C.c_void_p,C.c_uint32,C.c_int,C.c_uint,C.POINTER(Cmp)]
    lib.seccomp_load.argtypes=[C.c_void_p];lib.seccomp_release.argtypes=[C.c_void_p]
    os.closerange(3,32);resource.setrlimit(resource.RLIMIT_NOFILE,(3,3));os.environ.clear()
    ctx=lib.seccomp_init(0x80000000)
    if not ctx:raise RuntimeError('seccomp init')
    def allow(name,cmp=None):
        number=lib.seccomp_syscall_resolve_name(name.encode())
        if number<0 or lib.seccomp_rule_add_array(ctx,0x7fff0000,number,int(cmp is not None),C.byref(cmp) if cmp is not None else None):raise RuntimeError('seccomp rule')
    for name in ['brk','munmap','mprotect','mremap','madvise','futex','clock_gettime','rt_sigreturn','exit','exit_group']:allow(name)
    allow('mmap',Cmp(3,7,0x20,0x20));allow('read',Cmp(0,4,0,0));allow('write',Cmp(0,4,1,0));allow('write',Cmp(0,4,2,0))
    if lib.seccomp_load(ctx):raise RuntimeError('seccomp load')
    lib.seccomp_release(ctx)
    # Extra Python-level denial prevents CPython diagnostic fopen from reaching
    # the already-denying kernel filter. This grants no file capability.
    def deny_post_preload_open(event,_args):
        if event=='open':
            if AUDIT_STATE['open_denials']<1024:AUDIT_STATE['open_denials']+=1
            raise PermissionError('all post-preload file opens are disabled')
    sys.addaudithook(deny_post_preload_open)
    return np,freeze,freeze_sha

def write_all(raw,chunk_size=65536):
    offset=0
    while offset<len(raw):
        try:n=os.write(1,raw[offset:offset+chunk_size])
        except InterruptedError:continue
        if n<=0:os._exit(66)
        offset+=n

def read_one(cap):
    raw=bytearray()
    while True:
        try:block=os.read(0,min(4096,cap+1-len(raw)))
        except InterruptedError:continue
        if not block:
            if raw:raise ValueError('truncated frame')
            return None
        raw.extend(block)
        if len(raw)>cap:raise ValueError('frame cap')
        if b'\n' in block:
            if not raw.endswith(b'\n') or raw.count(b'\n')!=1:raise ValueError('pipelined frame')
            return bytes(raw[:-1])

def main(cpu_limit,parent_pid,expected_binding,expected_resource_profile,worker_role):
    limits=role_limits(expected_resource_profile,worker_role)
    if type(cpu_limit) is not int or cpu_limit != limits['cpu_seconds'] or parent_pid<=1 or not is_hash(expected_binding):os._exit(64)
    profile_echo={'resource_profile_sha256':expected_resource_profile,'worker_role':worker_role}
    np,freeze,freeze_sha=initialize(cpu_limit,parent_pid)
    write_all(b'{"ready":2}\n')
    raw=read_one(MAX_SOURCE_FRAME)
    if raw is None:os._exit(0)
    try:source,binding=source_frame(strict_json(raw,MAX_SOURCE_FRAME),freeze_sha,expected_binding,expected_resource_profile)
    except (ValueError,TypeError,UnicodeError):
        write_all(encode({'admitted':False,'kind':'source_protocol','binding_sha256':expected_binding,**profile_echo,**AUDIT_STATE},1024));os._exit(0)
    try:admitted=validate_source(source)
    except AdmissionError:
        write_all(encode({'admitted':False,'kind':'static','binding_sha256':expected_binding,**profile_echo,**AUDIT_STATE},1024));os._exit(0)
    try:
        # Compile exactly the checked object. No host parse, transform or reparse.
        canonical_text=ast.dump(admitted.tree,annotate_fields=True,include_attributes=False)
        if len(canonical_text.encode('utf-8'))>MAX_AST_TEXT:raise ValueError('canonical AST export bound')
        code=compile(admitted.tree,'<registered-numeric-source>','exec',flags=0,dont_inherit=True,optimize=0)
    except (SyntaxError,ValueError,TypeError):
        write_all(encode({'admitted':False,'kind':'compile','binding_sha256':expected_binding,**profile_echo,**AUDIT_STATE},1024));os._exit(0)
    namespace={'__builtins__':{},'np':build_facade(np),'len':len,'range':range}
    exec(code,namespace,namespace)
    function=namespace['score']
    write_all(encode({'admitted':True,'source_sha256':admitted.source_sha256,'manifest_sha256':admitted.manifest_sha256,'node_count':admitted.node_count,'ast_depth':admitted.ast_depth,'apis':list(admitted.called_apis),'canonical_text':canonical_text,'binding_sha256':expected_binding,**profile_echo,**AUDIT_STATE},MAX_ADMISSION))
    if worker_role=='admission':
        # Compile/define only: an admission worker never invokes the score function.
        if read_one(MAX_REQUEST) is not None:os._exit(65)
        os._exit(0)
    events=ArithmeticEvents()
    warnings.simplefilter('always')
    warnings.showwarning=events.python_warning
    np.seterrcall(events.callback);np.seterr(**POLICY['numpy_seterr'])
    for step in range(MAX_STEPS):
        raw=read_one(MAX_REQUEST)
        if raw is None:os._exit(0)
        try:item,bins=request(strict_json(raw,MAX_REQUEST),step)
        except (ValueError,TypeError,UnicodeError):os._exit(65)
        events.begin()
        score_call_cpu_ns=0
        try:
            current_item,current_bins=prepare_numeric_inputs(np,item,bins)
            call_started=time.process_time_ns()
            try:result=function(current_item,current_bins)
            finally:score_call_cpu_ns=time.process_time_ns()-call_started
            scores=validate_final_scores(np,result,len(bins))
            write_all(encode({'v':3,'step':step,'scores':scores.tolist(),'arithmetic_events':events.evidence(),'score_call_cpu_ns':score_call_cpu_ns,'dtype':str(scores.dtype),'binding_sha256':expected_binding},MAX_RESPONSE))
        except (ArithmeticError,ValueError,TypeError,IndexError,NumericContractError) as exc:
            write_all(encode({'v':3,'step':step,'failure':'numerical_policy','arithmetic_events':events.evidence(),'binding_sha256':expected_binding,'exception_kind':type(exc).__name__,'score_call_cpu_ns':score_call_cpu_ns},1024));os._exit(0)
    if read_one(MAX_REQUEST) is not None:raise ValueError('step cap')
    os._exit(0)
if __name__=='__main__':
    try:
        if len(sys.argv)!=6:os._exit(64)
        main(int(sys.argv[1]),int(sys.argv[2]),sys.argv[3],sys.argv[4],sys.argv[5])
    except BaseException:os._exit(70)
