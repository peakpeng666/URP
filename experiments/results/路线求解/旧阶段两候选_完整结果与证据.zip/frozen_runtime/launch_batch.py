"""One approved finite handwritten test batch; never automatic retry."""
import json
import os
import pathlib
import resource
import subprocess
import sys
import time
ROOT=pathlib.Path(__file__).resolve().parent
START=time.monotonic()
ENV={'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','NUMEXPR_NUM_THREADS':'1','BLIS_NUM_THREADS':'1','VECLIB_MAXIMUM_THREADS':'1','LANG':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1'}
def main():
    raise RuntimeError("r4 launcher is disabled for v2; a separately reviewed finite profile-test budget is required")
    if resource.getrlimit(resource.RLIMIT_CPU)!=(10,10) or resource.getrlimit(resource.RLIMIT_AS)!=(536870912,)*2:raise RuntimeError('host caps')
    with (ROOT/'run_started.json').open('x') as handle:json.dump({'start_monotonic':START,'started_unix':time.time(),'scope':'handwritten registry only40CPU60wall'},handle)
    p=subprocess.Popen(['/usr/bin/prlimit','--as=536870912:536870912','--cpu=3:3','--',sys.executable,'-I','-B',str(ROOT/'prepare.py'),str(os.getpid())],stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=ENV,close_fds=True)
    try:out,err=p.communicate(timeout=10)
    except BaseException:
        p.kill();p.wait(timeout=2);raise
    if p.returncode!=0 or err:raise RuntimeError('preparation failed '+repr(out)+repr(err))
    (ROOT/'launch_state.json').write_text(json.dumps({'start_monotonic':START,'preparation':json.loads(out)},indent=2)+'\n')
    os.execve(sys.executable,[sys.executable,'-I','-B',str(ROOT/'validate.py')],ENV)
if __name__=='__main__':main()
