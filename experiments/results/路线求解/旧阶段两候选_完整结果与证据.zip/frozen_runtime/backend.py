"""Registry callback with fixed role profiles and a capped instance supervisor."""
import copy
import pathlib
from registry import FrozenRegistry,ExecutionJournal,require,digest,sha,verify_seal,seal
from policy import POLICY,policy_sha256
from deployment import DeploymentFreeze
from resource_profile import resolve_profile,role_limits
from dependencies import load_worker_freeze,digest as file_sha
from checker import check_instance,check_assignment
from runner import Session,ResourceLimitFailure
from supervised_runner import supervised_pack
ROOT=pathlib.Path(__file__).resolve().parent

class RegistryBackend:
    def __init__(self,registry,journal,*,raw_reader,instance_provider,reserve_worker,reserve_supervisor,deployment_freeze):
        require(type(registry) is FrozenRegistry and type(journal) is ExecutionJournal,'backend components')
        require(all(callable(x) for x in (raw_reader,instance_provider,reserve_worker,reserve_supervisor)),'trusted providers/reservations required')
        require(type(deployment_freeze) is DeploymentFreeze,'externally pinned deployment required')
        self.registry=registry;self.journal=journal;self.raw_reader=raw_reader;self.instance_provider=instance_provider
        self.reserve_worker=reserve_worker;self.reserve_supervisor=reserve_supervisor
        self.deployment=deployment_freeze;self.capture_bindings={}
    def bind_capture(self,claim,raw_response_sha256):
        verify_seal(claim);require(claim['claim_id'] not in self.capture_bindings,'capture replay')
        binding=self.registry.binding(claim['slot_id'])
        require(claim['sha256']==binding['claim_sha256'] and raw_response_sha256==binding['raw_response_sha256'],'capture binding mismatch')
        self.capture_bindings[claim['claim_id']]=raw_response_sha256
    def verify(self,candidate,claim,panel,freeze):
        verify_seal(freeze)
        binding=self.registry.match(candidate,claim,self.raw_reader(claim['claim_id']))
        require(self.capture_bindings.pop(claim['claim_id'],None)==binding['raw_response_sha256'],'fresh adapter capture binding')
        worker_freeze,runtime=load_worker_freeze()
        require(runtime==binding['runtime_freeze_sha256']==freeze['runtime_sha256'],'runtime freeze')
        require(freeze.get('policy_sha256')==binding['policy_sha256']==policy_sha256(),'numerical policy')
        require(claim['freeze_sha256']==freeze['sha256'],'claim freeze')
        for key,file in [('isolation_profile_sha256','ISOLATION.json'),('checker_sha256','checker.py'),('intake_manifest_sha256','INTAKE.json')]:
            require(freeze.get(key)==file_sha(ROOT/file),'frozen '+key)
        activation=self.deployment.validate(self.registry,freeze)
        profile=resolve_profile(binding['resource_profile_sha256'])
        require(panel.get('kind')==activation['mode'],'panel mode')
        if activation['source_origin']=='handwritten_fixture':
            require(candidate['code_sha256'] in worker_freeze['handwritten_test_source_hashes'],'handwritten acceptance source')
        require(type(panel.get('instances')) is list and 1<=len(panel['instances'])<=profile['max_instances'],'panel count')
        for index,expected in enumerate(panel['instances']):
            require(type(expected.get('instance_index')) is int and expected['instance_index']==index and type(expected.get('n')) is int and 1<=expected['n']<=5000,'panel order')
        bundle_token=self.journal.reserve(binding,'verify');worker=None;failure_stage='admission'
        common={'source_sha256':candidate['code_sha256'],'bounded_child_verified':True,'runtime_sha256':runtime,
                'isolation_profile_sha256':freeze['isolation_profile_sha256'],'cleanup_status':'passed',
                'registry_binding':dict(binding),'policy_sha256':policy_sha256(),'deployment_sha256':activation['sha256'],
                'source_origin':activation['source_origin'],'resource_profile_sha256':binding['resource_profile_sha256']}
        try:
            admission_id=claim['claim_id']+'/admission'
            self.reserve_worker(cpu_seconds=role_limits(binding['resource_profile_sha256'],'admission')['cpu_seconds'],worker_role='admission',execution_id=admission_id)
            try:
                worker=Session(candidate,binding,worker_role='admission',execution_id=admission_id)
                admission=copy.deepcopy(worker.admission);worker.close();gate=worker.evidence()
                require(gate['reaped'] and gate['returncode']==0,'admission cleanup')
                canonical=admission.pop('canonical_text',None)
            except ResourceLimitFailure as exc:
                gate=exc.worker_evidence
                require(gate['source_sent'] and gate['source_after_host_gate'] and gate['reaped'] and gate['cleanup_error'] is None,'admission cap provenance/cleanup')
                reason=gate['terminal_reason'];require(type(reason) is dict,'admission cap reason')
                admission={'admitted':False,'kind':'resource_limit' if reason['kind']=='worker_cpu_limit' else 'timeout'}
                canonical=None
            admission.update(**copy.deepcopy(common),worker=compact_evidence(gate),worker_role='admission')
            failure_stage='instance'
            scores=[];identity=None
            if admission['admitted']:
                identity={'method':'bounded-child-ast-dump-v1','canonical_text':canonical,
                          'code_identity':sha(canonical.encode()),'joint_identity':digest([candidate['description'].strip(),canonical])}
                for expected in panel['instances']:
                    idx=expected['instance_index'];execution_id=claim['claim_id']+'/instance/'+str(idx)
                    token=self.journal.reserve(binding,execution_id)
                    instance=self.instance_provider(idx)
                    require(type(instance) is dict and set(instance)=={'items','capacity'},'instance provider')
                    items=instance['items'];capacity=instance['capacity'];check_instance(items,capacity,expected)
                    self.reserve_worker(cpu_seconds=role_limits(binding['resource_profile_sha256'],'instance')['cpu_seconds'],worker_role='instance',execution_id=execution_id)
                    self.reserve_supervisor(cpu_seconds=profile['supervisor_cpu_seconds'],execution_id=execution_id)
                    report=supervised_pack(items,capacity,candidate,binding,execution_id=execution_id,instance_index=idx)
                    outcome=report['outcome'];ev=report['worker'];checked=None
                    if outcome=='ok':
                        checked=check_assignment(items,capacity,report['result'])
                        require(ev['admission']['canonical_text']==canonical,'instance AST identity')
                        require(ev['assignment_complete'] is True,'complete assignment')
                    else:
                        require(ev['reaped'] and ev['cleanup_error'] is None and not ev['assignment_complete'],'failure cleanup/partial assignment')
                    evidence={'slot_id':claim['slot_id'],'claim_id':claim['claim_id'],'execution_id':execution_id,'instance_index':idx,
                        'intake_manifest_sha256':freeze['intake_manifest_sha256'],'no_cross_slot_cache':True,
                        'runtime_sha256':runtime,'isolation_profile_sha256':freeze['isolation_profile_sha256'],
                        'checker_sha256':freeze['checker_sha256'],'cleanup_status':'passed','checker_status':'passed' if checked else 'not_run',
                        'assignment_sha256':checked['assignment_sha256'] if checked else None,'assignment_complete':checked is not None,
                        'policy_sha256':policy_sha256(),'deployment_sha256':activation['sha256'],'source_origin':activation['source_origin'],
                        'resource_profile_sha256':binding['resource_profile_sha256'],'worker_role':'instance',
                        'registry_binding':dict(binding),'worker':compact_evidence(ev),'supervisor':report['supervisor_evidence']}
                    record={'kind':panel['kind'],'instance_index':idx,'input_sha256':expected['input_sha256'],'code_sha256':candidate['code_sha256'],
                            'outcome':outcome,'used_bins':checked['used_bins'] if checked else None,'L1':expected['L1'],'evidence':evidence}
                    self.journal.finish(token,record);scores.append(record)
                    if outcome!='ok':break
            bundle=seal({'schema':'wave-bounded-verification-v1','mode':activation['mode'],'claim_id':claim['claim_id'],'slot_id':claim['slot_id'],
                'source_sha256':candidate['code_sha256'],'description_sha256':candidate['description_sha256'],'freeze_sha256':freeze['sha256'],
                'intake_manifest_sha256':freeze['intake_manifest_sha256'],'registry_binding':dict(binding),'policy_sha256':policy_sha256(),
                'resource_profile_sha256':binding['resource_profile_sha256'],'resource_profile':profile,
                'deployment_sha256':activation['sha256'],'source_origin':activation['source_origin'],'arithmetic_policy':copy.deepcopy(POLICY),
                'admission':admission,'identity':identity,'scores':scores})
            self.journal.finish(bundle_token,bundle);return bundle
        except BaseException as exc:
            if worker is not None and failure_stage=='admission':
                if not worker.reaped:exc=worker._preserve_failure(exc,kill=True)
                elif getattr(exc,'worker_evidence',None) is None:
                    exc.worker_evidence=worker.evidence();exc.worker_evidence['exception']=type(exc).__name__+': '+str(exc)
            failure={'exception':type(exc).__name__+': '+str(exc),'worker_evidence':getattr(exc,'worker_evidence',None),
                     'supervisor_evidence':getattr(exc,'supervisor_evidence',None),'binding':dict(binding)}
            try:self.journal.finish(bundle_token,{'terminal_failure':failure})
            except BaseException as journal_error:exc.journal_error=type(journal_error).__name__+': '+str(journal_error)
            raise

def compact_evidence(value):
    out=copy.deepcopy(value)
    if out.get('admission') and 'canonical_text' in out['admission']:
        text=out['admission'].pop('canonical_text');out['admission']['canonical_text_sha256']=sha(text.encode())
    paths=out.pop('mapped_dependencies',None)
    out['mapped_dependencies_sha256']=digest(paths) if paths is not None else None
    return out
