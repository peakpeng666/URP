"""Fixed trusted fault controls; never input-provided source."""
import os
import pathlib
import sys
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent))
from worker import initialize,write_all,read_one,AUDIT_STATE
from protocol import strict_json,request,encode,MAX_REQUEST,MAX_RESPONSE
try:
    mode=sys.argv[1];cpu=int(sys.argv[2]);parent=int(sys.argv[3])
    if mode not in ('shutdown_tail','cpu','wall','memory','no_read','partial','malformed_response','open_deny') or cpu!=1:os._exit(64)
    target=pathlib.Path(__file__).resolve().parent/'diagnostic_sentinel.bin'
    initialize(cpu,parent);write_all(b'{"ready":2}\n')
    if mode=='no_read':
        while True:pass
    raw=read_one(MAX_REQUEST)
    if raw is None:os._exit(0)
    item,bins=request(strict_json(raw,MAX_REQUEST),0)
    if mode=='open_deny':
        denied=[]
        for access in ('rb','wb'):
            try:
                with open(target,access) as handle:
                    if access=='rb':handle.read(1)
                    else:handle.write(b'FORBIDDEN')
            except PermissionError:denied.append(True)
            else:denied.append(False)
        write_all(encode({'read_denied':denied[0],'write_denied':denied[1],**AUDIT_STATE},512));os._exit(0)
    if mode=='cpu':
        while True:pass
    if mode=='wall':os.read(0,1);os._exit(0)
    if mode=='memory':
        try:bytearray(2*1024**3)
        except MemoryError:os._exit(73)
        os._exit(74)
    if mode=='malformed_response':write_all(b'{"v":2,"v":2}\n');os.read(0,1);os._exit(0)
    write_all(encode({'v':2,'step':0,'scores':[b-item for b in bins],'overflow_events':0,'dtype':'int64'},MAX_RESPONSE),chunk_size=3 if mode=='partial' else 65536)
    if read_one(MAX_REQUEST) is not None:os._exit(79)
    if mode=='shutdown_tail':write_all(b'UNEXPECTED TAIL\n')
    os._exit(0)
except BaseException:os._exit(70)
