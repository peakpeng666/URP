"""Per-instance trusted supervisor launch/receipt, not a new source sandbox."""
import base64
import hashlib
import os
import pathlib
import resource
import signal
import subprocess
import sys
import time
from registry import require,digest
from resource_profile import resolve_profile,role_limits
from runner import ENV
from dependencies import load_worker_freeze,mapped,digest as file_digest
from supervisor_transport import MAX_JOB,MAX_RESULT,BoundedPipe,encode,decode
ROOT=pathlib.Path(__file__).resolve().parent

class SupervisorIntegrityError(RuntimeError):
    pass

def supervised_pack(items,capacity,candidate,binding,*,execution_id,instance_index):
    profile=resolve_profile(binding['resource_profile_sha256']);limits=role_limits(binding['resource_profile_sha256'],'instance')
    frozen,runtime_sha=load_worker_freeze()
    require(runtime_sha==binding['runtime_freeze_sha256'],'supervisor expected runtime')
    inherited_cpu=resource.getrlimit(resource.RLIMIT_CPU)[1]
    require(inherited_cpu==resource.RLIM_INFINITY or inherited_cpu>=profile['supervisor_cpu_seconds'],'supervisor inherited hard CPU ceiling')
    start=time.monotonic();deadline=start+limits['wall_seconds']
    supervisor_cpu=profile['supervisor_cpu_seconds'];address_space=profile['worker_as_bytes']
    command=['/usr/bin/prlimit',f'--cpu={supervisor_cpu}:{supervisor_cpu}',f'--as={address_space}:{address_space}',
             '--core=0:0','--fsize=0:0','--nofile=32:32','--',sys.executable,'-I','-B',str(ROOT/'instance_supervisor.py'),
             str(os.getpid()),binding['resource_profile_sha256'],binding['runtime_freeze_sha256']]
    p=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=ENV,
                       cwd=ROOT,close_fds=True,start_new_session=True,bufsize=0)
    channel=None;reaped=False;usage=None;returncode=None;report=None;observed=None;cleanup_error=None;observed_mappings=None
    def reap(until,kill):
        nonlocal reaped,usage,returncode
        if kill and not reaped:
            try:os.killpg(p.pid,signal.SIGKILL)
            except ProcessLookupError:pass
        while not reaped:
            pid,status,current=os.wait4(p.pid,os.WNOHANG)
            if pid:
                reaped=True;usage=current;returncode=os.waitstatus_to_exitcode(status);p.returncode=returncode
            elif time.monotonic()>=until:break
            else:time.sleep(min(.002,max(0.0,until-time.monotonic())))
        if not reaped:raise SupervisorIntegrityError('supervisor not reaped before cleanup deadline')
    try:
        channel=BoundedPipe(p)
        require(channel.exchange(None,min(deadline,start+limits['startup_wall_seconds']),128)==b'{"ready":"instance_supervisor_v1"}','supervisor ready')
        require(pathlib.Path(f'/proc/{p.pid}/exe').resolve()==pathlib.Path(sys.executable).resolve(),'supervisor executable')
        status={row.split(':',1)[0]:row.split(':',1)[1].strip() for row in pathlib.Path(f'/proc/{p.pid}/status').read_text().splitlines()}
        require(int(status['Pid'])==p.pid and int(status['PPid'])==os.getpid(),'supervisor PID/parent')
        rows=pathlib.Path(f'/proc/{p.pid}/limits').read_text().splitlines()
        observed={}
        for label,key,value in [('Max cpu time','cpu_seconds',supervisor_cpu),('Max address space','address_space_bytes',address_space),('Max open files','open_files',32),('Max file size','file_size_bytes',0),('Max core file size','core_bytes',0)]:
            match=[row for row in rows if row.startswith(label)]
            require(len(match)==1 and match[0][len(label):].split()[:2]==[str(value)]*2,'supervisor observed resource')
            observed[key]=[value,value]
        observed_mappings=mapped(p.pid)
        require(not observed_mappings-set(frozen['dependencies']),'parent observed supervisor mappings')
        for name in observed_mappings:require(file_digest(name)==frozen['dependencies'][name],'parent observed supervisor dependency hash')
        job={'v':1,'source_b64':base64.b64encode(candidate['code'].encode('utf-8')).decode('ascii'),
             'binding':binding,'items':items,'capacity':capacity,'execution_id':execution_id,'instance_index':instance_index,
             'instance_started':float(start),'absolute_deadline':float(deadline)}
        report=decode(channel.exchange(encode(job,MAX_JOB),deadline,MAX_RESULT),MAX_RESULT)
        p.stdin.close()
        reap(min(deadline,time.monotonic()+profile['cleanup_wall_seconds']),False)
        for stream in (p.stdout,p.stderr):
            try:tail=os.read(stream.fileno(),1)
            except BlockingIOError:raise SupervisorIntegrityError('supervisor missing terminal EOF')
            require(not tail,'unexpected supervisor shutdown tail')
        require(returncode==0,'supervisor nonzero terminal')
        require(type(report) is dict and report.get('schema')=='trusted-instance-supervisor-result-v1','supervisor report schema')
        require(report.get('binding')==binding and report.get('execution_id')==execution_id and report.get('instance_index')==instance_index,'supervisor report identity')
        require(report.get('resource_profile_sha256')==binding['resource_profile_sha256'] and report.get('supervisor_role')=='instance_supervisor','supervisor role/profile')
        require(report.get('shared_instance_started')==start and report.get('shared_absolute_deadline')==deadline,'supervisor deadline binding')
        worker=report.get('worker');require(type(worker) is dict and worker.get('reaped') is True,'supervisor child cleanup proof')
        require(worker.get('registry_binding')==binding and worker.get('worker_role')=='instance','supervisor worker binding/role')
        require(report.get('outcome') in ('ok','numeric_failure','resource_limit','timeout'),'supervisor outcome')
        if report['outcome']=='ok':require(type(report.get('result')) is dict and report['result'].get('worker')==worker,'supervisor result/worker identity')
        else:require(report.get('result') is None,'failed supervisor result')
        # wait4 for this trusted supervisor reports its process plus reaped
        # descendants on Linux; retain raw usage and pre-emit self usage distinctly.
        inclusive_cpu=usage.ru_utime+usage.ru_stime
        child_cpu=worker.get('cpu_seconds')
        require(type(child_cpu) in (int,float) and inclusive_cpu+0.01>=report['supervisor_self_cpu_at_emit']+child_cpu,'inclusive supervisor CPU accounting')
        actual_supervisor_cpu=max(0.0,inclusive_cpu-child_cpu)
        require(time.monotonic()<=deadline,'supervisor terminal shared deadline')
        report['supervisor_evidence']={'pid':p.pid,'role':'instance_supervisor','runtime_freeze_sha256':binding['runtime_freeze_sha256'],'resource_profile_sha256':binding['resource_profile_sha256'],
            'execution_id':execution_id,'instance_index':instance_index,'host_observed_limits':observed,'mapped_dependencies_sha256':digest(sorted(observed_mappings)),'dependency_verified_before_job':True,
            'configured_wall_seconds':limits['wall_seconds'],'cleanup_within_wall':True,'shared_instance_started':start,'shared_absolute_deadline':deadline,
            'reaped':True,'returncode':returncode,'wait4_cpu_seconds':usage.ru_utime+usage.ru_stime,
            'self_cpu_at_emit':report['supervisor_self_cpu_at_emit'],'actual_supervisor_cpu_seconds':actual_supervisor_cpu,'child_cpu_seconds':child_cpu,
            'wall_seconds':time.monotonic()-start,'peak_rss_kib':usage.ru_maxrss,
            'input_bytes':channel.input_bytes,'output_bytes':channel.output_bytes,'stderr_bytes':channel.stderr_bytes,
            'cleanup_error':None,'cpu_accounting_scope':'Linux wait4 inclusive descendants; self_at_emit excludes final serialization tail'}
        require(time.monotonic()<=deadline,'supervisor final receipt deadline')
        return report
    except BaseException as exc:
        try:reap(min(deadline,time.monotonic()+profile['cleanup_wall_seconds']),True)
        except BaseException as cleanup:cleanup_error=type(cleanup).__name__+': '+str(cleanup)
        exc.supervisor_evidence={'pid':p.pid,'role':'instance_supervisor','runtime_freeze_sha256':binding['runtime_freeze_sha256'],'resource_profile_sha256':binding['resource_profile_sha256'],
            'execution_id':execution_id,'instance_index':instance_index,'host_observed_limits':observed,'reaped':reaped,
            'returncode':returncode,'wait4_cpu_seconds':None if usage is None else usage.ru_utime+usage.ru_stime,
            'wall_seconds':time.monotonic()-start,'cleanup_error':cleanup_error,
            'descendant_cleanup_proven':False,'failure_policy':'integrity stop; no invented child reap or automatic retry'}
        raise
    finally:
        for stream in (p.stdin,p.stdout,p.stderr):
            if not stream.closed:stream.close()
