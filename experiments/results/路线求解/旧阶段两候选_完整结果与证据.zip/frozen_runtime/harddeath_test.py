"""Bounded process-local subreaper test. Every supervisor has parent-death guard."""
import ctypes as C
import json
import os
import pathlib
import signal
import subprocess
import sys
import time
ROOT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from runner import Session
from test_support import binding

def parent_guard(expected):
    lib=C.CDLL(None,use_errno=True)
    if lib.prctl(1,signal.SIGKILL,0,0,0)!=0:raise RuntimeError('test PDEATHSIG unavailable')
    if os.getppid()!=expected:os._exit(76)
    armed=C.c_int()
    if lib.prctl(2,C.byref(armed),0,0,0)!=0 or armed.value!=signal.SIGKILL:raise RuntimeError('test parent guard mismatch')

if len(sys.argv)>1 and sys.argv[1]=='victim':
    parent_guard(int(sys.argv[2]))
    candidate,identity=binding()
    s=Session(candidate,identity,fixture='no_read',defer_source=True)
    print(json.dumps({'pid':s.p.pid,'evidence':s.evidence()}),flush=True)
    while True:time.sleep(1)

parent_guard(int(sys.argv[1]))
lib=C.CDLL(None,use_errno=True)
if lib.prctl(36,1,0,0,0)!=0:raise RuntimeError('test subreaper unavailable')
armed=C.c_int()
if lib.prctl(37,C.byref(armed),0,0,0)!=0 or armed.value!=1:raise RuntimeError('test subreaper mismatch')
p=subprocess.Popen([sys.executable,'-I','-B',str(__file__),'victim',str(os.getpid())],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,env={'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1'},close_fds=True)
worker_pid=None
try:
    record=json.loads(p.stdout.readline());worker_pid=record['pid']
    killed_at=time.monotonic();p.kill();p.wait(timeout=2)
    until=time.monotonic()+3;pid=0
    while time.monotonic()<until:
        pid,status,usage=os.wait4(worker_pid,os.WNOHANG)
        if pid:break
        time.sleep(.005)
    if not pid:raise RuntimeError('parent death worker not reaped')
    out,err=p.communicate(timeout=1)
    if os.waitstatus_to_exitcode(status)!=-signal.SIGKILL or out or err:raise RuntimeError('death status/EOF mismatch')
    worker_cpu=usage.ru_utime+usage.ru_stime
    if not worker_cpu<0.8:raise RuntimeError('cannot distinguish parent death from CPU limit')
    if pathlib.Path(f'/proc/{worker_pid}').exists():raise RuntimeError('reaped PID remains')
    print(json.dumps({'passed':True,'supervisor_sigkill':p.returncode,'worker_sigkill':os.waitstatus_to_exitcode(status),'worker_reaped':True,'supervisor_streams_eof':True,'worker_fds_closed_by_exit':True,'worker_cpu_seconds':worker_cpu,'elapsed_after_parent_kill':time.monotonic()-killed_at,'worker_hard_cpu_seconds':1,'busy_no_read_fixture':True,'worker_peak_rss_kib':usage.ru_maxrss,'worker_predeath':record['evidence'],'production_claim':'PDEATHSIG termination; production platform orphan reaping is not guaranteed by this test'}))
finally:
    if p.poll() is None:p.kill();p.wait(timeout=2)
    if worker_pid and pathlib.Path(f'/proc/{worker_pid}').exists():
        try:os.kill(worker_pid,signal.SIGKILL)
        except ProcessLookupError:pass
        until=time.monotonic()+1
        while time.monotonic()<until:
            try:
                pid,_,_=os.wait4(worker_pid,os.WNOHANG)
                if pid:break
            except ChildProcessError:break
            time.sleep(.005)
