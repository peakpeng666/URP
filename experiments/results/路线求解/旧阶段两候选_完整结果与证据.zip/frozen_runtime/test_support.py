"""Handwritten bounded test metadata, not a host candidate parser."""
import base64
import json
import pathlib
from registry import sha,digest,seal
from dependencies import load_worker_freeze
from resource_profile import DIAGNOSTIC_PROFILE_ID,profile_sha256
ROOT=pathlib.Path(__file__).resolve().parent

def candidate(name):
    fixture=json.loads((ROOT/'handwritten_fixtures.json').read_text())[name]
    code=base64.b64decode(fixture['source_b64'],validate=True).decode('utf-8')
    description='Handwritten registry control '+name
    return {'description':description,'code':code,'description_sha256':sha(description.encode()),
            'code_sha256':sha(code.encode()),'pair_sha256':digest({'description':description,'code':code}),
            'description_consistency':'undetermined'}

def raw(candidate):
    return ('{'+candidate['description']+'}\n```python\n'+candidate['code']+'```').encode()

def claim(slot,freeze_sha=None):
    return seal({'schema':'wave-external-claim-v1','run_id':'registry-handwritten-batch','claim_id':digest(['wave-claim-v1','registry-handwritten-batch',slot]),
                 'slot_id':slot,'phase':0,'request_sha256':digest(['handwritten-request',slot]),'freeze_sha256':freeze_sha or digest('handwritten-test-freeze')})

def binding(name='finite'):
    c=candidate(name);cl=claim(name);_,runtime=load_worker_freeze()
    from policy import policy_sha256
    return c,{'batch_id':cl['run_id'],'wave_id':'handwritten-wave-0','slot_id':name,'raw_response_sha256':sha(raw(c)),
        'source_sha256':c['code_sha256'],'policy_sha256':policy_sha256(),'runtime_freeze_sha256':runtime,
        'claim_sha256':cl['sha256'],'claim_id':cl['claim_id'],'registry_sha256':digest('trusted-harddeath-test-binding'),'resource_profile_sha256':profile_sha256(DIAGNOSTIC_PROFILE_ID)}
