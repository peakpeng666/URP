"""Resource-limited trusted dependency preparation. No fixture parse or calls."""
import ctypes as C
import hashlib
import json
import os
import pathlib
import resource
import signal
import sys
import time
START=time.monotonic();ROOT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
def main():
    if resource.getrlimit(resource.RLIMIT_CPU)!=(3,3) or resource.getrlimit(resource.RLIMIT_AS)!=(536870912,536870912):raise RuntimeError('prep limits')
    expected=int(sys.argv[1]);lib=C.CDLL(None,use_errno=True)
    if lib.prctl(1,signal.SIGKILL,0,0,0)!=0 or os.getppid()!=expected:raise RuntimeError('prep parent guard')
    armed=C.c_int()
    if lib.prctl(2,C.byref(armed),0,0,0)!=0 or armed.value!=signal.SIGKILL:raise RuntimeError('prep parent signal')
    import worker
    import runner
    import instance_supervisor
    import supervised_runner
    import numpy as np
    import numpy.ma
    from dependencies import digest,inventory
    from policy import policy_sha256
    if (ROOT/'pre_run_freeze.json').exists() or (ROOT/'worker_freeze.json').exists():raise RuntimeError('preparation already attempted')
    frozen=json.loads((ROOT/'source_freeze.json').read_text())
    for name,expected_hash in frozen['files'].items():
        if digest(ROOT/name)!=expected_hash:raise RuntimeError('reviewed source mismatch')
    baseline=ROOT.parent/'numpy_source_runner_v3_preload_ma'
    if digest(baseline/'pre_run_freeze.json')!='5ff72807e4904a282a34d17180bc3dedf991aac66d2fe7a6ce4316b32f1710a4':raise RuntimeError('baseline freeze')
    old=json.loads((baseline/'pre_run_freeze.json').read_text())
    for name in ('admission.py','manifest.py','api_manifest.json','facade.py','facade_original_static_v1.py','INPUT_DTYPE_VARIANT.json'):
        if digest(ROOT/name)!=old['files'][name]:raise RuntimeError('preserved contract changed')
    libraries=worker.preload_library();deps=inventory()
    for p in pathlib.Path(np.__file__).resolve().parent.rglob('*'):
        if p.is_file() and p.suffix in ('.py','.pyc','.so'):deps[str(p.resolve())]=digest(p)
    fixtures=json.loads((ROOT/'handwritten_fixtures.json').read_text())
    value={'identity':'numpy_source_registry_v2_profiles','python':sys.version,'numpy_version':np.__version__,
           'files':frozen['files'],'dependencies':deps,'policy_sha256':policy_sha256(),
           'handwritten_test_source_hashes':[v['source_sha256'] for v in fixtures.values()],
           'compile':{'mode':'exec','flags':0,'dont_inherit':True,'optimize':0,'same_accepted_ast':True}}
    with (ROOT/'worker_freeze.json').open('x') as handle:json.dump(value,handle,sort_keys=True,indent=2);handle.write('\n')
    value=dict(value,worker_freeze_sha256=digest(ROOT/'worker_freeze.json'))
    own=resource.getrusage(resource.RUSAGE_SELF)
    value.update(prep_cpu_seconds=own.ru_utime+own.ru_stime,prep_wall_seconds=time.monotonic()-START)
    with (ROOT/'pre_run_freeze.json').open('x') as handle:json.dump(value,handle,sort_keys=True,indent=2);handle.write('\n')
    print(json.dumps({'status':'prepared','cpu_seconds':value['prep_cpu_seconds'],'wall_seconds':value['prep_wall_seconds']}),flush=True)
if __name__=='__main__':main()
