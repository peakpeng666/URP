# CVRP n100/n200 scale experiment

Read reports/REPORT_ZH.md and reports/SUMMARY.json.16 new synthetic geometry blocks;384 trajectories;768 correlated checkpoints. Main pre-fixed contrast random_regret2 vs random_cheapest at160000 deltas. Initialization included. No LLM/API/paid calls, no method changes.

All code uses the Python standard library. source/budget_engine.py and source/legacy are byte-identical to previous validated operators. Input, schedule and pre-generation/pre-run source hashes are frozen. reports/finalize.py is a post-results reporting helper and does not alter core source or numerical outputs.

Read-only verification: add source/ to sys.path, import budget_engine and call verify(). For isolated reproduction, use bundled frozen input and a selected schedule row with budget_engine.trajectory; compare route/cost/delta outputs, not timing. Never overwrite completed raw files. Full clean regeneration requires the previous bundle at the provenance path read by prepare.py; all actual inputs are bundled for independent single-row replay without generation.
