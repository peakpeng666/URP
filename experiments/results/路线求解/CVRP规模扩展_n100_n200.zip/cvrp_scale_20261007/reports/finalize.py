"""Post-results descriptive reporting/packaging, no numerical search or tuning."""
from pathlib import Path
from collections import defaultdict
import csv,datetime,difflib,hashlib,json,statistics,time
ROOT=Path(__file__).resolve().parents[1];OLD=Path('/workspace/shared/vrp_unseen_geometry_20261007')
started=time.process_time()
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
s=read(ROOT/'reports/SUMMARY.json');cfg=read(ROOT/'freeze/PROTOCOL.json')
primary=next(r for r in s['paired_comparisons'] if r['primary'])
early=next(r for r in s['paired_comparisons'] if r['budget']==40000 and r['competitor']=='random_cheapest')
resources=[read(ROOT/f'raw/{stage}_RESOURCE.json') for stage in ['PREPARE','RUN','ANALYZE']]
measured=sum(r['child_total_cpu_seconds']+r['wrapper_cpu_seconds'] for r in resources)
entries=read(ROOT/'freeze/INPUT_MANIFEST.json');newhashes={r['coordinate_sha256'] for r in entries};oldhashes=set(read(ROOT/'freeze/OLD_GEOMETRY_HASHES.json')['hashes'])
assert len(newhashes)==16 and not newhashes&oldhashes
oldseeds={e['geometry_seed'] for e in read(OLD/'freeze/INPUT_MANIFEST.json')};newseeds={e['geometry_seed'] for e in entries};assert not oldseeds&newseeds
dump(ROOT/'reports/NOVELTY_CHECK.json',{'new_geometry_hash_count':len(newhashes),'previous_geometry_hash_count':len(oldhashes),'coordinate_overlap':[],'new_geometry_seeds':sorted(newseeds),'previous32_geometry_seed_overlap':[],'new_search_seeds':cfg['search_seeds'],'historical_runs_entering_statistics':0,'model_study_role':'No64k prompts/models/results/seeds loaded; no model/API call. Distinct new seed namespace.'})
with (ROOT/'reports/paired_geometry_comparisons.csv').open() as f:paired=list(csv.DictReader(f))
subgroups=[]
for b in cfg['checkpoints']:
    selected=[r for r in paired if int(r['budget'])==b and r['competitor']=='random_cheapest']
    groups={'overall':selected}
    for n in cfg['customer_counts']:groups[f'n{n}']=[r for r in selected if int(r['n'])==n]
    for f in cfg['families']:
        for n in cfg['customer_counts']:groups[f'{f}-n{n}']=[r for r in selected if r['family']==f and int(r['n'])==n]
    for name,rr in groups.items():
        vals=[float(r['rr_cost_improvement_pct']) for r in rr]
        subgroups.append({'budget':b,'group':name,'geometry_count':len(rr),'mean_rr_cost_improvement_pct':statistics.fmean(vals),'wins':sum(v>1e-9 for v in vals),'ties':sum(abs(v)<=1e-9 for v in vals),'losses':sum(v< -1e-9 for v in vals)})
with (ROOT/'reports/primary_subgroup_descriptives.csv').open('x',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(subgroups[0]));w.writeheader();w.writerows(subgroups)
late=[r for r in subgroups if r['budget']==160000]
negative=[r for r in paired if int(r['budget'])==160000 and r['competitor']=='random_cheapest' and float(r['rr_cost_improvement_pct'])< -1e-9]
best={b:s['rankings'][str(b)][0]['algorithm'] for b in cfg['checkpoints']}
claim=('当前合成样本中预定主对比支持random_regret2平均成本更低。' if primary['ci95_lower_pct']>0 else '预定主对比的95%区间包含0，无法据此支持random_regret2有稳定平均优势。' if primary['ci95_upper_pct']>=0 else '当前合成样本中预定主对比反而支持random_cheapest平均成本更低。')
report=f'''# CVRP规模扩展：n100/n200

## 短结论

16个预冻结的新几何、384条轨迹已完成；768个检查点全部可评分，384个初始化均可行，失败/缺失/重跑均为0。预定主比较在160,000 delta时，random_regret2相对random_cheapest的平均配对成本改善为{primary['mean_rr_cost_improvement_pct']:.4f}%，95%分层几何bootstrap区间[{primary['ci95_lower_pct']:.4f}%, {primary['ci95_upper_pct']:.4f}%]；几何级{primary['wins']}胜/{primary['ties']}平/{primary['losses']}负。{claim}

40,000时相应改善{early['mean_rr_cost_improvement_pct']:.4f}%，95%区间[{early['ci95_lower_pct']:.4f}%, {early['ci95_upper_pct']:.4f}%]。按平均相对遗憾排序，40,000第一为{best[40000]}，160,000第一为{best[160000]}；排名变化保留在下表，不据此挑选新方法或扩样。

重要边界：n200在40,000时四算法全部没有改善初始化，random两法各48/48轨迹尚未完成一轮搜索；160,000时random_regret2仍有21/48条未完成一轮，仅15/48条获得接受改善。结论限于这个预算区间，不能说大规模搜索已充分。

这是同一合成生成器的规模敏感性实验。新规模、几何和seed均不进入之前64k模型实验，原数据不改；没有LLM、API、付费、源码生成、参数调整。不是SOTA、田间验证、全局最优或最终盲测证据。

## 预固定设计和初始化

- uniform/clustered × n100/n200四层各4个，共16个新几何；几何seed202610075100–202610075115。
- constant5、high_variance_random、high_variance_spatial_x三需求均为总量5n；后两种为一半1、一半9；容量30、无限同质车辆。
- 两个配对搜索seed75101、75119，四算法random/worst × cheapest/regret2，共384条轨迹；检查点40,000、160,000是同条轨迹的相关重复测量。
- 初始化savings包含在delta预算内：n100为4,950，n200为19,900；n200占首检查点49.75%，占终点12.4375%。没有赠送初始化；矩阵距离和整解目标边求和另有计数，并计入CPU限制。
- 所有单点路线满足需求≤容量；savings仅合并容量允许的路线，因而初始化可行。实跑384个baseline全部通过独立checker；768次检查点ledger均吻合n(n−1)/2初始化计数。
- 固定严格改善接受、10%–30%移除；四算子、预算引擎、生成器与checker与上一轮按字节相同。已冻结384条，不补样、不换seed、不重试失败。

## 解质量和名次

先对每个几何×需求×算法的2个seed取平均，再相对同块四算法最小均值计算相对遗憾，等权平均3需求和16几何。四算法池内最低成本不是CVRP全局最优。

|预算|算法|平均相对遗憾%|平均名次（含并列）|
|---:|---|---:|---:|
'''
for b in cfg['checkpoints']:
    for r in s['rankings'][str(b)]:report+=f"|{b:,}|{r['algorithm']}|{r['mean_relative_regret_pct']:.4f}|{r['mean_midrank']:.4f}|\n"
report+='\n名次变化为160,000减40,000，负值代表名次改善；区间沿用同一次几何块bootstrap，两个检查点从不独立重采样。增加预算带来的成本改善亦先逐几何需求配对计算。\n\n|算法|名次变化|95%区间|增加预算成本改善%|95%区间|\n|---|---:|---|---:|---|\n'
for r in s['rank_and_budget_changes']:
    report+=f"|{r['algorithm']}|{r['mean_rank_change_late_minus_early']:.4f}|[{r['rank_change_ci95_lower']:.4f}, {r['rank_change_ci95_upper']:.4f}]|{r['mean_budget_cost_improvement_pct']:.4f}|[{r['budget_gain_ci95_lower_pct']:.4f}, {r['budget_gain_ci95_upper_pct']:.4f}]|\n"
c=s['primary_contrast_change_between_checkpoints']
report+=f"\n主对比改善幅度从40,000到160,000变化{c['mean_percentage_points']:.4f}个百分点，配对95%区间[{c['ci95_lower']:.4f}, {c['ci95_upper']:.4f}]。这不是把两个独立实验的区间相减。\n"
report+='\n## 异质性与搜索进展\n\n160,000时预定主对比的描述性分层结果：\n\n|组|几何数|random_regret2改善%|胜/平/负|\n|---|---:|---:|---|\n'
for r in late:report+=f"|{r['group']}|{r['geometry_count']}|{r['mean_rr_cost_improvement_pct']:.4f}|{r['wins']}/{r['ties']}/{r['losses']}|\n"
report+='\n主对比负例：'+('; '.join(f"{r['geometry_id']}: {float(r['rr_cost_improvement_pct']):.4f}%" for r in negative) if negative else '本轮没有几何平均负例；不等于所有需求/seed都胜。')+'\n'
report+='\n|n|预算|算法|无完整搜索迭代/48|无接受改善/48|平均完整迭代|\n|---:|---:|---|---:|---:|---:|\n'
for r in s['search_progress_by_size']:
    report+=f"|{r['n']}|{r['budget']:,}|{r['algorithm']}|{r['no_completed_search_iteration']}|{r['no_accepted_improvement']}|{r['mean_completed_iterations']:.3f}|\n"
report+='''
大规模下，低delta预算可能尚未完成一轮destroy/repair，或者完成候选但没有改善；这两种状态与初始化失败不同。每个算法在两个检查点都保留合法incumbent，未完成的候选不冒充可行输出。停止原因delta_budget表示正常耗尽预定delta上限，不计为失败。

## 不确定性、完整性与资源

- 统计单位是16个几何块，不是384次独立实验，更不是768个独立样本。先组内平均2搜索seed，3需求等权；每层有放回抽4个几何，10,000次、seed202610075201。所有算法、需求、seed与检查点共同保留。
- CI是条件于当前生成器和固定搜索seed的几何抽样不确定性。每层只有4几何，2搜索seed亦有限；次比较/子组/名次变化均未作多重比较校正，不作普适保证。
- 全384轨迹、768检查点、16几何共同支持集均完整。所有停止均是delta_budget；没有CPU或墙时提前停、非法解、遗漏预算、错误、补跑或删样本。
- 原独立坐标checker验证全部baseline与检查点；额外独立实现直接重算预选32个输出的欧氏目标、覆盖与容量，全部通过。全部检查点成本不升；不重审历史结果。
'''
report+=f"- 新坐标hash16个互异，与此前{len(oldhashes)}个已登记几何hash无交集。source/legacy及budget_engine未改，源码差分、冻结时间/hash和完整失败清单均保留。\n"
report+=f"- 单求解进程CPU {resources[1]['child_total_cpu_seconds']:.6f}秒，墙时{resources[1]['wall_seconds']:.6f}秒；准备、运行、分析及启动器实测合计{measured:.6f}秒。报告/打包继续单列，加10秒未逐项计量的保守开销，总任务上限180秒；完整账见RESOURCE_ACCOUNTING.json。CPU/墙时不是算法速度排名。\n"
report+='''- 外部API、LLM、付费、依赖安装、上传均为0。父任务统一私有交付。

## 文件入口

- freeze/：生成前协议、SOURCE_PROVENANCE、INITIALIZATION_GATE、输入清单、384条固定计划、冻结hash
- raw/TRAJECTORIES.jsonl：完整新轨迹、baseline/checkpoint路线与目标、所有预算/CPU/距离/目标边计数；failures/FAILURES.json保留失败清单
- reports/SUMMARY.json、paired_summary.csv、geometry_demand_aggregates.csv：主对比和几何块数据
- reports/rank_budget_changes.csv、geometry_rank_budget_changes.csv：跨预算名次与成本变化及CI
- reports/search_progress_by_size.csv、initialization_budget_checks.csv：低预算进展、初始化计费
- reports/SPOT_CHECK.json、SOURCE_DIFF.patch、NOVELTY_CHECK.json：直接复算、未改动核心代码及新几何证据
- SHA256SUMS.txt、MANIFEST.json：交付前文件校验；本报告是执行自检，非外部审计。
'''
(ROOT/'reports/REPORT_ZH.md').write_text(report)
(ROOT/'README.md').write_text('''# CVRP n100/n200 scale experiment

Read reports/REPORT_ZH.md and reports/SUMMARY.json.16 new synthetic geometry blocks;384 trajectories;768 correlated checkpoints. Main pre-fixed contrast random_regret2 vs random_cheapest at160000 deltas. Initialization included. No LLM/API/paid calls, no method changes.

All code uses the Python standard library. source/budget_engine.py and source/legacy are byte-identical to previous validated operators. Input, schedule and pre-generation/pre-run source hashes are frozen. reports/finalize.py is a post-results reporting helper and does not alter core source or numerical outputs.

Read-only verification: add source/ to sys.path, import budget_engine and call verify(). For isolated reproduction, use bundled frozen input and a selected schedule row with budget_engine.trajectory; compare route/cost/delta outputs, not timing. Never overwrite completed raw files. Full clean regeneration requires the previous bundle at the provenance path read by prepare.py; all actual inputs are bundled for independent single-row replay without generation.
''')
patch=['# Actual unified differences from vrp_unseen_geometry_20261007.\n','# budget_engine.py and all source/legacy/*.py are byte-identical.\n']
for name in ['prepare.py','run.py','analyze.py','measure.py']:
    a=OLD/'source'/name;b=ROOT/'source'/name
    patch+=difflib.unified_diff(a.read_text().splitlines(True),b.read_text().splitlines(True),fromfile='a/source/'+name,tofile='b/source/'+name)
(ROOT/'reports/SOURCE_DIFF.patch').write_text(''.join(patch))
fr=read(ROOT/'freeze/PRE_RUN_FREEZE.json');bad=[p for p,h in fr['sha256'].items() if sha(ROOT/p)!=h];assert not bad
core=[r for r in read(ROOT/'freeze/SOURCE_PROVENANCE.json') if r['file']=='source/budget_engine.py' or r['file'].startswith('source/legacy/')];assert all(r['byte_identical_to_original'] for r in core)
assert s['valid_checkpoint_observations']==768 and s['baseline_feasible']==384 and s['initialization_budget_checks_passed']==768 and s['spot_check_passed'] and s['formal_failures']==0 and s['stop_reasons']=={'delta_budget':384}
dump(ROOT/'reports/FINAL_SELF_CHECK.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'frozen_files_unchanged':True,'legacy_and_budget_engine_byte_identical':True,'new_geometries':16,'trajectories':384,'checkpoint_observations':768,'all_feasible':True,'all_initialization_budget_checks_passed':True,'extra_independent_recomputations':32,'failures':0,'source_diff_present':True,'external_uploads':0})
dump(ROOT/'reports/RESOURCE_ACCOUNTING.json',{'measured_stages':resources,'measured_preparation_run_analysis_and_wrappers_cpu_seconds':measured,'finalization_cpu_seconds_before_resource_write':time.process_time()-started,'unmeasured_setup_inspection_allowance_cpu_seconds':10.0,'allowance_is_not_measurement':True,'total_task_cpu_ceiling':180.0,'solver_hard_cpu_cap_seconds':151,'numerical_search_processes':1,'external_calls':0,'note':'Finalizer process-tree CPU and manifest/archive measured by packaging wrapper, added after it exits. No solver reruns in packaging.'})
print(json.dumps({'primary':primary,'early':early,'report':'reports/REPORT_ZH.md','cpu_before_finalization':measured,'finalization_cpu_so_far':time.process_time()-started},ensure_ascii=False))
