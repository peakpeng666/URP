"""Execute only fresh geometries with the unchanged frozen budget engine."""
import json, os, resource, sys, time, traceback
from pathlib import Path
sys.dont_write_bytecode=True
from budget_engine import ROOT, verify, read, dump, utc, trajectory, from_dict

def main():
    verify();cfg=read(ROOT/'freeze/PROTOCOL.json');calls=read(ROOT/'freeze/SCHEDULE.json')
    start_cpu=time.process_time();start_wall=time.perf_counter()
    resource.setrlimit(resource.RLIMIT_CPU,(cfg['process_cpu_hard_limit'],cfg['process_cpu_hard_limit']+1))
    dump(ROOT/'raw/STARTED.json',{'utc':utc(),'pid':os.getpid(),'python':sys.version,'cpu_affinity':sorted(os.sched_getaffinity(0)),'scheduled_trajectories':len(calls),'no_historical_results_loaded':True,'reused_byte_identical_checkpoint_engine':True})
    failures=[]
    with (ROOT/'raw/TRAJECTORIES.jsonl').open('x') as out:
        for call in calls:
            row={**call,'started_utc':utc()}
            if time.process_time()+cfg['per_trajectory_cpu_limit']+cfg['return_reserve_cpu']>cfg['process_cpu_soft_gate']:
                row.update(status='not_run_global_cpu_gate',missing_budgets=cfg['checkpoints'])
            elif time.perf_counter()-start_wall+cfg['per_trajectory_wall_limit']>cfg['execution_wall_limit']:
                row.update(status='not_run_global_wall_gate',missing_budgets=cfg['checkpoints'])
            else:
                try:
                    inst=from_dict(read(ROOT/call['input_file']))
                    row.update(trajectory(inst,call['pair'],call['search_seed'],cfg));row['status']='executed'
                except Exception as e:
                    row.update(status='runner_failure',error={'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()},missing_budgets=cfg['checkpoints'])
            row['finished_utc']=utc()
            out.write(json.dumps(row,ensure_ascii=False,allow_nan=False)+'\n');out.flush()
            if row['status']!='executed' or row.get('error') or row.get('missing_budgets') or row.get('stop_reason')!='delta_budget' or any(not cp['scoreable'] for cp in row.get('checkpoints',[])):
                failures.append({'run_id':call['run_id'],'status':row['status'],'stop_reason':row.get('stop_reason'),'error':row.get('error'),'missing_budgets':row.get('missing_budgets',[])})
            if (call['run_id']+1)%144==0:print(json.dumps({'completed':call['run_id']+1,'cpu_seconds':time.process_time(),'wall_seconds':time.perf_counter()-start_wall}),flush=True)
    dump(ROOT/'failures/FAILURES.json',{'count':len(failures),'rows':failures,'retries':0})
    verify()
    dump(ROOT/'raw/COMPLETION.json',{'utc':utc(),'planned_rows':len(calls),'written_rows':len(calls),'failure_count':len(failures),'execution_cpu_seconds':time.process_time()-start_cpu,'process_cpu_seconds':time.process_time(),'wall_seconds':time.perf_counter()-start_wall,'external_api_calls':0,'model_calls':0,'paid_calls':0,'network_calls':0,'old_runs_counted':0,'frozen_hashes_unchanged':True})
if __name__=='__main__':main()
