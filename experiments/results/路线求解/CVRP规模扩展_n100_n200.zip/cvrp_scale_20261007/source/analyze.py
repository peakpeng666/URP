"""Frozen paired geometry analysis; standard library; no old numeric results."""
from pathlib import Path
from collections import defaultdict,Counter
import csv,json,math,random,resource,statistics,sys,time
sys.dont_write_bytecode=True
from budget_engine import ROOT,verify,read,dump,sha,utc

def mean(xs):return statistics.fmean(xs)
def csvwrite(name,rows):
    if not rows:return
    with (ROOT/'reports'/name).open('x',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def quantile(xs,p):
    x=sorted(xs);a=(len(x)-1)*p;i=int(a);return x[i]+(x[min(i+1,len(x)-1)]-x[i])*(a-i)
def direct_check(obj,output):
    routes=output['routes'];n=len(obj['demands'])-1;nodes=[];terms=[];loads=[]
    for r in routes:
        assert r[0]==r[-1]==0 and 0 not in r[1:-1]
        nodes+=r[1:-1];load=sum(obj['demands'][j] for j in r[1:-1]);loads.append(load);assert load<=obj['capacity']
        for a,b in zip(r,r[1:]):
            dx=obj['coordinates'][a][0]-obj['coordinates'][b][0];dy=obj['coordinates'][a][1]-obj['coordinates'][b][1]
            terms.append(math.sqrt(dx*dx+dy*dy))
    assert sorted(nodes)==list(range(1,n+1));cost=math.fsum(terms)
    assert math.isclose(cost,output['reported_cost'],rel_tol=1e-10,abs_tol=1e-9)
    return {'recomputed_cost':cost,'reported_cost':output['reported_cost'],'absolute_difference':abs(cost-output['reported_cost']),'route_count':len(routes),'max_route_load':max(loads),'passed':True}

def main():
    resource.setrlimit(resource.RLIMIT_CPU,(10,11));started=time.process_time();verify()
    cfg=read(ROOT/'freeze/PROTOCOL.json');schedule=read(ROOT/'freeze/SCHEDULE.json');manifest=read(ROOT/'freeze/INPUT_MANIFEST.json')
    rows=[json.loads(l) for l in (ROOT/'raw/TRAJECTORIES.jsonl').read_text().splitlines()]
    assert len(rows)==len(schedule)==cfg['formal_trajectories']
    assert [r['run_id'] for r in rows]==[r['run_id'] for r in schedule]
    algorithms=['_'.join(p) for p in cfg['pairs']];budgets=cfg['checkpoints'];seeds=cfg['search_seeds'];demands=cfg['demand_modes']
    geo_meta={e['geometry_id']:{k:e[k] for k in ('family','n','replicate','geometry_seed')} for e in manifest};geos=sorted(geo_meta)
    observed={};obs=[];spot=[];issues=[];statuses=Counter();stops=Counter();baseline_valid=0;initialization_checks=[]
    for r in rows:
        statuses[r['status']]+=1
        stops[r.get('stop_reason',r['status'])]+=1
        baseline_valid+=bool(r.get('baseline_check',{}).get('accepted'))
        for k in ('geometry_id','algorithm','search_seed','input_sha256'):assert r[k]==schedule[r['run_id']][k]
        prev=r.get('baseline',{}).get('reported_cost',math.inf) if r.get('baseline') else math.inf
        for cp in r.get('checkpoints',[]):
            key=(r['geometry_id'],r['demand_mode'],r['algorithm'],r['search_seed'],cp['budget'])
            assert key not in observed
            valid=bool(r['status']=='executed' and not r.get('error') and cp['scoreable'] and cp['deltas']==cp['budget'] and cp['check']['accepted'])
            cost=cp['check']['recomputed_cost'] if valid else None
            observed[key]=cost
            if cost is not None:
                assert cost<=prev+1e-9;prev=cost
                assert sum(cp['delta_by_kind'].values())==cp['budget']
                expected=r['n']*(r['n']-1)//2
                assert cp['delta_by_kind']['savings']==expected
                initialization_checks.append({'run_id':r['run_id'],'n':r['n'],'budget':cp['budget'],'savings_deltas':cp['delta_by_kind']['savings'],'expected':expected,'passed':True})
            obs.append({k:r[k] for k in ('run_id','geometry_id','family','n','replicate','demand_mode','algorithm','search_seed')}|{'budget':cp['budget'],'valid':valid,'cost':cost,'routes':cp['check']['route_count'],'deltas':cp['deltas'],'iterations_completed':cp['iterations_completed'],'accepted_improvements':cp['accepted_improvements'],'initialization_savings_deltas':cp['delta_by_kind']['savings'],'baseline_cost':r['baseline']['reported_cost'] if r.get('baseline') else None,'solver_cpu_seconds':cp['solver_cpu_seconds']})
            if r['replicate']==0 and r['demand_mode']=='constant5' and r['search_seed']==seeds[0]:
                try:result=direct_check(read(ROOT/r['input_file']),cp['output'])
                except Exception as e:result={'passed':False,'error':repr(e)}
                spot.append({'run_id':r['run_id'],'geometry_id':r['geometry_id'],'algorithm':r['algorithm'],'budget':cp['budget'],**result})
    usable=[];excluded=[]
    for g in geos:
        missing=[(d,a,s,b) for d in demands for a in algorithms for s in seeds for b in budgets if observed.get((g,d,a,s,b)) is None]
        (excluded if missing else usable).append({'geometry_id':g,'missing_or_invalid_cells':missing} if missing else g)
    block=[];costs={};regrets={};midranks={}
    for g in usable:
        for d in demands:
            for b in budgets:
                means={a:mean(observed[g,d,a,s,b] for s in seeds) for a in algorithms};minimum=min(means.values())
                for a,c in means.items():
                    rel=100*(c/minimum-1);rank=1+sum(v<c-1e-9 for v in means.values())+.5*sum(abs(v-c)<=1e-9 for k,v in means.items() if k!=a)
                    costs[g,d,a,b]=c;regrets[g,d,a,b]=rel;midranks[g,d,a,b]=rank
                    block.append({'geometry_id':g,**geo_meta[g],'demand_mode':d,'budget':b,'algorithm':a,'seed_mean_cost':c,'relative_regret_pct':rel,'midrank':rank})
    geom=[]
    for g in usable:
        for b in budgets:
            for a in algorithms:geom.append({'geometry_id':g,**geo_meta[g],'budget':b,'algorithm':a,'mean_relative_regret_pct':mean(regrets[g,d,a,b] for d in demands),'mean_midrank':mean(midranks[g,d,a,b] for d in demands)})
    rr=cfg['primary_algorithm'];competitors=[a for a in algorithms if a!=rr];contrasts=[];gain={}
    for g in usable:
        for b in budgets:
            for a in competitors:
                gains=[100*(costs[g,d,a,b]-costs[g,d,rr,b])/costs[g,d,a,b] for d in demands]
                val=mean(gains);gain[g,b,a]=val
                contrasts.append({'geometry_id':g,**geo_meta[g],'budget':b,'comparison':rr+' vs '+a,'competitor':a,'rr_cost_improvement_pct':val,'constant5_pct':gains[0],'high_variance_random_pct':gains[1],'high_variance_spatial_x_pct':gains[2]})
    groups={(f,n):[g for g in usable if geo_meta[g]['family']==f and geo_meta[g]['n']==n] for f in cfg['families'] for n in cfg['customer_counts']}
    contrast_keys=[(b,a) for b in budgets for a in competitors]
    boot={key:[] for key in contrast_keys};rng=random.Random(cfg['bootstrap_seed'])
    rank_change={(g,a):mean(midranks[g,d,a,budgets[1]]-midranks[g,d,a,budgets[0]] for d in demands) for g in usable for a in algorithms}
    budget_gain={(g,a):mean(100*(costs[g,d,a,budgets[0]]-costs[g,d,a,budgets[1]])/costs[g,d,a,budgets[0]] for d in demands) for g in usable for a in algorithms}
    rank_boot={a:[] for a in algorithms};budget_boot={a:[] for a in algorithms};contrast_change_boot=[]
    if all(groups.values()):
        for _ in range(cfg['bootstrap_replicates']):
            draw=[rng.choice(gs) for gs in groups.values() for _ in range(len(gs))]
            for b,a in contrast_keys:boot[b,a].append(mean(gain[g,b,a] for g in draw))
            for a in algorithms:
                rank_boot[a].append(mean(rank_change[g,a] for g in draw))
                budget_boot[a].append(mean(budget_gain[g,a] for g in draw))
            contrast_change_boot.append(mean(gain[g,budgets[1],cfg['primary_competitor']]-gain[g,budgets[0],cfg['primary_competitor']] for g in draw))
    paired=[]
    for b,a in contrast_keys:
        vals=[gain[g,b,a] for g in usable];dist=boot[b,a]
        paired.append({'budget':b,'competitor':a,'primary':b==cfg['primary_budget'] and a==cfg['primary_competitor'],'geometry_count':len(vals),'mean_rr_cost_improvement_pct':mean(vals) if vals else None,'median_pct':statistics.median(vals) if vals else None,'min_pct':min(vals) if vals else None,'max_pct':max(vals) if vals else None,'ci95_lower_pct':quantile(dist,.025) if dist else None,'ci95_upper_pct':quantile(dist,.975) if dist else None,'wins':sum(v>1e-9 for v in vals),'ties':sum(abs(v)<=1e-9 for v in vals),'losses':sum(v< -1e-9 for v in vals)})
    changes=[];geometry_changes=[]
    for a in algorithms:
        vals=[rank_change[g,a] for g in usable];bd=budget_boot[a];rd=rank_boot[a]
        changes.append({'algorithm':a,'geometry_count':len(usable),'mean_rank_change_late_minus_early':mean(vals) if vals else None,'rank_change_ci95_lower':quantile(rd,.025) if rd else None,'rank_change_ci95_upper':quantile(rd,.975) if rd else None,'rank_improved_geometries':sum(v< -1e-9 for v in vals),'rank_tied_geometries':sum(abs(v)<=1e-9 for v in vals),'rank_worsened_geometries':sum(v>1e-9 for v in vals),'mean_budget_cost_improvement_pct':mean(budget_gain[g,a] for g in usable) if usable else None,'budget_gain_ci95_lower_pct':quantile(bd,.025) if bd else None,'budget_gain_ci95_upper_pct':quantile(bd,.975) if bd else None})
        for g in usable:geometry_changes.append({'geometry_id':g,**geo_meta[g],'algorithm':a,'mean_rank_change_late_minus_early':rank_change[g,a],'budget_cost_improvement_pct':budget_gain[g,a]})
    contrast_change={'mean_percentage_points':mean(gain[g,budgets[1],cfg['primary_competitor']]-gain[g,budgets[0],cfg['primary_competitor']] for g in usable) if usable else None,'ci95_lower':quantile(contrast_change_boot,.025) if contrast_change_boot else None,'ci95_upper':quantile(contrast_change_boot,.975) if contrast_change_boot else None}
    by_size=[]
    for n in cfg['customer_counts']:
        selected=[r for r in obs if r['n']==n]
        for b in budgets:
            for a in algorithms:
                sr=[r for r in selected if r['budget']==b and r['algorithm']==a]
                by_size.append({'n':n,'budget':b,'algorithm':a,'observations':len(sr),'valid':sum(r['valid'] for r in sr),'no_completed_search_iteration':sum(r['iterations_completed']==0 for r in sr),'no_accepted_improvement':sum(r['accepted_improvements']==0 for r in sr),'mean_completed_iterations':mean(r['iterations_completed'] for r in sr) if sr else None,'mean_accepted_improvements':mean(r['accepted_improvements'] for r in sr) if sr else None})
    aggregate=[]
    for b in budgets:
        for group,gs,ds in [('overall',usable,demands)]+[(d,usable,[d]) for d in demands]+[(f'{f}-n{n}',v,demands) for (f,n),v in groups.items()]:
            for a in algorithms:
                aggregate.append({'budget':b,'group':group,'algorithm':a,'geometries':len(gs),'mean_relative_regret_pct':mean(mean(regrets[g,d,a,b] for d in ds) for g in gs) if gs else None,'mean_midrank':mean(mean(midranks[g,d,a,b] for d in ds) for g in gs) if gs else None})
    rankings={str(b):sorted([r for r in aggregate if r['budget']==b and r['group']=='overall'],key=lambda r:(r['mean_relative_regret_pct'],r['algorithm'])) for b in budgets}
    audit={'additional_direct_recomputations':len(spot),'planned_direct_recomputations':32,'all_passed':len(spot)==32 and all(r['passed'] for r in spot),'rows':spot,'all_new_checkpoint_monotonicity_checks_passed':True,'old_outputs_reaudited':0,'all_frozen_hashes_unchanged':True,'baseline_checks_passed':baseline_valid,'planned_baseline_checks':len(schedule),'initialization_budget_checks_passed':len(initialization_checks)}
    dump(ROOT/'reports/SPOT_CHECK.json',audit)
    summary={'utc':utc(),'scope':cfg['scope'],'planned_geometries':cfg['geometry_count'],'usable_geometries':len(usable),'excluded_geometries':excluded,'planned_trajectories':len(schedule),'executed_trajectories':statuses['executed'],'checkpoint_observations':len(obs),'valid_checkpoint_observations':sum(r['valid'] for r in obs),'formal_failures':read(ROOT/'failures/FAILURES.json')['count'],'rankings':rankings,'paired_comparisons':paired,'rank_and_budget_changes':changes,'primary_contrast_change_between_checkpoints':contrast_change,'search_progress_by_size':by_size,'stop_reasons':dict(stops),'baseline_feasible':baseline_valid,'initialization_budget_checks_passed':len(initialization_checks),'complete_common_support':len(usable)==cfg['geometry_count'],'bootstrap':{'unit':'geometry','replicates':cfg['bootstrap_replicates'],'seed':cfg['bootstrap_seed'],'cells':{str(k):len(v) for k,v in groups.items()},'interval':'percentile95','scope':'Conditional on synthetic generators and fixed search seeds; correlated checkpoints retained in same resample'},'spot_check_passed':audit['all_passed'],'old_runs_counted':0,'analysis_cpu_seconds_before_write':time.process_time()-started}
    dump(ROOT/'reports/SUMMARY.json',summary)
    csvwrite('rank_budget_changes.csv',changes);csvwrite('geometry_rank_budget_changes.csv',geometry_changes);csvwrite('search_progress_by_size.csv',by_size);csvwrite('initialization_budget_checks.csv',initialization_checks);csvwrite('checkpoint_observations.csv',obs);csvwrite('geometry_demand_aggregates.csv',block);csvwrite('geometry_aggregates.csv',geom);csvwrite('paired_geometry_comparisons.csv',contrasts);csvwrite('paired_summary.csv',paired);csvwrite('aggregate_rankings.csv',aggregate)
    csvwrite('bootstrap_paired_means.csv',[{'resample':i,**{f'{b}_{a}':boot[b,a][i] for b,a in contrast_keys}} for i in range(len(next(iter(boot.values()))))])
    print(json.dumps(summary,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
