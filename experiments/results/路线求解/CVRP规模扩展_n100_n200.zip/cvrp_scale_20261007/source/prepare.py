"""Freeze a finite larger-scale CVRP experiment before any new generation."""
from pathlib import Path
import hashlib,json,math,random,statistics,sys,time
sys.dont_write_bytecode=True
from budget_engine import ROOT,legacy,from_dict,sha,dump,read,utc
OLD=Path('/workspace/shared/vrp_unseen_geometry_20261007')
def main():
    started=time.process_time()
    cfg={
      'name':'CVRP larger-scale n100/n200 20261007',
      'scope':'Finite new synthetic dev geometries from unchanged uniform/clustered generators at n100/n200. Not real-field validation, SOTA, global optimality, a new distribution family or final blind benchmark. New seeds are unrelated to the 64k model study; no model call or generated operator.',
      'families':['uniform','clustered'],'customer_counts':[100,200],'replicates_per_cell':4,'geometry_count':16,
      'geometry_seed_base':202610075100,'geometry_seeds':list(range(202610075100,202610075116)),
      'geometry_seed_assignment':'family uniform,clustered; n100,200; replicate0..3; seed base+index',
      'search_seeds':[75101,75119],'schedule_seed':202610075199,
      'demand_modes':['constant5','high_variance_random','high_variance_spatial_x'],'demand_seed_offset':1000000,'capacity':30,
      'demand_rule':'constant5=[5]*n; alternatives n/2 ones and n/2 nines. Random shuffle seed=geometry_seed+1000000; spatial9 assigned to largest x then y then node ID. All demand totals5*n, every demand<=capacity30.',
      'pairs':[['random','cheapest'],['random','regret2'],['worst','cheapest'],['worst','regret2']],
      'checkpoints':[40000,160000],'formal_trajectories':384,'formal_checkpoint_observations':768,
      'algorithm_rule':'budget_engine.py, legacy algorithm and vendored generator/checker are byte-identical to previous study. Strict improvement,10-30% removal, deterministic iteration seeds. No method changes, tuning or retries.',
      'eval_unit':'Candidate delta arithmetic charged before arithmetic: savings+removal+insertion. Matrix distances, full objective edge sums and feasibility checks excluded from delta total and counted separately. Equal delta is not equal walltime or FLOPs.',
      'initialization_rule':'Initialization is paid inside each trajectory. Savings uses n*(n-1)/2 delta expressions:4950 at n100;19900 at n200. Both strictly below40000. Every demand<=30 and unlimited fleet means singleton initialization is feasible; merges preserve capacity. Baseline must pass checker, and initial-budget equality is verified from each checkpoint ledger. No free initialization or conditional scale change.',
      'sampling_rule':'Freeze protocol/source before any new coordinates; generate all16 in fixed seed order. No replacement, expansion, result-based exclusions or winner selection.',
      'independence':'16 geometry blocks.3 paired demands,2 paired search seeds,4 algorithms,2 correlated checkpoints are repeated measurements, not384 or768 independent samples.',
      'aggregation':'Average2 seeds within geometry-demand-algorithm-checkpoint. Relative regret100*(cost/min_four_costs-1); equal3 demands per geometry then equal16 geometries. Rank uses mean seed costs and midranks for ties; oracle is only these4 operators.',
      'primary_contrast':'At160000:100*(random_cheapest_mean_cost-random_regret2_mean_cost)/random_cheapest_mean_cost within geometry-demand then mean3 demands and16 geometries; positive favors random_regret2.',
      'secondary_contrasts':'Other competitors,40000, demand/family/n breakdown, checkpoint quality gains and mean rank changes are descriptive; no multiplicity-adjusted claims. Rank change is rank_at160000 minus rank_at40000; negative improves rank.',
      'intervals':'95% percentile stratified paired geometry bootstrap10000 draws,seed202610075201. Sample4 geometries with replacement in each family*n cell; keep demands,seeds,algorithms and checkpoints together. Same draws for all contrasts and rank changes. Conditional on this generator and these search seeds.',
      'bootstrap_seed':202610075201,'bootstrap_replicates':10000,'primary_algorithm':'random_regret2','primary_competitor':'random_cheapest','primary_budget':160000,'tie_tolerance':1e-9,
      'failure_rule':'Preserve every planned trajectory, error, missing checkpoint and unrun row. No retries, imputation or replacement. Common support requires all4 algorithms*2 seeds*3 demands*2 checkpoints per geometry; list exclusions. If incomplete, label incomplete and no confirmatory claim. If any stratum empty do not bootstrap pooled estimand.',
      'audit_rule':'Existing independent coordinate checker on all new baselines and checkpoints. Extra direct coverage/capacity/objective recomputation at replicate0,constant5,search_seed75101 in each4 family*n cell*4 algorithms*2 checkpoints=32 outputs. Verify monotonicity and initialization delta counts on all rows. Do not audit old numerical results.',
      'old_results':'Read previous input coordinate hashes only for novelty; compare copied source bytes. No historical runs are counted as new or enter pooled analysis.',
      'per_trajectory_cpu_limit':2.0,'per_trajectory_wall_limit':30.0,'process_cpu_soft_gate':144.0,'process_cpu_hard_limit':150,'return_reserve_cpu':4.0,'execution_wall_limit':900.0,
      'total_task_cpu_ceiling':180.0,'resource_plan':'One solver process hard cap151 CPU s, soft gate144. Analysis hard cap11; preparation and finalization measured.10 CPU s conservative setup/inspection allowance. Total measured plus allowance must be<=180; no external calls/dependencies.',
      'external_api_calls':0,'model_calls':0,'paid_calls':0,'new_dependencies':0,'external_uploads':0,'protocol_written_utc':utc()}
    dump(ROOT/'freeze/PROTOCOL.json',cfg)
    (ROOT/'freeze/PROTOCOL_ZH.md').write_text('''# 大规模CVRP短冻结\n\n新几何16个：uniform/clustered × n100/n200各4个，种子202610075100至202610075115。每几何3种等总需求，搜索seed75101、75119，4个原封不动的算子组合；384条轨迹，仅保存40,000和160,000 delta，768个相关检查点。\n\n初始化计费：n100为4,950、n200为19,900次savings delta，低于40,000。无限同质车辆且单需求不超过容量30，单点路线可行，合并保容量；不赠送初始化。主对比预定160,000时random_regret2对random_cheapest的几何块平均配对改善。先平均2搜索seed与3需求，再以16几何为单位，4层各4几何的10,000次bootstrap；同一重采样保留两个检查点，报告CI、异质性及名次变化。\n\n不因结果补样、不挑winner、不重试失败。CPU总上限180秒；单数值进程硬上限151秒，分析11秒，另记录准备/检查/封装资源并保留10秒保守开销。无LLM/API/付费/新依赖/上传。仅为合成开发分布的规模敏感性实验，不是SOTA、田间验证或全局最优证据。\n''')
    dump(ROOT/'freeze/PRE_GENERATION_FREEZE.json',{'utc':utc(),'new_geometries_generated_before_freeze':0,'new_trajectories_run_before_freeze':0,'sha256':{str(p.relative_to(ROOT)):sha(p) for p in sorted((ROOT/'source').rglob('*.py'))}|{'freeze/PROTOCOL.json':sha(ROOT/'freeze/PROTOCOL.json'),'freeze/PROTOCOL_ZH.md':sha(ROOT/'freeze/PROTOCOL_ZH.md')}})
    old_hashes=sorted(set(read(OLD/'freeze/OLD_GEOMETRY_HASHES.json')['hashes'])|{e['coordinate_sha256'] for e in read(OLD/'freeze/INPUT_MANIFEST.json')})
    dump(ROOT/'freeze/OLD_GEOMETRY_HASHES.json',{'purpose':'Novelty only; no old outcomes loaded','count':len(old_hashes),'hashes':old_hashes})
    entries=[];new_hashes=[]
    specs=[(fam,n,r) for fam in cfg['families'] for n in cfg['customer_counts'] for r in range(cfg['replicates_per_cell'])]
    for index,(fam,n,rep) in enumerate(specs):
        seed=cfg['geometry_seeds'][index];base=legacy.generate_instance(n,fam,seed,cfg['capacity']).to_dict()
        geom=f'scale-{fam}-n{n}-r{rep}-s{seed}'
        ch=hashlib.sha256(json.dumps(base['coordinates'],separators=(',',':')).encode()).hexdigest()
        assert ch not in old_hashes and ch not in new_hashes;new_hashes.append(ch)
        rd=[1]*(n//2)+[9]*(n//2);random.Random(seed+cfg['demand_seed_offset']).shuffle(rd)
        spatial=[1]*n
        order=sorted(range(1,n+1),key=lambda i:(*base['coordinates'][i],i))
        for node in order[n//2:]:spatial[node-1]=9
        for mode,dem in zip(cfg['demand_modes'],[[5]*n,rd,spatial]):
            obj={**base,'instance_id':geom+'-'+mode,'demands':[0]+dem};inst=from_dict(obj)
            fn='input/'+obj['instance_id']+'.json';dump(ROOT/fn,obj)
            xs=[a[0] for a in base['coordinates'][1:]];mx=statistics.mean(xs);md=statistics.mean(dem)
            den=math.sqrt(sum((x-mx)**2 for x in xs)*sum((q-md)**2 for q in dem))
            entries.append({'geometry_id':geom,'family':fam,'n':n,'replicate':rep,'geometry_seed':seed,'demand_mode':mode,'input_file':fn,'input_sha256':sha(ROOT/fn),'coordinate_sha256':ch,'total_demand':sum(dem),'demand_variance':statistics.pvariance(dem),'demand_x_pearson':sum((x-mx)*(q-md) for x,q in zip(xs,dem))/den if den else None})
    dump(ROOT/'freeze/INPUT_MANIFEST.json',entries)
    schedule=[{**e,'search_seed':s,'algorithm':'_'.join(pair),'pair':pair} for e in entries for s in cfg['search_seeds'] for pair in cfg['pairs']]
    random.Random(cfg['schedule_seed']).shuffle(schedule)
    for i,c in enumerate(schedule):c['run_id']=i
    dump(ROOT/'freeze/SCHEDULE.json',schedule)
    provenance=[]
    for p in sorted((ROOT/'source').rglob('*.py')):
        old=OLD/p.relative_to(ROOT)
        provenance.append({'file':str(p.relative_to(ROOT)),'sha256':sha(p),'source':str(old) if old.exists() else None,'source_sha256':sha(old) if old.exists() else None,'byte_identical_to_original':sha(p)==sha(old) if old.exists() else None})
    assert all(r['byte_identical_to_original'] for r in provenance if r['file']=='source/budget_engine.py' or r['file'].startswith('source/legacy/'))
    dump(ROOT/'freeze/SOURCE_PROVENANCE.json',provenance)
    dump(ROOT/'freeze/INITIALIZATION_GATE.json',{'utc':utc(),'before_formal_runs':True,'proof':'Singletons feasible because every demand<=30 and unlimited fleet. Savings only merges capacity-feasible routes. Savings all-pairs delta count n*(n-1)/2 is below first checkpoint. Objective and distance work retains CPU limit and separate counters.','n100_savings_deltas':4950,'n200_savings_deltas':19900,'first_checkpoint':40000,'gate_passed':True,'empirical_validation':'All new baseline checker results and checkpoint savings counters in raw; no free precomputation.'})
    dump(ROOT/'freeze/PRE_RUN_FREEZE.json',{'utc':utc(),'formal_runs_before_freeze':0,'new_geometries':16,'duplicate_old_geometries':0,'sha256':{str(p.relative_to(ROOT)):sha(p) for dr in ['source','input','freeze'] for p in sorted((ROOT/dr).rglob('*')) if p.is_file()}})
    dump(ROOT/'raw/PREPARATION_RESOURCE.json',{'cpu_seconds':time.process_time()-started,'new_geometry_count':len(new_hashes),'input_count':len(entries),'schedule_count':len(schedule)})
    print(json.dumps({'prepared':True,'geometries':16,'trajectories':len(schedule),'protocol_sha256':sha(ROOT/'freeze/PROTOCOL.json'),'freeze_sha256':sha(ROOT/'freeze/PRE_RUN_FREEZE.json')}))
if __name__=='__main__':main()
