"""Frozen equal-delta anytime-budget experiment. Standard library, no network."""
from pathlib import Path
import argparse, copy, datetime, hashlib, importlib.util, json, math, os, random, resource, signal, sys, time, traceback
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
ORIGINAL = ROOT/'input/independent_cvrp_demand_shift_20261006'
spec = importlib.util.spec_from_file_location('legacy', ROOT/'source/legacy/experiment.py')
legacy = importlib.util.module_from_spec(spec); spec.loader.exec_module(legacy)
from urp_cvrp.instance import from_dict
from urp_cvrp.checker import check_solution

def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def read(p): return json.loads(Path(p).read_text())
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p, data):
    with Path(p).open('x') as f: json.dump(data,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')
def verify():
    fr=read(ROOT/'freeze/PRE_RUN_FREEZE.json')
    bad=[p for p,h in fr['sha256'].items() if sha(ROOT/p)!=h]
    if bad: raise RuntimeError('freeze mismatch: '+repr(bad))
    return fr

class CheckpointBudget(legacy.Budget):
    """Flush checkpoint before asking for the next delta expression.

    Thus all uncounted operations following delta B can finish (including a
    full candidate's objective computation/acceptance). This is identical to
    independently stopping legacy.run_one before delta B+1 with no iteration cap.
    """
    def __init__(self, points, cfg, callback):
        super().__init__(max(points),cfg['per_trajectory_cpu_limit'],cfg['per_trajectory_wall_limit'])
        self.points=set(points); self.emitted=set(); self.callback=callback
    def delta(self,kind):
        if self.deltas in self.points and self.deltas not in self.emitted:
            self.callback(self.deltas)
            self.emitted.add(self.deltas)
        super().delta(kind)


def trajectory(instance,pair,seed,cfg):
    state={'output':None,'baseline':None,'iterations_started':0,'iterations_completed':0,'accepted_improvements':0}
    checkpoints=[]; trace=[]; stop='unexpected'; error=None
    def checkpoint(b):
        usage=budget.snapshot()
        checkpoints.append({'budget':b,'output':copy.deepcopy(state['output']),
            'iterations_started':state['iterations_started'], 'iterations_completed':state['iterations_completed'],
            'accepted_improvements':state['accepted_improvements'],**usage})
    budget=CheckpointBudget(cfg['checkpoints'],cfg,checkpoint)
    def cpu_signal(s,f): raise legacy.StopBudget('hard_cpu_limit')
    def wall_signal(s,f): raise legacy.StopBudget('hard_wall_limit')
    oldc=signal.signal(signal.SIGPROF,cpu_signal);oldw=signal.signal(signal.SIGALRM,wall_signal)
    signal.setitimer(signal.ITIMER_PROF,cfg['per_trajectory_cpu_limit'])
    signal.setitimer(signal.ITIMER_REAL,cfg['per_trajectory_wall_limit'])
    try:
        matrix=legacy.matrix_for(instance,budget)
        routes=legacy.savings(instance,matrix,budget);cost=legacy.cost_of(routes,matrix,budget)
        state['output']=legacy.output_for(routes,cost);state['baseline']=copy.deepcopy(state['output'])
        iteration=0
        while True:
            budget.check();state['iterations_started']+=1
            lo=min(instance.n_customers,max(2,math.ceil(.1*instance.n_customers)))
            hi=min(instance.n_customers,max(lo,math.ceil(.3*instance.n_customers)))
            q=random.Random(legacy.derived_seed(seed,'q',iteration)).randint(lo,hi)
            rng=random.Random(legacy.derived_seed(seed,'removal',iteration))
            partial,removed=legacy.destroy(routes,pair[0],q,rng,matrix,budget)
            candidate=legacy.repair(partial,removed,pair[1],instance,matrix,budget)
            candidate_cost=legacy.cost_of(candidate,matrix,budget)
            state['iterations_completed']+=1
            accepted=candidate_cost < cost-1e-9
            if accepted:
                routes,cost=candidate,candidate_cost
                state['output']=legacy.output_for(routes,cost);state['accepted_improvements']+=1
            trace.append({'iteration':iteration,'q':q,'candidate_cost':candidate_cost,'accepted':accepted,'incumbent_cost':cost,'deltas':budget.deltas})
            iteration+=1
    except legacy.StopBudget as e: stop=str(e)
    except Exception as e:
        stop='algorithm_failure';error={'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()}
    finally:
        signal.setitimer(signal.ITIMER_PROF,0);signal.setitimer(signal.ITIMER_REAL,0)
        signal.signal(signal.SIGPROF,oldc);signal.signal(signal.SIGALRM,oldw)
    usage=budget.snapshot(); checker_start=time.process_time()
    baseline_check=check_solution(instance,state['baseline']).to_dict()
    for c in checkpoints:
        c['check']=check_solution(instance,c['output']).to_dict()
        c['scoreable']=bool(c['check']['accepted'] and baseline_check['accepted'] and c['deltas']==c['budget'])
    missing=[b for b in cfg['checkpoints'] if b not in {x['budget'] for x in checkpoints}]
    return {'stop_reason':stop,'error':error,'baseline':state['baseline'],'baseline_check':baseline_check,
        'checkpoints':checkpoints,'missing_budgets':missing,'trace':trace,**usage,
        'checker_cpu_seconds':time.process_time()-checker_start}


def execute():
    verify();cfg=read(ROOT/'freeze/PROTOCOL.json');schedule=read(ROOT/'freeze/SCHEDULE.json')
    start_cpu=time.process_time();start_wall=time.perf_counter()
    dump(ROOT/'raw/STARTED.json',{'utc':utc(),'pid':os.getpid(),'python':sys.version,'cpu_affinity':sorted(os.sched_getaffinity(0)),
         'process_cpu_start':start_cpu,'run_cpu_hard_limit':cfg['process_cpu_hard_limit'],'scheduled_trajectories':len(schedule)})
    # CPU limit bounds this single-process solver + tests + validation + serialization.
    resource.setrlimit(resource.RLIMIT_CPU,(cfg['process_cpu_hard_limit'],cfg['process_cpu_hard_limit']+1))
    tests=[]
    smoke=read(ROOT/'freeze/SMOKE.json')
    instance=from_dict(read(ROOT/smoke['file']))
    for pair in cfg['pairs']:
        long=trajectory(instance,pair,cfg['smoke_seed'],cfg)
        tests.append({'kind':'checkpoint_trajectory','pair':pair,'result':long})
        for b in cfg['checkpoints']:
            ref=legacy.run_one(instance,pair,cfg['smoke_seed'],10**9,
               {'delta_limit':b,'cpu_limit_seconds':cfg['per_trajectory_cpu_limit'],'wall_limit_seconds':cfg['per_trajectory_wall_limit']})
            cp=next((x for x in long['checkpoints'] if x['budget']==b),None)
            ok=bool(cp and cp['output']==ref['output'] and cp['deltas']==ref['deltas']==b and ref['check']['accepted'])
            tests.append({'kind':'standalone_equivalence','pair':pair,'budget':b,'passed':ok,'reference':ref})
    dump(ROOT/'raw/SMOKE.json',{'tests':tests,'all_passed':all(t.get('passed',True) for t in tests)})
    if not all(t.get('passed',True) for t in tests):
        dump(ROOT/'failures/SMOKE_FAILURE.json',{'utc':utc(),'action':'formal not run','reason':'checkpoint equivalence mismatch'})
        raise RuntimeError('Smoke failed; formal not run')
    formal_start_cpu=time.process_time()
    failures=[];done=0
    with (ROOT/'raw/TRAJECTORIES.jsonl').open('x') as f:
        for call in schedule:
            common={**call,'started_utc':utc()}
            elapsed=time.process_time()
            if elapsed+cfg['per_trajectory_cpu_limit']+cfg['return_reserve_cpu']>cfg['process_cpu_soft_gate']:
                result={**common,'status':'not_run_global_cpu_gate','cpu_at_skip':elapsed,'missing_budgets':cfg['checkpoints']}
            elif time.perf_counter()-start_wall+cfg['per_trajectory_wall_limit']>cfg['execution_wall_limit']:
                result={**common,'status':'not_run_global_wall_gate','missing_budgets':cfg['checkpoints']}
            else:
                try:
                    instance=from_dict(read(ROOT/call['input_file']))
                    result={**common,**trajectory(instance,call['pair'],call['search_seed'],cfg),'status':'executed'}
                except Exception as e:
                    result={**common,'status':'runner_failure','error':{'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()},'missing_budgets':cfg['checkpoints']}
            result['finished_utc']=utc()
            f.write(json.dumps(result,ensure_ascii=False,allow_nan=False)+'\n');f.flush();done+=1
            if result['status']!='executed' or result.get('error') or result.get('missing_budgets') or any(not c['scoreable'] for c in result.get('checkpoints',[])):
                failures.append({'run_id':call['run_id'],'status':result['status'],'error':result.get('error'),'missing_budgets':result.get('missing_budgets',[])})
            if done%24==0: print(json.dumps({'completed':done,'process_cpu':time.process_time(),'wall':time.perf_counter()-start_wall}),flush=True)
    dump(ROOT/'failures/FAILURES.json',{'count':len(failures),'rows':failures,'retries':0})
    verify()
    dump(ROOT/'raw/COMPLETION.json',{'utc':utc(),'rows':done,'failure_count':len(failures),'formal_process_cpu_seconds':time.process_time()-formal_start_cpu,
      'process_cpu_seconds':time.process_time(),'execution_cpu_seconds':time.process_time()-start_cpu,'wall_seconds':time.perf_counter()-start_wall,
      'external_api_calls':0,'model_calls':0,'network_calls':0,'dependency_installations':0,'frozen_hashes_unchanged':True})

if __name__=='__main__': execute()
