#!/usr/bin/env python3
"""Independent read-only large-X audit. Standard library only, no solver execution.

Only original VRPLIB coordinates/demands/capacity enter the independent metric.
The metadata/catalog k and witness route count are descriptive, never constraints.
Fingerprint exclusions deliberately ignore capacity and vehicle metadata, matching
coordinate-demand bases even after translation or customer renumbering. This is
not a proof against arbitrary rotations, reflections, or geometric isomorphism.
"""
from __future__ import annotations
import argparse
from collections import Counter, defaultdict
from decimal import Decimal
import hashlib
import json
import math
from pathlib import Path
import re
from audit_inputs import parse_vrp, decimal_matrix
from independent_validator import validate_solution


def sha(data):
    return hashlib.sha256(data).hexdigest()


def packed(value):
    return json.dumps(value, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode()


def canonical_decimal(value):
    value = Decimal(value)
    if not value.is_finite():
        raise ValueError('non-finite fingerprint input')
    # Formatting rather than Decimal.normalize avoids context-dependent rounding.
    text = format(value, 'f')
    if '.' in text:
        text = text.rstrip('0').rstrip('.')
    return '0' if value == 0 else text


def fingerprints(problem):
    xy, demands = problem['coordinates'], problem['demands']
    ordered = [[canonical_decimal(x), canonical_decimal(y)] for x, y in xy]
    dx, dy = xy[0]
    relative = sorted([[canonical_decimal(x-dx), canonical_decimal(y-dy), int(d)]
                       for (x, y), d in zip(xy[1:], demands[1:])])
    return {'ordered_exact': sha(packed([ordered, demands])),
            'translation_and_renumbering_invariant': sha(packed(relative))}


def parse_original(text, expected_name=None):
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    if not lines or lines[-1] != 'EOF' or lines.count('EOF') != 1:
        raise ValueError('requires exactly one terminal EOF')
    headers = {}
    for line in lines:
        if line == 'NODE_COORD_SECTION':
            break
        if ':' not in line:
            raise ValueError('unexpected pre-coordinate line')
        key, value = (part.strip() for part in line.split(':', 1))
        if key not in {'NAME','COMMENT','TYPE','DIMENSION','EDGE_WEIGHT_TYPE','CAPACITY'}:
            raise ValueError('unsupported header: '+key)
        if key != 'COMMENT':
            if key in headers:
                raise ValueError('duplicate header: '+key)
            headers[key] = value
    n = int(headers['DIMENSION'])
    if n < 2:
        raise ValueError('requires at least one customer')
    problem = parse_vrp(text, n-1)
    if expected_name is not None and problem['instance_id'] != expected_name:
        raise ValueError('original NAME differs from expected instance_id')
    if problem['original_node_ids'] != list(range(1,n+1)):
        raise ValueError('this audit requires original depot node 1')
    if any(d > problem['capacity'] for d in problem['demands']):
        raise ValueError('customer demand exceeds capacity')
    return problem


def parse_reference(text):
    routes, numbers, cost = [], [], None
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        match = re.fullmatch(r'Route\s+#([0-9]+):\s*(.*)', line)
        if match:
            if cost is not None:
                raise ValueError('route after cost')
            tokens = match[2].split()
            if not tokens or any(not re.fullmatch(r'[0-9]+', t) for t in tokens):
                raise ValueError('reference routes must contain nonempty integer customer lists')
            numbers.append(int(match[1]))
            routes.append([0]+[int(t) for t in tokens]+[0])
            continue
        match = re.fullmatch(r'Cost\s+([0-9]+(?:\.0+)?)', line)
        if match and cost is None:
            cost = int(Decimal(match[1]))
            continue
        raise ValueError('unknown or duplicate reference line')
    if not routes or numbers != list(range(1,len(routes)+1)) or cost is None:
        raise ValueError('missing/sequenced routes or cost')
    return routes, cost


def audit(root):
    root = Path(root)
    read = lambda rel: json.loads((root/rel).read_text(), parse_float=Decimal)
    errors, checks = [], {}
    selected, metadata, rule = (read('freeze/'+p) for p in ['SELECTED_PANEL.json','CATALOG_METADATA.json','SELECTION_RULE.json'])
    historical, schedule = (read('freeze/'+p) for p in ['HISTORICAL_INPUTS.json','SCHEDULE.json'])
    catalog = read('freeze/CATALOG_FREEZE.json')
    expected = []
    for band, (lo,hi) in enumerate(rule['bands'], 1):
        eligible = sorted([x for x in metadata if lo <= x['n_customers'] <= hi],
                          key=lambda x:(x['n_customers'], x['instance_id']))[:rule['per_band']]
        expected += [(x['instance_id'], x['n_customers'], band) for x in eligible]
    observed = [(x['instance_id'],x['n_customers'],x['band']) for x in selected]
    checks['catalog_metadata_digest'] = sha((root/'freeze/CATALOG_METADATA.json').read_bytes()) == rule['source_pool_sha256'] == catalog['metadata_sha256']
    checks['catalog_freeze_digest'] = sha((root/'freeze/CATALOG_FREEZE.json').read_bytes()) == rule['catalog_frozen_first_sha256']
    checks['catalog_snapshot_digest'] = sha((root/'evidence/cvrplib_catalog_20261008.html').read_bytes()) == catalog['snapshot_sha256']
    checks['selector_independently_reproduced'] = observed == expected
    checks['12_sequential_unique_slots'] = len(selected) == 12 and len({x['instance_id'] for x in selected}) == 12 and [x['selection_slot'] for x in selected] == list(range(1,13))
    checks['selection_uses_only_name_and_customer_count'] = rule['selection_uses'] == ['instance_id','n_customers'] and rule['ranking'] == ['n_customers ascending','instance_id ascending']
    checks['selection_no_replacements'] = rule['no_replacements'] is True
    checks['solver_K_is_customer_count'] = all(x['K'] == x['n_customers'] for x in selected)
    expected_schedule = [(x['selection_slot'],x['instance_id'],seed) for x in selected for seed in [0,1,2]]
    checks['36_unique_sequential_calls'] = len(schedule) == 36 and len({x['call_id'] for x in schedule}) == 36 and [(x['selection_slot'],x['instance_id'],x['seed']) for x in schedule] == expected_schedule
    checks['all_calls_1_second'] = all(x['max_runtime_seconds'] == 1 for x in schedule)
    checks['41_unique_historical_inputs'] = len(historical) == 41 and len({x['instance_id'] for x in historical}) == 41
    checks['historical_groups_25_plus_16'] = Counter(x['group'] for x in historical) == {'historical25':25,'transfer16':16}
    started = read('provenance/ACQUISITION_STARTED.json')
    checks['selection_committed_before_download'] = started['selection_sha256'] == sha((root/'freeze/SELECTED_PANEL.json').read_bytes())
    checks['retrieval_plan_committed'] = started['plan_sha256'] == sha((root/'freeze/RETRIEVAL_PLAN.json').read_bytes())
    tasks = read('freeze/TASKS.json')
    checks['task_slots_match_selection'] = [(x['selection_slot'],x['instance_id'],x['K']) for x in tasks] == [(x['selection_slot'],x['instance_id'],x['n_customers']) for x in selected]
    acquisition = [json.loads(line) for line in (root/'provenance/ACQUISITION.jsonl').read_text().splitlines() if line.strip()]
    acquired = {x['path']:x for x in acquisition if x.get('success')}
    checks['24_unique_one_shot_acquisitions'] = len(acquisition) == 24 and len(acquired) == 24 and len({x['path'] for x in acquisition}) == 24 and all(x['attempt']==1 for x in acquisition)
    history_rows, index = [], defaultdict(list)
    for h in historical:
        row = {'instance_id':h['instance_id'], 'group':h['group'], 'errors':[]}
        try:
            raw = (root/h['local']).read_bytes()
            p = parse_original(raw.decode('utf-8-sig'),h['instance_id'])
            hashes = fingerprints(p)
            row.update(raw_sha256=sha(raw),fingerprints=hashes,n_customers=len(p['demands'])-1,capacity=p['capacity'])
            if sha(raw) != h['sha256']:
                row['errors'].append('copied historical raw hash mismatch')
            origin = Path(h['origin'])
            row['original_byte_identity_checked'] = origin.exists()
            if not origin.exists() or origin.read_bytes() != raw:
                row['errors'].append('historical origin unavailable or nonidentical')
            for kind,value in hashes.items():
                index[(kind,value)].append(h['instance_id'])
        except Exception as exc:
            row['errors'].append(type(exc).__name__+': '+str(exc))
        row['valid'] = not row['errors']; history_rows.append(row)
    checks['all_41_historical_inputs_valid'] = all(x['valid'] for x in history_rows)
    historical_clusters = [names for (kind,value),names in index.items() if kind == 'translation_and_renumbering_invariant']
    historical_unique_bases = len(historical_clusters)
    tasks_by_id = {t['instance_id']:t for t in tasks}
    panel_rows, seen, reference_rows = [], defaultdict(list), []
    for selected_row in selected:
        name = selected_row['instance_id']
        row = {'instance_id':name,'selection_slot':selected_row['selection_slot'],'errors':[],'checks':{}}
        rc = row['checks']
        try:
            vrp_path, json_path = 'input/'+name+'.vrp','input/'+name+'.json'
            raw = (root/vrp_path).read_bytes()
            p = parse_original(raw.decode('utf-8-sig'),name)
            normalized = read(json_path)
            normxy = [[Decimal(str(x)),Decimal(str(y))] for x,y in normalized['coordinates']]
            actual_n = len(p['demands'])-1
            rc['dimension'] = actual_n == selected_row['n_customers'] == len(normalized['demands'])-1
            rc['normalized_name'] = normalized['instance_id'] == name
            rc['original_coordinates_preserved'] = p['coordinates'] == normxy
            rc['original_demands_preserved'] = p['demands'] == normalized['demands']
            rc['original_capacity_preserved'] = p['capacity'] == normalized['capacity'] == selected_row['capacity']
            rc['solver_K_is_customer_count'] = normalized['K'] == p['K'] == actual_n
            rc['raw_bytes_match_acquisition'] = sha(raw) == acquired[vrp_path]['sha256']
            forbidden = {'routes','reference_routes','reference_integer_cost','reference_cost','cost','K_ref'}
            rc['normalized_input_no_reference_keys'] = not (set(normalized) & forbidden)
            rc['normalized_schema_exact'] = set(normalized) == {'instance_id','coordinates','demands','capacity','K'}
            frozen_task = tasks_by_id[name]
            rc['task_normalized_sha256'] = frozen_task['normalized_sha256'] == sha((root/json_path).read_bytes())
            rc['task_raw_instance_sha256'] = frozen_task['source_instance_sha256'] == sha(raw)
            rc['task_K_solver'] = frozen_task['K_solver'] == actual_n
            matrix = decimal_matrix(p['coordinates'])
            json_matrix = decimal_matrix(normxy)
            mismatches, float_mismatches = [], []
            for i,a in enumerate(normxy):
                for j,b in enumerate(normxy):
                    if matrix[i][j] != json_matrix[i][j]:
                        mismatches.append([i,j])
                    intended = math.floor(math.hypot(float(a[0])-float(b[0]),float(a[1])-float(b[1]))+0.5)
                    if matrix[i][j] != intended:
                        float_mismatches.append([i,j])
            rc['all_cell_original_vs_normalized_decimal'] = not mismatches
            rc['all_cell_decimal_vs_adapter_intended_float'] = not float_mismatches
            rc['matrix_symmetric'] = all(matrix[i][j] == matrix[j][i] for i in range(actual_n+1) for j in range(i))
            rc['matrix_diagonal_zero'] = all(matrix[i][i] == 0 for i in range(actual_n+1))
            hashes = fingerprints(p)
            historic_hits = sorted({n for k,v in hashes.items() for n in index.get((k,v),[])})
            panel_hits = sorted({n for k,v in hashes.items() for n in seen.get((k,v),[])})
            for k,v in hashes.items():
                seen[(k,v)].append(name)
            rc['task_fingerprints_match'] = frozen_task['fingerprints'] == hashes
            rc['task_historical_hits_match'] = frozen_task['historical_duplicate_names'] == historic_hits
            rc['task_panel_hits_match'] = frozen_task['earlier_duplicate_names'] == panel_hits
            rc['no_historical_coordinate_demand_base_overlap'] = not historic_hits
            rc['no_earlier_selected_coordinate_demand_base_overlap'] = not panel_hits
            row.update(n=actual_n+1,n_customers=actual_n,directed_cells=(actual_n+1)**2,vrp_sha256=sha(raw),json_sha256=sha((root/json_path).read_bytes()),matrix_sha256=sha(packed(matrix)),matrix_sha256_encoding="JSON array of rows, separators=(',',':'), UTF-8, no newline",fingerprints=hashes,historical_duplicate_names=historic_hits,earlier_panel_duplicate_names=panel_hits,decimal_mismatch_cells=mismatches,float_mismatch_cells=float_mismatches)
            ref_path = 'references/'+name+'.sol'
            refbytes = (root/ref_path).read_bytes()
            routes, reported = parse_reference(refbytes.decode('utf-8-sig'))
            validation = validate_solution(p,routes,reported)
            rc['reference_raw_bytes_match_acquisition'] = sha(refbytes) == acquired[ref_path]['sha256']
            rc['independent_reference_valid'] = validation['valid'] and validation['reported_cost_checked'] and validation['reported_cost_matches']
            normalized_ref = read('references/'+name+'.json')
            rc['task_reference_sha256'] = frozen_task['source_reference_sha256'] == sha(refbytes)
            rc['task_reference_route_count_audit_only'] = frozen_task['K_reference_audit_only'] == len(routes)
            rc['normalized_reference_routes'] = normalized_ref['reference_routes'] == [r[1:-1] for r in routes]
            rc['normalized_reference_cost'] = normalized_ref['reference_integer_cost'] == reported
            rc['normalized_reference_loads'] = normalized_ref['loads'] == validation['loads']
            rc['normalized_reference_K_ref_audit_only'] = normalized_ref['K_ref'] == len(routes)
            rc['normalized_reference_K_solver'] = normalized_ref['K_solver'] == actual_n
            rc['normalized_reference_semantics'] = normalized_ref['instance_id'] == name and normalized_ref['standard_CVRP_no_fixed_vehicle_count'] is True and normalized_ref['not_available_to_solver'] is True
            reference_rows.append({'instance_id':name,'raw_sha256':sha(refbytes),'K_name_audit_only':selected_row['K_name_audit_only'],'K_catalog_audit_only':selected_row['K_catalog_audit_only'],'K_ref_audit_only':len(routes),'K_solver':actual_n,'reference_cost':reported,'validation':validation})
            independently_eligible = not historic_hits and not panel_hits and validation['valid'] and checks['all_41_historical_inputs_valid']
            rc['task_eligibility_match'] = frozen_task['eligible'] == independently_eligible and (not frozen_task['errors']) == independently_eligible
            row['errors'] += [label for label,ok in rc.items() if not ok]
        except Exception as exc:
            row['errors'].append(type(exc).__name__+': '+str(exc))
        row['valid'] = not row['errors']; panel_rows.append(row)
    errors += [label for label,ok in checks.items() if not ok]
    errors += ['historical audit failed: '+x['instance_id'] for x in history_rows if not x['valid']]
    errors += ['panel audit failed: '+x['instance_id'] for x in panel_rows if not x['valid']]
    return {'valid':not errors,'errors':errors,'checks':checks,'tasks':len(selected),'scheduled_calls':len(schedule),'total_directed_cells':sum(x.get('directed_cells',0) for x in panel_rows),'no_optimizer_executed':True,'no_external_packages_imported':True,'actual_PyVRP_data_matrix_checked':False,'model_matrix_caveat':'Parent separately verifies actual built-model matrices against these independent original-VRPLIB hashes without solving.','fingerprint_semantics':'ordered raw coordinates+demands; translation-and-renumbering invariant depot-relative customer coordinates+demands; capacity and K intentionally excluded; rotation/reflection/general isomorphism not claimed','historical_unique_coordinate_demand_bases':historical_unique_bases,'historical_overlap_clusters':[names for names in historical_clusters if len(names)>1],'historical_inputs':history_rows,'references':reference_rows,'rows':panel_rows}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1])
    ap.add_argument('--output',type=Path)
    args = ap.parse_args()
    result = audit(args.root)
    text = json.dumps(result,indent=2,sort_keys=True,allow_nan=False)+'\n'
    if args.output:
        with args.output.open('x') as handle:
            handle.write(text)
    else:
        print(text,end='')
    return 0 if result['valid'] else 1

if __name__ == '__main__':
    raise SystemExit(main())
