#!/usr/bin/env python3
"""Independent saved-artifact audit. No optimizer imports or optimization calls.

Original .vrp and .sol files are independently parsed. Only saved route edges
are rescored with Decimal80 HALF_UP; the full matrix is not recomputed. Source
and readback ZIP hashes are verified locally; cloud owner-only status is bound
to the returned receipts, not freshly queried by this script.
"""
from pathlib import Path
from collections import Counter,defaultdict
from datetime import datetime,timezone
from fractions import Fraction
import argparse,csv,hashlib,io,json,math,zipfile
from audit_large_x_inputs import parse_original,parse_reference
from independent_validator import validate_solution


def sha(value):return hashlib.sha256(value).hexdigest()
def filehash(p):return sha(p.read_bytes())
def utc(t):return datetime.fromisoformat(t.replace('Z','+00:00'))
def near(a,b):return math.isclose(float(a),float(b),rel_tol=1e-12,abs_tol=1e-9)
def fraction_record(v):return {'numerator':v.numerator,'denominator':v.denominator,'float':float(v)}


def audit(root):
    root=Path(root)
    read=lambda rel:json.loads((root/rel).read_text())
    lines=lambda rel:[json.loads(line) for line in (root/rel).read_text().splitlines() if line.strip()]
    csvread=lambda rel:list(csv.DictReader(io.StringIO((root/rel).read_text())))
    checks={}
    def check(ok,label):checks[label]=bool(ok)
    frozen=read('freeze/FROZEN_FILES.json'); frozenhash=filehash(root/'freeze/FROZEN_FILES.json')
    for rel,m in frozen['files'].items():check((root/rel).stat().st_size==m['bytes'] and filehash(root/rel)==m['sha256'],'frozen:'+rel)
    precheck=read('freeze/INDEPENDENT_PRECHECK.json')
    check(precheck['status']=='PASS','precheck_PASS')
    for rel,m in precheck['signed_files'].items():check((root/rel).stat().st_size==m['bytes'] and filehash(root/rel)==m['sha256'],'presigned:'+rel)
    archive_audits=[]
    for stage in ['PREEXEC','RAW_UNREVIEWED']:
        receipt=read('provenance/'+stage+'_DRIVE_RECEIPT.json')
        source=Path(receipt['source']);download=Path(receipt['download_path']);a,b=source.read_bytes(),download.read_bytes()
        check(a==b and len(a)==receipt['bytes'] and sha(a)==receipt['sha256']==receipt['download_sha256'],'archive_actual_bytes:'+stage)
        check(receipt['verified'] and receipt['owner_only'] and receipt['shared'] is False and receipt['download_byte_identical'] and receipt['remote_readback_sha256_verified'],'receipt_permissions_and_readback:'+stage)
        check(receipt['frozen_files_sha256']==frozenhash,'receipt_frozen_binding:'+stage)
        with zipfile.ZipFile(io.BytesIO(b)) as z:
            names=z.namelist();check(len(names)==len(set(names)),'zip_no_duplicate_members:'+stage)
            prefix=root.name+'/'
            check(z.read(prefix+'freeze/FROZEN_FILES.json')==(root/'freeze/FROZEN_FILES.json').read_bytes(),'zip_freeze_manifest:'+stage)
            for rel,m in frozen['files'].items():check(len(z.read(prefix+rel))==m['bytes'] and sha(z.read(prefix+rel))==m['sha256'],'zip_frozen:'+stage+':'+rel)
            if stage=='PREEXEC':check(not any(p.startswith(prefix+'raw/') for p in names),'PREEXEC_contains_no_raw')
            else:
                check(z.read(prefix+'raw/RAW_UNREVIEWED_MANIFEST.json')==(root/'raw/RAW_UNREVIEWED_MANIFEST.json').read_bytes(),'RAW_archive_manifest')
                for rel,m in read('raw/RAW_UNREVIEWED_MANIFEST.json')['files'].items():check(z.read(prefix+rel)==(root/rel).read_bytes(),'RAW_archive_member:'+rel)
        archive_audits.append({'stage':stage,'sha256':sha(a),'bytes':len(a),'drive_id':receipt['drive_id'],'confirmed_at_utc':receipt['confirmed_at_utc'],'byte_identical_source_and_download':a==b,'owner_only_from_receipt':receipt['owner_only']})
    old_count=0
    for old in read('freeze/OLD_FILES_BEFORE.json')['roots']:
        oldroot=Path(old['root']);actual={str(p.relative_to(oldroot)) for p in oldroot.rglob('*') if p.is_file()}
        check(actual==set(old['files']),'old_file_set:'+str(oldroot))
        for rel,m in old['files'].items():
            p=oldroot/rel;check(p.stat().st_size==m['bytes'] and filehash(p)==m['sha256'],'old_hash:'+str(oldroot/rel));old_count+=1
    check(old_count==796,'old_796_files')
    raw_manifest=read('raw/RAW_UNREVIEWED_MANIFEST.json')
    for rel,m in raw_manifest['files'].items():check(filehash(root/rel)==m['sha256'] and (root/rel).stat().st_size==m['bytes'],'raw_manifest:'+rel)
    actualraw={str(p.relative_to(root)) for p in (root/'raw').rglob('*') if p.is_file()}
    check(actualraw==set(raw_manifest['files'])|{'raw/RAW_UNREVIEWED_MANIFEST.json'},'raw_exact_file_set')
    approval=read('provenance/PARENT_EXECUTION_APPROVAL.json');started=read('raw/STARTED.json');finished=read('raw/FINISHED.json')
    outerstart=read('raw/EXECUTOR_STARTED.json');outerend=read('raw/EXECUTOR_FINISHED.json')
    pre_receipt=read('provenance/PREEXEC_DRIVE_RECEIPT.json');raw_receipt=read('provenance/RAW_UNREVIEWED_DRIVE_RECEIPT.json')
    check(approval['approved'] and approval['scope']=='one frozen36-call standard-X PyVRP benchmark; no retry' and approval['serialized_window_released'],'approval_scope')
    check(approval['frozen_files_sha256']==frozenhash==started['freeze_sha256']==finished['freeze_sha256_after'] and approval['preexec_archive_sha256']==pre_receipt['sha256'],'approval_hash_bindings')
    check(started['approval_sha256']==filehash(root/'provenance/PARENT_EXECUTION_APPROVAL.json') and started['preexec_receipt_sha256']==filehash(root/'provenance/PREEXEC_DRIVE_RECEIPT.json'),'STARTED_hash_bindings')
    summary=read('reports/SUMMARY.json')
    chronology=[pre_receipt['confirmed_at_utc'],approval['window_release_received_utc'],approval['utc'],outerstart['utc'],started['utc'],finished['utc'],outerend['utc'],raw_manifest['utc'],raw_receipt['confirmed_at_utc'],summary['utc']]
    check(all(utc(a)<=utc(b) for a,b in zip(chronology,chronology[1:])),'PREEXEC_window_approval_execution_RAW_readback_scoring_chronology')
    check(outerstart['no_retries'] and started['no_retries'] and outerend['supervisor_returncode']==0 and not outerend['external_timeout'] and outerend['launcher_error'] is None and outerend['process_group_kill_attempt_completed_before_seal'],'one_executor_clean_completion')
    check(finished['planned_calls']==finished['retained_calls']==finished['spawned_calls']==36,'supervisor36_complete')
    tasks=read('freeze/TASKS.json');schedule=read('freeze/SCHEDULE.json');results=lines('raw/results.jsonl');attempts=lines('raw/attempts.jsonl')
    check(len(tasks)==12 and len(schedule)==len(results)==36 and len(attempts)==72,'task_call_attempt_counts')
    check(len({r['call_id'] for r in results})==36 and [r['call_id'] for r in results]==[e['call_id'] for e in schedule],'exact_once_ordered36_result_records')
    check([(a['call_id'],a['phase']) for a in attempts]==[(e['call_id'],phase) for e in schedule for phase in ['STARTED','FINISHED']],'exact_once72_attempt_phases')
    for i,e in enumerate(schedule):
        check(all(results[i][k]==v for k,v in e.items()),'record_schedule:'+e['call_id'])
        check(all(attempts[2*i][k]==v for k,v in e.items()),'start_schedule:'+e['call_id'])
        check({k:v for k,v in attempts[2*i+1].items() if k not in ['phase','utc']}==results[i],'finished_record_identity:'+e['call_id'])
        check(utc(attempts[2*i]['utc'])<=utc(attempts[2*i+1]['utc']),'call_chronology:'+e['call_id'])
        if i:check(utc(attempts[2*i-1]['utc'])<=utc(attempts[2*i]['utc']),'no_call_time_overlap:'+e['call_id'])
    problems={};refs={};ref_checks=[];matrix={x['instance_id']:x['matrix_sha256'] for x in read('independent_review/INPUT_MATRIX_AUDIT.json')['rows']}
    for task in tasks:
        name=task['instance_id'];p=parse_original((root/'input'/f'{name}.vrp').read_text(),name);problems[name]=p
        n=len(p['demands'])-1
        check(task['eligible'] and task['K']==task['K_solver']==p['K']==n,'task_K_and_eligibility:'+name)
        routes,claimed=parse_reference((root/'references'/f'{name}.sol').read_text());v=validate_solution(p,routes,claimed)
        check(v['valid'] and v['reported_cost_matches'],'reference_original_validation:'+name)
        refs[name]=v
        ref_checks.append({'instance_id':name,'cost':v['cost'],'nonempty_routes':v['nonempty_routes'],'K_solver':p['K'],'validation':v})
    perseed=csvread('reports/PER_SEED.csv');pertask=csvread('reports/PER_INSTANCE.csv');saved=read('reports/SAVED_ROUTE_VALIDATION.json')
    check(len(perseed)==36 and [r['call_id'] for r in perseed]==[e['call_id'] for e in schedule],'PER_SEED36_order')
    check(len(pertask)==12 and [r['instance_id'] for r in pertask]==[t['instance_id'] for t in tasks],'PER_INSTANCE12_order')
    check(saved['optimizer_rerun'] is False and len(saved['calls'])==36 and len(saved['reference_validation'])==12,'saved_route_audit_counts')
    expected_limits={'inherited':{'AS_bytes':[512*1024**2,1536*1024**2],'CPU_seconds':[30,30]},'effective':{'AS_bytes':[1536*1024**2,1536*1024**2],'CPU_seconds':[10,10]}}
    check(started['supervisor_limits']==finished['supervisor_effective_limits']==expected_limits['inherited'],'supervisor_effective_limits')
    calls=[];costs=defaultdict(list);answers=[]
    for i,(e,rec) in enumerate(zip(schedule,results)):
        cid=e['call_id'];name=e['instance_id'];p=problems[name]
        check(rec['status']=='UNREVIEWED_PROCESS_SUCCESS' and rec['returncode']==0 and rec['process_spawned'] and rec['child_reaped'],'process_success:'+cid)
        for stream in ['stdout','stderr']:check(filehash(root/rec[stream])==rec[stream+'_sha256'],'saved_stream_hash:'+cid+':'+stream)
        normalized=read('input/'+name+'.json');payload={k:normalized[k] for k in ['coordinates','demands','capacity','K']};payload.update(seed=e['seed'],max_runtime_seconds=e['max_runtime_seconds'])
        check(sha(json.dumps(payload,separators=(',',':')).encode())==rec['payload_sha256'],'reference_free_payload_hash:'+cid)
        answer=json.loads((root/rec['stdout']).read_text());answers.append(answer)
        validation=validate_solution(p,answer['routes'],answer['reported_cost']);check(validation['valid'] and validation['reported_cost_matches'],'original_vrp_saved_route_validation:'+cid)
        check(answer['seed']==e['seed'] and answer['max_runtime_seconds']==1.0 and answer['version']=='0.14.0' and answer['algorithm']=='ILS' and answer['solver']=='PyVRP','solver_seed_version:'+cid)
        check(answer['solver_is_feasible'] and answer['solver_is_complete'] and answer['reported_distance']==answer['reported_cost']==answer['internal_route_cost']==validation['cost'] and answer['reported_duration_cost']==answer['reported_fixed_vehicle_cost']==0,'distance_only_cost:'+cid)
        check(answer['reported_num_routes']==validation['nonempty_routes']<=p['K'],'route_bound_redundant_n:'+cid)
        check(answer['model_matrix_sha256']==matrix[name],'model_matrix_original_hash:'+cid)
        check(answer['resource_limits']==expected_limits,'resource_inheritance:'+cid)
        check(not answer['denied_io_events'] and not answer['reference_or_history_payload_fields'],'reference_isolation:'+cid)
        check(0<rec['cpu_seconds_audit_only']<10 and 0<rec['wall_seconds_audit_only']<20 and 0<answer['worker_maxrss_KiB_audit_only']<1536*1024,'realized_resources_within_guards:'+cid)
        check(0<=answer['build_wall_seconds_audit_only']<=rec['wall_seconds_audit_only'] and 0<=answer['solve_wall_seconds_audit_only']<=rec['wall_seconds_audit_only'] and 0<=answer['build_cpu_seconds_audit_only']+answer['solve_cpu_seconds_audit_only']<=rec['cpu_seconds_audit_only']+1e-8,'time_fields_consistent:'+cid)
        native_good=len(answer['native_routes'])==len(answer['routes'])
        for j,(route,native) in enumerate(zip(answer['routes'],answer['native_routes'])):
            native_good &= native['distance']==validation['route_costs'][j] and native['delivery']==[validation['loads'][j]] and native['vehicle_type']==0 and native['start_depot']==native['end_depot']==0 and native['num_trips']==1 and native['is_feasible']
            native_good &= [x['node'] for x in native['activities']]==route
            for pos,a in enumerate(native['activities']):
                native_good &= a['node']==a['location']
                native_good &= ((a['type']=='DEPOT' and a['idx']==a['node']==0) if pos in [0,len(native['activities'])-1] else (a['type']=='CLIENT' and a['idx']+1==a['node']))
        check(native_good,'native_location_client_mapping_and_route_data:'+cid)
        check(saved['calls'][i]['call_id']==cid and saved['calls'][i]['valid'] and not saved['calls'][i]['errors'] and saved['calls'][i]['validation']==validation,'existing_saved_validation_match:'+cid)
        row=perseed[i]
        for field,value in [('selection_slot',e['selection_slot']),('seed',e['seed']),('cost',validation['cost']),('nonempty_routes',validation['nonempty_routes']),('iterations',answer['num_iterations']),('worker_maxrss_KiB_audit_only',answer['worker_maxrss_KiB_audit_only'])]:check(int(row[field])==value,'PER_SEED:'+cid+':'+field)
        check(row['instance_id']==name and row['status']=='VALID' and row['failure']=='','PER_SEED:'+cid+':status')
        for field,value in [('max_runtime_seconds',1.0),('search_runtime_audit_only',answer['solver_loop_runtime']),('process_wall_audit_only',rec['wall_seconds_audit_only']),('process_cpu_audit_only',rec['cpu_seconds_audit_only']),('build_wall_audit_only',answer['build_wall_seconds_audit_only']),('solve_wall_audit_only',answer['solve_wall_seconds_audit_only'])]:check(near(row[field],value),'PER_SEED:'+cid+':'+field)
        costs[name].append(validation['cost'])
        calls.append({'call_id':cid,'instance_id':name,'seed':e['seed'],'validation':validation,'native_valid':native_good,'cpu_seconds':rec['cpu_seconds_audit_only'],'wall_seconds':rec['wall_seconds_audit_only'],'maxrss_KiB':answer['worker_maxrss_KiB_audit_only'],'model_matrix_sha256':answer['model_matrix_sha256']})
    instance_stats=[];allgaps=[];bands=defaultdict(list)
    for i,t in enumerate(tasks):
        name=t['instance_id'];values=costs[name];reference=refs[name]['cost'];mean=Fraction(sum(values),3);gap=100*(mean-reference)/reference;sd=math.sqrt(sum((Fraction(v)-mean)**2 for v in values)/2)
        row=pertask[i];allgaps.append(gap);bands[t['band']].append(gap)
        expected={'selection_slot':t['selection_slot'],'band':t['band'],'n_customers':t['n_customers'],'K_solver':t['K'],'K_name_audit_only':t['K_name_audit_only'],'K_catalog_audit_only':t['K_catalog_audit_only'],'reference_nonempty_routes_audit_only':refs[name]['nonempty_routes'],'reference_cost':reference,'valid_seed_count':3,'planned_seed_count':3,'seed0_cost':values[0],'seed1_cost':values[1],'seed2_cost':values[2],'mean3_cost':mean,'mean3_reference_gap_percent':gap,'best_of3_cost_secondary':min(values),'worst_of3_cost_secondary':max(values),'range3_cost_secondary':max(values)-min(values),'sample_SD3_cost_secondary':sd}
        for key,value in expected.items():check(near(row[key],value),'PER_INSTANCE:'+name+':'+key)
        check(row['complete_three_seed']=='True','PER_INSTANCE:'+name+':complete')
        check(saved['reference_validation'][i]['instance_id']==name and saved['reference_validation'][i]['reference']==refs[name] and saved['reference_validation'][i]['no_optimality_proof_established_here'],'saved_reference_match:'+name)
        instance_stats.append({'instance_id':name,'band':t['band'],'costs_seed0_1_2':values,'reference_cost':reference,'mean3_cost':fraction_record(mean),'mean3_reference_gap_percent':fraction_record(gap),'best3':min(values),'worst3':max(values),'range3':max(values)-min(values),'sampleSD3':sd})
    allmean=sum(allgaps)/12;bandstats=[]
    for band in range(1,5):
        mean=sum(bands[band])/3;row=summary['descriptive_bands'][band-1]
        check(row['band']==band and row['planned_tasks']==row['complete_tasks']==3 and row['customer_interval']==read('freeze/SELECTION_RULE.json')['bands'][band-1] and near(row['three_task_mean_gap_percent'],mean) and near(row['available_complete_mean_gap_percent'],mean),'SUMMARY_band:'+str(band))
        bandstats.append({'band':band,'gap_percent':fraction_record(mean)})
    check(near(summary['all12_mean_reference_gap_percent'],allmean) and near(summary['descriptive_available_complete_mean_gap_percent'],allmean),'SUMMARY_primary_exact_fraction')
    check(summary['planned_instances']==summary['complete_three_seed_tasks']==summary['descriptive_complete_task_denominator']==12 and summary['planned_calls']==summary['observed_scheduled_rows']==summary['spawned_calls']==summary['valid_calls']==36 and summary['failed_or_unavailable_seed_slots']==0,'SUMMARY_denominators')
    check(summary['old_files_verified_unchanged']==finished['old_files_verified_unchanged']==old_count,'SUMMARY_old_count')
    check(not summary['strict_blind'] and not summary['preregistered_confirmatory'] and not summary['old_TSR_comparator_available'] and summary['cross_panel_difference_cannot_be_attributed_only_to_size'] and summary['no_equal_compute_or_speed_claim'] and summary['no_optimality_proof_claim'],'SUMMARY_claim_limits')
    report=(root/'reports/REPORT_ZH.txt').read_text()
    check(f'{float(allmean):.9f}%' in report,'REPORT_primary_value')
    check(all(str(float(x['gap_percent']['float']))+'%' in report for x in bandstats),'REPORT_band_values')
    check(all(s in report for s in ['有效输出36/36','三seed齐全12/12','不固定路线数','不能单独归因规模','没有TSR同任务结果','未在本研究重建最优性证明','非严格盲测','失败不删除、不换题、不加预算重跑']),'REPORT_counts_and_limits')
    resource_stats={
      'child_CPU_sum_seconds':sum(x['cpu_seconds_audit_only'] for x in results),
      'child_CPU_min_seconds':min(x['cpu_seconds_audit_only'] for x in results),
      'child_CPU_max_seconds':max(x['cpu_seconds_audit_only'] for x in results),
      'child_process_wall_sum_seconds':sum(x['wall_seconds_audit_only'] for x in results),
      'child_process_wall_min_seconds':min(x['wall_seconds_audit_only'] for x in results),
      'child_process_wall_max_seconds':max(x['wall_seconds_audit_only'] for x in results),
      'worker_peak_maxrss_KiB':max(x['worker_maxrss_KiB_audit_only'] for x in answers),
      'supervisor_CPU_seconds':finished['supervisor_cpu_seconds_audit_only'],
      'supervisor_wall_seconds':finished['wall_seconds_audit_only'],
      'supervisor_maxrss_KiB':finished['supervisor_maxrss_KiB_audit_only'],
      'outer_wall_seconds':outerend['wall_seconds_audit_only'],
      'solver_loop_runtime_min_seconds':min(x['solver_loop_runtime'] for x in answers),
      'solver_loop_runtime_max_seconds':max(x['solver_loop_runtime'] for x in answers),
      'scope':'Recorded process and loop diagnostics only. Child CPU plus supervisor CPU exclude outer launcher, acquisition, tests, packaging, upload, scoring and independent review. maxRSS high-water figures are not summed concurrent memory and AS bounds are not RSS.'}
    check(resource_stats['child_process_wall_sum_seconds']<=resource_stats['supervisor_wall_seconds']<=resource_stats['outer_wall_seconds'],'wall_hierarchy')
    check(0<resource_stats['supervisor_CPU_seconds']<30 and resource_stats['supervisor_wall_seconds']<900 and resource_stats['outer_wall_seconds']<960,'supervisor_outer_limits')
    reportfiles={str(p.relative_to(root)):{'bytes':p.stat().st_size,'sha256':filehash(p)} for p in sorted((root/'reports').glob('*')) if p.is_file()}
    return {'utc':datetime.now(timezone.utc).isoformat(),'status':'PASS' if all(checks.values()) else 'FAIL','errors':[k for k,v in checks.items() if not v],'checks_passed':sum(checks.values()),'checks_total':len(checks),'checks':checks,'no_optimizer_called':True,'no_full_matrix_recomputed':True,'original_vrp_saved_edges_rescored_Decimal80':True,'independent_primary_gap_percent':fraction_record(allmean),'independent_bands':bandstats,'instances':instance_stats,'calls':calls,'references':ref_checks,'resource_diagnostics':resource_stats,'archive_audits':archive_audits,'old_files_hash_verified':old_count,'frozen_manifest_sha256':frozenhash,'raw_manifest_sha256':filehash(root/'raw/RAW_UNREVIEWED_MANIFEST.json'),'reviewed_report_files':reportfiles,'limitations':['This panel uses standard X CVRP; previous at-most-K_ref panel has different semantics, so cross-panel changes are not solely attributable to size.','No TSR output exists for these12 tasks; this audit makes no TSR comparison, general CVRP/SOTA superiority or optimality claim.','Results are descriptive for12 deterministically selected instances and three fixed seeds, neither strictly blind nor confirmatory; no inferential significance claimed.','The1s timer excludes model construction and initialization, and may overshoot to a stopping callback. No equal-compute or speed comparison is justified.','Audit verifies retained evidence and logged single attempts; it does not forensically prove no unlogged activity elsewhere.','Cloud private ownership is recorded in verified connector receipts; this script independently verifies source/download bytes and ZIP members, not a fresh remote ACL lookup.','Exact dependencies require the separate existing private wheel archive.','The REPORT_ZH.txt ending awaiting independent review is historical staging text from the frozen report generator; this postrun audit supplies the completed independent review without editing that report.']}


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);ap.add_argument('--output',type=Path);args=ap.parse_args()
    result=audit(args.root);text=json.dumps(result,indent=2,ensure_ascii=False,allow_nan=False)+'\n'
    if args.output:
        with args.output.open('x') as f:f.write(text)
    else:print(text,end='')
    print(json.dumps({k:result[k] for k in ['status','errors','checks_passed','checks_total','independent_primary_gap_percent','resource_diagnostics']},ensure_ascii=False,indent=2))
    return 0 if result['status']=='PASS' else 1
if __name__=='__main__':raise SystemExit(main())
