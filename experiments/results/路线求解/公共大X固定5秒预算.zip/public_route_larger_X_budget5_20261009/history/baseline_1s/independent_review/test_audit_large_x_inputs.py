#!/usr/bin/env python3
"""Fictional-data tests only. No public optimization or PyVRP import."""
import copy
from decimal import Decimal
import unittest
from audit_large_x_inputs import parse_original, parse_reference, fingerprints, canonical_decimal
from independent_validator import validate_solution

SAMPLE = '''NAME : fictional-n4-k1
COMMENT : do not use any objective metadata
TYPE : CVRP
DIMENSION : 4
EDGE_WEIGHT_TYPE : EUC_2D
CAPACITY : 2
NODE_COORD_SECTION
1 0 0
2 1 0
3 0 1
4 1 1
DEMAND_SECTION
1 0
2 1
3 1
4 1
DEPOT_SECTION
1
-1
EOF
'''

class IndependentLargeXTests(unittest.TestCase):
    def test_K_ignores_filename(self):
        p = parse_original(SAMPLE)
        self.assertEqual(p['K'],3)
        result = validate_solution(p,[[0,1,0],[0,2,0],[0,3,0]],6)
        self.assertTrue(result['valid'])
    def test_half_up_edge_not_bankers(self):
        p = parse_original(SAMPLE.replace('2 1 0','2 0.5 0'))
        result = validate_solution(p,[[0,1,0],[0,2,0],[0,3,0]],6)
        self.assertTrue(result['valid'])
    def test_decimal_canonical(self):
        self.assertEqual(canonical_decimal(Decimal('-0.000')),'0')
        self.assertEqual(canonical_decimal(Decimal('1.2000')),'1.2')
        self.assertEqual(canonical_decimal(Decimal('123456789012345678901234567890.001')),'123456789012345678901234567890.001')
    def test_missing_eof_rejected(self):
        with self.assertRaises(ValueError): parse_original(SAMPLE.replace('EOF',''))
    def test_duplicate_eof_rejected(self):
        with self.assertRaises(ValueError): parse_original(SAMPLE+'EOF\n')
    def test_trailing_content_rejected(self):
        with self.assertRaises(ValueError): parse_original(SAMPLE+'junk\n')
    def test_duplicate_header_rejected(self):
        with self.assertRaises(ValueError): parse_original(SAMPLE.replace('TYPE : CVRP','TYPE : CVRP\nTYPE : CVRP'))
    def test_duration_extension_rejected(self):
        with self.assertRaises(ValueError): parse_original(SAMPLE.replace('TYPE : CVRP','TYPE : CVRP\nDISTANCE : 5'))
    def test_wrong_name_rejected(self):
        with self.assertRaises(ValueError): parse_original(SAMPLE,'other-name')
    def test_nonfinite_coordinate_rejected(self):
        with self.assertRaises(ValueError): parse_original(SAMPLE.replace('2 1 0','2 NaN 0'))
    def test_overcapacity_demand_rejected(self):
        with self.assertRaises(ValueError): parse_original(SAMPLE.replace('2 1\n','2 3\n'))
    def test_duplicate_coord_rejected(self):
        with self.assertRaises(ValueError): parse_original(SAMPLE.replace('3 0 1','2 0 1'))
    def test_second_depot_rejected(self):
        with self.assertRaises(ValueError): parse_original(SAMPLE.replace('1\n-1','1\n2\n-1'))
    def test_reference_parse_and_validation(self):
        p = parse_original(SAMPLE)
        r,c = parse_reference('Route #1: 1 2\nRoute #2: 3\nCost 5.0\n')
        self.assertTrue(validate_solution(p,r,c)['valid'])
    def test_reference_wrong_cost_detected(self):
        p = parse_original(SAMPLE)
        r,c = parse_reference('Route #1: 1 2\nRoute #2: 3\nCost 6\n')
        self.assertFalse(validate_solution(p,r,c)['valid'])
    def test_reference_duplicate_customer_detected(self):
        p = parse_original(SAMPLE)
        r,c = parse_reference('Route #1: 1 2\nRoute #2: 2 3\nCost 6\n')
        self.assertFalse(validate_solution(p,r,c)['valid'])
    def test_reference_internal_depot_detected(self):
        p = parse_original(SAMPLE)
        r,c = parse_reference('Route #1: 1 0 2\nRoute #2: 3\nCost 6\n')
        self.assertFalse(validate_solution(p,r,c)['valid'])
    def test_reference_out_of_range_detected(self):
        p = parse_original(SAMPLE)
        r,c = parse_reference('Route #1: 1 2\nRoute #2: 4\nCost 6\n')
        self.assertFalse(validate_solution(p,r,c)['valid'])
    def test_reference_fails_closed(self):
        invalid = ['Route #2: 1 2 3\nCost 4','Route #1: \nCost 0',
                   'Route #1: 1\nCost 2\nCost 2','Route #1: 1\nCost 2\nRoute #2: 2 3',
                   'Route #1: 1.0\nCost 2','Route #1: 1\nCost 2.5',
                   'Route #1: 1\nCost NaN','Route #1: 1\nCost 2\nJunk',
                   'Route #1: -1\nCost 2','Route #1: 1']
        for text in invalid:
            with self.subTest(text=text):
                with self.assertRaises(ValueError): parse_reference(text)
    def test_fingerprint_ignores_capacity_and_K(self):
        p = parse_original(SAMPLE); other=copy.deepcopy(p)
        other['capacity']=100;other['K']=1
        self.assertEqual(fingerprints(p), fingerprints(other))
    def test_fingerprint_translation_and_renumbering(self):
        p = parse_original(SAMPLE);other=copy.deepcopy(p)
        order=[0,3,1,2]
        other['coordinates']=[[p['coordinates'][i][0]+10,p['coordinates'][i][1]-8] for i in order]
        other['demands']=[p['demands'][i] for i in order]
        f,g=fingerprints(p),fingerprints(other)
        self.assertNotEqual(f['ordered_exact'],g['ordered_exact'])
        self.assertEqual(f['translation_and_renumbering_invariant'],g['translation_and_renumbering_invariant'])
    def test_fingerprint_demand_change_detected(self):
        p = parse_original(SAMPLE);other=copy.deepcopy(p);other['demands'][1]=2
        for key,value in fingerprints(p).items(): self.assertNotEqual(value,fingerprints(other)[key])

if __name__=='__main__':unittest.main(verbosity=2)
