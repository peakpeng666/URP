标准X大实例短预算质量研究，2026-10-09 UTC

状态：准备中，尚未进行公共优化。
12题预定客户数100–523，四带各3题，每题seed0/1/2、MaxRuntime1秒，默认PyVRP0.14.0 ILS。
标准CVRP不固定路线数，K_solver=客户数，固定车辆成本为0。与旧16题at-most-K_ref派生面板不同，不能仅按规模解释gap差异，也没有本轮TSR比较。
完整协议见freeze/PROTOCOL.json；原始文件与normalized inputs、参考解、历史41题底本指纹、独立矩阵审核、合成全链测试均保留。
依赖复用已有隔离venv；environment/RESTORE_MANIFEST.json精确引用已有私有wheel归档。此包不重复包含wheel字节，离线恢复须先取回被引用的依赖归档。
执行前须完成独立审查、PREEXEC私有实际字节回读、父任务对freeze和归档SHA的批准、串行执行窗口。执行后RAW先归档回读再末评分，独立审查保存解，不重跑求解器。
