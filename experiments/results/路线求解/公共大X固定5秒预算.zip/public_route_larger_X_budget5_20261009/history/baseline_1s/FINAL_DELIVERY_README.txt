标准X大实例实验已执行并通过独立末审

36/36固定调用完成，36/36有效；全12题三seed均值平均reference gap2.648316148%。
阅读reports/FINAL_REPORT_ZH.txt；全部数值在reports/PER_SEED.csv、reports/PER_INSTANCE.csv、reports/SUMMARY.json。独立审查在independent_review/POSTRUN_INDEPENDENT_AUDIT.json。
本轮标准CVRP不固定路线数，和旧16题at-most-K_ref派生面板不同；不能将两批差异单归因规模，没有TSR大实例对照。
README.txt及reports/REPORT_ZH.txt为执行前说明/自动初稿，保留其历史状态；最终结论以FINAL_REPORT_ZH与独立末审为准。
PREEXEC及RAW已真实私有上传下载字节验证；最终归档回执随后单独保存，以免自引用。
此包采用增量依赖恢复：environment/RESTORE_MANIFEST.json精确引用现有私有wheel归档及SHA，恢复时必须一并取回，不是自包含安装包。
