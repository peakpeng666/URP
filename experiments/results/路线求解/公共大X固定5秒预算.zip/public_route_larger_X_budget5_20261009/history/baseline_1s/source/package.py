"""One-time stage archives. No benchmark solver is imported or called."""
from common import ROOT,now,sha,read,save,verify_frozen,verify_old
import sys,zipfile

def eligible(p):
    return p.is_file() and '__pycache__' not in p.parts

def package(stage):
    assert stage in ('PREEXEC','RAW_UNREVIEWED','FINAL_REVIEWED')
    if stage=='PREEXEC':
        assert not (ROOT/'raw/STARTED.json').exists()
        assert read('freeze/INDEPENDENT_PRECHECK.json')['status']=='PASS'
        verify_old()
        files={str(p.relative_to(ROOT)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(ROOT.rglob('*')) if eligible(p) and str(p.relative_to(ROOT)).split('/')[0] not in ('raw','reports')}
        save(ROOT/'freeze/FROZEN_FILES.json',{'utc':now(),'stage':'PREEXEC_FROZEN','files':files})
    verify_frozen()
    if stage=='RAW_UNREVIEWED':
        save(ROOT/'raw/RAW_UNREVIEWED_MANIFEST.json',{'utc':now(),'status':'UNREVIEWED_RAW_NO_ENDPOINT_SCORING_YET','files':{str(p.relative_to(ROOT)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted((ROOT/'raw').rglob('*')) if eligible(p)}})
    path=ROOT.parent/(ROOT.name+'_'+stage+'.zip')
    with zipfile.ZipFile(path,'x',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(ROOT.rglob('*')):
            if eligible(p):z.write(p,str(p.relative_to(ROOT.parent)))
    return {'path':str(path),'bytes':path.stat().st_size,'sha256':sha(path),'frozen_files_sha256':sha(ROOT/'freeze/FROZEN_FILES.json'),'stage':stage}
if __name__=='__main__':
    import json
    print(json.dumps(package(sys.argv[1])))
