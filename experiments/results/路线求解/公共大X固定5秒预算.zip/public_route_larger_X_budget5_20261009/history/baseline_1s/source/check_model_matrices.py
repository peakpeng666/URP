"""Build PyVRP data for frozen inputs only: never calls solve or constructs solutions."""
import sys,json,hashlib
from common import ROOT,read,save,now
from worker import build_model

def main():
    if not __debug__:raise RuntimeError('Assertions must be enabled')
    independent=read('independent_review/INPUT_MATRIX_AUDIT.json')
    expected={r['instance_id']:r['matrix_sha256'] for r in independent['rows']}
    rows=[]
    for task in read('freeze/TASKS.json'):
        if not task['eligible']:continue
        raw=read(f"input/{task['instance_id']}.json")
        payload={k:raw[k] for k in ('coordinates','demands','capacity','K')}
        data,matrix,mapping=build_model(payload)
        actual=hashlib.sha256(json.dumps(data.distance_matrix(0).tolist(),separators=(',',':')).encode()).hexdigest()
        assert actual==expected[task['instance_id']]
        v=data.vehicle_type(0)
        assert v.num_available==raw['K'] and list(v.capacity)==[raw['capacity']]
        assert v.fixed_cost==0 and v.unit_distance_cost==1 and v.unit_duration_cost==0
        assert v.unit_overtime_cost==0 and v.max_overtime==0
        assert v.start_depot==v.end_depot==0 and list(v.reload_depots)==[] and v.max_reloads==0
        assert data.num_vehicle_types==1 and data.num_shipments==0 and data.num_groups==0
        assert not data.duration_matrix(0).any()
        assert all(data.client(i).required and data.client(i).location==i+1 and list(data.client(i).delivery)==[raw['demands'][i+1]] and list(data.client(i).pickup)==[0] for i in range(data.num_clients))
        rows.append({'instance_id':task['instance_id'],'model_matrix_sha256':actual,'independent_expected_sha256':expected[task['instance_id']],'all_model_semantics_asserted':True,'mapped_nodes':len(mapping),'num_vehicles_available':v.num_available,'capacity':list(v.capacity),'directed_cells':len(matrix)**2})
    save(ROOT/'selftests/ACTUAL_MODEL_MATRIX_AUDIT.json',{'utc':now(),'status':'PASS','tasks_built_without_optimization':len(rows),'public_optimizer_calls':0,'source':'worker.build_model only, no solve, RandomNumberGenerator or Solution invoked','rows':rows})
    print('PASS actual PyVRP models; zero public optimization calls')
if __name__=='__main__':main()
