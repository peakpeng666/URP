"""Saved-output endpoint evaluation only, after verified raw private readback; no optimizer imports."""
from pathlib import Path
import sys,json,csv,statistics
from fractions import Fraction
from common import ROOT,now,sha,read,save,verify_frozen,verify_old,receipt
sys.path.insert(0,str(ROOT/'independent_review'))
from independent_validator import validate_solution

def dump_csv(path,rows):
    keys=list(dict.fromkeys(k for row in rows for k in row))
    with path.open('x',newline='') as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)

def main():
    verify_frozen();receipt('RAW_UNREVIEWED');verify_old()
    manifest=read('raw/RAW_UNREVIEWED_MANIFEST.json')
    assert all(sha(ROOT/p)==m['sha256'] and (ROOT/p).stat().st_size==m['bytes'] for p,m in manifest['files'].items())
    schedule=read('freeze/SCHEDULE.json');tasks=read('freeze/TASKS.json')
    observed=[json.loads(line) for line in (ROOT/'raw/results.jsonl').read_text().splitlines()] if (ROOT/'raw/results.jsonl').exists() else []
    assert len({r['call_id'] for r in observed})==len(observed)
    assert set(r['call_id'] for r in observed)<=set(r['call_id'] for r in schedule)
    by_id={r['call_id']:r for r in observed};task_map={t['instance_id']:t for t in tasks}
    inputs={t['instance_id']:read(f"input/{t['instance_id']}.json") for t in tasks if t['eligible']}
    matrix_hashes={r['instance_id']:r['matrix_sha256'] for r in read('independent_review/INPUT_MATRIX_AUDIT.json')['rows'] if r.get('valid',True)}
    audit_rows=[];seed_rows=[]
    for e in schedule:
        record=by_id.get(e['call_id']);answer=None;validation=None;errors=[]
        if not task_map[e['instance_id']]['eligible']:errors.append('INELIGIBLE_INPUT')
        if record is None:errors.append('NEVER_STARTED_OR_MISSING_RECORD')
        elif record['status']!='UNREVIEWED_PROCESS_SUCCESS':errors.append(record['status'])
        if record is not None and record.get('process_spawned'):
            for typ in ('stdout','stderr'):
                p=ROOT/record[typ]
                if not p.exists() or sha(p)!=record.get(typ+'_sha256'):errors.append(f'{typ}_HASH_MISMATCH')
        if not errors:
            try:
                answer=json.loads((ROOT/record['stdout']).read_text())
                validation=validate_solution(inputs[e['instance_id']],answer['routes'],answer['reported_cost'])
                if not(validation['valid'] and validation['reported_cost_checked'] and validation['reported_cost_matches']):errors.append('INDEPENDENT_ROUTE_VALIDATION_FAILED')
                if not(answer['solver_is_feasible'] and answer['solver_is_complete']):errors.append('SOLVER_NOT_FEASIBLE_COMPLETE')
                if answer['reported_fixed_vehicle_cost']!=0 or answer['reported_duration_cost']!=0:errors.append('NON_DISTANCE_OBJECTIVE')
                if answer['reported_cost']!=answer['reported_distance']:errors.append('DISTANCE_OBJECTIVE_MISMATCH')
                expected_limits={'inherited':{'AS_bytes':[512*1024**2,1536*1024**2],'CPU_seconds':[30,30]},'effective':{'AS_bytes':[1536*1024**2,1536*1024**2],'CPU_seconds':[10,10]}}
                if answer.get('resource_limits')!=expected_limits:errors.append('RESOURCE_INHERITANCE_MISMATCH')
                if answer['model_matrix_sha256']!=matrix_hashes[e['instance_id']]:errors.append('MODEL_MATRIX_MISMATCH')
                if answer['denied_io_events'] or answer['reference_or_history_payload_fields']:errors.append('IO_OR_PAYLOAD_VIOLATION')
                if answer['seed']!=e['seed'] or answer['max_runtime_seconds']!=1.0 or answer['version']!='0.14.0':errors.append('SCHEDULE_VERSION_MISMATCH')
                if len(answer['native_routes'])!=len(answer['routes']):errors.append('NATIVE_ROUTE_COUNT_MISMATCH')
                else:
                    for closed,native in zip(answer['routes'],answer['native_routes']):
                        if [a['node'] for a in native['activities']]!=closed:errors.append('NATIVE_MAPPING_MISMATCH')
                        for pos,a in enumerate(native['activities']):
                            if a['location']!=a['node']:errors.append('LOCATION_MAP_MISMATCH')
                            if pos in (0,len(native['activities'])-1):
                                if a['type']!='DEPOT' or a['idx']!=0 or a['node']!=0:errors.append('BAD_NATIVE_DEPOT')
                            elif a['type']!='CLIENT' or a['idx']+1!=a['node']:errors.append('BAD_NATIVE_CLIENT')
                        if native['vehicle_type']!=0 or native['num_trips']!=1:errors.append('BAD_NATIVE_VEHICLE_TRIP')
            except Exception as exc:errors.append('PARSE_VALIDATION_EXCEPTION:'+str(exc))
        valid=not errors
        audit_rows.append({'call_id':e['call_id'],'valid':valid,'errors':errors,'validation':validation})
        seed_rows.append({**e,'status':'VALID' if valid else 'UNAVAILABLE','cost':validation['cost'] if valid else None,
          'nonempty_routes':validation['nonempty_routes'] if valid else None,'iterations':answer.get('num_iterations') if answer else None,
          'search_runtime_audit_only':answer.get('solver_loop_runtime') if answer else None,
          'process_wall_audit_only':record.get('wall_seconds_audit_only') if record else None,'process_cpu_audit_only':record.get('cpu_seconds_audit_only') if record else None,
          'build_wall_audit_only':answer.get('build_wall_seconds_audit_only') if answer else None,'solve_wall_audit_only':answer.get('solve_wall_seconds_audit_only') if answer else None,
          'worker_maxrss_KiB_audit_only':answer.get('worker_maxrss_KiB_audit_only') if answer else None,'failure':';'.join(errors)})
    task_rows=[];ref_audits=[];gaps=[];by_band={b:[] for b in range(1,5)}
    for task in tasks:
        name=task['instance_id'];slot=task['selection_slot'];seed=[r for r in seed_rows if r['instance_id']==name];values=[r['cost'] for r in seed if r['status']=='VALID']
        reference=None;ref_audit=None
        if task['eligible']:
            ref=read(f'references/{name}.json');ref_audit=validate_solution(inputs[name],[[0,*r,0] for r in ref['reference_routes']],ref['reference_integer_cost'])
            assert ref_audit['valid'] and ref_audit['reported_cost_matches'];reference=ref_audit['cost'];assert reference>0
            assert inputs[name]['K']==task['n_customers'] and ref['K_solver']==task['n_customers']
            ref_audits.append({'instance_id':name,'reference':ref_audit,'no_optimality_proof_established_here':True})
        row={'instance_id':name,'selection_slot':slot,'band':task['band'],'n_customers':task['n_customers'],'K_solver':task['K'],'K_name_audit_only':task['K_name_audit_only'],'K_catalog_audit_only':task['K_catalog_audit_only'],'reference_nonempty_routes_audit_only':ref_audit['nonempty_routes'] if ref_audit else None,'reference_cost':reference,'valid_seed_count':len(values),'planned_seed_count':3,'seed0_cost':seed[0]['cost'],'seed1_cost':seed[1]['cost'],'seed2_cost':seed[2]['cost'],'mean3_cost':None,'mean3_reference_gap_percent':None,'best_of3_cost_secondary':None,'worst_of3_cost_secondary':None,'range3_cost_secondary':None,'sample_SD3_cost_secondary':None,'complete_three_seed':len(values)==3 and reference is not None}
        if row['complete_three_seed']:
            mean=Fraction(sum(values),3);gap=100*(mean-reference)/reference;gaps.append(gap);by_band[task['band']].append(gap)
            row.update(mean3_cost=float(mean),mean3_reference_gap_percent=float(gap),best_of3_cost_secondary=min(values),worst_of3_cost_secondary=max(values),range3_cost_secondary=max(values)-min(values),sample_SD3_cost_secondary=statistics.stdev(values))
        task_rows.append(row)
    avg=lambda v:float(sum(v)/len(v)) if v else None
    summary={'utc':now(),'stage':'STANDARD_X_SHORT_BUDGET_DESCRIPTIVE_QUALITY','solver':'PyVRP 0.14.0 default ILS','task_semantics':'Standard CVRP: no fixed fleet size, num_available=n_customers, zero fixed vehicle cost. Not the old at-most-K_ref derived panel.','planned_instances':12,'planned_calls':36,'observed_scheduled_rows':len(observed),'spawned_calls':sum(r.get('process_spawned',False) for r in observed),'valid_calls':sum(a['valid'] for a in audit_rows),'complete_three_seed_tasks':len(gaps),'all12_mean_reference_gap_percent':avg(gaps) if len(gaps)==12 else None,'descriptive_available_complete_mean_gap_percent':avg(gaps),'descriptive_complete_task_denominator':len(gaps),'descriptive_bands':[{'band':b,'customer_interval':read('freeze/SELECTION_RULE.json')['bands'][b-1],'planned_tasks':3,'complete_tasks':len(by_band[b]),'three_task_mean_gap_percent':avg(by_band[b]) if len(by_band[b])==3 else None,'available_complete_mean_gap_percent':avg(by_band[b])} for b in range(1,5)],'failed_or_unavailable_seed_slots':36-sum(a['valid'] for a in audit_rows),'strict_blind':False,'preregistered_confirmatory':False,'old_TSR_comparator_available':False,'cross_panel_difference_cannot_be_attributed_only_to_size':True,'no_equal_compute_or_speed_claim':True,'no_optimality_proof_claim':True,'old_files_verified_unchanged':verify_old(),'limitations':read('freeze/PROTOCOL.json')['limitations']}
    save(ROOT/'reports/SAVED_ROUTE_VALIDATION.json',{'utc':now(),'optimizer_rerun':False,'calls':audit_rows,'reference_validation':ref_audits})
    save(ROOT/'reports/SUMMARY.json',summary);dump_csv(ROOT/'reports/PER_SEED.csv',seed_rows);dump_csv(ROOT/'reports/PER_INSTANCE.csv',task_rows)
    lines=['标准X大实例：PyVRP0.14.0默认ILS短预算质量面板','', '本轮使用标准CVRP，不固定路线数：可用车辆上界取客户数，固定车费为0，仅最小化整数总距离。文件名k、目录K和参考解路线数均不成为车数约束。','与之前16题at-most-K_ref派生面板的任务定义不同，因此两批gap差异不能单独归因规模。','',f"12题客户数100–523，四个预定区间各3题；每题seeds0/1/2，MaxRuntime(1.0s)，共36个计划槽。有效输出{summary['valid_calls']}/36，三seed齐全{len(gaps)}/12。",'主结果为每题三seed平均成本的reference gap，再对12题等权。']
    if len(gaps)==12:lines.append(f"全12题平均reference gap：{avg(gaps):.9f}%。")
    else:lines.append('存在失败或缺失，全12题主均值留空；可用完整任务描述值及其分母见SUMMARY.json。')
    for b in summary['descriptive_bands']:lines.append(f"规模带{b['customer_interval']}：完整{b['complete_tasks']}/3题，描述均值gap={b['three_task_mean_gap_percent']}%。")
    lines+=['','边界与审计：','- 非严格盲测、非确认性研究；只有这12个确定性选定标准X实例，不推断全部CVRP或通用大规模能力。','- 本轮没有TSR同任务结果，不构造或声称TSR大规模胜负。','- 1秒是ILS循环stop，模型构建、导入与初始化不在该1秒内；每子进程另外配置10秒CPU/20秒外墙时/1536MiB AS，主管30秒CPU/900秒墙时、AS软512/硬1536MiB；外层960秒杀进程组。','- 配置CPU限额和390秒，不是严格实测端到端CPU上界；软AS并存限额和2048MiB、理论硬限额和3072MiB，也不是RSS实测。实际时间/CPU/maxRSS在逐seed数据。','- 参考为已独立验证可行成本，未在本研究重建最优性证明；即使gap为0也不宣称由此证明最优。','- 不调参、不热启动、不给solver参考解或cost；Python audit hook不等于原生系统调用安全沙箱。','- 每冻结调用只执行一次。失败不删除、不换题、不加预算重跑；best-of3只在逐题副表。','- 时间型停止受硬件/负载影响，固定seed不保证逐位复现；主进程与另一个研究批次按父任务分配窗口串行执行。','', '依赖恢复：environment/RESTORE_MANIFEST.json引用已有私有wheel归档及SHA，不重复打包依赖；必须连同该归档才能从零恢复。','报告待独立最终审阅。']
    with (ROOT/'reports/REPORT_ZH.txt').open('x') as f:f.write('\n'.join(lines)+'\n')
    print(json.dumps(summary,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
