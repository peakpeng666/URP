"""No optimizer: strict parse, reference feasibility check, historical fingerprint exclusion."""
from common import ROOT,now,sha,read,save
from legacy_parse_data import parse_instance,parse_sol,refcheck,fp
import sys,json

def main():
    history=[];index={}
    for h in read('freeze/HISTORICAL_INPUTS.json'):
        p=ROOT/h['local'];assert sha(p)==h['sha256'];meta,xy,ds=parse_instance(p);assert meta['NAME']==h['instance_id']
        fingerprints=fp(xy,ds);history.append({**h,'fingerprints':fingerprints})
        for typ,value in fingerprints.items():index.setdefault((typ,value),[]).append(h['instance_id'])
    assert len(history)==41
    save(ROOT/'freeze/HISTORICAL_FINGERPRINTS.json',history)
    tasks=[];seen={}
    for selected in read('freeze/SELECTED_PANEL.json'):
        name=selected['instance_id'];t=dict(selected,eligible=False,errors=[])
        try:
            p=ROOT/'input'/f'{name}.vrp';s=ROOT/'references'/f'{name}.sol'
            meta,xy,ds=parse_instance(p)
            assert meta['NAME']==name and len(ds)-1==selected['n_customers'] and int(meta['CAPACITY'])==selected['capacity']
            assert all(x==x.to_integral_value() and y==y.to_integral_value() for x,y in xy)
            assert all(0<d<=int(meta['CAPACITY']) for d in ds[1:])
            hashes=fp(xy,ds);hits=sorted(set(n for typ,v in hashes.items() for n in index.get((typ,v),[])));internal=sorted(set(n for typ,v in hashes.items() for n in seen.get((typ,v),[])))
            for typ,v in hashes.items():seen.setdefault((typ,v),[]).append(name)
            if hits or internal:t['errors'].append('duplicate historical/panel coordinate-demand base')
            routes,claimed=parse_sol(s);reference=refcheck(xy,ds,int(meta['CAPACITY']),routes,claimed)
            normalized={'instance_id':name,'coordinates':[[int(x),int(y)] for x,y in xy],'demands':ds,'capacity':int(meta['CAPACITY']),'K':len(ds)-1}
            save(ROOT/'input'/f'{name}.json',normalized)
            save(ROOT/'references'/f'{name}.json',{**reference,'instance_id':name,'standard_CVRP_no_fixed_vehicle_count':True,'K_solver':len(ds)-1,'reference_url':selected['reference_url'],'not_available_to_solver':True})
            t.update(eligible=not t['errors'],fingerprints=hashes,historical_duplicate_names=hits,earlier_duplicate_names=internal,source_instance_sha256=sha(p),source_reference_sha256=sha(s),normalized_sha256=sha(ROOT/'input'/f'{name}.json'),K_solver=len(ds)-1,K_reference_audit_only=reference['K_ref'])
        except Exception as e:t['errors'].append(type(e).__name__+': '+str(e))
        tasks.append(t)
    save(ROOT/'freeze/TASKS.json',tasks)
    save(ROOT/'freeze/INPUT_PREPARATION.json',{'utc':now(),'selected_slots':12,'eligible':sum(t['eligible'] for t in tasks),'history_named_tasks':41,'history_unique_bases':len(set(h['fingerprints']['translation_and_renumbering_invariant'] for h in history)),'no_replacements':True,'public_optimizer_calls':0,'failures':[t for t in tasks if not t['eligible']]})
    print(json.dumps(read('freeze/INPUT_PREPARATION.json'),indent=2))
if __name__=='__main__':main()
