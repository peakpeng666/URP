标准X固定预算扩展，2026-10-09 UTC

科研执行已完成：新增5s档36次唯一正式调用，36/36有效。历史1s不重跑。12题同3seed主均值gap：历史2.6483161483549815%，新5s1.273383409349262%；5s减历史1s=-1.3749327390057196个百分点。36配对全部改善，严格等于reference从0到5，无低于reference。
跨时段描述性对照：不支持纯预算因果、固定seed轨迹嵌套、单调性、最优性证明、统计显著或等算力/速度断言。

主要阅读顺序：
reports/REPORT_ZH.txt
reports/COMPARISON_SUMMARY.json
reports/COMPARISON_PER_INSTANCE.csv
reports/PAIRED_SEED_CHANGES.csv
reports/BOTH_BUDGETS_PER_SEED.csv
independent_review/POSTRUN_INDEPENDENT_AUDIT.json

完整原始输出在raw；历史非pycache底本在history/baseline_1s。新PREEXEC与RAW私有实际回读证据在provenance。
依赖只以environment/RESTORE_MANIFEST.json精确引用原有私有归档DriveID/hash及恢复清单，本包不重复包含wheel。恢复需要被引用的私有依赖包。
旧所有证据文件保持不变。两个受阻交接索引未改，未建替代索引。
最终包本身不能包含它随后产生的实际回读receipt；最终owner-only回读证据保存在包外provenance/FINAL_REVIEWED_DRIVE_RECEIPT.json，并由交付链接呈现。制作本README时最终归档尚待完成。
