"""Deterministic invented full chain tests; public files are not read."""
import sys,json,resource,signal
from common import ROOT,now,read,save,sha
from run_once import execute_call
sys.path.insert(0,str(ROOT/'independent_review'))
from independent_validator import validate_solution

def run_in_limited_supervisor(limits):
    assert limits=={'AS_bytes':[512*1024**2,1536*1024**2],'CPU_seconds':[30,30]}
    signal.alarm(150)
    dest=ROOT/'selftests/integration';dest.mkdir(exist_ok=False)
    python=read('environment/RUNTIME.json')['python_executable'];records=[]
    fixtures=[
        {'instance_id':'INVENTED_524_LOCATIONS','coordinates':[[0,0]]+[[i%31,(i*17)%29] for i in range(1,524)],'demands':[0]+[1]*523,'capacity':25,'K':523},
        {'instance_id':'INVENTED_STANDARD_UNBOUNDED','coordinates':[[0,0],[1,0],[0,1],[-1,0]],'demands':[0,2,2,2],'capacity':3,'K':3},
        {'instance_id':'INVENTED_DUPLICATE_LOCATIONS','coordinates':[[0,0],[1,1],[1,1],[3,4]],'demands':[0,1,1,2],'capacity':3,'K':3},
    ]
    for seed,fixture in enumerate(fixtures):
        entry={'call_id':f'FIXTURE_seed{seed}','seed':seed,'max_runtime_seconds':5.0,'instance_id':fixture['instance_id']}
        payload={k:v for k,v in fixture.items() if k!='instance_id'};payload.update(seed=seed,max_runtime_seconds=5.0)
        record=execute_call(entry,payload,python,dest)
        assert record['status']=='UNREVIEWED_PROCESS_SUCCESS' and record['child_reaped'],record
        answer=json.loads((ROOT/record['stdout']).read_text());audit=validate_solution(fixture,answer['routes'],answer['reported_cost'])
        assert audit['valid'] and audit['reported_cost_matches'],audit
        expected={'inherited':limits,'effective':{'AS_bytes':[1536*1024**2,1536*1024**2],'CPU_seconds':[15,15]}}
        assert answer['resource_limits']==expected
        records.append({'kind':'invented_actual_full_budget_solver','fixture':fixture,'record':record,'validation':audit,'resource_limits':answer['resource_limits'],'worker_maxrss_KiB':answer['worker_maxrss_KiB_audit_only']})
    for kind,expected_status in [('wall_timeout','WALL_TIMEOUT'),('cpu_limit','PROCESS_FAILURE_OR_CPU_LIMIT'),('as_limit','PROCESS_FAILURE_OR_CPU_LIMIT')]:
        entry={'call_id':'FAULT_'+kind,'seed':0,'max_runtime_seconds':5.0,'instance_id':'INVENTED_'+kind}
        record=execute_call(entry,{'synthetic_fault':kind},python,dest,ROOT/'source/synthetic_fault_worker.py')
        assert record['status']==expected_status and record['child_reaped'],record
        lines=(ROOT/record['stdout']).read_text().splitlines();diagnostic=json.loads(lines[0]);assert diagnostic['resource_limits']['inherited']==limits
        if kind=='wall_timeout':assert record['wall_seconds_audit_only']>=25 and record['returncode']<0
        elif kind=='cpu_limit':assert record['cpu_seconds_audit_only']>=14.5 and record['returncode']<0
        else:assert record['returncode']==23 and json.loads(lines[1])=={'expected_memory_error':True}
        records.append({'kind':'injected_resource_fault','record':record,'diagnostic':diagnostic})
    e={'call_id':'FAULT_malformed','seed':0,'max_runtime_seconds':5.0,'instance_id':'INVENTED_MALFORMED'}
    bad=execute_call(e,{'malformed':True},python,dest);assert bad['status']=='PROCESS_FAILURE_OR_CPU_LIMIT' and bad['child_reaped']
    records.append({'kind':'bad_payload','record':bad})
    second=execute_call(e,{'malformed':True},python,dest);assert second['status']=='CALL_ERROR_UNDETERMINED' and not second['process_spawned'];records.append({'kind':'exclusive_output_guard','record':second})
    signal.alarm(0)
    save(ROOT/'selftests/SUPERVISOR_INTEGRATION.json',{'utc':now(),'status':'PASS','scope':'Actual configured production limited supervisor -> production execute_call/Popen -> exact venv real worker; invented524-location full5s plus fixedseed1/2 small fixtures, wall/CPU/AS faults, malformed and duplicate protections.','public_optimizer_calls':0,'synthetic_optimizer_calls':3,'supervisor_limits':limits,'supervisor_maxrss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'records':records,'source_sha256':{name:sha(ROOT/'source'/name) for name in ['worker.py','run_once.py','synthetic_integration.py','synthetic_fault_worker.py']}})
    print('PASS synthetic production chain and resource faults')
