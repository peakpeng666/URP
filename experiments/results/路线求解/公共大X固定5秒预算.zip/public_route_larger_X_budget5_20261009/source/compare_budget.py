"""Saved-route-only historical1s versus new5s comparison, no optimizer imports."""
from pathlib import Path
import sys,json,csv,statistics
from fractions import Fraction
from collections import Counter
from common import ROOT,now,sha,read,save
sys.path.insert(0,str(ROOT/'independent_review'))
from audit_large_x_inputs import parse_original
from independent_validator import validate_solution

def dump_csv(path,rows):
    keys=list(dict.fromkeys(k for row in rows for k in row))
    with path.open('x',newline='') as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)

def evaluate_budget(base,budget,child_cpu):
    """Retain the fixed36 slots even for absent records/files or invalid output."""
    load=lambda rel:json.loads((base/rel).read_text())
    schedule=load('freeze/SCHEDULE.json');tasks=load('freeze/TASKS.json')
    assert len(schedule)==36 and len(tasks)==12
    results=base/'raw/results.jsonl'
    observed=[json.loads(x) for x in results.read_text().splitlines()] if results.exists() else []
    counts=Counter(r['call_id'] for r in observed);byid={r['call_id']:r for r in observed}
    assert set(byid)<=set(e['call_id'] for e in schedule)
    originals={};references={};reference_audits=[]
    for task in tasks:
        name=task['instance_id']
        if not task['eligible']:continue
        problem=parse_original((base/'input'/f'{name}.vrp').read_text(),name)
        assert problem['K']==len(problem['demands'])-1
        normalized=load(f'input/{name}.json')
        assert normalized['K']==problem['K'] and normalized['demands']==problem['demands'] and normalized['capacity']==problem['capacity']
        assert normalized['coordinates']==[[float(x),float(y)] for x,y in problem['coordinates']]
        ref=load(f'references/{name}.json')
        v=validate_solution(problem,[[0,*r,0] for r in ref['reference_routes']],ref['reference_integer_cost'])
        assert v['valid'] and v['reported_cost_matches'] and v['cost']>0
        originals[name]=problem;references[name]=v['cost'];reference_audits.append({'instance_id':name,'validation':v})
    rows=[];validations=[]
    for e in schedule:
        name=e['instance_id'];rec=byid.get(e['call_id']);errors=[];ans=None;v=None
        if name not in originals:errors.append('INELIGIBLE_INPUT')
        if counts[e['call_id']]>1:errors.append('DUPLICATE_RECORD')
        if rec is None:errors.append('MISSING_RECORD')
        elif rec['status']!='UNREVIEWED_PROCESS_SUCCESS':errors.append(rec['status'])
        if rec is not None and rec.get('process_spawned'):
            for kind in ('stdout','stderr'):
                p=base/rec[kind]
                if not p.is_file() or sha(p)!=rec.get(kind+'_sha256'):errors.append(kind.upper()+'_HASH_MISMATCH')
        if not errors:
            try:
                ans=json.loads((base/rec['stdout']).read_text())
                v=validate_solution(originals[name],ans['routes'],ans['reported_cost'])
                if not(v['valid'] and v['reported_cost_checked'] and v['reported_cost_matches']):errors.append('INVALID_SAVED_ROUTE')
                if not(ans['solver_is_complete'] and ans['solver_is_feasible']):errors.append('INCOMPLETE_OR_INFEASIBLE')
                if ans['reported_cost']!=ans['reported_distance'] or ans['reported_fixed_vehicle_cost']!=0 or ans['reported_duration_cost']!=0:errors.append('OBJECTIVE_MISMATCH')
                if ans['seed']!=e['seed'] or ans['max_runtime_seconds']!=budget or e['max_runtime_seconds']!=budget or ans['version']!='0.14.0':errors.append('BUDGET_SEED_VERSION_MISMATCH')
                limits={'inherited':{'AS_bytes':[512*1024**2,1536*1024**2],'CPU_seconds':[30,30]},'effective':{'AS_bytes':[1536*1024**2,1536*1024**2],'CPU_seconds':[child_cpu,child_cpu]}}
                if ans['resource_limits']!=limits:errors.append('LIMIT_MISMATCH')
                if ans['denied_io_events'] or ans['reference_or_history_payload_fields']:errors.append('IO_OR_PAYLOAD_VIOLATION')
            except Exception as exc:errors.append('VALIDATION_EXCEPTION:'+repr(exc))
        valid=not errors;cost=v['cost'] if valid else None;ref=references.get(name)
        rows.append({**e,'budget_role':'historical1s' if budget==1.0 else 'new5s','budget_seconds':budget,'status':'VALID' if valid else 'UNAVAILABLE','cost':cost,'reference_cost':ref,'gap_percent':float(100*Fraction(cost-ref,ref)) if valid else None,'equals_reference':cost==ref if valid else None,'below_reference':cost<ref if valid else None,'process_wall_seconds_audit_only':rec.get('wall_seconds_audit_only') if rec else None,'process_cpu_seconds_audit_only':rec.get('cpu_seconds_audit_only') if rec else None,'solve_wall_seconds_audit_only':ans.get('solve_wall_seconds_audit_only') if ans else None,'build_wall_seconds_audit_only':ans.get('build_wall_seconds_audit_only') if ans else None,'solver_loop_runtime_audit_only':ans.get('solver_loop_runtime') if ans else None,'failure':';'.join(errors)})
        validations.append({'call_id':e['call_id'],'budget_seconds':budget,'valid':valid,'errors':errors,'validation':v})
    return rows,validations,reference_audits

def summarize(oldrows,newrows,tasks):
    old={(r['instance_id'],r['seed']):r for r in oldrows};new={(r['instance_id'],r['seed']):r for r in newrows}
    assert set(old)==set(new) and len(old)==36
    paired=[];taskrows=[];ogaps=[];ngaps=[];deltas=[]
    for task in tasks:
        name=task['instance_id'];oldcost=[];newcost=[];ref=None
        for seed in [0,1,2]:
            a,b=old[(name,seed)],new[(name,seed)]
            if a['reference_cost'] is not None and b['reference_cost'] is not None:
                assert a['reference_cost']==b['reference_cost']
            ref=a['reference_cost'] if a['reference_cost'] is not None else b['reference_cost']
            if a['status']=='VALID':oldcost.append(a['cost'])
            if b['status']=='VALID':newcost.append(b['cost'])
            valid=a['status']==b['status']=='VALID'
            delta=b['cost']-a['cost'] if valid else None
            outcome=('IMPROVED' if delta<0 else 'EQUAL' if delta==0 else 'WORSE') if valid else 'UNAVAILABLE'
            paired.append({'instance_id':name,'seed':seed,'historical1s_cost':a['cost'],'new5s_cost':b['cost'],'new_minus_historical_cost':delta,'outcome':outcome})
        om=Fraction(sum(oldcost),3) if len(oldcost)==3 and ref is not None else None
        nm=Fraction(sum(newcost),3) if len(newcost)==3 and ref is not None else None
        og=100*(om-ref)/ref if om is not None else None
        ng=100*(nm-ref)/ref if nm is not None else None
        delta=ng-og if og is not None and ng is not None else None
        if og is not None:ogaps.append(og)
        if ng is not None:ngaps.append(ng)
        if delta is not None:deltas.append(delta)
        taskrows.append({'instance_id':name,'selection_slot':task['selection_slot'],'band':task['band'],'n_customers':task['n_customers'],'reference_cost':ref,'historical1s_valid_seeds':len(oldcost),'new5s_valid_seeds':len(newcost),'historical1s_mean3_cost':float(om) if om is not None else None,'new5s_mean3_cost':float(nm) if nm is not None else None,'historical1s_mean3_gap_percent':float(og) if og is not None else None,'new5s_mean3_gap_percent':float(ng) if ng is not None else None,'new5s_minus_historical1s_gap_pp':float(delta) if delta is not None else None})
    avg=lambda vals:float(sum(vals)/len(vals)) if vals else None
    counts=dict(Counter(r['outcome'] for r in paired))
    for state in ('IMPROVED','EQUAL','WORSE','UNAVAILABLE'):counts.setdefault(state,0)
    summary={'utc':now(),'comparison':'New5s versus previously observed historical1s, cross-period descriptive only','planned_tasks':12,'planned_calls_each_budget':36,'historical1s_valid_calls':sum(r['status']=='VALID' for r in oldrows),'new5s_valid_calls':sum(r['status']=='VALID' for r in newrows),'historical1s_complete_tasks':len(ogaps),'new5s_complete_tasks':len(ngaps),'paired_complete_tasks':len(deltas),'historical1s_all12_mean_reference_gap_percent':avg(ogaps) if len(ogaps)==12 else None,'new5s_all12_mean_reference_gap_percent':avg(ngaps) if len(ngaps)==12 else None,'all12_new5s_minus_historical1s_gap_pp':avg(deltas) if len(deltas)==12 else None,'all12_historical1s_minus_new5s_reduction_pp':-avg(deltas) if len(deltas)==12 else None,'available_paired_complete_task_mean_delta_pp':avg(deltas),'available_paired_complete_task_denominator':len(deltas),'paired_seed_outcomes':counts,'reference_equality_counts':{'historical1s':sum(r['equals_reference'] is True for r in oldrows),'new5s':sum(r['equals_reference'] is True for r in newrows)},'below_reference_counts':{'historical1s':sum(r['below_reference'] is True for r in oldrows),'new5s':sum(r['below_reference'] is True for r in newrows)},'no_monotonicity_assumption':True,'no_causal_budget_only_claim':True,'no_equal_compute_or_speed_claim':True,'optimizer_rerun':False,'bands':[]}
    for band in range(1,5):
        rows=[r for r in taskrows if r['band']==band];valid=[r for r in rows if r['new5s_minus_historical1s_gap_pp'] is not None]
        summary['bands'].append({'band':band,'planned_tasks':3,'paired_complete_tasks':len(valid),'historical1s_mean_gap_percent':statistics.mean(r['historical1s_mean3_gap_percent'] for r in rows) if all(r['historical1s_mean3_gap_percent'] is not None for r in rows) else None,'new5s_mean_gap_percent':statistics.mean(r['new5s_mean3_gap_percent'] for r in rows) if all(r['new5s_mean3_gap_percent'] is not None for r in rows) else None,'new_minus_historical_gap_pp':statistics.mean(r['new5s_minus_historical1s_gap_pp'] for r in valid) if len(valid)==3 else None})
    return summary,paired,taskrows

def main():
    oldrows,olda,oldref=evaluate_budget(ROOT/'history/baseline_1s',1.0,10)
    newrows,newa,newref=evaluate_budget(ROOT,5.0,15)
    summary,pairs,taskrows=summarize(oldrows,newrows,read('freeze/TASKS.json'))
    save(ROOT/'reports/COMPARISON_SUMMARY.json',summary)
    save(ROOT/'reports/COMPARISON_SAVED_ROUTE_AUDIT.json',{'utc':now(),'optimizer_rerun':False,'historical1s':olda,'new5s':newa,'historical_references':oldref,'new_references':newref})
    dump_csv(ROOT/'reports/BOTH_BUDGETS_PER_SEED.csv',oldrows+newrows)
    dump_csv(ROOT/'reports/PAIRED_SEED_CHANGES.csv',pairs)
    dump_csv(ROOT/'reports/COMPARISON_PER_INSTANCE.csv',taskrows)
    lines=['标准X同题预算扩展：历史1秒与新5秒','', '同12题、seeds0/1/2；只新增5s档36个唯一调用。旧1s是已观察的跨时段历史，不重跑、不warmstart；求解器仍为PyVRP0.14.0默认ILS。','标准CVRP，不固定路线数：num_available=客户数；文件名k、目录k、reference路线数仅作审计元数据。距离逐边EUC2D取整，单仓必访闭合、容量约束、固定车费0。','',f"历史1s有效{summary['historical1s_valid_calls']}/36，新5s有效{summary['new5s_valid_calls']}/36，完整配对任务{summary['paired_complete_tasks']}/12。",'主值：先各题3seed成本均值计算reference gap，再12题等权。',f"历史1s平均gap：{summary['historical1s_all12_mean_reference_gap_percent']}%；新5s：{summary['new5s_all12_mean_reference_gap_percent']}%。",f"5s减历史1s：{summary['all12_new5s_minus_historical1s_gap_pp']}个百分点；减少量：{summary['all12_historical1s_minus_new5s_reduction_pp']}个百分点。",f"同题同seed变化：{summary['paired_seed_outcomes']}。",f"达到reference（严格等于）：{summary['reference_equality_counts']}；低于reference另列：{summary['below_reference_counts']}。"]
    for b in summary['bands']:lines.append(f"规模带{b['band']}：历史1s gap={b['historical1s_mean_gap_percent']}%，新5s gap={b['new5s_mean_gap_percent']}%，差={b['new_minus_historical_gap_pp']}个百分点，完整{b['paired_complete_tasks']}/3题。")
    lines+=['','解释边界：','- 两档在不同时间段运行，预算与时段/机器负载因素混在一起；这是描述性对照，不能将全部变化归因预算。','- fresh5s与旧1s不是同条轨迹延长；不预设逐seed单调改善。','- 任一档任一seed缺失/无效，该题均值不可用；任一题不齐则全12主差值null。全部72seed槽、36配对槽、12任务槽保留。','- reference为可行见证，不因gap0而宣称证明最优；无TSR大X对照、不声称统计显著、通用性、SOTA、等算力或速度优势。','- MaxRuntime5s是首ILS停止回调开始的计时，导入、模型构建和初始化不包括；迭代边界可超时。整个solve、build、进程墙时和CPU实测分别保留在逐seed表。','- 每child15CPU/25wall/1536MiB AS；主管30CPU/1050wall、AS软512/硬1536；外层1110wall。配置CPU限额和570s、并存软AS2048MiB/理论硬AS3072MiB不是实耗或严格上界，外层及前后处理另计。','- 无调参、补跑、换题、reference warmstart、新安装、模型调用或费用。原始输出先私有归档实际下载同字节验证，再评分。','- 依赖精确引用environment/RESTORE_MANIFEST.json所列旧私有wheel包，恢复需另取，未重复上传依赖字节。','- 两个受阻交接索引未修改，也未创建替代索引。','报告待独立最终审核。']
    (ROOT/'reports/REPORT_ZH.txt').write_text('\n'.join(lines)+'\n')
    print(json.dumps(summary,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
