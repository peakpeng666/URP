#!/usr/bin/env python3
"""Read-only source/input/history differential audit. Never imports a solver."""
import ast,copy,hashlib,json
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1]
OLD=Path('/workspace/shared/public_route_larger_X_20261009')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def ast_fn(path,name):return next(n for n in ast.parse(path.read_text()).body if isinstance(n,ast.FunctionDef) and n.name==name)
def normal_run(n):
    n=copy.deepcopy(n)
    found=0
    for d in ast.walk(n):
        if isinstance(d,ast.Dict):
            for i,k in enumerate(d.keys):
                if isinstance(k,ast.Constant) and k.value=='limit_semantics':
                    assert isinstance(d.values[i],ast.Constant) and isinstance(d.values[i].value,str)
                    d.values[i]=ast.Constant(value='RESOURCE_TIMER_DIAGNOSTIC_ONLY');found+=1
    assert found==1
    return ast.dump(n,include_attributes=False)
def audit():
    checks={}; details={}
    def ck(label,value):checks[label]=bool(value)
    baseline=read(ROOT/'independent_review/HISTORICAL_BASELINE_AT_AUDIT_START.json')
    oldfiles={str(p.relative_to(OLD)) for p in OLD.rglob('*') if p.is_file()}
    ck('historical_original_file_set_unchanged',oldfiles==set(baseline['files']))
    ck('historical_original_280_files_unchanged',all((OLD/r).stat().st_size==m['bytes'] and digest(OLD/r)==m['sha256'] for r,m in baseline['files'].items()))
    hist=ROOT/'history/baseline_1s'; histfiles={str(p.relative_to(hist)) for p in hist.rglob('*') if p.is_file()}
    copied_expected={r for r in oldfiles if '__pycache__' not in Path(r).parts and not r.endswith('.pyc')}
    ck('historical_copy_exact_noncache_file_set',histfiles==copied_expected)
    ck('full_historical_copy_byte_identical',all((hist/r).read_bytes()==(OLD/r).read_bytes() for r in copied_expected))
    for folder in ('input','references','environment','evidence'):
        a={str(p.relative_to(OLD/folder)) for p in (OLD/folder).rglob('*') if p.is_file()};b={str(p.relative_to(ROOT/folder)) for p in (ROOT/folder).rglob('*') if p.is_file()}
        ck(folder+'_exact_file_set',a==b)
        ck(folder+'_same_bytes',all((OLD/folder/r).read_bytes()==(ROOT/folder/r).read_bytes() for r in a))
    for rel in ['freeze/SELECTED_PANEL.json','freeze/TASKS.json','freeze/SELECTION_RULE.json','independent_review/INPUT_MATRIX_AUDIT.json','independent_review/independent_validator.py']:
        ck('same_bytes:'+rel,(OLD/rel).read_bytes()==(ROOT/rel).read_bytes())
    for fn in ('build_model','extract_routes'):
        ck('worker_AST_identical:'+fn,ast.dump(ast_fn(OLD/'source/worker.py',fn),include_attributes=False)==ast.dump(ast_fn(ROOT/'source/worker.py',fn),include_attributes=False))
    ck('worker_run_AST_identical_except_diagnostic',normal_run(ast_fn(OLD/'source/worker.py','run'))==normal_run(ast_fn(ROOT/'source/worker.py','run')))
    a=read(OLD/'freeze/SCHEDULE.json');b=read(ROOT/'freeze/SCHEDULE.json')
    expected=[dict(e,max_runtime_seconds=5.0) for e in a]
    ck('36_old_slots_only_runtime_differs',len(b)==36 and b==expected)
    ck('36_unique_sequential_seeds012',len({e['call_id'] for e in b})==36 and [e['seed'] for e in b]==[0,1,2]*12)
    tasks=read(ROOT/'freeze/TASKS.json');panel=read(ROOT/'freeze/SELECTED_PANEL.json')
    ck('12_original_selected_tasks',len(tasks)==12 and len({t['instance_id'] for t in tasks})==12)
    ck('all12_fleet_n_clients',all(t['K']==t['K_solver']==t['n_customers'] for t in tasks))
    for t in tasks:
        p=read(ROOT/'input'/f"{t['instance_id']}.json")
        ck('fleet_and_solver_only_payload:'+t['instance_id'],p['K']==len(p['demands'])-1==t['n_customers'] and set(p)=={'instance_id','coordinates','demands','capacity','K'})
    allowed={
      'worker.py':[("'limit_semantics':'1s is ILS stop criterion, not full-process limit; 10s CPU and 20s external wall cap.'","'limit_semantics':'5s starts at first ILS stop callback, excludes initialization and can overshoot at iteration boundary; not full-process limit; 15s CPU and25s external wall guard.'"),('(10,10)','(15,15)')],
      'run_once.py':[('timeout=20','timeout=25'),('signal.alarm(900)','signal.alarm(1050)'),('one frozen36-call standard-X PyVRP benchmark; no retry','one frozen36-call standard-X PyVRP5s extension; no retry'),("e['max_runtime_seconds']==1.0","e['max_runtime_seconds']==5.0")],
      'execute_and_seal.py':[('timeout=960','timeout=1110')],
    }
    for name,replacements in allowed.items():
        source=(OLD/'source'/name).read_text()
        for a,b in replacements:source=source.replace(a,b)
        ck('source_only_authorized_changes:'+name,source==(ROOT/'source'/name).read_text())
    for name in ['common.py','synthetic_fault_worker.py','package.py']:
        ck('unchanged_support:'+name,(OLD/'source'/name).read_bytes()==(ROOT/'source'/name).read_bytes())
    p=read(ROOT/'freeze/PROTOCOL.json');budget=p['budget']
    wanted={'child_CPU_seconds':15,'child_wall_seconds':25,'child_AS_MiB':1536,'supervisor_CPU_seconds':30,'supervisor_wall_seconds':1050,'supervisor_AS_soft_MiB':512,'supervisor_AS_hard_MiB':1536,'outer_wall_seconds':1110,'max_concurrent_children':1,'sum_configured_CPU_limits_seconds':570,'combined_current_soft_AS_MiB':2048,'combined_theoretical_hard_AS_MiB':3072}
    ck('protocol_resource_limits',all(budget[k]==v for k,v in wanted.items()))
    ck('protocol_timer_init_and_overshoot_disclosed',all(s in budget['stop'] for s in ['first ILS stopping callback','initialization excluded','iteration boundaries can overshoot']))
    ck('historical_cross_period_and_no_monotonicity_limits',all(any(s in line for line in p['limitations']) for s in ['different time periods','not randomized','guarantee monotonic','No general-CVRP']))
    ck('missingness_explicit_for_either_budget','either budget' in p['primary']['missing'] and 'null' in p['primary']['missing'])
    matrix=read(ROOT/'independent_review/INPUT_MATRIX_AUDIT.json')
    ck('reused_original_input_matrix_audit_passed',matrix['valid'] and len(matrix['rows'])==12 and all(r['valid'] for r in matrix['rows']))
    receipt=read(ROOT/'provenance/HISTORICAL_FINAL_READBACK.json');r=receipt['receipt']
    ck('historical_receipt_bound',digest(Path(receipt['source_receipt']))==receipt['receipt_sha256'])
    ck('historical_archive_actual_bytes_match',Path(r['source']).read_bytes()==Path(r['download_path']).read_bytes() and digest(Path(r['source']))==r['sha256']==r['download_sha256'])
    ck('historical_private_readback_receipt',r['owner_only'] and not r['shared'] and r['remote_readback_sha256_verified'] and r['download_byte_identical'])
    signed=[p for p in (ROOT/'source').glob('*.py')]+[ROOT/'freeze'/n for n in ['PROTOCOL.json','SCHEDULE.json','TASKS.json','SELECTED_PANEL.json']]
    return {'utc':datetime.now(timezone.utc).isoformat(),'status':'PASS' if all(checks.values()) else 'FAIL','checks':checks,'errors':[k for k,v in checks.items() if not v],'historical_file_count':len(oldfiles),'solver_calls':0,'public_optimization_performed':False,'matrix_reuse_basis':'Same original and normalized inputs, same adapter build_model AST, same environment, identical historical full-matrix audit. No extra full matrix construction or optimization.','scope':'Static source, existing-artifact and protocol differential review. Synthetic runtime and missingness tests separately recorded; this is not execution approval.','examined_source_hashes':{str(p.relative_to(ROOT)):digest(p) for p in signed}}
if __name__=='__main__':
    r=audit();print(json.dumps(r,ensure_ascii=False,indent=2));raise SystemExit(r['status']!='PASS')
