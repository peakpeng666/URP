#!/usr/bin/env python3
"""Independent original-VRP saved-route audit and exact 1s/5s comparison.

No solver import, optimization, repair, replacement, or trajectory extrapolation.
Each planned slot remains present even if unavailable. Published witnesses are
recomputed from original .sol/.vrp. Decimal80 individual rounded edges are reused
from the independently tested historical validator, never from solver matrices.
"""
from pathlib import Path
from collections import Counter,defaultdict
from fractions import Fraction
from datetime import datetime,timezone
import csv,hashlib,json,math,zipfile,io
from audit_large_x_inputs import parse_original,parse_reference
from independent_validator import validate_solution
ROOT=Path(__file__).resolve().parents[1]
def read(p):return json.loads(p.read_text())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def exact(v):return None if v is None else {'numerator':v.numerator,'denominator':v.denominator,'float':float(v)}
def near(a,b):return a is None and b is None or a is not None and b is not None and math.isclose(float(a),float(b),rel_tol=1e-12,abs_tol=1e-9)
def lines(p):return [json.loads(s) for s in p.read_text().splitlines() if s.strip()] if p.exists() else []
def audit_panel(root,budget):
    tasks=read(root/'freeze/TASKS.json');schedule=read(root/'freeze/SCHEDULE.json');records=lines(root/'raw/results.jsonl')
    assert len(tasks)==12 and len(schedule)==36
    assert len({r['call_id'] for r in records})==len(records)
    assert {r['call_id'] for r in records}<={e['call_id'] for e in schedule}
    byid={r['call_id']:r for r in records};problems={};refs={};calls=[];taskstats=[]
    matrix={x['instance_id']:x['matrix_sha256'] for x in read(ROOT/'independent_review/INPUT_MATRIX_AUDIT.json')['rows']}
    for t in tasks:
        name=t['instance_id'];p=parse_original((root/'input'/f'{name}.vrp').read_text(),name)
        assert p['K']==t['K']==t['K_solver']==t['n_customers']==len(p['demands'])-1
        rr,c=parse_reference((root/'references'/f'{name}.sol').read_text());v=validate_solution(p,rr,c)
        assert v['valid'] and v['reported_cost_checked'] and v['reported_cost_matches']
        problems[name]=p;refs[name]=v
    for e in schedule:
        errors=[];v=None;a=None;r=byid.get(e['call_id']);name=e['instance_id']
        assert e['max_runtime_seconds']==budget
        if r is None:errors.append('MISSING_RECORD')
        elif r['status']!='UNREVIEWED_PROCESS_SUCCESS':errors.append(r['status'])
        else:
            if not all(r[k]==val for k,val in e.items()):errors.append('RECORD_SCHEDULE_MISMATCH')
            if not(r['process_spawned'] and r['child_reaped'] and r['returncode']==0):errors.append('PROCESS_NOT_COMPLETE')
            for stream in ('stdout','stderr'):
                if not(root/r[stream]).is_file() or digest(root/r[stream])!=r[stream+'_sha256']:errors.append('STREAM_HASH:'+stream)
            if not errors:
                try:
                    a=read(root/r['stdout']);v=validate_solution(problems[name],a['routes'],a['reported_cost'])
                    if not(v['valid'] and v['reported_cost_checked'] and v['reported_cost_matches']):errors.append('INDEPENDENT_ROUTE_INVALID')
                    if not(a['seed']==e['seed'] and a['max_runtime_seconds']==budget and a['version']=='0.14.0' and a['algorithm']=='ILS' and a['solver']=='PyVRP'):errors.append('SOLVER_IDENTITY')
                    if not(a['solver_is_feasible'] and a['solver_is_complete'] and a['reported_cost']==a['reported_distance']==a['internal_route_cost']==v['cost'] and a['reported_duration_cost']==a['reported_fixed_vehicle_cost']==0):errors.append('OBJECTIVE_OR_FEASIBILITY')
                    if a['reported_num_routes']!=v['nonempty_routes']:errors.append('ROUTE_COUNT')
                    expected={'inherited':{'AS_bytes':[512*1024**2,1536*1024**2],'CPU_seconds':[30,30]},'effective':{'AS_bytes':[1536*1024**2,1536*1024**2],'CPU_seconds':[10,10] if budget==1 else [15,15]}}
                    if a['resource_limits']!=expected:errors.append('RESOURCE_LIMITS')
                    if a['model_matrix_sha256']!=matrix[name]:errors.append('MATRIX_HASH')
                    if a['denied_io_events'] or a['reference_or_history_payload_fields']:errors.append('REFERENCE_ISOLATION')
                    normalized=read(root/'input'/f'{name}.json');payload={k:normalized[k] for k in ('coordinates','demands','capacity','K')};payload.update(seed=e['seed'],max_runtime_seconds=e['max_runtime_seconds'])
                    if hashlib.sha256(json.dumps(payload,separators=(',',':')).encode()).hexdigest()!=r['payload_sha256']:errors.append('REFERENCE_FREE_PAYLOAD_HASH')
                    native_good=len(a['native_routes'])==len(a['routes'])
                    for j,(route,native) in enumerate(zip(a['routes'],a['native_routes'])):
                        native_good &= native['distance']==v['route_costs'][j] and native['delivery']==[v['loads'][j]] and native['vehicle_type']==0 and native['start_depot']==native['end_depot']==0 and native['num_trips']==1 and native['is_feasible']
                        native_good &= [z['node'] for z in native['activities']]==route
                        for pos,z in enumerate(native['activities']):
                            native_good &= z['node']==z['location'] and ((z['type']=='DEPOT' and z['idx']==z['node']==0) if pos in (0,len(native['activities'])-1) else (z['type']=='CLIENT' and z['idx']+1==z['node']))
                    if not native_good:errors.append('NATIVE_MAPPING')
                except Exception as exc:errors.append(type(exc).__name__+': '+str(exc))
        valid=not errors
        calls.append({**e,'valid':valid,'errors':errors,'validation':v,'cost':v['cost'] if valid else None,'reference_cost':refs[name]['cost'],'reference_equal':valid and v['cost']==refs[name]['cost'],'below_reference':valid and v['cost']<refs[name]['cost'],'process_cpu_seconds':r.get('cpu_seconds_audit_only') if r else None,'process_wall_seconds':r.get('wall_seconds_audit_only') if r else None,'solve_wall_seconds':a.get('solve_wall_seconds_audit_only') if a else None,'build_wall_seconds':a.get('build_wall_seconds_audit_only') if a else None,'solver_loop_runtime':a.get('solver_loop_runtime') if a else None})
    for t in tasks:
        name=t['instance_id'];cs=[c for c in calls if c['instance_id']==name];assert [c['seed'] for c in cs]==[0,1,2]
        valid=[c['cost'] for c in cs if c['valid']];mean=Fraction(sum(valid),3) if len(valid)==3 else None;gap=100*(mean-refs[name]['cost'])/refs[name]['cost'] if mean is not None else None
        taskstats.append({'instance_id':name,'band':t['band'],'costs_seed012':[c['cost'] for c in cs],'valid_seed_count':len(valid),'reference_cost':refs[name]['cost'],'mean3':mean,'gap':gap,'best3':min(valid) if len(valid)==3 else None,'range3':max(valid)-min(valid) if len(valid)==3 else None})
    gaps=[t['gap'] for t in taskstats if t['gap'] is not None]
    return {'budget':budget,'planned_calls':36,'valid_calls':sum(c['valid'] for c in calls),'complete_tasks':len(gaps),'all12':sum(gaps)/12 if len(gaps)==12 else None,'available_complete_mean':sum(gaps)/len(gaps) if gaps else None,'reference_equal':sum(c['reference_equal'] for c in calls),'below_reference':sum(c['below_reference'] for c in calls),'calls':calls,'tasks':taskstats,'reference_validations':refs}
def serial_panel(p):
    return {**p,'all12':exact(p['all12']),'available_complete_mean':exact(p['available_complete_mean']),'tasks':[{**t,'mean3':exact(t['mean3']),'gap':exact(t['gap'])} for t in p['tasks']]}
def compare(old,new):
    pairs=[];counts=Counter();deltas=[]
    for a,b in zip(old['calls'],new['calls']):
        assert (a['instance_id'],a['seed'])==(b['instance_id'],b['seed'])
        valid=a['valid'] and b['valid'];d=b['cost']-a['cost'] if valid else None;label='unavailable' if not valid else 'improved' if d<0 else 'equal' if d==0 else 'worse';counts[label]+=1
        pairs.append({'instance_id':a['instance_id'],'seed':a['seed'],'old_cost':a['cost'],'new_cost':b['cost'],'new_minus_old_cost':d,'outcome':label})
    taskpairs=[]
    for a,b in zip(old['tasks'],new['tasks']):
        assert a['instance_id']==b['instance_id'];d=b['gap']-a['gap'] if a['gap'] is not None and b['gap'] is not None else None
        if d is not None:deltas.append(d)
        taskpairs.append({'instance_id':a['instance_id'],'band':a['band'],'old_gap':exact(a['gap']),'new_gap':exact(b['gap']),'new_minus_old_pp':exact(d)})
    primary=sum(deltas)/12 if len(deltas)==12 else None
    return {'seed_outcomes':{k:counts[k] for k in ['improved','equal','worse','unavailable']},'complete_paired_tasks':len(deltas),'all12_new_minus_old_pp':exact(primary),'all12_old_minus_new_reduction_pp':exact(-primary if primary is not None else None),'available_complete_paired_difference_pp':exact(sum(deltas)/len(deltas) if deltas else None),'seed_pairs':pairs,'task_pairs':taskpairs}
def review_evidence(old,new,comparison):
    checks={}
    def ck(label,value):checks[label]=bool(value)
    def csvrows(name):return list(csv.DictReader((ROOT/'reports'/name).open()))
    frozen=read(ROOT/'freeze/FROZEN_FILES.json');frozenhash=digest(ROOT/'freeze/FROZEN_FILES.json')
    for rel,m in frozen['files'].items():ck('frozen:'+rel,digest(ROOT/rel)==m['sha256'] and (ROOT/rel).stat().st_size==m['bytes'])
    precheck=read(ROOT/'freeze/INDEPENDENT_PRECHECK.json');ck('precheck_PASS',precheck['status']=='PASS')
    for rel,m in precheck['signed_files'].items():ck('prechecked:'+rel,digest(ROOT/rel)==m['sha256'] and (ROOT/rel).stat().st_size==m['bytes'])
    snapshot=read(ROOT/'independent_review/HISTORICAL_BASELINE_AT_AUDIT_START.json');original=Path(snapshot['root'])
    ck('old_original_file_set',set(snapshot['files'])=={str(p.relative_to(original)) for p in original.rglob('*') if p.is_file()})
    ck('old_all280_original_hashes',all(digest(original/rel)==m['sha256'] and (original/rel).stat().st_size==m['bytes'] for rel,m in snapshot['files'].items()))
    manifest=read(ROOT/'raw/RAW_UNREVIEWED_MANIFEST.json')
    ck('raw_exact_file_set',{str(p.relative_to(ROOT)) for p in (ROOT/'raw').rglob('*') if p.is_file()}==set(manifest['files'])|{'raw/RAW_UNREVIEWED_MANIFEST.json'})
    for stage in ['PREEXEC','RAW_UNREVIEWED']:
        r=read(ROOT/'provenance'/f'{stage}_DRIVE_RECEIPT.json');data=Path(r['download_path']).read_bytes()
        ck('private_readback:'+stage,r['owner_only'] and not r['shared'] and r['remote_readback_sha256_verified'] and r['download_byte_identical'] and data==Path(r['source']).read_bytes() and hashlib.sha256(data).hexdigest()==r['sha256']==r['download_sha256'])
        ck('archive_freeze_binding:'+stage,r['frozen_files_sha256']==frozenhash)
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            prefix=ROOT.name+'/'
            ck('zip_unique:'+stage,len(z.namelist())==len(set(z.namelist())))
            ck('zip_freeze:'+stage,z.read(prefix+'freeze/FROZEN_FILES.json')==(ROOT/'freeze/FROZEN_FILES.json').read_bytes())
            ck('zip_all_frozen:'+stage,all(hashlib.sha256(z.read(prefix+rel)).hexdigest()==m['sha256'] for rel,m in frozen['files'].items()))
            if stage=='PREEXEC':ck('PREEXEC_no_new_raw',not any(n.startswith(prefix+'raw/') for n in z.namelist()))
            else:ck('RAW_all_members_match',all(z.read(prefix+rel)==(ROOT/rel).read_bytes() for rel in manifest['files']))
    approval=read(ROOT/'provenance/PARENT_EXECUTION_APPROVAL.json');begin=read(ROOT/'raw/STARTED.json');finish=read(ROOT/'raw/FINISHED.json');outer=read(ROOT/'raw/EXECUTOR_FINISHED.json')
    ck('approval_scope',approval['approved'] and approval['scope']=='one frozen36-call standard-X PyVRP5s extension; no retry')
    ck('approval_hash_bound',approval['frozen_files_sha256']==begin['freeze_sha256']==finish['freeze_sha256_after']==frozenhash and begin['approval_sha256']==digest(ROOT/'provenance/PARENT_EXECUTION_APPROVAL.json') and approval['preexec_archive_sha256']==read(ROOT/'provenance/PREEXEC_DRIVE_RECEIPT.json')['sha256'])
    ck('completed_once',begin['no_retries'] and finish['planned_calls']==finish['retained_calls']==finish['spawned_calls']==36 and outer['supervisor_returncode']==0 and not outer['external_timeout'] and outer['launcher_error'] is None and outer['process_group_kill_attempt_completed_before_seal'])
    schedule=read(ROOT/'freeze/SCHEDULE.json');records=lines(ROOT/'raw/results.jsonl');attempts=lines(ROOT/'raw/attempts.jsonl')
    ck('exact36_ordered_results',[r['call_id'] for r in records]==[e['call_id'] for e in schedule])
    ck('exact72_attempt_phases',[(a['call_id'],a['phase']) for a in attempts]==[(e['call_id'],p) for e in schedule for p in ['STARTED','FINISHED']])
    ck('one_child_at_a_time',all(attempts[i]['utc']<=attempts[i+1]['utc'] for i in range(len(attempts)-1)))
    expected={'AS_bytes':[512*1024**2,1536*1024**2],'CPU_seconds':[30,30]}
    ck('supervisor_limits',begin['supervisor_limits']==finish['supervisor_effective_limits']==expected)
    ck('realized_guard_bounds',finish['supervisor_cpu_seconds_audit_only']<30 and finish['wall_seconds_audit_only']<1050 and outer['wall_seconds_audit_only']<1110 and all(c['process_cpu_seconds']<15 and c['process_wall_seconds']<25 for c in new['calls']))
    summary=read(ROOT/'reports/COMPARISON_SUMMARY.json')
    for key,value in [('historical1s_valid_calls',old['valid_calls']),('new5s_valid_calls',new['valid_calls']),('historical1s_complete_tasks',old['complete_tasks']),('new5s_complete_tasks',new['complete_tasks']),('paired_complete_tasks',comparison['complete_paired_tasks']),('available_paired_complete_task_denominator',comparison['complete_paired_tasks'])]:ck('comparison_summary:'+key,summary[key]==value)
    for key,value in [('historical1s_all12_mean_reference_gap_percent',old['all12']),('new5s_all12_mean_reference_gap_percent',new['all12']),('all12_new5s_minus_historical1s_gap_pp',new['all12']-old['all12'] if old['all12'] is not None and new['all12'] is not None else None)]:ck('comparison_exact:'+key,near(summary[key],value))
    ck('comparison_opposite_sign_reduction',near(summary['all12_historical1s_minus_new5s_reduction_pp'],old['all12']-new['all12'] if old['all12'] is not None and new['all12'] is not None else None))
    ck('paired_outcomes',summary['paired_seed_outcomes']=={k.upper():v for k,v in comparison['seed_outcomes'].items()})
    ck('exact_reference_equality',summary['reference_equality_counts']=={'historical1s':old['reference_equal'],'new5s':new['reference_equal']})
    ck('below_reference_separate',summary['below_reference_counts']=={'historical1s':old['below_reference'],'new5s':new['below_reference']})
    both=csvrows('BOTH_BUDGETS_PER_SEED.csv');paired=csvrows('PAIRED_SEED_CHANGES.csv');taskrows=csvrows('COMPARISON_PER_INSTANCE.csv')
    ck('tables_retain72_36_12',len(both)==72 and len(paired)==36 and len(taskrows)==12)
    for row,c in zip(both,old['calls']+new['calls']):ck('both_seed:'+row['budget_role']+':'+c['call_id'],row['instance_id']==c['instance_id'] and int(row['seed'])==c['seed'] and (int(row['cost']) if row['cost'] else None)==c['cost'] and row['status']==('VALID' if c['valid'] else 'UNAVAILABLE'))
    for row,c in zip(paired,comparison['seed_pairs']):ck('pair:'+c['instance_id']+':'+str(c['seed']),row['instance_id']==c['instance_id'] and int(row['seed'])==c['seed'] and row['outcome']==c['outcome'].upper() and (int(row['new_minus_historical_cost']) if row['new_minus_historical_cost'] else None)==c['new_minus_old_cost'])
    for row,a,b in zip(taskrows,old['tasks'],new['tasks']):
        ck('comparison_task:'+a['instance_id'],row['instance_id']==a['instance_id'] and near(row['historical1s_mean3_cost'] or None,a['mean3']) and near(row['new5s_mean3_cost'] or None,b['mean3']) and near(row['historical1s_mean3_gap_percent'] or None,a['gap']) and near(row['new5s_mean3_gap_percent'] or None,b['gap']) and near(row['new5s_minus_historical1s_gap_pp'] or None,b['gap']-a['gap'] if b['gap'] is not None and a['gap'] is not None else None))
    for band in range(1,5):
        a=[t['gap'] for t in old['tasks'] if t['band']==band];b=[t['gap'] for t in new['tasks'] if t['band']==band];row=summary['bands'][band-1]
        oa=sum(a)/3 if all(x is not None for x in a) else None;nb=sum(b)/3 if all(x is not None for x in b) else None
        ck('band:'+str(band),near(row['historical1s_mean_gap_percent'],oa) and near(row['new5s_mean_gap_percent'],nb) and near(row['new_minus_historical_gap_pp'],nb-oa if nb is not None and oa is not None else None))
    summary5=read(ROOT/'reports/SUMMARY.json');ck('new5s_summary_matches',near(summary5['all12_mean_reference_gap_percent'],new['all12']) and summary5['valid_calls']==new['valid_calls'] and summary5['complete_three_seed_tasks']==new['complete_tasks'])
    ck('comparison_claim_limits',summary['no_monotonicity_assumption'] and summary['no_causal_budget_only_claim'] and summary['no_equal_compute_or_speed_claim'] and summary['optimizer_rerun'] is False)
    narrative=(ROOT/'reports/REPORT_ZH.txt').read_text()
    ck('narrative_limits',all(x in narrative for x in ['跨时段历史','不预设逐seed单调','迭代边界可超时','无TSR大X对照','全部72seed槽','15CPU/25wall','1050wall','1110wall','570s']))
    return checks

def audit():
    # No endpoint scoring before actual raw receipt and hashes are available.
    receipt=read(ROOT/'provenance/RAW_UNREVIEWED_DRIVE_RECEIPT.json')
    assert receipt['owner_only'] and not receipt['shared'] and receipt['remote_readback_sha256_verified'] and receipt['download_byte_identical']
    assert digest(Path(receipt['source']))==digest(Path(receipt['download_path']))==receipt['sha256']==receipt['download_sha256']
    manifest=read(ROOT/'raw/RAW_UNREVIEWED_MANIFEST.json')
    assert all(digest(ROOT/p)==m['sha256'] and (ROOT/p).stat().st_size==m['bytes'] for p,m in manifest['files'].items())
    old=audit_panel(ROOT/'history/baseline_1s',1.0);new=audit_panel(ROOT,5.0);comparison=compare(old,new);checks=review_evidence(old,new,comparison)
    return {'utc':datetime.now(timezone.utc).isoformat(),'status':'PASS' if all(checks.values()) else 'FAIL','checks':checks,'errors':[k for k,v in checks.items() if not v],'scope':'Original-VRP independent recomputation of72 saved routes and24 reference witnesses; no optimization rerun','historical':serial_panel(old),'new':serial_panel(new),'comparison':comparison}
if __name__=='__main__':
    result=audit();print(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False))
