"""Invented VRPLIB+JSON-only comparison tests. No optimizer, no real raw mutation."""
from pathlib import Path
import contextlib,csv,hashlib,importlib.util,io,json,sys,tempfile,unittest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'source'))
import compare_budget as report

def write(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x))
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def fixture(base,budget,mode='complete',weak_reference=False):
    tasks=[];schedule=[];records=[]
    for i in range(12):
        name=f'INVENTED_THREE_NODE_{i}';eligible=not(mode=='ineligible' and i==0)
        tasks.append({'instance_id':name,'selection_slot':i+1,'band':i//3+1,'n_customers':2,'K':2,'K_solver':2,'eligible':eligible})
        text=f'NAME : {name}\nTYPE : CVRP\nDIMENSION : 3\nEDGE_WEIGHT_TYPE : EUC_2D\nCAPACITY : 2\nNODE_COORD_SECTION\n1 0 0\n2 1 0\n3 2 0\nDEMAND_SECTION\n1 0\n2 1\n3 1\nDEPOT_SECTION\n1\n-1\nEOF\n'
        path=base/'input'/f'{name}.vrp';path.parent.mkdir(parents=True,exist_ok=True);path.write_text(text)
        write(base/'input'/f'{name}.json',{'instance_id':name,'coordinates':[[0,0],[1,0],[2,0]],'demands':[0,1,1],'capacity':2,'K':2})
        write(base/'references'/f'{name}.json',{'reference_routes':[[1],[2]] if weak_reference else [[1,2]],'reference_integer_cost':6 if weak_reference else 4,'K_solver':2})
        for seed in range(3):
            cid=f'F{i+1}_s{seed}';e={'call_id':cid,'instance_id':name,'selection_slot':i+1,'seed':seed,'max_runtime_seconds':budget};schedule.append(e)
            if mode=='missing' and i==0 and seed==1:continue
            joint=(seed==0 if budget==1 else seed==2);routes=[[0,1,2,0]] if joint else [[0,1,0],[0,2,0]];cost=4 if joint else 6
            a={'routes':routes,'reported_cost':cost+1 if mode=='bad_cost' and i==0 and seed==1 else cost,'reported_distance':cost,'reported_fixed_vehicle_cost':0,'reported_duration_cost':0,'solver_is_complete':True,'solver_is_feasible':True,'seed':seed,'max_runtime_seconds':budget,'version':'0.14.0','resource_limits':{'inherited':{'AS_bytes':[512*1024**2,1536*1024**2],'CPU_seconds':[30,30]},'effective':{'AS_bytes':[1536*1024**2,1536*1024**2],'CPU_seconds':[10,10] if budget==1 else [15,15]}},'denied_io_events':[],'reference_or_history_payload_fields':[]}
            out=base/'raw/calls'/f'{cid}.stdout';err=base/'raw/calls'/f'{cid}.stderr';write(out,a);err.write_text('')
            r={**e,'status':'SKIPPED_INELIGIBLE_INPUT' if not eligible else 'UNREVIEWED_PROCESS_SUCCESS','process_spawned':eligible,'stdout':str(out.relative_to(base)),'stderr':str(err.relative_to(base)),'stdout_sha256':digest(out),'stderr_sha256':digest(err)}
            if i==0 and seed==1:
                if mode=='malformed':out.write_text('{broken');r['stdout_sha256']=digest(out)
                if mode=='missing_file':out.unlink()
                if mode=='hash_mismatch':out.write_text(out.read_text()+'\n')
                if mode=='failure':r['status']='WALL_TIMEOUT'
                if mode=='duplicate':records.append(r.copy())
            records.append(r)
    write(base/'freeze/TASKS.json',tasks);write(base/'freeze/SCHEDULE.json',schedule)
    path=base/'raw/results.jsonl';path.parent.mkdir(parents=True,exist_ok=True);path.write_text(''.join(json.dumps(r)+'\n' for r in records))
    return tasks

class ComparisonMissingnessTests(unittest.TestCase):
    def exercise(self,oldmode='complete',newmode='complete',weak=False):
        with tempfile.TemporaryDirectory(prefix='invented_compare_',dir=ROOT/'independent_review') as temp:
            root=Path(temp);old=root/'old';new=root/'new';tasks=fixture(old,1.0,oldmode,weak);fixture(new,5.0,newmode,weak)
            a,va,ra=report.evaluate_budget(old,1.0,10);b,vb,rb=report.evaluate_budget(new,5.0,15)
            s,p,t=report.summarize(a,b,tasks)
            self.assertEqual(len(a),36);self.assertEqual(len(b),36);self.assertEqual(len(p),36);self.assertEqual(len(t),12)
            self.assertEqual(s['planned_calls_each_budget'],36);self.assertEqual(s['planned_tasks'],12)
            for label,mode,rows in [('historical1s',oldmode,a),('new5s',newmode,b)]:
                want=36 if mode=='complete' else 33 if mode=='ineligible' else 35
                self.assertEqual(s[label+'_valid_calls'],want)
                if mode!='complete':
                    self.assertIsNone(s[label+'_all12_mean_reference_gap_percent']);self.assertIsNone(t[0][label+'_mean3_cost'])
                    for row in rows:
                        if row['status']=='UNAVAILABLE':self.assertIsNone(row['cost']);self.assertIsNone(row['gap_percent'])
            if oldmode==newmode=='complete':
                self.assertEqual(s['paired_complete_tasks'],12);self.assertEqual(s['all12_new5s_minus_historical1s_gap_pp'],0)
                self.assertEqual(s['paired_seed_outcomes'],{'IMPROVED':12,'EQUAL':12,'WORSE':12,'UNAVAILABLE':0})
                self.assertEqual(s['reference_equality_counts'],{'historical1s':24 if weak else 12,'new5s':24 if weak else 12})
                self.assertEqual(s['below_reference_counts'],{'historical1s':12 if weak else 0,'new5s':12 if weak else 0})
            else:
                self.assertEqual(s['paired_complete_tasks'],11);self.assertEqual(s['available_paired_complete_task_denominator'],11)
                self.assertIsNone(s['all12_new5s_minus_historical1s_gap_pp']);self.assertIsNone(s['all12_historical1s_minus_new5s_reduction_pp'])
                self.assertIsNone(t[0]['new5s_minus_historical1s_gap_pp']);self.assertIsNone(s['bands'][0]['new_minus_historical_gap_pp'])
                self.assertEqual(s['paired_seed_outcomes']['UNAVAILABLE'],3 if 'ineligible' in (oldmode,newmode) else 1)
            self.assertTrue(s['no_monotonicity_assumption']);self.assertTrue(s['no_causal_budget_only_claim']);self.assertFalse(s['optimizer_rerun'])
    def test_complete_preserves_worse_equal_improved(self):self.exercise()
    def test_reference_equality_separate_from_below(self):self.exercise(weak=True)
    def test_new_missing(self):self.exercise(newmode='missing')
    def test_old_missing(self):self.exercise(oldmode='missing')
    def test_new_invalid_cost(self):self.exercise(newmode='bad_cost')
    def test_old_invalid_cost(self):self.exercise(oldmode='bad_cost')
    def test_new_ineligible(self):self.exercise(newmode='ineligible')
    def test_old_ineligible(self):self.exercise(oldmode='ineligible')
    def test_both_ineligible(self):self.exercise(oldmode='ineligible',newmode='ineligible')
    def test_new_malformed(self):self.exercise(newmode='malformed')
    def test_old_malformed(self):self.exercise(oldmode='malformed')
    def test_new_missing_file(self):self.exercise(newmode='missing_file')
    def test_old_missing_file(self):self.exercise(oldmode='missing_file')
    def test_new_failed_call(self):self.exercise(newmode='failure')
    def test_old_failed_call(self):self.exercise(oldmode='failure')
    def test_hash_mismatch(self):self.exercise(newmode='hash_mismatch')
    def test_duplicate_record(self):self.exercise(newmode='duplicate')

if __name__=='__main__':unittest.main(verbosity=2)
