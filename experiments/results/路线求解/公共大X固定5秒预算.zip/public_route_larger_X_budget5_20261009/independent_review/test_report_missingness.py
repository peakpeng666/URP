#!/usr/bin/env python3
"""Lightweight, invented JSON-only tests of production report.main.

The production endpoint evaluator is loaded without execution and pointed to an
isolated TemporaryDirectory. Freeze/cloud receipt/old-file checks are explicit
fixture stubs; no real receipt is manufactured or real evidence mutated. No
solver import, model construction, network call, or public route optimization.
"""
from pathlib import Path
import contextlib
import csv
import hashlib
import importlib.util
import io
import json
import sys
import tempfile
import unittest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'source'))
spec=importlib.util.spec_from_file_location('production_report_under_test',ROOT/'source/report.py')
report=importlib.util.module_from_spec(spec);spec.loader.exec_module(report)


def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x))

class ReportMissingnessTests(unittest.TestCase):
    def exercise(self,mode):
        with tempfile.TemporaryDirectory(prefix='fictional_report_',dir=ROOT/'independent_review') as temp:
            base=Path(temp);(base/'raw/calls').mkdir(parents=True);(base/'reports').mkdir()
            tasks=[];schedule=[];records=[];matrixrows=[]
            for i in range(12):
                name=f'INVENTED_TWO_NODE_{i}'
                eligible=not(mode=='ineligible' and i==0)
                task={'instance_id':name,'selection_slot':i+1,'band':i//3+1,'n_customers':1,'K':1,'K_name_audit_only':1,'K_catalog_audit_only':1,'eligible':eligible}
                tasks.append(task)
                problem={'instance_id':name,'coordinates':[[0,0],[1,0]],'demands':[0,1],'capacity':1,'K':1}
                write(base/'input'/f'{name}.json',problem)
                write(base/'references'/f'{name}.json',{'reference_routes':[[1]],'reference_integer_cost':2,'K_solver':1})
                matrixrows.append({'instance_id':name,'matrix_sha256':'FICTIONAL_MATRIX_HASH','valid':True})
                for seed in range(3):
                    cid=f'F{i+1}_s{seed}'
                    entry={'call_id':cid,'instance_id':name,'selection_slot':i+1,'seed':seed,'max_runtime_seconds':5.0}
                    schedule.append(entry)
                    if mode=='missing' and i==0 and seed==1:continue
                    if not eligible:
                        records.append({**entry,'status':'SKIPPED_INELIGIBLE_INPUT','process_spawned':False});continue
                    answer={'routes':[[0,1,0]],'reported_cost':3 if mode=='invalid' and i==0 and seed==1 else 2,'solver_is_feasible':True,'solver_is_complete':True,'reported_fixed_vehicle_cost':0,'reported_duration_cost':0,'reported_distance':2,'resource_limits':{'inherited':{'AS_bytes':[512*1024**2,1536*1024**2],'CPU_seconds':[30,30]},'effective':{'AS_bytes':[1536*1024**2,1536*1024**2],'CPU_seconds':[15,15]}},'model_matrix_sha256':'FICTIONAL_MATRIX_HASH','denied_io_events':[],'reference_or_history_payload_fields':[],'seed':seed,'max_runtime_seconds':5.0,'version':'0.14.0','native_routes':[{'activities':[{'node':0,'location':0,'type':'DEPOT','idx':0},{'node':1,'location':1,'type':'CLIENT','idx':0},{'node':0,'location':0,'type':'DEPOT','idx':0}],'vehicle_type':0,'num_trips':1}]}
                    out=base/'raw/calls'/f'{cid}.stdout';err=base/'raw/calls'/f'{cid}.stderr'
                    write(out,answer);err.write_text('')
                    records.append({**entry,'status':'UNREVIEWED_PROCESS_SUCCESS','process_spawned':True,'stdout':str(out.relative_to(base)),'stderr':str(err.relative_to(base)),'stdout_sha256':digest(out),'stderr_sha256':digest(err)})
            write(base/'freeze/TASKS.json',tasks);write(base/'freeze/SCHEDULE.json',schedule)
            write(base/'freeze/SELECTION_RULE.json',{'bands':[[1,1]]*4})
            write(base/'freeze/PROTOCOL.json',{'limitations':['FICTIONAL DATA ONLY']})
            write(base/'raw/RAW_UNREVIEWED_MANIFEST.json',{'files':{}})
            write(base/'independent_review/INPUT_MATRIX_AUDIT.json',{'rows':matrixrows})
            (base/'raw/results.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in records))
            report.ROOT=base
            report.read=lambda rel:json.loads((base/rel).read_text())
            report.verify_frozen=lambda: 'FIXTURE_FREEZE_STUB'
            report.receipt=lambda stage: {'fixture_stub':True}
            report.verify_old=lambda:0
            report.comparison_main=lambda:None  # separately exercised by test_compare_budget_missingness.py
            with contextlib.redirect_stdout(io.StringIO()):report.main()
            summary=json.loads((base/'reports/SUMMARY.json').read_text())
            seeds=list(csv.DictReader(io.StringIO((base/'reports/PER_SEED.csv').read_text())))
            instances=list(csv.DictReader(io.StringIO((base/'reports/PER_INSTANCE.csv').read_text())))
            self.assertEqual(len(seeds),36);self.assertEqual(len(instances),12)
            self.assertEqual(summary['planned_calls'],36);self.assertEqual(summary['planned_instances'],12)
            if mode=='complete':
                self.assertEqual(summary['valid_calls'],36)
                self.assertEqual(summary['all12_mean_reference_gap_percent'],0)
                self.assertEqual(summary['descriptive_complete_task_denominator'],12)
            else:
                self.assertIsNone(summary['all12_mean_reference_gap_percent'])
                self.assertEqual(summary['descriptive_complete_task_denominator'],11)
                self.assertEqual(summary['valid_calls'],33 if mode=='ineligible' else 35)
                self.assertEqual(instances[0]['mean3_cost'],'')
                self.assertEqual(instances[0]['best_of3_cost_secondary'],'')
                self.assertEqual(summary['descriptive_bands'][0]['complete_tasks'],2)
                self.assertIsNone(summary['descriptive_bands'][0]['three_task_mean_gap_percent'])
            self.assertFalse(summary['old_TSR_comparator_available'])
            self.assertTrue(summary['cross_panel_difference_cannot_be_attributed_only_to_size'])
            self.assertTrue(summary['no_equal_compute_or_speed_claim'])
    def test_complete_36_seed_slots(self):self.exercise('complete')
    def test_missing_seed_retains_36(self):self.exercise('missing')
    def test_invalid_seed_retains_36(self):self.exercise('invalid')
    def test_ineligible_retains_36(self):self.exercise('ineligible')

if __name__=='__main__':unittest.main(verbosity=2)
