import sys,time,resource,signal,statistics as st,collections,csv,math
sys.dont_write_bytecode=True
resource.setrlimit(resource.RLIMIT_CPU,(10,10));resource.setrlimit(resource.RLIMIT_AS,(256*1024**2,256*1024**2));signal.alarm(10)
C=time.process_time_ns();W=time.perf_counter_ns()
from common import *
assert read(ROOT/'provenance/RAW_ARCHIVE_VERIFIED.json')['verified'] is True
f=verify_freeze();protocol=read(ROOT/'freeze/PROTOCOL.json');schedule=read(ROOT/'freeze/SCHEDULE.json')
def dist(xs):
 if not xs:return None
 q=st.quantiles(xs,n=4,method='inclusive') if len(xs)>1 else [xs[0]]*3
 return {'n':len(xs),'sum':sum(xs),'mean':st.mean(xs),'median':st.median(xs),'min':min(xs),'max':max(xs),'p25':q[0],'p75':q[2],'sd':st.stdev(xs) if len(xs)>1 else 0}
def writecsv(name,rows):
 if rows:
  with (ROOT/'reports'/name).open('x',newline='') as h:
   w=csv.DictWriter(h,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
expected={b['batch_id']+'-'+i+f'-P{r:02d}':(b,i,r) for b in schedule for i in b['instance_order'] for r in range(b['repetitions'])}
seen=collections.Counter();bad=[];drifts=[];invalid=[];mutations=[];derived_errors=[];first={};seconds=collections.defaultdict(list);phasecounts=collections.Counter();signs=collections.defaultdict(set)
for line in (ROOT/'raw/calls.jsonl').open():
 r=json.loads(line);cid=r['call_id'];seen[cid]+=1;phasecounts[r['phase']]+=1
 if cid not in expected:bad.append(cid)
 else:
  b,i,p=expected[cid]
  if (r['instance_id'],r['repetition'],r['phase'],r['round'],r['arm'])!=(i,p,b['phase'],b['round'],b['arm']):bad.append(cid)
 if r['functional_signature']!=r['reference_signature']:drifts.append(cid)
 if r['status']=='SUCCESS' and not r['checker']['accepted']:invalid.append(cid)
 if not r['input_unchanged']:mutations.append(cid)
 r['diagnostic']=r['non_time_diagnostic']
 if signature(r)!=r['functional_signature'] or digest(r['output'])!=r['output_sha256'] or digest(((r['diagnostic'] or{}).get('capacity_partition') or{}).get('prune_trace'))!=r['prune_trace_sha256']:derived_errors.append(cid)
 key=(r['instance_id'],r['arm']);signs[key].add(r['functional_signature'])
 if key not in first:first[key]=r
 if r['phase']=='timed':seconds[(r['instance_id'],r['arm'],r['round'])].append(r['algorithm_wall_ns'])
parts=[json.loads(x) for x in (ROOT/'raw/partitions.jsonl').read_text().splitlines()]
pindex={(r['instance_id'],r['arm']):r for r in parts}
partbad=[r['instance_id']+':'+r['arm'] for r in parts if r['functional_signature']!=r['reference_signature'] or signature(r)!=r['functional_signature'] or not r['input_unchanged'] or not r['assignment_valid']]
ids=sorted({i for i,a in first});inputs={i:read(ROOT/'input'/f'{i}.json') for i in ids}
functional_rows=[];accountingbad=[];tracebad=[]
for i in ids:
 pa=pindex[(i,'waste_solver')];pb=pindex[(i,'cached_solver')]
 for key,field in [('node_trace_sha256','node_trace'),('prune_trace_sha256',None),('assignment_sha256','groups')]:
  if pa[key]!=pb[key]:tracebad.append((i,key))
  for row in (pa,pb):
   value=row['diagnostic']['prune_trace'] if field is None else row[field]
   if digest(value)!=row[key]:tracebad.append((i,key,'recomputed'))
 for endpoint,idx in [('initialize',first),('partition',pindex)]:
  a=idx[(i,'waste_solver')];b=idx[(i,'cached_solver')]
  x=a['diagnostic'];y=b['diagnostic']
  if endpoint=='initialize':x=(x or{}).get('capacity_partition');y=(y or{}).get('capacity_partition')
  if x!=y:accountingbad.append((endpoint,i))
  raw=inputs[i];n=len(raw['demands'])-1
  trace=pa['node_trace'] if x else []
  guard_trace=[t for t in trace if t['depth']<n]
  order=sorted(range(1,len(raw['demands'])),key=lambda j:(-raw['demands'][j],j))
  remaining_items=sum(n-t['depth'] for t in guard_trace)
  min_items=sum(sum(raw['demands'][j]>0 for j in order[t['depth']:]) for t in guard_trace if sum(t['residual'])-sum(raw['demands'][j] for j in order[t['depth']:])>=0)
  positive_items=sum(n-t['depth'] for t in guard_trace if sum(t['residual'])-sum(raw['demands'][j] for j in order[t['depth']:])>=0)
  pruned_materialized=sum(len(t['remaining']) for t in (x or{}).get('prune_trace',[]))
  functional_rows.append({'endpoint':endpoint,'instance_id':i,'family':raw['family'],'status':a['status'],'paired_signature_equal':a['functional_signature']==b['functional_signature'],'node_trace_sha256':pa['node_trace_sha256'] if x else None,'assignment_sha256':pa['assignment_sha256'] if x else None,'prune_trace_sha256':digest((x or{}).get('prune_trace')),'nodes':(x or{}).get('nodes',0),'prunes':(x or{}).get('prunes',0),'original_waste_checks':(x or{}).get('waste_checks',0),'cached_waste_checks':(y or{}).get('waste_checks',0),'original_residual_checks':(x or{}).get('residual_checks',0),'cached_residual_checks':(y or{}).get('residual_checks',0),'original_remaining_materialized_items':remaining_items,'cached_prune_remaining_materialized_items':pruned_materialized,'cached_setup_ordered_items':n if x else 0,'cached_setup_suffix_iterations':n if x else 0,'original_remaining_negative_test_items':remaining_items,'original_remaining_sum_items':remaining_items,'original_positive_filter_items':positive_items,'original_min_positive_items':min_items,'original_slack_residual_sum_items':len(guard_trace)*raw['K'],'cached_initial_slack_residual_sum_items':raw['K'] if x else 0})
writecsv('FUNCTIONAL_PER_INSTANCE.csv',functional_rows)
bs=[json.loads(x) for x in (ROOT/'raw/batches.jsonl').read_text().splitlines()];timed=[b for b in bs if b['phase']=='timed'];bindex={(b['round'],b['arm']):b for b in timed}
writecsv('PANEL_BATCHES.csv',bs)
ticks=read(ROOT/'raw/CPU_CLOCK_TICKS.json');jumps=[b-a for a,b in zip(ticks,ticks[1:]) if b>a]
cal=read(ROOT/'raw/CLOCK_BRACKETS.json');positive=[r['cpu_ns'] for r in cal if r['cpu_ns']>0]
quantum=max(4_000_000,st.median(jumps+positive) if jumps+positive else 4_000_000)
# Frozen conservative observability rule: all ten timed batches >=100 effective quanta.
clock_eligible=len(timed)==10 and all(b['completed_calls']==384 and b['wrapper_inclusive_panel_cpu_ns']>=100*quantum for b in timed)
wall_eligible=len(timed)==10 and all(b['completed_calls']==384 and b['wrapper_inclusive_panel_wall_ns']>0 for b in timed)
roundrows=[]
for rnd in range(1,6):
 if any((rnd,a) not in bindex for a in ARMS):continue
 x=bindex[(rnd,'waste_solver')];y=bindex[(rnd,'cached_solver')]
 roundrows.append({'round':rnd,'original_cpu_ns':x['wrapper_inclusive_panel_cpu_ns'],'cached_cpu_ns':y['wrapper_inclusive_panel_cpu_ns'],'cpu_ratio':y['wrapper_inclusive_panel_cpu_ns']/x['wrapper_inclusive_panel_cpu_ns'] if clock_eligible else None,'original_wall_ns':x['wrapper_inclusive_panel_wall_ns'],'cached_wall_ns':y['wrapper_inclusive_panel_wall_ns'],'wall_ratio':y['wrapper_inclusive_panel_wall_ns']/x['wrapper_inclusive_panel_wall_ns'] if wall_eligible else None})
writecsv('PAIRED_ROUNDS.csv',roundrows)
wallrows=[]
for i in ids:
 ratios=[]
 for rnd in range(1,6):
  x=seconds[(i,'waste_solver',rnd)];y=seconds[(i,'cached_solver',rnd)]
  if len(x)==len(y)==8 and min(x+y)>0:ratios.append(sum(y)/sum(x))
 wallrows.append({'instance_id':i,'family':inputs[i]['family'],'rounds':len(ratios),'ratios':json.dumps(ratios),'median_ratio':st.median(ratios) if len(ratios)==5 else None})
writecsv('SECONDARY_INSTANCE_WALL.csv',wallrows)
finish=read(ROOT/'raw/FINISHED.json');wf=read(ROOT/'raw/WORKER_FINISHED.json');toy=read(ROOT/'raw/TOY_FINISHED.json')
old=read(ROOT/'provenance/OLD_FILES_BEFORE.json')
oldchanges=[p for p,h in old.items() if sha(SOURCE/p)!=h]
batchbad=[]
for x,b in zip(bs,schedule):
 if any(x[k]!=b[k] for k in ['batch_id','phase','round','arm']) or x['completed_calls']!=48*b['repetitions']:batchbad.append(x['batch_id'])
checks={'calls_complete':not(set(expected)-set(seen)) and len(seen)==3936 and all(v==1 for v in seen.values()),'schedule_metadata':not bad,'phase_counts':dict(phasecounts)=={'warmup':96,'timed':3840},'batches_complete':len(bs)==12 and not batchbad,'all_outputs_and_semantic_diagnostics_match_reference':not drifts,'no_success_invalid':not invalid,'inputs_unchanged':not mutations,'signatures_recomputed':not derived_errors,'repeat_determinism':all(len(v)==1 for v in signs.values()),'all96_partitions_match_reference':len(parts)==96 and len(pindex)==96 and not partbad,'scan_accounting_exact':not accountingbad,'toy7140_pass':toy['states']==7140 and toy['decision_mismatches']==0 and toy['false_prunes']==0 and toy['metadata_mismatches']==0 and toy['transition_mismatches']==0 and toy['negative_domain_cases']==6,'old_tree_unchanged':not oldchanges,'normal_finish':finish['returncode']==0 and not finish['timeout'] and wf['complete'],'exact_node_assignment_prune_trace_hashes':not tracebad,'preparation_source_scope_verified':read(ROOT/'provenance/PREPARATION_CHECKS.json')['only_bounded_partition_and_two_new_helpers_changed']}
summary={'namespace':protocol['namespace'],'scientific_units':48,'timed_calls':3840,'warmup_calls':96,'direct_partition_calls':96,'toy':toy,'functional':{},'clocks':{'effective_quantum_ns':quantum,'clock_tick_positive_jumps':dist(jumps),'empty_positive_cpu_readings':dist(positive),'empty_zero_cpu':sum(r['cpu_ns']==0 for r in cal),'cpu_eligible':clock_eligible,'wall_eligible':wall_eligible,'observability_rule':'All10batches>=100*max(prior4ms,median positive observed CPU increments); descriptive batch-level estimate only.'},'timing':{},'paired_rounds':roundrows,'secondary_instance_wall_ratio_medians':dist([r['median_ratio'] for r in wallrows if r['median_ratio'] is not None]),'caveats':['Same artificial48instances; timing repetitions are not new generalization samples.','Comparison is cached newbound versus original newbound, not original baseline.','Full initializer wrapper-inclusive batches include Python loops, snapshot, retained diagnostic objects, GC, and per-call wall reads; exclude external checker, hash, serialization and disk I/O.','No claim about exact per-call CPU; underlying process clock remains quantized.','All existing counters, exact output, node visits and prune traces must match; source-derived removed item visits are mechanism evidence, not time.','No confidence intervals, p-values, selected rounds, reruns or baseline-speedup claims.']}
for endpoint in ['initialize','partition']:
 fr=[r for r in functional_rows if r['endpoint']==endpoint]
 summary['functional'][endpoint]={'statuses':dict(collections.Counter(r['status'] for r in fr)),'identical_instances':sum(r['paired_signature_equal'] for r in fr),'totals':{k:sum(r[k] for r in fr) for k in ['nodes','prunes','original_waste_checks','cached_waste_checks','original_residual_checks','cached_residual_checks','original_remaining_materialized_items','cached_prune_remaining_materialized_items','cached_setup_ordered_items','cached_setup_suffix_iterations','original_remaining_negative_test_items','original_remaining_sum_items','original_positive_filter_items','original_min_positive_items','original_slack_residual_sum_items','cached_initial_slack_residual_sum_items']}}
for clock,eligible in [('cpu',clock_eligible),('wall',wall_eligible)]:
 totals={a:sum(r['wrapper_inclusive_panel_'+clock+'_ns'] for r in timed if r['arm']==a) for a in ARMS}
 ratios=[r[clock+'_ratio'] for r in roundrows if r[clock+'_ratio'] is not None]
 summary['timing'][clock]={'raw_total_ns':totals,'eligible':eligible,'cached_over_original_ratio':totals['cached_solver']/totals['waste_solver'] if eligible else None,'paired_ratio_distribution':dist(ratios),'ns_per_complete_initializer_including_failures':{a:totals[a]/1920 for a in ARMS} if eligible else None}
summary['resources']={'execution_cpu_seconds':finish['child_cpu_seconds']+finish['supervisor_cpu_ns']/1e9,'execution_wall_seconds':finish['elapsed_ns']/1e9,'analysis_cpu_seconds':(time.process_time_ns()-C)/1e9,'analysis_wall_seconds':(time.perf_counter_ns()-W)/1e9,'analysis_peakrss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'worker_peakrss_KiB':finish['child_peakrss_KiB'],'supervisor_peakrss_KiB':finish['supervisor_peakrss_KiB'],'limit_envelope':'CPU100+5+10=115s<120s; wall220+10=230s<240s; concurrent worker768MiB+supervisor128MiB<=896MiB address space; analysis256MiB sequential'}
checks['resources_ok']=summary['resources']['execution_cpu_seconds']+summary['resources']['analysis_cpu_seconds']<120 and summary['resources']['execution_wall_seconds']+summary['resources']['analysis_wall_seconds']<240 and finish['child_peakrss_KiB']+finish['supervisor_peakrss_KiB']<1024**2 and resource.getrusage(resource.RUSAGE_SELF).ru_maxrss<1024**2
audit={'passed':all(checks.values()),'checks':checks,'drift_calls':drifts,'invalid_successes':invalid,'partition_mismatches':partbad,'old_tree_changes':oldchanges,'bad_scan_accounting':accountingbad,'missing_calls':sorted(set(expected)-set(seen))}
dump(ROOT/'reports/SUMMARY.json',summary);dump(ROOT/'reports/AUDIT.json',audit)
cp=summary['timing']['cpu']['cached_over_original_ratio'];wp=summary['timing']['wall']['cached_over_original_ratio'];fct=summary['functional']['initialize'];pct=summary['functional']['partition']
report=f'''容量界固定顺序缓存：单候选固定面板实验

自动化自审：{'PASS' if audit['passed'] else 'FAIL'}；外部独审另存。原newbound与单一cached变体，不含快速gate，不调用模型，不修改旧冻结材料。

数学：固定order允许一次预计算后缀sum、最小正数与负数域标志；每次放置同时减少总剩余容量与剩余需求相同的整数需求，故slack不变，回溯同理。空列表、全零、负slack、负数域报错顺序、原guard三元组保持。浮点及自定义数值对象不在等价声明内。详见EQUIVALENCE_PROOF.txt。

功能：初始化 {fct['statuses']}，两臂48/48输出及完整非时间诊断一致；直接分区 {pct['statuses']}，精确assignment/node/prune trace哈希一致。7140预定小状态全部guard三元组一致、可行误剪0、后缀统计和slack转移差异0；6个负数域控制一致。初始化扫描会计 {fct['totals']}。这些计数只能说明重复工作减少，不能当作加速。高slack族初始化常由前置算法完成，直接分区机制计数不能替代初始化收益。

计时：5轮×每臂整板48×8调用，共3840计时调用；预定96热身；主单位为384次完整初始化整板CPU和wall，单例仅次级wall。setup/cache建设、失败路径、matrix、内部checker、output_for均计时；Python循环、Budget快照、结果缓冲、GC和单次wall读取包含在整板；外部验证/hash/序列化/落盘排除。
CPU cached/original比：{cp if cp is not None else '不可估：未满足所有整板>=100个有效量化的预定阈值'}。
wall cached/original比：{wp if wp is not None else '不可估'}。
process_time_ns实际约4ms量化，有效量化=max(4ms,固定探针正跳变中位数)={quantum/1e6:.3f}ms；使用与前阶段相同保守阈值。不因阈值未过增加轮次或剔除轮次。即使通过也仅是描述性整板估计，不声称精确单调用CPU或统计显著。

限制：仍是固定48个人工结构，8次与5轮是技术重复，不是更多科学样本；无随机外部分布泛化证据。候选仅一个；不改变节点预算、分支顺序、失败回退或输出，不进行baseline速度比较。没有局部搜索阶段或整体算法质量提升声明。所有原始读数保留，无重跑、选择轮次、选择子集或隐藏失败。
'''
(ROOT/'reports/REPORT_ZH.txt').write_text(report)
print(json.dumps({'audit_passed':audit['passed'],'functional':summary['functional'],'timing':summary['timing'],'resources':summary['resources']},ensure_ascii=False))
