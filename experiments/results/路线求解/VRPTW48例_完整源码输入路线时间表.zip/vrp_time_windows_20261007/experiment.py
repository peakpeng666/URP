"""Frozen standard-library VRPTW experiment. Run only through supervise.py."""
import os,sys,json,math,random,itertools,time,hashlib,datetime,statistics,csv,traceback
from pathlib import Path
import checker
ROOT=Path(__file__).resolve().parent
EPS=1e-9
PHASE={}

def dump(name,value):
    (ROOT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def generate():
    instances=[]
    for gi in range(16):
        rng=random.Random(2026100701+gi); pts=[(0.,0.)]
        for j in range(1,8):
            if gi<8:xy=(rng.uniform(-10,10),rng.uniform(-10,10))
            else:
                c=-6 if j%2 else 6
                xy=tuple(max(-10,min(10,rng.gauss(c,1.8))) for _ in range(2))
            pts.append(tuple(round(v,3) for v in xy))
        anchors={}
        for route in ((1,2,3,4),(5,6,7)):
            now=0.;prev=0
            for j in route:
                now+=math.dist(pts[prev],pts[j]);anchors[j]=now;now+=2;prev=j
        jitter={j:rng.uniform(-8,8) for j in range(1,8)}
        for level,width in [('tight',2),('medium',10),('wide',30)]:
            nodes=[{'id':0,'x':0.,'y':0.,'demand':0,'service':0.,'window':[0.,120.]}]
            for j,demand in enumerate([2,1,2,1,2,1,1],1):
                center=anchors[j]+jitter[j]
                nodes.append({'id':j,'x':pts[j][0],'y':pts[j][1],'demand':demand,'service':2.,'window':[max(0.,center-width),max(0.,center+width)],'reference_start':anchors[j],'center_jitter':jitter[j]})
            instances.append({'id':f'G{gi+1:02d}_{level}','geometry':f'G{gi+1:02d}','stratum':'uniform' if gi<8 else 'two_cluster','level':level,'halfwidth':width,'seed':2026100701+gi,'vehicles':2,'capacity':6,'depart_time':0.,'return_deadline':120.,'nodes':nodes,'reference_routes':[[1,2,3,4],[5,6,7]]})
    return instances

class Model:
    def __init__(self,ins):
        self.ins=ins;self.nodes=ins['nodes'];self.n=len(self.nodes)-1
        self.d=[[math.hypot(a['x']-b['x'],a['y']-b['y']) for b in self.nodes]for a in self.nodes]
    def route(self,route,windows=True):
        load=sum(self.nodes[j]['demand'] for j in route)
        if load>self.ins['capacity']:return None
        clock=0.;cost=0.;prev=0;slack=self.ins['return_deadline']
        for j in route:
            cost+=self.d[prev][j];clock+=self.d[prev][j]
            if windows:
                a,b=self.nodes[j]['window'];clock=max(clock,a)
                if clock>b+EPS:return None
                slack=min(slack,b-clock)
            clock+=self.nodes[j]['service'];prev=j
        cost+=self.d[prev][0];clock+=self.d[prev][0]
        if clock>self.ins['return_deadline']+EPS:return None
        slack=min(slack,self.ins['return_deadline']-clock)
        return cost,slack
    def cost(self,routes):return sum(self.route(r)[0] for r in routes)

def canonical(routes):return tuple(sorted(tuple(r) for r in routes))
def exact(model,windows=True):
    best={0:(0.,())};evaluated=0
    for k in range(1,model.n+1):
        for route in itertools.permutations(range(1,model.n+1),k):
            evaluated+=1
            got=model.route(route,windows)
            if got is None:continue
            mask=sum(1<<(j-1) for j in route);candidate=(got[0],route)
            if mask not in best or candidate<best[mask]:best[mask]=candidate
    cover={}
    for a,(ca,ra) in best.items():
        for b,(cb,rb) in best.items():
            if a&b:continue
            union=a|b;candidate=(ca+cb,canonical((ra,rb)))
            if union not in cover or candidate<cover[union]:cover[union]=candidate
    full=cover.get((1<<model.n)-1)
    maxmask=min(cover,key=lambda m:(-m.bit_count(),cover[m][0],cover[m][1]))
    return {'cover':cover,'full':full,'maximum':(maxmask,cover[maxmask]),'ordered_subsets_evaluated':evaluated,'feasible_single_route_masks':len(best)}

def insert(model,routes,remaining,kind):
    while remaining:
        candidates=[]
        for j in sorted(remaining):
            for vi,r in enumerate(routes):
                old=model.route(r)[0]
                for pos in range(len(r)+1):
                    candidate=r[:pos]+[j]+r[pos:];got=model.route(candidate)
                    if got is None:continue
                    delta=got[0]-old
                    key=(delta,j,vi,pos) if kind=='distance_first' else (model.nodes[j]['window'][1],-got[1],delta,j,vi,pos)
                    candidates.append((key,j,vi,candidate))
        if not candidates:break
        _,j,vi,candidate=min(candidates,key=lambda c:c[0]);routes[vi]=candidate;remaining.remove(j)
    return routes

def improve(model,routes):
    for _ in range(5):
        old=model.cost(routes);candidates=[]
        for vi,r in enumerate(routes):
            for left in range(len(r)):
                for right in range(left+1,len(r)):
                    candidate=[list(x) for x in routes];candidate[vi]=r[:left]+list(reversed(r[left:right+1]))+r[right+1:]
                    if model.route(candidate[vi]) is not None:candidates.append(candidate)
            for ix,j in enumerate(r):
                base=[list(x) for x in routes];base[vi].pop(ix)
                for vj in range(len(routes)):
                    for pos in range(len(base[vj])+1):
                        candidate=[list(x) for x in base];candidate[vj].insert(pos,j)
                        if all(model.route(x) is not None for x in candidate):candidates.append(candidate)
        good=[(model.cost(c),canonical(c),c) for c in candidates if model.cost(c)<old-EPS]
        if not good:break
        routes=min(good,key=lambda x:(x[0],x[1]))[2]
    return routes

def heuristic(model,kind):
    routes=[[],[]];remaining=set(range(1,8))
    routes=insert(model,routes,remaining,kind);routes=improve(model,routes)
    routes=insert(model,routes,remaining,kind);return improve(model,routes)

def brute_full(ins):
    best=None; count=0
    for perm in itertools.permutations(range(1,8)):
        for split in range(8):
            count+=1;routes=[perm[:split],perm[split:]]
            # independent checker only; no solver feasibility/matrix used.
            result=checker.audit(ins,routes)
            if result['full_service_feasible']:
                cand=(result['total_distance'],canonical(routes))
                if best is None or cand<best:best=cand
    return best,count

def record(ins,method,routes,cpu,oracle,status='complete'):
    if routes is None:
        return {'instance':ins['id'],'geometry':ins['geometry'],'stratum':ins['stratum'],'level':ins['level'],'method':method,'status':status,'routes':None,'audit':None,'cpu_seconds':cpu,'full_oracle_objective':None,'full_gap_percent':None,'same_served_mask_optimum':None,'same_served_mask_gap_percent':None,'coverage_shortfall':None}
    routes=[list(x) for x in routes];a=checker.audit(ins,routes);mask=sum(1<<(j-1) for j in set(sum(routes,[])))
    target=oracle['cover'].get(mask);full=oracle['full'];maxcount=oracle['maximum'][0].bit_count()
    gap=None
    if a['route_feasible'] and target is not None and mask:gap=100*(a['total_distance']/target[0]-1)
    fg=None
    if a['full_service_feasible'] and full:fg=100*(a['total_distance']/full[0]-1)
    return {'instance':ins['id'],'geometry':ins['geometry'],'stratum':ins['stratum'],'level':ins['level'],'method':method,'status':status,'routes':routes,'audit':a,'cpu_seconds':cpu,'full_oracle_objective':full[0] if full else None,'full_gap_percent':fg,'same_served_mask_optimum':target[0] if target is not None and a['route_feasible'] else None,'same_served_mask_gap_percent':gap,'coverage_shortfall':maxcount-a['served_unique'] if a['route_feasible'] else None}

def metrics(rows,ins,oracles):
    out={'instance_count':len(ins),'geometry_count':16,'task_opportunities':len(ins)*7,'by_level':{},'cpu_phases':PHASE,'methods':{},'paired':{}}
    for level in ['tight','medium','wide','all']:
        subset=[i for i in ins if level=='all' or i['level']==level];ids={i['id'] for i in subset}
        of=sum(oracles[i['id']]['full'] is not None for i in subset)
        maximum=sum(oracles[i['id']]['maximum'][0].bit_count() for i in subset)
        block={'cases':len(subset),'oracle_full_feasible':of,'oracle_full_infeasible':len(subset)-of,'oracle_maximum_tasks':maximum,'task_opportunities':len(subset)*7,'methods':{}}
        for method in ['distance_first','time_window_first','capacity_only_diagnostic']:
            rr=[r for r in rows if r['instance'] in ids and r['method']==method];aa=[r['audit'] for r in rr]
            full=sum(a['full_service_feasible'] for a in aa);gaps=[r['full_gap_percent'] for r in rr if r['full_gap_percent'] is not None];sg=[r['same_served_mask_gap_percent'] for r in rr if r['same_served_mask_gap_percent'] is not None]
            block['methods'][method]={'full_service_feasible':full,'full_rate_all':full/len(subset),'full_rate_oracle_feasible':full/of if of else None,'feasible_routes':sum(a['route_feasible'] for a in aa),'served_unique':sum(a['served_unique'] for a in aa),'valid_served_tasks':sum(a['served_unique'] for a in aa if a['route_feasible']),'late_starts':sum(a['late_starts'] for a in aa),'total_lateness':sum(a['total_lateness'] for a in aa),'overloaded_vehicles':sum(a['overloaded_vehicles'] for a in aa),'late_depot_returns':sum(a['late_depot_returns'] for a in aa),'missing_tasks':sum(len(a['missing']) for a in aa),'duplicate_cases':sum(bool(a['duplicates']) for a in aa),'full_gap_n':len(gaps),'full_gap_mean_percent':statistics.mean(gaps) if gaps else None,'full_gap_max_percent':max(gaps) if gaps else None,'same_mask_gap_n':len(sg),'same_mask_gap_mean_percent':statistics.mean(sg) if sg else None,'same_mask_gap_max_percent':max(sg) if sg else None,'cpu_seconds':sum(r['cpu_seconds'] for r in rr)}
        d={r['instance']:r for r in rows if r['instance'] in ids and r['method']=='distance_first'};t={r['instance']:r for r in rows if r['instance'] in ids and r['method']=='time_window_first'}
        block['paired']={'tw_full_only':sum(t[k]['audit']['full_service_feasible'] and not d[k]['audit']['full_service_feasible'] for k in ids),'distance_full_only':sum(d[k]['audit']['full_service_feasible'] and not t[k]['audit']['full_service_feasible'] for k in ids),'both_full':sum(d[k]['audit']['full_service_feasible'] and t[k]['audit']['full_service_feasible'] for k in ids),'neither_full':sum(not d[k]['audit']['full_service_feasible'] and not t[k]['audit']['full_service_feasible'] for k in ids),'tw_more_coverage':sum(t[k]['audit']['served_unique']>d[k]['audit']['served_unique'] for k in ids),'distance_more_coverage':sum(d[k]['audit']['served_unique']>t[k]['audit']['served_unique'] for k in ids)}
        out['by_level'][level]=block
    return out

def export(ins,rows,summary):
    with (ROOT/'metrics.csv').open('w',newline='') as f:
        fields=['instance','geometry','stratum','level','method','status','cpu_seconds','full_oracle_objective','full_gap_percent','same_served_mask_optimum','same_served_mask_gap_percent','coverage_shortfall','full_service_feasible','served_unique','total_distance','late_starts','total_lateness','overloaded_vehicles','late_depot_returns','missing']
        w=csv.DictWriter(f,fields);w.writeheader()
        for r in rows:
            x={k:r.get(k) for k in fields};a=r.get('audit') or {};x.update({k:a[k] for k in fields if k in a});w.writerow(x)
    with (ROOT/'timetables.csv').open('w',newline='') as f:
        fields=['instance','method','vehicle','event','node','load','arrival','wait','start','depart','window_open','window_close','lateness','leg_distance','return_time'];w=csv.DictWriter(f,fields);w.writeheader()
        for r in rows:
            if not r['audit']:continue
            for sc in r['audit']['schedules']:
                for stop in sc['stops']:
                    x={k:v for k,v in stop.items() if k in fields};x.update(instance=r['instance'],method=r['method'],vehicle=sc['vehicle'],event='customer',load=sc['load']);w.writerow(x)
                w.writerow({'instance':r['instance'],'method':r['method'],'vehicle':sc['vehicle'],'event':'depot_return','node':0,'load':sc['load'],'leg_distance':sc['return_leg_distance'],'return_time':sc['return_time'],'lateness':sc['depot_lateness']})
    # Cartesion geometry is intentionally not GeoJSON geographic coordinates.
    dump('map_backend.json',{'schema_version':1,'coordinate_system':'synthetic Cartesian, not longitude/latitude; not road travel','units':'arbitrary distance/time, speed1','time_window_semantics':'inclusive service-start','objective':'total Euclidean route distance, full service required','instances':ins,'solutions':rows,'summary':summary})
    b=summary['by_level'];allb=b['all'];d=allb['methods']['distance_first'];t=allb['methods']['time_window_first'];p=allb['methods']['capacity_only_diagnostic']
    lines=['多车容量与时间窗实验报告','',f"48个新合成小实例中，精确oracle确认{allb['oracle_full_feasible']}例可全服务、{allb['oracle_full_infeasible']}例真实无解。距离优先完成{d['full_service_feasible']}/48，时间窗优先完成{t['full_service_feasible']}/48；在可全服务的实例上分别为{d['full_service_feasible']}/{allb['oracle_full_feasible']}和{t['full_service_feasible']}/{allb['oracle_full_feasible']}。",'',f"两启发式都执行相同可行性门：均有{d['late_starts']}、{t['late_starts']}次迟到，{d['overloaded_vehicles']}、{t['overloaded_vehicles']}次车辆超载。总服务任务分别{d['served_unique']}、{t['served_unique']}，分母336；精确最大可服务合计{allb['oracle_maximum_tasks']}。漏服务必须与成本一起读。",'', '分档结果（每档16例）']
    for level,zh in [('tight','紧'),('medium','中'),('wide','宽')]:
        q=b[level];dd=q['methods']['distance_first'];tt=q['methods']['time_window_first']
        lines.append(f"{zh}窗：oracle可全服务{q['oracle_full_feasible']}/16；距离优先{dd['full_service_feasible']}/16，时间窗优先{tt['full_service_feasible']}/16；服务任务{dd['served_unique']}/112和{tt['served_unique']}/112（oracle最大{q['oracle_maximum_tasks']}）。")
    lines+=['','纯距离解的诊断',f"精确求得的容量可行最短距离全服务路线，原样加上时间窗重放后，仅{p['full_service_feasible']}/48仍可行，共{p['late_starts']}个服务开始迟到。这只是证明这些样本的容量约束距离最优解不能直接当作时间窗可行解，不是第三个启发式。",'','成本与配对比较',f"全服务且可行的成本gap：距离优先平均{d['full_gap_mean_percent']:.3f}%（n={d['full_gap_n']}），时间窗优先平均{t['full_gap_mean_percent']:.3f}%（n={t['full_gap_n']}）。这两个均值的样本可能不同，不能单独据此判优。",f"各自相同已服务节点集合的精确可行最优gap：距离优先平均{d['same_mask_gap_mean_percent']:.3f}%（n={d['same_mask_gap_n']}），时间窗优先平均{t['same_mask_gap_mean_percent']:.3f}%（n={t['same_mask_gap_n']}）。该指标不补偿漏点。",f"同实例全服务配对：仅时间窗优先成功{allb['paired']['tw_full_only']}例，仅距离优先成功{allb['paired']['distance_full_only']}例，两者成功{allb['paired']['both_full']}例，两者未完成{allb['paired']['neither_full']}例。",'', '冻结与边界','求解前已冻结输入、协议、代码、checker、分析规则与SHA256，未做求解试跑、调参或筛掉失败。16个几何各派生3档嵌套窗，48例并非48个独立抽样。窗口围绕固定节点编号顺序的容量可行见证加抖动生成；中、宽窗保留见证，紧窗可能无解，因此有明确生成偏置。仅适用于这批7任务、2车、容量6、服务时间2的合成证据。','时间窗约束开始服务时刻，等待允许，所有车0时出发，120前回仓。目标只计总欧氏路长。没有道路网络、动态交通、定位误差、规模化或实地证据。','独立checker从原始节点和路线重算，覆盖等待、边界、迟到、超载、回仓、漏点、重复与未知节点；两几何三档共6例另用全排列+切分独立交叉验证精确目标。','原始路线和时间表在routes.jsonl、timetables.csv；所有未完成及无解保留，完整不可行目标写null。汇总见summary.json，冻结见freeze.json，自检见self_check.json、verification.json，CPU硬预算与精确子进程计量见resource_accounting.json。','map_backend.json提供约束展示的坐标、节点窗、需求、路线、逐站时刻和可行性字段；坐标为合成平面坐标，不可当真实经纬度。未修改任何已有科研面板或旧实验。']
    (ROOT/'report_zh.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')

def main():
    t=time.process_time();ins=generate();dump('inputs.json',ins);PHASE['generate_cpu_seconds']=time.process_time()-t
    frozen=['protocol.json','inputs.json','experiment.py','checker.py','supervise.py','verify.py','workload.py']
    dump('freeze.json',{'frozen_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'before_any_solver_call':True,'sha256':{f:sha(ROOT/f) for f in frozen},'inputs':len(ins),'pilot_runs':0})
    t=time.process_time();unit=checker.tests();PHASE['checker_unit_test_cpu_seconds']=time.process_time()-t
    # Generation and nesting checks do not optimize any route.
    for gi in range(16):
        three=ins[gi*3:gi*3+3]
        for j in range(1,8):
            wins=[x['nodes'][j]['window'] for x in three]
            assert wins[2][0]<=wins[1][0]<=wins[0][0] and wins[0][1]<=wins[1][1]<=wins[2][1]
        for x in three[1:]:assert checker.audit(x,x['reference_routes'])['full_service_feasible']
    rows=[];oracles={};checks=[];capcache={};PHASE.update(exact_time_window_cpu_seconds=0.,capacity_only_oracle_cpu_seconds=0.,heuristic_cpu_seconds=0.,independent_audit_export_cpu_seconds=0.,crosscheck_cpu_seconds=0.)
    stream=(ROOT/'routes.jsonl').open('w',encoding='utf-8')
    for instance in ins:
        model=Model(instance);t=time.process_time();oracle=exact(model);ocpu=time.process_time()-t;PHASE['exact_time_window_cpu_seconds']+=ocpu;oracles[instance['id']]=oracle
        for method in ['distance_first','time_window_first']:
            t=time.process_time();routes=heuristic(model,method);cpu=time.process_time()-t;PHASE['heuristic_cpu_seconds']+=cpu
            t=time.process_time();r=record(instance,method,routes,cpu,oracle);assert r['audit']['route_feasible'];assert r['coverage_shortfall']>=0;rows.append(r);stream.write(json.dumps(r,ensure_ascii=False,allow_nan=False)+'\n');stream.flush();PHASE['independent_audit_export_cpu_seconds']+=time.process_time()-t
        full=oracle['full'];maxmask,maxresult=oracle['maximum']
        for method,sol,status in [('oracle_full',full,'optimal' if full else 'proven_infeasible'),('oracle_max_coverage',maxresult,'optimal_max_coverage')]:
            t=time.process_time();r=record(instance,method,sol[1] if sol else None,ocpu,oracle,status);rows.append(r);stream.write(json.dumps(r,ensure_ascii=False,allow_nan=False)+'\n');PHASE['independent_audit_export_cpu_seconds']+=time.process_time()-t
        if instance['geometry'] not in capcache:
            t=time.process_time();co=exact(model,windows=False);ccpu=time.process_time()-t;PHASE['capacity_only_oracle_cpu_seconds']+=ccpu;capcache[instance['geometry']]=(co,ccpu)
        co,ccpu=capcache[instance['geometry']];assert co['full'] is not None
        t=time.process_time();r=record(instance,'capacity_only_diagnostic',co['full'][1],ccpu if instance['level']=='tight' else 0.,oracle,'replayed_capacity_only_optimum');rows.append(r);stream.write(json.dumps(r,ensure_ascii=False,allow_nan=False)+'\n');stream.flush();PHASE['independent_audit_export_cpu_seconds']+=time.process_time()-t
        if instance['geometry'] in ['G01','G09']:
            t=time.process_time();brute,count=brute_full(instance);PHASE['crosscheck_cpu_seconds']+=time.process_time()-t
            assert (brute is None)==(full is None)
            if full:assert abs(brute[0]-full[0])<1e-7
            checks.append({'instance':instance['id'],'full_permutation_split_candidates':count,'oracle':full[0] if full else None,'independent_bruteforce':brute[0] if brute else None,'pass':True})
        print(json.dumps({'instance':instance['id'],'oracle_full':full[0] if full else None,'max_coverage':maxmask.bit_count(),'completed':len(oracles)}),flush=True)
    stream.close()
    t=time.process_time();summary=metrics(rows,ins,oracles);export(ins,rows,summary);PHASE['analysis_exports_cpu_seconds']=time.process_time()-t
    dump('summary.json',summary)
    dump('oracle_tables.json',{k:{'full_feasible':v['full'] is not None,'ordered_subsets_evaluated':v['ordered_subsets_evaluated'],'feasible_single_route_masks':v['feasible_single_route_masks'],'best_two_vehicle_by_served_mask':{str(m):{'distance':c,'routes':r} for m,(c,r) in v['cover'].items()}} for k,v in oracles.items()})
    dump('self_check.json',{'unit_tests':unit,'unit_tests_passed':len(unit),'nested_windows_checks_passed':True,'medium_wide_reference_witness_checks':32,'independent_full_oracle_crosschecks':checks,'heuristic_route_feasibility_checks':96,'all48_cases_retained':len(oracles)==48,'source_unchanged':all(sha(ROOT/f)==h for f,h in json.loads((ROOT/'freeze.json').read_text())['sha256'].items()),'time_window_semantics':'service_start','no_solution_imputed_to_zero':True,'cpu_process_at_checkpoint':time.process_time()})
    print(json.dumps(summary['by_level']['all'],ensure_ascii=False),flush=True)

if __name__=='__main__':main()
