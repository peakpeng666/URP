"""Read-only post-run audit. Frozen before optimization, standard library only."""
import json,hashlib,math,csv
from pathlib import Path
import checker
P=Path(__file__).resolve().parent

def main():
    freeze=json.loads((P/'freeze.json').read_text());checks=[]
    for name,h in freeze['sha256'].items():
        assert hashlib.sha256((P/name).read_bytes()).hexdigest()==h,(name,'changed after freeze')
    checks.append('all_frozen_hashes_unchanged')
    instances=json.loads((P/'inputs.json').read_text());byid={x['id']:x for x in instances};assert len(byid)==48
    rows=[json.loads(s) for s in (P/'routes.jsonl').read_text().splitlines()];assert len(rows)==240
    keys={(r['instance'],r['method']) for r in rows};assert len(keys)==240
    tab=json.loads((P/'oracle_tables.json').read_text())
    for r in rows:
        if r['routes'] is None:
            assert r['method']=='oracle_full' and r['status']=='proven_infeasible' and r['full_oracle_objective'] is None
            assert not tab[r['instance']]['full_feasible']
            continue
        a=checker.audit(byid[r['instance']],r['routes']);assert a==r['audit']
        if r['method']!='capacity_only_diagnostic':assert a['route_feasible']
        if r['method']=='oracle_full':assert a['full_service_feasible'] and abs(a['total_distance']-r['full_oracle_objective'])<1e-7
        if r['same_served_mask_gap_percent'] is not None:assert r['same_served_mask_gap_percent']>=-1e-7
        if r['full_gap_percent'] is not None:assert a['full_service_feasible'] and r['full_gap_percent']>=-1e-7
    checks.append('240_records_recomputed_no_dropped_failure')
    checks.append('null_for_infeasible_full_objectives')
    # Check all oracle subset witnesses with the independent checker, not merely reported methods.
    witness_count=0
    for iid,t in tab.items():
        for mask,entry in t['best_two_vehicle_by_served_mask'].items():
            a=checker.audit(byid[iid],entry['routes']);assert a['route_feasible']
            actual=sum(1<<(j-1) for j in set(sum((list(x) for x in entry['routes']),[])))
            assert actual==int(mask) and abs(a['total_distance']-entry['distance'])<1e-7
            witness_count+=1
    checks.append('all_oracle_subset_witnesses_recomputed')
    summary=json.loads((P/'summary.json').read_text())
    for level,block in summary['by_level'].items():
        ins=[i for i in instances if level=='all' or i['level']==level];ids={i['id'] for i in ins}
        assert block['cases']==len(ins)
        assert block['oracle_full_feasible']==sum(tab[i['id']]['full_feasible'] for i in ins)
        for method,m in block['methods'].items():
            subset=[r for r in rows if r['method']==method and r['instance'] in ids]
            assert m['full_service_feasible']==sum(r['audit']['full_service_feasible'] for r in subset)
            assert m['served_unique']==sum(r['audit']['served_unique'] for r in subset)
            assert m['late_starts']==sum(r['audit']['late_starts'] for r in subset)
    checks.append('summary_denominators_and_counts_recomputed')
    assert len(list(csv.DictReader((P/'metrics.csv').open())))==240
    backend=json.loads((P/'map_backend.json').read_text());assert backend['solutions']==rows
    checks.append('csv_and_map_backend_consistent')
    out={'passed':True,'checks':checks,'record_count':240,'oracle_subset_witnesses_checked':witness_count,'read_only_solver_replay':True}
    (P/'verification.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(out,ensure_ascii=False))
if __name__=='__main__':main()
