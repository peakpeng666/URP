"""Post-run descriptive summaries and packaging; no solver rerun or tuning."""
import resource,time,json,statistics,hashlib,zipfile,math,re
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CPU,(1,1))
p=Path(__file__).resolve().parent
rs=[json.loads(s) for s in (p/'routes.jsonl').read_text().splitlines()];by={(r['instance'],r['method']):r for r in rs}
full=[r for r in rs if r['method']=='oracle_full' and r['routes']]
failed=[r for r in full if not by[r['instance'],'capacity_only_diagnostic']['audit']['full_service_feasible']]
strict=[r for r in failed if r['audit']['total_distance']>by[r['instance'],'capacity_only_diagnostic']['audit']['total_distance']+1e-7]
common=[(by[r['instance'],'distance_first'],by[r['instance'],'time_window_first']) for r in full if by[r['instance'],'distance_first']['audit']['full_service_feasible'] and by[r['instance'],'time_window_first']['audit']['full_service_feasible']]
geom=[]
for n in range(1,17):
    gid=f'G{n:02d}';row={'geometry':gid,'levels':{}}
    for lev in ['tight','medium','wide']:
        iid=gid+'_'+lev;d=by[iid,'distance_first'];t=by[iid,'time_window_first'];o=by[iid,'oracle_full']
        row['levels'][lev]={'oracle_full_feasible':o['routes'] is not None,'distance_full':d['audit']['full_service_feasible'],'time_window_full':t['audit']['full_service_feasible'],'distance_served':d['audit']['served_unique'],'time_window_served':t['audit']['served_unique']}
    geom.append(row)
sup={'analysis_status':'post-run descriptive supplemental analysis, not prespecified primary endpoints; no solver rerun or parameter change','pure_distance_diagnostic':{'oracle_feasible_denominator':len(full),'selected_capacity_only_optimum_infeasible':len(failed),'strictly_greater_time_window_optimum':len(strict),'equal_cost_feasible_alternative_exists':len(failed)-len(strict),'strictly_greater_instances':[r['instance'] for r in strict]},'matched_full_service':{'n':len(common),'distance_gap_mean_percent':statistics.mean(d['full_gap_percent'] for d,t in common),'time_window_gap_mean_percent':statistics.mean(t['full_gap_percent'] for d,t in common),'time_window_shorter':sum(t['audit']['total_distance']<d['audit']['total_distance']-1e-7 for d,t in common),'distance_shorter':sum(d['audit']['total_distance']<t['audit']['total_distance']-1e-7 for d,t in common),'equal_distance':sum(abs(d['audit']['total_distance']-t['audit']['total_distance'])<=1e-7 for d,t in common)},'geometry_triples':geom}
(p/'supplemental_analysis.json').write_text(json.dumps(sup,ensure_ascii=False,indent=2)+'\n')
account=json.loads((p/'resource_accounting.json').read_text());account['recorded_at_utc']=account.pop('started_utc');account['timestamp_label_correction']='Frozen supervisor captured this timestamp after child completion; relabeled recorded_at_utc in final artifact. No input, solver, result or frozen-source change.'
account['successful_full_run_shell_cpu_seconds_rounded']=4.315+0.051
account['successful_run_plus_preworkload_failure_cpu_seconds_rounded']=4.315+0.051+0.036
account['postrun_packaging_hard_cpu_limit_seconds']=1
account['observed_run_plus_postprocessing_hard_upper_bound_seconds']=4.315+0.051+0.036+1
account['postrun_packaging_cpu_checkpoint_seconds']=time.process_time()
account['accounting_scope']+=' Supplemental analysis/final archive runs with its own1s hard cap after observed previous CPU4.402s, so accounted final numerical/artifact work is bounded below5.402s. Source-authoring and conversational latency are not solver CPU.'
(p/'resource_accounting.json').write_text(json.dumps(account,ensure_ascii=False,indent=2)+'\n')
report=(p/'report_zh.txt').read_text().replace('均有0、0次迟到，0、0次车辆超载。','都为0次迟到、0次车辆超载、0次回仓超时。')
report+='\n补充描述性分析与CPU\n以下从既有原始结果计算，未重新求解或修改算法，也不作为预定主指标：33例有全服务解的实例中，固定平局规则选出的容量约束距离最优路线有20例违反时间窗。14例时间窗最优距离严格更长；另6例存在同距离可行改序。因此不能把全部35/48次诊断失效都归因于排序，也不能说加窗必然增加里程。\n共同全完成的27例，时间窗排序成本更低6例、距离排序更低10例、11例相等；平均全解gap分别5.949%和8.514%。时间窗排序在紧窗的两个实例反而少服务1个点，不是普遍占优。\n完整实验、全部校验和首次归档含启动失败约4.402 CPU秒；精确wait4计量的实验与校验子进程为4.285614 CPU秒，后续补充分析/最终归档另受1 CPU秒硬限制，总计保守小于5.402 CPU秒，低于120秒预算。单次小样本计时，不能据此宣布算法速度优势。首次启动在任何输入生成或求解前因继承CPU上限配置退出，原源码与失败日志均保留；修复启动顺序后首次冻结、首次求解即通过，未调参。\n'
(p/'report_zh.txt').write_text(report)
(p/'README.txt').write_text('VRPTW 48例合成约束基线 2026-10-07\n\n从report_zh.txt开始；主结果为summary.json，逐几何配对和额外诊断为supplemental_analysis.json（明确标记事后描述）。\n\ninputs.json：16几何x3嵌套窗，固定7任务2车容量6；每个输入都有完整窗口和见证生成参数。\nroutes.jsonl：48x5=240条完整记录，包括两启发式、全服务oracle、最大覆盖oracle和容量距离最优诊断；全服务无解写null，失败不删。\ntimetables.csv：逐车逐站到达/等待/开始/离开及回仓。metrics.csv：逐记录指标。\nmap_backend.json：可用于任务地图的合成平面坐标、需求、窗、路线和审计结果。不是经纬度或真实道路，不接入现有面板。\noracle_tables.json：全部5344个可行已服务集合的精确最短两车解及见证。\nprotocol.json和freeze.json：求解前协议、输入、实现和分析规则SHA256冻结。\nchecker.py：独立checker；self_check.json含8项故障/边界单测和6例全排列交叉验证；verification.json复核240条记录与5344个oracle见证。\nresource_accounting.json和shell_cpu.txt：完整CPU范围、硬限、启动失败计量；attempts/attempt00保留启动配置失败。\narchive_manifest.json和archive.sha256：归档完整性；manifest不自哈希，archive.sha256在ZIP外。\n\n复现：Python3.12标准库；将协议和*.py复制到新空目录，运行python supervise.py。不要覆盖本次冻结记录。硬上限为实验/验证子进程110 CPU秒+监督进程9 CPU秒。\n本次报告另含事后描述性补充；finalize_artifact.py中的计时数字针对本次运行，不应在新复现中原样采用。所有单位均为任意单位，速度1，开始服务窗闭区间，等待允许，0出发120前回仓。\n')
# Final archive integrity check; exclude compiled bytecode and self-referential outputs.
files=sorted(f for f in p.rglob('*') if f.is_file() and '__pycache__' not in f.parts and f.name not in ['archive_manifest.json','vrp_time_windows_20261007.zip','archive.sha256','finalization_cpu.txt'])
manifest={str(f.relative_to(p)):{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in files}
(p/'archive_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=p/'vrp_time_windows_20261007.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for f in files+[p/'archive_manifest.json']:z.write(f,arcname='vrp_time_windows_20261007/'+str(f.relative_to(p)))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for rel,m in manifest.items():assert hashlib.sha256(z.read('vrp_time_windows_20261007/'+rel)).hexdigest()==m['sha256']
checksum=hashlib.sha256(archive.read_bytes()).hexdigest();(p/'archive.sha256').write_text(checksum+'  '+archive.name+'\n')
print(json.dumps({'archive_bytes':archive.stat().st_size,'sha256':checksum,'entries':len(files)+1,'postrun_cpu_checkpoint_seconds':time.process_time(),'archive_integrity_passed':True}))
