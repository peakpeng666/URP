"""Single budgeted child executes complete experiment and independent validation."""
import experiment
import verify
experiment.main()
verify.main()
