VRPTW 48例合成约束基线 2026-10-07

从report_zh.txt开始；主结果为summary.json，逐几何配对和额外诊断为supplemental_analysis.json（明确标记事后描述）。

inputs.json：16几何x3嵌套窗，固定7任务2车容量6；每个输入都有完整窗口和见证生成参数。
routes.jsonl：48x5=240条完整记录，包括两启发式、全服务oracle、最大覆盖oracle和容量距离最优诊断；全服务无解写null，失败不删。
timetables.csv：逐车逐站到达/等待/开始/离开及回仓。metrics.csv：逐记录指标。
map_backend.json：可用于任务地图的合成平面坐标、需求、窗、路线和审计结果。不是经纬度或真实道路，不接入现有面板。
oracle_tables.json：全部5344个可行已服务集合的精确最短两车解及见证。
protocol.json和freeze.json：求解前协议、输入、实现和分析规则SHA256冻结。
checker.py：独立checker；self_check.json含8项故障/边界单测和6例全排列交叉验证；verification.json复核240条记录与5344个oracle见证。
resource_accounting.json和shell_cpu.txt：完整CPU范围、硬限、启动失败计量；attempts/attempt00保留启动配置失败。
archive_manifest.json和archive.sha256：归档完整性；manifest不自哈希，archive.sha256在ZIP外。

复现：Python3.12标准库；将协议和*.py复制到新空目录，运行python supervise.py。不要覆盖本次冻结记录。硬上限为实验/验证子进程110 CPU秒+监督进程9 CPU秒。
本次报告另含事后描述性补充；finalize_artifact.py中的计时数字针对本次运行，不应在新复现中原样采用。所有单位均为任意单位，速度1，开始服务窗闭区间，等待允许，0出发120前回仓。
