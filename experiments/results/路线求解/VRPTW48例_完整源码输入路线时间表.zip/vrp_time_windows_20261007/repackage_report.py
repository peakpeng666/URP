"""Text clarification only; no experiment/code/input changes or solver rerun."""
import json,zipfile,hashlib,resource,time
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CPU,(1,1))
p=Path(__file__).resolve().parent
rows=[json.loads(s) for s in (p/'routes.jsonl').read_text().splitlines()]
g12={r['method']:r for r in rows if r['instance']=='G12_tight'}
assert g12['oracle_full']['routes'] is not None
assert not g12['distance_first']['audit']['full_service_feasible'] and not g12['time_window_first']['audit']['full_service_feasible']
r=(p/'report_zh.txt').read_text()
r=r.replace('仅13/48仍可行，共100个服务开始迟到。','仅13/48仍可行，共100个服务开始迟到。其中15例本就没有可行全服务解，不能把这15次诊断失效归因于排序。有鉴别力的可行样本分母是33：所选纯距离最优路线仅13/33仍可行，另20/33违窗。')
r=r.replace('平均全解gap分别5.949%和8.514%。','共同27例平均全解gap：距离优先=8.514%，时间窗优先=5.949%。')
r=r.replace('时间窗排序在紧窗的两个实例反而少服务1个点，不是普遍占优。', '时间窗排序在G12和G15紧窗各比距离排序少服务1个点，不是普遍占优。紧窗唯一有全服务解的是G12_tight；距离优先只服务6/7，漏节点'+str(g12['distance_first']['audit']['missing'])+'；时间窗优先只服务5/7，漏节点'+str(g12['time_window_first']['audit']['missing'])+'，两者均错过这个可行全解。')
r=r.replace('后续补充分析/最终归档另受1 CPU秒硬限制，总计保守小于5.402 CPU秒，低于120秒预算。','第一次后处理实测0.099 CPU秒；最终文字澄清和重打包另受1 CPU秒硬限制，累计保守小于5.501 CPU秒，低于120秒预算。')
(p/'report_zh.txt').write_text(r)
a=json.loads((p/'resource_accounting.json').read_text());a['first_postrun_packaging_shell_cpu_seconds_rounded']=0.099;a['final_report_repackaging_hard_cpu_limit_seconds']=1;a['observed_run_plus_postprocessing_hard_upper_bound_seconds']=5.501;a['accounting_scope']+=' Final text-only clarification adds no solver run. First postprocessing shell total0.099s; final report repackaging1s hard bound, cumulative measured prior4.501s plus cap1s <5.501s (rounded).';(p/'resource_accounting.json').write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
# Assert all frozen inputs and implementations still identical.
frozen=json.loads((p/'freeze.json').read_text());assert all(hashlib.sha256((p/name).read_bytes()).hexdigest()==h for name,h in frozen['sha256'].items())
files=sorted(f for f in p.rglob('*') if f.is_file() and '__pycache__' not in f.parts and f.name not in ['archive_manifest.json','vrp_time_windows_20261007.zip','archive.sha256','repackage_cpu.txt'])
m={str(f.relative_to(p)):{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in files};(p/'archive_manifest.json').write_text(json.dumps(m,indent=2)+'\n')
zpath=p/'vrp_time_windows_20261007.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for f in files+[p/'archive_manifest.json']:z.write(f,'vrp_time_windows_20261007/'+str(f.relative_to(p)))
with zipfile.ZipFile(zpath) as z:
    assert z.testzip() is None
    assert all(hashlib.sha256(z.read('vrp_time_windows_20261007/'+name)).hexdigest()==entry['sha256'] for name,entry in m.items())
h=hashlib.sha256(zpath.read_bytes()).hexdigest();(p/'archive.sha256').write_text(h+'  '+zpath.name+'\n')
print(json.dumps({'archive':str(zpath),'bytes':zpath.stat().st_size,'sha256':h,'entries':len(files)+1,'cpu_checkpoint_seconds':time.process_time(),'frozen_hashes_unchanged':True,'archive_integrity_passed':True}))
