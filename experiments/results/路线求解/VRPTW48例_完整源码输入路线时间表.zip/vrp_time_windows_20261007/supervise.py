"""Hard cumulative CPU budget, exact child accounting and archivable package."""
import os,sys,time,resource,subprocess,json,hashlib,zipfile,datetime,math
from pathlib import Path
P=Path(__file__).resolve().parent
# Child workload aggregate <=110 CPU seconds; supervisor <=9, conservative <=119.
resource.setrlimit(resource.RLIMIT_CPU,(119,119))
started=time.monotonic();ledger=[];used=0.
for filename in ['workload.py']:
    remaining=math.floor(110-used)
    if remaining<=0:raise RuntimeError('Cumulative CPU budget exhausted')
    def limit():resource.setrlimit(resource.RLIMIT_CPU,(remaining,remaining))
    out=(P/(filename+'.stdout.log')).open('w');err=(P/(filename+'.stderr.log')).open('w')
    wall=time.monotonic();child=subprocess.Popen([sys.executable,str(P/filename)],stdout=out,stderr=err,preexec_fn=limit,cwd=P)
    resource.setrlimit(resource.RLIMIT_CPU,(9,9))
    pid,status,usage=os.wait4(child.pid,0);child.returncode=os.waitstatus_to_exitcode(status);out.close();err.close()
    cpu=usage.ru_utime+usage.ru_stime;used+=cpu
    item={'phase':filename,'exit_code':child.returncode,'cpu_user_seconds':usage.ru_utime,'cpu_system_seconds':usage.ru_stime,'cpu_total_seconds':cpu,'wall_seconds':time.monotonic()-wall,'os_hard_cpu_limit_seconds':remaining};ledger.append(item)
    print(json.dumps(item),flush=True)
    if child.returncode:break
account={'complete':len(ledger)==1 and all(x['exit_code']==0 for x in ledger),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'budget_seconds':120,'preworkload_setup_failure_cpu_seconds_shell':0.036,'preworkload_setup_failure':'Attempt00 inherited supervisor9s hard cap into child; child could not raise to110s. No generation, freeze, tests or solver ran. Original source/log preserved in attempts/attempt00. Fixed child launch order before first freeze.','aggregate_os_hard_upper_bound_seconds':119.036,'child_cpu_seconds_exact_wait4':used,'subprocesses':ledger,'supervisor_cpu_checkpoint_seconds':time.process_time(),'total_cpu_checkpoint_seconds':used+time.process_time(),'wall_seconds_checkpoint':time.monotonic()-started,'accounting_scope':'All generation, input/code freeze, independent unit tests, all48 solves, exact capacity-only diagnostic, six independent exhaustive cross-checks, summary/exports and post-run validation are included in exact wait4 child CPU. Supervisor metadata/hash/ZIP packaging has separate9s hard cap; final serialization tail occurs after checkpoint. Shell time log records full supervisor and children after exit. No pilot runs.'}
(P/'resource_accounting.json').write_text(json.dumps(account,indent=2)+'\n')
files=sorted(f for f in P.rglob('*') if f.is_file() and f.name not in ['archive_manifest.json','vrp_time_windows_20261007.zip','archive.sha256','shell_cpu.txt'])
manifest={str(f.relative_to(P)):{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in files}
(P/'archive_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=P/'vrp_time_windows_20261007.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for f in files+[P/'archive_manifest.json']:z.write(f,arcname='vrp_time_windows_20261007/'+str(f.relative_to(P)))
(P/'archive.sha256').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+archive.name+'\n')
print(json.dumps({'archive':str(archive),'archive_bytes':archive.stat().st_size,'all_completed':account['complete'],'children_cpu':used,'supervisor_cpu_after_packaging':time.process_time(),'observed_total_cpu_after_packaging':used+time.process_time(),'wall_after_packaging':time.monotonic()-started}),flush=True)
if not account['complete']:sys.exit(1)
