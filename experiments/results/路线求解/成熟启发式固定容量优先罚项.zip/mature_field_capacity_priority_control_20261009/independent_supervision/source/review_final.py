"""Final saved priority report cross-check, no native or optimizer imports."""
from audit_priority import *

def compare(a,s):
    require(a['status']=='SAVED_EVIDENCE_AUDITED'and len(a['rows'])==len(s['rows'])==144,'144 comparison rows')
    require(s['planned_formal_slots']==s['new_formal_cells']==s['planned_per_arm']==72 and s['planned_per_proxy_per_arm']==36 and s['field_denominator']==12,'new72 denominator')
    require(s['historical_reference_cells']==72 and s['total_comparison_rows']==144,'historical72 separate from new72')
    require(s['valid_feasible_slots']==a['valid_feasible_slots'],'new P valid count')
    for x,y in zip(a['rows'],s['rows']):
        for k in ROW_KEYS:require(type(x[k])is type(y[k])and x[k]==y[k],'row '+k)
        for k in('record_verified','routing_violation','diagnostic_base_E','diagnostic_base_G','observations','derived_penalty','initial_public_pm_snapshot_raw','first_iteration_integer_probes_raw','origin'):equal(x[k],y[k],'row detail '+k)
        if x['record_verified']:
            for k in('routes','loads'):require(x[k]==y[k],'route '+k)
    for k in SECTIONS:equal(a[k],s[k],k)
    require(s['formal_known_spawned']==a['ledger']['known_spawned']and s['formal_unknown_spawned_slots']==a['ledger']['unknown_spawned_slots'],'actual new call count')
    require(s['toy_solver_calls']==s['toy_model_instances']==2 and s['new_solver_calls_in_report']==s['new_native_constructions_in_report']==0,'prepared toys and saved-only report')
    return True

def main():
    resource.setrlimit(resource.RLIMIT_CPU,(15,15));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2));signal.alarm(60);receipt=gate();c=time.process_time();w=time.monotonic();a=load(ROOT/'independent_supervision/results/SAVED_PRIORITY_AUDIT.json');s=load(ROOT/'reports/SUMMARY.json')
    for x in(a,s):require(x['frozen_files_sha256']==receipt['frozen_files_sha256']and x['raw_archive_sha256']==receipt['sha256'],'source identity')
    require(s['independent_saved_audit_sha256']==sha(ROOT/'independent_supervision/results/SAVED_PRIORITY_AUDIT.json'),'independent audit binding');compare(a,s);text=(ROOT/'reports/REPORT_ZH.txt').read_text()
    for phrase in('72','36','250','初始化','历史','非同期','条件','泛化','预测'):require(phrase in text,'reader boundary '+phrase)
    r={'status':'PASS','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'frozen_files_sha256':receipt['frozen_files_sha256'],'raw_archive_sha256':receipt['sha256'],'report_sha256':sha(ROOT/'reports/REPORT_ZH.txt'),'summary_sha256':sha(ROOT/'reports/SUMMARY.json'),'independent_audit_sha256':sha(ROOT/'independent_supervision/results/SAVED_PRIORITY_AUDIT.json'),'planned_new_calls':72,'historical_cells':72,'total_comparison_rows':144,'valid_new_P':a['valid_feasible_slots'],'new_solver_calls':0,'new_native_constructions':0,'resources':{'cpu_seconds':time.process_time()-c,'wall_seconds':time.monotonic()-w}};save_exclusive(ROOT/'independent_supervision/results/FINAL_REPORT_REVIEW.json',r);print(json.dumps(r))
if __name__=='__main__':main()
