"""Independent fixed216 denominators and paired reductions from verified saved rows."""
from collections import Counter
import json
ARMS=('A','P');PAIRS=(('A','P'),)
METRICS=('normalized_own_cost','own_gap_mm','own_gap_percent','base_E','base_G','G_realized_excess_mm')
ROW_KEYS=('call_id','instance_id','proxy','seed','arm','scale','max_iterations','valid','base_E','base_G','normalized_own_cost','own_gap_mm','own_gap_percent','exact_hit','G_realized_excess_mm','E_offset_from_lex_reference_mm','E_optimal_tie_difference_mm')

def describe(values):return {'mean':sum(values)/len(values)if values else None,'min':min(values)if values else None,'max':max(values)if values else None}
def numbers(rows,complete):return {'count':len(rows),'complete':complete,'metrics':{m:describe([r[m]for r in rows])for m in METRICS}}
def observations(rows):
    initial={'feasible':0,'infeasible':0,'unknown':0};first=Counter();updates=Counter();never=0;unknown=0
    for row in rows:
        o=row.get('observations')
        if not isinstance(o,dict)or o.get('observed')is False:initial['unknown']+=1;unknown+=1;updates['unknown']+=1;continue
        state=o['initial_solution_feasible'];initial['feasible'if state is True else'infeasible'if state is False else'unknown']+=1
        i=o.get('first_best_feasible_iteration')
        if type(i)is int and 0<=i<=250:first[str(i)]+=1
        elif 'first_best_feasible_iteration'in o and i is None:never+=1
        else:unknown+=1
        count=o.get('pm_updates_observed');updates[str(count)if type(count)is int else'unknown']+=1
    return {'planned_denominator':len(rows),'initial_solution_feasibility':initial,'first_best_feasible_iteration_histogram':dict(sorted(first.items(),key=lambda p:int(p[0]))),'no_best_feasible_observed':never,'first_best_feasible_unknown':unknown,'pm_update_count_histogram':dict(updates),'scope':'Saved public callback observations only. No stage-specific causal attribution.'}
def arm_summary(rows):
    good=[r for r in rows if r['valid']];n=len(rows);v=len(good);hit=sum(r['exact_hit']for r in good)
    return {'planned':n,'valid_feasible':v,'failed_or_unverified':n-v,'verified_infeasible':sum(r['record_verified']and not r['valid']for r in rows),'technical_or_unverified':sum(not r['record_verified']for r in rows),'feasibility_rate_all_planned':v/n,'exact_hits':hit,'exact_hit_rate_all_planned':hit/n,'exact_hit_rate_valid_only':hit/v if v else None,'complete_panel':numbers(good,True)if v==n else None,'conditional_valid_subset':numbers(good,v==n),'observation_diagnostics':observations(rows),'raw_status_counts':dict(Counter(r['raw_status']for r in rows))}
def pair_row(left,right):
    ok=left['valid']and right['valid'];a=left['arm'];b=right['arm']
    return {'instance_id':left['instance_id'],'seed':left['seed'],'proxy':left['proxy'],'comparison':a+'_vs_'+b,'left_arm':a,'right_arm':b,'left_valid':left['valid'],'right_valid':right['valid'],'common_success':ok,'transition':('success'if left['valid']else'failure')+'_to_'+('success'if right['valid']else'failure'),'right_minus_left':{m:right[m]-left[m]if ok else None for m in METRICS},'delta_sign':'right minus left, in original units; quality is conditional on both succeeding'}
def pair_summary(rows):
    good=[r for r in rows if r['common_success']];n=len(rows);v=len(good);counts={k:0 for k in('success_to_success','success_to_failure','failure_to_success','failure_to_failure')};counts.update(Counter(r['transition']for r in rows));metrics={m:describe([r['right_minus_left'][m]for r in good])for m in METRICS}
    return {'planned_pairs':n,'common_success_count':v,'paired_success_transitions':counts,'descriptive_paired_risk_difference_right_minus_left':(counts['failure_to_success']-counts['success_to_failure'])/n,'complete_panel_mean_deltas':{m:metrics[m]['mean']if n==v else None for m in METRICS},'conditional_pair_common_success':{'denominator':v,'planned_denominator':n,'metrics':metrics}}
def group(rows):
    lookup={(r['instance_id'],r['seed'],r['proxy'],r['arm']):r for r in rows};keys=list(dict.fromkeys(k[:3]for k in lookup));assert len(lookup)==len(rows)==2*len(keys);assert all((*k,a)in lookup for k in keys for a in ARMS)
    pairs=[pair_row(lookup[(*k,'A')],lookup[(*k,'P')])for k in keys];failed=[lookup[(*k,'P')]for k in keys if not lookup[(*k,'A')]['valid']]
    return {'planned_slots':len(rows),'new_planned_slots':len(keys),'historical_reference_slots':len(keys),'planned_per_arm':len(keys),'arms':{a:arm_summary([lookup[(*k,a)]for k in keys])for a in ARMS},'pairs':{'A_vs_P':pair_summary(pairs)},'historical_failure_subgroup':{'planned':len(failed),'new_valid_feasible':sum(r['valid']for r in failed),'cost_difference_defined':False,'scope':'Descriptive pre-existing baseline-failure subgroup; every field/seed/proxy was treated, no rescue subset.','new_rows':[{'call_id':r['call_id'],'valid':r['valid'],'normalized_own_cost':r['normalized_own_cost'],'own_gap_mm':r['own_gap_mm'],'baseline_cost_delta':None}for r in failed]}}

def probes(rows):
    result={}
    for arm in ARMS:
        rr=[r for r in rows if r['arm']==arm];seen={};unknown=0
        for r in rr:
            a,b=r.get('initial_public_pm_snapshot_raw'),r.get('first_iteration_integer_probes_raw')
            if a is None or b is None:unknown+=1;continue
            item={'initial_public_pm_snapshot_raw':a,'first_iteration_integer_probes_raw':b};key=json.dumps(item,sort_keys=True,separators=(',',':'))
            if key not in seen:seen[key]={**item,'count':0}
            seen[key]['count']+=1
        result[arm]={'planned_denominator':len(rr),'available':len(rr)-unknown,'unknown':unknown,'observed_raw_signatures':list(seen.values())}
    return {'scope':'Raw saved first-iteration probes at violations1,2,7,1000; no normalization or hidden-double recovery.','by_arm':result}

def summarize(rows,fields):
    lookup={(r['instance_id'],r['seed'],r['proxy'],r['arm']):r for r in rows};expected={(f,s,p,a)for f in fields for s in range(3)for p in('E','G')for a in ARMS};assert len(rows)==len(lookup)==144 and set(lookup)==expected
    pairs=[pair_row(lookup[(f,s,p,'A')],lookup[(f,s,p,'P')])for f in fields for s in range(3)for p in('E','G')];pred=[]
    for r in rows:
        if r['arm']=='P':
            o=r.get('observations')or{};pred.append({'call_id':r['call_id'],'initialized_feasible':o.get('initial_solution_feasible'),'current_feasible_all250':o.get('source_prediction_current_feasible_all250_observed'),'returned_feasible':r['valid']if r['record_verified']else None})
    return {'overall':group(rows),'by_proxy':{p:group([r for r in rows if r['proxy']==p])for p in('E','G')},'per_field':[{'instance_id':f,'field_weight':1,'seed_count':3,'overall':group([r for r in rows if r['instance_id']==f]),'by_proxy':{p:group([r for r in rows if r['instance_id']==f and r['proxy']==p])for p in('E','G')}}for f in fields],'paired_rows':pairs,'first_iteration_probe_diagnostics':probes(rows),'new_P_source_prediction_observations':pred,'source_prediction_counts':{k:{'true':sum(r[k]is True for r in pred),'false':sum(r[k]is False for r in pred),'unknown':sum(r[k]is None for r in pred)}for k in('initialized_feasible','current_feasible_all250','returned_feasible')}}
