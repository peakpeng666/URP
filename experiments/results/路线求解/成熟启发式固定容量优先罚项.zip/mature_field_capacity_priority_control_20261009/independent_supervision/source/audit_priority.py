"""Independent saved newP72 plus fixed historicalA72 audit; no native imports."""
from priority_contract import *
from priority_summary import summarize,ROW_KEYS
import resource,signal,time,itertools
CONTROL_SHA='c6a04bb79f34a22761da1b7a8a84093529c99ee45761d976e69157caddc81377'
SECTIONS=('overall','by_proxy','per_field','paired_rows','first_iteration_probe_diagnostics','new_P_source_prediction_observations','source_prediction_counts')
def blank(e,status):
    r=dict(e);r.update(valid=False,failure=None,raw_status=status,record_verified=False,routing_violation=None,base_E=None,base_G=None,normalized_own_cost=None,diagnostic_base_E=None,diagnostic_base_G=None,own_gap_mm=None,own_gap_percent=None,exact_hit=False,G_realized_excess_mm=None,E_offset_from_lex_reference_mm=None,E_optimal_tie_difference_mm=None,offset_is_search_error=False,observations=None,derived_penalty=None,initial_public_pm_snapshot_raw=None,first_iteration_integer_probes_raw=None,saved_G_path_length_m=None,saved_G_path_legs=None,origin='historical_default_scale_A72'if e['arm']=='A'else'new_input_derived_P72');return r

def promote(r,v,answer,truth):
    r.update(record_verified=True,routing_violation=v['routing_violation'],diagnostic_base_E=v['base_E'],diagnostic_base_G=v['base_G'],observations=v['observations'],routes=v['routes'],loads=v['loads'],derived_penalty=v['derived_penalty'])
    if v['observations']['observed']:
        o=answer['penalty_observation'];r.update(initial_public_pm_snapshot_raw=o['initial_penalties'],first_iteration_integer_probes_raw=o['rows'][0]['observed_search_evaluator_integer_probes'])
    if not v['valid']:r['failure']='NO_FEASIBLE_INCUMBENT';return r
    require(answer['reported_cost']==v['normalized_own_cost'],'original integer cost');r.update(valid=True,base_E=v['base_E'],base_G=v['base_G'],normalized_own_cost=v['normalized_own_cost'],**endpoints(r['proxy'],{'E':v['base_E'],'G':v['base_G']},truth));return r

def historical_inputs(check_archive=False):
    d=ROOT/'historical_reference';m=load(d/'CONTROL_A72_ARCHIVE_IDENTITY.json');require(m['archive_sha256']==CONTROL_SHA and m['rows']==72,'immediate scale A72 source')
    require(sha(d/'DEFAULT_A72_OUTPUTS.json')==m['default_outputs_sha256']and sha(d/'DEFAULT_A72_REVIEWED_ROWS.json')==m['reviewed_rows_sha256'],'frozen control extraction bytes');items=load(d/'DEFAULT_A72_OUTPUTS.json');rr=load(d/'DEFAULT_A72_REVIEWED_ROWS.json');idx={(r['instance_id'],r['seed'],r['proxy']):r for r in rr};expect={(f,s,p)for f in FIELDS for s in range(3)for p in('E','G')};require(len(items)==len(rr)==72 and set(idx)==expect,'full historical72')
    members={x['call_id']:x for x in m['members']};require(len(members)==72,'all original source member identities')
    for item in items:
        e=item['entry'];z=members[e['call_id']];require(item['frozen_stdout']==z['frozen_stdout'],'local retained source path');b=(ROOT/item['frozen_stdout']).read_bytes();require(len(b)==z['bytes']and hashlib.sha256(b).hexdigest()==z['sha256']==item['raw_record']['stdout_sha256'],'control original bytes');require(json.loads(b)==item['output'],'wrapper source equality')
    if check_archive:
        require(sha(m['source_archive'])==CONTROL_SHA,'real downloaded scale FINAL identity')
        with zipfile.ZipFile(m['source_archive'])as z:
            prefix='mature_field_cost_scale_control_20261009/';s=json.loads(z.read(prefix+'reports/SUMMARY.json'));require([r for r in s['rows']if r['arm']=='A']==rr,'all72 original reviewed control rows')
            for v in members.values():require(z.read(v['archive_member'])==(ROOT/v['frozen_stdout']).read_bytes(),'original archive control stdout')
    return items,idx

def collect(schedule,slots,items,events,errors,outer,problems,truth,params,history,reviewed):
    ledger,by=audit_ledger(schedule,events,items,slots,errors,outer);rows=[]
    for e in schedule:
        cid=e['call_id'];slot=by.get(cid,{});r=blank(e,slot.get('status','MISSING_RESULT'))
        try:
            require(slot.get('status')in('UNREVIEWED_PROCESS_SUCCESS','UNREVIEWED_INFEASIBLE')and slot.get('process_spawned')is True and slot.get('child_reaped')is True and slot.get('returncode')==0 and not slot.get('error'),'completed call')
            require(slot['stdout']==f'raw/calls/{cid}.stdout'and slot['stderr']==f'raw/calls/{cid}.stderr','fixed paths')
            for key in('stdout','stderr'):require(sha(ROOT/slot[key])==slot[key+'_sha256'],'output bytes')
            require(not ledger['errors']and not ledger['per_call_errors'][cid],'chronological complete ledger');a=load(ROOT/slot['stdout']);p=problems[e['instance_id']];payload={k:p[k]for k in('coordinates','demands','capacity','K')};payload.update({k:e[k]for k in('seed','max_iterations','arm','scale','observe_penalties')});payload['distance_matrix']=p['matrices'][e['proxy']]
            require(hashlib.sha256(compact(payload)).hexdigest()==slot['payload_sha256'],'ten-key single-matrix payload');v=check_answer(p,e,a,params);require(v['valid']==(slot['status']=='UNREVIEWED_PROCESS_SUCCESS'),'retained status versus feasibility');promote(r,v,a,truth[e['instance_id']])
        except Exception as exc:r=blank(e,slot.get('status','MISSING_RESULT'));r['failure']=type(exc).__name__+':'+str(exc)
        rows.append(r)
    for item in history:
        e,a=item['entry'],item['output'];key=(e['instance_id'],e['seed'],e['proxy']);v=check_historical(problems[e['instance_id']],e,a,params);r=promote(blank(e,item['raw_record']['status']),v,a,truth[e['instance_id']])
        for k in ROW_KEYS:require(type(r[k])is type(reviewed[key][k])and r[k]==reviewed[key][k],'control endpoint unchanged '+k)
        rows.append(r)
    fields=list(dict.fromkeys(e['instance_id']for e in schedule));return {'status':'SAVED_EVIDENCE_AUDITED','planned_formal_slots':72,'planned_per_arm':72,'planned_per_proxy_per_arm':36,'field_denominator':12,'historical_reference_cells':72,'total_comparison_rows':144,'new_formal_cells':72,'rows':rows,'ledger':ledger,'valid_feasible_slots':sum(r['valid']for r in rows if r['arm']=='P'),'new_solver_calls':0,'new_native_constructions':0,**summarize(rows,fields)}

def main():
    resource.setrlimit(resource.RLIMIT_CPU,(60,60));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2));signal.alarm(120);receipt=gate();dest=ROOT/'independent_supervision/results';dest.mkdir(exist_ok=True);save_exclusive(dest/'SAVED_AUDIT_STARTED.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'new_solver_calls':0});c=time.process_time();w=time.monotonic();schedule=load(ROOT/'freeze/SCHEDULE.json');require(len(schedule)==72 and[(e['instance_id'],e['seed'],e['proxy'])for e in schedule]==list(itertools.product(FIELDS,range(3),('E','G'))),'fixed72 schedule');require(all(e['arm']=='P'and e['scale']==1 and e['max_iterations']==250 and e['observe_penalties']is True for e in schedule),'fixedP semantics')
    p,t,pre=source_inputs();history,reviewed=historical_inputs();events,ee=lines(ROOT/'raw/attempts.jsonl');items,ie=lines(ROOT/'raw/results.jsonl');params=load(ROOT/'environment/DEFAULT_SOLVE_PARAMS.json')['parameters'];a=collect(schedule,load(ROOT/'raw/ALL_PLANNED_SLOTS.json'),items,events,ee+ie,load(ROOT/'raw/EXECUTOR_FINISHED.json'),p,t,params,history,reviewed);a.update(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),frozen_files_sha256=receipt['frozen_files_sha256'],raw_archive_sha256=receipt['sha256'],control_archive_sha256=CONTROL_SHA,q5_final_sha256=Q5_SHA,resources={'cpu_seconds':time.process_time()-c,'wall_seconds':time.monotonic()-w,'maxrss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss});save_exclusive(dest/'SAVED_PRIORITY_AUDIT.json',a);print(json.dumps({'status':a['status'],'newP_valid':a['valid_feasible_slots'],'planned':72,'historicalA_valid':a['overall']['arms']['A']['valid_feasible']}))
if __name__=='__main__':main()
