"""Invented72 new/72 control saved-schema replay from two source toy families."""
import copy,itertools,json,pathlib,sys,zipfile,time,hashlib,resource,signal
import audit_priority as independent
from audit_priority import *
def write(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')
def main():
    resource.setrlimit(resource.RLIMIT_CPU,(60,60));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2));signal.alarm(120)
    base=ROOT;D=base/'independent_supervision/selftests/replay_r1';D.mkdir(exist_ok=False);c=time.process_time();w=time.monotonic();params=load(base/'environment/DEFAULT_SOLVE_PARAMS.json')['parameters'];toy=load(base/'selftests/toy/FIXTURE.json');problem=copy.deepcopy(toy);problem['matrices']['G']=copy.deepcopy(problem['matrices']['E']);fields=['INVENTED_PRIORITY_'+str(i)for i in range(12)];problems={f:dict(copy.deepcopy(problem),instance_id=f)for f in fields};truth={f:{'instance_id':f,'valid_for_exact_conclusion':True,'E_star':300002,'G_star':300002,'G_at_E_optimum':300002,'delta_integer_mm':0}for f in fields};newtemplate=load(base/'selftests/toy/raw/calls/TOY_P_OBS.stdout');oldtemplate=load(pathlib.Path('/workspace/shared/mature_field_cost_scale_control_20261009/selftests/toy/raw/calls/TOY_A_OBS.stdout'));schedule=[];slots=[];events=[];history=[];reviewed={};identities={}
    for f in fields:
        write(D/f'input/{f}.json',problems[f]);identities[f]={'input_sha256':sha(D/f'input/{f}.json')}
    for i,(f,seed,proxy)in enumerate(itertools.product(fields,range(3),('E','G')),1):
        e={'schedule_index':i,'call_id':f'{f}_{proxy}_s{seed}_P','instance_id':f,'proxy':proxy,'seed':seed,'arm':'P','scale':1,'observe_penalties':True,'max_iterations':250};schedule.append(e);a=copy.deepcopy(newtemplate);a['seed']=seed;out=f"raw/calls/{e['call_id']}.stdout";err=f"raw/calls/{e['call_id']}.stderr";write(D/out,a);(D/err).write_text('');p=problems[f];payload={k:p[k]for k in('coordinates','demands','capacity','K')};payload.update({k:e[k]for k in('seed','max_iterations','arm','scale','observe_penalties')});payload['distance_matrix']=p['matrices'][proxy];slot={'call_id':e['call_id'],'schedule':e,'status':'UNREVIEWED_PROCESS_SUCCESS','returncode':0,'process_spawned':True,'child_reaped':True,'stdout':out,'stderr':err,'stdout_sha256':sha(D/out),'stderr_sha256':sha(D/err),'payload_sha256':hashlib.sha256(compact(payload)).hexdigest()};slots.append(slot)
        for kind in('STARTED','FINISHED'):
            event={'event_kind':kind,'utc':'2026-10-09T00:00:00+00:00','call_id':e['call_id'],'schedule':e}
            if kind=='FINISHED':event['result']=slot
            events.append(event)
        old=copy.deepcopy(oldtemplate);old['seed']=seed;oe={**e,'call_id':f'{f}_{proxy}_s{seed}_A','arm':'A','min_penalty':.1,'max_penalty':100000.};rel=f"historical_reference/default_A72_raw/{oe['call_id']}.stdout";write(D/rel,old);record={'status':'UNREVIEWED_PROCESS_SUCCESS','stdout_sha256':sha(D/rel)};history.append({'entry':oe,'output':old,'raw_record':record,'frozen_stdout':rel});reviewed[(f,seed,proxy)]=promote(blank(oe,record['status']),check_historical(p,oe,old,params),old,truth[f])
    outer={'cleanup':{'quiescent':True},'known_spawned':72,'unknown_spawned_slots':0,'ledger_errors':[]};independent.ROOT=D;full=collect(schedule,slots,slots,events,[],outer,problems,truth,params,history,reviewed);require(full['valid_feasible_slots']==72,'all invented newP72')
    write(D/'environment/DEFAULT_SOLVE_PARAMS.json',{'parameters':params});write(D/'freeze/SCHEDULE.json',schedule);write(D/'raw/ALL_PLANNED_SLOTS.json',slots);write(D/'raw/EXECUTOR_FINISHED.json',outer);write(D/'input/IDENTITIES.json',{'fields':identities});write(D/'historical_reference/DEFAULT_A72_OUTPUTS.json',history);write(D/'historical_reference/DEFAULT_A72_REVIEWED_ROWS.json',list(reviewed.values()))
    with zipfile.ZipFile(D/'input/Q5_FINAL.zip','x',zipfile.ZIP_DEFLATED)as z:z.writestr('independent_supervision/FINAL_AUDIT.json',json.dumps({'status':'PASS','verified_fields':12,'fields':list(truth.values())}))
    write(D/'freeze/PROTOCOL.json',{'fields':fields,'input':{'archive':'input/Q5_FINAL.zip','sha256':sha(D/'input/Q5_FINAL.zip')},'toy_solver_calls':2,'toy_model_instances':2,'endpoints':{},'analysis':{}})
    sys.path.insert(0,str(base/'source'));import report as author;import endpoint_core,historical_endpoint_core,report_core
    author.ROOT=D;author.read=lambda rel:load(D/rel);author.verify_frozen=lambda:'INVENTED_ONLY';author.verify_old=lambda:0;author.receipt=lambda stage:{'sha256':'INVENTED_ONLY'};endpoint_core.read=historical_endpoint_core.read=author.read;their=author.collect_saved_evidence()
    for x,y in zip(full['rows'],their['rows']):
        for k in ROW_KEYS:require(type(x[k])is type(y[k])and x[k]==y[k],'row '+k)
    for k in SECTIONS:equal(full[k],their[k],k)
    broken=copy.deepcopy(slots);broken[0]['status']='PROCESS_FAILURE_OR_CPU_LIMIT';ev=copy.deepcopy(events);ev[1]['result']=broken[0];partial=collect(schedule,broken,broken,ev,[],outer,problems,truth,params,history,reviewed);require(partial['valid_feasible_slots']==71 and partial['overall']['arms']['P']['planned']==72 and partial['overall']['arms']['P']['complete_panel']is None,'new failure72 denominator');write(D/'raw/ALL_PLANNED_SLOTS.json',broken);other=author.collect_saved_evidence()
    for k in SECTIONS:equal(partial[k],other[k],k)
    mutation=copy.deepcopy(full['rows'])
    for r in [x for x in mutation if x['arm']=='A'][:12]:
        r.update(valid=False,exact_hit=False,routing_violation=True)
        for k in ('normalized_own_cost','own_gap_mm','own_gap_percent','base_E','base_G','G_realized_excess_mm','E_offset_from_lex_reference_mm','E_optimal_tie_difference_mm'):r[k]=None
    ours=summarize(mutation,fields);theirs=report_core.build_summary(mutation,fields)
    for k in SECTIONS:equal(ours[k],theirs[k],k)
    require(ours['overall']['historical_failure_subgroup']['planned']==12 and ours['overall']['pairs']['A_vs_P']['common_success_count']==60,'invented baseline failure subgroup')
    independent.ROOT=base;source_inputs();historical_inputs(check_archive=True)
    result={'status':'PASS','invented_new_slots':72,'invented_control_rows':72,'full_new_valid':72,'partial_new_valid':71,'invented_historical_failure_subgroup':12,'all_denominators_retained':True,'independent_author_sections_match':list(SECTIONS),'previous_source_fields_verified':12,'control_A_raw_cells_verified':72,'new_native_constructions':0,'new_solver_calls':0,'resources':{'cpu_seconds':time.process_time()-c,'wall_seconds':time.monotonic()-w}};write(base/'independent_supervision/selftests/SAVED_PRIORITY_REPLAY_R1.json',result);print(json.dumps(result))
if __name__=='__main__':main()
