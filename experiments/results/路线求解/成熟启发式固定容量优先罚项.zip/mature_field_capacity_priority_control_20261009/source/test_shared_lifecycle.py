"""Same reviewed pure-sleep death-chain/quiescence checks with local helper bytes."""
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
from common import ROOT, save, read, sha, now
from process_lifecycle import parent_death
from execute_and_seal import stop_process_group

DEST = ROOT / 'selftests/lifecycle_sync'


def worker():
    save(DEST / 'worker.json', {'pid': os.getpid()})
    time.sleep(30)


def supervisor():
    save(DEST / 'supervisor.json', {'pid': os.getpid()})
    parent = os.getpid()
    proc = subprocess.Popen([sys.executable, '-B', __file__, 'worker'], preexec_fn=lambda: parent_death(parent))
    proc.wait()


def outer():
    save(DEST / 'outer.json', {'pid': os.getpid()})
    parent = os.getpid()
    proc = subprocess.Popen([sys.executable, '-B', __file__, 'supervisor'], preexec_fn=lambda: parent_death(parent), start_new_session=True)
    proc.wait()


def alive(pid):
    try:
        text = Path('/proc', str(pid), 'stat').read_text()
        return text[text.rfind(')') + 2:].split()[0] not in ('Z', 'X')
    except FileNotFoundError:
        return False


def main():
    DEST.mkdir(exist_ok=False)
    proc = subprocess.Popen([sys.executable, '-B', __file__, 'outer'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    try:
        deadline = time.monotonic() + 5
        while not (DEST / 'worker.json').exists() and time.monotonic() < deadline:
            time.sleep(0.01)
        assert (DEST / 'worker.json').exists()
        pids = [read('selftests/lifecycle_sync/' + label + '.json')['pid'] for label in ('outer', 'supervisor', 'worker')]
        proc.kill()
        proc.wait()
        deadline = time.monotonic() + 3
        while any(alive(pid) for pid in pids) and time.monotonic() < deadline:
            time.sleep(0.01)
        assert not any(alive(pid) for pid in pids)
    finally:
        if proc.poll() is None:
            proc.kill()
        proc.wait()
    sleeping = subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(30)'], start_new_session=True)
    try:
        try:
            sleeping.wait(timeout=0.15)
        except subprocess.TimeoutExpired:
            pass
        cleanup = stop_process_group(sleeping)
        assert cleanup['quiescent'] and cleanup['remaining_group_members'] == []
    finally:
        stop_process_group(sleeping)
    save(ROOT / 'selftests/LIFECYCLE_SYNC.json', {'status': 'PASS', 'utc': now(), 'solver_calls': 0, 'model_constructions': 0,
         'helper_sha256': sha(ROOT / 'source/process_lifecycle.py'),
         'checks': {'PDEATHSIG_chain_after_outer_SIGKILL': True, 'post_killpg_group_quiescence': True},
         'scope': 'Reviewed shared helper unchanged. Pure sleeping subprocesses, both parent PIDs captured before fork; no native optimization fixture.'})
    print('PASS same shared pure-sleep PDEATHSIG chain and group quiescence; zero solver calls')


if __name__ == '__main__':
    if len(sys.argv) == 1:
        main()
    else:
        globals()[sys.argv[1]]()
