"""Replay only the two authorized saved toys and adverse dictionary mutations."""
import copy,json,resource,signal
from common import ROOT,read,save,now
from gates import get_schedule,verify_toy_freeze
from endpoint_core import validate_saved
from ledger import reconcile

def main():
    resource.setrlimit(resource.RLIMIT_CPU,(30,30));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2));signal.alarm(120)
    verify_toy_freeze();p=read('selftests/toy/FIXTURE.json');schedule=get_schedule('toy');slots=read('selftests/toy/raw/ALL_PLANNED_SLOTS.json')
    answers=[read(s['stdout'])for s in slots]
    assert all(validate_saved(p,e,a)['normalized_own_cost']==300002 for e,a in zip(schedule,answers))
    cases=[]
    def rejects(label,mutate):
        x=copy.deepcopy(answers[0]);mutate(x)
        try:validate_saved(p,schedule[0],x)
        except(AssertionError,KeyError,TypeError,ValueError):cases.append(label);return
        raise AssertionError('ACCEPTED_BAD_SAVED_OUTPUT:'+label)
    rejects('wrong_input_derived_P',lambda x:x['derived_penalty'].__setitem__('P',450000))
    rejects('wrong_P_max',lambda x:x['default_solve_params']['values']['penalty']['values'].__setitem__('max_penalty',450000.0))
    rejects('wrong_P_min',lambda x:x['default_solve_params']['values']['penalty']['values'].__setitem__('min_penalty',0.1))
    rejects('noninteger_matrix',lambda x:x['native_distance_matrix'][0].__setitem__(1,75000.0))
    rejects('wrong_capacity',lambda x:x['native_model_parameters']['vehicle'].__setitem__('capacity',[4]))
    rejects('unexpected_PM_update',lambda x:x['penalty_observation']['rows'][20]['observed_post_registration_penalties'][0].__setitem__(0,900000))
    rejects('integer_probe_changed',lambda x:x['penalty_observation']['rows'][0]['observed_search_evaluator_integer_probes'][1].__setitem__('load',900000))
    rejects('wrong_update_interval',lambda x:x['default_solve_params']['values']['penalty']['values'].__setitem__('solutions_between_updates',50))
    rejects('missing_customer',lambda x:x['routes'][0].pop(1))
    missing,errors=reconcile(schedule,'','');assert len(missing)==2 and not errors
    _,errors=reconcile(schedule,'\n'.join(json.dumps(slots[0])for _ in range(2)),'')
    assert 'DUPLICATE_RESULT:'+slots[0]['call_id']in errors
    report={'status':'PASS','utc':now(),'solver_calls':0,'native_constructions':0,'saved_toy_outputs_replayed':2,'rejected_mutations':cases,'ledger_missing_retained':2,'ledger_duplicates_rejected':True}
    save(ROOT/'selftests/SAVED_CONTRACT_REPLAY.json',report);print(json.dumps(report))
if __name__=='__main__':main()
