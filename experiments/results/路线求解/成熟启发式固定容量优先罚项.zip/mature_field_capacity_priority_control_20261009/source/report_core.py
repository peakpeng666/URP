"""Pure saved-result endpoints: fixed historical A72 versus new P72; standard library only.

No optimization, native model construction, path search, or solver import is used.
Every scientific cost is in the original integer units, after exact scale removal.
"""
from collections import Counter
import json

ARMS = ('A', 'P')
PAIRS = (('A', 'P'),)
METRICS = ('normalized_own_cost', 'own_gap_mm', 'own_gap_percent',
           'base_E', 'base_G', 'G_realized_excess_mm')
ROW_AUDIT_KEYS = ('call_id', 'instance_id', 'proxy', 'seed', 'arm', 'scale',
                  'max_iterations', 'valid', 'base_E', 'base_G',
                  'normalized_own_cost', 'own_gap_mm', 'own_gap_percent',
                  'exact_hit', 'G_realized_excess_mm',
                  'E_offset_from_lex_reference_mm', 'E_optimal_tie_difference_mm')
STATS_KEYS = ('current_cost', 'current_feas', 'candidate_cost', 'candidate_feas',
              'best_cost', 'best_feas')
TERMINAL_KEYS = ('routes', 'reported_cost', 'reported_distance',
                 'solver_is_feasible', 'solver_is_complete',
                 'native_model_parameters', 'model_matrix_sha256')


def blank_row(entry, raw_status):
    row = dict(entry)
    row['origin']='historical_default_scale_A72' if entry['arm']=='A' else 'new_input_derived_P72'
    row['derived_penalty']=None
    row.update(valid=False, failure=None, raw_status=raw_status,
               record_verified=False, routing_violation=None,
               base_E=None, base_G=None, normalized_own_cost=None,
               diagnostic_base_E=None, diagnostic_base_G=None,
               own_gap_mm=None, own_gap_percent=None, exact_hit=False,
               G_realized_excess_mm=None, E_offset_from_lex_reference_mm=None,
               E_optimal_tie_difference_mm=None, offset_is_search_error=False,
               observations=None, initial_public_pm_snapshot_raw=None,
               first_iteration_integer_probes_raw=None, saved_G_path_length_m=None,
               saved_G_path_legs=None)
    return row


def apply_checked(row, checked, oracle, answer):
    """Promote only independently checked feasible output to scientific endpoints."""
    assert type(checked['valid']) is bool
    assert type(checked['routing_violation']) is bool
    row.update(record_verified=True, routing_violation=checked['routing_violation'],
               diagnostic_base_E=checked['base_E'], diagnostic_base_G=checked['base_G'],
               observations=checked['observations'], routes=checked['routes'],
               loads=checked['loads'])
    row['derived_penalty']=answer.get('derived_penalty')
    raw_observation = answer.get('penalty_observation')
    if checked['observations'].get('observed') is True and isinstance(raw_observation, dict):
        row['initial_public_pm_snapshot_raw'] = raw_observation.get('initial_penalties')
        saved_observations = raw_observation.get('rows', [])
        if saved_observations and saved_observations[0].get('iteration') == 1:
            row['first_iteration_integer_probes_raw'] = saved_observations[0].get('observed_search_evaluator_integer_probes')
    if not checked['valid']:
        assert checked['normalized_own_cost'] is None
        row['failure'] = 'NO_FEASIBLE_INCUMBENT'
        return row
    assert checked['routing_violation'] is False
    assert oracle['valid_for_exact_conclusion'] is True
    scale = row['scale']
    assert type(scale) is int and scale == 1
    reported = answer['reported_cost']
    assert type(reported) is int and reported % scale == 0, 'NONEXACT_COST_SCALE_REMOVAL'
    own = reported // scale
    assert type(checked['normalized_own_cost']) is int
    assert own == checked['normalized_own_cost'] == checked['base_' + row['proxy']]
    assert all(type(checked['base_' + p]) is int for p in ('E', 'G'))
    optimum = oracle[row['proxy'] + '_star']
    assert type(optimum) is int and optimum > 0
    gap = own - optimum
    assert gap >= 0, 'NEGATIVE_OWN_OBJECTIVE_GAP'
    excess = checked['base_G'] - oracle['G_star']
    assert excess >= 0, 'NEGATIVE_G_REALIZED_EXCESS'
    offset = checked['base_G'] - oracle['G_at_E_optimum'] if row['proxy'] == 'E' else None
    tie = offset if row['proxy'] == 'E' and gap == 0 else None
    if row['proxy'] == 'E':
        assert excess == offset + oracle['delta_integer_mm']
    if tie is not None:
        assert tie >= 0, 'NEGATIVE_E_OPTIMAL_TIE_DIFFERENCE'
    row.update(valid=True, base_E=checked['base_E'], base_G=checked['base_G'],
               normalized_own_cost=own, own_gap_mm=gap,
               own_gap_percent=100 * gap / optimum, exact_hit=gap == 0,
               G_realized_excess_mm=excess, E_offset_from_lex_reference_mm=offset,
               E_optimal_tie_difference_mm=tie)
    return row


def metric_summary(rows, complete):
    result = {}
    for metric in METRICS:
        values = [r[metric] for r in rows]
        assert all(value is not None for value in values)
        result[metric] = {'mean': sum(values) / len(values) if values else None,
                          'min': min(values) if values else None,
                          'max': max(values) if values else None}
    return {'count': len(rows), 'complete': complete, 'metrics': result}


def summarize_arm(rows):
    assert rows
    good = [r for r in rows if r['valid']]
    hits = sum(r['exact_hit'] for r in good)
    complete = len(good) == len(rows)
    return {'planned': len(rows), 'valid_feasible': len(good),
            'failed_or_unverified': len(rows) - len(good),
            'verified_infeasible': sum(r['record_verified'] and not r['valid'] for r in rows),
            'technical_or_unverified': sum(not r['record_verified'] for r in rows),
            'feasibility_rate_all_planned': len(good) / len(rows),
            'exact_hits': hits, 'exact_hit_rate_all_planned': hits / len(rows),
            'exact_hit_rate_valid_only': hits / len(good) if good else None,
            'complete_panel': metric_summary(good, True) if complete else None,
            'conditional_valid_subset': metric_summary(good, complete),
            'observation_diagnostics': summarize_observations(rows),
            'raw_status_counts': dict(Counter(r['raw_status'] for r in rows))}


def summarize_observations(rows):
    initial = {'feasible': 0, 'infeasible': 0, 'unknown': 0}
    first, unknown, never = Counter(), 0, 0
    updates = Counter()
    for row in rows:
        obs = row.get('observations')
        if not isinstance(obs, dict) or obs.get('observed') is False:
            initial['unknown'] += 1
            unknown += 1
            updates['unknown'] += 1
            continue
        value = obs.get('initial_solution_feasible')
        initial['feasible' if value is True else 'infeasible' if value is False else 'unknown'] += 1
        iteration = obs.get('first_best_feasible_iteration')
        if type(iteration) is int and 0 <= iteration <= 250:
            first[str(iteration)] += 1
        elif 'first_best_feasible_iteration' in obs and iteration is None:
            never += 1
        else:
            unknown += 1
        value = obs.get('pm_updates_observed')
        updates[str(value) if type(value) is int else 'unknown'] += 1
    return {'planned_denominator': len(rows), 'initial_solution_feasibility': initial,
            'first_best_feasible_iteration_histogram': dict(sorted(first.items(), key=lambda pair: int(pair[0]))),
            'no_best_feasible_observed': never, 'first_best_feasible_unknown': unknown,
            'pm_update_count_histogram': dict(updates),
            'scope': 'Saved public callback observations only. No stage-specific causal attribution.'}


def summarize_first_probes(rows):
    """Count every arm's saved raw initial snapshot/probe signature, no scaling."""
    by_arm = {}
    for arm in ARMS:
        selected = [row for row in rows if row['arm'] == arm]
        signatures, examples, unknown = Counter(), {}, 0
        for row in selected:
            snapshot, probes = row.get('initial_public_pm_snapshot_raw'), row.get('first_iteration_integer_probes_raw')
            if snapshot is None or probes is None:
                unknown += 1
                continue
            value = {'initial_public_pm_snapshot_raw': snapshot,
                     'first_iteration_integer_probes_raw': probes}
            key = json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)
            signatures[key] += 1
            examples[key] = value
        by_arm[arm] = {'planned_denominator': len(selected), 'available': len(selected) - unknown,
                       'unknown': unknown,
                       'observed_raw_signatures': [{**examples[key], 'count': count} for key, count in signatures.items()]}
    return {'scope': 'Raw saved first-iteration probes at violations1,2,7,1000; no normalization or hidden-double recovery.',
            'by_arm': by_arm}


def make_pair(left, right):
    assert (left['instance_id'], left['seed'], left['proxy']) == (right['instance_id'], right['seed'], right['proxy'])
    common = left['valid'] and right['valid']
    return {'instance_id': left['instance_id'], 'seed': left['seed'], 'proxy': left['proxy'],
            'comparison': left['arm'] + '_vs_' + right['arm'],
            'left_arm': left['arm'], 'right_arm': right['arm'],
            'left_valid': left['valid'], 'right_valid': right['valid'],
            'common_success': common,
            'transition': ('success' if left['valid'] else 'failure') + '_to_' + ('success' if right['valid'] else 'failure'),
            'right_minus_left': {m: right[m] - left[m] if common else None for m in METRICS},
            'delta_sign': 'right minus left, in original units; quality is conditional on both succeeding'}


def summarize_pairs(pairs):
    assert pairs
    common = [p for p in pairs if p['common_success']]
    transitions = {key: 0 for key in ('success_to_success', 'success_to_failure', 'failure_to_success', 'failure_to_failure')}
    transitions.update(Counter(p['transition'] for p in pairs))
    metrics = {m: {'mean': sum(p['right_minus_left'][m] for p in common) / len(common) if common else None,
                   'min': min(p['right_minus_left'][m] for p in common) if common else None,
                   'max': max(p['right_minus_left'][m] for p in common) if common else None}
               for m in METRICS}
    return {'planned_pairs': len(pairs), 'common_success_count': len(common),
            'paired_success_transitions': transitions,
            'descriptive_paired_risk_difference_right_minus_left':
                (transitions['failure_to_success'] - transitions['success_to_failure']) / len(pairs),
            'complete_panel_mean_deltas': {m: metrics[m]['mean'] if len(common) == len(pairs) else None for m in METRICS},
            'conditional_pair_common_success': {'denominator': len(common), 'planned_denominator': len(pairs), 'metrics': metrics}}


def summarize_group(rows):
    """One frozen historical A and one new P per key; no silent cell dropping."""
    lookup={(r['instance_id'],r['seed'],r['proxy'],r['arm']):r for r in rows}
    assert len(lookup)==len(rows)
    keys=list(dict.fromkeys((r['instance_id'],r['seed'],r['proxy'])for r in rows))
    assert len(rows)==2*len(keys)
    assert all((*key,a)in lookup for key in keys for a in ARMS)
    pairs=[make_pair(lookup[(*key,'A')],lookup[(*key,'P')])for key in keys]
    previously_failed=[lookup[(*key,'P')]for key in keys if not lookup[(*key,'A')]['valid']]
    return {'planned_slots':len(rows),'new_planned_slots':len(keys),'historical_reference_slots':len(keys),
            'planned_per_arm':len(keys),'arms':{a:summarize_arm([lookup[(*key,a)]for key in keys])for a in ARMS},
            'pairs':{'A_vs_P':summarize_pairs(pairs)},
            'historical_failure_subgroup':{'planned':len(previously_failed),'new_valid_feasible':sum(r['valid']for r in previously_failed),
                'cost_difference_defined':False,'scope':'Descriptive pre-existing baseline-failure subgroup; every field/seed/proxy was treated, no rescue subset.',
                'new_rows':[{'call_id':r['call_id'],'valid':r['valid'],'normalized_own_cost':r['normalized_own_cost'],'own_gap_mm':r['own_gap_mm'],'baseline_cost_delta':None}for r in previously_failed]}}


def build_summary(rows,fields):
    assert len(fields)==len(set(fields))==12
    assert len(rows)==len({r['call_id']for r in rows})==144
    expected={(f,s,p,a)for f in fields for s in (0,1,2)for p in ('E','G')for a in ARMS}
    lookup={(r['instance_id'],r['seed'],r['proxy'],r['arm']):r for r in rows}
    assert set(lookup)==expected and all(r['max_iterations']==250 for r in rows)
    for row in rows:
        if not row['valid']:
            assert all(row[m]is None for m in METRICS)
            assert row['exact_hit']is False
    pairs=[make_pair(lookup[(f,s,p,'A')],lookup[(f,s,p,'P')])for f in fields for s in (0,1,2)for p in ('E','G')]
    treated=[r for r in rows if r['arm']=='P']
    predictions=[]
    for r in treated:
        obs=r.get('observations')or{}
        predictions.append({'call_id':r['call_id'],'initialized_feasible':obs.get('initial_solution_feasible'),
                            'current_feasible_all250':obs.get('source_prediction_current_feasible_all250_observed'),
                            'returned_feasible':r['valid']if r['record_verified']else None})
    return {'overall':summarize_group(rows),
            'pooled_own_objective_metrics_scope':'Overall own-cost/gap mixes E and G objectives; by_proxy is the primary quality comparison.',
            'first_iteration_probe_diagnostics':summarize_first_probes(rows),
            'by_proxy':{p:summarize_group([r for r in rows if r['proxy']==p])for p in ('E','G')},
            'per_field':[{'instance_id':f,'field_weight':1,'seed_count':3,
                'overall':summarize_group([r for r in rows if r['instance_id']==f]),
                'by_proxy':{p:summarize_group([r for r in rows if r['instance_id']==f and r['proxy']==p])for p in ('E','G')}}for f in fields],
            'paired_rows':pairs,'new_P_source_prediction_observations':predictions,
            'source_prediction_counts':{k:{'true':sum(r[k]is True for r in predictions),'false':sum(r[k]is False for r in predictions),'unknown':sum(r[k]is None for r in predictions)}for k in ('initialized_feasible','current_feasible_all250','returned_feasible')}}
