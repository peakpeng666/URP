"""Readback-gated saved-only report for the 72 new fixed-P slots and72 frozen historical defaults."""
import json
import math
import resource
import signal
import zipfile
from pathlib import Path
from collections import Counter
from common import ROOT, read, save, sha, now, verify_frozen, verify_old, receipt
from report_core import (ARMS, ROW_AUDIT_KEYS, blank_row, apply_checked,
                         build_summary)


def exact_match(expected, actual, path='root'):
    """Compare all supplied independent fields; float tolerance only for summaries."""
    if isinstance(expected, dict):
        assert isinstance(actual, dict), path
        for key, value in expected.items():
            assert key in actual, path + '.' + key
            exact_match(value, actual[key], path + '.' + key)
    elif isinstance(expected, list):
        assert isinstance(actual, list) and len(expected) == len(actual), path
        for idx, (left, right) in enumerate(zip(expected, actual)):
            exact_match(left, right, path + '[' + str(idx) + ']')
    elif isinstance(expected, float):
        assert type(actual) in (float, int) and math.isclose(expected, actual, rel_tol=1e-12, abs_tol=1e-12), path
    else:
        assert type(expected) is type(actual) and expected == actual, path


def safe_output(relative):
    path = (ROOT / relative).resolve()
    assert path.is_relative_to((ROOT / 'raw/calls').resolve()), 'OUTPUT_PATH_OUTSIDE_RAW_CALLS'
    return path


def collect_saved_evidence():
    # This import is intentionally delayed: endpoint_core is a pure saved-data
    # validator, never the observer/worker/native implementation.
    from endpoint_core import validate_saved
    digest = verify_frozen()
    verify_old()
    raw = receipt('RAW_UNREVIEWED')
    protocol, schedule = read('freeze/PROTOCOL.json'), read('freeze/SCHEDULE.json')
    slots, outer = read('raw/ALL_PLANNED_SLOTS.json'), read('raw/EXECUTOR_FINISHED.json')
    assert len(schedule) == len(slots) == 72
    assert [slot['schedule'] for slot in slots] == schedule
    assert [slot['call_id'] for slot in slots] == [e['call_id'] for e in schedule]
    assert outer['cleanup']['quiescent'] is True
    assert sha(ROOT / protocol['input']['archive']) == protocol['input']['sha256']
    with zipfile.ZipFile(ROOT / protocol['input']['archive']) as archive:
        exact = json.loads(archive.read('independent_supervision/FINAL_AUDIT.json'))
    assert exact['status'] == 'PASS' and exact['verified_fields'] == 12
    oracles = {r['instance_id']: r for r in exact['fields']}
    assert len(oracles) == 12 and set(oracles) == set(protocol['fields'])
    identities = read('input/IDENTITIES.json')['fields']
    problems = {}
    for field in protocol['fields']:
        relative = 'input/' + field + '.json'
        assert sha(ROOT / relative) == identities[field]['input_sha256']
        problems[field] = read(relative)
    rows, answers = [], {}
    for entry, slot in zip(schedule, slots):
        row = blank_row(entry, slot['status'])
        answer = None
        try:
            assert slot['status'] in ('UNREVIEWED_PROCESS_SUCCESS', 'UNREVIEWED_INFEASIBLE'), 'NON_SUCCESS_PROCESS_STATUS'
            assert slot['returncode'] == 0 and slot['process_spawned'] is True and slot['child_reaped'] is True
            stdout, stderr = safe_output(slot['stdout']), safe_output(slot['stderr'])
            assert sha(stdout) == slot['stdout_sha256'] and sha(stderr) == slot['stderr_sha256'], 'RAW_OUTPUT_HASH_MISMATCH'
            answer = json.loads(stdout.read_text())
            assert not outer['ledger_errors'], 'LEDGER_INTEGRITY_FAILURE'
            checked = validate_saved(problems[entry['instance_id']], entry, answer)
            assert checked['valid'] == (slot['status'] == 'UNREVIEWED_PROCESS_SUCCESS'), 'STATUS_FEASIBILITY_MISMATCH'
            apply_checked(row, checked, oracles[entry['instance_id']], answer)
        except (AssertionError, KeyError, TypeError, ValueError, OSError, IndexError, OverflowError) as exc:
            # An endpoint failure cannot leave a partially promoted scientific row.
            row = blank_row(entry, slot['status'])
            row['failure'] = type(exc).__name__ + ':' + str(exc)
        answers[(entry['instance_id'], entry['seed'], entry['proxy'], entry['arm'])] = answer
        rows.append(row)
    # Historical A is revalidated using its frozen original endpoint code,
    # including original 60-second supervisor inheritance, never passed to P workers.
    from historical_endpoint_core import validate_saved as validate_historical
    history=read('historical_reference/DEFAULT_A72_OUTPUTS.json')
    reviewed=read('historical_reference/DEFAULT_A72_REVIEWED_ROWS.json')
    historical_lookup={(r['instance_id'],r['seed'],r['proxy']):r for r in reviewed}
    expected_history={(f,s,p)for f in protocol['fields']for s in (0,1,2)for p in ('E','G')}
    assert len(history)==len(reviewed)==72 and set(historical_lookup)==expected_history
    history_keys=set()
    for item in history:
        entry,answer=item['entry'],item['output']; key=(entry['instance_id'],entry['seed'],entry['proxy'])
        assert key not in history_keys and entry['arm']=='A' and entry['scale']==1
        history_keys.add(key)
        record=item['raw_record']; source=(ROOT/item['frozen_stdout']).resolve()
        assert source.is_relative_to((ROOT/'historical_reference/default_A72_raw').resolve())
        assert source.stat().st_size>0 and sha(source)==record['stdout_sha256']
        assert json.loads(source.read_text())==answer
        row=blank_row(entry,record['status'])
        checked=validate_historical(problems[entry['instance_id']],entry,answer)
        apply_checked(row,checked,oracles[entry['instance_id']],answer)
        previous=historical_lookup[key]
        for column in ROW_AUDIT_KEYS:
            assert row[column]==previous[column],('HISTORICAL_ENDPOINT_DRIFT',key,column)
        rows.append(row)
    assert history_keys==expected_history
    summary = build_summary(rows, protocol['fields'])
    return {'utc': now(), 'status': 'AUTHOR_SAVED_REPORT_COMPLETE_PENDING_INDEPENDENT_REVIEW',
            'frozen_files_sha256': digest, 'raw_archive_sha256': raw['sha256'],
            'q5_final_sha256': protocol['input']['sha256'],
            'planned_formal_slots': 72, 'planned_per_arm': 72, 'planned_per_proxy_per_arm': 36,
            'field_denominator': 12, 'seeds_per_field': 3,
            'valid_feasible_slots': sum(row['valid'] for row in rows if row['arm']=='P'),
            'raw_status_counts': dict(Counter(row['raw_status'] for row in rows if row['arm']=='P')),
            'formal_known_spawned': outer['known_spawned'],
            'formal_unknown_spawned_slots': outer['unknown_spawned_slots'],
            'toy_solver_calls': protocol['toy_solver_calls'], 'toy_model_instances': protocol['toy_model_instances'],
            'new_solver_calls_in_report': 0, 'new_native_constructions_in_report': 0,
            'rows': rows, **summary,
            'historical_reference_cells':72,'total_comparison_rows':144,'new_formal_cells':72,
            'historical_control_design':'Fixed noncontemporaneous historical control, not fresh randomized control.',
            'ledger_errors': outer['ledger_errors'],
            'endpoint_definitions': protocol['endpoints'], 'analysis_limits': protocol['analysis'],
            'saved_G_path_evidence': 'Reuse frozen Q5 canonical paths and existing legality/length audits; no new geometry, shortest paths, or physical field scaling.',
            'complete_panel_policy': 'Any invalid or missing required slot makes the corresponding complete-panel cost/gap statistic null.',
            'primary_statistical_unit': '12 previously observed fields. The three seeds and two proxies are repeated measurements, not independent fields.'}


def check_independent(data, audit):
    assert audit['status'] == 'SAVED_EVIDENCE_AUDITED'
    assert audit['raw_archive_sha256'] == data['raw_archive_sha256']
    assert audit['frozen_files_sha256'] == data['frozen_files_sha256']
    assert len(audit['rows']) == len(data['rows']) == 144
    expected = {r['call_id']: r for r in audit['rows']}
    assert len(expected) == len({r['call_id'] for r in data['rows']}) == 144
    assert set(expected) == {r['call_id'] for r in data['rows']}
    for row in data['rows']:
        other = expected[row['call_id']]
        for key in ROW_AUDIT_KEYS:
            # Exact row endpoints have matching computations, not tolerance.
            assert type(row[key]) is type(other[key]) and row[key] == other[key], (row['call_id'], key)
    compared = ['rows']
    for key in ('overall','by_proxy','per_field','paired_rows','first_iteration_probe_diagnostics','new_P_source_prediction_observations','source_prediction_counts'):
        if key in audit:
            exact_match(audit[key], data[key], key)
            compared.append(key)
    return compared


def report_text(data):
    lines=['输入派生容量优先配置与路线质量：新增72格、固定历史默认对照72格',
           '研究问题是在当前12客户、单位需求、Q5且至多3车模型上保持已可行初始化，并衡量路线质量代价。',
           '唯一预选P=(n+K)maxedge+1=15maxedge+1；公开min=max同时改变全部罚项通道，当前只有容量可能违约。',
           '新P处理固定250次ILS；默认A72来自刚完成尺度线，属于非同期历史对照。初始化在250计数之前。',
           '源码预测与运行观察分开；原始随机4/4/4由源码推出，callback只看到随后初始化结果。',
           '所有72预选格均保留，E/G各36，田块12；失败成本/gap为null，不补跑，不作速度、显著性或泛化结论。','']
    for arm in ARMS:
        cell=data['overall']['arms'][arm]
        label='历史默认A'if arm=='A'else'新容量优先P'
        lines.append(f"{label}：有效可行{cell['valid_feasible']}/72，精确命中{cell['exact_hits']}/72；完整面板成本{'可计算'if cell['complete_panel']else'为null'}。")
        for proxy in ('E','G'):
            c=data['by_proxy'][proxy]['arms'][arm]; full=c['complete_panel']
            gap=full['metrics']['own_gap_mm']['mean']if full else None
            lines.append(f"  {proxy}：可行{c['valid_feasible']}/36，精确命中{c['exact_hits']}/36，完整均值gap={gap}mm；有效子集分母{c['valid_feasible']}。")
    pair=data['overall']['pairs']['A_vs_P']
    lines+=['',f"全72对可行状态迁移：{pair['paired_success_transitions']}。",
            f"质量差方向P-A，仅双方成功{pair['common_success_count']}/72对定义；完整72对均值成本差={pair['complete_panel_mean_deltas']['normalized_own_cost']}。"]
    for proxy in ('E','G'):
        pair=data['by_proxy'][proxy]['pairs']['A_vs_P']; q=pair['conditional_pair_common_success']
        lines.append(f"{proxy}共同成功{q['denominator']}/36：条件均值自身成本差={q['metrics']['normalized_own_cost']['mean']}mm，自身gap差={q['metrics']['own_gap_mm']['mean']}mm。")
    sub=data['overall']['historical_failure_subgroup']
    lines += [f"历史默认失败{sub['planned']}格中，新P可行{sub['new_valid_feasible']}格；这些格只报告新P成本/精确gap，不定义相对默认失败的成本改善。",'',
              f"新P源码不变式观察计数：{data['source_prediction_counts']}。",'',
              '解释边界：',
              '- 罚后字典序证明限完整覆盖、最多3条单趟路线、非负距离、没有其它有效费用或约束。缺客户中间状态不属于定理。',
              '- 原始4/4/4随机解已可行；版本源码说明exhaustive初始化的有效算子保持完整性且严格罚后下降。该配置的初始化保持是预先提出的条件不变式，不包装未知可行性发现。',
              '- ILS扰动中间可缺客户/超载；已有可行best按原生feasible-only cost保留。不会据结果宣称所有内部候选可行或全局最优。',
              '- 本线同时改变初始化max和ILS midpoint，不能分离两阶段因果贡献；不扫参，不新增缩放臂。',
              '- P(sD)=sU+1并非sP，不宣称算法轨迹单位不变。',
              '- E/G目标质量分别报告；总表混合own-cost仅描述固定面板。G是冻结候选图路径代理，非连续几何最优。',
              '- E在G上的一般参考偏移可为负；只有E已达到自身最优时，才定义E最优集内G并列差。',
              '- 精确解只用于RAW归档后的评分，从未输入solver；报告仅重放保存证据，新增solver/native调用0。',
              '- 逐田块、逐seed、逐proxy与完整失败槽见SUMMARY.json。']
    return '\n'.join(lines)+'\n'


def main():
    resource.setrlimit(resource.RLIMIT_CPU,(30,30));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2));signal.alarm(120)
    data=collect_saved_evidence()
    audit_path='independent_supervision/results/SAVED_PRIORITY_AUDIT.json'
    audited=check_independent(data,read(audit_path))
    data['status']='INDEPENDENT_SAVED_VERIFIED_PENDING_REPORT_REVIEW'
    data['independent_saved_audit_sha256']=sha(ROOT/audit_path);data['independently_compared_sections']=audited
    save(ROOT/'reports/STARTED.json',{'utc':now(),'solver_calls':0,'native_constructions':0,'independent_endpoint_comparison_passed_before_writing':True})
    save(ROOT/'reports/SUMMARY.json',data)
    with(ROOT/'reports/REPORT_ZH.txt').open('x')as f:f.write(report_text(data))
    print(json.dumps({'valid_feasible_slots':data['valid_feasible_slots'],'planned_new':72,'historical':72,'report':'reports/REPORT_ZH.txt','independently_compared_sections':audited},ensure_ascii=False))
if __name__=='__main__':main()
