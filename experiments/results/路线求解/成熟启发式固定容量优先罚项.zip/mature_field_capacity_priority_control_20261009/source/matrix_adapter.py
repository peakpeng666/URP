"""Direct frozen-matrix adapter. No geometry, rounding, or optimization in this module."""
import math

def validate_payload(payload):
    expected = {'coordinates','demands','capacity','K','distance_matrix','seed','max_iterations','arm','scale','observe_penalties'}
    assert isinstance(payload,dict) and set(payload) == expected
    points,demands,matrix = payload['coordinates'],payload['demands'],payload['distance_matrix']
    assert payload['arm']=='P' and payload['scale']==1 and type(payload['scale'])is int
    assert type(payload['observe_penalties'])is bool
    assert isinstance(points,list) and len(points) in (5,13)
    assert all(isinstance(p,list) and len(p)==2 and all(type(x) in (int,float) and math.isfinite(x) for x in p) for p in points)
    assert isinstance(demands,list) and len(demands)==len(points)
    assert all(type(v)is int for v in demands) and demands==[0]+[1]*(len(points)-1)
    assert type(payload['capacity']) is int and type(payload['K']) is int
    assert (len(points),payload['capacity'],payload['K']) in ((5,2,2),(13,5,3))
    assert type(payload['seed'])is int and payload['seed'] in (0,1,2)
    assert type(payload['max_iterations'])is int and payload['max_iterations']==250
    assert isinstance(matrix,list) and len(matrix)==len(points)
    assert all(isinstance(row,list) and len(row)==len(points) for row in matrix)
    for i,row in enumerate(matrix):
        for j,value in enumerate(row):
            assert type(value)is int and 0<=value<=3944800
            assert value==matrix[j][i] and (i!=j or value==0)

def build_model(payload):
    from pyvrp import Model
    points, demands = payload['coordinates'], payload['demands']
    assert len(points) == len(demands) and demands[0] == 0
    assert all(type(v) is int and v >= 0 for v in demands)
    assert type(payload['K']) is int and payload['K'] > 0
    assert type(payload['capacity']) is int and payload['capacity'] > 0
    validate_payload(payload)
    model = Model()
    locations = [model.add_location(float(x), float(y), name=f'node_{i}') for i, (x,y) in enumerate(points)]
    depot = model.add_depot(locations[0], service_duration=0, name='depot_0')
    for node in range(1, len(points)):
        model.add_client(locations[node], delivery=demands[node], pickup=0,
                         service_duration=0, prize=0, required=True, name=f'node_{node}')
    model.add_vehicle_type(num_available=payload['K'], capacity=payload['capacity'],
                           start_depot=depot, end_depot=depot, fixed_cost=0,
                           unit_distance_cost=1, unit_duration_cost=0,
                           initial_load=0, reload_depots=[], max_reloads=0,
                           max_overtime=0, unit_overtime_cost=0)
    matrix = payload['distance_matrix']
    assert len(matrix) == len(points) and all(len(row) == len(points) for row in matrix)
    for i, row in enumerate(matrix):
        for j, value in enumerate(row):
            assert type(value) is int and 0 <= value <= 3944800
            assert value == matrix[j][i] and (i != j or value == 0)
            model.add_edge(locations[i], locations[j], distance=value, duration=0)
    data = model.data()
    location_to_node = {i:i for i in range(len(points))}
    assert data.num_locations == len(points) and data.num_clients == len(points)-1
    assert data.num_depots == 1 and data.num_vehicles == payload['K']
    assert data.num_shipments == data.num_groups == 0
    assert data.num_vehicle_types == data.num_profiles == 1
    assert all(data.client(c).location == c+1 for c in range(data.num_clients))
    assert data.distance_matrix(0).tolist() == matrix
    assert not data.duration_matrix(0).any()
    return data, matrix, location_to_node


def native_model_parameters(data,payload):
    def attrs(obj,names):return {name:getattr(obj,name) for name in names}
    vehicle=attrs(data.vehicle_type(0),['capacity','num_available','start_depot','end_depot','fixed_cost','unit_distance_cost','unit_duration_cost','unit_overtime_cost','initial_load','reload_depots','max_reloads','max_trips','max_overtime','max_distance','max_duration','shift_duration','start_late','tw_early','tw_late','profile'])
    clients=[attrs(data.client(i),['location','delivery','pickup','service_duration','prize','required','release_time','tw_early','tw_late','group'])for i in range(data.num_clients)]
    depot=attrs(data.depot(0),['location','service_duration','tw_early','tw_late'])
    unbounded=2**63-1
    assert vehicle['capacity']==[payload['capacity']] and vehicle['num_available']==payload['K'] and 1 <= payload['K'] <= data.num_clients and vehicle['initial_load']==[0]
    assert vehicle['start_depot']==vehicle['end_depot']==vehicle['fixed_cost']==vehicle['unit_duration_cost']==vehicle['unit_overtime_cost']==vehicle['max_reloads']==vehicle['max_overtime']==vehicle['tw_early']==vehicle['profile']==0
    assert vehicle['unit_distance_cost']==vehicle['max_trips']==1 and vehicle['reload_depots']==[]
    assert all(vehicle[k]==unbounded for k in ['max_distance','max_duration','shift_duration','start_late','tw_late'])
    assert all(c['location']==i+1 and c['delivery']==[payload['demands'][i+1]]and c['pickup']==[0]and c['required']is True and c['group']is None and c['service_duration']==c['prize']==c['release_time']==c['tw_early']==0 and c['tw_late']==unbounded for i,c in enumerate(clients))
    assert depot=={'location':0,'service_duration':0,'tw_early':0,'tw_late':unbounded}
    locations=[attrs(data.location(i),['x','y']) for i in range(data.num_locations)]
    assert [[p['x'],p['y']] for p in locations]==payload['coordinates']
    return {'locations':locations,'num_vehicle_types':data.num_vehicle_types,'num_profiles':data.num_profiles,'num_groups':data.num_groups,'vehicle':vehicle,'clients':clients,'depot':depot,'num_locations':data.num_locations,'num_clients':data.num_clients,'num_depots':data.num_depots,'num_vehicles':data.num_vehicles,'num_shipments':data.num_shipments,'duration_matrix_all_zero':not data.duration_matrix(0).any()}

