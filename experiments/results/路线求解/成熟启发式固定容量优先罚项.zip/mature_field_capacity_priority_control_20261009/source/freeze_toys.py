"""Freeze the exact two-toy execution path before its unique launch."""
from common import ROOT,save,sha,now,verify_old
from gates import check_environment,get_schedule

def main():
    assert not (ROOT/'selftests/toy/raw').exists()
    assert len(get_schedule('toy'))==2
    check_environment();verify_old()
    files=[ROOT/'source'/name for name in ['common.py','io_guard.py','process_lifecycle.py','matrix_adapter.py','worker.py','penalty_bound.py','observer.py','gates.py','run_once.py','execute_and_seal.py','ledger.py','endpoint_core.py','check_toys.py','freeze_toys.py']]
    files += [ROOT/rel for rel in ['selftests/toy/FIXTURE.json','selftests/toy/SCHEDULE.json','selftests/toy/AUTHORIZATION.json','environment/RUNTIME.json','environment/DEFAULT_SOLVE_PARAMS.json','freeze/PROTOCOL.json','freeze/OLD_FILES_BEFORE.json']]
    save(ROOT/'selftests/toy/FROZEN.json',{'utc':now(),'purpose':'Exactly2 authorized artificial toy calls only; not formal72 approval','files':{str(p.relative_to(ROOT)):{'bytes':p.stat().st_size,'sha256':sha(p)}for p in files},'planned_model_instances':2,'planned_solver_calls':2,'no_retries':True})
    print('TOY FROZEN',sha(ROOT/'selftests/toy/FROZEN.json'))
if __name__=='__main__':main()
