"""Same outer/supervisor/worker chain for authorized toys and one gated formal batch."""
import subprocess,sys,os,signal,time,json,resource
from common import ROOT,now,sha,read,save,verify_old
from run_once import child_environment
from process_lifecycle import parent_death,wait_group_quiescent
from gates import check_gate,get_schedule
from ledger import reconcile

def stop_process_group(p):
    if p is not None:
        try:os.killpg(p.pid,signal.SIGKILL)
        except ProcessLookupError:pass
        p.wait()
        remaining=wait_group_quiescent(p.pid,timeout=2)
        return {'quiescent':not remaining,'remaining_group_members':remaining}
    return {'quiescent':True,'remaining_group_members':[]}

def main():
    assert __debug__ and len(sys.argv)==2 and sys.argv[1] in ('toy','formal')
    mode=sys.argv[1]
    resource.setrlimit(resource.RLIMIT_CPU,(30,30))
    resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,1536*1024**2))
    gate=check_gate(mode);schedule=get_schedule(mode)
    dest=ROOT/'selftests/toy/raw' if mode=='toy' else ROOT/'raw'
    dest.mkdir(exist_ok=True)
    save(dest/'EXECUTOR_STARTED.json',{'utc':now(),'mode':mode,'gate':gate,'no_retries':True})
    out=dest/'supervisor.stdout';err=dest/'supervisor.stderr'
    p=None;timed_out=False;error=None;started=time.monotonic();parent=os.getpid()
    try:
        with out.open('xb') as fo,err.open('xb') as fe:
            p=subprocess.Popen([gate['python'],'-B',str(ROOT/'source/run_once.py'),mode],
              stdout=fo,stderr=fe,env=child_environment(),cwd=dest,start_new_session=True,
              preexec_fn=lambda:parent_death(parent))
            try:p.wait(timeout=98 if mode=='toy' else 1958)
            except subprocess.TimeoutExpired:timed_out=True
    except Exception as exc:error=repr(exc)
    finally:cleanup=stop_process_group(p)
    results=(dest/'results.jsonl').read_text() if (dest/'results.jsonl').exists() else ''
    attempts=(dest/'attempts.jsonl').read_text() if (dest/'attempts.jsonl').exists() else ''
    slots,ledger_errors=reconcile(schedule,results,attempts)
    save(dest/'ALL_PLANNED_SLOTS.json',slots)
    save(dest/'EXECUTOR_FINISHED.json',{'utc':now(),'mode':mode,
      'supervisor_returncode':p.returncode if p else None,'external_timeout':timed_out,
      'launcher_error':error,'process_group_kill_attempt_completed_before_seal':True,'cleanup':cleanup,
      'wall_seconds_audit_only':time.monotonic()-started,'planned_slots':len(schedule),
      'retained_slots':len(slots),'ledger_errors':ledger_errors,
      'known_spawned':sum(r.get('process_spawned') is True for r in slots),
      'unknown_spawned_slots':sum(r.get('process_spawned') is None for r in slots)})
    if not cleanup['quiescent']:raise RuntimeError('WORKER_GROUP_NOT_QUIESCENT_NO_SEAL')
    verify_old();check_gate(mode)
    if mode=='formal':
        from package import package
        print(json.dumps(package('RAW_UNREVIEWED')))
    else:
        save(dest/'RAW_MANIFEST.json',{'utc':now(),'files':{str(f.relative_to(ROOT)):{'bytes':f.stat().st_size,'sha256':sha(f)} for f in sorted(dest.rglob('*')) if f.is_file()},'model_instances_planned':2,'solver_calls_planned':2})
        print(json.dumps({'mode':'toy','retained_slots':len(slots),'raw':str(dest),'solver_calls_planned':2}))
if __name__=='__main__':main()
