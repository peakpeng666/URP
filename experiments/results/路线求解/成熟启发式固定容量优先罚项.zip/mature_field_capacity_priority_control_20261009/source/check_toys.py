"""Saved-only two-toy validation. No optimizer imports or new native calls."""
import json
from common import ROOT,read,save,sha,now
from gates import verify_toy_freeze,get_schedule
from endpoint_core import validate_saved

def main():
    verify_toy_freeze();schedule=get_schedule('toy');problem=read('selftests/toy/FIXTURE.json')
    slots=read('selftests/toy/raw/ALL_PLANNED_SLOTS.json');outer=read('selftests/toy/raw/EXECUTOR_FINISHED.json')
    assert len(slots)==2 and outer['cleanup']['quiescent'] and not outer['ledger_errors']
    assert outer['supervisor_returncode']==0 and not outer['external_timeout']
    assert outer['known_spawned']==2 and outer['unknown_spawned_slots']==0
    rows=[];answers=[]
    for entry,record in zip(schedule,slots):
        assert record['schedule']==entry and record['status']=='UNREVIEWED_PROCESS_SUCCESS'
        assert record['process_spawned']is True and record['child_reaped']is True and record['returncode']==0
        assert sha(ROOT/record['stdout'])==record['stdout_sha256'] and sha(ROOT/record['stderr'])==record['stderr_sha256']
        answer=read(record['stdout']);checked=validate_saved(problem,entry,answer);answers.append(answer)
        assert checked['valid'] and checked['normalized_own_cost']==300002
        assert answer['derived_penalty']=={'formula':'(n_customers+K)*max_edge+1','n_customers':4,'K':2,'max_edge':75000,'U':450000,'P':450001}
        rows.append({'call_id':entry['call_id'],'status':'PASS','matrix_entries':25,'reported_cost':answer['reported_cost'],'derived_penalty':answer['derived_penalty'],'routes':checked['routes'],'loads':checked['loads'],'observations':checked['observations']})
    invariant=['routes','native_routes','solver_is_feasible','solver_is_complete','reported_cost','reported_distance','stats','num_iterations','native_distance_matrix','derived_penalty']
    for key in invariant: assert answers[0][key]==answers[1][key],('OBSERVER_CHANGED_RESULT',key)
    assert rows[0]['observations']['initial_solution_feasible']is True
    assert rows[0]['observations']['first_best_feasible_iteration']==0
    report={'utc':now(),'status':'PASS','toy_calls_planned':2,'toy_calls_spawned':2,'toy_solver_calls':2,'toy_model_instances':2,'explicit_solution_constructions':0,'new_solver_calls_in_this_check':0,'formal_solver_calls':0,'native_matrix_entries_total':50,'full_outer_supervisor_worker_chain':True,'observer_invariance_checked_fields':invariant,'rows':rows,'freeze_sha256':sha(ROOT/'selftests/toy/FROZEN.json')}
    save(ROOT/'selftests/toy/VERIFIED.json',report);print(json.dumps(report))
if __name__=='__main__':main()
