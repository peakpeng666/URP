"""Synthetic saved-row endpoint tests; no optimizer, no real objective scoring."""
import copy,json,resource,signal
from common import ROOT,read,save,now
from report_core import blank_row,apply_checked,build_summary,METRICS
from report import report_text

def main():
    resource.setrlimit(resource.RLIMIT_CPU,(30,30));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2));signal.alarm(120)
    fields=read('freeze/PROTOCOL.json')['fields'];schedule=read('freeze/SCHEDULE.json');rows=[]
    for i,entry in enumerate(schedule):
        for arm in ('A','P'):
            e=dict(entry,arm=arm,call_id=entry['call_id'].replace('_P_',f'_{arm}_'))
            row=blank_row(e,'SYNTHETIC_ONLY');valid=not(arm=='A'and i<12)
            row.update(valid=valid,record_verified=True,routing_violation=not valid,observations={'initial_solution_feasible':valid,'first_best_feasible_iteration':0 if valid else None,'pm_updates_observed':0})
            if valid:
                value=100 if arm=='A'else 105
                row.update(normalized_own_cost=value,base_E=value,base_G=value,own_gap_mm=value-100,own_gap_percent=value-100,G_realized_excess_mm=value-100,exact_hit=arm=='A')
            rows.append(row)
    out=build_summary(rows,fields)
    assert out['overall']['arms']['A']['valid_feasible']==60 and out['overall']['arms']['P']['valid_feasible']==72
    assert out['overall']['arms']['A']['complete_panel']is None
    assert out['overall']['arms']['P']['complete_panel']['count']==72
    pair=out['overall']['pairs']['A_vs_P'];assert pair['common_success_count']==60
    assert pair['conditional_pair_common_success']['metrics']['normalized_own_cost']['mean']==5
    assert pair['complete_panel_mean_deltas']['normalized_own_cost']is None
    assert out['overall']['historical_failure_subgroup']['planned']==12
    assert all(x['baseline_cost_delta']is None for x in out['overall']['historical_failure_subgroup']['new_rows'])
    assert out['by_proxy']['E']['arms']['A']['valid_feasible']==30
    assert out['by_proxy']['G']['arms']['P']['valid_feasible']==36
    assert out['overall']['arms']['A']['exact_hit_rate_all_planned']==60/72
    mutated=copy.deepcopy(rows);j=next(i for i,r in enumerate(mutated)if r['arm']=='P')
    mutated[j]=blank_row({k:mutated[j][k]for k in schedule[0]},'NOT_STARTED_ABORTED')
    failed=build_summary(mutated,fields)
    assert failed['overall']['arms']['P']['complete_panel']is None
    assert failed['overall']['arms']['P']['failed_or_unverified']==1
    for invalid in (rows[:-1],rows+[rows[0]]):
        try:build_summary(invalid,fields)
        except AssertionError:pass
        else:raise AssertionError('MISSING_OR_DUPLICATE_ROW_ACCEPTED')
    bad=copy.deepcopy(rows);bad[0]['normalized_own_cost']=10
    try:build_summary(bad,fields)
    except AssertionError:pass
    else:raise AssertionError('FAILED_COST_PROMOTED')
    text=report_text({'overall':out['overall'],'by_proxy':out['by_proxy'],'source_prediction_counts':out['source_prediction_counts']})
    assert '非同期历史对照' in text and '新增72格' in text and '失败12格' in text
    report={'status':'PASS','utc':now(),'synthetic_comparison_rows':144,'new_real_rows':0,'solver_calls':0,'native_constructions':0,'checks':['full144rows/72new/72history','A60valid/P72valid','allpanelnull_on_failure','common60_only','historical12fail_cost_deltas_null','separateE/G36','PminusA_direction','exact_hit_all72','missing_duplicate_rejected','failed_cost_rejected','report_limits_present']}
    save(ROOT/'selftests/REPORT_SYNTHETIC.json',report);print(json.dumps(report))
if __name__=='__main__':main()
