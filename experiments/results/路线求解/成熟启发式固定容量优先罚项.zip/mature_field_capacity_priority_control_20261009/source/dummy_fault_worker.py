"""Only malformed-output lifecycle fixtures. No solver imports or file IO."""
import json
import sys
mode = json.load(sys.stdin)['mode']
if mode == 'nonzero':
    raise SystemExit(7)
if mode == 'malformed':
    print('not JSON')
elif mode == 'missing_fields':
    print('{}')
