"""Author-side saved-output checks and signed endpoint definitions; standard library only."""
import hashlib,json,copy
from common import read
from penalty_bound import derive_penalty
from io_guard import WARNING_SOURCE,WARNING_SOURCE_SHA256,READ_FLAGS


def route_cost(matrix,routes):
    return sum(matrix[a][b] for r in routes for a,b in zip(r,r[1:]))


def validate_saved(problem,entry,answer):
    """Raises on any invalid model, coverage, objective, or native mapping; no repair."""
    n=len(problem['coordinates'])-1;scale=entry['scale'];matrix=[[scale*v for v in row]for row in problem['matrices'][entry['proxy']]]
    assert answer['arm']==entry['arm'] and answer['scale']==scale and answer['observe_penalties']==entry['observe_penalties']
    payload={**entry,**{k:problem[k]for k in ('coordinates','demands','capacity','K')},'distance_matrix':matrix}
    derived=derive_penalty(matrix,n,problem['K'])
    assert answer['derived_penalty']==derived,'DERIVED_PENALTY_MISMATCH'
    validate_parameters(answer,{**entry,'min_penalty':float(derived['P']),'max_penalty':float(derived['P'])})
    observed=validate_observation(answer,payload)
    assert answer['solver']=='PyVRP' and answer['version']=='0.14.0' and answer['algorithm']=='ILS'
    assert answer['seed']==entry['seed'] and answer['max_iterations']==entry['max_iterations']
    assert answer['num_iterations']==len(answer['stats'])==len(answer['stats_runtime_per_iteration'])==entry['max_iterations']
    assert answer['model_instances']==answer['solver_calls']==1 and answer['explicit_solution_constructions']==0
    assert answer['solver_is_complete'] is True
    assert answer['denied_io_events']==[] and answer['reference_or_history_payload_fields']==[]
    assert answer['warning_source_verification']=={'path':WARNING_SOURCE,'sha256':WARNING_SOURCE_SHA256,'verified_before_search':True,'default_warning_behavior_preserved':True}
    expected_read={'event':'open','path':WARNING_SOURCE,'mode':'r','flags':READ_FLAGS,'verified_source_sha256':WARNING_SOURCE_SHA256}
    assert isinstance(answer['allowed_warning_source_reads'],list) and all(x==expected_read for x in answer['allowed_warning_source_reads'])
    assert all(type(value)is int for row in answer['native_distance_matrix'] for value in row)
    assert answer['native_distance_matrix']==matrix and answer['native_matrix_entries_checked']==(n+1)**2
    assert answer['model_matrix_sha256']==hashlib.sha256(json.dumps(matrix,separators=(',',':')).encode()).hexdigest()
    assert answer['reported_duration_cost']==answer['reported_fixed_vehicle_cost']==0
    params=answer['native_model_parameters'];v=params['vehicle'];clients=params['clients'];depot=params['depot']
    assert params['num_locations']==n+1 and params['num_clients']==n
    assert params['num_depots']==params['num_profiles']==params['num_vehicle_types']==1
    assert params['num_vehicles']==problem['K'] and params['num_shipments']==params['num_groups']==0
    assert params['duration_matrix_all_zero'] is True
    assert [[q['x'],q['y']] for q in params['locations']]==problem['coordinates']
    assert v['capacity']==[problem['capacity']] and v['num_available']==problem['K'] and v['initial_load']==[0]
    assert all(v[k]==0 for k in ['start_depot','end_depot','fixed_cost','unit_duration_cost','unit_overtime_cost','max_reloads','max_overtime','tw_early','profile'])
    assert v['unit_distance_cost']==v['max_trips']==1 and v['reload_depots']==[]
    assert all(v[k]==2**63-1 for k in ['max_distance','max_duration','shift_duration','start_late','tw_late'])
    assert depot=={'location':0,'service_duration':0,'tw_early':0,'tw_late':2**63-1}
    assert len(clients)==n
    for i,c in enumerate(clients):
        assert c['location']==i+1 and c['delivery']==[1] and c['pickup']==[0]
        assert c['required'] is True and c['group'] is None
        assert all(c[k]==0 for k in ['service_duration','prize','release_time','tw_early']) and c['tw_late']==2**63-1
    routes=answer['routes'];assert isinstance(routes,list) and 1<=len(routes)<=problem['K']
    assert answer['reported_num_routes']==len(routes)==len(answer['native_routes'])
    seen=[];legs=0;loads=[]
    for route,native in zip(routes,answer['native_routes']):
        assert isinstance(route,list) and len(route)>=3 and all(type(x)is int for x in route)
        assert route[0]==route[-1]==0 and all(1<=x<=n for x in route[1:-1])
        loads.append(len(route)-2);seen.extend(route[1:-1]);legs+=len(route)-1
        assert native['start_depot']==native['end_depot']==native['vehicle_type']==0 and native['num_trips']==1
        assert native['is_feasible']==(len(route)-2<=problem['capacity']) and native['delivery']==[len(route)-2]
        assert native['distance']==route_cost(matrix,[route])
        assert len(native['activities'])==len(route)
        for node,activity in zip(route,native['activities']):
            assert activity['node']==activity['location']==node
            assert activity['type']==('DEPOT' if node==0 else 'CLIENT')
            assert activity['idx']==(0 if node==0 else node-1)
    assert sorted(seen)==list(range(1,n+1)) and legs==n+len(routes)
    costs={p:route_cost(problem['matrices'][p],routes) for p in ('E','G')}
    valid=all(v<=problem['capacity'] for v in loads)
    assert answer['solver_is_feasible'] is valid
    assert answer['reported_distance']==answer['internal_route_cost']==scale*costs[entry['proxy']]
    assert answer['reported_distance']%scale==0
    if valid:
        assert len(routes)==problem['K'] and type(answer['reported_cost'])is int
        assert answer['reported_cost']==answer['reported_distance']
    else:assert answer['reported_cost'] is None
    assert answer['resource_limits']['effective']['CPU_seconds']==[15,15]
    assert answer['resource_limits']['effective']['AS_bytes']==[1536*1024**2]*2
    assert answer['resource_limits']['inherited']['CPU_seconds']==[30,30]
    assert answer['resource_limits']['inherited']['AS_bytes']==[512*1024**2,1536*1024**2]
    return {'valid':valid,'routing_violation':not valid,'base_E':costs['E'],'base_G':costs['G'],'normalized_own_cost':costs[entry['proxy']] if valid else None,'E':costs['E'],'G':costs['G'],'legs':legs,'routes':routes,'loads':loads,'observations':observed}


def define_endpoints(proxy,costs,oracle):
    own=costs[proxy]-oracle[proxy+'_star']
    assert type(own)is int and own>=0,'NEGATIVE_OWN_OBJECTIVE_GAP'
    excess=costs['G']-oracle['G_star'];assert excess>=0
    offset=costs['G']-oracle['G_at_E_optimum'] if proxy=='E' else None
    tie=offset if proxy=='E' and own==0 else None
    if tie is not None:assert tie>=0,'NEGATIVE_TIE_DIFFERENCE'
    if proxy=='E':assert excess==offset+oracle['delta_integer_mm']
    return {'own_gap_mm':own,'own_gap_percent':100*own/oracle[proxy+'_star'] if oracle[proxy+'_star']>0 else None,
            'exact_hit':own==0,'G_realized_excess_mm':excess,'E_offset_from_lex_reference_mm':offset,
            'E_optimal_tie_difference_mm':tie,'offset_is_search_error':False}


def summarize_cells(rows,proxy,budget):
    selected=[r for r in rows if r['proxy']==proxy and r['max_iterations']==budget]
    valid=[r for r in selected if r['valid']]
    values=[r['own_gap_mm'] for r in valid]
    hits=sum(r['exact_hit'] for r in valid)
    return {'proxy':proxy,'max_iterations':budget,'planned':len(selected),'eligible':len(valid),
      'failed_or_unverified':len(selected)-len(valid),'exact_hits':hits,
      'exact_hit_rate_all_planned':hits/len(selected) if selected else None,
      'exact_hit_rate_valid_only':hits/len(valid) if valid else None,
      'complete_panel_mean_gap_mm':sum(values)/len(values) if values and len(valid)==len(selected) else None,
      'valid_subset_mean_gap_mm':sum(values)/len(values) if values else None,
      'valid_subset_max_gap_mm':max(values) if values else None}


def validate_parameters(answer,entry):
    expected=copy.deepcopy(read('environment/DEFAULT_SOLVE_PARAMS.json')['parameters'])
    expected['values']['penalty']['values']['min_penalty']=entry['min_penalty']
    expected['values']['penalty']['values']['max_penalty']=entry['max_penalty']
    if entry['observe_penalties']:
        expected['values']['ils']['values']['callbacks']={'type':'observer.ReadonlyPenaltyObserver','values':{}}
    assert answer['default_solve_params']==expected,'PARAMETER_DRIFT'

def validate_observation(answer,payload):
    o=answer['penalty_observation']
    if not payload['observe_penalties']:
        assert o is None
        return {'observed':False,'initial_solution_feasible':None,'first_best_feasible_iteration':None,'pm_updates_observed':None}
    assert o['schema']=='public_scale_penalty_observer_v1' and o['probe_values']==[1,2,7,1000]
    assert len(o['rows'])==payload['max_iterations']==250
    derived=derive_penalty(payload['distance_matrix'],len(payload['coordinates'])-1,payload['K'])
    assert answer['derived_penalty']==derived,'DERIVED_PENALTY_MISMATCH'
    p=float(derived['P'])
    expected=[[p],p,p];assert o['initial_penalties']==expected,'INITIAL_PENALTY_DRIFT'
    initial=o['initial_solution_routes'];n=len(payload['coordinates'])-1
    assert isinstance(initial,list) and 1<=len(initial)<=payload['K']
    seen=[];loads=[]
    for route in initial:
        assert len(route)>=3 and route[0]==route[-1]==0
        assert all(type(v)is int and 1<=v<=n for v in route[1:-1])
        seen.extend(route[1:-1]);loads.append(len(route)-2)
    assert sorted(seen)==list(range(1,n+1))
    initial_feasible=all(v<=payload['capacity']for v in loads)
    assert o['initial_solution_feasible'] is initial_feasible
    first=0 if initial_feasible else None;found=initial_feasible
    for i,(r,st) in enumerate(zip(o['rows'],answer['stats']),1):
        assert r['iteration']==i and r['expected_search_penalties_source_derived']==expected
        assert r['observed_post_registration_penalties']==expected,'UNEXPECTED_PENALTY_UPDATE'
        probes=r['observed_search_evaluator_integer_probes']
        assert probes==[{'violation':v,'load':int(v*p),'duration':int(v*p),'distance':int(v*p)}for v in (1,2,7,1000)],'INTEGER_PROBE_MISMATCH'
        assert type(r['best_is_feasible'])is bool and r['best_is_feasible']==st['best_feas']
        if found:assert r['best_is_feasible']
        if r['best_is_feasible'] and first is None:first=i
        found=found or r['best_is_feasible']
    assert o['first_best_feasible_iteration']==first
    assert found==answer['solver_is_feasible']
    return {'observed':True,'initial_solution_feasible':initial_feasible,'initial_solution_routes':initial,'initial_solution_loads':loads,'first_best_feasible_iteration':first,'pm_updates_observed':0,'source_prediction_initial_feasible_observed':initial_feasible,'source_prediction_current_feasible_all250_observed':all(s['current_feas']for s in answer['stats'])}
