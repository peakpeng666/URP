"""Preregistered small checker, atomic-repair and exhaustive-oracle fixtures."""
import copy,math,random,time
from audit import check,brute,unit_tests
from oracle import solve
import fixed_solver as fs

def raw(id,xy,dem,Q,K):return {'instance_id':id,'coordinates':xy,'demands':[0]+dem,'capacity':Q,'K':K,'split':'unit_test'}

def toy_specs():
    return {'checker_tests':['valid two routes','at most K (fewer permitted)','reject too many routes','capacity','missing','duplicate','unknown ID','empty route','cost mismatch'],
      'mechanism_tests':['new-route allowed only below K','FFD positive fallback charged','feasible packing where deterministic FFD fails stays INIT_FAIL','candidate repair failure discards full partial solution','candidate budget truncation discards full partial solution'],
      'oracle_tests':'Every n=1..6 in uniform and two-cluster toy seeds 2026100811900+2*(n-1)+family; demand cycle1..4,Q6; all K1..n. Add zero-distance n3 and feasible-FFD-failure n6. Compare exhaustive permutation/nonempty-cuts independent sqrt distances against DP all K.',
      'scope':'Only toy inputs. Main 16 geometries have not yet been generated, solved, or scored.'}

def fixtures():
    out=[]
    for n in range(1,7):
        for family in range(2):
            seed=2026100811900+2*(n-1)+family;r=random.Random(seed);xy=[[0,0]]
            for j in range(n):
                if family==0:xy.append([round(r.uniform(-50,50),6),round(r.uniform(-50,50),6)])
                else:xy.append([round(r.gauss(c,8),6) for c in ((-30,-20) if j%2==0 else (30,20))])
            out.append(raw(f'TOY_N{n}_F{family}',xy,[1+j%4 for j in range(n)],6,n))
    out.append(raw('TOY_ZERO',[[0,0]]*4,[1,1,1],3,3))
    out.append(raw('TOY_FFD_FAIL_FEASIBLE',[[0,0]]*7,[6,5,3,2,2,2],10,2))
    return out

def run():
    start=time.process_time();checks=unit_tests();detail=[]
    for f in fixtures():
        exact=solve(f);b=brute(f);ks=[]
        for k in range(1,len(f['demands'])):
            a=exact['by_k'][str(k)];v=b['by_k'][str(k)]
            assert (a is None)==(v is None),(f['instance_id'],k)
            if a is not None:
                assert math.isclose(a['cost'],v['cost'],rel_tol=1e-10,abs_tol=1e-8)
                assert check(f,dict(a,reported_cost=a['cost']),k)['accepted']
            ks.append({'K':k,'feasible':a is not None,'exact_cost':None if a is None else a['cost'],'brute_cost':None if v is None else v['cost']})
        detail.append({'id':f['instance_id'],'brute_candidates':b['candidates'],'K_results':ks})
    cfg={'delta_limit':5000,'per_trajectory_cpu_seconds':2,'per_trajectory_wall_seconds':10,'iterations':0}
    f=raw('TOY_FFD_POSITIVE',[[0,0]]*4,[1,1,1],2,2)
    r=fs.run_one(f,'cheapest',0,cfg)
    assert r['status']=='LEGAL_COMPLETION' and r['initialization']['fallback_triggered'] and r['deltas']==7
    checks.append('fallback_charged_savings3_plus_insertion4')
    f=fixtures()[-1];r2=fs.run_one(f,'cheapest',0,cfg)
    assert solve(f)['by_k']['2'] is not None
    assert r2['status']=='INIT_FAIL' and r2['output'] is None and r2['deltas']==15
    checks.append('FFD_FAIL_is_not_math_infeasible_and_no_rescue')
    gate=raw('TOY_ROUTE_GATE',[[0,0],[1,0],[2,0]],[1,1],2,1)
    inst=fs.instance_for(gate);bgt=fs.Budget(1000,2,10);matrix=fs.matrix_for(inst,bgt)
    opts=fs.route_options(2,[[1]],[1],inst,matrix,bgt)
    assert opts and all(x[1]<1 for x in opts)
    inst.K=2;assert any(x[1]==1 for x in fs.route_options(2,[[1]],[1],inst,matrix,bgt))
    checks.append('fresh_route_exact_K_gate')
    # Feasible original [[6,4],[5,2,3]] becomes irreparable by cheapest choosing2 then3.
    f=raw('TOY_ATOMIC',[[0,0],[-10,0],[10,0],[-9,0],[9,0],[30,0]],[6,5,2,3,4],10,2)
    inst=fs.instance_for(f);bgt=fs.Budget(1000,2,10);matrix=fs.matrix_for(inst,bgt)
    original=[[1,5],[2,3,4]];snapshot=copy.deepcopy(original)
    incumbent=fs.output_for(original,fs.cost_of(original,matrix,bgt));assert check(f,incumbent,2)['accepted']
    fail=fs.evaluate_candidate(f,[[1],[2]],[3,4,5],'cheapest',inst,matrix,bgt)
    assert fail['status']=='repair_failed' and fail['candidate'] is None and original==snapshot and check(f,incumbent,2)['accepted']
    assert not check(f,fs.output_for(fail['detail']['partial_routes'],0),2)['accepted']
    checks.append('partial_failure_atomic_discard_missing_not_cheap')
    bgt=fs.Budget(1,2,10);cut=fs.evaluate_candidate(f,[[1],[2]],[3,4,5],'cheapest',inst,matrix,bgt)
    assert cut['status']=='budget_discarded' and cut['candidate'] is None and original==snapshot and check(f,incumbent,2)['accepted']
    checks.append('budget_cut_atomic_discard')
    return {'passed':True,'checks':checks,'oracle_fixture_count':len(detail),'oracle_crosschecks':detail,'fallback_positive':r,'fallback_feasible_but_failed':r2,'repair_failure_example':fail,'budget_discard_example':cut,'cpu_seconds':time.process_time()-start}
