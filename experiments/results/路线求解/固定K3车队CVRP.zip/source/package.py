"""Package frozen evidence, never include credentials or unrelated files."""
import json,zipfile
from common import ROOT,utc,read,dump,sha,verify

def main():
    verify();assert read(ROOT/'reports/TRACE_CHECKS.json')['verified']
    (ROOT/'README.txt').write_text('Fixed-fleet CVRP experiment, one launch, 16 fresh geometries / 128 trajectories. Start with reports/REPORT_ZH.txt and reports/SUMMARY.json. Independent external audit is pending. Original predecessor is read-only. No formal reruns. source/supervise.py prepare/main/audit/package each refuses an existing stage receipt. SHA256SUMS and MANIFEST cover all evidence available at package start; package-stage receipt is emitted after archive creation and therefore intentionally outside the archive.\n')
    paths=[p for p in sorted(ROOT.rglob('*')) if p.is_file() and p.suffix!='.zip' and p.name not in ['MANIFEST.json','SHA256SUMS.txt','archive.sha256'] and '__pycache__' not in str(p) and p.name not in ['package.stdout.log','package.stderr.log','package.json']]
    files=[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in paths]
    dump(ROOT/'MANIFEST.json',{'created_utc':utc(),'file_count':len(files),'files':files,'external_audit_status':'pending','exclusions':['archive self hash','package-stage receipt and logs produced during/after packaging']})
    (ROOT/'SHA256SUMS.txt').write_text(''.join(f'{x["sha256"]}  {x["path"]}\n' for x in files)+f'{sha(ROOT/"MANIFEST.json")}  MANIFEST.json\n')
    archive=ROOT/(ROOT.name+'.zip')
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in paths+[ROOT/'MANIFEST.json',ROOT/'SHA256SUMS.txt']:z.write(p,str(p.relative_to(ROOT)))
    (ROOT/'archive.sha256').write_text(sha(archive)+'  '+archive.name+'\n');print(json.dumps({'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'files':len(files)}))
if __name__=='__main__':main()
