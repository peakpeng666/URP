"""Freeze rules and tests, verify toys, then freeze fresh inputs; no main solves."""
import random
from pathlib import Path
from common import ROOT,utc,sha,read,dump,digest
import toys
OLD=[Path('/workspace/shared')/p for p in ['vrp_unseen_geometry_20261007','cvrp_scale_20261007','vrp_time_windows_20261007','exact_cvrp_controls_20261008']]

def make(gi):
    seed=2026100811300+gi;r=random.Random(seed);family='uniform' if gi<8 else 'two_cluster';xy=[[0.,0.]]
    for j in range(9):
        if family=='uniform':pt=[r.uniform(-50,50),r.uniform(-50,50)]
        else:pt=[r.gauss(c,8) for c in ((-30,-20) if j%2==0 else (30,20))]
        xy.append([round(x,6) for x in pt])
    dem=[1,1,2,2,3,3,4,4,4];random.Random(seed+1000000).shuffle(dem)
    return {'spec_version':'euclidean-fixedK-cvrp-v1','instance_id':f'FK{gi+1:02d}','coordinates':xy,'demands':[0]+dem,'capacity':9,'K':3,'fleet':'at_most_K_nonempty_routes','depot':0,'objective':'sum_unrounded_euclidean_distance','family':family,'generation_seed':seed,'split':'fresh_development'}

def cfg():
    return {'title':'Fixed-fleet feasibility mechanism contrast v1','created_utc':utc(),'n':9,'Q':9,'K':3,'geometry_count':16,'geometry_seeds':list(range(2026100811300,2026100811316)),'families':['uniform']*8+['two_cluster']*8,
      'generator':'U[-50,50]^2 or alternating N((-30,-20),8^2 I)/N((30,20),8^2 I), depot (0,0), coordinate round6; independent random.Random(seed).',
      'demand_rule':'Same prior multiset [1,1,2,2,3,3,4,4,4], shuffled seed+1000000. No solution-based sample filtering or repair. This narrow easy-packing multiset cannot support broad capacity-feasibility generalization.',
      'methods':['cheapest','regret2'],'search_seeds':[113011,113027,113041,113057],'schedule_seed':2026100811399,'planned_runs':128,'delta_limit':5000,'iterations':1000000000,'per_trajectory_cpu_seconds':2.,'per_trajectory_wall_seconds':10.,'main_cpu_soft_seconds':89,'main_cpu_hard_seconds':90,'main_wall_seconds':150,
      'initialization':'Common charged legacy parallel savings. Only if >K: exactly one FFD capacity construction, demand-descending then ID ascending; bins first-fit order up toK; append customers in that order. Then each fixed bin routed by sequential cheapest insertion in FFD append order, tie position index; charge every expression. Failure=INIT_FAIL, no retry, witness, oracle, warm start or resampling.',
      'repair':'Same legacy cheapest or route-based regret2, ties unchanged; route_options only offers singleton if current nonempty routes<K. No insert possible: reject entire candidate, retain legal incumbent, charge consumed work. Budget truncation also atomically discarded; no incomplete route cost used.',
      'search':'Legacy random remove10–30%,n9 meansq2..3 using paired derived seeds by iteration; strict improve epsilon1e-9. Iteration indices stay paired, number completed may differ under5000 delta.',
      'objective':'Every customer exactly once, every route depot-return and nonempty, integer capacityQ9, at mostK3 vehicles, total unrounded Euclidean; fewer thanK allowed.',
      'meter':'Every savings/removal/insertion delta charged before arithmetic;5000 includes initialization and failed candidates. Capacity sorting/packing has no delta expression; full objective edges,matrix distances,budget checks,CPU/wall recorded separately. Independent checker arithmetic recorded in total process/solver CPU but is not a delta. Equal delta is not equal FLOPs/CPU.',
      'oracle':'Only after all128 heuristic attempts complete; Held-Karp capacity-feasible subset tour + anchored partitionDP allK; K3 used to score. Does not enter algorithm interface. Exact combinatorial enumeration over IEEE double, numerically validated, not interval certificate.',
      'preregistered_toys':toys.toy_specs(),'checker':'Independent audit.py sqrt distances and full coverage/load/vehicle/cost checks; all emitted candidates and accepted incumbents checked; invalid output zero tolerance. Failure retains planned denominator.',
      'aggregation':'First planned128/method64 and oracle-feasible planned denominator; legal completion requires valid output and status LEGAL_COMPLETION. Also valid outputs separately and illegal non-null outputs. Hit legal and signed gap<=1% with numerical tolerance. Secondary common support=all4 seeds of both methods legally completed and oracle-feasible; average seeds within geom, then equal geom. Report all16 geom status and worst individual seed. Seeds are repeats, not independent n.',
      'hit_tolerance':'Exact hit abs(cost-opt)<=max(1e-8,1e-10*abs(opt)); threshold1% allowed same absolute tolerance; signed gaps retained.',
      'failure_policy':'One formal launch. No rerun, code edit, sample deletion or sampling replacements after freeze. Oracle infeasibility retained; INIT_FAIL distinguished from proven infeasible. Missing or interrupted planned records retained by analysis as NOT_RUN.',
      'historical_reference':'Legacy source is included byte-identically for primitive reuse/provenance, and its ungated run_one is not executed on this formal sample. Prior uncontrolled low costs are not treated as valid fixedK performance. No EX06 reuse.',
      'external_api_calls':0,'model_calls':0,'dependency_installs':0,'uploads':0,'main_solver_pilot_calls':0}

def main():
    dump(ROOT/'freeze/PROTOCOL.json',cfg())
    dump(ROOT/'freeze/TOY_PREREGISTRATION.json',toys.toy_specs())
    frozen={str(p.relative_to(ROOT)):sha(p) for p in sorted((ROOT/'source').rglob('*.py'))}
    frozen.update({str(p.relative_to(ROOT)):sha(p) for p in sorted((ROOT/'freeze').glob('*.json'))})
    dump(ROOT/'freeze/PRE_TOY_FREEZE.json',{'utc':utc(),'main_inputs_generated':0,'main_launches':0,'sha256':frozen})
    dump(ROOT/'input/TOY_FIXTURES.json',toys.fixtures())
    dump(ROOT/'reports/TOY_VALIDATION.json',toys.run())
    dump(ROOT/'freeze/PRE_GENERATION_FREEZE.json',{'utc':utc(),'main_inputs_generated':0,'main_launches':0,'sha256':frozen,'toy_validation_sha256':sha(ROOT/'reports/TOY_VALIDATION.json')})
    oldordered=set();oldunordered=set();records=[];inherited=set()
    for d in OLD:
        files=list((d/'input').glob('*.json'))
        if (d/'inputs.json').exists():files.append(d/'inputs.json')
        for path in files:
            val=read(path)
            for v in val if isinstance(val,list) else [val]:
                if not isinstance(v,dict):continue
                xy=v.get('coordinates')
                if xy is None and isinstance(v.get('nodes'),list):xy=[[n['x'],n['y']] for n in v['nodes']]
                if xy is None:continue
                h=digest(xy);u=digest(sorted(xy));oldordered.add(h);oldunordered.add(u)
                records.append({'file':str(path),'file_sha256':sha(path),'id':v.get('instance_id',v.get('id')),'ordered_sha256':h,'unordered_sha256':u})
        mf=d/'freeze/INPUT_MANIFEST.json'
        if mf.exists():
            for e in read(mf):
                if 'coordinates_sha256' in e:oldordered.add(e['coordinates_sha256'])
                if 'unordered_coordinates_sha256' in e:oldunordered.add(e['unordered_coordinates_sha256'])
        prior=d/'freeze/OLD_GEOMETRY_HASHES.json'
        if prior.exists():
            doc=read(prior)
            for h in doc.get('hashes',[])+doc.get('inherited_ordered_hashes',[]):oldordered.add(h);inherited.add(h)
            for r in doc.get('records',[]):
                if 'ordered_coordinate_sha256' in r:oldordered.add(r['ordered_coordinate_sha256'])
                if 'unordered_coordinate_sha256' in r:oldunordered.add(r['unordered_coordinate_sha256'])
    dump(ROOT/'freeze/OLD_GEOMETRY_HASHES.json',{'records':records,'ordered_hashes':sorted(oldordered),'unordered_hashes':sorted(oldunordered),'inherited_ordered_hashes':sorted(inherited),'scope':'Four specified historical bundles plus inherited recorded hashes; no universal history claim.'})
    entries=[];new=set();newu=set()
    for gi in range(16):
        r=make(gi);h=digest(r['coordinates']);u=digest(sorted(r['coordinates']))
        assert h not in oldordered and h not in new and u not in oldunordered and u not in newu
        new.add(h);newu.add(u);path=f'input/{r["instance_id"]}.json';dump(ROOT/path,r)
        entries.append({'geometry_id':r['instance_id'],'family':r['family'],'generation_seed':r['generation_seed'],'input_file':path,'input_sha256':sha(ROOT/path),'coordinates_sha256':h,'unordered_coordinates_sha256':u})
    dump(ROOT/'freeze/INPUT_MANIFEST.json',entries)
    c=read(ROOT/'freeze/PROTOCOL.json');schedule=[dict(e,method=m,search_seed=s) for e in entries for s in c['search_seeds'] for m in c['methods']]
    random.Random(c['schedule_seed']).shuffle(schedule)
    for i,r in enumerate(schedule):r['run_id']=i
    dump(ROOT/'freeze/SCHEDULE.json',schedule)
    prov=[]
    for p in sorted((ROOT/'source/legacy').rglob('*.py')):
        src=OLD[-1]/p.relative_to(ROOT);assert sha(p)==sha(src)
        prov.append({'copy':str(p.relative_to(ROOT)),'source':str(src),'sha256':sha(p),'byte_identical':True})
    for name in ['common.py','oracle.py','audit.py','supervise.py']:
        p=ROOT/'source'/name;src=OLD[-1]/'source'/name;assert sha(p)==sha(src)
        prov.append({'copy':str(p.relative_to(ROOT)),'source':str(src),'sha256':sha(p),'byte_identical':True})
    dump(ROOT/'freeze/SOURCE_PROVENANCE.json',prov)
    dump(ROOT/'freeze/PRE_RUN_FREEZE.json',{'utc':utc(),'main_launches_before_freeze':0,'main_geometries':16,'planned_runs':128,'duplicates':0,'sha256':{str(p.relative_to(ROOT)):sha(p) for directory in ['source','input','freeze'] for p in sorted((ROOT/directory).rglob('*')) if p.is_file()}})
    print('TOYS PASSED; sixteen fresh inputs and 128 planned runs frozen.')
if __name__=='__main__':main()
