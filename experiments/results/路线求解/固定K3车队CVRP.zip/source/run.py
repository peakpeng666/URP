"""Exactly one main numerical process: all heuristics first, then evaluation DP."""
import json,os,platform,sys,time
from common import ROOT,utc,read,dump,sha,verify
from fixed_solver import run_one

def main():
    start=time.process_time();wall=time.perf_counter();freeze=verify()
    dump(ROOT/'raw/STARTED.json',{'utc':utc(),'pid':os.getpid(),'main_launch_number':1,'freeze_sha256':sha(ROOT/'freeze/PRE_RUN_FREEZE.json')})
    affinity=sorted(os.sched_getaffinity(0)) if hasattr(os,'sched_getaffinity') else None
    if affinity:os.sched_setaffinity(0,{affinity[-1]})
    dump(ROOT/'receipts/ENVIRONMENT.json',{'utc':utc(),'python':sys.version,'platform':platform.platform(),'stdlib_only':True,'affinity_before':affinity,'selected_cpu':affinity[-1] if affinity else None,'external_calls':0,'dependency_installs':0})
    cfg=read(ROOT/'freeze/PROTOCOL.json');schedule=read(ROOT/'freeze/SCHEDULE.json');cpu=time.process_time();ws=time.perf_counter();records=[]
    with (ROOT/'raw/heuristics.jsonl').open('x') as out:
        for e in schedule:
            r=read(ROOT/e['input_file']);record=run_one(r,e['method'],e['search_seed'],cfg)
            record.update({'run_id':e['run_id'],'geometry_id':e['geometry_id'],'family':e['family'],'input_sha256':e['input_sha256'],'completed_utc':utc()})
            out.write(json.dumps(record,ensure_ascii=False,allow_nan=False)+'\n');out.flush();records.append(record)
    hcpu=time.process_time()-cpu;hwall=time.perf_counter()-ws
    dump(ROOT/'raw/HEURISTICS_FINISHED.json',{'utc':utc(),'planned':128,'recorded':len(records),'raw_sha256':sha(ROOT/'raw/heuristics.jsonl'),'oracle_main_calls_so_far':0,'heuristic_stage_cpu_seconds':hcpu,'heuristic_stage_wall_seconds':hwall})
    # Evaluation module deliberately imported only after all formal heuristic results are persisted.
    from oracle import solve
    cpu=time.process_time();ws=time.perf_counter();oracles=[]
    with (ROOT/'raw/oracles.jsonl').open('x') as out:
        for e in read(ROOT/'freeze/INPUT_MANIFEST.json'):
            r=read(ROOT/e['input_file']);cs=time.process_time();w=time.perf_counter();o=solve(r)
            row={'geometry_id':e['geometry_id'],'input_sha256':e['input_sha256'],'result':o,'oracle_cpu_seconds':time.process_time()-cs,'oracle_wall_seconds':time.perf_counter()-w,'completed_utc':utc()}
            out.write(json.dumps(row,allow_nan=False)+'\n');out.flush();oracles.append(row)
    ocpu=time.process_time()-cpu;owall=time.perf_counter()-ws;verify()
    dump(ROOT/'raw/FINISHED.json',{'utc':utc(),'heuristic_runs':len(records),'oracle_runs':len(oracles),'heuristic_cpu_seconds':hcpu,'heuristic_wall_seconds':hwall,'oracle_cpu_seconds':ocpu,'oracle_wall_seconds':owall,'main_internal_cpu_seconds':time.process_time()-start,'main_internal_wall_seconds':time.perf_counter()-wall,'source_and_inputs_unchanged':True,'all_heuristics_preceded_main_oracle':True})
    print(json.dumps({'heuristic_runs':len(records),'oracle_runs':len(oracles),'statuses':{x:sum(r['status']==x for r in records) for x in set(r['status'] for r in records)},'main_cpu_seconds':time.process_time()-start}))
if __name__=='__main__':main()
