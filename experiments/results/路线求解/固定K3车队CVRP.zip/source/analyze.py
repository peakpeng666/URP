"""Frozen local numerical/trace verification and denominator-complete analysis.
This is not the separate external independent audit requested from the parent.
"""
import csv,json,math,statistics,time
from collections import Counter
from common import ROOT,utc,read,dump,verify,sha
from audit import check

def mean(xs):return statistics.mean(xs) if xs else None
def fmt(x):return 'NA' if x is None else f'{x:.6f}'

def main():
    verify();t=time.process_time();cfg=read(ROOT/'freeze/PROTOCOL.json');entries=read(ROOT/'freeze/INPUT_MANIFEST.json');schedule=read(ROOT/'freeze/SCHEDULE.json')
    runs=[json.loads(l) for l in (ROOT/'raw/heuristics.jsonl').read_text().splitlines()];oracles=[json.loads(l) for l in (ROOT/'raw/oracles.jsonl').read_text().splitlines()]
    byid={r['run_id']:r for r in runs};assert len(byid)==len(runs);os={r['geometry_id']:r for r in oracles};inputs={e['geometry_id']:read(ROOT/e['input_file']) for e in entries}
    verification=[];rows=[];failures=[]
    for e in entries:
        oid=e['geometry_id'];out=os.get(oid)
        if out:
            for k,o in out['result']['by_k'].items():
                if o is not None:assert check(inputs[oid],dict(o,reported_cost=o['cost']),int(k))['accepted']
    for e in schedule:
        r=byid.get(e['run_id']);oid=e['geometry_id'];opt=None if oid not in os else os[oid]['result']['by_k']['3'];raw=inputs[oid]
        if r is None:
            rows.append({'run_id':e['run_id'],'geometry_id':oid,'family':e['family'],'method':e['method'],'search_seed':e['search_seed'],'status':'NOT_RUN','oracle_feasible':None if oid not in os else opt is not None,'legal_completion':False,'valid_output':False,'illegal_output':False,'gap_percent':None,'hit_le1_percent':False,'exact_hit':False,'cost':None,'oracle_cost':None if opt is None else opt['cost']})
            continue
        assert r['geometry_id']==oid and r['method']==e['method'] and r['search_seed']==e['search_seed'] and r['input_sha256']==e['input_sha256']
        assert r['deltas']<=cfg['delta_limit'] and sum(r['delta_by_kind'].values())==r['deltas']
        result=check(raw,r['output'],3);baseline=check(raw,r['baseline'],3)
        valid=result['accepted'];legal=valid and r['status']=='LEGAL_COMPLETION';illegal=r['output'] is not None and not valid
        if r['baseline'] is not None:assert baseline['accepted']
        prior=r['baseline'];accepted=failed=complete=cut=0;prior_deltas=0
        for tr in r['trace']:
            assert prior is not None
            assert tr['deltas']>=prior_deltas;prior_deltas=tr['deltas']
            if tr['candidate_status']=='complete':
                complete+=1;c=check(raw,tr['candidate'],3);assert c['accepted']
                should=c['cost']<prior['reported_cost']-1e-9
                assert tr['accepted']==should
                if should:prior=tr['candidate'];accepted+=1
            else:
                assert tr['candidate'] is None and not tr['accepted']
                failed+=tr['candidate_status']=='repair_failed';cut+=tr['candidate_status']=='budget_discarded'
            assert prior==tr['incumbent'] and check(raw,tr['incumbent'],3)['accepted']
        assert prior==r['output'];assert accepted==r['accepted_improvements'] and failed==r['repair_failures'] and complete==r['iterations_completed']
        verification.append({'run_id':r['run_id'],'baseline_legal':baseline['accepted'],'output_valid':valid,'trace_count':len(r['trace']),'completed_candidates':complete,'accepted_candidates':accepted,'failed_candidates':failed,'budget_discarded_candidates':cut,'atomic_rollback_verified':True,'all_accepted_legal':True})
        cost=result['cost'] if valid else None;gap=100*(cost-opt['cost'])/opt['cost'] if legal and opt is not None and opt['cost']>0 else None
        tol=max(1e-8,1e-10*abs(opt['cost'])) if opt else 1e-8
        if legal and opt is not None:assert cost>=opt['cost']-tol
        row={'run_id':r['run_id'],'geometry_id':oid,'family':e['family'],'method':r['method'],'search_seed':r['search_seed'],'status':r['status'],'stop_reason':r['stop_reason'],'oracle_feasible':None if oid not in os else opt is not None,'legal_completion':legal,'valid_output':valid,'illegal_output':illegal,'gap_percent':gap,'hit_le1_percent':bool(legal and opt is not None and cost<=opt['cost']*1.01+tol),'exact_hit':bool(legal and opt is not None and abs(cost-opt['cost'])<=tol),'cost':cost,'oracle_cost':None if opt is None else opt['cost'],'baseline_cost':baseline['cost'] if baseline['accepted'] else None,'routes':result.get('nonempty_routes'),'deltas':r['deltas'],'solver_cpu_seconds':r['solver_cpu_seconds'],'solver_wall_seconds':r['solver_wall_seconds'],'repair_failures':r['repair_failures'],'fallback_triggered':bool(r['initialization'] and r['initialization']['fallback_triggered']),'initialization_deltas':None if not r['initialization'] else r['initialization'].get('deltas_after_initialization'),'accepted_improvements':r['accepted_improvements']}
        rows.append(row)
        if not legal:failures.append(row|{'error':r['error'],'checker':result})
    # Every method/search seed pays for and uses the same deterministic initialization.
    baseline_consistency=[]
    for e in entries:
        g=[r for r in runs if r['geometry_id']==e['geometry_id']]
        same=not g or all(r['baseline']==g[0]['baseline'] and r['initialization']==g[0]['initialization'] for r in g)
        assert same;baseline_consistency.append({'geometry_id':e['geometry_id'],'identical_common_initialization':same})
    common=[e['geometry_id'] for e in entries if len([r for r in rows if r['geometry_id']==e['geometry_id'] and r['legal_completion'] and r['oracle_feasible']])==8]
    geom=[]
    for e in entries:
        item={'geometry_id':e['geometry_id'],'family':e['family'],'common_support':e['geometry_id'] in common,'oracle_feasible':e['geometry_id'] in os and os[e['geometry_id']]['result']['by_k']['3'] is not None}
        for m in cfg['methods']:
            rs=[r for r in rows if r['geometry_id']==e['geometry_id'] and r['method']==m];gs=[r['gap_percent'] for r in rs if r['gap_percent'] is not None]
            item[m]={'planned':4,'legal':sum(r['legal_completion'] for r in rs),'hit_le1_percent':sum(r['hit_le1_percent'] for r in rs),'mean_gap_percent':mean(gs) if len(gs)==4 else None,'worst_seed_gap_percent':max(gs) if gs else None,'cost_mean_all4':mean([r['cost'] for r in rs]) if all(r['legal_completion'] for r in rs) else None}
        geom.append(item)
    summaries={}
    for m in cfg['methods']:
        rs=[r for r in rows if r['method']==m];commonmeans=[g[m]['mean_gap_percent'] for g in geom if g['common_support']];validgaps=[r for r in rs if r['gap_percent'] is not None]
        worst=max(validgaps,key=lambda r:r['gap_percent']) if validgaps else None
        summaries[m]={'planned':len(rs),'oracle_feasible_planned':sum(r['oracle_feasible'] is True for r in rs),'oracle_infeasible_planned':sum(r['oracle_feasible'] is False for r in rs),'oracle_missing_planned':sum(r['oracle_feasible'] is None for r in rs),'legal_completion_count':sum(r['legal_completion'] for r in rs),'legal_completion_rate_planned':sum(r['legal_completion'] for r in rs)/len(rs),'valid_output_count':sum(r['valid_output'] for r in rs),'illegal_output_count':sum(r['illegal_output'] for r in rs),'status_counts':dict(Counter(r['status'] for r in rs)),'le1_percent_count_planned':sum(r['hit_le1_percent'] for r in rs),'le1_percent_rate_planned':sum(r['hit_le1_percent'] for r in rs)/len(rs),'exact_hit_count':sum(r['exact_hit'] for r in rs),'common_geometry_count':len(common),'common_geometry_mean_gap_percent':mean(commonmeans),'common_geometry_median_gap_percent':statistics.median(commonmeans) if commonmeans else None,'worst_seed':worst,'fallback_trajectory_count':sum(r.get('fallback_triggered',False) for r in rs),'repair_failure_count':sum(r.get('repair_failures',0) for r in rs),'delta_sum':sum(r.get('deltas',0) for r in rs),'solver_cpu_seconds':sum(r.get('solver_cpu_seconds',0) for r in rs),'solver_wall_seconds':sum(r.get('solver_wall_seconds',0) for r in rs)}
    pairs=[g['regret2']['mean_gap_percent']-g['cheapest']['mean_gap_percent'] for g in geom if g['common_support']]
    win=tie=loss=0
    for g in geom:
        if not g['common_support']:continue
        diff=g['regret2']['cost_mean_all4']-g['cheapest']['cost_mean_all4']
        if diff< -1e-8:win+=1
        elif diff>1e-8:loss+=1
        else:tie+=1
    summary={'utc':utc(),'planned_geometries':16,'oracle_feasible_geometries':sum(os[e['geometry_id']]['result']['by_k']['3'] is not None for e in entries if e['geometry_id'] in os),'planned_runs':128,'recorded_runs':len(runs),'illegal_outputs_total':sum(r['illegal_output'] for r in rows),'legal_completion_total':sum(r['legal_completion'] for r in rows),'common_support_geometry_ids':common,'methods':summaries,'paired_regret2_minus_cheapest_mean_gap_pp':mean(pairs),'regret2_win_tie_loss_geometry_mean_cost':[win,tie,loss],'seed_repeats_not_independent_samples':True,'family_breakdowns_descriptive_only':{f:{m:{'planned':sum(r['family']==f and r['method']==m for r in rows),'le1_count':sum(r['family']==f and r['method']==m and r['hit_le1_percent'] for r in rows),'common_geometry_mean_gap_percent':mean([g[m]['mean_gap_percent'] for g in geom if g['common_support'] and g['family']==f])} for m in cfg['methods']} for f in ['uniform','two_cluster']},'main_receipt':read(ROOT/'receipts/main.json'),'run_times':read(ROOT/'raw/FINISHED.json'),'analysis_cpu_seconds':time.process_time()-t,'independent_external_review_status':'pending'}
    dump(ROOT/'reports/SUMMARY.json',summary);dump(ROOT/'reports/GEOMETRY_RESULTS.json',geom);dump(ROOT/'reports/RUN_METRICS.json',rows);dump(ROOT/'reports/TRACE_CHECKS.json',{'verified':True,'runs':verification,'baseline_consistency':baseline_consistency,'illegal_output_zero':summary['illegal_outputs_total']==0});dump(ROOT/'failures/FAILURE_LEDGER.json',{'failed_planned_runs':failures,'not_run':[r for r in rows if r['status']=='NOT_RUN'],'oracle_infeasible_geometry_ids':[e['geometry_id'] for e in entries if e['geometry_id'] in os and os[e['geometry_id']]['result']['by_k']['3'] is None],'repair_failures_total':sum(v['failed_candidates'] for v in verification),'budget_discards_total':sum(v['budget_discarded_candidates'] for v in verification),'full_candidate_failure_evidence':'raw/heuristics.jsonl: trace candidate_status, detail, and retained incumbent'})
    fields=sorted(set().union(*(r.keys() for r in rows)))
    with (ROOT/'reports/RUN_METRICS.csv').open('x') as f:
        wr=csv.DictWriter(f,fieldnames=fields);wr.writeheader();wr.writerows(rows)
    a=summaries['cheapest'];b=summaries['regret2'];fallbackgeoms=sorted(set(r['geometry_id'] for r in rows if r.get('fallback_triggered')))
    text='固定车队 CVRP 最小机制实验（外部独审待完成）\n\n'
    text+=f'计划：16 个全新几何、2 方法、4 配对重复 seed，共128次；n9/Q9/K≤3；每次5000 delta含初始化。oracle证明固定K可行几何 {summary["oracle_feasible_geometries"]}/16。未按解质量筛样本，所有计划分母保留。\n'
    text+=f'合法完成：cheapest {a["legal_completion_count"]}/64，regret2 {b["legal_completion_count"]}/64；非法非空输出 {summary["illegal_outputs_total"]}；INIT_FAIL分别 {a["status_counts"].get("INIT_FAIL",0)}/{b["status_counts"].get("INIT_FAIL",0)}。\n'
    text+=f'合法且 gap≤1%：cheapest {a["le1_percent_count_planned"]}/64，regret2 {b["le1_percent_count_planned"]}/64。精确命中分别 {a["exact_hit_count"]}/64、{b["exact_hit_count"]}/64。\n'
    text+=f'双方四seed均合法共同支持几何 {len(common)}/16：先在每几何平均seed后，平均gap为 cheapest {fmt(a["common_geometry_mean_gap_percent"])}%，regret2 {fmt(b["common_geometry_mean_gap_percent"])}%；配对 RR2−cheapest {fmt(mean(pairs))} 个百分点；RR2赢/平/负 {win}/{tie}/{loss}。\n'
    for m,s in summaries.items():
        w=s['worst_seed']
        if w is None:
            text+=f'{m} 无合法可评分seed。\n';continue
        text+=f'{m} 最坏seed：{w["geometry_id"]} seed {w["search_seed"]}，gap {w["gap_percent"]:.6f}%，cost {w["cost"]:.12f}，oracle {w["oracle_cost"]:.12f}。\n'
    text+=f'共同初始化触发FFD：{len(fallbackgeoms)}/16几何（{fallbackgeoms}）；每方法触发 {a["fallback_trajectory_count"]}/64、{b["fallback_trajectory_count"]}/64。repair失败候选分别 {a["repair_failure_count"]}、{b["repair_failure_count"]}，全部丢弃并保留合法incumbent。\n'
    rec=summary['main_receipt'];text+=f'单次主进程 exit {rec["exit_code"]}，CPU {rec["child_total_cpu_seconds"]:.6f}秒，wall {rec["elapsed_wall_seconds"]:.6f}秒；上限CPU90/wall150。调用delta合计{a["delta_sum"]+b["delta_sum"]}。\n\n'
    text+='解释边界：本轮首先证明固定K门控与原子回退在这批数据正常运作；仅16个小型新开发几何、固定需求多重集，不能外推到大规模或任意装箱分布。4个seed是同一几何的重复，并非64个独立样本。旧无K内核未作本轮有效成绩，旧EX06未重用。无外部API/模型调用/安装/上传。数值oracle为完整组合枚举加双精度成本，不是区间算术证明。\n'
    text+='证据：freeze/含规则、toy预注册、source和input哈希；raw/含所有轨迹、完整失败和oracle；reports/含逐运行/逐几何/trace重查；receipts/含退出、CPU、wall。\n'
    (ROOT/'reports/REPORT_ZH.txt').write_text(text)
    verify();print(json.dumps({'summary':str(ROOT/'reports/SUMMARY.json'),'legal_runs':summary['legal_completion_total'],'illegal_outputs':summary['illegal_outputs_total'],'cheapest_le1':a['le1_percent_count_planned'],'regret2_le1':b['le1_percent_count_planned'],'mean_gap_percent':[a['common_geometry_mean_gap_percent'],b['common_geometry_mean_gap_percent']]}))
if __name__=='__main__':main()
