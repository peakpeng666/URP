from common import *
verify()
import capacity_solver as c, fixed_solver as f
from audit import unit_tests,check
checks=unit_tests();cases=[]
for n in [9,27,54]:
 raw={'demands':[0]+[1]*n,'coordinates':[[i,0] for i in range(n+1)],'capacity':9,'K':n//3}
 for mod in [f,c]:
  inst=mod.instance_for(raw);assert inst.n_customers==n and inst.K==n//3
  b=mod.Budget(100000,30,60);m=mod.matrix_for(inst,b);r,cost,d=mod.initialize(raw,inst,m,b)
  assert check(raw,mod.output_for(r,cost),inst.K)['accepted'];cases.append({'n':n,'arm':mod.__name__,'accepted':True})
g,diag=c.bounded_partition([0,4,4,4,3,3,3,2,2,2],9,3);assert g is not None and diag['nodes']<=256
_,lim=c.bounded_partition([0,1,1],2,1,node_limit=1);assert lim['nodes']==1 and lim['limit_reached']
dump(ROOT/'reports/TOYS.json',{'utc':utc(),'independent_checker_tests':checks,'parameterization_cases':cases,'tight_n9_DFS':diag,'node_limit_guard':lim,'main_inputs_read':False})
