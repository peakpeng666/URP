import importlib,os,time
from common import *
freeze=verify()
dump(ROOT/'raw/STARTED.json',{'utc':utc(),'freeze_sha256':sha(ROOT/'freeze/PRE_RUN_FREEZE.json')})
with (ROOT/'raw/results.jsonl').open('x') as out:
 for item in read(ROOT/'freeze/SCHEDULE.json'):
  raw=read(ROOT/'input'/f"{item['instance_id']}.json");mod=importlib.import_module(item['arm']);inst=mod.instance_for(raw)
  budget=mod.Budget(100000,30,60);output=None;diag=None;status='INITFAIL';stop=None;err=None;stage='matrix'
  cpu=time.process_time();wall=time.perf_counter()
  try:
   matrix=mod.matrix_for(inst,budget);stage='initialization'
   routes,cost,diag=mod.initialize(raw,inst,matrix,budget)
   output=mod.output_for(routes,cost);status='SUCCESS';stop='initialization_complete';stage='complete'
  except mod.InitFailure as ex:stop=str(ex);diag=getattr(ex,'detail',None);err=type(ex).__name__
  except mod.StopBudget as ex:status='BUDGET';stop=str(ex);err=type(ex).__name__
  except Exception as ex:status='ERROR';stop=str(ex);err=type(ex).__name__
  usage=budget.snapshot()
  result={**item,'n':raw['n'],'family':raw['family'],'input_sha256':sha(ROOT/'input'/f"{item['instance_id']}.json"),'status':status,'stop_reason':stop,'error_type':err,'stop_stage':stage,'initialization':diag,'output':output,'cpu_seconds':time.process_time()-cpu,'wall_seconds':time.perf_counter()-wall,**usage}
  out.write(json.dumps(result,allow_nan=False)+'\n');out.flush();os.fsync(out.fileno())
  if status in ['BUDGET','ERROR']:
   dump(ROOT/'raw/ABORTED.json',{'utc':utc(),'reason':status,'call':item,'no_retry':True});raise SystemExit(2)
dump(ROOT/'raw/FINISHED.json',{'utc':utc(),'calls':72,'results_sha256':sha(ROOT/'raw/results.jsonl'),'witness_read':False,'local_search_calls':0,'oracle_calls':0})
print('72 initialization calls sealed.')
