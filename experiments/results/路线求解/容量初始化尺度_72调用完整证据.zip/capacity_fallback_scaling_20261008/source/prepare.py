import random,sys,platform
from common import *
OLD=Path('/workspace/shared/capacity_partition_fallback_20261008/source')
protocol={'utc':utc(),'question':'Initialization feasibility scaling only; no local search, oracle, filtering, tuning or retries','n':[9,27,54],'Q':9,'K':'n/3 upper bound','families':['tight','feasible_random','loose'],'replicates':4,'calls':72,'base_seed':2026100802535100,'seed_rule':'base + 10000*n + 100*family_index + replicate; demand seed=geometry seed+100000000; shuffle seed=geometry seed+200000000','geometry':'independent random.Random(seed).uniform(0,100) for x,y of depot AND n customers','tight':'[4,4,4,3,3,3,2,2,2] repeated n/9; shuffled customer labels; known mechanism regression','feasible_random':'K independent triples, each component randint(1,3); shuffle labels; no feasibility-based selection','loose':'all 1; shuffled labels','arms':['fixed_solver','capacity_solver'],'dfs_nodes':256,'delta_limit':100000,'per_call_cpu':30,'per_call_wall':60,'main_cpu_hard':30,'main_cpu_soft':29,'main_wall':60,'metrics':['status','stop_reason','coverage/capacity/K independent check','deltas by kind','cpu/wall','DFS nodes/outcome/limit','savings route count','FFD failure'],'witness_policy':'separate files never read/imported by main; only checked after raw result seal','interpretation':'not search quality, not realistic agriculture; all-success only within these groups; local timestamp not external timestamp'}
dump(ROOT/'freeze/PRE_GENERATION.json',protocol)
old=read(ROOT/'provenance/OLD_GEOMETRY_HASHES.json');old_o=set(old['ordered_hashes']);old_u=set(old.get('unordered_hashes',[]))
for g in read(ROOT/'provenance/GEOMETRY_MANIFEST.json'):old_o.add(g['coordinates_sha256']);old_u.add(g['unordered_coordinates_sha256'])
manifest=[];schedule=[]
for n in protocol['n']:
 for fi,family in enumerate(protocol['families']):
  for rep in range(4):
   ident=f'N{n:02d}-{family}-R{rep+1}';seed=protocol['base_seed']+10000*n+100*fi+rep; rng=random.Random(seed)
   xy=[[rng.uniform(0,100),rng.uniform(0,100)] for _ in range(n+1)]
   if family=='tight':d=[4,4,4,3,3,3,2,2,2]*(n//9);groups=[[j+i,j+i+3,j+i+6] for j in range(1,n+1,9) for i in range(3)]
   elif family=='feasible_random':dr=random.Random(seed+100000000);d=[dr.randint(1,3) for _ in range(n)];groups=[list(range(j,j+3)) for j in range(1,n+1,3)]
   else:d=[1]*n;groups=[list(range(j,j+3)) for j in range(1,n+1,3)]
   perm=list(range(1,n+1));random.Random(seed+200000000).shuffle(perm);dem=[0]+[0]*n
   for oldid,newid in enumerate(perm,1):dem[newid]=d[oldid-1]
   witness=[[perm[j-1] for j in g] for g in groups]
   raw={'instance_id':ident,'n':n,'family':family,'replicate':rep+1,'coordinates':xy,'demands':dem,'capacity':9,'K':n//3}
   oh=digest(xy);uh=digest(sorted(xy));assert oh not in old_o and uh not in old_u
   dump(ROOT/'input'/f'{ident}.json',raw);dump(ROOT/'witness'/f'{ident}.json',{'groups':witness})
   manifest.append({'instance_id':ident,'geometry_seed':seed,'demand_seed':seed+100000000,'shuffle_seed':seed+200000000,'coordinates_sha256':oh,'unordered_coordinates_sha256':uh,'prior_geometry_collision':False})
   for arm in protocol['arms']:schedule.append({'instance_id':ident,'arm':arm})
assert len({g['coordinates_sha256'] for g in manifest})==36
prov=[]
for p in sorted((ROOT/'source').rglob('*.py')):
 q=OLD/p.relative_to(ROOT/'source')
 if q.exists():assert p.read_bytes()==q.read_bytes();prov.append({'file':str(p.relative_to(ROOT)),'upstream_sha256':sha(q),'copied_sha256':sha(p),'byte_identical':True})
dump(ROOT/'provenance/CORE_BYTE_CHECK.json',prov)
(ROOT/'provenance/CORE_DIFF.patch').write_text('# Empty patch: all inherited sources byte-identical. Existing instance_for uses len(demands)-1 and raw K; no n/K modification required. Only new harness/generator/analysis files.\n')
dump(ROOT/'freeze/GEOMETRY_MANIFEST.json',manifest);dump(ROOT/'freeze/SCHEDULE.json',schedule)
dump(ROOT/'receipts/ENVIRONMENT.json',{'utc':utc(),'python':sys.version,'platform':platform.platform(),'model_api_calls':0,'installs':0,'uploads':0})
files=[p for folder in ['source','input','witness','provenance','freeze'] for p in (ROOT/folder).rglob('*') if p.is_file()]
dump(ROOT/'freeze/PRE_RUN_FREEZE.json',{'utc':utc(),'sha256':{str(p.relative_to(ROOT)):sha(p) for p in sorted(files)}})
print('Frozen 36 inputs, 72 calls and all source before toys/main.')
