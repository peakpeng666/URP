import collections,math,csv
from common import *
verify()
finished=read(ROOT/'raw/FINISHED.json');assert sha(ROOT/'raw/results.jsonl')==finished['results_sha256']
rows=[json.loads(s) for s in (ROOT/'raw/results.jsonl').read_text().splitlines()];assert len(rows)==72
checks=[];groups={};metrics=[];wchecks=[];by_pair={}
# Post-hoc independent checking; no imported solver/checker or matrix.
def independent(raw,output):
 if output is None:return {'present':False,'accepted':False,'errors':['no_output']}
 routes=output['routes'];flat=[];loads=[];cost=0.;errors=[]
 for route in routes:
  if len(route)<3 or route[0]!=0 or route[-1]!=0 or any(type(i)!=int or i<1 or i>raw['n'] for i in route[1:-1]):errors.append('route_shape');continue
  flat+=route[1:-1];loads.append(sum(raw['demands'][i] for i in route[1:-1]))
  for a,b in zip(route,route[1:]):
   ax,ay=raw['coordinates'][a];bx,by=raw['coordinates'][b];cost+=((ax-bx)**2+(ay-by)**2)**.5
 if sorted(flat)!=list(range(1,raw['n']+1)):errors.append('coverage')
 if len(routes)>raw['K']:errors.append('K')
 if any(x>raw['capacity'] for x in loads):errors.append('capacity')
 if not math.isclose(cost,output['reported_cost'],abs_tol=1e-8,rel_tol=1e-10):errors.append('cost')
 return {'present':True,'accepted':not errors,'errors':errors,'customer_count':len(flat),'loads':loads,'routes':len(routes),'K':raw['K'],'recomputed_cost':cost}
for row in rows:
 raw=read(ROOT/'input'/f"{row['instance_id']}.json");assert row['input_sha256']==sha(ROOT/'input'/f"{row['instance_id']}.json")
 chk=independent(raw,row['output']);checks.append({'instance_id':row['instance_id'],'arm':row['arm'],**chk})
 assert (row['status']=='SUCCESS')==chk['accepted'];assert row['deltas']<=100000 and row['delta_by_kind']['removal']==0
 key=(row['n'],row['family'],row['arm']);g=groups.setdefault(key,{'n':key[0],'family':key[1],'arm':key[2],'calls':0,'success':0,'INITFAIL':0,'BUDGET':0,'ERROR':0,'DFS_calls':0,'DFS_nodes':[],'DFS_outcomes':{},'stops':{},'deltas_total':0,'cpu_total':0.,'wall_total':0.})
 g['calls']+=1;g['success' if row['status']=='SUCCESS' else row['status']]+=1;g['deltas_total']+=row['deltas'];g['cpu_total']+=row['cpu_seconds'];g['wall_total']+=row['wall_seconds'];g['stops'][row['stop_reason']]=g['stops'].get(row['stop_reason'],0)+1
 diag=row['initialization'] or {};dfs=diag.get('capacity_partition')
 if dfs:g['DFS_calls']+=1;g['DFS_nodes'].append(dfs['nodes']);g['DFS_outcomes'][dfs['outcome']]=g['DFS_outcomes'].get(dfs['outcome'],0)+1;assert dfs['node_limit']==256 and dfs['nodes']<=256
 metrics.append({'instance_id':row['instance_id'],'n':row['n'],'family':row['family'],'arm':row['arm'],'status':row['status'],'stop_reason':row['stop_reason'],'deltas':row['deltas'],'cpu_seconds':row['cpu_seconds'],'wall_seconds':row['wall_seconds'],'savings_routes':diag.get('savings_route_count'),'FFD_triggered':diag.get('fallback_triggered'),'DFS_nodes':dfs['nodes'] if dfs else 0,'DFS_outcome':dfs['outcome'] if dfs else 'NOT_CALLED','DFS_limit_reached':dfs['limit_reached'] if dfs else False,'independent_accepted':chk['accepted']})
 by_pair.setdefault(row['instance_id'],{})[row['arm']]=row
for ident, pair in by_pair.items():
 raw=read(ROOT/'input'/f'{ident}.json');w=read(ROOT/'witness'/f'{ident}.json')['groups'];flat=[i for g in w for i in g];loads=[sum(raw['demands'][i] for i in g) for g in w]
 ok=sorted(flat)==list(range(1,raw['n']+1)) and len(w)<=raw['K'] and all(v<=9 for v in loads);assert ok
 wchecks.append({'instance_id':ident,'accepted':ok,'loads':loads,'group_count':len(w),'checked_only_after_raw_seal':True})
 assert pair['fixed_solver']['input_sha256']==pair['capacity_solver']['input_sha256']
 if pair['fixed_solver']['status']=='SUCCESS':assert pair['fixed_solver']['output']==pair['capacity_solver']['output'] and pair['fixed_solver']['deltas']==pair['capacity_solver']['deltas']
summary=list(groups.values());dump(ROOT/'reports/SUMMARY.json',summary);dump(ROOT/'reports/OUTPUT_CHECKS.json',checks);dump(ROOT/'reports/WITNESS_CHECKS.json',wchecks)
with (ROOT/'reports/METRICS.csv').open('x',newline='') as f:w=csv.DictWriter(f,fieldnames=list(metrics[0]));w.writeheader();w.writerows(metrics)
r=read(ROOT/'receipts/main.json')
lines=['容量初始化尺度试验：单次冻结，36新输入×两臂＝72调用。','仅初始化，不运行局部搜索；K为最多车辆数；Q=9；每臂delta上限100000，原DFS上限256已入节点（根与完成节点计入）。','每规模每族4个独立uniform新几何，客户及仓库坐标均在[0,100]独立生成。两臂同输入，无筛选、oracle或见证热启动。','tight为已见失败机制的规模重复，不是全新机制；feasible_random来自1..3三项组（容量至多9）并打乱标签；loose全1。所有36例事后见证核验可行。','原继承源码全部字节相同，无n/K修正；现成参数化由9/27/54玩具验证。','']
for g in summary:
 lines.append(f"n={g['n']} {g['family']} {g['arm']}: 成功{g['success']}/{g['calls']}，INITFAIL {g['INITFAIL']}/{g['calls']}，budget {g['BUDGET']}，错误{g['ERROR']}；DFS调用{g['DFS_calls']}，节点{g['DFS_nodes']}，结局{g['DFS_outcomes']}；终止{g['stops']}")
lines+=['',f"独立客户覆盖/容量/K/成本检查：成功输出均通过；失败不输出解。主进程CPU {r['total_cpu_seconds']:.6f}s，wall {r['elapsed_wall_seconds']:.6f}s，退出{r['exit_code']}，硬限CPU30/wall60s。",'DFS节点限额失败不是数学不可行；所有全成功描述只限该36输入及相应分组。每格仅4个几何，不可作可扩展或现实农业分布结论。不同n需求/几何实例并非相同实例放大配对。','初始化delta之外，DFS节点是额外有界工作，分别报告CPU/wall；初始化成本不作搜索质量胜负。未执行后续搜索或oracle。','原算法成功的配对：输出与delta严格相同。所有结果逐行fsync，结束hash封存后才读取独立见证。','准备/玩具/分析/包装资源另列receipts，主跑仅一次，不盲重试。未调用模型/API、安装或上传；token费用未知。冻结/时间戳为本地证据，非第三方可信时间戳。']
(ROOT/'reports/REPORT_ZH.txt').write_text('\n'.join(lines)+'\n');print('\n'.join(lines))
