import os,resource,signal,subprocess,sys,time
from common import *
if (ROOT/'receipts/main.json').exists() or (ROOT/'raw/STARTED.json').exists():raise SystemExit('No rerun permitted')
start=time.perf_counter()
def pre():os.setsid();resource.setrlimit(resource.RLIMIT_CPU,(29,30))
with (ROOT/'receipts/main.stdout.log').open('x') as out,(ROOT/'receipts/main.stderr.log').open('x') as err:
 child=subprocess.Popen([sys.executable,'-B',str(ROOT/'source/run.py')],stdout=out,stderr=err,preexec_fn=pre)
 killed=False
 while True:
  pid,status,usage=os.wait4(child.pid,os.WNOHANG)
  if pid:break
  if time.perf_counter()-start>=60:
   killed=True;os.killpg(child.pid,signal.SIGKILL);pid,status,usage=os.wait4(child.pid,0);break
  time.sleep(.01)
 code=os.waitstatus_to_exitcode(status);child.returncode=code
 receipt={'utc':utc(),'exit_code':code,'signal':-code if code<0 else None,'cpu_soft_limit_seconds':29,'cpu_hard_limit_seconds':30,'wall_limit_seconds':60,'wall_limit_kill':killed,'user_cpu_seconds':usage.ru_utime,'system_cpu_seconds':usage.ru_stime,'total_cpu_seconds':usage.ru_utime+usage.ru_stime,'elapsed_wall_seconds':time.perf_counter()-start,'maxrss_kib':usage.ru_maxrss,'complete':code==0,'no_retry':True}
 dump(ROOT/'receipts/main.json',receipt);print(json.dumps(receipt));sys.exit(code)
