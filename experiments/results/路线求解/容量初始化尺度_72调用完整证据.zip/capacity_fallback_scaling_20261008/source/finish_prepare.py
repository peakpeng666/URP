# Recovery only: preserve original failed prepare.py, inputs, witnesses, protocol and receipt.
# Failure was provenance selection including new same-name harness sources; no solver ran.
import sys,platform
from common import *
assert not (ROOT/'raw/STARTED.json').exists() and not (ROOT/'freeze/PRE_RUN_FREEZE.json').exists()
protocol=read(ROOT/'freeze/PRE_GENERATION.json');old=read(ROOT/'provenance/OLD_GEOMETRY_HASHES.json');old_o=set(old['ordered_hashes']);old_u=set(old.get('unordered_hashes',[]))
for g in read(ROOT/'provenance/GEOMETRY_MANIFEST.json'):old_o.add(g['coordinates_sha256']);old_u.add(g['unordered_coordinates_sha256'])
manifest=[];schedule=[]
for n in protocol['n']:
 for fi,family in enumerate(protocol['families']):
  for rep in range(4):
   ident=f'N{n:02d}-{family}-R{rep+1}';seed=protocol['base_seed']+10000*n+100*fi+rep
   raw=read(ROOT/'input'/f'{ident}.json');xy=raw['coordinates'];oh=digest(xy);uh=digest(sorted(xy));assert oh not in old_o and uh not in old_u
   manifest.append({'instance_id':ident,'geometry_seed':seed,'demand_seed':seed+100000000,'shuffle_seed':seed+200000000,'coordinates_sha256':oh,'unordered_coordinates_sha256':uh,'prior_geometry_collision':False})
   for arm in protocol['arms']:schedule.append({'instance_id':ident,'arm':arm})
assert len(manifest)==36 and len({g['coordinates_sha256'] for g in manifest})==36
OLD=Path('/workspace/shared/capacity_partition_fallback_20261008/source');prov=[]
inherited=[ROOT/'source'/name for name in ['fixed_solver.py','capacity_solver.py','audit.py','common.py']]+list((ROOT/'source/legacy').rglob('*.py'))
for p in sorted(inherited):
 q=OLD/p.relative_to(ROOT/'source');assert p.read_bytes()==q.read_bytes();prov.append({'file':str(p.relative_to(ROOT)),'upstream_sha256':sha(q),'copied_sha256':sha(p),'byte_identical':True})
dump(ROOT/'provenance/CORE_BYTE_CHECK.json',prov)
(ROOT/'provenance/CORE_DIFF.patch').write_text('# Empty: copied core byte-identical; n/K already dynamic. New harness separate. prepare.py retained with failed overbroad provenance assertion; finish_prepare.py completes only provenance and freeze without regenerating inputs or witnesses.\n')
dump(ROOT/'freeze/GEOMETRY_MANIFEST.json',manifest);dump(ROOT/'freeze/SCHEDULE.json',schedule)
dump(ROOT/'receipts/ENVIRONMENT.json',{'utc':utc(),'python':sys.version,'platform':platform.platform(),'model_api_calls':0,'installs':0,'uploads':0})
dump(ROOT/'receipts/PREPARATION_RECOVERY.json',{'utc':utc(),'failure':'new harness sources sharing upstream names wrongly included in copied-byte assertion','preserved':'all original source, generated inputs, witnesses, pre-generation protocol, stderr and CPU receipt','fix':'explicit copied-source list in finish_prepare.py','main_runs_before_recovery':0,'regenerated_inputs':0})
files=[p for folder in ['source','input','witness','provenance','freeze'] for p in (ROOT/folder).rglob('*') if p.is_file()]
dump(ROOT/'freeze/PRE_RUN_FREEZE.json',{'utc':utc(),'sha256':{str(p.relative_to(ROOT)):sha(p) for p in sorted(files)}})
print('Frozen existing 36 inputs and 72 call schedule. No regeneration.')
