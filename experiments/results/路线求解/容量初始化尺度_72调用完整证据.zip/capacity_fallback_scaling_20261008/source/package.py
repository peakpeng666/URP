import zipfile
from common import *
verify()
files=[p for p in ROOT.rglob('*') if p.is_file() and p.suffix!='.zip' and p.name not in ['SHA256SUMS.txt','archive.sha256']]
(ROOT/'SHA256SUMS.txt').write_text(''.join(sha(p)+'  '+str(p.relative_to(ROOT))+'\n' for p in sorted(files)))
archive=ROOT/(ROOT.name+'.zip')
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(files)+[ROOT/'SHA256SUMS.txt']:z.write(p,str(p.relative_to(ROOT.parent)))
(ROOT/'archive.sha256').write_text(sha(archive)+'  '+archive.name+'\n');print(archive,sha(archive))
