import os,subprocess,sys,time
from common import *
stage=sys.argv[1];assert stage in ['prepare','finish_prepare','toys','analyze','package']
receipt=ROOT/'receipts'/f'{stage}.json'
assert not receipt.exists(),'No stage retry'
start=time.perf_counter()
with (ROOT/'receipts'/f'{stage}.stdout.log').open('x') as out,(ROOT/'receipts'/f'{stage}.stderr.log').open('x') as err:
 p=subprocess.Popen([sys.executable,'-B',str(ROOT/'source'/f'{stage}.py')],stdout=out,stderr=err)
 _,status,usage=os.wait4(p.pid,0);code=os.waitstatus_to_exitcode(status);p.returncode=code
r={'utc':utc(),'stage':stage,'exit_code':code,'user_cpu_seconds':usage.ru_utime,'system_cpu_seconds':usage.ru_stime,'total_cpu_seconds':usage.ru_utime+usage.ru_stime,'wall_seconds':time.perf_counter()-start,'maxrss_kib':usage.ru_maxrss}
dump(receipt,r);print(json.dumps(r));sys.exit(code)
