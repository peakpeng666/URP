#!/usr/bin/env python3
"""Descriptive geometry dependence audit. Never changes instance selection."""
from collections import Counter
from datetime import datetime,timezone
from pathlib import Path
import hashlib,itertools,json,resource,time
resource.setrlimit(resource.RLIMIT_CPU,(15,15))
ROOT=Path(__file__).resolve().parent;OLD=Path('/workspace/shared/official_cvrp_benchmarks_20261008')
start=time.monotonic();cpu=time.process_time()
def load(p):return json.loads(p.read_text())
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
fp=ROOT/'audit/01_fixed_selection.json';before=hashlib.sha256(fp.read_bytes()).hexdigest();f=load(fp)
data=[]
for name in ['A-n32-k5','B-n31-k5','P-n40-k5']:
 obj=load(OLD/f'clean/{name}.instance.json');data.append({'group':'old_exploration','name':name,'coordinates':obj['coordinates']})
for s in f['selected']:
 obj=load(ROOT/f"solver_inputs/{s['name']}.instance.json");data.append({'group':'new_frozen_validation','name':s['name'],'coordinates':obj['coordinates']})
pairs=[]
for a,b in itertools.combinations(data,2):
 A=Counter(map(tuple,a['coordinates'][1:]));B=Counter(map(tuple,b['coordinates'][1:]));As=set(A);Bs=set(B)
 mi=sum((A&B).values());mu=sum((A|B).values());ui=len(As&Bs);uu=len(As|Bs)
 AF=set(map(tuple,a['coordinates']));BF=set(map(tuple,b['coordinates']))
 pairs.append({'a':a['name'],'b':b['name'],'groups':[a['group'],b['group']],'same_depot_coordinate':a['coordinates'][0]==b['coordinates'][0],
 'customer_multiset':{'a_count':sum(A.values()),'b_count':sum(B.values()),'intersection_count':mi,'union_count':mu,'fraction_of_a_shared':mi/sum(A.values()),'fraction_of_b_shared':mi/sum(B.values()),'jaccard':mi/mu,'overlap_over_smaller':mi/min(sum(A.values()),sum(B.values())),'a_is_submultiset_of_b':not(A-B),'b_is_submultiset_of_a':not(B-A)},
 'customer_unique_coordinate_sets':{'a_unique_count':len(As),'b_unique_count':len(Bs),'intersection_count':ui,'union_count':uu,'fraction_of_a_shared':ui/len(As),'fraction_of_b_shared':ui/len(Bs),'jaccard':ui/uu,'overlap_over_smaller':ui/min(len(As),len(Bs)),'a_is_subset_of_b':As<=Bs,'b_is_subset_of_a':Bs<=As},
 'all_node_unique_coordinate_sets_including_depot_role_ignored':{'intersection_count':len(AF&BF),'union_count':len(AF|BF),'jaccard':len(AF&BF)/len(AF|BF),'a_is_subset_of_b':AF<=BF,'b_is_subset_of_a':BF<=AF}})
result={'schema':'cvrp-descriptive-coordinate-overlap-v1','computed_utc':datetime.now(timezone.utc).isoformat(),'fixed_selection_sha256':before,'does_not_change_selection':True,'no_solver_model_or_algorithm_results_used':True,'metric_definitions':{'customer_multiset':'Exact integer (x,y) equality with customer multiplicity preserved; depot excluded; intersection=sum min counts, union=sum max counts.','customer_unique_coordinate_sets':'Distinct exact customer coordinate locations; computed only for dependence annotation, never merges input customers.','same_depot_coordinate':'Depot is compared independently so depot/customer role is not silently conflated.','containment':'Reports both directional subset/submultiset predicates; not a claim of equal demands, distances induced with depot, or identical optimization problem.','statistics_boundary':'Different full geometry hashes do not imply independent statistical observations; coordinate overlap does not quantify all dependencies. Seeds are repetitions, not new instances.'},'instances':[{'name':x['name'],'group':x['group'],'depot':x['coordinates'][0],'customers':len(x['coordinates'])-1,'unique_customer_coordinate_count':len(set(map(tuple,x['coordinates'][1:])))} for x in data],'pair_count':len(pairs),'pairs':pairs,'resource_use':{'cpu_seconds':time.process_time()-cpu,'local_wall_seconds_excluding_network':time.monotonic()-start,'network_wall_seconds':0.0}}
assert hashlib.sha256(fp.read_bytes()).hexdigest()==before
write(ROOT/'audit/geometry_overlap.json',result)
for p in sorted(pairs,key=lambda x:x['customer_multiset']['jaccard'],reverse=True)[:10]:
 print(p['a'],p['b'],'same_depot',p['same_depot_coordinate'],'multiset',p['customer_multiset'])
