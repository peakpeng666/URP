#!/usr/bin/env python3
"""Offline, stdlib-only data preparation and reference-route verification.

This file is authored for this package, not downloaded. It executes no source
content, performs no search/optimization, and makes no network requests.
"""
import hashlib
import html
import json
import math
import re
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
NAMES = ("A-n32-k5", "B-n31-k5", "P-n40-k5")
INDEX_URL = "https://galgos.inf.puc-rio.br/cvrplib/index.php/en/instances"
TSPLIB_PDF = "https://comopt.ifi.uni-heidelberg.de/software/TSPLIB95/tsp/tsp95.pdf"
TSPLIB_FAQ = "https://comopt.ifi.uni-heidelberg.de/software/TSPLIB95/tsp/TSPFAQ.html"


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def digest(path):
    data = path.read_bytes()
    return {"path": str(path.relative_to(ROOT)), "size_bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest()}


def parse_instance(path):
    text = path.read_bytes().decode("ascii")
    header, sections = {}, {}
    section = None
    eof = False
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        if eof:
            raise ValueError("Unexpected material after EOF")
        if line == "EOF":
            eof = True
        elif line in ("NODE_COORD_SECTION", "DEMAND_SECTION", "DEPOT_SECTION"):
            if line in sections:
                raise ValueError("Duplicate section")
            section = line
            sections[section] = []
        elif section is None:
            match = re.fullmatch(r"([A-Z_]+)\s*:\s*(.*)", line)
            if not match or match[1] in header:
                raise ValueError("Malformed or duplicate header")
            header[match[1]] = match[2]
        else:
            if not re.fullmatch(r"-?\d+(?:\s+-?\d+)*", line):
                raise ValueError("Noninteger data or unrecognized section")
            sections[section].append([int(token) for token in line.split()])
    assert eof
    assert set(header) == {"NAME", "COMMENT", "TYPE", "DIMENSION", "EDGE_WEIGHT_TYPE", "CAPACITY"}
    assert header["TYPE"] == "CVRP" and header["EDGE_WEIGHT_TYPE"] == "EUC_2D"
    n = int(header["DIMENSION"])
    c = sections["NODE_COORD_SECTION"]
    d = sections["DEMAND_SECTION"]
    assert len(c) == len(d) == n
    assert all(len(row) == 3 for row in c) and all(len(row) == 2 for row in d)
    assert [row[0] for row in c] == [row[0] for row in d] == list(range(1, n + 1))
    assert sections["DEPOT_SECTION"] == [[1], [-1]]
    coordinates = [row[1:] for row in c]
    demands = [row[1] for row in d]
    capacity = int(header["CAPACITY"])
    assert capacity > 0 and demands[0] == 0
    assert all(0 < demand <= capacity for demand in demands[1:])
    comment = re.fullmatch(r"\(Augerat et al, No of trucks: (\d+), Optimal value: (\d+)\)", header["COMMENT"])
    assert comment is not None
    return header, coordinates, demands, capacity, int(comment[1]), int(comment[2])


def exact_nint_distance(a, b):
    squared = (a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2
    floor_root = math.isqrt(squared)
    result = floor_root + int(4 * squared >= (2 * floor_root + 1) ** 2)
    # Independent floating-point cross-check of the published nonnegative formula.
    assert result == math.floor(math.sqrt(squared) + 0.5)
    return result


def parse_solution(path):
    routes, cost = [], None
    for line in path.read_bytes().decode("ascii").splitlines():
        line = line.strip()
        if not line:
            continue
        match = re.fullmatch(r"Route #(\d+):\s*(\d+(?:\s+\d+)*)", line)
        if match:
            assert cost is None and int(match[1]) == len(routes) + 1
            routes.append([int(token) for token in match[2].split()])
        else:
            match = re.fullmatch(r"Cost\s+(\d+)", line)
            assert match is not None and cost is None
            cost = int(match[1])
    assert routes and cost is not None
    return routes, cost


def official_row(name, page):
    matches = [row for row in re.findall(r"<tr\b[^>]*>.*?</tr>", page, re.S)
               if re.search(r">\s*" + re.escape(name) + r"\s*</a>", row)]
    assert len(matches) == 1
    row = matches[0]
    cells = re.findall(r"<td\b[^>]*>(.*?)</td>", row, re.S)
    text = [" ".join(html.unescape(re.sub(r"<[^>]+>", " ", cell)).split()) for cell in cells]
    instance_link = re.search(r'href="([^"]+)"\s+title="Instance File"', row)[1]
    solution_link = re.search(r'href="([^"]+)"\s+title="Solution File"', row)[1]
    number = lambda value: float(value.replace("$", "").replace(",", ""))
    return {"instance": name, "customers": int(number(text[1])),
            "reported_K": int(number(text[2])), "capacity": int(number(text[3])),
            "UB": int(number(text[4])), "Opt": text[5],
            "instance_url": "https://galgos.inf.puc-rio.br" + instance_link,
            "solution_url": "https://galgos.inf.puc-rio.br" + solution_link,
            "source_url": INDEX_URL, "source_path": "sources/cvrplib_all_instances.html"}, row


def main():
    downloads = json.loads((ROOT / "audit/downloads.json").read_text())
    downloads += json.loads((ROOT / "audit/downloads_extra.json").read_text())
    source_index = {record["path"]: record for record in downloads}
    assert all("error" not in record for record in downloads)
    for record in downloads:
        actual = digest(ROOT / record["path"])
        assert record["sha256"] == actual["sha256"] and record["size_bytes"] == actual["size_bytes"]

    page = (ROOT / "sources/cvrplib_all_instances.html").read_text()
    records, checks = [], []
    # Test tie convention separately; Python round() is intentionally not used.
    tie_tests = [{"input": x, "nint_nonnegative": math.floor(x + 0.5)}
                 for x in (0.0, 0.49, 0.5, 1.5, 2.5, 3.5)]
    assert [case["nint_nonnegative"] for case in tie_tests] == [0, 0, 1, 2, 3, 4]

    for name in NAMES:
        header, coordinates, demands, capacity, trucks, comment_cost = parse_instance(ROOT / f"raw/{name}.vrp")
        table, row = official_row(name, page)
        n = len(coordinates)
        assert header["NAME"] == name
        assert table["customers"] == n - 1 and table["capacity"] == capacity
        assert table["reported_K"] == trucks and table["UB"] == comment_cost and table["Opt"] == "yes"
        for suffix, key in (("vrp", "instance_url"), ("sol", "solution_url")):
            assert source_index[f"raw/{name}.{suffix}"]["requested_url"] == table[key]
        (ROOT / f"sources/{name}.official_table_row.html").write_text(row + "\n")

        matrix = [[exact_nint_distance(a, b) for b in coordinates] for a in coordinates]
        assert all(matrix[i][i] == 0 for i in range(n))
        assert all(matrix[i][j] == matrix[j][i] for i in range(n) for j in range(n))
        routes, stated_cost = parse_solution(ROOT / f"raw/{name}.sol")
        visited = [v for route in routes for v in route]
        # The official .sol uses 1..n_customers, equal to zero-based normalized indices.
        assert sorted(visited) == list(range(1, n))
        loads = [sum(demands[v] for v in route) for route in routes]
        costs = [sum(matrix[a][b] for a, b in zip([0] + route, route + [0])) for route in routes]
        lower_bound = (sum(demands) + capacity - 1) // capacity
        assert all(load <= capacity for load in loads)
        assert len(routes) == trucks == lower_bound == 5
        assert sum(costs) == stated_cost == table["UB"]
        duplicates = [[i, j] for i in range(n) for j in range(i + 1, n) if coordinates[i] == coordinates[j]]
        triangle_violations = sum(matrix[i][j] > matrix[i][k] + matrix[k][j]
                                  for i in range(n) for j in range(i + 1, n)
                                  for k in range(n))
        continuous_cost = sum(math.hypot(coordinates[a][0] - coordinates[b][0], coordinates[a][1] - coordinates[b][1])
                              for route in routes for a, b in zip([0] + route, route + [0]))

        instance = {"schema": "official-cvrp-fixed-k-instance-v1", "name": name,
                    "dimension": n, "n_customers": n - 1, "depot": 0,
                    "node_ids_original": list(range(1, n + 1)), "coordinates": coordinates,
                    "demands": demands, "capacity": capacity,
                    "edge_weight_type": "EUC_2D", "distance_convention": "TSPLIB95_nint_EUC_2D",
                    "distance_matrix": matrix,
                    "fixed_k": 5, "fixed_k_origin": "explicit local experimental protocol; official table K and COMMENT both report 5",
                    "reference_solutions_excluded_from_instance": True}
        reference = {"schema": "official-cvrp-reference-solution-v1", "name": name,
                     "indexing": "normalized depot=0, customers=1..n; route lists omit depot at both ends",
                     "routes": routes, "route_loads": loads, "route_costs": costs,
                     "total_cost": sum(costs), "number_of_routes": len(routes),
                     "status": "official CVRPLIB table Opt=yes; not independently proven here",
                     "usage": "evaluation/audit only; do not feed routes to construction or algorithm search"}
        write_json(ROOT / f"clean/{name}.instance.json", instance)
        write_json(ROOT / f"clean/{name}.reference_solution.json", reference)

        record = {"name": name, "official_table": table,
                  "raw_instance": source_index[f"raw/{name}.vrp"],
                  "raw_solution": source_index[f"raw/{name}.sol"],
                  "source_version_or_commit": None,
                  "version_note": "Direct CVRPLIB HTTP snapshot; no immutable version/commit exposed. Raw SHA-256 identifies bytes.",
                  "dimension_including_depot": n, "n_customers": n - 1,
                  "capacity": capacity, "demands_original_id_order": demands,
                  "total_demand": sum(demands), "capacity_lower_bound_on_routes": lower_bound,
                  "depot_original_id": 1, "depot_normalized_id": 0,
                  "raw_depot_section": [1, -1], "depot_demand": demands[0],
                  "reported_number_of_trucks": trucks,
                  "vehicle_upper_bound_explicitly_specified": None,
                  "vehicle_upper_bound_note": "Official table says |K|=5 and COMMENT says No of trucks: 5; neither retrieved source explicitly defines an upper-bound relation. Do not infer one from filename. TSPLIB generic CVRP definition leaves fleet size unspecified.",
                  "fixed_k_experimental_protocol": 5,
                  "fixed_k_feasibility_evidence": "capacity lower bound = 5 and independently checked official reference has 5 nonempty routes",
                  "edge_weight_type": header["EDGE_WEIGHT_TYPE"],
                  "distance_convention": "d_ij=floor(sqrt((x_i-x_j)^2+(y_i-y_j)^2)+0.5); round each edge before summing",
                  "distance_authority": {"documentation_url": TSPLIB_PDF, "section": "2.1, printed p.6 (PDF page index 5)", "nint_faq_url": TSPLIB_FAQ},
                  "official_UB": table["UB"], "official_optimality_flag": table["Opt"],
                  "optimality_claim_scope": "CVRPLIB explicitly marks Opt=yes; this package verifies feasibility and objective only, not an optimality proof.",
                  "clean_instance": digest(ROOT / f"clean/{name}.instance.json"),
                  "reference_solution": digest(ROOT / f"clean/{name}.reference_solution.json")}
        records.append(record)
        checks.append({"name": name, "all_passed": True,
                       "raw_hashes_match_download_audit": True,
                       "table_file_name_dimension_capacity_K_UB_agree": True,
                       "customers_covered_exactly_once": True, "all_routes_nonempty": all(routes),
                       "route_count": len(routes), "capacity_lower_bound_on_routes": lower_bound,
                       "route_loads": loads, "route_costs": costs, "sum_route_costs": sum(costs),
                       "raw_solution_cost": stated_cost, "official_table_UB": table["UB"],
                       "raw_comment_optimal_value": comment_cost,
                       "matrix_symmetric_integer_zero_diagonal": True,
                       "integer_exact_and_published_float_formulas_agree_for_every_pair": True,
                       "duplicate_coordinate_pairs_normalized": duplicates,
                       "off_diagonal_zero_distance_pairs": [[i, j] for i in range(n) for j in range(i + 1, n) if matrix[i][j] == 0],
                       "rounded_triangle_inequality_violations_unordered_endpoint_pairs_all_middle_nodes": triangle_violations,
                       "continuous_euclidean_reference_cost_diagnostic_only": continuous_cost,
                       "solution_index_mapping": "sol customer label c maps to vrp original node c+1 and clean index c; validated by full coverage and all costs",
                       "no_solver_or_search_executed": True})

    manifest = {"schema": "official-cvrp-data-package-v1", "package_date_label": "20261008",
                "actual_retrieval_dates_utc": sorted(set(record["retrieved_utc"][:10] for record in downloads)),
                "scope": "three official public CVRP snapshots; offline strict parsing and arithmetic verification only",
                "source_catalog_url": INDEX_URL,
                "official_identity_source": "https://galgos.inf.puc-rio.br/cvrplib/index.php/en/about",
                "raw_files_unchanged": True, "no_downloaded_code_executed": True,
                "no_solver_or_model_run": True, "no_external_upload": True,
                "instances": records,
                "all_downloads": downloads,
                "license": {"terms_url": "https://galgos.inf.puc-rio.br/cvrplib/index.php/en/register/terms",
                            "terms_updated": "December 2025",
                            "research_use": "CVRPLIB terms section 6 states that instances and datasets are provided for research use.",
                            "public_redistribution_rights": "not established; dataset-specific additional terms may apply",
                            "spdx_data_license": None,
                            "code_license_does_not_license_data": True},
                "historical_data_boundary": "This package has direct official-source evidence. It neither authenticates nor replaces the earlier 56-customer Solomon-labelled data whose official identity was not verified.",
                "source_failures": [{"url": "https://dimacs.rutgers.edu/files/6916/3848/0327/CVRP_Competition_Rules.pdf", "status": "404 in web tool", "effect": "not used as authority; no security or access bypass attempted"},
                                    {"url": "https://galgos.inf.puc-rio.br/cvrplib/index.php/en/download/bks/82", "status": "web tool cache miss; normal Python urllib read succeeded HTTP 200", "effect": "raw successful direct read is the provenance record"}]}
    write_json(ROOT / "manifest.json", manifest)
    write_json(ROOT / "audit/validation.json", {"all_passed": True, "nint_tie_tests": tie_tests, "instances": checks})
    write_json(ROOT / "audit/source_table_rows.json", [record["official_table"] for record in records])
    print(json.dumps({"all_passed": True, "instances": checks}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
