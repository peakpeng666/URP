#!/usr/bin/env python3
"""Download official reference bodies only after immutable selection was frozen."""
import hashlib,json,time,urllib.request,resource
from datetime import datetime,timezone
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CPU,(15,15))
ROOT=Path(__file__).resolve().parent
now=lambda:datetime.now(timezone.utc).isoformat()
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
fpath=ROOT/'audit/01_fixed_selection.json';f=json.loads(fpath.read_text());records=[]
start=time.monotonic();cpu=time.process_time();network=0
for x in f['selected']:
 p=ROOT/f"references/{x['name']}.sol"; assert not p.exists()
 r={'path':str(p.relative_to(ROOT)),'requested_url':x['solution_url'],'request_started_utc':now(),'selection_freeze_sha256':hashlib.sha256(fpath.read_bytes()).hexdigest()};t=time.monotonic()
 try:
  with urllib.request.urlopen(urllib.request.Request(x['solution_url'],headers={'User-Agent':'CVRP-research-data-audit/1.0'}),timeout=30) as resp:
   b=resp.read();r.update({'final_url':resp.url,'status':resp.status,'headers':dict(resp.headers)})
  p.write_bytes(b);r.update({'retrieved_utc':now(),'sha256':hashlib.sha256(b).hexdigest(),'size_bytes':len(b)})
 except Exception as e:r['error']=repr(e)
 r['network_wall_seconds']=time.monotonic()-t;network+=r['network_wall_seconds'];records.append(r)
 write(ROOT/'audit/reference_downloads.json',records)
write(ROOT/'audit/reference_download_resources.json',{'cpu_seconds':time.process_time()-cpu,'network_wall_seconds':network,'local_wall_seconds_excluding_network':time.monotonic()-start-network,'selection_freeze_sha256':hashlib.sha256(fpath.read_bytes()).hexdigest(),'all_passed':all('error' not in r for r in records)})
print(json.dumps({'downloaded':len(records),'all_passed':all('error' not in r for r in records)},ensure_ascii=False))
