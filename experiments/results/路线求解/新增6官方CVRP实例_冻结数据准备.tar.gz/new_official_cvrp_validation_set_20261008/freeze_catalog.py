#!/usr/bin/env python3
import hashlib,html,json,re,shutil,time
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parent
OLD=Path('/workspace/shared/official_cvrp_benchmarks_20261008')
started=time.monotonic(); cpu=time.process_time()
now=lambda:datetime.now(timezone.utc).isoformat()
write=lambda p,x:p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
assert not (ROOT/'audit/00_selection_rule_and_candidate_catalog.json').exists()
source=OLD/'sources/cvrplib_all_instances.html'; target=ROOT/'sources/cvrplib_all_instances.html'
shutil.copyfile(source,target); b=target.read_bytes(); page=b.decode()
oldnames=['A-n32-k5','B-n31-k5','P-n40-k5']
rows=[]
for row in re.findall(r'<tr\b[^>]*>.*?</tr>',page,re.S):
 m=re.search(r'>\s*([ABP]-n\d+-k\d+)\s*</a>',row)
 if not m:continue
 c=[' '.join(html.unescape(re.sub('<[^>]+>',' ',v)).split()) for v in re.findall(r'<td\b[^>]*>(.*?)</td>',row,re.S)]
 num=lambda x:int(float(re.sub(r'[$,{}]','',x)))
 customers=num(c[1])
 if not 30<=customers<=50:continue
 name=m[1]; dim=customers+1
 assert int(re.search('-n(\d+)-',name)[1])==dim
 il=re.search(r'href="([^"]+)"\s+title="Instance File"',row)[1]
 sl=re.search(r'href="([^"]+)"\s+title="Solution File"',row)[1]
 (ROOT/f'sources/{name}.official_table_row.html').write_text(row+'\n')
 rows.append({'name':name,'family':name[0],'dimension_official_customer_count_plus_depot':dim,'customers':customers,'reported_K':num(c[2]),'capacity':num(c[3]),'instance_url':'https://galgos.inf.puc-rio.br'+il,'solution_url':'https://galgos.inf.puc-rio.br'+sl,'initial_status':'exclude_old_exploration_instance' if name in oldnames else 'ordered_candidate_requires_geometry_check','official_row_sha256':hashlib.sha256((row+'\n').encode()).hexdigest()})
rows.sort(key=lambda r:(r['family'],r['dimension_official_customer_count_plus_depot'],r['name']))
record={'schema':'cvrp-preselection-freeze-v1','frozen_utc':now(),'selection_rule':{'families_in_processing_order':['A','B','P'],'customers_min_inclusive':30,'customers_max_inclusive':50,'max_selected_each_family':2,'sort_within_family':['official_DIMENSION_ascending','name_lexicographic_ascending'],'metadata_dimension_source':'official table |C|+1 depot; raw DIMENSION must agree before acceptance','excluded_old_names':oldnames,'geometry_equivalence':'same depot coordinate and equal sorted customer-coordinate multiset; preserve multiplicity, ignore node labels, demands, capacity, K','deduplication_scope':'all three old geometries plus all newly selected geometries across families','availability':'official links must return valid parseable .vrp and .sol; failed requests logged, no alternative source; if fewer than 2 in family report shortage','forbidden_selection_factors':['cost','gap','algorithm_performance','neutral_move_experiment_results'],'no_solver_no_model_no_algorithm_selection':True,'later_method_requires_separate_freeze':True},'phase_boundary':'Catalog and immutable rule frozen before new raw downloads. Exact geometry exclusions cannot be established before reading raw coordinates; phase 1 freezes name decisions after coordinate-only screening and before reference download/full validation. No cost or routes used in selection.','source_catalog':{'url':'https://galgos.inf.puc-rio.br/cvrplib/index.php/en/instances','copied_official_snapshot_retrieved_utc':'2026-10-07T23:51:19.311479+00:00','web_reopened_utc':now(),'sha256':hashlib.sha256(b).hexdigest(),'size_bytes':len(b),'note':'Reuses the same official snapshot as existing approved package; fresh web read confirms current catalog. No immutable upstream commit exposed.'},'candidates':rows,'resource_use':{'local_cpu_seconds':time.process_time()-cpu,'local_wall_seconds_excluding_network':time.monotonic()-started}}
p=ROOT/'audit/00_selection_rule_and_candidate_catalog.json';write(p,record)
print(json.dumps({'frozen_utc':record['frozen_utc'],'freeze_file':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'candidates':[(r['name'],r['initial_status']) for r in rows]},ensure_ascii=False,indent=2))
