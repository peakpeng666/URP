#!/usr/bin/env python3
"""Deterministic metadata/geometry-only selection. No solution body is read."""
import hashlib,json,re,resource,time,urllib.request
from datetime import datetime,timezone
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CPU,(15,15))
ROOT=Path(__file__).resolve().parent; OLD=Path('/workspace/shared/official_cvrp_benchmarks_20261008')
start=time.monotonic(); cpu=time.process_time(); network=0.0
now=lambda:datetime.now(timezone.utc).isoformat()
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def geometry(path):
 text=path.read_text(encoding='ascii')
 dimension=int(re.search(r'^DIMENSION\s*:\s*(\d+)\s*$',text,re.M)[1])
 coords_block=text.split('NODE_COORD_SECTION',1)[1].split('DEMAND_SECTION',1)[0]
 rows=[list(map(int,line.split())) for line in coords_block.strip().splitlines()]
 assert len(rows)==dimension and all(len(x)==3 for x in rows)
 assert [x[0] for x in rows]==list(range(1,dimension+1))
 depot=text.split('DEPOT_SECTION',1)[1].split('EOF',1)[0].split()
 assert depot==['1','-1']
 obj={'depot':rows[0][1:],'customers_multiset':sorted(x[1:] for x in rows[1:])}
 return dimension,hashlib.sha256(json.dumps(obj,sort_keys=True,separators=(',',':')).encode()).hexdigest(),obj
freeze=ROOT/'audit/00_selection_rule_and_candidate_catalog.json'; f=json.loads(freeze.read_text())
assert not (ROOT/'audit/01_fixed_selection.json').exists()
seen={}; old=[]
for name in f['selection_rule']['excluded_old_names']:
 p=OLD/f'raw/{name}.vrp'; dim,g,obj=geometry(p);seen[g]=name
 old.append({'name':name,'raw_vrp_sha256':sha(p),'geometry_sha256':g,'dimension':dim,'geometry':obj})
write(ROOT/'audit/old_geometry_evidence.json',old)
selected=[]; decisions=[]; requests=[]
for family in f['selection_rule']['families_in_processing_order']:
 chosen=[]
 for row in [r for r in f['candidates'] if r['family']==family]:
  name=row['name']
  if row['initial_status']=='exclude_old_exploration_instance':
   decisions.append({'name':name,'decision':'excluded','reason':'old_exploration_instance'});continue
  if len(chosen)==2:
   decisions.append({'name':name,'decision':'not_inspected','reason':'family_quota_already_filled_by_earlier_candidates'});continue
  p=ROOT/f'raw/{name}.vrp'; rec={'path':str(p.relative_to(ROOT)),'requested_url':row['instance_url'],'request_started_utc':now(),'method':'GET'}
  t=time.monotonic()
  try:
   with urllib.request.urlopen(urllib.request.Request(row['instance_url'],headers={'User-Agent':'CVRP-research-data-audit/1.0'}),timeout=30) as resp:
    b=resp.read();rec.update({'final_url':resp.url,'status':resp.status,'headers':dict(resp.headers)})
   p.write_bytes(b);rec.update({'retrieved_utc':now(),'sha256':hashlib.sha256(b).hexdigest(),'size_bytes':len(b)})
  except Exception as e:
   rec['error']=repr(e)
  rec['network_wall_seconds']=time.monotonic()-t;network+=rec['network_wall_seconds'];requests.append(rec)
  if 'error' in rec:
   decisions.append({'name':name,'decision':'excluded','reason':'official_vrp_unavailable','details':rec['error']});continue
  try:
   dim,g,obj=geometry(p)
   assert dim==row['dimension_official_customer_count_plus_depot']
  except Exception as e:
   decisions.append({'name':name,'decision':'excluded','reason':'raw_geometry_or_DIMENSION_invalid','details':repr(e)});continue
  if g in seen:
   decisions.append({'name':name,'decision':'excluded','reason':'duplicate_geometry','same_as':seen[g],'geometry_sha256':g,'raw_vrp_sha256':rec['sha256']});continue
  # HEAD establishes link accessibility without opening any reference-solution body.
  head={'requested_url':row['solution_url'],'request_started_utc':now(),'method':'HEAD','solution_body_read':False};t=time.monotonic()
  try:
   with urllib.request.urlopen(urllib.request.Request(row['solution_url'],method='HEAD',headers={'User-Agent':'CVRP-research-data-audit/1.0'}),timeout=30) as resp:
    head.update({'final_url':resp.url,'status':resp.status,'headers':dict(resp.headers),'completed_utc':now()})
  except Exception as e:head['error']=repr(e)
  head['network_wall_seconds']=time.monotonic()-t;network+=head['network_wall_seconds'];requests.append(head)
  if 'error' in head:
   decisions.append({'name':name,'decision':'excluded','reason':'official_solution_link_unavailable','details':head['error']});continue
  item={**row,'dimension_verified_from_raw_DIMENSION':dim,'geometry_sha256':g,'raw_vrp_sha256':rec['sha256'],'raw_vrp_size_bytes':len(b),'solution_link_accessible_HEAD_only':True,'selected_utc':now()}
  selected.append(item);chosen.append(name);seen[g]=name
  decisions.append({'name':name,'decision':'selected','reason':'next_available_distinct_geometry_in_frozen_order','geometry_sha256':g,'raw_vrp_sha256':rec['sha256']})
write(ROOT/'audit/geometry_screening_network.json',requests)
result={'schema':'cvrp-fixed-selection-v1','frozen_utc':now(),'rule_and_catalog_sha256':sha(freeze),'old_geometry_evidence_sha256':sha(ROOT/'audit/old_geometry_evidence.json'),'selected':selected,'decisions':decisions,'shortfall_by_family':{fam:2-sum(x['family']==fam for x in selected) for fam in ['A','B','P']},'new_distinct_geometry_count':len(selected),'old_geometry_count':len(old),'no_solution_body_read_before_selection_freeze':True,'no_solver_model_or_algorithm_run':True,'neutral_result_accessed':False,'known_cost_gap_or_performance_used_in_selection':False,'geometry_hash_convention':'SHA256 UTF-8 json.dumps({depot:[x,y],customers_multiset:sorted([x,y] for each customer preserving repeats)},sort_keys=True,separators=(comma,colon))','resource_use':{'cpu_seconds':time.process_time()-cpu,'network_wall_seconds':network,'local_wall_seconds_excluding_network':time.monotonic()-start-network}}
write(ROOT/'audit/01_fixed_selection.json',result)
print(json.dumps({'frozen_utc':result['frozen_utc'],'selection_sha256':sha(ROOT/'audit/01_fixed_selection.json'),'selected':[{k:x[k] for k in ['name','customers','reported_K','capacity','raw_vrp_sha256','geometry_sha256']} for x in selected],'shortfall_by_family':result['shortfall_by_family'],'resource_use':result['resource_use']},ensure_ascii=False,indent=2))
