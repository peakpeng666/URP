#!/usr/bin/env python3
"""Offline stdlib data parsing and reference-route integer verification only.
No optimization, model, solver, algorithm selection, uploads, or network access.
"""
import hashlib,html,importlib.util,json,math,re,resource,shutil,sys,time
from datetime import datetime,timezone
from pathlib import Path
sys.dont_write_bytecode=True
resource.setrlimit(resource.RLIMIT_CPU,(15,15))
ROOT=Path(__file__).resolve().parent
OLD=Path('/workspace/shared/official_cvrp_benchmarks_20261008')
start=time.monotonic();cpu=time.process_time();now=lambda:datetime.now(timezone.utc).isoformat()
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def digest(p):
 b=p.read_bytes();return {'path':str(p.relative_to(ROOT)),'size_bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def load(path):return json.loads(path.read_text())
def official_metadata(name):
 row=(ROOT/f'sources/{name}.official_table_row.html').read_text()
 cells=[' '.join(html.unescape(re.sub('<[^>]+>',' ',x)).split()) for x in re.findall(r'<td\b[^>]*>(.*?)</td>',row,re.S)]
 number=lambda s:int(float(re.sub(r'[$,{}]','',s)))
 return {'name':cells[0],'customers':number(cells[1]),'reported_K':number(cells[2]),'capacity':number(cells[3]),'UB':number(cells[4]),'Opt':cells[5]}
freeze0=ROOT/'audit/00_selection_rule_and_candidate_catalog.json';freeze1=ROOT/'audit/01_fixed_selection.json'
f=load(freeze1);assert f['rule_and_catalog_sha256']==digest(freeze0)['sha256']
# Reuse exact approved stdlib implementation without changing the prior package.
parser=ROOT/'reused_approved_prepare_data.py';shutil.copyfile(OLD/'prepare_data.py',parser)
spec=importlib.util.spec_from_file_location('approved_data_parser',parser);approved=importlib.util.module_from_spec(spec);spec.loader.exec_module(approved)
source_snapshots=[]
old_downloads=load(OLD/'audit/downloads.json')+load(OLD/'audit/downloads_extra.json')
for name in ['cvrplib_terms.html','cvrplib_about.html','tsplib_home.html','tsplib_faq.html','tsplib95.pdf']:
 shutil.copyfile(OLD/f'sources/{name}',ROOT/f'sources/{name}')
 r=next(r for r in old_downloads if r['path']==f'sources/{name}')
 assert r['sha256']==digest(ROOT/f'sources/{name}')['sha256']
 source_snapshots.append(r)
requests=load(ROOT/'audit/geometry_screening_network.json')
ref_requests=load(ROOT/'audit/reference_downloads.json'); assert all('error' not in r for r in ref_requests)
checks=[];instances=[];seen={x['geometry_sha256'] for x in load(ROOT/'audit/old_geometry_evidence.json')}
for selected in f['selected']:
 name=selected['name'];raw=ROOT/f'raw/{name}.vrp';sol=ROOT/f'references/{name}.sol'
 assert digest(raw)['sha256']==selected['raw_vrp_sha256']
 header,coordinates,demands,Q,K,comment_cost=approved.parse_instance(raw)
 table=official_metadata(name);n=len(coordinates)
 assert header['NAME']==name==table['name'] and n==selected['dimension_verified_from_raw_DIMENSION']
 assert table['customers']==n-1==selected['customers'] and Q==table['capacity']==selected['capacity']
 assert K==table['reported_K']==selected['reported_K']
 geometry={'depot':coordinates[0],'customers_multiset':sorted(coordinates[1:])}
 g=hashlib.sha256(json.dumps(geometry,sort_keys=True,separators=(',',':')).encode()).hexdigest()
 assert g==selected['geometry_sha256'] and g not in seen;seen.add(g)
 matrix=[[approved.exact_nint_distance(a,b) for b in coordinates] for a in coordinates]
 assert all(matrix[i][i]==0 for i in range(n))
 assert all(matrix[i][j]==matrix[j][i] and type(matrix[i][j])==int for i in range(n) for j in range(n))
 routes,cost=approved.parse_solution(sol)
 assert all(routes) and sorted(v for r in routes for v in r)==list(range(1,n))
 loads=[sum(demands[v] for v in route) for route in routes]
 costs=[sum(matrix[a][b] for a,b in zip([0]+route,route+[0])) for route in routes]
 lb=(sum(demands)+Q-1)//Q
 assert all(x<=Q for x in loads) and len(routes)<=K and lb<=len(routes)
 assert sum(costs)==cost==comment_cost==table['UB']
 dup=[[i,j] for i in range(n) for j in range(i+1,n) if coordinates[i]==coordinates[j]]
 triangle=sum(matrix[i][j]>matrix[i][k]+matrix[k][j] for i in range(n) for j in range(i+1,n) for k in range(n))
 inp={'schema':'official-cvrp-k-upper-bound-instance-v1','name':name,'dimension':n,'n_customers':n-1,'depot':0,'node_ids_original':list(range(1,n+1)),'coordinates':coordinates,'demands':demands,'capacity':Q,'edge_weight_type':'EUC_2D','distance_convention':'TSPLIB95_nint_EUC_2D','distance_matrix':matrix,'reported_K':K,'max_vehicles':K,'vehicle_protocol':'at_most_reported_K_nonempty_routes','vehicle_protocol_origin':'explicit local experimental choice; not inferred as official file semantics','reference_cost_and_routes_excluded':True}
 ip=ROOT/f'solver_inputs/{name}.instance.json';write(ip,inp)
 ref={'schema':'official-cvrp-reference-solution-v1','name':name,'indexing':'depot=0; official sol customer c maps to raw vrp node c+1 and normalized index c; routes omit depot at ends','routes':routes,'route_loads':loads,'route_costs':costs,'total_cost':sum(costs),'number_of_routes':len(routes),'official_UB':table['UB'],'official_Opt':table['Opt'],'status':'official catalog reported status only; feasibility and objective checked here, no independent optimality proof','usage':'evaluation/audit only; never use routes or reference cost for initialization, parent prompts, algorithm search, or instance selection'}
 rp=ROOT/f'references/{name}.reference_solution.json';write(rp,ref)
 rr=next(r for r in requests if r.get('path')==f'raw/{name}.vrp');sr=next(r for r in ref_requests if r['path']==f'references/{name}.sol')
 assert digest(sol)['sha256']==sr['sha256']
 check={'name':name,'all_passed':True,'customers_covered_exactly_once':True,'route_count':len(routes),'reported_K':K,'reference_respects_local_K_le_reported_K':True,'capacity_lower_bound_routes':lb,'route_loads':loads,'route_costs':costs,'integer_total_cost':sum(costs),'official_UB':table['UB'],'official_Opt':table['Opt'],'raw_comment_optimal_value':comment_cost,'duplicate_coordinate_pairs_normalized':dup,'zero_length_off_diagonal_pairs':[[i,j] for i in range(n) for j in range(i+1,n) if matrix[i][j]==0],'rounded_triangle_inequality_violations_unordered_endpoint_pairs_all_middle_nodes':triangle,'integer_exact_and_published_float_nint_agree':True,'no_solver_or_search_executed':True}
 checks.append(check)
 instances.append({'name':name,'family':name[0],'dimension':n,'customers':n-1,'reported_K':K,'capacity':Q,'total_demand':sum(demands),'capacity_lower_bound_routes':lb,'local_protocol':{'route_constraint':'K_used <= reported_K','max_vehicles':K,'routes_nonempty':True,'official_upper_bound_relation_explicitly_specified':None,'semantic_boundary':'Official table |K| and COMMENT No of trucks report K, but retrieved raw files do not explicitly define exact-K versus upper-bound semantics; this is a separately declared local protocol. Do not assume all instances use K=5.','exact_K_equivalent_here_by_capacity_lower_bound':lb==K},'raw_instance':rr,'raw_reference_solution':sr,'official_table':table,'official_table_evidence':digest(ROOT/f'sources/{name}.official_table_row.html'),'geometry_sha256':g,'solver_input':digest(ip),'reference_answer':digest(rp),'reference_feasibility_checked':True,'optimality_independently_proved':False})
validation={'schema':'cvrp-reference-validation-v1','all_passed':True,'validated_utc':now(),'instances':checks,'nint_tie_tests':[{'x':x,'result':math.floor(x+0.5)} for x in [0.,0.49,0.5,1.5,2.5,3.5]],'resource_use':{'cpu_seconds':time.process_time()-cpu,'local_wall_seconds_excluding_network':time.monotonic()-start,'network_wall_seconds':0.0}}
write(ROOT/'audit/validation.json',validation)
manifest={'schema':'new-official-cvrp-validation-set-v1','created_utc':now(),'package_date_label':'20261008','source_catalog_url':'https://galgos.inf.puc-rio.br/cvrplib/index.php/en/instances','source_catalog_snapshot':load(freeze0)['source_catalog'],'selection_rule_freeze':digest(freeze0),'fixed_selection_freeze':digest(freeze1),'selection_frozen_utc':f['frozen_utc'],'ordered_candidates_and_exclusions':f['decisions'],'distinct_new_geometry_count':f['new_distinct_geometry_count'],'shortfall_by_family':f['shortfall_by_family'],'old_exploration_instances_excluded':['A-n32-k5','B-n31-k5','P-n40-k5'],'instances':instances,'source_version_or_commit':None,'version_note':'Official HTTP byte snapshots identified by SHA256; no immutable upstream commit exposed.','reused_parser':{'copy':digest(parser),'original_source_path':str(OLD/'prepare_data.py'),'original_source_sha256':hashlib.sha256((OLD/'prepare_data.py').read_bytes()).hexdigest(),'functions_reused':['parse_instance','parse_solution','exact_nint_distance'],'original_files_modified':False,'original_main_executed':False},'reused_authority_source_snapshots':source_snapshots,'distance_definition':'d_ij=floor(sqrt((x_i-x_j)^2+(y_i-y_j)^2)+0.5); round each edge before summing, never Python round or continuous total','distance_authority':{'url':'https://comopt.ifi.uni-heidelberg.de/software/TSPLIB95/tsp/tsp95.pdf','section':'2.1 printed p.6 PDF index 5','nint_faq_url':'https://comopt.ifi.uni-heidelberg.de/software/TSPLIB95/tsp/TSPFAQ.html'},'duplicate_coordinate_policy':'preserve every customer and its demand; geometry dedup compares multisets and does not merge customers','triangle_inequality_assumed':False,'license':{'terms_url':'https://galgos.inf.puc-rio.br/cvrplib/index.php/en/register/terms','terms_updated':'December 2025','research_use':'CVRPLIB Terms section 6 says instances and datasets are provided for research use.','public_redistribution_rights':'not established; dataset-specific additional terms may apply','spdx_data_license':None,'code_license_does_not_license_data':True,'intended_storage':'private research package only; parent review required before authorized private Drive upload'},'information_firewall':{'solver_inputs_directory':'solver_inputs/','reference_answers_directory':'references/','raw_vrp_contains_reference_cost_in_COMMENT':True,'raw_and_source_files_for_audit_only':'Never expose raw .vrp, official rows, manifest or references to algorithm/model prompts; solver consumes only solver_inputs/*.instance.json.','selected_without_reference_routes_cost_gap_or_neutral_results':True,'algorithm_selection_or_execution_performed':False,'later_fixed_method_needs_new_preregistration':True},'no_software_installed':True,'no_downloaded_code_executed':True,'no_solver_or_model_run':True,'no_external_upload':True}
write(ROOT/'manifest.json',manifest)
print(json.dumps({'all_passed':True,'selection_frozen_utc':f['frozen_utc'],'new_distinct_geometries':len(instances),'instances':[{'name':x['name'],'reported_K':x['reported_K'],'Q':x['capacity'],'reference_UB':x['official_table']['UB']} for x in instances],'validation_resource_use':validation['resource_use'],'manifest_sha256':digest(ROOT/'manifest.json')['sha256']},ensure_ascii=False,indent=2))
