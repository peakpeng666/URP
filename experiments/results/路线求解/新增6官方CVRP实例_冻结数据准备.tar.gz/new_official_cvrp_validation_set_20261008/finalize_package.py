#!/usr/bin/env python3
"""Finalize the descriptive data package, without changing either freeze file."""
import hashlib,json,time
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parent
start=time.monotonic();cpu=time.process_time()
def load(p):return json.loads(p.read_text())
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def digest(p):
 b=p.read_bytes();return {'path':str(p.relative_to(ROOT)),'size_bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
f0=ROOT/'audit/00_selection_rule_and_candidate_catalog.json';f1=ROOT/'audit/01_fixed_selection.json'
h0=digest(f0)['sha256'];h1=digest(f1)['sha256'];a=load(f0);b=load(f1);v=load(ROOT/'audit/validation.json');o=load(ROOT/'audit/geometry_overlap.json');m=load(ROOT/'manifest.json')
resources={'catalog_freeze':a['resource_use'],'geometry_screening':b['resource_use'],'reference_downloads':load(ROOT/'audit/reference_download_resources.json'),'offline_validation':v['resource_use'],'descriptive_overlap':o['resource_use']}
cpu_total=sum(r.get('cpu_seconds',r.get('local_cpu_seconds',0)) for r in resources.values())
wall_total=sum(r.get('local_wall_seconds_excluding_network',0) for r in resources.values())
network_total=sum(r.get('network_wall_seconds',0) for r in resources.values())
res={'schema':'cvrp-data-preparation-resource-accounting-v1','measured_stages':resources,'measured_cpu_seconds':cpu_total,'measured_local_wall_seconds_excluding_network':wall_total,'network_wall_seconds_separate':network_total,'resource_limits':{'new_local_CPU_budget_seconds':15,'local_processing_wall_budget_seconds_excluding_network':30,'network_wait_accounted_separately':True},'budget_met':cpu_total<15 and wall_total<30,'scope_note':'Recorded executable preparation stages; small read-only shell inspection and final serialization/archive overhead are not part of solver computation. No solver was run.'}
write(ROOT/'audit/resource_accounting.json',res)
m['coordinate_overlap_audit']=digest(ROOT/'audit/geometry_overlap.json')
m['statistical_dependence_boundary']={'different_official_instance_count':6,'different_complete_depot_plus_customer_multiset_count':6,'statistical_independence_not_claimed':True,'important_overlap':{'old':'P-n40-k5','new':'P-n45-k5','same_depot':True,'shared_customer_coordinate_multiset_count':39,'old_customer_count':39,'new_customer_count':44,'old_is_customer_submultiset_of_new':True,'shared_fraction_of_new':39/44},'selection_unchanged_after_descriptive_audit':True,'reporting_rule':'Do not count repeated seeds or correlated geometries as independent samples; low coordinate overlap alone is not proof of independence.'}
m['resource_accounting']=digest(ROOT/'audit/resource_accounting.json')
m['source_visibility_boundary']='Official catalog includes UB/Opt metadata and raw .vrp COMMENT includes reference values. Those fields were not used as selection factors; this is rule-frozen selection, not a claim that the preparer never saw public costs.'
m['finalized_utc']=datetime.now(timezone.utc).isoformat()
write(ROOT/'manifest.json',m)
rows=[]
for x in m['instances']:
 rows.append(f"| {x['name']} | {x['customers']} | {x['reported_K']} | {x['capacity']} | {x['total_demand']} | {x['official_table']['UB']} | {x['official_table']['Opt']} |")
readme=f'''# 新增官方 CVRP 验证实例：冻结清单

本包仅做数据准备：新增 **6 个不同官方实例、6 种不同完整“仓库+客户坐标多重集”**，A/B/P 各 2 个。没有运行 solver、模型或算法选择，没有安装软件或上传。原有 3 个探索实例和原有源码只读。

## 固定名单

| 实例 | 客户数 | 官网 reportedK | Q | 总需求 | 官方参考值 | 官方 Opt |
|---|---:|---:|---:|---:|---:|---|
{chr(10).join(rows)}

官网来源：[CVRPLIB All Instances](https://galgos.inf.puc-rio.br/cvrplib/index.php/en/instances)。原始 `.vrp` / `.sol` URL、HTTP 元数据、抓取时间、字节数和 SHA256 均在 `manifest.json`。

## 选择顺序与时间证据

1. 规则及全部候选顺序于 **{a['frozen_utc']}** 冻结，SHA256：`{h0}`。
2. 按官方 DIMENSION（表格客户数+1，原文件逐份核对）升序、名字字典序；仅取 30–50 客户；排除 A-n32-k5/B-n31-k5/P-n40-k5；再排除与旧/已选实例“同仓库且同客户坐标多重集”的候选。跨系列也执行精确去重。
3. 几何去重需要原始坐标，所以冻结规则后先仅下载实例做坐标筛查，再于 **{b['frozen_utc']}** 冻结确定名单及逐候选原因，SHA256：`{h1}`。此时未下载或读取新参考解正文，仅 HEAD 确认官方解链接可访问。随后才下载并完整验证参考解。
4. 排除旧 3 例后，各系列前 2 个候选均不同完整几何，直接入选；后续候选因已满额未读取坐标，不能冒称它们是重复几何。P 的同 DIMENSION 字典序为 k10、k7、k8，因此选 P-n50-k10。没有缺项。
5. 官网公开表格和原始 COMMENT 包含参考值；规则不使用成本、gap 或算法表现筛选，不声称准备者从未看过公开成本。未读取 neutral 实验输出。后续方法、搜索预算和评价方案仍须另行冻结。

## 重要相关性边界

**不同完整几何不等于统计独立。** 旧 P-n40-k5 的 39 个客户坐标（保留重数）全部包含于新 P-n45-k5 的 44 个客户坐标中，仓库也相同：旧侧重合 100%，新侧 88.64%，多重集 Jaccard 88.64%。P-n45-k5 是明显的增点近亲；按先定规则保留，不能事后按实验效果换掉，也不能描述为与旧 P 独立的全新几何样本。

旧 3 + 新 6 共 9 例的 36 对比较在 `audit/geometry_overlap.json`，同时给出客户坐标集合、多重集、双向包含关系、各侧重合比例、Jaccard 和仓库是否相同。其余任意一对客户坐标多重集交集至多 1 个；这仍不证明统计独立。后续不能把 seed 重复或相关几何当作独立样本。

## 使用协议与验证

- 本地协议明确为 **使用的非空路线数 ≤ reportedK**，分别为 5/6/5/5/5/10，绝非统一 K5。官网表格和原 COMMENT 报告 K，但未明确“恰好”或“至多”的原始语义，所以该上限是本地实验约定。本 6 例容量下界恰好等于各自 reportedK，官方参考解也各用该条数，仅对这些实例可由容量推出恰好用满。
- 复用已审 stdlib 解析和 TSPLIB EUC_2D nint：每条边先计算 floor(sqrt(dx²+dy²)+0.5)，再求和；用整数 isqrt 阈值法并逐对浮点公式交叉检查。不要用 Python round、连续欧氏总长或最后统一取整。
- 六份解全部通过覆盖、非空路线、容量、回仓整数成本和本地车数上限验证，结果与 `.sol`、`.vrp` COMMENT 和官网 UB 一致。Opt=yes 仅照录官网，未独立证明最优。
- 同坐标客户完整保留。B-n34-k5 在归一化索引 7/21、10/23 处同坐标，B-n35-k5 在 17/29 处同坐标；绝不可合并。六例均有取整后的三角不等式违反，算法只应使用显式矩阵。

## 文件隔离、资源与许可

- `solver_inputs/`：6 个纯实例 JSON，仅含坐标、需求、容量、reportedK/本地上限及整数矩阵，排除了参考值和参考路线。
- `references/`：官方 `.sol` 原字节及归一化参考解，限评价和审计。`raw/` 的 `.vrp` COMMENT、`sources/`、`manifest.json` 也含参考信息，均不得进入构造器或模型父代提示词。
- `audit/`：两阶段冻结证据、下载记录、验证、几何相关性和资源记录；`FILE_INVENTORY.json` 为逐文件校验清单。
- `validate_package.py` 为离线验证入口；`reused_approved_prepare_data.py` 是旧已审源码的原字节副本，仅复用其中三个函数，未运行它的旧 main；不要直接执行该副本。若重建主 manifest，最后执行 `describe_geometry_overlap.py` 和 `finalize_package.py` 恢复相关性标注。冻结脚本拒绝覆盖已有冻结文件。
- 已测准备阶段 CPU **{cpu_total:.4f} 秒**，本地处理 wall **{wall_total:.4f} 秒**；网络等待另列 **{network_total:.3f} 秒**。小于 CPU 15 秒/本地 wall 30 秒限额，无求解预算支出。
- [CVRPLIB Terms](https://galgos.inf.puc-rio.br/cvrplib/index.php/en/register/terms) 第 6 节允许研究使用；公开再分发授权未确认，可能另受具体数据条款约束。无明确 SPDX 数据许可；代码许可不替代数据许可。本包仅供科研私有保存，待父任务审查后按已有授权存入私有 Drive，不公开发布。
'''
(ROOT/'README.zh.md').write_text(readme)
assert digest(f0)['sha256']==h0 and digest(f1)['sha256']==h1
inventory={'schema':'cvrp-file-inventory-v1','created_utc':datetime.now(timezone.utc).isoformat(),'self_excluded':True,'files':[digest(p) for p in sorted(ROOT.rglob('*')) if p.is_file() and p.name!='FILE_INVENTORY.json']}
write(ROOT/'FILE_INVENTORY.json',inventory)
print(json.dumps({'manifest':digest(ROOT/'manifest.json'),'inventory':digest(ROOT/'FILE_INVENTORY.json'),'fixed_selection':digest(f1),'resource_accounting':res,'file_count':len(inventory['files'])},ensure_ascii=False,indent=2))
