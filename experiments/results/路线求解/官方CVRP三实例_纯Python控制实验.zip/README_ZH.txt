官方CVRP固定K整数目标控制实验
先读 reports/REPORT_ZH.txt，再看 reports/PER_INSTANCE_METHOD.csv。
完整48 checkpoint路线见 reports/CHECKPOINT_RESULTS.json；24逐步轨迹见raw/heuristics.jsonl。
只有3个benchmark实例。4 seed重复和双检查点不是额外独立样本。
输入五字段、目标矩阵分别在input；官方原.vrp在provenance，原.sol与解析路线只在reference。
官方来源、K语义与Opt归属的证据完整保留在provenance。
freeze/PROTOCOL与PRE_TOY/PRE_RUN固定算法、seed、预算、输入与源码；provenance/INTEGER_ADAPTER_DIFF.patch是全部core适配。
raw/READ_AUDIT为实际主进程文件读取审计；raw/HEURISTICS_FINISHED先封存，随后才有报告评分。
独立审计不由本worker冒充；reports中的通过仅为任务玩具/自检。
无API调用、模型调用、安装、购买、上传或n39指数oracle。主进程CPU/wall硬限90/150秒。
MANIFEST与SHA256SUMS覆盖封存内容；ZIP外的archive.sha256校验ZIP。
packaging过程本身的supervisor receipt/stdout/stderr在ZIP外，以免自引用hash。
