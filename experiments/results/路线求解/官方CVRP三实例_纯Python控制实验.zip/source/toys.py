"""Predetermined local fixtures; no benchmark optimization or reference reads."""
import copy,math,random
import official_solver as s
from integer_distance import edge,matrix_for
from integer_audit import check

def toy(name,xy,d,Q,K):
    return dict(instance_id=name,coordinates=xy,demands=d,capacity=Q,K=K)

def run():
    tests=[];records=[]
    cfg=dict(delta_limit=2000,iterations=16,per_trajectory_cpu_seconds=3.,per_trajectory_wall_seconds=10.)
    # Integer rounding creates a triangle violation, an insertion cost -1, and zero edges.
    raw=toy('NONMETRIC_DUPLICATES',[[0,0],[1,1],[2,2],[1,1]],[0,1,1,1],4,5)
    inst=s.instance_for(raw);budget=s.Budget(1000,3,10);m=matrix_for(inst,budget)
    assert m[0][2]==3 and m[0][1]+m[1][2]==2 and m[1][3]==0
    options=s.route_options(1,[[2]],[1],inst,m,budget)
    assert options[0][0]==-1
    n=len(m);checked_deltas=0
    for a in range(n):
      for b in range(n):
       for node in range(n):
        delta=m[a][node]+m[node][b]-m[a][b]
        before=edge(raw['coordinates'][a],raw['coordinates'][b])
        after=edge(raw['coordinates'][a],raw['coordinates'][node])+edge(raw['coordinates'][node],raw['coordinates'][b])
        assert delta==after-before;checked_deltas+=1
    tests.append('integer_rounding_negative_insertion_zero_edge_all_64_deltas')
    for method in ['cheapest','regret2']:
      r=s.run_one(raw,method,1901,cfg)
      assert r['status']=='LEGAL_COMPLETION' and check(raw,r['output'],5)['accepted']
      assert sorted(j for route in r['output']['routes'] for j in route[1:-1])==[1,2,3]
      tests.append('duplicate_coordinates_remain_distinct_'+method);records.append(r)
    # K=5 must accept five necessary singleton routes, reject K=4.
    f=toy('FIVE_VEHICLES',[[0,0],[1,0],[2,0],[3,0],[4,0],[5,0]],[0,10,10,10,10,10],10,5)
    r=s.run_one(f,'regret2',1902,{**cfg,'iterations':0})
    assert r['status']=='LEGAL_COMPLETION' and len(r['output']['routes'])==5
    assert 'vehicle_upper_bound_exceeded' in check(f,r['output'],4)['errors']
    tests.append('generic_K5_not_hidden_K3');records.append(r)
    f=toy('DFS_RESCUE',[[0,0]]*10,[0,4,4,4,3,3,3,2,2,2],9,3)
    r=s.run_one(f,'cheapest',1903,{**cfg,'iterations':0})
    cp=r['initialization']['capacity_partition']
    assert r['status']=='LEGAL_COMPLETION' and cp['nodes']<=256 and cp['outcome']=='FOUND'
    assert r['deltas']==54 and cp['route_insertion_deltas']==18
    tests.append('DFS256_demand_only_rescue_and_charged_insertion');records.append(r)
    bins,cp=s.bounded_partition(f['demands'],9,3,1)
    assert bins is None and cp['nodes']==1 and cp['limit_reached'] and not cp['mathematical_infeasibility_claim']
    tests.append('DFS_limit_no_infeasibility_claim')
    r=s.run_one(f,'cheapest',1903,{**cfg,'iterations':0,'delta_limit':40})
    assert r['output'] is None and r['deltas']==40 and r['stop_reason']=='delta_budget'
    tests.append('DFS_insertion_cutoff_no_partial_route');records.append(r)
    f=toy('TRUE_CAPACITY_IMPOSSIBLE',[[0,0]]*5,[0,5,5,5,5],9,3)
    r=s.run_one(f,'regret2',1904,{**cfg,'iterations':0})
    assert r['status']=='CONSTRUCTION_FAIL' and r['output'] is None
    tests.append('construction_failure_not_false_feasible');records.append(r)
    # Deliberately truncate a repair after one actual delta: incumbent cannot mutate.
    f=toy('ATOMIC_REPAIR',[[0,0],[1,1],[2,2],[1,1]],[0,1,1,1],4,5)
    inst=s.instance_for(f);b=s.Budget(100,3,10);m=matrix_for(inst,b);partial=[[2]];snap=copy.deepcopy(partial)
    out=s.evaluate_candidate(f,partial,[1,3],'cheapest',inst,m,s.Budget(1,3,10))
    assert out['status']=='budget_discarded' and out['candidate'] is None and partial==snap
    tests.append('atomic_partial_repair_discard');records.append(out)
    # Independent checker adversarial cases.
    good={'routes':[[0,1,3,2,0]],'reported_cost':5}
    assert check(f,good,5)['accepted']
    for label,o,k,expect in [
      ('duplicate',{'routes':[[0,1,1,2,0]],'reported_cost':5},5,'duplicate_customers'),
      ('missing',{'routes':[[0,1,2,0]],'reported_cost':5},5,'missing_customers'),
      ('wrong_cost',dict(good,reported_cost=6),5,'reported_cost_mismatch'),
      ('empty',{'routes':[[0,0]],'reported_cost':0},5,'invalid_route_shape_or_id'),
      ('unknown',{'routes':[[0,99,0]],'reported_cost':0},5,'invalid_route_shape_or_id')]:
        assert expect in check(f,o,k)['errors'];tests.append('checker_'+label)
    return {'passed':True,'tests':tests,'records':records,'official_solver_calls':0,'reference_file_reads':0,'oracle_calls':0}
