"""Create one checksummed immutable archive; never overwrite a package."""
import json,os,zipfile
from common import ROOT,dump,read,sha,utc,verify
verify()
summary=read(ROOT/'reports/SUMMARY.json')
assert read(ROOT/'receipts/main.json')['complete'] and read(ROOT/'receipts/audit.json')['complete']
readme='''官方CVRP固定K整数目标控制实验
先读 reports/REPORT_ZH.txt，再看 reports/PER_INSTANCE_METHOD.csv。
完整48 checkpoint路线见 reports/CHECKPOINT_RESULTS.json；24逐步轨迹见raw/heuristics.jsonl。
只有3个benchmark实例。4 seed重复和双检查点不是额外独立样本。
输入五字段、目标矩阵分别在input；官方原.vrp在provenance，原.sol与解析路线只在reference。
官方来源、K语义与Opt归属的证据完整保留在provenance。
freeze/PROTOCOL与PRE_TOY/PRE_RUN固定算法、seed、预算、输入与源码；provenance/INTEGER_ADAPTER_DIFF.patch是全部core适配。
raw/READ_AUDIT为实际主进程文件读取审计；raw/HEURISTICS_FINISHED先封存，随后才有报告评分。
独立审计不由本worker冒充；reports中的通过仅为任务玩具/自检。
无API调用、模型调用、安装、购买、上传或n39指数oracle。主进程CPU/wall硬限90/150秒。
MANIFEST与SHA256SUMS覆盖封存内容；ZIP外的archive.sha256校验ZIP。
packaging过程本身的supervisor receipt/stdout/stderr在ZIP外，以免自引用hash。
'''
(ROOT/'README_ZH.txt').write_text(readme)
excluded={'MANIFEST.json','SHA256SUMS.txt','archive.sha256','official_cvrp_controls_20261008.zip','receipts/package.json','receipts/package.stdout.log','receipts/package.stderr.log'}
files=sorted(p for p in ROOT.rglob('*') if p.is_file() and str(p.relative_to(ROOT)) not in excluded)
manifest={'created_utc':utc(),'files':[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files],
 'scope':'Immutable task deliverable; package supervision receipt is external to prevent self-hash recursion.'}
dump(ROOT/'MANIFEST.json',manifest)
files.append(ROOT/'MANIFEST.json')
(ROOT/'SHA256SUMS.txt').write_text(''.join(f"{sha(p)}  {p.relative_to(ROOT)}\n" for p in files))
files.append(ROOT/'SHA256SUMS.txt')
archive=ROOT/'official_cvrp_controls_20261008.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in files:z.write(p,str(p.relative_to(ROOT)))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
(ROOT/'archive.sha256').write_text(f'{sha(archive)}  {archive.name}\n')
for p in files+[archive,ROOT/'archive.sha256']:p.chmod(0o444)
print(json.dumps({'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'manifest_files':len(manifest['files']),'readonly':True}))
