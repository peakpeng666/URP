"""Input and objective audit, fixed plan and toys. Never benchmark optimization."""
import difflib,itertools,json,math,shutil,sys,time
from pathlib import Path
from common import ROOT,dump,read,sha,utc
from integer_distance import edge
from integer_audit import check
DATA=Path('/workspace/shared/official_cvrp_benchmarks_20261008')
OLD=Path('/workspace/shared/capacity_partition_fallback_20261008')
NAMES=['A-n32-k5','B-n31-k5','P-n40-k5']
protocol={'title':'Official CVRP fixed-K integer-objective controls v1','created_utc':utc(),
 'instances':NAMES,'K_upper_bound':5,'capacities':[100,100,140],
 'methods':['cheapest','regret2'],'search_seeds':[202610084101,202610084103,202610084107,202610084109],
 'schedule_seed':202610084199,'planned_trajectories':24,'checkpoints':[40000,160000],'planned_checkpoint_rows':48,
 'delta_limit':160000,'iterations':1000000000,'per_trajectory_cpu_seconds':3.,'per_trajectory_wall_seconds':10.,
 'main_cpu_soft_seconds':89,'main_cpu_hard_seconds':90,'main_wall_seconds':150,
 'initialization':'Same charged savings then FFD; only if both miss K, unchanged deterministic demand-only capacity DFS capped at256 entered states and charged fixed-group insertion.',
 'objective':'sum of edge-wise TSPLIB95 EUC_2D nint integer costs. No metric assumptions; co-located customer IDs remain distinct.',
 'search':'Unchanged random removal q uniform integers ceil10%-ceil30%, cheapest or regret2 insertion, strict improving acceptance; identical inherited delta accounting and random hash derivation.',
 'checkpoint_semantics':'One160k trajectory, inspect last fully committed incumbent at or before each cut. Atomic candidate crossing40k excluded; no restart. Incomplete final search preserves last legal incumbent. Checkpoint reach flag is separate from legal output.',
 'solver_interface':['instance_id','coordinates','demands','capacity','K'],
 'anti_leakage':'Official routes/objective verified offline first; not passed to solver. Main process filesystem audit blocks reference, provenance and outside shared reads. All heuristic records flush/fsync/hash-sealed before scoring reads reference solutions. No early stopping by reference cost.',
 'primary':'Per instance and method at40k/160k: planned4 seeds, legal outputs, reached cuts, INIT_FAIL/CONSTRUCTION_FAIL and failure counts; mean/min/worst cost, gaps to official stated reference, reference hit count.',
 'aggregation':'Three named instances are three benchmark units. Seeds repeat search and checkpoints repeat measurement; neither creates independent instances. Descriptive results only, no significance or SOTA claim.',
 'reference_scope':'Official Opt=yes is attributed to CVRPLIB; no independent optimality proof. K<=5 is explicit local protocol, not an inferred official upper-bound relation.',
 'failure_policy':'Exactly one main launch, no screening/reruns/replacements/tuning. Preserve missing planned rows and any below-reference anomaly; do not claim breakthrough.',
 'resources':'Main child <=90 CPU seconds and150 wall seconds; stage receipts use wait4 user+system CPU. Report extra bounded DFS nodes and separate matrix/objective operations. Standard library only.',
 'external_api_calls':0,'model_calls':0,'dependency_installs':0,'uploads':0,'oracle_calls':0,
 'toy_plan':['rounding and negative insertion in nonmetric triangle','co-located IDs and zero edges','generic K5','DFS256 rescue and insertion charge','one-node cutoff no infeasibility claim','atomic insertion/repair truncation','checker adversarial failures','checkpoint matches separately truncated toy trajectory','source/allowlist no reference contract'],
 'seed_novelty_scope':'New compared with fixed_fleet_cvrp_20261008 and capacity_partition_fallback_20261008 protocol seeds; no universal seed novelty assertion.'}
for prior in [OLD,Path('/workspace/shared/fixed_fleet_cvrp_20261008')]:
 assert not set(protocol['search_seeds'])&set(read(prior/'freeze/PROTOCOL.json')['search_seeds'])
dump(ROOT/'freeze/PROTOCOL.json',protocol)
shutil.copy2(DATA/'manifest.json',ROOT/'provenance/OFFICIAL_DATA_MANIFEST.json')
shutil.copy2(DATA/'README.zh.md',ROOT/'provenance/OFFICIAL_DATA_README.zh.md')
shutil.copy2(DATA/'FILE_INVENTORY.json',ROOT/'provenance/OFFICIAL_DATA_FILE_INVENTORY.json')
shutil.copytree(DATA/'sources',ROOT/'provenance/official_sources')
shutil.copytree(DATA/'audit',ROOT/'provenance/official_data_audit')
source_prov=[]
for rel in ['capacity_solver.py','fixed_solver.py','legacy/experiment.py']:
 target=ROOT/('provenance/'+rel if not rel.startswith('legacy/') else 'source/'+rel)
 assert sha(OLD/'source'/rel)==sha(target)
 source_prov.append({'path':str(target.relative_to(ROOT)),'origin':str(OLD/'source'/rel),'sha256':sha(target),'byte_identical':True})
for p in (ROOT/'source/legacy').rglob('*.py'):
 assert sha(p)==sha(OLD/'source'/p.relative_to(ROOT/'source'))
 source_prov.append({'path':str(p.relative_to(ROOT)),'origin':str(OLD/'source'/p.relative_to(ROOT/'source')),'sha256':sha(p),'byte_identical':True})
dump(ROOT/'freeze/SOURCE_PROVENANCE.json',source_prov)
inputs=[];audits=[]
for name in NAMES:
 clean=read(DATA/'clean'/f'{name}.instance.json')
 raw={k:clean[k] for k in ['coordinates','demands','capacity']};raw.update(instance_id=name,K=5)
 assert clean['node_ids_original']==list(range(1,clean['dimension']+1))
 assert clean['fixed_k']==5 and clean['edge_weight_type']=='EUC_2D'
 dump(ROOT/'input'/f'{name}.json',raw)
 shutil.copy2(DATA/'raw'/f'{name}.vrp',ROOT/'provenance'/f'{name}.vrp')
 shutil.copy2(DATA/'raw'/f'{name}.sol',ROOT/'reference'/f'{name}.sol')
 shutil.copy2(DATA/'clean'/f'{name}.reference_solution.json',ROOT/'reference'/f'{name}.reference_solution.json')
 # Independently parse VRP coordinate/demand IDs and depot instead of trusting JSON mapping.
 text=(ROOT/'provenance'/f'{name}.vrp').read_text();lines=text.splitlines();sections={};section=None
 for line in lines:
  if line.strip() in ['NODE_COORD_SECTION','DEMAND_SECTION','DEPOT_SECTION']:
   section=line.strip();sections[section]=[]
  elif section and line.strip()!='EOF':sections[section].append(line.split())
 xy={int(z[0]):list(map(int,z[1:])) for z in sections['NODE_COORD_SECTION']}
 demand={int(z[0]):int(z[1]) for z in sections['DEMAND_SECTION']}
 assert raw['coordinates']==[xy[k] for k in range(1,len(xy)+1)]
 assert raw['demands']==[demand[k] for k in range(1,len(xy)+1)]
 assert sections['DEPOT_SECTION']==[['1'],['-1']]
 matrix=[[edge(a,b) for b in raw['coordinates']] for a in raw['coordinates']]
 assert matrix==clean['distance_matrix']
 for a,b in itertools.product(range(len(matrix)),repeat=2):
  x,y=raw['coordinates'][a],raw['coordinates'][b]
  assert matrix[a][b]==math.floor(math.sqrt((x[0]-y[0])**2+(x[1]-y[1])**2)+.5)
 dump(ROOT/'input'/f'{name}.matrix.json',matrix)
 routes=[];claimed=None
 for line in (ROOT/'reference'/f'{name}.sol').read_text().splitlines():
  if line.startswith('Route #'):routes.append(list(map(int,line.split(':',1)[1].split())))
  elif line.startswith('Cost'):claimed=int(line.split()[1])
 reference=read(ROOT/'reference'/f'{name}.reference_solution.json')
 assert routes==reference['routes'] and claimed==reference['total_cost']
 checked=check(raw,{'routes':[[0,*r,0] for r in routes],'reported_cost':claimed},5)
 assert checked['accepted']
 zeros=[];duplicates=[];violations=[]
 for a in range(len(matrix)):
  for b in range(a+1,len(matrix)):
   if matrix[a][b]==0:zeros.append([a,b])
   if raw['coordinates'][a]==raw['coordinates'][b]:duplicates.append([a,b])
   for c in range(len(matrix)):
    if matrix[a][b]>matrix[a][c]+matrix[c][b]:violations.append([a,c,b])
 # All insertion/reversal-removal formulas are algebraic even for negative values.
 delta_count=0;negative_count=0
 for a,b,c in itertools.product(range(len(matrix)),repeat=3):
  delta=matrix[a][c]+matrix[c][b]-matrix[a][b]
  lhs=sum([matrix[a][c],matrix[c][b]])-sum([matrix[a][b]])
  assert delta==lhs
  delta_count+=1;negative_count+=delta<0
 audits.append({'instance':name,'raw_id_mapping_verified':True,'solution_ids':'sol c -> original vrp c+1 -> normalized c',
  'reference_check':checked,'reference_cost':claimed,'duplicate_coordinate_pairs':duplicates,'off_diagonal_zero_pairs':zeros,
  'triangle_violation_count_unordered_endpoints':len(violations),'triangle_example':violations[:1],
  'all_ordered_insertion_deltas_checked':delta_count,'negative_insertion_deltas':negative_count,'matrix_matches_official_clean':True})
 inputs.append({'instance_id':name,'input_file':f'input/{name}.json','sha256':sha(ROOT/'input'/f'{name}.json'),
  'matrix_file':f'input/{name}.matrix.json','matrix_sha256':sha(ROOT/'input'/f'{name}.matrix.json'),
  'original_vrp_sha256':sha(ROOT/'provenance'/f'{name}.vrp'),'n_customers':len(raw['demands'])-1,'K':5,'capacity':raw['capacity']})
dump(ROOT/'reports/PREFLIGHT_OFFICIAL_AUDIT.json',{'passed':True,'created_utc':utc(),'solver_calls':0,'instances':audits})
dump(ROOT/'freeze/INPUT_MANIFEST.json',inputs)
import random
schedule=[{'instance_id':n,'method':m,'search_seed':s} for n in NAMES for m in protocol['methods'] for s in protocol['search_seeds']]
random.Random(protocol['schedule_seed']).shuffle(schedule)
dump(ROOT/'freeze/SCHEDULE.json',schedule)
# Freeze every executable and input before any toy; production keys untouched by test limits.
paths=sorted([p for p in (ROOT/'source').rglob('*') if p.is_file()]+list((ROOT/'input').glob('*'))+list((ROOT/'freeze').glob('*')))
dump(ROOT/'freeze/PRE_TOY_FREEZE.json',{'utc':utc(),'sha256':{str(p.relative_to(ROOT)):sha(p) for p in paths}})
from toys import run
report=run()
from checkpoints import at
import official_solver as solver
raw={'instance_id':'CHECKPOINT_TOY','coordinates':[[0,0],[1,1],[2,2],[1,1]],'demands':[0,1,1,1],'capacity':4,'K':5}
cfg={k:protocol[k] for k in ['iterations','per_trajectory_cpu_seconds','per_trajectory_wall_seconds']}
for method in protocol['methods']:
 full=solver.run_one(raw,method,1941,{**cfg,'delta_limit':130})
 prefix=solver.run_one(raw,method,1941,{**cfg,'delta_limit':70})
 assert at(full,70)['output']==prefix['output']
 report['tests'].append('atomic_checkpoint_prefix_equivalence_'+method)
# Check the only core changes are the two objective dependency imports.
old=(ROOT/'provenance/capacity_solver.py').read_text();new=(ROOT/'source/official_solver.py').read_text()
assert new==old.replace('from experiment import Budget, StopBudget, matrix_for, cost_of, savings, derived_seed, destroy, output_for','from experiment import Budget, StopBudget, cost_of, savings, derived_seed, destroy, output_for\nfrom integer_distance import matrix_for').replace('from audit import check','from integer_audit import check')
report['tests'].append('only_integer_objective_import_adapter_no_search_change')
report['scope']='Task-specific tests passed; independent whole-package audit remains external.'
dump(ROOT/'reports/TOY_VALIDATION.json',report)
freeze=read(ROOT/'freeze/PRE_TOY_FREEZE.json')
assert all(sha(ROOT/p)==h for p,h in freeze['sha256'].items())
paths+= [ROOT/'freeze/PRE_TOY_FREEZE.json',ROOT/'reports/TOY_VALIDATION.json']
dump(ROOT/'freeze/PRE_RUN_FREEZE.json',{'utc':utc(),'sha256':{str(p.relative_to(ROOT)):sha(p) for p in paths},'passed_toys':len(report['tests']),'references_not_in_solver_freeze':True})
print(json.dumps({'prepared':True,'toy_count':len(report['tests']),'trajectories':24,'checkpoint_rows':48}))
