"""Post-seal scoring only. No heuristic invocation and no optimizer import."""
import collections,csv,json,math,statistics,time
from common import ROOT,dump,read,sha,utc,verify
from integer_audit import check
from checkpoints import at
verify()
seal=read(ROOT/'raw/HEURISTICS_FINISHED.json')
assert seal['heuristics_sha256']==sha(ROOT/'raw/heuristics.jsonl')
records=[json.loads(line) for line in (ROOT/'raw/heuristics.jsonl').read_text().splitlines()]
protocol=read(ROOT/'freeze/PROTOCOL.json');schedule=read(ROOT/'freeze/SCHEDULE.json')
assert len(records)==len(schedule)==24
assert [(r['instance_id'],r['method'],r['search_seed']) for r in records]==[(s['instance_id'],s['method'],s['search_seed']) for s in schedule]
reference_read_started=utc()
refs={n:read(ROOT/'reference'/f'{n}.reference_solution.json') for n in protocol['instances']}
rows=[];trace_checks=[];anomalies=[]
for r in records:
 raw=read(ROOT/'input'/f"{r['instance_id']}.json");ref=refs[r['instance_id']]['total_cost'];last=math.inf;trace_legal=True
 base=r.get('baseline')
 if base is not None:
  assert check(raw,base,5)['accepted'];last=base['reported_cost']
 for e in r.get('trace',[]):
  assert e['deltas']<=160000
  if e['candidate'] is not None:assert check(raw,e['candidate'],5)['accepted']
  assert check(raw,e['incumbent'],5)['accepted']
  assert e['incumbent']['reported_cost']<=last;last=e['incumbent']['reported_cost']
  if e['candidate_status']!='complete':assert e['candidate'] is None and not e['accepted']
 if r.get('output') is not None:assert check(raw,r['output'],5)['accepted']
 assert r['deltas']<=160000
 if 'delta_by_kind' in r:assert sum(r['delta_by_kind'].values())==r['deltas']
 trace_checks.append({'instance_id':r['instance_id'],'method':r['method'],'search_seed':r['search_seed'],'checked_trace_entries':len(r.get('trace',[])),'passed':True})
 for cut in protocol['checkpoints']:
  cp=at(r,cut);checked=check(raw,cp['output'],5);cost=checked['cost'] if checked['accepted'] else None
  gap=100*(cost-ref)/ref if cost is not None else None
  row={'instance_id':r['instance_id'],'method':r['method'],'search_seed':r['search_seed'],'checkpoint':cut,
   'trajectory_status':r['status'],'stop_reason':r['stop_reason'],'reached_cut':cp['reached_cut'],'legal':checked['accepted'],
   'cost':cost,'official_reference':ref,'gap_percent':gap,'official_value_hit':cost==ref,
   'output':cp['output'],'check':checked,'last_atomic_record_deltas':cp['last_atomic_record_deltas']}
  rows.append(row)
  if cost is not None and cost<ref:anomalies.append(row)
summaries=[]
for n in protocol['instances']:
 for cut in protocol['checkpoints']:
  for method in protocol['methods']:
   group=[r for r in rows if (r['instance_id'],r['checkpoint'],r['method'])==(n,cut,method)]
   costs=[r['cost'] for r in group if r['legal']];gaps=[r['gap_percent'] for r in group if r['legal']]
   statuses=collections.Counter(r['trajectory_status'] for r in group)
   summary={'instance_id':n,'checkpoint':cut,'method':method,'planned_seeds':4,'observed_rows':len(group),'legal_outputs':len(costs),
    'reached_cut':sum(r['reached_cut'] for r in group),'INIT_FAIL':statuses['INIT_FAIL'],'CONSTRUCTION_FAIL':statuses['CONSTRUCTION_FAIL'],
    'NOT_RUN':statuses['NOT_RUN'],'other_failure':sum(v for k,v in statuses.items() if k not in ['LEGAL_COMPLETION','INIT_FAIL','CONSTRUCTION_FAIL','NOT_RUN']),
    'official_reference':refs[n]['total_cost'],'cost_mean':statistics.mean(costs) if costs else None,'cost_min':min(costs) if costs else None,
    'cost_worst':max(costs) if costs else None,'gap_mean_percent':statistics.mean(gaps) if gaps else None,
    'gap_min_percent':min(gaps) if gaps else None,'gap_worst_percent':max(gaps) if gaps else None,
    'official_value_hits':sum(r['official_value_hit'] for r in group),'seed_costs':{str(r['search_seed']):r['cost'] for r in group}}
   summaries.append(summary)
initializations=[]
for n in protocol['instances']:
 g=[r for r in records if r['instance_id']==n];inits=[r.get('initialization') for r in g]
 # Same deterministic initializer and same budget must yield identical baseline; volatile DFS times excluded.
 assert len({json.dumps(r.get('baseline'),sort_keys=True) for r in g})==1
 first=inits[0] or {};dfs=first.get('capacity_partition') or {}
 initializations.append({'instance_id':n,'planned_initializations':8,'baseline_identical_all_methods_seeds':True,
  'baseline_cost':(g[0].get('baseline') or {}).get('reported_cost'),'savings_route_count':first.get('savings_route_count'),
  'ffd_fallback':first.get('fallback_triggered'),'dfs_triggered':bool(dfs),'dfs_nodes_each':dfs.get('nodes',0),
  'dfs_total_nodes':sum((i or {}).get('capacity_partition',{}).get('nodes',0) for i in inits),
  'dfs_total_cpu_seconds':sum((i or {}).get('capacity_partition',{}).get('cpu_seconds',0) for i in inits),
  'initialization_deltas':first.get('deltas_after_initialization')})
receipt=read(ROOT/'receipts/main.json');read_audit=read(ROOT/'raw/READ_AUDIT.json')
assert receipt['exit_code']==0 and not read_audit['denied'] and read_audit['reference_read_count']==0
resources={'main_receipt':receipt,'solver_cpu_seconds_sum':sum(r.get('solver_cpu_seconds',0) for r in records),
 'final_checker_cpu_seconds_sum':sum(r.get('final_checker_cpu_seconds',0) for r in records),
 'counted_deltas':sum(r['deltas'] for r in records),'delta_by_kind':{k:sum(r.get('delta_by_kind',{}).get(k,0) for r in records) for k in ['savings','removal','insertion']},
 'matrix_pair_evaluations':sum(r.get('matrix_distances',0) for r in records),'objective_edge_evaluations':sum(r.get('objective_edges',0) for r in records),
 'dfs_entered_nodes_total':sum(i['dfs_total_nodes'] for i in initializations),'dfs_cpu_seconds_total':sum(i['dfs_total_cpu_seconds'] for i in initializations),
 'external_api_calls':0,'scientific_model_calls':0,'dependency_installs':0,'uploads':0,'oracle_calls':0,
 'cost_scope':'No billed external calls or purchases; actual process CPU is reported, platform cloud cost is not priced here.'}
summary={'utc':utc(),'unique_benchmark_instances':3,'planned_trajectories':24,'observed_trajectories':len(records),
 'legal_trajectories':sum(r['status']=='LEGAL_COMPLETION' for r in records),'trajectory_status_counts':dict(collections.Counter(r['status'] for r in records)),
 'planned_checkpoint_rows':48,'observed_checkpoint_rows':len(rows),'legal_checkpoint_rows':sum(r['legal'] for r in rows),
 'checkpoint_rows_reached':sum(r['reached_cut'] for r in rows),'reference_read_started_after_seal':reference_read_started,
 'sealed_utc':seal['utc'],'below_reference_anomaly_count':len(anomalies),'per_instance_method':summaries,
 'initialization':initializations,'independent_audit_status':'not performed by this worker; task-specific and posthoc checks passed',
 'limitations':['Three named benchmarks only; seeds and checkpoints are dependent repeats, not new instances.','No SOTA comparison, significance claim, universal superiority, or independent optimality proof.','K<=5 is local protocol; reported official K relation remains unasserted.','Results measure these two simple methods with same counted deltas; initialization and checks add measured CPU.']}
dump(ROOT/'reports/SUMMARY.json',summary);dump(ROOT/'reports/CHECKPOINT_RESULTS.json',rows)
dump(ROOT/'reports/TRACE_CHECKS.json',{'passed':True,'checks':trace_checks,'candidate_and_incumbent_outputs_checked':sum(x['checked_trace_entries'] for x in trace_checks)})
dump(ROOT/'reports/RESOURCE_ACCOUNTING.json',resources);dump(ROOT/'reports/BELOW_REFERENCE_ANOMALIES.json',anomalies)
with (ROOT/'reports/PER_INSTANCE_METHOD.csv').open('x',newline='') as f:
 fields=[k for k in summaries[0] if k!='seed_costs'];w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
 for r in summaries:w.writerow({k:r[k] for k in fields})
def fmt(v):return 'NA' if v is None else f'{v:.4f}'
lines=['官方 CVRP 整数距离控制实验（仅3个具名实例）','',
 '计划24条独立搜索轨迹=3实例×2方法×4固定新seed；每条观察40k与160k，共48检查点，绝不是48个独立实例。',
 f"合法轨迹 {summary['legal_trajectories']}/24；合法检查点 {summary['legal_checkpoint_rows']}/48；实际达到预算检查点 {summary['checkpoint_rows_reached']}/48。",
 f"进程实际CPU {receipt['child_total_cpu_seconds']:.6f}s，wall {receipt['elapsed_wall_seconds']:.6f}s；退出码 {receipt['exit_code']}。",
 '以下每行均为同一实例/方法的4 seed；mean/min/worst是成本，gap为相对官方所报值的百分比。','']
for r in summaries:
 lines.append(f"{r['instance_id']} | {r['checkpoint']} deltas | {r['method']} | legal {r['legal_outputs']}/4 reached {r['reached_cut']}/4 | mean/min/worst {r['cost_mean']}/{r['cost_min']}/{r['cost_worst']} | mean/min/worst gap {fmt(r['gap_mean_percent'])}/{fmt(r['gap_min_percent'])}/{fmt(r['gap_worst_percent'])}% | 官方值命中 {r['official_value_hits']}/4 | INIT_FAIL {r['INIT_FAIL']} CONSTRUCTION_FAIL {r['CONSTRUCTION_FAIL']}")
lines+=['','初始化：']
for r in initializations:
 lines.append(f"{r['instance_id']}：8次共用初始解均一致，初始成本{r['baseline_cost']}，savings路线数{r['savings_route_count']}，FFD启用{r['ffd_fallback']}，DFS启用{r['dfs_triggered']}，DFS节点每次{r['dfs_nodes_each']}、总{r['dfs_total_nodes']}；初始化计费delta={r['initialization_deltas']}。")
lines+=['','证据与边界：',
 '逐边EUC_2D nint，非未舍入欧氏距离。B中两对同坐标客户仍有不同ID并必须各服务一次；所有整数矩阵存在三角违例，不假定metric。',
 'K≤5为本地明确协议；官方reportedK=5不在此被改写成已证明的官方上界语义。官方参考路线按ID和逐边整数成本独立重算合法，官网Opt=yes仅归属于官网，未独立证明最优。',
 '五字段solver输入不含参考cost/路线；主进程禁止读取reference/provenance/外部shared路径。所有输出写盘、fsync、hash封存后，评分进程才读参考值。准备阶段确曾为语义验证读取参考，不作为搜索调参或终止条件。',
 '唯一主跑，无pilot、补跑、换实例、oracle、ORTools、安装、API调用、购买或上传。原包和原core未改动，整数适配仅换矩阵与checker两处依赖。',
 f"固定delta总量{resources['counted_deltas']}；矩阵边计算{resources['matrix_pair_evaluations']}；完整目标边计算{resources['objective_edge_evaluations']}；额外DFS节点{resources['dfs_entered_nodes_total']}。计数公平不等于CPU相同。",
 '3个具名小实例仅做描述性比较，seed不是新实例，不作显著性、SOTA或推广优越性结论。整数参考值命中只表示达到给定参考成本。',
 f"低于官方值异常{len(anomalies)}；如出现只封存待核，不称突破。",'本worker的任务玩具与结果审计通过；独立审计由父任务另行执行。']
(ROOT/'reports/REPORT_ZH.txt').write_text('\n'.join(lines)+'\n')
print(json.dumps({'legal_trajectories':summary['legal_trajectories'],'checkpoint_rows':len(rows),'cpu':receipt['child_total_cpu_seconds'],'anomalies':len(anomalies),'results':summaries},ensure_ascii=False))
