"""Evidence-only archive; no upload, no credentials, no old-bundle mutation."""
import json,zipfile
from common import ROOT,utc,read,dump,sha,verify

def main():
 verify();assert read(ROOT/'reports/TRACE_CHECKS.json')['verified']
 stages={s:read(ROOT/'receipts'/f'{s}.json') for s in ['prepare','main','audit']}
 summary=read(ROOT/'reports/SUMMARY.json')
 dump(ROOT/'reports/RESOURCE_ACCOUNTING.json',{'created_utc':utc(),'stages':stages,'observed_total_child_cpu_seconds_before_packaging':sum(s['child_total_cpu_seconds'] for s in stages.values()),'observed_total_elapsed_wall_seconds_before_packaging':sum(s['elapsed_wall_seconds'] for s in stages.values()),'scope':'Supervised preparation, one main numerical launch, local analysis. Source editing, packaging and parent independent audit separate. Does not claim all assistant CPU.','main_calls':summary['recorded_runs'],'formal_oracle_inputs':summary['oracle_records'],'delta_total':summary['overall']['delta_sum'],'main_cpu_hard_cap':90,'main_wall_cap':150,'external_api_calls':0,'scientific_model_calls':0,'dependency_installs':0,'uploads':0,'financial_scope':'No billable research API, purchases or installs; platform/assistant token cost unavailable, not asserted zero.'})
 (ROOT/'README.txt').write_text('Fixed-fleet feasibility stress controls:16 fresh geometries,4 demand variants each,512 planned calls. Start reports/REPORT_ZH.txt and SUMMARY.json. Core identical to previously independently audited fixed_fleet_cvrp_20261008. Current independent external audit pending. Reproduce in a NEW directory copied from source/provenance only, create freeze/input/raw/reports/receipts/failures directories, and run python -B source/supervise.py prepare, main, audit, package. Never rerun this archived formal directory. Historical novelty check requires the five prior paths in prepare.py; those references were read-only. Generated controls are deliberate stress fixtures, not a natural demand sample. Archive excludes its own hash and package-stage receipt/logs emitted during/after packaging.\n')
 paths=[p for p in sorted(ROOT.rglob('*')) if p.is_file() and p.suffix!='.zip' and p.name not in ['MANIFEST.json','SHA256SUMS.txt','archive.sha256','package.stdout.log','package.stderr.log','package.json'] and '__pycache__' not in str(p)]
 files=[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in paths]
 dump(ROOT/'MANIFEST.json',{'created_utc':utc(),'file_count':len(files),'files':files,'external_audit_status':'pending','exclusions':['archive self hash','package-stage receipt and logs produced during/after packaging']})
 (ROOT/'SHA256SUMS.txt').write_text(''.join(f'{x["sha256"]}  {x["path"]}\n' for x in files)+f'{sha(ROOT/"MANIFEST.json")}  MANIFEST.json\n')
 archive=ROOT/(ROOT.name+'.zip')
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in paths+[ROOT/'MANIFEST.json',ROOT/'SHA256SUMS.txt']:z.write(p,str(p.relative_to(ROOT)))
 (ROOT/'archive.sha256').write_text(sha(archive)+'  '+archive.name+'\n');print(json.dumps({'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'files':len(files)}))
if __name__=='__main__':main()
