"""Frozen denominator-complete analysis, direct output/trace checks; no heuristic reruns."""
import csv,json,math,statistics,time
from collections import Counter
from common import ROOT,utc,read,dump,verify,sha
from audit import check

def mean(xs):return statistics.mean(xs) if xs else None
def ratio(n,d):return n/d if d else None
def jsonl(path):
 if not path.exists():return [],[]
 rows=[];bad=[];lines=path.read_text().splitlines()
 for i,line in enumerate(lines):
  try:rows.append(json.loads(line))
  except json.JSONDecodeError:
   if i!=len(lines)-1:raise
   bad.append({'file':str(path.relative_to(ROOT)),'line':i+1,'reason':'truncated_last_record','characters':len(line)})
 return rows,bad

def summarize(rs):
 feasible=[r for r in rs if r['oracle_feasible'] is True];infeasible=[r for r in rs if r['oracle_feasible'] is False]
 valid=[r for r in feasible if r['legal_completion']];n=len(rs);f=len(feasible);nf=len(infeasible)
 return {'planned':n,'oracle_feasible_planned':f,'oracle_infeasible_planned':nf,'oracle_unknown_planned':n-f-nf,
 'recorded':sum(r['status']!='NOT_RUN' for r in rs),'status_counts':dict(Counter(r['status'] for r in rs)),'category_counts':dict(Counter(r['evaluation_category'] for r in rs)),
 'legal_completion_count':sum(r['legal_completion'] for r in rs),'legal_completion_rate_all_planned':ratio(sum(r['legal_completion'] for r in rs),n),
 'valid_output_count':sum(r['valid_output'] for r in rs),'illegal_output_count':sum(r['illegal_output'] for r in rs),
 'feasible_legal_return_count':len(valid),'feasible_legal_return_rate':ratio(len(valid),f),'feasible_init_fail_count':sum(r['status']=='INIT_FAIL' for r in feasible),'feasible_init_fail_rate':ratio(sum(r['status']=='INIT_FAIL' for r in feasible),f),
 'feasible_search_failure_count':sum(r['search_failure'] for r in feasible),'feasible_no_output_count':sum(not r['has_output'] for r in feasible),
 'infeasible_null_output_count':sum(not r['has_output'] and r['status']!='NOT_RUN' for r in infeasible),'infeasible_null_output_rate':ratio(sum(not r['has_output'] and r['status']!='NOT_RUN' for r in infeasible),nf),'infeasible_init_fail_count':sum(r['status']=='INIT_FAIL' for r in infeasible),
 'exact_hit_count':sum(r['exact_hit'] for r in rs),'legal_suboptimal_count':sum(r['evaluation_category']=='LEGAL_SUBOPTIMAL' for r in rs),
 'le1_percent_count':sum(r['hit_le1_percent'] for r in rs),'le1_rate_all_planned':ratio(sum(r['hit_le1_percent'] for r in rs),n),'le1_rate_oracle_feasible':ratio(sum(r['hit_le1_percent'] for r in feasible),f),
 'valid_only_mean_gap_percent_secondary':mean([r['gap_percent'] for r in valid]),'valid_only_worst_gap_percent':max([r['gap_percent'] for r in valid],default=None),
 'repair_failed_candidate_count':sum(r.get('repair_failures',0) for r in rs),'fallback_trajectory_count':sum(r.get('fallback_triggered',False) for r in rs),'delta_sum':sum(r.get('deltas',0) for r in rs),'solver_cpu_seconds':sum(r.get('solver_cpu_seconds',0) for r in rs),'solver_wall_seconds':sum(r.get('solver_wall_seconds',0) for r in rs)}

def main():
 start=time.process_time();freeze=verify();cfg=read(ROOT/'freeze/PROTOCOL.json');entries=read(ROOT/'freeze/INPUT_MANIFEST.json');schedule=read(ROOT/'freeze/SCHEDULE.json')
 runs,malformed=jsonl(ROOT/'raw/heuristics.jsonl');oracles,obad=jsonl(ROOT/'raw/oracles.jsonl');malformed+=obad
 byid={r['run_id']:r for r in runs};os={r['instance_id']:r for r in oracles};inputs={e['instance_id']:read(ROOT/e['input_file']) for e in entries}
 assert len(byid)==len(runs) and len(os)==len(oracles);assert set(byid)<=set(e['run_id'] for e in schedule)
 checks=[];rows=[];failures=[];init_consistency=[]
 if (ROOT/'raw/HEURISTICS_FINISHED.json').exists():
  hf=read(ROOT/'raw/HEURISTICS_FINISHED.json');assert sha(ROOT/'raw/heuristics.jsonl')==hf['raw_sha256'] and hf['oracle_main_calls_so_far']==0
  assert max(r['completed_utc'] for r in runs)<=hf['utc'];assert all(hf['utc']<o['completed_utc'] for o in oracles)
  assert freeze['utc']<read(ROOT/'raw/STARTED.json')['utc']<hf['utc']
 else:assert not oracles
 for e in entries:
  iid=e['instance_id'];raw=inputs[iid];o=os.get(iid)
  if o:
   assert o['input_sha256']==e['input_sha256']
   for k,v in o['result']['by_k'].items():
    if v is not None:assert check(raw,dict(v,reported_cost=v['cost']),int(k))['accepted']
  same=[r for r in runs if r['instance_id']==iid]
  assert not same or all(r['baseline']==same[0]['baseline'] and r['initialization']==same[0]['initialization'] for r in same)
  init_consistency.append({'instance_id':iid,'recorded':len(same),'identical_initialization':True})
 for e in schedule:
  iid=e['instance_id'];r=byid.get(e['run_id']);raw=inputs[iid];opt=os[iid]['result']['by_k']['3'] if iid in os else None;feasible=None if iid not in os else opt is not None
  base={k:e[k] for k in ['run_id','geometry_id','instance_id','family','pattern_id','pattern_name','method','search_seed','input_sha256']}
  base.update(oracle_feasible=feasible,oracle_cost=None if opt is None else opt['cost'])
  if r is None:
   rows.append(base|{'status':'NOT_RUN','has_output':False,'legal_completion':False,'valid_output':False,'illegal_output':False,'search_failure':False,'evaluation_category':'NOT_RUN','gap_percent':None,'hit_le1_percent':False,'exact_hit':False,'cost':None});continue
  for key in ['run_id','geometry_id','instance_id','family','pattern_id','method','search_seed','input_sha256']:assert r[key]==e[key]
  assert r['deltas']<=cfg['delta_limit'] and sum(r['delta_by_kind'].values())==r['deltas']
  result=check(raw,r['output'],3);bc=check(raw,r['baseline'],3);valid=result['accepted'];legal=valid and r['status']=='LEGAL_COMPLETION';illegal=r['output'] is not None and not valid
  if r['baseline'] is not None:assert bc['accepted']
  prior=r['baseline'];accepted=failed=completed=cut=0;delta=0
  for tr in r['trace']:
   assert prior is not None and delta<=tr['deltas']<=cfg['delta_limit'];delta=tr['deltas']
   if tr['candidate_status']=='complete':
    completed+=1;c=check(raw,tr['candidate'],3);assert c['accepted'];should=c['cost']<prior['reported_cost']-1e-9;assert tr['accepted']==should
    if should:prior=tr['candidate'];accepted+=1
   else:
    assert tr['candidate_status'] in ['repair_failed','budget_discarded'];assert tr['candidate'] is None and not tr['accepted']
    failed+=tr['candidate_status']=='repair_failed';cut+=tr['candidate_status']=='budget_discarded'
   assert prior==tr['incumbent'] and check(raw,tr['incumbent'],3)['accepted']
  assert prior==r['output'] and accepted==r['accepted_improvements'] and failed==r['repair_failures'] and completed==r['iterations_completed']
  checks.append({'run_id':r['run_id'],'trace_count':len(r['trace']),'completed_candidates':completed,'repair_failed_candidates':failed,'budget_discarded_candidates':cut,'accepted_candidates':accepted,'all_emitted_candidates_legal':True,'atomic_rollback_verified':True})
  cost=result['cost'] if valid else None;tol=max(1e-8,1e-10*abs(opt['cost'])) if opt else 1e-8
  if legal and opt is not None:assert cost>=opt['cost']-tol
  if feasible is False:assert not valid
  gap=100*(cost-opt['cost'])/opt['cost'] if legal and opt is not None else None;exact=bool(legal and opt is not None and abs(cost-opt['cost'])<=tol)
  searchfail=r['status']=='ALGORITHM_FAILURE' and r['baseline'] is not None
  if feasible is None:category='ORACLE_UNKNOWN'
  elif feasible is False:category='ORACLE_INFEASIBLE_NULL_OUTPUT' if r['output'] is None else 'ORACLE_INFEASIBLE_INVALID_OUTPUT'
  elif legal:category='LEGAL_OPTIMAL' if exact else 'LEGAL_SUBOPTIMAL'
  elif r['status']=='INIT_FAIL':category='INITIALIZATION_NOT_FOUND_ON_FEASIBLE'
  elif illegal:category='ILLEGAL_OUTPUT'
  elif searchfail:category='SEARCH_FAILURE_ON_FEASIBLE'
  else:category='OTHER_FAILURE_ON_FEASIBLE'
  row=base|{'status':r['status'],'stop_reason':r['stop_reason'],'has_output':r['output'] is not None,'legal_completion':legal,'valid_output':valid,'illegal_output':illegal,'search_failure':searchfail,'evaluation_category':category,'gap_percent':gap,'hit_le1_percent':bool(legal and opt is not None and cost<=opt['cost']*1.01+tol),'exact_hit':exact,'cost':cost,'baseline_cost':bc['cost'] if bc['accepted'] else None,'routes':result.get('nonempty_routes'),'deltas':r['deltas'],'solver_cpu_seconds':r['solver_cpu_seconds'],'solver_wall_seconds':r['solver_wall_seconds'],'repair_failures':failed,'fallback_triggered':bool(r['initialization'] and r['initialization']['fallback_triggered']),'initialization_deltas':r['initialization'].get('deltas_after_initialization') if r['initialization'] else None,'accepted_improvements':accepted}
  rows.append(row)
  if not legal:failures.append(row|{'error':r['error'],'checker':result,'interpretation':'Expected no solution on oracle-infeasible input; no solver proof inferred.' if feasible is False else 'Retained failure on planned denominator.'})
 cells=[]
 for e in entries:
  rr=[r for r in rows if r['instance_id']==e['instance_id']];common=len(rr)==8 and all(r['legal_completion'] and r['oracle_feasible'] for r in rr)
  item={k:e[k] for k in ['geometry_id','instance_id','family','pattern_id','pattern_name']};item.update(common_quality_support=common,oracle_feasible=rr[0]['oracle_feasible'])
  for m in cfg['methods']:
   rs=[r for r in rr if r['method']==m];item[m]=summarize(rs);item[m]['mean_gap_all4']=mean([r['gap_percent'] for r in rs]) if all(r['gap_percent'] is not None for r in rs) else None;item[m]['mean_cost_all4']=mean([r['cost'] for r in rs]) if all(r['legal_completion'] for r in rs) else None
  cells.append(item)
 methods={m:summarize([r for r in rows if r['method']==m]) for m in cfg['methods']};patterns={};family={}
 for p in cfg['patterns']:
  cc=[c for c in cells if c['pattern_id']==p['id'] and c['common_quality_support']];quality={m:{'common_geometry_count':len(cc),'equal_geometry_mean_gap_percent':mean([c[m]['mean_gap_all4'] for c in cc])} for m in cfg['methods']}
  diffs=[c['regret2']['mean_cost_all4']-c['cheapest']['mean_cost_all4'] for c in cc]
  quality['regret2_win_tie_loss_geometry_mean_cost']=[sum(x< -1e-8 for x in diffs),sum(abs(x)<=1e-8 for x in diffs),sum(x>1e-8 for x in diffs)]
  patterns[p['id']]={'name':p['name'],'demand_vector':p['demands'],'demand_total':p['sum'],'planned_geometries':16,'oracle_feasible_inputs':sum(c['oracle_feasible'] is True for c in cells if c['pattern_id']==p['id']),'oracle_infeasible_inputs':sum(c['oracle_feasible'] is False for c in cells if c['pattern_id']==p['id']),'methods':{m:summarize([r for r in rows if r['pattern_id']==p['id'] and r['method']==m]) for m in cfg['methods']},'quality_secondary':quality}
 for f in ['uniform','two_cluster']:
  family[f]={p['id']:{m:summarize([r for r in rows if r['family']==f and r['pattern_id']==p['id'] and r['method']==m]) for m in cfg['methods']} for p in cfg['patterns']}
 geometry=[]
 for g in read(ROOT/'freeze/GEOMETRY_MANIFEST.json'):
  cc=[c for c in cells if c['geometry_id']==g['geometry_id']];fc=[c for c in cc if c['oracle_feasible'] is True];complete=len(fc)==2 and all(c['common_quality_support'] for c in fc)
  geometry.append(g|{'pattern_cells':[{k:c[k] for k in ['instance_id','pattern_id','oracle_feasible','common_quality_support']} for c in cc],'both_feasible_patterns_common_support':complete,'both_patterns_equal_weight_mean_gap':{m:mean([c[m]['mean_gap_all4'] for c in fc]) if complete else None for m in cfg['methods']}})
 complete=[g for g in geometry if g['both_feasible_patterns_common_support']]
 examples={}
 # Illustrative post-scoring examples: smallest scheduled run_id in each category, never input selection.
 for r in rows:
  k=r['evaluation_category']
  if k in examples:continue
  saved=byid.get(r['run_id']);o=os.get(r['instance_id']);raw=inputs[r['instance_id']]
  examples[k]={'selection_rule':'First run_id in frozen schedule with this post-scoring category; illustration only.',**r,'input':raw,'initialization':saved.get('initialization') if saved else None,'output':saved.get('output') if saved else None,'oracle_K3':o['result']['by_k']['3'] if o else None,'independent_simple_infeasibility_checks':{'total_demand':sum(raw['demands']),'fleet_total_capacity':raw['capacity']*raw['K'],'customers_above_half_capacity':sum(2*d>raw['capacity'] for d in raw['demands'])}}
 summary={'utc':utc(),'planned_geometries':16,'demand_variants_per_geometry':4,'planned_inputs':64,'planned_runs':512,'recorded_runs':len(runs),'oracle_records':len(oracles),'oracle_feasible_inputs':sum(c['oracle_feasible'] is True for c in cells),'oracle_infeasible_inputs':sum(c['oracle_feasible'] is False for c in cells),'overall':summarize(rows),'methods':methods,'patterns':patterns,'family_breakdowns_descriptive':family,'both_feasible_patterns_common_geometry_ids':[g['geometry_id'] for g in complete],'secondary_complete_geometry_mean_gap':{m:mean([g['both_patterns_equal_weight_mean_gap'][m] for g in complete]) for m in cfg['methods']},'independent_external_review_status':'pending','statistical_scope':'16 blocked fresh development geometries, deliberate demand stress controls; variants and seeds not independent; no significance/general distribution claim.','oracle_scope':'Exact combinatorial DP with IEEE double costs; no certified interval arithmetic.','main_receipt':read(ROOT/'receipts/main.json'),'analysis_cpu_seconds':time.process_time()-start,'malformed_raw_records':malformed}
 dump(ROOT/'reports/SUMMARY.json',summary);dump(ROOT/'reports/INPUT_CELL_RESULTS.json',cells);dump(ROOT/'reports/GEOMETRY_RESULTS.json',geometry);dump(ROOT/'reports/RUN_METRICS.json',rows);dump(ROOT/'reports/ILLUSTRATIVE_EXAMPLES.json',examples)
 dump(ROOT/'reports/TRACE_CHECKS.json',{'verified':True,'run_checks':checks,'common_initialization':init_consistency,'illegal_output_count':sum(r['illegal_output'] for r in rows),'unchanged_source_freeze_verified':True,'late_oracle_seal_verified':bool((ROOT/'raw/HEURISTICS_FINISHED.json').exists()),'label_firewall':'run.py allowlists solver raw/cfg; tags added only after solver returns.'})
 dump(ROOT/'failures/FAILURE_LEDGER.json',{'all_non_legal_return_records':failures,'not_run':[r for r in rows if r['status']=='NOT_RUN'],'malformed_raw_records':malformed,'feasible_initialization_failure_ids':sorted({r['instance_id'] for r in rows if r['evaluation_category']=='INITIALIZATION_NOT_FOUND_ON_FEASIBLE'}),'oracle_infeasible_input_ids':[c['instance_id'] for c in cells if c['oracle_feasible'] is False],'repair_failed_candidate_count':sum(c['repair_failed_candidates'] for c in checks),'budget_discarded_candidate_count':sum(c['budget_discarded_candidates'] for c in checks),'infeasible_null_is_not_ability_failure':True,'init_fail_is_not_infeasibility_proof':True,'raw_evidence':'raw/heuristics.jsonl stores all complete, failed and truncated candidates and retained incumbents.'})
 fields=sorted(set().union(*(r.keys() for r in rows)))
 with (ROOT/'reports/RUN_METRICS.csv').open('x') as f:
  wr=csv.DictWriter(f,fieldnames=fields);wr.writeheader();wr.writerows(rows)
 rec=summary['main_receipt'];overall=summary['overall'];a=methods['cheapest'];b=methods['regret2']
 text='固定车队可行性压力对照：冻结后的单次正式结果\n\n'
 text+='模型为最多3条非空车路线（K≤3），每车容量9；不是恰好3车。16个全新几何（uniform/two_cluster各8），每几何4个刻意构造需求变体，2法×4seed，共512次。独立几何数仍是16；需求变体与seed均是同几何重复。\n'
 text+=f'全计划512次：已记录{len(runs)}，合法返回{overall["legal_completion_count"]}，INIT_FAIL {overall["status_counts"].get("INIT_FAIL",0)}，搜索异常{overall["feasible_search_failure_count"]}，非法输出{overall["illegal_output_count"]}。全计划合法率只描述流程，不能把不可行输入纳入能力失败率。\n'
 text+=f'oracle可行32个输入/256次：合法返回{overall["feasible_legal_return_count"]}/256，初始化没找到{overall["feasible_init_fail_count"]}/256；oracle不可行32个输入/256次：无输出{overall["infeasible_null_output_count"]}/256。后者是数学无解对照的预期结果，不是算法能力失败；solver本身只报INIT_FAIL，并没有不可行性证明。\n\n'
 for pid,p in patterns.items():
  text+=f'{pid} {p["name"]}，需求{p["demand_vector"]}总量{p["demand_total"]}：oracle可行{p["oracle_feasible_inputs"]}/16，不可行{p["oracle_infeasible_inputs"]}/16。\n'
  for m in cfg['methods']:
   x=p['methods'][m];text+=f'  {m}：计划{x["planned"]}，合法{x["legal_completion_count"]}，可行侧INIT_FAIL {x["feasible_init_fail_count"]}，不可行侧无输出{x["infeasible_null_output_count"]}，≤1%命中{x["le1_percent_count"]}。\n'
 text+='\n这4种需求是预先定下的stress controls，特意含装箱困难和已知不可行结构，不能当自然需求分布或一般失败率。紧容量可行向量能分成3组[4,3,2]，但FFD会用4箱；几何相关savings是否先成功决定是否进入这个失效边界。\n'
 text+=f'合法返回内，精确最优{overall["exact_hit_count"]}，合法但次优{overall["legal_suboptimal_count"]}。这是评分后的区分；INIT_FAIL只表示初始化未找到，不能当数学不可行结论。全部启发式封存后才运行64个oracle，未暖启动、修复、筛样或调参。\n'
 text+='\n次要质量指标（只在双方4seed全合法的同需求几何上，可能有幸存者偏差，不替代主分母）：\n'
 for pid,p in patterns.items():
  q=p['quality_secondary'];text+=f'  {pid}：共同几何{q["cheapest"]["common_geometry_count"]}；平均gap cheapest={q["cheapest"]["equal_geometry_mean_gap_percent"]}%，regret2={q["regret2"]["equal_geometry_mean_gap_percent"]}%；regret2胜/平/负={q["regret2_win_tie_loss_geometry_mean_cost"]}。\n'
 text+=f'候选修复失败总{overall["repair_failed_candidate_count"]}次，均原子丢弃并保留合法incumbent，不能等同整次搜索失败。每call上限5000delta含初始化；早期INIT_FAIL不补足、不转移预算。\n'
 text+=f'\n主进程CPU {rec["child_total_cpu_seconds"]:.6f}秒，wall {rec["elapsed_wall_seconds"]:.6f}秒；硬CPU90/wall150，退出码{rec["exit_code"]}。一次启动，无预跑/补跑/补抽，核心源码逐字节不变，外部API/科研模型/安装/上传均0。\n'
 text+='证据：freeze/预生成与主跑冻结、64inputs、512计划；raw/全量轨迹与后置oracle；reports/逐运行、逐输入格、逐几何、首例示范与trace复查；receipts/退出/CPU/wall；provenance/上一版本toy及独审PASS。冻结时间和哈希是本地证据，不是第三方时间戳。独立新审计待父任务执行。\n'
 (ROOT/'reports/REPORT_ZH.txt').write_text(text)
 verify();print(json.dumps({'planned':512,'legal':overall['legal_completion_count'],'feasible_init_fail':overall['feasible_init_fail_count'],'infeasible_null':overall['infeasible_null_output_count'],'suboptimal':overall['legal_suboptimal_count'],'illegal':overall['illegal_output_count']}))
if __name__=='__main__':main()
