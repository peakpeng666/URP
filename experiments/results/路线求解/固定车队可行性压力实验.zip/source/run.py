"""One formal launch: no structural labels to solver, all heuristics sealed before oracle."""
import json,os,platform,sys,time
from common import ROOT,utc,read,dump,sha,verify
from fixed_solver import run_one
SOLVER_RAW_KEYS=('instance_id','coordinates','demands','capacity','K')
SOLVER_CFG_KEYS=('delta_limit','iterations','per_trajectory_cpu_seconds','per_trajectory_wall_seconds')
def main():
 start=time.process_time();wall=time.perf_counter();verify()
 dump(ROOT/'raw/STARTED.json',{'utc':utc(),'pid':os.getpid(),'main_launch_number':1,'freeze_sha256':sha(ROOT/'freeze/PRE_RUN_FREEZE.json')})
 affinity=sorted(os.sched_getaffinity(0)) if hasattr(os,'sched_getaffinity') else None
 if affinity:os.sched_setaffinity(0,{affinity[-1]})
 dump(ROOT/'receipts/ENVIRONMENT.json',{'utc':utc(),'python':sys.version,'platform':platform.platform(),'stdlib_only':True,'affinity_before':affinity,'selected_cpu':affinity[-1] if affinity else None,'external_calls':0,'dependency_installs':0,'solver_raw_keys':SOLVER_RAW_KEYS,'solver_cfg_keys':SOLVER_CFG_KEYS})
 cfg=read(ROOT/'freeze/PROTOCOL.json');scfg={k:cfg[k] for k in SOLVER_CFG_KEYS};schedule=read(ROOT/'freeze/SCHEDULE.json');cpu=time.process_time();ws=time.perf_counter();count=0
 with (ROOT/'raw/heuristics.jsonl').open('x') as out:
  for e in schedule:
   raw=read(ROOT/e['input_file']);r={k:raw[k] for k in SOLVER_RAW_KEYS};record=run_one(r,e['method'],e['search_seed'],scfg)
   record.update({k:e[k] for k in ('run_id','geometry_id','family','pattern_id','pattern_name','input_sha256')});record['completed_utc']=utc()
   out.write(json.dumps(record,ensure_ascii=False,allow_nan=False)+'\n');out.flush();os.fsync(out.fileno());count+=1
 hcpu=time.process_time()-cpu;hwall=time.perf_counter()-ws
 dump(ROOT/'raw/HEURISTICS_FINISHED.json',{'utc':utc(),'planned':len(schedule),'recorded':count,'raw_sha256':sha(ROOT/'raw/heuristics.jsonl'),'oracle_main_calls_so_far':0,'heuristic_stage_cpu_seconds':hcpu,'heuristic_stage_wall_seconds':hwall,'every_record_flushed_and_fsynced':True})
 with (ROOT/'raw/HEURISTICS_FINISHED.json').open('rb') as f:os.fsync(f.fileno())
 # Intentionally delayed import. Solver has neither oracle object nor labels.
 from oracle import solve
 cpu=time.process_time();ws=time.perf_counter();ocount=0
 with (ROOT/'raw/oracles.jsonl').open('x') as out:
  for e in read(ROOT/'freeze/INPUT_MANIFEST.json'):
   r=read(ROOT/e['input_file']);cs=time.process_time();w=time.perf_counter();o=solve(r)
   row={k:e[k] for k in ('geometry_id','instance_id','pattern_id','input_sha256')};row.update(result=o,oracle_cpu_seconds=time.process_time()-cs,oracle_wall_seconds=time.perf_counter()-w,completed_utc=utc())
   out.write(json.dumps(row,allow_nan=False)+'\n');out.flush();os.fsync(out.fileno());ocount+=1
 ocpu=time.process_time()-cpu;owall=time.perf_counter()-ws;verify()
 dump(ROOT/'raw/FINISHED.json',{'utc':utc(),'heuristic_runs':count,'oracle_runs':ocount,'heuristic_cpu_seconds':hcpu,'heuristic_wall_seconds':hwall,'oracle_cpu_seconds':ocpu,'oracle_wall_seconds':owall,'main_internal_cpu_seconds':time.process_time()-start,'main_internal_wall_seconds':time.perf_counter()-wall,'source_and_inputs_unchanged':True,'all_heuristics_preceded_main_oracle':True})
 print(json.dumps({'heuristic_runs':count,'oracle_runs':ocount,'main_cpu_seconds':time.process_time()-start}))
if __name__=='__main__':main()
