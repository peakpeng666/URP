"""Experiment-only data, schedule and evidence freeze. No solver/oracle calls."""
import random
from pathlib import Path
from common import ROOT,utc,sha,read,dump,digest
OLD=[Path('/workspace/shared')/p for p in ['vrp_unseen_geometry_20261007','cvrp_scale_20261007','vrp_time_windows_20261007','exact_cvrp_controls_20261008','fixed_fleet_cvrp_20261008']]
PATTERNS=[
 {'id':'D01','name':'low_load_feasible','demands':[1,1,1,2,2,2,3,3,3],'sum':18,'construction':'Two bins each [3,3,2,1] and [3,2,2,1,1] have loads9/9; thus <=K3 feasible.'},
 {'id':'D02','name':'tight_packable_ffd_stress','demands':[4,4,4,3,3,3,2,2,2],'sum':27,'construction':'Three [4,3,2] bins of9 are feasible. Demand-descending first-fit uses4 bins; savings may still find3. Selected deliberately before any new input/solver result.'},
 {'id':'D03','name':'packing_infeasible','demands':[5,5,5,5,1,1,1,1,1],'sum':25,'construction':'Four demands5>Q/2 require >=4 routes although total25<=KQ27.'},
 {'id':'D04','name':'total_overload_infeasible','demands':[5,5,5,3,3,3,2,2,2],'sum':30,'construction':'Total30>KQ27, all individual demands<=Q9.'}]

def cfg():
 return {'title':'Fixed-fleet feasibility stress controls v1','created_utc':utc(),'n':9,'Q':9,'K':3,'geometry_count':16,'input_variant_count':64,'geometry_seeds':list(range(2026100823300,2026100823316)),'families':['uniform']*8+['two_cluster']*8,'patterns':PATTERNS,
 'generator':'random.Random(seed); uniform U[-50,50]^2 or alternating Gaussian centers(-30,-20)/(30,20), standard deviation8; depot0,0; round6. Each geometry is shared by4 demand variants.',
 'demand_shuffle':'For pattern zero-based pi, random.Random(geometry_seed+1000000+10000*pi).shuffle(fixed demand vector); never resample.',
 'selection_scope':'Purpose-built stress controls, not representative random demand distribution; mathematical structures fixed before geometry generation. No result-dependent selection, tuning, repair or sample replacement.',
 'methods':['cheapest','regret2'],'search_seeds':[113011,113027,113041,113057],'schedule_seed':2026100823399,'planned_runs':512,
 'delta_limit':5000,'iterations':1000000000,'per_trajectory_cpu_seconds':2.,'per_trajectory_wall_seconds':10.,'main_cpu_soft_seconds':89,'main_cpu_hard_seconds':90,'main_wall_seconds':150,
 'unchanged_core':'Exact predecessor bytes: fixed_solver.py, legacy/**, audit.py, oracle.py, common.py, supervise.py. No algorithm edits; only experimental data/orchestration/statistics/package.',
 'solver_interface':'Only instance_id, coordinates, demands, capacity,K passed as raw; only delta_limit,iterations,per_trajectory_cpu_seconds,per_trajectory_wall_seconds passed as cfg. No pattern, construction label, expected feasibility, geometry family, manifest or oracle data in solver arguments.',
 'initialization':'Common charged legacy parallel savings. If >K, exactly one deterministic FFD fallback then fixed-bin sequential cheapest insertion. INIT_FAIL means initializer did not provide a legal solution, never a mathematical infeasibility claim. No retry or oracle rescue.',
 'repair':'Old fixedK cheapest/regret2; insertion and singleton choices K-gated. Failed/truncated candidate atomically discarded, legal incumbent retained; failed effort charged.',
 'objective':'At most K=3 nonempty depot-return routes; every customer exactly once, load<=Q9; sum unrounded Euclidean distance. Not exactly three routes.',
 'meter':'Each call up to5000 deltas including initialization and failed candidates. Early INIT_FAIL can consume less; unused allowance not transferred/replenished. Equal delta limit not equal CPU/FLOPs.',
 'oracle':'Import/call only after all512 heuristic attempts are durably written, fsynced, hashed, and sealed. Oracle only evaluates all64 planned inputs; never warms, repairs, selects, filters or tunes heuristics. IEEE double exact combinatorial DP, not interval certificate.',
 'aggregation':'Primary all512/method256 planned; separately oracle-feasible256/method128 and infeasible256/method128 expected by construction, determined by post-seal oracle. LEGAL_COMPLETION/INIT_FAIL/ALGORITHM_FAILURE/ILLEGAL_OUTPUT/NOT_RUN status; feasible INIT_FAIL is initialization failure, infeasible null output is expected abstention, not ability failure and not solver proof. Search candidate failure is separate from trajectory failure. Legal suboptimal outputs reported by oracle gap.',
 'secondary_quality':'Within each demand pattern, average four seeds per geometry among geometry-pattern cells where both methods all4 legally return; equal-weight common cells. Overall geometry mean only where both feasible patterns and both methods all4 valid; descriptive survivor subset, never replace planned-denominator results. Families descriptive; no significance claims.',
 'independence':'16 independent generated geometries;4 demand variants on each and4 search seeds are repeated/block observations, not64/256/512 independent geometries.',
 'hit_tolerance':'Exact abs(cost-opt)<=max(1e-8,1e-10*abs(opt)); <=1% uses same absolute tolerance; signed gap retained.',
 'failure_policy':'One formal launch. No main rerun or replacement. All scheduled failures/missing kept; partial last JSONL line retained as evidence and counted NOT_RUN, not silently removed. Numerical/data/source freeze fixed before main.',
 'throughput_basis':{'predecessor_planned':128,'predecessor_main_cpu_seconds':2.297943,'predecessor_main_wall_seconds':2.3165903840126703,'linear_512_cpu_seconds':9.191772,'pilot_calls':0},
 'prior_tests':'No repeated toy calls: unchanged-core predecessor toy validation and independent PASS copied into provenance. No new main pilot.',
 'external_api_calls':0,'scientific_model_calls':0,'dependency_installs':0,'uploads':0}

def make_geometry(gi,c):
 seed=c['geometry_seeds'][gi];r=random.Random(seed);family=c['families'][gi];xy=[[0.,0.]]
 for j in range(9):
  pt=[r.uniform(-50,50),r.uniform(-50,50)] if family=='uniform' else [r.gauss(z,8) for z in ((-30,-20) if j%2==0 else (30,20))]
  xy.append([round(z,6) for z in pt])
 return xy

def main():
 c=cfg();dump(ROOT/'freeze/PROTOCOL.json',c)
 prov=[]
 for p in sorted((ROOT/'source').rglob('*.py')):
  if p.name in ['prepare.py','run.py','analyze.py','package.py']:continue
  original=OLD[-1]/p.relative_to(ROOT);assert sha(p)==sha(original)
  prov.append({'copy':str(p.relative_to(ROOT)),'source':str(original),'sha256':sha(p),'byte_identical':True})
 dump(ROOT/'freeze/SOURCE_PROVENANCE.json',prov)
 prereg={str(p.relative_to(ROOT)):sha(p) for folder in ['source','provenance','freeze'] for p in sorted((ROOT/folder).rglob('*')) if p.is_file()}
 dump(ROOT/'freeze/PRE_GENERATION_FREEZE.json',{'utc':utc(),'generated_inputs':0,'main_launches':0,'solver_calls':0,'oracle_calls':0,'sha256':prereg})
 oldo=set();oldu=set();records=[]
 for d in OLD:
  files=list((d/'input').glob('*.json'))
  if (d/'inputs.json').exists():files.append(d/'inputs.json')
  for p in files:
   v=read(p)
   for x in v if isinstance(v,list) else [v]:
    if not isinstance(x,dict):continue
    xy=x.get('coordinates')
    if xy is None and isinstance(x.get('nodes'),list):xy=[[n['x'],n['y']] for n in x['nodes']]
    if xy is None:continue
    h=digest(xy);u=digest(sorted(xy));oldo.add(h);oldu.add(u)
    records.append({'file':str(p),'file_sha256':sha(p),'ordered_sha256':h,'unordered_sha256':u})
  mf=d/'freeze/INPUT_MANIFEST.json'
  if mf.exists():
   for e in read(mf):
    if 'coordinates_sha256' in e:oldo.add(e['coordinates_sha256'])
    if 'unordered_coordinates_sha256' in e:oldu.add(e['unordered_coordinates_sha256'])
  mf=d/'freeze/OLD_GEOMETRY_HASHES.json'
  if mf.exists():
   q=read(mf)
   for key in ['hashes','ordered_hashes','inherited_ordered_hashes']:oldo.update(q.get(key,[]))
   oldu.update(q.get('unordered_hashes',[]))
   for e in q.get('records',[]):
    for key in ['ordered_coordinate_sha256','ordered_sha256']:
     if key in e:oldo.add(e[key])
    for key in ['unordered_coordinate_sha256','unordered_sha256']:
     if key in e:oldu.add(e[key])
 dump(ROOT/'freeze/OLD_GEOMETRY_HASHES.json',{'records':records,'ordered_hashes':sorted(oldo),'unordered_hashes':sorted(oldu),'scope':'Five specified prior bundles plus their inherited recorded hashes, not universal novelty.'})
 entries=[];new=set();newu=set();geoms=[]
 for gi in range(c['geometry_count']):
  xy=make_geometry(gi,c);h=digest(xy);u=digest(sorted(xy));assert h not in oldo|new and u not in oldu|newu
  new.add(h);newu.add(u);gid=f'FS{gi+1:02d}';seed=c['geometry_seeds'][gi]
  geoms.append({'geometry_id':gid,'generation_seed':seed,'family':c['families'][gi],'coordinates_sha256':h,'unordered_coordinates_sha256':u})
  for pi,p in enumerate(PATTERNS):
   dem=p['demands'][:];dseed=seed+1000000+10000*pi;random.Random(dseed).shuffle(dem);iid=gid+'-'+p['id']
   r={'instance_id':iid,'coordinates':xy,'demands':[0]+dem,'capacity':9,'K':3};path=f'input/{iid}.json';dump(ROOT/path,r)
   entries.append(dict(geoms[-1],instance_id=iid,pattern_id=p['id'],pattern_name=p['name'],pattern_index=pi,demand_shuffle_seed=dseed,input_file=path,input_sha256=sha(ROOT/path)))
 dump(ROOT/'freeze/GEOMETRY_MANIFEST.json',geoms);dump(ROOT/'freeze/INPUT_MANIFEST.json',entries)
 schedule=[dict(e,method=m,search_seed=s) for e in entries for s in c['search_seeds'] for m in c['methods']];random.Random(c['schedule_seed']).shuffle(schedule)
 for i,e in enumerate(schedule):e['run_id']=i
 dump(ROOT/'freeze/SCHEDULE.json',schedule)
 dump(ROOT/'freeze/PRE_RUN_FREEZE.json',{'utc':utc(),'main_launches_before_freeze':0,'main_geometries':16,'input_variants':64,'planned_runs':512,'duplicates_across_geometries':0,'sha256':{str(p.relative_to(ROOT)):sha(p) for folder in ['source','input','freeze','provenance'] for p in sorted((ROOT/folder).rglob('*')) if p.is_file()}})
 print('FROZEN:16 fresh geometries,64 predefined variants,512 calls; solver/oracle calls0.')
if __name__=='__main__':main()
