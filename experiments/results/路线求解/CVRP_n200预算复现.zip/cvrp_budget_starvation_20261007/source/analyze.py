"""Frozen descriptive analysis and independent all-output route audit."""
from pathlib import Path
from collections import Counter,defaultdict
import csv,hashlib,json,math,statistics,resource
ROOT=Path(__file__).resolve().parents[1]
resource.setrlimit(resource.RLIMIT_CPU,(10,10))
def read(p):return json.loads(p.read_text())
def dump(p,d):
    with p.open('x') as f:json.dump(d,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
def csvwrite(name,rows):
    if not rows:return
    with (ROOT/'reports'/name).open('x',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def independent_audit(inst,out):
    errors=[];detail=[];allnodes=[];edges=[]
    if not isinstance(out,dict) or not isinstance(out.get('routes'),list):return {'passed':False,'errors':['missing routes'],'route_details':[]}
    n=len(inst['coordinates'])-1
    for ri,route in enumerate(out['routes']):
        valid=bool(isinstance(route,list) and len(route)>=3 and route[0]==0 and route[-1]==0 and all(type(x)==int and 0<x<=n for x in route[1:-1]))
        if not valid:errors.append('invalid route '+str(ri));continue
        nodes=route[1:-1];allnodes.extend(nodes)
        load=sum(inst['demands'][x] for x in nodes)
        if load>inst['capacity']:errors.append('capacity '+str(ri))
        dist=[]
        for a,b in zip(route,route[1:]):
            x1,y1=inst['coordinates'][a];x2,y2=inst['coordinates'][b]
            dist.append(math.hypot(x1-x2,y1-y2))
        edges.extend(dist)
        detail.append({'route_index':ri,'customers':nodes,'load':load,'capacity':inst['capacity'],'cost':math.fsum(dist)})
    if Counter(allnodes)!=Counter(range(1,n+1)):errors.append('customer coverage not exactly once')
    cost=math.fsum(edges);reported=out.get('reported_cost')
    if not isinstance(reported,(int,float)) or not math.isfinite(reported) or not math.isclose(cost,reported,rel_tol=1e-12,abs_tol=1e-8):errors.append('objective mismatch')
    return {'passed':not errors,'errors':errors,'recomputed_cost':cost,'reported_cost':reported,'route_details':detail}
def ranks(vals):
    names=sorted(vals,key=lambda a:(vals[a],a));out={};i=0
    while i<len(names):
        j=i+1
        while j<len(names) and abs(vals[names[j]]-vals[names[i]])<=1e-9:j+=1
        for a in names[i:j]:out[a]=(i+1+j)/2
        i=j
    return out
def mean(x):return statistics.mean(x) if x else None
cfg=read(ROOT/'freeze/PROTOCOL.json');points=cfg['report_checkpoints'];algorithms=['_'.join(x) for x in cfg['pairs']]
scheduled=read(ROOT/'freeze/SCHEDULE.json')
raw=ROOT/'raw/TRAJECTORIES.jsonl'
rows=[json.loads(x) for x in raw.read_text().splitlines()] if raw.exists() else []
ids={r['run_id'] for r in rows}
for c in scheduled:
    if c['run_id'] not in ids:rows.append({**c,'status':'not_written_process_termination','missing_budgets':cfg['checkpoints']})
assert len(rows)==32 and len({r['run_id'] for r in rows})==32
oldrows=[json.loads(x) for x in (ROOT/'input/prior_selected_trajectories.jsonl').read_text().splitlines()]
oldmap={(r['geometry_id'],r['algorithm']):r for r in oldrows}
audits=[];checks=[];observations=[];firsts=[];replications=[];failures=[];lookup={}
for r in rows:
    rid=r['run_id'];g=r['geometry_id'];a=r['algorithm'];old=oldmap[(g,a)];inst=read(ROOT/r['input_file'])
    if r.get('status')!='executed' or r.get('missing_budgets') or r.get('error'):failures.append({'run_id':rid,'status':r['status'],'missing_budgets':r.get('missing_budgets'),'error':r.get('error')})
    outputs=[('baseline',r.get('baseline'))]+[(str(c['budget']),c['output']) for c in r.get('checkpoints',[])]
    for label,out in outputs:
        audit=independent_audit(inst,out);audits.append({'run_id':rid,'geometry_id':g,'algorithm':a,'checkpoint':label,**audit})
    cps={c['budget']:c for c in r.get('checkpoints',[])}
    costs=[r['baseline']['reported_cost']] if r.get('baseline') else []
    costs.extend(cps[b]['output']['reported_cost'] for b in sorted(cps))
    checks.append({'run_id':rid,'monotonicity':all(y<=x+1e-9 for x,y in zip(costs,costs[1:])),
      'ledger':all(c['deltas']==c['budget']==sum(c['delta_by_kind'].values()) and c['delta_by_kind']['savings']==19900 and c['matrix_distances']==40401 for c in cps.values())})
    for b in [40000,160000]:
        cp=cps.get(b);op=next(c for c in old['checkpoints'] if c['budget']==b)
        strip=lambda x:{k:v for k,v in x.items() if k not in ['solver_cpu_seconds','solver_wall_seconds']}
        passed=bool(cp and strip(cp)==strip(op))
        replications.append({'run_id':rid,'original_run_id':old['run_id'],'geometry_id':g,'algorithm':a,'budget':b,'exact_checkpoint_except_timing':passed,
          'exact_baseline':r.get('baseline')==old['baseline'],'exact_baseline_check':r.get('baseline_check')==old['baseline_check'],
          'exact_completed_trace': [x for x in r.get('trace',[]) if x['deltas']<=b]==[x for x in old['trace'] if x['deltas']<=b]})
    trace=r.get('trace',[]);first=next((x for x in trace if x['accepted']),None)
    firsts.append({'run_id':rid,'geometry_id':g,'family':r['family'],'algorithm':a,'first_completed_round_delta':trace[0]['deltas'] if trace else None,
      'first_improvement_delta':first['deltas'] if first else None,'first_improvement_censored':first is None,
      'censoring_delta':r.get('deltas',0) if first is None else None,'attained_delta':r.get('deltas',0),
      'improvement_after_160k':bool(first and first['deltas']>160000)})
    base=r.get('baseline',{}).get('reported_cost')
    for b in points:
        c=cps.get(b)
        if not c or not c.get('scoreable'):continue
        value={'run_id':rid,'geometry_id':g,'family':r['family'],'algorithm':a,'budget':b,'cost':c['output']['reported_cost'],
          'baseline_cost':base,'baseline_gain_pct':100*(base-c['output']['reported_cost'])/base,
          'iterations_started':c['iterations_started'],'iterations_completed':c['iterations_completed'],'accepted_improvements':c['accepted_improvements'],
          'solver_cpu_seconds':c['solver_cpu_seconds'],'rank':None,'relative_regret_pct':None}
        observations.append(value);lookup[(g,a,b)]=value
geometries=sorted({r['geometry_id'] for r in scheduled});complete=[]
for g in geometries:
    for b in points:
        if all((g,a,b) in lookup for a in algorithms):
            vals={a:lookup[g,a,b]['cost'] for a in algorithms};rr=ranks(vals);best=min(vals.values());complete.append((g,b))
            for a in algorithms:lookup[g,a,b].update(rank=rr[a],relative_regret_pct=100*(vals[a]/best-1))
aggregates=[]
for b in points:
    for a in algorithms:
        xx=[v for v in observations if v['algorithm']==a and v['budget']==b]
        iterations=[v['iterations_completed'] for v in xx]
        aggregates.append({'budget':b,'algorithm':a,'available_geometries':len(xx),'zero_completed_rounds':sum(x==0 for x in iterations),
          'mean_completed_rounds':mean(iterations),'min_completed_rounds':min(iterations) if iterations else None,'max_completed_rounds':max(iterations) if iterations else None,
          'improved_vs_baseline_count':sum(x['baseline_gain_pct']>1e-9 for x in xx),'mean_baseline_gain_pct':mean([x['baseline_gain_pct'] for x in xx]),
          'mean_rank':mean([x['rank'] for x in xx if x['rank'] is not None]),'mean_relative_regret_pct':mean([x['relative_regret_pct'] for x in xx if x['relative_regret_pct'] is not None])})
changes=[]
for g in geometries:
    for a in algorithms:
        old=lookup.get((g,a,160000))
        for b in [640000,1280000]:
            new=lookup.get((g,a,b))
            if old and new:
                changes.append({'geometry_id':g,'family':old['family'],'algorithm':a,'from_budget':160000,'to_budget':b,
                  'cost_at160k':old['cost'],'cost_at_higher':new['cost'],'gain_from160k_pct':100*(old['cost']-new['cost'])/old['cost'],
                  'rounds_at160k':old['iterations_completed'],'rounds_at_higher':new['iterations_completed'],
                  'rank_at160k':old['rank'],'rank_at_higher':new['rank'],'rank_change':new['rank']-old['rank'] if old['rank'] is not None and new['rank'] is not None else None})
paired=[]
for g in geometries:
    for b in points:
        rc=lookup.get((g,'random_cheapest',b));rr=lookup.get((g,'random_regret2',b))
        if rc and rr:paired.append({'geometry_id':g,'family':rc['family'],'budget':b,'random_cheapest_cost':rc['cost'],'random_regret2_cost':rr['cost'],'regret2_advantage_pct':100*(rc['cost']-rr['cost'])/rc['cost']})
first_summary=[]
for a in algorithms:
    xx=[x for x in firsts if x['algorithm']==a];observed=[x['first_improvement_delta'] for x in xx if not x['first_improvement_censored']]
    first_summary.append({'algorithm':a,'count':len(xx),'first_improvement_observed':len(observed),'censored':len(xx)-len(observed),'first_improvement_after160k':sum(x['improvement_after_160k'] for x in xx),
      'observed_first_delta_min':min(observed) if observed else None,'observed_first_delta_median':statistics.median(observed) if observed else None,'observed_first_delta_max':max(observed) if observed else None,
      'observed_only_warning':'Conditional on improvement by attained budget; censored trajectories retained separately.'})
rank_changes=[]
for g in geometries:
    if all((g,b) in complete for b in points):
        rr={b:{a:lookup[g,a,b]['rank'] for a in algorithms} for b in points}
        rank_changes.append({'geometry_id':g,'ranks_changed_160k_to640k':rr[160000]!=rr[640000],'ranks_changed_160k_to1280k':rr[160000]!=rr[1280000],
          'winners160k':';'.join(a for a in algorithms if rr[160000][a]==min(rr[160000].values())),
          'winners1280k':';'.join(a for a in algorithms if rr[1280000][a]==min(rr[1280000].values()))})
validation={'independent_outputs_checked':len(audits),'independent_routes_checked':sum(len(x['route_details']) for x in audits),'all_independent_outputs_passed':all(x['passed'] for x in audits),
  'all_monotonicity_and_ledger_checks':all(x['monotonicity'] and x['ledger'] for x in checks),
  'exact_reproduction_all_passed':all(all(x[k] for k in ['exact_checkpoint_except_timing','exact_baseline','exact_baseline_check','exact_completed_trace']) for x in replications),
  'exact_reproduction_checkpoint_count':len(replications),'main_checkpoint_count':len(observations),'failure_count':len(failures)}
summary={'study':'8 reused n200 geometries, constant5, seed75101, descriptive budget reproduction only','validation':validation,'aggregates':aggregates,'first_improvement':first_summary,
  'paired_regret2_advantage_mean_pct':{str(b):mean([x['regret2_advantage_pct'] for x in paired if x['budget']==b]) for b in points},
  'paired_geometry_count':{str(b):len([x for x in paired if x['budget']==b]) for b in points},
  'geometries_with_rank_change160k_to1280k':sum(x['ranks_changed_160k_to1280k'] for x in rank_changes),
  'no_pvalues_or_population_claims':True,'no_new_independent_geometries':True}
dump(ROOT/'reports/INDEPENDENT_ROUTE_AUDIT.json',audits);dump(ROOT/'reports/LEDGER_MONOTONICITY.json',checks)
dump(ROOT/'reports/EXACT_REPRODUCTION.json',replications);dump(ROOT/'reports/SUMMARY.json',summary)
dump(ROOT/'reports/FAILURE_COMPLETENESS.json',{'planned':32,'written':len(ids),'rows':failures})
csvwrite('checkpoint_observations.csv',observations);csvwrite('aggregate_by_budget.csv',aggregates);csvwrite('first_improvement.csv',firsts);csvwrite('first_improvement_summary.csv',first_summary)
csvwrite('paired_budget_changes.csv',changes);csvwrite('paired_regret2_contrast.csv',paired);csvwrite('geometry_rank_changes.csv',rank_changes)
lines=['# n200：更充分预算能否解除搜索饥饿？','',
'这是同8个既有几何、constant5、seed75101的预算复现实验：32轨迹，160k/640k/1.28M为相关检查点。没有新增独立样本，也不对其他需求、种子或真实业务数据做推广。','',
'## 核心数值','',
'|算子|预算|完成轮数均值（范围）|零轮几何|改善基线几何|平均基线改善%|平均名次|','|---|---:|---:|---:|---:|---:|---:|']
for x in aggregates:
    lines.append(f"|{x['algorithm']}|{x['budget']}|{x['mean_completed_rounds']:.3f}（{x['min_completed_rounds']}–{x['max_completed_rounds']}）|{x['zero_completed_rounds']}/{x['available_geometries']}|{x['improved_vs_baseline_count']}/{x['available_geometries']}|{x['mean_baseline_gain_pct']:.6f}|{x['mean_rank']:.4f}|")
lines+=['','## 160k后真正新增的改善','']
for a in algorithms:
    xx=[x for x in changes if x['algorithm']==a and x['to_budget']==1280000]
    lines.append(f"- {a}：{sum(x['gain_from160k_pct']>1e-9 for x in xx)}/{len(xx)}个几何继续改善；配对平均降成本{mean([x['gain_from160k_pct'] for x in xx]):.6f}%。")
lines+=['','## 首次改进与排序','']
for x in first_summary:
    lines.append(f"- {x['algorithm']}：首次改进可见{x['first_improvement_observed']}/8，未改进右删失{x['censored']}/8；首次发生在160k之后{x['first_improvement_after160k']}/8；已观察首次改进delta范围{x['observed_first_delta_min']}–{x['observed_first_delta_max']}（仅已观察者，不代表删失者）。")
lines.append('- random_regret2相对random_cheapest的配对平均优势（正数更好）：'+ '；'.join(f"{b}: {summary['paired_regret2_advantage_mean_pct'][str(b)]:.6f}%" for b in points)+'。')
lines.append(f"- 160k至1.28M有{summary['geometries_with_rank_change160k_to1280k']}/{len(rank_changes)}个几何的四算子名次发生变化（包括并列关系改变）。")
lines+=['','## 审计与边界','',
f"- 独立从原始坐标验算{validation['independent_outputs_checked']}个基线/检查点输出、{validation['independent_routes_checked']}条车路线；覆盖、容量与目标全部通过：{validation['all_independent_outputs_passed']}。",
f"- 40k与160k合计{len(replications)}个检查点，去除CPU与墙钟字段后与原轨迹严格相等，连同基线及完成轮trace全部复现：{validation['exact_reproduction_all_passed']}。",
f"- 所有检查点初始化固定19900 savings delta、总ledger、40401矩阵距离及目标单调性通过：{validation['all_monotonicity_and_ledger_checks']}。失败/缺失轨迹数{len(failures)}。",
'- 更充分仅相对160k：1.28M不证明收敛。完成轮数与改善并非同一件事；足够多轮仍不改善可能来自算子/接受准则，不等于所有更高预算都无效。',
'- 观察到预算扩充后可完成轮数，能检验“此前没跑完一轮”的混杂；不能仅凭本8几何/1需求/1种子断言规模退化已被证伪或算子总体胜出。',
'- 没有假设检验、置信区间或独立样本扩增。CPU实测及上界见RESOURCE_ACCOUNTING.json，逐阶段侧录见raw/*_RESOURCE.json。',
'- 源码、输入、冻结协议、原始轨迹、失败记录、原复现参考、逐路线验算全部入档。无外部服务、API、模型调用、付费或依赖安装。','']
(ROOT/'reports/REPORT_ZH.md').write_text('\n'.join(lines),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,allow_nan=False))
if not all(validation[k] for k in ['all_independent_outputs_passed','all_monotonicity_and_ledger_checks','exact_reproduction_all_passed']):raise SystemExit('validation failed')
