"""Metadata-only selection, feasibility estimate and pre-run freeze. No solver run."""
from pathlib import Path
import datetime,hashlib,json,random,resource,shutil,time
ROOT=Path(__file__).resolve().parents[1]
OLD=Path('/workspace/shared/cvrp_scale_20261007')
resource.setrlimit(resource.RLIMIT_CPU,(8,8))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def dump(p,d):
    with p.open('x') as f:json.dump(d,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
oldcfg=read(OLD/'freeze/PROTOCOL.json')
seed=min(oldcfg['search_seeds'])
selected=[x for x in read(OLD/'freeze/INPUT_MANIFEST.json') if x['n']==200 and x['demand_mode']=='constant5']
selected.sort(key=lambda x:x['geometry_id'])
assert len(selected)==8 and len({x['geometry_id'] for x in selected})==8
assert {x['family'] for x in selected}=={'uniform','clustered'}
for x in selected:
    p=OLD/x['input_file'];assert sha(p)==x['input_sha256'];shutil.copyfile(p,ROOT/x['input_file'])
original_rows=[json.loads(x) for x in (OLD/'raw/TRAJECTORIES.jsonl').read_text().splitlines()]
oldrows=[x for x in original_rows if x['n']==200 and x['demand_mode']=='constant5' and x['search_seed']==seed]
assert len(oldrows)==32
with (ROOT/'input/prior_selected_trajectories.jsonl').open('x') as f:
    for r in oldrows:f.write(json.dumps(r,ensure_ascii=False,allow_nan=False)+'\n')
shutil.copyfile(OLD/'freeze/PROTOCOL.json',ROOT/'input/original_protocol.json')
schedule=[]
for x in selected:
    for pair in oldcfg['pairs']:
        ref=next(r for r in oldrows if r['geometry_id']==x['geometry_id'] and r['pair']==pair)
        schedule.append({**x,'search_seed':seed,'algorithm':'_'.join(pair),'pair':pair,'original_run_id':ref['run_id']})
random.Random(202610076199).shuffle(schedule)
for i,x in enumerate(schedule):x['run_id']=i
cfg={'name':'CVRP n200 budget-starvation reproduction 20261007',
'created_utc':utc(),'study_type':'exploratory paired budget reproduction, not new independent geometries',
'selection_rule':'All existing n200 geometries, constant5 demand, numerically smallest original search seed, all four original operators. Fixed using metadata; no filtering by outcomes.',
'geometry_count':8,'demand_mode':'constant5','search_seeds':[seed],'pairs':oldcfg['pairs'],
'checkpoints':[40000,160000,640000,1280000],'report_checkpoints':[160000,640000,1280000],
'auxiliary_checkpoint':40000,'formal_trajectories':32,'schedule_seed':202610076199,
'source_policy':'budget_engine.py, run.py and all legacy source byte-identical to old study; no changes to operators, RNG, stopping or acceptance semantics.',
'initialization_rule':'Each rerun pays matrix setup and 19900 savings deltas inside its own budget. Savings+removal+insertion delta ledger unchanged. Matrix, objective edges and feasibility excluded from deltas but separately tracked.',
'checkpoint_rule':'Correlated checkpoints on each 1.28M trajectory. Original 40k checkpoint retained so all original non-timing diagnostics reproduce exactly; main analysis is 160k/640k/1.28M.',
'primary_question':'Does higher delta budget resolve zero completed rounds, reveal later first improvements, and change quality/rank on the fixed 8 n200 geometries?',
'analysis_plan':{'unit':'8 paired geometries, uniform4 and clustered4; one demand and one shared seed. 32 trajectories and 96 main checkpoints are not independent sample counts.',
'metrics':['completed iterations by checkpoint','number with zero completed iterations','exact first completed iteration delta','exact first strict accepted improvement delta or right censoring','baseline-relative percent cost gain','paired 160k-to-higher-budget percent cost gain','geometry-level midranks with absolute 1e-9 ties','mean rank and within-four relative regret','paired random_cheapest minus random_regret2 percent contrast, positive favors regret2'],
'aggregation':'Equal weights across8 geometries; family breakdown descriptive only. Report individual geometry rows. No hypothesis tests, confidence intervals or broad generalization.',
'rank':'Per-geometry rank by incumbent objective at fixed budget; average tied ranks. Mean across complete geometry blocks. No cross-budget winner redefinition within a comparison.',
'first_improvement':'First trace entry with accepted=true; deltas include paid initialization. If none by attained budget, right-censored; never substitute zero or drop it.',
'failure':'No reruns, replacements, result-based exclusions or imputation. Preserve every32 planned rows including missing budgets. Summary columns state available count. All-4-method comparison requires matched complete geometry blocks at compared budgets.',
'legacy_replication':'At160k, compare every checkpoint field except solver_cpu_seconds and solver_wall_seconds, full baseline and checker, and all completed trace entries through160k. Auxiliary40k checked likewise.',
'independent_validation':'Every baseline and checkpoint output independently recomputed directly from coordinates without importing solver or its checker: customer coverage exactly once, depot endpoints, capacity, finite objective, reported objective agreement. Save per-route loads and costs. Check monotonicity, savings19900, ledger sum, 40401 matrix distances.'},
'per_trajectory_cpu_limit':4.0,'per_trajectory_wall_limit':30.0,
'process_cpu_soft_gate':140.0,'process_cpu_hard_limit':146,'return_reserve_cpu':4.0,'execution_wall_limit':600.0,
'experiment_cpu_hard_ceiling':180.0,
'resource_plan':'Sequential prepare hard8, solver hard147 inclusive grace, analysis hard10, finalize hard5; supervisor hard2. Sum hard upper bounds172 CPU seconds. Reserve8 for setup and bounded read-only inspection. No children from stages. Any failed/timeout stage retained; no reruns.',
'phase_cpu_hard_limits':{'prepare':8,'run':147,'analyze':10,'finalize':5},'supervisor_cpu_hard_limit':2,
'setup_and_inspection_allowance_cpu_seconds':8.0,'no_new_independent_geometry_samples':True,
'external_api_calls':0,'model_calls':0,'paid_calls':0,'network_calls':0,'new_dependencies':0,'external_uploads':0}
dump(ROOT/'freeze/PROTOCOL.json',cfg)
dump(ROOT/'freeze/INPUT_MANIFEST.json',selected)
dump(ROOT/'freeze/SCHEDULE.json',schedule)
oldsource={str(p.relative_to(OLD)):sha(p) for p in (OLD/'source').rglob('*.py') if p.name in ['budget_engine.py','run.py'] or 'legacy' in p.parts}
assert all(sha(ROOT/p)==h for p,h in oldsource.items())
dump(ROOT/'freeze/SOURCE_PROVENANCE.json',{'old_root':str(OLD),'byte_identical_files':oldsource,'input_geometry_reuse':True,'legacy_result_sha256':sha(OLD/'raw/TRAJECTORIES.jsonl')})
dump(ROOT/'freeze/OLD_DIRECTORY_HASHES.json',{str(p.relative_to(OLD)):sha(p) for p in OLD.rglob('*') if p.is_file()})
times=[r['solver_cpu_seconds'] for r in oldrows]
dump(ROOT/'freeze/FEASIBILITY.json',{'utc':utc(),'selection':'fixed by metadata before inspecting timing','old32_solver_cpu_total':sum(times),'old32_solver_cpu_max':max(times),'linear8x_total_estimate':8*sum(times),'linear8x_max_estimate':8*max(times),'estimate_limit':'Not a runtime guarantee. No new pilot solver run, no change to selected sample after estimate.','available_solver_hard_limit':147})
(ROOT/'freeze/PROTOCOL_ZH.md').write_text('''# 冻结协议：n200预算饥饿复现实验

全部8个既有n200几何 × constant5 × 原最小seed75101 × 4原算子 = 32条预算复现轨迹。不是新几何样本，禁止按旧或新结果筛选。

主检查点160k、640k、1.28M，保留40k仅作原诊断字段严格复现。原引擎、算子与运行器逐字节不改；每轨迹初始化收取19900 savings delta，其他计费口径完全不变。

先冻结输入哈希、选样、顺序、源码和本分析程序，再启动任何新求解。主要观察完成轮数、首轮与首次严格改进的精确delta、真实目标下降及几何内算子名次。所有统计只描述8个配对几何，一个需求、一个种子；没有显著性检验或推广至n200总体的声明。

每个基线和检查点均以独立代码直接从坐标验覆盖、容量、目标，并记录每条车路线。160k原数值和路线（除CPU/墙钟）必须逐字段精确一致。无改进按右删失记录，不冒充零预算，也不剔除。CPU或墙钟超限、不完整检查点及未运行均保留，无补跑与替换。

总CPU硬上限180秒：prepare8、solver147（含软硬信号宽限）、analyze10、finalize5、监督器2秒，各阶段无子进程；合计172秒，另预留8秒前期设置和只读检查。旧32条160k求解合计4.65秒，线性8倍估算37.24秒，仅用于可行性，不保证实测。单轨迹CPU4秒；若超限照实保留。无外部API、模型、付费调用和新依赖。
''',encoding='utf-8')
files=[p for base in ['source','input','freeze'] for p in (ROOT/base).rglob('*') if p.is_file()]
dump(ROOT/'freeze/PRE_RUN_FREEZE.json',{'utc':utc(),'all_new_solver_runs_started':False,'sha256':{str(p.relative_to(ROOT)):sha(p) for p in sorted(files)}})
print(json.dumps({'frozen':True,'geometries':8,'trajectories':32,'estimated_solver_cpu':8*sum(times),'protocol_hash':sha(ROOT/'freeze/PROTOCOL.json')}))
