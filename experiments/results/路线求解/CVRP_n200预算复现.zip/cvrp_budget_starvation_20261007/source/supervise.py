"""Bound all sequential experiment stages and record child CPU independently."""
from pathlib import Path
import datetime,hashlib,json,os,resource,subprocess,sys,time,zipfile
ROOT=Path(__file__).resolve().parents[1]
resource.setrlimit(resource.RLIMIT_CPU,(1,147))  # Default SIGXCPU kills supervisor at1s; hard147 permits child-specific caps. Account conservative2s.
CAPS={'prepare':8,'run':147,'analyze':10,'finalize':5}
assert sum(CAPS.values())+2+8==180
start=time.perf_counter();phases=[]
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def dump(p,d):
    with p.open('x') as f:json.dump(d,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for phase,cap in CAPS.items():
    before=resource.getrusage(resource.RUSAGE_CHILDREN);wall=time.perf_counter()
    def limit():resource.setrlimit(resource.RLIMIT_CPU,(cap,cap))
    with (ROOT/f'raw/{phase.upper()}_STDOUT.txt').open('x') as out,(ROOT/f'raw/{phase.upper()}_STDERR.txt').open('x') as err:
        child=subprocess.Popen([sys.executable,'-B',str(ROOT/f'source/{phase}.py')],stdout=out,stderr=err,start_new_session=True,preexec_fn=limit)
        try:code=child.wait(timeout=660 if phase=='run' else 60);wall_killed=False
        except subprocess.TimeoutExpired:os.killpg(child.pid,9);code=child.wait();wall_killed=True
    after=resource.getrusage(resource.RUSAGE_CHILDREN)
    record={'phase':phase,'utc':utc(),'pid':child.pid,'exit_code':code,'wall_timeout':wall_killed,
      'cpu_hard_limit_seconds':cap,'child_user_cpu_seconds':after.ru_utime-before.ru_utime,'child_system_cpu_seconds':after.ru_stime-before.ru_stime,
      'child_total_cpu_seconds':after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime,
      'wall_seconds':time.perf_counter()-wall,'maxrss_kib':after.ru_maxrss}
    dump(ROOT/f'raw/{phase.upper()}_RESOURCE.json',record);phases.append(record)
    print(json.dumps(record),flush=True)
    if phase=='prepare' and code!=0:raise SystemExit('preparation failed; solver never started')
    # Preserve partial-run analysis after solver termination. Never retry.
if not (ROOT/'failures/FAILURES.json').exists():
    dump(ROOT/'failures/FAILURES.json',{'note':'runner terminated before final failure ledger; see raw stage sidecars and reports/FAILURE_COMPLETENESS.json','retries':0})
actual=sum(x['child_total_cpu_seconds'] for x in phases)
account={'utc':utc(),'phase_records':phases,'measured_stage_cpu_seconds':actual,'supervisor_observed_cpu_before_packaging':time.process_time(),
'supervisor_hard_cpu_upper_bound':2,'setup_and_inspection_allowance_cpu_seconds':8,
'conservative_total_cpu_seconds':actual+2+8,'experiment_cpu_hard_ceiling':180,'sum_stage_hard_cpu_caps_plus_supervisor_and_allowance':180,
'within_ceiling':actual+2+8<=180,'all_stage_exit_codes_zero':all(x['exit_code']==0 for x in phases),'wall_seconds_before_packaging':time.perf_counter()-start,
'accounting_note':'Stage CPU from OS wait/rusage includes user+system. Each stage has an independent CPU hard RLIMIT, no child processes. Supervisor hard-capped2s. Setup/read-only inspection reserved8s is an allowance, not a measured claim.','external_api_calls':0,'model_calls':0,'paid_calls':0,'network_calls':0,'dependency_installations':0,'retries':0}
dump(ROOT/'reports/RESOURCE_ACCOUNTING.json',account)
files=[p for p in ROOT.rglob('*') if p.is_file()]
manifest={'utc':utc(),'file_count':len(files),'files':[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(files)]}
dump(ROOT/'MANIFEST.json',manifest)
files.append(ROOT/'MANIFEST.json')
with (ROOT/'SHA256SUMS.txt').open('x') as f:
    for p in sorted(files):f.write(sha(p)+'  '+str(p.relative_to(ROOT))+'\n')
archive=ROOT.parent/(ROOT.name+'.zip')
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(ROOT.rglob('*')):
        if p.is_file():z.write(p,str(p.relative_to(ROOT.parent)))
proof={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'supervisor_cpu_seconds_at_finish':time.process_time(),'stage_cpu_seconds':actual,'conservative_total_cpu_seconds':actual+2+8,'wall_seconds':time.perf_counter()-start}
with (ROOT.parent/(ROOT.name+'_archive_receipt.json')).open('x') as f:json.dump(proof,f,indent=2)
print(json.dumps(proof),flush=True)
