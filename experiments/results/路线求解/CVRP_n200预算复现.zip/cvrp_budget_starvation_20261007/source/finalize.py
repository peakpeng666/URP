"""Verify immutable evidence and old directory; do not rerun any solver."""
from pathlib import Path
import hashlib,json,resource
ROOT=Path(__file__).resolve().parents[1]
resource.setrlimit(resource.RLIMIT_CPU,(5,5))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def dump(p,d):
    with p.open('x') as f:json.dump(d,f,ensure_ascii=False,indent=2);f.write('\n')
freeze=read(ROOT/'freeze/PRE_RUN_FREEZE.json');bad=[p for p,h in freeze['sha256'].items() if not (ROOT/p).exists() or sha(ROOT/p)!=h]
old=Path('/workspace/shared/cvrp_scale_20261007');oldhash=read(ROOT/'freeze/OLD_DIRECTORY_HASHES.json')
oldbad=[p for p,h in oldhash.items() if not (old/p).exists() or sha(old/p)!=h]
oldadded=[str(p.relative_to(old)) for p in old.rglob('*') if p.is_file() and str(p.relative_to(old)) not in oldhash]
source=read(ROOT/'freeze/SOURCE_PROVENANCE.json')['byte_identical_files'];sourcebad=[p for p,h in source.items() if sha(ROOT/p)!=h]
summary=read(ROOT/'reports/SUMMARY.json') if (ROOT/'reports/SUMMARY.json').exists() else None
r={'frozen_file_count':len(freeze['sha256']),'frozen_hash_mismatches':bad,'old_directory_hash_mismatches':oldbad,'old_directory_new_files':oldadded,
'old_directory_unchanged':not oldbad and not oldadded,'source_byte_identity_mismatches':sourcebad,'summary_present':summary is not None,'all_passed':not bad and not oldbad and not oldadded and not sourcebad and summary is not None}
dump(ROOT/'reports/FINAL_SELF_CHECK.json',r)
(ROOT/'README.md').write_text('''# CVRP n200 budget-starvation reproduction

Start with reports/REPORT_ZH.md (Chinese findings) and reports/SUMMARY.json.

- freeze/: preregistered selection, input and code hashes, original source provenance, CPU feasibility estimate.
- input/: eight reused n200 constant5 geometries and the 32 matching old reference trajectories.
- source/: unchanged original engine/operators/runner plus frozen preparation, analysis and resource supervisor.
- raw/: all32 new rerun trajectories, stdout/stderr and process-tree CPU measurements.
- failures/: every algorithm/runner/resource failure or missing checkpoint, without retries.
- reports/: independent coverage/capacity/objective audit for every route, exact 40k/160k reproduction audit, descriptive paired8-geometry analysis and resource accounting.

These are budget reproductions of existing geometry/seed combinations, not new independent data. Main checkpoints:160k,640k,1.28M;40k is auxiliary exact-reproduction audit only. No externalAPI/model/paid calls or dependency installations.

Source is frozen before the first new solver run. No old files are overwritten. SHA256SUMS.txt and MANIFEST.json cover the completed evidence bundle. The adjacent ZIP is the archive deliverable. Running the scripts in this existing directory is intentionally blocked by exclusive-create outputs; reproduce only in a fresh directory and preserve provenance.
''',encoding='utf-8')
print(json.dumps(r))
if not r['all_passed']:raise SystemExit('self check failed')
