# CVRP n200 budget-starvation reproduction

Start with reports/REPORT_ZH.md (Chinese findings) and reports/SUMMARY.json.

- freeze/: preregistered selection, input and code hashes, original source provenance, CPU feasibility estimate.
- input/: eight reused n200 constant5 geometries and the 32 matching old reference trajectories.
- source/: unchanged original engine/operators/runner plus frozen preparation, analysis and resource supervisor.
- raw/: all32 new rerun trajectories, stdout/stderr and process-tree CPU measurements.
- failures/: every algorithm/runner/resource failure or missing checkpoint, without retries.
- reports/: independent coverage/capacity/objective audit for every route, exact 40k/160k reproduction audit, descriptive paired8-geometry analysis and resource accounting.

These are budget reproductions of existing geometry/seed combinations, not new independent data. Main checkpoints:160k,640k,1.28M;40k is auxiliary exact-reproduction audit only. No externalAPI/model/paid calls or dependency installations.

Source is frozen before the first new solver run. No old files are overwritten. SHA256SUMS.txt and MANIFEST.json cover the completed evidence bundle. The adjacent ZIP is the archive deliverable. Running the scripts in this existing directory is intentionally blocked by exclusive-create outputs; reproduce only in a fresh directory and preserve provenance.
