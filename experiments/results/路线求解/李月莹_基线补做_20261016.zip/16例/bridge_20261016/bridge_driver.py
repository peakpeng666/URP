"""Run a separate 48-call batch using the archived r1 worker and call wrapper."""
import hashlib
import json
import os
import signal
import sys
import time
from pathlib import Path

from common import ROOT, append, now, read, save, sha
from run_once import configure_supervisor_limits, execute_call


def main():
    schedule = read("freeze/SCHEDULE.json")
    assert len(schedule) == 48
    assert len({entry["call_id"] for entry in schedule}) == 48
    assert all(entry["seed"] in (0, 1, 2) and entry["max_runtime_seconds"] == 1.0 for entry in schedule)
    frozen = read("freeze/FROZEN_FILES.json")["files"]
    checked = {}
    for relative, meta in frozen.items():
        if relative.startswith(("source/", "input/", "freeze/SCHEDULE.json")):
            actual = ROOT / relative
            assert actual.stat().st_size == meta["bytes"] and sha(actual) == meta["sha256"], relative
            checked[relative] = meta["sha256"]
    assert sum(path.startswith("input/") for path in checked) == 32
    assert "source/worker.py" in checked and "source/run_once.py" in checked
    limits = configure_supervisor_limits()
    signal.alarm(600)
    raw = ROOT / "raw"
    calls = raw / "calls"
    calls.mkdir(parents=True, exist_ok=False)
    save(raw / "STARTED.json", {
        "utc": now(), "batch_id": "bridge_20261016", "calls": len(schedule),
        "source_and_input_sha256": checked, "schedule_sha256": sha(ROOT / "freeze/SCHEDULE.json"),
        "python": sys.executable, "supervisor_limits": limits,
        "protocol": "Archived r1 source and inputs; seeds 0,1,2; PyVRP 0.14.0 default ILS; MaxRuntime(1.0) in search loop; each call fresh worker; no retries",
    })
    started = time.monotonic()
    for index, entry in enumerate(schedule, 1):
        data = read(f"input/{entry['instance_id']}.json")
        assert set(data) == {"instance_id", "coordinates", "demands", "capacity", "K"}
        payload = {key: data[key] for key in ("coordinates", "demands", "capacity", "K")}
        payload.update(seed=entry["seed"], max_runtime_seconds=entry["max_runtime_seconds"])
        append(raw / "attempts.jsonl", {"phase": "STARTED", "utc": now(), **entry})
        item = execute_call(entry, payload, sys.executable, calls)
        append(raw / "results.jsonl", item)
        append(raw / "attempts.jsonl", {"phase": "FINISHED", "utc": now(), **item})
        print(f"{index}/48 {item['call_id']} {item['status']} {item['wall_seconds_audit_only']:.3f}s", flush=True)
    signal.alarm(0)
    save(raw / "FINISHED.json", {"utc": now(), "batch_id": "bridge_20261016", "calls": len(schedule),
                                 "wall_seconds_audit_only": time.monotonic() - started,
                                 "results_sha256": sha(raw / "results.jsonl")})


if __name__ == "__main__":
    main()
