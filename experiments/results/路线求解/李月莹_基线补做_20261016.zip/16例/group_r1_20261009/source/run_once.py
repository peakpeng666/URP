"""R1 single-use supervisor. One shared bounded launch path for production and invented integration tests."""
import os,sys,json,time,resource,signal,subprocess,traceback,hashlib
from pathlib import Path
from common import ROOT,now,sha,read,save,append,verify_frozen,verify_old,receipt,verify_prior_failed

def child_environment():
    return {'PATH':'/usr/local/bin:/usr/bin:/bin','HOME':'/tmp','LANG':'C.UTF-8','LC_ALL':'C.UTF-8',
            'PYTHONDONTWRITEBYTECODE':'1','PYTHONHASHSEED':'0','PYTHONNOUSERSITE':'1',
            'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1',
            'NUMEXPR_NUM_THREADS':'1','VECLIB_MAXIMUM_THREADS':'1'}

def configure_supervisor_limits():
    if not __debug__:raise RuntimeError('Assertions must be enabled')
    resource.setrlimit(resource.RLIMIT_CPU,(20,20))
    # Soft512 contains supervisor use; hard1024 permits the child budget it inherits.
    resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,1024*1024**2))
    return {'AS_bytes':list(resource.getrlimit(resource.RLIMIT_AS)),
            'CPU_seconds':list(resource.getrlimit(resource.RLIMIT_CPU))}

def execute_call(entry,payload,python,output_dir,worker_script=None):
    """The identical production Popen/communicate/cleanup path used by integration fixtures."""
    worker_script=Path(worker_script) if worker_script else ROOT/'source/worker.py'
    cid=entry['call_id'];out=output_dir/f'{cid}.stdout';err=output_dir/f'{cid}.stderr'
    encoded=json.dumps(payload,separators=(',',':')).encode()
    item={**entry,'status':'UNREVIEWED_PROCESS_SUCCESS','returncode':None,
          'stdout':str(out.relative_to(ROOT)),'stderr':str(err.relative_to(ROOT)),
          'payload_sha256':hashlib.sha256(encoded).hexdigest(),'process_spawned':False}
    started=time.monotonic();use=resource.getrusage(resource.RUSAGE_CHILDREN);before=use.ru_utime+use.ru_stime
    p=None
    try:
        with out.open('xb') as fo,err.open('xb') as fe:
            p=subprocess.Popen([python,'-B',str(worker_script)],stdin=subprocess.PIPE,
                               stdout=fo,stderr=fe,env=child_environment(),cwd=output_dir)
            item['process_spawned']=True
            try:p.communicate(encoded,timeout=10)
            except subprocess.TimeoutExpired:
                p.kill();p.communicate();item['status']='WALL_TIMEOUT'
            item['returncode']=p.returncode
            if p.returncode and item['status']=='UNREVIEWED_PROCESS_SUCCESS':item['status']='PROCESS_FAILURE_OR_CPU_LIMIT'
        if item['status']=='UNREVIEWED_PROCESS_SUCCESS':
            answer=json.loads(out.read_text())
            assert answer['seed']==entry['seed'] and answer['version']=='0.14.0'
            assert answer['max_runtime_seconds']==entry['max_runtime_seconds']
            assert answer['denied_io_events']==[] and answer['reference_or_history_payload_fields']==[]
            if not answer['solver_is_feasible']:item['status']='UNREVIEWED_INFEASIBLE'
    except Exception as exc:
        item.update(status='CALL_ERROR_UNDETERMINED',error=str(exc),traceback=traceback.format_exc())
    finally:
        if p is not None:
            if p.poll() is None:p.kill()
            p.wait()
    use=resource.getrusage(resource.RUSAGE_CHILDREN)
    item.update(cpu_seconds_audit_only=use.ru_utime+use.ru_stime-before,
                wall_seconds_audit_only=time.monotonic()-started,
                child_reaped=p is None or p.poll() is not None)
    for label,file in [('stdout',out),('stderr',err)]:
        if file.exists():item[label+'_sha256']=sha(file)
    return item

def main():
    limits=configure_supervisor_limits()
    if sys.argv[1:]==['--synthetic-integration']:
        from synthetic_integration import run_in_limited_supervisor
        return run_in_limited_supervisor(limits)
    if sys.argv[1:]==['--synthetic-full-budget']:
        from synthetic_full_budget import run_in_limited_supervisor
        return run_in_limited_supervisor(limits)
    assert not sys.argv[1:], 'Only the explicit fixed synthetic test modes are supported'
    signal.alarm(600)
    wall,cpu=time.monotonic(),time.process_time()
    freeze_hash=verify_frozen();verify_old();verify_prior_failed();r=receipt('PREEXEC')
    assert read('freeze/INDEPENDENT_PRECHECK.json')['status']=='PASS'
    approval=read('provenance/PARENT_EXECUTION_APPROVAL.json')
    assert approval['approved'] is True and approval['frozen_files_sha256']==freeze_hash
    assert approval['preexec_archive_sha256']==r['sha256']
    assert approval['scope']=='one frozen 48-call PyVRP r1 benchmark; no retry'
    env=read('environment/RUNTIME.json');python=env['python_executable']
    assert Path(python).is_file() and sha(Path(python).resolve())==env['python_binary_sha256']
    for file in env['installed_distribution_files']:
        p=Path(file['path']);assert p.stat().st_size==file['bytes'] and sha(p)==file['sha256'],str(p)
    schedule=read('freeze/SCHEDULE.json');assert len(schedule)==48 and len({e['call_id'] for e in schedule})==48
    assert all(e['seed'] in (0,1,2) and e['max_runtime_seconds']==1.0 for e in schedule)
    save(ROOT/'raw/STARTED.json',{'utc':now(),'freeze_sha256':freeze_hash,'approval_sha256':sha(ROOT/'provenance/PARENT_EXECUTION_APPROVAL.json'),'preexec_receipt_sha256':sha(ROOT/'provenance/PREEXEC_DRIVE_RECEIPT.json'),'planned_calls':48,'no_retries':True,'supervisor_limits':limits})
    output_dir=ROOT/'raw/calls';output_dir.mkdir(exist_ok=False);results=[]
    for entry in schedule:
        data=read(f"input/{entry['instance_id']}.json")
        assert set(data)=={'instance_id','coordinates','demands','capacity','K'}
        payload={k:data[k] for k in ('coordinates','demands','capacity','K')}
        payload.update(seed=entry['seed'],max_runtime_seconds=entry['max_runtime_seconds'])
        append(ROOT/'raw/attempts.jsonl',{'phase':'STARTED','utc':now(),**entry})
        item=execute_call(entry,payload,python,output_dir)
        append(ROOT/'raw/results.jsonl',item);append(ROOT/'raw/attempts.jsonl',{'phase':'FINISHED','utc':now(),**item});results.append(item)
    signal.alarm(0)
    save(ROOT/'raw/FINISHED.json',{'utc':now(),'status':'COMPLETED_UNREVIEWED','planned_calls':48,'retained_calls':len(results),'spawned_calls':sum(r['process_spawned'] for r in results),'wall_seconds_audit_only':time.monotonic()-wall,'supervisor_cpu_seconds_audit_only':time.process_time()-cpu,'supervisor_maxrss_KiB_audit_only':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'supervisor_effective_limits':limits,'old_files_verified_unchanged':verify_old(),'prior_failed_files_verified_unchanged':verify_prior_failed(),'freeze_sha256_after':verify_frozen()})
if __name__=='__main__':main()
