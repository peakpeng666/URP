"""Saved-only tests: replay the one existing toy and retain the frozen 12 slots."""
import ast
import copy
import json
from pathlib import Path
import sys
import audit_saved_adapter as a

ROOT = Path(__file__).resolve().parents[2]


def main():
    toy = a.read(ROOT/'selftests/SUPERVISOR_INTEGRATION.json')
    problem = toy['fixture']
    ans = a.read(ROOT/toy['record']['stdout'])
    checks = {}
    def check_answer(output):
        return a.audit_answer(problem, problem['reference_routes'], 12, 1, output)['valid']
    checks['same_saved_toy_passes'] = check_answer(ans)
    for name, output in [('missing', None), ('nonobject', []), ('malformed_scalar', 7)]:
        checks[name+'_is_failed'] = not check_answer(output)
    for key, value in [('native_solution_constructions', '1'), ('native_route_constructions', 2),
                       ('optimization_calls', True), ('status', 'OTHER')]:
        changed = copy.deepcopy(ans); changed[key] = value
        checks['changed_'+key+'_is_failed'] = not check_answer(changed)
    changed = copy.deepcopy(ans)
    changed['native_routes'][0]['activities'][1]['idx'] = 1
    checks['wrong_client_index_is_failed'] = not check_answer(changed)
    changed = copy.deepcopy(ans)
    changed['native_observations']['objective_cost'] = 13
    checks['wrong_native_cost_is_failed'] = not check_answer(changed)
    # Empty production raw is read only. This does not create or call a model.
    rows, ledger = a.collect(ROOT)
    checks['empty_raw_retains_12_slots'] = len(rows) == 12 and all(not x['valid'] for x in rows)
    checks['all_12_reference_costs_known'] = all(type(x['reference_cost']) is int for x in rows)
    checks['missing_counts_remain_unknown'] = all(x['actual_output_solution_constructions'] is None
                                                 and x['actual_output_optimization_calls'] is None for x in rows)
    schedule = a.read(ROOT/'freeze/SCHEDULE.json')
    bad, _ = a.audit_ledger(schedule, [{'call_id': []}], [{'call_id': {}}])
    checks['bad_ledger_ids_fail_without_throwing'] = bad['status'] == 'INCOMPLETE_OR_INVALID' and len(bad['calls']) == 12
    checks['no_pyvrp_imported'] = not any(k == 'pyvrp' or k.startswith('pyvrp.') for k in sys.modules)
    for path in Path(__file__).parent.glob('*.py'):
        ast.parse(path.read_text())
    output = dict(status='PASS' if all(checks.values()) else 'FAIL', checks=checks,
                  scope='Same one saved toy, fixed frozen input arithmetic, and missing/bad saved records only.',
                  additional_native_constructions=0, additional_optimization_calls=0,
                  missing_raw_replay=[{k:r[k] for k in ('call_id', 'instance_id', 'K_ref', 'reference_cost', 'valid',
                                      'actual_output_solution_constructions', 'actual_output_optimization_calls')} for r in rows],
                  source_sha256={p.name:a.sha(p) for p in sorted(Path(__file__).parent.glob('*.py'))})
    dest = ROOT/'independent_supervision/selftests/SAVED_AUDIT_REPLAY.json'
    dest.parent.mkdir(parents=True, exist_ok=True)
    with dest.open('x') as f:
        json.dump(output, f, indent=2); f.write('\n')
    print(json.dumps(output))
    assert output['status'] == 'PASS'


if __name__ == '__main__':
    main()
