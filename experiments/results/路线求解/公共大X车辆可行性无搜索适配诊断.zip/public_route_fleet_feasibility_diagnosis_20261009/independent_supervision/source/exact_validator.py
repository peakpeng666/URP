"""Independent standard-library CVRP audit with integer-exact EUC_2D rounding."""
import math,json,hashlib
from collections import Counter

def parse_vrp(text):
    headers={};coords={};demands={};depots=[];section=None
    for raw in text.splitlines():
        line=raw.strip()
        if not line:continue
        if line=='EOF':break
        if line in ('NODE_COORD_SECTION','DEMAND_SECTION','DEPOT_SECTION'):section=line;continue
        if section is None:
            if ':'in line:k,v=line.split(':',1);headers[k.strip()]=v.strip()
        elif section=='NODE_COORD_SECTION':
            a=line.split();assert len(a)==3;i,x,y=map(int,a);assert i not in coords;coords[i]=[x,y]
        elif section=='DEMAND_SECTION':
            i,d=map(int,line.split());assert i not in demands;demands[i]=d
        elif section=='DEPOT_SECTION':depots.extend(map(int,line.split()))
    n=int(headers['DIMENSION']);assert headers['EDGE_WEIGHT_TYPE']=='EUC_2D';assert headers['TYPE']=='CVRP'
    assert sorted(coords)==sorted(demands)==list(range(1,n+1));assert depots==[1,-1]
    assert demands[1]==0 and all(d>=0 for d in demands.values())
    return {'coordinates':[coords[i]for i in range(1,n+1)],'demands':[demands[i]for i in range(1,n+1)],'capacity':int(headers['CAPACITY'])}

def parse_sol(text):
    routes=[];cost=None
    for raw in text.splitlines():
        line=raw.strip()
        if not line:continue
        if line.startswith('Route #'):
            title,visits=line.split(':',1);assert int(title.split('#')[1])==len(routes)+1
            r=list(map(int,visits.split()));assert r;routes.append([0,*r,0])
        elif line.lower().startswith('cost '):assert cost is None;cost=int(line.split()[1])
        else:raise ValueError('Unknown SOL line')
    assert routes and type(cost)is int
    return routes,cost

def edge(a,b):
    assert all(type(x)is int for x in [*a,*b])
    sq=(a[0]-b[0])**2+(a[1]-b[1])**2;r=math.isqrt(sq)
    # floor(sqrt(sq)+1/2), exact integer comparison, ties round upwards.
    return r+int(4*sq>=(2*r+1)**2)

def validate(problem,routes,cost,K):
    errors=[];n=len(problem['demands'])-1;q=problem['capacity'];loads=[];costs=[];seen=[]
    if len(routes)!=K:errors.append('ROUTE_COUNT_NOT_K_REF')
    for i,r in enumerate(routes):
        if not(len(r)>=3 and r[0]==r[-1]==0 and all(type(j)is int and 1<=j<=n for j in r[1:-1])):
            errors.append(f'BAD_ROUTE_{i}');continue
        seen.extend(r[1:-1]);load=sum(problem['demands'][j]for j in r);loads.append(load)
        if load>q:errors.append(f'CAPACITY_{i}')
        costs.append(sum(edge(problem['coordinates'][a],problem['coordinates'][b])for a,b in zip(r,r[1:])))
    if Counter(seen)!=Counter(range(1,n+1)):errors.append('COVERAGE')
    total=sum(costs)
    if total!=cost:errors.append('COST_MISMATCH')
    matrix=[[edge(a,b)for b in problem['coordinates']]for a in problem['coordinates']]
    h=hashlib.sha256(json.dumps(matrix,separators=(',',':')).encode()).hexdigest()
    return {'valid':not errors,'errors':errors,'metric':'TSPLIB_EUC_2D_integer_isqrt_exact_half_up','route_loads':loads,'route_costs':costs,'cost':total,'K_ref':K,'n_customers':n,'matrix_sha256':h,'arithmetic':'s=dx²+dy²; r=isqrt(s); rounded=r+int(4*s>=(2*r+1)²)'}
