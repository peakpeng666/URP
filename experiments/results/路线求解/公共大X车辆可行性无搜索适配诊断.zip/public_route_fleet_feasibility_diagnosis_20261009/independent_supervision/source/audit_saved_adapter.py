"""Independent, standard-library-only saved-evidence audit. Never imports PyVRP.

Run only after the RAW archive's private byte-readback receipt exists. Failed or
missing slots remain in the fixed denominator. Archive/integrity errors are
separate from mathematical witness feasibility. No subprocess or native calls.
"""
import collections
import datetime
import hashlib
import json
import math
from pathlib import Path
import resource
import signal
import zipfile

from exact_validator import parse_vrp, parse_sol, validate

ROOT = Path(__file__).resolve().parents[2]
BASE_NAME = 'public_route_fleet_budget_interaction_20261009'
LIMITS = {'inherited': {'AS_bytes': [512*1024**2, 1536*1024**2], 'CPU_seconds': [30, 30]},
          'effective': {'AS_bytes': [1536*1024**2, 1536*1024**2], 'CPU_seconds': [15, 15]}}
CHECK_KEYS = {'native_feasible', 'native_complete', 'all_customers', 'route_count_equals_K_ref',
              'zero_violations', 'exact_route_order_roundtrip', 'objective_matches_reference',
              'only_distance_objective', 'route_loads_match', 'route_capacity'}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def exact_equal(a, b):
    """Require matching scalar types, except integer coordinates saved as floats."""
    if isinstance(a, dict) and isinstance(b, dict):
        return a.keys() == b.keys() and all(exact_equal(a[k], b[k]) for k in a)
    if isinstance(a, list) and isinstance(b, list):
        return len(a) == len(b) and all(exact_equal(x, y) for x, y in zip(a, b))
    return type(a) is type(b) and a == b


def expected_model(problem, K):
    u = 2**63 - 1
    vehicle = dict(capacity=[problem['capacity']], num_available=K, start_depot=0,
                   end_depot=0, fixed_cost=0, unit_distance_cost=1, unit_duration_cost=0,
                   unit_overtime_cost=0, initial_load=[0], reload_depots=[], max_reloads=0,
                   max_trips=1, max_overtime=0, max_distance=u, max_duration=u,
                   shift_duration=u, start_late=u, tw_early=0, tw_late=u, profile=0)
    clients = [dict(location=i, delivery=[d], pickup=[0], service_duration=0,
                    prize=0, required=True, release_time=0, tw_early=0, tw_late=u, group=None)
               for i, d in enumerate(problem['demands']) if i]
    n = len(clients)
    return dict(locations=[dict(x=float(x), y=float(y)) for x, y in problem['coordinates']],
                num_vehicle_types=1, num_profiles=1, num_groups=0, vehicle=vehicle,
                clients=clients, depot=dict(location=0, service_duration=0, tw_early=0, tw_late=u),
                num_locations=n+1, num_clients=n, num_depots=1, num_vehicles=K,
                num_shipments=0, duration_matrix_all_zero=True)


def audit_answer(problem, reference, cost, K, answer, baseline=None, exact=None):
    errors = []
    exact = exact or validate(problem, reference, cost, K)
    def check(ok, name):
        if not ok:
            errors.append(name)
    if not isinstance(answer, dict):
        return dict(valid=False, status='MISSING_OR_MALFORMED_OUTPUT',
                    errors=['MISSING_OR_MALFORMED_OUTPUT'], independent_validation=exact)
    try:
        check(exact['valid'], 'INVALID_SOURCE_WITNESS')
        expected = dict(status='ADAPTER_CONSTRUCTION_OBSERVED', version='0.14.0', seed=None,
                        model_constructions=1, native_solution_constructions=1,
                        native_route_constructions=K, optimization_calls=0, search_iterations=0,
                        random_initialization_calls=0, reference_used=True,
                        fair_cold_start_quality_result=False, K_ref=K, reference_declared_cost=cost,
                        denied_io_events=[], blocked_optimizer_attempts=[])
        for key, value in expected.items():
            check(key in answer and exact_equal(answer[key], value), 'FIELD:'+key)
        check(exact_equal(answer['routes'], reference), 'EXACT_ROUTE_ROUNDTRIP')
        check(answer['model_matrix_sha256'] == exact['matrix_sha256'], 'EXACT_FULL_MATRIX')
        check(exact_equal(answer['resource_limits'], LIMITS), 'RESOURCE_LIMITS')
        check(exact_equal(answer['native_model_parameters'], expected_model(problem, K)), 'MODEL_FIELDS')
        if baseline is not None:
            check(exact_equal(answer['native_model_parameters'], baseline['native_model_parameters']), 'COLD_MODEL_IDENTITY')
            check(answer['model_matrix_sha256'] == baseline['model_matrix_sha256'], 'COLD_MATRIX_IDENTITY')
        obs = answer['native_observations']
        expected_obs = dict(is_feasible=True, is_complete=True, num_routes=K,
                            num_clients=len(problem['demands'])-1, num_missing_clients=0,
                            num_missing_groups=0, num_missing_shipments=0, excess_load=[0],
                            excess_distance=0, time_warp=0, distance=cost, distance_cost=cost,
                            duration_cost=0, fixed_vehicle_cost=0, uncollected_prizes=0, objective_cost=cost)
        check(exact_equal(obs, expected_obs), 'NATIVE_SOLUTION_FIELDS')
        nr = answer['native_routes']
        check(type(nr) is list and len(nr) == K, 'NATIVE_ROUTE_COUNT')
        if isinstance(nr, list):
            for idx, route in enumerate(nr):
                if idx >= len(reference):
                    errors.append('EXTRA_NATIVE_ROUTE:'+str(idx)); continue
                acts = [dict(type='DEPOT', idx=0, location=0, node=0)]
                acts += [dict(type='CLIENT', idx=j-1, location=j, node=j) for j in reference[idx][1:-1]]
                acts += [dict(type='DEPOT', idx=0, location=0, node=0)]
                want = dict(activities=acts, distance=exact['route_costs'][idx],
                            delivery=[exact['route_loads'][idx]], vehicle_type=0,
                            start_depot=0, end_depot=0, num_trips=1, is_feasible=True,
                            excess_load=[0], excess_distance=0, time_warp=0)
                check(exact_equal(route, want), 'NATIVE_ROUTE_FIELDS:'+str(idx))
        checks = answer['checks']
        check(isinstance(checks, dict) and set(checks) == CHECK_KEYS and
              all(v is True for v in checks.values()), 'WORKER_CHECKS')
        for key in ('build_wall_seconds_audit_only', 'total_wall_seconds_audit_only',
                    'total_cpu_seconds_audit_only', 'worker_maxrss_KiB_audit_only'):
            value = answer[key]
            check(type(value) in (int, float) and math.isfinite(value) and value >= 0, 'TIMING_SCHEMA:'+key)
        check(answer['build_wall_seconds_audit_only'] <= answer['total_wall_seconds_audit_only'], 'TIMING_ORDER')
    except Exception as exc:
        errors.append('OUTPUT_SCHEMA:'+type(exc).__name__+':'+str(exc))
    return dict(valid=not errors, status='NATIVE_REFERENCE_ACCEPTED' if not errors else 'ADAPTER_VALIDATION_FAILURE',
                errors=errors, independent_validation=exact)


def jsonl(path):
    rows, errors = [], []
    try:
        lines = Path(path).read_text().splitlines()
    except OSError as exc:
        return rows, ['MISSING_OR_UNREADABLE_LEDGER:'+str(exc)]
    for idx, line in enumerate(lines, 1):
        try:
            row = json.loads(line)
            if not isinstance(row, dict):
                raise ValueError('row must be an object')
            rows.append(row)
        except (ValueError, TypeError) as exc:
            errors.append('MALFORMED_LEDGER_LINE:'+str(idx)+':'+str(exc))
    return rows, errors


def audit_ledger(schedule, records, events):
    expected = {e['call_id']: e for e in schedule}
    errors, byid, local, lifecycle = [], {}, {cid: [] for cid in expected}, []
    for row in records:
        cid = row.get('call_id')
        if type(cid) is not str:
            errors.append('RESULT_ID_SCHEMA'); continue
        if cid not in expected:
            errors.append('UNEXPECTED_RESULT:'+cid); continue
        if cid in byid:
            errors.append('DUPLICATE_RESULT:'+cid)
        byid[cid] = row
    for event in events:
        cid, kind = event.get('call_id'), event.get('event_kind')
        if type(cid) is not str:
            errors.append('EVENT_ID_SCHEMA'); continue
        if cid not in expected:
            errors.append('UNEXPECTED_EVENT:'+cid); continue
        if kind not in ('STARTED', 'FINISHED'):
            errors.append('EVENT_KIND:'+cid); continue
        lifecycle.append((cid, kind))
        local[cid].append(kind)
        if event.get('schedule') != expected[cid]:
            errors.append('EVENT_SCHEDULE:'+cid)
        keys = {'event_kind', 'utc', 'call_id', 'schedule'} | ({'result'} if kind == 'FINISHED' else set())
        if set(event) != keys:
            errors.append('EVENT_SCHEMA:'+cid)
        if kind == 'FINISHED' and event.get('result') != byid.get(cid):
            errors.append('FINISHED_RESULT_MISMATCH:'+cid)
        try:
            if datetime.datetime.fromisoformat(event['utc']).tzinfo is None:
                raise ValueError('missing timezone')
        except (KeyError, TypeError, ValueError):
            errors.append('EVENT_UTC:'+cid)
    wanted = [(e['call_id'], k) for e in schedule for k in ('STARTED', 'FINISHED')]
    if lifecycle != wanted[:len(lifecycle)]:
        errors.append('NON_SERIAL_LIFECYCLE')
    per = {}
    for cid, entry in expected.items():
        ee = []
        if local[cid] != ['STARTED', 'FINISHED']:
            ee.append('MISSING_OR_INVALID_START_FINISH')
        if cid not in byid:
            ee.append('MISSING_RESULT')
        elif byid[cid].get('schedule') != entry:
            ee.append('RESULT_SCHEDULE_MISMATCH')
        per[cid] = dict(errors=ee, events=local[cid])
    return dict(status='PASS' if not errors and not any(x['errors'] for x in per.values()) else 'INCOMPLETE_OR_INVALID',
                errors=errors, calls=per, observed_records=len(records), observed_events=len(events)), byid


def verify_receipt(root, stage, frozen_hash):
    receipt = read(root/'provenance'/f'{stage}_DRIVE_RECEIPT.json')
    for key in ('owner_only', 'remote_readback_sha256_verified', 'download_byte_identical'):
        if receipt.get(key) is not True:
            raise ValueError('ARCHIVE_GATE:'+stage+':'+key)
    if receipt.get('shared') is not False or receipt.get('frozen_files_sha256') != frozen_hash:
        raise ValueError('ARCHIVE_GATE:'+stage+':permissions/freeze')
    archive = root.parent/(root.name+'_'+stage+'.zip')
    if not (receipt['sha256'] == receipt['download_sha256'] == sha(archive) == sha(receipt['download_path'])):
        raise ValueError('ARCHIVE_GATE:'+stage+':actual byte hash')
    return receipt, archive


def verify_gates(root):
    """Hard prerequisite: actual local readback bytes for both archives exist."""
    frozen_hash = sha(root/'freeze/FROZEN_FILES.json')
    frozen = read(root/'freeze/FROZEN_FILES.json')['files']
    for rel, info in frozen.items():
        p = root/rel
        if p.stat().st_size != info['bytes'] or sha(p) != info['sha256']:
            raise ValueError('FROZEN_FILE_CHANGED:'+rel)
    pre, _ = verify_receipt(root, 'PREEXEC', frozen_hash)
    raw, archive = verify_receipt(root, 'RAW_UNREVIEWED', frozen_hash)
    approval = read(root/'provenance/PARENT_EXECUTION_APPROVAL.json')
    if not (approval.get('approved') is True and approval['frozen_files_sha256'] == frozen_hash
            and approval['preexec_archive_sha256'] == pre['sha256']
            and approval['scope'] == 'one frozen12-instance no-search reference adapter batch; zero optimization calls; no retry'):
        raise ValueError('PARENT_HASH_BOUND_APPROVAL')
    errors = []
    manifest = read(root/'raw/RAW_UNREVIEWED_MANIFEST.json')['files']
    actual = {str(p.relative_to(root)) for p in (root/'raw').rglob('*') if p.is_file() and '__pycache__' not in p.parts}
    if actual != set(manifest) | {'raw/RAW_UNREVIEWED_MANIFEST.json'}:
        errors.append('RAW_FILE_SET')
    with zipfile.ZipFile(archive) as z:
        if len(z.namelist()) != len(set(z.namelist())):
            errors.append('DUPLICATE_ARCHIVE_MEMBER')
        for rel, info in manifest.items():
            p = root/rel
            try:
                data = p.read_bytes()
                if len(data) != info['bytes'] or hashlib.sha256(data).hexdigest() != info['sha256']:
                    errors.append('RAW_MANIFEST_MISMATCH:'+rel)
                if z.read(root.name+'/'+rel) != data:
                    errors.append('RAW_ARCHIVE_MEMBER_MISMATCH:'+rel)
            except (OSError, KeyError) as exc:
                errors.append('RAW_MEMBER_UNREADABLE:'+rel+':'+str(exc))
        if z.read(root.name+'/raw/RAW_UNREVIEWED_MANIFEST.json') != (root/'raw/RAW_UNREVIEWED_MANIFEST.json').read_bytes():
            errors.append('RAW_MANIFEST_ARCHIVE_MISMATCH')
    for path, info in read(root/'freeze/OLD_FILES_BEFORE.json')['files'].items():
        p = Path(path)
        if p.stat().st_size != info['bytes'] or sha(p) != info['sha256']:
            errors.append('OLD_FILE_CHANGED:'+path)
    return frozen_hash, raw, errors


def safe_count(answer, key):
    value = answer.get(key) if isinstance(answer, dict) else None
    return value if type(value) is int and value >= 0 else None


def collect(root, batch_errors=()):
    schedule = read(root/'freeze/SCHEDULE.json')
    assert len(schedule) == 12 and len({e['call_id'] for e in schedule}) == 12
    assert [e['schedule_index'] for e in schedule] == list(range(1, 13))
    records, re = jsonl(root/'raw/results.jsonl')
    events, ee = jsonl(root/'raw/attempts.jsonl')
    ledger, byid = audit_ledger(schedule, records, events)
    common_errors = list(batch_errors) + re + ee + ledger['errors']
    rows = []
    for entry in schedule:
        cid, name, K = entry['call_id'], entry['instance_id'], entry['K_ref']
        answer, cost, exact = None, None, None
        errors = common_errors + ledger['calls'][cid]['errors']
        item = byid.get(cid)
        result = dict(valid=False, status='INPUT_OR_BASELINE_FAILURE', errors=[], independent_validation=None)
        try:
            problem = parse_vrp((root/f'input/{name}.vrp').read_text())
            reference, cost = parse_sol((root/f'references/{name}.sol').read_text())
            exact = validate(problem, reference, cost, K)
            baseline = read(root.parent/BASE_NAME/f'raw/calls/X{entry["schedule_index"]:02d}_s0_Kref_b250.stdout')
            if item:
                for stream in ('stdout', 'stderr'):
                    expected_path = f'raw/calls/{cid}.{stream}'
                    if item.get(stream) != expected_path:
                        errors.append('OUTPUT_PATH:'+stream); continue
                    path = root/expected_path
                    try:
                        if sha(path) != item.get(stream+'_sha256'):
                            errors.append('OUTPUT_HASH:'+stream)
                        if stream == 'stdout':
                            answer = read(path)
                    except (OSError, ValueError) as exc:
                        errors.append('OUTPUT_READ:'+stream+':'+str(exc))
                payload = dict(**problem, K=K, reference_routes=reference, reference_declared_cost=cost)
                ph = hashlib.sha256(json.dumps(payload, separators=(',', ':')).encode()).hexdigest()
                if not (item.get('schedule') == entry and item.get('payload_sha256') == ph
                        and type(item.get('returncode')) is int and item['returncode'] == 0
                        and item.get('process_spawned') is True and item.get('child_reaped') is True
                        and item.get('status') == 'UNREVIEWED_PROCESS_SUCCESS'):
                    errors.append('PROCESS_OR_PAYLOAD_RECORD')
            else:
                errors.append('MISSING_RESULT')
            result = audit_answer(problem, reference, cost, K, answer, baseline, exact)
        except Exception as exc:
            errors.append('SLOT_EVIDENCE_ERROR:'+type(exc).__name__+':'+str(exc))
        result['errors'] += errors
        result['valid'] = result['valid'] and not errors
        if errors:
            result['status'] = 'PROCESS_LEDGER_OR_EVIDENCE_FAILURE'
        result.update(call_id=cid, instance_id=name, K_ref=K, reference_cost=cost,
                      process_status=item.get('status') if item else 'MISSING_RESULT',
                      actual_output_solution_constructions=safe_count(answer, 'native_solution_constructions'),
                      actual_output_optimization_calls=safe_count(answer, 'optimization_calls'))
        rows.append(result)
    ledger['errors'] += re + ee
    if ledger['errors']:
        ledger['status'] = 'INCOMPLETE_OR_INVALID'
    return rows, ledger


def main():
    if not __debug__:
        raise RuntimeError('Assertions must be enabled')
    resource.setrlimit(resource.RLIMIT_CPU, (60, 60))
    resource.setrlimit(resource.RLIMIT_AS, (512*1024**2, 512*1024**2))
    signal.alarm(120)
    frozen_hash, raw, batch_errors = verify_gates(ROOT)
    rows, ledger = collect(ROOT, batch_errors)
    evidence = {}
    for name in ('EXECUTOR_STARTED', 'EXECUTOR_FINISHED', 'STARTED', 'FINISHED'):
        try:
            evidence[name] = read(ROOT/'raw'/f'{name}.json')
        except (OSError, ValueError) as exc:
            evidence[name] = {'evidence_error': str(exc)}
    output = dict(status='SAVED_EVIDENCE_AUDITED', utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  raw_archive_sha256=raw['sha256'], frozen_files_sha256=frozen_hash,
                  scope='Saved data only; no PyVRP import, native construction, optimization, repair, or retry.',
                  planned_denominator=12, accepted=sum(row['valid'] for row in rows),
                  batch_integrity_errors=batch_errors, ledger=ledger, lifecycle_evidence=evidence, rows=rows,
                  audit_resource_limits={'CPU_seconds': list(resource.getrlimit(resource.RLIMIT_CPU)),
                                         'AS_bytes': list(resource.getrlimit(resource.RLIMIT_AS)),
                                         'alarm_seconds': 120},
                  additional_native_constructions=0, additional_optimization_calls=0,
                  self_source_sha256={p.name: sha(p) for p in sorted(Path(__file__).parent.glob('*.py'))})
    dest = ROOT/'independent_supervision/results/SAVED_ADAPTER_AUDIT.json'
    dest.parent.mkdir(exist_ok=True)
    with dest.open('x') as f:
        json.dump(output, f, indent=2, ensure_ascii=False, allow_nan=False); f.write('\n')
    signal.alarm(0)
    print(json.dumps(dict(status=output['status'], accepted=output['accepted'], planned_denominator=12, path=str(dest))))


if __name__ == '__main__':
    main()
