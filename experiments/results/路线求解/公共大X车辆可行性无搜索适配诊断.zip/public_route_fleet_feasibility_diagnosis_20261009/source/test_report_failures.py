"""Saved-only malformed JSON/count regression; zero native construction or search."""
import json,hashlib,shutil,copy
from pathlib import Path
import report
from exact_validator import parse_vrp,parse_sol
from adapter_audit import audit_answer
BASE=Path(__file__).resolve().parents[1]
def main():
    dest=BASE/'selftests/report_failure_r2';dest.mkdir(exist_ok=False)
    for folder in ['input','references','freeze','raw/calls']:(dest/folder).mkdir(parents=True)
    for folder in ['input','references']:
        for p in(BASE/folder).iterdir():shutil.copyfile(p,dest/folder/p.name)
    shutil.copyfile(BASE/'freeze/SCHEDULE.json',dest/'freeze/SCHEDULE.json')
    schedule=json.loads((dest/'freeze/SCHEDULE.json').read_text());fixture=json.loads((BASE/'selftests/SUPERVISOR_INTEGRATION.json').read_text());good=json.loads((BASE/fixture['record']['stdout']).read_text())
    text_counts=copy.deepcopy(good);text_counts.update(native_solution_constructions='1',optimization_calls='0')
    bool_counts=copy.deepcopy(good);bool_counts.update(native_solution_constructions=True,optimization_calls=False)
    negative_counts=copy.deepcopy(good);negative_counts.update(native_solution_constructions=-1,optimization_calls=-1)
    answers=[['nonempty list'],'nonempty string',text_counts,bool_counts,negative_counts];items=[];events=[]
    for e,answer in zip(schedule,answers):
        name=e['instance_id'];problem=parse_vrp((dest/f'input/{name}.vrp').read_text());rr,cost=parse_sol((dest/f'references/{name}.sol').read_text());payload={**problem,'K':e['K_ref'],'reference_routes':rr,'reference_declared_cost':cost};ph=hashlib.sha256(json.dumps(payload,separators=(',',':')).encode()).hexdigest()
        path=dest/'raw/calls'/f'{e["call_id"]}.stdout';path.write_text(json.dumps(answer)+'\n')
        item={'call_id':e['call_id'],'schedule':e,'stdout':str(path.relative_to(dest)),'stdout_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'payload_sha256':ph,'returncode':0,'process_spawned':True,'child_reaped':True,'status':'UNREVIEWED_PROCESS_SUCCESS'};items.append(item);events.extend([{'event_kind':'STARTED','utc':'SAVED_ONLY_FIXTURE','call_id':e['call_id'],'schedule':e},{'event_kind':'FINISHED','utc':'SAVED_ONLY_FIXTURE','call_id':e['call_id'],'schedule':e,'result':item}])
    for invalid_id in [[],{}]:
        items.append({'call_id':invalid_id})
        events.append({'call_id':invalid_id,'event_kind':'STARTED'})
    (dest/'raw/results.jsonl').write_text(''.join(json.dumps(x)+'\n'for x in items));(dest/'raw/attempts.jsonl').write_text(''.join(json.dumps(x)+'\n'for x in events))
    original=report.ROOT
    try:
        report.ROOT=dest;rows,ledger=report.collect();counts=report.count_totals(rows)
    finally:report.ROOT=original
    assert len(rows)==12 and not any(r['valid']for r in rows)
    assert all(r['actual_output_solution_constructions']is None and r['actual_output_optimization_calls']is None for r in rows)
    assert counts=={'formal_solution_constructions_verified_from_outputs':0,'formal_optimization_calls_verified_from_outputs':0,'unknown_solution_construction_count_slots':12,'unknown_optimization_call_count_slots':12,'missing_or_unreadable_output_count':12}
    assert all(any('COUNT_FIELD_SCHEMA' in e for e in rows[i]['errors'])for i in [2,3,4])
    assert 'RESULT_CALL_ID_SCHEMA'in ledger['errors']and 'EVENT_CALL_ID_SCHEMA'in ledger['errors']
    fixture_payload=fixture['fixture'];badstatus=copy.deepcopy(good);badstatus['status']='BAD_STATUS'
    status_audit=audit_answer(fixture_payload,fixture_payload['reference_routes'],12,1,badstatus)
    assert not status_audit['valid']and 'OUTPUT_STATUS'in status_audit['errors']
    badroutes=copy.deepcopy(good);badroutes['native_route_constructions']=0
    routecount_audit=audit_answer(fixture_payload,fixture_payload['reference_routes'],12,1,badroutes)
    assert not routecount_audit['valid']and 'NATIVE_ROUTE_CONSTRUCTION_COUNT'in routecount_audit['errors']
    good_audit=audit_answer(fixture_payload,fixture_payload['reference_routes'],12,1,good)
    assert good_audit['valid']
    result={'status':'PASS','status_field_failure_preserved':status_audit,'route_construction_count_failure_preserved':routecount_audit,'unchanged_saved_good_fixture':good_audit,'scope':'Production collect/count_totals on one saved-only12-slot fixture: nonempty list/string JSON, string/bool/negative counts, seven missing outputs; appended list/dict IDs retained as ledger schema errors; status and route-count checks on same saved toy output. These simulated files are not actual native calls.','native_constructions':0,'optimization_calls':0,'planned_rows_retained':len(rows),'counts':counts,'rows':rows,'ledger':ledger,'source_hashes':{f:hashlib.sha256((BASE/'source'/f).read_bytes()).hexdigest()for f in ['report.py','adapter_audit.py','test_report_failures.py']}}
    (dest/'REPORT.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS malformed saved-output regression; all12rows retained; no native/optimizer calls')
if __name__=='__main__':main()
