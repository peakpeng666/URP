"""Exactly one invented two-client native adapter fixture; zero optimisation."""
import json,signal
from common import ROOT,read,save,now,sha
from run_once import logged_call
from exact_validator import validate

def run_in_limited_supervisor(limits):
    assert limits=={'AS_bytes':[512*1024**2,1536*1024**2],'CPU_seconds':[30,30]}
    signal.alarm(50)
    dest=ROOT/'selftests/integration';dest.mkdir(exist_ok=False);calls=dest/'calls';calls.mkdir()
    payload={'coordinates':[[0,0],[3,0],[3,4]],'demands':[0,2,3],'capacity':5,'K':1,'reference_routes':[[0,1,2,0]],'reference_declared_cost':12}
    entry={'call_id':'INVENTED_TWO_CLIENT_ADAPTER','schedule_index':1,'instance_id':'INVENTED_TWO_CLIENT_ADAPTER','K_ref':1,'formal_constructions':0,'synthetic_constructions':1,'optimization_calls':0}
    item=logged_call(entry,payload,read('environment/RUNTIME.json')['python_executable'],calls,dest)
    assert item['status']=='UNREVIEWED_PROCESS_SUCCESS'and item['child_reaped'],item
    answer=read(item['stdout']);audit=validate(payload,answer['routes'],12,1)
    assert audit['valid']and audit['matrix_sha256']==answer['model_matrix_sha256']
    assert answer['routes']==[[0,1,2,0]]and answer['native_observations']['objective_cost']==12
    assert [x['type']for x in answer['native_routes'][0]['activities']]==['DEPOT','CLIENT','CLIENT','DEPOT']
    assert [x['idx']for x in answer['native_routes'][0]['activities']]==[0,0,1,0]
    assert [x['location']for x in answer['native_routes'][0]['activities']]==[0,1,2,0]
    assert answer['resource_limits']=={'inherited':limits,'effective':{'AS_bytes':[1536*1024**2,1536*1024**2],'CPU_seconds':[15,15]}}
    signal.alarm(0)
    save(ROOT/'selftests/SUPERVISOR_INTEGRATION.json',{'status':'PASS','utc':now(),'scope':'One invented two-client route verifies API client-index mapping, automatically added depot endpoints, exact roundtrip, cost12 and production child limits/logger. No public reference constructed.','public_native_solution_constructions':0,'synthetic_native_solution_constructions':1,'optimization_calls':0,'record':item,'fixture':payload,'independent_exact_validation':audit,'supervisor_limits':limits,'source_sha256':{n:sha(ROOT/'source'/n)for n in ['worker.py','model_helpers.py','run_once.py','synthetic_integration.py','exact_validator.py']}})
    print('PASS one invented two-client adapter fixture; zero formal constructions; zero optimisation calls')
