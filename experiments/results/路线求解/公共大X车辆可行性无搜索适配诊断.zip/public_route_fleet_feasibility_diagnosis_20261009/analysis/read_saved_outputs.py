"""Read-only recomputation of saved evidence; never imports or invokes PyVRP."""
import json, pathlib, importlib.util, hashlib, collections, math
BASE=pathlib.Path('/workspace/shared/public_route_fleet_budget_interaction_20261009')
OLD=pathlib.Path('/workspace/shared/public_route_fleet_constraint_effects_20261009')
OUT=pathlib.Path(__file__).parent
spec=importlib.util.spec_from_file_location('validator', BASE/'independent_review/independent_validator.py'); v=importlib.util.module_from_spec(spec); spec.loader.exec_module(v)
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
refs=[]
for task in read(BASE/'freeze/TASKS.json'):
 name=task['instance_id']; problem=read(BASE/f'input/{name}.json');problem['K']=task['K_ref']
 routes=[]; stated=None
 for line in (BASE/f'references/{name}.sol').read_text().splitlines():
  if line.startswith('Route #'):routes.append([0,*map(int,line.split(':',1)[1].split()),0])
  elif line.lower().startswith('cost'):stated=int(line.split()[-1])
 val=v.validate_solution(problem,routes,stated)
 n=len(problem['demands'])-1;k=problem['K'];per=max(n//k,1)+int(n>k and n%k!=0)
 refs.append({'instance_id':name,'source_instance_sha256':sha(BASE/f'input/{name}.vrp'),'source_reference_sha256':sha(BASE/f'references/{name}.sol'),'K_ref':k,'reference_validation':val,'total_demand':sum(problem['demands']),'total_fleet_capacity':k*problem['capacity'],'total_capacity_slack':k*problem['capacity']-sum(problem['demands']),'max_customer_demand':max(problem['demands']),'cold_random_constructor_predicted_route_count_before_exhaustive':(n+per-1)//per,'cold_random_constructor_max_clients_per_route':per})
failed=[];all_calls=[]
rows=[json.loads(x)for x in (BASE/'raw/results.jsonl').read_text().splitlines()]
for row in rows:
 r=read(BASE/row['stdout']);sch=row['schedule'];stats=r['stats']; flds=['current_cost','current_feas','candidate_cost','candidate_feas','best_cost','best_feas']
 item={'call_id':row['call_id'],'instance_id':sch['instance_id'],'seed':sch['seed'],'arm':sch['arm'],'completed_iterations':r['num_iterations'],'feasible':r['solver_is_feasible'],'six_fields_exact':all(set(s)==set(flds)for s in stats),'saved_stdout_sha256':sha(BASE/row['stdout']),'feasible_iteration_end_counts':{f:sum(s[f]for s in stats)for f in ['current_feas','candidate_feas','best_feas']},'cost_ranges':{f:{'min':min(s[f]for s in stats),'max':max(s[f]for s in stats),'distinct':len(set(s[f]for s in stats)),'last':stats[-1][f]}for f in ['current_cost','candidate_cost','best_cost']}}
 all_calls.append(item)
 if not r['solver_is_feasible']:
  problem=read(BASE/f"input/{sch['instance_id']}.json");problem['K']=sch['K'];val=v.validate_solution(problem,r['routes'],r['reported_distance']);q=problem['capacity']; loads=val['loads'];oldpath=OLD/f"raw/calls/X{sch['selection_slot']:02d}_s{sch['seed']}_Kref.stdout";old=read(oldpath)
  failed.append({**item,'reported_cost':r['reported_cost'],'reported_distance':r['reported_distance'],'reported_num_routes':r['reported_num_routes'],'solver_is_complete':r['solver_is_complete'],'independent_revalidation':val,'total_excess_load':sum(max(0,x-q)for x in loads),'overloaded_routes_1based':[{'route':i+1,'load':x,'excess':x-q}for i,x in enumerate(loads)if x>q],'first_stat':stats[0],'last_stat':stats[-1],'saved_returned_routes_equal_old25':r['routes']==old['routes'],'old25_stdout_sha256':sha(oldpath),'six_field_prefix25_equal':stats[:25]==old['stats']})
cap=[r for r in rows if r['schedule']['arm']=='at_most_K_ref']
res={'status':'READ_ONLY_SAVED_EVIDENCE_RECOMPUTED_NO_SOLVER_CALLS','source_final_zip_sha256':sha(BASE.with_name(BASE.name+'_FINAL_REVIEWED.zip')),'reference_count':len(refs),'all_references_independently_valid':all(x['reference_validation']['valid']for x in refs),'references':refs,'all_new_calls':all_calls,'failed_calls':failed,'historical_capped250_observed_resources_audit_only':{'calls':len(cap),'total_child_cpu_seconds':sum(r['cpu_seconds_audit_only']for r in cap),'total_external_wall_seconds':sum(r['wall_seconds_audit_only']for r in cap),'max_child_cpu_seconds':max(r['cpu_seconds_audit_only']for r in cap)}}
(OUT/'SAVED_OUTPUT_DIAGNOSTICS.json').write_text(json.dumps(res,indent=2)+'\n')
print(json.dumps({'status':res['status'],'reference_count':len(refs),'all_valid':res['all_references_independently_valid'],'calls':len(all_calls),'failed':len(failed),'failed_excess_load':[x['total_excess_load']for x in failed],'failed_returned_routes_equal_25':[x['saved_returned_routes_equal_old25']for x in failed]},indent=2))
