"""Audit saved adapter records only, after RAW archival gate; no PyVRP imports."""
import json,collections,hashlib
from common import ROOT,now,sha,read,save,verify_frozen,verify_old,receipt
from adapter_audit import audit_ledger,audit_answer
from exact_validator import parse_vrp,parse_sol
BASE=ROOT.parent/'public_route_fleet_budget_interaction_20261009'

def jsonl(path):
    rows=[];errors=[]
    if not path.exists():return rows,['MISSING_LEDGER:'+str(path)]
    for idx,line in enumerate(path.read_text().splitlines(),1):
        try:
            r=json.loads(line);assert isinstance(r,dict);rows.append(r)
        except Exception as e:errors.append('INVALID_LEDGER_LINE:'+str(idx)+':'+repr(e))
    return rows,errors

def observed_count(answer,key,errors):
    if not isinstance(answer,dict):return None
    value=answer.get(key)
    if type(value)is not int or value<0:
        errors.append('COUNT_FIELD_SCHEMA:'+key)
        return None
    return value

def count_totals(rows):
    return {'formal_solution_constructions_verified_from_outputs':sum(x['actual_output_solution_constructions']or 0 for x in rows),'formal_optimization_calls_verified_from_outputs':sum(x['actual_output_optimization_calls']or 0 for x in rows),'missing_or_unreadable_output_count':sum(x['actual_output_solution_constructions']is None for x in rows)}

def collect():
    schedule=read('freeze/SCHEDULE.json');items,ie=jsonl(ROOT/'raw/results.jsonl');events,ee=jsonl(ROOT/'raw/attempts.jsonl');ledger=audit_ledger(schedule,events,items)
    ledger['errors']+=ie+ee
    if ie or ee:ledger['status']='INCOMPLETE_OR_INVALID'
    expected_ids={e['call_id']for e in schedule}
    byid={x['call_id']:x for x in items if type(x.get('call_id'))is str and x['call_id']in expected_ids};ls={x['call_id']:x for x in ledger['calls']};rows=[]
    for entry in schedule:
        cid=entry['call_id'];name=entry['instance_id'];problem=parse_vrp((ROOT/f'input/{name}.vrp').read_text());reference,cost=parse_sol((ROOT/f'references/{name}.sol').read_text());item=byid.get(cid);answer=None;errors=[]
        if item:
            try:
                path=ROOT/item['stdout'];assert path.is_relative_to(ROOT/'raw/calls')and sha(path)==item['stdout_sha256'];answer=json.loads(path.read_text())
            except Exception as e:errors.append('READ_OR_HASH:'+repr(e))
        baseline=json.loads((BASE/f'raw/calls/X{entry["schedule_index"]:02d}_s0_Kref_b250.stdout').read_text())
        out=audit_answer(problem,reference,cost,entry['K_ref'],answer,baseline)
        errors+=ledger['errors']+ls[cid]['errors']
        payload={**problem,'K':entry['K_ref'],'reference_routes':reference,'reference_declared_cost':cost};ph=hashlib.sha256(json.dumps(payload,separators=(',',':')).encode()).hexdigest()
        if not item:errors.append('MISSING_RESULT')
        elif not(item.get('schedule')==entry and item.get('payload_sha256')==ph and item.get('returncode')==0 and item.get('process_spawned')and item.get('child_reaped')and item.get('status')=='UNREVIEWED_PROCESS_SUCCESS'):errors.append('PROCESS_OR_PAYLOAD_RECORD')
        out.update(call_id=cid,instance_id=name,K_ref=entry['K_ref'],reference_cost=cost,process_status=item.get('status')if item else'MISSING_RESULT',actual_output_solution_constructions=observed_count(answer,'native_solution_constructions',errors),actual_output_optimization_calls=observed_count(answer,'optimization_calls',errors))
        out['errors']+=errors
        if errors:out.update(valid=False,status='PROCESS_LEDGER_OR_OUTPUT_FAILURE')
        rows.append(out)
    return rows,ledger

def main():
    verify_frozen();verify_old();r=receipt('RAW_UNREVIEWED')
    independent=read('independent_supervision/results/SAVED_ADAPTER_AUDIT.json')
    assert independent['status']=='SAVED_EVIDENCE_AUDITED'and independent['raw_archive_sha256']==r['sha256']and independent['frozen_files_sha256']==sha(ROOT/'freeze/FROZEN_FILES.json')
    rows,ledger=collect()
    assert len(independent['rows'])==len(rows)==12
    for ours,theirs in zip(rows,independent['rows']):
        assert all(ours[k]==theirs[k]for k in ['call_id','instance_id','K_ref','reference_cost','valid']), (ours,theirs)
    summary={'utc':now(),'scope':'Existing12reference SOL native mapping and feasibility adapter; no search','planned_denominator':12,'accepted':sum(x['valid']for x in rows),'status_counts':dict(collections.Counter(x['status']for x in rows)),**count_totals(rows),'synthetic_solution_constructions':1,'synthetic_optimization_calls':0,'ledger_status':ledger['status'],'raw_archive_sha256':r['sha256'],'frozen_files_sha256':sha(ROOT/'freeze/FROZEN_FILES.json'),'independent_audit_sha256':sha(ROOT/'independent_supervision/results/SAVED_ADAPTER_AUDIT.json'),'old_files_unchanged':verify_old(),'interpretation':'This accepts supplied witnesses in the same native model. It does not discover a new solution, diagnose all search mechanisms, recover or replace old cold-start failures, or compare algorithm performance.'}
    save(ROOT/'reports/RESULTS.json',rows);save(ROOT/'reports/LEDGER_AUDIT.json',ledger);save(ROOT/'reports/SUMMARY.json',summary)
    lines=['车辆约束失败的源码诊断与原SOL无搜索原生适配核验','',f"原生接受并经独立核验：{summary['accepted']}/12；真实Solution构造已从输出核验{summary['formal_solution_constructions_verified_from_outputs']}次，新增优化调用{summary['formal_optimization_calls_verified_from_outputs']}次。",'另有1次虚构两客户构造预检，优化调用0；无seed重复、无warm-start求解。','固定原SOL路线，不排序、不修复，K_ref为实际非空路线数。CLIENT索引为SOL节点j−1，起终仓由原生Route自动添加；回读逐项还原闭合路线。','全部成本使用独立整数isqrt的精确EUC_2D最近整数半上舍入复核，且核对完整距离矩阵。','', '逐题结果']
    for x in rows:lines.append(f"{x['instance_id']}：K_ref={x['K_ref']}，参考成本={x['reference_cost']}，{x['status']}。")
    lines+=['','只读源码诊断补充', (ROOT/'analysis/DIAGNOSIS_ZH.txt').read_text(),'', '解释边界','该核验仅证明给定可行见证可由同一原生模型编码和评价，不是新的可行解发现，不证明冷启动初始化/邻域/罚项中哪一项是唯一失败原因；不改变旧25/250的33/36、失败路线或报告。没有公平算法优越性、SOTA、泛化或农业实际车队结论。']
    with(ROOT/'reports/REPORT_ZH.txt').open('x')as f:f.write('\n'.join(lines)+'\n')
    print(json.dumps(summary,ensure_ascii=False))
if __name__=='__main__':main()
