"""Saved-only adapter checks; ledger routine byte-identical to reviewed fleet supervisor audit."""
import json,hashlib
from exact_validator import parse_vrp,parse_sol,validate

def audit_ledger(schedule,attempts,items):
 errors=[];expected={e['call_id']:e for e in schedule};byid={};events={cid:[]for cid in expected}
 if len(expected)!=len(schedule):errors.append('DUPLICATE_SCHEDULE_ID')
 for item in items:
  cid=item.get('call_id')
  if cid not in expected:errors.append('UNEXPECTED_RESULT')
  if cid in byid:errors.append('DUPLICATE_RESULT')
  byid[cid]=item
 for event in attempts:
  cid=event.get('call_id')
  if cid not in expected:errors.append('UNEXPECTED_EVENT');continue
  if event.get('schedule')!=expected[cid]:errors.append('EVENT_SCHEDULE_MISMATCH')
  kind=event.get('event_kind')
  if kind not in ('STARTED','FINISHED'):errors.append('INVALID_EVENT_KIND')
  required={'event_kind','utc','call_id','schedule'}|({'result'}if kind=='FINISHED'else set())
  if set(event)!=required:errors.append('EVENT_SCHEMA_MISMATCH')
  if kind=='FINISHED'and event.get('result')!=byid.get(cid):errors.append('FINISHED_RESULT_MISMATCH')
  events[cid].append(kind)
 per=[]
 for entry in schedule:
  cid=entry['call_id'];ev=events[cid];local=[]
  if ev!=['STARTED','FINISHED']:local.append('MISSING_OR_INVALID_START_FINISH_SEQUENCE')
  if cid not in byid:local.append('MISSING_RESULT')
  if cid in byid and byid[cid].get('schedule')!=entry:local.append('RESULT_SCHEDULE_MISMATCH')
  per.append({'call_id':cid,'events':ev,'errors':local,'ledger_valid':not local})
 order=[e.get('call_id')for e in attempts if e.get('event_kind')=='STARTED']
 if order!=[e['call_id']for e in schedule][:len(order)]:errors.append('START_ORDER_MISMATCH')
 expected_lifecycle=[(e['call_id'],kind)for e in schedule for kind in ('STARTED','FINISHED')]
 observed_lifecycle=[(e.get('call_id'),e.get('event_kind'))for e in attempts]
 if observed_lifecycle!=expected_lifecycle[:len(observed_lifecycle)]:errors.append('NON_SERIAL_OR_INVALID_EVENT_LIFECYCLE')
 return {'status':'PASS'if not errors and all(p['ledger_valid']for p in per)else'INCOMPLETE_OR_INVALID','errors':errors,'planned_denominator':len(schedule),'observed_records':len(items),'observed_events':len(attempts),'calls':per}

def audit_answer(problem,reference,cost,K,answer,baseline=None):
    errors=[];validation=None
    if not isinstance(answer,dict):return {'status':'MISSING_OR_MALFORMED_OUTPUT','valid':False,'errors':['MISSING_OR_MALFORMED_OUTPUT'],'independent_validation':None}
    try:
        if answer['version']!='0.14.0' or answer['seed']is not None:errors.append('IDENTITY')
        if any(type(answer.get(k))is not int or answer[k]<0 for k in ['optimization_calls','search_iterations','random_initialization_calls','model_constructions','native_solution_constructions']):errors.append('COUNT_FIELD_SCHEMA')
        if answer['K_ref']!=K:errors.append('K_REF')
        if any(answer[k]!=0 for k in ['optimization_calls','search_iterations','random_initialization_calls']):errors.append('UNREQUESTED_SEARCH')
        if any(answer[k]!=1 for k in ['model_constructions','native_solution_constructions']):errors.append('CONSTRUCTION_COUNT')
        if not(answer['reference_used']is True and answer['fair_cold_start_quality_result']is False):errors.append('REFERENCE_DISCLOSURE')
        if answer['denied_io_events']or answer['blocked_optimizer_attempts']:errors.append('FORBIDDEN_ACTION')
        if answer['routes']!=reference:errors.append('REFERENCE_ROUNDTRIP')
        validation=validate(problem,answer['routes'],cost,K)
        if not validation['valid']:errors+=validation['errors']
        if answer['model_matrix_sha256']!=validation['matrix_sha256']:errors.append('EXACT_FULL_MATRIX')
        obs=answer['native_observations']
        if not(obs['is_feasible']is True and obs['is_complete']is True):errors.append('NATIVE_INFEASIBLE_OR_INCOMPLETE')
        if not(obs['num_routes']==K and obs['num_clients']==len(problem['demands'])-1):errors.append('NATIVE_COUNTS')
        if any(obs[x]!=0 for x in ['num_missing_clients','num_missing_groups','num_missing_shipments','excess_distance','time_warp','duration_cost','fixed_vehicle_cost','uncollected_prizes']):errors.append('NATIVE_VIOLATIONS_OR_OBJECTIVE')
        if obs['excess_load']!=[0]:errors.append('NATIVE_LOAD_VIOLATION')
        if not(obs['distance']==obs['distance_cost']==obs['objective_cost']==cost==validation['cost']):errors.append('NATIVE_OBJECTIVE_MISMATCH')
        if answer['reference_declared_cost']!=cost:errors.append('REFERENCE_COST')
        expected_limits={'inherited':{'AS_bytes':[512*1024**2,1536*1024**2],'CPU_seconds':[30,30]},'effective':{'AS_bytes':[1536*1024**2,1536*1024**2],'CPU_seconds':[15,15]}}
        if answer['resource_limits']!=expected_limits:errors.append('RESOURCE_LIMITS')
        if len(answer['native_routes'])!=K:errors.append('NATIVE_ROUTE_COUNT')
        for i,nr in enumerate(answer['native_routes']):
            acts=nr['activities'];rr=reference[i]
            exp=[{'type':'DEPOT','idx':0,'location':0,'node':0}]+[{'type':'CLIENT','idx':j-1,'location':j,'node':j}for j in rr[1:-1]]+[{'type':'DEPOT','idx':0,'location':0,'node':0}]
            if acts!=exp:errors.append(f'NATIVE_ACTIVITIES_{i}')
            if nr['delivery']!=[validation['route_loads'][i]]or nr['distance']!=validation['route_costs'][i]:errors.append(f'NATIVE_LOAD_DISTANCE_{i}')
            if not(nr['is_feasible']is True and nr['excess_load']==[0]and nr['excess_distance']==nr['time_warp']==0):errors.append(f'NATIVE_ROUTE_VIOLATION_{i}')
            if not(nr['vehicle_type']==nr['start_depot']==nr['end_depot']==0 and nr['num_trips']==1):errors.append(f'NATIVE_ROUTE_TYPE_{i}')
        if baseline is not None:
            if answer['native_model_parameters']!=baseline['native_model_parameters']:errors.append('COLD_MODEL_CHANGED')
            if answer['model_matrix_sha256']!=baseline['model_matrix_sha256']:errors.append('COLD_MATRIX_CHANGED')
        if not all(answer['checks'].values()):errors.append('WORKER_CHECK_FAILURE')
    except(Exception)as exc:errors.append('OUTPUT_SCHEMA:'+repr(exc))
    return {'status':'NATIVE_REFERENCE_ACCEPTED'if not errors else'ADAPTER_VALIDATION_FAILURE','valid':not errors,'errors':errors,'independent_validation':validation}
