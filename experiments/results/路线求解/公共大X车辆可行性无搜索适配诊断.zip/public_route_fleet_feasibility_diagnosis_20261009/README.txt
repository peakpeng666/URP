PyVRP0.14.0 fleet feasibility: source diagnosis and no-search native reference adapter

This supplements the reviewed25/250fleet results without modifying them.
At preexecution freeze: zero formal reference constructions, exactly one invented two-client construction, zero optimizer calls.
See freeze/PROTOCOL.json and selftests/SUPERVISOR_INTEGRATION.json.
Source/API diagnosis: analysis/DIAGNOSIS_ZH.txt, source_evidence/VERIFIED_IDENTITY.json.
All12inputs/references and current code included. Existing official wheel dependencies are reused, not reinstalled; restore using environment/DEPENDENCIES.json and the unchanged original manifests.
Formal execution requires independent PRECHECK, verified private PREEXEC receipt, and parent hash-bound approval.
