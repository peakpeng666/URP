"""Post-run, read-only portable evidence verification; never runs a solver.

This helper was authored after the numerical run and is not part of PRE_RUN_FREEZE.
It verifies all locally bundled frozen files and source copies without requiring
absolute paths on the producer machine. Present original sources are also checked.
"""
from pathlib import Path
import hashlib,json,sys
root=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
checks=[]
for rel,h in load(root/'PRE_RUN_FREEZE.json')['hashes'].items():
 p=root/rel;checks.append({'file':rel,'scope':'pre_run_freeze','ok':p.is_file() and sha(p)==h})
for item in load(root/'SOURCE_MANIFEST.json'):
 p=root/item['copy'];checks.append({'file':item['copy'],'scope':'source_copy','ok':p.is_file() and sha(p)==item['sha256']})
 p=Path(item['source'])
 if p.is_file():checks.append({'file':str(p),'scope':'available_original_source','ok':sha(p)==item['sha256']})
manifest=root/'FINAL_MANIFEST.json'
if manifest.exists():
 for row in load(manifest)['files']:
  p=root/row['path'];checks.append({'file':row['path'],'scope':'final_manifest','ok':p.is_file() and sha(p)==row['sha256'] and p.stat().st_size==row['bytes']})
print(json.dumps({'ok':all(c['ok'] for c in checks),'checks':len(checks),'failed':[c for c in checks if not c['ok']],'qualifications':'Hash validation only, not numerical independent audit; no solver calls.'},indent=2))
sys.exit(0 if all(c['ok'] for c in checks) else 1)
