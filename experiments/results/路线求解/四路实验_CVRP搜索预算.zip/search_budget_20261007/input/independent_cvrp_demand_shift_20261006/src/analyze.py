"""Frozen descriptive analysis. No optimization or learned selector."""
from pathlib import Path
from collections import Counter,defaultdict
import csv,json,statistics,time
ROOT=Path(__file__).resolve().parents[1]
def load(p): return json.loads(Path(p).read_text())
def mean(x):return statistics.mean(x) if x else None
def csvwrite(path,rows):
    if not rows:return
    with path.open('x',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
def main():
    cpu=time.process_time();wall=time.perf_counter();cfg=load(ROOT/'PROTOCOL.json');eps=1e-9
    algs=sorted('_'.join(p) for p in cfg['pairs']);modes=cfg['demand_modes']
    rows=[json.loads(l) for l in (ROOT/'results/formal.jsonl').read_text().splitlines()];smoke=[json.loads(l) for l in (ROOT/'results/smoke.jsonl').read_text().splitlines()]
    idx=defaultdict(list)
    for r in rows: idx[(r['geometry_id'],r['demand_mode'],r['algorithm'])].append(r)
    records={};per_instance=[];incomplete=[]
    for geo in sorted({r['geometry_id'] for r in rows}):
        for mode in modes:
            if any(len(idx[(geo,mode,a)])!=3 or not all(r.get('scoreable') for r in idx[(geo,mode,a)]) for a in algs):
                incomplete.append({'geometry_id':geo,'demand_mode':mode});continue
            costs={a:mean([r['check']['recomputed_cost'] for r in idx[(geo,mode,a)]]) for a in algs}
            best=min(costs.values());bestset=sorted(a for a in algs if costs[a]<=best+eps);rec={}
            for a in algs:
                rs=idx[(geo,mode,a)];v=costs[a]
                rank=1+sum(c<v-eps for c in costs.values())+(sum(abs(c-v)<=eps for c in costs.values())-1)/2
                baseline=mean([r['baseline_check']['recomputed_cost'] for r in rs]);gap=100*(v/best-1)
                rec[a]={'geometry_id':geo,'demand_mode':mode,'family':rs[0]['family'],'n':rs[0]['n'],'algorithm':a,'mean_distance':v,'mean_vehicles':mean([r['vehicle_count'] for r in rs]),'mean_savings_distance':baseline,'improvement_over_savings_percent':100*(baseline-v)/baseline,'mean_cost_oracle':best,'relative_distance_regret_percent':gap,'midrank':rank,'is_tied_best':a in bestset,'chosen_best':bestset[0]}
                per_instance.append(rec[a])
            records[(geo,mode)]=rec
    aggregate=[]
    for mode in modes:
        for a in algs:
            rs=[r for r in per_instance if r['demand_mode']==mode and r['algorithm']==a]
            aggregate.append({'demand_mode':mode,'algorithm':a,'geometry_count':len(rs),'mean_distance':mean([r['mean_distance'] for r in rs]),'mean_vehicles':mean([r['mean_vehicles'] for r in rs]),'mean_relative_regret_percent':mean([r['relative_distance_regret_percent'] for r in rs]),'mean_improvement_over_savings_percent':mean([r['improvement_over_savings_percent'] for r in rs]),'mean_midrank':mean([r['midrank'] for r in rs]),'tied_best_count':sum(r['is_tied_best'] for r in rs)})
    transfer=[];pairwise=[]
    for geo in sorted({key[0] for key in records}):
        source=records.get((geo,modes[0]));
        if source is None: continue
        chosen=next(iter(source.values()))['chosen_best'];old=cfg['old_fixed_recommendation']
        for mode in modes:
            target=records.get((geo,mode))
            if target is None:continue
            winners=sorted(a for a in algs if target[a]['is_tied_best']);s=target[chosen];f=target[old]
            transfer.append({'geometry_id':geo,'demand_mode':mode,'source_selected_algorithm':chosen,'target_winners':'|'.join(winners),'source_choice_is_target_best':chosen in winners,'source_selected_distance':s['mean_distance'],'source_selected_vehicles':s['mean_vehicles'],'source_selected_regret_percent':s['relative_distance_regret_percent'],'old_fixed_algorithm':old,'old_fixed_distance':f['mean_distance'],'old_fixed_vehicles':f['mean_vehicles'],'old_fixed_regret_percent':f['relative_distance_regret_percent'],'target_mean_cost_oracle':f['mean_cost_oracle']})
        for m1,m2 in [(modes[0],modes[1]),(modes[0],modes[2]),(modes[1],modes[2])]:
            a=records.get((geo,m1));b=records.get((geo,m2))
            if a is None or b is None:continue
            strict=rev=tie_change=0
            for ai in range(len(algs)):
                for aj in range(ai+1,len(algs)):
                    x,y=algs[ai],algs[aj];d1=a[x]['mean_distance']-a[y]['mean_distance'];d2=b[x]['mean_distance']-b[y]['mean_distance']
                    if abs(d1)>eps and abs(d2)>eps:strict+=1;rev+=int(d1*d2<0)
                    if (abs(d1)<=eps)!=(abs(d2)<=eps):tie_change+=1
            wa={x for x in algs if a[x]['is_tied_best']};wb={x for x in algs if b[x]['is_tied_best']}
            pairwise.append({'geometry_id':geo,'from_mode':m1,'to_mode':m2,'common_best_exists':bool(wa&wb),'winner_set_changed':wa!=wb,'strict_comparable_algorithm_pairs':strict,'strict_reversals':rev,'tie_status_changes':tie_change})
    transfer_summary=[]
    for mode in modes:
        rs=[r for r in transfer if r['demand_mode']==mode]
        baseline={r['geometry_id']:r for r in transfer if r['demand_mode']==modes[0]}
        transfer_summary.append({'demand_mode':mode,'geometries':len(rs),'source_selected_not_best_count':sum(not r['source_choice_is_target_best'] for r in rs),'source_selected_mean_regret_percent':mean([r['source_selected_regret_percent'] for r in rs]),'source_selected_max_regret_percent':max([r['source_selected_regret_percent'] for r in rs],default=None),'old_fixed_mean_regret_percent':mean([r['old_fixed_regret_percent'] for r in rs]),'old_fixed_max_regret_percent':max([r['old_fixed_regret_percent'] for r in rs],default=None),'paired_change_old_fixed_regret_percentage_points':mean([r['old_fixed_regret_percent']-baseline[r['geometry_id']]['old_fixed_regret_percent'] for r in rs if r['geometry_id'] in baseline]),'source_selected_mean_vehicles':mean([r['source_selected_vehicles'] for r in rs]),'old_fixed_mean_vehicles':mean([r['old_fixed_vehicles'] for r in rs])})
    reversal_summary=[]
    for a,b in [(modes[0],modes[1]),(modes[0],modes[2]),(modes[1],modes[2])]:
        rs=[r for r in pairwise if r['from_mode']==a and r['to_mode']==b]
        reversal_summary.append({'from_mode':a,'to_mode':b,'geometries':len(rs),'winner_set_changed_count':sum(r['winner_set_changed'] for r in rs),'no_common_best_count':sum(not r['common_best_exists'] for r in rs),'strict_comparable_pairs':sum(r['strict_comparable_algorithm_pairs'] for r in rs),'strict_reversals':sum(r['strict_reversals'] for r in rs),'geometries_with_strict_reversals':sum(r['strict_reversals']>0 for r in rs),'tie_status_changes':sum(r['tie_status_changes'] for r in rs)})
    resource=[]
    for stage,rr in [('formal',rows),('smoke',smoke)]:
        for a in algs:
            rs=[r for r in rr if r['algorithm']==a];resource.append({'stage':stage,'algorithm':a,'planned':len(rs),'executed':sum(r['run_status']=='executed' for r in rs),'scoreable':sum(r.get('scoreable',False) for r in rs),'solver_cpu_seconds':sum(r.get('solver_cpu_seconds',0) for r in rs),'checker_cpu_seconds':sum(r.get('checker_cpu_seconds',0) for r in rs),'solver_wall_seconds':sum(r.get('solver_wall_seconds',0) for r in rs),'total_deltas':sum(r.get('deltas',0) for r in rs),'iterations_completed':sum(r.get('iterations_completed',0) for r in rs),'max_solver_cpu_seconds':max([r.get('solver_cpu_seconds',0) for r in rs]),'stop_reasons':json.dumps(dict(Counter(r.get('stop_reason',r['run_status']) for r in rs)),sort_keys=True)})
    csvwrite(ROOT/'results/per_geometry_algorithm.csv',per_instance);csvwrite(ROOT/'results/aggregate.csv',aggregate);csvwrite(ROOT/'results/transfer.csv',transfer);csvwrite(ROOT/'results/rank_changes.csv',pairwise);csvwrite(ROOT/'results/resources.csv',resource)
    result={'formal_scheduled':len(rows),'formal_executed':sum(r['run_status']=='executed' for r in rows),'formal_scoreable':sum(r.get('scoreable',False) for r in rows),'smoke_scheduled':len(smoke),'smoke_scoreable':sum(r.get('scoreable',False) for r in smoke),'incomplete_geometry_demand_blocks':incomplete,'aggregate':aggregate,'transfer':transfer_summary,'ranking_changes':reversal_summary,'resources':resource,'analysis_cpu_seconds':time.process_time()-cpu,'analysis_wall_seconds':time.perf_counter()-wall,'scope':'Descriptive synthetic paired development; no trained selector or paper replication; 24 paired geometry units'}
    with (ROOT/'results/summary.json').open('x') as f:json.dump(result,f,ensure_ascii=False,indent=2,allow_nan=False)
    print(json.dumps({k:v for k,v in result.items() if k not in ['aggregate','resources']},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
