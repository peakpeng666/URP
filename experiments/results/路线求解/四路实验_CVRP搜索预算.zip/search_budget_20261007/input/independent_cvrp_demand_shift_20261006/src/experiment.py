"""Frozen matched-coordinate demand shift using unchanged legacy fixed pairs."""
from pathlib import Path
import argparse, datetime, hashlib, importlib.util, json, math, os, random, statistics, sys, time
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('legacy_pairing',ROOT/'vendor/pairing/experiment.py')
legacy=importlib.util.module_from_spec(spec);spec.loader.exec_module(legacy)
from urp_cvrp.instance import from_dict

def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,v):
    with Path(p).open('x') as f: json.dump(v,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
def read(p): return json.loads(Path(p).read_text())

def make_protocol():
    cfg={'namespace':'dot-independent-cvrp-demand-shift-20261006-v1','split':'dev',
         'geometry_families':['uniform','clustered'],'customer_counts':[20,50], 'replicates_per_cell':6,
         'geometry_seed_base':202610061500,'smoke_geometry_seed':202610061580,
         'demand_modes':['constant5','high_variance_random','high_variance_spatial_x'],
         'random_demand_seed_offset':1000000,'capacity':30,'search_seeds':[613,631,647],
         'smoke_search_seed':659,'schedule_seed':202610061577,
         'pairs':[['random','cheapest'],['random','regret2'],['worst','cheapest'],['worst','regret2']],
         'iterations':100,'delta_limit':100000,'cpu_limit_seconds':2.0,'wall_limit_seconds':5.0,
         'all_numerical_cpu_limit_seconds':180.0,'process_cpu_return_reserve_seconds':3.0,
         'formal_runs':864,'smoke_runs':12,'old_fixed_recommendation':'random_regret2',
         'distance_objective':'sum original unrounded Euclidean depot-to-depot edge distances; no vehicle-count penalty',
         'vehicles':'number of nonempty depot-to-depot routes; report separately, seed-average then equal geometry mean',
         'demand_controls':'All demands sum to 5*n and are <= capacity. constant5 has zero variance; random/spatial both have n/2 ones and n/2 nines. Spatial mode puts nines on largest x (ties y, customer id); changes spatial assignment only relative to random.',
         'coordinate_generation':'Unmodified legacy generator with explicit fresh seeds; generated demands replaced without using old data.',
         'statistics':'First average 3 search seeds within geometry/demand/algorithm. Equal-weight 24 geometries, not 72 demand records or 864 runs, are the paired units. Purely descriptive.',
         'tie_rule':'For mean cost ties use absolute epsilon 1e-9; midrank uses count lower plus half ties. Selected algorithm lexicographically first among costs <= minimum+epsilon.',
         'rank_definition':'Per-demand aggregate ordering by equal-geometry mean relative regret to mean-cost oracle; also report average within-geometry midrank.',
         'distance_loss_definition':'100*(algorithm mean cost / min of four algorithm mean costs - 1). Oracle chooses algorithm after seed-averaging, never lucky seed.',
         'source_transfer':'Choose four-algorithm minimum mean cost on constant5 for each geometry with frozen tie rule; apply that algorithm to each target demand on same geometry. Offline paired analysis only, no trained selector, no external validation.',
         'comparison_to_old':'Prior 432 scale runs and prior 96 pairing runs are provenance only, neither counted as new. PyVRP absent, no package installation; this is a four-pair smaller-pool transfer, not old three-algorithm or paper replication.',
         'failure_rule':'Retain every scheduled row. Missing/invalid/over-budget outcomes never replaced; paired mean statistics only for fully valid 12-run geometry-demand blocks, incomplete blocks explicitly enumerated. Global CPU gate may leave explicit not-run rows; no retries.',
         'isolation':'No network/model/API, training, heldout access, original directory modifications or upload. Vendored algorithm copied byte-for-byte.',
         'cpu_accounting':'Single process; solver + checker individually and whole run process CPU including generation? Inputs already generated; total run process CPU includes imports/load/check/write. Smoke included in same 180-second run ceiling. Freeze/preparation/analysis measured separately.'}
    dump(ROOT/'PROTOCOL.json',cfg)
    entries=[]; geo_index=0
    for stage,specs in [('formal',[(fam,n,r,cfg['geometry_seed_base']+i) for i,(fam,n,r) in enumerate((fam,n,r) for fam in cfg['geometry_families'] for n in cfg['customer_counts'] for r in range(6))]),('smoke',[('uniform',10,0,cfg['smoke_geometry_seed'])])]:
        for fam,n,r,seed in specs:
            inst=legacy.generate_instance(n,fam,seed,30);base=inst.to_dict();geom=f'{fam}-n{n}-r{r}-s{seed}'
            rng=random.Random(seed+cfg['random_demand_seed_offset']);random_demands=[1]*(n//2)+[9]*(n//2);rng.shuffle(random_demands)
            spatial=[1]*n
            order=sorted(range(1,n+1),key=lambda i:(base['coordinates'][i][0],base['coordinates'][i][1],i))
            for node in order[n//2:]:spatial[node-1]=9
            for mode,demands in zip(cfg['demand_modes'],[[5]*n,random_demands,spatial]):
                raw={**base,'instance_id':f'demandshift-{stage}-{geom}-{mode}','demands':[0]+demands}
                instance=from_dict(raw);p=ROOT/'data/instances'/(raw['instance_id']+'.json');dump(p,raw)
                xs=[v[0] for v in raw['coordinates'][1:]];mx=statistics.mean(xs);my=statistics.mean(demands)
                den=math.sqrt(sum((x-mx)**2 for x in xs)*sum((q-my)**2 for q in demands))
                corr=sum((x-mx)*(q-my) for x,q in zip(xs,demands))/den if den else None
                entries.append({'stage':stage,'geometry_id':geom,'family':fam,'n':n,'replicate':r,'geometry_seed':seed,'mode':mode,'file':str(p.relative_to(ROOT)), 'instance_id':instance.instance_id,'sha256':sha(p),'canonical_sha256':instance.sha256,'coordinate_sha256':hashlib.sha256(json.dumps(base['coordinates'],separators=(',',':')).encode()).hexdigest(),'total_demand':sum(demands),'demand_variance':statistics.pvariance(demands),'demand_x_pearson':corr,'capacity_lower_bound_vehicles':math.ceil(sum(demands)/30)})
            geo_index+=1
    dump(ROOT/'data/manifest.json',{'entries':entries,'formal_geometries':24,'formal_demand_instances':72,'smoke_geometries':1,'heldout':'not_read_not_generated_not_evaluated'})
    for stage in ['smoke','formal']:
        seeds=[cfg['smoke_search_seed']] if stage=='smoke' else cfg['search_seeds']
        calls=[{'instance_id':e['instance_id'],'algorithm':'_'.join(pair),'search_seed':s} for e in entries if e['stage']==stage for s in seeds for pair in cfg['pairs']]
        random.Random(cfg['schedule_seed']+(stage=='smoke')).shuffle(calls);dump(ROOT/'data'/f'{stage}_schedule.json',calls)

def verify_freeze():
    frozen=read(ROOT/'PRE_RUN_FREEZE.json')
    bad=[p for p,h in frozen['hashes'].items() if sha(ROOT/p)!=h]
    if bad:raise RuntimeError(f'Frozen inputs/source changed: {bad}')
    changed=[r['source'] for r in read(ROOT/'SOURCE_MANIFEST.json') if sha(r['source'])!=r['sha256']]
    if changed:raise RuntimeError(f'Original sources changed: {changed}')
    return frozen

def execute():
    start_process=time.process_time();start_wall=time.perf_counter();verify_freeze();cfg=read(ROOT/'PROTOCOL.json')
    entries={e['instance_id']:e for e in read(ROOT/'data/manifest.json')['entries']}
    affinity=sorted(os.sched_getaffinity(0));cpu=affinity[-2] if len(affinity)>1 else affinity[0];os.sched_setaffinity(0,{cpu})
    dump(ROOT/'results/RUN_STARTED.json',{'utc':utc(),'pid':os.getpid(),'selected_cpu':cpu,'affinity_before':affinity,'process_cpu_start':start_process,'solver_api_calls_planned':876})
    spent_solver=spent_checker=0;count=0
    for stage in ['smoke','formal']:
        with (ROOT/'results'/f'{stage}.jsonl').open('x') as handle:
            for call in read(ROOT/'data'/f'{stage}_schedule.json'):
                e=entries[call['instance_id']];inst=from_dict(read(ROOT/e['file']))
                base={'stage':stage,'run_index':count,'geometry_id':e['geometry_id'],'demand_mode':e['mode'],'algorithm':call['algorithm'],'search_seed':call['search_seed'],'source_file':e['file']}
                elapsed=time.process_time()-start_process
                if elapsed+cfg['cpu_limit_seconds']+cfg['process_cpu_return_reserve_seconds']>cfg['all_numerical_cpu_limit_seconds']:
                    result={**base,'run_status':'not_run_global_cpu_gate','process_cpu_at_skip':elapsed}
                else:
                    pair=next(p for p in cfg['pairs'] if '_'.join(p)==call['algorithm'])
                    result={**legacy.run_one(inst,pair,call['search_seed'],cfg['iterations'],cfg),**base,'run_status':'executed'}
                    spent_solver+=result['solver_cpu_seconds'];spent_checker+=result['checker_cpu_seconds']
                    out=result['output'];result['vehicle_count']=len(out['routes']) if out else None
                    result['route_loads']=[sum(inst.demands[x] for x in route[1:-1]) for route in out['routes']] if out else None
                    result['closed_routes']=bool(out is not None and all(r[0]==r[-1]==0 for r in out['routes']))
                    result['budget_conformant']=result['solver_cpu_seconds']<=cfg['cpu_limit_seconds'] and result['solver_wall_seconds']<=cfg['wall_limit_seconds']
                    result['scoreable']=bool(result['check']['accepted'] and result['baseline_check']['accepted'] and result['budget_conformant'] and result['error'] is None)
                handle.write(json.dumps(result,ensure_ascii=False,allow_nan=False)+'\n');handle.flush();count+=1
                if count%72==0:print(json.dumps({'completed':count,'process_cpu':time.process_time()-start_process,'wall':time.perf_counter()-start_wall}),flush=True)
    verify_freeze();dump(ROOT/'results/COMPLETION.json',{'finished_utc':utc(),'scheduled_rows':count,'cumulative_solver_cpu_seconds':spent_solver,'cumulative_checker_cpu_seconds':spent_checker,'run_process_cpu_seconds':time.process_time()-start_process,'run_wall_seconds':time.perf_counter()-start_wall,'external_api_calls':0,'model_calls':0,'dependency_installations':0,'frozen_hashes_unchanged':True})

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('command',choices=['prepare','run','verify']);a=p.parse_args()
    {'prepare':make_protocol,'run':execute,'verify':verify_freeze}[a.command]()
