import csv,collections,datetime,hashlib,json,math,pathlib,re,statistics,time
H=pathlib.Path(__file__).resolve().parent;R=H.parents[1]/'independent_cvrp_demand_shift_20261006';read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();start=time.process_time();pins={}
def get(name):pins[name]=sha(R/name);return read(R/name)
p=get('PROTOCOL.json');s=get('results/summary.json');m=get('data/manifest.json');resource=get('results/RESOURCE_ACCOUNTING.json');completion=get('results/COMPLETION.json');audit=read(H/'CHECKS.json')
rows={}
for stage in ['formal','smoke']:
 f=R/f'results/{stage}.jsonl';pins[str(f.relative_to(R))]=sha(f);rows[stage]=[json.loads(l) for l in f.read_text().splitlines()]
resources=[]
for stage in ['formal','smoke']:
 for alg in sorted('_'.join(x) for x in p['pairs']):
  rr=[r for r in rows[stage] if r['algorithm']==alg]
  resources.append({'stage':stage,'algorithm':alg,'planned':len(rr),'executed':sum(r['run_status']=='executed' for r in rr),'scoreable':sum(r['scoreable'] for r in rr),'solver_cpu_seconds':sum(r['solver_cpu_seconds'] for r in rr),'checker_cpu_seconds':sum(r['checker_cpu_seconds'] for r in rr),'solver_wall_seconds':sum(r['solver_wall_seconds'] for r in rr),'total_deltas':sum(r['deltas'] for r in rr),'iterations_completed':sum(r['iterations_completed'] for r in rr),'max_solver_cpu_seconds':max(r['solver_cpu_seconds'] for r in rr),'stop_reasons':json.dumps(dict(collections.Counter(r['stop_reason'] for r in rr)),sort_keys=True)})
for a,b in zip(resources,s['resources']):
 assert a.keys()==b.keys()
 for k,v in a.items():assert (math.isclose(v,b[k],rel_tol=1e-12,abs_tol=1e-9) if isinstance(v,(int,float)) else v==b[k]),(k,v,b[k])
f=R/'results/resources.csv';pins[str(f.relative_to(R))]=sha(f)
with f.open() as h:csvrows=list(csv.DictReader(h))
assert len(csvrows)==8
for got,ex in zip(csvrows,resources):
 for k,v in ex.items():assert (math.isclose(float(got[k]),v,rel_tol=1e-12,abs_tol=1e-9) if isinstance(v,(int,float)) else got[k]==v)
assert collections.Counter(r['stop_reason'] for r in rows['formal'])=={'delta_budget':408,'iteration_budget':456}
assert sum(r['deltas'] for r in rows['formal'])==50803771
trans=read(H/'INDEPENDENT_TRANSFER.json');per=list(csv.DictReader((R/'results/per_geometry_algorithm.csv').open()));fail=[r for r in trans if r['demand_mode']=='high_variance_spatial_x' and not r['source_choice_is_target_best']];assert len(fail)==3
for f in fail:
 source=[r for r in per if r['geometry_id']==f['geometry_id'] and r['demand_mode']=='constant5' and r['is_tied_best']=='True'];assert {r['algorithm'] for r in source}>={'random_cheapest','random_regret2'};assert f['source_selected_algorithm']=='random_cheapest'
assert collections.Counter(r['source_selected_algorithm'] for r in trans if r['demand_mode']=='constant5')=={'random_regret2':15,'random_cheapest':9}
positive_fixed=[r for r in trans if r['demand_mode']=='high_variance_spatial_x' and r['old_fixed_regret_percent']>1e-9];assert len(positive_fixed)==1 and positive_fixed[0]['geometry_id']=='uniform-n20-r2-s202610061502';assert positive_fixed[0]['old_fixed_vehicles']==4
correlations={mode:statistics.mean(e['demand_x_pearson'] for e in m['entries'] if e['stage']=='formal' and e['mode']==mode) for mode in p['demand_modes'][1:]}
assert round(correlations['high_variance_random'],5)==0.05656 and round(correlations['high_variance_spatial_x'],5)==0.85527
f=R/'results/RUN_PROCESS_TIME.txt';pins[str(f.relative_to(R))]=sha(f);times={k:float(v) for k,v in re.findall(r'(\w+)=([\d.]+)',f.read_text())};assert math.isclose(times['full_process_user_cpu_seconds']+times['full_process_system_cpu_seconds'],37.682,abs_tol=1e-9)
assert resource['execute_scope']==completion and resource['complete_solver_executable_cpu_seconds']==37.682 and resource['preparation_cpu_seconds']is None and resource['report_packaging_cpu_seconds']is None
assert resource['analysis_cpu_seconds']==s['analysis_cpu_seconds'];assert resource['launch_attempts'][0]['exit_code']==127 and resource['launch_attempts'][0]['solver_calls']==0
attempts=list(R.rglob('LAUNCH_ATTEMPT_1_STDERR.txt'));assert len(attempts)==1 and '/usr/bin/time' in attempts[0].read_text();pins[str(attempts[0].relative_to(R))]=sha(attempts[0]);assert attempts[0].with_name('LAUNCH_ATTEMPT_1_STDOUT.txt').stat().st_size==0
old=get('source_reference/scale_protocol.json');oldseeds=set()
def harvest(x):
 if isinstance(x,dict):
  for k,v in x.items():
   if 'seed' in k:
    if type(v)is int:oldseeds.add(v)
    elif isinstance(v,list):oldseeds.update(y for y in v if type(y)is int)
   harvest(v)
 elif isinstance(x,list):
  for v in x:harvest(v)
harvest(old);new={e['geometry_seed'] for e in m['entries']}|{e['geometry_seed']+1000000 for e in m['entries']}|set(p['search_seeds'])|{p['smoke_search_seed'],p['schedule_seed']};assert not oldseeds&new
for name in ['REPORT_ZH.md','README.md']:pins[name]=sha(R/name)
res={'status':'PASS_PROSE_AND_ADDITIONAL_NUMERICAL_METADATA','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'resource_csv_rows_verified':8,'total_all_csv_rows_verified':audit['coverage']['csv_rows_verified']+8,'formal_stop_reasons':{'delta_budget':408,'iteration_budget':456},'formal_delta_count':50803771,'spatial_source_transfer_mismatches':3,'all_three_mismatches_from_source_tied_winner':True,'spatial_fixed_loss_positive_geometry_count':1,'source_choices':{'random_regret2':15,'random_cheapest':9},'demand_x_correlations':correlations,'old_scale_explicit_seed_values_checked':sorted(oldseeds),'old_scale_seed_overlap':[],'full_interpreter_cpu_seconds':37.682,'full_interpreter_elapsed_seconds':37.688,'failed_time_launch_before_solver_accounted':True,'source_scope_limitations_present_in_report':True,'no_claim_whole_research_cpu_is37_682':True,'cpu_seconds':time.process_time()-start,'pins':pins,'note':'Final report may receive audit-closure text; final publication receipt binds finalized report and manifest separately.'}
(H/'METADATA_CHECK.json').write_text(json.dumps(res,ensure_ascii=False,indent=2)+'\n');print(json.dumps(res,ensure_ascii=False))
