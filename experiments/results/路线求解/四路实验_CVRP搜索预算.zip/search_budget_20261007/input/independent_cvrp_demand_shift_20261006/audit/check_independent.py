"""Independent saved-evidence audit. Never imports or executes producer modules."""
import collections,csv,datetime,hashlib,json,math,pathlib,random,statistics,traceback,time,resource
H=pathlib.Path(__file__).resolve().parent;R=H.parents[1]/'independent_cvrp_demand_shift_20261006'
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(pathlib.Path(p).read_text())
canon=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False)
mean=statistics.mean;eps=1e-9
pins={};progress=collections.Counter();metrics={};start=time.process_time()
def load(name):pins[name]=sha(R/name);return read(R/name)
def eq(a,b,label=''):
    if isinstance(a,dict):assert a.keys()==b.keys(),(label,a.keys(),b.keys());[eq(a[k],b[k],label+'/'+k) for k in a]
    elif isinstance(a,list):assert len(a)==len(b),(label,len(a),len(b));[eq(x,y,label+'/'+str(i)) for i,(x,y) in enumerate(zip(a,b))]
    elif isinstance(a,(int,float)) and not isinstance(a,bool):assert math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-9),(label,a,b)
    else:assert a==b,(label,a,b)
def csvcheck(name,expected):
    pins[name]=sha(R/name)
    with (R/name).open() as f:rows=list(csv.DictReader(f))
    assert len(rows)==len(expected),(name,len(rows),len(expected))
    for i,(got,exp) in enumerate(zip(rows,expected)):
        assert got.keys()==exp.keys(),(name,i,got.keys(),exp.keys())
        for k,v in exp.items():
            if v is None:assert got[k]==''
            elif isinstance(v,bool):assert got[k]==str(v)
            elif isinstance(v,(int,float)):eq(float(got[k]),v,f'{name}/{i}/{k}')
            else:assert got[k]==v,(name,i,k,got[k],v)
    progress['csv_rows_verified']+=len(rows)
def geometry(n,fam,seed):
    rng=random.Random(seed);out=[[50.,50.]]
    for _ in range(n):
        if fam=='uniform':xy=[rng.uniform(0,100),rng.uniform(0,100)]
        else:
            cx,cy=rng.choice([(25,25),(75,25),(50,75)]);xy=[min(100,max(0,rng.gauss(cx,7))),min(100,max(0,rng.gauss(cy,7)))]
        out.append([round(z,6) for z in xy])
    return out
def routecheck(data,sol):
    assert set(sol)=={'routes','reported_cost'};coords=data['coordinates'];dem=data['demands'];seen=[];edges=[];loads=[]
    for route in sol['routes']:
        assert len(route)>=3 and route[0]==route[-1]==0 and all(type(i)is int and 1<=i<len(coords) for i in route[1:-1])
        seen+=route[1:-1];loads.append(sum(dem[i] for i in route));assert loads[-1]<=data['capacity']
        edges += [math.dist(coords[i],coords[j]) for i,j in zip(route,route[1:])]
    assert sorted(seen)==list(range(1,len(coords)));distance=math.fsum(edges)
    eq(distance,sol['reported_cost']);assert len(sol['routes'])>=math.ceil(sum(dem)/data['capacity'])
    progress['saved_solutions_checked']+=1;progress['customer_visits_checked']+=len(seen);progress['route_edges_recomputed']+=len(edges)
    return distance,len(loads),loads

def main():
    p=load('PROTOCOL.json');freeze=load('PRE_RUN_FREEZE.json')
    assert sha(R/'PRE_RUN_FREEZE.json')=='cec9424e83a2a886bb8835b947b51c96bbe78152994ddf0d08ebdb341e64bdc4'
    assert p==read(H/'pre_run/PROTOCOL.json') and freeze==read(H/'pre_run/PRE_RUN_FREEZE.json')
    for name,h in freeze['hashes'].items():assert sha(R/name)==h,name;pins[name]=h
    sources=load('SOURCE_MANIFEST.json');external={}
    for rec in sources:
        assert sha(rec['source'])==rec['sha256'];external[rec['source']]=rec['sha256']
    assert sha(R/'vendor/pairing/experiment.py')==sha(R.parent/'independent_cvrp_pairing_20261006/experiment.py')
    meta=load('data/manifest.json')['entries'];data={};groups=collections.defaultdict(list)
    for m in meta:
        d=load(m['file']);assert sha(R/m['file'])==m['sha256'];assert hashlib.sha256(canon(d).encode()).hexdigest()==m['canonical_sha256']
        assert d['instance_id']==m['instance_id'] and d['generation_seed']==m['geometry_seed']
        assert d['coordinates']==geometry(m['n'],m['family'],m['geometry_seed'])
        assert d['capacity']==30 and d['demands'][0]==0 and sum(d['demands'])==5*m['n']
        assert all(type(x)is int and 0<=x<=30 for x in d['demands'])
        assert m['coordinate_sha256']==hashlib.sha256(json.dumps(d['coordinates'],separators=(',',':')).encode()).hexdigest()
        if m['mode']=='constant5':assert d['demands'][1:]==[5]*m['n']
        elif m['mode']=='high_variance_random':
            v=[1]*(m['n']//2)+[9]*(m['n']//2);random.Random(m['geometry_seed']+1000000).shuffle(v);assert d['demands'][1:]==v
        else:
            order=sorted(range(1,m['n']+1),key=lambda i:(*d['coordinates'][i],i));assert [d['demands'][i] for i in order]==[1]*(m['n']//2)+[9]*(m['n']//2)
        eq(statistics.pvariance(d['demands'][1:]),m['demand_variance'])
        xs=[c[0] for c in d['coordinates'][1:]];ds=d['demands'][1:];mx=mean(xs);my=mean(ds);den=math.sqrt(sum((x-mx)**2 for x in xs)*sum((q-my)**2 for q in ds));corr=sum((x-mx)*(q-my) for x,q in zip(xs,ds))/den if den else None;eq(corr,m['demand_x_pearson'])
        data[m['instance_id']]=d;groups[m['geometry_id']].append(d);progress['inputs_verified']+=1
    assert len(groups)==25 and len(data)==75
    for ds in groups.values():assert len(ds)==3 and ds[0]['coordinates']==ds[1]['coordinates']==ds[2]['coordinates'];assert sorted(ds[1]['demands'])==sorted(ds[2]['demands'])
    newseeds={m['geometry_seed'] for m in meta}|{m['geometry_seed']+1000000 for m in meta}|set(p['search_seeds'])|{p['smoke_search_seed'],p['schedule_seed']}
    oldseeds=set()
    def harvest(obj):
        if isinstance(obj,dict):
            for k,v in obj.items():
                if 'seed' in k:
                    if type(v)is int:oldseeds.add(v)
                    if isinstance(v,list):oldseeds.update(x for x in v if type(x)is int)
                harvest(v)
        elif isinstance(obj,list):
            for v in obj:harvest(v)
    for folder in ['independent_cvrp_pairing_20261006','independent_cvrp_selection_crc_20261006']:
        for name in ['PLAN.json','PROTOCOL.json','data/manifest.json']:
            file=R.parent/folder/name
            if file.exists():harvest(read(file));external[str(file)]=sha(file)
    assert not newseeds&oldseeds,sorted(newseeds&oldseeds)
    allrows={};verified={};index=0
    for stage,expected_count in [('smoke',12),('formal',864)]:
        schedule=load(f'data/{stage}_schedule.json');assert len(schedule)==expected_count
        pins[f'results/{stage}.jsonl']=sha(R/f'results/{stage}.jsonl');rows=[json.loads(l) for l in (R/f'results/{stage}.jsonl').read_text().splitlines()];assert len(rows)==expected_count
        expected=[{'instance_id':m['instance_id'],'algorithm':'_'.join(pair),'search_seed':seed} for m in meta if m['stage']==stage for seed in ([p['smoke_search_seed']] if stage=='smoke' else p['search_seeds']) for pair in p['pairs']]
        random.Random(p['schedule_seed']+(stage=='smoke')).shuffle(expected);assert expected==schedule
        for r,call in zip(rows,schedule):
            assert all(r[k]==v for k,v in call.items()) and r['run_index']==index;index+=1;assert r['stage']==stage
            if r['run_status']!='executed':progress['not_run_rows']+=1;continue
            d=data[r['instance_id']];final,vehicles,loads=routecheck(d,r['output']);initial,iv,il=routecheck(d,r['baseline'])
            eq(final,r['check']['recomputed_cost']);eq(initial,r['baseline_check']['recomputed_cost']);assert r['check']['accepted'] and r['baseline_check']['accepted'];assert vehicles==r['vehicle_count'] and loads==r['route_loads'] and r['closed_routes']
            assert r['instance_sha256']==hashlib.sha256(canon(d).encode()).hexdigest();assert r['algorithm']==r['pair'];assert r['budget_conformant']==(r['solver_cpu_seconds']<=2 and r['solver_wall_seconds']<=5)
            assert r['scoreable']==bool(r['check']['accepted'] and r['baseline_check']['accepted'] and r['budget_conformant'] and r['error'] is None)
            assert r['deltas']==sum(r['delta_by_kind'].values())<=100000 and r['matrix_distances']==(r['n']+1)**2
            prev=initial;accepted=0;pd=0
            for ti,t in enumerate(r['trace']):
                assert t['iteration']==ti and pd<=t['deltas']<=r['deltas'];pd=t['deltas']
                seed=int.from_bytes(hashlib.sha256(f"{r['search_seed']}/q/{ti}".encode()).digest()[:8],'big');lo=min(r['n'],max(2,math.ceil(.1*r['n'])));hi=min(r['n'],max(lo,math.ceil(.3*r['n'])));assert t['q']==random.Random(seed).randint(lo,hi)
                improved=t['candidate_cost']<prev-1e-9;assert improved==t['accepted'];accepted+=improved;prev=t['candidate_cost'] if improved else prev;eq(prev,t['incumbent_cost']);progress['saved_cost_trace_entries_checked']+=1
            eq(prev,final);assert len(r['trace'])==r['iterations_completed']<=r['iterations_started']<=100;assert accepted==r['accepted_improvements'];eq((initial-final)/initial,r['improvement_fraction'])
            verified[(r['geometry_id'],r['demand_mode'],r['algorithm'],r['search_seed'])]=(final,vehicles,initial);progress[stage+'_runs_verified']+=1
        allrows[stage]=rows
    algs=sorted('_'.join(x) for x in p['pairs']);modes=p['demand_modes'];idx=collections.defaultdict(list)
    for r in allrows['formal']:idx[(r['geometry_id'],r['demand_mode'],r['algorithm'])].append(r)
    per=[];rec={};incomplete=[]
    for geo in sorted({r['geometry_id'] for r in allrows['formal']}):
        for mode in modes:
            if any(len(idx[geo,mode,a])!=3 or not all(r['scoreable'] for r in idx[geo,mode,a]) for a in algs):incomplete.append({'geometry_id':geo,'demand_mode':mode});continue
            vals={a:mean(verified[geo,mode,a,r['search_seed']][0] for r in idx[geo,mode,a]) for a in algs};best=min(vals.values());winners=[a for a in algs if vals[a]<=best+eps]
            for a in algs:
                rs=idx[geo,mode,a];base=mean(verified[geo,mode,a,r['search_seed']][2] for r in rs);v=vals[a];rank=(sum(x<v-eps for x in vals.values())+1+sum(x<=v+eps for x in vals.values()))/2
                z={'geometry_id':geo,'demand_mode':mode,'family':rs[0]['family'],'n':rs[0]['n'],'algorithm':a,'mean_distance':v,'mean_vehicles':mean(verified[geo,mode,a,r['search_seed']][1] for r in rs),'mean_savings_distance':base,'improvement_over_savings_percent':100*(base-v)/base,'mean_cost_oracle':best,'relative_distance_regret_percent':100*(v/best-1),'midrank':rank,'is_tied_best':a in winners,'chosen_best':winners[0]};per.append(z);rec[geo,mode,a]=z
    csvcheck('results/per_geometry_algorithm.csv',per)
    agg=[]
    for mode in modes:
        for a in algs:
            xs=[r for r in per if r['demand_mode']==mode and r['algorithm']==a];agg.append({'demand_mode':mode,'algorithm':a,'geometry_count':len(xs),'mean_distance':mean(r['mean_distance'] for r in xs),'mean_vehicles':mean(r['mean_vehicles'] for r in xs),'mean_relative_regret_percent':mean(r['relative_distance_regret_percent'] for r in xs),'mean_improvement_over_savings_percent':mean(r['improvement_over_savings_percent'] for r in xs),'mean_midrank':mean(r['midrank'] for r in xs),'tied_best_count':sum(r['is_tied_best'] for r in xs)})
    csvcheck('results/aggregate.csv',agg);trans=[];changes=[]
    for geo in sorted({k[0] for k in rec}):
        choice=rec[geo,modes[0],algs[0]]['chosen_best'];old=p['old_fixed_recommendation']
        for mode in modes:
            winners=[a for a in algs if rec[geo,mode,a]['is_tied_best']];s=rec[geo,mode,choice];f=rec[geo,mode,old]
            trans.append({'geometry_id':geo,'demand_mode':mode,'source_selected_algorithm':choice,'target_winners':'|'.join(winners),'source_choice_is_target_best':choice in winners,'source_selected_distance':s['mean_distance'],'source_selected_vehicles':s['mean_vehicles'],'source_selected_regret_percent':s['relative_distance_regret_percent'],'old_fixed_algorithm':old,'old_fixed_distance':f['mean_distance'],'old_fixed_vehicles':f['mean_vehicles'],'old_fixed_regret_percent':f['relative_distance_regret_percent'],'target_mean_cost_oracle':f['mean_cost_oracle']})
        for mi,mj in [(0,1),(0,2),(1,2)]:
            x,y=modes[mi],modes[mj];wx={a for a in algs if rec[geo,x,a]['is_tied_best']};wy={a for a in algs if rec[geo,y,a]['is_tied_best']};strict=rev=ties=0
            for ai in range(4):
                for aj in range(ai+1,4):
                    dx=rec[geo,x,algs[ai]]['mean_distance']-rec[geo,x,algs[aj]]['mean_distance'];dy=rec[geo,y,algs[ai]]['mean_distance']-rec[geo,y,algs[aj]]['mean_distance'];sx=0 if abs(dx)<=eps else (1 if dx>0 else -1);sy=0 if abs(dy)<=eps else (1 if dy>0 else -1);strict+=bool(sx and sy);rev+=sx*sy==-1;ties+=(sx==0)!=(sy==0)
            changes.append({'geometry_id':geo,'from_mode':x,'to_mode':y,'common_best_exists':bool(wx&wy),'winner_set_changed':wx!=wy,'strict_comparable_algorithm_pairs':strict,'strict_reversals':rev,'tie_status_changes':ties})
    csvcheck('results/transfer.csv',trans);csvcheck('results/rank_changes.csv',changes)
    tsum=[]
    for mode in modes:
        xs=[r for r in trans if r['demand_mode']==mode];bas={r['geometry_id']:r for r in trans if r['demand_mode']==modes[0]};tsum.append({'demand_mode':mode,'geometries':len(xs),'source_selected_not_best_count':sum(not r['source_choice_is_target_best'] for r in xs),'source_selected_mean_regret_percent':mean(r['source_selected_regret_percent'] for r in xs),'source_selected_max_regret_percent':max(r['source_selected_regret_percent'] for r in xs),'old_fixed_mean_regret_percent':mean(r['old_fixed_regret_percent'] for r in xs),'old_fixed_max_regret_percent':max(r['old_fixed_regret_percent'] for r in xs),'paired_change_old_fixed_regret_percentage_points':mean(r['old_fixed_regret_percent']-bas[r['geometry_id']]['old_fixed_regret_percent'] for r in xs),'source_selected_mean_vehicles':mean(r['source_selected_vehicles'] for r in xs),'old_fixed_mean_vehicles':mean(r['old_fixed_vehicles'] for r in xs)})
    rsum=[]
    for mi,mj in [(0,1),(0,2),(1,2)]:
        x,y=modes[mi],modes[mj];xs=[r for r in changes if r['from_mode']==x and r['to_mode']==y];rsum.append({'from_mode':x,'to_mode':y,'geometries':len(xs),'winner_set_changed_count':sum(r['winner_set_changed'] for r in xs),'no_common_best_count':sum(not r['common_best_exists'] for r in xs),'strict_comparable_pairs':sum(r['strict_comparable_algorithm_pairs'] for r in xs),'strict_reversals':sum(r['strict_reversals'] for r in xs),'geometries_with_strict_reversals':sum(r['strict_reversals']>0 for r in xs),'tie_status_changes':sum(r['tie_status_changes'] for r in xs)})
    result=load('results/summary.json');eq(result['aggregate'],agg);eq(result['transfer'],tsum);eq(result['ranking_changes'],rsum);eq(result['incomplete_geometry_demand_blocks'],incomplete)
    assert result['formal_executed']==result['formal_scoreable']==result['formal_scheduled']==864 and result['smoke_scheduled']==result['smoke_scoreable']==12
    done=load('results/COMPLETION.json');assert done['scheduled_rows']==876 and done['run_process_cpu_seconds']<=180 and done['external_api_calls']==done['model_calls']==done['dependency_installations']==0 and done['frozen_hashes_unchanged']
    eq(done['cumulative_solver_cpu_seconds'],sum(r['solver_cpu_seconds'] for rs in allrows.values() for r in rs));eq(done['cumulative_checker_cpu_seconds'],sum(r['checker_cpu_seconds'] for rs in allrows.values() for r in rs))
    for name,h in pins.items():assert sha(R/name)==h,name
    for path,h in external.items():assert sha(path)==h,path
    report={'status':'PASS_SAVED_NUMERICAL_EVIDENCE','finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'coverage':dict(progress),'new_formal_executions':864,'new_smoke_executions':12,'historical_runs_counted_as_new':0,'new_seed_metadata_overlap':[],'named_old_seed_count':len(oldseeds),'paired_formal_geometries':24,'source_pool_identical':True,'distance_and_vehicles_separate':True,'aggregate':agg,'transfer':tsum,'rank_changes':rsum,'author_execution_cpu_seconds':done['run_process_cpu_seconds'],'checker_cpu_seconds':time.process_time()-start,'limitations':['Scalar trace consistency verified, not missing intermediate candidate route feasibility or internal evaluation count arithmetic.','Scores are distance-only with vehicles descriptive; no lexicographic fleet benchmark.','24 paired synthetic geometries, offline source-conditioned transfer, no learned deployment selector or heldout/generalization/SOTA reproduction claim.','Static source and hash audit, not OS syscall provenance or exact all-in CPU attestation.','Author final prose/release manifest require metadata review when available.']}
    (H/'CHECKS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');(H/'SOURCE_PINS.json').write_text(json.dumps({'files':pins,'external':external},indent=2)+'\n');(H/'INDEPENDENT_TRANSFER.json').write_text(json.dumps(trans,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False))
try:main()
except BaseException as ex:
    (H/'FAILURE.json').write_text(json.dumps({'error':repr(ex),'traceback':traceback.format_exc(),'partial_coverage':dict(progress),'checker_cpu_seconds':time.process_time()-start},indent=2)+'\n');raise
