# 独立 CVRP 固定 destroy/repair 配对实验

## 结论先行

预定 96 次正式运行与 16 次独立 smoke 均已实际完成，全部通过独立可行性和成本检查，0 次算法失败。8 个合成开发实例等权、实例内先平均 3 个搜索种子后，random + regret-2 在此面板上平均改善最高：**1.4952%**。其余依次为 random + cheapest 0.6485%、worst + regret-2 0.4838%、worst + cheapest 0.2480%。这只是固定小型开发面板结果，不能据此宣称统计普适性、完整 G-LNS 复现或农业田间有效。

## 冻结与范围

- PLAN.json 冻结时间：2026-10-06T02:51:01.274854+00:00；FREEZE.json 保存计划哈希，PRE_RUN_SHA256SUMS.txt 在首次实验前保存实现及依赖哈希
- 新数据：uniform/clustered × n20/n50 × 2 实例重复，容量 30；另有两个 n10 smoke 实例。新命名种子以 SHA-256 派生，见 PLAN.json；没有读取旧 holdout 或旧数据文件
- **每轮 q 在 ceil(0.1n)–ceil(0.3n) 之间均匀变化，同实例/搜索种子下四配对共用 q 序列**。这是运行前独立冻结的版本，随后收到固定20%移除建议时没有更改计划。因此不能称为固定20%移除实验
- uniform 与 clustered 是自制合成欧氏 CVRP 开发分布，车辆数不限、同质车辆、仓库0、距离不取整；源生成器原样复制，只调用 generate_instance，未调用带旧 seed 字段的 generate_from_config
- 单进程并固定一核，独立无 pip 的 stdlib venv；无包安装、模型调用、自适应选择或主实验数据串用，原五个组件源文件哈希未变
- 概念来源为 [G-LNS 固定提交](https://github.com/ZBoyn/G-LNS/tree/ea834aaa23a6952ff5e47d377940ec38b7e97482) 的成对接口思想；没有下载执行其代码，没有 LLM/双种群/共演化，也未检验其累计 synergy 评分

## 算法契约

统一使用 parallel Clarke-Wright savings 初解。这里的实现保留可信 baselines.py 的排序、端点合并与平局规则，并逐次显式记 savings delta；smoke 单元测试逐项与原 baseline 输出一致。只接受目标降低超过 1e-9 的完整候选；预算在半轮耗尽时丢弃半成品，返回此前完整 incumbent。

- random：从现有客户均匀不放回抽 q 个
- worst：每删除一个客户都重新计算所有剩余客户的边际距离节省，选最大；同分按客户编号
- cheapest：每步枚举所有待插客户在所有容量可行路线位置的 delta，含开一条新路线，选全局最便宜；平局按客户、路线、位置
- regret-2：先取每客户在每条可行路线的最佳插入位置，再在不同路线（含新路线）的两个最佳代价间求 regret，优先最大 regret；只有一个可行路线时记无限 regret。每插一步都更新载重
- destroy 和 repair 均复制路线，不修改冻结元组形式的坐标或需求

## 实际结果

统计单位是 **8 个实例**，搜索种子是实例内重复，不能把24个run当成24个独立实例。排名为每实例四配对的 midrank（允许并列）后平均。

| 配对 | 等实例权均值改善 | 平均midrank | 验收通过 | delta截断 | 实际delta总数 | CPU秒 | wall秒 |
|---|---:|---:|---:|---:|---:|---:|---:|
| random_regret2 | 1.4952% | 1.188 | 24/24 | 12 | 1,385,072 | 0.9242 | 0.9297 |
| random_cheapest | 0.6485% | 2.312 | 24/24 | 12 | 1,376,795 | 0.9465 | 0.9462 |
| worst_regret2 | 0.4838% | 3.000 | 24/24 | 10 | 1,401,129 | 0.9645 | 0.9554 |
| worst_cheapest | 0.2480% | 3.500 | 24/24 | 9 | 1,349,760 | 0.9399 | 0.9358 |

每实例结果（百分比；各自3种子均值）：

| 实例 | random+cheapest | random+regret2 | worst+cheapest | worst+regret2 |
|---|---:|---:|---:|---:|
| 1 / uniform n20 / r0 | 0.5903% | 0.5903% | 0.0000% | 0.5903% |
| 2 / uniform n20 / r1 | 0.4312% | 0.9117% | 0.0000% | 0.0000% |
| 3 / uniform n50 / r0 | 0.7039% | 3.2379% | 0.8870% | 0.8328% |
| 4 / uniform n50 / r1 | 0.5476% | 1.7545% | 0.0000% | 0.0736% |
| 5 / clustered n20 / r0 | 0.0354% | 0.0354% | 0.0000% | 0.0000% |
| 6 / clustered n20 / r1 | 1.2429% | 2.1409% | 0.0000% | 0.0000% |
| 7 / clustered n50 / r0 | 0.4973% | 0.8692% | 0.0000% | 0.0000% |
| 8 / clustered n50 / r1 | 1.1395% | 2.4219% | 1.0970% | 2.3736% |

random+regret2 在8实例均为并列或单独第一，但只有两个分布、两个规模、每格两个实例，不做显著性推断。各配对仍有较多重复最终路线，详见 CSV；相同结果不被当成新增独立证据。

## 描述性交互

将改善百分比记为 Y，报告 (Y_worst,regret2 − Y_worst,cheapest) − (Y_random,regret2 − Y_random,cheapest)，在8实例平均为 **-0.610917 个百分点**。即本面板上 regret-2 相对 cheapest 的收益，对 random destroy 比对 worst destroy 大约多 0.611 个百分点。这是固定配对的描述性差中之差；不是 G-LNS synergy 分数验证、显著性检验或因果机制证明。逐实例差异另存 summary.json。

## 资源与失败完整账本

- 正式：96 真正运行，53 次完成100迭代，43 次达到100000 delta；0算法异常，0 CPU或wall超时，0补样，0更换种子
- 正式求解：累计 3.775123 CPU秒、3.767056 墙钟秒；单run最大CPU 0.071998秒、最大墙钟 0.071439秒；总delta 5,512,756
- CPU/墙钟覆盖每次的矩阵、savings初解、搜索、结果封装与预算检查；独立checker在返回后运行，另计正式checker CPU 0.004027秒。进程启动、数据生成、JSON磁盘写入、汇总/绘图不在求解CPU范围内
- 计数在算术表达式之前发生，savings增益、worst removal收益、每个插入位置/新路线的delta均逐次计数，重复重算重复收费；总矩阵距离计算 146,016 次，完整目标边读取 326,944 次另列
- 每run同时受100迭代、100000 delta、2秒CPU和5秒硬墙钟上限约束；CPU/墙钟定时器与每个delta前合作检查双保险。累计正式CPU上限192秒也有总量门禁
- **相同迭代/delta上限不代表相同实际工作量**：worst额外支付删除收益计算；cheapest与regret-2的排序/选择成本也不同，构造距离与全目标检查另计。部分run首先达到迭代上限，其他首先达到delta上限。因此这里比较的是同上限配置下各自轨迹，不是纯算子机制在完全等CPU、等完整迭代或等候选分布条件下的因果消融
- smoke完全单独记账，不进入正式统计

## 验证

9项 unittest 通过，含11个非法输出负例、可信savings对齐、所有配对可行性与不污染输入、新路线容量兜底、delta先检查、插入选项精确计数、预算中断保留可行初解、种子重放。实际正式/烟雾结果均经 vendor checker 从原始坐标重算：每客户恰好一次、路线仓库起终点、无中间仓库、编号合法、容量、欧氏距离与上报成本一致。

二次审计只读取落盘路线，不重跑优化器：112run的最终解与初解共224次重新验收，全部通过；验证96唯一预定槽位完整、预算上限、原始数据哈希、源组件未变、各实例初解一致、共用q序列、incumbent单调。结果见 results/AUDIT.json 与 checker_revalidation.jsonl。

## 文件与复现

- experiment.py：完整求解与运行器；test_experiment.py：小范围单元/负向测试
- PLAN.json / PLAN.md / FREEZE.json / PRE_RUN_SHA256SUMS.txt：运行前冻结证据
- SOURCE_MANIFEST.json / vendor/：本地可信来源与原样副本
- data/manifest.json / *.json：仅本次新生成开发实例、来源命名、文件哈希、canonical哈希
- results/formal.jsonl / smoke.jsonl：逐run输出路线、checker、trace、预算与种子完整原始账本
- results/per_run.csv / per_instance_pair.csv / summary.json：可审计汇总
- figures/pairing_results.svg：stdlib生成的可缩放科研图；PNG以相同落盘汇总用系统已有Pillow绘制，仅供呈现，不是求解依赖，也未安装或更改全局包。SVG转换工具缺少rsvg委托，因此没有使用该转换结果

程序默认拒绝覆写已存在stage结果。如要复现应在新副本中明确使用新的输出目录，不能直接覆盖本次证据。
