# CVRP matched-coordinate demand shift

阅读 REPORT_ZH.md。此包新增864次正式和12次小例求解，不是旧432次数据回放。使用既有4个固定destroy/repair配对；当前环境无PyVRP且未安装。24几何、3种等总需求、4算法、3搜索种子，纯距离目标，车辆单独报告。

原始数据、协议、输入、算法源码、逐路线验证和成本都在包内，正式采样仅为development，未触碰holdout。无需第三方依赖，Python 3.12标准库即可检查。

验证冻结：python -B src/experiment.py verify

本目录拒绝覆盖既有求解和分析结果。若要重新求解，请把整个包复制到新的明确replay目录，再把副本results移到archive_original_results并新建results；src/experiment.py run会使用冻结输入和顺序，不重新生成数据；src/analyze.py随后生成新汇总。重放属于新的成本账本，不能作为新几何样本。verify同时检查原始旧来源路径；若迁移到另一台机器，旧路径不存在会阻止执行，应该先由审计者核验SOURCE_MANIFEST中的副本SHA并建立明确的新环境来源映射，不要悄悄跳过源pin检查。当前包承诺本工作区可追溯，未宣称任意机器免适配重放。

仅在独立审计放行后归档；数值运行阶段未上传任何未审稿。

便携只读证据验证：python -B src/verify_bundle.py
该辅助脚本在数值运行后新增，未冒充事前冻结源码；它核对包内冻结文件、来源副本和最终manifest，不执行solver、不要求原机器绝对路径存在。原来源在场时也核对其哈希；路线独立审计另附。
