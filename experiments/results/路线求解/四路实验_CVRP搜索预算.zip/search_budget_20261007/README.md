# CVRP等评价预算消融证据包

入口：reports/REPORT_ZH.md。288条正式轨迹，4个预冻结相关检查点，16个standalone等价性smoke参考运行；详细协议见freeze/PROTOCOL.json。

## 复核

1. 验证SHA256SUMS.txt以及freeze/PRE_RUN_FREEZE.json中的哈希。
2. 查看raw/SMOKE.json的all_passed，以及raw/RESOURCE.json退出码。
3. 从raw/TRAJECTORIES.jsonl直接重算距离、容量、客户覆盖和各预算统计。分析代码在analysis/analyze.py，不依赖第三方库。
4. 原包和原解压内容完整保留在input，历史结果只用于来源留存。

## 重新运行

需要Python 3.10及以上和Linux标准库，无依赖安装、网络或API。

为避免覆盖证据，必须在新的空目录建立复现实验副本。复制source、input、freeze、analysis四个目录，再创建空raw、reports、failures目录；不要复制已经生成的结果。保留所有冻结文件原字节。运行：

python -B source/launch.py
python -B analysis/time_phase.py ANALYSIS python -B analysis/analyze.py

代码采用排他新建模式，遇到已存在结果会停止。复制冻结的source后不要运行prepare.py，它只用于第一次冻结。freeze/PRE_RUN_FREEZE.json保存的是相对于包根目录的哈希。

本轮未上传外部；父线程独立审计和Drive归档在本任务完成后另行处理。
