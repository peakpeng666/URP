from pathlib import Path
import datetime,json,os,resource,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[1]
start=time.perf_counter();ru=resource.getrusage(resource.RUSAGE_CHILDREN)
with (ROOT/'raw/STDOUT.jsonl').open('x') as out,(ROOT/'raw/STDERR.txt').open('x') as err:
 p=subprocess.Popen([sys.executable,'-B',str(ROOT/'source/experiment.py')],stdout=out,stderr=err,start_new_session=True)
 try: rc=p.wait(timeout=900)
 except subprocess.TimeoutExpired:
  os.killpg(p.pid,9);rc=p.wait()
end=resource.getrusage(resource.RUSAGE_CHILDREN)
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':rc,'child_user_cpu_seconds':end.ru_utime-ru.ru_utime,'child_system_cpu_seconds':end.ru_stime-ru.ru_stime,'child_total_cpu_seconds':end.ru_utime+end.ru_stime-ru.ru_utime-ru.ru_stime,'launcher_cpu_seconds':time.process_time(),'wall_seconds':time.perf_counter()-start,'child_hard_cpu_limit':151,'wall_timeout':900,'maxrss_kib':end.ru_maxrss}
with (ROOT/'raw/RESOURCE.json').open('x') as f:json.dump(result,f,indent=2)
print(json.dumps(result))
raise SystemExit(rc)
