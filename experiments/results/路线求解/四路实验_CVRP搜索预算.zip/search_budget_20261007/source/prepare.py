from pathlib import Path
import datetime, hashlib, json, random, time
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'input/independent_cvrp_demand_shift_20261006'
def dump(p,d):
 with p.open('x') as f: json.dump(d,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
cfg={
 'name':'CVRP matched equal-delta budget ablation 20261007','source_zip_sha256':'11edf911bfa2aaf75bfb1154e14d65bf4b3d35ba816aee77aa806baa1c10cfee',
 'subset_rule':'Before any new numerical run, take existing formal replicates r0 and r1 from each family (uniform,clustered) x customer count (20,50), all three demand modes. No result-based selection, expansion, or retries.',
 'replicates':[0,1],'geometry_count':8,'demand_modes':['constant5','high_variance_random','high_variance_spatial_x'],
 'search_seeds':[17011,17027,17041], 'seed_rule':'Fresh search seeds, paired across algorithms and demand modes. Delta counts not RNG iteration alignments determine checkpoint.',
 'pairs':[['random','cheapest'],['random','regret2'],['worst','cheapest'],['worst','regret2']],
 'checkpoints':[2500,10000,40000,160000],'schedule_seed':202610070242,'smoke_seed':17053,
 'formal_trajectories':288,'formal_checkpoint_observations':1152,'smoke_long_trajectories':4,'smoke_independent_reference_runs':16,
 'eval_unit':'Original implementation candidate delta arithmetic: savings + removal + insertion, charged immediately before expression. Includes initialization savings; excludes distance matrix, full objective edges and checker recomputation, all separately counted or measured. Not a uniform FLOP or elapsed-time budget.',
 'objective':'Unrounded Euclidean depot-to-depot edge sum, no vehicle penalty. Return last complete incumbent with every customer exactly once and route demand <=30. Legacy independent checker recomputes coordinates and loads.',
 'algorithm_changes':'Legacy operators copied byte-for-byte. New runner removes 100-iteration cap, retaining strict-improvement acceptance and deterministic per-iteration seed derivation; raises no new operators. Budget is sole normal stopping rule.',
 'checkpoint_semantics':'Before requesting delta B+1, save latest completed incumbent after all uncounted operations at count B. This equals standalone legacy stopping at B when CPU/wall limits do not bind; smoke verifies all four budgets and all four algorithms.',
 'dependence':'One maximum-budget trajectory per geometry x demand x seed x algorithm. Four checkpoints are strongly correlated repeated measures, NOT 1152 independent runs. Seeds and demands also paired within geometry; geometry is primary descriptive unit.',
 'statistics':'Average 3 seeds within geometry/demand/algorithm/budget. Relative regret=100*(mean cost / minimum algorithm mean cost-1). Equal-weight 3 demands within geometry then 8 geometries for overall means. Ranking by mean relative regret; per-demand rankings and per-geometry midranks secondary. No inferential significance claims.',
 'ties':'Cost absolute tolerance 1e-9; midrank 1+number smaller+half number other ties. Aggregate ranking ties 1e-9; lexicographic display only.',
 'saturation':'Predefined practical plateau: within-algorithm mean paired cost gain from 40000 to160000 <=0.5%, and >=75% of geometry-demand seed-averaged blocks gain <=0.5%. Describe earlier gains separately; finite-budget plateau is not asymptotic convergence.',
 'failed_case_rule':'Keep every planned trajectory and checkpoint status. Never impute missing scores, rerun, replace or expand. Main curve common support requires all algorithms,seeds,budgets for a geometry-demand block, and overall means require all three demand blocks for a geometry; incomplete coverage enumerated. Failures remain first-class outcomes.',
 'limits':'Single Python process, no solver children. Full process CPU hard 151 seconds; formal soft gate reserves up to7 seconds below140. Preparation, analysis, selfchecks and packaging measured separately; all task process-tree total under180 seconds. Parent independent audit has own budget. Task wall20minutes, runner wall14minutes.',
 'per_trajectory_cpu_limit':2.0,'per_trajectory_wall_limit':30.0,'process_cpu_soft_gate':140.0,'process_cpu_hard_limit':150,'return_reserve_cpu':5.0,'execution_wall_limit':840.0,
 'speed_interpretation':'Concurrent cloud workloads; CPU/wall disclosed only, never wall-time algorithm speed ranking.',
 'scope':'Reused development geometries, smaller four-pair pool. Historical864+12 are provenance only. No PyVRP, no SOTA claim, no heldout evaluation, no model/API/paid calls, no new dependencies, no external upload.'}
assert sha(ROOT/'input/original.zip')==cfg['source_zip_sha256']
entries=json.loads((OLD/'data/manifest.json').read_text())['entries']; selected=[e for e in entries if e['stage']=='formal' and e['replicate'] in cfg['replicates']]
assert len(selected)==24 and len({e['geometry_id'] for e in selected})==8
for e in selected: e['input_file']=str((OLD/e['file']).relative_to(ROOT));assert sha(ROOT/e['input_file'])==e['sha256']
dump(ROOT/'freeze/PROTOCOL.json',cfg);dump(ROOT/'freeze/INPUT_MANIFEST.json',selected)
smoke=next(e for e in entries if e['stage']=='smoke' and e['mode']=='constant5');smoke['file']=str((OLD/smoke['file']).relative_to(ROOT));dump(ROOT/'freeze/SMOKE.json',smoke)
schedule=[{'geometry_id':e['geometry_id'],'family':e['family'],'n':e['n'],'replicate':e['replicate'],'demand_mode':e['mode'],'input_file':e['input_file'],'input_sha256':e['sha256'],'search_seed':s,'algorithm':'_'.join(p),'pair':p} for e in selected for s in cfg['search_seeds'] for p in cfg['pairs']]
random.Random(cfg['schedule_seed']).shuffle(schedule)
for i,r in enumerate(schedule):r['run_id']=i
assert len(schedule)==288
dump(ROOT/'freeze/SCHEDULE.json',schedule)
files=sorted(p for directory in [ROOT/'source',ROOT/'input',ROOT/'freeze'] for p in directory.rglob('*') if p.is_file())
dump(ROOT/'freeze/PRE_RUN_FREEZE.json',{'frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'numerical_runs_before_freeze':0,'sha256':{str(p.relative_to(ROOT)):sha(p) for p in files}})
print(sha(ROOT/'freeze/PRE_RUN_FREEZE.json'))
