from pathlib import Path
import datetime,hashlib,json,time,zipfile
ROOT=Path(__file__).resolve().parents[1];start=time.process_time()
def dump(p,x):
 with p.open('x') as f:json.dump(x,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
old=ROOT/'input/independent_cvrp_demand_shift_20261006/vendor/pairing'
links=[]
for p in sorted((ROOT/'source/legacy').rglob('*.py')):
 o=old/p.relative_to(ROOT/'source/legacy');assert p.read_bytes()==o.read_bytes()
 links.append({'source':str(o.relative_to(ROOT)),'copy':str(p.relative_to(ROOT)),'sha256':sha(p),'byte_identical':True})
dump(ROOT/'reports/SOURCE_MANIFEST.json',{'legacy_files':links,'new_runner':'source/experiment.py','analysis_written_after_formal_started':True,'analysis_methods_predeclared_in':'freeze/PROTOCOL.json'})
frozen=json.loads((ROOT/'freeze/PRE_RUN_FREEZE.json').read_text());assert all(sha(ROOT/p)==h for p,h in frozen['sha256'].items())
rows=[json.loads(x) for x in (ROOT/'raw/TRAJECTORIES.jsonl').read_text().splitlines()]
checks={'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'normal_delta_stops':sum(r['stop_reason']=='delta_budget' and r['error'] is None for r in rows),'all_checkpoint_cpu_wall_within_limits':all(c['solver_cpu_seconds']<2 and c['solver_wall_seconds']<30 for r in rows for c in r['checkpoints']),'all_legacy_sources_byte_identical':True,'all_frozen_hashes_unchanged':True}
assert checks['normal_delta_stops']==288 and checks['all_checkpoint_cpu_wall_within_limits']
dump(ROOT/'reports/STOP_AND_FREEZE_CHECK.json',checks)
run=json.loads((ROOT/'raw/RESOURCE.json').read_text());analysis=json.loads((ROOT/'raw/ANALYSIS_RESOURCE.json').read_text())
measured=run['child_total_cpu_seconds']+run['launcher_cpu_seconds']+analysis['child_total_cpu_seconds']+analysis['launcher_cpu_seconds']
dump(ROOT/'reports/RESOURCE_ACCOUNTING.json',{'experiment_process_tree_cpu_seconds':run['child_total_cpu_seconds'],'experiment_launcher_cpu_seconds':run['launcher_cpu_seconds'],'analysis_process_tree_cpu_seconds':analysis['child_total_cpu_seconds'],'analysis_launcher_cpu_seconds':analysis['launcher_cpu_seconds'],'measured_completed_phases_cpu_seconds':measured,'preparation_shell_conservative_allowance_seconds':10.0,'allowance_is_not_measured':True,'finalization_packaging_reserve_seconds':10.0,'conservative_measured_plus_allowances_cpu_seconds':measured+20,'cpu_limit_seconds':180,'finalization_measurement_file':'../search_budget_20261007_pre_audit.resource.json','wall_limit_seconds':1200,'numerical_task_start_utc':'2026-10-07T02:42:47+00:00','note':'Only one numeric solver process; no solver descendants. Parent independent audit is a separate task.'})
# Manifest deliberately excludes itself, SHA listing, and the archive outside ROOT.
files=sorted(p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name not in ['FILE_MANIFEST.json','SHA256SUMS.txt'])
manifest={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'EXECUTOR_SELF_CHECKED_PENDING_PARENT_INDEPENDENT_AUDIT','files':[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files]}
dump(ROOT/'FILE_MANIFEST.json',manifest)
files.append(ROOT/'FILE_MANIFEST.json')
with (ROOT/'SHA256SUMS.txt').open('x') as f:
 for p in sorted(files):f.write(sha(p)+'  '+str(p.relative_to(ROOT))+'\n')
files.append(ROOT/'SHA256SUMS.txt')
archive=ROOT.parent/'search_budget_20261007_pre_audit.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(files):z.write(p,arcname=str(Path(ROOT.name)/p.relative_to(ROOT)))
metadata={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'finalization_cpu_seconds':time.process_time()-start,'content_files':len(files),'status':'pending_parent_independent_audit'}
dump(ROOT.parent/'search_budget_20261007_pre_audit.archive.json',metadata)
print(json.dumps(metadata))
