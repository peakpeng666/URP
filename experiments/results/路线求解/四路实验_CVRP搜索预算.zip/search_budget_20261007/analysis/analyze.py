"""Descriptive aggregation exactly as specified in frozen PROTOCOL.json."""
from pathlib import Path
from collections import defaultdict,Counter
import csv,datetime,hashlib,itertools,json,math,statistics,time
ROOT=Path(__file__).resolve().parents[1]
start=time.process_time()
def read(p):return json.loads(p.read_text())
def dump(p,d):
 with p.open('x') as f:json.dump(d,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
def csvout(name,rows):
 with (ROOT/'reports'/name).open('x',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def mean(xs):return statistics.mean(xs)
cfg=read(ROOT/'freeze/PROTOCOL.json');budgets=cfg['checkpoints'];algorithms=['_'.join(p) for p in cfg['pairs']];demands=cfg['demand_modes']
rows=[json.loads(x) for x in (ROOT/'raw/TRAJECTORIES.jsonl').read_text().splitlines()]
schedule=read(ROOT/'freeze/SCHEDULE.json');assert len(rows)==len(schedule)==288
assert [r['run_id'] for r in rows]==[r['run_id'] for r in schedule]
checks=[];support=defaultdict(dict);instances={};checkpoint_rows=[];flat_failures=[];trace_checks=0

def independently_check(raw,out):
 assert isinstance(out,dict) and isinstance(out['routes'],list)
 counts=Counter();edges=[];loads=[]
 for route in out['routes']:
  assert type(route)==list and len(route)>=3 and route[0]==route[-1]==0 and 0 not in route[1:-1]
  assert all(type(x)==int and 0<=x<len(raw['coordinates']) for x in route)
  counts.update(route[1:-1]);loads.append(sum(raw['demands'][x] for x in route))
  assert loads[-1]<=raw['capacity']
  for a,b in zip(route,route[1:]):
   x,y=raw['coordinates'][a],raw['coordinates'][b];edges.append(math.sqrt((x[0]-y[0])**2+(x[1]-y[1])**2))
 assert counts==Counter(range(1,len(raw['coordinates'])))
 c=math.fsum(edges);assert math.isclose(c,out['reported_cost'],rel_tol=1e-9,abs_tol=1e-9)
 return c,len(loads)
for r in rows:
 key=(r['geometry_id'],r['demand_mode']);support[key][(r['algorithm'],r['search_seed'])]=r
 if r['input_file'] not in instances:instances[r['input_file']]=read(ROOT/r['input_file'])
 raw=instances[r['input_file']]
 if r['status']!='executed':
  for b in budgets:flat_failures.append({'run_id':r['run_id'],'budget':b,'reason':r['status']})
  continue
 assert r['deltas']==sum(r['delta_by_kind'].values()) and r['deltas']<=max(budgets)
 if r['stop_reason']=='delta_budget':assert r['deltas']==max(budgets)
 baseline,baseline_vehicles=independently_check(raw,r['baseline'])
 last=baseline;lastdelta=0
 for t in r['trace']:
  assert t['deltas']>=lastdelta and t['incumbent_cost']<=last+1e-9
  assert t['accepted']==(t['candidate_cost']<last-1e-9)
  assert abs(t['incumbent_cost']-(t['candidate_cost'] if t['accepted'] else last))<1e-8
  last=t['incumbent_cost'];lastdelta=t['deltas'];trace_checks+=1
 for b in budgets:
  cp=next((p for p in r['checkpoints'] if p['budget']==b),None)
  if cp is None or not cp['scoreable']:
   flat_failures.append({'run_id':r['run_id'],'budget':b,'reason':'missing_or_not_scoreable'});continue
  c,vehicles=independently_check(raw,cp['output'])
  assert cp['budget']==cp['deltas']==sum(cp['delta_by_kind'].values())
  assert abs(c-cp['check']['recomputed_cost'])<1e-8
  assert c<=baseline+1e-9
  # Prefix incumbent derived from stored, completed-candidate trace.
  eligible=[t for t in r['trace'] if t['deltas']<=b]
  expected=eligible[-1]['incumbent_cost'] if eligible else baseline
  assert abs(c-expected)<1e-8
  checkpoint_rows.append({'run_id':r['run_id'],'geometry_id':r['geometry_id'],'family':r['family'],'n':r['n'],'demand_mode':r['demand_mode'],'search_seed':r['search_seed'],'algorithm':r['algorithm'],'budget':b,'cost':c,'baseline_cost':baseline,'vehicles':vehicles,'baseline_vehicles':baseline_vehicles,'improvement_pct':100*(baseline-c)/baseline,'iterations_completed':cp['iterations_completed'],'savings_evals':cp['delta_by_kind']['savings'],'removal_evals':cp['delta_by_kind']['removal'],'insertion_evals':cp['delta_by_kind']['insertion'],'matrix_distances':cp['matrix_distances'],'objective_edges':cp['objective_edges'],'prefix_cpu_seconds':cp['solver_cpu_seconds'],'prefix_wall_seconds':cp['solver_wall_seconds']})
complete_blocks=[];incomplete=[]
for key,items in sorted(support.items()):
 ok=len(items)==len(algorithms)*len(cfg['search_seeds']) and all(r['status']=='executed' and len(r['checkpoints'])==len(budgets) and all(p['scoreable'] for p in r['checkpoints']) for r in items.values())
 (complete_blocks if ok else incomplete).append(key)
complete_geometries=sorted(g for g in {g for g,d in complete_blocks} if all((g,d) in complete_blocks for d in demands))
assert len(complete_geometries)>0,'No complete geometries'
valid=[r for r in checkpoint_rows if r['geometry_id'] in complete_geometries]
groups=defaultdict(list)
for r in valid:groups[(r['geometry_id'],r['demand_mode'],r['algorithm'],r['budget'])].append(r)
aggregated={key:{'cost':mean(x['cost'] for x in vals),'baseline_cost':mean(x['baseline_cost'] for x in vals),'vehicles':mean(x['vehicles'] for x in vals),'improvement_pct':mean(x['improvement_pct'] for x in vals),'prefix_cpu_seconds':mean(x['prefix_cpu_seconds'] for x in vals),'prefix_wall_seconds':mean(x['prefix_wall_seconds'] for x in vals)} for key,vals in groups.items()}
perblock=[]
for g in complete_geometries:
 for d in demands:
  for b in budgets:
   costs={a:aggregated[(g,d,a,b)]['cost'] for a in algorithms};oracle=min(costs.values())
   for a in algorithms:
    score=aggregated[g,d,a,b];c=costs[a]
    rank=1+sum(x<c-1e-9 for x in costs.values())+sum(abs(x-c)<=1e-9 for aa,x in costs.items() if aa!=a)/2
    perblock.append({'geometry_id':g,'demand_mode':d,'budget':b,'algorithm':a,**score,'relative_regret_pct':100*(c/oracle-1),'midrank':rank})
summary=[];rankings={}
for d in ['all']+demands:
 for b in budgets:
  for a in algorithms:
   values=[p for p in perblock if p['budget']==b and p['algorithm']==a and (d=='all' or p['demand_mode']==d)]
   summary.append({'demand_mode':d,'budget':b,'algorithm':a,'n_geometries':len(complete_geometries),'n_geometry_demand_blocks':len(values),'mean_relative_regret_pct':mean(p['relative_regret_pct'] for p in values),'mean_midrank':mean(p['midrank'] for p in values),'mean_baseline_improvement_pct':mean(p['improvement_pct'] for p in values),'mean_distance':mean(p['cost'] for p in values),'mean_vehicles':mean(p['vehicles'] for p in values),'mean_prefix_cpu_seconds':mean(p['prefix_cpu_seconds'] for p in values),'mean_prefix_wall_seconds':mean(p['prefix_wall_seconds'] for p in values)})
  ranked=sorted([r for r in summary if r['demand_mode']==d and r['budget']==b],key=lambda r:(r['mean_relative_regret_pct'],r['algorithm']))
  rankings[f'{d}/{b}']=[r['algorithm'] for r in ranked]
gains=[]
for a in algorithms:
 for lo,hi in zip(budgets,budgets[1:]):
  for d in ['all']+demands:
   differences=[100*(aggregated[g,dm,a,lo]['cost']-aggregated[g,dm,a,hi]['cost'])/aggregated[g,dm,a,lo]['cost'] for g in complete_geometries for dm in demands if d=='all' or dm==d]
   gains.append({'algorithm':a,'demand_mode':d,'from_budget':lo,'to_budget':hi,'mean_paired_gain_pct':mean(differences),'median_paired_gain_pct':statistics.median(differences),'min_gain_pct':min(differences),'max_gain_pct':max(differences),'fraction_gain_le_0_5_pct':mean(v<=0.5+1e-12 for v in differences),'block_count':len(differences),'practical_plateau_rule_met':bool(lo==40000 and hi==160000 and mean(differences)<=0.5 and mean(v<=0.5+1e-12 for v in differences)>=.75)})
paired=[]
for b in budgets:
 for a,aa in itertools.combinations(algorithms,2):
  ds=[]
  for g in complete_geometries:
   delta=mean(100*(aggregated[g,d,a,b]['cost']/aggregated[g,d,aa,b]['cost']-1) for d in demands);ds.append(delta)
  paired.append({'budget':b,'algorithm_a':a,'algorithm_b':aa,'mean_geometry_relative_cost_a_minus_b_pct':mean(ds),'a_wins_geometries':sum(x<-1e-9 for x in ds),'ties_geometries':sum(abs(x)<=1e-9 for x in ds),'a_loses_geometries':sum(x>1e-9 for x in ds),'geometry_deltas_pct':json.dumps(ds)})
checks={'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'raw_trajectories':len(rows),'checkpoint_observations':len(checkpoint_rows),'not_independent_checkpoint_count':True,'independently_recomputed_outputs':len(checkpoint_rows)+sum(r['status']=='executed' for r in rows),'trace_rows_verified':trace_checks,'complete_geometry_count':len(complete_geometries),'complete_geometry_demand_blocks':len(complete_blocks),'incomplete_blocks':incomplete,'failures':flat_failures,'all_checks_passed':True,'analysis_cpu_seconds_before_write':time.process_time()-start}
csvout('checkpoint_observations.csv',checkpoint_rows);csvout('geometry_demand_aggregates.csv',perblock);csvout('budget_summary.csv',summary);csvout('paired_budget_gains.csv',gains);csvout('paired_algorithm_comparisons.csv',paired)
dump(ROOT/'reports/SELF_CHECK.json',checks)
dump(ROOT/'reports/SUMMARY.json',{'ranking_metric':'mean_relative_regret_pct','rankings':rankings,'summary':summary,'budget_gains':gains,'common_support_geometries':complete_geometries,'same_geometries_reused_across_budgets':True,'inference':'descriptive only; no significance claims'})
print(json.dumps({'checks':checks,'all_rankings':{k:v for k,v in rankings.items() if k.startswith('all/')},'all_budget_gains':[g for g in gains if g['demand_mode']=='all']},ensure_ascii=False,indent=2))
