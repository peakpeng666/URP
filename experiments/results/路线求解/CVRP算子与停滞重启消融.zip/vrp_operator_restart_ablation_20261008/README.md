# CVRP operator × restart ablation

Start with reports/REPORT_ZH.md and reports/SUMMARY.json.

Frozen 16 fresh n50 geometries, two demands, two paired search seeds, 2×2 strategies. Same legacy delta ledger, including restart reconstruction. Source/core files, protocol, all inputs, raw trajectories, failures, route audits, resource and exit receipts retained. No external calls or paid resources. Reports are execution/self-check evidence, not an independent external review. No old package modified.
