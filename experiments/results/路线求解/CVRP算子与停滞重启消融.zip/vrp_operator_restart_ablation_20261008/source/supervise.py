"""Simple stage exit receipts and externally enforced solver resource ceilings."""
from pathlib import Path
import datetime,hashlib,json,os,resource,subprocess,sys,time,zipfile
ROOT=Path(__file__).resolve().parents[1]
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def dump(p,d):
    with p.open('x') as f:json.dump(d,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    start=time.perf_counter();records=[]
    for phase,cap,wallcap in [('prepare',10,30),('run',175,240),('analyze',25,60)]:
        before=resource.getrusage(resource.RUSAGE_CHILDREN);wall=time.perf_counter()
        def limit():resource.setrlimit(resource.RLIMIT_CPU,(cap,cap))
        with (ROOT/f'raw/{phase.upper()}_STDOUT.txt').open('x') as out,(ROOT/f'raw/{phase.upper()}_STDERR.txt').open('x') as err:
            p=subprocess.Popen([sys.executable,'-B',str(ROOT/f'source/{phase}.py')],stdout=out,stderr=err,start_new_session=True,preexec_fn=limit)
            try:code=p.wait(timeout=wallcap);killed=False
            except subprocess.TimeoutExpired:os.killpg(p.pid,9);code=p.wait();killed=True
        after=resource.getrusage(resource.RUSAGE_CHILDREN)
        rec={'phase':phase,'utc':utc(),'pid':p.pid,'exit_code':code,'wall_timeout':killed,'cpu_hard_limit_seconds':cap,'wall_limit_seconds':wallcap,
             'child_user_cpu_seconds':after.ru_utime-before.ru_utime,'child_system_cpu_seconds':after.ru_stime-before.ru_stime,
             'child_total_cpu_seconds':after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime,'wall_seconds':time.perf_counter()-wall,'maxrss_kib':after.ru_maxrss}
        dump(ROOT/f'raw/{phase.upper()}_RESOURCE.json',rec);records.append(rec);print(json.dumps(rec),flush=True)
        if phase=='prepare' and code!=0:raise SystemExit('prepare failed; formal not started')
    account={'utc':utc(),'phases':records,'measured_stage_cpu_seconds':sum(r['child_total_cpu_seconds'] for r in records),
             'supervisor_cpu_before_packaging':time.process_time(),'setup_inspection_cpu_allowance_seconds':8,
             'main_cpu_ceiling':180,'main_wall_ceiling':240,'main_within_ceilings':next(r for r in records if r['phase']=='run')['child_total_cpu_seconds']<=180 and next(r for r in records if r['phase']=='run')['wall_seconds']<=240,
             'external_api_calls':0,'model_calls':0,'paid_calls':0,'dependency_installations':0,'uploads':0,'monetary_charge_incurred':0,
             'platform_compute_billing':'No paid resource purchase or metered API invoked; underlying platform compute billing is not exposed.',
             'analysis_auxiliary_to_main_cap':True,'retries':0}
    dump(ROOT/'reports/RESOURCE_ACCOUNTING.json',account)
    (ROOT/'README.md').write_text('# CVRP operator × restart ablation\n\nStart with reports/REPORT_ZH.md and reports/SUMMARY.json.\n\nFrozen 16 fresh n50 geometries, two demands, two paired search seeds, 2×2 strategies. Same legacy delta ledger, including restart reconstruction. Source/core files, protocol, all inputs, raw trajectories, failures, route audits, resource and exit receipts retained. No external calls or paid resources. Reports are execution/self-check evidence, not an independent external review. No old package modified.\n')
    files=sorted(p for p in ROOT.rglob('*') if p.is_file());dump(ROOT/'MANIFEST.json',{'utc':utc(),'files':[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files]})
    files.append(ROOT/'MANIFEST.json')
    with (ROOT/'SHA256SUMS.txt').open('x') as f:
        for p in sorted(files):f.write(sha(p)+'  '+str(p.relative_to(ROOT))+'\n')
    archive=ROOT.parent/(ROOT.name+'.zip')
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(ROOT.rglob('*')):
            if p.is_file():z.write(p,str(p.relative_to(ROOT.parent)))
    receipt={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'supervisor_cpu_seconds':time.process_time(),'stage_cpu_seconds':account['measured_stage_cpu_seconds'],'total_wall_seconds':time.perf_counter()-start}
    dump(ROOT.parent/(ROOT.name+'_archive_receipt.json'),receipt);print(json.dumps(receipt),flush=True)
if __name__=='__main__':main()
