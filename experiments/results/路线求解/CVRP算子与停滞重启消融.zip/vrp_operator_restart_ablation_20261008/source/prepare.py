from pathlib import Path
import hashlib,json,random,sys,time
sys.dont_write_bytecode=True
from budget_engine import ROOT,legacy,from_dict,sha,dump,read,utc
OLD=Path('/workspace/shared/vrp_unseen_geometry_20261007')
def main():
    t=time.process_time()
    cfg={'name':'CVRP operator x stagnation restart 2x2','written_utc':utc(),
         'geometry_count':16,'families':['uniform','clustered'],'n':50,'replicates_per_family':8,
         'geometry_seeds':list(range(202610080100,202610080116)),
         'search_seeds':[81011,81029],'demand_modes':['constant5','high_variance_random'],
         'demand_seed_offset':1000000,'capacity':30,'repairs':['cheapest','regret2'],'restart_settings':[False,True],
         'checkpoints':[40000,160000],'primary_budget':160000,'formal_trajectories':256,
         'schedule_seed':202610080199,'bootstrap_seed':202610080299,'bootstrap_replicates':10000,
         'restart_stagnation_iterations':8,
         'restart_rule':'One candidate rule. After 8 consecutive completed proposals without strict improvement to CURRENT solution, reconstruct from empty routes with randomly shuffled customer order using derived_seed(search_seed,restart,restart_index). Insert each next customer at its cheapest capacity-feasible position by unchanged route_options. Charge every insertion delta within SAME total ledger. Reset stagnation; accept reconstruction as current even if worse, retaining historical best. No partial reconstruction submitted. No operator/threshold tuning.',
         'operator_rule':'Unchanged random destroy, q uniformly 10%-30% each iteration; cheapest versus regret2 repair. Strict improvement to current; output global best. No-restart arms must reproduce old solver exactly.',
         'eval_unit':'Legacy candidate delta arithmetic, savings+removal+insertion, including all restart insertion choices. Full-objective edge sums, matrix distances, checker work separately counted. Equal delta count, NOT equal whole-objective calls, FLOPs, CPU, or wall time.',
         'design':'16 fresh geometry blocks; 2 demand variants and 2 paired seeds repeated within block; 4 factorial arms; checkpoints correlated. Do not treat 256 trajectories or 512 checkpoints as independent samples.',
         'primary_contrast':'At160000, operator effect WITHOUT restart:100*(cheapest_off_mean_cost-regret2_off_mean_cost)/cheapest_off_mean_cost per geometry-demand, then mean2 demands then equal16 geometries.',
         'secondary_contrasts':['restart_effect_cheapest','restart_effect_regret2','operator_effect_with_restart','factorial_interaction'],
         'contrasts':'Restart effect:100*(off_mean-on_mean)/off_mean within each repair. Operator with restart uses cheapest_on denominator. Interaction:100*((cheapest_off-regret2_off)-(cheapest_on-regret2_on))/cheapest_off. Positive interaction means operator absolute saving shrinks when adding restart. Also report40000 descriptively.',
         'aggregation':'Mean2 search seeds per geometry-demand-arm, compute paired % contrasts, average2 demands per geometry. Mean16 geometry-level contrasts; win/tie/loss by geometry. Bootstrap8 blocks per family with replacement; all repeated measures stay together.95% percentile interval,10000 fixed resamples; secondary comparisons unadjusted.',
         'failure_rule':'No retries,replacement,posthoc expansion or score-based filtering. Preserve every planned call and failure. Common-support geometry requires all16 calls and both checkpoints valid. Missing support makes conclusions incomplete.',
         'novelty':'Same existing synthetic dev generators, no new distribution families, no real field instances, no strong modern external baselines, no optimality/SOTA claims.',
         'per_trajectory_cpu_limit':3.0,'per_trajectory_wall_limit':15.0,'process_cpu_hard_limit':175,
         'process_cpu_soft_gate':165.0,'execution_wall_limit':230.0,'main_cpu_ceiling':180.0,'main_wall_ceiling':240.0,
         'resource_forecast':'Old unseen1152x40000=46.08M deltas used39.219825 CPU seconds; old scale384x160000=61.44M used53.245502. New40.96M forecasts34.86-35.50s; even4x <180s. Auxiliary preparation/analysis/packaging recorded separately.',
         'external_api_calls':0,'model_calls':0,'paid_calls':0,'new_dependencies':0,'external_uploads':0}
    dump(ROOT/'freeze/PROTOCOL.json',cfg)
    provenance=[]
    for p in sorted((ROOT/'source').rglob('*.py')):
        rel=p.relative_to(ROOT);old=OLD/rel
        provenance.append({'path':str(rel),'sha256':sha(p),'source':str(old) if old.exists() else 'new_for_this_ablation',
                           'source_sha256':sha(old) if old.exists() else None,'byte_identical':sha(p)==sha(old) if old.exists() else None})
    dump(ROOT/'freeze/SOURCE_PROVENANCE.json',provenance)
    dump(ROOT/'freeze/PRE_GENERATION_FREEZE.json',{'utc':utc(),'new_geometry_count_before_freeze':0,'new_solver_runs_before_freeze':0,
         'sha256':{str(p.relative_to(ROOT)):sha(p) for p in sorted((ROOT/'source').rglob('*.py'))}|{'freeze/PROTOCOL.json':sha(ROOT/'freeze/PROTOCOL.json')}})
    old_hashes=set(read(OLD/'freeze/OLD_GEOMETRY_HASHES.json')['hashes']);old_seeds=set();old_sources=[]
    for name in ['vrp_unseen_geometry_20261007','cvrp_scale_20261007','cvrp_budget_starvation_20261007']:
        manifest=ROOT.parent/name/'freeze/INPUT_MANIFEST.json';data=read(manifest)
        if isinstance(data,dict):data=data.get('entries',[])
        for e in data:
            if 'coordinate_sha256' in e:old_hashes.add(e['coordinate_sha256'])
            if 'geometry_seed' in e:old_seeds.add(e['geometry_seed'])
        old_sources.append({'path':str(manifest),'sha256':sha(manifest)})
    dump(ROOT/'freeze/OLD_GEOMETRIES.json',{'coordinate_hashes':sorted(old_hashes),'geometry_seeds':sorted(old_seeds),'sources':old_sources})
    entries=[];new_hashes=[]
    for index,seed in enumerate(cfg['geometry_seeds']):
        family=cfg['families'][index//8];rep=index%8;geom=f'ablate-{family}-n50-r{rep}-s{seed}'
        base=legacy.generate_instance(50,family,seed,30).to_dict()
        ch=hashlib.sha256(json.dumps(base['coordinates'],separators=(',',':')).encode()).hexdigest()
        assert ch not in old_hashes and ch not in new_hashes and seed not in old_seeds
        new_hashes.append(ch)
        random_demands=[1]*25+[9]*25;random.Random(seed+cfg['demand_seed_offset']).shuffle(random_demands)
        for mode,dem in zip(cfg['demand_modes'],[[5]*50,random_demands]):
            obj={**base,'instance_id':geom+'-'+mode,'demands':[0]+dem};from_dict(obj)
            fn='input/'+obj['instance_id']+'.json';dump(ROOT/fn,obj)
            entries.append({'geometry_id':geom,'family':family,'n':50,'replicate':rep,'geometry_seed':seed,'demand_mode':mode,
                            'input_file':fn,'input_sha256':sha(ROOT/fn),'coordinate_sha256':ch})
    dump(ROOT/'freeze/INPUT_MANIFEST.json',entries)
    calls=[{**e,'search_seed':seed,'repair':repair,'restart_on':on,'algorithm':repair+('_restart' if on else '_off')}
           for e in entries for seed in cfg['search_seeds'] for repair in cfg['repairs'] for on in cfg['restart_settings']]
    random.Random(cfg['schedule_seed']).shuffle(calls)
    for i,c in enumerate(calls):c['run_id']=i
    dump(ROOT/'freeze/SCHEDULE.json',calls)
    dump(ROOT/'freeze/PRE_RUN_FREEZE.json',{'utc':utc(),'formal_runs_before_freeze':0,'sha256':{str(p.relative_to(ROOT)):sha(p) for dr in ['source','input','freeze'] for p in sorted((ROOT/dr).rglob('*')) if p.is_file()}})
    dump(ROOT/'raw/PREPARATION.json',{'cpu_seconds':time.process_time()-t,'geometry_count':16,'trajectories':len(calls),'new_hashes_distinct':len(set(new_hashes)),'old_coordinate_hashes_checked':len(old_hashes)})
    print(json.dumps({'prepared':True,'trajectories':len(calls),'protocol_sha256':sha(ROOT/'freeze/PROTOCOL.json')}),flush=True)
if __name__=='__main__':main()
