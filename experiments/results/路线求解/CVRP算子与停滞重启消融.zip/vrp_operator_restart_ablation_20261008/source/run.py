import copy,json,os,resource,sys,time,traceback
sys.dont_write_bytecode=True
from budget_engine import ROOT,verify,read,dump,utc,legacy,from_dict
from ablation import trajectory

def main():
    verify();cfg=read(ROOT/'freeze/PROTOCOL.json');calls=read(ROOT/'freeze/SCHEDULE.json')
    start=time.perf_counter();cpu=time.process_time()
    resource.setrlimit(resource.RLIMIT_CPU,(175,175))
    dump(ROOT/'raw/STARTED.json',{'utc':utc(),'pid':os.getpid(),'python':sys.version,'cpu_affinity':sorted(os.sched_getaffinity(0)),
                                'planned_calls':len(calls),'no_historical_outcomes_loaded':True})
    smoke=legacy.generate_instance(6,'uniform',202610080099,30)
    smoke_cfg={**cfg,'checkpoints':[500,2000]};tests=[]
    for repair in cfg['repairs']:
        result=trajectory(smoke,repair,False,81999,smoke_cfg)
        for cp in result['checkpoints']:
            ref=legacy.run_one(smoke,['random',repair],81999,10**9,{'delta_limit':cp['budget'],'cpu_limit_seconds':3,'wall_limit_seconds':15})
            tests.append({'repair':repair,'budget':cp['budget'],'passed':cp['output']==ref['output'] and cp['deltas']==ref['deltas'] and ref['check']['accepted'],
                          'ablation_output':cp['output'],'legacy_output':ref['output'],'ablation_ledger':cp['delta_by_kind'],'legacy_ledger':ref['delta_by_kind']})
    dump(ROOT/'raw/SMOKE_EQUIVALENCE.json',{'formal':False,'tests':tests,'all_passed':len(tests)==4 and all(t['passed'] for t in tests)})
    if len(tests)!=4 or not all(t['passed'] for t in tests):raise RuntimeError('off-arm equivalence smoke failed; formal blocked')
    failures=[]
    with (ROOT/'raw/TRAJECTORIES.jsonl').open('x') as f:
        for call in calls:
            row={**call,'started_utc':utc()}
            if time.process_time()+cfg['per_trajectory_cpu_limit']+3>cfg['process_cpu_soft_gate']:
                row.update(status='not_run_cpu_gate',missing_budgets=cfg['checkpoints'])
            elif time.perf_counter()-start+cfg['per_trajectory_wall_limit']>cfg['execution_wall_limit']:
                row.update(status='not_run_wall_gate',missing_budgets=cfg['checkpoints'])
            else:
                try:row.update(trajectory(from_dict(read(ROOT/call['input_file'])),call['repair'],call['restart_on'],call['search_seed'],cfg));row['status']='executed'
                except Exception as e:row.update(status='runner_failure',error={'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()},missing_budgets=cfg['checkpoints'])
            row['finished_utc']=utc();f.write(json.dumps(row,allow_nan=False)+'\n');f.flush()
            if row['status']!='executed' or row.get('error') or row.get('missing_budgets') or row.get('stop_reason')!='delta_budget' or any(not c['scoreable'] for c in row.get('checkpoints',[])):
                failures.append({'run_id':call['run_id'],'status':row['status'],'error':row.get('error'),'stop_reason':row.get('stop_reason'),'missing_budgets':row.get('missing_budgets',[])})
            if (call['run_id']+1)%32==0:print(json.dumps({'completed':call['run_id']+1,'cpu_seconds':time.process_time(),'wall_seconds':time.perf_counter()-start}),flush=True)
    dump(ROOT/'failures/FAILURES.json',{'count':len(failures),'rows':failures,'retries':0})
    verify();dump(ROOT/'raw/COMPLETION.json',{'utc':utc(),'planned':len(calls),'written':len(calls),'failures':len(failures),'execution_cpu_seconds':time.process_time()-cpu,'process_cpu_seconds':time.process_time(),'wall_seconds':time.perf_counter()-start,'model_calls':0,'api_calls':0,'paid_calls':0,'frozen_hashes_unchanged':True})
if __name__=='__main__':main()
