"""Frozen paired-block statistics and independent coordinate audit; no solver calls."""
from pathlib import Path
import collections,csv,hashlib,json,math,random,statistics,time
ROOT=Path(__file__).resolve().parents[1]
def read(p):return json.loads(p.read_text())
def dump(p,d):
    with p.open('x') as f:json.dump(d,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')
def csvout(name,rows):
    if not rows:return
    with (ROOT/'reports'/name).open('x',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def audit(inst,out):
    if not isinstance(out,dict):return {'accepted':False,'error':'missing_output'}
    routes=out.get('routes',[]);seen=[];loads=[];dist=[];endpoint_ok=True
    for route in routes:
        endpoint_ok &= len(route)>=3 and route[0]==route[-1]==0 and 0 not in route[1:-1]
        seen.extend(route[1:-1]);loads.append(sum(inst['demands'][i] for i in route[1:-1]))
        dist.extend(math.hypot(inst['coordinates'][a][0]-inst['coordinates'][b][0],inst['coordinates'][a][1]-inst['coordinates'][b][1]) for a,b in zip(route,route[1:]))
    cost=math.fsum(dist)
    ok=endpoint_ok and sorted(seen)==list(range(1,len(inst['coordinates']))) and max(loads,default=0)<=inst['capacity'] and math.isclose(cost,out.get('reported_cost',-1),rel_tol=1e-9,abs_tol=1e-9)
    return {'accepted':ok,'recomputed_cost':cost,'route_count':len(routes),'max_load':max(loads,default=0),'coverage_exact':sorted(seen)==list(range(1,len(inst['coordinates'])))}
def percentile(xs,q):
    s=sorted(xs);x=q*(len(s)-1);a=int(x);b=min(a+1,len(s)-1);return s[a]+(s[b]-s[a])*(x-a)
def main():
    t=time.process_time();cfg=read(ROOT/'freeze/PROTOCOL.json');schedule=read(ROOT/'freeze/SCHEDULE.json')
    path=ROOT/'raw/TRAJECTORIES.jsonl';rows=[json.loads(s) for s in path.read_text().splitlines()] if path.exists() else []
    by_id={r['run_id']:r for r in rows};audits=[];obs=[];valid=set();problems=[]
    for call in schedule:
        row=by_id.get(call['run_id']);inst=read(ROOT/call['input_file'])
        if not row:problems.append({'run_id':call['run_id'],'reason':'missing_row'});continue
        checked=audit(inst,row.get('baseline'));audits.append({'run_id':call['run_id'],'stage':'baseline',**checked})
        prior=checked.get('recomputed_cost',math.inf);row_ok=checked['accepted'] and row.get('stop_reason')=='delta_budget' and row.get('status')=='executed' and not row.get('error')
        for budget in cfg['checkpoints']:
            cp=next((c for c in row.get('checkpoints',[]) if c['budget']==budget),None)
            if not cp:row_ok=False;continue
            a=audit(inst,cp.get('output'));audits.append({'run_id':call['run_id'],'stage':str(budget),**a})
            ledger_ok=cp['deltas']==budget==sum(cp['delta_by_kind'].values()) and cp['delta_by_kind']['savings']==1225 and cp['delta_by_kind']['removal']==0
            mono=a.get('recomputed_cost',math.inf)<=prior+1e-8
            restart_ok=0<=cp['restart_insertion_deltas']<=cp['delta_by_kind']['insertion'] and (call['restart_on'] or cp['restart_started']==0)
            row_ok &= a['accepted'] and ledger_ok and mono and restart_ok and cp['scoreable']
            prior=a.get('recomputed_cost',math.inf)
            obs.append({k:call[k] for k in ['run_id','geometry_id','family','demand_mode','search_seed','algorithm','restart_on']}|{'budget':budget,'cost':a.get('recomputed_cost'),'accepted':a['accepted'],'ledger_ok':ledger_ok,'monotonic':mono,'restart_accounting_ok':restart_ok,'iterations_completed':cp['iterations_completed'],'restarts_started':cp['restart_started'],'restarts_completed':cp['restart_completed'],'restart_insertion_deltas':cp['restart_insertion_deltas'],'objective_edges':cp['objective_edges'],'matrix_distances':cp['matrix_distances']})
        last_stagnation=0
        for event in row.get('trace',[]):
            if event['event']=='restart':
                row_ok &= last_stagnation==cfg['restart_stagnation_iterations'] and event['deltas']>event['deltas_before'];last_stagnation=0
            else:last_stagnation=event['stagnation']
        if row_ok:valid.add(call['run_id'])
        else:problems.append({'run_id':call['run_id'],'reason':'status_audit_ledger_or_trigger_failure'})
    allg=sorted(set(c['geometry_id'] for c in schedule));common=[g for g in allg if all(c['run_id'] in valid for c in schedule if c['geometry_id']==g)]
    dump(ROOT/'reports/INDEPENDENT_ROUTE_AUDIT.json',{'implementation':'This analysis directly uses input coordinates/demands and math.hypot; imports no solver helpers, matrices or checker. Self-run independent implementation, not external review.','count':len(audits),'all_passed':all(a['accepted'] for a in audits),'rows':audits})
    dump(ROOT/'reports/FAILURE_COMPLETENESS.json',{'planned':len(schedule),'present':len(rows),'unique_ids':len(by_id),'valid_calls':len(valid),'missing_ids':sorted(set(c['run_id'] for c in schedule)-set(by_id)),'problems':problems,'common_geometry_count':len(common),'excluded_geometries':sorted(set(allg)-set(common)),'retries':0})
    csvout('checkpoint_observations.csv',obs)
    groups=collections.defaultdict(list)
    for o in obs:
        if o['geometry_id'] in common:groups[(o['geometry_id'],o['family'],o['demand_mode'],o['budget'],o['algorithm'])].append(o['cost'])
    means={key:statistics.mean(v) for key,v in groups.items()};detail=[]
    for g in common:
        fam=next(c['family'] for c in schedule if c['geometry_id']==g)
        for d in cfg['demand_modes']:
            for b in cfg['checkpoints']:
                costs={a:means[g,fam,d,b,a] for a in ['cheapest_off','regret2_off','cheapest_restart','regret2_restart']}
                co,ro,cr,rr=[costs[a] for a in ['cheapest_off','regret2_off','cheapest_restart','regret2_restart']]
                effects={'operator_without_restart':100*(co-ro)/co,'restart_effect_cheapest':100*(co-cr)/co,'restart_effect_regret2':100*(ro-rr)/ro,'operator_with_restart':100*(cr-rr)/cr,'factorial_interaction':100*((co-ro)-(cr-rr))/co}
                for contrast,v in effects.items():detail.append({'geometry_id':g,'family':fam,'demand_mode':d,'budget':b,'contrast':contrast,'improvement_percent':v})
    csvout('paired_geometry_demand_contrasts.csv',detail)
    geo=[];gg=collections.defaultdict(list)
    for r in detail:gg[(r['geometry_id'],r['family'],r['budget'],r['contrast'])].append(r['improvement_percent'])
    for (g,f,b,c),v in gg.items():geo.append({'geometry_id':g,'family':f,'budget':b,'contrast':c,'improvement_percent':statistics.mean(v)})
    csvout('paired_geometry_contrasts.csv',geo)
    rng=random.Random(cfg['bootstrap_seed']);blocks=[[g for g in common if next(c['family'] for c in schedule if c['geometry_id']==g)==fam] for fam in cfg['families']]
    samples=[[rng.choice(block) for block in blocks for _ in range(len(block))] for _ in range(cfg['bootstrap_replicates'])] if all(blocks) else []
    summary=[];bootout=[]
    for b in cfg['checkpoints']:
        for c in ['operator_without_restart','restart_effect_cheapest','restart_effect_regret2','operator_with_restart','factorial_interaction']:
            selected=[r for r in geo if r['budget']==b and r['contrast']==c];values={r['geometry_id']:r['improvement_percent'] for r in selected};v=list(values.values())
            if not v:continue
            bs=[statistics.mean(values[g] for g in sample) for sample in samples]
            summary.append({'budget':b,'contrast':c,'geometry_count':len(v),'mean_percent':statistics.mean(v),'ci_low':percentile(bs,.025) if bs else None,'ci_high':percentile(bs,.975) if bs else None,'wins':sum(x>1e-9 for x in v),'ties':sum(abs(x)<=1e-9 for x in v),'losses':sum(x< -1e-9 for x in v),'minimum':min(v),'maximum':max(v)})
            bootout.extend({'budget':b,'contrast':c,'replicate':i,'mean_percent':v} for i,v in enumerate(bs))
    csvout('paired_summary.csv',summary);csvout('bootstrap_means.csv',bootout)
    subgroups=[]
    for b in cfg['checkpoints']:
        for family in cfg['families']:
            for contrast in sorted(set(r['contrast'] for r in geo)):
                vs=[r['improvement_percent'] for r in geo if r['budget']==b and r['family']==family and r['contrast']==contrast]
                if vs:subgroups.append({'budget':b,'family':family,'contrast':contrast,'geometries':len(vs),'mean_percent':statistics.mean(vs),'wins':sum(v>1e-9 for v in vs),'ties':sum(abs(v)<=1e-9 for v in vs),'losses':sum(v< -1e-9 for v in vs)})
    csvout('family_descriptives.csv',subgroups)
    arms=[]
    for b in cfg['checkpoints']:
        for a in ['cheapest_off','regret2_off','cheapest_restart','regret2_restart']:
            xs=[o for o in obs if o['budget']==b and o['algorithm']==a and o['geometry_id'] in common]
            regrets=[]
            for g in common:
                fam=next(c['family'] for c in schedule if c['geometry_id']==g)
                for d in cfg['demand_modes']:
                    best=min(means[g,fam,d,b,x] for x in ['cheapest_off','regret2_off','cheapest_restart','regret2_restart'])
                    regrets.append(100*(means[g,fam,d,b,a]/best-1))
            if xs:arms.append({'budget':b,'algorithm':a,'trajectories':len(xs),'mean_pool_regret_percent':statistics.mean(regrets),'trajectories_with_completed_restart':sum(x['restarts_completed']>0 for x in xs),'mean_completed_restarts':statistics.mean(x['restarts_completed'] for x in xs),'total_restart_insertion_deltas':sum(x['restart_insertion_deltas'] for x in xs),'mean_completed_iterations':statistics.mean(x['iterations_completed'] for x in xs),'mean_objective_edges':statistics.mean(x['objective_edges'] for x in xs)})
    csvout('arm_descriptives.csv',arms)
    frozen=read(ROOT/'freeze/PRE_RUN_FREEZE.json');bad=[p for p,h in frozen['sha256'].items() if hashlib.sha256((ROOT/p).read_bytes()).hexdigest()!=h]
    old=read(ROOT/'freeze/OLD_GEOMETRIES.json');manifest=read(ROOT/'freeze/INPUT_MANIFEST.json');newhash=set(e['coordinate_sha256'] for e in manifest)
    dump(ROOT/'reports/FINAL_SELF_CHECK.json',{'frozen_hashes_unchanged':not bad,'mismatches':bad,'unique_new_geometry_hashes':len(newhash),'old_geometry_overlap':sorted(newhash&set(old['coordinate_hashes'])),'all_256_calls_valid':len(valid)==256,'all_16_geometry_common_support':len(common)==16,'external_review':False})
    dump(ROOT/'reports/SUMMARY.json',{'geometry_count':len(common),'planned_geometries':16,'formal_trajectories':len(rows),'valid_trajectories':len(valid),'contrasts':summary,'arms':arms,'analysis_cpu_seconds':time.process_time()-t,'external_calls':0})
    mainrows=[r for r in summary if r['budget']==160000]
    text=['# CVRP算子×停滞重启消融','',f'固定16个全新n50几何、2需求、2搜索seed、4策略：{len(valid)}/256条有效。统计独立块仅{len(common)}个几何，512检查点不视为独立样本。','', '## 160,000 delta结果','']
    labels={'operator_without_restart':'无重启时regret2相对cheapest','restart_effect_cheapest':'cheapest加重启','restart_effect_regret2':'regret2加重启','operator_with_restart':'有重启时regret2相对cheapest','factorial_interaction':'交互：重启使算子绝对收益缩小'}
    for r in mainrows:text.append(f"- {labels[r['contrast']]}：平均{r['mean_percent']:.4f}%，95%几何bootstrap区间[{r['ci_low']:.4f}%, {r['ci_high']:.4f}%]；几何{r['wins']}胜/{r['ties']}平/{r['losses']}负。")
    text+=['','正值代表对应改善；交互除以无重启cheapest成本，只用于描述。主比较是无重启算子差，其他比较未作多重比较校正。先平均2搜索seed、再等权2需求和16几何；uniform/clustered各8几何整块分层bootstrap10,000次，固定seed202610080299。','', '## 固定方法及完整性','', '- 从旧最好random_regret2和固定random_cheapest出发做2×2。新增唯一规则是连续8个完整候选未改善当前解即随机顺序逐客户最便宜可行插入重构，再按相同原算子搜索；保留历史最优。重启接受较差当前解属于被测多起点机制。', '- 所有重启插入位置比较逐项计入同一160,000总delta预算，初始化savings也收费。不是等整解评价次数、等CPU或等FLOP；完整目标边求和、矩阵和检查器另计。', '- 40000是同一轨迹的中途重复测量。未改客户覆盖、容量30、无舍入欧氏距离和无限同质车辆。无重启新包装器在预定n6 smoke与旧实现4项检查点结果一致。', '- 所有基线和检查点用原独立checker检查，分析器再直接坐标复算共768个输出；详见INDEPENDENT_ROUTE_AUDIT.json。这是独立实现的自检，不冒充外部独审。', '- 未补样、未换seed、未重试、未按成绩调阈值；所有未完成候选不提交。几何hash与已登记旧几何零交集。', '- 限于原uniform/clustered合成生成器的n50、constant5和随机1/9需求，以及当前两search seed和固定预算；未测试空间相关需求、真实实例、强现代基线、其他重启阈值或其他重启构造。不作SOTA或普适机制归因。', '', '## 资源和复现', '', '主运行CPU/墙时及退出码见raw/RUN_RESOURCE.json；总阶段资源见reports/RESOURCE_ACCOUNTING.json。模型、API、依赖安装、付费资源及外传均为0。源码和输入启动前冻结；原包不改。将source复制到新空目录（同时建立freeze/input/raw/reports/failures目录），运行source/supervise.py可按固定方案重建；已有目录输出使用独占创建，禁止覆盖重跑。']
    (ROOT/'reports/REPORT_ZH.md').write_text('\n'.join(text)+'\n')
    print(json.dumps({'valid':len(valid),'geometries':len(common),'primary_and_secondary_160k':mainrows,'analysis_cpu_seconds':time.process_time()-t}),flush=True)
if __name__=='__main__':main()
