官方CVRP中性接受规则固定方法验证
先读reports/REPORT_ZH.txt。主对比regret2 neutral/strict，cheapest次要。
6个新增官方实例×2方法×2接受开关×4新seed=96轨迹；40k/160k=192检查点。
P45包含旧P40全部39客户坐标，按相关变体单列；其余5例预声明低重叠敏感性，不声称独立。
每实例mean/min/worst成本及gap、失败全分母见PER_INSTANCE_METHOD_ARM.csv；配对改善/恶化/相同见PAIRED_SUMMARY.csv。
冻结方法、96计划及4新seed位于freeze。源码solver及所有科学组件与已独审PASS旧neutral包字节相同。
K/Q由输入参数读取，K6/K10合成玩具及旧中性玩具通过；未在新官方实例试跑或调参。
raw含96逐步candidate/current/best轨迹及fsync/hash seal；READ_AUDIT记录唯一主跑允许读取来源。
准备阶段只读验证官方参考成本/可行性；solver无参考访问，gap仅在主跑所有输出封存后计算。
receipts记录真实退出码、wait4 CPU、wall及资源界限，主跑硬限120CPU/180wall。
provenance/dataset为冻结来源/原始数据/官方引用与使用边界，保持私有研究用途。
无API、模型调用、安装、购买、上传、tabu、退火、重启、换例或补跑；旧包未修改。
此包只有自检，父任务另行独审。无显著性、普遍优越或SOTA结论。
MANIFEST及SHA256SUMS覆盖交付；archive.sha256验证ZIP；包装receipt在ZIP外防自引用。
