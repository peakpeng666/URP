"""Checksummed one-shot immutable delivery, packaging receipt kept outside ZIP."""
import json,zipfile
from common import ROOT,dump,read,sha,utc,verify
verify()
assert read(ROOT/'receipts/main.json')['complete'] and read(ROOT/'receipts/audit.json')['complete']
assert read(ROOT/'reports/TRACE_CHECKS.json')['passed']
assert read(ROOT/'freeze/GATE_PASS.json')['status']=='PASS'
readme='官方CVRP中性接受规则固定方法验证\n先读reports/REPORT_ZH.txt。主对比regret2 neutral/strict，cheapest次要。\n6个新增官方实例×2方法×2接受开关×4新seed=96轨迹；40k/160k=192检查点。\nP45包含旧P40全部39客户坐标，按相关变体单列；其余5例预声明低重叠敏感性，不声称独立。\n每实例mean/min/worst成本及gap、失败全分母见PER_INSTANCE_METHOD_ARM.csv；配对改善/恶化/相同见PAIRED_SUMMARY.csv。\n冻结方法、96计划及4新seed位于freeze。源码solver及所有科学组件与已独审PASS旧neutral包字节相同。\nK/Q由输入参数读取，K6/K10合成玩具及旧中性玩具通过；未在新官方实例试跑或调参。\nraw含96逐步candidate/current/best轨迹及fsync/hash seal；READ_AUDIT记录唯一主跑允许读取来源。\n准备阶段只读验证官方参考成本/可行性；solver无参考访问，gap仅在主跑所有输出封存后计算。\nreceipts记录真实退出码、wait4 CPU、wall及资源界限，主跑硬限120CPU/180wall。\nprovenance/dataset为冻结来源/原始数据/官方引用与使用边界，保持私有研究用途。\n无API、模型调用、安装、购买、上传、tabu、退火、重启、换例或补跑；旧包未修改。\n此包只有自检，父任务另行独审。无显著性、普遍优越或SOTA结论。\nMANIFEST及SHA256SUMS覆盖交付；archive.sha256验证ZIP；包装receipt在ZIP外防自引用。\n'
(ROOT/'README_ZH.txt').write_text(readme)
name='official_cvrp_neutral_validation_20261008.zip'
excluded={'MANIFEST.json','SHA256SUMS.txt','archive.sha256',name,'receipts/package.json','receipts/package.stdout.log','receipts/package.stderr.log'}
files=sorted(p for p in ROOT.rglob('*') if p.is_file() and str(p.relative_to(ROOT)) not in excluded)
manifest={'created_utc':utc(),'files':[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files],'scope':'Immutable experimental delivery, package supervisor receipt external to avoid recursive hash. Separate parent independent audit is not claimed here.'}
dump(ROOT/'MANIFEST.json',manifest);files.append(ROOT/'MANIFEST.json')
(ROOT/'SHA256SUMS.txt').write_text(''.join(f'{sha(p)}  {p.relative_to(ROOT)}\n' for p in files));files.append(ROOT/'SHA256SUMS.txt')
archive=ROOT/name
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in files:z.write(p,str(p.relative_to(ROOT)))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
(ROOT/'archive.sha256').write_text(f'{sha(archive)}  {name}\n')
for p in files+[archive,ROOT/'archive.sha256']:p.chmod(0o444)
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'manifest_files':len(manifest['files']),'readonly':True}))
