"""Verify frozen sources/data/reference, then freeze design before synthetic toys and unique main."""
import collections,difflib,json,math,random,re,shutil
from common import ROOT,dump,read,sha,utc
from integer_audit import check
OLD=ROOT.parent/'official_cvrp_neutral_moves_20261008'
DATA=ROOT.parent/'new_official_cvrp_validation_set_20261008'
AUDIT=ROOT.parent/'audit_official_cvrp_neutral_moves_20261008'
EXPECTED='4a59f1dcc4cc0ee159d5cdd9a229150f2bb82b68209e1ce037fc7c130ef8e408'
assert sha(DATA/'manifest.json')==EXPECTED
manifest=read(DATA/'manifest.json');inventory=read(DATA/'FILE_INVENTORY.json')
for f in inventory['files']:
    p=DATA/f['path'];assert p.stat().st_size==f['size_bytes'] and sha(p)==f['sha256']
gate=read(AUDIT/'AUDIT_RESULT.json')
assert gate['status']=='PASS' and gate['solver_calls']==0
assert gate['main_package_sha256']==sha(OLD/'official_cvrp_neutral_moves_20261008.zip')
oldmanifest=read(OLD/'MANIFEST.json')
for f in oldmanifest['files']:assert sha(OLD/f['path'])==f['sha256']
for f in (OLD/'source').rglob('*.py'):
    rel=f.relative_to(OLD/'source')
    if str(rel) not in ['prepare.py','run.py','supervise.py','analyze.py','package.py']:assert sha(f)==sha(ROOT/'source'/rel)
for name in ['AUDIT_RESULT.json','MANIFEST.json','REPORT_ZH.txt']:
    shutil.copyfile(AUDIT/name,ROOT/'provenance'/('parent_audit_'+name))
shutil.copytree(DATA,ROOT/'provenance/dataset',dirs_exist_ok=False)
names=['A-n33-k5','A-n33-k6','B-n34-k5','B-n35-k5','P-n45-k5','P-n50-k10']
assert [x['name'] for x in manifest['instances']]==names
expectedK=[5,6,5,5,5,10];valid=[]
# Independent strict raw parsing; no constructor/search/oracle runs on official data.
def parse_vrp(path):
    headers={};coords={};demands={};depots=[];section=None
    for line in path.read_text().splitlines():
        line=line.strip()
        if line in ['NODE_COORD_SECTION','DEMAND_SECTION','DEPOT_SECTION']:section=line;continue
        if line=='EOF':break
        if not line:continue
        if section=='NODE_COORD_SECTION':
            a,x,y=map(int,line.split());coords[a]=[x,y]
        elif section=='DEMAND_SECTION':a,q=map(int,line.split());demands[a]=q
        elif section=='DEPOT_SECTION':depots.extend(map(int,line.split()))
        elif ':' in line:
            a,b=line.split(':',1);headers[a.strip()]=b.strip()
    n=int(headers['DIMENSION']);assert list(sorted(coords))==list(range(1,n+1))==list(sorted(demands))
    assert depots==[1,-1] and headers['EDGE_WEIGHT_TYPE']=='EUC_2D'
    return headers,[coords[i] for i in range(1,n+1)],[demands[i] for i in range(1,n+1)]
for name,K,meta in zip(names,expectedK,manifest['instances']):
    inp=read(DATA/'solver_inputs'/f'{name}.instance.json')
    heads,xy,demands=parse_vrp(DATA/'raw'/f'{name}.vrp')
    assert inp['coordinates']==xy and inp['demands']==demands and inp['capacity']==int(heads['CAPACITY'])
    assert inp['max_vehicles']==inp['reported_K']==K==meta['reported_K']
    matrix=[[math.floor(math.sqrt((a[0]-b[0])**2+(a[1]-b[1])**2)+.5) for b in xy] for a in xy]
    assert matrix==inp['distance_matrix']
    raw={'instance_id':name,'coordinates':xy,'demands':demands,'capacity':inp['capacity'],'K':K}
    dump(ROOT/'input'/f'{name}.json',raw)
    ref=read(DATA/'references'/f'{name}.reference_solution.json')
    solroutes=[];solcost=None
    for line in (DATA/'references'/f'{name}.sol').read_text().splitlines():
        if line.startswith('Route'):solroutes.append(list(map(int,line.split(':',1)[1].split())))
        elif line.startswith('Cost'):solcost=int(line.split()[1])
    assert solroutes==ref['routes'] and solcost==ref['total_cost']==ref['official_UB']==meta['official_table']['UB']
    output={'routes':[[0]+r+[0] for r in solroutes],'reported_cost':solcost}
    checked=check(raw,output,K);assert checked['accepted'] and checked['route_costs']==ref['route_costs'] and checked['loads']==ref['route_loads']
    assert math.ceil(sum(demands)/raw['capacity'])==K
    for ext in ['sol','reference_solution.json']:shutil.copyfile(DATA/'references'/f'{name}.{ext}',ROOT/'reference'/f'{name}.{ext}')
    valid.append({'instance_id':name,'K':K,'capacity':raw['capacity'],'customers':len(demands)-1,'reference_check':checked,'reference_status':ref['official_Opt'],'optimality_independently_proved':False,'raw_and_input_equal':True,'distance_matrix_independently_recomputed':True,'duplicate_customer_coordinates':len(xy[1:])-len(set(map(tuple,xy[1:]))),'offdiagonal_zero_edges':sum(matrix[i][j]==0 for i in range(len(xy)) for j in range(i+1,len(xy))),'triangle_violations_ordered':sum(matrix[i][j]>matrix[i][k]+matrix[k][j] for i in range(len(xy)) for j in range(len(xy)) for k in range(len(xy)))})
dump(ROOT/'reports/DATA_AND_REFERENCE_VALIDATION.json',{'passed':True,'utc':utc(),'dataset_manifest_sha256':EXPECTED,'inventory_files_verified':len(inventory['files']),'reference_preparation_read':True,'reference_prep_scope':'Read-only reference feasibility/cost validation before main; no reference used in design/source/solver input. Scoring of heuristic outputs only after seal.','instances':valid,'official_solver_calls':0})
protocol=read(OLD/'freeze/PROTOCOL.json')
for key in ['K_upper_bound','strict_regression','prior_observation']:protocol.pop(key,None)
protocol.update(title='Fixed canonical-neutral rule, six additional official CVRP validation instances',created_utc=utc(),instances=names,instance_K=dict(zip(names,expectedK)),capacities=[r['capacity'] for r in valid],search_seeds=[202610085201,202610085203,202610085207,202610085209],schedule_seed=202610085299,planned_trajectories=96,planned_checkpoint_rows=192,main_cpu_soft_seconds=119,main_cpu_hard_seconds=120,main_wall_seconds=180,main_cpu_guard_seconds=116,main_wall_guard_seconds=170,
 schedule_policy='Shuffle 6 instances x 2 methods x 4 new seeds once with Python random.Random(202610085299), then adjacent mode pairs, strict first for even pair index, neutral first for odd pair index.',
 primary='Regret-2 neutral versus strict; each instance at160k is primary. Report40k as secondary repeated checkpoint. Report all4 planned seeds, completion/legal/reached/failure rates and mean/min/worst cost/gap; paired improve/worsen/same counts.',
 secondary='Cheapest repair neutral versus strict;40k checkpoint; mechanism counts and CPU are descriptive.',
 aggregation='Six named instances are benchmark units, seeds/checkpoints are repeated measurements. Equal-weight six-instance mean of within-instance mean gaps is descriptive only. Report P-n45-k5 separately; prespecified five-instance low-overlap sensitivity excludes only P-n45-k5, without claiming independence.',
 hypothesis_scope='Fixed rule validation on rule-frozen additional official instances and4 new seeds, conditioned on old neutral independent audit PASS. No tuning on new data. Six complete geometries differ but are not six independent geometries; P45 contains all39 old P40 customer coordinates.',
 seed_novelty_scope='Four stated new search seeds, not new statistical units.',
 reference_scope='Each instance uses local K<=reported K, with K from input, not hardcoded5. All6 capacity lower bounds equal reported K, so exact-K and at-most-K coincide here. Official Opt=yes is attributed, no independent proof.',
 anti_leakage='Preparation validates official references read-only, but scientific solver allowlists only source/input/freeze and toy PASS; .sol and reference/provenance blocked. Five-field inputs omit reference metadata. No heuristic gap computed until all output rows are flushed/fsynced/hash-sealed. Read audit is process-scoped, not a claim that preparer never saw public reference values.',
 failure_policy='Exactly one main launch, no retuning, pilot on official instances, reruns, seed/instance replacement. All96 planned rows retained, including failures and unrun work. Invalid or partial observations do not disappear from denominators.',
 resources='Main process119CPU soft/120CPU hard/180wall seconds,3CPU/10wall per trajectory. Same160k deltas and inherited objective accounting. No API/install/purchase/upload.',
 toy_plan=protocol['toy_plan']+['Synthetic mandatory6 and10 vehicles with capacities7 and13, both methods/modes','zero-distance distinctIDs and nonmetric nint counterexample'],
 source_equivalence='official_solver.py, toys.py, integer_distance.py, integer_audit.py, checkpoints.py and all legacy modules are byte-identical to audited old neutral package. Only preparation/reporting/schedule/path and global resource limits change.')
dump(ROOT/'freeze/PROTOCOL.json',protocol)
base=[{'instance_id':n,'method':m,'search_seed':s} for n in names for m in protocol['methods'] for s in protocol['search_seeds']]
random.Random(protocol['schedule_seed']).shuffle(base)
schedule=[{**spec,'acceptance_mode':mode,'parent_schedule_index':i} for i,spec in enumerate(base) for mode in (['strict','neutral'] if i%2==0 else ['neutral','strict'])]
dump(ROOT/'freeze/SCHEDULE.json',schedule)
dump(ROOT/'freeze/GATE_PASS.json',{'status':gate['status'],'read_verified_utc':utc(),'parent_audit_sha256':sha(AUDIT/'AUDIT_RESULT.json'),'parent_package_sha256':gate['main_package_sha256'],'audited_solver_sha256':sha(OLD/'source/official_solver.py'),'new_solver_sha256':sha(ROOT/'source/official_solver.py'),'byte_identical_solver':True})
dump(ROOT/'freeze/INPUT_MANIFEST.json',{'utc':utc(),'dataset_manifest_sha256':EXPECTED,'files':{str(p.relative_to(ROOT)):sha(p) for p in sorted((ROOT/'input').glob('*'))},'adapter':'Exactly instance_id/coordinates/demands/capacity/K from frozen solver_inputs; matrix recomputed by unchanged solver.'})
diffs={};unchanged={}
for f in (OLD/'source').rglob('*.py'):
    rel=f.relative_to(OLD/'source');new=ROOT/'source'/rel
    if sha(f)==sha(new):unchanged[str(rel)]=sha(f)
    else:diffs[str(rel)]=''.join(difflib.unified_diff(f.read_text().splitlines(True),new.read_text().splitlines(True),fromfile='old/'+str(rel),tofile='validation/'+str(rel)))
(ROOT/'provenance/SOURCE_CHANGES.patch').write_text('\n'.join(diffs.values()))
assert 'official_solver.py' in unchanged and 'integer_audit.py' in unchanged and 'integer_distance.py' in unchanged and 'checkpoints.py' in unchanged
(ROOT/'provenance/SOLVER_DIFF.patch').write_text('')
dump(ROOT/'freeze/SOURCE_PROVENANCE.json',{'old_package':str(OLD),'old_manifest_sha256':sha(OLD/'MANIFEST.json'),'unchanged_modules':unchanged,'modified_operational_modules':list(diffs),'solver_diff_empty':True,'source_changes_sha256':sha(ROOT/'provenance/SOURCE_CHANGES.patch'),'new_module':'adaptation_toys.py','data_and_reference_validation_sha256':sha(ROOT/'reports/DATA_AND_REFERENCE_VALIDATION.json')})
files=[p for folder in ['source','input','freeze'] for p in (ROOT/folder).rglob('*') if p.is_file()]
dump(ROOT/'freeze/PRE_TOY_FREEZE.json',{'utc':utc(),'sha256':{str(p.relative_to(ROOT)):sha(p) for p in sorted(files)},'official_solver_calls_before_freeze':0})
from adaptation_toys import run
out=run();assert out['passed'];dump(ROOT/'reports/TOY_VALIDATION.json',out)
pre=read(ROOT/'freeze/PRE_TOY_FREEZE.json');assert all(sha(ROOT/p)==h for p,h in pre['sha256'].items())
runtime=[p for folder in ['source','input','freeze'] for p in (ROOT/folder).rglob('*') if p.is_file()]+[ROOT/'reports/TOY_VALIDATION.json']
dump(ROOT/'freeze/PRE_RUN_FREEZE.json',{'utc':utc(),'sha256':{str(p.relative_to(ROOT)):sha(p) for p in sorted(runtime)},'pre_toy_sha256':sha(ROOT/'freeze/PRE_TOY_FREEZE.json'),'toys_passed':True,'parent_audit_pass_verified':True,'planned_trajectories':96,'main_attempts_before_freeze':0})
print(json.dumps({'frozen':True,'toy_count':len(out['tests']),'gate':'PASS','planned_trajectories':96,'freeze_sha256':sha(ROOT/'freeze/PRE_RUN_FREEZE.json')}))
