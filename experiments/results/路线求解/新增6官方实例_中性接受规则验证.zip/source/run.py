"""Unique reference-blind heuristic process; seals all trajectories before scoring."""
import hashlib,json,os,platform,sys,time
from pathlib import Path
sys.dont_write_bytecode=True
from common import ROOT,dump,read,sha,utc,verify
if (ROOT/'raw/STARTED.json').exists():raise SystemExit('Main already attempted; no reruns')
# Install before importing solver or verifying frozen files. Shared-root reads allowed
# only for this task source/input/freeze and the toy PASS report, never references.
reads=[];blocked=[]
def guard(event,args):
 if event!='open':return
 target,mode,flags=args
 if not isinstance(target,(str,bytes,os.PathLike)):return
 p=Path(os.fsdecode(target)).resolve()
 write=bool(flags & (os.O_WRONLY|os.O_RDWR)) if isinstance(flags,int) else bool(mode and any(c in mode for c in 'wax+'))
 if write:return
 if p.suffix=='.sol':
  blocked.append(str(p));raise PermissionError('Reference solution read blocked')
 if str(p).startswith('/workspace/'):
  allowed=any(p.is_relative_to(ROOT/part) for part in ['source','input','freeze']) or p==ROOT/'reports/TOY_VALIDATION.json'
  if not allowed:
   blocked.append(str(p));raise PermissionError('Reference-blind shared-read contract blocked '+str(p))
 reads.append(str(p))
sys.addaudithook(guard)
freeze=verify();cfg=read(ROOT/'freeze/PROTOCOL.json');schedule=read(ROOT/'freeze/SCHEDULE.json')
import official_solver as solver
allowed=sorted(os.sched_getaffinity(0)) if hasattr(os,'sched_getaffinity') else []
selected=allowed[-1] if allowed else None
if selected is not None:os.sched_setaffinity(0,{selected})
dump(ROOT/'receipts/ENVIRONMENT.json',{'python':sys.version,'platform':platform.platform(),'pid':os.getpid(),
 'start_utc':utc(),'affinity_before':allowed,'selected_cpu':selected,'stdlib_only':True,
 'installed_dependencies':0,'external_api_calls':0,'model_calls':0,'uploads':0})
start=time.process_time();wall=time.perf_counter()
dump(ROOT/'raw/STARTED.json',{'utc':utc(),'planned_trajectories':len(schedule),'freeze_sha256':sha(ROOT/'freeze/PRE_RUN_FREEZE.json')})
solver_cfg={k:cfg[k] for k in ['delta_limit','iterations','per_trajectory_cpu_seconds','per_trajectory_wall_seconds']}
stream_hash=hashlib.sha256()
with (ROOT/'raw/heuristics.jsonl').open('x',encoding='utf-8') as handle:
 for index,spec in enumerate(schedule):
  raw=read(ROOT/'input'/f"{spec['instance_id']}.json")
  assert sorted(raw)==sorted(cfg['solver_interface'])
  if time.process_time()-start+cfg['per_trajectory_cpu_seconds']>cfg['main_cpu_guard_seconds'] or time.perf_counter()-wall+cfg['per_trajectory_wall_seconds']>cfg['main_wall_guard_seconds']:
   result={**spec,'status':'NOT_RUN','stop_reason':'main_resource_guard','output':None,'deltas':0,'trace':[]}
  else:
   result=solver.run_one(raw,spec['method'],spec['search_seed'],{**solver_cfg,'neutral_accept':spec['acceptance_mode']=='neutral'})
  result.update(acceptance_mode=spec['acceptance_mode'],parent_schedule_index=spec['parent_schedule_index'],schedule_index=index,finished_utc=utc(),input_sha256=sha(ROOT/'input'/f"{spec['instance_id']}.json"))
  line=json.dumps(result,ensure_ascii=False,allow_nan=False)+'\n'
  handle.write(line);handle.flush();os.fsync(handle.fileno());stream_hash.update(line.encode('utf-8'))
  print(json.dumps({'run':index+1,**spec,'status':result['status'],'deltas':result['deltas'],
    'cost':(result['output'] or {}).get('reported_cost'),'cpu':result.get('solver_cpu_seconds')}),flush=True)
dump(ROOT/'raw/HEURISTICS_FINISHED.json',{'utc':utc(),'trajectory_count':len(schedule),
 'heuristics_sha256':stream_hash.hexdigest(),'all_rows_flushed_fsynced':True,
 'main_process_cpu_at_seal':time.process_time()-start,'main_process_wall_at_seal':time.perf_counter()-wall,
 'reference_or_provenance_reads':0,'unexpected_denied_reads':blocked})
dump(ROOT/'raw/READ_AUDIT.json',{'opened_read_paths':sorted(set(reads)),'open_read_count':len(reads),
 'denied':blocked,'reference_read_count':0,'scope':'Python audit open events for main process after guard installed before solver import.'})
dump(ROOT/'raw/FINISHED.json',{'utc':utc(),'stage':'all heuristic outputs sealed; no reference scoring in this process'})
