"""Post-seal scoring and replay, with no optimizer import or invocation."""
import collections,copy,csv,json,math,shutil,statistics
from common import ROOT,dump,read,sha,utc,verify
from integer_audit import check
from checkpoints import at
verify()
seal=read(ROOT/'raw/HEURISTICS_FINISHED.json')
assert seal['heuristics_sha256']==sha(ROOT/'raw/heuristics.jsonl')
records=[json.loads(line) for line in (ROOT/'raw/heuristics.jsonl').read_text().splitlines()]
protocol=read(ROOT/'freeze/PROTOCOL.json');schedule=read(ROOT/'freeze/SCHEDULE.json')
keys=lambda r:(r['instance_id'],r['method'],r['search_seed'],r['acceptance_mode'])
assert len(records)==len(schedule)==96 and [keys(r) for r in records]==[keys(r) for r in schedule]
reference_read_started=utc()
# Reference feasibility was validated during preparation. This is the first
# scoring of sealed heuristic outputs against reference values.
refs={name:read(ROOT/'reference'/f'{name}.reference_solution.json') for name in protocol['instances']}

def canon(routes):return tuple(sorted(min(tuple(r),tuple(reversed(r))) for r in routes))
def bodies(o):return [r[1:-1] for r in o['routes']]
def geo_signature(raw,o,with_load=False):
    parts=[]
    for route in bodies(o):
        coords=tuple(tuple(raw['coordinates'][node]) for node in route)
        seq=min(coords,tuple(reversed(coords)))
        parts.append((seq,sum(raw['demands'][node] for node in route)) if with_load else seq)
    return tuple(sorted(parts))
def loads(raw,o):return tuple(sorted(sum(raw['demands'][n] for n in r) for r in bodies(o)))
def strip_timing(value):
    if isinstance(value,list):return [strip_timing(x) for x in value]
    if isinstance(value,dict):return {k:strip_timing(v) for k,v in value.items() if not k.endswith('_seconds') and k not in ['finished_utc','schedule_index']}
    return value

def project(new,old):
    if isinstance(old,dict):return {k:project(new[k],v) for k,v in old.items() if not k.endswith('_seconds') and k not in ['finished_utc','schedule_index']}
    if isinstance(old,list):
        assert len(new)==len(old)
        return [project(a,b) for a,b in zip(new,old)]
    return new

def packed(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
regressions=[];trace_checks=[];rows=[];anomalies=[];mechanisms=[];errors=[]
for r in records:
    name=r['instance_id'];raw=read(ROOT/'input'/f'{name}.json');ref=refs[name]['total_cost']
    current=copy.deepcopy(r.get('baseline'));best=copy.deepcopy(current)
    counts={'equal_cost_candidates':0,'neutral_proposals':0,'neutral_accepted':0,'canonical_noops':0,'strict_improvements':0}
    descriptive={'neutral_coordinate_path_changed':0,'neutral_coordinate_path_unchanged':0,'neutral_load_multiset_changed':0,'neutral_load_multiset_unchanged':0,'neutral_coordinate_route_load_signature_changed':0,'neutral_coordinate_route_load_signature_unchanged':0}
    snapshots=[];passed=True
    if current is not None:assert check(raw,current,raw['K'])['accepted']
    for e in r.get('trace',[]):
        assert e['deltas']<=160000
        candidate=e['candidate']
        if candidate is not None:
            assert e['candidate_status']=='complete' and check(raw,candidate,raw['K'])['accepted']
            c=candidate['reported_cost'];pc=current['reported_cost'];assert c==int(c)
            kind='strict_improvement' if c<pc else ('canonical_noop' if canon(bodies(candidate))==canon(bodies(current)) else 'neutral_proposal') if c==pc else 'worse'
            assert e['acceptance_kind']==kind
            if c==pc:counts['equal_cost_candidates']+=1
            if kind=='neutral_proposal':
                counts['neutral_proposals']+=1
                for label,a,b in [('coordinate_path',geo_signature(raw,current),geo_signature(raw,candidate)),('load_multiset',loads(raw,current),loads(raw,candidate)),('coordinate_route_load_signature',geo_signature(raw,current,True),geo_signature(raw,candidate,True))]:
                    descriptive['neutral_'+label+('_changed' if a!=b else '_unchanged')]+=1
            if kind=='canonical_noop':counts['canonical_noops']+=1
            accepted=kind=='strict_improvement' or (kind=='neutral_proposal' and r['acceptance_mode']=='neutral')
            assert e['accepted']==accepted
            if accepted:current=copy.deepcopy(candidate)
            if kind=='strict_improvement':counts['strict_improvements']+=1;best=copy.deepcopy(candidate)
            elif accepted:counts['neutral_accepted']+=1
        else:assert e['candidate_status']!='complete' and not e['accepted']
        assert e['current']==current and e['incumbent']==best
        assert check(raw,e['current'],raw['K'])['accepted'] and check(raw,e['incumbent'],raw['K'])['accepted']
        snapshots.append((e['deltas'],dict(counts),dict(descriptive)))
    if r.get('output') is not None:assert r['output']==best and check(raw,r['output'],raw['K'])['accepted']
    if r.get('current_output') is not None:assert r['current_output']==current
    assert r['deltas']<=160000
    if 'delta_by_kind' in r:assert sum(r['delta_by_kind'].values())==r['deltas']
    if 'neutral_counts' in r:assert r['neutral_counts']==counts and r['accepted_improvements']==counts['strict_improvements']
    trace_checks.append({'instance_id':name,'method':r['method'],'search_seed':r['search_seed'],'acceptance_mode':r['acceptance_mode'],'checked_trace_entries':len(r.get('trace',[])),'passed':True})
    mechanisms.append({**{k:r[k] for k in ['instance_id','method','search_seed','acceptance_mode']},**counts,**descriptive})
    for cut in protocol['checkpoints']:
        cp=at(r,cut);checked=check(raw,cp['output'],raw['K']);cost=checked['cost'] if checked['accepted'] else None
        selected=[x for x in snapshots if x[0]<=cut]
        cc=selected[-1][1] if selected else {k:0 for k in counts};dd=selected[-1][2] if selected else {k:0 for k in descriptive}
        row={**{k:r[k] for k in ['instance_id','method','search_seed','acceptance_mode']},'checkpoint':cut,'trajectory_status':r['status'],'stop_reason':r['stop_reason'],'reached_cut':cp['reached_cut'],'legal':checked['accepted'],'cost':cost,'official_reference':ref,'gap_percent':100*(cost-ref)/ref if cost is not None else None,'official_value_hit':cost==ref,'output':cp['output'],'check':checked,'last_atomic_record_deltas':cp['last_atomic_record_deltas'],'counts':cc,'descriptive':dd}
        rows.append(row)
        if cost is not None and cost<ref:anomalies.append(row)
summaries=[];pairs=[]
for name in protocol['instances']:
    for cut in protocol['checkpoints']:
        for method in protocol['methods']:
            for mode in protocol['acceptance_modes']:
                group=[r for r in rows if (r['instance_id'],r['checkpoint'],r['method'],r['acceptance_mode'])==(name,cut,method,mode)]
                costs=[r['cost'] for r in group if r['legal']];gaps=[r['gap_percent'] for r in group if r['legal']];status=collections.Counter(r['trajectory_status'] for r in group)
                rec={'instance_id':name,'checkpoint':cut,'method':method,'acceptance_mode':mode,'planned_seeds':4,'observed_rows':len(group),'legal_outputs':len(costs),'reached_cut':sum(r['reached_cut'] for r in group),'INIT_FAIL':status['INIT_FAIL'],'CONSTRUCTION_FAIL':status['CONSTRUCTION_FAIL'],'NOT_RUN':status['NOT_RUN'],'other_failure':sum(v for k,v in status.items() if k not in ['LEGAL_COMPLETION','INIT_FAIL','CONSTRUCTION_FAIL','NOT_RUN']),'official_reference':refs[name]['total_cost'],'cost_mean':statistics.mean(costs) if costs else None,'cost_min':min(costs) if costs else None,'cost_worst':max(costs) if costs else None,'gap_mean_percent':statistics.mean(gaps) if gaps else None,'gap_min_percent':min(gaps) if gaps else None,'gap_worst_percent':max(gaps) if gaps else None,'official_value_hits':sum(r['official_value_hit'] for r in group),'seed_costs':{str(r['search_seed']):r['cost'] for r in group},'counts':{k:sum(r['counts'][k] for r in group) for k in counts},'descriptive':{k:sum(r['descriptive'][k] for r in group) for k in descriptive}}
                summaries.append(rec)
            for seed in protocol['search_seeds']:
                both={r['acceptance_mode']:r for r in rows if (r['instance_id'],r['checkpoint'],r['method'],r['search_seed'])==(name,cut,method,seed)}
                strict,neutral=both['strict'],both['neutral'];d=neutral['cost']-strict['cost'] if strict['legal'] and neutral['legal'] else None
                pairs.append({'instance_id':name,'checkpoint':cut,'method':method,'search_seed':seed,'strict_cost':strict['cost'],'neutral_cost':neutral['cost'],'neutral_minus_strict':d,'outcome':'missing_or_illegal' if d is None else 'improved' if d<0 else 'worsened' if d>0 else 'same'})
paired_summary=[]
for name in protocol['instances']:
    for cut in protocol['checkpoints']:
        for method in protocol['methods']:
            group=[r for r in pairs if (r['instance_id'],r['checkpoint'],r['method'])==(name,cut,method)];c=collections.Counter(r['outcome'] for r in group);diff=[r['neutral_minus_strict'] for r in group if r['neutral_minus_strict'] is not None]
            paired_summary.append({'instance_id':name,'checkpoint':cut,'method':method,'planned_pairs':4,'improved':c['improved'],'worsened':c['worsened'],'same':c['same'],'missing_or_illegal':c['missing_or_illegal'],'mean_neutral_minus_strict':statistics.mean(diff) if diff else None})
receipt=read(ROOT/'receipts/main.json');audit=read(ROOT/'raw/READ_AUDIT.json')
assert receipt['exit_code']==0 and not audit['denied'] and audit['reference_read_count']==0
arms=[]
for mode in protocol['acceptance_modes']:
    group=[r for r in records if r['acceptance_mode']==mode]
    arms.append({'acceptance_mode':mode,'planned_trajectories':48,'solver_cpu_seconds_sum':sum(r.get('solver_cpu_seconds',0) for r in group),'solver_cpu_seconds_mean':statistics.mean(r.get('solver_cpu_seconds',0) for r in group),'solver_wall_seconds_sum':sum(r.get('solver_wall_seconds',0) for r in group),'final_checker_cpu_seconds_sum':sum(r.get('final_checker_cpu_seconds',0) for r in group),'counted_deltas':sum(r['deltas'] for r in group),'matrix_pair_evaluations':sum(r.get('matrix_distances',0) for r in group),'objective_edge_evaluations':sum(r.get('objective_edges',0) for r in group),'delta_by_kind':{k:sum(r.get('delta_by_kind',{}).get(k,0) for r in group) for k in ['savings','removal','insertion']},'counts':{k:sum(r.get('neutral_counts',{}).get(k,0) for r in group) for k in counts}})
resources={'main_receipt':receipt,'by_arm':arms,'fixed_delta_total':sum(r['deltas'] for r in records),'all_96_reached_160k':all(r['deltas']==160000 for r in records),'external_api_calls':0,'model_calls':0,'dependency_installs':0,'purchases':0,'uploads':0,'oracle_calls':0,'cpu_comparison_scope':'Instrumented one-shot same-machine execution, paired mode order alternates. Same counted deltas does not mean same CPU; complete candidates and canonical computations differ. Timing is descriptive and not a dedicated runtime benchmark.'}
for rec in summaries:
    rec['legal_output_rate']=rec['legal_outputs']/rec['planned_seeds']
    rec['budget_completion_rate']=rec['reached_cut']/rec['planned_seeds']
    rec['mean_scope']='Available legal outputs; denominators and failures explicitly retained; no imputation.'
aggregate=[]
for cut in protocol['checkpoints']:
    for method in protocol['methods']:
        for scope,names in [('six_instances_descriptive',protocol['instances']),('five_low_overlap_sensitivity',[x for x in protocol['instances'] if x!='P-n45-k5']),('P45_correlated_variant',['P-n45-k5'])]:
            modes={}
            for mode in protocol['acceptance_modes']:
                group=[r for r in summaries if r['instance_id'] in names and r['checkpoint']==cut and r['method']==method and r['acceptance_mode']==mode]
                all_complete=all(r['legal_outputs']==4 and r['reached_cut']==4 for r in group)
                modes[mode]={'instances':len(names),'planned_runs':4*len(names),'legal_runs':sum(r['legal_outputs'] for r in group),'reached_cut':sum(r['reached_cut'] for r in group),'mean_of_instance_mean_gap_percent':statistics.mean(r['gap_mean_percent'] for r in group) if all_complete else None,'complete_all_planned_seeds':all_complete}
            diff=modes['neutral']['mean_of_instance_mean_gap_percent']-modes['strict']['mean_of_instance_mean_gap_percent'] if all(v['complete_all_planned_seeds'] for v in modes.values()) else None
            pg=[r for r in paired_summary if r['instance_id'] in names and r['checkpoint']==cut and r['method']==method]
            aggregate.append({'scope':scope,'instances':names,'checkpoint':cut,'method':method,'arms':modes,'neutral_minus_strict_mean_gap_percentage_points':diff,'paired_search_repeat_counts':{k:sum(r[k] for r in pg) for k in ['improved','worsened','same','missing_or_illegal']},'inference':'Descriptive only; seeds are repeats, geometry independence not assumed. Aggregate gap withheld if any planned seed is incomplete.'})
summary={'utc':utc(),'design':protocol['hypothesis_scope'],'unique_named_instances':6,'statistical_independence_claimed':False,'primary':'regret2 at160000; per-instance paired neutral versus strict','planned_trajectories':96,'observed_trajectories':len(records),'legal_trajectories':sum(r['status']=='LEGAL_COMPLETION' for r in records),'trajectory_status_counts':dict(collections.Counter(r['status'] for r in records)),'planned_checkpoint_rows':192,'observed_checkpoint_rows':len(rows),'legal_checkpoint_rows':sum(r['legal'] for r in rows),'checkpoint_rows_reached':sum(r['reached_cut'] for r in rows),'reference_scoring_started_after_seal':reference_read_started,'references_validated_before_main':True,'sealed_utc':seal['utc'],'byte_identical_solver_to_audited_parent':read(ROOT/'freeze/GATE_PASS.json')['byte_identical_solver'],'below_reference_anomaly_count':len(anomalies),'per_instance_method_arm':summaries,'paired_comparison':paired_summary,'prespecified_descriptive_aggregation':aggregate,'errors':errors,'independent_audit_status':'Not performed by this worker; parent to independently audit sealed package.','limitations':['Methods frozen from prior posthoc three-instance exploration; no tuning on these6 or new4 seeds.','Six full geometry multisets differ but are not6 independent geometries. P45 contains all39 oldP40 customer coordinates; report separately.','Seeds and checkpoints repeat search/measurement, not independent instances. Low overlap does not prove independence.','No significance, SOTA or universal superiority claim.','Canonical removes labels and whole-route reversal only; real IDs including co-located distinct-demand customers remain.','Neutral paths can cycle or yield worse paired final best; no tabu, annealing, restarts or tuning.','Equal160k counted deltas is not equal CPU; timings are one-shot instrumented descriptive measurements.','Official Opt=yes is attributed only, not independently proved.','Failures retained in planned denominators; legal-cost statistics do not impute missing results.']}
for path,obj in [('SUMMARY.json',summary),('CHECKPOINT_RESULTS.json',rows),('PAIRED_RESULTS.json',pairs),('PAIRED_SUMMARY.json',paired_summary),('MECHANISM_COUNTS.json',mechanisms),('TRACE_CHECKS.json',{'passed':not errors,'results':trace_checks,'entries_checked':sum(x['checked_trace_entries'] for x in trace_checks)}),('RESOURCE_ACCOUNTING.json',resources),('BELOW_REFERENCE_ANOMALIES.json',anomalies),('PRESPECIFIED_AGGREGATES.json',aggregate)]:dump(ROOT/'reports'/path,obj)
with (ROOT/'reports/PER_INSTANCE_METHOD_ARM.csv').open('x',newline='') as f:
    fields=[k for k in summaries[0] if k not in ['seed_costs','counts','descriptive']]+list(counts)+list(descriptive);w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
    for r in summaries:w.writerow({**{k:r[k] for k in fields if k in r},**r['counts'],**r['descriptive']})
with (ROOT/'reports/PAIRED_SUMMARY.csv').open('x',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(paired_summary[0]));w.writeheader();w.writerows(paired_summary)
def fmt(v):return 'NA' if v is None else f'{v:.4f}'
lines=['官方CVRP中性接受规则：固定方法新实例验证','',f"唯一主跑：96计划轨迹，观察{len(records)}，合法{summary['legal_trajectories']}/96；192检查点合法{summary['legal_checkpoint_rows']}/192、达预算{summary['checkpoint_rows_reached']}/192。",f"主跑退出码{receipt['exit_code']}，wait4实际CPU {receipt['child_total_cpu_seconds']:.6f}s、wall {receipt['elapsed_wall_seconds']:.6f}s；硬限120CPU/180wall。",'6实例×2方法×strict/neutral×4新seed；每轨迹160k counted delta，40k/160k原子BEST检查点。主对比regret2在160k；cheapest和40k为次要。','原中性实验独审明确PASS后启动；solver、接受规则、canonical、best规则、计账、初始化和repair源码与原包字节相同。没有按新数据调参。','K从输入分别取5/6/5/5/5/10；Q分别100/100/100/100/150/100。局部协议K<=reportedK，各例容量下界等于K，故本组exact-K与at-most-K一致。','P45含旧P40全部39客户坐标，是相关扩展变体；其他5例低重叠敏感性表在跑前声明，也不据此声称独立。','seed不是实例，检查点不是样本量；六例平均只是等权描述。无显著性或SOTA结论。','', '160k主对比：每实例regret2 strict→neutral的mean gap（min/worst见下面完整表），配对计数为改善/恶化/相同/缺失：']
for name in protocol['instances']:
    g={r['acceptance_mode']:r for r in summaries if r['instance_id']==name and r['method']=='regret2' and r['checkpoint']==160000}
    pair=next(r for r in paired_summary if r['instance_id']==name and r['method']=='regret2' and r['checkpoint']==160000)
    lines.append(f"{name}: {fmt(g['strict']['gap_mean_percent'])}% → {fmt(g['neutral']['gap_mean_percent'])}%；{pair['improved']}/{pair['worsened']}/{pair['same']}/{pair['missing_or_illegal']}")
lines+=['','预声明描述性平均与敏感性：']
for a in aggregate:
    if a['checkpoint']==160000:
        lines.append(f"{a['scope']} | {a['method']} | strict/neutral mean gap {fmt(a['arms']['strict']['mean_of_instance_mean_gap_percent'])}/{fmt(a['arms']['neutral']['mean_of_instance_mean_gap_percent'])}% | difference {fmt(a['neutral_minus_strict_mean_gap_percentage_points'])}百分点 | paired search repeats {a['paired_search_repeat_counts']}")
lines+=['','完整每实例/检查点/方法/开关：4计划seed全分母；成本及gap统计只统计合法输出，缺失不填补。']
for r in summaries:
    lines.append(f"{r['instance_id']} | {r['checkpoint']} | {r['method']} | {r['acceptance_mode']} | legal {r['legal_outputs']}/4 reached {r['reached_cut']}/4 | mean/min/worst cost {r['cost_mean']}/{r['cost_min']}/{r['cost_worst']} | mean/min/worst gap {fmt(r['gap_mean_percent'])}/{fmt(r['gap_min_percent'])}/{fmt(r['gap_worst_percent'])}% | INIT/CONSTRUCTION/NOT_RUN/other {r['INIT_FAIL']}/{r['CONSTRUCTION_FAIL']}/{r['NOT_RUN']}/{r['other_failure']}")
lines+=['','全部配对结果（neutral best - strict best）：']
for r in paired_summary:lines.append(f"{r['instance_id']} | {r['checkpoint']} | {r['method']} | improved/worsened/same/missing {r['improved']}/{r['worsened']}/{r['same']}/{r['missing_or_illegal']} | mean cost difference {r['mean_neutral_minus_strict']}")
lines+=['','计账与机制：']
for r in arms:lines.append(f"{r['acceptance_mode']}：48轨迹delta={r['counted_deltas']}，solver CPU={r['solver_cpu_seconds_sum']:.6f}s，矩阵pair={r['matrix_pair_evaluations']}，完整目标edge={r['objective_edge_evaluations']}；counts={r['counts']}。")
lines+=['同delta不等于同CPU；计时包含canonical与检查开销，仅单次描述。','无tabu、退火、重启、pilot、补跑、换例、换seed、oracle、API、安装、购买或上传。','准备阶段只读核验官方参考可行性/成本。solver进程未读取参考或官方目标，全部输出flush/fsync/hash封存后才计算gap。不是准备人员未见过公开成本的盲法宣称。','原3例包不改；所有保存candidate/current/best用整数逐边checker复核。',f'低于官方参考异常={len(anomalies)}；此处为自检，等待父任务独审。','', '引用：冻结官方表、原始.vrp/.sol及TSPLIB95来源与检索时间见provenance/dataset/manifest.json；其中Opt=yes为CVRPLIB归属声明，无独立最优性证明。','https://galgos.inf.puc-rio.br/cvrplib/index.php/en/instances','https://comopt.ifi.uni-heidelberg.de/software/TSPLIB95/tsp/tsp95.pdf']
(ROOT/'reports/REPORT_ZH.txt').write_text('\n'.join(lines)+'\n')
print(json.dumps({'legal':summary['legal_trajectories'],'checkpoint_legal':summary['legal_checkpoint_rows'],'cpu':receipt['child_total_cpu_seconds'],'paired160k':[r for r in paired_summary if r['checkpoint']==160000],'aggregate160k':[r for r in aggregate if r['checkpoint']==160000]},ensure_ascii=False))
assert not errors
