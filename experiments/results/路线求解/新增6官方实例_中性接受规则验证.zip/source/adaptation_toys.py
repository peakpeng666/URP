"""K/Q-only synthetic integration extension; never optimize an official instance."""
import official_solver as s
from integer_audit import check
from integer_distance import edge
from toys import run as inherited_run

def run():
    report=inherited_run()
    for K,Q in [(6,7),(10,13)]:
        raw={'instance_id':f'SYNTHETIC_K{K}_Q{Q}','coordinates':[[0,0]]+[[1,0]]*K,'demands':[0]+[Q]*K,'capacity':Q,'K':K}
        for method in ['cheapest','regret2']:
            for neutral in [False,True]:
                r=s.run_one(raw,method,901,dict(delta_limit=137,iterations=100000,per_trajectory_cpu_seconds=3.,per_trajectory_wall_seconds=10.,neutral_accept=neutral))
                assert r['status']=='LEGAL_COMPLETION' and r['deltas']==137 and r['stop_reason']=='delta_budget'
                assert r['K']==K and len(r['output']['routes'])==K and r['output']['reported_cost']==2*K
                assert check(raw,r['output'],K)['accepted'] and not check(raw,r['output'],K-1)['accepted']
                assert check(raw,r['current_output'],K)['accepted']
                report['records'].append(r)
        report['tests'].append(f'unmocked_K{K}_Q{Q}_all_four_arms_use_input_bounds')
    assert edge([0,0],[1,1])+edge([1,1],[2,2])<edge([0,0],[2,2])
    assert edge([1,0],[1,0])==0
    report['tests']+=['rounded_EUC_2D_can_be_nonmetric','distinct_IDs_at_zero_distance_preserved']
    report['synthetic_new_KQ_solver_calls']=8
    return report
