"""One-shot stage runner with process-group wall cap and exact wait4 CPU receipt."""
import argparse,json,os,resource,signal,subprocess,sys,time
from common import ROOT,dump,utc
p=argparse.ArgumentParser();p.add_argument('stage',choices=['prepare','main','audit','package']);args=p.parse_args()
script={'prepare':'prepare.py','main':'run.py','audit':'analyze.py','package':'package.py'}[args.stage]
limits={'prepare':(19,20,60),'main':(119,120,180),'audit':(19,20,60),'package':(19,20,60)};soft,hard,wall=limits[args.stage]
receipt=ROOT/'receipts'/f'{args.stage}.json';receipt.parent.mkdir(exist_ok=True)
if receipt.exists():raise SystemExit('Never rerun an attempted stage')
if args.stage=='main' and (ROOT/'raw/STARTED.json').exists():raise SystemExit('Main already launched')
start=time.perf_counter();cpu=time.process_time()
def pre():os.setsid();resource.setrlimit(resource.RLIMIT_CPU,(soft,hard))
with (ROOT/'receipts'/f'{args.stage}.stdout.log').open('x') as stdout,(ROOT/'receipts'/f'{args.stage}.stderr.log').open('x') as stderr:
    child=subprocess.Popen([sys.executable,'-B',str(ROOT/'source'/script)],stdout=stdout,stderr=stderr,preexec_fn=pre,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
    terminated=False;status=None;usage=None
    while True:
        pid,st,ru=os.wait4(child.pid,os.WNOHANG)
        if pid:status=st;usage=ru;break
        if time.perf_counter()-start>=wall:
            terminated=True;os.killpg(child.pid,signal.SIGKILL);pid,status,usage=os.wait4(child.pid,0);break
        time.sleep(.025)
    code=os.waitstatus_to_exitcode(status);child.returncode=code
value={'stage':args.stage,'utc':utc(),'exit_code':code,'raw_wait_status':status,'signal':-code if code<0 else None,'wall_limit_kill':terminated,'cpu_soft_limit_seconds':soft,'cpu_hard_limit_seconds':hard,'wall_limit_seconds':wall,'child_user_cpu_seconds':usage.ru_utime,'child_system_cpu_seconds':usage.ru_stime,'child_total_cpu_seconds':usage.ru_utime+usage.ru_stime,'maxrss_kib':usage.ru_maxrss,'elapsed_wall_seconds':time.perf_counter()-start,'supervisor_cpu_checkpoint_seconds':time.process_time()-cpu,'complete':code==0}
dump(receipt,value);print(json.dumps(value));sys.exit(0 if code==0 else 1)
