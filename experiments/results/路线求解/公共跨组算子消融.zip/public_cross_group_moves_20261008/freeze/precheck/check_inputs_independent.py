"""Verify new copied public data and baseline provenance; no optimization or old-tree access."""
import pathlib,json,hashlib,math,collections
R=pathlib.Path('/workspace/shared/public_cross_group_moves_20261008');O=pathlib.Path('/workspace/shared/public_cross_group_moves_review_20261008')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def cost(rr,cc):return sum(int(math.sqrt((cc[a][0]-cc[b][0])**2+(cc[a][1]-cc[b][1])**2)+0.5) for route in rr for a,b in zip(route,route[1:]))
def parse_vrp(p):
    header={};coords={};demands={};depots=[];section=None
    for raw in p.read_text().splitlines():
        line=raw.strip()
        if line=='EOF':break
        if line in ('NODE_COORD_SECTION','DEMAND_SECTION','DEPOT_SECTION'):section=line;continue
        if section=='NODE_COORD_SECTION':i,x,y=line.split();coords[int(i)]=[float(x),float(y)]
        elif section=='DEMAND_SECTION':i,d=line.split();demands[int(i)]=int(d)
        elif section=='DEPOT_SECTION':
            if line!='-1':depots.append(int(line))
        elif ':' in line:
            key,value=line.split(':',1);header[key.strip()]=value.strip()
    n=int(header['DIMENSION']);assert sorted(coords)==sorted(demands)==list(range(1,n+1));assert depots==[1];assert header['EDGE_WEIGHT_TYPE']=='EUC_2D'
    return header,[coords[i] for i in range(1,n+1)],[demands[i] for i in range(1,n+1)]
def checkroutes(rr,dd,q,k):
    assert len(rr)==k and all(len(r)>=2 and r[0]==r[-1]==0 for r in rr)
    assert sorted(x for r in rr for x in r[1:-1])==list(range(1,len(dd)))
    loads=[sum(dd[x] for x in r[1:-1]) for r in rr];assert max(loads)<=q;return loads

tasks=json.loads((R/'inputs/SEARCH_TASKS.json').read_text());refs=json.loads((R/'inputs/POSTSCORING_REFERENCES.json').read_text())
original=[json.loads(x) for x in (R/'inputs/prior/ORIGINAL_INITIALIZER_RESULTS.jsonl').read_text().splitlines()]
prior=[json.loads(x) for x in (R/'inputs/prior/FIXED_GROUP_RESULTS.jsonl').read_text().splitlines()]
prior_tasks=json.loads((R/'inputs/prior/FIXED_GROUP_TASKS.json').read_text());manifest=json.loads((R/'freeze/INPUT_MANIFEST.json').read_text())
assert len(tasks)==len(refs)==len(prior)==len(prior_tasks)==16
assert [t['selection_slot'] for t in tasks]==list(range(1,17));assert len({t['instance_id'] for t in tasks})==16
for entry in manifest['copied_files']:
    p=R/entry['copy'];assert sha(p)==entry['sha256'] and p.stat().st_size==entry['bytes']
rows=[];bases=collections.defaultdict(list)
for t,ref,past,pt in zip(tasks,refs,prior,prior_tasks):
    name=t['instance_id'];assert ref['instance_id']==past['instance_id']==pt['instance_id']==name
    data=json.loads((R/'inputs/instances'/f'{name}.json').read_text());norm=json.loads((R/'inputs/normalized'/f'{name}.json').read_text());head,coords,dem=parse_vrp(R/'inputs/instances'/f'{name}.vrp')
    assert coords==data['coordinates']==norm['coordinates'];assert dem==data['demands']==norm['demands']
    assert int(head['CAPACITY'])==data['capacity']==norm['capacity'];assert data['K']==norm['K']==t['K']==pt['K']
    assert 'at most K_ref nonempty routes' in norm['problem_definition']
    assert norm['source_instance_sha256']==sha(R/'inputs/instances'/f'{name}.vrp')
    assert norm['source_reference_sha256']==sha(R/'inputs/references'/f'{name}.sol')
    loads=checkroutes(t['baseline_routes'],dem,data['capacity'],t['K'])
    assert t['baseline_routes']==past['baseline_routes']==pt['baseline_routes']
    originals=[x for x in original if x['instance_id']==name and x['endpoint']=='initialize_256'];assert len(originals)==3
    assert [x['call_id'] for x in originals]==t['original_call_ids'];assert len({x['arm'] for x in originals})==3
    for orig in originals:
        assert orig['status']=='SUCCESS';assert orig['output']['routes']==t['baseline_routes'];assert orig['independent_check']['accepted']
    basecost=cost(t['baseline_routes'],coords);assert basecost==ref['baseline_integer_cost']==pt['baseline_integer_cost']
    checkroutes(ref['reference_routes'],dem,data['capacity'],t['K']);assert cost(ref['reference_routes'],coords)==ref['reference_integer_cost']==pt['reference_integer_cost']
    checkroutes(ref['previous_two_opt_routes'],dem,data['capacity'],t['K']);assert cost(ref['previous_two_opt_routes'],coords)==ref['previous_two_opt_integer_cost']==past['two_opt']['independent_check']['cost']
    bases[json.dumps([coords,dem],sort_keys=True)].append(name)
    rows.append(dict(instance_id=name,K=t['K'],baseline_cost=basecost,baseline_loads=loads,problem_definition=norm['problem_definition'],input_sha256=sha(R/'inputs/instances'/f'{name}.json'),normalized_sha256=sha(R/'inputs/normalized'/f'{name}.json')))
assert len(bases)==14
result=dict(status='PASS',tasks=16,distinct_coordinate_demand_bases=14,aliased_bases=[v for v in bases.values() if len(v)>1],all_three_original_initializer_arms_identical=True,original_input_and_reference_file_hashes_match_normalization=True,source_vrp_roundtrip_verified=True,baseline_and_reference_coverage_capacity_K_verified=True,baseline_cost_and_prior_two_opt_cost_recomputed=True,original_definition_all16_at_most_K_nonempty=True,no_benchmark_optimization=True,no_old_tree_reads=True,rows=rows,input_manifest_sha256=sha(R/'freeze/INPUT_MANIFEST.json'))
(O/'INPUTS_INDEPENDENT_RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='rows'},indent=2))
