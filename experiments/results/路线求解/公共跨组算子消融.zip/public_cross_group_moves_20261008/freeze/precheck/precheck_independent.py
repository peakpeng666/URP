"""Independent invented-fixture pre-execution audit. Never reads benchmark inputs."""
import sys, os, importlib.util, json, hashlib, random, itertools, math, datetime
from pathlib import Path
sys.dont_write_bytecode = True
BASE=Path('/workspace/shared/public_cross_group_moves_20261008')
OUT=Path('/workspace/shared/public_cross_group_moves_review_20261008')
spec=importlib.util.spec_from_file_location('reviewed_engine',BASE/'source/engine.py'); engine=importlib.util.module_from_spec(spec);spec.loader.exec_module(engine)
OPS={'T':['two_opt'],'TR':['two_opt','relocate'],'TS':['two_opt','swap'],'TRS':['two_opt','relocate','swap']}

def weights(coords):
    return [[int(math.sqrt((x[0]-y[0])**2+(x[1]-y[1])**2)+0.5) for y in coords] for x in coords]
def full_cost(routes,d):
    z=0
    for row in routes:
        for idx in range(len(row)-1): z+=d[row[idx]][row[idx+1]]
    return z

def enum(routes,op):
    out=[]
    if op=='two_opt':
        for a in range(len(routes)):
            for i in range(1,len(routes[a])-1):
                for j in range(i+1,len(routes[a])-1):out.append([a,i,a,j])
    elif op=='relocate':
        for a in range(len(routes)):
            for i in range(1,len(routes[a])-1):
                for b in range(len(routes)):
                    if a==b:continue
                    for j in range(1,len(routes[b])):out.append([a,i,b,j])
    else:
        for a in range(len(routes)):
            for b in range(a+1,len(routes)):
                for i in range(1,len(routes[a])-1):
                    for j in range(1,len(routes[b])-1):out.append([a,i,b,j])
    return out

def transform(routes,op,c):
    r=[list(row) for row in routes];a,i,b,j=c
    if op=='two_opt':r[a]=r[a][:i]+list(reversed(r[a][i:j+1]))+r[a][j+1:]
    elif op=='relocate':
        x=r[a][i];r[a]=r[a][:i]+r[a][i+1:];r[b]=r[b][:j]+[x]+r[b][j:]
    else:r[a][i],r[b][j]=r[b][j],r[a][i]
    return r

def validate(routes,demands,q,k):
    assert len(routes)==k
    assert all(len(r)>=2 and r[0]==r[-1]==0 for r in routes)
    assert sorted(x for r in routes for x in r[1:-1])==list(range(1,len(demands)))
    return [sum(demands[x] for x in r[1:-1]) for r in routes]

def reference(coords,demands,q,routes,arm,budget):
    d=weights(coords);r=[x[:] for x in routes];initial=full_cost(r,d);cur=initial;ops=OPS[arm]
    trace=[];scans=[];moves=[];cp=[{'attempted':0,'cost':cur}];counts={op:dict(attempted=0,feasible=0,accepted=0) for op in ops};oi=0;stop='BUDGET_EXHAUSTED'
    while len(trace)<budget:
        op=ops[oi];cs=enum(r,op);start=len(trace);accepted=False;done=True
        for c in cs:
            if len(trace)==budget:done=False;break
            rr=transform(r,op,c);ll=validate(rr,demands,q,len(routes));feasible=max(ll,default=0)<=q
            delta=full_cost(rr,d)-cur if feasible else None;take=feasible and delta<0
            trace.append([op,*c,int(feasible),delta,int(take)])
            counts[op]['attempted']+=1;counts[op]['feasible']+=int(feasible)
            if take:
                r=rr;cur=full_cost(r,d);counts[op]['accepted']+=1
                moves.append(dict(attempted=len(trace),op=op,candidate=c,delta=delta,cost=cur));accepted=True;done=False
            if len(trace) in (100,1000,5000,10000,20000):cp.append(dict(attempted=len(trace),cost=cur))
            if take:break
        scans.append(dict(op=op,start_attempted=start,end_attempted=len(trace),complete_nonimproving=done and not accepted,accepted=accepted))
        if accepted:oi=0
        elif done:
            oi+=1
            if oi==len(ops):stop='LOCAL_OPTIMUM';break
        else:break
    return dict(arm=arm,budget=budget,routes=r,loads=validate(r,demands,q,len(routes)),initial_cost=initial,cost=cur,attempted=len(trace),feasible=sum(v['feasible'] for v in counts.values()),accepted=len(moves),counts=counts,termination=stop,unspent_budget=budget-len(trace),trace=trace,scans=scans,accepted_moves=moves,checkpoints=cp)

def main():
    delta_checks=0;capacity_rejects=0;empty_targets=0;empty_sources=0;enum_states=0
    coords=[(0,0),(10,0),(0,11),(-12,0),(0,-13),(1,1)];demands=[0,1,2,3,1,2];d=weights(coords)
    # Every permutation and 3-slot composition of five synthetic customers.
    for perm in itertools.permutations(range(1,6)):
        for cut1 in range(6):
            for cut2 in range(cut1,6):
                routes=[[0,*perm[:cut1],0],[0,*perm[cut1:cut2],0],[0,*perm[cut2:],0]]
                loads=validate(routes,demands,100,3);q=max(loads);enum_states+=1
                assert engine.matrix(coords)==d
                for op in OPS['TRS']:
                    cs=enum(routes,op);assert [list(c) for c in engine.candidates(routes,op)]==cs
                    assert len(cs)==len(set(tuple(c) for c in cs))
                    for c in cs:
                        rr=transform(routes,op,c);ll=validate(rr,demands,q,3);ok=max(ll)<=q
                        feasible,delta=engine.evaluate(routes,loads,demands,q,d,op,c)
                        assert feasible==ok
                        assert delta==(full_cost(rr,d)-full_cost(routes,d) if ok else None)
                        mr=[row[:] for row in routes];ml=loads[:];engine.apply(mr,ml,demands,op,c)
                        assert mr==rr and ml==ll
                        capacity_rejects+=int(not ok);delta_checks+=1
                        if op=='relocate':empty_targets+=int(len(routes[c[2]])==2);empty_sources+=int(len(routes[c[0]])==3)
    rng=random.Random(845199)
    fixtures=[]
    fixtures.append(([(0,0)],[0],0,[[0,0],[0,0],[0,0]]))
    fixtures.append(([(0,0),(0,0),(0,0)],[0,0,0],0,[[0,1,0],[0,2,0],[0,0]]))
    for t in range(100):
        n=2+t%8;k=1+t%4;c=[(rng.randrange(-40,41),rng.randrange(-40,41)) for _ in range(n)];dem=[0]+[rng.randrange(0,6) for _ in range(n-1)]
        order=list(range(1,n));rng.shuffle(order);routes=[[0,0] for _ in range(k)]
        for x in order:routes[rng.randrange(k)].insert(-1,x)
        q=max(sum(dem[x] for x in row) for row in routes)+t%3
        fixtures.append((c,dem,q,routes))
    searches=0;local=0;budget_ends=0;accepted={op:0 for op in OPS['TRS']};infeasible_trace=0
    for coords,demands,q,routes in fixtures:
        for arm in OPS:
            for budget in (0,1,2,7,37,1000):
                expected=reference(coords,demands,q,routes,arm,budget)
                got=engine.search(coords,demands,q,routes,arm,budget)
                assert got==expected,(arm,budget,got,expected)
                validate(got['routes'],demands,q,len(routes));assert max(got['loads'],default=0)<=q
                for op,values in got['counts'].items():accepted[op]+=values['accepted']
                infeasible_trace+=sum(1 for tr in got['trace'] if tr[5]==0)
                if got['termination']=='LOCAL_OPTIMUM':
                    local+=1
                    for op in OPS[arm]:
                        for c in enum(got['routes'],op):
                            rr=transform(got['routes'],op,c);ll=validate(rr,demands,q,len(routes))
                            assert max(ll,default=0)>q or full_cost(rr,weights(coords))>=got['cost']
                else:assert got['attempted']==budget;budget_ends+=1
                searches+=1
    assert capacity_rejects and empty_targets and empty_sources and all(accepted.values()) and infeasible_trace
    assert engine.matrix([(0,0),(0.5,0),(1.5,0),(2.5,0)])[0]==[0,1,2,3]
    result=dict(status='PASS',scope='invented fixtures only; no benchmark optimization',engine_sha256=hashlib.sha256((BASE/'source/engine.py').read_bytes()).hexdigest(),all_permutation_partition_states=enum_states,candidate_delta_feasibility_apply_checks=delta_checks,capacity_infeasible_candidates=capacity_rejects,relocate_empty_destination_cases=empty_targets,relocate_singleton_source_cases=empty_sources,full_trace_reference_searches=searches,local_optima_exhaustively_verified=local,budget_exhaustion_cases=budget_ends,infeasible_attempts_in_search_traces=infeasible_trace,accepted_fixture_moves=accepted,rounding_half_up=True,reviewed_files={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (BASE/'source').glob('*.py')})
    (OUT/'PRECHECK_INDEPENDENT_RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
