"""Read-only independent replay of already-saved formal traces. NEVER imports/runs optimizer.
Only moves explicitly recorded as accepted are applied. Rejected candidates are checked one by one.
Neighborhood enumeration is used only to certify saved scan completeness/order, never to select a move.
"""
import json,pathlib,math,hashlib,collections,csv,datetime,decimal
R=pathlib.Path('/workspace/shared/public_cross_group_moves_20261008');O=pathlib.Path('/workspace/shared/public_cross_group_moves_review_20261008')
OPS={'T':['two_opt'],'TR':['two_opt','relocate'],'TS':['two_opt','swap'],'TRS':['two_opt','relocate','swap']}
def read(p):return json.loads((R/p).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def full_cost(rr,d):return sum(d[a][b] for row in rr for a,b in zip(row,row[1:]))
def matrix(coords):
    with decimal.localcontext() as ctx:
        ctx.prec=80;c=[[decimal.Decimal(str(x)) for x in row] for row in coords]
        return [[int(sum((a[i]-b[i])**2 for i in (0,1)).sqrt().quantize(decimal.Decimal(1),rounding=decimal.ROUND_HALF_UP)) for b in c] for a in c]
def loads(rr,dem,k):
    assert len(rr)==k and all(len(r)>=2 and r[0]==r[-1]==0 for r in rr)
    assert all(type(x)is int for r in rr for x in r)
    assert sorted(x for r in rr for x in r[1:-1])==list(range(1,len(dem)))
    return [sum(dem[x] for x in row[1:-1]) for row in rr]
def enum(rr,op):
    if op=='two_opt':
        for a,row in enumerate(rr):
            for i in range(1,len(row)-1):
                for j in range(i+1,len(row)-1):yield [a,i,a,j]
    elif op=='relocate':
        for a,row in enumerate(rr):
            for i in range(1,len(row)-1):
                for b,target in enumerate(rr):
                    if b!=a:
                        for j in range(1,len(target)):yield [a,i,b,j]
    else:
        for a,row in enumerate(rr):
            for b in range(a+1,len(rr)):
                for i in range(1,len(row)-1):
                    for j in range(1,len(rr[b])-1):yield [a,i,b,j]
def transform(rr,op,c):
    r=[list(x) for x in rr];a,i,b,j=c
    if op=='two_opt':r[a]=r[a][:i]+r[a][i:j+1][::-1]+r[a][j+1:]
    elif op=='relocate':x=r[a][i];r[a]=r[a][:i]+r[a][i+1:];r[b]=r[b][:j]+[x]+r[b][j:]
    else:r[a][i],r[b][j]=r[b][j],r[a][i]
    return r

def replay(task,data,result):
    arm=result['arm'];ops=OPS[arm];k=task['K'];q=data['capacity'];dem=data['demands'];d=matrix(data['coordinates']);rr=[list(x) for x in task['baseline_routes']]
    assert max(loads(rr,dem,k))<=q;initial=full_cost(rr,d);cur=initial;n=0;oi=0;trace=result['trace'];moves=[];cp=[dict(attempted=0,cost=cur)];counts={op:dict(attempted=0,feasible=0,accepted=0) for op in ops}
    assert result['budget']==20000;assert len(trace)==result['attempted']<=20000
    accepted_states=[]
    for scan_idx,scan in enumerate(result['scans']):
        assert oi<len(ops);op=ops[oi];assert scan['op']==op and scan['start_attempted']==n
        end=scan['end_attempted'];assert n<=end<=len(trace)
        cs=enum(rr,op);seen_take=False
        for ix in range(n,end):
            tr=trace[ix];c=next(cs,None);assert c is not None and tr[:5]==[op,*c]
            candidate=transform(rr,op,c);ll=loads(candidate,dem,k);feasible=max(ll)<=q;newcost=full_cost(candidate,d);delta=newcost-cur if feasible else None;take=feasible and delta<0
            assert tr[5:]==[int(feasible),delta,int(take)],(task['instance_id'],arm,ix,tr,delta)
            counts[op]['attempted']+=1;counts[op]['feasible']+=int(feasible)
            if take:
                assert ix==end-1 and not seen_take;rr=candidate;cur=newcost;seen_take=True;counts[op]['accepted']+=1
                moves.append(dict(attempted=ix+1,op=op,candidate=c,delta=delta,cost=cur))
                accepted_states.append(dict(attempted=ix+1,cost=cur,loads=ll,nonempty_routes=sum(len(r)>2 for r in rr),routes_sha256=hashlib.sha256(json.dumps(rr,separators=(',',':')).encode()).hexdigest()))
            if ix+1 in (100,1000,5000,10000,20000):cp.append(dict(attempted=ix+1,cost=cur))
        n=end;assert scan['accepted']==seen_take
        if seen_take:
            assert not scan['complete_nonimproving'];oi=0
        elif scan['complete_nonimproving']:
            assert next(cs,None) is None;oi+=1
        else:
            assert next(cs,None) is not None;assert n==20000 and scan_idx==len(result['scans'])-1
    assert n==len(trace)
    if result['termination']=='LOCAL_OPTIMUM':assert oi==len(ops)
    else:assert result['termination']=='BUDGET_EXHAUSTED' and n==20000 and oi<len(ops)
    assert result['initial_cost']==initial and result['cost']==cur<=initial
    assert result['routes']==rr and result['loads']==loads(rr,dem,k) and max(result['loads'])<=q
    assert result['counts']==counts and result['accepted_moves']==moves and result['checkpoints']==cp
    assert result['accepted']==len(moves) and result['feasible']==sum(v['feasible'] for v in counts.values())
    assert result['unspent_budget']==20000-n
    assert result['reference_read_attempts']==0 and result['denied_io_events']==[]
    assert result['limits']==dict(hard_cpu_seconds=2,external_wall_seconds=3,address_space_MiB=256)
    return dict(instance_id=task['instance_id'],arm=arm,attempted=n,feasible=result['feasible'],accepted=len(moves),initial_cost=initial,cost=cur,termination=result['termination'],K=k,nonempty_routes=sum(len(x)>2 for x in rr),trace_replayed=True,full_cost_and_constraints_at_every_attempt=True,all_saved_scans_valid=True,accepted_states=accepted_states)

def main():
    assert (R/'raw/FINISHED.json').exists(),'Formal run is not finished; stop without running optimizer.'
    tasks=read('inputs/SEARCH_TASKS.json');schedule=read('freeze/SCHEDULE.json');results=[json.loads(x) for x in (R/'raw/results.jsonl').read_text().splitlines()];attempts=[json.loads(x) for x in (R/'raw/attempts.jsonl').read_text().splitlines()]
    assert len(tasks)==16 and len(schedule)==len(results)==64 and len(attempts)==128
    assert len({e['call_id'] for e in schedule})==64
    assert collections.Counter((e['instance_id'],e['arm']) for e in schedule)==collections.Counter((t['instance_id'],a) for t in tasks for a in OPS)
    frozen=read('freeze/FROZEN_FILES.json')
    for p,v in frozen['files'].items():assert sha(R/p)==v['sha256'],p
    rawmanifest=read('raw/RAW_UNREVIEWED_MANIFEST.json')
    for p,v in rawmanifest['files'].items():assert sha(R/p)==v['sha256'],p
    rows=[];failed=[]
    for i,(entry,meta) in enumerate(zip(schedule,results)):
        assert all(meta[k]==v for k,v in entry.items());a,b=attempts[2*i:2*i+2]
        assert a['phase']=='STARTED' and b['phase']=='FINISHED';assert all(a[k]==v and b[k]==v for k,v in entry.items());assert a['utc']<=b['utc']
        if i:assert attempts[2*i-1]['utc']<=a['utc']
        if meta['status']!='SUCCESS':failed.append(meta);continue
        assert meta['returncode']==0
        for f in ('stdout','stderr'):assert sha(R/meta[f])==meta[f+'_sha256']
        assert (R/meta['stderr']).read_bytes()==b''
        result=read(meta['stdout']);task=tasks[entry['selection_slot']-1];assert task['instance_id']==entry['instance_id'] and result['arm']==entry['arm']
        data=read(f"inputs/instances/{task['instance_id']}.json");row=replay(task,data,result);row['call_id']=entry['call_id'];rows.append(row)
        for key,value in meta['summary'].items():assert result[key]==value
        assert meta['K_slots']==row['K'] and meta['nonempty_routes']==row['nonempty_routes']
    refs={x['instance_id']:x for x in read('inputs/POSTSCORING_REFERENCES.json')}
    for row in rows:
        ref=refs[row['instance_id']];row['reference_cost']=ref['reference_integer_cost'];row['reference_gap_percent']=100*(row['cost']/row['reference_cost']-1)
        if row['arm']=='T':
            meta=next(r for r in results if r['call_id']==row['call_id']);assert read(meta['stdout'])['routes']==ref['previous_two_opt_routes'] and row['cost']==ref['previous_two_opt_integer_cost']
    sums={}
    for arm in OPS:
        rr=[x for x in rows if x['arm']==arm];base={x['instance_id']:x for x in rows if x['arm']=='T'}
        sums[arm]=dict(valid_tasks=len(rr),cost_sum=sum(x['cost'] for x in rr),attempted=sum(x['attempted'] for x in rr),feasible=sum(x['feasible'] for x in rr),accepted=sum(x['accepted'] for x in rr),mean_reference_gap_percent=sum(x['reference_gap_percent'] for x in rr)/16 if len(rr)==16 else None,local_optimum=sum(x['termination']=='LOCAL_OPTIMUM' for x in rr),budget_exhausted=sum(x['termination']=='BUDGET_EXHAUSTED' for x in rr),better_than_T=sum(x['cost']<base[x['instance_id']]['cost'] for x in rr),equal_to_T=sum(x['cost']==base[x['instance_id']]['cost'] for x in rr),worse_than_T=sum(x['cost']>base[x['instance_id']]['cost'] for x in rr))
    result=dict(status='PASS' if not failed else 'PARTIAL_FAILURES_RETAINED',formal_optimization_rerun=False,optimizer_imports=False,tasks=16,calls=64,full_trace_replayed_successful_calls=len(rows),retained_failures=failed,total_attempts_verified=sum(x['attempted'] for x in rows),total_accepted_moves_verified=sum(x['accepted'] for x in rows),summary=sums,rows=rows,frozen_manifest_sha256=sha(R/'freeze/FROZEN_FILES.json'),raw_manifest_sha256=sha(R/'raw/RAW_UNREVIEWED_MANIFEST.json'),auditor_script_sha256=sha(pathlib.Path(__file__)))
    (O/'SAVED_TRACE_INDEPENDENT_AUDIT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ('rows','retained_failures')},indent=2))
if __name__=='__main__':main()
