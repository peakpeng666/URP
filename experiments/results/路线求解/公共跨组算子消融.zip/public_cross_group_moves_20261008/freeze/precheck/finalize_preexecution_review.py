"""Consolidate completed independent pre-execution checks. Does not optimize benchmark data."""
import pathlib,json,hashlib,sys,ast,collections
sys.dont_write_bytecode=True
sys.path.insert(0,str(pathlib.Path(__file__).parent))
from audit_saved_traces import matrix as decimal_matrix
from precheck_independent import engine
R=pathlib.Path('/workspace/shared/public_cross_group_moves_20261008');O=pathlib.Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
assert not (R/'raw/STARTED.json').exists()
pre=read(O/'PRECHECK_INDEPENDENT_RESULT.json');inputs=read(O/'INPUTS_INDEPENDENT_RESULT.json');worker=read(O/'WORKER_FIXTURE_RESULT.json')
assert pre['status']==inputs['status']==worker['status']=='PASS'
assert pre['engine_sha256']==sha(R/'source/engine.py');assert worker['worker_sha256']==sha(R/'source/worker.py')
assert inputs['input_manifest_sha256']==sha(R/'freeze/INPUT_MANIFEST.json')
tasks=read(R/'inputs/SEARCH_TASKS.json');schedule=read(R/'freeze/SCHEDULE.json');protocol=read(R/'freeze/PROTOCOL.json')
assert len(schedule)==64 and len({s['call_id'] for s in schedule})==64
arms=['T','TR','TS','TRS'];positions={a:collections.Counter() for a in arms};edge_cells=0
for slot,task in enumerate(tasks):
    group=schedule[slot*4:(slot+1)*4];rot=slot%4
    assert [g['arm'] for g in group]==arms[rot:]+arms[:rot]
    assert all(g['selection_slot']==slot+1 and g['instance_id']==task['instance_id'] for g in group)
    for position,g in enumerate(group):positions[g['arm']][position]+=1
    data=read(R/'inputs/instances'/f"{task['instance_id']}.json")
    independent=decimal_matrix(data['coordinates']);assert independent==engine.matrix(data['coordinates']);edge_cells+=len(independent)**2
assert all(list(count.values())==[4]*4 for count in positions.values())
assert protocol['budget']['attempted_candidates_per_task_arm']==20000 and protocol['budget']['total_max_candidates']==1280000
assert protocol['limits']['total_CPU_hard_bound_seconds']==133 and protocol['limits']['formal_calls']==64
assert protocol['secondary_frozen_checkpoints']==[0,100,1000,5000,10000,20000]
for p in (R/'source').glob('*.py'):ast.parse(p.read_text())
result={
 'status':'PASS','scope':'Independent pre-execution review of current source, invented fixtures, frozen-candidate inputs, protocol and schedule; formal run/remote archival not yet performed.',
 'benchmark_optimization_executed_by_reviewer':False,'formal_run_started':False,'reviewer_writes_only_new_review_directory':True,
 'core_algorithm':{k:v for k,v in pre.items() if k not in ('reviewed_files',)},
 'input_review':{k:v for k,v in inputs.items() if k!='rows'},
 'worker_invented_fixture_review':worker,
 'independent_decimal_distance_cells_equal_search':edge_cells,
 'static_review':{
  'four_arm_operator_sets_correct':True,'deterministic_candidate_order_as_protocol':True,'every_candidate_including_capacity_reject_consumes_budget':True,
  'first_strict_improvement_restarts_two_opt':True,'fixed_K_and_empty_slots_preserved':True,'reference_not_used_by_engine':True,
  'worker_reference_free_exact_payload_and_IO_hook':True,'runner_validates_all16_initial_inputs_before_STARTED':True,
  'runner_requires_private_remote_readback_receipt_and_frozen_hashes':True,'exclusive_STARTED_and_call_outputs_prevent_formal_rerun':True,
  'balanced_frozen_execution_schedule_64_calls':True,'report_requires_raw_remote_readback_and_manifest_hashes':True,
  'failed_calls_retained_and_all16_mean_null_if_any_failure':True,'None_report_format_issue_fixed_before_freeze':True,
  'exploratory_scope_14_bases_equal_caps_not_equal_actual_effort_and_no_optimality_claim_declared':True},
 'pending_before_formal_execution':['Package and freeze these exact reviewed files and precheck evidence.','Obtain private PREEXEC upload and verified byte-identical remote readback receipt.','Verify runtime frozen hashes still match; only author invokes unique formal runner.'],
 'scope_limits':['Input provenance verified against copied source VRP, normalized original definitions, copied original initializer records and copy manifest; reviewer did not read old directories.','No formal output claim until saved trace review.','Remote upload owner-only permissions and timing are verified later from archivist receipt.'],
 'source_sha256':{str(p.relative_to(R)):sha(p) for p in sorted((R/'source').glob('*.py'))},
 'protocol_sha256':sha(R/'freeze/PROTOCOL.json'),'schedule_sha256':sha(R/'freeze/SCHEDULE.json'),
 'review_evidence_sha256':{p.name:sha(p) for p in sorted(O.glob('*')) if p.is_file() and p.name!='INDEPENDENT_PRECHECK_FINAL.json'}
}
(O/'INDEPENDENT_PRECHECK_FINAL.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':'PASS','independent_decimal_distance_cells':edge_cells,'source_sha256':result['source_sha256'],'evidence':str(O/'INDEPENDENT_PRECHECK_FINAL.json')},indent=2))
