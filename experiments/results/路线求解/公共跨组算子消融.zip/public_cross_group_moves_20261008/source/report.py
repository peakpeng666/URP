"""Post-execution scoring only; reference data first accessed here, after raw archive."""
import json,pathlib,csv,hashlib,datetime
from check_saved import raw_data,validate
R=pathlib.Path(__file__).resolve().parents[1]
def read(p):return json.loads((R/p).read_text())
def write(p,v): (R/p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    receipt=read('provenance/RAW_UNREVIEWED_DRIVE_RECEIPT.json');assert receipt['owner_only'] and receipt['remote_readback_sha256_verified']
    assert receipt['sha256']==receipt['download_sha256']==sha(R.parent/(R.name+'_RAW_UNREVIEWED.zip'))
    raw_manifest=read('raw/RAW_UNREVIEWED_MANIFEST.json')
    assert all(sha(R/p)==v['sha256'] for p,v in raw_manifest['files'].items())
    refs={r['instance_id']:r for r in read('inputs/POSTSCORING_REFERENCES.json')};tasks={r['instance_id']:r for r in read('inputs/SEARCH_TASKS.json')}
    records=[json.loads(x) for x in (R/'raw/results.jsonl').read_text().splitlines()];rows=[];trajectories=[];byarm={a:[] for a in ('T','TR','TS','TRS')}
    for meta in records:
        row={k:meta[k] for k in ('call_id','instance_id','selection_slot','arm','status')};row['cost']=None
        task=tasks[row['instance_id']];ref=refs[row['instance_id']];row['reference_cost']=ref['reference_integer_cost']
        if row['status']=='SUCCESS':
            result=read(meta['stdout']);d,dem,q,coords=raw_data(R/'inputs/instances'/f"{row['instance_id']}.vrp")
            data=read(f"inputs/instances/{row['instance_id']}.json")
            assert data['demands']==dem and data['capacity']==q and data['coordinates']==[list(map(float,z)) for z in coords]
            chk=validate(result['routes'],dem,q,task['K'],d);base=validate(task['baseline_routes'],dem,q,task['K'],d);rr=validate(ref['reference_routes'],dem,q,task['K'],d)
            assert base['cost']==ref['baseline_integer_cost'] and rr['cost']==ref['reference_integer_cost'] and chk['cost']==result['cost']<=base['cost']
            row.update({k:result[k] for k in ('cost','initial_cost','attempted','feasible','accepted','termination','unspent_budget')})
            row.update({'K_slots':chk['K_slots'],'nonempty_routes':chk['nonempty_routes'],'reference_gap_percent':100*(chk['cost']/rr['cost']-1),
                        'cost_reduction':base['cost']-chk['cost'],'process_cpu_seconds_for_audit_only':meta['process_cpu_seconds_for_audit_only'],
                        'process_wall_seconds_for_audit_only':meta['process_wall_seconds_for_audit_only']})
            row['matches_previous_two_opt_routes']=result['routes']==ref['previous_two_opt_routes'] if row['arm']=='T' else None
            row['matches_previous_two_opt_cost']=result['cost']==ref['previous_two_opt_integer_cost'] if row['arm']=='T' else None
            for op in ('two_opt','relocate','swap'):
                for count in ('attempted','feasible','accepted'):row[f'{op}_{count}']=result['counts'].get(op,{}).get(count,0)
            for level in (0,100,1000,5000,10000,20000):
                valid=result['attempted']>=level or result['termination']=='LOCAL_OPTIMUM'
                moves=[m for m in result['accepted_moves'] if m['attempted']<=level]
                val=moves[-1]['cost'] if moves else base['cost']
                trajectories.append({'instance_id':row['instance_id'],'arm':row['arm'],'budget_node':level,'cost':val if valid else None,
                    'actual_attempted_to_terminal':result['attempted'],'carried_after_certified_local_optimum':level>result['attempted'] and result['termination']=='LOCAL_OPTIMUM'})
        rows.append(row);byarm[row['arm']].append(row)
    assert len(rows)==64 and all(len(x)==16 for x in byarm.values())
    bases=[r['baseline_integer_cost'] for r in refs.values()];reference=[r['reference_integer_cost'] for r in refs.values()]
    summaries={}
    basearm={r['instance_id']:r for r in byarm['T']}
    for arm,items in byarm.items():
        good=[r for r in items if r['cost'] is not None];full=len(good)==16
        summaries[arm]={'valid_tasks':len(good),'failure_or_undetermined_tasks':16-len(good),'mean_reference_gap_percent_all16':sum(r['reference_gap_percent'] for r in good)/16 if full else None,
          'cost_sum_all16':sum(r['cost'] for r in good) if full else None,'attempted_sum':sum(r.get('attempted',0) for r in good),'feasible_sum':sum(r.get('feasible',0) for r in good),
          'accepted_sum':sum(r.get('accepted',0) for r in good),'local_optimum_tasks':sum(r.get('termination')=='LOCAL_OPTIMUM' for r in good),
          'budget_exhausted_tasks':sum(r.get('termination')=='BUDGET_EXHAUSTED' for r in good),
          'cost_better_than_T_tasks':sum(r['cost']<basearm[r['instance_id']]['cost'] for r in good if basearm[r['instance_id']]['cost'] is not None),
          'cost_equal_to_T_tasks':sum(r['cost']==basearm[r['instance_id']]['cost'] for r in good if basearm[r['instance_id']]['cost'] is not None),
          'cost_worse_than_T_tasks':sum(r['cost']>basearm[r['instance_id']]['cost'] for r in good if basearm[r['instance_id']]['cost'] is not None),
          'nonempty_less_than_K_tasks':sum(r['nonempty_routes']<r['K_slots'] for r in good)}
    old=read('freeze/OLD_TREES_BEFORE.json');changed=[p for p,v in old.items() if not pathlib.Path(p).is_file() or sha(pathlib.Path(p))!=v['sha256']]
    frozen=read('freeze/FROZEN_FILES.json');fchanged=[p for p,v in frozen['files'].items() if sha(R/p)!=v['sha256']]
    summary={'stage':'POSTHOC_CROSS_GROUP_MOVE_ABLATION','independent_review_status':'PENDING','tasks':16,'coordinate_demand_bases':14,'calls':64,
       'mean_original_reference_gap_percent':sum(100*(a/b-1) for a,b in zip(bases,reference))/16,'primary_endpoint':'Terminal cost under equal20000 attempted-candidate caps; early local optimum allowed',
       'arms':summaries,'baseline_matches_previous_two_opt_all16':all(r.get('matches_previous_two_opt_cost') and r.get('matches_previous_two_opt_routes') for r in byarm['T']),
       'frozen_files_unchanged':not fchanged,'old_files_unchanged':not changed,'old_file_count':len(old),'changed_old_files':changed,'changed_frozen_files':fchanged,
       'limitations':['Same exploratory16 tasks with14 coordinate-demand bases; not independent new sample or confirmatory inference.',
       'Equal attempted-candidate ceilings, not equal realized attempts, feasible moves, floating operations, CPU or wall time.',
       'Capacity-rejected candidates count against budget. All attempts, feasibility and accepted counts retained.',
       'Operators have different per-candidate work; no speed advantage or SOTA/global-optimum claim.',
       'Greedy ordering and operator schedule are part of treatment; adding an operator need not dominate at same budget.',
       'Feasible reference is scoring comparator, not proved globally optimal; never read by search.',
       'Original fixed-K semantics preserve K slots and allow at most K nonempty routes; occupancy reported separately.',
       '16 terminal outcomes per arm primary. Frozen checkpoint curves secondary, no best-node selection or significance test.']}
    write('reports/SUMMARY.json',summary)
    for path,vals in [('reports/PER_CALL.csv',rows),('reports/FIXED_BUDGET_TRAJECTORIES.csv',trajectories)]:
        keys=list(dict.fromkeys(k for row in vals for k in row))
        with (R/path).open('w') as f:w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(vals)
    lines=['公共CVRP-derived固定K跨组局部调整消融（新事后探索阶段）','独立结果审查：待完成。','所有16任务保留，14个坐标/需求底本；64次唯一正式调用。','预算为每任务每臂20,000候选尝试上限，非等实际算力。','']
    for arm,s in summaries.items():
        gap='未定' if s['mean_reference_gap_percent_all16'] is None else format(s['mean_reference_gap_percent_all16'],'.9f')
        lines.append(f"{arm}: {s['valid_tasks']}/16有效；平均reference gap {gap}%；总成本{s['cost_sum_all16']}；尝试{s['attempted_sum']}；可行{s['feasible_sum']}；接受{s['accepted_sum']}；局部最优{s['local_optimum_tasks']}；预算终止{s['budget_exhausted_tasks']}。")
    lines+=['','T=仅组内2-opt；TR=2-opt+单客跨路线relocate；TS=2-opt+两客跨路线swap；TRS=三者。','共同起点、同一整数EUC_2D、固定扫描顺序，严格改进才接受；reference只在全部正式调用和raw归档后评分。',
      '实际尝试数、容量可行率、单次计算成本不同。不能把本表解释为等CPU的算子因果优势。','本结果用于定位是否可通过简单跨组调整获得可行质量改进，不是全局最优或新数据泛化证据。',
      '原问题为K个固定槽、至多K条非空路线；允许空槽，K_slots与nonempty_routes逐任务分别记录。','全部旧证据及冻结文件哈希保持不变。','']
    (R/'reports/REPORT_ZH.txt').write_text('\n'.join(lines))
if __name__=='__main__':main()
