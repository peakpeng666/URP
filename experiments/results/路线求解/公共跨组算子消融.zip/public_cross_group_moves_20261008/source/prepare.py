"""Freeze only existing raw inputs; never optimize benchmark data."""
import pathlib,json,hashlib,shutil,datetime
R=pathlib.Path(__file__).resolve().parents[1];B=R.parent
OLD=[B/x for x in ('public_capacity_benchmark_preparation_20261008','public_capacity_benchmark_execution_20261008_r1','public_route_quality_rescoring_20261008','public_fixed_group_ordering_20261008')]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def copy(src,dest):
    p=R/dest;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,p)
    return {'source':str(src),'copy':dest,'bytes':p.stat().st_size,'sha256':sha(p)}
def main():
    assert not (R/'freeze/INPUT_MANIFEST.json').exists()
    old={str(p):{'bytes':p.stat().st_size,'sha256':sha(p)} for tree in OLD for p in sorted(tree.rglob('*')) if p.is_file()}
    write(R/'freeze/OLD_TREES_BEFORE.json',old)
    fixed=OLD[3];tasks=json.loads((fixed/'inputs/TASKS.json').read_text());raw=[json.loads(x) for x in (OLD[1]/'raw/results.jsonl').read_text().splitlines()]
    history=[json.loads(x) for x in (fixed/'raw/results.jsonl').read_text().splitlines()]
    copies=[];minimal=[];references=[];bases=set()
    for task,previous in zip(tasks,history):
        name=task['instance_id'];matches=[r for r in raw if r['instance_id']==name and r['endpoint']=='initialize_256']
        assert len(matches)==3 and all(r['output']['routes']==task['baseline_routes'] for r in matches)
        norm=json.loads((OLD[0]/'normalized'/f'{name}.json').read_text())
        assert 'at most K_ref nonempty routes' in norm['problem_definition']
        data=json.loads((OLD[1]/'input'/f'{name}.json').read_text());assert data['K']==task['K']==norm['K']
        bases.add(json.dumps([data['coordinates'],data['demands']],sort_keys=True))
        minimal.append({'instance_id':name,'selection_slot':task['selection_slot'],'K':task['K'],'baseline_routes':task['baseline_routes'],
            'K_semantics':'fixed K slots, at most K nonempty routes','original_call_ids':[r['call_id'] for r in matches]})
        references.append({'instance_id':name,'baseline_integer_cost':task['baseline_integer_cost'],'reference_integer_cost':task['reference_integer_cost'],
            'reference_routes':task['reference_routes'],'reference_url':task['reference_url'],'instance_url':task['instance_url'],
            'previous_two_opt_routes':[r['route'] for r in previous['two_opt']['result']['routes']],
            'previous_two_opt_integer_cost':previous['two_opt']['independent_check']['cost']})
        for src,dest in [(OLD[1]/'input'/f'{name}.json',f'inputs/instances/{name}.json'),(fixed/'inputs/instances'/f'{name}.vrp',f'inputs/instances/{name}.vrp'),
                         (fixed/'inputs/references'/f'{name}.sol',f'inputs/references/{name}.sol'),(OLD[0]/'normalized'/f'{name}.json',f'inputs/normalized/{name}.json')]:copies.append(copy(src,dest))
    for src,dest in [(OLD[1]/'raw/results.jsonl','inputs/prior/ORIGINAL_INITIALIZER_RESULTS.jsonl'),(fixed/'inputs/TASKS.json','inputs/prior/FIXED_GROUP_TASKS.json'),
                     (fixed/'raw/results.jsonl','inputs/prior/FIXED_GROUP_RESULTS.jsonl'),(fixed/'independent_review/INDEPENDENT_REVIEW.json','inputs/prior/FIXED_GROUP_INDEPENDENT_REVIEW.json'),
                     (OLD[2]/'independent_review/INDEPENDENT_REVIEW.json','inputs/prior/SCORER_INDEPENDENT_REVIEW.json')]:copies.append(copy(src,dest))
    write(R/'inputs/SEARCH_TASKS.json',minimal);write(R/'inputs/POSTSCORING_REFERENCES.json',references)
    assert len(tasks)==16 and len(bases)==14
    write(R/'freeze/INPUT_MANIFEST.json',{'copied_files':copies,'tasks':16,'coordinate_demand_bases':14,'all_three_original_arms_routes_identical':True,
          'reference_inputs_not_passed_to_worker':True,'K_semantics_verified_all16':'fixed slots; at most K nonempty'})
if __name__=='__main__':main()
