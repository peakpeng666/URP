"""Final report statement and table verification against already-audited saved results."""
from pathlib import Path
import json,hashlib,datetime
R=Path('/workspace/shared/public_cross_group_moves_20261008');O=Path(__file__).parent
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=read(O/'SAVED_TRACE_INDEPENDENT_AUDIT.json');d=read(R/'reports/DESCRIPTIVE_COMPARISONS.json');summary=read(R/'reports/SUMMARY.json');report=(R/'reports/FINAL_REPORT_ZH.txt').read_text();status=read(R/'reports/INDEPENDENT_REVIEW_STATUS.json');finish=read(R/'raw/FINISHED.json')
assert summary['independent_review_status']==status['status']=='PASS'
assert all(r['cost']>r['reference_cost'] for r in a['rows'])
assert all(r['K']==r['nonempty_routes'] for r in a['rows'])
lookup={r['instance_id']:r for r in d['per_instance']};seen=set()
for line in report.splitlines():
    parts=line.split()
    if parts and parts[0] in lookup:
        name=parts[0];v=lookup[name];assert len(parts)==8,parts
        assert list(map(int,parts[1:7]))==[v['reference_cost'],*[v['costs'][x] for x in ['T','TR','TS','TRS']],v['TRS_minus_TS']]
        assert parts[7]==('局部最优' if v['TRS_termination']=='LOCAL_OPTIMUM' else '预算耗尽');seen.add(name)
assert len(seen)==16
for arm,s in a['summary'].items():
    match=[line.split() for line in report.splitlines() if line.split() and line.split()[0]==arm]
    assert len(match)==1;parts=match[0];assert len(parts)==8
    assert parts[1]==format(s['mean_reference_gap_percent'],'.6f')
    assert list(map(int,parts[2:6]))==[s['cost_sum'],s['attempted'],s['feasible'],s['accepted']]
    assert parts[6]==f"{s['local_optimum']}/{s['budget_exhausted']}"
    assert parts[7]==f"{s['better_than_T']}/{s['equal_to_T']}/{s['worse_than_T']}"
# Exact statements additionally reviewed directly for scope and interpretation.
assert '10.892060个百分点' in report
assert '2项改善、8项持平、6项退化' in report
assert '16任务、14个坐标/需求底本' in report
assert '未运行增预算或逆序反事实' in report and '不能据此孤立归因' in report
assert '下一轮最小辨别方案（仅提案，未执行）' in report
assert '独立审查者未访问旧目录' in report
assert '不作速度优势声明' in report and '未在本项目中证明为全局最优' in report
assert '4.91秒' in report and abs(finish['wall_seconds_for_audit_only']-4.91)<0.005
assert '3.47秒' in report and abs(finish['children_cpu_seconds_for_audit_only']-3.47)<0.005
assert '0.38秒' in report and abs(finish['supervisor_cpu_seconds_for_audit_only']-0.38)<0.005
assert '20.5MiB' in report and abs(finish['children_maxrss_KiB']/1024-20.5)<0.05
result=dict(status='PASS',report='reports/FINAL_REPORT_ZH.txt',report_sha256=sha(R/'reports/FINAL_REPORT_ZH.txt'),summary_sha256=sha(R/'reports/SUMMARY.json'),status_file_sha256=sha(R/'reports/INDEPENDENT_REVIEW_STATUS.json'),checks={'four_arm_summary_numbers':True,'sixteen_task_cost_table':True,'all64_terminal_costs_strictly_above_reference':True,'all64_K_slots_equal_nonempty_in_this_run':True,'all16_T_routes_and_costs_match_prior_verified_in_trace_review':True,'TRS_vs_TS_2_better_8_equal_6_worse':True,'all6_losses_at_cap_3_zero_swap_attempts':True,'association_not_single_cause_claim':True,'resource_numbers_rounding_and_non_speed_scope':True,'old916_file_check_attributed_to_author_only':True,'14_bases_not_independent16_source_claim':True,'next_order_reversal_only_proposed_not_executed':True},provenance_wording_note='The 15:42:34 report-generation time is the initial postscoring report. This final report was written later; neither precedes raw archive readback.',evidence={'saved_trace_audit_sha256':sha(O/'SAVED_TRACE_INDEPENDENT_AUDIT.json'),'formal_review_sha256':sha(O/'INDEPENDENT_FORMAL_REVIEW.json')},formal_optimizer_reruns=0,reviewer_old_directory_reads=0)
(O/'FINAL_STATEMENT_REVIEW.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
