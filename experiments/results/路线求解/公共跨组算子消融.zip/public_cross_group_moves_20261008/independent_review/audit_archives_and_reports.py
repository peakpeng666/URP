"""Independent saved-archive, receipt, timing and report audit. No optimizer and no old-tree reads."""
import pathlib,json,hashlib,zipfile,datetime,csv,collections,math
R=pathlib.Path('/workspace/shared/public_cross_group_moves_20261008');O=pathlib.Path(__file__).parent
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def utc(s):return datetime.datetime.fromisoformat(s.replace('Z','+00:00'))
trace=read(O/'SAVED_TRACE_INDEPENDENT_AUDIT.json');assert trace['status']=='PASS'
frozen=read(R/'freeze/FROZEN_FILES.json');rawmanifest=read(R/'raw/RAW_UNREVIEWED_MANIFEST.json');started=read(R/'raw/STARTED.json');finished=read(R/'raw/FINISHED.json')
pre=read(R/'provenance/PREEXEC_DRIVE_RECEIPT.json');raw=read(R/'provenance/RAW_UNREVIEWED_DRIVE_RECEIPT.json')
archives={}
for stage,receipt in [('PREEXEC',pre),('RAW_UNREVIEWED',raw)]:
    zpath=R.parent/(R.name+'_'+stage+'.zip');download=pathlib.Path(receipt['download_path'])
    assert receipt['owner_only'] and receipt['shared'] is False and receipt['remote_readback_sha256_verified'] and receipt['download_byte_identical']
    assert receipt['sha256']==receipt['download_sha256']==sha(zpath)==sha(download)
    assert receipt['bytes']==zpath.stat().st_size==download.stat().st_size
    assert receipt['frozen_files_sha256']==sha(R/'freeze/FROZEN_FILES.json')
    with zipfile.ZipFile(zpath) as z:
        assert z.testzip() is None;members=z.namelist();assert len(members)==len(set(members))
        prefix=R.name+'/'
        assert all(n.startswith(prefix) for n in members)
        for rel,v in frozen['files'].items():assert hashlib.sha256(z.read(prefix+rel)).hexdigest()==v['sha256']==sha(R/rel)
        assert z.read(prefix+'freeze/FROZEN_FILES.json')==(R/'freeze/FROZEN_FILES.json').read_bytes()
        assert not any(n.startswith(prefix+'reports/') for n in members)
        if stage=='PREEXEC':assert not any(n.startswith(prefix+'raw/') for n in members)
        else:
            for rel,v in rawmanifest['files'].items():assert hashlib.sha256(z.read(prefix+rel)).hexdigest()==v['sha256']==sha(R/rel)
            assert z.read(prefix+'raw/RAW_UNREVIEWED_MANIFEST.json')==(R/'raw/RAW_UNREVIEWED_MANIFEST.json').read_bytes()
            assert z.read(prefix+'provenance/PREEXEC_DRIVE_RECEIPT.json')==(R/'provenance/PREEXEC_DRIVE_RECEIPT.json').read_bytes()
        archives[stage]=dict(sha256=sha(zpath),download_bytes_rehashed=True,member_count=len(members),frozen_members_match=True,contains_reports=False,receipt_utc=receipt['confirmed_at_utc'],owner_only_per_archivist_receipt=True,url=receipt['url'])
assert started['receipt_sha256']==sha(R/'provenance/PREEXEC_DRIVE_RECEIPT.json')
assert utc(pre['confirmed_at_utc'])<utc(started['utc'])<utc(finished['utc'])<utc(raw['confirmed_at_utc'])
report_mtimes={p.name:datetime.datetime.fromtimestamp(p.stat().st_mtime,datetime.timezone.utc).isoformat() for p in (R/'reports').glob('*') if p.is_file()}
assert all(utc(raw['confirmed_at_utc'])<utc(t) for t in report_mtimes.values())
summary=read(R/'reports/SUMMARY.json');assert summary['tasks']==16 and summary['calls']==64 and summary['coordinate_demand_bases']==14
assert summary['frozen_files_unchanged'] and summary['changed_frozen_files']==[]
mapkeys={'valid_tasks':'valid_tasks','cost_sum':'cost_sum_all16','attempted':'attempted_sum','feasible':'feasible_sum','accepted':'accepted_sum','mean_reference_gap_percent':'mean_reference_gap_percent_all16','local_optimum':'local_optimum_tasks','budget_exhausted':'budget_exhausted_tasks','better_than_T':'cost_better_than_T_tasks','equal_to_T':'cost_equal_to_T_tasks','worse_than_T':'cost_worse_than_T_tasks'}
for arm,s in trace['summary'].items():
    for source,target in mapkeys.items():assert summary['arms'][arm][target]==s[source]
    assert summary['arms'][arm]['failure_or_undetermined_tasks']==0
    assert summary['arms'][arm]['nonempty_less_than_K_tasks']==sum(r['nonempty_routes']<r['K'] for r in trace['rows'] if r['arm']==arm)
refs=read(R/'inputs/POSTSCORING_REFERENCES.json');expected=sum(100*(r['baseline_integer_cost']/r['reference_integer_cost']-1) for r in refs)/16
assert summary['mean_original_reference_gap_percent']==expected and summary['baseline_matches_previous_two_opt_all16']
metas=[json.loads(x) for x in (R/'raw/results.jsonl').read_text().splitlines()];bykey={(m['instance_id'],m['arm']):m for m in metas};rows={(r['instance_id'],r['arm']):r for r in trace['rows']}
percall=list(csv.DictReader((R/'reports/PER_CALL.csv').open()));assert len(percall)==64
for r in percall:
    key=(r['instance_id'],r['arm']);truth=rows[key];meta=bykey[key];saved=read(R/meta['stdout'])
    for k in ('call_id','instance_id','arm'):assert r[k]==truth[k]
    assert r['status']=='SUCCESS' and r['termination']==truth['termination']
    for k in ('cost','initial_cost','attempted','feasible','accepted','nonempty_routes'):assert int(r[k])==truth[k]
    assert int(r['K_slots'])==truth['K'] and int(r['unspent_budget'])==20000-truth['attempted']
    assert int(r['cost_reduction'])==truth['initial_cost']-truth['cost']
    assert float(r['reference_gap_percent'])==truth['reference_gap_percent'] and int(r['reference_cost'])==truth['reference_cost']
    for op in ('two_opt','relocate','swap'):
        for k in ('attempted','feasible','accepted'):assert int(r[op+'_'+k])==saved['counts'].get(op,{}).get(k,0)
curves=list(csv.DictReader((R/'reports/FIXED_BUDGET_TRAJECTORIES.csv').open()));assert len(curves)==384
levels=[0,100,1000,5000,10000,20000]
assert collections.Counter((r['instance_id'],r['arm'],int(r['budget_node'])) for r in curves)==collections.Counter((name,arm,l) for name,arm in rows for l in levels)
for r in curves:
    key=(r['instance_id'],r['arm']);truth=rows[key];l=int(r['budget_node']);saved=read(R/bykey[key]['stdout'])
    moves=[m for m in saved['accepted_moves'] if m['attempted']<=l];value=moves[-1]['cost'] if moves else truth['initial_cost']
    assert int(r['cost'])==value and int(r['actual_attempted_to_terminal'])==truth['attempted']
    assert (r['carried_after_certified_local_optimum']=='True')==(l>truth['attempted'] and truth['termination']=='LOCAL_OPTIMUM')
# Descriptive comparisons only, no inferential claims or new outcome selection.
contrasts=[]
for task in read(R/'inputs/SEARCH_TASKS.json'):
    name=task['instance_id'];costs={a:rows[(name,a)]['cost'] for a in ('T','TR','TS','TRS')}
    contrasts.append(dict(instance_id=name,costs=costs,TS_minus_TRS=costs['TS']-costs['TRS']))
comparisons=dict(TS_better_than_TRS=sum(x['TS_minus_TRS']<0 for x in contrasts),TS_equal_TRS=sum(x['TS_minus_TRS']==0 for x in contrasts),TS_worse_than_TRS=sum(x['TS_minus_TRS']>0 for x in contrasts),TS_mean_gap_reduction_vs_T_percentage_points=trace['summary']['T']['mean_reference_gap_percent']-trace['summary']['TS']['mean_reference_gap_percent'],TRS_more_realized_attempts_than_TS=trace['summary']['TRS']['attempted']-trace['summary']['TS']['attempted'])
desc=read(R/'reports/DESCRIPTIVE_COMPARISONS.json')
for arm in ('TR','TS','TRS'):
    ss=trace['summary'][arm]
    assert desc['relative_T'][arm]=={'better':ss['better_than_T'],'equal':ss['equal_to_T'],'worse':ss['worse_than_T']}
comp=desc['TRS_vs_TS'];assert [comp[k] for k in ('better','equal','worse')]==[comparisons['TS_worse_than_TRS'],comparisons['TS_equal_TRS'],comparisons['TS_better_than_TRS']]
assert len(desc['per_instance'])==16
for r in desc['per_instance']:
    name=r['instance_id'];actual={a:rows[(name,a)] for a in ('T','TR','TS','TRS')};saved=read(R/bykey[(name,'TRS')]['stdout'])
    assert r['costs']=={a:v['cost'] for a,v in actual.items()}
    assert r['cost_reduction_vs_T']=={a:actual['T']['cost']-v['cost'] for a,v in actual.items()}
    assert r['TRS_minus_TS']==actual['TRS']['cost']-actual['TS']['cost']
    assert r['reference_cost']==actual['TRS']['reference_cost'] and r['K_slots']==actual['TRS']['K']
    assert r['nonempty_routes_by_arm']=={a:v['nonempty_routes'] for a,v in actual.items()}
    for a in ('TRS','TS'):assert r[a+'_termination']==actual[a]['termination']
    assert r['TRS_swap_attempted']==saved['counts']['swap']['attempted'] and r['TRS_swap_accepted']==saved['counts']['swap']['accepted']
worse=[r['instance_id'] for r in desc['per_instance'] if r['TRS_minus_TS']>0];zero=[r['instance_id'] for r in desc['per_instance'] if r['TRS_termination']=='BUDGET_EXHAUSTED' and r['TRS_swap_attempted']==0]
assert comp['worse_instances']==worse and len(worse)==6
assert comp['all_worse_cases_TRS_budget_exhausted'] and all(rows[(name,'TRS')]['termination']=='BUDGET_EXHAUSTED' for name in worse)
assert comp['TRS_capped_with_zero_swap_candidates']==zero and len(zero)==3
comparisons.update(TRS_worse_instances=worse,all_TRS_worse_cases_hit_budget=True,TRS_capped_zero_swap_attempt_instances=zero,causal_attribution_not_isolated=True)
result=dict(status='PASS',scope='Saved formal trace, archived bytes, chronology and reported quantities; no formal search rerun.',tasks=16,coordinate_demand_bases=14,calls=64,total_attempts_verified=trace['total_attempts_verified'],total_accepted_moves_verified=trace['total_accepted_moves_verified'],all_outputs_cost_capacity_coverage_K_valid=True,all_attempts_and_scan_order_and_termination_valid=True,all_preexecution_frozen_files_byte_identical=True,archives=archives,timing=dict(PREEXEC_remote_verified_utc=pre['confirmed_at_utc'],formal_started_utc=started['utc'],formal_finished_utc=finished['utc'],RAW_remote_verified_utc=raw['confirmed_at_utc'],report_file_mtimes_utc=report_mtimes),reported_summary_matches_independent_review=True,reported_percall_rows_verified=64,reported_frozen_budget_nodes_verified=384,summary=trace['summary'],descriptive_TS_TRS_comparison=comparisons,per_task_TS_TRS=contrasts,limitations=['Exploratory posthoc panel: 16 tasks from 14 coordinate-demand bases, not 16 independent sources or 64 independent samples.','Identical 20,000 candidate ceilings do not equalize realized attempts, feasible moves, or CPU effort.','No global-optimum, statistical significance, broad operator-superiority or speed claim is supported.','Reference-free behavior supported by reviewed code, exact worker payload and zero denied IO in every saved call.','Google Drive owner-only permissions are corroborated by archivist receipt; reviewer independently rehashed the actual remote-readback files.','Old-directory immutability is author-reported with 916 entries; reviewer honored no-old-directory-read scope and did not independently reread those old files.'],reviewed_files={str(p.relative_to(R)):sha(p) for p in sorted((R/'reports').glob('*')) if p.is_file()},supporting_evidence_sha256={p.name:sha(p) for p in [O/'SAVED_TRACE_INDEPENDENT_AUDIT.json',O/'audit_saved_traces.py',pathlib.Path(__file__)]})
(O/'INDEPENDENT_FORMAL_REVIEW.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ('per_task_TS_TRS','summary','limitations','reviewed_files','supporting_evidence_sha256')},indent=2))
