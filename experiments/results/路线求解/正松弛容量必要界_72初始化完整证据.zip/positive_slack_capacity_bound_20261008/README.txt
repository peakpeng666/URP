Positive-slack capacity bound exploratory initialization study.
Start: reports/REPORT_ZH.txt; proof: reports/PROOF.txt.
Protocol and pre-run hashes: freeze/. Raw 72-call results and toy evidence: raw/.
Cases and separate feasible witnesses: input/, witness/.
Frozen solver source and post-run analysis: source/.
No claim of benefit on official CVRP: all nine audited inputs cannot trigger this bound.
All failures retained; no main rerun or parameter tuning. Independent audit delivered separately.
