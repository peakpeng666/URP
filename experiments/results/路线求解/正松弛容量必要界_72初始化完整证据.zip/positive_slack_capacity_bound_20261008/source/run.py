import importlib,os,time,resource,signal
resource.setrlimit(resource.RLIMIT_CPU,(60,60));signal.alarm(120)
process_cpu_start=time.process_time();process_wall_start=time.perf_counter()
from common import *
freeze=read(ROOT/'freeze/PRE_RUN_FREEZE.json')
# Hash only science code, actual inputs, schedule/protocol; NEVER touch witness in this process.
verified=[]
for path,h in freeze['sha256'].items():
 if path.startswith(('source/','input/','freeze/')):
  assert sha(ROOT/path)==h,path;verified.append(path)
dump(ROOT/'raw/STARTED.json',{'utc':utc(),'freeze_sha256':sha(ROOT/'freeze/PRE_RUN_FREEZE.json'),'verified_paths':verified,'witness_files_opened':0})
with (ROOT/'raw/results.jsonl').open('x') as out:
 for item in read(ROOT/'freeze/SCHEDULE.json'):
  raw=read(ROOT/'input'/f"{item['instance_id']}.json");mod=importlib.import_module(item['arm']);inst=mod.instance_for(raw)
  budget=mod.Budget(100000,60,120);output=None;diag=None;status='INITFAIL';stop=None;err=None
  cpu=time.process_time();wall=time.perf_counter()
  try:
   matrix=mod.matrix_for(inst,budget)
   routes,cost,diag=mod.initialize(raw,inst,matrix,budget)
   output=mod.output_for(routes,cost);status='SUCCESS';stop='initialization_complete'
  except mod.InitFailure as ex:stop=str(ex);diag=getattr(ex,'detail',None);err=type(ex).__name__
  except mod.StopBudget as ex:status='BUDGET';stop=str(ex);err=type(ex).__name__
  except Exception as ex:status='ERROR';stop=str(ex);err=type(ex).__name__
  usage=budget.snapshot()
  result={**item,'n':raw['n'],'family':raw['family'],'input_sha256':sha(ROOT/'input'/f"{item['instance_id']}.json"),'status':status,'stop_reason':stop,'error_type':err,'initialization':diag,'output':output,'measured_cpu_seconds':time.process_time()-cpu,'measured_wall_seconds':time.perf_counter()-wall,**usage}
  out.write(json.dumps(result,allow_nan=False)+'\n');out.flush();os.fsync(out.fileno())
  if status in ['BUDGET','ERROR']:
   dump(ROOT/'raw/ABORTED.json',{'utc':utc(),'reason':status,'call':item,'no_retry':True});raise SystemExit(2)
dump(ROOT/'raw/FINISHED.json',{'utc':utc(),'calls':72,'process_cpu_seconds':time.process_time()-process_cpu_start,'process_wall_seconds':time.perf_counter()-process_wall_start,'rusage':list(resource.getrusage(resource.RUSAGE_SELF)),'results_sha256':sha(ROOT/'raw/results.jsonl'),'witness_files_opened':0,'local_search_calls':0,'oracle_calls':0})
print('72 initialization calls sealed.')
