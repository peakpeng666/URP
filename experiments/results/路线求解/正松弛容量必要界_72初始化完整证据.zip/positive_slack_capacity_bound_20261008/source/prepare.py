from common import *
import random,platform
assert read(ROOT/'reports/TOYS.json')['passed']
protocol={'utc':utc(),'base_seed':202610080438,'n':[27,54],'Q':[91,93],'K':'n/3','families':['controlled','random_witness'],'replicates':3,'arms':['capacity_solver','pruned_solver','waste_solver'],'calls':72,'instances':24,'generation':'n x Q x family x rep; never filter by outcome','seed':'base+100000*n+1000*Q+100*family_index+rep(0..2)','controlled':'repeat [40,40,40,30,30,30,20,20,20] n/9 times; witness40+30+20','random_witness':'each of K groups uniformly samples one of all ordered positive integer triples summing90, without conditioning/filtering','demand_seed':'seed+100000000','shuffle_seed':'seed+200000000','geometry':'independent uniform(0,100)^2 depot+customers from seed','node_limit':256,'delta_limit':100000,'main_cpu_hard':60,'main_wall_hard':120,'toy_cpu_hard':15,'toy_wall_hard':30,'local_search':False,'witness_separation':'runner never reads witness','interpretation':'exploratory constructed boundary; no real-world/official benefit claim; equal nodes != equal CPU','arm_order':'rotate three arms by rep','no_tuning_no_rerun':True}
dump(ROOT/'freeze/PRE_GENERATION.json',protocol)
triples=[(a,b,90-a-b) for a in range(1,89) for b in range(1,90-a)]
assert len(triples)==3916
schedule=[]
for n in protocol['n']:
 for Q in protocol['Q']:
  for fi,family in enumerate(protocol['families']):
   for rep in range(3):
    seed=protocol['base_seed']+100000*n+1000*Q+100*fi+rep;r=random.Random(seed)
    xy=[[r.uniform(0,100),r.uniform(0,100)] for _ in range(n+1)]
    if family=='controlled':
     ds=[40,40,40,30,30,30,20,20,20]*(n//9); groups=[[j+i,j+i+3,j+i+6] for j in range(1,n+1,9) for i in range(3)]
    else:
     rng=random.Random(seed+100000000);ds=[d for _ in range(n//3) for d in rng.choice(triples)];groups=[list(range(j,j+3)) for j in range(1,n+1,3)]
    perm=list(range(1,n+1));random.Random(seed+200000000).shuffle(perm);dem=[0]*(n+1)
    for old,new in enumerate(perm,1):dem[new]=ds[old-1]
    ident=f'N{n}-Q{Q}-{family}-R{rep+1}'
    raw={'instance_id':ident,'n':n,'capacity':Q,'K':n//3,'family':family,'replicate':rep+1,'coordinates':xy,'demands':dem}
    assert (n//3)*Q-sum(dem)>0
    dump(ROOT/'input'/f'{ident}.json',raw)
    dump(ROOT/'witness'/f'{ident}.json',{'groups':[[perm[j-1] for j in g] for g in groups]})
    arms=protocol['arms'][rep:]+protocol['arms'][:rep]
    schedule.extend({'instance_id':ident,'arm':a} for a in arms)
dump(ROOT/'freeze/SCHEDULE.json',schedule)
files=[p for folder in ['source','input','witness','provenance','freeze'] for p in (ROOT/folder).rglob('*') if p.is_file()]
dump(ROOT/'freeze/PRE_RUN_FREEZE.json',{'utc':utc(),'sha256':{str(p.relative_to(ROOT)):sha(p) for p in sorted(files)},'proof_sha256':sha(ROOT/'reports/PROOF.txt'),'toy_sha256':sha(ROOT/'reports/TOYS.json')})
print('24 cases,72 calls frozen')
