from common import *
import time,resource,signal
from itertools import combinations_with_replacement
from functools import lru_cache
from waste_solver import waste_capacity_test,bounded_partition
from capacity_solver import bounded_partition as base
resource.setrlimit(resource.RLIMIT_CPU,(15,15));signal.alarm(30)
cpu=time.process_time(); wall=time.perf_counter()
@lru_cache(None)
def oracle(ds,rs):
 if not ds:return True
 for i,r in enumerate(rs):
  if ds[0]<=r:
   rr=list(rs);rr[i]-=ds[0]
   if oracle(ds[1:],tuple(rr)):return True
 return False
states=pruned=feasible=0
with (ROOT/'raw/toy_states.jsonl').open('x') as out:
 for K in range(1,4):
  for rs in combinations_with_replacement(range(6),K):
   for n in range(6):
    for ds in combinations_with_replacement(range(6),n):
     truth=oracle(ds,rs);flag,_,_=waste_capacity_test(ds,rs)
     assert not(flag and truth),(ds,rs)
     states+=1;pruned+=flag;feasible+=truth
     out.write(json.dumps([ds,rs,truth,flag])+'\n')
checks=0
for Q in range(1,6):
 for K in range(1,4):
  for n in range(6):
   for ds in combinations_with_replacement(range(Q+1),n):
    truth=oracle(ds,(Q,)*K)
    a,ar=base([0,*ds],Q,K,100000); b,br=bounded_partition([0,*ds],Q,K,100000)
    assert not ar['limit_reached'] and not br['limit_reached']
    assert (a is not None)==(b is not None)==truth
    checks+=1
negative=0
for ds,rs in [([-1],[2]),([2],[-1])]:
 try:waste_capacity_test(ds,rs)
 except ValueError:negative+=1
assert negative==2
# Explicit positive-slack obstruction and non-sufficiency examples.
assert waste_capacity_test([2,2],[1,1,3])[0] # U=1 W=2
assert not waste_capacity_test([3,3,3],[4,5])[0] and not oracle((3,3,3),(4,5))
dump(ROOT/'reports/TOYS.json',{'passed':True,'states':states,'pruned':pruned,'feasible':feasible,'full_search_checks':checks,'negative_input_errors_checked':negative,'cpu_seconds':time.process_time()-cpu,'wall_seconds':time.perf_counter()-wall,'limits':{'cpu':15,'wall':30},'method':'independent labeled-bin oracle without symmetry or candidate pruning'})
print(read(ROOT/'reports/TOYS.json'))
