from common import *
from collections import Counter,defaultdict
from audit import check
import csv
f=verify();rs=[json.loads(s) for s in (ROOT/'raw/results.jsonl').read_text().splitlines()]
assert len(rs)==72
assert [(r['instance_id'],r['arm']) for r in rs]==[(r['instance_id'],r['arm']) for r in read(ROOT/'freeze/SCHEDULE.json')]
checks=[];witness=[];metrics=[]
for p in sorted((ROOT/'input').glob('*.json')):
 x=read(p);groups=read(ROOT/'witness'/p.name)['groups']; flat=[j for g in groups for j in g]
 ok=sorted(flat)==list(range(1,len(x['demands']))) and len(groups)<=x['K'] and all(sum(x['demands'][j] for j in g)<=x['capacity'] for g in groups)
 assert ok
 witness.append({'instance_id':x['instance_id'],'accepted':ok,'loads':[sum(x['demands'][j] for j in g) for g in groups]})
for r in rs:
 x=read(ROOT/'input'/f"{r['instance_id']}.json");diag=r['initialization'] or {};p=diag.get('capacity_partition',{})
 if r['output']:
  c=check(x,r['output'],x['K']);assert c['accepted']; checks.append({'instance_id':r['instance_id'],'arm':r['arm'],**c})
 assert p.get('nodes',0)<=256
 for trace in p.get('prune_trace',[]):
  assert 1<=trace['entered_node']<=p['nodes'];d=trace['remaining'];res=trace['residual']; U=sum(res)-sum(d); m=min(v for v in d if v>0); W=sum(v for v in res if 0<v<m)
  assert W>U and U==x['K']*x['capacity']-sum(x['demands'])
 metrics.append({'instance_id':r['instance_id'],'arm':r['arm'],'n':x['n'],'Q':x['capacity'],'family':x['family'],'U':x['K']*x['capacity']-sum(x['demands']),'min_demand':min(x['demands'][1:]),'status':r['status'],'fallback':bool(p),'nodes':p.get('nodes',0),'prunes':p.get('prunes',0),'partition_cpu':p.get('cpu_seconds',0),'init_cpu':r['measured_cpu_seconds'],'init_wall':r['measured_wall_seconds'],'init_deltas':r['deltas'],'insertion_deltas':r['delta_by_kind'].get('insertion',0),'outcome':p.get('outcome','NOT_ENTERED')})
with (ROOT/'reports/METRICS.csv').open('x') as out:
 w=csv.DictWriter(out,fieldnames=list(metrics[0]));w.writeheader();w.writerows(metrics)
summaries=[]
for fields in [('arm',),('arm','family'),('arm','family','n','Q')]:
 groups=defaultdict(list)
 for r in metrics:groups[tuple(r[k] for k in fields)].append(r)
 for key,items in sorted(groups.items()):
  summaries.append(dict(zip(fields,key))|{'denominator':len(items),'success':sum(r['status']=='SUCCESS' for r in items),'fail':sum(r['status']!='SUCCESS' for r in items),'fallback_calls':sum(r['fallback'] for r in items),'entered_nodes':sum(r['nodes'] for r in items),'prunes':sum(r['prunes'] for r in items),'init_cpu_sum':sum(r['init_cpu'] for r in items),'partition_cpu_sum':sum(r['partition_cpu'] for r in items),'init_delta_sum':sum(r['init_deltas'] for r in items)})
by=defaultdict(dict)
for r in rs:by[r['instance_id']][r['arm']]=r
paired=[]
for ident,arms in by.items():
 a=arms['capacity_solver'];b=arms['pruned_solver'];c=arms['waste_solver']
 assert a['status']==b['status'] and a['output']==b['output'] and a['deltas']==b['deltas']
 paired.append({'instance_id':ident,'baseline':a['status'],'tight':b['status'],'waste':c['status'],'rescued':a['status']!='SUCCESS' and c['status']=='SUCCESS','lost':a['status']=='SUCCESS' and c['status']!='SUCCESS','same_savings_route_count':len({(r['initialization'] or {}).get('savings_route_count') for r in arms.values()})==1})
assert all(r['same_savings_route_count'] for r in paired)
dump(ROOT/'reports/OUTPUT_CHECKS.json',checks);dump(ROOT/'reports/WITNESS_CHECKS.json',witness);dump(ROOT/'reports/SUMMARY.json',summaries);dump(ROOT/'reports/PAIRED.json',paired)
print(json.dumps([r for r in summaries if set(r).isdisjoint({'family'})],indent=2));print('rescues',[r['instance_id'] for r in paired if r['rescued']])
