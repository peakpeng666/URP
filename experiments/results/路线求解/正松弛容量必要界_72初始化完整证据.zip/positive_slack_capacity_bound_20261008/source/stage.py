from common import *
import ast
s=(ROOT/'source/pruned_solver.py').read_text()
a=s.index('def tight_capacity_test(');b=s.index('\ndef bounded_partition',a)
s=s[:a]+'''def waste_capacity_test(remaining, residual):
    """Necessary obstruction, not sufficiency. Nonnegative integer demands/rooms."""
    if any(x < 0 for x in remaining) or any(r < 0 for r in residual):
        raise ValueError('negative demand or residual outside domain')
    if not remaining:
        return False, False, 0
    slack = sum(residual) - sum(remaining)
    if slack < 0:
        return True, True, 0
    positive = [x for x in remaining if x > 0]
    if not positive:
        return False, False, 0
    smallest = min(positive)
    wasted = sum(r for r in residual if 0 < r < smallest)
    return wasted > slack, True, len(residual)
''' + s[b:]
s=s.replace('tight_capacity_test(remaining, residual)','waste_capacity_test(remaining, residual)').replace('tight_checks','waste_checks')
(ROOT/'source/waste_solver.py').write_text(s)
proof='''Necessary bound for nonnegative demands and residual capacities, using all K bins.
Let D be sum of remaining demand, R sum of all residual capacity, U=R-D. U<0 is impossible by aggregate capacity. If no positive demands remain, this bound does not reject (zero-size items need no capacity). Otherwise let m be the minimum positive remaining demand. Every bin with 0<r<m cannot receive a positive item, and zero-size items cannot consume capacity. Such bins retain W=sum(r:0<r<m) unused capacity in every completion. Any completion leaves exactly U unused capacity. Therefore W>U implies no completion. W<=U is NOT sufficient. Empty remaining list returns non-rejection. Negative input demands/residuals are outside domain and rejected as input errors. For all-positive inputs U=0 reduces to the old full-fill obstruction.
Descending fixed assignment implies the minimum positive remaining demand is constant until the positive list is exhausted. For integer residuals W<=K*(m-1). If K*(m-1)<=U initially, this bound can never trigger; no solver execution is needed for this conclusion.
'''
(ROOT/'reports/PROOF.txt').write_text(proof)
checks={}
base=(ROOT/'source/capacity_solver.py').read_text(); tree=ast.parse(s)
for node in ast.parse(base).body:
 if isinstance(node,(ast.FunctionDef,ast.ClassDef)) and node.name!='bounded_partition':
  other=next(x for x in tree.body if type(x)==type(node) and x.name==node.name)
  checks[node.name]=ast.get_source_segment(base,node)==ast.get_source_segment(s,other)
assert all(checks.values())
dump(ROOT/'provenance/SOURCE_CHECKS.json',{'unchanged_non_partition_definitions':checks,'base_sha256':sha(ROOT/'source/capacity_solver.py'),'old_source_sha256':sha('/workspace/shared/tight_capacity_pruning_20261008/source/capacity_solver.py')})
rows=[]
for name in ['official_cvrp_benchmarks_20261008','new_official_cvrp_validation_set_20261008']:
 for p in sorted(Path('/workspace/shared',name).rglob('*.instance.json')):
  import re
  x=read(p); K=int(re.search(r'-k(\d+)',p.name)[1]); ds=x['demands'][1:]; m=min(ds); U=K*x['capacity']-sum(ds)
  assert all(type(d)==int and d>0 for d in ds)
  rows.append({'name':x['name'],'K':K,'min_demand':m,'W_upper':K*(m-1),'U':U,'never_triggers':K*(m-1)<=U,'input_path':str(p),'input_sha256':sha(p),'solver_run':False})
assert len(rows)==9 and all(r['never_triggers'] for r in rows)
dump(ROOT/'reports/OFFICIAL_READ_ONLY.json',rows)
print('Staged source, proof and read-only nine-instance applicability audit.')
