import zipfile,json
from common import *
assert (ROOT/'raw/FINISHED.json').exists()
files=sorted(x for x in ROOT.rglob('*') if x.is_file())
(ROOT/'RAW_UNAUDITED_SHA256SUMS.txt').write_text(''.join(sha(x)+'  '+str(x.relative_to(ROOT))+'\n' for x in files))
out=ROOT.parent/(ROOT.name+'_RAW_COMPLETE_UNAUDITED.zip')
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED) as z:
 for x in sorted(ROOT.rglob('*')):
  if x.is_file():z.write(x,ROOT.name+'/'+str(x.relative_to(ROOT)))
print(json.dumps({'package':str(out),'bytes':out.stat().st_size,'sha256':sha(out),'claims':'UNAUDITED timing data;not oldraw;no report yet'},indent=2))
