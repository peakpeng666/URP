from pathlib import Path
import json,hashlib,datetime
ROOT=Path(__file__).resolve().parents[1]
SOURCE=Path('/workspace/shared/capacity_cross_structure_reproduction_20261008_r1')
ARMS=['capacity_solver','pruned_solver','waste_solver']
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(o):return hashlib.sha256(json.dumps(o,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def dump(p,o):
 with Path(p).open('x') as f:json.dump(o,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')
def untimed(o):
 if isinstance(o,dict):return {k:untimed(v) for k,v in o.items() if k not in ['cpu_seconds','wall_seconds','solver_cpu_seconds','solver_wall_seconds']}
 if isinstance(o,list):return [untimed(v) for v in o]
 return o
def signature(status,out,diag,budget,error=None):
 routes=None if out is None else [r[1:-1] for r in out['routes']]
 assignment=None if routes is None else sorted(sorted(r) for r in routes)
 canon=None if routes is None else sorted(min(r,r[::-1]) for r in routes)
 return {'status':status,'error_sha256':digest(error),'assignment_sha256':digest(assignment),'route_sha256':digest(canon),'output_sha256':digest(out),'diagnostic_sha256':digest(untimed(diag)),'budget_sha256':digest(untimed(budget))}
