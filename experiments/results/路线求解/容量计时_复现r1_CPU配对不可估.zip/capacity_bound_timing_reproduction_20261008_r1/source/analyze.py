import sys,time,resource,signal,random,statistics as st,math,csv,collections
sys.dont_write_bytecode=True
resource.setrlimit(resource.RLIMIT_CPU,(10,10));resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3))
from common import *
signal.alarm(10)
BEGIN_C=time.process_time_ns();BEGIN_W=time.perf_counter_ns()
def dist(xs):
 if not xs:return None
 xs=sorted(xs);q=st.quantiles(xs,n=4,method='inclusive') if len(xs)>1 else [xs[0]]*3;m=st.mean(xs)
 return {'n':len(xs),'sum':sum(xs),'mean':m,'median':st.median(xs),'p25':q[0],'p75':q[2],'min':xs[0],'max':xs[-1],'sd':st.stdev(xs) if len(xs)>1 else 0,'cv':st.stdev(xs)/m if len(xs)>1 and m else 0,'geometric_mean':math.exp(st.mean(math.log(x) for x in xs)) if all(x>0 for x in xs) else None}
def csvout(name,rows):
 if rows:
  with (ROOT/'reports'/name).open('x',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
p=read(ROOT/'freeze/PROTOCOL.json');f=read(ROOT/'freeze/PRE_RUN_FREEZE.json');schedule=read(ROOT/'freeze/SCHEDULE.json')
rows=[json.loads(x) for x in (ROOT/'raw/calls.jsonl').read_text().splitlines()];timed=[r for r in rows if r['phase']=='timed'];warm=[r for r in rows if r['phase']=='warmup']
refs={(r['instance_id'],r['arm']):r for r in read(ROOT/'provenance/REFERENCE_INITIALIZE.json')};ids=sorted({i for i,a in refs});inputs={i:read(ROOT/'input'/f'{i}.json') for i in ids}
def tags(i):
 b=refs[(i,'capacity_solver')];n=refs[(i,'waste_solver')]
 return ['all48','family:'+inputs[i]['family'],'outcome:'+('success' if b['status']=='SUCCESS' else'fail')+'_'+('success' if n['status']=='SUCCESS' else'fail'),'capacity_trigger:'+str('capacity_partition' in (b['diagnostic'] or{}))]
index=collections.defaultdict(list)
for r in timed:index[(r['instance_id'],r['arm'],r['round'])].append(r)
cellrows=[];cellidx={}
for key,rs in sorted(index.items()):
 i,a,k=key;row={'instance_id':i,'arm':a,'round':k,'calls':len(rs)}
 for clock in ['cpu','wall']:
  xs=[r['algorithm_'+clock+'_ns'] for r in rs];d=dist(xs);row[clock+'_valid']=len(rs)==p['repetitions_per_cell'] and all(x>0 for x in xs)
  for name in ['mean','median','p25','p75','min','max','sd','cv']:row[clock+'_'+name]=d[name]
 cellrows.append(row);cellidx[key]=row
csvout('CELL_TIMING.csv',cellrows)
pairrows=[]
for a,b in p['pairs']:
 for i in ids:
  for clock in ['cpu','wall']:
   eligible=all((i,x,k) in cellidx and cellidx[(i,x,k)][clock+'_valid'] for k in range(1,8) for x in [a,b])
   xs=[cellidx[(i,a,k)][clock+'_mean']/cellidx[(i,b,k)][clock+'_mean'] for k in range(1,8)] if eligible else[];d=dist(xs)
   pairrows.append({'instance_id':i,'family':inputs[i]['family'],'numerator':a,'denominator':b,'clock':clock,'eligible':eligible,'ratios_by_round':json.dumps(xs),**{k:None if d is None else d[k] for k in ['median','p25','p75','min','max','cv']}})
csvout('PAIRED_PER_INSTANCE.csv',pairrows)
armrows=[]
for i in ids:
 for a in ARMS:
  for clock in ['cpu','wall']:
   xs=[cellidx[(i,a,k)][clock+'_mean'] for k in range(1,8) if (i,a,k) in cellidx]
   armrows.append({'instance_id':i,'arm':a,'clock':clock,**(dist(xs) or{})})
csvout('INSTANCE_ARM_DISPERSION.csv',armrows)
summary={'namespace':p['namespace'],'scientific_units':48,'timed_calls':len(timed),'warmup_calls':len(warm),'strata':{},'paired':[]}
for tag in sorted({t for i in ids for t in tags(i)}):
 selected_ids={i for i in ids if tag in tags(i)};ss={'instances':len(selected_ids),'arms':{}}
 for a in ARMS:
  rs=[r for r in timed if r['instance_id'] in selected_ids and r['arm']==a];v={'calls':len(rs),'statuses':dict(collections.Counter(r['status'] for r in rs)),'reference_statuses':dict(collections.Counter(refs[(i,a)]['status'] for i in selected_ids)),'components':{}}
  for clock in ['cpu','wall']:
   xs=[r['algorithm_'+clock+'_ns'] for r in rs];valid=len(rs)==7*p['repetitions_per_cell']*len(selected_ids) and all(x>0 for x in xs)
   v[clock+'_valid']=valid;v['algorithm_'+clock+'_seconds']=sum(xs)/1e9 if valid else None;v[clock+'_nonpositive_calls']=sum(x<=0 for x in xs)
   for comp in ['setup','matrix','initialize','output']:
    cs=[r[comp+'_'+clock+'_ns'] for r in rs if r[comp+'_'+clock+'_ns'] is not None]
    v['components'][comp+'_'+clock]={'raw_seconds':sum(cs)/1e9,'calls':len(cs),'nonpositive_calls':sum(x<=0 for x in cs)}
  ss['arms'][a]=v
 summary['strata'][tag]=ss
 for a,b in p['pairs']:
  for clock in ['cpu','wall']:
   prs=[r for r in pairrows if r['instance_id'] in selected_ids and r['numerator']==a and r['denominator']==b and r['clock']==clock and r['eligible']]
   av=ss['arms'][a]['algorithm_'+clock+'_seconds'];bv=ss['arms'][b]['algorithm_'+clock+'_seconds']
   summary['paired'].append({'stratum':tag,'numerator':a,'denominator':b,'clock':clock,'eligible_instances':len(prs),'total_ratio':av/bv if av is not None and bv is not None and bv>0 else None,'instance_median_ratio_distribution':dist([r['median'] for r in prs])})
# Round-wise totals retained, never remove a slow round.
roundrows=[]
for rnd in range(1,8):
 for a in ARMS:
  rs=[r for r in timed if r['round']==rnd and r['arm']==a]
  roundrows.append({'round':rnd,'arm':a,'calls':len(rs),'algorithm_cpu_seconds':sum(r['algorithm_cpu_ns'] for r in rs)/1e9,'algorithm_wall_seconds':sum(r['algorithm_wall_ns'] for r in rs)/1e9})
csvout('ROUND_TOTALS.csv',roundrows)
regenerated=[]
for rnd in range(8):
 pairs=[(i,a) for i in ids for a in ARMS];random.Random(2026100800+rnd).shuffle(pairs)
 for order,(i,a) in enumerate(pairs):regenerated.append({'cell_id':f'R{rnd}-C{order:03d}','phase':'warmup' if rnd==0 else 'timed','round':rnd,'round_seed':2026100800+rnd,'order':order,'instance_id':i,'arm':a,'repetitions':1 if rnd==0 else p['repetitions_per_cell']})
schedule_structure_valid=len(ids)==48 and len(refs)==144 and len(schedule)==1152 and schedule==regenerated
expected={c['cell_id']+'-P%02d'%j:{**{k:v for k,v in c.items() if k!='repetitions'},'repetition':j} for c in schedule for j in range(c['repetitions'])};actual=collections.Counter(r['call_id'] for r in rows)
finish=read(ROOT/'raw/FINISHED.json');wf=read(ROOT/'raw/WORKER_FINISHED.json');source_snapshot=read(ROOT/'provenance/SOURCE_SNAPSHOT.json')
dummy=read(ROOT/'provenance/DUMMY_RESOURCE_TEST.json')
audit={'utc':utc(),'schedule_structure_valid':schedule_structure_valid,'analysis_maxrss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'dummy_cpu_seconds':dummy['child_cpu_seconds']+dummy['supervisor_cpu_seconds'],'dummy_wall_seconds':dummy['wall_seconds'],'timed_calls':len(timed),'warmup_calls':len(warm),'expected_timed_calls':7*144*p['repetitions_per_cell'],'missing_call_ids':sorted(set(expected)-set(actual)),'extra_call_ids':sorted(set(actual)-set(expected)),'duplicate_call_ids':{k:v for k,v in actual.items() if v!=1},'schedule_mismatches':[r['call_id'] for r in rows if r['call_id'] not in expected or any(r.get(k)!=v for k,v in expected[r['call_id']].items())],'drift_calls':[r['call_id'] for r in rows if r['drift_fields']],'invalid_success_calls':[r['call_id'] for r in rows if r['status']=='SUCCESS' and not r['feasible']],'input_mutation_calls':[r['call_id'] for r in rows if not r['input_unchanged']],'unexpected_statuses':dict(collections.Counter(r['status'] for r in rows if r['status'] not in ['SUCCESS','INITFAIL'])),'freeze_changes':[x for x,h in f['sha256'].items() if sha(ROOT/x)!=h],'source_snapshot_changes':[x for x,h in source_snapshot.items() if sha(SOURCE/x)!=h],'source_count':len(source_snapshot),'solver_bytes_equal':all(sha(x)==sha(SOURCE/'source'/x.relative_to(ROOT/'source/solvers')) for x in (ROOT/'source/solvers').rglob('*') if x.is_file()),'diagnostic_store_invalid':[x.name for x in (ROOT/'raw/diagnostics').glob('*.json') if digest(read(x))!=x.stem],'diagnostic_store_missing':sorted({r['signature']['diagnostic_sha256'] for r in rows if not (ROOT/'raw/diagnostics'/(r['signature']['diagnostic_sha256']+'.json')).exists()}),'normal_completion':finish['returncode']==0 and not finish['timeout'] and wf['complete'],'resources_ok':finish['child_cpu_seconds']+finish['supervisor_cpu_seconds']+dummy['child_cpu_seconds']+dummy['supervisor_cpu_seconds']+10<300 and finish['wall_seconds']+dummy['wall_seconds']+10<600 and max(finish['child_maxrss_KiB'],finish['supervisor_maxrss_KiB'],resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)<1024**2,'nonpositive_algorithm_cpu_calls':sum(r['algorithm_cpu_ns']<=0 for r in rows),'nonpositive_algorithm_wall_calls':sum(r['algorithm_wall_ns']<=0 for r in rows),'finish':finish,'worker_finish':wf,'no_solver_rerun':True}
audit['passed']=audit['schedule_structure_valid'] and len(timed)==7*144*p['repetitions_per_cell'] and len(warm)==144 and audit['solver_bytes_equal'] and audit['normal_completion'] and audit['resources_ok'] and not any(audit[k] for k in ['missing_call_ids','extra_call_ids','duplicate_call_ids','schedule_mismatches','drift_calls','invalid_success_calls','input_mutation_calls','unexpected_statuses','freeze_changes','source_snapshot_changes','diagnostic_store_invalid','diagnostic_store_missing'])
audit['analysis_cpu_seconds']=(time.process_time_ns()-BEGIN_C)/1e9;audit['analysis_wall_seconds']=(time.perf_counter_ns()-BEGIN_W)/1e9
audit['measured_execution_cpu_seconds_including_dummy_analysis']=finish['child_cpu_seconds']+finish['supervisor_cpu_seconds']+dummy['child_cpu_seconds']+dummy['supervisor_cpu_seconds']+audit['analysis_cpu_seconds']
audit['measured_execution_wall_seconds_including_dummy_analysis']=finish['wall_seconds']+dummy['wall_seconds']+audit['analysis_wall_seconds']
audit['memory_scope']='1GiB per process,not aggregate; supervisor and child execute concurrently, analysis sequential'
dump(ROOT/'reports/SUMMARY.json',summary);dump(ROOT/'reports/AUDIT.json',audit)
print(json.dumps({'passed':audit['passed'],'counts':[len(warm),len(timed)],'all48':summary['strata']['all48'],'pairs':[q for q in summary['paired'] if q['stratum']=='all48']},indent=2))
