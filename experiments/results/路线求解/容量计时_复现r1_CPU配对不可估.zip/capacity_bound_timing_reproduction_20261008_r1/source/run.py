import sys,os,time,subprocess,resource,signal
sys.dont_write_bytecode=True
from common import *
dummy='--dummy' in sys.argv
c=time.process_time_ns();w=time.perf_counter_ns();ru0=resource.getrusage(resource.RUSAGE_CHILDREN)
resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3))
if not dummy:
 freeze=read(ROOT/'freeze/PRE_RUN_FREEZE.json')
 for p,h in freeze['sha256'].items():assert sha(ROOT/p)==h,p
 gates=read(ROOT/'provenance/EXECUTION_GATES.json')
 assert gates['preexecution_archive_readback_verified'] and gates['source_reproduction_external_audit_passed']
 dump(ROOT/'raw/STARTED.json',{'utc':utc(),'namespace':'capacity-bound-timing-reproduction-20261008-r1','freeze_sha256':sha(ROOT/'freeze/PRE_RUN_FREEZE.json'),'gates_sha256':sha(ROOT/'provenance/EXECUTION_GATES.json'),'schedule_once':True,'allocated_hard_cpu_seconds':280,'wall_timeout_seconds':569})
# Do not lower supervisor CPU hard limit until AFTER child creation.
launch=time.perf_counter_ns()
p=subprocess.Popen([sys.executable,'-B',str(ROOT/'source/worker.py')]+(['--dummy'] if dummy else []),stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONHASHSEED':'0','LAUNCH_WALL_NS':str(launch)},start_new_session=True)
resource.setrlimit(resource.RLIMIT_CPU,(20,20))
timeout=False
try:stdout,stderr=p.communicate(timeout=5 if dummy else 569)
except subprocess.TimeoutExpired:timeout=True;os.killpg(p.pid,signal.SIGKILL);stdout,stderr=p.communicate()
ru=resource.getrusage(resource.RUSAGE_CHILDREN)
result={'utc':utc(),'returncode':p.returncode,'timeout':timeout,'supervisor_cpu_seconds':(time.process_time_ns()-c)/1e9,'child_cpu_seconds':ru.ru_utime+ru.ru_stime-ru0.ru_utime-ru0.ru_stime,'wall_seconds':(time.perf_counter_ns()-w)/1e9,'child_maxrss_KiB':ru.ru_maxrss,'supervisor_maxrss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'supervisor_cpu_limit':resource.getrlimit(resource.RLIMIT_CPU),'worker_stdout':stdout if dummy else None,'worker_stderr':stderr if dummy else None}
if dummy:
 parsed=json.loads(stdout) if p.returncode==0 else {};result['passed']=p.returncode==0 and parsed.get('solver_calls')==0 and parsed.get('worker_limits',{}).get('cpu')==[255,260] and parsed.get('worker_limits',{}).get('as')==[1024**3,1024**3]
 dump(ROOT/'provenance/DUMMY_RESOURCE_TEST.json',result)
else:
 (ROOT/'raw/WORKER_STDOUT.txt').write_text(stdout);(ROOT/'raw/WORKER_STDERR.txt').write_text(stderr);dump(ROOT/'raw/FINISHED.json',result)
print(stdout,end='');print(stderr,end='');print(json.dumps(result,indent=2))
