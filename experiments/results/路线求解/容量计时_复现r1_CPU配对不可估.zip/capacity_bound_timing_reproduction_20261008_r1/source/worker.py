import time,os
ENTRY_C=time.process_time_ns();ENTRY_W=time.perf_counter_ns()
import sys,resource,signal,importlib,json,gc,platform
sys.dont_write_bytecode=True
from common import *
inherited={'cpu':resource.getrlimit(resource.RLIMIT_CPU),'as':resource.getrlimit(resource.RLIMIT_AS)}
resource.setrlimit(resource.RLIMIT_CPU,(255,260));resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3))
limits={'cpu':resource.getrlimit(resource.RLIMIT_CPU),'as':resource.getrlimit(resource.RLIMIT_AS)}
if '--dummy' in sys.argv:
 print(json.dumps({'dummy':True,'solver_calls':0,'inherited':inherited,'worker_limits':limits,'pid':os.getpid()}));sys.exit(0)
class StageStop(BaseException):pass
stop_requested=None;algorithm_active=False
def stop(signum,frame):
 global stop_requested
 stop_requested='signal_'+str(signum)
 if algorithm_active:raise StageStop(stop_requested)
signal.signal(signal.SIGXCPU,stop);signal.signal(signal.SIGALRM,stop);signal.setitimer(signal.ITIMER_REAL,560)
pc=time.process_time_ns();pw=time.perf_counter_ns()
freeze=read(ROOT/'freeze/PRE_RUN_FREEZE.json')
for p,h in freeze['sha256'].items():assert sha(ROOT/p)==h,p
schedule=read(ROOT/'freeze/SCHEDULE.json');protocol=read(ROOT/'freeze/PROTOCOL.json')
sys.path.insert(0,str(ROOT/'source/solvers'))
mods={arm:importlib.import_module(arm) for arm in ARMS}
assert all(m.CAPACITY_NODE_LIMIT==256 for m in mods.values())
from audit import check
inputs={p.stem:read(p) for p in sorted((ROOT/'input').glob('*.json'))};input_digests={k:digest(v) for k,v in inputs.items()}
refs={(r['instance_id'],r['arm']):r for r in read(ROOT/'provenance/REFERENCE_INITIALIZE.json')}
refsig={k:signature(r['status'],r['output'],r['diagnostic'],r['budget'],r['error']) for k,r in refs.items()}
meta={'utc':utc(),'namespace':protocol['namespace'],'freeze_sha256':sha(ROOT/'freeze/PRE_RUN_FREEZE.json'),'pid':os.getpid(),'inherited_limits':inherited,'effective_limits':limits,'startup_cpu_ns':ENTRY_C,'startup_wall_ns':ENTRY_W-int(os.environ['LAUNCH_WALL_NS']),'imports_before_preload_cpu_ns':pc-ENTRY_C,'imports_before_preload_wall_ns':pw-ENTRY_W,'preload_and_verification_cpu_ns':time.process_time_ns()-pc,'preload_and_verification_wall_ns':time.perf_counter_ns()-pw,'python':sys.version,'platform':platform.platform(),'gc_enabled':gc.isenabled(),'gc_threshold':gc.get_threshold(),'clocks':{k:vars(time.get_clock_info(k)) for k in ['process_time','perf_counter']}}
dump(ROOT/'raw/WORKER_STARTED.json',meta)
cal=[]
for _ in range(1000):
 c=time.process_time_ns();w=time.perf_counter_ns();e=time.perf_counter_ns();d=time.process_time_ns();cal.append({'cpu_ns':d-c,'wall_ns':e-w})
dump(ROOT/'raw/CLOCK_BRACKETS.json',cal)

def invoke(raw,mod):
 global algorithm_active
 out=diag=budget=None;status='ERROR';error=None;abort=False;marks=[]
 algorithm_active=True
 c=time.process_time_ns();w=time.perf_counter_ns();marks.append((c,w))
 try:
  inst=mod.instance_for(raw);budget=mod.Budget(100000,1,2)
  marks.append((time.process_time_ns(),time.perf_counter_ns()))
  matrix=mod.matrix_for(inst,budget)
  marks.append((time.process_time_ns(),time.perf_counter_ns()))
  routes,cost,diag=mod.initialize(raw,inst,matrix,budget)
  marks.append((time.process_time_ns(),time.perf_counter_ns()))
  out=mod.output_for(routes,cost);status='SUCCESS'
 except mod.InitFailure as exc:diag=getattr(exc,'detail',None);status='INITFAIL';error={'type':type(exc).__name__,'message':str(exc)}
 except mod.StopBudget as exc:status='BUDGET';error={'type':type(exc).__name__,'message':str(exc)}
 except StageStop as exc:status='STAGE_BUDGET';error={'type':type(exc).__name__,'message':str(exc)};abort=True
 except Exception as exc:status='ERROR';error={'type':type(exc).__name__,'message':str(exc)}
 ew=time.perf_counter_ns();ec=time.process_time_ns();algorithm_active=False
 # Unlike source outer timer, new explicit algorithm boundary excludes snapshot.
 usage=budget.snapshot() if budget is not None else None
 last=min(len(marks)-1,3);marks.append((ec,ew))
 r={'status':status,'output':out,'diagnostic':diag,'budget':usage,'error':error,'stage_abort':abort,'algorithm_cpu_ns':ec-c,'algorithm_wall_ns':ew-w}
 for i,name in enumerate(['setup','matrix','initialize','output']):
  for j,clock in enumerate(['cpu','wall']):r[name+'_'+clock+'_ns']=marks[i+1][j]-marks[i][j] if i<=last else None
 return r

counts={'warmup':0,'timed':0};cells_done=0;active=None;reason=None;postc=postw=0;batch=[];cell_saved=True;saved_in_cell=0
(ROOT/'raw/diagnostics').mkdir();seen=set()
with (ROOT/'raw/calls.jsonl').open('x') as f,(ROOT/'raw/cells.jsonl').open('x') as g:
 try:
  for cell in schedule:
   if stop_requested:reason=stop_requested;break
   active=cell;cell_saved=False;saved_in_cell=0;batch=[]
   c=time.process_time_ns();w=time.perf_counter_ns()
   for rep in range(cell['repetitions']):
    if stop_requested:break
    r=invoke(inputs[cell['instance_id']],mods[cell['arm']]);batch.append(r)
    if r['stage_abort']:break
   bw=time.perf_counter_ns()-w;bc=time.process_time_ns()-c
   pc=time.process_time_ns();pw=time.perf_counter_ns()
   raw=inputs[cell['instance_id']];ref=refs[(cell['instance_id'],cell['arm'])];rsig=refsig[(cell['instance_id'],cell['arm'])]
   for rep,r in enumerate(batch):
    diag=r.pop('diagnostic');sig=signature(r['status'],r['output'],diag,r['budget'],r['error']);dh=sig['diagnostic_sha256']
    if dh not in seen:dump(ROOT/'raw/diagnostics'/f'{dh}.json',untimed(diag));seen.add(dh)
    part=(diag or {}).get('capacity_partition')
    checked=check(raw,r['output'],raw['K']) if r['output'] is not None else {'accepted':False,'errors':['no_output']}
    r.update({**{k:v for k,v in cell.items() if k!='repetitions'},'call_id':cell['cell_id']+'-P%02d'%rep,'repetition':rep,'feasible':bool(checked['accepted']),'checker':checked,'signature':sig,'reference_call_id':ref['call_id'],'reference_signature':rsig,'drift_fields':[k for k,v in sig.items() if v!=rsig[k]],'input_sha256':freeze['sha256']['input/'+cell['instance_id']+'.json'],'input_unchanged':digest(raw)==input_digests[cell['instance_id']],'capacity_called':part is not None,'nodes':None if part is None else part['nodes'],'prunes':0 if part is None else part.get('prunes',0),'partition_outcome':None if part is None else part['outcome'],'partition_raw_cpu_seconds':None if part is None else part['cpu_seconds'],'partition_raw_wall_seconds':None if part is None else part['wall_seconds'],'local_search_calls':0})
    f.write(json.dumps(r,allow_nan=False)+'\n');counts[cell['phase']]+=1;saved_in_cell+=1
   f.flush();os.fsync(f.fileno())
   g.write(json.dumps({**cell,'completed_repetitions':len(batch),'wrapper_inclusive_batch_cpu_ns':bc,'wrapper_inclusive_batch_wall_ns':bw,'algorithm_cpu_sum_ns':sum(r['algorithm_cpu_ns'] for r in batch),'algorithm_wall_sum_ns':sum(r['algorithm_wall_ns'] for r in batch),'zero_algorithm_cpu_calls':sum(r['algorithm_cpu_ns']<=0 for r in batch),'zero_algorithm_wall_calls':sum(r['algorithm_wall_ns']<=0 for r in batch),'all_signatures_match':all(not r['drift_fields'] for r in batch)},allow_nan=False)+'\n');g.flush();os.fsync(g.fileno());cells_done+=1;cell_saved=True
   postc+=time.process_time_ns()-pc;postw+=time.perf_counter_ns()-pw
   if stop_requested:reason=stop_requested;break
   if cells_done%144==0:print('Finished phase',cell['phase'],'round',cell['round'],'calls',counts,flush=True)
 except BaseException as exc:reason=type(exc).__name__+':'+str(exc);raise
 finally:
  signal.setitimer(signal.ITIMER_REAL,0)
  if not cell_saved:dump(ROOT/'raw/PARTIAL_CELL_RETAINED.json',{'cell':active,'already_written_records':saved_in_cell,'buffered_records':batch,'note':'Retained partial buffer; overlaps explicitly identified. No retry.'})
  dump(ROOT/'raw/WORKER_FINISHED.json',{'utc':utc(),'complete':reason is None and cells_done==len(schedule),'reason':reason,'last_cell':active,'cells_done':cells_done,'calls':counts,'worker_cpu_ns':time.process_time_ns(),'worker_wall_ns':time.perf_counter_ns()-ENTRY_W,'postprocessing_cpu_ns':postc,'postprocessing_wall_ns':postw,'maxrss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'calls_sha256':sha(ROOT/'raw/calls.jsonl'),'cells_sha256':sha(ROOT/'raw/cells.jsonl'),'reruns':0})
