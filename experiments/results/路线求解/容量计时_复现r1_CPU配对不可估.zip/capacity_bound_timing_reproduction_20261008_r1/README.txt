Independent timing stage on capacity_cross_structure_reproduction_20261008_r1.
Read reports/REPORT_ZH.txt first, then reports/INDEPENDENT_REVIEW.json.
7 frozen rounds x48cases x3arms x16calls=16128timed calls, plus144retained warmups.
No old raw recovery claim, no added independent scientific instances.
CPU nanosecond counters remained coarse: primary algorithm CPU ratios are non-estimable.
All wall times valid. New-bound/baseline wall total ratio1.200511288.
All original solver/input bytes unchanged; no reruns, no dropped failures/rounds.
The pre-execution snapshot and raw-first snapshot were privately backed up and downloaded byte-identically before the next stage.
