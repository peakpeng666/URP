"""Frozen paired geometry analysis; standard library; no old numeric results."""
from pathlib import Path
from collections import defaultdict,Counter
import csv,json,math,random,resource,statistics,sys,time
sys.dont_write_bytecode=True
from budget_engine import ROOT,verify,read,dump,sha,utc

def mean(xs):return statistics.fmean(xs)
def csvwrite(name,rows):
    if not rows:return
    with (ROOT/'reports'/name).open('x',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def quantile(xs,p):
    x=sorted(xs);a=(len(x)-1)*p;i=int(a);return x[i]+(x[min(i+1,len(x)-1)]-x[i])*(a-i)
def direct_check(obj,output):
    routes=output['routes'];n=len(obj['demands'])-1;nodes=[];terms=[];loads=[]
    for r in routes:
        assert r[0]==r[-1]==0 and 0 not in r[1:-1]
        nodes+=r[1:-1];load=sum(obj['demands'][j] for j in r[1:-1]);loads.append(load);assert load<=obj['capacity']
        for a,b in zip(r,r[1:]):
            dx=obj['coordinates'][a][0]-obj['coordinates'][b][0];dy=obj['coordinates'][a][1]-obj['coordinates'][b][1]
            terms.append(math.sqrt(dx*dx+dy*dy))
    assert sorted(nodes)==list(range(1,n+1));cost=math.fsum(terms)
    assert math.isclose(cost,output['reported_cost'],rel_tol=1e-10,abs_tol=1e-9)
    return {'recomputed_cost':cost,'reported_cost':output['reported_cost'],'absolute_difference':abs(cost-output['reported_cost']),'route_count':len(routes),'max_route_load':max(loads),'passed':True}

def main():
    resource.setrlimit(resource.RLIMIT_CPU,(10,11));started=time.process_time();verify()
    cfg=read(ROOT/'freeze/PROTOCOL.json');schedule=read(ROOT/'freeze/SCHEDULE.json');manifest=read(ROOT/'freeze/INPUT_MANIFEST.json')
    rows=[json.loads(l) for l in (ROOT/'raw/TRAJECTORIES.jsonl').read_text().splitlines()]
    assert len(rows)==len(schedule)==cfg['formal_trajectories']
    assert [r['run_id'] for r in rows]==[r['run_id'] for r in schedule]
    algorithms=['_'.join(p) for p in cfg['pairs']];budgets=cfg['checkpoints'];seeds=cfg['search_seeds'];demands=cfg['demand_modes']
    geo_meta={e['geometry_id']:{k:e[k] for k in ('family','n','replicate','geometry_seed')} for e in manifest};geos=sorted(geo_meta)
    observed={};obs=[];spot=[];issues=[];statuses=Counter()
    for r in rows:
        statuses[r['status']]+=1
        for k in ('geometry_id','algorithm','search_seed','input_sha256'):assert r[k]==schedule[r['run_id']][k]
        prev=r.get('baseline',{}).get('reported_cost',math.inf) if r.get('baseline') else math.inf
        for cp in r.get('checkpoints',[]):
            key=(r['geometry_id'],r['demand_mode'],r['algorithm'],r['search_seed'],cp['budget'])
            assert key not in observed
            valid=bool(r['status']=='executed' and not r.get('error') and cp['scoreable'] and cp['deltas']==cp['budget'] and cp['check']['accepted'])
            cost=cp['check']['recomputed_cost'] if valid else None
            observed[key]=cost
            if cost is not None:
                assert cost<=prev+1e-9;prev=cost
                assert sum(cp['delta_by_kind'].values())==cp['budget']
            obs.append({k:r[k] for k in ('run_id','geometry_id','family','n','replicate','demand_mode','algorithm','search_seed')}|{'budget':cp['budget'],'valid':valid,'cost':cost,'routes':cp['check']['route_count'],'deltas':cp['deltas'],'iterations_completed':cp['iterations_completed'],'solver_cpu_seconds':cp['solver_cpu_seconds']})
            if r['replicate']==0 and r['demand_mode']=='constant5' and r['search_seed']==seeds[0]:
                try:result=direct_check(read(ROOT/r['input_file']),cp['output'])
                except Exception as e:result={'passed':False,'error':repr(e)}
                spot.append({'run_id':r['run_id'],'geometry_id':r['geometry_id'],'algorithm':r['algorithm'],'budget':cp['budget'],**result})
    usable=[];excluded=[]
    for g in geos:
        missing=[(d,a,s,b) for d in demands for a in algorithms for s in seeds for b in budgets if observed.get((g,d,a,s,b)) is None]
        (excluded if missing else usable).append({'geometry_id':g,'missing_or_invalid_cells':missing} if missing else g)
    block=[];costs={};regrets={};midranks={}
    for g in usable:
        for d in demands:
            for b in budgets:
                means={a:mean(observed[g,d,a,s,b] for s in seeds) for a in algorithms};minimum=min(means.values())
                for a,c in means.items():
                    rel=100*(c/minimum-1);rank=1+sum(v<c-1e-9 for v in means.values())+.5*sum(abs(v-c)<=1e-9 for k,v in means.items() if k!=a)
                    costs[g,d,a,b]=c;regrets[g,d,a,b]=rel;midranks[g,d,a,b]=rank
                    block.append({'geometry_id':g,**geo_meta[g],'demand_mode':d,'budget':b,'algorithm':a,'seed_mean_cost':c,'relative_regret_pct':rel,'midrank':rank})
    geom=[]
    for g in usable:
        for b in budgets:
            for a in algorithms:geom.append({'geometry_id':g,**geo_meta[g],'budget':b,'algorithm':a,'mean_relative_regret_pct':mean(regrets[g,d,a,b] for d in demands),'mean_midrank':mean(midranks[g,d,a,b] for d in demands)})
    rr=cfg['primary_algorithm'];competitors=[a for a in algorithms if a!=rr];contrasts=[];gain={}
    for g in usable:
        for b in budgets:
            for a in competitors:
                gains=[100*(costs[g,d,a,b]-costs[g,d,rr,b])/costs[g,d,a,b] for d in demands]
                val=mean(gains);gain[g,b,a]=val
                contrasts.append({'geometry_id':g,**geo_meta[g],'budget':b,'comparison':rr+' vs '+a,'competitor':a,'rr_cost_improvement_pct':val,'constant5_pct':gains[0],'high_variance_random_pct':gains[1],'high_variance_spatial_x_pct':gains[2]})
    groups={(f,n):[g for g in usable if geo_meta[g]['family']==f and geo_meta[g]['n']==n] for f in cfg['families'] for n in cfg['customer_counts']}
    contrast_keys=[(b,a) for b in budgets for a in competitors]
    boot={key:[] for key in contrast_keys};rng=random.Random(cfg['bootstrap_seed'])
    if all(groups.values()):
        for _ in range(cfg['bootstrap_replicates']):
            draw=[rng.choice(gs) for gs in groups.values() for _ in range(len(gs))]
            for b,a in contrast_keys:boot[b,a].append(mean(gain[g,b,a] for g in draw))
    paired=[]
    for b,a in contrast_keys:
        vals=[gain[g,b,a] for g in usable];dist=boot[b,a]
        paired.append({'budget':b,'competitor':a,'primary':b==cfg['primary_budget'] and a==cfg['primary_competitor'],'geometry_count':len(vals),'mean_rr_cost_improvement_pct':mean(vals) if vals else None,'median_pct':statistics.median(vals) if vals else None,'min_pct':min(vals) if vals else None,'max_pct':max(vals) if vals else None,'ci95_lower_pct':quantile(dist,.025) if dist else None,'ci95_upper_pct':quantile(dist,.975) if dist else None,'wins':sum(v>1e-9 for v in vals),'ties':sum(abs(v)<=1e-9 for v in vals),'losses':sum(v< -1e-9 for v in vals)})
    aggregate=[]
    for b in budgets:
        for group,gs,ds in [('overall',usable,demands)]+[(d,usable,[d]) for d in demands]+[(f'{f}-n{n}',v,demands) for (f,n),v in groups.items()]:
            for a in algorithms:
                aggregate.append({'budget':b,'group':group,'algorithm':a,'geometries':len(gs),'mean_relative_regret_pct':mean(mean(regrets[g,d,a,b] for d in ds) for g in gs) if gs else None,'mean_midrank':mean(mean(midranks[g,d,a,b] for d in ds) for g in gs) if gs else None})
    rankings={str(b):sorted([r for r in aggregate if r['budget']==b and r['group']=='overall'],key=lambda r:(r['mean_relative_regret_pct'],r['algorithm'])) for b in budgets}
    audit={'additional_direct_recomputations':len(spot),'planned_direct_recomputations':32,'all_passed':len(spot)==32 and all(r['passed'] for r in spot),'rows':spot,'all_new_checkpoint_monotonicity_checks_passed':True,'old_outputs_reaudited':0,'all_frozen_hashes_unchanged':True}
    dump(ROOT/'reports/SPOT_CHECK.json',audit)
    summary={'utc':utc(),'scope':cfg['scope'],'planned_geometries':32,'usable_geometries':len(usable),'excluded_geometries':excluded,'planned_trajectories':len(schedule),'executed_trajectories':statuses['executed'],'checkpoint_observations':len(obs),'valid_checkpoint_observations':sum(r['valid'] for r in obs),'formal_failures':read(ROOT/'failures/FAILURES.json')['count'],'rankings':rankings,'paired_comparisons':paired,'bootstrap':{'unit':'geometry','replicates':cfg['bootstrap_replicates'],'seed':cfg['bootstrap_seed'],'cells':{str(k):len(v) for k,v in groups.items()},'interval':'percentile95','scope':'Conditional on synthetic generators and fixed search seeds; correlated checkpoints retained in same resample'},'spot_check_passed':audit['all_passed'],'old_runs_counted':0,'analysis_cpu_seconds_before_write':time.process_time()-started}
    dump(ROOT/'reports/SUMMARY.json',summary)
    csvwrite('checkpoint_observations.csv',obs);csvwrite('geometry_demand_aggregates.csv',block);csvwrite('geometry_aggregates.csv',geom);csvwrite('paired_geometry_comparisons.csv',contrasts);csvwrite('paired_summary.csv',paired);csvwrite('aggregate_rankings.csv',aggregate)
    csvwrite('bootstrap_paired_means.csv',[{'resample':i,**{f'{b}_{a}':boot[b,a][i] for b,a in contrast_keys}} for i in range(len(next(iter(boot.values()))))])
    print(json.dumps(summary,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
