"""Measure process-tree CPU and preserve stdout/stderr/exit code per stage."""
from pathlib import Path
import datetime,json,os,resource,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[1]
phase=sys.argv[1];limit={'prepare':30,'run':660,'analyze':120,'finalize':120}[phase]
start=time.perf_counter();ru=resource.getrusage(resource.RUSAGE_CHILDREN)
with (ROOT/f'raw/{phase.upper()}_STDOUT.txt').open('x') as out,(ROOT/f'raw/{phase.upper()}_STDERR.txt').open('x') as err:
    p=subprocess.Popen([sys.executable,'-B',str(ROOT/f'source/{phase}.py')],stdout=out,stderr=err,start_new_session=True)
    try:rc=p.wait(timeout=limit)
    except subprocess.TimeoutExpired:os.killpg(p.pid,9);rc=p.wait()
end=resource.getrusage(resource.RUSAGE_CHILDREN)
r={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase':phase,'exit_code':rc,'child_user_cpu_seconds':end.ru_utime-ru.ru_utime,'child_system_cpu_seconds':end.ru_stime-ru.ru_stime,'child_total_cpu_seconds':end.ru_utime+end.ru_stime-ru.ru_utime-ru.ru_stime,'wrapper_cpu_seconds':time.process_time(),'wall_seconds':time.perf_counter()-start,'maxrss_kib':end.ru_maxrss}
with (ROOT/f'raw/{phase.upper()}_RESOURCE.json').open('x') as f:json.dump(r,f,indent=2)
print(json.dumps(r));print((ROOT/f'raw/{phase.upper()}_STDOUT.txt').read_text()[-12000:])
if rc:print((ROOT/f'raw/{phase.upper()}_STDERR.txt').read_text())
raise SystemExit(rc)
