"""Write fixed protocol before generating any new geometry. No network."""
from pathlib import Path
import datetime, hashlib, importlib.util, json, math, random, statistics, sys, time
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[1]
OLD=Path('/workspace/shared/search_budget_20261007')
from budget_engine import legacy, from_dict, sha, dump, read, utc

def main():
    started=time.process_time()
    cfg={
      'name':'CVRP fresh synthetic geometry validation 20261007',
      'scope':'New synthetic geometries not previously used for tuning, sampled from the SAME uniform/clustered generators at n20/n50. This is not real field validation, a new geometry-distribution family, SOTA benchmarking, optimality evidence, or an untouched final benchmark. Stored split remains dev by existing input contract.',
      'families':['uniform','clustered'],'customer_counts':[20,50],'replicates_per_cell':8,'geometry_count':32,
      'geometry_seed_base':202610073200,'geometry_seeds':list(range(202610073200,202610073232)),
      'geometry_seed_assignment':'In family order uniform,clustered; n order20,50; replicate0..7. Assign geometry_seed_base + index.',
      'search_seeds':[27011,27027,27041],'schedule_seed':202610073299,
      'demand_modes':['constant5','high_variance_random','high_variance_spatial_x'],
      'demand_seed_offset':1000000,'capacity':30,
      'demand_rule':'constant5=[5]*n; the others have n/2 ones and n/2 nines. Random demand shuffles with geometry_seed+1000000. Spatial demand assigns9 to largest x, breaking ties by y then node ID. All modes share geometry, have total5*n and demand<=30.',
      'pairs':[['random','cheapest'],['random','regret2'],['worst','cheapest'],['worst','regret2']],
      'checkpoints':[10000,40000],'formal_trajectories':1152,'formal_checkpoint_observations':2304,
      'algorithm_rule':'Frozen source/budget_engine.py copied byte-for-byte from preceding budget study; source/legacy and vendor unchanged. Same strict-improvement acceptance, removal fraction10-30%, deterministic iteration seed derivation; no tuning, new operators or retries.',
      'eval_unit':'Legacy candidate delta arithmetic, savings+removal+insertion, charged before arithmetic. Excludes distance matrices, complete objective edge sums and checker work; those retain separate counters. Not equal FLOPs or equal walltime.',
      'sampling_rule':'Freeze before generating or evaluating any new geometry. Generate all32 in fixed seed order; no replacement, winner selection, expansion or result-based exclusions.',
      'independence':'32 primary geometry blocks; 3 paired demands,3 search seeds,4 algorithms and2 correlated checkpoints remain within-block repeated measurements.1152 trajectories and2304 observations are not independent geometry samples.',
      'aggregation':'Within geometry x demand x algorithm x checkpoint average3 seed costs. Relative regret=100*(mean_cost/min_four_mean_costs-1). Equal-weight3 demands per geometry, then32 geometries. Four-algorithm oracle is not global CVRP optimum.',
      'primary_contrast':'At40000:100*(random_cheapest_mean_cost-random_regret2_mean_cost)/random_cheapest_mean_cost within each geometry-demand, then mean3 demands and equal32 geometries. Positive favors frozen recommendation random_regret2.',
      'secondary_contrasts':'Same paired cost improvement vs worst_cheapest and worst_regret2;10000 budget; by family/n/demand; descriptive ranks and win/tie/loss. No multiplicity-adjusted claims.',
      'intervals':'95% percentile paired geometry bootstrap;10000 resamples,seed202610073301. Resample8 geometry IDs with replacement within each of4 family x n cells, retaining all seeds, demands, algorithms and budgets together. Same resamples across contrasts. Conditional on this generator and fixed search seeds, not universal confidence guarantees. Report CI crossing0 and heterogeneity.',
      'bootstrap_seed':202610073301,'bootstrap_replicates':10000,'primary_algorithm':'random_regret2','primary_competitor':'random_cheapest','primary_budget':40000,
      'tie_tolerance':1e-9,
      'failure_rule':'Keep all planned rows, errors and missing budgets. No imputation, reruns or replacing seeds. Main common support requires all4 algorithms x3 seeds x2 budgets for all3 demands in a geometry; enumerate any excluded geometry. If incomplete, bootstrap only within nonempty cells and mark estimate incomplete; no confirmatory claim.',
      'audit_rule':'Reuse existing independent coordinate-based checker on all new outputs; do not re-audit old history. Additional independently implemented direct objective/coverage/capacity calculation for one preselected trajectory in each of4 family x n cells x4 algorithms, at both budgets:32 outputs. Pick replicate0,constant5,search_seed27011. Check monotonic checkpoints on all new rows.',
      'old_results':'Old outputs and8 geometry results are provenance only. Read old input coordinate hashes solely to ensure no duplicate geometry. Zero historical runs counted as new.',
      'per_trajectory_cpu_limit':2.0,'per_trajectory_wall_limit':30.0,'process_cpu_soft_gate':94.0,'process_cpu_hard_limit':100,'return_reserve_cpu':4.0,'execution_wall_limit':600.0,
      'total_task_cpu_ceiling':120.0,'resource_plan':'Single solver process. Solver hard cap101 CPU seconds, soft gate94; measured generation and analysis plus unmeasured shell/setup conservative10-second allowance must remain<=120. No children inside solver. Wrapper measures child user+system CPU;10000-resample analysis limited to10 CPU seconds. Concurrent walltime not speed ranking.',
      'external_api_calls':0,'model_calls':0,'paid_calls':0,'new_dependencies':0,'external_uploads':0,
    }
    cfg['protocol_written_utc']=utc()
    dump(ROOT/'freeze/PROTOCOL.json',cfg)
    (ROOT/'freeze/PROTOCOL_ZH.md').write_text('''# 预固定的新合成几何验证协议\n\n在生成和评价前固定32个新几何，uniform/clustered × n20/n50各8个。种子202610073200–202610073231按上述分层顺序分配。三需求总量均为5n；搜索种子27011、27027、27041，配对用于四算法。仅记录10,000与40,000 delta，1,152条轨迹、2,304个相关检查点，不把检查点当独立运行。\n\n主对比预定为40,000时random_regret2对random_cheapest的几何平均配对成本改善；32个几何为统计单位，3需求和3搜索种子先组内汇总。使用固定种子202610073301做10,000次分层几何bootstrap，报告95%区间和局部负例。全部失败保留，不补跑、不改参数、不根据结果挑样本。\n\n复用已冻结操作器及检查器，只额外独立重算32个预选新输出；旧数值结果不重审、不重计。新几何来自原有生成器，并非真实田间、全新分布族、SOTA或最终盲测。单进程总任务CPU上限120秒，数值子进程硬上限101秒，资源实测另附。\n''')
    # This marker exists before generating even the first new coordinates.
    dump(ROOT/'freeze/PRE_GENERATION_FREEZE.json',{'utc':utc(),'new_geometries_generated_before_freeze':0,'new_trajectories_run_before_freeze':0,'sha256':{str(p.relative_to(ROOT)):sha(p) for p in sorted((ROOT/'source').rglob('*.py'))}|{'freeze/PROTOCOL.json':sha(ROOT/'freeze/PROTOCOL.json'),'freeze/PROTOCOL_ZH.md':sha(ROOT/'freeze/PROTOCOL_ZH.md')}})
    old_manifest=read(OLD/'input/independent_cvrp_demand_shift_20261006/data/manifest.json')['entries']
    old_geometry_hashes=sorted({e['coordinate_sha256'] for e in old_manifest})
    dump(ROOT/'freeze/OLD_GEOMETRY_HASHES.json',{'purpose':'Duplicate-coordinate exclusion check only; no old outcomes enter analysis','count':len(old_geometry_hashes),'hashes':old_geometry_hashes})
    entries=[];new_hashes=[]
    specs=[(fam,n,r) for fam in cfg['families'] for n in cfg['customer_counts'] for r in range(8)]
    for index,(fam,n,rep) in enumerate(specs):
        seed=cfg['geometry_seeds'][index];base=legacy.generate_instance(n,fam,seed,30).to_dict()
        geom=f'unseen-{fam}-n{n}-r{rep}-s{seed}'
        ch=hashlib.sha256(json.dumps(base['coordinates'],separators=(',',':')).encode()).hexdigest()
        assert ch not in old_geometry_hashes and ch not in new_hashes
        new_hashes.append(ch)
        rd=[1]*(n//2)+[9]*(n//2);random.Random(seed+cfg['demand_seed_offset']).shuffle(rd)
        spatial=[1]*n
        order=sorted(range(1,n+1),key=lambda i:(*base['coordinates'][i],i))
        for node in order[n//2:]:spatial[node-1]=9
        for mode,dem in zip(cfg['demand_modes'],[[5]*n,rd,spatial]):
            obj={**base,'instance_id':geom+'-'+mode,'demands':[0]+dem};inst=from_dict(obj)
            fn='input/'+obj['instance_id']+'.json';dump(ROOT/fn,obj)
            xs=[a[0] for a in base['coordinates'][1:]];mx=statistics.mean(xs);md=statistics.mean(dem)
            den=math.sqrt(sum((x-mx)**2 for x in xs)*sum((q-md)**2 for q in dem))
            entries.append({'geometry_id':geom,'family':fam,'n':n,'replicate':rep,'geometry_seed':seed,'demand_mode':mode,'input_file':fn,'input_sha256':sha(ROOT/fn),'coordinate_sha256':ch,'total_demand':sum(dem),'demand_variance':statistics.pvariance(dem),'demand_x_pearson':sum((x-mx)*(q-md) for x,q in zip(xs,dem))/den if den else None})
    dump(ROOT/'freeze/INPUT_MANIFEST.json',entries)
    schedule=[{**e,'search_seed':s,'algorithm':'_'.join(pair),'pair':pair} for e in entries for s in cfg['search_seeds'] for pair in cfg['pairs']]
    random.Random(cfg['schedule_seed']).shuffle(schedule)
    for i,c in enumerate(schedule):c['run_id']=i
    dump(ROOT/'freeze/SCHEDULE.json',schedule)
    source_rows=[]
    for f in sorted((ROOT/'source').rglob('*.py')):
        old=(OLD/'source/experiment.py') if f.name=='budget_engine.py' else OLD/f.relative_to(ROOT)
        source_rows.append({'file':str(f.relative_to(ROOT)),'sha256':sha(f),'source':str(old) if old.exists() else None,'source_sha256':sha(old) if old.exists() else None,'byte_identical_to_original':sha(f)==sha(old) if old.exists() else None})
    dump(ROOT/'freeze/SOURCE_PROVENANCE.json',source_rows)
    dump(ROOT/'freeze/PRE_RUN_FREEZE.json',{'utc':utc(),'formal_runs_before_freeze':0,'new_geometries':32,'duplicate_old_geometries':0,'sha256':{str(p.relative_to(ROOT)):sha(p) for dr in ['source','input','freeze'] for p in sorted((ROOT/dr).rglob('*')) if p.is_file()}})
    dump(ROOT/'raw/PREPARATION_RESOURCE.json',{'cpu_seconds':time.process_time()-started,'new_geometry_count':len(new_hashes),'input_count':len(entries),'schedule_count':len(schedule)})
    print(json.dumps({'prepared':True,'geometries':32,'trajectories':len(schedule),'protocol_sha256':sha(ROOT/'freeze/PROTOCOL.json'),'freeze_sha256':sha(ROOT/'freeze/PRE_RUN_FREEZE.json')}))
if __name__=='__main__':main()
