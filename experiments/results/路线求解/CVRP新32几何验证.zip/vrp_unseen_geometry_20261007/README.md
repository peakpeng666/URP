# CVRP fresh synthetic geometry validation 20261007

Start with reports/REPORT_ZH.md and reports/SUMMARY.json. This bundle contains only32 newly generated geometries and1152 newly executed trajectories. Two checkpoints per trajectory are paired repeated measures. Old results are not counted. No model/API/network calls.

The Python standard library is sufficient. Core legacy operators, input contract, checker and anytime checkpoint engine are byte-identical to the preceding budget experiment. New sources freeze before generation; finalization is a separate post-results reporting helper under reports/.

Read-only verification: add source/ to Python import path, import budget_engine, call budget_engine.verify(). To reproduce one chosen row in a separate audit process, read freeze/SCHEDULE.json, load its input_file with budget_engine.from_dict, and call budget_engine.trajectory(instance, row['pair'], row['search_seed'], protocol). Compare checkpoint output and delta count, not timing fields. Do not overwrite completed raw data.

Full reproduction needs an empty destination containing source/ plus the documented preceding source package for prepare.py provenance. Inputs and frozen schedule are already bundled for independently rerunning individual trajectories. source/measure.py provides stage process-tree resource accounting. No dependency installation or paid interface is needed.
