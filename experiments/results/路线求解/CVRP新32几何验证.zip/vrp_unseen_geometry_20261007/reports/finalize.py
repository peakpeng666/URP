"""Post-results reporting and minimal provenance packaging; no solver calls."""
from pathlib import Path
import csv,datetime,difflib,hashlib,json,resource,sys,time,zipfile
ROOT=Path(__file__).resolve().parents[1];OLD=Path('/workspace/shared/search_budget_20261007')
started=time.process_time()
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
s=read(ROOT/'reports/SUMMARY.json');cfg=read(ROOT/'freeze/PROTOCOL.json')
resources=[read(ROOT/f'raw/{stage}_RESOURCE.json') for stage in ['PREPARE','RUN','ANALYZE']]
measured=sum(r['child_total_cpu_seconds']+r['wrapper_cpu_seconds'] for r in resources)
primary=next(x for x in s['paired_comparisons'] if x['primary'])
oldman=OLD/'input/independent_cvrp_demand_shift_20261006/data/manifest.json'
olds=read(oldman)['entries'];news=read(ROOT/'freeze/INPUT_MANIFEST.json')
oldseeds=sorted({e['geometry_seed'] for e in olds});newseeds=sorted({e['geometry_seed'] for e in news})
oldhashes={e['coordinate_sha256'] for e in olds};newhashes={e['coordinate_sha256'] for e in news}
assert not set(newseeds)&set(oldseeds) and not newhashes&oldhashes
assert len(newseeds)==len(newhashes)==32
novelty={'old_manifest_source':str(oldman),'old_manifest_sha256':sha(oldman),'old_geometry_count_including_smoke':len(oldhashes),'old_geometry_seeds':oldseeds,'new_geometry_seeds':newseeds,'geometry_seed_overlap':[],'coordinate_hash_overlap':[],'all32_new_hashes_distinct':True,'new_search_seeds':cfg['search_seeds'],'old_budget_study_search_seeds':read(OLD/'freeze/PROTOCOL.json')['search_seeds'],'old_results_in_new_statistics':0}
dump(ROOT/'reports/NOVELTY_CHECK.json',novelty)
report=f'''# CVRP 新合成几何验证结果

## 结论

32个预先固定的新几何上，random_regret2在10,000和40,000 delta预算下均保持四算法总体第一。40,000时，它相对random_cheapest的平均配对成本改善为{primary['mean_rr_cost_improvement_pct']:.4f}%，分层几何bootstrap 95%区间为[{primary['ci95_lower_pct']:.4f}%, {primary['ci95_upper_pct']:.4f}%]。32几何中27胜、4平、1负，不能说每个几何都胜。

这是原uniform/clustered生成器内、未经本轮调参的新样本验证。它检验旧8开发几何上的排序能否延续到新抽样几何，未测试新的分布族或更大规模，也没有真实田间、现代强基线、SOTA或最优性证据。

## 固定设计

- 在生成任何新坐标前写入协议及SHA256：uniform/clustered × n20/n50四层各8几何；几何种子202610073200至202610073231；配对搜索种子27011、27027、27041。
- 每几何保留constant5、高方差随机、高方差按x空间相关三需求。总需求均为5n；高方差两模式均为一半1、一半9；容量30。
- 四个destroy/repair组合以及预算引擎按字节复用。无参数搜索、筛选赢家、替换种子或补跑。
- 32 × 3需求 × 3搜索种子 × 4算法 = 1,152条轨迹；每条运行至40,000并保留10,000检查点。2,304个检查点是相关重复测量，主配对单位只有32个几何。全部旧结果只作来源，新增统计中旧运行数为0。
- 评价单位为候选delta算术，包含初始化savings、removal、insertion；距离矩阵、整解目标和检查器成本另外记录，不是等CPU或等FLOP。

## 结果和边界

四算法平均相对遗憾如下，单位%。先平均同几何同需求的3个搜索种子，再相对该块四算法中最小均值算遗憾，最后等权汇总需求和几何。这里的oracle仅指四算法池内最佳。

| delta预算 | random_regret2 | random_cheapest | worst_regret2 | worst_cheapest |
|---:|---:|---:|---:|---:|
'''
for b in cfg['checkpoints']:
    d={r['algorithm']:r['mean_relative_regret_pct'] for r in s['rankings'][str(b)]}
    report+=f"| {b:,} | {d['random_regret2']:.4f} | {d['random_cheapest']:.4f} | {d['worst_regret2']:.4f} | {d['worst_cheapest']:.4f} |\n"
report+='''
预定主比较为40,000时random_regret2对random_cheapest。改善百分比先逐几何需求块计算100 × (对照成本 − random_regret2成本)/对照成本，再平均三需求与32几何。主比较的中位数为0.6531%，范围−0.1323%至1.9365%。负例为clustered n20、replicate6、几何种子202610073222：三需求平均比random_cheapest差0.1323%。

10,000预算的相应平均改善为0.3196%，95%区间[0.2207%, 0.4317%]，24胜、6平、2负。所有需求组及四个family×n分层中，random_regret2均为平均相对遗憾第一；其余名次并不处处固定，例如10,000时两个n50分层中worst_regret2排在random_cheapest之前。

区间由预固定种子202610073301生成10,000次分层bootstrap：每层有放回抽8个几何，同一几何的全部需求、算法、搜索种子和预算共同保留。不将2,304个检查点当独立样本。该区间只反映当前生成器与固定搜索种子下的几何抽样不确定性；32个几何和3个搜索种子仍有限。次比较未作多重比较校正，不把这些区间包装成普适保证或最终盲测证明。

## 完整性与资源

- 1,152/1,152轨迹、2,304/2,304检查点可评分；32/32几何进入共同支持集。失败、非法解、缺失、重跑均为0，空失败清单仍保留。
- 复用坐标重算的独立检查器检查全部新输出；另外按预定选择，对四层r0、constant5、首搜索种子、四算法、两预算共32个输出独立重算目标、客户覆盖和容量，全部通过。所有新轨迹检查点成本不升。没有重审历史输出。
- 32个新几何的坐标hash互异，与原需求实验24个正式几何及1个smoke几何均无重叠；新几何种子亦无重叠。
'''
report+=f"- 数值进程CPU为39.219825秒，数值墙时39.279507秒；准备、分析及三次计量启动器合计计入后，打包前实测CPU为{measured:.6f}秒。打包另计，未逐条计量的轻量shell、文件查看和准备保守预留10秒，完整资源账见RESOURCE_ACCOUNTING.json。总额远低于120秒上限。并发云环境墙时不用于算法速度排名。\n"
report+='''- 模型、付费API、网络求解、依赖安装均为0；本目录未外传。父线程统一处理私有交付。

## 最小复核入口

- freeze/PROTOCOL.json、PRE_GENERATION_FREEZE.json、PRE_RUN_FREEZE.json：预生成设计、输入及源码冻结
- raw/TRAJECTORIES.jsonl：1,152条轨迹及原始检查点；failures/FAILURES.json：保留全部失败状态
- reports/SUMMARY.json、paired_summary.csv、paired_geometry_comparisons.csv：主结论与负例
- reports/geometry_demand_aggregates.csv、bootstrap_paired_means.csv：按几何配对汇总及固定bootstrap原值
- reports/SPOT_CHECK.json、NOVELTY_CHECK.json：额外32输出复算及新旧几何不重叠证据
- reports/SOURCE_DIFF.patch、freeze/SOURCE_PROVENANCE.json：运行器差分及未改动核心源码hash
- MANIFEST.json、SHA256SUMS.txt：最小文件清单和校验值

本报告为本次执行及自检记录，额外独立审计若开展，应另留审计证据，不冒充本报告已完成的外部审计。
'''
(ROOT/'reports/REPORT_ZH.md').write_text(report)
(ROOT/'README.md').write_text('''# CVRP fresh synthetic geometry validation 20261007

Start with reports/REPORT_ZH.md and reports/SUMMARY.json. This bundle contains only32 newly generated geometries and1152 newly executed trajectories. Two checkpoints per trajectory are paired repeated measures. Old results are not counted. No model/API/network calls.

The Python standard library is sufficient. Core legacy operators, input contract, checker and anytime checkpoint engine are byte-identical to the preceding budget experiment. New sources freeze before generation; finalization is a separate post-results reporting helper under reports/.

Read-only verification: add source/ to Python import path, import budget_engine, call budget_engine.verify(). To reproduce one chosen row in a separate audit process, read freeze/SCHEDULE.json, load its input_file with budget_engine.from_dict, and call budget_engine.trajectory(instance, row['pair'], row['search_seed'], protocol). Compare checkpoint output and delta count, not timing fields. Do not overwrite completed raw data.

Full reproduction needs an empty destination containing source/ plus the documented preceding source package for prepare.py provenance. Inputs and frozen schedule are already bundled for independently rerunning individual trajectories. source/measure.py provides stage process-tree resource accounting. No dependency installation or paid interface is needed.
''')
patch=['# Frozen source/budget_engine.py is a byte-identical copy of prior source/experiment.py.\n','# All source/legacy/* files are byte-identical; hashes are in freeze/SOURCE_PROVENANCE.json.\n','# Added wrapper/generation/analysis/measurement code follows. No legacy operator edits.\n']
for name in ['prepare.py','run.py','analyze.py','measure.py']:
    p=ROOT/'source'/name
    patch+=difflib.unified_diff([],p.read_text().splitlines(True),fromfile='/dev/null',tofile='b/source/'+name)
(ROOT/'reports/SOURCE_DIFF.patch').write_text(''.join(patch))
# Verify immutable experiment files after all numerical analysis.
fr=read(ROOT/'freeze/PRE_RUN_FREEZE.json');bad=[n for n,h in fr['sha256'].items() if sha(ROOT/n)!=h];assert not bad
alllegacy=[r for r in read(ROOT/'freeze/SOURCE_PROVENANCE.json') if r['file'].startswith('source/legacy/') or r['file']=='source/budget_engine.py'];assert all(r['byte_identical_to_original'] for r in alllegacy)
account={'measured_stages':resources,'measured_preparation_run_analysis_and_wrappers_cpu_seconds':measured,'finalization_cpu_seconds_before_manifest':time.process_time()-started,'unmeasured_shell_and_lightweight_setup_conservative_allowance_seconds':10.0,'allowance_is_not_a_measurement':True,'cpu_limit_seconds':120.0,'solver_cpu_hard_limit_seconds':101,'numerical_search_processes':1,'external_calls':0,'finalization_and_archive_resource':'raw/FINALIZE_RESOURCE.json records the complete finalize.py child after exit; raw/ARCHIVE_RESOURCE.json records final archive/manifest step. Their CPU is additional to the stage sum above.','independent_parent_audit':'separate scope and resource ledger; not included in this task CPU'}
dump(ROOT/'reports/RESOURCE_ACCOUNTING.json',account)
dump(ROOT/'reports/FINAL_SELF_CHECK.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'frozen_files_unchanged':not bad,'legacy_and_budget_engine_byte_identical':True,'geometries':32,'trajectories':1152,'checkpoint_observations':2304,'all_scoreable':s['valid_checkpoint_observations']==2304,'failures':s['formal_failures'],'source_diff_present':True,'external_uploads':0})
print(json.dumps({'report':'reports/REPORT_ZH.md','core_files_unchanged':True,'measured_cpu_before_finalization':measured,'finalization_cpu_so_far':time.process_time()-started}))
