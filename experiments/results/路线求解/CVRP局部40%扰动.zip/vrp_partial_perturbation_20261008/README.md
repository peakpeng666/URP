# CVRP partial40 perturbation ablation

Start with reports/REPORT_ZH.md and reports/SUMMARY.json.

Frozen 16 fresh n50 geometries, two demands, two paired search seeds, 3 perturbation arms. Same legacy delta ledger, including full and partial reconstruction. Source/core files, protocol, all inputs, raw trajectories, failures, route audits, resource and exit receipts retained. No external calls or paid resources. Reports are execution/self-check evidence, not an independent external review. No old package modified.
