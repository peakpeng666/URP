from pathlib import Path
import hashlib,json,random,sys,time
sys.dont_write_bytecode=True
from budget_engine import ROOT,legacy,from_dict,sha,dump,read,utc
OLD=Path('/workspace/shared/vrp_operator_restart_ablation_20261008')
def main():
    t=time.process_time()
    cfg={'name':'CVRP RR2 none vs full vs partial40 perturbation','written_utc':utc(),
         'geometry_count':16,'families':['uniform','clustered'],'n':50,'replicates_per_family':8,
         'geometry_seeds':list(range(202610080300,202610080316)),
         'search_seeds':[83011,83029],'demand_modes':['constant5','high_variance_random'],
         'demand_seed_offset':1000000,'capacity':30,'arms':['none','full','partial40'],
         'checkpoints':[40000,160000],'primary_budget':160000,'formal_trajectories':192,
         'schedule_seed':202610080399,'bootstrap_seed':202610080499,'bootstrap_replicates':10000,
         'restart_stagnation_iterations':8,'partial_fraction':0.4,
         'full_rule':'Byte-identical legacy random-order cheapest sequential insertion from empty. derived_seed(search_seed,restart,index).',
         'partial_rule':'Uniformly sample exactly ceil(0.4*n)=20 customers from current using derived_seed(search_seed,partial_perturbation,index). Original random destroy and original regret2 repair. Preserve relative order of 30 retained customers within their original routes; repair may insert customers. No new operator or noise.',
         'shared_trigger_and_acceptance':'After 8 consecutive completed proposals without strict improvement to CURRENT, trigger perturbation. Accept only fully repaired solution as current even if worse; preserve GLOBAL BEST. Reset stagnation. Interrupted reconstruction is never submitted. All remove/repair candidate deltas counted in same budget.',
         'justification_before_results':'Legacy ordinary iterations random-remove 10%-30% (5-15) and strictly improve current; fixed40% (20) is outside ordinary q range yet retains60% of customers. Distinct kick also allows worsening. Single rule; no fraction/threshold tuning.',
         'operator_rule':'All arms unchanged random destroy, q uniform integer5..15, original regret2 repair, strict current improvement, global best output.',
         'eval_unit':'Candidate delta arithmetic savings+removal+insertion. Random removal evaluates no distance deltas, hence removal ledger correctly zero; all insertion comparisons count. Full objective edge sums, matrix distances, checker separately counted. Not equal CPU,FLOP or whole-objective calls.',
         'fleet':'Unlimited homogeneous capacity30 vehicles. No fixed-K feasibility interpretation.',
         'primary_contrast':'At160k,100*(full_mean_cost-partial40_mean_cost)/full_mean_cost per geometry-demand; average2 demands, equal16 geometries. Positive favors partial.',
         'secondary_contrasts':['partial_vs_none','full_vs_none'],
         'aggregation':'Average2 search seeds within geometry-demand-arm, form relative cost contrasts, equal2 demand variants then equal16 independent geometries. Stratified bootstrap8 geometries per family with replacement10000 times. Checkpoints and variants are repeated measures, not independent sample sizes. Secondary intervals unadjusted.',
         'mechanism':'Report planned/executed trajectories, perturbations started/completed/incomplete, direct delta cost, immediate current degradation relative pre-current and pre-best, first completed perturbation budget remaining and used after, subsequent global-best improvement and delta to first improvement/recovery. Trigger-conditioned diagnostics descriptive and potentially selected, not standalone causal estimators.',
         'failure_rule':'No retries, replacement, posthoc expansion, score-based filtering. Preserve every planned call. Common-support geometry needs all12 calls and2 checkpoints valid. No triggers means no mechanism test.',
         'scope':'Fresh geometries from same uniform/clustered synthetic generators. n50 only; constant5/random1-9 demand only. No real field, fixed-K, modern external baselines, SOTA or universal mechanism claim.',
         'per_trajectory_cpu_limit':3.0,'per_trajectory_wall_limit':10.0,'process_cpu_hard_limit':115,
         'process_cpu_soft_gate':108.0,'execution_wall_limit':170.0,'main_cpu_ceiling':120.0,'main_wall_ceiling':180.0,
         'resource_forecast':'Previous256x160k used33.7CPU sec;192x160k predicts25.3sec before instrumentation. Even4x remains<120sec.',
         'external_api_calls':0,'model_calls':0,'paid_calls':0,'new_dependencies':0,'external_uploads':0}
    dump(ROOT/'freeze/PROTOCOL.json',cfg)
    prov=[]
    for p in sorted((ROOT/'source').rglob('*.py')):
        rel=p.relative_to(ROOT);old=OLD/rel
        if p.name=='reference_ablation.py':old=OLD/'source/ablation.py'
        prov.append({'path':str(rel),'sha256':sha(p),'source':str(old) if old.exists() else 'new_for_partial_ablation','source_sha256':sha(old) if old.exists() else None,'byte_identical':sha(p)==sha(old) if old.exists() else None})
    dump(ROOT/'freeze/SOURCE_PROVENANCE.json',prov)
    dump(ROOT/'freeze/PRE_GENERATION_FREEZE.json',{'utc':utc(),'new_geometry_count_before_freeze':0,'new_solver_runs_before_freeze':0,'sha256':{str(p.relative_to(ROOT)):sha(p) for p in sorted((ROOT/'source').rglob('*.py'))}|{'freeze/PROTOCOL.json':sha(ROOT/'freeze/PROTOCOL.json')}})
    old=read(OLD/'freeze/OLD_GEOMETRIES.json');old_hashes=set(old['coordinate_hashes']);old_seeds=set(old['geometry_seeds'])
    for e in read(OLD/'freeze/INPUT_MANIFEST.json'):old_hashes.add(e['coordinate_sha256']);old_seeds.add(e['geometry_seed'])
    dump(ROOT/'freeze/OLD_GEOMETRIES.json',{'coordinate_hashes':sorted(old_hashes),'geometry_seeds':sorted(old_seeds),'sources':[{'path':str(OLD/'freeze/OLD_GEOMETRIES.json'),'sha256':sha(OLD/'freeze/OLD_GEOMETRIES.json')},{'path':str(OLD/'freeze/INPUT_MANIFEST.json'),'sha256':sha(OLD/'freeze/INPUT_MANIFEST.json')}]})
    entries=[];new_hashes=[]
    for index,seed in enumerate(cfg['geometry_seeds']):
        family=cfg['families'][index//8];rep=index%8;geom=f'partial40-{family}-n50-r{rep}-s{seed}'
        base=legacy.generate_instance(50,family,seed,30).to_dict()
        ch=hashlib.sha256(json.dumps(base['coordinates'],separators=(',',':')).encode()).hexdigest()
        assert ch not in old_hashes and ch not in new_hashes and seed not in old_seeds
        new_hashes.append(ch);demands=[1]*25+[9]*25;random.Random(seed+cfg['demand_seed_offset']).shuffle(demands)
        for mode,dem in zip(cfg['demand_modes'],[[5]*50,demands]):
            obj={**base,'instance_id':geom+'-'+mode,'demands':[0]+dem};from_dict(obj)
            fn='input/'+obj['instance_id']+'.json';dump(ROOT/fn,obj)
            entries.append({'geometry_id':geom,'family':family,'n':50,'replicate':rep,'geometry_seed':seed,'demand_mode':mode,'input_file':fn,'input_sha256':sha(ROOT/fn),'coordinate_sha256':ch})
    dump(ROOT/'freeze/INPUT_MANIFEST.json',entries)
    calls=[{**e,'search_seed':s,'arm':a} for e in entries for s in cfg['search_seeds'] for a in cfg['arms']]
    random.Random(cfg['schedule_seed']).shuffle(calls)
    for i,c in enumerate(calls):c['run_id']=i
    dump(ROOT/'freeze/SCHEDULE.json',calls)
    dump(ROOT/'freeze/PRE_RUN_FREEZE.json',{'utc':utc(),'formal_runs_before_freeze':0,'sha256':{str(p.relative_to(ROOT)):sha(p) for dr in ['source','input','freeze'] for p in sorted((ROOT/dr).rglob('*')) if p.is_file()}})
    dump(ROOT/'raw/PREPARATION.json',{'cpu_seconds':time.process_time()-t,'geometry_count':16,'trajectories':len(calls),'new_hashes_distinct':len(set(new_hashes)),'old_coordinate_hashes_checked':len(old_hashes)})
    print(json.dumps({'prepared':True,'trajectories':len(calls),'protocol_sha256':sha(ROOT/'freeze/PROTOCOL.json')}),flush=True)
if __name__=='__main__':main()
