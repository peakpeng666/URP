"""One frozen restart rule over byte-identical legacy operators. No network."""
import copy, math, random, time, traceback
from budget_engine import CheckpointBudget, legacy, check_solution

def restart(instance, matrix, budget, seed, index):
    """Random-order cheapest sequential insertion. Every candidate delta is charged."""
    nodes=list(range(1,instance.n_customers+1))
    random.Random(legacy.derived_seed(seed,'restart',index)).shuffle(nodes)
    routes=[];loads=[]
    for node in nodes:
        _,ri,pi=legacy.route_options(node,routes,loads,instance,matrix,budget)[0]
        if ri==len(routes):routes.append([node]);loads.append(instance.demands[node])
        else:routes[ri].insert(pi,node);loads[ri]+=instance.demands[node]
    return routes

def trajectory(instance, repair, restart_on, seed, cfg):
    state={'output':None,'baseline':None,'iterations_started':0,'iterations_completed':0,
           'accepted_improvements':0,'current_improvements':0,'restart_started':0,'restart_completed':0,
           'restart_insertion_deltas':0,'stagnation':0,'current_cost':None}
    checkpoints=[];trace=[];stop='unexpected';error=None
    def checkpoint(b):
        checkpoints.append({'budget':b,**copy.deepcopy(state),**budget.snapshot()})
    class PhaseBudget(CheckpointBudget):
        restart_phase=False
        def delta(self,kind):
            super().delta(kind)
            if self.restart_phase:state['restart_insertion_deltas']+=1
    budget=PhaseBudget(cfg['checkpoints'],cfg,checkpoint)
    try:
        matrix=legacy.matrix_for(instance,budget)
        routes=legacy.savings(instance,matrix,budget);cost=legacy.cost_of(routes,matrix,budget)
        best_cost=cost;state['current_cost']=cost
        state['output']=legacy.output_for(routes,cost);state['baseline']=copy.deepcopy(state['output'])
        iteration=0
        while True:
            budget.check()
            if restart_on and state['stagnation']>=cfg['restart_stagnation_iterations']:
                rid=state['restart_started'];state['restart_started']+=1;before=budget.deltas
                # Assign only after complete reconstruction, preserving the incumbent on interruption.
                budget.restart_phase=True
                try:
                    rebuilt=restart(instance,matrix,budget,seed,rid)
                    rebuilt_cost=legacy.cost_of(rebuilt,matrix,budget)
                finally:
                    budget.restart_phase=False
                routes,cost=rebuilt,rebuilt_cost;state['current_cost']=cost
                state['restart_completed']+=1;state['stagnation']=0
                improved=cost<best_cost-1e-9
                if improved:
                    best_cost=cost;state['output']=legacy.output_for(routes,cost);state['accepted_improvements']+=1
                trace.append({'event':'restart','restart_id':rid,'current_cost':cost,'best_cost':best_cost,
                              'best_improved':improved,'deltas_before':before,'deltas':budget.deltas})
            state['iterations_started']+=1
            lo=min(instance.n_customers,max(2,math.ceil(.1*instance.n_customers)))
            hi=min(instance.n_customers,max(lo,math.ceil(.3*instance.n_customers)))
            q=random.Random(legacy.derived_seed(seed,'q',iteration)).randint(lo,hi)
            rng=random.Random(legacy.derived_seed(seed,'removal',iteration))
            partial,removed=legacy.destroy(routes,'random',q,rng,matrix,budget)
            candidate=legacy.repair(partial,removed,repair,instance,matrix,budget)
            candidate_cost=legacy.cost_of(candidate,matrix,budget)
            state['iterations_completed']+=1
            accepted=candidate_cost<cost-1e-9
            if accepted:
                routes,cost=candidate,candidate_cost;state['current_cost']=cost
                state['current_improvements']+=1;state['stagnation']=0
            else:state['stagnation']+=1
            improved=candidate_cost<best_cost-1e-9
            if improved:
                best_cost=candidate_cost;state['output']=legacy.output_for(candidate,candidate_cost)
                state['accepted_improvements']+=1
            trace.append({'event':'iteration','iteration':iteration,'q':q,'candidate_cost':candidate_cost,
                          'accepted_current':accepted,'best_improved':improved,'current_cost':cost,
                          'best_cost':best_cost,'deltas':budget.deltas,'stagnation':state['stagnation']})
            iteration+=1
    except legacy.StopBudget as e:stop=str(e)
    except Exception as e:stop='algorithm_failure';error={'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()}
    usage=budget.snapshot();checker_start=time.process_time()
    baseline_check=check_solution(instance,state['baseline']).to_dict()
    for cp in checkpoints:
        cp['check']=check_solution(instance,cp['output']).to_dict()
        cp['scoreable']=bool(cp['check']['accepted'] and baseline_check['accepted'] and cp['deltas']==cp['budget'])
    return {'stop_reason':stop,'error':error,'baseline_check':baseline_check,**state,'checkpoints':checkpoints,
            'missing_budgets':[b for b in cfg['checkpoints'] if b not in {c['budget'] for c in checkpoints}],
            'trace':trace,**usage,'checker_cpu_seconds':time.process_time()-checker_start}
