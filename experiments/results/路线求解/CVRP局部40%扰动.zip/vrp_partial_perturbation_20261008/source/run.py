import copy,json,os,resource,sys,time,traceback
sys.dont_write_bytecode=True
from budget_engine import ROOT,verify,read,dump,utc,legacy,from_dict,check_solution
from perturbation import trajectory,partial_perturbation
from reference_ablation import trajectory as reference_trajectory

def smoke_tests(cfg):
    toy=legacy.generate_instance(6,'uniform',202610080299,30)
    sc={**cfg,'checkpoints':[500,2000,8000]};tests=[]
    for arm in ['none','full']:
        got=trajectory(toy,arm,83999,sc);ref=reference_trajectory(toy,'regret2',arm=='full',83999,sc)
        for cp,rc in zip(got['checkpoints'],ref['checkpoints']):
            tests.append({'name':'legacy_control_equivalence','arm':arm,'budget':cp['budget'],
              'passed':cp['output']==rc['output'] and cp['current_cost']==rc['current_cost'] and cp['delta_by_kind']==rc['delta_by_kind'] and cp['iterations_completed']==rc['iterations_completed'] and cp['perturbations_completed']==rc['restart_completed'],
              'current_cost':cp['current_cost'],'output':cp['output'],'ledger':cp['delta_by_kind']})
    toy=legacy.generate_instance(10,'uniform',202610080298,30)
    b=legacy.Budget(20000,3,10);matrix=legacy.matrix_for(toy,b);routes=legacy.savings(toy,matrix,b);before=copy.deepcopy(routes);start=b.deltas
    rebuilt,removed=partial_perturbation(routes,toy,matrix,b,83999,0,.4)
    selected=set(removed);retained=[[x for x in r if x not in selected] for r in before];retained=[r for r in retained if r]
    after_retained=[[x for x in r if x not in selected] for r in rebuilt];after_retained=[r for r in after_retained if r]
    checked=check_solution(toy,legacy.output_for(rebuilt,legacy.cost_of(rebuilt,matrix,b))).accepted
    tests.append({'name':'partial_keeps_original_routes_order_and_charges','passed':len(removed)==4 and routes==before and retained==after_retained and b.deltas>start and b.by_kind['removal']==0 and checked,'removed':removed,'delta_cost':b.deltas-start})
    sc={**cfg,'checkpoints':[12000]};got=trajectory(toy,'partial40',83999,sc)
    starts=[e for e in got['trace'] if e['event']=='perturbation_start'];completed=[e for e in got['trace'] if e['event']=='perturbation_complete']
    tests.append({'name':'toy_partial_mechanism_triggered','passed':bool(completed) and all(len(e['removed'])==4 for e in completed),'started':len(starts),'completed':len(completed)})
    if starts:
        first=starts[0];cut={**cfg,'checkpoints':[first['deltas']+1]};short=trajectory(toy,'partial40',83999,cut)
        tests.append({'name':'interrupted_partial_not_submitted','passed':short['perturbations_started']==1 and short['perturbations_completed']==0 and short['current_output']==first['before_current_output'] and short['current_cost']==first['before_current_cost'] and short['deltas']==cut['checkpoints'][0] and short['perturbation_deltas']==1,'cut_budget':cut['checkpoints'][0]})
    return tests

def main():
    verify();cfg=read(ROOT/'freeze/PROTOCOL.json');calls=read(ROOT/'freeze/SCHEDULE.json');start=time.perf_counter();cpu=time.process_time()
    resource.setrlimit(resource.RLIMIT_CPU,(cfg['process_cpu_hard_limit'],cfg['process_cpu_hard_limit']))
    dump(ROOT/'raw/STARTED.json',{'utc':utc(),'pid':os.getpid(),'python':sys.version,'cpu_affinity':sorted(os.sched_getaffinity(0)),'planned_calls':len(calls),'no_formal_outcomes_loaded':True})
    tests=smoke_tests(cfg);ok=len(tests)==9 and all(t['passed'] for t in tests)
    dump(ROOT/'raw/SMOKE_TESTS.json',{'formal':False,'tests':tests,'all_passed':ok})
    if not ok:raise RuntimeError('smoke failed; formal not started')
    failures=[];formal_cpu=time.process_time()
    with (ROOT/'raw/TRAJECTORIES.jsonl').open('x') as f:
        for call in calls:
            row={**call,'started_utc':utc()}
            if time.process_time()+cfg['per_trajectory_cpu_limit']+3>cfg['process_cpu_soft_gate']:row.update(status='not_run_cpu_gate',missing_budgets=cfg['checkpoints'])
            elif time.perf_counter()-start+cfg['per_trajectory_wall_limit']>cfg['execution_wall_limit']:row.update(status='not_run_wall_gate',missing_budgets=cfg['checkpoints'])
            else:
                try:row.update(trajectory(from_dict(read(ROOT/call['input_file'])),call['arm'],call['search_seed'],cfg));row['status']='executed'
                except Exception as e:row.update(status='runner_failure',error={'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()},missing_budgets=cfg['checkpoints'])
            row['finished_utc']=utc();f.write(json.dumps(row,allow_nan=False)+'\n');f.flush()
            if row['status']!='executed' or row.get('error') or row.get('missing_budgets') or row.get('stop_reason')!='delta_budget' or any(not c['scoreable'] for c in row.get('checkpoints',[])):
                failures.append({'run_id':call['run_id'],'status':row['status'],'error':row.get('error'),'stop_reason':row.get('stop_reason'),'missing_budgets':row.get('missing_budgets',[])})
            if (call['run_id']+1)%32==0:print(json.dumps({'completed':call['run_id']+1,'cpu_seconds':time.process_time(),'wall_seconds':time.perf_counter()-start}),flush=True)
    dump(ROOT/'failures/FAILURES.json',{'count':len(failures),'rows':failures,'retries':0})
    verify();dump(ROOT/'raw/COMPLETION.json',{'utc':utc(),'planned':len(calls),'written':len(calls),'failures':len(failures),'formal_cpu_seconds':time.process_time()-formal_cpu,'execution_cpu_seconds':time.process_time()-cpu,'process_cpu_seconds':time.process_time(),'wall_seconds':time.perf_counter()-start,'model_calls':0,'api_calls':0,'paid_calls':0,'frozen_hashes_unchanged':True})
if __name__=='__main__':main()
