"""One predeclared partial perturbation; legacy search/operators unmodified."""
import copy, math, random, time, traceback
from budget_engine import CheckpointBudget, legacy, check_solution
from reference_ablation import restart

def partial_perturbation(routes, instance, matrix, budget, seed, index, fraction):
    q=min(instance.n_customers,max(1,math.ceil(fraction*instance.n_customers)))
    rng=random.Random(legacy.derived_seed(seed,'partial_perturbation',index))
    partial,removed=legacy.destroy(routes,'random',q,rng,matrix,budget)
    rebuilt=legacy.repair(partial,removed,'regret2',instance,matrix,budget)
    return rebuilt,removed

def trajectory(instance, arm, seed, cfg):
    state={'output':None,'baseline':None,'current_output':None,'iterations_started':0,'iterations_completed':0,
           'accepted_improvements':0,'current_improvements':0,'perturbations_started':0,'perturbations_completed':0,
           'perturbation_deltas':0,'stagnation':0,'current_cost':None}
    checkpoints=[];trace=[];stop='unexpected';error=None
    def checkpoint(b):checkpoints.append({'budget':b,**copy.deepcopy(state),**budget.snapshot()})
    class PhaseBudget(CheckpointBudget):
        perturbation_phase=False
        def delta(self,kind):
            super().delta(kind)
            if self.perturbation_phase:state['perturbation_deltas']+=1
    budget=PhaseBudget(cfg['checkpoints'],cfg,checkpoint)
    try:
        matrix=legacy.matrix_for(instance,budget)
        routes=legacy.savings(instance,matrix,budget);cost=legacy.cost_of(routes,matrix,budget)
        best_cost=cost;state['current_cost']=cost
        state['output']=legacy.output_for(routes,cost);state['baseline']=copy.deepcopy(state['output'])
        state['current_output']=copy.deepcopy(state['output']);iteration=0
        while True:
            budget.check()
            if arm!='none' and state['stagnation']>=cfg['restart_stagnation_iterations']:
                rid=state['perturbations_started'];state['perturbations_started']+=1;before=budget.deltas
                before_current=cost;before_best=best_cost
                trace.append({'event':'perturbation_start','perturbation_id':rid,'deltas':before,
                              'stagnation':state['stagnation'],'before_current_cost':cost,'before_best_cost':best_cost,
                              'before_current_output':copy.deepcopy(state['current_output'])})
                budget.perturbation_phase=True
                try:
                    if arm=='full':rebuilt=restart(instance,matrix,budget,seed,rid);removed=list(range(1,instance.n_customers+1))
                    else:rebuilt,removed=partial_perturbation(routes,instance,matrix,budget,seed,rid,cfg['partial_fraction'])
                    rebuilt_cost=legacy.cost_of(rebuilt,matrix,budget)
                finally:budget.perturbation_phase=False
                routes,cost=rebuilt,rebuilt_cost;state['current_cost']=cost
                state['current_output']=legacy.output_for(routes,cost)
                state['perturbations_completed']+=1;state['stagnation']=0
                improved=cost<best_cost-1e-9
                if improved:
                    best_cost=cost;state['output']=legacy.output_for(routes,cost);state['accepted_improvements']+=1
                trace.append({'event':'perturbation_complete','perturbation_id':rid,'current_cost':cost,'best_cost':best_cost,
                              'before_current_cost':before_current,'before_best_cost':before_best,'removed':removed,
                              'output':copy.deepcopy(state['current_output']),'best_improved':improved,
                              'deltas_before':before,'deltas':budget.deltas})
            state['iterations_started']+=1
            lo=min(instance.n_customers,max(2,math.ceil(.1*instance.n_customers)))
            hi=min(instance.n_customers,max(lo,math.ceil(.3*instance.n_customers)))
            q=random.Random(legacy.derived_seed(seed,'q',iteration)).randint(lo,hi)
            rng=random.Random(legacy.derived_seed(seed,'removal',iteration))
            partial,removed=legacy.destroy(routes,'random',q,rng,matrix,budget)
            candidate=legacy.repair(partial,removed,'regret2',instance,matrix,budget)
            candidate_cost=legacy.cost_of(candidate,matrix,budget)
            state['iterations_completed']+=1
            accepted=candidate_cost<cost-1e-9
            if accepted:
                routes,cost=candidate,candidate_cost;state['current_cost']=cost
                state['current_output']=legacy.output_for(routes,cost)
                state['current_improvements']+=1;state['stagnation']=0
            else:state['stagnation']+=1
            improved=candidate_cost<best_cost-1e-9
            if improved:
                best_cost=candidate_cost;state['output']=legacy.output_for(candidate,candidate_cost)
                state['accepted_improvements']+=1
            trace.append({'event':'iteration','iteration':iteration,'q':q,'candidate_cost':candidate_cost,
                          'accepted_current':accepted,'best_improved':improved,'current_cost':cost,
                          'best_cost':best_cost,'deltas':budget.deltas,'stagnation':state['stagnation']})
            iteration+=1
    except legacy.StopBudget as e:stop=str(e)
    except Exception as e:stop='algorithm_failure';error={'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()}
    usage=budget.snapshot();checker_start=time.process_time()
    baseline_check=check_solution(instance,state['baseline']).to_dict()
    for cp in checkpoints:
        cp['check']=check_solution(instance,cp['output']).to_dict()
        cp['current_check']=check_solution(instance,cp['current_output']).to_dict()
        cp['scoreable']=bool(cp['check']['accepted'] and cp['current_check']['accepted'] and baseline_check['accepted'] and cp['deltas']==cp['budget'])
    return {'stop_reason':stop,'error':error,'baseline_check':baseline_check,**state,'checkpoints':checkpoints,
            'missing_budgets':[b for b in cfg['checkpoints'] if b not in {c['budget'] for c in checkpoints}],
            'trace':trace,**usage,'checker_cpu_seconds':time.process_time()-checker_start}
