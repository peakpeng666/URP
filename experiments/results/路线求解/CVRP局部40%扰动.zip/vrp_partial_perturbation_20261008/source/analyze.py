"""Predeclared paired-block statistics and independent coordinate audit; no solver calls."""
from pathlib import Path
import collections,csv,hashlib,json,math,random,statistics,time
ROOT=Path(__file__).resolve().parents[1]
def read(p):return json.loads(p.read_text())
def dump(p,d):
    with p.open('x') as f:json.dump(d,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')
def csvout(name,rows):
    if not rows:return
    with (ROOT/'reports'/name).open('x',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def audit(inst,out):
    if not isinstance(out,dict):return {'accepted':False,'error':'missing_output'}
    routes=out.get('routes',[]);seen=[];loads=[];dist=[];endpoint_ok=True
    for route in routes:
        endpoint_ok &= len(route)>=3 and route[0]==route[-1]==0 and 0 not in route[1:-1]
        seen.extend(route[1:-1]);loads.append(sum(inst['demands'][i] for i in route[1:-1]))
        dist.extend(math.hypot(inst['coordinates'][a][0]-inst['coordinates'][b][0],inst['coordinates'][a][1]-inst['coordinates'][b][1]) for a,b in zip(route,route[1:]))
    cost=math.fsum(dist)
    ok=endpoint_ok and sorted(seen)==list(range(1,len(inst['coordinates']))) and max(loads,default=0)<=inst['capacity'] and math.isclose(cost,out.get('reported_cost',-1),rel_tol=1e-9,abs_tol=1e-9)
    return {'accepted':ok,'recomputed_cost':cost,'route_count':len(routes),'max_load':max(loads,default=0),'coverage_exact':sorted(seen)==list(range(1,len(inst['coordinates'])))}
def percentile(xs,q):
    s=sorted(xs);x=q*(len(s)-1);a=int(x);b=min(a+1,len(s)-1);return s[a]+(s[b]-s[a])*(x-a)
def main():
    t=time.process_time();cfg=read(ROOT/'freeze/PROTOCOL.json');schedule=read(ROOT/'freeze/SCHEDULE.json')
    p=ROOT/'raw/TRAJECTORIES.jsonl';rows=[json.loads(s) for s in p.read_text().splitlines()] if p.exists() else []
    by_id={r['run_id']:r for r in rows};audits=[];obs=[];valid=set();problems=[];mechanisms=[];events=[]
    for call in schedule:
        row=by_id.get(call['run_id']);inst=read(ROOT/call['input_file'])
        if not row:problems.append({'run_id':call['run_id'],'reason':'missing_row'});continue
        checked=audit(inst,row.get('baseline'));audits.append({'run_id':call['run_id'],'stage':'baseline',**checked})
        prior=checked.get('recomputed_cost',math.inf);row_ok=checked['accepted'] and row.get('status')=='executed' and row.get('stop_reason')=='delta_budget' and not row.get('error')
        for budget in cfg['checkpoints']:
            cp=next((c for c in row.get('checkpoints',[]) if c['budget']==budget),None)
            if not cp:row_ok=False;continue
            a=audit(inst,cp.get('output'));ca=audit(inst,cp.get('current_output'))
            audits.extend([{'run_id':call['run_id'],'stage':str(budget)+'_best',**a},{'run_id':call['run_id'],'stage':str(budget)+'_current',**ca}])
            ledger=cp['deltas']==budget==sum(cp['delta_by_kind'].values()) and cp['delta_by_kind']['savings']==1225 and cp['delta_by_kind']['removal']==0
            mono=a.get('recomputed_cost',math.inf)<=prior+1e-8
            perturb_ok=0<=cp['perturbation_deltas']<=cp['delta_by_kind']['insertion'] and (call['arm']!='none' or cp['perturbations_started']==0) and cp['perturbations_completed']<=cp['perturbations_started']<=cp['perturbations_completed']+1
            row_ok &= a['accepted'] and ca['accepted'] and ledger and mono and perturb_ok and cp['scoreable'];prior=a.get('recomputed_cost',math.inf)
            obs.append({k:call[k] for k in ['run_id','geometry_id','family','demand_mode','search_seed','arm']}|{'budget':budget,'cost':a.get('recomputed_cost'),'current_cost':ca.get('recomputed_cost'),'accepted':a['accepted'],'current_accepted':ca['accepted'],'ledger_ok':ledger,'monotonic':mono,'perturb_accounting_ok':perturb_ok,'iterations_completed':cp['iterations_completed'],'perturbations_started':cp['perturbations_started'],'perturbations_completed':cp['perturbations_completed'],'perturbation_deltas':cp['perturbation_deltas'],'objective_edges':cp['objective_edges'],'matrix_distances':cp['matrix_distances']})
        last_stagnation=0;starts=[];completes=[];pending=None
        for event in row.get('trace',[]):
            if event['event']=='perturbation_start':
                row_ok &= last_stagnation==event['stagnation']==8 and pending is None
                pending=event;starts.append(event)
                a=audit(inst,event['before_current_output']);audits.append({'run_id':call['run_id'],'stage':'perturbation_start_'+str(event['perturbation_id']),**a});row_ok &= a['accepted']
            elif event['event']=='perturbation_complete':
                row_ok &= pending is not None and event['perturbation_id']==pending['perturbation_id'] and event['deltas']>event['deltas_before']==pending['deltas']
                a=audit(inst,event['output']);audits.append({'run_id':call['run_id'],'stage':'perturbation_complete_'+str(event['perturbation_id']),**a});row_ok &= a['accepted']
                if call['arm']=='partial40':
                    selected=set(event['removed']);before=[[x for x in r[1:-1] if x not in selected] for r in pending['before_current_output']['routes']];after=[[x for x in r[1:-1] if x not in selected] for r in event['output']['routes']]
                    row_ok &= len(selected)==20 and [r for r in before if r]==[r for r in after if r]
                ev={k:call[k] for k in ['run_id','geometry_id','family','demand_mode','search_seed','arm']}|{'perturbation_id':event['perturbation_id'],'deltas_before':event['deltas_before'],'deltas_after':event['deltas'],'construction_deltas':event['deltas']-event['deltas_before'],'before_current_cost':event['before_current_cost'],'before_best_cost':event['before_best_cost'],'after_current_cost':event['current_cost'],'current_degradation_percent':100*(event['current_cost']/event['before_current_cost']-1),'best_gap_percent':100*(event['current_cost']/event['before_best_cost']-1),'improved_best':event['best_improved']}
                events.append(ev);completes.append(event);pending=None;last_stagnation=0
            else:
                row_ok &= pending is None and event['q']>=5 and event['q']<=15
                last_stagnation=event['stagnation']
        if pending:
            row_ok &= row['current_output']==pending['before_current_output'] and row['current_cost']==pending['before_current_cost']
        row_ok &= len(starts)==row.get('perturbations_started') and len(completes)==row.get('perturbations_completed')
        if row_ok:valid.add(call['run_id'])
        else:problems.append({'run_id':call['run_id'],'reason':'status_route_ledger_order_trigger_failure'})
        m={k:call[k] for k in ['run_id','geometry_id','family','demand_mode','search_seed','arm']}|{'started':len(starts),'completed':len(completes),'incomplete':len(starts)-len(completes),'perturbation_deltas':row.get('perturbation_deltas'),'first_start_delta':starts[0]['deltas'] if starts else None,'first_complete_delta':None,'budget_used_after_first_completion':None,'first_current_degradation_percent':None,'first_best_gap_percent':None,'best_improvement_since_first_start_percent':None,'best_updates_since_first_start':None,'best_updates_after_first_completion':None,'first_perturbation_improved_best':None,'iterations_after_first_completion':None,'delta_to_first_later_best_improvement':None,'current_recovered_preperturbation_best':None,'delta_to_current_recovery':None}
        if completes:
            e=completes[0];later=[x for x in row['trace'] if x['deltas']>=e['deltas'] and x['event'] in ['iteration','perturbation_complete']]
            improvements=[x for x in later if x.get('best_improved')];recovery=[x for x in later if x['current_cost']<=e['before_best_cost']+1e-9]
            m.update(first_complete_delta=e['deltas'],budget_used_after_first_completion=row['deltas']-e['deltas'],first_current_degradation_percent=100*(e['current_cost']/e['before_current_cost']-1),first_best_gap_percent=100*(e['current_cost']/e['before_best_cost']-1),best_improvement_since_first_start_percent=100*(e['before_best_cost']-row['output']['reported_cost'])/e['before_best_cost'],best_updates_since_first_start=len(improvements),best_updates_after_first_completion=sum(x['deltas']>e['deltas'] for x in improvements),first_perturbation_improved_best=e['best_improved'],iterations_after_first_completion=sum(x['event']=='iteration' for x in later),delta_to_first_later_best_improvement=(improvements[0]['deltas']-e['deltas']) if improvements else None,current_recovered_preperturbation_best=bool(recovery),delta_to_current_recovery=(recovery[0]['deltas']-e['deltas']) if recovery else None)
        mechanisms.append(m)
    allg=sorted(set(c['geometry_id'] for c in schedule));common=[g for g in allg if all(c['run_id'] in valid for c in schedule if c['geometry_id']==g)]
    dump(ROOT/'reports/INDEPENDENT_ROUTE_AUDIT.json',{'implementation':'Standalone coordinate/demand audit imports no solver or checker. Independent implementation self-check; external review still separate. Also checks retained-customer order, exact trigger, and interrupted current preservation.','count':len(audits),'all_passed':all(a['accepted'] for a in audits),'rows':audits})
    dump(ROOT/'reports/FAILURE_COMPLETENESS.json',{'planned':len(schedule),'present':len(rows),'unique_ids':len(by_id),'valid_calls':len(valid),'missing_ids':sorted(set(c['run_id'] for c in schedule)-set(by_id)),'problems':problems,'common_geometry_count':len(common),'excluded_geometries':sorted(set(allg)-set(common)),'retries':0})
    csvout('checkpoint_observations.csv',obs);csvout('perturbation_events.csv',events);csvout('first_perturbation_trajectories.csv',mechanisms)
    groups=collections.defaultdict(list)
    for o in obs:
        if o['geometry_id'] in common:groups[o['geometry_id'],o['family'],o['demand_mode'],o['budget'],o['arm']].append(o['cost'])
    means={k:statistics.mean(v) for k,v in groups.items()};detail=[]
    contrasts=['partial_vs_full','partial_vs_none','full_vs_none']
    for g in common:
        fam=next(c['family'] for c in schedule if c['geometry_id']==g)
        for d in cfg['demand_modes']:
            for b in cfg['checkpoints']:
                n,f,p=[means[g,fam,d,b,a] for a in cfg['arms']]
                for c,v in zip(contrasts,[100*(f-p)/f,100*(n-p)/n,100*(n-f)/n]):detail.append({'geometry_id':g,'family':fam,'demand_mode':d,'budget':b,'contrast':c,'improvement_percent':v})
    csvout('paired_geometry_demand_contrasts.csv',detail);gg=collections.defaultdict(list)
    for r in detail:gg[r['geometry_id'],r['family'],r['budget'],r['contrast']].append(r['improvement_percent'])
    geo=[{'geometry_id':g,'family':f,'budget':b,'contrast':c,'improvement_percent':statistics.mean(v)} for (g,f,b,c),v in gg.items()];csvout('paired_geometry_contrasts.csv',geo)
    rng=random.Random(cfg['bootstrap_seed']);blocks=[[g for g in common if next(c['family'] for c in schedule if c['geometry_id']==g)==f] for f in cfg['families']]
    samples=[[rng.choice(block) for block in blocks for _ in range(len(block))] for _ in range(cfg['bootstrap_replicates'])] if all(blocks) else []
    summary=[];boots=[]
    for b in cfg['checkpoints']:
        for c in contrasts:
            vals={r['geometry_id']:r['improvement_percent'] for r in geo if r['budget']==b and r['contrast']==c};v=list(vals.values())
            if not v:continue
            bs=[statistics.mean(vals[g] for g in sample) for sample in samples]
            summary.append({'budget':b,'contrast':c,'geometry_count':len(v),'mean_percent':statistics.mean(v),'ci_low':percentile(bs,.025),'ci_high':percentile(bs,.975),'wins':sum(x>1e-9 for x in v),'ties':sum(abs(x)<=1e-9 for x in v),'losses':sum(x< -1e-9 for x in v)})
            boots.extend({'budget':b,'contrast':c,'replicate':i,'mean_percent':x} for i,x in enumerate(bs))
    csvout('paired_summary.csv',summary);csvout('bootstrap_means.csv',boots)
    armstats=[]
    for arm in cfg['arms']:
        ms=[m for m in mechanisms if m['arm']==arm and m['geometry_id'] in common];es=[e for e in events if e['arm']==arm and e['geometry_id'] in common];xs=[o for o in obs if o['arm']==arm and o['geometry_id'] in common and o['budget']==cfg['primary_budget']]
        def av(key,source):
            # First average repeated measurements within independent geometry, then equal geometries.
            z=collections.defaultdict(list)
            for x in source:
                if x[key] is not None:z[x['geometry_id']].append(x[key])
            return statistics.mean(statistics.mean(v) for v in z.values()) if z else None
        armstats.append({'arm':arm,'trajectories':len(ms),'triggered_trajectories':sum(m['started']>0 for m in ms),'completed_perturbation_trajectories':sum(m['completed']>0 for m in ms),'total_started':sum(m['started'] for m in ms),'total_completed':sum(m['completed'] for m in ms),'total_incomplete':sum(m['incomplete'] for m in ms),'total_perturbation_deltas':sum(m['perturbation_deltas'] or 0 for m in ms),'perturbation_budget_percent':100*sum(m['perturbation_deltas'] or 0 for m in ms)/(len(ms)*cfg['primary_budget']) if ms else None,'geom_equal_completed_iterations':av('iterations_completed',xs),'geom_equal_event_current_degradation_percent':av('current_degradation_percent',es),'geom_equal_event_best_gap_percent':av('best_gap_percent',es),'geom_equal_first_completion_delta':av('first_complete_delta',ms),'geom_equal_budget_after_first_completion':av('budget_used_after_first_completion',ms),'geom_equal_first_best_gap_percent':av('first_best_gap_percent',ms),'geom_equal_best_improvement_since_first_start_percent':av('best_improvement_since_first_start_percent',ms),'geom_equal_best_updates_since_first_start':av('best_updates_since_first_start',ms),'geom_equal_best_updates_after_first_completion':av('best_updates_after_first_completion',ms),'geom_equal_iterations_after_first_completion':av('iterations_after_first_completion',ms),'trajectories_with_best_improvement_since_first_start':sum((m['best_updates_since_first_start'] or 0)>0 for m in ms),'trajectories_recovered_preperturbation_best':sum(m['current_recovered_preperturbation_best'] is True for m in ms),'geom_equal_recovery_delta_conditional':av('delta_to_current_recovery',ms)})
    csvout('arm_mechanism_summary.csv',armstats)
    frozen=read(ROOT/'freeze/PRE_RUN_FREEZE.json');bad=[p for p,h in frozen['sha256'].items() if hashlib.sha256((ROOT/p).read_bytes()).hexdigest()!=h]
    old=read(ROOT/'freeze/OLD_GEOMETRIES.json');manifest=read(ROOT/'freeze/INPUT_MANIFEST.json');nh=set(e['coordinate_sha256'] for e in manifest)
    dump(ROOT/'reports/FINAL_SELF_CHECK.json',{'frozen_hashes_unchanged':not bad,'mismatches':bad,'unique_new_geometry_hashes':len(nh),'old_geometry_overlap':sorted(nh&set(old['coordinate_hashes'])),'all_planned_calls_valid':len(valid)==len(schedule),'all_16_geometry_common_support':len(common)==16,'external_review':False})
    dump(ROOT/'reports/SUMMARY.json',{'geometry_count':len(common),'planned_geometries':16,'formal_trajectories':len(rows),'valid_trajectories':len(valid),'contrasts':summary,'arms':armstats,'analysis_cpu_seconds':time.process_time()-t,'external_calls':0})
    labels={'partial_vs_full':'局部40%相对全量重建','partial_vs_none':'局部40%相对无扰动','full_vs_none':'全量重建相对无扰动'}
    text=['# CVRP局部40%扰动：三臂固定预算实验','',f'预定16个全新n50几何（uniform/clustered各8），2需求、2搜索seed、3臂；{len(valid)}/192条有效，独立样本为{len(common)}个几何。没有补样或按成绩筛选。','', '## 160k delta结果','']
    for r in summary:
        if r['budget']==160000:text.append(f"- {labels[r['contrast']]}：{r['mean_percent']:.4f}%，95%几何分层bootstrap区间[{r['ci_low']:.4f}%, {r['ci_high']:.4f}%]；{r['wins']}胜/{r['ties']}平/{r['losses']}负。正值代表前者更好。")
    text+=['','主比较为局部40%对全量；其余比较为未校正的次比较。先平均2 seed、算各需求相对差，再等权2需求和16几何；10,000次固定seed分层整geometry bootstrap。40k来自同一轨迹，仅描述。','', '## 预定规则及计费','', '- 三臂普通搜索都用原random ruin + regret2。原q均匀5–15（10%–30%）。唯一新增规则固定20客户（40%），保留30客户（60%）在各原路径内的相对次序，用原regret2重插。不声称40%是最优比例。', '- 触发精确定义是连续8个完整候选未严格改善current，不是8次未改善global best。局部与全量完全一致。完整扰动无条件接收为current、保留global best；中断扰动不提交。旧全量规则保留为随机顺序逐客户最便宜可行插入。', '- savings和所有插入delta同160k总账收费。random removal不计算距离候选delta，因此removal账为0并非漏计。完整目标边求和、矩阵和独立检查另计；这不是等整解目标次数、CPU或FLOP。', '- unlimited homogeneous fleet、容量30、欧氏距离无舍入；不是固定车辆K模型。','', '## 实际机制暴露','']
    for a in armstats:
        text.append(f"- {a['arm']}：{a['triggered_trajectories']}/{a['trajectories']}轨迹触发，开始/完成/中断={a['total_started']}/{a['total_completed']}/{a['total_incomplete']}；扰动delta={a['total_perturbation_deltas']}（总预算{a['perturbation_budget_percent']:.4f}%）。")
        if a['total_completed']:
            text.append(f"  完整事件的geometry等权平均current相对原current劣化{a['geom_equal_event_current_degradation_percent']:.4f}%，相对原best差距{a['geom_equal_event_best_gap_percent']:.4f}%；首次完成后平均剩余且实际用掉{a['geom_equal_budget_after_first_completion']:.1f} delta。首次触发以来best改善{a['geom_equal_best_improvement_since_first_start_percent']:.4f}%，更新{a['geom_equal_best_updates_since_first_start']:.3f}次；{a['trajectories_with_best_improvement_since_first_start']}条有后续best改善，{a['trajectories_recovered_preperturbation_best']}条current曾恢复至扰动前best。")
    text+=['','完整机制逐事件见perturbation_events.csv；首次扰动后预算、改进次数、到首次best改善/恢复的delta逐轨迹见first_perturbation_trajectories.csv。事件和触发条件的统计是描述性，重复扰动及后续路径也会影响结果，不能单独当因果估计。','', '完整重建使用旧顺序cheapest构造，局部使用regret2重插；这是两种固定机制的比较，不是仅改变扰动比例的纯因果消融。', '', '## 检查、范围、资源','', '- 玩具检查覆盖无扰动与旧全量包装器的6项检查点等价、局部保序计费、实际触发、预算途中不提交。独立分析器直接从坐标与需求复算所有baseline、best/current检查点、扰动前后解，另查保序、触发与未完成提交。仅为独立实现自检；父任务另行外部独审。', '- freeze目录包含启动前源码/规则/输入hash、旧几何hash排重、192调用顺序。原包不修改，主运行仅一次。完整失败、退出码、CPU/wall见failures与raw；资源汇总见RESOURCE_ACCOUNTING.json。', '- 只支持此单一40%规则、连续8次current停滞、160k预算、新n50合成uniform/clustered与两需求分布；不推广为其他比例/阈值、真实VRP、固定K、现代强基线或普遍机制结论。', '- 模型/API/付费资源/安装/外传均0。资源未包括父任务独审；主进程<=120CPU/180wall，准备、统计和打包单独记账。', '', '复现需将source复制至新的空目录，建freeze/input/raw/reports/failures后运行source/supervise.py。独占创建会阻止在已产出目录覆盖重跑。']
    (ROOT/'reports/REPORT_ZH.md').write_text('\n'.join(text)+'\n')
    print(json.dumps({'valid':len(valid),'geometries':len(common),'main':[r for r in summary if r['budget']==160000],'arms':armstats,'analysis_cpu_seconds':time.process_time()-t}),flush=True)
if __name__=='__main__':main()
