Solomon100 用户存档候选：可复核的100客户短预算基线

先读 reports/report_zh.txt 和 reports/summary.json。

本轮完整56实例×2预算，不是7节点玩具。每份100客户+仓库。
真实来源是用户已有Google Drive的Solomon命名存档，来源ID在evidence/drive_selected_inputs.json。
SINTEF官方说明已核实，但本轮官方ZIP获取403，作者页也失败。没有官方字节级同一性证明。
不声称从官方成功下载，不声称这些文件绝对等于官方原版。

目标是K上限内总距离单目标，所有客户必须服务。SINTEF BKS是先车数再距离；不算跨口径gap。
112请求、全部结果和失败均保留；每个实例两预算相关。SEARCH限制250ms/1000ms。
固定seed2026100708，OR-Tools9.14.6206，单线程Routing CP，PCI+GLS。
protocol/freeze.json在首个solve之前固化输入manifest、源码、搜索参数、顺序与协议。
source/finalize.py是事后打包脚本，不属于预冻结求解代码。

数据许可边界：未找到明确原实例再分发许可，ZIP不携带inputs/或原ZIP。
请通过你已有授权副本提供数据；或使用获取脚本在官方源可访问时正常获取（错误即停，无规避路线）。
获取脚本要求原字节SHA与本实验相同；若仅换行等差异也会拒绝，不能静默替换冻结输入。
同名官方版本如字节不同，应单独建立新协议，而不是覆盖本实验数据。

在有受支持Python和依赖的机器中复现：
1. 安装source/requirements.lock所列确切版本（本轮实际测试Linux CPython3.12.14）。
2. python source/acquire_inputs.py --local-dir /path/to/your/authorized/instances
3. 保留本包原raw/与reports/以备审计；新运行需移到独立工作副本，勿覆盖本轮原结果。
4. 在该独立副本移走raw/results.jsonl、raw/stdout.log、raw/stderr.log，执行python source/supervise.py。
   不要重做prepare或改源码；run会校验freeze及输入SHA，并拒绝覆盖已有results。
5. python source/analyze.py 重新做连续原坐标、服务、窗、容量、返仓、全服务校验。
6. 短wall预算在不同硬件、Python或负载下不保证逐字复現路线；协议、数据和算法设定固定。

reports/metrics.csv是112行可分析指标；raw/results.jsonl保存未加工OR-Tools状态和路线；
reports/evaluated_results.json保存独立连续检查及每站时间；reports/failures.json保留所有非成功请求；
evidence/package_provenance.json记录复用wheel来源及SHA。没有API调用、购买、Codex或外传研究提示词。
SHA256SUMS.txt覆盖清洁包内所有条目（不含自身）；ZIP旁sha256文件覆盖成品ZIP。
本包仅给既有项目所有者，包含其私有Drive文件ID。不要直接公开私有来源索引。
