import sys,json,csv,math,statistics,hashlib,time,resource,collections
from pathlib import Path
from checker import read_original,check,tests
P=Path(__file__).resolve().parent.parent
def write(p,x):(P/p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def stats(xs):
    return {'n':len(xs),'mean':statistics.mean(xs) if xs else None,'median':statistics.median(xs) if xs else None,'min':min(xs) if xs else None,'max':max(xs) if xs else None}
def main():
    start=time.process_time();resource.setrlimit(resource.RLIMIT_CPU,(10,10))
    freeze=json.loads((P/'protocol/freeze.json').read_text());checks={n:sha(P/n)==h for n,h in freeze['sha256'].items()}
    assert all(checks.values()),[n for n,v in checks.items() if not v]
    requests=json.loads((P/'protocol/requests.json').read_text());rows=[]
    rawlist=[json.loads(l) for l in (P/'raw/results.jsonl').read_text().splitlines()] if (P/'raw/results.jsonl').exists() else []
    raw={r['run_id']:r for r in rawlist};assert len(raw)==len(rawlist)
    manifests={r['name']:r for r in json.loads((P/'protocol/input_manifest.json').read_text())}
    write('evidence/checker_tests.json',{'passed':True,'cases':tests()})
    for req in requests:
        r=raw.get(req['run_id'],{**req,'outcome':'NOT_RUN_BUDGET','assignment_returned':False,'routes':None})
        if r.get('routes') is not None:
            file=P/'inputs'/f"{r['instance']}.txt";assert sha(file)==manifests[file.name]['sha256']
            audit=check(read_original(file),r['routes'])
            r['continuous_check']=audit;r['outcome']='SUCCESS' if audit['valid'] else 'FAIL'
            r['original_distance']=audit['distance'];r['vehicles_used']=audit['vehicles_used']
            bound=(100+audit['vehicles_used'])*0.5/1e6
            r['encoding_cost_error']=r['objective_integer']/1e6-audit['distance'];r['encoding_cost_error_bound']=bound
            assert abs(r['encoding_cost_error'])<=bound+1e-9
        rows.append(r)
    write('reports/evaluated_results.json',rows)
    with (P/'reports/metrics.csv').open('w') as f:
        fields=['run_id','instance','family','budget_ms','outcome','ortools_status_name','vehicles_used','original_distance','solve_wall_s','solve_cpu_s','model_wall_s','total_wall_s','total_cpu_s','encoding_cost_error']
        w=csv.DictWriter(f,fields,extrasaction='ignore');w.writeheader();w.writerows(rows)
    groups=[]
    for ms in [250,1000]:
        for fam in ['ALL','C1','C2','R1','R2','RC1','RC2']:
            rr=[r for r in rows if r['budget_ms']==ms and (fam=='ALL' or r['family']==fam)];good=[r for r in rr if r['outcome']=='SUCCESS']
            groups.append({'budget_ms':ms,'family':fam,'attempted':len(rr),'success':len(good),'success_rate':len(good)/len(rr),'outcomes':dict(collections.Counter(r['outcome'] for r in rr)),'vehicles':stats([r['vehicles_used'] for r in good]),'distance':stats([r['original_distance'] for r in good]),'solve_wall_s':stats([r['solve_wall_s'] for r in rr if 'solve_wall_s'in r]),'solve_cpu_s':stats([r['solve_cpu_s'] for r in rr if 'solve_cpu_s'in r])})
    by={(r['instance'],r['budget_ms']):r for r in rows};pairs=[]
    for name in sorted({r['instance'] for r in rows}):
        a=by[name,250];b=by[name,1000];p={'instance':name,'250ms':a['outcome'],'1000ms':b['outcome'],'paired_complete':a['outcome']==b['outcome']=='SUCCESS'}
        if p['paired_complete']:p.update(distance_delta_1000_minus_250=b['original_distance']-a['original_distance'],vehicle_delta_1000_minus_250=b['vehicles_used']-a['vehicles_used'])
        pairs.append(p)
    pp=[p for p in pairs if p['paired_complete']]
    summary={'source_label':'User-archived Solomon100 candidates; official byte identity unverified','objective_label':'Fixed vehicle upper bound, single distance objective; no lexicographic BKS gaps','unique_instances':56,'paired_requests':112,'groups':groups,'pair_analysis':{'n_complete_pairs':len(pp),'distance_improved':sum(p['distance_delta_1000_minus_250']< -1e-9 for p in pp),'distance_same':sum(abs(p['distance_delta_1000_minus_250'])<=1e-9 for p in pp),'distance_worse':sum(p['distance_delta_1000_minus_250']>1e-9 for p in pp),'delta':stats([p['distance_delta_1000_minus_250'] for p in pp])},'all_results_retained':len(rows)==112,'no_paid_api_calls':True,'bks_gap_computed':False}
    write('reports/summary.json',summary);write('reports/paired_budget_results.json',pairs)
    write('reports/failures.json',[r for r in rows if r['outcome']!='SUCCESS'])
    write('evidence/verification.json',{'frozen_files_unchanged':checks,'all_frozen_files_unchanged':all(checks.values()),'request_count':len(requests),'raw_count':len(rawlist),'complete_result_count':len(rows),'checker_passed_count':sum(r['outcome']=='SUCCESS' for r in rows),'checker_rejected_count':sum(r.get('continuous_check',{}).get('valid') is False for r in rows),'all_cost_error_bounds_passed':True,'audit_cpu_s':time.process_time()-start})
    lines=['Solomon100 用户存档候选基准：固定车辆上限、单目标距离','',
      '范围：56份实例，每份100客户+1仓库，覆盖C1/C2/R1/R2/RC1/RC2；每份250ms与1000ms各一次，共112条冻结请求。',
      '来源：用户已拥有的URP/Resources/Solomon/instances/In。官方SINTEF备份ZIP返回403，作者页也不可取；未绕过。文件结构、101节点、整型常量、车辆上限、容量与窗已全量校验并记SHA256，但没有证明与官方原始字节完全一致。',
      '口径：官方SINTEF先最少车辆、再双精度欧氏距离。本实验是文件车辆上限内的总距离单目标，所有客户必须服务。因此不计算或暗示对官方BKS的gap、最优性或算法优越性。',
      '模型：OR-Tools9.14.6206；PCI初始解+GLS(lambda0.1)，seed2026100708；单线程CP，关闭CP-SAT及fallback；同实例两档新建模型、无warmstart，无试跑和按结果调参。',
      '精度：时间向上取整×1e6，路长成本最近整数×1e6；整型坐标用isqrt精确量化。连续原坐标独立重放容量、服务时间、开始服务窗、等待、返仓、全覆盖；1e-9容差。保守时间量化会排除部分连续边界解；成本误差<=每边0.5e-6。',
      '', '结果（距离/车辆均值仅在成功返回并独立校验通过的实例内）：']
    for g in groups:
        vv=g['vehicles']['mean'];dd=g['distance']['mean'];tt=g['solve_wall_s']['mean']
        lines.append(f"{g['budget_ms']}ms {g['family']}: {g['success']}/{g['attempted']} 成功；车辆均值{vv if vv is None else round(vv,3)}；距离均值{dd if dd is None else round(dd,3)}；求解wall均值{tt if tt is None else round(tt,6)}秒；状态{g['outcomes']}")
    lines+=['',f"配对统计：完整成功对{len(pp)}/56；1000ms距离改善{summary['pair_analysis']['distance_improved']}、持平{summary['pair_analysis']['distance_same']}、变差{summary['pair_analysis']['distance_worse']}。两档相关，不作为112个独立样本。不做显著性检验。",'状态含义：SUCCESS有独立校验通过的全服务解；TIMEOUT为未返回解且工具明确超时；UNKNOWN表示未找到，不能叫无解；FAIL表示异常/不合法模型/校验失败。全部失败与未完成均留在结果中。',
      '短预算在共享云端按wall计时，调度和调用开销会影响搜索轨迹。报告不等于严格跨硬件性能结论。零付费/模型API调用；复用已有官方PyPI安装，不新增软件/模型，不用Codex。',
      '交付包：源码、冻结协议、输入哈希与Drive来源、112次raw和评估、失败、环境版本、费用/资源与校验。原输入再分发许可未明确，清洁ZIP不含56份原文件，仅提供获取/复现脚本和引用；没有更改用户Drive源文件。',
      '', '来源：','https://www.sintef.no/projectweb/top/vrptw/100-customers/','https://www.sintef.no/projectweb/top/vrptw/solomon-benchmark/','https://www.sintef.no/projectweb/top/vrptw/documentation2/','https://developers.google.com/optimization/routing/routing_options','https://developers.google.com/optimization/routing/vrptw']
    (P/'reports/report_zh.txt').write_text('\n'.join(lines)+'\n');print(json.dumps(summary,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
