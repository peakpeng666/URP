import subprocess,sys,time,resource,json
from pathlib import Path
P=Path(__file__).resolve().parent.parent
start=time.perf_counter();u0=resource.getrusage(resource.RUSAGE_CHILDREN)
def limit():resource.setrlimit(resource.RLIMIT_CPU,(150,150))
with (P/'raw/stdout.log').open('x') as out,(P/'raw/stderr.log').open('x') as err:
    p=subprocess.Popen([sys.executable,str(P/'source/benchmark.py'),'run'],stdout=out,stderr=err,preexec_fn=limit)
    resource.setrlimit(resource.RLIMIT_CPU,(5,5))
    try:rc=p.wait(timeout=240);timeout=False
    except subprocess.TimeoutExpired:p.kill();rc=p.wait();timeout=True
u=resource.getrusage(resource.RUSAGE_CHILDREN)
(P/'raw/supervisor_resource.json').write_text(json.dumps({'exit_code':rc,'wall_timeout':timeout,'wall_s':time.perf_counter()-start,'child_cpu_s':u.ru_utime+u.ru_stime-u0.ru_utime-u0.ru_stime,'child_cpu_cap_s':150,'supervisor_cpu_cap_s':5,'maxrss_kib':u.ru_maxrss},indent=2)+'\n')
print((P/'raw/supervisor_resource.json').read_text())
