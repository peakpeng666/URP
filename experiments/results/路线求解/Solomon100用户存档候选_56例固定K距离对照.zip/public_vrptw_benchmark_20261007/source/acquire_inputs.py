"""Supply existing authorized copies or download official public archive when accessible.
No cookies, proxies, retry-evasion, alternate hosts, or authentication. Stop on HTTP errors.
Raw data is deliberately absent from this delivery ZIP. Before redistribution check rights.
Usage: python source/acquire_inputs.py --local-dir /path/to/owned/instances
       python source/acquire_inputs.py --official-public-download
Exact bytes must match this experiment's manifest before its frozen run can be replayed.
"""
import argparse,urllib.request,zipfile,io,hashlib,json,shutil
from pathlib import Path
P=Path(__file__).resolve().parent.parent
URL='https://www.sintef.no/globalassets/project/top/vrptw/solomon/solomon-100.zip'
def main():
    p=argparse.ArgumentParser();g=p.add_mutually_exclusive_group(required=True);g.add_argument('--local-dir',type=Path);g.add_argument('--official-public-download',action='store_true');a=p.parse_args()
    wanted={r['name']:r for r in json.loads((P/'protocol/input_manifest.json').read_text())};data={}
    if a.local_dir:
        for name in wanted:data[name]=(a.local_dir/name).read_bytes()
    else:
        try:
            with urllib.request.urlopen(URL,timeout=30) as r:body=r.read(10_000_000)
        except Exception as e:raise SystemExit(f'Official source unavailable; stop without alternate download route: {e}')
        with zipfile.ZipFile(io.BytesIO(body)) as z:
            for info in z.infolist():
                name=Path(info.filename).name.lower()
                if name in wanted:
                    if name in data:raise SystemExit('Duplicate basename in archive')
                    data[name]=z.read(info)
    errors=[]
    for name,m in wanted.items():
        if name not in data:errors.append(f'{name}: missing')
        elif hashlib.sha256(data[name]).hexdigest()!=m['sha256']:errors.append(f'{name}: bytes differ from pinned user archive. Do not silently change a frozen input.')
    if errors:raise SystemExit('\n'.join(errors))
    (P/'inputs').mkdir(exist_ok=True)
    for name,b in data.items():(P/'inputs'/name).write_bytes(b)
    print('All56 exact SHA256 matches materialized locally. No source file modified.')
if __name__=='__main__':main()
