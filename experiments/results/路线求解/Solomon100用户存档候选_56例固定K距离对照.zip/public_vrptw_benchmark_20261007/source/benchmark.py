"""One-pass, pre-frozen user-archived Solomon-candidate benchmark. No network in run."""
import os
os.environ['OMP_NUM_THREADS']='1'
import sys,json,math,time,hashlib,re,platform,importlib.metadata,traceback,resource
from pathlib import Path
from datetime import datetime,timezone
from ortools.constraint_solver import pywrapcp,routing_enums_pb2
from ortools.util import optional_boolean_pb2
from google.protobuf import text_format
P=Path(__file__).resolve().parent.parent
SCALE=1_000_000
SEED=2026100708
BUDGETS=[250,1000]
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value): (P/path).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def parse(path):
    lines=path.read_text().splitlines();name=lines[0].strip().lower()
    assert name==path.stem.lower(),(name,path.name)
    vindex=next(i for i,l in enumerate(lines) if l.strip()=='VEHICLE')
    k,q=map(int,lines[vindex+2].split())
    nodes=[]
    for line in lines:
        toks=line.split()
        if len(toks)==7 and all(re.fullmatch(r'-?\d+',t) for t in toks):
            vals=list(map(int,toks));nodes.append(dict(zip(['id','x','y','demand','ready','due','service'],vals)))
    assert len(nodes)==101 and [x['id'] for x in nodes]==list(range(101)),name
    assert k>0 and q>0 and nodes[0]['demand']==0 and nodes[0]['ready']==0 and nodes[0]['service']==0
    assert all(0<=x['ready']<=x['due'] and x['service']>=0 and 0<=x['demand']<=q for x in nodes)
    return {'id':name,'family':re.match(r'(rc|r|c)[12]',name).group(0).upper(),'vehicles':k,'capacity':q,'nodes':nodes}
def params(ms):
    p=pywrapcp.DefaultRoutingSearchParameters()
    p.first_solution_strategy=routing_enums_pb2.FirstSolutionStrategy.PARALLEL_CHEAPEST_INSERTION
    p.local_search_metaheuristic=routing_enums_pb2.LocalSearchMetaheuristic.GUIDED_LOCAL_SEARCH
    p.guided_local_search_lambda_coefficient=0.1
    p.time_limit.FromMilliseconds(ms);p.lns_time_limit.FromMilliseconds(100)
    p.use_cp=optional_boolean_pb2.BOOL_TRUE;p.use_cp_sat=optional_boolean_pb2.BOOL_FALSE
    p.use_generalized_cp_sat=optional_boolean_pb2.BOOL_FALSE;p.fallback_to_cp_sat_size_threshold=0
    p.sat_parameters.num_search_workers=1;p.sat_parameters.random_seed=SEED;p.log_search=False
    return p
def encode(d):
    nodes=d['nodes'];cost=[];travel=[]
    for a in nodes:
        c=[];t=[]
        for b in nodes:
            z=((a['x']-b['x'])**2+(a['y']-b['y'])**2)*SCALE*SCALE
            s=math.isqrt(z);c.append(s+int(4*z>=(2*s+1)**2));t.append(s+int(s*s<z))
        cost.append(c);travel.append(t)
    return cost,travel

def prepare():
    assert not (P/'protocol/freeze.json').exists(),'Prior freeze exists'
    files=sorted((P/'inputs').glob('*.txt'))
    expected=[f'{f}{t}{i:02}' for f,t,n in [('c',1,9),('c',2,8),('r',1,12),('r',2,11),('rc',1,8),('rc',2,8)] for i in range(1,n+1)]
    assert sorted(x.stem for x in files)==sorted(expected)
    manifest=[]
    for f in files:
        d=parse(f);c,t=encode(d)
        encoded={'cost_nearest':c,'travel_ceil':t,'service_exact':[x['service']*SCALE for x in d['nodes']]}
        canonical=json.dumps(d,sort_keys=True,separators=(',',':')).encode()
        manifest.append({'name':f.name,'sha256':sha(f),'bytes':f.stat().st_size,'semantic_sha256':hashlib.sha256(canonical).hexdigest(),'encoded_sha256':hashlib.sha256(json.dumps(encoded,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'family':d['family'],'n_customers':100,'vehicle_limit':d['vehicles'],'capacity':d['capacity'],'depot_due':d['nodes'][0]['due'],'all_constants_integer':True})
    write('protocol/input_manifest.json',manifest)
    requests=[]
    for i,f in enumerate(files):
        for ms in (BUDGETS if i%2==0 else list(reversed(BUDGETS))):
            requests.append({'sequence':len(requests),'instance':f.stem,'family':manifest[i]['family'],'budget_ms':ms,'seed':SEED,'run_id':f'{f.stem}__{ms}ms'})
    write('protocol/requests.json',requests)
    for ms in BUDGETS:(P/f'protocol/parameters_{ms}ms.textproto').write_text(str(params(ms)))
    env={'python':sys.version,'python_executable':sys.executable,'platform':platform.platform(),'machine':platform.machine(),'ortools':importlib.metadata.version('ortools'),'logical_cpus':os.cpu_count(),'execution':'dot cloud Linux, single Routing CP solver thread','packages':sorted([{'name':x.metadata['Name'],'version':x.version} for x in importlib.metadata.distributions()],key=lambda x:x['name'].lower())}
    write('evidence/environment.json',env)
    (P/'source/requirements.lock').write_text('\n'.join(f"{x['name']}=={x['version']}" for x in env['packages'] if x['name'].lower()!='pip')+'\n')
    protocol={
      'study_id':'ARCHIVED_SOLOMON100_DISTANCE_ONLY_FIXED_V1',
      'dataset':'All 56 files in user-owned URP/Resources/Solomon/instances/In. 100 customers plus depot each. No result-based filtering. Candidates structurally consistent with Solomon; official byte identity is unverified.',
      'provenance':'SINTEF official model and 56 names verified; official backup ZIP web fetch returned 403; author page retrieval failed. Inputs instead materialized from already-owned Google Drive files; source files unchanged. SHA256 pins these user-archive bytes only.',
      'objective':'Minimize total rounded arc distance with vehicle count bounded by file K. Mandatory all100 customers; no AddDisjunction, no dropping, no vehicle fixed cost, no span penalty. This is deliberately a distance-only baseline, not SINTEF hierarchical vehicles-first optimization. No BKS gaps.',
      'original_semantics':'Euclidean distance equals travel time; service start must lie inside inclusive ready/due window; waiting allowed; capacity bound Q per vehicle; all nonempty routes start and return to depot within its window. Depot earliest0 and service0 verified.',
      'integer_encoding':{'scale':SCALE,'all_constants':'All file constants checked integral. Coordinates remain exact integers. Demand/capacity unscaled integers. Ready/due/service multiply exactly by1e6.',
        'distance_cost':'Nearest integer of Euclidean length*S, midpoint ties upward; math.isqrt plus exact integer midpoint comparison. Per arc absolute error<=0.5/S.',
        'travel_time':'Ceil(Euclidean length*S), exact integer isqrt. Add exact service at arc origin. Per arc conservative excess<1/S.',
        'error_bound':'For nonempty routes serving100 total, total arcs=100+vehicles_used<=100+K, so total cost error<=0.5*(100+K)/S. For any one route, cumulative travel excess<101/S=0.000101 original time units. Earliest waiting cannot amplify this bound. Conservative time encoding may exclude boundary-feasible continuous routes. Independent continuous replay tolerance1e-9.',
        'no_infeasibility_claim':'Even solver proof on rounded/conservative model does not prove continuous original infeasible.'},
      'solver':'OR-Tools9.14.6206 RoutingModel CP; PARALLEL_CHEAPEST_INSERTION + GUIDED_LOCAL_SEARCH lambda0.1. Fixed full textproto saved. CP-SAT and fallback disabled; no warmstart, no BKS route input.',
      'seed':SEED,'budgets_ms':BUDGETS,'order':'Alphabetical filename order; even index250 then1000ms, odd1000 then250ms. Same instance pair, fresh models. One pass only, zero pilot solves, no tuning on outcomes.',
      'budget':'Per-call wall-clock search cap250/1000ms; model building and extraction separately timed. Search requested total70 seconds. Entire benchmark child has hard RLIMIT_CPU150s; supervisor5s; prepare plus audit and packaging each capped to keep total<180CPU seconds. Shared cloud wall-clock noise remains; no repeated seeds/statistical independence claim.',
      'outcomes':'SUCCESS only returned assignment passing independent continuous replay. UNKNOWN for no assignment unless OR-Tools explicit timeout. FAIL for exceptions, invalid model, or checker rejection. TIMEOUT for explicit timeout with no assignment; NOT_RUN_BUDGET for missing records after process cap. No found solution is called infeasible.',
      'analysis':'Report all112 requests, six families, all failures, used vehicles, original float distance, full-service feasibility, process/solver wall andCPU time. Compare budgets paired by56 instances only. No significance tests, no BKS gaps, no optimality/universal performance claims.',
      'data_distribution':'No explicit upstream data redistribution license found on inspected official pages. Conservatively exclude all raw inputs from clean ZIP; provide source references, private archive file IDs, hashes, acquisition and verification scripts. This is a permission precaution, not a legal ruling.',
      'costs':'No paid/model API, no new installation, no Codex task. Reuse installed official PyPI OR-Tools wheel.'}
    write('protocol/protocol.json',protocol)
    names=[str(x.relative_to(P)) for x in sorted((P/'source').glob('*')) if x.is_file()]+[str(x.relative_to(P)) for x in sorted((P/'protocol').glob('*')) if x.is_file()]+['evidence/environment.json','evidence/source_notes.json','evidence/package_provenance.json']
    write('protocol/freeze.json',{'frozen_at_utc':datetime.now(timezone.utc).isoformat(),'solver_calls_before_freeze':0,'inputs_included':56,'requests':112,'sha256':{name:sha(P/name) for name in names}})
    print('Frozen all56 inputs/112 requests; zero prior solver calls.',flush=True)

def solve(d,req):
    t0=time.perf_counter();c0=time.process_time();cost,travel=encode(d);n=len(d['nodes']);k=d['vehicles']
    manager=pywrapcp.RoutingIndexManager(n,k,0);routing=pywrapcp.RoutingModel(manager);routing.solver().ReSeed(SEED)
    def c(a,b):return cost[manager.IndexToNode(a)][manager.IndexToNode(b)]
    def t(a,b):
        i=manager.IndexToNode(a);j=manager.IndexToNode(b)
        return travel[i][j]+d['nodes'][i]['service']*SCALE
    def q(a):return d['nodes'][manager.IndexToNode(a)]['demand']
    routing.SetArcCostEvaluatorOfAllVehicles(routing.RegisterTransitCallback(c))
    routing.AddDimensionWithVehicleCapacity(routing.RegisterUnaryTransitCallback(q),0,[d['capacity']]*k,True,'Capacity')
    horizon=d['nodes'][0]['due']*SCALE
    routing.AddDimension(routing.RegisterTransitCallback(t),horizon,horizon,True,'Time');td=routing.GetDimensionOrDie('Time')
    for node in d['nodes'][1:]:td.CumulVar(manager.NodeToIndex(node['id'])).SetRange(node['ready']*SCALE,node['due']*SCALE)
    for v in range(k):td.CumulVar(routing.Start(v)).SetValue(0);td.CumulVar(routing.End(v)).SetRange(0,horizon)
    p=pywrapcp.DefaultRoutingSearchParameters();p.Clear();text_format.Parse((P/f"protocol/parameters_{req['budget_ms']}ms.textproto").read_text(),p)
    first=[];ts=time.perf_counter();cs=time.process_time()
    def callback():
        if not first:first.append({'wall_s':time.perf_counter()-ts,'cpu_s':time.process_time()-cs,'objective':routing.CostVar().Value()})
    routing.AddAtSolutionCallback(callback);sol=routing.SolveWithParameters(p);sw=time.perf_counter()-ts;sc=time.process_time()-cs
    status=routing.status();out={**req,'assignment_returned':sol is not None,'ortools_status':status,'ortools_status_name':routing_enums_pb2.RoutingSearchStatus.Value.Name(status),'solve_wall_s':sw,'solve_cpu_s':sc,'model_wall_s':ts-t0,'model_cpu_s':cs-c0,'first_solution':first[0] if first else None,'routes':None,'objective_integer':None,'outcome':'TIMEOUT' if status==4 else ('FAIL' if status==5 else 'UNKNOWN')}
    if sol is not None:
        routes=[]
        for v in range(k):
            idx=routing.Start(v);route=[0];cumul=[]
            while not routing.IsEnd(idx):
                idx=sol.Value(routing.NextVar(idx));node=manager.IndexToNode(idx);route.append(node)
                cv=td.CumulVar(idx);cumul.append({'node':node,'min':sol.Min(cv),'max':sol.Max(cv)})
            if len(route)>2:routes.append({'vehicle':v,'nodes':route,'encoded_cumul_ranges':cumul})
        out.update(routes=routes,vehicles_used=len(routes),objective_integer=sol.ObjectiveValue(),outcome='ASSIGNMENT_UNCHECKED')
    out.update(total_wall_s=time.perf_counter()-t0,total_cpu_s=time.process_time()-c0)
    return out

def run():
    freeze=json.loads((P/'protocol/freeze.json').read_text())
    for name,digest in freeze['sha256'].items():assert sha(P/name)==digest,name
    assert importlib.metadata.version('ortools')=='9.14.6206'
    for m in json.loads((P/'protocol/input_manifest.json').read_text()):assert sha(P/'inputs'/m['name'])==m['sha256']
    requests=json.loads((P/'protocol/requests.json').read_text());t0=time.perf_counter();c0=time.process_time()
    with (P/'raw/results.jsonl').open('x') as f:
        for req in requests:
            try:r=solve(parse(P/'inputs'/f"{req['instance']}.txt"),req)
            except Exception as ex:r={**req,'outcome':'FAIL','assignment_returned':False,'routes':None,'error':repr(ex),'traceback':traceback.format_exc()}
            f.write(json.dumps(r)+'\n');f.flush();print(req['run_id'],r['outcome'],r.get('vehicles_used'),flush=True)
    write('raw/runner_resource.json',{'wall_s':time.perf_counter()-t0,'cpu_s':time.process_time()-c0,'maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'requests_completed':len(requests)})
if __name__=='__main__':{'prepare':prepare,'run':run}[sys.argv[1]]()
