"""Post-run packaging only; not part of frozen solver or evaluation implementation."""
import json,time,hashlib,zipfile,resource,re
from pathlib import Path
P=Path(__file__).resolve().parent.parent
start=time.process_time();resource.setrlimit(resource.RLIMIT_CPU,(5,5))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
s=json.loads((P/'reports/summary.json').read_text());v=json.loads((P/'evidence/verification.json').read_text());run=json.loads((P/'raw/supervisor_resource.json').read_text());prep=json.loads((P/'evidence/prepare_resource.json').read_text())
assert v['all_frozen_files_unchanged'] and v['complete_result_count']==112
assert run['child_cpu_s']<150
resource_report={'paid_model_api_calls':0,'new_paid_purchases':0,'new_software_installations':0,'codex_tasks':0,'provider':'preexisting OR-Tools official PyPI installation in dot cloud','measured_benchmark_child_cpu_s':run['child_cpu_s'],'measured_preparation_cpu_s':prep['cpu_s'],'measured_analysis_cpu_s':v['audit_cpu_s'],'measured_accounted_subtotal_cpu_s':run['child_cpu_s']+prep['cpu_s']+v['audit_cpu_s'],'hard_limits_seconds':{'benchmark_child':150,'supervisor':5,'prepare':5,'analysis':10,'reserved_independent_verification':5,'packaging':5},'sum_hard_limits_cpu_s':180,'measurement_boundary':'Experimental local process CPU only. Connector/provider/web service CPU is not observable. Benchmark child measurement includes interpreter/model/search/extraction; search wall limits are not CPU budgets.','billing_boundary':'No paid/model API called or new purchase made. Platform subscription/infrastructure cost not exposed; do not interpret this as a universal zero-infrastructure-cost claim.'}
(P/'evidence/resource_accounting.json').write_text(json.dumps(resource_report,ensure_ascii=False,indent=2)+'\n')
readme='''Solomon100 用户存档候选：可复核的100客户短预算基线

先读 reports/report_zh.txt 和 reports/summary.json。

本轮完整56实例×2预算，不是7节点玩具。每份100客户+仓库。
真实来源是用户已有Google Drive的Solomon命名存档，来源ID在evidence/drive_selected_inputs.json。
SINTEF官方说明已核实，但本轮官方ZIP获取403，作者页也失败。没有官方字节级同一性证明。
不声称从官方成功下载，不声称这些文件绝对等于官方原版。

目标是K上限内总距离单目标，所有客户必须服务。SINTEF BKS是先车数再距离；不算跨口径gap。
112请求、全部结果和失败均保留；每个实例两预算相关。SEARCH限制250ms/1000ms。
固定seed2026100708，OR-Tools9.14.6206，单线程Routing CP，PCI+GLS。
protocol/freeze.json在首个solve之前固化输入manifest、源码、搜索参数、顺序与协议。
source/finalize.py是事后打包脚本，不属于预冻结求解代码。

数据许可边界：未找到明确原实例再分发许可，ZIP不携带inputs/或原ZIP。
请通过你已有授权副本提供数据；或使用获取脚本在官方源可访问时正常获取（错误即停，无规避路线）。
获取脚本要求原字节SHA与本实验相同；若仅换行等差异也会拒绝，不能静默替换冻结输入。
同名官方版本如字节不同，应单独建立新协议，而不是覆盖本实验数据。

在有受支持Python和依赖的机器中复现：
1. 安装source/requirements.lock所列确切版本（本轮实际测试Linux CPython3.12.14）。
2. python source/acquire_inputs.py --local-dir /path/to/your/authorized/instances
3. 保留本包原raw/与reports/以备审计；新运行需移到独立工作副本，勿覆盖本轮原结果。
4. 在该独立副本移走raw/results.jsonl、raw/stdout.log、raw/stderr.log，执行python source/supervise.py。
   不要重做prepare或改源码；run会校验freeze及输入SHA，并拒绝覆盖已有results。
5. python source/analyze.py 重新做连续原坐标、服务、窗、容量、返仓、全服务校验。
6. 短wall预算在不同硬件、Python或负载下不保证逐字复現路线；协议、数据和算法设定固定。

reports/metrics.csv是112行可分析指标；raw/results.jsonl保存未加工OR-Tools状态和路线；
reports/evaluated_results.json保存独立连续检查及每站时间；reports/failures.json保留所有非成功请求；
evidence/package_provenance.json记录复用wheel来源及SHA。没有API调用、购买、Codex或外传研究提示词。
SHA256SUMS.txt覆盖清洁包内所有条目（不含自身）；ZIP旁sha256文件覆盖成品ZIP。
本包仅给既有项目所有者，包含其私有Drive文件ID。不要直接公开私有来源索引。
'''
(P/'README_zh.txt').write_text(readme)
# Strict allowlist: no raw input data, venv, caches, source ZIPs, credentials, or temporary downloads.
allowed=[]
for folder in ['source','protocol','raw','reports','evidence']:
    for p in sorted((P/folder).rglob('*')):
        if not p.is_file() or '__pycache__' in p.parts or p.suffix in ['.pyc','.html']:continue
        allowed.append(p)
allowed.append(P/'README_zh.txt')
for p in allowed:
    raw=p.read_bytes()
    if re.search(rb'(?:skoid=[0-9a-f-]{24}|sktid=[0-9a-f-]{24}|[?&]sig=[A-Za-z0-9%/+]{20}|BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----|sk-[A-Za-z0-9]{25})',raw):raise RuntimeError('Potential secret in '+str(p))
manifest={str(p.relative_to(P)):sha(p) for p in sorted(allowed)}
(P/'SHA256SUMS.txt').write_text(''.join(f'{h}  {n}\n' for n,h in manifest.items()))
allowed.append(P/'SHA256SUMS.txt')
zpath=P.parent/(P.name+'.zip')
with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(allowed):
        i=zipfile.ZipInfo(P.name+'/'+str(p.relative_to(P)),date_time=(2026,10,7,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o644<<16
        z.writestr(i,p.read_bytes())
with zipfile.ZipFile(zpath) as z:
    assert z.testzip() is None
    assert not any('/inputs/' in n or '/.venv/' in n or '__pycache__'in n for n in z.namelist())
    for n,h in manifest.items():assert hashlib.sha256(z.read(P.name+'/'+n)).hexdigest()==h
receipt={'zip':str(zpath),'zip_bytes':zpath.stat().st_size,'zip_sha256':sha(zpath),'entries':len(allowed),'raw_input_files_in_zip':0,'zip_crc_and_sha_verified':True,'packaging_cpu_s':time.process_time()-start,'accounted_cpu_s_including_packaging':resource_report['measured_accounted_subtotal_cpu_s']+time.process_time()-start,'no_upload_performed':True}
(P.parent/(P.name+'.zip.sha256')).write_text(f"{receipt['zip_sha256']}  {zpath.name}\n")
(P/'delivery_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
