from pathlib import Path
import json,hashlib,shutil,datetime,ast
R=Path('/workspace/shared/public_route_fleet_budget_interaction_20261009');F=R.parent/'public_route_fleet_constraint_effects_20261009';S=R.parent/'public_route_fixed_iterations_repro_20261009';X=R.parent/'public_route_larger_X_20261009'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):
 with p.open('x')as f:json.dump(x,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
for n in ['common.py','worker.py','run_once.py','execute_and_seal.py','package.py','synthetic_fault_worker.py','test_process_cleanup.py']:
 shutil.copyfile(F/'source'/n,R/'source'/n)
for p in (F/'independent_review').glob('*.py'):shutil.copyfile(p,R/'independent_review'/p.name)
for n in ['RUNTIME.json','DEFAULT_SOLVE_PARAMS.json','DETERMINISM_SETTINGS.json','RESTORE_MANIFEST.json','WHEELS.json','REUSED_WHEEL_ARCHIVE_RECEIPT.json','requirements.lock']:
 shutil.copyfile(F/'environment'/n,R/'environment'/n)
shutil.copyfile(S/'environment/OFFICIAL_SOURCE_AUDIT.json',R/'environment/OFFICIAL_SOURCE_AUDIT.json')
for p in (S/'evidence').glob('pyvrp0140_*.py'):shutil.copyfile(p,R/'evidence'/p.name)
shutil.copyfile(X/'provenance/ACQUISITION.jsonl',R/'evidence/ORIGINAL_ACQUISITION.jsonl')
for n in ['K_REF_VALIDATION.json','BASELINE_A.json']:shutil.copyfile(F/'freeze'/n,R/'evidence'/('HISTORICAL_'+n))
tasks=json.loads((F/'freeze/TASKS.json').read_text());pairs=json.loads((F/'reports/PAIRED_RESULTS.json').read_text());newtasks=[];hist=[];sched=[]
for t in tasks:
 iid=t['instance_id'];standard=json.loads((S/'input'/f'{iid}.json').read_text());capped=json.loads((F/'input'/f'{iid}.json').read_text());assert all(standard[k]==capped[k]for k in ('coordinates','demands','capacity'));assert standard['K']==len(standard['demands'])-1 and capped['K']==t['K'];newtasks.append({**t,'K_ref':t['K'],'standard_K':standard['K']});shutil.copyfile(S/'input'/f'{iid}.json',R/'input'/f'{iid}.json');shutil.copyfile(S/'input'/f'{iid}.vrp',R/'input'/f'{iid}.vrp');shutil.copyfile(F/'references'/f'{iid}.sol',R/'references'/f'{iid}.sol')
 for seed in [0,1,2]:
  p=next(p for p in pairs if p['instance_id']==iid and p['seed']==seed)
  for arm,label,d,cid in [('standard_n_clients','standard25',S,p['control']['call_id']),('at_most_K_ref','capped25',F,p['treatment']['call_id'])]:
   old=d/'raw/calls'/f'{cid}.stdout';dst=R/'history'/label/old.name;shutil.copyfile(old,dst);a=json.loads(old.read_text());assert a['seed']==seed and a['max_iterations']==25
   prior=p['control' if arm=='standard_n_clients'else'treatment'];hist.append({'instance_id':iid,'selection_slot':t['selection_slot'],'seed':seed,'arm':arm,'budget':25,'K':standard['K']if arm=='standard_n_clients'else t['K'],'call_id':cid,'output_file':str(dst.relative_to(R)),'stdout_sha256':sha(dst),'source_stdout':str(old),'prior_audited_status':prior['status'],'prior_valid_feasible':prior['valid_feasible'],'prior_cost':prior['cost'],'prior_vehicles':prior['vehicles'],'prior_evidence_file':str(F/'reports/PAIRED_RESULTS.json'),'prior_evidence_sha256':sha(F/'reports/PAIRED_RESULTS.json')})
  pi=(t['selection_slot']-1)*3+seed+1;arms=['standard_n_clients','at_most_K_ref']if pi%2 else ['at_most_K_ref','standard_n_clients']
  for pos,arm in enumerate(arms,1):sched.append({'call_id':f"X{t['selection_slot']:02d}_s{seed}_{'std'if arm=='standard_n_clients'else'Kref'}_b250",'instance_id':iid,'selection_slot':t['selection_slot'],'seed':seed,'max_iterations':250,'arm':arm,'K':standard['K']if arm=='standard_n_clients'else t['K'],'pair_index':pi,'within_pair_order':pos,'schedule_index':len(sched)+1})
save(R/'freeze/TASKS.json',newtasks);save(R/'freeze/HISTORICAL_CELLS.json',{'selection':'standard repeat A only; all36 capped25 cells, including3infeasible; no rerun or best selection','cells':hist});save(R/'freeze/SCHEDULE.json',sched)
proposal=json.loads((R/'freeze/PLAN_PROPOSAL.json').read_text());proposal['status']='ROOT_PLAN_APPROVED_PENDING_INDEPENDENT_PRECHECK_AND_PREEXEC';proposal['resource_proposal']['guard_semantics']='Exactly250 complete ILS loops after default initialization; not equal basic work or CPU. Guard termination is a failed call.';save(R/'freeze/PROTOCOL.json',proposal)
save(R/'provenance/PARENT_PLAN_APPROVAL.json',{'approved':True,'source':'Root collaboration message 2026-10-09T03:50:23Z','scope':'Prepare and synthetic test72-call250ILS paired protocol; no formal execution permission','resources':proposal['resource_proposal']})
files={}
for d in [F,S]:
 for p in sorted(d.rglob('*')):
  if p.is_file()and'__pycache__'not in p.parts:files[str(p)]={'bytes':p.stat().st_size,'sha256':sha(p)}
save(R/'freeze/OLD_FILES_BEFORE.json',{'files':files,'rule':'All preexisting old files remain byte-identical; adding new receipt to new project does not change old packages.'})
# Worker only budget string changes, model construction/default search/environment untouched.
p=R/'source/worker.py';s=p.read_text().replace("payload['max_iterations'] == 25","payload['max_iterations'] == 250").replace('26th callback','251st callback').replace('25 counted','250 counted').replace('Exactly25 completed','Exactly250 completed');p.write_text(s)
p=R/'source/execute_and_seal.py';s=p.read_text().replace('timeout=1060','timeout=1960');p.write_text(s)
p=R/'source/run_once.py';s=p.read_text().replace('fleet-treatment','paired fleet-budget').replace("entry['max_iterations']==25","entry['max_iterations']==250").replace("answer['num_iterations']==25 and len(answer['stats'])==25","answer['num_iterations']==250 and len(answer['stats'])==250").replace('signal.alarm(1000)','signal.alarm(1900)').replace("one frozen36-call at-most-K_ref PyVRP25-iteration batch; no retry","one frozen72-call paired fleet rules PyVRP250-iteration batch; no retry").replace("old_final=read('provenance/CONTROL_FINAL_REVIEWED_DRIVE_RECEIPT.json')","old_final=read('provenance/STANDARD25_FINAL_DRIVE_RECEIPT.json')").replace("len(schedule)==36 and len({e['call_id'] for e in schedule})==36","len(schedule)==72 and len({e['call_id'] for e in schedule})==72").replace("e['max_iterations']==25 and e['treatment']=='at_most_K_ref'","e['max_iterations']==250 and e['arm'] in ('standard_n_clients','at_most_K_ref')").replace("'planned_calls':36","'planned_calls':72").replace("payload.update(seed=entry['seed'],max_iterations=entry['max_iterations'])","payload.update(K=entry['K'],seed=entry['seed'],max_iterations=entry['max_iterations'])")
s=s.replace("old_final=read('provenance/STANDARD25_FINAL_DRIVE_RECEIPT.json')", "old_cap=read('provenance/CAPPED25_FINAL_DRIVE_RECEIPT.json')\n    assert old_cap['owner_only'] and old_cap['download_byte_identical'] and old_cap['remote_readback_sha256_verified'] and old_cap['shared'] is False\n    old_final=read('provenance/STANDARD25_FINAL_DRIVE_RECEIPT.json')")
s=s.replace("save(ROOT/'raw/STARTED.json'", "assert len({(e['instance_id'],e['seed'],e['arm']) for e in schedule})==72\n    tasks={t['instance_id']:t for t in read('freeze/TASKS.json')}\n    for j in range(0,72,2):\n        a,b=schedule[j:j+2];pi=j//2+1\n        assert a['pair_index']==b['pair_index']==pi and a['instance_id']==b['instance_id'] and a['seed']==b['seed']\n        assert [a['arm'],b['arm']]==(['standard_n_clients','at_most_K_ref'] if pi%2 else ['at_most_K_ref','standard_n_clients'])\n    for e in schedule:\n        assert e['K']==tasks[e['instance_id']]['standard_K' if e['arm']=='standard_n_clients' else 'K_ref']\n    save(ROOT/'raw/STARTED.json'")
p.write_text(s)
# AST checks do not execute the solver.
old=ast.parse((F/'source/worker.py').read_text());new=ast.parse((R/'source/worker.py').read_text());checks={}
for name in ['build_model','native_model_parameters','parameter_description','extract_routes','configure_worker_limits']:
 a=next(n for n in old.body if isinstance(n,ast.FunctionDef)and n.name==name);b=next(n for n in new.body if isinstance(n,ast.FunctionDef)and n.name==name);checks[name]=ast.dump(a)==ast.dump(b);assert checks[name]
def func(p,name):return next(n for n in ast.parse(p.read_text()).body if isinstance(n,ast.FunctionDef)and n.name==name)
checks['child_environment']=ast.dump(func(F/'source/run_once.py','child_environment'))==ast.dump(func(R/'source/run_once.py','child_environment'));assert checks['child_environment']
save(R/'evidence/REUSED_SOURCE_IDENTITY.json',{'status':'PASS','unchanged_AST_functions':checks,'changes':['Exact fixed iteration assertion25to250','New adjacent counterbalanced72call schedule','Supervisor/outer wall budgets1900/1960','New report/prefix endpoints, retained old evidence'],'no_formal_solver_call':True})
print('Preparation file copies, source adaptation, schedule and history complete; zero solver calls')
