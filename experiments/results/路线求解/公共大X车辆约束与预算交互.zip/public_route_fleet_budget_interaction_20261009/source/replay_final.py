"""Final-source saved evidence replay only. Does not create any subprocess or optimize."""
import copy,json
from common import ROOT,read,save,sha,now,verify_old
from endpoints import audit_call,audit_ledger,invalidate,prefix_observation

def main():
 smoke=read('selftests/SUPERVISOR_INTEGRATION.json');records=[]
 for v in smoke['records'][:5]:
  i=v['record'];o=audit_call(v['fixture'],i['schedule'],i,read(i['stdout']));assert not o['errors']and o['status']==v['audit']['status'];records.append(o)
 dest=ROOT/'selftests/integration';items=[json.loads(s)for s in(dest/'results.jsonl').read_text().splitlines()];events=[json.loads(s)for s in(dest/'attempts.jsonl').read_text().splitlines()]
 ledger=audit_ledger(smoke['schedule'],events,items);assert ledger['status']=='PASS'
 v=smoke['records'][2];i=v['record'];e=i['schedule'];p=v['fixture'];a=read(i['stdout']);checks=[]
 for status in ['WALL_TIMEOUT','PROCESS_FAILURE_OR_CPU_LIMIT','CALL_ERROR_UNDETERMINED']:
  b=copy.deepcopy(i);b.update(status=status,returncode=-9);o=audit_call(p,e,b,None);invalidate(o,['MISSING_LOG_FINISH']);assert o['status']==status and not o['valid_record'];checks.append(status)
 o=audit_call(p,e,None,None);invalidate(o,['MISSING_LOG_FINISH']);assert o['status']=='MISSING_RESULT';checks.append('MISSING_RESULT')
 for label,mutate in [('WRONG_COST',lambda x:x.update(reported_cost=x['reported_cost']+1)),('WRONG_BUDGET',lambda x:x.update(max_iterations=25)),('WRONG_STATS_TYPE',lambda x:x['stats'][0].update(current_feas=1)),('WRONG_FLEET',lambda x:x['native_model_parameters']['vehicle'].update(num_available=99)),('INFEASIBLE_FLAG',lambda x:x.update(solver_is_feasible=False)),('IO_VIOLATION',lambda x:x.update(denied_io_events=['open']))]:
  b=copy.deepcopy(a);mutate(b);o=audit_call(p,e,i,b);assert not o['valid_record']and not o['valid_feasible']and o['cost']is None;checks.append(label)
 save(ROOT/'selftests/FINAL_SOURCE_SAVED_REPLAY.json',{'status':'PASS','utc':now(),'optimizer_calls':0,'subprocess_calls':0,'scope':'Final endpoint and report source hashes after prefreeze failure-classification/lifecycle/malformed-ledger refinement. Production worker and supervisor unchanged since5-call invented integration.','five_saved_invented_outputs':records,'ledger':ledger,'fault_checks':checks,'old_files_verified_unchanged':verify_old(),'source_sha256':{n:sha(ROOT/'source'/n)for n in('worker.py','run_once.py','endpoints.py','report.py','replay_final.py')}})
 print('PASS final-source saved five outputs, production ledger and10failure checks; zero subprocesses/optimization')
if __name__=='__main__':main()
