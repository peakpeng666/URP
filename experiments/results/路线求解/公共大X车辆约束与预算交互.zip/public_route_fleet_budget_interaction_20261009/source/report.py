"""Read saved outputs only after authenticated RAW byte readback and independent audit."""
import json,math,collections
from common import ROOT,read,save,receipt,verify_frozen,verify_old,sha,now
from endpoints import audit_saved_answer,audit_call,audit_ledger,invalidate,prefix_observation,four_cell_record,summarize

def independent_match(expected,actual,path='root'):
 if isinstance(expected,dict):
  assert isinstance(actual,dict),path
  for k,v in expected.items():assert k in actual,path+'.'+k;independent_match(v,actual[k],path+'.'+k)
 elif isinstance(expected,list):
  assert isinstance(actual,list)and len(expected)==len(actual),path
  for i,(x,y)in enumerate(zip(expected,actual)):independent_match(x,y,f'{path}[{i}]')
 elif isinstance(expected,float):assert type(actual)in(int,float)and math.isclose(expected,actual,rel_tol=1e-12,abs_tol=1e-12),path
 else:assert expected==actual,path

def read_ledger_jsonl(path):
 records=[];errors=[];line_count=0
 if not path.exists():return records,errors,line_count
 for line_count,line in enumerate(path.read_text(errors='replace').splitlines(),1):
  try:
   value=json.loads(line)
   if not isinstance(value,dict):raise ValueError('Ledger row is not an object')
   records.append(value)
  except (ValueError,TypeError)as exc:errors.append({'file':str(path.relative_to(ROOT)),'line':line_count,'error':str(exc)})
 return records,errors,line_count

def collect_saved_evidence():
 tasks=read('freeze/TASKS.json');schedule=read('freeze/SCHEDULE.json');history=read('freeze/HISTORICAL_CELLS.json')['cells']
 assert len(tasks)==12 and len(schedule)==72 and len(history)==72
 results,result_errors,result_lines=read_ledger_jsonl(ROOT/'raw/results.jsonl')
 attempts,event_errors,event_lines=read_ledger_jsonl(ROOT/'raw/attempts.jsonl')
 ledger=audit_ledger(schedule,attempts,results)
 ledger['parse_errors']=result_errors+event_errors;ledger['physical_result_lines']=result_lines;ledger['physical_event_lines']=event_lines
 if ledger['parse_errors']:ledger['errors'].append('MALFORMED_LEDGER_JSONL');ledger['status']='INCOMPLETE_OR_INVALID'
 lm={r['call_id']:r for r in ledger['calls']}
 byid={r.get('call_id'):r for r in results};old_answers={};old_audits={};new_answers={};new_audits={};problems={t['instance_id']:read('input/'+t['instance_id']+'.json')for t in tasks}
 for h in history:
  p=ROOT/h['output_file'];assert sha(p)==h['stdout_sha256'];old_answers[(h['instance_id'],h['seed'],h['arm'])]=json.loads(p.read_text())
 for h in history:
  key=(h['instance_id'],h['seed'],h['arm']);a=old_answers[key];standard=old_answers[(h['instance_id'],h['seed'],'standard_n_clients')];e={**h,'max_iterations':25};problem={**problems[h['instance_id']],'K':h['K']}
  audited=audit_saved_answer(problem,e,a,standard)
  assert audited['valid_record'] and audited['status']==h['prior_audited_status'] and audited['valid_feasible']==h['prior_valid_feasible']and audited['cost']==h['prior_cost']and audited['vehicles']==h['prior_vehicles'],audited
  audited['source']='previously_reviewed25; standard uses predetermined A only';audited['stdout_sha256']=h['stdout_sha256'];old_audits[key]=audited
 for e in schedule:
  key=(e['instance_id'],e['seed'],e['arm']);item=byid.get(e['call_id']);a=None;errors=[]
  if item:
   try:
    p=ROOT/item['stdout'];assert p.is_relative_to(ROOT/'raw/calls')and sha(p)==item['stdout_sha256'];a=json.loads(p.read_text())
   except Exception as exc:errors.append('OUTPUT_READ_OR_HASH_ERROR:'+repr(exc))
  problem={**problems[e['instance_id']],'K':e['K']};standard=old_answers[(e['instance_id'],e['seed'],'standard_n_clients')]
  audited=audit_call(problem,e,item,a,standard);invalidate(audited,errors+lm[e['call_id']]['errors']+ledger['errors']);new_answers[key]=a;new_audits[key]=audited
 rows=[];prefix=[]
 for t in tasks:
  iid=t['instance_id']
  for seed in [0,1,2]:
   cells={}
   for arm,label in [('standard_n_clients','standard'),('at_most_K_ref','capped')]:
    key=(iid,seed,arm);cells[label+'25']=old_audits[key];cells[label+'250']=new_audits[key]
    prefix.append(prefix_observation(old_answers[key],new_answers[key],old_audits[key],new_audits[key]))
   rows.append(four_cell_record(iid,seed,cells))
 per=[{'instance_id':t['instance_id'],'K_ref':t['K_ref'],'n_customers':t['n_customers'],**summarize([r for r in rows if r['instance_id']==t['instance_id']])}for t in tasks]
 overall=summarize(rows)
 return {'rows':rows,'per_instance':per,'overall':overall,'prefix':prefix,'ledger':ledger,'observed_records':len(results)}

def main():
 verify_frozen();verify_old();r=receipt('RAW_UNREVIEWED')
 independent=read('independent_supervision/results/SAVED_BUDGET_AUDIT.json')
 assert independent['status']=='SAVED_EVIDENCE_AUDITED'and independent['raw_archive_sha256']==r['sha256']and independent['frozen_files_sha256']==sha(ROOT/'freeze/FROZEN_FILES.json')
 assert independent['planned_calls']==72 and len(independent['rows'])==36
 evidence=collect_saved_evidence();rows=evidence['rows'];overall=evidence['overall'];per=evidence['per_instance'];prefix=evidence['prefix']
 assert independent['observed_records']==evidence['observed_records']
 for own,ours in zip(independent['rows'],rows):
  independent_match({k:own[k]for k in ('instance_id','seed','paired25','paired250','valid_all_four','interaction_delta_cost','interaction_relative_pp','interaction_delta_vehicles','budget_effects')},ours,'row')
  for cell in ('standard25','capped25','standard250','capped250'):independent_match({k:own['cells'][cell][k]for k in('status','valid_record','valid_feasible','cost','vehicles')},ours['cells'][cell],'cell')
 independent_match(independent['overall'],overall,'overall');independent_match(independent['per_instance'],per,'per_instance')
 assert len(independent['prefix'])==72
 for own,ours in zip(independent['prefix'],prefix):independent_match({k:own[k]for k in('instance_id','seed','arm','status','equal','first_difference')},ours,'prefix')
 summary={'utc':now(),'question':'Fleet cap by fixed default ILS iteration budget, descriptive historical2x2 comparison','new_planned_calls':72,'historical_cells_reused':72,'full_table_cells':144,'overall':overall,'prefix_statuses':dict(collections.Counter(p['status']for p in prefix)),'raw_archive_sha256':r['sha256'],'frozen_files_sha256':sha(ROOT/'freeze/FROZEN_FILES.json'),'independent_audit_sha256':sha(ROOT/'independent_supervision/results/SAVED_BUDGET_AUDIT.json'),'independent144cells_and72prefixes_match':True,'ledger_status':evidence['ledger']['status'],'interpretation':'All required failed/missing cells retained; full-panel incomplete quality endpoints null. Conditional analyses have explicit common-success denominators. Historical25outputs never replaced. Same iteration count is not same primitive work/CPU. F_capped subseteq F_standard means exact optimum cannot improve under added constraint; returned heuristics can.','historical_disclosure':'Historicalstandard25repeatA only. Its original phase-key collision was audited and recovered read-only; it remains disclosed and unchanged. New schedule uses event_kind and nested schedule. Historical25andnew250are noncontemporaneous; no causal or timing-performance inference.'}
 for name,value in [('LEDGER_AUDIT',evidence['ledger']),('FOUR_CELL_RESULTS',rows),('PER_INSTANCE',per),('PREFIX_COMPARISON',prefix),('SUMMARY',summary)]:save(ROOT/'reports'/f'{name}.json',value)
 feas=overall['feasibility'];q=overall['complete_primary'];c=overall['conditional_common_success'];common=overall['all_four_common_success_count']
 lines=['车辆上限与固定ILS迭代预算：25/250历史二维对照','',f"新250档：standard可行{feas['standard250']['feasible']}/36，at-most-K_ref可行{feas['capped250']['feasible']}/36。",f"旧25档保持原记录：standard repeat A可行{feas['standard25']['feasible']}/36，at-most-K_ref可行{feas['capped25']['feasible']}/36；没有补跑、选优或用250结果追改。",'K_ref不是文件名中的k，而由冻结原SOL实际非空路线数给出；at-most不要求恰好用满。原SOL在两规则均有独立可行见证。','',f"250档完整36对平均成本差（约束−标准）：{q['paired250_delta_cost']['mean']}；平均相对差：{q['paired250_relative_delta_pct']['mean']}%。任何所需格无有效可行结果时，该完整总体指标为null。",f"250档共同成功条件均值：成本差{c['paired250_delta_cost']['mean']}，相对差{c['paired250_relative_delta_pct']['mean']}%；分母{c['paired250_delta_cost']['n']}/36。",f"四格共同成功{common}/36：交互Δ250−Δ25平均成本差{c['interaction_delta_cost']['mean']}，相对交互{c['interaction_relative_pp']['mean']}个百分点。完整36交互为{q['interaction_delta_cost']['mean']}，不得以条件子集代替。",f"72个同输入/seed/规则轨迹的前25步六质量字段观察：{summary['prefix_statuses']}。时间字段排除；不同或不可用均保留，不触发重跑。 这仅说明六个成本/可行性统计字段的一致性，不证明路线、完整搜索状态或随机状态逐字节一致。",'',f"失败类别：{json.dumps(feas,ensure_ascii=False)}",'', '解释边界','- NO_FEASIBLE_INCUMBENT_WITHIN_BUDGET指完成预算但未返回可行解；CPU/wall限制、进程/输出/账本失败是工程或guard失败，两类分别保留，不能互换。','- 若较长预算恢复可行，仅说明这些已观察调用在扩展预算下找到可行结果；不证明25普遍不足、250普遍足够或旧25原本无失败。','- 旧25与新250跨时间运行，固定迭代不代表等基本操作量、CPU或wall，不做纯因果或速度结论。','- 增加车辆约束使可行域缩小，精确最优值不可能下降；启发式返回更低成本属于有限预算搜索行为。','- 同12个已观察公开X题、3seed、两个声明派生问题，无统计显著性、SOTA、独立新真实数据或农业实际车队外推。','- 历史standard日志phase缺陷及只读恢复保持披露；新日志event_kind和nested schedule先行全链测试。','- 所有正式72调用只执行一次；无warm start、参数调整、补跑或进一步升预算。','','逐题（每规则/预算3个seed全部保留）']
 for p in per:lines.append(f"{p['instance_id']} K_ref={p['K_ref']}；250可行标准{p['feasibility']['standard250']['feasible']}/3、约束{p['feasibility']['capped250']['feasible']}/3；完整三对成本差{p['complete_primary']['paired250_delta_cost']['mean']}；共同成功条件n={p['conditional_common_success']['paired250_delta_cost']['n']}/3，均差{p['conditional_common_success']['paired250_delta_cost']['mean']}。")
 with(ROOT/'reports/REPORT_ZH.txt').open('x')as f:f.write('\n'.join(lines)+'\n')
 print(json.dumps(summary,ensure_ascii=False))
if __name__=='__main__':main()
