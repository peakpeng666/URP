"""Read saved invented outputs, inject validation faults, and test reserved keys with malformed payload (no optimization)."""
import copy,json
from common import ROOT,read,save,sha,now
from endpoints import audit_call,audit_ledger,prefix_observation,four_cell_record,summarize
from run_once import logged_call

def main():
 smoke=read('selftests/SUPERVISOR_INTEGRATION.json');records=[]
 for v in smoke['records'][:5]:
  item=v['record'];a=read(item['stdout']);out=audit_call(v['fixture'],item['schedule'],item,a);assert not out['errors']and out['status']==v['audit']['status'];records.append(out)
 v=smoke['records'][2];p=v['fixture'];item=v['record'];e=item['schedule'];a=read(item['stdout']);checks=[]
 for status in ['WALL_TIMEOUT','PROCESS_FAILURE_OR_CPU_LIMIT','CALL_ERROR_UNDETERMINED']:
  bad=copy.deepcopy(item);bad.update(status=status,returncode=-9);out=audit_call(p,e,bad,None);assert out['status']==status and not out['valid_record'];checks.append(status)
 out=audit_call(p,e,None,None);assert out['status']=='MISSING_RESULT'and not out['valid_record'];checks.append('MISSING_RESULT')
 for label,mutate in [('WRONG_COST',lambda x:x.update(reported_cost=x['reported_cost']+1)),('WRONG_BUDGET',lambda x:x.update(max_iterations=25)),('WRONG_STATS_TYPE',lambda x:x['stats'][0].update(current_feas=1)),('WRONG_FLEET',lambda x:x['native_model_parameters']['vehicle'].update(num_available=99)),('INFEASIBLE_FLAG',lambda x:x.update(solver_is_feasible=False)),('IO_VIOLATION',lambda x:x.update(denied_io_events=['open']))]:
  bad=copy.deepcopy(a);mutate(bad);out=audit_call(p,e,item,bad);assert not out['valid_record']and not out['valid_feasible']and out['cost']is None,(label,out);checks.append(label)
 dest=ROOT/'selftests/reserved_event';dest.mkdir();calls=dest/'calls';calls.mkdir()
 shadow={'call_id':'RESERVED_KEYS','instance_id':'INVENTED_MALFORMED','seed':0,'max_iterations':250,'arm':'at_most_K_ref','K':1,'event_kind':'OVERRIDE','phase':2,'repeat_index':3}
 result=logged_call(shadow,{'malformed':True},read('environment/RUNTIME.json')['python_executable'],calls,dest);assert result['status']=='PROCESS_FAILURE_OR_CPU_LIMIT'
 events=[json.loads(s)for s in(dest/'attempts.jsonl').read_text().splitlines()];items=[json.loads(s)for s in(dest/'results.jsonl').read_text().splitlines()];ledger=audit_ledger([shadow],events,items);assert ledger['status']=='PASS'and events[0]['event_kind']=='STARTED'and events[0]['schedule']['event_kind']=='OVERRIDE'
 save(ROOT/'selftests/FINAL_ENDPOINT_SAVED_REPLAY.json',{'status':'PASS','utc':now(),'public_optimizer_calls':0,'additional_synthetic_optimizer_calls':0,'malformed_payload_process_calls':1,'fault_checks':checks,'saved_invented_outputs':records,'production_logged_reserved_key_ledger':ledger,'source_sha256':{n:sha(ROOT/'source'/n)for n in('worker.py','run_once.py','endpoints.py','report.py','replay_synthetic.py')}})
 print('PASS saved-only failure replay and actual production logger reserved-key regression; zero additional optimization')
if __name__=='__main__':main()
