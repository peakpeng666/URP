"""Production logger, subprocess guard path and endpoint replay on invented data only."""
import copy,json,signal
from common import ROOT,read,save,now,sha
from run_once import logged_call,execute_call
from endpoints import audit_call,audit_ledger,four_cell_record,summarize,prefix_observation

def run_in_limited_supervisor(limits):
 assert limits=={'AS_bytes':[512*1024**2,1536*1024**2],'CPU_seconds':[30,30]}
 signal.alarm(180);dest=ROOT/'selftests/integration';dest.mkdir(exist_ok=False);calls=dest/'calls';calls.mkdir()
 python=read('environment/RUNTIME.json')['python_executable'];records=[];schedule=[]
 large={'instance_id':'INVENTED_524','coordinates':[[0,0]]+[[i%31,(i*17)%29]for i in range(1,524)],'demands':[0]+[1]*523,'capacity':25,'K':523}
 small={'instance_id':'INVENTED_TIGHT','coordinates':[[0,0],[1,0],[2,0],[0,1],[0,2]],'demands':[0,1,1,1,1],'capacity':2,'K':4}
 impossible={'instance_id':'INVENTED_IMPOSSIBLE_SCHEMA_ONLY','coordinates':[[0,0],[1,0],[0,1]],'demands':[0,2,2],'capacity':3,'K':1}
 fixtures=[(large,'standard_n_clients',523,0),(large,'at_most_K_ref',22,0),(small,'at_most_K_ref',2,1),(small,'standard_n_clients',4,1),(impossible,'at_most_K_ref',1,2)]
 for p,arm,K,seed in fixtures:
  p={**p,'K':K};i=len(schedule)+1;e={'call_id':f'FIXTURE_{i}','instance_id':p['instance_id'],'seed':seed,'max_iterations':250,'arm':arm,'K':K,'schedule_index':i,'pair_index':(i+1)//2,'within_pair_order':1 if i%2 else 2};schedule.append(e)
  payload={k:v for k,v in p.items()if k!='instance_id'};payload.update(seed=seed,max_iterations=250)
  item=logged_call(e,payload,python,calls,dest);answer=json.loads((ROOT/item['stdout']).read_text());audit=audit_call(p,e,item,answer)
  assert not audit['errors'],audit
  assert answer['resource_limits']=={'inherited':limits,'effective':{'AS_bytes':[1536*1024**2,1536*1024**2],'CPU_seconds':[15,15]}}
  if p['instance_id']=='INVENTED_TIGHT':assert audit['valid_feasible']
  if p['instance_id']=='INVENTED_IMPOSSIBLE_SCHEMA_ONLY':assert audit['status']=='NO_FEASIBLE_INCUMBENT_WITHIN_BUDGET'
  records.append({'fixture':p,'record':item,'audit':audit})
 e={'call_id':'FIXTURE_malformed','instance_id':'INVENTED_MALFORMED','seed':0,'max_iterations':250,'arm':'at_most_K_ref','K':1,'schedule_index':6};schedule.append(e)
 bad=logged_call(e,{'malformed':True},python,calls,dest);assert bad['status']=='PROCESS_FAILURE_OR_CPU_LIMIT'and bad['child_reaped'];records.append({'record':bad})
 duplicate=execute_call(e,{'malformed':True},python,calls);assert duplicate['status']=='CALL_ERROR_UNDETERMINED'and not duplicate['process_spawned']
 items=[json.loads(s)for s in(dest/'results.jsonl').read_text().splitlines()];events=[json.loads(s)for s in(dest/'attempts.jsonl').read_text().splitlines()];ledger=audit_ledger(schedule,events,items);assert ledger['status']=='PASS',ledger
 altered=copy.deepcopy(events);altered[0]['event_kind']='BAD';assert audit_ledger(schedule,altered,items)['status']!='PASS'
 partial=audit_ledger(schedule,events[:-2],items[:-1]);assert partial['planned_denominator']==6 and partial['status']!='PASS'
 # Saved-output-only prefix fixtures, not additional old25 solver runs.
 x=records[2];new=read(x['record']['stdout']);old=copy.deepcopy(new);old.update(max_iterations=25,num_iterations=25,stats=new['stats'][:25],stats_runtime_per_iteration=new['stats_runtime_per_iteration'][:25]);audit=x['audit']
 prefix=prefix_observation(old,new,audit,audit);assert prefix['status']=='SAME'
 changed=copy.deepcopy(new);changed['stats'][2]['current_cost']+=1;diff=prefix_observation(old,changed,audit,audit);assert diff['status']=='DIFFERENT'and diff['first_difference']['iteration']==3
 missing=copy.deepcopy(audit);missing['valid_record']=False;assert prefix_observation(old,None,audit,missing)['status']=='UNAVAILABLE'
 # Full144cell schema is exercised from saved invented outputs, with every failure denominator retained.
 good=records[2]['audit'];failed=records[4]['audit'];rows=[]
 for i in range(36):rows.append(four_cell_record('INVENTED_'+str(i//3),i%3,{'standard25':good,'capped25':failed if i==35 else good,'standard250':good,'capped250':good}))
 summary=summarize(rows);assert summary['planned_cells']==144 and summary['feasibility']['capped25']['planned_denominator']==36 and summary['feasibility']['capped25']['feasible']==35
 assert summary['complete_primary']['interaction_delta_cost']['mean']is None and summary['conditional_common_success']['interaction_delta_cost']['n']==35 and summary['complete_primary']['paired250_delta_cost']['mean']==0
 signal.alarm(0)
 save(ROOT/'selftests/SUPERVISOR_INTEGRATION.json',{'status':'PASS','utc':now(),'scope':'Actual production-schema logged_call and execute_call in limited supervisor. Five invented250ILS calls, malformed process failure and duplicate output guard; saved-only prefix and144cell endpoint replay. No formal/public input optimization.','public_optimizer_calls':0,'synthetic_optimizer_calls':5,'supervisor_limits':limits,'schedule':schedule,'records':records,'ledger':ledger,'duplicate_output_guard':duplicate,'prefix_same_fixture':prefix,'prefix_difference_fixture':diff,'full144cell_failure_summary':summary,'source_sha256':{n:sha(ROOT/'source'/n)for n in('worker.py','run_once.py','synthetic_integration.py','endpoints.py','report.py')}})
 print('PASS production-chain synthetic replay: five invented calls, zero public calls')
