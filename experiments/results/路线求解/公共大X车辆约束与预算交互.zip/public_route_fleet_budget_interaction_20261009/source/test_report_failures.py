"""Saved-only full collector failure regression; no solver import or call."""
import copy,json,sys
from pathlib import Path
import report
from common import ROOT,save,now,sha
from endpoints import audit_ledger,audit_call,invalidate

def main():
 e1={'call_id':'a'};e2={'call_id':'b'};i1={'call_id':'a','schedule':e1};i2={'call_id':'b','schedule':e2}
 a=[{'event_kind':'STARTED','utc':'t','call_id':'a','schedule':e1},{'event_kind':'STARTED','utc':'t','call_id':'b','schedule':e2},{'event_kind':'FINISHED','utc':'t','call_id':'a','schedule':e1,'result':i1},{'event_kind':'FINISHED','utc':'t','call_id':'b','schedule':e2,'result':i2}]
 ledger=audit_ledger([e1,e2],a,[i1,i2]);assert 'NON_SERIAL_OR_INVALID_EVENT_LIFECYCLE'in ledger['errors']
 for s in ['MISSING_RESULT','WALL_TIMEOUT','PROCESS_FAILURE_OR_CPU_LIMIT','CALL_ERROR_UNDETERMINED']:
  x={'status':s,'errors':[],'valid_record':False,'valid_feasible':False,'cost':None,'vehicles':None};invalidate(x,['LEDGER_ERROR']);assert x['status']==s
 dest=ROOT/'selftests/malformed_ledger_fixture';dest.mkdir(exist_ok=False)
 for name in ('freeze','input','history'):(dest/name).symlink_to(ROOT/name,target_is_directory=True)
 (dest/'raw').mkdir();(dest/'raw/results.jsonl').write_text('{not JSON}\n[]\n{"unexpected":"object"}\n');(dest/'raw/attempts.jsonl').write_text('null\n{broken\n')
 original=report.ROOT;report.ROOT=dest
 try:result=report.collect_saved_evidence()
 finally:report.ROOT=original
 assert len(result['rows'])==36 and len(result['prefix'])==72 and result['overall']['planned_cells']==144
 assert result['overall']['feasibility']['standard25']['feasible']==36 and result['overall']['feasibility']['capped25']['feasible']==33
 assert result['overall']['feasibility']['standard250']['statuses']=={'MISSING_RESULT':36}and result['overall']['feasibility']['capped250']['statuses']=={'MISSING_RESULT':36}
 assert 'MALFORMED_LEDGER_JSONL'in result['ledger']['errors']and len(result['ledger']['parse_errors'])==4
 assert result['overall']['complete_primary']['paired250_delta_cost']['mean']is None
 # Symlink fixtures are test-only; remove directory links so archives contain no duplicated dependency trees.
 for name in ('freeze','input','history'):(dest/name).unlink()
 save(ROOT/'selftests/REPORT_FAILURE_REGRESSION.json',{'status':'PASS','utc':now(),'optimizer_calls':0,'nonserial_lifecycle_rejected':ledger,'direct_failure_statuses_preserved':True,'malformed_ledger_retains144cells':True,'overall':result['overall'],'ledger':result['ledger'],'source_sha256':{n:sha(ROOT/'source'/n)for n in('endpoints.py','report.py','test_report_failures.py')}})
 print('PASS nonserial lifecycle, preserved direct failure classes and malformed-ledger144cell collector regression')
if __name__=='__main__':main()
