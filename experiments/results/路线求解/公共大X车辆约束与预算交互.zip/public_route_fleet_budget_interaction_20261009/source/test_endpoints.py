import copy,unittest
from endpoints import audit_ledger,four_cell_record,summarize,comparable_model,prefix_observation,metric
class Tests(unittest.TestCase):
 def good(self,cost=100):return {'instance_id':'x','seed':0,'valid_record':True,'valid_feasible':True,'status':'FEASIBLE','cost':cost,'vehicles':4}
 def row(self,costs=(100,110,90,95)):
  return four_cell_record('x',0,{k:self.good(c)for k,c in zip(('standard25','capped25','standard250','capped250'),costs)})
 def test_sign(self):
  r=self.row();self.assertEqual(r['paired25']['delta_cost'],10);self.assertEqual(r['paired250']['delta_cost'],5);self.assertEqual(r['interaction_delta_cost'],-5);self.assertAlmostEqual(r['interaction_relative_pp'],100*5/90-10);self.assertEqual(r['budget_effects'],{'standard':-10,'capped':-15})
 def test_null_not_imputed(self):
  r=self.row();r['cells']['capped25'].update(valid_feasible=False,status='NO_FEASIBLE_INCUMBENT_WITHIN_BUDGET',cost=None,vehicles=None);r=four_cell_record('x',0,r['cells']);s=summarize([self.row(),r]);self.assertEqual(s['planned_cells'],8);self.assertIsNone(s['complete_primary']['interaction_delta_cost']['mean']);self.assertEqual(s['conditional_common_success']['interaction_delta_cost']['n'],1);self.assertIsNone(s['complete_primary']['paired25_delta_cost']['mean']);self.assertEqual(s['complete_primary']['paired250_delta_cost']['mean'],5);self.assertEqual(s['conditional_common_success']['same_all_four_subset']['n'],1)
 def test_all_failure_retained(self):
  r=self.row()
  for c in r['cells'].values():c.update(valid_record=False,valid_feasible=False,status='MISSING_RESULT',cost=None,vehicles=None)
  s=summarize([four_cell_record('x',0,r['cells'])]);self.assertEqual(s['planned_pairs'],1);self.assertIsNone(s['complete_primary']['standard25_cost']['mean']);self.assertEqual(s['feasibility']['standard25']['statuses'],{'MISSING_RESULT':1})
 def test_nested_reserved_event(self):
  e={'call_id':'x','event_kind':'evil','phase':2};r={'call_id':'x','schedule':e};events=[{'event_kind':'STARTED','utc':'t','call_id':'x','schedule':e},{'event_kind':'FINISHED','utc':'t','call_id':'x','schedule':e,'result':r}];self.assertEqual(audit_ledger([e],events,[r])['status'],'PASS');events[0]['event_kind']=2;self.assertNotEqual(audit_ledger([e],events,[r])['status'],'PASS')
 def test_missing_duplicate(self):
  e={'call_id':'x'};a=audit_ledger([e],[],[]);self.assertEqual(a['planned_denominator'],1);self.assertFalse(a['calls'][0]['ledger_valid']);r={'call_id':'x','schedule':e};self.assertIn('DUPLICATE_RESULT',audit_ledger([e],[],[r,r])['errors'])
 def test_same_model_except_K(self):
  s={'num_vehicles':10,'vehicle':{'num_available':10,'capacity':[3]}};a=copy.deepcopy(s);a['num_vehicles']=a['vehicle']['num_available']=3;self.assertTrue(comparable_model(s,a,3));a['vehicle']['capacity']=[4];self.assertFalse(comparable_model(s,a,3))
 def test_no_missing_zero_replacement(self):self.assertIsNone(metric([1,None],2,False)['mean']);self.assertEqual(metric([1,None],2,True)['n'],1)
if __name__=='__main__':unittest.main()
