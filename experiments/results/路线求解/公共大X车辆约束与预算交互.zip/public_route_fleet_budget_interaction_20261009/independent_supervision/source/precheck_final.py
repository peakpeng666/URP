"""Final independent preexecution candidate. Read only saved evidence; no optimizer."""
from audit_saved_budget import *
from review_design_history import inspect
import ast

def main():
    start=time.process_time();history=inspect();smoke=load(ROOT/'selftests/SUPERVISOR_INTEGRATION.json');final=load(ROOT/'selftests/FINAL_SOURCE_SAVED_REPLAY.json');reg=load(ROOT/'selftests/REPORT_FAILURE_REGRESSION.json');own=load(ROOT/'independent_supervision/results/INDEPENDENT_SAVED_SELFTEST_FINAL.json')
    require(all(x['status']=='PASS'for x in(smoke,final,reg,own)),'selftests PASS')
    for name,h in smoke['source_sha256'].items():
        if name not in('endpoints.py','report.py'):require(sha(ROOT/'source'/name)==h,'executed production worker/supervisor frozen '+name)
    for record in(final,reg):
        for name,h in record['source_sha256'].items():require(sha(ROOT/'source'/name)==h,'final saved replay source '+name)
    for name,h in own['source_sha256'].items():require(sha(ROOT/name)==h,'independent tested source '+name)
    require(own['optimizer_calls_by_reviewer']==0 and own['no_subprocess_by_test']is True,'independent zero-call selftest')
    require(smoke['synthetic_optimizer_calls']==5 and smoke['public_optimizer_calls']==0,'authorized invented-only selftest count')
    cleanup=load(ROOT/'selftests/PROCESS_CLEANUP.json');require(cleanup['status']=='PASS'and len(cleanup['fixtures'])==3 and all(x['pass']and x['late_file_absent']for x in cleanup['fixtures']),'whole process group cleanup saved tests')
    require(reg['malformed_ledger_retains144cells']and reg['direct_failure_statuses_preserved']and reg['nonserial_lifecycle_rejected']['status']!='PASS','reported faults corrected')
    # Recompute missing-new72 endpoints using independently checked historical cells.
    h={(v['instance_id'],v['seed'],v['arm']):v for v in history['rows']};rows=[];tasks=load(ROOT/'freeze/TASKS.json')
    for task in tasks:
        iid=task['instance_id']
        for seed in range(3):
            c={}
            for arm,label in(('standard_n_clients','standard'),('at_most_K_ref','capped')):
                c[label+'25']={**h[iid,seed,arm],'valid_record':True,'errors':[]};c[label+'250']=blank('MISSING_RESULT')
            rows.append(four(iid,seed,c))
    sys.path.insert(0,str(ROOT/'source'));import report,endpoints
    collected=report.collect_saved_evidence();require(collected['observed_records']==0 and len(collected['rows'])==36,'no real calls')
    equal(summarize(rows),collected['overall'],'all144 saved/missing report schema')
    for ownrow,theirrow in zip(rows,collected['rows']):
        equal({k:ownrow[k]for k in('instance_id','seed','paired25','paired250','valid_all_four','interaction_delta_cost','interaction_relative_pp','interaction_delta_vehicles','budget_effects')},theirrow,'missing row schema')
        for key in CELL_NAMES:equal({k:ownrow['cells'][key][k]for k in('status','valid_record','valid_feasible','cost','vehicles')},theirrow['cells'][key],'missing cell')
    # Confirm both audit and author reject the actual interleaving counterexample.
    schedule=smoke['schedule'];events,_=lines(ROOT/'selftests/integration/attempts.jsonl');items,_=lines(ROOT/'selftests/integration/results.jsonl')
    bad=copy.deepcopy(events);bad[1],bad[2]=bad[2],bad[1];require(endpoints.audit_ledger(schedule,bad,items)['status']!='PASS','final author serial lifecycle')
    require(check_ledger(schedule,events,items)[0]['status']=='PASS','independent complete actual saved log')
    reserved_events,_=lines(ROOT/'selftests/reserved_event/attempts.jsonl');reserved_items,_=lines(ROOT/'selftests/reserved_event/results.jsonl')
    require(reserved_events[0]['event_kind']=='STARTED'and reserved_events[0]['schedule']['event_kind']=='OVERRIDE'and reserved_events[1]['event_kind']=='FINISHED','nested reserved-key production regression')
    for item in items+reserved_items:
        for key in('stdout','stderr'):require(sha(ROOT/item[key])==item[key+'_sha256'],'saved production evidence hash')
    # Static checks bind unique launch / RAW-before-score contract and budgets.
    protocol=load(ROOT/'freeze/PROTOCOL.json');resource_plan=protocol['resource_proposal']
    require(resource_plan['child_cpu_seconds']==15 and resource_plan['child_AS_MiB']==1536 and resource_plan['child_wall_seconds']==25 and resource_plan['supervisor_cpu_seconds']==30 and resource_plan['supervisor_wall_seconds']==1900 and resource_plan['outer_wall_seconds']==1960 and resource_plan['max_concurrent_children']==1,'approved resource design')
    for root in('source','independent_supervision/source'):
        for p in(ROOT/root).glob('*.py'):ast.parse(p.read_text())
    run=(ROOT/'source/run_once.py').read_text();outer=(ROOT/'source/execute_and_seal.py').read_text();rpt=(ROOT/'source/report.py').read_text();pkg=(ROOT/'source/package.py').read_text()
    for snippet in("receipt('PREEXEC')","approval['preexec_archive_sha256']==r['sha256']","save(ROOT/'raw/STARTED.json'","signal.alarm(1900)","'no_retries':True"):require(snippet in run,'launch guard '+snippet)
    for snippet in("save(ROOT/'raw/EXECUTOR_STARTED.json'","p.wait(timeout=1960)",'start_new_session=True',"stop_process_group(p)","package('RAW_UNREVIEWED')"):require(snippet in outer,'outer guard '+snippet)
    require(rpt.index("r=receipt('RAW_UNREVIEWED')")<rpt.index('evidence=collect_saved_evidence()'),'RAW before report scoring')
    require("read('independent_supervision/results/FINAL_REPORT_REVIEW.json')"in pkg,'final primary signature required')
    require(not(ROOT/'freeze/FROZEN_FILES.json').exists()and not list((ROOT/'raw').rglob('*')),'preexecution not frozen or started')
    require(not(ROOT/'provenance/RAW_UNREVIEWED_DRIVE_RECEIPT.json').exists(),'RAW not yet available')
    try:gate()
    except FileNotFoundError:pass
    else:raise ValueError('RAW gate unexpectedly open before receipt')
    output={'status':'PASS_CANDIDATE_FOR_PRIMARY_SUPERVISOR_SIGNATURE','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'execution_authorized':False,'optimizer_calls_by_reviewer':0,'planned_new_calls':72,'historical_cells_verified':72,'full_cells':144,'history_review_sha256':sha(ROOT/'independent_supervision/results/DESIGN_HISTORY_REVIEW.json'),'historical_archives':history['historical_archives'],'K_ref':history['reference_feasibility'],'historical_statuses':history['historical_statuses'],'whole_worker_change':'Only exact budget assertion25->250 and matching iteration documentation; build_model, native parameters, default SolveParams, initial_solution=None, route extraction, child environment, limits and runtime unchanged.','runtime_distribution_files_verified':history['installed_distribution_files_verified'],'old_files_verified_unchanged':history['old_files_verified_unchanged'],'saved_selftest':{'production_events':12,'production_records':6,'actual_invented_solver_answers':5,'reserved_event_shadowing_rejected':True,'fault_categories':own['negative_checks'],'all144_missing_denominators_verified':True,'historical72_plus_missing_new72_report_match':True,'author_final_source_replay_sha256':sha(ROOT/'selftests/FINAL_SOURCE_SAVED_REPLAY.json'),'independent_selftest_sha256':sha(ROOT/'independent_supervision/results/INDEPENDENT_SAVED_SELFTEST_FINAL.json')},'corrected_author_preexecution_findings':['Serial lifecycle required, interleaved START/FINISH rejected','Malformed ledger parsing preserves all144 planned cells','Direct missing/process/guard failure categories retained with ledger errors','Reference K and finite-budget/noncontemporaneous qualifications retained'],'reviewer_development_failures_preserved':['INITIAL_PRECHECK_FAILURE.json','SECOND_PRECHECK_FAILURE.json','SELFTEST_INITIAL_FAILURE.json'],'post_audit':{'launcher':'independent_supervision/source/launch_audit_once.py --results','CPU_seconds':60,'AS_MiB':512,'wall_seconds':120,'no_solver_import_or_call':True,'no_usr_bin_time_dependency':True,'actual_RAW_readback_gate_before_scoring':True,'one_use_launch_markers':True,'report_interface':'SAVED_BUDGET_AUDIT.json; rows36/cells144, overall/per_instance, prefix72; report mode separately hash binds final files'},'reviewed_source_sha256':{str(p.relative_to(ROOT)):sha(p)for folder in('source','independent_supervision/source','independent_review')for p in sorted((ROOT/folder).glob('*.py'))},'required_next_gates':['Primary supervisor signs freeze/INDEPENDENT_PRECHECK.json','PREEXEC freeze and owner-only actual-byte archive readback','Root hash-bound unique72-call execution approval and exclusive CPU window','RAW seal then owner-only actual-byte readback before any endpoint scoring','Primary supervisor grants saved-audit CPU window; launch exactly once and preserve failure if any'],'limitations':['Historical standard is predetermined repeat A with retained phase-key collision/read-only recovery disclosure','K_ref is original SOL nonempty route count, not filename k; at-most constraint','Budget is completed official ILS iterations after initialization, not equal CPU/operations/time','Three seeds do not increase12 independent instances; panel was already observed','Full36 quality aggregates null if required cells fail; conditional interaction uses same all4-valid subset with n/36','No rerun for prefix divergence or infeasibility and no further budget extension','F_capped subseteq F_standard; lower returned heuristic cost cannot establish smaller constrained true optimum'],'cpu_seconds_audit_only':time.process_time()-start}
    save_exclusive(ROOT/'independent_supervision/results/PRECHECK_CANDIDATE.json',output)
    print(json.dumps({k:output[k]for k in('status','execution_authorized','planned_new_calls','historical_cells_verified','cpu_seconds_audit_only')}))
if __name__=='__main__':
    resource.setrlimit(resource.RLIMIT_CPU,(60,60));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2));signal.alarm(120);main()
