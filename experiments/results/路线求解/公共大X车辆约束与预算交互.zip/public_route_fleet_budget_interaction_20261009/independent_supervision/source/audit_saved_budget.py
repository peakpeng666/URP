"""Independent fleet-budget RAW/report audit, standard library only.
No optimizer or author endpoint/validator imports. Actual downloaded RAW bytes are
verified before reading/scoring any formal answer. All 144 scheduled cells stay.
"""
from original_primitives import *
from saved_answer import answer_check, compact
from review_design_history import STAGES
from collections import Counter
import resource, signal, statistics, time
FIELDS=('current_cost','candidate_cost','best_cost','current_feas','candidate_feas','best_feas')
CELL_NAMES=('standard25','capped25','standard250','capped250')
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def save_exclusive(path,value):
    with Path(path).open('x')as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n')
def gate():
    r=load(ROOT/'provenance/RAW_UNREVIEWED_DRIVE_RECEIPT.json')
    require(r['owner_only']is True and r['shared']is False and r['remote_readback_sha256_verified']is True and r['download_byte_identical']is True,'RAW owner-only authenticated receipt')
    archive=ROOT.parent/(ROOT.name+'_RAW_UNREVIEWED.zip')
    require(sha(archive)==sha(r['download_path'])==r['sha256']==r['download_sha256'],'RAW actual downloaded bytes')
    require(sha(ROOT/'freeze/FROZEN_FILES.json')==r['frozen_files_sha256'],'RAW freeze identity')
    frozen=load(ROOT/'freeze/FROZEN_FILES.json');raw=load(ROOT/'raw/RAW_UNREVIEWED_MANIFEST.json')
    actual={str(p.relative_to(ROOT))for p in (ROOT/'raw').rglob('*')if p.is_file()and'__pycache__'not in p.parts}
    require(actual==set(raw['files'])|{'raw/RAW_UNREVIEWED_MANIFEST.json'},'exact immutable raw set')
    with zipfile.ZipFile(r['download_path'])as z:
        require(len(z.namelist())==len(set(z.namelist())),'no duplicate RAW archive members')
        for rel,m in (frozen['files']|raw['files']).items():
            p=ROOT/rel;require(p.stat().st_size==m['bytes']and sha(p)==m['sha256'],'frozen/raw local bytes '+rel)
            require(z.read(ROOT.name+'/'+rel)==p.read_bytes(),'actual RAW member '+rel)
        for rel in ('freeze/FROZEN_FILES.json','raw/RAW_UNREVIEWED_MANIFEST.json'):require(z.read(ROOT.name+'/'+rel)==(ROOT/rel).read_bytes(),'manifest member '+rel)
    for path,m in load(ROOT/'freeze/OLD_FILES_BEFORE.json')['files'].items():require(Path(path).stat().st_size==m['bytes']and sha(path)==m['sha256'],'old immutable '+path)
    return r

def lines(path):
    if not Path(path).exists():return [],[]
    rows=[];errs=[]
    for n,s in enumerate(Path(path).read_text().splitlines(),1):
        try:
            x=json.loads(s);require(isinstance(x,dict),'object');rows.append(x)
        except Exception as e:errs.append(f'{Path(path).name} line {n}: {e}')
    return rows,errs

def check_ledger(schedule,events,items,parse_errors=()):
    expected={e['call_id']:e for e in schedule};byid={};errs=list(parse_errors);per={cid:[]for cid in expected}
    for item in items:
        cid=item.get('call_id')
        if cid not in expected:errs.append('UNEXPECTED_RESULT');continue
        if cid in byid:errs.append('DUPLICATE_RESULT')
        byid[cid]=item
    starts=[];finishes=[];active=None
    for e in events:
        cid=e.get('call_id');kind=e.get('event_kind')
        if cid not in expected:errs.append('UNEXPECTED_EVENT');continue
        if kind not in ('STARTED','FINISHED'):errs.append('INVALID_EVENT_KIND');continue
        if e.get('schedule')!=expected[cid]:per[cid].append('EVENT_SCHEDULE_MISMATCH')
        if set(e)!={'event_kind','utc','call_id','schedule'}|({'result'}if kind=='FINISHED'else set()):per[cid].append('EVENT_SCHEMA_MISMATCH')
        if kind=='STARTED':
            if active is not None:errs.append('OVERLAPPED_OR_UNFINISHED_CALL')
            active=cid;starts.append(cid)
        else:
            if active!=cid:errs.append('FINISH_WITHOUT_MATCHED_ACTIVE_START')
            active=None;finishes.append(cid)
            if e.get('result')!=byid.get(cid):per[cid].append('FINISHED_RESULT_MISMATCH')
    if starts!=[e['call_id']for e in schedule][:len(starts)]:errs.append('START_ORDER_MISMATCH')
    if len(starts)!=len(set(starts))or len(finishes)!=len(set(finishes)):errs.append('DUPLICATE_ATTEMPT')
    for cid in expected:
        kinds=[e.get('event_kind')for e in events if e.get('call_id')==cid]
        if kinds!=['STARTED','FINISHED']:per[cid].append('MISSING_OR_INVALID_START_FINISH_SEQUENCE')
        if cid not in byid:per[cid].append('MISSING_RESULT')
        elif byid[cid].get('schedule')!=expected[cid]:per[cid].append('RESULT_SCHEDULE_MISMATCH')
    return {'status':'PASS'if not errs and not any(per.values())else'INCOMPLETE_OR_INVALID','errors':errs,'planned_denominator':len(schedule),'observed_records':len(items),'observed_events':len(events),'started':len(starts),'finished':len(finishes),'calls':[{'call_id':cid,'errors':errors,'ledger_valid':not errs and not errors}for cid,errors in per.items()]},byid

def blank(status='INVALID_OUTPUT'):
    return {'status':status,'valid_record':False,'valid_feasible':False,'cost':None,'vehicles':None,'errors':[]}
def inspect_new(p,entry,item,ledger_errors,matrix_sha,output_base=None):
    out=blank('MISSING_RESULT'if item is None else item.get('status')if item.get('status')in('WALL_TIMEOUT','PROCESS_FAILURE_OR_CPU_LIMIT','CALL_ERROR_UNDETERMINED')else'INVALID_OUTPUT')
    out.update(call_id=entry['call_id'],instance_id=entry['instance_id'],seed=entry['seed'],arm=entry['arm'],budget=250)
    answer=None
    if item is None:out['errors']=['MISSING_RESULT',*ledger_errors];return out,answer
    try:
        require(not ledger_errors,'ledger: '+repr(ledger_errors))
        require(item.get('call_id')==entry['call_id']and item.get('schedule')==entry,'record schedule')
        payload={k:p[k]for k in('coordinates','demands','capacity','K')};payload.update(seed=entry['seed'],max_iterations=250)
        require(item.get('payload_sha256')==hashlib.sha256(compact(payload)).hexdigest(),'original payload identity')
        for key in('stdout','stderr'):
            path=(ROOT/item[key]).resolve();wanted=((output_base or ROOT/'raw/calls')/f"{entry['call_id']}.{key}").resolve()
            require(path==wanted and sha(path)==item[key+'_sha256'],'exact output path/hash')
        require(item.get('process_spawned')is True and item.get('child_reaped')is True and item.get('returncode')==0,'process success/reap')
        require(item.get('status')in('UNREVIEWED_PROCESS_SUCCESS','UNREVIEWED_INFEASIBLE'),'process outcome')
        answer=load(ROOT/item['stdout']);out.update(answer_check(p,answer,entry['seed'],250,matrix_sha))
        require(item['status']==('UNREVIEWED_PROCESS_SUCCESS'if out['valid_feasible']else'UNREVIEWED_INFEASIBLE'),'process/native feasibility agreement')
        out['valid_record']=True
    except Exception as e:
        out.update(valid_record=False,valid_feasible=False,cost=None,vehicles=None);out['errors'].append(str(e))
        if out['status']in('FEASIBLE','NO_FEASIBLE_INCUMBENT_WITHIN_BUDGET')or(out['status']=='INVALID_OUTPUT'and answer is None):out['status']='INVALID_OUTPUT_OR_LEDGER'
    return out,answer

def pair(a,b):
    ok=a['valid_feasible']and b['valid_feasible'];return {'valid_pair':ok,'delta_cost':b['cost']-a['cost']if ok else None,'relative_delta_pct':100*(b['cost']-a['cost'])/a['cost']if ok else None,'delta_vehicles':b['vehicles']-a['vehicles']if ok else None}
def four(iid,seed,cells):
    x=pair(cells['standard25'],cells['capped25']);y=pair(cells['standard250'],cells['capped250']);ok=x['valid_pair']and y['valid_pair']
    return {'instance_id':iid,'seed':seed,'cells':cells,'paired25':x,'paired250':y,'valid_all_four':ok,'interaction_delta_cost':y['delta_cost']-x['delta_cost']if ok else None,'interaction_relative_pp':y['relative_delta_pct']-x['relative_delta_pct']if ok else None,'interaction_delta_vehicles':y['delta_vehicles']-x['delta_vehicles']if ok else None,'budget_effects':{arm:cells[arm+'250']['cost']-cells[arm+'25']['cost']if cells[arm+'25']['valid_feasible']and cells[arm+'250']['valid_feasible']else None for arm in('standard','capped')}}
def metric(vals,n,conditional):
    valid=[v for v in vals if v is not None];complete=len(valid)==n;ok=bool(valid)and(conditional or complete)
    return {'mean':statistics.mean(valid)if ok else None,'median':statistics.median(valid)if ok else None,'n':len(valid),'planned_denominator':n,'complete':complete,'conditional':conditional}
def summarize(rows):
    n=len(rows);out={'planned_pairs':n,'planned_cells':4*n,'feasibility':{},'complete_primary':{},'conditional_common_success':{}}
    primary=out['complete_primary'];conditional=out['conditional_common_success']
    for key in CELL_NAMES:
        c=[r['cells'][key]for r in rows];out['feasibility'][key]={'feasible':sum(x['valid_feasible']for x in c),'planned_denominator':n,'statuses':dict(sorted(Counter(x['status']for x in c).items()))}
        primary[key+'_cost']=metric([x['cost']if x['valid_feasible']else None for x in c],n,False)
    for key in('paired25','paired250'):
        for name in('delta_cost','relative_delta_pct','delta_vehicles'):
            vals=[r[key][name]for r in rows];primary[key+'_'+name]=metric(vals,n,False);conditional[key+'_'+name]=metric(vals,n,True)
        good=[r[key]['delta_cost']for r in rows if r[key]['valid_pair']]
        conditional[key+'_directions']={'capped_lower':sum(x<0 for x in good),'equal':sum(x==0 for x in good),'capped_higher':sum(x>0 for x in good)}
    common=[r for r in rows if r['valid_all_four']];out['all_four_common_success_count']=len(common)
    for name in('interaction_delta_cost','interaction_relative_pp','interaction_delta_vehicles'):
        vals=[r[name]for r in rows];primary[name]=metric(vals,n,False);conditional[name]=metric(vals,n,True)
    conditional['same_all_four_subset']={'n':len(common),'planned_denominator':n}
    for key in('paired25','paired250'):
        for name in('delta_cost','relative_delta_pct','delta_vehicles'):conditional['same_all_four_subset'][key+'_'+name]=metric([r[key][name]for r in common],n,True)
    out['status_transitions']={}
    for arm in('standard','capped'):
        vals=[r['budget_effects'][arm]for r in rows];primary[arm+'_budget_effect']=metric(vals,n,False);conditional[arm+'_budget_effect']=metric(vals,n,True)
        out['status_transitions'][arm]={'planned_denominator':n,'counts':dict(Counter(r['cells'][arm+'25']['status']+' -> '+r['cells'][arm+'250']['status']for r in rows))}
    return out

def prefix(old,new,a,b):
    out={'instance_id':a['instance_id'],'seed':a['seed'],'arm':a['arm'],'status':'UNAVAILABLE','equal':None,'first_difference':None,'fields':list(FIELDS),'time_excluded':True,'historical_feasible':a['valid_feasible'],'new_feasible':b['valid_feasible']}
    if not(a['valid_record']and b['valid_record']):return out
    same=all(old[k]==new[k]for k in('seed','native_model_parameters','default_solve_params','model_matrix_sha256','resource_limits','solver','version','algorithm'))
    out['same_input_seed_model_solver_identity']=same
    if not same:out['status']='IDENTITY_MISMATCH';return out
    x=old['stats'];y=new['stats'][:25]
    if len(x)!=25 or len(y)!=25:return out
    out.update(equal=x==y,status='SAME'if x==y else'DIFFERENT',old25_sha256=digest(x),new250_prefix25_sha256=digest(y))
    for i,(u,v)in enumerate(zip(x,y),1):
        if u!=v:out['first_difference']={'iteration':i,'fields':{k:{'old25':u[k],'new250':v[k]}for k in FIELDS if u[k]!=v[k]}};break
    return out

def results():
    receipt=gate();schedule=load(ROOT/'freeze/SCHEDULE.json');tasks=load(ROOT/'freeze/TASKS.json');history=load(ROOT/'freeze/HISTORICAL_CELLS.json')['cells']
    require(len(schedule)==len(history)==72 and len(tasks)==12,'frozen factorial size')
    items,ie=lines(ROOT/'raw/results.jsonl');events,ee=lines(ROOT/'raw/attempts.jsonl');ledger,byid=check_ledger(schedule,events,items,ie+ee)
    per_ledger={x['call_id']:x['errors']+ledger['errors']for x in ledger['calls']}
    oldz={}
    for arm,(stage,name,wanted)in STAGES.items():
        r=load(ROOT/f'provenance/{stage}_FINAL_DRIVE_RECEIPT.json');require(sha(r['download_path'])==r['sha256']==wanted,'old FINAL retained actual bytes');oldz[arm]=zipfile.ZipFile(r['download_path'])
    cells={};answers={};inputs={};matrix={}
    for t in tasks:
        iid=t['instance_id'];p=vrp(ROOT/'input'/f'{iid}.vrp');rr,c=sol(ROOT/'references'/f'{iid}.sol');require(len(rr)==t['K_ref'],'true reference K');route_check({**p,'K':t['K_ref']},rr,c)
        require(p==load(ROOT/'input'/f'{iid}.json'),'original standard input');inputs[iid]=p;matrix[iid]=hashlib.sha256(compact([[edge(a,b)for b in p['coordinates']]for a in p['coordinates']])).hexdigest()
    for h in history:
        iid,seed,arm=h['instance_id'],h['seed'],h['arm'];name=STAGES[arm][1];raw=(ROOT/h['output_file']).read_bytes()
        require(raw==oldz[arm].read(name+'/raw/calls/'+h['call_id']+'.stdout')and hashlib.sha256(raw).hexdigest()==h['stdout_sha256'],'historical exact archived member')
        answer=json.loads(raw);p={**inputs[iid],'K':h['K']};a=answer_check(p,answer,seed,25,matrix[iid]);a.update(valid_record=True,errors=[],instance_id=iid,seed=seed,arm=arm,budget=25,call_id=h['call_id'])
        key=(iid,seed,arm,25);cells[key]=a;answers[key]=answer
    for e in schedule:
        iid,seed,arm=e['instance_id'],e['seed'],e['arm'];key=(iid,seed,arm,250)
        cells[key],answers[key]=inspect_new({**inputs[iid],'K':e['K']},e,byid.get(e['call_id']),per_ledger[e['call_id']],matrix[iid])
    rows=[]
    for t in tasks:
        for seed in range(3):
            iid=t['instance_id'];c={('standard'if arm=='standard_n_clients'else'capped')+str(b):cells[iid,seed,arm,b]for arm in STAGES for b in(25,250)};rows.append(four(iid,seed,c))
    prefixes=[prefix(answers[h['instance_id'],h['seed'],h['arm'],25],answers[h['instance_id'],h['seed'],h['arm'],250],cells[h['instance_id'],h['seed'],h['arm'],25],cells[h['instance_id'],h['seed'],h['arm'],250])for h in history]
    per_instance=[{'instance_id':t['instance_id'],'K_ref':t['K_ref'],'n_customers':t['n_customers'],**summarize([r for r in rows if r['instance_id']==t['instance_id']])}for t in tasks]
    require(len(rows)==36 and len(cells)==144 and len(prefixes)==72,'no lost denominator')
    for z in oldz.values():z.close()
    out={'status':'SAVED_EVIDENCE_AUDITED','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'raw_archive_sha256':receipt['sha256'],'frozen_files_sha256':receipt['frozen_files_sha256'],'optimizer_calls_by_reviewer':0,'planned_calls':72,'historical_cells':72,'planned_cells':144,'observed_records':len(items),'started':ledger['started'],'finished':ledger['finished'],'spawned':sum(i.get('process_spawned')is True for i in items),'full_ledger':ledger['status']=='PASS','ledger':ledger,'rows':rows,'overall':summarize(rows),'per_instance':per_instance,'prefix':prefixes,'prefix_counts':dict(Counter(x['status']for x in prefixes)),'method':'Original VRP/SOL parsing, exact integer sqrt edge rounding, all native fields/activities/capacities/fleet, complete default params, actual downloaded archive members, payloads, full ordered lifecycle, 144 cells, six-field timing-free prefix observation. No author validator/endpoint or solver imports.'}
    save_exclusive(ROOT/'independent_supervision/results/SAVED_BUDGET_AUDIT.json',out)
    print(json.dumps({k:out[k]for k in('status','started','finished','spawned','full_ledger','prefix_counts','overall')}))

def equal(a,b,label):
    if isinstance(a,float):require(type(b)in(int,float)and math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-12),label)
    elif isinstance(a,dict):
        require(isinstance(b,dict),label)
        for k,v in a.items():require(k in b,label+'.'+k);equal(v,b[k],label+'.'+k)
    elif isinstance(a,list):
        require(isinstance(b,list)and len(a)==len(b),label)
        for i,(x,y)in enumerate(zip(a,b)):equal(x,y,f'{label}[{i}]')
    else:require(a==b,label)

def report():
    receipt=gate();audit=load(ROOT/'independent_supervision/results/SAVED_BUDGET_AUDIT.json');summary=load(ROOT/'reports/SUMMARY.json')
    require(audit['raw_archive_sha256']==receipt['sha256']==summary['raw_archive_sha256'],'RAW report binding')
    require(audit['frozen_files_sha256']==summary['frozen_files_sha256'],'freeze report binding')
    require(summary['new_planned_calls']==summary['historical_cells_reused']==72 and summary['full_table_cells']==144,'report denominators')
    equal(audit['overall'],summary['overall'],'overall');equal(audit['per_instance'],load(ROOT/'reports/PER_INSTANCE.json'),'per instance')
    rows=load(ROOT/'reports/FOUR_CELL_RESULTS.json');require(len(rows)==36,'report all36 rows')
    for own,theirs in zip(audit['rows'],rows):
        equal({k:own[k]for k in('instance_id','seed','paired25','paired250','valid_all_four','interaction_delta_cost','interaction_relative_pp','interaction_delta_vehicles','budget_effects')},theirs,'four-cell metrics')
        for key in CELL_NAMES:equal({k:own['cells'][key][k]for k in('status','valid_record','valid_feasible','cost','vehicles')},theirs['cells'][key],key)
    equal(audit['prefix'],load(ROOT/'reports/PREFIX_COMPARISON.json'),'prefix')
    text=(ROOT/'reports/REPORT_ZH.txt').read_text()
    for phrase in('at-most-K_ref','phase','可行域','repeat A','共同成功','36','CPU'):require(phrase in text,'report qualification '+phrase)
    for choices in(('非同期','跨时间'),('未找到可行','未返回可行'),('文件名k','文件名中的k')):require(any(p in text for p in choices),'report qualification '+repr(choices))
    out={'status':'PASS_CANDIDATE_FOR_PRIMARY_SUPERVISOR_SIGNATURE','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'raw_archive_sha256':receipt['sha256'],'frozen_files_sha256':receipt['frozen_files_sha256'],'report_sha256':sha(ROOT/'reports/REPORT_ZH.txt'),'summary_sha256':sha(ROOT/'reports/SUMMARY.json'),'independent_audit_sha256':sha(ROOT/'independent_supervision/results/SAVED_BUDGET_AUDIT.json'),'all144_cells36_rows12_instances72_prefixes_independently_checked':True,'interpretation_qualifications_checked':True,'optimizer_calls_by_reviewer':0}
    save_exclusive(ROOT/'independent_supervision/results/FINAL_REPORT_CANDIDATE.json',out);print(json.dumps(out))
if __name__=='__main__':
    resource.setrlimit(resource.RLIMIT_CPU,(60,60));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2));signal.alarm(120)
    require(sys.argv[1:]in(['--results'],['--report']),'usage --results or --report')
    results()if sys.argv[1]=='--results'else report()
