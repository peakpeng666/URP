"""Bounded one-use audit launcher. Preserves partial output/failure. No /usr/bin/time."""
from pathlib import Path
import datetime,json,subprocess,sys,time,resource
ROOT=Path(__file__).resolve().parents[2]
def save(p,x):
 with p.open('x')as f:json.dump(x,f,indent=2);f.write('\n')
def main():
 if not __debug__:raise RuntimeError('assertions disabled')
 if sys.argv[1:]not in(['--results'],['--report']):raise ValueError('usage --results or --report')
 stage='SAVED_AUDIT'if sys.argv[1]=='--results'else'REPORT_AUDIT';d=ROOT/'independent_supervision/results';now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
 save(d/(stage+'_ATTEMPT.json'),{'utc':now(),'no_retry':True,'CPU_seconds':60,'AS_bytes':512*1024**2,'wall_seconds':120,'argv':sys.argv[1:]})
 p=None;timeout=False;error=None;start=time.monotonic();before=resource.getrusage(resource.RUSAGE_CHILDREN)
 try:
  with(d/(stage+'.stdout')).open('xb')as out,(d/(stage+'.stderr')).open('xb')as err:
   p=subprocess.Popen([sys.executable,'-B',str(ROOT/'independent_supervision/source/audit_saved_budget.py'),sys.argv[1]],stdout=out,stderr=err)
   try:p.wait(timeout=120)
   except subprocess.TimeoutExpired:timeout=True;p.kill();p.wait()
 except Exception as e:error=repr(e)
 finally:
  if p and p.poll()is None:p.kill();p.wait()
 after=resource.getrusage(resource.RUSAGE_CHILDREN);result={'utc':now(),'returncode':p.returncode if p else None,'timeout':timeout,'error':error,'wall_seconds':time.monotonic()-start,'child_cpu_seconds':after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime,'maxrss_KiB':after.ru_maxrss,'output_preserved':True}
 save(d/(stage+'_EXECUTION.json'),result);print(json.dumps(result))
 if error or timeout or not p or p.returncode:raise SystemExit(1)
if __name__=='__main__':main()
