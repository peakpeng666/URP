"""No optimizer: own audit checks from already saved invented outputs and JSON faults."""
from audit_saved_budget import *
import copy, importlib.util

def rejected(f):
    try:f()
    except Exception:return True
    return False

def main(output_name="INDEPENDENT_SAVED_SELFTEST.json"):
    start=time.process_time();smoke=load(ROOT/'selftests/SUPERVISOR_INTEGRATION.json');replay=load(ROOT/'selftests/FINAL_ENDPOINT_SAVED_REPLAY.json')
    records=smoke['records'];schedule=smoke['schedule'];events,ee=lines(ROOT/'selftests/integration/attempts.jsonl');items,ie=lines(ROOT/'selftests/integration/results.jsonl')
    ledger,_=check_ledger(schedule,events,items,ie+ee);require(ledger['status']=='PASS','actual saved production-schema full replay')
    require(len(items)==6 and len(events)==12,'six items including malformed payload guard')
    checked=[]
    for v in records[:5]:
        p=v['fixture'];item=v['record'];e=item['schedule'];a=load(ROOT/item['stdout'])
        for key in('stdout','stderr'):require(sha(ROOT/item[key])==item[key+'_sha256'],'saved fixture file hash')
        m=hashlib.sha256(compact([[edge(x,y)for y in p['coordinates']]for x in p['coordinates']])).hexdigest()
        got,answer=inspect_new(p,e,item,[],m,ROOT/'selftests/integration/calls')
        require(got['valid_record']and got['status']==v['audit']['status'],'full own audit on saved synthetic')
        equal({k:got[k]for k in('status','valid_record','valid_feasible','cost','vehicles')},v['audit'],'fixture outcomes')
        checked.append({'call_id':e['call_id'],'status':got['status'],'sha256':sha(ROOT/item['stdout'])})
    f=records[2];p=f['fixture'];item=f['record'];e=item['schedule'];a=load(ROOT/item['stdout']);faults=[]
    for label,mut in [('COST',lambda x:x.update(reported_cost=x['reported_cost']+1)),('BUDGET',lambda x:x.update(max_iterations=25)),('FLEET',lambda x:x['native_model_parameters']['vehicle'].update(num_available=99)),('STATS_BOOL',lambda x:x['stats'][0].update(current_feas=1)),('NATIVE_ACTIVITY',lambda x:x['native_routes'][0]['activities'][1].update(idx=999)),('MATRIX',lambda x:x.update(model_matrix_sha256='0'*64)),('DEFAULT_PARAMS',lambda x:x.update(default_solve_params={})),('RESOURCE_LIMITS',lambda x:x['resource_limits']['effective'].update(CPU_seconds=[99,99])),('IO',lambda x:x.update(denied_io_events=['open']))]:
        bad=copy.deepcopy(a);mut(bad);require(rejected(lambda:answer_check(p,bad,e['seed'],250)),label+' rejected');faults.append(label)
    for status in('WALL_TIMEOUT','PROCESS_FAILURE_OR_CPU_LIMIT','CALL_ERROR_UNDETERMINED'):
        bad=copy.deepcopy(item);bad.update(status=status,returncode=-9);out,_=inspect_new(p,e,bad,[],None,ROOT/'selftests/integration/calls');require(out['status']==status and not out['valid_record']and out['cost']is None,'guard status kept');faults.append(status)
    out,_=inspect_new(p,e,None,['MISSING_RESULT'],None);require(out['status']=='MISSING_RESULT'and not out['valid_feasible'],'missing kept');faults.append('MISSING_RESULT')
    # Alter only JSON in memory: no logged_call, subprocess, worker, or optimization.
    overlap=copy.deepcopy(events);overlap[1],overlap[2]=overlap[2],overlap[1];require(check_ledger(schedule,overlap,items)[0]['status']!='PASS','overlap rejected');faults.append('INTERLEAVED_LEDGER')
    duplicate=copy.deepcopy(items)+[copy.deepcopy(items[0])];require(check_ledger(schedule,events,duplicate)[0]['status']!='PASS','duplicate result rejected');faults.append('DUPLICATE_RESULT')
    require(check_ledger(schedule,events[:-2],items[:-1])[0]['planned_denominator']==6,'missing ledger denominator');faults.append('MISSING_LIFECYCLE')
    require(check_ledger(schedule,events,items,['malformed line'])[0]['status']!='PASS','malformed ledger rejected');faults.append('MALFORMED_LEDGER')
    # Independent 144-cell table tests retain missing/invalid categories and null full metrics.
    good={'status':'FEASIBLE','valid_record':True,'valid_feasible':True,'cost':100,'vehicles':5,'errors':[]}
    failed=blank('MISSING_RESULT');rows=[four('INVENTED_'+str(i//3),i%3,{key:copy.deepcopy(good)for key in CELL_NAMES})for i in range(36)]
    rows[-1]=four('INVENTED_11',2,{**{key:copy.deepcopy(good)for key in CELL_NAMES},'capped25':failed})
    summary=summarize(rows);require(summary['planned_cells']==144 and summary['planned_pairs']==36 and summary['feasibility']['capped25']=={'feasible':35,'planned_denominator':36,'statuses':{'FEASIBLE':35,'MISSING_RESULT':1}},'missing full denominator')
    require(summary['complete_primary']['interaction_delta_cost']['mean']is None and summary['conditional_common_success']['interaction_delta_cost']['n']==35 and summary['complete_primary']['paired250_delta_cost']['mean']==0,'conditional vs primary')
    all_failed=summarize([four(str(i),0,{key:blank('MISSING_RESULT')for key in CELL_NAMES})for i in range(36)])
    require(all_failed['planned_cells']==144 and all_failed['all_four_common_success_count']==0 and all(v['mean']is None for v in all_failed['complete_primary'].values()),'all144 missing preserved')
    # Independent prefix uses all six fields only, including well-formed infeasible.
    new=copy.deepcopy(a);old=copy.deepcopy(new);old.update(max_iterations=25,num_iterations=25,stats=copy.deepcopy(new['stats'][:25]),stats_runtime_per_iteration=[999]*25)
    aa={**good,'instance_id':'INVENTED_TIGHT','seed':1,'arm':'at_most_K_ref'}
    require(prefix(old,new,aa,aa)['status']=='SAME','time fields excluded')
    new['stats'][2]['candidate_feas']=not new['stats'][2]['candidate_feas'];d=prefix(old,new,aa,aa);require(d['status']=='DIFFERENT'and d['first_difference']['iteration']==3,'first quality difference')
    require(prefix(old,None,aa,{**aa,'valid_record':False})['status']=='UNAVAILABLE','missing prefix')
    bad=copy.deepcopy(a);bad['seed']=99;require(prefix(old,bad,aa,aa)['status']=='IDENTITY_MISMATCH','identity gate')
    inf=records[4];a_inf=load(ROOT/inf['record']['stdout']);old_inf=copy.deepcopy(a_inf);old_inf.update(max_iterations=25,num_iterations=25,stats=a_inf['stats'][:25],stats_runtime_per_iteration=a_inf['stats_runtime_per_iteration'][:25]);ia=inf['audit'];require(prefix(old_inf,a_inf,ia,ia)['status']=='SAME','infeasible included in prefix')
    # Cross-check author metrics on a nonzero difference table with deliberately missing cells.
    sys.path.insert(0,str(ROOT/'source'));import endpoints
    for i,r in enumerate(rows):
        cells=copy.deepcopy(r['cells']);cells['standard25']['cost']=100+i;cells['capped25']['cost']=120+i if cells['capped25']['valid_feasible']else None;cells['standard250']['cost']=80+i;cells['capped250']['cost']=90+i
        rows[i]=four(r['instance_id'],r['seed'],cells);equal(rows[i],endpoints.four_cell_record(r['instance_id'],r['seed'],cells),'independent row interface')
    equal(summarize(rows),endpoints.summarize(rows),'independent summary interface')
    equal(prefix(old,new,aa,aa),endpoints.prefix_observation(old,new,aa,aa),'independent prefix interface')
    out={'status':'PASS','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'optimizer_calls_by_reviewer':0,'no_subprocess_by_test':True,'saved_production_events':len(events),'saved_production_items':len(items),'saved_invented_answers':checked,'negative_checks':faults,'all144_missing_denominator_tested':True,'conditional_vs_complete_primary_tested':True,'author_schema_match':True,'cpu_seconds_audit_only':time.process_time()-start,'source_sha256':{str(p.relative_to(ROOT)):sha(p)for p in sorted((ROOT/'independent_supervision/source').glob('*.py'))}}
    save_exclusive(ROOT/'independent_supervision/results'/output_name,out);print(json.dumps({k:out[k]for k in('status','saved_production_events','saved_production_items','negative_checks','cpu_seconds_audit_only')}))
if __name__=='__main__':
    resource.setrlimit(resource.RLIMIT_CPU,(60,60));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2));signal.alarm(120);main()
