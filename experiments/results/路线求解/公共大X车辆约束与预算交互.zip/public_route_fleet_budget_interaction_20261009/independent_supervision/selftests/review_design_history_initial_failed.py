"""Read-only design and historical-byte review. Does not import or call a solver."""
from original_primitives import *
from saved_answer import answer_check, compact
import resource, signal, time
STAGES={'standard_n_clients':('STANDARD25','public_route_fixed_iterations_repro_20261009','b44064b50860847a929e0fe5278e8b853f40f2f0ab5d03ed26c3d6471cc1b895'),'at_most_K_ref':('CAPPED25','public_route_fleet_constraint_effects_20261009','2ee97cde88670683515176ee697b63ee6cc646bf1b503b6ba6b3549dab1666be')}
def inspect():
    tasks=load(ROOT/'freeze/TASKS.json');schedule=load(ROOT/'freeze/SCHEDULE.json');history=load(ROOT/'freeze/HISTORICAL_CELLS.json')['cells'];protocol=load(ROOT/'freeze/PROTOCOL.json')
    require(len(tasks)==12 and len(schedule)==len(history)==72,'12 tasks and 72/72 cells')
    require([t['selection_slot'] for t in tasks]==list(range(1,13)),'task selection order')
    require([t['K_ref'] for t in tasks]==[26,14,13,19,16,11,21,13,72,39,21,155],'actual reference K list')
    target={(t['instance_id'],s,arm) for t in tasks for s in range(3) for arm in STAGES}
    require(len({e['call_id'] for e in schedule})==72,'unique calls')
    for data,label in [(schedule,'new'),(history,'history')]:require(len({(e['instance_id'],e['seed'],e['arm'])for e in data})==72 and {(e['instance_id'],e['seed'],e['arm'])for e in data}==target,label+' factorial')
    pos=0
    for t in tasks:
        for seed in range(3):
            pi=pos//2+1;arms=list(STAGES) if pi%2 else list(reversed(STAGES))
            for within,arm in enumerate(arms,1):
                e=schedule[pos];pos+=1
                require((e['instance_id'],e['seed'],e['arm'],e['K'],e['max_iterations'],e['pair_index'],e['within_pair_order'],e['schedule_index'])==(t['instance_id'],seed,arm,t['standard_K' if arm=='standard_n_clients' else 'K_ref'],250,pi,within,pos),'full counterbalanced schedule')
    require(protocol['new_calls']==protocol['historical_cells']==72 and protocol['new_budget']==250 and protocol['historical_budget']==25,'protocol budgets')
    archives={};zips={};members={}
    for arm,(stage,name,wanted) in STAGES.items():
        r=load(ROOT/f'provenance/{stage}_FINAL_DRIVE_RECEIPT.json')
        require(r['owner_only']is True and r['shared']is False and r['download_byte_identical']is True and r['remote_readback_sha256_verified']is True,'historical owner-only receipt')
        require(sha(r['source'])==sha(r['download_path'])==r['sha256']==r['download_sha256']==wanted,'historical actual archive bytes')
        z=zipfile.ZipFile(r['download_path']);zips[arm]=z
        require(len(z.namelist())==len(set(z.namelist())),'unique archive members')
        # Actual downloaded FINAL is the source of retained input/model/environment/output evidence.
        frozen=json.loads(z.read(name+'/freeze/FROZEN_FILES.json'))
        require(hashlib.sha256(z.read(name+'/freeze/FROZEN_FILES.json')).hexdigest()==r['frozen_files_sha256'],'historical freeze member')
        for rel,meta in frozen['files'].items():
            b=z.read(name+'/'+rel);require(len(b)==meta['bytes'] and hashlib.sha256(b).hexdigest()==meta['sha256'],'historical frozen member '+rel)
        archives[arm]={'sha256':wanted,'download_path':r['download_path'],'frozen_members_verified':len(frozen['files']),'members':len(z.namelist())}
        for rel in ['source/worker.py','source/run_once.py','environment/RUNTIME.json','environment/DEFAULT_SOLVE_PARAMS.json']:
            require(z.read(name+'/'+rel)==(ROOT.parent/name/rel).read_bytes(),'old source environment member '+rel)
        for rel in ['environment/RUNTIME.json','environment/DEFAULT_SOLVE_PARAMS.json']:
            require(z.read(name+'/'+rel)==(ROOT/rel).read_bytes(),'same runtime/default bytes '+rel)
    # Fixed historical selection must be exact A, not outcome-adaptive A/B selection.
    fixed=json.loads(zips['standard_n_clients'].read(STAGES['standard_n_clients'][1]+'/reports/FIXED_ITERATION_BASELINE.json'))
    fixed={(v['instance_id'],v['seed']):v for v in fixed['cases']}
    saved_rows=[];refs=[]
    for t in tasks:
        ident=t['instance_id'];p=vrp(ROOT/'input'/f'{ident}.vrp');rr,cost=sol(ROOT/'references'/f'{ident}.sol')
        require(len(rr)==t['K_ref']==t['K'] and p['K']==t['standard_K']==t['n_customers'],'reference nonempty route K/customer K')
        p['K']=t['K_ref'];require(p==load(ROOT/'input'/f'{ident}.json'),'original VRP derived input')
        v=route_check(p,rr,cost);refs.append({'instance_id':ident,'K_ref':len(rr),'original_SOL_cost':cost,'maximum_load':max(v['loads']),'capacity':p['capacity'],'independently_feasible':True})
        for arm,(_,name,_) in STAGES.items():
            z=zips[arm]
            for kind,ext,key in [('input','vrp','source_instance_sha256'),('references','sol','source_reference_sha256')]:
                f=ROOT/kind/f'{ident}.{ext}';require(sha(f)==t[key] and z.read(name+'/'+kind+'/'+f.name)==f.read_bytes(),'source exact archive identity')
            old_input=json.loads(z.read(name+'/input/'+ident+'.json'));require(old_input=={**p,'K':t['standard_K'] if arm=='standard_n_clients' else t['K_ref']},'old/new input only prescribed K')
        matrix_sha=hashlib.sha256(compact([[edge(a,b) for b in p['coordinates']] for a in p['coordinates']])).hexdigest()
        for h in [h for h in history if h['instance_id']==ident]:
            arm=h['arm'];name=STAGES[arm][1];key='standard_K'if arm=='standard_n_clients'else'K_ref';require(h['budget']==25 and h['K']==t[key],'historical K/budget')
            if arm=='standard_n_clients':
                b=fixed[ident,h['seed']];require(b['selected_repeat']=='A' and b['call_A']==h['call_id'] and b['pair_status']=='PASS','fixed A exact selection')
            else:require(h['call_id']==f"X{t['selection_slot']:02}_s{h['seed']}_Kref",'capped unique prior call')
            raw=zips[arm].read(name+'/raw/calls/'+h['call_id']+'.stdout')
            require(raw==(ROOT/h['output_file']).read_bytes()==Path(h['source_stdout']).read_bytes(),'old output from real downloaded FINAL')
            require(hashlib.sha256(raw).hexdigest()==h['stdout_sha256'],'historical saved hash')
            a=json.loads(raw);r=answer_check({**p,'K':t[key]},a,h['seed'],25,matrix_sha)
            require((r['status'],r['valid_feasible'],r['cost'],r['vehicles'])==(h['prior_audited_status'],h['prior_valid_feasible'],h['prior_cost'],h['prior_vehicles']),'historical independent outcomes')
            saved_rows.append({'instance_id':ident,'seed':h['seed'],'arm':arm,'budget':25,'call_id':h['call_id'],'stdout_sha256':h['stdout_sha256'],**r})
    failures=[r for r in saved_rows if not r['valid_feasible']]
    require(len(failures)==3 and all(r['instance_id']=='X-n524-k153' and r['arm']=='at_most_K_ref' and r['saved_route_audit']['feasibility_errors']==['CAPACITY'] for r in failures),'all three historical capacity failures preserved')
    oldworker=(ROOT.parent/STAGES['at_most_K_ref'][1]/'source/worker.py').read_text();worker=(ROOT/'source/worker.py').read_text()
    normalized=oldworker.replace("payload['max_iterations'] == 25", "payload['max_iterations'] == 250").replace('26th callback','251st callback').replace('25 counted ILS','250 counted ILS').replace('Exactly25 completed','Exactly250 completed')
    require(normalized==worker,'entire worker only allowed budget assertion and prose changes')
    require(funcs(ROOT.parent/STAGES['at_most_K_ref'][1]/'source/run_once.py')['child_environment']==funcs(ROOT/'source/run_once.py')['child_environment'],'child environment AST unchanged')
    runtime=load(ROOT/'environment/RUNTIME.json');require(sha(Path(runtime['python_executable']).resolve())==runtime['python_binary_sha256'],'runtime interpreter')
    for f in runtime['installed_distribution_files']:require(Path(f['path']).stat().st_size==f['bytes'] and sha(f['path'])==f['sha256'],'installed source/runtime bytes')
    for e in load(ROOT/'environment/OFFICIAL_SOURCE_AUDIT.json')['evidence']:require(sha(e['installed_source'])==sha(ROOT/e['local_evidence'])==e['sha256'],'official algorithm retained source bytes')
    oldfiles=load(ROOT/'freeze/OLD_FILES_BEFORE.json')['files']
    for path,meta in oldfiles.items():require(Path(path).stat().st_size==meta['bytes'] and sha(path)==meta['sha256'],'old unchanged '+path)
    require(not list((ROOT/'raw').rglob('*')),'no formal call')
    for z in zips.values():z.close()
    return {'status':'DESIGN_HISTORY_PASS_PENDING_SOURCE_SELFTEST_AND_SIGNATURE','optimizer_calls_by_reviewer':0,'historical_archives':archives,'reference_feasibility':refs,'historical_cells_audited':72,'historical_statuses':{arm:dict(Counter(r['status']for r in saved_rows if r['arm']==arm))for arm in STAGES},'rows':saved_rows,'installed_distribution_files_verified':len(runtime['installed_distribution_files']),'old_files_verified_unchanged':len(oldfiles),'whole_worker_allowed_change_verified':True,'selected_historical_repeat':'A only; no best selection','reviewed_source_sha256':{str(p.relative_to(ROOT)):sha(p)for p in sorted((ROOT/'source').glob('*.py'))}}
if __name__=='__main__':
    resource.setrlimit(resource.RLIMIT_CPU,(60,60));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2));signal.alarm(120)
    t=time.process_time();out=inspect();out['cpu_seconds_audit_only']=time.process_time()-t;out['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (ROOT/'independent_supervision/results/DESIGN_HISTORY_REVIEW.json').open('x')as f:json.dump(out,f,indent=2);f.write('\n')
    print(json.dumps({k:out[k] for k in ('status','historical_cells_audited','historical_statuses','cpu_seconds_audit_only')}))
