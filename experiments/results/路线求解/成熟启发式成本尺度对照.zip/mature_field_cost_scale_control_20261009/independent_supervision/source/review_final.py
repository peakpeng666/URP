"""Final saved-scale report comparison with independently audited216 slots."""
from audit_scale import *

def compare(a,s):
    require(a['status']=='SAVED_EVIDENCE_AUDITED'and len(a['rows'])==len(s['rows'])==216,'216 rows')
    require(s['planned_formal_slots']==216 and s['planned_per_arm']==72 and s['planned_per_proxy_per_arm']==36 and s['field_denominator']==12,'complete denominators')
    require(s['valid_feasible_slots']==a['valid_feasible_slots'],'valid count')
    for x,y in zip(a['rows'],s['rows']):
        for k in ROW_KEYS:require(type(x[k])is type(y[k])and x[k]==y[k],'row '+k)
        for k in('record_verified','routing_violation','diagnostic_base_E','diagnostic_base_G','observations'):equal(x[k],y[k],'row diagnostic '+k)
        if x['record_verified']:
            for k in('routes','loads'):require(x[k]==y[k],'saved route '+k)
    for k in SECTIONS:equal(a[k],s[k],k)
    require(s['formal_known_spawned']==a['ledger']['known_spawned']and s['formal_unknown_spawned_slots']==a['ledger']['unknown_spawned_slots'],'actual call accounting')
    require(s['toy_solver_calls']==s['toy_model_instances']==4 and s['new_solver_calls_in_report']==s['new_native_constructions_in_report']==0,'no additional calls')
    require(s['historical_reference_cells']==72 and s['historical_cells_in_primary']==0,'history exclusion from primary')
    return True

def main():
    resource.setrlimit(resource.RLIMIT_CPU,(15,15));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2));signal.alarm(60);receipt=gate();c=time.process_time();w=time.monotonic();a=load(ROOT/'independent_supervision/results/SAVED_SCALE_AUDIT.json');s=load(ROOT/'reports/SUMMARY.json')
    for x in(a,s):require(x['frozen_files_sha256']==receipt['frozen_files_sha256']and x['raw_archive_sha256']==receipt['sha256'],'source identity')
    require(s['independent_saved_audit_sha256']==sha(ROOT/'independent_supervision/results/SAVED_SCALE_AUDIT.json'),'report audit bytes');compare(a,s);text=(ROOT/'reports/REPORT_ZH.txt').read_text()
    for phrase in('216','72','36','250','初始化','尺度','条件','泛化','罚后','因果'):require(phrase in text,'report limit '+phrase)
    result={'status':'PASS','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'frozen_files_sha256':receipt['frozen_files_sha256'],'raw_archive_sha256':receipt['sha256'],'report_sha256':sha(ROOT/'reports/REPORT_ZH.txt'),'summary_sha256':sha(ROOT/'reports/SUMMARY.json'),'independent_audit_sha256':sha(ROOT/'independent_supervision/results/SAVED_SCALE_AUDIT.json'),'planned_formal_slots':216,'valid_feasible_slots':a['valid_feasible_slots'],'new_solver_calls':0,'new_native_constructions':0,'resources':{'cpu_seconds':time.process_time()-c,'wall_seconds':time.monotonic()-w}}
    save_exclusive(ROOT/'independent_supervision/results/FINAL_REPORT_REVIEW.json',result);print(json.dumps(result))
if __name__=='__main__':main()
