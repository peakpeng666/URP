"""One frozen saved216 audit: native matrix scale, feasibility, public observer, fixed denominators."""
from scale_contract import *
from scale_summary import summarize,history,ROW_KEYS
import itertools,resource,signal,time
LEGACY_SHA='c389ceafdf85228179e9ae393057e5f0fff5355a5b6f8a7e355874c1903e0c9b'
SECTIONS=('overall','by_proxy','per_field','paired_rows','triple_rows','fresh_A_legacy250_diagnostics','fresh_A_legacy250_diagnostic_counts')

def blank(e,status):
    r=dict(e);r.update(valid=False,failure=None,raw_status=status,record_verified=False,routing_violation=None,base_E=None,base_G=None,normalized_own_cost=None,diagnostic_base_E=None,diagnostic_base_G=None,own_gap_mm=None,own_gap_percent=None,exact_hit=False,G_realized_excess_mm=None,E_offset_from_lex_reference_mm=None,E_optimal_tie_difference_mm=None,offset_is_search_error=False,observations=None,saved_G_path_length_m=None,saved_G_path_legs=None);return r

def historical_inputs(check_archive=False):
    d=ROOT/'historical_reference';meta=load(d/'EXACT_ARCHIVE_IDENTITY.json');require(meta['archive_sha256']==LEGACY_SHA,'historical archive identity')
    require(sha(d/'ALL72_LEGACY250_ROWS.json')==meta['derived_rows_sha256']and sha(d/'ALL72_LEGACY250_OUTPUTS.json')==meta['derived_outputs_sha256'],'historical frozen extraction bytes')
    rows=load(d/'ALL72_LEGACY250_ROWS.json');answers=load(d/'ALL72_LEGACY250_OUTPUTS.json');require(rows['diagnostic_only']is True and answers['diagnostic_only']is True,'history diagnostic only')
    oldrows={(r['instance_id'],r['seed'],r['proxy']):r for r in rows['rows']};oldanswers={(r['entry']['instance_id'],r['entry']['seed'],r['entry']['proxy']):r['answer']for r in answers['rows']}
    expected={(f,s,p)for f in FIELDS for s in range(3)for p in('E','G')};require(len(rows['rows'])==len(answers['rows'])==72 and set(oldrows)==set(oldanswers)==expected,'72 history full cells')
    if check_archive:
        require(sha(meta['archive_path'])==LEGACY_SHA,'original closed legacy archive bytes')
        with zipfile.ZipFile(meta['archive_path'])as z:
            base='mature_field_exact_gap_20261009/';summary=json.loads(z.read(base+'reports/SUMMARY.json'));index={(r['instance_id'],r['seed'],r['proxy']):r for r in summary['rows']if r['max_iterations']==250}
            require(index==oldrows,'legacy exact source rows')
            for e in meta['all72_source_stdout']:
                b=z.read(e['archive_member']);require(len(b)==e['bytes']and hashlib.sha256(b).hexdigest()==e['sha256'],'legacy raw member identity');s=e['schedule'];key=(s['instance_id'],s['seed'],s['proxy']);require(json.loads(b)==oldanswers[key],'legacy extracted output')
    return oldrows,oldanswers

def collect(schedule,slots,items,events,errors,outer,problems,truth,params,oldrows,oldanswers):
    ledger,by=audit_ledger(schedule,events,items,slots,errors,outer);rows=[];answers={}
    for e in schedule:
        cid=e['call_id'];slot=by.get(cid,{});r=blank(e,slot.get('status','MISSING_RESULT'));answer=None
        try:
            require(slot.get('status')in('UNREVIEWED_PROCESS_SUCCESS','UNREVIEWED_INFEASIBLE')and slot.get('process_spawned')is True and slot.get('child_reaped')is True and slot.get('returncode')==0 and not slot.get('error'),'completed call status')
            require(slot['stdout']==f'raw/calls/{cid}.stdout'and slot['stderr']==f'raw/calls/{cid}.stderr','fixed call paths')
            for key in('stdout','stderr'):require(sha(ROOT/slot[key])==slot[key+'_sha256'],'saved output bytes')
            answer=load(ROOT/slot['stdout']);require(not ledger['errors']and not ledger['per_call_errors'][cid],'saved ledger valid')
            p=problems[e['instance_id']];payload={k:p[k]for k in('coordinates','demands','capacity','K')};payload.update({k:e[k]for k in('seed','max_iterations','arm','scale','min_penalty','max_penalty','observe_penalties')});payload['distance_matrix']=[[e['scale']*v for v in row]for row in p['matrices'][e['proxy']]]
            require(hashlib.sha256(compact(payload)).hexdigest()==slot['payload_sha256'],'twelve-key single-matrix payload identity')
            v=check_answer(p,e,answer,params);require(v['valid']==(slot['status']=='UNREVIEWED_PROCESS_SUCCESS'),'status versus independent feasibility')
            r.update(record_verified=True,routing_violation=v['routing_violation'],diagnostic_base_E=v['base_E'],diagnostic_base_G=v['base_G'],observations=v['observations'],routes=v['routes'],loads=v['loads'])
            if v['valid']:
                require(answer['reported_cost']%e['scale']==0 and answer['reported_cost']//e['scale']==v['normalized_own_cost'],'reported exact scale division')
                costs={'E':v['base_E'],'G':v['base_G']};value=endpoints(e['proxy'],costs,truth[e['instance_id']]);r.update(valid=True,base_E=v['base_E'],base_G=v['base_G'],normalized_own_cost=v['normalized_own_cost'],**value)
            else:r['failure']='NO_FEASIBLE_INCUMBENT'
        except Exception as exc:r=blank(e,slot.get('status','MISSING_RESULT'));r['failure']=type(exc).__name__+':'+str(exc)
        rows.append(r)
        if e['arm']=='A':answers[(e['instance_id'],e['seed'],e['proxy'])]=answer
    fields=list(dict.fromkeys(e['instance_id']for e in schedule));diagnostics=[]
    for row in rows:
        if row['arm']=='A':
            key=(row['instance_id'],row['seed'],row['proxy']);diagnostics.append(history(row,answers[key],oldanswers[key],row['valid'],oldrows[key]['valid']))
    return {'status':'SAVED_EVIDENCE_AUDITED','planned_formal_slots':216,'planned_per_arm':72,'planned_per_proxy_per_arm':36,'field_denominator':12,'rows':rows,'ledger':ledger,'valid_feasible_slots':sum(r['valid']for r in rows),'new_solver_calls':0,'new_native_constructions':0,**summarize(rows,fields),'fresh_A_legacy250_diagnostics':diagnostics,'fresh_A_legacy250_diagnostic_counts':dict(Counter(d['status']for d in diagnostics))}

def run():
    resource.setrlimit(resource.RLIMIT_CPU,(60,60));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2));signal.alarm(120);r=gate();dest=ROOT/'independent_supervision/results';dest.mkdir(exist_ok=True);save_exclusive(dest/'SAVED_AUDIT_STARTED.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'new_solver_calls':0,'new_native_constructions':0});c=time.process_time();w=time.monotonic()
    schedule=load(ROOT/'freeze/SCHEDULE.json');perms=list(itertools.permutations('ABC'));expected=[]
    for idx,(f,s,p)in enumerate(itertools.product(FIELDS,range(3),('E','G'))):
        for pos,arm in enumerate(perms[idx%6],1):expected.append((f,s,p,arm,idx+1,pos,list(perms[idx%6])))
    require(len(schedule)==216 and [(e['instance_id'],e['seed'],e['proxy'],e['arm'],e['triple_index'],e['arm_position'],e['arm_permutation'])for e in schedule]==expected,'balanced fixed216 schedule');require(all(e['max_iterations']==250 and e['observe_penalties']is True for e in schedule),'fixed250 symmetric observation')
    problems,truth,pre=source_inputs();oldrows,oldanswers=historical_inputs();ev,ee=lines(ROOT/'raw/attempts.jsonl');items,ie=lines(ROOT/'raw/results.jsonl');params=load(ROOT/'environment/DEFAULT_SOLVE_PARAMS.json')['parameters']
    x=collect(schedule,load(ROOT/'raw/ALL_PLANNED_SLOTS.json'),items,ev,ee+ie,load(ROOT/'raw/EXECUTOR_FINISHED.json'),problems,truth,params,oldrows,oldanswers)
    x.update(frozen_files_sha256=r['frozen_files_sha256'],raw_archive_sha256=r['sha256'],q5_final_sha256=Q5_SHA,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),resources={'cpu_seconds':time.process_time()-c,'wall_seconds':time.monotonic()-w,'maxrss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss});save_exclusive(dest/'SAVED_SCALE_AUDIT.json',x);print(json.dumps({'valid_feasible_slots':x['valid_feasible_slots'],'planned':216,'by_arm':{k:v['valid_feasible']for k,v in x['overall']['arms'].items()}}))
if __name__=='__main__':run()
