"""Independent scale and public-observation contract; no native library imports."""
import copy
from base_saved import *
ARMS={'A':(1,.1,100000.),'B':(10,.1,100000.),'C':(10,1.,1000000.)}

def observation(a,e,p):
    o=a['penalty_observation']
    if not e['observe_penalties']:
        require(o is None,'unobserved callback');return {'observed':False,'initial_solution_feasible':None,'first_best_feasible_iteration':None,'pm_updates_observed':None}
    require(o['schema']=='public_scale_penalty_observer_v1'and o['probe_values']==[1,2,7,1000],'observer schema/probes')
    midpoint=e['min_penalty']+(e['max_penalty']-e['min_penalty'])/2;expected=[[midpoint],midpoint,midpoint];require(o['initial_penalties']==expected,'initial public midpoint')
    rr=o['initial_solution_routes'];n=len(p['coordinates'])-1;seen=[];loads=[]
    require(isinstance(rr,list)and 1<=len(rr)<=p['K'],'initial route count')
    for r in rr:
        require(isinstance(r,list)and len(r)>=3 and r[0]==r[-1]==0 and all(type(v)is int and 1<=v<=n for v in r[1:-1]),'initial route schema')
        seen.extend(r[1:-1]);loads.append(sum(p['demands'][v]for v in r[1:-1]))
    require(Counter(seen)==Counter(range(1,n+1)),'initial coverage');initial=all(v<=p['capacity']for v in loads);require(o['initial_solution_feasible']is initial,'initial feasibility')
    first=0 if initial else None;found=initial;require(len(o['rows'])==250==len(a['stats']),'250observations')
    probes=[{'violation':v,'load':int(v*midpoint),'duration':int(v*midpoint),'distance':int(v*midpoint)}for v in(1,2,7,1000)]
    for i,(row,stat)in enumerate(zip(o['rows'],a['stats']),1):
        require(type(row['iteration'])is int and row['iteration']==i,'observer iteration')
        require(row['expected_search_penalties_source_derived']==row['observed_post_registration_penalties']==expected,'500registration no250update contract')
        require(row['observed_search_evaluator_integer_probes']==probes,'delivered integer evaluator probes')
        state=row['best_is_feasible'];require(type(state)is bool and state==stat['best_feas'],'publicbest versus stats')
        require(not found or state,'bestfeasible monotonicity')
        if state and first is None:first=i
        found=found or state
    require(o['first_best_feasible_iteration']==first and found==a['solver_is_feasible'],'first observed feasible/final')
    return {'observed':True,'initial_solution_feasible':initial,'initial_solution_routes':rr,'initial_solution_loads':loads,'first_best_feasible_iteration':first,'pm_updates_observed':0}

def check_answer(p,e,a,default_params):
    require((e['scale'],e['min_penalty'],e['max_penalty'])==ARMS[e['arm']],'declared three-arm parameters')
    require(a['arm']==e['arm']and a['scale']==e['scale']and a['observe_penalties']==e['observe_penalties'],'output arm identity')
    params=copy.deepcopy(default_params);pen=params['values']['penalty']['values'];pen['min_penalty']=e['min_penalty'];pen['max_penalty']=e['max_penalty']
    if e['observe_penalties']:params['values']['ils']['values']['callbacks']={'type':'observer.ReadonlyPenaltyObserver','values':{}}
    scaled=copy.deepcopy(p);factor=e['scale'];scaled['matrices']={k:[[factor*x for x in row]for row in m]for k,m in p['matrices'].items()}
    v=validate_answer(scaled,e,a,params);require(v['E']%factor==v['G']%factor==a['reported_distance']%factor==0,'exact native route scale removal')
    base={key:matrix_cost(p['matrices'][key],v['routes'])for key in('E','G')}
    require(all(base[key]*factor==v[key]for key in('E','G')),'unscaled matrix route cross-check')
    obs=observation(a,e,p)
    return {'valid':v['valid_feasible'],'routing_violation':not v['valid_feasible'],'base_E':base['E'],'base_G':base['G'],'normalized_own_cost':base[e['proxy']]if v['valid_feasible']else None,'routes':v['routes'],'loads':v['loads'],'observations':obs}
