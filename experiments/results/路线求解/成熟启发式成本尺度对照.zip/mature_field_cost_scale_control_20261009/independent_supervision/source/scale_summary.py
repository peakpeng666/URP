"""Independent fixed216 denominators and paired reductions from verified saved rows."""
from collections import Counter
ARMS=('A','B','C');PAIRS=(('A','B'),('B','C'),('A','C'))
METRICS=('normalized_own_cost','own_gap_mm','own_gap_percent','base_E','base_G','G_realized_excess_mm')
ROW_KEYS=('call_id','instance_id','proxy','seed','arm','scale','max_iterations','valid','base_E','base_G','normalized_own_cost','own_gap_mm','own_gap_percent','exact_hit','G_realized_excess_mm','E_offset_from_lex_reference_mm','E_optimal_tie_difference_mm')

def describe(values):return {'mean':sum(values)/len(values)if values else None,'min':min(values)if values else None,'max':max(values)if values else None}
def numbers(rows,complete):return {'count':len(rows),'complete':complete,'metrics':{m:describe([r[m]for r in rows])for m in METRICS}}
def observations(rows):
    initial={'feasible':0,'infeasible':0,'unknown':0};first=Counter();updates=Counter();never=0;unknown=0
    for row in rows:
        o=row.get('observations')
        if not isinstance(o,dict)or o.get('observed')is False:initial['unknown']+=1;unknown+=1;updates['unknown']+=1;continue
        state=o['initial_solution_feasible'];initial['feasible'if state is True else'infeasible'if state is False else'unknown']+=1
        i=o.get('first_best_feasible_iteration')
        if type(i)is int and 0<=i<=250:first[str(i)]+=1
        elif 'first_best_feasible_iteration'in o and i is None:never+=1
        else:unknown+=1
        count=o.get('pm_updates_observed');updates[str(count)if type(count)is int else'unknown']+=1
    return {'planned_denominator':len(rows),'initial_solution_feasibility':initial,'first_best_feasible_iteration_histogram':dict(sorted(first.items(),key=lambda p:int(p[0]))),'no_best_feasible_observed':never,'first_best_feasible_unknown':unknown,'pm_update_count_histogram':dict(updates),'scope':'Saved public callback observations only. No stage-specific causal attribution.'}
def arm_summary(rows):
    good=[r for r in rows if r['valid']];n=len(rows);v=len(good);hit=sum(r['exact_hit']for r in good)
    return {'planned':n,'valid_feasible':v,'failed_or_unverified':n-v,'verified_infeasible':sum(r['record_verified']and not r['valid']for r in rows),'technical_or_unverified':sum(not r['record_verified']for r in rows),'feasibility_rate_all_planned':v/n,'exact_hits':hit,'exact_hit_rate_all_planned':hit/n,'exact_hit_rate_valid_only':hit/v if v else None,'complete_panel':numbers(good,True)if v==n else None,'conditional_valid_subset':numbers(good,v==n),'observation_diagnostics':observations(rows),'raw_status_counts':dict(Counter(r['raw_status']for r in rows))}
def pair_row(left,right):
    ok=left['valid']and right['valid'];a=left['arm'];b=right['arm']
    return {'instance_id':left['instance_id'],'seed':left['seed'],'proxy':left['proxy'],'comparison':a+'_vs_'+b,'left_arm':a,'right_arm':b,'left_valid':left['valid'],'right_valid':right['valid'],'common_success':ok,'transition':('success'if left['valid']else'failure')+'_to_'+('success'if right['valid']else'failure'),'right_minus_left':{m:right[m]-left[m]if ok else None for m in METRICS},'delta_sign':'right minus left, in original units; quality is conditional on both succeeding'}
def pair_summary(rows):
    good=[r for r in rows if r['common_success']];n=len(rows);v=len(good);counts={k:0 for k in('success_to_success','success_to_failure','failure_to_success','failure_to_failure')};counts.update(Counter(r['transition']for r in rows));metrics={m:describe([r['right_minus_left'][m]for r in good])for m in METRICS}
    return {'planned_pairs':n,'common_success_count':v,'paired_success_transitions':counts,'descriptive_paired_risk_difference_right_minus_left':(counts['failure_to_success']-counts['success_to_failure'])/n,'complete_panel_mean_deltas':{m:metrics[m]['mean']if n==v else None for m in METRICS},'conditional_pair_common_success':{'denominator':v,'planned_denominator':n,'metrics':metrics}}
def group(rows):
    lookup={(r['instance_id'],r['seed'],r['proxy'],r['arm']):r for r in rows};keys=list(dict.fromkeys(k[:3]for k in lookup));assert len(lookup)==len(rows)==3*len(keys)
    assert all((*key,a)in lookup for key in keys for a in ARMS)
    common=[key for key in keys if all(lookup[(*key,a)]['valid']for a in ARMS)];n=len(keys);v=len(common)
    comparisons={a+'_vs_'+b:[pair_row(lookup[(*k,a)],lookup[(*k,b)])for k in keys]for a,b in PAIRS}
    triple={'planned_triples':n,'common_success_count':v,'conditional_three_arm_common_success':{'denominator':v,'planned_denominator':n,'by_arm':{a:numbers([lookup[(*k,a)]for k in common],v==n)for a in ARMS},'mean_deltas':{a+'_vs_'+b:{m:sum(lookup[(*k,b)][m]-lookup[(*k,a)][m]for k in common)/v if v else None for m in METRICS}for a,b in PAIRS}}}
    return {'planned_slots':len(rows),'planned_per_arm':n,'arms':{a:arm_summary([lookup[(*k,a)]for k in keys])for a in ARMS},'pairs':{name:pair_summary(rr)for name,rr in comparisons.items()},'three_arm_common_success':triple}
def summarize(rows,fields):
    lookup={(r['instance_id'],r['seed'],r['proxy'],r['arm']):r for r in rows};expected={(f,s,p,a)for f in fields for s in range(3)for p in('E','G')for a in ARMS};assert len(rows)==len(lookup)==216 and set(lookup)==expected
    pairs=[];triples=[]
    for f in fields:
        for seed in range(3):
            for proxy in('E','G'):
                g={a:lookup[(f,seed,proxy,a)]for a in ARMS};pairs.extend(pair_row(g[a],g[b])for a,b in PAIRS);triples.append({'instance_id':f,'seed':seed,'proxy':proxy,'valid_by_arm':{a:g[a]['valid']for a in ARMS},'all_three_common_success':all(g[a]['valid']for a in ARMS)})
    return {'overall':group(rows),'by_proxy':{p:group([r for r in rows if r['proxy']==p])for p in('E','G')},'per_field':[{'instance_id':f,'field_weight':1,'seed_count':3,'overall':group([r for r in rows if r['instance_id']==f]),'by_proxy':{p:group([r for r in rows if r['instance_id']==f and r['proxy']==p])for p in('E','G')}}for f in fields],'paired_rows':pairs,'triple_rows':triples}

def history(entry,new,old,valid,oldvalid):
    keys=('routes','reported_cost','reported_distance','solver_is_feasible','solver_is_complete','native_model_parameters','model_matrix_sha256');stats=('current_cost','current_feas','candidate_cost','candidate_feas','best_cost','best_feas')
    out={'instance_id':entry['instance_id'],'seed':entry['seed'],'proxy':entry['proxy'],'fresh_call_id':entry['call_id'],'diagnostic_only':True,'fresh_scientific_valid':valid,'historical_scientific_valid':oldvalid,'iterations_required':250,'status':'UNAVAILABLE','first_difference':None,'terminal_fields_equal':None,'terminal_field_equality':None,'cost_scale_policy':'Raw saved A and legacy trajectories only; never normalize penalized trajectory costs.'}
    if not isinstance(new,dict)or not isinstance(old,dict):out['reason']='MISSING_FRESH_OR_HISTORICAL_ANSWER';return out
    eq={k:new[k]==old[k]if k in new and k in old else None for k in keys};out.update(terminal_field_equality=eq,terminal_fields_equal=all(eq.values())if all(v is not None for v in eq.values())else None)
    a=old.get('stats');b=new.get('stats')
    if not isinstance(a,list)or not isinstance(b,list)or len(a)!=250 or len(b)!=250:out['reason']='MISSING_OR_INCOMPLETE_250_ITERATION_STATS';return out
    for i,(x,y)in enumerate(zip(a,b),1):
        if not isinstance(x,dict)or not isinstance(y,dict)or any(k not in x or k not in y for k in stats):out['reason']='MISSING_STATS_FIELDS';return out
        if out['first_difference']is None:
            for k in stats:
                if x[k]!=y[k]:out['first_difference']={'iteration':i,'field':k,'legacy_raw':x[k],'fresh_raw':y[k]};break
    out['status']='ALL_250_EQUAL'if out['first_difference']is None else'DIFFERENT';return out
