"""Replay216 invented-schema records cloned from four saved toys, no native/solver calls."""
import copy,itertools,json,pathlib,sys,zipfile,time,hashlib
import audit_scale as independent
from audit_scale import *
def write(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')
def main():
    base=ROOT;D=base/'independent_supervision/selftests/replay_r1';D.mkdir(exist_ok=False);c=time.process_time();w=time.monotonic();params=load(base/'environment/DEFAULT_SOLVE_PARAMS.json')['parameters'];toy=load(base/'selftests/toy/FIXTURE.json');problem=copy.deepcopy(toy);problem['matrices']['G']=copy.deepcopy(problem['matrices']['E']);fields=['INVENTED_SCALE_'+str(i)for i in range(12)];problems={f:dict(copy.deepcopy(problem),instance_id=f)for f in fields};truth={f:{'instance_id':f,'valid_for_exact_conclusion':True,'E_star':300002,'G_star':300002,'G_at_E_optimum':300002,'delta_integer_mm':0}for f in fields}
    templates={arm:load(base/f'selftests/toy/raw/calls/TOY_{arm}_OBS.stdout')for arm in'ABC'};oldtemplate=load(base/'selftests/toy/raw/calls/TOY_A_NOOBS.stdout');schedule=[];slots=[];events=[];oldrows={};oldanswers={};outputs=[];priorrows=[];identities={}
    for f in fields:
        write(D/f'input/{f}.json',problems[f]);identities[f]={'input_sha256':sha(D/f'input/{f}.json')}
        for seed in range(3):
            for proxy in('E','G'):
                key=(f,seed,proxy);old=copy.deepcopy(oldtemplate);old['seed']=seed;oldanswers[key]=old;oldrows[key]={'instance_id':f,'seed':seed,'proxy':proxy,'valid':True};priorrows.append(oldrows[key]);outputs.append({'entry':{'instance_id':f,'seed':seed,'proxy':proxy},'answer':old})
    for t,(f,seed,proxy)in enumerate(itertools.product(fields,range(3),('E','G'))):
        permutation=list(itertools.permutations('ABC'))[t%6]
        for pos,arm in enumerate(permutation,1):
            scale,minimum,maximum=ARMS[arm];e={'schedule_index':len(schedule)+1,'call_id':f'{f}_{proxy}_s{seed}_{arm}','instance_id':f,'proxy':proxy,'seed':seed,'arm':arm,'scale':scale,'min_penalty':minimum,'max_penalty':maximum,'observe_penalties':True,'max_iterations':250,'triple_index':t+1,'arm_position':pos,'arm_permutation':list(permutation)};schedule.append(e)
            a=copy.deepcopy(templates[arm]);a['seed']=seed;out=f"raw/calls/{e['call_id']}.stdout";err=f"raw/calls/{e['call_id']}.stderr";write(D/out,a);(D/err).write_text('')
            p=problems[f];payload={k:p[k]for k in('coordinates','demands','capacity','K')};payload.update({k:e[k]for k in('seed','max_iterations','arm','scale','min_penalty','max_penalty','observe_penalties')});payload['distance_matrix']=[[scale*v for v in row]for row in p['matrices'][proxy]]
            slot={'call_id':e['call_id'],'schedule':e,'status':'UNREVIEWED_PROCESS_SUCCESS'if a['solver_is_feasible']else'UNREVIEWED_INFEASIBLE','returncode':0,'process_spawned':True,'child_reaped':True,'stdout':out,'stderr':err,'stdout_sha256':sha(D/out),'stderr_sha256':sha(D/err),'payload_sha256':hashlib.sha256(compact(payload)).hexdigest()};slots.append(slot)
            for kind in('STARTED','FINISHED'):
                event={'event_kind':kind,'utc':'2026-10-09T00:00:00+00:00','call_id':e['call_id'],'schedule':e}
                if kind=='FINISHED':event['result']=slot
                events.append(event)
    outer={'cleanup':{'quiescent':True},'known_spawned':216,'unknown_spawned_slots':0,'ledger_errors':[]}
    independent.ROOT=D
    full=collect(schedule,slots,slots,events,[],outer,problems,truth,params,oldrows,oldanswers);require(full['valid_feasible_slots']==144,'144 valid A/C and72 retained B infeasible');write(D/'INDEPENDENT_FULL.json',full)
    # Author reducer cross-check on same copied saved evidence. Isolated test gates only.
    write(D/'environment/DEFAULT_SOLVE_PARAMS.json',{'parameters':params});write(D/'freeze/SCHEDULE.json',schedule);write(D/'raw/ALL_PLANNED_SLOTS.json',slots);write(D/'raw/EXECUTOR_FINISHED.json',outer);write(D/'input/IDENTITIES.json',{'fields':identities});write(D/'historical_reference/ALL72_LEGACY250_ROWS.json',{'diagnostic_only':True,'rows':priorrows});write(D/'historical_reference/ALL72_LEGACY250_OUTPUTS.json',{'diagnostic_only':True,'rows':outputs})
    with zipfile.ZipFile(D/'input/Q5_FINAL.zip','x',zipfile.ZIP_DEFLATED)as z:z.writestr('independent_supervision/FINAL_AUDIT.json',json.dumps({'status':'PASS','verified_fields':12,'fields':list(truth.values())}))
    write(D/'freeze/PROTOCOL.json',{'fields':fields,'input':{'archive':'input/Q5_FINAL.zip','sha256':sha(D/'input/Q5_FINAL.zip')},'toy_solver_calls':4,'toy_model_instances':4,'endpoints':{},'analysis':{}})
    sys.path.insert(0,str(base/'source'));import report as author;import endpoint_core
    author.ROOT=D;author.read=lambda rel:load(D/rel);author.verify_frozen=lambda:'INVENTED_ONLY';author.verify_old=lambda:0;author.receipt=lambda stage:{'sha256':'INVENTED_ONLY'};endpoint_core.read=author.read
    their=author.collect_saved_evidence()
    for x,y in zip(full['rows'],their['rows']):
        for k in ROW_KEYS:require(type(x[k])is type(y[k])and x[k]==y[k],'row '+k)
    for k in SECTIONS:equal(full[k],their[k],k)
    broken=copy.deepcopy(slots);broken[0]['status']='PROCESS_FAILURE_OR_CPU_LIMIT';ev=copy.deepcopy(events);ev[1]['result']=broken[0]
    partial=collect(schedule,broken,broken,ev,[],outer,problems,truth,params,oldrows,oldanswers);require(partial['valid_feasible_slots']==143 and partial['overall']['arms']['A']['planned']==72 and partial['overall']['arms']['A']['complete_panel']is None,'failure all72 denominator')
    write(D/'raw/ALL_PLANNED_SLOTS.json',broken);other=author.collect_saved_evidence()
    for k in SECTIONS:equal(partial[k],other[k],k)
    # Restore real module root then independently verify all original input and historical source bytes without optimizing them.
    independent.ROOT=base;source_inputs();historical_inputs(check_archive=True)
    result={'status':'PASS','invented_schema_records':216,'full_valid':144,'full_verified_infeasible':72,'partial_valid':143,'all216_denominator_retained':True,'independent_author_sections_match':list(SECTIONS),'previous_source_fields_verified':12,'legacy250_raw_cells_verified':72,'new_native_constructions':0,'new_solver_calls':0,'resources':{'cpu_seconds':time.process_time()-c,'wall_seconds':time.monotonic()-w}}
    write(base/'independent_supervision/selftests/SAVED_SCALE_REPLAY_R1.json',result);print(json.dumps(result))
if __name__=='__main__':main()
