"""Read-only gates shared by toy and formal launch; no optimizer imports."""
from pathlib import Path
import itertools
from common import ROOT,read,sha,verify_frozen,verify_old,receipt
FORMAL_SCOPE='one frozen216-call PyVRP cost-scale control batch,12fields3seeds2proxies3arms,250ILS,no retry'
def check_environment():
    env=read('environment/RUNTIME.json');python=Path(env['python_executable'])
    assert python.is_file() and sha(python.resolve())==env['python_binary_sha256']
    for item in env['installed_distribution_files']:
        p=Path(item['path']);assert p.stat().st_size==item['bytes'] and sha(p)==item['sha256'],str(p)
    assert env['pyvrp_version']=='0.14.0'
    return str(python)
def verify_toy_freeze():
    meta=read('selftests/toy/FROZEN.json')
    for rel,item in meta['files'].items():
        p=ROOT/rel;assert p.stat().st_size==item['bytes'] and sha(p)==item['sha256'],'TOY_FROZEN_CHANGED:'+rel
    auth=read('selftests/toy/AUTHORIZATION.json')
    assert auth['approved'] is True and auth['toy_solver_calls']==auth['toy_model_instances']==4
    assert auth['fixture_sha256']==sha(ROOT/'selftests/toy/FIXTURE.json')
    assert auth['schedule_sha256']==sha(ROOT/'selftests/toy/SCHEDULE.json')
    return sha(ROOT/'selftests/toy/FROZEN.json')
def check_gate(mode):
    assert mode in ('toy','formal');verify_old()
    if mode=='toy':return {'mode':mode,'freeze_sha256':verify_toy_freeze(),'python':check_environment()}
    digest=verify_frozen();r=receipt('PREEXEC');review=read('freeze/INDEPENDENT_PRECHECK.json')
    assert review['status']=='PASS'
    approval=read('provenance/PARENT_EXECUTION_APPROVAL.json')
    assert approval['approved'] is True and approval['scope']==FORMAL_SCOPE
    assert approval['frozen_files_sha256']==digest and approval['preexec_archive_sha256']==r['sha256']
    return {'mode':mode,'freeze_sha256':digest,'python':check_environment(),'approval_sha256':sha(ROOT/'provenance/PARENT_EXECUTION_APPROVAL.json'),'preexec_receipt_sha256':sha(ROOT/'provenance/PREEXEC_DRIVE_RECEIPT.json')}
def get_schedule(mode):
    schedule=read('selftests/toy/SCHEDULE.json' if mode=='toy' else 'freeze/SCHEDULE.json')
    assert [e['schedule_index']for e in schedule]==list(range(1,len(schedule)+1))
    assert len({e['call_id']for e in schedule})==len(schedule)
    protocol=read('freeze/PROTOCOL.json')
    for e in schedule:
        assert e['max_iterations']==250 and e['seed'] in (0,1,2)
        assert {k:e[k]for k in ('scale','min_penalty','max_penalty')}==protocol['arms'][e['arm']]
    if mode=='toy':
        assert len(schedule)==4
        assert [(e['arm'],e['observe_penalties'])for e in schedule]==[('A',True),('B',True),('C',True),('A',False)]
        assert all(e['instance_id']=='TOY_SCALE_MATRIX' and e['proxy']=='E' and e['seed']==0 for e in schedule)
    else:
        expected=[];perms=list(itertools.permutations(('A','B','C')))
        for t,(f,s,p) in enumerate(itertools.product(protocol['fields'],(0,1,2),('E','G')),1):
            for pos,a in enumerate(perms[(t-1)%6],1):expected.append((f,s,p,a,t,pos,list(perms[(t-1)%6])))
        assert len(schedule)==216
        assert [(e['instance_id'],e['seed'],e['proxy'],e['arm'],e['triple_index'],e['arm_position'],e['arm_permutation'])for e in schedule]==expected
        assert all(e['observe_penalties'] is True for e in schedule)
    return schedule
def load_payload(entry,mode):
    if mode=='toy':data=read('selftests/toy/FIXTURE.json')
    else:
        rel=f"input/{entry['instance_id']}.json"
        assert sha(ROOT/rel)==read('input/IDENTITIES.json')['fields'][entry['instance_id']]['input_sha256']
        data=read(rel)
    assert data['instance_id']==entry['instance_id']
    payload={k:data[k] for k in ('coordinates','demands','capacity','K')}
    payload.update({k:entry[k]for k in ('seed','max_iterations','arm','scale','min_penalty','max_penalty','observe_penalties')})
    payload['distance_matrix']=[[entry['scale']*v for v in row]for row in data['matrices'][entry['proxy']]]
    return payload
