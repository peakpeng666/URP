"""No-solver, in-memory synthetic replay tests for the saved 216-slot report."""
import ast
import copy
import json
import sys
import types
import unittest
from pathlib import Path
from unittest.mock import patch

import report
from report_core import (ARMS, METRICS, ROW_AUDIT_KEYS, apply_checked, blank_row,
                         build_summary, historical_diagnostic, summarize_observations,
                         summarize_first_probes)


FIELDS = ['synthetic_field_' + str(i) for i in range(12)]
ORACLE = {'valid_for_exact_conclusion': True, 'E_star': 100, 'G_star': 120,
          'G_at_E_optimum': 125, 'delta_integer_mm': 5}


def fixture():
    schedule, rows, answers, checks = [], [], {}, {}
    for field in FIELDS:
        for seed in (0, 1, 2):
            for proxy in ('E', 'G'):
                for index, arm in enumerate(ARMS):
                    entry = {'schedule_index': len(schedule) + 1,
                             'call_id': f'{field}_{proxy}_{seed}_{arm}',
                             'instance_id': field, 'proxy': proxy, 'seed': seed,
                             'max_iterations': 250, 'arm': arm,
                             'scale': 1 if arm == 'A' else 10}
                    gap = index * 5
                    base_E = 100 + gap if proxy == 'E' else 105 + gap
                    base_G = 125 + gap if proxy == 'E' else 120 + gap
                    own = base_E if proxy == 'E' else base_G
                    obs = {'observed': True, 'initial_solution_feasible': arm == 'A',
                           'first_best_feasible_iteration': 0 if arm == 'A' else 2,
                           'pm_updates_observed': 0}
                    checked = {'valid': True, 'routing_violation': False,
                               'base_E': base_E, 'base_G': base_G,
                               'normalized_own_cost': own, 'routes': [[0, 1, 0]],
                               'loads': [1], 'observations': obs}
                    stat = {'current_cost': own * entry['scale'], 'current_feas': True,
                            'candidate_cost': own * entry['scale'], 'candidate_feas': True,
                            'best_cost': own * entry['scale'], 'best_feas': True}
                    answer = {'reported_cost': own * entry['scale'],
                              'reported_distance': own * entry['scale'],
                              'solver_is_feasible': True, 'solver_is_complete': True,
                              'routes': [[0, 1, 0]], 'native_model_parameters': {},
                              'model_matrix_sha256': 'synthetic',
                              'stats': [dict(stat) for _ in range(250)]}
                    penalty = 500000.5 if arm == 'C' else 50000.05
                    answer['penalty_observation'] = {'initial_penalties': [[penalty], penalty, penalty],
                        'rows': [{'iteration': 1, 'observed_search_evaluator_integer_probes':
                                  [{'violation': v, 'load': int(v * penalty), 'duration': int(v * penalty),
                                    'distance': int(v * penalty)} for v in (1, 2, 7, 1000)]}]}
                    row = apply_checked(blank_row(entry, 'UNREVIEWED_PROCESS_SUCCESS'), checked, ORACLE, answer)
                    schedule.append(entry)
                    rows.append(row)
                    answers[entry['call_id']] = answer
                    checks[entry['call_id']] = checked
    return schedule, rows, answers, checks


def invalidate(rows, index, verified=False):
    old = rows[index]
    rows[index] = blank_row({k: old[k] for k in ('schedule_index', 'call_id', 'instance_id', 'proxy', 'seed', 'max_iterations', 'arm', 'scale')},
                            'UNREVIEWED_INFEASIBLE' if verified else 'NOT_STARTED_ABORTED')
    if verified:
        rows[index].update(record_verified=True, routing_violation=True,
                           diagnostic_base_E=90, diagnostic_base_G=110,
                           failure='NO_FEASIBLE_INCUMBENT')


class ReportCoreTests(unittest.TestCase):
    def setUp(self):
        self.schedule, self.rows, self.answers, self.checks = fixture()

    def test_complete_fixed_denominators_and_original_units(self):
        data = build_summary(self.rows, FIELDS)
        self.assertEqual(data['overall']['planned_slots'], 216)
        self.assertEqual(len(data['paired_rows']), 216)
        self.assertEqual(len(data['triple_rows']), 72)
        self.assertEqual(len(data['per_field']), 12)
        for arm in ARMS:
            cell = data['overall']['arms'][arm]
            self.assertEqual((cell['planned'], cell['valid_feasible']), (72, 72))
            self.assertIsNotNone(cell['complete_panel'])
            for proxy in ('E', 'G'):
                self.assertEqual(data['by_proxy'][proxy]['arms'][arm]['planned'], 36)
        self.assertEqual(data['overall']['arms']['A']['exact_hits'], 72)
        self.assertEqual(data['overall']['arms']['B']['conditional_valid_subset']['metrics']['own_gap_mm']['mean'], 5)
        self.assertEqual(data['overall']['pairs']['A_vs_B']['complete_panel_mean_deltas']['own_gap_mm'], 5)
        for field in data['per_field']:
            self.assertEqual(field['overall']['planned_per_arm'], 6)
            self.assertEqual(field['by_proxy']['E']['planned_per_arm'], 3)

    def test_separate_pair_and_three_arm_common_success(self):
        # Three distinct E triples: A fails, B fails, C fails.
        invalidate(self.rows, 0)
        invalidate(self.rows, 7, verified=True)
        invalidate(self.rows, 14)
        data = build_summary(self.rows, FIELDS)
        overall = data['overall']
        self.assertEqual(overall['three_arm_common_success']['common_success_count'], 69)
        for arm in ARMS:
            cell = overall['arms'][arm]
            self.assertEqual(cell['valid_feasible'], 71)
            self.assertIsNone(cell['complete_panel'])
            self.assertEqual(cell['conditional_valid_subset']['count'], 71)
            self.assertEqual(data['by_proxy']['E']['arms'][arm]['valid_feasible'], 35)
            self.assertEqual(data['by_proxy']['G']['arms'][arm]['valid_feasible'], 36)
            self.assertIsNotNone(data['by_proxy']['G']['arms'][arm]['complete_panel'])
        for pair in overall['pairs'].values():
            self.assertEqual(pair['common_success_count'], 70)
            self.assertEqual(pair['paired_success_transitions']['success_to_failure'], 1)
            self.assertEqual(pair['paired_success_transitions']['failure_to_success'], 1)
            self.assertEqual(pair['descriptive_paired_risk_difference_right_minus_left'], 0)
            self.assertTrue(all(value is None for value in pair['complete_panel_mean_deltas'].values()))
        self.assertEqual(overall['arms']['B']['verified_infeasible'], 1)
        self.assertEqual(overall['arms']['A']['technical_or_unverified'], 1)
        self.assertTrue(all(self.rows[7][metric] is None for metric in METRICS))
        self.assertEqual(self.rows[7]['diagnostic_base_E'], 90)

    def test_failure_retains_fixed_denominator_and_paired_direction(self):
        invalidate(self.rows, 1)
        data = build_summary(self.rows, FIELDS)
        pair = data['overall']['pairs']['A_vs_B']
        self.assertEqual(pair['planned_pairs'], 72)
        self.assertEqual(pair['descriptive_paired_risk_difference_right_minus_left'], -1 / 72)
        self.assertEqual(data['overall']['arms']['B']['feasibility_rate_all_planned'], 71 / 72)
        self.assertEqual(data['overall']['arms']['A']['exact_hit_rate_all_planned'], 1)

    def test_missing_duplicate_or_failed_scientific_cost_is_rejected(self):
        for bad in (self.rows[:-1], self.rows[:-1] + [self.rows[0]]):
            with self.assertRaises(AssertionError):
                build_summary(bad, FIELDS)
        invalidate(self.rows, 0)
        self.rows[0]['normalized_own_cost'] = 0
        with self.assertRaises(AssertionError):
            build_summary(self.rows, FIELDS)

    def test_nonexact_scale_or_wrong_scale_rejected(self):
        entry = self.schedule[1]
        answer = copy.deepcopy(self.answers[entry['call_id']])
        answer['reported_cost'] += 1
        with self.assertRaises(AssertionError):
            apply_checked(blank_row(entry, 'UNREVIEWED_PROCESS_SUCCESS'), self.checks[entry['call_id']], ORACLE, answer)
        wrong = dict(entry, scale=1)
        with self.assertRaises(AssertionError):
            apply_checked(blank_row(wrong, 'UNREVIEWED_PROCESS_SUCCESS'), self.checks[entry['call_id']], ORACLE, self.answers[entry['call_id']])

    def test_infeasible_cost_is_diagnostic_only(self):
        entry = self.schedule[1]
        checked = copy.deepcopy(self.checks[entry['call_id']])
        checked.update(valid=False, routing_violation=True, normalized_own_cost=None)
        row = apply_checked(blank_row(entry, 'UNREVIEWED_INFEASIBLE'), checked, ORACLE, {'reported_cost': None})
        self.assertFalse(row['valid'])
        self.assertFalse(row['exact_hit'])
        self.assertEqual(row['diagnostic_base_E'], checked['base_E'])
        self.assertTrue(all(row[metric] is None for metric in METRICS))

    def test_negative_gap_rejected_but_signed_E_offset_preserved(self):
        entry = self.schedule[0]
        checked = copy.deepcopy(self.checks[entry['call_id']])
        checked.update(base_E=99, normalized_own_cost=99)
        with self.assertRaises(AssertionError):
            apply_checked(blank_row(entry, 'UNREVIEWED_PROCESS_SUCCESS'), checked, ORACLE, {'reported_cost': 99})
        checked.update(base_E=101, normalized_own_cost=101, base_G=120)
        row = apply_checked(blank_row(entry, 'UNREVIEWED_PROCESS_SUCCESS'), checked, ORACLE, {'reported_cost': 101})
        self.assertEqual(row['E_offset_from_lex_reference_mm'], -5)
        self.assertIsNone(row['E_optimal_tie_difference_mm'])
        self.assertFalse(row['offset_is_search_error'])

    def test_observation_unknown_never_and_initial_are_distinct(self):
        row = self.rows[0]
        never = dict(row, observations={'observed': True, 'initial_solution_feasible': False,
                                      'first_best_feasible_iteration': None, 'pm_updates_observed': 0})
        absent = dict(row, observations={'observed': False, 'initial_solution_feasible': None,
                                       'first_best_feasible_iteration': None, 'pm_updates_observed': None})
        data = summarize_observations([row, never, absent, dict(row, observations=None)])
        self.assertEqual(data['initial_solution_feasibility'], {'feasible': 1, 'infeasible': 1, 'unknown': 2})
        self.assertEqual(data['no_best_feasible_observed'], 1)
        self.assertEqual(data['first_best_feasible_unknown'], 2)
        self.assertEqual(data['first_best_feasible_iteration_histogram'], {'0': 1})

    def test_raw_probe_two_and_seven_are_not_normalized(self):
        probes = summarize_first_probes(self.rows)
        for arm in ARMS:
            self.assertEqual(probes['by_arm'][arm]['available'], 72)
            self.assertEqual(probes['by_arm'][arm]['unknown'], 0)
        a = probes['by_arm']['A']['observed_raw_signatures'][0]['first_iteration_integer_probes_raw']
        c = probes['by_arm']['C']['observed_raw_signatures'][0]['first_iteration_integer_probes_raw']
        self.assertEqual(a[1]['load'], 100000)
        self.assertEqual(c[1]['load'], 1000001)
        self.assertEqual(a[2]['load'], 350000)
        self.assertEqual(c[2]['load'], 3500003)
        self.assertNotEqual(c[1]['load'], 10 * a[1]['load'])
        self.assertNotEqual(c[2]['load'], 10 * a[2]['load'])

    def test_all_72_historical_diagnostics_without_validity_filter(self):
        diagnostics = []
        for entry in self.schedule:
            if entry['arm'] == 'A':
                answer = self.answers[entry['call_id']]
                diagnostics.append(historical_diagnostic(entry, answer, copy.deepcopy(answer), False, False))
        self.assertEqual(len(diagnostics), 72)
        self.assertTrue(all(d['status'] == 'ALL_250_EQUAL' for d in diagnostics))
        entry = self.schedule[0]
        original = self.answers[entry['call_id']]
        modified = copy.deepcopy(original)
        modified['stats'][249]['best_cost'] += 1
        result = historical_diagnostic(entry, modified, original, True, True)
        self.assertEqual(result['status'], 'DIFFERENT')
        self.assertEqual(result['first_difference']['iteration'], 250)
        self.assertEqual(result['first_difference']['fresh_raw'], 101)
        modified['stats'].pop()
        self.assertEqual(historical_diagnostic(entry, modified, original, True, True)['status'], 'UNAVAILABLE')
        self.assertEqual(historical_diagnostic(entry, None, original, False, True)['status'], 'UNAVAILABLE')

    def test_independent_endpoint_mismatch_is_rejected(self):
        data = {'rows': self.rows, 'raw_archive_sha256': 'raw', 'frozen_files_sha256': 'freeze'}
        audit = {'status': 'SAVED_EVIDENCE_AUDITED', 'raw_archive_sha256': 'raw',
                 'frozen_files_sha256': 'freeze',
                 'rows': [{key: row[key] for key in ROW_AUDIT_KEYS} for row in self.rows]}
        self.assertEqual(report.check_independent(data, audit), ['rows'])
        audit['rows'][1]['normalized_own_cost'] += 1
        with self.assertRaises(AssertionError):
            report.check_independent(data, audit)

    def test_no_solver_imports_or_execution_entrypoints(self):
        for name in ('report.py', 'report_core.py', 'test_report.py'):
            tree = ast.parse((Path(__file__).parent / name).read_text())
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    modules = [item.name for item in node.names]
                elif isinstance(node, ast.ImportFrom):
                    modules = [node.module or '']
                else:
                    continue
                self.assertFalse(any(module.startswith(('pyvrp', 'observer', 'worker', 'subprocess')) for module in modules), name)
        self.assertFalse(any(name == 'pyvrp' or name.startswith('pyvrp.') for name in sys.modules))


class SavedReplayTests(unittest.TestCase):
    def test_full_in_memory_replay_retains_infeasible_and_not_started(self):
        schedule, _, answers, checks = fixture()
        infeasible_id, missing_id = schedule[1]['call_id'], schedule[8]['call_id']
        checks[infeasible_id].update(valid=False, routing_violation=True, normalized_own_cost=None)
        answers[infeasible_id]['reported_cost'] = None
        answers[infeasible_id]['solver_is_feasible'] = False
        slots = []
        outputs = {}
        for entry in schedule:
            cid = entry['call_id']
            slot = {'call_id': cid, 'schedule': entry, 'status': 'UNREVIEWED_PROCESS_SUCCESS',
                    'returncode': 0, 'process_spawned': True, 'child_reaped': True,
                    'stdout': cid + '.stdout', 'stderr': cid + '.stderr',
                    'stdout_sha256': 'hash', 'stderr_sha256': 'hash'}
            if cid == infeasible_id:
                slot['status'] = 'UNREVIEWED_INFEASIBLE'
            if cid == missing_id:
                slot['status'] = 'NOT_STARTED_ABORTED'
            slots.append(slot)
            outputs[cid + '.stdout'] = json.dumps(answers[cid])
        history_entries = [entry for entry in schedule if entry['arm'] == 'A']
        files = {'freeze/PROTOCOL.json': {'fields': FIELDS, 'input': {'archive': 'input/Q5_FINAL.zip', 'sha256': 'hash'},
                                        'toy_solver_calls': 4, 'toy_model_instances': 4, 'endpoints': {}, 'analysis': {}},
                 'freeze/SCHEDULE.json': schedule, 'raw/ALL_PLANNED_SLOTS.json': slots,
                 'raw/EXECUTOR_FINISHED.json': {'cleanup': {'quiescent': True}, 'ledger_errors': [],
                                              'known_spawned': 215, 'unknown_spawned_slots': 0},
                 'input/IDENTITIES.json': {'fields': {f: {'input_sha256': 'hash'} for f in FIELDS}},
                 'historical_reference/ALL72_LEGACY250_ROWS.json': {'diagnostic_only': True,
                    'rows': [dict(entry, valid=True) for entry in history_entries]},
                 'historical_reference/ALL72_LEGACY250_OUTPUTS.json': {'diagnostic_only': True,
                    'rows': [{'entry': entry, 'answer': answers[entry['call_id']]} for entry in history_entries]}}
        files.update({'input/' + f + '.json': {} for f in FIELDS})
        archive = {'status': 'PASS', 'verified_fields': 12,
                   'fields': [dict(ORACLE, instance_id=f) for f in FIELDS]}
        endpoint = types.ModuleType('endpoint_core')
        endpoint.validate_saved = lambda problem, entry, answer: checks[entry['call_id']]

        class FakeOutput:
            def __init__(self, path):
                self.path = path
            def read_text(self):
                return outputs[self.path]

        class FakeArchive:
            def __enter__(self):
                return self
            def __exit__(self, *args):
                return False
            def read(self, path):
                assert path == 'independent_supervision/FINAL_AUDIT.json'
                return json.dumps(archive).encode()

        with patch.dict(sys.modules, {'endpoint_core': endpoint}), \
             patch.object(report, 'verify_frozen', return_value='freeze'), \
             patch.object(report, 'verify_old', return_value=0), \
             patch.object(report, 'receipt', return_value={'sha256': 'raw'}), \
             patch.object(report, 'read', side_effect=lambda path: files[path]), \
             patch.object(report, 'sha', return_value='hash'), \
             patch.object(report, 'safe_output', side_effect=FakeOutput), \
             patch.object(report.zipfile, 'ZipFile', return_value=FakeArchive()):
            result = report.collect_saved_evidence()
        self.assertEqual(result['valid_feasible_slots'], 214)
        self.assertEqual(result['planned_formal_slots'], 216)
        self.assertEqual(result['historical_cells_in_primary'], 0)
        self.assertEqual(result['fresh_A_legacy250_diagnostic_counts'], {'ALL_250_EQUAL': 72})
        self.assertEqual(result['overall']['arms']['B']['verified_infeasible'], 1)
        self.assertEqual(result['overall']['arms']['C']['technical_or_unverified'], 1)
        row = result['rows'][1]
        self.assertIsNone(row['base_E'])
        self.assertIsNotNone(row['diagnostic_base_E'])
        self.assertEqual(result['new_solver_calls_in_report'], 0)
        self.assertIn('固定216槽', report.report_text(result))
        self.assertFalse(any(name == 'pyvrp' or name.startswith('pyvrp.') for name in sys.modules))


if __name__ == '__main__':
    unittest.main(verbosity=2)
