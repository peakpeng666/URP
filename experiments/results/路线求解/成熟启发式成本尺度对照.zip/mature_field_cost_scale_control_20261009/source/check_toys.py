"""Saved-only four-toy verification. No PyVRP import, native construction or rerun."""
import json
from common import ROOT,read,save,sha,now
from gates import verify_toy_freeze,get_schedule
from endpoint_core import validate_saved,route_cost

def main():
    verify_toy_freeze();schedule=get_schedule('toy');problem=read('selftests/toy/FIXTURE.json')
    slots=read('selftests/toy/raw/ALL_PLANNED_SLOTS.json');outer=read('selftests/toy/raw/EXECUTOR_FINISHED.json')
    assert len(slots)==4 and outer['cleanup']['quiescent'] and not outer['ledger_errors']
    assert outer['supervisor_returncode']==0 and not outer['external_timeout']
    assert outer['known_spawned']==4 and outer['unknown_spawned_slots']==0
    rows=[];answers={}
    for entry,record in zip(schedule,slots):
        assert record['schedule']==entry and record['status'] in ('UNREVIEWED_PROCESS_SUCCESS','UNREVIEWED_INFEASIBLE')
        assert record['process_spawned'] is True and record['child_reaped'] is True and record['returncode']==0
        assert sha(ROOT/record['stdout'])==record['stdout_sha256'] and sha(ROOT/record['stderr'])==record['stderr_sha256']
        answer=read(record['stdout']);checked=validate_saved(problem,entry,answer);answers[entry['call_id']]=answer
        # Analytic optimum: two capacity2 routes, each two75000 depot legs plus one customer edge.
        oracle=300002
        rows.append({'call_id':entry['call_id'],'status':'PASS','matrix_entries':25,'reported_cost':answer['reported_cost'],'independently_feasible':checked['valid'],'toy_exact_base_cost':oracle,'toy_gap':checked['normalized_own_cost']-oracle if checked['valid']else None,'routes':checked['routes'],'loads':checked['loads'],'observations':checked['observations'],'num_iterations':answer['num_iterations'],'model_instances':1,'solver_calls':1})
    a=answers['TOY_A_OBS'];u=answers['TOY_A_NOOBS']
    invariant=['routes','native_routes','solver_is_feasible','solver_is_complete','reported_cost','reported_distance','stats','num_iterations','native_distance_matrix']
    for key in invariant:assert a[key]==u[key],('OBSERVER_CHANGED_RESULT',key)
    report={'utc':now(),'status':'PASS','toy_calls_planned':4,'toy_calls_spawned':4,'toy_solver_calls':4,'toy_model_instances':4,'explicit_solution_constructions':0,'new_solver_calls_in_this_check':0,'formal_solver_calls':0,'native_matrix_entries_total':100,'full_outer_supervisor_worker_chain':True,'observer_invariance_checked_fields':invariant,'C_equals_A_not_a_gate':True,'toy_feasibility_pattern_not_a_gate':True,'rows':rows,'freeze_sha256':sha(ROOT/'selftests/toy/FROZEN.json')}
    save(ROOT/'selftests/toy/VERIFIED.json',report);print(json.dumps(report))
if __name__=='__main__':main()
