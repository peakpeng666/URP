"""Readback-gated saved-only report for the fixed 216-slot cost-scale control."""
import json
import math
import resource
import signal
import zipfile
from collections import Counter
from common import ROOT, read, save, sha, now, verify_frozen, verify_old, receipt
from report_core import (ARMS, ROW_AUDIT_KEYS, blank_row, apply_checked,
                         build_summary, historical_diagnostic)


def exact_match(expected, actual, path='root'):
    """Compare all supplied independent fields; float tolerance only for summaries."""
    if isinstance(expected, dict):
        assert isinstance(actual, dict), path
        for key, value in expected.items():
            assert key in actual, path + '.' + key
            exact_match(value, actual[key], path + '.' + key)
    elif isinstance(expected, list):
        assert isinstance(actual, list) and len(expected) == len(actual), path
        for idx, (left, right) in enumerate(zip(expected, actual)):
            exact_match(left, right, path + '[' + str(idx) + ']')
    elif isinstance(expected, float):
        assert type(actual) in (float, int) and math.isclose(expected, actual, rel_tol=1e-12, abs_tol=1e-12), path
    else:
        assert type(expected) is type(actual) and expected == actual, path


def safe_output(relative):
    path = (ROOT / relative).resolve()
    assert path.is_relative_to((ROOT / 'raw/calls').resolve()), 'OUTPUT_PATH_OUTSIDE_RAW_CALLS'
    return path


def collect_saved_evidence():
    # This import is intentionally delayed: endpoint_core is a pure saved-data
    # validator, never the observer/worker/native implementation.
    from endpoint_core import validate_saved
    digest = verify_frozen()
    verify_old()
    raw = receipt('RAW_UNREVIEWED')
    protocol, schedule = read('freeze/PROTOCOL.json'), read('freeze/SCHEDULE.json')
    slots, outer = read('raw/ALL_PLANNED_SLOTS.json'), read('raw/EXECUTOR_FINISHED.json')
    assert len(schedule) == len(slots) == 216
    assert [slot['schedule'] for slot in slots] == schedule
    assert [slot['call_id'] for slot in slots] == [e['call_id'] for e in schedule]
    assert outer['cleanup']['quiescent'] is True
    assert sha(ROOT / protocol['input']['archive']) == protocol['input']['sha256']
    with zipfile.ZipFile(ROOT / protocol['input']['archive']) as archive:
        exact = json.loads(archive.read('independent_supervision/FINAL_AUDIT.json'))
    assert exact['status'] == 'PASS' and exact['verified_fields'] == 12
    oracles = {r['instance_id']: r for r in exact['fields']}
    assert len(oracles) == 12 and set(oracles) == set(protocol['fields'])
    identities = read('input/IDENTITIES.json')['fields']
    problems = {}
    for field in protocol['fields']:
        relative = 'input/' + field + '.json'
        assert sha(ROOT / relative) == identities[field]['input_sha256']
        problems[field] = read(relative)
    rows, answers = [], {}
    for entry, slot in zip(schedule, slots):
        row = blank_row(entry, slot['status'])
        answer = None
        try:
            assert slot['status'] in ('UNREVIEWED_PROCESS_SUCCESS', 'UNREVIEWED_INFEASIBLE'), 'NON_SUCCESS_PROCESS_STATUS'
            assert slot['returncode'] == 0 and slot['process_spawned'] is True and slot['child_reaped'] is True
            stdout, stderr = safe_output(slot['stdout']), safe_output(slot['stderr'])
            assert sha(stdout) == slot['stdout_sha256'] and sha(stderr) == slot['stderr_sha256'], 'RAW_OUTPUT_HASH_MISMATCH'
            answer = json.loads(stdout.read_text())
            assert not outer['ledger_errors'], 'LEDGER_INTEGRITY_FAILURE'
            checked = validate_saved(problems[entry['instance_id']], entry, answer)
            assert checked['valid'] == (slot['status'] == 'UNREVIEWED_PROCESS_SUCCESS'), 'STATUS_FEASIBILITY_MISMATCH'
            apply_checked(row, checked, oracles[entry['instance_id']], answer)
        except (AssertionError, KeyError, TypeError, ValueError, OSError, IndexError, OverflowError) as exc:
            # An endpoint failure cannot leave a partially promoted scientific row.
            row = blank_row(entry, slot['status'])
            row['failure'] = type(exc).__name__ + ':' + str(exc)
        answers[(entry['instance_id'], entry['seed'], entry['proxy'], entry['arm'])] = answer
        rows.append(row)
    historical_rows = read('historical_reference/ALL72_LEGACY250_ROWS.json')
    historical_outputs = read('historical_reference/ALL72_LEGACY250_OUTPUTS.json')
    assert historical_rows['diagnostic_only'] is True and historical_outputs['diagnostic_only'] is True
    old_rows = {(r['instance_id'], r['seed'], r['proxy']): r for r in historical_rows['rows']}
    old_answers = {(r['entry']['instance_id'], r['entry']['seed'], r['entry']['proxy']): r['answer'] for r in historical_outputs['rows']}
    expected_history = {(f, s, p) for f in protocol['fields'] for s in (0, 1, 2) for p in ('E', 'G')}
    assert len(historical_rows['rows']) == len(historical_outputs['rows']) == 72
    assert set(old_rows) == set(old_answers) == expected_history
    diagnostics = []
    for row in rows:
        if row['arm'] != 'A':
            continue
        key = row['instance_id'], row['seed'], row['proxy']
        diagnostics.append(historical_diagnostic(row, answers[(*key, 'A')], old_answers[key], row['valid'], old_rows[key]['valid']))
    assert len(diagnostics) == 72
    summary = build_summary(rows, protocol['fields'])
    return {'utc': now(), 'status': 'AUTHOR_SAVED_REPORT_COMPLETE_PENDING_INDEPENDENT_REVIEW',
            'frozen_files_sha256': digest, 'raw_archive_sha256': raw['sha256'],
            'q5_final_sha256': protocol['input']['sha256'],
            'planned_formal_slots': 216, 'planned_per_arm': 72, 'planned_per_proxy_per_arm': 36,
            'field_denominator': 12, 'seeds_per_field': 3,
            'valid_feasible_slots': sum(row['valid'] for row in rows),
            'raw_status_counts': dict(Counter(row['raw_status'] for row in rows)),
            'formal_known_spawned': outer['known_spawned'],
            'formal_unknown_spawned_slots': outer['unknown_spawned_slots'],
            'toy_solver_calls': protocol['toy_solver_calls'], 'toy_model_instances': protocol['toy_model_instances'],
            'new_solver_calls_in_report': 0, 'new_native_constructions_in_report': 0,
            'rows': rows, **summary,
            'fresh_A_legacy250_diagnostics': diagnostics,
            'fresh_A_legacy250_diagnostic_counts': dict(Counter(d['status'] for d in diagnostics)),
            'historical_reference_cells': 72, 'historical_cells_in_primary': 0,
            'ledger_errors': outer['ledger_errors'],
            'endpoint_definitions': protocol['endpoints'], 'analysis_limits': protocol['analysis'],
            'saved_G_path_evidence': 'Reuse frozen Q5 canonical paths and existing legality/length audits; no new geometry, shortest paths, or physical field scaling.',
            'complete_panel_policy': 'Any invalid or missing required slot makes the corresponding complete-panel cost/gap statistic null.',
            'primary_statistical_unit': '12 previously observed fields. The three seeds and two proxies are repeated measurements, not independent fields.'}


def check_independent(data, audit):
    assert audit['status'] == 'SAVED_EVIDENCE_AUDITED'
    assert audit['raw_archive_sha256'] == data['raw_archive_sha256']
    assert audit['frozen_files_sha256'] == data['frozen_files_sha256']
    assert len(audit['rows']) == len(data['rows']) == 216
    expected = {r['call_id']: r for r in audit['rows']}
    assert len(expected) == len({r['call_id'] for r in data['rows']}) == 216
    assert set(expected) == {r['call_id'] for r in data['rows']}
    for row in data['rows']:
        other = expected[row['call_id']]
        for key in ROW_AUDIT_KEYS:
            # Exact row endpoints have matching computations, not tolerance.
            assert type(row[key]) is type(other[key]) and row[key] == other[key], (row['call_id'], key)
    compared = ['rows']
    for key in ('overall', 'by_proxy', 'per_field', 'paired_rows', 'triple_rows',
                'first_iteration_probe_diagnostics',
                'fresh_A_legacy250_diagnostics', 'fresh_A_legacy250_diagnostic_counts'):
        if key in audit:
            exact_match(audit[key], data[key], key)
            compared.append(key)
    return compared


def report_text(data):
    lines = ['成熟田块成本尺度与罚项上下限对照：固定216槽',
             'A：D与默认罚项界；B：10D与默认罚项界；C：10D且min/max同时乘10。',
             '三臂均为固定250次ILS迭代；默认初始化在该计数之前。同迭代数不等于同CPU或同基本操作量。',
             '主指标为每臂全部72槽的有效可行率。E/G各36槽；田块分母12，seed不是独立田块样本。',
             '主要成本/质量比较按E与G代理分别报告；overall的own-cost/gap混合两个搜索目标，仅为固定面板描述，不能当单一目标。',
             '原单位科学成本必须将保存成本精确除scale，再与原冻结exact真值比较。失败成本/gap为null，不作补跑、补seed或缺失填充。', '']
    for arm in ARMS:
        cell = data['overall']['arms'][arm]
        lines.append(f"{arm}：有效可行{cell['valid_feasible']}/72；精确命中{cell['exact_hits']}/72；全部面板成本/gap{'可计算' if cell['complete_panel'] is not None else '为null（存在失败或未核验槽）'}。")
        for proxy in ('E', 'G'):
            part = data['by_proxy'][proxy]['arms'][arm]
            complete = part['complete_panel']
            gap = complete['metrics']['own_gap_mm']['mean'] if complete else None
            subset = part['conditional_valid_subset']['metrics']['own_gap_mm']['mean']
            lines.append(f"  {proxy}：{part['valid_feasible']}/36，完整面板均值gap={gap}mm；有效子集均值gap={subset}mm，子集分母{part['valid_feasible']}。")
    lines += ['', '配对方向均为右臂减左臂；配对可行率差使用全部72对，质量只在明确共同成功集合内定义。']
    for label, pair in data['overall']['pairs'].items():
        lines.append(f"{label}：共同成功{pair['common_success_count']}/72；可行率差={100 * pair['descriptive_paired_risk_difference_right_minus_left']}个百分点；迁移={pair['paired_success_transitions']}；全部配对均值gap差={pair['complete_panel_mean_deltas']['own_gap_mm']}。")
    triple = data['overall']['three_arm_common_success']
    lines += [f"三臂共同成功{triple['common_success_count']}/72；其条件统计和各配对自身共同成功分母分别报告，不能互相替代。",
              f"fresh A对旧250的全部72格仅作诊断：{data['fresh_A_legacy250_diagnostic_counts']}。历史数据不进入任何主臂或增加样本数。", '',
              '首轮公开整数探针（原始值，未除scale）']
    for arm, item in data['first_iteration_probe_diagnostics']['by_arm'].items():
        lines.append(f"{arm}：可读{item['available']}/72，unknown={item['unknown']}；原始PM快照/1、2、7、1000探针签名={json.dumps(item['observed_raw_signatures'], ensure_ascii=False, separators=(',', ':'))}。")
    lines += ['',
              '观察与解释边界',
              '- callback初始可行性、首次best可行迭代和罚项变化计数来自已保存公开观察；未知仍为unknown，不用缺失值推断状态。',
              '- 250登记小于默认500更新间隔；本设计不识别初始化上限与ILS中点各自的因果贡献。',
              '- C同时改变初始化max和ILS midpoint，且整数探针/舍入等意味着不能声称严格尺度齐次。',
              '- 原始罚后轨迹cost只用于保存诊断，绝不一律除10或当物理路线成本。',
              '- 10D只是目标数值尺度干预，不是把真实田块几何放大10倍。G路径合法性/长度复用原冻结证据，无新增几何或最短路求解。',
              '- E代理的G相对E词典序参考偏移可以为负；仅E已命中最优时才定义E最优集内G并列差，不能把一般偏移叫搜索误差。',
              '- 固定已观察12田块的描述性比较；无独立田块泛化、统计显著性、SOTA、连续几何最优或农业车队部署主张。',
              '- 逐田块、逐seed、逐proxy、完整失败和条件子集见SUMMARY.json；观察不触发筛选、救场或重跑。',
              '- 本报告仅读取已保存输出，新增solver调用0，新增native模型构造0。']
    return '\n'.join(lines) + '\n'


def main():
    resource.setrlimit(resource.RLIMIT_CPU, (30, 30))
    resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
    signal.alarm(120)
    data = collect_saved_evidence()
    audit_path = 'independent_supervision/results/SAVED_SCALE_AUDIT.json'
    audited = check_independent(data, read(audit_path))
    data['status'] = 'INDEPENDENT_SAVED_VERIFIED_PENDING_REPORT_REVIEW'
    data['independent_saved_audit_sha256'] = sha(ROOT / audit_path)
    data['independently_compared_sections'] = audited
    save(ROOT / 'reports/STARTED.json', {'utc': now(), 'solver_calls': 0,
         'native_constructions': 0, 'independent_endpoint_comparison_passed_before_writing': True})
    save(ROOT / 'reports/SUMMARY.json', data)
    with (ROOT / 'reports/REPORT_ZH.txt').open('x') as stream:
        stream.write(report_text(data))
    print(json.dumps({'valid_feasible_slots': data['valid_feasible_slots'], 'planned': 216,
                      'report': 'reports/REPORT_ZH.txt', 'independently_compared_sections': audited}, ensure_ascii=False))


if __name__ == '__main__':
    main()
