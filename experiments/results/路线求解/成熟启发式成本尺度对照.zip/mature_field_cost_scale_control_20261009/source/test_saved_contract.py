"""Replay saved artificial outputs and adversarial dictionaries; no new native/solver."""
import copy,json,resource,signal
from common import ROOT,read,save,now
from gates import get_schedule,verify_toy_freeze
from endpoint_core import validate_saved
from ledger import reconcile

def main():
    resource.setrlimit(resource.RLIMIT_CPU,(30,30));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2));signal.alarm(120)
    verify_toy_freeze();problem=read('selftests/toy/FIXTURE.json');schedule=get_schedule('toy');slots=read('selftests/toy/raw/ALL_PLANNED_SLOTS.json')
    answers=[read(s['stdout'])for s in slots]
    checked=[validate_saved(problem,e,a)for e,a in zip(schedule,answers)]
    assert checked[0]['normalized_own_cost']==checked[2]['normalized_own_cost']==300002
    assert checked[1]['valid'] is False and checked[1]['normalized_own_cost'] is None and checked[1]['loads']==[4]
    cases=[]
    def rejects(label,index,mutate):
        x=copy.deepcopy(answers[index]);mutate(x)
        try:validate_saved(problem,schedule[index],x)
        except (AssertionError,KeyError,TypeError,ValueError):cases.append(label);return
        raise AssertionError('ACCEPTED_BAD_SAVED_OUTPUT:'+label)
    rejects('scaled_cost_not_divisible',2,lambda x:x.__setitem__('reported_cost',x['reported_cost']+1))
    rejects('matrix_changed',2,lambda x:x['native_distance_matrix'][0].__setitem__(1,750001))
    rejects('capacity_changed',0,lambda x:x['native_model_parameters']['vehicle'].__setitem__('capacity',[4]))
    rejects('infeasible_promoted',1,lambda x:x.__setitem__('solver_is_feasible',True))
    rejects('bad_activity_index',0,lambda x:x['native_routes'][0]['activities'][1].__setitem__('idx',99))
    rejects('unexpected_PM_update',0,lambda x:x['penalty_observation']['rows'][20]['observed_post_registration_penalties'][0].__setitem__(0,100000))
    rejects('integer_probe_changed',2,lambda x:x['penalty_observation']['rows'][0]['observed_search_evaluator_integer_probes'][1].__setitem__('load',1000000))
    rejects('wrong_update_interval',0,lambda x:x['default_solve_params']['values']['penalty']['values'].__setitem__('solutions_between_updates',50))
    rejects('fake_early_feasibility',1,lambda x:x['penalty_observation'].__setitem__('first_best_feasible_iteration',0))
    missing,errors=reconcile(schedule,'','')
    assert len(missing)==4 and not errors and all(x['process_spawned'] is False for x in missing)
    duplicate='\n'.join(json.dumps(slots[0])for _ in range(2));_,errors=reconcile(schedule,duplicate,'')
    assert 'DUPLICATE_RESULT:'+slots[0]['call_id'] in errors
    report={'status':'PASS','utc':now(),'solver_calls':0,'native_constructions':0,'saved_toy_outputs_replayed':4,'rejected_mutations':cases,'ledger_missing_retained':4,'ledger_duplicates_rejected':True,'resource_budget':{'CPU_seconds':30,'AS_bytes':512*1024**2,'wall_seconds':120}}
    save(ROOT/'selftests/SAVED_CONTRACT_REPLAY.json',report);print(json.dumps(report))
if __name__=='__main__':main()
