"""One cold official PyVRP0.14.0 ILS call using only one frozen integer matrix."""
import sys,json,math,time,resource,dataclasses,hashlib
from importlib.metadata import version
from matrix_adapter import build_model,native_model_parameters,validate_payload
from io_guard import verified_io_guard

def parameter_description(obj):
    if obj is None or isinstance(obj,(str,int,float,bool)):return obj
    if isinstance(obj,type):return obj.__module__+'.'+obj.__name__
    if type(obj).__name__ in ('IteratedLocalSearchCallbacks','ReadonlyPenaltyObserver'):
        return {'type':type(obj).__module__+'.'+type(obj).__name__,'values':{}}
    if isinstance(obj,(list,tuple)):return [parameter_description(v)for v in obj]
    values={}
    for name in dir(obj):
        if not name.startswith('_'):
            value=getattr(obj,name)
            if not callable(value):values[name]=parameter_description(value)
    return {'type':type(obj).__module__+'.'+type(obj).__name__,'values':values}


def extract_routes(solution, data, location_to_node):
    native, routes = [], []
    for route in solution.routes():
        mapped, activities = [], []
        for activity in route:
            if activity.is_client():
                kind = 'CLIENT'
                location = data.client(activity.idx).location
            elif activity.is_depot():
                kind = 'DEPOT'
                location = data.depot(activity.idx).location
            else:
                raise ValueError('Unexpected shipment activity in CVRP')
            node = location_to_node[location]
            mapped.append(node)
            activities.append({'type':kind,'idx':activity.idx,'location':location,'node':node})
        assert mapped and mapped[0] == mapped[-1] == 0 and 0 not in mapped[1:-1]
        assert len(mapped) >= 3
        assert route.start_depot() == route.end_depot() == 0
        assert route.vehicle_type() == 0 and route.num_trips() == 1
        routes.append(mapped)
        native.append({'activities':activities,'distance':route.distance(),
                       'delivery':route.delivery(),'vehicle_type':route.vehicle_type(),
                       'start_depot':route.start_depot(),'end_depot':route.end_depot(),
                       'num_trips':route.num_trips(),'is_feasible':route.is_feasible()})
    return routes, native


def run(payload):
    validate_payload(payload)
    from pyvrp import solve,SolveParams
    from pyvrp.stop import MaxIterations
    from pyvrp.PenaltyManager import PenaltyParams
    from pyvrp.IteratedLocalSearch import IteratedLocalSearchParams
    from observer import ReadonlyPenaltyObserver
    package_version=version('pyvrp')
    assert package_version=='0.14.0'
    denied,allowed=[],[]
    audit,warning_source=verified_io_guard(denied,allowed)
    sys.addaudithook(audit)
    wall,cpu=time.perf_counter(),time.process_time()
    data,matrix,mapping=build_model(payload)
    native_parameters=native_model_parameters(data,payload)
    observer=ReadonlyPenaltyObserver(lambda sol:extract_routes(sol,data,mapping)[0]) if payload['observe_penalties'] else None
    params=SolveParams(ils=IteratedLocalSearchParams(callbacks=observer),penalty=PenaltyParams(min_penalty=payload['min_penalty'],max_penalty=payload['max_penalty']))
    actual_params=parameter_description(params)
    built,build_cpu=time.perf_counter(),time.process_time()
    result=solve(data,stop=MaxIterations(payload['max_iterations']),seed=payload['seed'],
                 collect_stats=True,display=False,params=params,initial_solution=None)
    solved,solve_cpu=time.perf_counter(),time.process_time()
    assert result.num_iterations==payload['max_iterations']==len(result.stats.data)
    routes,native=extract_routes(result.best,data,mapping)
    cost=result.cost()
    cost=int(cost) if math.isfinite(cost) else None
    internal=sum(matrix[a][b] for r in routes for a,b in zip(r,r[1:]))
    if result.is_feasible():assert cost==internal==result.best.distance()
    readback=data.distance_matrix(0).tolist()
    assert readback==matrix
    return {'solver':'PyVRP','version':package_version,'algorithm':'ILS',
      'seed':payload['seed'],'max_iterations':payload['max_iterations'],
      'arm':payload['arm'],'scale':payload['scale'],'observe_penalties':payload['observe_penalties'],
      'penalty_observation':observer.observation() if observer else None,
      'model_instances':1,'solver_calls':1,'explicit_solution_constructions':0,
      'solver_is_feasible':result.is_feasible(),'solver_is_complete':result.best.is_complete(),
      'reported_cost':cost,'reported_distance':result.best.distance(),
      'reported_duration_cost':result.best.duration_cost(),
      'reported_fixed_vehicle_cost':result.best.fixed_vehicle_cost(),
      'reported_num_routes':result.best.num_routes(),'native_model_parameters':native_parameters,
      'default_solve_params':actual_params,'native_distance_matrix':readback,
      'native_matrix_entries_checked':len(matrix)**2,
      'model_matrix_sha256':hashlib.sha256(json.dumps(readback,separators=(',',':')).encode()).hexdigest(),
      'routes':routes,'native_routes':native,'internal_route_cost':internal,
      'num_iterations':result.num_iterations,'solver_loop_runtime':result.runtime,
      'build_wall_seconds_audit_only':built-wall,'build_cpu_seconds_audit_only':build_cpu-cpu,
      'solve_wall_seconds_audit_only':solved-built,'solve_cpu_seconds_audit_only':solve_cpu-build_cpu,
      'stats_runtime_per_iteration':result.stats.runtimes,
      'stats':[dataclasses.asdict(d) for d in result.stats],
      'denied_io_events':denied,'allowed_warning_source_reads':allowed,
      'warning_source_verification':warning_source,'reference_or_history_payload_fields':[],
      'limit_semantics':'Exactly250 ILS iterations AFTER official initialization. Guards15CPU/25wall are failures; no equal primitive-work or CPU claim.'}

def configure_worker_limits():
    if not __debug__:raise RuntimeError('Assertions must be enabled')
    before={'AS_bytes':list(resource.getrlimit(resource.RLIMIT_AS)),
            'CPU_seconds':list(resource.getrlimit(resource.RLIMIT_CPU))}
    resource.setrlimit(resource.RLIMIT_CPU,(15,15))
    resource.setrlimit(resource.RLIMIT_AS,(1536*1024**2,1536*1024**2))
    after={'AS_bytes':list(resource.getrlimit(resource.RLIMIT_AS)),
           'CPU_seconds':list(resource.getrlimit(resource.RLIMIT_CPU))}
    return {'inherited':before,'effective':after}

if __name__ == '__main__':
    limits=configure_worker_limits()
    payload=json.load(sys.stdin)
    result=run(payload)
    result['resource_limits']=limits
    result['worker_maxrss_KiB_audit_only']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    json.dump(result,sys.stdout,ensure_ascii=False,separators=(',',':'),allow_nan=False)
    sys.stdout.write('\n')
