"""Post-seal audit and reference-only scoring. Never calls a solver."""
import json,hashlib,shutil,re,statistics,csv,collections
from pathlib import Path
from datetime import datetime,timezone
from checker import check,self_test
P=Path(__file__).resolve().parent
SOURCE=Path('/workspace/shared/official_cvrp_benchmarks_20261008')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,data):
    with (P/name).open('x') as f:json.dump(data,f,ensure_ascii=False,indent=2);f.write('\n')
freeze=json.loads((P/'freeze.json').read_text());seal=json.loads((P/'output_seal.json').read_text())
for manifest in (freeze,seal):
    for name,digest in manifest['sha256'].items():assert sha(P/name)==digest,name
assert seal['reference_files_opened']==0
started=datetime.now(timezone.utc).isoformat()
requests=json.loads((P/'requests.json').read_text());names=sorted({r['instance'] for r in requests})
refs={};reference_evidence=[]
for name in names:
    raw=SOURCE/'raw'/f'{name}.sol'
    content=raw.read_text();matches=re.findall(r'^Cost\s+([0-9]+)\s*$',content,re.MULTILINE|re.IGNORECASE)
    assert len(matches)==1,(name,'reference cost parse')
    refs[name]=int(matches[0])
    for src in [raw,SOURCE/'raw'/f'{name}.vrp',SOURCE/'clean'/f'{name}.reference_solution.json']:
        dst=P/'provenance'/src.name;shutil.copyfile(src,dst)
        reference_evidence.append({'source':str(src),'local':str(dst.relative_to(P)),'sha256':sha(dst)})
shutil.copyfile(SOURCE/'manifest.json',P/'provenance'/'source_manifest.json')
shutil.copyfile(SOURCE/'README.zh.md',P/'provenance'/'source_README.zh.md')
write('reference_access.json',{'first_reference_read_after_utc':started,'output_sealed_at_utc':seal['sealed_at_utc'],
 'output_seal_sha256':sha(P/'output_seal.json'),'purpose':'Post-seal gap scoring only','references':refs,'files':reference_evidence})
resources={r['run_id']:r for r in json.loads((P/'process_resources.json').read_text())}
rows=[];audits=[];phase_totals=collections.defaultdict(lambda:{'cpu_s':0.0,'wall_s':0.0})
for req in requests:
    resource_record=resources[req['run_id']];path=P/'raw'/f"{req['run_id']}.result.json"
    result=json.loads(path.read_text()) if path.exists() else None
    audited=None
    if result and result['assignment_returned']:
        inst=json.loads((P/'inputs'/f"{req['instance']}.json").read_text())
        audited=check(inst,result['routes_node_indices'],result['objective_integer'])
        assert audited==result['independent_check'],req['run_id']
        assert result['routes_original_node_ids']==[[inst['node_ids_original'][j] for j in route] for route in result['routes_node_indices']]
    valid=bool(audited and audited['valid']);cost=audited['integer_cost'] if valid else None
    if result:
        for phase,times in result['phases'].items():
            for key in ['cpu_s','wall_s']:phase_totals[phase][key]+=times[key]
    row={**req,'outcome':result['outcome'] if result else 'no_result',
         'status_code':result['status_code'] if result else None,'status_name':result['status_name'] if result else None,
         'valid':valid,'cost':cost,'reference_cost':refs[req['instance']],
         'gap_pct':100*(cost-refs[req['instance']])/refs[req['instance']] if valid else None,
         'used_vehicles':audited['used_vehicles'] if valid else None,
         'search_wall_s':result['phases'].get('search',{}).get('wall_s') if result else None,
         'search_cpu_s':result['phases'].get('search',{}).get('cpu_s') if result else None,
         'process_wall_s':resource_record.get('observed_process_wall_s'),
         'process_cpu_s':resource_record.get('total_cpu_s'),'process_max_rss_kib':resource_record.get('max_rss_kib'),
         'returncode':resource_record.get('returncode'),'reaped':resource_record.get('reaped',False)}
    rows.append(row);audits.append({'run_id':req['run_id'],'check':audited})
cells=[]
for name in names:
    for ms in [250,1000]:
        rs=sorted([r for r in rows if r['instance']==name and r['budget_ms']==ms],key=lambda r:r['repeat'])
        costs=[r['cost'] for r in rs if r['valid']];gaps=[r['gap_pct'] for r in rs if r['valid']]
        cells.append({'instance':name,'budget_ms':ms,'scheduled':3,'valid_count':len(costs),
                      'costs_by_repeat':[r['cost'] for r in rs],'gaps_pct_by_repeat':[r['gap_pct'] for r in rs],
                      'median_cost':statistics.median(costs) if costs else None,
                      'min_cost':min(costs) if costs else None,'max_cost':max(costs) if costs else None,
                      'median_gap_pct':statistics.median(gaps) if gaps else None,
                      'status_counts':dict(collections.Counter(str(r['status_name']) for r in rs)),
                      'search_wall_s_range':[min(r['search_wall_s'] for r in rs if r['search_wall_s'] is not None),max(r['search_wall_s'] for r in rs if r['search_wall_s'] is not None)] if any(r['search_wall_s'] is not None for r in rs) else None})
budget_summary=[]
for ms in [250,1000]:
    c=[c for c in cells if c['budget_ms']==ms]
    med=[x['median_gap_pct'] for x in c if x['median_gap_pct'] is not None]
    budget_summary.append({'budget_ms':ms,'statistical_units':3,'valid_instances':len(med),
        'mean_of_instance_median_gap_pct':statistics.mean(med) if med else None,
        'median_of_instance_median_gap_pct':statistics.median(med) if med else None,
        'note':'Descriptive only, no independent-repeat inference.'})
summary={'statistical_units':3,'scheduled_runs':18,'valid_assignments':sum(r['valid'] for r in rows),
 'native_status_counts':dict(collections.Counter(str(r['status_name']) for r in rows)),
 'all_launched_children_reaped':all(r['reaped'] for r in rows),
 'reference_costs':refs,'cells':cells,'budget_summary':budget_summary,'phases_sum':dict(phase_totals),
 'failure_or_unknown_reruns':0,'interpretation':'Quality at two specified wall-clock search limits. Not comparable as an equal compute budget to old pure-Python160k evaluation runs. Three instances only.'}
write('evaluated_runs.json',rows);write('postseal_independent_checks.json',audits);write('summary.json',summary)
write('verification.json',{'frozen_files_unchanged':True,'sealed_raw_files_unchanged':True,
                          'checker_self_tests':self_test(),'all_returned_assignments_valid':all(r['valid'] for r in rows if r['outcome']!='no_result'),
                          'distinct_process_count':len({r['pid'] for r in resources.values() if r.get('launched')}),
                          'audit_after_seal':True,'reference_only_used_for_gap_scoring':True})
with (P/'metrics.csv').open('x',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
run=json.loads((P/'run_resources.json').read_text());outer=json.loads((P/'run.resource.json').read_text())
lines=['官方 CVRP 成熟求解器小型质量对照','',
 '协议：OR-Tools 9.14.6206；PARALLEL_CHEAPEST_INSERTION + GUIDED_LOCAL_SEARCH (λ=0.1)；K≤5；整数 EUC_2D；全部客户必访。',
 '3 个官方实例，每个时限预定重复 3 次，共 18 次；每次新建独立子进程。同坐标客户保留独立身份。',
 '250ms / 1000ms 是原生搜索墙钟时限，导入、建模、取解、检查、退出的完整实际开销另计。',
 '参考值和参考路线在全部原始输出封存之后才读取，仅用于 gap 评分；无 warm start、目标值提前停搜或调参。','',
 f"有效解：{summary['valid_assignments']}/18；原生状态：{summary['native_status_counts']}。",
 '所有返回路线均由坐标重新构建整数成本，并复核容量、车辆数和客户精确覆盖。','']
for cell in cells:
    gaps=', '.join('无解' if g is None else f'{g:.4f}%' for g in cell['gaps_pct_by_repeat'])
    lines.append(f"{cell['instance']} | {cell['budget_ms']}ms | 成本 {cell['costs_by_repeat']} | gap [{gaps}] | 有效 {cell['valid_count']}/3")
lines.extend(['',f"18 个求解子进程总 CPU：{run['children_cpu_s']:.6f}s；整批进程树 CPU：{outer['process_tree_total_cpu_s']:.6f}s，观测墙钟：{outer['observed_process_tree_wall_s']:.6f}s。",
 f"单子进程最大 RSS：{run['child_peak_rss_kib_max']} KiB；全部独立 PID 已 wait4 收割：{run['all_launched_children_reaped']}。",
 '完整准备/执行/评分/打包开销见各 *.resource.json 与 resource_accounting.json；不要把整批进程树 CPU 与子进程 CPU 重复相加。','',
 '结论边界：这是两个指定时限下的成熟工具质量标定。3 实例是统计单位；重复仅查看时间截断搜索波动，不能当作18个独立实例。不与旧纯Python 160k评估次数宣称同预算排名。',
 '更长时限的单次结果不保证支配较短时限；固定配置在本小样本上的表现不能外推到整个 CVRP。原生 ROUTING_SUCCESS 不等于最优证明。',
 '复现：使用现有 ortools==9.14.6206 环境，在全新目录放置源码与 inputs 后执行 prepare.py、supervise.py、finalize.py。参数与顺序已冻结；原目录拒绝覆盖或补跑。',
 '原始结果、完整路线、原生状态、阶段/整进程资源、封存哈希与来源证据均随包提供；本次不安装、不调用模型/API、不产生新购买。'])
(P/'report_zh.txt').write_text('\n'.join(lines)+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))
