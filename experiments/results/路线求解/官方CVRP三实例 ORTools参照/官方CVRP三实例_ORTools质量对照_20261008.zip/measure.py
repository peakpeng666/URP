"""Measure one entry-point process tree, including imports and process exit."""
import sys,os,subprocess,time,json,resource
from pathlib import Path
P=Path(__file__).resolve().parent
label=sys.argv[1]; target=sys.argv[2]; w=time.perf_counter(); c=time.process_time()
with (P/f'{label}.stdout').open('x') as out,(P/f'{label}.stderr').open('x') as err:
    child=subprocess.Popen([sys.executable,'-B',str(P/target)],stdout=out,stderr=err,cwd=P)
    pid,status,usage=os.wait4(child.pid,0)
    rc=os.waitstatus_to_exitcode(status);child.returncode=rc
record={'label':label,'target':target,'pid':pid,'returncode':rc,'reaped':True,
 'process_tree_user_cpu_s':usage.ru_utime,'process_tree_system_cpu_s':usage.ru_stime,
 'process_tree_total_cpu_s':usage.ru_utime+usage.ru_stime,'observed_process_tree_wall_s':time.perf_counter()-w,
 'process_tree_max_rss_kib':usage.ru_maxrss,'wrapper_internal_cpu_s':time.process_time()-c,
 'accounting':'Linux wait4 resource usage includes reaped descendants. Do not add run child CPU again.'}
with (P/f'{label}.resource.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps(record),flush=True)
raise SystemExit(rc)
