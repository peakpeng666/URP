"""Post-run portable replay helper. It was not used in the reported benchmark.

Run with an existing ortools==9.14.6206 interpreter and a NEW output directory.
No network/install is performed. Prior raw outputs and references are never
copied into the solve directory before its raw output seal exists.
"""
import sys,json,hashlib,subprocess,shutil,re,csv
from pathlib import Path
P=Path(__file__).resolve().parent
if len(sys.argv)!=2:raise SystemExit('usage: python -B reproduce.py /absolute/new/output-directory')
dest=Path(sys.argv[1]).resolve()
if dest.exists():raise SystemExit('Destination must not already exist; no overwrite or retry.')
import ortools
if ortools.__version__!='9.14.6206':raise SystemExit('Use an existing ortools==9.14.6206 environment; no automatic install.')
frozen=json.loads((P/'freeze.json').read_text())
for name,digest in frozen['sha256'].items():
    if hashlib.sha256((P/name).read_bytes()).hexdigest()!=digest:raise SystemExit(f'Frozen file changed: {name}')
dest.mkdir(parents=True);(dest/'raw').mkdir()
for name in frozen['sha256']:
    target=dest/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(P/name,target)
shutil.copyfile(P/'freeze.json',dest/'freeze.json')
subprocess.run([sys.executable,'-B',str(dest/'measure.py'),'run','supervise.py'],cwd=dest,check=True)
seal=json.loads((dest/'output_seal.json').read_text())
for name,digest in seal['sha256'].items():
    assert hashlib.sha256((dest/name).read_bytes()).hexdigest()==digest
# This section is deliberately after the subprocess seal, with no solver call.
sys.path.insert(0,str(dest))
from checker import check
requests=json.loads((dest/'requests.json').read_text());rows=[]
for req in requests:
    name=req['instance'];input_data=json.loads((dest/'inputs'/f'{name}.json').read_text())
    cost=int(re.search(r'^Cost\s+(\d+)\s*$',(P/'provenance'/f'{name}.sol').read_text(),re.MULTILINE|re.IGNORECASE).group(1))
    path=dest/'raw'/f"{req['run_id']}.result.json"
    result=json.loads(path.read_text()) if path.exists() else None
    checked=check(input_data,result['routes_node_indices'],result['objective_integer']) if result and result['assignment_returned'] else None
    objective=checked['integer_cost'] if checked and checked['valid'] else None
    rows.append({**req,'status_name':result['status_name'] if result else None,'check':checked,
                 'reference_cost':cost,'gap_pct':100*(objective-cost)/cost if objective is not None else None})
(dest/'portable_replay_scores.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
print('Replay completed and reaped; see raw outputs, resource logs, output_seal.json and portable_replay_scores.json.')
