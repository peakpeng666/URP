"""Finalize a private research artifact; no network, solver or model calls."""
import json,hashlib,zipfile,sys,time,resource
from pathlib import Path
from datetime import datetime,timezone
P=Path(__file__).resolve().parent
W=time.perf_counter();C=time.process_time()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['freeze.json','output_seal.json']:
    for rel,digest in json.loads((P/name).read_text())['sha256'].items():assert sha(P/rel)==digest,rel
phase_resources={name:json.loads((P/f'{name}.resource.json').read_text()) for name in ['prepare','run','finalize']}
cpu=sum(x['process_tree_total_cpu_s']+x['wrapper_internal_cpu_s'] for x in phase_resources.values())
wall=sum(x['observed_process_tree_wall_s'] for x in phase_resources.values())
accounting={'recorded_at_utc':datetime.now(timezone.utc).isoformat(),'measured_phases':phase_resources,
 'prepare_run_score_inclusive_cpu_plus_observed_wrapper_cpu_s':cpu,
 'prepare_run_score_sum_observed_process_wall_s':wall,
 'under60cpu_120wall_for_measured_core_dynamic_work':cpu<60 and wall<120,
 'benchmark_children':json.loads((P/'run_resources.json').read_text()),
 'packaging_accounting':'Outer complete package process and wrapper are measured separately in package.resource.json. That file is produced after archive creation and remains an accompanying sidecar.',
 'scope':'Actual executable preparation, benchmark and scoring, including interpreter imports/exits. Text editing, tool transport and assistant deliberation are not benchmark execution wall time.',
 'double_count_warning':'run.resource.json already includes reaped worker descendants; do not add its child CPU a second time.',
 'rss_semantics':'Per-process wait4 ru_maxrss is Linux KiB peak RSS. Process-tree maxRSS is a high-water maximum, not a sum of live concurrent process RSS. Phase RSS is cumulative.',
 'phase_cpu_semantics':'time.process_time supplies per-phase CPU. Very short phases may be reported zero due observed runtime accounting; complete-process wait4 is the resource total.',
 'not_same_budget_as_old_python160k':True,'retries':0}
(P/'resource_accounting.json').write_text(json.dumps(accounting,ensure_ascii=False,indent=2)+'\n')
summary=json.loads((P/'summary.json').read_text())
readme='''Official CVRP / OR-Tools quality reference, 2026-10-08

Start with report_zh.txt, summary.json and metrics.csv. Full routes and native
statuses are in raw/*.result.json. Per-run wait4 CPU, observed spawn-to-reap wall,
maxRSS, exit codes and reaping evidence are in raw/*.resource.json.

Frozen design: three verified official CVRP instances, K <= 5, mandatory unique
customer IDs even when coordinates coincide, exact TSPLIB EUC_2D integer costs.
OR-Tools 9.14.6206 CP Routing; PARALLEL_CHEAPEST_INSERTION and GLS(lambda=0.1).
250ms and 1000ms search-wall limits; three predeclared repetitions each; same
seed for all requests. Fresh interpreter for every request. No compensation
or retries. Three instances are the statistical units, not eighteen runs.

Integrity:
  freeze.json hashes all pre-solve source, inputs, configs and request order.
  output_seal.json hashes all completed raw outputs before reference access.
  reference_access.json records later reference-only gap scoring.
  input_provenance.json links exact input bytes to the prior verified package.
  provenance/source_manifest.json retains official URLs, hashes and terms.
  FILE_INVENTORY.json hashes the artifact members (excluding itself/archive).

Portable replay (no install, network or original source-directory required):
  Use an existing Python environment with ortools==9.14.6206 and the locked
  dependencies. Do not modify the reported output directory. Invoke:
    python -B reproduce.py /absolute/path/to/a/new/replay_directory
  reproduce.py verifies frozen inputs, copies the frozen experiment into the
  new directory, executes exactly 18 independent children once, seals outputs,
  and only then loads the bundled reference costs for portable replay scores.
  The replay helper was authored after the reported experiment and has only
  been syntax/readiness checked here; it was NOT executed, to avoid new runs.
  Changing machine load or timing can change a wall-limited solution; exact
  cost reproduction is not guaranteed. No Ubuntu22.04/Python3.10 acceptance
  claim is made. Actual tested environment is in environment.json.

Core historical entry points: prepare.py created original freeze from the
verified local data package; supervise.py ran the request list; finalize.py
scored against that local package. For portable replay use reproduce.py rather
than those original absolute-path preparation/scoring entry points.

Resource boundaries:
  prepare.resource.json, run.resource.json, finalize.resource.json measure
  complete executable process trees. run totals already include worker CPU.
  resource_accounting.json aggregates these without double counting.
  package.resource.json is a measured post-archive sidecar, delivered beside
  the ZIP. A root audit may append its own audit evidence before final upload.

Scope and permissions:
  No new installations, purchases, API/model calls, uploads, public sharing or
  changes to old experiment packages. This is a private research bundle.
  CVRPLIB data terms allow research use; public redistribution rights were not
  established. See provenance/source_manifest.json for the original terms.
  This is quality calibration at two search limits, never an equal-budget
  ranking against old pure-Python160k evaluation-count experiments.
'''
(P/'README.txt').write_text(readme)
with (P/'report_zh.txt').open('a') as f:
    f.write(f'\n资源补充：准备+整批执行+评分含进程退出及已观测包装器CPU，共 {cpu:.6f} CPU秒；各执行进程观测墙钟合计 {wall:.6f} 秒。完整打包资源另见随包侧文件 package.resource.json。\n')
    f.write('便携复现请使用 README.txt 的 reproduce.py 入口；上文 prepare/finalize 属原始路径入口，原始来源目录不在时不适用。复现入口只做语法核查，未额外执行求解。\n')
exclude={'FILE_INVENTORY.json','archive.sha256','official_cvrp_ortools_reference_20261008.zip','package.resource.json','package.stdout','package.stderr'}
files=[p for p in sorted(P.rglob('*')) if p.is_file() and p.name not in exclude and '__pycache__' not in p.parts]
inventory={'created_at_utc':datetime.now(timezone.utc).isoformat(),'files':[
 {'path':str(p.relative_to(P)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files]}
(P/'FILE_INVENTORY.json').write_text(json.dumps(inventory,ensure_ascii=False,indent=2)+'\n')
archive=P/'official_cvrp_ortools_reference_20261008.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for p in files+[P/'FILE_INVENTORY.json']:z.write(p,str(p.relative_to(P)))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
(P/'archive.sha256').write_text(sha(archive)+'  '+archive.name+'\n')
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),
                  'members':len(files)+1,'internal_package_cpu_s':time.process_time()-C,
                  'internal_package_wall_s':time.perf_counter()-W,'tested_zip':True}))
