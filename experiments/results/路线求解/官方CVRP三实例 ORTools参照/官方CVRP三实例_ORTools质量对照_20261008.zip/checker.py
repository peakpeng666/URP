"""Independent CVRP checker: reconstruct distances from coordinates, not matrix."""
import math

def integer_distance(a, b):
    squared = sum((x-y)**2 for x,y in zip(a,b))
    lower = math.isqrt(squared)
    return lower + int(4*squared >= (2*lower+1)**2)

def check(instance, routes, solver_objective=None):
    errors=[]; seen=[]; loads=[]; costs=[]
    n=instance['dimension']; coords=instance['coordinates']; demands=instance['demands']
    if not isinstance(routes,list):
        return {'valid':False,'errors':['routes_not_list']}
    if len(routes)>5: errors.append('too_many_vehicle_routes')
    for v,route in enumerate(routes):
        if not isinstance(route,list) or len(route)<2 or route[0]!=0 or route[-1]!=0:
            errors.append(f'route_{v}_endpoints'); continue
        if any(type(j) is not int or not 0<=j<n for j in route):
            errors.append(f'route_{v}_node_range'); continue
        customers=route[1:-1]
        if 0 in customers: errors.append(f'route_{v}_internal_depot')
        seen.extend(customers)
        load=sum(demands[j] for j in customers); loads.append(load)
        if load>instance['capacity']:errors.append(f'route_{v}_capacity')
        costs.append(sum(integer_distance(coords[a],coords[b]) for a,b in zip(route,route[1:])))
    expected=set(range(1,n)); actual=set(seen)
    if len(seen)!=len(actual): errors.append('duplicate_customer')
    if actual!=expected: errors.append('customer_coverage')
    used=sum(len(r)>2 for r in routes if isinstance(r,list))
    if used>5:errors.append('used_vehicles_over_five')
    total=sum(costs)
    if solver_objective is not None and total!=solver_objective:errors.append('objective_mismatch')
    return {'valid':not errors,'errors':errors,'integer_cost':total,'route_costs':costs,
            'route_loads':loads,'used_vehicles':used,'customer_visits':len(seen),
            'unique_customers':len(actual),'expected_customers':n-1,
            'missing_customers':sorted(expected-actual),'unexpected_customers':sorted(actual-expected)}

def self_test():
    x={'dimension':4,'coordinates':[[0,0],[1,1],[1,1],[3,4]],'demands':[0,2,3,4],'capacity':5}
    route=[[0,1,2,0],[0,3,0]]
    assert integer_distance([0,0],[1,1])==1
    assert integer_distance([0,0],[3,4])==5
    assert check(x,route,12)['valid']
    assert not check(x,[[0,1,2,3,0]])['valid']
    assert not check(x,[[0,1,0],[0,3,0]])['valid']
    assert not check(x,[[0,1,2,0],[0,2,3,0]])['valid']
    assert not check(x,route,13)['valid']
    assert not check(x,[[0,1,2,0],[0,3,0]]+[[0,0]]*4)['valid']
    assert not check(x,[[0,1,0,2,0],[0,3,0]])['valid']
    return {'passed':True,'cases':8,'includes_distinct_colocated_customers':True}
