"""Freeze local source and exact solver inputs without opening any reference solution."""
import json,hashlib,sys,os,platform,importlib.metadata,shutil,collections
from pathlib import Path
from datetime import datetime,timezone
import ortools
from ortools.constraint_solver import pywrapcp,routing_enums_pb2
from ortools.util import optional_boolean_pb2
from checker import integer_distance,self_test
P=Path(__file__).resolve().parent
SOURCE=Path('/workspace/shared/official_cvrp_benchmarks_20261008')
NAMES=['A-n32-k5','B-n31-k5','P-n40-k5'];SEED=2026100801
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,data):
    with (P/name).open('x') as f:json.dump(data,f,ensure_ascii=False,indent=2);f.write('\n')
assert ortools.__version__=='9.14.6206'
assert not (P/'freeze.json').exists()
input_records=[]
for name in NAMES:
    src=SOURCE/'clean'/f'{name}.instance.json'; dest=P/'inputs'/f'{name}.json'
    shutil.copyfile(src,dest);d=json.loads(dest.read_text())
    assert d['reference_solutions_excluded_from_instance'] is True
    assert d['depot']==0 and d['fixed_k']==5 and d['edge_weight_type']=='EUC_2D'
    assert len(d['coordinates'])==len(d['demands'])==d['dimension']
    assert all(type(z) is int for xy in d['coordinates'] for z in xy)
    reconstructed=[[integer_distance(a,b) for b in d['coordinates']] for a in d['coordinates']]
    assert reconstructed==d['distance_matrix']
    groups=collections.defaultdict(list)
    for j,xy in enumerate(d['coordinates']):groups[tuple(xy)].append(j)
    duplicates=[v for v in groups.values() if len(v)>1]
    input_records.append({'name':name,'source_path':str(src),'source_sha256':sha(src),'local_sha256':sha(dest),
                          'dimension':d['dimension'],'distinct_colocated_node_index_groups':duplicates,
                          'matrix_verified_against_integer_coordinate_reconstruction':True})
requests=[]
for repeat in range(1,4):
    order=NAMES[repeat-1:]+NAMES[:repeat-1]
    for ix,name in enumerate(order):
        budgets=[250,1000] if (ix+repeat-1)%2==0 else [1000,250]
        for ms in budgets:
            requests.append({'sequence':len(requests)+1,'instance':name,'budget_ms':ms,'repeat':repeat,
                             'seed':SEED,'run_id':f'{name}__{ms}ms__r{repeat}'})
write('requests.json',requests)
for ms in [250,1000]:
    params=pywrapcp.DefaultRoutingSearchParameters()
    params.first_solution_strategy=routing_enums_pb2.FirstSolutionStrategy.PARALLEL_CHEAPEST_INSERTION
    params.local_search_metaheuristic=routing_enums_pb2.LocalSearchMetaheuristic.GUIDED_LOCAL_SEARCH
    params.guided_local_search_lambda_coefficient=0.1
    params.time_limit.FromMilliseconds(ms)
    params.lns_time_limit.FromMilliseconds(100)
    params.use_cp=optional_boolean_pb2.BOOL_TRUE
    params.use_cp_sat=optional_boolean_pb2.BOOL_FALSE
    params.use_generalized_cp_sat=optional_boolean_pb2.BOOL_FALSE
    params.fallback_to_cp_sat_size_threshold=0
    params.sat_parameters.num_search_workers=1
    params.sat_parameters.random_seed=SEED
    params.log_search=False
    (P/f'parameters_{ms}ms.textproto').write_text(str(params))
write('input_provenance.json',input_records)
write('checker_self_tests.json',self_test())
write('environment.json',{'ortools':ortools.__version__,'python':sys.version,'executable':sys.executable,
    'platform':platform.platform(),'visible_cpu_count':os.cpu_count(),
    'existing_venv':'/workspace/shared/vrptw_mature_solver_20261007/.venv','no_install':True,
    'packages':sorted([{'name':d.metadata['Name'],'version':d.version} for d in importlib.metadata.distributions()],key=lambda x:x['name'].lower())})
shutil.copyfile('/workspace/shared/vrptw_mature_solver_20261007/requirements.lock',P/'requirements.lock')
write('protocol.json',{'study_id':'OFFICIAL_CVRP_ORTOOLS_REFERENCE_20261008_V1',
 'purpose':'Small mature-solver quality reference at two wall-clock search limits, not an equal-budget ranking with old pure-Python160k evaluations.',
 'inputs':NAMES,'distance':'Exact supplied TSPLIB95 EUC_2D nearest-integer matrix; validated by integer arithmetic.',
 'constraints':'All customers mandatory, identity-preserving even at duplicate coordinates; no disjunctions; capacity; at most five nonempty routes; unused vehicles allowed.',
 'objective':'Total integer depot-to-depot travel; no vehicle fixed costs, penalties or span terms.',
 'solver':'OR-Tools9.14.6206 CP Routing; PARALLEL_CHEAPEST_INSERTION + GUIDED_LOCAL_SEARCH(lambda0.1); CP-SAT and fallback disabled.',
 'limits_ms':[250,1000],'repeats_per_cell':3,'requests':18,'same_seed_all_runs':SEED,
 'replication':'Three independent instances are the statistical units. Repeats characterize wall-clock search variability, not eighteen independent instances or multiple stochastic seeds.',
 'order':'For repeats1..3 rotate instance order left0..2; alternate the two budgets by (position+repeat-1) parity. Exact order in requests.json.',
 'isolation':'Each request launches a separate fresh interpreter; external wait4 captures user+system CPU, maxRSS, exit, and observed spawn-to-reap wall. No shared model or callbacks.',
 'phase_metrics':'Imports, input/parameter loading, model, search, extraction, independent validation; external total also includes interpreter startup, output serialization/fsync, and process exit. Phase RSS is cumulative high-water mark, not incremental.',
 'budget':'Main dynamic execution under60CPU seconds/120wall seconds; run watchdog stops at58 aggregateCPU/118wall, each child6wall/5hardCPU; measured preparation and finalization also reported. No retries.',
 'reference_blindness':'No .sol or reference_solution JSON is opened during prepare or solve. Complete raw outputs are hashed/sealed before references are read solely for gap scoring. No warmstart, objective cutoff, objective stopping or reference-dependent retuning.',
 'failure_policy':'Keep every native status/null/error/timeout. No replacement or compensatory runs. A null assignment or timeout does not prove infeasibility.',
 'analysis':'Report each instance/budget three costs and gaps, medians/ranges, native statuses, independent checks and actual resources. No p-values, broad superiority, or same-budget claims.',
 'source_mutability':'Only new output directory is modified. Existing source and venv are read-only inputs.',
 'network':'No network, API/model call, installation or new purchase.'})
files=['measure.py','prepare.py','worker.py','supervise.py','checker.py','finalize.py','protocol.json','requests.json','environment.json','requirements.lock','input_provenance.json','checker_self_tests.json']+[f'parameters_{ms}ms.textproto' for ms in [250,1000]]+[f'inputs/{name}.json' for name in NAMES]
write('freeze.json',{'frozen_at_utc':datetime.now(timezone.utc).isoformat(),'before_any_solver_call':True,
 'pilot_solves':0,'reference_files_opened':0,'sha256':{name:sha(P/name) for name in files}})
print('Frozen18 requests;0 solves;0 reference files opened.')
