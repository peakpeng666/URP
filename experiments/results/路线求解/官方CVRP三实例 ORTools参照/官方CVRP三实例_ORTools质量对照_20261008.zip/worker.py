"""One invocation, one model, one solve. No references, retries or warm starts."""
import time
BEGIN_WALL=time.perf_counter(); BEGIN_CPU=time.process_time()
import os
os.environ['OMP_NUM_THREADS']='1'
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['MKL_NUM_THREADS']='1'
import sys,json,resource,traceback
from pathlib import Path
from datetime import datetime,timezone
import ortools
from ortools.constraint_solver import pywrapcp,routing_enums_pb2
from google.protobuf import text_format
from checker import check
P=Path(__file__).resolve().parent
phases={}
def mark(name,w,c):
    phases[name]={'wall_s':time.perf_counter()-w,'cpu_s':time.process_time()-c,
                  'cumulative_peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
mark('imports',BEGIN_WALL,BEGIN_CPU)
w=time.perf_counter();c=time.process_time()
req=json.loads(sys.argv[1]); instance=json.loads((P/'inputs'/f"{req['instance']}.json").read_text())
assert ortools.__version__=='9.14.6206'
params=pywrapcp.DefaultRoutingSearchParameters();params.Clear()
text_format.Parse((P/f"parameters_{req['budget_ms']}ms.textproto").read_text(),params)
mark('load_inputs_and_parameters',w,c)
result={**req,'pid':os.getpid(),'ortools_version':ortools.__version__,
        'assignment_returned':False,'routes_node_indices':None,'routes_original_node_ids':None,
        'objective_integer':None,'independent_check':None,'status_code':None,'status_name':None}
try:
    w=time.perf_counter();c=time.process_time()
    manager=pywrapcp.RoutingIndexManager(instance['dimension'],5,0)
    routing=pywrapcp.RoutingModel(manager)
    routing.solver().ReSeed(req['seed'])
    matrix=instance['distance_matrix'];demands=instance['demands']
    def cost(a,b):return matrix[manager.IndexToNode(a)][manager.IndexToNode(b)]
    def demand(a):return demands[manager.IndexToNode(a)]
    cost_id=routing.RegisterTransitCallback(cost)
    demand_id=routing.RegisterUnaryTransitCallback(demand)
    routing.SetArcCostEvaluatorOfAllVehicles(cost_id)
    routing.AddDimensionWithVehicleCapacity(demand_id,0,[instance['capacity']]*5,True,'Capacity')
    mark('model',w,c)
    w=time.perf_counter();c=time.process_time()
    assignment=routing.SolveWithParameters(params)
    mark('search',w,c)
    result['status_code']=routing.status()
    result['status_name']=routing_enums_pb2.RoutingSearchStatus.Value.Name(routing.status())
    result['branches']=routing.solver().Branches()
    result['failures']=routing.solver().Failures()
    result['assignment_returned']=assignment is not None
    w=time.perf_counter();c=time.process_time()
    if assignment is not None:
        routes=[]
        for v in range(5):
            index=routing.Start(v);route=[]
            for _ in range(instance['dimension']+2):
                route.append(manager.IndexToNode(index))
                if routing.IsEnd(index):break
                index=assignment.Value(routing.NextVar(index))
            else:raise RuntimeError('route extraction cycle')
            routes.append(route)
        result['routes_node_indices']=routes
        result['routes_original_node_ids']=[[instance['node_ids_original'][j] for j in r] for r in routes]
        result['objective_integer']=assignment.ObjectiveValue()
    mark('extract',w,c)
    w=time.perf_counter();c=time.process_time()
    if assignment is not None:
        result['independent_check']=check(instance,result['routes_node_indices'],result['objective_integer'])
        result['outcome']='valid_assignment' if result['independent_check']['valid'] else 'checker_rejected'
    else:result['outcome']='no_assignment_in_budget'
    mark('independent_validation',w,c)
except Exception as exc:
    result.update(outcome='error',error=repr(exc),traceback=traceback.format_exc())
result.update(phases=phases,completed_at_utc=datetime.now(timezone.utc).isoformat(),
              internal_before_serialization_wall_s=time.perf_counter()-BEGIN_WALL,
              internal_before_serialization_cpu_s=time.process_time()-BEGIN_CPU,
              internal_peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
out=P/'raw'/f"{req['run_id']}.result.json"
with out.open('x') as f:
    json.dump(result,f,ensure_ascii=False,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps({'run_id':req['run_id'],'outcome':result['outcome'],'status_name':result['status_name']}),flush=True)
