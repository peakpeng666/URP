Official CVRP / OR-Tools quality reference, 2026-10-08

Start with report_zh.txt, summary.json and metrics.csv. Full routes and native
statuses are in raw/*.result.json. Per-run wait4 CPU, observed spawn-to-reap wall,
maxRSS, exit codes and reaping evidence are in raw/*.resource.json.

Frozen design: three verified official CVRP instances, K <= 5, mandatory unique
customer IDs even when coordinates coincide, exact TSPLIB EUC_2D integer costs.
OR-Tools 9.14.6206 CP Routing; PARALLEL_CHEAPEST_INSERTION and GLS(lambda=0.1).
250ms and 1000ms search-wall limits; three predeclared repetitions each; same
seed for all requests. Fresh interpreter for every request. No compensation
or retries. Three instances are the statistical units, not eighteen runs.

Integrity:
  freeze.json hashes all pre-solve source, inputs, configs and request order.
  output_seal.json hashes all completed raw outputs before reference access.
  reference_access.json records later reference-only gap scoring.
  input_provenance.json links exact input bytes to the prior verified package.
  provenance/source_manifest.json retains official URLs, hashes and terms.
  FILE_INVENTORY.json hashes the artifact members (excluding itself/archive).

Portable replay (no install, network or original source-directory required):
  Use an existing Python environment with ortools==9.14.6206 and the locked
  dependencies. Do not modify the reported output directory. Invoke:
    python -B reproduce.py /absolute/path/to/a/new/replay_directory
  reproduce.py verifies frozen inputs, copies the frozen experiment into the
  new directory, executes exactly 18 independent children once, seals outputs,
  and only then loads the bundled reference costs for portable replay scores.
  The replay helper was authored after the reported experiment and has only
  been syntax/readiness checked here; it was NOT executed, to avoid new runs.
  Changing machine load or timing can change a wall-limited solution; exact
  cost reproduction is not guaranteed. No Ubuntu22.04/Python3.10 acceptance
  claim is made. Actual tested environment is in environment.json.

Core historical entry points: prepare.py created original freeze from the
verified local data package; supervise.py ran the request list; finalize.py
scored against that local package. For portable replay use reproduce.py rather
than those original absolute-path preparation/scoring entry points.

Resource boundaries:
  prepare.resource.json, run.resource.json, finalize.resource.json measure
  complete executable process trees. run totals already include worker CPU.
  resource_accounting.json aggregates these without double counting.
  package.resource.json is a measured post-archive sidecar, delivered beside
  the ZIP. A root audit may append its own audit evidence before final upload.

Scope and permissions:
  No new installations, purchases, API/model calls, uploads, public sharing or
  changes to old experiment packages. This is a private research bundle.
  CVRPLIB data terms allow research use; public redistribution rights were not
  established. See provenance/source_manifest.json for the original terms.
  This is quality calibration at two search limits, never an equal-budget
  ranking against old pure-Python160k evaluation-count experiments.
