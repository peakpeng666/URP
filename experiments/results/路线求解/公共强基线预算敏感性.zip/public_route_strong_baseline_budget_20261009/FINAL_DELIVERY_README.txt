先读 reports/FINAL_REPORT_ZH.txt；主表为 reports/PER_INSTANCE.csv，全部96行在 reports/PER_SEED.csv。
独立末审见 independent_review/POSTRUN_INDEPENDENT_AUDIT.json、POSTRUN_REVIEW_ZH.md及FINAL_NARRATIVE_REVIEW.json。
原始证据在raw/，冻结协议/顺序/清单在freeze/，代码在source/。
本轮0.1秒和5秒是主ILS循环停止条件，不是整次调用时间上限；历史1秒只作跨时段背景。
完整恢复依赖本增量包及此前已回读旧r1 final ZIP，精确身份/hash及14个wheel清单见environment/DEPENDENCY_RESTORATION.json与DEPENDENCY_ARCHIVE_RECEIPT.json。
最终归档生成后，其私有上传与真实回读回执在provenance/FINAL_REVIEWED_DRIVE_RECEIPT.json交付侧文件中；不能将包内旧阶段回执当成最终包回执。
