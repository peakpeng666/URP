"""Independent saved-evidence postrun audit. No optimization, package import, or rerun.

Run only after explicit archive-readback and CPU-window release from the parent.
Reconstruct costs from original VRP files with Decimal80, not producer summaries.
"""
import csv
import datetime
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
import statistics
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'independent_review'))
from audit_inputs import expected_schedule, parse_vrp, decimal_matrix
from independent_validator import validate_solution


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(name):
    return json.loads((ROOT / name).read_text())


def records(name):
    return [json.loads(line) for line in (ROOT / name).read_text().splitlines() if line]


def close(a, b):
    return a is None and b is None or a is not None and b is not None and math.isclose(float(a), float(b), rel_tol=1e-12, abs_tol=1e-12)


def check_receipt(stage, freeze_hash):
    receipt = read('provenance/' + stage + '_DRIVE_RECEIPT.json')
    assert receipt['owner_only'] and not receipt['shared']
    assert receipt['remote_readback_sha256_verified'] and receipt['download_byte_identical']
    assert receipt['frozen_files_sha256'] == freeze_hash
    archive = ROOT.parent / (ROOT.name + '_' + stage + '.zip')
    assert digest(archive) == digest(receipt['download_path']) == receipt['sha256'] == receipt['download_sha256']
    assert archive.stat().st_size == Path(receipt['download_path']).stat().st_size
    return {'archive_sha256': receipt['sha256'], 'bytes': archive.stat().st_size, 'owner_only': True, 'actual_recorded_download_byte_identity_rechecked': True}


def run():
    freeze_hash = digest(ROOT / 'freeze/FROZEN_FILES.json')
    frozen = read('freeze/FROZEN_FILES.json')['files']
    for name, meta in frozen.items():
        p = ROOT / name
        assert p.stat().st_size == meta['bytes'] and digest(p) == meta['sha256'], name
    receipts = {stage: check_receipt(stage, freeze_hash) for stage in ('PREEXEC', 'RAW_UNREVIEWED')}
    approval = read('provenance/PARENT_EXECUTION_APPROVAL.json')
    assert approval['approved'] and approval['frozen_files_sha256'] == freeze_hash
    assert approval['preexec_archive_sha256'] == receipts['PREEXEC']['archive_sha256']
    manifest = read('raw/RAW_UNREVIEWED_MANIFEST.json')['files']
    for name, meta in manifest.items():
        p = ROOT / name
        assert p.stat().st_size == meta['bytes'] and digest(p) == meta['sha256'], name
    old_counts = {}
    for filename in ('OLD_FILES_BEFORE.json', 'PRIOR_FAILED_RUN_FILES.json'):
        m = read('freeze/' + filename); old = Path(m['root'])
        assert {str(p.relative_to(old)) for p in old.rglob('*') if p.is_file()} == set(m['files'])
        for name, meta in m['files'].items():
            p = old / name
            assert p.stat().st_size == meta['bytes'] and digest(p) == meta['sha256'], name
        old_counts[filename] = len(m['files'])
    schedule = read('freeze/SCHEDULE.json'); tasks = read('freeze/TASKS.json')
    assert schedule == expected_schedule(tasks)
    saved = records('raw/results.jsonl'); attempts = records('raw/attempts.jsonl')
    assert len(saved) == len(schedule) == 96 and len(attempts) == 192
    assert len({r['call_id'] for r in saved}) == 96
    for index, (entry, row) in enumerate(zip(schedule, saved)):
        assert all(row[k] == value for k, value in entry.items())
        pair = attempts[2*index:2*index+2]
        assert [p['phase'] for p in pair] == ['STARTED', 'FINISHED']
        assert all(all(p[k] == value for k, value in entry.items()) for p in pair)
        assert row['process_spawned'] and row['child_reaped'] and row['returncode'] == 0
        assert row['status'] == 'UNREVIEWED_PROCESS_SUCCESS'
    finished = read('raw/FINISHED.json'); executor = read('raw/EXECUTOR_FINISHED.json')
    assert finished['retained_calls'] == finished['spawned_calls'] == finished['planned_calls'] == 96
    assert finished['status'] == 'COMPLETED_UNREVIEWED'
    assert executor['supervisor_returncode'] == 0 and not executor['external_timeout'] and executor['launcher_error'] is None
    assert executor['process_group_kill_attempt_completed_before_seal']
    matrices = {}; originals = {}; references = {}; history = {}
    for task in tasks:
        name = task['instance_id']
        problem = parse_vrp((ROOT / 'input' / (name + '.vrp')).read_text(), task['K'])
        originals[name] = problem
        matrices[name] = hashlib.sha256(json.dumps(decimal_matrix(problem['coordinates']), separators=(',', ':')).encode()).hexdigest()
        ref = read('references/' + name + '.json')
        checked = validate_solution(problem, [[0, *r, 0] for r in ref['reference_routes']], ref['reference_integer_cost'])
        assert checked['valid'] and checked['reported_cost_matches']
        assert ref['K_ref'] == task['K'] and checked['cost'] > 0
        references[name] = checked['cost']
        h = read(f"history/S{task['selection_slot']:02d}_TSR.stdout")
        checked_h = validate_solution(problem, h['routes'], h['cost'])
        assert checked_h['valid'] and checked_h['reported_cost_matches']
        history[name] = checked_h['cost']
    rows = []; by_task = {}; by_pair = {}; resources = {0.1: [], 5.0: []}
    below = []
    for entry, row in zip(schedule, saved):
        name = entry['instance_id']; budget = entry['max_runtime_seconds']; seed = entry['seed']
        for stream in ('stdout', 'stderr'):
            assert digest(ROOT / row[stream]) == row[stream + '_sha256']
        assert not (ROOT / row['stderr']).read_bytes()
        answer = json.loads((ROOT / row['stdout']).read_text())
        assert answer['seed'] == seed and answer['max_runtime_seconds'] == budget
        assert answer['version'] == '0.14.0' and answer['algorithm'] == 'ILS'
        assert answer['solver_is_feasible'] and answer['solver_is_complete']
        assert answer['denied_io_events'] == answer['reference_or_history_payload_fields'] == []
        assert answer['resource_limits'] == {'inherited': {'AS_bytes': [512*1024**2, 1024*1024**2], 'CPU_seconds': [20,20]}, 'effective': {'AS_bytes': [1024*1024**2]*2, 'CPU_seconds': [5 if budget == .1 else 10]*2}}
        assert answer['reported_fixed_vehicle_cost'] == answer['reported_duration_cost'] == 0
        assert answer['model_matrix_sha256'] == matrices[name]
        input_json = read('input/' + name + '.json')
        payload = {k: input_json[k] for k in ('coordinates', 'demands', 'capacity', 'K')}
        payload.update(seed=seed, max_runtime_seconds=budget)
        assert hashlib.sha256(json.dumps(payload, separators=(',', ':')).encode()).hexdigest() == row['payload_sha256']
        check = validate_solution(originals[name], answer['routes'], answer['reported_cost'])
        assert check['valid'] and check['reported_cost_matches']
        cost = check['cost']; reference = references[name]
        assert answer['reported_distance'] == answer['internal_route_cost'] == cost
        assert answer['reported_num_routes'] == len(answer['native_routes']) == len(answer['routes']) == check['nonempty_routes']
        for native, closed, route_cost, load in zip(answer['native_routes'], answer['routes'], check['route_costs'], check['loads']):
            assert [a['node'] for a in native['activities']] == closed
            assert native['distance'] == route_cost and native['delivery'] == [load]
            assert native['vehicle_type'] == native['start_depot'] == native['end_depot'] == 0
            assert native['num_trips'] == 1 and native['is_feasible']
            for a in native['activities']:
                assert a['location'] == a['node']
                if a['node'] == 0:
                    assert a['type'] == 'DEPOT' and a['idx'] == 0
                else:
                    assert a['type'] == 'CLIENT' and a['idx'] + 1 == a['node']
        assert len(answer['stats']) == len(answer['stats_runtime_per_iteration']) == answer['num_iterations']
        assert 0 <= answer['solve_pre_first_stop_wall_seconds_audit_only'] <= answer['solve_wall_seconds_audit_only']
        assert answer['solver_loop_runtime'] >= budget
        relation = 'BELOW' if cost < reference else 'EQUAL' if cost == reference else 'ABOVE'
        audit_row = {'call_id': entry['call_id'], 'instance_id': name, 'seed': seed, 'budget': budget, 'cost': cost,
                     'reference': reference, 'gap_percent': float(Fraction(100*(cost-reference), reference)), 'relation': relation,
                     'validated': True, 'iterations': answer['num_iterations']}
        rows.append(audit_row)
        if relation == 'BELOW': below.append(audit_row)
        by_task.setdefault((name, budget), []).append(cost)
        by_pair.setdefault((name, seed), {})[budget] = cost
        resources[budget].append({'call_id': entry['call_id'], 'child_cpu': row['cpu_seconds_audit_only'],
            'launch_parse_cleanup_wall': row['wall_seconds_audit_only'], 'full_solve_wall': answer['solve_wall_seconds_audit_only'],
            'full_solve_cpu': answer['solve_cpu_seconds_audit_only'],
            'pre_first_stop_wall': answer['solve_pre_first_stop_wall_seconds_audit_only'], 'worker_maxrss_KiB': answer['worker_maxrss_KiB_audit_only']})
    calculated = {}; per_task = []
    for budget, label in ((.1, 'short'), (5., 'long')):
        task_gaps = []
        for task in tasks:
            name = task['instance_id']; costs = by_task[(name, budget)]; assert len(costs) == 3
            mean = Fraction(sum(costs), 3); gap = 100*(mean-references[name])/references[name]
            task_gaps.append(gap)
            per_task.append({'instance_id': name, 'budget': budget, 'mean3_cost': float(mean), 'gap_percent': float(gap), 'min': min(costs), 'max': max(costs), 'range': max(costs)-min(costs), 'sample_sd': statistics.stdev(costs)})
        chosen = [r for r in rows if r['budget'] == budget]
        gaps = [r['gap_percent'] for r in chosen]
        calculated[label] = {'valid_calls': len(chosen), 'complete_task_count': len(task_gaps),
            'all16_mean_reference_gap_percent': float(sum(task_gaps) / 16),
            'reference_equal': sum(r['relation'] == 'EQUAL' for r in chosen),
            'reference_below': sum(r['relation'] == 'BELOW' for r in chosen),
            'reference_above': sum(r['relation'] == 'ABOVE' for r in chosen),
            'seed_gap_distribution_descriptive': {'count': len(gaps), 'minimum': min(gaps), 'q1_inclusive': statistics.quantiles(gaps,n=4,method='inclusive')[0], 'median': statistics.median(gaps), 'q3_inclusive': statistics.quantiles(gaps,n=4,method='inclusive')[2], 'maximum': max(gaps), 'sample_sd': statistics.stdev(gaps)}}
    delta = sum(100*(Fraction(sum(by_task[(t['instance_id'],.1)]),3)-Fraction(sum(by_task[(t['instance_id'],5.)]),3))/references[t['instance_id']] for t in tasks) / 16
    calculated['all16_short_minus_long_gap_pp'] = float(delta)
    calculated['pairs'] = {'long_lower_cost': sum(p[5.] < p[.1] for p in by_pair.values()), 'equal_cost': sum(p[5.] == p[.1] for p in by_pair.values()), 'long_higher_cost': sum(p[5.] > p[.1] for p in by_pair.values()), 'unavailable_pair': 0}
    summary = read('reports/SUMMARY.json')
    assert summary['planned_calls'] == summary['observed_calls'] == summary['valid_calls'] == 96
    assert summary['complete_two_budget_task_count'] == 16
    for label in ('short', 'long'):
        for key, value in calculated[label].items():
            if isinstance(value, dict):
                assert all(close(value[k], summary[label][key][k]) for k in value)
            else:
                assert close(value, summary[label][key]), (label, key, value, summary[label][key])
        assert summary[label]['unavailable_calls'] == 0
    assert close(delta, summary['all16_short_minus_long_gap_pp'])
    assert summary['current_stage_same_instance_seed_descriptive_pairs'] == calculated['pairs']
    assert bool(below) == summary['final_claims_blocked_until_below_review']
    assert summary['historical_one_second']['reference_equal_count'] == 34
    with (ROOT / 'reports/PER_SEED.csv').open() as f: csv_seeds = list(csv.DictReader(f))
    assert len(csv_seeds) == 96
    csv_ids = {r['call_id']: r for r in csv_seeds}
    for r in rows:
        c = csv_ids[r['call_id']]
        assert int(c['cost']) == r['cost'] and c['status'] == 'VALID' and c['reference_relation'] == r['relation']
        assert close(c['reference_gap_percent'], r['gap_percent'])
    with (ROOT / 'reports/PER_INSTANCE.csv').open() as f: csv_tasks = {r['instance_id']: r for r in csv.DictReader(f)}
    assert len(csv_tasks) == 16
    for r in per_task:
        label = 'short' if r['budget'] == .1 else 'long'; c = csv_tasks[r['instance_id']]
        assert close(c[label + '_mean3_cost'], r['mean3_cost'])
        assert close(c[label + '_mean3_reference_gap_percent'], r['gap_percent'])
        assert int(c[label + '_valid_seeds']) == 3
        for suffix, field in (('_min3_cost_secondary','min'),('_max3_cost_secondary','max'),('_range3_cost_secondary','range'),('_sample_SD3_cost_secondary','sample_sd')):
            assert close(c[label + suffix], r[field])
    resource_summary = {}
    for budget, values in resources.items():
        resource_summary[str(budget)] = {key: {'sum': sum(v[key] for v in values), 'min': min(v[key] for v in values), 'max': max(v[key] for v in values), 'mean': statistics.mean(v[key] for v in values)} for key in values[0] if key != 'call_id'}
    return {'status': 'PASS' if not below else 'PASS_NUMERICS_BELOW_REFERENCE_REVIEW_REQUIRED', 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'public_optimizer_calls_by_reviewer': 0, 'synthetic_optimizer_calls_by_reviewer': 0,
        'frozen_files_sha256': freeze_hash, 'frozen_files_verified': len(frozen), 'raw_manifest_files_verified': len(manifest),
        'private_archive_receipts_rechecked': receipts, 'old_file_counts_verified_unchanged': old_counts,
        'unique_scheduled_processes': 96, 'ordered_attempt_log_events': 192, 'independent_valid_calls': len(rows),
        'model_distance_matrices_recomputed_from_original_VRP': 16, 'calculated': calculated,
        'below_reference_calls': below, 'summary_and_per_seed_and_per_instance_csv_agree': True,
        'resource_summary_audit_only': resource_summary, 'supervisor': finished, 'executor': executor,
        'rows': rows, 'per_task': per_task,
        'report_hashes': {str(p.relative_to(ROOT)): digest(p) for p in sorted((ROOT/'reports').iterdir()) if p.is_file()},
        'limitations': ['Descriptive panel only; no optimality, statistical significance, SOTA or equal-compute claims.', 'Historical1s is cross-period context; only0.1/5 are new same-stage conditions.', 'MaxRuntime excludes initialization and is not end-to-end duration.', 'Independent time-stopped runs need not produce nested trajectories or monotone realized costs.']}


if __name__ == '__main__':
    print(json.dumps(run(), ensure_ascii=False, indent=2, allow_nan=False))
