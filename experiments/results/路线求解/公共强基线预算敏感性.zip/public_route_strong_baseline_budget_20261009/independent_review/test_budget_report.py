"""Independent invented-data tests of the real report path. No optimizer imports/calls.

External readback gates are mocked ONLY in temporary fixture roots. The real
experiment root and its raw/results are never written by these tests.
"""
import contextlib
import copy
import hashlib
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'source'))
import report
from audit_inputs import expected_schedule


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def fixture_report(omitted=(), failed=(), malformed=()):
    tasks = [{'instance_id': f'INVENTED_{i}', 'selection_slot': i, 'K': 1} for i in range(1, 17)]
    schedule = expected_schedule(tasks)
    with tempfile.TemporaryDirectory(prefix='independent_budget_report_') as temporary:
        root = Path(temporary)
        (root / 'raw/calls').mkdir(parents=True)
        (root / 'reports').mkdir()
        observed = []
        for entry in schedule:
            key = (entry['selection_slot'], entry['seed'], entry['max_runtime_seconds'])
            if key in omitted:
                continue
            short = entry['max_runtime_seconds'] == 0.1
            high = short and entry['seed'] != 0
            route = [0, 2, 1, 3, 0] if high else [0, 1, 2, 3, 0]
            cost = 48 if high else 40
            activities = [{'node': n, 'location': n, 'type': 'DEPOT' if n == 0 else 'CLIENT', 'idx': 0 if n == 0 else n - 1} for n in route]
            answer = {
                'routes': [route], 'reported_cost': cost,
                'solver_is_feasible': True, 'solver_is_complete': True,
                'reported_fixed_vehicle_cost': 0, 'reported_duration_cost': 0,
                'reported_distance': cost, 'resource_limits': {
                    'inherited': {'AS_bytes': [512 * 1024 ** 2, 1024 * 1024 ** 2], 'CPU_seconds': [20, 20]},
                    'effective': {'AS_bytes': [1024 * 1024 ** 2] * 2, 'CPU_seconds': [5 if short else 10] * 2}},
                'model_matrix_sha256': 'INVENTED_MATRIX', 'denied_io_events': [],
                'reference_or_history_payload_fields': [], 'seed': entry['seed'],
                'max_runtime_seconds': entry['max_runtime_seconds'], 'version': '0.14.0',
                'native_routes': [{'activities': activities, 'vehicle_type': 0, 'num_trips': 1}],
            }
            out = root / 'raw/calls' / (entry['call_id'] + '.stdout')
            err = out.with_suffix('.stderr')
            out.write_text('malformed' if key in malformed else json.dumps(answer))
            err.write_text('injected failure' if key in failed else '')
            observed.append({**entry, 'status': 'PROCESS_FAILURE_OR_CPU_LIMIT' if key in failed else 'UNREVIEWED_PROCESS_SUCCESS',
                'stdout': str(out.relative_to(root)), 'stderr': str(err.relative_to(root)),
                'stdout_sha256': sha(out), 'stderr_sha256': sha(err)})
        (root / 'raw/results.jsonl').write_text(''.join(json.dumps(r) + '\n' for r in observed))
        problem = {'coordinates': [[0, 0], [0, 10], [10, 10], [10, 0]], 'demands': [0, 1, 1, 1], 'capacity': 3, 'K': 1}
        objects = {
            'raw/RAW_UNREVIEWED_MANIFEST.json': {'files': {}},
            'freeze/SCHEDULE.json': schedule, 'freeze/TASKS.json': tasks,
            'independent_review/INPUT_MATRIX_AUDIT.json': {'rows': [{'instance_id': t['instance_id'], 'matrix_sha256': 'INVENTED_MATRIX'} for t in tasks]},
            'history/R1_SUMMARY.json': {}, 'freeze/PROTOCOL.json': {'limitations': ['INVENTED TEST'], 'budget': {}},
            'raw/EXECUTOR_FINISHED.json': {'fixture_only': True},
        }
        for t in tasks:
            objects[f"input/{t['instance_id']}.json"] = {**problem, 'instance_id': t['instance_id']}
            objects[f"references/{t['instance_id']}.json"] = {'reference_routes': [[1, 2, 3]], 'reference_integer_cost': 40, 'K_ref': 1}
            objects[f"history/S{t['selection_slot']:02d}_TSR.stdout"] = {'routes': [[0, 1, 2, 3, 0]], 'cost': 40}
        with patch.object(report, 'ROOT', root), patch.object(report, 'read', side_effect=lambda name: copy.deepcopy(objects[name])), \
             patch.object(report, 'verify_frozen'), patch.object(report, 'receipt'), \
             patch.object(report, 'verify_old', return_value=0), patch.object(report, 'verify_prior_failed', return_value=0), \
             contextlib.redirect_stdout(io.StringIO()):
            report.main()
        summary = json.loads((root / 'reports/SUMMARY.json').read_text())
        audit = json.loads((root / 'reports/SAVED_ROUTE_VALIDATION.json').read_text())
        return summary, audit


class BudgetReportTests(unittest.TestCase):
    def test_complete_full_report(self):
        s, a = fixture_report()
        self.assertEqual(s['valid_calls'], 96)
        self.assertEqual(len(a['calls']), 96)
        self.assertEqual(s['short']['complete_task_count'], 16)
        self.assertAlmostEqual(s['short']['all16_mean_reference_gap_percent'], 100 * (16 / 3) / 40)
        self.assertEqual(s['long']['all16_mean_reference_gap_percent'], 0)
        self.assertAlmostEqual(s['all16_short_minus_long_gap_pp'], 100 * (16 / 3) / 40)
        self.assertEqual(s['short']['reference_equal'], 16)
        self.assertEqual(s['short']['reference_above'], 32)
        self.assertEqual(s['long']['reference_equal'], 48)
        self.assertEqual(s['current_stage_same_instance_seed_descriptive_pairs'], {'long_lower_cost': 32, 'equal_cost': 16, 'long_higher_cost': 0, 'unavailable_pair': 0})

    def test_one_missing_short_seed_leaves_long_primary(self):
        s, a = fixture_report(omitted={(1, 0, 0.1)})
        self.assertEqual(s['observed_calls'], 95)
        self.assertEqual(len(a['calls']), 96)
        self.assertEqual(s['short']['complete_task_count'], 15)
        self.assertIsNone(s['short']['all16_mean_reference_gap_percent'])
        self.assertIsNone(s['all16_short_minus_long_gap_pp'])
        self.assertEqual(s['long']['complete_task_count'], 16)
        self.assertEqual(s['long']['all16_mean_reference_gap_percent'], 0)
        self.assertEqual(s['complete_two_budget_task_count'], 15)
        self.assertEqual(s['current_stage_same_instance_seed_descriptive_pairs']['unavailable_pair'], 1)

    def test_failed_seed_retained_and_not_averaged_as_two(self):
        s, a = fixture_report(failed={(2, 1, 5.0)})
        self.assertEqual(s['observed_calls'], 96)
        self.assertEqual(s['valid_calls'], 95)
        self.assertIsNone(s['long']['all16_mean_reference_gap_percent'])
        self.assertEqual(s['long']['complete_task_count'], 15)
        self.assertIsNotNone(s['short']['all16_mean_reference_gap_percent'])
        self.assertIsNone(s['all16_short_minus_long_gap_pp'])
        failures = [r for r in a['calls'] if not r['valid']]
        self.assertEqual(len(failures), 1)
        self.assertIn('PROCESS_FAILURE_OR_CPU_LIMIT', failures[0]['errors'])

    def test_malformed_success_output_retained_invalid(self):
        s, a = fixture_report(malformed={(3, 2, 0.1)})
        self.assertEqual(s['valid_calls'], 95)
        self.assertIsNone(s['short']['all16_mean_reference_gap_percent'])
        self.assertTrue(any(any(e.startswith('PARSE_VALIDATION_EXCEPTION') for e in r['errors']) for r in a['calls']))

    def test_all_missing_never_started_rows_retained(self):
        omitted = {(i, seed, budget) for i in range(1, 17) for seed in range(3) for budget in (0.1, 5.0)}
        s, a = fixture_report(omitted=omitted)
        self.assertEqual(s['observed_calls'], 0)
        self.assertEqual(len(a['calls']), 96)
        for label in ('short', 'long'):
            self.assertEqual(s[label]['valid_calls'], 0)
            self.assertEqual(s[label]['unavailable_calls'], 48)
            self.assertIsNone(s[label]['all16_mean_reference_gap_percent'])
            self.assertIsNone(s[label]['available_complete_task_mean_gap_percent_descriptive'])
            self.assertIsNone(s[label]['seed_gap_distribution_descriptive']['minimum'])
        self.assertEqual(s['current_stage_same_instance_seed_descriptive_pairs']['unavailable_pair'], 48)

    def test_equal_instance_weighting_and_reference_relations(self):
        seeds = []
        tasks = []
        for i in range(16):
            # Deliberately unequal per-instance gap, not a cost-pooled percentage.
            gap = i * 2 - 10
            tasks.append({'short_mean3_reference_gap_percent': gap,
                'long_mean3_reference_gap_percent': 0,
                'short_minus_long_mean3_gap_pp': gap})
            for seed in range(3):
                for budget in (0.1, 5.0):
                    cost = 100 + gap if budget == 0.1 else 100
                    relation = 'BELOW' if cost < 100 else 'EQUAL' if cost == 100 else 'ABOVE'
                    seeds.append({'instance_id': str(i), 'seed': seed, 'max_runtime_seconds': budget, 'status': 'VALID', 'cost': cost, 'reference_gap_percent': cost - 100, 'reference_relation': relation})
        s = report.aggregate(seeds, tasks)
        self.assertEqual(s['short']['all16_mean_reference_gap_percent'], 5)
        self.assertEqual(s['all16_short_minus_long_gap_pp'], 5)
        self.assertEqual(s['short']['reference_below'], 15)
        self.assertEqual(s['short']['reference_equal'], 3)
        self.assertEqual(s['short']['reference_above'], 30)
        self.assertEqual(s['current_stage_same_instance_seed_descriptive_pairs']['long_higher_cost'], 15)
        self.assertEqual(s['current_stage_same_instance_seed_descriptive_pairs']['long_lower_cost'], 30)


if __name__ == '__main__':
    unittest.main(verbosity=2)
