"""Read-only archive, chronology and resource-export consistency supplement."""
from pathlib import Path
import datetime
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parents[1]
read=lambda n:json.loads((ROOT/n).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
timestamp=lambda x:datetime.datetime.fromisoformat(x.replace('Z','+00:00'))
pre=read('provenance/PREEXEC_DRIVE_RECEIPT.json');raw=read('provenance/RAW_UNREVIEWED_DRIVE_RECEIPT.json')
approval=read('provenance/PARENT_EXECUTION_APPROVAL.json');started=read('raw/STARTED.json');finished=read('raw/FINISHED.json');summary=read('reports/SUMMARY.json')
assert timestamp(pre['confirmed_at_utc'])<timestamp(approval['utc'])<timestamp(started['utc'])<timestamp(finished['utc'])<timestamp(raw['confirmed_at_utc'])<timestamp(summary['utc'])
assert started['approval_sha256']==sha(ROOT/'provenance/PARENT_EXECUTION_APPROVAL.json')
assert started['preexec_receipt_sha256']==sha(ROOT/'provenance/PREEXEC_DRIVE_RECEIPT.json')
assert approval['independent_precheck_sha256']==sha(ROOT/'freeze/INDEPENDENT_PRECHECK.json')
assert approval['scope']=='one frozen 96-call PyVRP two-budget benchmark; no retry'
counts={}
for stage,manifest in [('PREEXEC',read('freeze/FROZEN_FILES.json')['files']),('RAW_UNREVIEWED',read('raw/RAW_UNREVIEWED_MANIFEST.json')['files'])]:
 with zipfile.ZipFile(ROOT.parent/(ROOT.name+'_'+stage+'.zip')) as z:
  for rel,meta in manifest.items():
   data=z.read(ROOT.name+'/'+rel);assert len(data)==meta['bytes'] and hashlib.sha256(data).hexdigest()==meta['sha256'],rel
  counts[stage]=len(manifest)
usage=read('reports/RESOURCE_USAGE_AUDIT.json');by_id={r['call_id']:r for r in usage['rows']}
assert len(by_id)==96
mapping={'solve_wall_audit_only':'solve_wall_seconds_audit_only','solve_cpu_audit_only':'solve_cpu_seconds_audit_only','solve_pre_first_stop_wall_audit_only':'solve_pre_first_stop_wall_seconds_audit_only','build_wall_audit_only':'build_wall_seconds_audit_only','worker_maxrss_KiB_audit_only':'worker_maxrss_KiB_audit_only','iterations':'num_iterations','search_runtime_audit_only':'solver_loop_runtime'}
for row in [json.loads(s) for s in (ROOT/'raw/results.jsonl').read_text().splitlines()]:
 out=read(row['stdout']);export=by_id[row['call_id']]
 assert export['status']=='VALID' and export['max_runtime_seconds']==row['max_runtime_seconds']
 assert export['process_wall_audit_only']==row['wall_seconds_audit_only'] and export['process_cpu_audit_only']==row['cpu_seconds_audit_only']
 for dest,source in mapping.items():assert export[dest]==out[source],(row['call_id'],dest)
assert usage['supervisor']==finished and usage['executor']==read('raw/EXECUTOR_FINISHED.json')
result={'status':'PASS','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'optimizer_calls':0,'signed_gate_chronology_verified':['PREEXEC_readback','hash_bound_approval','formal_START','formal_FINISH','RAW_readback','endpoint_scoring'],'actual_archive_members_byte_hash_verified':counts,'resource_export_rows_crosschecked_to_original_raw':96,'resource_field_mapping':mapping,'process_wall_scope':'launch through parent parse/validation and cleanup, not solely child lifetime','all_gate_hash_links_verified':True}
print(json.dumps(result,ensure_ascii=False,indent=2))
