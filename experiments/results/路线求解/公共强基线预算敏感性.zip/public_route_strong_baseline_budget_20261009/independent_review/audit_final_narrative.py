"""Sign final narrative only after reading final texts and checking numeric support."""
from pathlib import Path
import datetime
from fractions import Fraction
import hashlib
import json
import math
import statistics

ROOT=Path(__file__).resolve().parents[1]
read=lambda n:json.loads((ROOT/n).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
audit=read('independent_review/POSTRUN_INDEPENDENT_AUDIT.json')
assert audit['status']=='PASS'
report=(ROOT/'reports/FINAL_REPORT_ZH.txt').read_text();readme=(ROOT/'FINAL_DELIVERY_README.txt').read_text()
usage=read('reports/RESOURCE_USAGE_AUDIT.json');rollup=read('reports/RESOURCE_SUMMARY.json')
for budget in (0.1,5.0):
 rows=[r for r in usage['rows'] if r['max_runtime_seconds']==budget]
 for field,values in rollup['groups'][str(budget)].items():
  v=[r[field] for r in rows]
  expected={'n':len(v),'min':min(v),'mean':statistics.mean(v),'median':statistics.median(v),'max':max(v)}
  if field!='worker_maxrss_KiB_audit_only':expected['sum']=sum(v)
  assert values==expected,(budget,field)
 group=rollup['groups'][str(budget)]
 for field in ('solve_pre_first_stop_wall_audit_only','solve_wall_audit_only','process_wall_audit_only'):
  for metric in ('min','mean','max'):assert format(group[field][metric],'.9f') in report,(budget,field,metric)
 assert format(group['process_cpu_audit_only']['mean'],'.9f') in report
 assert format(group['process_cpu_audit_only']['sum'],'.6f') in report
 assert 'sum' not in group['worker_maxrss_KiB_audit_only']
by_task={}
for r in audit['rows']:by_task.setdefault(r['instance_id'],{}).setdefault(r['budget'],[]).append(r['cost'])
count={'long_mean_lower':0,'equal':0,'long_mean_higher':0}
for task,p in by_task.items():
 a,b=sum(p[.1]),sum(p[5.]);count['long_mean_lower' if b<a else 'equal' if a==b else 'long_mean_higher']+=1
assert count=={'long_mean_lower':11,'equal':5,'long_mean_higher':0}
assert '11题更低、5题相同' in report
historical_gaps=[]
for t in read('freeze/TASKS.json'):
 ref=read('references/'+t['instance_id']+'.json')['reference_integer_cost']
 cost=read(f"history/S{t['selection_slot']:02d}_TSR.stdout")['cost']
 historical_gaps.append(Fraction(100*(cost-ref),ref))
history_gap=sum(historical_gaps)/16
assert format(float(history_gap),'.9f') in report
for label in ('short','long'):
 group=audit['calculated'][label]
 assert format(group['all16_mean_reference_gap_percent'],'.9f') in report
 for metric in ('median','q1_inclusive','q3_inclusive','maximum','sample_sd'):
  v=group['seed_gap_distribution_descriptive'][metric]
  assert v==0 or format(v,'.9f') in report,(label,metric)
assert format(audit['calculated']['all16_short_minus_long_gap_pp'],'.9f') in report
assert format(sum(r['process_cpu_audit_only'] for r in usage['rows']),'.6f') in report
for key in ('supervisor_cpu_seconds','supervisor_wall_seconds'):assert format(rollup[key],'.9f') in report
for token in ['740','244.8','1536','2048','96','192','148','200','70176','70440']:
 assert token in report
for token in ['跨时段','不调ILS参数','0.1秒档不表示0.1秒内返回完整解','不是本研究证明的最优值','不宣称统计显著性','SOTA','不保证严格轨迹嵌套','Python层面','共同组成完整恢复集合']:
 assert token in report,token
assert '记录时点' in report and '后续' in report and 'JSON' in report
for stage in ('PREEXEC','RAW_UNREVIEWED'):
 assert read('provenance/'+stage+'_DRIVE_RECEIPT.json')['sha256'] in report
assert sha(ROOT/'freeze/FROZEN_FILES.json') in report
assert '50f01f3c345e12add88bdcfa76189e2f8ef83fde4fd5675d60c41bbf8275d067' in report
assert '45735218' in report
assert '不能将包内旧阶段回执当成最终包回执' in readme
files=['reports/FINAL_REPORT_ZH.txt','FINAL_DELIVERY_README.txt','reports/RESOURCE_SUMMARY.json']
support=['reports/SUMMARY.json','reports/PER_INSTANCE.csv','reports/PER_SEED.csv','reports/RESOURCE_USAGE_AUDIT.json','independent_review/POSTRUN_INDEPENDENT_AUDIT.json','independent_review/POSTRUN_SUPPLEMENT_AUDIT.json','independent_review/HISTORICAL_CONTEXT_AUDIT.json','independent_review/POSTRUN_REVIEW_ZH.md']
result={'status':'PASS','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'optimizer_calls':0,'scope':'Final report and delivery README reviewed against independently recomputed saved solutions, archived gate evidence, and resource records; final cloud archive verification remains a delivery step.','per_task_integer_sum_comparison':count,'historical_TSR_equal_instance_gap_percent':float(history_gap),'every_resource_rollup_field_recomputed':True,'rounded_narrative_numbers_matched':True,'time_memory_and_history_limitations_verified':True,'dependency_restoration_collection_scope_verified':True,'final_archive_success_not_claimed_in_advance':True,'signed_files':{p:{'bytes':(ROOT/p).stat().st_size,'sha256':sha(ROOT/p)} for p in files},'supporting_files':{p:{'bytes':(ROOT/p).stat().st_size,'sha256':sha(ROOT/p)} for p in support},'resolved_final_wording':['ru_maxrss clarified as high-water up to sampling time; later output/cleanup peak not established.'],'unresolved_blockers':[]}
print(json.dumps(result,indent=2,ensure_ascii=False))
