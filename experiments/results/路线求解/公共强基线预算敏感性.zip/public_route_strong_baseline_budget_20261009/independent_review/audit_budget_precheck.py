"""Independent pre-execution evidence audit; never invokes any optimizer."""
import ast
import contextlib
import datetime
import hashlib
import io
import json
from pathlib import Path
import sys
import tempfile
from unittest.mock import patch
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OLD = ROOT.parent / 'public_route_strong_baseline_20261009_r1'
sys.path[:0] = [str(ROOT / 'source'), str(ROOT / 'independent_review')]
from independent_validator import validate_solution
from audit_inputs import audit


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(rel):
    return json.loads((ROOT / rel).read_text())


def run():
    evidence = {'status': 'PASS', 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                'reviewer_executed_public_optimizer_calls': 0, 'reviewer_executed_synthetic_optimizer_calls': 0}
    input_audit = audit(ROOT, OLD)
    assert input_audit['valid']
    evidence['inputs_and_schedule'] = {k: v for k, v in input_audit.items() if k != 'rows'}
    old_ast, new_ast = [ast.parse((p / 'source/worker.py').read_text()) for p in (OLD, ROOT)]
    trees = [{n.name: n for n in tree.body if isinstance(n, ast.FunctionDef)} for tree in (old_ast, new_ast)]
    for name in ('build_model', 'extract_routes'):
        assert ast.dump(trees[0][name]) == ast.dump(trees[1][name])
    old_solve, new_solve = [next(n for n in ast.walk(t['run']) if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == 'solve') for t in trees]
    for field in ('seed', 'collect_stats', 'display', 'params', 'initial_solution'):
        values = [next(kw.value for kw in call.keywords if kw.arg == field) for call in (old_solve, new_solve)]
        assert ast.dump(values[0]) == ast.dump(values[1])
    assert 'stop._start_runtime' in (ROOT / 'source/worker.py').read_text()
    evidence['scientific_model_AST_identical'] = ['build_model', 'extract_routes']
    evidence['unchanged_solve_keywords_AST_verified'] = ['seed', 'collect_stats', 'display', 'params', 'initial_solution']
    continuity = read('selftests/INTEGRATION_SOURCE_CONTINUITY.json')
    for name, digest in continuity['source_hashes'].items():
        assert sha(ROOT / 'source' / name) == digest
    problem = {'coordinates': [[0, 0], [10, 0], [11, 0], [12, 0]], 'demands': [0, 1, 1, 1], 'capacity': 3, 'K': 3}
    fixtures = [problem,
        {'coordinates': [[0,0],[1,0],[2,0],[0,2]], 'demands': [0,2,2,2], 'capacity': 4, 'K': 2},
        {'coordinates': [[0,0],[0.5,0],[2,2],[3,1]], 'demands': [0,1,1,1], 'capacity': 3, 'K': 2},
        {'coordinates': [[0,0],[1,1],[1,1],[4,0]], 'demands': [0,1,1,2], 'capacity': 3, 'K': 2}]
    audited = []
    success_count = 0
    for filename in ('SUPERVISOR_INTEGRATION.json', 'FULL_BUDGET_SUPERVISOR_INTEGRATION.json'):
        record = read('selftests/' + filename)
        assert record['status'] == 'PASS' and record['public_optimizer_calls'] == 0
        for name, digest in record['source_sha256'].items():
            assert sha(ROOT / 'source' / name) == digest
        for item in record['records']:
            row = item['record']
            for stream in ('stdout', 'stderr'):
                assert sha(ROOT / row[stream]) == row[stream + '_sha256']
            assert row['child_reaped']
            budget = row['max_runtime_seconds']
            if row['status'] == 'UNREVIEWED_PROCESS_SUCCESS':
                answer = json.loads((ROOT / row['stdout']).read_text())
                assert answer['resource_limits'] == {'inherited': {'AS_bytes': [512*1024**2,1024*1024**2], 'CPU_seconds': [20,20]}, 'effective': {'AS_bytes': [1024*1024**2]*2, 'CPU_seconds': [5 if budget == .1 else 10]*2}}
                assert answer['seed'] == row['seed'] and answer['max_runtime_seconds'] == budget
                assert answer['version'] == '0.14.0'
                assert not answer['denied_io_events'] and not answer['reference_or_history_payload_fields']
                assert 0 <= answer['solve_pre_first_stop_wall_seconds_audit_only'] <= answer['solve_wall_seconds_audit_only']
                assert answer['solver_loop_runtime'] >= budget
                assert len(answer['stats']) == len(answer['stats_runtime_per_iteration']) == answer['num_iterations']
                current = fixtures[int(row['call_id'].split('_')[1])] if row['call_id'].startswith('FIXTURE_') else problem
                validation = validate_solution(current, answer['routes'], answer['reported_cost'])
                assert validation['valid'] and validation['reported_cost_matches']
                success_count += 1
                audited.append({'call_id': row['call_id'], 'budget': budget, 'seed': row['seed'],
                    'validated_cost': validation['cost'], 'stats_count': answer['num_iterations'],
                    'pre_first_stop_wall': answer['solve_pre_first_stop_wall_seconds_audit_only'],
                    'full_solve_wall': answer['solve_wall_seconds_audit_only'],
                    'process_plus_supervisor_overhead_wall': row['wall_seconds_audit_only'],
                    'child_cpu': row['cpu_seconds_audit_only'], 'verified': True})
            elif row['call_id'] == 'FAULT_wall_timeout':
                assert row['status'] == 'WALL_TIMEOUT' and row['wall_seconds_audit_only'] >= 10 and row['returncode'] < 0
            elif row['call_id'] == 'FAULT_cpu_limit':
                assert row['status'] == 'PROCESS_FAILURE_OR_CPU_LIMIT' and row['cpu_seconds_audit_only'] >= 4.5 and row['returncode'] < 0
            elif item.get('kind') == 'duplicate_test_path_rejected_before_spawn':
                assert not row['process_spawned'] and row['status'] == 'CALL_ERROR_UNDETERMINED'
            else:
                assert row['call_id'] == 'FAULT_malformed_payload' and row['returncode'] == 1
    assert success_count == 10
    full = [r for r in audited if r['call_id'].startswith('FULL_')]
    assert {(r['budget'], r['seed']) for r in full} == {(b,s) for b in (.1, 5.) for s in (0,1,2)}
    evidence['saved_synthetic_results_independently_revalidated'] = audited
    evidence['actual_limited_supervisor_source_continuity_verified'] = True
    evidence['saved_failure_faults_and_no_duplicate_spawn_verified'] = True
    matrix = read('selftests/ACTUAL_MODEL_MATRIX_AUDIT.json')
    expected = {r['instance_id']: r for r in input_audit['rows']}
    assert matrix['public_optimizer_calls'] == 0 and matrix['tasks_built_without_optimization'] == 16
    for row in matrix['rows']:
        assert row['model_matrix_sha256'] == row['independent_expected_sha256'] == expected[row['instance_id']]['matrix_sha256']
        assert row['directed_cells'] == expected[row['instance_id']]['directed_cells']
    evidence['saved_actual_model_matrices_independently_matched'] = 16
    # Fresh cleanup and fake-API tests, redirected to temporary directories, not
    # merely trusting the producer's saved PASS. No PyVRP is imported by these.
    import test_process_cleanup
    import test_adapter_offline
    fresh = {}
    with tempfile.TemporaryDirectory(prefix='independent_budget_safety_') as temporary:
        tmp = Path(temporary); (tmp / 'selftests').mkdir()
        with patch.object(test_process_cleanup, 'ROOT', tmp), contextlib.redirect_stdout(io.StringIO()):
            test_process_cleanup.main()
        with patch.object(test_adapter_offline, 'ROOT', tmp), contextlib.redirect_stdout(io.StringIO()):
            test_adapter_offline.main()
        for name in ('PROCESS_CLEANUP', 'ADAPTER_OFFLINE'):
            value = json.loads((tmp / 'selftests' / (name + '.json')).read_text())
            assert value['status'] == 'PASS'; fresh[name] = value
    evidence['independently_reexecuted_nonoptimizer_safety_fixtures'] = fresh
    for manifest_name in ('OLD_FILES_BEFORE.json', 'PRIOR_FAILED_RUN_FILES.json'):
        manifest = read('freeze/' + manifest_name); root = Path(manifest['root'])
        assert {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()} == set(manifest['files'])
        for name, meta in manifest['files'].items():
            p = root/name; assert p.stat().st_size == meta['bytes'] and sha(p) == meta['sha256']
        evidence[manifest_name + '_unchanged_files'] = len(manifest['files'])
    runtime = read('environment/RUNTIME.json')
    assert sha(Path(runtime['python_executable']).resolve()) == runtime['python_binary_sha256']
    for row in runtime['installed_distribution_files']:
        p = Path(row['path']); assert p.stat().st_size == row['bytes'] and sha(p) == row['sha256']
    evidence['installed_distribution_files_verified'] = len(runtime['installed_distribution_files'])
    receipt = read('environment/DEPENDENCY_ARCHIVE_RECEIPT.json')
    archive = Path(receipt['source']); download = Path(receipt['download_path'])
    assert archive.stat().st_size == download.stat().st_size == 45735218
    assert sha(archive) == sha(download) == '50f01f3c345e12add88bdcfa76189e2f8ef83fde4fd5675d60c41bbf8275d067'
    assert receipt['byte_exact_transport_part_readback_verified'] and not receipt['direct_complete_file_download_verified']
    wheels = read('environment/WHEELS.json')['wheels']
    with zipfile.ZipFile(archive) as z:
        for row in wheels:
            p = OLD / 'environment/wheels' / row['file']
            assert p.stat().st_size == row['bytes'] and sha(p) == row['sha256']
            body = z.read(OLD.name + '/environment/wheels/' + row['file'])
            assert len(body) == row['bytes'] and hashlib.sha256(body).hexdigest() == row['sha256']
    evidence['dependency_archive_and_actual_local_readback_verified'] = {'bytes': 45735218, 'sha256': sha(archive), 'wheels_verified_in_archive_and_on_disk': len(wheels), 'scope': 'Existing verified part-transport readback; no new direct Drive download performed by reviewer.'}
    assert not list((ROOT / 'raw').rglob('*'))
    evidence['new_public_raw_empty_before_execution'] = True
    evidence['current_scientific_source_hashes'] = {str(p.relative_to(ROOT)): sha(p) for folder in ('source', 'freeze', 'environment') for p in sorted((ROOT/folder).rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
    return evidence


if __name__ == '__main__':
    result = run()
    print(json.dumps(result, indent=2, ensure_ascii=False))
