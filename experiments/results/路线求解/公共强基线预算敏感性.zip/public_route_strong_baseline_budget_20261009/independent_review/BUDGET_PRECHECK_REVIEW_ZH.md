# 两档 PyVRP 预算敏感性实验独立预审

结论：PASS，可进入冻结与 PREEXEC 私有归档。此结论本身不代替后续逐字节回读及绑定冻结哈希的单轮执行许可。审核未运行任何公共实例优化，也未新增虚构实例优化调用。

## 设计与算法

- 独立从原 16 题 selection_slot、seed 0/1/2 重建了全部 96 条调用的 9 个字段，逐条等于计划；48 对相邻独立进程，24 对短先、24 对长先。没有新增 1 秒调用。
- 每次是新 MaxRuntime 对象，默认 PyVRP 0.14.0 ILS、SolveParams、collect_stats=True、display=False、initial_solution=None 未变；build_model 和 extract_routes 的 AST 与旧 r1 相同，关键 solve 参数也以 AST 核对相同。
- 必访一次、整数 EUC_2D 每边舍入、单容量、最多 K_ref 辆、纯距离目标未变。原始 VRP 和归一化输入逐字节一致；Decimal80 独立重算 40,882 个有向矩阵单元全匹配，实际建模证据的 16 个矩阵哈希再次对齐。

## 时间与资源解释

固定版本官方源码核对了 [MaxRuntime](https://raw.githubusercontent.com/PyVRP/PyVRP/v0.14.0/pyvrp/stop/MaxRuntime.py)、[solve](https://raw.githubusercontent.com/PyVRP/PyVRP/v0.14.0/pyvrp/solve.py) 和 [ILS](https://raw.githubusercontent.com/PyVRP/PyVRP/v0.14.0/pyvrp/IteratedLocalSearch.py)。停止计时从首次 stop 回调开始，随机初解及初始穷尽局部搜索在计时前完成；仅迭代边界检查，允许超过名义时间。0.1 秒不是端到端出解时间。

solve_pre_first_stop_wall 是 solve 前时间点至首次停止回调的观测区间，包括参数/搜索结构准备、初解与预循环准备，不是纯初始化算法时间或初始化 CPU。读取固定版本私有时间字段发生在 solve 返回后，没有插入回调。完整 solve CPU/wall 另记。旧 execute_call 的 process_wall 字段还包含主管解析/校验/清理开销，报告已明确限定。

资源链为主管 CPU20 秒、AS 软512/硬1024 MiB，短子 CPU5/wall10、长子 CPU10/wall15、子 AS1024 MiB，最多一子；外主管墙时1500秒。名义搜索停止参数合计244.8秒，配置 CPU 数值合计740秒，不是实际端到端 CPU 的数学硬上界。保留内核粒度、RSS与AS的区别。r0硬512导致子1024启动失败的问题已由继承证据排除；不能由合成成功保证所有正式调用都不会失败。

## 独立执行与复核证据

- 重新运行30个解析器/可行性验证器测试及6个新编报告测试。真正的 report.main 在临时虚构raw上检验完整96行、缺一seed、进程失败、坏JSON和全未启动；另检验等权聚合、低于/等于/高于reference、非单调配对结果。36项全通过。
- 另独立重新运行3个纯stdlib进程组清理场景及4个fake-API映射场景，均通过，没有导入PyVRP或调用优化。
- 对作者已保存的10个虚构成功求解，重新核对stdout/stderr字节哈希、路线Decimal可行性/目标、seed/预算、实际继承与有效限制、stats长度和计时区间。全预算6项覆盖两档各seed0/1/2。失败注入、重复输出不再spawn及测试源码连续性独立复核通过。没有重跑这些求解。
- 旧r1和r0所有文件相对本阶段快照仍一致；现venv解释器、4,440个已安装文件、14个wheel的哈希均匹配。依赖包45,735,218字节/SHA256 50f01f3c345e12add88bdcfa76189e2f8ef83fde4fd5675d60c41bbf8275d067，与既有分片传输重组回读文件一致；逐wheel同时核验旧完整ZIP内与本地文件。审核没有重新声称完成新的整包Drive直接下载。
- 历史1秒的48份保存路线重新验证：34等于、0低于、14高于reference，16题等权平均gap 0.14874690080787073%。仅作跨时段背景。
- 审查时本阶段raw目录为空；没有发生正式公共求解。

## 统计与结论边界

每档每题必须恰有3个有效seed才给主均值；任一题不完整则该档all16为null；直接两档all16差必须16题两档均完整。失败/缺失行仍占计划分母，配对也标不可用；不补跑、不择优seed。低于reference与等于reference分列，若出现低于值，报告阻断最终主张并要求原来源、距离矩阵、目标、K及映射复核。

两档是同阶段相邻、同题同seed的独立墙钟运行，不能据此声称严格嵌套轨迹、逐题单调或固定算力。历史1秒不是并行新增档，TSR非等算力；没有最优性、SOTA、显著性或总体推广主张。

已修正审查发现的两处文档/报表缺漏：协议旧260秒文字改为740秒；各档逐题range字段补齐。无未解决的预执行阻断项。

## 剩余门槛

1. 将本审核文件、完整合成raw及恢复清单一并冻结，生成PREEXEC档案。
2. 确认私有权限、实际逐字节回读及绑定本次冻结/档案哈希的父任务批准。
3. 严格一次96调用；任何失败保留，不以失败为由补跑。
4. raw立即私有归档回读后再评分，保存路线/报告末审，最后最终私有交付。

证据：BUDGET_PRECHECK_EVIDENCE.json、INPUT_MATRIX_AUDIT.json、ALL_INDEPENDENT_TESTS.txt、HISTORICAL_CONTEXT_AUDIT.json；可复查脚本 audit_budget_precheck.py、test_budget_report.py。
