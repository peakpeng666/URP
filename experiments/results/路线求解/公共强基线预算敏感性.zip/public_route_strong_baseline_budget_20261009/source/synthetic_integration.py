"""Fixed invented inputs only, dispatched from the actual resource-limited production supervisor."""
import sys,json,resource,signal
from pathlib import Path
from common import ROOT,now,read,save,sha
from run_once import execute_call
sys.path.insert(0,str(ROOT/'independent_review'))
from independent_validator import validate_solution
FIXTURES=[
 {'instance_id':'INVENTED_SLACK_K','coordinates':[[0,0],[10,0],[11,0],[12,0]],'demands':[0,1,1,1],'capacity':3,'K':3},
 {'instance_id':'INVENTED_CAPACITY_SPLIT','coordinates':[[0,0],[1,0],[2,0],[0,2]],'demands':[0,2,2,2],'capacity':4,'K':2},
 {'instance_id':'INVENTED_ROUNDING','coordinates':[[0,0],[0.5,0],[2,2],[3,1]],'demands':[0,1,1,1],'capacity':3,'K':2},
 {'instance_id':'INVENTED_DUPLICATE_LOCATION','coordinates':[[0,0],[1,1],[1,1],[4,0]],'demands':[0,1,1,2],'capacity':3,'K':2},
]
def run_in_limited_supervisor(limits):
    assert limits=={'AS_bytes':[512*1024**2,1024*1024**2],'CPU_seconds':[20,20]}
    signal.alarm(60)
    dest=ROOT/'selftests/integration';dest.mkdir(exist_ok=False)
    python=read('environment/RUNTIME.json')['python_executable'];records=[]
    for idx,fixture in enumerate(FIXTURES):
        entry={'call_id':f'FIXTURE_{idx}','seed':0,'max_runtime_seconds':.1,'instance_id':fixture['instance_id']}
        payload={k:v for k,v in fixture.items() if k!='instance_id'};payload.update(seed=0,max_runtime_seconds=.1)
        record=execute_call(entry,payload,python,dest)
        assert record['status']=='UNREVIEWED_PROCESS_SUCCESS' and record['child_reaped'],record
        answer=json.loads((ROOT/record['stdout']).read_text())
        audit=validate_solution(fixture,answer['routes'],answer['reported_cost']);assert audit['valid'] and audit['reported_cost_matches']
        expected={'inherited':limits,'effective':{'AS_bytes':[1024*1024**2,1024*1024**2],'CPU_seconds':[5,5]}}
        assert answer['resource_limits']==expected
        if idx==0:assert len(answer['routes'])<fixture['K']
        records.append({'kind':'synthetic_actual_solver_success','record':record,'validation':audit,'resource_limits':answer['resource_limits'],'worker_maxrss_KiB':answer['worker_maxrss_KiB_audit_only']})
    for kind,expected_status in [('wall_timeout','WALL_TIMEOUT'),('cpu_limit','PROCESS_FAILURE_OR_CPU_LIMIT')]:
        entry={'call_id':'FAULT_'+kind,'seed':0,'max_runtime_seconds':.1,'instance_id':'INVENTED_'+kind}
        record=execute_call(entry,{'synthetic_fault':kind},python,dest,ROOT/'source/synthetic_fault_worker.py')
        assert record['status']==expected_status and record['returncode']<0 and record['child_reaped'],record
        diagnostic=json.loads((ROOT/record['stdout']).read_text())
        assert diagnostic['resource_limits']['inherited']==limits
        if kind=='wall_timeout':assert record['wall_seconds_audit_only']>=10
        if kind=='cpu_limit':assert record['cpu_seconds_audit_only']>=4.5
        records.append({'kind':'synthetic_failure_injection','record':record,'diagnostic':diagnostic})
    entry={'call_id':'FAULT_malformed_payload','seed':0,'max_runtime_seconds':.1,'instance_id':'INVENTED_MALFORMED'}
    bad=execute_call(entry,{'malformed':True},python,dest)
    assert bad['status']=='PROCESS_FAILURE_OR_CPU_LIMIT' and bad['returncode']==1 and bad['child_reaped']
    records.append({'kind':'actual_worker_bad_payload','record':bad})
    # Exclusive output creation catches accidental reuse without spawning another process.
    second=execute_call(entry,{'malformed':True},python,dest)
    assert second['status']=='CALL_ERROR_UNDETERMINED' and not second['process_spawned']
    records.append({'kind':'duplicate_test_path_rejected_before_spawn','record':second})
    signal.alarm(0)
    save(ROOT/'selftests/SUPERVISOR_INTEGRATION.json',{'utc':now(),'status':'PASS','entrypoint':'production run_once.py --synthetic-integration','scope':'Actual production configure_supervisor_limits and execute_call/Popen, real venv worker for4 invented successful optimizations; same Popen and worker resource setup for injected wall/CPU faults; no public inputs or formal gates bypassed.','public_optimizer_calls':0,'synthetic_successful_solves':4,'spawned_fault_processes':3,'duplicate_spawn_prevented':True,'supervisor_limits':limits,'supervisor_maxrss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'source_sha256':{name:sha(ROOT/'source'/name) for name in ['run_once.py','worker.py','synthetic_integration.py','synthetic_fault_worker.py']},'records':records})
    print('PASS actual limited production supervisor -> Popen -> venv worker:4 successes, wall/CPU/malformed faults, duplicate guard')
