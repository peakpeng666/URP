"""Read-only independent route validation and descriptive quality report, gated on raw archive readback."""
from pathlib import Path
import sys,json,csv,statistics
from fractions import Fraction
from resources import caps
from common import ROOT,now,sha,read,save,verify_frozen,verify_old,receipt,verify_prior_failed
sys.path.insert(0,str(ROOT/'independent_review'))
from independent_validator import validate_solution

def dump_csv(path,rows):
    keys=list(dict.fromkeys(k for row in rows for k in row))
    with path.open('x',newline='') as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)

def main():
    verify_frozen(); receipt('RAW_UNREVIEWED');verify_old();verify_prior_failed()
    manifest=read('raw/RAW_UNREVIEWED_MANIFEST.json')
    assert all(sha(ROOT/p)==m['sha256'] for p,m in manifest['files'].items())
    schedule=read('freeze/SCHEDULE.json');tasks=read('freeze/TASKS.json')
    observed=[json.loads(line) for line in (ROOT/'raw/results.jsonl').read_text().splitlines()] if (ROOT/'raw/results.jsonl').exists() else []
    assert len({r['call_id'] for r in observed})==len(observed)
    assert set(r['call_id'] for r in observed)<=set(r['call_id'] for r in schedule)
    by_id={r['call_id']:r for r in observed}
    inputs={t['instance_id']:read(f"input/{t['instance_id']}.json") for t in tasks}
    matrix_hashes={r['instance_id']:r['matrix_sha256'] for r in read('independent_review/INPUT_MATRIX_AUDIT.json')['rows']}
    audit_rows=[];seed_rows=[]
    for e in schedule:
        record=by_id.get(e['call_id']);answer=None;validation=None;errors=[]
        if record is None:errors.append('NEVER_STARTED_OR_MISSING_RECORD')
        elif record['status']!='UNREVIEWED_PROCESS_SUCCESS':errors.append(record['status'])
        if record is not None:
            for typ in ('stdout','stderr'):
                p=ROOT/record[typ]
                if not p.exists() or sha(p)!=record.get(typ+'_sha256'):errors.append(f'{typ}_HASH_MISMATCH')
            if not errors:
                try:
                    answer=json.loads((ROOT/record['stdout']).read_text())
                    validation=validate_solution(inputs[e['instance_id']],answer['routes'],answer['reported_cost'])
                    if not(validation['valid'] and validation['reported_cost_checked'] and validation['reported_cost_matches']):errors.append('INDEPENDENT_ROUTE_VALIDATION_FAILED')
                    if not(answer['solver_is_feasible'] and answer['solver_is_complete']):errors.append('SOLVER_NOT_FEASIBLE_COMPLETE')
                    if answer['reported_fixed_vehicle_cost']!=0 or answer['reported_duration_cost']!=0:errors.append('NON_DISTANCE_OBJECTIVE')
                    if answer['reported_cost']!=answer['reported_distance']:errors.append('DISTANCE_OBJECTIVE_MISMATCH')
                    expected_limits={'inherited':{'AS_bytes':[512*1024**2,1024*1024**2],'CPU_seconds':[20,20]},'effective':{'AS_bytes':[1024*1024**2,1024*1024**2],'CPU_seconds':[caps(e['max_runtime_seconds'])['cpu']]*2}}
                    if answer.get('resource_limits')!=expected_limits:errors.append('RESOURCE_INHERITANCE_MISMATCH')
                    if answer['model_matrix_sha256']!=matrix_hashes[e['instance_id']]:errors.append('MODEL_MATRIX_MISMATCH')
                    if answer['denied_io_events'] or answer['reference_or_history_payload_fields']:errors.append('IO_OR_PAYLOAD_VIOLATION')
                    if answer['seed']!=e['seed'] or answer['max_runtime_seconds']!=e['max_runtime_seconds'] or answer['version']!='0.14.0':errors.append('SCHEDULE_VERSION_MISMATCH')
                    if len(answer['native_routes'])!=len(answer['routes']):errors.append('NATIVE_ROUTE_COUNT_MISMATCH')
                    else:
                        for closed,native in zip(answer['routes'],answer['native_routes']):
                            if [a['node'] for a in native['activities']]!=closed:errors.append('NATIVE_MAPPING_MISMATCH')
                            for pos,a in enumerate(native['activities']):
                                if a['location']!=a['node']:errors.append('LOCATION_MAP_MISMATCH')
                                if pos in (0,len(native['activities'])-1):
                                    if a['type']!='DEPOT' or a['idx']!=0 or a['node']!=0:errors.append('BAD_NATIVE_DEPOT')
                                elif a['type']!='CLIENT' or a['idx']+1!=a['node']:errors.append('BAD_NATIVE_CLIENT')
                            if native['vehicle_type']!=0 or native['num_trips']!=1:errors.append('BAD_NATIVE_VEHICLE_TRIP')
                except Exception as exc:errors.append('PARSE_VALIDATION_EXCEPTION:'+str(exc))
        valid=not errors
        audit_rows.append({'call_id':e['call_id'],'valid':valid,'errors':errors,'validation':validation})
        seed_rows.append({**e,'status':'VALID' if valid else 'UNAVAILABLE','cost':validation['cost'] if valid else None,
                          'nonempty_routes':validation['nonempty_routes'] if valid else None,
                          'iterations':answer.get('num_iterations') if answer else None,
                          'search_runtime_audit_only':answer.get('solver_loop_runtime') if answer else None,
                          'process_wall_audit_only':record.get('wall_seconds_audit_only') if record else None,
                          'process_cpu_audit_only':record.get('cpu_seconds_audit_only') if record else None,
                          'solve_wall_audit_only':answer.get('solve_wall_seconds_audit_only') if answer else None,
                          'solve_cpu_audit_only':answer.get('solve_cpu_seconds_audit_only') if answer else None,
                          'solve_pre_first_stop_wall_audit_only':answer.get('solve_pre_first_stop_wall_seconds_audit_only') if answer else None,
                          'build_wall_audit_only':answer.get('build_wall_seconds_audit_only') if answer else None,
                          'worker_maxrss_KiB_audit_only':answer.get('worker_maxrss_KiB_audit_only') if answer else None,
                          'failure':';'.join(errors)})
    task_rows=[];history_audit=[];refmap={}
    for task in tasks:
        name=task['instance_id'];p=inputs[name];slot=task['selection_slot']
        ref=read(f'references/{name}.json');tsr=read(f'history/S{slot:02d}_TSR.stdout')
        ref_audit=validate_solution(p,[[0,*r,0] for r in ref['reference_routes']],ref['reference_integer_cost'])
        tsr_audit=validate_solution(p,tsr['routes'],tsr['cost'])
        assert ref_audit['valid'] and ref_audit['reported_cost_matches'] and tsr_audit['valid'] and tsr_audit['reported_cost_matches']
        reference=ref_audit['cost'];assert reference>0 and ref['K_ref']==p['K'];refmap[name]=reference
        history_audit.append({'instance_id':name,'reference':ref_audit,'historical_TSR':tsr_audit,'reference_source':ref,'reference_is_not_optimality_proof':True})
        row={'instance_id':name,'selection_slot':slot,'reference_cost':reference,'historical_TSR_cost':tsr_audit['cost'],'short_minus_long_mean3_gap_pp':None}
        means={}
        for budget,prefix in [(0.1,'short'),(5.0,'long')]:
            seed=sorted((r for r in seed_rows if r['instance_id']==name and r['max_runtime_seconds']==budget),key=lambda r:r['seed'])
            values=[r['cost'] for r in seed if r['status']=='VALID'];complete=len(values)==3
            mean=Fraction(sum(values),3) if complete else None;means[budget]=mean
            row.update({prefix+'_valid_seeds':len(values),prefix+'_mean3_cost':float(mean) if mean is not None else None,prefix+'_mean3_reference_gap_percent':float(100*(mean-reference)/reference) if mean is not None else None,prefix+'_min3_cost_secondary':min(values) if complete else None,prefix+'_max3_cost_secondary':max(values) if complete else None,prefix+'_range3_cost_secondary':max(values)-min(values) if complete else None,prefix+'_sample_SD3_cost_secondary':statistics.stdev(values) if complete else None})
            for r in seed:row[prefix+'_seed'+str(r['seed'])+'_cost']=r['cost']
        if all(v is not None for v in means.values()):row['short_minus_long_mean3_gap_pp']=float(100*(means[.1]-means[5.])/reference)
        task_rows.append(row)
    for row in seed_rows:
        reference=refmap[row['instance_id']];cost=row['cost']
        row.update(reference_cost=reference,reference_gap_percent=100*(cost-reference)/reference if cost is not None else None,reference_relation=('EQUAL' if cost==reference else 'BELOW' if cost<reference else 'ABOVE') if cost is not None else 'UNAVAILABLE')
    # Pure aggregation helpers are separately tested for missing data.
    summary=aggregate(seed_rows,task_rows)
    summary.update(utc=now(),stage='DESCRIPTIVE_TWO_BUDGET_SENSITIVITY',solver='PyVRP0.14.0 default ILS, no warmstart',planned_instances=16,planned_calls=96,observed_calls=len(observed),valid_calls=sum(r['valid'] for r in audit_rows),historical_one_second={'context':'Previously archived cross-period context; no new1s calls and no strict same-stage paired timing comparison','summary':read('history/R1_SUMMARY.json'),'reference_equal_count':34},limitations=read('freeze/PROTOCOL.json')['limitations'],old_r1_files_verified_unchanged=verify_old(),prior_r0_files_verified_unchanged=verify_prior_failed())
    below=[r for r in seed_rows if r['reference_relation']=='BELOW']
    summary['below_reference_requires_independent_review']=below
    summary['final_claims_blocked_until_below_review']=bool(below)
    save(ROOT/'reports/SAVED_ROUTE_VALIDATION.json',{'utc':now(),'optimizer_rerun':False,'calls':audit_rows,'history_reference_validation':history_audit})
    save(ROOT/'reports/SUMMARY.json',summary)
    dump_csv(ROOT/'reports/PER_SEED.csv',seed_rows);dump_csv(ROOT/'reports/PER_INSTANCE.csv',task_rows)
    resource_rows=[{k:r[k] for k in ['call_id','max_runtime_seconds','status','process_wall_audit_only','process_cpu_audit_only','solve_wall_audit_only','solve_cpu_audit_only','solve_pre_first_stop_wall_audit_only','build_wall_audit_only','worker_maxrss_KiB_audit_only','iterations','search_runtime_audit_only']} for r in seed_rows]
    save(ROOT/'reports/RESOURCE_USAGE_AUDIT.json',{'utc':now(),'scope':'Actual recorded per-process audit values; process_wall_audit_only covers launch through supervisor output parse/validation and cleanup, not only child lifetime; no speed/hardware-generalization claim','rows':resource_rows,'supervisor':read('raw/FINISHED.json') if (ROOT/'raw/FINISHED.json').exists() else None,'executor':read('raw/EXECUTOR_FINISHED.json'),'configured_caps':read('freeze/PROTOCOL.json')['budget'],'caveats':['solve_pre_first_stop_wall includes solve setup/random/exhaustive initialization and ILS pre-loop preparation; not pure initialization algorithm time.','MaxRuntime excludes imports/model/initialization; this is not a claim that a complete solution is produced within0.1 seconds.','RLIMIT CPU enforcement may overshoot by kernel accounting/scheduling granularity. AS limit is not actual RSS.','Outer packaging, archival, re-analysis and unrelated services are outside supervisor/worker safety caps.']})
    text=['PyVRP默认ILS：两档预算敏感性（描述性）','原16题×seed0/1/2×MaxRuntime0.1s、5s；每次独立新进程与随机初始化，算法/题义未调。',f"新增有效结果{summary['valid_calls']}/96；失败/缺失保留且不补跑。",'主指标为每题3seed均值后16题等权reference gap，0.1减5为正表示5档平均成本更低。']
    for prefix,label in [('short','0.1s主循环停止档'),('long','5s主循环停止档')]:
        b=summary[prefix];text += [f"{label}：完整任务{b['complete_task_count']}/16；全16题平均gap={b['all16_mean_reference_gap_percent']}%；等于reference {b['reference_equal']}/48、低于{b['reference_below']}/48、高于{b['reference_above']}/48、不可用{b['unavailable_calls']}/48。"]
    text += [f"两新档主差（短减长）：{summary['all16_short_minus_long_gap_pp']}个百分点。",'历史1s（原r1的48次）仅跨时段描述性背景：gap0.148746901%，34/48等reference；本次没有重跑1s。','初始化及完整solve/进程实测CPU、wall、内存和RLIMIT逐调用见RESOURCE_USAGE_AUDIT.json。','MaxRuntime从主循环首次stop回调计时，排除导入、建模、初解及初始穷尽局部搜索；只在迭代边界检查。0.1档不代表0.1秒完整出解。','同seed的独立墙钟运行并不保证严格轨迹嵌套或质量逐题单调，结果保留真实实现。','reference只是公开可行比较值，不构成本研究的最优性证明；不作统计显著性、SOTA、等算力或跨硬件速度推广。','若结果低于reference，最终结论须等独立原文件/度量/来源复核。','报告当前待独立末审；raw已在评分前私有归档并逐字节回读。']
    (ROOT/'reports/REPORT_ZH.txt').write_text('\n'.join(text)+'\n')
    print(json.dumps(summary,ensure_ascii=False,indent=2))

def aggregate(seed_rows,task_rows):
    avg=lambda x:sum(x)/len(x) if x else None
    summary={}
    for budget,prefix in [(.1,'short'),(5.,'long')]:
        rows=[r for r in seed_rows if r['max_runtime_seconds']==budget];valid=[r for r in rows if r['status']=='VALID']
        means=[r[prefix+'_mean3_reference_gap_percent'] for r in task_rows if r[prefix+'_mean3_reference_gap_percent'] is not None]
        values=[r['reference_gap_percent'] for r in valid];q=statistics.quantiles(values,n=4,method='inclusive') if len(values)>=2 else [None]*3
        summary[prefix]={'max_runtime_seconds':budget,'valid_calls':len(valid),'unavailable_calls':48-len(valid),'complete_task_count':len(means),'all16_mean_reference_gap_percent':avg(means) if len(means)==16 else None,'available_complete_task_mean_gap_percent_descriptive':avg(means),'reference_equal':sum(r['reference_relation']=='EQUAL' for r in rows),'reference_below':sum(r['reference_relation']=='BELOW' for r in rows),'reference_above':sum(r['reference_relation']=='ABOVE' for r in rows),'seed_gap_distribution_descriptive':{'count':len(values),'minimum':min(values) if values else None,'q1_inclusive':q[0],'median':statistics.median(values) if values else None,'q3_inclusive':q[2],'maximum':max(values) if values else None,'sample_sd':statistics.stdev(values) if len(values)>1 else None}}
    deltas=[r['short_minus_long_mean3_gap_pp'] for r in task_rows if r['short_minus_long_mean3_gap_pp'] is not None]
    summary.update(complete_two_budget_task_count=len(deltas),all16_short_minus_long_gap_pp=avg(deltas) if len(deltas)==16 else None,available_complete_two_budget_task_delta_descriptive=avg(deltas))
    pairs={}
    for r in seed_rows:pairs.setdefault((r['instance_id'],r['seed']),{})[r['max_runtime_seconds']]=r['cost']
    tally={'long_lower_cost':0,'equal_cost':0,'long_higher_cost':0,'unavailable_pair':0}
    for p in pairs.values():
        a,b=p.get(.1),p.get(5.)
        key='unavailable_pair' if a is None or b is None else 'long_lower_cost' if b<a else 'equal_cost' if b==a else 'long_higher_cost';tally[key]+=1
    summary['current_stage_same_instance_seed_descriptive_pairs']=tally
    return summary
if __name__=='__main__':main()
