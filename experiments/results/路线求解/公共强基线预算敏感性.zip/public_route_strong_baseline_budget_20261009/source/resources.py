"""Frozen safety caps, separate from the unchanged ILS stopping rule."""
BUDGETS={0.1:{"cpu":5,"wall":10},5.0:{"cpu":10,"wall":15}}
SUPERVISOR_CPU=20
SUPERVISOR_WALL=1500
def caps(budget):
    assert type(budget) in (int,float) and budget in BUDGETS
    return BUDGETS[budget]
