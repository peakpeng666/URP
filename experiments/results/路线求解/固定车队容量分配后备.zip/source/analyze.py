"""No reruns: denominator-complete paired analysis and full saved-trace validation."""
import csv,json,math,statistics,time
from collections import Counter,defaultdict
from common import ROOT,utc,read,dump,sha,verify,digest
from audit import check
TIMING=('solver_cpu_seconds','solver_wall_seconds','final_checker_cpu_seconds','final_checker_wall_seconds')
TAGS=('run_id','geometry_id','family','pattern_id','pattern_name','input_sha256','version','completed_utc')
def mean(x):return statistics.mean(x) if x else None
def ratio(n,d):return n/d if d else None
def stable(r):return {k:v for k,v in r.items() if k not in TIMING+TAGS}
def serialized(r):return json.dumps(stable(r),sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def jsonl(p):
 rows=[];bad=[]
 if not p.exists():return rows,bad
 ls=p.read_text().splitlines()
 for i,l in enumerate(ls):
  try:rows.append(json.loads(l))
  except json.JSONDecodeError:
   assert i==len(ls)-1;bad.append({'file':str(p.relative_to(ROOT)),'line':i+1,'characters':len(l)})
 return rows,bad
def summary(rs):
 feasible=[r for r in rs if r['oracle_feasible'] is True];infeasible=[r for r in rs if r['oracle_feasible'] is False]
 legal=[r for r in rs if r['legal']]
 return {'planned':len(rs),'recorded':sum(r['status']!='NOT_RUN' for r in rs),'status_counts':dict(Counter(r['status'] for r in rs)),
 'oracle_feasible_planned':len(feasible),'oracle_infeasible_planned':len(infeasible),'oracle_unknown_planned':len(rs)-len(feasible)-len(infeasible),
 'legal_count':len(legal),'legal_rate_all_planned':ratio(len(legal),len(rs)),
 'legal_count_oracle_feasible':sum(r['legal'] for r in feasible),'legal_rate_oracle_feasible':ratio(sum(r['legal'] for r in feasible),len(feasible)),
 'infeasible_emitted_output_count':sum(r['has_output'] for r in infeasible),'infeasible_legal_false_positive_count':sum(r['legal'] for r in infeasible),
 'illegal_output_count':sum(r['has_output'] and not r['valid_output'] for r in rs),
 'valid_only_mean_gap_percent_descriptive':mean([r['gap_percent'] for r in legal if r['gap_percent'] is not None]),
 'exact_count':sum(r['exact'] for r in legal),'within1percent_count':sum(r['within1'] for r in legal),
 'dfs_calls':sum(r.get('dfs_nodes',0)>0 for r in rs),'dfs_nodes':sum(r.get('dfs_nodes',0) for r in rs),'dfs_max_nodes':max([r.get('dfs_nodes',0) for r in rs],default=0),
 'dfs_cpu_seconds':sum(r.get('dfs_cpu_seconds',0) for r in rs),'dfs_wall_seconds':sum(r.get('dfs_wall_seconds',0) for r in rs),'dfs_outcomes':dict(Counter(r['dfs_outcome'] for r in rs if r.get('dfs_outcome'))),
 'solver_cpu_seconds':sum(r.get('solver_cpu_seconds',0) for r in rs),'solver_wall_seconds':sum(r.get('solver_wall_seconds',0) for r in rs),'delta_sum':sum(r.get('deltas',0) for r in rs),'repair_failed_candidates':sum(r.get('repair_failures',0) for r in rs)}
def main():
 start=time.process_time();fr=verify();cfg=read(ROOT/'freeze/PROTOCOL.json');entries=read(ROOT/'freeze/INPUT_MANIFEST.json');schedule=read(ROOT/'freeze/SCHEDULE.json')
 runs,bad=jsonl(ROOT/'raw/heuristics.jsonl');oracles,obad=jsonl(ROOT/'raw/oracles.jsonl');bad+=obad
 byid={r['run_id']:r for r in runs};os={o['instance_id']:o for o in oracles};raws={e['instance_id']:read(ROOT/e['input_file']) for e in entries};assert len(byid)==len(runs) and len(os)==len(oracles)
 assert set(byid)<=set(e['run_id'] for e in schedule)
 hf=read(ROOT/'raw/HEURISTICS_FINISHED.json') if (ROOT/'raw/HEURISTICS_FINISHED.json').exists() else None
 if hf:
  assert sha(ROOT/'raw/heuristics.jsonl')==hf['raw_sha256'] and hf['oracle_main_calls_so_far']==0
  assert max(r['completed_utc'] for r in runs)<=hf['utc'];assert all(hf['utc']<o['completed_utc'] for o in oracles)
  assert fr['utc']<read(ROOT/'raw/STARTED.json')['utc']<hf['utc']
 else:assert not oracles
 for e in entries:
  o=os.get(e['instance_id'])
  if o:
   assert o['input_sha256']==e['input_sha256']
   for k,v in o['result']['by_k'].items():
    if v is not None:assert check(raws[e['instance_id']],dict(v,reported_cost=v['cost']),int(k))['accepted']
 rows=[];tracechecks=[]
 for e in schedule:
  r=byid.get(e['run_id']);raw=raws[e['instance_id']];o=os.get(e['instance_id']);opt=o['result']['by_k']['3'] if o else None;feasible=None if o is None else opt is not None
  row={k:e[k] for k in ['run_id','geometry_id','instance_id','family','pattern_id','pattern_name','method','version','search_seed','input_sha256']}
  row.update(oracle_feasible=feasible,oracle_cost=None if opt is None else opt['cost'])
  if r is None:
   rows.append(row|{'status':'NOT_RUN','legal':False,'valid_output':False,'has_output':False,'cost':None,'gap_percent':None,'exact':False,'within1':False});continue
  for key in row:
   if key in ['oracle_feasible','oracle_cost']:continue
   assert r[key]==e[key]
  assert 0<=r['deltas']<=5000 and sum(r['delta_by_kind'].values())==r['deltas']
  result=check(raw,r['output'],3);base=check(raw,r['baseline'],3);legal=result['accepted'] and r['status']=='LEGAL_COMPLETION'
  if r['baseline'] is not None:assert base['accepted']
  prior=r['baseline'];acc=failed=complete=cut=0;delta=0
  for t in r['trace']:
   assert prior is not None and delta<=t['deltas']<=5000;delta=t['deltas']
   if t['candidate_status']=='complete':
    complete+=1;c=check(raw,t['candidate'],3);assert c['accepted'];yes=c['cost']<prior['reported_cost']-1e-9;assert t['accepted']==yes
    if yes:prior=t['candidate'];acc+=1
   else:
    assert t['candidate_status'] in ['repair_failed','budget_discarded'] and t['candidate'] is None and not t['accepted']
    failed+=t['candidate_status']=='repair_failed';cut+=t['candidate_status']=='budget_discarded'
   assert prior==t['incumbent'] and check(raw,prior,3)['accepted']
  assert prior==r['output'] and acc==r['accepted_improvements'] and failed==r['repair_failures'] and complete==r['iterations_completed']
  cp=(r['initialization'] or {}).get('capacity_partition',{})
  if cp:
   assert e['version']=='capacity_dfs256' and 0<cp['nodes']<=256 and cp['node_limit']==256 and not cp['mathematical_infeasibility_claim']
   if cp['groups'] is not None:
    flat=[n for g in cp['groups'] for n in g];assert sorted(flat)==list(range(1,10)) and len(cp['groups'])<=3
    assert all(sum(raw['demands'][n] for n in g)<=9 for g in cp['groups'])
    assert cp['route_insertion_deltas']==sum(len(g)*(len(g)+1)//2 for g in cp['groups'])
   else:assert r['status']=='CONSTRUCTION_FAIL' and r['output'] is None
  cost=result['cost'] if result['accepted'] else None;tol=max(1e-8,1e-10*abs(opt['cost'])) if opt else 1e-8
  if legal and opt:assert cost>=opt['cost']-tol
  if feasible is False:assert not result['accepted']
  gap=100*(cost-opt['cost'])/opt['cost'] if legal and opt else None
  row.update(status=r['status'],stop_reason=r['stop_reason'],legal=legal,valid_output=result['accepted'],has_output=r['output'] is not None,cost=cost,gap_percent=gap,exact=bool(legal and opt and abs(cost-opt['cost'])<=tol),within1=bool(legal and opt and cost<=1.01*opt['cost']+tol),baseline_cost=base['cost'] if base['accepted'] else None,dfs_nodes=cp.get('nodes',0),dfs_outcome=cp.get('outcome'),dfs_cpu_seconds=cp.get('cpu_seconds',0),dfs_wall_seconds=cp.get('wall_seconds',0),dfs_insertion_deltas=cp.get('route_insertion_deltas',0),repair_failures=failed,deltas=r['deltas'],solver_cpu_seconds=r['solver_cpu_seconds'],solver_wall_seconds=r['solver_wall_seconds'])
  rows.append(row);tracechecks.append({'run_id':r['run_id'],'completed':complete,'repair_failed':failed,'budget_discarded':cut,'accepted':acc,'atomic_and_legality_pass':True})
 pair_index=defaultdict(dict)
 for r in rows:pair_index[(r['instance_id'],r['method'],r['search_seed'])][r['version']]=r
 pairs=[];bitwise=[]
 for key,v in pair_index.items():
  a=v['original'];b=v['capacity_dfs256'];common=a['legal'] and b['legal'];rescue=not a['legal'] and b['legal'];lost=a['legal'] and not b['legal']
  if a['legal']:
   ra=byid[a['run_id']];rb=byid[b['run_id']];same=serialized(ra)==serialized(rb);assert same
   bitwise.append({'original_run_id':a['run_id'],'new_run_id':b['run_id'],'serialized_non_timing_bytes_identical':same,'stable_payload_sha256':digest(stable(ra))})
  pairs.append({k:a[k] for k in ['geometry_id','instance_id','family','pattern_id','method','search_seed','oracle_feasible']}|{'original_run_id':a['run_id'],'new_run_id':b['run_id'],'common_success':common,'rescued':rescue,'lost':lost,'original_gap_percent':a['gap_percent'] if common else None,'new_common_gap_percent':b['gap_percent'] if common else None,'new_rescue_gap_percent':b['gap_percent'] if rescue else None,'new_minus_original_cost':b['cost']-a['cost'] if common else None,'new_solver_cpu_seconds':b.get('solver_cpu_seconds',0),'old_solver_cpu_seconds':a.get('solver_cpu_seconds',0),'solver_cpu_difference_seconds':b.get('solver_cpu_seconds',0)-a.get('solver_cpu_seconds',0),'new_dfs_cpu_seconds':b.get('dfs_cpu_seconds',0),'new_dfs_nodes':b.get('dfs_nodes',0)})
 geoms=[]
 for g in read(ROOT/'freeze/GEOMETRY_MANIFEST.json'):
  ps=[p for p in pairs if p['geometry_id']==g['geometry_id']];item=g|{'versions':{v:summary([r for r in rows if r['geometry_id']==g['geometry_id'] and r['version']==v]) for v in cfg['versions']},'methods':{}}
  for m in cfg['methods']:
   mp=[p for p in ps if p['method']==m];cells=[]
   for pattern in cfg['patterns']:
    z=[p for p in mp if p['pattern_id']==pattern['id']];assert len(z)==4
    cells.append({'pattern_id':pattern['id'],'common_all4':all(p['common_success'] for p in z),'rescued_all4':all(p['rescued'] for p in z),'common_original_gap':mean([p['original_gap_percent'] for p in z]) if all(p['common_success'] for p in z) else None,'common_new_gap':mean([p['new_common_gap_percent'] for p in z]) if all(p['common_success'] for p in z) else None,'rescued_new_gap':mean([p['new_rescue_gap_percent'] for p in z]) if all(p['rescued'] for p in z) else None})
   item['methods'][m]={'cells':cells,'common_cell_count':sum(c['common_all4'] for c in cells),'rescue_cell_count':sum(c['rescued_all4'] for c in cells),'common_original_gap_geometry_mean':mean([c['common_original_gap'] for c in cells if c['common_all4']]),'common_new_gap_geometry_mean':mean([c['common_new_gap'] for c in cells if c['common_all4']]),'rescue_new_gap_geometry_mean':mean([c['rescued_new_gap'] for c in cells if c['rescued_all4']])}
  geoms.append(item)
 versions={v:summary([r for r in rows if r['version']==v]) for v in cfg['versions']}
 patterns={p['id']:{'name':p['name'],'versions':{v:summary([r for r in rows if r['pattern_id']==p['id'] and r['version']==v]) for v in cfg['versions']},'rescued_pairs':sum(x['rescued'] for x in pairs if x['pattern_id']==p['id']),'common_pairs':sum(x['common_success'] for x in pairs if x['pattern_id']==p['id'])} for p in cfg['patterns']}
 quality={}
 for m in cfg['methods']:
  gg=[g['methods'][m] for g in geoms];common=[x for x in gg if x['common_original_gap_geometry_mean'] is not None];rescue=[x for x in gg if x['rescue_new_gap_geometry_mean'] is not None]
  quality[m]={'common_support_geometries':len(common),'common_original_gap_equal_geometry_percent':mean([x['common_original_gap_geometry_mean'] for x in common]),'common_new_gap_equal_geometry_percent':mean([x['common_new_gap_geometry_mean'] for x in common]),'rescue_support_geometries':len(rescue),'rescue_new_gap_equal_geometry_percent':mean([x['rescue_new_gap_geometry_mean'] for x in rescue]),'rescue_baseline_cost_reduction_percent':None,'reason':'Original provides no legal cost for rescued cells. Gaps use independently evaluated oracle only; surviving subsets do not replace planned denominator.'}
 out={'created_utc':utc(),'planned_geometries':16,'planned_inputs':64,'planned_runs':1024,'recorded_runs':len(runs),'oracle_records':len(oracles),'oracle_feasible_inputs':sum(o['result']['by_k']['3'] is not None for o in oracles),'versions':versions,'version_methods':{v:{m:summary([r for r in rows if r['version']==v and r['method']==m]) for m in cfg['methods']} for v in cfg['versions']},'patterns':patterns,'paired_counts':{'pairs':len(pairs),'common_success':sum(p['common_success'] for p in pairs),'rescued':sum(p['rescued'] for p in pairs),'lost':sum(p['lost'] for p in pairs),'bitwise_negative_control_pass':len(bitwise)},'geometry_unit_quality':quality,'family_descriptions':{f:{v:summary([r for r in rows if r['family']==f and r['version']==v]) for v in cfg['versions']} for f in ['uniform','two_cluster']},'main_receipt':read(ROOT/'receipts/main.json'),'statistical_scope':'16 independent geometries; four demand variants and four seeds are blocked repeats. D01 is known mechanism regression, D02 another deliberate tight fixture, D03 low-load negative control, D04 unscreened seeded demand. No population/significance claim.','external_review':'pending','malformed_records':bad,'analysis_cpu_seconds_checkpoint':time.process_time()-start}
 dump(ROOT/'reports/SUMMARY.json',out);dump(ROOT/'reports/RUN_METRICS.json',rows);dump(ROOT/'reports/PAIRED_RESULTS.json',pairs);dump(ROOT/'reports/GEOMETRY_RESULTS.json',geoms)
 dump(ROOT/'reports/TRACE_CHECKS.json',{'verified':True,'run_checks':tracechecks,'bitwise_negative_controls':bitwise,'bitwise_scope':'All non-timing solver fields, excluding experiment tags; serialized IEEE-double costs/routes/trace/counters unchanged. Hardware timing cannot be bitwise equal.','late_oracle_seal_verified':bool(hf),'label_firewall':'run.py allowlists solver raw/config; tags added only after return.'})
 dump(ROOT/'failures/FAILURE_LEDGER.json',{'nonlegal_runs':[r for r in rows if not r['legal']],'malformed_records':bad,'missing_run_ids':[r['run_id'] for r in rows if r['status']=='NOT_RUN'],'construction_fail_is_not_infeasibility_proof':True,'all_planned_retained':True})
 with (ROOT/'reports/RUN_METRICS.csv').open('x') as f:
  w=csv.DictWriter(f,fieldnames=sorted(set().union(*(r.keys() for r in rows))));w.writeheader();w.writerows(rows)
 a=versions['original'];b=versions['capacity_dfs256'];rec=out['main_receipt'];parts=['固定车队：有界容量分配后备的单次冻结试验','', '这是新算法部件：原 savings 与一次FFD原样，仅原失败后加需求/Q/K DFS（256节点硬限）及原箱内最便宜插入。repair/search/随机规则不变；旧源保留且字节一致。',
 f'16个新独立geometry（两族各8）×4需求×2方法×2init×4seed＝1024 calls，全部记录{len(runs)}。只有16个独立几何；需求与seed均为区组内重复。',
 f'主结果：每版本计划512；原合法{a["legal_count"]}/512（{100*a["legal_rate_all_planned"]:.3f}%），新合法{b["legal_count"]}/512（{100*b["legal_rate_all_planned"]:.3f}%）。',
 f'oracle可行{out["oracle_feasible_inputs"]}/64输入：每版本可行分母{a["oracle_feasible_planned"]}；原{a["legal_count_oracle_feasible"]}/{a["oracle_feasible_planned"]}，新{b["legal_count_oracle_feasible"]}/{b["oracle_feasible_planned"]}。原/新不可行侧输出{a["infeasible_emitted_output_count"]}/{b["infeasible_emitted_output_count"]}，非法输出{a["illegal_output_count"]}/{b["illegal_output_count"]}。',
 f'配对：共同成功{out["paired_counts"]["common_success"]}；新增救活{out["paired_counts"]["rescued"]}；丢失原成功{out["paired_counts"]["lost"]}。原成功配对{len(bitwise)}条全通过：输出、双精度成本、baseline、全部trace与计数的序列化逐字节相同（仅剔除CPU/wall及实验标签）。','']
 for pid,p in patterns.items():
  av=p['versions']['original'];bv=p['versions']['capacity_dfs256'];parts.append(f'{pid} {p["name"]}：原合法{av["legal_count"]}/{av["planned"]}，新{bv["legal_count"]}/{bv["planned"]}；可行分母{av["oracle_feasible_planned"]}；救活{p["rescued_pairs"]}配对。')
 parts+=['','次要质量（先同需求内4seed平均，再在geometry内等权、最后等权geometry；仅对应成功支持集，不替代主分母）：']
 for m,q in quality.items():parts.append(f'{m}：共同成功支持{q["common_support_geometries"]} geometry，原/新平均gap {q["common_original_gap_equal_geometry_percent"]}% / {q["common_new_gap_equal_geometry_percent"]}%；救活支持{q["rescue_support_geometries"]} geometry，新gap {q["rescue_new_gap_equal_geometry_percent"]}%。')
 parts+=['新增完成没有原baseline合法成本，因此不计算“降本百分比”；oracle gap仅作为后置质量评价。',f'新DFS调用{b["dfs_calls"]}次，节点总{b["dfs_nodes"]}、最大{b["dfs_max_nodes"]}（硬限256）；DFS累计CPU {b["dfs_cpu_seconds"]:.6f}s。原solver累计CPU {a["solver_cpu_seconds"]:.6f}s，新{b["solver_cpu_seconds"]:.6f}s，差额含救活后新增搜索，不能全当DFS纯开销。',f'所有实际新组内插入delta计原5000，各call未转移/补充；DFS节点是额外有界计算，不宣称等CPU或免费oracle。原/新delta总数{a["delta_sum"]}/{b["delta_sum"]}。',f'主CPU {rec["child_total_cpu_seconds"]:.6f}s、wall {rec["elapsed_wall_seconds"]:.6f}s，硬限90/150，退出{rec["exit_code"]}。准备/分析/包装另计。','全部启发式fsync/hash封存后才调用64个路由oracle，未用于构造、救活、筛样或调节点数；不做数学不可行或广泛泛化声明。D01已知失效机制回归，D02新紧容量例子，D03低负载负对照，D04预定1..5值域与新seed且未筛选。','标准库；模型/API/安装/上传均0。平台token成本未知，未称总成本为0。独立审计由父任务另排。冻结与哈希为本地证据，非第三方可信时间戳。']
 (ROOT/'reports/REPORT_ZH.txt').write_text('\n'.join(parts)+'\n');verify();print(json.dumps({'original_legal':a['legal_count'],'new_legal':b['legal_count'],'oracle_feasible_calls_each':a['oracle_feasible_planned'],'paired':out['paired_counts'],'dfs_cpu_seconds':b['dfs_cpu_seconds']}))
if __name__=='__main__':main()
