"""Evidence-only reproducible archive. No upload or old-bundle mutation."""
import zipfile,json
from common import ROOT,utc,read,dump,sha,verify

def main():
 verify();assert read(ROOT/'reports/TRACE_CHECKS.json')['verified'];s=read(ROOT/'reports/SUMMARY.json')
 stages={stage:read(ROOT/'receipts'/f'{stage}.json') for stage in ['prepare','main','audit']}
 dump(ROOT/'reports/RESOURCE_ACCOUNTING.json',{'created_utc':utc(),'stages':stages,'total_supervised_child_cpu_seconds_before_packaging':sum(x['child_total_cpu_seconds'] for x in stages.values()),'total_supervised_elapsed_wall_seconds_before_packaging':sum(x['elapsed_wall_seconds'] for x in stages.values()),'scope':'Preparation includes toys, one formal numerical launch includes all heuristics and late oracles, audit is local analysis. Editing, packaging and independent review are separate. Not all assistant CPU.', 'planned_calls':1024,'recorded_calls':s['recorded_runs'],'formal_oracle_inputs':s['oracle_records'],'versions':s['versions'],'main_cpu_hard_cap_seconds':90,'main_wall_hard_cap_seconds':150,'external_api_calls':0,'scientific_model_calls':0,'dependency_installs':0,'uploads':0,'financial_scope':'No research API/purchase/install; platform token cost unavailable and not claimed zero.'})
 (ROOT/'README.txt').write_text('Bounded capacity-partition fallback v2. Start reports/REPORT_ZH.txt and SUMMARY.json. This is a new algorithm component; source/fixed_solver.py and source/legacy are unchanged predecessor copies, while source/capacity_solver.py adds only the post-FFD-failure bounded demand-only DFS and construction-failure status. See provenance/MINIMAL_CORE_DIFF.patch. One formal1024-call run,16 independent geometries,64 inputs, oracle only after full heuristic seal. Source/input/pre-run hashes and complete raw trace evidence included. Independent external review pending. Reproduction: copy source and provenance into a NEW directory, mkdir freeze input raw reports receipts failures, then python -B source/supervise.py prepare; main; audit; package as four separate commands. Historical novelty checks require read-only prior paths named in prepare.py. Never rerun this archived directory. Archive excludes itself, its hash and package-stage receipt/logs generated during/after packaging.\n')
 paths=[p for p in sorted(ROOT.rglob('*')) if p.is_file() and p.suffix!='.zip' and p.name not in ['MANIFEST.json','SHA256SUMS.txt','archive.sha256','package.json','package.stdout.log','package.stderr.log'] and '__pycache__' not in str(p)]
 files=[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in paths]
 dump(ROOT/'MANIFEST.json',{'created_utc':utc(),'file_count':len(files),'files':files,'external_audit_status':'pending','exclusions':['archive self/hash','package-stage receipt/logs produced during/after packaging']})
 (ROOT/'SHA256SUMS.txt').write_text(''.join(f'{x["sha256"]}  {x["path"]}\n' for x in files)+f'{sha(ROOT/"MANIFEST.json")}  MANIFEST.json\n')
 archive=ROOT/(ROOT.name+'.zip')
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in paths+[ROOT/'MANIFEST.json',ROOT/'SHA256SUMS.txt']:z.write(p,str(p.relative_to(ROOT)))
 (ROOT/'archive.sha256').write_text(sha(archive)+'  '+archive.name+'\n');print(json.dumps({'path':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'files':len(files)}))
if __name__=='__main__':main()
