"""Only predetermined toy fixtures; no main instances or routing oracle access."""
import copy,json,time
import fixed_solver as old
import capacity_solver as new
from audit import check

def raw(i,d,Q=9,K=3):
 return {'instance_id':i,'coordinates':[[0,0]]*(len(d)+1),'demands':[0]+d,'capacity':Q,'K':K}
def stable(r):
 return {k:v for k,v in r.items() if k not in ('solver_cpu_seconds','solver_wall_seconds','final_checker_cpu_seconds','final_checker_wall_seconds')}
def run():
 cfg={'delta_limit':5000,'per_trajectory_cpu_seconds':2.,'per_trajectory_wall_seconds':10.,'iterations':0}
 tests=[];records=[]
 f=raw('TOY_CAPACITY_RESCUE',[4,4,4,3,3,3,2,2,2])
 a=old.run_one(f,'cheapest',101,cfg);b=new.run_one(f,'cheapest',101,cfg)
 assert a['status']=='INIT_FAIL' and a['output'] is None
 assert b['status']=='LEGAL_COMPLETION' and check(f,b['output'],3)['accepted']
 cp=b['initialization']['capacity_partition'];assert cp['nodes']<=256 and cp['outcome']=='FOUND'
 assert b['deltas']==36+18 and cp['route_insertion_deltas']==18
 tests.append('feasible_capacity_only_rescue_and_18_insertions_charged');records.append({'old':a,'new':b})
 f=raw('TOY_TRUE_PACKING_INFEASIBLE',[5,5,5,5,1,1,1,1,1]);b=new.run_one(f,'regret2',101,cfg)
 assert b['status']=='CONSTRUCTION_FAIL' and b['output'] is None
 assert b['initialization']['capacity_partition']['outcome']=='SEARCH_EXHAUSTED'
 tests.append('four_demands5_need_four_bins_Q9_K3_no_false_positive_no_proof_claim');records.append({'new':b})
 bins,report=new.bounded_partition([0,4,4,4,3,3,3,2,2,2],9,3,1)
 assert bins is None and report['nodes']==1 and report['limit_reached'] and report['outcome']=='NODE_LIMIT'
 tests.append('one_node_toy_limit_is_respected_without_changing_production256');records.append({'one_node_limit':report})
 # Test full failure propagation at the normal production cap on an all-infeasible input.
 f=raw('TOY_SUCCESS_BRANCH',[1,1,1,2,2,2,3,3,3]);cfg['iterations']=12
 for method in ['cheapest','regret2']:
  a=old.run_one(f,method,113,cfg);b=new.run_one(f,method,113,cfg)
  assert a['status']=='LEGAL_COMPLETION' and stable(a)==stable(b)
  assert 'capacity_partition' not in b['initialization']
  tests.append('unchanged_original_success_full_non_timing_record_'+method);records.append({'old':a,'new':b})
 # New insertion cannot escape the old delta cap; incomplete init emits no route.
 f=raw('TOY_DELTA_CUTOFF',[4,4,4,3,3,3,2,2,2]);cfg['iterations']=0;cfg['delta_limit']=40
 b=new.run_one(f,'cheapest',101,cfg)
 assert b['output'] is None and b['deltas']==40 and b['stop_reason']=='delta_budget'
 tests.append('new_group_insertion_truncation_no_output_at_delta40');records.append({'new':b})
 return {'passed':True,'tests':tests,'records':records,'oracle_calls':0,'main_input_calls':0,'timing_exclusion_for_bitwise':'Only four volatile CPU/wall fields excluded; every remaining nested field including routes, binary-double JSON cost, baseline, trace, deltas and budget-check counts identical.'}
