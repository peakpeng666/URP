"""Preregister, toy test, generate unscreened data, freeze; no formal solver/oracle."""
import ast,random
from pathlib import Path
from common import ROOT,utc,sha,read,dump,digest
OLD=[Path('/workspace/shared')/p for p in ['fixed_fleet_cvrp_20261008','fixed_fleet_feasibility_stress_20261008']]
PATTERNS=[{'id':'D01','name':'known_failure_mechanism_regression','demands':[4,4,4,3,3,3,2,2,2]},
 {'id':'D02','name':'new_tight_multiset','demands':[4,4,4,4,3,3,2,2,1]},
 {'id':'D03','name':'low_load_negative_control','demands':[1,1,1,2,2,2,3,3,3]},
 {'id':'D04','name':'unscreened_seeded_random_1_to_5','demands':None,'distribution':'Nine independent uniform integer draws in [1,5] for each geometry; no resampling or feasibility/quality selection.'}]
def cfg():
 return {'title':'Bounded capacity-partition initialization fallback v2','created_utc':utc(),'n':9,'Q':9,'K':3,
 'geometry_count':16,'input_variant_count':64,'geometry_seeds':list(range(2026100837100,2026100837116)),
 'families':['uniform']*8+['two_cluster']*8,'patterns':PATTERNS,'random_demand_seeds':list(range(2026100880000,2026100880016)),
 'geometry_generator':'random.Random(seed); depot(0,0), uniform U[-50,50]^2 or alternating Gaussian centers(-30,-20)/(30,20), sd8; round6.',
 'fixed_demand_shuffle':'random.Random(geometry_seed+1000000+10000*pattern_index).shuffle(fixed vector). Random D04 is generated directly, not shuffled or conditioned.',
 'methods':['cheapest','regret2'],'versions':['original','capacity_dfs256'],'search_seeds':[113011,113027,113041,113057],'schedule_seed':2026100837199,'planned_runs':1024,
 'delta_limit':5000,'iterations':1000000000,'per_trajectory_cpu_seconds':2.,'per_trajectory_wall_seconds':10.,'main_cpu_soft_seconds':89,'main_cpu_hard_seconds':90,'main_wall_seconds':150,
 'capacity_dfs_node_limit':256,'capacity_dfs':'Only after savings returns >K and the original one-shot FFD raises InitFailure. Sort customer IDs by (-demand,id), visit ascending bin IDs; skip equal residual capacities at each node. Count every entered recursive state including root and terminal; hard cap256. No distance or oracle arguments; no cost optimization. SEARCH_EXHAUSTED and NODE_LIMIT both give CONSTRUCTION_FAIL and never mathematical infeasibility claims.',
 'construction_routes':'Found groups use exact original FFD fixed-group sequential cheapest insertion formula/tie order; all actual insertion deltas charged to original5000. DFS bounded nodes are separately counted extra CPU, not free oracle work. Original successful branch unchanged.',
 'core_scope':'fixed_solver.py and legacy/** byte identical to predecessor. capacity_solver.py is new code with explicit minimal diff; repair/search/random primitives unchanged. Only init failure fallback and failure status added.',
 'solver_interface':'Raw only instance_id,coordinates,demands,capacity,K. Config only delta_limit,iterations,per_trajectory_cpu_seconds,per_trajectory_wall_seconds. No pattern, witness, feasibility or oracle metadata sent.',
 'objective':'At most3 nonempty depot-return routes, Q9, each customer once, unrounded Euclidean sum. Not exactly3 routes.',
 'oracle':'No routing oracle called during toys. Main oracle imported only after all1024 heuristic records are flushed/fsynced/hashed/sealed, then evaluates all64 inputs. No rescue, screening, node-limit tuning or warm start. IEEE double exact combinatorial DP, not interval proof.',
 'primary':'Legal completion counts/rates on all planned calls and post-seal oracle-feasible calls per version and method; invalid false positives on oracle-infeasible inputs. INIT_FAIL and CONSTRUCTION_FAIL never infeasibility proofs.',
 'secondary':'Common-success original/new paired gaps, rescue-only new gaps without baseline cost or percent cost reduction. Per geometry average four seeds then equal eligible demand cells;16 geometries are units. Report pattern strata and family descriptions; no significance claim.',
 'negative_control':'Every original successful matched method/seed run must serialize bitwise identically to new counterpart after excluding only four volatile timing fields. All original successful initialization diagnostics, traces, routes, costs, counters remain identical.',
 'failure_policy':'One formal launch, no pilots/reruns/replacements; planned missing rows retained NOT_RUN. Toy fixtures prelisted; no oracle-assisted parameter change.',
 'toy_tests':['capacity-feasible known partition rescued at Q9/K3, charged18 insertion deltas','four demands5 at Q9/K3 truly infeasible and no output','same feasible demands with node_limit1 exhaust','old-success branch full non-timing record identical under both methods','new group insertion respects delta40 and emits no partial output'],
 'novelty_scope':'Both named prior bundles plus their inherited geometry hashes; no universal novelty claim.',
 'external_api_calls':0,'scientific_model_calls':0,'dependency_installs':0,'uploads':0}
def make_geometry(gi,c):
 r=random.Random(c['geometry_seeds'][gi]);xy=[[0.,0.]]
 for j in range(9):
  pt=[r.uniform(-50,50),r.uniform(-50,50)] if c['families'][gi]=='uniform' else [r.gauss(z,8) for z in ((-30,-20) if j%2==0 else (30,20))]
  xy.append([round(z,6) for z in pt])
 return xy
def main():
 c=cfg();dump(ROOT/'freeze/PROTOCOL.json',c)
 old=(ROOT/'source/fixed_solver.py').read_text();new=(ROOT/'source/capacity_solver.py').read_text()
 oa=ast.parse(old);na=ast.parse(new)
 unchanged=['instance_for','ffd_routes','route_options','repair','evaluate_candidate']
 for name in unchanged:
  left=next(x for x in oa.body if isinstance(x,ast.FunctionDef) and x.name==name);right=next(x for x in na.body if isinstance(x,ast.FunctionDef) and x.name==name)
  assert ast.get_source_segment(old,left)==ast.get_source_segment(new,right)
 left=next(x for x in oa.body if isinstance(x,ast.FunctionDef) and x.name=='run_one');right=next(x for x in na.body if isinstance(x,ast.FunctionDef) and x.name=='run_one')
 assert ast.get_source_segment(old,left)==ast.get_source_segment(new,right).replace("        if isinstance(exc,ConstructionFailure):status='CONSTRUCTION_FAIL'\n",'')
 dump(ROOT/'freeze/STATIC_CORE_CHECK.json',{'passed':True,'functions_source_identical':unchanged,'run_one_only_change':'failure status for ConstructionFailure; all search, RNG and counters identical','old_solver_sha256':sha(ROOT/'source/fixed_solver.py'),'new_solver_sha256':sha(ROOT/'source/capacity_solver.py')})

 prov=[]
 for p in sorted((ROOT/'source').rglob('*.py')):
  if p.name not in ['fixed_solver.py','audit.py','oracle.py','common.py'] and 'legacy' not in p.parts:continue
  original=OLD[0]/p.relative_to(ROOT);assert sha(p)==sha(original)
  prov.append({'path':str(p.relative_to(ROOT)),'source':str(original),'sha256':sha(p),'byte_identical':True})
 dump(ROOT/'freeze/SOURCE_PROVENANCE.json',prov)
 def hashes(folders):return {str(p.relative_to(ROOT)):sha(p) for folder in folders for p in sorted((ROOT/folder).rglob('*')) if p.is_file()}
 dump(ROOT/'freeze/PRE_TOY_FREEZE.json',{'utc':utc(),'main_calls':0,'oracle_calls':0,'sha256':hashes(['source','provenance','freeze'])})
 from toys import run
 toy=run();assert toy['passed'];dump(ROOT/'reports/TOY_VALIDATION.json',toy)
 dump(ROOT/'freeze/PRE_GENERATION_FREEZE.json',{'utc':utc(),'main_calls':0,'main_inputs_generated':0,'oracle_calls':0,'sha256':hashes(['source','provenance','freeze','reports'])})
 oldo=set();oldu=set();records=[]
 for d in OLD:
  for p in sorted((d/'input').glob('*.json')):
   v=read(p)
   if not isinstance(v,dict) or 'coordinates' not in v:continue
   h=digest(v['coordinates']);u=digest(sorted(v['coordinates']));oldo.add(h);oldu.add(u);records.append({'path':str(p),'sha256':sha(p),'ordered':h,'unordered':u})
  q=read(d/'freeze/OLD_GEOMETRY_HASHES.json')
  for key in ['hashes','ordered_hashes','inherited_ordered_hashes']:oldo.update(q.get(key,[]))
  oldu.update(q.get('unordered_hashes',[]))
 dump(ROOT/'freeze/OLD_GEOMETRY_HASHES.json',{'ordered_hashes':sorted(oldo),'unordered_hashes':sorted(oldu),'records':records})
 entries=[];geoms=[];new=set();newu=set()
 for gi in range(16):
  xy=make_geometry(gi,c);h=digest(xy);u=digest(sorted(xy));assert h not in oldo|new and u not in oldu|newu;new.add(h);newu.add(u)
  gid=f'CP{gi+1:02d}';seed=c['geometry_seeds'][gi];g={'geometry_id':gid,'generation_seed':seed,'family':c['families'][gi],'coordinates_sha256':h,'unordered_coordinates_sha256':u};geoms.append(g)
  for pi,p in enumerate(PATTERNS):
   if p['demands'] is None:
    ds=c['random_demand_seeds'][gi];r=random.Random(ds);dem=[r.randint(1,5) for _ in range(9)]
   else:
    ds=seed+1000000+10000*pi;dem=p['demands'][:];random.Random(ds).shuffle(dem)
   iid=gid+'-'+p['id'];path=f'input/{iid}.json';raw={'instance_id':iid,'coordinates':xy,'demands':[0]+dem,'capacity':9,'K':3};dump(ROOT/path,raw)
   entries.append(g|{'instance_id':iid,'pattern_id':p['id'],'pattern_name':p['name'],'demand_seed':ds,'input_file':path,'input_sha256':sha(ROOT/path)})
 dump(ROOT/'freeze/GEOMETRY_MANIFEST.json',geoms);dump(ROOT/'freeze/INPUT_MANIFEST.json',entries)
 schedule=[dict(e,method=m,version=v,search_seed=s) for e in entries for s in c['search_seeds'] for m in c['methods'] for v in c['versions']];random.Random(c['schedule_seed']).shuffle(schedule)
 for i,e in enumerate(schedule):e['run_id']=i
 dump(ROOT/'freeze/SCHEDULE.json',schedule)
 dump(ROOT/'freeze/PRE_RUN_FREEZE.json',{'utc':utc(),'main_launches_before_freeze':0,'planned_runs':1024,'sha256':hashes(['source','provenance','freeze','input','reports'])})
 print('FROZEN: toy PASS;16 new geometries,64 inputs,1024 calls; formal solver/oracle calls0.')
if __name__=='__main__':main()
