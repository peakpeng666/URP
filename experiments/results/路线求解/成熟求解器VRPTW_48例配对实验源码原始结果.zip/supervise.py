"""Measure whole benchmark child incl imports; hard CPU/wall caps; never retries."""
import os,sys,time,resource,json,subprocess,signal
from pathlib import Path
P=Path(__file__).resolve().parent
def limit():resource.setrlimit(resource.RLIMIT_CPU,(109,110))
t=time.monotonic()
with (P/'benchmark.stdout.log').open('x') as out,(P/'benchmark.stderr.log').open('x') as err:
    child=subprocess.Popen([str(P/'.venv/bin/python'),'-B',str(P/'experiment.py'),'run'],stdout=out,stderr=err,preexec_fn=limit)
    resource.setrlimit(resource.RLIMIT_CPU,(4,5))
    killed=False
    while True:
        pid,status,usage=os.wait4(child.pid,os.WNOHANG)
        if pid:break
        if time.monotonic()-t>130:
            os.kill(child.pid,signal.SIGKILL);killed=True
        time.sleep(.1)
    rc=os.waitstatus_to_exitcode(status);child.returncode=rc
rec={'child_returncode':rc,'child_user_cpu_s':usage.ru_utime,'child_system_cpu_s':usage.ru_stime,
     'child_cpu_total_s':usage.ru_utime+usage.ru_stime,'wall_s':time.monotonic()-t,
     'max_rss_kib':usage.ru_maxrss,'child_cpu_hard_limit_s':110,'supervisor_cpu_hard_limit_s':5,
     'wall_hard_limit_s':130,'wall_watchdog_killed':killed,
     'supervisor_cpu_s':time.process_time(),'no_retry':True}
(P/'run_resource.json').write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec))
