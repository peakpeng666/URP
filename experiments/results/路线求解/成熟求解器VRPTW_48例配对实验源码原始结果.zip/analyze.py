import json,time,statistics,collections,resource
from pathlib import Path
from checker import audit
resource.setrlimit(resource.RLIMIT_CPU,(9,10))
P=Path(__file__).resolve().parent
start=time.process_time()
def load(name):return json.loads((P/name).read_text())
def write(name,x):(P/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
I={i['id']:i for i in load('inputs.json')};E={i['instance']:i for i in load('encoded_inputs.json')}
R=[json.loads(x) for x in (P/'results.jsonl').read_text().splitlines()]
Q=load('requests.json');B=[json.loads(x) for x in (P/'reference/routes.jsonl').read_text().splitlines()]
O=load('reference/oracle_tables.json');F={iid for iid,o in O.items() if o['full_feasible']}
def full(r):return r.get('audit') is not None and r['audit']['full_service_feasible']
def original_oracle(iid):return O[iid]['best_two_vehicle_by_served_mask'].get('127')
def gap(r):
    o=original_oracle(r['instance'])
    return (r['audit']['total_distance']/o['distance']-1)*100 if full(r) and o else None
for r in R:r['full_gap_original_percent']=gap(r);r['reference_oracle_full_feasible']=r['instance'] in F
write('evaluated_results.json',R)
def describe(v):
    return {'n':len(v),'mean':statistics.mean(v),'median':statistics.median(v),'max':max(v),'min':min(v)} if v else {'n':0,'mean':None,'median':None,'max':None,'min':None}
def sum_for(rr):
    ff=[r for r in rr if r['instance'] in F];good=[r for r in ff if full(r)]
    return {'requested_n':len(rr),'original_oracle_feasible_n':len(ff),'valid_full_service_n':len(good),
      'success_rate_feasible':len(good)/len(ff) if ff else None,'success_ids':[r['instance'] for r in good],
      'missed_original_feasible_ids':[r['instance'] for r in ff if not full(r)],
      'outcomes_all48':dict(collections.Counter(r['outcome'] for r in rr)),
      'ortools_status_counts_all48':dict(collections.Counter(r.get('ortools_status_name','ERROR') for r in rr)),
      'original_infeasible_n':sum(r['instance'] not in F for r in rr),
      'original_infeasible_outcomes':dict(collections.Counter(r['outcome'] for r in rr if r['instance'] not in F)),
      'full_gap_percent':describe([gap(r) for r in good]),
      'solver_wall_s_all':describe([r['solve_wall_s'] for r in rr if 'solve_wall_s' in r]),
      'solver_cpu_s_all':describe([r['solve_cpu_s'] for r in rr if 'solve_cpu_s' in r]),
      'solver_wall_s_feasible':describe([r['solve_wall_s'] for r in ff if 'solve_wall_s' in r]),
      'first_solution_wall_s':describe([r['first_solution']['wall_s'] for r in good if r.get('first_solution')]),
      'solver_cpu_s_sum':sum(r.get('solve_cpu_s',0) for r in rr),
      'total_cpu_s_sum':sum(r.get('total_cpu_s',0) for r in rr),
      'checker_rejected_n':sum(r['outcome']=='find_but_checker_rejected' for r in rr)}
summary={'unique_instances':48,'geometry_clusters':16,'requests':len(Q),'completed_records':len(R),'missing_run_ids':sorted({q['run_id'] for q in Q}-{r['run_id'] for r in R}),
         'original_oracle_feasible_n':len(F),'original_oracle_infeasible_n':48-len(F),'budgets':{},'baseline':{},'paired_comparisons':{}}
for ms in [250,1000]:summary['budgets'][str(ms)]=sum_for([r for r in R if r['budget_ms']==ms])
for m in ['distance_first','time_window_first']:
    rr=[r for r in B if r['method']==m]
    summary['baseline'][m]={'full_n':sum(full(r) for r in rr),'feasible_denominator':len(F),'full_gap_percent':describe([gap(r) for r in rr if full(r)]),'cpu_s_sum':sum(r.get('cpu_seconds',0) for r in rr),'g12_tight':next(r for r in rr if r['instance']=='G12_tight')}
    bm={r['instance']:r for r in rr}
    for ms in [250,1000]:
        nm={r['instance']:r for r in R if r['budget_ms']==ms};common=[iid for iid in F if iid in nm and full(nm[iid]) and full(bm[iid])]
        summary['paired_comparisons'][f'{ms}ms_vs_{m}']={
          'feasible_denominator':len(F),'mature_only_full':sum(full(nm[iid]) and not full(bm[iid]) for iid in F if iid in nm),
          'baseline_only_full':sum(not full(nm[iid]) and full(bm[iid]) for iid in F if iid in nm),
          'both_full_n':len(common),'both_fail':sum(not full(nm[iid]) and not full(bm[iid]) for iid in F if iid in nm),
          'mature_gap_mean_common':statistics.mean(gap(nm[iid]) for iid in common) if common else None,
          'baseline_gap_mean_common':statistics.mean(gap(bm[iid]) for iid in common) if common else None,
          'mature_shorter':sum(nm[iid]['audit']['total_distance']<bm[iid]['audit']['total_distance']-1e-7 for iid in common),
          'baseline_shorter':sum(bm[iid]['audit']['total_distance']<nm[iid]['audit']['total_distance']-1e-7 for iid in common),
          'same_cost':sum(abs(bm[iid]['audit']['total_distance']-nm[iid]['audit']['total_distance'])<=1e-7 for iid in common)}
a={r['instance']:r for r in R if r['budget_ms']==250};b={r['instance']:r for r in R if r['budget_ms']==1000}
common=[iid for iid in F if iid in a and iid in b and full(a[iid]) and full(b[iid])]
summary['budget_pairing']={'unique_feasible_n':len(F),'both_full':len(common),'short_only_full':sum(full(a[iid]) and not full(b[iid]) for iid in F if iid in a and iid in b),'long_only_full':sum(full(b[iid]) and not full(a[iid]) for iid in F if iid in a and iid in b),'long_cost_better':sum(b[iid]['audit']['total_distance']<a[iid]['audit']['total_distance']-1e-7 for iid in common),'short_cost_better':sum(a[iid]['audit']['total_distance']<b[iid]['audit']['total_distance']-1e-7 for iid in common),'cost_tie':sum(abs(a[iid]['audit']['total_distance']-b[iid]['audit']['total_distance'])<=1e-7 for iid in common),'not_independent_samples':True}
# Post-hoc diagnostic only. Uses existing oracle routes, never feeds any route to solver.
rep=[]
for iid in sorted(F):
    o=original_oracle(iid);e=E[iid];viol=[];cost=0
    for route in o['routes']:
        prev=0;now=e['depart_scaled']
        for node in route:
            now=max(now+e['transit_service_from_plus_travel'][prev][node],e['windows_inward'][node][0])
            if now>e['windows_inward'][node][1]:viol.append({'node':node,'late_ticks':now-e['windows_inward'][node][1]})
            cost+=e['cost_matrix_nearest'][prev][node];prev=node
        now+=e['transit_service_from_plus_travel'][prev][0];cost+=e['cost_matrix_nearest'][prev][0]
        if now>e['return_deadline_scaled']:viol.append({'depot_late_ticks':now-e['return_deadline_scaled']})
    rep.append({'instance':iid,'original_optimal_witness_encoded_feasible':not viol,'violations':viol,'witness_integer_cost':cost,'original_distance_recomputed':audit(I[iid],o['routes'])['total_distance']})
write('oracle_witness_encoding_diagnostic.json',rep)
summary['original_oracle_optimal_witnesses_encoded_feasible_n']=sum(x['original_optimal_witness_encoded_feasible'] for x in rep)
summary['g12_tight']=[r for r in R if r['instance']=='G12_tight']
summary['by_level']={str(ms):{lev:sum_for([r for r in R if r['budget_ms']==ms and I[r['instance']]['level']==lev]) for lev in ['tight','medium','wide']} for ms in [250,1000]}
summary['analysis_cpu_s']=time.process_time()-start
write('summary.json',summary)
print(json.dumps({k:v for k,v in summary.items() if k in ['budgets','budget_pairing','paired_comparisons']},ensure_ascii=False,indent=2))
