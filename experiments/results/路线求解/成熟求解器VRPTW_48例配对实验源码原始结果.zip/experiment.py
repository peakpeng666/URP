"""Frozen, one-pass OR-Tools VRPTW benchmark. Never imports original solver/oracle."""
import os
os.environ.setdefault('OMP_NUM_THREADS','1')
import sys,json,math,time,hashlib,platform,importlib.metadata,traceback,shutil
from pathlib import Path
from decimal import Decimal,ROUND_CEILING,ROUND_FLOOR
from datetime import datetime,timezone
from ortools.constraint_solver import pywrapcp,routing_enums_pb2
from ortools.util import optional_boolean_pb2
from google.protobuf import text_format
from checker import audit,tests
P=Path(__file__).resolve().parent
SCALE=1_000_000; SEED=2026100707; BUDGETS=[250,1000]
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(name,value):(P/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def parameters(ms):
    p=pywrapcp.DefaultRoutingSearchParameters()
    p.first_solution_strategy=routing_enums_pb2.FirstSolutionStrategy.PATH_CHEAPEST_ARC
    p.local_search_metaheuristic=routing_enums_pb2.LocalSearchMetaheuristic.GUIDED_LOCAL_SEARCH
    p.guided_local_search_lambda_coefficient=0.1
    p.time_limit.FromMilliseconds(ms)
    p.lns_time_limit.FromMilliseconds(100)
    p.use_cp=optional_boolean_pb2.BOOL_TRUE
    p.use_cp_sat=optional_boolean_pb2.BOOL_FALSE
    p.use_generalized_cp_sat=optional_boolean_pb2.BOOL_FALSE
    p.fallback_to_cp_sat_size_threshold=0
    p.sat_parameters.num_search_workers=1
    p.sat_parameters.random_seed=SEED
    p.log_search=False
    return p

def scaled(x,direction):
    return int((Decimal(str(x))*SCALE).to_integral_value(rounding=direction))
def encode(instance):
    nodes=instance['nodes']; n=len(nodes)
    coords=[]
    for x in nodes:
        xy=[Decimal(str(x[k]))*1000 for k in ('x','y')]
        assert all(t==int(t) for t in xy)
        coords.append([int(t) for t in xy])
    costs=[]; travels=[]
    for a in coords:
        cost=[];travel=[]
        for b in coords:
            q=((a[0]-b[0])**2+(a[1]-b[1])**2)*(SCALE//1000)**2
            f=math.isqrt(q)
            travel.append(f+(f*f<q))
            cost.append(f+(4*q>=(2*f+1)**2))
        costs.append(cost);travels.append(travel)
    service=[scaled(x['service'],ROUND_CEILING) for x in nodes]
    assert all(Decimal(str(x['service']))*SCALE==s for x,s in zip(nodes,service))
    transit=[[travels[i][j]+service[i] for j in range(n)] for i in range(n)]
    windows=[[scaled(x['window'][0],ROUND_CEILING),scaled(x['window'][1],ROUND_FLOOR)] for x in nodes]
    return {'instance':instance['id'],'node_ids':[x['id'] for x in nodes],'scale':SCALE,
        'cost_matrix_nearest':costs,'travel_matrix_ceil':travels,'transit_service_from_plus_travel':transit,
        'service_scaled':service,'windows_inward':windows,'demands':[x['demand'] for x in nodes],
        'vehicles':instance['vehicles'],'capacity':instance['capacity'],
        'depart_scaled':scaled(instance['depart_time'],ROUND_CEILING),
        'return_deadline_scaled':scaled(instance['return_deadline'],ROUND_FLOOR)}

def prepare():
    assert not (P/'freeze.json').exists(),'Refuse to replace prior freeze'
    src=Path('/workspace/shared/vrp_time_windows_20261007')
    aud=Path('/workspace/shared/audit_vrp_time_windows_20261007')
    (P/'reference').mkdir(exist_ok=True)
    for name in ['inputs.json','protocol.json','freeze.json','routes.jsonl','oracle_tables.json','summary.json','report_zh.txt']:
        shutil.copyfile(src/name,P/'reference'/name)
    for name in ['independent_results.json','audit_zh.txt']:
        shutil.copyfile(aud/name,P/'reference'/name)
    shutil.copyfile(src/'inputs.json',P/'inputs.json')
    data=json.loads((P/'inputs.json').read_text())
    assert len(data)==48 and len({i['id'] for i in data})==48
    assert sha(P/'inputs.json')=='a899e22baf91e1435b8aca7af88c0107ea90a7439f257e4ba2bc55d2275af6bb'
    encoded=[encode(i) for i in data];write('encoded_inputs.json',encoded)
    order=[]
    for k,i in enumerate(data):
        for ms in (BUDGETS if k%2==0 else BUDGETS[::-1]):
            order.append({'sequence':len(order),'instance':i['id'],'budget_ms':ms,'run_id':f"{i['id']}__{ms}ms",'random_seed':SEED})
    write('requests.json',order)
    for ms in BUDGETS:(P/f'parameters_{ms}ms.textproto').write_text(str(parameters(ms)))
    env={'python':sys.version,'python_executable':str(Path(sys.executable).resolve()),'platform':platform.platform(),
        'machine':platform.machine(),'ortools':importlib.metadata.version('ortools'),
        'packages':sorted([{'name':d.metadata['Name'],'version':d.version} for d in importlib.metadata.distributions()],key=lambda d:d['name'].lower()),
        'cpu_count_visible':os.cpu_count(),'tested_user_machine':False,'target_migration_note':'Actual cloud Linux CPython3.12.14 only; Ubuntu22.04/Python3.10 not tested.'}
    write('environment.json',env)
    (P/'requirements.lock').write_text('\n'.join(f"{d['name']}=={d['version']}" for d in env['packages'] if d['name'].lower()!='pip')+'\n')
    protocol={
      'study_id':'VRPTW_MATURE_SOLVER_20261007_FIXED_V1','question':'Can a fixed mature solver close full-service misses in the same48 CVRPTW cases?',
      'inputs':'Exact byte-for-byte copy of existing48; 16 correlated geometry triples;7 nodes,2 vehicles,capacity6; no filtering/resampling',
      'objective':'Mandatory all7 service tasks; minimize total Euclidean route length; no disjunctions, dropped-node penalties, vehicle fixed costs or span costs',
      'time_semantics':'Inclusive start-of-service windows; departures0; waiting allowed; service2; return by120; continuous checker replays earliest schedules',
      'solver':'OR-Tools9.14.6206 RoutingModel CP, PATH_CHEAPEST_ARC + GUIDED_LOCAL_SEARCH lambda0.1; full textproto saved; CP-SAT fallback disabled; one CP search thread',
      'seed':SEED,'budgets_ms':BUDGETS,'budget_semantics':'Per-call wall-clock search limit, plus separately measured model/extraction/check overhead; one fresh solve per instance per budget; no warmstart or oracle route fed to solver',
      'order':'Input file order; even0-based instance index250ms then1000ms; odd1000ms then250ms; fixed pairing before solving',
      'repeats':0,'pilot_solves':0,'no_retuning':'No solver/configuration changes after freeze; errors retained; no repeated failed runs',
      'integer_encoding':{'scale':SCALE,'coordinates':'Original3-decimal coordinates converted exactly to integer thousandths',
        'cost':'Nearest integer length*S via exact integer square-root and midpoint comparison, ties up. Per-arc error<=0.5/S; full route<=9 arcs so total error<=4.5e-6 original distance units',
        'time':'Exact integer square-root ceiling of travel*S plus exact service*S. Per-travel overestimate<1/S; window lower ceil(S*decimal JSON lower), upper floor(S*decimal JSON upper); departure0 and return120 exact',
        'error_bound':'For a fixed route with m tasks: encoded earliest service time exceeds continuous by less than (m+1)/S; return by less than (m+2)/S. Conservative universal m<=7 bounds8e-6 for service,9e-6 for return. An upper-bound floor tightens by<1e-6. Bound excludes tiny binary-float replay roundoff, checker tolerance1e-9.',
        'limitation':'Inward rounding can exclude original boundary-feasible routes. No encoded infeasibility claim about original. Post-solve check original oracle witness representability only, no solver tuning. Integer cost exact optimum, if proven, would still apply to encoded subset only.'},
      'resource':'Single benchmark process RLIMIT_CPU110s hard; supervisor5s; installation measured separately; remaining verification/packaging caps total20s. Total requested computation below180CPU seconds; no network/paidAPI in solve.',
      'analysis':'33 original-oracle-feasible instances primary denominator;15 proven-infeasible by reference oracle separately reported, never algorithm-ranking denominator. Full gap from original continuous checker and reference continuous exact optimum. Paired budgets are same48 not96 independent instances. Report counts, mean/median/max gap and time; no p-values, no universal superiority.',
      'status':'find only with returned assignment and independently valid full service; find_but_checker_rejected distinct; fail_timeout only when solver reports timeout; other null assignment no_solution_in_budget or error, never proof of original infeasibility',
      'checker':'Unchanged original independent checker source copied; no solver matrix used. Post-run verification independently replays all new non-null routes using different implementation.',
      'sources':['https://developers.google.com/optimization/install/python','https://pypi.org/project/ortools/9.14.6206/','https://developers.google.com/optimization/routing/vrptw','https://developers.google.com/optimization/routing/routing_options'],
      'official_compatibility':'Pinned PyPI9.14.6206 metadata requires Python>=3.9 and lists CPython3.12 wheels; this is compatibility metadata, not Python3.10 migration acceptance.'}
    write('protocol.json',protocol)
    include=['inputs.json','encoded_inputs.json','requests.json','protocol.json','experiment.py','checker.py','supervise.py','analyze.py','verify.py','requirements.lock','environment.json']+[f'parameters_{ms}ms.textproto' for ms in BUDGETS]
    write('freeze.json',{'frozen_at_utc':datetime.now(timezone.utc).isoformat(),'before_any_solver_call':True,'pilot_solves':0,'sha256':{n:sha(P/n) for n in include}})
    print('Prepared and frozen96 requests; solver calls0',flush=True)

def solve(instance,e,request):
    t0=time.perf_counter();cpu0=time.process_time()
    manager=pywrapcp.RoutingIndexManager(len(e['node_ids']),e['vehicles'],0)
    routing=pywrapcp.RoutingModel(manager)
    routing.solver().ReSeed(SEED)
    def cost(a,b):return e['cost_matrix_nearest'][manager.IndexToNode(a)][manager.IndexToNode(b)]
    def transit(a,b):return e['transit_service_from_plus_travel'][manager.IndexToNode(a)][manager.IndexToNode(b)]
    def demand(a):return e['demands'][manager.IndexToNode(a)]
    ci=routing.RegisterTransitCallback(cost);ti=routing.RegisterTransitCallback(transit);di=routing.RegisterUnaryTransitCallback(demand)
    routing.SetArcCostEvaluatorOfAllVehicles(ci)
    routing.AddDimensionWithVehicleCapacity(di,0,[e['capacity']]*e['vehicles'],True,'Capacity')
    horizon=e['return_deadline_scaled']
    routing.AddDimension(ti,horizon,horizon,True,'Time')
    td=routing.GetDimensionOrDie('Time')
    for j,w in enumerate(e['windows_inward']):
        if j:td.CumulVar(manager.NodeToIndex(j)).SetRange(*w)
    for v in range(e['vehicles']):
        td.CumulVar(routing.Start(v)).SetValue(e['depart_scaled'])
        td.CumulVar(routing.End(v)).SetRange(0,horizon)
    p=routing_enums_pb2 # parameters loaded exactly from frozen serialized configuration
    params=pywrapcp.DefaultRoutingSearchParameters();params.Clear()
    text_format.Parse((P/f"parameters_{request['budget_ms']}ms.textproto").read_text(),params)
    checkpoints=[]
    solve_start=time.perf_counter();scpu=time.process_time()
    def on_solution():
        if not checkpoints:checkpoints.append({'wall_s':time.perf_counter()-solve_start,'cpu_s':time.process_time()-scpu,'objective_integer':routing.CostVar().Value()})
    routing.AddAtSolutionCallback(on_solution)
    sol=routing.SolveWithParameters(params)
    solve_wall=time.perf_counter()-solve_start;solve_cpu=time.process_time()-scpu
    raw_status=routing.status();status_name=routing_enums_pb2.RoutingSearchStatus.Value.Name(raw_status)
    out={**request,'ortools_status':raw_status,'ortools_status_name':status_name,'assignment_returned':sol is not None,
        'solve_wall_s':solve_wall,'solve_cpu_s':solve_cpu,'first_solution':checkpoints[0] if checkpoints else None,
        'model_wall_s':solve_start-t0,'model_cpu_s':scpu-cpu0,'routes':None,'encoded_cumul_ranges':None,
        'objective_integer':None,'audit':None,'outcome':'timeout_no_assignment' if raw_status==4 else 'no_solution_in_budget'}
    if sol is not None:
        routes=[];ranges=[]
        for v in range(e['vehicles']):
            idx=routing.Start(v);route=[];vr=[]
            while True:
                j=manager.IndexToNode(idx);cv=td.CumulVar(idx)
                vr.append({'node':j,'min':sol.Min(cv),'max':sol.Max(cv),'is_start':routing.IsStart(idx),'is_end':routing.IsEnd(idx)})
                if routing.IsEnd(idx):break
                if not routing.IsStart(idx):route.append(e['node_ids'][j])
                idx=sol.Value(routing.NextVar(idx))
            routes.append(route);ranges.append(vr)
        checked=audit(instance,routes)
        out.update(routes=routes,encoded_cumul_ranges=ranges,objective_integer=sol.ObjectiveValue(),audit=checked,
                   outcome='find' if checked['full_service_feasible'] else 'find_but_checker_rejected')
    out.update(total_wall_s=time.perf_counter()-t0,total_cpu_s=time.process_time()-cpu0)
    return out

def run():
    freeze=json.loads((P/'freeze.json').read_text())
    for name,digest in freeze['sha256'].items():assert sha(P/name)==digest,name
    assert importlib.metadata.version('ortools')=='9.14.6206'
    assert not (P/'results.jsonl').exists(),'Refuse second benchmark pass'
    write('checker_tests.json',{'passed':True,'tests':tests()})
    data={i['id']:i for i in json.loads((P/'inputs.json').read_text())}
    enc={i['instance']:i for i in json.loads((P/'encoded_inputs.json').read_text())}
    requests=json.loads((P/'requests.json').read_text())
    with (P/'results.jsonl').open('x') as f:
        for req in requests:
            try:r=solve(data[req['instance']],enc[req['instance']],req)
            except Exception as ex:
                r={**req,'outcome':'error','routes':None,'audit':None,'assignment_returned':False,'error':repr(ex),'traceback':traceback.format_exc()}
                with (P/'failures.jsonl').open('a') as ff:ff.write(json.dumps(r)+'\n')
            f.write(json.dumps(r,ensure_ascii=False)+'\n');f.flush()
            print(req['run_id'],r['outcome'],r.get('ortools_status_name'),flush=True)
if __name__=='__main__':
    {'prepare':prepare,'run':run}[sys.argv[1]]()
