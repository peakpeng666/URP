"""Independent post-run replay: no adapter, experiment, or checker imports; no solves."""
import json,math,hashlib,time,resource,collections
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CPU,(9,10));start=time.process_time()
P=Path(__file__).resolve().parent
def load(n):return json.loads((P/n).read_text())
I={i['id']:i for i in load('inputs.json')};E={i['instance']:i for i in load('encoded_inputs.json')}
R=[json.loads(x) for x in (P/'results.jsonl').read_text().splitlines()];Q=load('requests.json');O=load('reference/oracle_tables.json')
assert len(R)==len(Q)==96 and len({r['run_id'] for r in R})==96
assert [r['run_id'] for r in R]==[q['run_id'] for q in Q]
for n,h in load('freeze.json')['sha256'].items():assert hashlib.sha256((P/n).read_bytes()).hexdigest()==h,n
checks=0;max_cost_error=0.;max_replay_distance_error=0.;bad=[]
for r in R:
    if r['routes'] is None:
        assert not r.get('assignment_returned') and r.get('audit') is None
        continue
    i=I[r['instance']];e=E[r['instance']];n={x['id']:x for x in i['nodes']};seen=[];dist=0.;issues=[];int_cost=0
    assert len(r['routes'])==2
    for route in r['routes']:
        now=0.;prev=0;load_route=0;inow=0
        for node in route:
            seen.append(node);a=n[prev];b=n[node]
            d=math.hypot(a['x']-b['x'],a['y']-b['y']);dist+=d
            now=max(now+d,b['window'][0]);load_route+=b['demand']
            if now>b['window'][1]+1e-9:issues.append('late_start')
            now+=b['service']
            inow=max(inow+e['transit_service_from_plus_travel'][prev][node],e['windows_inward'][node][0])
            assert inow<=e['windows_inward'][node][1]
            int_cost+=e['cost_matrix_nearest'][prev][node];prev=node
        back=math.hypot(n[prev]['x']-n[0]['x'],n[prev]['y']-n[0]['y']);dist+=back;now+=back
        if now>i['return_deadline']+1e-9:issues.append('late_depot')
        if load_route>i['capacity']:issues.append('overload')
        inow+=e['transit_service_from_plus_travel'][prev][0];assert inow<=e['return_deadline_scaled']
        int_cost+=e['cost_matrix_nearest'][prev][0]
    if sorted(seen)!=list(range(1,8)):issues.append('coverage_or_duplicate')
    assert not issues,(r['run_id'],issues)
    assert r['audit']['full_service_feasible'] and r['outcome']=='find'
    assert r['objective_integer']==int_cost
    err=abs(dist-int_cost/1e6);assert err<=4.5e-6+1e-12
    max_cost_error=max(max_cost_error,err)
    max_replay_distance_error=max(max_replay_distance_error,abs(dist-r['audit']['total_distance']))
    assert abs(dist-r['audit']['total_distance'])<1e-9
    optimum=O[r['instance']]['best_two_vehicle_by_served_mask'].get('127');assert optimum is not None
    assert dist>=optimum['distance']-1e-7
    checks+=1
frozen_input=hashlib.sha256((P/'inputs.json').read_bytes()).hexdigest()
assert frozen_input=='a899e22baf91e1435b8aca7af88c0107ea90a7439f257e4ba2bc55d2275af6bb'
out={'passed':True,'records_checked':len(R),'returned_solutions_independently_replayed':checks,'all_returned_solutions_valid_full':True,
     'original_input_sha256':frozen_input,'all_frozen_file_hashes_match':True,'max_integer_cost_vs_original_error':max_cost_error,
     'max_independent_replay_distance_difference':max_replay_distance_error,'cpu_s':time.process_time()-start,
     'limitations':'Verification checks witnesses and recorded gaps, not exhaustive OR-Tools optimality; original infeasibility labels come only from reference oracle.'}
(P/'verification.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
