VRPTW mature fixed solver benchmark, 2026-10-07
Start with report_zh.txt, then summary.json and verification.json.
96 requests = same48 instances x2 paired time budgets.33 original feasible cases are the ranking denominator.
All returned routes are mandatory-full-service and were rechecked on original continuous data.
Raw no-assignment is not a proof of original infeasibility. See reference oracle and independent audit.

Reproduction (new directory, same actual CPython3.12 environment):
1. Copy all files named in freeze.json plus freeze.json, reference/ and supervise.py to a NEW output directory. Do not copy results.jsonl or benchmark logs: the runner deliberately refuses overwrite/repeat.
2. python3.12 -m venv .venv
3. .venv/bin/python -m pip install --index-url https://pypi.org/simple --only-binary=:all: -r requirements.lock
4. .venv/bin/python -B supervise.py
5. .venv/bin/python -B analyze.py
6. .venv/bin/python -B verify.py
Do not run prepare again: existing input, request order, parameters, hashes and source were frozen before the reported run.
Wall-clock-limited local search can vary with host load even with identical seeds; compare original-unit feasibility/cost and preserve timings. This is a pinned3.12 environment lock, not a tested3.10 migration lock.
For a new preregistered study use a new directory and new study ID; never overwrite this run.

Artifact inventory:
inputs.json: byte-identical original48 inputs.
encoded_inputs.json: all integer matrices, windows and capacities sent to OR-Tools.
requests.json and parameters_*.textproto: all96 requests and every effective parameter.
experiment.py/checker.py/supervise.py/analyze.py/verify.py: benchmark, independent checker, budget supervisor and analysis sources.
results.jsonl: raw routes, integer cumul ranges, status, objective, independent original-unit schedules, wall/CPU timing.
evaluated_results.json/metrics.csv/summary.json: gap and pairwise descriptions.
map_backend.json: synthetic-coordinate visualization payload with status guards.
oracle_witness_encoding_diagnostic.json: post-run original-optimal-witness representability check only.
reference/: unchanged original data, solver source, oracle evidence and audit.
install.log/install_report.json/package_provenance.json/requirements.lock/environment.json: official package installation provenance.
failures.jsonl: retained pre-install launch failure; no solver retries.
resource_accounting.json/run_resource.json: budget and measured CPU evidence.
archive_manifest.json: every payload SHA256. archive.sha256 beside the ZIP verifies the ZIP itself.

ZIP excludes .venv, caches, installed third-party binaries, credentials and unrelated files.
No external upload or publication was performed for this task.
