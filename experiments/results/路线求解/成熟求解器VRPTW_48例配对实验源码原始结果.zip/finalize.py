import json,hashlib,time,resource,zipfile,shutil,csv
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CPU,(4,5));start=time.process_time()
P=Path(__file__).resolve().parent
load=lambda n:json.loads((P/n).read_text())
def write(n,x):(P/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
s=load('summary.json');v=load('verification.json');run=load('run_resource.json');inst=load('install_resource.json');R=load('evaluated_results.json')
# Source provenance only; these copies are never used by the mature solver.
for src,dst in [('/workspace/shared/vrp_time_windows_20261007/experiment.py','reference/original_experiment.py'),('/workspace/shared/audit_vrp_time_windows_20261007/independent_check.py','reference/independent_audit_check.py')]:
    shutil.copyfile(src,P/dst)
metrics=[]
for r in R:
    a=r.get('audit') or {}
    metrics.append({'instance':r['instance'],'budget_ms':r['budget_ms'],'outcome':r['outcome'],'ortools_status':r.get('ortools_status_name'),
    'reference_oracle_feasible':r['reference_oracle_full_feasible'],'full_service':a.get('full_service_feasible',False),
    'continuous_distance':a.get('total_distance'),'full_gap_percent':r['full_gap_original_percent'],
    'solve_wall_s':r.get('solve_wall_s'),'solve_cpu_s':r.get('solve_cpu_s'),'objective_integer':r.get('objective_integer')})
with (P/'metrics.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(metrics[0]));w.writeheader();w.writerows(metrics)
input_data=load('inputs.json');by={(r['instance'],r['budget_ms']):r for r in R}
write('map_backend.json',{'schema':'vrptw-mature-solver-v1','synthetic_coordinates':True,'distance_time_units':'Arbitrary Euclidean units; speed1; not real latitude/longitude, road travel or traffic',
 'source_input_sha256':v['original_input_sha256'],'display_guard':'Only outcome=find and audit.full_service_feasible=true may display as completed; null routes are not successful empty routes. Original infeasibility label is separately sourced.',
 'instances':[{'input':i,'reference_oracle_full_feasible':s['original_oracle_feasible_n']>0 and by[i['id'],250]['reference_oracle_full_feasible'],
  'runs':[by[i['id'],ms] for ms in [250,1000]]} for i in input_data]})
g12=next(r for r in R if r['instance']=='G12_tight' and r['budget_ms']==250)
short=s['budgets']['250'];long=s['budgets']['1000']
report=f'''成熟固定求解器补全 CVRPTW 漏服务：48例配对实验

结论
同一批48例、原窗口与全服务目标均未改动。固定 OR-Tools 9.14.6206 在250毫秒和1000毫秒两档预算下，都在33/33个原oracle可行实例返回完整可行路线；按原连续数据独立重算，全部与原精确最优距离相符（1e-7容差，平均gap约0%，n=33/档）。两预算共同33例成本全部打平，当前样本未体现延长预算的额外收益。
15例原oracle真无解在每档均无返回方案，原始状态均为ROUTING_FAIL。它不是本报告中对原连续问题的无解证明；无解结论只引用已有精确枚举oracle及其独审。两档均保留48条记录，未以15例无解降低算法排名分母；两预算也不是96个独立样本。

关键漏服务已补上
G12_tight：两档均得到路线0→5→1→7→4→0，以及0→6→2→3→0，总距离{g12['audit']['total_distance']:.10f}，原单位gap约0%。原距离优先只能服务6/7、时间窗优先只能服务5/7；本次均7/7且无迟到、超载或返仓超时。
原距离优先27/33，本次33/33，补上6例；原时间窗优先31/33，本次33/33，补上2例。没有反向损失。
共同完成的27例中，相比距离优先，成熟求解器成本更低14例、持平13例；共同31例中，相比时间窗优先，成本更低18例、持平13例。共同样本的原启发式平均gap分别8.514%和6.572%，本次均约0%。这是本批样本描述，非普遍优势证明。

冻结与模型
本次实际运行环境：dot云端Linux，CPython3.12.14，OR-Tools9.14.6206；未在用户Ubuntu22.04/Python3.10实测。官方PyPI元数据Requires-Python>=3.9仅说明包级兼容声明，不能替代迁移验收。本次从官方PyPI安装，完整依赖版本、wheel来源及SHA256已保留。
求解前冻结同48输入、源码、完整参数和96请求顺序；无试跑、无按结果调参、无失败补跑、无warm start，未向求解器注入oracle路线。固定PATH_CHEAPEST_ARC初解、GUIDED_LOCAL_SEARCH、lambda0.1、seed2026100707、单CP搜索线程，CP-SAT及其fallback均关闭。每例两预算相邻，按输入序号交替250/1000与1000/250先后顺序。
必须服务全部7个点，2车每车容量6；0时出发、允许等待、服务时长2、开始服务时刻落在含端点时间窗、120前返仓。只最小化路长，没有可丢点罚金、车辆固定成本或时间跨度成本。

整数编码与原连续复核
scale=1,000,000。原3位小数坐标先精确转为千分整数，距离缩放用整数平方根及精确中点比较。cost四舍五入，每弧误差≤0.5e-6；全服务最多9弧，总误差≤4.5e-6原距离单位。
旅行时间向上取整，服务时间可精确缩放；窗口下界向上、上界向下，保持保守。每段旅行增加<1e-6时间；固定m站路线最早服务时刻累计偏移<(m+1)e-6、返仓<(m+2)e-6，上界另收紧<1e-6。保守舍入可能排除原边界可行解，不能将整数无解直接解释为原问题无解。
本次66个返回方案全部由原checker及另一份独立重放实现按原坐标、原窗口、原需求重算；66/66为全服务可行，未将编码可行自动当作原连续可行。实测整数cost与原距离最大差{v['max_integer_cost_vs_original_error']:.12g}，小于上界。原oracle的33个最优见证在本编码中也全部仍可行；这是求解结束后的诊断，未反馈调参。它不意味着任意边界路线都不会被排除。
浮点gap保留原值，微小正负数约±2.23e-14%视为数值误差；展示约0%。原oracle最优性沿用原枚举与独审证据，本次不宣称OR-Tools状态提供连续全局最优证明。

预算与时间
250毫秒档：48例总求解CPU {short['solver_cpu_s_sum']:.3f}秒，平均wall {short['solver_wall_s_all']['mean']:.4f}秒/例；33个可行例平均wall {short['solver_wall_s_feasible']['mean']:.4f}秒/例。
1000毫秒档：48例总求解CPU {long['solver_cpu_s_sum']:.3f}秒，平均wall {long['solver_wall_s_all']['mean']:.4f}秒/例；33个可行例平均wall {long['solver_wall_s_feasible']['mean']:.4f}秒/例。
两档完整工作进程（含导入、校验、模型与输出）实测{run['child_cpu_total_s']:.3f}CPU秒；安装实测{inst['cpu_user_s']+inst['cpu_system_s']:.3f}CPU秒，合计{run['child_cpu_total_s']+inst['cpu_user_s']+inst['cpu_system_s']:.3f}CPU秒，加轻量监督、分析、验证和归档后仍远低180秒。完整资源台账见resource_accounting.json。
每次参数是搜索wall时限而非精确CPU时限，返回与回调有约毫秒级超调，实际最大分别{short['solver_wall_s_all']['max']:.6f}和{long['solver_wall_s_all']['max']:.6f}秒。工作进程另有110CPU秒硬限，未触发。统计不是速度优势检验；启发式原计时与成熟求解器预算不同，不能只凭时间表排名。
安装启动曾因/usr/bin/time不存在而未执行；随后用Python资源计量器正常安装，原失败已留存。求解/校验无失败，96请求只执行一次。

可用于首版展示的含义与边界
本批7任务小实例上，成熟固定求解器可作为比两种构造启发式更强的全服务路线基线，特别是G12紧窗的正确完整路线。map_backend.json可直接供约束/路线展示，原始路线、逐站时间和状态均保留；null路线必须显示未找到，不能伪装成空路线成功。
仍是16组几何派生的48个相关合成实例，窗口靠近固定编号见证，有生成偏置；不是48个独立真实业务样本。没有道路网络、实时交通、多目标、规模扩展或用户机器迁移证据。250毫秒在这批样本足够，不代表更大规模保证。

主要证据
protocol.json / freeze.json：设计与事前冻结；requests.json / parameters_*：所有请求与固定配置。
results.jsonl：全部96条原始返回；evaluated_results.json / metrics.csv：原单位评分；verification.json：66方案全量独立校验。
reference/：原输入、原结果、oracle表、原实验源码和独审依据；没有重新优化或修改原目录。
package_provenance.json / requirements.lock / environment.json：官方来源、版本和本次实际环境。

官方资料
https://developers.google.com/optimization/install/python
https://pypi.org/project/ortools/9.14.6206/
https://developers.google.com/optimization/routing/vrptw
https://developers.google.com/optimization/routing/routing_options
'''
(P/'report_zh.txt').write_text(report)
(P/'README.txt').write_text('''VRPTW mature fixed solver benchmark, 2026-10-07
Start with report_zh.txt, then summary.json and verification.json.
96 requests = same48 instances x2 paired time budgets.33 original feasible cases are the ranking denominator.
All returned routes are mandatory-full-service and were rechecked on original continuous data.
Raw no-assignment is not a proof of original infeasibility. See reference oracle and independent audit.

Reproduction (new directory, same actual CPython3.12 environment):
1. Copy all files named in freeze.json plus freeze.json, reference/ and supervise.py to a NEW output directory. Do not copy results.jsonl or benchmark logs: the runner deliberately refuses overwrite/repeat.
2. python3.12 -m venv .venv
3. .venv/bin/python -m pip install --index-url https://pypi.org/simple --only-binary=:all: -r requirements.lock
4. .venv/bin/python -B supervise.py
5. .venv/bin/python -B analyze.py
6. .venv/bin/python -B verify.py
Do not run prepare again: existing input, request order, parameters, hashes and source were frozen before the reported run.
Wall-clock-limited local search can vary with host load even with identical seeds; compare original-unit feasibility/cost and preserve timings. This is a pinned3.12 environment lock, not a tested3.10 migration lock.
For a new preregistered study use a new directory and new study ID; never overwrite this run.

Artifact inventory:
inputs.json: byte-identical original48 inputs.
encoded_inputs.json: all integer matrices, windows and capacities sent to OR-Tools.
requests.json and parameters_*.textproto: all96 requests and every effective parameter.
experiment.py/checker.py/supervise.py/analyze.py/verify.py: benchmark, independent checker, budget supervisor and analysis sources.
results.jsonl: raw routes, integer cumul ranges, status, objective, independent original-unit schedules, wall/CPU timing.
evaluated_results.json/metrics.csv/summary.json: gap and pairwise descriptions.
map_backend.json: synthetic-coordinate visualization payload with status guards.
oracle_witness_encoding_diagnostic.json: post-run original-optimal-witness representability check only.
reference/: unchanged original data, solver source, oracle evidence and audit.
install.log/install_report.json/package_provenance.json/requirements.lock/environment.json: official package installation provenance.
failures.jsonl: retained pre-install launch failure; no solver retries.
resource_accounting.json/run_resource.json: budget and measured CPU evidence.
archive_manifest.json: every payload SHA256. archive.sha256 beside the ZIP verifies the ZIP itself.

ZIP excludes .venv, caches, installed third-party binaries, credentials and unrelated files.
No external upload or publication was performed for this task.
''')
measured=inst['cpu_user_s']+inst['cpu_system_s']+run['child_cpu_total_s']+run['supervisor_cpu_s']+s['analysis_cpu_s']+v['cpu_s']
resource_report={'cpu_budget_s':180,'installation_subprocess_cpu_s':inst['cpu_user_s']+inst['cpu_system_s'],'benchmark_whole_child_cpu_s':run['child_cpu_total_s'],'benchmark_supervisor_cpu_s':run['supervisor_cpu_s'],'analysis_script_internal_cpu_s':s['analysis_cpu_s'],'independent_verification_internal_cpu_s':v['cpu_s'],
  'measured_subtotal_before_finalization_s':measured,'benchmark_hard_cpu_s':110,'supervisor_hard_cpu_s':5,'analysis_hard_cpu_s':10,'verification_hard_cpu_s':10,'finalization_hard_cpu_s':5,
  'conservative_accounting_envelope_s':170,
  'accounting_envelope_definition':'Installation actual7.773 + benchmark hard110 + supervisor hard5 + analysis hard10 + verification hard10 + finalization hard5 + reserved22.227 for preparation, small metadata shell reads, imports and failed launcher =170, below180. Preparation/coordination were not individually instrumented;170 is a conservative allowance envelope, NOT an OS-enforced global sum or a fully measured total.',
  'solver_calls':96,'repeated_solver_calls':0,'solver_errors':sum(r['outcome']=='error' for r in R),'solver_timeouts':sum(r['outcome']=='timeout_no_assignment' for r in R),
  'observed_task_compute_below_budget':True,'paid_api_calls':0,'codex_tasks':0,'network_in_solver':False}
resource_report['finalization_cpu_s_before_archive']=time.process_time()-start
write('resource_accounting.json',resource_report)
files=sorted(f for f in P.rglob('*') if f.is_file() and '.venv' not in f.parts and '__pycache__' not in f.parts and f.name not in ['archive_manifest.json','archive.sha256','finalization_complete.json'] and f.suffix!='.zip')
manifest={'study_id':'VRPTW_MATURE_SOLVER_20261007_FIXED_V1','files':[{ 'path':str(f.relative_to(P)),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in files]}
write('archive_manifest.json',manifest)
zpath=P/'vrptw_mature_solver_20261007.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED) as z:
    for f in files+[P/'archive_manifest.json']:z.write(f,f.relative_to(P))
with zipfile.ZipFile(zpath) as z:
    assert z.testzip() is None
    for f in manifest['files']:assert hashlib.sha256(z.read(f['path'])).hexdigest()==f['sha256']
archive_sha=hashlib.sha256(zpath.read_bytes()).hexdigest();(P/'archive.sha256').write_text(archive_sha+'  '+zpath.name+'\n')
complete={'zip':zpath.name,'bytes':zpath.stat().st_size,'sha256':archive_sha,'payload_files':len(files)+1,'archive_verified':True,'finalization_cpu_s_including_archive':time.process_time()-start,'measured_total_including_finalization_s':measured+time.process_time()-start,'note':'Finalization completion receipt intentionally outside ZIP; no circular self-hash.'}
write('finalization_complete.json',complete);print(json.dumps(complete,indent=2))
