import sys,time,resource,signal,statistics as st,collections,csv,math
sys.dont_write_bytecode=True
resource.setrlimit(resource.RLIMIT_CPU,(10,10));resource.setrlimit(resource.RLIMIT_AS,(256*1024**2,256*1024**2));signal.alarm(10)
C=time.process_time_ns();W=time.perf_counter_ns()
from common import *
assert read(ROOT/'provenance/RAW_ARCHIVE_VERIFIED.json')['verified'] is True
f=verify_freeze();protocol=read(ROOT/'freeze/PROTOCOL.json');schedule=read(ROOT/'freeze/SCHEDULE.json')
def dist(xs):
 if not xs:return None
 q=st.quantiles(xs,n=4,method='inclusive') if len(xs)>1 else [xs[0]]*3
 return {'n':len(xs),'sum':sum(xs),'mean':st.mean(xs),'median':st.median(xs),'min':min(xs),'max':max(xs),'p25':q[0],'p75':q[2],'sd':st.stdev(xs) if len(xs)>1 else 0}
def writecsv(name,rows):
 if rows:
  with (ROOT/'reports'/name).open('x',newline='') as h:
   w=csv.DictWriter(h,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
expected={b['batch_id']+'-'+i+f'-P{r:02d}':(b,i,r) for b in schedule for i in b['instance_order'] for r in range(b['repetitions'])}
seen=collections.Counter();bad=[];drifts=[];invalid=[];mutations=[];derived_errors=[];first={};seconds=collections.defaultdict(list);phasecounts=collections.Counter();signs=collections.defaultdict(set)
for line in (ROOT/'raw/calls.jsonl').open():
 r=json.loads(line);cid=r['call_id'];seen[cid]+=1;phasecounts[r['phase']]+=1
 if cid not in expected:bad.append(cid)
 else:
  b,i,p=expected[cid]
  if (r['instance_id'],r['repetition'],r['phase'],r['round'],r['arm'])!=(i,p,b['phase'],b['round'],b['arm']):bad.append(cid)
 if r['functional_signature']!=r['reference_signature']:drifts.append(cid)
 if r['status']=='SUCCESS' and not r['checker']['accepted']:invalid.append(cid)
 if not r['input_unchanged']:mutations.append(cid)
 r['diagnostic']=r['non_time_diagnostic']
 if signature(r)!=r['functional_signature']:derived_errors.append(cid)
 key=(r['instance_id'],r['arm']);signs[key].add(r['functional_signature'])
 if key not in first:first[key]=r
 if r['phase']=='timed':seconds[(r['instance_id'],r['arm'],r['round'])].append(r['algorithm_wall_ns'])
parts=[json.loads(x) for x in (ROOT/'raw/partitions.jsonl').read_text().splitlines()]
pindex={(r['instance_id'],r['arm']):r for r in parts}
partbad=[r['instance_id']+':'+r['arm'] for r in parts if r['functional_signature']!=r['reference_signature'] or signature(r)!=r['functional_signature'] or not r['input_unchanged'] or not r['assignment_valid']]
ids=sorted({i for i,a in first});inputs={i:read(ROOT/'input'/f'{i}.json') for i in ids}
functional_rows=[];accountingbad=[]
for i in ids:
 for endpoint,idx in [('initialize',first),('partition',pindex)]:
  a=idx[(i,'waste_solver')];b=idx[(i,'gated_solver')]
  x=a['diagnostic'];y=b['diagnostic']
  if endpoint=='initialize':x=(x or{}).get('capacity_partition');y=(y or{}).get('capacity_partition')
  orig_checks=(x or{}).get('waste_checks',0);new_checks=(y or{}).get('waste_checks',0)
  orig_res=(x or{}).get('residual_checks',0);new_res=(y or{}).get('residual_checks',0)
  skips=orig_checks-new_checks
  if skips<0 or orig_res-new_res!=skips*inputs[i]['K']:accountingbad.append((endpoint,i))
  functional_rows.append({'endpoint':endpoint,'instance_id':i,'family':inputs[i]['family'],'status':a['status'],'paired_signature_equal':a['functional_signature']==b['functional_signature'],'nodes':(x or{}).get('nodes',0),'prunes':(x or{}).get('prunes',0),'original_waste_checks':orig_checks,'gated_waste_checks':new_checks,'gate_skips':skips,'original_residual_checks':orig_res,'gated_residual_checks':new_res,'saved_residual_checks':orig_res-new_res})
writecsv('FUNCTIONAL_PER_INSTANCE.csv',functional_rows)
bs=[json.loads(x) for x in (ROOT/'raw/batches.jsonl').read_text().splitlines()];timed=[b for b in bs if b['phase']=='timed'];bindex={(b['round'],b['arm']):b for b in timed}
writecsv('PANEL_BATCHES.csv',bs)
ticks=read(ROOT/'raw/CPU_CLOCK_TICKS.json');jumps=[b-a for a,b in zip(ticks,ticks[1:]) if b>a]
cal=read(ROOT/'raw/CLOCK_BRACKETS.json');positive=[r['cpu_ns'] for r in cal if r['cpu_ns']>0]
quantum=max(4_000_000,st.median(jumps+positive) if jumps+positive else 4_000_000)
# Frozen conservative observability rule: all ten timed batches >=100 effective quanta.
clock_eligible=len(timed)==10 and all(b['completed_calls']==384 and b['wrapper_inclusive_panel_cpu_ns']>=100*quantum for b in timed)
wall_eligible=len(timed)==10 and all(b['completed_calls']==384 and b['wrapper_inclusive_panel_wall_ns']>0 for b in timed)
roundrows=[]
for rnd in range(1,6):
 if any((rnd,a) not in bindex for a in ARMS):continue
 x=bindex[(rnd,'waste_solver')];y=bindex[(rnd,'gated_solver')]
 roundrows.append({'round':rnd,'original_cpu_ns':x['wrapper_inclusive_panel_cpu_ns'],'gated_cpu_ns':y['wrapper_inclusive_panel_cpu_ns'],'cpu_ratio':y['wrapper_inclusive_panel_cpu_ns']/x['wrapper_inclusive_panel_cpu_ns'] if clock_eligible else None,'original_wall_ns':x['wrapper_inclusive_panel_wall_ns'],'gated_wall_ns':y['wrapper_inclusive_panel_wall_ns'],'wall_ratio':y['wrapper_inclusive_panel_wall_ns']/x['wrapper_inclusive_panel_wall_ns'] if wall_eligible else None})
writecsv('PAIRED_ROUNDS.csv',roundrows)
wallrows=[]
for i in ids:
 ratios=[]
 for rnd in range(1,6):
  x=seconds[(i,'waste_solver',rnd)];y=seconds[(i,'gated_solver',rnd)]
  if len(x)==len(y)==8 and min(x+y)>0:ratios.append(sum(y)/sum(x))
 wallrows.append({'instance_id':i,'family':inputs[i]['family'],'rounds':len(ratios),'ratios':json.dumps(ratios),'median_ratio':st.median(ratios) if len(ratios)==5 else None})
writecsv('SECONDARY_INSTANCE_WALL.csv',wallrows)
finish=read(ROOT/'raw/FINISHED.json');wf=read(ROOT/'raw/WORKER_FINISHED.json');toy=read(ROOT/'raw/TOY_FINISHED.json')
old=read(ROOT/'provenance/OLD_FILES_BEFORE.json')
oldchanges=[p for p,h in old.items() if sha(SOURCE/p)!=h]
batchbad=[]
for x,b in zip(bs,schedule):
 if any(x[k]!=b[k] for k in ['batch_id','phase','round','arm']) or x['completed_calls']!=48*b['repetitions']:batchbad.append(x['batch_id'])
checks={'calls_complete':not(set(expected)-set(seen)) and len(seen)==3936 and all(v==1 for v in seen.values()),'schedule_metadata':not bad,'phase_counts':dict(phasecounts)=={'warmup':96,'timed':3840},'batches_complete':len(bs)==12 and not batchbad,'all_outputs_and_semantic_diagnostics_match_reference':not drifts,'no_success_invalid':not invalid,'inputs_unchanged':not mutations,'signatures_recomputed':not derived_errors,'repeat_determinism':all(len(v)==1 for v in signs.values()),'all96_partitions_match_reference':len(parts)==96 and len(pindex)==96 and not partbad,'scan_accounting_exact':not accountingbad,'toy7140_pass':toy['states']==7140 and toy['decision_mismatches']==0 and toy['false_prunes']==0,'old_tree_unchanged':not oldchanges,'normal_finish':finish['returncode']==0 and not finish['timeout'] and wf['complete'],'source_exactly_two_lines_added':(ROOT/'source/solvers/gated_solver.py').read_text().replace('    if slack >= len(residual) * (smallest - 1):\n        return False, False, 0\n','')==(ROOT/'source/solvers/waste_solver.py').read_text()}
summary={'namespace':protocol['namespace'],'scientific_units':48,'timed_calls':3840,'warmup_calls':96,'direct_partition_calls':96,'toy':toy,'functional':{},'clocks':{'effective_quantum_ns':quantum,'clock_tick_positive_jumps':dist(jumps),'empty_positive_cpu_readings':dist(positive),'empty_zero_cpu':sum(r['cpu_ns']==0 for r in cal),'cpu_eligible':clock_eligible,'wall_eligible':wall_eligible,'observability_rule':'All10batches>=100*max(prior4ms,median positive observed CPU increments); descriptive batch-level estimate only.'},'timing':{},'paired_rounds':roundrows,'secondary_instance_wall_ratio_medians':dist([r['median_ratio'] for r in wallrows if r['median_ratio'] is not None]),'caveats':['Same artificial48instances; timing repetitions are not new generalization samples.','Comparison is gated newbound versus original newbound, not original baseline.','Full initializer wrapper-inclusive batches include Python loops, snapshot, retained diagnostic objects, GC, and per-call wall reads; exclude external checker, hash, serialization and disk I/O.','No claim about exact per-call CPU; underlying process clock remains quantized.','Only waste_checks and residual_checks intentionally differ; search semantics, exact output, node visits and prune traces must match.','No confidence intervals, p-values, selected rounds, reruns or baseline-speedup claims.']}
for endpoint in ['initialize','partition']:
 fr=[r for r in functional_rows if r['endpoint']==endpoint]
 summary['functional'][endpoint]={'statuses':dict(collections.Counter(r['status'] for r in fr)),'identical_instances':sum(r['paired_signature_equal'] for r in fr),'nodes':sum(r['nodes'] for r in fr),'prunes':sum(r['prunes'] for r in fr),'original_waste_checks':sum(r['original_waste_checks'] for r in fr),'gated_waste_checks':sum(r['gated_waste_checks'] for r in fr),'gate_skips':sum(r['gate_skips'] for r in fr),'saved_residual_checks':sum(r['saved_residual_checks'] for r in fr),'gate_skip_instances':sum(r['gate_skips']>0 for r in fr)}
for clock,eligible in [('cpu',clock_eligible),('wall',wall_eligible)]:
 totals={a:sum(r['wrapper_inclusive_panel_'+clock+'_ns'] for r in timed if r['arm']==a) for a in ARMS}
 ratios=[r[clock+'_ratio'] for r in roundrows if r[clock+'_ratio'] is not None]
 summary['timing'][clock]={'raw_total_ns':totals,'eligible':eligible,'gated_over_original_ratio':totals['gated_solver']/totals['waste_solver'] if eligible else None,'paired_ratio_distribution':dist(ratios),'ns_per_complete_initializer_including_failures':{a:totals[a]/1920 for a in ARMS} if eligible else None}
summary['resources']={'execution_cpu_seconds':finish['child_cpu_seconds']+finish['supervisor_cpu_ns']/1e9,'execution_wall_seconds':finish['elapsed_ns']/1e9,'analysis_cpu_seconds':(time.process_time_ns()-C)/1e9,'analysis_wall_seconds':(time.perf_counter_ns()-W)/1e9,'analysis_peakrss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'worker_peakrss_KiB':finish['child_peakrss_KiB'],'supervisor_peakrss_KiB':finish['supervisor_peakrss_KiB'],'limit_envelope':'CPU100+5+10=115s<120s; wall220+10=230s<240s; concurrent worker768MiB+supervisor128MiB<=896MiB address space; analysis256MiB sequential'}
checks['resources_ok']=summary['resources']['execution_cpu_seconds']+summary['resources']['analysis_cpu_seconds']<120 and summary['resources']['execution_wall_seconds']+summary['resources']['analysis_wall_seconds']<240 and finish['child_peakrss_KiB']+finish['supervisor_peakrss_KiB']<1024**2 and resource.getrusage(resource.RUSAGE_SELF).ru_maxrss<1024**2
audit={'passed':all(checks.values()),'checks':checks,'drift_calls':drifts,'invalid_successes':invalid,'partition_mismatches':partbad,'old_tree_changes':oldchanges,'bad_scan_accounting':accountingbad,'missing_calls':sorted(set(expected)-set(seen))}
dump(ROOT/'reports/SUMMARY.json',summary);dump(ROOT/'reports/AUDIT.json',audit)
cp=summary['timing']['cpu']['gated_over_original_ratio'];wp=summary['timing']['wall']['gated_over_original_ratio'];fct=summary['functional']['initialize'];pct=summary['functional']['partition']
report=f'''容量必要界快速跳过：单候选固定面板实验\n\n审计：{'PASS' if audit['passed'] else 'FAIL'}（自动化自审；外部复核另存）。\n只增加 U >= K*(m-1) 的两行短路，无模型调用，无新实例，无性能筛选。\n\n数学依据：非负整数 residual 中任何 0<r<m 项最多 m-1，至多 K 项，故 W<=K*(m-1)。若 U>=此上界，则 W>U 必为假，跳过求和保留精确剪枝决策。m=1 时所有正整数 residual 不满足 r<m。所有48输入非负整数；递归只作整数需求扣除/回退。浮点输入不在验证或承诺域内。\n\n功能结果：初始化 {fct['statuses']}，两臂48/48完全一致；总访问 {fct['nodes']} 节点、{fct['prunes']} 剪枝一致。直接分区 {pct['statuses']}，48/48结果及非计时语义一致。7140预定小状态判定差异0、可行状态误剪0。诊断计数 waste_checks/residual_checks 因省略求和而有预期差异，节点、剪枝trace、结果、预算非计时计数无差异。\n初始化每48面板跳过 {fct['gate_skips']} 次求和，少检查 {fct['saved_residual_checks']} 个残余容量；直接分区分别 {pct['gate_skips']} 和 {pct['saved_residual_checks']}。高slack族初始化常由前置算法完成，不能把直接分区收益当作初始化收益。\n\n计时：5轮，每臂每轮48输入×8次，共3840计时调用；96预定热身不计入主比较；同轮同实例顺序，两臂顺序固定预生成。主单位为整板384次连续调用，单例只有次级wall，不报告单例CPU。\nCPU gate/original比：{cp if cp is not None else '不可估：不满足预定整板量化阈值'}。\nwall gate/original比：{wp if wp is not None else '不可估'}。\n每轮和全量原始读数见PAIRED_ROUNDS.csv及raw/batches.jsonl。不丢轮，不重跑。CPU有效量化评估约{quantum/1e6:.3f}ms；整板达到阈值仍仅支持描述性估计，不等于精确CPU成本或统计显著加速。\n\n单位成本：两臂完整initialize路径（包括失败）每次平均整板CPU/wall成本=整板累计时间/1920。包含循环、Budget快照、结果缓冲、诊断对象保留、GC及单次wall读取；不包含外部验证、hash、JSON、落盘。不是仅W求和的微基准，也不是baseline比较。\n\n局限：固定48个人工结构，重复是计时技术重复，无新泛化证据。候选仅一个，旧三臂源码及结果保持只读。历史实验证据不被新结果替代。进程时钟量化、缓存、系统调度及Python封装可能主导小差异，不能据此声称整体算法恢复baseline速度。\n'''
(ROOT/'reports/REPORT_ZH.txt').write_text(report)
print(json.dumps({'audit_passed':audit['passed'],'functional':summary['functional'],'timing':summary['timing'],'resources':summary['resources']},ensure_ascii=False))
