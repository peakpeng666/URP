import sys,time,os,resource,signal,importlib,itertools,gc,platform
sys.dont_write_bytecode=True
ENTRY_C=time.process_time_ns();ENTRY_W=time.perf_counter_ns()
resource.setrlimit(resource.RLIMIT_CPU,(95,100));resource.setrlimit(resource.RLIMIT_AS,(768*1024**2,768*1024**2))
from common import *
class StageStop(BaseException):pass
stop_requested=None;active_call=False
def stop(signum,frame):
 global stop_requested
 stop_requested='signal_'+str(signum)
 if active_call:raise StageStop(stop_requested)
signal.signal(signal.SIGXCPU,stop);signal.signal(signal.SIGALRM,stop);signal.setitimer(signal.ITIMER_REAL,215)
f=verify_freeze();protocol=read(ROOT/'freeze/PROTOCOL.json');schedule=read(ROOT/'freeze/SCHEDULE.json')
receipt=read(ROOT/'provenance/PREEXEC_ARCHIVE_VERIFIED.json')
assert receipt['verified'] is True
assert receipt['preexecution_zip_sha256']==sha(ROOT.parent/'capacity_bound_fast_gate_20261008_PREEXECUTION_SNAPSHOT.zip')
sys.path.insert(0,str(ROOT/'source/solvers'))
mods={a:importlib.import_module(a) for a in ARMS}
from audit import check
inputs={p.stem:read(p) for p in sorted((ROOT/'input').glob('*.json'))}
input_digests={i:digest(v) for i,v in inputs.items()}
refs={r['instance_id']:r for r in read(ROOT/'provenance/REFERENCE_INITIALIZE.json')}
partrefs={r['instance_id']:r for r in read(ROOT/'provenance/REFERENCE_PARTITION.json')}
for m in mods.values():assert m.CAPACITY_NODE_LIMIT==256
for raw in inputs.values():
 assert type(raw['capacity']) is int and raw['capacity']>0 and type(raw['K']) is int and raw['K']>0
 assert all(type(x) is int and x>=0 for x in raw['demands']) and raw['demands'][0]==0
meta={'utc':utc(),'pid':os.getpid(),'cpu_limit':resource.getrlimit(resource.RLIMIT_CPU),'address_space_limit':resource.getrlimit(resource.RLIMIT_AS),'python':sys.version,'platform':platform.platform(),'gc_enabled':gc.isenabled(),'gc_threshold':gc.get_threshold(),'clocks':{k:vars(time.get_clock_info(k)) for k in ['process_time','perf_counter']},'freeze_sha256':sha(ROOT/'freeze/PRE_RUN_FREEZE.json')}
dump(ROOT/'raw/WORKER_STARTED.json',meta)
cal=[]
for _ in range(1000):
 c=time.process_time_ns();w=time.perf_counter_ns();ew=time.perf_counter_ns();ec=time.process_time_ns();cal.append({'cpu_ns':ec-c,'wall_ns':ew-w})
dump(ROOT/'raw/CLOCK_BRACKETS.json',cal)
ticks=[time.process_time_ns() for _ in range(10000)]
dump(ROOT/'raw/CPU_CLOCK_TICKS.json',ticks)

def feasible(remaining,residual):
 ds=sorted((x for x in remaining if x),reverse=True)
 def visit(i,rooms):
  if i==len(ds):return True
  seen=set()
  for j,r in enumerate(rooms):
   if r in seen:continue
   seen.add(r)
   if r>=ds[i]:
    nxt=rooms[:];nxt[j]-=ds[i]
    if visit(i+1,nxt):return True
  return False
 return visit(0,list(residual))

# Predeclared Cartesian domain, 84 residual vectors x 85 demand vectors = 7140 states.
state_count=mismatches=false_prunes=gate_skips=0
with (ROOT/'raw/toy_states.jsonl').open('x') as h:
 for K in range(1,4):
  for residual in itertools.product(range(4),repeat=K):
   for n in range(4):
    for rem in itertools.product(range(4),repeat=n):
     if stop_requested:raise StageStop(stop_requested)
     a=mods['waste_solver'].waste_capacity_test(rem,residual)
     b=mods['gated_solver'].waste_capacity_test(rem,residual)
     can=feasible(rem,residual);state_count+=1
     mismatches+=a[0]!=b[0];false_prunes+=bool(b[0] and can);gate_skips+=bool(a[1] and not b[1])
     h.write(json.dumps({'state_id':state_count,'remaining':rem,'residual':residual,'original':a,'gated':b,'feasible_exhaustive':can},allow_nan=False)+'\n')
 h.flush();os.fsync(h.fileno())
dump(ROOT/'raw/TOY_FINISHED.json',{'states':state_count,'decision_mismatches':mismatches,'false_prunes':false_prunes,'gate_skips':gate_skips})
assert state_count==7140 and not mismatches and not false_prunes

# Functional direct-partition endpoint, once per input and arm, not a timing comparison.
with (ROOT/'raw/partitions.jsonl').open('x') as h:
 for i,raw in inputs.items():
  for a in ARMS:
   if stop_requested:raise StageStop(stop_requested)
   groups,diag=mods[a].bounded_partition(raw['demands'],raw['capacity'],raw['K'],256)
   r={'instance_id':i,'arm':a,'groups':groups,'diagnostic':diag,'status':'SUCCESS' if groups is not None else diag['outcome']}
   r['functional_signature']=signature(r);r['reference_signature']=signature(partrefs[i]);r['input_unchanged']=digest(raw)==input_digests[i]
   r['assignment_valid']=groups is None or (sorted(j for b in groups for j in b)==list(range(1,len(raw['demands']))) and len(groups)<=raw['K'] and all(sum(raw['demands'][j] for j in b)<=raw['capacity'] for b in groups))
   h.write(json.dumps(r,allow_nan=False)+'\n')
 h.flush();os.fsync(h.fileno())

def invoke(raw,mod):
 global active_call
 out=diag=budget=None;error=None;status='ERROR';abort=False
 active_call=True;w=time.perf_counter_ns()
 try:
  inst=mod.instance_for(raw);budget=mod.Budget(100000,1,2)
  matrix=mod.matrix_for(inst,budget)
  routes,cost,diag=mod.initialize(raw,inst,matrix,budget)
  out=mod.output_for(routes,cost);status='SUCCESS'
 except mod.InitFailure as e:diag=getattr(e,'detail',None);status='INITFAIL';error={'type':type(e).__name__,'message':str(e)}
 except mod.StopBudget as e:status='BUDGET';error={'type':type(e).__name__,'message':str(e)}
 except StageStop as e:status='STAGE_BUDGET';error={'type':type(e).__name__,'message':str(e)};abort=True
 except Exception as e:status='ERROR';error={'type':type(e).__name__,'message':str(e)}
 wall=time.perf_counter_ns()-w;active_call=False
 usage=budget.snapshot() if budget is not None else None
 return {'status':status,'output':out,'diagnostic':diag,'budget':usage,'error':error,'stage_abort':abort,'algorithm_wall_ns':wall}

counts={'warmup':0,'timed':0};batches_done=0;reason=None;active=None;buffer=[];batch_saved=True;saved_records=0
with (ROOT/'raw/calls.jsonl').open('x') as h,(ROOT/'raw/batches.jsonl').open('x') as g:
 try:
  for batch in schedule:
   if stop_requested:reason=stop_requested;break
   active=batch;buffer=[];batch_saved=False;saved_records=0
   c=time.process_time_ns();w=time.perf_counter_ns()
   for i in batch['instance_order']:
    for rep in range(batch['repetitions']):
     if stop_requested:break
     r=invoke(inputs[i],mods[batch['arm']]);buffer.append((i,rep,r))
     if r['stage_abort']:break
    if stop_requested:break
   wall=time.perf_counter_ns()-w;cpu=time.process_time_ns()-c
   # Validation, signatures and durable JSON writes all outside the full-panel timer.
   for i,rep,r in buffer:
    raw=inputs[i];r['functional_signature']=signature(r);r['reference_signature']=signature(refs[i]);r['non_time_diagnostic']=strip_time(r.pop('diagnostic'))
    r['input_unchanged']=digest(raw)==input_digests[i]
    r['checker']=check(raw,r['output'],raw['K']) if r['output'] is not None else {'accepted':False,'errors':['no_output']}
    r.update({'call_id':batch['batch_id']+'-'+i+f'-P{rep:02d}','phase':batch['phase'],'round':batch['round'],'arm':batch['arm'],'instance_id':i,'repetition':rep,'input_sha256':f['sha256']['input/'+i+'.json']})
    h.write(json.dumps(r,allow_nan=False)+'\n');counts[batch['phase']]+=1;saved_records+=1
   h.flush();os.fsync(h.fileno())
   g.write(json.dumps({'batch_id':batch['batch_id'],'phase':batch['phase'],'round':batch['round'],'arm':batch['arm'],'completed_calls':len(buffer),'expected_calls':48*batch['repetitions'],'wrapper_inclusive_panel_cpu_ns':cpu,'wrapper_inclusive_panel_wall_ns':wall,'algorithm_wall_sum_ns':sum(r['algorithm_wall_ns'] for _,_,r in buffer)},allow_nan=False)+'\n');g.flush();os.fsync(g.fileno())
   batches_done+=1;batch_saved=True
   print(batch['batch_id'],'calls',len(buffer),'CPU_ns',cpu,'wall_ns',wall,flush=True)
   if stop_requested:reason=stop_requested;break
 except BaseException as e:reason=type(e).__name__+':'+str(e);raise
 finally:
  signal.setitimer(signal.ITIMER_REAL,0)
  if not batch_saved:dump(ROOT/'raw/PARTIAL_BATCH.json',{'batch':active,'already_written_records':saved_records,'buffer':buffer,'overlap_note':'Buffer includes already-written rows; do not double count; no retry.'})
  dump(ROOT/'raw/WORKER_FINISHED.json',{'utc':utc(),'complete':reason is None and batches_done==len(schedule),'reason':reason,'batches':batches_done,'calls':counts,'worker_cpu_ns':time.process_time_ns(),'worker_elapsed_ns':time.perf_counter_ns()-ENTRY_W,'peakrss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'reruns':0})
