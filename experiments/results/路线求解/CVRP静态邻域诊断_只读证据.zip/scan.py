import pathlib,json,math,time,resource,signal,hashlib,csv,collections
D=pathlib.Path(__file__).resolve().parent
resource.setrlimit(resource.RLIMIT_CPU,(29,30))
signal.alarm(59)
t0=time.process_time();w0=time.monotonic()
roots=[pathlib.Path('/workspace/shared')/s for s in ('official_cvrp_controls_20261008','official_cvrp_neutral_validation_20261008')]
manifest={};results=[];counts=collections.Counter();matrix_count=0

def read(p):
 b=p.read_bytes();manifest[str(p)]=hashlib.sha256(b).hexdigest();return b

def cost(rs,m):
 counts['independent_objective_edges']+=sum(len(r)+1 for r in rs if r)
 return sum(m[a][b] for r in rs if r for a,b in zip([0]+r,r+[0]))

def validate(rs,x,m):
 seen=[n for r in rs for n in r];loads=[sum(x['demands'][n] for n in r) for r in rs]
 assert sorted(seen)==list(range(1,len(x['demands'])))
 assert all(l<=x['capacity'] for l in loads)
 assert len([r for r in rs if r])<=x['K']
 counts['independent_solution_checks']+=1
 return {'cost':cost(rs,m),'loads':loads,'coverage_ok':True,'capacity_ok':True,'fleet_ok':True}

with (D/'ALL_DELTAS.csv').open('w') as f:
 writer=csv.writer(f);writer.writerow(['trajectory','operator','route_a','position_a','route_b','position_b','feasible','delta','full_cost_delta'])
 for root in roots:
  read(root/'source/official_solver.py')
  lp=root/'source/legacy/experiment.py'
  if lp.exists():read(lp)
  for idx,line in enumerate(read(root/'raw/heuristics.jsonl').splitlines()):
   r=json.loads(line);x=json.loads(read(root/'input'/f"{r['instance_id']}.json"));coords=x['coordinates'];m=[]
   for a in coords:
    row=[]
    for b in coords:
     s=(a[0]-b[0])**2+(a[1]-b[1])**2;k=math.isqrt(s);row.append(k+(4*s>=(2*k+1)**2));matrix_count+=1
    m.append(row)
   o=r['output'];assert all(z[0]==z[-1]==0 and 0 not in z[1:-1] for z in o['routes']);rs=[z[1:-1] for z in o['routes']];old=validate(rs,x,m);assert old['cost']==o['reported_cost']
   tid=f'{root.name}:{idx}';rr={'trajectory':tid,'instance':r['instance_id'],'method':r['method'],'mode':r.get('acceptance_mode','strict'),'seed':r['search_seed'],'original':o,'original_check':old,'neighbors':{}}
   for op in ('relocate','swap','2opt'):
    rr['neighbors'][op]={'considered':0,'capacity_rejected':0,'evaluated_deltas':0,'negative_deltas':0,'best_delta':0,'best_witness':None}
   def submit(op,a,i,b,j,can,delta,reads,feasible):
    st=rr['neighbors'][op];st['considered']+=1
    if not feasible:
     st['capacity_rejected']+=1;writer.writerow([tid,op,a,i,b,j,False,'','']);return
    counts['delta_edge_lookups']+=reads;counts['candidate_deltas']+=1;st['evaluated_deltas']+=1
    chk=validate(can,x,m);assert chk['cost']-old['cost']==delta,(tid,op,a,i,b,j,delta,chk['cost'],old['cost'])
    writer.writerow([tid,op,a,i,b,j,True,delta,chk['cost']-old['cost']])
    if delta<0:st['negative_deltas']+=1
    if delta<st['best_delta']:
     st['best_delta']=delta;st['best_witness']={'move':[a,i,b,j],'routes':[[0]+z+[0] for z in can if z],'check':chk}
   # All single-node relocate positions after removal; exclude exact no-op.
   # One empty target suffices if an extra vehicle is available (vehicle labels irrelevant).
   for a,z in enumerate(rs):
    for i,u in enumerate(z):
     partial=[v[:] for v in rs];partial[a].pop(i)
     if len(rs)<x['K']:partial.append([])
     for b,v in enumerate(partial):
      for j in range(len(v)+1):
       if a==b and j==i:continue
       feasible=a==b or sum(x['demands'][n] for n in v)+x['demands'][u]<=x['capacity']
       if not feasible:submit('relocate',a,i,b,j,None,None,0,False);continue
       left=z[i-1] if i else 0;right=z[i+1] if i+1<len(z) else 0;l=v[j-1] if j else 0;t=v[j] if j<len(v) else 0
       delta=m[left][right]-m[left][u]-m[u][right]+m[l][u]+m[u][t]-m[l][t]
       can=[v[:] for v in partial];can[b].insert(j,u);submit('relocate',a,i,b,j,can,delta,6,True)
   positions=[(a,i) for a,z in enumerate(rs) for i in range(len(z))]
   for t,(a,i) in enumerate(positions):
    for b,j in positions[t+1:]:
     u,v=rs[a][i],rs[b][j]
     feasible=a==b or (old['loads'][a]-x['demands'][u]+x['demands'][v]<=x['capacity'] and old['loads'][b]-x['demands'][v]+x['demands'][u]<=x['capacity'])
     if not feasible:submit('swap',a,i,b,j,None,None,0,False);continue
     can=[z[:] for z in rs];can[a][i],can[b][j]=v,u
     edge_positions={(a,i),(a,i+1),(b,j),(b,j+1)};delta=0
     for ri,ei in edge_positions:
      bef=[0]+rs[ri]+[0];aft=[0]+can[ri]+[0];delta+=m[aft[ei]][aft[ei+1]]-m[bef[ei]][bef[ei+1]]
     submit('swap',a,i,b,j,can,delta,2*len(edge_positions),True)
   for a,z in enumerate(rs):
    for i in range(len(z)):
     for j in range(i+1,len(z)):
      if i==0 and j==len(z)-1:continue # whole-route reversal has zero cost in symmetric matrix
      left=z[i-1] if i else 0;right=z[j+1] if j+1<len(z) else 0
      delta=m[left][z[j]]+m[z[i]][right]-m[left][z[i]]-m[z[j]][right]
      can=[v[:] for v in rs];can[a][i:j+1]=reversed(can[a][i:j+1]);submit('2opt',a,i,a,j,can,delta,4,True)
   results.append(rr)
   if time.process_time()-t0>27 or time.monotonic()-w0>57:raise RuntimeError('Budget safety abort')
(D/'TRAJECTORY_CHECKS.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
groups={}
for r in results:
 for op,st in r['neighbors'].items():
  key='|'.join([r['trajectory'].split(':')[0],r['method'],r['mode'],op]);g=groups.setdefault(key,collections.Counter());g['trajectories']+=1;g['with_improvement']+=st['best_delta']<0;g['sum_best_delta']+=st['best_delta'];g.update({k:st[k] for k in ['considered','capacity_rejected','evaluated_deltas','negative_deltas']})
summary={'complete':True,'trajectories':len(results),'all_originals_and_all_feasible_neighbors_independently_validated':True,'matrix_distance_computations':matrix_count,'accounting':dict(counts),'groups':groups,'cpu_seconds':time.process_time()-t0,'wall_seconds':time.monotonic()-w0,'cpu_limit_seconds':30,'wall_limit_seconds':60,'scope':'Static one-step neighborhoods of saved FINAL BEST only; no search, iterative descent, checkpoint scan, tuning, oracle read, or trajectory replay. Move descriptions use zero-based route/customer indices. Relocate position is measured after removal. Includes intra/inter relocate and swap; 2opt is intra-route only. Infeasible candidates have no delta evaluation. Every feasible candidate recomputed and coverage/capacity/fleet checked independently. Duplicate equivalent moves retained and charged; route reversal noops excluded.'}
(D/'SUMMARY.json').write_text(json.dumps(summary,indent=2));(D/'INPUT_SHA256.json').write_text(json.dumps(manifest,indent=2));print(json.dumps(summary,indent=2))
