"""Independent saved-output audit: direct frozen matrices, exact integer routes, no optimizer/native imports."""
from evidence_primitives import *
from native_contract import expected_native
from decimal import Decimal,localcontext
import io,resource,signal,time
Q5_SHA='23142f498d31bd1a247d906a82ea6a167afee362b99eac0f129b37a5b4603fbb'
PARENT_SHA='c2ad0a293255abb8a4f8345704403373b5154a94963cb72862cbd262bd1a0d37'
WARNING_PATH='/workspace/shared/public_route_strong_baseline_20261009_venv/lib/python3.12/site-packages/pyvrp/PenaltyManager.py'
WARNING_SHA='2f691640bb5a785920df1077653d2bf406bc0350594913f9fe8378c127a3e6d1'
FIELDS=['nl_field_'+str(i)for i in (40,44,63,187,1,2,7,8,17,67,89,143)]
ROW_KEYS=('call_id','instance_id','proxy','seed','max_iterations','valid','E','G','own_gap_mm','own_gap_percent','exact_hit','G_realized_excess_mm','E_offset_from_lex_reference_mm','E_optimal_tie_difference_mm')
AGG_KEYS=('cells','field_summaries','paired_realized_differences','paired_budget_improvements')
def compact(x):return json.dumps(x,separators=(',',':')).encode()
def matrix_cost(M,routes):return sum(M[a][b]for r in routes for a,b in zip(r,r[1:]))
def defaults():return load(ROOT/'selftests/toy/DEFAULT_PARAMS.json')['parameters']

def validate_answer(p,e,a,params):
    require((a['solver'],a['version'],a['algorithm'])==('PyVRP','0.14.0','ILS'),'solver identity')
    require(type(a['seed'])is int and a['seed']==e['seed'],'seed')
    budget=e['max_iterations'];n=len(p['coordinates'])-1;M=p['matrices'][e['proxy']]
    require(type(a['max_iterations'])is int and type(a['num_iterations'])is int and a['max_iterations']==a['num_iterations']==budget,'iteration budget')
    require(a['model_instances']==a['solver_calls']==1 and a['explicit_solution_constructions']==0,'call counts')
    require(a['native_model_parameters']==expected_native(p),'full native model')
    require(a['default_solve_params']==params,'full default parameters')
    require(a['denied_io_events']==a['reference_or_history_payload_fields']==[],'IO/reference fields')
    require(a['warning_source_verification']=={'path':WARNING_PATH,'sha256':WARNING_SHA,'verified_before_search':True,'default_warning_behavior_preserved':True},'warning source identity')
    allowed={'event':'open','path':WARNING_PATH,'mode':'r','flags':524288,'verified_source_sha256':WARNING_SHA}
    require(isinstance(a['allowed_warning_source_reads'],list)and all(x==allowed for x in a['allowed_warning_source_reads']),'warning read events')
    require(len(a['native_distance_matrix'])==n+1 and all(len(r)==n+1 and all(type(x)is int for x in r)for r in a['native_distance_matrix']),'native matrix schema')
    require(a['native_distance_matrix']==M and a['native_matrix_entries_checked']==(n+1)**2,'every native matrix entry')
    require(a['model_matrix_sha256']==hashlib.sha256(compact(M)).hexdigest(),'native matrix hash')
    require(a['resource_limits']=={'inherited':{'AS_bytes':[512*1024**2,1536*1024**2],'CPU_seconds':[60,60]},'effective':{'AS_bytes':[1536*1024**2]*2,'CPU_seconds':[15,15]}},'resource inheritance')
    sf={'current_cost','candidate_cost','best_cost','current_feas','candidate_feas','best_feas'}
    require(len(a['stats'])==len(a['stats_runtime_per_iteration'])==budget,'statistics length')
    for r in a['stats']:require(set(r)==sf and all(type(r[k])is(bool if k.endswith('_feas')else int)for k in sf),'statistics schema')
    require(all(type(t)in(int,float)and math.isfinite(t)and t>=0 for t in a['stats_runtime_per_iteration']),'timing schema')
    routes=a['routes'];require(isinstance(routes,list)and len(routes)==len(a['native_routes'])==a['reported_num_routes'],'route count')
    served=[];loads=[]
    for r,native in zip(routes,a['native_routes']):
        require(isinstance(r,list)and len(r)>=3 and all(type(x)is int for x in r),'route schema')
        require(r[0]==r[-1]==0 and all(1<=x<=n for x in r[1:-1]),'closed service routes')
        served+=r[1:-1];load_value=sum(p['demands'][x]for x in r[1:-1]);loads.append(load_value)
        require(native['distance']==matrix_cost(M,[r])and native['delivery']==[load_value],'native cost/load')
        require(native['is_feasible']==(load_value<=p['capacity'])and native['num_trips']==1 and native['vehicle_type']==native['start_depot']==native['end_depot']==0,'native route parameters')
        require(native['activities']==[{'type':'DEPOT'if j in(0,len(r)-1)else'CLIENT','idx':0 if j in(0,len(r)-1)else node-1,'node':node,'location':node}for j,node in enumerate(r)],'native activity mapping')
    covered=Counter(served)==Counter(range(1,n+1));feasible=covered and len(routes)<=p['K']and all(v<=p['capacity']for v in loads)
    require(type(a['solver_is_complete'])is bool and type(a['solver_is_feasible'])is bool and a['solver_is_complete']==covered and a['solver_is_feasible']==feasible,'independent feasibility flags')
    costs={k:matrix_cost(p['matrices'][k],routes)for k in('E','G')}
    require(a['reported_distance']==a['internal_route_cost']==costs[e['proxy']] and a['reported_fixed_vehicle_cost']==a['reported_duration_cost']==0,'native objective components')
    require((type(a['reported_cost'])is int and a['reported_cost']==costs[e['proxy']])if feasible else a['reported_cost']is None,'reported feasible objective')
    if feasible:require(len(routes)==p['K'] and sum(len(r)-1 for r in routes)==n+p['K'],'fixed tasks imply exactly K routes')
    return {'valid_feasible':feasible,'E':costs['E'],'G':costs['G'],'routes':routes,'loads':loads,'matrix_entries':(n+1)**2}

def endpoints(proxy,costs,truth):
    own=costs[proxy]-truth[proxy+'_star'];require(own>=0,'negative primary gap')
    realized=costs['G']-truth['G_star'];require(realized>=0,'negative realized G excess')
    offset=costs['G']-truth['G_at_E_optimum']if proxy=='E'else None
    tied=offset if proxy=='E'and own==0 else None
    require(tied is None or tied>=0,'negative secondary gap within E optimum')
    if proxy=='E':require(realized==offset+truth['delta_integer_mm'],'signed decomposition')
    return {'own_gap_mm':own,'own_gap_percent':100*own/truth[proxy+'_star']if truth[proxy+'_star']>0 else None,'exact_hit':own==0,'G_realized_excess_mm':realized,'E_offset_from_lex_reference_mm':offset,'E_optimal_tie_difference_mm':tied,'offset_is_search_error':False}

def source_inputs():
    ids=load(ROOT/'input/IDENTITIES.json');require(sha(ROOT/'input/Q5_FINAL.zip')==ids['q5_final_sha256']==Q5_SHA,'Q5 exact archive identity')
    with zipfile.ZipFile(ROOT/'input/Q5_FINAL.zip')as q:
        oracle=json.loads(q.read('independent_supervision/FINAL_AUDIT.json'));nested=q.read('input/PARENT_FINAL.zip')
    require(hashlib.sha256(nested).hexdigest()==PARENT_SHA,'nested path archive identity')
    require(oracle['status']=='PASS'and oracle['verified_fields']==12 and set(oracle['eligible_instance_ids'])==set(FIELDS),'previous exact verification')
    truth={x['instance_id']:x for x in oracle['fields']};problems={};pre={}
    with zipfile.ZipFile(io.BytesIO(nested))as z:
        for field in FIELDS:
            meta=ids['fields'][field];require(meta['selected_original_ids']==list(range(13)),'selected task IDs')
            require(sha(ROOT/f'input/{field}.json')==meta['input_sha256'],'input bytes')
            for name,m in meta['upstream_members'].items():
                b=z.read(m['member']);require(len(b)==m['bytes']and hashlib.sha256(b).hexdigest()==m['sha256'],'source member '+field+'/'+name)
            source=json.loads(z.read(f'raw/fields/{field}/preprocess.json'));p=load(ROOT/f'input/{field}.json')
            require(p['coordinates']==source['coordinates'][:13]and p['demands']==[0]+[1]*12 and p['capacity']==5 and p['K']==3,'original coordinates and CVRP definition')
            for name in('E','G'):require(p['matrices'][name]==[r[:13]for r in source['integer_matrices'][name][:13]],'direct integer matrix copy '+name)
            require(truth[field]['valid_for_exact_conclusion']is True,'valid oracle field')
            problems[field]=p;pre[field]=source
    return problems,truth,pre

def audit_ledger(schedule,events,items,slots,parse_errors,outer):
    expected={e['call_id']:e for e in schedule};by={};errors=list(parse_errors);per={cid:[]for cid in expected};active=None;started=[];finished=[];last_utc=None
    for r in items:
        cid=r.get('call_id')
        if cid not in expected or cid in by:errors.append('unexpected/duplicate result');continue
        by[cid]=r
        if r.get('schedule')!=expected[cid]:per[cid].append('result schedule mismatch')
    for row in events:
        cid=row.get('call_id');kind=row.get('event_kind')
        if cid not in expected or kind not in('STARTED','FINISHED'):errors.append('unknown event');continue
        if row.get('schedule')!=expected[cid]:per[cid].append('event schedule mismatch')
        try:
            current=datetime.datetime.fromisoformat(row['utc']);require(last_utc is None or current>=last_utc,'event UTC order');last_utc=current
        except Exception:errors.append('invalid UTC chronology')
        if kind=='STARTED':
            if active is not None:errors.append('overlap/unclosed prior call')
            active=cid;started.append(cid)
        else:
            if active!=cid:errors.append('unmatched finish')
            active=None;finished.append(cid)
            if row.get('result')!=by.get(cid):per[cid].append('finished versus results mismatch')
    if len(set(started))!=len(started)or len(set(finished))!=len(finished):errors.append('duplicate call event')
    if started!=[e['call_id']for e in schedule if e['call_id']in set(started)]:errors.append('schedule order')
    if len(slots)!=len(schedule)or [r.get('schedule')for r in slots]!=schedule:errors.append('complete slot ledger order')
    slotby={r['schedule']['call_id']:r for r in slots if isinstance(r,dict)and isinstance(r.get('schedule'),dict)and r['schedule'].get('call_id')in expected}
    for cid in expected:
        if cid not in by:per[cid].append('missing original result')
        elif slotby.get(cid)!=by[cid]:per[cid].append('slot versus original result mismatch')
        if cid in by and by[cid].get('status')=='NOT_STARTED_INPUT_FAILURE':
            if cid in started or by[cid].get('process_spawned')is not False:per[cid].append('input failure start ambiguity')
        elif [x.get('event_kind')for x in events if x.get('call_id')==cid]!=['STARTED','FINISHED']:per[cid].append('missing start/finish')
    require(outer['cleanup']['quiescent']is True,'whole process group quiescence')
    known=sum(r.get('process_spawned')is True for r in slots);unknown=sum(r.get('process_spawned')is None for r in slots)
    require(known==outer['known_spawned']and unknown==outer['unknown_spawned_slots'],'actual call accounting')
    return {'errors':errors,'per_call_errors':per,'started_events':len(started),'finished_events':len(finished),'observed_records':len(items),'known_spawned':known,'unknown_spawned_slots':unknown,'planned_slots':len(schedule)},by

def aggregates(rows,fields):
    cells=[];field_summaries=[];paired=[];budgets=[];lookup={(r['instance_id'],r['seed'],r['proxy'],r['max_iterations']):r for r in rows}
    for budget in(250,25):
        for proxy in('E','G'):
            allrows=[r for r in rows if r['max_iterations']==budget and r['proxy']==proxy];valid=[r for r in allrows if r['valid']];n=len(allrows);m=len(valid);vals=[r['own_gap_mm']for r in valid];hits=sum(r['exact_hit']for r in valid)
            cells.append({'proxy':proxy,'max_iterations':budget,'planned':n,'eligible':m,'failed_or_unverified':n-m,'exact_hits':hits,'exact_hit_rate_all_planned':hits/n if n else None,'exact_hit_rate_valid_only':hits/m if m else None,'complete_panel_mean_gap_mm':sum(vals)/m if m and m==n else None,'valid_subset_mean_gap_mm':sum(vals)/m if m else None,'valid_subset_max_gap_mm':max(vals)if vals else None})
    for field in fields:
        for budget in(250,25):
            for seed in range(3):
                e=lookup[(field,seed,'E',budget)];g=lookup[(field,seed,'G',budget)];ok=e['valid']and g['valid']
                paired.append({'instance_id':field,'seed':seed,'max_iterations':budget,'valid_pair':ok,'E_minus_G_realized_mm':e['G']-g['G']if ok else None})
            for proxy in('E','G'):
                vv=[lookup[(field,s,proxy,budget)]for s in range(3)if lookup[(field,s,proxy,budget)]['valid']];vals=[r['own_gap_mm']for r in vv]
                field_summaries.append({'instance_id':field,'proxy':proxy,'max_iterations':budget,'planned':3,'eligible':len(vv),'complete3seed_mean_own_gap_mm':sum(vals)/3 if len(vv)==3 else None,'valid_subset_mean_own_gap_mm':sum(vals)/len(vv)if vv else None,'exact_hits_all3_denominator':sum(r['exact_hit']for r in vv)})
        for seed in range(3):
            for proxy in('E','G'):
                a=lookup[(field,seed,proxy,25)];b=lookup[(field,seed,proxy,250)];ok=a['valid']and b['valid']
                budgets.append({'instance_id':field,'seed':seed,'proxy':proxy,'valid_pair':ok,'own_gap25_minus250_mm':a['own_gap_mm']-b['own_gap_mm']if ok else None})
    return dict(cells=cells,field_summaries=field_summaries,paired_realized_differences=paired,paired_budget_improvements=budgets)

def collect(schedule,slots,items,events,parse_errors,outer,problems,truth,pre,params):
    ledger,by=audit_ledger(schedule,events,items,slots,parse_errors,outer);rows=[]
    for e in schedule:
        cid=e['call_id'];slot=by.get(cid,{});row={**e,'valid':False,'failure':None,'raw_status':slot.get('status','MISSING_RESULT'),'E':None,'G':None,'own_gap_mm':None,'own_gap_percent':None,'exact_hit':False,'G_realized_excess_mm':None,'E_offset_from_lex_reference_mm':None,'E_optimal_tie_difference_mm':None,'saved_G_path_length_m':None,'saved_G_path_legs':None}
        try:
            require(not ledger['errors']and not ledger['per_call_errors'][cid],'call ledger validity')
            require(slot.get('status')in('UNREVIEWED_PROCESS_SUCCESS','UNREVIEWED_INFEASIBLE')and slot.get('returncode')==0 and slot.get('process_spawned')is True and slot.get('child_reaped')is True,'completed call')
            require(not slot.get('error'),'call error field')
            require(slot['stdout']==f'raw/calls/{cid}.stdout'and slot['stderr']==f'raw/calls/{cid}.stderr','fixed call paths')
            for k in('stdout','stderr'):require(sha(ROOT/slot[k])==slot[k+'_sha256'],'raw output hash')
            p=problems[e['instance_id']];payload={k:p[k]for k in('coordinates','demands','capacity','K')};payload.update(distance_matrix=p['matrices'][e['proxy']],seed=e['seed'],max_iterations=e['max_iterations'])
            require(slot['payload_sha256']==hashlib.sha256(compact(payload)).hexdigest(),'single-matrix payload identity')
            answer=load(ROOT/slot['stdout']);checked=validate_answer(p,e,answer,params)
            require((slot['status']=='UNREVIEWED_PROCESS_SUCCESS')==checked['valid_feasible'],'status matches native feasibility')
            row['valid_record']=True;row['route_loads']=checked['loads']
            if not checked['valid_feasible']:row['failure']='NO_FEASIBLE_INCUMBENT';rows.append(row);continue
            values=endpoints(e['proxy'],checked,truth[e['instance_id']]);source=pre[e['instance_id']]
            with localcontext()as ctx:
                ctx.prec=80;lengths={tuple(sorted(x['pair'])):Decimal(x['decimal80_path_length_m'])for x in source['pair_checks']};total=Decimal(0);paths=[]
                for route in checked['routes']:
                    for a,b in zip(route,route[1:]):
                        v=lengths[tuple(sorted((a,b)))];total+=v;g=p['matrices']['G'][a][b]
                        require(abs(v-Decimal(g)/1000)<=Decimal('0.00050001'),'saved leg quantization bound')
                        paths.append({'from':a,'to':b,'saved_canonical_path':source['canonical_paths'][a][b],'saved_length_m':str(v),'G_mm':g})
                require(len(paths)==15 and abs(total-Decimal(checked['G'])/1000)<=Decimal('0.00750015'),'15 saved legs and aggregate bound')
                row.update(valid=True,E=checked['E'],G=checked['G'],routes=checked['routes'],saved_G_path_length_m=str(total),saved_G_path_legs=paths,**values)
        except Exception as err:row['failure']=type(err).__name__+':'+str(err)
        rows.append(row)
    fields=list(dict.fromkeys(e['instance_id']for e in schedule))
    return {'status':'SAVED_EVIDENCE_AUDITED','planned_formal_slots':len(schedule),'observed_records':len(items),'rows':rows,'ledger':ledger,'valid_calls':sum(r['valid']for r in rows),'new_solver_calls':0,'new_native_constructions':0,**aggregates(rows,fields)}

def run():
    resource.setrlimit(resource.RLIMIT_CPU,(60,60));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2));signal.alarm(120)
    receipt=gate();out=ROOT/'independent_supervision/results';out.mkdir(exist_ok=True)
    save_exclusive(out/'SAVED_AUDIT_STARTED.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'solver_calls':0,'native_constructions':0})
    cpu=time.process_time();wall=time.monotonic();schedule=load(ROOT/'freeze/SCHEDULE.json');require(len(schedule)==144 and list(dict.fromkeys(e['instance_id']for e in schedule))==FIELDS,'144 slots and fixed12 fields')
    expected=[(f,s,p,b)for f in FIELDS for s in range(3)for p in('E','G')for b in(25,250)]
    require([(e['instance_id'],e['seed'],e['proxy'],e['max_iterations'])for e in schedule]==expected,'frozen schedule order')
    problems,truth,pre=source_inputs();events,ee=lines(ROOT/'raw/attempts.jsonl');items,ie=lines(ROOT/'raw/results.jsonl')
    result=collect(schedule,load(ROOT/'raw/ALL_PLANNED_SLOTS.json'),items,events,ee+ie,load(ROOT/'raw/EXECUTOR_FINISHED.json'),problems,truth,pre,defaults())
    result.update(frozen_files_sha256=receipt['frozen_files_sha256'],raw_archive_sha256=receipt['sha256'],q5_final_sha256=Q5_SHA,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),resources={'cpu_seconds':time.process_time()-cpu,'wall_seconds':time.monotonic()-wall,'maxrss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'limits':{'CPU_seconds':60,'AS_MiB':512,'wall_seconds':120}})
    save_exclusive(out/'SAVED_EXACT_GAP_AUDIT.json',result);print(json.dumps({'valid_calls':result['valid_calls'],'planned':144,'cells':result['cells']}))
if __name__=='__main__':run()
