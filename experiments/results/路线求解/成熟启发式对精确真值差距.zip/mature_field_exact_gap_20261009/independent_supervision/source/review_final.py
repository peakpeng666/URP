"""Final saved report cross-check, no solver or constructor."""
from audit_exact_gap import *
def main():
    resource.setrlimit(resource.RLIMIT_CPU,(15,15));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2));signal.alarm(60)
    receipt=gate();cpu=time.process_time();wall=time.monotonic();audit=load(ROOT/'independent_supervision/results/SAVED_EXACT_GAP_AUDIT.json');report=load(ROOT/'reports/SUMMARY.json');text=(ROOT/'reports/REPORT_ZH.txt').read_text()
    require(audit['status']=='SAVED_EVIDENCE_AUDITED'and audit['raw_archive_sha256']==receipt['sha256']and audit['frozen_files_sha256']==receipt['frozen_files_sha256'],'independent saved audit identity')
    require(report['raw_archive_sha256']==receipt['sha256']and report['frozen_files_sha256']==receipt['frozen_files_sha256'],'report source identity')
    require(report['independent_saved_audit_sha256']==sha(ROOT/'independent_supervision/results/SAVED_EXACT_GAP_AUDIT.json'),'report audit binding')
    require(report['planned_formal_slots']==144 and report['primary250_slots']==report['sensitivity25_slots']==72 and report['field_denominator']==12,'fixed denominators')
    require(len(report['rows'])==len(audit['rows'])==144 and report['verified_author_slots']==audit['valid_calls'],'retained and valid count')
    for r,s in zip(report['rows'],audit['rows']):
        for k in ROW_KEYS:require(r[k]==s[k],'row identity/value '+k)
        if r['valid']:
            for k in('routes','saved_G_path_length_m','saved_G_path_legs'):require(r[k]==s[k],'route/path saved evidence '+k)
    for k in AGG_KEYS:require(report[k]==audit[k],'all aggregates '+k)
    require(report['formal_known_spawned']==audit['ledger']['known_spawned']and report['formal_unknown_spawned_slots']==audit['ledger']['unknown_spawned_slots'],'actual calls')
    require(report['new_solver_calls_in_report']==report['new_native_constructions_in_report']==0 and report['toy_solver_calls']==report['toy_model_instances']==2,'no additional optimization')
    for phrase in('144','250','25','36','12','不能称搜索误差','初始化','完整面板','未见泛化','并列选路差'):require(phrase in text,'report scope '+phrase)
    result={'status':'PASS','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'raw_archive_sha256':receipt['sha256'],'frozen_files_sha256':receipt['frozen_files_sha256'],'report_sha256':sha(ROOT/'reports/REPORT_ZH.txt'),'summary_sha256':sha(ROOT/'reports/SUMMARY.json'),'independent_audit_sha256':sha(ROOT/'independent_supervision/results/SAVED_EXACT_GAP_AUDIT.json'),'planned_formal_slots':144,'verified_calls':audit['valid_calls'],'new_solver_calls':0,'new_native_constructions':0,'resources':{'cpu_seconds':time.process_time()-cpu,'wall_seconds':time.monotonic()-wall}}
    save_exclusive(ROOT/'independent_supervision/results/FINAL_REPORT_REVIEW.json',result);print(json.dumps(result))
if __name__=='__main__':main()
