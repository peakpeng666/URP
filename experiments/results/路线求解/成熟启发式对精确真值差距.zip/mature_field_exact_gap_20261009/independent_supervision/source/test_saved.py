"""Independent non-optimizing tests using the two retained native toys and fabricated144 slots."""
import copy,shutil,sys,time
import audit_exact_gap as a
from audit_exact_gap import *
def write(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')
def reject(fn):
    try:fn()
    except (ValueError,KeyError,TypeError,AssertionError):return
    raise AssertionError('expected rejection')
def main():
    cpu=time.process_time();wall=time.monotonic();base=ROOT;dest=base/'independent_supervision/selftests/saved_r2';dest.mkdir(exist_ok=False)
    p=load(base/'selftests/toy/FIXTURE.json');ss=load(base/'selftests/toy/SCHEDULE.json');params=defaults();toy=[]
    for e in ss:
        out=base/f"selftests/toy/raw/calls/{e['call_id']}.stdout";answer=load(out);v=validate_answer(p,e,answer,params);require(v['valid_feasible'],'toy valid');toy.append({'call_id':e['call_id'],'stdout_sha256':sha(out),'cost':v[e['proxy']],'native_entries':v['matrix_entries']})
        for change in [lambda x:x['native_distance_matrix'][0].__setitem__(1,999),lambda x:x['native_routes'][0]['activities'][1].__setitem__('idx',99),lambda x:x.update(reported_cost=0),lambda x:x['resource_limits']['inherited'].__setitem__('CPU_seconds',[30,30]),lambda x:x['stats'][0].__setitem__('best_feas',1)]:
            c=copy.deepcopy(answer);change(c);reject(lambda:validate_answer(p,e,c,params))
    require([x['cost']for x in toy]==[54,82]and sum(x['native_entries']for x in toy)==50,'two native saved toys')
    orc={'E_star':100,'G_star':100,'G_at_E_optimum':120,'delta_integer_mm':20}
    require(endpoints('E',{'E':101,'G':110},orc)['E_offset_from_lex_reference_mm']==-10,'signed offset retained')
    require(endpoints('E',{'E':100,'G':130},orc)['E_optimal_tie_difference_mm']==10,'tie gap when primary hit')
    reject(lambda:endpoints('E',{'E':99,'G':130},orc));reject(lambda:endpoints('E',{'E':100,'G':110},orc))
    problems,truth,pre=source_inputs();require(len(problems)==len(truth)==len(pre)==12,'all12 source identity, no objective optimization')
    # Original author-generated invented schema is input evidence only. Adapt trace/payload fields missing in its reducer-only fixture.
    src=base/'selftests/report_replay_r3';schedule=load(src/'freeze/SCHEDULE.json');slots=load(src/'raw/ALL_PLANNED_SLOTS.json');fields=list(dict.fromkeys(x['instance_id']for x in schedule))
    pp={f:load(src/f'input/{f}.json')for f in fields};tt={f:{'E_star':15,'G_star':15,'G_at_E_optimum':15,'delta_integer_mm':0}for f in fields};pre0={'pair_checks':[{'pair':[i,j],'decimal80_path_length_m':'0.001'}for i in range(13)for j in range(i+1,13)],'canonical_paths':[[[i]if i==j else[i,j]for j in range(13)]for i in range(13)]};pr={f:pre0 for f in fields}
    # Build canonical valid saved answers from prior invented fixture, not by invoking any native constructor.
    original=load(src/slots[0]['stdout']);routes=[[0,1,2,0],[0,3,4,5,6,7,0],[0,8,9,10,11,12,0]];events=[];newslots=[]
    for e in schedule:
        answer=copy.deepcopy(original);answer.update(seed=e['seed'],max_iterations=e['max_iterations'],num_iterations=e['max_iterations'],default_solve_params={})
        answer['stats']=[{'current_cost':15,'candidate_cost':15,'best_cost':15,'current_feas':True,'candidate_feas':True,'best_feas':True}for _ in range(e['max_iterations'])];answer['stats_runtime_per_iteration']=[0]*e['max_iterations']
        stdout=f"raw/calls/{e['call_id']}.stdout";stderr=f"raw/calls/{e['call_id']}.stderr";write(dest/stdout,answer);(dest/stderr).write_text('')
        problem=pp[e['instance_id']];payload={k:problem[k]for k in('coordinates','demands','capacity','K')};payload.update(distance_matrix=problem['matrices'][e['proxy']],seed=e['seed'],max_iterations=e['max_iterations'])
        slot={'call_id':e['call_id'],'schedule':e,'status':'UNREVIEWED_PROCESS_SUCCESS','returncode':0,'process_spawned':True,'child_reaped':True,'stdout':stdout,'stderr':stderr,'stdout_sha256':sha(dest/stdout),'stderr_sha256':sha(dest/stderr),'payload_sha256':hashlib.sha256(compact(payload)).hexdigest()};newslots.append(slot)
        events.extend([{'event_kind':'STARTED','utc':'2026-10-09T00:00:00+00:00','call_id':e['call_id'],'schedule':e},{'event_kind':'FINISHED','utc':'2026-10-09T00:00:00+00:00','call_id':e['call_id'],'schedule':e,'result':slot}])
    a.ROOT=dest;outer={'cleanup':{'quiescent':True},'known_spawned':144,'unknown_spawned_slots':0}
    full=collect(schedule,newslots,newslots,events,[],outer,pp,tt,pr,{})
    write(dest/'FULL.json',full);require(full['valid_calls']==144,'full144 saved audit: '+str([r['failure']for r in full['rows']if not r['valid']][:2]))
    # Compare independent reduction with author's read-only reducer against the same invented evidence.
    sys.path.insert(0,str(base/'source'));import report as author
    author.ROOT=src;author.read=lambda rel:load(src/rel);author.verify_frozen=lambda:'SYNTHETIC_ONLY';author.verify_old=lambda:0;author.receipt=lambda stage:{'sha256':'SYNTHETIC_ONLY'}
    oldslots=author.read('raw/ALL_PLANNED_SLOTS.json');author.read=lambda rel:newslots if rel=='raw/ALL_PLANNED_SLOTS.json'else(load(src/rel))
    # Author paths must refer to these same invented answers while archive/inputs remain the saved fixture.
    for sub in('input','freeze','selftests/toy'):
        for path in (src/sub).rglob('*'):
            if path.is_file():target=dest/path.relative_to(src);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,target)
    write(dest/'raw/ALL_PLANNED_SLOTS.json',newslots);write(dest/'raw/EXECUTOR_FINISHED.json',dict(outer,ledger_errors=[]))
    author.ROOT=dest;author.read=lambda rel:load(dest/rel)
    aa=author.build_report()
    for k in AGG_KEYS:require(full[k]==aa[k],'independent vs author '+k)
    for x,y in zip(full['rows'],aa['rows']):
        for k in ROW_KEYS:require(x[k]==y[k],'row '+k)
    broken=copy.deepcopy(newslots);broken[1]['status']='PROCESS_FAILURE_OR_CPU_LIMIT';ev=copy.deepcopy(events);ev[3]['result']=broken[1]
    partial=collect(schedule,broken,broken,ev,[],outer,pp,tt,pr,{})
    require(partial['valid_calls']==143 and partial['cells'][0]['planned']==36 and partial['cells'][0]['complete_panel_mean_gap_mm']is None,'failure denominator')
    require(sum(p['valid_pair']for p in partial['paired_realized_differences'])==71 and sum(p['valid_pair']for p in partial['paired_budget_improvements'])==71,'paired denominators')
    # An unstarted-input failure skips event pair but keeps its slot, without invalidating other143.
    absent=copy.deepcopy(newslots);absent[1].update(status='NOT_STARTED_INPUT_FAILURE',process_spawned=False);ev=events[:2]+events[4:]
    out=collect(schedule,absent,absent,ev,[],dict(outer,known_spawned=143),pp,tt,pr,{})
    require(out['valid_calls']==143,'explicit unstarted input failure propagation')
    a.ROOT=base
    record={'status':'PASS','saved_native_toys':toy,'frozen_source_fields_checked':12,'invented_slots':144,'full_valid':144,'failure_valid':143,'new_native_constructions':0,'new_solver_calls':0,'new_real_field_optimization':0,'checks':['full-native matrix50 toy entries','client/depot mapping','resource hard inheritance','statistics types','signed offset and primary tie distinction','144-row independent/author metrics agreement','72+72 pair denominators','unstarted-input failure retention'],'resources':{'cpu_seconds':time.process_time()-cpu,'wall_seconds':time.monotonic()-wall}}
    write(base/'independent_supervision/selftests/SAVED_CHECK_R2.json',record);print(json.dumps(record))
if __name__=='__main__':main()
