"""Saved-only integer gap report, gated on private RAW readback; never imports PyVRP."""
import collections,decimal,io,json,resource,signal,time,zipfile
from common import ROOT,read,save,sha,now,verify_frozen,verify_old,receipt
from endpoint_core import validate_saved,define_endpoints,summarize_cells

def build_report():
    digest=verify_frozen();verify_old();raw=receipt('RAW_UNREVIEWED')
    protocol=read('freeze/PROTOCOL.json');schedule=read('freeze/SCHEDULE.json')
    slots=read('raw/ALL_PLANNED_SLOTS.json');outer=read('raw/EXECUTOR_FINISHED.json')
    assert len(schedule)==len(slots)==144 and outer['cleanup']['quiescent'] is True
    assert [s['schedule'] for s in slots]==schedule
    assert sha(ROOT/'input/Q5_FINAL.zip')==protocol['input']['sha256']
    with zipfile.ZipFile(ROOT/'input/Q5_FINAL.zip') as q:
        exact=json.loads(q.read('independent_supervision/FINAL_AUDIT.json'))
        nested=q.read('input/PARENT_FINAL.zip')
    assert exact['status']=='PASS' and exact['verified_fields']==12
    oracles={r['instance_id']:r for r in exact['fields']}
    rows=[];problems={};default_params=read('selftests/toy/DEFAULT_PARAMS.json')['parameters']
    with zipfile.ZipFile(io.BytesIO(nested)) as parent,decimal.localcontext() as ctx:
        ctx.prec=80
        pre={f:json.loads(parent.read(f'raw/fields/{f}/preprocess.json')) for f in protocol['fields']}
        for e,slot in zip(schedule,slots):
            row={**e,'valid':False,'failure':None,'raw_status':slot['status'],'E':None,'G':None,
                 'own_gap_mm':None,'own_gap_percent':None,'exact_hit':False,'G_realized_excess_mm':None,
                 'E_offset_from_lex_reference_mm':None,'E_optimal_tie_difference_mm':None,
                 'saved_G_path_length_m':None,'saved_G_path_legs':None}
            try:
                assert not outer['ledger_errors'],'LEDGER_INTEGRITY_FAILURE'
                assert slot['status'] in ('UNREVIEWED_PROCESS_SUCCESS','UNREVIEWED_INFEASIBLE') and slot['returncode']==0
                assert slot['process_spawned'] is True and slot['child_reaped'] is True
                assert sha(ROOT/slot['stdout'])==slot['stdout_sha256'] and sha(ROOT/slot['stderr'])==slot['stderr_sha256']
                problem=problems.setdefault(e['instance_id'],read(f"input/{e['instance_id']}.json"))
                assert sha(ROOT/f"input/{e['instance_id']}.json")==read('input/IDENTITIES.json')['fields'][e['instance_id']]['input_sha256']
                answer=read(slot['stdout']);assert answer['default_solve_params']==default_params
                if slot['status']=='UNREVIEWED_INFEASIBLE':
                    assert answer['solver_is_feasible'] is False and answer['reported_cost'] is None
                    row['failure']='NO_FEASIBLE_INCUMBENT';rows.append(row);continue
                checked=validate_saved(problem,e,answer);oracle=oracles[e['instance_id']]
                assert oracle['valid_for_exact_conclusion'] is True
                endpoint=define_endpoints(e['proxy'],checked,oracle)
                source=pre[e['instance_id']]
                lengths={tuple(sorted(x['pair'])):decimal.Decimal(x['decimal80_path_length_m']) for x in source['pair_checks']}
                paths=[];length=decimal.Decimal(0)
                for route in checked['routes']:
                    for a,b in zip(route,route[1:]):
                        saved=lengths[tuple(sorted((a,b)))];length+=saved
                        assert abs(saved-decimal.Decimal(problem['matrices']['G'][a][b])/1000)<=decimal.Decimal('0.00050001')
                        paths.append({'from':a,'to':b,'saved_canonical_path':source['canonical_paths'][a][b],
                                      'saved_length_m':str(saved),'G_mm':problem['matrices']['G'][a][b]})
                assert len(paths)==15 and abs(length-decimal.Decimal(checked['G'])/1000)<=decimal.Decimal('0.00750015')
                row.update(valid=True,E=checked['E'],G=checked['G'],routes=checked['routes'],
                           saved_G_path_length_m=str(length),saved_G_path_legs=paths,**endpoint)
            except (AssertionError,KeyError,TypeError,ValueError,OSError,IndexError) as exc:
                row['failure']=type(exc).__name__+':'+str(exc)
            rows.append(row)
    cells=[summarize_cells(rows,p,b) for b in (250,25) for p in ('E','G')]
    lookup={(r['instance_id'],r['seed'],r['proxy'],r['max_iterations']):r for r in rows}
    paired=[];budget_pairs=[];field_summaries=[]
    for f in protocol['fields']:
        for b in (250,25):
            for seed in (0,1,2):
                e,g=[lookup[(f,seed,p,b)] for p in ('E','G')]
                valid=e['valid'] and g['valid']
                paired.append({'instance_id':f,'seed':seed,'max_iterations':b,'valid_pair':valid,
                               'E_minus_G_realized_mm':e['G']-g['G'] if valid else None})
            for p in ('E','G'):
                rr=[lookup[(f,s,p,b)] for s in (0,1,2)];vv=[r for r in rr if r['valid']]
                field_summaries.append({'instance_id':f,'proxy':p,'max_iterations':b,'planned':3,'eligible':len(vv),
                  'complete3seed_mean_own_gap_mm':sum(r['own_gap_mm'] for r in vv)/3 if len(vv)==3 else None,
                  'valid_subset_mean_own_gap_mm':sum(r['own_gap_mm'] for r in vv)/len(vv) if vv else None,
                  'exact_hits_all3_denominator':sum(r['exact_hit'] for r in vv)})
        for seed in (0,1,2):
            for p in ('E','G'):
                a,b=[lookup[(f,seed,p,n)] for n in (25,250)];valid=a['valid'] and b['valid']
                budget_pairs.append({'instance_id':f,'seed':seed,'proxy':p,'valid_pair':valid,
                                     'own_gap25_minus250_mm':a['own_gap_mm']-b['own_gap_mm'] if valid else None})
    return {'utc':now(),'status':'AUTHOR_SAVED_REPORT_COMPLETE_PENDING_INDEPENDENT_REVIEW',
      'frozen_files_sha256':digest,'raw_archive_sha256':raw['sha256'],'q5_final_sha256':protocol['input']['sha256'],
      'planned_formal_slots':144,'primary250_slots':72,'sensitivity25_slots':72,
      'verified_author_slots':sum(r['valid'] for r in rows),'field_denominator':12,'raw_status_counts':dict(collections.Counter(r['raw_status'] for r in rows)),
      'toy_solver_calls':2,'toy_model_instances':2,'formal_known_spawned':outer['known_spawned'],'formal_unknown_spawned_slots':outer['unknown_spawned_slots'],
      'new_solver_calls_in_report':0,'new_native_constructions_in_report':0,'cells':cells,'field_summaries':field_summaries,
      'paired_realized_differences':paired,'paired_budget_improvements':budget_pairs,'rows':rows,
      'limitations':protocol['claims'],'endpoint_definitions':protocol['endpoint_definitions']}

ROW_AUDIT_KEYS=('call_id','instance_id','proxy','seed','max_iterations','valid','E','G',
 'own_gap_mm','own_gap_percent','exact_hit','G_realized_excess_mm',
 'E_offset_from_lex_reference_mm','E_optimal_tie_difference_mm')

def check_independent(data,audit):
    assert audit['status']=='SAVED_EVIDENCE_AUDITED'
    assert audit['raw_archive_sha256']==data['raw_archive_sha256']
    assert audit['frozen_files_sha256']==data['frozen_files_sha256']
    assert len(audit['rows'])==len(data['rows'])==144
    assert len({r['call_id'] for r in audit['rows']})==144
    assert len({r['call_id'] for r in data['rows']})==144
    expected={r['call_id']:r for r in audit['rows']}
    for row in data['rows']:
        other=expected[row['call_id']]
        for key in ROW_AUDIT_KEYS:assert row[key]==other[key],(row['call_id'],key)
    for key,length in [('cells',4),('field_summaries',48),('paired_realized_differences',72),('paired_budget_improvements',72)]:
        assert len(data[key])==len(audit[key])==length
        assert data[key]==audit[key],key
    return True

def main():
    resource.setrlimit(resource.RLIMIT_CPU,(30,30));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2));signal.alarm(60)
    audit=read('independent_supervision/results/SAVED_EXACT_GAP_AUDIT.json')
    assert audit['status']=='SAVED_EVIDENCE_AUDITED'
    data=build_report();check_independent(data,audit)
    data['status']='INDEPENDENT_SAVED_VERIFIED_PENDING_REPORT_REVIEW'
    data['independent_saved_audit_sha256']=sha(ROOT/'independent_supervision/results/SAVED_EXACT_GAP_AUDIT.json')
    save(ROOT/'reports/STARTED.json',{'utc':now(),'solver_calls':0,'native_constructions':0,'independent_comparison_passed_before_writing':True})
    save(ROOT/'reports/SUMMARY.json',data)
    text=['成熟启发式对精确真值差距：固定144槽',
      f"保存输出独立核验完成：有效{data['verified_author_slots']}/144；逐行指标及汇总与独立计算一致。",
      '主分析250轮72槽；预算敏感性25轮72槽。每预算/代理36槽，田块分母12。',
      '预算为官方默认初始化之后的ILS迭代，不能视为等CPU或目标评估次数。',
      '正式调用以完整台账为准；另有固定4客户toy solver2、显式ProblemData模型2。solver内部对象构造未逐个计数。',
      '失败保留计划分母，失败cost/gap为null；下面同时列完整面板和有效子集。']
    for cell in data['cells']:
        text.append(f"{cell['proxy']} / {cell['max_iterations']}轮：有效{cell['eligible']}/{cell['planned']}，精确命中{cell['exact_hits']}/{cell['planned']}；完整面板均值gap={cell['complete_panel_mean_gap_mm']}mm；有效子集均值gap={cell['valid_subset_mean_gap_mm']}mm；有效子集最大gap={cell['valid_subset_max_gap_mm']}mm。")
    text+=['E搜索gap=E(H_E)-E*；G搜索gap=G(H_G)-G*。主目标命中不要求路线或第二目标一致。',
      'G(H_E)-G(R_EG)在E未达最优时可能为负，不能称搜索误差；E已命中时才解释为E最优集合内的G并列选路差。',
      '同seed两预算存在轨迹前缀依赖；田块、种子、路线不能混作独立样本。逐田逐seed完整数据见SUMMARY.json。',
      '本批只描述已观察的12个NL边界及合成任务/Q5容量，不主张未见泛化、连续几何最优、车辆动力学、车间避碰或实车可部署。',
      'G实现成本只串接已冻结合法图路径；未重新求最短路，也未做新几何检验。',
      '无任何新增求解、native构造、重试、选种子、换田块、调预算或修改两旧交接索引。']
    with (ROOT/'reports/REPORT_ZH.txt').open('x') as f:f.write('\n'.join(text)+'\n')
    print(json.dumps({'verified_author_slots':data['verified_author_slots'],'planned':144,'report':'reports/REPORT_ZH.txt'}))
if __name__=='__main__':main()
