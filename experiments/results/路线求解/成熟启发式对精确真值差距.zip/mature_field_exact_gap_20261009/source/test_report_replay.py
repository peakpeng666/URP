"""Exercise the entire report reducer on fabricated144-slot saved evidence, never real inputs."""
import copy,io,json,zipfile
from pathlib import Path
from common import ROOT,save,sha,now
from test_synthetic import fake_answer
import report

def jwrite(p,d):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(d,indent=2,allow_nan=False)+'\n')

def main():
    dest=ROOT/'selftests/report_replay_r3';dest.mkdir(exist_ok=False)
    fields=[f'SYNTHETIC_FIELD_{i}' for i in range(12)]
    problem={'coordinates':[[i,0] for i in range(13)],'demands':[0]+[1]*12,'capacity':5,'K':3,
             'matrices':{p:[[0 if i==j else 1 for j in range(13)] for i in range(13)] for p in ('E','G')}}
    routes=[[0,1,2,0],[0,3,4,5,6,7,0],[0,8,9,10,11,12,0]]
    identities={};exact_fields=[];inner=io.BytesIO()
    pre={'pair_checks':[{'pair':[i,j],'decimal80_path_length_m':'0.001'} for i in range(13) for j in range(i+1,13)],
         'canonical_paths':[[[i] if i==j else [i,j] for j in range(13)] for i in range(13)]}
    with zipfile.ZipFile(inner,'w',zipfile.ZIP_DEFLATED) as z:
        for f in fields:z.writestr(f'raw/fields/{f}/preprocess.json',json.dumps(pre))
    for f in fields:
        path=dest/f'input/{f}.json';jwrite(path,dict(problem,instance_id=f));identities[f]={'input_sha256':sha(path)}
        exact_fields.append({'instance_id':f,'valid_for_exact_conclusion':True,'E_star':15,'G_star':15,'G_at_E_optimum':15,'delta_integer_mm':0})
    q=dest/'input/Q5_FINAL.zip'
    with zipfile.ZipFile(q,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('input/PARENT_FINAL.zip',inner.getvalue())
        z.writestr('independent_supervision/FINAL_AUDIT.json',json.dumps({'status':'PASS','verified_fields':12,'fields':exact_fields}))
    protocol={'fields':fields,'input':{'sha256':sha(q)},'claims':{'scope':'Fabricated schema fixture only'},'endpoint_definitions':{}}
    jwrite(dest/'freeze/PROTOCOL.json',protocol);jwrite(dest/'input/IDENTITIES.json',{'fields':identities})
    jwrite(dest/'selftests/toy/DEFAULT_PARAMS.json',{'parameters':{}})
    schedule=[];slots=[]
    for f in fields:
        for seed in (0,1,2):
            for p in ('E','G'):
                for b in (25,250):
                    entry={'schedule_index':len(schedule)+1,'call_id':f'{f}_{p}_{seed}_{b}','instance_id':f,'proxy':p,'seed':seed,'max_iterations':b};schedule.append(entry)
                    answer=fake_answer(problem,entry,routes);answer['default_solve_params']={}
                    out=dest/f"raw/calls/{entry['call_id']}.stdout";err=out.with_suffix('.stderr');jwrite(out,answer);err.write_text('')
                    slots.append({'call_id':entry['call_id'],'schedule':entry,'status':'UNREVIEWED_PROCESS_SUCCESS','returncode':0,'process_spawned':True,'child_reaped':True,
                      'stdout':str(out.relative_to(dest)),'stderr':str(err.relative_to(dest)),'stdout_sha256':sha(out),'stderr_sha256':sha(err)})
    jwrite(dest/'freeze/SCHEDULE.json',schedule);jwrite(dest/'raw/ALL_PLANNED_SLOTS.json',slots)
    jwrite(dest/'raw/EXECUTOR_FINISHED.json',{'cleanup':{'quiescent':True},'ledger_errors':[],'known_spawned':144,'unknown_spawned_slots':0})
    # Explicit synthetic dependency injection. No real gate is bypassed for real evidence.
    report.ROOT=dest;report.read=lambda rel:json.loads((dest/rel).read_text())
    report.verify_frozen=lambda:'SYNTHETIC_ONLY';report.verify_old=lambda:0
    report.receipt=lambda stage:{'sha256':'SYNTHETIC_ONLY'}
    full=report.build_report()
    assert full['verified_author_slots']==144 and all(c['eligible']==36 and c['exact_hits']==36 and c['complete_panel_mean_gap_mm']==0 for c in full['cells'])
    audit=copy.deepcopy(full);audit['status']='SAVED_EVIDENCE_AUDITED'
    assert report.check_independent(full,audit)
    for mutation in [lambda a:a.update(status='NOT_AUDITED'),lambda a:a.update(raw_archive_sha256='wrong'),lambda a:a['rows'][0].update(own_gap_mm=1),lambda a:a['cells'][0].update(planned=35),lambda a:a['paired_budget_improvements'].pop()]:
        broken_audit=copy.deepcopy(audit);mutation(broken_audit)
        try:report.check_independent(full,broken_audit)
        except (AssertionError,KeyError):pass
        else:raise AssertionError('Independent report gate failed to reject mutation')
    assert len(full['rows'])==144 and len(full['field_summaries'])==48 and len(full['paired_realized_differences'])==72 and len(full['paired_budget_improvements'])==72
    assert all(r['saved_G_path_length_m']=='0.015' and len(r['saved_G_path_legs'])==15 for r in full['rows'])
    broken=copy.deepcopy(slots);broken[1]['status']='PROCESS_FAILURE_OR_CPU_LIMIT';jwrite(dest/'raw/ALL_PLANNED_SLOTS.json',broken)
    partial=report.build_report();bad=partial['rows'][1]
    assert partial['verified_author_slots']==143 and not bad['valid'] and all(bad[k] is None for k in ['E','G','own_gap_mm','G_realized_excess_mm','saved_G_path_length_m'])
    cell=next(c for c in partial['cells'] if c['proxy']=='E' and c['max_iterations']==250)
    assert cell['planned']==36 and cell['eligible']==35 and cell['complete_panel_mean_gap_mm'] is None and cell['valid_subset_mean_gap_mm']==0
    assert sum(p['valid_pair'] for p in partial['paired_realized_differences'])==71
    assert sum(p['valid_pair'] for p in partial['paired_budget_improvements'])==71
    infeasible=copy.deepcopy(slots);infeasible[1]['status']='UNREVIEWED_INFEASIBLE'
    e=schedule[1];bad_routes=[[0,1,2,3,4,5,6,0],[0,7,8,9,0],[0,10,11,12,0]]
    a=fake_answer(problem,e,bad_routes);a.update(default_solve_params={},solver_is_feasible=False,reported_cost=None);a['native_routes'][0]['is_feasible']=False
    out=dest/infeasible[1]['stdout'];jwrite(out,a);infeasible[1]['stdout_sha256']=sha(out)
    jwrite(dest/'raw/ALL_PLANNED_SLOTS.json',infeasible)
    no_incumbent=report.build_report();r=no_incumbent['rows'][1]
    assert not r['valid'] and r['failure']=='NO_FEASIBLE_INCUMBENT' and r['own_gap_mm'] is None and r['E'] is None
    save(ROOT/'selftests/REPORT_REPLAY_R3.json',{'utc':now(),'status':'PASS','solver_calls':0,'native_model_instances':0,'real_field_objective_evaluations':0,
      'fabricated_slots':144,'complete_case_verified':144,'injected_failure_verified':143,
      'checks':['no_feasible_incumbent_distinguished_from_audit_failure','independent_saved_hard_gate_identity_row_endpoint_and_aggregate_rejections','full144_schema_all_groups_and_physical_leg_evidence','failure_costs_null','primary36_denominator_retained','complete_panel_aggregate_null_on_failure','paired_complete_case71of72']})
    print('PASS complete144 and143/144 failure report replay; fabricated inputs only;0solver/native')
if __name__=='__main__':main()
