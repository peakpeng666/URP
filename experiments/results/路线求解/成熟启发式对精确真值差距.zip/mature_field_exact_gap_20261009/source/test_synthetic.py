"""Standard-library contract/negative tests; zero PyVRP imports and zero solver calls."""
import ast,copy,hashlib,json
from common import ROOT,read,save,now
from matrix_adapter import validate_payload
from endpoint_core import validate_saved,define_endpoints,summarize_cells,route_cost
from ledger import reconcile
from gates import get_schedule,load_payload
from io_guard import WARNING_SOURCE,WARNING_SOURCE_SHA256

def reject(fn):
    try:fn()
    except (AssertionError,KeyError,TypeError,ValueError,IndexError):return
    raise AssertionError('Expected rejection')

def fake_answer(problem,entry,routes):
    n=len(problem['coordinates'])-1;M=problem['matrices'][entry['proxy']];U=2**63-1
    v={'capacity':[problem['capacity']],'num_available':problem['K'],'initial_load':[0],'reload_depots':[],
       'unit_distance_cost':1,'max_trips':1}
    v.update({k:0 for k in ['start_depot','end_depot','fixed_cost','unit_duration_cost','unit_overtime_cost','max_reloads','max_overtime','tw_early','profile']})
    v.update({k:U for k in ['max_distance','max_duration','shift_duration','start_late','tw_late']})
    clients=[{'location':i,'delivery':[1],'pickup':[0],'required':True,'group':None,
              'service_duration':0,'prize':0,'release_time':0,'tw_early':0,'tw_late':U} for i in range(1,n+1)]
    native=[]
    for r in routes:
        native.append({'activities':[{'type':'DEPOT' if x==0 else 'CLIENT','idx':0 if x==0 else x-1,'location':x,'node':x} for x in r],
          'distance':route_cost(M,[r]),'delivery':[len(r)-2],'vehicle_type':0,'start_depot':0,'end_depot':0,'num_trips':1,'is_feasible':True})
    cost=route_cost(M,routes)
    return {'solver':'PyVRP','version':'0.14.0','algorithm':'ILS','seed':entry['seed'],'max_iterations':entry['max_iterations'],
      'num_iterations':entry['max_iterations'],'stats':[{}]*entry['max_iterations'],'stats_runtime_per_iteration':[0]*entry['max_iterations'],
      'model_instances':1,'solver_calls':1,'explicit_solution_constructions':0,'solver_is_feasible':True,'solver_is_complete':True,
      'warning_source_verification':{'path':WARNING_SOURCE,'sha256':WARNING_SOURCE_SHA256,'verified_before_search':True,'default_warning_behavior_preserved':True},'allowed_warning_source_reads':[],
      'denied_io_events':[],'reference_or_history_payload_fields':[],'native_distance_matrix':M,'native_matrix_entries_checked':(n+1)**2,
      'model_matrix_sha256':hashlib.sha256(json.dumps(M,separators=(',',':')).encode()).hexdigest(),
      'reported_cost':cost,'reported_distance':cost,'internal_route_cost':cost,'reported_duration_cost':0,'reported_fixed_vehicle_cost':0,
      'native_model_parameters':{'vehicle':v,'clients':clients,'depot':{'location':0,'service_duration':0,'tw_early':0,'tw_late':U},
         'num_locations':n+1,'num_clients':n,'num_depots':1,'num_profiles':1,'num_vehicle_types':1,'num_vehicles':problem['K'],
         'num_shipments':0,'num_groups':0,'duration_matrix_all_zero':True,'locations':[{'x':x,'y':y} for x,y in problem['coordinates']]},
      'routes':routes,'native_routes':native,'reported_num_routes':len(routes),
      'resource_limits':{'effective':{'CPU_seconds':[15,15],'AS_bytes':[1536*1024**2]*2},
                         'inherited':{'CPU_seconds':[60,60],'AS_bytes':[512*1024**2,1536*1024**2]}}}

def main():
    checks=[]
    schedule=get_schedule('formal');assert len(schedule)==144
    assert all(sum(e['proxy']==p and e['max_iterations']==b for e in schedule)==36 for p in ('E','G') for b in (25,250));checks.append('144_unique_cells_and36_per_proxy_budget')
    toy=get_schedule('toy');payload=load_payload(toy[0],'toy');validate_payload(payload)
    for change in [lambda p:p.update(distance_matrix=p['distance_matrix'][:-1]),lambda p:p['distance_matrix'][1].__setitem__(2,True),lambda p:p['distance_matrix'][1].__setitem__(2,999),lambda p:p.update(K=3),lambda p:p.update(seed=True),lambda p:p.update(max_iterations=26),lambda p:p.update(reference_cost=1),lambda p:p['coordinates'][0].__setitem__(0,float('nan'))]:
        p=copy.deepcopy(payload);change(p);reject(lambda:validate_payload(p))
    checks.append('payload_identity_dimensions_boolean_as_int_symmetry_coordinates_extra_fields')
    source=(ROOT/'source/matrix_adapter.py').read_text();tree=ast.parse(source)
    assert not any(isinstance(n,ast.Call) and ((isinstance(n.func,ast.Attribute) and n.func.attr in ('hypot','sqrt')) or (isinstance(n.func,ast.Name) and n.func.id=='round')) for n in ast.walk(tree));checks.append('adapter_no_geometry_or_rounding_calls')
    problem=read('selftests/toy/FIXTURE.json');entry=toy[0];answer=fake_answer(problem,entry,[[0,1,2,0],[0,3,4,0]])
    assert validate_saved(problem,entry,answer)['E']==54
    for change in [lambda a:a['native_distance_matrix'][1].__setitem__(2,2),lambda a:a.update(native_matrix_entries_checked=169),lambda a:a['routes'][0].__setitem__(1,2),lambda a:a['routes'][0].__setitem__(1,0),lambda a:a['native_routes'][0]['activities'][1].__setitem__('idx',1),lambda a:a.update(reported_cost=53),lambda a:a.update(solver_is_feasible=False),lambda a:a['native_model_parameters']['vehicle'].__setitem__('fixed_cost',1),lambda a:a['stats'].pop(),lambda a:a['resource_limits']['inherited'].__setitem__('CPU_seconds',[30,30])]:
        a=copy.deepcopy(answer);change(a);reject(lambda:validate_saved(problem,entry,a))
    checks.append('saved_matrix_mapping_coverage_objective_constraints_iterations_inheritance_rejections')
    # Synthetic13-node input; never evaluates a real-field solution.
    p13={'coordinates':[[i,0] for i in range(13)],'demands':[0]+[1]*12,'capacity':5,'K':3,'matrices':{p:[[0 if i==j else 1 for j in range(13)] for i in range(13)] for p in ('E','G')}}
    for sizes in [(2,5,5),(3,4,5),(4,4,4)]:
        routes=[];cursor=1
        for size in sizes:routes.append([0,*range(cursor,cursor+size),0]);cursor+=size
        assert validate_saved(p13,entry,fake_answer(p13,entry,routes))['legs']==15
    bad=[[0,1,2,3,4,5,6,0],[0,7,8,9,0],[0,10,11,12,0]]
    reject(lambda:validate_saved(p13,entry,fake_answer(p13,entry,bad)));checks.append('three_Q5_size_patterns_and_overload_rejection')
    oracle={'E_star':100,'G_star':100,'G_at_E_optimum':120,'delta_integer_mm':20}
    signed=define_endpoints('E',{'E':101,'G':110},oracle)
    assert signed['own_gap_mm']==1 and signed['E_offset_from_lex_reference_mm']==-10 and signed['E_optimal_tie_difference_mm'] is None
    tie=define_endpoints('E',{'E':100,'G':130},oracle)
    assert tie['exact_hit'] and tie['E_optimal_tie_difference_mm']==10
    reject(lambda:define_endpoints('E',{'E':99,'G':130},oracle));reject(lambda:define_endpoints('E',{'E':100,'G':110},oracle))
    assert define_endpoints('G',{'E':0,'G':0},{'E_star':0,'G_star':0,'G_at_E_optimum':0,'delta_integer_mm':0})['own_gap_percent'] is None
    checks.append('signed_cross_metric_offset_tie_separation_negative_gap_and_zero_denominator')
    sample=[{'proxy':'E','max_iterations':250,'valid':True,'own_gap_mm':3,'exact_hit':False},{'proxy':'E','max_iterations':250,'valid':False,'own_gap_mm':None,'exact_hit':False}]
    summary=summarize_cells(sample,'E',250);assert summary['planned']==2 and summary['eligible']==1 and summary['complete_panel_mean_gap_mm'] is None and summary['valid_subset_mean_gap_mm']==3
    rows,errors=reconcile(schedule,'',json.dumps({'event_kind':'STARTED','call_id':schedule[0]['call_id']}))
    assert len(rows)==144 and not errors and rows[0]['status']=='UNKNOWN_AFTER_SUPERVISOR_FAILURE' and rows[1]['status']=='NOT_STARTED_SUPERVISOR_FAILURE'
    r={'call_id':schedule[0]['call_id'],'schedule':schedule[0]};_,errors=reconcile(schedule,json.dumps(r)+'\n'+json.dumps(r),'');assert errors
    _,errors=reconcile(schedule,'not JSON','');assert errors;checks.append('failure_null_complete_case_denominators_and_interruption_ledger')
    save(ROOT/'selftests/SYNTHETIC_CONTRACT_R2.json',{'utc':now(),'status':'PASS','checks':checks,'solver_calls':0,'native_model_instances':0,'real_field_objective_evaluations':0})
    print(json.dumps({'status':'PASS','checks':len(checks),'solver_calls':0}))
if __name__=='__main__':main()
