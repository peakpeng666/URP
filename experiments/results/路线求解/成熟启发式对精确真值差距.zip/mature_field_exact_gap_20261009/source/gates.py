"""Read-only gates shared by toy and formal launch; no optimizer imports."""
from pathlib import Path
from common import ROOT,read,sha,verify_frozen,verify_old,receipt
FORMAL_SCOPE='one frozen144-call PyVRP E/G Q5 exact-gap batch, seeds0/1/2,25/250ILS, no retry'

def check_environment():
    env=read('environment/RUNTIME.json')
    python=Path(env['python_executable'])
    assert python.is_file() and sha(python.resolve())==env['python_binary_sha256']
    for item in env['installed_distribution_files']:
        p=Path(item['path'])
        assert p.stat().st_size==item['bytes'] and sha(p)==item['sha256'],str(p)
    assert env['pyvrp_version']=='0.14.0'
    return str(python)

def verify_toy_freeze():
    meta=read('selftests/toy/FROZEN.json')
    for rel,item in meta['files'].items():
        p=ROOT/rel
        assert p.stat().st_size==item['bytes'] and sha(p)==item['sha256'],'TOY_FROZEN_CHANGED:'+rel
    auth=read('selftests/toy/AUTHORIZATION.json')
    assert auth['approved'] is True and auth['toy_solver_calls']==auth['toy_model_instances']==2
    assert auth['fixture_sha256']==sha(ROOT/'selftests/toy/FIXTURE.json')
    assert auth['schedule_sha256']==sha(ROOT/'selftests/toy/SCHEDULE.json')
    return sha(ROOT/'selftests/toy/FROZEN.json')

def check_gate(mode):
    assert mode in ('toy','formal')
    verify_old()
    if mode=='toy':
        digest=verify_toy_freeze()
        return {'mode':mode,'freeze_sha256':digest,'python':check_environment()}
    digest=verify_frozen();r=receipt('PREEXEC')
    review=read('freeze/INDEPENDENT_PRECHECK.json')
    assert review['status']=='PASS'
    approval=read('provenance/PARENT_EXECUTION_APPROVAL.json')
    assert approval['approved'] is True and approval['scope']==FORMAL_SCOPE
    assert approval['frozen_files_sha256']==digest
    assert approval['preexec_archive_sha256']==r['sha256']
    return {'mode':mode,'freeze_sha256':digest,'python':check_environment(),
            'approval_sha256':sha(ROOT/'provenance/PARENT_EXECUTION_APPROVAL.json'),
            'preexec_receipt_sha256':sha(ROOT/'provenance/PREEXEC_DRIVE_RECEIPT.json')}

def get_schedule(mode):
    path='selftests/toy/SCHEDULE.json' if mode=='toy' else 'freeze/SCHEDULE.json'
    schedule=read(path)
    assert [e['schedule_index'] for e in schedule]==list(range(1,len(schedule)+1))
    assert len({e['call_id'] for e in schedule})==len(schedule)
    if mode=='toy':
        assert len(schedule)==2
        assert [(e['proxy'],e['seed'],e['max_iterations']) for e in schedule]==[('E',0,25),('G',0,25)]
        assert all(e['instance_id']=='TOY_NON_EUCLIDEAN' for e in schedule)
    else:
        protocol=read('freeze/PROTOCOL.json')
        expected=[(f,s,p,b) for f in protocol['fields'] for s in (0,1,2) for p in ('E','G') for b in (25,250)]
        assert len(schedule)==144
        assert [(e['instance_id'],e['seed'],e['proxy'],e['max_iterations']) for e in schedule]==expected
    return schedule

def load_payload(entry,mode):
    if mode=='toy':
        data=read('selftests/toy/FIXTURE.json')
    else:
        rel=f"input/{entry['instance_id']}.json"
        assert sha(ROOT/rel)==read('input/IDENTITIES.json')['fields'][entry['instance_id']]['input_sha256']
        data=read(rel)
    assert data['instance_id']==entry['instance_id']
    payload={k:data[k] for k in ('coordinates','demands','capacity','K')}
    payload.update(distance_matrix=data['matrices'][entry['proxy']],seed=entry['seed'],max_iterations=entry['max_iterations'])
    return payload
