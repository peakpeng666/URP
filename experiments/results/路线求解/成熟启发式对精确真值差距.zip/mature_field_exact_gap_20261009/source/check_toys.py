"""Saved-only end-to-end toy verification; no PyVRP import or native construction."""
import itertools,json
from common import ROOT,read,save,sha,now
from gates import verify_toy_freeze,get_schedule
from endpoint_core import validate_saved,route_cost

def main():
    verify_toy_freeze();schedule=get_schedule('toy');problem=read('selftests/toy/FIXTURE.json')
    slots=read('selftests/toy/raw/ALL_PLANNED_SLOTS.json');outer=read('selftests/toy/raw/EXECUTOR_FINISHED.json')
    assert len(slots)==2 and outer['cleanup']['quiescent'] and not outer['ledger_errors']
    assert outer['supervisor_returncode']==0 and not outer['external_timeout']
    assert outer['known_spawned']==2 and outer['unknown_spawned_slots']==0
    rows=[];parameter_sets=[]
    for entry,record in zip(schedule,slots):
        assert record['schedule']==entry and record['status']=='UNREVIEWED_PROCESS_SUCCESS'
        assert record['process_spawned'] is True and record['child_reaped'] is True and record['returncode']==0
        assert sha(ROOT/record['stdout'])==record['stdout_sha256'] and sha(ROOT/record['stderr'])==record['stderr_sha256']
        answer=read(record['stdout']);checked=validate_saved(problem,entry,answer);parameter_sets.append(answer['default_solve_params'])
        # Exactly three unlabeled pair partitions on four unit-demand clients.
        partitions=[[[0,1,j,0],[0,*[x for x in range(2,5) if x!=j],0]] for j in range(2,5)]
        oracle=min(route_cost(problem['matrices'][entry['proxy']],routes) for routes in partitions)
        rows.append({'call_id':entry['call_id'],'status':'PASS','matrix_entries':25,'reported_cost':answer['reported_cost'],
                     'recomputed_cost':checked[entry['proxy']],'toy_exact_cost':oracle,'toy_gap':checked[entry['proxy']]-oracle,
                     'routes':checked['routes'],'num_iterations':answer['num_iterations'],'model_instances':1,'solver_calls':1})
    assert parameter_sets[0]==parameter_sets[1]
    save(ROOT/'selftests/toy/DEFAULT_PARAMS.json',{'parameters':parameter_sets[0],'source':'Both authorized toy calls using fresh unmodified official SolveParams'})
    assert [r['toy_exact_cost'] for r in rows]==[54,82]
    report={'utc':now(),'status':'PASS','toy_calls_planned':2,'toy_calls_spawned':2,'toy_solver_calls':2,
            'toy_model_instances':2,'explicit_solution_constructions':0,'new_solver_calls_in_this_check':0,
            'formal_solver_calls':0,'native_matrix_entries_total':50,'full_outer_supervisor_worker_chain':True,
            'native_internal_solution_constructions':'Not counted;2 refers to explicit ProblemData model instances, not solver-internal objects',
            'rows':rows,'freeze_sha256':sha(ROOT/'selftests/toy/FROZEN.json')}
    save(ROOT/'selftests/toy/VERIFIED.json',report);print(json.dumps(report))
if __name__=='__main__':main()
