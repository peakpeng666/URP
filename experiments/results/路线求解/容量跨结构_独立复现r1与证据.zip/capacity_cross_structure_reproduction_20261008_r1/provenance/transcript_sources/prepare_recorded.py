from common import *
import random,math,platform
from functools import lru_cache
protocol={
 'utc':utc(),'base_seed':202610081156,'scope':'new cross-structure exploratory experiment, not old panel replication',
 'families':['heterogeneous_triples','heterogeneous_quads','bounded_global_composition','nontrigger_high_slack'],
 'K_values':[4,7,10,13],'Q_values_by_family':[[37,61,89],[41,67,97],[43,71,101],[47,73,103]],
 'instances':48,'arms':['capacity_solver','pruned_solver','waste_solver'],
 'endpoints':[{'name':'partition_256','nodes':256},{'name':'partition_4096','nodes':4096},{'name':'initialize_256','nodes':256}],
 'calls':432,'seed_formula':'base_seed + family_index*100000 + K*1000 + Q; geometry seed+1e6; permutation seed+2e6',
 'triple_generation':'each bin is a uniformly sampled ordered positive composition of Q-1 into 3 parts, each >=floor(Q/6)',
 'quad_generation':'bin b has a uniformly sampled composition of Q-(1+b%3) into 4 parts, each >=floor(Q/10)',
 'global_generation':'uniform ordered bounded composition of K*(Q-1) into 3K parts in [floor(Q/6),floor(Q/2)]; exact integer completion counts; no feasibility rejection or filtering',
 'control_generation':'each bin uniformly partitions Q-ceil(Q/4) into 3 parts, each >=floor(Q/10); U=K*ceil(Q/4)>=K*(m-1) guarantees bound cannot trigger',
 'geometry':'independent uniform[0,100]^2 depot and customers; shuffle labels separately',
 'structure_definition':'(K,Q,sorted demands), plus normalized demands/Q signature, no duplicate or old structure accepted; violation aborts without reseed',
 'no_outcome_filtering':True,'no_optional_stopping':True,'no_main_reruns':True,'no_tuning':True,
 'schedule':'instance deterministic family/K/Q order, endpoint order fixed, arm order rotation by (instance_index+endpoint_index)%3',
 'witness_policy':'truth witnesses generated only for 3 construction families; stored separately; call runner may not read witness or oracle artifacts',
 'oracle_main':'independent subset DP for all n<=16, no extension based on observed status',
 'toy_oracle':'all multisets n=0..5 demand0..5 crossed all sorted residual vectors K=1..3 residual0..5, plus 2000 random nonnegative states seed base+3e6, n0..8 K1..4 room0..12 demand0..10',
 'budgets':{'per_call_cpu_hard_seconds':1,'per_call_wall_hard_seconds':2,'per_call_memory_MiB':256,'parent_memory_MiB':1024,'main_global_wall_seconds':1000,'main_sum_child_cpu_stop_seconds':450,'oracle_cpu_hard_seconds':45,'oracle_wall_hard_seconds':90,'audit_cpu_hard_seconds':60,'audit_wall_hard_seconds':90,'total_cpu_limit_seconds':600,'total_wall_limit_seconds':1200,'delta_limit':100000},
 'timing':'single execution per input/arm/endpoint, descriptive microbenchmark; includes pruning trace overhead in measured partition CPU, not robust speed claim',
 'claims':'all failures classified; node_limit is unknown, not infeasible. Mathematical bound proof separate from empirical benefit. No official CVRP, real-world generalization, or statistical population effect claim.',
 'offline_only':True,'python':platform.python_version()
}
dump(ROOT/'freeze/PRE_GENERATION.json',protocol)

def composition(total,k,lower,rng):
 rem=total-k*lower
 cuts=sorted(rng.sample(range(rem+k-1),k-1))
 bounds=[-1]+cuts+[rem+k-1]
 return [bounds[i+1]-bounds[i]-1+lower for i in range(k)]

def bounded_composition(total,n,lo,hi,rng):
 @lru_cache(None)
 def count(k,s):
  if k==0:return int(s==0)
  if s<k*lo or s>k*hi:return 0
  return sum(count(k-1,s-d) for d in range(lo,hi+1))
 ds=[]
 for left in range(n,0,-1):
  pick=rng.randrange(count(left,total))
  for d in range(lo,hi+1):
   ways=count(left-1,total-d)
   if pick<ways:ds.append(d);total-=d;break
   pick-=ways
 assert total==0
 return ds

old=Path(read(ROOT/'provenance/SOURCE_ORIGIN.json')['old_root'])
def signatures(x):
 ds=sorted(x['demands'][1:]);q=x['capacity'];k=x['K']
 return [k,q,ds], [k,[[d//math.gcd(d,q),q//math.gcd(d,q)] for d in ds]]
old_sigs=set();old_norm=set()
for f in (old/'input').glob('*.json'):
 a,b=signatures(read(f));old_sigs.add(digest(a));old_norm.add(digest(b))
seen=set();norm=set();matrix=[];schedule=[]
for fi,fam in enumerate(protocol['families']):
 for k in protocol['K_values']:
  for q in protocol['Q_values_by_family'][fi]:
   seed=protocol['base_seed']+fi*100000+k*1000+q;rng=random.Random(seed)
   groups=[];ds=[]
   if fi in [0,1,3]:
    width=4 if fi==1 else 3
    for b in range(k):
     slack=1 if fi==0 else 1+b%3 if fi==1 else math.ceil(q/4)
     lower=q//6 if fi==0 else q//10
     parts=composition(q-slack,width,lower,rng)
     groups.append(list(range(len(ds)+1,len(ds)+1+width)));ds.extend(parts)
   else:ds=bounded_composition(k*(q-1),3*k,q//6,q//2,rng)
   n=len(ds);perm=list(range(1,n+1));random.Random(seed+2000000).shuffle(perm)
   dem=[0]*(n+1)
   for oldid,newid in enumerate(perm,1):dem[newid]=ds[oldid-1]
   geo=random.Random(seed+1000000);xy=[[geo.uniform(0,100),geo.uniform(0,100)] for _ in range(n+1)]
   ident=f'S{len(matrix)+1:02d}-{fam}-K{k}-Q{q}'
   raw={'instance_id':ident,'n':n,'capacity':q,'K':k,'family':fam,'seed':seed,'coordinates':xy,'demands':dem}
   sig,normsig=signatures(raw);s,ns=digest(sig),digest(normsig)
   assert s not in seen|old_sigs and ns not in norm|old_norm
   seen.add(s);norm.add(ns);U=k*q-sum(dem);m=min(ds)
   assert U>0
   if fi==3:assert U>=k*(m-1)
   dump(ROOT/'input'/f'{ident}.json',raw)
   if groups:dump(ROOT/'witness'/f'{ident}.json',{'groups':[[perm[j-1] for j in g] for g in groups],'source':'generator membership; withheld from all solver calls'})
   entry={'instance_id':ident,'family':fam,'n':n,'K':k,'Q':q,'seed':seed,'demands_sorted':sorted(ds),'slack':U,'min_demand':m,'nontrigger_sufficient':U>=k*(m-1),'structure_sha256':s,'normalized_structure_sha256':ns,'has_witness':bool(groups)}
   matrix.append(entry)
   for ei,endpoint in enumerate(protocol['endpoints']):
    shift=(len(matrix)-1+ei)%3;arms=protocol['arms'][shift:]+protocol['arms'][:shift]
    for arm in arms:schedule.append({'call_id':f'C{len(schedule)+1:04d}','instance_id':ident,'endpoint':endpoint['name'],'node_limit':endpoint['nodes'],'arm':arm})
dump(ROOT/'freeze/MATRIX.json',matrix);dump(ROOT/'freeze/SCHEDULE.json',schedule)
files=[p for folder in ['source','input','witness','provenance','freeze'] for p in (ROOT/folder).rglob('*') if p.is_file() and '__pycache__' not in str(p)]
files.append(ROOT/'reports/PROOF.txt')
dump(ROOT/'freeze/PRE_RUN_FREEZE.json',{'utc':utc(),'sha256':{str(p.relative_to(ROOT)):sha(p) for p in sorted(files)},'instances':len(matrix),'unique_structures':len(seen),'unique_normalized_structures':len(norm),'old_structure_overlap':0,'old_normalized_structure_overlap':0,'calls':len(schedule)})
print('Frozen:',len(matrix),'independent structures;',len(schedule),'calls.')
