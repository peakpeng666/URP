from pathlib import Path
import json,hashlib,datetime,sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[1]
def read(p): return json.loads(Path(p).read_text())
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def dump(p,v):
 with Path(p).open('x') as f: json.dump(v,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
def digest(v): return hashlib.sha256(json.dumps(v,separators=(',',':'),sort_keys=True).encode()).hexdigest()
def verify_freeze():
 f=read(ROOT/'freeze/PRE_RUN_FREEZE.json')
 for p,h in f['sha256'].items(): assert sha(ROOT/p)==h,p
 return f
