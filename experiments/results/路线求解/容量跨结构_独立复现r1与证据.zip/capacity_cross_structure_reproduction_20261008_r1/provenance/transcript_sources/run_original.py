import os,subprocess,resource,signal,time,sys
from common import *
resource.setrlimit(resource.RLIMIT_CPU,(60,60));resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3));signal.alarm(1000)
cpu=time.process_time();wall=time.perf_counter();freeze=verify_freeze();schedule=read(ROOT/'freeze/SCHEDULE.json')
dump(ROOT/'raw/STARTED.json',{'utc':utc(),'freeze_sha256':sha(ROOT/'freeze/PRE_RUN_FREEZE.json'),'calls_scheduled':len(schedule),'witness_access':'parent verifies only file digests; isolated solver children never read witness files','execution':'serial subprocess, exactly once per call'})
with (ROOT/'raw/results.jsonl').open('x') as f:
 for item in schedule:
  if time.perf_counter()-wall>990 or resource.getrusage(resource.RUSAGE_CHILDREN).ru_utime+resource.getrusage(resource.RUSAGE_CHILDREN).ru_stime>450:
   dump(ROOT/'raw/ABORTED.json',{'utc':utc(),'next_call':item,'reason':'global_budget','no_retry':True});sys.exit(2)
  before=resource.getrusage(resource.RUSAGE_CHILDREN);tw=time.perf_counter()
  p=subprocess.Popen([sys.executable,'-B',str(ROOT/'source/call_once.py'),json.dumps(item)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
  timeout=False
  try:stdout,stderr=p.communicate(timeout=2.5)
  except subprocess.TimeoutExpired:p.kill();stdout,stderr=p.communicate();timeout=True
  after=resource.getrusage(resource.RUSAGE_CHILDREN)
  (ROOT/'raw/calls'/f"{item['call_id']}.stdout").write_text(stdout)
  (ROOT/'raw/calls'/f"{item['call_id']}.stderr").write_text(stderr)
  if p.returncode==0:
   record=json.loads(stdout)
  else:
   record={**item,'status':'TIMEOUT' if timeout or p.returncode in [-9,-14,-24] else 'PROCESS_ERROR','diagnostic':None,'groups':None,'output':None,'input_sha256':sha(ROOT/'input'/f"{item['instance_id']}.json"),'measured_cpu_seconds':None,'measured_wall_seconds':None,'error':stderr}
  record.update({'process_returncode':p.returncode,'process_cpu_seconds':after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime,'process_wall_seconds':time.perf_counter()-tw,'children_maxrss_KiB':after.ru_maxrss})
  f.write(json.dumps(record,allow_nan=False)+'\n');f.flush();os.fsync(f.fileno())
  if int(item['call_id'][1:])%72==0:print(item['call_id'],'complete',flush=True)
ru=resource.getrusage(resource.RUSAGE_CHILDREN)
dump(ROOT/'raw/FINISHED.json',{'utc':utc(),'calls':len(schedule),'parent_cpu_seconds':time.process_time()-cpu,'children_cpu_seconds':ru.ru_utime+ru.ru_stime,'wall_seconds':time.perf_counter()-wall,'children_maxrss_KiB':ru.ru_maxrss,'results_sha256':sha(ROOT/'raw/results.jsonl'),'no_reruns':True})
print('All scheduled calls sealed.')
