import resource,signal,sys,time,importlib,json
resource.setrlimit(resource.RLIMIT_CPU,(1,1));resource.setrlimit(resource.RLIMIT_AS,(256*1024**2,256*1024**2));signal.alarm(2)
sys.dont_write_bytecode=True
from common import *
item=json.loads(sys.argv[1]);raw=read(ROOT/'input'/f"{item['instance_id']}.json")
mod=importlib.import_module(item['arm']);out=None;diag=None;groups=None;budget_usage=None;error=None
cpu=time.process_time();wall=time.perf_counter()
if item['endpoint'].startswith('partition'):
 try:
  groups,diag=mod.bounded_partition(raw['demands'],raw['capacity'],raw['K'],item['node_limit'])
  status='SUCCESS' if groups is not None else diag['outcome']
 except Exception as e:status='ERROR';error={'type':type(e).__name__,'message':str(e)}
else:
 inst=mod.instance_for(raw);budget=mod.Budget(100000,1,2)
 try:
  matrix=mod.matrix_for(inst,budget);routes,cost,diag=mod.initialize(raw,inst,matrix,budget)
  out=mod.output_for(routes,cost);status='SUCCESS'
 except mod.InitFailure as e:
  diag=getattr(e,'detail',None);status='INITFAIL';error={'type':type(e).__name__,'message':str(e)}
 except mod.StopBudget as e:status='BUDGET';error={'type':type(e).__name__,'message':str(e)}
 except Exception as e:status='ERROR';error={'type':type(e).__name__,'message':str(e)}
 budget_usage=budget.snapshot()
record={**item,'input_sha256':sha(ROOT/'input'/f"{item['instance_id']}.json"),'status':status,'diagnostic':diag,'groups':groups,'output':out,'budget':budget_usage,'error':error,'measured_cpu_seconds':time.process_time()-cpu,'measured_wall_seconds':time.perf_counter()-wall,'witness_files_opened':0,'local_search_calls':0}
print(json.dumps(record,allow_nan=False))
