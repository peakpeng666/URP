"""Declared oracle restored from prior visible tool arguments, new reproduction only."""
from common import *
import itertools,random,resource,signal,time,functools,sys
if '--execute-authorized' not in sys.argv:
 raise SystemExit('Preparation only; oracle requires authorized execution after verified archive.')
resource.setrlimit(resource.RLIMIT_CPU,(45,45));resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3));signal.alarm(90)
cpu=time.process_time();wall=time.perf_counter();verify_freeze()
extra=read(ROOT/'freeze/ORACLE_SOURCE_FREEZE.json')
assert sha(ROOT/'source/oracle.py')==extra['oracle_source_sha256']
claim_namespace=read(ROOT/'freeze/REPRODUCTION_PROTOCOL.json')['claim_namespace']
from waste_solver import waste_capacity_test,bounded_partition as new_partition
from pruned_solver import tight_capacity_test,bounded_partition as tight_partition
from capacity_solver import bounded_partition as base_partition

@functools.lru_cache(maxsize=100000)
def subset_assignment(ds,rs):
 ds=tuple(x for x in ds if x>0);n=len(ds);full=(1<<n)-1
 sums=[0]*(1<<n)
 for mask in range(1,1<<n):
  bit=mask&-mask;sums[mask]=sums[mask^bit]+ds[bit.bit_length()-1]
 reach={0}
 for room in rs:
  nxt=set()
  for used in reach:
   left=full^used;part=left
   while True:
    if sums[part]<=room:nxt.add(used|part)
    if part==0:break
    part=(part-1)&left
  reach=nxt
 return full in reach

def homogeneous_subset_dp(ds,q):
 n=len(ds);size=1<<n;dp=[None]*size;dp[0]=(1,0)
 if max(ds,default=0)>q:return {'feasible':False,'minimum_bins':None,'reason':'oversize'}
 for mask in range(1,size):
  best=(n+1,q+1)
  for j,d in enumerate(ds):
   if mask>>j&1:
    bins,load=dp[mask^(1<<j)]
    candidate=(bins,load+d) if load+d<=q else (bins+1,d)
    if candidate<best:best=candidate
  dp[mask]=best
 return {'minimum_bins':dp[-1][0] if n else 0,'last_bin_load':dp[-1][1],'subset_states':size,'dp_digest':digest(dp)}

count=pruned=feasible=bad=0
with (ROOT/'raw/toy_states.jsonl').open('x') as f:
 def test(ds,rs,kind):
  global count,pruned,feasible,bad
  truth=subset_assignment(tuple(ds),tuple(rs));w=waste_capacity_test(ds,rs)[0];t=tight_capacity_test(ds,rs)[0]
  count+=1;pruned+=w;feasible+=truth;bad+=int((w or t) and truth)
  f.write(json.dumps({'kind':kind,'demands':ds,'residual':rs,'oracle_feasible':truth,'new_reject':w,'tight_reject':t})+'\n')
 for n in range(6):
  for ds in itertools.combinations_with_replacement(range(6),n):
   for k in range(1,4):
    for rs in itertools.combinations_with_replacement(range(6),k):test(ds,rs,'exhaustive')
 rng=random.Random(202610081156+3000000)
 for i in range(2000):
  ds=sorted(rng.randrange(11) for _ in range(rng.randrange(9)))
  rs=sorted(rng.randrange(13) for _ in range(rng.randrange(1,5)))
  test(ds,rs,'random')
assert bad==0
full_count=0
with (ROOT/'raw/toy_partition.jsonl').open('x') as f:
 for n in range(5):
  for ds in itertools.combinations_with_replacement(range(5),n):
   for q in range(1,7):
    for k in range(1,4):
     truth=subset_assignment(ds,(q,)*k);observed=[]
     for solver in [base_partition,tight_partition,new_partition]:
      bins,diag=solver([0,*ds],q,k,1000000);assert not diag['limit_reached'];observed.append(bins is not None)
     assert observed==[truth]*3
     f.write(json.dumps({'demands':ds,'Q':q,'K':k,'oracle_feasible':truth,'solver_feasible':observed})+'\n');full_count+=1
for ds,rs in [([-1],[1]),([1],[-1])]:
 try:waste_capacity_test(ds,rs)
 except ValueError:pass
 else:raise AssertionError('negative domain not rejected')
main=[]
for item in read(ROOT/'freeze/MATRIX.json'):
 if item['n']<=16:
  raw=read(ROOT/'input'/f"{item['instance_id']}.json");answer=homogeneous_subset_dp(raw['demands'][1:],raw['capacity'])
  answer['feasible']=answer['minimum_bins'] is not None and answer['minimum_bins']<=raw['K']
  main.append({'instance_id':raw['instance_id'],'input_sha256':sha(ROOT/'input'/f"{item['instance_id']}.json"),**answer})
dump(ROOT/'reports/ORACLE.json',{'utc':utc(),'claim_namespace':claim_namespace,'phase':'reproduction_after_workspace_loss_not_original_recovery','passed':True,'toy_states':count,'toy_feasible':feasible,'new_rejected':pruned,'false_rejections':bad,'full_partition_tests':full_count,'main_exact':main,'cpu_seconds':time.process_time()-cpu,'wall_seconds':time.perf_counter()-wall,'maxrss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'toy_states_sha256':sha(ROOT/'raw/toy_states.jsonl'),'toy_partition_sha256':sha(ROOT/'raw/toy_partition.jsonl'),'independence':'subset allocation / homogeneous subset DP; no solver DFS/bound used for truth'})
print('Oracle passed:',count,'states;',full_count,'three-arm full partitions;',len(main),'main exact checks.')
