import os,subprocess,resource,signal,time,sys,math
if "--execute-authorized" not in sys.argv:
 raise SystemExit("Preparation snapshot only. Wait for parent authorization after verified private archive; no solver executed.")
from common import *
resource.setrlimit(resource.RLIMIT_CPU,(60,60));resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3));signal.alarm(1000)
cpu=time.process_time();wall=time.perf_counter();initial_ru=resource.getrusage(resource.RUSAGE_CHILDREN);initial_child_cpu=initial_ru.ru_utime+initial_ru.ru_stime;call_cpu=[];freeze=verify_freeze();schedule=read(ROOT/'freeze/SCHEDULE.json');claim_namespace=read(ROOT/'freeze/REPRODUCTION_PROTOCOL.json')['claim_namespace']
dump(ROOT/'raw/STARTED.json',{'utc':utc(),'freeze_sha256':sha(ROOT/'freeze/PRE_RUN_FREEZE.json'),'claim_namespace':claim_namespace,'calls_scheduled':len(schedule),'children_cpu_initial_seconds':initial_child_cpu,'witness_access':'parent verifies only file digests; isolated solver children never read witness files','execution':'serial subprocess, exactly once per call'})
with (ROOT/'raw/results.jsonl').open('x') as f:
 for item in schedule:
  if time.perf_counter()-wall>990 or resource.getrusage(resource.RUSAGE_CHILDREN).ru_utime+resource.getrusage(resource.RUSAGE_CHILDREN).ru_stime-initial_child_cpu>450:
   dump(ROOT/'raw/ABORTED.json',{'utc':utc(),'next_call':item,'reason':'global_budget','no_retry':True});sys.exit(2)
  before=resource.getrusage(resource.RUSAGE_CHILDREN);tw=time.perf_counter()
  p=subprocess.Popen([sys.executable,'-B',str(ROOT/'source/call_once.py'),json.dumps(item)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
  timeout=False
  try:stdout,stderr=p.communicate(timeout=2.5)
  except subprocess.TimeoutExpired:p.kill();stdout,stderr=p.communicate();timeout=True
  after=resource.getrusage(resource.RUSAGE_CHILDREN)
  (ROOT/'raw/calls'/f"{item['call_id']}.stdout").write_text(stdout)
  (ROOT/'raw/calls'/f"{item['call_id']}.stderr").write_text(stderr)
  if p.returncode==0:
   record=json.loads(stdout)
  else:
   record={**item,'status':'TIMEOUT' if timeout or p.returncode in [-9,-14,-24] else 'PROCESS_ERROR','diagnostic':None,'groups':None,'output':None,'input_sha256':sha(ROOT/'input'/f"{item['instance_id']}.json"),'measured_cpu_seconds':None,'measured_wall_seconds':None,'error':stderr}
  record.update({'process_returncode':p.returncode,'process_cpu_seconds':after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime,'process_wall_seconds':time.perf_counter()-tw,'children_maxrss_KiB':after.ru_maxrss})
  record['claim_namespace']=claim_namespace;call_cpu.append(record['process_cpu_seconds'])
  f.write(json.dumps(record,allow_nan=False)+'\n');f.flush();os.fsync(f.fileno())
  if int(item['call_id'][1:])%72==0:print(item['call_id'],'complete',flush=True)
ru=resource.getrusage(resource.RUSAGE_CHILDREN)
dump(ROOT/'raw/FINISHED.json',{'utc':utc(),'claim_namespace':claim_namespace,'calls':len(schedule),'parent_cpu_seconds':time.process_time()-cpu,'children_cpu_seconds':ru.ru_utime+ru.ru_stime-initial_child_cpu,'children_cpu_initial_seconds':initial_child_cpu,'children_cpu_final_absolute_seconds':ru.ru_utime+ru.ru_stime,'per_call_cpu_sum_seconds':math.fsum(call_cpu),'wall_seconds':time.perf_counter()-wall,'children_maxrss_KiB':ru.ru_maxrss,'results_sha256':sha(ROOT/'raw/results.jsonl'),'no_reruns':True})
print('All scheduled calls sealed.')
