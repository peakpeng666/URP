"""No solver or oracle imports; hash, syntax, and witness checks only."""
from common import *
import ast,collections,math
freeze=verify_freeze();known=read(ROOT/'provenance/KNOWN_PRIOR_INPUT_HASHES.json')['hashes'];matrix=read(ROOT/'freeze/MATRIX.json');schedule=read(ROOT/'freeze/SCHEDULE.json')
assert len(matrix)==48 and len(schedule)==432
checks=[]
for item in matrix:
 p=ROOT/'input'/f"{item['instance_id']}.json";raw=read(p);actual=sha(p)
 prior=known.get(item['instance_id']);assert prior is None or actual==prior,(item['instance_id'],actual,prior)
 assert raw['K']*raw['capacity']>sum(raw['demands'])
 if item['has_witness']:
  groups=read(ROOT/'witness'/f"{item['instance_id']}.json")['groups']
  assert sorted(j for g in groups for j in g)==list(range(1,raw['n']+1))
  assert len(groups)<=raw['K']
  assert all(sum(raw['demands'][j] for j in g)<=raw['capacity'] for g in groups)
 checks.append({'instance_id':item['instance_id'],'current_input_sha256':actual,'prior_input_sha256':prior,'prior_match':actual==prior if prior else None})
syntax=[]
for p in sorted((ROOT/'source').rglob('*.py')):
 ast.parse(p.read_text());syntax.append(str(p.relative_to(ROOT)))
assert not list((ROOT/'raw').rglob('*.*'))
dump(ROOT/'reports/PREPARATION_CHECKS.json',{'utc':utc(),'claim_namespace':read(ROOT/'freeze/REPRODUCTION_PROTOCOL.json')['claim_namespace'],'state':'PREPARATION_ONLY_NOT_EXECUTED','solver_calls':0,'oracle_calls':0,'inputs':48,'known_prior_hash_matches':sum(x['prior_match'] is True for x in checks),'unknown_prior_input_hashes':sum(x['prior_match'] is None for x in checks),'input_checks':checks,'syntax_checked':syntax,'main_results_present':False,'no_performance_filtering':True,'generated_witnesses_validated':36,'prior_raw_not_recovered':True})
print('Preparation only: 48 inputs generated; 12 historical hashes match; remaining 36 historical hashes unavailable; solver/oracle calls=0.')
