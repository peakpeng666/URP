"""Post-run independent recomputation; no solver imports, no experiment reruns."""
from common import *
import collections,csv,math,resource,signal,time
resource.setrlimit(resource.RLIMIT_CPU,(60,60));resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3));signal.alarm(90)
cpu=time.process_time();wall=time.perf_counter();freeze=verify_freeze()
claim=read(ROOT/'freeze/REPRODUCTION_PROTOCOL.json')['claim_namespace'];matrix=read(ROOT/'freeze/MATRIX.json');items={x['instance_id']:x for x in matrix};schedule=read(ROOT/'freeze/SCHEDULE.json')
rows=[json.loads(s) for s in (ROOT/'raw/results.jsonl').read_text().splitlines()];assert len(rows)==len(schedule)==432
arms=['capacity_solver','pruned_solver','waste_solver'];endpoints=['partition_256','partition_4096','initialize_256']
for r,s in zip(rows,schedule):
 assert r['claim_namespace']==claim
 assert all(r[k]==v for k,v in s.items())
 assert r['input_sha256']==sha(ROOT/'input'/f"{r['instance_id']}.json")

def part(r):return (r['diagnostic'] or {}).get('capacity_partition',{}) if r['endpoint'].startswith('initialize') else r['diagnostic'] or {}
def groups_check(raw,groups):
 ids=[j for g in groups for j in g];assert sorted(ids)==list(range(1,raw['n']+1));assert len(groups)<=raw['K']
 loads=[sum(raw['demands'][j] for j in g) for g in groups];assert all(x<=raw['capacity'] for x in loads)
 return loads

output_checks=[];witness_checks=[];prune_checks=[];metrics=[];controls=[]
for item in matrix:
 raw=read(ROOT/'input'/f"{item['instance_id']}.json")
 if item['has_witness']:
  groups=read(ROOT/'witness'/f"{item['instance_id']}.json")['groups']
  witness_checks.append({'instance_id':item['instance_id'],'loads':groups_check(raw,groups)})
for r in rows:
 raw=read(ROOT/'input'/f"{r['instance_id']}.json");item=items[r['instance_id']];p=part(r)
 if r['status']=='SUCCESS':
  c={'call_id':r['call_id']}
  if r['endpoint'].startswith('partition'):c['loads']=groups_check(raw,r['groups'])
  else:
   out=r['output'];routes=out['routes'];assert all(z[0]==z[-1]==0 and len(z)>=3 for z in routes)
   c['loads']=groups_check(raw,[z[1:-1] for z in routes]);xy=raw['coordinates']
   dist=math.fsum(math.hypot(xy[a][0]-xy[b][0],xy[a][1]-xy[b][1]) for z in routes for a,b in zip(z,z[1:]))
   assert math.isclose(dist,out['reported_cost'],abs_tol=1e-8,rel_tol=1e-10);c['recomputed_cost']=dist;c['cost_residual']=dist-out['reported_cost']
  output_checks.append(c)
 traces=p.get('prune_trace',[]);assert len(traces)==p.get('prunes',0)
 for t in traces:
  ds=t['remaining'];rs=t['residual'];groups=t['groups'];assigned=[j for g in groups for j in g]
  assert len(groups)==len(rs)==raw['K'];assert len(set(assigned))==len(assigned)
  assert rs==[raw['capacity']-sum(raw['demands'][j] for j in g) for g in groups]
  order=sorted(range(1,raw['n']+1),key=lambda j:(-raw['demands'][j],j))
  assert sorted(assigned)==sorted(order[:t['depth']]);assert ds==[raw['demands'][j] for j in order[t['depth']:]]
  U=sum(rs)-sum(ds);positive=[x for x in ds if x>0];m=min(positive) if positive else None;W=sum(x for x in rs if m and 0<x<m)
  assert U<0 or W>U
  if r['arm']=='pruned_solver':assert U==0
  prune_checks.append({'call_id':r['call_id'],'entered_node':t['entered_node'],'depth':t['depth'],'U':U,'W':W,'m':m})
 if item['nontrigger_sufficient']:
  assert p.get('prunes',0)==0;controls.append(r['call_id'])
 if p:assert p['nodes']<=r['node_limit']
 metrics.append({'call_id':r['call_id'],'instance_id':r['instance_id'],'claim_namespace':claim,'family':item['family'],'n':item['n'],'K':item['K'],'Q':item['Q'],'slack':item['slack'],'endpoint':r['endpoint'],'arm':r['arm'],'status':r['status'],'partition_outcome':p.get('outcome','NOT_ENTERED'),'nodes':p.get('nodes',0),'prunes':p.get('prunes',0),'measured_cpu_seconds':r['measured_cpu_seconds'],'measured_wall_seconds':r['measured_wall_seconds'],'partition_cpu_seconds':p.get('cpu_seconds',r['measured_cpu_seconds'] if r['endpoint'].startswith('partition') else 0),'process_cpu_seconds':r['process_cpu_seconds'],'process_wall_seconds':r['process_wall_seconds'],'delta_evaluations':(r.get('budget') or {}).get('deltas')})
summary={};paired={}
for ep in endpoints:
 summary[ep]={}
 for arm in arms:
  rr=[x for x in metrics if x['endpoint']==ep and x['arm']==arm]
  summary[ep][arm]={'success':sum(x['status']=='SUCCESS' for x in rr),'total':len(rr),'statuses':dict(collections.Counter(x['status'] for x in rr)),'nodes':sum(x['nodes'] for x in rr),'prunes':sum(x['prunes'] for x in rr),'cpu_seconds':math.fsum(x['measured_cpu_seconds'] or 0 for x in rr),'zero_cpu_observations':sum(x['measured_cpu_seconds']==0 for x in rr),'by_family':{fam:{'success':sum(x['status']=='SUCCESS' for x in rr if x['family']==fam),'total':sum(x['family']==fam for x in rr),'nodes':sum(x['nodes'] for x in rr if x['family']==fam),'prunes':sum(x['prunes'] for x in rr if x['family']==fam)} for fam in sorted({x['family'] for x in rr})}}
 pp=[]
 for item in matrix:
  rr={x['arm']:x for x in metrics if x['endpoint']==ep and x['instance_id']==item['instance_id']};b,t,w=[rr[a] for a in arms]
  assert (b['status'],b['nodes'])==(t['status'],t['nodes'])
  pp.append({'instance_id':item['instance_id'],'family':item['family'],'baseline_status':b['status'],'new_status':w['status'],'baseline_nodes':b['nodes'],'new_nodes':w['nodes'],'node_delta':w['nodes']-b['nodes'],'rescued':b['status']!='SUCCESS' and w['status']=='SUCCESS','lost':b['status']=='SUCCESS' and w['status']!='SUCCESS'})
 paired[ep]={'rescues':[p for p in pp if p['rescued']],'losses':[p for p in pp if p['lost']],'all':pp}
for item in matrix:
 for ep in endpoints:
  rr=[next(x for x in rows if x['instance_id']==item['instance_id'] and x['endpoint']==ep and x['arm']==a) for a in arms[:2]]
  assert all(rr[0][k]==rr[1][k] for k in ['status','groups','output'])
oracle=read(ROOT/'reports/ORACLE.json');assert oracle['claim_namespace']==claim and oracle['passed']
assert oracle['toy_states_sha256']==sha(ROOT/'raw/toy_states.jsonl') and oracle['toy_partition_sha256']==sha(ROOT/'raw/toy_partition.jsonl')
main_exact={x['instance_id']:x for x in oracle['main_exact']}
for r in rows:
 if r['instance_id'] in main_exact:
  truth=main_exact[r['instance_id']]['feasible']
  if r['status']=='SUCCESS':assert truth
  if r['status']=='SEARCH_EXHAUSTED':assert not truth
finish=read(ROOT/'raw/FINISHED.json');call_cpu=math.fsum(r['process_cpu_seconds'] for r in rows)
assert math.isclose(call_cpu,finish['children_cpu_seconds'],abs_tol=1e-9)
assert math.isclose(finish['children_cpu_final_absolute_seconds']-finish['children_cpu_initial_seconds'],call_cpu,abs_tol=1e-9)
assert finish['results_sha256']==sha(ROOT/'raw/results.jsonl')
assert len({digest(x['demands_sorted']) for x in matrix})==48
old=Path(read(ROOT/'provenance/SOURCE_ORIGIN.json')['old_root'])
for p,h in read(ROOT/'provenance/OLD_FILES_BEFORE.json').items():assert sha(old/p)==h
with (ROOT/'reports/METRICS.csv').open('x',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(metrics[0]));w.writeheader();w.writerows(metrics)
for name,obj in [('SUMMARY',summary),('PAIRED',paired),('OUTPUT_CHECKS',output_checks),('WITNESS_CHECKS',witness_checks),('PRUNE_CHECKS',prune_checks)]:dump(ROOT/'reports'/f'{name}.json',obj)
dump(ROOT/'reports/ANALYSIS_CHECKS.json',{'utc':utc(),'claim_namespace':claim,'passed':True,'independent_logic_not_external_review':True,'schedule_calls':432,'success_outputs':len(output_checks),'witnesses':len(witness_checks),'prune_states':len(prune_checks),'nontrigger_calls':len(controls),'main_exact_instances':len(main_exact),'old_source_archive_unchanged':True,'known_prior_input_hash_matches':12,'unknown_prior_input_hashes':36,'hard_timeouts':sum(r['status']=='TIMEOUT' for r in rows),'errors':sum(r['status'] in ['ERROR','BUDGET','PROCESS_ERROR'] for r in rows),'per_call_cpu_sum_seconds':call_cpu,'cpu_baseline_consistency':True,'cpu_seconds':time.process_time()-cpu,'wall_seconds':time.perf_counter()-wall})
print(json.dumps({'checked_outputs':len(output_checks),'checked_prunes':len(prune_checks),'cpu_baseline_consistent':True,'rescues':{e:len(paired[e]['rescues']) for e in endpoints}}))
