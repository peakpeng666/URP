import copy,unittest
from endpoints import audit_ledger,paired_record,summarize,comparable_model
class Tests(unittest.TestCase):
 def test_nested_reserved_schedule_fields(self):
  e={'call_id':'case','event_kind':'evil','phase':2,'repeat_index':1};r={'call_id':'case','schedule':e}
  a=[{'event_kind':'STARTED','utc':'t','call_id':'case','schedule':e},{'event_kind':'FINISHED','utc':'t','call_id':'case','schedule':e,'result':r}]
  self.assertEqual(audit_ledger([e],a,[r])['status'],'PASS')
  b=copy.deepcopy(a);b[0]['event_kind']=1;self.assertNotEqual(audit_ledger([e],b,[r])['status'],'PASS')
 def test_missing_and_duplicate(self):
  e={'call_id':'x'};v=audit_ledger([e],[],[]);self.assertEqual(v['planned_denominator'],1);self.assertFalse(v['calls'][0]['ledger_valid'])
  r={'call_id':'x','schedule':e};self.assertIn('DUPLICATE_RESULT',audit_ledger([e],[],[r,r])['errors'])
 def test_failure_retained(self):
  good={'instance_id':'x','seed':0,'valid_feasible':True,'status':'FEASIBLE','cost':100,'vehicles':4};bad={**good,'valid_feasible':False,'status':'NO_FEASIBLE_INCUMBENT_WITHIN_BUDGET','cost':None,'vehicles':None}
  p=paired_record(good,bad);self.assertFalse(p['valid_pair']);self.assertIsNone(p['delta_cost']);s=summarize([p]);self.assertEqual(s['planned_pairs'],1);self.assertEqual(s['valid_pairs'],0);self.assertEqual(s['control_feasible'],1);self.assertIsNone(s['delta_cost']['mean'])
 def test_sign_and_equal_weight(self):
  c={'instance_id':'x','seed':0,'valid_feasible':True,'status':'FEASIBLE','cost':100,'vehicles':4};t={**c,'cost':90,'vehicles':3};p=paired_record(c,t);self.assertEqual((p['delta_cost'],p['relative_delta_pct'],p['delta_vehicles']),(-10,-10.,-1));self.assertEqual(summarize([p])['cost_direction_counts']['treatment_lower'],1)
 def test_only_fleet_change(self):
  c={'num_vehicles':10,'vehicle':{'num_available':10,'capacity':[3]},'x':1};t=copy.deepcopy(c);t['num_vehicles']=3;t['vehicle']['num_available']=3;self.assertTrue(comparable_model(c,t,3));t['x']=2;self.assertFalse(comparable_model(c,t,3))
if __name__=='__main__':unittest.main()
