"""Compute saved paired endpoints only after authenticated RAW archive/readback."""
import json,collections,statistics,math
from common import ROOT,read,save,receipt,verify_frozen,verify_old,sha,now
from endpoints import audit_call,audit_ledger,paired_record,summarize,validate_solution

def independent_match(expected,actual,path='root'):
    if isinstance(expected,dict):
        assert isinstance(actual,dict),path
        for k,v in expected.items():
            assert k in actual,path+'.'+k
            independent_match(v,actual[k],path+'.'+k)
    elif isinstance(expected,list):
        assert isinstance(actual,list) and len(expected)==len(actual),path
        for i,(x,y) in enumerate(zip(expected,actual)):independent_match(x,y,f'{path}[{i}]')
    elif isinstance(expected,float):
        assert type(actual) in (int,float) and math.isclose(expected,actual,rel_tol=1e-12,abs_tol=1e-12),path
    else:assert expected==actual,path

def main():
    verify_frozen();verify_old();r=receipt('RAW_UNREVIEWED')
    independent=read('independent_supervision/results/SAVED_FLEET_AUDIT.json')
    assert independent['status']=='SAVED_EVIDENCE_AUDITED'
    assert independent['raw_archive_sha256']==r['sha256']
    assert independent['frozen_files_sha256']==sha(ROOT/'freeze/FROZEN_FILES.json')
    assert independent['planned_calls']==36 and len(independent['rows'])==36
    schedule=read('freeze/SCHEDULE.json');baseline=read('freeze/BASELINE_A.json');tasks=read('freeze/TASKS.json')
    results=[json.loads(x)for x in (ROOT/'raw/results.jsonl').read_text().splitlines()] if (ROOT/'raw/results.jsonl').exists()else[]
    attempts=[json.loads(x)for x in (ROOT/'raw/attempts.jsonl').read_text().splitlines()] if (ROOT/'raw/attempts.jsonl').exists()else[]
    ledger=audit_ledger(schedule,attempts,results);assert not ledger['errors'],ledger
    ids=[v['call_id']for v in results];assert len(ids)==len(set(ids))
    byid={v['call_id']:v for v in results};bc={(v['instance_id'],v['seed']):v for v in baseline['cases']};lm={v['call_id']:v for v in ledger['calls']};pairs=[]
    for entry in schedule:
        problem=read('input/'+entry['instance_id']+'.json');control=bc[(entry['instance_id'],entry['seed'])];cp=ROOT/control['control_file'];assert sha(cp)==control['stdout_sha256']
        ca=json.loads(cp.read_text());standard={**problem,'K':len(problem['demands'])-1};cv=validate_solution(standard,ca['routes'],ca['reported_cost'])
        assert cv['valid'] and cv['reported_cost_checked'] and cv['cost']==control['cost'] and cv['nonempty_routes']==control['vehicles']
        c={'call_id':control['call_A'],'instance_id':entry['instance_id'],'seed':entry['seed'],'valid_feasible':True,'status':'FEASIBLE','cost':cv['cost'],'vehicles':cv['nonempty_routes'],'stdout_sha256':sha(cp),'source':'historical_preselected_repeat_A'}
        item=byid.get(entry['call_id']);answer=None;read_errors=[]
        if item:
            try:
                p=ROOT/item['stdout'];assert p.is_relative_to(ROOT/'raw/calls');assert sha(p)==item['stdout_sha256'];answer=json.loads(p.read_text())
            except Exception as exc:read_errors.append('OUTPUT_READ_OR_HASH_ERROR:'+repr(exc))
        ta=audit_call(problem,entry,item,answer,ca)
        ta['errors'].extend(read_errors+lm[entry['call_id']]['errors'])
        if ta['errors']:
            ta.update(valid_feasible=False,cost=None,vehicles=None)
            if ta['status'] in ('FEASIBLE','NO_FEASIBLE_INCUMBENT_WITHIN_BUDGET'):ta['status']='INVALID_OUTPUT_OR_LEDGER'
        pairs.append(paired_record(c,ta))
    assert len(pairs)==36
    per=[]
    for task in tasks:
        rows=[p for p in pairs if p['instance_id']==task['instance_id']];assert len(rows)==3
        per.append({'instance_id':task['instance_id'],'K_ref':task['K'],'n_customers':task['n_customers'],**summarize(rows)})
    overall=summarize(pairs);complete=[v for v in per if v['valid_pairs']==3]
    overall['complete_instance_equal_weighted']={'included_instances':len(complete),'planned_instances':12,'rule':'Only3/3 valid-pair instances; omitted instances remain listed and retained in overall feasibility denominator.',**{f'mean_{k}':statistics.mean(v[k]['mean']for v in complete)if complete else None for k in ('delta_cost','relative_delta_pct','delta_vehicles')}}
    summary={'utc':now(),'question':'At-most-K_ref modeling effect under fixed25ILSiterations','treatment_call_denominator':36,'historical_control_denominator':36,'no_standard_arm_rerun':True,'control_selection':'Preselected repeat A, never best A/B','overall':overall,'raw_archive_sha256':r['sha256'],'frozen_files_sha256':sha(ROOT/'freeze/FROZEN_FILES.json'),'ledger_status':ledger['status'],'limit':'Same observed12X panel and3seeds; noncontemporaneous historical controls; no time comparison, optimality, solver superiority, or agricultural deployment inference. Infeasible incumbent is a budget failure, not mathematical infeasibility.','control_provenance_disclosure':'Old raw had phase-key event label collision, missed by precheck and independently detected postrun. A qualified read-only recovery verified72 calls/36pairs; this project uses only preselected A and preserves old evidence. New logs use distinct event_kind with nested schedule and preexec production-schema replay.'}
    assert independent['observed_records']==len(results)
    assert len({(v['instance_id'],v['seed']) for v in independent['rows']})==36
    for own,ours in zip(independent['rows'],pairs):
        independent_match({k:own[k] for k in ('instance_id','seed','valid_pair','delta_cost','relative_delta_pct','delta_vehicles')},ours,'paired')
        for arm in ('control','treatment'):
            independent_match({k:own[arm][k] for k in ('status','valid_feasible','cost','vehicles')},ours[arm],arm)
    independent_match(independent['per_instance'],per,'per_instance')
    independent_match(independent['overall'],overall,'overall')
    summary['independent_audit_sha256']=sha(ROOT/'independent_supervision/results/SAVED_FLEET_AUDIT.json')
    summary['independent36_pairs_and12_instance_metrics_match']=True
    save(ROOT/'reports/LEDGER_AUDIT.json',ledger);save(ROOT/'reports/PAIRED_RESULTS.json',pairs);save(ROOT/'reports/PER_INSTANCE.json',per);save(ROOT/'reports/SUMMARY.json',summary)
    o=overall;lines=['固定ILS预算下的参考车数上限派生对照','',f"新增处理臂可行 {o['treatment_feasible']}/36；历史标准控制可行 {o['control_feasible']}/36；有效配对 {o['valid_pairs']}/36。",'处理为at-most-K_ref，不要求恰好使用K_ref辆。K_ref由冻结原SOL实际非空路线数定义，全部具有独立验证的可行见证，未采用文件名k。','同12个已观察标准X输入、seed0/1/2、PyVRP0.14.0默认ILS、无warm start、25完整ILS迭代。唯一求解输入变化为车辆可用数。标准控制严格沿用已审repeat A，未按A/B择优，未补跑。','',f"仅对有效配对：成本差（处理−控制）均值 {o['delta_cost']['mean']}，中位数 {o['delta_cost']['median']}；相对差均值 {o['relative_delta_pct']['mean']}%；用车差均值 {o['delta_vehicles']['mean']}。",f"成本低于/等于/高于控制：{o['cost_direction_counts']}；失败类别：{o['treatment_statuses']}。",'以上均值明确以有效配对为条件，所有36个计划格、每题3seed和失败分母保留，详见PAIRED_RESULTS/PER_INSTANCE；全12汇总另列3/3完整题目的等题权均值及纳入数。','','解释边界','- 约束后的有限预算结果更低，不能证明受限问题的数学最优更低。可行域收缩不可能降低同一最小化问题的精确最优值。','- 未找到可行incumbent是短预算搜索失败；原SOL已给出可行见证，不能称数学无解。','-25迭代不代表等CPU、wall或基本操作量；历史控制非同期，不做跨时段计时性能比较。','-公开SOL仅为两问题均可行的参照锚点，不推最优或SOTA。两规则是同坐标、需求的声明派生对照，不是新独立真实数据或农业实际车队。','-原控制项目的phase键覆写与只读恢复已披露；旧raw/source不改。本项目新event_kind及嵌套schedule已在冻结前做正式schema全链重放。','','逐题结果']
    for v in per:lines.append(f"{v['instance_id']}：K_ref={v['K_ref']}，处理可行{v['treatment_feasible']}/3，有效对{v['valid_pairs']}/3，成本差均值{v['delta_cost']['mean']}，相对差均值{v['relative_delta_pct']['mean']}%，用车差均值{v['delta_vehicles']['mean']}。")
    with (ROOT/'reports/REPORT_ZH.txt').open('x')as f:f.write('\n'.join(lines)+'\n')
    print(json.dumps(summary,ensure_ascii=False))
if __name__=='__main__':main()
