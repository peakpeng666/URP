"""Saved-evidence only; no optimizer. Every scheduled case remains visible."""
import json,sys,hashlib,statistics,copy
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'independent_review'))
from independent_validator import validate_solution
COST_FIELDS=('current_cost','candidate_cost','best_cost');BOOL_FIELDS=('current_feas','candidate_feas','best_feas')

def hash_payload(problem,entry):
    p={k:problem[k] for k in ('coordinates','demands','capacity','K')};p.update(seed=entry['seed'],max_iterations=25)
    return hashlib.sha256(json.dumps(p,separators=(',',':')).encode()).hexdigest()

def audit_ledger(schedule,attempts,items):
    errors=[];expected={e['call_id']:e for e in schedule}
    if len(expected)!=len(schedule):errors.append('DUPLICATE_SCHEDULE_ID')
    byid={};events={cid:[] for cid in expected}
    for item in items:
        cid=item.get('call_id')
        if cid not in expected:errors.append('UNEXPECTED_RESULT')
        if cid in byid:errors.append('DUPLICATE_RESULT')
        byid[cid]=item
    for event in attempts:
        cid=event.get('call_id')
        if cid not in expected:errors.append('UNEXPECTED_EVENT');continue
        if event.get('schedule')!=expected[cid]:errors.append('EVENT_SCHEDULE_MISMATCH')
        kind=event.get('event_kind')
        if kind not in ('STARTED','FINISHED'):errors.append('INVALID_EVENT_KIND')
        required={'event_kind','utc','call_id','schedule'}|({'result'} if kind=='FINISHED' else set())
        if set(event)!=required:errors.append('EVENT_SCHEMA_MISMATCH')
        if kind=='FINISHED' and event.get('result')!=byid.get(cid):errors.append('FINISHED_RESULT_MISMATCH')
        events[cid].append(kind)
    per=[]
    for entry in schedule:
        cid=entry['call_id'];ev=events[cid];local=[]
        if ev!=['STARTED','FINISHED']:local.append('MISSING_OR_INVALID_START_FINISH_SEQUENCE')
        if cid not in byid:local.append('MISSING_RESULT')
        if cid in byid and byid[cid].get('schedule')!=entry:local.append('RESULT_SCHEDULE_MISMATCH')
        per.append({'call_id':cid,'events':ev,'errors':local,'ledger_valid':not local})
    observed_order=[e.get('call_id') for e in attempts if e.get('event_kind')=='STARTED']
    if observed_order!=[e['call_id']for e in schedule][:len(observed_order)]:errors.append('START_ORDER_MISMATCH')
    return {'status':'PASS' if not errors and all(v['ledger_valid'] for v in per) else 'INCOMPLETE_OR_INVALID','errors':errors,'planned_denominator':len(schedule),'observed_records':len(items),'observed_events':len(attempts),'calls':per}

def comparable_model(control,treatment,K_ref):
    expected=copy.deepcopy(control)
    expected['num_vehicles']=K_ref;expected['vehicle']['num_available']=K_ref
    return expected==treatment

def audit_call(problem,entry,item,answer,control_answer=None):
    out={'call_id':entry['call_id'],'instance_id':entry['instance_id'],'seed':entry['seed'],'valid_feasible':False,'status':'MISSING_RESULT' if item is None else 'INVALID_OUTPUT','process_status':item.get('status') if isinstance(item,dict) else None,'errors':[],'cost':None,'vehicles':None}
    errs=out['errors']
    if not isinstance(item,dict):errs.append('MISSING_RESULT');return out
    if item.get('status') in ('WALL_TIMEOUT','PROCESS_FAILURE_OR_CPU_LIMIT','CALL_ERROR_UNDETERMINED'):
        out['status']=item['status']
    if item.get('schedule')!=entry or item.get('call_id')!=entry['call_id']:errs.append('SCHEDULE_MISMATCH')
    if item.get('returncode')!=0 or not item.get('process_spawned') or not item.get('child_reaped'):errs.append('PROCESS_FAILURE')
    if item.get('status') not in ('UNREVIEWED_PROCESS_SUCCESS','UNREVIEWED_INFEASIBLE'):errs.append('PROCESS_STATUS_FAILURE')
    if item.get('payload_sha256')!=hash_payload(problem,entry):errs.append('PAYLOAD_HASH_MISMATCH')
    if not isinstance(answer,dict):errs.append('MISSING_OR_MALFORMED_OUTPUT');return out
    try:
        if (answer['solver'],answer['version'],answer['algorithm'])!=('PyVRP','0.14.0','ILS'):errs.append('SOLVER_MISMATCH')
        if answer['seed']!=entry['seed'] or type(answer['seed'])is not int:errs.append('SEED_MISMATCH')
        if answer['max_iterations']!=25 or answer['num_iterations']!=25:errs.append('BUDGET_MISMATCH')
        if answer['denied_io_events']!=[] or answer['reference_or_history_payload_fields']!=[]:errs.append('IO_OR_REFERENCE_VIOLATION')
        stats=answer['stats']
        if not(isinstance(stats,list) and len(stats)==25 and all(isinstance(d,dict) and set(d)==set(COST_FIELDS+BOOL_FIELDS) and all(type(d[k])is int for k in COST_FIELDS) and all(type(d[k])is bool for k in BOOL_FIELDS) for d in stats)):errs.append('STATS_SCHEMA')
        if len(answer['stats_runtime_per_iteration'])!=25:errs.append('RUNTIME_SCHEMA')
        if type(answer['solver_is_feasible'])is not bool or type(answer['solver_is_complete'])is not bool:errs.append('FLAGS_SCHEMA')
        native=answer['native_model_parameters']
        if native['num_vehicles']!=problem['K'] or native['vehicle']['num_available']!=problem['K']:errs.append('FLEET_MODEL_MISMATCH')
        if control_answer is not None:
            if not comparable_model(control_answer['native_model_parameters'],native,problem['K']):errs.append('OTHER_MODEL_CHANGE')
            if control_answer['default_solve_params']!=answer['default_solve_params']:errs.append('SOLVE_PARAMETER_CHANGE')
            if control_answer['model_matrix_sha256']!=answer['model_matrix_sha256']:errs.append('MATRIX_CHANGE')
            if control_answer['resource_limits']!=answer['resource_limits']:errs.append('RESOURCE_LIMIT_CHANGE')
        validation=validate_solution(problem,answer['routes'],answer['reported_cost'])
        out['route_validation']=validation;out['solver_is_feasible']=answer['solver_is_feasible'];out['solver_is_complete']=answer['solver_is_complete']
        if answer['reported_num_routes']!=validation['nonempty_routes'] or any(len(r)<3 for r in answer['routes']):errs.append('ROUTE_COUNT_MISMATCH')
        if answer['reported_duration_cost']!=0 or answer['reported_fixed_vehicle_cost']!=0:errs.append('NON_DISTANCE_COST')
        if answer['reported_distance']!=answer['internal_route_cost'] or validation['cost']!=answer['reported_distance']:errs.append('DISTANCE_MISMATCH')
        if answer['solver_is_feasible']:
            if not (validation['valid'] and validation['reported_cost_checked'] and validation['reported_cost_matches'] and type(answer['reported_cost'])is int and answer['solver_is_complete']):errs.append('INVALID_FEASIBLE_CLAIM')
            if item['status']!='UNREVIEWED_PROCESS_SUCCESS':errs.append('STATUS_FLAG_MISMATCH')
        else:
            if validation['feasible'] or answer['reported_cost']is not None or item['status']!='UNREVIEWED_INFEASIBLE':errs.append('INFEASIBLE_FLAG_MISMATCH')
        if not errs:
            if answer['solver_is_feasible']:out.update(valid_feasible=True,status='FEASIBLE',cost=validation['cost'],vehicles=validation['nonempty_routes'])
            else:out['status']='NO_FEASIBLE_INCUMBENT_WITHIN_BUDGET'
    except (KeyError,TypeError,ValueError)as exc:errs.append('SCHEMA_ERROR:'+repr(exc))
    return out

def paired_record(control,treatment):
    valid=control['valid_feasible'] and treatment['valid_feasible']
    return {'instance_id':treatment['instance_id'],'seed':treatment['seed'],'control':control,'treatment':treatment,'valid_pair':valid,'delta_cost':treatment['cost']-control['cost'] if valid else None,'relative_delta_pct':100*(treatment['cost']-control['cost'])/control['cost'] if valid else None,'delta_vehicles':treatment['vehicles']-control['vehicles'] if valid else None}

def summarize(rows):
    valid=[r for r in rows if r['valid_pair']]
    out={'planned_pairs':len(rows),'valid_pairs':len(valid),'control_feasible':sum(r['control']['valid_feasible']for r in rows),'treatment_feasible':sum(r['treatment']['valid_feasible']for r in rows),'treatment_statuses':{s:sum(r['treatment']['status']==s for r in rows)for s in sorted({r['treatment']['status']for r in rows})},'conditional_on_valid_pairs':True}
    for name in ('delta_cost','relative_delta_pct','delta_vehicles'):
        vals=[r[name]for r in valid];out[name]={'mean':statistics.mean(vals)if vals else None,'median':statistics.median(vals)if vals else None,'n':len(vals),'planned_denominator':len(rows)}
    out['cost_direction_counts']={s:sum((r['delta_cost']<0 if s=='treatment_lower' else r['delta_cost']>0 if s=='treatment_higher' else r['delta_cost']==0) for r in valid)for s in ['treatment_lower','treatment_equal','treatment_higher']}
    return out
