"""Read-only source examination and preparation; no optimizer import or call."""
import json,hashlib,re,sys,shutil,datetime
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OLD=Path('/workspace/shared/public_route_fixed_iterations_repro_20261009')
X=Path('/workspace/shared/public_route_larger_X_20261009')
sys.path.insert(0,str(ROOT/'independent_review'))
from independent_validator import validate_solution

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):
 with p.open('x')as f:json.dump(x,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
def parse_vrp(p):
 headers={};xy={};d={};dep=[];mode=None
 for line in p.read_text().splitlines():
  line=line.strip()
  if not line or line=='EOF':continue
  if line in ('NODE_COORD_SECTION','DEMAND_SECTION','DEPOT_SECTION'):mode=line;continue
  if mode=='NODE_COORD_SECTION':
   a,x,y=line.split();xy[int(a)]=[int(x),int(y)]
  elif mode=='DEMAND_SECTION':
   a,v=line.split();d[int(a)]=int(v)
  elif mode=='DEPOT_SECTION':dep.append(int(line))
  else:
   k,v=line.split(':',1);headers[k.strip()]=v.strip()
 n=int(headers['DIMENSION']);assert headers['TYPE']=='CVRP' and headers['EDGE_WEIGHT_TYPE']=='EUC_2D'
 assert list(sorted(xy))==list(range(1,n+1))==list(sorted(d)) and dep==[1,-1]
 return {'coordinates':[xy[i] for i in range(1,n+1)],'demands':[d[i] for i in range(1,n+1)],'capacity':int(headers['CAPACITY']),'K':n-1}
def parse_sol(p):
 routes=[];cost=None
 for line in p.read_text().splitlines():
  line=line.strip()
  if line.startswith('Route #'):
   m=re.fullmatch(r'Route #(\d+):\s*(.*)',line);assert m and int(m.group(1))==len(routes)+1
   body=list(map(int,m.group(2).split()));assert body
   routes.append([0]+body+[0])
  elif line.startswith('Cost '):assert cost is None;cost=int(line.split()[1])
  elif line:raise ValueError(line)
 assert routes and cost is not None
 return routes,cost

def main():
 tasks=json.loads((OLD/'freeze/TASKS.json').read_text());bas=json.loads((OLD/'reports/FIXED_ITERATION_BASELINE.json').read_text())
 assert len(tasks)==12 and len(bas['cases'])==36
 krefs=[];controls=[];newtasks=[]
 for t in tasks:
  name=t['instance_id'];vrp=X/'input'/f'{name}.vrp';sol=X/'references'/f'{name}.sol'
  assert sha(vrp)==sha(OLD/'input'/f'{name}.vrp')==t['source_instance_sha256']
  assert sha(sol)==t['source_reference_sha256']
  p=parse_vrp(vrp);existing=json.loads((OLD/'input'/f'{name}.json').read_text());assert all(p[k]==existing[k] for k in p)
  routes,cost=parse_sol(sol);kref=len(routes);restricted={**p,'K':kref}
  a=validate_solution(p,routes,cost);b=validate_solution(restricted,routes,cost)
  assert a['valid'] and b['valid'] and a['reported_cost_checked'] and b['nonempty_routes']==kref
  shutil.copyfile(vrp,ROOT/'input'/vrp.name);shutil.copyfile(sol,ROOT/'references'/sol.name)
  save(ROOT/'input'/f'{name}.json',{'instance_id':name,**restricted})
  krefs.append({'instance_id':name,'K_ref':kref,'source_vrp_sha256':sha(vrp),'source_sol_sha256':sha(sol),'source_sol_path':str(sol),'reported_reference_cost':cost,'standard_validation':a,'restricted_validation':b,'K_name_not_used':t['K_name_audit_only'],'closed_reference_routes':routes})
  newtasks.append({'instance_id':name,'selection_slot':t['selection_slot'],'n_customers':len(p['demands'])-1,'capacity':p['capacity'],'K':kref,'eligible':True,'errors':[],'source_instance_sha256':sha(vrp),'source_reference_sha256':sha(sol)})
  for c in [c for c in bas['cases'] if c['instance_id']==name]:
   assert c['pair_status']=='PASS' and c['selected_repeat']=='A' and c['eligible_as_verified_repeatability_baseline']
   raw=OLD/'raw/calls'/f"{c['call_A']}.stdout";answer=json.loads(raw.read_text());a=validate_solution(p,answer['routes'],answer['reported_cost']);assert a['valid'] and a['cost']==c['baseline']['cost']
   shutil.copyfile(raw,ROOT/'control'/raw.name)
   controls.append({'instance_id':name,'seed':c['seed'],'call_A':c['call_A'],'source_stdout':str(raw),'stdout_sha256':sha(raw),'control_file':str((ROOT/'control'/raw.name).relative_to(ROOT)),'cost':a['cost'],'vehicles':a['nonempty_routes'],'K':p['K'],'independent_validation':a})
 save(ROOT/'freeze/K_REF_VALIDATION.json',{'status':'PASS','definition':'Actual nonempty routes in existing independently feasible original SOL; filename k never defines the cap.','references':krefs})
 save(ROOT/'freeze/BASELINE_A.json',{'selection':'Only predetermined repeat A. No best-of-A/B selection, no standard-arm rerun.','source_baseline_path':str(OLD/'reports/FIXED_ITERATION_BASELINE.json'),'source_baseline_sha256':sha(OLD/'reports/FIXED_ITERATION_BASELINE.json'),'source_raw_archive_sha256':bas['raw_archive_sha256'],'cases':controls})
 save(ROOT/'freeze/TASKS.json',newtasks)
 for n in ['RUNTIME.json','DEFAULT_SOLVE_PARAMS.json','DETERMINISM_SETTINGS.json','RESTORE_MANIFEST.json','WHEELS.json','REUSED_WHEEL_ARCHIVE_RECEIPT.json','requirements.lock']:shutil.copyfile(OLD/'environment'/n,ROOT/'environment'/n)
 print(json.dumps({'status':'PASS','K_ref':[(v['instance_id'],v['K_ref'])for v in krefs],'baseline_records':len(controls)},indent=2))
if __name__=='__main__':main()
