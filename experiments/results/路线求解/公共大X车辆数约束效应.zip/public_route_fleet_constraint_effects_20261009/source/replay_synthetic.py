"""Read saved invented outputs under final endpoint logic; never call an optimizer."""
import copy,json
from common import ROOT,read,save,sha,now
from endpoints import audit_call,audit_ledger

def main():
    smoke=read('selftests/SUPERVISOR_INTEGRATION.json');records=[]
    for v in smoke['records'][:3]:
        item=v['record'];answer=read(item['stdout']);out=audit_call(v['fixture'],item['schedule'],item,answer)
        assert not out['errors'] and out['status']==v['audit']['status'],out
        records.append(out)
    x=smoke['records'][1];e=x['record']['schedule'];p=x['fixture'];item=x['record'];a=read(item['stdout']);checks=[]
    for status in ['WALL_TIMEOUT','PROCESS_FAILURE_OR_CPU_LIMIT','CALL_ERROR_UNDETERMINED']:
        bad=copy.deepcopy(item);bad.update(status=status,returncode=-9)
        out=audit_call(p,e,bad,None);assert out['status']==status and not out['valid_feasible'];checks.append({'fault':status,'status':out['status']})
    out=audit_call(p,e,None,None);assert out['status']=='MISSING_RESULT';checks.append({'fault':'missing','status':out['status']})
    bad=copy.deepcopy(a);bad['reported_cost']+=1;out=audit_call(p,e,item,bad);assert out['status']=='INVALID_OUTPUT' and not out['valid_feasible'];checks.append({'fault':'wrong_cost','status':out['status']})
    bad=copy.deepcopy(a);bad['native_model_parameters']['vehicle']['num_available']+=1;out=audit_call(p,e,item,bad);assert 'FLEET_MODEL_MISMATCH'in out['errors'];checks.append({'fault':'wrong_fleet','status':out['status']})
    d=ROOT/'selftests/integration';items=[json.loads(x)for x in (d/'results.jsonl').read_text().splitlines()];events=[json.loads(x)for x in (d/'attempts.jsonl').read_text().splitlines()]
    ledger=audit_ledger(smoke['schedule'],events,items);assert ledger['status']=='PASS'
    save(ROOT/'selftests/FINAL_ENDPOINT_SAVED_REPLAY.json',{'status':'PASS','utc':now(),'additional_optimizer_calls':0,'reason':'Pre-freeze failure category refinement; original actual supervisor smoke output and execution-time hashes retained. Replayed exact saved output and complete formal event schema under final endpoints. Production worker/launch/logger unchanged.','source_sha256':{n:sha(ROOT/'source'/n)for n in ['worker.py','run_once.py','endpoints.py','report.py','replay_synthetic.py']},'records':records,'ledger':ledger,'injected_saved_output_checks':checks})
    print('PASS saved-only full ledger and endpoint replay, with6 failure checks')
if __name__=='__main__':main()
