"""Production event schema, logger, limited Popen path, and saved replay on invented data."""
import json,signal,resource
from common import ROOT,read,save,now,sha
from run_once import logged_call,execute_call
from endpoints import audit_call,audit_ledger

def run_in_limited_supervisor(limits):
    assert limits=={'AS_bytes':[512*1024**2,1536*1024**2],'CPU_seconds':[30,30]}
    signal.alarm(180)
    dest=ROOT/'selftests/integration';dest.mkdir(exist_ok=False);calls=dest/'calls';calls.mkdir()
    python=read('environment/RUNTIME.json')['python_executable'];records=[];schedule=[]
    fixtures=[{'instance_id':'INVENTED_524_CAPPED','coordinates':[[0,0]]+[[i%31,(i*17)%29] for i in range(1,524)],'demands':[0]+[1]*523,'capacity':25,'K':22},
              {'instance_id':'INVENTED_TIGHT_CAP','coordinates':[[0,0],[1,0],[2,0],[0,1],[0,2]],'demands':[0,1,1,1,1],'capacity':2,'K':2},
              {'instance_id':'INVENTED_IMPOSSIBLE_FOR_SCHEMA_ONLY','coordinates':[[0,0],[1,0],[0,1]],'demands':[0,2,2],'capacity':3,'K':1}]
    for seed,p in enumerate(fixtures):
        e={'call_id':f'FIXTURE_s{seed}_Kref','instance_id':p['instance_id'],'seed':seed,'max_iterations':25,'treatment':'at_most_K_ref','schedule_index':len(schedule)+1}
        schedule.append(e);payload={k:v for k,v in p.items()if k!='instance_id'};payload.update(seed=seed,max_iterations=25)
        item=logged_call(e,payload,python,calls,dest);answer=json.loads((ROOT/item['stdout']).read_text());audit=audit_call(p,e,item,answer)
        assert not audit['errors'],audit
        assert answer['resource_limits']=={'inherited':limits,'effective':{'AS_bytes':[1536*1024**2,1536*1024**2],'CPU_seconds':[15,15]}}
        if seed==1:assert audit['valid_feasible'],audit
        if seed==2:assert audit['status']=='NO_FEASIBLE_INCUMBENT_WITHIN_BUDGET',audit
        records.append({'fixture':p,'record':item,'audit':audit})
    e={'call_id':'FIXTURE_malformed','instance_id':'INVENTED_MALFORMED','seed':0,'max_iterations':25,'treatment':'at_most_K_ref','schedule_index':4};schedule.append(e)
    bad=logged_call(e,{'malformed':True},python,calls,dest);assert bad['status']=='PROCESS_FAILURE_OR_CPU_LIMIT' and bad['child_reaped'];records.append({'record':bad})
    duplicate=execute_call(e,{'malformed':True},python,calls);assert duplicate['status']=='CALL_ERROR_UNDETERMINED' and not duplicate['process_spawned']
    items=[json.loads(x)for x in (dest/'results.jsonl').read_text().splitlines()];events=[json.loads(x)for x in (dest/'attempts.jsonl').read_text().splitlines()]
    ledger=audit_ledger(schedule,events,items);assert ledger['status']=='PASS',ledger
    # Collision regression: even malicious/reserved schedule keys remain nested; no extra optimization.
    shadow={'call_id':'SHADOW','event_kind':'OVERRIDE','phase':2,'repeat_index':3};event={'event_kind':'STARTED','utc':'test','call_id':'SHADOW','schedule':shadow}
    assert event['event_kind']=='STARTED' and event['schedule']['event_kind']=='OVERRIDE'
    tampered=json.loads(json.dumps(events));tampered[0]['event_kind']=1
    assert audit_ledger(schedule,tampered,items)['status']!='PASS'
    incomplete=audit_ledger(schedule,events[:-2],items[:-1]);assert incomplete['planned_denominator']==4 and incomplete['status']!='PASS'
    signal.alarm(0)
    save(ROOT/'selftests/SUPERVISOR_INTEGRATION.json',{'status':'PASS','utc':now(),'scope':'Production schema, logged_call, execute_call and actual resource-limited supervisor replay; three invented25-iteration solver calls plus malformed-input failure and exclusive-output guard. Impossible invented fixture tests failure schema only and is not part of formal panel.','public_optimizer_calls':0,'synthetic_optimizer_calls':3,'supervisor_limits':limits,'schedule':schedule,'ledger_audit':ledger,'records':records,'duplicate_output_guard':duplicate,'tampered_event_rejected':True,'missing_record_denominator_retained':True,'reserved_key_collision_safe':True,'source_sha256':{n:sha(ROOT/'source'/n)for n in ['worker.py','run_once.py','synthetic_integration.py','endpoints.py']}})
    print('PASS full production-schema invented supervisor replay; zero public calls')
