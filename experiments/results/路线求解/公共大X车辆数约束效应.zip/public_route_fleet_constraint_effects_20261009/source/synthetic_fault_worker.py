"""Invented failure injection only. Never used by the formal supervisor schedule."""
import sys,json,time,os
from worker import configure_worker_limits
limits=configure_worker_limits()
payload=json.load(sys.stdin)
assert set(payload)=={'synthetic_fault'} and payload['synthetic_fault'] in ('wall_timeout','cpu_limit','as_limit')
print(json.dumps({'synthetic_only':True,'pid':os.getpid(),'resource_limits':limits}),flush=True)
if payload['synthetic_fault']=='wall_timeout':time.sleep(60)
elif payload['synthetic_fault']=='as_limit':
    try:
        block=bytearray(1600*1024**2)
    except MemoryError:
        print(json.dumps({'expected_memory_error':True}),flush=True);sys.exit(23)
    raise RuntimeError('AS limit did not block oversized allocation')
else:
    value=0
    while True:value=(value+1)%1000003
