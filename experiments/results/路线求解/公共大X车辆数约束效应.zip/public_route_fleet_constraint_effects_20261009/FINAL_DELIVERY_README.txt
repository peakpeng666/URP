Read reports/REPORT_ZH.txt and independent_supervision/SUPERVISION_ZH.txt first.

This is a declared same-input modeling comparison, with36 new at-most-K_ref treatment calls and36 predetermined historical repeat-A controls, PyVRP0.14.0 defaultILS/25iterations. Standard controls were not rerun or selected by performance.

Formal treatment feasibility is33/36 versus36/36 controls. Conditional on33valid pairs/11complete instances out of12, mean relative cost difference is+2.63335% and mean vehicle difference is-0.60606. Three seed failures all belong toX-n524-k153 and have capacity violations. They remain in the36-call denominator and do not imply mathematical infeasibility: its original155-route SOL is independently feasible.

The full bundle retains the original raw, frozen source, authenticated PREEXEC/RAW receipts, independent checks, initial generated report and reader-only clarification. It also retains the independent audit's outer launch failure caused by unavailable /usr/bin/time; the same frozen audit code was subsequently run via a Python outer launcher. No optimizer reruns occurred. The historical control's earlier phase-key collision and qualified read-only recovery are explicitly disclosed.

No elapsed-time speed claim, exact-optimum or SOTA claim, new independent real-world dataset claim, or agricultural fleet deployment claim is made. Exact prior private archives restore the existing dependencies; no redundant wheel bundle was added. Old project indexes were not modified or replaced.
