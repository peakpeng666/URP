"""Independent fleet36 precheck: original bytes and saved evidence only. No solver imports/calls."""
from pathlib import Path
from collections import Counter
import ast, copy, datetime, hashlib, json, math, re, sys, zipfile
ROOT = Path(__file__).resolve().parents[2]
OLD = ROOT.parent / 'public_route_fixed_iterations_repro_20261009'
def load(p): return json.loads(Path(p).read_text())
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def require(x, why):
    if not x: raise ValueError(why)
def edge(a,b):
    s=sum((x-y)**2 for x,y in zip(a,b)); q=math.isqrt(s)
    return q + int(4*s >= (2*q+1)**2)
def vrp(path):
    h={}; xy={}; demands={}; depot=[]; section=None
    for raw in Path(path).read_text().splitlines():
        line=raw.strip()
        if not line: continue
        if line=='EOF': break
        if line in ('NODE_COORD_SECTION','DEMAND_SECTION','DEPOT_SECTION'): section=line; continue
        if section is None:
            k,v=line.split(':',1); require(k.strip() not in h,'duplicate header'); h[k.strip()]=v.strip()
        elif section=='NODE_COORD_SECTION':
            i,x,y=map(int,line.split());require(i not in xy,'duplicate coordinate');xy[i]=[x,y]
        elif section=='DEMAND_SECTION':
            i,d=map(int,line.split());require(i not in demands,'duplicate demand');demands[i]=d
        else: depot.extend(map(int,line.split()))
    n=int(h['DIMENSION']); q=int(h['CAPACITY'])
    require(h['TYPE']=='CVRP' and h['EDGE_WEIGHT_TYPE']=='EUC_2D','CVRP EUC_2D')
    require(sorted(xy)==sorted(demands)==list(range(1,n+1)),'identities')
    require(depot==[1,-1] and demands[1]==0 and q>0,'depot/capacity')
    require(all(0<=d<=q for d in demands.values()),'demands bounds')
    return {'instance_id':h['NAME'],'coordinates':[xy[i] for i in range(1,n+1)],'demands':[demands[i] for i in range(1,n+1)],'capacity':q,'K':n-1}
def sol(path):
    routes=[]; cost=None
    for raw in Path(path).read_text().splitlines():
        line=raw.strip()
        if not line: continue
        m=re.fullmatch(r'Route #(\d+):\s*(.*)',line)
        if m:
            require(int(m[1])==len(routes)+1,'SOL route numbering')
            body=list(map(int,m[2].split())); require(body,'SOL empty route'); routes.append([0,*body,0])
        else:
            m=re.fullmatch(r'Cost\s+(\d+)',line);require(m and cost is None,'SOL cost syntax');cost=int(m[1])
    require(routes and cost is not None,'SOL required content');return routes,cost
def route_check(p,routes,reported,feasible=True):
    served=[];cost=0;loads=[];errors=[];n=len(p['coordinates'])
    require(isinstance(routes,list),'route list')
    for r in routes:
        require(isinstance(r,list) and len(r)>=3 and all(type(v)is int and 0<=v<n for v in r),'route node schema')
        require(r[0]==r[-1]==0 and 0 not in r[1:-1],'closed route')
        served.extend(r[1:-1]); loads.append(sum(p['demands'][i] for i in r[1:-1]))
        cost+=sum(edge(p['coordinates'][a],p['coordinates'][b]) for a,b in zip(r,r[1:]))
    if Counter(served)!=Counter(range(1,n)):errors.append('COVERAGE')
    if any(v>p['capacity'] for v in loads):errors.append('CAPACITY')
    if len(routes)>p['K']:errors.append('FLEET')
    if feasible:require(not errors and type(reported)is int and reported==cost,'feasible route/cost violation '+str(errors))
    return {'cost':cost,'vehicles':len(routes),'loads':loads,'feasibility_errors':errors}
def funcs(path):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(Path(path).read_text()).body if isinstance(n,ast.FunctionDef)}
def main():
    expected_k=[26,14,13,19,16,11,21,13,72,39,21,155]
    tasks=load(ROOT/'freeze/TASKS.json'); schedule=load(ROOT/'freeze/SCHEDULE.json');base=load(ROOT/'freeze/BASELINE_A.json')
    require(len(tasks)==12 and len(schedule)==len(base['cases'])==36,'design counts')
    require(len({e['call_id'] for e in schedule})==36,'unique schedule')
    expected=[(t['instance_id'],s)for t in tasks for s in range(3)]
    require([(e['instance_id'],e['seed'])for e in schedule]==expected,'12 by 3 exact schedule')
    require(all(e['max_iterations']==25 and e['treatment']=='at_most_K_ref' and e['schedule_index']==i+1 for i,e in enumerate(schedule)),'schedule constants')
    require([(c['instance_id'],c['seed'])for c in base['cases']]==expected,'control order')
    receipt=load(ROOT/'provenance/CONTROL_FINAL_REVIEWED_DRIVE_RECEIPT.json')
    require(receipt['owner_only'] is True and receipt['shared'] is False and receipt['download_byte_identical'] and receipt['remote_readback_sha256_verified'],'private old receipt')
    archive=OLD.parent/(OLD.name+'_FINAL_REVIEWED.zip')
    require(sha(archive)==sha(receipt['download_path'])==receipt['sha256']==receipt['download_sha256'],'actual old archive bytes')
    refs=[]; controls=[]
    with zipfile.ZipFile(receipt['download_path']) as z:
        oldbase=z.read(OLD.name+'/reports/FIXED_ITERATION_BASELINE.json')
        require(hashlib.sha256(oldbase).hexdigest()==base['source_baseline_sha256']==sha(base['source_baseline_path']),'old baseline member')
        oldb={(c['instance_id'],c['seed']):c for c in json.loads(oldbase)['cases']}
        for idx,t in enumerate(tasks):
            name=t['instance_id']; p=vrp(ROOT/'input'/f'{name}.vrp');routes,cost=sol(ROOT/'references'/f'{name}.sol')
            require(len(routes)==expected_k[idx]==t['K'],'K_ref actual routes')
            p['K']=len(routes);require(p==load(ROOT/'input'/f'{name}.json'),'derived input only K')
            std=load(OLD/'input'/f'{name}.json');require(std=={**p,'K':len(p['demands'])-1},'only K changed')
            for kind,ext,key in [('input','vrp','source_instance_sha256'),('references','sol','source_reference_sha256')]:
                current=ROOT/kind/f'{name}.{ext}'; require(sha(current)==t[key],'source hash')
                # Original reference bytes are also independently retained in larger-X evidence.
                original=ROOT.parent/'public_route_larger_X_20261009'/kind/f'{name}.{ext}'
                require(current.read_bytes()==original.read_bytes(),'original byte identity')
            value=route_check(p,routes,cost); refs.append({'instance_id':name,'K_ref':len(routes),'cost':cost,'max_load':max(value['loads']),'capacity':p['capacity']})
            M=[[edge(a,b) for b in p['coordinates']]for a in p['coordinates']]
            matrix_sha=hashlib.sha256(json.dumps(M,separators=(',',':')).encode()).hexdigest()
            for c in [v for v in base['cases']if v['instance_id']==name]:
                b=oldb[name,c['seed']];require(b['selected_repeat']=='A' and b['call_A']==c['call_A'] and b['pair_status']=='PASS','fixed A identity')
                data=z.read(OLD.name+'/raw/calls/'+c['call_A']+'.stdout')
                require(data==(ROOT/c['control_file']).read_bytes()==Path(c['source_stdout']).read_bytes(),'A bytes vs authenticated FINAL member')
                require(hashlib.sha256(data).hexdigest()==c['stdout_sha256'],'A hash')
                a=json.loads(data);v=route_check(std,a['routes'],a['reported_cost'])
                require(v['cost']==c['cost'] and v['vehicles']==c['vehicles'],'A outcomes')
                require(a['num_iterations']==a['max_iterations']==25 and len(a['stats'])==25,'A iterations')
                require(a['model_matrix_sha256']==matrix_sha,'integer matrix hash')
                require(a['default_solve_params']==load(ROOT/'environment/DEFAULT_SOLVE_PARAMS.json'),'default params')
                require(a['native_model_parameters']['num_vehicles']==a['native_model_parameters']['vehicle']['num_available']==std['K'],'old fleet')
                controls.append({'call_id':c['call_A'],'sha256':c['stdout_sha256'],'cost':v['cost'],'vehicles':v['vehicles']})
    oldworker=(OLD/'source/worker.py').read_text(); worker=(ROOT/'source/worker.py').read_text()
    change_old="vehicle['num_available']==data.num_clients==payload['K']"
    change_new="vehicle['num_available']==payload['K'] and 1 <= payload['K'] <= data.num_clients"
    require(oldworker.count(change_old)==1 and oldworker.replace(change_old,change_new)==worker,'entire worker only allowed assertion diff')
    require(funcs(OLD/'source/run_once.py')['child_environment']==funcs(ROOT/'source/run_once.py')['child_environment'],'child environment AST')
    smoke=load(ROOT/'selftests/SUPERVISOR_INTEGRATION.json');replay=load(ROOT/'selftests/FINAL_ENDPOINT_SAVED_REPLAY.json')
    for n,h in smoke['source_sha256'].items():
        if n!='endpoints.py':require(sha(ROOT/'source'/n)==h,'executed source hash '+n)
    for n,h in replay['source_sha256'].items():require(sha(ROOT/'source'/n)==h,'final replay source '+n)
    events=[json.loads(x)for x in (ROOT/'selftests/integration/attempts.jsonl').read_text().splitlines()]
    items=[json.loads(x)for x in (ROOT/'selftests/integration/results.jsonl').read_text().splitlines()]
    require(len(events)==8 and len(items)==4,'full supervisor replay cardinality')
    for i,entry in enumerate(smoke['schedule']):
        item=items[i]; require(item['schedule']==entry and item['call_id']==entry['call_id'],'nested item')
        for j,kind in enumerate(('STARTED','FINISHED')):
            e=events[2*i+j];require(e['event_kind']==kind and e['schedule']==entry and e['call_id']==entry['call_id'],'complete sequential schema')
            require(set(e)=={'event_kind','utc','schedule','call_id'}|({'result'}if kind=='FINISHED'else set()),'event fields')
            if kind=='FINISHED':require(e['result']==item,'FINISHED result identity')
        for key in ('stdout','stderr'):require(sha(ROOT/item[key])==item[key+'_sha256'],'synthetic '+key+' bytes')
    for r in smoke['records'][:3]:
        a=load(ROOT/r['record']['stdout']);p=r['fixture'];v=route_check(p,a['routes'],a['reported_cost'],a['solver_is_feasible'])
        require(a['native_model_parameters']['num_vehicles']==a['native_model_parameters']['vehicle']['num_available']==p['K'],'actual synthetic native K')
        require(a['num_iterations']==25 and len(a['stats'])==25 and a['default_solve_params']==load(ROOT/'environment/DEFAULT_SOLVE_PARAMS.json'),'actual defaults and budget')
        require(bool(v['feasibility_errors'])== (not a['solver_is_feasible']),'saved infeasible recognized')
    # Use final endpoint code only for non-optimizer fault injection and saved-output replay.
    sys.path.insert(0,str(ROOT/'source'));from endpoints import audit_call,audit_ledger,paired_record,summarize
    require(audit_ledger(smoke['schedule'],events,items)['status']=='PASS','endpoint whole ledger')
    faults=[];p=smoke['records'][1]['fixture'];item=items[1];entry=item['schedule'];answer=load(ROOT/item['stdout'])
    for status in ('WALL_TIMEOUT','PROCESS_FAILURE_OR_CPU_LIMIT','CALL_ERROR_UNDETERMINED'):
        bad=copy.deepcopy(item);bad.update(status=status,returncode=-9)
        out=audit_call(p,entry,bad,None);require(out['status']==status and not out['valid_feasible'],'failure status retained');faults.append(status)
    require(audit_call(p,entry,None,None)['status']=='MISSING_RESULT','missing preserved')
    bad=copy.deepcopy(answer);bad['reported_cost']+=1; require(not audit_call(p,entry,item,bad)['valid_feasible'],'false cost rejected')
    bad=copy.deepcopy(answer);bad['native_model_parameters']['vehicle']['num_available']+=1; require('FLEET_MODEL_MISMATCH'in audit_call(p,entry,item,bad)['errors'],'wrong fleet rejected')
    good={'instance_id':'fixture','seed':0,'valid_feasible':True,'status':'FEASIBLE','cost':100,'vehicles':5}
    failed={**good,'valid_feasible':False,'status':'NO_FEASIBLE_INCUMBENT_WITHIN_BUDGET','cost':None,'vehicles':None}
    summary=summarize([paired_record(good,failed)]*36);require(summary['planned_pairs']==36 and summary['valid_pairs']==0 and summary['delta_cost']['mean']is None,'failure denominator36')
    old_files=load(ROOT/'freeze/OLD_FILES_BEFORE.json')['files']
    for p,m in old_files.items():require(Path(p).stat().st_size==m['bytes'] and sha(p)==m['sha256'],'old unchanged '+p)
    runtime=load(ROOT/'environment/RUNTIME.json')
    require(sha(Path(runtime['python_executable']).resolve())==runtime['python_binary_sha256'],'python binary identity')
    for f in runtime['installed_distribution_files']:require(Path(f['path']).stat().st_size==f['bytes'] and sha(f['path'])==f['sha256'],'installed file '+f['path'])
    require(not list((ROOT/'raw').rglob('*')),'zero formal calls before precheck')
    output={'status':'PASS_CANDIDATE_FOR_PRIMARY_SUPERVISOR_SIGNATURE','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'execution_authorized':False,'optimizer_calls_by_reviewer':0,'K_ref':refs,'control_calls_verified':len(controls),'controls':controls,'old_final_archive_sha256':receipt['sha256'],'source_scope':'Full worker bytes differ only by allowed native K assertion; child environment AST identical. No optimizer import or call by reviewer.','full_saved_supervisor_replay':{'events':8,'records':4,'native_model_default_budget_verified':3,'final_source_hashes_verified':True,'failure_types_checked':faults+['MISSING_RESULT','INVALID_COST','INVALID_FLEET','NO_FEASIBLE_INCUMBENT_WITHIN_BUDGET'],'all36_failure_denominator_checked':True},'old_files_verified_unchanged':len(old_files),'installed_distribution_files_verified':len(runtime['installed_distribution_files']),'reviewed_source_sha256':{str(p.relative_to(ROOT)):sha(p)for p in sorted((ROOT/'source').glob('*.py'))},'remaining_execution_gates':['Primary supervisor signature in freeze/INDEPENDENT_PRECHECK.json','Freeze and PREEXEC owner-only authenticated actual-byte readback','Root hash-bound approval and exclusive CPU window'],'interpretation_requirements':['K_ref is at-most, actual nonempty original SOL routes, never filename k','Historical control is fixed A only and cannot support elapsed-time fairness','Old phase-key collision and qualified read-only recovery must remain disclosed','Negative incumbent differences concern finite-budget search; constrained true optimum cannot be smaller','No feasible incumbent is distinct from invalid/process/guard failure; retain36 denominator'],'limitations':['Saved selftests establish actual worker/supervisor path, not future treatment feasibility','Primary supervisor alone signs official approval']}
    dest=ROOT/'independent_supervision/results/PRECHECK_CANDIDATE.json'
    with dest.open('x')as f:json.dump(output,f,ensure_ascii=False,indent=2);f.write('\n')
    print(json.dumps({k:output[k]for k in ('status','control_calls_verified','old_files_verified_unchanged','installed_distribution_files_verified','optimizer_calls_by_reviewer')}))
if __name__=='__main__': main()
