"""Independent fleet saved-result audit. Never imports solver or author endpoint/validator.

Parse original VRP/SOL; integer isqrt costs; authenticated RAW gate first.
Run with --results after private RAW readback, and --report after author report.
"""
from pathlib import Path
from collections import Counter
import datetime, hashlib, json, math, resource, signal, statistics, sys, zipfile
from precheck_saved import ROOT, OLD, load, sha, require, vrp, sol, edge, route_check

def compact(x):return json.dumps(x,separators=(',',':')).encode()
def expected_native(p):
    n=len(p['coordinates']);u=2**63-1
    v={'capacity':[p['capacity']],'num_available':p['K'],'start_depot':0,'end_depot':0,'fixed_cost':0,'unit_distance_cost':1,'unit_duration_cost':0,'unit_overtime_cost':0,'initial_load':[0],'reload_depots':[],'max_reloads':0,'max_trips':1,'max_overtime':0,'max_distance':u,'max_duration':u,'shift_duration':u,'start_late':u,'tw_early':0,'tw_late':u,'profile':0}
    c=[{'location':i,'delivery':[p['demands'][i]],'pickup':[0],'service_duration':0,'prize':0,'required':True,'release_time':0,'tw_early':0,'tw_late':u,'group':None}for i in range(1,n)]
    return {'locations':[{'x':q[0],'y':q[1]}for q in p['coordinates']],'num_vehicle_types':1,'num_profiles':1,'num_groups':0,'vehicle':v,'clients':c,'depot':{'location':0,'service_duration':0,'tw_early':0,'tw_late':u},'num_locations':n,'num_clients':n-1,'num_depots':1,'num_vehicles':p['K'],'num_shipments':0,'duration_matrix_all_zero':True}

def gate():
    r=load(ROOT/'provenance/RAW_UNREVIEWED_DRIVE_RECEIPT.json')
    require(r['owner_only']is True and r['shared']is False and r['remote_readback_sha256_verified'] and r['download_byte_identical'],'RAW private receipt')
    archive=ROOT.parent/(ROOT.name+'_RAW_UNREVIEWED.zip')
    require(sha(archive)==sha(r['download_path'])==r['sha256']==r['download_sha256'],'RAW actual bytes')
    frozen=load(ROOT/'freeze/FROZEN_FILES.json');require(sha(ROOT/'freeze/FROZEN_FILES.json')==r['frozen_files_sha256'],'RAW frozen identity')
    raw=load(ROOT/'raw/RAW_UNREVIEWED_MANIFEST.json')
    actual={str(p.relative_to(ROOT))for p in (ROOT/'raw').rglob('*')if p.is_file() and '__pycache__'not in p.parts}
    require(actual==set(raw['files'])|{'raw/RAW_UNREVIEWED_MANIFEST.json'},'raw exact set')
    with zipfile.ZipFile(r['download_path'])as z:
        for rel,meta in (frozen['files']|raw['files']).items():
            p=ROOT/rel;require(p.stat().st_size==meta['bytes'] and sha(p)==meta['sha256'],'retained bytes '+rel)
            require(z.read(ROOT.name+'/'+rel)==p.read_bytes(),'RAW member byte identity '+rel)
        require(z.read(ROOT.name+'/freeze/FROZEN_FILES.json')==(ROOT/'freeze/FROZEN_FILES.json').read_bytes(),'freeze member')
        require(z.read(ROOT.name+'/raw/RAW_UNREVIEWED_MANIFEST.json')==(ROOT/'raw/RAW_UNREVIEWED_MANIFEST.json').read_bytes(),'RAW manifest member')
    for p,m in load(ROOT/'freeze/OLD_FILES_BEFORE.json')['files'].items():require(Path(p).stat().st_size==m['bytes'] and sha(p)==m['sha256'],'old unchanged '+p)
    return r

def answer_check(p,a,seed):
    require((a['solver'],a['version'],a['algorithm'])==('PyVRP','0.14.0','ILS'),'solver identity')
    require(type(a['seed'])is int and a['seed']==seed and a['max_iterations']==a['num_iterations']==25,'seed/budget')
    require(a['denied_io_events']==a['reference_or_history_payload_fields']==[],'reference/IO')
    require(a['native_model_parameters']==expected_native(p),'full native model')
    require(a['default_solve_params']==load(ROOT/'environment/DEFAULT_SOLVE_PARAMS.json'),'defaults')
    require(a['resource_limits']=={'inherited':{'AS_bytes':[512*1024**2,1536*1024**2],'CPU_seconds':[30,30]},'effective':{'AS_bytes':[1536*1024**2]*2,'CPU_seconds':[15,15]}},'resource limits')
    fields={'current_cost','candidate_cost','best_cost','current_feas','candidate_feas','best_feas'}
    require(len(a['stats'])==len(a['stats_runtime_per_iteration'])==25,'stats count')
    for d in a['stats']:
        require(set(d)==fields and all(type(d[k])is(bool if k.endswith('_feas')else int)for k in fields),'stats schema')
    require(type(a['solver_is_feasible'])is bool and type(a['solver_is_complete'])is bool,'feasible schema')
    M=[[edge(x,y)for y in p['coordinates']]for x in p['coordinates']]
    require(a['model_matrix_sha256']==hashlib.sha256(compact(M)).hexdigest(),'exact integer native matrix')
    v=route_check(p,a['routes'],a['reported_cost'],a['solver_is_feasible'])
    require(a['reported_num_routes']==v['vehicles'],'reported fleet')
    require(a['reported_distance']==a['internal_route_cost']==v['cost'],'distance identity')
    require(a['reported_duration_cost']==a['reported_fixed_vehicle_cost']==0,'other cost')
    require(a['solver_is_complete']==('COVERAGE'not in v['feasibility_errors']),'complete flag')
    require(a['solver_is_feasible']==(not v['feasibility_errors']),'feasibility claim')
    if not a['solver_is_feasible']:require(a['reported_cost']is None,'infeasible objective must be null')
    require(len(a['native_routes'])==len(a['routes']),'native route length')
    for r,n,l in zip(a['routes'],a['native_routes'],v['loads']):
        require(n['distance']==sum(M[x][y]for x,y in zip(r,r[1:])) and n['delivery']==[l],'native distance/load')
        require(n['is_feasible']==(l<=p['capacity']) and n['num_trips']==1 and n['vehicle_type']==n['start_depot']==n['end_depot']==0,'native feasibility/type')
        require(len(n['activities'])==len(r),'activities count')
        for j,(node,b)in enumerate(zip(r,n['activities'])):
            depot=j in (0,len(r)-1)
            require(b=={'type':'DEPOT'if depot else'CLIENT','idx':0 if depot else node-1,'location':node,'node':node},'native node mapping')
    return {'status':'FEASIBLE'if a['solver_is_feasible']else'NO_FEASIBLE_INCUMBENT_WITHIN_BUDGET','valid_feasible':a['solver_is_feasible'],'cost':v['cost']if a['solver_is_feasible']else None,'vehicles':v['vehicles']if a['solver_is_feasible']else None,'saved_route_audit':v}

def readlines(p):return [json.loads(s)for s in p.read_text().splitlines()]if p.exists()else[]
def aggregate(rows):
    valid=[r for r in rows if r['valid_pair']]
    s={'planned_pairs':len(rows),'valid_pairs':len(valid),'control_feasible':sum(r['control']['valid_feasible']for r in rows),'treatment_feasible':sum(r['treatment']['valid_feasible']for r in rows),'treatment_statuses':dict(Counter(r['treatment']['status']for r in rows)),'conditional_on_valid_pairs':True}
    for k in ('delta_cost','relative_delta_pct','delta_vehicles'):
        values=[r[k]for r in valid];s[k]={'mean':statistics.mean(values)if values else None,'median':statistics.median(values)if values else None,'n':len(values),'planned_denominator':len(rows)}
    s['cost_direction_counts']={k:sum(f(r['delta_cost'])for r in valid)for k,f in [('treatment_lower',lambda x:x<0),('treatment_equal',lambda x:x==0),('treatment_higher',lambda x:x>0)]}
    return s

def results():
    receipt=gate();schedule=load(ROOT/'freeze/SCHEDULE.json');require(len(schedule)==36 and len({e['call_id']for e in schedule})==36,'schedule36')
    items=readlines(ROOT/'raw/results.jsonl');events=readlines(ROOT/'raw/attempts.jsonl');byid={i['call_id']:i for i in items};expected={e['call_id']:e for e in schedule}
    require(len(items)==len(byid) and set(byid)<=set(expected),'unique allowed results')
    starts=[e['call_id']for e in events if e.get('event_kind')=='STARTED'];finishes=[e['call_id']for e in events if e.get('event_kind')=='FINISHED']
    require(len(starts)==len(set(starts)) and len(finishes)==len(set(finishes)),'no duplicate attempts')
    require(starts==[e['call_id']for e in schedule][:len(starts)] and set(finishes)<=set(starts),'schedule sequence')
    correct=[]
    for cid in starts:
        correct.append(('STARTED',cid))
        if cid in finishes:correct.append(('FINISHED',cid))
    require([(e.get('event_kind'),e.get('call_id'))for e in events]==correct,'serial lifecycle ordering')
    for e in events:
        require(e['schedule']==expected[e['call_id']],'event schedule')
        require(set(e)=={'event_kind','utc','call_id','schedule'}|({'result'}if e['event_kind']=='FINISHED'else set()),'event schema')
        if e['event_kind']=='FINISHED':require(e['result']==byid.get(e['call_id']),'finish/result match')
    base={(c['instance_id'],c['seed']):c for c in load(ROOT/'freeze/BASELINE_A.json')['cases']};rows=[];cache={}
    oldr=load(ROOT/'provenance/CONTROL_FINAL_REVIEWED_DRIVE_RECEIPT.json');require(sha(oldr['download_path'])==oldr['sha256'],'old FINAL actual bytes')
    with zipfile.ZipFile(oldr['download_path'])as oldzip:
        for entry in schedule:
            ident=entry['instance_id'];cid=entry['call_id'];seed=entry['seed']
            if ident not in cache:
                p=vrp(ROOT/'input'/f'{ident}.vrp');routes,cost=sol(ROOT/'references'/f'{ident}.sol');p['K']=len(routes);route_check(p,routes,cost)
                require(p==load(ROOT/'input'/f'{ident}.json'),'input original parse');cache[ident]=p
            p=cache[ident];b=base[ident,seed];control=(ROOT/b['control_file']).read_bytes()
            require(control==oldzip.read(OLD.name+'/raw/calls/'+b['call_A']+'.stdout') and hashlib.sha256(control).hexdigest()==b['stdout_sha256'],'control A FINAL member')
            c=answer_check({**p,'K':len(p['demands'])-1},json.loads(control),seed);require(c['valid_feasible'],'valid control');c.update(call_id=b['call_A'])
            item=byid.get(cid);t={'status':'MISSING_RESULT','valid_feasible':False,'cost':None,'vehicles':None,'errors':[]}
            if item:
                t['status']=item['status']if item['status']in ('WALL_TIMEOUT','PROCESS_FAILURE_OR_CPU_LIMIT','CALL_ERROR_UNDETERMINED')else'INVALID_OUTPUT'
                try:
                    require(item['call_id']==cid and item['schedule']==entry,'record schedule')
                    payload={k:p[k]for k in ('coordinates','demands','capacity','K')};payload.update(seed=seed,max_iterations=25)
                    require(item['payload_sha256']==hashlib.sha256(compact(payload)).hexdigest(),'payload original identity')
                    require(cid in starts and cid in finishes,'complete lifecycle')
                    for key in ('stdout','stderr'):
                        path=ROOT/item[key];require(path.is_relative_to(ROOT/'raw/calls') and sha(path)==item[key+'_sha256'],'output path/hash')
                    require(item['process_spawned']is True and item['child_reaped']is True and item['returncode']==0,'process state')
                    require(item['status']in ('UNREVIEWED_PROCESS_SUCCESS','UNREVIEWED_INFEASIBLE'),'process category')
                    a=load(ROOT/item['stdout']);t.update(answer_check(p,a,seed))
                    require(item['status']==('UNREVIEWED_PROCESS_SUCCESS'if t['valid_feasible']else'UNREVIEWED_INFEASIBLE'),'native/process feasibility match')
                except Exception as exc:
                    t.update(valid_feasible=False,cost=None,vehicles=None);t['errors'].append(str(exc))
                    if t['status']in ('FEASIBLE','NO_FEASIBLE_INCUMBENT_WITHIN_BUDGET'):t['status']='INVALID_OUTPUT_OR_LEDGER'
            valid=c['valid_feasible'] and t['valid_feasible'];rows.append({'call_id':cid,'instance_id':ident,'seed':seed,'control':c,'treatment':t,'valid_pair':valid,'delta_cost':t['cost']-c['cost']if valid else None,'relative_delta_pct':100*(t['cost']-c['cost'])/c['cost']if valid else None,'delta_vehicles':t['vehicles']-c['vehicles']if valid else None})
    per=[{'instance_id':ident,'K_ref':p['K'],'n_customers':len(p['demands'])-1,**aggregate([r for r in rows if r['instance_id']==ident])}for ident,p in cache.items()]
    overall=aggregate(rows);full=[p for p in per if p['valid_pairs']==3]
    overall['complete_instance_equal_weighted']={'included_instances':len(full),'planned_instances':12,**{f'mean_{k}':statistics.mean(p[k]['mean']for p in full)if full else None for k in ('delta_cost','relative_delta_pct','delta_vehicles')}}
    output={'status':'SAVED_EVIDENCE_AUDITED','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'raw_archive_sha256':receipt['sha256'],'frozen_files_sha256':receipt['frozen_files_sha256'],'optimizer_calls_by_reviewer':0,'planned_calls':36,'observed_records':len(items),'started':len(starts),'finished':len(finishes),'spawned':sum(i.get('process_spawned',False)for i in items),'full_ledger':len(items)==len(starts)==len(finishes)==36,'rows':rows,'per_instance':per,'overall':overall,'method':'Independent original VRP/SOL parsing, exact integer sqrt edge rounding, original input and native model identity, activities, capacities, fleet, payloads, source/archive bytes, traces, fixed A provenance and all36 denominators. No author validator/endpoint or optimizer imports.'}
    with (ROOT/'independent_supervision/results/SAVED_FLEET_AUDIT.json').open('x')as f:json.dump(output,f,ensure_ascii=False,indent=2);f.write('\n')
    print(json.dumps({k:output[k]for k in ('status','started','finished','spawned','overall')},ensure_ascii=False))

def equal(a,b,label):
    if isinstance(a,float):require(type(b)in (int,float) and math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-12),label)
    elif isinstance(a,dict):
        require(isinstance(b,dict),label)
        for k,v in a.items():require(k in b,label+'.'+k);equal(v,b[k],label+'.'+k)
    elif isinstance(a,list):
        require(isinstance(b,list) and len(a)==len(b),label)
        for i,(x,y)in enumerate(zip(a,b)):equal(x,y,f'{label}[{i}]')
    else:require(a==b,label)

def report():
    receipt=gate();audit=load(ROOT/'independent_supervision/results/SAVED_FLEET_AUDIT.json');summary=load(ROOT/'reports/SUMMARY.json')
    require(audit['raw_archive_sha256']==receipt['sha256']==summary['raw_archive_sha256'],'RAW report binding')
    require(audit['frozen_files_sha256']==summary['frozen_files_sha256'],'freeze report binding')
    require(summary['treatment_call_denominator']==summary['historical_control_denominator']==36,'report denominators')
    equal(audit['overall'],summary['overall'],'overall');equal(audit['per_instance'],load(ROOT/'reports/PER_INSTANCE.json'),'per instance')
    pairs=load(ROOT/'reports/PAIRED_RESULTS.json');require(len(pairs)==36,'report all pairs')
    for own,theirs in zip(audit['rows'],pairs):
        equal({k:own[k]for k in ('instance_id','seed','valid_pair','delta_cost','relative_delta_pct','delta_vehicles')},theirs,'paired metrics')
        for arm in ('control','treatment'):equal({k:own[arm][k]for k in ('status','valid_feasible','cost','vehicles')},theirs[arm],arm)
    text=(ROOT/'reports/REPORT_ZH.txt').read_text()
    for phrase in ('at-most-K_ref','非同期','phase','可行域收缩','未找到可行','文件名k','repeat A'):require(phrase in text,'report required qualification '+phrase)
    require('collision'in summary['control_provenance_disclosure'],'old control qualification')
    out={'status':'PASS_CANDIDATE_FOR_PRIMARY_SUPERVISOR_SIGNATURE','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'raw_archive_sha256':receipt['sha256'],'frozen_files_sha256':receipt['frozen_files_sha256'],'report_sha256':sha(ROOT/'reports/REPORT_ZH.txt'),'summary_sha256':sha(ROOT/'reports/SUMMARY.json'),'independent_audit_sha256':sha(ROOT/'independent_supervision/results/SAVED_FLEET_AUDIT.json'),'all36_pair_and12_instance_metrics_independently_recomputed':True,'interpretation_qualifications_checked':True,'optimizer_calls_by_reviewer':0}
    with (ROOT/'independent_supervision/results/FINAL_REPORT_CANDIDATE.json').open('x')as f:json.dump(out,f,ensure_ascii=False,indent=2);f.write('\n')
    print(json.dumps(out))
if __name__=='__main__':
    if not __debug__:raise RuntimeError('Assertions must be enabled')
    resource.setrlimit(resource.RLIMIT_CPU,(60,60))
    resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
    signal.alarm(120)
    require(sys.argv[1:]in (['--results'],['--report']),'usage --results or --report')
    results()if sys.argv[1]=='--results'else report()
