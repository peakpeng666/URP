"""Invented fixtures only. Does not execute an optimiser or formal panel call."""
import copy
from decimal import Decimal, getcontext, ROUND_DOWN
import unittest

from independent_validator import rounded_edge, validate_solution


class IndependentValidatorTests(unittest.TestCase):
    def setUp(self):
        self.p = {"coordinates": [[0, 0], [3, 4], [6, 8]], "demands": [0, 2, 3], "capacity": 5, "K": 2}

    def test_per_edge_half_up(self):
        self.assertEqual(rounded_edge([0, 0], ["0.5", 0]), 1)
        self.assertEqual(rounded_edge([0, 0], ["2.5", 0]), 3)
        self.assertEqual(rounded_edge([0, 0], ["0.4999999999999999999999999999", 0]), 0)
        self.assertEqual(rounded_edge([0, 0], ["0.5000000000000000000000000001", 0]), 1)
        self.assertEqual(rounded_edge([0, 0], [1, 1]), 1)
        self.assertEqual(rounded_edge([0, 0], [3, 4]), 5)

    def test_edge_rounding_not_total_rounding(self):
        p = {"coordinates": [[0, 0], ["0.5", 0]], "demands": [0, 1], "capacity": 1, "K": 1}
        self.assertTrue(validate_solution(p, [[0, 1, 0]], 2)["valid"])

    def test_fewer_than_K_is_feasible(self):
        r = validate_solution(self.p, [[0, 1, 2, 0]], 20)
        self.assertTrue(r["valid"])
        self.assertEqual(r["nonempty_routes"], 1)
        self.assertEqual(r["loads"], [5])

    def test_empty_slots_do_not_consume_vehicles(self):
        self.p["K"] = 1
        r = validate_solution(self.p, [[0, 0], [0, 1, 2, 0], [0, 0]], 20)
        self.assertTrue(r["valid"])
        self.assertEqual(r["slot_count"], 3)
        self.assertEqual(r["nonempty_routes"], 1)

    def test_zero_demand_customer_is_still_required(self):
        self.p["demands"][2] = 0
        self.assertFalse(validate_solution(self.p, [[0, 1, 0]])["valid"])

    def test_reverse_route_same_cost(self):
        self.assertTrue(validate_solution(self.p, [[0, 2, 1, 0]], 20)["valid"])

    def test_split_routes(self):
        self.assertTrue(validate_solution(self.p, [[0, 1, 0], [0, 2, 0]], 30)["valid"])

    def test_missing_customer(self):
        self.assertIn("MISSING_CUSTOMERS: 2", validate_solution(self.p, [[0, 1, 0]])["errors"])

    def test_duplicate_within_route(self):
        self.assertEqual(validate_solution(self.p, [[0, 1, 1, 2, 0]])["duplicate_customers"], [1])

    def test_duplicate_across_routes(self):
        self.assertEqual(validate_solution(self.p, [[0, 1, 0], [0, 1, 2, 0]])["duplicate_customers"], [1])

    def test_capacity(self):
        self.p["capacity"] = 4
        r = validate_solution(self.p, [[0, 1, 2, 0]], 20)
        self.assertFalse(r["valid"])
        self.assertFalse(r["feasible"])
        self.assertEqual(r["cost"], 20)  # diagnostic cost never authorises use

    def test_vehicle_limit(self):
        self.p["K"] = 1
        self.assertFalse(validate_solution(self.p, [[0, 1, 0], [0, 2, 0]], 30)["valid"])

    def test_internal_depot(self):
        r = validate_solution(self.p, [[0, 1, 0, 2, 0]])
        self.assertFalse(r["valid"])
        self.assertIsNone(r["cost"])

    def test_bad_closure(self):
        for routes in [[[1, 2, 0]], [[0, 1, 2]], [[1, 2]]]:
            with self.subTest(routes=routes):
                self.assertFalse(validate_solution(self.p, routes)["valid"])

    def test_node_types_and_bounds(self):
        for node in [-1, 3, 1.0, "1", True, None, [], {}]:
            with self.subTest(node=node):
                self.assertFalse(validate_solution(self.p, [[0, node, 2, 0]])["valid"])

    def test_route_shapes(self):
        for routes in [None, {}, [None], [[]], [[0]], [(0, 1, 2, 0)], []]:
            with self.subTest(routes=routes):
                self.assertFalse(validate_solution(self.p, routes)["valid"])

    def test_reported_cost_mismatch(self):
        r = validate_solution(self.p, [[0, 1, 2, 0]], 19)
        self.assertTrue(r["feasible"])
        self.assertFalse(r["valid"])
        self.assertFalse(r["reported_cost_matches"])

    def test_invalid_reported_cost(self):
        for value in [True, -1, 20.5, "NaN", "Infinity", {}]:
            with self.subTest(value=value):
                self.assertFalse(validate_solution(self.p, [[0, 1, 2, 0]], value)["valid"])

    def test_optional_cost_flag(self):
        r = validate_solution(self.p, [[0, 1, 2, 0]])
        self.assertTrue(r["valid"])
        self.assertFalse(r["reported_cost_checked"])

    def test_invalid_input_scalars(self):
        for field, value in [("K", True), ("K", -1), ("K", 1.5), ("capacity", 0), ("capacity", "NaN"), ("demands", [0, -1, 3]), ("demands", [1, 2, 3]), ("demands", [0, 2]), ("coordinates", [[0, 0], [float("nan"), 0], [1, 1]])]:
            with self.subTest(field=field, value=value):
                p = copy.deepcopy(self.p)
                p[field] = value
                self.assertFalse(validate_solution(p, [[0, 1, 2, 0]])["valid"])

    def test_zero_customers(self):
        p = {"coordinates": [[0, 0]], "demands": [0], "capacity": 1, "K": 0}
        self.assertTrue(validate_solution(p, [], 0)["valid"])

    def test_global_decimal_context_not_changed_or_used(self):
        ctx = getcontext()
        old_prec, old_rounding = ctx.prec, ctx.rounding
        try:
            ctx.prec, ctx.rounding = 2, ROUND_DOWN
            self.assertEqual(rounded_edge([0, 0], [Decimal("2.5"), 0]), 3)
            self.assertEqual(ctx.prec, 2)
            self.assertEqual(ctx.rounding, ROUND_DOWN)
        finally:
            ctx.prec, ctx.rounding = old_prec, old_rounding


if __name__ == "__main__":
    unittest.main(verbosity=2)
