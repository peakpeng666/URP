# Final independent pre-execution review

Status: PASS for preparation integrity and scientific task semantics. This is not
permission to bypass the separate PREEXEC archive/readback and parent execution
approval gates. No formal public optimisation has run at this review point.

## Completed checks

- Installation permission was supplied as exact user/assistant transcript
  evidence. The resulting isolated environment identifies PyVRP 0.14.0.
- All 14 retained binary wheels (42,613,891 bytes) match their recorded SHA256.
  An independent registry lookup matched each filename, byte count and SHA256
  against that exact version's official PyPI JSON and pythonhosted file URL.
- The interpreter hash and all 4,440 recorded installed distribution file hashes
  match the actual environment. No package was imported by this reviewer.
- The four installed-package solves used invented fixtures only. Their saved
  stdout/stderr hashes were independently rechecked, and saved routes were
  independently rescored with Decimal80 HALF_UP. Costs, capacity, coverage and
  at-most-K feasibility match, including a one-route result with K=3.
- Thirty independent validator/parser fixture tests passed; fake-API tests cover
  shuffled activity/location mapping and malformed activities. Actual model
  construction tests cover all 16 fixed inputs and 40,882 distance cells. All
  model-matrix hashes match the separately computed Decimal matrices.
- Actual-model source checks vehicle capacity/availability, mandatory deliveries,
  zero pickups/duration/objective extras, no reloads/shipments/groups, and exact
  directed matrix data. No solve or solution construction occurs in that check.
- Three process-group failure fixtures recorded no surviving writing child or
  delayed write after cleanup. Source uses per-call kill/wait, outer process-group
  termination, a non-secret environment whitelist and enabled-assertion checks.
- Static review confirms explicit profile 0 for all matrix calls, real
  is_client/is_depot predicates, client-to-location-to-original-node mapping,
  independent initial solutions, fixed seeds, one-shot guards and no retry.
- Endpoint report code gates scoring on RAW private byte readback and raw hashes,
  requires independent route and reported-cost agreement, and correctly preserves
  unavailable seeds/tasks with null all16 primary means. It was not executed.
- Original experiment file set and all 389 original file hashes remain unchanged.
  The formal raw directory was empty when checked.

## Limits and next gates

The independently checked installed-model matrix file is supplied evidence from
the model-construction process; the reviewer did not invoke model construction or
optimisation. Saved synthetic route scoring and registry/runtime hash checks are
direct independent recomputations. There is no claim of OS/native I/O isolation,
bitwise reproducibility under wall-time stopping, equal compute, a proven optimum,
or new blind generalisation testing.

The 260-second CPU and 1,536-MiB address-space bounds describe the benchmark
supervisor/workers in their stated scope. Installation, outer orchestration,
hashing, archiving and postprocessing are excluded, as now stated in the protocol.

Before PREEXEC packaging, compare the files against the SHA256/byte manifest in
freeze/INDEPENDENT_PRECHECK.json. A relevant source, environment, input, protocol,
schedule or test-evidence change requires a fresh review; the mere word PASS does
not approve different bytes. Then freeze, privately upload, actually download and
verify the archive, obtain the parent's exact frozen-plan approval, and only then
execute the unique 48 calls. Archive stable raw bytes and verify remote readback
before any historical/reference endpoint scoring. The final saved-route/report
audit remains required and does not rerun the optimiser.

## Read-only check bookkeeping

FINAL_PRECHECK_EVIDENCE.json was successfully created by the first independent
read-only recheck at its recorded UTC time. A subsequent equivalent recheck reached
the exclusive-create step after verifying the evidence and refused to overwrite
that existing file. Its FileExistsError is preserved in FINAL_PRECHECK_EXECUTION.log.
This was an evidence-write guard, not a failed optimiser call; no benchmark or
synthetic optimisation was repeated. The durable recheck script remains available
for review, and intentionally uses exclusive output creation.
