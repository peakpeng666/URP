"""Independent read-only evidence recheck; no package imports or optimisation."""
import ast
import concurrent.futures
import datetime
import hashlib
import json
from pathlib import Path
import urllib.request

from independent_validator import validate_solution
from audit_inputs import audit

ROOT = Path(__file__).resolve().parents[1]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads((ROOT / path).read_text())


def official_check(row):
    url = f"https://pypi.org/pypi/{row['name']}/{row['version']}/json"
    try:
        with urllib.request.urlopen(url, timeout=30) as response:
            metadata = json.load(response)
        entries = [v for v in metadata['urls'] if v['filename'] == row['file']]
        assert len(entries) == 1, row['file']
        entry = entries[0]
        assert entry['digests']['sha256'] == row['sha256']
        assert entry['size'] == row['bytes']
        assert entry['url'].startswith('https://files.pythonhosted.org/')
        return {**row, 'registry_metadata_url': url,
                'official_file_url': entry['url'], 'official_registry_match': True}
    except Exception as exc:
        return {**row, 'registry_metadata_url': url,
                'official_registry_match': False, 'error': repr(exc)}


def main():
    wheels = read('environment/WHEELS.json')
    runtime = read('environment/RUNTIME.json')
    synthetic = read('selftests/SYNTHETIC_SOLVER.json')
    models = read('selftests/ACTUAL_MODEL_MATRIX_AUDIT.json')
    independent = read('independent_review/INPUT_MATRIX_AUDIT.json')
    assert runtime['isolated_venv'] and not runtime['system_site_packages']
    assert runtime['pyvrp_version'] == '0.14.0'
    assert sha(Path(runtime['python_executable']).resolve()) == runtime['python_binary_sha256']
    for item in runtime['installed_distribution_files']:
        path = Path(item['path'])
        assert path.stat().st_size == item['bytes'] and sha(path) == item['sha256'], str(path)
    for item in wheels['wheels']:
        path = ROOT / 'environment/wheels' / item['file']
        assert path.stat().st_size == item['bytes'] and sha(path) == item['sha256'], str(path)
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
        official = list(executor.map(official_check, wheels['wheels']))
    rechecked = []
    for row in synthetic['fixtures']:
        name = row['instance']['instance_id']
        stdout = ROOT / 'selftests' / f'{name}.stdout'
        stderr = ROOT / 'selftests' / f'{name}.stderr'
        assert sha(stdout) == row['stdout_sha256']
        assert sha(stderr) == row['stderr_sha256']
        output = json.loads(stdout.read_text())
        check = validate_solution(row['instance'], output['routes'], output['reported_cost'])
        assert check['valid'] and check['reported_cost_checked'] and check['reported_cost_matches']
        assert check == row['validation']
        assert output['denied_io_events'] == output['reference_or_history_payload_fields'] == []
        assert output['reported_duration_cost'] == output['reported_fixed_vehicle_cost'] == 0
        assert output['solver_is_complete'] and output['solver_is_feasible']
        rechecked.append({'instance_id': name, 'valid': True,
                          'independent_cost': check['cost'],
                          'nonempty_routes': check['nonempty_routes'],
                          'stdout_sha256': sha(stdout)})
    lookup = {row['instance_id']: row for row in independent['rows']}
    assert len(models['rows']) == 16 and models['public_optimizer_calls'] == 0
    for row in models['rows']:
        original = lookup[row['instance_id']]
        assert row['model_matrix_sha256'] == row['independent_expected_sha256'] == original['matrix_sha256']
        assert row['directed_cells'] == original['directed_cells'] and row['all_model_semantics_asserted']
    input_check = audit(ROOT, Path('/workspace/shared/public_route_order_transfer_20261008'))
    assert input_check['valid']
    assert all(a['matrix_sha256'] == b['matrix_sha256'] for a, b in zip(input_check['rows'], independent['rows']))
    old = read('freeze/OLD_FILES_BEFORE.json')
    old_root = Path(old['root'])
    assert {str(p.relative_to(old_root)) for p in old_root.rglob('*') if p.is_file()} == set(old['files'])
    for relative, item in old['files'].items():
        assert sha(old_root / relative) == item['sha256']
        assert (old_root / relative).stat().st_size == item['bytes']
    assert not any(path.is_file() for path in (ROOT / 'raw').rglob('*'))
    for path in (ROOT / 'source').glob('*.py'):
        ast.parse(path.read_text())
    result = {
        'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'status': 'PASS' if all(r['official_registry_match'] for r in official) else 'OFFICIAL_REGISTRY_RECHECK_INCOMPLETE',
        'scope': 'Read-only evidence recheck; no package import, model construction, optimisation or endpoint scoring',
        'wheel_bytes': sum(row['bytes'] for row in wheels['wheels']),
        'wheel_local_hashes_verified': len(wheels['wheels']),
        'official_registry_matches': sum(row['official_registry_match'] for row in official),
        'official_wheels': official, 'runtime_binary_hash_match': True,
        'installed_files_verified': len(runtime['installed_distribution_files']),
        'original_files_unchanged': len(old['files']), 'synthetic_raw_rechecks': rechecked,
        'public_model_matrix_rechecks': 16, 'directed_cells': 40882,
        'public_optimizer_calls_before_gate': 0, 'raw_directory_empty': True,
    }
    with (ROOT / 'independent_review/FINAL_PRECHECK_EVIDENCE.json').open('x') as out:
        json.dump(result, out, indent=2)
        out.write('\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('official_wheels', 'synthetic_raw_rechecks')}))
    for row in official:
        if not row['official_registry_match']:
            print(row['name'], row['error'])
    return 0 if result['status'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
