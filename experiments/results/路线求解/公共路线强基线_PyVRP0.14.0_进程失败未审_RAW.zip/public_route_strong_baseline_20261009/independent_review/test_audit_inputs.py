"""Invented parser fixtures only; no panel solves or solution reads."""
from decimal import Decimal
import unittest

from audit_inputs import decimal_matrix, parse_vrp

FIXTURE = """NAME : fixture
COMMENT : arbitrary public answer text is not retained
TYPE : CVRP
DIMENSION : 3
EDGE_WEIGHT_TYPE : EUC_2D
CAPACITY : 8
NODE_COORD_SECTION
3 6 8
1 0 0
2 3 4
DEMAND_SECTION
2 2
3 3
1 0
DEPOT_SECTION
1
-1
EOF
"""


class InputParserTests(unittest.TestCase):
    def test_unordered_sections_and_comment_ignored(self):
        p = parse_vrp(FIXTURE, 2)
        self.assertEqual(p["original_node_ids"], [1, 2, 3])
        self.assertEqual(p["demands"], [0, 2, 3])
        self.assertEqual(p["K"], 2)
        self.assertNotIn("COMMENT", p)
        self.assertEqual(decimal_matrix(p["coordinates"]), [[0, 5, 10], [5, 0, 5], [10, 5, 0]])

    def test_nonfirst_depot_mapping(self):
        text = FIXTURE.replace("2 2\n3 3\n1 0", "2 0\n3 3\n1 2").replace("DEPOT_SECTION\n1", "DEPOT_SECTION\n2")
        p = parse_vrp(text, 2)
        self.assertEqual(p["original_node_ids"], [2, 1, 3])
        self.assertEqual(p["coordinates"][0], [Decimal(3), Decimal(4)])

    def test_duplicate_node(self):
        with self.assertRaises(ValueError):
            parse_vrp(FIXTURE.replace("3 6 8", "2 6 8"), 2)

    def test_missing_node(self):
        with self.assertRaises(ValueError):
            parse_vrp(FIXTURE.replace("3 6 8\n", ""), 2)

    def test_invalid_metric(self):
        with self.assertRaises(ValueError):
            parse_vrp(FIXTURE.replace("EUC_2D", "EXPLICIT"), 2)

    def test_multiple_depots(self):
        with self.assertRaises(ValueError):
            parse_vrp(FIXTURE.replace("DEPOT_SECTION\n1\n-1", "DEPOT_SECTION\n1\n2\n-1"), 2)

    def test_negative_or_noninteger_demand(self):
        for value in ["-1", "2.5"]:
            with self.subTest(value=value), self.assertRaises(ValueError):
                parse_vrp(FIXTURE.replace("2 2\n3 3", f"2 {value}\n3 3"), 2)

    def test_no_trailing_content(self):
        with self.assertRaises(ValueError):
            parse_vrp(FIXTURE + "other content\n", 2)


if __name__ == "__main__":
    unittest.main(verbosity=2)
