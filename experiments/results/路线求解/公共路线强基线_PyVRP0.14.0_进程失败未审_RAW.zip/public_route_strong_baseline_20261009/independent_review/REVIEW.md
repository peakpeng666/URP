# Independent protocol and verifier review

Review scope: frozen original 16-task CVRP semantics, proposed supplementary PyVRP
0.14.0 quality benchmark, source-level adapter/supervisor inspection, standalone
route checker, and read-only original-input equivalence. No optimiser was run, no
external package was imported or installed, and no historic/reference route was
scored during this pre-execution review. Original experiment files were not edited.

Status: PREPARATION CHECKS PASSED; FINAL EXECUTION GATE STILL PENDING.
Do not interpret this document as authorisation to run formal calls.

## Verified preparation results

- `independent_validator.py`: separate standard-library implementation, with no
  import from the main worker or scoring code. `validate_solution(problem, routes,
  reported_cost=None)` returns `valid`, `feasible`, `errors`, independently
  recomputed `cost`, per-route costs/loads, observed slots/nonempty vehicles,
  missing/duplicate customers, and reported-cost check flags.
- Formal scoring requires all of `valid`, `reported_cost_checked`, and
  `reported_cost_matches`. A diagnostic cost on an infeasible route set must not
  enter aggregates. Feasibility and cost agreement are distinct.
- Distances use Decimal precision 80, square root, and ROUND_HALF_UP on each edge.
  No solver distance matrix or binary floating-point square root is trusted by
  this route checker. It rejects internal depot visits, invalid node types/IDs,
  missing/duplicate customers, overloads, excess nonempty vehicles and cost errors.
- Empty `[0,0]` slots do not consume vehicles. The checker accepts fewer than K
  used routes; it separately reports stored slot count and does not require K
  nonempty routes. The original panel permits at-most-K_ref, not exactly K.
- `audit_inputs.py` parses original VRPLIB independently, deliberately ignoring
  comments, and reads K from frozen TASKS rather than a filename or public answer.
  All 16 copied JSON/VRP pairs are byte-identical to the original inputs. The
  original task list and prescribed 48-call seed schedule match.
- All 40,882 directed distance entries agree across original-VRP Decimal80,
  normalized-JSON Decimal80 and intended floor(hypot+0.5). Matrices are symmetric,
  with zero diagonals. See `INPUT_MATRIX_AUDIT.json` for per-instance hashes and
  checks. This does not yet establish the actual installed PyVRP model matrices.

## Important API and protocol findings

The fixed v0.14.0 source, rather than the unversioned documentation site, was
reviewed. The latter was serving 1.0.0a0 when checked.

1. A Route iterates through its entire scheduled activity sequence, including
   both depot endpoints. Client activity indices identify the clients array;
   map through `data.client(activity.idx).location`, then an explicit
   location-to-original-input mapping. Depot indices are a separate namespace.
   Reject shipment activities and intermediate depot visits. A shuffled-location
   synthetic fixture should catch any accidental use of idx+1. [Route source](https://raw.githubusercontent.com/PyVRP/PyVRP/v0.14.0/pyvrp/cpp/Route.cpp)

2. Use `is_client()`/`is_depot()` or actual enum symbols. The type stub and C++
   header give different numeric CLIENT/DEPOT enumeration orders, so hard-coded
   numeric tags are unsafe. [Activity header](https://raw.githubusercontent.com/PyVRP/PyVRP/v0.14.0/pyvrp/cpp/Activity.h), [type stub](https://raw.githubusercontent.com/PyVRP/PyVRP/v0.14.0/pyvrp/_pyvrp.pyi)

3. `add_edge` is directed. Both orientations of every pair must be set, or the
   missing direction retains a very large default. A one-type fleet with K
   vehicles bounds use; there is no requirement to use all of them. Require
   mandatory clients and explicit delivery, zero pickup, zero duration/service,
   zero fixed/duration/overtime costs, no shipments, no reloads and no warm start.
   The inspected worker expresses these choices. [Model source](https://raw.githubusercontent.com/PyVRP/PyVRP/v0.14.0/pyvrp/Model.py), [Solution source](https://raw.githubusercontent.com/PyVRP/PyVRP/v0.14.0/pyvrp/cpp/Solution.cpp)

4. MaxRuntime begins timing at its first stop callback. The solver constructs
   neighbours and its randomized/exhaustive initial solution beforehand. The
   main loop tests stopping between iterations, so it can overshoot. Every seed
   must get a new stopping object. Save full-process, build, solve and loop timing
   separately. A fixed seed with wall-time stopping does not guarantee a
   reproducible terminal route. [MaxRuntime source](https://raw.githubusercontent.com/PyVRP/PyVRP/v0.14.0/pyvrp/stop/MaxRuntime.py), [solve source](https://raw.githubusercontent.com/PyVRP/PyVRP/v0.14.0/pyvrp/solve.py), [ILS source](https://raw.githubusercontent.com/PyVRP/PyVRP/v0.14.0/pyvrp/IteratedLocalSearch.py)

5. This is a supplementary quality comparison with different algorithms,
   initializers, budgets and timing. It is neither compute-matched nor a new
   blind test. The selected public references are feasible denominators, not
   optimality proofs from this study. Equal-weight per-instance 3-seed means are
   primary; best-of-3 is secondary. Any missing/invalid seed makes that task's
   primary unavailable and any unavailable task makes the all16 primary null.

6. The fixed v0.14.0 bindings require an explicit profile argument for both
   `data.distance_matrix(0)` and `data.duration_matrix(0)`. The first inspected
   worker omitted this argument in model checks and matrix hashing, which would
   raise TypeError. This was reported before installation or execution; verify
   all occurrences are corrected in the final source. A subsequent AST review confirmed all three calls now pass profile 0; installed runtime testing remains pending. [Binding source](https://raw.githubusercontent.com/PyVRP/PyVRP/v0.14.0/pyvrp/cpp/bindings.cpp)

## Isolation and execution reliability

- VRPLIB comments can contain reference values. Passing only coordinates,
  demands, capacity, K, seed and runtime via stdin avoids these fields, original
  names and historic solutions. Do not feed the raw VRP text to the worker.
- A Python audit hook is useful evidence of attempted Python-level I/O; it is
  not a native/system-call sandbox. Zero audit events must not be described as
  proof that no native library could read a file or use the network.
- The first inspected supervisor needed an unconditional finally block to kill
  and reap any live child after generic exceptions. Otherwise the next scheduled
  call could overlap a surviving process. A fatal supervisor termination also
  requires the outer executor to wait for or terminate its child before a raw
  archive is made. Archive bytes must be stable, including stderr/stdout.
- Remove inherited PYTHONOPTIMIZE (and require `__debug__`) because many gates are
  implemented as assertions. Avoid inherited PYTHONPATH/PYTHONHOME and unrelated
  credentials; use a minimal environment. Verify the actual interpreter and
  package file hashes, not just a version string.
- STARTED, immutable per-call stdout/stderr, fixed seed schedule and no retries
  are the right design. Keep malformed/failed calls and never replace a task or
  seed. Failure handling may diagnose without rerunning a formal call.

### Revision reviewed after initial findings

The supervisor now has per-call finally kill/wait cleanup. Its child environment
is an explicit whitelist, without inherited Python injection variables or
unrelated credentials. Worker and supervisor reject disabled assertions. The
new outer executor launches a separate process session and attempts a group kill,
then reaps the supervisor before sealing raw bytes, including after CPU/fatal
termination. These changes address the identified design gaps at source level;
runtime failure fixtures are still required. In fatal-group tests, explicitly
verify that no surviving descendant can continue writing before archiving.

The newly inspected endpoint report checks the RAW_UNREVIEWED receipt and raw
hashes before reading saved routes/reference/history for scoring. It correctly
passes `reported_cost` to the independent validator and uses exact Fraction
arithmetic and integer cross multiplication for three-seed mean comparisons.
Incomplete seed sets retain unavailable task rows and null all16 primary means.
This is source inspection only; no endpoint report has been run here.

## Required tests and remaining gates

1. Obtain installation authorisation; preserve official wheel/dependency hashes
   and the selected runtime. No such installation occurred in this review.
2. Execute invented-fixture tests of the installed adapter: shuffled client and
   location mapping, fewer-than-K route use, binding capacity, forbidden reload,
   required zero-demand customer, both depot endpoints, no shipment, complete
   directed model matrix, zero duration and pure-distance objective. Verify model
   matrices against the independent per-instance hashes without public solving.
3. Exercise isolation and resource/failure handling with invented fixtures:
   denied Python open/network, CPU/wall failure, malformed output, no leftover
   child, one STARTED guard and no retry. Do not use these tests to tune the panel.
4. Independently re-read final changed source, test receipts, protocol and freeze
   hashes, then write a final gate status. The present review is not that gate.
5. Preserve PREEXEC private upload plus byte-identical readback and parent approval
   before the unique 48 formal calls. Freeze verifier and fixtures alongside code.
6. Immediately after execution, archive stable unreviewed raw bytes and verify
   private remote readback before scoring. Only then independently validate all
   saved new routes, original TSR routes and reference routes, and verify all16
   aggregation, denominators, signs, failures and no-retry provenance.

## Reproduction of non-solving checks

Run from this directory:

    python -m unittest -v test_independent_validator.py test_audit_inputs.py
    python audit_inputs.py

The validator CLI accepts a normalized input JSON and a solution JSON object with
`routes` and `cost`. The new worker uses the field name `reported_cost`, so endpoint
auditing should call the API with that field explicitly, or form the CLI input
object without altering the original raw output. No route repair is performed.
