"""Invented fake-API mapping tests. Does not import or run PyVRP."""
from types import SimpleNamespace as N
from worker import extract_routes
from common import ROOT, save, now
class Activity:
    def __init__(self,kind,idx): self.kind,self.idx=kind,idx
    def is_client(self):return self.kind=='CLIENT'
    def is_depot(self):return self.kind=='DEPOT'
class Route:
    def __init__(self,activities):self.activities=activities
    def __iter__(self):return iter(self.activities)
    def start_depot(self):return 0
    def end_depot(self):return 0
    def vehicle_type(self):return 0
    def num_trips(self):return 1
    def distance(self):return 6
    def delivery(self):return [2]
    def is_feasible(self):return True
class Solution:
    def __init__(self,routes):self._routes=routes
    def routes(self):return self._routes
class Data:
    def depot(self,idx):assert idx==0;return N(location=3)
    def client(self,idx):return N(location=[2,0][idx])

def main():
    mapping={3:0,2:2,0:1}
    a=[Activity('DEPOT',0),Activity('CLIENT',0),Activity('CLIENT',1),Activity('DEPOT',0)]
    routes,native=extract_routes(Solution([Route(a)]),Data(),mapping)
    assert routes==[[0,2,1,0]] and native[0]['activities'][1]['location']==2
    tests=[{'case':'scrambled_locations_use_explicit_map','passed':True}]
    for name,bad in [('internal_depot',[a[0],a[1],a[0],a[2],a[3]]),('unexpected_shipment',[a[0],Activity('PICKUP',0),a[3]]),('unclosed',[a[1],a[2],a[3]])]:
        try:extract_routes(Solution([Route(bad)]),Data(),mapping)
        except (AssertionError,ValueError):tests.append({'case':name,'passed':True})
        else:raise AssertionError(name)
    save(ROOT/'selftests/ADAPTER_OFFLINE.json',{'utc':now(),'scope':'Invented fake API only; no PyVRP imported or optimizer run','status':'PASS','tests':tests})
    print('PASS',len(tests),'fake-API mapping tests')
if __name__=='__main__':main()
