"""Single-use frozen supervisor; refuses to start before approval and PREEXEC readback."""
import os,sys,json,time,resource,signal,subprocess,traceback,hashlib
from pathlib import Path
from common import ROOT,now,sha,read,save,append,verify_frozen,verify_old,receipt

def child_environment():
    # Do not inherit unrelated credentials, Python path injection, or optimization.
    return {'PATH':'/usr/local/bin:/usr/bin:/bin','HOME':'/tmp','LANG':'C.UTF-8','LC_ALL':'C.UTF-8',
            'PYTHONDONTWRITEBYTECODE':'1','PYTHONHASHSEED':'0','PYTHONNOUSERSITE':'1',
            'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1',
            'NUMEXPR_NUM_THREADS':'1','VECLIB_MAXIMUM_THREADS':'1'}
def main():
    if not __debug__: raise RuntimeError('Assertions must be enabled')
    resource.setrlimit(resource.RLIMIT_CPU,(20,20))
    resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
    signal.alarm(600)
    wall,cpu=time.monotonic(),time.process_time()
    freeze_hash=verify_frozen();verify_old();r=receipt('PREEXEC')
    assert read('freeze/INDEPENDENT_PRECHECK.json')['status']=='PASS'
    approval=read('provenance/PARENT_EXECUTION_APPROVAL.json')
    assert approval['approved'] is True and approval['frozen_files_sha256']==freeze_hash
    assert approval['preexec_archive_sha256']==r['sha256']
    assert approval['scope']=='one frozen 48-call PyVRP benchmark; no retry'
    env=read('environment/RUNTIME.json');python=env['python_executable']
    assert Path(python).is_file() and sha(Path(python).resolve())==env['python_binary_sha256']
    for file in env['installed_distribution_files']:
        p=Path(file['path']);assert p.stat().st_size==file['bytes'] and sha(p)==file['sha256'], str(p)
    schedule=read('freeze/SCHEDULE.json'); assert len(schedule)==48
    assert len({e['call_id'] for e in schedule})==48
    save(ROOT/'raw/STARTED.json',{'utc':now(),'freeze_sha256':freeze_hash,'approval_sha256':sha(ROOT/'provenance/PARENT_EXECUTION_APPROVAL.json'),'preexec_receipt_sha256':sha(ROOT/'provenance/PREEXEC_DRIVE_RECEIPT.json'),'planned_calls':48,'no_retries':True})
    (ROOT/'raw/calls').mkdir(exist_ok=False)
    results=[]
    for entry in schedule:
        cid=entry['call_id'];data=read(f"input/{entry['instance_id']}.json")
        assert set(data)=={'instance_id','coordinates','demands','capacity','K'}
        payload={k:data[k] for k in ('coordinates','demands','capacity','K')}
        payload.update(seed=entry['seed'],max_runtime_seconds=entry['max_runtime_seconds'])
        encoded=json.dumps(payload,separators=(',',':')).encode()
        out=ROOT/'raw/calls'/f'{cid}.stdout';err=ROOT/'raw/calls'/f'{cid}.stderr'
        item={**entry,'status':'UNREVIEWED_PROCESS_SUCCESS','returncode':None,
              'stdout':str(out.relative_to(ROOT)),'stderr':str(err.relative_to(ROOT)),
              'payload_sha256':hashlib.sha256(encoded).hexdigest(),'process_spawned':False}
        append(ROOT/'raw/attempts.jsonl',{'phase':'STARTED','utc':now(),**entry})
        started=time.monotonic();use=resource.getrusage(resource.RUSAGE_CHILDREN);before=use.ru_utime+use.ru_stime
        p=None
        try:
            with out.open('xb') as fo,err.open('xb') as fe:
                p=subprocess.Popen([python,'-B',str(ROOT/'source/worker.py')],stdin=subprocess.PIPE,
                    stdout=fo,stderr=fe,env=child_environment(),cwd=ROOT/'raw')
                item['process_spawned']=True
                try:p.communicate(encoded,timeout=10)
                except subprocess.TimeoutExpired:
                    p.kill();p.communicate();item['status']='WALL_TIMEOUT'
                item['returncode']=p.returncode
                if p.returncode and item['status']=='UNREVIEWED_PROCESS_SUCCESS':item['status']='PROCESS_FAILURE_OR_CPU_LIMIT'
            # Parse only record integrity, never compare to reference or history here.
            if item['status']=='UNREVIEWED_PROCESS_SUCCESS':
                answer=json.loads(out.read_text())
                assert answer['seed']==entry['seed'] and answer['version']=='0.14.0'
                assert answer['max_runtime_seconds']==1.0
                assert answer['denied_io_events']==[] and answer['reference_or_history_payload_fields']==[]
                if not answer['solver_is_feasible']:item['status']='UNREVIEWED_INFEASIBLE'
        except Exception as exc:
            item.update(status='CALL_ERROR_UNDETERMINED',error=str(exc),traceback=traceback.format_exc())
        finally:
            if p is not None:
                if p.poll() is None:p.kill()
                p.wait()
        use=resource.getrusage(resource.RUSAGE_CHILDREN)
        item.update(cpu_seconds_audit_only=use.ru_utime+use.ru_stime-before,wall_seconds_audit_only=time.monotonic()-started)
        for label,file in [('stdout',out),('stderr',err)]:
            if file.exists():item[label+'_sha256']=sha(file)
        append(ROOT/'raw/results.jsonl',item);append(ROOT/'raw/attempts.jsonl',{'phase':'FINISHED','utc':now(),**item});results.append(item)
    signal.alarm(0)
    save(ROOT/'raw/FINISHED.json',{'utc':now(),'status':'COMPLETED_UNREVIEWED','planned_calls':48,'retained_calls':len(results),'spawned_calls':sum(r['process_spawned'] for r in results),'wall_seconds_audit_only':time.monotonic()-wall,'supervisor_cpu_seconds_audit_only':time.process_time()-cpu,'old_files_verified_unchanged':verify_old(),'freeze_sha256_after':verify_frozen()})
if __name__=='__main__':main()
