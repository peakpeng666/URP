"""Synthetic pure-stdlib process cleanup faults; no model imports or CVRP calls."""
import sys,subprocess,time,os,signal,json
from pathlib import Path
from common import ROOT,save,now
from execute_and_seal import stop_process_group
from run_once import child_environment

def main():
    base=ROOT/'selftests/faults';base.mkdir(exist_ok=False)
    tests=[]
    for label,mode in [('leader_hard_death','kill'),('external_timeout','timeout'),('leader_exits_with_orphan','exit')]:
        child_pid=base/(label+'.pid');marker=base/(label+'.late_write')
        child_code=f"import os,time,pathlib;pathlib.Path({str(child_pid)!r}).write_text(str(os.getpid()));time.sleep(0.6);pathlib.Path({str(marker)!r}).write_text('MUST_NOT_EXIST')"
        leader_code=f"import subprocess,sys,time;subprocess.Popen([sys.executable,'-c',{child_code!r}]);"+('' if mode=='exit' else 'time.sleep(60)')
        p=subprocess.Popen([sys.executable,'-c',leader_code],start_new_session=True,env=child_environment(),stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        try:
            deadline=time.monotonic()+3
            while not child_pid.exists() and time.monotonic()<deadline:time.sleep(.005)
            assert child_pid.exists(),label+' child did not start'
            pid=int(child_pid.read_text())
            if mode=='kill':p.kill();p.wait(timeout=2)
            elif mode=='exit':p.wait(timeout=2)
            else:
                try:p.wait(timeout=.03)
                except subprocess.TimeoutExpired:pass
                else:raise AssertionError('expected timeout')
            stop_process_group(p)
            time.sleep(.7)
            status_path=Path('/proc')/str(pid)/'stat'
            state=status_path.read_text().split()[2] if status_path.exists() else 'ABSENT'
            assert state in ('Z','X','ABSENT'),(label,state)
            assert not marker.exists(), label+' orphan wrote after cleanup'
            tests.append({'fixture':label,'pass':True,'leader_returncode':p.returncode,'child_final_state':state,'late_file_absent':True})
        finally:stop_process_group(p)
    save(ROOT/'selftests/PROCESS_CLEANUP.json',{'utc':now(),'status':'PASS','scope':'3 invented pure-stdlib subprocess faults; zero PyVRP imports and zero CVRP optimizer calls','fixtures':tests})
    print('PASS 3 process-group cleanup faults; no delayed writes')
if __name__=='__main__':main()
