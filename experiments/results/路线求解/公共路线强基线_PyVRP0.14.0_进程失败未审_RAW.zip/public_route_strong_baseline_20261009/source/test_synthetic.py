"""Only invented toy instances. Requires separately authorized PyVRP installation."""
from pathlib import Path
import sys,json,subprocess,time
from common import ROOT,read,save,sha,now
from run_once import child_environment
sys.path.insert(0,str(ROOT/'independent_review'))
from independent_validator import validate_solution
FIXTURES=[
 {'instance_id':'INVENTED_SLACK_K','coordinates':[[0,0],[10,0],[11,0],[12,0]],'demands':[0,1,1,1],'capacity':3,'K':3},
 {'instance_id':'INVENTED_CAPACITY_SPLIT','coordinates':[[0,0],[1,0],[2,0],[0,2]],'demands':[0,2,2,2],'capacity':4,'K':2},
 {'instance_id':'INVENTED_ROUNDING','coordinates':[[0,0],[0.5,0],[2,2],[3,1]],'demands':[0,1,1,1],'capacity':3,'K':2},
 {'instance_id':'INVENTED_DUPLICATE_LOCATION','coordinates':[[0,0],[1,1],[1,1],[4,0]],'demands':[0,1,1,2],'capacity':3,'K':2},
]
def main():
    python=read('environment/RUNTIME.json')['python_executable']
    results=[]
    for index,fixture in enumerate(FIXTURES):
        payload={k:v for k,v in fixture.items() if k!='instance_id'}
        payload.update(seed=0,max_runtime_seconds=0.05)
        start=time.monotonic()
        p=subprocess.run([python,'-B',str(ROOT/'source/worker.py')],input=json.dumps(payload).encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=10,env=child_environment())
        prefix=ROOT/'selftests'/fixture['instance_id']
        prefix.with_suffix('.stdout').write_bytes(p.stdout);prefix.with_suffix('.stderr').write_bytes(p.stderr)
        assert p.returncode==0, p.stderr.decode()[:1000]
        result=json.loads(p.stdout)
        valid=validate_solution(fixture,result['routes'],result['reported_cost'])
        assert result['solver_is_feasible'] and result['solver_is_complete'] and valid['valid']
        assert result['reported_cost']==result['reported_distance']
        assert result['reported_fixed_vehicle_cost']==result['reported_duration_cost']==0
        assert result['denied_io_events']==[]
        if index==0:assert len(result['routes'])<fixture['K'], 'Slack K fixture unexpectedly uses all vehicles'
        results.append({'instance':fixture,'returncode':p.returncode,'elapsed_seconds':time.monotonic()-start,'validation':valid,'native_routes':result['native_routes'],'stdout_sha256':sha(prefix.with_suffix('.stdout')),'stderr_sha256':sha(prefix.with_suffix('.stderr'))})
    save(ROOT/'selftests/SYNTHETIC_SOLVER.json',{'utc':now(),'status':'PASS','formal_public_calls':0,'synthetic_calls':len(FIXTURES),'tuned':False,'fixtures':results})
    print('PASS',len(FIXTURES),'invented synthetic calls; zero public benchmark calls')
if __name__=='__main__':main()
