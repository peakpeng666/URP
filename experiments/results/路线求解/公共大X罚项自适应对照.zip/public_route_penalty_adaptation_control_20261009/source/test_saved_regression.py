"""Pure saved-data endpoint/trace/ledger checks. No solver or native construction."""
import copy
import json
from common import ROOT, read, save, now, sha
from endpoints import (audit_answer, audit_observation, audit_ledger, trajectory_diagnostic,
                       paired_record, summarize, invalidate)


def main():
    errors = []
    fixture = read('selftests/integration/PLANNED.json')['fixtures'][0]
    old_plan = read('selftests/integration/PLANNED.json')
    entry = next(e for e in old_plan['schedule'] if e['call_id'] == 'TOY_FEASIBLE_p50_observed')
    answer = read('selftests/integration/calls/' + entry['call_id'] + '.stdout')
    # Explicit schema fixture only: retain original source unchanged; supplement
    # newly introduced guard-metadata fields from its zero-solver verified shape.
    fixed = read('selftests/warning_recheck/calls/TOY_IMPOSSIBLE_p50_observed_warning_fix_recheck.stdout')
    answer['warning_source_verification'] = copy.deepcopy(fixed['warning_source_verification'])
    answer['allowed_warning_source_reads'] = []
    defaults = read('environment/DEFAULT_SOLVE_PARAMS.json')
    good = audit_answer(fixture, entry, answer, defaults)
    assert good['valid_record'] and good['valid_feasible'], good
    cases = []
    def reject(label, mutate):
        bad = copy.deepcopy(answer)
        mutate(bad)
        audited = audit_answer(fixture, entry, bad, defaults)
        assert not audited['valid_record'], label
        cases.append({'case': label, 'status': audited['status'], 'errors': audited['errors']})
    reject('different_numeric_parameter', lambda a: a['default_solve_params']['values']['penalty']['values'].__setitem__('target_feasible', 0.7))
    reject('different_native_fleet', lambda a: a['native_model_parameters']['vehicle'].__setitem__('num_available', 3))
    reject('missing_stats_iteration', lambda a: a['stats'].pop())
    reject('unexpected_allowed_file', lambda a: a['allowed_warning_source_reads'].append({'path': '/not/authorized'}))
    reject('false_feasible_flag', lambda a: a.__setitem__('solver_is_feasible', False))
    reject('bad_route_cost', lambda a: a.__setitem__('reported_cost', a['reported_cost'] + 1))
    reject('wrong_old_evaluator_probe', lambda a: a['penalty_observation']['rows'][49]['observed_search_evaluator_integer_probes'][0].__setitem__('load', 7))
    reject('missing_observation_iteration', lambda a: a['penalty_observation']['rows'].pop())
    impossible_entry = read('selftests/warning_recheck/PLANNED.json')['schedule'][1]
    impossible = read('selftests/warning_recheck/PLANNED.json')['fixture']
    failed = audit_answer(impossible, impossible_entry, fixed, defaults)
    assert failed['valid_record'] and not failed['valid_feasible']
    assert failed['status'] == 'NO_FEASIBLE_INCUMBENT_WITHIN_BUDGET'
    rows = [paired_record('INVENTED_' + str(i // 3), i % 3, good, failed if i == 35 else good) for i in range(36)]
    summary = summarize(rows)
    assert summary['planned_cells'] == 72 and summary['feasibility']['p50']['feasible'] == 35
    assert summary['complete_primary']['delta_cost']['mean'] is None
    assert summary['conditional_common_success']['delta_cost']['n'] == 35
    assert summary['paired_success_transitions']['success_failure'] == 1
    all_good = summarize([paired_record('FIX', 0, good, good) for _ in range(36)])
    assert all_good['complete_primary']['delta_cost']['mean'] == 0
    assert trajectory_diagnostic(answer, answer, 50, 'same')['status'] == 'SAME'
    changed = copy.deepcopy(answer)
    changed['stats'][0]['current_cost'] += 1
    diagnostic = trajectory_diagnostic(answer, changed, 50, 'changed')
    assert diagnostic['status'] == 'DIFFERENT' and diagnostic['first_difference']['iteration'] == 1
    assert diagnostic['is_inclusion_or_rerun_gate'] is False and good['valid_feasible']
    attempts = [json.loads(line) for line in (ROOT / 'selftests/integration/attempts.jsonl').read_text().splitlines()]
    results = [json.loads(line) for line in (ROOT / 'selftests/integration/results.jsonl').read_text().splitlines()]
    assert audit_ledger(old_plan['schedule'], attempts, results)['status'] == 'PASS'
    assert audit_ledger(old_plan['schedule'], attempts[:-2], results[:-1])['status'] != 'PASS'
    duplicate = results + [results[-1]]
    assert audit_ledger(old_plan['schedule'], attempts, duplicate)['status'] != 'PASS'
    bad_events = copy.deepcopy(attempts)
    bad_events[0]['event_kind'] = 'BAD'
    assert audit_ledger(old_plan['schedule'], bad_events, results)['status'] != 'PASS'
    # Verify theoretical check points and observable new-value timing separately.
    trace = audit_observation(fixed, 50)
    assert trace['valid'] and trace['scheduled_update_checks'] == [50, 100, 150, 200, 250]
    assert trace['search_affected_checkpoints_source_derived'] == [51, 101, 151, 201]
    save(ROOT / 'selftests/SAVED_REGRESSION.json', {'status': 'PASS', 'utc': now(), 'solver_calls': 0,
         'scope': 'Saved tiny fixtures and explicit guard-schema-only supplementation. No replacement of original8 results.',
         'rejection_cases': cases, 'full72_missing_failure_summary': summary,
         'prefix_mismatch_is_diagnostic_only': diagnostic, 'source_sha256': sha(ROOT / 'source/endpoints.py')})
    print('PASS saved endpoint, trace, failure-denominator and ledger checks; zero solver calls')


if __name__ == '__main__':
    main()
