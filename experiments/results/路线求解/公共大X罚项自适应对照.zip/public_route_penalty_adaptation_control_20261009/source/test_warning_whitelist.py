"""Default-warning path and denials, using the worker import order; no solver."""
import json
import sys
import warnings
import worker
from pyvrp import solve, SolveParams
from pyvrp.stop import MaxIterations
from pyvrp.PenaltyManager import PenaltyParams
from pyvrp.IteratedLocalSearch import IteratedLocalSearchParams
from pyvrp.exceptions import PenaltyBoundWarning
from observer import ReadonlyPenaltyObserver
from io_guard import verified_io_guard, WARNING_SOURCE, READ_FLAGS

denied, allowed = [], []
hook, receipt = verified_io_guard(denied, allowed)
# Check disallowed event shapes without issuing any write or network operation.
rejections = []
for event, args in [('open', (WARNING_SOURCE, 'w', 577)),
                    ('open', (WARNING_SOURCE + '.other', 'r', READ_FLAGS)),
                    ('socket.connect', ('not_a_real_socket',)),
                    ('subprocess.Popen', ('not_a_real_program',))]:
    try:
        hook(event, args)
    except PermissionError:
        rejections.append({'event': event, 'args': list(args), 'rejected': True})
    else:
        raise AssertionError('Disallowed shape accepted')
denied.clear()
sys.addaudithook(hook)
warnings.warn_explicit('Zero-solver default-warning whitelist test', PenaltyBoundWarning, WARNING_SOURCE, 228)
assert len(allowed) == 1 and denied == []
print(json.dumps({'status': 'PASS', 'solver_calls': 0, 'model_or_solution_constructions': 0,
                  'allowed_source_reads': allowed, 'actual_denied_events': denied,
                  'simulated_disallowed_event_shapes': rejections, 'source_verification': receipt}))
