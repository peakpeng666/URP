"""Unique outer executor: reap/stop whole process group before sealing raw evidence."""
import subprocess,sys,os,signal,time,json
from common import ROOT,now,sha,read,save,verify_frozen,verify_old,receipt
from run_once import child_environment
from package import package
from process_lifecycle import parent_death,wait_group_quiescent

def stop_process_group(p):
    if p is not None:
        # A dead leader can leave a child in this process group.
        try:os.killpg(p.pid,signal.SIGKILL)
        except ProcessLookupError:pass
        p.wait()
        remaining=wait_group_quiescent(p.pid,timeout=2)
        return {'quiescent':not remaining,'remaining_group_members':remaining}
    return {'quiescent':True,'remaining_group_members':[]}

def main():
    if not __debug__:raise RuntimeError('Assertions must be enabled')
    verify_frozen();verify_old();preexec=receipt('PREEXEC')
    approval=read('provenance/PARENT_EXECUTION_APPROVAL.json')
    assert approval['approved'] is True and approval['frozen_files_sha256']==sha(ROOT/'freeze/FROZEN_FILES.json')
    assert approval['preexec_archive_sha256']==preexec['sha256']
    assert approval['scope']=='one frozen72-call paired penalty500-versus50 PyVRP250-iteration batch; no retry'
    assert read('freeze/INDEPENDENT_PRECHECK.json')['status']=='PASS'
    save(ROOT/'raw/EXECUTOR_STARTED.json',{'utc':now(),'no_retries':True})
    out=ROOT/'raw/supervisor.stdout';err=ROOT/'raw/supervisor.stderr'
    p=None;timed_out=False;error=None;started=time.monotonic();parent=os.getpid()
    try:
        with out.open('xb') as fo,err.open('xb') as fe:
            p=subprocess.Popen([sys.executable,'-B',str(ROOT/'source/run_once.py')],stdout=fo,stderr=fe,
                               env=child_environment(),cwd=ROOT/'raw',start_new_session=True,
                               preexec_fn=lambda:parent_death(parent))
            try:p.wait(timeout=1958)
            except subprocess.TimeoutExpired:timed_out=True
    except Exception as exc:error=repr(exc)
    finally:
        cleanup=stop_process_group(p)
    save(ROOT/'raw/EXECUTOR_FINISHED.json',{'utc':now(),'supervisor_returncode':p.returncode if p else None,'external_timeout':timed_out,'launcher_error':error,'process_group_kill_attempt_completed_before_seal':True,'cleanup':cleanup,'wall_seconds_audit_only':time.monotonic()-started})
    if not cleanup['quiescent']:raise RuntimeError('WORKER_GROUP_NOT_QUIESCENT_NO_SEAL')
    print(json.dumps(package('RAW_UNREVIEWED')))
if __name__=='__main__':main()
