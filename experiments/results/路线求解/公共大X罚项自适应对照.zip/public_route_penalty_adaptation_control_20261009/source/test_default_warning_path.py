import json, sys, warnings
source = "/workspace/shared/public_route_strong_baseline_20261009_venv/lib/python3.12/site-packages/pyvrp/PenaltyManager.py"
events = []
def audit(event, args):
    if event == "open" or event.startswith(("socket.", "subprocess.", "os.system", "os.exec", "os.spawn")):
        events.append({"event": event, "args": list(args)})
        raise PermissionError("Source read denied by existing worker rule")
sys.addaudithook(audit)
warnings.warn_explicit("Zero-solver diagnostic of default warning formatting", UserWarning, source, 228)
print(json.dumps({"scope": "Default warnings formatting only; no PyVRP import or native construction or solver call", "observed_blocked_events": events}))
