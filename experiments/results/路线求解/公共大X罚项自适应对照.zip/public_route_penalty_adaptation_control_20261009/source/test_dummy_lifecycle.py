"""Production subprocess/logging path with pure-stdlib failing dummy workers."""
import json
from common import ROOT, read, save, now
from run_once import logged_call, execute_call, configure_supervisor_limits
from endpoints import audit_ledger


def main():
    limits = configure_supervisor_limits()
    dest = ROOT / 'selftests/dummy_lifecycle'
    dest.mkdir(exist_ok=False)
    calls = dest / 'calls'
    calls.mkdir()
    schedule, records = [], []
    python = read('environment/RUNTIME.json')['python_executable']
    for i, mode in enumerate(('malformed', 'missing_fields', 'nonzero'), 1):
        entry = {'call_id': 'DUMMY_' + mode, 'seed': 0, 'max_iterations': 250,
                 'solutions_between_updates': 50, 'schedule_index': i}
        schedule.append(entry)
        result = logged_call(entry, {'mode': mode}, python, calls, dest, ROOT / 'source/dummy_fault_worker.py')
        assert result['child_reaped'] and result['status'] in ('CALL_ERROR_UNDETERMINED', 'PROCESS_FAILURE_OR_CPU_LIMIT')
        records.append(result)
    duplicate = execute_call(schedule[0], {'mode': 'malformed'}, python, calls, ROOT / 'source/dummy_fault_worker.py')
    assert not duplicate['process_spawned'] and duplicate['status'] == 'CALL_ERROR_UNDETERMINED'
    events = [json.loads(line) for line in (dest / 'attempts.jsonl').read_text().splitlines()]
    ledger = audit_ledger(schedule, events, records)
    assert ledger['status'] == 'PASS'
    save(ROOT / 'selftests/DUMMY_LIFECYCLE.json', {'status': 'PASS', 'utc': now(), 'solver_calls': 0,
         'spawned_dummy_processes': 3, 'duplicate_guard_spawned': False, 'limits': limits, 'ledger': ledger})
    print('PASS production logging3 dummy failures and duplicate output guard; zero solver calls')


if __name__ == '__main__':
    main()
