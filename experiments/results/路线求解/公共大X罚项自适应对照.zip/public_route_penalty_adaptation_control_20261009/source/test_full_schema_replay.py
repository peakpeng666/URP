"""Production report collector on invented72-cell saved-data fixtures, no optimizer."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
from common import ROOT, save, read, now, sha
from endpoints import payload_for


def main():
    base = ROOT / 'selftests/full_schema_replay'
    base.mkdir(exist_ok=False)
    for folder in ['freeze', 'environment', 'input', 'raw/calls', 'historical_reference/calls']:
        (base / folder).mkdir(parents=True, exist_ok=True)
    fixtures = read('selftests/integration/PLANNED.json')['fixtures']
    tiny = fixtures[0]
    variants = {interval: read(f'selftests/integration/calls/TOY_FEASIBLE_p{interval}_observed.stdout') for interval in (500, 50)}
    old = read('selftests/integration/calls/TOY_FEASIBLE_p500_plain.stdout')
    verified = read('selftests/warning_recheck/calls/TOY_IMPOSSIBLE_p50_observed_warning_fix_recheck.stdout')['warning_source_verification']
    tasks, schedule, historical, records, events = [], [], [], [], []
    for slot in range(1, 13):
        iid = 'INVENTED_SCHEMA_' + str(slot)
        problem = {**tiny, 'instance_id': iid}
        tasks.append({'instance_id': iid, 'K_ref': 2, 'n_customers': 4})
        (base / 'input' / (iid + '.json')).write_text(json.dumps(problem))
        for seed in (0, 1, 2):
            pi = (slot - 1) * 3 + seed + 1
            original = copy.deepcopy(old)
            original['seed'] = seed
            old_path = base / 'historical_reference/calls' / f'{iid}_s{seed}.json'
            old_path.write_text(json.dumps(original))
            historical.append({'instance_id': iid, 'seed': seed, 'output_file': str(old_path.relative_to(base)), 'stdout_sha256': sha(old_path)})
            for order, interval in enumerate((500, 50) if pi % 2 else (50, 500), 1):
                entry = {'instance_id': iid, 'seed': seed, 'K': 2, 'call_id': f'{iid}_s{seed}_p{interval}', 'solutions_between_updates': interval, 'max_iterations': 250, 'pair_index': pi, 'within_pair_order': order, 'schedule_index': len(schedule) + 1}
                schedule.append(entry)
                answer = copy.deepcopy(variants[interval])
                answer['seed'] = seed
                answer['warning_source_verification'] = verified
                answer['allowed_warning_source_reads'] = []
                path = base / 'raw/calls' / (entry['call_id'] + '.json')
                path.write_text(json.dumps(answer))
                payload = payload_for(problem, entry)
                item = {'call_id': entry['call_id'], 'schedule': entry, 'status': 'UNREVIEWED_PROCESS_SUCCESS', 'returncode': 0,
                        'stdout': str(path.relative_to(base)), 'stdout_sha256': sha(path),
                        'payload_sha256': hashlib.sha256(json.dumps(payload, separators=(',', ':')).encode()).hexdigest(),
                        'process_spawned': True, 'child_reaped': True}
                records.append(item)
                events.extend([{'event_kind': 'STARTED', 'utc': 'SYNTHETIC_FIXTURE_NOT_AN_EXECUTION', 'call_id': entry['call_id'], 'schedule': entry},
                               {'event_kind': 'FINISHED', 'utc': 'SYNTHETIC_FIXTURE_NOT_AN_EXECUTION', 'call_id': entry['call_id'], 'schedule': entry, 'result': item}])
    for path, value in [('freeze/TASKS.json', tasks), ('freeze/SCHEDULE.json', schedule), ('freeze/HISTORICAL_CELLS.json', {'all36': historical}), ('environment/DEFAULT_SOLVE_PARAMS.json', read('environment/DEFAULT_SOLVE_PARAMS.json'))]:
        (base / path).write_text(json.dumps(value))
    def ledgers(items, attempts):
        (base / 'raw/results.jsonl').write_text(''.join(json.dumps(x) + '\n' for x in items))
        (base / 'raw/attempts.jsonl').write_text(''.join(json.dumps(x) + '\n' for x in attempts))
    spec = importlib.util.spec_from_file_location('fixture_report', ROOT / 'source/report.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.ROOT = base
    module.read = lambda relative: json.loads((base / relative).read_text())
    ledgers(records, events)
    complete = module.collect_saved_evidence()
    assert len(complete['rows']) == 36 and len(complete['diagnostics']) == 72
    assert complete['overall']['feasibility']['p500']['feasible'] == 36
    assert complete['overall']['feasibility']['p50']['feasible'] == 36
    assert complete['ledger']['status'] == 'PASS'
    ledgers(records[:-1], events[:-2])
    missing = module.collect_saved_evidence()
    assert len(missing['rows']) == 36 and missing['overall']['planned_cells'] == 72
    assert missing['overall']['feasibility']['p500']['feasible'] == 35
    assert missing['overall']['complete_primary']['delta_cost']['mean'] is None
    assert missing['overall']['conditional_common_success']['delta_cost']['n'] == 35
    assert missing['rows'][-1]['cells']['p500']['status'] == 'MISSING_RESULT'
    ledgers(records, events)
    # A six-field prefix difference is only diagnostic, with no route/record rejection.
    entry = schedule[1]
    path = base / records[1]['stdout']
    answer = json.loads(path.read_text())
    answer['stats'][0]['current_cost'] += 1
    path.write_text(json.dumps(answer))
    records[1]['stdout_sha256'] = sha(path)
    events[3]['result'] = records[1]
    ledgers(records, events)
    different = module.collect_saved_evidence()
    assert different['diagnostics'][0]['status'] == 'DIFFERENT'
    assert different['overall']['feasibility']['p50']['feasible'] == 36
    save(ROOT / 'selftests/FULL_SCHEMA_REPLAY.json', {'status': 'PASS', 'utc': now(), 'optimizer_calls': 0,
         'scope': 'Invented schema-only cloned tiny saved outputs with synthetic seed labels, never experimental measurements. Exercise actual production collector, not its gate/receipt main.',
         'complete72_case': {'planned_pairs': 36, 'primary_feasible500': 36, 'primary_feasible50': 36},
         'missing_last_case': {'planned_cells': 72, 'primary_feasible500': 35, 'primary_paired_cost_null': True, 'common_success': 35},
         'prefix_difference_case': {'diagnostic': 'DIFFERENT', 'primary_feasible50': 36, 'retained_without_rerun': True},
         'source_report_sha256': sha(ROOT / 'source/report.py'), 'source_endpoints_sha256': sha(ROOT / 'source/endpoints.py')})
    print('PASS full72 schema collector, missing-slot retention and non-gating prefix diagnostic; zero solver calls')


if __name__ == '__main__':
    main()
