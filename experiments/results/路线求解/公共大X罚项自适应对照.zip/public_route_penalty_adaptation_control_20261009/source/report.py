"""Report saved fresh paired outputs after RAW readback and independent audit."""
import json
import math
import resource
import signal
from collections import Counter
from common import ROOT, read, save, sha, now, receipt, verify_frozen, verify_old
from endpoints import audit_call, audit_ledger, invalidate, paired_record, summarize, trajectory_diagnostic


def independent_match(expected, actual, path='root'):
    if isinstance(expected, dict):
        assert isinstance(actual, dict), path
        for key, value in expected.items():
            assert key in actual, path + '.' + key
            independent_match(value, actual[key], path + '.' + key)
    elif isinstance(expected, list):
        assert isinstance(actual, list) and len(expected) == len(actual), path
        for i, (left, right) in enumerate(zip(expected, actual)):
            independent_match(left, right, f'{path}[{i}]')
    elif isinstance(expected, float):
        assert type(actual) in (int, float) and math.isclose(expected, actual, rel_tol=1e-12, abs_tol=1e-12), path
    else:
        assert expected == actual, path


def ledger_rows(path):
    rows, errors = [], []
    if not path.exists():
        return rows, errors
    for number, line in enumerate(path.read_text(errors='replace').splitlines(), 1):
        try:
            row = json.loads(line)
            if not isinstance(row, dict):
                raise ValueError('Not an object')
            rows.append(row)
        except (ValueError, TypeError) as exc:
            errors.append({'path': str(path.relative_to(ROOT)), 'line': number, 'error': str(exc)})
    return rows, errors


def collect_saved_evidence():
    tasks, schedule = read('freeze/TASKS.json'), read('freeze/SCHEDULE.json')
    history = read('freeze/HISTORICAL_CELLS.json')['all36']
    assert len(tasks) == 12 and len(schedule) == 72 and len(history) == 36
    results, result_errors = ledger_rows(ROOT / 'raw/results.jsonl')
    events, event_errors = ledger_rows(ROOT / 'raw/attempts.jsonl')
    ledger = audit_ledger(schedule, events, results)
    ledger['parse_errors'] = result_errors + event_errors
    if ledger['parse_errors']:
        ledger['errors'].append('MALFORMED_LEDGER_JSONL')
        ledger['status'] = 'INCOMPLETE_OR_INVALID'
    ledger_by_id = {row['call_id']: row for row in ledger['calls']}
    item_by_id = {row.get('call_id'): row for row in results}
    originals = {}
    for h in history:
        path = ROOT / h['output_file']
        assert path.resolve().is_relative_to((ROOT / 'historical_reference/calls').resolve())
        assert sha(path) == h['stdout_sha256']
        originals[(h['instance_id'], h['seed'])] = json.loads(path.read_text())
    problems = {t['instance_id']: read('input/' + t['instance_id'] + '.json') for t in tasks}
    defaults = read('environment/DEFAULT_SOLVE_PARAMS.json')
    answers, audits = {}, {}
    for entry in schedule:
        key = (entry['instance_id'], entry['seed'], entry['solutions_between_updates'])
        item, answer, errors = item_by_id.get(entry['call_id']), None, []
        if item:
            try:
                path = ROOT / item['stdout']
                assert path.resolve().is_relative_to((ROOT / 'raw/calls').resolve())
                assert sha(path) == item['stdout_sha256']
                answer = json.loads(path.read_text())
            except (OSError, ValueError, KeyError, TypeError, AssertionError) as exc:
                errors.append('OUTPUT_READ_OR_HASH_ERROR:' + repr(exc))
        problem = {**problems[entry['instance_id']], 'K': entry['K']}
        original = originals[(entry['instance_id'], entry['seed'])]
        audit = audit_call(problem, entry, item, answer, defaults, original)
        invalidate(audit, errors + ledger['errors'] + ledger_by_id[entry['call_id']]['errors'])
        answers[key], audits[key] = answer, audit
    rows, diagnostics = [], []
    for task in tasks:
        iid = task['instance_id']
        for seed in [0, 1, 2]:
            left, right = answers[(iid, seed, 500)], answers[(iid, seed, 50)]
            rows.append(paired_record(iid, seed, audits[(iid, seed, 500)], audits[(iid, seed, 50)]))
            prefix = trajectory_diagnostic(left, right, 50, 'fresh500_vs_fresh50_first50')
            prefix.update(instance_id=iid, seed=seed)
            diagnostics.append(prefix)
            historical = trajectory_diagnostic(originals[(iid, seed)], left, 250, 'historical500_vs_fresh500_all250')
            historical.update(instance_id=iid, seed=seed)
            original = originals[(iid, seed)]
            fields = ['routes', 'reported_cost', 'reported_distance', 'solver_is_feasible', 'solver_is_complete', 'native_model_parameters', 'model_matrix_sha256']
            historical['returned_solution_and_model_fields_equal'] = all(original.get(f) == left.get(f) for f in fields) if isinstance(left, dict) else None
            diagnostics.append(historical)
    per_instance = [{'instance_id': task['instance_id'], 'K_ref': task['K_ref'],
                     **summarize([row for row in rows if row['instance_id'] == task['instance_id']])} for task in tasks]
    return {'rows': rows, 'overall': summarize(rows), 'per_instance': per_instance,
            'diagnostics': diagnostics, 'ledger': ledger, 'observed_records': len(results)}


def main():
    verify_frozen()
    verify_old()
    raw = receipt('RAW_UNREVIEWED')
    independent = read('independent_supervision/results/SAVED_PENALTY_AUDIT.json')
    assert independent['status'] == 'SAVED_EVIDENCE_AUDITED'
    assert independent['raw_archive_sha256'] == raw['sha256']
    assert independent['frozen_files_sha256'] == sha(ROOT / 'freeze/FROZEN_FILES.json')
    assert independent['planned_calls'] == 72 and len(independent['rows']) == 36
    evidence = collect_saved_evidence()
    assert independent['observed_records'] == evidence['observed_records']
    for other, ours in zip(independent['rows'], evidence['rows']):
        keys = ('instance_id', 'seed', 'common_success', 'delta_cost', 'relative_delta_pct', 'delta_vehicles')
        independent_match({k: other[k] for k in keys}, ours)
        for arm in ('p500', 'p50'):
            independent_match({k: other['cells'][arm][k] for k in ('status', 'valid_record', 'valid_feasible', 'cost', 'vehicles')}, ours['cells'][arm])
    independent_match(independent['overall'], evidence['overall'])
    independent_match(independent['per_instance'], evidence['per_instance'])
    assert len(independent['diagnostics']) == 72
    for other, ours in zip(independent['diagnostics'], evidence['diagnostics']):
        keys = ('label', 'instance_id', 'seed', 'status', 'first_difference')
        independent_match({k: other[k] for k in keys}, ours)
        if ours['label'].startswith('historical'):
            independent_match(other['returned_solution_and_model_fields_equal'], ours['returned_solution_and_model_fields_equal'])
    overall = evidence['overall']
    diagnostic_counts = {label: dict(Counter(d['status'] for d in evidence['diagnostics'] if d['label'] == label)) for label in ('fresh500_vs_fresh50_first50', 'historical500_vs_fresh500_all250')}
    summary = {'utc': now(), 'question': 'Fixed250-iteration paired public penalty registration500 versus50 on the already-observed X12 panel with K_ref',
               'new_planned_calls': 72, 'new_observed_records': evidence['observed_records'],
               'historical_reference_cells': 36, 'historical_cells_in_primary': 0,
               'overall': overall, 'diagnostic_counts': diagnostic_counts,
               'ledger_status': evidence['ledger']['status'],
               'raw_archive_sha256': raw['sha256'], 'frozen_files_sha256': sha(ROOT / 'freeze/FROZEN_FILES.json'),
               'independent_audit_sha256': sha(ROOT / 'independent_supervision/results/SAVED_PENALTY_AUDIT.json'),
               'independent_endpoints_match': True,
               'synthetic_disclosure': 'Original eight attempts preserved including two warning-IO audit failures; exactly two authorized technical rechecks after a minimal source-read-only whitelist. Total10 attempts, one of four observer/no-op groups uses rechecked cells.',
               'last_update_notice': 'The scheduled update at iteration250 end cannot influence any route within this run. At most four updated evaluator blocks are used, starting51/101/151/201; a scheduled check need not change numeric values.',
               'interpretation': 'Fixed already-observed panel descriptive comparison; no p-values, independent fresh instances, generalized causal mechanism, speed/optimality/SOTA or agricultural-fleet inference. Failed/missing cells retained; conditional common-success quality never replaces complete primary.'}
    for name, value in [('SUMMARY', summary), ('PAIRED_RESULTS', evidence['rows']), ('PER_INSTANCE', evidence['per_instance']), ('DIAGNOSTICS', evidence['diagnostics']), ('LEDGER_AUDIT', evidence['ledger'])]:
        save(ROOT / 'reports' / (name + '.json'), value)
    f = overall['feasibility']
    lines = ['固定250轮ILS的罚项适应对照：500与50登记间隔', '',
             f"新配对72调用：500档有效可行{f['p500']['feasible']}/36，50档{f['p50']['feasible']}/36。",
             f"描述性配对成功率差（50−500）：{100 * overall['descriptive_paired_risk_difference']}个百分点。迁移：{overall['paired_success_transitions']}。",
             '所有分母固定；进程/guard/输出/账本异常与完成预算但无可行解分开保留。旧36只是一致性参考，不进入主指标或增加样本数。', '',
             '末尾更新的重要边界：第50/100/150/200/250轮尾是更新检查点；新罚项最早用于51/101/151/201轮。第250轮尾第五次检查不可能影响本批任何路线，而且数值更新不保证每次变化。', '',
             f"全体36对平均路线成本差：{overall['complete_primary']['delta_cost']['mean']}；只有全部72格有效可行才有此全体配对统计。",
             f"共同成功条件子集n={overall['common_success_count']}/36，平均成本差{overall['conditional_common_success']['delta_cost']['mean']}，平均相对差{overall['conditional_common_success']['relative_delta_pct']['mean']}%；不能替代全体指标。",
             f"预声明一致性诊断：{diagnostic_counts}。全部不同/不可用结果保留，不触发重跑或筛选。", '',
             '观测和解释边界',
             '- 两臂相同只读公开callback；仅登记间隔500→50改变。K_ref取原冻结SOL路线数，非文件名k；250轮不包含默认初始化。',
             '- callback读取PM公开浮点快照及当轮evaluator的公开整数探针，后者不能恢复全部隐藏double。source-derived字段明确是源码顺序推导。',
             '- callback的candidate可能已经exhaustive-on-best替换，未用它或stats.candidate_feas重构实际登记窗口。',
             '- 同固定迭代数不等于同CPU、wall或基本操作量；罚后cost不能跨更新块或两臂当物理路线成本比较。',
             '- 同一已观察12题/3seed的探索性干预，不能据三个先前失败就认定登记频率是唯一原因；未新增独立实例，不作统计显著性/SOTA/农业车队外推。',
             '- 原8个合成尝试中2个warning源文件读取被过宽IO规则拦截，原失败保留。经预批仅加2技术复核，共10；4组observer/no-op对照中1组采用复核结果。无默认warning替换，仅精确已哈希源码只读白名单。',
             '- 正式公共72每格仅一次，无warm start、失败救场升预算、补seed、调参扫网格或solver patch。', '', '逐题（两档各3个seed全部保留）']
    for row in evidence['per_instance']:
        lines.append(f"{row['instance_id']} K_ref={row['K_ref']}：500档{row['feasibility']['p500']['feasible']}/3，50档{row['feasibility']['p50']['feasible']}/3；共同成功{row['common_success_count']}/3。")
    with (ROOT / 'reports/REPORT_ZH.txt').open('x') as stream:
        stream.write('\n'.join(lines) + '\n')
    print(json.dumps({'new_feasible500': f['p500']['feasible'], 'new_feasible50': f['p50']['feasible'], 'ledger': evidence['ledger']['status'], 'diagnostics': diagnostic_counts}, ensure_ascii=False))


if __name__ == '__main__':
    resource.setrlimit(resource.RLIMIT_CPU, (30, 30))
    resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
    signal.alarm(120)
    main()
