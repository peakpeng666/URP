"""Two specifically authorized technical rechecks; preserve all original eight calls."""
import json
import signal
from common import ROOT, read, save, now, sha
from run_once import logged_call
from endpoints import payload_for, audit_call, audit_ledger


def run_recheck(limits):
    signal.alarm(75)
    dest = ROOT / 'selftests/warning_recheck'
    dest.mkdir(exist_ok=False)
    calls = dest / 'calls'
    calls.mkdir()
    original = read('selftests/integration/PLANNED.json')
    fixture = next(f for f in original['fixtures'] if f['instance_id'] == 'TOY_IMPOSSIBLE')
    originals = [e for e in original['schedule'] if e['instance_id'] == 'TOY_IMPOSSIBLE' and e['solutions_between_updates'] == 50]
    assert len(originals) == 2
    schedule = [{**e, 'call_id': e['call_id'] + '_warning_fix_recheck', 'technical_recheck_of': e['call_id'], 'schedule_index': i + 1} for i, e in enumerate(originals)]
    save(dest / 'PLANNED.json', {'purpose': 'Explicit root-approved two-cell technical recheck after exact-source read-only warning guard fix', 'fixture': fixture, 'schedule': schedule, 'additional_solver_calls': 2})
    python = read('environment/RUNTIME.json')['python_executable']
    records = [logged_call(e, payload_for(fixture, e, e['observe_penalties']), python, calls, dest) for e in schedule]
    answers, audits, errors = [], [], []
    for e, item in zip(schedule, records):
        answer = None
        try:
            answer = json.loads((ROOT / item['stdout']).read_text())
        except (ValueError, OSError) as exc:
            errors.append('Unreadable output ' + repr(exc))
        audit = audit_call(fixture, e, item, answer, read('environment/DEFAULT_SOLVE_PARAMS.json'), observe=e['observe_penalties'])
        if not audit['valid_record'] or audit['valid_feasible']:
            errors.append(e['call_id'] + ':' + repr(audit['errors']))
        if isinstance(answer, dict) and len(answer.get('allowed_warning_source_reads', [])) != 1:
            errors.append('Expected one default-warning source read for ' + e['call_id'])
        answers.append(answer)
        audits.append(audit)
    fields = ['stats', 'routes', 'reported_cost', 'reported_distance', 'solver_is_feasible', 'native_model_parameters', 'model_matrix_sha256']
    equal = all(isinstance(a, dict) for a in answers) and all(answers[0][field] == answers[1][field] for field in fields)
    if not equal:
        errors.append('Observer/nonobserver invariance mismatch after warning fix')
    old_same = []
    for original_entry, answer in zip(originals, answers):
        before = read('selftests/integration/calls/' + original_entry['call_id'] + '.stdout')
        old_same.append({'original_call_id': original_entry['call_id'], 'same_non_time_search_and_route_fields': isinstance(answer, dict) and all(before[field] == answer[field] for field in fields)})
    attempts = [json.loads(line) for line in (dest / 'attempts.jsonl').read_text().splitlines()]
    ledger = audit_ledger(schedule, attempts, records)
    if ledger['status'] != 'PASS':
        errors.append('Recheck ledger invalid')
    result = {'status': 'PASS' if not errors else 'FAIL', 'utc': now(), 'errors': errors,
              'newly_authorized_attempts': 2, 'total_synthetic_attempts_across_stages': 10,
              'original_eight_stage_status_retained': read('selftests/SUPERVISOR_INTEGRATION.json')['status'],
              'original_failed_cells_retained': 2, 'four_original_contrast_groups': 4,
              'groups_using_rechecked_cells': 1, 'public_solver_calls': 0,
              'completed_solver_calls_with_outputs': sum(isinstance(a, dict) and a.get('num_iterations') == 250 for a in answers),
              'audits': audits, 'observer_invariance_equal': equal, 'before_after_diagnostics': old_same,
              'ledger': ledger, 'supervisor_limits': limits,
              'source_sha256': {n: sha(ROOT / 'source' / n) for n in ['worker.py', 'observer.py', 'io_guard.py', 'run_once.py', 'endpoints.py', 'synthetic_warning_recheck.py']}}
    signal.alarm(0)
    save(ROOT / 'selftests/WARNING_RECHECK.json', result)
    print(json.dumps({'status': result['status'], 'new_calls': 2, 'total_attempts': 10, 'errors': errors, 'observer_invariance_equal': equal}))
    return 0 if not errors else 1
