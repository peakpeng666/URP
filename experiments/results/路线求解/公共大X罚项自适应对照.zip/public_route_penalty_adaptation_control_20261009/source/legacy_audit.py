"""Saved evidence only; no optimizer. Missing cells never disappear from denominators."""
import copy,hashlib,json,statistics,sys
from pathlib import Path
from route_validator import validate_solution
COST_FIELDS=('current_cost','candidate_cost','best_cost')
BOOL_FIELDS=('current_feas','candidate_feas','best_feas')
STATS_FIELDS=set(COST_FIELDS+BOOL_FIELDS)
ARMS=('standard_n_clients','at_most_K_ref')

def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def hash_payload(problem,entry):
 p={k:problem[k]for k in ('coordinates','demands','capacity','K')};p.update(seed=entry['seed'],max_iterations=entry['max_iterations'])
 return hashlib.sha256(json.dumps(p,separators=(',',':')).encode()).hexdigest()
def comparable_model(standard,actual,K):
 expected=copy.deepcopy(standard);expected['num_vehicles']=K;expected['vehicle']['num_available']=K
 return expected==actual

def audit_ledger(schedule,attempts,items):
 errors=[];expected={e['call_id']:e for e in schedule};byid={};events={cid:[]for cid in expected}
 if len(expected)!=len(schedule):errors.append('DUPLICATE_SCHEDULE_ID')
 for item in items:
  cid=item.get('call_id')
  if cid not in expected:errors.append('UNEXPECTED_RESULT')
  if cid in byid:errors.append('DUPLICATE_RESULT')
  byid[cid]=item
 for event in attempts:
  cid=event.get('call_id')
  if cid not in expected:errors.append('UNEXPECTED_EVENT');continue
  if event.get('schedule')!=expected[cid]:errors.append('EVENT_SCHEDULE_MISMATCH')
  kind=event.get('event_kind')
  if kind not in ('STARTED','FINISHED'):errors.append('INVALID_EVENT_KIND')
  required={'event_kind','utc','call_id','schedule'}|({'result'}if kind=='FINISHED'else set())
  if set(event)!=required:errors.append('EVENT_SCHEMA_MISMATCH')
  if kind=='FINISHED'and event.get('result')!=byid.get(cid):errors.append('FINISHED_RESULT_MISMATCH')
  events[cid].append(kind)
 per=[]
 for entry in schedule:
  cid=entry['call_id'];ev=events[cid];local=[]
  if ev!=['STARTED','FINISHED']:local.append('MISSING_OR_INVALID_START_FINISH_SEQUENCE')
  if cid not in byid:local.append('MISSING_RESULT')
  if cid in byid and byid[cid].get('schedule')!=entry:local.append('RESULT_SCHEDULE_MISMATCH')
  per.append({'call_id':cid,'events':ev,'errors':local,'ledger_valid':not local})
 order=[e.get('call_id')for e in attempts if e.get('event_kind')=='STARTED']
 if order!=[e['call_id']for e in schedule][:len(order)]:errors.append('START_ORDER_MISMATCH')
 expected_lifecycle=[(e['call_id'],kind)for e in schedule for kind in ('STARTED','FINISHED')]
 observed_lifecycle=[(e.get('call_id'),e.get('event_kind'))for e in attempts]
 if observed_lifecycle!=expected_lifecycle[:len(observed_lifecycle)]:errors.append('NON_SERIAL_OR_INVALID_EVENT_LIFECYCLE')
 return {'status':'PASS'if not errors and all(p['ledger_valid']for p in per)else'INCOMPLETE_OR_INVALID','errors':errors,'planned_denominator':len(schedule),'observed_records':len(items),'observed_events':len(attempts),'calls':per}

def audit_saved_answer(problem,entry,answer,standard_answer=None):
 out={'call_id':entry['call_id'],'instance_id':entry['instance_id'],'seed':entry['seed'],'arm':entry['arm'],'budget':entry['max_iterations'],'valid_record':False,'valid_feasible':False,'status':'INVALID_OUTPUT','errors':[],'cost':None,'vehicles':None}
 errs=out['errors'];budget=entry['max_iterations']
 if not isinstance(answer,dict):errs.append('MISSING_OR_MALFORMED_OUTPUT');return out
 try:
  if (answer['solver'],answer['version'],answer['algorithm'])!=('PyVRP','0.14.0','ILS'):errs.append('SOLVER_MISMATCH')
  if answer['seed']!=entry['seed']or type(answer['seed'])is not int:errs.append('SEED_MISMATCH')
  if budget not in (25,250)or type(answer['max_iterations'])is not int or type(answer['num_iterations'])is not int or answer['max_iterations']!=budget or answer['num_iterations']!=budget:errs.append('BUDGET_MISMATCH')
  if answer['denied_io_events']!=[]or answer['reference_or_history_payload_fields']!=[]:errs.append('IO_OR_REFERENCE_VIOLATION')
  stats=answer['stats'];schema=isinstance(stats,list)and len(stats)==budget and all(isinstance(d,dict)and set(d)==STATS_FIELDS and all(type(d[k])is int for k in COST_FIELDS)and all(type(d[k])is bool for k in BOOL_FIELDS)for d in stats)
  if not schema:errs.append('STATS_SCHEMA')
  if not isinstance(answer['stats_runtime_per_iteration'],list)or len(answer['stats_runtime_per_iteration'])!=budget:errs.append('RUNTIME_SCHEMA')
  if type(answer['solver_is_feasible'])is not bool or type(answer['solver_is_complete'])is not bool:errs.append('FLAGS_SCHEMA')
  native=answer['native_model_parameters']
  if native['num_vehicles']!=problem['K']or native['vehicle']['num_available']!=problem['K']:errs.append('FLEET_MODEL_MISMATCH')
  if [[p['x'],p['y']]for p in native['locations']]!=problem['coordinates']:errs.append('COORDINATE_MODEL_MISMATCH')
  if standard_answer is not None:
   if not comparable_model(standard_answer['native_model_parameters'],native,problem['K']):errs.append('OTHER_MODEL_CHANGE')
   if standard_answer['default_solve_params']!=answer['default_solve_params']:errs.append('SOLVE_PARAMETER_CHANGE')
   if standard_answer['model_matrix_sha256']!=answer['model_matrix_sha256']:errs.append('MATRIX_CHANGE')
   if standard_answer['resource_limits']!=answer['resource_limits']:errs.append('RESOURCE_LIMIT_CHANGE')
  validation=validate_solution(problem,answer['routes'],answer['reported_cost']);out['route_validation']=validation
  out.update(solver_is_feasible=answer['solver_is_feasible'],solver_is_complete=answer['solver_is_complete'])
  if answer['reported_num_routes']!=validation['nonempty_routes']or any(len(r)<3 for r in answer['routes']):errs.append('ROUTE_COUNT_MISMATCH')
  if answer['reported_duration_cost']!=0 or answer['reported_fixed_vehicle_cost']!=0:errs.append('NON_DISTANCE_COST')
  if answer['reported_distance']!=answer['internal_route_cost']or validation['cost']!=answer['reported_distance']:errs.append('DISTANCE_MISMATCH')
  if answer['solver_is_feasible']:
   if not(validation['valid']and validation['reported_cost_checked']and validation['reported_cost_matches']and type(answer['reported_cost'])is int and answer['solver_is_complete']):errs.append('INVALID_FEASIBLE_CLAIM')
  elif validation['feasible']or answer['reported_cost']is not None:errs.append('INFEASIBLE_FLAG_MISMATCH')
  if not errs:
   out['valid_record']=True
   if answer['solver_is_feasible']:out.update(valid_feasible=True,status='FEASIBLE',cost=validation['cost'],vehicles=validation['nonempty_routes'])
   else:out['status']='NO_FEASIBLE_INCUMBENT_WITHIN_BUDGET'
  if schema:out['quality_trajectory_sha256']=digest(stats)
  out['constraint_violations']=validation['errors']
 except (KeyError,TypeError,ValueError,IndexError)as exc:errs.append('SCHEMA_ERROR:'+repr(exc))
 return out

def invalidate(out,errors,status=None):
 out['errors'].extend(errors)
 if errors:
  preserved=out['status']if out['status']in('MISSING_RESULT','WALL_TIMEOUT','PROCESS_FAILURE_OR_CPU_LIMIT','CALL_ERROR_UNDETERMINED')else'INVALID_OUTPUT_OR_LEDGER'
  out.update(valid_record=False,valid_feasible=False,cost=None,vehicles=None,status=status or preserved)
 return out

def audit_call(problem,entry,item,answer,standard_answer=None):
 out=audit_saved_answer(problem,entry,answer,standard_answer);errs=[];status=None
 if not isinstance(item,dict):return invalidate(out,['MISSING_RESULT'],'MISSING_RESULT')
 if item.get('status')in('WALL_TIMEOUT','PROCESS_FAILURE_OR_CPU_LIMIT','CALL_ERROR_UNDETERMINED'):status=item['status']
 if item.get('schedule')!=entry or item.get('call_id')!=entry['call_id']:errs.append('SCHEDULE_MISMATCH')
 if item.get('returncode')!=0 or not item.get('process_spawned')or not item.get('child_reaped'):errs.append('PROCESS_FAILURE')
 if item.get('status')not in('UNREVIEWED_PROCESS_SUCCESS','UNREVIEWED_INFEASIBLE'):errs.append('PROCESS_STATUS_FAILURE')
 if item.get('payload_sha256')!=hash_payload(problem,entry):errs.append('PAYLOAD_HASH_MISMATCH')
 if isinstance(answer,dict)and type(answer.get('solver_is_feasible'))is bool and item.get('status')in('UNREVIEWED_PROCESS_SUCCESS','UNREVIEWED_INFEASIBLE'):
  expected='UNREVIEWED_PROCESS_SUCCESS'if answer['solver_is_feasible']else'UNREVIEWED_INFEASIBLE'
  if item['status']!=expected:errs.append('STATUS_FLAG_MISMATCH')
 out['process_status']=item.get('status');return invalidate(out,errs,status)

def prefix_observation(old,new,old_audit,new_audit):
 result={'instance_id':old_audit['instance_id'],'seed':old_audit['seed'],'arm':old_audit['arm'],'status':'UNAVAILABLE','equal':None,'first_difference':None,'fields':list(COST_FIELDS+BOOL_FIELDS),'time_excluded':True,'historical_feasible':old_audit['valid_feasible'],'new_feasible':new_audit['valid_feasible']}
 if not old_audit['valid_record']or not new_audit['valid_record']:return result
 identity=all(old[k]==new[k]for k in ('seed','native_model_parameters','default_solve_params','model_matrix_sha256','resource_limits','solver','version','algorithm'))
 result['same_input_seed_model_solver_identity']=identity
 if not identity:result['status']='IDENTITY_MISMATCH';return result
 a=old['stats'];b=new['stats'][:25]
 if len(a)!=25 or len(b)!=25:return result
 result.update(equal=a==b,status='SAME'if a==b else'DIFFERENT',old25_sha256=digest(a),new250_prefix25_sha256=digest(b))
 for i,(x,y)in enumerate(zip(a,b),1):
  if x!=y:result['first_difference']={'iteration':i,'fields':{k:{'old25':x[k],'new250':y[k]}for k in COST_FIELDS+BOOL_FIELDS if x[k]!=y[k]}};break
 return result

def paired_record(standard,capped):
 good=standard['valid_feasible']and capped['valid_feasible']
 return {'valid_pair':good,'delta_cost':capped['cost']-standard['cost']if good else None,'relative_delta_pct':100*(capped['cost']-standard['cost'])/standard['cost']if good else None,'delta_vehicles':capped['vehicles']-standard['vehicles']if good else None}
def four_cell_record(iid,seed,cells):
 p25=paired_record(cells['standard25'],cells['capped25']);p250=paired_record(cells['standard250'],cells['capped250']);good=p25['valid_pair']and p250['valid_pair']
 return {'instance_id':iid,'seed':seed,'cells':cells,'paired25':p25,'paired250':p250,'valid_all_four':good,'interaction_delta_cost':p250['delta_cost']-p25['delta_cost']if good else None,'interaction_relative_pp':p250['relative_delta_pct']-p25['relative_delta_pct']if good else None,'interaction_delta_vehicles':p250['delta_vehicles']-p25['delta_vehicles']if good else None,'budget_effects':{arm:cells[arm+'250']['cost']-cells[arm+'25']['cost']if cells[arm+'250']['valid_feasible']and cells[arm+'25']['valid_feasible']else None for arm in ('standard','capped')}}
def metric(values,denominator,conditional):
 good=[v for v in values if v is not None];complete=len(good)==denominator
 usable=bool(good)and(conditional or complete)
 return {'mean':statistics.mean(good)if usable else None,'median':statistics.median(good)if usable else None,'n':len(good),'planned_denominator':denominator,'complete':complete,'conditional':conditional}
def summarize(rows):
 n=len(rows);cellnames=('standard25','capped25','standard250','capped250');overall={'planned_pairs':n,'planned_cells':4*n,'feasibility':{},'complete_primary':{},'conditional_common_success':{}}
 for key in cellnames:
  cells=[r['cells'][key]for r in rows];statuses={s:sum(c['status']==s for c in cells)for s in sorted({c['status']for c in cells})}
  overall['feasibility'][key]={'feasible':sum(c['valid_feasible']for c in cells),'planned_denominator':n,'statuses':statuses}
  overall['complete_primary'][key+'_cost']=metric([c['cost']if c['valid_feasible']else None for c in cells],n,False)
 for budget in (25,250):
  key='paired'+str(budget)
  for name in ('delta_cost','relative_delta_pct','delta_vehicles'):
   values=[r[key][name]for r in rows];overall['complete_primary'][key+'_'+name]=metric(values,n,False);overall['conditional_common_success'][key+'_'+name]=metric(values,n,True)
  overall['conditional_common_success'][key+'_directions']={label:sum(r[key]['valid_pair']and pred(r[key]['delta_cost'])for r in rows)for label,pred in [('capped_lower',lambda x:x<0),('equal',lambda x:x==0),('capped_higher',lambda x:x>0)]}
 common=[r for r in rows if r['valid_all_four']];overall['all_four_common_success_count']=len(common)
 for name in ('interaction_delta_cost','interaction_relative_pp','interaction_delta_vehicles'):
  values=[r[name]for r in rows];overall['complete_primary'][name]=metric(values,n,False);overall['conditional_common_success'][name]=metric(values,n,True)
 overall['conditional_common_success']['same_all_four_subset']={'n':len(common),'planned_denominator':n,**{key+'_'+name:metric([r[key][name]for r in common]+[None]*(n-len(common)),n,True)for key in('paired25','paired250')for name in('delta_cost','relative_delta_pct','delta_vehicles')}}
 for arm in ('standard','capped'):
  values=[r['budget_effects'][arm]for r in rows];overall['complete_primary'][arm+'_budget_effect']=metric(values,n,False);overall['conditional_common_success'][arm+'_budget_effect']=metric(values,n,True)
  transitions={}
  for r in rows:
   t=r['cells'][arm+'25']['status']+' -> '+r['cells'][arm+'250']['status'];transitions[t]=transitions.get(t,0)+1
  overall.setdefault('status_transitions',{})[arm]={'planned_denominator':n,'counts':transitions}
 return overall
