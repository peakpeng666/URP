import json, sys, warnings
import worker
from pyvrp import solve, SolveParams
from pyvrp.stop import MaxIterations
from pyvrp.PenaltyManager import PenaltyParams
from pyvrp.IteratedLocalSearch import IteratedLocalSearchParams
from pyvrp.exceptions import PenaltyBoundWarning
from observer import ReadonlyPenaltyObserver
source = "/workspace/shared/public_route_strong_baseline_20261009_venv/lib/python3.12/site-packages/pyvrp/PenaltyManager.py"
events = []
def audit(event, args):
    if event == "open" or event.startswith(("socket.", "subprocess.", "os.system", "os.exec", "os.spawn")):
        events.append({"event": event, "args": list(args)})
        raise PermissionError("Source read denied by existing worker rule")
sys.addaudithook(audit)
warnings.warn_explicit("Zero-solver diagnostic of default warning formatting", PenaltyBoundWarning, source, 228)
print(json.dumps({"scope": "Default warnings formatting only; same imports as worker; no model or Solution construction or solver call", "observed_blocked_events": events}))
