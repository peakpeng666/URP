"""Bounded saved report comparison, never calls the optimizer or result collector."""
from audit_saved_penalty import ROOT,load,sha,gate,equal,require,save_exclusive
import resource,signal,datetime,json

def main():
    resource.setrlimit(resource.RLIMIT_CPU,(15,15));resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912));signal.alarm(60)
    receipt=gate();audit=load(ROOT/'independent_supervision/results/SAVED_PENALTY_AUDIT.json');summary=load(ROOT/'reports/SUMMARY.json')
    require(audit['status']=='SAVED_EVIDENCE_AUDITED','saved audit completed')
    require(audit['raw_archive_sha256']==summary['raw_archive_sha256']==receipt['sha256'],'raw binding')
    require(audit['frozen_files_sha256']==summary['frozen_files_sha256']==receipt['frozen_files_sha256'],'freeze binding')
    require(summary['new_planned_calls']==72 and summary['historical_reference_cells']==36 and summary['historical_cells_in_primary']==0,'denominators')
    equal(audit['overall'],summary['overall'],'overall');equal(audit['per_instance'],load(ROOT/'reports/PER_INSTANCE.json'),'per instance')
    rows=load(ROOT/'reports/PAIRED_RESULTS.json');require(len(rows)==36,'all36 pairs')
    for a,b in zip(audit['rows'],rows):
        equal({k:a[k] for k in ('instance_id','seed','common_success','delta_cost','relative_delta_pct','delta_vehicles')},b,'pair')
        for arm in ('p500','p50'):equal({k:a['cells'][arm][k] for k in ('status','valid_record','valid_feasible','cost','vehicles')},b['cells'][arm],'cell')
    equal(audit['diagnostics'],load(ROOT/'reports/DIAGNOSTICS.json'),'diagnostics')
    text=(ROOT/'reports/REPORT_ZH.txt').read_text()
    for term in ('36','250','500','50','共同成功','第250','callback','唯一原因','10','CPU'):require(term in text,'report qualification '+term)
    out={'status':'PASS_CANDIDATE_FOR_PRIMARY_SUPERVISOR_SIGNATURE','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'raw_archive_sha256':receipt['sha256'],'frozen_files_sha256':receipt['frozen_files_sha256'],'report_sha256':sha(ROOT/'reports/REPORT_ZH.txt'),
         'summary_sha256':sha(ROOT/'reports/SUMMARY.json'),'independent_audit_sha256':sha(ROOT/'independent_supervision/results/SAVED_PENALTY_AUDIT.json'),
         'optimizer_calls':0,'checked_fresh_cells':72,'checked_pairs':36,'checked_diagnostics':72,'method':'Saved independent evidence comparison plus bounded required qualification checks; final human-readable report inspection remains primary supervisor responsibility.'}
    save_exclusive(ROOT/'independent_supervision/results/FINAL_REPORT_CANDIDATE.json',out);print(json.dumps(out))
if __name__=='__main__':main()
