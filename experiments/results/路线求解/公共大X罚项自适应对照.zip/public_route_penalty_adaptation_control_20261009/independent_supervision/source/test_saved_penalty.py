"""Saved toy replay only, zero native/solver calls."""
from audit_saved_penalty import *
from saved_answer import answer_check
import ast

def main():
    cases=[]
    plan=load(ROOT/'selftests/integration/PLANNED.json');fixtures={p['instance_id']:p for p in plan['fixtures']}
    # Original8 stage keeps its two denied-IO outcomes; only successful records
    # validate base native outputs under the parameter snapshot actually used.
    items,_=lines(ROOT/'selftests/integration/results.jsonl')
    for item in items:
        a=load(ROOT/item['stdout']);e=item['schedule'];p=fixtures[e['instance_id']]
        if not a['denied_io_events']:
            answer_check(p,a,e['seed'],250,expected_params=a['default_solve_params'])
            if e['observe_penalties']:trace_check(a,e['solutions_between_updates'])
            cases.append('original_saved_native_'+e['call_id'])
    recheck=load(ROOT/'selftests/warning_recheck/PLANNED.json');p=recheck['fixture']
    records,_=lines(ROOT/'selftests/warning_recheck/results.jsonl')
    item=next(r for r in records if r['schedule']['observe_penalties']);e=item['schedule'];a=load(ROOT/item['stdout'])
    mh=hashlib.sha256(compact([[edge(x,y) for y in p['coordinates']] for x in p['coordinates']])).hexdigest()
    checked,answer=inspect(p,e,item,[],mh,a,ROOT/'selftests/warning_recheck/calls')
    require(checked['valid_record'] and not checked['valid_feasible'] and checked['status']=='NO_FEASIBLE_INCUMBENT_WITHIN_BUDGET','formal-contract saved recheck')
    cases.append('current_full_saved_contract_warning_recheck')
    for label in ('probe','wrong_iteration','unexpected_update'):
        bad=copy.deepcopy(a)
        if label=='probe':bad['penalty_observation']['rows'][0]['observed_search_evaluator_integer_probes'][0]['load']+=1
        elif label=='wrong_iteration':bad['penalty_observation']['rows'][0]['iteration']=2
        else:bad['penalty_observation']['rows'][0]['observed_post_registration_penalties'][0][0]=90000
        try:trace_check(bad,50)
        except ValueError:cases.append('reject_'+label)
        else:raise AssertionError(label)
    good={'status':'FEASIBLE','valid_record':True,'valid_feasible':True,'cost':10,'vehicles':2}
    failure={'status':'NO_FEASIBLE_INCUMBENT_WITHIN_BUDGET','valid_record':True,'valid_feasible':False,'cost':None,'vehicles':None}
    rows=[paired('fixture',i,good,good) for i in range(36)]
    rows[0]=paired('fixture',0,good,failure);m=summarize(rows)
    require(m['feasibility']['p500']['feasible']==36 and m['feasibility']['p50']['feasible']==35,'denominators')
    require(m['complete_primary']['delta_cost']['mean'] is None and m['conditional_common_success']['delta_cost']['n']==35,'missing complete cost')
    require(m['paired_success_transitions']['success_failure']==1,'paired transition')
    cases.append('36_pairs72_cells_failure_retained')
    b=copy.deepcopy(a);b['stats'][0]['current_cost']+=1
    require(diagnostic(a,b,50,'fresh500_vs_fresh50_first50','fixture',0)['status']=='DIFFERENT','observation not rerun gate')
    cases.append('diagnostic_difference_retained')
    schedule=plan['schedule'];events,_=lines(ROOT/'selftests/integration/attempts.jsonl');ledger,_=check_ledger(schedule,events,items)
    require(ledger['status']=='PASS' and ledger['planned_denominator']==8,'original8 ledger including guard failures')
    cases.append('original8_ledger_2guard_failures_not_deleted')
    for path in (ROOT/'independent_supervision/source').glob('*.py'):ast.parse(path.read_text())
    out={'status':'PASS','checks':cases,'optimizer_calls':0,'native_calls':0,'scope':'Saved invented outputs and pure endpoints; original stage failure retained; no fresh problem optimization','source_hashes':{p.name:sha(p) for p in (ROOT/'independent_supervision/source').glob('*.py')}}
    save_exclusive(ROOT/'independent_supervision/selftests/SAVED_OUTPUT_CHECKS.json',out);print(json.dumps({'status':'PASS','checks':len(cases)}))
if __name__=='__main__':main()
