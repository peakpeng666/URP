"""Independent saved-answer validator. Original integer arithmetic; no optimizer or author endpoint imports."""
from original_primitives import *
def compact(x):return json.dumps(x,separators=(',',':')).encode()
def expected_native(p):
    n=len(p['coordinates']);u=2**63-1
    v={'capacity':[p['capacity']],'num_available':p['K'],'start_depot':0,'end_depot':0,'fixed_cost':0,'unit_distance_cost':1,'unit_duration_cost':0,'unit_overtime_cost':0,'initial_load':[0],'reload_depots':[],'max_reloads':0,'max_trips':1,'max_overtime':0,'max_distance':u,'max_duration':u,'shift_duration':u,'start_late':u,'tw_early':0,'tw_late':u,'profile':0}
    c=[{'location':i,'delivery':[p['demands'][i]],'pickup':[0],'service_duration':0,'prize':0,'required':True,'release_time':0,'tw_early':0,'tw_late':u,'group':None}for i in range(1,n)]
    return {'locations':[{'x':q[0],'y':q[1]}for q in p['coordinates']],'num_vehicle_types':1,'num_profiles':1,'num_groups':0,'vehicle':v,'clients':c,'depot':{'location':0,'service_duration':0,'tw_early':0,'tw_late':u},'num_locations':n,'num_clients':n-1,'num_depots':1,'num_vehicles':p['K'],'num_shipments':0,'duration_matrix_all_zero':True}

def answer_check(p,a,seed,budget,matrix_sha=None,expected_params=None):
    require((a['solver'],a['version'],a['algorithm'])==('PyVRP','0.14.0','ILS'),'solver identity')
    require(type(a['seed'])is int and a['seed']==seed and type(a['max_iterations'])is int and type(a['num_iterations'])is int and a['max_iterations']==a['num_iterations']==budget,'seed/budget')
    require(a['denied_io_events']==a['reference_or_history_payload_fields']==[],'reference/IO')
    require(a['native_model_parameters']==expected_native(p),'full native model')
    require(a['default_solve_params']==(expected_params if expected_params is not None else load(ROOT/'environment/DEFAULT_SOLVE_PARAMS.json')),'defaults')
    require(a['resource_limits']=={'inherited':{'AS_bytes':[512*1024**2,1536*1024**2],'CPU_seconds':[30,30]},'effective':{'AS_bytes':[1536*1024**2]*2,'CPU_seconds':[15,15]}},'resource limits')
    fields={'current_cost','candidate_cost','best_cost','current_feas','candidate_feas','best_feas'}
    require(len(a['stats'])==len(a['stats_runtime_per_iteration'])==budget,'stats count')
    for d in a['stats']:
        require(set(d)==fields and all(type(d[k])is(bool if k.endswith('_feas')else int)for k in fields),'stats schema')
    require(type(a['solver_is_feasible'])is bool and type(a['solver_is_complete'])is bool,'feasible schema')
    if matrix_sha is None:
        M=[[edge(x,y)for y in p['coordinates']]for x in p['coordinates']]
        matrix_sha=hashlib.sha256(compact(M)).hexdigest()
    require(a['model_matrix_sha256']==matrix_sha,'exact integer native matrix')
    v=route_check(p,a['routes'],a['reported_cost'],a['solver_is_feasible'])
    require(a['reported_num_routes']==v['vehicles'],'reported fleet')
    require(a['reported_distance']==a['internal_route_cost']==v['cost'],'distance identity')
    require(a['reported_duration_cost']==a['reported_fixed_vehicle_cost']==0,'other cost')
    require(a['solver_is_complete']==('COVERAGE'not in v['feasibility_errors']),'complete flag')
    require(a['solver_is_feasible']==(not v['feasibility_errors']),'feasibility claim')
    if not a['solver_is_feasible']:require(a['reported_cost']is None,'infeasible objective must be null')
    require(len(a['native_routes'])==len(a['routes']),'native route length')
    for r,n,l in zip(a['routes'],a['native_routes'],v['loads']):
        require(n['distance']==sum(edge(p['coordinates'][x],p['coordinates'][y])for x,y in zip(r,r[1:])) and n['delivery']==[l],'native distance/load')
        require(n['is_feasible']==(l<=p['capacity']) and n['num_trips']==1 and n['vehicle_type']==n['start_depot']==n['end_depot']==0,'native feasibility/type')
        require(len(n['activities'])==len(r),'activities count')
        for j,(node,b)in enumerate(zip(r,n['activities'])):
            depot=j in (0,len(r)-1)
            require(b=={'type':'DEPOT'if depot else'CLIENT','idx':0 if depot else node-1,'location':node,'node':node},'native node mapping')
    return {'status':'FEASIBLE'if a['solver_is_feasible']else'NO_FEASIBLE_INCUMBENT_WITHIN_BUDGET','valid_feasible':a['solver_is_feasible'],'cost':v['cost']if a['solver_is_feasible']else None,'vehicles':v['vehicles']if a['solver_is_feasible']else None,'saved_route_audit':v}

