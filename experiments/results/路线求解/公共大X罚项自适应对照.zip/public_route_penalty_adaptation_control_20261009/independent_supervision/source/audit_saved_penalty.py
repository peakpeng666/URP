"""Independent saved penalty experiment audit; no author endpoint or solver imports."""
from original_primitives import *
from saved_answer import answer_check, compact
from evidence_primitives import gate,lines,check_ledger,blank,metric,equal,digest,save_exclusive
import resource,signal,time
FIELDS=('current_cost','candidate_cost','best_cost','current_feas','candidate_feas','best_feas')
WARNING_SOURCE='/workspace/shared/public_route_strong_baseline_20261009_venv/lib/python3.12/site-packages/pyvrp/PenaltyManager.py'
WARNING_SHA='2f691640bb5a785920df1077653d2bf406bc0350594913f9fe8378c127a3e6d1'

def trace_check(answer,interval):
    obs=answer['penalty_observation'];require(obs['schema']=='public_penalty_observer_v1' and obs['probe_values']==[1,1000],'observer schema')
    mid=0.1+(100000-0.1)/2
    initial=[[mid],mid,mid];require(obs['initial_penalties']==initial and type(obs['initial_solution_feasible']) is bool,'observer initial')
    require(len(obs['rows'])==250,'250 penalty observations')
    previous=initial;changes=[]
    for i,row in enumerate(obs['rows'],1):
        require(row['iteration']==i and row['expected_search_penalties_source_derived']==previous,'source-order expected snapshot')
        post=row['observed_post_registration_penalties']
        require(isinstance(post,list) and len(post)==3 and isinstance(post[0],list) and len(post[0])==1,'one load dimension')
        values=[*post[0],*post[1:]]
        require(all(type(v) in (int,float) and math.isfinite(v) and 0.1<=v<=100000 for v in values),'penalty bounds')
        probes=[{'violation':v,'load':int(v*previous[0][0]),'duration':int(v*previous[1]),'distance':int(v*previous[2])}for v in (1,1000)]
        require(row['observed_search_evaluator_integer_probes']==probes,'public integer evaluator probes')
        if post!=previous:require(i%interval==0,'unscheduled change');changes.append(i)
        previous=post
    return {'scheduled_update_checks':list(range(interval,251,interval)), 'observed_numeric_change_iterations':changes,
            'observed_initial_penalties':initial,'observed_final_post_registration_penalties':previous,
            'observation_sha256':digest(obs),'valid':True}

def inspect(p,e,item,ledger_errors,matrix_hash,original,output_base=None):
    status='MISSING_RESULT' if item is None else item.get('status') if item.get('status') in ('WALL_TIMEOUT','PROCESS_FAILURE_OR_CPU_LIMIT','CALL_ERROR_UNDETERMINED') else 'INVALID_OUTPUT'
    out=blank(status);answer=None
    try:
        require(item is not None,'missing result')
        require(item.get('schedule')==e and item.get('call_id')==e['call_id'],'entry identity')
        payload={k:p[k] for k in ('coordinates','demands','capacity','K')};payload.update(seed=e['seed'],max_iterations=250,solutions_between_updates=e['solutions_between_updates'],observe_penalties=True)
        require(item['payload_sha256']==hashlib.sha256(compact(payload)).hexdigest(),'payload bytes')
        for label in ('stdout','stderr'):
            path=(ROOT/item[label]).resolve();expected=((output_base or ROOT/'raw/calls')/(e['call_id']+'.'+label)).resolve()
            require(path==expected and sha(path)==item[label+'_sha256'],'saved path/hash '+label)
        # Preserve diagnostic output even if the call has a process/guard failure.
        answer=load(ROOT/item['stdout'])
        require(not ledger_errors,'ledger errors '+repr(ledger_errors))
        require(item.get('process_spawned') is True and item.get('child_reaped') is True and item.get('returncode')==0,'process success')
        require(item.get('status') in ('UNREVIEWED_PROCESS_SUCCESS','UNREVIEWED_INFEASIBLE'),'process status')
        params=copy.deepcopy(load(ROOT/'environment/DEFAULT_SOLVE_PARAMS.json'))
        params['values']['penalty']['values']['solutions_between_updates']=e['solutions_between_updates']
        params['values']['ils']['values']['callbacks']={'type':'observer.ReadonlyPenaltyObserver','values':{}}
        validated=answer_check(p,answer,e['seed'],250,matrix_hash,params)
        require(answer['solutions_between_updates']==e['solutions_between_updates'] and answer['observe_penalties'] is True,'interval and symmetric observer')
        require(answer['warning_source_verification']=={'path':WARNING_SOURCE,'sha256':WARNING_SHA,'verified_before_search':True,'default_warning_behavior_preserved':True},'source-read verification')
        expected_read={'event':'open','path':WARNING_SOURCE,'mode':'r','flags':524288,'verified_source_sha256':WARNING_SHA}
        require(isinstance(answer['allowed_warning_source_reads'],list) and all(x==expected_read for x in answer['allowed_warning_source_reads']),'exact warning-source read whitelist')
        for key in ('native_model_parameters','model_matrix_sha256','seed'):require(answer[key]==original[key],'historical model identity '+key)
        trace=trace_check(answer,e['solutions_between_updates'])
        require(item['status']==('UNREVIEWED_PROCESS_SUCCESS' if validated['valid_feasible'] else 'UNREVIEWED_INFEASIBLE'),'native/record outcome')
        out.update(validated,valid_record=True,penalty_trace_audit=trace)
    except (KeyError,TypeError,ValueError,AssertionError,OSError,IndexError) as ex:
        out.update(valid_record=False,valid_feasible=False,cost=None,vehicles=None);out['errors'].append(str(ex))
    return out,answer

def paired(iid,seed,c,t):
    good=c['valid_feasible'] and t['valid_feasible'];delta=t['cost']-c['cost'] if good else None
    return {'instance_id':iid,'seed':seed,'cells':{'p500':c,'p50':t},'common_success':good,
            'delta_cost':delta,'relative_delta_pct':100*delta/c['cost'] if good else None,
            'delta_vehicles':t['vehicles']-c['vehicles'] if good else None}

def summarize(rows):
    n=len(rows);out={'planned_pairs':n,'planned_cells':2*n,'feasibility':{},'complete_primary':{},'conditional_common_success':{}}
    for arm in ('p500','p50'):
        cells=[r['cells'][arm] for r in rows];feasible=sum(c['valid_feasible'] for c in cells)
        out['feasibility'][arm]={'feasible':feasible,'planned_denominator':n,'fraction':feasible/n if n else None,'statuses':dict(Counter(c['status'] for c in cells))}
        out['complete_primary'][arm+'_cost']=metric([c['cost'] if c['valid_feasible'] else None for c in cells],n,False)
    out['descriptive_paired_risk_difference']=(out['feasibility']['p50']['feasible']-out['feasibility']['p500']['feasible'])/n if n else None
    transitions={key:0 for key in ('success_success','success_failure','failure_success','failure_failure')};detailed=Counter()
    for r in rows:
        a,b=r['cells']['p500'],r['cells']['p50'];key=('success' if a['valid_feasible'] else 'failure')+'_'+('success' if b['valid_feasible'] else 'failure');transitions[key]+=1;detailed[a['status']+' -> '+b['status']]+=1
    out.update(paired_success_transitions=transitions,paired_detailed_status_transitions=dict(detailed),common_success_count=sum(r['common_success'] for r in rows))
    for key in ('delta_cost','relative_delta_pct','delta_vehicles'):
        values=[r[key] for r in rows];out['complete_primary'][key]=metric(values,n,False);out['conditional_common_success'][key]=metric(values,n,True)
    return out

def diagnostic(a,b,n,label,iid,seed):
    out={'label':label,'instance_id':iid,'seed':seed,'status':'UNAVAILABLE','first_difference':None}
    if isinstance(a,dict) and isinstance(b,dict):
        try:
            x,y=a['stats'][:n],b['stats'][:n]
            if len(x)==len(y)==n:
                out['status']='SAME' if x==y else 'DIFFERENT'
                for i,(u,v) in enumerate(zip(x,y),1):
                    if u!=v:
                        out['first_difference']={'iteration':i,'fields':{k:{'left':u[k],'right':v[k]} for k in FIELDS if u[k]!=v[k]}};break
        except (KeyError,TypeError,IndexError):pass
    if label.startswith('historical'):
        fields=('routes','reported_cost','reported_distance','solver_is_feasible','solver_is_complete','native_model_parameters','model_matrix_sha256')
        out['returned_solution_and_model_fields_equal']=all(a.get(k)==b.get(k) for k in fields) if isinstance(a,dict) and isinstance(b,dict) else None
    return out

def collect():
    schedule=load(ROOT/'freeze/SCHEDULE.json');tasks=load(ROOT/'freeze/TASKS.json');history=load(ROOT/'freeze/HISTORICAL_CELLS.json')['all36']
    require(len(schedule)==72 and len(tasks)==12 and len(history)==36,'fixed panel size')
    items,ie=lines(ROOT/'raw/results.jsonl');events,ee=lines(ROOT/'raw/attempts.jsonl');ledger,byid=check_ledger(schedule,events,items,ie+ee)
    error_by_id={r['call_id']:r['errors']+ledger['errors'] for r in ledger['calls']}
    inputs={};matrices={};originals={}
    for t in tasks:
        iid=t['instance_id'];p=vrp(ROOT/'input'/(iid+'.vrp'));rr,cost=sol(ROOT/'references'/(iid+'.sol'))
        require(len(rr)==t['K_ref'],'actual SOL K_ref');route_check({**p,'K':t['K_ref']},rr,cost)
        require(p==load(ROOT/'input'/(iid+'.json')),'original standard payload');inputs[iid]=p
        matrices[iid]=hashlib.sha256(compact([[edge(a,b) for b in p['coordinates']] for a in p['coordinates']])).hexdigest()
    old=load(ROOT/'provenance/OLD_CONTROL_FINAL_DRIVE_RECEIPT.json')
    require(sha(old['download_path'])==old['sha256']==old['download_sha256'],'actual historical downloaded final')
    with zipfile.ZipFile(old['download_path']) as z:
        prefix='public_route_fleet_budget_interaction_20261009/'
        for h in history:
            raw=(ROOT/h['output_file']).read_bytes();require(hashlib.sha256(raw).hexdigest()==h['stdout_sha256'],'historical stdout hash')
            require(raw==z.read(prefix+'raw/calls/'+h['call_id']+'.stdout'),'historical archived stdout')
            originals[h['instance_id'],h['seed']]=json.loads(raw)
    answers={};audits={}
    for e in schedule:
        iid,seed,interval=e['instance_id'],e['seed'],e['solutions_between_updates'];p={**inputs[iid],'K':e['K']}
        require(e['K']==next(t['K_ref'] for t in tasks if t['instance_id']==iid),'scheduled K_ref')
        audits[iid,seed,interval],answers[iid,seed,interval]=inspect(p,e,byid.get(e['call_id']),error_by_id[e['call_id']],matrices[iid],originals[iid,seed])
    rows=[];diagnostics=[]
    for t in tasks:
        iid=t['instance_id']
        for seed in range(3):
            rows.append(paired(iid,seed,audits[iid,seed,500],audits[iid,seed,50]))
            diagnostics.append(diagnostic(answers[iid,seed,500],answers[iid,seed,50],50,'fresh500_vs_fresh50_first50',iid,seed))
            diagnostics.append(diagnostic(originals[iid,seed],answers[iid,seed,500],250,'historical500_vs_fresh500_all250',iid,seed))
    per_instance=[{'instance_id':t['instance_id'],'K_ref':t['K_ref'],**summarize([r for r in rows if r['instance_id']==t['instance_id']])} for t in tasks]
    return {'rows':rows,'overall':summarize(rows),'per_instance':per_instance,'diagnostics':diagnostics,'ledger':ledger,'observed_records':len(items)}

def main():
    assert __debug__;resource.setrlimit(resource.RLIMIT_CPU,(60,60));resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912));signal.alarm(120)
    start=time.monotonic();r=gate();dest=ROOT/'independent_supervision/results';dest.mkdir(exist_ok=True)
    save_exclusive(dest/'SAVED_AUDIT_STARTED.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'optimizer_calls':0})
    out=collect();u=resource.getrusage(resource.RUSAGE_SELF)
    out.update(status='SAVED_EVIDENCE_AUDITED',planned_calls=72,historical_cells_in_primary=0,raw_archive_sha256=r['sha256'],frozen_files_sha256=r['frozen_files_sha256'],optimizer_calls_by_reviewer=0,native_calls_by_reviewer=0,cpu_seconds=u.ru_utime+u.ru_stime,wall_seconds=time.monotonic()-start,peak_rss_kib=u.ru_maxrss)
    save_exclusive(dest/'SAVED_PENALTY_AUDIT.json',out);print(json.dumps({'status':out['status'],'overall':out['overall']}))
if __name__=='__main__':main()
