"""Independent fleet-budget original-byte primitives: original bytes and saved evidence only. No solver imports/calls."""
from pathlib import Path
from collections import Counter
import ast, copy, datetime, hashlib, json, math, re, sys, zipfile
ROOT = Path(__file__).resolve().parents[2]
OLD = ROOT.parent / 'public_route_fixed_iterations_repro_20261009'
def load(p): return json.loads(Path(p).read_text())
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def require(x, why):
    if not x: raise ValueError(why)
def edge(a,b):
    s=sum((x-y)**2 for x,y in zip(a,b)); q=math.isqrt(s)
    return q + int(4*s >= (2*q+1)**2)
def vrp(path):
    h={}; xy={}; demands={}; depot=[]; section=None
    for raw in Path(path).read_text().splitlines():
        line=raw.strip()
        if not line: continue
        if line=='EOF': break
        if line in ('NODE_COORD_SECTION','DEMAND_SECTION','DEPOT_SECTION'): section=line; continue
        if section is None:
            k,v=line.split(':',1); require(k.strip() not in h,'duplicate header'); h[k.strip()]=v.strip()
        elif section=='NODE_COORD_SECTION':
            i,x,y=map(int,line.split());require(i not in xy,'duplicate coordinate');xy[i]=[x,y]
        elif section=='DEMAND_SECTION':
            i,d=map(int,line.split());require(i not in demands,'duplicate demand');demands[i]=d
        else: depot.extend(map(int,line.split()))
    n=int(h['DIMENSION']); q=int(h['CAPACITY'])
    require(h['TYPE']=='CVRP' and h['EDGE_WEIGHT_TYPE']=='EUC_2D','CVRP EUC_2D')
    require(sorted(xy)==sorted(demands)==list(range(1,n+1)),'identities')
    require(depot==[1,-1] and demands[1]==0 and q>0,'depot/capacity')
    require(all(0<=d<=q for d in demands.values()),'demands bounds')
    return {'instance_id':h['NAME'],'coordinates':[xy[i] for i in range(1,n+1)],'demands':[demands[i] for i in range(1,n+1)],'capacity':q,'K':n-1}
def sol(path):
    routes=[]; cost=None
    for raw in Path(path).read_text().splitlines():
        line=raw.strip()
        if not line: continue
        m=re.fullmatch(r'Route #(\d+):\s*(.*)',line)
        if m:
            require(int(m[1])==len(routes)+1,'SOL route numbering')
            body=list(map(int,m[2].split())); require(body,'SOL empty route'); routes.append([0,*body,0])
        else:
            m=re.fullmatch(r'Cost\s+(\d+)',line);require(m and cost is None,'SOL cost syntax');cost=int(m[1])
    require(routes and cost is not None,'SOL required content');return routes,cost
def route_check(p,routes,reported,feasible=True):
    served=[];cost=0;loads=[];errors=[];n=len(p['coordinates'])
    require(isinstance(routes,list),'route list')
    for r in routes:
        require(isinstance(r,list) and len(r)>=3 and all(type(v)is int and 0<=v<n for v in r),'route node schema')
        require(r[0]==r[-1]==0 and 0 not in r[1:-1],'closed route')
        served.extend(r[1:-1]); loads.append(sum(p['demands'][i] for i in r[1:-1]))
        cost+=sum(edge(p['coordinates'][a],p['coordinates'][b]) for a,b in zip(r,r[1:]))
    if Counter(served)!=Counter(range(1,n)):errors.append('COVERAGE')
    if any(v>p['capacity'] for v in loads):errors.append('CAPACITY')
    if len(routes)>p['K']:errors.append('FLEET')
    if feasible:require(not errors and type(reported)is int and reported==cost,'feasible route/cost violation '+str(errors))
    return {'cost':cost,'vehicles':len(routes),'loads':loads,'feasibility_errors':errors}
def funcs(path):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(Path(path).read_text()).body if isinstance(n,ast.FunctionDef)}
