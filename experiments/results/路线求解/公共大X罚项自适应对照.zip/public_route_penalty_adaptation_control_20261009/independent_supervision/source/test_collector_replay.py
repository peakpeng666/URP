"""Independent full-collector comparison on explicitly invented saved fixtures; no solver."""
import pathlib,sys,json,shutil,zipfile,hashlib,importlib.util
ROOT=pathlib.Path(__file__).resolve().parents[2];FIX=ROOT/'independent_supervision/selftests/collector_r1'
shutil.copytree(ROOT/'selftests/full_schema_replay',FIX)
(FIX/'references').mkdir();(FIX/'provenance').mkdir()
def load(p):return json.loads(p.read_text())
def save(p,x):p.write_text(json.dumps(x))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
tasks=load(FIX/'freeze/TASKS.json');hist=load(FIX/'freeze/HISTORICAL_CELLS.json')['all36']
for task in tasks:
    iid=task['instance_id'];p=load(FIX/'input'/(iid+'.json'));p['K']=len(p['coordinates'])-1;save(FIX/'input'/(iid+'.json'),p)
    lines=[f'NAME : {iid}','TYPE : CVRP','DIMENSION : 5','EDGE_WEIGHT_TYPE : EUC_2D','CAPACITY : 2','NODE_COORD_SECTION']
    lines += [f'{i+1} {x} {y}' for i,(x,y) in enumerate(p['coordinates'])]+['DEMAND_SECTION']+[f'{i+1} {d}' for i,d in enumerate(p['demands'])]+['DEPOT_SECTION','1','-1','EOF']
    (FIX/'input'/(iid+'.vrp')).write_text('\n'.join(lines)+'\n')
    a=load(FIX/next(h['output_file'] for h in hist if h['instance_id']==iid))
    lines=[f'Route #{i+1}: '+ ' '.join(map(str,r[1:-1])) for i,r in enumerate(a['routes'])]+['Cost '+str(a['reported_cost'])]
    (FIX/'references'/(iid+'.sol')).write_text('\n'.join(lines)+'\n')
archive=FIX/'SYNTHETIC_OLD_FINAL.zip'
with zipfile.ZipFile(archive,'w') as z:
    for h in hist:
        h['call_id']=h['instance_id']+'_s'+str(h['seed'])
        z.write(FIX/h['output_file'],'public_route_fleet_budget_interaction_20261009/raw/calls/'+h['call_id']+'.stdout')
save(FIX/'freeze/HISTORICAL_CELLS.json',{'all36':hist})
save(FIX/'provenance/OLD_CONTROL_FINAL_DRIVE_RECEIPT.json',{'synthetic_only':True,'download_path':str(archive),'sha256':sha(archive),'download_sha256':sha(archive)})
records=[json.loads(l) for l in (FIX/'raw/results.jsonl').read_text().splitlines()]
for r in records:
    original=FIX/r['stdout'];out=FIX/'raw/calls'/(r['call_id']+'.stdout');out.write_bytes(original.read_bytes());err=out.with_suffix('.stderr');err.write_text('')
    r.update(stdout=str(out.relative_to(FIX)),stderr=str(err.relative_to(FIX)),stdout_sha256=sha(out),stderr_sha256=sha(err))
def ledger(rs):
    events=[]
    for r in rs:
        common={'utc':'INVENTED_SCHEMA_NOT_AN_EXECUTION','call_id':r['call_id'],'schedule':r['schedule']}
        events.extend([{'event_kind':'STARTED',**common},{'event_kind':'FINISHED',**common,'result':r}])
    (FIX/'raw/results.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in rs));(FIX/'raw/attempts.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in events))
ledger(records)
import audit_saved_penalty as independent,original_primitives,saved_answer
independent.ROOT=original_primitives.ROOT=saved_answer.ROOT=FIX
sys.path.insert(0,str(ROOT/'source'))
spec=importlib.util.spec_from_file_location('author_saved_collector',ROOT/'source/report.py');author=importlib.util.module_from_spec(spec);spec.loader.exec_module(author);author.ROOT=FIX;author.read=lambda rel:load(FIX/rel)
results=[]
for label,rs in [('full72',records),('missing_last',records[:-1])]:
    ledger(rs);ours=independent.collect();theirs=author.collect_saved_evidence()
    independent.equal(ours['overall'],theirs['overall'],'overall');independent.equal(ours['per_instance'],theirs['per_instance'],'per instance')
    for a,b in zip(ours['rows'],theirs['rows']):
        independent.equal({k:a[k] for k in ('instance_id','seed','common_success','delta_cost','relative_delta_pct','delta_vehicles')},b,'pair')
        for arm in ('p500','p50'):independent.equal({k:a['cells'][arm][k] for k in ('status','valid_record','valid_feasible','cost','vehicles')},b['cells'][arm],'cell')
    for a,b in zip(ours['diagnostics'],theirs['diagnostics']):independent.equal(a,b,'diagnostic')
    assert len(ours['rows'])==36 and len(ours['diagnostics'])==72
    results.append({'case':label,'status':'PASS','feasible500':ours['overall']['feasibility']['p500']['feasible'],'feasible50':ours['overall']['feasibility']['p50']['feasible']})
(FIX/'REPORT.json').write_text(json.dumps({'status':'PASS','optimizer_calls':0,'native_calls':0,'fixture_scope':'Invented schema-only clones, no experimental results. Synthetic receipt is never passed through formal audit main gate.','checks':results},indent=2))
print(json.dumps({'status':'PASS','checks':results}))
