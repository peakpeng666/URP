Route #1: 3 4
Route #2: 1 2
Cost 8
