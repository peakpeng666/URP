"""Public-API, read-only penalty observations. No mutation of solver objects."""
from pyvrp.IteratedLocalSearch import IteratedLocalSearchCallbacks

PROBE_VALUES = (1, 1000)


def public_snapshot(manager):
    loads, duration, distance = manager.penalties()
    return [list(map(float, loads)), float(duration), float(distance)]


class ReadonlyPenaltyObserver(IteratedLocalSearchCallbacks):
    def __init__(self):
        self._manager = None
        self._initial = None
        self._previous = None
        self._initial_feasible = None
        self._rows = []

    def on_start(self, ils):
        self._manager = ils.penalty_manager
        self._initial = public_snapshot(self._manager)
        self._previous = self._initial
        self._initial_feasible = bool(ils.initial_solution.is_feasible())

    def on_iteration(self, current, candidate, best, cost_evaluator):
        # The candidate argument can differ from the object registered by ILS.
        # It is deliberately neither inspected nor used to reconstruct windows.
        post = public_snapshot(self._manager)
        probes = [
            {"violation": value,
             "load": int(cost_evaluator.load_penalty(value, 0, 0)),
             "duration": int(cost_evaluator.tw_penalty(value)),
             "distance": int(cost_evaluator.dist_penalty(value, 0))}
            for value in PROBE_VALUES
        ]
        self._rows.append({
            "iteration": len(self._rows) + 1,
            "expected_search_penalties_source_derived": self._previous,
            "observed_post_registration_penalties": post,
            "observed_search_evaluator_integer_probes": probes,
        })
        self._previous = post

    def observation(self):
        return {
            "schema": "public_penalty_observer_v1",
            "initial_penalties": self._initial,
            "initial_solution_feasible": self._initial_feasible,
            "probe_values": list(PROBE_VALUES),
            "rows": self._rows,
            "scope": "Public PM snapshots and integer evaluator probes only. Expected pre-search values use source order; registered candidates and hidden evaluator doubles are not observed.",
        }
