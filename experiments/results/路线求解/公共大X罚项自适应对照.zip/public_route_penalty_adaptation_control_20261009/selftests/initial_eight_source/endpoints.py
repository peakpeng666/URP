"""Saved-output audits and fixed-denominator endpoints. No PyVRP import."""
import copy
import hashlib
import json
import math
from collections import Counter
from legacy_audit import (audit_saved_answer, audit_ledger, invalidate,
                          metric, digest, COST_FIELDS, BOOL_FIELDS)


def payload_for(problem, entry, observe=True):
    payload = {key: problem[key] for key in ('coordinates', 'demands', 'capacity', 'K')}
    payload.update(K=entry['K'], seed=entry['seed'], max_iterations=250,
                   solutions_between_updates=entry['solutions_between_updates'],
                   observe_penalties=observe)
    return payload


def snapshot_valid(snapshot):
    return (isinstance(snapshot, list) and len(snapshot) == 3
            and isinstance(snapshot[0], list) and len(snapshot[0]) == 1
            and all(type(v) in (int, float) and math.isfinite(v)
                    and 0.1 <= v <= 100000 for v in [*snapshot[0], *snapshot[1:]]))


def audit_observation(answer, interval):
    errors = []
    result = {'errors': errors, 'scheduled_update_checks': [],
              'observed_numeric_change_iterations': [],
              'search_affected_checkpoints_source_derived': [51, 101, 151, 201] if interval == 50 else [],
              'last_iteration_update_cannot_affect_search': True}
    try:
        obs = answer['penalty_observation']
        if obs['schema'] != 'public_penalty_observer_v1' or obs['probe_values'] != [1, 1000]:
            errors.append('OBSERVER_SCHEMA')
        initial = obs['initial_penalties']
        midpoint = 0.1 + (100000 - 0.1) / 2
        if initial != [[midpoint], midpoint, midpoint]:
            errors.append('INITIAL_PENALTIES')
        if type(obs['initial_solution_feasible']) is not bool:
            errors.append('INITIAL_FEASIBILITY_TYPE')
        previous = initial
        if len(obs['rows']) != 250:
            errors.append('OBSERVER_ROW_COUNT')
        for iteration, row in enumerate(obs['rows'], 1):
            if row['iteration'] != iteration:
                errors.append('OBSERVER_ITERATION')
            expected = row['expected_search_penalties_source_derived']
            post = row['observed_post_registration_penalties']
            if not snapshot_valid(expected) or not snapshot_valid(post):
                errors.append('PENALTY_SNAPSHOT_SCHEMA_OR_BOUNDS')
                continue
            if expected != previous:
                errors.append('EXPECTED_SOURCE_ORDER')
            expected_probes = [
                {'violation': value, 'load': int(value * expected[0][0]),
                 'duration': int(value * expected[1]), 'distance': int(value * expected[2])}
                for value in [1, 1000]
            ]
            if row['observed_search_evaluator_integer_probes'] != expected_probes:
                errors.append('EVALUATOR_PUBLIC_PROBE_MISMATCH')
            scheduled = iteration % interval == 0
            if scheduled:
                result['scheduled_update_checks'].append(iteration)
            if post != previous:
                result['observed_numeric_change_iterations'].append(iteration)
                if not scheduled:
                    errors.append('UNSCHEDULED_NUMERIC_PENALTY_CHANGE')
            previous = post
        result['observation_sha256'] = digest(obs)
        result['observed_initial_penalties'] = initial
        result['observed_final_post_registration_penalties'] = previous
    except (KeyError, TypeError, ValueError, IndexError) as exc:
        errors.append('OBSERVER_MALFORMED:' + repr(exc))
    result['valid'] = not errors
    return result


def audit_answer(problem, entry, answer, defaults, original=None, observe=True):
    tag = 'p' + str(entry['solutions_between_updates'])
    result = audit_saved_answer(problem, {**entry, 'arm': tag}, answer)
    result['solutions_between_updates'] = entry['solutions_between_updates']
    errors = []
    if not isinstance(answer, dict):
        return result
    try:
        expected_params = copy.deepcopy(defaults)
        expected_params['values']['penalty']['values']['solutions_between_updates'] = entry['solutions_between_updates']
        if observe:
            expected_params['values']['ils']['values']['callbacks'] = {'type': 'observer.ReadonlyPenaltyObserver', 'values': {}}
        if answer['default_solve_params'] != expected_params:
            errors.append('OTHER_SOLVER_PARAMETER_CHANGE')
        if answer['solutions_between_updates'] != entry['solutions_between_updates']:
            errors.append('REGISTRATION_INTERVAL_MISMATCH')
        if answer['observe_penalties'] is not observe:
            errors.append('OBSERVER_MODE_MISMATCH')
        expected_limits = {'inherited': {'AS_bytes': [512 * 1024**2, 1536 * 1024**2], 'CPU_seconds': [30, 30]},
                           'effective': {'AS_bytes': [1536 * 1024**2, 1536 * 1024**2], 'CPU_seconds': [15, 15]}}
        if answer['resource_limits'] != expected_limits:
            errors.append('RESOURCE_LIMIT_CHANGE')
        if original is not None:
            for key in ('native_model_parameters', 'model_matrix_sha256', 'seed'):
                if answer[key] != original[key]:
                    errors.append('HISTORICAL_MODEL_IDENTITY_MISMATCH:' + key)
        if observe:
            result['penalty_trace_audit'] = audit_observation(answer, entry['solutions_between_updates'])
            errors.extend(result['penalty_trace_audit']['errors'])
        elif answer['penalty_observation'] is not None:
            errors.append('UNEXPECTED_OBSERVATION')
    except (KeyError, TypeError, ValueError, IndexError) as exc:
        errors.append('PARAM_OR_TRACE_SCHEMA:' + repr(exc))
    return invalidate(result, errors)


def audit_call(problem, entry, item, answer, defaults, original=None, observe=True):
    result = audit_answer(problem, entry, answer, defaults, original, observe)
    errors = []
    status = None
    if not isinstance(item, dict):
        return invalidate(result, ['MISSING_RESULT'], 'MISSING_RESULT')
    if item.get('status') in ('WALL_TIMEOUT', 'PROCESS_FAILURE_OR_CPU_LIMIT', 'CALL_ERROR_UNDETERMINED'):
        status = item['status']
    if item.get('schedule') != entry or item.get('call_id') != entry['call_id']:
        errors.append('SCHEDULE_MISMATCH')
    if item.get('returncode') != 0 or not item.get('process_spawned') or not item.get('child_reaped'):
        errors.append('PROCESS_FAILURE')
    if item.get('status') not in ('UNREVIEWED_PROCESS_SUCCESS', 'UNREVIEWED_INFEASIBLE'):
        errors.append('PROCESS_STATUS_FAILURE')
    payload = payload_for(problem, entry, observe)
    expected_hash = hashlib.sha256(json.dumps(payload, separators=(',', ':')).encode()).hexdigest()
    if item.get('payload_sha256') != expected_hash:
        errors.append('PAYLOAD_HASH_MISMATCH')
    if isinstance(answer, dict) and type(answer.get('solver_is_feasible')) is bool:
        expected_status = 'UNREVIEWED_PROCESS_SUCCESS' if answer['solver_is_feasible'] else 'UNREVIEWED_INFEASIBLE'
        if item.get('status') in ('UNREVIEWED_PROCESS_SUCCESS', 'UNREVIEWED_INFEASIBLE') and item['status'] != expected_status:
            errors.append('STATUS_FLAG_MISMATCH')
    result['process_status'] = item.get('status')
    return invalidate(result, errors, status)


def trajectory_diagnostic(a, b, length, label):
    out = {'label': label, 'status': 'UNAVAILABLE', 'first_difference': None,
           'iterations': length, 'timing_excluded': True, 'is_inclusion_or_rerun_gate': False}
    if not isinstance(a, dict) or not isinstance(b, dict):
        return out
    try:
        x, y = a['stats'][:length], b['stats'][:length]
        if len(x) != length or len(y) != length:
            return out
        out.update(status='SAME' if x == y else 'DIFFERENT', left_sha256=digest(x), right_sha256=digest(y))
        for i, (left, right) in enumerate(zip(x, y), 1):
            if left != right:
                out['first_difference'] = {'iteration': i, 'fields': {k: {'left': left[k], 'right': right[k]} for k in COST_FIELDS + BOOL_FIELDS if left[k] != right[k]}}
                break
    except (KeyError, TypeError, ValueError):
        out['status'] = 'UNAVAILABLE'
    return out


def paired_record(iid, seed, control, treatment):
    valid = control['valid_feasible'] and treatment['valid_feasible']
    delta = treatment['cost'] - control['cost'] if valid else None
    return {'instance_id': iid, 'seed': seed, 'cells': {'p500': control, 'p50': treatment},
            'common_success': valid, 'delta_cost': delta,
            'relative_delta_pct': 100 * delta / control['cost'] if valid else None,
            'delta_vehicles': treatment['vehicles'] - control['vehicles'] if valid else None}


def summarize(rows):
    n = len(rows)
    result = {'planned_pairs': n, 'planned_cells': n * 2, 'feasibility': {},
              'complete_primary': {}, 'conditional_common_success': {}}
    for arm in ('p500', 'p50'):
        cells = [row['cells'][arm] for row in rows]
        feasible = sum(cell['valid_feasible'] for cell in cells)
        result['feasibility'][arm] = {'feasible': feasible, 'planned_denominator': n,
                                    'fraction': feasible / n if n else None,
                                    'statuses': dict(Counter(cell['status'] for cell in cells))}
        result['complete_primary'][arm + '_cost'] = metric([cell['cost'] if cell['valid_feasible'] else None for cell in cells], n, False)
    result['descriptive_paired_risk_difference'] = (result['feasibility']['p50']['feasible'] - result['feasibility']['p500']['feasible']) / n if n else None
    transitions = {name: 0 for name in ('success_success', 'success_failure', 'failure_success', 'failure_failure')}
    detailed = Counter()
    for row in rows:
        left, right = row['cells']['p500'], row['cells']['p50']
        transitions[('success' if left['valid_feasible'] else 'failure') + '_' + ('success' if right['valid_feasible'] else 'failure')] += 1
        detailed[left['status'] + ' -> ' + right['status']] += 1
    result['paired_success_transitions'] = transitions
    result['paired_detailed_status_transitions'] = dict(detailed)
    for key in ('delta_cost', 'relative_delta_pct', 'delta_vehicles'):
        values = [row[key] for row in rows]
        result['complete_primary'][key] = metric(values, n, False)
        result['conditional_common_success'][key] = metric(values, n, True)
    result['common_success_count'] = sum(row['common_success'] for row in rows)
    return result
