"""Exactly eight prespecified toy solves through the production limited supervisor."""
import json
import signal
from common import ROOT, read, save, now, sha
from run_once import logged_call
from endpoints import audit_call, audit_ledger, payload_for


def run_in_limited_supervisor(limits):
    assert limits == {'AS_bytes': [512 * 1024**2, 1536 * 1024**2], 'CPU_seconds': [30, 30]}
    signal.alarm(240)
    dest = ROOT / 'selftests/integration'
    dest.mkdir(exist_ok=False)
    calls = dest / 'calls'
    calls.mkdir()
    python = read('environment/RUNTIME.json')['python_executable']
    fixtures = [
        {'instance_id': 'TOY_FEASIBLE', 'coordinates': [[0, 0], [1, 0], [2, 0], [0, 1], [0, 2]], 'demands': [0, 1, 1, 1, 1], 'capacity': 2, 'K': 2},
        {'instance_id': 'TOY_IMPOSSIBLE', 'coordinates': [[0, 0], [1, 0], [2, 0], [0, 1], [0, 2]], 'demands': [0, 1, 1, 1, 1], 'capacity': 1, 'K': 2},
    ]
    schedule = []
    for fixture in fixtures:
        for interval in (500, 50):
            for observe in (False, True):
                schedule.append({'call_id': fixture['instance_id'] + '_p' + str(interval) + ('_observed' if observe else '_plain'),
                                 'instance_id': fixture['instance_id'], 'seed': 0, 'K': 2,
                                 'max_iterations': 250, 'solutions_between_updates': interval,
                                 'observe_penalties': observe, 'schedule_index': len(schedule) + 1})
    save(dest / 'PLANNED.json', {'fixtures': fixtures, 'schedule': schedule, 'planned_native_builds': 8, 'planned_solver_calls': 8})
    byid = {fixture['instance_id']: fixture for fixture in fixtures}
    records = []
    for entry in schedule:
        problem = byid[entry['instance_id']]
        payload = payload_for(problem, entry, entry['observe_penalties'])
        records.append(logged_call(entry, payload, python, calls, dest))
    # Analysis happens only after the fixed eight attempts have all been retained.
    errors = []
    answers = {}
    audits = []
    defaults = read('environment/DEFAULT_SOLVE_PARAMS.json')
    for entry, item in zip(schedule, records):
        answer = None
        try:
            answer = json.loads((ROOT / item['stdout']).read_text())
        except (ValueError, OSError) as exc:
            errors.append(entry['call_id'] + ': output unavailable ' + repr(exc))
        audited = audit_call(byid[entry['instance_id']], entry, item, answer, defaults, observe=entry['observe_penalties'])
        if audited['errors']:
            errors.append(entry['call_id'] + ': ' + repr(audited['errors']))
        expected_feasible = entry['instance_id'] == 'TOY_FEASIBLE'
        if audited['valid_feasible'] != expected_feasible or not audited['valid_record']:
            errors.append(entry['call_id'] + ': unexpected toy feasibility or invalid output')
        answers[entry['call_id']] = answer
        audits.append(audited)
    invariance = []
    for i in range(0, 8, 2):
        left = answers[schedule[i]['call_id']]
        right = answers[schedule[i + 1]['call_id']]
        fields = ['stats', 'routes', 'reported_cost', 'reported_distance', 'solver_is_feasible', 'native_model_parameters', 'model_matrix_sha256']
        equal = isinstance(left, dict) and isinstance(right, dict) and all(left[field] == right[field] for field in fields)
        invariance.append({'plain': schedule[i]['call_id'], 'observed': schedule[i + 1]['call_id'], 'equal_non_time_fields': equal, 'fields': fields})
        if not equal:
            errors.append('Readonly observer invariance mismatch for ' + schedule[i]['call_id'])
    attempts = [json.loads(line) for line in (dest / 'attempts.jsonl').read_text().splitlines()]
    ledger = audit_ledger(schedule, attempts, records)
    if ledger['status'] != 'PASS':
        errors.append('Toy ledger invalid')
    signal.alarm(0)
    result = {'status': 'PASS' if not errors else 'FAIL', 'utc': now(), 'errors': errors,
              'scope': 'Prespecified 2 four-client fixtures by 2 intervals by 2 callback modes; 250 iterations, seed0. No public input solves.',
              'planned_synthetic_solver_calls': 8, 'recorded_attempts': len(records),
              'spawned_workers': sum(item['process_spawned'] for item in records),
              'completed_solver_calls_with_outputs': sum(isinstance(a, dict) and a.get('num_iterations') == 250 for a in answers.values()),
              'public_solver_calls': 0, 'supervisor_limits': limits, 'audits': audits,
              'observer_invariance': invariance, 'ledger': ledger,
              'source_sha256': {name: sha(ROOT / 'source' / name) for name in ['worker.py', 'observer.py', 'run_once.py', 'synthetic_integration.py', 'endpoints.py']}}
    save(ROOT / 'selftests/SUPERVISOR_INTEGRATION.json', result)
    print(json.dumps({'status': result['status'], 'completed_solver_calls_with_outputs': result['completed_solver_calls_with_outputs'], 'errors': errors}))
    return 0 if not errors else 1
