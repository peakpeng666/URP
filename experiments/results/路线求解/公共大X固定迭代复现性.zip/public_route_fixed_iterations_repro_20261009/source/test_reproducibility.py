"""Invented pure-Python endpoint and missingness tests, no PyVRP import."""
import copy,unittest
from reproducibility import audit_call,compare_pair,canonical_routes
PROBLEM={'coordinates':[[0,0],[1,0],[2,0],[3,0]],'demands':[0,1,1,1],'capacity':3,'K':3}

def fixture(rep='A'):
 e={'call_id':'INVENTED_s0_'+rep,'instance_id':'INVENTED','seed':0,'repeat':rep,'max_iterations':25}
 i={**e,'status':'UNREVIEWED_PROCESS_SUCCESS','returncode':0,'process_spawned':True,'child_reaped':True}
 a={'version':'0.14.0','solver':'PyVRP','algorithm':'ILS','seed':0,'max_iterations':25,'solver_is_feasible':True,'solver_is_complete':True,'denied_io_events':[],'reference_or_history_payload_fields':[],'reported_cost':6,'reported_distance':6,'internal_route_cost':6,'reported_duration_cost':0,'reported_fixed_vehicle_cost':0,'reported_num_routes':1,'num_iterations':25,'routes':[[0,1,2,3,0]],'stats':[{'current_cost':6,'candidate_cost':6,'best_cost':6,'current_feas':True,'candidate_feas':True,'best_feas':True} for _ in range(25)],'stats_runtime_per_iteration':[.001]*25,'model_matrix_sha256':'a'*64,'native_model_parameters':{},'default_solve_params':{}}
 return e,i,a

def audited(rep='A',mutate=None):
 e,i,a=fixture(rep)
 if mutate:mutate(a)
 return audit_call(PROBLEM,e,i,a)

class Tests(unittest.TestCase):
 def test_equal(self):self.assertEqual(compare_pair(audited(),audited('B'))['status'],'PASS')
 def test_timing_excluded(self):
  self.assertEqual(compare_pair(audited(),audited('B',lambda a:a.update(stats_runtime_per_iteration=[9.]*25,worker_maxrss_KiB_audit_only=999)))['status'],'PASS')
 def test_reverse_canonical(self):
  p=compare_pair(audited(),audited('B',lambda a:a.update(routes=[[0,3,2,1,0]])));self.assertEqual(p['status'],'PASS');self.assertFalse(p['raw_route_order_and_direction_equal'])
 def test_same_cost_different_route(self):
  p=compare_pair(audited(),audited('B',lambda a:a.update(routes=[[0,1,3,2,0]])));self.assertEqual(p['status'],'DIFFERENT');self.assertTrue(p['cost_equal']);self.assertFalse(p['canonical_routes_equal'])
 def test_trajectory_difference(self):
  def mut(a):a['stats'][7]['candidate_cost']=7
  p=compare_pair(audited(),audited('B',mut));self.assertEqual(p['status'],'DIFFERENT');self.assertEqual(p['first_differing_iteration']['iteration'],8)
 def test_float_is_not_integer_stat(self):
  def mut(a):a['stats'][0]['current_cost']=6.0
  self.assertEqual(compare_pair(audited(),audited('B',mut))['status'],'UNCONFIRMED')
 def test_bool_is_not_integer_cost(self):self.assertFalse(audited(mutate=lambda a:a.update(reported_cost=True))['valid_for_primary'])
 def test_missing_call(self):
  e,i,a=fixture('B');self.assertEqual(compare_pair(audited(),audit_call(PROBLEM,e,None,None))['status'],'UNCONFIRMED')
 def test_failed_call_same_result_not_pass(self):
  e,i,a=fixture('B');i['status']='WALL_TIMEOUT';self.assertEqual(compare_pair(audited(),audit_call(PROBLEM,e,i,a))['status'],'UNCONFIRMED')
 def test_invalid_same_outputs_not_pass(self):
  a=audited(mutate=lambda x:x.update(routes=[[0,1,2,0]]));self.assertEqual(compare_pair(a,a)['status'],'UNCONFIRMED')
 def test_invalid_difference_preserved(self):
  a=audited(mutate=lambda x:x.update(reported_cost=999));p=compare_pair(audited(),a);self.assertEqual(p['status'],'UNCONFIRMED');self.assertIn('cost',p['different_fields'])
 def test_wrong_length(self):self.assertFalse(audited(mutate=lambda a:a.update(stats=a['stats'][:24]))['valid_for_primary'])
 def test_native_snapshot_difference(self):self.assertEqual(compare_pair(audited(),audited('B',lambda a:a.update(native_model_parameters={'changed':1})))['status'],'DIFFERENT')
 def test_canonical_route_order(self):self.assertEqual(canonical_routes([[0,3,2,0],[0,1,0]]),canonical_routes([[0,1,0],[0,2,3,0]]))
if __name__=='__main__':unittest.main()
