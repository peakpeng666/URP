"""Pure saved-evidence endpoints; no solver import and no timing comparison."""
import hashlib,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'independent_review'))
from independent_validator import validate_solution
COST_FIELDS=('current_cost','candidate_cost','best_cost')
BOOL_FIELDS=('current_feas','candidate_feas','best_feas')
STATS_FIELDS=set(COST_FIELDS+BOOL_FIELDS)

def canonical_routes(routes):
    """Symmetric single-depotCVRP equivalence; original routes are not modified."""
    return [list(t) for t in sorted(min(tuple(r[1:-1]),tuple(reversed(r[1:-1]))) for r in routes)]

def digest(value):return hashlib.sha256(json.dumps(value,separators=(',',':'),sort_keys=True,allow_nan=False).encode()).hexdigest()

def audit_call(problem,entry,item,answer):
    record={'call_id':entry['call_id'],'instance_id':entry['instance_id'],'seed':entry['seed'],'repeat':entry['repeat'],'valid_for_primary':False,'errors':[],'process_status':None if item is None else item.get('status')}
    errors=record['errors']
    if item is None:errors.append('MISSING_RESULT_SLOT')
    else:
        if any(item.get(k)!=entry[k] for k in entry):errors.append('SCHEDULE_METADATA_MISMATCH')
        if item.get('status')!='UNREVIEWED_PROCESS_SUCCESS':errors.append('PROCESS_NOT_SUCCESSFUL')
        if item.get('returncode')!=0:errors.append('NONZERO_OR_MISSING_RETURN_CODE')
        if not item.get('process_spawned') or not item.get('child_reaped'):errors.append('PROCESS_NOT_SPAWNED_OR_REAPED')
    if not isinstance(answer,dict):errors.append('MISSING_OR_MALFORMED_OUTPUT');return record
    try:
        if answer['version']!='0.14.0' or answer['solver']!='PyVRP' or answer['algorithm']!='ILS':errors.append('ALGORITHM_MISMATCH')
        if type(answer['seed']) is not int or answer['seed']!=entry['seed']:errors.append('SEED_MISMATCH')
        if type(answer['max_iterations']) is not int or answer['max_iterations']!=25:errors.append('BUDGET_MISMATCH')
        if answer['solver_is_feasible'] is not True or answer['solver_is_complete'] is not True:errors.append('SOLVER_INFEASIBLE_OR_INCOMPLETE')
        if answer['denied_io_events']!=[] or answer['reference_or_history_payload_fields']!=[]:errors.append('IO_OR_REFERENCE_VIOLATION')
        if type(answer['reported_cost']) is not int:errors.append('COST_NOT_INTEGER')
        if type(answer['num_iterations']) is not int or answer['num_iterations']!=25:errors.append('WRONG_ITERATION_COUNT')
        stats=answer['stats']
        schema=isinstance(stats,list) and len(stats)==25 and all(isinstance(d,dict) and set(d)==STATS_FIELDS and all(type(d[k]) is int for k in COST_FIELDS) and all(type(d[k]) is bool for k in BOOL_FIELDS) for d in stats)
        if not schema:errors.append('WRONG_QUALITY_TRAJECTORY_SCHEMA')
        if not isinstance(answer['stats_runtime_per_iteration'],list) or len(answer['stats_runtime_per_iteration'])!=25:errors.append('WRONG_RUNTIME_DIAGNOSTIC_LENGTH')
        audit=validate_solution(problem,answer['routes'],answer['reported_cost'])
        record['route_validation']=audit
        if not(audit['valid'] and audit['reported_cost_checked'] and audit['reported_cost_matches']):errors.append('INDEPENDENT_ROUTE_OR_COST_INVALID')
        if answer['reported_cost']!=answer['reported_distance'] or answer['reported_cost']!=answer['internal_route_cost']:errors.append('OBJECTIVE_MISMATCH')
        if answer['reported_duration_cost']!=0 or answer['reported_fixed_vehicle_cost']!=0:errors.append('NON_DISTANCE_COST')
        if any(len(r)<3 for r in answer['routes']) or answer['reported_num_routes']!=len(answer['routes']):errors.append('EMPTY_OR_MISCOUNTED_ROUTES')
        if not isinstance(answer['native_model_parameters'],dict) or not isinstance(answer['default_solve_params'],dict):errors.append('MISSING_NATIVE_OR_DEFAULT_PARAMETERS')
        if not isinstance(answer['model_matrix_sha256'],str) or len(answer['model_matrix_sha256'])!=64:errors.append('MISSING_MATRIX_HASH')
        record.update(cost=answer['reported_cost'],solver_is_feasible=answer['solver_is_feasible'],solver_is_complete=answer['solver_is_complete'],num_iterations=answer['num_iterations'],model_matrix_sha256=answer['model_matrix_sha256'],default_solve_params=answer['default_solve_params'],native_model_parameters=answer['native_model_parameters'],stats=stats)
        if audit['valid']:
            record['canonical_routes']=canonical_routes(answer['routes']);record['canonical_route_sha256']=digest(record['canonical_routes']);record['raw_routes']=answer['routes']
        if schema:record['quality_trajectory_sha256']=digest(stats)
    except (KeyError,TypeError,ValueError) as exc:errors.append('OUTPUT_SCHEMA_ERROR: '+repr(exc))
    record['valid_for_primary']=not errors
    return record

def compare_pair(first,second):
    fields=('cost','solver_is_feasible','solver_is_complete','num_iterations','model_matrix_sha256','default_solve_params','native_model_parameters','canonical_routes','stats')
    differences={key:{'A':first[key],'B':second[key]} for key in fields if key in first and key in second and first[key]!=second[key]}
    good=first['valid_for_primary'] and second['valid_for_primary']
    status=('PASS' if not differences else 'DIFFERENT') if good else 'UNCONFIRMED'
    first_diff=None
    if 'stats' in differences and isinstance(first['stats'],list) and isinstance(second['stats'],list):
        for i,(a,b) in enumerate(zip(first['stats'],second['stats']),1):
            if a!=b:first_diff={'iteration':i,'A':a,'B':b};break
        if first_diff is None and len(first['stats'])!=len(second['stats']):first_diff={'iteration':min(len(first['stats']),len(second['stats']))+1,'reason':'length differs'}
    return {'status':status,'A_call_id':first['call_id'],'B_call_id':second['call_id'],'A_errors':first['errors'],'B_errors':second['errors'],'different_fields':list(differences),'differences':differences,'first_differing_iteration':first_diff,'raw_route_order_and_direction_equal':first.get('raw_routes')==second.get('raw_routes') if 'raw_routes' in first and 'raw_routes' in second else None,'canonical_routes_equal':first.get('canonical_routes')==second.get('canonical_routes') if 'canonical_routes' in first and 'canonical_routes' in second else None,'cost_equal':first.get('cost')==second.get('cost') if 'cost' in first and 'cost' in second else None,'trajectory_equal':first.get('stats')==second.get('stats') if 'stats' in first and 'stats' in second else None}
