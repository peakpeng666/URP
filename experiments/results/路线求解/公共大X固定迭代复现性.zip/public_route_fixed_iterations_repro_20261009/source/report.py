"""Analyze saved evidence only, after authenticated private RAW readback."""
import json,collections
from common import ROOT,read,save,receipt,verify_frozen,verify_old,sha,now
from reproducibility import audit_call,compare_pair

def main():
    verify_frozen();verify_old();raw_receipt=receipt('RAW_UNREVIEWED')
    independent=read('independent_supervision/results/SAVED_RESULT_AUDIT.json')
    assert independent['status'] in ('PASS_36_OF_36','NOT_ALL_REPRODUCIBLE')
    assert independent['raw_archive_sha256']==raw_receipt['sha256']
    assert independent['frozen_files_sha256']==sha(ROOT/'freeze/FROZEN_FILES.json')
    assert independent['calls_denominator']==72 and independent['pairs_denominator']==36
    schedule=read('freeze/SCHEDULE.json');tasks=read('freeze/TASKS.json')
    results_path=ROOT/'raw/results.jsonl'
    results=[json.loads(line) for line in results_path.read_text().splitlines()] if results_path.exists() else []
    ids=[r['call_id'] for r in results];assert len(ids)==len(set(ids)),'Duplicate result records retained; requires diagnosis'
    expected={e['call_id'] for e in schedule};assert set(ids)<=expected,'Unexpected result records'
    byid={r['call_id']:r for r in results};audits=[];pairs=[];bypair={}
    for entry in schedule:
        item=byid.get(entry['call_id']);answer=None;read_error=None
        if item:
            p=ROOT/item.get('stdout','NO_OUTPUT')
            try:
                assert p.is_relative_to(ROOT/'raw/calls')
                assert sha(p)==item['stdout_sha256']
                answer=json.loads(p.read_text())
            except Exception as exc:read_error=repr(exc)
        audit=audit_call(read('input/'+entry['instance_id']+'.json'),entry,item,answer)
        if read_error:audit['read_error']=read_error
        if item:
            payload={k:read('input/'+entry['instance_id']+'.json')[k] for k in ('coordinates','demands','capacity','K')}
            payload.update(seed=entry['seed'],max_iterations=25)
            import hashlib
            expected_hash=hashlib.sha256(json.dumps(payload,separators=(',',':')).encode()).hexdigest()
            audit['expected_payload_sha256']=expected_hash;audit['recorded_payload_sha256']=item.get('payload_sha256')
            if item.get('payload_sha256')!=expected_hash:audit['errors'].append('PAYLOAD_HASH_MISMATCH');audit['valid_for_primary']=False
        audits.append(audit);bypair.setdefault((entry['instance_id'],entry['seed']),{})[entry['repeat']]=audit
    for task in tasks:
        for seed in [0,1,2]:
            pair=bypair[(task['instance_id'],seed)];record=compare_pair(pair['A'],pair['B']);record.update(instance_id=task['instance_id'],seed=seed,selection_slot=task['selection_slot']);pairs.append(record)
    assert len(audits)==72 and len(pairs)==36
    statuses=dict(collections.Counter(p['status'] for p in pairs))
    assert statuses==independent['pair_statuses']
    assert sum(a['valid_for_primary'] for a in audits)==independent['valid_calls']
    assert {(p['instance_id'],p['seed']):p['status'] for p in pairs}=={(p['instance_id'],p['seed']):p['status'] for p in independent['pairs']}
    assert len(results)==independent['observed_result_records']
    summary={'utc':now(),'question':'Same-input/same-seed fresh-process repetition at25officialILSiterations','planned_call_denominator':72,'planned_pair_denominator':36,'retained_result_records':len(results),'valid_calls':sum(a['valid_for_primary'] for a in audits),'pair_statuses':statuses,'all36_pairs_pass':all(p['status']=='PASS' for p in pairs),'algorithm':'PyVRP0.14.0 defaultILS, standardCVRP K=n_clients, initial_solutionNone','max_iterations':25,'all_calls_no_reruns':True,'cost_mean_or_performance_improvement_claim':None,'limits':'Only these frozen inputs,seeds,version/environment and25iterations; no cross-machine/version determinism or solution-quality claim. Same-config repeats are not independent performance samples.','excluded_equality_fields':'Times/RSS/timestamps/paths/process metadata. Original raw values retained.','first_run_order':'18A-first/18B-first; reversedcaseorder phase2','raw_manifest_sha256':sha(ROOT/'raw/RAW_UNREVIEWED_MANIFEST.json'),'independent_audit_sha256':sha(ROOT/'independent_supervision/results/SAVED_RESULT_AUDIT.json'),'independent_counts_and_every_pair_state_match':True}
    baseline=[]
    for pair in pairs:
        a,b=bypair[(pair['instance_id'],pair['seed'])]['A'],bypair[(pair['instance_id'],pair['seed'])]['B']
        row={'instance_id':pair['instance_id'],'seed':pair['seed'],'pair_status':pair['status'],'call_A':a['call_id'],'call_B':b['call_id'],'cost_A':a.get('cost'),'cost_B':b.get('cost'),'eligible_as_verified_repeatability_baseline':pair['status']=='PASS','selected_repeat':'A' if pair['status']=='PASS' else None,'baseline':None}
        if pair['status']=='PASS':
            row['baseline']={k:a[k] for k in ['cost','canonical_routes','canonical_route_sha256','quality_trajectory_sha256','stats','model_matrix_sha256','expected_payload_sha256']}
        baseline.append(row)
    save(ROOT/'reports/FIXED_ITERATION_BASELINE.json',{'frozen_files_sha256':sha(ROOT/'freeze/FROZEN_FILES.json'),'raw_archive_sha256':raw_receipt['sha256'],'max_iterations':25,'selection_rule':'Use repeatA only forPASS pairs, predetermined rather thanbestof2. Unconfirmed/different pairs stayvisible andhave nobaseline. Thirtysix cases, not72 independent performance samples.','cases':baseline})
    save(ROOT/'reports/CALL_AUDIT.json',audits);save(ROOT/'reports/PAIR_COMPARISON.json',pairs);save(ROOT/'reports/SUMMARY.json',summary)
    outcome=f"{statuses.get('PASS',0)}/36对通过，{statuses.get('DIFFERENT',0)}对存在差异，{statuses.get('UNCONFIRMED',0)}对无法确认；有效调用{summary['valid_calls']}/72。"
    report='固定ILS迭代预算重复性验证\n\n'+outcome+'\n12个既有标准X实例，seeds0/1/2，每配置两个独立新进程；PyVRP0.14.0默认ILS、无warmstart，官方MaxIterations25。\n比较独立验解后的整数成本、规范化无向route签名和25步六字段质量轨迹；轨迹中的cost是当轮evaluator罚后搜索成本，并非全是可行路线原始目标；wall/CPU/RSS时间诊断不要求一致。\n初始化发生于25次计数迭代之前；一次ILS迭代内部工作量可变，不代表等CPU或等基本操作量。\n结论仅适用于本版本、此冻结环境和输入面板，不证明跨机器或版本的确定性。重复运行不能包装为性能提升或独立样本扩充；本实验没有解质量提升比较。\n所有原始路线、计时、过程失败和差异均保留，无正式补跑。独立监督后审见independent_supervision。\n'
    with (ROOT/'reports/REPORT_ZH.txt').open('x') as f:f.write(report)
    print(json.dumps(summary,ensure_ascii=False))
if __name__=='__main__':main()
