"""Invented full-budget smoke through the actual production limited supervisor."""
import sys,json,resource,signal
from common import ROOT,now,read,save,sha
from run_once import execute_call
from reproducibility import audit_call,compare_pair

def run_in_limited_supervisor(limits):
    assert limits=={'AS_bytes':[512*1024**2,1536*1024**2],'CPU_seconds':[30,30]}
    signal.alarm(180)
    dest=ROOT/'selftests/integration';dest.mkdir(exist_ok=False)
    python=read('environment/RUNTIME.json')['python_executable'];records=[];case_audits={}
    fixtures=[
        {'instance_id':'INVENTED_524_LOCATIONS','coordinates':[[0,0]]+[[i%31,(i*17)%29] for i in range(1,524)],'demands':[0]+[1]*523,'capacity':25,'K':523},
        {'instance_id':'INVENTED_STANDARD_UNBOUNDED','coordinates':[[0,0],[1,0],[0,1],[-1,0]],'demands':[0,2,2,2],'capacity':3,'K':3},
        {'instance_id':'INVENTED_DUPLICATE_LOCATIONS','coordinates':[[0,0],[1,1],[1,1],[3,4]],'demands':[0,1,1,2],'capacity':3,'K':3},
    ]
    for seed,fixture in enumerate(fixtures):
        for rep in (('A','B') if seed==0 else ('A',)):
            entry={'call_id':f'FIXTURE_seed{seed}_{rep}','seed':seed,'repeat':rep,'max_iterations':25,'instance_id':fixture['instance_id']}
            payload={k:v for k,v in fixture.items() if k!='instance_id'};payload.update(seed=seed,max_iterations=25)
            record=execute_call(entry,payload,python,dest)
            assert record['status']=='UNREVIEWED_PROCESS_SUCCESS' and record['child_reaped'],record
            answer=json.loads((ROOT/record['stdout']).read_text());audit=audit_call(fixture,entry,record,answer)
            assert audit['valid_for_primary'],audit
            expected={'inherited':limits,'effective':{'AS_bytes':[1536*1024**2,1536*1024**2],'CPU_seconds':[15,15]}}
            assert answer['resource_limits']==expected
            records.append({'kind':'invented_actual_full25iteration_solver','fixture':fixture,'record':record,'audit':audit,'resource_limits':answer['resource_limits'],'worker_maxrss_KiB':answer['worker_maxrss_KiB_audit_only']})
            if seed==0:case_audits[rep]=audit
    # The duplicate test is verification only, and its result is preserved even if different.
    duplicate_result=compare_pair(case_audits['A'],case_audits['B'])
    e={'call_id':'FAULT_malformed','seed':0,'repeat':'A','max_iterations':25,'instance_id':'INVENTED_MALFORMED'}
    bad=execute_call(e,{'malformed':True},python,dest);assert bad['status']=='PROCESS_FAILURE_OR_CPU_LIMIT' and bad['child_reaped'];records.append({'kind':'bad_payload','record':bad})
    second=execute_call(e,{'malformed':True},python,dest);assert second['status']=='CALL_ERROR_UNDETERMINED' and not second['process_spawned'];records.append({'kind':'exclusive_output_guard','record':second})
    signal.alarm(0)
    save(ROOT/'selftests/SUPERVISOR_INTEGRATION.json',{'utc':now(),'status':'PASS','scope':'Actual productionlimitedsupervisor->identicalexecute_call/Popen->exactvenv/realworker->independentDecimalroutecheck. Invented524-locations repeated plus two smallfixtures, full25iterations, malformed and duplicatefileguards. Historical unchangedCPU/wall/ASfaults retained separately; no public solving.','public_optimizer_calls':0,'synthetic_optimizer_calls':4,'supervisor_limits':limits,'supervisor_maxrss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'invented_repeat_comparison':duplicate_result,'records':records,'source_sha256':{name:sha(ROOT/'source'/name) for name in ['worker.py','run_once.py','synthetic_integration.py']}})
    print('PASS syntheticproductionchain, full25iterations andnativeparams; invented repeat '+duplicate_result['status'])
