"""Invented deterministic fixtures. No solver and no actual public-instance optimization."""
import tempfile,copy,json,hashlib
from pathlib import Path
from audit_saved import edge,matrix,signature,parse_vrp,route_audit,trajectory,pairs_from,compact,FIELDS
passed=[]
def expect_failure(name,fn):
    try:fn()
    except (ValueError,KeyError):passed.append(name);return
    raise AssertionError('Expected failure: '+name)
assert [edge((0,0),p)for p in[(0,0),(3,4),(1,1),(1,2),(2,2)]]==[0,5,1,2,3];passed.append('exact_integer_rounding')
text='NAME : invented\nTYPE : CVRP\nDIMENSION : 4\nEDGE_WEIGHT_TYPE : EUC_2D\nCAPACITY : 3\nNODE_COORD_SECTION\n1 0 0\n2 3 0\n3 0 4\n4 3 4\nDEMAND_SECTION\n1 0\n2 1\n3 1\n4 1\nDEPOT_SECTION\n1\n-1\nEOF\n'
with tempfile.TemporaryDirectory()as t:
 p=Path(t)/'invented.vrp';p.write_text(text);d=parse_vrp(p)
assert d=={'instance_id':'invented','coordinates':[[0,0],[3,0],[0,4],[3,4]],'demands':[0,1,1,1],'capacity':3,'K':3};passed.append('independent_vrp_parser')
M=matrix(d);route=[0,1,3,2,0];cost=sum(M[a][b]for a,b in zip(route,route[1:]))
a={'routes':[route],'reported_num_routes':1,'reported_cost':cost,'reported_distance':cost,'internal_route_cost':cost,'reported_fixed_vehicle_cost':0,'reported_duration_cost':0,'solver_is_feasible':True,'solver_is_complete':True,'model_matrix_sha256':hashlib.sha256(compact(M)).hexdigest(),'native_routes':[{'activities':[{'type':'DEPOT'if k in(0,4)else'CLIENT','idx':0 if k in(0,4)else n-1,'location':n,'node':n}for k,n in enumerate(route)],'distance':cost,'delivery':[3],'is_feasible':True,'num_trips':1,'vehicle_type':0,'start_depot':0,'end_depot':0}]}
assert route_audit(a,d,M)['cost']==14;passed.append('valid_feasibility_native_cost')
b=copy.deepcopy(a);b['routes'][0][2]=1;expect_failure('duplicate_missing_client',lambda:route_audit(b,d,M))
b=copy.deepcopy(a);b['reported_cost']+=1;expect_failure('false_cost',lambda:route_audit(b,d,M))
b=copy.deepcopy(a);b['native_routes'][0]['activities'][1]['idx']=2;expect_failure('wrong_native_activity',lambda:route_audit(b,d,M))
b=copy.deepcopy(d);b['capacity']=2;expect_failure('over_capacity',lambda:route_audit(a,b,M))
b=copy.deepcopy(a);b['model_matrix_sha256']='0'*64;expect_failure('wrong_matrix',lambda:route_audit(b,d,M))
assert signature([[0,1,2,0],[0,3,0]])==signature([[0,3,0],[0,2,1,0]]);passed.append('route_order_reversal_equivalence')
stats=[{'current_cost':14,'current_feas':True,'candidate_cost':14,'candidate_feas':True,'best_cost':14,'best_feas':True}for _ in range(25)]
t={'num_iterations':25,'max_iterations':25,'stats':stats,'stats_runtime_per_iteration':[.01]*25};trajectory(t);passed.append('trace25_schema')
b=copy.deepcopy(t);b['stats'].pop();expect_failure('trace24_rejected',lambda:trajectory(b))
b=copy.deepcopy(t);b['stats'][0]['best_feas']=1;expect_failure('integer_not_bool_rejected',lambda:trajectory(b))
schedule=[];rows={}
for i in range(36):
 for rep in['A','B']:
  cid=f'c{i}{rep}';schedule.append({'instance_id':str(i//3),'seed':i%3,'repeat':rep,'call_id':cid});rows[cid]={'status':'VALID','value':{'cost':14,'signature':[(1,3,2)],'payload_sha256':'payload','model_matrix_sha256':'matrix','flags':[True,True],'trajectory':copy.deepcopy(stats),'raw_routes':[route],'default_solve_params':{'frozen':'defaults'},'native_model_parameters':{'model':'frozen'}}}
assert len(pairs_from(schedule,rows))==36 and all(x['status']=='PASS'for x in pairs_from(schedule,rows));passed.append('all36_pair_denominator')
b=copy.deepcopy(rows);b['c0A']={'status':'MISSING'};ps=pairs_from(schedule,b);assert len(ps)==36 and sum(x['status']=='PASS'for x in ps)==35 and ps[0]['status']=='UNCONFIRMED';passed.append('missing_retains_denominator')
b=copy.deepcopy(rows);b['c0B']['value']['trajectory'][7]['candidate_cost']=15;ps=pairs_from(schedule,b);assert ps[0]['status']=='DIFFERENT' and ps[0]['first_differing_iteration']['iteration']==8;passed.append('trajectory_difference_located')
print(json.dumps({'status':'PASS','fixture_tests':passed,'count':len(passed),'optimizer_called':False}))
