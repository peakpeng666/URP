"""Independent PREEXEC evidence review, with no model construction or solver imports/calls."""
from pathlib import Path
from collections import Counter,defaultdict
import ast,datetime,json,hashlib,resource,signal
from audit_saved import ROOT,check,load,digest,compact,parse_vrp,matrix,call_audit

def main():
 resource.setrlimit(resource.RLIMIT_CPU,(60,60));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2));signal.alarm(120)
 check(not(ROOT/'raw/STARTED.json').exists()and not(ROOT/'raw/EXECUTOR_STARTED.json').exists(),'must precede formal execution')
 check(not(ROOT/'raw/calls').exists(),'no public-output directory')
 protocol=load(ROOT/'freeze/PROTOCOL.json');schedule=load(ROOT/'freeze/SCHEDULE.json');tasks=load(ROOT/'freeze/TASKS.json');panel=load(ROOT/'freeze/SELECTED_PANEL.json')
 check(protocol['calls']==72 and protocol['pairs']==36 and protocol['instances']==12 and protocol['max_iterations']==25,'fixed protocol counts')
 check(len(schedule)==72 and len({x['call_id']for x in schedule})==72 and len(tasks)==12,'schedule unique72')
 check(schedule[:36]==sorted(schedule[:36],key=lambda e:e['case_index']),'first phase order')
 check([e['case_index']for e in schedule[36:]]==list(reversed([e['case_index']for e in schedule[:36]])),'second phase reverse')
 check(Counter(e['repeat']for e in schedule[:36])==Counter({'A':18,'B':18}),'first-repeat label balance')
 cases=defaultdict(list)
 for i,e in enumerate(schedule,1):
  check(e['sequence']==i and e['max_iterations']==25 and e['seed']in (0,1,2),'entry order/budget/seed')
  cases[e['instance_id'],e['seed']].append(e['repeat'])
 check(len(cases)==36 and all(Counter(v)==Counter({'A':1,'B':1})for v in cases.values()),'36inputseed pairs')
 check({(t['instance_id'],s)for t in tasks for s in [0,1,2]}==set(cases),'complete fixed panel')
 oldinput=Path('/workspace/shared/public_route_larger_X_20261009/input');input_rows=[];matrix_evidence={r['instance_id']:r for r in load(ROOT/'selftests/ACTUAL_MODEL_MATRIX_AUDIT.json')['rows']}
 for task in tasks:
  ident=task['instance_id'];data=parse_vrp(ROOT/'input'/f'{ident}.vrp')
  check(data==load(ROOT/'input'/f'{ident}.json'),'VRP/normalized data '+ident)
  for ext in ['json','vrp']:check(digest(ROOT/'input'/f'{ident}.{ext}')==digest(oldinput/f'{ident}.{ext}'),'unchanged copied input '+ident)
  check(task['eligible']is True and task['errors']==[] and data['K']==task['K']==len(data['demands'])-1,'standard unlimited fleet semantics')
  M=matrix(data);mh=hashlib.sha256(compact(M)).hexdigest();check(mh==matrix_evidence[ident]['model_matrix_sha256'],'independent exact-integer matrix '+ident)
  input_rows.append({'instance_id':ident,'locations':len(M),'K':data['K'],'capacity':data['capacity'],'independent_matrix_sha256':mh})
 for f in ['SUPERVISOR_INTEGRATION.json','PROCESS_CLEANUP.json','ADAPTER_OFFLINE.json','ACTUAL_MODEL_MATRIX_AUDIT.json','STOP_SEMANTICS.json','REUSED_CHAIN_IDENTITY.json']:
  check(load(ROOT/'selftests'/f)['status']=='PASS','author evidence '+f)
 check(load(ROOT/'independent_supervision/results/SYNTHETIC_TESTS.json')['status']=='PASS','own invented fixtures')
 check(load(ROOT/'independent_supervision/results/SAVED_SYNTHETIC_INTEGRATION_AUDIT.json')['status']=='PASS','own actual saved synthetic output review')
 smoke=load(ROOT/'selftests/SUPERVISOR_INTEGRATION.json');check(smoke['public_optimizer_calls']==0 and smoke['synthetic_optimizer_calls']==4,'invented-only smoke accounting')
 for rel,sha in smoke['source_sha256'].items():check(digest(ROOT/'source'/rel)==sha,'source after synthetic smoke '+rel)
 source_hashes={}
 for file in sorted(ROOT.rglob('*.py')):
  ast.parse(file.read_text(),filename=str(file));source_hashes[str(file.relative_to(ROOT))]=digest(file)
 old_count=0
 for group in load(ROOT/'freeze/OLD_FILES_BEFORE.json')['roots']:
  base=Path(group['root']);expected=group['files'];check({str(p.relative_to(base))for p in base.rglob('*')if p.is_file()}==set(expected),'historical file set')
  for rel,m in expected.items():check((base/rel).stat().st_size==m['bytes']and digest(base/rel)==m['sha256'],'historical file '+rel);old_count+=1
 runtime=load(ROOT/'environment/RUNTIME.json');check(digest(Path(runtime['python_executable']).resolve())==runtime['python_binary_sha256'],'runtime executable')
 for m in runtime['installed_distribution_files']:check(Path(m['path']).stat().st_size==m['bytes']and digest(m['path'])==m['sha256'],'installed dependency '+m['path'])
 out={'status':'PASS','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'Independent current-experiment supervisor','scope':'Protocol/source/native baseline/independent original VRP integer matrices/schedule/old data/runtime identities and invented fixture evidence only. No public optimization run or postrun result is claimed.','planned_calls':72,'planned_pairs':36,'input_instances':12,'input_reviews':input_rows,'source_sha256':source_hashes,'old_files_verified_unchanged':old_count,'installed_distribution_files_verified':len(runtime['installed_distribution_files']),'reviewer_optimizer_calls':0,'author_formal_optimizer_calls_before_preexec':0,'author_invented_smoke_calls':4,'resolved_preexec_findings':['CPU1110 renamed configured-limit sum, not strict full-pipeline bound','Native actual model and SolveParams snapshots added','Missing/invalid=>UNCONFIRMED, both valid but different=>DIFFERENT; retain72/36denominators','Penalty-cost trace semantics explicit','Author reporting requires independent saved-result audit and exact hashes/counts/statuses; accepts negative findings','FINAL package requires independently reviewed report/summary hashes'],'limitations':['Same frozen environment and25 official ILS iterations, not equal basic operations or CPU','Short fixed-iteration study is reproducibility, not performance or optimality evidence','Previously observed12-instance panel, not held-out data','Audit hook is not a native syscall sandbox','Restore references inspected; no fresh environment installation performed','Post-RAW audit CPU60/AS512MiB/wall120; no solver imports or calls'],'pending_gates':['New PREEXEC private actual-byte readback','Parent exact-freeze execution authorization and available CPU window','Unique batch, immediate RAW private actual-byte readback before independent saved-result audit','Independent final narrative review and final private actual-byte readback']}
 with(ROOT/'freeze/INDEPENDENT_PRECHECK.json').open('x')as f:json.dump(out,f,ensure_ascii=False,indent=2);f.write('\n')
 print(json.dumps({k:out[k]for k in ['status','planned_calls','planned_pairs','old_files_verified_unchanged','installed_distribution_files_verified','reviewer_optimizer_calls']}))
if __name__=='__main__':main()
