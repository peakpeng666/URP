"""Independent saved-evidence audit. Standard library only; never imports a solver or author validator."""
from pathlib import Path
from collections import Counter,defaultdict
import json,math,hashlib,datetime,resource,signal,sys
ROOT=Path(__file__).resolve().parents[2]
FIELDS=('current_cost','current_feas','candidate_cost','candidate_feas','best_cost','best_feas')
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def compact(x):return json.dumps(x,separators=(',',':')).encode()
def check(flag,message):
    if not flag:raise ValueError(message)
def parse_vrp(path):
    header={};coords={};demands={};depots=[];section=None
    for raw in Path(path).read_text().splitlines():
        s=raw.strip()
        if not s:continue
        if s=='EOF':break
        if s in ('NODE_COORD_SECTION','DEMAND_SECTION','DEPOT_SECTION'):section=s;continue
        if section is None:
            if ':'in s:k,v=s.split(':',1);header[k.strip()]=v.strip()
        elif section=='NODE_COORD_SECTION':
            a=s.split();check(len(a)==3,'coordinate width');i,x,y=map(int,a);check(i not in coords,'duplicate node');coords[i]=[x,y]
        elif section=='DEMAND_SECTION':
            a=s.split();check(len(a)==2,'demand width');i,d=map(int,a);check(i not in demands,'duplicate demand');demands[i]=d
        else:
            for v in map(int,s.split()):
                if v!=-1:depots.append(v)
    N=int(header['DIMENSION']);Q=int(header['CAPACITY'])
    check(header['TYPE']=='CVRP' and header['EDGE_WEIGHT_TYPE']=='EUC_2D','CVRP EUC_2D expected')
    check(sorted(coords)==sorted(demands)==list(range(1,N+1)),'noncontiguous identities')
    check(depots==[1] and demands[1]==0 and Q>0,'depot/capacity')
    check(all(0<=d<=Q for d in demands.values()),'demands')
    return {'instance_id':header['NAME'],'coordinates':[coords[i]for i in range(1,N+1)],'demands':[demands[i]for i in range(1,N+1)],'capacity':Q,'K':N-1}
def edge(a,b):
    s=(a[0]-b[0])**2+(a[1]-b[1])**2;q=math.isqrt(s)
    return q+int(4*s>=(2*q+1)**2)
def matrix(data):return [[edge(a,b)for b in data['coordinates']]for a in data['coordinates']]
def signature(routes):return sorted([min(tuple(r[1:-1]),tuple(reversed(r[1:-1])))for r in routes])
def route_audit(answer,data,M):
    N=len(data['coordinates']);routes=answer['routes'];check(isinstance(routes,list) and 0<len(routes)<=data['K'],'route count')
    check(answer['reported_num_routes']==len(routes),'reported routes')
    served=[];distances=[];loads=[]
    for r in routes:
        check(isinstance(r,list) and len(r)>=3 and all(type(i)is int and 0<=i<N for i in r),'route indices')
        check(r[0]==r[-1]==0 and 0 not in r[1:-1],'route depots')
        served.extend(r[1:-1]);load=sum(data['demands'][i]for i in r[1:-1]);check(load<=data['capacity'],'capacity')
        distances.append(sum(M[a][b]for a,b in zip(r,r[1:])));loads.append(load)
    check(Counter(served)==Counter(range(1,N)),'client multiplicities')
    cost=sum(distances)
    for key in ('reported_cost','reported_distance','internal_route_cost'):check(type(answer[key])is int and answer[key]==cost,key)
    check(answer['reported_fixed_vehicle_cost']==answer['reported_duration_cost']==0,'extra costs')
    check(answer['solver_is_feasible']is True and answer['solver_is_complete']is True,'feasibility flags')
    native=answer['native_routes'];check(len(native)==len(routes),'native route count')
    for r,n,d,l in zip(routes,native,distances,loads):
        check(n['distance']==d and n['delivery']==[l],'native load/cost')
        check(n['is_feasible']is True and n['num_trips']==1 and n['vehicle_type']==n['start_depot']==n['end_depot']==0,'native route model')
        check(len(n['activities'])==len(r),'native activity length')
        for k,(node,a) in enumerate(zip(r,n['activities'])):
            depot=k in (0,len(r)-1)
            check(a=={'type':'DEPOT'if depot else'CLIENT','idx':0 if depot else node-1,'location':node,'node':node},'native activity mapping')
    check(answer['model_matrix_sha256']==hashlib.sha256(compact(M)).hexdigest(),'native matrix digest')
    return {'cost':cost,'signature':signature(routes),'loads':loads}
def expected_native_model(data):
    N=len(data['coordinates']);U=2**63-1
    vehicle={'capacity':[data['capacity']],'num_available':data['K'],'start_depot':0,'end_depot':0,'fixed_cost':0,'unit_distance_cost':1,'unit_duration_cost':0,'unit_overtime_cost':0,'initial_load':[0],'reload_depots':[],'max_reloads':0,'max_trips':1,'max_overtime':0,'max_distance':U,'max_duration':U,'shift_duration':U,'start_late':U,'tw_early':0,'tw_late':U,'profile':0}
    clients=[{'location':i,'delivery':[data['demands'][i]],'pickup':[0],'service_duration':0,'prize':0,'required':True,'release_time':0,'tw_early':0,'tw_late':U,'group':None}for i in range(1,N)]
    return {'locations':[{'x':p[0],'y':p[1]}for p in data['coordinates']],'num_vehicle_types':1,'num_profiles':1,'num_groups':0,'vehicle':vehicle,'clients':clients,'depot':{'location':0,'service_duration':0,'tw_early':0,'tw_late':U},'num_locations':N,'num_clients':N-1,'num_depots':1,'num_vehicles':N-1,'num_shipments':0,'duration_matrix_all_zero':True}
def trajectory(answer):
    check(answer['num_iterations']==answer['max_iterations']==25,'iteration count')
    stats=answer['stats'];check(len(stats)==25,'quality trace length')
    check(len(answer['stats_runtime_per_iteration'])==25,'runtime trace length')
    for row in stats:
        check(set(row)==set(FIELDS),'quality trace fields')
        for f in FIELDS:check(type(row[f])is(bool if f.endswith('_feas')else int),'quality field type '+f)
    return [{f:row[f]for f in FIELDS}for row in stats]
def call_audit(entry,record,answer,data,M):
    check(record['call_id']==entry['call_id'],'call identity')
    check(all(record[k]==v for k,v in entry.items()),'schedule record mismatch')
    check(record['status']=='UNREVIEWED_PROCESS_SUCCESS' and record['process_spawned']is True and record['returncode']==0 and record['child_reaped']is True,'process status')
    payload={k:data[k]for k in ('coordinates','demands','capacity','K')};payload.update(seed=entry['seed'],max_iterations=25)
    expected=hashlib.sha256(compact(payload)).hexdigest();check(record['payload_sha256']==expected,'payload identity')
    check(answer['solver']=='PyVRP' and answer['version']=='0.14.0' and answer['algorithm']=='ILS' and answer['seed']==entry['seed'],'solver identity')
    check(answer['denied_io_events']==answer['reference_or_history_payload_fields']==[],'denied IO/reference payload')
    check(answer['resource_limits']['effective']=={'AS_bytes':[1536*1024**2]*2,'CPU_seconds':[15,15]},'effective child limits')
    check(answer['native_model_parameters']==expected_native_model(data),'native effective model')
    check(answer['default_solve_params']==load(ROOT/'environment/DEFAULT_SOLVE_PARAMS.json'),'frozen default SolveParams')
    value=route_audit(answer,data,M);value.update(trajectory=trajectory(answer),payload_sha256=expected,model_matrix_sha256=answer['model_matrix_sha256'],flags=[answer['solver_is_feasible'],answer['solver_is_complete']],default_solve_params=answer['default_solve_params'],native_model_parameters=answer['native_model_parameters'],raw_routes=answer['routes'])
    return value

def pairs_from(schedule,rows):
    cases=defaultdict(dict)
    for e in schedule:cases[e['instance_id'],e['seed']][e['repeat']]=e['call_id']
    check(len(cases)==36 and all(set(v)=={'A','B'}for v in cases.values()),'36 repeated cases')
    pairs=[]
    for (ident,seed),ids in cases.items():
        a,b=rows[ids['A']],rows[ids['B']];mismatch=[];first=None
        if a['status']=='VALID' and b['status']=='VALID':
            for component in ('cost','signature','payload_sha256','model_matrix_sha256','flags','default_solve_params','native_model_parameters','trajectory'):
                if a['value'][component]!=b['value'][component]:mismatch.append(component)
            if 'trajectory'in mismatch:
                for i,(x,y)in enumerate(zip(a['value']['trajectory'],b['value']['trajectory']),1):
                    if x!=y:first={'iteration':i,'A':x,'B':y};break
            status='DIFFERENT'if mismatch else'PASS'
        else:status='UNCONFIRMED'
        pairs.append({'instance_id':ident,'seed':seed,'A':ids['A'],'B':ids['B'],'status':status,'call_statuses':[a['status'],b['status']],'mismatches':mismatch,'first_differing_iteration':first,'raw_route_equality':a.get('value',{}).get('raw_routes')==b.get('value',{}).get('raw_routes')if status!='UNCONFIRMED'else None})
    return pairs

def main():
    resource.setrlimit(resource.RLIMIT_CPU,(59,59));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2));signal.alarm(119)
    gate=load(ROOT/'provenance/PARENT_AUDIT_APPROVAL.json');check(gate.get('approved')is True,'parent audit gate')
    receipt=load(ROOT/'provenance/RAW_UNREVIEWED_DRIVE_RECEIPT.json')
    check(receipt.get('owner_only')is True and receipt.get('shared')is False and receipt.get('download_byte_identical')is True and receipt.get('remote_readback_sha256_verified')is True,'RAW receipt')
    check(gate.get('raw_archive_sha256')==receipt['sha256'] and gate.get('frozen_files_sha256')==receipt['frozen_files_sha256'],'hash-bound audit approval')
    archive=ROOT.parent/(ROOT.name+'_RAW_UNREVIEWED.zip')
    check(digest(archive)==digest(receipt['download_path'])==receipt['sha256']==receipt['download_sha256'],'RAW actual byte hashes')
    manifest=load(ROOT/'freeze/FROZEN_FILES.json')
    check(digest(ROOT/'freeze/FROZEN_FILES.json')==receipt['frozen_files_sha256'],'freeze receipt')
    for rel,m in manifest['files'].items():check((ROOT/rel).stat().st_size==m['bytes'] and digest(ROOT/rel)==m['sha256'],'frozen '+rel)
    rawmanifest=load(ROOT/'raw/RAW_UNREVIEWED_MANIFEST.json')
    check({str(p.relative_to(ROOT))for p in (ROOT/'raw').rglob('*')if p.is_file() and '__pycache__'not in p.parts}==set(rawmanifest['files'])|{'raw/RAW_UNREVIEWED_MANIFEST.json'},'raw exact member set')
    for rel,m in rawmanifest['files'].items():check((ROOT/rel).stat().st_size==m['bytes'] and digest(ROOT/rel)==m['sha256'],'raw '+rel)
    schedule=load(ROOT/'freeze/SCHEDULE.json');check(len(schedule)==72 and len({e['call_id']for e in schedule})==72,'schedule72')
    records=[json.loads(s)for s in (ROOT/'raw/results.jsonl').read_text().splitlines()]if(ROOT/'raw/results.jsonl').exists()else[]
    check(len({r['call_id']for r in records})==len(records),'duplicate result identity')
    check(set(r['call_id']for r in records)<=set(e['call_id']for e in schedule),'unexpected result identity')
    attempts=[json.loads(s)for s in (ROOT/'raw/attempts.jsonl').read_text().splitlines()]if(ROOT/'raw/attempts.jsonl').exists()else[]
    mapping=load(ROOT/'independent_supervision/postraw_amendment/DERIVED_EVENT_MAPPING.json')
    check(mapping['status']=='PASS_UNAMBIGUOUS_SCHEMA_RECOVERY' and mapping['attempts_sha256']==digest(ROOT/'raw/attempts.jsonl') and mapping['results_sha256']==digest(ROOT/'raw/results.jsonl') and mapping['schedule_sha256']==digest(ROOT/'freeze/SCHEDULE.json'),'postraw mapping identity')
    started=[a['call_id']for a in attempts if 'status'not in a];finished=[a['call_id']for a in attempts if 'status'in a]
    check(len(started)==len(set(started)) and len(finished)==len(set(finished)),'duplicate attempt')
    check(set(started)<=set(e['call_id']for e in schedule) and set(finished)<=set(started),'unexpected attempt')
    check(started==[e['call_id']for e in schedule if e['call_id']in started],'started schedule order')
    expected_attempt=[]
    for cid in started:
        expected_attempt.append(('STARTED',cid))
        if cid in finished:expected_attempt.append(('FINISHED',cid))
    check([('FINISHED'if 'status'in a else'STARTED',a['call_id'])for a in attempts]==expected_attempt,'overlapping or reordered attempts')
    recordmap={r['call_id']:r for r in records};cache={};rows={}
    for a in attempts:
        e=next(e for e in schedule if e['call_id']==a['call_id'])
        if 'status'not in a:check(all(a[k]==v for k,v in e.items()),'attempt scheduled fields')
        else:check({k:v for k,v in a.items()if k!='utc'}==recordmap.get(a['call_id']),'finish/result ledger mismatch')
    old_count=0
    for group in load(ROOT/'freeze/OLD_FILES_BEFORE.json')['roots']:
        root=Path(group['root']);expected=group['files']
        check({str(p.relative_to(root))for p in root.rglob('*')if p.is_file()}==set(expected),'old file set')
        for rel,m in expected.items():check((root/rel).stat().st_size==m['bytes'] and digest(root/rel)==m['sha256'],'old file '+rel);old_count+=1
    for e in schedule:
        cid=e['call_id'];rec=recordmap.get(cid);row={'call_id':cid,'status':'MISSING','error':None}
        if rec:
            try:
                check(cid in started and cid in finished,'missing start/finish attempt evidence')
                ident=e['instance_id']
                if ident not in cache:
                    data=parse_vrp(ROOT/'input'/f'{ident}.vrp');check(data==load(ROOT/'input'/f'{ident}.json'),'independent VRP versus JSON');cache[ident]=(data,matrix(data))
                for key in ('stdout','stderr'):check(digest(ROOT/rec[key])==rec[key+'_sha256'],'saved '+key+' identity')
                row['value']=call_audit(e,rec,load(ROOT/rec['stdout']),*cache[ident]);row['status']='VALID'
            except Exception as ex:row.update(status='INVALID_OR_FAILED',error=str(ex))
        rows[cid]=row
    pairs=pairs_from(schedule,rows);counts=dict(Counter(p['status']for p in pairs));valid=sum(r['status']=='VALID'for r in rows.values())
    out={'status':'PASS_36_OF_36'if counts.get('PASS',0)==36 else'NOT_ALL_REPRODUCIBLE','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'This frozen runtime,12 inputs,3 seeds,two fresh-process repeats,25 official ILS iterations. No performance or cross-environment guarantee.','calls_denominator':72,'pairs_denominator':36,'valid_calls':valid,'observed_result_records':len(records),'started_calls':len(started),'finished_attempts':len(finished),'spawned_calls':sum(bool(r.get('process_spawned'))for r in records),'pair_statuses':counts,'pairs':pairs,'rows':list(rows.values()),'raw_archive_sha256':receipt['sha256'],'frozen_files_sha256':receipt['frozen_files_sha256'],'postraw_schema_adapter':True,'schema_recovery_mapping_sha256':digest(ROOT/'independent_supervision/postraw_amendment/DERIVED_EVENT_MAPPING.json'),'original_audit_failure_retained':'independent_supervision/results/SAVED_AUDIT_RUN.json','old_files_verified_unchanged':old_count,'optimizer_calls_by_reviewer':0,'method':'Independent parser and integer isqrt per-edge rounding; no solver/author-validator imports; exact route coverage,capacity,native activities,cost,matrix,payload,trace and pairing checks.'}
    dest=ROOT/'independent_supervision/results/SAVED_RESULT_AUDIT.json'
    with dest.open('x')as f:json.dump(out,f,ensure_ascii=False,indent=2);f.write('\n')
    print(json.dumps({k:out[k]for k in ['status','valid_calls','calls_denominator','pairs_denominator','pair_statuses','started_calls','spawned_calls']}))
if __name__=='__main__':main()
