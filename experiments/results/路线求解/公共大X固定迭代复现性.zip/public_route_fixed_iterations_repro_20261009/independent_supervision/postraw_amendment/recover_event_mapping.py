"""Post-RAW event-name recovery only. Original bytes and frozen source remain unchanged."""
from pathlib import Path
import json,hashlib,datetime
R=Path(__file__).resolve().parents[2];O=Path(__file__).parent
h=lambda b:hashlib.sha256(b).hexdigest();j=lambda p:json.loads(Path(p).read_text())
def main():
 raw=(R/'raw/attempts.jsonl').read_bytes();lines=raw.splitlines(keepends=True);events=[json.loads(b)for b in lines];records=[json.loads(s)for s in (R/'raw/results.jsonl').read_text().splitlines()];schedule=j(R/'freeze/SCHEDULE.json')
 assert len(events)==144 and len(records)==len(schedule)==72
 rows=[]
 for i,(entry,record)in enumerate(zip(schedule,records)):
  start,finish=events[2*i:2*i+2]
  assert set(start)==set(entry)|{'utc'}and all(start[k]==v for k,v in entry.items())
  assert {k:v for k,v in finish.items()if k!='utc'}==record and all(record[k]==v for k,v in entry.items())
  assert 'status'not in start and 'status'in finish and 'returncode'in finish
  assert datetime.datetime.fromisoformat(start['utc'])<=datetime.datetime.fromisoformat(finish['utc'])
  if i+1<72:assert datetime.datetime.fromisoformat(finish['utc'])<=datetime.datetime.fromisoformat(events[2*(i+1)]['utc'])
  for offset,event,derived in[(0,start,'DERIVED_START'),(1,finish,'DERIVED_FINISH')]:
   ix=2*i+offset;rows.append({'original_line_number_1_based':ix+1,'original_line_including_newline_sha256':h(lines[ix]),'call_id':entry['call_id'],'original_numeric_phase':event['phase'],'derived_event_kind':derived,'utc':event['utc'],'field_set':sorted(event),'exact_match_basis':'schedule+utc'if offset==0 else'result+utc'})
 source=(R/'source/run_once.py').read_text().splitlines();locations=[{'line_number':i+1,'source':line}for i,line in enumerate(source)if "append(ROOT/'raw/attempts.jsonl'"in line]
 assert len(locations)==2
 out={'status':'PASS_UNAMBIGUOUS_SCHEMA_RECOVERY','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'authorization':'Root approval2026-10-09T02:50:17Z for postraw schema-only adapter, no raw/frozen modifications or extra solver calls','attempts_sha256':h(raw),'results_sha256':h((R/'raw/results.jsonl').read_bytes()),'schedule_sha256':h((R/'freeze/SCHEDULE.json').read_bytes()),'frozen_run_once_sha256':h((R/'source/run_once.py').read_bytes()),'frozen_code_write_locations':locations,'cause':'Schedule phase1/2 overwrites event label because entry/item expansion follows literal phase field. PREEXEC did not detect this key collision.','proof':'Each odd line has exact schedule keys+utc and no status; each adjacent even line has exact saved result keys+utc.72call IDs match schedule exactly; UTC spans are non-overlapping and monotonic. Original numeric phase remains checked. Labels in mapping are derived, never represented as original recorded labels.','raw_modified':False,'frozen_source_modified':False,'optimizer_calls':0,'mapping':rows}
 with(O/'DERIVED_EVENT_MAPPING.json').open('x')as f:json.dump(out,f,ensure_ascii=False,indent=2);f.write('\n')
 print(json.dumps({'status':out['status'],'mapped_lines':len(rows),'calls':72}))
if __name__=='__main__':main()
