Read reports/REPORT_ZH.txt first. It prominently discloses the schedule/event phase collision missed at PREEXEC, discovered by independent postrun supervision, and the explicit read-only recovery. The original RAW, frozen source and failed audit remain unchanged. No optimizer rerun occurred.

The reviewed result is 72/72 valid calls and 36/36 matching pairs for this frozen environment, input panel, version, and 25 ILS iterations only. It is not a performance improvement. reports/FIXED_ITERATION_BASELINE.json selects repeat A by the prior rule and includes recovery provenance.

Dependency restoration uses the exact existing private archive listed in environment/RESTORE_MANIFEST.json; no wheel archive is duplicated.
