"""Atomic checkpoint: never credits a candidate completed beyond the delta cut."""
import copy

def at(record,cut):
    out=None;last=None
    init=record.get('initialization') or {}
    if record.get('baseline') is not None and init.get('deltas_after_initialization',cut+1)<=cut:
        out=record['baseline'];last=init['deltas_after_initialization']
    for entry in record.get('trace',[]):
        if entry['deltas']<=cut:
            out=entry['incumbent'];last=entry['deltas']
    if record.get('deltas',0)<=cut and record.get('output') is not None:
        out=record['output']
    return {'requested_deltas':cut,'reached_cut':record.get('deltas',0)>=cut,
            'trajectory_deltas':record.get('deltas',0),'last_atomic_record_deltas':last,
            'output':copy.deepcopy(out)}
