"""Post-seal scoring and replay, with no optimizer import or invocation."""
import collections,copy,csv,json,math,shutil,statistics
from common import ROOT,dump,read,sha,utc,verify
from integer_audit import check
from checkpoints import at
verify()
seal=read(ROOT/'raw/HEURISTICS_FINISHED.json')
assert seal['heuristics_sha256']==sha(ROOT/'raw/heuristics.jsonl')
records=[json.loads(line) for line in (ROOT/'raw/heuristics.jsonl').read_text().splitlines()]
protocol=read(ROOT/'freeze/PROTOCOL.json');schedule=read(ROOT/'freeze/SCHEDULE.json')
keys=lambda r:(r['instance_id'],r['method'],r['search_seed'],r['acceptance_mode'])
assert len(records)==len(schedule)==48 and [keys(r) for r in records]==[keys(r) for r in schedule]
reference_read_started=utc()
# The first reference content access of this experiment occurs here, after raw seal.
parent=ROOT.parent/'official_cvrp_controls_20261008'
for name in protocol['instances']:
    for ext in ['sol','reference_solution.json']:
        target=ROOT/'reference'/f'{name}.{ext}';assert not target.exists();shutil.copyfile(parent/'reference'/target.name,target)
refs={name:read(ROOT/'reference'/f'{name}.reference_solution.json') for name in protocol['instances']}
old_records=[json.loads(x) for x in (ROOT/'regression/parent_heuristics.jsonl').read_text().splitlines()]
old_map={(r['instance_id'],r['method'],r['search_seed']):r for r in old_records}

def canon(routes):return tuple(sorted(min(tuple(r),tuple(reversed(r))) for r in routes))
def bodies(o):return [r[1:-1] for r in o['routes']]
def geo_signature(raw,o,with_load=False):
    parts=[]
    for route in bodies(o):
        coords=tuple(tuple(raw['coordinates'][node]) for node in route)
        seq=min(coords,tuple(reversed(coords)))
        parts.append((seq,sum(raw['demands'][node] for node in route)) if with_load else seq)
    return tuple(sorted(parts))
def loads(raw,o):return tuple(sorted(sum(raw['demands'][n] for n in r) for r in bodies(o)))
def strip_timing(value):
    if isinstance(value,list):return [strip_timing(x) for x in value]
    if isinstance(value,dict):return {k:strip_timing(v) for k,v in value.items() if not k.endswith('_seconds') and k not in ['finished_utc','schedule_index']}
    return value

def project(new,old):
    if isinstance(old,dict):return {k:project(new[k],v) for k,v in old.items() if not k.endswith('_seconds') and k not in ['finished_utc','schedule_index']}
    if isinstance(old,list):
        assert len(new)==len(old)
        return [project(a,b) for a,b in zip(new,old)]
    return new

def packed(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
regressions=[];trace_checks=[];rows=[];anomalies=[];mechanisms=[];errors=[]
for r in records:
    name=r['instance_id'];raw=read(ROOT/'input'/f'{name}.json');ref=refs[name]['total_cost']
    if r['acceptance_mode']=='strict':
        old=old_map[(name,r['method'],r['search_seed'])]
        try:
            projected=project(r,old);expected=strip_timing(old);match=packed(projected)==packed(expected)
            checkpoint_match=all(packed(at(r,cut))==packed(at(old,cut)) for cut in protocol['checkpoints'])
        except (KeyError,AssertionError) as exc:match=False;checkpoint_match=False
        regressions.append({'instance_id':name,'method':r['method'],'search_seed':r['search_seed'],'full_non_timing_bitwise_match':match,'checkpoints_bitwise_match':checkpoint_match,'new_projected_sha256':__import__('hashlib').sha256(packed(projected)).hexdigest() if match else None,'old_non_timing_sha256':__import__('hashlib').sha256(packed(expected)).hexdigest() if match else None})
        if not(match and checkpoint_match):errors.append({'kind':'strict_regression_failure','key':keys(r)})
    current=copy.deepcopy(r.get('baseline'));best=copy.deepcopy(current)
    counts={'equal_cost_candidates':0,'neutral_proposals':0,'neutral_accepted':0,'canonical_noops':0,'strict_improvements':0}
    descriptive={'neutral_coordinate_path_changed':0,'neutral_coordinate_path_unchanged':0,'neutral_load_multiset_changed':0,'neutral_load_multiset_unchanged':0,'neutral_coordinate_route_load_signature_changed':0,'neutral_coordinate_route_load_signature_unchanged':0}
    snapshots=[];passed=True
    if current is not None:assert check(raw,current,5)['accepted']
    for e in r.get('trace',[]):
        assert e['deltas']<=160000
        candidate=e['candidate']
        if candidate is not None:
            assert e['candidate_status']=='complete' and check(raw,candidate,5)['accepted']
            c=candidate['reported_cost'];pc=current['reported_cost'];assert c==int(c)
            kind='strict_improvement' if c<pc else ('canonical_noop' if canon(bodies(candidate))==canon(bodies(current)) else 'neutral_proposal') if c==pc else 'worse'
            assert e['acceptance_kind']==kind
            if c==pc:counts['equal_cost_candidates']+=1
            if kind=='neutral_proposal':
                counts['neutral_proposals']+=1
                for label,a,b in [('coordinate_path',geo_signature(raw,current),geo_signature(raw,candidate)),('load_multiset',loads(raw,current),loads(raw,candidate)),('coordinate_route_load_signature',geo_signature(raw,current,True),geo_signature(raw,candidate,True))]:
                    descriptive['neutral_'+label+('_changed' if a!=b else '_unchanged')]+=1
            if kind=='canonical_noop':counts['canonical_noops']+=1
            accepted=kind=='strict_improvement' or (kind=='neutral_proposal' and r['acceptance_mode']=='neutral')
            assert e['accepted']==accepted
            if accepted:current=copy.deepcopy(candidate)
            if kind=='strict_improvement':counts['strict_improvements']+=1;best=copy.deepcopy(candidate)
            elif accepted:counts['neutral_accepted']+=1
        else:assert e['candidate_status']!='complete' and not e['accepted']
        assert e['current']==current and e['incumbent']==best
        assert check(raw,e['current'],5)['accepted'] and check(raw,e['incumbent'],5)['accepted']
        snapshots.append((e['deltas'],dict(counts),dict(descriptive)))
    if r.get('output') is not None:assert r['output']==best and check(raw,r['output'],5)['accepted']
    if r.get('current_output') is not None:assert r['current_output']==current
    assert r['deltas']<=160000
    if 'delta_by_kind' in r:assert sum(r['delta_by_kind'].values())==r['deltas']
    if 'neutral_counts' in r:assert r['neutral_counts']==counts and r['accepted_improvements']==counts['strict_improvements']
    trace_checks.append({'instance_id':name,'method':r['method'],'search_seed':r['search_seed'],'acceptance_mode':r['acceptance_mode'],'checked_trace_entries':len(r.get('trace',[])),'passed':True})
    mechanisms.append({**{k:r[k] for k in ['instance_id','method','search_seed','acceptance_mode']},**counts,**descriptive})
    for cut in protocol['checkpoints']:
        cp=at(r,cut);checked=check(raw,cp['output'],5);cost=checked['cost'] if checked['accepted'] else None
        selected=[x for x in snapshots if x[0]<=cut]
        cc=selected[-1][1] if selected else {k:0 for k in counts};dd=selected[-1][2] if selected else {k:0 for k in descriptive}
        row={**{k:r[k] for k in ['instance_id','method','search_seed','acceptance_mode']},'checkpoint':cut,'trajectory_status':r['status'],'stop_reason':r['stop_reason'],'reached_cut':cp['reached_cut'],'legal':checked['accepted'],'cost':cost,'official_reference':ref,'gap_percent':100*(cost-ref)/ref if cost is not None else None,'official_value_hit':cost==ref,'output':cp['output'],'check':checked,'last_atomic_record_deltas':cp['last_atomic_record_deltas'],'counts':cc,'descriptive':dd}
        rows.append(row)
        if cost is not None and cost<ref:anomalies.append(row)
summaries=[];pairs=[]
for name in protocol['instances']:
    for cut in protocol['checkpoints']:
        for method in protocol['methods']:
            for mode in protocol['acceptance_modes']:
                group=[r for r in rows if (r['instance_id'],r['checkpoint'],r['method'],r['acceptance_mode'])==(name,cut,method,mode)]
                costs=[r['cost'] for r in group if r['legal']];gaps=[r['gap_percent'] for r in group if r['legal']];status=collections.Counter(r['trajectory_status'] for r in group)
                rec={'instance_id':name,'checkpoint':cut,'method':method,'acceptance_mode':mode,'planned_seeds':4,'observed_rows':len(group),'legal_outputs':len(costs),'reached_cut':sum(r['reached_cut'] for r in group),'INIT_FAIL':status['INIT_FAIL'],'CONSTRUCTION_FAIL':status['CONSTRUCTION_FAIL'],'NOT_RUN':status['NOT_RUN'],'other_failure':sum(v for k,v in status.items() if k not in ['LEGAL_COMPLETION','INIT_FAIL','CONSTRUCTION_FAIL','NOT_RUN']),'official_reference':refs[name]['total_cost'],'cost_mean':statistics.mean(costs) if costs else None,'cost_min':min(costs) if costs else None,'cost_worst':max(costs) if costs else None,'gap_mean_percent':statistics.mean(gaps) if gaps else None,'gap_min_percent':min(gaps) if gaps else None,'gap_worst_percent':max(gaps) if gaps else None,'official_value_hits':sum(r['official_value_hit'] for r in group),'seed_costs':{str(r['search_seed']):r['cost'] for r in group},'counts':{k:sum(r['counts'][k] for r in group) for k in counts},'descriptive':{k:sum(r['descriptive'][k] for r in group) for k in descriptive}}
                summaries.append(rec)
            for seed in protocol['search_seeds']:
                both={r['acceptance_mode']:r for r in rows if (r['instance_id'],r['checkpoint'],r['method'],r['search_seed'])==(name,cut,method,seed)}
                strict,neutral=both['strict'],both['neutral'];d=neutral['cost']-strict['cost'] if strict['legal'] and neutral['legal'] else None
                pairs.append({'instance_id':name,'checkpoint':cut,'method':method,'search_seed':seed,'strict_cost':strict['cost'],'neutral_cost':neutral['cost'],'neutral_minus_strict':d,'outcome':'missing_or_illegal' if d is None else 'improved' if d<0 else 'worsened' if d>0 else 'same'})
paired_summary=[]
for name in protocol['instances']:
    for cut in protocol['checkpoints']:
        for method in protocol['methods']:
            group=[r for r in pairs if (r['instance_id'],r['checkpoint'],r['method'])==(name,cut,method)];c=collections.Counter(r['outcome'] for r in group);diff=[r['neutral_minus_strict'] for r in group if r['neutral_minus_strict'] is not None]
            paired_summary.append({'instance_id':name,'checkpoint':cut,'method':method,'planned_pairs':4,'improved':c['improved'],'worsened':c['worsened'],'same':c['same'],'missing_or_illegal':c['missing_or_illegal'],'mean_neutral_minus_strict':statistics.mean(diff) if diff else None})
receipt=read(ROOT/'receipts/main.json');audit=read(ROOT/'raw/READ_AUDIT.json')
assert receipt['exit_code']==0 and not audit['denied'] and audit['reference_read_count']==0
arms=[]
for mode in protocol['acceptance_modes']:
    group=[r for r in records if r['acceptance_mode']==mode]
    arms.append({'acceptance_mode':mode,'planned_trajectories':24,'solver_cpu_seconds_sum':sum(r.get('solver_cpu_seconds',0) for r in group),'solver_cpu_seconds_mean':statistics.mean(r.get('solver_cpu_seconds',0) for r in group),'solver_wall_seconds_sum':sum(r.get('solver_wall_seconds',0) for r in group),'final_checker_cpu_seconds_sum':sum(r.get('final_checker_cpu_seconds',0) for r in group),'counted_deltas':sum(r['deltas'] for r in group),'matrix_pair_evaluations':sum(r.get('matrix_distances',0) for r in group),'objective_edge_evaluations':sum(r.get('objective_edges',0) for r in group),'delta_by_kind':{k:sum(r.get('delta_by_kind',{}).get(k,0) for r in group) for k in ['savings','removal','insertion']},'counts':{k:sum(r.get('neutral_counts',{}).get(k,0) for r in group) for k in counts}})
resources={'main_receipt':receipt,'by_arm':arms,'fixed_delta_total':sum(r['deltas'] for r in records),'all_48_reached_160k':all(r['deltas']==160000 for r in records),'external_api_calls':0,'model_calls':0,'dependency_installs':0,'purchases':0,'uploads':0,'oracle_calls':0,'cpu_comparison_scope':'Instrumented one-shot same-machine execution, paired mode order alternates. Same counted deltas does not mean same CPU; complete candidates and canonical computations differ. Timing is descriptive and not a dedicated runtime benchmark.'}
regression={'passed':all(x['full_non_timing_bitwise_match'] and x['checkpoints_bitwise_match'] for x in regressions),'matched_trajectories':sum(x['full_non_timing_bitwise_match'] for x in regressions),'planned_strict_trajectories':24,'projection':'Project onto every original old key, dropping timing seconds, finished_utc and schedule_index only; canonical serialized UTF-8 bytes compared, not float tolerances. Added neutral instrumentation excluded. Checkpoints compared in full.','results':regressions}
summary={'utc':utc(),'design':'posthoc exploratory reuse of previously seen official3 instances and original4 seeds; no heldout claim','unique_benchmark_instances':3,'planned_trajectories':48,'observed_trajectories':len(records),'legal_trajectories':sum(r['status']=='LEGAL_COMPLETION' for r in records),'trajectory_status_counts':dict(collections.Counter(r['status'] for r in records)),'planned_checkpoint_rows':96,'observed_checkpoint_rows':len(rows),'legal_checkpoint_rows':sum(r['legal'] for r in rows),'checkpoint_rows_reached':sum(r['reached_cut'] for r in rows),'reference_read_started_after_seal':reference_read_started,'sealed_utc':seal['utc'],'strict_regression_passed':regression['passed'],'below_reference_anomaly_count':len(anomalies),'per_instance_method_arm':summaries,'paired_comparison':paired_summary,'errors':errors,'independent_audit_status':'Not performed by this worker; parent requested to arrange independent audit.','limitations':['Already inspected3 official instances and same4 seeds; posthoc exploratory intervention only.','Seeds and checkpoints are repeated measurements, not independent instances.','No significance, SOTA, universal superiority or new independent-validation claim.','Canonical removes labels and full-route reversal only; real customer IDs including co-located distinct-demand customers retained.','Current may drift across neutral states or cycle; no tabu, annealing, restart, new tuning or extra budget.','Neutral can change future trajectory and worsen final best relative to paired strict despite within-run monotone best.','Same160k counted deltas is not equal CPU; source/check/objective work measured separately.','Official reference value attribution inherited from parent; no new proof of optimality.']}
for path,obj in [('SUMMARY.json',summary),('CHECKPOINT_RESULTS.json',rows),('PAIRED_RESULTS.json',pairs),('PAIRED_SUMMARY.json',paired_summary),('MECHANISM_COUNTS.json',mechanisms),('STRICT_REGRESSION.json',regression),('TRACE_CHECKS.json',{'passed':not errors,'results':trace_checks,'entries_checked':sum(x['checked_trace_entries'] for x in trace_checks)}),('RESOURCE_ACCOUNTING.json',resources),('BELOW_REFERENCE_ANOMALIES.json',anomalies)]:dump(ROOT/'reports'/path,obj)
with (ROOT/'reports/PER_INSTANCE_METHOD_ARM.csv').open('x',newline='') as f:
    fields=[k for k in summaries[0] if k not in ['seed_costs','counts','descriptive']]+list(counts)+list(descriptive);w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
    for r in summaries:w.writerow({**{k:r[k] for k in fields if k in r},**r['counts'],**r['descriptive']})
def fmt(v):return 'NA' if v is None else f'{v:.4f}'
lines=['官方CVRP等成本非等价状态中性接受开关：事后探索','',f"48轨迹合法 {summary['legal_trajectories']}/48；96检查点合法 {summary['legal_checkpoint_rows']}/96、达到预算 {summary['checkpoint_rows_reached']}/96。",f"strict对原24轨迹非计时逐字段bitwise回归：{regression['matched_trajectories']}/24；40k/160k检查点也必须逐字节一致。",f"唯一主跑退出码 {receipt['exit_code']}，wait4实际CPU {receipt['child_total_cpu_seconds']:.6f}s、wall {receipt['elapsed_wall_seconds']:.6f}s；硬限60CPU/90wall。",'这是复用已看过的3个官方实例与原4个seed的事后探索，不是新独立样本或heldout。seed不是实例。未预设收益。','仅改变等整数成本且ID-canonical不同的接受规则；canonical去车辆标签和整路反向，保留真实ID；best仅严格改善更新。初始化、repair、160k计账均不变。','所有mean/min/worst均在每实例/方法/开关的原4seed全分母上报告。','']
for r in summaries:
    lines.append(f"{r['instance_id']} | {r['checkpoint']} | {r['method']} | {r['acceptance_mode']} | legal {r['legal_outputs']}/4 reached {r['reached_cut']}/4 | mean/min/worst cost {r['cost_mean']}/{r['cost_min']}/{r['cost_worst']} | mean/min/worst gap {fmt(r['gap_mean_percent'])}/{fmt(r['gap_min_percent'])}/{fmt(r['gap_worst_percent'])}% | neutral proposed/accepted/noop/strict-improved {r['counts']['neutral_proposals']}/{r['counts']['neutral_accepted']}/{r['counts']['canonical_noops']}/{r['counts']['strict_improvements']}")
lines+=['','配对结果（相同实例/方法/seed，neutral best - strict best；负为改善）：']
for r in paired_summary:lines.append(f"{r['instance_id']} | {r['checkpoint']} | {r['method']} | improved/worsened/same/missing {r['improved']}/{r['worsened']}/{r['same']}/{r['missing_or_illegal']} | mean cost difference {r['mean_neutral_minus_strict']}")
lines+=['','计账与机制：']
for r in arms:lines.append(f"{r['acceptance_mode']}：24轨迹计费delta={r['counted_deltas']}，solver CPU合计={r['solver_cpu_seconds_sum']:.6f}s，mean={r['solver_cpu_seconds_mean']:.6f}s；矩阵pair={r['matrix_pair_evaluations']}，完整目标edge={r['objective_edge_evaluations']}；counts={r['counts']}。")
lines+=['同delta不等于同CPU。本次计时包含新仪表与canonical成本，是单次描述性耗时，非专用运行时基准。','坐标路径、load multiset及坐标路径+载荷签名的变化分类只用于后处理解释，不改变ID接受规则、不调参。坐标相同不意味着同一状态，特别是不同需求客户的分车。','所有候选、current、best、输出均以独立整数逐边checker复核；不完整repair不提交候选；预算截断保留合法best。','无tabu、退火、重启、pilot、补跑、换seed、换实例、oracle、API、安装、购买或上传。','主进程文件读取allowlist阻断reference/regression；全部48条输出flush/fsync/hash封存后分析阶段才读取原参考值。','strict复现只证明实现兼容；neutral结果不能外推更多实例、不能作显著性或SOTA结论。',f'低于官方值异常={len(anomalies)}；独立审计交父任务另行执行。']
(ROOT/'reports/REPORT_ZH.txt').write_text('\n'.join(lines)+'\n')
print(json.dumps({'legal':summary['legal_trajectories'],'strict_regression':regression['passed'],'cpu':receipt['child_total_cpu_seconds'],'paired':paired_summary,'arms':arms},ensure_ascii=False))
assert not errors
