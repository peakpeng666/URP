"""Freeze protocol, minimal diff, inputs, and sources before toys and sole main run."""
import difflib,json,platform,sys
from common import ROOT,dump,read,sha,utc
PARENT=ROOT.parent/'official_cvrp_controls_20261008'
old=read(PARENT/'freeze/PROTOCOL.json')
protocol={**old,'title':'Official CVRP canonical-neutral acceptance switch, posthoc v1','created_utc':utc(),
 'acceptance_modes':['strict','neutral'],'planned_trajectories':48,'planned_checkpoint_rows':96,
 'main_cpu_soft_seconds':59,'main_cpu_hard_seconds':60,'main_wall_seconds':90,
 'search':'All inherited initialization, random removal, cheapest/regret2 repair, integer objective and delta accounting unchanged. Strict improving acceptance retained. Neutral arm also accepts exact equal integer cost iff ID canonical route state differs. Canonical removes vehicle label and whole-route reversal only. Current changes on neutral, best updates only on strict improvement. No tabu, annealing, restart or tuning.',
 'schedule_policy':'Original24 randomized schedule retained; paired strict/neutral jobs adjacent, strict first for even schedule indices, neutral first for odd indices. No new seed or shuffle.',
 'checkpoint_semantics':'One160k trajectory per arm. Record last fully committed BEST at or before40k/160k. Exclude candidate crossing cut; no restart. Best remains unchanged by neutral steps.',
 'primary':'Per instance, method and arm at40k/160k: all4 planned seeds, legal/reached/failure denominators, mean/min/worst integer cost and reference gap. Paired neutral-best minus strict-best classified improvement/worsening/same.',
 'mechanism_metrics':'Completed exact equal-cost candidates, ID-canonical-different neutral proposals, accepted neutral moves, canonical noops, strict improvements; counts for full160k and each atomic checkpoint. Posthoc coordinate-path and route-load signatures are descriptive only and never affect acceptance.',
 'strict_regression':'All original24 strict trajectories and40k/160k checkpoints must match old non-timing results bitwise after projecting new instrumentation out. Strip only keys ending _seconds, cpu_seconds, wall_seconds, finished_utc and schedule_index; preserve original input hashes and all remaining old fields.',
 'anti_leakage':'Solver process allowlists only source/input/freeze plus toy PASS under /workspace; blocks .sol and reference/regression paths. No reference costs/routes in five-field solver inputs. Flush/fsync/hash-seal all outputs before separate analyzer first reads reference values. Source provenance and prior trajectory copies are inaccessible to solver.',
 'hypothesis_scope':'Posthoc exploratory test motivated by already inspected official traces. Reuses same3 previously seen instances and4 seeds. Not independent validation, no heldout/new-instance claim; seeds are search repeats, not instances. No benefit assumed.',
 'failure_policy':'Exactly one main launch. No screening, rerun, replacement or retuning. Any budget-limited or failed planned trajectory retained in denominators. Regression failure blocks scientific conclusion.',
 'resources':'Main child hard60CPU seconds and90wall seconds. Per-trajectory inherited3CPU/10wall safeguards. Fixed160k counted deltas does not imply equal CPU. Report wait4 process CPU and paired per-arm instrumented solver CPU plus extra canonical/check costs.',
 'toy_plan':['exact equal integer cost distinct real IDs','vehicle-label and full-route reversal noop','best retained after neutral and updated on strict','atomic budget cutoff legal','unmocked both methods and modes bounded toy'],
 'seed_novelty_scope':'Exactly original four seeds, no novelty claim.',
 'prior_observation':'Selection motivated by prior read-only diagnosis of rejected equal-cost non-equivalent moves. It is an exploratory intervention, not a prospectively selected fresh benchmark.'}
dump(ROOT/'freeze/PROTOCOL.json',protocol)
schedule=[]
for i,spec in enumerate(read(PARENT/'freeze/SCHEDULE.json')):
    for mode in (['strict','neutral'] if i%2==0 else ['neutral','strict']):schedule.append({**spec,'acceptance_mode':mode,'parent_schedule_index':i})
dump(ROOT/'freeze/SCHEDULE.json',schedule)
parent=ROOT/'provenance/parent_official_solver.py';new=ROOT/'source/official_solver.py'
diff=''.join(difflib.unified_diff(parent.read_text().splitlines(True),new.read_text().splitlines(True),fromfile='parent/official_solver.py',tofile='neutral/official_solver.py'))
(ROOT/'provenance/NEUTRAL_MINIMAL_DIFF.patch').write_text(diff)
dump(ROOT/'freeze/INPUT_MANIFEST.json',{'created_utc':utc(),'files':{str(p.relative_to(ROOT)):sha(p) for p in sorted((ROOT/'input').glob('*'))},'unchanged_from_parent':all(sha(p)==sha(PARENT/'input'/p.name) for p in (ROOT/'input').glob('*'))})
dump(ROOT/'freeze/SOURCE_PROVENANCE.json',{'parent_package':str(PARENT),'parent_manifest_sha256':sha(PARENT/'MANIFEST.json'),'parent_raw_sha256':sha(PARENT/'raw/heuristics.jsonl'),'parent_solver_sha256':sha(parent),'new_solver_sha256':sha(new),'minimal_diff_sha256':sha(ROOT/'provenance/NEUTRAL_MINIMAL_DIFF.patch'),'unchanged_files':['legacy/','integer_audit.py','integer_distance.py','checkpoints.py'],'unchanged_auxiliary_hashes':{str(p.relative_to(ROOT/'source')):sha(p) for p in sorted((ROOT/'source').rglob('*.py')) if p.name in ['integer_audit.py','integer_distance.py','checkpoints.py'] or 'legacy' in p.parts}})
files=sorted([p for folder in ['source','input','freeze','provenance','regression'] for p in (ROOT/folder).rglob('*') if p.is_file()])
dump(ROOT/'freeze/PRE_TOY_FREEZE.json',{'utc':utc(),'sha256':{str(p.relative_to(ROOT)):sha(p) for p in files}})
from toys import run
out=run();dump(ROOT/'reports/TOY_VALIDATION.json',out)
assert out['passed']
# Check all source/protocol bytes remain exactly those frozen before toys.
pre=read(ROOT/'freeze/PRE_TOY_FREEZE.json')
assert all(sha(ROOT/p)==h for p,h in pre['sha256'].items())
# Runtime allowlist-compatible freeze: solver only verifies inputs/source/freeze/toy PASS.
runtime=[p for folder in ['source','input','freeze'] for p in (ROOT/folder).rglob('*') if p.is_file()]+[ROOT/'reports/TOY_VALIDATION.json']
dump(ROOT/'freeze/PRE_RUN_FREEZE.json',{'utc':utc(),'sha256':{str(p.relative_to(ROOT)):sha(p) for p in sorted(runtime)},'pre_toy_sha256':sha(ROOT/'freeze/PRE_TOY_FREEZE.json'),'toys_passed':True,'planned_trajectories':48,'main_attempts_before_freeze':0})
print(json.dumps({'frozen':True,'toy_count':len(out['tests']),'planned_trajectories':48,'freeze_sha256':sha(ROOT/'freeze/PRE_RUN_FREEZE.json')}))
