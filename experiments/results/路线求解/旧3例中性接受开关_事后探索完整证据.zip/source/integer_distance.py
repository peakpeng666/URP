"""Only objective adaptation: integer EUC_2D, same all-pair ledger as legacy."""
import math

def edge(a,b):
    if any(type(z) is not int for z in (*a,*b)):
        raise ValueError('integer coordinates required')
    s=(a[0]-b[0])**2+(a[1]-b[1])**2
    root=math.isqrt(s)
    return root + int(4*s >= (2*root+1)**2)

def matrix_for(instance,budget):
    matrix=[]
    for a in instance.coordinates:
        row=[]
        for b in instance.coordinates:
            budget.check();budget.matrix_distances+=1
            row.append(edge(a,b))
        matrix.append(row)
    return matrix
