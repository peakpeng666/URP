from pathlib import Path
import datetime, hashlib, json, sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[1]
def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p): return json.loads(Path(p).read_text())
def dump(p,v):
    with Path(p).open('x') as f: json.dump(v,f,ensure_ascii=False,indent=2,allow_nan=False); f.write('\n')
def digest(v): return hashlib.sha256(json.dumps(v,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def verify():
    f=read(ROOT/'freeze/PRE_RUN_FREEZE.json')
    bad=[p for p,h in f['sha256'].items() if sha(ROOT/p)!=h]
    if bad: raise RuntimeError('frozen files changed: '+repr(bad))
    return f
