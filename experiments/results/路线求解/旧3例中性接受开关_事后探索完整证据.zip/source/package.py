"""Checksummed one-shot immutable delivery, packaging receipt kept outside ZIP."""
import json,zipfile
from common import ROOT,dump,read,sha,utc,verify
verify()
assert read(ROOT/'receipts/main.json')['complete'] and read(ROOT/'receipts/audit.json')['complete']
assert read(ROOT/'reports/STRICT_REGRESSION.json')['passed']
readme='''官方CVRP中性接受开关实验：事后探索\n先读reports/REPORT_ZH.txt。每实例/方法/开关4 seed的mean/min/worst gap见PER_INSTANCE_METHOD_ARM.csv。\n3个已看官方实例 × 2种原repair × strict/neutral × 原4 seed =48轨迹。40k/160k共96检查点。seed不是实例；不是heldout或新独立样本。\n只新增等整数成本且真实ID-canonical不同的接受。canonical仅去车辆标签及整路反向，best仅严格改善更新。\nfreeze封存协议/源码/输入及原schedule的确定性扩展；provenance/NEUTRAL_MINIMAL_DIFF.patch为完整solver最小diff。\nraw/heuristics.jsonl为全部48条逐步轨迹，包含candidate、current与best，READ_AUDIT证明主跑未读参考。\nraw/HEURISTICS_FINISHED先封存；analyze之后才首次复制/读取reference。regression保存原24条，只对分析器开放。\nreports/STRICT_REGRESSION.json逐字段去计时bitwise匹配；CHECKPOINT_RESULTS为96完整检查点，PAIRED_RESULTS为同seed比较。\nMECHANISM_COUNTS含等成本提出、接受、canonical noop、严格改进及仅解释的坐标/载荷分类。\nreceipts记录退出码、wait4 CPU、wall；同delta不等于同CPU。主跑硬限60CPU/90wall秒。\n无新API、模型调用、安装、购买、上传、tabu、退火、重启、调参或补跑；旧包未改。\n本worker只做玩具/自检，父任务另作独立审计。\nMANIFEST与SHA256SUMS覆盖交付文件；archive.sha256校验ZIP。包装receipt及日志位于ZIP外以免自引用。\n'''
(ROOT/'README_ZH.txt').write_text(readme)
name='official_cvrp_neutral_moves_20261008.zip'
excluded={'MANIFEST.json','SHA256SUMS.txt','archive.sha256',name,'receipts/package.json','receipts/package.stdout.log','receipts/package.stderr.log'}
files=sorted(p for p in ROOT.rglob('*') if p.is_file() and str(p.relative_to(ROOT)) not in excluded)
manifest={'created_utc':utc(),'files':[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files],'scope':'Immutable experimental delivery, package supervisor receipt external to avoid recursive hash. Separate parent independent audit is not claimed here.'}
dump(ROOT/'MANIFEST.json',manifest);files.append(ROOT/'MANIFEST.json')
(ROOT/'SHA256SUMS.txt').write_text(''.join(f'{sha(p)}  {p.relative_to(ROOT)}\n' for p in files));files.append(ROOT/'SHA256SUMS.txt')
archive=ROOT/name
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in files:z.write(p,str(p.relative_to(ROOT)))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
(ROOT/'archive.sha256').write_text(f'{sha(archive)}  {name}\n')
for p in files+[archive,ROOT/'archive.sha256']:p.chmod(0o444)
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'manifest_files':len(manifest['files']),'readonly':True}))
