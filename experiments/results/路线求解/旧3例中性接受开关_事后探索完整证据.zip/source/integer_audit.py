"""Independent checker: no solver or matrix imports, direct sqrt/nint edge sums."""
import math
from collections import Counter

def check(raw,output,K):
    xy=raw['coordinates'];demands=raw['demands'];n=len(demands)-1
    errors=[];loads=[];counts=Counter();cost=0;route_costs=[]
    if not isinstance(output,dict) or not isinstance(output.get('routes'),list):
        return {'accepted':False,'errors':['malformed_output'],'cost':None}
    routes=output['routes']
    if len(routes)>K:errors.append('vehicle_upper_bound_exceeded')
    for route in routes:
        if not isinstance(route,list) or len(route)<3 or any(type(j) is not int or not 0<=j<=n for j in route):
            errors.append('invalid_route_shape_or_id');continue
        if route[0]!=0 or route[-1]!=0 or 0 in route[1:-1]:errors.append('invalid_depot')
        counts.update(route[1:-1]);load=sum(demands[j] for j in route[1:-1]);loads.append(load)
        if load>raw['capacity']:errors.append('capacity_exceeded')
        rc=0
        for a,b in zip(route,route[1:]):
            dx=xy[a][0]-xy[b][0];dy=xy[a][1]-xy[b][1]
            rc+=math.floor(math.sqrt(dx*dx+dy*dy)+.5)
        route_costs.append(rc);cost+=rc
    missing=sorted(set(range(1,n+1))-set(counts));duplicate=sorted(j for j,c in counts.items() if c!=1)
    if missing:errors.append('missing_customers')
    if duplicate:errors.append('duplicate_customers')
    claimed=output.get('reported_cost',output.get('cost'))
    if type(claimed) not in (int,float) or not math.isfinite(claimed) or cost!=claimed:errors.append('reported_cost_mismatch')
    return {'accepted':not errors,'errors':errors,'cost':cost,'route_costs':route_costs,'loads':loads,
            'nonempty_routes':len(routes),'missing':missing,'duplicates':duplicate,
            'objective_residual':cost-claimed if type(claimed) in (int,float) and math.isfinite(claimed) else None}
