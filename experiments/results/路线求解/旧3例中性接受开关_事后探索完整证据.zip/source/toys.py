"""Frozen small fixtures; no official instance optimization or reference reads."""
import copy
from unittest.mock import patch
import official_solver as s
from integer_audit import check
from checkpoints import at

def run():
    tests=[];records=[]
    raw={'instance_id':'NEUTRAL_TOY','coordinates':[[0,0]]+[[1,0]]*6,'demands':[0]+[1]*6,'capacity':6,'K':5}
    a=[[1,2,3],[4,5,6]];b=[[1,3,2],[4,5,6]];noop=[[6,5,4],[2,3,1]];improved=[[1,3,2,4,5,6]]
    outputs=[s.output_for(b,4),s.output_for(noop,4),s.output_for(improved,2)]
    for o in [s.output_for(a,4)]+outputs:assert check(raw,o,5)['accepted']
    assert s.canonical(a)==s.canonical([[6,5,4],[3,2,1]])
    assert s.canonical(a)!=s.canonical(b)
    assert s.acceptance_kind(a,4,outputs[0])=='neutral_proposal'
    assert s.acceptance_kind(b,4,outputs[1])=='canonical_noop'
    assert s.acceptance_kind(a,4,s.output_for([[1,2,4],[3,5,6]],4))=='neutral_proposal'
    tests+=['equal_integer_cost_different_ID_order_is_neutral','pure_vehicle_label_and_reversal_are_noop','different_ID_partition_is_retained']
    cfg=dict(delta_limit=100,iterations=3,per_trajectory_cpu_seconds=3.,per_trajectory_wall_seconds=10.)
    def initial(raw,inst,matrix,budget):
        return copy.deepcopy(a),4,{'deltas_after_initialization':budget.deltas,'toy_injected_legal_initialization':True}
    def scripted(*args):
        budget=args[-1]
        try:budget.delta('insertion')
        except s.StopBudget as exc:return {'status':'budget_discarded','reason':str(exc),'candidate':None}
        candidate=copy.deepcopy(outputs[scripted.i]);scripted.i+=1
        return {'status':'complete','candidate':candidate,'checker':check(raw,candidate,5)}
    for mode in [False,True]:
        scripted.i=0
        with patch.object(s,'initialize',initial),patch.object(s,'evaluate_candidate',scripted):
            r=s.run_one(raw,'cheapest',991,{**cfg,'neutral_accept':mode})
        assert r['status']=='LEGAL_COMPLETION' and r['output']==outputs[-1]
        assert r['trace'][0]['incumbent']==s.output_for(a,4)
        assert r['trace'][0]['current']==(outputs[0] if mode else s.output_for(a,4))
        assert r['trace'][0]['accepted']==mode
        assert r['accepted_improvements']==1 and r['neutral_counts']['strict_improvements']==1
        if mode:assert not r['trace'][1]['accepted'] and r['neutral_counts']['canonical_noops']==1 and r['neutral_counts']['neutral_accepted']==1
        assert at(r,1)['output']==s.output_for(a,4) and at(r,3)['output']==outputs[-1]
        records.append(r)
    tests+=['strict_rejects_equal_different_state','neutral_updates_current_but_retains_best','best_updates_only_on_strict_improvement','checkpoint_uses_best_not_current']
    scripted.i=0
    with patch.object(s,'initialize',initial),patch.object(s,'evaluate_candidate',scripted):
        r=s.run_one(raw,'cheapest',991,{**cfg,'neutral_accept':True,'delta_limit':1})
    assert r['deltas']==1 and r['stop_reason']=='delta_budget'
    assert r['output']==s.output_for(a,4) and r['current_output']==outputs[0]
    assert check(raw,r['output'],5)['accepted'] and check(raw,r['current_output'],5)['accepted']
    assert r['trace'][-1]['candidate_status']=='budget_discarded' and not r['trace'][-1]['accepted']
    tests.append('budget_cutoff_preserves_legal_best_and_current');records.append(r)
    inst=s.instance_for(raw);budget=s.Budget(100,3,10);matrix=s.matrix_for(inst,budget);partial=[[2,3],[4,5,6]];before=copy.deepcopy(partial)
    r=s.evaluate_candidate(raw,partial,[1],'regret2',inst,matrix,s.Budget(1,3,10))
    assert r['status']=='budget_discarded' and r['candidate'] is None and partial==before
    tests.append('actual_repair_cutoff_is_atomic');records.append(r)
    # An unmocked bounded toy checks integration for both methods and arms.
    for method in ['cheapest','regret2']:
        for mode in [False,True]:
            r=s.run_one(raw,method,992,{**cfg,'neutral_accept':mode,'iterations':10000,'delta_limit':137})
            assert r['deltas']==137 and r['stop_reason']=='delta_budget' and check(raw,r['output'],5)['accepted']
            assert check(raw,r['current_output'],5)['accepted'];records.append(r)
    tests.append('unmocked_both_methods_both_arms_137_delta_legal')
    return {'passed':True,'tests':tests,'records':records,'official_solver_calls':0,'reference_file_reads':0,'oracle_calls':0}
