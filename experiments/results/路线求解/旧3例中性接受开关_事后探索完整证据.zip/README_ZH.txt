官方CVRP中性接受开关实验：事后探索
先读reports/REPORT_ZH.txt。每实例/方法/开关4 seed的mean/min/worst gap见PER_INSTANCE_METHOD_ARM.csv。
3个已看官方实例 × 2种原repair × strict/neutral × 原4 seed =48轨迹。40k/160k共96检查点。seed不是实例；不是heldout或新独立样本。
只新增等整数成本且真实ID-canonical不同的接受。canonical仅去车辆标签及整路反向，best仅严格改善更新。
freeze封存协议/源码/输入及原schedule的确定性扩展；provenance/NEUTRAL_MINIMAL_DIFF.patch为完整solver最小diff。
raw/heuristics.jsonl为全部48条逐步轨迹，包含candidate、current与best，READ_AUDIT证明主跑未读参考。
raw/HEURISTICS_FINISHED先封存；analyze之后才首次复制/读取reference。regression保存原24条，只对分析器开放。
reports/STRICT_REGRESSION.json逐字段去计时bitwise匹配；CHECKPOINT_RESULTS为96完整检查点，PAIRED_RESULTS为同seed比较。
MECHANISM_COUNTS含等成本提出、接受、canonical noop、严格改进及仅解释的坐标/载荷分类。
receipts记录退出码、wait4 CPU、wall；同delta不等于同CPU。主跑硬限60CPU/90wall秒。
无新API、模型调用、安装、购买、上传、tabu、退火、重启、调参或补跑；旧包未改。
本worker只做玩具/自检，父任务另作独立审计。
MANIFEST与SHA256SUMS覆盖交付文件；archive.sha256校验ZIP。包装receipt及日志位于ZIP外以免自引用。
