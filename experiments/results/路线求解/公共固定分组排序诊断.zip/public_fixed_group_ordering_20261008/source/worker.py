import resource
resource.setrlimit(resource.RLIMIT_CPU,(1,1))
resource.setrlimit(resource.RLIMIT_AS,(256*1024**2,256*1024**2))
import json,sys,time
from engine import matrix,two_opt,held_karp
start=time.monotonic();p=json.load(sys.stdin);d=matrix(p['coordinates'])
if p['kind']=='two_opt':result=two_opt(p['routes'],d,10000)
elif p['kind']=='held_karp':result=held_karp(p['route'],d)
else:raise ValueError('unknown kind')
result['worker_limits']={'cpu_seconds':1,'wall_seconds_external':2,'address_space_MiB':256}
result['worker_cpu_seconds_for_audit_only']=time.process_time()
result['worker_wall_seconds_for_audit_only']=time.monotonic()-start
print(json.dumps(result,separators=(',',':')))
