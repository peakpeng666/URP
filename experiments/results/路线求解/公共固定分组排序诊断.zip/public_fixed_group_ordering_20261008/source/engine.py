"""Frozen pure functions. No benchmark files are read here."""
import math

def matrix(coordinates):
    return [[math.floor(math.hypot(x-u,y-v)+0.5) for u,v in coordinates] for x,y in coordinates]

def cost(route,d):
    return sum(d[a][b] for a,b in zip(route,route[1:]))

def two_opt(routes,d,budget=10000):
    """Shared per-instance cap, route order then lexicographic (i,j), first improving restart."""
    used=0; result=[]
    for slot, original in enumerate(routes,1):
        r=original[:]; m=len(r)-2; start_used=used; moves=[]; status='BUDGET_EXHAUSTED'
        if m<2:
            status='LOCAL_OPTIMUM'
        else:
            while used<budget:
                improved=False; exhausted=False
                for i in range(1,m):
                    for j in range(i+1,m+1):
                        if used>=budget:
                            exhausted=True; break
                        used+=1
                        a,b,c,e=r[i-1],r[i],r[j],r[j+1]
                        delta=d[a][c]+d[b][e]-d[a][b]-d[c][e]
                        if delta<0:
                            before=cost(r,d);r[i:j+1]=reversed(r[i:j+1])
                            assert cost(r,d)==before+delta
                            moves.append({'candidate':used,'i':i,'j':j,'delta':delta})
                            improved=True;break
                    if improved or exhausted: break
                if exhausted: break
                if not improved:
                    status='LOCAL_OPTIMUM';break
        result.append({'slot':slot,'route':r,'cost':cost(r,d),'status':status,
                       'candidate_count':used-start_used,'accepted_moves':moves})
    return {'routes':result,'candidate_count':used,'budget':budget}

def held_karp(route,d):
    """All subset-endpoint states, ascending node IDs and masks; exact integer arithmetic."""
    nodes=sorted(route[1:-1]);n=len(nodes)
    assert len(nodes)==len(set(nodes)) and 0 not in nodes and n<=12
    if n==0:
        return {'route':[0,0],'cost':0,'nodes':nodes,'states':[], 'state_count':0,'transition_count':0,'terminal':None}
    dp={};parent={};states=[];transitions=0
    for mask in range(1,1<<n):
        for j in range(n):
            if not mask>>j&1:continue
            previous=mask^(1<<j)
            if previous==0:
                best=d[0][nodes[j]];pred=-1
            else:
                best=None;pred=None
                for k in range(n):
                    if previous>>k&1:
                        transitions+=1
                        value=dp[previous,k]+d[nodes[k]][nodes[j]]
                        if best is None or value<best:
                            best=value;pred=k
            dp[mask,j]=best;parent[mask,j]=pred;states.append([mask,j,best,pred])
    full=(1<<n)-1
    total,terminal=min((dp[full,j]+d[nodes[j]][0],j) for j in range(n))
    order=[];mask=full;j=terminal
    while mask:
        order.append(nodes[j]);prev=parent[mask,j];mask^=1<<j;j=prev
    result=[0]+list(reversed(order))+[0]
    assert cost(result,d)==total and sorted(result[1:-1])==nodes
    return {'route':result,'cost':total,'nodes':nodes,'states':states,'state_count':len(states),
            'transition_count':transitions,'terminal':terminal}
