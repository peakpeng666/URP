import pathlib,json,hashlib,shutil,datetime
from independent_check import independent_matrix,check_routes
ROOT=pathlib.Path(__file__).resolve().parents[1]
S=pathlib.Path('/workspace/shared/public_route_quality_rescoring_20261008')
O=pathlib.Path('/workspace/shared/public_capacity_benchmark_execution_20261008_r1')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,d):p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
def main():
    assert not (ROOT/'raw/STARTED.json').exists()
    files=[]
    def copy(a,b):
        b=ROOT/b;b.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(a,b)
        files.append({'source':str(a),'snapshot':str(b.relative_to(ROOT)),'sha256':sha(b),'bytes':b.stat().st_size})
    for rel in ['raw/results.jsonl','freeze/SCHEDULE.json']:
        copy(O/rel,'inputs/original/'+pathlib.Path(rel).name)
    for rel in ['raw/scores.jsonl','raw/reference_checks.jsonl','independent_review/INDEPENDENT_REVIEW.json','reports/SUMMARY.json']:
        copy(S/rel,'inputs/original/'+pathlib.Path(rel).name)
    original=[json.loads(x) for x in (O/'raw/results.jsonl').read_text().splitlines()]
    scores=[json.loads(x) for x in (S/'raw/scores.jsonl').read_text().splitlines()]
    refs={x['instance_id']:x for x in map(json.loads,(S/'raw/reference_checks.jsonl').read_text().splitlines())}
    review=json.loads((S/'independent_review/INDEPENDENT_REVIEW.json').read_text());assert review['status']=='PASS_WITH_INFERENCE_LIMITATIONS'
    tasks=[]
    for score in sorted((s for s in scores if s['arm']=='capacity_solver'),key=lambda x:x['selection_slot']):
        name=score['instance_id'];arms=[r for r in original if r['instance_id']==name and r['endpoint']=='initialize_256']
        assert len(arms)==3 and {r['arm'] for r in arms}=={'capacity_solver','waste_solver','pruned_solver'}
        assert all(r['status']=='SUCCESS' and r['output']==arms[0]['output'] for r in arms)
        original_routes=arms[0]['output']['routes'];assert original_routes==[r['normalized_order'] for r in score['routes']]
        for a,b in [(O/'input'/f'{name}.json',f'inputs/instances/{name}.json'),
                    (S/'inputs/preparation/raw/instances'/f'{name}.vrp',f'inputs/instances/{name}.vrp'),
                    (S/'inputs/preparation/raw/solutions'/f'{name}.sol',f'inputs/references/{name}.sol')]:copy(a,b)
        data=json.loads((O/'input'/f'{name}.json').read_text());d,dem,q,coords=independent_matrix(ROOT/'inputs/instances'/f'{name}.vrp')
        assert data['demands']==dem and data['capacity']==q
        assert data['coordinates']==[[float(x),float(y)] for k,(x,y) in sorted(coords.items())]
        baseline=check_routes(original_routes,d,dem,q,data['K']);assert baseline['cost']==score['integer_cost']
        rr=[r['normalized_order'] for r in refs[name]['routes']]
        ref=check_routes(rr,d,dem,q,data['K']);assert ref['cost']==refs[name]['integer_cost']
        lengths=[len(r)-2 for r in original_routes]
        tasks.append({'selection_slot':score['selection_slot'],'instance_id':name,'K':data['K'],'baseline_routes':original_routes,
                      'original_initialize_call_ids':[r['call_id'] for r in arms],'three_saved_outputs_equal':True,
                      'baseline_integer_cost':score['integer_cost'],'reference_integer_cost':ref['cost'],
                      'reference_routes':rr,'reference_url':refs[name]['solution_url'],'instance_url':refs[name]['instance_url'],
                      'route_customer_counts':lengths,'eligible_exact_route_slots':[j+1 for j,n in enumerate(lengths) if n<=12],
                      'all_routes_size_eligible':all(n<=12 for n in lengths)})
    assert len(tasks)==16
    write(ROOT/'inputs/TASKS.json',tasks)
    write(ROOT/'freeze/INPUT_MANIFEST.json',{'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':files})
    old=[]
    for base in [O,S]:
        for p in sorted(base.rglob('*')):
            if p.is_file():old.append({'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size})
    write(ROOT/'freeze/OLD_TREES_BEFORE.json',old)
    sizes=[n for t in tasks for n in t['route_customer_counts']]
    write(ROOT/'freeze/INPUT_SCALE.json',{'tasks':len(tasks),'routes':len(sizes),'eligible_routes':sum(n<=12 for n in sizes),
      'ineligible_routes':sum(n>12 for n in sizes),'max_route_customers':max(sizes),'fully_size_eligible_instances':sum(t['all_routes_size_eligible'] for t in tasks),
      'eligible_DP_states':sum(n*2**(n-1) if n else 0 for n in sizes if n<=12),
      'eligible_DP_transitions':sum(n*(n-1)*2**(n-2) if n>1 else 0 for n in sizes if n<=12)})
if __name__=='__main__':main()
