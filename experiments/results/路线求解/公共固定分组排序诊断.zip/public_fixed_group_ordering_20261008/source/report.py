import pathlib,json,csv,hashlib,statistics,datetime
ROOT=pathlib.Path(__file__).resolve().parents[1]
def write(p,d):p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    receipt=json.loads((ROOT/'provenance/RAW_UNREVIEWED_DRIVE_RECEIPT.json').read_text())
    assert receipt.get('owner_only') is True and receipt.get('remote_readback_sha256_verified') is True
    raw_manifest=json.loads((ROOT/'raw/RAW_UNREVIEWED_MANIFEST.json').read_text())
    assert all(sha(ROOT/p)==h['sha256'] for p,h in raw_manifest['files'].items())
    tasks=json.loads((ROOT/'inputs/TASKS.json').read_text())
    raw={r['instance_id']:r for r in map(json.loads,(ROOT/'raw/results.jsonl').read_text().splitlines())}
    rows=[];route_rows=[]
    for task in tasks:
        name=task['instance_id'];r=raw.get(name,{});B=task['baseline_integer_cost'];R=task['reference_integer_cost']
        O=r['two_opt']['independent_check']['cost'] if r.get('two_opt') and r['two_opt']['accepted'] else None
        E=r.get('fixed_group_exact_cost') if r.get('fixed_group_exact_qualified') else None
        rows.append({'instance_id':name,'K':task['K'],'status':r.get('status','MISSING_UNDETERMINED'),
          'baseline_integer_cost':B,'two_opt_integer_cost':O,'reference_integer_cost':R,'baseline_gap_percent':100*(B-R)/R,
          'two_opt_gap_percent':100*(O-R)/R if O is not None else None,'two_opt_cost_reduction':B-O if O is not None else None,
          'two_opt_gap_reduction_percentage_points':100*(B-O)/R if O is not None else None,
          'two_opt_candidates':r['two_opt']['result']['candidate_count'] if O is not None else None,
          'exact_route_successes':sum(x['exact_status']=='SUCCESS_CERTIFIED' for x in r.get('routes',[])),
          'route_count':task['K'],'fixed_group_exact_qualified':E is not None,'fixed_group_exact_cost':E,
          'exact_ordering_improvement':B-E if E is not None else None,'exact_gap_percent':100*(E-R)/R if E is not None else None,
          'exact_residual_above_reference':E-R if E is not None else None,
          'attribution':'Certified fixed-group minimum exceeds this public reference; ordering alone cannot reach that reference.' if E is not None and E>R else
            ('Certified fixed-group minimum reaches or improves this reference; no global optimality claim.' if E is not None else
             'Fixed-group optimum not established; remaining gap cannot be assigned wholly to grouping.')})
        for rr in r.get('routes',[]):
            slot=rr['slot'];o=r['two_opt']['result']['routes'][slot-1] if O is not None else None
            route_rows.append({'instance_id':name,'slot':slot,'customers':rr['customer_count'],'baseline_load':rr.get('baseline_load'),
              'baseline_cost':rr.get('baseline_cost'),'two_opt_cost':o['cost'] if o else None,'two_opt_status':o['status'] if o else None,
              'two_opt_candidate_count':o['candidate_count'] if o else None,'exact_status':rr['exact_status'],'exact_cost':rr.get('exact_cost'),
              'exact_evidence':rr.get('DP_proof_file'),'DP_proof_sha256':rr.get('DP_proof_sha256')})
    for name,records in [('PER_INSTANCE.csv',rows),('PER_ROUTE.csv',route_rows)]:
        with (ROOT/'reports'/name).open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
    valid=[r for r in rows if r['two_opt_integer_cost']is not None];exact=[r for r in rows if r['fixed_group_exact_qualified']]
    summary={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stage':'NEW_FIXED_GROUP_ORDERING_DIAGNOSTIC',
      'independent_review_status':'PENDING','tasks_retained':16,'coordinate_demand_bases':14,'baseline_sets':1,'route_count':len(route_rows),
      'two_opt_valid_tasks':len(valid),'two_opt_failure_or_undetermined_tasks':16-len(valid),
      'baseline_mean_reference_gap_percent':statistics.mean(r['baseline_gap_percent'] for r in rows),
      'two_opt_mean_reference_gap_percent_all16':statistics.mean(r['two_opt_gap_percent'] for r in valid) if len(valid)==16 else None,
      'mean_gap_reduction_percentage_points_all16':statistics.mean(r['two_opt_gap_reduction_percentage_points'] for r in valid) if len(valid)==16 else None,
      'baseline_cost_sum':sum(r['baseline_integer_cost'] for r in rows),'two_opt_cost_sum_all16':sum(r['two_opt_integer_cost'] for r in valid) if len(valid)==16 else None,
      'reference_cost_sum':sum(r['reference_integer_cost'] for r in rows),
      'improved_two_opt_instances':sum(r['two_opt_cost_reduction']>0 for r in valid),'unchanged_two_opt_instances':sum(r['two_opt_cost_reduction']==0 for r in valid),
      'exact_success_routes':sum(r['exact_status']=='SUCCESS_CERTIFIED' for r in route_rows),'ineligible_over12_routes':sum(r['exact_status']=='INELIGIBLE_OVER_12' for r in route_rows),
      'exact_failure_or_unattempted_routes':[r for r in route_rows if r['exact_status'] not in ('SUCCESS_CERTIFIED','INELIGIBLE_OVER_12')],
      'whole_instance_fixed_group_exact_qualified':len(exact),'exact_qualified_instance_ids':[r['instance_id'] for r in exact],
      'per_instance':rows,'below_reference_instances':[r['instance_id'] for r in rows if (r['two_opt_integer_cost']is not None and r['two_opt_integer_cost']<r['reference_integer_cost']) or (r['fixed_group_exact_cost']is not None and r['fixed_group_exact_cost']<r['reference_integer_cost'])],
      'limitations':['Post-hoc diagnostic on same16 fixed-K tasks, 14 coordinate-demand bases, not original capacity endpoint or a new independent dataset.',
      'Single baseline because all three original arm outputs are identical. No arm comparison or significance claim.',
      '2-opt demonstrated realizable order-only gains. Its remaining gap is not a grouping certificate.',
      'Exact full-instance attribution requires every route to be size-eligible and certified. No hybrid exact total for incomplete tasks.',
      'Public reference is verified feasible, not established here as a global optimum certificate.',
      'No speed comparison; CPU figures are resource audit only and timing quantization is known.']}
    freeze=json.loads((ROOT/'freeze/FROZEN_FILES.json').read_text())
    summary['frozen_files_unchanged']=all(sha(ROOT/p)==v['sha256'] for p,v in freeze['files'].items())
    old=json.loads((ROOT/'freeze/OLD_TREES_BEFORE.json').read_text());changed=[r['path'] for r in old if not pathlib.Path(r['path']).is_file() or sha(pathlib.Path(r['path']))!=r['sha256']]
    summary['old_existing_file_count']=len(old);summary['old_existing_files_unchanged']=not changed;summary['old_existing_changed_files']=changed
    write(ROOT/'reports/SUMMARY.json',summary)
    lines=['固定客户分组下的访问顺序诊断（新阶段，独审待定）','',
      '全部16固定K任务保留，来自14个坐标/需求底本。只使用一套原三臂完全一致的初始化baseline。',
      '标准成本逐边floor(hypot+.5)，独立用原.vrp的80位Decimal平方根ROUND_HALF_UP逐边重算。depot、分组、载荷和K均固定。',
      '2-opt：原route顺序，组内(i,j)字典序首改进并重启，所有route共用每实例10000候选硬上限。',
      'Held–Karp：仅≤12客户route，每route正式一次，完整DP表与路径保存；不合格和失败保留。完整实例最优必须所有route成功。','',
      f"2-opt有效 {len(valid)}/16；改善 {summary['improved_two_opt_instances']}，不变 {summary['unchanged_two_opt_instances']}。",
      f"全16 baseline平均reference gap：{summary['baseline_mean_reference_gap_percent']:.6f}%。",
      f"全16 2-opt平均reference gap：{summary['two_opt_mean_reference_gap_percent_all16']}%；平均缩小{summary['mean_gap_reduction_percentage_points_all16']}个百分点。",
      f"精确route成功 {summary['exact_success_routes']}；超过12客户未求精确 {summary['ineligible_over12_routes']}；全组精确资格 {len(exact)}/16。",'','逐实例：实例 | baseline | 2-opt | public ref | baseline gap% | 2-opt gap% | 固定分组精确成本（无资格记未定） | 精确到ref剩余成本']
    for r in rows:lines.append(f"{r['instance_id']} | {r['baseline_integer_cost']} | {r['two_opt_integer_cost']} | {r['reference_integer_cost']} | {r['baseline_gap_percent']:.6f} | {r['two_opt_gap_percent']} | {r['fixed_group_exact_cost'] if r['fixed_group_exact_qualified'] else '未定'} | {r['exact_residual_above_reference']}")
    lines+=['','解释边界：','- 2-opt改善是实证可实现的组内排序贡献；没有全组精确资格时，其剩余差不能全部归因分组。',
      '- 仅全组精确实例可分解baseline-ref=(baseline-固定组最优)+(固定组最优-ref)。后一项>0只证明保持当前分组无法达到该参考，不是全局最优证书。',
      '- 未求精确的14条route仍保留在完整16任务的2-opt统计；不拿可精确6任务冒充全样本。',
      '- 原公开ref仅作为已验证可行参考；不声称本研究证明其全局最优。没有新数据集、原容量主终点、显著性或速度优势claim。',
      f"- 旧目录当前已有{len(old)}文件哈希保持：{not changed}。",'- raw已先按未审结果私有保存并远端回读。独立审计结论须另行确认。']
    (ROOT/'reports/REPORT_ZH.txt').write_text('\n'.join(lines)+'\n')
if __name__=='__main__':main()
