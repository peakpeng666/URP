"""Single-use, bounded sequential process supervisor. Never imports optimization functions."""
import pathlib,json,hashlib,subprocess,resource,datetime,time,signal,sys,os,traceback
from independent_check import independent_matrix,check_routes,check_certificate
ROOT=pathlib.Path(__file__).resolve().parents[1]
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,d):
    with p.open('w') as f:json.dump(d,f,ensure_ascii=False,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
def append(p,d):
    with p.open('a') as f:f.write(json.dumps(d,separators=(',',':'))+'\n');f.flush();os.fsync(f.fileno())
def call(call_id,payload):
    append(ROOT/'raw/attempts.jsonl',{'call_id':call_id,'phase':'STARTED','kind':payload['kind'],'utc':now()})
    out=ROOT/'raw/oracle_calls'/f'{call_id}.stdout';err=ROOT/'raw/oracle_calls'/f'{call_id}.stderr'
    start=time.monotonic();cpu=resource.getrusage(resource.RUSAGE_CHILDREN);before=cpu.ru_utime+cpu.ru_stime
    status='SUCCESS';code=None
    with out.open('xb') as fo,err.open('xb') as fe:
        p=subprocess.Popen([sys.executable,'-B',str(ROOT/'source/worker.py')],stdin=subprocess.PIPE,stdout=fo,stderr=fe,
                           env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
        try:p.communicate(json.dumps(payload).encode(),timeout=2)
        except subprocess.TimeoutExpired:
            p.kill();p.communicate();status='WALL_TIMEOUT'
        code=p.returncode
        if code and status=='SUCCESS':status='PROCESS_FAILURE_OR_CPU_LIMIT'
    cpu=resource.getrusage(resource.RUSAGE_CHILDREN)
    meta={'call_id':call_id,'status':status,'returncode':code,'cpu_seconds_for_audit_only':cpu.ru_utime+cpu.ru_stime-before,
      'wall_seconds_for_audit_only':time.monotonic()-start,'stdout_sha256':sha(out),'stderr_sha256':sha(err),
      'stdout':str(out.relative_to(ROOT)),'stderr':str(err.relative_to(ROOT))}
    result=None
    if status=='SUCCESS':
        try:result=json.loads(out.read_text())
        except Exception as e:meta['status']='INVALID_OUTPUT';meta['error']=str(e)
    append(ROOT/'raw/attempts.jsonl',{'phase':'FINISHED','utc':now(),**meta})
    return result,meta

def main():
    # Exactly 117 possible subprocess calls: 16 two-opt +101 eligible exact routes.
    # Parent hard3 CPU seconds +each child hard1 =>aggregate authorized CPU <=120 seconds.
    resource.setrlimit(resource.RLIMIT_CPU,(3,3));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
    signal.alarm(240)
    t0=time.monotonic();cpu0=time.process_time()
    receipt=json.loads((ROOT/'provenance/PREEXEC_DRIVE_RECEIPT.json').read_text())
    assert receipt.get('owner_only') is True and receipt.get('remote_readback_sha256_verified') is True
    assert receipt['frozen_files_sha256']==sha(ROOT/'freeze/FROZEN_FILES.json')
    assert json.loads((ROOT/'inputs/original/INDEPENDENT_REVIEW.json').read_text())['status']=='PASS_WITH_INFERENCE_LIMITATIONS'
    manifest=json.loads((ROOT/'freeze/FROZEN_FILES.json').read_text())
    assert all(sha(ROOT/p)==h['sha256'] for p,h in manifest['files'].items())
    tasks=json.loads((ROOT/'inputs/TASKS.json').read_text());assert len(tasks)==16
    assert sum(len(t['eligible_exact_route_slots']) for t in tasks)==101
    with (ROOT/'raw/STARTED.json').open('x') as f:json.dump({'utc':now(),'phase':'NEW_FIXED_GROUP_ORDERING_DIAGNOSTIC','no_reruns':True,'frozen_manifest_sha256':sha(ROOT/'freeze/FROZEN_FILES.json')},f)
    complete=0
    for task in tasks:
        name=task['instance_id'];idx=task['selection_slot'];base=task['baseline_routes']
        item={'instance_id':name,'selection_slot':idx,'retained':True,'baseline_routes':base,'reference_integer_cost':task['reference_integer_cost'],
              'all_routes_size_eligible':task['all_routes_size_eligible'],'two_opt':None,'routes':[],'fixed_group_exact_cost':None,'fixed_group_exact_qualified':False}
        try:
            data=json.loads((ROOT/'inputs/instances'/f'{name}.json').read_text());d,dem,q,coords=independent_matrix(ROOT/'inputs/instances'/f'{name}.vrp')
            bcheck=check_routes(base,d,dem,q,task['K'],base);item['baseline_check']=bcheck;assert bcheck['cost']==task['baseline_integer_cost']
            item['reference_check']=check_routes(task['reference_routes'],d,dem,q,task['K']);assert item['reference_check']['cost']==task['reference_integer_cost']
            result,meta=call(f'T{idx:02d}_2OPT',{'kind':'two_opt','coordinates':data['coordinates'],'routes':base})
            if result is not None:
                try:
                    routes=[r['route'] for r in result['routes']];checked=check_routes(routes,d,dem,q,task['K'],base)
                    assert len(result['routes'])==task['K'] and 0<=result['candidate_count']<=10000
                    assert sum(r['candidate_count'] for r in result['routes'])==result['candidate_count']
                    for old,r,ch in zip(base,result['routes'],checked['routes']):
                        replay=old[:];prev_candidate=0
                        for move in r['accepted_moves']:
                            i,j=move['i'],move['j'];assert 1<=i<j<=len(old)-2 and move['delta']<0
                            oldcost=sum(d[a][b] for a,b in zip(replay,replay[1:]));replay[i:j+1]=reversed(replay[i:j+1])
                            assert sum(d[a][b] for a,b in zip(replay,replay[1:]))==oldcost+move['delta']
                        assert replay==r['route'] and ch['cost']==r['cost']
                    assert checked['cost']<=bcheck['cost'];item['two_opt']={'accepted':True,'result':result,'independent_check':checked,'call':meta}
                except Exception as e:item['two_opt']={'accepted':False,'status':'INDEPENDENT_CHECK_FAILED','error':str(e),'call':meta}
            else:item['two_opt']={'accepted':False,'status':meta['status'],'call':meta}
            for slot,r in enumerate(base,1):
                row={'slot':slot,'customer_count':len(r)-2,'baseline_route':r,'baseline_cost':bcheck['routes'][slot-1]['cost'],
                     'baseline_load':bcheck['routes'][slot-1]['load'],'exact_status':'INELIGIBLE_OVER_12','exact_cost':None,'exact_route':None}
                if len(r)-2<=12:
                    proof,meta=call(f'T{idx:02d}_R{slot:02d}_HK',{'kind':'held_karp','coordinates':data['coordinates'],'route':r})
                    row['call']=meta
                    if proof is not None:
                        try:
                            certificate=check_certificate(proof,r,d);assert proof['cost']<=row['baseline_cost']
                            row.update({'exact_status':'SUCCESS_CERTIFIED','exact_cost':proof['cost'],'exact_route':proof['route'],
                                        'certificate_check':certificate,'DP_proof_file':meta['stdout'],'DP_proof_sha256':meta['stdout_sha256']})
                        except Exception as e:row.update({'exact_status':'CERTIFICATE_FAILED','error':str(e)})
                    else:row['exact_status']=meta['status']
                item['routes'].append(row)
            if len(item['routes'])==task['K'] and all(r['exact_status']=='SUCCESS_CERTIFIED' for r in item['routes']):
                exact=check_routes([r['exact_route'] for r in item['routes']],d,dem,q,task['K'],base)
                item['fixed_group_exact_qualified']=True;item['fixed_group_exact_cost']=exact['cost'];item['exact_independent_check']=exact
            item['status']='COMPLETE_WITH_DECLARED_ELIGIBILITY' if all(r['exact_status'] in ('SUCCESS_CERTIFIED','INELIGIBLE_OVER_12') for r in item['routes']) and item['two_opt']['accepted'] else 'COMPLETE_WITH_FAILURES'
        except Exception as e:
            item['status']='TASK_ERROR_UNDETERMINED';item['error']=str(e);item['traceback']=traceback.format_exc()
            # No resume or retry: preserve every remaining planned route as unattempted.
            present={r['slot'] for r in item['routes']}
            for slot,r in enumerate(base,1):
                if slot not in present:item['routes'].append({'slot':slot,'customer_count':len(r)-2,'exact_status':'UNATTEMPTED_TASK_ERROR','exact_cost':None})
        append(ROOT/'raw/results.jsonl',item);complete+=1
    signal.alarm(0);children=resource.getrusage(resource.RUSAGE_CHILDREN)
    write(ROOT/'raw/FINISHED.json',{'utc':now(),'retained_tasks':complete,'status':'FINISHED','supervisor_cpu_seconds_for_audit_only':time.process_time()-cpu0,
      'children_cpu_seconds_for_audit_only':children.ru_utime+children.ru_stime,'wall_seconds_for_audit_only':time.monotonic()-t0,
      'supervisor_maxrss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'children_maxrss_KiB':children.ru_maxrss,
      'cpu_hard_budget_design':'parent3s +117child*1s <=120s','wall_hard_limit_seconds':240,'max_concurrent_children':1,
      'address_space_hard_limits_MiB':{'parent':512,'child':256,'combined_max':768}})
    raw={str(p.relative_to(ROOT)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted((ROOT/'raw').rglob('*')) if p.is_file()}
    write(ROOT/'raw/RAW_UNREVIEWED_MANIFEST.json',{'utc':now(),'status':'UNREVIEWED_RAW','files':raw})
if __name__=='__main__':main()
