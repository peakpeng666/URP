"""Independent raw-VRP Decimal scorer and certificate verifier; does not import engine."""
from decimal import Decimal,localcontext,ROUND_HALF_UP
from collections import Counter

def parse_vrp(path):
    section=None;coords={};demand={};header={};depots=[]
    for raw in path.read_text().splitlines():
        line=raw.strip()
        if not line:continue
        if line in ('NODE_COORD_SECTION','DEMAND_SECTION','DEPOT_SECTION'):
            section=line;continue
        if line=='EOF':break
        if section=='NODE_COORD_SECTION':
            a,x,y=line.split();coords[int(a)]=(Decimal(x),Decimal(y))
        elif section=='DEMAND_SECTION':
            a,b=line.split();demand[int(a)]=int(b)
        elif section=='DEPOT_SECTION':
            if int(line)!=-1:depots.append(int(line))
        else:
            a,b=line.split(':',1);header[a.strip()]=b.strip()
    assert header['EDGE_WEIGHT_TYPE']=='EUC_2D' and depots==[1]
    assert set(coords)==set(range(1,int(header['DIMENSION'])+1))==set(demand)
    return coords,demand,int(header['CAPACITY'])

def independent_matrix(path):
    coords,demand,q=parse_vrp(path);d=[]
    with localcontext() as c:
        c.prec=80
        for a in range(1,len(coords)+1):
            row=[]
            for b in range(1,len(coords)+1):
                x=coords[a][0]-coords[b][0];y=coords[a][1]-coords[b][1]
                row.append(int((x*x+y*y).sqrt().quantize(Decimal(1),rounding=ROUND_HALF_UP)))
            d.append(row)
    return d,[demand[i] for i in range(1,len(coords)+1)],q,coords

def check_routes(routes,d,demands,q,K,baseline=None):
    assert len(routes)==K
    seen=[];records=[]
    for slot,r in enumerate(routes):
        assert isinstance(r,list) and len(r)>=2 and r[0]==r[-1]==0
        assert all(type(x)is int and 1<=x<len(d) for x in r[1:-1])
        if baseline is not None: assert Counter(r[1:-1])==Counter(baseline[slot][1:-1])
        load=sum(demands[x] for x in r[1:-1]);assert load<=q
        edges=[{'from':a,'to':b,'integer_cost':d[a][b]} for a,b in zip(r,r[1:])]
        records.append({'slot':slot+1,'load':load,'customer_count':len(r)-2,'cost':sum(x['integer_cost'] for x in edges),'edges':edges})
        seen+=r[1:-1]
    assert Counter(seen)==Counter(range(1,len(d)))
    return {'accepted':True,'cost':sum(r['cost'] for r in records),'routes':records,
            'closure':True,'coverage_exact_once':True,'K_slots_preserved':True,'capacity_valid':True,
            'fixed_groups_preserved':baseline is not None}

def check_certificate(proof,baseline,d):
    """Check supplied complete DP table recurrence; never call Held-Karp/optimization."""
    nodes=proof['nodes'];n=len(nodes)
    assert nodes==sorted(baseline[1:-1]) and len(nodes)==len(set(nodes)) and n<=12
    assert proof['route'][0]==proof['route'][-1]==0 and sorted(proof['route'][1:-1])==nodes
    assert proof['cost']==sum(d[a][b] for a,b in zip(proof['route'],proof['route'][1:]))
    if not n:
        assert proof['states']==[] and proof['cost']==0
        return {'accepted':True,'states_verified':0,'recurrence_verified':True}
    table={(m,j):(c,p) for m,j,c,p in proof['states']}
    expected={(m,j) for m in range(1,1<<n) for j in range(n) if m&(1<<j)}
    assert set(table)==expected and len(table)==len(proof['states'])==proof['state_count']==n*2**(n-1)
    transitions=0
    for m,j in sorted(expected):
        c,p=table[m,j];assert type(c)is int and type(p)is int
        prev=m^(1<<j)
        if not prev:
            assert (c,p)==(d[0][nodes[j]],-1)
        else:
            options=[(table[prev,k][0]+d[nodes[k]][nodes[j]],k) for k in range(n) if prev&(1<<k)]
            transitions+=len(options);assert (c,p)==min(options)
    assert transitions==proof['transition_count']==(n*(n-1)*2**(n-2) if n>=2 else 0)
    assert (proof['cost'],proof['terminal'])==min((table[(1<<n)-1,j][0]+d[nodes[j]][0],j) for j in range(n))
    mask=(1<<n)-1;j=proof['terminal'];reverse=[]
    while mask:
        reverse.append(nodes[j]);p=table[mask,j][1];mask^=1<<j;j=p
    assert proof['route']==[0]+list(reversed(reverse))+[0]
    return {'accepted':True,'states_verified':len(table),'recurrence_verified':True,'terminal_minimum_verified':True}
