import itertools,json,hashlib,math
from engine import matrix,cost,two_opt,held_karp
from independent_check import check_certificate

def main():
    fixtures=[[(0,0)],[(0,0),(3,4)],[(0,0),(2,0),(0,2)],
      [(0,0),(4,4),(0,4),(4,0)],[(0,0),(0.5,0),(1.5,0),(0,0)],
      [(0,0),(1,7),(4,2),(-2,3),(8,-1),(0,6),(-3,-3)],
      [(0,0),(2,9),(-3,5),(7,1),(5,8),(0,-4),(9,-2),(4,4)],
      [(0,0),(5,8),(1,-2),(3,7),(9,0),(-3,2),(6,6),(-5,-4),(2,3)]]
    out=[]
    for num,coords in enumerate(fixtures):
        d=matrix(coords);r=[0]+list(range(1,len(coords)))+[0]
        p=held_karp(r,d);verified=check_certificate(p,r,d)
        brute=min(cost([0]+list(x)+[0],d) for x in itertools.permutations(r[1:-1]))
        assert p['cost']==brute
        opt=two_opt([r],d,10000);rr=opt['routes'][0]['route']
        assert sorted(rr[1:-1])==sorted(r[1:-1]) and rr[0]==rr[-1]==0
        assert type(opt['routes'][0]['cost'])is int and brute<=cost(rr,d)<=cost(r,d)
        assert opt['candidate_count']<=10000
        if opt['routes'][0]['status']=='LOCAL_OPTIMUM':
            for i in range(1,len(rr)-2):
                for j in range(i+1,len(rr)-1):
                    swapped=rr[:i]+list(reversed(rr[i:j+1]))+rr[j+1:]
                    assert cost(swapped,d)>=cost(rr,d)
        assert two_opt([r],d,10000)==opt
        out.append({'fixture':num,'customers':len(r)-2,'bruteforce_cost':brute,'two_opt_cost':cost(rr,d),'certificate':verified})
    assert matrix([(0,0),(0.5,0),(1.5,0)])[0]==[0,1,2]
    d=matrix([(0,0),(4,4),(0,4),(4,0)]);r=[0,1,2,3,0]
    zero=two_opt([r],d,0);assert zero['candidate_count']==0 and zero['routes'][0]['route']==r
    one=two_opt([r,[0,0]],d,1);assert one['candidate_count']==1 and one['routes'][1]['route']==[0,0]
    broken=held_karp(r,d);broken['states'][0][2]+=1
    try:check_certificate(broken,r,d)
    except AssertionError:pass
    else:raise AssertionError('corrupt DP table accepted')
    print(json.dumps({'status':'PASS','scope':'invented fixtures only, no benchmark optimization','fixtures':out,
        'additional_tests':['half-up rounding','zero budget','shared one-candidate cap','empty route','determinism','corrupted DP rejected']},indent=2))
if __name__=='__main__':main()
