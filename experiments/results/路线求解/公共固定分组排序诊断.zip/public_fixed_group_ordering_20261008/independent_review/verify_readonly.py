"""Independent read-only evidence audit; no author imports and no solver/oracle calls.
2-opt only checks the supplied accepted trace and non-improving skipped/final scans.
DP only checks supplied table values/parents against each allowed transition.
"""
from pathlib import Path
from fractions import Fraction
from collections import Counter
from datetime import datetime, timezone
import math, json, hashlib, zipfile, statistics, csv, copy
ROOT=Path('/workspace/shared/public_fixed_group_ordering_20261008')
OUT=Path('/workspace/shared/public_fixed_group_ordering_review_20261008')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(rel): return json.loads((ROOT/rel).read_text())
def lines(rel): return [json.loads(s) for s in (ROOT/rel).read_text().splitlines()]
def demand(condition, message):
    if not condition: raise AssertionError(message)
def same(a,b,label): demand(a==b,f'{label}: {a!r} != {b!r}')
def dump(path,value): path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
def snapshot(base): return {str(p.relative_to(base)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(base.rglob('*')) if p.is_file()}
before=snapshot(ROOT)

def parse_vrp(name):
    header={}; coords={}; weights={}; depots=[]; section=None
    for line in (ROOT/'inputs/instances'/f'{name}.vrp').read_text().splitlines():
        line=line.strip()
        if not line: continue
        if line=='EOF': break
        if line.endswith('_SECTION'): section=line; continue
        if section is None:
            k,v=line.split(':',1); header[k.strip()]=v.strip()
        elif section=='NODE_COORD_SECTION':
            k,x,y=line.split(); demand(int(k) not in coords,'duplicate coordinate'); coords[int(k)]=(Fraction(x),Fraction(y))
        elif section=='DEMAND_SECTION':
            k,q=line.split(); demand(int(k) not in weights,'duplicate demand'); weights[int(k)]=int(q)
        elif section=='DEPOT_SECTION':
            if int(line)!=-1: depots.append(int(line))
    n=int(header['DIMENSION']); same(header['EDGE_WEIGHT_TYPE'],'EUC_2D','metric'); same(header['TYPE'],'CVRP','type')
    same(sorted(coords),list(range(1,n+1)),'raw coordinates'); same(sorted(weights),list(range(1,n+1)),'raw demands'); same(depots,[1],'depot')
    q=int(header['CAPACITY']); xy=[coords[i] for i in range(1,n+1)]; dem=[weights[i] for i in range(1,n+1)]
    same(dem[0],0,'depot demand'); demand(all(x>0 for x in dem[1:]),'positive demands')
    # Exact algebraic EUC_2D rounding, no floating or Decimal sqrt.
    scale=math.lcm(*(v.denominator for p in xy for v in p))
    zz=[(int(x*scale),int(y*scale)) for x,y in xy]; dist=[]
    for x,y in zz:
        row=[]
        for u,v in zz:
            sq=(x-u)**2+(y-v)**2; floor=math.isqrt(sq)//scale
            row.append(floor+int(4*sq >= ((2*floor+1)*scale)**2))
        dist.append(row)
    normalized=read(f'inputs/instances/{name}.json')
    same(normalized['demands'],dem,'normalized demand mapping'); same(normalized['capacity'],q,'capacity mapping')
    same([[Fraction(str(v)) for v in p] for p in normalized['coordinates']],[list(p) for p in xy],'coordinate mapping c to raw c+1')
    float_dist=[[math.floor(math.hypot(x-u,y-v)+.5) for u,v in normalized['coordinates']] for x,y in normalized['coordinates']]
    same(dist,float_dist,'entire author float matrix versus exact integer algebra')
    return dist,dem,q,xy,normalized['K']

def cost(route,d): return sum(d[a][b] for a,b in zip(route,route[1:]))
def routes_check(routes,d,dem,q,K,groups=None):
    same(len(routes),K,'K preserved'); seen=[]; out=[]
    for i,r in enumerate(routes):
        demand(len(r)>=2 and r[0]==r[-1]==0,'depot closure')
        demand(all(type(c) is int and 0<c<len(d) for c in r[1:-1]),'customer IDs')
        if groups is not None: same(Counter(r[1:-1]),Counter(groups[i][1:-1]),'same group in same slot')
        load=sum(dem[c] for c in r[1:-1]); demand(load<=q,'capacity feasible'); seen.extend(r[1:-1])
        out.append({'slot':i+1,'customers':len(r)-2,'load':load,'cost':cost(r,d)})
    same(Counter(seen),Counter(range(1,len(d))),'all customers exactly once')
    return out

def certify_dp(proof,route,d):
    nodes=sorted(route[1:-1]); n=len(nodes); same(proof['nodes'],nodes,'DP group'); demand(n<=12,'DP eligibility')
    states=proof['states']; table={}
    for row in states:
        demand(len(row)==4 and all(type(v) is int for v in row),'state row integers')
        m,j,c,p=row; demand((m,j) not in table,'duplicate state'); table[m,j]=(c,p)
    expected={(m,j) for m in range(1,1<<n) for j in range(n) if (m>>j)&1}
    same(set(table),expected,'complete DP state domain'); same(len(table),proof['state_count'],'state count')
    transitions=0
    for m,j in expected:
        c,parent=table[m,j]; rest=m^(1<<j)
        if not rest: same((c,parent),(d[0][nodes[j]],-1),'singleton')
        else:
            demand(parent>=0 and ((rest>>parent)&1),'predecessor membership')
            same(c,table[rest,parent][0]+d[nodes[parent]][nodes[j]],'chosen predecessor realizes state')
            for k in range(n):
                if not ((rest>>k)&1): continue
                candidate=table[rest,k][0]+d[nodes[k]][nodes[j]]; transitions+=1
                demand(c<=candidate,'Bellman lower bound for every predecessor')
                if c==candidate: demand(parent<=k,'lowest predecessor tie rule')
    same(transitions,proof['transition_count'],'transitions')
    same(len(table),n*2**(n-1) if n else 0,'combinatorial state count')
    same(transitions,n*(n-1)*2**(n-2) if n>=2 else 0,'combinatorial transitions')
    if n:
        end=proof['terminal']; demand(type(end) is int and 0<=end<n,'terminal domain'); full=(1<<n)-1
        same(proof['cost'],table[full,end][0]+d[nodes[end]][0],'terminal realization')
        for j in range(n):
            v=table[full,j][0]+d[nodes[j]][0]; demand(proof['cost']<=v,'terminal lower bound')
            if proof['cost']==v: demand(end<=j,'terminal tie rule')
        backwards=[]; mask=full; j=end
        while mask:
            demand((mask>>j)&1,'backtracking membership'); backwards.append(nodes[j]); pred=table[mask,j][1]; mask^=1<<j; j=pred
        same(j,-1,'backtracking sentinel'); same(proof['route'],[0]+backwards[::-1]+[0],'DP reconstructed witness')
    else: same(proof['route'],[0,0],'empty witness'); same(proof['cost'],0,'empty cost')
    same(sorted(proof['route'][1:-1]),nodes,'DP path coverage'); same(cost(proof['route'],d),proof['cost'],'DP witness cost')
    return len(table),transitions

def verify_trace(result,baseline,d):
    same(result['budget'],10000,'fixed candidate budget'); same(len(result['routes']),len(baseline),'trace slots')
    global_count=0; accepted=0; details=[]
    for slot,(base,record) in enumerate(zip(baseline,result['routes']),1):
        same(record['slot'],slot,'trace slot order'); r=base[:]; n=len(r)-2; start=global_count
        # Follow recorded moves, asserting every preceding lexicographic candidate was rejected legally.
        for move in record['accepted_moves']:
            i,j=move['i'],move['j']; demand(1<=i<j<=n,'move domain'); hit=False
            for a in range(1,n):
                for b in range(a+1,n+1):
                    global_count+=1; demand(global_count<=10000,'candidate cap')
                    delta=d[r[a-1]][r[b]]+d[r[a]][r[b+1]]-d[r[a-1]][r[a]]-d[r[b]][r[b+1]]
                    if (a,b)==(i,j):
                        same(global_count,move['candidate'],'global move candidate index'); same(delta,move['delta'],'move delta'); demand(delta<0,'strict improvement')
                        old=cost(r,d); r[a:b+1]=list(reversed(r[a:b+1])); same(cost(r,d),old+delta,'full path change equals delta'); hit=True; accepted+=1; break
                    demand(delta>=0,'no skipped earlier improvement')
                if hit: break
            demand(hit,'recorded move found')
        # This completed output declares LOCAL_OPTIMUM in every route. Check every final candidate;
        # no new route is selected, optimized, or returned by the checker.
        same(record['status'],'LOCAL_OPTIMUM','completed full-scan stop')
        for a in range(1,n):
            for b in range(a+1,n+1):
                global_count+=1; demand(global_count<=10000,'final-scan budget')
                delta=d[r[a-1]][r[b]]+d[r[a]][r[b+1]]-d[r[a-1]][r[a]]-d[r[b]][r[b+1]]
                demand(delta>=0,'no final improving 2-opt move')
        same(r,record['route'],'trace final route'); same(cost(r,d),record['cost'],'trace cost'); same(global_count-start,record['candidate_count'],'trace route count')
        details.append({'slot':slot,'checked_candidates':global_count-start,'accepted_moves':len(record['accepted_moves']),'full_terminal_scan':True})
    same(global_count,result['candidate_count'],'instance candidate total')
    return global_count,accepted,details

# Integrity and chronology.
manifest=read('freeze/FROZEN_FILES.json'); raw_manifest=read('raw/RAW_UNREVIEWED_MANIFEST.json')
for label,obj in [('frozen',manifest),('raw',raw_manifest)]:
    for rel,meta in obj['files'].items(): same(before[rel],meta,label+' checksum '+rel)
inputs=read('freeze/INPUT_MANIFEST.json')['files']
for f in inputs:
    same(sha(ROOT/f['snapshot']),f['sha256'],'input snapshot'); same(sha(Path(f['source'])),f['sha256'],'upstream original')
old=read('freeze/OLD_TREES_BEFORE.json'); same(len(old),490,'old file count')
for f in old: same(sha(Path(f['path'])),f['sha256'],'unchanged old file'); same(Path(f['path']).stat().st_size,f['bytes'],'old byte count')
archives=[]
for rel in ['provenance/PREEXEC_DRIVE_RECEIPT.json','provenance/RAW_UNREVIEWED_DRIVE_RECEIPT.json']:
    receipt=read(rel)
    for key in ('owner_only','remote_readback_sha256_verified','download_byte_identical'): same(receipt[key],True,'receipt '+key)
    src=Path(receipt['source']); downloaded=Path(receipt['download_path']); same(sha(src),receipt['sha256'],'archive SHA'); same(sha(downloaded),sha(src),'downloaded bytes SHA'); same(src.stat().st_size,receipt['bytes'],'archive bytes')
    with zipfile.ZipFile(src) as z:
        members=z.namelist(); same(len(members),len(set(members)),'no duplicate archive paths')
        for member in members:
            p=ROOT.parent/member; demand(p.is_file(),'archived member present'); same(z.read(member),p.read_bytes(),'archive member identical')
    archives.append({'receipt':rel,'file_id':receipt['file_id'],'bytes':receipt['bytes'],'sha256':sha(src),'members_verified':len(members),'download_file_rehashed':True,'owner_only_from_archive_receipt':True})
pre=read('provenance/PREEXEC_DRIVE_RECEIPT.json'); raw_receipt=read('provenance/RAW_UNREVIEWED_DRIVE_RECEIPT.json'); started=read('raw/STARTED.json'); finished=read('raw/FINISHED.json'); summary=read('reports/SUMMARY.json')
def dt(x): return datetime.fromisoformat(x.replace('Z','+00:00'))
demand(dt(manifest['created_utc'])<dt(pre['confirmed_at_utc'])<dt(started['utc'])<dt(finished['utc'])<dt(raw_receipt['confirmed_at_utc'])<dt(summary['created_utc']),'freeze, backup, execute, raw backup, report order')
same(started['frozen_manifest_sha256'],sha(ROOT/'freeze/FROZEN_FILES.json'),'frozen gate')
# Call ledger includes all attempts. A recorded absence of extra calls is not external execution attestation.
attempts=lines('raw/attempts.jsonl'); demand(len(attempts)%2==0,'paired attempts'); calls={}; kinds=Counter()
for a,b in zip(attempts[::2],attempts[1::2]):
    same(a['phase'],'STARTED','start phase'); same(b['phase'],'FINISHED','finish phase'); same(a['call_id'],b['call_id'],'paired ID'); demand(a['call_id'] not in calls,'one attempt per call'); same(b['status'],'SUCCESS','success'); same(b['returncode'],0,'exit status')
    for k in ('stdout','stderr'): same(sha(ROOT/b[k]),b[k+'_sha256'],'call output hash')
    same((ROOT/b['stderr']).stat().st_size,0,'empty stderr'); demand(0<=b['wall_seconds_for_audit_only']<2,'wall ceiling'); demand(0<=b['cpu_seconds_for_audit_only']<1,'CPU ceiling')
    demand(dt(started['utc'])<=dt(a['utc'])<dt(b['utc'])<=dt(finished['utc']),'call in execution window'); calls[a['call_id']]={k:v for k,v in b.items() if k not in ('phase','utc')}; kinds[a['kind']]+=1
same(dict(kinds),{'two_opt':16,'held_karp':101},'actual call counts'); same(len(calls),117,'call denominator')
same(len(list((ROOT/'raw/oracle_calls').glob('*.stdout'))),117,'stdout file count'); same(len(list((ROOT/'raw/oracle_calls').glob('*.stderr'))),117,'stderr file count')
original=lines('inputs/original/results.jsonl'); schedule=read('inputs/original/SCHEDULE.json'); same(len(original),96,'original formal result count'); same({r['call_id'] for r in original},{r['call_id'] for r in schedule},'original schedule coverage')
tasks=read('inputs/TASKS.json'); results=lines('raw/results.jsonl'); same(len(tasks),16,'task denominator'); same(len(results),16,'result denominator')
same([r['instance_id'] for r in tasks],[r['instance_id'] for r in results],'retained order'); same([t['selection_slot'] for t in tasks],list(range(1,17)),'selection order')
rows=[]; routes=[]; seen_calls=set(); coordinate_bases=set(); negative_controls=[]; checked_edges=0
for task,raw in zip(tasks,results):
    name=task['instance_id']; d,dem,q,xy,K=parse_vrp(name); checked_edges+=len(d)**2
    coordinate_bases.add(tuple(zip(tuple(xy),dem))); same(K,task['K'],'task K')
    same(raw['baseline_routes'],task['baseline_routes'],'raw baseline'); same(raw['selection_slot'],task['selection_slot'],'raw slot'); same(raw['retained'],True,'retention')
    arms=[r for r in original if r['instance_id']==name and r['endpoint']=='initialize_256']; same(len(arms),3,'three original arms'); same({r['arm'] for r in arms},{'capacity_solver','waste_solver','pruned_solver'},'arm identities')
    for arm in arms: same(arm['status'],'SUCCESS','old success'); same(arm['output'],arms[0]['output'],'three arms all outputs equal'); same(arm['output']['routes'],task['baseline_routes'],'unchanged original assignment')
    same(set(task['original_initialize_call_ids']),{r['call_id'] for r in arms},'original call provenance')
    base=routes_check(task['baseline_routes'],d,dem,q,K); baseline_cost=sum(r['cost'] for r in base); same(baseline_cost,task['baseline_integer_cost'],'baseline exact cost')
    ref=[]; declared=None
    for line in (ROOT/'inputs/references'/f'{name}.sol').read_text().splitlines():
        if line.startswith('Route #'): ref.append([0]+[int(x) for x in line.split(':',1)[1].split()]+[0])
        elif line.startswith('Cost'): declared=int(line.split()[1])
    same(ref,task['reference_routes'],'raw SOL mapping'); refcheck=routes_check(ref,d,dem,q,K); reference_cost=sum(r['cost'] for r in refcheck); same(reference_cost,declared,'SOL declared cost'); same(reference_cost,task['reference_integer_cost'],'reference cost')
    cid=f"T{task['selection_slot']:02d}_2OPT"; opt=raw['two_opt']; same(opt['call'],calls[cid],'2opt ledger'); seen_calls.add(cid); result=read(calls[cid]['stdout']); same(result,opt['result'],'raw 2opt output'); same(opt['accepted'],True,'2opt accepted')
    counts,moves,trace=verify_trace(result,task['baseline_routes'],d)
    if 'tampered 2-opt candidate count rejected' not in negative_controls:
        corrupted=copy.deepcopy(result); corrupted['candidate_count']+=1
        try: verify_trace(corrupted,task['baseline_routes'],d)
        except AssertionError: negative_controls.append('tampered 2-opt candidate count rejected')
        else: raise AssertionError('tampered 2-opt accepted')
    optcheck=routes_check([r['route'] for r in result['routes']],d,dem,q,K,task['baseline_routes']); optcost=sum(r['cost'] for r in optcheck); demand(optcost<=baseline_cost,'no worse cost')
    exacts=[]; eligible=[]
    for r,bc,tr in zip(raw['routes'],base,trace):
        slot=r['slot']; same(slot,bc['slot'],'route slot'); same(r['baseline_cost'],bc['cost'],'route baseline cost'); same(r['baseline_load'],bc['load'],'route baseline load'); same(r['customer_count'],bc['customers'],'route size'); same(optcheck[slot-1]['load'],bc['load'],'2opt identical load')
        rr={'instance_id':name,**bc,**tr,'two_opt_cost':optcheck[slot-1]['cost'],'exact_cost':None,'states_verified':0,'transitions_verified':0,'status':r['exact_status']}
        if bc['customers']<=12:
            eligible.append(slot); same(r['exact_status'],'SUCCESS_CERTIFIED','eligible status'); cid=f"T{task['selection_slot']:02d}_R{slot:02d}_HK"; same(r['call'],calls[cid],'DP ledger'); seen_calls.add(cid)
            same(r['DP_proof_file'],calls[cid]['stdout'],'DP file'); same(r['DP_proof_sha256'],calls[cid]['stdout_sha256'],'DP SHA'); proof=read(r['DP_proof_file']); nstates,ntrans=certify_dp(proof,task['baseline_routes'][slot-1],d)
            same(proof['route'],r['exact_route'],'recorded exact route'); same(proof['cost'],r['exact_cost'],'recorded exact cost'); demand(proof['cost']<=optcheck[slot-1]['cost'],'exact <= feasible 2opt')
            exacts.append(proof['route']); rr.update(exact_cost=proof['cost'],states_verified=nstates,transitions_verified=ntrans)
            if 'tampered DP singleton rejected' not in negative_controls and proof['states']:
                broken=copy.deepcopy(proof); broken['states'][0][2]+=1
                try: certify_dp(broken,task['baseline_routes'][slot-1],d)
                except AssertionError: negative_controls.append('tampered DP singleton rejected')
                else: raise AssertionError('tampered DP accepted')
        else:
            same(r['exact_status'],'INELIGIBLE_OVER_12','over-threshold status'); same(r['exact_cost'],None,'no ineligible exact cost'); same(r['exact_route'],None,'no ineligible exact route'); demand('call' not in r,'no over-threshold call')
        routes.append(rr)
    same(eligible,task['eligible_exact_route_slots'],'all and only eligible slots'); same(len(raw['routes']),K,'all route records')
    qualified=len(exacts)==K; same(qualified,raw['fixed_group_exact_qualified'],'full qualification'); same(qualified,task['all_routes_size_eligible'],'size eligibility')
    exact_cost=sum(r['cost'] for r in routes_check(exacts,d,dem,q,K,task['baseline_routes'])) if qualified else None; same(exact_cost,raw['fixed_group_exact_cost'],'exact total or null')
    rows.append({'instance_id':name,'K':K,'baseline':baseline_cost,'two_opt':optcost,'reference':reference_cost,'two_opt_candidates':counts,'two_opt_accepted_moves':moves,'exact_routes':len(exacts),'fixed_group_exact_qualified':qualified,'fixed_group_exact_cost':exact_cost,'exact_residual_above_reference':exact_cost-reference_cost if qualified else None,'baseline_gap_percent':100*(baseline_cost-reference_cost)/reference_cost,'two_opt_gap_percent':100*(optcost-reference_cost)/reference_cost})
same(seen_calls,set(calls),'no unassigned formal calls'); same(len(coordinate_bases),14,'unique coordinate-demand bases'); same(len(routes),115,'route count')
scale=read('freeze/INPUT_SCALE.json'); same(sum(r['states_verified'] for r in routes),scale['eligible_DP_states'],'all DP states'); same(sum(r['transitions_verified'] for r in routes),scale['eligible_DP_transitions'],'all DP transitions')
for actual,saved in zip(rows,summary['per_instance']):
    for ours,theirs in [('baseline','baseline_integer_cost'),('two_opt','two_opt_integer_cost'),('reference','reference_integer_cost'),('exact_routes','exact_route_successes'),('two_opt_candidates','two_opt_candidates'),('fixed_group_exact_cost','fixed_group_exact_cost'),('exact_residual_above_reference','exact_residual_above_reference')]: same(actual[ours],saved[theirs],'reported '+theirs)
    for k in ('baseline_gap_percent','two_opt_gap_percent'): demand(abs(actual[k]-saved[k])<1e-12,'reported gap')
means={'baseline_mean_reference_gap_percent':statistics.mean(r['baseline_gap_percent'] for r in rows),'two_opt_mean_reference_gap_percent_all16':statistics.mean(r['two_opt_gap_percent'] for r in rows),'mean_gap_reduction_percentage_points_all16':statistics.mean(100*(r['baseline']-r['two_opt'])/r['reference'] for r in rows)}
for k,v in means.items(): demand(abs(v-summary[k])<1e-12,'reported aggregate '+k)
for field,key in [('baseline','baseline_cost_sum'),('two_opt','two_opt_cost_sum_all16'),('reference','reference_cost_sum')]: same(sum(r[field] for r in rows),summary[key],'reported sum')
with (ROOT/'reports/PER_INSTANCE.csv').open() as f: saved_instance_csv=list(csv.DictReader(f))
with (ROOT/'reports/PER_ROUTE.csv').open() as f: saved_route_csv=list(csv.DictReader(f))
same(len(saved_instance_csv),16,'report instance CSV denominator'); same(len(saved_route_csv),115,'report route CSV denominator')
for actual,saved in zip(rows,saved_instance_csv):
    same(actual['instance_id'],saved['instance_id'],'instance CSV order')
    for a,b in [('baseline','baseline_integer_cost'),('two_opt','two_opt_integer_cost'),('reference','reference_integer_cost')]: same(actual[a],int(saved[b]),'instance CSV cost')
for actual,saved in zip(routes,saved_route_csv):
    same(actual['instance_id'],saved['instance_id'],'route CSV instance'); same(actual['slot'],int(saved['slot']),'route CSV slot'); same(actual['customers'],int(saved['customers']),'route CSV size'); same(actual['status'],saved['exact_status'],'route CSV status'); same(actual['exact_cost'],int(saved['exact_cost']) if saved['exact_cost'] else None,'route CSV exact cost')
after=snapshot(ROOT); same(after,before,'author tree unchanged by review')
report={'status':'PASS_WITH_INFERENCE_LIMITATIONS','created_utc':datetime.now(timezone.utc).isoformat(),'scope':'Independent read-only checking of frozen inputs, recorded traces, DP certificates and reported numbers; no author code imported; no solver/oracle executed.','author_tree_unchanged_files':len(before),'frozen_files_verified':len(manifest['files']),'raw_manifest_files_verified':len(raw_manifest['files']),'source_snapshots_verified':len(inputs),'old_files_unchanged':len(old),'archives':archives,'provenance_limit':'Archive receipts assert owner-only remote access; this review rehashed the saved remote-download files and every archived member, rather than querying current Drive ACLs. Execution ledger/source support recorded one-attempt counts, not universal proof no unrecorded execution occurred.','tasks':16,'coordinate_demand_bases':14,'baseline_sets':1,'routes':115,'original_formal_calls':96,'new_formal_calls':len(calls),'new_call_kinds':dict(kinds),'full_distance_matrix_entries_verified':checked_edges,'two_opt_candidates_verified':sum(r['two_opt_candidates'] for r in rows),'two_opt_accepted_moves_verified':sum(r['two_opt_accepted_moves'] for r in rows),'two_opt_all115_terminal_scans_verified':True,'two_opt_max_candidates_per_task':max(r['two_opt_candidates'] for r in rows),'two_opt_budget_exhausted_tasks':0,'exact_success_routes':sum(r['exact_cost'] is not None for r in routes),'over12_ineligible_routes':sum(r['exact_cost'] is None for r in routes),'DP_states_verified':sum(r['states_verified'] for r in routes),'DP_transitions_verified':sum(r['transitions_verified'] for r in routes),'full_exact_tasks':sum(r['fixed_group_exact_qualified'] for r in rows),'improved_tasks':sum(r['two_opt']<r['baseline'] for r in rows),'unchanged_tasks':sum(r['two_opt']==r['baseline'] for r in rows),**means,'negative_controls':negative_controls,'per_instance':rows,'ineligible_routes':[{'instance_id':r['instance_id'],'slot':r['slot'],'customers':r['customers']} for r in routes if r['exact_cost'] is None],'limitations':['Post-hoc new ordering diagnostic only; not original capacity primary endpoint or a prospective preregistration.','16 tasks share 14 coordinate-demand bases; three identical original arms are one baseline, not 48 independent observations.','2-opt local-optimum certificates do not establish fixed-group global optima.','Only six all-route-certified tasks support exact fixed-group residual decomposition. The other ten have no exact fixed-group total.','Positive certified fixed-group optimum minus feasible reference proves current grouping cannot reach that reference by reordering. It is not a global optimality or SOTA certificate.','No CPU speed comparison; time values are solely resource audit.']}
dump(OUT/'INDEPENDENT_REVIEW.json',report); dump(OUT/'AUTHOR_TREE_HASHES.json',before)
for name,data in [('VERIFIED_INSTANCES.csv',rows),('VERIFIED_ROUTES.csv',routes)]:
    with (OUT/name).open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(data[0])); writer.writeheader(); writer.writerows(data)
print(json.dumps({k:v for k,v in report.items() if k not in ('per_instance','ineligible_routes','archives')},ensure_ascii=False,indent=2))
