"""Read-only independent route validation and descriptive quality report, gated on raw archive readback."""
from pathlib import Path
import sys,json,csv,statistics
from fractions import Fraction
from common import ROOT,now,sha,read,save,verify_frozen,verify_old,receipt,verify_prior_failed
sys.path.insert(0,str(ROOT/'independent_review'))
from independent_validator import validate_solution

def dump_csv(path,rows):
    keys=list(dict.fromkeys(k for row in rows for k in row))
    with path.open('x',newline='') as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)

def main():
    verify_frozen(); receipt('RAW_UNREVIEWED');verify_old();verify_prior_failed()
    manifest=read('raw/RAW_UNREVIEWED_MANIFEST.json')
    assert all(sha(ROOT/p)==m['sha256'] for p,m in manifest['files'].items())
    schedule=read('freeze/SCHEDULE.json');tasks=read('freeze/TASKS.json')
    observed=[json.loads(line) for line in (ROOT/'raw/results.jsonl').read_text().splitlines()] if (ROOT/'raw/results.jsonl').exists() else []
    assert len({r['call_id'] for r in observed})==len(observed)
    assert set(r['call_id'] for r in observed)<=set(r['call_id'] for r in schedule)
    by_id={r['call_id']:r for r in observed}
    inputs={t['instance_id']:read(f"input/{t['instance_id']}.json") for t in tasks}
    matrix_hashes={r['instance_id']:r['matrix_sha256'] for r in read('independent_review/INPUT_MATRIX_AUDIT.json')['rows']}
    audit_rows=[];seed_rows=[]
    for e in schedule:
        record=by_id.get(e['call_id']);answer=None;validation=None;errors=[]
        if record is None:errors.append('NEVER_STARTED_OR_MISSING_RECORD')
        elif record['status']!='UNREVIEWED_PROCESS_SUCCESS':errors.append(record['status'])
        if record is not None:
            for typ in ('stdout','stderr'):
                p=ROOT/record[typ]
                if not p.exists() or sha(p)!=record.get(typ+'_sha256'):errors.append(f'{typ}_HASH_MISMATCH')
            if not errors:
                try:
                    answer=json.loads((ROOT/record['stdout']).read_text())
                    validation=validate_solution(inputs[e['instance_id']],answer['routes'],answer['reported_cost'])
                    if not(validation['valid'] and validation['reported_cost_checked'] and validation['reported_cost_matches']):errors.append('INDEPENDENT_ROUTE_VALIDATION_FAILED')
                    if not(answer['solver_is_feasible'] and answer['solver_is_complete']):errors.append('SOLVER_NOT_FEASIBLE_COMPLETE')
                    if answer['reported_fixed_vehicle_cost']!=0 or answer['reported_duration_cost']!=0:errors.append('NON_DISTANCE_OBJECTIVE')
                    if answer['reported_cost']!=answer['reported_distance']:errors.append('DISTANCE_OBJECTIVE_MISMATCH')
                    expected_limits={'inherited':{'AS_bytes':[512*1024**2,1024*1024**2],'CPU_seconds':[20,20]},'effective':{'AS_bytes':[1024*1024**2,1024*1024**2],'CPU_seconds':[5,5]}}
                    if answer.get('resource_limits')!=expected_limits:errors.append('RESOURCE_INHERITANCE_MISMATCH')
                    if answer['model_matrix_sha256']!=matrix_hashes[e['instance_id']]:errors.append('MODEL_MATRIX_MISMATCH')
                    if answer['denied_io_events'] or answer['reference_or_history_payload_fields']:errors.append('IO_OR_PAYLOAD_VIOLATION')
                    if answer['seed']!=e['seed'] or answer['max_runtime_seconds']!=1.0 or answer['version']!='0.14.0':errors.append('SCHEDULE_VERSION_MISMATCH')
                    if len(answer['native_routes'])!=len(answer['routes']):errors.append('NATIVE_ROUTE_COUNT_MISMATCH')
                    else:
                        for closed,native in zip(answer['routes'],answer['native_routes']):
                            if [a['node'] for a in native['activities']]!=closed:errors.append('NATIVE_MAPPING_MISMATCH')
                            for pos,a in enumerate(native['activities']):
                                if a['location']!=a['node']:errors.append('LOCATION_MAP_MISMATCH')
                                if pos in (0,len(native['activities'])-1):
                                    if a['type']!='DEPOT' or a['idx']!=0 or a['node']!=0:errors.append('BAD_NATIVE_DEPOT')
                                elif a['type']!='CLIENT' or a['idx']+1!=a['node']:errors.append('BAD_NATIVE_CLIENT')
                            if native['vehicle_type']!=0 or native['num_trips']!=1:errors.append('BAD_NATIVE_VEHICLE_TRIP')
                except Exception as exc:errors.append('PARSE_VALIDATION_EXCEPTION:'+str(exc))
        valid=not errors
        audit_rows.append({'call_id':e['call_id'],'valid':valid,'errors':errors,'validation':validation})
        seed_rows.append({**e,'status':'VALID' if valid else 'UNAVAILABLE','cost':validation['cost'] if valid else None,
                          'nonempty_routes':validation['nonempty_routes'] if valid else None,
                          'iterations':answer.get('num_iterations') if answer else None,
                          'search_runtime_audit_only':answer.get('solver_loop_runtime') if answer else None,
                          'process_wall_audit_only':record.get('wall_seconds_audit_only') if record else None,
                          'failure':';'.join(errors)})
    task_rows=[];history_audit=[];gap_deltas=[];baseline_gaps=[];history_gaps=[];improved=equal=worse=0
    for task in tasks:
        name=task['instance_id'];p=inputs[name];slot=task['selection_slot']
        ref=read(f'references/{name}.json');tsr=read(f'history/S{slot:02d}_TSR.stdout')
        ref_routes=[[0,*r,0] for r in ref['reference_routes']]
        ref_audit=validate_solution(p,ref_routes,ref['reference_integer_cost'])
        tsr_audit=validate_solution(p,tsr['routes'],tsr['cost'])
        assert ref_audit['valid'] and ref_audit['reported_cost_matches'] and tsr_audit['valid'] and tsr_audit['reported_cost_matches'],name
        reference=ref_audit['cost'];historical=tsr_audit['cost']
        assert reference>0 and ref['K_ref']==p['K']
        history_audit.append({'instance_id':name,'reference':ref_audit,'historical_TSR':tsr_audit,'reference_is_not_an_optimality_proof':True})
        seed=[r for r in seed_rows if r['instance_id']==name];values=[r['cost'] for r in seed if r['status']=='VALID'];complete=len(values)==3
        row={'instance_id':name,'selection_slot':slot,'reference_cost':reference,'historical_TSR_cost':historical,'historical_TSR_reference_gap_percent':100*(historical-reference)/reference,'valid_seed_count':len(values),'planned_seed_count':3,'seed0_cost':seed[0]['cost'],'seed1_cost':seed[1]['cost'],'seed2_cost':seed[2]['cost'],'mean3_cost':None,'mean3_reference_gap_percent':None,'historical_TSR_minus_mean3_gap_pp':None,'historical_TSR_excess_over_mean3_percent':None,'best_of3_cost_secondary':None,'worst_of3_cost_secondary':None,'range3_cost_secondary':None,'sample_SD3_cost_secondary':None,'historical_TSR_vs_mean3':'UNAVAILABLE'}
        history_gaps.append(Fraction(100*(historical-reference),reference))
        if complete:
            mean=Fraction(sum(values),3);bgap=100*(mean-reference)/reference;delta=Fraction(100*historical,reference)-100*mean/reference
            category='TSR_HIGHER_COST' if historical*3>sum(values) else ('EQUAL' if historical*3==sum(values) else 'TSR_LOWER_COST')
            improved+=category=='TSR_HIGHER_COST';equal+=category=='EQUAL';worse+=category=='TSR_LOWER_COST'
            row.update(mean3_cost=float(mean),mean3_reference_gap_percent=float(bgap),historical_TSR_minus_mean3_gap_pp=float(delta),historical_TSR_excess_over_mean3_percent=float(100*(historical-mean)/mean),best_of3_cost_secondary=min(values),worst_of3_cost_secondary=max(values),range3_cost_secondary=max(values)-min(values),sample_SD3_cost_secondary=statistics.stdev(values),historical_TSR_vs_mean3=category)
            baseline_gaps.append(bgap);gap_deltas.append(delta)
        task_rows.append(row)
    n=len(gap_deltas);all_complete=n==16
    avg=lambda v:float(sum(v)/len(v)) if v else None
    summary={'utc':now(),'stage':'DESCRIPTIVE_STRONG_BASELINE_QUALITY_COMPARISON','solver':'PyVRP 0.14.0 default ILS, no warmstart','execution_history':[{'revision':'r0','planned_process_attempts':48,'observed_process_attempts':48,'startup_failures':48,'actual_public_optimizer_calls':0,'quality_result_available':False,'cause':'Inherited supervisor512MiB hard AS prevented worker raising to1024MiB; failed before payload/PyVRP import/model/solve.'},{'revision':'r1','planned_process_attempts':48,'observed_process_attempts':len(observed),'completed_valid_solver_outputs':sum(r['valid'] for r in audit_rows),'unavailable_call_count':48-sum(r['valid'] for r in audit_rows)}],'planned_instances':16,'planned_calls':48,'observed_calls':len(observed),'valid_calls':sum(r['valid'] for r in audit_rows),'complete_three_seed_tasks':n,'all16_mean_PyVRP_reference_gap_percent':avg(baseline_gaps) if all_complete else None,'all16_mean_historical_TSR_reference_gap_percent':avg(history_gaps),'all16_mean_historical_TSR_minus_PyVRP_gap_pp':avg(gap_deltas) if all_complete else None,'descriptive_available_complete_tasks_mean_PyVRP_reference_gap_percent':avg(baseline_gaps),'descriptive_available_complete_tasks_mean_gap_delta_pp':avg(gap_deltas),'descriptive_complete_task_denominator':n,'PyVRP_mean_better_equal_worse_vs_TSR':{'better':improved,'equal':equal,'worse':worse,'unavailable':16-n},'positive_delta_interpretation':'Historical TSR higher distance cost than PyVRP mean3, normalized by same public reference.','no_equal_compute_or_speed_claim':True,'no_optimality_proof_claim':True,'no_repeated_calls_within_each_frozen_revision':True,'separately_declared_r1_technical_retry':True,'old_files_unchanged_count':verify_old(),'limitations':read('freeze/PROTOCOL.json')['limitations']}
    save(ROOT/'reports/SAVED_ROUTE_VALIDATION.json',{'utc':now(),'optimizer_rerun':False,'calls':audit_rows,'history_reference_validation':history_audit})
    save(ROOT/'reports/SUMMARY.json',summary)
    dump_csv(ROOT/'reports/PER_SEED.csv',seed_rows);dump_csv(ROOT/'reports/PER_INSTANCE.csv',task_rows)
    lines=['公开16题：成熟开源基线质量对照','目录本地日期标签：2026-10-09；执行与档案时间以UTC字段为准。','',f"PyVRP 0.14.0 默认 ILS；16题×3 seeds（0,1,2），每次 MaxRuntime(1.0s)，无旧解/参考解热启动。",'执行主状态：r0保留48次进程尝试、48次启动失败、实际公共求解0次，无质量结果。r1为单独冻结的资源继承技术修复轮。',f"r1有效调用 {summary['valid_calls']}/48；三次均有效任务 {n}/16。",'主结果用每题三次成本均值，再对16题等权；best-of-3仅在逐题副表。','',f"历史TSR平均reference gap：{avg(history_gaps):.9f}%。"]
    if all_complete:
        lines += [f"PyVRP三seed均值的平均reference gap：{avg(baseline_gaps):.9f}%。",f"历史TSR减PyVRP的平均reference-gap差：{avg(gap_deltas):+.9f}个百分点。正值代表历史TSR成本更高。",f"逐题PyVRP均值相对TSR：{improved}题更低、{equal}题相同、{worse}题更高。"]
    else:lines += ['存在缺失/失败/无效调用；全16题主均值留空。可用完整任务的描述均值及分母见SUMMARY.json，不能当成全16题结论。']
    lines += ['', '解释边界：','- at-most-K_ref，单车容量约束、客户恰访一次；距离按每边EUC_2D整数舍入。','- 本实验只对照解的质量。PyVRP与历史TSR预算、初始化、语言实现均不同，不比较速度或等算力。','- 1秒是主ILS循环的停止条件，初始化/模型构建在外；另配置5秒CPU、10秒墙时外限；CPU执行终止受内核计量/调度粒度影响，实际CPU可能略超过配置数值。固定seed也不保证时间型搜索完全复现。','- Published reference是可行公开比较值，不是本研究证明的严格最优值。','- 这16题已有历史结果，不是新的盲测或确认性研究；无统计显著性、普适优势或SOTA主张。','- 各冻结轮内不删除失败、不补题、不重跑；r1是单独披露的技术重试，r0失败完整保留；原目录逐文件哈希不变。','','证据：PER_SEED.csv、PER_INSTANCE.csv、SAVED_ROUTE_VALIDATION.json、冻结协议、环境/依赖哈希、原始stdout/stderr与分阶段私有归档回执。','r1技术变更：主管AS软512/硬1024MiB，worker软硬1024MiB；当前软限相加1536MiB、理论硬限相加2048MiB。算法/seed/停止条件/CPU和墙时预算未变。','该报告待独立最终审阅。']
    (ROOT/'reports/REPORT_ZH.txt').write_text('\n'.join(lines)+'\n')
    print(json.dumps(summary,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
