"""Additional immutable full-stop/seed1+2 fixtures through the actual limited supervisor."""
import sys,json,resource,signal
from common import ROOT,read,save,sha,now
from run_once import execute_call
sys.path.insert(0,str(ROOT/'independent_review'))
from independent_validator import validate_solution

def run_in_limited_supervisor(limits):
    assert limits=={'AS_bytes':[512*1024**2,1024*1024**2],'CPU_seconds':[20,20]}
    signal.alarm(45)
    dest=ROOT/'selftests/full_budget_integration';dest.mkdir(exist_ok=False)
    problem={'coordinates':[[0,0],[10,0],[11,0],[12,0]],'demands':[0,1,1,1],'capacity':3,'K':3}
    python=read('environment/RUNTIME.json')['python_executable'];records=[]
    for seed in [1,2]:
        payload={**problem,'seed':seed,'max_runtime_seconds':1.0}
        entry={'call_id':f'FULL_SEED_{seed}','instance_id':'INVENTED_SLACK_K_FULL_BUDGET','seed':seed,'max_runtime_seconds':1.0}
        record=execute_call(entry,payload,python,dest)
        assert record['status']=='UNREVIEWED_PROCESS_SUCCESS' and record['child_reaped']
        answer=json.loads((ROOT/record['stdout']).read_text())
        check=validate_solution(problem,answer['routes'],answer['reported_cost'])
        assert check['valid'] and check['reported_cost_matches']
        assert answer['seed']==seed and answer['max_runtime_seconds']==1.0
        assert answer['resource_limits']=={'inherited':limits,'effective':{'AS_bytes':[1024*1024**2,1024*1024**2],'CPU_seconds':[5,5]}}
        records.append({'record':record,'validation':check,'resource_limits':answer['resource_limits'],'worker_maxrss_KiB':answer['worker_maxrss_KiB_audit_only'],'solver_loop_runtime':answer['solver_loop_runtime']})
    signal.alarm(0)
    save(ROOT/'selftests/FULL_BUDGET_SUPERVISOR_INTEGRATION.json',{'utc':now(),'status':'PASS','entrypoint':'production run_once.py --synthetic-full-budget','public_optimizer_calls':0,'synthetic_successful_solves':2,'seeds':[1,2],'max_runtime_seconds':1.0,'supervisor_limits':limits,'supervisor_maxrss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'source_sha256':{name:sha(ROOT/'source'/name) for name in ['run_once.py','worker.py','synthetic_full_budget.py']},'records':records})
    print('PASS same production limited supervisor: fixed invented problem, seed1/2, MaxRuntime1.0')
