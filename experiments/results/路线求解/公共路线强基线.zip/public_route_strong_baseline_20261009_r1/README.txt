公开CVRP迁移16题：PyVRP 0.14.0强基线，r1技术修复轮

主执行状态必须保留：r0共48次计划进程尝试全部在资源限额设置时失败；实际公共求解0次，无解质量结论。r0源码、raw、归档不修改。r1尚未正式执行。

r1唯一科学外技术调整：主管AS软512/硬1024MiB，worker仍软硬1024MiB，解决继承的硬上限不可提高问题。有效软限相加1536MiB；理论硬限相加2048MiB；非RSS实测。260秒仅为主管及48个worker配置CPU限额的算术和；内核计量/调度粒度可使实测略超过配置，不能称严格实际总CPU上界。
算法仍PyVRP0.14.0默认ILS；固定16题、seed0/1/2、MaxRuntime1秒、子CPU5秒/外墙10秒、主管CPU20秒/外墙600秒均不变。

source/run_once.py --synthetic-integration 通过同一个生产资源配置与Popen函数测试4个虚构成功题，以及真实wall timeout、CPU硬限、坏payload和重复输出防护。另外同一主管链新增seed1/2、MaxRuntime1.0完整时长虚构题测试并保留原始证据，不覆盖先前测试。测试不读取公共题，不绕过正式执行门控。

freeze/R0_TO_R1.diff：精确源码/协议差分。
freeze/SOURCE_SEMANTIC_COMPATIBILITY.json：build_model/extract_routes/run算法函数AST及科学协议块相等证据。
selftests/SUPERVISOR_INTEGRATION.json：真实受限主管链证据与每个worker继承/实际限额。
history/PRIOR_FAILED_RUN_AUDIT.json：旧轮失败的独立审计。

环境复用先前已授权安装的精确隔离venv，14个官方wheel、依赖锁和4440安装文件哈希仍核对；不改全局环境。
正式r1执行仍须独立precheck、新完整PREEXEC私有实际回读、父任务对新freeze的一次批准。执行后RAW先真实回读，才可末评分和独审。不调参、不补题、不重跑本轮调用；reference不是严格最优证明，不比较等算力或速度。
