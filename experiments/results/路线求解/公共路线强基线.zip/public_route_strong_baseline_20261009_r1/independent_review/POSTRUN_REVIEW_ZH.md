# r1 独立末审

结论：PASS。此结论针对已保存的实验结果、计算与证据一致性，不将本实验提升为盲测、确认性研究、等计算量比较或最优性证明。

## 主结果

从原始 VRPLIB 输入解析坐标与需求，复用独立标准库验解器，按 Decimal 80 位精度逐边 ROUND_HALF_UP 求整数距离。48 份 PyVRP 解、16 份公开 reference 解、16 份历史 TSR 解全部通过客户恰访一次、合法索引/闭仓库、容量、至多 K 条非空路线和成本检查。逐条原生活动的 depot/client 类型、client 索引到 location/node 映射、路线距离与载重均与保存路线一致。

预冻结口径保持“每题三个 seed 成本取均值，再对 16 题等权”。以 Fraction 精确重算后转浮点显示：

- PyVRP 平均 reference gap：0.14874690080787073%
- 历史 TSR 平均 reference gap：11.992317722371023%
- TSR 减 PyVRP 的平均差：11.843570821563151 个百分点
- 用整数交叉相乘比较：16/16 题 PyVRP 均值成本更低

逐 seed、逐题 CSV 全部字段与原始证据重算一致。best-of-3 只在预设次要列，不用于主统计。

## 后验描述核验

这部分只描述已保存的结果，不引入额外求解或更换主指标：

- 34/48 份解恰等于给定 reference，14/48 更高，0/48 更低
- gap 中位数 0%，最大 0.8704061895551257%，样本标准差 0.2724979193411701 个百分点
- seed 0/1/2 的平均 gap 分别为 0.11395223486417783%、0.14768721218906097%、0.1846012553703734%；命中分别为 12/16、11/16、11/16
- 10/16 题三个 seed 全部等于 reference；12/16 题至少一次等于 reference

没有低于 reference 的输出，因此不存在需进一步解释的负 gap。所有 reference 路线均在相同输入、舍入、Q 和 at-most-K 语义下重新验证为可行；这仍不是最优性证明。48 份结果是 16 题的重复实现，不是 48 个独立抽样任务。

## 排程、输入、源码与保全

- 固定 16 题 × seeds 0、1、2，48 计划/48 启动/48 完成/48 结果；96 条严格交替的开始与结束事件，时间顺序无重叠。
- 原始调用目录恰有预期的 48 对 stdout/stderr；成功状态、返回码、reap 标志一致，全部 worker stderr 为空。
- 逐调用重新构造仅含 coordinates、demands、capacity、K、seed、max_runtime_seconds 的净化 payload，字节哈希与记录一致。
- 冻结 worker.run 静态源码仅有一次 solve 调用，initial_solution=None，默认 SolveParams；排程与源码无内部重试分支，独占创建保护保留。无额外或重复调用的判断限于所封存的排程、日志、源码和档案证据，不是对全系统未记录活动的独立 OS 级证明。
- 原始 VRPLIB 与规范 JSON 全字段一致；独立 Decimal 与实际使用的 EUC_2D 整数矩阵共 40,882 个有向单元一致，全部 48 份输出中的模型矩阵哈希相符。
- r1 的 build_model、extract_routes、run AST 与 r0 完全相同；算法、任务语义、seed 排程、主次指标和 reference 隔离块保持一致。
- 148 个冻结文件、104 个原始封存文件、389 个历史实验文件及 250 个 r0 文件的精确文件集合/字节数/SHA 检查通过。记录的解释器、4,440 个依赖安装文件和全部 wheel 哈希检查通过。

## r0 与资源披露

r0 的 48 个进程尝试完整保留。全部 stderr 为相同的继承地址空间硬限错误，stdout 为空；失败发生在输入读取、PyVRP 导入、模型构建和实际公共求解前。故 r0 公共求解 0 次，无质量结果。r1 是单独披露、重新冻结的资源继承技术重试，不能掩盖为首次无故障成功。

r1 的保存记录逐项确认：主管 AS 软 512/硬 1024 MiB，worker AS 软硬 1024 MiB；主管 CPU 配置 20 秒，worker 5 秒。当前软限合计 1536 MiB、硬限合计 2048 MiB。配置 CPU 限额之和 260 秒不是精确实际总 CPU 上界，也不包含外层安装/归档/审计。

原始数据的资源描述复算：worker CPU 合计 55.453286 秒，含主管为 56.369312633 秒；worker 最大进程墙时 1.2284153340006014 秒；ILS loop 观测为 1.0000142740027513 至 1.0030241330023273 秒。48 个 worker ru_maxrss 均为 70744 KiB，主管 70972 KiB。这是进程生命周期 high-water 观测，不是 solver 净新增内存，不用于历史 TSR 的性能或等计算量比较。

## 私有归档证据链

PREEXEC、RAW 的本地包、官方认证分片下载、按序重建包逐字节相同；各片偏移、长度、SHA、完整覆盖、ZIP CRC、成员唯一性与全部成员当前字节一致。PREEXEC 回读在执行之前；原始封存在 RAW 回读之前；报告端点评分在 RAW 回读之后。

需要精确表述：这是私有 Google Drive 分片认证回读重建完整 ZIP 的验证。回执明确 direct_complete_file_download_verified=false，不能改称整 ZIP 远程对象本身被直接下载。本末审为离线证据检查，未新增远程操作；权限结论依据保存的认证回执，不宣称本次重新查询了服务器当前权限。

- 精确批准 freeze SHA-256：182ea37bbc306050691b4b3f80ad50bc24bdff035f5d8f16e97983c2b55c1a7c
- PREEXEC ZIP SHA-256：aa69e11a39891b4b6312a21b60ea14349dd18d9e16eb29f07cc4d6a21752cc8e
- RAW ZIP SHA-256：475de45fd682b653b168c19bdf49e830dff9ab271ad8ab92e9eb7a81101132e9
- 本末审证据：POSTRUN_INDEPENDENT_AUDIT.json；SHA-256 824d2598c576ecfde0e77e97b9baad91f721f59a441414cff47631c48ffea11a
- 资源补充核验：POSTRUN_SUPPLEMENT_AUDIT.json；SHA-256 41cdc36ce59f9de2a6be41cf239e727ed50c90d107ae03a1f65a15ce866a42d5
- 可复核脚本：audit_saved_results_posthoc.py；SHA-256 fef5343a990200738adfd38cb6814e4bae18c14eee976b6dcd651c090080df4a

## 科研结论约束

在这个固定面板上，自制 TSR 顺序局部搜索与成熟 PyVRP 基线仍有明显解质量差距。先前 TSR 相对 TRS 的局部收益不足以支持有竞争力或 SOTA 算法定位。机制、路径依赖与自动调度仍可作为探索方向，但不能由此主张创新性、统计显著性、普适优势或盲测泛化。初始化、搜索机制与预算不同，本对照不能单独归因差距来源。

本末审没有导入 PyVRP、构建模型、运行求解器、启动新实验、安装、上传或修改既有源码/frozen/raw 文件，也没有重新运行 source/report.py。仅在 independent_review 中新增审计产物。
