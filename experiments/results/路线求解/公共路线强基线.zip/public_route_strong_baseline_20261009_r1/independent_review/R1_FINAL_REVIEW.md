# R1 independent pre-execution review

Status: PASS for this reviewed r1 candidate. This is a new review, not reuse of the
r0 PASS. Formal public optimisation remains zero in r1 at the time of this review.
New freeze, private PREEXEC byte readback and exact parent approval remain required.

## Prior failure remains part of the result history

R0 retains 48 launched process attempts, 48 startup failures and zero actual public
solver entries. Its worker tried to raise an inherited 512-MiB AS hard limit to
1,024 MiB before reading the payload. The previous precheck did not exercise that
supervisor-to-worker resource inheritance path. Standalone synthetic success and
separate cleanup tests did not establish integrated readiness. R0 evidence and
its original PASS are preserved without editing; the failure is disclosed in r1's
main report and structured execution history.

The present review rechecked the entire 250-file r0 manifest and 389-file earlier
historical experiment manifest. File sets and hashes remain unchanged. The r0 RAW
archive is byte-identical to the recorded actual remote-readback reconstruction.
No old file or archive was changed by this review.

## Technical correction and resource statement

The supervisor now sets AS soft/hard limits to 512/1,024 MiB. The worker still sets
its original 1,024/1,024-MiB limit. Actual integrated outputs show the worker
inheriting AS 512/1,024 and CPU 20/20, then obtaining AS 1,024/1,024 and CPU 5/5.
The AS hard limit is no longer raised by the child; only its soft limit changes
within the inherited ceiling. This is consistent with the [Python resource limit
API](https://docs.python.org/3.12/library/resource.html#resource.setrlimit).

The supervisor's hard AS ceiling is now 1,024 MiB. The sum of supervisor and one
worker hard ceilings is 2,048 MiB; the sum of their currently configured soft
limits is 1,536 MiB. These are virtual-address-space quantities, not physical RSS.
Actual maxRSS is recorded separately. The sum of configured CPU limits is 260 s;
the observed CPU failure fixture used about 5.35 s under a configured 5-s limit.
The protocol now correctly avoids promising an exact realised CPU total and
discloses kernel accounting/scheduling granularity and excluded orchestration.

## Direct independent rechecks

- `build_model`, `extract_routes`, and `run` ASTs match r0 exactly. Solver version,
  initialization, operators/default parameters, rounding, objective, task semantics,
  primary/secondary analyses, isolation payload and formal seed schedule are
  unchanged. SCHEDULE bytes match. No result-directed tuning occurred.
- All 4,440 recorded installed runtime files and the interpreter hash match.
  Copied wheel/runtime provenance, input/reference/history bytes match r0. The
  existing official-wheel registry verification remains linked through preserved
  r0 evidence; no new dependency selection or installation occurred in r1.
- Original VRPLIB and normalized input recomputation agrees for all 16 instances
  and 40,882 directed cells. The actual r1 model-construction evidence has the
  same per-instance matrix hashes. No public solve is used for this check.
- Four saved successful invented solves now came through the production
  `run_once.py --synthetic-integration` entrypoint, actual supervisor limits,
  shared `execute_call`/Popen and the exact venv worker. Raw hashes and independent
  Decimal80 route validation match, including fewer-than-K vehicle use.
- Same-path negative fixtures preserve a 10-s wall timeout, a CPU-limit failure,
  and an actual worker malformed-payload failure. Reusing a fixture output path
  was rejected before another process could spawn. Every child is reaped.
- Two additional fixed invented calls use seeds 1 and 2 and the formal
  MaxRuntime(1.0), CPU 5 s and wall 10 s settings. Both saved outputs independently
  validate, use one route of cost 24, and record correct inherited/effective limits.
  Their measured solver loops are just over one second. No original failure group
  or public optimisation was repeated to obtain these additional checks.
- The added full-budget CLI route is the only change to the supervisor between
  the first integration test and the later test. Independently removing that
  route and reverting its argument-error wording reconstructs exactly the source
  SHA bound into the original integration test. Shared configure/launch/cleanup
  behavior is unchanged. All current full-budget source hashes match.
- Thirty independent parser/validator fixtures, four fake-API adapter fixtures,
  and three process-group cleanup fault fixtures retain PASS evidence.
- Endpoint report source checks RAW readback and hashes before scoring, checks
  actual inherited/effective limits, retains missing results, and uses exact
  three-seed arithmetic before floating display. R0 failure appears in the main
  status; no-repeat wording is expressly scoped within each frozen revision.

This review read, parsed, hashed and independently rescored saved invented routes.
It did not import PyVRP, reconstruct a model, run any new synthetic/public solver
call, or score public reference/history endpoints. Actual model construction and
integration executions are reviewed evidence produced by the preparation task.
The full formal 48-call workflow is intentionally not run as a precheck.

## Remaining execution gates and limitations

Compare current bytes against the new INDEPENDENT_PRECHECK reviewed-files manifest
before packaging. Relevant changes require a fresh review. Then create the new
freeze and PREEXEC archive, privately upload and actually download identical bytes,
and obtain parent approval bound to those exact hashes. Only then may the unique
r1 48-call schedule run. Preserve every failure and never repeat a call within
that revision. Seal and remotely read back raw bytes before endpoint scoring.

The final saved-route/report/provenance audit is still required. Report r0 and r1
attempt counts separately from actual solver entries, without treating the r0
failures as solver-quality outcomes or hiding them through replacement. The
quality comparison remains descriptive, compute-unmatched, non-blind, and limited
to the same selected 16 instances. Public references are feasible comparisons,
not optimality proofs established by this study. Time-based stopping is not
bitwise reproducible, and the Python audit hook is not a native syscall sandbox.
