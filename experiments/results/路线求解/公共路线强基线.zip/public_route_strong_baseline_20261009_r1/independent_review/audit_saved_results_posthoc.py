#!/usr/bin/env python3
"""Independent post-run audit, stdlib-only, no solver/model/report execution.
Reads immutable raw/frozen evidence. Reuses separately authored stdlib Decimal80
validator and VRPLIB parser. Only creates a new exclusive evidence JSON file.
"""
from pathlib import Path
from decimal import Decimal
from fractions import Fraction
from datetime import datetime, timezone
import ast, csv, hashlib, json, math, statistics, sys, zipfile
sys.dont_write_bytecode = True
from independent_validator import validate_solution
from audit_inputs import parse_vrp, decimal_matrix
ROOT = Path(__file__).resolve().parents[1]
FREEZE = '182ea37bbc306050691b4b3f80ad50bc24bdff035f5d8f16e97983c2b55c1a7c'
RAW_SHA = '475de45fd682b653b168c19bdf49e830dff9ab271ad8ab92e9eb7a81101132e9'
checks = []; evidence = {}; refs = {}; hist = {}; inputs = {}; outputs = {}; validations = {}
def ck(ok, what):
    if not ok: raise AssertionError(what)
    checks.append(what)
def j(path): return json.loads(Path(path).read_text())
def jr(rel): return j(ROOT / rel)
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for part in iter(lambda:f.read(1024*1024), b''): h.update(part)
    return h.hexdigest()
def digest(data): return hashlib.sha256(data).hexdigest()
def compact(v): return json.dumps(v,separators=(',',':')).encode()
def jsonl(path): return [json.loads(x) for x in Path(path).read_text().splitlines()]
def verify_manifest(root, manifest, exact=False):
    if exact: ck({str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()} == set(manifest), str(root)+': exact file set')
    for rel,m in manifest.items():
        p=root/rel; ck(p.is_file() and p.stat().st_size==m['bytes'] and sha(p)==m['sha256'],str(p)+': size/SHA')
    return len(manifest)
def close(a,b): return math.isclose(float(a),float(b),rel_tol=1e-12,abs_tol=1e-12)
def astfn(path,name):
    return ast.dump(next(n for n in ast.parse(Path(path).read_text()).body if isinstance(n,ast.FunctionDef) and n.name==name),include_attributes=False)
def quant(v):
    return {'count':len(v),'mean_reference_gap_percent':float(sum(v)/len(v)), 'median_reference_gap_percent':float(statistics.median(v)), 'minimum_reference_gap_percent':float(min(v)), 'maximum_reference_gap_percent':float(max(v)), 'sample_standard_deviation_of_gaps_percent':statistics.stdev([float(x) for x in v]), 'equal_reference_count':sum(x==0 for x in v),'below_reference_count':sum(x<0 for x in v),'at_or_better_reference_count':sum(x<=0 for x in v),'above_reference_count':sum(x>0 for x in v)}
ck(sha(ROOT/'freeze/FROZEN_FILES.json') == FREEZE, 'Exact parent-approved freeze SHA')
frozen=jr('freeze/FROZEN_FILES.json'); rawmanifest=jr('raw/RAW_UNREVIEWED_MANIFEST.json')
evidence['frozen_files_verified']=verify_manifest(ROOT,frozen['files'])
evidence['raw_files_verified']=verify_manifest(ROOT,rawmanifest['files'])
ck({str(p.relative_to(ROOT)) for p in (ROOT/'raw').rglob('*') if p.is_file()} == set(rawmanifest['files'])|{'raw/RAW_UNREVIEWED_MANIFEST.json'}, 'Raw file set exact, no unlisted call files')
old=jr('freeze/OLD_FILES_BEFORE.json'); prior=jr('freeze/PRIOR_FAILED_RUN_FILES.json'); oldroot=Path(old['root']); priorroot=Path(prior['root'])
evidence['old_files_verified']=verify_manifest(oldroot,old['files'],True)
evidence['r0_files_verified']=verify_manifest(priorroot,prior['files'],True)
runtime=jr('environment/RUNTIME.json')
ck(sha(Path(runtime['python_executable']).resolve())==runtime['python_binary_sha256'], 'Recorded interpreter hash')
for m in runtime['installed_distribution_files']: ck(Path(m['path']).stat().st_size==m['bytes'] and sha(m['path'])==m['sha256'], 'Installed distribution file '+m['path'])
evidence['installed_distribution_files_verified']=len(runtime['installed_distribution_files'])
for m in jr('environment/WHEELS.json')['wheels']: ck(sha(ROOT/'environment/wheels'/m['file'])==m['sha256'] and (ROOT/'environment/wheels'/m['file']).stat().st_size==m['bytes'], 'Wheel '+m['file'])
protocol=jr('freeze/PROTOCOL.json'); p0=j(priorroot/'freeze/PROTOCOL.json')
for key in ('baseline','task_semantics','schedule','primary','secondary','reference_isolation'): ck(protocol[key]==p0[key], 'r0/r1 science unchanged '+key)
for name in ('build_model','extract_routes','run'): ck(astfn(ROOT/'source/worker.py',name)==astfn(priorroot/'source/worker.py',name),'r0/r1 worker AST unchanged '+name)
ck((ROOT/'freeze/SCHEDULE.json').read_bytes()==(priorroot/'freeze/SCHEDULE.json').read_bytes(), 'r0/r1 schedule bytes identical')
evidence['source_review']={'scientific_AST_and_protocol_equal':True,'one_solve_call_in_worker_run':True,'initial_solution_None':True,'payload_whitelist_only':True,'Python_audit_hook_not_native_sandbox':True,'scope':'Static source inspection plus saved hashes; no source imported or executed.'}
runast=next(n for n in ast.parse((ROOT/'source/worker.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='run')
solves=[n for n in ast.walk(runast) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='solve']
ck(len(solves)==1 and any(k.arg=='initial_solution' and isinstance(k.value,ast.Constant) and k.value.value is None for k in solves[0].keywords),'Exactly one solve call, no initial solution')
archives=[]
for stage in ('PREEXEC','RAW_UNREVIEWED'):
    r=jr(f'provenance/{stage}_DRIVE_RECEIPT.json'); archive=Path(r['source']); back=Path(r['download_path']); tm=jr(f'provenance/{stage}_TRANSPORT_MANIFEST.json')
    ck(r['owner_only'] and not r['shared'] and r['download_byte_identical'] and r['remote_readback_sha256_verified'],stage+' private authenticated readback receipt flags')
    ck(r['frozen_files_sha256']==FREEZE,stage+' receipt freeze match')
    ck(sha(archive)==sha(back)==r['sha256']==r['download_sha256'],stage+' archive/readback SHA')
    ck(archive.read_bytes()==back.read_bytes(),stage+' archive/readback byte equality')
    if stage=='RAW_UNREVIEWED': ck(sha(archive)==RAW_SHA,'Parent specified RAW SHA')
    data=archive.read_bytes(); offset=0; rebuilt=hashlib.sha256()
    for m,part in zip(tm['parts'],r['transport_parts']):
        raw=Path(part['download_path']).read_bytes(); source=Path(m['path']).read_bytes()
        ck(m['offset']==offset and len(raw)==m['bytes'] and digest(raw)==m['sha256']==part['sha256']==part['download_sha256'],stage+' part hash/offset '+str(m['index']))
        ck(raw==source==data[offset:offset+len(raw)],stage+' part/source/archive byte equality '+str(m['index']))
        ck(part['owner_only'] and not part['shared'] and part['remote_readback_sha256_verified'],stage+' part receipt permission/readback '+str(m['index']))
        rebuilt.update(raw); offset+=len(raw)
    ck(len(tm['parts'])==len(r['transport_parts']) and offset==len(data) and rebuilt.hexdigest()==r['sha256'],stage+' complete ordered part coverage')
    m=r['transport_manifest']; ck(Path(m['source']).read_bytes()==Path(m['download_path']).read_bytes() and sha(m['source'])==m['sha256']==m['download_sha256'],stage+' transport manifest remote byte equality')
    with zipfile.ZipFile(archive) as z:
        ck(len(z.namelist())==len(set(z.namelist())),stage+' ZIP unique members')
        ck(z.testzip() is None,stage+' ZIP CRC all members')
        for name in z.namelist():
            rel=Path(name).relative_to(ROOT.name); ck(z.read(name)==(ROOT/rel).read_bytes(),stage+' ZIP member matches current '+str(rel))
        for name in frozen['files']: ck(digest(z.read(ROOT.name+'/'+name))==frozen['files'][name]['sha256'],stage+' frozen ZIP member '+name)
        count=len(z.namelist())
    archives.append({'stage':stage,'sha256':r['sha256'],'bytes':len(data),'members':count,'parts':len(tm['parts']),'readback':'Official authenticated Drive transport-part readback; ordered reconstruction byte-identical. Complete remote ZIP object not directly downloaded.','direct_complete_file_download_verified':r['direct_complete_file_download_verified'],'remote_archive_url':r['url'],'receipt_sha256':sha(ROOT/f'provenance/{stage}_DRIVE_RECEIPT.json')})
evidence['archives']=archives
priorreceipt=jr('provenance/PRIOR_FAILED_RAW_DRIVE_RECEIPT.json')
ck(sha(Path(priorreceipt['download_path']))==priorreceipt['sha256']==sha(ROOT.parent/'public_route_strong_baseline_20261009_RAW_UNREVIEWED.zip'),'Preserved r0 RAW/readback SHA')
schedule=jr('freeze/SCHEDULE.json'); tasks=jr('freeze/TASKS.json'); results=jsonl(ROOT/'raw/results.jsonl'); attempts=jsonl(ROOT/'raw/attempts.jsonl')
ck(len(tasks)==16 and [t['selection_slot'] for t in tasks]==list(range(1,17)),'16 tasks exact selection order')
ck(tasks==j(oldroot/'freeze/TASKS.json'),'Historical selected task definitions identical')
expected=[{'call_id':f"P{t['selection_slot']:02d}_s{s}",'instance_id':t['instance_id'],'selection_slot':t['selection_slot'],'seed':s,'max_runtime_seconds':1.0} for t in tasks for s in (0,1,2)]
ck(schedule==expected and len(results)==48 and len(attempts)==96,'Exact frozen 48 schedule, 48 results, 96 attempt phase rows')
ck(len({r['call_id'] for r in results})==48,'48 unique call IDs')
start=jr('raw/STARTED.json'); finish=jr('raw/FINISHED.json'); outer=jr('raw/EXECUTOR_FINISHED.json'); approval=jr('provenance/PARENT_EXECUTION_APPROVAL.json')
ck(start['freeze_sha256']==finish['freeze_sha256_after']==approval['frozen_files_sha256']==FREEZE,'Execution freeze continuity')
ck(start['approval_sha256']==sha(ROOT/'provenance/PARENT_EXECUTION_APPROVAL.json') and start['preexec_receipt_sha256']==sha(ROOT/'provenance/PREEXEC_DRIVE_RECEIPT.json'),'Execution approval/readback SHA bindings')
ck(approval['preexec_archive_sha256']==archives[0]['sha256'],'Approval PREEXEC SHA')
ck(finish['retained_calls']==finish['spawned_calls']==finish['planned_calls']==48 and finish['status']=='COMPLETED_UNREVIEWED','Final counts and status')
ck(outer['supervisor_returncode']==0 and not outer['external_timeout'] and outer['launcher_error'] is None and outer['process_group_kill_attempt_completed_before_seal'],'Outer executor clean completion')
ck((ROOT/'raw/supervisor.stdout').stat().st_size==0 and (ROOT/'raw/supervisor.stderr').stat().st_size==0,'Supervisor stdout/stderr empty')
ck(jr('provenance/PREEXEC_DRIVE_RECEIPT.json')['confirmed_at_utc']<start['utc']<finish['utc']<rawmanifest['utc']<jr('provenance/RAW_UNREVIEWED_DRIVE_RECEIPT.json')['confirmed_at_utc']<jr('reports/SUMMARY.json')['utc'],'PREEXEC readback < execution < raw sealing < raw readback < scoring')
expected_limits={'inherited':{'AS_bytes':[512*1024**2,1024*1024**2],'CPU_seconds':[20,20]},'effective':{'AS_bytes':[1024*1024**2,1024*1024**2],'CPU_seconds':[5,5]}}
ck(start['supervisor_limits']==finish['supervisor_effective_limits']==expected_limits['inherited'],'Supervisor actual limits')
matrices={}; refvalid={}; histvalid={}; cells=0
for t in tasks:
    name=t['instance_id']; slot=t['selection_slot']; inp=jr(f'input/{name}.json'); parsed=parse_vrp((ROOT/f'input/{name}.vrp').read_text(),t['K'])
    for sub in ('input/'+name+'.vrp','input/'+name+'.json','references/'+name+'.json'): ck((ROOT/sub).read_bytes()==(oldroot/sub).read_bytes(),'Original source byte equality '+sub)
    ck((ROOT/f'history/S{slot:02d}_TSR.stdout').read_bytes()==(oldroot/f'raw/calls/S{slot:02d}_TSR.stdout').read_bytes(),'Historical TSR stdout copied unchanged '+name)
    ck(set(inp)=={'instance_id','coordinates','demands','capacity','K'},'Normalized input whitelist '+name)
    for k in inp: ck(inp[k]==parsed[k], 'Original VRPLIB versus normalized '+name+' '+k)
    matrix=decimal_matrix(parsed['coordinates']); floatmatrix=[[math.floor(math.hypot(float(a[0]-b[0]),float(a[1]-b[1]))+.5) for b in parsed['coordinates']] for a in parsed['coordinates']]
    ck(matrix==floatmatrix,'All-cell Decimal80 versus EUC_2D float floor metric '+name)
    matrices[name]=digest(compact(matrix)); cells+=len(matrix)**2; inputs[name]=parsed
    ref=jr(f'references/{name}.json'); h=jr(f'history/S{slot:02d}_TSR.stdout')
    rv=validate_solution(parsed,[[0]+r+[0] for r in ref['reference_routes']],ref['reference_integer_cost']); hv=validate_solution(parsed,h['routes'],h['cost'])
    ck(rv['valid'] and hv['valid'] and rv['reported_cost_matches'] and hv['reported_cost_matches'],'Independent original-VRPLIB reference/TSR validation '+name)
    ck(ref['K_ref']==t['K'] and ref['source_instance_id']==name and rv['loads']==ref['loads'] and hv['loads']==h['loads'],'Reference and history K/identity/loads '+name)
    refs[name]=rv['cost'];hist[name]=hv['cost']; refvalid[name]=rv;histvalid[name]=hv
for idx,(e,r) in enumerate(zip(schedule,results)):
    cid=e['call_id']; name=e['instance_id']; a,b=attempts[2*idx:2*idx+2]
    ck({k:r[k] for k in e}==e and {k:a[k] for k in e}==e and a['phase']=='STARTED' and b['phase']=='FINISHED','Unique ordered start/finish '+cid)
    ck({k:v for k,v in b.items() if k not in ('phase','utc')}==r and a['utc']<b['utc'],'Attempt/result agreement '+cid)
    if idx: ck(attempts[2*idx-1]['utc']<a['utc'],'Sequential nonoverlapping execution '+cid)
    ck(r['returncode']==0 and r['process_spawned'] and r['child_reaped'] and r['status']=='UNREVIEWED_PROCESS_SUCCESS','Success/spawn/reap '+cid)
    ck(r['stdout']==f'raw/calls/{cid}.stdout' and r['stderr']==f'raw/calls/{cid}.stderr','Output path '+cid)
    for typ in ('stdout','stderr'):ck(sha(ROOT/r[typ])==r[typ+'_sha256'],'Raw '+typ+' SHA '+cid)
    ck((ROOT/r['stderr']).stat().st_size==0,'Empty worker stderr '+cid)
    inp=jr(f'input/{name}.json'); payload={k:inp[k] for k in ('coordinates','demands','capacity','K')};payload.update(seed=e['seed'],max_runtime_seconds=1.0)
    ck(digest(compact(payload))==r['payload_sha256'],'Whitelisted payload exact byte hash '+cid)
    out=jr(r['stdout']); v=validate_solution(inputs[name],out['routes'],out['reported_cost']); outputs[cid]=out;validations[cid]=v
    ck(v['valid'] and v['reported_cost_matches'] and v['reported_cost_checked'],'Independent original-VRPLIB saved solution '+cid)
    ck(out['solver']=='PyVRP' and out['version']=='0.14.0' and out['algorithm']=='ILS' and out['seed']==e['seed'] and out['max_runtime_seconds']==1.0,'Solver identity/budget '+cid)
    ck(out['solver_is_feasible'] and out['solver_is_complete'] and out['reported_cost']==out['reported_distance']==out['internal_route_cost']==v['cost'] and out['reported_duration_cost']==out['reported_fixed_vehicle_cost']==0,'Objective completeness and cost '+cid)
    ck(out['reported_num_routes']==v['nonempty_routes']==len(out['native_routes'])==len(out['routes']),'Native route count '+cid)
    ck(out['model_matrix_sha256']==matrices[name] and not out['denied_io_events'] and not out['reference_or_history_payload_fields'],'Matrix/IO diagnostics '+cid)
    ck(out['resource_limits']==expected_limits,'Worker actual inherited/effective limits '+cid)
    ck(out['num_iterations']==len(out['stats'])==len(out['stats_runtime_per_iteration']) and out['num_iterations']>0,'Iteration telemetry complete '+cid)
    ck(out['solver_loop_runtime']>=1 and out['solve_wall_seconds_audit_only']>=out['solver_loop_runtime'],'Timed stop telemetry '+cid)
    ck(out['stats'][-1]['best_cost']==out['reported_cost'] and out['stats'][-1]['best_feas'],'Last best telemetry agrees '+cid)
    for k,native in enumerate(out['native_routes']):
        acts=native['activities'];route=out['routes'][k]
        ck([a['node'] for a in acts]==route,'Native-to-saved mapping '+cid+':'+str(k))
        for pos,a in enumerate(acts):
            if pos==0 or pos==len(acts)-1: ck(a=={'type':'DEPOT','idx':0,'location':0,'node':0},'Native depot '+cid+':'+str(k)+':'+str(pos))
            else: ck(a['type']=='CLIENT' and a['idx']+1==a['location']==a['node'],'Native client mapping '+cid+':'+str(k)+':'+str(pos))
        ck(native['distance']==v['route_costs'][k] and native['delivery']==[v['loads'][k]],'Native per-route distance/load '+cid+':'+str(k))
        ck(native['vehicle_type']==native['start_depot']==native['end_depot']==0 and native['num_trips']==1 and native['is_feasible'],'Native vehicle/depot/trip feasibility '+cid+':'+str(k))
r0results=jsonl(priorroot/'raw/results.jsonl');r0attempts=jsonl(priorroot/'raw/attempts.jsonl');r0error=jr('history/PRIOR_FAILED_RUN_AUDIT.json')['stderr'];
ck(len(r0results)==48 and len(r0attempts)==96 and len({r['call_id'] for r in r0results})==48,'r0 48 unique preserved attempts')
for e,r in zip(schedule,r0results):
    ck(r['call_id']==e['call_id'] and r['process_spawned'] and r['returncode']!=0 and (priorroot/r['stdout']).stat().st_size==0 and (priorroot/r['stderr']).read_text()==r0error,'r0 pre-solve startup failure '+e['call_id'])
evidence['r0']={'process_attempts':48,'startup_failures':48,'public_solver_calls':0,'cause':'RLIMIT_AS raised above inherited hard512MiB, before payload read/import/model/solve. Source entrypoint order and identical traceback confirmed.'}
seed_csv=list(csv.DictReader((ROOT/'reports/PER_SEED.csv').open()));inst_csv=list(csv.DictReader((ROOT/'reports/PER_INSTANCE.csv').open())); saved=jr('reports/SAVED_ROUTE_VALIDATION.json')
ck(len(seed_csv)==48 and len(inst_csv)==16 and len(saved['calls'])==48 and len(saved['history_reference_validation'])==16 and saved['optimizer_rerun'] is False,'CSV/validation report complete')
seedgaps=[]; pg={0:[],1:[],2:[]}; rows=[]; raw_seed_rows=[]
for e,r,c,savedcall in zip(schedule,results,seed_csv,saved['calls']):
    cid=e['call_id']; out=outputs[cid];v=validations[cid];name=e['instance_id'];gap=Fraction(100*(v['cost']-refs[name]),refs[name]); seedgaps.append(gap);pg[e['seed']].append(gap)
    wanted={**e,'status':'VALID','cost':v['cost'],'nonempty_routes':v['nonempty_routes'],'iterations':out['num_iterations'],'search_runtime_audit_only':out['solver_loop_runtime'],'process_wall_audit_only':r['wall_seconds_audit_only'],'failure':''}
    ck(set(c)==set(wanted),'PER_SEED complete columns '+cid)
    for k,value in wanted.items(): ck(close(c[k],value) if isinstance(value,(int,float)) else c[k]==value,'PER_SEED '+cid+' '+k)
    ck(savedcall=={'call_id':cid,'valid':True,'errors':[],'validation':v},'Saved independent validation equality '+cid)
    raw_seed_rows.append({'call_id':cid,'instance_id':name,'seed':e['seed'],'cost':v['cost'],'reference_cost':refs[name],'gap_percent':float(gap)})
basegaps=[];histgaps=[];deltas=[]
for t,c,sv in zip(tasks,inst_csv,saved['history_reference_validation']):
    name=t['instance_id'];slot=t['selection_slot'];costs=[validations[f'P{slot:02d}_s{s}']['cost'] for s in (0,1,2)];ref=refs[name];h=hist[name];mean=Fraction(sum(costs),3);bgap=100*(mean-ref)/ref;hgap=Fraction(100*(h-ref),ref);delta=hgap-bgap
    basegaps.append(bgap);histgaps.append(hgap);deltas.append(delta)
    wanted={'instance_id':name,'selection_slot':slot,'reference_cost':ref,'historical_TSR_cost':h,'historical_TSR_reference_gap_percent':float(hgap),'valid_seed_count':3,'planned_seed_count':3,**{f'seed{s}_cost':costs[s] for s in (0,1,2)},'mean3_cost':float(mean),'mean3_reference_gap_percent':float(bgap),'historical_TSR_minus_mean3_gap_pp':float(delta),'historical_TSR_excess_over_mean3_percent':float(100*(h-mean)/mean),'best_of3_cost_secondary':min(costs),'worst_of3_cost_secondary':max(costs),'range3_cost_secondary':max(costs)-min(costs),'sample_SD3_cost_secondary':statistics.stdev(costs),'historical_TSR_vs_mean3':'TSR_HIGHER_COST' if 3*h>sum(costs) else ('EQUAL' if 3*h==sum(costs) else 'TSR_LOWER_COST')}
    ck(set(c)==set(wanted),'PER_INSTANCE complete columns '+name)
    for k,value in wanted.items(): ck(close(c[k],value) if isinstance(value,(int,float)) else c[k]==value,'PER_INSTANCE '+name+' '+k)
    ck(sv=={'instance_id':name,'reference':refvalid[name],'historical_TSR':histvalid[name],'reference_is_not_an_optimality_proof':True},'Saved reference/history validation equality '+name)
    rows.append(wanted)
summary=jr('reports/SUMMARY.json'); metric={'all16_mean_PyVRP_reference_gap_percent':sum(basegaps)/16,'all16_mean_historical_TSR_reference_gap_percent':sum(histgaps)/16,'all16_mean_historical_TSR_minus_PyVRP_gap_pp':sum(deltas)/16}
for key,val in metric.items(): ck(summary[key]==float(val),'Summary exact Fraction-to-float '+key)
ck(summary['valid_calls']==summary['observed_calls']==summary['planned_calls']==48 and summary['planned_instances']==summary['complete_three_seed_tasks']==16,'Summary full denominators')
ck(summary['PyVRP_mean_better_equal_worse_vs_TSR']=={'better':16,'equal':0,'worse':0,'unavailable':0} and all(3*r['historical_TSR_cost']>sum(r[f'seed{s}_cost'] for s in (0,1,2)) for r in rows),'16 exact integer-cross-multiplication wins')
descriptive={'pooled48':quant(seedgaps),'per_seed':{str(s):quant(pg[s]) for s in (0,1,2)},'tasks_with_all3_equal_reference':sum(all(r[f'seed{s}_cost']==r['reference_cost'] for s in (0,1,2)) for r in rows),'tasks_with_at_least1_equal_reference':sum(any(r[f'seed{s}_cost']==r['reference_cost'] for s in (0,1,2)) for r in rows)}
desc=jr('reports/DESCRIPTIVE_SEED_SUMMARY.json')
for group in ('pooled48','per_seed'):
    if group=='pooled48': pairs=[(descriptive[group],desc[group])]
    else:pairs=[(descriptive[group][s],desc[group][s]) for s in ('0','1','2')]
    for own,reported in pairs:
        for key,val in own.items(): ck(close(reported[key],val),'Posthoc descriptive '+group+' '+key)
for key in ('tasks_with_all3_equal_reference','tasks_with_at_least1_equal_reference'):ck(desc[key]==descriptive[key],key)
for direction,pred in [('below',lambda g:g<0),('above',lambda g:g>0)]:
    selected=[{'instance_id':x['instance_id'],'seed':x['seed'],'cost':x['cost'],'reference_cost':x['reference_cost'],'gap_percent':x['gap_percent'],'equal_reference':x['gap_percent']==0,'below_reference':x['gap_percent']<0} for x in raw_seed_rows if pred(x['gap_percent'])]
    ck(desc[direction+'_reference_rows']==selected,'Posthoc '+direction+'-reference rows exact raw agreement')
report=(ROOT/'reports/REPORT_ZH.txt').read_text()
for token in ['r0保留48次进程尝试','实际公共求解0次','r1为单独冻结','主结果用每题三次成本均值','best-of-3仅','不比较速度或等算力','不是本研究证明的严格最优值','不是新的盲测或确认性研究']:ck(token in report,'Main report disclosure '+token)
evidence['resource_usage_audit_only']={'worker_process_cpu_sum_seconds':sum(r['cpu_seconds_audit_only'] for r in results),'supervisor_cpu_seconds':finish['supervisor_cpu_seconds_audit_only'],'worker_plus_supervisor_cpu_seconds':sum(r['cpu_seconds_audit_only'] for r in results)+finish['supervisor_cpu_seconds_audit_only'],'worker_process_cpu_max_seconds':max(r['cpu_seconds_audit_only'] for r in results),'worker_process_wall_max_seconds':max(r['wall_seconds_audit_only'] for r in results),'solver_loop_wall_min_seconds':min(o['solver_loop_runtime'] for o in outputs.values()),'solver_loop_wall_max_seconds':max(o['solver_loop_runtime'] for o in outputs.values()),'worker_maxrss_max_KiB':max(o['worker_maxrss_KiB_audit_only'] for o in outputs.values()),'supervisor_maxrss_KiB':finish['supervisor_maxrss_KiB_audit_only'],'outer_executor_wall_seconds':outer['wall_seconds_audit_only'],'scope':'AS hard ceilings sum2048MiB, current soft sum1536MiB; not RSS. Configured CPU limits sum260s, not an exact observed end-to-end bound. Excludes outer packaging, installation and review.'}
evidence.update({'status':'PASS','utc':datetime.now(timezone.utc).isoformat(),'scope':'Offline independent saved-evidence audit; no optimizer/model/package import, new experiment, source/report rerun, install, upload, or existing frozen/raw mutation. Does not assert omniscient OS process attestation or native syscall isolation.','frozen_files_sha256':FREEZE,'raw_archive_sha256':RAW_SHA,'directed_input_matrix_cells_recomputed':cells,'r1_plan_start_finish_result_valid_counts':[48,48,48,48,48],'no_extra_attempts_evidence':'Exactly48 ordered unique scheduled IDs;96 alternating timestamped start/finish rows;48 results;96 exact stdout/stderr paths;exclusive source guards;no retry loop;frozen source/raw archive agreement. Scope is recorded execution, not proof of absence of activity outside evidence.','independently_validated_saved_routes':{'PyVRP':48,'reference':16,'historical_TSR':16},'primary_metrics':{k:{'fraction':str(v),'float':float(v)} for k,v in metric.items()},'descriptive_posthoc':descriptive,'per_instance':rows,'per_seed':raw_seed_rows,'checks_passed':len(checks),'check_log_sha256':digest(compact(checks)),'checked_report_sha256':{str(p.relative_to(ROOT)):sha(p) for p in (ROOT/'reports').glob('*') if p.is_file()},'audit_script_sha256':sha(__file__),'mandatory_interpretation':'On this fixed16-task panel, homemade sequential local search remains materially behind the mature PyVRP baseline. Prior TSR-over-TRS local benefits do not establish competitive/SOTA algorithm quality. Mechanism/automatic scheduling exploration remains possible; no innovation, significance, optimality, equal-compute, speed or universal superiority claim.'})
# Recheck immutable boundary at end, after all analysis.
verify_manifest(ROOT,frozen['files']);verify_manifest(ROOT,rawmanifest['files']);verify_manifest(oldroot,old['files'],True);verify_manifest(priorroot,prior['files'],True)
output=ROOT/'independent_review/POSTRUN_INDEPENDENT_AUDIT.json'
with output.open('x') as f:json.dump(evidence,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
print(json.dumps({'status':'PASS','output':str(output),'sha256':sha(output),'checks':evidence['checks_passed'],'primary':evidence['primary_metrics'],'descriptive':descriptive,'resource':evidence['resource_usage_audit_only']},ensure_ascii=False,indent=2))
