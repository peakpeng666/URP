from common import *
from itertools import combinations_with_replacement,product
from functools import lru_cache
from pruned_solver import tight_capacity_test,bounded_partition
from capacity_solver import bounded_partition as original
@lru_cache(None)
def exhaustive(dem,res):
 # Independent all labeled-bin assignments recurrence: no symmetry or new pruning.
 if not dem:return True
 for i,room in enumerate(res):
  if dem[0]<=room:
   rr=list(res);rr[i]-=dem[0]
   if exhaustive(dem[1:],tuple(rr)):return True
 return False
count=pruned=feasible=zero_cases=0
with (ROOT/'reports/toy_states.jsonl').open('x') as out:
 for Q in range(1,6):
  for K in range(1,4):
   for residual in combinations_with_replacement(range(Q+1),K):
    for n in range(6):
     for dem in combinations_with_replacement(range(1,Q+1),n):
      feasible_case=exhaustive(dem,residual);flag,tight,scanned=tight_capacity_test(list(dem),list(residual))
      assert not (flag and feasible_case),(dem,residual)
      count+=1;pruned+=flag;feasible+=feasible_case
      out.write(json.dumps([Q,K,list(dem),list(residual),feasible_case,flag])+'\n')
 # Zero demand and empty/zero capacity cases explicitly exhaustive.
 for K in range(1,4):
  for residual in combinations_with_replacement(range(4),K):
   for n in range(5):
    for dem in combinations_with_replacement(range(4),n):
     truth=exhaustive(dem,residual);flag,_,_=tight_capacity_test(list(dem),list(residual))
     assert not(flag and truth);zero_cases+=1
     out.write(json.dumps(['zero_edge',K,list(dem),list(residual),truth,flag])+'\n')
full=0
for Q in range(1,6):
 for K in range(1,4):
  for n in range(7):
   for dem in combinations_with_replacement(range(1,Q+1),n):
    truth=exhaustive(dem,(Q,)*K)
    a,ar=original([0,*dem],Q,K,100000);b,br=bounded_partition([0,*dem],Q,K,100000)
    assert (a is not None)==(b is not None)==truth
    assert not ar['limit_reached'] and not br['limit_reached'];full+=1
boundaries=[]
for dem,res,expected,label in [([], [0,2],False,'empty'),([2],[0,2],False,'zero_residual'),([2],[1,2],False,'underfull_counterexample'),([2,2],[1,3],True,'full_impossible'),([0,2],[1,1],False,'zero_demand_conservative')]:
 got=tight_capacity_test(dem,res)[0];assert got==expected
 boundaries.append({'label':label,'demands':dem,'residual':res,'pruned':got,'feasible':exhaustive(tuple(dem),tuple(res))})
dump(ROOT/'reports/TOYS.json',{'passed':True,'positive_state_cases':count,'positive_state_prunes':pruned,'positive_feasible':feasible,'zero_edge_cases':zero_cases,'initial_problem_comparisons':full,'unsafe_prunes':0,'boundaries':boundaries,'state_trace_sha256':sha(ROOT/'reports/toy_states.jsonl'),'scope':'Q1..5 K1..3 remaining n0..5 demand multisets1..Q; all residual multisets0..Q; initial n0..6; zero demand supplementary Q3 n0..4','oracle':'exhaustive labeled-bin assignments, independently implemented; no pruning'} )
print('Necessary-condition exhaustive tests passed',count,zero_cases,full)
