import random,sys,platform,ast
from common import *
BASE=Path('/workspace/shared/capacity_fallback_scaling_20261008')
assert read(ROOT/'reports/TOYS.json')['passed']
protocol={'utc':utc(),'base_seed':2026100803011200,'n':[9,27,54],'Q':9,'K':'n/3 upper bound','families':['tight','full_random','loose'],'replicates':4,'arms':['capacity_solver','pruned_solver'],'calls':72,'geometry':'independent uniform(0,100) x,y for depot and all customers','seed_rule':'base+10000*n+100*family_index+rep(0..3); demand seed +100000000; shuffle seed +200000000','tight':'repeat [4,4,4,3,3,3,2,2,2], then shuffle customer labels; mechanism-associated exploratory family','full_random':'each vehicle independently uniformly samples from all 28 ordered positive integer triples summing to9; concatenate and shuffle customer labels','loose':'all1','dfs_entered_node_limit':256,'delta_limit':100000,'local_search':False,'main_cpu_hard':30,'main_wall':60,'toy_cpu_hard':10,'toy_wall':20,'selection':'all generated cases retained once; no retry/tuning/filtering','witness_policy':'generator saves separate witness; scientific runner does not open or hash witness; postrun independent witness check only','source_policy':'baseline byte identical; candidate changes only necessary-condition predicate, counters, prune trace','interpretation':'same nodes not same CPU; no universal or real-distribution claim; initial feasibility only'}
dump(ROOT/'freeze/PRE_GENERATION.json',protocol)
old_geometry=[]
for path in [BASE,Path('/workspace/shared/capacity_partition_fallback_20261008')]:
 for p in (path/'input').glob('*.json'):
  raw=read(p);old_geometry.append(digest(sorted(raw['coordinates'])))
old_set=set(old_geometry);triples=[(a,b,9-a-b) for a in range(1,8) for b in range(1,9-a)];assert len(triples)==28
manifest=[];schedule=[]
for n in protocol['n']:
 for fi,family in enumerate(protocol['families']):
  for rep in range(4):
   ident=f'N{n:02d}-{family}-R{rep+1}';seed=protocol['base_seed']+10000*n+100*fi+rep; rng=random.Random(seed)
   xy=[[rng.uniform(0,100),rng.uniform(0,100)] for _ in range(n+1)]
   if family=='tight':d=[4,4,4,3,3,3,2,2,2]*(n//9);groups=[[j+i,j+i+3,j+i+6] for j in range(1,n+1,9) for i in range(3)]
   elif family=='full_random':dr=random.Random(seed+100000000);d=[v for _ in range(n//3) for v in dr.choice(triples)];groups=[list(range(j,j+3)) for j in range(1,n+1,3)]
   else:d=[1]*n;groups=[list(range(j,j+3)) for j in range(1,n+1,3)]
   perm=list(range(1,n+1));random.Random(seed+200000000).shuffle(perm);dem=[0]+[0]*n
   for oldid,newid in enumerate(perm,1):dem[newid]=d[oldid-1]
   witness=[[perm[j-1] for j in group] for group in groups]
   raw={'instance_id':ident,'n':n,'family':family,'replicate':rep+1,'coordinates':xy,'demands':dem,'capacity':9,'K':n//3}
   ordered=digest(xy);unordered=digest(sorted(xy));assert unordered not in old_set
   dump(ROOT/'input'/f'{ident}.json',raw);dump(ROOT/'witness'/f'{ident}.json',{'groups':witness})
   manifest.append({'instance_id':ident,'geometry_seed':seed,'demand_seed':seed+100000000,'shuffle_seed':seed+200000000,'ordered_geometry_sha256':ordered,'unordered_geometry_sha256':unordered,'prior_collision':False})
   # Alternate arm order over replications to avoid always paying first-call costs in baseline.
   arms=protocol['arms'] if rep%2==0 else protocol['arms'][::-1]
   schedule.extend({'instance_id':ident,'arm':arm} for arm in arms)
assert len({x['unordered_geometry_sha256'] for x in manifest})==36
up=BASE/'source/capacity_solver.py';assert sha(up)==sha(ROOT/'source/capacity_solver.py')
# All non-partition inherited functions byte-for-byte equal by AST source extraction.
a=ast.parse((ROOT/'source/capacity_solver.py').read_text());b=ast.parse((ROOT/'source/pruned_solver.py').read_text())
sa=(ROOT/'source/capacity_solver.py').read_text();sb=(ROOT/'source/pruned_solver.py').read_text()
checks={}
for node in a.body:
 if isinstance(node,(ast.FunctionDef,ast.ClassDef)) and node.name!='bounded_partition':
  other=next(x for x in b.body if isinstance(x,type(node)) and x.name==node.name)
  checks[node.name]=ast.get_source_segment(sa,node)==ast.get_source_segment(sb,other)
assert all(checks.values())
dump(ROOT/'provenance/SOURCE_CHECKS.json',{'baseline_upstream':str(up),'baseline_sha256':sha(up),'baseline_byte_identical':True,'unchanged_other_functions':checks,'prior_geometry_count':len(old_geometry)})
dump(ROOT/'freeze/GEOMETRY_MANIFEST.json',manifest);dump(ROOT/'freeze/SCHEDULE.json',schedule)
dump(ROOT/'receipts/ENVIRONMENT.json',{'utc':utc(),'python':sys.version,'platform':platform.platform(),'api_calls':0,'installs':0,'uploads':0})
files=[p for folder in ['source','input','witness','provenance','freeze'] for p in (ROOT/folder).rglob('*') if p.is_file()]
dump(ROOT/'freeze/PRE_RUN_FREEZE.json',{'utc':utc(),'sha256':{str(p.relative_to(ROOT)):sha(p) for p in sorted(files)},'toy_summary_sha256':sha(ROOT/'reports/TOYS.json'),'proof_sha256':sha(ROOT/'reports/PROOF_ZH.txt')})
print('36 inputs and 72 initializations frozen once, after safety tests.')
