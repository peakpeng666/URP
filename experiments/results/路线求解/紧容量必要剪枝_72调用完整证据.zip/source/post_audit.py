from common import *
from collections import Counter
rows=[json.loads(x) for x in (ROOT/'raw/results.jsonl').read_text().splitlines()]
timing={'measured_cpu_seconds','measured_wall_seconds','solver_cpu_seconds','solver_wall_seconds','cpu_seconds','wall_seconds'}
def scrub(x):
 if isinstance(x,dict):return {k:scrub(v) for k,v in x.items() if k not in timing and k!='arm'}
 if isinstance(x,list):return [scrub(v) for v in x]
 return x
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
pairs=[];calls=0;prunes=0
for ident in sorted({x['instance_id'] for x in rows}):
 a=next(x for x in rows if x['instance_id']==ident and x['arm']=='capacity_solver');b=next(x for x in rows if x['instance_id']==ident and x['arm']=='pruned_solver')
 bypass=not a['initialization'].get('capacity_partition');ffd_success=bypass and a['initialization']['fallback_triggered']
 record={'instance_id':ident,'DFS_bypassed':bypass,'FFD_succeeded':ffd_success}
 if bypass:
  ca=canonical(scrub(a));cb=canonical(scrub(b));assert ca==cb
  record.update(non_timing_all_fields_bitwise_equal=True,canonical_sha256=__import__('hashlib').sha256(ca).hexdigest())
 if a['status']=='SUCCESS':
  assert canonical(a['output'])==canonical(b['output']);record['successful_common_output_bitwise_equal']=True
  for k in ['deltas','delta_by_kind','matrix_distances','objective_edges','budget_checks']:assert a[k]==b[k]
 p=b['initialization'].get('capacity_partition')
 if p:
  calls+=1;raw=read(ROOT/'input'/f'{ident}.json');order=sorted(range(1,len(raw['demands'])),key=lambda j:(-raw['demands'][j],j))
  assert len(p['prune_trace'])==p['prunes']
  for e in p['prune_trace']:
   prunes+=1;assert sorted(j for g in e['groups'] for j in g)==sorted(order[:e['depth']])
   assert e['remaining']==[raw['demands'][j] for j in order[e['depth']:]]
   assert e['residual']==[9-sum(raw['demands'][j] for j in group) for group in e['groups']]
   assert len(e['residual'])==raw['K'] and 1<=e['entered_node']<=p['nodes']<=256
 pairs.append(record)
dump(ROOT/'reports/POST_AUDIT.json',{'all_passed':True,'pairs':pairs,'bypass_count':sum(x['DFS_bypassed'] for x in pairs),'actual_FFD_success_count':sum(x['FFD_succeeded'] for x in pairs),'common_success_output_equal':sum(x.get('successful_common_output_bitwise_equal',False) for x in pairs),'candidate_DFS_calls':calls,'fully_reconstructed_prune_events':prunes,'correction':'Initial analyzer checked a nonexistent delta_kinds key as null; this supplemental audit explicitly checks actual delta_by_kind and ALL non-timing fields by canonical JSON bytes on bypass cases. Frozen source was not edited and main was not rerun.'})
(ROOT/'reports/AUDIT_ADDENDUM_ZH.txt').write_text('补充自审（不是独立外部审计）：25例未调用DFS，其全部非时序字段经规范JSON字节比较一致，包含正确delta_by_kind字段。初版分析器误写delta_kinds而比较两侧空值，本补充检查纠正覆盖缺口；未改冻结源码或重跑。28例共同成功输出字节一致；106次剪枝轨迹逐项重建客户、余量、剩余需求、节点上限正确。\nCPU逐初始化观测呈约4ms跳变，多次显示0不意味着免费；不得据此估计可靠加速比，主跑进程wait4 CPU为0.160463s。\n审计补充与打包脚本为主跑结束后新增，不属于事前源码冻结集合；不更改算法、输入、主结果。\n')
print(json.dumps({'bypass':sum(x['DFS_bypassed'] for x in pairs),'FFD_success':sum(x['FFD_succeeded'] for x in pairs),'prunes':prunes}))
