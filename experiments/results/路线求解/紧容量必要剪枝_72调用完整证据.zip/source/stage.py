import os,resource,signal,subprocess,sys,time
from common import *
name=sys.argv[1];cpu_limit=int(sys.argv[2]);wall_limit=int(sys.argv[3]);script=sys.argv[4]
receipt=ROOT/'receipts'/f'{name}.json'
if receipt.exists():raise SystemExit('Stage already ran; no retry')
start=time.perf_counter()
def pre():
 os.setsid();resource.setrlimit(resource.RLIMIT_CPU,(cpu_limit-1,cpu_limit))
with (ROOT/'receipts'/f'{name}.stdout.log').open('x') as out,(ROOT/'receipts'/f'{name}.stderr.log').open('x') as err:
 child=subprocess.Popen([sys.executable,'-B',str(ROOT/'source'/script)],stdout=out,stderr=err,preexec_fn=pre)
 killed=False
 while True:
  pid,status,usage=os.wait4(child.pid,os.WNOHANG)
  if pid:break
  if time.perf_counter()-start>=wall_limit:
   killed=True;os.killpg(child.pid,signal.SIGKILL);pid,status,usage=os.wait4(child.pid,0);break
  time.sleep(.01)
 code=os.waitstatus_to_exitcode(status);child.returncode=code
 record={'utc':utc(),'stage':name,'exit_code':code,'user_cpu_seconds':usage.ru_utime,'system_cpu_seconds':usage.ru_stime,'total_cpu_seconds':usage.ru_utime+usage.ru_stime,'wall_seconds':time.perf_counter()-start,'cpu_hard':cpu_limit,'wall_limit':wall_limit,'wall_kill':killed,'complete':code==0,'no_retry':True}
 dump(receipt,record);print(json.dumps(record));sys.exit(code)
