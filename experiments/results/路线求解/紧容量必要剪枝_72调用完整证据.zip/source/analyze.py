import collections,csv,math
from common import *
from audit import check
assert (ROOT/'raw/FINISHED.json').exists();verify()
rows=[json.loads(x) for x in (ROOT/'raw/results.jsonl').read_text().splitlines()];assert len(rows)==72
metrics=[];checked=[];witness=[];pairs=[]
for ident in sorted({x['instance_id'] for x in rows}):
 raw=read(ROOT/'input'/f'{ident}.json');g=read(ROOT/'witness'/f'{ident}.json')['groups'];flat=[j for group in g for j in group]
 assert sorted(flat)==list(range(1,raw['n']+1)) and len(g)<=raw['K']
 loads=[sum(raw['demands'][j] for j in group) for group in g];assert max(loads)<=9
 witness.append({'instance_id':ident,'accepted':True,'loads':loads})
 pair=[x for x in rows if x['instance_id']==ident];base=next(x for x in pair if x['arm']=='capacity_solver');cand=next(x for x in pair if x['arm']=='pruned_solver')
 if not base['initialization'].get('capacity_partition'):
  # All non-timing scientific results must be byte-identical whenever DFS was bypassed.
  keys=['status','stop_reason','error_type','initialization','output','deltas','delta_kinds']
  evidence={k:base.get(k)==cand.get(k) for k in keys};assert all(evidence.values())
  pairs.append({'instance_id':ident,'DFS_bypassed':True,'non_timing_bitwise_equal':True,'fields':evidence})
 else:pairs.append({'instance_id':ident,'DFS_bypassed':False,'base_status':base['status'],'pruned_status':cand['status']})
for row in rows:
 raw=read(ROOT/'input'/f"{row['instance_id']}.json");d=row['initialization'];partition=d.get('capacity_partition',{})
 if row['output'] is not None:
  result=check(raw,row['output'],raw['K']);assert result['accepted'];checked.append({'instance_id':row['instance_id'],'arm':row['arm'],**result})
 else:checked.append({'instance_id':row['instance_id'],'arm':row['arm'],'output_absent':True,'not_an_infeasibility_claim':True})
 assert partition.get('nodes',0)<=256
 for event in partition.get('prune_trace',[]):
  assert sum(event['remaining'])==sum(event['residual'])
  assert any(0<r<min(event['remaining']) for r in event['residual'])
 metrics.append({'instance_id':row['instance_id'],'n':row['n'],'family':row['family'],'arm':row['arm'],'status':row['status'],'nodes':partition.get('nodes',0),'limit_reached':partition.get('limit_reached',False),'prunes':partition.get('prunes',0),'guard_checks':partition.get('guard_checks',0),'tight_checks':partition.get('tight_checks',0),'residual_checks':partition.get('residual_checks',0),'cpu_seconds':row['measured_cpu_seconds'],'wall_seconds':row['measured_wall_seconds'],'deltas':row.get('deltas'),'DFS_invoked':bool(partition),'ffd_failed':bool(d.get('original_ffd_failure'))})
summary=[]
for n in [9,27,54]:
 for family in ['tight','full_random','loose']:
  for arm in ['capacity_solver','pruned_solver']:
   rr=[r for r in metrics if r['n']==n and r['family']==family and r['arm']==arm]
   summary.append({'n':n,'family':family,'arm':arm,'success':sum(r['status']=='SUCCESS' for r in rr),'failure':sum(r['status']!='SUCCESS' for r in rr),'node_limit_hits':sum(r['limit_reached'] for r in rr),'max_nodes':max(r['nodes'] for r in rr),'total_nodes':sum(r['nodes'] for r in rr),'prunes':sum(r['prunes'] for r in rr),'guard_checks':sum(r['guard_checks'] for r in rr),'tight_checks':sum(r['tight_checks'] for r in rr),'residual_checks':sum(r['residual_checks'] for r in rr),'cpu_seconds':sum(r['cpu_seconds'] for r in rr),'wall_seconds':sum(r['wall_seconds'] for r in rr)})
dump(ROOT/'reports/SUMMARY.json',summary);dump(ROOT/'reports/OUTPUT_CHECKS.json',checked);dump(ROOT/'reports/WITNESS_CHECKS.json',witness);dump(ROOT/'reports/PAIR_CHECKS.json',pairs)
with (ROOT/'reports/METRICS.csv').open('x',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(metrics[0]));w.writeheader();w.writerows(metrics)
lines=['紧容量必要条件剪枝：一次性初始化实验（待独立审计）','安全性：证明见PROOF_ZH；穷举见TOYS。全部输出独立复算覆盖、容量、车辆上限、成本；36构造见证只在此事后分析解析。','72初始化，无后续搜索。原fallback256与新增剪枝fallback256；节点均包括根/完成叶，剪枝状态也扣已入节点。','每组4例；成功/失败如下：']
for x in summary:lines.append(f"n={x['n']} {x['family']} {x['arm']}: {x['success']}/{x['failure']}；限额命中{x['node_limit_hits']}，节点合计{x['total_nodes']}，剪枝{x['prunes']}，检查{x['guard_checks']}/{x['tight_checks']}/{x['residual_checks']}，实际CPU={x['cpu_seconds']:.6f}s")
lines+=['检查三数为：非终端状态调用/满载状态/实际逐箱检查数；还存在求和、min和日志开销。相同节点上限不等于同CPU；单次亚毫秒计时不适合作稳定性能结论。','所有未调用DFS例的status/output/完整initialization与delta非时序数据一致。失败无输出，构造失败不等于数学不可行。','tight是机制关联探索；full_random是每车正整数三元组满载生成的特定分布，非现实普适分布；loose全1为宽松对照。36例不能支持一般分布改进或路径搜索质量结论。','准备、玩具、主跑、分析、打包分别有资源收据；人工编辑/工具传输未作为可测子进程CPU汇总，不能把主跑CPU称全任务成本。无模型/API、安装、购买、上传；原目录未改。']
(ROOT/'reports/REPORT_ZH.txt').write_text('\n'.join(lines)+'\n')
print('\n'.join(lines))
