from common import *
import zipfile
verify()
receipts={p.stem:read(p) for p in (ROOT/'receipts').glob('*.json') if p.stem!='ENVIRONMENT'}
dump(ROOT/'reports/RESOURCE_ACCOUNTING.json',{'stages':receipts,'measured_subprocess_cpu_before_packaging':sum(v.get('total_cpu_seconds',0) for v in receipts.values()),'packaging_receipt':'receipts/package.json is external to this archive and written by supervisor only after archive closes','unmetered':'Authoring, interactive tool calls, parent orchestration, initial source copies and packaging supervisor CPU not included; no total task CPU claim','no_scientific_rerun':True})
(ROOT/'README.txt').write_text('紧容量必要剪枝实验：36新输入×2臂=72初始化；唯一主跑，无后续搜索。\n先读 reports/REPORT_ZH.txt 与 reports/AUDIT_ADDENDUM_ZH.txt，后看 PROOF_ZH.txt、TOYS.json、POST_AUDIT.json。\n原始结果 raw/results.jsonl；冻结协议 freeze/PRE_GENERATION.json、PRE_RUN_FREEZE.json；差异 provenance/NECESSARY_PRUNE.patch；源码 source/。\n所有构造见证只生成到 witness/，科学runner从未打开/哈希这些文件；准备与事后审计会核hash、事后分析校验见证。\n源码中 post_audit.py、package.py 是科学运行后增加的审计/封包工具，不在事前冻结列表；其他冻结内容仍验证一致。\n打包进程收据 receipts/package.json 在封包关闭后产生，故放包外；归档hash也在包外。\n')
exclude={'SHA256SUMS.txt','archive.sha256','tight_capacity_pruning_20261008.zip','receipts/package.json','receipts/package.stdout.log','receipts/package.stderr.log'}
files=sorted(p for p in ROOT.rglob('*') if p.is_file() and str(p.relative_to(ROOT)) not in exclude and '__pycache__' not in p.parts)
(ROOT/'SHA256SUMS.txt').write_text(''.join(f'{sha(p)}  {p.relative_to(ROOT)}\n' for p in files))
with zipfile.ZipFile(ROOT/'tight_capacity_pruning_20261008.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
 for p in files+[ROOT/'SHA256SUMS.txt']:z.write(p,str(p.relative_to(ROOT)))
(ROOT/'archive.sha256').write_text(sha(ROOT/'tight_capacity_pruning_20261008.zip')+'  tight_capacity_pruning_20261008.zip\n')
