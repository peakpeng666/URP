紧容量必要剪枝实验：36新输入×2臂=72初始化；唯一主跑，无后续搜索。
先读 reports/REPORT_ZH.txt 与 reports/AUDIT_ADDENDUM_ZH.txt，后看 PROOF_ZH.txt、TOYS.json、POST_AUDIT.json。
原始结果 raw/results.jsonl；冻结协议 freeze/PRE_GENERATION.json、PRE_RUN_FREEZE.json；差异 provenance/NECESSARY_PRUNE.patch；源码 source/。
所有构造见证只生成到 witness/，科学runner从未打开/哈希这些文件；准备与事后审计会核hash、事后分析校验见证。
源码中 post_audit.py、package.py 是科学运行后增加的审计/封包工具，不在事前冻结列表；其他冻结内容仍验证一致。
打包进程收据 receipts/package.json 在封包关闭后产生，故放包外；归档hash也在包外。
