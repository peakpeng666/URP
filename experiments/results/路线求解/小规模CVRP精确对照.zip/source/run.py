"""Single frozen main workload; failures remain data; never retry."""
import importlib.util,json,math,os,sys,time,traceback
from common import ROOT,read,dump,verify,utc
import audit,oracle
spec=importlib.util.spec_from_file_location('legacy',ROOT/'source/legacy/experiment.py');legacy=importlib.util.module_from_spec(spec);spec.loader.exec_module(legacy)

def main():
    cfg=read(ROOT/'freeze/PROTOCOL.json');verify();start=time.perf_counter();cpu=time.process_time()
    dump(ROOT/'raw/STARTED.json',{'utc':utc(),'pid':os.getpid(),'python':sys.version,'cpu_limit':90,'wall_limit':150,'launch_number':1,'affinity':sorted(os.sched_getaffinity(0))})
    phase={};t=time.process_time();units=audit.unit_tests();cross=[]
    for raw in read(ROOT/'input/CROSSCHECK_FIXTURES.json'):
        got=oracle.solve(raw);ref=audit.brute(raw);checks=[]
        for k,exact in got['by_k'].items():
            b=ref['by_k'][k];ok=(exact is None)==(b is None);residual=None
            if exact is not None and b is not None:
                residual=exact['cost']-b['cost'];ok=ok and math.isclose(exact['cost'],b['cost'],abs_tol=1e-8,rel_tol=1e-10)
                ok=ok and audit.check(raw,exact,int(k))['accepted'] and audit.check(raw,b,int(k))['accepted']
            checks.append({'K':int(k),'oracle':exact,'brute':b,'residual':residual,'pass':ok})
        cross.append({'id':raw['instance_id'],'n':len(raw['demands'])-1,'enumerated_candidates':ref['candidates'],'feasible_candidates':ref['capacity_feasible_candidates'],'checks':checks})
    phase['pre_main_oracle_crosscheck_and_unit_cpu']=time.process_time()-t
    success=all(c['pass'] for row in cross for c in row['checks'])
    dump(ROOT/'raw/ORACLE_CROSSCHECK.json',{'unit_tests':units,'fixtures':cross,'all_passed':success,'numerical_only':True})
    if not success:raise RuntimeError('Oracle crosscheck failed, no formal optimization launched')
    oracles={};phase['main_oracle_cpu']=0.;phase['main_heuristic_cpu']=0.;phase['independent_in_main_audit_cpu']=0.
    with (ROOT/'raw/ORACLES.jsonl').open('x') as f:
        for e in read(ROOT/'freeze/INPUT_MANIFEST.json'):
            raw=read(ROOT/e['input_file']);t=time.process_time();out=oracle.solve(raw);elapsed=time.process_time()-t;phase['main_oracle_cpu']+=elapsed
            audits={k:audit.check(raw,v,int(k)) if v else None for k,v in out['by_k'].items()}
            record={**e,'oracle':out,'independent_audit_by_k':audits,'cpu_seconds':elapsed};oracles[e['geometry_id']]=record
            f.write(json.dumps(record,allow_nan=False)+'\n');f.flush()
            assert all(a['accepted'] for a in audits.values() if a)
    failures=[]
    with (ROOT/'raw/TRAJECTORIES.jsonl').open('x') as f:
        for call in read(ROOT/'freeze/SCHEDULE.json'):
            r={**call,'started_utc':utc()}
            if time.process_time()>85 or time.perf_counter()-start>138:
                r.update(status='not_run_global_gate');failures.append({'run_id':call['run_id'],'status':r['status']})
            else:
                try:
                    raw=read(ROOT/call['input_file']);instance=legacy.from_dict(raw);t=time.process_time()
                    result=legacy.run_one(instance,call['pair'],call['search_seed'],cfg['iterations'],{'delta_limit':cfg['delta_limit'],'cpu_limit_seconds':cfg['per_trajectory_cpu_seconds'],'wall_limit_seconds':cfg['per_trajectory_wall_seconds']})
                    elapsed=time.process_time()-t;phase['main_heuristic_cpu']+=elapsed;t=time.process_time()
                    a=audit.check(raw,result['output'],9);b=audit.check(raw,result['baseline'],9);a3=audit.check(raw,result['output'],3)
                    optimum=oracles[call['geometry_id']]['oracle']['by_k']['9']['cost'];opt3=oracles[call['geometry_id']]['oracle']['by_k']['3']
                    valid=a['accepted'] and b['accepted'] and result['deltas']==cfg['delta_limit'] and result['stop_reason']=='delta_budget' and result['error'] is None
                    r.update(status='complete' if valid else 'failed_or_incomplete',result=result,independent_audit=a,baseline_audit=b,K3_diagnostic_audit=a3,primary_optimum=optimum,raw_gap_percent=100*(a['cost']/optimum-1) if a['accepted'] else None,optimal_hit=bool(a['accepted'] and abs(a['cost']-optimum)<=max(1e-8,1e-10*abs(optimum))),K3_feasible_gap_percent=100*(a3['cost']/opt3['cost']-1) if a3['accepted'] and opt3 else None,outer_call_cpu_seconds=elapsed)
                    phase['independent_in_main_audit_cpu']+=time.process_time()-t
                    if not valid:failures.append({'run_id':call['run_id'],'status':r['status'],'stop_reason':result['stop_reason'],'error':result['error']})
                except Exception as ex:
                    r.update(status='runner_exception',error={'type':type(ex).__name__,'message':str(ex),'traceback':traceback.format_exc()});failures.append({'run_id':call['run_id'],'status':r['status'],'error':r['error']})
            r['finished_utc']=utc();f.write(json.dumps(r,ensure_ascii=False,allow_nan=False)+'\n');f.flush()
    dump(ROOT/'failures/FAILURES.json',{'count':len(failures),'rows':failures,'retries':0})
    verify();dump(ROOT/'raw/COMPLETION.json',{'utc':utc(),'phase_cpu':phase,'process_cpu_seconds':time.process_time(),'elapsed_cpu_seconds':time.process_time()-cpu,'elapsed_wall_seconds':time.perf_counter()-start,'expected_rows':128,'failure_count':len(failures),'all_frozen_hashes_unchanged':True,'external_api_calls':0,'model_calls':0,'dependency_installations':0,'uploads':0})
    print(json.dumps({'done':True,'failures':len(failures),'cpu':time.process_time(),'wall':time.perf_counter()-start}))
if __name__=='__main__':
    try:main()
    except BaseException as ex:
        dump(ROOT/'failures/FATAL.json',{'utc':utc(),'type':type(ex).__name__,'message':str(ex),'traceback':traceback.format_exc()});raise
