"""Frozen read-only numerical audit and descriptive geometry-level analysis."""
import csv,json,math,statistics
from common import ROOT,read,dump,verify,sha,utc
import audit

def lines(path):return [json.loads(x) for x in path.read_text().splitlines() if x.strip()] if path.exists() else []
def mean(values):return statistics.mean(values) if values else None

def main():
    verify();cfg=read(ROOT/'freeze/PROTOCOL.json');schedule=read(ROOT/'freeze/SCHEDULE.json');entries=read(ROOT/'freeze/INPUT_MANIFEST.json');rows=lines(ROOT/'raw/TRAJECTORIES.jsonl');orows=lines(ROOT/'raw/ORACLES.jsonl');oracles={r['geometry_id']:r for r in orows};row_by_id={r['run_id']:r for r in rows}
    missing=[r for r in schedule if r['run_id'] not in row_by_id];checks=[];audited_routes=0;audited_tours=0
    assert len(row_by_id)==len(rows),'Duplicate trajectory IDs'
    for e in entries:
        raw=read(ROOT/e['input_file']);o=oracles.get(e['geometry_id'])
        if o:
            for k,v in o['oracle']['by_k'].items():
                if v:
                    assert audit.check(raw,v,int(k))['accepted'];audited_routes+=1
            for mask,t in o['oracle']['tours'].items():
                ids=t['route'][1:-1];assert len(ids)==len(set(ids)) and sum(1<<(j-1) for j in ids)==int(mask)
                assert sum(raw['demands'][j] for j in ids)==t['load']<=raw['capacity']
                edges=[]
                for a,b in zip(t['route'],t['route'][1:]):
                    ax,ay=raw['coordinates'][a];bx,by=raw['coordinates'][b];edges.append(math.sqrt((ax-bx)**2+(ay-by)**2))
                assert math.isclose(math.fsum(edges),t['cost'],abs_tol=1e-8,rel_tol=1e-10);audited_tours+=1
    for r in rows:
        if 'result' not in r: continue
        raw=read(ROOT/r['input_file']);res=r['result'];a=audit.check(raw,res['output'],9);b=audit.check(raw,res['baseline'],9)
        assert a==r['independent_audit'] and b==r['baseline_audit'];audited_routes+=2
        assert audit.check(raw,res['output'],3)==r['K3_diagnostic_audit']
        prior=res['baseline']['reported_cost']
        for tr in res['trace']:
            assert tr['incumbent_cost']<=prior+1e-9;prior=tr['incumbent_cost']
        good=bool(r['status']=='complete' and a['accepted'] and b['accepted'] and res['check']['accepted'] and res['baseline_check']['accepted'] and res['deltas']==5000 and res['delta_by_kind']['savings']==36 and sum(res['delta_by_kind'].values())==5000 and r['raw_gap_percent']>=-1e-7)
        checks.append({'run_id':r['run_id'],'passed':good})
    common=[];blocks=[]
    for e in entries:
        rr=[r for r in rows if r['geometry_id']==e['geometry_id'] and r['status']=='complete'];b={'geometry_id':e['geometry_id'],'family':e['family'],'methods':{}}
        for alg in ['random_cheapest','random_regret2']:
            aa=[r for r in rr if r['algorithm']==alg];b['methods'][alg]={'n_seeds':len(aa),'mean_cost':mean([r['independent_audit']['cost'] for r in aa]),'mean_gap_percent':mean([r['raw_gap_percent'] for r in aa]),'hit_fraction':mean([int(r['optimal_hit']) for r in aa]),'K3_valid_fraction':mean([int(r['K3_diagnostic_audit']['accepted']) for r in aa])}
        if len(rr)==8:
            common.append(e['geometry_id']);b['gap_difference_cheapest_minus_regret2_pp']=b['methods']['random_cheapest']['mean_gap_percent']-b['methods']['random_regret2']['mean_gap_percent']
            delta=b['methods']['random_cheapest']['mean_cost']-b['methods']['random_regret2']['mean_cost'];b['regret2_outcome']='win' if delta>1e-8 else ('loss' if delta < -1e-8 else 'tie')
        blocks.append(b)
    methods={}
    for alg in ['random_cheapest','random_regret2']:
        rr=[r for r in rows if r['algorithm']==alg and r['status']=='complete'];g=[b['methods'][alg] for b in blocks if b['geometry_id'] in common]
        worst=max(rr,key=lambda r:r['raw_gap_percent']) if rr else None
        methods[alg]={'planned':64,'complete':len(rr),'legal_K9':sum(r['independent_audit']['accepted'] for r in rr),'geometry_mean_gap_percent':mean([v['mean_gap_percent'] for v in g]),'median_geometry_mean_gap_percent':statistics.median([v['mean_gap_percent'] for v in g]) if g else None,'maximum_observed_gap_percent':max((r['raw_gap_percent'] for r in rr),default=None),'optimal_hits':sum(r['optimal_hit'] for r in rr),'optimal_hit_denominator':64,'geometry_average_hit_fraction':mean([v['hit_fraction'] for v in g]),'K3_valid_outputs':sum(r['K3_diagnostic_audit']['accepted'] for r in rr),'K3_over_vehicle_limit':sum('vehicle_upper_bound_exceeded' in r['K3_diagnostic_audit']['errors'] for r in rr),'deltas':sum(r['result']['deltas'] for r in rr),'solver_cpu_seconds':sum(r['result']['solver_cpu_seconds'] for r in rr),'solver_wall_seconds':sum(r['result']['solver_wall_seconds'] for r in rr),'matrix_distances':sum(r['result']['matrix_distances'] for r in rr),'objective_edges':sum(r['result']['objective_edges'] for r in rr),'iterations_completed':sum(r['result']['iterations_completed'] for r in rr),'worst_case':None if worst is None else {'geometry_id':worst['geometry_id'],'search_seed':worst['search_seed'],'run_id':worst['run_id'],'routes':worst['result']['output']['routes'],'cost':worst['independent_audit']['cost'],'optimum':worst['primary_optimum'],'gap_percent':worst['raw_gap_percent']}}
    baseline=[];k3=[]
    for e in entries:
        rr=[r for r in rows if r['geometry_id']==e['geometry_id'] and r.get('baseline_audit',{}).get('accepted')]
        if rr:
            assert len({json.dumps(r['result']['baseline'],sort_keys=True) for r in rr})==1
            r=rr[0];baseline.append({'geometry_id':e['geometry_id'],'cost':r['baseline_audit']['cost'],'gap_percent':100*(r['baseline_audit']['cost']/r['primary_optimum']-1),'hit':abs(r['baseline_audit']['cost']-r['primary_optimum'])<=max(1e-8,1e-10*abs(r['primary_optimum']))})
        if e['geometry_id'] in oracles:
            o=oracles[e['geometry_id']]['oracle'];a=o['by_k']['9'];b=o['by_k']['3'];k3.append({'geometry_id':e['geometry_id'],'K3_feasible':b is not None,'K9_optimum':a['cost'],'K9_nonempty_routes':a['nonempty_routes'],'K3_optimum':b['cost'] if b else None,'K3_premium_percent':100*(b['cost']/a['cost']-1) if b else None})
    failures=[{'run_id':r['run_id'],'status':r['status'],'error':r.get('error',r.get('result',{}).get('error'))} for r in rows if r['status']!='complete']
    complete=len(rows)==len(schedule) and not missing and not failures and len(common)==16 and all(c['passed'] for c in checks)
    summary={'complete':complete,'geometry_count':16,'search_seeds_per_geometry':4,'planned_trajectories':128,'completed_trajectories':sum(r['status']=='complete' for r in rows),'common_support_geometries':common,'methods':methods,'paired_geometry_outcomes':{q:sum(b.get('regret2_outcome')==q for b in blocks) for q in ['win','tie','loss']},'mean_paired_gap_difference_cheapest_minus_regret2_pp':mean([b['gap_difference_cheapest_minus_regret2_pp'] for b in blocks if 'gap_difference_cheapest_minus_regret2_pp' in b]),'baseline':{'geometries':len(baseline),'mean_gap_percent':mean([b['gap_percent'] for b in baseline]),'optimal_hits':sum(b['hit'] for b in baseline)},'K3_diagnostic':{'oracle_feasible':sum(k['K3_feasible'] for k in k3),'higher_optimum_than_K9':sum(k['K3_feasible'] and k['K3_optimum']>k['K9_optimum']+1e-8 for k in k3),'mean_premium_percent':mean([k['K3_premium_percent'] for k in k3 if k['K3_feasible']]),'max_premium_percent':max((k['K3_premium_percent'] for k in k3 if k['K3_feasible']),default=None)},'families':{},'inference_limits':'16 independent fresh generated geometry blocks only; seeds repeated, controls fixed, K9 nonbinding. No SOTA/real-world/fixed-three-fleet claim.'}
    for fam in ['uniform','two_cluster']:
        bb=[b for b in blocks if b['family']==fam and b['geometry_id'] in common];summary['families'][fam]={alg:mean([b['methods'][alg]['mean_gap_percent'] for b in bb]) for alg in methods}
    dump(ROOT/'reports/SUMMARY.json',summary);dump(ROOT/'reports/GEOMETRY_LEVEL.json',blocks);dump(ROOT/'reports/K3_DIAGNOSTIC.json',k3);dump(ROOT/'reports/BASELINE_BY_GEOMETRY.json',baseline)
    dump(ROOT/'reports/INDEPENDENT_AUDIT.json',{'utc':utc(),'frozen_hashes_unchanged':True,'all_checks_passed':complete,'trajectory_checks':checks,'route_outputs_reaudited':audited_routes,'subset_tours_reaudited':audited_tours,'missing_planned_trajectories':missing,'failures':failures,'crosscheck':read(ROOT/'raw/ORACLE_CROSSCHECK.json')['all_passed'],'not_a_formal_numeric_certificate':True})
    with (ROOT/'reports/TRAJECTORY_METRICS.csv').open('x',newline='') as f:
        fields=['run_id','geometry_id','family','algorithm','search_seed','status','gap_percent','optimal_hit','cost','optimum','route_count','K3_valid','solver_cpu_seconds','deltas'];w=csv.DictWriter(f,fields);w.writeheader()
        for r in rows:
            d={k:r[k] for k in fields if k in r};a=r.get('independent_audit',{});res=r.get('result',{});d.update(gap_percent=r.get('raw_gap_percent'),cost=a.get('cost'),optimum=r.get('primary_optimum'),route_count=a.get('nonempty_routes'),K3_valid=r.get('K3_diagnostic_audit',{}).get('accepted'),solver_cpu_seconds=res.get('solver_cpu_seconds'),deltas=res.get('deltas'));w.writerow(d)
    c=methods['random_cheapest'];r=methods['random_regret2'];p=summary['paired_geometry_outcomes'];completion=read(ROOT/'raw/COMPLETION.json') if (ROOT/'raw/COMPLETION.json').exists() else {};cross=read(ROOT/'raw/ORACLE_CROSSCHECK.json');cross_count=sum(len(x['checks']) for x in cross['fixtures'])
    text=f'''小规模 CVRP 精确最优对照（完整状态：{complete}）

结论
16个独立新几何，n=9、Q=9；每几何4个预定搜索seed，原固定 random_cheapest 与 random_regret2 共128次运行。每次含初始化均为5,000次delta。两法合法结果分别{c['legal_K9']}/64、{r['legal_K9']}/64。
相对 Held–Karp＋容量子集分区 DP 的 K=9 全局组合最优参考，geometry等权平均gap分别{c['geometry_mean_gap_percent']:.6f}%、{r['geometry_mean_gap_percent']:.6f}%；最优容差命中{c['optimal_hits']}/64与{r['optimal_hits']}/64；最坏gap {c['maximum_observed_gap_percent']:.6f}%与{r['maximum_observed_gap_percent']:.6f}%。原 savings 初始化平均gap {summary['baseline']['mean_gap_percent']:.6f}%，最优命中{summary['baseline']['optimal_hits']}/16。
先平均4seed再逐几何配对，regret2胜/平/负={p['win']}/{p['tie']}/{p['loss']}；cheapest减regret2平均gap差{summary['mean_paired_gap_difference_cheapest_minus_regret2_pp']:.6f}个百分点。仅描述这些有限样本，不据此宣传普遍优势。

关键车辆语义缺口
旧内核输入合同明确unlimited_identical_vehicles，repair一直允许新开单点路线，没有实现固定少车辆约束。为了原控制与oracle严格同目标，主对照固定K=n=9；至多9条非空回仓路线，未使用车辆省略、零费用，绝非恰9车。不能把本实验叫作固定3车算法验证。
预冻结的同几何K=3仅作精确诊断：{summary['K3_diagnostic']['oracle_feasible']}/16可行，其中{summary['K3_diagnostic']['higher_optimum_than_K9']}个最优值高于K9。原方法输出中分别{c['K3_over_vehicle_limit']}/64、{r['K3_over_vehicle_limit']}/64超过3车，不能算作K3合法解，不能对这些解报K3最优gap。K3可行原解的条件gap仅存原始记录，不混入主结果。没有丢掉难例或改动原算法。

精确算法与核查
Held–Karp求每个容量可行非空客户子集的最短仓库环；含最小客户的子集作为首块，分区DP枚举所有容量可行分区，允许至多K块，求K1..9。欧氏边长为未取整double。组合枚举完整，但浮点并非区间认证或形式化证明；最优命中容差=max(1e-8,1e-10*|最优值|)。
n1..6×两种几何分布及零距离退化例，共{len(cross['fixtures'])}个独立测试fixture；全排列＋所有非空切分独立穷举，{cross_count}个K结果的可行/无解状态及数值全部一致。另有{len(cross['unit_tests'])}个checker单测覆盖超车数、超容量、漏点、重复、非法编号、空路线、错成本及至多K语义。后审计重算{audited_routes}个完整路线输出与{audited_tours}个子集路线；不导入solver距离矩阵。原内核与vendor源码逐字节保留，源自cvrp_scale_20261007。

冻结、抽样与费用
生成规则、种子、16几何、预算、控制、分析和完整源码先冻结，再生成输入并再次冻结。uniform8个，双高斯簇8个；需求[1,1,2,2,3,3,4,4,4]独立打乱，总24，容量9。所有实际旧输入的有序和无序坐标hash及继承旧hash进行新颖性对照。16几何是独立单位；128次运行并非128个样本。没有pilot、补抽、失败重跑或求解后调参。
主数值进程硬上限90CPU秒、150wall秒，跨全部精确求解、穷举测试、启发式与运行内核查。主进程自报CPU {completion.get('process_cpu_seconds')}秒，wall {completion.get('elapsed_wall_seconds')}秒；精确OS wait4退出收据见receipts/main.json。setup、后审计、封包分别计费，完整主求解外的shell/交互式代码编写和检查开销未纳入数值CPU，不能把主进程费用称为全任务费用。包装收据在zip旁外置；包内有包装前检查点。API/模型/安装/上传/付费调用均0。

交付与复现
raw/ORACLES.jsonl含全部各K最优路线和子集tour；raw/TRAJECTORIES.jsonl含128次完整原输出、baseline、逐迭代trace、delta及资源账本；reports中有CSV、几何级汇总、K3诊断与独立审计。输入、旧源拷贝、生成器、oracle、checker、协议、来源与SHA256全部保留。
安全单行复现：在新输出路径运行source/replay.py --run-id N --output /tmp/replay-N.json，输出比较只看路线、目标与delta，不比较计时。完整重跑必须复制到新目录并保留冻结input/source，重新运行run.py而非prepare.py；绝不覆盖本包raw。未使用ORTools、网络、模型API或时间窗；不是大规模最优保证或真实道路验证。
'''
    (ROOT/'reports/REPORT_ZH.txt').write_text(text)
    print(json.dumps(summary,ensure_ascii=False))
if __name__=='__main__':main()
