"""Freeze every specification and source before generation; no solver calls."""
import json,random,sys,time
from pathlib import Path
from common import ROOT,utc,sha,read,dump,digest
OLD=[Path('/workspace/shared/vrp_unseen_geometry_20261007'),Path('/workspace/shared/cvrp_scale_20261007'),Path('/workspace/shared/vrp_time_windows_20261007')]

def make(gi,n=9,test=False):
    seed=(202610089900 if test else 202610089300)+gi
    rng=random.Random(seed); family='uniform' if (gi%2==0 if test else gi<8) else 'two_cluster'
    pts=[[0.,0.]]
    for j in range(n):
        if family=='uniform':p=[rng.uniform(-50,50),rng.uniform(-50,50)]
        else:
            center=(-30,-20) if j%2==0 else (30,20)
            p=[rng.gauss(c,8) for c in center]
        pts.append([round(x,6) for x in p])
    dem=([1,1,2,2,3,3,4,4,4] if not test else [1+j%4 for j in range(n)])
    random.Random(seed+1000000).shuffle(dem)
    return {'spec_version':'euclidean-cvrp-v1','instance_id':f'EX{gi+1:02d}' if not test else f'TEST{gi:02d}', 'coordinates':pts,'demands':[0]+dem,'capacity':9 if not test else 6,'depot':0,'objective':'sum_unrounded_euclidean_distance','fleet':'unlimited_identical_vehicles','split':'dev' if not test else 'unit_test','generation_seed':seed,'family':family}

def main():
    cfg={'name':'Exact small CVRP controls; 16 independent fresh geometries', 'n':9,'K_primary':9,'K_diagnostic':3,'Q':9,'geometry_seeds':list(range(202610089300,202610089316)), 'families':['uniform']*8+['two_cluster']*8,
      'generator':'uniform U[-50,50]^2 or alternating two Gaussian clusters centered (-30,-20),(30,20), coordinate sd8; depot (0,0), rounded6 decimals; random.Random(seed).',
      'demand_rule':'[1,1,2,2,3,3,4,4,4] shuffled with seed+1000000; integer demand total24, Q9. No selection or rejection by solver outcome.',
      'search_seeds':[83011,83027,83041,83057], 'pairs':[['random','cheapest'],['random','regret2']], 'delta_limit':5000,'iterations':1000000000,'per_trajectory_cpu_seconds':2.,'per_trajectory_wall_seconds':10.,'main_cpu_soft_seconds':89,'main_cpu_hard_seconds':90,'main_wall_seconds':150,'schedule_seed':202610089399,
      'fleet_semantics':'At most K nonempty depot-return routes; empty vehicles omitted at zero cost; never exactly K. Primary K=n=9 is mathematically identical to original unlimited fleet checker and solver. Original code has no fixed-small-fleet enforcement. K3 exact optimum and feasibility audit are diagnostic only; NEVER compare K3 optimum to >3-route cost as a valid gap.',
      'same_objective':'All customers exactly once, integer capacity constraints, total unrounded symmetric Euclidean distance, identical vehicles, no time windows, no penalties.',
      'fixed_controls':'Byte-identical legacy.run_one: parallel savings initialization, random removal 10-30% clamped min2, repair cheapest or regret2; strict improving acceptance epsilon1e-9. No adaptive modifications.',
      'evaluation_unit':'One savings/removal/insertion delta expression. Both methods and every seed pay exactly5000 including initialization36; matrix distances, full objective edges, CPU/wall and budget checks reported separately. Equal deltas is not equal CPU/FLOPs.',
      'oracle':'Held-Karp minimum depot-return tour for every capacity-feasible customer subset; anchored subset partition DP minimizes over at most K routes. Enumerate K1..9; comparisons use K9, K3 diagnostic only. Floating double arithmetic, numerically cross-checked not formal interval certificate.',
      'crosscheck':'Before formal work: every n1..6 in each of 2 families, plus zero-distance n3 fixture; independently enumerate all permutations and nonempty cuts, compare every K1..n optimum and infeasibility. Independent sqrt coordinate cost checker imports no solver code.',
      'hit_tolerance':'abs(cost-optimum)<=max(1e-8,1e-10*abs(optimum)); raw signed gap retained, no numerical proof claim.',
      'aggregation':'Geometry is sampling unit n16. Four search seeds are paired replicates, not new data. Mean gaps/hits over four seeds per geometry then equal-weight16 geometries. Paired method differences in percentage points; W/T/L on geometry mean costs, tolerance1e-8. Baseline described once per geometry. All family breakdowns descriptive; no p-values or broad superiority claim.',
      'failure_rule':'One main launch only; no retries/resampling/algorithm changes after freeze. Retain failures and all planned/not-run IDs; incomplete common-support geometry flagged. Main hard cap90 CPU, wall150; setup/audit/package measured separately.',
      'budget_basis':'Prior n100/n200 run: 384 trajectories x160000 delta completed in53.245502 CPU seconds, source reports/RESOURCE_ACCOUNTING.json. New budget128 x5000=640000 delta plus small n9 DP and <=6 brute tests, deliberately far below cap; no pilot solves.',
      'external_api_calls':0,'model_calls':0,'dependency_installs':0,'uploads':0,'created_utc':utc()}
    dump(ROOT/'freeze/PROTOCOL.json',cfg)
    sources={str(p.relative_to(ROOT)):sha(p) for p in sorted((ROOT/'source').rglob('*.py'))}
    dump(ROOT/'freeze/PRE_GENERATION_FREEZE.json',{'utc':utc(),'generated_main_geometries':0,'main_launches':0,'sha256':sources|{'freeze/PROTOCOL.json':sha(ROOT/'freeze/PROTOCOL.json')}})
    seen=set();unordered=set(); old_records=[]; inherited=set()
    for directory in OLD:
        prior=directory/'freeze/OLD_GEOMETRY_HASHES.json'
        if prior.exists(): inherited.update(read(prior)['hashes'])
        files=list((directory/'input').glob('*.json')) if (directory/'input').exists() else [directory/'inputs.json']
        for p in files:
            val=read(p)
            for v in val if isinstance(val,list) else [val]:
                if not isinstance(v,dict):continue
                coords=v.get('coordinates')
                if coords is None and 'nodes' in v:coords=[[q['x'],q['y']] for q in v['nodes']]
                if coords is None:continue
                h=digest(coords);u=digest(sorted(coords)); seen.add(h);unordered.add(u)
                old_records.append({'file':str(p),'file_sha256':sha(p),'id':v.get('instance_id',v.get('id')),'ordered_coordinate_sha256':h,'unordered_coordinate_sha256':u,'n':len(coords)-1})
    seen.update(inherited)
    dump(ROOT/'freeze/OLD_GEOMETRY_HASHES.json',{'records':old_records,'unique_ordered_count':len(seen),'inherited_ordered_hashes':sorted(inherited),'scope':'Read-only coordinates and previously recorded geometry hashes from the three specified bundles. Does not claim comparison with every historical experiment.'})
    entries=[];new=set();new_unordered=set()
    for gi in range(16):
        raw=make(gi);h=digest(raw['coordinates']);u=digest(sorted(raw['coordinates']))
        assert h not in seen and h not in new and u not in unordered and u not in new_unordered
        new.add(h);new_unordered.add(u)
        path='input/'+raw['instance_id']+'.json';dump(ROOT/path,raw)
        entries.append({'geometry_id':raw['instance_id'],'input_file':path,'input_sha256':sha(ROOT/path),'coordinates_sha256':h,'unordered_coordinates_sha256':u,'family':raw['family'],'seed':raw['generation_seed'],'n':9,'K_primary':9,'K_diagnostic':3,'Q':9})
    dump(ROOT/'freeze/INPUT_MANIFEST.json',entries)
    tests=[make(2*(n-1)+family,n,True) for n in range(1,7) for family in range(2)]
    tests.append({'spec_version':'euclidean-cvrp-v1','instance_id':'TEST_ZERO_DISTANCE','coordinates':[[0,0]]*4,'demands':[0,1,1,1],'capacity':3,'depot':0,'objective':'sum_unrounded_euclidean_distance','fleet':'unlimited_identical_vehicles','split':'unit_test','generation_seed':None,'family':'zero_distance'})
    dump(ROOT/'input/CROSSCHECK_FIXTURES.json',tests)
    schedule=[dict(e,search_seed=s,pair=pair,algorithm='_'.join(pair)) for e in entries for s in cfg['search_seeds'] for pair in cfg['pairs']]
    random.Random(cfg['schedule_seed']).shuffle(schedule)
    for j,r in enumerate(schedule):r['run_id']=j
    dump(ROOT/'freeze/SCHEDULE.json',schedule)
    provenance=[]
    for p in sorted((ROOT/'source/legacy').rglob('*.py')):
        source=OLD[1]/p.relative_to(ROOT)
        assert sha(p)==sha(source)
        provenance.append({'copy':str(p.relative_to(ROOT)),'sha256':sha(p),'source':str(source),'byte_identical':True})
    dump(ROOT/'freeze/SOURCE_PROVENANCE.json',provenance)
    dump(ROOT/'freeze/PRE_RUN_FREEZE.json',{'utc':utc(),'main_launches_before_freeze':0,'main_geometries':16,'main_trajectories':len(schedule),'duplicate_old_or_new_geometries':0,'sha256':{str(p.relative_to(ROOT)):sha(p) for directory in ['source','input','freeze'] for p in sorted((ROOT/directory).rglob('*')) if p.is_file()}})
    print(json.dumps({'prepared':True,'geometry_count':16,'trajectory_count':len(schedule),'deltas_each':5000,'solver_pilot_calls':0}))
if __name__=='__main__':main()
