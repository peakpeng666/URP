"""Post-run packager; never calls a solver. Exact packaging receipt lives next to ZIP."""
import json,time,zipfile
from common import ROOT,read,dump,sha,verify,utc
start=time.process_time();verify()
receipts=[read(ROOT/'receipts'/f'{name}.json') for name in ['prepare','main','audit']]
dump(ROOT/'reports/RESOURCE_ACCOUNTING.json',{'utc':utc(),'completed_stages_before_packaging':receipts,'measured_child_cpu_before_packaging':sum(r['child_total_cpu_seconds'] for r in receipts),'main_numeric_cpu_hard_limit_seconds':90,'main_numeric_wall_hard_limit_seconds':150,'packaging_process_cpu_checkpoint_seconds':time.process_time(),'packaging_limit_seconds':20,'packaging_exact_receipt':'receipts/package.json produced only AFTER zip snapshot; deliver this receipt beside archive','unmeasured_scope':'Interactive source authoring, inspection shell commands and conversational latency; not represented as zero and not included in measured child CPU. Supervisor checkpoints are separate and omit final serialization tail.','model_calls':0,'api_calls':0,'network_calls':0,'dependency_installs':0,'paid_api_spend':0})
(ROOT/'README.txt').write_text('Start with reports/REPORT_ZH.txt and SUMMARY.json. Main: n9/Q9/K9, preserving original unlimited-fleet semantics. K3 is pre-frozen diagnostic only. 16 independent geometries; 128 seed-method trajectories. All raw data, frozen inputs, exact DP, independent exhaustive checks, vendored unchanged controls, and hashes included. No network/API/install/upload. Do not overwrite completed raw records. ZIP excludes itself and its hash, plus the supervisor package receipt that is generated after ZIP closes. The separate receipts/package.json is the exact final packaging cost.\n')
files=[p for p in sorted(ROOT.rglob('*')) if p.is_file() and p.suffix!='.zip' and p.name not in ['MANIFEST.json','SHA256SUMS.txt','archive.sha256'] and '__pycache__' not in p.parts and p.relative_to(ROOT).as_posix() not in ['receipts/package.stdout.log','receipts/package.stderr.log']]
manifest={'utc':utc(),'files':[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files],'packaging_cpu_checkpoint_seconds':time.process_time(),'mutable_excluded_files':['archive.sha256','receipts/package.json','receipts/package.stdout.log','receipts/package.stderr.log']}
dump(ROOT/'MANIFEST.json',manifest)
(ROOT/'SHA256SUMS.txt').write_text(''.join(f"{x['sha256']}  {x['path']}\n" for x in manifest['files']))
archive=ROOT/(ROOT.name+'.zip')
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
    for f in files+[ROOT/'MANIFEST.json',ROOT/'SHA256SUMS.txt']:z.write(f,str(f.relative_to(ROOT)))
(ROOT/'archive.sha256').write_text(sha(archive)+'  '+archive.name+'\n')
print(json.dumps({'archive':str(archive),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),'packaging_cpu_checkpoint_seconds':time.process_time()-start}))
