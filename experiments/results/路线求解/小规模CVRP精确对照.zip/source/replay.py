"""Optional user-invoked one-row replay; never called by this experiment."""
import argparse,importlib.util,json
from pathlib import Path
from common import ROOT,read,dump,verify
p=argparse.ArgumentParser();p.add_argument('--run-id',required=True,type=int);p.add_argument('--output',required=True);args=p.parse_args();out=Path(args.output).resolve()
if out.is_relative_to(ROOT):raise SystemExit('Output must be outside completed bundle')
verify();row=next(r for r in read(ROOT/'freeze/SCHEDULE.json') if r['run_id']==args.run_id);cfg=read(ROOT/'freeze/PROTOCOL.json')
s=importlib.util.spec_from_file_location('legacy',ROOT/'source/legacy/experiment.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
r=m.run_one(m.from_dict(read(ROOT/row['input_file'])),row['pair'],row['search_seed'],cfg['iterations'],{'delta_limit':cfg['delta_limit'],'cpu_limit_seconds':cfg['per_trajectory_cpu_seconds'],'wall_limit_seconds':cfg['per_trajectory_wall_seconds']});dump(out,{'schedule':row,'result':r})
