"""Seal post-run independent numerical, text, chronology and artifact review, without search."""
import pathlib,json,hashlib,datetime
R=pathlib.Path('/workspace/shared/public_route_operator_order_20261008');O=pathlib.Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
stamp=lambda s:datetime.datetime.fromisoformat(s.replace('Z','+00:00'))
pre=read(R/'provenance/PREEXEC_DRIVE_RECEIPT.json');raw=read(R/'provenance/RAW_UNREVIEWED_DRIVE_RECEIPT.json');old=read(R/'freeze/UPSTREAM_FINAL_ARCHIVE_GATE.json');started=read(R/'raw/STARTED.json');finished=read(R/'raw/FINISHED.json');summary=read(R/'reports/SUMMARY.json');audit=read(O/'FORMAL_SAVED_TRACE_AND_REPORT_REVIEW.json')
assert audit['status']=='PASS' and summary['independent_review_status']=='PASS'
chronology=[old['confirmed_at_utc'],pre['confirmed_at_utc'],started['utc'],finished['utc'],raw['confirmed_at_utc'],summary['scored_utc'],audit['utc']]
assert all(stamp(a)<stamp(b) for a,b in zip(chronology,chronology[1:]))
for rec in (pre,raw):assert rec['shared'] is False and rec['owner_only'] is True
for p,v in read(R/'freeze/FROZEN_FILES.json')['files'].items():assert sha(R/p)==v['sha256']
for p,v in read(R/'freeze/UPSTREAM_FILES_BEFORE.json').items():assert sha(pathlib.Path(p))==v['sha256']
for p,v in read(O/'PRECHECK_COPY_FILES.json')['files'].items():assert sha(O/p)==v['sha256']
text=(R/'reports/REPORT_ZH.txt').read_text();assert '待完成' not in text and ('PASS' in text or '通过' in text)
assert f"{audit['paired_primary']['mean_gap_difference_percentage_points_all16']:.9f}个百分点" in text
for row in audit['paired_tasks']:
    expected=f"{row['instance_id']}: {row['TSR_cost']}, {row['TRS_cost']}, {row['difference_gap_percentage_points']:.9f}；{row['outcome']}";assert expected in text
for row in summary['secondary_all_frozen_nodes']:assert f"{row['budget_node']}: TSR−TRS平均gap差{row['equal_task_mean_gap_difference_percentage_points_all16']:.9f}个百分点；有效对16/16。" in text
for phrase in ['新事后探索阶段','14坐标/需求底本','容量失败候选计入预算','允许空槽','不能单独区分预算分配与贪心路径依赖','不作速度、显著性、SOTA或跨新数据泛化声明','未挑任务、节点或失败项','T/TR/TS仅历史背景']:assert phrase in text
final_text=(R/'reports/FINAL_REPORT_ZH.txt').read_text();assert final_text.startswith(text.rstrip())
by={(x['instance_id'],x['arm']):x for x in audit['details']}
improved={x['instance_id'] for x in audit['paired_tasks'] if x['outcome']=='improved'}
old_capped={x['instance_id'] for x in audit['details'] if x['arm']=='TRS' and x['termination']=='BUDGET_EXHAUSTED'}
assert improved==old_capped and len(improved)==6
assert by[('E-n51-k5','TSR')]['attempted']==16945 and by[('E-n51-k5','TSR')]['termination']=='LOCAL_OPTIMUM'
assert all(by[(x,'TSR')]['attempted']==20000 and by[(x,'TSR')]['termination']=='BUDGET_EXHAUSTED' for x in improved-{'E-n51-k5'})
for x in {t['instance_id'] for t in audit['paired_tasks']}-improved:assert by[(x,'TRS')]['termination']=='LOCAL_OPTIMUM' and by[(x,'TRS')]['cost']==by[(x,'TSR')]['cost']
assert summary['arms']['TRS']['never_entered_scan_tasks']['swap']==['A-n65-k9','B-n66-k9','F-n72-k4']
assert summary['arms']['TSR']['never_entered_scan_tasks']['swap']==[] and summary['arms']['TSR']['never_entered_scan_tasks']['relocate']==['B-n66-k9','F-n72-k4']
for arm in ('TRS','TSR'):
    for op in ('two_opt','relocate','swap'):
        v=summary['arms'][arm]['operator_counts'][op];assert f"{v['attempted']}/{v['feasible']}/{v['accepted']}" in final_text
historical=list(map(json.loads,(R/'history/raw/results.jsonl').read_text().splitlines()));refs={x['instance_id']:x for x in read(R/'inputs/POSTSCORING_REFERENCES.json')}
for arm in ('T','TR','TS'):
    rr=[x for x in historical if x['arm']==arm];assert len(rr)==16 and all(x['status']=='SUCCESS' for x in rr)
    gap=sum(100*(x['summary']['cost']/refs[x['instance_id']]['reference_integer_cost']-1) for x in rr)/16
    assert f"{arm}：平均reference gap {gap:.9f}%。" in final_text
assert '不能单独证明唯一原因是预算饥饿' in final_text and '不是一般等价性定理' in final_text
files=['audit_formal_saved.py','FORMAL_SAVED_TRACE_AND_REPORT_REVIEW.json','finalize_formal.py']
result={'status':'PASS','stage':'FINAL_INDEPENDENT_SAVED_RESULT_AND_REPORT_REVIEW','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'new_formal_calls':16,'historical_primary_saved_calls':16,'public_optimizer_calls_by_reviewer':0,'new_public_optimizer_reruns':0,'historical_public_optimizer_reruns':0,'saved_candidates_independently_full_rescored':393730,'all32_primary_saved_traces_verified':True,'all192_fixed_node_rows_verified':True,'all16_paired_task_terminal_results_verified':True,'complete_operator_attempt_feasible_accepted_first_scan_first_candidate_verification':True,'primary_verified':audit['paired_primary'],'mean_reference_gaps_percent':{a:summary['arms'][a]['mean_reference_gap_percent_all16'] for a in ('TRS','TSR')},'operator_counts_verified':{a:summary['arms'][a]['operator_counts'] for a in ('TRS','TSR')},'explicit_chronology_utc':dict(zip(['upstream_final_readback','new_preexec_readback','new_formal_started','new_formal_finished','new_raw_readback','author_report_scored','independent_trace_review'],chronology)),'explicit_chronology_strict_order_passed':True,'archive_evidence':'Reviewer locally verified actual recorded remote-download files against source archives by SHA256, byte equality, ZIP CRC and members. Remote owner-only/shared=false permission evidence comes from archived uploader receipts; reviewer made no network call.','preexec_source_inputs_protocol_history_and_review_hashes_unchanged':True,'upstream262_preexisting_files_unchanged':True,'original12_precheck_evidence_files_unchanged':True,'final_text_report_verified':True,'final_supplement_operator_diagnostics_and_all3_historical_context_means_verified':True,'report_status_markers_pass':True,'limitations_preserved':['New posthoc exploratory contrast on16 fixed tasks with14 coordinate-demand bases.','Saved sequential-stage historical TRS comparator; no old optimizer rerun.','Equal20,000 attempted-candidate ceilings do not imply equal actual work or CPU.','Cannot separate operator budget allocation from greedy path dependence.','No significance, global optimality, SOTA or cross-data generalized superiority claim.'],'report_sha256':{str(p.relative_to(R)):sha(p) for p in sorted((R/'reports').glob('*')) if p.is_file()},'evidence_sha256':{p:sha(O/p) for p in files},'remaining_delivery_gate':'Archive FINAL_REVIEWED privately, retrieve actual remote bytes and verify byte equality, hash, CRC and required members. This final-delivery gate remains separate from the completed numerical/trace/report audit.'}
(O/'INDEPENDENT_FORMAL_REVIEW.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');files.append('INDEPENDENT_FORMAL_REVIEW.json')
(O/'FORMAL_REVIEW_COPY_FILES.json').write_text(json.dumps({'status':'PASS','files':{p:{'bytes':(O/p).stat().st_size,'sha256':sha(O/p)} for p in files},'note':'These4 post-run files are new. Keep all preexec evidence unchanged. Exclude synthetic fixture directories from published audit ZIP.'},indent=2)+'\n')
print(json.dumps({'status':'PASS','final_review_sha256':sha(O/'INDEPENDENT_FORMAL_REVIEW.json'),'copy_manifest':str(O/'FORMAL_REVIEW_COPY_FILES.json')},indent=2))
