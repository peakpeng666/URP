"""Independent full-rescoring reference and saved-evidence tools. No production optimizer imports."""
from decimal import Decimal, localcontext, ROUND_HALF_UP
from collections import Counter
OPS={'T':('two_opt',),'TR':('two_opt','relocate'),'TS':('two_opt','swap'),'TRS':('two_opt','relocate','swap'),'TSR':('two_opt','swap','relocate')}
LEVELS=[0,100,1000,5000,10000,20000]
def matrix(coords):
    with localcontext() as cx:
        cx.prec=80
        c=[tuple(Decimal(str(v)) for v in row) for row in coords]
        return [[int(((x-a)**2+(y-b)**2).sqrt().quantize(Decimal(1),rounding=ROUND_HALF_UP)) for a,b in c] for x,y in c]
def score(routes,d): return sum(d[r[i]][r[i+1]] for r in routes for i in range(len(r)-1))
def loads(routes,dem):return [sum(dem[x] for x in r[1:-1]) for r in routes]
def validate(routes,dem,q,k,d):
    assert len(routes)==k
    assert all(type(r)is list and len(r)>=2 and r[0]==0 and r[-1]==0 for r in routes)
    assert all(type(x)is int and 1<=x<len(dem) for r in routes for x in r[1:-1])
    assert Counter(x for r in routes for x in r[1:-1])==Counter(range(1,len(dem)))
    l=loads(routes,dem);assert all(0<=v<=q for v in l)
    return {'loads':l,'cost':score(routes,d),'K_slots':k,'nonempty_routes':sum(len(r)>2 for r in routes)}
def candidates(routes,op):
    if op=='two_opt':
        return [(a,i,a,j) for a,r in enumerate(routes) for i in range(1,len(r)-2) for j in range(i+1,len(r)-1)]
    if op=='swap':
        return [(a,i,b,j) for a in range(len(routes)) for b in range(a+1,len(routes)) for i in range(1,len(routes[a])-1) for j in range(1,len(routes[b])-1)]
    assert op=='relocate'
    return [(a,i,b,j) for a in range(len(routes)) for i in range(1,len(routes[a])-1) for b in range(len(routes)) if b!=a for j in range(1,len(routes[b]))]
def transformed(routes,op,c):
    a,i,b,j=c;out=[r.copy() for r in routes]
    if op=='two_opt':out[a]=routes[a][:i]+list(reversed(routes[a][i:j+1]))+routes[a][j+1:]
    elif op=='swap':out[a][i],out[b][j]=routes[b][j],routes[a][i]
    else:
        out[a]=routes[a][:i]+routes[a][i+1:]
        out[b]=routes[b][:j]+[routes[a][i]]+routes[b][j:]
    return out
def oracle(coords,dem,q,initial,arm,budget):
    """For INVENTED fixtures only. Derives deltas by complete rescoring, never production delta code."""
    d=matrix(coords);routes=[r.copy() for r in initial];cost=score(routes,d);orig=cost
    trace=[];scans=[];moves=[];idx=0;ops=OPS[arm];stop='BUDGET_EXHAUSTED';check=[{'attempted':0,'cost':cost}]
    count={op:{'attempted':0,'feasible':0,'accepted':0} for op in ops}
    while len(trace)<budget:
        op=ops[idx];start=len(trace);cs=candidates(routes,op);found=False;complete=True
        for c in cs:
            if len(trace)==budget:complete=False;break
            r=transformed(routes,op,c);ok=all(v<=q for v in loads(r,dem));delta=score(r,d)-cost if ok else None;accept=ok and delta<0
            trace.append([op,*c,int(ok),delta,int(accept)])
            count[op]['attempted']+=1;count[op]['feasible']+=int(ok);count[op]['accepted']+=int(accept)
            if accept:
                routes=r;cost=score(routes,d);moves.append({'attempted':len(trace),'op':op,'candidate':list(c),'delta':delta,'cost':cost})
            if len(trace) in LEVELS:check.append({'attempted':len(trace),'cost':cost})
            if accept:found=True;complete=False;break
        scans.append({'op':op,'start_attempted':start,'end_attempted':len(trace),'complete_nonimproving':complete and not found,'accepted':found})
        if found:idx=0
        elif complete:
            idx+=1
            if idx==len(ops):stop='LOCAL_OPTIMUM';break
        else:break
    return {'arm':arm,'budget':budget,'routes':routes,'loads':loads(routes,dem),'initial_cost':orig,'cost':cost,'attempted':len(trace),'feasible':sum(x['feasible'] for x in count.values()),'accepted':len(moves),'counts':count,'termination':stop,'unspent_budget':budget-len(trace),'trace':trace,'scans':scans,'accepted_moves':moves,'checkpoints':check}
def read_vrp(path):
    fields={};coords={};dem={};depots=[];section='HEADER'
    for line in path.read_text().splitlines():
        words=line.split()
        if not words:continue
        if words[0]=='EOF':break
        if words[0] in ('NODE_COORD_SECTION','DEMAND_SECTION','DEPOT_SECTION'):section=words[0];continue
        if section=='HEADER':
            k,v=line.split(':',1);fields[k.strip()]=v.strip()
        elif section=='NODE_COORD_SECTION':coords[int(words[0])]=[Decimal(words[1]),Decimal(words[2])]
        elif section=='DEMAND_SECTION':dem[int(words[0])]=int(words[1])
        elif int(words[0])!=-1:depots.append(int(words[0]))
    n=int(fields['DIMENSION']);assert fields['EDGE_WEIGHT_TYPE']=='EUC_2D' and depots==[1]
    assert set(coords)==set(dem)==set(range(1,n+1))
    cc=[coords[x] for x in range(1,n+1)];dd=[dem[x] for x in range(1,n+1)]
    return cc,dd,int(fields['CAPACITY']),matrix(cc)
def first_entries(result):
    return {op:{'first_scan_entry_cumulative_attempts':next((s['start_attempted'] for s in result['scans'] if s['op']==op),None),'first_actual_attempt_1based':next((i+1 for i,t in enumerate(result['trace']) if t[0]==op),None)} for op in OPS[result['arm']]}
