"""Post-run independent auditor. Replays only saved candidates, never calls/imports production search."""
import pathlib,json,hashlib,csv,datetime,zipfile,math
from collections import Counter
from independent_core import OPS,LEVELS,read_vrp,score,loads,validate,candidates,transformed
R=pathlib.Path('/workspace/shared/public_route_operator_order_20261008');O=pathlib.Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
def close(a,b):assert a is not None and b is not None and math.isclose(float(a),float(b),rel_tol=1e-12,abs_tol=1e-10),(a,b)
def stamp(x):return datetime.datetime.fromisoformat(x.replace('Z','+00:00'))
def verify_receipt(name,stage):
    rec=read(R/'provenance'/name);a=R.parent/(R.name+'_'+stage+'.zip');b=pathlib.Path(rec['download_path'])
    assert rec['owner_only'] and rec['remote_readback_sha256_verified'] and rec['download_byte_identical'];assert a.read_bytes()==b.read_bytes() and sha(a)==rec['sha256']==rec['download_sha256']
    with zipfile.ZipFile(b) as z:assert z.testzip() is None
    return rec

def saved_trace(task,res,d,dem,q):
    routes=[r.copy() for r in task['baseline_routes']];initial=validate(routes,dem,q,task['K'],d)['cost'];current=initial;pos=0;idx=0;ops=OPS[res['arm']];budget=res['budget']
    assert budget==20000 and res['initial_cost']==initial
    counts={op:{'attempted':0,'feasible':0,'accepted':0} for op in ops};moves=[];check=[{'attempted':0,'cost':initial}];first={op:{'scan':None,'attempt':None,'scans':0} for op in ops};local=False
    for si,s in enumerate(res['scans']):
        assert pos<budget and not local and s['op']==ops[idx] and s['start_attempted']==pos
        op=s['op'];start=pos;cs=candidates(routes,op);end=s['end_attempted'];assert start<=end<=len(res['trace']) and end-start<=len(cs)
        first[op]['scans']+=1
        if first[op]['scan'] is None:first[op]['scan']=start
        accepted=False
        for ci in range(end-start):
            t=res['trace'][pos];c=cs[ci];assert t[0]==op and t[1:5]==list(c) and not accepted
            changed=transformed(routes,op,c);ok=all(v<=q for v in loads(changed,dem));delta=score(changed,d)-current if ok else None;accept=bool(ok and delta<0)
            assert t==[op,*c,int(ok),delta,int(accept)],(task['instance_id'],res['arm'],pos+1,t,delta)
            pos+=1;counts[op]['attempted']+=1;counts[op]['feasible']+=int(ok);counts[op]['accepted']+=int(accept)
            if first[op]['attempt'] is None:first[op]['attempt']=pos
            if accept:
                routes=changed;current=score(routes,d);validate(routes,dem,q,task['K'],d);moves.append({'attempted':pos,'op':op,'candidate':list(c),'delta':delta,'cost':current});accepted=True
            if pos in LEVELS:check.append({'attempted':pos,'cost':current})
        complete=not accepted and end-start==len(cs)
        assert s['accepted']==accepted and s['complete_nonimproving']==complete and pos==end
        if accepted:idx=0
        elif complete:
            idx+=1
            if idx==len(ops):local=True;assert si==len(res['scans'])-1
        else:assert pos==budget and si==len(res['scans'])-1
    assert pos==len(res['trace'])==res['attempted']<=budget
    assert local or pos==budget
    assert res['termination']==('LOCAL_OPTIMUM' if local else 'BUDGET_EXHAUSTED')
    assert res['routes']==routes and res['loads']==loads(routes,dem) and res['cost']==current and res['counts']==counts
    assert res['feasible']==sum(x['feasible'] for x in counts.values()) and res['accepted']==len(moves) and res['unspent_budget']==budget-pos
    assert res['accepted_moves']==moves and res['checkpoints']==check
    assert res['reference_read_attempts']==0 and res['denied_io_events']==[]
    assert res['limits']=={'hard_cpu_seconds':2,'external_wall_seconds':3,'address_space_MiB':256}
    curve={level:next((m['cost'] for m in reversed(moves) if m['attempted']<=level),initial) for level in LEVELS}
    return {'initial_cost':initial,'cost':current,'attempted':pos,'feasible':res['feasible'],'accepted':len(moves),'termination':res['termination'],'unspent_budget':budget-pos,'counts':counts,'first':first,'curve':curve,'K_slots':task['K'],'nonempty_routes':sum(len(r)>2 for r in routes),'scans':len(res['scans']),'raw_trace_sha256':hashlib.sha256(json.dumps(res['trace'],separators=(',',':')).encode()).hexdigest()}

def main():
    pre=verify_receipt('PREEXEC_DRIVE_RECEIPT.json','PREEXEC');raw=verify_receipt('RAW_UNREVIEWED_DRIVE_RECEIPT.json','RAW_UNREVIEWED')
    frozen=read(R/'freeze/FROZEN_FILES.json')
    for p,v in frozen['files'].items():assert sha(R/p)==v['sha256']
    for p,v in read(R/'freeze/UPSTREAM_FILES_BEFORE.json').items():assert sha(pathlib.Path(p))==v['sha256']
    for p,v in read(R/'raw/RAW_UNREVIEWED_MANIFEST.json')['files'].items():assert sha(R/p)==v['sha256']
    tasks=read(R/'inputs/SEARCH_TASKS.json');schedule=read(R/'freeze/SCHEDULE.json');refs={r['instance_id']:r for r in read(R/'inputs/POSTSCORING_REFERENCES.json')}
    new=list(map(json.loads,(R/'raw/results.jsonl').read_text().splitlines()));old=[r for r in map(json.loads,(R/'history/raw/results.jsonl').read_text().splitlines()) if r['arm']=='TRS'];attempts=list(map(json.loads,(R/'raw/attempts.jsonl').read_text().splitlines()))
    assert len(new)==len(old)==16 and len(attempts)==32 and len(list((R/'raw/calls').glob('*.stdout')))==16 and len(list((R/'raw/calls').glob('*.stderr')))==16
    assert len({r['call_id'] for r in new})==16 and [r['selection_slot'] for r in new]==list(range(1,17))
    for i,(item,entry) in enumerate(zip(new,schedule)):
        assert all(item[k]==v for k,v in entry.items()) and item['status']=='SUCCESS' and item['returncode']==0
        start,end=attempts[2*i:2*i+2];assert start['phase']=='STARTED' and end['phase']=='FINISHED' and start['call_id']==end['call_id']==item['call_id']
        assert all(end[k]==v for k,v in item.items()) and stamp(start['utc'])<=stamp(end['utc'])
        if i:assert stamp(attempts[2*i-1]['utc'])<=stamp(start['utc'])
    started=read(R/'raw/STARTED.json');finished=read(R/'raw/FINISHED.json');summary=read(R/'reports/SUMMARY.json')
    assert started['planned_calls']==16 and started['no_reruns'] and finished['status']=='FINISHED' and finished['retained_calls']==16
    assert started['receipt_sha256']==sha(R/'provenance/PREEXEC_DRIVE_RECEIPT.json') and started['frozen_files_sha256']==sha(R/'freeze/FROZEN_FILES.json') and started['upstream_final_receipt_sha256']==sha(R/'freeze/UPSTREAM_FINAL_ARCHIVE_GATE.json')
    oldgate=read(R/'freeze/UPSTREAM_FINAL_ARCHIVE_GATE.json');assert stamp(oldgate['confirmed_at_utc'])<stamp(started['utc'])<=stamp(attempts[0]['utc'])<=stamp(attempts[-1]['utc'])<=stamp(finished['utc'])
    # Archive members provide exact preexec/raw state evidence independent of receipt timestamp spelling.
    with zipfile.ZipFile(pathlib.Path(pre['download_path'])) as z:
        assert R.name+'/raw/STARTED.json' not in z.namelist()
        for p,v in frozen['files'].items():assert hashlib.sha256(z.read(R.name+'/'+p)).hexdigest()==v['sha256']
    with zipfile.ZipFile(pathlib.Path(raw['download_path'])) as z:
        for p,v in read(R/'raw/RAW_UNREVIEWED_MANIFEST.json')['files'].items():assert hashlib.sha256(z.read(R.name+'/'+p)).hexdigest()==v['sha256']
        assert R.name+'/reports/SUMMARY.json' not in z.namelist()
    details={};paired=[]
    for arm,prefix,records in [('TRS','history/',old),('TSR','',new)]:
        for item in records:
            task=tasks[item['selection_slot']-1];name=task['instance_id'];assert item['instance_id']==name and item['arm']==arm and item['status']=='SUCCESS'
            path=R/(prefix+item['stdout']);assert sha(path)==item['stdout_sha256'];assert sha(R/(prefix+item['stderr']))==item['stderr_sha256'] and (R/(prefix+item['stderr'])).stat().st_size==0
            coords,dem,q,d=read_vrp(R/'inputs/instances'/f'{name}.vrp');res=read(path);assert res['arm']==arm
            ref=refs[name];refcheck=validate(ref['reference_routes'],dem,q,task['K'],d);assert refcheck['cost']==ref['reference_integer_cost']
            got=saved_trace(task,res,d,dem,q)
            assert item['summary']=={k:v for k,v in res.items() if k not in ('trace','scans','routes','loads','accepted_moves','checkpoints')}
            assert item['K_slots']==got['K_slots'] and item['nonempty_routes']==got['nonempty_routes'];got.update(instance_id=name,selection_slot=task['selection_slot'],arm=arm,reference_cost=refcheck['cost']);details[(name,arm)]=got
    csvrows=list(csv.DictReader((R/'reports/PER_CALL.csv').open()));assert len(csvrows)==32
    for row in csvrows:
        got=details[(row['instance_id'],row['arm'])]
        for key in ('initial_cost','cost','attempted','feasible','accepted','unspent_budget','K_slots','nonempty_routes'):assert int(row[key])==got[key]
        assert row['termination']==got['termination'];close(row['reference_gap_percent'],100*(got['cost']/got['reference_cost']-1))
        for op in OPS[row['arm']]:
            for k,v in got['counts'][op].items():assert int(row[op+'_'+k])==v
            for field,k in [('first_scan_entry_after_attempts','scan'),('first_candidate_attempt_1based','attempt'),('scans_entered','scans')]:
                actual=row[op+'_'+field];expected=got['first'][op][k];assert actual==('' if expected is None else str(expected))
    csvpairs=list(csv.DictReader((R/'reports/PAIRED_TSR_MINUS_TRS.csv').open()));assert len(csvpairs)==16
    for task,row in zip(tasks,csvpairs):
        name=task['instance_id'];a=details[(name,'TSR')];b=details[(name,'TRS')];diff=a['cost']-b['cost'];gap=100*diff/a['reference_cost'];outcome='improved' if diff<0 else 'worse' if diff>0 else 'equal'
        assert row['instance_id']==name and int(row['TSR_cost'])==a['cost'] and int(row['historical_TRS_cost'])==b['cost'] and int(row['TSR_minus_TRS_cost'])==diff and row['outcome']==outcome;close(row['TSR_minus_TRS_gap_percentage_points'],gap)
        paired.append({'instance_id':name,'TSR_cost':a['cost'],'TRS_cost':b['cost'],'difference_cost':diff,'difference_gap_percentage_points':gap,'outcome':outcome})
    primary=summary['primary'];assert primary['valid_pairs']==16 and primary['unavailable_tasks']==0
    close(primary['mean_gap_difference_percentage_points_all16'],sum(x['difference_gap_percentage_points'] for x in paired)/16);close(primary['mean_cost_difference_all16'],sum(x['difference_cost'] for x in paired)/16)
    for status in ('improved','equal','worse'):assert primary[status+'_tasks']==sum(x['outcome']==status for x in paired)
    curves=list(csv.DictReader((R/'reports/FIXED_BUDGET_TRAJECTORIES.csv').open()));assert len(curves)==16*2*6 and len({(r['instance_id'],r['arm'],r['budget_node']) for r in curves})==192
    for row in curves:
        got=details[(row['instance_id'],row['arm'])];level=int(row['budget_node']);assert int(row['cost'])==got['curve'][level] and int(row['actual_attempted_to_terminal'])==got['attempted']
        assert row['carried_after_certified_local_optimum']==str(got['termination']=='LOCAL_OPTIMUM' and level>got['attempted'])
    for row,level in zip(summary['secondary_all_frozen_nodes'],LEVELS):
        assert row['budget_node']==level and row['valid_pairs']==16
        close(row['equal_task_mean_gap_difference_percentage_points_all16'],sum(100*(details[(t['instance_id'],'TSR')]['curve'][level]-details[(t['instance_id'],'TRS')]['curve'][level])/refs[t['instance_id']]['reference_integer_cost'] for t in tasks)/16)
    for arm,s in summary['arms'].items():
        rr=[details[(t['instance_id'],arm)] for t in tasks];assert s['valid_tasks']==16 and s['failure_or_undetermined_tasks']==0
        close(s['mean_reference_gap_percent_all16'],sum(100*(x['cost']/x['reference_cost']-1) for x in rr)/16);assert s['cost_sum_all16']==sum(x['cost'] for x in rr)
        for k in ('attempted','feasible','accepted'):assert s[k+'_sum']==sum(x[k] for x in rr)
        assert s['local_optimum_tasks']==sum(x['termination']=='LOCAL_OPTIMUM' for x in rr) and s['budget_exhausted_tasks']==sum(x['termination']=='BUDGET_EXHAUSTED' for x in rr)
        for op in OPS[arm]:
            for metric in ('attempted','feasible','accepted'):assert s['operator_counts'][op][metric]==sum(x['counts'][op][metric] for x in rr)
            assert s['never_entered_scan_tasks'][op]==[x['instance_id'] for x in rr if x['first'][op]['scan'] is None] and s['zero_candidate_tasks'][op]==[x['instance_id'] for x in rr if x['counts'][op]['attempted']==0]
    assert summary['tasks']==16 and summary['coordinate_demand_bases']==14 and summary['new_formal_calls']==16 and summary['historical_public_optimization_reruns']==0
    result={'status':'PASS','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'public_optimizer_calls_by_reviewer':0,'independent_recorded_candidate_replay_only':True,'saved_primary_calls_audited':32,'total_saved_candidates_audited':sum(x['attempted'] for x in details.values()),'new_saved_candidates':sum(x['attempted'] for (n,a),x in details.items() if a=='TSR'),'all_candidate_deltas_full_rescored':True,'all_scans_candidate_order_and_restarts_verified':True,'all_operator_counts_first_entries_accepted_moves_checkpoints_verified':True,'curve_rows_verified':192,'paired_primary':primary,'paired_tasks':paired,'details':list(details.values()),'frozen_and_upstream_hashes_unchanged':True,'actual_preexec_and_raw_download_hashes_bytes_crc_and_members_verified':True,'raw_archive_precedes_report_by_member_evidence':True,'new_calls_exactly16_no_reruns_in_saved_ledger':True,'report_numeric_tables_independently_recomputed':True,'source_engine_not_imported':True}
    (O/'FORMAL_SAVED_TRACE_AND_REPORT_REVIEW.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('details','paired_tasks')},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
