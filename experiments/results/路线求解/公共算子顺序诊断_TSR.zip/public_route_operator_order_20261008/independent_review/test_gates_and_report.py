"""Runs copied supervisor control flow with a stub Popen: NO optimizer process is started."""
import pathlib,json,hashlib,types,importlib.util,sys,contextlib,io,datetime,zipfile
sys.dont_write_bytecode=True
from independent_core import oracle,LEVELS
R=pathlib.Path('/workspace/shared/public_route_operator_order_20261008');O=pathlib.Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x))
def load(p,name):
    spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
sys.path.insert(0,str(R/'source'));run=load(R/'source/run_once.py','reviewed_supervisor');report=load(R/'source/report.py','reviewed_report')
class Resource:
    RLIMIT_CPU=0;RLIMIT_AS=1;RUSAGE_CHILDREN=2;RUSAGE_SELF=3
    def __init__(self):self.limits=[]
    def setrlimit(self,*v):self.limits.append(v)
    def getrusage(self,*v):return types.SimpleNamespace(ru_utime=0.,ru_stime=0.,ru_maxrss=0)
class Signal:
    def __init__(self):self.alarms=[]
    def alarm(self,s):self.alarms.append(s)
class ProcessFactory:
    PIPE=object();TimeoutExpired=TimeoutError
    def __init__(self):self.calls=[]
    def Popen(self,args,stdin,stdout,stderr,env):
        factory=self
        class P:
            returncode=0
            def communicate(self,payload,timeout):
                x=json.loads(payload);factory.calls.append((args,x,timeout,env))
                assert set(x)=={'coordinates','demands','capacity','routes','arm','budget'}
                assert x['arm']=='TSR' and x['budget']==20000 and timeout==3
                assert args[1]=='-B' and env['PYTHONDONTWRITEBYTECODE']=='1'
                stdout.write(json.dumps({'arm':'TSR','attempted':0,'reference_read_attempts':0,'denied_io_events':[],'routes':x['routes'],'loads':[2,0]}).encode())
        return P()
def gate_fixture(name):
    f=O/'gate_fixtures'/name;f.mkdir(parents=True,exist_ok=False)
    (f.parent/(f.name+'_PREEXEC.zip')).write_bytes(b'INVENTED preexec archive bytes')
    newdownload=f/'new_download.zip';newdownload.write_bytes(b'INVENTED preexec archive bytes')
    oldsrc=f/'old_source.zip';oldsrc.write_bytes(b'INVENTED old archive bytes');olddownload=f/'old_download.zip';olddownload.write_bytes(oldsrc.read_bytes());orig=f/'old_original_receipt.json';save(orig,{'invented_receipt':True})
    save(f/'freeze/UPSTREAM_FINAL_ARCHIVE_GATE.json',{'owner_only':True,'remote_readback_sha256_verified':True,'download_byte_identical':True,'sha256':sha(oldsrc),'download_sha256':sha(olddownload),'download_path':str(olddownload),'source':str(oldsrc),'original_receipt_path':str(orig),'original_receipt_sha256':sha(orig),'confirmed_at_utc':'2020-01-01T00:00:00Z'})
    marker=f/'marker';marker.write_text('INVENTED frozen content');save(f/'freeze/FROZEN_FILES.json',{'files':{'marker':{'sha256':sha(marker)}}});save(f/'freeze/INDEPENDENT_PRECHECK.json',{'status':'PASS'})
    save(f/'provenance/PREEXEC_DRIVE_RECEIPT.json',{'owner_only':True,'remote_readback_sha256_verified':True,'frozen_files_sha256':sha(f/'freeze/FROZEN_FILES.json'),'download_byte_identical':True,'shared':False,'sha256':sha(newdownload),'download_sha256':sha(newdownload),'download_path':str(newdownload)})
    tasks=[];schedule=[]
    for i in range(1,17):
        name=f'invented_{i}';tasks.append({'instance_id':name,'selection_slot':i,'K':2,'baseline_routes':[[0,1,2,0],[0,0]]});schedule.append({'call_id':f'F{i:02}_TSR','selection_slot':i,'instance_id':name,'arm':'TSR'})
        save(f/f'inputs/instances/{name}.json',{'instance_id':name,'coordinates':[[0,0],[1,0],[2,0]],'demands':[0,1,1],'capacity':2,'K':2})
    save(f/'inputs/SEARCH_TASKS.json',tasks);save(f/'freeze/SCHEDULE.json',schedule)
    return f

def change(f,path,key,val):
    p=f/path;x=json.loads(p.read_text());x[key]=val;save(p,x)
scenarios={
 'missing_receipt':lambda f:(f/'provenance/PREEXEC_DRIVE_RECEIPT.json').unlink(),
 'owner_only_false':lambda f:change(f,'provenance/PREEXEC_DRIVE_RECEIPT.json','owner_only',False),
 'readback_false':lambda f:change(f,'provenance/PREEXEC_DRIVE_RECEIPT.json','remote_readback_sha256_verified',False),
 'new_download_tampered':lambda f:(f/'new_download.zip').write_bytes(b'changed'),
 'old_download_tampered':lambda f:(f/'old_download.zip').write_bytes(b'changed'),
 'old_original_receipt_tampered':lambda f:(f/'old_original_receipt.json').write_bytes(b'changed'),
 'old_future_confirmation':lambda f:change(f,'freeze/UPSTREAM_FINAL_ARCHIVE_GATE.json','confirmed_at_utc','2999-01-01T00:00:00Z'),
 'shared_true':lambda f:change(f,'provenance/PREEXEC_DRIVE_RECEIPT.json','shared',True),
 'new_byte_identity_false':lambda f:change(f,'provenance/PREEXEC_DRIVE_RECEIPT.json','download_byte_identical',False),
 'frozen_tampered':lambda f:(f/'marker').write_text('changed'),
 'precheck_failed':lambda f:change(f,'freeze/INDEPENDENT_PRECHECK.json','status','FAIL'),
 'only15_tasks':lambda f:save(f/'inputs/SEARCH_TASKS.json',json.loads((f/'inputs/SEARCH_TASKS.json').read_text())[:-1]),
 'invalid_capacity':lambda f:change(f,'inputs/instances/invented_1.json','capacity',0)}
results=[]
for name,mutation in scenarios.items():
    f=gate_fixture(name);mutation(f);run.R=f;run.resource=Resource();run.signal=Signal();run.subprocess=ProcessFactory()
    try:run.main();raise RuntimeError('gate did not block')
    except (AssertionError,FileNotFoundError):pass
    assert len(run.subprocess.calls)==0 and not (f/'raw/STARTED.json').exists()
    results.append({'scenario':name,'blocked_before_started_and_popen':True})
f=gate_fixture('success_and_repeat');run.R=f;run.resource=Resource();run.signal=Signal();run.subprocess=ProcessFactory();run.main()
assert len(run.subprocess.calls)==16 and run.resource.limits==[(0,(5,5)),(1,(512*1024**2,512*1024**2))] and run.signal.alarms==[60,0]
try:run.main();raise RuntimeError('repeat not blocked')
except FileExistsError:pass
assert len(run.subprocess.calls)==16
results.append({'scenario':'positive16_invented_stub_calls_then_repeat_blocked','stub_calls':16,'real_processes':0})

# Real bounded worker receives one invented input; compare all non-timing fields to independent oracle.
import subprocess
payload={'coordinates':[[0,0],[1,0],[2,0]],'demands':[0,1,1],'capacity':2,'routes':[[0,1,2,0],[0,0]],'arm':'TSR','budget':20000}
p=subprocess.run([sys.executable,'-B',str(R/'source/worker.py')],input=json.dumps(payload),text=True,capture_output=True,timeout=3)
assert p.returncode==0 and not p.stderr;worker=json.loads(p.stdout);expected=oracle(payload['coordinates'],payload['demands'],2,payload['routes'],'TSR',20000)
assert all(worker[k]==v for k,v in expected.items());assert worker['limits']=={'hard_cpu_seconds':2,'external_wall_seconds':3,'address_space_MiB':256};assert worker['reference_read_attempts']==0 and worker['denied_io_events']==[]
(O/'INVENTED_WORKER_TSR.stdout').write_text(p.stdout)

# Exercise reporter unchanged on invented saved records, including retained failure.
report_checks=[]
for fail in (False,True):
    f=O/'report_fixtures'/('failure' if fail else 'success');f.mkdir(parents=True,exist_ok=False);(f/'reports').mkdir()
    tasks=[];refs=[];new=[];history=[]
    for i in range(1,17):
        name=f'invented_{i}';tasks.append({'instance_id':name,'selection_slot':i,'K':2,'baseline_routes':payload['routes']});refs.append({'instance_id':name,'reference_routes':payload['routes'],'reference_integer_cost':4,'baseline_integer_cost':4})
        instance=f/f'inputs/instances/{name}.vrp';instance.parent.mkdir(parents=True,exist_ok=True);instance.write_text('NAME : invented\nTYPE : CVRP\nDIMENSION : 3\nCAPACITY : 2\nEDGE_WEIGHT_TYPE : EUC_2D\nNODE_COORD_SECTION\n1 0 0\n2 1 0\n3 2 0\nDEMAND_SECTION\n1 0\n2 1\n3 1\nDEPOT_SECTION\n1\n-1\nEOF\n')
        for prefix,arm,records in (('', 'TSR',new),('history/','TRS',history)):
            result=oracle(payload['coordinates'],payload['demands'],2,payload['routes'],arm,20000);path=f'{prefix}raw/calls/F{i}_{arm}.stdout';save(f/path,result)
            records.append({'call_id':f'F{i}_{arm}','selection_slot':i,'instance_id':name,'arm':arm,'status':'FAILED' if fail and i==1 and arm=='TSR' else 'SUCCESS','stdout':f'raw/calls/F{i}_{arm}.stdout','stdout_sha256':sha(f/path),'process_cpu_seconds_for_audit_only':0,'process_wall_seconds_for_audit_only':0})
    save(f/'inputs/SEARCH_TASKS.json',tasks);save(f/'inputs/POSTSCORING_REFERENCES.json',refs)
    for prefix,records in (('',new),('history/',history)):
        (f/f'{prefix}raw/results.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in records))
    save(f/'freeze/UPSTREAM_FILES_BEFORE.json',{});save(f/'freeze/PROTOCOL.json',{'limitations':['synthetic reporter test']});save(f/'history/reports/SUMMARY.json',{'arms':{'T':{},'TR':{},'TS':{}}});save(f/'freeze/FROZEN_FILES.json',{'files':{}});save(f/'raw/RAW_UNREVIEWED_MANIFEST.json',{'files':{}})
    archive=f.parent/(f.name+'_RAW_UNREVIEWED.zip');archive.write_bytes(b'invented raw archive');download=f/'download.zip';download.write_bytes(archive.read_bytes());save(f/'provenance/RAW_UNREVIEWED_DRIVE_RECEIPT.json',{'owner_only':True,'remote_readback_sha256_verified':True,'download_byte_identical':True,'sha256':sha(archive),'download_sha256':sha(download),'download_path':str(download)})
    report.R=f
    with contextlib.redirect_stdout(io.StringIO()):report.main()
    summary=json.loads((f/'reports/SUMMARY.json').read_text());assert summary['primary']['valid_pairs']==(15 if fail else 16);assert summary['primary']['unavailable_tasks']==int(fail)
    assert summary['primary']['mean_gap_difference_percentage_points_all16']==(None if fail else 0.0)
    assert len(summary['secondary_all_frozen_nodes'])==6
    for row in summary['secondary_all_frozen_nodes']:assert row['valid_pairs']==(15 if fail else 16) and row['equal_task_mean_gap_difference_percentage_points_all16']==(None if fail else 0.0)
    report_checks.append({'retained_failure':fail,'six_nodes_all16_mean_and_missingness_verified':True})
# Verify upstream archive locally and all copied members, including complete old primary traces.
gate=json.loads((R/'freeze/UPSTREAM_FINAL_ARCHIVE_GATE.json').read_text());source=pathlib.Path(gate['source']);download=pathlib.Path(gate['download_path']);assert source.read_bytes()==download.read_bytes() and sha(source)==gate['sha256']==gate['download_sha256']
assert sha(pathlib.Path(gate['original_receipt_path']))==gate['original_receipt_sha256']
with zipfile.ZipFile(download) as z:
    assert z.testzip() is None
    copied=json.loads((R/'freeze/COPIED_INPUTS_AND_HISTORY.json').read_text())['files']
    root=pathlib.Path(json.loads((R/'freeze/COPIED_INPUTS_AND_HISTORY.json').read_text())['source_root'])
    for rel,meta in copied.items():assert z.read(root.name+'/'+str(pathlib.Path(meta['source']).relative_to(root)))==(R/rel).read_bytes()
result={'status':'PASS','public_optimizer_calls':0,'actual_worker_calls_invented_only':1,'stub_supervisor_no_real_process_calls':16,'gating_scenarios':results,'resource_limits_static_and_stub_verified':True,'CPU_upper_bound_seconds':37,'parent_alarm_seconds':60,'sequential_child_wall_timeout_seconds':3,'reporter_synthetic_cases':report_checks,'upstream_final_download_actual_bytes_verified':True,'upstream_final_zip_crc_and_copied127_members_verified':True,'source_sha256':{p.name:sha(p) for p in sorted((R/'source').glob('*.py'))},'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(O/'GATES_REPORT_REVIEW.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
