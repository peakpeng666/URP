import pathlib,json,hashlib,datetime
from independent_core import *
R=pathlib.Path('/workspace/shared/public_route_operator_order_20261008');O=pathlib.Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
copied=read(R/'freeze/COPIED_INPUTS_AND_HISTORY.json')['files']
for rel,m in copied.items():
    p=R/rel;src=pathlib.Path(m['source']);assert sha(p)==m['sha256']==sha(src) and p.stat().st_size==m['bytes']
prior=read(R/'freeze/UPSTREAM_FILES_BEFORE.json')
for p,m in prior.items():assert sha(pathlib.Path(p))==m['sha256']
tasks=read(R/'inputs/SEARCH_TASKS.json');schedule=read(R/'freeze/SCHEDULE.json');refs={x['instance_id']:x for x in read(R/'inputs/POSTSCORING_REFERENCES.json')}
initial={x['call_id']:x for x in map(json.loads,(R/'inputs/prior/ORIGINAL_INITIALIZER_RESULTS.jsonl').read_text().splitlines())};hist=list(map(json.loads,(R/'history/raw/results.jsonl').read_text().splitlines()))
assert len(tasks)==len(schedule)==len(refs)==16 and len(initial)==96 and len(hist)==64
assert [t['selection_slot'] for t in tasks]==list(range(1,17));assert [e['selection_slot'] for e in schedule]==list(range(1,17));assert len({e['call_id'] for e in schedule})==16
out=[];bases=set()
for task,entry in zip(tasks,schedule):
    name=task['instance_id'];slot=task['selection_slot'];data=read(R/'inputs/instances'/f'{name}.json');norm=read(R/'inputs/normalized'/f'{name}.json')
    assert entry=={'call_id':f'O{slot:02}_TSR','selection_slot':slot,'instance_id':name,'arm':'TSR','paired_historical_call_id':f'T{slot:02}_TRS'}
    assert set(data)=={'instance_id','coordinates','demands','capacity','K'} and data['instance_id']==name and data['K']==task['K']==norm['K']
    cc,dem,q,d=read_vrp(R/'inputs/instances'/f'{name}.vrp')
    assert [[Decimal(str(v)) for v in row] for row in data['coordinates']]==cc
    assert data['demands']==dem==norm['demands'] and data['coordinates']==norm['coordinates'] and q==data['capacity']==norm['capacity']
    assert dem[0]==0 and all(type(v)is int and v>=0 for v in dem)
    assert 'fixed K_ref slots' in norm['problem_definition'] and 'at most K_ref nonempty' in norm['problem_definition']
    base=validate(task['baseline_routes'],dem,q,task['K'],d)
    assert len(task['original_call_ids'])==3
    for cid in task['original_call_ids']:
        origin=initial[cid];assert origin['instance_id']==name and origin['endpoint']=='initialize_256' and origin['status']=='SUCCESS' and origin['output']['routes']==task['baseline_routes']
    ref=refs[name];refchk=validate(ref['reference_routes'],dem,q,task['K'],d)
    assert base['cost']==ref['baseline_integer_cost'] and refchk['cost']==ref['reference_integer_cost']
    sr=[];declared=None
    for line in (R/'inputs/references'/f'{name}.sol').read_text().splitlines():
        if line.startswith('Route'):sr.append([0]+list(map(int,line.split(':',1)[1].split()))+[0])
        elif line.startswith('Cost'):declared=int(line.split()[-1])
    assert sr==ref['reference_routes'] and declared==refchk['cost']
    records=[x for x in hist if x['instance_id']==name];assert len(records)==4 and {x['arm'] for x in records}=={'T','TR','TS','TRS'}
    for meta in records:
        assert meta['selection_slot']==slot and meta['status']=='SUCCESS';stdout=(R/'history'/meta['stdout']) if meta['arm']=='TRS' else pathlib.Path(read(R/'freeze/COPIED_INPUTS_AND_HISTORY.json')['source_root'])/meta['stdout'];assert sha(stdout)==meta['stdout_sha256']
        saved=read(stdout);assert saved['initial_cost']==base['cost'] and saved['budget']==20000
    bases.add(json.dumps([data['coordinates'],data['demands']],separators=(',',':')))
    out.append({'instance_id':name,'slot':slot,**base,'reference_cost':refchk['cost'],'original_initializer_records_verified':3,'historical_arms_verified':4})
assert len(bases)==14
protocol=read(R/'freeze/PROTOCOL.json')
assert protocol['arms']=={'TSR':['two_opt','swap','relocate']} and protocol['secondary_frozen_checkpoints']==LEVELS
assert protocol['budget']['attempted_candidates_per_task_arm']==20000 and protocol['budget']['total_max_candidates']==320000
assert protocol['limits']=={'formal_calls':16,'max_concurrent_children':1,'per_child_hard_CPU_seconds':2,'per_child_external_wall_seconds':3,'per_child_address_space_MiB':256,'supervisor_hard_CPU_seconds':5,'supervisor_wall_alarm_seconds':60,'supervisor_address_space_MiB':512,'total_CPU_hard_bound_seconds':37,'combined_address_space_MiB':768,'proof':'5+16*2=37 CPU seconds; parent alarm60; one child at a time. Same per-call limits as historical TRS; resource metrics are auditing only, not equal-time comparison.'}
assert not (R/'raw/STARTED.json').exists()
result={'status':'PASS','public_optimizer_calls':0,'independently_parsed_EUC_2D_16_inputs':True,'original_initializer_saved_records_checked':48,'historical_saved_call_metadata_checked':64,'byte_identical_copied_files':len(copied),'upstream_preexisting_files_unchanged':len(prior),'unique_coordinate_demand_bases':len(bases),'planned_new_calls':len(schedule),'all_tasks':out,'protocol_primary_comparator':'Historical frozen TRS; all16 equal-task terminal difference; historical T/TR/TS context only','six_frozen_nodes':LEVELS,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(O/'INPUT_PROTOCOL_REVIEW.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='all_tasks'},indent=2))
