import sys,pathlib,importlib.util,json,random,hashlib,ast,datetime
sys.dont_write_bytecode=True
from independent_core import *
R=pathlib.Path('/workspace/shared/public_route_operator_order_20261008');O=pathlib.Path(__file__).resolve().parent

def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
new=load(R/'source/engine.py','new_engine');old=load(R/'history/source/engine.py','old_engine')
a=ast.parse((R/'source/engine.py').read_text());b=ast.parse((R/'history/source/engine.py').read_text())
assert new.OPS==OPS and old.OPS=={k:v for k,v in OPS.items() if k!='TSR'}
a.body=[x for x in a.body if not(isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='OPS' for t in x.targets))]
b.body=[x for x in b.body if not(isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='OPS' for t in x.targets))]
assert ast.dump(a)==ast.dump(b)
for name in ('worker.py','check_saved.py'):assert (R/'source'/name).read_bytes()==(R/'history/source'/name).read_bytes()
assert new.matrix([[0,0],[.5,0],[1.5,0],[2.5,0]])==matrix([[0,0],[.5,0],[1.5,0],[2.5,0]])
rng=random.Random(732621);fixtures=[]
for f in range(90):
    n=2+f%11;k=1+f%5;coord=[[rng.randrange(-25,26),rng.randrange(-25,26)] for _ in range(n)];dem=[0]+[rng.randrange(0,7) for _ in range(n-1)]
    groups=[[] for _ in range(k)];ids=list(range(1,n));rng.shuffle(ids)
    for t,x in enumerate(ids):groups[t%k].append(x)
    rr=[[0]+g+[0] for g in groups];q=max(loads(rr,dem))+f%3;fixtures.append((coord,dem,q,rr))
# Explicit capacity failures, empty slot, all-zero costs, and a capped larger invented case.
fixtures += [([[0,0],[1,0],[2,0]],[0,3,4],4,[[0,1,0],[0,2,0],[0,0]]),([[0,0]]*4,[0,1,1,1],3,[[0,1,2,3,0],[0,0]])]
n=49;k=8;coord=[[rng.randrange(-100,101),rng.randrange(-100,101)] for _ in range(n)];dem=[0]+[1]*(n-1);ids=list(range(1,n));rng.shuffle(ids);rr=[[0]+ids[a::k]+[0] for a in range(k)];fixtures.append((coord,dem,8,rr))
coverage={'capacity_rejects':0,'accepted_by_operator':{o:0 for o in OPS['TSR']},'empty_slots_in_fixtures':0,'budget_exhausted_positive':0,'local_optimum':0,'zero_candidate_scan_entries':0};calls=0;eq=0;checked=0;finger=hashlib.sha256()
for f,(coord,dem,q,rr) in enumerate(fixtures):
    d=matrix(coord);validate(rr,dem,q,len(rr),d);coverage['empty_slots_in_fixtures']+=sum(r==[0,0] for r in rr)
    for op in OPS['TSR']:
        cs=candidates(rr,op);assert cs==list(new.candidates(rr,op))
        for c in cs:
            changed=transformed(rr,op,c);ok=all(x<=q for x in loads(changed,dem));actual=new.evaluate(rr,loads(rr,dem),dem,q,d,op,c)
            assert actual==(ok,score(changed,d)-score(rr,d) if ok else None)
            checked+=1
    budgets=(0,1,2,7,100,1000,20000) if f<92 else (20000,)
    for arm in OPS:
        for budget in budgets:
            actual=new.search(coord,dem,q,rr,arm,budget);expected=oracle(coord,dem,q,rr,arm,budget)
            assert actual==expected,(f,arm,budget,next((k for k in expected if actual[k]!=expected[k]),None))
            if arm!='TSR':assert old.search(coord,dem,q,rr,arm,budget)==actual;eq+=1
            validate(actual['routes'],dem,q,len(rr),d)
            finger.update(json.dumps(actual,sort_keys=True,separators=(',',':')).encode());calls+=1
            coverage['capacity_rejects']+=actual['attempted']-actual['feasible']
            for op,v in actual['counts'].items():coverage['accepted_by_operator'][op]+=v['accepted']
            coverage['budget_exhausted_positive']+=int(actual['termination']=='BUDGET_EXHAUSTED' and budget>0)
            coverage['local_optimum']+=int(actual['termination']=='LOCAL_OPTIMUM')
            coverage['zero_candidate_scan_entries']+=sum(s['start_attempted']==s['end_attempted'] for s in actual['scans'])
            assert actual['attempted']<=budget
assert all(coverage['accepted_by_operator'].values()) and coverage['capacity_rejects'] and coverage['zero_candidate_scan_entries']
result={'status':'PASS','scope':'invented fixtures only; no public optimizer calls','fixtures':len(fixtures),'independent_full_output_comparisons':calls,'historical_old_arm_full_output_equalities':eq,'candidate_delta_feasibility_full_rescore_checks':checked,'coverage':coverage,'full_output_digest_sha256':finger.hexdigest(),'engine_only_ops_extension':True,'worker_check_saved_byte_identical':True,'engine_sha256':hashlib.sha256((R/'source/engine.py').read_bytes()).hexdigest(),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(O/'SYNTHETIC_REVIEW.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
