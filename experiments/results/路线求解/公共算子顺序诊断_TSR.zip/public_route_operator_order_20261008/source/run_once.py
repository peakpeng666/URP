"""Single use supervisor. Search has no reference fields or files; score after all16 calls."""
import pathlib,json,hashlib,subprocess,resource,datetime,time,signal,sys,os,traceback
from check_saved import validate_input
R=pathlib.Path(__file__).resolve().parents[1]
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v,mode='w'):
    with p.open(mode) as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
def append(p,v):
    with p.open('a') as f:f.write(json.dumps(v,separators=(',',':'))+'\n');f.flush();os.fsync(f.fileno())
def main():
    resource.setrlimit(resource.RLIMIT_CPU,(5,5));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2));signal.alarm(60)
    (R/'raw/calls').mkdir(parents=True,exist_ok=True)
    wall=time.monotonic();cpu=time.process_time();receipt=json.loads((R/'provenance/PREEXEC_DRIVE_RECEIPT.json').read_text())
    assert receipt.get('owner_only') is True and receipt.get('remote_readback_sha256_verified') is True
    assert receipt['frozen_files_sha256']==sha(R/'freeze/FROZEN_FILES.json')
    assert receipt['download_byte_identical'] and receipt['shared'] is False
    assert receipt['sha256']==receipt['download_sha256']==sha(R.parent/(R.name+'_PREEXEC.zip'))==sha(pathlib.Path(receipt['download_path']))
    old_receipt=json.loads((R/'freeze/UPSTREAM_FINAL_ARCHIVE_GATE.json').read_text())
    assert old_receipt['owner_only'] and old_receipt['remote_readback_sha256_verified'] and old_receipt['download_byte_identical']
    assert old_receipt['sha256']==old_receipt['download_sha256']==sha(pathlib.Path(old_receipt['download_path']))
    assert old_receipt['sha256']==sha(pathlib.Path(old_receipt['source']))
    assert old_receipt['original_receipt_sha256']==sha(pathlib.Path(old_receipt['original_receipt_path']))
    assert datetime.datetime.fromisoformat(old_receipt['confirmed_at_utc'].replace('Z','+00:00'))<datetime.datetime.now(datetime.timezone.utc)
    frozen=json.loads((R/'freeze/FROZEN_FILES.json').read_text())
    assert all(sha(R/p)==v['sha256'] for p,v in frozen['files'].items())
    assert json.loads((R/'freeze/INDEPENDENT_PRECHECK.json').read_text())['status']=='PASS'
    tasks=json.loads((R/'inputs/SEARCH_TASKS.json').read_text());schedule=json.loads((R/'freeze/SCHEDULE.json').read_text());assert len(tasks)==16 and len(schedule)==16
    for task in tasks:validate_input(json.loads((R/'inputs/instances'/f"{task['instance_id']}.json").read_text()),task)
    write(R/'raw/STARTED.json',{'utc':now(),'no_reruns':True,'receipt_sha256':sha(R/'provenance/PREEXEC_DRIVE_RECEIPT.json'),
        'frozen_files_sha256':sha(R/'freeze/FROZEN_FILES.json'),'upstream_final_receipt_sha256':sha(R/'freeze/UPSTREAM_FINAL_ARCHIVE_GATE.json'),'planned_calls':16},'x')
    results=[]
    for entry in schedule:
        call_id=entry['call_id'];task=tasks[entry['selection_slot']-1];assert task['instance_id']==entry['instance_id'] and entry['arm']=='TSR'
        out=R/'raw/calls'/f'{call_id}.stdout';err=R/'raw/calls'/f'{call_id}.stderr'
        data=json.loads((R/'inputs/instances'/f"{task['instance_id']}.json").read_text())
        payload={k:data[k] for k in ('coordinates','demands','capacity')};payload.update({'routes':task['baseline_routes'],'arm':entry['arm'],'budget':20000})
        append(R/'raw/attempts.jsonl',{'phase':'STARTED','utc':now(),**entry})
        start=time.monotonic();usage=resource.getrusage(resource.RUSAGE_CHILDREN);before=usage.ru_utime+usage.ru_stime;status='SUCCESS';code=None
        try:
            with out.open('xb') as fo,err.open('xb') as fe:
                p=subprocess.Popen([sys.executable,'-B',str(R/'source/worker.py')],stdin=subprocess.PIPE,stdout=fo,stderr=fe,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
                try:p.communicate(json.dumps(payload).encode(),timeout=3)
                except subprocess.TimeoutExpired:p.kill();p.communicate();status='WALL_TIMEOUT'
                code=p.returncode
                if code and status=='SUCCESS':status='PROCESS_FAILURE_OR_CPU_LIMIT'
            item={**entry,'status':status,'returncode':code,'stdout':str(out.relative_to(R)),'stderr':str(err.relative_to(R)),
                  'stdout_sha256':sha(out),'stderr_sha256':sha(err)}
            if status=='SUCCESS':
                result=json.loads(out.read_text());assert result['arm']==entry['arm'] and 0<=result['attempted']<=20000
                assert result['reference_read_attempts']==0 and result['denied_io_events']==[]
                item['summary']={k:v for k,v in result.items() if k not in ('trace','scans','routes','loads','accepted_moves','checkpoints')}
                item['nonempty_routes']=sum(len(r)>2 for r in result['routes']);item['K_slots']=len(result['routes'])
        except Exception as e:item={**entry,'status':'CALL_ERROR_UNDETERMINED','error':str(e),'traceback':traceback.format_exc(),'returncode':code}
        usage=resource.getrusage(resource.RUSAGE_CHILDREN)
        item['process_cpu_seconds_for_audit_only']=usage.ru_utime+usage.ru_stime-before;item['process_wall_seconds_for_audit_only']=time.monotonic()-start
        append(R/'raw/attempts.jsonl',{'phase':'FINISHED','utc':now(),**item});append(R/'raw/results.jsonl',item);results.append(item)
    signal.alarm(0);usage=resource.getrusage(resource.RUSAGE_CHILDREN)
    write(R/'raw/FINISHED.json',{'utc':now(),'status':'FINISHED' if all(r['status']=='SUCCESS' for r in results) else 'FINISHED_WITH_FAILURES',
          'planned_calls':16,'retained_calls':len(results),'retained_tasks':16,'supervisor_cpu_seconds_for_audit_only':time.process_time()-cpu,
          'children_cpu_seconds_for_audit_only':usage.ru_utime+usage.ru_stime,'wall_seconds_for_audit_only':time.monotonic()-wall,
          'parent_maxrss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'children_maxrss_KiB':usage.ru_maxrss,
          'hard_CPU_bound_seconds':37,'hard_wall_seconds':60,'combined_address_space_MiB':768,'max_concurrent_children':1})
    write(R/'raw/RAW_UNREVIEWED_MANIFEST.json',{'utc':now(),'status':'UNREVIEWED_RAW','files':{str(p.relative_to(R)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted((R/'raw').rglob('*')) if p.is_file()}})
if __name__=='__main__':main()
