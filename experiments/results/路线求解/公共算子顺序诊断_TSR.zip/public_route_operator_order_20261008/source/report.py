"""Postscore unique TSR calls against frozen historical TRS only after raw remote readback."""
import pathlib,json,csv,hashlib,datetime
from check_saved import raw_data,validate
R=pathlib.Path(__file__).resolve().parents[1]
LEVELS=(0,100,1000,5000,10000,20000)
OPS=('two_opt','relocate','swap')
def read(p):return json.loads((R/p).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):(R/p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def savecsv(p,rows):
    keys=list(dict.fromkeys(k for row in rows for k in row))
    with (R/p).open('w') as f:w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)
def op_metrics(result,op):
    scans=[s for s in result['scans'] if s['op']==op]
    first=next((i+1 for i,t in enumerate(result['trace']) if t[0]==op),None)
    return {**result['counts'][op],'first_scan_entry_after_attempts':scans[0]['start_attempted'] if scans else None,'first_candidate_attempt_1based':first,'scans_entered':len(scans)}
def main():
    receipt=read('provenance/RAW_UNREVIEWED_DRIVE_RECEIPT.json')
    assert receipt['owner_only'] and receipt['remote_readback_sha256_verified'] and receipt['download_byte_identical']
    assert receipt['sha256']==receipt['download_sha256']==sha(R.parent/(R.name+'_RAW_UNREVIEWED.zip'))==sha(pathlib.Path(receipt['download_path']))
    rawmanifest=read('raw/RAW_UNREVIEWED_MANIFEST.json');assert all(sha(R/p)==v['sha256'] for p,v in rawmanifest['files'].items())
    frozen=read('freeze/FROZEN_FILES.json');assert all(sha(R/p)==v['sha256'] for p,v in frozen['files'].items())
    tasks=read('inputs/SEARCH_TASKS.json');refs={x['instance_id']:x for x in read('inputs/POSTSCORING_REFERENCES.json')}
    new=[json.loads(x) for x in (R/'raw/results.jsonl').read_text().splitlines()]
    history=[json.loads(x) for x in (R/'history/raw/results.jsonl').read_text().splitlines()]
    old=[r for r in history if r['arm']=='TRS'];assert len(new)==len(old)==16
    assert [r['selection_slot'] for r in new]==list(range(1,17)) and all(r['arm']=='TSR' for r in new)
    rows=[];curves=[];byarm={'TRS':{},'TSR':{}}
    for prefix,records in [('history/',old),('',new)]:
        for meta in records:
            task=tasks[meta['selection_slot']-1];assert meta['instance_id']==task['instance_id'];ref=refs[task['instance_id']]
            row={k:meta[k] for k in ('call_id','selection_slot','instance_id','arm','status')}
            row.update(evidence_stage='historical_frozen' if prefix else 'new_unique_call',cost=None,reference_cost=ref['reference_integer_cost'])
            if meta['status']=='SUCCESS':
                result=read(prefix+meta['stdout']);assert sha(R/(prefix+meta['stdout']))==meta['stdout_sha256']
                d,dem,q,coords=raw_data(R/'inputs/instances'/f"{task['instance_id']}.vrp")
                base=validate(task['baseline_routes'],dem,q,task['K'],d);chk=validate(result['routes'],dem,q,task['K'],d);rr=validate(ref['reference_routes'],dem,q,task['K'],d)
                assert result['cost']==chk['cost']<=base['cost']==result['initial_cost']==ref['baseline_integer_cost']
                assert rr['cost']==ref['reference_integer_cost']
                row.update({k:result[k] for k in ('cost','initial_cost','attempted','feasible','accepted','termination','unspent_budget')})
                row.update(K_slots=chk['K_slots'],nonempty_routes=chk['nonempty_routes'],reference_gap_percent=100*(chk['cost']/rr['cost']-1),process_cpu_seconds_for_audit_only=meta['process_cpu_seconds_for_audit_only'],process_wall_seconds_for_audit_only=meta['process_wall_seconds_for_audit_only'])
                for op in OPS:
                    row.update({op+'_'+k:v for k,v in op_metrics(result,op).items()})
                for level in LEVELS:
                    known=result['attempted']>=level or result['termination']=='LOCAL_OPTIMUM';moves=[m for m in result['accepted_moves'] if m['attempted']<=level]
                    cost=moves[-1]['cost'] if moves else base['cost']
                    curves.append(dict(instance_id=task['instance_id'],selection_slot=task['selection_slot'],arm=meta['arm'],evidence_stage=row['evidence_stage'],budget_node=level,cost=cost if known else None,actual_attempted_to_terminal=result['attempted'],carried_after_certified_local_optimum=level>result['attempted'] and result['termination']=='LOCAL_OPTIMUM'))
            else:
                for level in LEVELS:curves.append(dict(instance_id=task['instance_id'],selection_slot=task['selection_slot'],arm=meta['arm'],evidence_stage=row['evidence_stage'],budget_node=level,cost=None,actual_attempted_to_terminal=None,carried_after_certified_local_optimum=False))
            rows.append(row);byarm[meta['arm']][task['instance_id']]=row
    paired=[]
    for task in tasks:
        name=task['instance_id'];a=byarm['TSR'][name];b=byarm['TRS'][name];valid=a['cost'] is not None and b['cost'] is not None
        diff=a['cost']-b['cost'] if valid else None
        paired.append(dict(instance_id=name,selection_slot=task['selection_slot'],reference_cost=a['reference_cost'],TSR_cost=a['cost'],historical_TRS_cost=b['cost'],TSR_minus_TRS_cost=diff,TSR_minus_TRS_gap_percentage_points=100*diff/a['reference_cost'] if valid else None,outcome='improved' if valid and diff<0 else 'worse' if valid and diff>0 else 'equal' if valid else 'unavailable',TSR_termination=a.get('termination'),historical_TRS_termination=b.get('termination'),TSR_attempted=a.get('attempted'),historical_TRS_attempted=b.get('attempted')))
    arm_summaries={}
    for arm,mapping in byarm.items():
        rr=list(mapping.values());good=[r for r in rr if r['cost'] is not None];full=len(good)==16
        arm_summaries[arm]=dict(valid_tasks=len(good),failure_or_undetermined_tasks=16-len(good),mean_reference_gap_percent_all16=sum(r['reference_gap_percent'] for r in good)/16 if full else None,cost_sum_all16=sum(r['cost'] for r in good) if full else None,attempted_sum=sum(r['attempted'] for r in good),feasible_sum=sum(r['feasible'] for r in good),accepted_sum=sum(r['accepted'] for r in good),local_optimum_tasks=sum(r['termination']=='LOCAL_OPTIMUM' for r in good),budget_exhausted_tasks=sum(r['termination']=='BUDGET_EXHAUSTED' for r in good),operator_counts={op:{metric:sum(r[op+'_'+metric] for r in good) for metric in ('attempted','feasible','accepted')} for op in OPS},never_entered_scan_tasks={op:[r['instance_id'] for r in good if r[op+'_first_scan_entry_after_attempts'] is None] for op in OPS},zero_candidate_tasks={op:[r['instance_id'] for r in good if r[op+'_attempted']==0] for op in OPS})
    valid=[r for r in paired if r['TSR_minus_TRS_cost'] is not None]
    primary=dict(contrast='TSR minus frozen historical TRS; negative favors TSR',valid_pairs=len(valid),mean_gap_difference_percentage_points_all16=sum(r['TSR_minus_TRS_gap_percentage_points'] for r in valid)/16 if len(valid)==16 else None,mean_cost_difference_all16=sum(r['TSR_minus_TRS_cost'] for r in valid)/16 if len(valid)==16 else None,improved_tasks=sum(r['outcome']=='improved' for r in paired),equal_tasks=sum(r['outcome']=='equal' for r in paired),worse_tasks=sum(r['outcome']=='worse' for r in paired),unavailable_tasks=16-len(valid))
    secondary=[]
    cm={(r['instance_id'],r['arm'],r['budget_node']):r for r in curves}
    for level in LEVELS:
        rr=[]
        for task in tasks:
            name=task['instance_id'];a=cm[(name,'TSR',level)]['cost'];b=cm[(name,'TRS',level)]['cost']
            if a is not None and b is not None:rr.append(100*(a-b)/refs[name]['reference_integer_cost'])
        secondary.append(dict(budget_node=level,valid_pairs=len(rr),equal_task_mean_gap_difference_percentage_points_all16=sum(rr)/16 if len(rr)==16 else None))
    previous=read('freeze/UPSTREAM_FILES_BEFORE.json');changed=[p for p,v in previous.items() if not pathlib.Path(p).is_file() or sha(pathlib.Path(p))!=v['sha256']]
    assert not changed,changed
    historical=read('history/reports/SUMMARY.json')
    summary=dict(stage='POSTHOC_OPERATOR_ORDER_ABLATION',scored_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),independent_review_status='PENDING',tasks=16,coordinate_demand_bases=14,new_formal_calls=16,historical_primary_comparator_calls=16,historical_public_optimization_reruns=0,arms=arm_summaries,primary=primary,secondary_all_frozen_nodes=secondary,historical_context_only={a:historical['arms'][a] for a in ('T','TR','TS')},frozen_files_unchanged=True,upstream_preexisting_files_unchanged=True,upstream_preexisting_file_count=len(previous),changed_upstream_files=changed,limitations=read('freeze/PROTOCOL.json')['limitations'])
    write('reports/SUMMARY.json',summary);savecsv('reports/PER_CALL.csv',rows);savecsv('reports/PAIRED_TSR_MINUS_TRS.csv',paired);savecsv('reports/FIXED_BUDGET_TRAJECTORIES.csv',curves)
    def fmt(v):return '不可用' if v is None else f'{v:.9f}'
    lines=['公共CVRP-derived算子顺序消融：新事后探索阶段','独立结果审查：待完成。','全部16固定任务，14坐标/需求底本。仅新增TSR16次正式调用；主对照为已保存TRS16项，不重跑旧臂。','TSR=[2-opt,swap,relocate]；历史TRS=[2-opt,relocate,swap]。初始路线、距离、容量和20,000候选上限相同。','',f"主指标，逐任务TSR−TRS的16任务等权平均gap差：{fmt(primary['mean_gap_difference_percentage_points_all16'])}个百分点。",f"改善{primary['improved_tasks']}，持平{primary['equal_tasks']}，退化{primary['worse_tasks']}，不可用{primary['unavailable_tasks']}。",f"平均整数成本差：{fmt(primary['mean_cost_difference_all16'])}；负值有利于TSR。",'']
    for arm,s in arm_summaries.items():lines.append(f"{arm}: {s['valid_tasks']}/16有效；平均reference gap {fmt(s['mean_reference_gap_percent_all16'])}%；实际尝试{s['attempted_sum']}；可行{s['feasible_sum']}；接受{s['accepted_sum']}；局部最优{s['local_optimum_tasks']}；预算终止{s['budget_exhausted_tasks']}。")
    lines+=['','逐任务主对照（TSR成本，历史TRS成本，gap差百分点）：']
    for r in paired:lines.append(f"{r['instance_id']}: {r['TSR_cost']}, {r['historical_TRS_cost']}, {fmt(r['TSR_minus_TRS_gap_percentage_points'])}；{r['outcome']}")
    lines+=['','所有六固定节点（仅描述，不选择最有利节点）：']
    for r in secondary:lines.append(f"{r['budget_node']}: TSR−TRS平均gap差{fmt(r['equal_task_mean_gap_difference_percentage_points_all16'])}个百分点；有效对{r['valid_pairs']}/16。")
    lines+=['','每算子的实际尝试、可行、接受、首次扫描进入和首次实际候选位置均见PER_CALL.csv；完整候选及扫描轨迹见raw。','首次扫描进入为进入算子时已消耗候选数，首次实际候选为1起算；空值表示未进入/未尝试，二者不可混淆。','容量失败候选计入预算。K个槽保持不变，允许空槽；K_slots与nonempty_routes分别记录。','reference只用于调用结束且raw私有归档回读后的评分，不是全局最优证书。','该对照可描述固定预算下两种顺序的差异；不能单独区分预算分配与贪心路径依赖。','同上限不等于同实际候选、同可行数或等CPU；不作速度、显著性、SOTA或跨新数据泛化声明。','T/TR/TS仅历史背景，不作为本轮新增臂或挑选赢家；未挑任务、节点或失败项。','旧已存在文件及本轮PREEXEC冻结文件哈希不变。','']
    (R/'reports/REPORT_ZH.txt').write_text('\n'.join(lines))
    print(json.dumps({'primary':primary,'arms':arm_summaries,'secondary':secondary},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
