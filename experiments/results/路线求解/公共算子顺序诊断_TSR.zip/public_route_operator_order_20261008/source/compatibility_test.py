"""Invented fixtures only: prove full output equality for all historical schedules."""
import importlib.util,json,random,pathlib,hashlib
from engine import search,matrix
from check_saved import raw_data,validate_input
R=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('old_frozen_engine',R/'history/source/engine.py');old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
def main():
    assert (R/'source/worker.py').read_bytes()==(R/'history/source/worker.py').read_bytes()
    assert (R/'source/check_saved.py').read_bytes()==(R/'history/source/check_saved.py').read_bytes()
    previous=(R/'history/source/engine.py').read_text();current=(R/'source/engine.py').read_text()
    assert current==previous.replace("'TS': ('two_opt','swap'), 'TRS': ('two_opt','relocate','swap')}","'TS': ('two_opt','swap'), 'TRS': ('two_opt','relocate','swap'),\n       'TSR': ('two_opt','swap','relocate')}")
    rng=random.Random(918273);pairs=0;fixtures=64
    for t in range(fixtures):
        n=1+t%10;k=1+t%5
        coords=[(rng.randrange(-50,51),rng.randrange(-50,51)) for _ in range(n)]
        demands=[0]+[rng.randrange(0,8) for _ in range(n-1)];routes=[[0,0] for _ in range(k)]
        order=list(range(1,n));rng.shuffle(order)
        for x in order:routes[rng.randrange(k)].insert(-1,x)
        q=max(sum(demands[x] for x in row) for row in routes)+t%3
        for arm in old.OPS:
            for budget in (0,1,2,7,37,100,1000,20000):
                assert search(coords,demands,q,routes,arm,budget)==old.search(coords,demands,q,routes,arm,budget)
                pairs+=1
    # Input validation and distance equivalence, not benchmark optimization.
    inputs=[]
    for task in json.loads((R/'inputs/SEARCH_TASKS.json').read_text()):
        data=json.loads((R/'inputs/instances'/f"{task['instance_id']}.json").read_text());validate_input(data,task)
        d,dem,q,coords=raw_data(R/'inputs/instances'/f"{task['instance_id']}.vrp")
        assert d==matrix(data['coordinates']) and dem==data['demands'] and q==data['capacity']
        assert data['coordinates']==[list(map(float,z)) for z in coords]
        inputs.append({'instance_id':task['instance_id'],'status':'PASS','n':len(dem),'K':task['K']})
    result={'status':'PASS','invented_fixtures':fixtures,'full_output_old_schedule_comparisons':pairs,'old_schedules':list(old.OPS),'only_engine_change':'Added TSR OPS tuple; search implementation byte-identical','worker_and_check_saved_byte_identical':True,'public_optimization_calls':0,'input_checks':inputs,'all16_EUC_2D_Decimal_matrix_match':True,'old_engine_sha256':hashlib.sha256((R/'history/source/engine.py').read_bytes()).hexdigest(),'new_engine_sha256':hashlib.sha256((R/'source/engine.py').read_bytes()).hexdigest()}
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
