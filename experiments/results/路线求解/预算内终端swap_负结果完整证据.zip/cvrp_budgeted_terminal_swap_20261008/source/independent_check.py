"""Independent full-output validator: exact squared integer rounding, no solver imports."""
from collections import Counter
from math import isqrt

def edge(a,b):
    squared=sum((x-y)**2 for x,y in zip(a,b));root=isqrt(squared)
    return root+int(4*squared>=(2*root+1)**2)

def check(raw,out):
    assert isinstance(out,dict)
    seen=[];loads=[];cost=0;edges=0
    assert len(out['routes'])<=raw['K']
    for route in out['routes']:
        assert len(route)>=3 and route[0]==route[-1]==0
        assert all(type(u) is int and 1<=u<len(raw['demands']) for u in route[1:-1])
        seen+=route[1:-1];load=sum(raw['demands'][u] for u in route[1:-1]);loads.append(load)
        assert load<=raw['capacity']
        for u,v in zip(route,route[1:]):cost+=edge(raw['coordinates'][u],raw['coordinates'][v]);edges+=1
    assert Counter(seen)==Counter(range(1,len(raw['demands'])))
    assert cost==out['reported_cost']
    return {'accepted':True,'cost':cost,'loads':loads,'routes':len(loads),'objective_edges':edges}
