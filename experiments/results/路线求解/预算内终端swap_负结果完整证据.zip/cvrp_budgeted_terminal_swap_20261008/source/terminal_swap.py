"""One complete lexical cross-route swap scan; atomic best-improving commit."""
import copy,time
from experiment import StopBudget

def scan(raw, original, matrix, budget):
    start=time.process_time(); wall=time.perf_counter()
    routes=[r[1:-1] for r in original['routes']]
    owner={u:(ri,pi) for ri,r in enumerate(routes) for pi,u in enumerate(r)}
    loads=[sum(raw['demands'][u] for u in r) for r in routes]
    stats=dict(all_pairs=0,same_route_skipped=0,capacity_pair_checks=0,capacity_inequalities=0,capacity_rejected=0,feasible_pair_deltas=0,distance_lookups=0,negative_pairs=0,zero_pairs=0,positive_pairs=0,commits=0,complete=False,stop_reason=None,best_pair=None,best_delta=0)
    trace=[]; best=None; budget.by_kind.setdefault('swap',0)
    try:
        for u in sorted(owner):
            for v in sorted(owner):
                if u>=v: continue
                budget.check();stats['all_pairs']+=1
                ri,pi=owner[u];rj,pj=owner[v]
                if ri==rj:
                    stats['same_route_skipped']+=1
                    trace.append({'u':u,'v':v,'status':'same_route_skipped'})
                    continue
                stats['capacity_pair_checks']+=1;stats['capacity_inequalities']+=2
                left_load=loads[ri]-raw['demands'][u]+raw['demands'][v]
                right_load=loads[rj]-raw['demands'][v]+raw['demands'][u]
                if left_load>raw['capacity'] or right_load>raw['capacity']:
                    stats['capacity_rejected']+=1
                    trace.append({'u':u,'v':v,'status':'capacity_rejected','new_loads':[left_load,right_load]})
                    continue
                budget.delta('swap')
                a=routes[ri][pi-1] if pi else 0;b=routes[ri][pi+1] if pi+1<len(routes[ri]) else 0
                c=routes[rj][pj-1] if pj else 0;d=routes[rj][pj+1] if pj+1<len(routes[rj]) else 0
                delta=matrix[a][v]+matrix[v][b]+matrix[c][u]+matrix[u][d]-matrix[a][u]-matrix[u][b]-matrix[c][v]-matrix[v][d]
                stats['feasible_pair_deltas']+=1;stats['distance_lookups']+=8
                stats['negative_pairs' if delta<0 else 'zero_pairs' if delta==0 else 'positive_pairs']+=1
                trace.append({'u':u,'v':v,'status':'feasible','delta':delta,'new_loads':[left_load,right_load]})
                if delta<0 and (best is None or (delta,u,v)<best):best=(delta,u,v)
        budget.check()  # timeout after enumeration must not commit an unfinished action
        stats['complete']=True
    except StopBudget as exc:stats['stop_reason']=str(exc)
    output=copy.deepcopy(original)
    if stats['complete'] and best is not None:
        delta,u,v=best;ri,pi=owner[u];rj,pj=owner[v]
        routes[ri][pi],routes[rj][pj]=v,u
        output={'routes':[[0]+r+[0] for r in routes],'reported_cost':original['reported_cost']+delta}
        stats.update(commits=1,best_pair=[u,v],best_delta=delta)
    stats.update(cpu_seconds=time.process_time()-start,wall_seconds=time.perf_counter()-wall)
    return output,stats,trace
