"""One-shot reference-blind run; unchanged strict RR2, one terminal atomic swap."""
import copy,hashlib,json,os,signal,sys,time,platform
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[1]
reads=[];denied=[]
def guard(event,args):
 if event!='open':return
 target,mode,flags=args
 if not isinstance(target,(str,bytes,os.PathLike)):return
 p=Path(os.fsdecode(target)).resolve()
 write=bool(flags & (os.O_WRONLY|os.O_RDWR)) if isinstance(flags,int) else bool(mode and any(c in mode for c in 'wax+'))
 if write:return
 if p.suffix=='.sol' or (str(p).startswith('/workspace/') and not any(p.is_relative_to(ROOT/part) for part in ['source','input','freeze']) and p!=ROOT/'reports/TOY_VALIDATION.json'):
  denied.append(str(p));raise PermissionError('read outside scientific allowlist '+str(p))
 reads.append(str(p))
sys.addaudithook(guard)
def dump(path,obj):
 with path.open('x') as f:json.dump(obj,f,indent=2);f.flush();os.fsync(f.fileno())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
freeze=json.loads((ROOT/'freeze/PRE_RUN_FREEZE.json').read_text())
for rel,value in freeze['hashes'].items():assert sha(ROOT/rel)==value,rel
assert json.loads((ROOT/'reports/TOY_VALIDATION.json').read_text())['status']=='PASS'
cfg=json.loads((ROOT/'freeze/PLAN.json').read_text());schedule=json.loads((ROOT/'freeze/SCHEDULE.json').read_text())
import official_solver as solver
from terminal_swap import scan
from experiment import StopBudget
capture={};original_matrix_for=solver.matrix_for
def capture_matrix(inst,budget):
 matrix=original_matrix_for(inst,budget);capture.update(matrix=matrix,budget=budget);return matrix
solver.matrix_for=capture_matrix
start=time.process_time();wall=time.perf_counter()
dump(ROOT/'raw/STARTED.json',{'pid':os.getpid(),'time_ns':time.time_ns(),'freeze_sha256':sha(ROOT/'freeze/PRE_RUN_FREEZE.json'),'planned':48})
stream=hashlib.sha256()
with (ROOT/'raw/heuristics.jsonl').open('x') as handle:
 for index,spec in enumerate(schedule):
  raw=json.loads((ROOT/'input'/f"{spec['instance_id']}.json").read_text())
  assert sorted(raw)==['K','capacity','coordinates','demands','instance_id']
  n=len(raw['demands'])-1;reserve=n*(n-1)//2 if spec['arm']=='terminal_swap' else 0
  row=dict(spec,schedule_index=index,reserved_deltas=reserve,rr2_delta_limit=160000-reserve)
  if time.process_time()-start+3>27 or time.perf_counter()-wall+10>55:
   row.update(status='NOT_RUN',output=None,stop_reason='main_resource_guard')
  else:
   t=time.process_time();w=time.perf_counter();capture.clear()
   rr=solver.run_one(raw,'regret2',spec['search_seed'],{'delta_limit':160000-reserve,'iterations':1000000000,'per_trajectory_cpu_seconds':3.,'per_trajectory_wall_seconds':10.,'neutral_accept':False})
   row['rr2']=rr;row['output']=copy.deepcopy(rr['output']);row['status']=rr['status'];row['swap']=None;row['swap_trace']=[]
   budget=capture.get('budget')
   if reserve and rr['status']=='LEGAL_COMPLETION':
    budget.limit=160000
    def handler(*args):raise StopBudget('combined_trajectory_hard_limit')
    ow=signal.signal(signal.SIGALRM,handler);oc=signal.signal(signal.SIGPROF,handler)
    try:
     # Original budget clock also covers initialization, RR2 and final check.
     budget.check()
     signal.setitimer(signal.ITIMER_REAL,max(0.000001,10-(time.perf_counter()-budget.wall_start)))
     signal.setitimer(signal.ITIMER_PROF,max(0.000001,3-(time.process_time()-budget.cpu_start)))
     row['output'],row['swap'],row['swap_trace']=scan(raw,rr['output'],capture['matrix'],budget)
    except StopBudget as exc:
     row['swap']={'complete':False,'commits':0,'stop_reason':str(exc)}
    finally:
     signal.setitimer(signal.ITIMER_REAL,0);signal.setitimer(signal.ITIMER_PROF,0)
     signal.signal(signal.SIGALRM,ow);signal.signal(signal.SIGPROF,oc)
   row['total_delta_deltas']=budget.deltas if budget else rr['deltas']
   row['total_delta_by_kind']=dict(budget.by_kind) if budget else rr['delta_by_kind']
   row['unused_delta_allowance']=160000-row['total_delta_deltas']
   row['conservative_reserve_unused']=reserve-(row['swap'] or {}).get('feasible_pair_deltas',0)
   row['trajectory_cpu_seconds']=time.process_time()-t;row['trajectory_wall_seconds']=time.perf_counter()-w
  line=json.dumps(row,ensure_ascii=False,allow_nan=False)+'\n';handle.write(line);handle.flush();os.fsync(handle.fileno());stream.update(line.encode())
  print(json.dumps({'index':index,**spec,'status':row['status'],'cost':(row['output'] or {}).get('reported_cost'),'cpu':row.get('trajectory_cpu_seconds')}),flush=True)
dump(ROOT/'raw/SEALED.json',{'rows':len(schedule),'sha256':stream.hexdigest(),'all_flushed_fsynced':True,'main_cpu_at_seal':time.process_time()-start,'main_wall_at_seal':time.perf_counter()-wall,'python':sys.version,'platform':platform.platform()})
dump(ROOT/'raw/READ_AUDIT.json',{'read_paths':sorted(set(reads)),'denied':denied,'reference_reads':0,'scope':'Python open audit installed before solver imports'})
