import hashlib,json,os,resource,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
receipt=ROOT/'receipts/LAUNCH.json'
with receipt.open('x') as f:json.dump({'launches':1,'started_ns':time.time_ns(),'cpu_soft':29,'cpu_hard':30,'wall_hard':60},f)
def limits():resource.setrlimit(resource.RLIMIT_CPU,(29,30))
c=resource.getrusage(resource.RUSAGE_CHILDREN);w=time.perf_counter();returncode=None;timedout=False
with (ROOT/'receipts/STDOUT.txt').open('x') as out,(ROOT/'receipts/STDERR.txt').open('x') as err:
 try:
  completed=subprocess.run([sys.executable,'-B',str(ROOT/'source/run.py')],stdout=out,stderr=err,preexec_fn=limits,timeout=60,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
  returncode=completed.returncode
 except subprocess.TimeoutExpired:timedout=True
c2=resource.getrusage(resource.RUSAGE_CHILDREN)
report={'returncode':returncode,'wall_timeout':timedout,'child_user_cpu':c2.ru_utime-c.ru_utime,'child_system_cpu':c2.ru_stime-c.ru_stime,'child_total_cpu':c2.ru_utime+c2.ru_stime-c.ru_utime-c.ru_stime,'supervised_wall_seconds':time.perf_counter()-w,'max_rss_kb':c2.ru_maxrss,'launches':1,'cpu_limit_seconds':30,'wall_limit_seconds':60}
(ROOT/'receipts/EXIT.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
