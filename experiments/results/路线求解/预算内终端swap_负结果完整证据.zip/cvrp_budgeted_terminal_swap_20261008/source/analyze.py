"""Post-seal independent full costs and exact non-timing baseline regression."""
import copy,hashlib,json,time
from pathlib import Path
from independent_check import check
ROOT=Path(__file__).resolve().parents[1]
OLD=Path('/workspace/shared/official_cvrp_neutral_validation_20261008')
start=time.process_time();wall=time.perf_counter()
def digest(b):return hashlib.sha256(b).hexdigest()
def canonical(o):return json.dumps(o,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def non_timing(o):
 if isinstance(o,dict):return {k:non_timing(v) for k,v in o.items() if not k.endswith('_seconds')}
 if isinstance(o,list):return [non_timing(v) for v in o]
 return o
rawbytes=(ROOT/'raw/heuristics.jsonl').read_bytes();seal=json.loads((ROOT/'raw/SEALED.json').read_text());assert digest(rawbytes)==seal['sha256']
rows=[json.loads(l) for l in rawbytes.splitlines()]
oldrows={(r['instance_id'],r['search_seed']):r for r in map(json.loads,(OLD/'raw/heuristics.jsonl').read_text().splitlines()) if r['method']=='regret2' and r['acceptance_mode']=='strict'}
checks=[];regression=[];pairs=[];checkpoints=[];counts=dict(outputs_checked=0,objective_edges=0,feasible_swaps_checked=0)
for row in rows:
 raw=json.loads((ROOT/'input'/f"{row['instance_id']}.json").read_text());record={'schedule_index':row['schedule_index'],'status':row['status']}
 if row['output'] is None:checks.append(record);continue
 def validate(out):
  if out is None:return
  result=check(raw,out);counts['outputs_checked']+=1;counts['objective_edges']+=result['objective_edges'];return result
 record['final']=validate(row['output']);rr=row['rr2']
 checkpoint=rr['baseline'] if rr['initialization']['deltas_after_initialization']<=40000 else None
 for entry in rr['trace']:
  if entry['deltas']<=40000:checkpoint=entry['incumbent']
 validate(checkpoint)
 checkpoints.append({'instance_id':row['instance_id'],'search_seed':row['search_seed'],'arm':row['arm'],'requested_deltas':40000,'reached_cut':rr['deltas']>=40000,'output':checkpoint})
 for key in ['output','baseline','current_output']:validate(rr[key])
 for step in rr['trace']:
  for key in ['candidate','current','incumbent']:validate(step.get(key))
 assert row['total_delta_deltas']<=160000
 if row['arm']=='baseline':
  old=oldrows[(row['instance_id'],row['search_seed'])]
  expected=non_timing({k:old[k] for k in rr})
  actual=non_timing(rr);a=canonical(actual);b=canonical(expected)
  regression.append({'instance_id':row['instance_id'],'search_seed':row['search_seed'],'pass':a==b,'actual_sha256':digest(a),'expected_sha256':digest(b),'fields':sorted(actual)})
  assert a==b,('baseline_non_timing_regression',row['instance_id'],row['search_seed'])
 elif row['swap'] is not None:
  original=rr['output'];loc={n:(ri,pi) for ri,r in enumerate(original['routes']) for pi,n in enumerate(r) if n}
  best=None
  for step in row['swap_trace']:
   if step['status']!='feasible':continue
   out=copy.deepcopy(original);u,v=step['u'],step['v'];ri,pi=loc[u];rj,pj=loc[v]
   out['routes'][ri][pi],out['routes'][rj][pj]=v,u
   out['reported_cost']+=step['delta'];validate(out);counts['feasible_swaps_checked']+=1
   if step['delta']<0 and (best is None or (step['delta'],u,v)<best):best=(step['delta'],u,v)
  if row['swap']['complete']:
   assert len(row['swap_trace'])==row['reserved_deltas']
   if best:assert row['swap']['best_pair']==list(best[1:]) and row['swap']['best_delta']==best[0]
   else:assert row['output']==original and row['swap']['commits']==0
  else:assert row['output']==original and row['swap']['commits']==0
 checks.append(record)
for inst in sorted(set(r['instance_id'] for r in rows)):
 for seed in sorted(set(r['search_seed'] for r in rows)):
  a=next(r for r in rows if r['instance_id']==inst and r['search_seed']==seed and r['arm']=='baseline')
  b=next(r for r in rows if r['instance_id']==inst and r['search_seed']==seed and r['arm']=='terminal_swap')
  if a['output'] and b['output']:
   ca=a['output']['reported_cost'];cb=b['output']['reported_cost'];pre=b['rr2']['output']['reported_cost']
   pairs.append({'instance_id':inst,'search_seed':seed,'baseline_cost':ca,'reserved_rr2_cost':pre,'swap_cost':cb,'paired_cost_difference':cb-ca,'reservation_cost_difference':pre-ca,'swap_improvement':cb-pre,'baseline_cpu_seconds':a['trajectory_cpu_seconds'],'treatment_cpu_seconds':b['trajectory_cpu_seconds'],'swap_commits':(b['swap'] or {}).get('commits',0),'feasible_pair_deltas':(b['swap'] or {}).get('feasible_pair_deltas',0),'total_delta_deltas':b['total_delta_deltas'],'reserved_deltas':b['reserved_deltas'],'unused_deltas':b['unused_delta_allowance']})
summary=[]
for inst in sorted(set(p['instance_id'] for p in pairs)):
 ps=[p for p in pairs if p['instance_id']==inst]
 summary.append({'instance_id':inst,'pairs':len(ps),'mean_cost_difference':sum(p['paired_cost_difference'] for p in ps)/len(ps),'improved':sum(p['paired_cost_difference']<0 for p in ps),'worsened':sum(p['paired_cost_difference']>0 for p in ps),'same':sum(p['paired_cost_difference']==0 for p in ps),'swap_commits':sum(p['swap_commits'] for p in ps)})
result={'planned':48,'emitted_rows':len(rows),'legal_finals':sum(c.get('final',{}).get('accepted',False) for c in checks),'baseline_non_timing_bitwise_pass':sum(r['pass'] for r in regression),'paired_results':pairs,'instance_summary':summary,'counts':counts,'audit_cpu_seconds':time.process_time()-start,'audit_wall_seconds':time.perf_counter()-wall,'no_references_read':True}
for filename,data in [('INDEPENDENT_CHECKS.json',checks),('BASELINE_REGRESSION.json',regression),('SUMMARY.json',result),('CHECKPOINTS_40K.json',checkpoints)]:
 (ROOT/'reports'/filename).write_text(json.dumps(data,indent=2))
print(json.dumps({k:v for k,v in result.items() if k not in ['paired_results']},indent=2))
