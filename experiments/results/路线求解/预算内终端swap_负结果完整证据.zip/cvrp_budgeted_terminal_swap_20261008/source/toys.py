import json,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[1]
import official_solver as solver
from experiment import Budget
from terminal_swap import scan
from independent_check import check,edge

def case(coords,demands,routes,capacity=100):
 raw={'instance_id':'synthetic','coordinates':coords,'demands':demands,'capacity':capacity,'K':len(routes)}
 matrix=[[edge(a,b) for b in coords] for a in coords]
 out={'routes':[[0]+r+[0] for r in routes]}
 out['reported_cost']=sum(matrix[u][v] for r in out['routes'] for u,v in zip(r,r[1:]))
 return raw,matrix,out

results=[]
def run(label,raw,matrix,out,limit):
 budget=Budget(limit,3,10);new,stats,trace=scan(raw,out,matrix,budget)
 checked=check(raw,new)
 for item in trace:
  if item['status']=='feasible':
   rs=[r[:] for r in out['routes']];u=item['u'];v=item['v'];loc={n:(i,j) for i,r in enumerate(rs) for j,n in enumerate(r) if n}
   i,j=loc[u];k,l=loc[v];rs[i][j],rs[k][l]=v,u
   check(raw,{'routes':rs,'reported_cost':out['reported_cost']+item['delta']})
 results.append({'case':label,'stats':stats,'trace':trace,'check':checked,'deltas':budget.deltas})
 return new,stats,trace

raw,mat,out=case([[0,0],[10,0],[-10,0],[10,0],[-10,0]],[0,1,1,1,1],[[1,2],[3,4]])
new,st,tr=run('negative_and_best_tie',raw,mat,out,4)
assert st['best_pair']==[1,4] and st['best_delta']==-40 and st['commits']==1 and st['same_route_skipped']==2 and st['feasible_pair_deltas']==4
assert sum(t.get('delta')==-40 for t in tr)==2
short,st,tr=run('insufficient_budget_atomic',raw,mat,out,3)
assert short==out and not st['complete'] and st['commits']==0 and st['feasible_pair_deltas']==3
raw,mat,out=case([[0,0],[10,0],[-10,0],[10,0],[-10,0]],[0,1,1,1,1],[[1,3],[2,4]])
new,st,tr=run('positive_not_accepted',raw,mat,out,4)
assert st['positive_pairs']==4 and new==out and st['commits']==0
raw,mat,out=case([[0,0]]*5,[0,1,1,1,1],[[1,2],[3,4]])
new,st,tr=run('colocated_zero_equal_not_accepted',raw,mat,out,4)
assert new==out and st['zero_pairs']==4 and st['commits']==0
raw,mat,out=case([[0,0],[1,0],[0,1],[2,0],[0,2]],[0,3,1,2,2],[[1,2],[3,4]],4)
new,st,tr=run('capacity_rejected',raw,mat,out,0)
assert st['capacity_rejected']==4 and st['capacity_pair_checks']==4 and st['capacity_inequalities']==8 and st['feasible_pair_deltas']==0 and st['complete']
assert edge([0,0],[1,1])+edge([1,1],[2,2])<edge([0,0],[2,2])
raw,mat,out=case([[0,0],[1,1],[2,2],[1,1]],[0,1,1,1],[[1,2],[3]],2)
new,st,tr=run('integer_nonmetric_nint',raw,mat,out,3)
rr=solver.run_one(raw,'regret2',777,{'delta_limit':25,'iterations':1000,'per_trajectory_cpu_seconds':3,'per_trajectory_wall_seconds':10,'neutral_accept':False})
assert rr['status']=='LEGAL_COMPLETION';check(raw,rr['output'])
results.append({'case':'unmodified_strict_rr2_toy','output':rr['output'],'stop':rr['stop_reason']})
(ROOT/'reports/TOY_VALIDATION.json').write_text(json.dumps({'status':'PASS','tests':results},indent=2))
print('PASS',len(results))
