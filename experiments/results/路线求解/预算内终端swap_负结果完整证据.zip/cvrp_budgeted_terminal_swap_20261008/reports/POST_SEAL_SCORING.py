"""Reporting-only implementation of frozen primary gap metric, written after seal.
No solver execution, optimization, rerun, parameter change or feedback.
"""
import hashlib,json,time,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'source'))
from independent_check import check
summary=json.loads((ROOT/'reports/SUMMARY.json').read_text());rows=[json.loads(l) for l in (ROOT/'raw/heuristics.jsonl').read_text().splitlines()]
assert hashlib.sha256((ROOT/'raw/heuristics.jsonl').read_bytes()).hexdigest()==json.loads((ROOT/'raw/SEALED.json').read_text())['sha256']
refs={};checks={};refhash={}
for inst in sorted(set(r['instance_id'] for r in rows)):
 p=Path('/workspace/shared/official_cvrp_neutral_validation_20261008/reference')/f'{inst}.reference_solution.json'
 ref=json.loads(p.read_text());raw=json.loads((ROOT/'input'/f'{inst}.json').read_text())
 checked=check(raw,{'routes':[[0]+r+[0] for r in ref['routes']],'reported_cost':ref['total_cost']})
 refs[inst]=ref['total_cost'];checks[inst]=checked;refhash[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
 gaprows=[]
for inst in refs:
 pairs=[p for p in summary['paired_results'] if p['instance_id']==inst]
 gaprows.append({'instance_id':inst,'reference_cost':refs[inst],'reference_status':'official reported optimal; independently checked feasibility/cost, not a new proof','baseline_mean_gap_percent':sum(100*(p['baseline_cost']/refs[inst]-1) for p in pairs)/4,'treatment_mean_gap_percent':sum(100*(p['swap_cost']/refs[inst]-1) for p in pairs)/4,'paired_gap_difference_pp':sum(100*p['paired_cost_difference']/refs[inst] for p in pairs)/4})
result={'primary_equal_instance_mean_gap_difference_pp':sum(r['paired_gap_difference_pp'] for r in gaprows)/6,'baseline_equal_instance_mean_gap_percent':sum(r['baseline_mean_gap_percent'] for r in gaprows)/6,'treatment_equal_instance_mean_gap_percent':sum(r['treatment_mean_gap_percent'] for r in gaprows)/6,'instance_gap_rows':gaprows,'post_seal_reference_hashes':refhash,'reference_checks':checks,'read_after_seal_ns':time.time_ns(),'scope':'Reporting only, references first read after SEALED; metrics fixed before launch.'}
(ROOT/'reports/GAP_SCORING.json').write_text(json.dumps(result,indent=2))
metrics={}
for arm in ['baseline','terminal_swap']:
 armrows=[r for r in rows if r['arm']==arm]
 metrics[arm]={k:sum(r.get(k,0) for r in armrows) for k in ['trajectory_cpu_seconds','trajectory_wall_seconds','total_delta_deltas','unused_delta_allowance','reserved_deltas','conservative_reserve_unused']}
 metrics[arm].update({k:sum(r['rr2'][k] for r in armrows) for k in ['matrix_distances','objective_edges','deltas','iterations_started','iterations_completed','accepted_improvements','repair_failures']})
 metrics[arm]['delta_by_kind']={k:sum(r['total_delta_by_kind'].get(k,0) for r in armrows) for k in ['savings','removal','insertion','swap']}
 metrics[arm]['legacy_checker_objective_edges']=sum(sum(len(route)-1 for route in rr['baseline']['routes'])+2*sum(len(route)-1 for route in rr['output']['routes'])+sum(sum(len(route)-1 for route in e['candidate']['routes']) for e in rr['trace'] if e['candidate']) for rr in (r['rr2'] for r in armrows))
 if arm=='terminal_swap':metrics[arm]['swap']={k:sum(r['swap'].get(k,0) for r in armrows) for k in ['all_pairs','same_route_skipped','capacity_pair_checks','capacity_inequalities','capacity_rejected','feasible_pair_deltas','distance_lookups','negative_pairs','zero_pairs','positive_pairs','commits','complete','cpu_seconds','wall_seconds']}
(ROOT/'reports/MECHANISM_COSTS.json').write_text(json.dumps(metrics,indent=2))
print(json.dumps(result,indent=2))
