"""Invented data only; no real route files loaded."""
import collections, decimal, pathlib, sys, unittest
from fractions import Fraction
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'source'))
import rescore as m
class ExtraFixtures(unittest.TestCase):
 def fixture(self,routes,demands=None,K=2,cost=None):
  v={'coordinates':[(0,0),(3,0),(0,4)],'demands':demands or [0,1,1],'capacity':2}
  o={'observation_id':'invented','instance_id':'invented','panel':'small16','method':'invented','role':'algorithm','seed':None,'routes':routes,'stored_integer_cost':cost if cost is not None else (14 if len(routes)>1 else 12)}
  return m.score_observation(o,{'K_limit':K},v)
 def test_malformed_members(self):
  for r in [None,7,False,'text']:
   self.assertFalse(self.fixture([r])['valid'])
 def test_bool_and_out_of_range_nodes(self):
  for routes in [[[0,True,2,0]],[[0,1,3,0]],[[0,-1,2,0]]]: self.assertFalse(self.fixture(routes)['valid'])
 def test_duplicate_missing_and_internal_depot(self):
  for routes in [[[0,1,1,0]],[[0,1,0]],[[0,1,0,2,0]]]: self.assertFalse(self.fixture(routes)['valid'])
 def test_capacity(self): self.assertFalse(self.fixture([[0,1,2,0]],demands=[0,2,2])['valid'])
 def test_X_has_no_K_limit(self):
  routes=[[0,1,0],[0,2,0]]
  self.assertFalse(self.fixture(routes,K=1)['valid']);self.assertTrue(self.fixture(routes,K=None)['valid'])
 def test_empty_slots_preserved_in_bound_only(self):
  r=self.fixture([[0,1,2,0],[0,0]],K=1,cost=12)
  self.assertTrue(r['valid']);self.assertEqual(r['route_slots'],2);self.assertEqual(r['nonempty_routes'],1);self.assertEqual(r['edge_count'],4)
  self.assertEqual(r['route_signature'],m.signature([[0,2,1,0]]))
 def test_decimal_is_not_ranking_authority(self):
  a={'integer':Fraction(2),'lo':Fraction(11,10),'hi':Fraction(12,10),'hist':{2:Fraction(1)},'decimal':decimal.Decimal(1)}
  b={'integer':Fraction(1),'lo':Fraction(1),'hi':Fraction(1),'hist':{1:Fraction(1)},'decimal':decimal.Decimal(1)}
  self.assertEqual(m.compare(a,b)['continuous_sign'],1)
 def test_overlap_is_unresolved_not_tie(self):
  a={'integer':Fraction(1),'lo':Fraction(0),'hi':Fraction(2),'hist':{2:Fraction(1)},'decimal':decimal.Decimal(1)}
  b={**a,'hist':{3:Fraction(1)}}
  self.assertEqual(m.compare(a,b)['classification'],'continuous_unresolved')
 def test_invalid_seed_propagates_unavailable(self): self.assertIsNone(m.vector([{'valid':False}]))
 def test_integer_square_boundaries_independent(self):
  for a in [0,1,2,7,101,1000000]:
   for q in sorted({max(0,a*a-1),a*a,a*a+1,a*a+a,a*a+a+1}):
    r,_,lo,hi=m.edge(q)
    with decimal.localcontext() as c:
     c.prec=100; d=decimal.Decimal(q).sqrt(); target=int(d.to_integral_value(rounding=decimal.ROUND_HALF_UP))
    self.assertEqual(r,target);self.assertLessEqual(lo*lo,q*m.SCALE*m.SCALE);self.assertGreaterEqual(hi*hi,q*m.SCALE*m.SCALE)
if __name__=='__main__': unittest.main()
