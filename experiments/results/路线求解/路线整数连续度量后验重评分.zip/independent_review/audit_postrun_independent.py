"""Separate implementation: parse source VRP/stdout; Decimal80 HALF_UP and Decimal100 sqrt.
Does not import any production scorer or solver. Only run after RAW preservation and CPU approval.
"""
import collections, csv, decimal, hashlib, itertools, json, pathlib, re, sys
from fractions import Fraction as F
from functools import lru_cache
ROOT=pathlib.Path(__file__).resolve().parents[1]
D=decimal.Decimal; SCALE=10**70; TOL=D('1e-65')
def load(p):return json.loads((ROOT/p).read_text())
def lines(p):return [json.loads(x) for x in (ROOT/p).read_text().splitlines() if x.strip()]
def csvrows(p):return list(csv.DictReader((ROOT/'reports'/p).open()))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def assertnear(actual,expected):assert abs(D(actual)-expected)<TOL,(actual,str(expected))
def parse_original(path):
 text=path.read_text(); values={}
 for line in text.splitlines():
  if ':' in line:
   k,v=line.split(':',1); values[k.strip()]=v.strip()
 assert values['TYPE']=='CVRP' and values['EDGE_WEIGHT_TYPE']=='EUC_2D'
 sections={}
 for section,nextsection in [('NODE_COORD_SECTION','DEMAND_SECTION'),('DEMAND_SECTION','DEPOT_SECTION')]:
  body=text.split(section,1)[1].split(nextsection,1)[0]
  sections[section]=[list(map(int,line.split())) for line in body.splitlines() if line.strip()]
 coordrows=sections['NODE_COORD_SECTION'];demandrows=sections['DEMAND_SECTION'];N=int(values['DIMENSION'])
 coords={r[0]:tuple(r[1:]) for r in coordrows};demands={r[0]:r[1] for r in demandrows}
 assert len(coordrows)==len(coords)==N and len(demandrows)==len(demands)==N
 assert set(coords)==set(demands)==set(range(1,N+1))
 deptext=text.split('DEPOT_SECTION',1)[1].split('EOF',1)[0];dep=[int(t) for t in deptext.split() if int(t)!=-1]
 assert dep==[1] and demands[1]==0
 return {'coordinates':[coords[k] for k in range(1,N+1)],'demands':[demands[k] for k in range(1,N+1)],'capacity':int(values['CAPACITY'])}
@lru_cache(None)
def oracle_edge(q):
 with decimal.localcontext() as ctx:
  ctx.prec=80; rounded=int(D(q).sqrt().to_integral_value(rounding=decimal.ROUND_HALF_UP))
 with decimal.localcontext() as ctx:
  ctx.prec=100; c=D(q).sqrt();scaled=c*D(SCALE)
  low=int(scaled.to_integral_value(rounding=decimal.ROUND_FLOOR))
  high=int(scaled.to_integral_value(rounding=decimal.ROUND_CEILING))
 # These integer inequalities independently prove the Decimal-derived floor/ceiling.
 assert low*low<=q*SCALE*SCALE<=high*high and high-low<=1
 assert (low==high)==(low*low==q*SCALE*SCALE)
 assert (rounded==0 or (2*rounded-1)**2<=4*q) and 4*q<=(2*rounded+1)**2
 return rounded,c,low,high

def route_signature(routes):
 bodies=[tuple(r[1:-1]) for r in routes if r[1:-1]]
 canonical=sorted(r if r<=r[::-1] else r[::-1] for r in bodies)
 return hashlib.sha256(json.dumps(canonical,separators=(',',':')).encode()).hexdigest()
def recalc(obs,instance):
 origin=pathlib.Path(obs['source_origin']['source_absolute_path']);source=json.loads(origin.read_text())
 assert sha(origin)==obs['source_origin']['source_sha256']
 routes=source['routes'] if obs['role']=='algorithm' else [[0]+r+[0] for r in source['reference_routes']]
 assert routes==obs['routes']
 v=parse_original(ROOT/instance['input_vrp']);n=len(v['demands']);customers=[];loads=[]
 assert isinstance(routes,list)
 for route in routes:
  assert isinstance(route,list) and len(route)>=2 and route[0]==route[-1]==0
  assert all(type(x)==int and 0<=x<n for x in route) and 0 not in route[1:-1]
  customers.extend(route[1:-1]);load=sum(v['demands'][x] for x in route[1:-1]);loads.append(load)
  assert load<=v['capacity']
 assert sorted(customers)==list(range(1,n))
 nonempty=sum(bool(r[1:-1]) for r in routes)
 if instance['panel']=='small16':assert nonempty<=load_json_reference(instance)['K_ref']==instance['K_limit']
 else:assert instance['K_limit'] is None
 qs=[]
 for r in routes:
  for u,vv in zip(r[:-1],r[1:]):
   ux,uy=v['coordinates'][u];vx,vy=v['coordinates'][vv];qs.append((ux-vx)**2+(uy-vy)**2)
 edges=[oracle_edge(q) for q in qs];integer=sum(e[0] for e in edges);continuous=sum((e[1] for e in edges),D(0));lo=sum(e[2] for e in edges);hi=sum(e[3] for e in edges)
 assert integer==obs['stored_integer_cost']
 assert F(lo,SCALE)>=F(2*integer-len(qs),2) and F(hi,SCALE)<=F(2*integer+len(qs),2)
 return {'integer':F(integer),'continuous':continuous,'lo':F(lo,SCALE),'hi':F(hi,SCALE),'hist':dict(collections.Counter(q for q in qs if q)),'edge_count':len(qs),'nonempty':nonempty,'slots':len(routes),'loads':loads,'signature':route_signature(routes),'delta':D(integer)-continuous}
def load_json_reference(instance):return load(instance['reference_json'])
def mean(vectors):
 N=len(vectors);counts=collections.Counter()
 for v in vectors:counts.update(v['hist'])
 return {'integer':sum(v['integer'] for v in vectors)/N,'continuous':sum(v['continuous'] for v in vectors)/N,'lo':sum(v['lo'] for v in vectors)/N,'hi':sum(v['hi'] for v in vectors)/N,'hist':{q:F(c,N) for q,c in counts.items()}}
def compare(a,b):
 delta=a['integer']-b['integer'];low=a['lo']-b['hi'];high=a['hi']-b['lo']
 si=1 if delta>0 else -1 if delta<0 else 0
 equal=a['hist']==b['hist'];sc=0 if equal else 1 if low>0 else -1 if high<0 else None
 if sc is None:cl='continuous_unresolved'
 elif si==0:cl='both_exact_tie' if sc==0 else 'integer_tie_broken'
 elif sc==0:cl='continuous_exact_tie'
 elif si==sc:cl='same_strict_order'
 else:cl='strict_reversal'
 return {'classification':cl,'integer_sign':si,'continuous_sign':sc,'integer_left_minus_right_exact':str(delta),'continuous_difference_lower_exact':str(low),'continuous_difference_upper_exact':str(high),'continuous_equality_proof':'identical_mean_squared_length_multiset' if equal else None,'continuous':a['continuous']-b['continuous']}
def verify_compare(actual,expected):
 for k,v in expected.items():
  if k=='continuous':assertnear(actual['continuous_left_minus_right_decimal80'],v)
  else:assert actual[k]==v,(k,actual[k],v)
def normalize(v,anchor):
 assert anchor['integer']>0 and anchor['lo']>0
 return {'integer':100*(v['integer']/anchor['integer']-1),'continuous':100*(v['continuous']/anchor['continuous']-1),'lo':100*(v['lo']/anchor['hi']-1),'hi':100*(v['hi']/anchor['lo']-1)}
def count_classes(rows):return dict(sorted(collections.Counter(r['classification'] for r in rows).items()))
def main():
 assert '--postrun-authorized' in sys.argv,'Needs explicit parent-authorized postrun window'
 gate=load('provenance/RAW_UNREVIEWED_DRIVE_RECEIPT.json')
 assert all(gate[k] is True for k in ['verified','owner_only','download_byte_identical','remote_readback_sha256_verified'])
 frozen=load('freeze/FROZEN_FILES.json');assert sha(ROOT/'freeze/FROZEN_FILES.json')==gate['frozen_files_sha256']
 for rel,h in frozen['files'].items():assert sha(ROOT/rel)==h,(rel,'frozen changed')
 rawmanifest=load('raw/RAW_FILES_MANIFEST.json')
 for rel,h in rawmanifest['files'].items():assert sha(ROOT/rel)==h,(rel,'raw changed')
 assert rawmanifest['frozen_files_sha256']==sha(ROOT/'freeze/FROZEN_FILES.json')
 assert load('raw/EXECUTOR_FINISHED.json')['returncode']==0
 obs=load('snapshots/OBSERVATIONS.json');inst={i['instance_id']:i for i in load('freeze/INSTANCES.json')}
 scores=lines('raw/SCORES.jsonl');byid={r['observation_id']:r for r in scores}
 assert len(scores)==len(byid)==len(obs)==240
 assert all(r['valid'] for r in scores),'Frozen expected valid sources unexpectedly unavailable: investigate without repair or rerun'
 independent={};rowproofs=[]
 with decimal.localcontext() as ctx:
  ctx.prec=100
  for o in obs:
   r=recalc(o,inst[o['instance_id']]);independent[o['observation_id']]=r;s=byid[o['observation_id']]
   for k in ['instance_id','panel','method','role','seed']:assert s[k]==o[k]
   assert s['integer_cost']==r['integer'] and s['edge_count']==r['edge_count']
   assert s['nonempty_routes']==r['nonempty'] and s['route_slots']==r['slots'] and s['loads']==r['loads']
   assert s['route_signature']==r['signature'] and s['scale_digits']==70
   assert int(s['continuous_lo_scaled'])==r['lo']*SCALE and int(s['continuous_hi_scaled'])==r['hi']*SCALE
   assert s['squared_length_multiplicities']=={str(q):c for q,c in sorted(r['hist'].items())}
   assertnear(s['continuous_cost_decimal80'],r['continuous']);assertnear(s['integer_minus_continuous_decimal80'],r['delta']);assertnear(s['absolute_rounding_error_decimal80'],abs(r['delta']))
   assert D(s['edge_count_half_error_bound'])==D(r['edge_count'])/2
   assert F(D(s['continuous_cost_decimal80']))>=r['lo'] and F(D(s['continuous_cost_decimal80']))<=r['hi']
   assert s['error_bound_proved'] and s['stored_integer_cost_matched'] and s['all_edge_integer_crosschecks_passed']
   rowproofs.append({'observation_id':o['observation_id'],'integer_cost_decimal80_HALF_UP':int(r['integer']),'continuous_cost_decimal100':str(r['continuous']),'integer_minus_continuous_decimal100':str(r['delta']),'valid':True,'edge_count':r['edge_count'],'integer_square_enclosure_checked':True,'route_signature':r['signature']})
  groups=load('freeze/GROUPS.json');gv={g['group_id']:mean([independent[x] for x in g['observation_ids']]) for g in groups}
  primary=lines('raw/PRIMARY_COMPARISONS.jsonl');desc=lines('raw/DESCRIPTIVE_COMPARISONS.jsonl')
  assert len(primary)==160 and len(desc)==916
  for actual,p in zip(primary,load('freeze/PRIMARY_PAIRS.json')):
   assert all(actual[k]==v for k,v in p.items());verify_compare(actual,compare(gv[p['left_group_id']],gv[p['right_group_id']]))
  for actual,p in zip(desc,load('freeze/DESCRIPTIVE_PAIRS.json')):
   assert all(actual[k]==v for k,v in p.items());verify_compare(actual,compare(independent[p['left_observation_id']],independent[p['right_observation_id']]))
  summary=load('reports/SUMMARY.json');mapping=collections.defaultdict(list)
  for o in obs:mapping[(o['instance_id'],independent[o['observation_id']]['signature'])].append(o['observation_id'])
  unique={};same=0
  for p in desc:
   a=independent[p['left_observation_id']];b=independent[p['right_observation_id']];sa,sb=sorted([a['signature'],b['signature']])
   if sa==sb:same+=1;continue
   key=(p['instance_id'],sa,sb)
   if key not in unique:unique[key]={'classification':compare(a,b)['classification'],'pairs':[]}
   assert unique[key]['classification']==p['classification'];unique[key]['pairs'].append(p['pair_id'])
  expected_counts={'instances':28,'algorithm_observations':212,'anchor_observations':28,'all_observations':240,'valid_observations':240,'unique_signatures_including_anchors':len(mapping),'primary_instance_pairs':160,'descriptive_saved_solution_pairs':916,'identical_route_signature_descriptive_pairs':same,'unique_different_route_pairs':len(unique)}
  assert summary['counts']==expected_counts
  assert summary['primary_classifications']==count_classes(primary) and summary['descriptive_classifications']==count_classes(desc)
  assert summary['descriptive_by_panel']=={panel:count_classes([p for p in desc if p['panel']==panel]) for panel in ['small16','X12']}
  method_pairs=collections.defaultdict(list)
  for p in primary:method_pairs[p['left_method']+' vs '+p['right_method']].append(p)
  assert summary['primary_by_method_pair']=={k:count_classes(v) for k,v in method_pairs.items()}
  assert summary['unique_different_route_pair_classifications']==count_classes(unique.values())
  assert summary['all_error_bounds_proved'] is True
  maxid=max(independent,key=lambda oid:abs(independent[oid]['delta']))
  assert summary['max_absolute_rounding_error']['observation_id']==maxid
  sigcsv=csvrows('ROUTE_SIGNATURES.csv');assert len(sigcsv)==len(mapping)
  for r in sigcsv:
   ids=mapping[(r['instance_id'],r['route_signature'])];assert int(r['multiplicity'])==len(ids) and json.loads(r['observation_ids'])==ids
  uncsv=csvrows('UNIQUE_DIFFERENT_ROUTE_PAIRS.csv');assert len(uncsv)==len(unique)
  for r in uncsv:
   u=unique[(r['instance_id'],r['signature_a'],r['signature_b'])];assert r['classification']==u['classification'] and json.loads(r['original_pair_ids'])==u['pairs']
  # Every CSV raw/primary/descriptive row must preserve the corresponding raw value.
  for filename,rows in [('PER_SOLUTION.csv',scores),('PRIMARY_160_COMPARISONS.csv',primary),('DESCRIPTIVE_916_COMPARISONS.csv',desc)]:
   file=csvrows(filename);assert len(file)==len(rows)
   for c,r in zip(file,rows):
    for k,v in r.items():
     expected='' if v is None else json.dumps(v,ensure_ascii=False,sort_keys=True) if isinstance(v,(dict,list)) else str(v)
     assert c[k]==expected,(filename,k)
  norms={};methodcsv={r['group_id']:r for r in csvrows('PER_INSTANCE_METHODS.csv')}
  assert len(methodcsv)==92
  for g in groups:
   v=gv[g['group_id']];a=independent[g['reference_observation_id']];n=normalize(v,a);norms[g['group_id']]=n;r=methodcsv[g['group_id']]
   assert r['complete']=='True' and json.loads(r['observation_ids'])==g['observation_ids']
   assert r['mean_integer_cost_exact']==str(v['integer']);assertnear(r['mean_continuous_cost_decimal80'],v['continuous'])
   assertnear(r['integer_relative_excess_over_saved_feasible_anchor_percent'],D(n['integer'].numerator)/D(n['integer'].denominator))
   assertnear(r['continuous_relative_excess_over_same_saved_feasible_anchor_percent'],n['continuous'])
   assert F(r['continuous_anchor_relative_excess_lower_exact'])==n['lo'] and F(r['continuous_anchor_relative_excess_upper_exact'])==n['hi']
  ags={};aggregatecsv={(r['panel'],r['method']):r for r in csvrows('METHOD_AGGREGATES.csv')}
  assert len(aggregatecsv)==6 and len(summary['method_aggregates'])==6
  for panel,methods,N in [('small16',['TRS','TSR','Py0.1','Py1','Py5'],16),('X12',['Py1'],12)]:
   for method in methods:
    selected=[g for g in groups if g['panel']==panel and g['method']==method];assert len(selected)==N
    n=[norms[g['group_id']] for g in selected];v={k:sum(x[k] for x in n)/N for k in ['integer','continuous','lo','hi']};v['hist']={g['instance_id']:gv[g['group_id']]['hist'] for g in selected};ags[(panel,method)]=v
    r=aggregatecsv[(panel,method)];assert r['all_instance_aggregate_available']=='True' and int(r['complete_instances'])==N and int(r['required_instances'])==N
    assertnear(r['equal_instance_mean_integer_anchor_relative_excess_percent'],D(v['integer'].numerator)/D(v['integer'].denominator));assertnear(r['equal_instance_mean_continuous_same_anchor_relative_excess_percent'],v['continuous'])
    sr=next(r for r in summary['method_aggregates'] if (r['panel'],r['method'])==(panel,method))
    assertnear(sr['equal_instance_mean_integer_anchor_relative_excess_percent'],D(v['integer'].numerator)/D(v['integer'].denominator));assertnear(sr['equal_instance_mean_continuous_same_anchor_relative_excess_percent'],v['continuous'])
  aggcsv=csvrows('AGGREGATE_10_DESCRIPTIVE_COMPARISONS.csv');assert len(aggcsv)==10;aggexpected=[]
  for r,(a,b) in zip(aggcsv,itertools.combinations(['TRS','TSR','Py0.1','Py1','Py5'],2)):
   assert r['left_method']==a and r['right_method']==b and r['panel']=='small16';expected=compare(ags[('small16',a)],ags[('small16',b)]);aggexpected.append(expected)
   for k,v in expected.items():
    if k=='continuous':assertnear(r['continuous_left_minus_right_decimal80'],v)
    else:assert r[k]==('' if v is None else str(v)),(k,r[k],v)
  assert summary['aggregate_10_descriptive_classifications']==count_classes(aggexpected)
 old=load('freeze/OLD_FILES_BEFORE.json');changes=[p for p,h in old.items() if not pathlib.Path(p).is_file() or sha(pathlib.Path(p))!=h]
 assert len(old)==1318 and not changes
 current={str(p) for dep in load('freeze/RESTORE_DEPENDENCIES.json').values() for p in pathlib.Path(dep['source_root']).rglob('*') if p.is_file()}
 assert current==set(old),(current-set(old),set(old)-current)
 assert load('reports/OLD_FILES_UNCHANGED.json')=={'checked':1318,'changed':[],'pass':True}
 evidence={'status':'INDEPENDENT_POSTRUN_PASS','implementation':'No production imports; original VRP/stdout parsed separately; Decimal80 HALF_UP integers; Decimal100 continuous; exact integer-square validation of 70-digit sqrt enclosures','counts':expected_counts,'unique_squared_edge_lengths_checked':oracle_edge.cache_info().currsize,'primary_classifications':count_classes(primary),'descriptive_classifications':count_classes(desc),'all_160_primary_and_916_descriptive_differences_and_classes_recomputed':True,'all_10_aggregate_descriptive_comparisons_recomputed':True,'all_92_method_means_and_6_panel_method_aggregates_recomputed':True,'all_route_signatures_and_pair_multiplicities_verified':True,'old_files_checked':1318,'old_files_changed':changes,'old_directories_new_files':[],'frozen_files_and_raw_manifests_verified':True,'reviewer_source_sha256':sha(pathlib.Path(__file__))}
 (ROOT/'independent_review/POSTRUN_INDEPENDENT.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2)+'\n')
 (ROOT/'independent_review/DECIMAL100_PER_SOLUTION.json').write_text(json.dumps(rowproofs,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(evidence,ensure_ascii=False))
if __name__=='__main__':main()
