"""Structural and provenance checks only. This script never calculates distances."""
import collections, hashlib, itertools, json, pathlib, subprocess, sys, zipfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
def read(p): return json.loads((ROOT/p).read_text())
def digest(b): return hashlib.sha256(b).hexdigest()
def main():
 protocol=read('freeze/PROTOCOL.json'); obs=read('snapshots/OBSERVATIONS.json'); instances=read('freeze/INSTANCES.json')
 inventory=read('freeze/INPUT_INVENTORY.json'); dependencies=read('freeze/RESTORE_DEPENDENCIES.json')
 assert len(obs)==240 and len({o['observation_id'] for o in obs})==240
 assert len(instances)==28 and len({i['instance_id'] for i in instances})==28
 assert collections.Counter(o['role'] for o in obs)=={'algorithm':212,'reference_feasible_anchor':28}
 assert collections.Counter(i['panel'] for i in instances)=={'small16':16,'X12':12}
 byid={o['observation_id']:o for o in obs}; inst={i['instance_id']:i for i in instances}
 assert set(protocol['scope']['small16'])=={i['instance_id'] for i in instances if i['panel']=='small16'}
 assert set(protocol['scope']['X12'])=={i['instance_id'] for i in instances if i['panel']=='X12'}
 assert len(inventory)==300 and len({i['source_absolute_path'] for i in inventory})==300
 archives={}; source_rows={}; inventory_by_path={i['source_absolute_path']:i for i in inventory}
 for label,dep in dependencies.items():
  receipt=read(dep['receipt_copy']); p=pathlib.Path(receipt['source']); data=p.read_bytes()
  assert digest(data)==receipt['sha256']==dep['raw_archive_sha256']
  assert all(receipt[k] is True for k in ['verified','owner_only','download_byte_identical','remote_readback_sha256_verified'])
  archives[dep['raw_archive_drive_file_id']]=zipfile.ZipFile(p)
  rp=pathlib.Path(dep['source_root'])/'raw/results.jsonl'
  source_rows[label]={r['call_id']:r for r in map(json.loads,rp.read_text().splitlines()) if r}
 for entry in inventory:
  data=pathlib.Path(entry['source_absolute_path']).read_bytes()
  assert digest(data)==entry['source_sha256']==entry['archive_member_sha256']
  assert len(data)==entry['bytes']
  assert archives[entry['archive_drive_file_id']].read(entry['archive_member_path'])==data
 for iid,i in inst.items():
  source=pathlib.Path(dependencies[i['source_label']]['source_root'])
  for target,src in [(i['input_vrp'],source/'input'/f'{iid}.vrp'),(i['input_json'],source/'input'/f'{iid}.json'),(i['reference_json'],source/'references'/f'{iid}.json')]:
   assert (ROOT/target).read_bytes()==src.read_bytes()
   assert str(src) in inventory_by_path
  js=read(i['input_json']);ref=read(i['reference_json'])
  assert i['n_customers']==len(js['demands'])-1
  assert i['K_limit']==(ref['K_ref'] if i['panel']=='small16' else None)
 for o in obs:
  origin=o['source_origin']; p=pathlib.Path(origin['source_absolute_path']); source=json.loads(p.read_text())
  assert origin==inventory_by_path[str(p)]
  if o['role']=='algorithm':
   row=source_rows[o['source_label']][o['call_id']]
   assert row['instance_id']==o['instance_id'] and row['status']==o['source_status']
   assert row.get('seed')==o['seed']
   assert pathlib.Path(dependencies[o['source_label']]['source_root'])/row['stdout']==p
   assert source['routes']==o['routes'] and source.get('cost',source.get('reported_cost'))==o['stored_integer_cost']
   assert o['original_solve_budget_seconds']==row.get('max_runtime_seconds')
   if o['method'] in ('TRS','TSR'): assert row['arm']==o['method'] and o['seed'] is None and o['source_label']=='transfer'
   else:
    assert source['seed']==o['seed'] and source['max_runtime_seconds']==o['original_solve_budget_seconds']
    assert o['method']=={.1:'Py0.1',1.:'Py1',5.:'Py5'}[row['max_runtime_seconds']]
   # Cross-period coordinate/demand inputs must be semantically identical; no scoring.
   source_instance=pathlib.Path(dependencies[o['source_label']]['source_root'])/'input'/f"{o['instance_id']}.json"
   assert json.loads(source_instance.read_text())==read(inst[o['instance_id']]['input_json'])
  else:
   assert o['routes']==[[0]+r+[0] for r in source['reference_routes']]
   assert o['stored_integer_cost']==source['reference_integer_cost'] and o['method']=='Anchor'
 groups=read('freeze/GROUPS.json'); primary=read('freeze/PRIMARY_PAIRS.json'); desc=read('freeze/DESCRIPTIVE_PAIRS.json')
 assert len(groups)==92 and len({g['group_id'] for g in groups})==92
 expected_primary=set(); expected_desc=set(); expected_groups=set()
 methods=['TRS','TSR','Py0.1','Py1','Py5']
 for iid,i in inst.items():
  alg=[o for o in obs if o['instance_id']==iid and o['role']=='algorithm']
  assert len(alg)==(11 if i['panel']=='small16' else 3)
  selected=methods if i['panel']=='small16' else ['Py1']
  for m in selected:
   os=[o for o in alg if o['method']==m]
   assert sorted((o['seed'] for o in os),key=lambda x:-1 if x is None else x)==([None] if m in ('TRS','TSR') else [0,1,2])
   g=next(g for g in groups if g['group_id']==iid+'__'+m)
   assert g['instance_id']==iid and g['panel']==i['panel'] and g['method']==m
   assert len(g['observation_ids'])==len(os) and set(g['observation_ids'])=={o['observation_id'] for o in os}
   assert g['reference_observation_id']==f"{i['panel']}__{iid}__Anchor"
   expected_groups.add(g['group_id'])
  if i['panel']=='small16':
   expected_primary.update((iid,iid+'__'+a,iid+'__'+b) for a,b in itertools.combinations(methods,2))
  expected_desc.update((iid,tuple(sorted([a['observation_id'],b['observation_id']]))) for a,b in itertools.combinations(alg,2))
 assert set(g['group_id'] for g in groups)==expected_groups
 assert len(primary)==160 and {(p['instance_id'],p['left_group_id'],p['right_group_id']) for p in primary}==expected_primary
 assert len(desc)==916 and {(p['instance_id'],tuple(sorted([p['left_observation_id'],p['right_observation_id']]))) for p in desc}==expected_desc
 assert len({p['pair_id'] for p in primary})==160 and len({p['pair_id'] for p in desc})==916
 old=read('freeze/OLD_FILES_BEFORE.json');changed=[p for p,h in old.items() if not pathlib.Path(p).is_file() or digest(pathlib.Path(p).read_bytes())!=h]
 assert len(old)==1318 and not changed
 assert not (ROOT/'raw/STARTED.json').exists(), 'Precheck may only run before formal scoring'
 for z in archives.values(): z.close()
 evidence={'status':'STRUCTURAL_PRECHECK_PASS_NO_REAL_ROUTE_SCORING','observations':240,'algorithm_rows':212,'anchors':28,'instances':28,'groups':92,'primary_pairs':160,'descriptive_pairs':916,'small_descriptive_pairs':880,'X_descriptive_pairs':36,'source_archive_members_verified':300,'source_raw_archives_verified':4,'all_original_routes_and_seeds_preserved':True,'old_source_files_checked':len(old),'old_source_files_changed':changed,'real_metric_scores_computed':0,'source_code_sha256':{str(p.relative_to(ROOT)):digest(p.read_bytes()) for p in sorted((ROOT/'source').glob('*.py'))}}
 (ROOT/'independent_review/PRECHECK_STRUCTURAL.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(evidence,ensure_ascii=False))
if __name__=='__main__': main()
