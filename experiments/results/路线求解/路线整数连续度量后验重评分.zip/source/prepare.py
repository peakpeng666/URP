"""Read-only source extraction; never computes route distances or ranks outputs."""
import hashlib,itertools,json,pathlib,shutil,zipfile,datetime
ROOT=pathlib.Path(__file__).resolve().parents[1]
BASE=ROOT.parent
SOURCES={'transfer':'public_route_order_transfer_20261008','py1':'public_route_strong_baseline_20261009_r1','py0105':'public_route_strong_baseline_budget_20261009','x1':'public_route_larger_X_20261009'}
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(p,o):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n')
def main():
 assert not (ROOT/'freeze/INPUT_INVENTORY.json').exists(),'One-shot preparation'
 inventory=[];deps={};old={};instances={};observations=[]
 for label,name in SOURCES.items():
  src=BASE/name
  for p in sorted(src.rglob('*')):
   if p.is_file():old[str(p)]=sha(p.read_bytes())
  receipt=json.loads((src/'provenance/RAW_UNREVIEWED_DRIVE_RECEIPT.json').read_text())
  assert receipt['verified'] and receipt['owner_only'] and receipt['download_byte_identical'] and receipt['remote_readback_sha256_verified']
  zpath=pathlib.Path(receipt['source']);assert sha(zpath.read_bytes())==receipt['sha256']
  shutil.copyfile(src/'provenance/RAW_UNREVIEWED_DRIVE_RECEIPT.json',ROOT/'provenance'/f'{label}_SOURCE_RAW_RECEIPT.json')
  with zipfile.ZipFile(zpath) as z:
   names=z.namelist()
   def provenance(p):
    b=p.read_bytes();rel=str(p.relative_to(src));matches=[n for n in names if n==rel or n.endswith('/'+rel)]
    assert len(matches)==1,(rel,matches)
    member=matches[0];assert z.read(member)==b,rel
    obj={'source_absolute_path':str(p),'source_relative_path':rel,'source_sha256':sha(b),'bytes':len(b),'archive_drive_file_id':receipt.get('drive_id',receipt.get('file_id')),'archive_sha256':receipt['sha256'],'archive_member_path':member,'archive_member_sha256':sha(b),'archive_url':receipt['url'],'archived_member_byte_identical':True}
    inventory.append(obj);return obj
   meta=provenance(src/'raw/results.jsonl')
   for row in [json.loads(l) for l in (src/'raw/results.jsonl').read_text().splitlines() if l.strip()]:
    if label=='transfer' and row.get('arm') not in ('TRS','TSR'):continue
    iid=row['instance_id'];panel='X12' if label=='x1' else 'small16'
    if label=='transfer':method=row['arm']
    else:method={0.1:'Py0.1',1.0:'Py1',5.0:'Py5'}[row['max_runtime_seconds']]
    p=src/row['stdout'];origin=provenance(p);out=json.loads(p.read_text())
    oid=f'{panel}__{iid}__{method}'+('' if label=='transfer' else f"__s{row['seed']}")
    obs={'observation_id':oid,'instance_id':iid,'panel':panel,'method':method,'role':'algorithm','seed':row.get('seed'),'call_id':row['call_id'],'source_label':label,'source_origin':origin,'source_status':row['status'],'routes':out.get('routes'),'stored_integer_cost':out.get('cost',out.get('reported_cost')),'original_solve_budget_seconds':row.get('max_runtime_seconds'),'fixed_candidate_budget':out.get('budget') if label=='transfer' else None}
    observations.append(obs)
    if iid not in instances:
     jp=src/'input'/f'{iid}.json';vp=src/'input'/f'{iid}.vrp';refp=src/'references'/f'{iid}.json'
     js=json.loads(jp.read_text());ref=json.loads(refp.read_text())
     for p2 in (jp,vp,refp):
      origin2=provenance(p2);target=ROOT/'input'/p2.name
      if p2==refp:target=ROOT/'input'/f'{iid}.reference.json'
      shutil.copyfile(p2,target)
     instances[iid]={'instance_id':iid,'panel':panel,'source_label':label,'n_customers':len(js['demands'])-1,'K_limit':js['K'] if panel=='small16' else None,'input_json':f'input/{iid}.json','input_vrp':f'input/{iid}.vrp','reference_json':f'input/{iid}.reference.json'}
     observations.append({'observation_id':f'{panel}__{iid}__Anchor','instance_id':iid,'panel':panel,'method':'Anchor','role':'reference_feasible_anchor','seed':None,'call_id':None,'source_label':label,'source_origin':origin2,'source_status':'SAVED_REFERENCE','routes':[[0,*r,0] for r in ref['reference_routes']],'stored_integer_cost':ref['reference_integer_cost'],'original_solve_budget_seconds':None,'fixed_candidate_budget':None})
    else:
     # Cross-stage data equality is a required precondition, not outcome screening.
     assert json.loads((src/'input'/f'{iid}.json').read_text())==json.loads((ROOT/'input'/f'{iid}.json').read_text())
   deps[label]={'source_root':str(src),'raw_archive_drive_file_id':receipt.get('drive_id',receipt.get('file_id')),'raw_archive_sha256':receipt['sha256'],'raw_archive_url':receipt['url'],'receipt_copy':f'provenance/{label}_SOURCE_RAW_RECEIPT.json'}
 observations.sort(key=lambda o:(o['panel'],o['instance_id'],o['method'],-1 if o['seed'] is None else o['seed']))
 assert len(instances)==28 and len(observations)==240
 dump(ROOT/'snapshots/OBSERVATIONS.json',observations);dump(ROOT/'freeze/INSTANCES.json',list(instances.values()))
 dump(ROOT/'freeze/INPUT_INVENTORY.json',inventory);dump(ROOT/'freeze/RESTORE_DEPENDENCIES.json',deps);dump(ROOT/'freeze/OLD_FILES_BEFORE.json',old)
 groups=[];primary=[];rawpairs=[]
 methods=['TRS','TSR','Py0.1','Py1','Py5']
 for iid,ins in instances.items():
  alg=[o for o in observations if o['instance_id']==iid and o['role']=='algorithm']; ref=next(o['observation_id'] for o in observations if o['instance_id']==iid and o['method']=='Anchor')
  for m in methods if ins['panel']=='small16' else ['Py1']:
   ids=[o['observation_id'] for o in alg if o['method']==m];assert len(ids)==(1 if m in ('TRS','TSR') else 3)
   groups.append({'group_id':iid+'__'+m,'instance_id':iid,'panel':ins['panel'],'method':m,'observation_ids':ids,'reference_observation_id':ref,'aggregation':'arithmetic_mean_all_saved_seeds'})
  if ins['panel']=='small16':
   for a,b in itertools.combinations(methods,2):primary.append({'pair_id':iid+'__'+a+'__vs__'+b,'instance_id':iid,'panel':'small16','left_group_id':iid+'__'+a,'right_group_id':iid+'__'+b,'left_method':a,'right_method':b})
  for a,b in itertools.combinations(alg,2):rawpairs.append({'pair_id':a['observation_id']+'__vs__'+b['observation_id'],'instance_id':iid,'panel':ins['panel'],'left_observation_id':a['observation_id'],'right_observation_id':b['observation_id']})
 assert len(primary)==160 and len(rawpairs)==916 and len(groups)==92
 dump(ROOT/'freeze/GROUPS.json',groups);dump(ROOT/'freeze/PRIMARY_PAIRS.json',primary);dump(ROOT/'freeze/DESCRIPTIVE_PAIRS.json',rawpairs)
 print(json.dumps({'instances':len(instances),'observation_rows':len(observations),'algorithm_rows':212,'anchor_rows':28,'primary_pairs':len(primary),'descriptive_pairs':len(rawpairs),'source_files_preserved':len(old),'source_members_restore_mapped':len(inventory)}))
if __name__=='__main__':main()
