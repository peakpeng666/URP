"""One formal rescore with an external wall guard; seal partial raw on failure."""
import datetime,hashlib,json,os,pathlib,subprocess,sys,time,zipfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 raw=ROOT/'raw';raw.mkdir(exist_ok=True)
 with (raw/'EXECUTOR_STARTED.json').open('x') as f:f.write(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'external_wall_limit_seconds':120})+'\n')
 start=time.monotonic();status='COMPLETED';rc=None
 env={'PATH':os.environ.get('PATH','/usr/bin:/bin'),'LANG':'C.UTF-8','LC_ALL':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1'}
 with (raw/'rescore.stdout').open('xb') as out,(raw/'rescore.stderr').open('xb') as err:
  child=subprocess.Popen([sys.executable,'-B',str(ROOT/'source/rescore.py')],stdout=out,stderr=err,cwd=str(ROOT),env=env)
  try:rc=child.wait(timeout=120)
  except subprocess.TimeoutExpired:status='WALL_TIMEOUT';child.kill();rc=child.wait()
  finally:
   if child.poll() is None:child.kill();child.wait()
 write(raw/'EXECUTOR_FINISHED.json',{'returncode':rc,'status':status if rc==0 else status+'_NONZERO','wall_seconds':time.monotonic()-start,'child_reaped':child.poll() is not None})
 files={str(p.relative_to(ROOT)):sha(p) for p in sorted(raw.rglob('*')) if p.is_file() and p.name!='RAW_FILES_MANIFEST.json'}
 write(raw/'RAW_FILES_MANIFEST.json',{'status':'UNREVIEWED','files':files,'frozen_files_sha256':sha(ROOT/'freeze/FROZEN_FILES.json')})
 target=ROOT.parent/(ROOT.name+'_RAW_UNREVIEWED.zip')
 with zipfile.ZipFile(target,'x',zipfile.ZIP_DEFLATED) as z:
  for p in sorted(raw.rglob('*')):
   if p.is_file():z.write(p,str(p.relative_to(ROOT)))
  for rel in ['freeze/FROZEN_FILES.json','freeze/PROTOCOL.json','provenance/PREEXEC_DRIVE_RECEIPT.json','provenance/CPU_WINDOW.json']:
   p=ROOT/rel
   if p.exists():z.write(p,rel)
 print(json.dumps({'raw_archive':str(target),'bytes':target.stat().st_size,'sha256':sha(target),'returncode':rc,'outcome_interpretation':'not_performed'}))
if __name__=='__main__':main()
