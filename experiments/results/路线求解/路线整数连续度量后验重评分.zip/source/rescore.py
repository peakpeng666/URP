"""Same saved solutions only: no solver imports, route edits, or optimization."""
import collections,datetime,decimal,hashlib,itertools,json,math,pathlib,resource,time
from fractions import Fraction
from functools import lru_cache
D=decimal.Decimal
ROOT=pathlib.Path(__file__).resolve().parents[1]
SCALE=10**70
CTX=decimal.Context(prec=80,rounding=decimal.ROUND_HALF_EVEN)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads((ROOT/p).read_text())
def dump(p,obj): (ROOT/p).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def decfrac(x):
 with decimal.localcontext(CTX):return str(D(x.numerator)/D(x.denominator))
def signature(routes):
 normalized=sorted(min(tuple(r[1:-1]),tuple(reversed(r[1:-1]))) for r in routes if len(r)>2)
 return sha(json.dumps(normalized,separators=(',',':')).encode())
def parse_vrp(path):
 header={};coords={};demands={};depots=[];section=None
 for line in path.read_text().splitlines():
  s=line.strip()
  if not s:continue
  if s in ('NODE_COORD_SECTION','DEMAND_SECTION','DEPOT_SECTION'):section=s;continue
  if s=='EOF':break
  if section=='NODE_COORD_SECTION':
   k,x,y=s.split();coords[int(k)]=(D(x),D(y))
  elif section=='DEMAND_SECTION':
   k,q=s.split();demands[int(k)]=int(q)
  elif section=='DEPOT_SECTION':
   v=int(s)
   if v!=-1:depots.append(v)
  elif ':' in s:
   k,v=s.split(':',1);header[k.strip()]=v.strip()
 assert header['EDGE_WEIGHT_TYPE']=='EUC_2D' and depots==[1]
 n=int(header['DIMENSION']);assert sorted(coords)==list(range(1,n+1)) and sorted(demands)==list(range(1,n+1))
 xy=[]
 for i in range(1,n+1):
  assert all(c==c.to_integral_value() for c in coords[i]),'This frozen scorer requires exact integer coordinates'
  xy.append(tuple(int(c) for c in coords[i]))
 return {'coordinates':xy,'demands':[demands[i] for i in range(1,n+1)],'capacity':int(header['CAPACITY'])}
@lru_cache(None)
def edge(q):
 assert isinstance(q,int) and q>=0
 a=math.isqrt(q);rounded=a+int(4*q>=(2*a+1)**2)
 t=math.isqrt(q*SCALE*SCALE);hi=t+int(t*t!=q*SCALE*SCALE)
 with decimal.localcontext(CTX):
  continuous=D(q).sqrt();independent_round=int(continuous.quantize(D(1),rounding=decimal.ROUND_HALF_UP))
 assert rounded==independent_round
 assert (rounded==0 or 4*q >= (2*rounded-1)**2) and 4*q <= (2*rounded+1)**2
 return rounded,continuous,t,hi

def score_observation(obs,inst,vrp):
 rts=obs.get('routes');errors=[];seen=[];loads=[]
 if not isinstance(rts,list):return {'observation_id':obs['observation_id'],'valid':False,'errors':['routes_not_list']}
 n=len(vrp['demands']);K=inst['K_limit']
 for r in rts:
  if not isinstance(r,list) or len(r)<2 or r[0]!=0 or r[-1]!=0:errors.append('route_not_closed');continue
  if any(type(v)!=int or not 0<=v<n for v in r):errors.append('node_type_or_range');continue
  if any(v==0 for v in r[1:-1]):errors.append('interior_depot')
  seen.extend(r[1:-1]);loads.append(sum(vrp['demands'][v] for v in r[1:-1]))
 if sorted(seen)!=list(range(1,n)):errors.append('coverage')
 if any(q>vrp['capacity'] for q in loads):errors.append('capacity')
 nonempty=sum(isinstance(r,list) and len(r)>2 for r in rts)
 if K is not None and nonempty>K:errors.append('at_most_K')
 if errors:return {'observation_id':obs['observation_id'],'valid':False,'errors':errors}
 total=0;lo=0;hi=0;continuous=D(0);hist=collections.Counter();ec=0
 with decimal.localcontext(CTX):
  for r in rts:
   for i,j in zip(r,r[1:]):
    xi,yi=vrp['coordinates'][i];xj,yj=vrp['coordinates'][j];q=(xi-xj)**2+(yi-yj)**2
    rounded,c,l,h=edge(q);total+=rounded;continuous+=c;lo+=l;hi+=h;ec+=1
    if q:hist[q]+=1
  err=D(total)-continuous;bound=D(ec)/2
  # Prove aggregate error by rational interval, independently of Decimal presentation.
  assert Fraction(lo,SCALE)>=Fraction(2*total-ec,2) and Fraction(hi,SCALE)<=Fraction(2*total+ec,2)
  if total!=obs['stored_integer_cost']:
   return {'observation_id':obs['observation_id'],'valid':False,'errors':['stored_integer_cost_mismatch'],'recomputed_integer_cost':total,'stored_integer_cost':obs['stored_integer_cost']}
  return {'observation_id':obs['observation_id'],'instance_id':obs['instance_id'],'panel':obs['panel'],'method':obs['method'],'role':obs['role'],'seed':obs['seed'],'valid':True,'errors':[],
   'integer_cost':total,'continuous_cost_decimal80':str(continuous),'continuous_lo_scaled':str(lo),'continuous_hi_scaled':str(hi),'scale_digits':70,'integer_minus_continuous_decimal80':str(err),'absolute_rounding_error_decimal80':str(abs(err)),'edge_count':ec,'nonempty_routes':nonempty,'route_slots':len(rts),'edge_count_half_error_bound':str(bound),'error_bound_proved':True,'route_signature':signature(rts),'squared_length_multiplicities':{str(k):v for k,v in sorted(hist.items())},'loads':loads,'stored_integer_cost_matched':True,'all_edge_integer_crosschecks_passed':True}

def vector(rows):
 if not rows or any(not r['valid'] for r in rows):return None
 n=len(rows);hist=collections.Counter()
 for r in rows:hist.update({int(k):v for k,v in r['squared_length_multiplicities'].items()})
 return {'integer':Fraction(sum(r['integer_cost'] for r in rows),n),'lo':Fraction(sum(int(r['continuous_lo_scaled']) for r in rows),n*SCALE),'hi':Fraction(sum(int(r['continuous_hi_scaled']) for r in rows),n*SCALE),'hist':{k:Fraction(v,n) for k,v in hist.items()},'decimal':sum((D(r['continuous_cost_decimal80']) for r in rows),D(0))/D(n)}
def sign(x):return (x>0)-(x<0)
def compare(a,b):
 if a is None or b is None:return {'classification':'unavailable','integer_sign':None,'continuous_sign':None}
 di=a['integer']-b['integer'];dl=a['lo']-b['hi'];dh=a['hi']-b['lo'];si=sign(di)
 equal=a['hist']==b['hist']
 sc=0 if equal else (1 if dl>0 else (-1 if dh<0 else None))
 if sc is None:typ='continuous_unresolved'
 elif si*sc==-1:typ='strict_reversal'
 elif si==0 and sc!=0:typ='integer_tie_broken'
 elif si!=0 and sc==0:typ='continuous_exact_tie'
 elif si==0 and sc==0:typ='both_exact_tie'
 else:typ='same_strict_order'
 return {'classification':typ,'integer_sign':si,'continuous_sign':sc,'integer_left_minus_right_exact':str(di),'continuous_left_minus_right_decimal80':str(a['decimal']-b['decimal']),'continuous_difference_lower_exact':str(dl),'continuous_difference_upper_exact':str(dh),'continuous_equality_proof':'identical_mean_squared_length_multiset' if equal else None}
def verify_gate(name):
 g=load('provenance/'+name)
 for k in ('verified','owner_only','download_byte_identical','remote_readback_sha256_verified'):assert g.get(k) is True,(name,k)
 assert g['frozen_files_sha256']==sha((ROOT/'freeze/FROZEN_FILES.json').read_bytes())
 return g

def main():
 resource.setrlimit(resource.RLIMIT_CPU,(30,30));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
 verify_gate('PREEXEC_DRIVE_RECEIPT.json');window=load('provenance/CPU_WINDOW.json');assert window['approved'] is True
 frozen=load('freeze/FROZEN_FILES.json')
 for rel,h in frozen['files'].items():assert sha((ROOT/rel).read_bytes())==h,rel
 (ROOT/'raw/STARTED.json').open('x').write(json.dumps({'at':now(),'cpu_window':window,'frozen_sha256':sha((ROOT/'freeze/FROZEN_FILES.json').read_bytes())})+'\n')
 start=time.monotonic();cpu=time.process_time();obs=load('snapshots/OBSERVATIONS.json');instances={i['instance_id']:i for i in load('freeze/INSTANCES.json')};vs={}
 for iid,inst in instances.items():
  v=parse_vrp(ROOT/inst['input_vrp']);j=load(inst['input_json'])
  assert v['coordinates']==[tuple(x) for x in j['coordinates']] and v['demands']==j['demands'] and v['capacity']==j['capacity']
  vs[iid]=v
 scores={}
 with (ROOT/'raw/SCORES.jsonl').open('x') as f:
  for o in obs:
   r=score_observation(o,instances[o['instance_id']],vs[o['instance_id']]);scores[o['observation_id']]=r;f.write(json.dumps(r,ensure_ascii=False)+'\n');f.flush()
 with decimal.localcontext(CTX):
  groups={g['group_id']:vector([scores[x] for x in g['observation_ids']]) for g in load('freeze/GROUPS.json')}
  with (ROOT/'raw/PRIMARY_COMPARISONS.jsonl').open('x') as f:
   for p in load('freeze/PRIMARY_PAIRS.json'):f.write(json.dumps({**p,**compare(groups[p['left_group_id']],groups[p['right_group_id']])})+'\n')
  with (ROOT/'raw/DESCRIPTIVE_COMPARISONS.jsonl').open('x') as f:
   for p in load('freeze/DESCRIPTIVE_PAIRS.json'):f.write(json.dumps({**p,**compare(vector([scores[p['left_observation_id']]]),vector([scores[p['right_observation_id']]]))})+'\n')
 dump('raw/FINISHED.json',{'at':now(),'status':'RAW_RESCORE_COMPLETE_UNREVIEWED','score_rows':len(scores),'primary_pairs':160,'descriptive_pairs':916,'cpu_seconds':time.process_time()-cpu,'wall_seconds':time.monotonic()-start,'maxrss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'solver_calls':0,'model_calls':0})
 print('Raw rescore completed; archive before reporting outcomes.')
if __name__=='__main__':main()
