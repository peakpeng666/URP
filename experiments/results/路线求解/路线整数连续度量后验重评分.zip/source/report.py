"""Interpret already preserved raw scores, after RAW Drive byte readback only."""
import collections,csv,decimal,hashlib,itertools,json,pathlib
from fractions import Fraction
from rescore import ROOT,D,CTX,load,dump,vector,compare,decfrac,signature,verify_gate

def lines(p):return [json.loads(l) for l in (ROOT/p).read_text().splitlines() if l.strip()]
def csvout(name,rows):
 if not rows:return
 keys=list(dict.fromkeys(k for r in rows for k in r))
 with (ROOT/'reports'/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=keys);w.writeheader()
  for r in rows:w.writerow({k:json.dumps(v,ensure_ascii=False,sort_keys=True) if isinstance(v,(dict,list)) else v for k,v in r.items()})
def counter(rows):return dict(sorted(collections.Counter(r['classification'] for r in rows).items()))
def count_zh(counts):
 names={'strict_reversal':'严格方向翻转','integer_tie_broken':'整数并列被连续打破','continuous_exact_tie':'连续精确并列','both_exact_tie':'双口径精确并列','same_strict_order':'严格次序不变','continuous_unresolved':'连续数值未决','unavailable':'不可用'}
 return '，'.join(names[k]+str(v)+'对' for k,v in counts.items())
def display_percent(v):return '不可用' if v is None else format(D(v),'.6f')
def norm(v,a):
 if v is None or a is None:return None
 return {'integer':100*(v['integer']/a['integer']-1),'lo':100*(v['lo']/a['hi']-1),'hi':100*(v['hi']/a['lo']-1),'decimal':100*(v['decimal']/a['decimal']-1)}
def main():
 verify_gate('RAW_UNREVIEWED_DRIVE_RECEIPT.json')
 for rel,h in load('raw/RAW_FILES_MANIFEST.json')['files'].items():
  assert hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()==h,rel
 scores=lines('raw/SCORES.jsonl');byid={r['observation_id']:r for r in scores};groups=load('freeze/GROUPS.json');primary=lines('raw/PRIMARY_COMPARISONS.jsonl');desc=lines('raw/DESCRIPTIVE_COMPARISONS.jsonl');obs=load('snapshots/OBSERVATIONS.json')
 assert len(scores)==240 and len(primary)==160 and len(desc)==916
 mapping=collections.defaultdict(list)
 for r in scores:
  if r['valid']:mapping[(r['instance_id'],r['route_signature'])].append(r['observation_id'])
 signature_rows=[{'instance_id':k[0],'route_signature':k[1],'multiplicity':len(v),'observation_ids':v} for k,v in sorted(mapping.items())]
 for r in scores:
  if r['valid']:r['signature_multiplicity_including_anchor']=len(mapping[(r['instance_id'],r['route_signature'])])
 csvout('PER_SOLUTION.csv',scores);csvout('ROUTE_SIGNATURES.csv',signature_rows)
 csvout('PRIMARY_160_COMPARISONS.csv',primary);csvout('DESCRIPTIVE_916_COMPARISONS.csv',desc)
 unique={};same=0
 for p in desc:
  a=byid[p['left_observation_id']];b=byid[p['right_observation_id']]
  if not a['valid'] or not b['valid']:continue
  sigs=sorted([a['route_signature'],b['route_signature']])
  if sigs[0]==sigs[1]:same+=1;continue
  key=(p['instance_id'],*sigs)
  if key not in unique:unique[key]={'instance_id':key[0],'signature_a':key[1],'signature_b':key[2],'classification':p['classification'],'original_pair_ids':[]}
  assert unique[key]['classification']==p['classification']
  unique[key]['original_pair_ids'].append(p['pair_id'])
 csvout('UNIQUE_DIFFERENT_ROUTE_PAIRS.csv',list(unique.values()))
 group_rows=[];group_values={};normalizations={}
 with decimal.localcontext(CTX):
  for g in groups:
   v=vector([byid[x] for x in g['observation_ids']]);a=vector([byid[g['reference_observation_id']]]);group_values[g['group_id']]=v;n=norm(v,a);normalizations[g['group_id']]=n
   rr={**g,'complete':v is not None}
   if n:rr.update({'mean_integer_cost_exact':str(v['integer']),'mean_continuous_cost_decimal80':str(v['decimal']),'integer_relative_excess_over_saved_feasible_anchor_percent':decfrac(n['integer']),'continuous_relative_excess_over_same_saved_feasible_anchor_percent':str(n['decimal']),'continuous_anchor_relative_excess_lower_exact':str(n['lo']),'continuous_anchor_relative_excess_upper_exact':str(n['hi'])})
   group_rows.append(rr)
  csvout('PER_INSTANCE_METHODS.csv',group_rows)
  aggregates=[];agvals={}
  for panel,methods,N in [('small16',['TRS','TSR','Py0.1','Py1','Py5'],16),('X12',['Py1'],12)]:
   for method in methods:
    gs=[g for g in groups if g['panel']==panel and g['method']==method];ns=[normalizations[g['group_id']] for g in gs];available=[n for n in ns if n is not None]
    rr={'panel':panel,'method':method,'required_instances':N,'complete_instances':len(available),'all_instance_aggregate_available':len(available)==N}
    if len(available)==N:
     v={k:sum(n[k] for n in ns)/N for k in ['integer','lo','hi','decimal']};v['hist']={g['instance_id']:group_values[g['group_id']]['hist'] for g in gs};agvals[(panel,method)]=v
     rr.update({'equal_instance_mean_integer_anchor_relative_excess_percent':decfrac(v['integer']),'equal_instance_mean_continuous_same_anchor_relative_excess_percent':str(v['decimal'])})
    aggregates.append(rr)
  agg_pairs=[]
  for a,b in itertools.combinations(['TRS','TSR','Py0.1','Py1','Py5'],2):agg_pairs.append({'panel':'small16','left_method':a,'right_method':b,**compare(agvals.get(('small16',a)),agvals.get(('small16',b)))})
  csvout('AGGREGATE_10_DESCRIPTIVE_COMPARISONS.csv',agg_pairs);csvout('METHOD_AGGREGATES.csv',aggregates)
 counts_by_method={}
 for p in primary:
  key=p['left_method']+' vs '+p['right_method'];counts_by_method.setdefault(key,[]).append(p)
 valid=[r for r in scores if r['valid']];summary={'status':'POSTHOC_SAVED_SOLUTION_METRIC_SENSITIVITY_NOT_RESOLVE','counts':{'instances':28,'algorithm_observations':212,'anchor_observations':28,'all_observations':240,'valid_observations':len(valid),'unique_signatures_including_anchors':len(mapping),'primary_instance_pairs':160,'descriptive_saved_solution_pairs':916,'identical_route_signature_descriptive_pairs':same,'unique_different_route_pairs':len(unique)},'primary_classifications':counter(primary),'primary_by_method_pair':{k:counter(v) for k,v in counts_by_method.items()},'descriptive_classifications':counter(desc),'descriptive_by_panel':{panel:counter([r for r in desc if r['panel']==panel]) for panel in ['small16','X12']},'unique_different_route_pair_classifications':counter(unique.values()),'aggregate_10_descriptive_classifications':counter(agg_pairs),'method_aggregates':aggregates,'max_absolute_rounding_error':max(valid,key=lambda r:D(r['absolute_rounding_error_decimal80'])) if valid else None,'all_error_bounds_proved':all(r.get('error_bound_proved') for r in valid),'limitations':['This is posthoc rescaling of the exact same saved feasible solutions, not optimization under continuous distances.','The official benchmark objective is integer EUC_2D. The continuous reference is only the cost of the same saved feasible anchor, not continuous BKS, an official gap, or an optimality certificate.','Small16 uses at most K_ref routes; X12 has no fixed fleet limit. Panels are not pooled for method ranking.','Time budgets refer to past stopping-callback budgets, not equal end-to-end compute. The 1-second small runs are historical cross-period results.','All seeds are preserved; repeated signatures and pair multiplicities are not independent evidence. No statistical significance or population generalization.','Coordinates have no established physical unit here. No meter interpretation.','Continuous strict order requires disjoint exact rational sqrt enclosures; overlapping intervals are unresolved unless equality is proved by identical weighted squared-length multisets.']}
 dump('reports/SUMMARY.json',summary)
 old=load('freeze/OLD_FILES_BEFORE.json');changed=[p for p,h in old.items() if not pathlib.Path(p).is_file() or hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()!=h];dump('reports/OLD_FILES_UNCHANGED.json',{'checked':len(old),'changed':changed,'pass':not changed})
 assert not changed
 c=summary['counts'];out=['保存路线的距离取整敏感性审计（待独立后审）','',f"范围：28个实例，240条保存解（212算法输出、28原参考可行锚点）；全部{len(valid)}条通过覆盖、容量与原车队约束校验。",'只重新计分，不生成路线、不调用求解器。小16为TRS、TSR和PyVRP三个预算组；大X12仅已有PyVRP1秒组。','',f"主检验：小16全部160个方法均值配对，分类：{count_zh(summary['primary_classifications'])}。",f"描述性：全部916个保存解对，分类：{count_zh(summary['descriptive_classifications'])}。",f"去除同签名的解对并合并重复对后，{len(unique)}个不同路线签名对，分类：{count_zh(summary['unique_different_route_pair_classifications'])}。",f"240条观察对应{len(mapping)}个不同路线签名；同签名的描述性配对{same}对。保留每个seed，重复输出不能当独立证据。",'', '方法均值：每题PyVRP用完整三个seed算术均值；全组聚合对实例等权，整数用精确有理数，连续用Decimal80展示和精确有理sqrt区间定方向。']
 for a in aggregates:out.append(f"{a['panel']} {a['method']}：整数相对保存锚点的平均超额{display_percent(a.get('equal_instance_mean_integer_anchor_relative_excess_percent'))}%；连续相对同一锚点{display_percent(a.get('equal_instance_mean_continuous_same_anchor_relative_excess_percent'))}%。")
 out+=['','误差证明：对任意边d≥0，round_half_up(d)=floor(d+1/2)，故|round_half_up(d)−d|≤1/2。对一条含m条闭合仓库边的保存解，三角不等式给出|整数成本−连续成本|≤m/2；所有保存解逐边、逐解检查成立。','百分比在本文展示到6位小数，完整80位展示值与用于判断的精确区间保存在详表；判断从不使用展示舍入值。','无物理单位转换。整数成本与原保存报告逐条核对；连续锚点不是官方连续gap/BKS或最优性证明。','TRS/TSR的最初共享构建使用连续欧氏不改变正式保存解搜索/评价采用整数EUC_2D的事实。此次改变的是同一保存路线的后验计分，不代表对连续目标重求解的性能。','原文件全部哈希核对未变。详表给出每条解的整数−连续差、界、签名、全部160/916比较及保守未决标记。']
 (ROOT/'reports/REPORT_ZH.txt').write_text('\n'.join(out)+'\n')
 print('Report written from archived raw; independent review still required.')
if __name__=='__main__':main()
