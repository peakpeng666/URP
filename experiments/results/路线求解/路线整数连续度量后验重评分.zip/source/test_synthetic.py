import collections,decimal,json,math,unittest
from rescore import edge,signature,score_observation,vector,compare,SCALE,D,CTX

def fake(qs):
 with decimal.localcontext(CTX):
  vals=[edge(q) for q in qs]
  return {'valid':True,'integer_cost':sum(x[0] for x in vals),'continuous_cost_decimal80':str(sum((x[1] for x in vals),D(0))),'continuous_lo_scaled':str(sum(x[2] for x in vals)),'continuous_hi_scaled':str(sum(x[3] for x in vals)),'squared_length_multiplicities':{str(k):v for k,v in collections.Counter(qs).items()}}
class Tests(unittest.TestCase):
 def test_edge_exact(self):
  for q in range(1001):
   r,c,l,h=edge(q);self.assertEqual(r,int(D(q).sqrt().quantize(D(1),rounding=decimal.ROUND_HALF_UP)));self.assertLessEqual(l*l,q*SCALE*SCALE);self.assertGreaterEqual(h*h,q*SCALE*SCALE)
 def test_signature(self):
  a=[[0,1,2,0],[0,3,0],[0,0]];b=[[0,3,0],[0,2,1,0]];self.assertEqual(signature(a),signature(b));self.assertNotEqual(signature(a),signature([[0,1,3,0],[0,2,0]]))
 def test_reversal(self):
  with decimal.localcontext(CTX):self.assertEqual(compare(vector([fake([2,2,2])]),vector([fake([13])]))['classification'],'strict_reversal')
 def test_integer_tie(self):
  with decimal.localcontext(CTX):self.assertEqual(compare(vector([fake([2,2])]),vector([fake([5])]))['classification'],'integer_tie_broken')
 def test_equal(self):
  with decimal.localcontext(CTX):self.assertEqual(compare(vector([fake([2,5])]),vector([fake([5,2])]))['classification'],'both_exact_tie')
 def test_unresolved(self):
  # Exact equality sqrt(8)=2sqrt(2) is deliberately not symbolically simplified.
  with decimal.localcontext(CTX):self.assertEqual(compare(vector([fake([8])]),vector([fake([2,2])]))['classification'],'continuous_unresolved')
 def test_mean_three(self):
  with decimal.localcontext(CTX):v=vector([fake([1]),fake([1]),fake([4])]);self.assertEqual(str(v['integer']),'4/3')
 def test_feasibility(self):
  v={'coordinates':[(0,0),(3,0),(0,4)],'demands':[0,1,1],'capacity':2};i={'K_limit':1};o={'observation_id':'synthetic','instance_id':'fixture','panel':'small16','method':'fixture','role':'algorithm','seed':None,'routes':[[0,1,2,0]],'stored_integer_cost':12}
  self.assertTrue(score_observation(o,i,v)['valid']);self.assertFalse(score_observation({**o,'routes':[[0,1,0]]},i,v)['valid']);self.assertFalse(score_observation({**o,'routes':[[0,1,0],[0,2,0]]},i,v)['valid'])
 def test_malformed_route_retained(self):
  v={'coordinates':[(0,0),(3,0)],'demands':[0,1],'capacity':2};i={'K_limit':1};o={'observation_id':'malformed','routes':[None,7]}
  r=score_observation(o,i,v);self.assertFalse(r['valid']);self.assertIn('route_not_closed',r['errors'])
 def test_stored_cost_mismatch_retained(self):
  v={'coordinates':[(0,0),(3,0)],'demands':[0,1],'capacity':2};i={'K_limit':1};o={'observation_id':'mismatch','routes':[[0,1,0]],'stored_integer_cost':7}
  r=score_observation(o,i,v);self.assertFalse(r['valid']);self.assertIn('stored_integer_cost_mismatch',r['errors'])
 def test_unavailable(self):self.assertEqual(compare(None,None)['classification'],'unavailable')
if __name__=='__main__':unittest.main()
