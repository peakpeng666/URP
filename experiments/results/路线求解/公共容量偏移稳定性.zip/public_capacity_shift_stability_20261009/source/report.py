"""Reference-free scoring, only after raw private archive readback. No solver imports."""
import csv,datetime,hashlib,json,pathlib
from collections import Counter
from decimal import Decimal,localcontext,ROUND_HALF_UP
from fractions import Fraction
from check_saved import validate
R=pathlib.Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(rel):return json.loads((R/rel).read_text())
def write(rel,x):
 with (R/rel).open('x') as f:json.dump(x,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
def matrix(coords):
 with localcontext() as c:
  c.prec=80
  return [[int(sum((Decimal(str(x))-Decimal(str(y)))**2 for x,y in zip(a,b)).sqrt().quantize(Decimal(1),rounding=ROUND_HALF_UP)) for b in coords] for a in coords]
def fraction(x):return {'value':float(x),'exact':str(x)}
def summary(pairs):
 assert len(pairs)==16
 valid=[x for x in pairs if x['TRS_cost'] is not None and x['TSR_cost'] is not None]
 relative=[Fraction(100*(x['TSR_cost']-x['TRS_cost']),x['TRS_cost']) for x in valid]
 absolute=[x['TSR_cost']-x['TRS_cost'] for x in valid]
 return {'denominator':16,'valid_pairs':len(valid),'proven_infeasible_tasks':sum(x['proven_infeasible'] for x in pairs),'outcomes':dict(Counter(x['outcome'] for x in pairs)),'all16_mean_TSR_minus_TRS_cost':float(Fraction(sum(absolute),16)) if len(valid)==16 else None,'all16_mean_relative_percent':fraction(sum(relative,Fraction())/16) if len(valid)==16 else None,'available_pair_mean_cost':float(Fraction(sum(absolute),len(valid))) if valid else None,'available_pair_mean_relative_percent':fraction(sum(relative,Fraction())/len(valid)) if valid else None,'available_pair_denominator':len(valid)}
def gates():
 receipt=read('provenance/RAW_UNREVIEWED_DRIVE_RECEIPT.json')
 assert receipt['owner_only'] and receipt['remote_readback_sha256_verified'] and receipt['download_byte_identical'] and not receipt['shared']
 assert receipt['sha256']==receipt['download_sha256']==sha(pathlib.Path(receipt['download_path']))==sha(R.parent/(R.name+'_RAW_UNREVIEWED.zip'))
 sealed=read('raw/SEALED_RAW_MANIFEST.json');assert all(sha(R/p)==v['sha256'] for p,v in sealed['files'].items())
 frozen=read('freeze/FROZEN_FILES.json');assert all(sha(R/p)==v['sha256'] for p,v in frozen['files'].items())
 assert (R/'raw/FINISHED.json').exists()
def main():
 gates();tasks=read('freeze/TASKS.json');history=read('freeze/HISTORICAL_BASELINE.json')
 results=[json.loads(x) for x in (R/'raw/results.jsonl').read_text().splitlines()];schedule=read('freeze/SCHEDULE.json')
 assert len(results)==len(schedule)==96
 assert all(all(r[k]==v for k,v in s.items()) for r,s in zip(results,schedule))
 records={(r['instance_id'],r['kind'],r['arm']):r for r in results};hist={(h['instance_id'],r['arm']):r for h in history for r in h['source_records']}
 endpoints=[];pairs=[];trajectories=[]
 for factor in ('0.8','1.0','1.2'):
  for h in history:
   name=h['instance_id'];slot=h['selection_slot']
   if factor=='1.0':
    data=read(f'historical/input/{name}.json');proven=False;init_status='HISTORICAL_VERIFIED_SUCCESS';task=None
   else:
    task=next(t for t in tasks if t['base_instance_id']==name and t['factor']==factor);data=read(f"input/{task['instance_id']}.json");proven=task['proven_infeasible'];init_status=records[(task['instance_id'],'initialize','capacity_solver')]['status']
   costs={};mat=matrix(data['coordinates'])
   for arm in ('TRS','TSR'):
    rec=hist[(name,arm)] if factor=='1.0' else records[(task['instance_id'],'search',arm)]
    prefix='historical/' if factor=='1.0' else ''
    row={'base_instance_id':name,'selection_slot':slot,'factor':factor,'capacity':data['capacity'],'K_slots':data['K'],'proven_infeasible':proven,'initialization_status':init_status,'arm':arm,'status':rec['status'],'new_process_spawned':False if factor=='1.0' else rec['process_spawned'],'source_stdout':prefix+rec['stdout'],'cost':None,'nonempty_routes':None,'attempted':None,'feasible':None,'capacity_rejected':None,'accepted':None,'termination':None}
    saved=None
    if rec['status']=='SUCCESS':
     saved=read(prefix+rec['stdout']);check=validate(saved['routes'],data['demands'],data['capacity'],data['K'],mat)
     assert check['cost']==saved['cost'] and saved['attempted']<=20000 and saved['arm']==arm
     row.update(cost=check['cost'],nonempty_routes=check['nonempty_routes'],attempted=saved['attempted'],feasible=saved['feasible'],capacity_rejected=saved['attempted']-saved['feasible'],accepted=saved['accepted'],termination=saved['termination'])
    costs[arm]=row['cost'];endpoints.append(row)
    for budget in (0,100,1000,5000,10000,20000):
     cost=None;carried=False
     if saved is not None:
      if budget<=saved['attempted'] or saved['termination']=='LOCAL_OPTIMUM':
       cost=saved['initial_cost']
       for move in saved['accepted_moves']:
        if move['attempted']<=budget:cost=move['cost']
       carried=budget>saved['attempted']
     trajectories.append({'base_instance_id':name,'factor':factor,'arm':arm,'budget_node':budget,'cost':cost,'carried_after_LOCAL_OPTIMUM':carried,'actual_attempted':row['attempted'],'status':row['status']})
   valid=all(costs[a] is not None for a in costs);delta=costs['TSR']-costs['TRS'] if valid else None
   pairs.append({'base_instance_id':name,'selection_slot':slot,'factor':factor,'capacity':data['capacity'],'K':data['K'],'proven_infeasible':proven,'TRS_cost':costs['TRS'],'TSR_cost':costs['TSR'],'TSR_minus_TRS_cost':delta,'relative_percent_TRS_denominator':float(Fraction(100*delta,costs['TRS'])) if valid else None,'outcome':('improved' if delta<0 else 'worse' if delta>0 else 'equal') if valid else ('PROVEN_INFEASIBLE' if proven else 'UNDETERMINED_NO_VALID_PAIR')})
 factors={f:summary([p for p in pairs if p['factor']==f]) for f in ('0.8','1.0','1.2')}
 for f,s in factors.items():
  rows=[x for x in endpoints if x['factor']==f]
  s['arm_success']={a:{'valid_routes':sum(x['status']=='SUCCESS' for x in rows if x['arm']==a),'all_task_denominator':16,'not_proven_infeasible_denominator':16-s['proven_infeasible_tasks']} for a in ('TRS','TSR')}
  s['search_statuses']=dict(Counter(x['status'] for x in rows));s['initialization_statuses']=dict(Counter(x['initialization_status'] for x in rows if x['arm']=='TRS'))
 transitions=[]
 for p in pairs:
  if p['factor']=='1.0':continue
  h=next(x for x in pairs if x['factor']=='1.0' and x['base_instance_id']==p['base_instance_id'])
  transitions.append({'base_instance_id':p['base_instance_id'],'factor':p['factor'],'historical_outcome':h['outcome'],'derived_outcome':p['outcome'],'both_comparable':p['TRS_cost'] is not None and p['TSR_cost'] is not None,'outcome_changed':p['outcome']!=h['outcome'] if p['TRS_cost'] is not None and p['TSR_cost'] is not None else None})
 summary_all={'status':'SCORED_AWAITING_INDEPENDENT_REVIEW','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'factors':factors,'original_bases':16,'derived_new_tasks':32,'historical_reused_tasks':16,'independent_sample_count_claim':False,'new_reference_gaps_computed':False,'resources':read('raw/FINISHED.json'),'transition_table':dict(Counter(t['historical_outcome']+'->'+t['derived_outcome'] for t in transitions if t['factor']=='1.2' and t['both_comparable'])),'limitations':read('freeze/PROTOCOL.json')['limitations']}
 write('reports/SUMMARY.json',summary_all)
 for path,rows in [('PAIRED_COSTS.csv',pairs),('PER_ARM.csv',endpoints),('FIXED_BUDGET_TRAJECTORIES.csv',trajectories),('OUTCOME_TRANSITIONS.csv',transitions)]:
  with (R/'reports'/path).open('x') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 lo=factors['0.8'];mid=factors['1.0'];hi=factors['1.2']
 def avg(s):return '未定义' if s['all16_mean_relative_percent'] is None else f"{s['all16_mean_relative_percent']['value']:.6f}%"
 report=f'''固定容量变化敏感性实验（待独立复核）

范围：既有16个公共迁移面板，固定坐标、需求与最多K非空车辆槽。容量因子事先固定为0.8/1.0/1.2；Q′=floor(因子×Q)，使用精确整数运算。32个新派生题，1.0直接引用16题既有已审TRS/TSR输出，无重跑。这些不是48个独立数据样本，也不是新的独立真实数据集。

可行性：0.8档16/16均满足总需求>KQ′，具有严格总量不可行证书；单需求没有超Q′。保留全部16题与48个SKIPPED_PROVEN_INFEASIBLE计划槽。搜索质量在该档无定义，不能以它检验两排序质量稳定性。1.2档通过必要条件后才各一次共享初始化，再运行固定TRS/TSR；通过必要条件本身不证明可行，实际输出需检验所有必访覆盖、载重及最多K约束。失败、超时、DFS限额或未找到解仅标未知，不当作不可行证明。

质量指标：同一道题成本差TSR−TRS，以及100×(TSR−TRS)/TRS；负值有利于TSR。它是相对TRS的成本变化百分比，不是published reference gap。原published reference不能用于新容量题，本报告未计算这种gap。

1.0历史：有效配对{mid['valid_pairs']}/16，结果{mid['outcomes']}；全16平均相对成本差{avg(mid)}。
1.2派生：有效配对{hi['valid_pairs']}/16，结果{hi['outcomes']}；全16平均相对成本差{avg(hi)}；全16平均绝对成本差{hi['all16_mean_TSR_minus_TRS_cost']}。
1.2与1.0的胜平负转移：{summary_all['transition_table']}。
缺失配对时，全16均值置空；可用配对均值另带明确分母，绝不以成功子集冒充全16。

资源：96个计划槽全部保留，其中48槽因严格不可行证书跳过。实际初始化进程{summary_all['resources']['initialization_processes']}次、搜索进程{summary_all['resources']['search_processes']}次；每搜索最多20000尝试，容量拒绝也计数。提前LOCAL_OPTIMUM可少于上限；固定节点的延用仅为已停止局部最优incumbent，不增加虚构评估。每进程外部3秒/256MiB，初始化硬CPU1秒、搜索2秒，监督器CPU10秒/180秒墙时；合计硬CPU上限90秒，单子进程并发、合计地址空间上限768MiB。计时只用于审计，不用于速度优势比较。

解释边界：容量变化同时可能改变初始化分组和贪心路径，不能隔离为排序的单一因果机制；原数据上的胜平负不能保证变容量后保持。只描述这16个坐标需求基底、一个确定性初始化及20000尝试预算，不声称统计显著、SOTA、全局最优或更广泛泛化。没有改变K、需求、因子，也没有补样、模型调用或新增依赖。

证据：冻结协议/源代码/派生输入/原始数据；96槽完整stdout与stderr、每次候选trace、初始化和失败信息；独立审核随后补入。先PREEXEC私有回读再唯一执行，RAW私有回读后才评分。旧证据不改。
'''
 (R/'reports/REPORT_ZH.txt').write_text(report)
 print(json.dumps(summary_all,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
