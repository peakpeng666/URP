"""Exactly one frozen endpoint call; public witness access denied by audit hook."""
import sys,os,json,resource,signal,time,hashlib,importlib
from pathlib import Path
sys.dont_write_bytecode=True
resource.setrlimit(resource.RLIMIT_CPU,(1,1));resource.setrlimit(resource.RLIMIT_AS,(256*1024**2,256*1024**2));signal.alarm(2)
ROOT=Path(__file__).resolve().parents[1];opened=[];denied=[]
stdlib=Path(os.__file__).resolve().parent

def file_audit(event,args):
 if event!='open':return
 path=args[0]
 if isinstance(path,int):return
 try:p=Path(os.fsdecode(path)).resolve()
 except Exception:raise PermissionError('unresolved file access')
 allowed=p.is_relative_to(ROOT/'source') or p.is_relative_to(ROOT/'input') or p.is_relative_to(stdlib)
 if not allowed:
  denied.append(str(p));raise PermissionError('file outside isolated source/input/stdlib allowlist')
 if p.is_relative_to(ROOT):opened.append(str(p.relative_to(ROOT)))
sys.addaudithook(file_audit)
parse_cpu0=time.process_time_ns();parse_wall0=time.perf_counter_ns()
item=json.loads(sys.argv[1]);input_path=ROOT/'input'/f"{item['instance_id']}.json";rawbytes=input_path.read_bytes();raw=json.loads(rawbytes)
parse_cpu_ns=time.process_time_ns()-parse_cpu0;parse_wall_ns=time.perf_counter_ns()-parse_wall0
parse_import_cpu=time.process_time_ns();mod=importlib.import_module(item['arm']);from independent_check import validate
parse_import_ns=time.process_time_ns()-parse_import_cpu
out=None;groups=None;diag=None;usage=None;error=None;matrix_cpu=None;matrix_wall=None
cpu=time.process_time_ns();wall=time.perf_counter_ns()
if item['endpoint']=='partition_256':
 try:
  groups,diag=mod.bounded_partition(raw['demands'],raw['capacity'],raw['K'],item['node_limit']);status='SUCCESS' if groups is not None else diag['outcome']
 except Exception as e:status='ALGORITHM_ERROR';error={'type':type(e).__name__,'message':str(e)}
else:
 inst=mod.instance_for(raw);budget=mod.Budget(100000,1,2)
 try:
  c=time.process_time_ns();w=time.perf_counter_ns();matrix=mod.matrix_for(inst,budget);matrix_cpu=time.process_time_ns()-c;matrix_wall=time.perf_counter_ns()-w
  routes,cost,diag=mod.initialize(raw,inst,matrix,budget);out=mod.output_for(routes,cost);status='SUCCESS'
 except mod.InitFailure as e:diag=getattr(e,'detail',None);status='INITFAIL';error={'type':type(e).__name__,'message':str(e)}
 except mod.StopBudget as e:status='BUDGET';error={'type':type(e).__name__,'message':str(e)}
 except Exception as e:status='ALGORITHM_ERROR';error={'type':type(e).__name__,'message':str(e)}
 usage=budget.snapshot()
measured_cpu=time.process_time_ns()-cpu;measured_wall=time.perf_counter_ns()-wall
cc=time.process_time_ns();cw=time.perf_counter_ns();checked=validate(raw,groups,out) if status=='SUCCESS' else None;checker_cpu=time.process_time_ns()-cc;checker_wall=time.perf_counter_ns()-cw
if checked is not None and not checked['accepted']:status='ILLEGAL_OUTPUT'
print(json.dumps({**item,'input_sha256':hashlib.sha256(rawbytes).hexdigest(),'status':status,'diagnostic':diag,'groups':groups,'output':out,'independent_check':checked,'budget':usage,'error':error,'measured_cpu_ns':measured_cpu,'measured_wall_ns':measured_wall,'matrix_cpu_ns':matrix_cpu,'matrix_wall_ns':matrix_wall,'checker_cpu_ns':checker_cpu,'checker_wall_ns':checker_wall,'import_cpu_ns':parse_import_ns,'parse_cpu_ns':parse_cpu_ns,'parse_wall_ns':parse_wall_ns,'child_self_maxrss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'reference_access_denied_paths':denied,'local_files_read':sorted(set(opened)),'solver_witness_or_BKS_reads':0,'local_search_calls':0},allow_nan=False))
