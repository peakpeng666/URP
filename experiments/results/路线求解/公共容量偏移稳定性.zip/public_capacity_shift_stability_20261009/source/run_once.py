"""Single-use derived-capacity supervisor:96 retained slots; at most48 processes."""
import pathlib,json,hashlib,subprocess,resource,datetime,time,signal,sys,os,traceback
from check_saved import validate
from harness_rules import certificate,skip_status
R=pathlib.Path(__file__).resolve().parents[1]
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads((R/p).read_text())
def write(p,v,mode='x'):
 with p.open(mode) as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
def append(p,v):
 with p.open('a') as f:f.write(json.dumps(v,separators=(',',':'))+'\n');f.flush();os.fsync(f.fileno())
def gates():
 receipt=read('provenance/PREEXEC_DRIVE_RECEIPT.json')
 assert receipt['owner_only'] and receipt['remote_readback_sha256_verified'] and receipt['download_byte_identical'] and receipt['shared'] is False
 assert receipt['frozen_files_sha256']==sha(R/'freeze/FROZEN_FILES.json')
 assert receipt['sha256']==receipt['download_sha256']==sha(R.parent/(R.name+'_PREEXEC.zip'))==sha(pathlib.Path(receipt['download_path']))
 frozen=read('freeze/FROZEN_FILES.json');assert all(sha(R/p)==v['sha256'] for p,v in frozen['files'].items())
 assert read('freeze/INDEPENDENT_PRECHECK.json')['status']=='PASS'
 tasks=read('freeze/TASKS.json');schedule=read('freeze/SCHEDULE.json')
 assert len(tasks)==32 and len(schedule)==96
 assert sum(t['proven_infeasible'] for t in tasks)==16
 assert sum(e['skip_proven_infeasible'] for e in schedule)==48
 for task in tasks:
  data=read(f"input/{task['instance_id']}.json")
  assert all(task[k]==v for k,v in certificate(data).items())
 old=read('freeze/OLD_FILES_BEFORE.json');assert all(sha(pathlib.Path(p))==v['sha256'] for p,v in old.items())
 return receipt

def main():
 resource.setrlimit(resource.RLIMIT_CPU,(10,10));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2));signal.alarm(180)
 wall=time.monotonic();cpu=time.process_time();receipt=gates()
 schedule=read('freeze/SCHEDULE.json');tasks=read('freeze/TASKS.json')
 assert len(schedule)==96 and len(tasks)==32 and len({x['call_id'] for x in schedule})==96
 write(R/'raw/STARTED.json',{'utc':now(),'no_reruns':True,'frozen_sha256':sha(R/'freeze/FROZEN_FILES.json'),'receipt_sha256':sha(R/'provenance/PREEXEC_DRIVE_RECEIPT.json'),'planned_initializations':32,'planned_search_slots':64,'analytically_skipped_slots':48,'max_initialization_processes':16,'max_search_processes':32})
 (R/'raw/calls').mkdir();(R/'raw/baselines').mkdir();results=[];baselines={}
 for entry in schedule:
  name=entry['instance_id'];slot=entry['selection_slot'];task=tasks[entry['task_index']-1];assert task['instance_id']==name
  data=read(f'input/{name}.json');assert set(data)=={'instance_id','coordinates','demands','capacity','K'}
  cid=entry['call_id'];out=R/'raw/calls'/f'{cid}.stdout';err=R/'raw/calls'/f'{cid}.stderr'
  append(R/'raw/attempts.jsonl',{'phase':'STARTED','utc':now(),**entry})
  started=time.monotonic();use=resource.getrusage(resource.RUSAGE_CHILDREN);before=use.ru_utime+use.ru_stime
  item={**entry,'status':'SUCCESS','process_spawned':False,'returncode':None,'stdout':str(out.relative_to(R)),'stderr':str(err.relative_to(R))}
  try:
   cert=certificate(data);assert cert['proven_infeasible']==entry['skip_proven_infeasible']==task['proven_infeasible']
   skip=skip_status(cert['proven_infeasible'],name in baselines,entry['kind'])
   if skip:
    with out.open('xb') as f:pass
    with err.open('xb') as f:pass
    item['status']=skip;item['process_spawned']=False;item['capacity_certificate']=cert
   else:
    if entry['kind']=='initialize':
     command=[sys.executable,'-B',str(R/'source/initialize_once.py'),json.dumps(entry)];payload=None
    else:
     payload={k:data[k] for k in ('coordinates','demands','capacity')};payload.update(routes=baselines[name],arm=entry['arm'],budget=20000)
     item['baseline_sha256']=sha(R/'raw/baselines'/f'{name}.json');item['payload_sha256']=hashlib.sha256(json.dumps(payload).encode()).hexdigest()
     command=[sys.executable,'-B',str(R/'source/worker.py')]
    with out.open('xb') as fo,err.open('xb') as fe:
     p=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=fo,stderr=fe,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'});item['process_spawned']=True
     try:p.communicate(None if payload is None else json.dumps(payload).encode(),timeout=3)
     except subprocess.TimeoutExpired:p.kill();p.communicate();item['status']='WALL_TIMEOUT'
     item['returncode']=p.returncode
     if p.returncode and item['status']=='SUCCESS':item['status']='PROCESS_FAILURE_OR_CPU_LIMIT'
    if item['status']=='SUCCESS':
     result=json.loads(out.read_text())
     if entry['kind']=='initialize':
      item['status']=result['status'];item['diagnostic']=result.get('diagnostic');item['budget']=result.get('budget')
      assert result['solver_witness_or_BKS_reads']==0 and result['reference_access_denied_paths']==[]
      if item['status']=='SUCCESS':
       assert result['independent_check']['accepted'] and len(result['output']['routes'])<=data['K']
       routes=[r[:] for r in result['output']['routes']]+[[0,0] for _ in range(data['K']-len(result['output']['routes']))]
       validate(routes,data['demands'],data['capacity'],data['K'])
       write(R/'raw/baselines'/f'{name}.json',{'instance_id':name,'source_initializer_call':cid,'source_stdout_sha256':sha(out),'routes':routes,'K':data['K'],'empty_slots_appended':data['K']-len(result['output']['routes'])})
       baselines[name]=routes
     else:
      assert result['arm']==entry['arm'] and 0<=result['attempted']<=20000 and result['reference_read_attempts']==0 and result['denied_io_events']==[]
      chk=validate(result['routes'],data['demands'],data['capacity'],data['K'])
      item['summary']={k:v for k,v in result.items() if k not in ('trace','scans','routes','loads','accepted_moves','checkpoints')}
      item.update(K_slots=data['K'],nonempty_routes=chk['nonempty_routes'])
  except Exception as e:
   item.update(status='CALL_ERROR_UNDETERMINED',error=str(e),traceback=traceback.format_exc())
   if entry['kind']=='initialize':baselines.pop(name,None)
  if out.exists():item['stdout_sha256']=sha(out)
  if err.exists():item['stderr_sha256']=sha(err)
  use=resource.getrusage(resource.RUSAGE_CHILDREN)
  item.update(process_cpu_seconds_for_audit_only=use.ru_utime+use.ru_stime-before,process_wall_seconds_for_audit_only=time.monotonic()-started)
  append(R/'raw/attempts.jsonl',{'phase':'FINISHED','utc':now(),**item});append(R/'raw/results.jsonl',item);results.append(item)
 signal.alarm(0);use=resource.getrusage(resource.RUSAGE_CHILDREN)
 write(R/'raw/FINISHED.json',{'utc':now(),'status':'FINISHED' if all(x['status'] in ('SUCCESS','SKIPPED_PROVEN_INFEASIBLE') for x in results) else 'FINISHED_WITH_FAILURES','planned_slots':96,'retained_slots':len(results),'initialization_processes':sum(x['kind']=='initialize' and x.get('process_spawned',False) for x in results),'search_processes':sum(x['kind']=='search' and x.get('process_spawned',False) for x in results),'wall_seconds_for_audit_only':time.monotonic()-wall,'supervisor_cpu_seconds_for_audit_only':time.process_time()-cpu,'children_cpu_seconds_for_audit_only':use.ru_utime+use.ru_stime,'hard_CPU_bound_seconds':90,'hard_wall_seconds':180,'combined_address_space_MiB':768,'max_concurrent_children':1})
 write(R/'raw/RAW_UNREVIEWED_MANIFEST.json',{'utc':now(),'status':'UNREVIEWED_RAW','files':{str(p.relative_to(R)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted((R/'raw').rglob('*')) if p.is_file()}})
if __name__=='__main__':main()
