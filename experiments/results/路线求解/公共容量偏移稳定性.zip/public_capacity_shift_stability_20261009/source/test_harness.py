"""Synthetic arithmetic and failure-policy fixtures only, no real-panel optimization."""
import json
from harness_rules import capacity,certificate,skip_status

def main():
 assert capacity(101,4)==80 and capacity(101,6)==121
 assert capacity(135,4)==108 and capacity(135,6)==162
 fixtures=[([0,10,10],10,2,False,False),([0,10,11],10,3,False,True),([0,8,8,8],10,2,True,False),([0,6,6,6],10,2,False,False)]
 for dem,q,k,tot,one in fixtures:
  c=certificate({'capacity':q,'K':k,'demands':dem})
  assert c['certificate_total_exceeds_fleet']==tot and c['certificate_max_exceeds_Q']==one and c['proven_infeasible']==(tot or one)
 assert skip_status(True,False,'initialize')=='SKIPPED_PROVEN_INFEASIBLE'
 assert skip_status(True,True,'search')=='SKIPPED_PROVEN_INFEASIBLE'
 assert skip_status(False,False,'initialize') is None
 assert skip_status(False,False,'search')=='SKIPPED_INITIALIZATION_FAILURE'
 assert skip_status(False,True,'search') is None
 # Passing the necessary arithmetic tests does not assert feasibility, e.g. 6+6+6 in two bins of10.
 assert not certificate({'capacity':10,'K':2,'demands':[0,6,6,6]})['proven_infeasible']
 from report import summary
 rows=[{'TRS_cost':100,'TSR_cost':90,'proven_infeasible':False,'outcome':'improved'} for _ in range(16)]
 assert summary(rows)['all16_mean_relative_percent']['value']==-10
 rows[0].update(TRS_cost=None,TSR_cost=None,outcome='UNKNOWN')
 assert summary(rows)['all16_mean_relative_percent'] is None and summary(rows)['available_pair_denominator']==15
 return {'status':'PASS','integer_floor_and_exact_boundaries':True,'total_and_single_demand_certificates':True,'passing_necessary_tests_not_proof_of_feasibility':True,'initialization_failure_kept_unknown':True,'all_skip_policies':True,'formal_calls':0}
if __name__=='__main__':print(json.dumps(main(),indent=2))
