"""Read-only arithmetic checker, no candidate imports or search."""
from collections import Counter
import math

def validate(raw,groups=None,output=None):
 errors=[];n=len(raw['demands'])-1;Q=raw['capacity'];K=raw['K'];cost=None
 if output is not None:
  routes=output.get('routes') if isinstance(output,dict) else None
  if not isinstance(routes,list):return {'accepted':False,'errors':['missing routes']}
  groups=[];edges=[]
  for route in routes:
   if not isinstance(route,list) or len(route)<3 or any(type(j)!=int or not 0<=j<=n for j in route) or route[0]!=0 or route[-1]!=0 or 0 in route[1:-1]:
    errors.append('bad depot/route shape');continue
   groups.append(route[1:-1])
   if all(type(j)==int and 0<=j<=n for j in route):
    for a,b in zip(route,route[1:]):
     x,y=raw['coordinates'][a],raw['coordinates'][b];edges.append(math.sqrt((x[0]-y[0])**2+(x[1]-y[1])**2))
  cost=math.fsum(edges);claimed=output.get('reported_cost')
  if type(claimed) not in (int,float) or not math.isfinite(claimed) or not math.isclose(cost,claimed,rel_tol=1e-10,abs_tol=1e-8):errors.append('cost mismatch')
 if not isinstance(groups,list):return {'accepted':False,'errors':['missing groups']}
 if len(groups)>K:errors.append('too many routes')
 flat=[];loads=[]
 for g in groups:
  if not isinstance(g,list) or not g:errors.append('empty/bad group');continue
  if any(type(j)!=int or not 1<=j<=n for j in g):errors.append('invalid customer');continue
  flat.extend(g);loads.append(sum(raw['demands'][j] for j in g))
 if Counter(flat)!=Counter(range(1,n+1)):errors.append('coverage is not exactly once')
 if any(l>Q for l in loads):errors.append('capacity exceeded')
 return {'accepted':not errors,'errors':errors,'loads':loads,'n_routes':len(groups),'continuous_cost':cost}
