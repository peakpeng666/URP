"""Arithmetic-only rules: never infer infeasibility from search failure."""
def capacity(base,numerator,denominator=5):
 assert type(base)is int and base>0 and numerator in (4,6) and denominator==5
 return base*numerator//denominator

def certificate(data):
 q=data['capacity'];k=data['K'];dem=data['demands']
 assert type(q)is int and q>0 and type(k)is int and k>0
 assert dem[0]==0 and all(type(x)is int and x>=0 for x in dem)
 total=sum(dem);maximum=max(dem)
 return {'total_demand':total,'max_demand':maximum,'fleet_capacity':k*q,'minimum_vehicles_total_demand':(total+q-1)//q,'certificate_total_exceeds_fleet':total>k*q,'certificate_max_exceeds_Q':maximum>q,'proven_infeasible':total>k*q or maximum>q}

def skip_status(proven,has_baseline,kind):
 if proven:return 'SKIPPED_PROVEN_INFEASIBLE'
 if kind=='search' and not has_baseline:return 'SKIPPED_INITIALIZATION_FAILURE'
 return None
