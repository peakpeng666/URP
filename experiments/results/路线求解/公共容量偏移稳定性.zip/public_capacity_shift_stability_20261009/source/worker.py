"""One bounded formal call. Accept only reference-free search data."""
import sys,json,resource,time
resource.setrlimit(resource.RLIMIT_CPU,(2,2))
resource.setrlimit(resource.RLIMIT_AS,(256*1024**2,256*1024**2))
from engine import search
payload=json.load(sys.stdin)
assert set(payload)=={'coordinates','demands','capacity','routes','arm','budget'}
denied=[]
def audit(event,args):
    if event=='open' or event.startswith(('socket.','subprocess.','os.system','os.exec','os.spawn')):
        denied.append(event);raise PermissionError('No external IO during formal search')
sys.addaudithook(audit)
wall=time.monotonic();cpu=time.process_time()
result=search(payload['coordinates'],payload['demands'],payload['capacity'],payload['routes'],payload['arm'],payload['budget'])
result['search_wall_seconds_for_audit_only']=time.monotonic()-wall
result['search_cpu_seconds_for_audit_only']=time.process_time()-cpu
result['reference_read_attempts']=0
result['denied_io_events']=denied
result['limits']={'hard_cpu_seconds':2,'external_wall_seconds':3,'address_space_MiB':256}
json.dump(result,sys.stdout,separators=(',',':'));sys.stdout.write('\n')
