"""Invented fixtures only. Exhaustively check every delta against full rescoring."""
import random,hashlib,json,itertools
from engine import matrix,cost,candidates,evaluate,apply,search,OPS

def check_routes(routes,demands,q,n,k):
    assert len(routes)==k and sorted(x for r in routes for x in r[1:-1])==list(range(1,n))
    assert all(r[0]==r[-1]==0 and sum(demands[x] for x in r[1:-1])<=q for r in routes)

def main():
    rng=random.Random(34031);checked=0;searches=0;accepted={op:0 for op in ('two_opt','relocate','swap')}
    assert matrix([(0,0),(0.5,0),(1.5,0)])[0]==[0,1,2]
    for trial in range(60):
        n=2+trial%8;k=1+trial%4
        coords=[(rng.randrange(-20,21),rng.randrange(-20,21)) for _ in range(n)]
        demands=[0]+[rng.randrange(1,5) for _ in range(n-1)]
        ids=list(range(1,n));rng.shuffle(ids);groups=[[] for _ in range(k)]
        for t,x in enumerate(ids):groups[t%k].append(x)
        routes=[[0]+g+[0] for g in groups];loads=[sum(demands[x] for x in g) for g in groups]
        q=max(loads)+trial%3;d=matrix(coords)
        for op in ('two_opt','relocate','swap'):
            for c in candidates(routes,op):
                ok,delta=evaluate(routes,loads,demands,q,d,op,c)
                rr=[r[:] for r in routes];ll=loads[:];old=cost(rr,d);apply(rr,ll,demands,op,c)
                assert ok==(max(ll)<=q)
                if ok:assert cost(rr,d)-old==delta
                else:assert delta is None
                assert ll==[sum(demands[x] for x in r[1:-1]) for r in rr]
                assert sorted(x for r in rr for x in r[1:-1])==list(range(1,n))
                checked+=1
        for arm in OPS:
            for budget in (0,1,1000):
                a=search(coords,demands,q,routes,arm,budget);b=search(coords,demands,q,routes,arm,budget)
                assert a==b and a['attempted']<=budget and a['cost']<=cost(routes,d)
                assert a['attempted']==len(a['trace'])==sum(v['attempted'] for v in a['counts'].values())
                check_routes(a['routes'],demands,q,n,k)
                if a['termination']=='LOCAL_OPTIMUM':
                    for op in OPS[arm]:
                        assert all(not (ok and delta<0) for ok,delta in (evaluate(a['routes'],a['loads'],demands,q,d,op,c) for c in candidates(a['routes'],op)))
                for op,v in a['counts'].items():accepted[op]+=v['accepted']
                searches+=1
    assert all(accepted.values())
    return {'status':'PASS','invented_fixtures':60,'delta_feasibility_checks':checked,'determinism_search_pairs':searches,
            'accepted_fixture_moves':accepted,'coverage_capacity_fixed_K_empty_routes':True,'half_up_rounding':True,
            'budget_0_1_1000':True,'local_optimum_exhaustive_checks':True,'benchmark_optimization_run':False}
if __name__=='__main__':print(json.dumps(main(),indent=2))
