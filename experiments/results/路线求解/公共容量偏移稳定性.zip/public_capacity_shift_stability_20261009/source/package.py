"""Freeze/package only, never invokes a benchmark solver."""
from pathlib import Path
import json,hashlib,zipfile,datetime,sys
R=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
if __name__=='__main__':
 stage=sys.argv[1];assert stage in ('PREEXEC','RAW_UNREVIEWED','FINAL_REVIEWED')
 if stage=='PREEXEC':
  assert not (R/'raw/STARTED.json').exists() and not (R/'freeze/FROZEN_FILES.json').exists()
  assert json.loads((R/'freeze/INDEPENDENT_PRECHECK.json').read_text())['status']=='PASS'
  files={str(p.relative_to(R)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(R.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and not str(p.relative_to(R)).startswith(('raw/','reports/','provenance/'))}
  with (R/'freeze/FROZEN_FILES.json').open('x') as f:json.dump({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PREEXEC_FROZEN','files':files},f,indent=2);f.write('\n')
 path=R.parent/(R.name+'_'+stage+'.zip')
 with zipfile.ZipFile(path,'x',zipfile.ZIP_DEFLATED) as z:
  for p in sorted(R.rglob('*')):
   if p.is_file() and '__pycache__' not in p.parts:z.write(p,str(p.relative_to(R.parent)))
 print(json.dumps({'path':str(path),'bytes':path.stat().st_size,'sha256':sha(path),'frozen_files_sha256':sha(R/'freeze/FROZEN_FILES.json')}))
