"""Independent Decimal metric and full route checks. No optimizer imports."""
from decimal import Decimal,localcontext,ROUND_HALF_UP
from collections import Counter

def raw_data(path):
    section=None;coords={};dem={};head={};depots=[]
    for raw in path.read_text().splitlines():
        x=raw.strip()
        if not x:continue
        if x in ('NODE_COORD_SECTION','DEMAND_SECTION','DEPOT_SECTION'):section=x;continue
        if x=='EOF':break
        if section=='NODE_COORD_SECTION':
            i,a,b=x.split();coords[int(i)]=(Decimal(a),Decimal(b))
        elif section=='DEMAND_SECTION':
            i,v=x.split();dem[int(i)]=int(v)
        elif section=='DEPOT_SECTION':
            if int(x)!=-1:depots.append(int(x))
        else:
            a,b=x.split(':',1);head[a.strip()]=b.strip()
    assert head['EDGE_WEIGHT_TYPE']=='EUC_2D' and depots==[1]
    n=int(head['DIMENSION']);assert set(coords)==set(dem)==set(range(1,n+1));matrix=[]
    with localcontext() as context:
        context.prec=80
        for i in range(1,n+1):
            row=[]
            for j in range(1,n+1):
                dx=coords[i][0]-coords[j][0];dy=coords[i][1]-coords[j][1]
                row.append(int((dx*dx+dy*dy).sqrt().quantize(Decimal(1),rounding=ROUND_HALF_UP)))
            matrix.append(row)
    return matrix,[dem[i] for i in range(1,n+1)],int(head['CAPACITY']),[coords[i] for i in range(1,n+1)]

def validate(routes,dem,q,K,d=None):
    assert len(routes)==K
    assert all(isinstance(r,list) and len(r)>=2 and r[0]==r[-1]==0 for r in routes)
    assert all(type(x)is int and 1<=x<len(dem) for r in routes for x in r[1:-1])
    assert Counter(x for r in routes for x in r[1:-1])==Counter(range(1,len(dem)))
    loads=[sum(dem[x] for x in r[1:-1]) for r in routes];assert all(x<=q for x in loads)
    return {'K_slots':K,'nonempty_routes':sum(len(r)>2 for r in routes),'loads':loads,
            'cost':None if d is None else sum(d[a][b] for r in routes for a,b in zip(r,r[1:]))}

def validate_input(data,task):
    assert set(data)=={'instance_id','demands','coordinates','capacity','K'}
    assert data['instance_id']==task['instance_id'] and data['K']==task['K']
    assert len(data['demands'])==len(data['coordinates']) and data['demands'][0]==0
    assert all(type(v)is int and v>=0 for v in data['demands'])
    return validate(task['baseline_routes'],data['demands'],data['capacity'],task['K'])
