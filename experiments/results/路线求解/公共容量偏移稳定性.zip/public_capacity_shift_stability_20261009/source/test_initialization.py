"""Invented fixture tests only; no benchmark files are read."""
import json
import capacity_solver as s
from independent_check import validate

def main():
 raw={'instance_id':'INVENTED_ONLY','coordinates':[[0,0],[1,0],[2,0],[0,2],[0,1]],'demands':[0,6,4,6,4],'capacity':10,'K':2}
 inst=s.instance_for(raw);b=s.Budget(100000,1,2);m=s.matrix_for(inst,b);routes,cost,diag=s.initialize(raw,inst,m,b)
 assert validate(raw,output=s.output_for(routes,cost))['accepted']
 groups,report=s.bounded_partition([0,6,6,4,4],10,2,256);assert groups and report['outcome']=='FOUND'
 groups,report=s.bounded_partition([0,6,6,4,4],10,2,1);assert groups is None and report['outcome']=='NODE_LIMIT'
 groups,report=s.bounded_partition([0,8,8,8],10,2,256);assert groups is None and report['outcome']=='SEARCH_EXHAUSTED'
 try:s.matrix_for(inst,s.Budget(100000,0,2));raise AssertionError('missing CPU stop')
 except s.StopBudget:pass
 try:s.initialize(raw,inst,m,s.Budget(0,1,2));raise AssertionError('missing delta stop')
 except s.StopBudget:pass
 return {'status':'PASS','invented_initializer_fixture_calls':1,'invented_partition_fixture_calls':3,'CPU_and_delta_stop_checked':True,'actual_panel_initialization_calls':0,'actual_panel_search_calls':0}
if __name__=='__main__':print(json.dumps(main(),indent=2))
