"""Synthetic supervisor and report fixtures. No actual child process is launched."""
import copy,datetime,importlib,json,pathlib,sys
from unittest.mock import patch
R=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(R/'source'))
import run_once as runner
import report as report
from harness_rules import certificate

def main():
    root=R/'independent_review/INVENTED_SUPERVISOR_FIXTURE';root.mkdir(exist_ok=False);(root/'raw').mkdir()
    tasks=[];schedule=[];inputs={};calls=[]
    for i in range(32):
        slot=i//2+1;factor,num=('0.8',4) if i%2==0 else ('1.2',6);name=f'INVENTED_{i+1:02}'
        data={'instance_id':name,'coordinates':[[0,0],[1,0],[2,0]],'demands':[0,3,2],'capacity':num,'K':1};inputs[f'input/{name}.json']=data
        cert=certificate(data);tasks.append(dict(instance_id=name,**cert))
        e={'instance_id':name,'selection_slot':slot,'task_index':i+1,'factor':factor,'skip_proven_infeasible':cert['proven_infeasible']}
        schedule.append(dict(e,call_id=f'I{i+1:02}',kind='initialize',arm='capacity_solver',endpoint='initialize_256',node_limit=256))
        for arm in (['TRS','TSR'] if slot%2 else ['TSR','TRS']):schedule.append(dict(e,call_id=f'S{i+1:02}_{arm}',kind='search',arm=arm,budget=20000))
    inputs.update({'freeze/TASKS.json':tasks,'freeze/SCHEDULE.json':schedule})
    class FakeProcess:
        def __init__(self,command,stdin,stdout,stderr,env):
            self.returncode=0;self.stdout=stdout;self.killed=False;calls.append(command)
            self.entry=json.loads(command[-1]) if command[-2].endswith('initialize_once.py') else None
            if self.entry and self.entry['task_index']==2:raise OSError('INVENTED spawn failure')
        def communicate(self,payload=None,timeout=None):
            if self.entry:
                idx=self.entry['task_index']
                if idx==6 and not self.killed:raise runner.subprocess.TimeoutExpired('INVENTED',3)
                if self.killed:return
                obj={'status':'INITFAIL' if idx==4 else 'SUCCESS','diagnostic':{'mathematical_infeasibility_claim':False},'budget':{},'solver_witness_or_BKS_reads':0,'reference_access_denied_paths':[],'independent_check':{'accepted':True},'output':{'routes':[[0,1,0]] if idx==8 else [[0,1,2,0]]}}
            else:
                p=json.loads(payload);obj={'arm':p['arm'],'routes':p['routes'],'cost':4,'initial_cost':4,'attempted':0,'feasible':0,'accepted':0,'termination':'LOCAL_OPTIMUM','budget':20000,'reference_read_attempts':0,'denied_io_events':[],'accepted_moves':[],'trace':[],'scans':[],'loads':[5],'checkpoints':[{'attempted':0,'cost':4}]}
            self.stdout.write(json.dumps(obj).encode());self.stdout.flush()
        def kill(self):self.killed=True;self.returncode=-9
    with patch.object(runner,'R',root),patch.object(runner,'read',lambda x:copy.deepcopy(inputs[x])),patch.object(runner,'gates',lambda:{}),patch.object(runner,'sha',lambda p:'INVENTED_HASH'),patch.object(runner.resource,'setrlimit',lambda *a:None),patch.object(runner.signal,'alarm',lambda *a:None),patch.object(runner.subprocess,'Popen',FakeProcess):
        runner.main();count=len(calls)
        try:runner.main()
        except FileExistsError:pass
        else:raise AssertionError('Second STARTED invocation was allowed')
        assert len(calls)==count
    results=[json.loads(x) for x in (root/'raw/results.jsonl').read_text().splitlines()]
    assert len(results)==96
    for row in results:
        assert 'process_spawned' in row,row['call_id']
    statuses={s:sum(x['status']==s for x in results) for s in {x['status'] for x in results}}
    assert statuses=={'SKIPPED_PROVEN_INFEASIBLE':48,'SKIPPED_INITIALIZATION_FAILURE':8,'CALL_ERROR_UNDETERMINED':2,'INITFAIL':1,'WALL_TIMEOUT':1,'SUCCESS':36},statuses
    assert len(calls)==40 # 16 initializer launch attempts, 24 search calls; no retries.
    assert all(x['status']=='SKIPPED_PROVEN_INFEASIBLE' and not x['process_spawned'] for x in results if x['factor']=='0.8')
    assert all(x['status']!='SKIPPED_PROVEN_INFEASIBLE' for x in results if x['factor']=='1.2')
    fin=json.loads((root/'raw/FINISHED.json').read_text());assert fin['initialization_processes']==15 and fin['search_processes']==24 and fin['retained_slots']==96
    # Summary has all16 denominator; missing or infeasible means no all16 cost estimate.
    pairs=[{'TRS_cost':100,'TSR_cost':90,'proven_infeasible':False,'outcome':'improved'} for _ in range(16)]
    s=report.summary(pairs);assert s['all16_mean_relative_percent']['exact']=='-10' and s['all16_mean_TSR_minus_TRS_cost']==-10 and s['valid_pairs']==16
    missing=copy.deepcopy(pairs);missing[0].update(TRS_cost=None,TSR_cost=None,outcome='UNDETERMINED_NO_VALID_PAIR')
    s=report.summary(missing);assert s['all16_mean_relative_percent'] is None and s['all16_mean_TSR_minus_TRS_cost'] is None and s['denominator']==16 and s['available_pair_denominator']==15 and s['available_pair_mean_relative_percent']['exact']=='-10'
    no_pairs=[{'TRS_cost':None,'TSR_cost':None,'proven_infeasible':True,'outcome':'PROVEN_INFEASIBLE'} for _ in range(16)]
    s=report.summary(no_pairs);assert s['valid_pairs']==0 and s['proven_infeasible_tasks']==16 and s['available_pair_mean_relative_percent'] is None and s['all16_mean_relative_percent'] is None
    # Missing RAW receipt must reject prior to any scoring.
    assert not (R/'provenance/RAW_UNREVIEWED_DRIVE_RECEIPT.json').exists()
    try:report.gates()
    except FileNotFoundError:pass
    else:raise AssertionError('RAW gate unexpectedly open')
    payload={'status':'PASS','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'synthetic_retained_slots':96,'synthetic_status_counts':statuses,'one_shot_second_STARTED_blocked':True,'all16_and_available_pair_denominators_checked':True,'RAW_missing_receipt_blocks_scoring':True,'formal_initialization_calls':0,'formal_search_calls':0,'fixture_launch_attempts_mocked_not_processes':len(calls)}
    (R/'independent_review/ORCHESTRATION_PRECHECK.json').write_text(json.dumps(payload,indent=2)+'\n');print(json.dumps(payload))
if __name__=='__main__':main()
