"""Invented no-solver gate and failure-policy fixtures; actual execution is blocked."""
import copy,importlib.util,json,pathlib,sys
from unittest.mock import patch
R=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(R/'source'))
import run_once as runner
import harness_rules as rules

def main():
    # Exercise actual arithmetic code, exact strictness, and integer boundaries.
    for q in range(2,102):
        for num in (4,6):
            value=rules.capacity(q,num);assert 5*value<=q*num<5*(value+1)
    for q in (2**53-1,2**53,2**53+1,10**30+4):
        for num in (4,6):assert rules.capacity(q,num)==q*num//5
    for data,want in [({'demands':[0,5,5],'capacity':5,'K':2},False),({'demands':[0,5,5,1],'capacity':5,'K':2},True),({'demands':[0,6,4],'capacity':5,'K':2},True),({'demands':[0,6,6,6],'capacity':10,'K':2},False)]:
        assert rules.certificate(data)['proven_infeasible']==want
    for kind in ('initialize','search'):
        assert rules.skip_status(True,False,kind)=='SKIPPED_PROVEN_INFEASIBLE'
        assert rules.skip_status(True,True,kind)=='SKIPPED_PROVEN_INFEASIBLE'
    assert rules.skip_status(False,False,'search')=='SKIPPED_INITIALIZATION_FAILURE'
    assert rules.skip_status(False,False,'initialize') is None
    assert rules.skip_status(False,True,'search') is None
    items={};tasks=[];schedule=[]
    for i in range(32):
        d={'demands':[0,5,5,1],'capacity':5 if i%2==0 else 10,'K':2};cert=rules.certificate(d)
        tasks.append(dict(instance_id=f'INVENTED_{i}',**cert));items[f'input/INVENTED_{i}.json']=d
        schedule.extend([{'skip_proven_infeasible':cert['proven_infeasible']}]*3)
    receipt={'owner_only':True,'remote_readback_sha256_verified':True,'download_byte_identical':True,'shared':False,'frozen_files_sha256':'OK','sha256':'OK','download_sha256':'OK','download_path':str(R/'independent_review/INVENTED_DOWNLOAD')}
    items.update({'provenance/PREEXEC_DRIVE_RECEIPT.json':receipt,'freeze/FROZEN_FILES.json':{'files':{'source/INVENTED.py':{'sha256':'OK'}}},'freeze/INDEPENDENT_PRECHECK.json':{'status':'PASS'},'freeze/TASKS.json':tasks,'freeze/SCHEDULE.json':schedule,'freeze/OLD_FILES_BEFORE.json':{str(R/'independent_review/INVENTED_OLD'):{'sha256':'OK'}}})
    passed=[]
    def attempt(label,modify=None,hash_fault=None,should_pass=False):
        data=copy.deepcopy(items)
        if modify:modify(data)
        def read(p):return data[p]
        def hash_(p):return 'BAD' if hash_fault and hash_fault(str(p)) else 'OK'
        with patch.object(runner,'read',read),patch.object(runner,'sha',hash_),patch.object(runner.subprocess,'Popen',side_effect=AssertionError('No process allowed in gate fixtures')):
            try:runner.gates()
            except (AssertionError,KeyError):
                assert not should_pass,label
            else:assert should_pass,label
        passed.append(label)
    attempt('valid_invented_gate',should_pass=True)
    attempt('missing_receipt',lambda x:x.pop('provenance/PREEXEC_DRIVE_RECEIPT.json'))
    for key in ('owner_only','remote_readback_sha256_verified','download_byte_identical'):
        attempt(key+'_false',lambda x,k=key:x['provenance/PREEXEC_DRIVE_RECEIPT.json'].__setitem__(k,False))
    attempt('public_shared',lambda x:x['provenance/PREEXEC_DRIVE_RECEIPT.json'].__setitem__('shared',True))
    attempt('download_digest_mismatch',lambda x:x['provenance/PREEXEC_DRIVE_RECEIPT.json'].__setitem__('download_sha256','BAD'))
    attempt('download_bytes_mismatch',hash_fault=lambda p:p.endswith('INVENTED_DOWNLOAD'))
    attempt('source_changed',hash_fault=lambda p:p.endswith('source/INVENTED.py'))
    attempt('frozen_manifest_changed',hash_fault=lambda p:p.endswith('freeze/FROZEN_FILES.json'))
    attempt('independent_precheck_not_PASS',lambda x:x['freeze/INDEPENDENT_PRECHECK.json'].__setitem__('status','PENDING'))
    attempt('certificate_tampered',lambda x:x['freeze/TASKS.json'][0].__setitem__('total_demand',999))
    attempt('schedule_missing_slot',lambda x:x['freeze/SCHEDULE.json'].pop())
    attempt('old_evidence_changed',hash_fault=lambda p:p.endswith('INVENTED_OLD'))
    # Verify ordinary current state is not accidentally executable before PREEXEC receipt.
    assert not (R/'provenance/PREEXEC_DRIVE_RECEIPT.json').exists()
    with patch.object(runner.subprocess,'Popen',side_effect=AssertionError('Must not launch before gate')):
        try:runner.gates()
        except FileNotFoundError:passed.append('actual_workspace_missing_receipt_blocks_gate')
        else:raise AssertionError('Unexpected available receipt; repeat audit against explicit fixture only')
    result={'status':'PASS','tested_actual_gate_function_with_invented_data':passed,'integer_floor_cases':208,'strict_total_and_single_demand_boundaries':True,'unknown_not_infeasible':True,'formal_initialization_calls':0,'formal_search_calls':0}
    (R/'independent_review/PREEXEC_GATE_FIXTURES.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
if __name__=='__main__':main()
