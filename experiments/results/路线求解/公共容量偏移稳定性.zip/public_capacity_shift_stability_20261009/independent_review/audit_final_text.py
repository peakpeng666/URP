"""Check final draft text and factor summary against independently replayed evidence."""
import collections,csv,datetime,hashlib,json,pathlib
R=pathlib.Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 audit=json.loads((R/'independent_review/POSTRUN_AUDIT.json').read_text());assert audit['status']=='PASS'
 report=R/'reports/FINAL_REPORT_DRAFT_ZH.txt';table=R/'reports/FACTOR_SUMMARY.csv';text=report.read_text()
 rows=list(csv.DictReader(table.open()));assert len(rows)==3 and [x['factor'] for x in rows]==['0.8','1.0','1.2']
 for row in rows:
  factor=row['factor'];a=audit['factors'][factor];assert row['task_denominator']=='16' and int(row['valid_pairs'])==a['valid_pairs']
  if factor=='0.8':
   assert row['proven_infeasible']=='16' and row['quality_defined']=='False' and row['retained_proof_skipped_primitive_slots']=='48'
   assert all(row[k]=='' for k in ('TSR_wins','ties','TSR_losses','all16_mean_cost_difference_TSR_minus_TRS','all16_mean_relative_percent_with_TRS_denominator'))
   assert row['new_initializer_processes']==row['new_search_processes']=='0'
  else:
   assert row['proven_infeasible']=='0' and row['quality_defined']=='True' and row['retained_proof_skipped_primitive_slots']=='0'
   for k,outcome in [('TSR_wins','improved'),('ties','equal'),('TSR_losses','worse')]:assert int(row[k])==a['outcomes'].get(outcome,0)
   assert float(row['all16_mean_relative_percent_with_TRS_denominator'])==a['mean_relative_percent'] and float(row['all16_mean_cost_difference_TSR_minus_TRS'])==a['mean_absolute']
   assert (row['new_initializer_processes'],row['new_search_processes'])==(('0','0') if factor=='1.0' else ('16','32'))
 lookup={(x['base_instance_id'],x['arm']):x for x in audit['results'] if x['factor']=='1.2'}
 assert lookup[('A-n61-k9','TRS')]['terminal_cost']==982 and lookup[('A-n61-k9','TSR')]['terminal_cost']==980
 assert lookup[('P-n55-k7','TRS')]['terminal_cost']==566 and lookup[('P-n55-k7','TSR')]['terminal_cost']==562
 for name,q in [('A-n61-k9',120),('P-n55-k7',204)]:assert json.loads((R/'input'/f'{name}__Q6of5.json').read_text())['capacity']==q
 for arm,attempted,local,exhausted in [('TRS',94959,15,1),('TSR',79828,16,0)]:
  rr=[v for v in lookup.values() if v['arm']==arm];assert sum(v['attempted'] for v in rr)==attempted
  c=collections.Counter(v['termination'] for v in rr);assert c['LOCAL_OPTIMUM']==local and c['BUDGET_EXHAUSTED']==exhausted
 assertions=['4胜10平2负','−2.39455%','−35.375','2胜14平0负','−0.05690%','−0.375','100×(TSR成本−TRS成本)/TRS成本','逐题计算后在16题上等权平均','平均差距缩小','0.8的质量没有定义','不是48个独立样本','初始化使用原连续欧氏距离','逐边四舍五入EUC_2D','94959','79828','96个新题计划槽全部保留','没有为新容量题计算这种gap','无统计显著性或泛化结论','0.8缺失数值为空，不当0']
 assert all(s in text for s in assertions)
 result={'status':'PASS','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Final readable report draft and factor summary, against independently replayed saved output; no solving.','report_draft_sha256':sha(report),'factor_summary_sha256':sha(table),'postrun_audit_sha256':sha(R/'independent_review/POSTRUN_AUDIT.json'),'verified':{'all_factor_denominators_and_mean_definitions':True,'0_8_undefined_quality_fields_empty_not_zero':True,'historical_no_rerun_and_new_problem_not_independent_sample_claims':True,'two_nonzero_1_2_pairs':True,'TRS_94959_attempts_15_local_1_exhausted':True,'TSR_79828_attempts_16_local_0_exhausted':True,'same_budget_not_equal_work_disclosed':True,'initializer_continuous_metric_and_search_rounded_metric_disclosed':True,'no_reference_gap_reuse':True,'descriptive_shrinking_gap_not_statistical_significance':True,'capacity_initialization_path_confounding_disclosed':True,'non_guarantee_and_no_SOTA_optimality_generalization_claims':True},'approved_finalization':'The draft may be renamed/copied byte-identically to reports/FINAL_REPORT_ZH.txt. If text changes, re-review the changed bytes.','final_delivery_upload_verification':'Still pending; this review makes no final-upload claim.','optimizer_calls':0,'initializer_calls':0}
 (R/'independent_review/FINAL_TEXT_TABLE_REVIEW.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
