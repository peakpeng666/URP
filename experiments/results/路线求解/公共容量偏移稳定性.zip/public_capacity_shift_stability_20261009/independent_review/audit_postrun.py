"""Independent saved-output/trace and report audit. No optimizer calls."""
import collections,csv,datetime,hashlib,importlib.util,json,math,pathlib,zipfile
from fractions import Fraction
R=pathlib.Path(__file__).resolve().parents[1]
ORIGINAL_REPLAY=pathlib.Path('/workspace/shared/public_route_order_transfer_20261008/independent_review/audit_saved_trace.py')
spec=importlib.util.spec_from_file_location('saved_only_replay',ORIGINAL_REPLAY);rep=importlib.util.module_from_spec(spec);spec.loader.exec_module(rep)
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rows(p):return list(csv.DictReader(p.open()))
def iso(s):return datetime.datetime.fromisoformat(s.replace('Z','+00:00'))
def number(s,value):
 if value is None:assert s==''
 else:assert math.isclose(float(s),float(value),rel_tol=1e-13,abs_tol=1e-13),(s,value)
def main():
 frozen=read(R/'freeze/FROZEN_FILES.json');sealed=read(R/'raw/SEALED_RAW_MANIFEST.json');old=read(R/'freeze/OLD_FILES_BEFORE.json')
 for entries,prefix in ((frozen['files'],R),(sealed['files'],R)):
  for p,v in entries.items():assert sha(prefix/p)==v['sha256'] and (prefix/p).stat().st_size==v['bytes'],p
 for p,v in old.items():assert sha(pathlib.Path(p))==v['sha256'] and pathlib.Path(p).stat().st_size==v['bytes'],p
 old_roots={pathlib.Path('/workspace/shared/public_route_order_transfer_20261008'),pathlib.Path('/workspace/shared/public_cross_group_moves_20261008')}
 assert set(old)=={str(p) for root in old_roots for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
 for p in (R/'historical').rglob('*'):
  if p.is_file():assert p.read_bytes()==(next(x for x in old_roots if x.name=='public_route_order_transfer_20261008')/p.relative_to(R/'historical')).read_bytes()
 archives=[];receipts={}
 for stage in ('PREEXEC','RAW_UNREVIEWED'):
  rc=read(R/f'provenance/{stage}_DRIVE_RECEIPT.json');receipts[stage]=rc
  assert rc['owner_only'] and not rc['shared'] and rc['remote_readback_sha256_verified'] and rc['download_byte_identical']
  local=R.parent/(R.name+'_'+stage+'.zip');download=pathlib.Path(rc['download_path'])
  assert local.read_bytes()==download.read_bytes() and sha(local)==rc['sha256']==rc['download_sha256'] and local.stat().st_size==rc['bytes']
  assert rc['frozen_files_sha256']==sha(R/'freeze/FROZEN_FILES.json')
  with zipfile.ZipFile(download) as z:
   for p,v in frozen['files'].items():assert hashlib.sha256(z.read(R.name+'/'+p)).hexdigest()==v['sha256']
   assert z.read(R.name+'/freeze/FROZEN_FILES.json')==(R/'freeze/FROZEN_FILES.json').read_bytes()
   if stage=='PREEXEC':assert not any(n.startswith(R.name+'/raw/') for n in z.namelist())
   else:
    assert z.read(R.name+'/raw/SEALED_RAW_MANIFEST.json')==(R/'raw/SEALED_RAW_MANIFEST.json').read_bytes()
    for p,v in sealed['files'].items():assert hashlib.sha256(z.read(R.name+'/'+p)).hexdigest()==v['sha256']
    assert not any(n.startswith(R.name+'/reports/') for n in z.namelist())
  archives.append({'stage':stage,'drive_id':rc['drive_id'],'sha256':sha(local),'bytes':local.stat().st_size,'download_byte_for_byte_matches':True,'all_frozen_members_match':True,'privacy':'Owner-only according to saved uploader receipt; independent bytes checked locally.'})
 protocol=read(R/'freeze/PROTOCOL.json');tasks=read(R/'freeze/TASKS.json');schedule=read(R/'freeze/SCHEDULE.json');history=read(R/'freeze/HISTORICAL_BASELINE.json')
 results=[json.loads(x) for x in (R/'raw/results.jsonl').read_text().splitlines()];attempts=[json.loads(x) for x in (R/'raw/attempts.jsonl').read_text().splitlines()]
 assert len(tasks)==32 and len(history)==16 and len(results)==len(schedule)==96 and len(attempts)==192
 assert len({r['call_id'] for r in results})==96
 assert [(a['phase'],a['call_id']) for a in attempts]==[(phase,e['call_id']) for e in schedule for phase in ('STARTED','FINISHED')]
 assert len(list((R/'raw/calls').glob('*')))==192 and len(list((R/'raw/baselines').glob('*.json')))==16
 starts=read(R/'raw/STARTED.json');finish=read(R/'raw/FINISHED.json');invoke=read(R/'raw/INVOCATION.json');outer=read(R/'raw/SUPERVISOR_RETURN.json');summary=read(R/'reports/SUMMARY.json')
 assert outer['returncode']==0 and not outer['outer_wall_timeout'] and outer['formal_started'] and outer['formal_finished']
 assert iso(receipts['PREEXEC']['confirmed_at_utc'])<=iso(invoke['utc'])<=iso(starts['utc'])<=iso(finish['utc'])<=iso(receipts['RAW_UNREVIEWED']['confirmed_at_utc'])<=iso(summary['created_utc'])
 assert finish['status']=='FINISHED' and finish['retained_slots']==96 and finish['initialization_processes']==16 and finish['search_processes']==32
 assert finish['wall_seconds_for_audit_only']<180 and finish['supervisor_cpu_seconds_for_audit_only']<10 and finish['children_cpu_seconds_for_audit_only']+finish['supervisor_cpu_seconds_for_audit_only']<90
 assert starts['frozen_sha256']==sha(R/'freeze/FROZEN_FILES.json') and starts['receipt_sha256']==sha(R/'provenance/PREEXEC_DRIVE_RECEIPT.json')
 baselines={};verified=[];saved_map={};raw_map={};skip_count=0;initializers=0;searches=0;init_cpu=search_cpu=0
 for i,(entry,result) in enumerate(zip(schedule,results)):
  assert all(result[k]==v for k,v in entry.items())
  assert all(attempts[2*i][k]==v for k,v in entry.items())
  assert all(attempts[2*i+1][k]==v for k,v in result.items())
  assert iso(attempts[2*i]['utc'])<=iso(attempts[2*i+1]['utc'])
  if i:assert iso(attempts[2*i-1]['utc'])<=iso(attempts[2*i]['utc'])
  data=read(R/'input'/f"{entry['instance_id']}.json");q=data['capacity'];k=data['K'];dem=data['demands'];task=tasks[entry['task_index']-1]
  assert data['instance_id']==task['instance_id']==entry['instance_id']
  assert q==task['base_capacity']*task['factor_numerator']//5
  total=sum(dem);maximum=max(dem);proven=total>k*q or maximum>q
  assert proven==task['proven_infeasible']==entry['skip_proven_infeasible']==(entry['factor']=='0.8')
  for field in ('stdout','stderr'):assert sha(R/result[field])==result[field+'_sha256']
  assert (R/result['stderr']).stat().st_size==0
  if proven:
   assert total>k*q and maximum<=q and result['status']=='SKIPPED_PROVEN_INFEASIBLE' and not result['process_spawned'] and result['returncode'] is None
   assert (R/result['stdout']).stat().st_size==0
   cert=result['capacity_certificate'];assert cert['total_demand']==total and cert['fleet_capacity']==k*q and cert['proven_infeasible'] and cert['certificate_total_exceeds_fleet']
   skip_count+=1;continue
  assert result['status']=='SUCCESS' and result['process_spawned'] and result['returncode']==0
  assert result['process_wall_seconds_for_audit_only']<3
  saved=read(R/result['stdout']);name=entry['instance_id']
  if entry['kind']=='initialize':
   initializers+=1;init_cpu+=result['process_cpu_seconds_for_audit_only'];assert result['process_cpu_seconds_for_audit_only']<1
   assert saved['status']=='SUCCESS' and saved['independent_check']['accepted'] and saved['solver_witness_or_BKS_reads']==0 and saved['reference_access_denied_paths']==[] and saved['local_search_calls']==0
   assert saved['input_sha256']==sha(R/'input'/f'{name}.json')
   assert all(p.startswith(('source/','input/')) for p in saved['local_files_read'])
   b=read(R/'raw/baselines'/f'{name}.json');routes=saved['output']['routes']
   assert b['routes']==routes+[[0,0] for _ in range(k-len(routes))] and b['source_initializer_call']==entry['call_id'] and b['source_stdout_sha256']==sha(R/result['stdout'])
   assert b['empty_slots_appended']==k-len(routes);rep.route_check(b['routes'],data)
   continuous=math.fsum(math.hypot(data['coordinates'][a][0]-data['coordinates'][b_][0],data['coordinates'][a][1]-data['coordinates'][b_][1]) for r in routes for a,b_ in zip(r,r[1:]))
   assert math.isclose(continuous,saved['output']['reported_cost'],rel_tol=1e-10,abs_tol=1e-8)
   assert saved['budget']['deltas']<=100000
   if 'capacity_partition' in (saved['diagnostic']or{}):assert saved['diagnostic']['capacity_partition']['nodes']<=256
   baselines[name]=b['routes']
  else:
   searches+=1;search_cpu+=result['process_cpu_seconds_for_audit_only'];assert result['process_cpu_seconds_for_audit_only']<2
   assert result['baseline_sha256']==sha(R/'raw/baselines'/f'{name}.json')
   payload={p:data[p] for p in ('coordinates','demands','capacity')};payload.update(routes=baselines[name],arm=entry['arm'],budget=20000)
   assert result['payload_sha256']==hashlib.sha256(json.dumps(payload).encode()).hexdigest()
   mat=[[rep.edge(a,b) for b in data['coordinates']] for a in data['coordinates']]
   replay=rep.replay(saved,baselines[name],data,mat)
   for key,value in result['summary'].items():assert saved[key]==value
   verified.append(dict(instance_id=name,base_instance_id=entry['base_instance_id'],factor='1.2',call_id=entry['call_id'],**replay));saved_map[(entry['base_instance_id'],'1.2',entry['arm'])]=saved;raw_map[(entry['base_instance_id'],'1.2')]=data
 assert skip_count==48 and initializers==16 and searches==32
 assert math.isclose(init_cpu+search_cpu,finish['children_cpu_seconds_for_audit_only'],abs_tol=1e-9)
 # Recheck both historical arms, fully replaying already-saved traces only.
 for h in history:
  name=h['instance_id'];data=read(R/'historical/input'/f'{name}.json');base=read(R/'historical/raw/baselines'/f'{name}.json')['routes'];mat=[[rep.edge(a,b) for b in data['coordinates']] for a in data['coordinates']]
  assert h['new_calls']==0 and h['factor']=='1.0'
  for record in h['source_records']:
   saved=read(R/'historical'/record['stdout']);assert sha(R/'historical'/record['stdout'])==record['stdout_sha256']
   v=rep.replay(saved,base,data,mat);verified.append(dict(instance_id=name,base_instance_id=name,factor='1.0',call_id=record['call_id'],**v));saved_map[(name,'1.0',record['arm'])]=saved;raw_map[(name,'1.0')]=data
 pairs={};derived={};expected_transitions=collections.Counter()
 for factor in ('0.8','1.0','1.2'):
  rr=[]
  for h in history:
   name=h['instance_id'];a=saved_map.get((name,factor,'TRS'));b=saved_map.get((name,factor,'TSR'))
   if a and b:
    delta=b['cost']-a['cost'];percent=Fraction(100*delta,a['cost']);outcome='improved' if delta<0 else 'worse' if delta>0 else 'equal'
   else:delta=percent=None;outcome='PROVEN_INFEASIBLE'
   pair={'TRS_cost':a['cost'] if a else None,'TSR_cost':b['cost'] if b else None,'delta':delta,'relative_percent':percent,'outcome':outcome};pairs[(name,factor)]=pair;rr.append(pair)
  valid=[p for p in rr if p['delta'] is not None];s=summary['factors'][factor]
  assert s['denominator']==16 and s['valid_pairs']==s['available_pair_denominator']==len(valid)
  assert s['outcomes']==dict(collections.Counter(p['outcome'] for p in rr)) and s['proven_infeasible_tasks']==(16 if factor=='0.8' else 0)
  if valid:
   mean=sum((p['relative_percent'] for p in valid),Fraction())/16;absolute=Fraction(sum(p['delta'] for p in valid),16)
   assert s['all16_mean_relative_percent']['exact']==s['available_pair_mean_relative_percent']['exact']==str(mean)
   assert s['all16_mean_relative_percent']['value']==s['available_pair_mean_relative_percent']['value']==float(mean)
   assert s['all16_mean_TSR_minus_TRS_cost']==s['available_pair_mean_cost']==float(absolute)
  else:
   mean=absolute=None
   assert all(s[k] is None for k in ('all16_mean_relative_percent','available_pair_mean_relative_percent','all16_mean_TSR_minus_TRS_cost','available_pair_mean_cost'))
  for arm in ('TRS','TSR'):assert s['arm_success'][arm]=={'valid_routes':len(valid),'all_task_denominator':16,'not_proven_infeasible_denominator':len(valid)}
  derived[factor]={'valid_pairs':len(valid),'outcomes':s['outcomes'],'mean_relative_percent':None if mean is None else float(mean),'mean_relative_exact':None if mean is None else str(mean),'mean_absolute':None if absolute is None else float(absolute)}
 for h in history:expected_transitions[pairs[(h['instance_id'],'1.0')]['outcome']+'->'+pairs[(h['instance_id'],'1.2')]['outcome']]+=1
 assert summary['transition_table']==dict(expected_transitions)
 paired_rows=rows(R/'reports/PAIRED_COSTS.csv');arm_rows=rows(R/'reports/PER_ARM.csv');trace_rows=rows(R/'reports/FIXED_BUDGET_TRAJECTORIES.csv');transition_rows=rows(R/'reports/OUTCOME_TRANSITIONS.csv')
 assert len(paired_rows)==48 and len(arm_rows)==96 and len(trace_rows)==576 and len(transition_rows)==32
 assert len({(x['base_instance_id'],x['factor']) for x in paired_rows})==48
 for row in paired_rows:
  p=pairs[(row['base_instance_id'],row['factor'])];assert row['outcome']==p['outcome']
  for field,value in [('TRS_cost',p['TRS_cost']),('TSR_cost',p['TSR_cost']),('TSR_minus_TRS_cost',p['delta']),('relative_percent_TRS_denominator',p['relative_percent'])]:number(row[field],value)
  assert row['proven_infeasible']==str(row['factor']=='0.8')
 assert len({(x['base_instance_id'],x['factor'],x['arm']) for x in arm_rows})==96
 for row in arm_rows:
  saved=saved_map.get((row['base_instance_id'],row['factor'],row['arm']))
  assert row['new_process_spawned']==str(row['factor']=='1.2')
  if saved:
   assert row['status']=='SUCCESS';data=raw_map[(row['base_instance_id'],row['factor'])]
   for field,value in [('cost',saved['cost']),('attempted',saved['attempted']),('feasible',saved['feasible']),('accepted',saved['accepted']),('capacity_rejected',saved['attempted']-saved['feasible']),('nonempty_routes',sum(len(r)>2 for r in saved['routes']))]:number(row[field],value)
   assert row['termination']==saved['termination'] and int(row['K_slots'])==data['K']
  else:
   assert row['status']=='SKIPPED_PROVEN_INFEASIBLE'
   for field in ('cost','attempted','feasible','accepted','capacity_rejected','nonempty_routes'):assert row[field]==''
 assert len({(x['base_instance_id'],x['factor'],x['arm'],x['budget_node']) for x in trace_rows})==576
 for row in trace_rows:
  saved=saved_map.get((row['base_instance_id'],row['factor'],row['arm']));budget=int(row['budget_node']);assert budget in (0,100,1000,5000,10000,20000)
  if saved:
   cost=saved['initial_cost'];carry=budget>saved['attempted']
   assert not carry or saved['termination']=='LOCAL_OPTIMUM'
   for move in saved['accepted_moves']:
    if move['attempted']<=budget:cost=move['cost']
   number(row['cost'],cost);assert row['carried_after_LOCAL_OPTIMUM']==str(carry);number(row['actual_attempted'],saved['attempted'])
  else:assert row['cost']=='' and row['carried_after_LOCAL_OPTIMUM']=='False' and row['actual_attempted']==''
 for row in transition_rows:
  a=pairs[(row['base_instance_id'],'1.0')];b=pairs[(row['base_instance_id'],row['factor'])];valid=b['delta'] is not None
  assert row['historical_outcome']==a['outcome'] and row['derived_outcome']==b['outcome'] and row['both_comparable']==str(valid)
  assert row['outcome_changed']==(str(a['outcome']!=b['outcome']) if valid else '')
 assert summary['new_reference_gaps_computed'] is False and summary['independent_sample_count_claim'] is False and summary['resources']==finish
 assert summary['limitations']==protocol['limitations']
 assert '原published reference不能用于新容量题' in (R/'reports/REPORT_ZH.txt').read_text()
 audit={'status':'PASS','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'method':'Independent Fraction/isqrt exact EUC_2D and saved-trace full-route arithmetic replay; no optimization or initialization rerun.','replay_source':str(ORIGINAL_REPLAY),'replay_source_sha256':sha(ORIGINAL_REPLAY),'audit_script_sha256':sha(pathlib.Path(__file__)),'scheduled_slots':96,'attempt_records':192,'proven_infeasible_skips':48,'formal_initializer_processes':16,'formal_search_processes':32,'historical_searches_reused_without_calls':32,'derived_trace_candidates_verified':sum(v['attempted'] for v in verified if v['factor']=='1.2'),'historical_trace_candidates_reverified':sum(v['attempted'] for v in verified if v['factor']=='1.0'),'all_trace_candidates_verified':sum(v['attempted'] for v in verified),'all_terminal_and_checkpoint_outputs_verified':True,'factors':derived,'transition_table':dict(expected_transitions),'results':verified,'archives':archives,'gate_timestamps_order_verified':True,'frozen_entries_unchanged':len(frozen['files']),'sealed_raw_entries_unchanged':len(sealed['files']),'old_evidence_files_unchanged':len(old),'resource_audit':finish,'report_CSV_row_counts':{'pairs':48,'arms':96,'checkpoints':576,'transitions':32},'reviewed_report_files':{str(p.relative_to(R)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted((R/'reports').iterdir()) if p.is_file()},'optimizer_calls_by_reviewer':0,'initializer_calls_by_reviewer':0,'remaining':'Final human-readable report wording and final uploaded deliverable verification remain separate checks.'}
 (R/'independent_review/POSTRUN_AUDIT.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({k:v for k,v in audit.items() if k not in ('results','reviewed_report_files')},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
