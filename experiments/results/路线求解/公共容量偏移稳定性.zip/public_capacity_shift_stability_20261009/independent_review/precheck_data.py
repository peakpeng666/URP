"""Independent pre-execution data review. No formal initializer/search calls."""
import ast,collections,datetime,hashlib,json,math,pathlib,sys
from fractions import Fraction
R=pathlib.Path(__file__).resolve().parents[1]
O=pathlib.Path('/workspace/shared/public_route_order_transfer_20261008')
C=pathlib.Path('/workspace/shared/public_cross_group_moves_20261008')
def read(p): return json.loads(p.read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def same(a,b): assert a.read_bytes()==b.read_bytes(),(str(a),str(b))
def rounded_distance(a,b):
    s=sum((Fraction(str(x))-Fraction(str(y)))**2 for x,y in zip(a,b))
    lo=math.isqrt(s.numerator//s.denominator)
    return lo+int(4*s.numerator>=s.denominator*(2*lo+1)**2)
def rescore(routes, data):
    assert len(routes)==data['K']
    assert all(isinstance(r,list) and len(r)>=2 and r[0]==r[-1]==0 for r in routes)
    assert collections.Counter(x for r in routes for x in r[1:-1])==collections.Counter(range(1,len(data['demands'])))
    assert all(all(type(x)is int and 1<=x<len(data['demands']) for x in r[1:-1]) for r in routes)
    assert all(sum(data['demands'][x] for x in r[1:-1])<=data['capacity'] for r in routes)
    return sum(rounded_distance(data['coordinates'][a],data['coordinates'][b]) for r in routes for a,b in zip(r,r[1:]))
def main():
    assert not (R/'raw/STARTED.json').exists() and not (R/'raw/INVOCATION.json').exists()
    tasks=read(R/'freeze/TASKS.json');schedule=read(R/'freeze/SCHEDULE.json');history=read(R/'freeze/HISTORICAL_BASELINE.json');prior=read(O/'freeze/TASKS.json')
    assert len(tasks)==32 and len(schedule)==96 and len(history)==16 and len(prior)==16
    assert len({x['instance_id'] for x in tasks})==32 and len({x['call_id'] for x in schedule})==96
    assert [t['selection_slot'] for t in prior]==list(range(1,17))
    assert [h['instance_id'] for h in history]==[t['instance_id'] for t in prior]
    certificates=[]
    for i,t in enumerate(tasks):
        p=prior[i//2];factor,num=[('0.8',4),('1.2',6)][i%2]
        base=read(R/'historical/input'/f"{p['instance_id']}.json");data=read(R/'input'/f"{t['instance_id']}.json")
        assert t['base_instance_id']==p['instance_id'] and t['selection_slot']==p['selection_slot'] and t['factor']==factor
        assert t['factor_numerator']==num and t['factor_denominator']==5 and t['rounding']=='integer_floor'
        assert t['base_capacity']==base['capacity'] and t['K']==p['K']==base['K']
        assert data==dict(base,instance_id=t['instance_id'],capacity=base['capacity']*num//5)
        assert set(data)=={'instance_id','coordinates','demands','capacity','K'}
        q=data['capacity'];total=sum(data['demands']);mx=max(data['demands']);k=data['K']
        assert t['capacity']==q and t['total_demand']==total and t['max_demand']==mx and t['fleet_capacity']==k*q
        assert t['minimum_vehicles_total_demand']==(total+q-1)//q
        assert t['certificate_total_exceeds_fleet']==(total>k*q)
        assert t['certificate_max_exceeds_Q']==(mx>q)
        assert t['proven_infeasible']==(total>k*q or mx>q)
        assert t['proven_infeasible']==(factor=='0.8')
        if factor=='0.8':
            assert total>k*q
            certificates.append({'base':p['instance_id'],'Q':q,'K':k,'demand':total,'fleet_capacity':k*q,'strict_excess':total-k*q})
        entries=schedule[3*i:3*i+3];arms=['TRS','TSR'] if p['selection_slot']%2 else ['TSR','TRS']
        assert [e['kind'] for e in entries]==['initialize','search','search']
        assert [e['arm'] for e in entries]==['capacity_solver']+arms
        assert entries[0]['endpoint']=='initialize_256' and entries[0]['node_limit']==256
        for e in entries:
            assert e['instance_id']==t['instance_id'] and e['task_index']==i+1 and e['base_instance_id']==p['instance_id']
            assert e['factor']==factor and e['selection_slot']==p['selection_slot'] and e['skip_proven_infeasible']==t['proven_infeasible']
            if e['kind']=='search': assert e['budget']==20000
    assert sum(e['skip_proven_infeasible'] for e in schedule)==48
    assert collections.Counter(e['kind'] for e in schedule if not e['skip_proven_infeasible'])=={'initialize':16,'search':32}
    compat=read(R/'freeze/SOURCE_COMPATIBILITY.json');hashes=[]
    frozen_old=read(O/'freeze/FROZEN_FILES.json')['files']
    for row in compat['algorithm_copies']:
        p=R/row['copy'];o=pathlib.Path(row['origin']);same(p,o)
        assert sha(p)==row['sha256']==frozen_old[row['copy']]['sha256'];hashes.append(row)
    old_entries=read(R/'freeze/OLD_FILES_BEFORE.json')
    for name,v in old_entries.items():
        p=pathlib.Path(name);assert p.stat().st_size==v['bytes'] and sha(p)==v['sha256'],name
    expected=set(old_entries)
    current={str(p) for root in (O,C) for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
    assert current==expected,{'added':list(current-expected),'removed':list(expected-current)}
    for row in frozen_old.values(): assert set(row)>={'bytes','sha256'}
    for name,row in frozen_old.items():
        p=O/name; assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],name
    copied=[]
    for p in sorted((R/'historical').rglob('*')):
        if p.is_file():
            rel=p.relative_to(R/'historical');same(p,O/rel);copied.append({'path':str(p.relative_to(R)),'sha256':sha(p),'bytes':p.stat().st_size})
    for name in ('SAVED_TRACE_AUDIT.json','FINAL_REPORT_AUDIT.json','FINAL_DELIVERY_VERIFICATION.json'):
        assert read(R/'historical/independent_review'/name)['status']=='PASS'
    afns=lambda p:[ast.dump(n,include_attributes=False) for n in ast.parse(p.read_text()).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))]
    assert afns(R/'source/engine.py')==afns(C/'source/engine.py')
    historic_records=[json.loads(l) for l in (R/'historical/raw/results.jsonl').read_text().splitlines()]
    old_audit={x['call_id']:x for x in read(R/'historical/independent_review/SAVED_TRACE_AUDIT.json')['results']}
    historic_checks=[]
    for h,p in zip(history,prior):
        assert h['factor']=='1.0' and h['new_calls']==0 and h['selection_slot']==p['selection_slot']
        data=read(R/'historical/input'/f"{p['instance_id']}.json");baseline=read(R/'historical/raw/baselines'/f"{p['instance_id']}.json")
        assert h['K']==data['K'] and h['capacity']==data['capacity']
        initial=rescore(baseline['routes'],data)
        wanted=[x for x in historic_records if x['instance_id']==p['instance_id'] and x['kind']=='search' and x['arm'] in ('TRS','TSR')]
        assert h['source_records']==wanted and len(wanted)==2 and {x['arm'] for x in wanted}=={'TRS','TSR'}
        for x in wanted:
            assert x['status']=='SUCCESS';out=read(R/'historical'/x['stdout'])
            assert sha(R/'historical'/x['stdout'])==x['stdout_sha256'] and sha(R/'historical'/x['stderr'])==x['stderr_sha256']
            assert sha(R/'historical/raw/baselines'/f"{p['instance_id']}.json")==x['baseline_sha256']
            cost=rescore(out['routes'],data)
            assert cost==out['cost']==x['summary']['cost']==old_audit[x['call_id']]['terminal_cost']
            assert initial==out['initial_cost']==x['summary']['initial_cost']==old_audit[x['call_id']]['initial_cost']
            assert out['attempted']<=20000 and out['budget']==20000
            historic_checks.append({'instance_id':p['instance_id'],'arm':x['arm'],'cost':cost,'initial_cost':initial,'routes_valid':True,'source_sha256':x['stdout_sha256']})
    # Exact threshold and capacity-floor arithmetic fixtures; no real-instance optimizer calls.
    rounding=[]
    for q in (1,2,3,4,5,6,9,10,11,99,100,101,2**53-1,2**53,2**53+1,10**30+4):
        for num in (4,6):
            qp=q*num//5;assert 5*qp<=q*num<5*(qp+1);rounding.append([q,num,qp])
    proof_tests=[]
    for demands,q,k,expected in [([0,5,5],5,2,False),([0,5,5,1],5,2,True),([0,6,4],5,2,True),([0,4,4,4],6,2,False),([0,3,3],4,2,False)]:
        got=sum(demands)>k*q or max(demands)>q;assert got==expected;proof_tests.append({'demands':demands,'Q':q,'K':k,'proven':got})
    assert rounded_distance([0,0],[.5,0])==1 and rounded_distance([0,0],[1.5,0])==2
    assert rounded_distance([0,0],[3,4])==5
    output={'status':'PASS','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'derived_tasks':32,'retained_schedule_slots':96,'strict_total_demand_certificates':certificates,'analytically_skipped_slots':48,'eligible_initializer_ceiling':16,'eligible_search_ceiling':32,'historical_outputs_recalculated':historic_checks,'historical_copies':copied,'algorithm_copy_count':len(hashes),'old_inventory_files_unchanged':len(old_entries),'old_frozen_entries_unchanged':len(frozen_old),'rounding_integer_boundary_fixtures':rounding,'proof_boundary_fixtures':proof_tests,'formal_initialization_calls':0,'formal_search_calls':0,'metric':'Fraction/isqrt exact rounded EUC_2D, independently written','limitations':'Pre-execution data and copied historical evidence review; no current run or remote receipt claims.'}
    (R/'independent_review/DATA_PRECHECK.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:output[k] for k in ('status','derived_tasks','retained_schedule_slots','analytically_skipped_slots','algorithm_copy_count','old_inventory_files_unchanged','old_frozen_entries_unchanged')}))
if __name__=='__main__':main()
