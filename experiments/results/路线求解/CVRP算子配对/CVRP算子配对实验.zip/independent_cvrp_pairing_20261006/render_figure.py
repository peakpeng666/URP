"""Presentation-only PNG rasterization using preinstalled Pillow; solver stays stdlib-only."""
import csv
import json
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
R=Path(__file__).resolve().parent
rows=list(csv.DictReader((R/'results/per_instance_pair.csv').open()))
summary=json.loads((R/'results/summary.json').read_text())['pair_summary']
pairs=['random_cheapest','random_regret2','worst_cheapest','worst_regret2']
labels=['Random + cheapest','Random + regret-2','Worst + cheapest','Worst + regret-2']
scale=2
img=Image.new('RGB',(1120*scale,760*scale),'white');d=ImageDraw.Draw(img)
fpath='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
bpath='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
def text(x,y,s,size=15,anchor='ls',color='#17304a',bold=False):
 font=ImageFont.truetype(bpath if bold else fpath,size*scale)
 d.text((x*scale,y*scale),s,font=font,fill=color,anchor=anchor)
def rect(x,y,w,h,color):d.rounded_rectangle((x*scale,y*scale,(x+w)*scale,(y+h)*scale),radius=3*scale,fill=color)
text(40,40,'Fixed CVRP operator pairing: small synthetic development panel',25,bold=True)
text(40,68,'Improvement over the same savings baseline (%); each cell averages 3 search seeds')
x0,y0,cw,ch=220,118,205,42
for j,s in enumerate(labels):text(x0+j*cw+cw/2,y0-12,s,anchor='ms')
maxv=max(float(x['mean_improvement_pct']) for x in rows)
for ix in range(8):
 rr=[x for x in rows if int(x['instance_index'])==ix];b=rr[0]
 text(40,y0+ix*ch+27,f"{b['family'].capitalize()} n{b['n']} / {int(b['replicate'])+1}")
 for j,p in enumerate(pairs):
  v=float(next(x['mean_improvement_pct'] for x in rr if x['pair']==p));t=v/maxv
  color=(int(242-205*t),int(247-130*t),int(250-85*t))
  rect(x0+j*cw,y0+ix*ch,cw-3,ch-3,color)
  text(x0+j*cw+cw/2,y0+ix*ch+27,f'{v:.3f}',anchor='ms',color='white' if t>.57 else '#17304a')
text(40,493,'Equal-instance panel mean')
barx,bary,width=280,515,650
for k in range(5):
 x=barx+k*width/4;d.line((x*scale,(bary-8)*scale,x*scale,(bary+135)*scale),fill='#e4e9ef',width=scale);text(x,bary+156,f'{k*0.4:.1f}',13,anchor='ms')
for j,s in enumerate(summary):
 y=bary+j*34;text(260,y+18,labels[pairs.index(s['pair'])],anchor='rs')
 bw=s['mean_improvement_pct']/1.6*width;rect(barx,y,bw,24,'#1675a9' if j==0 else '#789cb1');text(barx+bw+9,y+18,f"{s['mean_improvement_pct']:.3f}%")
text(40,704,'96/96 feasible; 53 runs hit 100 iterations, 43 hit 100,000 deltas. No CPU/wall timeout.',13)
text(40,729,'Descriptive only: 8 instances; unequal actual work. No holdout, significance, full G-LNS, or field-efficacy claim.',13)
img.save(R/'figures/pairing_results.png')
