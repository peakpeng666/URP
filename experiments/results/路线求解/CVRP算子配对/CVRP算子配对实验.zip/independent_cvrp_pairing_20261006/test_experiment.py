import copy
import json
import math
import random
import unittest
from pathlib import Path
import experiment as e
from urp_cvrp.baselines import savings as trusted_savings
from urp_cvrp.budget import Budget as TrustedBudget
from urp_cvrp.instance import from_dict


def tiny():
    return from_dict({'spec_version':'euclidean-cvrp-v1','instance_id':'unit-tiny','coordinates':[[0,0],[1,0],[2,0],[0,2]],'demands':[0,2,2,2],'capacity':4,'depot':0,'objective':'sum_unrounded_euclidean_distance','fleet':'unlimited_identical_vehicles','split':'unit_test','generation_seed':None,'family':'unit'})

class Tests(unittest.TestCase):
    def test_savings_matches_trusted_on_new_smoke(self):
        cfg=json.loads((e.ROOT/'PLAN.json').read_text())
        for spec in cfg['smoke_instances']:
            i=e.generate_instance(spec['n'],spec['family'],spec['seed'],cfg['capacity'])
            b=e.Budget(); m=e.matrix_for(i,b); routes=e.savings(i,m,b); actual=e.output_for(routes,e.cost_of(routes,m,b))
            expected=trusted_savings(i,0,TrustedBudget(2,5))
            self.assertEqual(actual,expected)
            self.assertEqual(b.deltas,i.n_customers*(i.n_customers-1)//2)
            self.assertEqual(b.by_kind['savings'],b.deltas)
    def test_checker_valid_exact_geometry(self):
        i=tiny(); out={'routes':[[0,1,2,0],[0,3,0]],'reported_cost':8.0}
        c=e.check_solution(i,out); self.assertTrue(c.accepted); self.assertEqual(c.recomputed_cost,8)
    def test_checker_negative_cases(self):
        i=tiny(); good={'routes':[[0,1,2,0],[0,3,0]],'reported_cost':8.0}
        cases=[None,{}, {'routes':[],'reported_cost':0}, {'routes':[[0,1,1,0],[0,3,0]],'reported_cost':8}, {'routes':[[0,1,2,3,0]],'reported_cost':8}, {'routes':[[1,2,0],[0,3,0]],'reported_cost':8}, {'routes':[[0,-1,2,0],[0,3,0]],'reported_cost':8}, {'routes':[[0,1,0,2,0],[0,3,0]],'reported_cost':8}, {'routes':[[0,True,2,0],[0,3,0]],'reported_cost':8}, {'routes':good['routes'],'reported_cost':7}, {'routes':good['routes'],'reported_cost':float('nan')}]
        for out in cases:
            with self.subTest(out=out): self.assertFalse(e.check_solution(i,out).accepted)
    def test_all_operator_pairs_preserve_input_and_feasibility(self):
        i=tiny(); original=i.to_dict(); routes=[[1,2],[3]]; untouched=copy.deepcopy(routes)
        for d in ['random','worst']:
            for r in ['cheapest','regret2']:
                b=e.Budget(); m=e.matrix_for(i,b)
                partial,removed=e.destroy(routes,d,2,random.Random(7),m,b)
                self.assertEqual(sorted(removed+[x for rt in partial for x in rt]),[1,2,3])
                repaired=e.repair(partial,removed,r,i,m,b)
                out=e.output_for(repaired,e.cost_of(repaired,m,b))
                self.assertTrue(e.check_solution(i,out).accepted)
                self.assertEqual(routes,untouched); self.assertEqual(i.to_dict(),original)
    def test_new_route_capacity_fallback(self):
        i=tiny(); b=e.Budget(); m=e.matrix_for(i,b)
        for r in ['cheapest','regret2']:
            routes=e.repair([[1,2]],[3],r,i,m,b)
            self.assertEqual(len(routes),2)
            self.assertTrue(e.check_solution(i,e.output_for(routes,e.cost_of(routes,m,b))).accepted)
    def test_delta_budget_computation_precheck(self):
        b=e.Budget(deltas=1); b.delta('insertion')
        with self.assertRaises(e.StopBudget): b.delta('removal')
        self.assertEqual(b.deltas,1); self.assertEqual(b.by_kind['removal'],0)
    def test_count_known_insertion_options(self):
        i=tiny(); b=e.Budget(); m=e.matrix_for(i,b)
        options=e.route_options(3,[[1]],[2],i,m,b)
        self.assertEqual(b.by_kind['insertion'],3) # 2 positions + singleton
        self.assertEqual(len(options),2) # distinct route alternatives
    def test_truncation_retains_valid_baseline(self):
        i=tiny(); cfg=json.loads((e.ROOT/'PLAN.json').read_text()); cfg['delta_limit']=3
        result=e.run_one(i,['worst','regret2'],7,100,cfg)
        self.assertEqual(result['stop_reason'],'delta_budget')
        self.assertTrue(result['check']['accepted']); self.assertEqual(result['deltas'],3)
        self.assertEqual(result['improvement_fraction'],0)
    def test_rng_replay_and_common_q(self):
        seed=11; n=20
        a=[random.Random(e.derived_seed(seed,'q',it)).randint(2,6) for it in range(20)]
        b=[random.Random(e.derived_seed(seed,'q',it)).randint(2,6) for it in range(20)]
        self.assertEqual(a,b); self.assertGreater(len(set(a)),1)

if __name__=='__main__': unittest.main(verbosity=2)
