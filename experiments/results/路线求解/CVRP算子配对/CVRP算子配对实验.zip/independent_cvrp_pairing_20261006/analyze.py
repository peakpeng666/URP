"""Read-only statistical audit of stored runs; never rerun an optimizer."""
import collections
import csv
import hashlib
import html
import json
import math
from pathlib import Path
import statistics
import sys
import datetime
import experiment as e

R=e.ROOT
cfg=json.loads((R/'PLAN.json').read_text())
e.verify_frozen(cfg)
formal=[json.loads(x) for x in (R/'results/formal.jsonl').read_text().splitlines()]
smoke=[json.loads(x) for x in (R/'results/smoke.jsonl').read_text().splitlines()]
manifest=json.loads((R/'data/manifest.json').read_text())
inst={}
for d in manifest['entries']:
    p=R/d['file']; assert hashlib.sha256(p.read_bytes()).hexdigest()==d['file_sha256']
    i=e.from_dict(json.loads(p.read_text())); assert i.sha256==d['canonical_sha256']; inst[i.instance_id]=i
assert len(formal)==96 and len(smoke)==16
expected={(x['seed'], '_'.join(p), s) for x in cfg['instances'] for p in cfg['pairs'] for s in cfg['search_seeds']}
observed={(inst[r['instance_id']].generation_seed,r['pair'],r['search_seed']) for r in formal}
assert expected==observed and len(observed)==96
assert sum(r['solver_cpu_seconds'] for r in formal)<=192
check_rows=[]
for r in formal+smoke:
    i=inst[r['instance_id']]
    assert i.sha256==r['instance_sha256']
    for key in ['output','baseline']:
        c=e.check_solution(i,r[key])
        assert c.accepted
        saved=r['check' if key=='output' else 'baseline_check']
        assert c.recomputed_cost==saved['recomputed_cost']
        check_rows.append({'stage':r['stage'],'run_index':r['run_index'],'kind':key,**c.to_dict()})
    assert r['deltas']<=100000 and r['deltas']==sum(r['delta_by_kind'].values())
    assert r['solver_cpu_seconds']<=2 and r['solver_wall_seconds']<=5
    assert r['iterations_completed']<= (100 if r['stage']=='formal' else 10)
    assert r['output']['reported_cost']<=r['baseline']['reported_cost']+1e-9
    if r['stop_reason']=='delta_budget': assert r['deltas']==100000
    if r['stop_reason']=='iteration_budget': assert r['iterations_completed']== (100 if r['stage']=='formal' else 10)
    for t in r['trace']:
        q=e.random.Random(e.derived_seed(r['search_seed'],'q',t['iteration'])).randint(max(2,math.ceil(.1*r['n'])),max(2,math.ceil(.3*r['n'])))
        assert q==t['q']
    assert all(a['incumbent_cost']>=b['incumbent_cost']-1e-9 for a,b in zip(r['trace'],r['trace'][1:]))
with (R/'results/checker_revalidation.jsonl').open('w') as f:
    for row in check_rows:f.write(json.dumps(row)+'\n')
for d in manifest['entries']:
    b=[r['baseline']['reported_cost'] for r in formal+smoke if r['instance_id']==d['instance_id']]
    assert len(set(b))==1
# Source files are checked again, without opening any old data.
source_audit=[]
for d in json.loads((R/'SOURCE_MANIFEST.json').read_text())['sources']:
    p=R.parent/d['source']; same=hashlib.sha256(p.read_bytes()).hexdigest()==d['sha256']; assert same
    source_audit.append({'path':d['source'],'unchanged':same})

pairs=['_'.join(p) for p in cfg['pairs']]
rows=[]
for ix in range(8):
    per=[]
    for p in pairs:
        rr=[r for r in formal if r['instance_index']==ix and r['pair']==p]
        assert len(rr)==3
        v=[100*r['improvement_fraction'] for r in rr]
        per.append({'instance_index':ix,'instance_id':rr[0]['instance_id'],'family':rr[0]['family'],'n':rr[0]['n'],'replicate':rr[0]['replicate'],'pair':p,'runs':3,'accepted':sum(r['check']['accepted'] for r in rr),'baseline_cost':rr[0]['baseline_check']['recomputed_cost'],'mean_final_cost':statistics.mean(r['check']['recomputed_cost'] for r in rr),'mean_improvement_pct':statistics.mean(v),'min_improvement_pct':min(v),'max_improvement_pct':max(v),'mean_deltas':statistics.mean(r['deltas'] for r in rr),'cpu_total_seconds':sum(r['solver_cpu_seconds'] for r in rr),'wall_total_seconds':sum(r['solver_wall_seconds'] for r in rr),'delta_truncations':sum(r['stop_reason']=='delta_budget' for r in rr),'mean_completed_iterations':statistics.mean(r['iterations_completed'] for r in rr),'distinct_final_route_sets':len(set(json.dumps(r['output']['routes']) for r in rr))})
    for x in per:
        better=sum(y['mean_improvement_pct']>x['mean_improvement_pct']+1e-9 for y in per)
        tied=sum(abs(y['mean_improvement_pct']-x['mean_improvement_pct'])<=1e-9 for y in per)
        x['midrank']=1+better+(tied-1)/2
        x['best_tied_or_solo']=better==0
    rows.extend(per)
with (R/'results/per_instance_pair.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
flat_keys=['stage','run_index','instance_index','instance_id','family','n','replicate','search_index','search_seed','pair','improvement_fraction','deltas','solver_cpu_seconds','solver_wall_seconds','checker_cpu_seconds','checker_wall_seconds','iterations_started','iterations_completed','accepted_improvements','stop_reason']
with (R/'results/per_run.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=flat_keys);w.writeheader();w.writerows({k:r[k] for k in flat_keys} for r in formal)
summary=[]
for p in pairs:
    ii=[x for x in rows if x['pair']==p]; rr=[x for x in formal if x['pair']==p]
    summary.append({'pair':p,'mean_improvement_pct':statistics.mean(x['mean_improvement_pct'] for x in ii),'mean_midrank':statistics.mean(x['midrank'] for x in ii),'best_instances_including_ties':sum(x['best_tied_or_solo'] for x in ii),'accepted':sum(x['check']['accepted'] for x in rr),'runs':len(rr),'deltas':sum(x['deltas'] for x in rr),'cpu_seconds':sum(x['solver_cpu_seconds'] for x in rr),'wall_seconds':sum(x['solver_wall_seconds'] for x in rr),'delta_truncations':sum(x['stop_reason']=='delta_budget' for x in rr),'min_completed_iterations':min(x['iterations_completed'] for x in rr),'max_completed_iterations':max(x['iterations_completed'] for x in rr)})
summary.sort(key=lambda x:-x['mean_improvement_pct'])
inter=[]
for ix in range(8):
    vals={x['pair']:x['mean_improvement_pct'] for x in rows if x['instance_index']==ix}
    interaction=(vals['worst_regret2']-vals['worst_cheapest'])-(vals['random_regret2']-vals['random_cheapest'])
    inter.append({'instance_index':ix,'regret_gain_random_pp':vals['random_regret2']-vals['random_cheapest'],'regret_gain_worst_pp':vals['worst_regret2']-vals['worst_cheapest'],'difference_of_differences_pp':interaction})
result={'n_instances':8,'search_repeats_per_instance_pair':3,'n_formal_runs':96,'n_smoke_runs':16,'accepted_formal':96,'accepted_smoke':16,'algorithm_failures':0,'stop_reasons':dict(collections.Counter(r['stop_reason'] for r in formal)),'cpu_total_seconds':sum(r['solver_cpu_seconds'] for r in formal),'wall_total_seconds':sum(r['solver_wall_seconds'] for r in formal),'checker_cpu_total_seconds':sum(r['checker_cpu_seconds'] for r in formal),'solver_cpu_max_seconds':max(r['solver_cpu_seconds'] for r in formal),'solver_wall_max_seconds':max(r['solver_wall_seconds'] for r in formal),'deltas_total':sum(r['deltas'] for r in formal),'matrix_distances_total':sum(r['matrix_distances'] for r in formal),'objective_edges_total':sum(r['objective_edges'] for r in formal),'pair_summary':summary,'interaction_per_instance':inter,'mean_interaction_pp':statistics.mean(x['difference_of_differences_pp'] for x in inter),'inference':'descriptive development-panel only; instances are units, search seeds are nested repeats; unequal actual work; no statistical significance claim'}
e.dump_json(R/'results/summary.json',result)
e.dump_json(R/'results/AUDIT.json',{'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passed':True,'formal_unique_expected_slots':96,'stored_output_rechecks':224,'original_sources_unchanged':source_audit,'plan_hash_unchanged':True,'code_prerun_hash_checked_externally':True,'instance_hashes_verified':True,'budget_caps_verified':True,'common_q_schedule_verified':True,'baseline_identical_within_instance':True,'no_optimizer_reruns_in_audit':True})

# SVG generated with standard library; every plotted cell is an 8-instance/4-pair mean.
svg=['<svg xmlns="http://www.w3.org/2000/svg" width="1120" height="760" viewBox="0 0 1120 760">','<rect width="1120" height="760" fill="#ffffff"/>','<style>text{font-family:DejaVu Sans,sans-serif;fill:#17304a} .small{font-size:13px} .label{font-size:15px} .title{font-size:25px;font-weight:bold}</style>']
def tx(x,y,s,cl='label',anchor='start',fill=None):
    svg.append(f'<text x="{x}" y="{y}" class="{cl}" text-anchor="{anchor}"'+(f' style="fill:{fill}"' if fill else '')+'>'+html.escape(str(s))+'</text>')
tx(40,40,'Fixed CVRP operator pairing: small synthetic development panel','title')
tx(40,68,'Improvement over the same savings baseline (%); each cell averages 3 search seeds','label')
x0,y0,cw,ch=220,118,205,42
labels=['Random + cheapest','Random + regret-2','Worst + cheapest','Worst + regret-2']
for j,s in enumerate(labels):tx(x0+j*cw+cw/2,y0-12,s,'label','middle')
maxv=max(x['mean_improvement_pct'] for x in rows)
for ix in range(8):
    rr=[x for x in rows if x['instance_index']==ix]; base=rr[0]
    tx(40,y0+ix*ch+27,f"{base['family'].capitalize()} n{base['n']} / {base['replicate']+1}")
    for j,p in enumerate(pairs):
        v=next(x['mean_improvement_pct'] for x in rr if x['pair']==p)
        t=v/maxv; color=f'rgb({int(242-205*t)},{int(247-130*t)},{int(250-85*t)})'
        svg.append(f'<rect x="{x0+j*cw}" y="{y0+ix*ch}" width="{cw-3}" height="{ch-3}" fill="{color}" rx="3"/>')
        tx(x0+j*cw+cw/2,y0+ix*ch+27,f'{v:.3f}',anchor='middle',fill='#ffffff' if t>.57 else '#17304a')
tx(40,493,'Equal-instance panel mean','label')
barx,bary,width=280,515,650
for k in range(5):
    x=barx+k*width/4;svg.append(f'<line x1="{x}" y1="{bary-8}" x2="{x}" y2="{bary+135}" stroke="#e4e9ef"/>');tx(x,bary+156,f'{k*0.4:.1f}','small','middle')
for j,s in enumerate(summary):
    y=bary+j*34;lab=labels[pairs.index(s['pair'])]
    tx(260,y+18,lab,'label','end')
    bw=s['mean_improvement_pct']/1.6*width
    svg.append(f'<rect x="{barx}" y="{y}" width="{bw:.3f}" height="24" rx="3" fill="'+('#1675a9' if j==0 else '#789cb1')+'"/>')
    tx(barx+bw+9,y+18,f"{s['mean_improvement_pct']:.3f}%")
tx(40,704,'96/96 feasible; 53 runs hit 100 iterations, 43 hit 100,000 deltas. No CPU/wall timeout.','small')
tx(40,729,'Descriptive only: 8 instances; unequal actual work. No holdout, significance, full G-LNS, or field-efficacy claim.','small')
svg.append('</svg>');(R/'figures/pairing_results.svg').write_text('\n'.join(svg)+'\n')

ptext='\n'.join(f"| {x['pair']} | {x['mean_improvement_pct']:.4f}% | {x['mean_midrank']:.3f} | {x['accepted']}/{x['runs']} | {x['delta_truncations']} | {x['deltas']:,} | {x['cpu_seconds']:.4f} | {x['wall_seconds']:.4f} |" for x in summary)
itable='\n'.join('| '+f"{ix+1} / {rr[0]['family']} n{rr[0]['n']} / r{rr[0]['replicate']}"+' | '+' | '.join(f"{next(z['mean_improvement_pct'] for z in rr if z['pair']==p):.4f}%" for p in pairs)+' |' for ix in range(8) for rr in [[x for x in rows if x['instance_index']==ix]])
report=f'''# 独立 CVRP 固定 destroy/repair 配对实验

## 结论先行

预定 96 次正式运行与 16 次独立 smoke 均已实际完成，全部通过独立可行性和成本检查，0 次算法失败。8 个合成开发实例等权、实例内先平均 3 个搜索种子后，random + regret-2 在此面板上平均改善最高：**1.4952%**。其余依次为 random + cheapest 0.6485%、worst + regret-2 0.4838%、worst + cheapest 0.2480%。这只是固定小型开发面板结果，不能据此宣称统计普适性、完整 G-LNS 复现或农业田间有效。

## 冻结与范围

- PLAN.json 冻结时间：{cfg['frozen_at_utc']}；FREEZE.json 保存计划哈希，PRE_RUN_SHA256SUMS.txt 在首次实验前保存实现及依赖哈希
- 新数据：uniform/clustered × n20/n50 × 2 实例重复，容量 30；另有两个 n10 smoke 实例。新命名种子以 SHA-256 派生，见 PLAN.json；没有读取旧 holdout 或旧数据文件
- **每轮 q 在 ceil(0.1n)–ceil(0.3n) 之间均匀变化，同实例/搜索种子下四配对共用 q 序列**。这是运行前独立冻结的版本，随后收到固定20%移除建议时没有更改计划。因此不能称为固定20%移除实验
- uniform 与 clustered 是自制合成欧氏 CVRP 开发分布，车辆数不限、同质车辆、仓库0、距离不取整；源生成器原样复制，只调用 generate_instance，未调用带旧 seed 字段的 generate_from_config
- 单进程并固定一核，独立无 pip 的 stdlib venv；无包安装、模型调用、自适应选择或主实验数据串用，原五个组件源文件哈希未变
- 概念来源为 [G-LNS 固定提交](https://github.com/ZBoyn/G-LNS/tree/ea834aaa23a6952ff5e47d377940ec38b7e97482) 的成对接口思想；没有下载执行其代码，没有 LLM/双种群/共演化，也未检验其累计 synergy 评分

## 算法契约

统一使用 parallel Clarke-Wright savings 初解。这里的实现保留可信 baselines.py 的排序、端点合并与平局规则，并逐次显式记 savings delta；smoke 单元测试逐项与原 baseline 输出一致。只接受目标降低超过 1e-9 的完整候选；预算在半轮耗尽时丢弃半成品，返回此前完整 incumbent。

- random：从现有客户均匀不放回抽 q 个
- worst：每删除一个客户都重新计算所有剩余客户的边际距离节省，选最大；同分按客户编号
- cheapest：每步枚举所有待插客户在所有容量可行路线位置的 delta，含开一条新路线，选全局最便宜；平局按客户、路线、位置
- regret-2：先取每客户在每条可行路线的最佳插入位置，再在不同路线（含新路线）的两个最佳代价间求 regret，优先最大 regret；只有一个可行路线时记无限 regret。每插一步都更新载重
- destroy 和 repair 均复制路线，不修改冻结元组形式的坐标或需求

## 实际结果

统计单位是 **8 个实例**，搜索种子是实例内重复，不能把24个run当成24个独立实例。排名为每实例四配对的 midrank（允许并列）后平均。

| 配对 | 等实例权均值改善 | 平均midrank | 验收通过 | delta截断 | 实际delta总数 | CPU秒 | wall秒 |
|---|---:|---:|---:|---:|---:|---:|---:|
{ptext}

每实例结果（百分比；各自3种子均值）：

| 实例 | random+cheapest | random+regret2 | worst+cheapest | worst+regret2 |
|---|---:|---:|---:|---:|
{itable}

random+regret2 在8实例均为并列或单独第一，但只有两个分布、两个规模、每格两个实例，不做显著性推断。各配对仍有较多重复最终路线，详见 CSV；相同结果不被当成新增独立证据。

## 描述性交互

将改善百分比记为 Y，报告 (Y_worst,regret2 − Y_worst,cheapest) − (Y_random,regret2 − Y_random,cheapest)，在8实例平均为 **{result['mean_interaction_pp']:.6f} 个百分点**。即本面板上 regret-2 相对 cheapest 的收益，对 random destroy 比对 worst destroy 大约多 0.611 个百分点。这是固定配对的描述性差中之差；不是 G-LNS synergy 分数验证、显著性检验或因果机制证明。逐实例差异另存 summary.json。

## 资源与失败完整账本

- 正式：96 真正运行，53 次完成100迭代，43 次达到100000 delta；0算法异常，0 CPU或wall超时，0补样，0更换种子
- 正式求解：累计 {result['cpu_total_seconds']:.6f} CPU秒、{result['wall_total_seconds']:.6f} 墙钟秒；单run最大CPU {result['solver_cpu_max_seconds']:.6f}秒、最大墙钟 {result['solver_wall_max_seconds']:.6f}秒；总delta {result['deltas_total']:,}
- CPU/墙钟覆盖每次的矩阵、savings初解、搜索、结果封装与预算检查；独立checker在返回后运行，另计正式checker CPU {result['checker_cpu_total_seconds']:.6f}秒。进程启动、数据生成、JSON磁盘写入、汇总/绘图不在求解CPU范围内
- 计数在算术表达式之前发生，savings增益、worst removal收益、每个插入位置/新路线的delta均逐次计数，重复重算重复收费；总矩阵距离计算 {result['matrix_distances_total']:,} 次，完整目标边读取 {result['objective_edges_total']:,} 次另列
- 每run同时受100迭代、100000 delta、2秒CPU和5秒硬墙钟上限约束；CPU/墙钟定时器与每个delta前合作检查双保险。累计正式CPU上限192秒也有总量门禁
- **相同迭代/delta上限不代表相同实际工作量**：worst额外支付删除收益计算；cheapest与regret-2的排序/选择成本也不同，构造距离与全目标检查另计。部分run首先达到迭代上限，其他首先达到delta上限。因此这里比较的是同上限配置下各自轨迹，不是纯算子机制在完全等CPU、等完整迭代或等候选分布条件下的因果消融
- smoke完全单独记账，不进入正式统计

## 验证

9项 unittest 通过，含11个非法输出负例、可信savings对齐、所有配对可行性与不污染输入、新路线容量兜底、delta先检查、插入选项精确计数、预算中断保留可行初解、种子重放。实际正式/烟雾结果均经 vendor checker 从原始坐标重算：每客户恰好一次、路线仓库起终点、无中间仓库、编号合法、容量、欧氏距离与上报成本一致。

二次审计只读取落盘路线，不重跑优化器：112run的最终解与初解共224次重新验收，全部通过；验证96唯一预定槽位完整、预算上限、原始数据哈希、源组件未变、各实例初解一致、共用q序列、incumbent单调。结果见 results/AUDIT.json 与 checker_revalidation.jsonl。

## 文件与复现

- experiment.py：完整求解与运行器；test_experiment.py：小范围单元/负向测试
- PLAN.json / PLAN.md / FREEZE.json / PRE_RUN_SHA256SUMS.txt：运行前冻结证据
- SOURCE_MANIFEST.json / vendor/：本地可信来源与原样副本
- data/manifest.json / *.json：仅本次新生成开发实例、来源命名、文件哈希、canonical哈希
- results/formal.jsonl / smoke.jsonl：逐run输出路线、checker、trace、预算与种子完整原始账本
- results/per_run.csv / per_instance_pair.csv / summary.json：可审计汇总
- figures/pairing_results.svg：stdlib生成的可缩放科研图；PNG以相同落盘汇总用系统已有Pillow绘制，仅供呈现，不是求解依赖，也未安装或更改全局包。SVG转换工具缺少rsvg委托，因此没有使用该转换结果

程序默认拒绝覆写已存在stage结果。如要复现应在新副本中明确使用新的输出目录，不能直接覆盖本次证据。当前成果只在本地，未对外上传。
'''
(R/'REPORT_ZH.md').write_text(report)
(R/'README.md').write_text('# Independent fixed CVRP pairing\n\nRead REPORT_ZH.md first. Data, protocol, code and raw runs are frozen/auditable. This is a synthetic development-panel mechanism probe, not a full G-LNS reproduction.\n\nStandard library only; .venv was created with `python -m venv --without-pip .venv`.\n\nOriginal launch: `.venv/bin/python -m unittest -v test_experiment`, then `.venv/bin/python experiment.py --stage all`. The runner refuses to overwrite existing results. Post-run audit: `.venv/bin/python analyze.py`; no optimizer reruns.\n')
print(json.dumps(result,indent=2))
