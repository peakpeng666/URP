# Independent fixed CVRP pairing

Read REPORT_ZH.md first. Data, protocol, code and raw runs are frozen/auditable. This is a synthetic development-panel mechanism probe, not a full G-LNS reproduction.

Standard library only; .venv was created with `python -m venv --without-pip .venv`.

Original launch: `.venv/bin/python -m unittest -v test_experiment`, then `.venv/bin/python experiment.py --stage all`. The runner refuses to overwrite existing results. Post-run audit: `.venv/bin/python analyze.py`; no optimizer reruns.
