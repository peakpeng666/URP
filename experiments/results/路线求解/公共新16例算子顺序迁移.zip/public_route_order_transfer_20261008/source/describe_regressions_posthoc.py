"""Requested posthoc description of saved regression traces; no solver reruns."""
from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parents[1]
records=[]
for slot,name in [(6,'A-n69-k9'),(15,'P-n55-k7')]:
 pair={'instance_id':name,'analysis_type':'posthoc_mechanistic_clue_not_new_primary_endpoint','arms':{}}
 ref=json.loads((R/f'references/{name}.json').read_text())['reference_integer_cost']
 for arm in ['TRS','TSR']:
  p=R/f'raw/calls/S{slot:02}_{arm}.stdout';x=json.loads(p.read_text());tail=x['scans'][-3:]
  assert x['termination']=='LOCAL_OPTIMUM' and x['attempted']<20000 and len(tail)==3 and {s['op'] for s in tail}=={'two_opt','relocate','swap'} and all(s['complete_nonimproving'] and not s['accepted'] for s in tail)
  pair['arms'][arm]={'source':str(p.relative_to(R)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'initial_cost':x['initial_cost'],'cost':x['cost'],'attempted':x['attempted'],'termination':x['termination'],'counts':x['counts'],'last_three_scans':tail,'accepted_moves':x['accepted_moves'],'budget_truncated_operators':[]}
 pair.update(cost_difference_TSR_minus_TRS=pair['arms']['TSR']['cost']-pair['arms']['TRS']['cost'],gap_difference_pp=100*(pair['arms']['TSR']['cost']-pair['arms']['TRS']['cost'])/ref,reference_cost=ref)
 records.append(pair)
with (R/'reports/POSTHOC_REGRESSIONS.json').open('x') as f:json.dump({'scope':'Only describe the two observed worse tasks using saved traces; no parameter changes, repairs, re-initializations, searches, new schedule candidates or experimental calls.','findings':records,'interpretation':'Both schedules exhaust all three neighborhoods without improvement at their own terminal states; these losses are not end-of-budget operator starvation. Different accepted move paths are observed. This is a posthoc clue, not a controlled causal proof separating ordering and path dependence.','stopping_rule':'Close this transfer panel after independent review and private delivery; do not automatically develop new operator schedules on it.'},f,indent=2,ensure_ascii=False)
lines=['两项退化的事后保存轨迹说明','这部分仅描述本轮已经保存的trace，不构成新增主指标或机制因果证明；未调参、修复或重跑。','']
for p in records:
 lines.append(f"{p['instance_id']}：TRS {p['arms']['TRS']['cost']} → TSR {p['arms']['TSR']['cost']}，整数成本+{p['cost_difference_TSR_minus_TRS']}；gap +{p['gap_difference_pp']:.9f}个百分点。")
 for a,x in p['arms'].items():lines.append(f"  {a}：实际尝试{x['attempted']}/20000，{x['termination']}；接受2-opt/relocate/swap分别{x['counts']['two_opt']['accepted']}/{x['counts']['relocate']['accepted']}/{x['counts']['swap']['accepted']}。")
 lines.append('  两臂终止前均完整扫描了全部三算子，均无可接受改进；没有算子因候选上限被截断。TSR扫描了relocate，但没有接受relocate。')
 lines.append('')
lines+=['两题都从相同共享初始化开始，在首次共同2-opt改进后选择了不同的跨路线动作。保存轨迹显示后续接受路径不同并到达不同局部终点；因此不能将这两项退化归于最终预算耗尽、未轮到relocate。','这些是事后机制线索，不能独立确证哪一步导致终差，也不证明任何全局最优。主结论仍是冻结16任务的4改善、10持平、2退化及等权均差−4.004741个百分点。','本轮在独审与私有交付后关闭，不自动用此迁移面板继续开发另一套候选顺序。','']
with (R/'reports/POSTHOC_REGRESSIONS_ZH.txt').open('x') as f:f.write('\n'.join(lines))
