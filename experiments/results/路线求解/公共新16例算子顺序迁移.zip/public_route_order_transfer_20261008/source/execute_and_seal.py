"""One-shot experiment invocation; seal unreviewed raw even if supervisor fails."""
import sys,json,subprocess,datetime,hashlib,os
from pathlib import Path
R=Path(__file__).resolve().parents[1]
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if __name__=='__main__':
 # Check archive gates before marking the execution invocation.
 from run_once import gates
 gates()
 with (R/'raw/INVOCATION.json').open('x') as f:json.dump({'utc':now(),'no_retry':True},f)
 with (R/'raw/supervisor.stdout').open('xb') as out,(R/'raw/supervisor.stderr').open('xb') as err:
  proc=subprocess.Popen([sys.executable,'-B',str(R/'source/run_once.py')],stdout=out,stderr=err,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
  timeout=False
  try:proc.wait(timeout=250)
  except subprocess.TimeoutExpired:proc.kill();proc.wait();timeout=True
 with (R/'raw/SUPERVISOR_RETURN.json').open('x') as f:json.dump({'utc':now(),'returncode':proc.returncode,'outer_wall_timeout':timeout,'formal_started':(R/'raw/STARTED.json').exists(),'formal_finished':(R/'raw/FINISHED.json').exists()},f,indent=2)
 with (R/'raw/SEALED_RAW_MANIFEST.json').open('x') as f:json.dump({'utc':now(),'status':'UNREVIEWED_RAW_COMPLETE_OR_PARTIAL','files':{str(p.relative_to(R)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted((R/'raw').rglob('*')) if p.is_file() and p.name!='SEALED_RAW_MANIFEST.json'}},f,indent=2)
 subprocess.run([sys.executable,'-B',str(R/'source/package.py'),'RAW_UNREVIEWED'],check=True)
 print(json.dumps({'supervisor_returncode':proc.returncode,'raw_package_ready':True}))
