"""Postscore saved routes only after actual remote RAW readback. Never optimize."""
from pathlib import Path
import json,hashlib,csv,datetime
from check_saved import raw_data,validate
R=Path(__file__).resolve().parents[1];ARMS=('T','TRS','TSR');LEVELS=(0,100,1000,5000,10000,20000)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads((R/p).read_text())
def write(p,x):
 with (R/p).open('x') as f:json.dump(x,f,ensure_ascii=False,indent=2);f.write('\n')
def csvwrite(p,rows):
 keys=list(dict.fromkeys(k for r in rows for k in r))
 with (R/p).open('x') as f:w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)
def main():
 receipt=read('provenance/RAW_UNREVIEWED_DRIVE_RECEIPT.json')
 assert receipt['owner_only'] and receipt['shared'] is False and receipt['remote_readback_sha256_verified'] and receipt['download_byte_identical']
 assert receipt['sha256']==receipt['download_sha256']==sha(R.parent/(R.name+'_RAW_UNREVIEWED.zip'))==sha(Path(receipt['download_path']))
 for manifest in ('freeze/FROZEN_FILES.json','raw/SEALED_RAW_MANIFEST.json'):
  assert all(sha(R/p)==v['sha256'] for p,v in read(manifest)['files'].items())
 tasks=read('freeze/TASKS.json');schedule=read('freeze/SCHEDULE.json')
 records=[json.loads(s) for s in (R/'raw/results.jsonl').read_text().splitlines()] if (R/'raw/results.jsonl').exists() else []
 byid={r['call_id']:r for r in records};assert len(byid)==len(records)
 rows=[];curves=[];paired=[];initializations=[]
 for task in tasks:
  name=task['instance_id'];slot=task['selection_slot'];K=task['K'];d,dem,q,_=raw_data(R/'input'/f'{name}.vrp');ref=read(f'references/{name}.json')
  rr=validate([[0]+r+[0] for r in ref['reference_routes']],dem,q,K,d);assert rr['cost']==ref['reference_integer_cost']
  refcost=rr['cost'];baseline=None;initmeta=byid.get(f'I{slot:02}')
  initializations.append({'instance_id':name,'selection_slot':slot,'status':initmeta['status'] if initmeta else 'NOT_REACHED','budget':None if not initmeta else initmeta.get('budget')})
  if initmeta and initmeta['status']=='SUCCESS':
   base=read(f'raw/baselines/{name}.json');baseline=validate(base['routes'],dem,q,K,d)
  arms={}
  for arm in ARMS:
   cid=f'S{slot:02}_{arm}';meta=byid.get(cid);row={'instance_id':name,'selection_slot':slot,'call_id':cid,'arm':arm,'status':meta['status'] if meta else 'NOT_REACHED','cost':None,'reference_cost':refcost,'reference_gap_percent':None}
   result=None
   if meta and meta['status']=='SUCCESS':
    assert baseline is not None and sha(R/meta['stdout'])==meta['stdout_sha256']
    result=read(meta['stdout']);chk=validate(result['routes'],dem,q,K,d)
    assert chk['cost']==result['cost']<=result['initial_cost']==baseline['cost']
    row.update({k:result[k] for k in ('cost','initial_cost','attempted','feasible','accepted','termination','unspent_budget')})
    row.update(reference_gap_percent=100*(row['cost']/refcost-1),K_slots=K,nonempty_routes=chk['nonempty_routes'],process_cpu_seconds_for_audit_only=meta['process_cpu_seconds_for_audit_only'],process_wall_seconds_for_audit_only=meta['process_wall_seconds_for_audit_only'])
    for op in ('two_opt','relocate','swap'):
     counts=result['counts'].get(op,{'attempted':0,'feasible':0,'accepted':0});scans=[s for s in result['scans'] if s['op']==op]
     for k,v in counts.items():row[op+'_'+k]=v
     row[op+'_first_scan_after_attempts']=scans[0]['start_attempted'] if scans else None
     row[op+'_first_candidate_attempt_1based']=next((i+1 for i,t in enumerate(result['trace']) if t[0]==op),None)
   for level in LEVELS:
    known=bool(result and (result['attempted']>=level or result['termination']=='LOCAL_OPTIMUM'))
    moves=[m for m in result['accepted_moves'] if m['attempted']<=level] if result else []
    cost=(moves[-1]['cost'] if moves else baseline['cost']) if known else None
    curves.append({'instance_id':name,'arm':arm,'budget_node':level,'cost':cost,'actual_attempted_to_terminal':result['attempted'] if result else None,'carried_after_LOCAL_OPTIMUM':bool(result and level>result['attempted'] and result['termination']=='LOCAL_OPTIMUM')})
   rows.append(row);arms[arm]=row
  valid=all(arms[a]['cost'] is not None for a in ('TRS','TSR'));delta=arms['TSR']['cost']-arms['TRS']['cost'] if valid else None
  paired.append({'instance_id':name,'selection_slot':slot,'TRS_cost':arms['TRS']['cost'],'TSR_cost':arms['TSR']['cost'],'TSR_minus_TRS_cost':delta,'TSR_minus_TRS_gap_percentage_points':100*delta/refcost if valid else None,'outcome':'improved' if valid and delta<0 else 'worse' if valid and delta>0 else 'equal' if valid else 'unavailable'})
 valid=[r for r in paired if r['TSR_minus_TRS_cost'] is not None]
 primary={'contrast':'TSR minus TRS; negative favors TSR','valid_pairs':len(valid),'mean_gap_difference_percentage_points_all16':sum(r['TSR_minus_TRS_gap_percentage_points'] for r in valid)/16 if len(valid)==16 else None,'descriptive_available_pair_mean_gap_difference_pp':sum(r['TSR_minus_TRS_gap_percentage_points'] for r in valid)/len(valid) if valid else None,'descriptive_denominator':len(valid),'improved':sum(r['outcome']=='improved' for r in paired),'equal':sum(r['outcome']=='equal' for r in paired),'worse':sum(r['outcome']=='worse' for r in paired),'unavailable':16-len(valid)}
 armstats={}
 for arm in ARMS:
  good=[r for r in rows if r['arm']==arm and r['cost'] is not None]
  armstats[arm]={'valid_tasks':len(good),'mean_reference_gap_percent_all16':sum(r['reference_gap_percent'] for r in good)/16 if len(good)==16 else None,'descriptive_available_mean_gap_percent':sum(r['reference_gap_percent'] for r in good)/len(good) if good else None,'descriptive_denominator':len(good),'attempted':sum(r['attempted'] for r in good),'feasible':sum(r['feasible'] for r in good),'accepted':sum(r['accepted'] for r in good),'LOCAL_OPTIMUM':sum(r['termination']=='LOCAL_OPTIMUM' for r in good),'BUDGET_EXHAUSTED':sum(r['termination']=='BUDGET_EXHAUSTED' for r in good),'operator_counts':{op:{k:sum(r[op+'_'+k] for r in good) for k in ('attempted','feasible','accepted')} for op in ('two_opt','relocate','swap')}}
 cm={(r['instance_id'],r['arm'],r['budget_node']):r['cost'] for r in curves};secondary=[]
 for level in LEVELS:
  pairs=[]
  for task in tasks:
   name=task['instance_id'];a=cm[(name,'TSR',level)];b=cm[(name,'TRS',level)]
   if a is not None and b is not None:pairs.append(100*(a-b)/read(f'references/{name}.json')['reference_integer_cost'])
  secondary.append({'budget_node':level,'valid_pairs':len(pairs),'mean_gap_difference_percentage_points_all16':sum(pairs)/16 if len(pairs)==16 else None})
 changed=[p for p,v in read('freeze/OLD_FILES_BEFORE.json').items() if not Path(p).is_file() or sha(Path(p))!=v['sha256']];assert not changed
 summary={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stage':'PUBLIC_TRANSFER_NOT_STRICT_BLIND_OR_PREREGISTERED','tasks':16,'distinct_coordinate_demand_bases':16,'historical_excluded_named_tasks':25,'independent_review':'PENDING','primary':primary,'arms':armstats,'secondary_all_nodes':secondary,'formal_initialization_processes':sum(r['kind']=='initialize' and r.get('process_spawned',False) for r in records),'formal_search_processes':sum(r['kind']=='search' and r.get('process_spawned',False) for r in records),'planned_slots_retained':64,'observed_record_slots':len(records),'old_files_unchanged':True,'limitations':read('freeze/PROTOCOL.json')['limitations']}
 write('reports/SUMMARY.json',summary);write('reports/INITIALIZATIONS.json',initializations);csvwrite('reports/PER_CALL.csv',rows);csvwrite('reports/PAIRED_TSR_MINUS_TRS.csv',paired);csvwrite('reports/FIXED_BUDGET_TRAJECTORIES.csv',curves)
 fmt=lambda v:'不可用' if v is None else f'{v:.9f}'
 lines=['公共CVRPLIB迁移复核：固定T/TRS/TSR顺序','独立结果审查：待完成。','新16任务、16坐标需求底本，A6/B6/P4；与全部旧25名的23底本无指纹重合。','基于元数据冻结选择；未按表现换题。范围仅本A/B/P面板与固定初始化pipeline。','这不是严格盲测，也不是预注册确认性研究；是未用于本轮算子顺序选择的公开迁移面板。','',f"主指标TSR−TRS：16任务等权gap差{fmt(primary['mean_gap_difference_percentage_points_all16'])}个百分点；改善{primary['improved']}、持平{primary['equal']}、退化{primary['worse']}、不可用{primary['unavailable']}。",f"实际唯一调用：初始化{summary['formal_initialization_processes']}/16，共享给每任务3臂；搜索{summary['formal_search_processes']}/48。"]
 for a,s in armstats.items():lines.append(f"{a}：{s['valid_tasks']}/16有效；全16平均gap {fmt(s['mean_reference_gap_percent_all16'])}%；候选{s['attempted']}，可行{s['feasible']}，接受{s['accepted']}；局部终止{s['LOCAL_OPTIMUM']}，预算终止{s['BUDGET_EXHAUSTED']}。")
 lines+=['','逐任务TSR−TRS：']+[f"{r['instance_id']}：{r['TRS_cost']} → {r['TSR_cost']}，差{fmt(r['TSR_minus_TRS_gap_percentage_points'])}个百分点，{r['outcome']}。" for r in paired]
 lines+=['','全部固定候选节点：']+[f"{r['budget_node']}：{fmt(r['mean_gap_difference_percentage_points_all16'])}个百分点；有效{r['valid_pairs']}/16。" for r in secondary]
 lines+=['','T仅描述基线；没有再调参、增算子、换样、重跑或模型调用。','初始化采用连续欧氏，优化/评分采用原EUC_2D整数边长；两个阶段完整列入pipeline与预算披露。','同20000候选上限不是等实际工作量或等CPU；不可推断速度、全局最优或普遍算法优势。','指纹排重覆盖原坐标需求及客户编号/平移变化，不声称旋转、反射、缩放或一般图同构。','旧9原normalized SHA及原.vrp恢复9/9通过；此次重取.vrp与历史原字节一致。','reference用于合法性验证及定义K_ref，路线与cost不供初始化/搜索；raw私有回读后才末评分。','旧证据文件哈希不变；完整失败记录、原始候选、初始路线、终止原因与资源记账均保留。','']
 with (R/'reports/REPORT_ZH.txt').open('x') as f:f.write('\n'.join(lines))
 print(json.dumps({'primary':primary,'arms':armstats},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
