"""Independent arithmetic-only audit. Never imports project code or invokes solvers.
Exact Fraction arithmetic validates rounding without sharing the production parser.
"""
import ast, collections, datetime, hashlib, json, math, re
from fractions import Fraction as F
from html.parser import HTMLParser
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=Path(__file__).resolve().parent

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def readj(p): return json.loads(p.read_text())
def digest(x): return hashlib.sha256(json.dumps(x,separators=(',',':'),sort_keys=True).encode()).hexdigest()
def frac(x): return F(str(x))
def canon(x): return str(frac(x))

def parse_vrp_text(text):
    headers={}; coords={}; demands={}; depots=[]; mode=None; saw_eof=False; depot_end=False
    for line in text.splitlines():
        line=line.strip()
        if not line: continue
        if line=='EOF': saw_eof=True; break
        if line.endswith('_SECTION'):
            assert line in ('NODE_COORD_SECTION','DEMAND_SECTION','DEPOT_SECTION'),line
            mode=line; continue
        if mode=='NODE_COORD_SECTION':
            fields=line.split(); assert len(fields)==3
            node=int(fields[0]); assert node not in coords
            coords[node]=(frac(fields[1]),frac(fields[2]))
        elif mode=='DEMAND_SECTION':
            fields=line.split(); assert len(fields)==2
            node=int(fields[0]); assert node not in demands
            demands[node]=int(fields[1])
        elif mode=='DEPOT_SECTION':
            for field in line.split():
                n=int(field)
                if n==-1: depot_end=True
                else:
                    assert not depot_end
                    depots.append(n)
        else:
            k,v=line.split(':',1); k=k.strip(); assert k not in headers
            headers[k]=v.strip()
    assert saw_eof and depot_end and len(depots)==1
    assert headers['TYPE']=='CVRP' and headers['EDGE_WEIGHT_TYPE']=='EUC_2D'
    assert len(coords)==len(demands)==int(headers['DIMENSION'])
    assert coords.keys()==demands.keys() and depots[0] in coords
    q=int(headers['CAPACITY']); assert q>0
    assert demands[depots[0]]==0 and all(0<=v<=q for v in demands.values())
    order=[depots[0]]+sorted(set(coords)-set(depots))
    return {'name':headers['NAME'],'xy':[coords[i] for i in order],'demand':[demands[i] for i in order],'Q':q,'source_ids':order}

def parse_vrp(p): return parse_vrp_text(p.read_text(encoding='utf-8-sig'))

def fingerprints(x):
    xy=x['xy']; ds=x['demand']; dx,dy=xy[0]
    # The invariant is a multiset, hence counts are retained, not reduced to a set.
    base=sorted([(a-dx,b-dy,d) for (a,b),d in zip(xy[1:],ds[1:])])
    exact=[(a,b,d) for (a,b),d in zip(xy,ds)]
    return {'ordered_exact':digest([[canon(a),canon(b),d] for a,b,d in exact]),
            'translation_and_renumbering_invariant':digest([[canon(a),canon(b),d] for a,b,d in base])}

def rounded_edge(a,b):
    sq=(a[0]-b[0])**2+(a[1]-b[1])**2
    floor=math.isqrt(sq.numerator//sq.denominator)
    return floor+int(4*sq.numerator>=sq.denominator*(2*floor+1)**2)

def read_reference(p,x):
    routes=[]; claimed=None
    for line in p.read_text().splitlines():
        line=line.strip()
        if not line:continue
        match=re.fullmatch(r'Route\s+#(\d+):\s*(.*)',line)
        if match:
            assert int(match[1])==len(routes)+1
            r=[int(z) for z in match[2].split()];assert r
            routes.append(r)
        else:
            match=re.fullmatch(r'Cost\s+(\d+(?:\.\d+)?)',line); assert match and claimed is None,line
            claimed=frac(match[1])
    assert claimed is not None and routes
    assert collections.Counter(n for r in routes for n in r)==collections.Counter(range(1,len(x['xy'])))
    loads=[sum(x['demand'][i] for i in r) for r in routes]; assert max(loads)<=x['Q']
    total=sum(rounded_edge(x['xy'][i],x['xy'][j]) for r in routes for i,j in zip([0]+r,r+[0]))
    assert total==claimed,(p,total,claimed)
    return {'K_ref':len(routes),'cost':total,'loads':loads,'routes':routes,'coverage_capacity_cost_valid':True}

class Rows(HTMLParser):
    def __init__(self):super().__init__();self.rows=[];self.row=None;self.cell=None
    def handle_starttag(self,tag,attrs):
        if tag=='tr':self.row=[]
        elif tag=='td' and self.row is not None:self.cell={'text':'','links':[]}
        elif tag=='a' and self.cell is not None:
            href=dict(attrs).get('href')
            if href:self.cell['links'].append(href)
    def handle_data(self,data):
        if self.cell is not None:self.cell['text']+=data
    def handle_endtag(self,tag):
        if tag=='td' and self.cell is not None:self.row.append(self.cell);self.cell=None
        elif tag=='tr' and self.row is not None:self.rows.append(self.row);self.row=None

def reconstruct_catalog(p):
    h=Rows(); h.feed(p.read_text()); rows=[]
    for row in h.rows:
        if not row: continue
        name=row[0]['text'].strip(); m=re.fullmatch(r'([ABEFP])-n(\d+)-k(\d+)',name)
        if not m:continue
        family,n,k=m.groups();customers=int(row[1]['text'].strip().strip('$'))
        assert customers==int(n)-1
        urls=row[0]['links']+[z for c in row[1:] for z in c['links']]
        instance=[u for u in urls if '/download/instance/' in u]; ref=[u for u in urls if '/download/bks/' in u]
        assert len(instance)==len(ref)==1
        rows.append({'name':name,'family':family,'n_customers':customers,'filename_k':int(k),
                     'instance_url':'https://galgos.inf.puc-rio.br'+instance[0],
                     'solution_url':'https://galgos.inf.puc-rio.br'+ref[0]})
    assert len(rows)==len({r['name'] for r in rows})
    return rows

def fixture_tests():
    a={'xy':[(F('1.5'),F('-2.5')),(F('2'),F('3')),(F('4.25'),F('1.5'))], 'demand':[0,2,3],'Q':9}
    translated={'xy':[(x+10,y-5) for x,y in a['xy']], 'demand':a['demand'],'Q':99}
    reordered={'xy':[translated['xy'][0],translated['xy'][2],translated['xy'][1]],'demand':[0,3,2],'Q':99}
    key='translation_and_renumbering_invariant'
    assert fingerprints(a)[key]==fingerprints(translated)[key]==fingerprints(reordered)[key]
    assert fingerprints(a)['ordered_exact']!=fingerprints(translated)['ordered_exact']
    changed=dict(a,demand=[0,3,2]); assert fingerprints(a)[key]!=fingerprints(changed)[key]
    reflected=dict(a,xy=[(-x,y) for x,y in a['xy']]); assert fingerprints(a)[key]!=fingerprints(reflected)[key]
    for number,expected in [('0.499999999',0),('0.5',1),('1.5',2),('2.499999',2),('2.5',3)]:
        assert rounded_edge((F(0),F(0)),(F(number),F(0)))==expected
    assert rounded_edge((F(0),F(0)),(F(3),F(4)))==5
    fixture='''NAME : fixture\nTYPE : CVRP\nDIMENSION : 3\nCAPACITY : 9\nEDGE_WEIGHT_TYPE : EUC_2D\nNODE_COORD_SECTION\n40 1.5 -2.5\n30 4.25 1.5\n20 2 3\nDEMAND_SECTION\n40 0\n30 3\n20 2\nDEPOT_SECTION\n40\n-1\nEOF\n'''
    p=parse_vrp_text(fixture);assert fingerprints(a)==fingerprints(p)
    return {'translation_renumbering_capacity_ignored':True,'demand_change_detected':True,'reflection_not_treated_equivalent':True,'exact_rounding_boundaries':True,'arbitrary_node_ids_and_depot':True}

def main():
    checks=[]; details={}; failures=[]
    def run(label,fn):
        try: details[label]=fn();checks.append({'check':label,'pass':True})
        except Exception as e:failures.append({'check':label,'error':repr(e)});checks.append({'check':label,'pass':False})
    rule=readj(ROOT/'freeze/SELECTION_RULE.json'); selected=readj(ROOT/'freeze/SELECTED_PANEL.json'); hist=readj(ROOT/'freeze/HISTORICAL_EXCLUSIONS.json')
    run('independent_synthetic_fixtures',fixture_tests)
    def selection():
        catalog=reconstruct_catalog(ROOT/'provenance/cvrplib_catalog.html')
        assert catalog==readj(ROOT/'provenance/catalog_ABEFP.json')
        assert sha(ROOT/'provenance/cvrplib_catalog.html')==rule['catalog_sha256']
        expected_old9={'A-n32-k5','B-n31-k5','P-n40-k5','A-n33-k5','A-n33-k6','B-n34-k5','B-n35-k5','P-n45-k5','P-n50-k10'}
        assert {r['name'] for r in hist['old9']}==expected_old9
        prior16=readj(ROOT.parent/'public_capacity_benchmark_preparation_20261008/freeze/SELECTED_PANEL.json')
        assert {r['name'] for r in hist['old16']}=={r['name'] for r in prior16}
        exclusions={r['name'] for r in hist['old9']+hist['old16']}
        assert len(exclusions)==25 and exclusions==set(rule['prior_name_exclusions'])
        chosen=[];decisions=[]
        assert rule['targets']=={'A':[35,40,45,50,60,70],'B':[35,40,45,50,60,70],'P':[18,21,55,70]}
        for family in ('A','B','P'):
            for target in rule['targets'][family]:
                pool=[r for r in catalog if r['family']==family and 12<=r['n_customers']<=80 and r['name'] not in exclusions and all((r['family'],r['n_customers'])!=(z['family'],z['n_customers']) for z in chosen)]
                pool.sort(key=lambda x:(abs(x['n_customers']-target),x['n_customers'],x['filename_k'],x['name']))
                chosen.append(dict(pool[0],target_n_customers=target,selection_slot=len(chosen)+1))
                decisions.append({'family':family,'target':target,'ranked_names':[z['name'] for z in pool],'chosen':pool[0]['name']})
        assert chosen==selected and decisions==readj(ROOT/'freeze/SELECTION_DECISIONS.json')
        assert rule['no_replacements'] is True
        return {'catalog_rows':len(catalog),'historical_name_exclusions':25,'selected':[r['name'] for r in chosen],'frozen_decisions_exact':True}
    run('metadata_selection_and_all25_exclusions',selection)
    def acquisition():
        plan=readj(ROOT/'freeze/RETRIEVAL_PLAN.json');records=[json.loads(s) for s in (ROOT/'provenance/ACQUISITION.jsonl').read_text().splitlines()]
        assert len(records)==len(plan['jobs'])==41 and len({r['path'] for r in records})==41
        assert collections.Counter((r['name'],r['kind'],r['url'],r['path']) for r in records)==collections.Counter((r['name'],r['kind'],r['url'],r['path']) for r in plan['jobs'])
        start=readj(ROOT/'provenance/ACQUISITION_STARTED.json')
        assert start['plan_sha256']==sha(ROOT/'freeze/RETRIEVAL_PLAN.json')
        assert start['selection_sha256']==sha(ROOT/'freeze/SELECTED_PANEL.json')
        assert rule['created_utc']<start['created_utc']<=min(r['started_utc'] for r in records)
        for r in records:
            assert r['attempt']==1 and r['success'] and r['status']==200
            assert r['sha256']==sha(ROOT/r['path']) and r['bytes']==(ROOT/r['path']).stat().st_size
        return {'one_record_per_planned_get':True,'attempts':41,'all_raw_sha_verified':True,'freeze_precedes_acquisition':True}
    run('acquisition_and_predata_freeze',acquisition)
    historical=[]
    def bases():
        for r in hist['old9']+hist['old16']:
            path=ROOT/r['copy'] if 'copy'in r else ROOT/'raw/exclusions'/f"{r['name']}.vrp"
            x=parse_vrp(path);assert x['name']==r['name']
            if 'copy'in r:assert sha(path)==r['sha256']==sha(Path(r['source']))
            historical.append({'name':r['name'],'fingerprints':fingerprints(x),'raw_sha256':sha(path)})
        newest=[]
        for row in selected:
            p=ROOT/'raw/instances'/f"{row['name']}.vrp"; x=parse_vrp(p); assert x['name']==row['name']
            fp=fingerprints(x);hits=[h['name'] for h in historical+newest if any(fp[k]==h['fingerprints'][k] for k in fp)]
            assert not hits,(row['name'],hits)
            newest.append({'name':row['name'],'fingerprints':fp,'historical_or_earlier_duplicate_hits':hits,'raw_sha256':sha(p)})
        groups=collections.defaultdict(list)
        for h in historical: groups[h['fingerprints']['translation_and_renumbering_invariant']].append(h['name'])
        return {'historical':historical,'new_panel':newest,'historical_unique_invariant_bases':len(groups),'historical_duplicate_groups':[v for v in groups.values() if len(v)>1],'scope':'Exact coordinate-demand multisets relative to depot. Translation and customer renumbering only; rotation, reflection, scaling, or general isomorphism are outside scope.'}
    run('raw_parse_and_base_deduplication',bases)
    def references():
        results=[]
        for r in selected:
            name=r['name'];x=parse_vrp(ROOT/'raw/instances'/f'{name}.vrp'); ref=read_reference(ROOT/'raw/references'/f'{name}.sol',x)
            assert len(x['demand'])-1==r['n_customers']
            normalized=readj(ROOT/'normalized'/f'{name}.json'); witness=readj(ROOT/'witness'/f'{name}.json')
            assert normalized['coordinates']==[[float(a),float(b)] for a,b in x['xy']]
            assert normalized['demands']==x['demand'] and normalized['capacity']==x['Q'] and normalized['K']==ref['K_ref']
            assert set(normalized)=={'instance_id','selection_slot','coordinates','demands','capacity','K','problem_definition','K_basis'}
            assert witness['reference_routes']==ref['routes'] and witness['reference_integer_cost']==ref['cost'] and witness['K_ref']==ref['K_ref']
            results.append({'name':name,'n_customers':r['n_customers'],'capacity':x['Q'],'K_ref':ref['K_ref'],'filename_k_for_comparison_only':r['filename_k'],'rounded_reference_cost':ref['cost'],'loads':ref['loads'],'coverage_capacity_cost_valid':True,'normalized_has_no_routes_or_costs':True})
        return results
    run('reference_arithmetic_Kref_and_clean_inputs',references)
    original_missing=[]
    def identities():
        records=[]
        for r in hist['old9']:
            p=ROOT/'provenance/recovered_old9'/f"{r['name']}.instance.json"
            if not p.exists():
                p=Path(r['input_path'])
            if not p.exists():
                original_missing.append(r['name']);records.append({'name':r['name'],'verified':False,'reason':'recorded normalized source file absent'});continue
            assert sha(p)==r['input_sha256']
            oldvrp=ROOT/'provenance/recovered_old9'/f"{r['name']}.vrp"
            assert oldvrp.read_bytes()==(ROOT/'raw/exclusions'/f"{r['name']}.vrp").read_bytes()
            raw=readj(p);current=parse_vrp(ROOT/'raw/exclusions'/f"{r['name']}.vrp")
            # Support original normalized format, never regenerate bytes to claim original SHA equality.
            assert raw['demands']==current['demand'] and raw['capacity']==current['Q']
            assert [[frac(v) for v in xy] for xy in raw['coordinates']]==[list(xy) for xy in current['xy']]
            records.append({'name':r['name'],'verified':True,'original_normalized_sha256':sha(p),'recovered_vrp_coordinates_demands_capacity_match':True,'recovered_original_vrp_byte_identical_to_current_get':True})
        return records
    run('original_old9_normalized_identities',identities)
    source_paths=[ROOT/'source/freeze_selection.py',ROOT/'source/acquire_frozen.py',ROOT/'source/validate_data.py',ROOT.parent/'public_route_operator_order_20261008/source/engine.py',ROOT.parent/'public_capacity_benchmark_execution_20261008_r1/source/capacity_solver.py',ROOT.parent/'public_capacity_benchmark_execution_20261008_r1/source/legacy/experiment.py']
    details['static_source_sha256']=[{'path':str(p),'sha256':sha(p),'syntax_valid':bool(ast.parse(p.read_text()))} for p in source_paths]
    summary={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'audit_script_sha256':sha(Path(__file__)),'audit_type':'independent parsing and arithmetic only; no initializer/search imports or invocations','checks':checks,'failures':failures,'all_arithmetic_and_selection_checks_pass':not failures,'old9_original_normalized_identity_missing':original_missing,'data_ready_for_formal_gate':not failures and not original_missing,'formal_execution_audited':False,'initialization_calls':0,'search_calls':0,'model_calls':0,'details':details}
    (OUT/'DATA_AUDIT.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps({k:v for k,v in summary.items() if k!='details'},indent=2))
if __name__=='__main__':main()
