"""Strict arithmetic/metadata verification only; no solver modules imported."""
from pathlib import Path
from decimal import Decimal,localcontext,ROUND_HALF_UP
from collections import Counter,defaultdict
import json,re,hashlib,datetime
R=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):
 with (R/p).open('x') as f:json.dump(x,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')
def canon(x):
 d=Decimal(str(x));return '0' if not d else format(d.normalize(),'f')
def fp(xy,demands):
 ordered=[[canon(v) for v in pair] for pair in xy]
 dep=xy[0]
 rel=sorted([[canon(x-dep[0]),canon(y-dep[1]),int(d)] for (x,y),d in zip(xy[1:],demands[1:])])
 digest=lambda x:hashlib.sha256(json.dumps(x,separators=(',',':')).encode()).hexdigest()
 return {'ordered_exact':digest([ordered,demands]),'translation_and_renumbering_invariant':digest(rel)}
def parse_instance(p):
 meta={};xy={};d={};depot=[];section=None;eof=False
 for line in p.read_text(encoding='utf-8-sig').splitlines():
  line=line.strip()
  if not line:continue
  if line=='EOF':eof=True;break
  if line.endswith('_SECTION'):
   assert line in ['NODE_COORD_SECTION','DEMAND_SECTION','DEPOT_SECTION'],line
   section=line;continue
  if section=='NODE_COORD_SECTION':
   a=line.split();assert len(a)==3;i=int(a[0]);assert i not in xy
   xy[i]=[Decimal(a[1]),Decimal(a[2])];assert all(z.is_finite() for z in xy[i])
  elif section=='DEMAND_SECTION':
   a=line.split();assert len(a)==2;i=int(a[0]);assert i not in d;d[i]=int(a[1])
  elif section=='DEPOT_SECTION':depot.extend(int(t) for t in line.split() if int(t)!=-1)
  else:
   a=line.split(':',1);assert len(a)==2;a=[s.strip() for s in a];assert a[0] not in meta;meta[a[0]]=a[1]
 assert meta['TYPE']=='CVRP' and meta['EDGE_WEIGHT_TYPE']=='EUC_2D'
 n=int(meta['DIMENSION']);q=int(meta['CAPACITY'])
 assert q>0 and set(xy)==set(d)==set(range(1,n+1)) and depot==[1] and d[1]==0 and eof
 assert all(0<=v<=q for v in d.values())
 return meta,[xy[i] for i in range(1,n+1)],[d[i] for i in range(1,n+1)]
def parse_sol(p):
 routes=[];nums=[];cost=None
 for line in p.read_text(encoding='utf-8-sig').splitlines():
  line=line.strip()
  if not line:continue
  m=re.fullmatch(r'Route\s+#(\d+):\s*(.*)',line)
  if m:nums.append(int(m[1]));routes.append([int(t) for t in m[2].split()]);continue
  m=re.fullmatch(r'Cost\s+([0-9]+(?:\.[0-9]+)?)',line)
  if m:assert cost is None;cost=Decimal(m[1]);continue
  raise ValueError('unknown reference line '+line)
 assert routes and all(routes) and nums==list(range(1,len(routes)+1)) and cost is not None
 return routes,cost
def refcheck(xy,ds,q,routes,claimed):
 assert Counter(c for r in routes for c in r)==Counter(range(1,len(ds)))
 loads=[sum(ds[c] for c in r) for r in routes];assert max(loads)<=q
 with localcontext() as ctx:
  ctx.prec=80
  val=sum(int(((xy[a][0]-xy[b][0])**2+(xy[a][1]-xy[b][1])**2).sqrt().to_integral_value(rounding=ROUND_HALF_UP)) for r in routes for a,b in zip([0]+r,r+[0]))
 assert Decimal(val)==claimed,(val,claimed)
 return {'reference_routes':routes,'loads':loads,'reference_integer_cost':val,'K_ref':len(routes),'coverage_and_capacity_valid':True}
def main():
 hist=json.loads((R/'freeze/HISTORICAL_EXCLUSIONS.json').read_text());old=[];index=defaultdict(list)
 for row in hist['old16']+hist['old9']:
  name=row['name'];p=R/row['copy'] if 'copy' in row else R/'raw/exclusions'/f'{name}.vrp'
  rec={'name':name,'source':str(p.relative_to(R)),'historical_normalized_sha256':row.get('input_sha256'),'original_normalized_byte_identity':'unverified' if 'copy' not in row else 'not applicable; verified copied official vrp bytes'}
  try:
   meta,xy,ds=parse_instance(p);assert meta['NAME']==name
   rec.update(valid=True,raw_sha256=sha(p),fingerprints=fp(xy,ds))
   for k,v in rec['fingerprints'].items():index[(k,v)].append(name)
  except Exception as e:rec.update(valid=False,error=type(e).__name__+': '+str(e))
  old.append(rec)
 write('reports/HISTORICAL_FINGERPRINTS.json',old)
 historical_complete=all(x['valid'] for x in old)
 seen=defaultdict(list);out=[]
 for row in json.loads((R/'freeze/SELECTED_PANEL.json').read_text()):
  name=row['name'];rec={'name':name,'selection_slot':row['selection_slot'],'eligible':False,'errors':[]}
  try:
   p=R/'raw/instances'/f'{name}.vrp';s=R/'raw/references'/f'{name}.sol'
   meta,xy,ds=parse_instance(p);assert meta['NAME']==name and len(ds)-1==row['n_customers']
   hashes=fp(xy,ds);hits=sorted(set(n for k,v in hashes.items() for n in index.get((k,v),[])));internal=sorted(set(n for k,v in hashes.items() for n in seen.get((k,v),[])))
   for k,v in hashes.items():seen[(k,v)].append(name)
   rec.update(instance_valid=True,fingerprints=hashes,historical_duplicate_names=hits,earlier_panel_duplicate_names=internal,source_instance_sha256=sha(p))
   routes,claimed=parse_sol(s);reference=refcheck(xy,ds,int(meta['CAPACITY']),routes,claimed)
   rec.update(reference_valid=True,source_reference_sha256=sha(s),n_customers=len(ds)-1,Q=int(meta['CAPACITY']),K_ref=reference['K_ref'])
   if hits or internal:rec['errors'].append('coordinate-demand base overlaps history or earlier selected slot')
   if not historical_complete:rec['errors'].append('historical exclusion data incomplete; novelty unverified')
   rec['eligible']=not rec['errors']
   # Reference route/cost stored separately. Search input receives only task K.
   normalized={'instance_id':name,'selection_slot':row['selection_slot'],'coordinates':[[float(x),float(y)] for x,y in xy],'demands':ds,'capacity':int(meta['CAPACITY']),'K':reference['K_ref'],'problem_definition':'fixed K_ref slots; at most K_ref nonempty routes; continuous-Euclidean initializer followed by rounded EUC_2D local search','K_basis':'independently validated reference nonempty route count, no witness search guidance'}
   write(f'normalized/{name}.json',normalized);write(f'witness/{name}.json',dict(reference,source_instance_id=name,reference_url=row['solution_url'],not_available_to_search=True))
  except Exception as e:rec['errors'].append(type(e).__name__+': '+str(e))
  out.append(rec)
 write('reports/PANEL_VALIDATION.json',out)
 write('reports/VALIDATION_SUMMARY.json',{'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'selected':16,'eligible':sum(x['eligible'] for x in out),'historical_exclusions_parsed':sum(x['valid'] for x in old),'historical_exclusions_complete':historical_complete,'old9_original_normalized_bytes_verified':False,'all_primary_slots_preserved':True,'formal_init_calls':0,'formal_search_calls':0,'model_calls':0,'failures':[x for x in out if not x['eligible']]})
 print(json.dumps({'eligible':sum(x['eligible'] for x in out),'old_valid':sum(x['valid'] for x in old),'failures':[x for x in out if not x['eligible']]},indent=2))
if __name__=='__main__':main()
