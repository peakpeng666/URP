"""One-shot public GETs only. No experiment calls, models, credentials or dependencies."""
import urllib.request,hashlib,json,datetime,concurrent.futures,threading
from pathlib import Path
R=Path(__file__).resolve().parents[1];lock=threading.Lock()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
planpath=R/'freeze/RETRIEVAL_PLAN.json';plan=json.loads(planpath.read_text())
with (R/'provenance/ACQUISITION_STARTED.json').open('x') as f:json.dump({'created_utc':now(),'plan_sha256':hashlib.sha256(planpath.read_bytes()).hexdigest(),'selection_sha256':hashlib.sha256((R/'freeze/SELECTED_PANEL.json').read_bytes()).hexdigest()},f,indent=2)
def fetch(job):
 r=dict(job,started_utc=now(),method='GET',authentication='none',attempt=1)
 try:
  req=urllib.request.Request(job['url'],headers={'User-Agent':'Academic CVRP data verification; read-only','Accept-Encoding':'identity'})
  with urllib.request.urlopen(req,timeout=60) as h:
   b=h.read(2097153)
   if len(b)>2097152:raise ValueError('over 2MiB response limit')
   if h.url.split('/')[2]!='galgos.inf.puc-rio.br':raise ValueError('unexpected redirect domain')
   r.update(status=h.status,url_final=h.url,content_type=h.headers.get('Content-Type'),http_date=h.headers.get('Date'),last_modified=h.headers.get('Last-Modified'),etag=h.headers.get('ETag'),content_length=h.headers.get('Content-Length'))
  with (R/job['path']).open('xb') as f:f.write(b)
  r.update(success=True,bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
 except Exception as e:r.update(success=False,error_type=type(e).__name__,error=str(e))
 r['finished_utc']=now()
 with lock:
  with (R/'provenance/ACQUISITION.jsonl').open('a') as f:f.write(json.dumps(r)+'\n')
 print(r['name'],r['kind'],r['success'],flush=True)
 return r
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:records=list(pool.map(fetch,plan['jobs']))
with (R/'reports/ACQUISITION_SUMMARY.json').open('x') as f:json.dump({'completed_utc':now(),'attempts':len(records),'success':sum(x['success'] for x in records),'failures':[x for x in records if not x['success']],'initializer_calls':0,'search_calls':0},f,indent=2)
