"""Recover only historical data members and verify established normalized hashes."""
from pathlib import Path
import tarfile,json,hashlib,datetime,sys
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'source'))
from validate_data import parse_instance,fp
prior=json.loads((R/'provenance/PRIOR_NINE_SOURCE.json').read_text())['records'];records=[];archives=[]
pairs=[('/workspace/scratch/27470b7a9f17/attachments/4f51d40a-d423-4fb2-9e67-ec10e67181ad/官方CVRP三实例_数据准备快照_20261008.tar.gz','1Plx6xg-QiKvKjZA5oeZy0WvwH-GWuADL'),('/workspace/scratch/27470b7a9f17/attachments/11ba550c-d5a0-4065-8549-cceb48cb39b6/新增6官方CVRP实例_冻结数据准备_20261008.tar.gz','175EFBU01a2DnWA6IEIDP1w2hCkqHQO8S')]
sha=lambda b:hashlib.sha256(b).hexdigest()
for path,driveid in pairs:
 p=Path(path);archives.append({'drive_id':driveid,'name':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())})
 with tarfile.open(p) as tar:
  for old in prior:
   name=old['name'];members=[x for x in tar.getmembers() if x.isfile() and Path(x.name).name in (name+'.instance.json',name+'.vrp')]
   if not members:continue
   assert len(members)==2
   out={}
   for m in members:
    b=tar.extractfile(m).read();target=R/'provenance/recovered_old9'/Path(m.name).name;target.parent.mkdir(exist_ok=True)
    with target.open('xb') as f:f.write(b)
    out[target.suffix]={'member':m.name,'copy':str(target.relative_to(R)),'bytes':len(b),'sha256':sha(b)}
   norm=json.loads((R/out['.json']['copy']).read_text());_,xy,ds=parse_instance(R/out['.vrp']['copy'])
   h=fp(xy,ds);_,rxy,rds=parse_instance(R/'raw/exclusions'/f'{name}.vrp')
   rec={'name':name,'archive_drive_id':driveid,'normalized':out['.json'],'original_vrp':out['.vrp'],'expected_normalized_sha256':old['input_sha256'],'normalized_hash_matches_history':out['.json']['sha256']==old['input_sha256'],'retrieved_vrp_byte_equal':(R/out['.vrp']['copy']).read_bytes()==(R/'raw/exclusions'/f'{name}.vrp').read_bytes(),'original_fingerprints':h,'retrieved_fingerprints_match':h==fp(rxy,rds),'normalized_geometry_demands_match':fp([[__import__('decimal').Decimal(str(v)) for v in a] for a in norm['coordinates']],norm['demands'])==h}
   assert rec['normalized_hash_matches_history'] and rec['retrieved_fingerprints_match'] and rec['normalized_geometry_demands_match']
   records.append(rec)
assert len(records)==9
summary={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archives':archives,'records':records,'all9_original_normalized_hashes_verified':all(x['normalized_hash_matches_history'] for x in records),'all9_official_vrp_bytes_identical':all(x['retrieved_vrp_byte_equal'] for x in records),'all9_fingerprints_match_original':all(x['retrieved_fingerprints_match'] for x in records),'supersedes_provisional_identity_limit_in':'reports/VALIDATION_SUMMARY.json (not overwritten)'}
with (R/'reports/HISTORICAL_RECOVERY_VERIFICATION.json').open('x') as f:json.dump(summary,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in summary.items() if k.startswith('all9')},indent=2))
