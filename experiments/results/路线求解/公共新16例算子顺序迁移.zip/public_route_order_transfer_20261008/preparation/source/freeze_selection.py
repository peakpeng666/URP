"""Metadata-only freeze; never imports or invokes an initializer or optimizer."""
import json,hashlib,datetime,shutil
from pathlib import Path
R=Path(__file__).resolve().parents[1];OLD=R.parent/'public_capacity_benchmark_preparation_20261008'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):
 with (R/p).open('x') as f:json.dump(x,f,indent=2,ensure_ascii=False);f.write('\n')
for name in ['catalog_ABEFP.json','cvrplib_catalog.html','PRIOR_NINE_SOURCE.json']:
 shutil.copyfile(OLD/'provenance'/name,R/'provenance'/name)
cat=json.loads((R/'provenance/catalog_ABEFP.json').read_text())
prior9=json.loads((R/'provenance/PRIOR_NINE_SOURCE.json').read_text())['records'];prior16=json.loads((OLD/'freeze/SELECTED_PANEL.json').read_text())
excluded=[x['name'] for x in prior9]+[x['name'] for x in prior16]
selected=[];decisions=[];targets={'A':[35,40,45,50,60,70],'B':[35,40,45,50,60,70],'P':[18,21,55,70]}
for family,ts in targets.items():
 for target in ts:
  pool=[x for x in cat if x['family']==family and 12<=x['n_customers']<=80 and x['name'] not in excluded and (family,x['n_customers']) not in [(z['family'],z['n_customers']) for z in selected]]
  ranked=sorted(pool,key=lambda x:(abs(x['n_customers']-target),x['n_customers'],x['filename_k'],x['name']))
  r=dict(ranked[0],target_n_customers=target,selection_slot=len(selected)+1);selected.append(r)
  decisions.append({'family':family,'target':target,'ranked_names':[x['name'] for x in ranked],'chosen':r['name']})
created=datetime.datetime.now(datetime.timezone.utc).isoformat()
write('freeze/SELECTION_RULE.json',{'created_utc':created,'stage':'retrieval_selection_frozen_before_new_downloads','source':'https://galgos.inf.puc-rio.br/cvrplib/en/instances/1','catalog_sha256':sha(R/'provenance/cvrplib_catalog.html'),'catalog_snapshot':'existing official catalog captured 2026-10-08; no algorithm outcomes used by selection script','targets':targets,'size_customers':[12,80],'prior_name_exclusions':excluded,'same_family_customer_count_unique':True,'ranking':['absolute distance in n_customers from target','n_customers ascending','filename k numeric ascending','name ascending'],'no_replacements':True,'failure_policy':'Retain all 16 named slots. Missing, invalid, duplicate or unverified-novelty slots do not execute and are not replaced. All16 primary mean is null if any slot cannot be scored.','fingerprints':{'ordered_exact':'depot and ordered customer absolute coordinate/demand values, exact decimal canonicalization, excluding capacity/K','base_invariant':'sorted customer (x−depot_x,y−depot_y,demand) multiset, exact decimal canonicalization, excluding capacity/K and source node numbering','scope':'detects same coordinate-demand base under customer renumbering and global translation; does not claim rotation/reflection/scaling/general graph-isomorphism detection'},'duplicate_policy':'Against all 25 historical named tasks and earlier selected slots. Any fingerprint hit disqualifies newer slot; do not replace it. Historical 16 include E/P repeated bases. If any old9 official data cannot be recovered sufficiently for exclusion, novelty is unverified and formal execution blocked.','claim':'Public transfer panel not used to choose this round operator schedule; neither strict blind test nor preregistered confirmatory study. Inference limited to selected A/B/P tasks and this deterministic initializer/search pipeline; does not extend E/F or all CVRPLIB.','model_calls':0,'initialization_calls':0,'search_calls':0})
write('freeze/SELECTED_PANEL.json',selected);write('freeze/SELECTION_DECISIONS.json',decisions)
jobs=[]
for x in selected:
 jobs.extend([{'name':x['name'],'kind':'candidate_instance','url':x['instance_url'],'path':f"raw/instances/{x['name']}.vrp"},{'name':x['name'],'kind':'reference_validation_only','url':x['solution_url'],'path':f"raw/references/{x['name']}.sol"}])
for name in [x['name'] for x in prior9]:
 x=next(z for z in cat if z['name']==name)
 jobs.append({'name':name,'kind':'historical_exclusion_retrieval','url':x['instance_url'],'path':f'raw/exclusions/{name}.vrp'})
write('freeze/RETRIEVAL_PLAN.json',{'created_utc':created,'jobs':jobs,'GET_attempts_max':41,'retries':0,'concurrency':3,'per_GET_timeout_seconds':60,'max_response_bytes':2097152,'host_allowlist':['galgos.inf.puc-rio.br'],'authentication':'none','strictly_no_initialization_or_search':True,'reference_use':'Parse/verify reference feasibility and cost; define at-most-K_ref task from count. Do not pass routes or costs to initialization/search.','historical_hash_limit':'Old9 history provides normalized *.instance.json SHA256, not original .vrp SHA256. Direct hash equality between different formats is not meaningful. Preserve recovered .vrp bytes and hashes and explicitly report original normalized identity as unverified unless actual original bytes recovered.'})
prior16e=[]
for x in prior16:
 p=OLD/'raw/instances'/f"{x['name']}.vrp"
 q=R/'provenance/historical_16_instances'/p.name;q.parent.mkdir(exist_ok=True);shutil.copyfile(p,q)
 prior16e.append({'name':x['name'],'source':str(p),'copy':str(q.relative_to(R)),'sha256':sha(q)})
write('freeze/HISTORICAL_EXCLUSIONS.json',{'old9':prior9,'old16':prior16e,'named_tasks':25,'old16_unique_ordered_bases':14,'all_historical_original_bytes_recovered':False})
sourcepaths=[OLD/'source/acquire.py',OLD/'source/verify_public_data.py',OLD/'source/freeze_selection.py',R.parent/'public_capacity_benchmark_execution_20261008_r1/source/capacity_solver.py',R.parent/'public_capacity_benchmark_execution_20261008_r1/source/call_once.py',R.parent/'public_capacity_benchmark_execution_20261008_r1/source/legacy/experiment.py',R.parent/'public_route_operator_order_20261008/source/engine.py',R.parent/'public_route_operator_order_20261008/source/worker.py']
write('provenance/REVIEWED_SOURCE_IDENTITIES.json',[{'path':str(p),'sha256':sha(p),'review':'read source without import/execution'} for p in sourcepaths])
print('\n'.join(x['name'] for x in selected))
