"""Independent aggregate and archived-byte verification of already saved results."""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter
import json,hashlib,datetime,math,csv,zipfile
R=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def equal(a,b):assert math.isclose(a,float(b),rel_tol=1e-12,abs_tol=1e-12),(a,b)
def csvrows(p):return list(csv.DictReader(p.open()))
def main():
 data=read(R/'independent_review/DATA_AUDIT.json');replay=read(R/'independent_review/SAVED_TRACE_AUDIT.json');summary=read(R/'reports/SUMMARY.json')
 assert data['data_ready_for_formal_gate'] and replay['status']=='PASS'
 refs={v['name']:v['rounded_reference_cost'] for v in data['details']['reference_arithmetic_Kref_and_clean_inputs']}
 tasks=read(R/'freeze/TASKS.json');byarm={(x['instance_id'],x['arm']):x for x in replay['results']};assert len(byarm)==48
 saved={};attempted=0;percall=csvrows(R/'reports/PER_CALL.csv');paired=csvrows(R/'reports/PAIRED_TSR_MINUS_TRS.csv');curves=csvrows(R/'reports/FIXED_BUDGET_TRAJECTORIES.csv')
 assert len(percall)==48 and len(paired)==16 and len(curves)==288
 assert len({(v['instance_id'],v['arm']) for v in percall})==48
 assert len({(v['instance_id'],v['arm'],v['budget_node']) for v in curves})==288
 cindex={(v['instance_id'],v['arm'],int(v['budget_node'])):v for v in curves}
 gapmeans={};pairs=[];nodepairs={k:[] for k in (0,100,1000,5000,10000,20000)}
 for arm in ('T','TRS','TSR'):
  armresults=[byarm[(t['instance_id'],arm)] for t in tasks]
  gapmeans[arm]=sum((F(100*(a['terminal_cost']-refs[a['instance_id']]),refs[a['instance_id']]) for a in armresults),F(0))/16
  equal(summary['arms'][arm]['mean_reference_gap_percent_all16'],gapmeans[arm])
  for key in ('attempted','feasible','accepted'):
   assert summary['arms'][arm][key]==sum(x[key] for x in armresults)
  assert summary['arms'][arm]['LOCAL_OPTIMUM']==sum(x['termination']=='LOCAL_OPTIMUM' for x in armresults)
  assert summary['arms'][arm]['BUDGET_EXHAUSTED']==sum(x['termination']=='BUDGET_EXHAUSTED' for x in armresults)
  for t in tasks:
   name=t['instance_id'];i=t['selection_slot'];s=read(R/'raw/calls'/f'S{i:02}_{arm}.stdout');saved[name,arm]=s;attempted+=len(s['trace'])
  for op in ('two_opt','relocate','swap'):
   traces=[tr for t in tasks for tr in saved[t['instance_id'],arm]['trace'] if tr[0]==op]
   expected={'attempted':len(traces),'feasible':sum(tr[5] for tr in traces),'accepted':sum(tr[7] for tr in traces)}
   assert summary['arms'][arm]['operator_counts'][op]==expected
 for t,pair in zip(tasks,paired):
  name=t['instance_id'];ref=refs[name];a=byarm[name,'TSR']['terminal_cost'];b=byarm[name,'TRS']['terminal_cost'];delta=a-b;pp=F(100*delta,ref)
  assert pair['instance_id']==name and int(pair['TSR_cost'])==a and int(pair['TRS_cost'])==b and int(pair['TSR_minus_TRS_cost'])==delta
  equal(float(pair['TSR_minus_TRS_gap_percentage_points']),pp)
  outcome='improved' if delta<0 else 'worse' if delta>0 else 'equal';assert pair['outcome']==outcome
  pairs.append({'instance_id':name,'TRS_cost':b,'TSR_cost':a,'delta_cost':delta,'delta_gap_pp':float(pp),'outcome':outcome})
  for arm in ('T','TRS','TSR'):
   audited=byarm[name,arm];nodecosts={v['attempted']:v['cost'] for v in audited['checkpoints']}
   for level in nodepairs:
    if level in nodecosts:cost=nodecosts[level];carry=False
    else:assert level>audited['attempted'] and audited['termination']=='LOCAL_OPTIMUM';cost=audited['terminal_cost'];carry=True
    row=cindex[name,arm,level];assert int(row['cost'])==cost and row['carried_after_LOCAL_OPTIMUM']==str(carry)
    assert int(row['actual_attempted_to_terminal'])==audited['attempted']
  for level in nodepairs:
   a=int(cindex[name,'TSR',level]['cost']);b=int(cindex[name,'TRS',level]['cost']);nodepairs[level].append(F(100*(a-b),ref))
 primary=sum((F(100*p['delta_cost'],refs[p['instance_id']]) for p in pairs),F(0))/16
 equal(summary['primary']['mean_gap_difference_percentage_points_all16'],primary)
 outcomes=Counter(p['outcome'] for p in pairs)
 for key in ('improved','equal','worse'):assert summary['primary'][key]==outcomes[key]
 assert summary['primary']['unavailable']==0 and summary['primary']['valid_pairs']==16
 nodes=[]
 for row in summary['secondary_all_nodes']:
  level=row['budget_node'];mean=sum(nodepairs[level],F(0))/16;equal(row['mean_gap_difference_percentage_points_all16'],mean);assert row['valid_pairs']==16
  nodes.append({'node':level,'delta_gap_pp':float(mean)})
 for row in percall:
  s=byarm[row['instance_id'],row['arm']];assert row['status']=='SUCCESS' and int(row['cost'])==s['terminal_cost']
  equal(float(row['reference_gap_percent']),F(100*(s['terminal_cost']-refs[row['instance_id']]),refs[row['instance_id']]))
  for key in ('attempted','feasible','accepted','K_slots','nonempty_routes'):assert int(row[key])==s[key]
 assert attempted==283372
 archives=[]
 frozen=read(R/'freeze/FROZEN_FILES.json')
 for stage,receiptname in [('PREEXEC','PREEXEC_DRIVE_RECEIPT.json'),('RAW_UNREVIEWED','RAW_UNREVIEWED_DRIVE_RECEIPT.json')]:
  receipt=read(R/'provenance'/receiptname);source=R.parent/(R.name+'_'+stage+'.zip');download=Path(receipt['download_path'])
  assert receipt['owner_only'] and receipt['shared'] is False and receipt['download_byte_identical'] and receipt['remote_readback_sha256_verified']
  assert sha(source)==sha(download)==receipt['sha256']==receipt['download_sha256']
  assert source.read_bytes()==download.read_bytes()
  with zipfile.ZipFile(download) as z:
   assert len(z.namelist())==len(set(z.namelist()))
   for p,v in frozen['files'].items():assert hashlib.sha256(z.read(R.name+'/'+p)).hexdigest()==v['sha256']
   assert hashlib.sha256(z.read(R.name+'/freeze/FROZEN_FILES.json')).hexdigest()==sha(R/'freeze/FROZEN_FILES.json')
   if stage=='PREEXEC':assert not any(n.startswith(R.name+'/raw/') for n in z.namelist())
   else:
    manifest=read(R/'raw/SEALED_RAW_MANIFEST.json')
    for p,v in manifest['files'].items():assert hashlib.sha256(z.read(R.name+'/'+p)).hexdigest()==v['sha256']==sha(R/p)
    assert not any(n.startswith(R.name+'/reports/') for n in z.namelist())
  archives.append({'stage':stage,'sha256':sha(source),'bytes':source.stat().st_size,'local_download_byte_identical':True,'frozen_manifest_entries_verified':len(frozen['files']),'private_owner_only_indicated_by_saved_receipt':True})
 before=read(R/'provenance/PREEXEC_DRIVE_RECEIPT.json')['confirmed_at_utc'];after=read(R/'provenance/RAW_UNREVIEWED_DRIVE_RECEIPT.json')['confirmed_at_utc']
 assert datetime.datetime.fromisoformat(before.replace('Z','+00:00'))<datetime.datetime.fromisoformat(read(R/'raw/INVOCATION.json')['utc'])
 assert datetime.datetime.fromisoformat(after.replace('Z','+00:00'))<datetime.datetime.fromisoformat(summary['created_utc'])
 text=(R/'reports/REPORT_ZH.txt').read_text()
 for needle in ['不是严格盲测','不是预注册确认性研究','范围仅本A/B/P面板','T仅描述基线','不声称旋转','不是等实际工作量或等CPU','初始化采用连续欧氏','不可推断速度、全局最优或普遍算法优势']:assert needle in text
 assert summary['limitations']==read(R/'freeze/PROTOCOL.json')['limitations']
 report={'status':'PASS','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'audit_script_sha256':sha(Path(__file__)),'aggregate_method':'Exact Fraction percentages using independently verified integer reference costs and independently replay-verified terminal route costs','formal_initializer_calls':16,'formal_search_calls':48,'trace_candidates_independently_verified':attempted,'all16_primary_TSR_minus_TRS_gap_pp':float(primary),'primary_exact_rational':str(primary),'outcomes':dict(outcomes),'arm_mean_gap_percent':{a:float(v) for a,v in gapmeans.items()},'all_fixed_nodes':nodes,'per_instance':pairs,'archives':archives,'source_inputs_and_original_evidence_unchanged':True,'report_claims_and_limitations':'PASS, conditional language and scope retained. Pending independent-review labels may now be updated to PASS with links to these audit artifacts.','optimizer_calls_by_reviewer':0,'initializer_calls_by_reviewer_on_real_panel':0,'report_files_sha256':{str(p.relative_to(R)):sha(p) for p in sorted((R/'reports').iterdir()) if p.is_file()}}
 (R/'independent_review/FINAL_REPORT_AUDIT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ('per_instance','report_files_sha256')},indent=2))
if __name__=='__main__':main()
