# Independent transfer-panel data review

Status: PASS for data preparation, 2026-10-08. Formal execution is not yet reviewed or authorized by this report.

## Evidence checked

- Reparsed the frozen official HTML with an independent HTMLParser and reconstructed all 90 A/B/E/F/P metadata records. The JSON catalog matches the HTML-derived records exactly.
- Recomputed the deterministic target-distance ranking, customer-count tie break, filename-k tie break, family-size uniqueness, and historical name exclusion. All 16 selected records and all complete ranked decision lists match the freeze. The result is A6/B6/P4 with no substitutions.
- Checked all 25 named exclusions: the old 9 names and all 16 tasks from the prior panel. Historical task count is 25; there are 23 distinct coordinate-demand bases within the declared translation/renumbering scope. The only historical base overlaps are P-n51-k10/E-n51-k5 and P-n76-k4/E-n76-k7.
- Independently parsed 41 .vrp files (25 historical, 16 new) using Fraction arithmetic. Every new task has distinct ordered and translation/customer-renumbering-invariant fingerprints relative to history and earlier new slots.
- Independently parsed all 16 .sol files, checked exact once-only customer coverage and capacities, counted nonempty routes, and recomputed rounded EUC_2D costs using integer-square-root/rational half-up comparisons. All costs agree. All current K_ref happen to equal filename k, but the implementation derives K from validated reference route count rather than assuming that equality.
- Verified all 41 acquisition records, one per planned GET, one attempt each, correct source paths and SHA256. The selection freeze precedes acquisition, and acquisition-start records pin the selection and retrieval-plan hashes.
- Checked recovered original normalized files against all 9 recorded historical SHA256 values. Original .vrp bytes are identical to the new official retrievals for all 9; coordinates, demands, and capacities agree semantically with original normalized files. This supersedes the earlier missing-byte limitation while retaining the provisional audit.
- Checked normalized inputs for exact coordinates/demands/capacity, validated K_ref, and absence of reference route or cost fields. Reference witness material is stored separately.

## Source review

Selection and acquisition sources do not invoke initialization or optimization. The data validator performs parsing, feasibility checks, arithmetic cost verification, and reference-count K construction only. The approved engine takes coordinates, demands, capacity, starting routes, arm, and budget; it does not accept reference data. The initializer reads only the instance geometry, demands, capacity, and K for the relevant construction path; no reference route or cost is used by that path. The execution supervisor and runtime boundaries still require separate PREEXEC review.

## Independent testing and scope

The independent script imports standard-library modules only and never imports project algorithms. Synthetic fixtures verify translation and renumbering invariance, capacity exclusion, changed-demand detection, non-equivalence of reflection in the test fixture, arbitrary source node IDs/depot ID, and exact rounding boundary cases. No real benchmark initialization or search was run.

Fingerprint claims cover global translation and customer renumbering only. They do not establish novelty under rotations, reflections, scaling, arbitrary graph isomorphism, or literature exposure. The public panel is neither a strict blind test nor preregistered confirmatory research.

Files: audit_data.py and DATA_AUDIT.json. DATA_AUDIT_PROVISIONAL_OLD9_MISSING.json preserves the initial snapshot before this reviewer read the recovered history.
