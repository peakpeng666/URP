"""Replay SAVED trace only. No solver imports/calls, no initializer rerun.
Candidate enumeration checks the recorded trace prefix and full-scan markers;
all candidate deltas are verified by whole-route integer rescoring.
"""
from pathlib import Path
from collections import Counter
from fractions import Fraction as F
import hashlib,json,math,datetime
R=Path(__file__).resolve().parents[1]
OPS={'T':['two_opt'],'TRS':['two_opt','relocate','swap'],'TSR':['two_opt','swap','relocate']}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def edge(a,b):
 s=sum((F(str(x))-F(str(y)))**2 for x,y in zip(a,b)); f=math.isqrt(s.numerator//s.denominator)
 return f+int(4*s.numerator>=s.denominator*(2*f+1)**2)
def score(routes,mat):return sum(mat[a][b] for route in routes for a,b in zip(route,route[1:]))
def route_check(routes,raw):
 assert len(routes)==raw['K']
 assert all(isinstance(r,list) and len(r)>=2 and r[0]==r[-1]==0 for r in routes)
 assert all(type(n)is int and 0<n<len(raw['demands']) for r in routes for n in r[1:-1])
 assert Counter(n for r in routes for n in r[1:-1])==Counter(range(1,len(raw['demands'])))
 loads=[sum(raw['demands'][n] for n in r[1:-1]) for r in routes];assert max(loads)<=raw['capacity']
 return loads

def enumerate_moves(routes,op):
 if op=='two_opt':
  for a in range(len(routes)):
   for i in range(1,len(routes[a])-2):
    for j in range(i+1,len(routes[a])-1):yield [a,i,a,j]
 elif op=='relocate':
  for a in range(len(routes)):
   for i in range(1,len(routes[a])-1):
    for b in range(len(routes)):
     if a!=b:
      for j in range(1,len(routes[b])):yield [a,i,b,j]
 elif op=='swap':
  for a in range(len(routes)):
   for b in range(a+1,len(routes)):
    for i in range(1,len(routes[a])-1):
     for j in range(1,len(routes[b])-1):yield [a,i,b,j]
 else:raise ValueError(op)

def changed_routes(routes,op,c):
 rr=[r[:] for r in routes];a,i,b,j=c
 if op=='two_opt':rr[a][i:j+1]=rr[a][i:j+1][::-1]
 elif op=='relocate':rr[b].insert(j,rr[a].pop(i))
 else:rr[a][i],rr[b][j]=rr[b][j],rr[a][i]
 return rr

def replay(saved,baseline,raw,mat):
 arm=saved['arm'];ops=OPS[arm];routes=[r[:] for r in baseline];loads=route_check(routes,raw)
 initial=score(routes,mat);current=initial;count={op:{'attempted':0,'feasible':0,'accepted':0} for op in ops};moves=[]
 cursor=0;opidx=0;checkpoints=[{'attempted':0,'cost':current}]
 assert saved['budget']==20000 and saved['initial_cost']==initial
 for scan in saved['scans']:
  assert opidx<len(ops) and scan['op']==ops[opidx] and scan['start_attempted']==cursor
  end=scan['end_attempted'];assert cursor<=end<=len(saved['trace'])
  op=scan['op'];candidates=enumerate_moves(routes,op);accepted=False
  while cursor<end:
   cand=next(candidates);tr=saved['trace'][cursor];assert tr[:5]==[op,*cand]
   rr=changed_routes(routes,op,cand)
   ll=[sum(raw['demands'][n] for n in r[1:-1]) for r in rr]
   feasible=max(ll)<=raw['capacity'];delta=score(rr,mat)-current if feasible else None;take=feasible and delta<0
   assert tr[5:]==[int(feasible),delta,int(take)]
   count[op]['attempted']+=1;count[op]['feasible']+=int(feasible);cursor+=1
   if take:
    assert cursor==end
    routes=rr;loads=ll;current+=delta;count[op]['accepted']+=1;accepted=True
    moves.append({'attempted':cursor,'op':op,'candidate':cand,'delta':delta,'cost':current})
   if cursor in (100,1000,5000,10000,20000):checkpoints.append({'attempted':cursor,'cost':current})
  assert scan['accepted']==accepted
  if accepted:
   assert not scan['complete_nonimproving'];opidx=0
  elif scan['complete_nonimproving']:
   assert next(candidates,None) is None
   opidx+=1
  else:
   assert cursor==saved['budget'] and next(candidates,None) is not None
 assert cursor==len(saved['trace'])==saved['attempted']
 assert saved['counts']==count and saved['accepted_moves']==moves and saved['checkpoints']==checkpoints
 assert saved['feasible']==sum(z['feasible'] for z in count.values()) and saved['accepted']==len(moves)
 assert saved['routes']==routes and saved['loads']==route_check(routes,raw)==loads
 assert saved['cost']==score(routes,mat)==current<=initial
 assert saved['unspent_budget']==20000-cursor
 if saved['termination']=='LOCAL_OPTIMUM':assert opidx==len(ops)
 else:assert saved['termination']=='BUDGET_EXHAUSTED' and cursor==20000
 assert saved['reference_read_attempts']==0 and saved['denied_io_events']==[]
 return {'arm':arm,'initial_cost':initial,'terminal_cost':current,'attempted':cursor,'accepted':len(moves),'feasible':saved['feasible'],'termination':saved['termination'],'nonempty_routes':sum(len(r)>2 for r in routes),'K_slots':raw['K'],'checkpoints':checkpoints,'all_trace_prefix_candidates_and_full_rescored_deltas_verified':True}

def main():
 assert (R/'raw/STARTED.json').exists()
 receipt=read(R/'provenance/RAW_UNREVIEWED_DRIVE_RECEIPT.json')
 assert receipt['remote_readback_sha256_verified'] and receipt['download_byte_identical'] and receipt['owner_only'] and not receipt['shared']
 assert receipt['sha256']==receipt['download_sha256']==sha(Path(receipt['download_path']))
 schedule=read(R/'freeze/SCHEDULE.json');results=[json.loads(line) for line in (R/'raw/results.jsonl').read_text().splitlines()]
 attempts=[json.loads(line) for line in (R/'raw/attempts.jsonl').read_text().splitlines()]
 assert len(results)==len(schedule)==64 and len(attempts)==128
 assert Counter((a['phase'],a['call_id']) for a in attempts)==Counter((phase,e['call_id']) for e in schedule for phase in ('STARTED','FINISHED'))
 summaries=[];failures=[];baselines={};seen=set();initializations=0;searches=0
 for entry,result in zip(schedule,results):
  for key,value in entry.items():assert result[key]==value
  name=entry['instance_id'];cid=entry['call_id'];assert cid not in seen;seen.add(cid)
  raw=read(R/'input'/f'{name}.json')
  for field in ('stdout','stderr'):assert sha(R/result[field])==result[field+'_sha256']
  if result.get('process_spawned'):initializations+=entry['kind']=='initialize';searches+=entry['kind']=='search'
  if result['status']!='SUCCESS':
   failures.append({'call_id':cid,'instance_id':name,'status':result['status']});continue
  saved=read(R/result['stdout'])
  if entry['kind']=='initialize':
   assert saved['status']=='SUCCESS' and saved['independent_check']['accepted'] and saved['solver_witness_or_BKS_reads']==0 and saved['reference_access_denied_paths']==[]
   assert saved['input_sha256']==sha(R/'input'/f'{name}.json')
   assert all(p.startswith(('source/','input/')) for p in saved['local_files_read'])
   baseline=read(R/'raw/baselines'/f'{name}.json');routes=saved['output']['routes'];assert len(routes)<=raw['K']
   assert baseline['routes']==routes+[[0,0] for _ in range(raw['K']-len(routes))]
   assert baseline['source_initializer_call']==cid and baseline['source_stdout_sha256']==sha(R/result['stdout'])
   assert baseline['empty_slots_appended']==raw['K']-len(routes)
   route_check(baseline['routes'],raw)
   continuous=math.fsum(math.hypot(raw['coordinates'][a][0]-raw['coordinates'][b][0],raw['coordinates'][a][1]-raw['coordinates'][b][1]) for r in routes for a,b in zip(r,r[1:]))
   assert math.isclose(continuous,saved['output']['reported_cost'],rel_tol=1e-10,abs_tol=1e-8)
   assert saved['budget']['deltas']<=100000
   if 'capacity_partition' in (saved['diagnostic']or{}):assert saved['diagnostic']['capacity_partition']['nodes']<=256
   baselines[name]=baseline['routes']
  else:
   assert name in baselines
   baseline_path=R/'raw/baselines'/f'{name}.json';assert result['baseline_sha256']==sha(baseline_path)
   payload={k:raw[k] for k in ('coordinates','demands','capacity')};payload.update(routes=baselines[name],arm=entry['arm'],budget=20000)
   assert result['payload_sha256']==hashlib.sha256(json.dumps(payload).encode()).hexdigest()
   mat=[[edge(a,b) for b in raw['coordinates']] for a in raw['coordinates']]
   summaries.append({'instance_id':name,'call_id':cid,**replay(saved,baselines[name],raw,mat)})
 frozen=read(R/'freeze/FROZEN_FILES.json');assert all(sha(R/p)==v['sha256'] for p,v in frozen['files'].items())
 old=read(R/'freeze/OLD_FILES_BEFORE.json');assert all(sha(Path(p))==v['sha256'] for p,v in old.items())
 report={'status':'PASS','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'audit_script_sha256':sha(Path(__file__)),'method':'Read-only saved-route and full trace arithmetic replay, no optimizer/initializer re-execution','formal_initialization_processes':initializations,'formal_search_processes':searches,'scheduled_slots':64,'retained_failures':failures,'results':summaries,'frozen_files_unchanged':True,'old_files_unchanged':True,'raw_remote_readback_verified_before_audit':True}
 (R/'independent_review/SAVED_TRACE_AUDIT.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({k:v for k,v in report.items() if k!='results'},indent=2))
if __name__=='__main__':main()
