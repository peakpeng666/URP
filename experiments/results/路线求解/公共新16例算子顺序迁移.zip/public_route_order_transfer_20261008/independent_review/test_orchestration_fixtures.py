"""Invented data and mocked children only; never launches an experiment child.
Tests unchanged supervisor/report logic with R redirected to temporary fixtures.
"""
from pathlib import Path
import contextlib,datetime,hashlib,importlib.util,io,json,subprocess,sys,tempfile
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1];sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT/'source'))
def load(name):
 spec=importlib.util.spec_from_file_location('fixture_'+name,ROOT/'source'/f'{name}.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod
def dump(p,x):p.parent.mkdir(exist_ok=True,parents=True);p.write_text(json.dumps(x))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def inventory(r):
 tasks=[];schedule=[]
 for i in range(1,17):
  name=f'INVENTED_FIXTURE_{i}';tasks.append({'instance_id':name,'selection_slot':i,'K':2,'eligible':True})
  dump(r/'input'/f'{name}.json',{'instance_id':name,'coordinates':[[0,0],[3,4],[6,8]],'demands':[0,1,1],'capacity':2,'K':2})
  schedule.append({'call_id':f'I{i:02}','instance_id':name,'selection_slot':i,'kind':'initialize','arm':'capacity_solver','endpoint':'initialize_256','node_limit':256})
  arms=['T','TRS','TSR'];arms=arms[(i-1)%3:]+arms[:(i-1)%3]
  for arm in arms:schedule.append({'call_id':f'S{i:02}_{arm}','instance_id':name,'selection_slot':i,'kind':'search','arm':arm,'budget':20000})
 dump(r/'freeze/TASKS.json',tasks);dump(r/'freeze/SCHEDULE.json',schedule);dump(r/'freeze/FROZEN_FILES.json',{'files':{}})
 dump(r/'provenance/PREEXEC_DRIVE_RECEIPT.json',{})
 (r/'raw').mkdir(exist_ok=True)
 return tasks,schedule

def supervisor_fixture(tmp):
 m=load('run_once');r=tmp/'supervisor';tasks,schedule=inventory(r);m.R=r;spawned=[];payloads={}
 class Child:
  def __init__(self,cmd,**kw):
   self.cmd=cmd;self.kw=kw;self.returncode=0;self.killed=False
   if cmd[2].endswith('initialize_once.py'):
    self.entry=json.loads(cmd[3]);self.cid=self.entry['call_id']
   else:
    self.cid=Path(kw['stdout'].name).stem;self.entry=next(e for e in schedule if e['call_id']==self.cid)
  def communicate(self,payload=None,timeout=None):
   if self.killed:self.returncode=-9;return None,None
   if self.entry['kind']=='search':
    v=json.loads(payload);payloads[self.cid]=v
   spawned.append(self.cid)
   if self.cid=='S03_T':raise subprocess.TimeoutExpired(self.cmd,timeout)
   if self.cid=='S04_TRS':self.returncode=1;self.kw['stderr'].write(b'invented process failure');return None,None
   if self.cid=='S05_TSR':self.kw['stdout'].write(b'{broken fixture');return None,None
   if self.entry['kind']=='initialize':
    if self.cid=='I02':out={'status':'INITFAIL','diagnostic':None,'budget':{},'solver_witness_or_BKS_reads':0,'reference_access_denied_paths':[]}
    else:out={'status':'SUCCESS','diagnostic':{},'budget':{},'solver_witness_or_BKS_reads':0,'reference_access_denied_paths':[],'independent_check':{'accepted':True},'output':{'routes':[[0,1,2,0]],'reported_cost':20}}
   else:
    out={'arm':self.entry['arm'],'attempted':0,'reference_read_attempts':0,'denied_io_events':[],'routes':json.loads(payload)['routes']}
   self.kw['stdout'].write(json.dumps(out).encode());return None,None
  def kill(self):self.killed=True
 def make(cmd,**kw):return Child(cmd,**kw)
 with patch.object(m,'gates',return_value={}),patch.object(m.resource,'setrlimit'),patch.object(m.signal,'alarm'),patch.object(m.subprocess,'Popen',side_effect=make):
  m.main();before=list(spawned)
  try:m.main();raise AssertionError('second invocation was accepted')
  except FileExistsError:pass
  assert spawned==before
 results=[json.loads(x) for x in (r/'raw/results.jsonl').read_text().splitlines()];byid={x['call_id']:x for x in results}
 assert len(results)==64 and len(spawned)==61 and len(set(spawned))==61
 assert sum(x['status']=='SKIPPED_INITIALIZATION_FAILURE' for x in results)==3
 assert byid['S03_T']['status']=='WALL_TIMEOUT' and byid['S04_TRS']['status']=='PROCESS_FAILURE_OR_CPU_LIMIT' and byid['S05_TSR']['status']=='CALL_ERROR_UNDETERMINED'
 assert byid['I16']['status']=='SUCCESS' and byid['S16_TSR']['status']=='SUCCESS'
 assert all(v['routes']==[[0,1,2,0],[0,0]] for v in payloads.values())
 assert all(set(v)=={'coordinates','demands','capacity','routes','arm','budget'} for v in payloads.values())
 assert (r/'raw/RAW_UNREVIEWED_MANIFEST.json').is_file()
 return {'pass':True,'mocked_child_processes':61,'retained_slots':64,'initializer_failure_skips_3':True,'timeout_process_failure_malformed_json_preserved':True,'later_tasks_continue':True,'same_baseline_with_appended_empty_slot':True,'second_invocation_blocked_before_any_child':True,'real_initializer_calls':0,'real_search_calls':0}

def report_fixture(tmp,kind):
 m=load('report');r=tmp/f'report_{kind}';tasks,schedule=inventory(r);m.R=r
 (r/'reports').mkdir();dump(r/'freeze/OLD_FILES_BEFORE.json',{});dump(r/'freeze/PROTOCOL.json',{'limitations':['invented only']});dump(r/'raw/SEALED_RAW_MANIFEST.json',{'files':{}})
 package=r.parent/(r.name+'_RAW_UNREVIEWED.zip');package.write_bytes(b'invented archive fixture')
 dump(r/'provenance/RAW_UNREVIEWED_DRIVE_RECEIPT.json',{'owner_only':True,'shared':False,'remote_readback_sha256_verified':True,'download_byte_identical':True,'sha256':sha(package),'download_sha256':sha(package),'download_path':str(package)})
 results=[]
 for t in tasks:
  name=t['instance_id'];i=t['selection_slot']
  (r/'input'/f'{name}.vrp').write_text('NAME : '+name+'\nTYPE : CVRP\nDIMENSION : 3\nCAPACITY : 2\nEDGE_WEIGHT_TYPE : EUC_2D\nNODE_COORD_SECTION\n1 0 0\n2 3 4\n3 6 8\nDEMAND_SECTION\n1 0\n2 1\n3 1\nDEPOT_SECTION\n1\n-1\nEOF\n')
  dump(r/'references'/f'{name}.json',{'reference_routes':[[1],[2]],'reference_integer_cost':30})
  if kind=='all_missing':continue
  dump(r/'raw/baselines'/f'{name}.json',{'routes':[[0,1,0],[0,2,0]]})
  results.append({'call_id':f'I{i:02}','kind':'initialize','status':'SUCCESS','process_spawned':True})
  for arm in ('T','TRS','TSR'):
   if i==16 and arm=='TSR' and kind=='one_pair_missing':continue
   res={'routes':[[0,1,0],[0,2,0]],'cost':30,'initial_cost':30,'attempted':0,'feasible':0,'accepted':0,'termination':'LOCAL_OPTIMUM','unspent_budget':20000,'counts':{},'scans':[],'trace':[],'accepted_moves':[]}
   path=r/'raw/calls'/f'S{i:02}_{arm}.stdout';dump(path,res)
   results.append({'call_id':f'S{i:02}_{arm}','kind':'search','status':'SUCCESS','stdout':str(path.relative_to(r)),'stdout_sha256':sha(path),'process_spawned':True,'process_cpu_seconds_for_audit_only':0,'process_wall_seconds_for_audit_only':0})
 (r/'raw/results.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in results))
 if kind=='bad_receipt':
  receipt=json.loads((r/'provenance/RAW_UNREVIEWED_DRIVE_RECEIPT.json').read_text());receipt['download_byte_identical']=False;dump(r/'provenance/RAW_UNREVIEWED_DRIVE_RECEIPT.json',receipt)
  try:m.main();raise RuntimeError('report passed bad readback gate')
  except AssertionError:pass
  assert not list((r/'reports').iterdir());return {'pass':True,'invalid_readback_blocks_all_report_writes':True}
 with contextlib.redirect_stdout(io.StringIO()):m.main()
 summary=json.loads((r/'reports/SUMMARY.json').read_text());p=summary['primary'];assert p['mean_gap_difference_percentage_points_all16'] is None
 expected=0 if kind=='all_missing' else 15;assert p['valid_pairs']==expected and p['unavailable']==16-expected and p['descriptive_denominator']==expected
 assert len((r/'reports/PER_CALL.csv').read_text().splitlines())==49
 assert len((r/'reports/FIXED_BUDGET_TRAJECTORIES.csv').read_text().splitlines())==289
 return {'pass':True,'available_pairs':expected,'all16_primary_null':True,'all48_search_slots_retained':True,'all288_fixed_nodes_retained':True}

def wrapper_fixture(tmp):
 r=tmp/'wrapper';r.mkdir();(r/'raw').mkdir();calls=[]
 class FailedChild:
  returncode=-9
  def __init__(self,*args,**kwargs):calls.append('child')
  def wait(self,timeout=None):return -9
  def kill(self):pass
 def package(cmd,check):
  assert cmd[-1]=='RAW_UNREVIEWED' and check
  assert (r/'raw/SEALED_RAW_MANIFEST.json').is_file();calls.append('seal_package');return None
 import run_once
 src=(ROOT/'source/execute_and_seal.py').read_text().replace('R=Path(__file__).resolve().parents[1]','R=Path(FIXTURE_ROOT)')
 scope={'__name__':'__main__','__file__':str(ROOT/'source/execute_and_seal.py'),'FIXTURE_ROOT':str(r)}
 with patch.object(run_once,'gates',return_value={}),patch.object(subprocess,'Popen',FailedChild),patch.object(subprocess,'run',package),contextlib.redirect_stdout(io.StringIO()):
  exec(compile(src,str(ROOT/'source/execute_and_seal.py'),'exec'),scope)
  assert calls==['child','seal_package']
  try:exec(compile(src,str(ROOT/'source/execute_and_seal.py'),'exec'),scope);raise AssertionError('wrapper rerun accepted')
  except FileExistsError:pass
  assert calls==['child','seal_package']
 saved=json.loads((r/'raw/SUPERVISOR_RETURN.json').read_text());assert saved['returncode']==-9 and not saved['formal_finished']
 return {'pass':True,'fatal_supervisor_sealed_and_package_requested':True,'wrapper_second_invocation_blocked':True,'real_child_processes':0}

if __name__=='__main__':
 with tempfile.TemporaryDirectory(prefix='route_transfer_review_') as td:
  tmp=Path(td);report={'status':'PASS','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'method':'Only invented 3-node inputs with mocked child process API; no actual benchmark or optimization','supervisor':supervisor_fixture(tmp),'report_all_missing':report_fixture(tmp,'all_missing'),'report_one_pair_missing':report_fixture(tmp,'one_pair_missing'),'report_bad_receipt':report_fixture(tmp,'bad_receipt'),'wrapper_fatal_and_no_retry':wrapper_fixture(tmp),'sources':{name:sha(ROOT/'source'/name) for name in ('run_once.py','report.py','execute_and_seal.py')}}
 (ROOT/'independent_review/ORCHESTRATION_FIXTURES.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
