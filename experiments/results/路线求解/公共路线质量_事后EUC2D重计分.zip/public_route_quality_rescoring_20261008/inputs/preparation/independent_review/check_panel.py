#!/usr/bin/env python3
"""Read-only public CVRP arithmetic audit. No solver, search, imports of project code, or network.

All outputs are written outside the source tree. .sol numbering is fixed BEFORE costs
are computed: depot 0 -> raw ID 1; customer c -> raw ID c+1. No offset fitting.
Decimal coordinates are converted to exact Fractions. EUC_2D rounding is computed by
integer comparisons, exactly equivalent to floor(sqrt(dx*dx+dy*dy)+0.5).
"""
import argparse
import hashlib
import json
import math
import re
from collections import Counter, defaultdict
from datetime import datetime, timezone
from fractions import Fraction
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urljoin

DEFAULT_SOURCE = Path('/workspace/shared/public_capacity_benchmark_preparation_20261008')
DEFAULT_OUTPUT = Path('/workspace/shared/public_capacity_benchmark_independent_review_20261008')
BASE_URL = 'https://galgos.inf.puc-rio.br'
EXPECTED_PRIOR = {'A-n32-k5', 'B-n31-k5', 'P-n40-k5', 'A-n33-k5', 'A-n33-k6',
                  'B-n34-k5', 'B-n35-k5', 'P-n45-k5', 'P-n50-k10'}

def require(test, message):
    if not test:
        raise ValueError(message)

def read_json(path):
    return json.loads(path.read_text(encoding='utf-8'))

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def canonical_digest(value):
    return hashlib.sha256(json.dumps(value, separators=(',', ':'), sort_keys=True).encode()).hexdigest()

def exact_int(token):
    require(re.fullmatch(r'[+-]?\d+', token) is not None, 'not an integer token: ' + token)
    return int(token)

def parse_vrp(text):
    headers, coords, demands, depots = {}, {}, {}, []
    section = None
    seen_sections = []
    depot_end = eof = False
    for lineno, raw in enumerate(text.splitlines(), 1):
        s = raw.strip()
        if not s:
            continue
        require(not eof, f'data after EOF at line {lineno}')
        if s == 'EOF':
            eof = True
            continue
        if s in ('NODE_COORD_SECTION', 'DEMAND_SECTION', 'DEPOT_SECTION'):
            require(s not in seen_sections, 'duplicate section ' + s)
            seen_sections.append(s)
            section = s
            continue
        if section is None:
            m = re.fullmatch(r'([^:]+?)\s*:\s*(.*)', s)
            require(m is not None, f'invalid header line {lineno}')
            key, value = m.group(1).strip(), m.group(2).strip()
            require(key not in headers, 'duplicate header ' + key)
            headers[key] = value
        elif section == 'NODE_COORD_SECTION':
            fields = s.split()
            require(len(fields) == 3, f'bad coordinate row {lineno}')
            node = exact_int(fields[0])
            require(node not in coords, 'duplicate coordinate node')
            coords[node] = (Fraction(fields[1]), Fraction(fields[2]))
        elif section == 'DEMAND_SECTION':
            fields = s.split()
            require(len(fields) == 2, f'bad demand row {lineno}')
            node = exact_int(fields[0])
            require(node not in demands, 'duplicate demand node')
            demands[node] = exact_int(fields[1])
        else:
            require(not depot_end, 'data after depot terminator')
            for token in s.split():
                value = exact_int(token)
                require(not depot_end, 'data after depot terminator')
                if value == -1:
                    depot_end = True
                else:
                    depots.append(value)
    require(eof and depot_end, 'missing EOF/depot terminator')
    require(seen_sections == ['NODE_COORD_SECTION', 'DEMAND_SECTION', 'DEPOT_SECTION'], 'unexpected section order')
    require(headers.get('TYPE') == 'CVRP', 'not CVRP')
    require(headers.get('EDGE_WEIGHT_TYPE') == 'EUC_2D', 'not EUC_2D')
    dimension, capacity = exact_int(headers['DIMENSION']), exact_int(headers['CAPACITY'])
    require(dimension > 1 and capacity > 0, 'invalid dimension/capacity')
    ids = list(range(1, dimension + 1))
    require(sorted(coords) == ids and sorted(demands) == ids, 'node ID coverage is not 1..dimension')
    require(list(coords) == ids and list(demands) == ids, 'node rows are not in numbered order')
    require(depots == [1], 'expected exactly one depot with raw ID 1')
    require(demands[1] == 0, 'depot demand is not zero')
    require(all(0 <= d <= capacity for d in demands.values()), 'negative demand or demand above capacity')
    return headers, coords, demands, dimension, capacity

def parse_sol(text):
    routes, route_numbers, cost = [], [], None
    for lineno, raw in enumerate(text.splitlines(), 1):
        s = raw.strip()
        if not s:
            continue
        m = re.fullmatch(r'Route\s+#(\d+)\s*:\s*(.*)', s)
        if m:
            require(cost is None, 'route after Cost')
            route_numbers.append(int(m.group(1)))
            routes.append([exact_int(v) for v in m.group(2).split()])
        else:
            m = re.fullmatch(r'Cost\s+([+-]?\d+(?:\.\d+)?)', s)
            require(m is not None and cost is None, f'bad solution line {lineno}')
            cost = Fraction(m.group(1))
    require(cost is not None and cost >= 0, 'missing or invalid Cost')
    require(route_numbers == list(range(1, len(routes) + 1)), 'nonsequential/duplicate route labels')
    return routes, cost

def edge_round(a, b):
    squared = sum((x - y) ** 2 for x, y in zip(a, b))
    numerator, denominator = squared.numerator, squared.denominator
    root_floor = math.isqrt(numerator // denominator)
    return root_floor + int(4 * numerator >= denominator * (2 * root_floor + 1) ** 2)

def audit_reference(vrp_text, sol_text):
    headers, coords, demands, dimension, Q = parse_vrp(vrp_text)
    routes, claimed = parse_sol(sol_text)
    flattened = [c for route in routes for c in route]
    counts = Counter(flattened)
    require(counts == Counter(range(1, dimension)), '.sol customer IDs do not cover 1..n exactly once')
    checked_routes = []
    for number, route in enumerate(routes, 1):
        raw_ids = [c + 1 for c in route]
        load = sum(demands[c] for c in raw_ids)
        require(load <= Q, 'reference route exceeds capacity')
        cycle = [1] + raw_ids + [1]
        edges = [{'from_raw': a, 'to_raw': b, 'EUC_2D': edge_round(coords[a], coords[b])}
                 for a, b in zip(cycle, cycle[1:])]
        checked_routes.append({'route': number, 'sol_customer_ids': route, 'raw_customer_ids': raw_ids,
                               'load': load, 'residual': Q - load,
                               'cost_EUC_2D': sum(e['EUC_2D'] for e in edges), 'edges': edges})
    total_cost = sum(r['cost_EUC_2D'] for r in checked_routes)
    require(total_cost == claimed, 'fixed-mapping EUC_2D cost differs from .sol Cost')
    K = sum(bool(route) for route in routes)
    customer_demands = [demands[i] for i in range(2, dimension + 1)]
    D, m = sum(customer_demands), min(customer_demands)
    require(m > 0, 'static minimum-positive-demand proof does not cover a zero-demand customer')
    U, bound = K * Q - D, K * (m - 1)
    require(U >= 0, 'negative total slack despite feasible reference')
    geometry = [[i, str(coords[i][0]), str(coords[i][1]), demands[i]] for i in range(1, dimension + 1)]
    return {'name': headers['NAME'], 'dimension': dimension, 'n_customers': dimension - 1,
            'node_ids_complete_ordered': True, 'single_depot_raw_id': 1,
            'Q': Q, 'nonnegative_integer_demands': True, 'all_customers_positive': True,
            'reference_customer_coverage_exact_once': True, 'reference_capacity_feasible': True,
            'K_reference_nonempty_routes': K, 'empty_reference_route_count': len(routes) - K,
            'D': D, 'm': m, 'U_KQ_minus_D': U, 'bound_K_times_m_minus_1': bound,
            'static_never_triggers_under_fixed_descending_order': U >= bound,
            'reference_claimed_cost': str(claimed), 'reference_recomputed_cost_EUC_2D': total_cost,
            'geometry_demands_fingerprint': canonical_digest(geometry),
            'demand_multiset_fingerprint': canonical_digest(sorted(customer_demands)),
            'routes': checked_routes}

class CatalogParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.rows, self.row, self.cell, self.links = [], None, None, None
    def handle_starttag(self, tag, attrs):
        if tag == 'tr':
            self.row, self.links = [], []
        elif tag == 'td' and self.row is not None:
            self.cell = []
        elif tag == 'a' and self.row is not None:
            href = dict(attrs).get('href')
            if href:
                self.links.append(href)
    def handle_data(self, data):
        if self.cell is not None:
            self.cell.append(data)
    def handle_endtag(self, tag):
        if tag == 'td' and self.cell is not None:
            self.row.append(' '.join(''.join(self.cell).split()))
            self.cell = None
        elif tag == 'tr' and self.row is not None:
            self.rows.append((self.row, self.links))
            self.row, self.cell, self.links = None, None, None

def parse_catalog(html):
    parser = CatalogParser()
    parser.feed(html)
    catalog = []
    for cells, links in parser.rows:
        if not cells:
            continue
        name = cells[0]
        match = re.fullmatch(r'([ABPEF])-n(\d+)-k(\d+)', name)
        if not match:
            continue
        n = exact_int(cells[1].strip('$'))
        require(n == int(match.group(2)) - 1, 'catalog customer count/name mismatch: ' + name)
        instance_urls = [u for u in links if '/download/instance/' in u]
        solution_urls = [u for u in links if '/download/bks/' in u]
        require(len(instance_urls) == len(solution_urls) == 1, 'missing/duplicate catalog file links: ' + name)
        catalog.append({'name': name, 'family': match.group(1), 'n_customers': n,
                        'filename_k': int(match.group(3)),
                        'instance_url': urljoin(BASE_URL, instance_urls[0]),
                        'solution_url': urljoin(BASE_URL, solution_urls[0])})
    require(len(catalog) == len({r['name'] for r in catalog}), 'duplicate catalog row')
    return catalog

def self_tests():
    require(edge_round((Fraction(0), Fraction(0)), (Fraction('0.5'), Fraction(0))) == 1, 'half-up .5 test')
    require(edge_round((Fraction(0), Fraction(0)), (Fraction('2.5'), Fraction(0))) == 3, 'half-up 2.5 test')
    require(edge_round((Fraction(0), Fraction(0)), (Fraction('2.4999999999999999999'), Fraction(0))) == 2, 'just-below test')
    fixture = ('NAME : tiny\nTYPE : CVRP\nDIMENSION : 3\nEDGE_WEIGHT_TYPE : EUC_2D\nCAPACITY : 3\n'
               'NODE_COORD_SECTION\n1 0 0\n2 1 0\n3 2 0\nDEMAND_SECTION\n1 0\n2 1\n3 2\nDEPOT_SECTION\n1\n-1\nEOF\n')
    sol = 'Route #1: 1 2\nCost 4\n'
    require(audit_reference(fixture, sol)['reference_recomputed_cost_EUC_2D'] == 4, 'valid fixture test')
    bad = [('duplicate customer', fixture, sol.replace('1 2', '1 1')),
           ('offset customer IDs', fixture, sol.replace('1 2', '2 3')),
           ('capacity violation', fixture.replace('CAPACITY : 3', 'CAPACITY : 2'), sol),
           ('negative demand', fixture.replace('2 1\n3 2\nDEPOT', '2 -1\n3 2\nDEPOT'), sol),
           ('two depots', fixture.replace('DEPOT_SECTION\n1', 'DEPOT_SECTION\n1 2'), sol),
           ('wrong cost', fixture, sol.replace('Cost 4', 'Cost 5')),
           ('duplicate coordinate ID', fixture.replace('3 2 0', '2 2 0'), sol)]
    for label, v, s in bad:
        try:
            audit_reference(v, s)
        except ValueError:
            pass
        else:
            raise ValueError('negative self-test was not rejected: ' + label)
    return {'passed': True, 'positive_rounding_and_reference_tests': 4,
            'rejected_malformed_cases': [label for label, _, _ in bad]}

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--source', type=Path, default=DEFAULT_SOURCE)
    ap.add_argument('--output', type=Path, default=DEFAULT_OUTPUT)
    args = ap.parse_args()
    source, output = args.source.resolve(), args.output.resolve()
    require(source not in output.parents and source != output, 'output must be outside source directory')
    output.mkdir(parents=True, exist_ok=True)
    files_before = {str(p.relative_to(source)): digest(p) for p in source.rglob('*') if p.is_file()}
    tests = self_tests()
    rule = read_json(source / 'freeze/SELECTION_RULE.json')
    panel = read_json(source / 'freeze/SELECTED_PANEL.json')
    decisions = read_json(source / 'freeze/SELECTION_DECISIONS.json')
    prior = read_json(source / 'provenance/PRIOR_NINE_OFFICIAL_READ_ONLY.json')
    require(set(rule['prior_ids_excluded']) == EXPECTED_PRIOR == {r['name'] for r in prior}, 'prior exclusion list mismatch')
    require(digest(source / 'provenance/cvrplib_catalog.html') == rule['catalog_sha256'], 'frozen catalog hash mismatch')
    catalog = parse_catalog((source / 'provenance/cvrplib_catalog.html').read_text())
    catalog_json = read_json(source / 'provenance/catalog_ABEFP.json')
    require(sorted(catalog, key=lambda r:r['name']) == sorted(catalog_json, key=lambda r:r['name']), 'HTML catalog != prepared catalog')
    require(rule['families'] == ['A','B','P','E','F'] and rule['size_inclusion_customers'] == [12,80], 'unexpected frozen family/size design')
    require(rule['target_counts'] == {'A':[35,50,65,75], 'B':[35,50,65,75], 'P':[35,50,65,75], 'E':[50,75], 'F':[45,75]}, 'unexpected targets')
    require(rule['no_replacements'] and rule['no_selection_based_on_demands_slack_triggerability_solver_performance'], 'frozen constraints missing')
    used, selected_recomputed, rankings = set(EXPECTED_PRIOR), [], []
    for family in rule['families']:
        for target in rule['target_counts'][family]:
            eligible = [r for r in catalog if r['family'] == family and 12 <= r['n_customers'] <= 80 and r['name'] not in used]
            ranked = sorted(eligible, key=lambda r:(abs(r['n_customers']-target), r['n_customers'], r['filename_k'], r['name']))
            require(bool(ranked), 'no catalog candidate for frozen slot')
            winner = ranked[0]
            used.add(winner['name'])
            selected_recomputed.append(dict(winner, target_n_customers=target, selection_slot=len(selected_recomputed)+1))
            rankings.append({'family':family, 'target':target, 'ranked_eligible_names':[r['name'] for r in ranked], 'chosen':winner['name']})
    require(selected_recomputed == panel and rankings == decisions, 'frozen ranking/selected panel mismatch')
    require(len(panel) == 16 and len({r['name'] for r in panel}) == 16, 'not 16 unique named tasks')
    require(not EXPECTED_PRIOR.intersection(r['name'] for r in panel), 'old instance in new panel')
    manifest = read_json(source / 'freeze/POST_ACQUISITION_PRE_SOLVER_FREEZE.json')
    for row in manifest['files']:
        p = source / row['path']
        require(p.stat().st_size == row['bytes'] and digest(p) == row['sha256'], 'freeze manifest mismatch: ' + row['path'])
    checks = []
    for selected in panel:
        name = selected['name']
        vp, sp = source / f'raw/instances/{name}.vrp', source / f'raw/solutions/{name}.sol'
        r = audit_reference(vp.read_text(), sp.read_text())
        require(r['name'] == name and r['n_customers'] == selected['n_customers'], 'raw name/count inconsistent with selection')
        r.update({'slot':selected['selection_slot'], 'instance_url':selected['instance_url'], 'solution_url':selected['solution_url'],
                  'raw_instance_sha256':digest(vp), 'raw_solution_sha256':digest(sp), 'filename_k_label_only':selected['filename_k']})
        checks.append(r)
    # Compare against the preparation report only AFTER our complete raw-data recomputation.
    prepared = {r['name']:r for r in read_json(source / 'reports/INDEPENDENT_ARITHMETIC_CHECKS.json')}
    field_map = {'Q':'Q', 'dimension':'dimension', 'n_customers':'n_customers',
                 'K_reference_nonempty_routes':'K_ref', 'D':'total_demand', 'm':'min_positive_demand',
                 'U_KQ_minus_D':'slack_U', 'bound_K_times_m_minus_1':'dead_capacity_upper_K_times_m_minus_1',
                 'static_never_triggers_under_fixed_descending_order':'theoretically_never_triggers_under_fixed_descending_order',
                 'reference_recomputed_cost_EUC_2D':'reference_cost_EUC_2D_recomputed',
                 'raw_instance_sha256':'source_instance_sha256', 'raw_solution_sha256':'source_reference_sha256'}
    for r in checks:
        q = prepared[r['name']]
        for independent_key, prepared_key in field_map.items():
            require(r[independent_key] == q[prepared_key], f'preparation-report discrepancy {r["name"]}: {independent_key}')
        require([t['load'] for t in r['routes']] == q['reference_route_loads'], 'preparation route loads differ')
        require(Fraction(r['reference_claimed_cost']) == Fraction(str(q['reference_cost_claimed'])), 'preparation reference Cost differs')
    geometry_groups, demand_groups = defaultdict(list), defaultdict(list)
    for r in checks:
        geometry_groups[r['geometry_demands_fingerprint']].append(r['name'])
        demand_groups[r['demand_multiset_fingerprint']].append(r['name'])
    duplicates = sorted([sorted(v) for v in geometry_groups.values() if len(v)>1])
    expected_duplicates = sorted([sorted(['P-n51-k10','E-n51-k5']), sorted(['P-n76-k4','E-n76-k7'])])
    require(duplicates == expected_duplicates, 'unexpected coordinate/demand duplicate grouping')
    not_excluded = [r['name'] for r in checks if not r['static_never_triggers_under_fixed_descending_order']]
    require(not_excluded == ['P-n23-k8'], 'unexpected static-bound screening result')
    files_after = {str(p.relative_to(source)): digest(p) for p in source.rglob('*') if p.is_file()}
    require(files_before == files_after, 'source tree changed during review')
    result = {'status':'PASS_WITH_INFERENCE_LIMITATIONS', 'created_utc':datetime.now(timezone.utc).isoformat(),
              'checker_sha256':digest(Path(__file__)), 'source_tree_unchanged':True,
              'scope':{'solver_executed':False, 'candidate_executed_or_imported':False, 'bin_packing_or_search':False,
                       'network_access_by_checker':False, 'output_uploaded':False, 'standard_library_only':True,
                       'source_files_hashed_before_and_after':len(files_before)},
              'fixed_mapping':'sol depot 0 -> raw ID 1; sol customer c in 1..n -> raw ID c+1; no offset alternatives tested',
              'rounding':'Exact rational squared distances and integer comparisons implement floor(distance+0.5) on each edge.',
              'self_tests':tests, 'selection_audit':{'catalog_html_rows_ABPEF':len(catalog), 'catalog_json_matches_html':True,
                       'frozen_catalog_sha256':rule['catalog_sha256'], 'all_16_selected_slots_and_full_rankings_match':True,
                       'nine_prior_ids_excluded':sorted(EXPECTED_PRIOR), 'freeze_manifest_entries_verified':len(manifest['files']),
                       'selection_rule_sha256':digest(source/'freeze/SELECTION_RULE.json'), 'selected_panel_sha256':digest(source/'freeze/SELECTED_PANEL.json')},
              'summary':{'named_tasks':16, 'all_raw_instances_valid':True, 'all_reference_solutions_feasible_and_cost_matching':True,
                         'independent_recomputations_match_preparation_report':True,
                         'static_never_trigger_count':15, 'static_upper_bound_does_not_exclude':not_excluded,
                         'coordinate_and_demand_unique_groups':len(geometry_groups), 'demand_multiset_unique_groups':len(demand_groups),
                         'shared_coordinate_demand_groups':duplicates},
              'inference_limitations':[
                  'P-n23-k8 has U=7 < K(m-1)=32: not excluded by this upper bound; this does NOT prove any trigger exists or occurs.',
                  'The 15 never-trigger deductions concern the stated integer residual dead-capacity predicate W>U under fixed descending order, with W<=K(m-1), positive customer demands, and the validated reference K.',
                  'K is a feasible reference fleet size, not a proof of minimum fleet requirement and not inferred from filename k.',
                  'There are 16 named capacity/fleet tasks but only 14 distinct indexed coordinate-and-demand bases; even 14 distinct bases are not proven statistically independent.',
                  'If a later experiment evaluates continuous hypot edge lengths, it is a derived objective distinct from the public EUC_2D objective. The EUC_2D reference verification here does not establish a continuous-objective optimum or justify an optimality gap against the original .sol Cost.',
                  'Reproducing a metadata rule and checking local freeze hashes does not establish external preregistration or independently prove historical absence of solver execution.',
                  'The panel is family/size-stratified convenience selection; known pre-freeze instance inspections are disclosed in the frozen rule. It is not a random or performance-tested sample.',
                  'Prior nine exclusion IDs are verified from supplied provenance; their original historical instance bytes were not re-audited.'
              ], 'checks':checks, 'selection_rankings_recomputed':rankings,
              'input_sha256_before_and_after':files_before,
              'source_mapping_evidence':[
                 {'url':'https://github.com/vidalt/HGS-CVRP/blob/main/Program/InstanceCVRPLIB.cpp',
                  'finding':'Author implementation maps raw node i+1 to internal index i, expects raw depot 1, and rounds Euclidean edge distances.', 'read_only_reviewed_date_utc':'2026-10-08'},
                 {'url':'https://github.com/vidalt/HGS-CVRP/blob/main/Program/Individual.cpp',
                  'finding':'Author reference-solution reader stores .sol customer integers directly as internal indices; complete route evaluation begins and ends at internal depot 0 and counts nonempty routes.', 'read_only_reviewed_date_utc':'2026-10-08'}]}
    (output/'INDEPENDENT_AUDIT.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps(result['summary'], ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
