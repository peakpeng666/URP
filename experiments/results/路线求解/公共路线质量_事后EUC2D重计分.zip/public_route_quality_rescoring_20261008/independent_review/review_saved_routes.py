#!/usr/bin/env python3
"""Independent saved-route arithmetic review. Never import or call solver code."""
import sys
sys.dont_write_bytecode = True
import json, math, hashlib, csv, statistics, resource, signal, time
from pathlib import Path
from collections import Counter, defaultdict
from decimal import Decimal, localcontext, ROUND_HALF_UP
from datetime import datetime, timezone

ROOT = Path('/workspace/shared/public_route_quality_rescoring_20261008')
OUT = Path(__file__).resolve().parent
ARMS = ('capacity_solver', 'waste_solver', 'pruned_solver')
resource.setrlimit(resource.RLIMIT_CPU, (30, 30))
resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
signal.alarm(60)
cpu0, wall0 = time.process_time(), time.monotonic()

def need(condition, message):
    if not condition:
        raise AssertionError(message)

def load(path):
    return json.loads(path.read_text())

def jsonl(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def canon(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)

def near(a, b):
    return math.isclose(a, b, rel_tol=1e-9, abs_tol=1e-9)

def parse_original(path):
    text = path.read_text()
    head, rest = text.split('NODE_COORD_SECTION')
    co, rest = rest.split('DEMAND_SECTION')
    de, tail = rest.split('DEPOT_SECTION')
    headers = dict((k.strip(), v.strip()) for k, v in (line.split(':', 1) for line in head.splitlines() if line.strip()))
    xy = {int(a): (Decimal(x), Decimal(y)) for a, x, y in (line.split() for line in co.splitlines() if line.strip())}
    demands = {int(a): int(q) for a, q in (line.split() for line in de.splitlines() if line.strip())}
    dimension = int(headers['DIMENSION'])
    need(headers['TYPE'] == 'CVRP' and headers['EDGE_WEIGHT_TYPE'] == 'EUC_2D', 'source metric/type')
    need(tail.split() == ['1', '-1', 'EOF'], 'source depot')
    need(set(xy) == set(demands) == set(range(1, dimension + 1)), 'source ids')
    need(demands[1] == 0, 'depot demand')
    return headers, xy, demands, int(headers['CAPACITY'])

def parse_reference(path):
    routes, cost = [], None
    for line in path.read_text().splitlines():
        if line.startswith('Route #'):
            label, customer_text = line.split(':')
            need(int(label.split('#')[1]) == len(routes) + 1, 'reference route labels')
            routes.append([0] + [int(x) for x in customer_text.split()] + [0])
        elif line.startswith('Cost '):
            need(cost is None, 'reference duplicated cost')
            cost = Decimal(line.split()[1])
        else:
            need(not line.strip(), 'reference unexpected line')
    need(routes and cost is not None, 'reference routes/cost missing')
    return routes, int(cost)

def calculate(routes, xy, demands, capacity, k):
    need(type(routes) is list and len(routes) == k, 'fixed K slots')
    visited, out = [], []
    for idx, route in enumerate(routes, 1):
        need(type(route) is list and len(route) >= 2, 'route type/length')
        need(all(type(v) is int for v in route), 'route id type')
        need(route[0] == route[-1] == 0, 'depot closure')
        need(all(v + 1 in xy and v != 0 for v in route[1:-1]), 'interior depot or bad id')
        visited.extend(v + 1 for v in route[1:-1])
        load_value = sum(demands[v + 1] for v in route[1:-1])
        need(load_value <= capacity, 'capacity')
        edges = []
        for a, b in zip(route[:-1], route[1:]):
            dx, dy = xy[a + 1][0] - xy[b + 1][0], xy[a + 1][1] - xy[b + 1][1]
            # Deliberately distinct from the producer's Fraction/isqrt implementation.
            with localcontext() as ctx:
                ctx.prec = 80
                decimal_distance = (dx * dx + dy * dy).sqrt()
                integer = int(decimal_distance.to_integral_value(rounding=ROUND_HALF_UP))
            floating = math.hypot(float(dx), float(dy))
            need(integer == math.floor(floating + 0.5), 'decimal and float rounding disagree')
            edges.append({'from_normalized': a, 'to_normalized': b, 'from_source': a+1, 'to_source': b+1,
                          'EUC_2D': integer, 'continuous': floating})
        out.append({'slot': idx, 'normalized_order': route, 'load': load_value, 'nonempty': len(route)>2,
                    'EUC_2D': sum(e['EUC_2D'] for e in edges), 'continuous': math.fsum(e['continuous'] for e in edges), 'edges': edges})
    need(Counter(visited) == Counter(range(2, len(xy)+1)), 'coverage not exactly once')
    return {'integer_cost': sum(r['EUC_2D'] for r in out), 'continuous_cost': math.fsum(e['continuous'] for r in out for e in r['edges']),
            'slot_count': len(out), 'nonempty_route_count': sum(r['nonempty'] for r in out),
            'empty_route_count': sum(not r['nonempty'] for r in out), 'routes': out}

def compare_routes(expected, scored):
    for key in ('integer_cost', 'slot_count', 'nonempty_route_count', 'empty_route_count'):
        need(expected[key] == scored[key], 'route total mismatch: ' + key)
    need(near(expected['continuous_cost'], scored['continuous_cost']), 'continuous total mismatch')
    need(len(expected['routes']) == len(scored['routes']), 'detail route count')
    for ours, theirs in zip(expected['routes'], scored['routes']):
        for key in ('slot', 'normalized_order', 'load', 'nonempty', 'EUC_2D'):
            need(ours[key] == theirs[key], 'route detail mismatch: ' + key)
        need(near(ours['continuous'], theirs['continuous']), 'route continuous detail')
        need(len(ours['edges']) == len(theirs['edges']), 'edge count')
        for oe, te in zip(ours['edges'], theirs['edges']):
            for key in ('from_normalized', 'to_normalized', 'from_source', 'to_source', 'EUC_2D'):
                need(oe[key] == te[key], 'edge mismatch: ' + key)
            need(near(oe['continuous'], te['continuous']), 'continuous edge mismatch')

def run():
    input_manifest = load(ROOT/'input_manifest/INPUT_MANIFEST.json')['inputs']
    frozen = load(ROOT/'freeze/FROZEN_FILES.json')
    for item in input_manifest:
        path = ROOT/item['snapshot_relative_path']
        need(path.stat().st_size == item['bytes'] and sha(path) == item['sha256'], 'input manifest mismatch')
        need(sha(Path(item['original_absolute_path'])) == item['sha256'], 'snapshot differs from original')
    for rel, digest in frozen.items():
        need(sha(ROOT/rel) == digest, 'frozen file changed: ' + rel)
    existing = load(ROOT/'input_manifest/ORIGINAL_TREES_BEFORE.json')
    for path, info in existing.items():
        need(sha(Path(path)) == info['sha256'], 'original file changed: ' + path)
    panel = load(ROOT/'inputs/preparation/freeze/SELECTED_PANEL.json')
    names = [p['name'] for p in panel]
    need(len(names) == len(set(names)) == 16, 'panel size/identity')
    raw = jsonl(ROOT/'inputs/execution/raw/results.jsonl')
    initial = [r for r in raw if r['endpoint'] == 'initialize_256']
    partition = [r for r in raw if r['endpoint'] == 'partition_256']
    need(len(raw) == 96 and len(initial) == len(partition) == 48, 'raw endpoint count')
    need(all(r['output'] is None and type(r['groups']) is list and r['independent_check']['continuous_cost'] is None for r in partition), 'partition groups/route distinction')
    expected_keys = Counter((n,a) for n in names for a in ARMS)
    need(Counter((r['instance_id'],r['arm']) for r in initial) == expected_keys, 'raw Cartesian coverage')
    scores = jsonl(ROOT/'raw/scores.jsonl')
    refs = jsonl(ROOT/'raw/reference_checks.jsonl')
    need(len(scores) == 48 and Counter((r['instance_id'],r['arm']) for r in scores) == expected_keys, 'scored Cartesian coverage')
    need(len(refs) == 16 and Counter(r['instance_id'] for r in refs) == Counter(names), 'reference coverage')
    score_by = {(r['instance_id'],r['arm']):r for r in scores}
    ref_by = {r['instance_id']:r for r in refs}
    input_by, geometry, reports, edge_count, reference_edge_count = {}, defaultdict(list), [], 0, 0
    for name in names:
        h,xy,demand,q = parse_original(ROOT/'inputs/preparation/raw/instances'/f'{name}.vrp')
        inp = load(ROOT/'inputs/execution/input'/f'{name}.json')
        input_by[name] = (xy,demand,q,inp)
        need(inp['coordinates'] == [[float(xy[i][0]),float(xy[i][1])] for i in range(1,len(xy)+1)], 'raw/input coordinates')
        need(inp['demands'] == [demand[i] for i in range(1,len(xy)+1)] and inp['capacity'] == q, 'raw/input demands/capacity')
        base = canon([[str(xy[i][0]),str(xy[i][1]),demand[i]] for i in range(1,len(xy)+1)])
        geometry[base].append(name)
        routes, claimed = parse_reference(ROOT/'inputs/preparation/raw/solutions'/f'{name}.sol')
        need(inp['K'] == len(routes), 'K not reference nonempty fleet')
        ref = calculate(routes,xy,demand,q,inp['K'])
        need(ref['integer_cost'] == claimed and ref['empty_route_count'] == 0, 'reference cost/nonempty fleet')
        compare_routes(ref,ref_by[name])
        reference_edge_count += sum(len(r['edges']) for r in ref['routes'])
    need(len(geometry) == 14, 'unique coordinate-demand bases')
    for row in initial:
        name, arm = row['instance_id'], row['arm']
        xy,demand,q,inp = input_by[name]
        saved = row['output']
        need(row['status'] == 'SUCCESS' and row['groups'] is None and type(saved['routes']) is list, 'explicit saved successful routes')
        ours = calculate(saved['routes'],xy,demand,q,inp['K'])
        scored = score_by[name,arm]
        need(scored['accepted'] is True, 'scored rejected valid saved route')
        compare_routes(ours,scored)
        edge_count += sum(len(r['edges']) for r in ours['routes'])
        need(scored['original_call_id'] == row['call_id'], 'call identity')
        need(sha(ROOT/'inputs/execution/input'/f'{name}.json') == row['input_sha256'] == scored['source_input_sha256'], 'input provenance')
        for original, label in ((saved['reported_cost'],'saved_original_continuous_reported_cost'),(row['independent_check']['continuous_cost'],'saved_original_continuous_checker_cost')):
            need(type(original) in (int,float) and math.isfinite(original) and near(original,ours['continuous_cost']), 'original continuous cost mismatch')
            need(original == scored[label], 'saved continuous value changed')
        refcost = ref_by[name]['integer_cost']
        gap = 100*(ours['integer_cost']-refcost)/refcost
        need(scored['reference_cost_EUC_2D'] == refcost and near(scored['gap_percent'],gap), 'reference gap mismatch')
        need(scored['gap_absolute'] == ours['integer_cost']-refcost and near(scored['gap_fraction'], gap/100), 'gap forms mismatch')
        need(scored['ordered_routes_sha256'] == hashlib.sha256(canon(saved['routes']).encode()).hexdigest(), 'saved route hash')
        need(scored['saved_output_sha256'] == hashlib.sha256(canon(saved).encode()).hexdigest(), 'saved output hash')
        reports.append({'instance_id':name,'arm':arm,'integer_cost':ours['integer_cost'],'reference_cost_EUC_2D':refcost,
                        'gap_percent':gap,'continuous_cost':ours['continuous_cost'],'slot_count':ours['slot_count'],
                        'nonempty_route_count':ours['nonempty_route_count'],'empty_route_count':ours['empty_route_count']})
    equality = []
    for name in names:
        rr = [r for r in initial if r['instance_id'] == name]
        equality.append({'instance_id':name,'ordered_routes_equal':all(r['output']['routes'] == rr[0]['output']['routes'] for r in rr),
                         'full_output_equal':all(r['output'] == rr[0]['output'] for r in rr)})
    summary = load(ROOT/'reports/SUMMARY.json')
    need(summary['tasks'] == 16 and summary['coordinate_demand_bases'] == 14 and summary['score_rows'] == summary['valid_score_rows'] == 48, 'summary coverage')
    need(summary['ordered_route_identical_task_count'] == sum(r['ordered_routes_equal'] for r in equality), 'summary route equality')
    need(summary['saved_output_object_identical_task_count'] == sum(r['full_output_equal'] for r in equality), 'summary output equality')
    metrics = {}
    for arm in ARMS:
        rs = [r for r in reports if r['arm'] == arm]; gaps = [r['gap_percent'] for r in rs]
        metric = {'accepted_instances':len(rs),'all_retained_instances':16,'mean_gap_percent':statistics.mean(gaps),
                  'median_gap_percent':statistics.median(gaps),'minimum_gap_percent':min(gaps),'maximum_gap_percent':max(gaps),
                  'summed_integer_cost':sum(r['integer_cost'] for r in rs),'summed_reference_cost':sum(r['reference_cost_EUC_2D'] for r in rs),
                  'pooled_cost_weighted_gap_percent':100*sum(r['integer_cost']-r['reference_cost_EUC_2D'] for r in rs)/sum(r['reference_cost_EUC_2D'] for r in rs),
                  'verified_route_slots':sum(r['slot_count'] for r in rs),'verified_nonempty_routes':sum(r['nonempty_route_count'] for r in rs),
                  'empty_route_slots':sum(r['empty_route_count'] for r in rs)}
        for key,value in metric.items(): need(near(value,summary['arm_summary'][arm][key]), 'summary statistic: '+key)
        metrics[arm] = metric
    below = [r for r in reports if r['integer_cost'] < r['reference_cost_EUC_2D']]
    need(len(below) == len(summary['below_reference_rows']), 'below reference rows summary')
    with (ROOT/'reports/PER_TASK_ARM.csv').open() as stream: csv_rows = list(csv.DictReader(stream))
    need(len(csv_rows)==48 and Counter((r['instance_id'],r['arm']) for r in csv_rows)==expected_keys, 'CSV coverage')
    for r in csv_rows:
        scored = score_by[r['instance_id'],r['arm']]
        need(all(r[key] == str(scored[key]) for key in r), 'CSV field differs from raw')
    with (ROOT/'reports/PER_TASK_ROUTE.csv').open() as stream: route_csv = list(csv.DictReader(stream))
    expected_routes = {(r['instance_id'],r['arm'],str(route['slot'])):route for r in scores for route in r['routes']}
    need(len(route_csv)==len(expected_routes), 'route CSV count')
    need(len({(r['instance_id'],r['arm'],r['slot']) for r in route_csv})==len(expected_routes), 'route CSV duplicates')
    for r in route_csv:
        exp = expected_routes[r['instance_id'],r['arm'],r['slot']]
        need(json.loads(r['normalized_order']) == exp['normalized_order'], 'route CSV order')
        need(all(r[k] == str(exp[k]) for k in ('slot','nonempty','load','continuous','EUC_2D')), 'route CSV details')
    finished = load(ROOT/'raw/FINISHED.json'); started = load(ROOT/'raw/STARTED.json')
    receipt = load(ROOT/'freeze/PRIVATE_SNAPSHOT_VERIFIED.json')
    need(receipt['owner_only_verified'] and receipt['remote_readback_sha256_verified'], 'PREEXEC receipt missing gate')
    need(receipt['frozen_files_sha256'] == sha(ROOT/'freeze/FROZEN_FILES.json'), 'PREEXEC frozen hash')
    need(datetime.fromisoformat(receipt['created_utc']) <= datetime.fromisoformat(started['created_utc']) <= datetime.fromisoformat(finished['created_utc']), 'gate chronology')
    need(finished['cpu_seconds'] < 30 and finished['wall_seconds'] < 60 and finished['maxrss_KiB'] < 512*1024, 'producer resource bounds')
    need(all(finished[k] == 0 for k in ('solver_calls','initializer_calls','optimization_calls','model_calls','network_calls')), 'producer prohibited calls')
    need(finished['status'] == 'COMPLETE_ALL_CHECKS_PASSED' and not finished['errors'], 'producer completion')
    need(finished['scores_sha256'] == sha(ROOT/'raw/scores.jsonl') and finished['reference_checks_sha256'] == sha(ROOT/'raw/reference_checks.jsonl'), 'raw hashes')
    relevant = [ROOT/p for p in ('source/score_once.py','source/report.py','freeze/SCORING_PROTOCOL.json','freeze/FROZEN_FILES.json','freeze/PRIVATE_SNAPSHOT_VERIFIED.json','input_manifest/INPUT_MANIFEST.json','raw/scores.jsonl','raw/reference_checks.jsonl','raw/STARTED.json','raw/FINISHED.json','reports/SUMMARY.json','reports/PER_TASK_ARM.csv','reports/PER_TASK_ROUTE.csv','reports/REPORT_ZH.txt')]
    for path, info in existing.items(): need(sha(Path(path)) == info['sha256'], 'original files changed during review')
    return {'status':'PASS_WITH_INFERENCE_LIMITATIONS' if not below else 'REQUIRES_BELOW_REFERENCE_REVIEW',
            'created_utc':datetime.now(timezone.utc).isoformat(),'review_method':'Independent Decimal(80-digit) sqrt + ROUND_HALF_UP on original .vrp nodes, fixed normalized c -> original c+1; original saved route order unchanged; producer code never imported or executed.',
            'tasks':16,'coordinate_demand_bases':14,'duplicate_base_groups':[v for v in geometry.values() if len(v)>1],
            'verified_initialize_rows':48,'unscored_partition_rows':48,'verified_reference_routes':sum(len(r['routes']) for r in refs),
            'verified_saved_route_slots':len(expected_routes),'verified_candidate_edges':edge_count,'verified_reference_edges':reference_edge_count,
            'all_input_snapshot_hashes_match':True,'input_files_checked':len(input_manifest),'frozen_files_checked':len(frozen),
            'original_existing_files_unchanged':len(existing),'all_EUC_2D_costs_and_edges_match':True,'all_original_continuous_cost_fields_match':True,
            'all_summary_and_CSV_values_match':True,'below_reference_rows':below,'arm_equality':equality,'arm_summary':metrics,
            'per_task_arm':reports,'reviewed_sha256':{str(p.relative_to(ROOT)):sha(p) for p in relevant},
            'producer_resources':{k:finished[k] for k in ('cpu_seconds','wall_seconds','maxrss_KiB')},
            'review_resources':{'cpu_seconds':time.process_time()-cpu0,'wall_seconds':time.monotonic()-wall0,'maxrss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},
            'review_solver_initializer_optimization_model_network_calls':0,
            'limitations':['Post-hoc measurement of saved continuous-objective initializations, not rerunning or optimizing under EUC_2D.',
                          'Fixed reference K slots and at most K nonempty routes; no minimum fleet proof.',
                          'Reference gap, not independent proof of original CVRP optimality gap; no SOTA or meter unit claim.',
                          '16 derived tasks share 14 coordinate-demand bases; identical arms are not independent samples.',
                          'Archive owner-only and remote-readback verification are accepted from the supplied signed-off receipt; this review does not independently access Google Drive.',
                          'Existing-file hashes checked, not a comprehensive OS or network security audit.']}

if __name__ == '__main__':
    result = run()
    with (OUT/'INDEPENDENT_REVIEW.json').open('x') as stream:
        json.dump(result,stream,indent=2,ensure_ascii=False,allow_nan=False);stream.write('\n')
    with (OUT/'INDEPENDENT_PER_TASK_ARM.csv').open('x',newline='') as stream:
        writer = csv.DictWriter(stream,fieldnames=list(result['per_task_arm'][0]));writer.writeheader();writer.writerows(result['per_task_arm'])
    print(json.dumps({k:result[k] for k in ('status','verified_initialize_rows','verified_saved_route_slots','verified_candidate_edges','below_reference_rows','arm_summary','review_resources')},ensure_ascii=False))
