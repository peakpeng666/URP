#!/usr/bin/env python3
"""Post-hoc arithmetic only. Never import, invoke, or re-run any solver."""
import sys
sys.dont_write_bytecode = True
import os, json, math, hashlib, re, resource, signal, time
from collections import Counter, defaultdict
from fractions import Fraction
from pathlib import Path
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]
ARMS = ('capacity_solver', 'waste_solver', 'pruned_solver')

def require(ok, reason):
    if not ok:
        raise ValueError(reason)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)

def digest(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()

def read(path):
    return json.loads(path.read_text())

def write_new(path, value):
    with path.open('x') as f:
        json.dump(value, f, indent=2, ensure_ascii=False, allow_nan=False)
        f.write('\n'); f.flush(); os.fsync(f.fileno())

def now():
    return datetime.now(timezone.utc).isoformat()

def parse_vrp(text):
    headers, xy, demands, depots = {}, {}, {}, []
    sections, section, ended, eof = [], None, False, False
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        require(not eof, 'data after EOF')
        if line == 'EOF':
            eof = True
        elif line in ('NODE_COORD_SECTION', 'DEMAND_SECTION', 'DEPOT_SECTION'):
            require(line not in sections, 'duplicate section'); sections.append(line); section = line
        elif section is None:
            require(':' in line, 'bad header')
            key, value = [x.strip() for x in line.split(':', 1)]
            require(key not in headers, 'duplicate header'); headers[key] = value
        elif section == 'NODE_COORD_SECTION':
            bits = line.split(); require(len(bits) == 3, 'bad coordinate')
            node = int(bits[0]); require(node not in xy, 'duplicate coordinate')
            xy[node] = (Fraction(bits[1]), Fraction(bits[2]))
        elif section == 'DEMAND_SECTION':
            bits = line.split(); require(len(bits) == 2, 'bad demand')
            node = int(bits[0]); require(node not in demands, 'duplicate demand'); demands[node] = int(bits[1])
        else:
            for token in line.split():
                require(not ended, 'data after depot terminator')
                node = int(token)
                if node == -1: ended = True
                else: depots.append(node)
    require(eof and ended, 'missing EOF/depot terminator')
    require(sections == ['NODE_COORD_SECTION', 'DEMAND_SECTION', 'DEPOT_SECTION'], 'bad sections')
    require(headers.get('TYPE') == 'CVRP' and headers.get('EDGE_WEIGHT_TYPE') == 'EUC_2D', 'wrong type')
    n, q = int(headers['DIMENSION']), int(headers['CAPACITY'])
    require(n > 1 and q > 0 and depots == [1], 'invalid dimension, capacity or depot')
    require(list(xy) == list(demands) == list(range(1, n + 1)), 'noncanonical original IDs')
    require(demands[1] == 0 and all(0 <= x <= q for x in demands.values()), 'bad demands')
    return headers, [xy[i] for i in range(1, n + 1)], [demands[i] for i in range(1, n + 1)], q

def parse_sol(text):
    routes, labels, cost = [], [], None
    for raw in text.splitlines():
        line = raw.strip()
        if not line: continue
        m = re.fullmatch(r'Route\s+#(\d+):\s*(.*)', line)
        if m:
            require(cost is None, 'route after cost')
            route = [int(x) for x in m.group(2).split()]
            require(route, 'empty reference route')
            routes.append([0] + route + [0]); labels.append(int(m.group(1)))
        else:
            m = re.fullmatch(r'Cost\s+([0-9]+(?:\.[0-9]+)?)', line)
            require(m is not None and cost is None, 'invalid or duplicate cost')
            cost = Fraction(m.group(1))
    require(routes and labels == list(range(1, len(routes) + 1)) and cost is not None, 'bad reference')
    return routes, cost

def edge(a, b):
    # Float convention requested, with an independent exact-rational half-up cross-check.
    dx, dy = a[0] - b[0], a[1] - b[1]
    continuous = math.hypot(float(dx), float(dy))
    rounded = math.floor(continuous + 0.5)
    squared = dx * dx + dy * dy
    num, den = squared.numerator, squared.denominator
    lo = math.isqrt(num // den)
    exact = lo + int(4 * num >= den * (2 * lo + 1) ** 2)
    require(rounded == exact, 'floating/exact rounding disagreement')
    return continuous, rounded

def validate_routes(routes, xy, demands, q, k, slots_required=True):
    require(type(routes) is list, 'missing ordered route array')
    if slots_required: require(len(routes) == k, 'not exactly K reference slots')
    else: require(len(routes) <= k, 'too many routes')
    counts, checked, continuous_edges = Counter(), [], []
    for number, route in enumerate(routes, 1):
        require(type(route) is list and len(route) >= 2, 'malformed route')
        require(all(type(c) is int for c in route), 'noninteger/bool node')
        require(route[0] == route[-1] == 0, 'route not depot-closed')
        require(all(1 <= c < len(demands) for c in route[1:-1]), 'depot interior or out-of-range ID')
        counts.update(route[1:-1]); load = sum(demands[c] for c in route[1:-1])
        require(load <= q, 'capacity violation')
        edges = []
        for a, b in zip(route, route[1:]):
            continuous, rounded = edge(xy[a], xy[b]); continuous_edges.append(continuous)
            edges.append({'from_normalized': a, 'to_normalized': b, 'from_source': a + 1,
                          'to_source': b + 1, 'continuous': continuous, 'EUC_2D': rounded})
        checked.append({'slot': number, 'normalized_order': route, 'nonempty': len(route) > 2,
                        'load': load, 'continuous': math.fsum(e['continuous'] for e in edges),
                        'EUC_2D': sum(e['EUC_2D'] for e in edges), 'edges': edges})
    require(counts == Counter(range(1, len(demands))), 'customer coverage not exact once')
    nonempty = sum(r['nonempty'] for r in checked)
    require(nonempty <= k, 'too many nonempty routes')
    return {'accepted': True, 'customer_coverage_exact_once': True, 'depot_closure_valid': True,
            'capacity_valid': True, 'slot_count': len(routes), 'nonempty_route_count': nonempty,
            'empty_route_count': len(routes) - nonempty, 'K_ref': k,
            'continuous_cost': math.fsum(continuous_edges), 'integer_cost': sum(r['EUC_2D'] for r in checked),
            'verifiable_route_count': len(checked), 'verifiable_nonempty_route_count': nonempty, 'routes': checked}

def self_tests():
    xy = [(Fraction(0), Fraction(0)), (Fraction(1), Fraction(0)), (Fraction(2), Fraction(0))]
    good = validate_routes([[0, 1, 2, 0], [0, 0]], xy, [0, 1, 2], 3, 2)
    require(good['integer_cost'] == 4 and good['empty_route_count'] == 1, 'empty slot/closure score')
    require(edge((Fraction(0), Fraction(0)), (Fraction('2.5'), Fraction(0)))[1] == 3, 'half-up')
    require(edge((Fraction(0), Fraction(0)), (Fraction('2.499'), Fraction(0)))[1] == 2, 'below half')
    cases = [([[0,1,1,0],[0,0]],3,2,'duplicate/missing'), ([[1,2,0],[0,0]],3,2,'open depot'),
             ([[0,1,0,2,0],[0,0]],3,2,'interior depot'), ([[0,1,3,0],[0,0]],3,2,'ID offset'),
             ([[0,1,2,0],[0,0]],2,2,'overload'), ([[0,1,2,0]],3,2,'slot count'),
             ([[0,True,2,0],[0,0]],3,2,'bool node')]
    for routes, q, k, label in cases:
        try: validate_routes(routes, xy, [0,1,2], q, k)
        except ValueError: pass
        else: raise ValueError('failed negative self-test: ' + label)
    return {'passed': True, 'positive_tests': 3, 'negative_rejections': [x[3] for x in cases], 'live_inputs_read': False}

def verify_manifest():
    manifest = read(ROOT / 'input_manifest/INPUT_MANIFEST.json')
    for item in manifest['inputs']:
        p = ROOT / item['snapshot_relative_path']
        require(p.stat().st_size == item['bytes'] and sha(p) == item['sha256'], 'snapshot hash changed: ' + str(p))
    for rel, expected in read(ROOT / 'freeze/FROZEN_FILES.json').items():
        require(sha(ROOT / rel) == expected, 'frozen protocol/source changed: ' + rel)
    return len(manifest['inputs'])

def originals_unchanged():
    changed = []
    for path, info in read(ROOT / 'input_manifest/ORIGINAL_TREES_BEFORE.json').items():
        p = Path(path)
        if not p.is_file() or sha(p) != info['sha256']: changed.append(path)
    return {'existing_files_checked': len(read(ROOT / 'input_manifest/ORIGINAL_TREES_BEFORE.json')),
            'changed_or_missing': changed, 'all_unchanged': not changed,
            'new_files_not_attributed_to_this_process': 'Not evaluated; old-tree writes are blocked.'}

def main():
    resource.setrlimit(resource.RLIMIT_CPU, (30, 30))
    resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
    signal.alarm(60)
    cpu0, wall0 = time.process_time(), time.monotonic()
    if sys.argv[1:] == ['--self-test-only']:
        print(json.dumps(self_tests())); return
    require(sys.argv[1:] == ['--execute-once'], 'explicit --execute-once required')
    receipt = read(ROOT / 'freeze/PRIVATE_SNAPSHOT_VERIFIED.json')
    require(receipt.get('remote_readback_sha256_verified') is True and receipt.get('owner_only_verified') is True,
            'private remote byte-level readback gate absent')
    require(receipt.get('frozen_files_sha256') == sha(ROOT / 'freeze/FROZEN_FILES.json'), 'receipt freeze mismatch')
    verified_input_files = verify_manifest()
    old_before = originals_unchanged(); require(old_before['all_unchanged'], 'old input tree changed before scoring')
    denied = []
    def audit(event, args):
        if event in ('socket.__new__', 'subprocess.Popen', 'os.system'):
            denied.append(event); raise PermissionError('network/process execution forbidden')
        if event == 'open' and not isinstance(args[0], int):
            path, mode, flags = args
            flags = flags if isinstance(flags, int) else 0
            write = bool(flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND))
            if write and not Path(os.fsdecode(path)).resolve().is_relative_to(ROOT / 'raw'):
                denied.append(str(path)); raise PermissionError('only new raw output writes allowed')
    sys.addaudithook(audit)
    write_new(ROOT / 'raw/STARTED.json', {'created_utc': now(), 'phase': 'post_hoc_route_arithmetic',
              'source_sha256': sha(Path(__file__)), 'verified_input_files': verified_input_files,
              'limits': {'cpu_seconds': 30, 'wall_seconds': 60, 'address_space_MiB': 512},
              'solver_calls': 0, 'initializer_calls': 0, 'optimization_calls': 0})
    tests = self_tests()
    e, p = ROOT / 'inputs/execution', ROOT / 'inputs/preparation'
    panel = read(p / 'freeze/SELECTED_PANEL.json'); names = [x['name'] for x in panel]
    require(len(names) == len(set(names)) == 16, 'panel not all 16')
    rows = [json.loads(s) for s in (e / 'raw/results.jsonl').read_text().splitlines()]
    require(len(rows) == 96, 'original call count changed')
    init = [r for r in rows if r['endpoint'] == 'initialize_256']
    require(len(init) == 48 and sum(r['endpoint'] == 'partition_256' for r in rows) == 48, 'wrong endpoints')
    require(Counter((r['instance_id'],r['arm']) for r in init) == Counter((n,a) for n in names for a in ARMS), 'missing/duplicate task arm')
    lookup = {(r['instance_id'],r['arm']): r for r in init}
    prior_audit = read(p / 'independent_review/INDEPENDENT_AUDIT.json')
    require(prior_audit['status'] == 'PASS_WITH_INFERENCE_LIMITATIONS', 'prior reference audit not passed')
    audit_checks = {x['name']:x for x in prior_audit['checks']}
    completed, errors = [], []
    with (ROOT / 'raw/scores.jsonl').open('x') as out, (ROOT / 'raw/reference_checks.jsonl').open('x') as refout:
        for slot in panel:
            name = slot['name']; base = None; ref = None; context_error = None
            try:
                inp = read(e / 'input' / (name + '.json')); norm = read(p / 'normalized' / (name + '.json'))
                witness = read(p / 'witness' / (name + '.json'))
                headers, xy, demands, q = parse_vrp((p / 'raw/instances' / (name + '.vrp')).read_text())
                require(headers['NAME'] == name and len(demands) - 1 == slot['n_customers'], 'instance identity mismatch')
                require(inp['coordinates'] == [[float(a),float(b)] for a,b in xy] == norm['coordinates'], 'coordinate mapping mismatch')
                require(inp['demands'] == demands == norm['demands'] and inp['capacity'] == q == norm['capacity'], 'demand/capacity mismatch')
                rr, claimed = parse_sol((p / 'raw/solutions' / (name + '.sol')).read_text())
                k = len(rr); require(inp['K'] == norm['K'] == witness['K_ref'] == k, 'reference K mismatch')
                require([r[1:-1] for r in rr] == witness['normalized_customer_routes'], 'reference order mismatch')
                ref = validate_routes(rr, xy, demands, q, k)
                require(ref['integer_cost'] == claimed == witness['reference_reported_cost'] == witness['independently_recomputed_EUC_2D_cost'] == audit_checks[name]['reference_recomputed_cost_EUC_2D'], 'reference cost mismatch')
                require(k == audit_checks[name]['K_reference_nonempty_routes'], 'independent audit K mismatch')
                require(sha(p/'raw/instances'/(name+'.vrp')) == norm['source_instance_sha256'], 'raw instance provenance mismatch')
                require(sha(p/'raw/solutions'/(name+'.sol')) == norm['source_reference_sha256'] == witness['source_solution_sha256'], 'raw reference provenance mismatch')
                ref.update(instance_id=name, public_reference_claimed_cost=int(claimed), independently_verified=True,
                           instance_url=slot['instance_url'], solution_url=slot['solution_url'],
                           exact_rounding_crosscheck=True, fixed_mapping='normalized/sol c -> original raw c+1; depot 0 -> raw 1')
                refout.write(canonical(ref)+'\n');refout.flush();os.fsync(refout.fileno())
                base = (inp, xy, demands, q, k)
            except Exception as exc:
                context_error = type(exc).__name__ + ': ' + str(exc)
                refout.write(canonical({'instance_id': name,'accepted':False,'error':context_error})+'\n');refout.flush();os.fsync(refout.fileno())
            for arm in ARMS:
                old = lookup[name,arm]
                row = {'instance_id':name,'arm':arm,'original_call_id':old['call_id'],
                       'selection_slot':slot['selection_slot'],'family':slot['family'],
                       'phase':'post_hoc_standardized_quality_not_preregistered_capacity_endpoint',
                       'saved_original_continuous_reported_cost':(old.get('output') or {}).get('reported_cost'),
                       'saved_original_continuous_checker_cost':(old.get('independent_check') or {}).get('continuous_cost'),
                       'original_status':old['status'],'original_fallback_triggered':old['diagnostic'].get('fallback_triggered'),
                       'source_input_sha256':old['input_sha256'],'reference_cost_EUC_2D':ref['integer_cost'] if ref else None,
                       'accepted':False,'gap_fraction':None,'gap_percent':None,'integer_cost':None,
                       'verifiable_route_count':0,'verifiable_nonempty_route_count':0}
                try:
                    require(context_error is None, context_error)
                    inp,xy,demands,q,k = base
                    require(old['status']=='SUCCESS' and old['groups'] is None, 'not successful saved initialize')
                    require(sha(e/'input'/(name+'.json')) == old['input_sha256'], 'original input hash mismatch')
                    require(isinstance(old['output'],dict) and 'routes' in old['output'], 'missing original ordered routes')
                    routes = old['output']['routes']; check = validate_routes(routes,xy,demands,q,k)
                    for saved in (row['saved_original_continuous_reported_cost'],row['saved_original_continuous_checker_cost']):
                        require(type(saved) in (int,float) and math.isfinite(saved), 'missing/nonfinite old continuous cost')
                        require(abs(check['continuous_cost']-saved) <= 1e-9*max(1,abs(saved)), 'continuous route/cost mismatch')
                    delta = check['integer_cost'] - ref['integer_cost']
                    row.update(check)
                    row.update(ordered_routes_sha256=digest(routes), saved_output_sha256=digest(old['output']),
                               gap_absolute=delta, gap_fraction=delta/ref['integer_cost'],
                               gap_percent=100*delta/ref['integer_cost'], reference_cost_EUC_2D=ref['integer_cost'],
                               exact_rounding_crosscheck=True,
                               below_reference_requires_review=delta<0,
                               below_reference_claim='No optimality or SOTA claim; mapping, rounding and coverage checked' if delta<0 else None,
                               reference_optimality_proven_by_this_score=False)
                except Exception as exc:
                    row['error'] = type(exc).__name__ + ': ' + str(exc); errors.append({'instance_id':name,'arm':arm,'error':row['error']})
                out.write(canonical(row)+'\n');out.flush();os.fsync(out.fileno());completed.append(row)
    old_after = originals_unchanged()
    status = 'COMPLETE_ALL_CHECKS_PASSED' if not errors and old_after['all_unchanged'] else 'COMPLETE_WITH_FAILURES'
    write_new(ROOT/'raw/FINISHED.json', {'created_utc':now(),'status':status,'scored_rows':len(completed),
              'accepted_rows':sum(r['accepted'] for r in completed),'retained_tasks':names,
              'errors':errors,'self_tests':tests,'original_trees_after':old_after,
              'cpu_seconds':time.process_time()-cpu0,'wall_seconds':time.monotonic()-wall0,
              'maxrss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
              'denied_action_attempts':denied,'solver_calls':0,'initializer_calls':0,
              'optimization_calls':0,'model_calls':0,'network_calls':0,
              'scores_sha256':sha(ROOT/'raw/scores.jsonl'),
              'reference_checks_sha256':sha(ROOT/'raw/reference_checks.jsonl')})
    print(json.dumps({'status':status,'rows':len(completed),'accepted':sum(r['accepted'] for r in completed),
                      'cpu_seconds':time.process_time()-cpu0,'wall_seconds':time.monotonic()-wall0}))

if __name__ == '__main__': main()
