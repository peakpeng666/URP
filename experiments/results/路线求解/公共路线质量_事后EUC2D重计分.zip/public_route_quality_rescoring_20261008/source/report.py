#!/usr/bin/env python3
"""Summarize already-written scoring rows; no route scoring or optimization."""
import sys
sys.dont_write_bytecode = True
import json, csv, math, statistics, hashlib
from pathlib import Path
from collections import defaultdict
from datetime import datetime, timezone
R = Path(__file__).resolve().parents[1]
def read(p): return json.loads(p.read_text())
def write(p,v):
    with p.open('x') as f: json.dump(v,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')
rows = [json.loads(s) for s in (R/'raw/scores.jsonl').read_text().splitlines()]
finished = read(R/'raw/FINISHED.json')
assert len(rows) == 48
byname = defaultdict(list)
for r in rows: byname[r['instance_id']].append(r)
per_instance=[]
for name, rs in byname.items():
    good=[x for x in rs if x['accepted']]
    per_instance.append({'instance_id':name,'selection_slot':rs[0]['selection_slot'],
        'arm_rows':len(rs),'accepted_arm_rows':len(good),
        'identical_ordered_route_arrays':len(good)==3 and len({r['ordered_routes_sha256'] for r in good})==1,
        'identical_saved_output_objects':len(good)==3 and len({r['saved_output_sha256'] for r in good})==1,
        'identical_EUC_2D_cost':len(good)==3 and len({r['integer_cost'] for r in good})==1,
        'min_gap_percent':min((r['gap_percent'] for r in good),default=None),
        'max_gap_percent':max((r['gap_percent'] for r in good),default=None)})
per_instance.sort(key=lambda x:x['selection_slot'])
arm_summary={}
for arm in ('capacity_solver','waste_solver','pruned_solver'):
    rs=[r for r in rows if r['arm']==arm and r['accepted']]
    gaps=[r['gap_percent'] for r in rs]
    arm_summary[arm]={'accepted_instances':len(rs),'all_retained_instances':16,
        'mean_gap_percent':statistics.mean(gaps) if gaps else None,'median_gap_percent':statistics.median(gaps) if gaps else None,
        'minimum_gap_percent':min(gaps) if gaps else None,'maximum_gap_percent':max(gaps) if gaps else None,
        'summed_integer_cost':sum(r['integer_cost'] for r in rs),'summed_reference_cost':sum(r['reference_cost_EUC_2D'] for r in rs),
        'pooled_cost_weighted_gap_percent':100*sum(r['integer_cost']-r['reference_cost_EUC_2D'] for r in rs)/sum(r['reference_cost_EUC_2D'] for r in rs) if rs else None,
        'verified_route_slots':sum(r['verifiable_route_count'] for r in rs),
        'verified_nonempty_routes':sum(r['verifiable_nonempty_route_count'] for r in rs),
        'empty_route_slots':sum(r['empty_route_count'] for r in rs)}
summary={'created_utc':datetime.now(timezone.utc).isoformat(),'status':finished['status'],
    'phase':'post_hoc_standardized_scoring_not_original_capacity_primary_endpoint',
    'tasks':16,'coordinate_demand_bases':14,'score_rows':48,'valid_score_rows':sum(r['accepted'] for r in rows),
    'ordered_route_identical_task_count':sum(x['identical_ordered_route_arrays'] for x in per_instance),
    'saved_output_object_identical_task_count':sum(x['identical_saved_output_objects'] for x in per_instance),
    'arm_summary':arm_summary,'per_instance':per_instance,
    'below_reference_rows':[{'instance_id':r['instance_id'],'arm':r['arm'],'gap_percent':r['gap_percent']} for r in rows if r.get('below_reference_requires_review')],
    'inference_limits':['All 16 frozen tasks retained, from 14 unique indexed coordinate-demand bases; not independent random replicates.',
       'Fixed K_ref slots, at most K_ref nonempty routes, with empty [0,0] slots permitted. K_ref is reference fleet count, not minimum fleet proof.',
       'Reference gap uses edge-rounded EUC_2D on both saved ordered routes and independently verified public reference routes; it is not an independently established optimality gap.',
       'The routes were built under continuous Euclidean objective. This is post-hoc measurement, not a rerun under integer distance.',
       'No physical unit is declared; costs are in original coordinate-based distance units, not assumed meters.',
       'No significance, SOTA, causal route-ordering-only explanation, or universal algorithm ranking is claimed.']}
write(R/'reports/SUMMARY.json',summary)
fields=['instance_id','arm','original_call_id','accepted','saved_original_continuous_reported_cost','saved_original_continuous_checker_cost','continuous_cost','integer_cost','reference_cost_EUC_2D','gap_absolute','gap_percent','K_ref','slot_count','nonempty_route_count','empty_route_count','verifiable_route_count','verifiable_nonempty_route_count','original_fallback_triggered','ordered_routes_sha256']
with (R/'reports/PER_TASK_ARM.csv').open('x',newline='') as f:
    w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(rows)
with (R/'reports/PER_TASK_ROUTE.csv').open('x',newline='') as f:
    w=csv.DictWriter(f,fieldnames=['instance_id','arm','slot','nonempty','load','continuous','EUC_2D','normalized_order']);w.writeheader()
    for r in rows:
        for route in r.get('routes',[]): w.writerow({**{k:r[k] for k in ('instance_id','arm')},**{k:route[k] for k in ('slot','nonempty','load','continuous','EUC_2D')},'normalized_order':json.dumps(route['normalized_order'],separators=(',',':'))})
lines=['公开CVRP派生任务：已保存初始化路线的事后标准化质量评分','',
'性质与边界',
'- 这是新的事后算术评分，不是原预注册容量主终点，也没有重新运行solver、initialize、模型或优化。',
'- 原96次调用含48次partition_256和48次initialize_256。仅后者的output.routes保存真实有序路线；前者的groups不作为路线，也不评分。',
'- 每条原路线保持原访问顺序，以原文件EUC_2D逐边floor(hypot(dx,dy)+0.5)计分，并用精确有理数平方距离/整数比较交叉检查。',
'- 原连续成本来自raw.output.reported_cost；raw.independent_check.continuous_cost另列，事后连续hypot重算也单列。不把delta操作计数当作成本。',
'- 成本/原坐标距离单位；未假定米等物理单位。',
'- 公共.sol编号c固定映射至.vrp节点c+1，depot 0映射至原节点1，没有尝试偏移来拟合参考成本。',
'- K取独立验证参考解非空车辆数，不取文件名k；严格验证原输出有K个槽位，允许空路线[0,0]，非空车辆数不超过K。',
'- 检查每个客户恰好一次、无内部depot、首尾depot闭合、每路线载荷<=Q；参考路线同样检查并与原.sol成本及独立审查结果相符。','',
'覆盖与结果',f"- 保留全部16固定K参考车队派生任务，48臂×任务记录中{summary['valid_score_rows']}条通过；16任务仅14个坐标与需求底本。",
'- 重复底本：E-n51-k5与P-n51-k10；E-n76-k7与P-n76-k4。不同容量/车队派生任务仍保留，不能作为独立重复。',
f"- 三臂有序route数组完全一致的任务：{summary['ordered_route_identical_task_count']}/16；连同原reported_cost的完整output对象相同：{summary['saved_output_object_identical_task_count']}/16。"]
for arm,v in arm_summary.items():
    lines.append(f"- {arm}: 有效{v['accepted_instances']}/16，平均reference gap {v['mean_gap_percent']:.6f}%，中位数{v['median_gap_percent']:.6f}%，范围{v['minimum_gap_percent']:.6f}%至{v['maximum_gap_percent']:.6f}%；可验证非空路线{v['verified_nonempty_routes']}，空槽{v['empty_route_slots']}。")
lines += ['', '全部16任务明细（各臂逐行完整数值见PER_TASK_ARM.csv）','实例 | 臂 | 原连续reported_cost | 事后EUC_2D整数成本 | 公共ref整数成本 | gap% | 可验证非空/槽位']
for item in per_instance:
    rs=byname[item['instance_id']]
    display=[rs[0]] if item['identical_saved_output_objects'] else rs
    for r in display:
        label='三臂相同' if item['identical_saved_output_objects'] else r['arm']
        if r['accepted']:
            lines.append(f"{r['instance_id']} | {label} | {r['saved_original_continuous_reported_cost']:.12f} | {r['integer_cost']} | {r['reference_cost_EUC_2D']} | {r['gap_percent']:.6f} | {r['verifiable_nonempty_route_count']}/{r['verifiable_route_count']}")
        else: lines.append(f"{r['instance_id']} | {label} | 不可验证：{r.get('error')}")
lines += ['', '解释与下一步',
'- reference gap定义为100×(同标准重算路线成本−同标准公共参考成本)/公共参考成本；不是此研究证明的原CVRP最优性差距。',
'- 若三臂完全相同，表示本面板中保存的初始化路线无质量差异；不能用它们的CPU微秒差异声称路线更优。',
'- 与参考路线存在成本差距可以支持把下一项研究转向路径/路线质量改进，但此评分不能分离组内访问顺序和客户分组的贡献，不能证明仅优化顺序就足够。',
'- 不自动增加算法变体、优化实验、求解预算或子集。全部16任务一起报告，均值以16任务计算，不把相同的三臂当48个独立样本。',
'- 小于参考成本的记录必须先复核编号、逐边舍入和覆盖，仍不得声称SOTA；本次此类记录数：'+str(len(summary['below_reference_rows']))+'。',
'', '执行审计',f"- 纯评分CPU {finished['cpu_seconds']:.6f}s，wall {finished['wall_seconds']:.6f}s，maxrss {finished['maxrss_KiB']} KiB；预算CPU30s/wall60s/内存512MiB。",
f"- 旧目录已有{finished['original_trees_after']['existing_files_checked']}个文件哈希前后一致：{finished['original_trees_after']['all_unchanged']}。",
'- source、协议、输入hash在评分前冻结并通过私有归档远端回读；评分raw先按未审结果备份，再生成本报告。独立审查状态另见review文件。']
(R/'reports/REPORT_ZH.txt').write_text('\n'.join(lines)+'\n')
print(json.dumps({k:summary[k] for k in ('valid_score_rows','ordered_route_identical_task_count','saved_output_object_identical_task_count','arm_summary')},ensure_ascii=False))
