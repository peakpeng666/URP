"""Read-only arithmetic/integrity audit. Never imports or calls author solver code."""
import time,resource
START_CPU=time.process_time(); START_WALL=time.perf_counter()
resource.setrlimit(resource.RLIMIT_CPU,(60,60))
import json,hashlib,zipfile,re,math,statistics,collections,random,decimal,datetime,pathlib
P=pathlib.Path('/workspace/shared/selector_budget_split_20261007')
A=pathlib.Path('/workspace/shared/selector_budget_split_audit_20261007')
Z=P.with_suffix('.zip')
checks=[]; issues=[]
def check(name,condition,detail=None):
    row={'name':name,'passed':bool(condition)}
    if detail is not None:row['detail']=detail
    checks.append(row)
    if not condition:issues.append(row)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(n):return json.loads((P/n).read_text())
def lines(n):return [json.loads(x) for x in (P/n).read_text().splitlines()]
def near(a,b,tol=1e-9):return a is not None and b is not None and abs(a-b)<=tol

def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def mean(x):return statistics.mean(x)
def write(n,d): (A/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
initial_files={str(x.relative_to(P)):sha(x) for x in P.rglob('*') if x.is_file()}
freeze=read('protocol/freeze.json'); events=lines('raw/events.jsonl')
check('expected freeze SHA256',sha(P/'protocol/freeze.json')=='89a8c9d90ab01678400c46c6ad98ce50739028bc1baef7f9700995ca9de60dd2')
check('82 frozen file hashes unchanged',len(freeze['sha256'])==82 and all(sha(P/k)==v for k,v in freeze['sha256'].items()),{'n':len(freeze['sha256'])})
manifest={line[66:]:line[:64] for line in (P/'SHA256SUMS.txt').read_text().splitlines()}
check('final manifest every entry matches',all(sha(P/k)==v for k,v in manifest.items()),{'n':len(manifest)})
exclude={'SHA256SUMS.txt','evidence/shell_time.txt','raw/stdout.log','raw/stderr.log'}
check('final manifest complete apart from declared excluded receipts',set(initial_files)-set(manifest)==exclude,sorted(set(initial_files)-set(manifest)))
check('expected final ZIP SHA256',sha(Z)=='4114ed234815fe12b401024d48c0a38e1ab5e1184d1d3768efe35837933312f5')
with zipfile.ZipFile(Z) as z:
    check('ZIP CRC',z.testzip() is None)
    expected={f'{P.name}/{n}' for n in set(manifest)|{'SHA256SUMS.txt'}}
    check('ZIP exact declared membership',set(z.namelist())==expected and len(z.namelist())==len(expected),{'members':len(z.namelist())})
    check('ZIP bytes match final directory',all(z.read(f'{P.name}/{n}')==(P/n).read_bytes() for n in set(manifest)|{'SHA256SUMS.txt'}))
seal=events[0];starts=[e for e in events if e['event']=='request_started'];ends=[e for e in events if e['event']=='request_finished'];skips=[e for e in events if e['event']=='fallback_skipped']
check('seal before every target call',seal['event']=='frozen_before_first_target' and seal['freeze_sha256']==sha(P/'protocol/freeze.json') and seal['solver_calls_before_freeze']==0 and all(seal['monotonic_ns']<e['monotonic_ns'] and seal['utc']<e['utc'] for e in starts),{'freeze_json_utc':freeze['frozen_utc'],'seal_event_utc':seal['utc'],'first_target_utc':starts[0]['utc'],'lead_ms':(starts[0]['monotonic_ns']-seal['monotonic_ns'])/1e6})
check('event sequence and clocks monotone',all(e['event_sequence']==i for i,e in enumerate(events)) and all(a['monotonic_ns']<=b['monotonic_ns'] and a['process_cpu_s']<=b['process_cpu_s'] for a,b in zip(events,events[1:])))
records=read('inputs/instances.json'); ds={d['id']:d for d in records};geoms=read('protocol/geometries.json'); features=read('protocol/features.json');predictions=read('protocol/predictions_sealed.json');model=read('protocol/source_training_models.json')['spatial_1nn8'];requests=read('protocol/requests.json');schedule=read('protocol/policy_schedule.json');results=lines('raw/results.jsonl');policies=lines('raw/policy_results.jsonl');cc=lines('raw/continuous_checks.jsonl');witnesses=read('evidence/witness_checks.json');im=read('protocol/input_manifest.json');protocol=read('protocol/protocol.json');summary=read('reports/summary.json');overhead=read('evidence/feature_prediction_overhead.json');resources=read('evidence/run_resources.json')
ri={r['run_id']:r for r in results};pl={(r['instance'],r['policy']):r for r in policies};cii={c['run_id']:c for c in cc}; wi={w['instance']:w for w in witnesses}
arms=['selector100_pci400','selector250_pci250','selector400_pci100','fixed_pci500'];splits={arms[0]:(100,400),arms[1]:(250,250),arms[2]:(400,100)}
check('24 geometries 48 width-paired problems',len(records)==len(ds)==48 and len(geoms)==24 and collections.Counter(d['geometry_id'] for d in records)=={g['geometry_id']:2 for g in geoms} and all(sorted(d['width'] for d in records if d['geometry_id']==g['geometry_id'])==[20,80] for g in geoms))
check('balanced four geometry families',collections.Counter(g['family'] for g in geoms)=={'radial_ring':6,'corner_clusters':6,'offcenter_uniform':6,'oblique_corridor':6})
check('fixed problem constants',all(len(d['nodes'])==101 and d['vehicles']==10 and d['capacity']==100 and d['nodes'][0]['due']==2000 and all(1<=n['demand']<=10 and n['service']==2 and n['due']-n['ready']==d['width'] for n in d['nodes'][1:]) for d in records))
original={}
for d in records:
    txt=(P/'inputs'/f"{d['id']}.txt").read_text();rows=[]
    for line in txt.splitlines():
        if re.fullmatch(r'\s*-?\d+(?:\s+-?\d+){6}\s*',line):rows.append(list(map(int,line.split())))
    keys=['id','x','y','demand','ready','due','service'];nd=[dict(zip(keys,row)) for row in rows]
    original[d['id']]={n['id']:n for n in nd}
    check('original text equals instance JSON '+d['id'],nd==d['nodes'] and txt.splitlines()[0]==d['id'])
newcoords={digest(sorted([[n['x'],n['y']] for n in d['nodes'][1:]])) for d in records}
newgh={digest({'depot':[d['nodes'][0]['x'],d['nodes'][0]['y']],'customers':sorted([[n['x'],n['y']] for n in d['nodes'][1:]])}) for d in records}
newseeds={g['seed'] for g in geoms}
check('recomputed 24 distinct geometry coordinates/hash/seeds',len(newcoords)==len(newgh)==len(newseeds)==24 and newgh=={g['geometry_sha256'] for g in geoms})
nonoverlap=[]
for name,n in [('diverse_geometry_selection_20261007',64),('selector_budgeted_recovery_20261007',48)]:
    p=P.parent/name;oldg=json.loads((p/'protocol/geometries.json').read_text()); oldd=json.loads((p/'inputs/instances.json').read_text())
    oc={digest(sorted([[node['x'],node['y']] for node in d['nodes'][1:]])) for d in oldd};og={digest({'depot':[d['nodes'][0]['x'],d['nodes'][0]['y']],'customers':sorted([[node['x'],node['y']] for node in d['nodes'][1:]])}) for d in oldd};os={g['seed'] for g in oldg}
    rec={'prior':name,'geometry_n':n,'coordinate_overlap':sorted(newcoords&oc),'geometry_overlap':sorted(newgh&og),'seed_overlap':sorted(newseeds&os)};nonoverlap.append(rec)
    check('no identity overlap '+name,len(oc)==len(og)==len(os)==n and not(newcoords&oc or newgh&og or newseeds&os),rec)
check('prior-source provenance hashes match',all(sha(pathlib.Path(x['path']))==x['sha256'] for x in read('evidence/source_provenance.json')))
check('frozen original model preserved',sha(P/'protocol/source_training_models.json')==sha(P.parent/'diverse_geometry_selection_20261007/raw/training_models.json')==sha(P.parent/'frozen_selector_transfer_20261007/protocol/training_models.json')=='52328f15e700562453095399fa10a4dd895af7ed70c89672c22f1b2d08d44ef2')
check('eight features and original 80 training instances/250ms labels',len(model['features'])==8 and len(model['train_instances'])==80 and set(model['labels'].values())<=set(['pci250','pca250','sav250']))
feature_errors=[];pred_errors=[]
for d in records:
    n=d['id'];ns=d['nodes'][1:];xs=[v['x'] for v in ns];ys=[v['y'] for v in ns];dem=[v['demand'] for v in ns];mx=mean(xs);my=mean(ys);vx=mean([(v-mx)**2 for v in xs]);vy=mean([(v-my)**2 for v in ys]);cov=mean([(x-mx)*(y-my) for x,y in zip(xs,ys)]);trace=vx+vy;rms=math.sqrt(trace);h=d['nodes'][0]['due']-d['nodes'][0]['ready'];dep=d['nodes'][0]
    nf={'capacity_over_total_demand':d['capacity']/sum(dem),'demand_population_cv':statistics.pstdev(dem)/mean(dem),'mean_window_width_over_depot_duration':mean([v['due']-v['ready'] for v in ns])/h,'mean_service_over_depot_duration':mean([v['service'] for v in ns])/h,'rms_radius_over_horizon':rms/h,'mean_nn_over_rms_radius':mean([min(math.hypot(a['x']-b['x'],a['y']-b['y']) for b in ns if a['id']!=b['id']) for a in ns])/rms,'covariance_anisotropy':(trace+math.sqrt((vx-vy)**2+4*cov*cov))/(2*trace),'depot_centroid_over_rms_radius':math.hypot(mx-dep['x'],my-dep['y'])/rms}
    if not all(near(nf[f],features[n][f],1e-12) for f in model['features']):feature_errors.append(n)
    v=[(nf[f]-model['feature_means'][f])/model['feature_scales'][f] for f in model['features']]
    distances={k:sum((a-b)**2 for a,b in zip(v,w)) for k,w in model['vectors'].items()};best=min(distances.values());ties=sorted(k for k,x in distances.items() if x<=best+1e-12);neighbor=min(ties,key=lambda k:(model['labels'][k]!=model['sbs'],k));pp=predictions[n]
    if not (pp['selected_config']==model['labels'][neighbor] and pp['neighbor']==neighbor and near(pp['neighbor_squared_distance'],distances[neighbor]) and pp['neighbor_tie_count']==len(ties) and pp['neighbor_tie_instances']==ties):pred_errors.append(n)
check('48 independently recomputed feature vectors',not feature_errors,feature_errors);check('48 independently recomputed sealed predictions',not pred_errors,{'mismatches':pred_errors,'configs':dict(collections.Counter(p['selected_config'] for p in predictions.values()))})
# Independent Decimal replay from text inputs, never reuse solver matrices/checker code.
decimal.getcontext().prec=60;sqrtcache={}
def route_replay(name,routes,objective=None):
    nodes=original[name];errs=[];seen=[];total=decimal.Decimal(0);obj=0;arcs=0;minmargin=None;vehicles=[]
    if not isinstance(routes,list):return {'valid':False,'errors':['no routes'],'distance':None}
    if len(routes)>10:errs.append('fleet')
    for rr in routes:
        r=rr['nodes'] if isinstance(rr,dict) else rr
        if isinstance(rr,dict):vehicles.append(rr.get('vehicle'))
        if not isinstance(r,list) or len(r)<3 or r[0]!=0 or r[-1]!=0 or 0 in r[1:-1] or any(type(x)!=int or x not in nodes for x in r):errs.append('route structure');continue
        seen.extend(r[1:-1]);load=sum(nodes[i]['demand'] for i in r[1:-1])
        if load>100:errs.append('capacity')
        now=decimal.Decimal(nodes[0]['ready'])
        for a,b in zip(r,r[1:]):
            x,y=nodes[a],nodes[b];sq=(x['x']-y['x'])**2+(x['y']-y['y'])**2
            if sq not in sqrtcache:sqrtcache[sq]=decimal.Decimal(sq).sqrt()
            leg=sqrtcache[sq];arcs+=1;total+=leg;obj+=int((leg*1000000).to_integral_value(rounding=decimal.ROUND_HALF_UP));now=max(now+x['service']+leg,decimal.Decimal(y['ready']));margin=decimal.Decimal(y['due'])-now
            minmargin=margin if minmargin is None else min(minmargin,margin)
            if margin<decimal.Decimal('-1e-9'):errs.append('window/depot deadline')
    if collections.Counter(seen)!=collections.Counter(range(1,101)):errs.append('all-service exactly once')
    if vehicles and (len(set(vehicles))!=len(vehicles) or any(type(v)!=int or not 0<=v<10 for v in vehicles)):errs.append('vehicle identity')
    error=abs(decimal.Decimal(obj)/1000000-total);bound=decimal.Decimal(arcs)/2000000
    if error>bound:errs.append('rounding bound')
    if objective is not None and obj!=objective:errs.append('integer objective')
    return {'valid':not errs,'errors':errs,'distance':float(total),'distance_decimal':str(total),'integer_objective':obj,'arc_count':arcs,'rounding_error':float(error),'rounding_bound':float(bound),'minimum_margin_decimal':str(minmargin)}
replayed=[]
for d in records:
    v=route_replay(d['id'],d['witness_routes']);replayed.append({'type':'witness','instance':d['id'],**v});check('witness valid '+d['id'],v['valid'] and wi[d['id']]['valid'] and near(v['distance'],wi[d['id']]['distance']))
for r in results:
    if r['outcome']=='SKIPPED_FIRST_SUCCESS':continue
    v=route_replay(r['instance'],r['routes'],r.get('objective_integer'));replayed.append({'type':'request','run_id':r['run_id'],**v});check('request replay '+r['run_id'],v['valid']==(r['outcome']=='SUCCESS')==bool(r['assignment_returned']) and v['valid']==cii[r['run_id']]['valid'] and (not v['valid'] or near(v['distance'],r['check_summary']['distance'])))
write('independent_route_replay.json',replayed)
check('192 successful routes and 18 failures independently accounted',sum(v['type']=='request' and v['valid'] for v in replayed)==192 and sum(v['type']=='request' and not v['valid'] for v in replayed)==18 and sum(v['type']=='witness' and v['valid'] for v in replayed)==48)
check('336 unique potential request rows no duplicates/retries',len(results)==len(ri)==len(requests)==336 and [r['run_id'] for r in results]==[r['run_id'] for r in requests] and all(i==r['request_sequence'] for i,r in enumerate(requests)))
check('requests preserve every frozen argument',all(all(r[k]==v for k,v in q.items()) for r,q in zip(results,requests)))
check('all input/parameter/source/prediction request hashes match bytes',all(sha(P/q['input_path'])==q['input_sha256'] and sha(P/q['parameter_path'])==q['parameter_sha256'] and q['frozen_prediction_sha256']==sha(P/'protocol/predictions_sealed.json') and all(sha(P/'source'/k)==h for k,h in q['source_sha256'].items()) for q in requests))
check('210 calls 210 starts 210 ends 126 skips, exact identities',len(starts)==len(ends)==len(cc)==210 and len(skips)==126 and len({e['run_id'] for e in starts})==210 and {e['run_id'] for e in starts}=={e['run_id'] for e in ends}==set(cii)=={r['run_id'] for r in results if r['outcome']!='SKIPPED_FIRST_SUCCESS'} and {e['run_id'] for e in skips}=={r['run_id'] for r in results if r['outcome']=='SKIPPED_FIRST_SUCCESS'})
active=None;serial=True
for e in events:
    if e['event']=='request_started':
        if active is not None:serial=False
        active=e['run_id']
    elif e['event']=='request_finished':
        if active!=e['run_id']:serial=False
        active=None
check('strict serial start/finish pairing no overlapping solver calls',serial and active is None)
check('192 policies exact frozen schedule',len(policies)==len(pl)==len(schedule)==192 and all(all(p[k]==v for k,v in s.items()) for p,s in zip(policies,schedule)))
policy_audit=[]
for p in policies:
    rs=[ri[k] for k in p['run_ids']];actual=[r for r in rs if r['outcome']!='SKIPPED_FIRST_SUCCESS'];first=rs[0];last=actual[-1];arm=p['policy'];n=p['instance'];ok=True
    if arm in splits:
        x,y=splits[arm];ok &= len(rs)==2 and first['config_id']==predictions[n]['selected_config'][:3]+str(x) and rs[1]['config_id']=='pci'+str(y) and (rs[1]['outcome']=='SKIPPED_FIRST_SUCCESS')==(first['outcome']=='SUCCESS') and p['fallback_executed']==(first['outcome']!='SUCCESS')
    else:ok &= len(rs)==1 and first['config_id']=='pci500' and not p['fallback_executed']
    ok &= p['returned_run_id']==last['run_id'] and p['executed_run_ids']==[r['run_id'] for r in actual] and p['nominal_search_ms_executed']==sum(r['budget_ms'] for r in actual)<=500 and p['valid']==(last['outcome']=='SUCCESS') and near(p['distance'],last['check_summary']['distance'])
    for clock in ['cpu_s','wall_s']:
        f=sum(v[clock] for v in overhead[n].values()) if arm in splits else 0
        ok &= near(p['feature_prediction_'+clock+'_charged'],f,1e-12) and near(p['charged_'+clock],p['policy_execution_'+clock]+f,1e-12)
        stages=sum(r['request_'+clock] for r in actual)
        ok &= p['policy_execution_'+clock]+1e-12>=stages
    check('policy branch, cost and return accounting '+str(p['policy_sequence']),ok)
    policy_audit.append({'sequence':p['policy_sequence'],'instance':n,'arm':arm,'request_cpu_s':sum(r['request_cpu_s'] for r in actual),'execution_cpu_s':p['policy_execution_cpu_s'],'charged_cpu_s':p['charged_cpu_s'],'charged_wall_s':p['charged_wall_s'],'success':p['valid']})
check('zero skipped costs and no skipped assignment',all(r['request_cpu_s']==r['request_wall_s']==0 and not r['assignment_returned'] and r['routes'] is None and r['ortools_status_name']=='NOT_EXECUTED' for r in results if r['outcome']=='SKIPPED_FIRST_SUCCESS'))
check('each executed stage component charged once',all(near(r['request_cpu_s'],r['total_cpu_s']+r['check_cpu_s'],1e-12) and near(r['request_wall_s'],r['total_wall_s']+r['check_wall_s'],1e-12) and r['total_cpu_s']+1e-12>=r['solve_cpu_s']+r['model_cpu_s'] and r['total_wall_s']+1e-12>=r['solve_wall_s']+r['model_wall_s'] for r in results if r['outcome']!='SKIPPED_FIRST_SUCCESS'))
check('all timing fields nonnegative',all(v>=0 for r in results+policies for k,v in r.items() if (k.endswith('_cpu_s') or k.endswith('_wall_s')) and isinstance(v,(float,int))))
position={a:dict(collections.Counter(s['arm_position'] for s in schedule if s['policy']==a)) for a in arms};adj=collections.Counter()
for i in range(48):
    ss=schedule[4*i:4*i+4]
    check('each problem has 4 arms in one serial block '+str(i),len({s['instance'] for s in ss})==1 and {s['policy'] for s in ss}==set(arms))
    adj.update((x['policy'],y['policy']) for x,y in zip(ss,ss[1:]))
check('Williams position and adjacent-pair balance',all(sorted(c.values())==[12]*4 for c in position.values()) and len(adj)==12 and set(adj.values())=={12},{'positions':position,'adjacent_pair_counts':{str(k):v for k,v in adj.items()}})
# Recompute every requested summary from raw policy rows; resampling unit is geometry.
recomputed={};cirows=[]
ordered=sorted(ds);gids=sorted({d['geometry_id'] for d in records});rows=read('reports/all48.json')
check('all48 report exact unique problems',len(rows)==48 and {r['instance'] for r in rows}==set(ds))
check('all48 report exactly agrees raw policies',all(all(row[a+'_'+k]==pl[row['instance'],a][k] for a in arms for k in ['valid','distance','charged_cpu_s','charged_wall_s','policy_execution_cpu_s','policy_execution_wall_s','nominal_search_ms_executed','fallback_executed','outcome']) for row in rows))
for a in arms:
    ps=[pl[n,a] for n in ordered];final=sum(p['valid'] for p in ps);v={'success_n':final,'problem_n':48,'both_window_geometry_n':sum(all(pl[n,a]['valid'] for n in ordered if ds[n]['geometry_id']==g) for g in gids),'mean_charged_cpu_s':mean([p['charged_cpu_s'] for p in ps]),'mean_charged_wall_s':mean([p['charged_wall_s'] for p in ps]),'total_charged_cpu_s':sum(p['charged_cpu_s'] for p in ps),'total_execution_cpu_s':sum(p['policy_execution_cpu_s'] for p in ps),'nominal_search_s':sum(p['nominal_search_ms_executed'] for p in ps)/1000}
    check('arm coverage and costs '+a,summary['methods'][a]['successes']==v['success_n'] and summary['methods'][a]['both_window_success_geometries']==v['both_window_geometry_n'] and near(summary['methods'][a]['total_charged_cpu_s'],v['total_charged_cpu_s']) and near(summary['methods'][a]['executed_nominal_search_s'],v['nominal_search_s']))
    if a in splits:
        first=[ri[pl[n,a]['run_ids'][0]] for n in ordered];fail=[r['instance'] for r in first if r['outcome']!='SUCCESS'];v['first_success']=48-len(fail);v['rescued_instances']=fail;v['fallback_success']=sum(ri[pl[n,a]['run_ids'][1]]['outcome']=='SUCCESS' for n in fail)
        dia=summary['stage_diagnostics'][a];check('stage rescue counts '+a,dia['first_success']==v['first_success'] and dia['rescued_instances']==fail and dia['fallback_rescued']==v['fallback_success'])
    recomputed[a]=v
check('same 6 failures across selector budgets',recomputed[arms[0]]['rescued_instances']==recomputed[arms[1]]['rescued_instances']==recomputed[arms[2]]['rescued_instances'])
for i,a in enumerate(arms):
    for b in arms[i+1:]:
        shared=[n for n in ordered if pl[n,a]['valid'] and pl[n,b]['valid']];quality=[];coverage=[]
        for g in gids:
            ns=[n for n in ordered if ds[n]['geometry_id']==g];coverage.append(mean([100*(int(pl[n,a]['valid'])-int(pl[n,b]['valid'])) for n in ns]));q=[100*(pl[n,a]['distance']/pl[n,b]['distance']-1) for n in ns if n in shared]
            if q:quality.append(mean(q))
        rng=random.Random(protocol['seeds']['bootstrap'])
        def boots(values):
            vals=sorted(sum(values[rng.randrange(len(values))] for _ in values)/len(values) for _ in range(5000));return [vals[int(.025*(len(vals)-1))],vals[int(.975*(len(vals)-1))]]
        cci=boots(coverage);qci=boots(quality)
        wins=sum(pl[n,a]['distance']<pl[n,b]['distance']-1e-6 for n in shared);ties=sum(abs(pl[n,a]['distance']-pl[n,b]['distance'])<=1e-6 for n in shared);losses=sum(pl[n,a]['distance']>pl[n,b]['distance']+1e-6 for n in shared)
        calc={'method':a,'control':b,'common_problem_n':len(shared),'common_geometry_n':len(quality),'mean_geometry_relative_distance_delta_pct':mean(quality),'cluster_bootstrap95_pct':qci,'coverage_cluster_bootstrap95_pp':cci,'wins':wins,'ties':ties,'losses':losses}
        rep=summary['comparisons'][a+'_vs_'+b]
        check('independent paired quality/CI '+a+'_vs_'+b,rep['common_success_n']==len(shared) and rep['common_success_geometry_n']==len(quality) and near(rep['mean_geometry_relative_distance_delta_pct'],mean(quality)) and all(near(x,y) for x,y in zip(rep['conditional_quality_geometry_bootstrap95_pct'],qci)) and rep['coverage_geometry_bootstrap95_pp']==cci and [rep['wins'],rep['ties'],rep['losses']]==[wins,ties,losses],calc)
        cirows.append(calc)
# Extra isolation checks do not run generation or solve.
parameter_normalized=[];parameter_ok=True
for pp in sorted((P/'protocol').glob('parameters_*.textproto')):
    name=pp.stem.removeprefix('parameters_');txt=pp.read_text();budget=int(name[3:]);strategy={'pci':'PARALLEL_CHEAPEST_INSERTION','pca':'PATH_CHEAPEST_ARC','sav':'SAVINGS'}[name[:3]]
    match=re.search(r'(?m)^time_limit \{\n  nanos: (\d+)\n\}',txt)
    parameter_ok &= match is not None and int(match.group(1))==budget*1000000 and txt.splitlines()[0]=='first_solution_strategy: '+strategy
    parameter_normalized.append(re.sub(r'(?m)^first_solution_strategy: .+','first_solution_strategy: NORMALIZED',re.sub(r'(?m)^time_limit \{\n  nanos: \d+\n\}','time_limit NORMALIZED',txt)))
check('ten parameter files differ only declared strategy and search time',parameter_ok and len(parameter_normalized)==10 and len(set(parameter_normalized))==1)
check('every request budget and strategy equals named config',all(r['budget_ms']==int(r['config_id'][3:]) and r['strategy']=={'pci':'PARALLEL_CHEAPEST_INSERTION','pca':'PATH_CHEAPEST_ARC','sav':'SAVINGS'}[r['config_id'][:3]] for r in requests))
check('input manifest metadata independently matches instances and text',len(im)==48 and all(m['input_sha256']==sha(P/'inputs'/f"{m['instance']}.txt") and m['geometry_id']==ds[m['instance']]['geometry_id'] and m['family']==ds[m['instance']]['family'] and m['seed']==ds[m['instance']]['seed'] and m['width']==ds[m['instance']]['width'] and m['customer_coordinates_sha256']==digest(sorted([[n['x'],n['y']] for n in ds[m['instance']]['nodes'][1:]])) for m in im))
pairs_valid=True
for g in gids:
    aa,bb=[ds[n] for n in ordered if ds[n]['geometry_id']==g]
    pairs_valid &= aa['seed']==bb['seed'] and aa['family']==bb['family'] and aa['witness_routes']==bb['witness_routes'] and [[n[k] for k in ['id','x','y','demand','service']] for n in aa['nodes']]==[[n[k] for k in ['id','x','y','demand','service']] for n in bb['nodes']]
check('width-paired cases share exact geometry/demand/service/witness',pairs_valid)
oldgen=(P.parent/'selector_budgeted_recovery_20261007/source/generator_shift.py').read_text();newgen=(P/'source/generator_shift.py').read_text()
for before,after in [('"""Fixed 48 new geometry units. No outcome access, solver calls, filtering or retries."""','"""Fixed 24 new geometry units for budget allocation ablation. No outcome access, solver calls, filtering or retries."""'),('202610073700','202610076100'),('202610073701','202610076101'),('202610073702','202610076102'),('range(12)','range(6)'),('gi = 12 * fi','gi = 6 * fi'),("gid = f's{gi:03d}'","gid = f'b{gi:03d}'"),('len(records) == 96','len(records) == 48'),("for g in geometries}) == 48","for g in geometries}) == 24")]:oldgen=oldgen.replace(before,after)
check('shift generator unchanged except planned seeds count IDs and docstring',oldgen==newgen)
# Aggregate resource receipt and run provenance without executing original modules.
ex=[r for r in results if r['outcome']!='SKIPPED_FIRST_SUCCESS'];resourcecalc={}
for kind,key in [('search','solve'),('model','model'),('checker','check')]:
    for clock in ['cpu_s','wall_s']:
        val=sum(r[key+'_'+clock] for r in ex);resourcecalc[kind+'_'+clock]=val;check('resource component '+kind+'_'+clock,near(val,resources[kind+'_'+clock]))
featurecpu=sum(v['feature']['cpu_s']+v['prediction']['cpu_s'] for v in overhead.values());execpu=sum(p['policy_execution_cpu_s'] for p in policies);chargecpu=sum(p['charged_cpu_s'] for p in policies)
check('feature overhead counted once physically and once per selector in comparisons',near(chargecpu,execpu+3*featurecpu))
shell=dict(line.split('=') for line in (P/'evidence/shell_time.txt').read_text().splitlines());shellcpu=float(shell['user_cpu_seconds'])+float(shell['system_cpu_seconds']);check('main shell receipt within hard180CPU',shellcpu<180 and resources['hard_cpu_limit_s']==180 and resources['process_cpu_s_before_report_zip']<=shellcpu and resources['process_wall_s_before_report_zip']<=float(shell['real_seconds']))
check('no unrecorded executed policy cost in physical CPU',execpu+featurecpu<=shellcpu+0.01)
source=(P/'source/study.py').read_text();core=(P/'source/core.py').read_text();gen=(P/'source/generator_shift.py').read_text()
check('static run has one prepare and execute and no target retries',source.count('results,policies=execute(ds,requests,schedule,overhead)')==1 and 'Already frozen: no overwrite or rerun' in source and 'selector.fit=forbidden_fit' in source and 'resource.setrlimit(resource.RLIMIT_CPU, (180, 180))' in source)
check('witness never enters solver construction',"d['witness_routes']" not in core and 'witness' not in core)
check('generation no outcome filtering/retry loop',all(t not in gen for t in ['ortools','while True','solve(','fit(']))
check('main native-status failure records fully retained',len(read('reports/all_failures.json')['requests'])==18 and {r['run_id'] for r in read('reports/all_failures.json')['requests']}=={r['run_id'] for r in results if r['outcome'] not in ['SUCCESS','SKIPPED_FIRST_SUCCESS']} and not read('reports/all_failures.json')['policies'])
status=collections.Counter((r['outcome'],r['ortools_status'],r['ortools_status_name']) for r in ex)
check('author directory unchanged during independent audit',initial_files=={str(x.relative_to(P)):sha(x) for x in P.rglob('*') if x.is_file()})
check('author ZIP unchanged during independent audit',sha(Z)=='4114ed234815fe12b401024d48c0a38e1ab5e1184d1d3768efe35837933312f5')
receipts={n:{'sha256':sha(P/n),'text':(P/n).read_text()} for n in ['evidence/shell_time.txt','raw/stdout.log','raw/stderr.log']}
caveats=[
'Same nominal maximum 500ms OR-Tools search wall is not equal actual CPU or strict end-to-end 500ms. First-stage success ends that policy; actual charged costs differ.',
'All 48 cases are four-family synthetic witness-constructed instances. Angle/capacity chunks and nearest-neighbor witness windows induce constructive-sampling bias; fresh hashes do not establish real-world representativeness.',
'Two widths per geometry are paired; arms share problems, frozen model, order design and host. Geometry-cluster bootstrap uses 24 units, not 48/192 independent samples. Distinct seeds/hashes establish identity non-overlap, not mathematical stochastic independence or absence of higher-level family/order/host correlation.',
'Coverage [0,0] paired empirical bootstrap differences are descriptive for this all-success sample, not proof of equal population coverage or certainty of future success. Six pairwise 95% intervals are unadjusted, not simultaneous inferential guarantees.',
'100/400ms transfer the strategy chosen by an 80-case original 250ms-label 1NN; no evidence they are budget-optimal selectors. 250 versus 400ms direct paired distance delta is +0.2098% with CI spanning zero; reliable improvement is not established.',
'Native ROUTING_FAIL code3 appears as generic UNKNOWN in 6 raw outcome values; native code/name and no-assignment/checker failure are retained. Another 12 failures are native timeout. No-success does not establish infeasibility.',
'CPU/wall and logs are self-recorded with local fsync/hash sealing, not externally trusted timestamp attestation or independent process tracing. Static code and logs support no retries/refits/API/P2 reads within this run, but cannot prove absence of unseen external activity. PID-namespace snapshots cannot exclude host contention.',
'Final ZIP/SHA intentionally exclude shell_time/stdout/stderr, which finish after the process writes ZIP. This audit independently records their hashes and content. Audit CPU and source-authoring time are outside the main experiment hard180CPU limit.',
]
report={'audit_status':'PASS_WITH_SCOPE_CAVEATS' if not issues else 'FAIL','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'author_root':str(P),'author_zip':str(Z),'author_zip_sha256':sha(Z),'freeze_sha256':sha(P/'protocol/freeze.json'),'freeze_event_utc':seal['utc'],'first_target_utc':starts[0]['utc'],'frozen_files_n':len(freeze['sha256']),'final_manifest_n':len(manifest),'checks_n':len(checks),'failed_checks':issues,'checks':checks,'author_receipts':receipts,'nonoverlap':nonoverlap,'methods':recomputed,'comparisons':cirows,'counts':{'potential_requests':len(results),'actual_calls':len(starts),'skips':len(skips),'policies':len(policies),'successful_route_replays':192,'witness_replays':48},'native_status_counts':[{'outcome':k[0],'native_code':k[1],'native_name':k[2],'count':v} for k,v in status.items()],'resources':{**resourcecalc,'main_shell_cpu_s':shellcpu,'main_shell_wall_s':float(shell['real_seconds']),'feature_prediction_physical_cpu_s':featurecpu,'sum_policy_execution_cpu_s':execpu,'sum_policy_charged_cpu_s':chargecpu,'main_process_minus_policy_and_physical_features_cpu_s':shellcpu-execpu-featurecpu},'caveats':caveats,'solver_executions_by_auditor':0,'author_imports_by_auditor':0,'uploads_by_auditor':0}
write('audit_results.json',report);write('policy_cost_audit.json',policy_audit)
text=['独立只读审计：冻结选择器预算分配','结论：'+report['audit_status'],f"独立检查 {len(checks)} 项，失败 {len(issues)} 项。未运行solver，未导入作者模块，未调用模型API，未读P2heldout，未修改作者包，未上传。",'',f"冻结事件 {seal['utc']}，首个目标 {starts[0]['utc']}；82项冻结hash不变。最终manifest {len(manifest)}项，ZIP CRC、逐字节、目录一致性通过。",f"ZIP SHA256: {sha(Z)}",'','重算结论：']
for a,v in recomputed.items():text.append(f"{a}: {v['success_n']}/48；双窗24/24 geometry；每题charged CPU={v['mean_charged_cpu_s']:.9f}s；每题charged wall={v['mean_charged_wall_s']:.9f}s。")
text += ['三选择器首段均42/48，相同6题被条件PCI后备救回。全部192策略成功，336潜在请求=210真实执行+126明确跳过。独立60位Decimal连续重放192成功路线及48 witnesses，18无解返回核为失败。']
for c in cirows:text.append(f"{c['method']} vs {c['control']}: 同48题/24geometry相对距离均值 {c['mean_geometry_relative_distance_delta_pct']:.9f}%；24geometry-cluster描述性95%CI {c['cluster_bootstrap95_pct']}；胜/平/负 {c['wins']}/{c['ties']}/{c['losses']}。")
text += ['',f"main shell CPU={shellcpu:.3f}s，wall={float(shell['real_seconds']):.3f}s，硬限180CPU；实际search CPU={resourcecalc['search_cpu_s']:.9f}s；对比charged费用包含每一选择器完整特征开销，不能将四臂charged总量等同物理进程。",'','限定：']+caveats
if issues:text+=['','未通过项：']+[json.dumps(x,ensure_ascii=False) for x in issues]
(A/'audit_report_zh.txt').write_text('\n'.join(text)+'\n')
write('audit_resource_receipt.json',{'auditor_process_cpu_s':time.process_time()-START_CPU,'auditor_wall_s':time.perf_counter()-START_WALL,'auditor_maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'auditor_hard_cpu_limit_s':60,'scope':'Independent audit only. No author solver/code executed; main experiment CPU separate. Wrapper time receipt is complete process endpoint.'})
print(json.dumps({'status':report['audit_status'],'checks':len(checks),'failures':issues,'cpu_s':time.process_time()-START_CPU,'wall_s':time.perf_counter()-START_WALL,'output':str(A)},ensure_ascii=False))
