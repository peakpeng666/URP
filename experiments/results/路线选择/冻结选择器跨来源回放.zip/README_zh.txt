先读reports/report_zh.txt。探索性跨来源回放，非外部盲测。
56完整预测及得分、4几何分层、源模型与hash、先预测后成本证据均在包内。
复算命令：python3 -B source/replay.py verify
包内无私有目标坐标/输入文本/完整路线；没有额外求解、API、安装、上传。
