#!/usr/bin/env python3
"""Fixed-model exploratory cross-source replay, Python standard library only.

run: Read source-only model/implementation and private target inputs, freeze all
protocol material, seal ALL predictions, only THEN read archived target outcomes.
verify: Reproduce predictions and tables from the distributable feature/cost
projection; this mode requires no private coordinates, full routes, or OR-Tools.
No training, solver call, network, fallback, rejection gate, or model selection.
"""
import resource
resource.setrlimit(resource.RLIMIT_CPU, (5, 5))
import sys
sys.dont_write_bytecode = True
import argparse, collections, csv, hashlib, importlib.util, json, math, os
import re, statistics, time, zipfile
from datetime import datetime, timezone
from pathlib import Path

P = Path(__file__).resolve().parent.parent
SOURCE = Path('/workspace/shared/diverse_geometry_selection_20261007')
TARGET = Path('/workspace/shared/solver_portfolio_headroom_20261007')
INPUT = Path('/workspace/shared/public_vrptw_benchmark_20261007/inputs')
MODEL_HASH = '52328f15e700562453095399fa10a4dd895af7ed70c89672c22f1b2d08d44ef2'
MODELS = ['primary_1nn4', 'spatial_1nn8']
CONTROLS = {'source_training_sbs': 'pci250', 'historical_target_sbs': 'sav250'}
CONFIGS = ['pci250', 'pca250', 'sav250']
TOL = 1e-6
START = time.perf_counter()

def utc(): return datetime.now(timezone.utc).isoformat()
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def digest(v): return hashlib.sha256(json.dumps(v, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
def read(p): return json.loads(Path(p).read_text())
def write(p, v):
    p = Path(p)
    p.write_text(json.dumps(v, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
    with p.open('rb') as f: os.fsync(f.fileno())
def dump_csv(p, rows):
    with Path(p).open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)
def mean(xs): return statistics.mean(xs) if xs else None
def module(name):
    spec = importlib.util.spec_from_file_location(name, P/'source'/f'{name}.py')
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    return mod
def event(kind, **kw):
    r = {'utc': utc(), 'monotonic_ns': time.monotonic_ns(), 'event': kind, **kw}
    with (P/'evidence/events.jsonl').open('a') as f:
        f.write(json.dumps(r) + '\n'); f.flush(); os.fsync(f.fileno())
    return r
def parse(path):
    lines = path.read_text().splitlines(); name = lines[0].strip().lower()
    assert name == path.stem.lower()
    vi = next(i for i, line in enumerate(lines) if line.strip() == 'VEHICLE')
    k, q = map(int, lines[vi+2].split())
    nodes = []
    for line in lines:
        ts = line.split()
        if len(ts) == 7 and all(re.fullmatch(r'-?\d+', t) for t in ts):
            nodes.append(dict(zip(['id', 'x', 'y', 'demand', 'ready', 'due', 'service'], map(int, ts))))
    assert len(nodes) == 101 and [n['id'] for n in nodes] == list(range(101))
    assert nodes[0]['ready'] == nodes[0]['service'] == nodes[0]['demand'] == 0
    assert k > 0 and q > 0 and all(0 <= n['ready'] <= n['due'] and 0 <= n['demand'] <= q and n['service'] >= 0 for n in nodes)
    return {'id': name, 'family': re.match(r'(rc|r|c)[12]', name).group(0).upper(), 'vehicles': k, 'capacity': q, 'nodes': nodes}

def predict_all(models, features, selector):
    predictions = []
    for name in sorted(features):
        p = {'instance': name, 'methods': {}}
        for method in MODELS:
            model = models[method]
            p['methods'][method] = selector.predict(model, [features[name][f] for f in model['features']])
        for method, config in CONTROLS.items():
            p['methods'][method] = {'selected_config': config}
        predictions.append(p)
    return predictions

def assess(predictions, metadata, costs):
    by = {(r['instance'], r['config_id']): r for r in costs}
    assert len(by) == 168 and set(by) == {(p['instance'], c) for p in predictions for c in CONFIGS}
    rows = []
    for p in predictions:
        name = p['instance']; row = {'instance': name, **metadata[name], 'methods': {}}
        for method, pred in p['methods'].items():
            cost = by[name, pred['selected_config']]
            row['methods'][method] = {**pred, 'outcome': cost['outcome'], 'valid': cost['valid'], 'distance': cost['distance']}
            for control, config in CONTROLS.items():
                baseline = by[name, config]
                row['methods'][method]['delta_vs_'+control+'_pct'] = 100*(cost['distance']/baseline['distance']-1) if cost['valid'] and baseline['valid'] else None
        rows.append(row)
    def aggregate(rs):
        out = {'n_all_predictions': len(rs), 'methods': {}}
        for method in MODELS+list(CONTROLS):
            selected = [r['methods'][method] for r in rs]
            valid = [x for x in selected if x['valid']]
            m = {'selected_config_counts': dict(collections.Counter(x['selected_config'] for x in selected)),
                 'valid_count': len(valid), 'total_count': len(rs), 'valid_rate': len(valid)/len(rs),
                 'outcome_counts': dict(collections.Counter(x['outcome'] for x in selected)),
                 'failed_instances': [r['instance'] for r in rs if not r['methods'][method]['valid']], 'comparisons': {}}
            for control in CONTROLS:
                common = [r for r in rs if r['methods'][method]['valid'] and r['methods'][control]['valid']]
                deltas = [r['methods'][method]['distance']-r['methods'][control]['distance'] for r in common]
                ratios = [r['methods'][method]['delta_vs_'+control+'_pct'] for r in common]
                aa = sum(r['methods'][method]['distance'] for r in common)
                bb = sum(r['methods'][control]['distance'] for r in common)
                m['comparisons'][control] = {'common_valid_n': len(common), 'all_prediction_n': len(rs),
                    'mean_instance_delta_pct': mean(ratios), 'median_instance_delta_pct': statistics.median(ratios) if ratios else None,
                    'ratio_of_distance_sums_delta_pct': 100*(aa/bb-1) if bb else None,
                    'selector_wins': sum(x < -TOL for x in deltas), 'ties': sum(abs(x) <= TOL for x in deltas),
                    'control_wins': sum(x > TOL for x in deltas),
                    'selector_fail_control_success': sum(not r['methods'][method]['valid'] and r['methods'][control]['valid'] for r in rs)}
            out['methods'][method] = m
        return out
    summary = aggregate(rows)
    geoms = []
    for geometry in sorted({r['geometry_sha256'] for r in rows}):
        group = [r for r in rows if r['geometry_sha256'] == geometry]
        geoms.append({'geometry_sha256': geometry, 'families': sorted({r['family'] for r in group}), 'instances': [r['instance'] for r in group], **aggregate(group)})
    summary['geometry_count'] = len(geoms)
    summary['geometry_equal_weight_mean_conditional_delta_pct'] = {
        m: {b: {'usable_geometry_n': len([g for g in geoms if g['methods'][m]['comparisons'][b]['common_valid_n']]),
                'mean_pct': mean([g['methods'][m]['comparisons'][b]['mean_instance_delta_pct'] for g in geoms if g['methods'][m]['comparisons'][b]['common_valid_n']])}
            for b in CONTROLS} for m in MODELS}
    return rows, summary, geoms

def shift_description(models, train_features, target_features, metadata):
    train = models[MODELS[0]]['train_instances']; fs = models[MODELS[1]]['features']
    ranges = {f: {'min': min(train_features[n][f] for n in train), 'max': max(train_features[n][f] for n in train)} for f in fs}
    outside = {n: [f for f in fs if not ranges[f]['min'] <= r[f] <= ranges[f]['max']] for n, r in target_features.items()}
    features = {f: {**ranges[f], 'target_min': min(r[f] for r in target_features.values()), 'target_max': max(r[f] for r in target_features.values()),
                   'target_outside_train_range_count': sum(f in fields for fields in outside.values()), 'denominator': 56} for f in fs}
    return {'purpose': 'Explanation only; not a gate, feature selection, rescaling, tuning, or evidence of a unique causal mechanism.',
            'source_train_instances': 80, 'features': features, 'outside_features_by_instance': outside,
            'target_any_outside_train_range': sum(bool(x) for x in outside.values()),
            'outside_feature_count_histogram': dict(collections.Counter(len(x) for x in outside.values())),
            'source_constraints': {'customers': 100, 'K': 10, 'capacity': 100, 'horizon': 2000, 'customer_service': 2, 'window_widths': [60, 180]},
            'target_constraints': {field: dict(collections.Counter(str(x[field]) for x in metadata.values()))
                                   for field in ['vehicle_limit', 'capacity', 'horizon', 'mean_customer_service', 'min_customer_service', 'max_customer_service']}}

def run():
    assert not (P/'protocol/freeze.json').exists(), 'Do not overwrite an existing frozen replay.'
    approval = read(P/'protocol/source_author_confirmation.json')
    assert approval['basic_validation_complete'] and approval['fixed_model_confirmed']
    files = {'raw/training_models.json': 'protocol/training_models.json', 'source/selector.py': 'source/selector.py',
             'source/generator.py': 'source/generator.py', 'protocol/features.json': 'protocol/source_features_reference.json',
             'protocol/protocol.json': 'protocol/source_protocol_reference.json', 'evidence/prediction_seal.json': 'evidence/source_prediction_seal.json',
             'evidence/verification.json': 'evidence/source_verification.json'}
    refs = []
    for src, dst in files.items():
        data = (SOURCE/src).read_bytes(); (P/dst).write_bytes(data)
        refs.append({'original_path': str(SOURCE/src), 'sha256': sha(SOURCE/src), 'copied_path': dst, 'bytes': len(data)})
    assert sha(P/'protocol/training_models.json') == MODEL_HASH == read(P/'evidence/source_prediction_seal.json')['model_sha256']
    models = read(P/'protocol/training_models.json'); generator = module('generator'); selector = module('selector')
    assert list(models) == MODELS and all(m['sbs'] == 'pci250' for m in models.values())
    assert models[MODELS[0]]['features'] == selector.PRIMARY
    assert models[MODELS[1]]['features'] == selector.PRIMARY+selector.SPATIAL
    assert all(len(m['train_instances']) == len(m['labels']) == len(m['vectors']) == 80 for m in models.values())
    manifest = read(TARGET/'protocol/input_manifest.json'); assert len(manifest) == 56
    for r in manifest: assert sha(INPUT/r['name']) == r['sha256'], r['name']
    write(P/'protocol/target_input_manifest.json', manifest)
    write(P/'protocol/source_references.json', refs)
    protocol = {
        'study_id': 'FROZEN_SYNTHETIC_TO_ARCHIVED_SOLOMON_EXPLORATORY_REPLAY',
        'status': 'Exploratory cross-source replay. Target archive outcomes were previously observed; NOT a new external blind test.',
        'source': str(SOURCE), 'source_model_sha256': MODEL_HASH, 'source_model_sealed_utc': '2026-10-07T07:46:38.702044+00:00',
        'target_results': str(TARGET/'raw/results.jsonl'), 'target_inputs': str(INPUT), 'target_n': 56, 'target_geometry_n': 4,
        'target_archive_filter': CONFIGS, 'exclude_long_config': 'pci750', 'model_methods': MODELS, 'fixed_controls': CONTROLS,
        'controls_explanation': 'PCI is frozen source-training SBS, never reselected. SAV is previously observed target-domain historical SBS, not an automatically identified baseline in an unknown domain.',
        'feature_formula': 'Byte-identical source/generator.py features(). h is target depot due-ready; customer-only population statistics. Source has h=2000 but this value is NOT hard-coded in feature extraction.',
        'model_rule': 'Byte-identical source/selector.py predict(). Frozen source-only means, population-sd scales (sd0->1), 80 source labels/vectors, k=1, squared Euclidean distance. Neighbor distances within 1e-12: prefer source-SBS-labeled neighbor then lexicographic source ID. Training cost tie tolerance 1e-6, source SBS then fixed config order PCI/PCA/SAV. NO fit() call.',
        'freeze_order': 'Freeze models, code, input SHA and evaluation; compute and fsync all56 predictions; fsync seal/event; only then open target outcome archive.',
        'allowed_target_information_before_seal': 'Input files, names/hashes, archival metadata, and already-known aggregate historical facts. No target outcome row is consumed by prediction.',
        'evaluation': 'Success rate with denominator56 first. For each selector and PCI/SAV separately, quality only on joint legal subset with explicit n, mean100*(selector/control-1), median, ratio-of-sums and absolute1e-6 wins/ties/losses. Positive delta means worse. Report all56 rows and all4 geometry clusters; no overall quality claim from success-only averages.',
        'failure_policy': 'Keep every selected TIMEOUT/no-solution/check failure; no free fallback, retries, new rejection gate, penalty substitution, sample omission or extra solve.',
        'geometry_summary': 'Target56 share4 coordinate-set geometries. Report descriptive per-geometry and equal-geometry conditional means. No significance, bootstrap, or external-generalization claim.',
        'semantics': 'Both sources:100 mandatory customers, original K is an upper limit, total distance single objective, Euclidean distance=travel-time, service-start time windows, wait allowed, original capacity and service. Same250ms search cap per frozen configuration. Arbitrary archive/synthetic units; no km/min conversion or official Solomon BKS gap.',
        'domain_shift': 'Source synthetic generator and constraint distributions differ substantially from archival target; inspect source-train feature ranges and K/capacity/horizon/service only after prediction sealing and only as explanation.',
        'resources': 'Standard library only, no installation/API/solver/network. RLIMIT_CPU5s per entry process; report actual run+verification processCPU and ensure cumulative<5s. Authoring/inspection and prior archived solving excluded.',
        'clean_package': 'No private target coordinates, original input texts, full target routes, credentials or environment. Include scalar feature vectors, model copy/references, hash manifest, minimal168 cost/status projection, predictions, scoring script and report. No upload.'}
    write(P/'protocol/protocol.json', protocol)
    frozen_files = [p for d in ['source', 'protocol', 'evidence'] for p in (P/d).glob('*') if p.is_file()]
    freeze = {'frozen_utc': utc(), 'files': {str(p.relative_to(P)): sha(p) for p in sorted(frozen_files)}, 'target_input_hashes': {r['name']: r['sha256'] for r in manifest}, 'source_refs': refs}
    write(P/'protocol/freeze.json', freeze); event('protocol_frozen', sha256=sha(P/'protocol/freeze.json'))
    features, metadata = {}, {}; feature_cpu = 0.
    for r in manifest:
        d = parse(INPUT/r['name']); cs = d['nodes'][1:]; dep = d['nodes'][0]
        t = time.process_time(); features[d['id']] = generator.features(d); feature_cpu += time.process_time()-t
        geometry = digest({'depot': [dep['x'], dep['y']], 'customers': sorted([n['x'], n['y']] for n in cs)})
        metadata[d['id']] = {'family': d['family'], 'geometry_sha256': geometry, 'vehicle_limit': d['vehicles'], 'capacity': d['capacity'],
                            'horizon': dep['due']-dep['ready'], 'mean_customer_service': statistics.mean(n['service'] for n in cs),
                            'min_customer_service': min(n['service'] for n in cs), 'max_customer_service': max(n['service'] for n in cs)}
    assert len(features) == 56 and len({v['geometry_sha256'] for v in metadata.values()}) == 4
    t = time.process_time(); predictions = predict_all(models, features, selector); predict_cpu = time.process_time()-t
    write(P/'raw/target_features.json', features); write(P/'raw/target_metadata.json', metadata)
    write(P/'raw/predictions_sealed.json', predictions)
    seal = {'sealed_utc': utc(), 'prediction_sha256': sha(P/'raw/predictions_sealed.json'), 'features_sha256': sha(P/'raw/target_features.json'),
            'metadata_sha256': sha(P/'raw/target_metadata.json'), 'model_sha256': MODEL_HASH, 'freeze_sha256': sha(P/'protocol/freeze.json'),
            'target_outcome_rows_consumed_in_this_replay_before_seal': 0, 'target_outcomes_previously_observed_in_research': True, 'predictions_n': 56}
    write(P/'evidence/prediction_seal.json', seal); event('all_predictions_sealed', **seal)
    print('SEALED', seal['sealed_utc'], seal['prediction_sha256'], flush=True)
    event('target_archive_open_started', path=str(TARGET/'raw/results.jsonl'))
    raw_bytes = (TARGET/'raw/results.jsonl').read_bytes(); costs = []
    for line in raw_bytes.splitlines():
        r = json.loads(line)
        if r['config_id'] not in CONFIGS: continue
        valid = r['outcome'] == 'SUCCESS'; check = r.get('check_summary') or {}
        distance = check.get('distance') if valid else None
        assert not valid or (isinstance(distance, (int, float)) and distance > 0 and check['valid'])
        costs.append({'instance': r['instance'], 'config_id': r['config_id'], 'outcome': r['outcome'], 'valid': valid, 'distance': distance,
                      'ortools_status_name': r.get('ortools_status_name'), 'run_id': r.get('run_id')})
    costs.sort(key=lambda x: (x['instance'], CONFIGS.index(x['config_id'])))
    write(P/'raw/archived_costs_projection.json', costs)
    write(P/'evidence/target_archive_receipt.json', {'path': str(TARGET/'raw/results.jsonl'), 'sha256': hashlib.sha256(raw_bytes).hexdigest(), 'total_rows_read': len(raw_bytes.splitlines()), 'retained_short_rows': len(costs), 'projection_sha256': sha(P/'raw/archived_costs_projection.json'), 'no_full_routes_or_coordinates_copied': True})
    rows, summary, geoms = assess(predictions, metadata, costs)
    assert summary['methods']['source_training_sbs']['valid_count'] == summary['methods']['historical_target_sbs']['valid_count'] == 56
    assert sum(r['outcome'] == 'TIMEOUT' for r in costs if r['config_id'] == 'pca250') == 7
    write(P/'reports/all56_scored.json', rows); write(P/'reports/summary.json', summary); write(P/'reports/all4_geometries.json', geoms)
    flat = []
    for r in rows:
        v = {k: value for k, value in r.items() if k != 'methods'}
        for method, x in r['methods'].items():
            for k in ['selected_config', 'neighbor', 'neighbor_squared_distance', 'neighbor_tie_count', 'outcome', 'valid', 'distance']+['delta_vs_'+b+'_pct' for b in CONTROLS]:
                v[method+'__'+k] = x.get(k)
        flat.append(v)
    dump_csv(P/'reports/all56_scored.csv', flat)
    geom_flat = []
    for g in geoms:
        for m in MODELS+list(CONTROLS):
            v = {'geometry_sha256': g['geometry_sha256'], 'families': ';'.join(g['families']), 'n': g['n_all_predictions'], 'method': m, 'valid_n': g['methods'][m]['valid_count']}
            for b in CONTROLS:
                q = g['methods'][m]['comparisons'][b]; v[b+'__common_n'] = q['common_valid_n']; v[b+'__mean_delta_pct'] = q['mean_instance_delta_pct']
            geom_flat.append(v)
    dump_csv(P/'reports/all4_geometries.csv', geom_flat)
    shift = shift_description(models, read(P/'protocol/source_features_reference.json'), features, metadata)
    write(P/'reports/input_distribution_shift.json', shift)
    immutable = all(sha(P/p) == h for p, h in freeze['files'].items())
    originals = all(sha(r['original_path']) == r['sha256'] for r in refs)
    target_inputs = all(sha(INPUT/r['name']) == r['sha256'] for r in manifest)
    assert immutable and originals and target_inputs
    events = [json.loads(x) for x in (P/'evidence/events.jsonl').read_text().splitlines()]
    assert events[0]['monotonic_ns'] < events[1]['monotonic_ns'] < events[2]['monotonic_ns']
    write(P/'evidence/verification.json', {'verified_utc': utc(), 'frozen_files_unchanged': immutable, 'source_references_unchanged': originals, 'target_inputs_unchanged': target_inputs,
         'sealed_predictions_before_target_archive_open': True, 'target_results_not_used_for_training_or_selection': True, 'no_fit_call': True, 'predictions_n': 56, 'geometries_n': 4, 'short_archive_rows': 168})
    write_report(summary, geoms, shift)
    write(P/'evidence/run_resources.json', {'measured_utc': utc(), 'process_cpu_s': time.process_time(), 'wall_s': time.perf_counter()-START, 'feature_cpu_s': feature_cpu, 'prediction_cpu_s': predict_cpu,
         'hard_cpu_limit_s': 5, 'solver_calls': 0, 'api_calls': 0, 'new_installs': 0, 'included': 'Imports, hashing, feature extraction, prediction, archive scoring, report generation; process CPU excludes prior experiments and authoring/inspection.', 'scope': 'Package/verification measured separately and summed in final resource receipt.'})
    print(json.dumps(summary, ensure_ascii=False), flush=True)

def write_report(summary, geoms, shift):
    lines = ['固定合成选择器迁回原56实例：探索性跨来源回放', '',
        '本目标成本此前已观察，本轮不是新的外部盲测。所有56输入的预测本轮均先封存，再读取目标成本。没有训练、调参、求解、API、安装、拒绝门控或免费fallback。',
        '源模型：80训练实例、40合成几何，原4特征1NN及预定8特征1NN；07:46:38.702044Z已封存，SHA256 '+MODEL_HASH+'。直接复用模型/标准化/标签/tie规则。',
        'PCI是固定源训练SBS；SAV是原目标域已有历史SBS参考，不能称未知域自动选出的基线。两基线本档案均56/56合法。配置均250ms搜索上限，非本轮新执行。', '',
        '主要结果：下列质量均为共同合法子集平均100×(选择器/基线−1)，负值较好；失败仍占56全预测分母。']
    for m in MODELS+list(CONTROLS):
        r = summary['methods'][m]
        lines.append(f"{m}：合法{r['valid_count']}/56（{100*r['valid_rate']:.3f}%），选择{r['selected_config_counts']}；失败{r['failed_instances']}。")
        for b, label in [('source_training_sbs', 'PCI'), ('historical_target_sbs', 'SAV')]:
            q = r['comparisons'][b]
            lines.append(f"  对{label}：共同合法{q['common_valid_n']}/56，平均相对差{q['mean_instance_delta_pct']:+.6f}%，中位数{q['median_instance_delta_pct']:+.6f}%；胜/平/负{q['selector_wins']}/{q['ties']}/{q['control_wins']}，选择失败但基线成功{q['selector_fail_control_success']}例。")
    lines += ['', '4目标几何聚合（这些分组不是4个新随机样本；不做显著性/外泛化证明）：']
    for g in geoms:
        lines.append(f"{','.join(g['families'])}（{g['geometry_sha256'][:12]}）：{g['n_all_predictions']}例")
        for m in MODELS:
            r = g['methods'][m]; a = r['comparisons']['source_training_sbs']; b = r['comparisons']['historical_target_sbs']
            lines.append(f"  {m}：合法{r['valid_count']}/{g['n_all_predictions']}；对PCI {a['mean_instance_delta_pct']:+.6f}%（n={a['common_valid_n']}）；对SAV {b['mean_instance_delta_pct']:+.6f}%（n={b['common_valid_n']}）。")
    lines += ['', f"输入分布：56/56至少一项8特征超出源训练范围；超范围特征个数分布{shift['outside_feature_count_histogram']}。"]
    for f, r in shift['features'].items():
        lines.append(f"  {f}：源训练[{r['min']:.8g},{r['max']:.8g}]，目标[{r['target_min']:.8g},{r['target_max']:.8g}]，超范围{r['target_outside_train_range_count']}/56。")
    lines += [f"源约束：{shift['source_constraints']}", f"目标约束分布（实例数）：{shift['target_constraints']}", '',
        '问题口径：两来源都是100强制客户、K上限、总距离单目标、欧氏距离等同行驶时间、允许等待、服务开始时间窗。源合成生成器围绕特定构造生成可行时间窗，目标来自用户存档；约束分布和生成机制不同。单位保留原抽象单位，不当作公里/分钟，不与官方车辆数优先BKS计算gap。',
        '解释边界：输入范围外只是描述，不证明失败原因，也没有改变预测。只回放一次固定250ms历史档案，不估计运行噪声；56条记录只有4个共享几何。成功子集较好不能覆盖失败损失，亦不能称全样本胜出。',
        '复算：python3 -B source/replay.py verify。此模式用包内标量特征、冻结模型和168条精简成本重算预测与全部得分，无私有坐标或完整路线。端到端特征复算需要用户私有原输入，并核对protocol/target_input_manifest.json。',
        '数据文件：reports/all56_scored.csv/json保留56预测及失败；reports/all4_geometries.csv/json列全部4几何；evidence/prediction_seal.json与events.jsonl记录本轮先预测后打分；protocol/freeze.json与source_references.json冻结完整规则。',
        '资源：详见evidence/run_resources.json及最终资源收据；stdlib，硬限5 CPU秒，零新求解/API/安装。代码编写与文件查阅不算实验进程CPU。未上传。']
    (P/'reports/report_zh.txt').write_text('\n'.join(lines)+'\n')
    (P/'README_zh.txt').write_text('先读reports/report_zh.txt。探索性跨来源回放，非外部盲测。\n56完整预测及得分、4几何分层、源模型与hash、先预测后成本证据均在包内。\n复算命令：python3 -B source/replay.py verify\n包内无私有目标坐标/输入文本/完整路线；没有额外求解、API、安装、上传。\n')

def verify():
    freeze = read(P/'protocol/freeze.json')
    assert all(sha(P/p) == h for p, h in freeze['files'].items())
    seal = read(P/'evidence/prediction_seal.json')
    for path, key in [('raw/predictions_sealed.json', 'prediction_sha256'), ('raw/target_features.json', 'features_sha256'), ('raw/target_metadata.json', 'metadata_sha256')]:
        assert sha(P/path) == seal[key]
    models = read(P/'protocol/training_models.json'); features = read(P/'raw/target_features.json')
    predictions = predict_all(models, features, module('selector'))
    assert predictions == read(P/'raw/predictions_sealed.json')
    rows, summary, geoms = assess(predictions, read(P/'raw/target_metadata.json'), read(P/'raw/archived_costs_projection.json'))
    assert rows == read(P/'reports/all56_scored.json') and summary == read(P/'reports/summary.json') and geoms == read(P/'reports/all4_geometries.json')
    csvrows = list(csv.DictReader((P/'reports/all56_scored.csv').open()))
    assert len(csvrows) == 56 and [r['instance'] for r in csvrows] == [r['instance'] for r in rows]
    result = {'verified_utc': utc(), 'all56_predictions_exact': True, 'all56_scores_exact': True, 'all4_geometries_exact': True, 'frozen_hashes_exact': True, 'process_cpu_s': time.process_time(), 'wall_s': time.perf_counter()-START}
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('action', choices=['run', 'verify']); args = parser.parse_args()
    {'run': run, 'verify': verify}[args.action]()
