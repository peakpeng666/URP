"""Fixed k=1 policies; original four-feature rule and predeclared eight-feature ablation.
No solver or test-outcome access in this module. Behavior follows archived protocol.
"""
import statistics
CONFIGS=['pci250','pca250','sav250']
PRIMARY=['capacity_over_total_demand','demand_population_cv','mean_window_width_over_depot_duration','mean_service_over_depot_duration']
SPATIAL=['rms_radius_over_horizon','mean_nn_over_rms_radius','covariance_anisotropy','depot_centroid_over_rms_radius']
COST_TOL=1e-6
DISTANCE2_TOL=1e-12

def avg(xs):return statistics.mean(xs) if xs else None

def fit(train_features,train_outcomes,features):
    names=sorted(train_features)
    assert set(train_outcomes)=={(name,config) for name in names for config in CONFIGS}
    coverage={c:sum(train_outcomes[n,c]['valid'] for n in names) for c in CONFIGS}
    candidates=[c for c in CONFIGS if coverage[c]==max(coverage.values())]
    oracle={n:min([train_outcomes[n,c]['distance'] for c in CONFIGS if train_outcomes[n,c]['valid']],default=None) for n in names}
    common=[n for n in names if all(train_outcomes[n,c]['valid'] for c in candidates)]
    scores={c:avg([train_outcomes[n,c]['distance']/oracle[n] for n in common]) for c in candidates}
    sbs=min(candidates,key=lambda c:(scores[c] if common else 0,CONFIGS.index(c)))
    means={f:avg([train_features[n][f] for n in names]) for f in features}
    stds={f:statistics.pstdev([train_features[n][f] for n in names]) for f in features}
    scales={f:stds[f] or 1.0 for f in features}
    labels={};skipped=[]
    for n in names:
        if oracle[n] is None:skipped.append(n);continue
        tied=[c for c in CONFIGS if train_outcomes[n,c]['valid'] and train_outcomes[n,c]['distance']<=oracle[n]+COST_TOL]
        labels[n]=min(tied,key=lambda c:(c!=sbs,CONFIGS.index(c)))
    vectors={n:[(train_features[n][f]-means[f])/scales[f] for f in features] for n in labels}
    return {'features':features,'train_instances':names,'coverage':coverage,'sbs':sbs,'sbs_score_common_instances':common,'sbs_scores':scores,'feature_means':means,'feature_population_stds':stds,'feature_scales':scales,'labels':labels,'skipped_unlabelable_training_instances':skipped,'vectors':vectors}

def predict(model,test_vector):
    features=model['features'];assert len(test_vector)==len(features)
    vector=[(test_vector[j]-model['feature_means'][f])/model['feature_scales'][f] for j,f in enumerate(features)]
    distance2={n:sum((a-b)**2 for a,b in zip(vector,v)) for n,v in model['vectors'].items()}
    if not distance2:return {'selected_config':model['sbs'],'neighbor':None,'neighbor_squared_distance':None,'neighbor_tie_count':0,'neighbor_tie_instances':[]}
    best=min(distance2.values());tied=sorted(n for n,v in distance2.items() if v<=best+DISTANCE2_TOL)
    neighbor=min(tied,key=lambda n:(model['labels'][n]!=model['sbs'],n))
    return {'selected_config':model['labels'][neighbor],'neighbor':neighbor,'neighbor_squared_distance':distance2[neighbor],'neighbor_tie_count':len(tied),'neighbor_tie_instances':tied}
