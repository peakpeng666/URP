#!/usr/bin/env python3
"""Independent scalar audit plus clean local ZIP, no solving or external writes."""
import resource
resource.setrlimit(resource.RLIMIT_CPU, (5, 5))
import sys
sys.dont_write_bytecode = True
import collections, hashlib, json, math, statistics, time, zipfile
from datetime import datetime, timezone
from pathlib import Path
P = Path(__file__).resolve().parent.parent
def read(p): return json.loads(Path(p).read_text())
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p, r): Path(p).write_text(json.dumps(r, ensure_ascii=False, indent=2, allow_nan=False)+'\n')
def utc(): return datetime.now(timezone.utc).isoformat()

models = read(P/'protocol/training_models.json')
train = read(P/'protocol/source_features_reference.json')
target = read(P/'raw/target_features.json')
preds = read(P/'raw/predictions_sealed.json')
scores = read(P/'reports/all56_scored.json')
frozen = read(P/'protocol/freeze.json')
max_squared_distance_roundoff = 0.
assert all(sha(P/k) == v for k, v in frozen['files'].items())
assert sha(P/'protocol/training_models.json') == read(P/'evidence/source_prediction_seal.json')['model_sha256']
for method, model in models.items():
    names = model['train_instances']; fields = model['features']
    for f in fields:
        values = [train[n][f] for n in names]
        assert statistics.mean(values) == model['feature_means'][f]
        assert statistics.pstdev(values) == model['feature_population_stds'][f]
        assert (statistics.pstdev(values) or 1.0) == model['feature_scales'][f]
    for n, vector in model['vectors'].items():
        assert vector == [(train[n][f]-model['feature_means'][f])/model['feature_scales'][f] for f in fields]
    for p in preds:
        n = p['instance']; x = [(target[n][f]-model['feature_means'][f])/model['feature_scales'][f] for f in fields]
        # Independent direct loop; do not import replay.py or selector.py.
        dists = {}
        for neighbor, vector in model['vectors'].items():
            total = 0.
            for j in range(len(fields)): total += (x[j]-vector[j])**2
            dists[neighbor] = total
        dmin = min(dists.values())
        candidates = sorted(k for k, v in dists.items() if v <= dmin+1e-12)
        best = sorted(candidates, key=lambda k: (model['labels'][k] != 'pci250', k))[0]
        expected = {'selected_config': model['labels'][best], 'neighbor': best,
                    'neighbor_squared_distance': dists[best], 'neighbor_tie_count': len(candidates), 'neighbor_tie_instances': candidates}
        actual = p['methods'][method]
        assert {k: v for k, v in actual.items() if k != 'neighbor_squared_distance'} == {k: v for k, v in expected.items() if k != 'neighbor_squared_distance'}
        max_squared_distance_roundoff = max(max_squared_distance_roundoff, abs(actual['neighbor_squared_distance']-expected['neighbor_squared_distance']))
        assert math.isclose(actual['neighbor_squared_distance'], expected['neighbor_squared_distance'], rel_tol=1e-14, abs_tol=1e-12)
    assert model['sbs'] == 'pci250'

archive_receipt = read(P/'evidence/target_archive_receipt.json')
assert sha(archive_receipt['path']) == archive_receipt['sha256']
archive = [json.loads(x) for x in Path(archive_receipt['path']).read_text().splitlines()]
raw = {(x['instance'], x['config_id']): x for x in archive}
projection = read(P/'raw/archived_costs_projection.json')
assert len(projection) == 168
for r in projection:
    a = raw[r['instance'], r['config_id']]
    assert r['outcome'] == a['outcome'] and r['valid'] == (a['outcome'] == 'SUCCESS')
    assert r['distance'] == (a['check_summary']['distance'] if r['valid'] else None)
    assert set(r) == {'instance', 'config_id', 'outcome', 'valid', 'distance', 'ortools_status_name', 'run_id'}
for row in scores:
    for method, val in row['methods'].items():
        a = raw[row['instance'], val['selected_config']]
        assert val['outcome'] == a['outcome']
        assert val['distance'] == (a['check_summary']['distance'] if a['outcome'] == 'SUCCESS' else None)

summary = read(P/'reports/summary.json')
for method in summary['methods']:
    m = summary['methods'][method]
    assert m['total_count'] == len(scores) == 56
    assert m['valid_count'] == sum(row['methods'][method]['valid'] for row in scores)
    for control in ['source_training_sbs', 'historical_target_sbs']:
        common = [r for r in scores if r['methods'][method]['valid'] and r['methods'][control]['valid']]
        q = m['comparisons'][control]
        assert q['common_valid_n'] == len(common)
        vals = [(r['methods'][method]['distance']/r['methods'][control]['distance']-1)*100 for r in common]
        assert q['mean_instance_delta_pct'] == statistics.mean(vals)
        assert q['selector_wins']+q['ties']+q['control_wins'] == len(common)
assert len(read(P/'reports/all4_geometries.json')) == 4
events = [json.loads(x) for x in (P/'evidence/events.jsonl').read_text().splitlines()]
assert [x['event'] for x in events] == ['protocol_frozen', 'all_predictions_sealed', 'target_archive_open_started']
assert all(events[i]['monotonic_ns'] < events[i+1]['monotonic_ns'] for i in range(2))
assert all(events[i]['utc'] < events[i+1]['utc'] for i in range(2))
write(P/'evidence/independent_scalar_audit.json', {'verified_utc': utc(), 'source_means_scales_vectors_rederived_from_80_source_feature_rows': True,
      'all112_selector_predictions_independently_recomputed': True, 'independent_distance_accumulation_max_abs_roundoff': max_squared_distance_roundoff, 'all168_projected_costs_match_original_archive': True,
      'all56_scored_selections_and_metrics_checked': True, 'four_geometry_groups_present': True, 'seal_order_verified': True,
      'all_original_frozen_files_unchanged': True, 'no_new_solver_calls': True, 'no_target_route_revalidation_in_this_replay': 'Uses prior independently validated archived SUCCESS status; no new solver or route replay.',
      'process_cpu_s_through_audit': time.process_time()})

def shell_cpu(path):
    values = dict(x.split('=', 1) for x in Path(path).read_text().splitlines() if x.startswith(('wall_s=', 'user_s=', 'sys_s=')))
    return float(values['user_s'])+float(values['sys_s'])
base_cpu = sum(shell_cpu(P/'evidence'/name) for name in ['run_shell_time.txt', 'verify_shell_time.txt', 'audit_attempt01_shell_time.txt', 'audit_attempt02_shell_time.txt'])
assert base_cpu+time.process_time() < 5
write(P/'evidence/resource_scope.json', {'run_complete_shell_cpu_s': shell_cpu(P/'evidence/run_shell_time.txt'),
      'verification_complete_shell_cpu_s': shell_cpu(P/'evidence/verify_shell_time.txt'),
      'audit_attempt01_complete_shell_cpu_s': shell_cpu(P/'evidence/audit_attempt01_shell_time.txt'),
      'audit_attempt02_complete_shell_cpu_s': shell_cpu(P/'evidence/audit_attempt02_shell_time.txt'),
      'run_plus_verification_plus_failed_audit_complete_shell_cpu_s': base_cpu, 'audit_and_package_final_timing': 'See external FINAL_package_receipt.json and FINAL_shell_time.txt; final artifact cannot include its own completed-process timing.',
      'hard_limit_per_experiment_entry_process_s': 5, 'cumulative_budget_s': 5,
      'scope': 'Actual run, verification, independent scalar audit and ZIP production CPU. Source/target historical solving and authoring/inspection excluded. No complex supervisor.',
      'preflight_failed_before_python_started': True, 'solver_calls': 0, 'model_api_calls': 0, 'installations': 0})
files = sorted(p for p in P.rglob('*') if p.is_file() and p.name != 'SHA256SUMS.txt')
for p in files:
    rel = str(p.relative_to(P))
    assert not any(x in p.parts for x in ['__pycache__', '.venv', 'venv', '.git', 'inputs'])
    assert p.suffix not in {'.zip', '.pyc'}
    # Private data may appear only as scalar projections and input hashes, never full records/routes.
    if p.suffix == '.json':
        def keys(v):
            if isinstance(v, dict):
                for k, item in v.items():
                    assert k not in {'routes', 'route_audits', 'encoded_cumul_ranges', 'nodes'}, (rel, k)
                    keys(item)
            elif isinstance(v, list):
                for item in v: keys(item)
        keys(read(p))
(P/'SHA256SUMS.txt').write_text(''.join(f'{sha(p)}  {p.relative_to(P)}\n' for p in files))
files.append(P/'SHA256SUMS.txt')
zip_path = P.parent/(P.name+'_FINAL.zip')
assert not zip_path.exists(), 'Do not overwrite a finalized ZIP.'
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for p in files: z.write(p, str(p.relative_to(P)))
with zipfile.ZipFile(zip_path) as z:
    assert z.testzip() is None
    assert len(z.namelist()) == len(files)
    for p in files: assert z.read(str(p.relative_to(P))) == p.read_bytes()
receipt = {'completed_utc': utc(), 'zip_path': str(zip_path), 'sha256': sha(zip_path), 'bytes': zip_path.stat().st_size, 'file_count': len(files),
           'zip_crc_and_every_member_verified': True, 'clean_package_verified': True, 'cpu_through_package_crc_hash_verification_s': time.process_time(),
           'prior_run_verify_and_failed_audit_complete_shell_cpu_s': base_cpu, 'minimum_measured_cumulative_cpu_s': base_cpu+time.process_time(),
           'final_complete_package_process_shell_timing': str(P.parent/(P.name+'_FINAL_shell_time.txt')),
           'scope_note': 'This final in-process reading excludes only writing this receipt and process exit; the external shell receipt captures complete package processCPU. Sum shell receipts for completed-process total.',
           'no_upload': True}
write(P.parent/(P.name+'_FINAL_package_receipt.json'), receipt)
print(json.dumps(receipt, ensure_ascii=False, indent=2))
