"""Synthetic generator: no OR-Tools, solver outcomes, network, or rejection on difficulty.
Integer Euclidean coordinate units also equal travel-time units; demands are arbitrary
load units. Instances are synthetic and freely redistributable, not agricultural data.
"""
import math,random,statistics,hashlib,json
FAMILIES=['uniform','clustered','jitter_grid','elongated']
BASE_SEED=202610071900
SPLIT_SEED=202610071901
WINDOW_WIDTHS=[60,180]
N=100;K=10;CAPACITY=100;SERVICE=2;HORIZON=2000;DEPOT=(50,50)

def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def coordinate_set(family,rng):
    if family=='uniform':return [(rng.randrange(0,101),rng.randrange(0,101)) for _ in range(N)]
    if family=='clustered':
        centers=[(rng.uniform(12,88),rng.uniform(12,88)) for _ in range(4)]
        result=[]
        for i in range(N):
            c=centers[i%4];result.append(tuple(max(0,min(100,round(v+rng.gauss(0,6)))) for v in c))
        rng.shuffle(result);return result
    if family=='jitter_grid':
        result=[(round(5+10*x+rng.uniform(-3,3)),round(5+10*y+rng.uniform(-3,3))) for x in range(10) for y in range(10)]
        rng.shuffle(result);return result
    if family=='elongated':return [(rng.randrange(-100,201),rng.randrange(40,61)) for _ in range(N)]
    raise ValueError(family)

def generate():
    test_indices={}
    srng=random.Random(SPLIT_SEED)
    for f in FAMILIES:test_indices[f]=set(srng.sample(range(16),6))
    records=[];geometries=[]
    for fi,family in enumerate(FAMILIES):
        for j in range(16):
            gi=fi*16+j;seed=BASE_SEED+1009*gi;rng=random.Random(seed)
            gid=f'g{gi:03d}';xy=coordinate_set(family,rng);demands=[rng.randint(1,10) for _ in range(N)]
            ordered=sorted(range(1,101),key=lambda n:(math.atan2(xy[n-1][1]-DEPOT[1],xy[n-1][0]-DEPOT[0]),math.hypot(xy[n-1][0]-DEPOT[0],xy[n-1][1]-DEPOT[1]),n))
            chunks=[];chunk=[];load=0
            for n in ordered:
                if load+demands[n-1]>CAPACITY:chunks.append(chunk);chunk=[];load=0
                chunk.append(n);load+=demands[n-1]
            if chunk:chunks.append(chunk)
            assert len(chunks)<=K
            # Within each angular capacity-feasible sector, deterministic nearest next.
            routes=[];starts={};returns=[]
            for chunk in chunks:
                pending=set(chunk);route=[0];point=DEPOT;t=0.
                while pending:
                    n=min(pending,key=lambda i:((xy[i-1][0]-point[0])**2+(xy[i-1][1]-point[1])**2,i))
                    t+=math.hypot(xy[n-1][0]-point[0],xy[n-1][1]-point[1]);starts[n]=t
                    t+=SERVICE;point=xy[n-1];pending.remove(n);route.append(n)
                t+=math.hypot(point[0]-DEPOT[0],point[1]-DEPOT[1]);route.append(0);routes.append(route);returns.append(t)
            assert max(returns)<HORIZON
            geom=digest({'depot':list(DEPOT),'customers':sorted([list(z) for z in xy])})
            split='test' if j in test_indices[family] else 'train'
            geometries.append({'geometry_id':gid,'geometry_sha256':geom,'seed':seed,'family':family,'family_index':j,'split':split,'witness_routes':routes,'no_wait_service_starts':starts,'no_wait_returns':returns})
            for width in WINDOW_WIDTHS:
                name=f'{gid}_w{width:03d}'
                nodes=[{'id':0,'x':DEPOT[0],'y':DEPOT[1],'demand':0,'ready':0,'due':HORIZON,'service':0}]
                for n in range(1,101):
                    ready=max(0,math.floor(starts[n])-width//2)
                    nodes.append({'id':n,'x':xy[n-1][0],'y':xy[n-1][1],'demand':demands[n-1],'ready':ready,'due':ready+width,'service':SERVICE})
                records.append({'id':name,'family':family,'vehicles':K,'capacity':CAPACITY,'nodes':nodes,'geometry_id':gid,'geometry_sha256':geom,'split':split,'width':width,'seed':seed,'witness_routes':routes})
    assert len({g['geometry_sha256'] for g in geometries})==64
    return records,geometries

def features(d):
    cs=d['nodes'][1:];h=d['nodes'][0]['due']-d['nodes'][0]['ready'];ds=[n['demand'] for n in cs]
    xs=[n['x'] for n in cs];ys=[n['y'] for n in cs];cx=statistics.mean(xs);cy=statistics.mean(ys)
    xx=statistics.mean([(x-cx)**2 for x in xs]);yy=statistics.mean([(y-cy)**2 for y in ys]);cov=statistics.mean([(x-cx)*(y-cy) for x,y in zip(xs,ys)])
    trace=xx+yy;rms=math.sqrt(trace)
    nn=[min(math.hypot(a['x']-b['x'],a['y']-b['y']) for b in cs if b['id']!=a['id']) for a in cs]
    dep=d['nodes'][0]
    return {'instance':d['id'],'capacity_over_total_demand':d['capacity']/sum(ds),'demand_population_cv':statistics.pstdev(ds)/statistics.mean(ds),'mean_window_width_over_depot_duration':statistics.mean([n['due']-n['ready'] for n in cs])/h,'mean_service_over_depot_duration':statistics.mean([n['service'] for n in cs])/h,'rms_radius_over_horizon':rms/h,'mean_nn_over_rms_radius':statistics.mean(nn)/rms if rms else 0.,'covariance_anisotropy':(trace+math.sqrt((xx-yy)**2+4*cov*cov))/(2*trace) if trace else 0.5,'depot_centroid_over_rms_radius':math.hypot(cx-dep['x'],cy-dep['y'])/rms if rms else 0.}

def as_text(d):
    lines=[d['id'],'','VEHICLE','NUMBER     CAPACITY',f"{d['vehicles']} {d['capacity']}",'','CUSTOMER','CUST NO. XCOORD. YCOORD. DEMAND READY TIME DUE DATE SERVICE TIME']
    for n in d['nodes']:lines.append(' '.join(str(n[k]) for k in ['id','x','y','demand','ready','due','service']))
    return '\n'.join(lines)+'\n'
