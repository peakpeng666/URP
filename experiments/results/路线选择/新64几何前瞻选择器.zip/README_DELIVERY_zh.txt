最终交付入口（以本说明为准）

1. 主报告：reports/report_with_both_controls_zh.txt。
2. 机器可读摘要：reports/summary_with_both_controls.json。
3. 全部48测试问题主表：reports/test_all48_with_both_controls.csv/.json。
4. 两选择器×两对照汇总：reports/primary_two_control_table.csv；24几何分层：reports/per_geometry_both_controls.csv/.json。
5. 原始240训练+144测试请求、所有失败与返回路线在raw/。原来的无后缀报告与ZIP保留，供追溯；两对照版仅把协议已有的训练SBS直接对照完整呈现，不新增求解或改预测。

必须同时看两个对照：固定SAV来自旧研究预先选定；训练SBS=PCI只用本轮80训练问题决定。原四特征主方法45/48成功，低于两个对照；共同成功的距离优势不能说成整体改善。预定空间消融48/48，与训练SBS同成功率，全48平均距离降低约1.44%。这是合成数据的有利描述结果，不能称农业泛化或SOTA。

全部64几何/128问题为本项目新生成合成数据，完整文本与JSON输入可再分发。两时间窗在几何分割中同组。生成窗口以确定性容量合法见证为中心，存在构造偏置，见证未送入求解器。统计单位是24测试几何。没有补跑、失败fallback、模型/API调用、新安装或上传。

归档例外必须保留：protocol/freeze.json误纳运行时尚为空的evidence/shell_time.txt。该文件在主进程退出后被bash填入时间，因此不能无保留声称最终全部冻结文件不变。最终ZIP不收原路径，以新增evidence/final_shell_time.txt提供完整回执；evidence/archive_erratum.json保存原空文件SHA、最终SHA和解释。所有科学冻结源码、输入、参数、分割、特征及封存模型/预测保持不变，旧freeze和旧ZIP不修改。

原进程完整CPU=101.860秒（bash user+sys，含退出）；进程内打包后采样101.322秒，差异来自采样时点与退出。短训练/推荐CPU为0的采样不能解释为零开销，wall非零。事后补充对照呈现与归档CPU另列。最终ZIP完整SHA/CRC及新增文件清单由最终打包回执提供。

运行重现：generator.py可单独生成全部合成数据；study.py使用已有OR-Tools9.14.6206及source/requirements.lock固定依赖。不可在本冻结目录直接重跑。新实验需要新空目录、source与prior_selector_protocol副本；原study还显式校验历史源码路径的provenance，因此原路径不可用时需先恢复匹配的历史源码供核验。此限制只涉及历史来源校验，不涉及旧私人实例数据；本包不含旧实例。固定wall预算存在运行时噪声，不承诺数值逐位复现。
