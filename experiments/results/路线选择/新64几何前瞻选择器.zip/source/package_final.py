"""Postrun final packaging only. Preserves original experiment and archive.
No solver imports, no model changes, no network or upload.
"""
import resource
resource.setrlimit(resource.RLIMIT_CPU,(4,4))
import hashlib,json,zipfile,time
from pathlib import Path
from datetime import datetime,timezone
P=Path(__file__).resolve().parent.parent
START=time.process_time()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
freeze=json.loads((P/'protocol/freeze.json').read_text());changed=[n for n,h in freeze['sha256'].items() if sha(P/n)!=h]
assert changed==['evidence/shell_time.txt'],changed
for line in (P/'SHA256SUMS.txt').read_text().splitlines():
 h,n=line.split('  ',1);assert sha(P/n)==h,n
seal=json.loads((P/'evidence/prediction_seal.json').read_text())
assert sha(P/'raw/test_predictions_sealed.json')==seal['prediction_sha256'];assert sha(P/'raw/training_models.json')==seal['model_sha256']
assert (P/'evidence/auditor_review.txt').exists()
base=json.loads((P.parent/(P.name+'_package_receipt.json')).read_text());report=json.loads((P/'evidence/two_control_reporting_receipt.json').read_text())
resource_scope={'utc':datetime.now(timezone.utc).isoformat(),'original_experiment_full_shell_cpu_s':101.860,'original_experiment_hard_cpu_limit_s':180,'original_experiment_scope':'Single process,imports/generation/freeze/384solves/checks/fit/predict/bootstrap/reverification/originalZIP;no supervision or retry.','two_control_reporting_process_cpu_sample_s':report['process_cpu_sample_s'],'two_control_reporting_hard_limit_s':8,'independent_audit_full_shell_cpu_s':0.662,'independent_audit_hard_limit_s':5,'additional_second_readonly_audit_cpu_s':None,'additional_second_readonly_audit_note':'Not separately metered. Read-only verification,zero solver calls. Do not present measured subtotal as exact all-audit total.','final_packaging_hard_limit_s':4,'measured_subtotal_before_final_packaging_s':101.860+report['process_cpu_sample_s']+0.662,'limit_scope':'Original experiment single-process180s limit is real;postrun presentation,independent audits and finalpackaging are separate stages. No claim of one OS-enforced global cap across separate audit processes.','source_authoring_and_tool_inspection_excluded':True,'solver_calls_total':384,'extra_solver_calls_after_primary_run':0,'uploads':0,'model_api_calls':0}
write(P/'evidence/delivery_resource_scope.json',resource_scope)
files=[p for p in sorted(P.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc' and p.name not in ['stdout.log','stderr.log','shell_time.txt','SHA256SUMS_FINAL.txt']]
allowed={'source','protocol','inputs','raw','reports','evidence'}
assert all(p.relative_to(P).parts[0] in allowed or p.name in ['README_zh.txt','README_DELIVERY_zh.txt','SHA256SUMS.txt'] for p in files)
assert all(p.suffix in ['.py','.txt','.json','.jsonl','.csv','.textproto','.lock'] for p in files)
sums=''.join(sha(p)+'  '+str(p.relative_to(P))+'\n' for p in files);(P/'SHA256SUMS_FINAL.txt').write_text(sums);files.append(P/'SHA256SUMS_FINAL.txt')
archive=P.parent/(P.name+'_FINAL.zip')
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in files:z.write(p,str(p.relative_to(P)))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(files)
 assert 'evidence/shell_time.txt' not in z.namelist() and 'evidence/final_shell_time.txt' in z.namelist()
 for line in sums.splitlines():h,n=line.split('  ',1);assert hashlib.sha256(z.read(n)).hexdigest()==h,n
receipt={'finished_utc':datetime.now(timezone.utc).isoformat(),'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'file_count':len(files),'final_packaging_process_cpu_sample_s':time.process_time(),'final_packaging_body_cpu_s':time.process_time()-START,'measured_experiment_reporting_audit_packaging_subtotal_s':resource_scope['measured_subtotal_before_final_packaging_s']+time.process_time(),'unmetered_additional_readonly_audit_disclosed':True,'crc_and_every_inner_hash_verified':True,'all_original_173_artifact_hashes_unchanged':True,'core_frozen_151_files_unchanged':True,'one_frozen_shell_timing_exception_documented':True,'original_archive_preserved_sha256':base['sha256'],'both_planned_controls_fully_presented':True,'uploaded':False,'extra_solver_calls':0}
write(P.parent/(P.name+'_FINAL_package_receipt.json'),receipt);(P.parent/(P.name+'_FINAL.zip.sha256')).write_text(receipt['sha256']+'  '+archive.name+'\n')
print(json.dumps(receipt,ensure_ascii=False))
