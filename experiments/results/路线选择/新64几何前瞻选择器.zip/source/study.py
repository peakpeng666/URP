"""One prospective synthetic heldout study. Run once. No network, warm starts, retries,
subprocesses, training search, adaptive choices, or test outcomes before prediction seal.
"""
import resource
resource.setrlimit(resource.RLIMIT_CPU,(180,180))
import os
os.environ['OMP_NUM_THREADS']='1'
os.environ['PYTHONDONTWRITEBYTECODE']='1'
import sys,json,math,time,hashlib,statistics,csv,collections,platform,traceback,zipfile,random
from pathlib import Path
from datetime import datetime,timezone
from decimal import Decimal,localcontext,ROUND_HALF_UP
import generator,selector,core,checker
from ortools.constraint_solver import pywrapcp
P=Path(__file__).resolve().parent.parent
CONFIGS=selector.CONFIGS
STRATEGIES=['PARALLEL_CHEAPEST_INSERTION','PATH_CHEAPEST_ARC','SAVINGS']
METHODS=['primary_1nn4','spatial_1nn8','fixed_sav250','training_sbs']
START=time.perf_counter()
EVENT_SEQUENCE=0
TOL=1e-6
OLD_SOLVER=Path('/workspace/shared/solver_portfolio_headroom_20261007')
OLD_SELECTOR=Path('/workspace/shared/geometry_heldout_selection_20261007')

def utc():return datetime.now(timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def digest(v):return generator.digest(v)
def write(rel,v):
    (P/rel).write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def read(rel):return json.loads((P/rel).read_text())
def csvwrite(rel,rs):
    with (P/rel).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rs[0]));w.writeheader();w.writerows(rs)
def event(kind,**data):
    global EVENT_SEQUENCE
    e={'event_sequence':EVENT_SEQUENCE,'utc':utc(),'monotonic_ns':time.monotonic_ns(),'event':kind,**data};EVENT_SEQUENCE+=1
    with (P/'raw/events.jsonl').open('a') as f:f.write(json.dumps(e,allow_nan=False)+'\n');f.flush();os.fsync(f.fileno())
    return e

def prepare():
    assert not (P/'protocol/freeze.json').exists(),'Frozen study exists: no silent overwrite or rerun.'
    assert not (P/'raw/events.jsonl').exists()
    assert core.importlib.metadata.version('ortools')=='9.14.6206'
    assert checker.tests()
    records,geometries=generator.generate();features={};feature_costs={};manifest=[];witnesses=[]
    for d in records:
        path=P/'inputs'/f"{d['id']}.txt";path.write_text(generator.as_text(d))
        independent=checker.read_original(path);w=checker.check(independent,d['witness_routes']);assert w['valid'],(d['id'],w['errors'])
        c=time.process_time();t=time.perf_counter();features[d['id']]=generator.features(d)
        feature_costs[d['id']]={'cpu_s':time.process_time()-c,'wall_s':time.perf_counter()-t}
        manifest.append({'instance':d['id'],'geometry_id':d['geometry_id'],'geometry_sha256':d['geometry_sha256'],'family':d['family'],'split':d['split'],'seed':d['seed'],'window_width':d['width'],'input_sha256':sha(path),'semantic_sha256':digest(d),'bytes':path.stat().st_size})
        witnesses.append({'instance':d['id'],'valid':w['valid'],'distance':w['distance'],'vehicles_used':w['vehicles_used'],'minimum_window_margin':w['minimum_window_margin'],'routes':d['witness_routes'],'route_audits':w['route_audits']})
    assert len(records)==128 and len({g['geometry_sha256'] for g in geometries})==64
    split={part:sorted(d['id'] for d in records if d['split']==part) for part in ['train','test']}
    assert len(split['train'])==80 and len(split['test'])==48
    for f in generator.FAMILIES:
        assert sum(g['family']==f and g['split']=='train' for g in geometries)==10
        assert sum(g['family']==f and g['split']=='test' for g in geometries)==6
    assert not {d['geometry_sha256'] for d in records if d['split']=='train'} & {d['geometry_sha256'] for d in records if d['split']=='test'}
    reqs=[]
    for phase in ['train','test']:
        # Independent predetermined geometry interleaving, not based on results.
        names=list(split[phase]);random.Random(generator.SPLIT_SEED+(0 if phase=='train' else 1)).shuffle(names)
        for i,n in enumerate(names):
            for j in range(3):
                idx=(i+j)%3
                reqs.append({'sequence':len(reqs),'phase':phase,'instance':n,'config_id':CONFIGS[idx],'strategy':STRATEGIES[idx],'budget_ms':250,'run_id':n+'__'+CONFIGS[idx],'seed':core.SEED})
    for c,s in zip(CONFIGS,STRATEGIES):
        pars=core.params(250,s);assert not pywrapcp.FindErrorInRoutingSearchParameters(pars)
        (P/f'protocol/parameters_{c}.textproto').write_text(str(pars))
    base=core.params(250,STRATEGIES[0])
    for s in STRATEGIES[1:]:
        pars=core.params(250,s);pars.first_solution_strategy=base.first_solution_strategy;assert pars==base
    prior=read('protocol/prior_selector_protocol.json')
    assert prior['features_in_order']==selector.PRIMARY
    oldpaths=[OLD_SOLVER/'source/core.py',OLD_SOLVER/'source/checker.py',OLD_SOLVER/'source/requirements.lock',OLD_SELECTOR/'protocol/protocol.json',OLD_SELECTOR/'source/study.py']
    write('protocol/source_provenance.json',[{'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size} for p in oldpaths])
    protocol={
      'study_id':'PROSPECTIVE_SYNTHETIC64_GEOMETRY_SELECTION_V1',
      'question':'Does the fixed four-feature 1-NN show useful heldout selection with substantially more new independent synthetic geometries, and what does a predeclared spatial-feature ablation show?',
      'prior_knowledge':'Prior archived56/four-geometry selection was unsuccessful and SAV was a strong fixed baseline. Old outcomes are not training or test samples here; only method/source protocol reused.',
      'population':'64 freshly generated seeded geometries,16 each uniform/clustered/jitter_grid/elongated;100 mandatory customers per geometry;2 widths per geometry;128 problems. Every generated geometry retained. Synthetic only, not real agricultural data.',
      'generator':'See frozen generator.py. Uniform integer[0,100]^2;clustered four iid Uniform[12,88]^2 centers with round/clipped Gaussian sd6 offsets,25 customers/center; jitter_grid10x10 at5+10i with independent Uniform[-3,3] jitters rounded;elongated integer x[-100,200],y[40,60]. Depot(50,50). Customer demands iid integer1..10 after coordinate generation. Independent per-geometry PRNG seeds BASE+1009*index. No solve-based filtering.',
      'fixed_semantics':{'customers':100,'vehicle_limit':10,'capacity':100,'service':2,'depot_open':0,'depot_close':2000,'window_widths':[60,180],'travel':'Continuous Euclidean distance equals travel time; arbitrary synthetic distance,time,load units,not km/min/ha.','windows':'Inclusive service-start windows; waiting allowed, service duration included before onward travel; return depot by2000.','objective':'Total distance only; no vehicle-count priority, no drops, no fixed vehicle cost.'},
      'witness_generation':'Angle-sort customers around depot; greedy capacity chunks; deterministic nearest-next within each chunk, ties node ID. With start0 calculate no-wait arrivals. ready=max(0,floor(arrival)-width/2),due=ready+width. Validate ALL witnesses independently from text inputs before freeze; any assertion aborts entire study, no replacement or filtering. Witness routes are NOT supplied to solver.',
      'generator_bias':'Windows deliberately center around one deterministic angular/nearest-neighbor capacity-feasible construction. Thus known feasible and biased toward that construction,not representative operational sampling. Families differ in spread and coordinates and overlap in labels;64 PRNG geometry units,2 related widths each. One seed per geometry and one solver run per configuration; no runtime noise replication.',
      'split':'Fixed seeded per-family sampling:10 train and6 test geometries each;80 train problems/48 test problems. Both widths always same split. Complete split frozen before any solve. Family/geometry identity is audit/split metadata,never a numeric/categorical model feature.',
      'configurations':dict(zip(CONFIGS,STRATEGIES)),
      'search':'Same frozen ORTools9.14.6206 params as prior:GLS lambda0.1,250ms wall search cap,CP enabled,CP-SAT disabled,CP ReSeed2026100708.Only first solution strategy differs. Fresh models,serial calls,no warm start/fallback/rerun.',
      'encoding':{'scale':1000000,'cost':'Integer Euclidean nearest rounding exact using isqrt;ties up.','travel':'Conservative ceil(distance*S)+origin service*S.','bounds':'Cost absolute error <=0.5*(100+vehicles_used)/S. Conservative time excess per route<101/S; may exclude continuous boundary solutions but windows here have witness slack.','independent_validation':'Original text coordinates continuous replay all returned routes,coverage/capacity/start windows/service/depot return; independent Decimal50 digit nearest objective and rounding bound.'},
      'primary_features':selector.PRIMARY,'spatial_ablation_features':selector.PRIMARY+selector.SPATIAL,
      'spatial_definitions':{'rms_radius_over_horizon':'sqrt(mean((x-cx)^2+(y-cy)^2))/2000 for customer centroid(cx,cy).','mean_nn_over_rms_radius':'Mean each customer nearest other-customer Euclidean distance divided by RMS radius;distinct customer IDs,coincident coords allowed;0 if radius0.','covariance_anisotropy':'Largest eigenvalue of population2x2 customer covariance divided by trace;0.5 if trace0.','depot_centroid_over_rms_radius':'Euclidean depot-to-customer-centroid distance /RMS radius;0 if radius0.'},
      'fixed_selector':'Exactly k1,squared Euclidean on train-only mean/population-sd standardized features;sd0->1. Original primary four-feature rule and same predeclared ablation;no feature choice,tuning or test-label use.',
      'training_sbs':prior['training_sbs'],'training_labels':prior['training_labels'],'neighbor_ties':prior['neighbor_ties'],
      'all_failures_training':'Keep unlabelable cases in training records and feature scaling,omit only as neighbors and explicitly report. If none labelable,use training SBS under original rule. No sample substitution.',
      'primary_baseline':'Fixed sav250 selected from prior study before new results. Training-only SBS optional secondary;no test-fitted SBS.',
      'prediction_seal':'After exactly240 training calls,fit only80 training feature/outcome rows. Predict48 test problems with test input features only;write models,predictions and sha256+timestamp,fsync seal before first test request. Test144 calls afterwards,models unchanged.',
      'failures':'All requests retained. Any returned assignment must pass checker. Timeout/no_solution never means mathematical infeasibility,as independent feasible witness exists. No numerical failure penalty,no free fallback,no retry. If hard CPU kill prevents reporting,missing requests must be recovered from frozen requests minus flushed result IDs;not-started and interrupted requests remain unobserved/NOT_RUN_BUDGET,never assumed success. No already-materialized missing-status ledger is claimed.',
      'evaluation':'All48 test rows and each method success coverage first. Distance comparisons vs fixedSAV only on common-success subset,explicit denominator;positive mean(method/SAV-1)% means worse.24 geometries are statistical units. Include per-geometry/per-family breakdown and posthoc VBS only descriptive,not optimum or executable free policy.',
      'bootstrap':'5000 seeded resamples of24 test geometry clusters with replacement. Coverage difference uses all24. Conditional quality:compute per-geometry mean relative delta over common-success widths;bootstrap average of available such geometry means and disclose usable count.95%percentile intervals descriptive only,conditional on observed success,no multiple-comparison significance/winner claim.',
      'resources':'Single process RLIMIT_CPU soft=hard180seconds established before imports,includes all preparation/solving/checking/fitting/analysis/ZIP. No supervisor process or hidden solver retries.384 requested calls*250ms=96s nominal wall search cap,not CPU. Measure search/model/checker and feature/training/prediction separately;software authoring/inspection not experimental processCPU. Original bash wall/user/sys receipt supplementary. SIGKILL may prevent final reports but per-request logs flushed.',
      'distribution':'New synthetic full inputs,witnesses,routes,raw failures,source,freeze,models,sealed predictions,report,and evidence in clean ZIP. Exclude venv,caches,credentials,old private input data. No upload,new installations,model/API calls,purchases orCodex tasks.'}
    write('protocol/protocol.json',protocol);write('protocol/input_manifest.json',manifest);write('protocol/geometries.json',geometries);write('protocol/split.json',split);write('protocol/features.json',features);write('protocol/requests.json',reqs);write('inputs/instances.json',records)
    write('evidence/witness_checks.json',witnesses);write('evidence/checker_tests.json',{'passed':True,'tests':checker.tests()});write('evidence/feature_extraction.json',feature_costs)
    write('evidence/environment.json',{'utc':utc(),'python':sys.version,'python_executable':sys.executable,'platform':platform.platform(),'ortools':core.importlib.metadata.version('ortools'),'hard_cpu_limit_s':180,'single_process':True,'cpu_count_os':os.cpu_count(),'OMP_NUM_THREADS':os.environ['OMP_NUM_THREADS'],'runtime_reproducibility':'Fixed params/seeds do not make wall-time-truncated solver output bitwise deterministic.'})
    frozen=[p for root in ['source','protocol','inputs','evidence'] for p in (P/root).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='freeze.json']
    write('protocol/freeze.json',{'frozen_utc':utc(),'solver_calls_before_freeze':0,'request_count':384,'train_calls':240,'test_calls':144,'geometry_count':64,'instance_count':128,'sha256':{str(p.relative_to(P)):sha(p) for p in sorted(frozen)}})
    event('protocol_frozen',freeze_sha256=sha(P/'protocol/freeze.json'),solver_calls_before_freeze=0)
    print('FROZEN 64 geometries;128 problems;384 requested solves',flush=True)
    return {d['id']:d for d in records},features,split,reqs

SQRTCACHE={}
def check_result(d,r):
    t=time.perf_counter();c=time.process_time();audit=None
    if r['assignment_returned']:
        original=checker.read_original(P/'inputs'/f"{d['id']}.txt");audit=checker.check(original,r['routes'])
        if audit['valid']:
            obj=0;arcs=0
            for route in r['routes']:
                for a,b in zip(route['nodes'],route['nodes'][1:]):
                    x=original['nodes'][a];y=original['nodes'][b];sq=(x[0]-y[0])**2+(x[1]-y[1])**2
                    if sq not in SQRTCACHE:
                        with localcontext() as ctx:ctx.prec=50;SQRTCACHE[sq]=int((Decimal(sq).sqrt()*core.SCALE).to_integral_value(rounding=ROUND_HALF_UP))
                    obj+=SQRTCACHE[sq];arcs+=1
            err=abs(obj/core.SCALE-audit['distance']);bound=arcs*0.5/core.SCALE+1e-9
            audit.update(independent_objective_integer=obj,reported_objective_integer=r['objective_integer'],rounding_error=err,rounding_bound=bound,arc_count=arcs)
            if obj!=r['objective_integer']:audit['errors'].append('objective mismatch')
            if err>bound:audit['errors'].append('rounding error exceeds bound')
            audit['valid']=not audit['errors']
        r['outcome']='SUCCESS' if audit['valid'] else 'FAIL_CHECKER'
    r['check_cpu_s']=time.process_time()-c;r['check_wall_s']=time.perf_counter()-t
    r['request_accounted_cpu_s']=r.get('total_cpu_s',0)+r['check_cpu_s'];r['request_accounted_wall_s']=r.get('total_wall_s',0)+r['check_wall_s']
    if audit:r['check_summary']={k:v for k,v in audit.items() if k!='route_audits'}
    return audit

def execute(phase,reqs,ds):
    result=[]
    with (P/f'raw/{phase}_results.jsonl').open('x') as out,(P/f'raw/{phase}_continuous_checks.jsonl').open('x') as ck:
        for req in [r for r in reqs if r['phase']==phase]:
            start=event('request_started',run_id=req['run_id'],phase=phase,request_sequence=req['sequence']);c=time.process_time();t=time.perf_counter()
            try:
                r=core.solve(ds[req['instance']],req);audit=check_result(ds[req['instance']],r)
            except Exception as ex:
                r={**req,'assignment_returned':False,'outcome':'FAIL_EXCEPTION','routes':None,'error':repr(ex),'traceback':traceback.format_exc(),'request_accounted_cpu_s':time.process_time()-c,'request_accounted_wall_s':time.perf_counter()-t};audit=None
            r['request_start_event']=start;r['request_end_utc']=utc()
            if audit:ck.write(json.dumps({'run_id':req['run_id'],**audit},allow_nan=False)+'\n');ck.flush()
            out.write(json.dumps(r,allow_nan=False)+'\n');out.flush();os.fsync(out.fileno());result.append(r)
            event('request_finished',run_id=req['run_id'],phase=phase,outcome=r['outcome'])
            if len(result)%24==0:print(phase,len(result),r['outcome'],flush=True)
    return result

def good(r):return r['outcome']=='SUCCESS'
def distance(r):return r['check_summary']['distance'] if good(r) else None

def fit_and_seal(train,features,split):
    outcomes={(r['instance'],r['config_id']):{'valid':good(r),'distance':distance(r)} for r in train}
    tf={n:features[n] for n in split['train']};models={};overhead={};predictions=[]
    for method,fs in [('primary_1nn4',selector.PRIMARY),('spatial_1nn8',selector.PRIMARY+selector.SPATIAL)]:
        t=time.perf_counter();c=time.process_time();models[method]=selector.fit(tf,outcomes,fs);overhead[method]={'training_cpu_s':time.process_time()-c,'training_wall_s':time.perf_counter()-t,'prediction_cpu_s':0.,'prediction_wall_s':0.}
    assert models['primary_1nn4']['sbs']==models['spatial_1nn8']['sbs']
    for n in split['test']:
        p={'instance':n,'methods':{}}
        for method in models:
            t=time.perf_counter();c=time.process_time();pred=selector.predict(models[method],[features[n][f] for f in models[method]['features']]);pc=time.process_time()-c;pw=time.perf_counter()-t
            overhead[method]['prediction_cpu_s']+=pc;overhead[method]['prediction_wall_s']+=pw;p['methods'][method]=pred
        p['methods']['fixed_sav250']={'selected_config':'sav250'};p['methods']['training_sbs']={'selected_config':models['primary_1nn4']['sbs']};predictions.append(p)
    write('raw/training_models.json',models);write('raw/test_predictions_sealed.json',predictions);write('raw/recommendation_overhead.json',overhead)
    for name in ['raw/training_models.json','raw/test_predictions_sealed.json']:
        with (P/name).open('rb') as f:os.fsync(f.fileno())
    seal={'sealed_utc':utc(),'test_solver_calls_before_seal':0,'training_requests_completed':len(train),'test_predictions':48,'prediction_sha256':sha(P/'raw/test_predictions_sealed.json'),'model_sha256':sha(P/'raw/training_models.json'),'train_results_sha256':sha(P/'raw/train_results.jsonl'),'freeze_sha256':sha(P/'protocol/freeze.json')}
    write('evidence/prediction_seal.json',seal)
    with (P/'evidence/prediction_seal.json').open('rb') as f:os.fsync(f.fileno())
    event('predictions_sealed',**seal)
    print('SEALED 48 test predictions BEFORE first test solve; training SBS='+models['primary_1nn4']['sbs'],flush=True)
    return predictions,models,overhead

def mean(xs):return statistics.mean(xs) if xs else None

def compare(rows,method):
    a=method;b='fixed_sav250';common=[r for r in rows if r[a+'_valid'] and r[b+'_valid']]
    ratios=[100*(r[a+'_distance']/r[b+'_distance']-1) for r in common];sa=sum(r[a+'_distance'] for r in common);sb=sum(r[b+'_distance'] for r in common)
    return {'method':method,'n_all':len(rows),'successes':sum(r[a+'_valid'] for r in rows),'failures':sum(not r[a+'_valid'] for r in rows),'success_rate':sum(r[a+'_valid'] for r in rows)/len(rows),'sav_successes':sum(r[b+'_valid'] for r in rows),'common_success_n':len(common),'method_only_success':sum(r[a+'_valid'] and not r[b+'_valid'] for r in rows),'sav_only_success':sum(not r[a+'_valid'] and r[b+'_valid'] for r in rows),'both_failed':sum(not r[a+'_valid'] and not r[b+'_valid'] for r in rows),'wins':sum(r[a+'_distance']<r[b+'_distance']-TOL for r in common),'ties':sum(abs(r[a+'_distance']-r[b+'_distance'])<=TOL for r in common),'losses':sum(r[a+'_distance']>r[b+'_distance']+TOL for r in common),'mean_relative_method_vs_sav_pct':mean(ratios),'sum_distance_reduction_vs_sav_pct':100*(1-sa/sb) if sb else None,'method_common_distance_sum':sa,'sav_common_distance_sum':sb,'selected_config_counts':dict(collections.Counter(r[a+'_config'] for r in rows)),'referenced_selected_solver_request_cpu_s':sum(r[a+'_cpu_s'] for r in rows)}

def bootstrap(geo):
    result={};rng=random.Random(202610071902)
    indexes=[[rng.randrange(24) for _ in range(24)] for _ in range(5000)]
    def interval(xs):
        xs=sorted(xs);return [xs[int(.025*(len(xs)-1))],xs[int(.975*(len(xs)-1))]] if xs else None
    for method in METHODS:
        st=[next(x for x in g['comparisons'] if x['method']==method) for g in geo]
        quality=[s['mean_relative_method_vs_sav_pct'] for s in st];coverage=[100*(s['successes']-s['sav_successes'])/s['n_all'] for s in st]
        qs=[];cs=[]
        for ix in indexes:
            v=[quality[i] for i in ix if quality[i] is not None]
            if v:qs.append(mean(v))
            cs.append(mean([coverage[i] for i in ix]))
        usable=[v for v in quality if v is not None]
        result[method]={'geometry_units':24,'replicates':5000,'seed':202610071902,'usable_common_success_geometry_units':len(usable),'equal_geometry_mean_relative_pct':mean(usable),'conditional_quality_percentile95_pct':interval(qs),'mean_coverage_difference_percentage_points':mean(coverage),'coverage_difference_percentile95_percentage_points':interval(cs),'interpretation':'Descriptive geometry-cluster bootstrap;quality conditional on returned valid solutions,not all-instance gain/significance.'}
    return result

def analyze(train,test,preds,models,overhead,ds):
    by={(r['instance'],r['config_id']):r for r in test};rows=[]
    for p in preds:
        n=p['instance'];d=ds[n];r={'instance':n,'geometry_id':d['geometry_id'],'geometry_sha256':d['geometry_sha256'],'family':d['family'],'window_width':d['width']}
        for c in CONFIGS:
            v=by[n,c];r[c+'_outcome']=v['outcome'];r[c+'_distance']=distance(v)
        for m in METHODS:
            c=p['methods'][m]['selected_config'];v=by[n,c];r.update({m+'_config':c,m+'_valid':good(v),m+'_outcome':v['outcome'],m+'_distance':distance(v),m+'_cpu_s':v['request_accounted_cpu_s']})
        valid=[by[n,c] for c in CONFIGS if good(by[n,c])];o=min(valid,key=distance) if valid else None
        r.update(oracle_valid=o is not None,oracle_config=o['config_id'] if o else None,oracle_distance=distance(o) if o else None);rows.append(r)
    summaries=[compare(rows,m) for m in METHODS];geo=[]
    for gid in sorted({r['geometry_id'] for r in rows}):
        subset=[r for r in rows if r['geometry_id']==gid];geo.append({'geometry_id':gid,'geometry_sha256':subset[0]['geometry_sha256'],'family':subset[0]['family'],'n':len(subset),'comparisons':[compare(subset,m) for m in METHODS]})
    families=[{'family':f,'geometry_count':6,'comparisons':[compare([r for r in rows if r['family']==f],m) for m in METHODS]} for f in generator.FAMILIES]
    config_stats=[]
    for phase,rr in [('train',train),('test',test)]:
        for c in CONFIGS:
            sub=[r for r in rr if r['config_id']==c];config_stats.append({'phase':phase,'config':c,'n':len(sub),'successes':sum(good(r) for r in sub),'outcomes':dict(collections.Counter(r['outcome'] for r in sub)),'solve_cpu_s':sum(r['solve_cpu_s'] for r in sub if 'solve_cpu_s' in r),'model_cpu_s':sum(r['model_cpu_s'] for r in sub if 'model_cpu_s' in r),'check_cpu_s':sum(r.get('check_cpu_s',0) for r in sub),'request_cpu_s':sum(r['request_accounted_cpu_s'] for r in sub)})
    oracle_common=[r for r in rows if r['oracle_valid'] and r['fixed_sav250_valid']]
    oracle={'valid':sum(r['oracle_valid'] for r in rows),'n_all':48,'common_with_sav_n':len(oracle_common),'mean_relative_oracle_vs_sav_pct':mean([100*(r['oracle_distance']/r['fixed_sav250_distance']-1) for r in oracle_common]),'sum_distance_reduction_vs_sav_pct':100*(1-sum(r['oracle_distance'] for r in oracle_common)/sum(r['fixed_sav250_distance'] for r in oracle_common)) if oracle_common else None,'meaning':'Posthoc best valid among three250ms results,not optimum and not free executable selector.'}
    summary={'study_id':'PROSPECTIVE_SYNTHETIC64_GEOMETRY_SELECTION_V1','new_geometries':64,'train_geometries':40,'test_geometries':24,'train_problems':80,'test_problems':48,'solver_calls':384,'training_sbs':models['primary_1nn4']['sbs'],'unlabelable_training':models['primary_1nn4']['skipped_unlabelable_training_instances'],'methods':summaries,'config_stats':config_stats,'geometry_bootstrap':bootstrap(geo),'oracle':oracle,'recommendation_overhead':overhead}
    write('reports/test_all48.json',rows);csvwrite('reports/test_all48.csv',rows);write('reports/per_geometry.json',geo);write('reports/per_family.json',families);write('reports/summary.json',summary);write('reports/all_failures.json',[r for r in train+test if not good(r)])
    flat=[]
    for g in geo:
        for c in g['comparisons']:flat.append({'geometry_id':g['geometry_id'],'family':g['family'],**{k:v for k,v in c.items() if k!='selected_config_counts'}})
    csvwrite('reports/per_geometry.csv',flat)
    fmt=lambda x:'NA' if x is None else f'{x:.6f}'
    lines=['64个新合成几何的前瞻封存选择器实验','',f"独立几何64（训练40、测试24），每个几何两种时间窗，共128问题、384请求。测试分母48，不把128问题或384请求当独立几何。",'主方法保留原四特征1-NN；空间8特征1-NN为预定消融。固定SAV250为事先指定强基线；另列训练内SBS。全部测试预测在第一条测试求解前封存。','',f"训练SBS={summary['training_sbs']}；全部配置失败、无法生成标签的训练问题{len(summary['unlabelable_training'])}/80，具体{summary['unlabelable_training']}。这些问题未替换，保留训练标准化、仅不能作为有标签近邻。",'','测试48问题全覆盖与同样本距离对比：正的平均相对差表示比SAV差；总距离降低为正才是改进。']
    for s in summaries:
        lines += [f"{s['method']}:成功{s['successes']}/48（{s['success_rate']*100:.2f}%）；对固定SAV共同成功{s['common_success_n']}/48，方法独有成功{s['method_only_success']}、SAV独有成功{s['sav_only_success']}、共同失败{s['both_failed']}；胜/平/负{s['wins']}/{s['ties']}/{s['losses']}；平均(method/SAV-1)={fmt(s['mean_relative_method_vs_sav_pct'])}%，共同成功总距离降低{fmt(s['sum_distance_reduction_vs_sav_pct'])}%。预测分布{s['selected_config_counts']}。"]
        b=summary['geometry_bootstrap'][s['method']];lines +=[f"  几何单位：共同成功可用{b['usable_common_success_geometry_units']}/24；等权几何平均相对差{fmt(b['equal_geometry_mean_relative_pct'])}%，描述性95%bootstrap区间{b['conditional_quality_percentile95_pct']}；覆盖率差百分点{fmt(b['mean_coverage_difference_percentage_points'])}，区间{b['coverage_difference_percentile95_percentage_points']}。"]
    lines +=['','逐配置训练/测试状态：']
    for s in config_stats:lines +=[f"{s['phase']}/{s['config']}:{s['successes']}/{s['n']}成功，{s['outcomes']}；搜索CPU{s['solve_cpu_s']:.6f}s，建模CPU{s['model_cpu_s']:.6f}s，独立验证CPU{s['check_cpu_s']:.6f}s。"]
    lines +=['',f"描述性事后oracle：合法{oracle['valid']}/48；与SAV共同成功{oracle['common_with_sav_n']}，平均相对差{fmt(oracle['mean_relative_oracle_vs_sav_pct'])}%，总距离降低{fmt(oracle['sum_distance_reduction_vs_sav_pct'])}%。这是三次真实执行后的最好输出，不是最优值，也不是免费选择策略。",'','资源与解释边界：','- 384次×250ms=96秒名义搜索wall上限；实际CPU单列，非等同。单进程唯一RLIMIT_CPU=180秒，涵盖初始化、生成、冻结、建模、搜索、校验、拟合、统计与打包；没有双监督器或重试。源码编写/阅读不属于实验进程CPU。','- 原特征仅容量/总需求、需求CV、平均窗宽/时域、平均服务/时域；固定容量/K/服务/时域不代表所有原特征都变化，服务特征常数且缩放退回1。空间特征仅四个预定统计，详见协议。没有以family、文件名、测试成本、失败指标或hash作为特征。ID只按原协议用于近邻并列破除。','- 特征联合抽取（8项）成本单列，是四特征主方法的保守上界；训练成本与测试推荐成本分开。选中配置CPU引用各自实际请求，推荐器没有在求解失败后换策略。此处评价阶段为诊断执行三配置，不声称部署时免费获得三次搜索。','- 所有128问题的已知可行见证在求解前独立重放通过；窗口围绕角度分区+最近邻构造路线生成，带明显构造偏置。见证没有作为warm start送入求解器。任何TIMEOUT/UNKNOWN/未返回解都不能说成数学无解。','- 所有返回解按原始连续坐标独立核查覆盖、容量、服务开始窗、服务时长、返仓；并以50位Decimal独立重算整数目标。距离单目标，K=10，容量100，服务2，时域2000，所有单位均为合成任意单位。','- 40训练/24测试按几何隔离，两窗始终同组；这是新数据上的前瞻封存测试，但只对本合成分布有效。64不是64个真实农田，不能称农业泛化或SOTA。','- 单次短wall截断会受负载影响，不宣称确定复现数值；没有重复运行估计求解器时间噪声。几何bootstrap是描述区间，质量区间条件于成功，不代替全48失败覆盖报告，也不做多方法挑赢家。','- 零模型/API调用、零新安装、零Codex任务、零新购买；旧实验与旧输入不改动。当前不上传。完整合成输入可再分发，干净ZIP含所有原始结果和失败。','', '推荐额外CPU：']
    for m,o in overhead.items():lines +=[f"{m}:训练{o['training_cpu_s']:.9f}s，48测试预测{o['prediction_cpu_s']:.9f}s。"]
    fc=read('evidence/feature_extraction.json');lines +=[f"联合8特征：训练80问题{sum(fc[n]['cpu_s'] for n in models['primary_1nn4']['train_instances']):.9f}s，测试48问题{sum(fc[n]['cpu_s'] for n in [p['instance'] for p in preds]):.9f}s。"]
    (P/'reports/report_zh.txt').write_text('\n'.join(lines)+'\n')
    return summary

def verify(train,test,preds,models):
    freeze=read('protocol/freeze.json');changed=[n for n,h in freeze['sha256'].items() if sha(P/n)!=h];assert not changed,changed
    old=read('protocol/source_provenance.json');assert all(sha(Path(r['path']))==r['sha256'] for r in old)
    seal=read('evidence/prediction_seal.json');assert sha(P/'raw/test_predictions_sealed.json')==seal['prediction_sha256'];assert sha(P/'raw/training_models.json')==seal['model_sha256'];assert sha(P/'raw/train_results.jsonl')==seal['train_results_sha256']
    events=[json.loads(l) for l in (P/'raw/events.jsonl').read_text().splitlines()];starts=[e for e in events if e['event']=='request_started'];pe=next(e for e in events if e['event']=='predictions_sealed');first_test=next(e for e in starts if e['phase']=='test')
    assert len(train)==240 and len(test)==144 and len(starts)==384
    assert pe['utc']<first_test['utc'] and pe['monotonic_ns']<first_test['monotonic_ns'];assert seal['sealed_utc']<first_test['utc']
    assert len({r['run_id'] for r in train+test})==384
    for model in models.values():assert not set(model['train_instances']) & {p['instance'] for p in preds}
    original=[d for d in read('inputs/instances.json')];regenerated,_=generator.generate();assert digest(original)==digest(regenerated)
    rechecked=0
    for r in train+test:
        if r['assignment_returned']:
            copy=dict(r);a=check_result({'id':r['instance']},copy);assert good(copy)==good(r);rechecked+=1
    ev={'verified_utc':utc(),'frozen_files_unchanged':not changed,'old_source_files_unchanged':True,'regenerated_synthetic_inputs_identical':True,'requests_unique':384,'train_requests':240,'test_requests':144,'all128_witnesses_valid':True,'returned_assignments_replayed':rechecked,'checker_rejections':sum(r['outcome']=='FAIL_CHECKER' for r in train+test),'prediction_seal_utc':seal['sealed_utc'],'first_test_request_utc':first_test['utc'],'prediction_seal_before_test':True,'source_freeze_before_first_request':events[0]['monotonic_ns']<starts[0]['monotonic_ns'],'test_costs_absent_when_fitting':True,'no_failed_retries_or_fallback':True,'failure_count':sum(not good(r) for r in train+test),'model_and_prediction_hashes_unchanged':True}
    write('evidence/verification.json',ev);return ev

def package(summary):
    resources={'utc':utc(),'whole_process_cpu_s_before_packaging':time.process_time(),'wall_s_before_packaging':time.perf_counter()-START,'single_hard_cpu_limit_s':180,'maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'nominal_solver_wall_caps_s':96,'actual_solver_cpu_s':sum(s['solve_cpu_s'] for s in summary['config_stats']),'actual_model_cpu_s':sum(s['model_cpu_s'] for s in summary['config_stats']),'actual_checker_cpu_s':sum(s['check_cpu_s'] for s in summary['config_stats']),'actual_all_requests_cpu_s':sum(s['request_cpu_s'] for s in summary['config_stats']),'experiment_includes':['imports','generation','feature extraction','freeze','384 requests','independent checks','model fit','test prediction','analysis','verification','packaging'],'excludes_from_this_process_measurement':['source authoring and read-only human/agent inspection'],'model_api_calls':0,'new_installations':0,'codex_tasks':0,'new_purchases':0,'uploaded':False}
    write('evidence/resource_accounting.json',resources)
    with (P/'reports/report_zh.txt').open('a') as f:f.write(f"\n实验进程打包前CPU={resources['whole_process_cpu_s_before_packaging']:.6f}s，wall={resources['wall_s_before_packaging']:.6f}s；实际搜索CPU={resources['actual_solver_cpu_s']:.6f}s。包括打包后的最终CPU与ZIP校验见同目录外的_package_receipt.json。\n")
    (P/'README_zh.txt').write_text('新合成64几何前瞻选择器实验。先读reports/report_zh.txt与reports/summary.json。\n完整合成输入在inputs/；protocol/freeze.json冻结源码、参数、输入和协议；evidence/prediction_seal.json证明48预测早于测试启动。\nraw/train_results.jsonl为240训练请求，raw/test_results.jsonl为144测试请求，失败不删。raw/events.jsonl保留顺序与双时间戳。\nsource/study.py为单进程180CPU秒硬限运行器。运行前先复制source和protocol/prior_selector_protocol.json到新空目录；不可覆盖本次冻结实验；环境依赖见source/requirements.lock，已有ORtools9.14.6206。源码provenance要求原来源路径存在才能重现，未提供旧私有数据。\n合成数据可再分发，非真实农业数据。没有模型/API、购买、安装、Codex或上传。固定wall预算有运行时噪声。ZIP不含环境、缓存、凭证、旧原始输入。\n')
    event('study_verified_complete',requests=384)
    files=[p for p in sorted(P.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc' and p.name not in ['stdout.log','stderr.log','shell_time.txt']]
    assert all('.venv' not in p.parts and p.suffix not in ['.pem','.key'] for p in files)
    sums=''.join(sha(p)+'  '+str(p.relative_to(P))+'\n' for p in files);(P/'SHA256SUMS.txt').write_text(sums);files.append(P/'SHA256SUMS.txt')
    archive=P.parent/(P.name+'.zip')
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in files:z.write(p,str(p.relative_to(P)))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for line in sums.splitlines():h,n=line.split('  ',1);assert hashlib.sha256(z.read(n)).hexdigest()==h
    receipt={'finished_utc':utc(),'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'file_count':len(files),'whole_process_cpu_s_including_packaging':time.process_time(),'wall_s_since_study_setup_after_imports':time.perf_counter()-START,'hard_cpu_limit_s':180,'crc_and_all_inner_hashes_verified':True,'uploaded':False,'note':'CPU sampled after archive creation/full CRC/hash verification;interpreter teardown adds a tiny unmeasured tail. bash builtin time receipt supplementary and includes interpreter import/setup wall time.'}
    (P.parent/(P.name+'_package_receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');(P.parent/(P.name+'.zip.sha256')).write_text(receipt['sha256']+'  '+archive.name+'\n')
    print(json.dumps(receipt),flush=True)

if __name__=='__main__':
    ds,features,split,requests=prepare();train=execute('train',requests,ds);preds,models,overhead=fit_and_seal(train,features,split);test=execute('test',requests,ds);summary=analyze(train,test,preds,models,overhead,ds);verify(train,test,preds,models);package(summary)
