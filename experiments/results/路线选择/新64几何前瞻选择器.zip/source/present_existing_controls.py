"""Postrun reporting supplement, written after results solely to expose the protocol's
already-planned fixed SAV and training-only SBS controls side-by-side. No model fitting,
prediction changes, solver imports/calls, resampling of instances, or protocol changes.
"""
import resource
resource.setrlimit(resource.RLIMIT_CPU,(8,8))
import json,statistics,random,hashlib,csv,time
from pathlib import Path
from datetime import datetime,timezone
P=Path(__file__).resolve().parent.parent
START=time.process_time()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,v):(P/n).write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def mean(x):return statistics.mean(x) if x else None
def csvwrite(n,rs):
    with (P/n).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rs[0]));w.writeheader();w.writerows(rs)
def compare(rows,m,b):
    co=[r for r in rows if r[m+'_valid'] and r[b+'_valid']];a=sum(r[m+'_distance'] for r in co);s=sum(r[b+'_distance'] for r in co)
    return {'method':m,'baseline':b,'n_all':len(rows),'method_successes':sum(r[m+'_valid'] for r in rows),'baseline_successes':sum(r[b+'_valid'] for r in rows),'common_success_n':len(co),'method_only_success':sum(r[m+'_valid'] and not r[b+'_valid'] for r in rows),'baseline_only_success':sum(not r[m+'_valid'] and r[b+'_valid'] for r in rows),'both_failed':sum(not r[m+'_valid'] and not r[b+'_valid'] for r in rows),'wins':sum(r[m+'_distance']<r[b+'_distance']-1e-6 for r in co),'ties':sum(abs(r[m+'_distance']-r[b+'_distance'])<=1e-6 for r in co),'losses':sum(r[m+'_distance']>r[b+'_distance']+1e-6 for r in co),'mean_relative_method_vs_baseline_pct':mean([100*(r[m+'_distance']/r[b+'_distance']-1) for r in co]),'sum_distance_reduction_vs_baseline_pct':100*(1-a/s) if s else None,'method_common_distance_sum':a,'baseline_common_distance_sum':s}
def bootstrap(gs):
    rng=random.Random(202610071902);q=[];c=[];means=[g['mean_relative_method_vs_baseline_pct'] for g in gs]
    cover=[100*(g['method_successes']-g['baseline_successes'])/g['n_all'] for g in gs]
    for _ in range(5000):
        ix=[rng.randrange(24) for j in range(24)];vs=[means[i] for i in ix if means[i] is not None]
        if vs:q.append(mean(vs))
        c.append(mean([cover[i] for i in ix]))
    def ci(xs):
        xs.sort();return [xs[int(.025*(len(xs)-1))],xs[int(.975*(len(xs)-1))]] if xs else None
    usable=[v for v in means if v is not None]
    return {'geometry_units':24,'usable_common_success_geometry_units':len(usable),'equal_geometry_mean_relative_pct':mean(usable),'conditional_quality_percentile95_pct':ci(q),'mean_coverage_difference_percentage_points':mean(cover),'coverage_difference_percentile95_percentage_points':ci(c),'replicates':5000,'seed':202610071902,'scope':'Same predeclared geometry bootstrap rule;descriptive,conditional on common-success subsets,not significance/winner proof.'}

rows=json.loads((P/'reports/test_all48.json').read_text());summary=json.loads((P/'reports/summary.json').read_text());frozen=json.loads((P/'protocol/freeze.json').read_text());seal=json.loads((P/'evidence/prediction_seal.json').read_text())
assert sha(P/'raw/test_predictions_sealed.json')==seal['prediction_sha256'] and sha(P/'raw/training_models.json')==seal['model_sha256']
assert all(sha(P/n)==h for n,h in frozen['sha256'].items() if n!='evidence/shell_time.txt')
comparisons=[];pergeo=[];perfamily=[]
for m in ['primary_1nn4','spatial_1nn8']:
    for b in ['fixed_sav250','training_sbs']:
        gs=[]
        for g in sorted({r['geometry_id'] for r in rows}):
            subset=[r for r in rows if r['geometry_id']==g];st={'geometry_id':g,'family':subset[0]['family'],**compare(subset,m,b)};gs.append(st);pergeo.append(st)
        st=compare(rows,m,b);st['geometry_bootstrap']=bootstrap(gs);comparisons.append(st)
        for f in sorted({r['family'] for r in rows}):perfamily.append({'family':f,'geometry_count':6,**compare([r for r in rows if r['family']==f],m,b)})
        for r in rows:
            r[m+'_vs_'+b+'_common_success']=r[m+'_valid'] and r[b+'_valid']
            r[m+'_vs_'+b+'_relative_pct']=100*(r[m+'_distance']/r[b+'_distance']-1) if r[m+'_valid'] and r[b+'_valid'] else None
summary['two_control_interpretation']={'fixed_sav250':'Old-domain strong fixed method,chosen before current data. Evaluates transfer of that fixed baseline.','training_sbs':'Single fixed method chosen only from80 new training problems under original coverage-first SBS rule;PCI250. Evaluates whether per-instance selection adds to new-domain fixed-method choice.','reporting_note':'Direct comparisons against both already-planned controls added after outcomes solely for complete presentation;original protocol,model,features,predictions and384 outcomes unchanged.'}
summary['direct_two_control_comparisons']=comparisons
write('reports/summary_with_both_controls.json',summary);write('reports/test_all48_with_both_controls.json',rows);csvwrite('reports/test_all48_with_both_controls.csv',rows);write('reports/per_geometry_both_controls.json',pergeo);csvwrite('reports/per_geometry_both_controls.csv',pergeo);write('reports/per_family_both_controls.json',perfamily)
flat=[{k:v for k,v in s.items() if k!='geometry_bootstrap'} for s in comparisons];csvwrite('reports/primary_two_control_table.csv',flat)
lines=['主摘要补充：必须同时看旧域固定SAV与新训练SBS','', '固定SAV是旧研究预先选定配置，反映旧域固定方法的迁移；训练SBS仅由本轮80训练问题选出PCI250，反映新数据上只挑一种固定方法。这两种对照回答不同问题。测试数据没有用于选SBS。','']
for s in comparisons:
    q=s['geometry_bootstrap']
    lines.append(f"{s['method']} 对 {s['baseline']}:成功{s['method_successes']}/48 对 {s['baseline_successes']}/48；共同成功{s['common_success_n']}/48；胜/平/负{s['wins']}/{s['ties']}/{s['losses']}；方法独有/基线独有成功{s['method_only_success']}/{s['baseline_only_success']}；平均相对距离差{s['mean_relative_method_vs_baseline_pct']:.6f}%（负为较短）；共同成功总距离降低{s['sum_distance_reduction_vs_baseline_pct']:.6f}%。")
    lines.append(f"  24几何等权平均相对距离差{q['equal_geometry_mean_relative_pct']:.6f}%，描述性95%bootstrap区间{q['conditional_quality_percentile95_pct']}，可用几何{q['usable_common_success_geometry_units']}/24；覆盖差{q['mean_coverage_difference_percentage_points']:.6f}个百分点。")
lines+=['','结论：原四特征1-NN虽在成功子集距离较短，但成功45/48，低于固定SAV46/48与训练SBS48/48，不能声称整体改善。预定空间消融48/48，对训练SBS同为48/48，观察到全48问题较短的距离；这是合成分布单次短预算下的积极描述结果，仍须结合几何区间和生成偏置，不能称已证实的泛化或SOTA。','', '计时精度说明：原主方法training_cpu_s与prediction_cpu_s采样均为0，但训练wall=0.001319238秒，48次预测wall合计0.002841153秒。短操作CPU采样存在计量粒度/量化限制，0不表示零开销，也不能据此做精细CPU加速结论；保留原始采样不改。','', '归档说明：冻结时误把运行结束才会填写的空shell_time.txt纳入，最终退出时该文件变化。冻结本身保留；仅此运行回执例外，科学输入/源码/参数/分割/模型/预测均不变。详见evidence/archive_erratum.json。','', '以下保留原始报告正文：','']
original=(P/'reports/report_zh.txt').read_text();(P/'reports/report_with_both_controls_zh.txt').write_text('\n'.join(lines)+original)
receipt=json.loads((P.parent/(P.name+'_package_receipt.json')).read_text());shell=P/'evidence/shell_time.txt';(P/'evidence/final_shell_time.txt').write_bytes(shell.read_bytes())
erratum={'written_utc':datetime.now(timezone.utc).isoformat(),'kind':'Archival bookkeeping exception,not scientific rerun','frozen_entry':'evidence/shell_time.txt','original_empty_sha256':frozen['sha256']['evidence/shell_time.txt'],'final_sha256':sha(shell),'explanation':'Shell redirects timing output before launching process,creating an empty file which prepare() mistakenly included in freeze. Bash writes real/user/sys only after process exit. In-process verification was true at its timestamp;final all-frozen-files-unchanged assertion requires this one explicit exception. Original ZIP deliberately omitted shell_time.txt as a changing runtime log.','original_freeze_unchanged_sha256':sha(P/'protocol/freeze.json'),'final_receipt_in_new_archive':'evidence/final_shell_time.txt','original_path_retained_outside_archive':str(shell),'scientific_frozen_files_unchanged':True,'original_archive_sha256':receipt['sha256'],'scientific_model_and_prediction_hashes_unchanged':True,'no_solves_rerun':True,'full_bash_timing':{'real_s':101.922,'user_s':99.093,'system_s':2.767,'total_cpu_s':101.860},'in_process_cpu_sample_including_packaging_s':receipt['whole_process_cpu_s_including_packaging'],'measurement_note':'Bash full processCPU includes exit/teardown;sample was taken after packaging/verification but before process exit. Additional postrun reporting/packagingCPU recorded separately.'}
write('evidence/archive_erratum.json',erratum)
write('evidence/original_package_receipt.json',receipt)
write('evidence/two_control_reporting_receipt.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_sha256':sha(Path(__file__)),'cpu_s':time.process_time()-START,'process_cpu_sample_s':time.process_time(),'hard_cpu_limit_s':8,'solver_calls':0,'original_protocol_unchanged':True,'model_prediction_unchanged':True,'purpose':'Full side-by-side presentation of already-planned controls,not method selection/tuning.'})
print(json.dumps({'comparisons':comparisons,'reporting_cpu_s':time.process_time()-START},ensure_ascii=False))
