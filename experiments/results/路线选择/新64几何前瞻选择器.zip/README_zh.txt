新合成64几何前瞻选择器实验。先读reports/report_zh.txt与reports/summary.json。
完整合成输入在inputs/；protocol/freeze.json冻结源码、参数、输入和协议；evidence/prediction_seal.json证明48预测早于测试启动。
raw/train_results.jsonl为240训练请求，raw/test_results.jsonl为144测试请求，失败不删。raw/events.jsonl保留顺序与双时间戳。
source/study.py为单进程180CPU秒硬限运行器。运行前先复制source和protocol/prior_selector_protocol.json到新空目录；不可覆盖本次冻结实验；环境依赖见source/requirements.lock，已有ORtools9.14.6206。源码provenance要求原来源路径存在才能重现，未提供旧私有数据。
合成数据可再分发，非真实农业数据。没有模型/API、购买、安装、Codex或上传。固定wall预算有运行时噪声。ZIP不含环境、缓存、凭证、旧原始输入。
