"""Package already-finished artifacts only; no author/audit mutation or solver import."""
import resource
resource.setrlimit(resource.RLIMIT_CPU, (20, 20))
import json, hashlib, time, zipfile
from pathlib import Path
from datetime import datetime, timezone

START = time.perf_counter()
HERE = Path(__file__).resolve().parent
BASE = HERE.parent
AUTHOR = BASE/'selector_budgeted_recovery_20261007'
AUDIT = BASE/'selector_budgeted_recovery_audit_20261007'
ORIGINAL = BASE/'selector_budgeted_recovery_20261007.zip'
FINAL = BASE/'selector_budgeted_recovery_20261007_FINAL.zip'
EXPECTED = '0836266d63ca7fc7842b22e380dc65170cfbf5703ef070660f0d31b0ee8433bb'

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,v): (HERE/name).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def snapshot(directory):
    return {str(p.relative_to(directory)):sha(p) for p in sorted(directory.rglob('*')) if p.is_file()}

assert not FINAL.exists(), 'Do not silently replace a delivered archive'
assert sha(ORIGINAL)==EXPECTED
author_before=snapshot(AUTHOR);audit_before=snapshot(AUDIT)
audit=json.loads((AUDIT/'audit_result.json').read_text())
assert audit['all_checks_passed'] and len(audit['checks'])==39

readme='''冻结选择器计费失败恢复实验：最终交付包

结果摘要
- 48个全新独立几何，每个两种时间窗，共96问题；统计单元为48个几何。
- 选择器250ms首阶段成功81/96，15次计费PCI250后备救回14例，最终95/96。
- 固定PCI500同为95/96，且同在s009_w020失败；固定SAV500为73/96。
- 对PCI的95个共同成功问题，选择器逐问题平均距离更长1.089614%；48几何等权更长1.133860%。不是全面胜出，也不是覆盖超过PCI。
- 选择器含特征/预测实际CPU27.607745秒，固定PCI48.604296秒。相同的是每策略名义最坏搜索上限500ms；实际搜索、CPU及端到端时间不相同。成功后停止，剩余预算不强行用满。
- 完整实验进程CPU116.833秒、wall116.892秒，实验硬CPU上限180秒；独立审计完整CPU1.322秒、wall1.324秒，另计。外层打包CPU也单列，见delivery_receipt.json和packaging_shell_time.txt，不冒充实验用时。

独立复审39项通过：源训练成员/缩放/标签、96预测、坐标及种子不重叠、96可行witness、263成功返回、覆盖率、条件距离、几何簇区间和CPU账均一致。原实验目录和原ZIP未改。

解释边界
这是一批有witness构造偏置的合成shift；几何和时间窗同时变化，单次wall截止运行。无解返回不代表数学不可行。32个原始ROUTING_FAIL被旧封装写成UNKNOWN，另8个TIMEOUT，40个实际求解失败完整保留。未重跑历史r101，不能说该具体旧失败已修复。条件距离均明确分母，不能掩盖失败。没有SOTA、显著性或普适泛化结论。

包内结构
1. original_experiment/selector_budgeted_recovery_20261007.zip：经过审计的原ZIP原字节，SHA256保持0836266d63ca7fc7842b22e380dc65170cfbf5703ef070660f0d31b0ee8433bb。
2. final_experiment_receipts/：原实验进程退出后完成的shell_time.txt、stdout.log、stderr.log，补齐原ZIP缺少的三份最终记录。
3. independent_audit/：独立复审报告、JSON、哈希证据、完整审计CPU记录、日志和审计源码。
4. manifest.json：每个交付条目的字节数与SHA256；完整性清单不自我包含。
5. packaging/package_final.py、packaging/resources_before_archive.json：外层打包的可追溯源码与计量范围。打包结束后的精确CPU/完整ZIP SHA256和CRC结果是外部sidecar，避免自引用。

只打包相关源码、数据、结果与审计资料，无缓存、密钥或无关文件；没有求解器调用、API调用、上传或公开发布。
'''
(HERE/'README_zh.txt').write_text(readme)

items=[('README_zh.txt',HERE/'README_zh.txt'),('original_experiment/'+ORIGINAL.name,ORIGINAL)]
for rel,arc in [('evidence/shell_time.txt','shell_time.txt'),('raw/stdout.log','stdout.log'),('raw/stderr.log','stderr.log')]:
    items.append(('final_experiment_receipts/'+arc,AUTHOR/rel))
for name in ['audit_report_zh.txt','audit_result.json','audit_evidence_hashes.json','audit_shell_time.txt','audit_stdout.log','audit_stderr.log','audit.py']:
    items.append(('independent_audit/'+name,AUDIT/name))
items.append(('packaging/package_final.py',Path(__file__).resolve()))
write('resources_before_archive.json',{'created_utc':datetime.now(timezone.utc).isoformat(),'process_cpu_s_before_archive':time.process_time(),'wall_s_before_archive':time.perf_counter()-START,'hard_packaging_cpu_limit_s':20,'resource_scope':'Separate administrative packaging only;not experiment or independent audit CPU. Full process receipt is packaging_shell_time.txt sidecar. No solver run or model import.','author_full_cpu_s':116.833,'author_full_wall_s':116.892,'independent_audit_full_cpu_s':1.322,'independent_audit_full_wall_s':1.324})
items.append(('packaging/resources_before_archive.json',HERE/'resources_before_archive.json'))
manifest={'created_utc':datetime.now(timezone.utc).isoformat(),'purpose':'Immutable experiment ZIP plus final receipts and independent audit','original_zip_sha256':EXPECTED,'original_zip_preserved_as_raw_bytes':True,'geometry_n':48,'problem_n':96,'experiment_coverage':{'fixed_pci500':95,'fixed_sav500':73,'selector250_pci250':95},'same_failed_problem_pci_and_selector':'s009_w020','selector_vs_pci_common_success_n':95,'selector_vs_pci_mean_problem_distance_delta_pct':1.0896142296354596,'budget_claim':'same nominal worst500ms search,not same actual CPU or end-to-end wall','independent_audit_checks_passed':39,'files':[{'archive_path':arc,'bytes':p.stat().st_size,'sha256':sha(p)} for arc,p in items],'exclusions':['caches','credentials','unrelated files'],'manifest_self_excluded':True}
write('manifest.json',manifest)
with zipfile.ZipFile(FINAL,'x') as z:
    for arc,p in items:
        z.write(p,arc,compress_type=zipfile.ZIP_STORED if p==ORIGINAL else zipfile.ZIP_DEFLATED)
    z.write(HERE/'manifest.json','manifest.json',compress_type=zipfile.ZIP_DEFLATED)
with zipfile.ZipFile(FINAL) as z:
    assert z.testzip() is None
    for f in manifest['files']:
        data=z.read(f['archive_path'])
        assert len(data)==f['bytes'] and hashlib.sha256(data).hexdigest()==f['sha256']
    assert hashlib.sha256(z.read('original_experiment/'+ORIGINAL.name)).hexdigest()==EXPECTED
    count=len(z.infolist())
assert sha(ORIGINAL)==EXPECTED
assert snapshot(AUTHOR)==author_before
assert snapshot(AUDIT)==audit_before
receipt={'created_utc':datetime.now(timezone.utc).isoformat(),'final_zip':str(FINAL),'final_zip_sha256':sha(FINAL),'final_zip_bytes':FINAL.stat().st_size,'final_zip_entries':count,'crc_passed':True,'every_manifest_entry_verified':True,'original_zip_sha256':sha(ORIGINAL),'original_zip_preserved':True,'author_directory_unchanged':True,'audit_directory_unchanged':True,'packaging_cpu_s_before_receipt_write':time.process_time(),'packaging_wall_s_before_receipt_write':time.perf_counter()-START,'resource_scope':'Outer packaging only,separate from experiment116.833CPU seconds and independent audit1.322CPU seconds. Full startup+serialization captured by packaging_shell_time.txt sidecar.','solver_calls':0,'uploaded':False}
write('delivery_receipt.json',receipt)
print(json.dumps(receipt,ensure_ascii=False),flush=True)
