"""Read-only independent audit. Standard library only; never imports author code or OR-Tools."""
import ast, collections, hashlib, json, math, random, re, resource, statistics, time, zipfile
from pathlib import Path
from decimal import Decimal, localcontext, ROUND_HALF_UP, ROUND_CEILING
from datetime import datetime, timezone

START_CPU, START_WALL = time.process_time(), time.perf_counter()
P = Path('/workspace/shared/selector_budgeted_recovery_20261007')
OLD = Path('/workspace/shared/diverse_geometry_selection_20261007')
OUT = Path('/workspace/shared/selector_budgeted_recovery_audit_20261007')
CHECKS, DETAILS = [], {}

def read(p): return json.loads(p.read_text())
def lines(p): return [json.loads(s) for s in p.read_text().splitlines()]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def digest(x): return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def check(name, ok, details=None):
    CHECKS.append({'check':name,'passed':bool(ok)})
    if details is not None: CHECKS[-1]['details']=details
    if not ok: raise AssertionError(name+': '+str(details))
def close(x,y): return math.isclose(x,y,rel_tol=1e-12,abs_tol=1e-9)

baseline_hashes={str(p.relative_to(P)):sha(p) for p in P.rglob('*') if p.is_file()}
freeze=read(P/'protocol/freeze.json')
check('128 frozen files unchanged',len(freeze['sha256'])==128 and all(sha(P/f)==h for f,h in freeze['sha256'].items()))
manifest_lines=(P/'SHA256SUMS.txt').read_text().splitlines()
check('final SHA256SUMS content matches',all(sha(P/s.split('  ',1)[1])==s.split('  ',1)[0] for s in manifest_lines),len(manifest_lines))
check('author-provided freeze hash',sha(P/'protocol/freeze.json')=='218239fce2c6b4540045f834d3453db6002d7157b04ba0a594a039fb580bd31d')
zip_path=P.with_suffix('.zip')
with zipfile.ZipFile(zip_path) as z:
    zip_bad=z.testzip();zip_names=z.namelist()
    zip_mismatches=[n for n in zip_names if hashlib.sha256(z.read(n)).hexdigest()!=sha(P.parent/n)]
check('archive CRC and included files match final directory',zip_bad is None and not zip_mismatches)
check('author-provided ZIP hash',sha(zip_path)=='0836266d63ca7fc7842b22e380dc65170cfbf5703ef070660f0d31b0ee8433bb')
DETAILS['package']={'directory_file_count':len(baseline_hashes),'manifest_entry_count':len(manifest_lines),'archive_entry_count':len(zip_names),'archive_bytes':zip_path.stat().st_size,'archive_sha256':sha(zip_path),'missing_from_zip':sorted(f for f in baseline_hashes if str(P.name+'/'+f) not in zip_names),'not_in_SHA256SUMS':sorted(set(baseline_hashes)-{s.split('  ',1)[1] for s in manifest_lines}-{'SHA256SUMS.txt'})}

ds=read(P/'inputs/instances.json'); by_id={d['id']:d for d in ds}
geoms=read(P/'protocol/geometries.json');old_geoms=read(OLD/'protocol/geometries.json');old_ds=read(OLD/'inputs/instances.json')
pred=read(P/'protocol/predictions_sealed.json'); feats=read(P/'protocol/features.json')
requests=read(P/'protocol/requests.json');schedule=read(P/'protocol/policy_schedule.json')
results=lines(P/'raw/results.jsonl');ri={r['run_id']:r for r in results}
policies=lines(P/'raw/policy_results.jsonl');pl={(r['instance'],r['policy']):r for r in policies}
events=lines(P/'raw/events.jsonl'); summary=read(P/'reports/summary.json');overhead=read(P/'evidence/feature_prediction_overhead.json')
all96=read(P/'reports/all96.json');model=read(P/'protocol/source_training_models.json')['spatial_1nn8']
check('96 unique inputs and 48 paired geometry units',len(ds)==len(by_id)==96 and len(geoms)==48 and len({g['geometry_id'] for g in geoms})==48)
grouped=collections.defaultdict(list)
for d in ds: grouped[d['geometry_id']].append(d)
check('two related windows per geometry',all(sorted(d['width'] for d in g)==[20,80] for g in grouped.values()))
check('four new families with 12 geometries each',collections.Counter(g['family'] for g in geoms)=={'radial_ring':12,'corner_clusters':12,'offcenter_uniform':12,'oblique_corridor':12})
coords=lambda d: digest(sorted([[n['x'],n['y']] for n in d['nodes'][1:]]))
old_coords={coords(d) for d in old_ds};new_coords={coords(d) for d in ds}
check('old64 and new48 coordinate sets disjoint',len(old_coords)==64 and len(new_coords)==48 and not old_coords&new_coords)
check('old and new geometry hashes and seeds disjoint',not {g['seed'] for g in geoms}&{g['seed'] for g in old_geoms} and not {g['geometry_sha256'] for g in geoms}&{g['geometry_sha256'] for g in old_geoms})
check('new seeds exactly frozen arithmetic sequence', [g['seed'] for g in geoms]==[202610073700+1013*i for i in range(48)])

# Parse each original text independently, comparing all semantics to JSON input.
parsed={}
for d in ds:
    txt=(P/'inputs'/f"{d['id']}.txt").read_text().splitlines()
    vi=txt.index('VEHICLE');fleet,cap=map(int,txt[vi+2].split())
    nodes={}
    for s in txt:
        t=s.split()
        if len(t)==7 and all(re.fullmatch(r'-?\d+',x) for x in t):
            n,*v=map(int,t);assert n not in nodes;nodes[n]=v
    assert sorted(nodes)==list(range(101))
    assert fleet==d['vehicles']==10 and cap==d['capacity']==100
    assert [nodes[n['id']] for n in d['nodes']]==[[n[k] for k in ['x','y','demand','ready','due','service']] for n in d['nodes']]
    parsed[d['id']]={'fleet':fleet,'capacity':cap,'nodes':nodes}
check('all original text inputs match JSON fields',True)

# Independently regenerate only coordinates and demands; no solver, candidates or outcome filtering.
for g in geoms:
    rng=random.Random(g['seed']);fam=g['family']
    if fam=='radial_ring':
        xy=[]
        for _ in range(100):
            theta=rng.uniform(-math.pi,math.pi);radius=rng.uniform(40,70)
            xy.append((round(radius*math.cos(theta)),round(radius*math.sin(theta))))
        depot=(0,0)
    elif fam=='corner_clusters':
        centers=[(-60,-60),(-60,60),(60,-60),(60,60)]
        xy=[(round(centers[i%4][0]+rng.gauss(0,4)),round(centers[i%4][1]+rng.gauss(0,4))) for i in range(100)]
        rng.shuffle(xy);depot=(0,0)
    elif fam=='offcenter_uniform':
        xy=[(rng.randrange(0,101),rng.randrange(0,101)) for _ in range(100)];depot=(-25,-25)
    else:
        xs=[rng.randrange(-150,151) for _ in range(100)]
        xy=[(x,round(.45*x+rng.uniform(-10,10))) for x in xs];depot=(0,0)
    demand=[rng.randint(1,10) for _ in range(100)]
    expected_hash=digest({'depot':list(depot),'customers':sorted([list(z) for z in xy])})
    assert expected_hash==g['geometry_sha256']
    for d in grouped[g['geometry_id']]:
        assert [(n['x'],n['y']) for n in d['nodes'][1:]]==xy
        assert [n['demand'] for n in d['nodes'][1:]]==demand
        assert (d['nodes'][0]['x'],d['nodes'][0]['y'])==depot
check('all 48 geometry seeds reproduce inputs without rejection',True)

source_map={'protocol/source_training_models.json':'raw/training_models.json','protocol/source_protocol.json':'protocol/protocol.json','protocol/source_geometries.json':'protocol/geometries.json','evidence/source_prediction_seal.json':'evidence/prediction_seal.json','source/source_generator.py':'source/generator.py',**{f'source/{n}':f'source/{n}' for n in ['core.py','checker.py','selector.py','requirements.lock']}}
check('model, archived provenance and reused source byte-identical',all(sha(P/a)==sha(OLD/b) for a,b in source_map.items()))
old_seal=read(OLD/'evidence/prediction_seal.json')
check('model hash matches archived pre-test model seal',sha(P/'protocol/source_training_models.json')==old_seal['model_sha256'])
check('nine provenance source hashes match',all(sha(Path(r['path']))==r['sha256'] for r in read(P/'evidence/source_provenance.json')))
old_by_id={d['id']:d for d in old_ds};train_ids=sorted(d['id'] for d in old_ds if d['split']=='train')
check('model training membership only original40 training geometries',model['train_instances']==train_ids and len(train_ids)==80 and len({old_by_id[n]['geometry_id'] for n in train_ids})==40)
tree=ast.parse((P/'source/study.py').read_text())
fitcalls=[n for n in ast.walk(tree) if isinstance(n,ast.Call) and ((isinstance(n.func,ast.Attribute) and n.func.attr=='fit') or (isinstance(n.func,ast.Name) and n.func.id=='fit'))]
check('prospective source has no fit call',not fitcalls)

def feature_calc(d):
    ns=d['nodes'][1:];n=len(ns);demand=[a['demand'] for a in ns];h=d['nodes'][0]['due']-d['nodes'][0]['ready']
    cx=statistics.mean(a['x'] for a in ns);cy=statistics.mean(a['y'] for a in ns)
    xx=statistics.mean((a['x']-cx)**2 for a in ns);yy=statistics.mean((a['y']-cy)**2 for a in ns);xy=statistics.mean((a['x']-cx)*(a['y']-cy) for a in ns)
    tr=xx+yy;r=math.sqrt(tr);nn=[min(math.dist((a['x'],a['y']),(b['x'],b['y'])) for b in ns if a['id']!=b['id']) for a in ns]
    return dict(zip(model['features'],[d['capacity']/sum(demand),statistics.pstdev(demand)/statistics.mean(demand),statistics.mean(a['due']-a['ready'] for a in ns)/h,statistics.mean(a['service'] for a in ns)/h,r/h,statistics.mean(nn)/r if r else 0,(tr+math.sqrt((xx-yy)**2+4*xy*xy))/(2*tr) if tr else .5,math.dist((cx,cy),(d['nodes'][0]['x'],d['nodes'][0]['y']))/r if r else 0]))

train_features={n:feature_calc(old_by_id[n]) for n in train_ids}
for f in model['features']:
    vals=[train_features[n][f] for n in train_ids]
    assert close(statistics.mean(vals),model['feature_means'][f])
    assert close(statistics.pstdev(vals),model['feature_population_stds'][f])
    assert close(statistics.pstdev(vals) or 1.0,model['feature_scales'][f])
for n,v in model['vectors'].items():
    assert all(close(z,(train_features[n][f]-model['feature_means'][f])/model['feature_scales'][f]) for z,f in zip(v,model['features']))
check('archived eight-feature scaling and vectors match old training inputs',True)

# Verify labels from the original training-only results, without calling fit.
trpath=OLD/'raw/train_results.jsonl';training_results=lines(trpath)
check('archived training-result bytes match old seal',sha(trpath)==old_seal['train_results_sha256'])
train_r={(r['instance'],r['config_id']):r for r in training_results}
configs=['pci250','pca250','sav250']
assert set(train_r)=={(n,c) for n in train_ids for c in configs}
def oldgood(r): return r['outcome']=='SUCCESS'
coverage={c:sum(oldgood(train_r[n,c]) for n in train_ids) for c in configs}
assert coverage==model['coverage']
assert max(coverage.values())==coverage[model['sbs']] and sum(x==max(coverage.values()) for x in coverage.values())==1
for n in train_ids:
    good=[c for c in configs if oldgood(train_r[n,c])]
    best=min(train_r[n,c]['check_summary']['distance'] for c in good)
    tied=[c for c in good if train_r[n,c]['check_summary']['distance']<=best+1e-6]
    assert model['labels'][n]==min(tied,key=lambda c:(c!=model['sbs'],configs.index(c)))
check('frozen labels and SBS match 240 original training results',True)
for d in ds:
    f=feature_calc(d);n=d['id'];assert all(close(f[k],feats[n][k]) for k in model['features'])
    v=[(f[k]-model['feature_means'][k])/model['feature_scales'][k] for k in model['features']]
    d2={k:sum((a-b)**2 for a,b in zip(v,z)) for k,z in model['vectors'].items()}
    nearest=min(d2.values());tied=sorted(k for k,x in d2.items() if x<=nearest+1e-12)
    neighbor=min(tied,key=lambda k:(model['labels'][k]!=model['sbs'],k));p=pred[n]
    assert p['neighbor']==neighbor and p['selected_config']==model['labels'][neighbor]
    assert p['neighbor_tie_instances']==tied and p['neighbor_tie_count']==len(tied) and close(p['neighbor_squared_distance'],d2[neighbor])
check('all 96 features and frozen 1NN predictions independently reproduce',True)

check('one sequential complete event stream', [e['event_sequence'] for e in events]==list(range(len(events))) and all(a['monotonic_ns']<b['monotonic_ns'] for a,b in zip(events,events[1:])))
seal=events[0];starts=[e for e in events if e['event']=='request_started'];ends=[e for e in events if e['event']=='request_finished'];skips=[e for e in events if e['event']=='fallback_skipped']
check('freeze and all prediction hashes precede target execution',seal['event']=='frozen_before_first_target' and seal['freeze_sha256']==sha(P/'protocol/freeze.json') and seal['prediction_sha256']==sha(P/'protocol/predictions_sealed.json') and datetime.fromisoformat(freeze['frozen_utc'])<datetime.fromisoformat(seal['utc'])<min(datetime.fromisoformat(e['utc']) for e in starts))
check('384 requests uniquely accounted; 303 calls and 81 skips',len(requests)==len(results)==len(ri)==384 and len(starts)==len(ends)==303 and len(skips)==81 and set(ri)=={r['run_id'] for r in requests})
check('no repeated target request in logged starts',len({e['run_id'] for e in starts})==303 and {e['run_id'] for e in starts}=={e['run_id'] for e in ends})
open_run=None
for e in events:
    if e['event']=='request_started': assert open_run is None;open_run=e['run_id'];assert ri[open_run]['start_event']==e
    if e['event']=='request_finished': assert e['run_id']==open_run;open_run=None;assert e['outcome']==ri[e['run_id']]['outcome']
assert open_run is None
for req in requests:
    assert all(ri[req['run_id']][k]==v for k,v in req.items())
check('serialized fresh calls match sealed requests and paired event boundaries',True)
DETAILS['freeze_timing']={'freeze_utc':freeze['frozen_utc'],'seal_event_utc':seal['utc'],'first_target_utc':starts[0]['utc'],'seal_to_first_target_ms':(starts[0]['monotonic_ns']-seal['monotonic_ns'])/1e6,'last_target_finished_utc':ends[-1]['utc'],'limitation':'Self-recorded hashes/events plus frozen source establish internal chronology, not external trusted timestamping or proof against undisclosed historical runs.'}

# New standalone continuous checker. Never trusts reported distances, matrices or schedules.
leg_cache={}
def leg(a,b):
    sq=(a[0]-b[0])**2+(a[1]-b[1])**2
    if sq not in leg_cache:
        with localcontext() as c:
            c.prec=60;z=Decimal(sq).sqrt()*1000000
            leg_cache[sq]=(math.sqrt(sq),int(z.to_integral_value(rounding=ROUND_HALF_UP)),int(z.to_integral_value(rounding=ROUND_CEILING)))
    return leg_cache[sq]
def replay(d,entries):
    nodes=d['nodes'];visits=[];legs=[];objective=0;min_slack=math.inf;return_max=0;arcs=0
    assert isinstance(entries,list) and len(entries)<=d['fleet']
    for entry in entries:
        route=entry['nodes'] if isinstance(entry,dict) else entry
        assert len(route)>=3 and route[0]==route[-1]==0 and 0 not in route[1:-1]
        assert all(type(k)==int and k in nodes for k in route)
        visits.extend(route[1:-1]);assert sum(nodes[k][2] for k in route[1:-1])<=d['capacity']
        t=0.;enc_t=0
        for a,b in zip(route,route[1:]):
            distance,cost,travel=leg(nodes[a],nodes[b]);legs.append(distance);objective+=cost;arcs+=1
            t=max(nodes[b][3],t+nodes[a][5]+distance)
            enc_t=max(nodes[b][3]*1000000,enc_t+nodes[a][5]*1000000+travel)
            assert t<=nodes[b][4]+1e-9 and enc_t<=nodes[b][4]*1000000
            min_slack=min(min_slack,nodes[b][4]-t)
        return_max=max(return_max,t)
    assert collections.Counter(visits)==collections.Counter(range(1,101))
    distance=math.fsum(legs);assert abs(objective/1e6-distance)<.5*arcs/1e6+1e-9
    return {'distance':distance,'objective_integer':objective,'arcs':arcs,'routes':len(entries),'min_window_slack':min_slack,'max_return':return_max}

witness_replays={d['id']:replay(parsed[d['id']],d['witness_routes']) for d in ds}
check('96 witnesses independently feasible continuously and in conservative encoded time',len(witness_replays)==96)
for d in ds:
    nd=parsed[d['id']]['nodes']
    for route in d['witness_routes']:
        t=0.
        for a,b in zip(route,route[1:]):
            t+=nd[a][5]+math.dist(nd[a][:2],nd[b][:2])
            if b:
                assert nd[b][3]==max(0,math.floor(t)-d['width']//2) and nd[b][4]==nd[b][3]+d['width']
check('time windows directly constructed around witness no-wait visits',True)
route_replays={}
for r in results:
    if r['assignment_returned']:
        x=replay(parsed[r['instance']],r['routes']);route_replays[r['run_id']]=x
        assert r['outcome']=='SUCCESS' and close(x['distance'],r['check_summary']['distance']) and x['objective_integer']==r['objective_integer']
    else: assert r['outcome']!='SUCCESS' and r['routes'] is None
check('all 263 successful assignment sets independently valid and objective-exact',len(route_replays)==263)
continuous=lines(P/'raw/continuous_checks.jsonl')
check('263 author checker records match independent replay',len(continuous)==263 and all(r['valid'] and close(r['distance'],route_replays[r['run_id']]['distance']) for r in continuous))
DETAILS['route_validation']={'witness_sets':96,'successful_assignment_sets':len(route_replays),'actual_nonempty_routes':sum(x['routes'] for x in route_replays.values()),'served_customer_visits':26300,'minimum_success_window_slack':min(x['min_window_slack'] for x in route_replays.values()),'maximum_success_return_time':max(x['max_return'] for x in route_replays.values()),'integer_objective_mismatches':0,'continuous_invalid':0,'encoded_time_invalid':0,'witness_minimum_window_slack':min(x['min_window_slack'] for x in witness_replays.values())}

methods=['fixed_pci500','fixed_sav500','selector250_pci250']
check('288 complete policies match sealed schedule',len(policies)==len(pl)==288 and all(all(p[k]==s[k] for k in s) for p,s in zip(policies,schedule)))
rows=[];policy_resources={}
for d in sorted(ds,key=lambda x:x['id']):
    n=d['id'];row={'instance':n,'geometry_id':d['geometry_id'],'family':d['family'],'width':d['width']}
    for m in methods:
        p=pl[n,m];executed=[rid for rid in p['run_ids'] if ri[rid]['outcome']!='SKIPPED_FIRST_SUCCESS']
        assert executed==p['executed_run_ids']
        total_ms=sum(ri[rid]['budget_ms'] for rid in executed)
        assert total_ms==p['nominal_search_ms_executed']<=500
        last=ri[executed[-1]];assert last['run_id']==p['returned_run_id'] and p['valid']==(last['outcome']=='SUCCESS')
        row[m+'_valid']=p['valid'];row[m+'_distance']=route_replays[last['run_id']]['distance'] if p['valid'] else None
        assert (close(p['distance'],row[m+'_distance']) if p['valid'] else p['distance'] is None)
        if m=='selector250_pci250':
            first,fallback=[ri[k] for k in p['run_ids']]
            assert first['config_id']==pred[n]['selected_config'] and first['budget_ms']==250 and fallback['config_id']=='pci250' and fallback['budget_ms']==250
            assert (fallback['outcome']=='SKIPPED_FIRST_SUCCESS')==(first['outcome']=='SUCCESS')
            assert p['fallback_executed']==(first['outcome']!='SUCCESS')
            row['first_stage_valid']=first['outcome']=='SUCCESS';row['fallback_executed']=p['fallback_executed']
    rows.append(row)
check('fallback trigger exact and final selection has no free or quality-triggered retry',True)
for x,y in zip(rows,all96):
    assert all(close(v,y[k]) if isinstance(v,float) else v==y[k] for k,v in x.items())
check('all96 author report agrees with independently replayed outcomes',True)
for m in methods:
    ps=[p for p in policies if p['policy']==m];rr=[ri[k] for p in ps for k in p['executed_run_ids']]
    suc=sum(x[m+'_valid'] for x in rows);reported=summary['methods'][m]
    assert suc==reported['successes'] and reported['total']==96 and reported['failures']==96-suc
    both=sum(all(x[m+'_valid'] for x in rows if x['geometry_id']==g) for g in grouped)
    assert both==reported['both_window_success_geometries']
    policy_cpu=sum(p['policy_execution_cpu_s'] for p in ps);req_cpu=sum(r['request_cpu_s'] for r in rr)
    assert all(p['policy_execution_cpu_s']+1e-9>=sum(ri[k]['request_cpu_s'] for k in p['executed_run_ids']) for p in ps)
    assert close(policy_cpu,reported['execution_cpu_s'])
    policy_resources[m]={'successes':suc,'failures':96-suc,'denominator':96,'both_windows_success_geometry_n':both,'executed_solver_calls':len(rr),'executed_nominal_search_s':sum(r['budget_ms'] for r in rr)/1000,'policy_cpu_s':policy_cpu,'request_cpu_s_nested_within_policy':req_cpu,'policy_wall_s':sum(p['policy_execution_wall_s'] for p in ps),'end_to_end_over_500ms_n':sum(p['policy_execution_wall_s']>.5 for p in ps),'failed_instances':[x['instance'] for x in rows if not x[m+'_valid']]}
check('all-policy failure denominators and nonoverlapping resource layers verified',True)
first=sum(x['first_stage_valid'] for x in rows);fallbacks=sum(x['fallback_executed'] for x in rows);rescued=sum(not x['first_stage_valid'] and x['selector250_pci250_valid'] for x in rows)
check('first81 fallback15 rescued14',first==81 and fallbacks==15 and rescued==14)

def compare(a,b):
    common=[r for r in rows if r[a+'_valid'] and r[b+'_valid']]
    grp=collections.defaultdict(list)
    for r in rows:grp[r['geometry_id']].append(r)
    cov=[statistics.mean(int(r[a+'_valid'])-int(r[b+'_valid']) for r in gr)*100 for gr in grp.values()]
    qual=[statistics.mean(100*(r[a+'_distance']/r[b+'_distance']-1) for r in gr if r[a+'_valid'] and r[b+'_valid']) for gr in grp.values() if any(r[a+'_valid'] and r[b+'_valid'] for r in gr)]
    rng=random.Random(202610073702)
    pct=lambda xs:[sorted(xs)[int(.025*(len(xs)-1))],sorted(xs)[int(.975*(len(xs)-1))]]
    cov_ci=pct([sum(cov[rng.randrange(len(cov))] for _ in cov)/len(cov) for _ in range(5000)])
    q_ci=pct([sum(qual[rng.randrange(len(qual))] for _ in qual)/len(qual) for _ in range(5000)])
    return {'common_success_n':len(common),'common_success_geometry_n':len(qual),'mean_problem_relative_delta_pct':statistics.mean(100*(r[a+'_distance']/r[b+'_distance']-1) for r in common),'mean_geometry_relative_delta_pct':statistics.mean(qual),'ratio_of_distance_sums_delta_pct':100*(sum(r[a+'_distance'] for r in common)/sum(r[b+'_distance'] for r in common)-1),'coverage_delta_pp':statistics.mean(cov),'wins':sum(r[a+'_distance']<r[b+'_distance']-1e-6 for r in common),'ties':sum(abs(r[a+'_distance']-r[b+'_distance'])<=1e-6 for r in common),'losses':sum(r[a+'_distance']>r[b+'_distance']+1e-6 for r in common),'coverage_geometry_bootstrap95_pp':cov_ci,'conditional_quality_geometry_bootstrap95_pct':q_ci}
comparisons={}
for a,b in [('selector250_pci250','fixed_pci500'),('selector250_pci250','fixed_sav500'),('fixed_pci500','fixed_sav500')]:
    key=a+'_vs_'+b;v=compare(a,b);comparisons[key]=v
    for k,x in v.items():
        y=summary['comparisons'][key][k]
        assert all(close(xx,yy) for xx,yy in zip(x,y)) if isinstance(x,list) else close(x,y)
check('coverage, conditional distance and all geometry-cluster bootstrap intervals independently reproduce',True)

executed=[r for r in results if r['outcome']!='SKIPPED_FIRST_SUCCESS'];resource_report=read(P/'evidence/run_resources.json')
for r in executed:
    assert close(r['request_cpu_s'],r['total_cpu_s']+r['check_cpu_s'])
    assert r['total_cpu_s']+1e-9>=r['model_cpu_s']+r['solve_cpu_s']
for report_key,row_key in [('search_cpu_s','solve_cpu_s'),('model_cpu_s','model_cpu_s'),('checker_cpu_s','check_cpu_s')]:
    assert close(resource_report[report_key],sum(r[row_key] for r in executed))
feature_cpu=sum(v['feature']['cpu_s'] for v in overhead.values());prediction_cpu=sum(v['prediction']['cpu_s'] for v in overhead.values())
selector_cpu=policy_resources['selector250_pci250']['policy_cpu_s']+feature_cpu+prediction_cpu
assert close(selector_cpu,summary['methods']['selector250_pci250']['execution_plus_feature_prediction_cpu_s'])
shell={k:float(v) for k,v in re.findall(r'(\w+)=([\d.]+)',(P/'evidence/shell_time.txt').read_text())}
shell_cpu=shell['user_s']+shell['sys_s'];all_policy_cpu=sum(p['policy_execution_cpu_s'] for p in policies)
assert shell_cpu<180 and shell_cpu>=resource_report['process_cpu_s_before_report_zip']>=all_policy_cpu+feature_cpu+prediction_cpu
DETAILS['resources']={'main_complete_shell_cpu_s':shell_cpu,'main_complete_shell_wall_s':shell['wall_s'],'hard_main_cpu_limit_s':180,'sum_nonoverlapping_policy_execution_cpu_s':all_policy_cpu,'feature_cpu_s':feature_cpu,'prediction_cpu_s':prediction_cpu,'selector_cpu_with_feature_prediction_s':selector_cpu,'selector_cpu_reduction_relative_to_pci_pct':100*(1-selector_cpu/policy_resources['fixed_pci500']['policy_cpu_s']),'remaining_main_cpu_including_preparation_analysis_and_packaging_s':shell_cpu-all_policy_cpu-feature_cpu-prediction_cpu,'nested_search_cpu_s':resource_report['search_cpu_s'],'nested_model_cpu_s':resource_report['model_cpu_s'],'nested_checker_cpu_s':resource_report['checker_cpu_s'],'accounting_note':'Policy execution includes solver/model/checker, extraction and event/I/O overhead. Do not add nested search/model/checker again. All policy CPU plus features/prediction is part of complete main CPU. Source authoring and external audit excluded from 180 seconds.'}
check('full main CPU and selector-feature accounting verified without double-counting',True)

failure_counter=collections.Counter((r.get('ortools_status_name'),r['outcome']) for r in results)
DETAILS['failure_statuses']=[{'ortools_status_name':k[0],'wrapper_outcome':k[1],'count':v} for k,v in failure_counter.items()]
DETAILS['policies']=policy_resources;DETAILS['comparisons']=comparisons
DETAILS['stage_diagnostics']={'first_success':first,'first_failures':96-first,'fallback_calls':fallbacks,'rescued':rescued,'final_success':first+rescued,'remaining_failure':'s009_w020'}
DETAILS['source_integrity']={'frozen_sha256_count':128,'model_sha256':sha(P/'protocol/source_training_models.json'),'source_training_result_sha256':sha(trpath),'recomputed_training_only_labels':80,'recomputed_predictions':96,'prediction_counts':dict(collections.Counter(v['selected_config'] for v in pred.values()))}
check('author directory unchanged throughout this audit',baseline_hashes=={str(p.relative_to(P)):sha(p) for p in P.rglob('*') if p.is_file()})

warnings=[
    '合成分布shift同时改变几何、仓库布局和时间窗；48个PRNG几何为统计单元，96个问题不是96个独立样本。四家族各12个几何，不代表真实业务分布。',
    '可行witness未交给solver，但窗围绕角度排序/容量分块/块内最近邻witness构造，保留这种可行性与构造偏置。无返回不等于数学不可行。',
    '相同的是每策略名义最坏搜索上限500ms。选择器81次首段成功立即停止，实际预算与CPU不等，也不是严格端到端500ms。',
    '覆盖95/96与固定PCI500相同且失败实例相同；95共同成功上选择器距离更差、耗时较低，是质量与资源权衡，不能称全面胜出或覆盖更好。',
    '几何簇bootstrap只描述此批构造样本的条件质量，不作显著性、SOTA或普适泛化宣称；单次wall截止求解有主机/时序噪声。',
    '32次原始ROUTING_FAIL被旧wrapper写成UNKNOWN；8次ROUTING_FAIL_TIMEOUT写成TIMEOUT。原始状态完整保留，40次均按失败计入。应在呈现层注明，勿把UNKNOWN说成状态缺失或已证不可行。',
    '现有ZIP及其SHA256SUMS未收录最终evidence/shell_time.txt、raw/stdout.log、raw/stderr.log。目录有三者，交付时需补附或在独立外层交付包中保留；勿改动被审计原包。',
    '冻结时间顺序由封存源码、哈希和自记日志支持；不是外部公证时间，也不能独立排除未披露历史运行。首次launcher失败发生在Python启动前，现有记录不构成target重试。',
    '本次没有重跑历史r101，也不能宣称具体历史失败已修复。未重跑任何solver/候选，未访问P2 heldout、API、上传或安装软件。'
]
result={'audit_id':'INDEPENDENT_SELECTOR_RECOVERY_20261007','created_utc':datetime.now(timezone.utc).isoformat(),'verdict':'PASS_WITH_LIMITATIONS','scope':'Read-only source and artifact audit; independently recomputed features/predictions, original-training provenance, geometry generation/nonoverlap, continuous/encoded feasibility, integer objectives, coverage/quality/bootstrap and CPU accounting; no solver execution.','all_checks_passed':True,'checks':CHECKS,'details':DETAILS,'warnings_zh':warnings,'audit_resources':{'process_cpu_s_before_report_serialization':time.process_time()-START_CPU,'wall_s_before_report_serialization':time.perf_counter()-START_WALL,'process_peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'separate_from_author_main_process':True,'note':'Final audit shell receipt includes Python startup and final serialization. Prior manual read-only tool inspections are outside this measured audit-script CPU, and are not charged to the author experiment.'}}
(OUT/'audit_result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
(OUT/'audit_evidence_hashes.json').write_text(json.dumps(baseline_hashes,ensure_ascii=False,indent=2)+'\n')
q=comparisons['selector250_pci250_vs_fixed_pci500']
report=f'''独立只读复审：冻结选择器计费失败恢复实验
结论：通过（有明确范围限制），未发现改变数值结论的计账或可行性错误。

1. 复核{len(CHECKS)}项全部通过；128封存文件哈希、最终清单、ZIP CRC与包内字节一致。模型与旧实验字节一致；80训练问题/40几何的成员、缩放、向量和标签均从原训练源核对；96新特征与1NN预测独立重算一致。代码无fit调用。
2. 冻结{freeze['frozen_utc']}，首目标{starts[0]['utc']}。303个唯一请求开始/结束事件、81条件跳过，合计384潜在请求；288策略结果齐全，序列未见重跑/免费补救。全部输入、预测、请求、顺序、参数在目标前封存。此为可追溯内部时间证据，非外部公证。
3. 48个新几何，每族12、每几何20/80两窗；种子重新生成坐标/需求一致，与旧64种子、客户坐标和几何hash均不重叠。96可行witness以及263份成功返回（{DETAILS['route_validation']['actual_nonempty_routes']}条非空路线）全部通过本审计独立连续/保守编码时间检查、全服务/容量/回仓检查和60位Decimal整数目标校验。
4. 覆盖：PCI500 95/96，SAV500 73/96，selector250→失败PCI250 95/96。首段81/96，15次计费后备救回14；最终同PCI一起失败s009_w020。40次实际求解失败全保留，32 ROUTING_FAIL被旧封装标UNKNOWN、8 TIMEOUT，均计失败。
5. 与PCI的95个共同成功问题上，选择器逐问题平均距离差+{q['mean_problem_relative_delta_pct']:.6f}%；48几何等权+{q['mean_geometry_relative_delta_pct']:.6f}%，描述性95%簇bootstrap[{q['conditional_quality_geometry_bootstrap95_pct'][0]:.6f}%, {q['conditional_quality_geometry_bootstrap95_pct'][1]:.6f}%]，胜/平/负26/16/53。独立复算与报告一致。
6. 完整main外壳CPU={shell_cpu:.3f}s<180s，wall={shell['wall_s']:.3f}s。selector含特征/预测CPU={selector_cpu:.6f}s，PCI={policy_resources['fixed_pci500']['policy_cpu_s']:.6f}s，selector低约{DETAILS['resources']['selector_cpu_reduction_relative_to_pci_pct']:.2f}%。这是同名义最坏搜索上限、实际预算不等的比较；policy已经包含search/model/checker，不能再相加。审计CPU单列，不混入180s。

必须随结论保留：这是有witness构造偏置的合成shift，一次运行，几何与窗同时改变；选择器覆盖未超过PCI，平均路程更差而资源更低，不能称总胜出，不能声称修复历史r101。条件距离不掩盖失败，CI仅描述本批样本。

交付提醒：作者现有ZIP少最终shell_time/stdout/stderr三份文件；最终目录三者齐全。应补附三者或装入独立交付外层包，保留原作者ZIP不变。
禁止动作均未执行：未跑solver或候选、未改作者目录、未读P2 heldout、未发API、未安装、未上传。

详细机器可读检查：audit_result.json；作者目录起止一致哈希：audit_evidence_hashes.json；审计完整进程CPU另见audit_shell_time.txt。
'''
(OUT/'audit_report_zh.txt').write_text(report)
print(json.dumps({'checks_passed':len(CHECKS),'verdict':result['verdict'],'audit_cpu_s':time.process_time()-START_CPU,'audit_wall_s':time.perf_counter()-START_WALL,'report':str(OUT/'audit_report_zh.txt'),'json':str(OUT/'audit_result.json')},ensure_ascii=False))
