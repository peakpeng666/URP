"""Verify locally supplied authorized original files. No download, copy or mutation."""
import json,hashlib,sys
from pathlib import Path
p=Path(__file__).resolve().parent.parent;source=Path(sys.argv[1]);bad=[]
for m in json.loads((p/'protocol/input_manifest.json').read_text()):
 f=source/m['name']
 if not f.is_file() or hashlib.sha256(f.read_bytes()).hexdigest()!=m['sha256']:bad.append(m['name'])
if bad:raise SystemExit('Missing or hash-mismatched files: '+', '.join(bad))
print('56/56 exact archived input hashes verified. No files modified.')
