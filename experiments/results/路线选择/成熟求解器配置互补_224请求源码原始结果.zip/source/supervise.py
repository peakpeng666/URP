"""Launch bounded complete study and write a clean package. No network."""
import resource
resource.setrlimit(resource.RLIMIT_CPU,(5,169))
import sys,subprocess,time,json,hashlib,zipfile
from pathlib import Path
from datetime import datetime,timezone
P=Path(__file__).resolve().parent.parent
cpu0=time.process_time();wall0=time.perf_counter();before=resource.getrusage(resource.RUSAGE_CHILDREN)
with (P/'raw/stdout.log').open('x') as out,(P/'raw/stderr.log').open('x') as err:
 child=subprocess.Popen([sys.argv[1],str(P/'source/study.py')],stdout=out,stderr=err)
 resource.setrlimit(resource.RLIMIT_CPU,(5,5))
 try:code=child.wait(timeout=600)
 except subprocess.TimeoutExpired:child.kill();code=child.wait()
after=resource.getrusage(resource.RUSAGE_CHILDREN)
child_cpu=(after.ru_utime+after.ru_stime)-(before.ru_utime+before.ru_stime)
res={'finished_utc':datetime.now(timezone.utc).isoformat(),'exit_code':code,'child_cpu_s':child_cpu,'child_user_s':after.ru_utime-before.ru_utime,'child_system_s':after.ru_stime-before.ru_stime,'supervisor_cpu_before_packaging_s':time.process_time(),'wall_s':time.perf_counter()-wall0,'child_maxrss_kib':after.ru_maxrss,'hard_cpu_limits_s':{'child':169,'supervisor_including_packaging':5,'reserved_independent_verification':5},'sum_hard_cpu_limits_s':179,'prior_preflight_actual_cpu_s':0.044444159000000004,'child_scope':'Interpreter/imports,preparation,freeze,224fresh modelbuilds/searches/extractions,continuous andinteger replay,analysis,reporting.','supervisor_scope':'Child launch,waiting,resource accounting,archive generation and verification.','paid_model_api_calls':0,'new_purchases':0,'new_software_installations':0,'codex_tasks':0,'billing_scope':'No paid API or new purchase,not a claim that platform infrastructure is free.','measurement_scope':'LocalprocessCPU;external serviceCPU unavailable. Searchbudgets are wall caps.'}
(P/'evidence/resource_accounting.json').write_text(json.dumps(res,indent=2)+'\n')
if code!=0:
 print(json.dumps(res));raise SystemExit('Child failed;flushedraw records preserved.No automaticrerun.')
with (P/'reports/report_zh.txt').open('a') as f:f.write(f"\n实际资源：实验主进程CPU {child_cpu:.6f}s（含初始化、准备、模型、搜索、校验和分析），监督进程打包前CPU {time.process_time():.6f}s；详见evidence/resource_accounting.json。\n")
# Delivery allows only generated artifacts and metadata, never raw source data or environments.
files=[x for x in sorted(P.rglob('*')) if x.is_file() and x.relative_to(P).parts[0] in {'source','protocol','raw','reports','evidence','README_zh.txt'} and '__pycache__' not in x.parts and x.suffix not in {'.pyc'}]
for x in files:
 assert '.venv' not in x.parts and 'inputs' not in x.relative_to(P).parts
 assert x.suffix not in ['.pem','.key']
sums=''.join(hashlib.sha256(x.read_bytes()).hexdigest()+'  '+str(x.relative_to(P))+'\n' for x in files)
(P/'SHA256SUMS.txt').write_text(sums);files.append(P/'SHA256SUMS.txt')
archive=P.parent/(P.name+'.zip')
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for x in files:z.write(x,str(x.relative_to(P)))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for line in sums.splitlines():
  digest,name=line.split('  ',1);assert hashlib.sha256(z.read(name)).hexdigest()==digest
receipt={'archive':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'file_count':len(files),'child_cpu_s':child_cpu,'supervisor_cpu_including_packaging_s':time.process_time(),'total_measured_cpu_s':child_cpu+time.process_time()+0.044444159000000004,'prior_preflight_cpu_s':0.044444159000000004,'total_wall_s':time.perf_counter()-wall0,'archive_crc_and_all_inner_hashes_verified':True,'excluded':['original input instance files','venv','caches','credentials'],'uploaded':False}
(P.parent/(P.name+'.zip.sha256')).write_text(receipt['sha256']+'  '+archive.name+'\n')
(P.parent/(P.name+'_package_receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
