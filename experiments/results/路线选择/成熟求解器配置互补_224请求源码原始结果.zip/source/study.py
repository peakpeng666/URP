"""Frozen 56-instance, 224-call headroom study. No training and no external API."""
import os
os.environ['OMP_NUM_THREADS']='1'
import resource
# The complete child, including imports, preparation, all solves and replay, has this cap.
resource.setrlimit(resource.RLIMIT_CPU,(169,169))
import sys,json,time,math,hashlib,platform,statistics,traceback,csv,collections,zipfile
from pathlib import Path
from datetime import datetime,timezone
from decimal import Decimal,localcontext,ROUND_HALF_UP,ROUND_CEILING
import core,checker
from ortools.constraint_solver import pywrapcp,routing_enums_pb2
from google.protobuf import text_format
P=Path(__file__).resolve().parent.parent
INPUT=Path(os.environ.get('VRPTW_INPUT_DIR','/workspace/shared/public_vrptw_benchmark_20261007/inputs'))
SCALE=core.SCALE
CONFIGS=[
 {'config_id':'pci250','strategy':'PARALLEL_CHEAPEST_INSERTION','budget_ms':250,'role':'fixed_primary_short'},
 {'config_id':'pca250','strategy':'PATH_CHEAPEST_ARC','budget_ms':250,'role':'portfolio_alternative'},
 {'config_id':'sav250','strategy':'SAVINGS','budget_ms':250,'role':'portfolio_alternative'},
 {'config_id':'pci750','strategy':'PARALLEL_CHEAPEST_INSERTION','budget_ms':750,'role':'fixed_primary_long_reference'}]
SHORT=[c['config_id'] for c in CONFIGS[:3]]
TOL=1e-6
START=time.perf_counter()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def digest(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def write(name,data):
 (P/name).write_text(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def mean(xs):return statistics.mean(xs) if xs else None
def csvwrite(name,rows):
 if not rows:return
 with (P/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def groups(rows,key):
 d=collections.defaultdict(list)
 for r in rows:d[r[key]].append(r['instance'])
 return [{'sha256':k,'instances':v,'n':len(v)} for k,v in sorted(d.items())]

def prepare():
 assert not (P/'protocol/freeze.json').exists(),'Frozen study already exists; do not overwrite or rerun silently.'
 assert core.importlib.metadata.version('ortools')=='9.14.6206'
 manifest=json.loads((P/'protocol/input_manifest.json').read_text());assert len(manifest)==56
 names=sorted(r['name'] for r in manifest)
 expected=sorted(f'{f}{t}{i:02}.txt' for f,t,n in [('c',1,9),('c',2,8),('r',1,12),('r',2,11),('rc',1,8),('rc',2,8)] for i in range(1,n+1))
 assert names==expected
 by={r['name']:r for r in manifest};features=[];identity=[]
 for name in names:
  path=INPUT/name;r=by[name];assert sha(path)==r['sha256'],name
  d=core.parse(path);assert digest(d)==r['semantic_sha256'],name
  cost,travel=core.encode(d)
  assert digest({'cost_nearest':cost,'travel_ceil':travel,'service_exact':[x['service']*SCALE for x in d['nodes']]})==r['encoded_sha256'],name
  nodes=d['nodes'];customers=nodes[1:];xs=[n['x'] for n in customers];ys=[n['y'] for n in customers];cx=mean(xs);cy=mean(ys)
  wid=[n['due']-n['ready'] for n in customers]
  geom=digest({'depot':[nodes[0]['x'],nodes[0]['y']],'customers':sorted([n['x'],n['y']] for n in customers)})
  gd=digest({'depot':[nodes[0]['x'],nodes[0]['y']],'customers':sorted([n['x'],n['y'],n['demand']] for n in customers)})
  gds=digest({'depot':[nodes[0]['x'],nodes[0]['y']],'customers':sorted([n['x'],n['y'],n['demand'],n['service']] for n in customers)})
  f={'instance':d['id'],'family':d['family'],'n_customers':100,'capacity':d['capacity'],'vehicle_limit':d['vehicles'],'depot_due':nodes[0]['due'],'timewindow_width_mean':mean(wid),'timewindow_width_min':min(wid),'timewindow_width_max':max(wid),'coordinate_x_range':max(xs)-min(xs),'coordinate_y_range':max(ys)-min(ys),'coordinate_rms_radius':math.sqrt(mean([(n['x']-cx)**2+(n['y']-cy)**2 for n in customers])),'total_demand':sum(n['demand'] for n in customers),'geometry_sha256':geom,'geometry_demand_sha256':gd,'geometry_demand_service_sha256':gds,'ordered_geometry_sha256':digest([[n['id'],n['x'],n['y']] for n in nodes])}
  features.append(f);identity.append({'instance':d['id'],'input_sha256':sha(path),'mtime_ns':path.stat().st_mtime_ns,'size':path.stat().st_size})
 write('protocol/instance_features.json',features);csvwrite('reports/instance_features.csv',features)
 write('protocol/shared_geometry.json',{key:groups(features,key) for key in ['geometry_sha256','geometry_demand_sha256','geometry_demand_service_sha256','ordered_geometry_sha256']})
 write('evidence/input_identity_before.json',identity)
 requests=[]
 for i,name in enumerate(names):
  order=CONFIGS[i%4:]+CONFIGS[:i%4]
  for c in order:requests.append({**c,'instance':name[:-4],'family':by[name]['family'],'sequence':len(requests),'run_id':name[:-4]+'__'+c['config_id'],'seed':core.SEED})
 assert len(requests)==224 and sum(r['budget_ms'] for r in requests)==84000
 write('protocol/requests.json',requests)
 for c in CONFIGS:
  p=core.params(c['budget_ms'],c['strategy'])
  assert not pywrapcp.FindErrorInRoutingSearchParameters(p)
  (P/f"protocol/parameters_{c['config_id']}.textproto").write_text(str(p))
 base=core.params(250,CONFIGS[0]['strategy'])
 for c in CONFIGS[1:3]:
  p=core.params(250,c['strategy']);p.first_solution_strategy=base.first_solution_strategy;assert p==base
 p=core.params(750,CONFIGS[0]['strategy']);p.time_limit.FromMilliseconds(250);assert p==base
 write('evidence/api_semantics.json',{'ortools_version':core.importlib.metadata.version('ortools'),'official_docs_url':'https://developers.google.com/optimization/routing/routing_options','official_docs_checked_utc':'2026-10-07T06:59:09Z','official_api_url':'https://or-tools.github.io/docs/python/classortools_1_1constraint__solver_1_1pywrapcp_1_1Solver.html','api_page_version':'9.15; version-specific details cross-checked using installed9.14.6206 descriptors/docstrings','strategies':{c['strategy']:getattr(routing_enums_pb2.FirstSolutionStrategy,c['strategy']) for c in CONFIGS[:3]},'parameter_validation':'FindErrorInRoutingSearchParameters returned empty for all4 configurations','only_first_solution_strategy_differs_between_short_configs':True,'only_time_limit_differs_between_primary_short_and_long':True,'routing_search_seed_fields':[f.name for f in base.DESCRIPTOR.fields if 'seed' in f.name],'cp_seed_api':'routing.solver().ReSeed(2026100708)','cp_seed_doc':pywrapcp.Solver.ReSeed.__doc__,'seed_caveat':'ReSeed initializes CP random generator; these construction/GLS choices need not consume it. No assertion of statistically distinct seeded runs. CP-SAT is disabled, so sat_parameters.random_seed is inactive. Wall limits can change outputs even with identical configuration and seed.','total_nominal_search_s':84,'pilot_solver_calls':0,'estimated_cpu_s':'about90-110s including preflight,224 model builds,search,replay,analysis; bound169s child plus5s supervisor plus5s optional independent verification=180s','scope':'fixed controls and no adaptive configuration choice; not bitwise deterministic outcomes'})
 protocol={
  'study_id':'SOLVER_PORTFOLIO_HEADROOM_ARCHIVED100_V1','question':'Does a small mature-solver configuration portfolio have conditional complementarity worth investigating before any future learned selector?',
  'dataset':'All56 preexisting user-archived100-customer files pinned by raw,parsed andencoded SHA256. No new heldout set. Official source identity unverified; no outcome-based filtering.',
  'fresh_comparison':'Every one of224 requests is newly executed, including primary250ms. No prior results imported, no failed-case-only retries, no pilot solves or tuning on these outputs.',
  'configs':CONFIGS,'shared_search':'GUIDED_LOCAL_SEARCH lambda0.1; CP enabled; CP-SAT/generalized CP-SAT/fallback disabled;same CP ReSeed2026100708;full parameter snapshots committed before first solve.',
  'model':'All100 customers mandatory. Minimize only nearest-integer-scaled arc distance.Original vehicle limit andcapacity.No drop penalties,no AddDisjunction,no fixed vehicle cost,no vehicle-count lexicographic objective.No warm starts.',
  'semantics':'Continuous Euclidean distance=travel time;inclusive service-start windows,waiting allowed,origin service time on each arc,depot start0/depot return by due.Demand and capacity integral.',
  'encoding':{'scale':SCALE,'cost':'Nearest integer Euclidean*S, ties upward, exact isqrt/midpoint comparison. Absolute cost error per arc<=0.5/S.','travel':'Ceil Euclidean*S plus exact origin service*S; conservative excess<1/S per arc.','bounds':'Total nonempty-route arcs100+vehicles_used<=100+K; total objective error<=0.5*(100+K)/S. One route excess<101/S=0.000101; could exclude continuous boundary-feasible routes. No original infeasibility claims.','validation':'Independent continuous replay tolerance1e-9. Independently recompute objective with50-digit Decimal sqrt andROUND_HALF_UP; verify total original-float rounding bound.'},
  'order':'Alphabetical instance names;cyclic4-config order rotated by instance index modulo4,14 occurrences of eachposition perconfig.Fresh models,serial execution.No outcome-dependent reruns.',
  'budgets':'3*250ms alternatives plus PCI750ms perinstance;224 requests84s nominalsearch. Search cap iswall clock,not CPU. Child hardRLIMIT_CPU169s includes imports/preparation/build/search/replay/analysis;supervisor including packaging5s;optional independent verification5s.Total180CPU seconds. SIGKILL preserves already-flushed records;missing remainNOT_RUN_BUDGET.',
  'failures':'Returned solution succeeds only after independent feasibility/objective checks.FAIL for exception/invalid/checkerfailure.TIMEOUT for explicit no-solution timeout.UNKNOWN for othernoassignment.Not finding a solution isnotproof of continuous infeasibility.No failure excluded fromdenominators.',
  'SBS':'Posthoc choose among the3 shortconfigs:maximize valid-count,then minimize mean ratio toVBS on the commonvalid instance intersection of maximumcoverage candidates,tie bypredeclared configorder.No arbitrary penalty assigned tofailure.TheSBS is an in-sample descriptive choice.',
  'VBS':'Perinstance minimum independent continuous distance among validshort outputs, ties tolerance1e-6.VBS is an oraclewithin these3 observed outputs,not an optimal-route boundor anunseen-data guarantee.Gap=(SBS/VBS-1)*100 onbothvalid;also report(SBS-VBS)/SBS reductionandrescuedfailures.',
  'executed_portfolio':'All3 short configs wereactuallyrun;best-of3 selection uses validoutputs and theirchecked continuous distances. Output equals observed VBS. Charge summedactual build/search/extract/check CPU ofall3 plus measuredselectionCPU;no cost-free oracle claim.',
  'long_comparison':'Compare best-of3 tofixed PCI750 on the same56instances. Equal nominal750mssearch only;3 setups andchecks versus1,failures may terminateearly;reportactualCPUandwall.No strictlyequal-total-compute claim.',
  'dependence':'Hash coordinategeometry,geometry+demand,andgeometry+demand+service (sorted customer tuples,depot separate) plus orderedgeometry;reportfamilies andclusters. The56 temporal/capacity variants arenot independent geometries. No significance tests andnoheldout/generalization claim.',
  'selection_features':'Only simple presolutionfeatures,for potentiallaterstudy;no training or selector evaluationsdoneonthisdataset.',
  'external_comparability':'SINTEF BKS is vehicles-first then distance;ourdistance-only objective isdifferent.No officialgapreported.',
  'costs':'No paidmodelAPI,newpurchase,newsoftwareinstallation orCodex.No transmission toexternalmodelproviders.',
  'distribution':'CleanZIP excludesoriginalinputs,venv,caches andcredentials. PrivateDrive sourceIDs/inputhashesand localverificationinstructions included. No uploadinthis task.'}
 write('protocol/protocol.json',protocol)
 write('evidence/environment.json',{'python':sys.version,'python_executable':sys.executable,'platform':platform.platform(),'ortools_version':core.importlib.metadata.version('ortools'),'logical_cpus':os.cpu_count(),'execution':'dot cloud,currentexistingPythonvenv,one serial Routing CP instanceat a time','single_thread_control':'OMP_NUM_THREADS=1;CP-SATdisabled;CP routingnotparallel','limits':{'child_cpu_s':169,'supervisor_cpu_s':5,'reserved_verification_cpu_s':5}})
 write('evidence/checker_tests.json',{'tests':checker.tests(),'passed':True})
 names=[str(p.relative_to(P)) for folder in ['source','protocol','evidence'] for p in sorted((P/folder).glob('*')) if p.is_file() and p.name!='freeze.json']
 write('protocol/freeze.json',{'frozen_utc':datetime.now(timezone.utc).isoformat(),'solver_calls_before_freeze':0,'input_count':56,'request_count':224,'sha256':{n:sha(P/n) for n in names}})
 print('FROZEN 56 inputs,224 requests;zero pilot calls.',flush=True)
 return requests

sqrtcache={}
def independently_check(instance,r):
 t=time.perf_counter();c=time.process_time();audit=None
 if r.get('assignment_returned'):
  original=checker.read_original(INPUT/f'{instance}.txt');audit=checker.check(original,r['routes'])
  if audit['valid']:
   obj=0;arc_count=0
   for route in r['routes']:
    for a,b in zip(route['nodes'],route['nodes'][1:]):
     x=original['nodes'][a];y=original['nodes'][b];sq=(x[0]-y[0])**2+(x[1]-y[1])**2
     if sq not in sqrtcache:
      with localcontext() as ctx:
       ctx.prec=50;sqroot=Decimal(sq).sqrt()*SCALE
       sqrtcache[sq]=int(sqroot.to_integral_value(rounding=ROUND_HALF_UP))
     obj+=sqrtcache[sq];arc_count+=1
   err=abs(obj/SCALE-audit['distance']);bound=0.5*arc_count/SCALE+1e-9
   audit.update(independent_objective_integer=obj,reported_objective_integer=r['objective_integer'],rounding_error=err,rounding_bound=bound,arc_count=arc_count)
   if obj!=r['objective_integer']:audit['errors'].append('integer objective mismatch')
   if err>bound:audit['errors'].append('distance rounding bound exceeded')
   audit['valid']=not audit['errors']
  r['outcome']='SUCCESS' if audit['valid'] else 'FAIL_CHECKER'
 r['check_wall_s']=time.perf_counter()-t;r['check_cpu_s']=time.process_time()-c
 r['request_accounted_cpu_s']=r.get('total_cpu_s',0)+r['check_cpu_s']
 r['request_accounted_wall_s']=r.get('total_wall_s',0)+r['check_wall_s']
 return audit

def run(requests):
 for name,d in json.loads((P/'protocol/freeze.json').read_text())['sha256'].items():assert sha(P/name)==d,name
 t0=time.perf_counter();c0=time.process_time();rows=[]
 with (P/'raw/results.jsonl').open('x') as out,(P/'raw/continuous_checks.jsonl').open('x') as checks:
  for req in requests:
   c1=time.process_time();t1=time.perf_counter()
   try:
    d=core.parse(INPUT/f"{req['instance']}.txt");parse_cpu=time.process_time()-c1;parse_wall=time.perf_counter()-t1
    r=core.solve(d,req);r.update(parse_cpu_s=parse_cpu,parse_wall_s=parse_wall)
    audit=independently_check(req['instance'],r)
    r['request_accounted_cpu_s']+=parse_cpu;r['request_accounted_wall_s']+=parse_wall
   except Exception as e:
    r={**req,'outcome':'FAIL_EXCEPTION','assignment_returned':False,'routes':None,'error':repr(e),'traceback':traceback.format_exc(),'request_accounted_cpu_s':time.process_time()-c1,'request_accounted_wall_s':time.perf_counter()-t1};audit=None
   if audit:
    checks.write(json.dumps({'run_id':req['run_id'],**audit})+'\n');checks.flush()
    r['check_summary']={k:v for k,v in audit.items() if k!='route_audits'}
   out.write(json.dumps(r,allow_nan=False)+'\n');out.flush();rows.append(r)
   print(req['sequence']+1,req['run_id'],r['outcome'],r.get('check_summary',{}).get('distance'),flush=True)
 write('raw/runner_resource.json',{'wall_s':time.perf_counter()-t0,'cpu_s':time.process_time()-c0,'requests_completed':len(rows),'maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss})
 return rows

def valid(r):return r.get('outcome')=='SUCCESS'
def distance(r):return r.get('check_summary',{}).get('distance') if valid(r) else None
def stat(rows,label):
 good=[r for r in rows if valid(r)];ds=[distance(r) for r in good]
 return {'method':label,'requests':len(rows),'legal_count':len(good),'legal_rate':len(good)/len(rows) if rows else None,'outcome_counts':dict(collections.Counter(r['outcome'] for r in rows)),'distance_valid_sum':sum(ds) if ds else None,'distance_valid_mean':mean(ds),'distance_valid_median':statistics.median(ds) if ds else None,'vehicles_valid_mean':mean([r['check_summary']['vehicles_used'] for r in good]),'vehicles_valid_sum':sum(r['check_summary']['vehicles_used'] for r in good),'cpu_s':sum(r.get('request_accounted_cpu_s',0) for r in rows),'wall_s':sum(r.get('request_accounted_wall_s',0) for r in rows),'solve_cpu_s':sum(r.get('solve_cpu_s',0) for r in rows),'model_cpu_s':sum(r.get('model_cpu_s',0) for r in rows),'checker_cpu_s':sum(r.get('check_cpu_s',0) for r in rows)}
def paired(a,b,label):
 both=[i for i in a if valid(a[i]) and valid(b[i])];delta=[distance(a[i])-distance(b[i]) for i in both];ratios=[100*(distance(a[i])/distance(b[i])-1) for i in both]
 da=sum(distance(a[i]) for i in both);db=sum(distance(b[i]) for i in both)
 return {'comparison':label,'both_valid_count':len(both),'first_only_valid':sum(valid(a[i]) and not valid(b[i]) for i in a),'second_only_valid':sum(not valid(a[i]) and valid(b[i]) for i in a),'both_invalid':sum(not valid(a[i]) and not valid(b[i]) for i in a),'first_wins':sum(x < -TOL for x in delta),'ties':sum(abs(x)<=TOL for x in delta),'second_wins':sum(x>TOL for x in delta),'first_distance_sum':da,'second_distance_sum':db,'sum_distance_reduction_first_vs_second_pct':100*(1-da/db) if db else None,'mean_per_instance_first_vs_second_pct':mean(ratios),'median_per_instance_first_vs_second_pct':statistics.median(ratios) if ratios else None,'mean_absolute_distance_delta_first_minus_second':mean(delta)}

def analyze(rows):
 t0=time.perf_counter();c0=time.process_time();requests=json.loads((P/'protocol/requests.json').read_text());seen={r['run_id'] for r in rows}
 for req in requests:
  if req['run_id'] not in seen:rows.append({**req,'outcome':'NOT_RUN_BUDGET','assignment_returned':False,'routes':None,'request_accounted_cpu_s':0,'request_accounted_wall_s':0})
 assert len(rows)==224 and len({r['run_id'] for r in rows})==224
 by=collections.defaultdict(dict)
 for r in rows:by[r['config_id']][r['instance']]=r
 names=sorted(by[SHORT[0]]);stats=[stat(list(by[c['config_id']].values()),c['config_id']) for c in CONFIGS]
 oracle={};selection_cpu=0.;selection_wall=0.
 for name in names:
  t=time.perf_counter();c=time.process_time();cands=[by[s][name] for s in SHORT if valid(by[s][name])]
  chosen=min(cands,key=distance) if cands else None
  selection_cpu+=time.process_time()-c;selection_wall+=time.perf_counter()-t
  oracle[name]={**chosen,'config_id':'best_of_3','chosen_config':chosen['config_id']} if chosen else {'instance':name,'family':by[SHORT[0]][name]['family'],'config_id':'best_of_3','outcome':'NO_VALID_PORTFOLIO_RESULT','chosen_config':None}
  for k in ['request_accounted_cpu_s','request_accounted_wall_s','solve_cpu_s','model_cpu_s','check_cpu_s']:oracle[name][k]=sum(by[s][name].get(k,0) for s in SHORT)
 portfolio=stat(list(oracle.values()),'best_of_3_executed');portfolio['cpu_s']+=selection_cpu;portfolio['wall_s']+=selection_wall;portfolio['selection_cpu_s']=selection_cpu;portfolio['selection_wall_s']=selection_wall
 coverage={s:sum(valid(r) for r in by[s].values()) for s in SHORT};top=[s for s in SHORT if coverage[s]==max(coverage.values())]
 common=[i for i in names if all(valid(by[s][i]) for s in top) and valid(oracle[i])]
 scores={s:mean([distance(by[s][i])/distance(oracle[i]) for i in common]) for s in top}
 sbs=min(top,key=lambda s:(scores[s] if scores[s] is not None else math.inf,SHORT.index(s)))
 comparable=[i for i in names if valid(by[sbs][i]) and valid(oracle[i])]
 gap=[100*(distance(by[sbs][i])/distance(oracle[i])-1) for i in comparable]
 headroom={'posthoc_sbs':sbs,'max_coverage_candidates':top,'selection_common_count':len(common),'selection_mean_ratio_to_vbs':scores,'paired_count':len(comparable),'mean_sbs_over_vbs_gap_pct':mean(gap),'median_sbs_over_vbs_gap_pct':statistics.median(gap) if gap else None,'maximum_sbs_over_vbs_gap_pct':max(gap) if gap else None,'mean_oracle_reduction_vs_sbs_pct':mean([100*(1-distance(oracle[i])/distance(by[sbs][i])) for i in comparable]),'complementary_improvement_instances':[i for i in comparable if distance(oracle[i])<distance(by[sbs][i])-TOL],'rescued_sbs_failures':[i for i in names if valid(oracle[i]) and not valid(by[sbs][i])],'oracle_valid_count':sum(valid(r) for r in oracle.values()),'limits':'Observed-set3-configurationheadroomonly,posthocSBS,andno generalizationorselector claim.'}
 comparisons=[paired(oracle,by[sbs],'best_of_3_vs_posthoc_SBS'),paired(oracle,by['pci750'],'best_of_3_vs_fixed_PCI750'),paired(by['pci750'],by['pci250'],'fixed_PCI750_vs_fixed_PCI250')]
 for s in SHORT:comparisons.append(paired(oracle,by[s],'best_of_3_vs_'+s))
 instances=[];features={r['instance']:r for r in json.loads((P/'protocol/instance_features.json').read_text())}
 for i in names:
  row={'instance':i,'family':features[i]['family'],'geometry_sha256':features[i]['geometry_sha256']}
  for conf in [*SHORT,'pci750']:
   r=by[conf][i];row.update({f'{conf}_outcome':r['outcome'],f'{conf}_distance':distance(r),f'{conf}_vehicles':r.get('check_summary',{}).get('vehicles_used'),f'{conf}_cpu_s':r.get('request_accounted_cpu_s',0)})
  v=distance(oracle[i]);win=[s for s in SHORT if valid(by[s][i]) and abs(distance(by[s][i])-v)<=TOL] if v is not None else []
  row.update(best_of_3_chosen=oracle[i]['chosen_config'],short_tied_winners=';'.join(win),best_of_3_distance=v,best_of_3_cpu_s=oracle[i]['request_accounted_cpu_s'],sbs=sbs,sbs_over_vbs_gap_pct=100*(distance(by[sbs][i])/v-1) if i in comparable else None,best_of_3_vs_pci750_pct=100*(v/distance(by['pci750'][i])-1) if valid(oracle[i]) and valid(by['pci750'][i]) else None)
  instances.append(row)
 wins={'unique_wins':{s:sum(r['short_tied_winners']==s for r in instances) for s in SHORT},'wins_including_ties':{s:sum(s in r['short_tied_winners'].split(';') for r in instances) for s in SHORT},'tied_instances':sum(len(r['short_tied_winners'].split(';'))>1 for r in instances),'uncovered_instances':sum(not r['short_tied_winners'] for r in instances)}
 clusters=json.loads((P/'protocol/shared_geometry.json').read_text());family=[];geometry=[]
 for fam in sorted(set(r['family'] for r in rows)):
  ids=[i for i in names if features[i]['family']==fam]
  family.append({'family':fam,'n':len(ids),'methods':[stat([r for r in rows if r['family']==fam and r['config_id']==c['config_id']],c['config_id']) for c in CONFIGS],'portfolio_vs_long':paired({i:oracle[i] for i in ids},{i:by['pci750'][i] for i in ids},'best_of_3_vs_PCI750')})
 for g in clusters['geometry_sha256']:
  ids=g['instances'];geometry.append({**g,'families':sorted(set(features[i]['family'] for i in ids)),'portfolio_vs_sbs':paired({i:oracle[i] for i in ids},{i:by[sbs][i] for i in ids},'best_of_3_vs_SBS'),'portfolio_vs_long':paired({i:oracle[i] for i in ids},{i:by['pci750'][i] for i in ids},'best_of_3_vs_PCI750')})
 summary={'study_id':'SOLVER_PORTFOLIO_HEADROOM_ARCHIVED100_V1','all_requests':224,'new_raw_records':len(seen),'methods':stats,'executed_portfolio':portfolio,'posthoc_headroom':headroom,'paired_comparisons':comparisons,'configuration_wins':wins,'family_results':family,'geometry_results':geometry,'geometry_group_counts':{k:len(v) for k,v in clusters.items()},'actual_portfolio_cpu_over_long':portfolio['cpu_s']/next(s for s in stats if s['method']=='pci750')['cpu_s']}
 write('reports/summary.json',summary);write('reports/failures.json',[r for r in rows if not valid(r)]);write('reports/evaluated_results.json',rows);write('reports/instance_comparisons.json',instances);write('reports/geometry_comparisons.json',geometry);write('reports/family_comparisons.json',family);write('reports/pairwise_short.json',[paired(by[a],by[b],a+'_vs_'+b) for n,a in enumerate(SHORT) for b in SHORT[n+1:]])
 csvwrite('reports/instance_comparisons.csv',instances);csvwrite('reports/method_metrics.csv',[{k:v for k,v in s.items() if k!='outcome_counts'} for s in stats]+[{k:v for k,v in portfolio.items() if k not in ['outcome_counts','selection_cpu_s','selection_wall_s']}])
 # Freeze and source input identity are checked again after all runs.
 changed=[n for n,d in json.loads((P/'protocol/freeze.json').read_text())['sha256'].items() if sha(P/n)!=d]
 changed_inputs=[m['name'] for m in json.loads((P/'protocol/input_manifest.json').read_text()) if sha(INPUT/m['name'])!=m['sha256']]
 assert not changed and not changed_inputs
 write('evidence/verification.json',{'request_count':224,'raw_count':len(seen),'unique_run_ids':len(seen),'all_frozen_files_unchanged':not changed,'all_original_input_hashes_unchanged':not changed_inputs,'checker_success_count':sum(valid(r) for r in rows),'checker_rejection_count':sum(r['outcome']=='FAIL_CHECKER' for r in rows),'all_failures_preserved':True,'source_parameter_diff_validated_before_freeze':True,'no_reruns':True,'geometry_groups':{k:len(v) for k,v in clusters.items()},'integer_objective_method':'Independent50digitDecimalEuclideansqrt,ROUND_HALF_UP','original_distance_error_bound_verified':all(r['check_summary']['rounding_error']<=r['check_summary']['rounding_bound'] for r in rows if valid(r))})
 write('raw/analysis_resource.json',{'cpu_s':time.process_time()-c0,'wall_s':time.perf_counter()-t0})
 report(summary)
 return summary

def report(s):
 fmt=lambda x:'NA' if x is None else f'{x:.6f}'
 h=s['posthoc_headroom'];p=s['paired_comparisons'][1];v=s['executed_portfolio'];long=next(r for r in s['methods'] if r['method']=='pci750');geom=s['geometry_group_counts']
 lines=['成熟求解器配置组合的条件互补上限：完整新实验','',f"冻结后新执行224/224请求：56个用户存档百客户实例 × 3种250ms配置与1种750ms固定参考。",'所有配置：OR-Tools9.14.6206，GLS(lambda0.1)，相同CP ReSeed，原车辆上限/容量/连续时间窗，全100客户必服务，唯一目标总距离。','', '逐方法结果（距离与车辆数仅对合法结果；法定率分母均56）：']
 for r in s['methods']:
  lines.append(f"{r['method']}: 合法{r['legal_count']}/56，距离均值{fmt(r['distance_valid_mean'])}，合法结果距离和{fmt(r['distance_valid_sum'])}，车辆均值{fmt(r['vehicles_valid_mean'])}，实际请求CPU{r['cpu_s']:.6f}s，wall{r['wall_s']:.6f}s；状态{r['outcome_counts']}")
 lines+=['',f"事后SBS={h['posthoc_sbs']}，VBS/实际执行best-of-3合法{v['legal_count']}/56。SBS选择首先比较覆盖，再在最大覆盖候选共同合法集合({h['selection_common_count']})比较平均归一化距离。",f"在SBS与VBS共同合法的{h['paired_count']}例上，平均(SBS/VBS-1)={h['mean_sbs_over_vbs_gap_pct']:.6f}%，中位数{h['median_sbs_over_vbs_gap_pct']:.6f}%；平均相对SBS降幅{h['mean_oracle_reduction_vs_sbs_pct']:.6f}%。",f"互补改进{len(h['complementary_improvement_instances'])}例；SBS失败而组合救回{len(h['rescued_sbs_failures'])}例。唯一赢家次数{s['configuration_wins']['unique_wins']}；含并列次数{s['configuration_wins']['wins_including_ties']}。",'',f"best-of-3 对固定PCI750：共同合法{p['both_valid_count']}，组合胜/平/负={p['first_wins']}/{p['ties']}/{p['second_wins']}；总距离相对降低{p['sum_distance_reduction_first_vs_second_pct']:.6f}%，平均逐实例相对差(组合/长预算-1)={p['mean_per_instance_first_vs_second_pct']:.6f}%。",f"组合实际请求CPU={v['cpu_s']:.6f}s，PCI750={long['cpu_s']:.6f}s，比值{s['actual_portfolio_cpu_over_long']:.6f}；组合选择额外CPU={v['selection_cpu_s']:.9f}s。",'250ms×3与750ms仅等名义搜索上限；组合要做3次建模/抽取/校验，有的失败可能提前结束，实际CPU不相等，不能称严格等总算力。组合执行的结果等于这3个已观察输出上的VBS，不是免费可实现的选择器。','',f"几何依赖：坐标集合{geom['geometry_sha256']}组，坐标+需求{geom['geometry_demand_sha256']}组，坐标+需求+服务{geom['geometry_demand_service_sha256']}组，按原node ID有序坐标{geom['ordered_geometry_sha256']}组。56例不是56个独立几何。",'每实例胜负/失败及简单特征已保存；按6个命名族和几何簇提供分层结果。没有训练选择器，没有把同集当测试，没有显著性检验、外泛化或新heldout声明。','', '方法与边界：','1. 先检查官方策略API与已安装版本；冻结全部参数、源码、输入指纹、请求和评价规则后才求解。短配置仅first_solution_strategy不同；长配置仅时间预算不同。PCI=PARALLEL_CHEAPEST_INSERTION，PCA=PATH_CHEAPEST_ARC，SAV=SAVINGS。','2. 主配置250ms也重新执行；旧实验路线和指标没有引入。本轮是完整新对比，不是失败补跑。每实例轮换4配置顺序，各位置14次。','3. CP ReSeed设置内部随机发生器；这些启发式未必消耗其随机流。CP-SAT关闭，其random_seed不生效。配置固定不代表wall截断后结果严格确定；没有重复运行估计时间噪声。','4. 1e6整数缩放：成本精确最近整数(中点向上)，行驶时间向上取整，时间窗/服务精确整数缩放。成本误差上限0.5×(100+用车数)/1e6；单路线保守时间增量<0.000101。保守模型可能排除原连续边界可行路线。','5. 所有返回路线按原坐标独立重放，检查覆盖/重复/容量/服务开始窗/返仓；另以50位Decimal重新算整数目标和距离舍入界。未返回解仅记TIMEOUT/UNKNOWN，不证明原问题不可行。','6. 原数据来自已授权用户存档；56名称/格式一致，但未独立获得官方文件hash，不能宣称已认证官方字节。SINTEF BKS是车数优先的词典序目标，本轮距离单目标不同，不计算官方gap。','7. 本结果只说明这些实例、3个配置与很短预算下的条件互补。它不能证明LLM有收益、推荐器有效或组合外推有效。若进一步研究选择器，需要事先规划独立几何与时间预算、训练/验证/测试拆分及选择开销。','8. 无新安装、付费模型API、Codex或外传模型提示词。主子进程全链硬CPU169秒，监督5秒，预留独审5秒，合计180秒；资源证据另列。','9. 干净ZIP不含原始实例、venv或凭证。保留原Drive ID、hash、私有副本获取/验证说明、源码、冻结、raw、失败、报告与资源证据。本任务未上传。','', '参考：','https://developers.google.com/optimization/routing/routing_options','https://www.sintef.no/projectweb/top/vrptw/100-customers/','https://www.sintef.no/projectweb/top/vrptw/documentation2/','https://www.sintef.no/projectweb/top/vrptw/solomon-benchmark/','Solomon(1987), Operations Research35(2),254–265,doi:10.1287/opre.35.2.254']
 if h['mean_sbs_over_vbs_gap_pct'] and h['mean_sbs_over_vbs_gap_pct']>0:
  lines.insert(2,f"结论：这个固定小组合在同一存档集合内有可观察互补空间；规模见下文，尚不足以判断学习选择器是否值得其训练和运行成本。")
 else:lines.insert(2,'结论：本次短预算、固定3配置组合没有观察到SBS之上的距离互补空间；不能据此否定其他预算或几何上的可能性。')
 (P/'reports/report_zh.txt').write_text('\n'.join(lines)+'\n')

if __name__=='__main__':
 t=time.perf_counter();c=time.process_time();requests=prepare();write('raw/preparation_resource.json',{'cpu_s':time.process_time()-c,'wall_s':time.perf_counter()-t,'note':'Actual childprocess totalalsoincludes imports beforethisphase.'});rows=run(requests);analyze(rows)
 write('raw/child_resource_before_exit.json',{'child_process_cpu_s':time.process_time(),'wall_s_since_module_start':time.perf_counter()-START,'maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'hard_cpu_limit_s':169,'requests':len(rows)})
 print('ALL224 FINISHED AND INDEPENDENTLY CHECKED',flush=True)
