"""Transparent post-run reporting-only edits; never changes frozen experiment or raw data."""
import resource,signal
resource.setrlimit(resource.RLIMIT_CPU,(1,1))
signal.setitimer(signal.ITIMER_PROF,0.8)
import json,time,hashlib,zipfile
from pathlib import Path
P=Path(__file__).resolve().parent.parent
receipt_path=P.parent/(P.name+'_package_receipt.json')
old=json.loads(receipt_path.read_text());archive=P.parent/(P.name+'.zip')
for name,h in json.loads((P/'protocol/freeze.json').read_text())['sha256'].items():assert hashlib.sha256((P/name).read_bytes()).hexdigest()==h
r=P/'reports/report_zh.txt';s=r.read_text().replace('法定率分母均56','合法率分母均56')
s=s.replace('监督5秒，预留独审5秒，合计180秒；资源证据另列。','监督5秒，预留独审5秒，三项硬限合计179秒；连同已测启动故障约0.044秒及本次报表修订/打包的0.8CPU秒硬限，总上界仍低于180秒。')
s=s.replace('组合选择额外CPU=0.000000000s。','组合选择额外CPU的本次计时读数为0s，选择wall约98微秒；0读数不能证明选择没有开销。')
s=s.replace('实际请求CPU14.563770s，wall14.600478s；状态', '实际请求CPU14.563770s，wall14.600478s；状态')
s+='\n报告补充（仅编辑呈现，不重跑）：PCA250的平均距离分母为49，其他方法为56，不能直接把这些不匹配分母的均值横比；同实例配对结果在pairwise_short.json。C2几何簇上组合总距离比PCI750高0.1502%，其他3几何簇较低，说明优势具有条件性。所有主实验冻结哈希、224个原始请求与结果数字均保持不变。\n'
r.write_text(s)
r=P/'README_zh.txt';r.write_text(r.read_text().replace('合计180s。','三项合计179s；含已测启动故障和本次0.8CPU秒修订打包硬限仍小于180s。'))
clar={'scope':'Reporting edits only. No solver calls, no raw or frozen file change.','changes':['Correct Chinese typo for legal rate.','Correct169+5+5 to179CPU seconds; disclose prior preflight and bounded reporting pass.','CPU selection readout0 does not demonstrate zero overhead; measured selectionwall98 microseconds.','Warn thatPCA mean distance uses49 successes while others use56.','Surface C2 cluster exception:portfolio0.1502% higher total distance thanPCI750.'],'previous_archive_sha256':old['sha256'],'previous_measured_total_cpu_s':old['total_measured_cpu_s'],'this_pass_cpu_hard_limit_s':0.8,'all_frozen_files_verified_unchanged':True}
(P/'evidence/reporting_clarifications.json').write_text(json.dumps(clar,ensure_ascii=False,indent=2)+'\n')
files=[x for x in sorted(P.rglob('*')) if x.is_file() and x.relative_to(P).parts[0] in {'source','protocol','raw','reports','evidence','README_zh.txt'} and '__pycache__' not in x.parts and x.suffix!='.pyc']
sums=''.join(hashlib.sha256(x.read_bytes()).hexdigest()+'  '+str(x.relative_to(P))+'\n' for x in files)
(P/'SHA256SUMS.txt').write_text(sums);files.append(P/'SHA256SUMS.txt')
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f in files:z.write(f,str(f.relative_to(P)))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for line in sums.splitlines():
  h,n=line.split('  ',1);assert hashlib.sha256(z.read(n)).hexdigest()==h
now={**old,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'file_count':len(files),'prior_archive_sha256':old['sha256'],'postrun_reporting_and_repack_cpu_s':time.process_time(),'total_measured_cpu_s':old['total_measured_cpu_s']+time.process_time(),'postrun_pass_cpu_hard_limit_s':0.8,'all_frozen_files_unchanged':True}
receipt_path.write_text(json.dumps(now,indent=2)+'\n')
(P.parent/(P.name+'.zip.sha256')).write_text(now['sha256']+'  '+archive.name+'\n')
print(json.dumps(now))
