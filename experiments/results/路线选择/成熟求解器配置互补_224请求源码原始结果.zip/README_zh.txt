成熟求解器小配置组合互补上限实验

先读 reports/report_zh.txt；机器可读报告在 reports/summary.json。
配置：PCI250、PCA250、SAVINGS250、固定PCI750；全部统一GLS和约束，224次独立新请求。
协议与冻结：protocol/protocol.json、freeze.json、requests.json及4个完整参数textproto。
源码：source/core.py为模型，checker.py为独立连续检查，study.py为冻结/完整新跑/分析，supervise.py为CPU约束/资源/干净打包。
原始结果与逐步路线重放：raw/results.jsonl、raw/continuous_checks.jsonl。
实例胜负和特征：reports/instance_comparisons.csv、instance_features.csv；共享几何见protocol/shared_geometry.json。

获取输入：本包故意不含许可未明的56个原始实例。对有权限的用户，protocol/input_manifest.json列出原Google Drive文件ID、URL、文件名和SHA256。使用已有授权Google Drive连接取得私有副本，再执行：
python source/verify_inputs.py /path/to/authorized/instances
只接受精确字节相同的副本。不以其他文件默默替代已冻结实例。不绕过官方源403，不推断用户存档已获官方字节认证。

本次直接读取旧实验inputs目录，无复制或修改。venv使用已安装OR-Tools9.14.6206；版本锁见source/requirements.lock。本任务没有安装库。
新的完整复现实验应另建独立目录，复制本包source与输入manifest、evidence/source_notes.json、package_provenance.json和source_reuse.json，建立空protocol/raw/reports/evidence子目录，明确重新冻结与执行全部224请求；不将旧raw/freeze混入新运行。把VRPTW_INPUT_DIR设置为授权输入路径，用同版本Python环境运行：
VRPTW_INPUT_DIR=/path/to/authorized/instances python source/supervise.py /path/to/venv/bin/python
已完成目录禁止直接重跑。固定种子不等于wall限时下逐位确定性，重新执行结果可以不同。

CPU硬预算：子进程169s，含初始化、准备、求解、校验、分析；监督及打包5s；预留独立审计5s；三项合计179s；含已测启动故障和本次0.8CPU秒修订打包硬限仍小于180s。搜索wall预算名义84s。各方法实际CPU另外报告。
根目录SHA256SUMS.txt验证包内文件；外部_package_receipt.json和zip.sha256记录ZIP自身hash与含打包的完整实际资源，避免自包含hash循环。
该ZIP与研究内容尚未上传；没有公开分享、API模型调用或外部模型数据传输。
