"""Read-only scientific reconstruction after SIGKILL; no solver/model execution or fitting."""
from pathlib import Path
import os,json,collections,time,hashlib
from datetime import datetime,timezone
P=Path(__file__).resolve().parent.parent
c=time.process_time();t=time.perf_counter()
def read(p):return json.loads(p.read_text())
def write(rel,z):(P/rel).write_text(json.dumps(z,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
reqs=read(P/'protocol/requests.json');results=[json.loads(s) for s in (P/'raw/results.jsonl').read_text().splitlines()];events=[json.loads(s) for s in (P/'raw/events.jsonl').read_text().splitlines()];preds=read(P/'protocol/predictions_sealed.json')
by={r['run_id']:r for r in results};started={r['run_id'] for r in events if r['event']=='request_start'}
assert len(reqs)==576 and len(results)==347 and len(started)==348
ledger=[{**r,'terminal_status':by[r['run_id']]['outcome'] if r['run_id'] in by else 'INTERRUPTED' if r['run_id'] in started else 'NOT_STARTED','termination_cause':None if r['run_id'] in by else 'unknown_SIGKILL_exit137'} for r in reqs]
write('runtime/request_terminal_ledger_corrected.json',ledger)
missing=[r for r in ledger if r['terminal_status'] in ['INTERRUPTED','NOT_STARTED']];write('runtime/not_completed_corrected.json',missing)
erratum={'utc':datetime.now(timezone.utc).isoformat(),'affected_original_file':'runtime/not_completed_requests.json','original_file_preserved':True,'issue':'The post-exit helper assumed all exit137 events were budget kills and classified never-started requests NOT_RUN_BUDGET. Exit137 alone does not identify cause. Recorded shell CPU111.258s is below hard180s.','corrected_file':'runtime/not_completed_corrected.json','corrected_status_counts':dict(collections.Counter(r['terminal_status'] for r in missing)),'termination_cause':'unknown','scientific_predictions_inputs_results_unchanged':True,'no_solver_retry':True}
write('runtime/termination_classification_erratum.json',erratum)
counts={phase:{'planned_calls':sum(r['phase']==phase for r in reqs),'completed_calls':sum(r['phase']==phase for r in results),'statuses':dict(collections.Counter(r['terminal_status'] for r in ledger if r['phase']==phase))} for phase in ['C','E']}
chosen=read(P/'protocol/calibration_selection.json')['rule']['id'];terminal={r['run_id']:r['terminal_status'] for r in ledger};policy_coverage={}
for method in ['B','G0','GW','GM','GC','RAW']:
 states=[]
 for p in preds:
  if p['split']!='E':continue
  gate=p['candidates'][chosen] if method=='GC' else p['fixed'][method]
  slot='A' if gate['config']=='pci250' else 'B'
  for rep in range(3):
   rid=p['instance']+f'__r{rep}__{slot}';states.append({'instance':p['instance'],'base_group':p['base_group'],'repeat':rep,'config':gate['config'],'slot':slot,'run_id':rid,'terminal_status':terminal[rid]})
 policy_coverage[method]={'planned_measurements':192,'planned_problems':64,'independent_base_groups':16,'status_counts':dict(collections.Counter(r['terminal_status'] for r in states)),'rows':states,'quality_statistics':'WITHHELD_INCOMPLETE_TEST_NO_OVERALL_COMPARISON'}
write('reports/incomplete_test_policy_accounting.json',policy_coverage)
failures=[r for r in results if r['outcome']!='SUCCESS'];write('reports/observed_failures_before_interruption.json',failures)
host=[json.loads(s) for s in (P/'runtime/host_snapshots.jsonl').read_text().splitlines()];rss=[];page=os.sysconf('SC_PAGE_SIZE')
for r in host:
 for z in r['visible_process_stats']:
  if '(python)' not in z['stat']:continue
  a=z['stat'].split(') ',1)[1].split();rss.append({'run_id':r['run_id'],'utc':r['utc'],'pid':z['pid'],'parent_pid':int(a[1]),'virtual_bytes':int(a[20]),'rss_pages':int(a[21]),'rss_bytes':int(a[21])*page,'rss_mib':int(a[21])*page/2**20})
mem={'page_size_bytes':page,'samples':len(rss),'first':rss[0],'last':rss[-1],'peak_visible_rss_mib':max(r['rss_mib'] for r in rss),'series':rss,'observation':'Marked resident-memory growth across fresh-model calls; not proof that OOM caused SIGKILL.','post_exit_cgroup_visible':Path('/sys/fs/cgroup').exists(),'post_exit_proc_self_cgroup':Path('/proc/self/cgroup').read_text(),'post_exit_cgroup_mounts':[s for s in Path('/proc/mounts').read_text().splitlines() if 'cgroup' in s],'namespace_caveat':'Post-exit tool process may have different namespace; absent cgroup records do not establish author memory limit or kill cause.'}
write('runtime/memory_growth_observation.json',mem)
freeze=read(P/'protocol/freeze.json');mut=[r for r,h in freeze['sha256'].items() if hashlib.sha256((P/r).read_bytes()).hexdigest()!=h];assert not mut
seal=next(e['sequence'] for e in events if e['event']=='scientific_freeze');cal=next(e['sequence'] for e in events if e['event']=='calibration_sealed');e0=min(e['sequence'] for e in events if e['event']=='request_start' and e['phase']=='E');assert cal<e0
summary={'status':'INTERRUPTED_NO_COMPLETE_TEST_CONCLUSION','completed_solver_calls':347,'started_calls':348,'planned_calls':576,'not_completed':229,'corrected_not_completed_statuses':erratum['corrected_status_counts'],'phase_counts':counts,'calibration_selected_rule':chosen,'calibration_complete':True,'test_complete':False,'test_quality_conclusion':None,'shell_wall_s':118.965,'shell_user_s':87.623,'shell_system_s':23.635,'shell_cpu_sum_s':111.258,'hard_cpu_limit_s':180,'cpu_limit_not_shown_reached':True,'exit_code':137,'termination_cause':'unknown_SIGKILL','scientific_frozen_files':len(freeze['sha256']),'scientific_mutations':mut,'scientific_seal_event_sequence':seal,'calibration_seal_event_sequence':cal,'first_test_start_event_sequence':e0,'no_rerun':True,'postrun_analysis_contains_no_solver_or_prediction_calls':True,'memory_peak_observed_mib':mem['peak_visible_rss_mib']}
write('reports/interruption_summary.json',summary)
lines=['距离门机制实验v1：中断交付报告','', '结论：没有完整测试结论；实验不补跑。',f'已完成347/576求解请求，已开始348。C校准192槽完整，E测试仅155/384槽完成。1槽已开始后中断，228槽尚未开始。','全部已完成结果、失败、计划未执行项均保留。E计划分母仍为64题×3重复、16独立基础geometry。不得把已完成的测试前缀当完整新验证。','', '校准按预注册选择r=1.0，margin仍0.01；选中候选C96/96观测成功，零额外失败，3题变体/2基础组采用非PCI，等组质量改善约0.201%。此数是择优校准分数，不能当测试收益。','原固定预测、所有GC候选、请求顺序均先封存；C阈值与E最终决策再次锁定后才有任何E求解。','', '中断：child Python收到SIGKILL，bash退出码137；实测wall118.965秒，user87.623秒+system23.635秒=CPU111.258秒，未显示触及180CPU硬限。具体原因未知。','请求前RSS从约57MiB升至约2157MiB，存在明显内存累积；没有可读cgroup/OOM事件，不能归因OOM。墙钟接近120秒也不足以归因工具超时。launcher只设置yield_time_ms=1000并获得session88129，未设置且接口未暴露timeout参数；shell存活并完成after_exit。','', '计账纠正：after_exit原脚本将exit137的未启动项误标NOT_RUN_BUDGET。原文件与冻结代码保持不动，runtime/termination_classification_erratum.json说明原因；正确账本为request_terminal_ledger_corrected.json和not_completed_corrected.json，使用INTERRUPTED/NOT_STARTED，原因unknown。','科学冻结哈希复核零修改；未补抽、未改阈值、未重试、未执行剩余请求。','', '数据入口：protocol/requests.json列576槽；raw/results.jsonl列347实际结果；raw/events.jsonl列348次开始；reports/observed_failures_before_interruption.json列全部已观察失败；reports/incomplete_test_policy_accounting.json按192计划观测保留每政策的缺失/中断状态，质量统计停止输出。','实际主运行资源以runtime/shell_time.txt和shell_exit_receipt.json为准。postrun仅分析旧输出，不含求解，成本另计。独立审计也另计。','这条机制实验独立于LLM BPP链；未读LLM heldout、未调用API、未上传。']
(P/'reports/interruption_report_zh.txt').write_text('\n'.join(lines)+'\n')
write('runtime/postrun_analysis_cost.json',{'cpu_s':time.process_time()-c,'wall_s':time.perf_counter()-t,'outside_main180cpu':True,'solver_calls':0,'purpose':'Preserve incomplete experiment and correct cause classification without altering frozen files.'})
print(json.dumps(summary,ensure_ascii=False,indent=2))
