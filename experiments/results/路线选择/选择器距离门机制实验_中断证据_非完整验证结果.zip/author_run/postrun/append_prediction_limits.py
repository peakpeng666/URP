"""Describe already sealed decisions, without running a model or solver."""
from pathlib import Path
import json,time
P=Path(__file__).resolve().parent.parent;c=time.process_time();t=time.perf_counter()
def read(rel):return json.loads((P/rel).read_text())
def write(rel,z):(P/rel).write_text(json.dumps(z,ensure_ascii=False,indent=2)+'\n')
pred=read('protocol/predictions_sealed.json');rule=read('protocol/calibration_selection.json')['rule']['id']
e=[p for p in pred if p['split']=='E'];sel=[p for p in e if p['candidates'][rule]['config']!='pci250']
z={'source':'Already sealed predictions and C-selected rule only; no new prediction, no E-cost selection.','total_instances':96,'test_instances':64,'test_base_groups':16,'selected_rule':rule,'GC_test_nonpci_cases':len(sel),'GC_test_nonpci_base_groups':sorted({p['base_group'] for p in sel}),'GC_test_nonpci_instances':[p['instance'] for p in sel],'preregistered_minimum_support_groups':4,'GC_support_threshold_met':len({p['base_group'] for p in sel})>=4,'G0_all96_nonpci_cases':sum(p['fixed']['G0']['config']!='pci250' for p in pred),'GW_all96_nonpci_cases':sum(p['fixed']['GW']['config']!='pci250' for p in pred),'GW_recovered_over_G0_instances':[p['instance'] for p in pred if p['fixed']['GW']['config']!='pci250' and p['fixed']['G0']['config']=='pci250'],'conclusions':['Even a complete test could not meet the preregistered primary positive-signal support threshold with these locked GC decisions.','GW recovered zero non-PCI choices, so this realization cannot test quality benefits of deleting the window distance component.','The algebraic w20 lower-bound result remains valid; it does not imply the remaining seven coordinates pass the0.5 gate.']}
assert len(sel)==6 and len(z['GC_test_nonpci_base_groups'])==3 and z['G0_all96_nonpci_cases']==z['GW_all96_nonpci_cases']==0
write('reports/sealed_prediction_limits.json',z)
append='''\n独审要求补充的机制支持限制（只核对封存决策，未用新测试成本）：\n1. 锁定GC在E只对6个题变体、3个独立基础组采用非PCI，低于预注册至少4组的支持门槛。因此即使补全测试，也不能达到这版预注册的继续研究正信号条件；本轮不补跑。\n2. G0和GW在全部96题都选择PCI，去窗宽门控恢复采用为0题、0组。本轮不能检验“移除窗宽项能恢复有益建议”。w20的2/3单维距离证明仍成立，但剩余七维也足以挡住建议；不能把结构证明等同于已找到有效门控修复。\n完整封存预测计数见reports/sealed_prediction_limits.json。\n'''
report=P/'reports/interruption_report_zh.txt';assert '独审要求补充的机制支持限制' not in report.read_text();report.write_text(report.read_text()+append)
summary=read('reports/interruption_summary.json');summary['sealed_prediction_limits']={k:v for k,v in z.items() if k not in ['source','conclusions','GC_test_nonpci_instances']};write('reports/interruption_summary.json',summary)
write('runtime/prediction_limits_appendix_cost.json',{'cpu_s':time.process_time()-c,'wall_s':time.perf_counter()-t,'outside_main180cpu':True,'solver_calls':0,'new_model_predictions':0,'frozen_files_modified':0,'purpose':'Append independent-audit limitations to the non-frozen interruption report.'})
print(json.dumps(z,ensure_ascii=False,indent=2))
