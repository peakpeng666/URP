#!/usr/bin/env bash
set -u
P=/workspace/shared/selector_distance_mechanism_run_20261007
PY=/workspace/shared/vrptw_mature_solver_20261007/.venv/bin/python
# Atomically refuse a second invocation. Static/toy checks do not create this marker.
( set -o noclobber; printf '%s\n' "$(date -u +%FT%TZ)" > "$P/runtime/launch_once.txt" ) || exit 73
export PYTHONHASHSEED=0 PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
TIMEFORMAT=$'real_s %R\nuser_s %U\nsys_s %S'
{ time "$PY" -B "$P/source/study.py" > "$P/raw/stdout.log" 2> "$P/raw/stderr.log"; } 2> "$P/runtime/shell_time.txt"
STATUS=$?
export RUN_EXIT_CODE="$STATUS"
"$PY" -B "$P/source/after_exit.py"
if [ "$STATUS" -ne 0 ]; then tail -50 "$P/raw/stderr.log"; fi
exit "$STATUS"
