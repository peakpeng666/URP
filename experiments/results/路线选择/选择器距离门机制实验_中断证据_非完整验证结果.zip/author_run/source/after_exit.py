"""Post-exit accounting only. Never imports or executes solver/model code."""
import os,json,time,hashlib
from pathlib import Path
from datetime import datetime,timezone
P=Path(__file__).resolve().parent.parent
c=time.process_time();t=time.perf_counter();status=int(os.environ['RUN_EXIT_CODE'])
def read(p):return json.loads(p.read_text())
def write(p,z):p.write_text(json.dumps(z,ensure_ascii=False,indent=2)+'\n')
requests=read(P/'protocol/requests.json') if (P/'protocol/requests.json').exists() else []
results=[json.loads(s) for s in (P/'raw/results.jsonl').read_text().splitlines()] if (P/'raw/results.jsonl').exists() else []
events=[json.loads(s) for s in (P/'raw/events.jsonl').read_text().splitlines()] if (P/'raw/events.jsonl').exists() else []
started={r['run_id'] for r in events if r['event']=='request_start'};done={r['run_id'] for r in results}
missing=[{**r,'terminal_status':'INTERRUPTED' if r['run_id'] in started else 'NOT_RUN_BUDGET' if status in [137,152] else 'NOT_RUN_ABORT'} for r in requests if r['run_id'] not in done]
write(P/'runtime/not_completed_requests.json',missing)
write(P/'runtime/shell_exit_receipt.json',{'utc':datetime.now(timezone.utc).isoformat(),'exit_code':status,'bash_time_fully_closed':True,'completed_requests':len(results),'planned_requests':len(requests),'not_completed':len(missing),'no_retry':True,'scope':'Shell has completed. Immutable scientific freeze excludes runtime logs and exit receipts.'})
freeze=read(P/'protocol/freeze.json') if (P/'protocol/freeze.json').exists() else None
mutated=[] if freeze is None else [r for r,h in freeze['sha256'].items() if hashlib.sha256((P/r).read_bytes()).hexdigest()!=h]
write(P/'runtime/post_exit_integrity.json',{'scientific_freeze_present':freeze is not None,'scientific_mutations':mutated,'all_frozen_bytes_unchanged':freeze is not None and not mutated,'solver_calls_in_postprocess':0,'postprocess_cpu_s':time.process_time()-c,'postprocess_wall_s':time.perf_counter()-t,'outside_main_cpu_budget':True})
print(json.dumps(read(P/'runtime/shell_exit_receipt.json'),ensure_ascii=False));print((P/'runtime/shell_time.txt').read_text());print('SCIENTIFIC_MUTATIONS',mutated)
