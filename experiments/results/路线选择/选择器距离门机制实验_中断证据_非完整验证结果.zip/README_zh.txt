距离门机制实验v1：完整中断证据包

本实验已停止，不补跑。347/576槽完成，348槽开始；C192完整、E155完成，1个INTERRUPTED、228个NOT_STARTED。未给不完整E结果计算整体质量优势。
校准半径按事前规则选r=1.0并在首次E前锁定。GC在E只采用6题/3独立组，低于预注册4组支持门槛；G0和GW在全部96题均PCI，去窗宽门控没有恢复采用。主进程收到SIGKILL，退出137；wall118.965秒、CPU111.258秒，未显示触及180CPU硬限。RSS从约57MiB增长到约2157MiB，但OOM/工具超时等具体原因未知。

目录：
- author_run：完整源码、96输入、576计划、347实际结果、348开始事件、全部失败、校准seal及中断/退出/内存证据
- preregistration：原预注册与w20单维必拒证明、独立算术脚本
- independent_audit：只读独立审计报告、逐项核对与资源收据

主中文报告：author_run/reports/interruption_report_zh.txt。
原错误NOT_RUN_BUDGET文件保留；runtime/termination_classification_erratum.json指明更正，正确状态见request_terminal_ledger_corrected.json。
科学freeze不含运行中收据，213个科学文件均未变化。源目录文件哈希见FILES_SHA256.json；此manifest不列自身。打包收据在ZIP外，生成于ZIP校验后，因此不自包含。主运行、独审、打包CPU分别记账；没有新求解、API、LLM heldout、上传或公开分享。
