"""Read-only arithmetic check. No solver/model imports, fitting, prediction, generation or network."""
from pathlib import Path
from fractions import Fraction
import collections, hashlib, json, math, statistics
ROOT=Path('/workspace/shared/selector_calibrated_abstention_20261007')
OUT=Path(__file__).resolve().parent

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p): return json.loads(p.read_text())
def feature(path):
    nodes=[]
    for line in path.read_text().splitlines():
        a=line.split()
        if len(a)==7:
            try: nodes.append(list(map(int,a)))
            except ValueError: pass
    assert len(nodes)==101 and [n[0] for n in nodes]==list(range(101))
    h=nodes[0][5]-nodes[0][4]
    w=sum(Fraction(n[5]-n[4],1) for n in nodes[1:])/100
    return w/Fraction(h,1)
ids=load(ROOT/'train/ids.json'); assert len(ids)==80
xs=[feature(ROOT/'train/inputs'/f'{i}.txt') for i in ids]
mu=sum(xs,Fraction(0))/len(xs)
var=sum(((x-mu)**2 for x in xs),Fraction(0))/len(xs)
assert mu==Fraction(3,50) and var==Fraction(9,10000)
sigma=Fraction(3,100)
model=load(ROOT/'train/frozen_model.json')
name='mean_window_width_over_depot_duration'
assert model['feature_means'][name]==float(mu)
assert model['feature_scales'][name]==float(sigma)
assert model['feature_population_stds'][name]==float(sigma)
pred=load(ROOT/'protocol/predictions_sealed.json')
rows=[]
for r in pred:
    i=r['instance']; x=feature(ROOT/'inputs'/f'{i}.txt')
    lower=min(abs(x-t)/sigma for t in set(xs))
    rows.append({'instance':i,'width':r['width'],'feature_fraction':str(x),
      'minimum_window_coordinate_distance_fraction':str(lower),
      'lower_bound_exceeds_radius_half':lower>Fraction(1,2),
      'archived_raw_choice':r['frozen_prediction']['selected_config'],
      'archived_full_distance':r['frozen_prediction']['standardized_distance']})
    assert r['frozen_prediction']['standardized_distance']+1e-12 >= float(lower)
nonpci=[r for r in pred if r['frozen_prediction']['selected_config']!='pci250']
assert len(nonpci)==32
assert all(not r['calibrated_gate']['distance_pass'] and r['calibrated_gate']['margin_pass'] for r in nonpci)
inputs=[ROOT/'train/inputs'/f'{i}.txt' for i in ids]+[ROOT/'inputs'/f"{r['instance']}.txt" for r in pred]
sources=[ROOT/'source/source_generator.py',ROOT/'source/selector.py',ROOT/'train/frozen_model.json',ROOT/'train/ids.json',ROOT/'protocol/predictions_sealed.json']
result={
 'status':'verified_by_raw_input_arithmetic_only',
 'source_feature_definition':'mean(customer_due-customer_ready)/(depot_due-depot_ready)',
 'training_instance_count':len(ids),
 'training_feature_values':dict(collections.Counter(map(str,xs))),
 'training_population_mean_fraction':str(mu),
 'training_population_variance_fraction':str(var),
 'training_population_scale_fraction':str(sigma),
 'frozen_scaler_matches_raw_inputs':True,
 'proof':'Euclidean standardized distance is at least the absolute difference in any one coordinate. w20/h2000=1/100; training widths give 3/100 and 9/100; minimum difference divided by 3/100 is 2/3, exceeding radius 1/2. Thus any non-PCI recommendation at w20 is distance-rejected regardless of other seven features or margin.',
 'w80_limit':'w80/h2000=1/25. Its coordinate-only lower bound is 1/3, not greater than 1/2. No universal rejection claim is justified for w80.',
 'actual_archived_global_config_counts':dict(collections.Counter(r['frozen_prediction']['selected_config'] for r in pred)),
 'actual_nonpci_recommendations':len(nonpci),
 'actual_all_nonpci_distance_fail_and_margin_pass':True,
 'actual_minimum_nonpci_full_distance':min(r['frozen_prediction']['standardized_distance'] for r in nonpci),
 'per_target_raw_input_check':rows,
 'source_sha256':{str(p.relative_to(ROOT)):sha(p) for p in sources},
 'raw_input_sha256':{str(p.relative_to(ROOT)):sha(p) for p in inputs},
 'scope':'Existing selector artifacts only. No experiment executed; no new prediction or model fitting; no solver, model API, LLM heldout, upload or repository operation.'}
(OUT/'window_bound_evidence.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['per_target_raw_input_check','source_sha256','raw_input_sha256']},ensure_ascii=False,indent=2))
