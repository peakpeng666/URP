"""Independent read-only audit. Stdlib only; no experiment imports or solver executions."""
import json,hashlib,math,statistics,collections,random,time,os,sys,re
from pathlib import Path
from decimal import Decimal,localcontext,ROUND_HALF_UP
P=Path('/workspace/shared/selector_distance_mechanism_run_20261007')
OUT=Path(__file__).resolve().parent
C0=time.process_time();T0=time.perf_counter()
def read(f):return json.loads((P/f).read_text())
def lines(f):return [json.loads(s) for s in (P/f).read_text().splitlines()]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def emit(f,z):(OUT/f).write_text(json.dumps(z,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def mean(v):return statistics.mean(v) if v else None
def close(a,b):return abs(a-b)<=1e-9*max(1,abs(a),abs(b))
checks=[]
def check(name,yes,detail=None):
 checks.append({'check':name,'passed':bool(yes),'detail':detail})
 if not yes:raise AssertionError((name,detail))
def parse(path):
 t=path.read_text().splitlines();i=t.index('VEHICLE');fleet,cap=map(int,t[i+2].split());ns={}
 for l in t:
  a=l.split()
  if len(a)==7 and all(re.fullmatch(r'-?\d+',x) for x in a):
   z=list(map(int,a));assert z[0] not in ns;ns[z[0]]=z[1:]
 assert list(ns)==list(range(101));return fleet,cap,ns
freeze=read('protocol/freeze.json');mut=[f for f,h in freeze['sha256'].items() if sha(P/f)!=h]
check('213 frozen scientific files unchanged',len(freeze['sha256'])==213 and not mut,mut)
check('runtime and shell receipts excluded',not any(f.startswith('runtime/') or 'shell_time' in f for f in freeze['sha256']))
check('preregistration identical',sha(P/'protocol/preregistration_zh.txt')==sha(Path('/workspace/shared/selector_distance_mechanism_prereg_20261007/preregistration_zh.txt')))
check('frozen model expected SHA',sha(P/'train/frozen_model.json')=='0e02905ba6b1c0a529a4dad060c4ff0f399709ec8ff2dfec9d80fd31ad39d900')
base=read('protocol/base_groups.json');ps=read('protocol/predictions_sealed.json');pred={p['instance']:p for p in ps};req=read('protocol/requests.json');rs=lines('raw/results.jsonl');ev=lines('raw/events.jsonl');model=read('train/frozen_model.json')
check('24 independent base groups and split',len(base)==24 and collections.Counter((x['split'],x['family']) for x in base.values())=={('C','uniform'):4,('E','uniform'):8,('C','elongated'):4,('E','elongated'):8})
check('96 cells and 576 unique requests',len(ps)==96 and len(req)==576 and len({x['run_id'] for x in req})==576)
check('unique planned slots',len({(x['instance'],x['repeat'],x['slot']) for x in req})==576)
check('all budgets and seeds fixed',all(x['budget_ms']==250 and x['seed']==2026100708 for x in req))
check('C192 E384 strict block order',[x['phase'] for x in req]==['C']*192+['E']*384)
check('physical frozen suggestion distribution',collections.Counter(x['prediction']['selected_config'] for x in ps)=={'pci250':40,'pca250':44,'sav250':12})
balance=collections.Counter((x['phase'],x['family'],x['variant'],x['width'],x['repeat'],x['slot'],x['position']) for x in req)
check('stratum A/B order balance',len(balance)==192 and all(v==(2 if k[0]=='C' else 4) for k,v in balance.items()))
for p in ps:
 row=[x for x in req if x['instance']==p['instance']];assert len(row)==6
 assert all(x['config_id']==('pci250' if x['slot']=='A' else p['prediction']['selected_config']) for x in row)
# Independently regenerate only fixed geometry/input arithmetic, never a solver.
inputs={};geom_hashes=[];customer_owners={}
for i in range(24):
 gid=f'm{i:03}';fam='uniform' if i<12 else 'elongated';seed=202610079900+10007*i;rng=random.Random(seed)
 coords=[(rng.randrange(0,101),rng.randrange(0,101)) for _ in range(100)] if fam=='uniform' else [(rng.randrange(-100,201),rng.randrange(40,61)) for _ in range(100)]
 demands=[rng.randint(1,10) for _ in range(100)];b=base[gid];assert b['seed']==seed and b['family']==fam and b['demands']==demands
 fids=[f'm{j:03}' for j in range(0 if i<12 else 12,12 if i<12 else 24)];cis=sorted(fids,key=lambda s:hashlib.sha256(('gate_mechanism_v1:split:'+s).encode()).hexdigest())[:4]
 assert b['split']==('C' if gid in cis else 'E')
 for d in ['D0','D1']:
  cc=coords if d=='D0' or fam=='uniform' else [(x-50,round(.45*(x-50)+(y-50))) for x,y in coords]
  depot=(50,50) if d=='D0' else (-25,-25) if fam=='uniform' else (0,0)
  gh=hashlib.sha256(json.dumps({'depot':list(depot),'customers':sorted([list(z) for z in cc])},sort_keys=True,separators=(',',':')).encode()).hexdigest();geom_hashes.append(gh)
  ch=tuple(sorted(cc));assert ch not in customer_owners or customer_owners[ch]==gid;customer_owners[ch]=gid
  starts={}
  for route in b['routes']:
   t=0.;prev=depot
   for n in route[1:-1]:
    xy=cc[n-1];t+=math.hypot(xy[0]-prev[0],xy[1]-prev[1]);starts[n]=t;t+=2;prev=xy
   assert t+math.hypot(prev[0]-depot[0],prev[1]-depot[1])<2000
  for w in [20,60]:
   name=f'{gid}_{d}_w{w:03}';fleet,cap,ns=parse(P/'inputs'/f'{name}.txt');inputs[name]=(fleet,cap,ns)
   assert (fleet,cap)==(10,100) and ns[0]==[*depot,0,0,2000,0]
   assert pred[name]['geometry_sha256']==gh
   for n in range(1,101):
    ready=max(0,math.floor(starts[n])-w//2);assert ns[n]==[*cc[n-1],demands[n-1],ready,ready+w,2]
check('fresh seeds, transformed coordinates, paired demands/windows and deterministic split reconstructed',True)
check('48 unique new geometry hashes',len(set(geom_hashes))==48)
old_seeds=set();old_hashes=set()
for z in read('evidence/old_geometry_reference.json'):
 check('old geometry provenance '+Path(z['path']).parent.parent.name,sha(Path(z['path']))==z['sha256'])
 old_hashes.update(z['geometry_hashes']);old_seeds.update(z['seeds'])
old_hashes.update(read('evidence/old_solomon_geometry_metadata.json')['geometry_hashes'])
check('no new geometry or seed collision with old references',not set(geom_hashes)&old_hashes and not {b['seed'] for b in base.values()}&old_seeds)
# Independent continuous schedule + 50-digit integer objective checks.
cache={}
def route_audit(ns,fleet,cap,routes,reported=None):
 visits=[];total=0.;obj=0;arcs=0;minmargin=math.inf
 assert len(routes)<=fleet
 for item in routes:
  route=item['nodes'] if isinstance(item,dict) else item;assert len(route)>=3 and route[0]==route[-1]==0 and 0 not in route[1:-1]
  assert all(type(n)==int and n in ns for n in route);visits+=route[1:-1];assert sum(ns[n][2] for n in route[1:-1])<=cap
  t=float(ns[0][3])
  for a,b in zip(route,route[1:]):
   u,v=ns[a],ns[b];s=(u[0]-v[0])**2+(u[1]-v[1])**2;leg=math.sqrt(s);total+=leg;t=max(t+u[5]+leg,v[3]);margin=v[4]-t;assert margin>=-1e-9;minmargin=min(minmargin,margin)
   if s not in cache:
    with localcontext() as ctx:ctx.prec=50;cache[s]=int((Decimal(s).sqrt()*1_000_000).to_integral_value(rounding=ROUND_HALF_UP))
   obj+=cache[s];arcs+=1
 assert collections.Counter(visits)==collections.Counter(range(1,101))
 if reported is not None:assert obj==reported and abs(obj/1e6-total)<=arcs*.5e-6+1e-9
 return total,obj,minmargin
for p in ps:
 fleet,cap,ns=inputs[p['instance']];route_audit(ns,fleet,cap,base[p['base_group']]['routes'])
trainraw=lines('train/raw_labels.jsonl');trby={(x['instance'],x['config_id']):x for x in trainraw};trainids=read('train/ids.json')
check('240 historical labels, no new training solver calls',len(trainraw)==240 and len(trby)==240 and len(trainids)==80)
valid_checks=[]
for stage,rr in [('new',rs),('historical',trainraw)]:
 for r in rr:
  if r['outcome']=='SUCCESS':
   fleet,cap,ns=inputs[r['instance']] if stage=='new' else parse(P/'train/inputs'/f"{r['instance']}.txt")
   dist,obj,margin=route_audit(ns,fleet,cap,r['routes'],r['objective_integer']);assert close(dist,r['check_summary']['distance'])
   valid_checks.append({'stage':stage,'run_id':r['run_id'],'distance':dist,'integer_objective':obj,'minimum_margin':margin})
  else:assert not r.get('assignment_returned')
check('all 96 witnesses and every returned route independently valid',True,dict(collections.Counter(x['stage'] for x in valid_checks)))
emit('independent_route_checks.json',valid_checks)
# Independent feature and nearest-neighbor arithmetic.
def feature(name,parsed):
 fleet,cap,ns=parsed;cs=[ns[i] for i in range(1,101)];h=ns[0][4]-ns[0][3];ds=[a[2] for a in cs];cx=mean([a[0] for a in cs]);cy=mean([a[1] for a in cs]);xx=mean([(a[0]-cx)**2 for a in cs]);yy=mean([(a[1]-cy)**2 for a in cs]);cov=mean([(a[0]-cx)*(a[1]-cy) for a in cs]);tr=xx+yy;rms=math.sqrt(tr)
 nn=[min(math.hypot(a[0]-b[0],a[1]-b[1]) for j,b in enumerate(cs) if i!=j) for i,a in enumerate(cs)]
 return dict(zip(model['features'],[cap/sum(ds),statistics.pstdev(ds)/mean(ds),mean([a[4]-a[3] for a in cs])/h,mean([a[5] for a in cs])/h,rms/h,mean(nn)/rms,(tr+math.sqrt((xx-yy)**2+4*cov**2))/(2*tr),math.hypot(cx-ns[0][0],cy-ns[0][1])/rms]))
for name in trainids:
 f=feature(name,parse(P/'train/inputs'/f'{name}.txt'));assert all(close(f[k],read('train/features.json')[name][k]) for k in f)
frozenfeatures=read('protocol/features.json');policies={};ruleids={'r05':.5,'r1':1.,'r2':2.,'r4':4.,'rinf':math.inf,'reject':-math.inf}
for p in ps:
 name=p['instance'];f=feature(name,inputs[name]);assert all(close(f[k],frozenfeatures[name][k]) for k in f);v=[(f[k]-model['feature_means'][k])/model['feature_scales'][k] for k in model['features']];ds={n:sum((a-b)**2 for a,b in zip(v,w)) for n,w in model['vectors'].items()};best=min(ds.values());tied=sorted(n for n,x in ds.items() if x<=best+1e-12);n=min(tied,key=lambda n:(model['labels'][n]!='pci250',n));cfg=model['labels'][n];pr=p['prediction'];assert pr['neighbor']==n and pr['selected_config']==cfg and close(pr['neighbor_squared_distance'],ds[n]);assert pr['neighbor_tie_instances']==tied
 tr=trby[n,cfg];tb=trby[n,'pci250'];margin=(tb['check_summary']['distance']-tr['check_summary']['distance'])/tb['check_summary']['distance'] if tb['outcome']==tr['outcome']=='SUCCESS' else None
 assert (margin is None and pr['neighbor_margin'] is None) or close(margin,pr['neighbor_margin'])
 contributions={k:(v[i]-model['vectors'][n][i])**2 for i,k in enumerate(model['features'])};assert all(close(x,pr['squared_distance_contributions'][k]) for k,x in contributions.items());dist=math.sqrt(ds[n]);dw=math.sqrt(max(0,ds[n]-contributions['mean_window_width_over_depot_duration']));assert close(dw,pr['distance_without_window'])
 mp=cfg!='pci250' and margin is not None and margin>=.01
 pp={'B':'pci250','G0':cfg if mp and dist<=.5 else 'pci250','GW':cfg if mp and dw<=.5 else 'pci250','GM':cfg if mp else 'pci250','RAW':cfg};pp.update({r:cfg if mp and dist<=rad else 'pci250' for r,rad in ruleids.items()});policies[name]=pp
 assert all(p['fixed'][k]['config']==pp[k] for k in ['B','G0','GW','GM','RAW']);assert all(p['candidates'][k]['config']==pp[k] for k in ruleids)
 if p['width']==20:assert dist>=2/3-1e-12 and pp['G0']=='pci250'
check('independent 8D neighbor, margin, unchanged-neighbor GW and all radius decisions',True)
check('structural w20 bound and w80 non-bound',close((.03-.01)/.03,2/3) and close((.04-.03)/.03,1/3) and (2/3)>.5 and (1/3)<.5)
check('observed results are exactly planned prefix with no duplicate retries',[r['run_id'] for r in rs]==[r['run_id'] for r in req[:len(rs)]])
starts=[x for x in ev if x['event']=='request_start'];done=[x for x in ev if x['event']=='request_done'];sf=next(x for x in ev if x['event']=='scientific_freeze');cl=next(x for x in ev if x['event']=='calibration_sealed')
check('event log contiguous', [x['sequence'] for x in ev]==list(range(len(ev))))
check('freeze hash matches logged prior freeze',sha(P/'protocol/freeze.json')==sf['sha256'])
check('calibration seal hash and sealed files',sha(P/'protocol/calibration_seal.json')==cl['sha256'] and all(sha(P/f)==h for f,h in read('protocol/calibration_seal.json')['sha256'].items()))
check('all starts after freeze; 192 C done before any E',all(x['sequence']>sf['sequence'] for x in starts) and sum(x['phase']=='C' and x['sequence']<cl['sequence'] for x in done)==192 and all(x['sequence']>cl['sequence'] for x in starts if x['phase']=='E'))
check('serial nonoverlapping request start/done',all(starts[i]['run_id']==done[i]['run_id'] and starts[i]['monotonic_ns']<done[i]['monotonic_ns']<starts[i+1]['monotonic_ns'] for i in range(len(done))))
by={r['run_id']:r for r in rs};started={r['run_id'] for r in starts};status={r['run_id']:(by[r['run_id']]['outcome'] if r['run_id'] in by else 'INTERRUPTED' if r['run_id'] in started else 'NOT_RUN_ABORT_UNKNOWN') for r in req}
ledger=[{**r,'audited_status':status[r['run_id']]} for r in req];emit('request_status_corrected_full_576.json',ledger)

def replay(split,method):
 rows=[]
 for p in ps:
  if p['split']!=split:continue
  for rep in range(3):
   n=p['instance'];cfg=policies[n][method];aid=f'{n}__r{rep}__A';sid=aid if cfg=='pci250' else f'{n}__r{rep}__B';a=by.get(aid);s=by.get(sid);av=a is not None and a['outcome']=='SUCCESS';sv=s is not None and s['outcome']=='SUCCESS';gain=(a['check_summary']['distance']-s['check_summary']['distance'])/a['check_summary']['distance'] if av and sv else None
   rows.append({'instance':n,'group':p['base_group'],'family':p['family'],'variant':p['variant'],'width':p['width'],'repeat':rep,'config':cfg,'baseline_id':aid,'selected_id':sid,'baseline_status':status[aid],'selected_status':status[sid],'baseline_valid':av,'valid':sv,'gain':gain,'both_results_available':a is not None and s is not None})
 return rows

def summary(rr):
 groups=sorted({r['group'] for r in rr});extra=[r for r in rr if r['baseline_valid'] and r['selected_status'] not in ['SUCCESS','INTERRUPTED','NOT_RUN_ABORT_UNKNOWN']];missing=[r for r in rr if not r['both_results_available']];q={g:mean([r['gain'] for r in rr if r['group']==g and r['gain'] is not None]) for g in groups};full=not extra and not missing and all(x is not None for x in q.values())
 return {'planned_observations':len(rr),'planned_cases':len({r['instance'] for r in rr}),'planned_base_groups':len(groups),'observed_policy_successes':sum(r['valid'] for r in rr),'policy_status_counts':dict(collections.Counter(r['selected_status'] for r in rr)),'baseline_status_counts':dict(collections.Counter(r['baseline_status'] for r in rr)),'paired_results_available':sum(r['both_results_available'] for r in rr),'nonpci_adoption_cases':len({r['instance'] for r in rr if r['config']!='pci250'}),'nonpci_adoption_groups':sorted({r['group'] for r in rr if r['config']!='pci250'}),'observed_extra_failure_count':len(extra),'observed_extra_failure_ids':[r['selected_id'] for r in extra],'missing_selected_or_baseline_observations':len(missing),'full_quality_defined':full,'full_equal_group_gain':mean(list(q.values())) if full else None,'common_success_count':sum(r['gain'] is not None for r in rr),'partial_conditional_equal_group_gain_diagnostic_only':mean([v for v in q.values() if v is not None]),'no_complete_E_inference':bool(split_incomplete and rr[0]['group'] in [g for g,b in base.items() if b['split']=='E'])}
split_incomplete=any(r['phase']=='E' and r['run_id'] not in by for r in req)
calcs={r:summary(replay('C',r)) for r in ruleids};eligible=[r for r,s in calcs.items() if s['observed_extra_failure_count']==0 and len(s['nonpci_adoption_groups'])>=2 and s['full_equal_group_gain'] is not None and s['full_equal_group_gain']>0]
if eligible:
 best=max(calcs[r]['full_equal_group_gain'] for r in eligible);tied=[r for r in eligible if best-calcs[r]['full_equal_group_gain']<=1e-12];chosen=min(tied,key=lambda r:(calcs[r]['nonpci_adoption_cases'],ruleids[r],r))
else:chosen='reject'
check('C-only calibration selection independently reproduced',chosen==read('protocol/calibration_selection.json')['rule']['id'],chosen)
cauthor={r['rule']['id']:r['summary'] for r in read('reports/calibration_candidates.json')}
for r,s in calcs.items():
 a=cauthor[r];assert s['observed_policy_successes']==a['successes'] and s['observed_extra_failure_count']==a['extra_failure_count'] and s['full_quality_defined']==a['full_pci_success_quality_defined'];assert s['full_equal_group_gain']==a['full_pci_success_equal_group_gain']
for d in read('protocol/test_gc_decisions.json'):assert d['decision']['config']==policies[d['instance']][chosen]
for pp in policies.values():pp['GC']=pp[chosen]
rrs={m:replay('E',m) for m in ['B','G0','GW','GM','GC','RAW']};ss={m:summary(rr) for m,rr in rrs.items()};emit('independent_calibration.json',calcs);emit('partial_E_policy_rows_full_192_each.json',rrs);emit('partial_E_summary_no_complete_quality.json',ss)
# Pure-feature paired mechanisms, independent of missing outcome rows.
paired=[]
for g,b in base.items():
 if b['split']!='E':continue
 pp=[p for p in ps if p['base_group']==g];z={'base_group':g,'family':b['family'],'metrics':{}}
 for key in ['standardized_distance','distance_without_window']+['adoption_'+m for m in ['G0','GW','GM','GC']]:
  c={(p['variant'],p['width']):(int(policies[p['instance']][key[9:]]!='pci250') if key.startswith('adoption_') else p['prediction'][key]) for p in pp}
  z['metrics'][key]={'D1_minus_D0':mean([c['D1',w]-c['D0',w] for w in [20,60]]),'w20_minus_w60':mean([c[d,20]-c[d,60] for d in ['D0','D1']]),'difference_in_differences':(c['D1',20]-c['D0',20])-(c['D1',60]-c['D0',60])}
 z['GW_minus_G0_adoption']=mean([int(policies[p['instance']]['GW']!='pci250')-int(policies[p['instance']]['G0']!='pci250') for p in pp]);paired.append(z)
emit('feature_only_paired_mechanisms.json',paired)
# Every available repeat, no best-of. Missing repeats remain explicit.
noise=[]
for p in ps:
 for slot in ['A','B']:
  obs=[by.get(f"{p['instance']}__r{i}__{slot}") for i in range(3)];ds=[r['check_summary']['distance'] for r in obs if r and r['outcome']=='SUCCESS'];noise.append({'instance':p['instance'],'split':p['split'],'slot':slot,'statuses':[status[f"{p['instance']}__r{i}__{slot}"] for i in range(3)],'valid_distances':ds,'range':max(ds)-min(ds) if ds else None,'population_sd':statistics.pstdev(ds) if ds else None})
emit('partial_repeatability_full_denominators.json',noise)
# Resource and host visibility: never infer shared-host idleness from isolated namespace.
host=lines('runtime/host_snapshots.jsonl');hs=[];commcounts=collections.Counter()
for x in host:
 for y in x['visible_process_stats']:
  s=y['stat'];comm=s[s.index('(')+1:s.index(')')];commcounts[comm]+=1;f=s[s.index(')')+2:].split()
  if comm=='python':hs.append({'run_id':x['run_id'],'utc':x['utc'],'rss_bytes':int(f[21])*4096,'virtual_bytes':int(f[20]),'process_cpu_ticks':int(f[11])+int(f[12])})
emit('host_memory_progression.json',hs)
shell=(P/'runtime/shell_time.txt').read_text();tm={k:float(v) for k,v in re.findall(r'^(real_s|user_s|sys_s) ([0-9.]+)$',shell,re.M)};receipt=read('runtime/shell_exit_receipt.json');check('sealed shell confirms partial exit137',receipt['exit_code']==137 and receipt['completed_requests']==347 and receipt['not_completed']==229 and len(rs)==347 and len(starts)==348)
check('not a demonstrated 180 second CPU-limit exhaustion',tm['user_s']+tm['sys_s']<180)
counts=collections.Counter(status.values());check('terminal denominator 347 completed +1 interrupted +228 unstarted',counts['INTERRUPTED']==1 and counts['NOT_RUN_ABORT_UNKNOWN']==228)
resources={'main_shell_cpu_s':tm['user_s']+tm['sys_s'],'main_shell_wall_s':tm['real_s'],'main_cpu_limit_s':180,'completed_search_cpu_s':sum(r['solve_cpu_s'] for r in rs),'completed_search_wall_s':sum(r['solve_wall_s'] for r in rs),'completed_model_cpu_s':sum(r['model_cpu_s'] for r in rs),'completed_checker_cpu_s':sum(r['check_cpu_s'] for r in rs),'completed_request_cpu_s':sum(r['request_cpu_s'] for r in rs),'nominal_planned_search_wall_cap_s':144,'completed_slot_nominal_cap_s':len(rs)*.25,'unaccounted_interrupted_slot_cost_and_other_main_overhead_included_in_shell':True,'feature_prediction_cpu':read('evidence/feature_prediction_cost.json'),'historical_sunk_training':read('evidence/historical_costs.json'),'post_exit':read('runtime/post_exit_integrity.json'),'host_visible_comm_counts':dict(commcounts),'host_visibility_is_namespace_limited':True,'external_ffmpeg_concurrency_disclosed_by_parent':True,'ffmpeg_not_visible_in_author_namespace_is_not_evidence_of_absence':True,'rss_first_mib':hs[0]['rss_bytes']/2**20,'rss_last_mib':hs[-1]['rss_bytes']/2**20,'memory_pressure_is_clue_not_proven_kill_cause':True,'cgroup_memory_events_unavailable_in_auditor_environment':True,'kill_cause':'unknown; no conclusive OOM, CPU cap, or launcher timeout evidence','deployment_costs':'Only a hypothetical one chosen 250ms search plus measured feature/recommendation overhead. Offline replays share physical slots and cannot be billed as independent deployments.'};emit('resource_audit.json',resources)
limitations=['SIGKILL exit137 stopped the unique run after 347/576 completed slots. No restart, no complete E comparison, no complete E quality/CI/positive signal.','Frozen after_exit.py incorrectly labels all unstarted requests as NOT_RUN_BUDGET whenever exit137 or152. Retain raw record and use explicit erratum: 1 INTERRUPTED,228 NOT_RUN_ABORT_UNKNOWN.','G0 and GW choose PCI on all96 cases: deleting the window component did not restore any adoption; this branch has zero active support. w20 lower bound2/3 is structural; w80 lower bound1/3 is not mandatory rejection.','C-only r1 selection is reproducible, but C8 groups and optimistic tuning score are not a safety or generalization result.','Substantial RSS growth57MiB to2157MiB suggests resource pressure. Kill cause is not established.','Main host process visibility is isolated; external ffmpeg concurrency disclosed by parent remains a confounder even though not present in snapshots.','No solver reruns, candidate calls, third-party sends or author-file writes by this audit.']
summaryout={'audit_result':'PARTIAL_RUN_PROTOCOL_FAILURE_NO_COMPLETE_E_INFERENCE','checks_passed':len(checks),'scientific_mutations':mut,'completed':len(rs),'started':len(starts),'planned':len(req),'corrected_full_status_counts':dict(counts),'phase_completed':dict(collections.Counter(r['phase'] for r in rs)),'chosen_C_radius_rule':chosen,'calibration_score':calcs[chosen]['full_equal_group_gain'],'E_summaries':ss,'limitations':limitations,'resources':resources};emit('audit_summary.json',summaryout);emit('checks.json',checks)
report=['独立审计结论：运行中断；不得作完整E主结论。','',f'唯一预定576槽，实际347完成（C192/E155）、1开始后中断、228未启动。Shell exit137，wall {tm["real_s"]}秒，CPU {tm["user_s"]+tm["sys_s"]:.3f}秒<180秒。终止原因未知。',f'213项科学冻结SHA全部匹配。96输入、24独立基础组（C8/E16）、变换/需求/窗口、固定8D近邻与门控、3重复双槽计划、192个C完成后锁r1再开始E均独立核对。{len(valid_checks)}条成功轨迹（新结果与历史训练）和96条见证均通过独立连续可行性及50位Decimal整数目标核验。',f'C只选r1，校准完整成功96/96，零额外失败，采用3题/2组；校准等组分数{calcs[chosen]["full_equal_group_gain"]*100:.6f}%，仅阈值选择。','G0/GW全部96题均退化PCI，GW恢复采用支持组=0。保留w20必拒结构证明；不能称去掉窗宽门已恢复收益。','']
for m,s in ss.items():report.append(f'{m}：预定E192观测/64题/16组；已观察成功{s["observed_policy_successes"]}；状态{s["policy_status_counts"]}；可用成对观测{s["paired_results_available"]}；已观察额外失败{s["observed_extra_failure_count"]}；完整质量未定义。')
report+=['','重要修正与边界：']+['- '+x for x in limitations]+['','审计自身使用标准库只读重算，不导入作者程序或ORTools，不执行任何solver/candidate。审计计算费用另记audit_cost.json。']
(OUT/'audit_report_zh.txt').write_text('\n'.join(report)+'\n');emit('audit_cost.json',{'audit_process_cpu_s':time.process_time()-C0,'audit_wall_s':time.perf_counter()-T0,'solver_calls':0,'candidate_calls':0,'outside_main_180s':True,'earlier_read_only_inspection_tool_times_not_in_this_process_timer':True,'monetary_cost_unavailable_not_reported_as_zero':True});emit('audit_manifest.json',{x.name:sha(x) for x in OUT.iterdir() if x.is_file() and x.name!='audit_manifest.json'})
print(json.dumps({'audit_result':summaryout['audit_result'],'checks':len(checks),'completed':len(rs),'new_success_rechecked':sum(x['stage']=='new' for x in valid_checks),'historical_success_rechecked':sum(x['stage']=='historical' for x in valid_checks),'status_counts':dict(counts),'C_rule':chosen,'E':ss,'audit_cost':json.loads((OUT/'audit_cost.json').read_text())},ensure_ascii=False))
