"""Independent read-only supplemental audit; no solver imports or execution."""
import json,hashlib,random,math,time,ast,collections
from pathlib import Path
C=time.process_time();T=time.perf_counter();P=Path('/workspace/shared/selector_distance_mechanism_run_20261007');A=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text())
write=lambda p,x:p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
ps=read(P/'protocol/predictions_sealed.json');base=read(P/'protocol/base_groups.json');qs=read(P/'protocol/requests.json');rules=read(P/'protocol/test_gc_decisions.json')
# Reproduce the predeclared randomized schedule from fresh PRNG state.
rng=random.Random(202610079901);expected=[]
for split in ['C','E']:
 for rep in range(3):
  pairs=[]
  for fam in ['uniform','elongated']:
   for d in ['D0','D1']:
    for w in [20,60]:
     rows=sorted((p for p in ps if p['split']==split and p['family']==fam and p['variant']==d and p['width']==w),key=lambda p:p['instance']);rng.shuffle(rows)
     for pos,p in enumerate(rows):pairs.append((p,['A','B'] if pos<len(rows)//2 else ['B','A']))
  rng.shuffle(pairs)
  for p,order in pairs:
   for pos,slot in enumerate(order):expected.append((p['instance'],rep,slot,pos))
assert expected==[(q['instance'],q['repeat'],q['slot'],q['position']) for q in qs]
# Reproduce D0 angular capacity chunks and NN witness order, with no routing solver.
for i in range(24):
 rng=random.Random(202610079900+10007*i);xy=[(rng.randrange(0,101),rng.randrange(0,101)) for _ in range(100)] if i<12 else [(rng.randrange(-100,201),rng.randrange(40,61)) for _ in range(100)];dem=[rng.randint(1,10) for _ in range(100)]
 order=sorted(range(1,101),key=lambda n:(math.atan2(xy[n-1][1]-50,xy[n-1][0]-50),math.hypot(xy[n-1][0]-50,xy[n-1][1]-50),n));chunks=[];c=[];load=0
 for n in order:
  if load+dem[n-1]>100:chunks.append(c);c=[];load=0
  c.append(n);load+=dem[n-1]
 if c:chunks.append(c)
 routes=[]
 for chunk in chunks:
  todo=set(chunk);route=[0];point=(50,50)
  while todo:
   n=min(todo,key=lambda n:((xy[n-1][0]-point[0])**2+(xy[n-1][1]-point[1])**2,n));todo.remove(n);route.append(n);point=xy[n-1]
  routes.append(route+[0])
 assert routes==base[f'm{i:03}']['routes']
# Cross-check author corrected ledger against independent identifiers/statuses.
ours=read(A/'request_status_corrected_full_576.json');missing={r['run_id']:r['audited_status'] for r in ours if r['audited_status'] in ['INTERRUPTED','NOT_RUN_ABORT_UNKNOWN']};their=read(P/'runtime/not_completed_corrected.json')
assert len(their)==229 and {r['run_id'] for r in their}==set(missing)
assert all(('INTERRUPTED' if r.get('terminal_status',r.get('status'))=='INTERRUPTED' else 'NOT_RUN_ABORT_UNKNOWN')==missing[r['run_id']] for r in their)
# Static callback lifetime clue; never invoke source.
tree=ast.parse((P/'source/core.py').read_text());solve=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='solve');callback=next(n for n in solve.body if isinstance(n,ast.FunctionDef) and n.name=='callback');refs=sorted({n.id for n in ast.walk(callback) if isinstance(n,ast.Name)});assert 'routing' in refs
support=[r for r in rules if r['decision']['config']!='pci250'];ng=sorted({r['base_group'] for r in support});assert len(support)==6 and len(ng)==3
assert all(p['fixed'][m]['config']=='pci250' for p in ps for m in ['G0','GW'])
launch=read(P/'runtime/launcher_tool_call_evidence.json')
z={'checks':['all 576 randomized schedule tuples reproduced exactly','all24 original witness routes independently reconstructed','author corrected229 missing request IDs and classifications consistent','frozen GC E support6cases3groups, below4-group preregistered criterion','G0/GW all96 cases choose PCI'],'GC_support_groups':ng,'GC_nonPCI_cases':[r['instance'] for r in support],'no_E_quality_CI_calculated_due_incomplete_run':True,'launcher_evidence':{'source':'author-copied tool arguments/metadata; not independent backend kill telemetry','path':'runtime/launcher_tool_call_evidence.json','sha256':hashlib.sha256((P/'runtime/launcher_tool_call_evidence.json').read_bytes()).hexdigest(),'session_id':launch['launch']['result']['session_id'],'no_explicit_timeout_or_termination_shown':not launch['explicit_timeout_argument_sent'] and not launch['explicit_termination_or_ctrl_c_sent'],'cause_remains_unknown':True},'memory_static_diagnosis':{'source':'source/core.py lines51-79','sha256':hashlib.sha256((P/'source/core.py').read_bytes()).hexdigest(),'callback_refers_to_routing':True,'routing_registers_callback':True,'hypothesis':'AddAtSolutionCallback closure captures routing. A RoutingModel→callback→RoutingModel retention cycle across SWIG/C++ and Python, or native allocation retention, is plausible. Transit callbacks also capture data/matrices. No lifetime experiment was run, so no leak or OOM attribution is proven.','stored_result_size_context':'raw/results.jsonl approximately2.3MiB; route result data alone does not explain2157MiB RSS','next_engineering_checks_only':['Use new non-scientific toy objects to measure RSS and construction/destruction with the identical callback pattern. Do not rerun the interrupted scientific samples.','Explicitly examine callback/manager/model lifetime and native destruction; gc.collect alone is not a guaranteed fix for C++ callback retention.','If each search slot uses an isolated subprocess, preserve serial preregistered slot ordering and include launch/build/checker costs. Enforce aggregate parent-plus-all-child CPU; parent process_time and a per-child RLIMIT are not an aggregate180-second budget.','A new prospective scientific run needs a new explicit protocol and fresh unobserved evaluation samples; preserve this interrupted run and its already-seen results.']},'audit_cpu_s':time.process_time()-C,'audit_wall_s':time.perf_counter()-T,'solver_calls':0,'candidate_calls':0}
write(A/'supplemental_checks_and_memory_diagnosis.json',z)
report=A/'audit_report_zh.txt';text=report.read_text();text+='\n补充核验：576槽随机顺序及24组D0见证顺序均独立从种子重建一致。作者229缺失项纠正账本与独审一致。\nGC封存E决策为6题/3基础组（m011、m015、m022）非PCI采用，低于预注册4组最低支持门槛；即使没有中断，也不能达到预定正信号标准。\nE中GC已观察成功76、B成功75的差异含GC有结果而配对B中断的槽，绝不是一例经确认的GC救回成功；禁止比较这些不齐分母。\n内存只读诊断：源码callback引用routing，可能存在RoutingModel与Python回调跨边界保留。仅为待验证假设，不能等同OOM原因。下一轮先用独立toy验证生命周期；如改每槽进程隔离，须累计所有子进程CPU并另预注册总预算。\n';report.write_text(text)
cost=read(A/'audit_cost.json');cost['supplement_cpu_s']=z['audit_cpu_s'];cost['supplement_wall_s']=z['audit_wall_s'];cost['sum_successful_audit_process_cpu_s']=cost['audit_process_cpu_s']+z['audit_cpu_s'];cost['sum_successful_audit_wall_s']=cost['audit_wall_s']+z['audit_wall_s'];cost['one_initial_audit_assertion_was_corrected']='Auditor expected96 schedule strata; correct count192. Failed checker invocation had0.02094s shell wall, CPU not separately captured. No author-file changes or solver calls.';write(A/'audit_cost.json',cost)
summary=read(A/'audit_summary.json');summary['audit_result']='INTERRUPTED_NO_COMPLETE_E_INFERENCE';summary['preregistered_GC_minimum_support_met']=False;summary['GC_frozen_E_support_groups']=ng;summary['author_missing_request_erratum_verified']=True;write(A/'audit_summary.json',summary)
write(A/'audit_manifest.json',{x.name:hashlib.sha256(x.read_bytes()).hexdigest() for x in A.iterdir() if x.is_file() and x.name!='audit_manifest.json'})
print(json.dumps({'supplement':'PASS','GC_support_groups':ng,'cost':cost},ensure_ascii=False))
