探索性几何留一配置选择离线分析

先读 reports/report_zh.txt；全部56预测保留在 reports/predictions_all56.csv。
本目录为新隔离产物；未改旧档、未求解、未调用模型、未安装、未上传。
复算时将本包复制到新空目录，只保留 source/；通过环境变量 SELECTION_ARCHIVE 与 SELECTION_INPUTS 指向有权限的原档案及56原输入，然后运行 python3 source/supervise.py。
原实例不在ZIP中；需依据 protocol/input_manifest.json 的来源身份在授权范围获取，校验原始SHA256。
不要删除本次freeze后原地覆盖。参数及规则仅一个版本，不存在隐含调参。
完整测量与分项见 evidence/resource_accounting.json；原CPU/wall表示历史run的记录，不是新运行。
