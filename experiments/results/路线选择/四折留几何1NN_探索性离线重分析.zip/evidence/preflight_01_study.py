"""One frozen exploratory leave-one-geometry-out reanalysis; Python stdlib only.

No solver imports, network calls, outcome-driven retries, or input-directory writes.
"""
import resource
resource.setrlimit(resource.RLIMIT_CPU, (8, 8))
import collections
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import re
import statistics
import sys
import time
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent.parent
ARCHIVE = Path(os.environ.get('SELECTION_ARCHIVE', '/workspace/shared/solver_portfolio_headroom_20261007'))
INPUTS = Path(os.environ.get('SELECTION_INPUTS', '/workspace/shared/public_vrptw_benchmark_20261007/inputs'))
CONFIGS = ['pci250', 'pca250', 'sav250']
FEATURES = ['capacity_over_total_demand', 'demand_population_cv',
            'mean_window_width_over_depot_duration', 'mean_service_over_depot_duration']
COST_TOL = 1e-6
DISTANCE2_TOL = 1e-12
START_WALL = time.perf_counter()
START_CPU = time.process_time()


def utc():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def write(relative, value):
    (ROOT / relative).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')


def csvwrite(relative, rows):
    with (ROOT / relative).open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def avg(values):
    return statistics.mean(values) if values else None


def parse_features(path):
    # Independent input-only parser. The instance identifier is audit metadata only.
    lines = path.read_text().splitlines()
    index = next(i for i, line in enumerate(lines) if line.strip() == 'VEHICLE')
    fleet, capacity = map(int, lines[index + 2].split())
    nodes = []
    for line in lines:
        tokens = line.split()
        if len(tokens) == 7 and all(re.fullmatch(r'-?\d+', token) for token in tokens):
            nodes.append(list(map(int, tokens)))
    assert [row[0] for row in nodes] == list(range(101))
    depot, customers = nodes[0], nodes[1:]
    duration = depot[5] - depot[4]
    demands = [row[3] for row in customers]
    assert duration > 0 and sum(demands) > 0 and capacity > 0 and fleet > 0
    return {
        'instance': path.stem,
        'geometry_sha256': digest({'depot': depot[1:3], 'customers': sorted(row[1:3] for row in customers)}),
        'capacity_over_total_demand': capacity / sum(demands),
        'demand_population_cv': statistics.pstdev(demands) / avg(demands),
        'mean_window_width_over_depot_duration': avg([row[5] - row[4] for row in customers]) / duration,
        'mean_service_over_depot_duration': avg([row[6] for row in customers]) / duration,
    }


def prepare_and_freeze():
    assert not (ROOT / 'protocol/freeze.json').exists(), 'Never overwrite a frozen analysis.'
    manifest = json.loads((ARCHIVE / 'protocol/input_manifest.json').read_text())
    existing_features = {row['instance']: row for row in json.loads((ARCHIVE / 'protocol/instance_features.json').read_text())}
    assert len(manifest) == 56
    features, identities = [], []
    for row in sorted(manifest, key=lambda item: item['name']):
        path = INPUTS / row['name']
        assert sha(path) == row['sha256'], row['name']
        feature = parse_features(path)
        assert feature['geometry_sha256'] == existing_features[feature['instance']]['geometry_sha256']
        features.append(feature)
        identities.append({key: row[key] for key in ['name', 'sha256', 'bytes', 'semantic_sha256', 'encoded_sha256', 'source_drive_id', 'source_drive_url']})
    groups = collections.defaultdict(list)
    for row in features:
        groups[row['geometry_sha256']].append(row['instance'])
    assert len(groups) == 4
    names = sorted(row['instance'] for row in features)
    folds = [{'fold': i + 1, 'test_geometry_sha256': group, 'test_instances': groups[group],
              'train_instances': sorted(set(names) - set(groups[group])),
              'n_test': len(groups[group]), 'n_train': len(names) - len(groups[group])}
             for i, group in enumerate(sorted(groups))]
    protocol = {
        'study_id': 'EXPLORATORY_ARCHIVE_LO_GEO_1NN_V1',
        'scope': 'Exploratory leave-one-geometry-out reanalysis of already observed archived outputs, not newly collected heldout data or an external test.',
        'prior_knowledge': 'Parent disclosed 56 instances, four geometries, approximately 2.61% aggregate in-sample oracle headroom, and seven PCA timeouts before this protocol. This is not a prospective blind preregistration.',
        'before_run': 'No numerical archived outcomes read for this selector before this freeze; source schema, prior protocol, feature/group metadata and the disclosed summary were inspected. Hashing outcome files treats their bytes as opaque.',
        'candidates': CONFIGS,
        'excluded': 'PCI750 is not a selector candidate. No spatial features, family labels, names, hash values, test costs or test failure indicators as model inputs.',
        'features_in_order': FEATURES,
        'feature_definitions': {
            FEATURES[0]: 'Vehicle capacity / sum of customer demands.',
            FEATURES[1]: 'Population standard deviation of customer demand / mean customer demand.',
            FEATURES[2]: 'Mean(customer due - ready) / (depot due - ready).',
            FEATURES[3]: 'Mean customer service duration / (depot due - ready).'},
        'folds': 'Leave one complete coordinate hash out. Hash JSON has separate depot coordinates and sorted full multiset of all 100 customer coordinate pairs; IDs omitted. Full hashes only determine folds.',
        'scaling': 'Per fold, compute population mean and population standard deviation on training instances only. Zero standard deviation replaced by 1. No global fitting or feature choice.',
        'classifier': 'Exactly k=1 nearest neighbor, squared Euclidean distance in the four training-standardized features. No fitting hyperparameters, tuning, feature ablations, gates, or fallback.',
        'training_sbs': 'Maximize successful valid archive count on training only; among maximum-coverage configs minimize mean ratio to training per-instance valid VBS on their common-valid intersection. If empty, fixed config order. Exact score ties use config order.',
        'training_labels': 'For each training instance choose best legal archived continuous distance. Values within absolute 1e-6 of minimum tie: training SBS first if among tied configs, then fixed config order. If no legal training config, exclude that instance as a neighbor and disclose; all train features still determine scaling. If none labelable, output training SBS.',
        'neighbor_ties': 'Squared distances within absolute 1e-12 of minimum: prefer training neighbors whose label equals training SBS, then lexicographic instance ID. ID only resolves an exact/tolerance tie; never used as a numeric/categorical feature.',
        'prediction_isolation': 'Fitting function receives only fold training outcomes/features; predictor receives only fitted training model and the four test features. All 56 choices written and hashed before any test scoring routine executes. Outcome archive already contains every fold; code-level per-fold separation is not an external blind test.',
        'failure_policy': 'No numerical failure penalty; failed selected outcome stays failed, distance and ratios null. No free fallback and no second run. Primary report success/failure counts on all 56 alongside common-valid quality metrics.',
        'primary_quality': 'Compare selector with training-fold SBS on the common-valid subset: mean per-instance relative cost change (selector/SBS-1)*100; also sum-distance reduction (1-sum selector/sum SBS)*100. Primary failure difference is separate and takes priority; do not declare an all-instance gain from a successful subset.',
        'oracle': 'Post-prediction minimum legal cost among the three 250ms archived outputs. Descriptive oracle, not optimum or executable single-run policy. Oracle gaps and captured headroom only on clearly reported common-valid subsets; no omission of failures in the main 56-row table.',
        'per_geometry': 'Report n_train/n_test, failures, coverage, paired quality, better/tied/worse counts and every positive/negative instance relative to fold SBS. Four geometry units cannot establish significance or generalization to all agricultural VRPs.',
        'runtime': 'Offline simulate choosing exactly one existing 250ms run. Quote its archived run_id and measured accounted/solve CPU and wall time. Current feature/training/prediction/analysis CPU measured separately; no deployment speed or newly executed solver claims.',
        'budget': 'At most 10 CPU seconds: child process RLIMIT_CPU 8 seconds, supervisor RLIMIT_CPU 1 second; measure child+supervisor including packaging. Inspection/authoring shell calls are not solver/computational experiment time.',
        'distribution': 'Clean ZIP excludes original raw instances, routes, full coordinates, virtual environments, caches, credentials. Includes source hashes, private Drive source identifiers, features, summarized archived outcomes, predictions, fold training audits and reports. No upload.',
        'no_execution': 'Zero new solves, zero model/API calls, zero installations, zero writes to old archive or original input files.',
    }
    write('protocol/input_manifest.json', identities)
    write('protocol/features.json', features)
    write('protocol/folds.json', folds)
    write('protocol/protocol.json', protocol)
    sources = ['protocol/input_manifest.json', 'protocol/instance_features.json', 'protocol/shared_geometry.json',
               'protocol/freeze.json', 'raw/results.jsonl', 'raw/continuous_checks.jsonl',
               'source/study.py', 'source/checker.py', 'evidence/verification.json']
    source_identity = {name: {'sha256': sha(ARCHIVE / name), 'bytes': (ARCHIVE / name).stat().st_size} for name in sources}
    write('protocol/archive_identity.json', source_identity)
    frozen_names = ['source/study.py', 'source/supervise.py', 'protocol/protocol.json', 'protocol/input_manifest.json',
                    'protocol/features.json', 'protocol/folds.json', 'protocol/archive_identity.json']
    write('protocol/freeze.json', {
        'frozen_utc': utc(), 'predictions_before_freeze': 0, 'selector_evaluations_before_freeze': 0,
        'source_input_count': 56, 'geometry_fold_count': 4, 'feature_count': 4,
        'sha256': {name: sha(ROOT / name) for name in frozen_names}})
    print('FROZEN ' + sha(ROOT / 'protocol/freeze.json'), flush=True)
    return features, folds


def load_outcomes():
    result = {}
    for line_number, line in enumerate((ARCHIVE / 'raw/results.jsonl').read_bytes().splitlines(), 1):
        row = json.loads(line)
        if row['config_id'] not in CONFIGS:
            continue
        key = (row['instance'], row['config_id'])
        assert key not in result
        valid = row['outcome'] == 'SUCCESS'
        check = row.get('check_summary', {})
        if valid:
            assert check['valid'] and check['distance'] > 0 and not check['errors']
        result[key] = {
            'instance': row['instance'], 'config': row['config_id'], 'run_id': row['run_id'],
            'outcome': row['outcome'], 'valid': valid, 'distance': check['distance'] if valid else None,
            'nominal_search_ms': row['budget_ms'],
            'archived_accounted_cpu_s': row['request_accounted_cpu_s'],
            'archived_accounted_wall_s': row['request_accounted_wall_s'],
            'archived_solve_cpu_s': row.get('solve_cpu_s'), 'archived_solve_wall_s': row.get('solve_wall_s'),
            'source_line': line_number, 'source_line_sha256': hashlib.sha256(line).hexdigest(),
        }
        assert row['budget_ms'] == 250
    assert len(result) == 168
    write('raw/archive_outcome_extract.json', list(result.values()))
    return result


def fit(train_features, train_outcomes):
    names = sorted(train_features)
    assert set(train_outcomes) == {(name, config) for name in names for config in CONFIGS}
    coverage = {config: sum(train_outcomes[name, config]['valid'] for name in names) for config in CONFIGS}
    candidates = [config for config in CONFIGS if coverage[config] == max(coverage.values())]
    oracle = {name: min([train_outcomes[name, config]['distance'] for config in CONFIGS
                        if train_outcomes[name, config]['valid']], default=None) for name in names}
    common = [name for name in names if all(train_outcomes[name, config]['valid'] for config in candidates)]
    scores = {config: avg([train_outcomes[name, config]['distance'] / oracle[name] for name in common]) for config in candidates}
    sbs = min(candidates, key=lambda config: (scores[config] if common else 0, CONFIGS.index(config)))
    means = {feature: avg([train_features[name][feature] for name in names]) for feature in FEATURES}
    stds = {feature: statistics.pstdev([train_features[name][feature] for name in names]) for feature in FEATURES}
    scales = {feature: stds[feature] or 1.0 for feature in FEATURES}
    labels = {}
    skipped = []
    for name in names:
        if oracle[name] is None:
            skipped.append(name)
            continue
        tied = [config for config in CONFIGS if train_outcomes[name, config]['valid'] and
                train_outcomes[name, config]['distance'] <= oracle[name] + COST_TOL]
        labels[name] = min(tied, key=lambda config: (config != sbs, CONFIGS.index(config)))
    vectors = {name: [(train_features[name][feature] - means[feature]) / scales[feature] for feature in FEATURES]
               for name in labels}
    return {'train_instances': names, 'coverage': coverage, 'sbs': sbs,
            'sbs_score_common_instances': common, 'sbs_scores': scores,
            'feature_means': means, 'feature_population_stds': stds, 'feature_scales': scales,
            'labels': labels, 'skipped_unlabelable_training_instances': skipped, 'vectors': vectors}


def predict(model, test_vector):
    # This function cannot inspect outcomes, test ID, geometry hash, or family.
    assert len(test_vector) == len(FEATURES)
    vector = [(test_vector[j] - model['feature_means'][feature]) / model['feature_scales'][feature]
              for j, feature in enumerate(FEATURES)]
    distance2 = {name: sum((left - right) ** 2 for left, right in zip(vector, value))
                 for name, value in model['vectors'].items()}
    if not distance2:
        return {'selected_config': model['sbs'], 'neighbor': None, 'neighbor_squared_distance': None,
                'neighbor_tie_count': 0, 'neighbor_tie_instances': []}
    best = min(distance2.values())
    tied = sorted(name for name, value in distance2.items() if value <= best + DISTANCE2_TOL)
    neighbor = min(tied, key=lambda name: (model['labels'][name] != model['sbs'], name))
    return {'selected_config': model['labels'][neighbor], 'neighbor': neighbor,
            'neighbor_squared_distance': distance2[neighbor], 'neighbor_tie_count': len(tied),
            'neighbor_tie_instances': tied}


def primary_summary(rows):
    common = [row for row in rows if row['selected_valid'] and row['sbs_valid']]
    all_oracle_common = [row for row in common if row['oracle_valid']]
    selected_sum = sum(row['selected_distance'] for row in common)
    sbs_sum = sum(row['sbs_distance'] for row in common)
    oracle_sum = sum(row['oracle_distance'] for row in all_oracle_common)
    better = [row['instance'] for row in common if row['selected_distance'] < row['sbs_distance'] - COST_TOL]
    worse = [row['instance'] for row in common if row['selected_distance'] > row['sbs_distance'] + COST_TOL]
    ties = [row['instance'] for row in common if abs(row['selected_distance'] - row['sbs_distance']) <= COST_TOL]
    return {
        'n_all': len(rows), 'selected_successes': sum(row['selected_valid'] for row in rows),
        'selected_failures': sum(not row['selected_valid'] for row in rows),
        'selected_coverage_pct': 100 * sum(row['selected_valid'] for row in rows) / len(rows),
        'sbs_successes': sum(row['sbs_valid'] for row in rows), 'sbs_failures': sum(not row['sbs_valid'] for row in rows),
        'sbs_coverage_pct': 100 * sum(row['sbs_valid'] for row in rows) / len(rows),
        'oracle_successes': sum(row['oracle_valid'] for row in rows),
        'selected_failure_instances': [row['instance'] for row in rows if not row['selected_valid']],
        'selected_failure_with_sbs_success_instances': [row['instance'] for row in rows if not row['selected_valid'] and row['sbs_valid']],
        'selected_success_with_sbs_failure_instances': [row['instance'] for row in rows if row['selected_valid'] and not row['sbs_valid']],
        'both_failures': sum(not row['selected_valid'] and not row['sbs_valid'] for row in rows),
        'common_valid_n': len(common), 'better_n': len(better), 'tied_n': len(ties), 'worse_n': len(worse),
        'better_instances': better, 'tied_instances': ties, 'worse_instances': worse,
        'selected_cost_common_sum': selected_sum, 'sbs_cost_common_sum': sbs_sum,
        'mean_relative_selected_vs_sbs_pct': avg([100 * (row['selected_distance'] / row['sbs_distance'] - 1) for row in common]),
        'sum_distance_reduction_selected_vs_sbs_pct': 100 * (1 - selected_sum / sbs_sum) if sbs_sum else None,
        'oracle_common_n': len(all_oracle_common), 'oracle_cost_common_sum': oracle_sum,
        'mean_selected_gap_to_oracle_pct_common': avg([100 * (row['selected_distance'] / row['oracle_distance'] - 1) for row in all_oracle_common]),
        'mean_sbs_gap_to_oracle_pct_common': avg([100 * (row['sbs_distance'] / row['oracle_distance'] - 1) for row in all_oracle_common]),
        'oracle_sum_headroom_vs_sbs_pct_common': 100 * (1 - oracle_sum / sbs_sum) if sbs_sum else None,
        'captured_oracle_distance_headroom_fraction_common': (sbs_sum - selected_sum) / (sbs_sum - oracle_sum) if sbs_sum - oracle_sum > COST_TOL else None,
        'selected_archived_accounted_cpu_s_all': sum(row['selected_archived_accounted_cpu_s'] for row in rows),
        'selected_archived_accounted_wall_s_all': sum(row['selected_archived_accounted_wall_s'] for row in rows),
        'sbs_archived_accounted_cpu_s_all': sum(row['sbs_archived_accounted_cpu_s'] for row in rows),
        'sbs_archived_accounted_wall_s_all': sum(row['sbs_archived_accounted_wall_s'] for row in rows),
        'selected_config_counts': dict(collections.Counter(row['selected_config'] for row in rows)),
    }


def main():
    features, folds = prepare_and_freeze()
    outcomes = load_outcomes()
    by_feature = {row['instance']: row for row in features}
    predictions, models = [], []
    cp0, wp0 = time.process_time(), time.perf_counter()
    for fold in folds:
        train_set = set(fold['train_instances'])
        test_set = set(fold['test_instances'])
        assert not train_set & test_set
        model = fit({name: by_feature[name] for name in train_set},
                    {key: value for key, value in outcomes.items() if key[0] in train_set})
        models.append({'fold': fold['fold'], **model})
        for name in fold['test_instances']:
            prediction = predict(model, [by_feature[name][feature] for feature in FEATURES])
            assert prediction['neighbor'] is None or prediction['neighbor'] in train_set
            predictions.append({'instance': name, 'fold': fold['fold'], 'geometry_sha256': fold['test_geometry_sha256'],
                                'n_train': fold['n_train'], 'n_test': fold['n_test'],
                                'fold_sbs_config': model['sbs'], **prediction})
    selection_cpu, selection_wall = time.process_time() - cp0, time.perf_counter() - wp0
    assert len(predictions) == 56 and len({row['instance'] for row in predictions}) == 56
    predictions.sort(key=lambda row: row['instance'])
    write('raw/predictions_before_scoring.json', predictions)
    write('raw/training_models.json', models)
    write('evidence/predictions_sealed.json', {'sealed_utc': utc(), 'test_scoring_started': False,
        'prediction_sha256': sha(ROOT / 'raw/predictions_before_scoring.json'),
        'model_sha256': sha(ROOT / 'raw/training_models.json'), 'n_predictions': 56})
    print('PREDICTIONS SEALED ' + sha(ROOT / 'raw/predictions_before_scoring.json'), flush=True)
    scored = []
    for prediction in predictions:
        name = prediction['instance']
        selected = outcomes[name, prediction['selected_config']]
        sbs = outcomes[name, prediction['fold_sbs_config']]
        legal = [outcomes[name, config] for config in CONFIGS if outcomes[name, config]['valid']]
        oracle = min(legal, key=lambda row: (row['distance'], CONFIGS.index(row['config']))) if legal else None
        row = {key: value for key, value in prediction.items() if key != 'neighbor_tie_instances'}
        row.update({'selected_run_id': selected['run_id'], 'selected_outcome': selected['outcome'],
                    'selected_valid': selected['valid'], 'selected_failed': not selected['valid'],
                    'selected_distance': selected['distance'], 'sbs_run_id': sbs['run_id'],
                    'sbs_outcome': sbs['outcome'], 'sbs_valid': sbs['valid'], 'sbs_distance': sbs['distance'],
                    'oracle_valid': oracle is not None, 'oracle_config': oracle['config'] if oracle else None,
                    'oracle_distance': oracle['distance'] if oracle else None,
                    'selected_vs_sbs_pct': 100 * (selected['distance'] / sbs['distance'] - 1) if selected['valid'] and sbs['valid'] else None,
                    'selected_gap_to_oracle_pct': 100 * (selected['distance'] / oracle['distance'] - 1) if selected['valid'] and oracle else None,
                    'sbs_gap_to_oracle_pct': 100 * (sbs['distance'] / oracle['distance'] - 1) if sbs['valid'] and oracle else None,
                    'selected_archived_accounted_cpu_s': selected['archived_accounted_cpu_s'],
                    'selected_archived_accounted_wall_s': selected['archived_accounted_wall_s'],
                    'selected_archived_solve_cpu_s': selected['archived_solve_cpu_s'],
                    'selected_archived_solve_wall_s': selected['archived_solve_wall_s'],
                    'sbs_archived_accounted_cpu_s': sbs['archived_accounted_cpu_s'],
                    'sbs_archived_accounted_wall_s': sbs['archived_accounted_wall_s'],
                    'selected_source_line': selected['source_line'], 'selected_source_line_sha256': selected['source_line_sha256']})
        scored.append(row)
    summary = primary_summary(scored)
    per_fold = []
    for fold in folds:
        subset = [row for row in scored if row['fold'] == fold['fold']]
        per_fold.append({**fold, 'fold_sbs_config': subset[0]['fold_sbs_config'], **primary_summary(subset)})
    # Reproduce old in-sample headroom for scale, never used to choose a fold policy.
    full_model = fit(by_feature, outcomes)
    global_sbs = full_model['sbs']
    global_pairs = [(outcomes[row['instance'], global_sbs]['distance'], row['oracle_distance']) for row in scored
                    if outcomes[row['instance'], global_sbs]['valid'] and row['oracle_valid']]
    descriptive = {'warning': 'Post-scoring reproduction only, not a heldout policy or evidence of predictability.',
                   'global_in_sample_sbs': global_sbs, 'common_valid_n': len(global_pairs),
                   'sum_distance_oracle_reduction_vs_sbs_pct': 100 * (1 - sum(b for a, b in global_pairs) / sum(a for a, b in global_pairs)),
                   'mean_sbs_gap_to_oracle_pct': avg([100 * (a / b - 1) for a, b in global_pairs])}
    write('reports/predictions_all56.json', scored)
    csvwrite('reports/predictions_all56.csv', scored)
    write('reports/summary.json', summary)
    write('reports/per_geometry.json', per_fold)
    csvwrite('reports/per_geometry.csv', [{key: value for key, value in row.items() if not isinstance(value, (dict, list))} for row in per_fold])
    write('reports/descriptive_oracle_context.json', descriptive)
    # Frozen hash checks, input immutability, and prediction isolation assertions.
    frozen = json.loads((ROOT / 'protocol/freeze.json').read_text())
    for name, expected in frozen['sha256'].items():
        assert sha(ROOT / name) == expected, name
    for name, expected in json.loads((ROOT / 'protocol/archive_identity.json').read_text()).items():
        assert sha(ARCHIVE / name) == expected['sha256'], name
    for identity in json.loads((ROOT / 'protocol/input_manifest.json').read_text()):
        assert sha(INPUTS / identity['name']) == identity['sha256']
    for row in scored:
        if row['selected_failed']:
            assert row['selected_distance'] is None and row['selected_gap_to_oracle_pct'] is None
    # Prediction replay uses only frozen models and input features, not scored outcomes.
    models_by_fold = {model['fold']: model for model in models}
    for row in predictions:
        again = predict(models_by_fold[row['fold']], [by_feature[row['instance']][feature] for feature in FEATURES])
        assert all(row[key] == value for key, value in again.items())
    write('evidence/verification.json', {'completed_utc': utc(), 'all_checks_passed': True,
          'n_predictions': len(scored), 'all56_preserved': True, 'four_disjoint_geometry_folds': True,
          'training_only_sbs_labels_scaling': True, 'test_predictor_has_no_outcome_id_or_group_inputs': True,
          'prediction_replay_identical': True, 'frozen_files_unchanged': True,
          'source_archive_and_raw_input_hashes_unchanged': True, 'failed_costs_remain_null': True,
          'new_solver_calls': 0, 'new_model_calls': 0, 'new_installs': 0,
          'archive_validity': 'Uses original independent continuous-check SUCCESS records; no new route replay and no fresh stochastic solver replicates.'})
    resource_data = {'cpu_s_since_script_start': time.process_time() - START_CPU,
                     'process_cpu_s_including_imports': time.process_time(),
                     'wall_s': time.perf_counter() - START_WALL,
                     'selection_fit_predict_cpu_s': selection_cpu, 'selection_fit_predict_wall_s': selection_wall,
                     'child_hard_cpu_limit_s': 8, 'maxrss_kib': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
    write('evidence/child_resource_before_report.json', resource_data)
    failures = summary['selected_failures']
    quality = summary['mean_relative_selected_vs_sbs_pct']
    lines = [
        '已观察档案的留一几何簇外配置选择重分析',
        '',
        '结论',
        f"固定四特征 1-NN 选择器成功 {summary['selected_successes']}/56；折内训练 SBS 成功 {summary['sbs_successes']}/56。",
        f"共同合法子集 n={summary['common_valid_n']}：选择器相对 SBS 的平均逐实例成本变化 {quality:+.6f}%；总距离降低 {summary['sum_distance_reduction_selected_vs_sbs_pct']:+.6f}%。",
        f"共同合法实例中选择器更好/相同/更差为 {summary['better_n']}/{summary['tied_n']}/{summary['worse_n']}；失败实例：{', '.join(summary['selected_failure_instances']) or '无'}。",
        '主结论须同时看全部 56 个任务的失败与共同合法质量；不能用成功子集均值掩盖失败。',
        '',
        '冻结与隔离',
        '仅一个预固定 k=1 分类器。四个特征为容量/总需求、需求总体变异系数、平均窗宽/depot时长、平均服务/depot时长。没有空间特征。',
        '按 depot 和完整客户坐标多重集 SHA256 分四折，几何 hash 不作特征。标准化、训练标签和 SBS 仅使用其他三簇；名字只用于距离平局时的固定排序。',
        '先冻结 protocol、输入 hash、四折和脚本；全部 56 个预测又在测试评分前封存。不存在测试失败门控、免费 fallback、参数搜索或追加重跑。',
        '分析者此前已知道档案总括结论。此冻结只是本次探索性重分析的执行前冻结，不是前瞻盲测预注册。',
        '',
        '每几何簇结果',
    ]
    for fold in per_fold:
        lines.extend([
            f"G{fold['fold']} {fold['test_geometry_sha256']}：训练 {fold['n_train']}，测试 {fold['n_test']}，训练 SBS={fold['fold_sbs_config']}。",
            f"  成功 1-NN {fold['selected_successes']}/{fold['n_all']}，SBS {fold['sbs_successes']}/{fold['n_all']}；共同合法 n={fold['common_valid_n']}，平均逐实例变化 {fold['mean_relative_selected_vs_sbs_pct']:+.6f}%，总距离降低 {fold['sum_distance_reduction_selected_vs_sbs_pct']:+.6f}%。",
            f"  正例：{', '.join(fold['better_instances']) or '无'}；负例：{', '.join(fold['worse_instances']) or '无'}；失败：{', '.join(fold['selected_failure_instances']) or '无'}。",
            f"  相同：{', '.join(fold['tied_instances']) or '无'}。",
        ])
    lines.extend([
        '', '与 oracle 上限的距离',
        f"在相同共同合法 n={summary['oracle_common_n']} 上，1-NN 与 oracle 的平均逐实例差距 {summary['mean_selected_gap_to_oracle_pct_common']:.6f}%，SBS 为 {summary['mean_sbs_gap_to_oracle_pct_common']:.6f}%。",
        f"共同合法子集按总距离计的 oracle 头部空间为 {summary['oracle_sum_headroom_vs_sbs_pct_common']:.6f}%；1-NN 捕获比例为 {summary['captured_oracle_distance_headroom_fraction_common']:.6f}（允许为负，不截断）。",
        f"原全样本描述性 SBS={global_sbs}，oracle 总距离降低 {descriptive['sum_distance_oracle_reduction_vs_sbs_pct']:.6f}%（n={descriptive['common_valid_n']}）；这个事后上限不能当作可学性证据。",
        '', '运行成本与实验边界',
        f"本轮只离线查询已存档的三个 250ms run 之一。所选 56 个 run 的既有 accounted CPU 合计 {summary['selected_archived_accounted_cpu_s_all']:.6f}s、wall 合计 {summary['selected_archived_accounted_wall_s_all']:.6f}s；不是本轮重新求解耗时，也不是在线部署实测。",
        f"本轮 fit+predict CPU={selection_cpu:.6f}s；完整进程和打包实测见 evidence/resource_accounting.json，硬上限 child8s+supervisor1s，总计低于10CPU秒。",
        '原求解质量由档案中的独立连续可行性校验结果支持。本轮未再次重放路线，也未重复随机求解；不能评估250ms边界下的跨次波动。',
        '这是已观察档案的探索性 LOgeo 重分析，不是新收集的 heldout 或外部独立测试。56个变体只有4个几何簇；不做显著性检验，不推断所有农业VRP的泛化。',
        '原输入的官方字节等价和再分发许可仍未验证。清洁ZIP不含原实例、完整坐标或路线；保留来源身份、hash及脚本。未上传。',
        '', '交付索引',
        'reports/predictions_all56.csv：全部56个预测、训练SBS、邻居、选中失败标志、合法成本/oracle差距、档案run_id和运行时间。',
        'reports/per_geometry.json：四簇分母、全失败/成功统计、正负实例明细。',
        'raw/training_models.json：各折训练集合、均值/标准差、SBS分数、训练最佳标签及标准化向量。',
        'protocol/freeze.json 与 evidence/predictions_sealed.json：冻结和预测封存证据。',
    ])
    (ROOT / 'reports/report_zh.txt').write_text('\n'.join(lines) + '\n')
    (ROOT / 'README_zh.txt').write_text(
        '探索性几何留一配置选择离线分析\n\n'
        '先读 reports/report_zh.txt；全部56预测保留在 reports/predictions_all56.csv。\n'
        '本目录为新隔离产物；未改旧档、未求解、未调用模型、未安装、未上传。\n'
        '复算时将本包复制到新空目录，只保留 source/；通过环境变量 SELECTION_ARCHIVE 与 SELECTION_INPUTS 指向有权限的原档案及56原输入，然后运行 python3 source/supervise.py。\n'
        '原实例不在ZIP中；需依据 protocol/input_manifest.json 的来源身份在授权范围获取，校验原始SHA256。\n'
        '不要删除本次freeze后原地覆盖。参数及规则仅一个版本，不存在隐含调参。\n'
        '完整测量与分项见 evidence/resource_accounting.json；原CPU/wall表示历史run的记录，不是新运行。\n')
    print(json.dumps(summary, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
