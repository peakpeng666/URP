"""Bound the offline study and account for child plus packaging CPU."""
import resource
resource.setrlimit(resource.RLIMIT_CPU, (1, 1))
import hashlib
import json
import subprocess
import sys
import time
import zipfile
from pathlib import Path
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent.parent
for directory in ['protocol', 'raw', 'reports', 'evidence']:
    (ROOT / directory).mkdir(exist_ok=True)
start = time.perf_counter()
with (ROOT / 'raw/stdout.log').open('x') as out, (ROOT / 'raw/stderr.log').open('x') as err:
    child = subprocess.run([sys.executable, str(ROOT / 'source/study.py')], stdout=out, stderr=err)
child_usage = resource.getrusage(resource.RUSAGE_CHILDREN)
assert child.returncode == 0, f'Child failed with {child.returncode}; inspect raw/stderr.log; never silently rerun.'
allow = ['README_zh.txt', 'source', 'protocol', 'raw', 'reports', 'evidence']
archive = ROOT.parent / (ROOT.name + '_clean.zip')
assert not archive.exists()


def accounting():
    own = resource.getrusage(resource.RUSAGE_SELF)
    return {'recorded_utc': datetime.now(timezone.utc).isoformat(),
            'child_user_cpu_s': child_usage.ru_utime, 'child_system_cpu_s': child_usage.ru_stime,
            'supervisor_user_cpu_s': own.ru_utime, 'supervisor_system_cpu_s': own.ru_stime,
            'total_observed_cpu_s': child_usage.ru_utime + child_usage.ru_stime + own.ru_utime + own.ru_stime,
            'wall_s': time.perf_counter() - start,
            'hard_cpu_limits_s': {'child': 8, 'supervisor': 1, 'sum': 9},
            'budget_cpu_s': 10, 'includes': 'Python imports, input parsing/hash verification, freeze, fitting/prediction, scoring, verification, reporting, and ZIP creation.',
            'new_solver_calls': 0, 'new_model_calls': 0, 'new_installs': 0}


# ZIP_STORED avoids compression variability; appended accounting is written after payload creation.
files = sorted(path for path in ROOT.rglob('*') if path.is_file() and path.relative_to(ROOT).parts[0] in allow)
assert not any(path.suffix in ['.pyc'] or '__pycache__' in path.parts for path in files)
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_STORED) as bundle:
    for path in files:
        bundle.write(path, str(path.relative_to(ROOT)))
    usage = accounting()
    assert usage['total_observed_cpu_s'] < 10
    (ROOT / 'evidence/resource_accounting.json').write_text(json.dumps(usage, indent=2) + '\n')
    bundle.write(ROOT / 'evidence/resource_accounting.json', 'evidence/resource_accounting.json')
    all_files = files + [ROOT / 'evidence/resource_accounting.json']
    checksums = '\n'.join(hashlib.sha256(path.read_bytes()).hexdigest() + '  ' + str(path.relative_to(ROOT)) for path in sorted(all_files)) + '\n'
    (ROOT / 'SHA256SUMS.txt').write_text(checksums)
    bundle.write(ROOT / 'SHA256SUMS.txt', 'SHA256SUMS.txt')
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None
    assert set(bundle.namelist()) == {str(path.relative_to(ROOT)) for path in all_files} | {'SHA256SUMS.txt'}
final = accounting()
final.update({'zip_path': str(archive), 'zip_bytes': archive.stat().st_size,
              'zip_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
              'zip_integrity_passed': True, 'note': 'Final receipt includes ZIP checks; in-ZIP accounting snapshot predates final checks by a small measured amount.'})
assert final['total_observed_cpu_s'] < 10
(ROOT.parent / (ROOT.name + '_receipt.json')).write_text(json.dumps(final, indent=2) + '\n')
print(json.dumps(final, indent=2))
