"""Independent post-run audit. No new predictions are substituted into results."""
import resource
resource.setrlimit(resource.RLIMIT_CPU, (1, 1))
import collections
import csv
import hashlib
import json
import math
from pathlib import Path
import statistics
import time
import zipfile

ROOT = Path(__file__).resolve().parent.parent
CONFIGS = ['pci250', 'pca250', 'sav250']
FEATURES = ['capacity_over_total_demand', 'demand_population_cv',
            'mean_window_width_over_depot_duration', 'mean_service_over_depot_duration']
read = lambda name: json.loads((ROOT / name).read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
start = time.perf_counter()
frozen = read('protocol/freeze.json')
for path, expected in frozen['sha256'].items():
    assert sha(ROOT / path) == expected
seal = read('evidence/predictions_sealed.json')
assert sha(ROOT / 'raw/predictions_before_scoring.json') == seal['prediction_sha256']
assert sha(ROOT / 'raw/training_models.json') == seal['model_sha256']
features = {r['instance']: r for r in read('protocol/features.json')}
outcomes = {(r['instance'], r['config']): r for r in read('raw/archive_outcome_extract.json')}
assert len(outcomes) == 168 and len(features) == 56
predictions = {r['instance']: r for r in read('raw/predictions_before_scoring.json')}
rows = read('reports/predictions_all56.json')
assert len(rows) == len(predictions) == 56
covered = set()
for fold in read('protocol/folds.json'):
    train, test = fold['train_instances'], fold['test_instances']
    assert not set(train) & set(test)
    assert len({features[name]['geometry_sha256'] for name in train}) == 3
    assert {features[name]['geometry_sha256'] for name in test} == {fold['test_geometry_sha256']}
    assert not covered & set(test)
    covered.update(test)
    coverage = {c: sum(outcomes[name, c]['valid'] for name in train) for c in CONFIGS}
    max_cov = max(coverage.values())
    contenders = [c for c in CONFIGS if coverage[c] == max_cov]
    valid_intersection = [name for name in train if all(outcomes[name, c]['valid'] for c in contenders)]
    scores = {}
    for c in contenders:
        ratios = [outcomes[name, c]['distance'] / min(outcomes[name, alt]['distance'] for alt in CONFIGS if outcomes[name, alt]['valid']) for name in valid_intersection]
        scores[c] = statistics.mean(ratios) if ratios else 0
    sbs = sorted(contenders, key=lambda c: (scores[c], CONFIGS.index(c)))[0]
    means = [statistics.mean(features[name][f] for name in train) for f in FEATURES]
    scales = [statistics.pstdev(features[name][f] for name in train) or 1 for f in FEATURES]
    labels = {}
    for name in train:
        costs = {c: outcomes[name, c]['distance'] for c in CONFIGS if outcomes[name, c]['valid']}
        if costs:
            best = min(costs.values())
            labels[name] = min([c for c in costs if costs[c] <= best + 1e-6], key=lambda c: (c != sbs, CONFIGS.index(c)))
    for name in test:
        # Compute from raw feature differences, independently of saved standardized vectors.
        distances = {other: sum(((features[name][f] - features[other][f]) / scale) ** 2
                                for f, scale in zip(FEATURES, scales)) for other in labels}
        nearest_d = min(distances.values())
        tied = [other for other in labels if distances[other] <= nearest_d + 1e-12]
        neighbor = min(tied, key=lambda other: (labels[other] != sbs, other))
        prediction = predictions[name]
        assert prediction['fold_sbs_config'] == sbs
        assert prediction['neighbor'] == neighbor
        assert prediction['selected_config'] == labels[neighbor]
        assert features[neighbor]['geometry_sha256'] != features[name]['geometry_sha256']
        assert math.isclose(prediction['neighbor_squared_distance'], distances[neighbor], rel_tol=1e-12, abs_tol=1e-12)
assert covered == set(features)
for row in rows:
    item = outcomes[row['instance'], row['selected_config']]
    assert row['selected_valid'] == item['valid'] and row['selected_distance'] == item['distance']
    assert row['selected_run_id'] == item['run_id']
    assert row['selected_archived_accounted_cpu_s'] == item['archived_accounted_cpu_s']
    assert row['selected_archived_accounted_wall_s'] == item['archived_accounted_wall_s']
    if not item['valid']:
        assert row['selected_distance'] is None and row['selected_vs_sbs_pct'] is None
common = [r for r in rows if r['selected_valid'] and r['sbs_valid']]
summary = read('reports/summary.json')
assert summary['common_valid_n'] == len(common)
assert math.isclose(summary['mean_relative_selected_vs_sbs_pct'], statistics.mean(100 * (r['selected_distance'] / r['sbs_distance'] - 1) for r in common), abs_tol=1e-12)
assert math.isclose(summary['sum_distance_reduction_selected_vs_sbs_pct'], 100 * (1 - sum(r['selected_distance'] for r in common) / sum(r['sbs_distance'] for r in common)), abs_tol=1e-12)
assert len(list(csv.DictReader((ROOT / 'reports/predictions_all56.csv').open()))) == 56
bundle_path = ROOT.parent / (ROOT.name + '_clean.zip')
with zipfile.ZipFile(bundle_path) as bundle:
    assert bundle.testzip() is None
    assert all(not name.startswith(('inputs/', 'credentials/', '.venv/')) for name in bundle.namelist())
    assert all(not name.endswith('.pyc') for name in bundle.namelist())
    for line in bundle.read('SHA256SUMS.txt').decode().splitlines():
        expected, name = line.split('  ', 1)
        assert hashlib.sha256(bundle.read(name)).hexdigest() == expected
    assert bundle.read('protocol/freeze.json') == (ROOT / 'protocol/freeze.json').read_bytes()
report = {
    'independent_postrun_audit': True, 'all_checks_passed': True,
    'prediction_matches': 56, 'geometry_fold_count': 4,
    'alternate_distance_formula_used': True, 'source_or_frozen_rule_changes': False,
    'outcome_extract_counts': dict(collections.Counter(r['outcome'] for r in outcomes.values())),
    'selected_config_counts': summary['selected_config_counts'],
    'cpu_s_including_imports': time.process_time(), 'wall_s': time.perf_counter() - start,
    'hard_cpu_limit_s': 1,
    'all_attempt_hard_envelope_s': 10,
    'budget_explanation': 'Failed initialization reserved <=2s; successful analysis/packaging child<=6s and supervisor<=1s; independent audit<=1s. Original archive and frozen analysis never changed.',
    'archive_zip_sha256_checked': sha(bundle_path),
}
(ROOT / 'evidence/independent_postrun_audit.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
