#!/usr/bin/env python3
"""Independent, read-only experiment audit. Standard library only; no solver or author imports.
Reads sealed repeatability artifacts and the explicitly allowlisted old budget-split provenance.
Writes only the separate audit output directory. No P2 data, network, uploads or solver calls.
"""
import ast, collections, csv, hashlib, json, math, random, re, resource, statistics, time, zipfile
from datetime import datetime, timezone
from decimal import Decimal, localcontext, ROUND_HALF_UP
from pathlib import Path
P=Path('/workspace/shared/solver_repeatability_20261007')
O=Path('/workspace/shared/solver_repeatability_audit_20261007')
OLD=Path('/workspace/shared/selector_budget_split_20261007')
ZIP=P.with_name(P.name+'_package.zip')
EXPECTED='9b8c67e638ae376f86f3e0c96394ff1088a7990e75a5c3229873b0db441c9f4e'
ARMS=['selector250_pci250','fixed_pci500']
SEED=2026100708
T0=time.perf_counter();C0=time.process_time();START=datetime.now(timezone.utc).isoformat()
CHECKS=[];ISSUES=[];WARNINGS=[];READS=set()
def raw(p):
    p=Path(p)
    assert p.is_relative_to(P) or p==ZIP or p==P.with_name(P.name+'_package_receipt.json') or p.is_relative_to(OLD) or p.is_relative_to(O)
    assert not any('heldout' in x.lower() or x.lower()=='p2' for x in p.parts)
    READS.add(str(p));return p.read_bytes()
def j(rel):return json.loads(raw(P/rel))
def jl(rel):return [json.loads(x) for x in raw(P/rel).decode().splitlines()]
def sha(p):return hashlib.sha256(raw(p)).hexdigest()
def digest(obj):return hashlib.sha256(json.dumps(obj,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def ck(label,condition,detail=None):
    CHECKS.append({'check':label,'passed':bool(condition),**({'detail':detail} if detail is not None else {})})
    if not condition:ISSUES.append({'check':label,'detail':detail})
def close(a,b,tol=1e-8):
    if a is None or b is None:return a is b
    return math.isclose(a,b,rel_tol=1e-11,abs_tol=tol)
def eq(a,b):
    if isinstance(a,dict):return isinstance(b,dict) and a.keys()==b.keys() and all(eq(a[k],b[k]) for k in a)
    if isinstance(a,list):return isinstance(b,list) and len(a)==len(b) and all(eq(x,y) for x,y in zip(a,b))
    if isinstance(a,float):return isinstance(b,(int,float)) and close(a,b)
    return a==b
def stats(xs):
    xs=list(xs)
    if not xs:return dict(n=0,min=None,max=None,mean=None,population_std=None,range=None,median=None)
    return dict(n=len(xs),min=min(xs),max=max(xs),mean=statistics.mean(xs),population_std=statistics.pstdev(xs),range=max(xs)-min(xs),median=statistics.median(xs))
def write(name,x): (O/name).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')

# Entire immutable input inventory, including non-packaged Python bytecode, before/after audit.
inventory_before={str(p.relative_to(P)):sha(p) for p in sorted(P.rglob('*')) if p.is_file()}
receipt=json.loads(raw(P.with_name(P.name+'_package_receipt.json')))
ck('Final outer ZIP SHA256 matches author stop-writing handoff',sha(ZIP)==EXPECTED==receipt['package_sha256'])
ck('Final ZIP byte count',ZIP.stat().st_size==receipt['package_bytes']==589457)
files={r:h for r,h in inventory_before.items() if '__pycache__' not in Path(r).parts and not r.endswith('.pyc')}
with zipfile.ZipFile(ZIP) as z:
    ck('ZIP CRC integrity',z.testzip() is None)
    ck('ZIP exact complete file set',set(z.namelist())==set(files),{'zip':len(z.namelist()),'directory_nonbytecode':len(files)})
    ck('All 66 ZIP file bytes match final directory',all(hashlib.sha256(z.read(r)).hexdigest()==h for r,h in files.items()))
    ck('Complete final shell and exit receipts included',all(z.read(r)==raw(P/r) for r in ['evidence/shell_time.txt','evidence/shell_exit_receipt.json']))
sumlines=raw(P/'SHA256SUMS.txt').decode().splitlines()
sums={line.split('  ',1)[1]:line.split('  ',1)[0] for line in sumlines}
ck('SHA256SUMS exact 65-file scope',set(sums)==set(files)-{'SHA256SUMS.txt'} and len(sums)==65)
ck('SHA256SUMS all valid',all(files[p]==h for p,h in sums.items()))
freeze=j('protocol/freeze.json')
ck('44 prospective frozen hashes all valid',len(freeze['sha256'])==44 and all(files[p]==h for p,h in freeze['sha256'].items()))
ck('All executable experiment source files frozen',all(p in freeze['sha256'] for p in files if p.startswith('source/')))

# Compare all explicitly identified upstream input/model/source/parameter artifacts, never old results.
prov=j('evidence/source_provenance.json')
allowed_old={Path(x['path']) for x in prov}
ck('Provenance paths narrowly limited to prior budget-split source/input/protocol',all(p.is_relative_to(OLD) and p.relative_to(OLD).parts[0] in ['source','inputs','protocol'] for p in allowed_old))
oldhash={str(p):sha(p) for p in sorted(allowed_old)}
ck('Upstream provenance hashes and byte lengths match',all(oldhash[x['path']]==x['sha256'] and ('bytes' not in x or Path(x['path']).stat().st_size==x['bytes']) for x in prov))
oldfreeze=json.loads(raw(OLD/'protocol/freeze.json'))
ck('Upstream provenance files match prior freeze',all(oldfreeze['sha256'].get(str(p.relative_to(OLD)))==oldhash[str(p)] for p in allowed_old if p.name!='freeze.json'))
oldmanifest=json.loads(raw(OLD/'protocol/input_manifest.json'))
universe=j('protocol/selection_universe.json');manifest=j('protocol/input_manifest.json');geometries=j('protocol/geometries.json')
gm={}
for m in oldmanifest:
    key={k:m[k] for k in ['geometry_id','family','seed','geometry_sha256','customer_coordinates_sha256']}
    ck('Old geometry consistency '+m['instance'],m['geometry_id'] not in gm or gm[m['geometry_id']]==key)
    gm[m['geometry_id']]=key
expected_universe=[];expected_selected=[]
for family in sorted({g['family'] for g in gm.values()}):
    members=sorted((g for g in gm.values() if g['family']==family),key=lambda g:(g['customer_coordinates_sha256'],g['geometry_id']))
    ck('Each family has six original candidates '+family,len(members)==6)
    expected_universe.extend(dict(g,family_coordinate_hash_rank=i,selected=i<=2) for i,g in enumerate(members,1))
    expected_selected.extend(members[:2])
ck('24 old geometries / 48 old related problems',len(gm)==24 and len(oldmanifest)==48)
ck('Selection is exact coordinate-hash-first-two per family',universe==expected_universe and geometries==expected_selected)
gids={g['geometry_id'] for g in expected_selected}
ck('Manifest is exact selected old subset',manifest==[m for m in oldmanifest if m['geometry_id'] in gids])
ds={d['id']:d for d in j('inputs/instances.json')};oldrecords={d['id']:d for d in json.loads(raw(OLD/'inputs/instances.json'))}
ck('Selected records unchanged from old inputs',all(d==oldrecords[n] for n,d in ds.items()))
ck('8 geometries, 16 related problems, widths 20 and 80',len(gids)==8 and len(ds)==16 and all({d['width'] for d in ds.values() if d['geometry_id']==g}=={20,80} for g in gids))

# Independent input parser: source text is the authoritative route replay input.
def parse_input(path):
    lines=raw(path).decode().splitlines();vi=lines.index('VEHICLE');fleet,cap=map(int,lines[vi+2].split());nodes={}
    for s in lines:
        parts=s.split()
        if len(parts)==7 and all(re.fullmatch('-?[0-9]+',x) for x in parts):
            vals=list(map(int,parts));assert vals[0] not in nodes;nodes[vals[0]]=dict(zip(['id','x','y','demand','ready','due','service'],vals))
    assert set(nodes)==set(range(101))
    return {'id':lines[0],'vehicles':fleet,'capacity':cap,'nodes':nodes}
parsed={n:parse_input(P/f'inputs/{n}.txt') for n in ds}
for m in manifest:
    n=m['instance'];d=ds[n];q=parsed[n]
    ck('Input byte/node/coordinate equality '+n,sha(P/f'inputs/{n}.txt')==m['input_sha256'] and q['id']==n and q['vehicles']==d['vehicles'] and q['capacity']==d['capacity'] and list(q['nodes'].values())==d['nodes'] and digest(sorted([[x['x'],x['y']] for x in d['nodes'][1:]]))==m['customer_coordinates_sha256'])

# Independent eight-feature extraction and frozen nearest-neighbor prediction; no refit.
def features(q):
    customers=list(q['nodes'].values())[1:];N=len(customers);demands=[v['demand'] for v in customers]
    cx=sum(v['x'] for v in customers)/N;cy=sum(v['y'] for v in customers)/N
    xx=statistics.mean((v['x']-cx)**2 for v in customers);yy=statistics.mean((v['y']-cy)**2 for v in customers);cov=statistics.mean((v['x']-cx)*(v['y']-cy) for v in customers)
    trace=xx+yy;radius=math.sqrt(trace);h=q['nodes'][0]['due']-q['nodes'][0]['ready'];depot=q['nodes'][0]
    return dict(instance=q['id'],capacity_over_total_demand=q['capacity']/sum(demands),demand_population_cv=statistics.pstdev(demands)/statistics.mean(demands),mean_window_width_over_depot_duration=statistics.mean(v['due']-v['ready'] for v in customers)/h,mean_service_over_depot_duration=statistics.mean(v['service'] for v in customers)/h,rms_radius_over_horizon=radius/h,mean_nn_over_rms_radius=statistics.mean(min(math.hypot(v['x']-u['x'],v['y']-u['y']) for u in customers if u['id']!=v['id']) for v in customers)/radius,covariance_anisotropy=(trace+math.sqrt((xx-yy)**2+4*cov*cov))/(2*trace),depot_centroid_over_rms_radius=math.hypot(cx-depot['x'],cy-depot['y'])/radius)
feat=j('protocol/features.json');pred=j('protocol/predictions_sealed.json');models=j('protocol/source_training_models.json');model=models['spatial_1nn8']
ck('Exactly frozen eight-feature 80-instance model',len(model['features'])==8 and len(model['train_instances'])==80 and sha(P/'protocol/source_training_models.json')==oldhash[str(OLD/'protocol/source_training_models.json')])
oldfeat=json.loads(raw(OLD/'protocol/features.json'));oldpred=json.loads(raw(OLD/'protocol/predictions_sealed.json'))
for n,q in parsed.items():
    f=features(q);ck('Independently recomputed eight features '+n,eq(f,feat[n]) and feat[n]==oldfeat[n])
    vector=[(f[k]-model['feature_means'][k])/model['feature_scales'][k] for k in model['features']]
    d2={name:sum((a-b)**2 for a,b in zip(vector,v)) for name,v in model['vectors'].items()}
    tied=sorted(name for name,v in d2.items() if v<=min(d2.values())+1e-12)
    nei=min(tied,key=lambda name:(model['labels'][name]!=model['sbs'],name))
    result=dict(selected_config=model['labels'][nei],neighbor=nei,neighbor_squared_distance=d2[nei],neighbor_tie_count=len(tied),neighbor_tie_instances=tied)
    ck('Independently recomputed sealed prediction '+n,eq(result,pred[n]) and pred[n]==oldpred[n])

# Prospective design, exact serialized request provenance and chronological terminal ledger.
reqs=j('protocol/requests.json');sched=j('protocol/policy_schedule.json');results=jl('raw/results.jsonl');policies=jl('raw/policy_results.jsonl');events=jl('raw/events.jsonl');checks=jl('raw/continuous_checks.jsonl');overhead=j('evidence/feature_prediction_overhead.json');summ=j('reports/summary.json')
rm={r['run_id']:r for r in results};qm={r['run_id']:r for r in reqs};pm={p['policy_id']:p for p in policies};cm={c['run_id']:c for c in checks}
ck('Exact prospective and terminal counts and uniqueness',len(reqs)==len(rm)==len(results)==144 and len(sched)==len(pm)==len(policies)==96)
ck('No omitted or extra request/policy and exact planned order',[r['run_id'] for r in reqs]==[r['run_id'] for r in results] and [s['policy_id'] for s in sched]==[p['policy_id'] for p in policies])
ck('All 96 instance/arm/repetition cells exactly once',collections.Counter((p['instance'],p['policy'],p['replicate']) for p in policies)==collections.Counter((n,a,k) for n in ds for a in ARMS for k in [1,2,3]))
names=sorted(ds);random.Random(202610077101).shuffle(names);rounds=[names,names[::-1],names[8:]+names[:8]]
expected_schedule=[]
for rep,order in enumerate(rounds,1):
    for pos,n in enumerate(order):
        arms=ARMS if (pos+rep)%2==0 else ARMS[::-1]
        for apos,a in enumerate(arms):
            pid=f'{n}__{a}__rep{rep}'
            expected_schedule.append(dict(policy_sequence=len(expected_schedule),policy_id=pid,replicate=rep,instance_position=pos,arm_position=apos,instance=n,policy=a,run_ids=[pid+'__single'] if a==ARMS[1] else [pid+'__first',pid+'__fallback']))
ck('Full randomized/reversed/rotated arm-balanced schedule matches',sched==expected_schedule)
ck('Each arm first 8 / second 8 in each round',all(collections.Counter(p['arm_position'] for p in policies if p['replicate']==rep and p['policy']==a)=={0:8,1:8} for rep in [1,2,3] for a in ARMS))
source_hashes={p:h for p,h in files.items() if p.startswith('source/')}
for i,(q,r) in enumerate(zip(reqs,results)):
    ck('Request and immutable provenance '+q['run_id'],q['request_sequence']==i and all(r.get(k)==v for k,v in q.items()) and q['seed']==SEED and q['new_routing_model'] is True and q['input_sha256']==files[q['input_path']] and q['parameter_sha256']==files[q['parameter_path']] and q['source_sha256']==source_hashes and q['frozen_prediction_sha256']==files['protocol/predictions_sealed.json'])
    config='pci500' if q['stage']=='single' else ('pci250' if q['stage']=='fallback' else pred[q['instance']]['selected_config'])
    ck('Fixed arm/stage configuration '+q['run_id'],q['config_id']==config and q['budget_ms']==int(config[3:]) and q['strategy']=={'pci':'PARALLEL_CHEAPEST_INSERTION','pca':'PATH_CHEAPEST_ARC','sav':'SAVINGS'}[config[:3]])
for cfg in ['pci250','pca250','sav250','pci500']:
    text=raw(P/f'protocol/parameters_{cfg}.textproto').decode()
    ck('Frozen parameters and same seed '+cfg,files[f'protocol/parameters_{cfg}.textproto']==oldhash[str(OLD/f'protocol/parameters_{cfg}.textproto')] and f'random_seed: {SEED}' in text and 'num_search_workers: 1' in text and f'nanos: {int(cfg[3:])*1000000}' in text)
executed=[r for r in results if r['outcome']!='SKIPPED_FIRST_SUCCESS'];skips=[r for r in results if r['outcome']=='SKIPPED_FIRST_SUCCESS']
starts=[e for e in events if e['event']=='request_started'];ends=[e for e in events if e['event']=='request_finished'];skipev=[e for e in events if e['event']=='fallback_skipped']
ck('Freeze is first event, prior to all targets',events[0]['event']=='frozen_before_first_target' and events[0]['freeze_sha256']==files['protocol/freeze.json'] and events[0]['solver_calls_before_freeze']==freeze['solver_calls_before_freeze']==0 and freeze['frozen_utc']<events[0]['utc']<starts[0]['utc'])
ck('Events strictly chronological and consecutively numbered',all(e['event_sequence']==i for i,e in enumerate(events)) and all(a['monotonic_ns']<b['monotonic_ns'] and a['utc']<=b['utc'] for a,b in zip(events,events[1:])))
ck('99 actual calls and 45 skips separately accounted',len(executed)==len(starts)==len(ends)==len(checks)==99 and len(skips)==len(skipev)==45)
ck('Exact start/end/check/skip IDs no duplicates',[e['run_id'] for e in starts]==[r['run_id'] for r in executed]==[e['run_id'] for e in ends]==[c['run_id'] for c in checks] and [e['run_id'] for e in skipev]==[r['run_id'] for r in skips])
expected_events=[events[0]]
for r in results:
    if r['outcome']=='SKIPPED_FIRST_SUCCESS':
        ck('Fallback skip follows independently valid first '+r['run_id'],r['stage']=='fallback' and rm[r['policy_id']+'__first']['outcome']=='SUCCESS' and rm[r['policy_id']+'__first']['check_summary']['valid'] and r['request_cpu_s']==r['request_wall_s']==0 and r['ortools_status'] is None and r['ortools_status_name']=='NOT_EXECUTED')
    else:
        si=next(e for e in starts if e['run_id']==r['run_id']);ei=next(e for e in ends if e['run_id']==r['run_id'])
        ck('Paired serial event and original native status '+r['run_id'],ei['event_sequence']==si['event_sequence']+1 and r['start_event']==si and ei['outcome']==r['outcome'] and ei['native_code']==r['ortools_status'] and si['utc']<=r['end_utc']<=ei['utc'])
        if r['stage']=='fallback':ck('Fallback only follows failed first '+r['run_id'],rm[r['policy_id']+'__first']['outcome']!='SUCCESS' and rm[r['policy_id']+'__first']['check_summary']['valid'] is False)
ck('Completion event and no extra event kinds',events[-1]['event']=='planned_run_complete' and len(events)==1+2*99+45+1)

# Fully independent continuous replay, exact half-up objective, and original encoded time feasibility.
def replay(q,routes):
    errors=[];nodes=q['nodes'];seen=[];dist=0.;minimum=math.inf;integer_obj=0;arcs=0;route_detail=[]
    if not isinstance(routes,list):return {'valid':False,'errors':['no routes'],'distance':None}
    if len(routes)>q['vehicles']:errors.append('too many vehicles')
    vehicles=[]
    for i,entry in enumerate(routes):
        r=entry['nodes'] if isinstance(entry,dict) else entry
        if isinstance(entry,dict):vehicles.append(entry['vehicle'])
        if not isinstance(r,list) or len(r)<3 or r[0]!=0 or r[-1]!=0 or 0 in r[1:-1] or any(type(x)!=int or x not in nodes for x in r):errors.append('bad route structure');continue
        seen.extend(r[1:-1]);load=sum(nodes[x]['demand'] for x in r[1:-1]);clock=float(nodes[0]['ready']);rd=0.;encoded=nodes[0]['ready']*1000000
        if load>q['capacity']:errors.append('capacity')
        for a,b in zip(r,r[1:]):
            v,w=nodes[a],nodes[b];sq=(v['x']-w['x'])**2+(v['y']-w['y'])**2;leg=math.sqrt(sq);rd+=leg
            clock=max(clock+v['service']+leg,w['ready']);margin=w['due']-clock;minimum=min(minimum,margin)
            if margin < -1e-9:errors.append('continuous late')
            with localcontext() as ctx:
                ctx.prec=60;dec=Decimal(sq).sqrt()*1000000
                integer_obj+=int(dec.to_integral_value(rounding=ROUND_HALF_UP))
                travel=math.isqrt(sq*1000000**2);travel+=int(travel**2<sq*1000000**2)
            encoded=max(encoded+v['service']*1000000+travel,w['ready']*1000000)
            if encoded>w['due']*1000000:errors.append('encoded late')
            arcs+=1
        dist+=rd;route_detail.append({'route_index':i,'nodes':r,'load':load,'distance':rd,'return_time':clock,'encoded_earliest_return':encoded})
    if collections.Counter(seen)!=collections.Counter(range(1,101)):errors.append('customer coverage')
    if vehicles and (len(set(vehicles))!=len(vehicles) or any(type(v)!=int or not 0<=v<q['vehicles'] for v in vehicles)):errors.append('vehicle ids')
    if abs(integer_obj/1000000-dist)>.5*arcs/1000000+1e-9:errors.append('rounding bound')
    return {'valid':not errors,'errors':errors,'distance':dist,'vehicles_used':len(routes),'served_unique':len(set(seen)),'minimum_window_margin':minimum,'objective_integer':integer_obj,'arcs':arcs,'route_details':route_detail}
replays=[]
for r in executed:
    x=replay(parsed[r['instance']],r['routes']);replays.append({'run_id':r['run_id'],**x});a=r['check_summary'];full=cm[r['run_id']]
    ck('Independent continuous/encoded replay '+r['run_id'],x['valid']==(r['outcome']=='SUCCESS')==a['valid']==full['valid'])
    if x['valid']:
        ck('Independent distance/objective/margin '+r['run_id'],close(x['distance'],a['distance']) and close(x['distance'],full['distance']) and x['objective_integer']==r['objective_integer']==a['independent_objective_integer'] and close(x['minimum_window_margin'],a['minimum_window_margin']) and x['served_unique']==100)
        ck('Three independent route hashes '+r['run_id'],digest([{'vehicle':v['vehicle'],'nodes':v['nodes']} for v in r['routes']])==r['route_ordered_sha256'] and digest(sorted(v['nodes'] for v in r['routes']))==r['route_canonical_sha256'] and digest(r['routes'])==r['route_payload_sha256'])
        ck('Assignment/native success record '+r['run_id'],r['assignment_returned'] and r['ortools_status'] in [1,2,7] and r['first_solution'] is not None)
    else:ck('No-assignment native failure preserved '+r['run_id'],not r['assignment_returned'] and r['routes'] is None and a['distance'] is None)
for n,d in ds.items():ck('Witness independently feasible '+n,replay(parsed[n],d['witness_routes'])['valid'])
write('independent_route_replays.json',replays)
# Mutant tests exercise the auditor's own continuous checker without any solver or author code.
from copy import deepcopy
base=next(r for r in executed if r['outcome']=='SUCCESS');baseq=parsed[base['instance']];baser=base['routes']
mutant_results=[]
def mutant_test(label,q,r,expected):
    actual=replay(q,r)['valid'];mutant_results.append({'test':label,'expected_valid':expected,'actual_valid':actual});ck('Auditor checker self-test '+label,actual==expected)
mutant_test('valid_returned_route',baseq,baser,True)
r=deepcopy(baser);r[0]['nodes'].pop(1);mutant_test('missing_customer',baseq,r,False)
r=deepcopy(baser);r[0]['nodes'].insert(1,r[0]['nodes'][1]);mutant_test('duplicate_customer',baseq,r,False)
r=deepcopy(baser);r[0]['nodes'].insert(1,0);mutant_test('interior_depot',baseq,r,False)
r=deepcopy(baser);r[0]['nodes'][1]=999;mutant_test('unknown_customer',baseq,r,False)
q=deepcopy(baseq);q['vehicles']=0;mutant_test('fleet_limit',q,baser,False)
q=deepcopy(baseq);q['capacity']=0;mutant_test('capacity_limit',q,baser,False)
q=deepcopy(baseq);q['nodes'][baser[0]['nodes'][1]]['due']=0;mutant_test('customer_deadline',q,baser,False)
q=deepcopy(baseq);q['nodes'][0]['due']=0;mutant_test('depot_return_deadline',q,baser,False)
write('auditor_checker_tests.json',mutant_results)


# Policy aggregation: all stages charged, no best-of, no reuse, true final executed run.
for p,s in zip(policies,sched):
    rr=[rm[x] for x in s['run_ids']];actual=[r for r in rr if r['outcome']!='SKIPPED_FIRST_SUCCESS'];last=actual[-1]
    ck('Policy exact stage accounting '+p['policy_id'],p['executed_run_ids']==[r['run_id'] for r in actual] and p['returned_run_id']==last['run_id'] and p['valid']==(last['outcome']=='SUCCESS') and p['outcome']==last['outcome'] and p['final_native_code']==last['ortools_status'] and close(p['distance'],last['check_summary']['distance']) and p['fallback_executed']==any(r['stage']=='fallback' for r in actual) and p['nominal_search_ms_executed']==sum(r['budget_ms'] for r in actual))
    ck('Policy route hashes match returned run '+p['policy_id'],all(p[h]==last[h] for h in ['route_ordered_sha256','route_canonical_sha256','route_payload_sha256']))
    ck('Policy search CPU/wall sums '+p['policy_id'],all(close(p[k],sum(r[k] for r in actual)) for k in ['solve_cpu_s','solve_wall_s']))
    charge=sum(v['cpu_s'] for v in overhead[p['instance']].values()) if p['policy']==ARMS[0] else 0
    wcharge=sum(v['wall_s'] for v in overhead[p['instance']].values()) if p['policy']==ARMS[0] else 0
    ck('Feature physical-vs-charged CPU and wall '+p['policy_id'],close(charge,p['feature_prediction_cpu_s_charged']) and close(wcharge,p['feature_prediction_wall_s_charged']) and close(p['charged_cpu_s'],p['policy_execution_cpu_s']+charge) and close(p['charged_wall_s'],p['policy_execution_wall_s']+wcharge))
failures=[r for r in executed if r['outcome']!='SUCCESS'];fr=j('reports/all_failures_and_skips.json')
ck('All failure/skip records retained exactly',fr['failed_requests']==failures and fr['success_skips']==skips and fr['failed_policies']==[p for p in policies if not p['valid']])
ck('Exactly three same-instance SAV first-stage failures, all recovered',len(failures)==3 and {r['instance'] for r in failures}=={'b019_w080'} and {r['replicate'] for r in failures}=={1,2,3} and all(r['config_id']=='sav250' and r['ortools_status']==3 and r['ortools_status_name']=='ROUTING_FAIL' for r in failures) and all(p['valid'] for p in policies))
WARNINGS.append({'severity':'minor_reporting','finding':'Inherited core maps native status 3 / ROUTING_FAIL to generic outcome UNKNOWN. All 3 such no-assignment requests are preserved in failed_requests and trigger the approved fallback; no failure is dropped. Interpret native code/name as authoritative; do not call these unexplained missing outcomes or proven infeasibility.','source':'source/core.py:69; reports/all_failures_and_skips.json'})

# Recompute all per-problem descriptive statistics and all geometry aggregates independently.
author_rows=j('reports/per_instance_repeatability.json');ridx={(r['instance'],r['policy']):r for r in author_rows};recomputed=[];by={}
resource_keys=['policy_execution_cpu_s','charged_cpu_s','policy_execution_wall_s','charged_wall_s','solve_cpu_s','solve_wall_s']
for n in sorted(ds):
    for arm in ARMS:
        ps=sorted((p for p in policies if p['instance']==n and p['policy']==arm),key=lambda p:p['replicate']);valid=[p for p in ps if p['valid']];dstat=stats(p['distance'] for p in valid)
        if valid:dstat['range_pct_of_success_mean']=100*dstat['range']/dstat['mean']
        row=dict(instance=n,geometry_id=ds[n]['geometry_id'],family=ds[n]['family'],width=ds[n]['width'],policy=arm,replicates=3,success_count=len(valid),coverage_pattern=[int(p['valid']) for p in ps],coverage_changed=0<len(valid)<3,native_code_pattern=[p['final_native_code'] for p in ps],fallback_pattern=[p['fallback_executed'] for p in ps],distance=dstat,route_hashes_by_replicate={h:[p[h] for p in ps] for h in ['route_ordered_sha256','route_canonical_sha256','route_payload_sha256']},distinct_success_route_hashes={h:len({p[h] for p in valid}) for h in ['route_ordered_sha256','route_canonical_sha256','route_payload_sha256']},distance_by_replicate=[p['distance'] for p in ps],resource={k:stats(p[k] for p in ps) for k in resource_keys},cpu_by_replicate=[p['policy_execution_cpu_s'] for p in ps])
        recomputed.append(row);by[n,arm]=row;ck('All per-problem route/distance/CPU statistics '+n+'/'+arm,eq(row,ridx[n,arm]))
ck('Exactly 32 problem-arm report rows',len(author_rows)==len(ridx)==32)
author_geoms=j('reports/per_geometry_repeatability.json');agg={g['geometry_id']:g for g in author_geoms}
for gid in sorted(gids):
    ns=sorted(n for n in ds if ds[n]['geometry_id']==gid);g=agg[gid]
    ck('Geometry identities and denominator '+gid,g['instances']==ns and g['independent_block_count']==1 and g['family']==ds[ns[0]]['family'])
    for arm in ARMS:
        pp=[p for p in policies if p['instance'] in ns and p['policy']==arm];ok=[all(p['valid'] for p in pp if p['replicate']==r) for r in [1,2,3]];d=[statistics.mean(p['distance'] for p in pp if p['replicate']==r) if ok[r-1] else None for r in [1,2,3]]
        v=dict(both_window_success_pattern=[int(x) for x in ok],both_window_success_count_of3=sum(ok),window_coverage_of2_by_replicate=[sum(p['valid'] for p in pp if p['replicate']==r) for r in [1,2,3]],both_window_mean_distance_by_replicate=d,both_window_mean_distance_stats=stats(x for x in d if x is not None),cpu_sum_by_replicate=[sum(p['policy_execution_cpu_s'] for p in pp if p['replicate']==r) for r in [1,2,3]],instances=[by[n,arm] for n in ns])
        ck('All per-geometry repeatability statistics '+gid+'/'+arm,eq(v,g['arms'][arm]))
contrasts=[]
for n in sorted(ds):
    a,b=by[n,ARMS[0]],by[n,ARMS[1]];all6=a['success_count']==b['success_count']==3;c=dict(instance=n,geometry_id=ds[n]['geometry_id'],all6_success=all6,selector_coverage_of3=a['success_count'],fixed_coverage_of3=b['success_count'])
    if all6:
        delta=a['distance']['mean']-b['distance']['mean'];noise=max(a['distance']['range'],b['distance']['range'])
        c.update(mean_distance_delta_selector_minus_fixed=delta,mean_relative_distance_delta_pct=100*(a['distance']['mean']/b['distance']['mean']-1),selector_within_repeat_range=a['distance']['range'],fixed_within_repeat_range=b['distance']['range'],max_within_arm_repeat_range=noise,absolute_mean_delta_le_observed_max_repeat_range=abs(delta)<=noise+1e-9,observed_success_distance_ranges_overlap=max(a['distance']['min'],b['distance']['min'])<=min(a['distance']['max'],b['distance']['max'])+1e-9)
    contrasts.append(c)
ck('All 16 arm contrasts recompute exactly',eq(contrasts,j('reports/arm_contrasts.json')))
paired=[]
for rep in [1,2,3]:
    rp={(p['instance'],p['policy']):p for p in policies if p['replicate']==rep};common=[n for n in ds if all(rp[n,a]['valid'] for a in ARMS)]
    paired.append(dict(replicate=rep,coverage_of16={a:sum(rp[n,a]['valid'] for n in ds) for a in ARMS},common_success_instance_n=len(common),common_success_geometry_n=len({ds[n]['geometry_id'] for n in common}),common_success_mean_relative_distance_delta_selector_minus_fixed_pct=statistics.mean(100*(rp[n,ARMS[0]]['distance']/rp[n,ARMS[1]]['distance']-1) for n in common)))
ck('All round-specific paired statistics',all(all(eq(v,summ['paired_rounds'][i][k]) for k,v in x.items()) for i,x in enumerate(paired)))
arm_summary={}
for arm in ARMS:
    rows=[r for r in recomputed if r['policy']==arm];ps=[p for p in policies if p['policy']==arm];repeatable=[r for r in rows if r['success_count']>=2]
    v=dict(successful_policy_evaluations_of48=sum(p['valid'] for p in ps),instances_all3_success_of16=sum(r['success_count']==3 for r in rows),instances_all3_failure_of16=sum(r['success_count']==0 for r in rows),instances_coverage_changed_of16=sum(r['coverage_changed'] for r in rows),instances_with_at_least2_successes=len(repeatable),instances_canonical_route_changed_among_at_least2_successes=sum(r['distinct_success_route_hashes']['route_canonical_sha256']>1 for r in repeatable),instances_ordered_route_changed_among_at_least2_successes=sum(r['distinct_success_route_hashes']['route_ordered_sha256']>1 for r in repeatable),instances_payload_changed_among_at_least2_successes=sum(r['distinct_success_route_hashes']['route_payload_sha256']>1 for r in repeatable),instances_distance_changed_among_at_least2_successes=sum(r['distance']['range']>1e-9 for r in repeatable),instances_native_code_changed_of16=sum(len(set(r['native_code_pattern']))>1 for r in rows),instances_fallback_changed_of16=sum(len(set(r['fallback_pattern']))>1 for r in rows),max_within_instance_distance_range_pct=max(r['distance']['range_pct_of_success_mean'] for r in repeatable),resource_all48={k:stats(p[k] for p in ps) for k in resource_keys if k!='charged_wall_s'},total_physical_policy_cpu_s=sum(p['policy_execution_cpu_s'] for p in ps),total_descriptive_charged_policy_cpu_s=sum(p['charged_cpu_s'] for p in ps),nominal_search_budget_executed_s=sum(p['nominal_search_ms_executed'] for p in ps)/1000)
    arm_summary[arm]=v;ck('Entire arm-level summary '+arm,eq(v,summ['arms'][arm]))
ck('Top-level sample/count/outcome summary',summ['independent_geometry_blocks']==8 and summ['related_instances']==16 and summ['planned_repeats']==3 and summ['policy_count']==96 and summ['potential_requests']==144 and summ['executed_requests']==99 and summ['success_skips']==45 and summ['outcomes']==dict(collections.Counter(r['outcome'] for r in results)) and summ['all6_common_success_instance_n']==16 and summ['all6_common_success_geometry_n']==8)
qualifying=[c for c in contrasts if c['absolute_mean_delta_le_observed_max_repeat_range']]
zero_ties=[c for c in qualifying if abs(c['mean_distance_delta_selector_minus_fixed'])<=1e-9 and c['max_within_arm_repeat_range']<=1e-9]
nonzero_qual=[c for c in qualifying if abs(c['mean_distance_delta_selector_minus_fixed'])>1e-9]
ck('Range threshold and overlaps with tie decomposition',len(qualifying)==summ['all6_with_absolute_mean_arm_delta_le_observed_max_repeat_range']==8 and len(zero_ties)==5 and len(nonzero_qual)==3 and sum(c['observed_success_distance_ranges_overlap'] for c in contrasts)==summ['all6_distance_ranges_overlap']==6)
WARNINGS.append({'severity':'interpretation','finding':'8/16 problems satisfy |mean arm difference| <= observed maximum within-arm range, but 5/8 are exact 0=0 ties. Only 3 problems have a nonzero difference satisfying that descriptor. This is not a significance test, equivalence statement or evidence that eight real effects are noise.','zero_tie_instances':[c['instance'] for c in zero_ties],'nonzero_qualifying_instances':[c['instance'] for c in nonzero_qual]})
write('recomputed_per_instance.json',recomputed);write('recomputed_arm_contrasts.json',contrasts)

# CSV consistency.
reader=list(csv.DictReader(raw(P/'reports/per_instance_repeatability.csv').decode().splitlines()))
ck('CSV row count and independent distance/CPU statistics',len(reader)==32 and all(z['geometry_id']==ds[z['instance']]['geometry_id'] and int(z['successes_of3'])==by[z['instance'],z['arm']]['success_count'] and all(close(float(z[col]),by[z['instance'],z['arm']][key][stat]) for col,key,stat in [('distance_min','distance','min'),('distance_max','distance','max'),('distance_population_std','distance','population_std'),('distance_range','distance','range')]) and all(close(float(z[col]),by[z['instance'],z['arm']]['resource']['policy_execution_cpu_s'][stat]) for col,stat in [('cpu_min','min'),('cpu_max','max'),('cpu_population_std','population_std')]) for z in reader))

# Resource boundaries: distinguish final main-process shell timing from pre-exit snapshot and packaging.
resources=j('evidence/run_resources.json');env=j('evidence/environment.json');exitrec=j('evidence/shell_exit_receipt.json');pack=j('evidence/packaging_receipt.json')
tm={x.split()[0]:float(x.split()[1]) for x in raw(P/'evidence/shell_time.txt').decode().splitlines()}
resource_sums={'solver_search_cpu_s':sum(r.get('solve_cpu_s',0) for r in results),'solver_search_wall_s':sum(r.get('solve_wall_s',0) for r in results),'model_cpu_s':sum(r.get('model_cpu_s',0) for r in results),'checker_cpu_s_first_pass':sum(r.get('check_cpu_s',0) for r in results),'feature_prediction_physical_cpu_s':sum(sum(x['cpu_s'] for x in t.values()) for t in overhead.values())}
ck('All resource component sums recompute',all(close(resources[k],v) for k,v in resource_sums.items()))
ck('Final main run exit zero and CPU bound',exitrec['exit_code']==0 and exitrec['bash_time_fully_closed'] and env['rlimit_cpu']==resources['rlimit_cpu']==[180,180] and tm['user_s']+tm['sys_s']<180 and close(tm['real_s'],37.745) and close(tm['user_s']+tm['sys_s'],37.720))
ck('Pre-exit CPU is correctly distinguished from final shell CPU',resources['process_cpu_s']<tm['user_s']+tm['sys_s'] and close(resources['resource_user_cpu_s']+resources['resource_system_cpu_s'],resources['process_cpu_s'],1e-4))
ck('Post-exit packaging begins after main exit',resources['utc']<exitrec['utc']<pack['utc']<receipt['utc'] and pack['source_run_exited'] and pack['complete_shell_time_sha256']==files['evidence/shell_time.txt'] and pack['complete_shell_exit_receipt_sha256']==files['evidence/shell_exit_receipt.json'])
ck('Two arms have same maximum nominal 500ms, not equal actual CPU',all(sum(qm[k]['budget_ms'] for k in s['run_ids'])==500 for s in sched) and close(sum(q['budget_ms'] for q in reqs)/1000,48) and close(sum(r['budget_ms'] for r in executed)/1000,36.75))
ck('Single-thread declared parameters and environment',env['ortools']=='9.14.6206' and env['OMP_NUM_THREADS']==env['OPENBLAS_NUM_THREADS']=='1' and env['PYTHONHASHSEED']=='0')
host=jl('raw/host_snapshots.jsonl');ck('97 host snapshots cover all 96 policies and end',len(host)==97 and [h.get('policy_sequence_before') for h in host[:-1]]==list(range(96)) and host[-1]['policy_sequence_after']==95)

# Static source path audit. Parse AST; never import or execute experiment code.
source={p:raw(P/p).decode() for p in files if p.endswith('.py') and p.startswith('source/')}
trees={p:ast.parse(t) for p,t in source.items()}
def callname(node):
    if isinstance(node,ast.Name):return node.id
    if isinstance(node,ast.Attribute):return callname(node.value)+'.'+node.attr
    return ''
call_sites=[]
for path,tree in trees.items():
    for node in ast.walk(tree):
        if isinstance(node,ast.Call):call_sites.append({'path':path,'line':node.lineno,'call':callname(node.func)})
coretree=trees['source/core.py'];solve=next(n for n in coretree.body if isinstance(n,ast.FunctionDef) and n.name=='solve')
solvecalls=[callname(n.func) for n in ast.walk(solve) if isinstance(n,ast.Call)]
ck('Every solve constructs local fresh manager/model and reseeds',all(solvecalls.count(n)==1 for n in ['pywrapcp.RoutingIndexManager','pywrapcp.RoutingModel']) and 'routing.solver().ReSeed(SEED)' in source['source/core.py'])
ck('Exactly one production solver entry and no warm-start APIs',sum(c['call']=='core.solve' for c in call_sites)==1 and sum(c['call']=='routing.SolveWithParameters' for c in call_sites)==1 and not any(any(x in c['call'] for x in ['SolveFromAssignment','ReadAssignmentFromRoutes','RestoreAssignment','ApplyLocks']) for c in call_sites))
ck('No fit invocation, generator invocation, subprocess or network APIs',not any(c['call'] in ['selector.fit','source_generator.generate'] or any(x in c['call'] for x in ['subprocess','os.system','os.popen','os.fork','requests.get','requests.post','urlopen','socket.','multiprocessing']) for c in call_sites))
ck('Main CPU hard limit set before heavy imports',source['source/study.py'].splitlines()[2]=='resource.setrlimit(resource.RLIMIT_CPU, (180, 180))')
ck('Actual loop only fixed schedule, fallback success skip',"for item in schedule:" in source['source/study.py'] and "if req['stage']=='fallback' and last['outcome']=='SUCCESS':" in source['source/study.py'] and 'r=core.solve(ds[n],req)' in source['source/study.py'])
ck('No target-outcome input paths in preparation',all(x not in source['source/study.py'].split('def check_result')[0] for x in ["OLD/'raw'","OLD/'reports'"]) and all(p.relative_to(OLD).parts[0] in ['source','inputs','protocol'] for p in allowed_old))
source_review={
 'fresh_model':'source/core.py:50-52 constructs cost/travel, manager and RoutingModel inside every call; RoutingModel.solver().ReSeed(SEED). model, callbacks, dimensions and params are local; source/study.py:212 is sole executed entry.',
 'same_input':'Source ds records are copied unchanged from selected old inputs, never mutated in solve, encode or checker. Inputs/parameter/source hashes match before-target freeze and all144 serialized requests. Each call parses identical config bytes.',
 'no_solution_cache':'No warm-start assignment API; no cross-call model/solution storage. SQRT_CACHE in study is a Decimal objective-checker cache only. Input/model/feature/prediction data reused by design. All solves occur in one Python process, so runtime/allocator/library state is not reset.',
 'native_failures':'All actual99 requests have native code/name, return-assignment flag and timing. Exactly three no-assignment code3 ROUTING_FAIL records; generic outcome UNKNOWN is a minor inherited taxonomy issue, not an omitted failure.',
 'exception_path_limit':'The except block would replace an already returned solver record if check_result raised, so native status could be lost on that unobserved exception path. This run contains no FAIL_EXCEPTION, and all actual native statuses are present. Do not claim arbitrary future exception completeness.',
 'selection':'source/study.py:65-80 reads old freeze and manifest, deduplicates geometry, sorts only coordinate hash/id within family and takes first2. No old results/costs/difficulty files are read by this entrypoint. Input archive has old48 instances only.',
 'boundaries':'Hard180 RLIMIT is sole main Python process. Main import/prepare/run/check/report exit:37.720CPU,37.745wall. source authoring and read-only inspection excluded; post-exit shell receipt-writing helper and final packaging are outside the hard180 process. Packaging measured0.234866379CPU/0.235060156wall through hash/CRC, excludes final receipt write/stdout/interpreter exit. Thus this is not a fully bounded whole-session180CPU total.',
 'limits':'Static source plus consistent hashes/log ordering support prospective freeze/no extra calls; no independent system-call trace, signed timestamp, runtime object-ID instrumentation, full binary hash inventory or host-isolation evidence exists. No claim of scheduler-only cause. Audit executes no author code and no solver.'}
write('source_review.json',source_review);write('source_call_sites.json',call_sites)
WARNINGS.append({'severity':'scope','finding':source_review['exception_path_limit']})
WARNINGS.append({'severity':'scope','finding':'Fresh RoutingModel is verified at source level on every actual solver path. These are not fresh OS processes and do not prove absence of external-library/allocator/runtime carry-over. No object-lifetime instrumentation was recorded.'})
WARNINGS.append({'severity':'resource_boundary','finding':source_review['boundaries']})
WARNINGS.append({'severity':'causal_limit','finding':'Same-seed wall-cutoff route/distance variation is directly observed. CPU/load snapshots do not isolate its cause: timing, system/runtime/library behavior, host scheduling or external work remain possible; no scheduler-only causal claim is supported.'})

inventory_after={str(p.relative_to(P)):sha(p) for p in sorted(P.rglob('*')) if p.is_file()}
ck('Author directory all files unchanged during audit',inventory_before==inventory_after)
ck('Final package unchanged during audit',sha(ZIP)==EXPECTED)
write('author_inventory_sha256.json',inventory_after)
report={'audit_started_utc':START,'audit_finished_utc':datetime.now(timezone.utc).isoformat(),'verdict':'PASS_WITH_CAVEATS' if not ISSUES else 'FAIL','solver_calls_by_auditor':0,'author_code_imports_or_execution':0,'network_or_api_calls':0,'p2_heldout_reads':0,'author_files_modified':False,'audited_package_sha256':EXPECTED,'checks_total':len(CHECKS),'checks_passed':sum(c['passed'] for c in CHECKS),'issues':ISSUES,'warnings':WARNINGS,'independent_units':{'old_geometry_blocks':8,'related_problems':16,'planned_repeats_per_arm':3,'arms':2,'policy_measurements':96,'potential_stage_requests':144,'actual_solver_calls':99,'success_skips':45,'successful_policy_measurements':96},'selected_geometry_ids':[g['geometry_id'] for g in geometries],'arm_summary':arm_summary,'paired_rounds':paired,'contrast_descriptor':{'qualifying_n':len(qualifying),'exact_zero_ties_n':len(zero_ties),'nonzero_qualifying_n':len(nonzero_qual),'zero_tie_instances':[c['instance'] for c in zero_ties],'nonzero_qualifying_instances':[c['instance'] for c in nonzero_qual]},'native_failure_count':len(failures),'native_failures':[{'run_id':r['run_id'],'native_code':r['ortools_status'],'native_name':r['ortools_status_name'],'generic_outcome':r['outcome']} for r in failures],'resource_boundaries':{'main_cpu_final_s':tm['user_s']+tm['sys_s'],'main_wall_final_s':tm['real_s'],'pre_exit_process_cpu_s':resources['process_cpu_s'],'packaging_cpu_s':receipt['packaging_cpu_s'],'packaging_wall_s':receipt['packaging_wall_s'],'main_cpu_hard_limit_s':180,'packaging_outside_main_limit':True,'audit_process_cpu_s_before_final_output':time.process_time()-C0,'audit_wall_s_before_final_output':time.perf_counter()-T0},'source_review':source_review,'checks':CHECKS,'reads':sorted(READS)}
write('audit_results.json',report)
lines=[
 '同 seed 短 wall cutoff 重复性实验：独立只读审计',
 '结论：'+report['verdict']+'；'+str(report['checks_passed'])+'/'+str(report['checks_total'])+'项核验通过。',
 '最终作者包 SHA-256：'+EXPECTED,
 '',
 '1. 实测结论',
 '8个旧几何块、16个相关题；两臂各3次、共96次策略测量。不是96个独立样本，不是新增泛化数据，也不是看到失败后的补跑。',
 '144个潜在请求终态齐全：99个实际求解、45个首阶段已成功后的条件跳过。两臂都48/48策略成功，16题的coverage三元组都为[1,1,1]。',
 'selector臂同题三次规范化路线及距离改变5/16题，最大距离极差/该题成功均值=5.162172778324567%；PCI500改变4/16题，最大1.6909626732827727%。',
 '逐題、逐几何、CPU/Wall的min/max/mean/总体标准差/极差及路线三类hash均从原始结果重新计算，与报告一致。独立从原txt解析并重放全部99请求：96返回解连续时间窗、服务、容量、仓库返回、车辆上限、恰好一次覆盖均通过；整数向上取整travel可行性和60位Decimal目标值复核也通过。',
 '',
 '2. 冻结、选择和执行路径',
 '44个事前freeze项均匹配。16预测、144潜在请求、96计划顺序先于首个target事件；最终ZIP的66个文件与目录逐字节一致，65项SHA清单无误，完整shell计时、退出码及封包脚本都已包含。',
 '24旧几何按每族客户坐标hash升序、几何ID破平局，取前2个，恰好8个；独立重算选择、8特征及80训练题冻结模型的预测，均吻合。未读取旧实验结果或P2数据。',
 '每个实际solver入口在函数内部新建RoutingIndexManager/RoutingModel，重新设同一个seed并重读冻结参数；没有warm-start或解缓存。模型冷启动在同一Python进程内，不能表述为进程、库或硬件状态完全重置。跨请求SQRT_CACHE只服务目标值checker。',
 '',
 '3. 必须保留的限定',
 '3次失败均为b019_w080的SAV首阶段，原生code=3 / ROUTING_FAIL；继承core将泛化outcome写为UNKNOWN。失败/原生码均未遗漏，3次均按事前策略PCI250回退成功。解不存在不等于证明不可行。',
 '若未来checker抛异常，当前except写法会覆盖已返回solver记录，可能丢失原native状态；本轮无异常，实际99个请求原native码齐全。这是未触发的潜在路径缺点。',
 '“8/16题平均臂差不超过观察到的最大同臂极差”中5题是0=0平局，仅3题存在非零臂差且满足该描述。不能说8个真实差异都被噪声淹没；也不能据此作显著性或等价推断。',
 'coverage本轮无变化；存在的是路线/距离变化。不能仅由这些数据将原因唯一归于负载或调度；计时、外部库、共享运行环境等不能被排除。',
 '',
 '4. 资源边界',
 '主运行完整bash receipt：CPU=37.720秒（user37.396+sys0.324），wall=37.745秒，退出码0。main内部退出前快照CPU=37.566856189秒，不应混同最终值。',
 '180 CPU秒hard RLIMIT只覆盖main进程。每策略500ms是名义最大搜索wall，不是端到端500ms，也不是等实际CPU；实际执行名义搜索预算合计36.75秒，计划最坏48秒。',
 '退出后包装独立计时0.234866379CPU秒/0.235060156wall秒，范围到hash/CRC校验前后；最终receipt写入/stdout/解释器退出未包含。外层receipt写入辅助进程、源码编写、只读检查与本审计也不在main的180秒范围。不能宣称整个工作会话含所有步骤严格小于180CPU秒。',
 '',
 '5. 审计范围及产物',
 f'审计只执行自写stdlib复核代码，无solver、作者代码import、API、安装或上传。作者目录全部{len(inventory_before)}文件前后hash不变，包hash不变。',
 '独立重算代码audit_repeatability.py；全量检查audit_results.json；逐题recomputed_per_instance.json；臂差recomputed_arm_contrasts.json；路线重放independent_route_replays.json；源码路径审查source_review.json。',
 f"本审计重算进程CPU（终末输出前）={report['resource_boundaries']['audit_process_cpu_s_before_final_output']:.6f}秒，wall={report['resource_boundaries']['audit_wall_s_before_final_output']:.6f}秒；外层完整计时另见audit_shell_time.txt。阅读/编写/沟通所用时间不计为solver或重算CPU。",
 '证据性质：freeze和事件先后由本地一致日志/源码/hash相互印证，未进行独立系统调用跟踪或第三方时间戳见证；不能将这些记录升级为更强的执行证明。'
]
(O/'audit_report_zh.txt').write_text('\n'.join(lines)+'\n')
print(json.dumps({'verdict':report['verdict'],'checks_passed':report['checks_passed'],'checks_total':report['checks_total'],'issues':ISSUES,'audit_process_cpu_s_before_final_output':report['resource_boundaries']['audit_process_cpu_s_before_final_output'],'audit_wall_s_before_final_output':report['resource_boundaries']['audit_wall_s_before_final_output'],'read_files':len(READS)},ensure_ascii=False))
