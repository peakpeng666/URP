#!/usr/bin/env python3
"""External partitioning of the immutable canonical run_shard protocol."""
import argparse
from datetime import datetime, timezone
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import sys
import time

sys.dont_write_bytecode = True
WORKER = Path(__file__).resolve().parents[1]
SOURCE = WORKER / 'source/runtime-v1'
sys.path.insert(0, str(SOURCE / 'src/research/src'))
from urp_research.cvrplib.io import parse_vrp, contract_for, sha, digest
from urp_research.cvrplib.cli import reserve_run_key
from urp_research.cvrplib.runner import run_payload
from urp_research.cvrplib.evaluate import evaluate_saved


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--resource-manifest', required=True, type=Path)
    parser.add_argument('--lane', required=True, type=int)
    parser.add_argument('--resume', action='store_true')
    args = parser.parse_args()
    resources = json.loads(args.resource_manifest.read_text())
    assert resources['status'] == 'FROZEN'
    assert sha(Path(__file__)) == resources['local_execution_driver_sha256']
    lane = resources['lanes'][args.lane]
    assert lane['lane_index'] == args.lane
    assert sorted(os.sched_getaffinity(0)) == [lane['core']]
    plan_path = SOURCE / 'protocol/formal_plan.json'
    assignment_path = SOURCE / 'protocol/ownership_assignment.json'
    plan_sha, assignment_sha = sha(plan_path), sha(assignment_path)
    assert plan_sha == resources['canonical_plan_sha256']
    assert assignment_sha == resources['assignment_sha256']
    plan = json.loads(plan_path.read_text())
    assignment = json.loads(assignment_path.read_text())
    assert assignment['canonical_plan_sha256'] == plan_sha
    assert assignment['machines']['ubuntu-local']['seeds'] == [3,4]
    assert plan['frozen'] and plan['purpose'] == 'teacher_baseline'
    canonical_driver_sha = sha(SOURCE / 'scripts/run_shard.py')
    assert canonical_driver_sha == assignment['driver_sha256']
    source = SOURCE / 'src/research/src/urp_research/cvrplib'
    def source_hash():
        return digest({str(p.relative_to(source)):sha(p) for p in sorted(source.rglob('*.py'))})
    assert source_hash() == plan['solver_source_sha256']
    manifest = SOURCE / 'src/research/configs/cvrplib_cases.json'
    assert sha(manifest) == plan['case_manifest_sha256']
    assert sha(SOURCE / plan['protocol_path']) == plan['protocol_sha256']
    cases = {c['case_id']:c for c in json.loads(manifest.read_text())['cases']}
    for case in cases.values():
        assert sha(SOURCE / case['instance_path']) == case['instance_sha256']
        assert sha(SOURCE / case['reference']['path']) == case['reference']['sha256']
    for line in (SOURCE / 'requirements.lock').read_text().splitlines():
        if line:
            name, version = line.split('==')
            assert importlib.metadata.version(name) == version
    assignments_path = WORKER / resources['lane_assignments_path']
    assert sha(assignments_path) == resources['lane_assignments_sha256']
    partitions = json.loads(assignments_path.read_text())
    selected = partitions['lanes'][args.lane]['canonical_indices']
    assert len(selected) == lane['planned_keys']
    assert all(plan['schedule'][i]['seed'] in (3,4) for i in selected)
    output = WORKER / lane['output_relative_path']
    output.mkdir(parents=True, exist_ok=args.resume)
    def save(path, obj):
        with path.open('x') as stream:
            json.dump(obj,stream,ensure_ascii=False,indent=2,allow_nan=False)
            stream.write('\n')
    if args.resume:
        assert json.loads((output/'plan.json').read_text()) == plan
    else:
        save(output/'plan.json',plan)
        save(output/'schedule.json',plan['schedule'])
        save(output/'lane-assignment.json',partitions['lanes'][args.lane])
        save(output/'assignment-ubuntu-local.json',assignment)
        save(output/'resource-manifest.json',resources)
        save(output/'environment.json',{'python':sys.version,'platform':platform.platform(),
            'executable':sys.executable,'affinity':sorted(os.sched_getaffinity(0)),
            'packages':{d.metadata['Name']:d.version for d in importlib.metadata.distributions()},
            'cpuinfo':Path('/proc/cpuinfo').read_text(),'plan_sha256':plan_sha,
            'resource_manifest_sha256':sha(args.resource_manifest),
            'resource_batch_id':resources['resource_batch_id']})
    for index in selected:
        # A thermal hold stops new dispatch only; every started attempt retains
        # its original five-second deadline and outcome.
        hold = WORKER / resources['dispatch_hold_relative_path']
        while hold.exists():
            time.sleep(1)
        assert source_hash() == plan['solver_source_sha256']
        assert sha(Path(__file__)) == resources['local_execution_driver_sha256']
        assert sorted(os.sched_getaffinity(0)) == [lane['core']]
        item = plan['schedule'][index]
        case = cases[item['case_id']]
        problem = parse_vrp((SOURCE/case['instance_path']).read_text())
        contract = contract_for(case,problem)
        payload = {k:problem[k] for k in ('coordinates','demands','capacity')}
        payload.update(K=contract['K'],algorithm=item['algorithm'],seed=item['seed'],budget_seconds=item['budget_seconds'])
        taskdir = output/f'{index:05d}-{case["case_id"]}-{item["algorithm"]}-s{item["seed"]}'
        if args.resume and (taskdir/'result.json').exists():
            prior = json.loads((taskdir/'result.json').read_text())
            assert prior['plan_sha256'] == plan_sha
            assert prior['resource_manifest_sha256'] == sha(args.resource_manifest)
            if not (taskdir/'evaluation.json').exists():
                save(taskdir/'evaluation.json',evaluate_saved(SOURCE,manifest,taskdir/'result.json'))
            continue
        if taskdir.exists():
            raise RuntimeError('Interrupted attempt preserved; adjudication required before resume: '+str(taskdir))
        taskdir.mkdir()
        key = reserve_run_key(output/'run-registry',{'plan_sha256':plan_sha,
            'instance_sha256':case['instance_sha256'],'algorithm':item['algorithm'],'seed':item['seed'],
            'budget_seconds':item['budget_seconds'],'contract':contract,
            'solver_source_sha256':plan['solver_source_sha256']},taskdir)
        result = run_payload(payload)
        result.update(purpose='formal_baseline',run_key=key,case_id=case['case_id'],contract=contract,
            instance_sha256=case['instance_sha256'],case_manifest_sha256=sha(manifest),
            protocol_sha256=plan['protocol_sha256'],plan_sha256=plan_sha,
            solver_source_sha256=plan['solver_source_sha256'],cohort=plan['cohort'],
            machine_id='ubuntu-local',assignment_sha256=assignment_sha,
            execution_driver_sha256=sha(Path(__file__)),canonical_execution_driver_sha256=canonical_driver_sha,
            resource_batch_id=resources['resource_batch_id'],resource_manifest_sha256=sha(args.resource_manifest),
            lane_id=lane['lane_id'],supervisor_affinity=sorted(os.sched_getaffinity(0)),
            configured_concurrency=resources['concurrency'],canonical_schedule_index=index,
            resource_core_type=lane['core_type'])
        save(taskdir/'result.json',result)
        evaluation = evaluate_saved(SOURCE,manifest,taskdir/'result.json')
        save(taskdir/'evaluation.json',evaluation)
        print(json.dumps({'canonical_index':index,'lane':args.lane,**item,
            'status':result['status'],'feasible':result['feasible'],'cost':result['cost'],
            'gap_percent':evaluation['gap_percent']}),flush=True)
    save(output/'completed-ubuntu-local.json',{'completed_utc':datetime.now(timezone.utc).isoformat(),
        'planned':len(selected),'attempted':len(selected),'canonical_planned':len(plan['schedule']),
        'purpose':'formal_baseline','plan_sha256':plan_sha,'resource_batch_id':resources['resource_batch_id']})


if __name__ == '__main__':
    main()
