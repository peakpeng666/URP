#!/usr/bin/env python3
"""Make the frozen auditor's sibling module available under isolated Python."""
from pathlib import Path
import runpy
import sys

sys.dont_write_bytecode=True
SOURCE=Path(__file__).resolve().parents[1]/'source/runtime-v1'
sys.path.insert(0,str(SOURCE/'independent'))
sys.argv[0]=str(SOURCE/'independent/audit_results.py')
runpy.run_path(sys.argv[0],run_name='__main__')
