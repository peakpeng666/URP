#!/usr/bin/env python3
"""Launch disjoint lanes and record resource samples without process arguments."""
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import sys
import time

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
from collect_inventory import cpu_ticks, sensors, read


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--spec', required=True, type=Path)
    args = parser.parse_args()
    spec = json.loads(args.spec.read_text())
    root = Path(__file__).resolve().parents[1]
    assert len({x['core'] for x in spec['lanes']}) == len(spec['lanes'])
    output = Path(spec['monitor_output'])
    output.mkdir(parents=True, exist_ok=False)
    env = dict(os.environ)
    env.update({key:'1' for key in ['OMP_NUM_THREADS','OMP_THREAD_LIMIT','OPENBLAS_NUM_THREADS',
        'MKL_NUM_THREADS','BLIS_NUM_THREADS','NUMEXPR_NUM_THREADS','VECLIB_MAXIMUM_THREADS','RAYON_NUM_THREADS']})
    env.update(TZ='UTC',PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1')
    children = []
    handles = []
    launched = []
    for lane in spec['lanes']:
        log = (output / (lane['id'] + '.log')).open('x')
        handles.append(log)
        proc = subprocess.Popen(['taskset','-c',str(lane['core']),*lane['command']],
            cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
        children.append((lane,proc))
        launched.append({'id':lane['id'],'pid':proc.pid,'core':lane['core']})
    (output/'launched.json').write_text(json.dumps({'at_utc':datetime.now(timezone.utc).isoformat(),'lanes':launched},indent=2)+'\n')
    start = time.monotonic()
    prev = cpu_ticks()
    peak = 0
    maximum_threads = {}
    sample_count = 0
    hold_path = root / spec['dispatch_hold_relative_path'] if spec.get('dispatch_hold_relative_path') else None
    thermal_hold_events = []
    with (output/'resources.jsonl').open('x') as stream:
        while True:
            tick = time.monotonic()
            now = cpu_ticks()
            temperatures = sensors()
            relevant = [r['celsius'] for r in temperatures if r['device'] in ('coretemp','acpitz')]
            if relevant: peak = max(peak,max(relevant))
            if hold_path and relevant:
                temp = max(relevant)
                if temp >= spec['pause_new_dispatch_celsius'] and not hold_path.exists():
                    event = {'at_utc':datetime.now(timezone.utc).isoformat(),'event':'thermal_hold_start','celsius':temp}
                    hold_path.write_text(json.dumps(event)+'\n')
                    thermal_hold_events.append(event)
                elif temp <= spec['resume_new_dispatch_celsius'] and hold_path.exists():
                    event = {'at_utc':datetime.now(timezone.utc).isoformat(),'event':'thermal_hold_end','celsius':temp}
                    hold_path.unlink()
                    thermal_hold_events.append(event)
            processes = []
            for p in Path('/proc').iterdir():
                if not p.name.isdigit(): continue
                try:
                    stat = (p/'stat').read_text(); fields=stat[stat.rfind(')')+2:].split()
                    status = (p/'status').read_text().splitlines()
                    row = {'pid':int(p.name),'name':read(p/'comm'),'ppid':int(fields[1]),
                           'threads':int(fields[17]),'rss_bytes':int(fields[21])*os.sysconf('SC_PAGE_SIZE')}
                    for line in status:
                        if line.startswith('Cpus_allowed_list:'):row['affinity']=line.split(':',1)[1].strip()
                    maximum_threads[row['name']] = max(maximum_threads.get(row['name'],0),row['threads'])
                    processes.append(row)
                except (OSError,ValueError,IndexError):continue
            busy={}
            for name,(total,idle) in now.items():
                dt,di=total-prev[name][0],idle-prev[name][1]
                busy[name]=round(100*(dt-di)/dt,3) if dt else None
            prev=now
            mem={}
            for line in Path('/proc/meminfo').read_text().splitlines():
                key,value=line.split(':',1)
                if key in ['MemAvailable','SwapFree','SwapTotal']:mem[key+'_KiB']=int(value.split()[0])
            frequencies={str(lane['core']):read('/sys/devices/system/cpu/cpu'+str(lane['core'])+'/cpufreq/scaling_cur_freq') for lane,_ in children}
            record={'at_utc':datetime.now(timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-start,
                    'loadavg':read('/proc/loadavg'),'cpu_busy_percent':busy,'memory':mem,
                    'sensors':temperatures,'lane_frequencies_khz':frequencies,'visible_processes':processes,
                    'lane_alive':{lane['id']:proc.poll() is None for lane,proc in children},
                    'dispatch_on_thermal_hold':bool(hold_path and hold_path.exists()),
                    'pressure':{x:read('/proc/pressure/'+x) for x in ['cpu','memory','io']}}
            stream.write(json.dumps(record,separators=(',',':'))+'\n');stream.flush()
            sample_count+=1
            if not any(proc.poll() is None for _,proc in children):break
            time.sleep(max(0,1-(time.monotonic()-tick)))
    codes={lane['id']:proc.wait() for lane,proc in children}
    for handle in handles:handle.close()
    summary={'at_utc':datetime.now(timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-start,
             'samples':sample_count,'max_package_or_acpi_celsius':peak,'max_threads_by_process_name':maximum_threads,
             'thermal_hold_events':thermal_hold_events,'exitcodes':codes}
    (output/'completed.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary),flush=True)
    if any(codes.values()):raise SystemExit(1)


if __name__=='__main__':main()
