本机 seeds 3–4 已完成：1802/1802，缺失 0，重复 0。
主机 ubuntu-local，资源批次 ubuntu-local-pcore4-20261015-b01，4 路 P 核 7/6/5/4，每路单线程。
状态分布：{"OK": 768, "TIMEOUT_WITH_FEASIBLE_INCUMBENT": 962, "NO_SOLUTION": 70, "TIMEOUT_NO_SOLUTION": 2}。
超时及失败全部保留；质量均值请同时查看可用分母。
summary.json / runs.csv 为本机单列分析；independent-result-audit.json 为独立路线与身份检查。
原始路线、评分、环境、计划、资源逐秒记录见 batches/；固定源码、协议与输入以已核验运行包为准；包内保留锁定依赖和执行入口证据。
