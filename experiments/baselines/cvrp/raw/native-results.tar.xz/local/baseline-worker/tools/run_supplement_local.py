from pathlib import Path
import sys,os,json,runpy
sys.dont_write_bytecode=True
w=Path('/home/peakpeng/Desktop/URP/baseline-worker')
r=w/'supplement/cohort_b'
jdk=Path(json.loads((w/'reports/isolated-jdk17.json').read_text())['jdk_home'])
os.environ['PATH']=str(jdk/'bin')+':'+os.defpath
os.environ['JAVA_HOME']=str(jdk)
sys.path.insert(0,str(r))
sys.argv=[str(r/'run_cohort.py'),'--run','--host-id','local']
runpy.run_path(sys.argv[0],run_name='__main__')
