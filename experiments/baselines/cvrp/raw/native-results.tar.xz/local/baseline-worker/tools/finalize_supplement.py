from collections import Counter
from fractions import Fraction
from pathlib import Path
import csv,hashlib,importlib.util,json,os,tarfile,math
W=Path(__file__).resolve().parents[1];R=W/'supplement/cohort_b';S=W/'source/runtime-v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def main():
 os.sched_setaffinity(0,{23})
 completion=json.loads((R/'local-resource-monitor/completed.json').read_text());assert not any(completion['exitcodes'].values())
 freeze=json.loads((R/'COHORT_FREEZE.json').read_text());assert sha(R/'COHORT_FREEZE.json')=='c98e8aae374917cf2a1f45284f4de09c81a179eff85e923714da8cd4f1d30743'
 for p,h in freeze['files'].items():assert sha(R/p)==h,p
 local=[r for r in freeze['schedule'] if r['host_id']=='local'];assert len(local)==96
 key=lambda r:(r['algorithm'],r['case_id'],r['seed'])
 expected={key(r) for r in local};records={};out=W/'reports/supplement-final';out.mkdir(exist_ok=False)
 cases={c['case_id']:c for c in json.loads((S/'src/research/configs/cvrplib_cases.json').read_text())['cases']}
 spec=importlib.util.spec_from_file_location('native_independent_validate',S/'independent/validate.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
 rows=[];errors=[]
 for path in sorted((R/'formal-runs-local').glob('*.json')):
  if path.name.endswith('.started.json') or path.name=='host_build.json':continue
  r=json.loads(path.read_text());k=key(r);assert k in expected and k not in records,k;records[k]=r
  assert r['host_id']=='local' and r['cohort']=='vendor_X12' and r['budget_seconds']==5
  c=cases[r['case_id']];assert c['contract']['id']=='standard-X-unlimited' and c['contract']['vehicle_limit'] is None
  assert sha(S/c['instance_path'])==c['instance_sha256']==r['instance_sha256']
  assert r['deadline_ns']-r['start_ns']==5_000_000_000
  p=v.read_instance(S/c['instance_path']);inc=r['incumbent'];check=None;timing=False
  if inc:
   raw_cost=inc['cost']
   exact_integer_value=type(raw_cost) is int or (type(raw_cost) is float and math.isfinite(raw_cost) and raw_cost.is_integer() and abs(raw_cost)<=2**53)
   checked_cost=int(raw_cost) if exact_integer_value else raw_cost
   check=v.check(p,inc['routes'],checked_cost,len(p['demands'])-1)
   timing=type(inc.get('receipt_ns')) is int and r['start_ns']<=inc['receipt_ns']<=r['deadline_ns'] and inc.get('before_deadline') is True and inc in r['events']
  eligible=bool(r['feasible_incumbent'] and check and check['valid'] and timing and not r['invalid_outputs'])
  if r['feasible_incumbent'] and not eligible:errors.append(path.name)
  reference_routes,reference_cost=v.read_solution(S/c['reference']['path'])
  reference_check=v.check(p,reference_routes,reference_cost,len(p['demands'])-1)
  assert reference_check['valid'] and sha(S/c['reference']['path'])==c['reference']['sha256']
  gap=Fraction(100*(int(inc['cost'])-reference_cost),reference_cost) if eligible else None
  rows.append({'algorithm':r['algorithm'],'case_id':r['case_id'],'seed':r['seed'],'budget_seconds':5,
   'status':r['status'],'termination_status':r['termination_status'],'signed_returncode':r['returncode'],
   'eligible':eligible,'cost':int(inc['cost']) if eligible else None,'raw_reported_cost':inc['cost'] if inc else None,'raw_reported_cost_type':type(inc['cost']).__name__ if inc else None,'lossless_integral_float_checked':bool(inc and type(inc['cost']) is float and exact_integer_value),'gap_percent':float(gap) if gap is not None else None,
   'gap_exact':str(gap) if gap is not None else None,'cpu_seconds':r['cpu_seconds'],'validation_cpu_seconds':r['validation_cpu_seconds'],
   'wall_seconds':r['wall_seconds'],'machine_id':'ubuntu-local','core':7,'concurrency':1,
   'resource_batch_id':'ubuntu-local-native-cohort-b-20261015','result_path':str(path.relative_to(W)),
   'result_sha256':sha(path),'independent_candidate_check':json.dumps(check,separators=(',',':')),'timing_pass':timing})
 assert set(records)==expected and not errors,(len(records),errors)
 starts=list((R/'formal-runs-local').glob('*.started.json'));assert len(starts)==96
 build=json.loads((R/'formal-runs-local/host_build.json').read_text())
 for name,h in build['binaries'].items():assert sha(R/name)==h
 summary={'cohort':'vendor_X12','main_4505_plan_excluded':True,'host_id':'local','planned':96,'attempted':96,
  'missing':0,'duplicate_keys':[],'audit_errors':errors,'eligible':sum(r['eligible'] for r in rows),
  'status_counts':dict(Counter(r['status'] for r in rows)),'termination_counts':dict(Counter(r['termination_status'] for r in rows)),
  'signed_returncode_counts':dict(Counter(str(r['signed_returncode']) for r in rows)),
  'machine_id':'ubuntu-local','core':7,'concurrency':1,'java_target_release':17,
  'max_package_or_acpi_celsius':completion['max_package_or_acpi_celsius'],
  'numeric_output_note':'AILS emits integral JSON floats. Before independent integer-distance checking, finite exact integral values <=2^53 are converted without rounding; raw bytes/type preserved. Non-integral values are never rounded into validity.',
  'timing_note':'Five-second launch/native-init/metric-check/search budget includes synchronous incumbent validation; kept separate from main cohort and other hosts.'}
 save(out/'summary-and-coverage.json',summary);save(out/'independent-result-audit.json',{'summary':summary,'rows':rows})
 with (out/'runs.csv').open('w') as f:
  writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
 (out/'README.txt').write_text('Separate vendor_X12 cohort: local seeds1-4, 12 unrestricted X cases, AILS-II and SISR, 96 planned rows. Parameters and five-second budget unchanged. All statuses and native exit codes retained. Single P core7, serial; JVM helper threads share this CPU. References used only by this post-run independent audit.\n')
 files=[p for base in [R/'formal-runs-local',R/'local-resource-monitor',out] for p in base.rglob('*') if p.is_file()]
 files.extend([R/'COHORT_FREEZE.json',R/'PREDECLARATION.md',W/'manifests/supplement-local-resources.json',
  W/'reports/supplement-local-build.json',W/'reports/isolated-jdk17.json',W/'reports/supplement-smoke-ails.json',
  W/'reports/supplement-smoke-sisr.json',W/'reports/supplement-numeric-representation-note.json',W/'tools/run_supplement_local.py',W/'tools/finalize_supplement.py',
  W/'logs/supplement-build-ails.log',W/'logs/supplement-build-sisr.log'])
 manifest=W/'deliverables/RESULTS_MANIFEST-supplement.json';save(manifest,{'cohort':'vendor_X12','planned':96,'files':[{'path':str(p.relative_to(W)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files]})
 archive=W/'deliverables/ubuntu-local-native-cohort-b-96-results.tar.gz'
 with tarfile.open(archive,'w:gz',compresslevel=5) as tar:
  for p in [*files,manifest]:tar.add(p,arcname='baseline-worker/'+str(p.relative_to(W)),recursive=False)
 delivery={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'summary':summary}
 save(W/'reports/supplement-delivery-ready.json',delivery);print(json.dumps(delivery,indent=2))
if __name__=='__main__':main()
